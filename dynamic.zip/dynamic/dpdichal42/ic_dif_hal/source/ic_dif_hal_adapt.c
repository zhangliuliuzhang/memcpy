#ifdef DYNAMIC_API_TEST
/* 这个文件原则上不对高层提供接口，这里全是调试使用 */
#include "ic_dif_hal_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "tsg.h"

static UINT32 g_sIc_dif_halRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 IcHalApiDCTsgCtrlAdapt(UINT32 cmd, UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
    return IcHalApiDCTsgCtrl(uiDifChan, uiCarrId, uiRadioMode, uiEn);
}

__attribute((constructor)) void _ic_dif_hal_adapt_init_()
{
    if (NOTREGIST == g_sIc_dif_halRegistFlag)
    {
        BspRegistService(BSP_CMD_IC_HAL_API_D_C_TSG_CTRL, IcHalApiDCTsgCtrlAdapt);

        g_sIc_dif_halRegistFlag = ISREGIST;
    }
}
#endif
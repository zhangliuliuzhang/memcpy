#ifdef DYNAMIC_API_TEST
/* 这个文件原则上不对高层提供接口，这里全是调试使用 */
#include "ic_opt_hal_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "cpri_reg.h"
#include "opt_tsg.h"

static UINT32 g_sIc_opt_halRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 IcHalCpriSetFrTestModeAdapt(UINT32 cmd, UINT32 ulLogOptNo, UINT32 ulTestMode)
{
    return IcHalCpriSetFrTestMode(ulLogOptNo, ulTestMode);
}

static UINT32 IcHalApiOptTsgSwitchAdapt(UINT32 cmd, UINT32 uAntChan, UINT32 uCarrNo, UINT32 uRadioMode, UINT32 uTsgType, UINT32 uSwitch)
{
    return IcHalApiOptTsgSwitch(uAntChan, uCarrNo, uRadioMode, uTsgType, uSwitch);
}

static UINT32 IcHalCpriInternalLoopbackAdapt(UINT32 cmd, UINT32 ulLogOptNo, UINT32 ulSwitch)
{
    return IcHalCpriInternalLoopback(ulLogOptNo, ulSwitch);
}

__attribute((constructor)) void _ic_opt_hal_adapt_init_()
{
    if (NOTREGIST == g_sIc_opt_halRegistFlag)
    {
        BspRegistService(BSP_CMD_IC_HAL_CPRI_SET_FR_TEST_MODE, IcHalCpriSetFrTestModeAdapt);
        BspRegistService(BSP_CMD_IC_HAL_API_OPT_TSG_SWITCH, IcHalApiOptTsgSwitchAdapt);
        BspRegistService(BSP_CMD_IC_HAL_CPRI_INTERNAL_LOOPBACK, IcHalCpriInternalLoopbackAdapt);

        g_sIc_opt_halRegistFlag = ISREGIST;
    }
}
#endif

#include "bsppub.h"

UINT32 BspBoardPreInit(VOID);
UINT32 BspBoardInit(VOID);

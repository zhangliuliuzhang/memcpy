
#include "r925xadm.h"
#include "boardcpuid.h"
#include "boardwatchdog.h"

/* ==============================================================
    cpuId 参数
 ============================================================== */
static T_CpuIdInfo s_CpuIdParaTbl[] = 
{
    {0,  0,  1,  0},
};

#if 0 /* 和APP、OSS确认 */
UINT32 BspBoardPreInit(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal |= BspInitCpuIdInfoTbl(s_CpuIdParaTbl, sizeof(s_CpuIdParaTbl)/sizeof(T_CpuIdInfo));
    retVal |= BspWatchDogInit();
    return retVal;
}

UINT32 BspBoardInit(VOID)
{
    UINT32 retVal = BSP_OK;
    return retVal;
}
#endif

__attribute((constructor)) void _r925x_adm_()
{
    (VOID)BspInitCpuIdInfoTbl(s_CpuIdParaTbl, sizeof(s_CpuIdParaTbl)/sizeof(T_CpuIdInfo));
    (VOID)BspWatchDogInit();
}

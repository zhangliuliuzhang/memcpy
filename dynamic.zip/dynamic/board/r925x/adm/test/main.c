#if BSP_MAKE_VER

#include <stdio.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "boardinit.h"
#include "watchdog.h"
#include "ushellapi.h"


extern void blockticksig(void);
void main()
{
    dbgInfo("hello from dpdic4.2!\n");

#if 1
    blockticksig();
    BspGetRpuId();
    dbgInfo("build time: %s %s V0.1\n", __DATE__, __TIME__);

#endif
    while(1)
    {
        sleep(1);
    }

    return ;
}

#endif /* BSP_MAKE_VER */

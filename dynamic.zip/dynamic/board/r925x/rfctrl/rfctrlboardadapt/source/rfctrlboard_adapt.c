#include "rfctrlboard_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "boardinit.h"
#include "bsppub.h"

static UINT32 g_sR925x_rfctrlboardRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspDeepSleepSwAdapt(UINT32 cmd, UINT32 sw)
{
    return BspDeepSleepSw(sw);
}

static UINT32 BspBoardPreInitAdapt(UINT32 cmd)
{
    return BspBoardPreInit();
}

static UINT32 BspBoardInitAdapt(UINT32 cmd)
{
    return BspBoardInit();
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 BspStubInitAdapt(UINT32 cmd)
{
    return BspStubInit();
}
#endif

__attribute((constructor)) void _r925x_rfctrlboard_adapt_init_()
{
    if (NOTREGIST == g_sR925x_rfctrlboardRegistFlag)
    {
        BspRegistService(BSP_CMD_DEEP_SLEEP_SW, BspDeepSleepSwAdapt);
        BspRegistService(BSP_CMD_BOARD_PRE_INIT, BspBoardPreInitAdapt);
        BspRegistService(BSP_CMD_BOARD_INIT, BspBoardInitAdapt);

#ifdef DYNAMIC_API_TEST
        /* 测试接口注册 */
        BspRegistService(BSP_CMD_STUB_INIT, BspStubInitAdapt);
#endif

        g_sR925x_rfctrlboardRegistFlag = ISREGIST;
    }
}

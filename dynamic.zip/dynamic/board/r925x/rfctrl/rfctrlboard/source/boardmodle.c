/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardmodle.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化流程函数
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/


#include "bsppub.h"
#include "bspcomm.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "funccommon_a.h"
#include "rruinfo.h"
#include "boardinit.h"
#include "boardtemprary.h"
#include "exprn.h"
#include "boardmodle.h"

/**************************************************************************
                            函数声明
**************************************************************************/
static UINT32 BspChangeFlowPreLgcType(VOID);
static UINT32 BspChangeFlowPostLgcType(VOID);
#ifdef PLAT_X86_TEST
UINT32 BspAdsTestGetHwId(VOID);
#endif

/**************************************************************************
                            类型声明
**************************************************************************/
/**************************************************************************
                            全局变量
**************************************************************************/
static T_BoardActFuncTblItem s_tBoardActFuncTblItem[E_BOARD_PROCESS_TYPE_MAX] = {};
static T_FuncChangeFlowPostLgcType s_tFuncChangeFlowPostLgcType[E_BOARD_PROCESS_TYPE_MAX] = {};

/* 需要单板传递给单板模型的信息 */
static T_BoardInterFace s_tBoardInterface = 
{
    E_BOARD_ONE_CHIP_RF_CTRL_TYPE,
    AAU_BD_NUM,
    NULL,
    BspChangeFlowPreLgcType,
    BspChangeFlowPostLgcType
};

/**************************************************************************
                            内部接口
**************************************************************************/
UINT32 BspSetBoardActFuncTblItem(UINT32 boardProcessType, T_BoardActFuncTbl *pBoardActFuncTbl, UINT32 boardActFuncTblLen)
{
    if(boardProcessType >= E_BOARD_PROCESS_TYPE_MAX)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pBoardActFuncTbl);

    s_tBoardActFuncTblItem[boardProcessType].pBoardActFuncTbl = pBoardActFuncTbl;
    s_tBoardActFuncTblItem[boardProcessType].boardActFuncTblLen = boardActFuncTblLen;

    return BSP_OK;
}

UINT32 BspSetChangeFlowPostFunc(UINT32 boardProcessType, FUNC_CHANGE_FLOW_POST_LGC_TYPE pFuncChangeFlowPostLgcType)
{
    if(boardProcessType >= E_BOARD_PROCESS_TYPE_MAX)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pFuncChangeFlowPostLgcType);

    s_tFuncChangeFlowPostLgcType[boardProcessType].funcChangeFlowPostLgcType = pFuncChangeFlowPostLgcType;

    return BSP_OK;
}


/************************************************************************
*  函数名称   : BspChangeFlowPreLgcType
*  功能描述   : 本接口在获取boardLgcType之前调用，故无法区分单板，
*            仅用于调整【E_HARD_FEATURE_GET_LGC_TYPE】前的平台初始化动作
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*------------------------------------------------------------------------
*/
static UINT32 BspChangeFlowPreLgcType(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 boardProcessIndex = 0;

    /*  ==== 增加单板下定义的初始化动作 ==== */
    for (boardProcessIndex = 0; boardProcessIndex < E_BOARD_PROCESS_TYPE_MAX; boardProcessIndex++)
    {
        if (NULL != s_tBoardActFuncTblItem[boardProcessIndex].pBoardActFuncTbl)
        {
            retVal |= BspBoardModleSetActByTbl(s_tBoardActFuncTblItem[boardProcessIndex].pBoardActFuncTbl, s_tBoardActFuncTblItem[boardProcessIndex].boardActFuncTblLen);
        }
    }
    
    BspSetChangIdMask(0xfcff);  //bit8,9不识别，区分不同上行VGA器件的，对软件bomid匹配不影响
#ifdef PLAT_X86_TEST
        retVal |= BspBoardModleSetActFunc(E_HARD_FEATURE_GET_BOMID, BspAdsTestGetHwId, "BspAdsTestGetHwId", BSP_INIT_NOT_RECORD);
#endif

    return retVal;
}

/************************************************************************
*  函数名称   : BspChangeFlowPostLgcType
*  功能描述   : 本接口在获取boardLgcType之后调用，可以区分单板，
*            仅用于调整【E_HARD_FEATURE_GET_LGC_TYPE】后的初始化动作
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*------------------------------------------------------------------------
*/
static UINT32 BspChangeFlowPostLgcType(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 boardProcessIndex = 0;

    /*  ==== 增加单板下定义的初始化动作 ==== */
    for (boardProcessIndex = 0; boardProcessIndex < E_BOARD_PROCESS_TYPE_MAX; boardProcessIndex++)
    {
        if (NULL != s_tFuncChangeFlowPostLgcType[boardProcessIndex].funcChangeFlowPostLgcType)
        {
            retVal |= s_tFuncChangeFlowPostLgcType[boardProcessIndex].funcChangeFlowPostLgcType();
        }
    }

    return retVal;
}

/**************************************************************************
                            对外接口
**************************************************************************/


/**************************************************************************
                            自举接口
**************************************************************************/
static __attribute((constructor)) void boardModleCfg()
{
    (VOID)BspBoardModleBrdIfInit(&s_tBoardInterface);
}

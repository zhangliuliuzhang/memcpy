#if BSP_MAKE_VER

#include <stdio.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "boardinit.h"
#include "watchdog.h"
#include "ushellapi.h"

#include "bsp_framework_api.h"

extern void blockticksig(void);
void main()
{
    dbgInfo("hello from dpdic4.2!\n");

    BspDynLibInit("bspservice.json");
    BspLoadModules();

#ifndef DEBUG_REGACCESS
    ushell_init();
#endif
#if 1
    blockticksig();

    BspBoardPreInit();
    /* BspWatchDogDisable(); */
    dbgInfo("build time: %s %s V0.1\n", __DATE__, __TIME__);

    /* DpdIcHalRegTblInit(); */
    BspBoardInit();

    ver();
    temp(NULL);
    mcucall(0, "ver", NULL);
    showpagridvolt(0, 1, 0, 31);
    BspSetCellTsg(0,0,0x10,17,1,1);//发TSG

    for (int i = 0; i < 3; i++)
    {
        sleep(3);
        powshow();
    }

#endif
    while(1)
    {
        sleep(1);
    }

    return ;
}

#endif /* BSP_MAKE_VER */

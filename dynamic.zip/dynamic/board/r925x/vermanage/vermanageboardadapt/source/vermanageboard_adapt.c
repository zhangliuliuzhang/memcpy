#include "vermanageboard_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"

static UINT32 g_sR925x_vermanageboardRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspBoardPreInitAdapt(UINT32 cmd)
{
    return BspBoardPreInit();
}

static UINT32 BspBoardInitAdapt(UINT32 cmd)
{
    return BspBoardInit();
}

static UINT32 verAdapt(UINT32 cmd, UINT32 flag)
{
    ver(flag);
    return BSP_OK;
}

__attribute((constructor)) void _r925x_vermanageboard_adapt_init_()
{
    if (NOTREGIST == g_sR925x_vermanageboardRegistFlag)
    {
        BspRegistService(BSP_CMD_BOARD_PRE_INIT, BspBoardPreInitAdapt);
        BspRegistService(BSP_CMD_BOARD_INIT, BspBoardInitAdapt);
        BspRegistService(BSP_CMD_VER, verAdapt);

        g_sR925x_vermanageboardRegistFlag = ISREGIST;
    }
}

#if BSP_MAKE_VER

#include <stdio.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "boardinit.h"

#include "bsp_framework_api.h"

extern void blockticksig(void);
void main()
{

    BspDynLibInit("bspservice.json");
    BspLoadModules();
    ushell_init();
    BspBoardPreInit();
    
    /* BspWatchDogDisable(); */
    dbgInfo("build time: %s %s V0.1\n", __DATE__, __TIME__);

    /* DpdIcHalRegTblInit(); */
    BspBoardInit();


    while(1)
    {
        
        sleep(1);        
    }

    return ;
}

#endif /* BSP_MAKE_VER */

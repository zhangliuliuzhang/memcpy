
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "boardmodle.h"

/**************************************************************************
                       单板特例功能初始化参数定义开始
**************************************************************************/

/* ==============================================================
    光口帧头初始化信息
 ============================================================== */
static UINT32 s_testAct1BoardGroup0 = 0; /* 单板分组1 */
static UINT32 s_testAct1BoardGroup1 = 1; /* 单板分组2 */
static UINT32 s_testAct1BoardGroup2 = 2; /* 单板分组3 */

static T_DataCfgGroup s_tDpdicOptMeasParaMap[] =
{
    {(VOID*)&s_testAct1BoardGroup0, 1, sizeof(UINT32)},
    {(VOID*)&s_testAct1BoardGroup1, 1, sizeof(UINT32)},
    {(VOID*)&s_testAct1BoardGroup2, 1, sizeof(UINT32)},
};

/**************************************************************************
                      单板特例功能初始化参数定义结束
**************************************************************************/
static VOID BoardTemporaryData(VOID)
{
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_TEMPRARY_TEST_ACT1,0,s_tDpdicOptMeasParaMap);   /*业务*/
}
static __attribute((constructor)) void TemporaryDataCfg()
{
   BspBoardModleSetDataFunc(E_BOARD_TEMPRARY_COMPO, BoardTemporaryData);
}


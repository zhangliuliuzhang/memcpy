/*****************************************************************************

*/
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "hardfeaturewrapper.h"
#include "board_ic4_2.h"
#include "flash.h"
#include "rruinfo.h"
#include "boardinit.h"
#include "boardverprotect.h"
#include "regdrv_access.h"
#include "svproperty.h"
#include "regdrv_accesstbl.h"
#include "boardcpuid.h"
#include "boardid.h"
/**************************************************************************
                       单板硬件特性及连接关系参数定义开始
**************************************************************************/
static T_BomidFlashInfo s_bomidFlashInfo = 
{
    FLASH_BOMID_OFFSET,
    FLASH_BOMID_SIZE    
};

static T_FlashInfo s_tBoardFlashInfo = 
{
    NOR_FLASH_SIZE + NAND_FLASH_SIZE,
    FLASH_SECTOR_SIZE,
    FLASH_PARTITION_NUM,
    {
        {"/dev/mtd0", FLASH_BOOT_PART_OFFSET,  FLASH_BOOT_PART_SIZE},
        {"/dev/mtd1", FLASH_BSP_PART_OFFSET,   FLASH_BSP_PART_SIZE},
        {"/dev/mtd2", FLASH_SECRET_KEY_OFFSET, FLASH_SECRET_KEY_SIZE},
    //  {"/dev/mtd3", FLASH_JFFS2_OFFSET,      FLASH_JFFS2_SIZE},
    }
};

static TVerGroup s_verGroup[AAU_BD_NUM]=
{
    [MF5TAA90Z]    = {"MF5TAA90Z", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x0100}},  /*IC4.2 FDD4T 900M,时钟为au5518，DLDVGA:声光电*/
    [MF5TAA90Y]    = {"MF5TAA90Y", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x0001}},  /*IC4.2 FDD4T 900M,时钟为idt8a35018d, DLDVGA:qpb9350*/
    [MF5TAA90W]    = {"MF5TAA90W", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x8203}},  /*IC4.2 FDD4T 900M,时钟为RC32012,DLDVGA:明夷*/
    [MF5TAA72Z]    = {"MF5TAA72Z", R9214H_S7200,    {0x0193, 0x0000, 0x0004, 0x0200}},  /*IC4.2 FDD4T 700M,时钟为au5518,DLDVGA:明夷*/
    [MF4TAA211]    = {"MF4TAA211", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x8208}},  /*IC4.2 FDD2T 2100M 时钟为au5518,DLDVGA:明夷*/
    [MG6TAA1821A]  = {"MG6TAA1821A", R9126_M1821,   {0x01A3, 0x0000, 0x0000, 0x0208}},  /*IC4.2 FDD2T异频合路机型 1800M+2100M  时钟为au5518*/
    [MF5TAB90W]    = {"MF5TAB90W", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x8213}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为RC32012,DLDVGA:明夷*/
    [MF5TAB90Z]    = {"MF5TAB90Z", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为au5518,DLDVGA:明夷*/
    [MF5TAB90Y]    = {"MF5TAB90Y", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB90X]    = {"MF5TAB90X", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x8212}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为au5517,DLDVGA:明夷*/
    [MF5TAB72W]    = {"MF5TAB72W", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x8213}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为RC32012,DLDVGA:明夷*/
    [MF5TAB72Z]    = {"MF5TAB72Z", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为au5518,DLDVGA:明夷*/
    [MF5TAB72Y]    = {"MF5TAB72Y", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB72X]    = {"MF5TAB72X", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x8212}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为au5517,DLDVGA:明夷*/
    [MF4TAA901]    = {"MF4TAA901", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x8208}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为au5518,DLDVGA:明夷*/
    [MF4TAA902]    = {"MF4TAA902", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x8209}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为idt8a35018d,DLDVGA:明夷*/
    [MF4TAA903]    = {"MF4TAA903", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x020A}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为au5517,DLDVGA:明夷*/
    [MF4TAA904]    = {"MF4TAA904", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x020B}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为RC32012,DLDVGA:明夷*/
    [MF4TAA215]    = {"MF4TAA215", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x8218}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为au5518,DLDVGA:明夷*/
    [MF4TAA216]    = {"MF4TAA216", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x8219}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为idt8a35018d,DLDVGA:明夷*/
    [MF4TAA217]    = {"MF4TAA217", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x021A}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为au5517,DLDVGA:明夷*/
    [MF4TAA218]    = {"MF4TAA218", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x021B}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为RC32012,DLDVGA:明夷*/
    [MF5TAB18Z]    = {"MF5TAB18Z", R9254E_S1800_A8A,{0x0193, 0x0000, 0x0003, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 1800M 时钟为au5518,DLDVGA:明夷*/
    [MF5TAB18Y]    = {"MF5TAB18Y", R9254E_S1800_A8A,{0x0193, 0x0000, 0x0003, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 1800M 时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB21Z]    = {"MF5TAB21Z", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为au5518,DLDVGA:明夷*/
    [MF5TAB21Y]    = {"MF5TAB21Y", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB21X]    = {"MF5TAB21X", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8212}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为au5517,DLDVGA:明夷*/
    [MF5TAB21W]    = {"MF5TAB21W", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8213}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为RC32012,DLDVGA:明夷*/
    [MF5TAC21Z]    = {"MF5TAC21Z", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0230}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为au5518,DLDVGA:明夷*/
    [MF5TAC21Y]    = {"MF5TAC21Y", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0231}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAC21X]    = {"MF5TAC21X", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8232}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为au5517,DLDVGA:明夷*/
    [MF5TAC21W]    = {"MF5TAC21W", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8233}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为RC32012,DLDVGA:明夷*/
    [MF5TAB21X_60W]= {"MF5TAB21X", R9254_S2100_A6A,{0x0193, 0x0000, 0x0002, 0x8212}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为au5517,DLDVGA:明夷*/
    [MF5TAB21W_60W]= {"MF5TAB21W", R9254_S2100_A6A,{0x0193, 0x0000, 0x0002, 0x8213}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为RC32012,DLDVGA:明夷*/
    [MF5TAB26Z]    = {"MF5TAB26Z", R9254_S2600_A6A,{0x0193, 0x0000, 0x0005, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 2600M 时钟为au5518,DLDVGA:明夷*/
    [MF5TAB26Y]    = {"MF5TAB26Y", R9254_S2600_A6A,{0x0193, 0x0000, 0x0005, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 2600M 时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB17Z]    = {"MF5TAB17Z", R9254E_S1700_A8A,{0x0193, 0x0000, 0x0006, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 1700M 时钟为au5518,DLDVGA:明夷*/
    [MF5TAB17Y]    = {"MF5TAB17Y", R9254E_S1700_A8A,{0x0193, 0x0000, 0x0006, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 1700M 时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB19Z]    = {"MF5TAB19Z", R9254E_S1900_A8A,{0x0193, 0x0000, 0x0007, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 1900M 时钟为au5518,DLDVGA:明夷*/
    [MF5TAB19Y]    = {"MF5TAB19Y", R9254E_S1900_A8A,{0x0193, 0x0000, 0x0007, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 1900M 时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB85Z]    = {"MF5TAB85Z", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x0210}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为au5518,DLDVGA:明夷*/
    [MF5TAB85Y]    = {"MF5TAB85Y", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x0211}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB85X]    = {"MF5TAB85X", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x8212}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为au5517,DLDVGA:明夷*/
    [MF5TAB85W]    = {"MF5TAB85W", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x8213}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为RC32012,DLDVGA:明夷*/
    [MF5TAB85Z_CP5]= {"MF5TAB85Z", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x1210}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为au5518,DLDVGA:明夷*/
    [MF5TAB85Y_CP5]= {"MF5TAB85Y", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x1211}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为idt8a35018d,DLDVGA:明夷*/
    [MF5TAB85X_CP5]= {"MF5TAB85X", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x9212}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为au5517,DLDVGA:明夷*/
    [MF5TAB85W_CP5]= {"MF5TAB85W", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x9213}},  /*IC4.2 电源新改版机型FDD4T 850M  时钟为RC32012,DLDVGA:明夷*/
    [MGCTAA1821A]   = {"MGCTAA1821A", R9242_M1821_A8A, {0x01AB, 0x0000, 0x0000, 0x0E1B}},  /*IC4.2 电源新改版机型FDD_UBR1821  时钟为RC32012,DLDVGA:明夷*/
    [MGCTAA1821B]   = {"MGCTAA1821B", R9242_M1821_A8A, {0x01AB, 0x0000, 0x0000, 0x0E1A}},  /*IC4.2 电源新改版机型FDD_UBR1821  时钟为5517,DLDVGA:明夷*/
    [MG6TAA1821A_AU5518]  = {"MG6TAA1821A", R9126_M1821,   {0x01A3, 0x0000, 0x0000, 0x0010}},  /*IC4.2 FDD2T异频合路机型 1800M+2100M  时钟为au5518*/
    [MG6TAA1826A_8A35018D]  = {"MG6TAA1821A", R9126_M1821,   {0x01A3, 0x0000, 0x0000, 0x0011}},  /*IC4.2 FDD2T异频合路机型 1800M+2100M  时钟为dt8a35018d*/
    [MG6TAA1826A_AU5517]  = {"MG6TAA1821A", R9126_M1821,   {0x01A3, 0x0000, 0x0000, 0x0012}},  /*IC4.2 FDD2T异频合路机型 1800M+2100M  时钟为aAU5517*/
    [MG6TAA1826A_RC32012]  = {"MG6TAA1821A", R9126_M1821,   {0x01A3, 0x0000, 0x0000, 0x0013}},  /*IC4.2 FDD2T异频合路机型 1800M+2100M  时钟为RC32012*/
};

static TVerGroup s_verGroup_Ex[]=
{
    [MF5TAA90Z]    = {"MF5TAA90Z", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x0200}},  /*IC4.2 FDD4T 900M,时钟为au5518，DLDVGA:明夷*/
    [MF5TAB90W]    = {"MF5TAB90W", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x8113}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为RC32012,DLDVGA:声光电*/
    [MF5TAB90Z]    = {"MF5TAB90Z", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为au5518,DLDVGA:声光电*/
    [MF5TAB90Y]    = {"MF5TAB90Y", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB90X]    = {"MF5TAB90X", R9244_S9000_D6A, {0x0193, 0x0000, 0x0001, 0x8112}},  /*IC4.2 电源新改版机型FDD4T 900M,时钟为au5517,DLDVGA:声光电*/
    [MF5TAB72W]    = {"MF5TAB72W", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x8113}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为RC32012,DLDVGA:声光电*/
    [MF5TAB72Z]    = {"MF5TAB72Z", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为au5518,DLDVGA:声光电*/
    [MF5TAB72Y]    = {"MF5TAB72Y", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB72X]    = {"MF5TAB72X", R9214H_S7200_D8A,{0x0193, 0x0000, 0x0004, 0x8112}},  /*IC4.2 电源新改版机型FDD4T 700M,时钟为au5517,DLDVGA:声光电*/
    [MF4TAA901]    = {"MF4TAA901", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x8108}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为au5518,DLDVGA:声光电*/
    [MF4TAA902]    = {"MF4TAA902", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x8109}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为idt8a35018d,DLDVGA:声光电*/
    [MF4TAA903]    = {"MF4TAA903", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x010A}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为au5517,DLDVGA:声光电*/
    [MF4TAA904]    = {"MF4TAA904", R9252E_S9000,    {0x0197, 0x0000, 0x0002, 0x010B}},  /*IC4.2 电源新改版机型FDD2T 900M,时钟为RC32012,DLDVGA:声光电*/
    [MF4TAA215]    = {"MF4TAA215", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x8118}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为au5518,DLDVGA:声光电*/
    [MF4TAA216]    = {"MF4TAA216", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x8119}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF4TAA217]    = {"MF4TAA217", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x011A}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为au5517,DLDVGA:声光电*/
    [MF4TAA218]    = {"MF4TAA218", R9252E_S2100,    {0x0197, 0x0000, 0x0000, 0x011B}},  /*IC4.2 电源新改版机型FDD2T 2100M 时钟为RC32012,DLDVGA:声光电*/
    [MF5TAB18Z]    = {"MF5TAB18Z", R9254E_S1800_A8A,{0x0193, 0x0000, 0x0003, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 1800M 时钟为au5518,DLDVGA:声光电*/
    [MF5TAB18Y]    = {"MF5TAB18Y", R9254E_S1800_A8A,{0x0193, 0x0000, 0x0003, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 1800M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB21Z]    = {"MF5TAB21Z", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为au5518,DLDVGA:声光电*/
    [MF5TAB21Y]    = {"MF5TAB21Y", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB21X]    = {"MF5TAB21X", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8112}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为au5517,DLDVGA:声光电*/
    [MF5TAB21W]    = {"MF5TAB21W", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8113}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为RC32012,DLDVGA:声光电*/
    [MF5TAC21Z]    = {"MF5TAC21Z", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0130}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为au5518,DLDVGA:声光电*/
    [MF5TAC21Y]    = {"MF5TAC21Y", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x0131}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAC21X]    = {"MF5TAC21X", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8132}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为au5517,DLDVGA:声光电*/
    [MF5TAC21W]    = {"MF5TAC21W", R9254E_S2100_A8A,{0x0193, 0x0000, 0x0000, 0x8133}},  /*IC4.2 电源插座温度检测机型FDD4T 2100M,时钟为RC32012,DLDVGA:声光电*/
    [MF5TAB21X_60W]= {"MF5TAB21X", R9254_S2100_A6A,{0x0193, 0x0000, 0x0002, 0x8112}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为au5517,DLDVGA:声光电*/
    [MF5TAB21W_60W]= {"MF5TAB21W", R9254_S2100_A6A,{0x0193, 0x0000, 0x0002, 0x8113}},  /*IC4.2 电源新改版机型FDD4T 2100M 时钟为RC32012,DLDVGA:声光电*/
    [MF5TAB26Z]    = {"MF5TAB26Z", R9254_S2600_A6A,{0x0193, 0x0000, 0x0005, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 2600M 时钟为au5518,DLDVGA:声光电*/
    [MF5TAB26Y]    = {"MF5TAB26Y", R9254_S2600_A6A,{0x0193, 0x0000, 0x0005, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 2600M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB17Z]    = {"MF5TAB17Z", R9254E_S1700_A8A,{0x0193, 0x0000, 0x0006, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 1700M 时钟为au5518,DLDVGA:声光电*/
    [MF5TAB17Y]    = {"MF5TAB17Y", R9254E_S1700_A8A,{0x0193, 0x0000, 0x0006, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 1700M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB19Z]    = {"MF5TAB19Z", R9254E_S1900_A8A,{0x0193, 0x0000, 0x0007, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 1900M 时钟为au5518,DLDVGA:声光电*/
    [MF5TAB19Y]    = {"MF5TAB19Y", R9254E_S1900_A8A,{0x0193, 0x0000, 0x0007, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 1900M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB85Z]    = {"MF5TAB85Z", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x0110}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为au5518,DLDVGA:声光电*/
    [MF5TAB85Y]    = {"MF5TAB85Y", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x0111}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB85X]    = {"MF5TAB85X", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x8112}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为au5517,DLDVGA:声光电*/
    [MF5TAB85W]    = {"MF5TAB85W", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x8113}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为RC32012,DLDVGA:声光电*/
    [MF5TAB85Z_CP5]= {"MF5TAB85Z", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x1110}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为au5518,DLDVGA:声光电*/
    [MF5TAB85Y_CP5]= {"MF5TAB85Y", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x1111}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为idt8a35018d,DLDVGA:声光电*/
    [MF5TAB85X_CP5]= {"MF5TAB85X", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x9112}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为au5517,DLDVGA:声光电*/
    [MF5TAB85W_CP5]= {"MF5TAB85W", R9254_S8500_A6A, {0x0193, 0x0000, 0x0008, 0x9113}},  /*IC4.2 电源新改版机型FDD4T 850M 时钟为RC32012,DLDVGA:声光电*/
    [MGCTAA1821A]  = {"MGCTAA1821A", R9242_M1821_A8A, {0x01AB, 0x0000, 0x0000, 0x0D1B}},  /*IC4.2 电源新改版机型FDD_UBR1821  时钟为RC32012,DLDVGA:声光电*/
    [MGCTAA1821B]  = {"MGCTAA1821B", R9242_M1821_A8A, {0x01AB, 0x0000, 0x0000, 0x0D1A}},  /*IC4.2 电源新改版机型FDD_UBR1821  时钟为5517,DLDVGA:声光电*/
};

static T_VerProtectInfo s_Protect_VerInfo =
{
    PROTECT_ZONE_ADDRESS,
    PROTECT_ZONE_SIZE,
    PROTECT_ZONE_FULL_VER,
};

static T_RruPropertyInfo s_tRruProperty =
{
    ascbuf,
    sizeof(ascbuf)
};

static T_Reg_Tbl s_regTbl[REG_MACRO_MAX] =
{
    BSP_SET_REG_TBL(REG_HIGH_RESERVED_MEM_BSP,        REG_FUNCDOMAIN_CPU_DDR3,BSP_MEM_ADDR - SYS_MEM_TOP,        REG_ACCESS_VAL,0,0,REG_NONEED_INIT),
    BSP_SET_REG_TBL(REG_HIGH_RESERVED_MEM_MGR,        REG_FUNCDOMAIN_CPU_DDR3,OSS_MEM_ADDR - SYS_MEM_TOP,        REG_ACCESS_VAL,0,0,REG_NONEED_INIT),
    BSP_SET_REG_TBL(REG_HIGH_RESERVED_MEM_APP1,       REG_FUNCDOMAIN_CPU_DDR3,APP_RESERVED_ADDR - SYS_MEM_TOP,   REG_ACCESS_VAL,0,0,REG_NONEED_INIT),
    BSP_SET_REG_TBL(REG_HIGH_RESERVED_MEM_USER_DEFINE,REG_FUNCDOMAIN_CPU_DDR3,BSP_VER_PROTECT_ADDR - SYS_MEM_TOP,REG_ACCESS_VAL,0,0,REG_NONEED_INIT),
};

static T_DataCfgGroup s_regTblMap[] =
{
    {(VOID*)s_regTbl, NELEMENTS(s_regTbl), sizeof(T_Reg_Tbl)},
};

static T_CpuIdInfo s_CpuIdParaTbl[] = 
{
    {0,  0,  1,  0},
};

static T_DataCfgGroup s_TcpuIdParaTbl[] =
{
    {(VOID*)s_CpuIdParaTbl, NELEMENTS(s_CpuIdParaTbl), sizeof(T_CpuIdInfo)},
};

static T_AllRunVerList s_Protect_VerList_ACEXIST =
{
    3,
    0,
    {
        {3,"cur3.swv","MGR"},
        {17,"cur17.swv","ACDSP"},
        {19,"cur19.swv","DPDDSP"},
    },
    {

    }
};

static T_AllRunVerList s_Protect_VerList_ACNOEXIST =
{
    2,
    0,
    {
        {3,"cur3.swv","MGR"},
        {19,"cur19.swv","DPDDSP"},
    },
    {

    }
};

static T_DataCfgGroup s_Protect_VerListCfgInfo[] =
{
    {(VOID*)&s_Protect_VerList_ACEXIST, 1, sizeof(T_AllRunVerList)},
    {(VOID*)&s_Protect_VerList_ACNOEXIST, 1, sizeof(T_AllRunVerList)},
};

static T_BoardIdItem s_devIdList[] =
{
    DEVICE_ID(TEMPSENSOR_Rf0   , "TempRf"     , 8),
    DEVICE_ID(CPU0             , "Cpu"        , 1),
    DEVICE_ID(BOARD0           , "Board"      , 1),
    DEVICE_ID(BOARDSOC0        , "BoardSoc"   , 8),
    DEVICE_ID(FPGA0            , "Fpga"       , 1),
    DEVICE_ID(PLL_TX0          , "PllTx"      , 8),
    DEVICE_ID(PLL_RX0          , "PllRx"      , 8),
    DEVICE_ID(PLL_FB0          , "PllFb"      , 8),
    DEVICE_ID(DATT_TX0         , "DattTx"     , 8),
    DEVICE_ID(DATT_RX0         , "DattRx"     , 8),
    DEVICE_ID(DATT_PRX0        , "DattPrx"    , 8),
    DEVICE_ID(ADC_PRX0         , "AdcFb"      , 8),
    DEVICE_ID(DAC_TX0          , "DacTx"      , 8),
    DEVICE_ID(ADC_RX0          , "AdcRx"      , 8),
    DEVICE_ID(TRANSIVER        , "RFTR"       , 8),
    DEVICE_ID(GRID_VOLT_PA0    , "GridVoltPa" , 8),
    DEVICE_ID(CURR0            , "Curr"       , 18),
    DEVICE_ID(PLL_SYS          , "PllSys"     , 1),
    DEVICE_ID(SFP0             , "Sfp"        , 4),
    DEVICE_ID(OPT0             , "Opt"        , 4),
    DEVICE_ID(TEMPSENSOR_PA0     , "TempPa"     , 8),
    DEVICE_ID(TEMPSENSOR_RF      , "TempRf"     , 8),
    DEVICE_ID(TEMPSENSOR_BOARD   , "TempBoard"  , 1),
    DEVICE_ID(FREQ_CFG_PA0       , "PaFreq"     , 8),
    DEVICE_ID(PA0                , "Pa"         , 8),
    DEVICE_ID(TEMPSENSOR_RPDC    , "TempRpdc"   , 4),
    DEVICE_ID(RPDC_DAC0          , "RpdcDac"    , 8),
    DEVICE_ID(RPDC_ADC0          , "RpdcAdc"    , 8),
    DEVICE_ID(EEPROM_RPDC        , "EepromRpdc" , 1),
    DEVICE_ID(RPDC_INFO          , "RpdcInfo"   , 1),
    DEVICE_ID(PWR_MCU            , "PwrMcu"     , 1),
    DEVICE_ID(KDA                , "Kda"        , 1),
    DEVICE_ID(USHELL             , "Ushell"     , 1),
    DEVICE_ID(TSG                , "Tsg"        , 8),
    DEVICE_ID(DVGA_RX0           , "DvgaRx"     , 8),
    DEVICE_ID(TEMPSENSOR_SFP     , "TempSfp"    , 2),
};

static T_BoardIdItem s_funcIdList[] =
{
    FUNC_ID(LED0            , "Led"            , 6),
    FUNC_ID(AGC0            , "Agc0"           , BSP_MAX_RX_CHAN),
    FUNC_ID(CARRIER0        , "Carrier"        , BSP_MAX_CARR_NUM),
    FUNC_ID(PA0             , "Pa"             , BSP_MAX_TX_CHAN),
    FUNC_ID(TSG_TX0         , "TsgTx"          , BSP_MAX_TX_CHAN),
    FUNC_ID(TX0             , "Tx"             , BSP_MAX_TX_CHAN),
    FUNC_ID(CFR0            , "Cfr"            , BSP_MAX_TX_CHAN),
    FUNC_ID(FREQ0           , "Freq"           , BSP_MAX_TX_CHAN),
    FUNC_ID(PA_CFG_FREQ0    , "OaFreq"         , BSP_MAX_TX_CHAN),
    FUNC_ID(AISG_POWER      , "AisgPower"      , 1),
    FUNC_ID(PA_DTX0         , "PaDtx"          , BSP_MAX_TX_CHAN),
};

static T_BoardIdItem s_thresholdIdList[] =
{
    THRESHOLD_ID(VSWR                  , "Vswr"             ,   1),
    THRESHOLD_ID(VSWR_PRE              , "Vswrper"          ,   1),
    THRESHOLD_ID(OVER_TEMPER           , "OverTemper"       ,   1),
    THRESHOLD_ID(SLIGHTOVER_TEMPER     , "SlightOverTemper" ,   1),
    THRESHOLD_ID(UNDER_TEMPER          , "UnderTemper"      ,   1),
    THRESHOLD_ID(SLIGHTUNDER_TEMPER    , "SlightUnderTemper" ,  1),
    THRESHOLD_ID(OVER_TOTAL_TX_POWER   , "OverTotalTxPower" ,   1),
    THRESHOLD_ID(UNDER_TOTAL_TX_POWER  , "UnderTotalTxPower",   1),
    THRESHOLD_ID(OVER_TOTAL_RX_POWER   , "OverTotalRxPower" ,   1),
    THRESHOLD_ID(UNDER_TOTAL_RX_POWER  , "UnderTotalRxPower",   1),
    THRESHOLD_ID(OVER_CARRIER_TX_POWER , "OverCarrierTxPower" , 1),
    THRESHOLD_ID(UNDER_CARRIER_TX_POWER, "UnderCarrierTxPower", 1),
    THRESHOLD_ID(OVER_CARRIER_RX_POWER , "OverCarrierRxPower" , 1),
    THRESHOLD_ID(UNDER_CARRIER_RX_POWER, "UnderCarrierRxPower", 1),
    THRESHOLD_ID(OVER_PA_TEMPER        , "PaOverTemper"       , 1),
    THRESHOLD_ID(SLIGHTOVER_PA_TEMPER  , "PaSlightOverTemper" , 1),
    THRESHOLD_ID(OVER_PWR_TEMPER       , "PwrOverTemper"      , 1),
    THRESHOLD_ID(SLIGHTOVER_PWR_TEMPER , "PwrSlightOverTemper", 1),
    THRESHOLD_ID(OVER_POWER_PWR        , "PwrOverPower"       , 1),
    THRESHOLD_ID(OVER_TOTAL_POWER_TX0  , "OverTotalPowerTx"   , BSP_MAX_TX_CHAN),
    THRESHOLD_ID(POWER_ADJ_TX0         , "PowerAdjTx0"        , 1),
};

static T_BoardIdItem s_gainIdList[] =
{
    GAIN_ID(TX0         , "Tx"         , BSP_MAX_TX_CHAN),
    GAIN_ID(FB0         , "Fb"         , BSP_MAX_PRX_CHAN),
    GAIN_ID(RXM0        , "RxM"        , BSP_MAX_RX_CHAN),
    GAIN_ID(CFR_TX0     , "Cfr"        , BSP_MAX_TX_CHAN),
    GAIN_ID(CARR0_TX0   , "Carr0Tx"    , BSP_MAX_TX_CHAN),
    GAIN_ID(CARR1_TX0   , "Carr1Tx"    , BSP_MAX_TX_CHAN),
    GAIN_ID(CARR0_RXM0  , "Carr0RxM"   , BSP_MAX_RX_CHAN),
    GAIN_ID(CARR1_RXM0  , "Carr1RxM"   , BSP_MAX_RX_CHAN),
    GAIN_ID(CARR0_RXD0  , "Carr0RxD"   , BSP_MAX_RX_CHAN),
    GAIN_ID(CARR1_RXD0  , "Carr1RxD"   , BSP_MAX_RX_CHAN),
    GAIN_ID(DIF_TX0     , "DifTx"      , BSP_MAX_TX_CHAN),
};
 /**************************************************************************
                       单板硬件特性及连接关系参数定义结束
 **************************************************************************/
static VOID SetHardFeatureData(VOID)
{
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_BOARD_ID,0,s_verGroup);
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_BOARD_ID,1,s_verGroup_Ex);
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_DEV_ID,0,s_devIdList);
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_FUNC_ID,0,s_funcIdList);
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_THRESHOLD_ID,0,s_thresholdIdList);
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_GAIN_ID,0,s_gainIdList);
    BOARD_MODLE_SET_LEVEL1_DATA(E_HARD_FEATURE_GET_BOMID,0,s_bomidFlashInfo);
    BOARD_MODLE_SET_LEVEL1_DATA(E_HARD_FEATURE_FLASH_INIT,0,s_tBoardFlashInfo);
    BOARD_MODLE_SET_LEVEL1_DATA(E_HARD_FEATURE_INIT_VER_PROTECT,0,s_Protect_VerInfo);
    BOARD_MODLE_SET_LEVEL1_DATA(E_HARD_FEATURE_RRU_PROPERTY,0,s_tRruProperty);
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_HARD_FEATURE_REG_TBL,0,s_regTblMap);
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_HARD_FEATURE_CPUID_INIT,0,s_TcpuIdParaTbl);
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_HARD_FEATURE_INIT_PROTECT_FILELIST,0,s_Protect_VerListCfgInfo);
    /*
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_BOARD_ID,0,s_verGroup);
    BOARD_MODLE_SET_LEVEL1_ARRAY(E_HARD_FEATURE_BOARD_ID,1,s_verGroup_Ex);
    */
}

static __attribute((constructor)) void HardFeatureDataCfg()
{
    BspBoardModleSetDataFunc(E_BOARD_HARD_FEATURE_COMPO, SetHardFeatureData);
}


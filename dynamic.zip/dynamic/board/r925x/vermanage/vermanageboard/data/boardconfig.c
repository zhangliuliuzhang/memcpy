/*****************************************************************************
*/
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "boardinit.h"


/**************************************************************************
                    单板Id和配置方案的对应关系定义开始
**************************************************************************/

/*
  注意: 只有深度为2的动作才需要在本文件中指定配置方案与单板的对应关系
*/

#define BOARD_CFG_START(boardId)   [boardId] = {  {
#define BOARD_CFG_END              } },
#define CHIP_CFG_START(chip)       [chip] = { {
#define CHIP_CFG_END               } },
#define ACT_CFG(acttype,cfg)       [acttype%BOARD_COMPO_ACT_SPACE]  = cfg+1,

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   系统软件服务初始化功能
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
static T_CompoCfgIdxBoardMap s_softServiceCfgMap[AAU_BD_NUM] =
{
    BOARD_CFG_START(MF4TAA901)
        CHIP_CFG_START(0)
            ACT_CFG(E_SOFT_SERVICE_UDPMSGMODULE_INIT,       0)
            ACT_CFG(E_SOFT_SERVICE_CORE_AFFINITY_CFG,       0)
           // ACT_CFG(E_SOFT_SERVICE_UART_INIT,               0)
          //  ACT_CFG(E_SOFT_SERVICE_INIT_RRU_FORM,           2)
        CHIP_CFG_END
    BOARD_CFG_END
};



/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   周边外设器件及主要芯片上电初始化
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
static T_CompoCfgIdxBoardMap s_chipPowerofCfgMap[AAU_BD_NUM] =
{
    BOARD_CFG_START(MF4TAA901)
        CHIP_CFG_START(0)
           //ACT_CFG(E_CHIP_POWERON_AC_DSP_LOAD,                  0)
           //ACT_CFG(E_CHIP_POWERON_DPDIC_PAD,                    0)
           //ACT_CFG(E_CHIP_POWERON_RFPLL_INIT,                   0)
           //ACT_CFG(E_CHIP_POWERON_ATT_INIT,                     0)
           //ACT_CFG(E_CHIP_POWERON_DAC_CALLBACK,                 0)
           //ACT_CFG(E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA,       0)
           //ACT_CFG(E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,       0)
           //ACT_CFG(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA,        0)
           //ACT_CFG(E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,         0)
           //ACT_CFG(E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,          0)
           //ACT_CFG(E_CHIP_POWERON_FILE_MOVE,                    0)
           //ACT_CFG(E_CHIP_POWERON_TRANSCEIVER_INIT,             0)
           //ACT_CFG(E_CHIP_POWERON_DPDIC_PWRSAVE,                0)
           //ACT_CFG(E_CHIP_POWERON_RFTBL_FILE_MOVE,              0)
        CHIP_CFG_END
    BOARD_CFG_END
};

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   数字芯片Tx/Rx/FB 3大链路
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */ 
static T_CompoCfgIdxBoardMap s_digTrxLinkBoardMap[AAU_BD_NUM] =
{
    BOARD_CFG_START(MF4TAA901)
        CHIP_CFG_START(0)
           //ACT_CFG(E_TRX_LINK_DPDIC_OPT_TX_SERDES,    0)
           //ACT_CFG(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,    0)
           //ACT_CFG(E_TRX_LINK_DPDIC_OPT_MEAS,         0)
           //ACT_CFG(E_TRX_LINK_DPDIC_OPT_HAL_INIT,     2)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_CLK,          0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_SAMRATE,      0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_CFG,          0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_RESALLOC,     0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_TX_ROUTE,     0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_TX_PARA,      0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_TX_204,       0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_RX_ROUTE,     0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_FB_ROUTE,     0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_FR,           0)
           //ACT_CFG(E_TRX_LINK_DPDIC_DIF_CFG_TDD,      0)
           //ACT_CFG(E_TRX_LINK_DPDIC_204_LINK,         0)
           //ACT_CFG(E_TRX_LINK_DPDIC_204_SYSREF,       0)
           //ACT_CFG(E_TRX_LINK_DPDIC_204_TXEQ,         0)
           //ACT_CFG(E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,0)
        CHIP_CFG_END
    BOARD_CFG_END
};


/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   临时功能
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
static T_CompoCfgIdxBoardMap s_tempraryFuncCfgMap[AAU_BD_NUM] =
{
    BOARD_CFG_START(MF4TAA901)
        CHIP_CFG_START(0)

        CHIP_CFG_END
    BOARD_CFG_END
};
/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   单板硬件特性及连接关系
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
 +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
static T_CompoCfgIdxBoardMap s_hardFeatureCfgMap[AAU_BD_NUM] =
{
    BOARD_CFG_START(MF4TAA901)
        CHIP_CFG_START(0)
            ACT_CFG(E_HARD_FEATURE_RRU_PROPERTY,            0)
            /*ACT_CFG(E_HARD_FEATURE_RRU_INFO,        0)*/
            //ACT_CFG(E_HARD_FEATURE_DRV_TBL,                 0)
            ACT_CFG(E_HARD_FEATURE_REG_TBL,                 0)
            //ACT_CFG(E_HARD_FEATURE_SPI_BUS,                 0)
            //ACT_CFG(E_HARD_FEATURE_IIC_BUS,                 0)
            //ACT_CFG(E_HARD_FEATURE_CALI_FILE,               0)
            //ACT_CFG(E_HARD_FEATURE_LINK_INFO_INIT,          0)
            /*ACT_CFG(E_HARD_FEATURE_DPDIC_REG_TBL,   0)*/
            ACT_CFG(E_HARD_FEATURE_CPUID_INIT,              0)
           //ACT_CFG(E_HARD_FEATURE_TDDIO_CTRL_INIT,         0)
           //ACT_CFG(E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,    0)
            ACT_CFG(E_HARD_FEATURE_INIT_PROTECT_FILELIST,   0)
            //ACT_CFG(E_HARD_FEATURE_OPT_PAPT_INIT,           0)
            //ACT_CFG(E_HARD_FEATURE_PAPT_UPDATA,             0)
            //ACT_CFG(E_HARD_FEATURE_CRM_PAPT_INIT,           0)
           //ACT_CFG(E_HARD_FEATURE_PWRTEMP_THRESHOLD_INIT,  0)
           //ACT_CFG(E_HARD_FEATURE_PA_VOLT_INIT,            0)
           //ACT_CFG(E_HARD_FEATURE_PWR_MAP_CHAN_INIT,       0)
        CHIP_CFG_END
    BOARD_CFG_END
};

static T_CompoCfgIdxBoardMap s_functionBoardMap[AAU_BD_NUM] =
{
    BOARD_CFG_START(MF4TAA901)
        CHIP_CFG_START(0)
            //ACT_CFG(E_FUNCTION_RRU_DEFABILITY,          0)
            //ACT_CFG(E_FUNCTION_PRE_ALLOC,               0)
            //ACT_CFG(E_FUNCTION_TX_FREQ_CFG,             0)
            //ACT_CFG(E_FUNCTION_RX_FREQ_CFG,             0)
            //ACT_CFG(E_FUNCTION_TX_RF_DELAY,             0)
            //ACT_CFG(E_FUNCTION_RX_RF_DELAY,             0)
            //ACT_CFG(E_FUNCTION_TX_DELT_DELAY,           0)
            //ACT_CFG(E_FUNCTION_RX_DELT_DELAY,           0)
            //ACT_CFG(E_FUNCTION_FDD_DELAY,               0)
            //ACT_CFG(E_FUNCTION_POWCALC_INIT,            0)
            //ACT_CFG(E_FUNCTION_DL_POWCALC_PARA_INIT,    0)
            //ACT_CFG(E_FUNCTION_UL_POWCALC_PARA_INIT,    0)
            //ACT_CFG(E_FUNCTION_OPENLOOP_PARA_INIT,      0)
            //ACT_CFG(E_FUNCTION_PAPT_PARA_INIT,          0)
            //ACT_CFG(E_FUNCTION_GSM_POWCALC_INIT,        0)
            //ACT_CFG(E_FUNCTION_CFR_COMM_PARA_INIT,      0)
            //ACT_CFG(E_FUNCTION_CFR_KICOMM_PARA_INIT,    0)
            //ACT_CFG(E_FUNCTION_CFR_KNCOMM_PARA_INIT,    0)
            //ACT_CFG(E_FUNCTION_CFR_DYN_PARA_INIT,       0)
            //ACT_CFG(E_FUNCTION_CFR_PAR_PARA_INIT,       0)
            //ACT_CFG(E_FUNCTION_DPD_PAR_PARA_INIT,       0)
            //ACT_CFG(E_FUNCTION_TRX_DIG_GAIN_INIT,       0)
            //ACT_CFG(E_FUNCTION_POWCALC_THREAD_INIT,     0)
            //ACT_CFG(E_FUNCTION_VGA_CTRL_PARA_INIT,         0)
            //ACT_CFG(E_FUNCTION_VGA_CTRL_MGC_PARA_INIT,     0)
            //ACT_CFG(E_FUNCTION_VGA_CTRL_COMP_PARA_INIT,    0)
            //ACT_CFG(E_FUNCTION_MGC_SHEET_PARA_INIT,        0)
            //ACT_CFG(E_FUNCTION_IF_BUS_PARA_INIT,           0)
            //ACT_CFG(E_FUNCTION_RF_BUS_PARA_INIT,           0)
            //ACT_CFG(E_FUNCTION_RF_ATT_PARA_INIT,           0)
            //ACT_CFG(E_FUNCTION_RF_ATT_REAL_VAL_INIT,       0)
            //ACT_CFG(E_FUNCTION_VGA_REAL_VAL_INIT,          0)
            //ACT_CFG(E_FUNCTION_VGA_CHN_ROUTE_INIT,         0)
            //ACT_CFG(E_FUNCTION_VGA_ADDR_ROUTE_INIT,        0)
            //ACT_CFG(E_FUNCTION_MGC_TIME_SLICE_PARA_INIT,   0)
            //ACT_CFG(E_FUNCTION_CHAN_GROUP_INIT,            0)
            //ACT_CFG(E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,0)
            //ACT_CFG(E_FUNCTION_PAPT_REPORT_RECOVER,        0)
            //ACT_CFG(E_FUNCTION_RXSCAN_INIT,                0)
            //ACT_CFG(E_FUNCTION_DTX_ABILITY_SUPPORT,        0)
            //ACT_CFG(E_FUNCTION_REV_PROTECT_INIT,           0)
            //ACT_CFG(E_FUNCTION_REV_GATE_PARA_INIT,         0)
            //ACT_CFG(E_FUNCTION_LNAOFF_PARA_INIT,           0)
            //ACT_CFG(E_FUNCTION_PWR_VOLT_ALM_THR,           0)
       CHIP_CFG_END
   BOARD_CFG_END
};
 /**************************************************************************
                     单板和功能项目配置方案的对应关系定义结束
 **************************************************************************/
static VOID SetBoardConfig(VOID)
{
    BspBoardModleSetBoardMap(E_BOARD_SOFT_SERVICE_COMPO, s_softServiceCfgMap, NELEMENTS(s_softServiceCfgMap));
    BspBoardModleSetBoardMap(E_BOARD_HARD_FEATURE_COMPO, s_hardFeatureCfgMap, NELEMENTS(s_hardFeatureCfgMap));
    BspBoardModleSetBoardMap(E_BOARD_CHIP_POWERON_COMPO, s_chipPowerofCfgMap, NELEMENTS(s_chipPowerofCfgMap));
    BspBoardModleSetBoardMap(E_BOARD_DIG_TRX_LINK_COMPO, s_digTrxLinkBoardMap, NELEMENTS(s_digTrxLinkBoardMap));
    BspBoardModleSetBoardMap(E_BOARD_FUNCTION_COMPO, s_functionBoardMap, NELEMENTS(s_functionBoardMap));
    BspBoardModleSetBoardMap(E_BOARD_TEMPRARY_COMPO, s_tempraryFuncCfgMap, NELEMENTS(s_tempraryFuncCfgMap));    
}

static __attribute((constructor)) void BoardConfig()
{
    BspBoardModleSetBoardMapFunc(SetBoardConfig);
}


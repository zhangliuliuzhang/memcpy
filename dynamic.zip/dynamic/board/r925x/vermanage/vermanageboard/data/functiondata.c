/******************************************************************************/
#include "functionwrapper.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"

/**************************************************************************
                            业务功能参数定义开始
**************************************************************************/

/**************************************************************************
                             业务功能参数定义结束
 **************************************************************************/
static VOID SetFunctionData(VOID)
{
    /*
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_FUNCTION_RRU_DEFABILITY,0,s_tRruDefAbilityPara);
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_FUNCTION_PRE_ALLOC,0,s_tDpdicPreAllocParaMap);
    */

}

static __attribute((constructor)) void FunctionDataCfg()
{
    BspBoardModleSetDataFunc(E_BOARD_FUNCTION_COMPO, SetFunctionData);
}



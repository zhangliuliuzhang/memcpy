/*****************************************************************************

*/
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "chippoweronwrapper.h"


 /**************************************************************************
               周边外设器件及主要芯片上电初始化参数定义结束
 **************************************************************************/
static VOID SetChipPoweronData(VOID)
{
    /*
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_CHIP_POWERON_DAC_CALLBACK, 0, s_tDacInterfaceCallBackInfo);
    BOARD_MODLE_SET_LEVEL1_DATA(E_CHIP_POWERON_DSP_LOAD, 0, s_DspLoadInfo);
    */
}

static __attribute((constructor)) void ChipPowerOnDataCfg()
{
    BspBoardModleSetDataFunc(E_BOARD_CHIP_POWERON_COMPO, SetChipPoweronData);
}

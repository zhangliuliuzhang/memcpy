/*****************************************************************************

*/
#include "boardmodlecommon.h"
#include "boardcorefunc.h"
#include "boardmodle_ic4_2.h"
#include "softservicewrapper.h"
#include "board_ic4_2.h"
#include "udpmsg_ic.h"

/**************************************************************************
                       系统软件服务初始化参数定义开始
**************************************************************************/
/* ==============================================================
    udp ip和端口信息
 ============================================================== */
static T_UdpPathSocketCfgInfo s_tLocalUdpPathSocketCfg =
{
  2,                                                      /*单板具有的udp交互类型个数，HEAD_TYPE_ID_SOC_DSP等，特别注意主从架构下主MGR 从MGR 从片的功能差异*/
  {
  {
      HEAD_TYPE_ID_SOC_DSP,                                                 /*消息类型 cpu和dsp交互*/
      {UDP_PATH_ID_SOC_DSP_SEND,"198.33.33.2",SOC_DSP_BIND_PORT_TX,0},   /*pathid cpu端ip port号 是否绑定 DSP希望对他们来说cpu的ip固定，不要区分主从.100 和.2*/
      {UDP_PATH_ID_SOC_DSP_RECV,"198.33.33.2",SOC_DSP_BIND_PORT_RX,0},      /*这里要注意 单片时IC的ip为198.33.33.2 不再像是3.0为.100*/
	  "198.33.34.2",                                                       /*DSP ip 198.33.34.2*/
  },
  {
      HEAD_TYPE_ID_SOC_ACDSP,
      {UDP_PATH_ID_SOC_ACDSP_SEND,"198.33.33.100",NXP_ACDSP_BIND_PORT_TX,BIND},
      {UDP_PATH_ID_SOC_ACDSP_RECV,"198.33.33.100",NXP_ACDSP_BIND_PORT_RX,0},
      "198.33.31.100",
  },
  }
};

static T_DataCfgGroup s_tUdpPathSocketCfg[] =
{
    {(VOID*)&s_tLocalUdpPathSocketCfg, 1, sizeof(T_UdpPathSocketCfgInfo)},
};

static T_BspLogInitInfo s_tBspLogInitPara =
{
    SIZE_8M,
    "p3bsplog"    /* 默认使用bsplog作为文件名时可以置为NULL,否则填文件名，例如"bsplog_m" */
};
/* ==============================================================
    进程核绑定配置信息
 ============================================================== */
static T_CoreProcAffinityInfo s_CoreProcAffinityInfo[] = 
{
    /* 进程名             coreId */
    {"MGR.EXE",         0x3}
};
static T_DataCfgGroup s_tCoreProcAffinityMap[] =
{
     {(VOID*)s_CoreProcAffinityInfo, NELEMENTS(s_CoreProcAffinityInfo), sizeof(T_CoreProcAffinityInfo)},
};

 /**************************************************************************
                       系统软件服务初始化参数定义结束
 **************************************************************************/
static VOID SetSoftServiceData(VOID)
{
    
    BOARD_MODLE_SET_LEVEL1_DATA(E_SOFT_SERVICE_BSP_LOG,0,s_tBspLogInitPara);
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_SOFT_SERVICE_UDPMSGMODULE_INIT,0,s_tUdpPathSocketCfg);
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_SOFT_SERVICE_CORE_AFFINITY_CFG, 0, s_tCoreProcAffinityMap);
}
static __attribute((constructor)) void SoftServiceDataCfg()
{
    BspBoardModleSetDataFunc(E_BOARD_SOFT_SERVICE_COMPO, SetSoftServiceData);
}




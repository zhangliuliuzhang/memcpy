/*****************************************************************************
   数字芯片Tx/Rx/FB 3大链路参数定义
*/
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"

/**************************************************************************
                   数字芯片Tx/Rx/FB 3大链路参数定义开始
**************************************************************************/

/**************************************************************************
                      数字芯片Tx/Rx/FB 3大链路参数定义开始结束
 **************************************************************************/
static VOID SetDigTrxLinkData(VOID)
{
    /*
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_TRX_LINK_DPDIC_OPT_TX_SERDES,0,s_tDpdicOptSerdesAndPcsParaMap);
    BOARD_MODLE_SET_LEVEL2_ARRAY(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,0,s_tDpdicOptCpriParaMap);
    */
}

static __attribute((constructor)) void TrxLinkDataCfg()
{
    BspBoardModleSetDataFunc(E_BOARD_DIG_TRX_LINK_COMPO, SetDigTrxLinkData);
}



#ifndef _BOARDMODLE_H_
#define _BOARDMODLE_H_

#ifdef __cplusplus 
extern "C" { 
#endif

/* 单板临时功能初始化组件包含动作定义 */
enum _E_BOARD_TEMPRARY_ACT_TYPE
{
    E_TEMPRARY_TEST_ACT1 = BOARD_TEMPRARY_ACT_BASE,                 /* 配置TDD FDD是否共存的标志 */
};

#ifdef __cplusplus
}
#endif

#endif /* _BOARDINIT_H_ */



#ifndef _BOARDINIT_H_
#define _BOARDINIT_H_

#ifdef __cplusplus 
extern "C" { 
#endif

/**************************************************************************
 *                        宏
 **************************************************************************/
enum
{
    MF5TAA90Z = 0,
    MF5TAA90Y,
    MF5TAA72Z,
    MF4TAA211,
    MF5TAA90W,
    MG6TAA1821A,
    MF5TAB90W,
    MF5TAB72W,
    MF4TAA901,
    MF5TAB90Z,
    MF5TAB72Z,
    MF5TAB90Y,
    MF5TAB72Y,
    MF5TAB90X,
    MF5TAB72X,
    MF4TAA902,
    MF4TAA903,
    MF4TAA904,
    MF4TAA215,
    MF4TAA216,
    MF4TAA217,
    MF4TAA218,
    MF5TAB18Z,
    MF5TAB18Y,
    MF5TAB21Z,
    MF5TAB21Y,
    MF5TAB21X,
    MF5TAB21W,
    MF5TAB21X_60W,
    MF5TAB21W_60W,
    MF5TAB26Z,
    MF5TAB26Y,
    MF5TAB17Z,
    MF5TAB17Y,
    MF5TAB19Z,
    MF5TAB19Y,
    MF5TAB85Z,
    MF5TAB85Y,
    MF5TAB85X,
    MF5TAB85W,
    MF5TAB85Z_CP5,
    MF5TAB85Y_CP5,
    MF5TAB85X_CP5,
    MF5TAB85W_CP5,
    MGCTAA1821A,
    MGCTAA1821B,
    MG6TAA1821A_AU5518,
    MG6TAA1826A_8A35018D,
    MG6TAA1826A_AU5517,
    MG6TAA1826A_RC32012,
    MF5TAC21Z,
    MF5TAC21Y,
    MF5TAC21X,
    MF5TAC21W,
    AAU_BD_NUM
};

/**************************************************************************
 *                         数据类型
 **************************************************************************/


/**************************************************************************
*                         函数声明
**************************************************************************/

UINT32 BspBoardPreInit(VOID);
UINT32 BspBoardInit(VOID);

#ifdef __cplusplus
}
#endif

#endif /* _BOARDINIT_H_ */


/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : dbgcmd.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供调试命令接口
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "drvregtbl.h"
#include "rruinfo.h"
#include "boardhardid.h"
#include "boardversionload.h"

#define STR_BOARD_VERSION      "R925x_V2.20.00.00B12.20200528"

static UINT32 verbase(VOID)
{
    UINT32 ulModGrpId = 0xff;
    UINT32 ulBrdGrpId = 0xff;
    UINT32 ulBrdTypeId = 0xff;
    UINT32 ulHwChangeId = 0xff;
    UINT32 bomId = BspGetBoardLgcType();
    UINT8  boardName[32] = {0};

    ulModGrpId  = BspGetModuleGroupIdPara();
    ulBrdGrpId  = BspGetBoardGroupIdPara();
    ulBrdTypeId = BspGetBoardTypeIdPara();
    ulHwChangeId = BspGetHardwareChangeIdPara();
    BspGetBoardLgcName(boardName,sizeof(boardName)); 
    RedirPrintf("BOM ID        : %02x %02x %02x %02x(%d:%s)\n",
            ulModGrpId, ulBrdGrpId, ulBrdTypeId, ulHwChangeId, bomId, boardName);

    RedirPrintf("BSP build time: %s %s\n", __DATE__, __TIME__);
#ifdef BSP_MAKE_VER
    RedirPrintf("BOARD VER     : bsp release.%s\n", STR_BOARD_VERSION);
#else
    RedirPrintf("BOARD VER     : cpu release.%s\n", STR_BOARD_VERSION);
#endif
    verbase_dspver(0);
    verbase_acdspver(0, "AC.EXE");

    return BSP_OK;
}

VOID ver(UINT32 flag)
{
    verbase();
    if (flag >= 1)
    {
        RedirPrintf("-------------------------------------------------------------\n");
        verload();
    }
    if (flag >= 2)
    {
        RedirPrintf("-------------------------------------------------------------\n");
        verswv();
    }
}

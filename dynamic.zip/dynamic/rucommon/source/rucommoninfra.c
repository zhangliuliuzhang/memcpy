#include <time.h>
#include <pthread.h>
#include "rucommoninfra.h"


typedef ULONG (*RSP_10MS_DELAY_FUNCPTER)(USHORT ulDelayMs);
static RSP_10MS_DELAY_FUNCPTER  pRsp10MsDelayFunc = NULL;

pthread_mutex_t task_hash_list_lock = PTHREAD_MUTEX_INITIALIZER;

static WIND_TCB * hash_table[MAX_HASH_TABLE_LEN] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,
                                                    NULL,NULL,NULL};


__attribute__((visibility("hidden"))) int BspSystem(const CHAR *pcCommand)
{
    return system(pcCommand);
}

static WIND_TCB * tcb_get_hash_table(pthread_t pthrid)
{
   
    int        hash_Key = GET_HASH_KEY((unsigned int)pthrid);
    WIND_TCB * temp_t   = NULL;
    int ret = 0;
    ret = pthread_mutex_lock(&task_hash_list_lock);
    if (ret != 0)
    {
        dbgErr("%s %d: pthread_mutex_lock error, ret:%d\n", __FUNCTION__, __LINE__, ret);
    }
    temp_t = hash_table[hash_Key];

    while (NULL != temp_t) {    
        if (pthread_equal(temp_t->pthrid,pthrid)) {
            pthread_mutex_unlock(&task_hash_list_lock);
            return temp_t;
        }
        
        temp_t = temp_t->nxt_task_hash;
    }

    pthread_mutex_unlock(&task_hash_list_lock);
     return NULL;
}

static WIND_TCB *my_task(void)
{
    pthread_t my_pthrid;
    my_pthrid = pthread_self();

    return tcb_get_hash_table(my_pthrid);
}

static STATUS taskDelay_Sys(int interval)
{
    struct timespec req ,rem;
    int ret=0;
    unsigned long sec,usec;
    unsigned long long temp = 0;
    TRACE_DLL_F("%i",interval);
    WIND_TCB *task = my_task();
    if ( task ) task->state |= DELAY;

    sec = 0;
    temp = (unsigned long long)((unsigned long long)interval * V2PT_TICK * 1000);
    
    if (temp >= 1000000) 
    {
        sec = (unsigned long)(temp/ 1000000);
        usec = (unsigned long)(temp % 1000000);
    }
    else
    {
        usec = (unsigned long)temp;
    }
    
    if (temp >= 0xffffffff)
    {
        dbgErr("sleep overflow! taskDelay interval = %d\n",interval);
        return -1;   
    }
    
    req.tv_sec = sec;
    req.tv_nsec = usec * 1000;

    ret=nanosleep(&req,&rem);
    if (ret == -1) 
    {
        dbgErr("%d %s\n", errno,strerror(errno));
    }

    while(ret == -1 && (errno == EINTR)){
        req.tv_sec=rem.tv_sec;
        req.tv_nsec=rem.tv_nsec;
        ret=nanosleep(&req,&rem);
    }
    if ( task ) task->state &= ~ DELAY;

    return (OK);
}

static int bspDelay(int iTicks)
{
    UINT32 ulTotalDelayMs=0; /* rsp传入的延时函数的入参单位为ms,所以ticks需要转换为ms */
    int iReturnVal = 0;
    
    /* 该函数判断pRsp10MsDelayFunc是否为NULL。 */
    /* 如果为NULL,则使用taskDelay完成延时操作。 */
    if (NULL == pRsp10MsDelayFunc)
    {
        iReturnVal = taskDelay_Sys(iTicks);
    }
    /* 如果为非NULL，则直接使用pRsp10MsDelayFunc完成延时操作 */
    else
    {
        ulTotalDelayMs = iTicks*1000/100;
        /* rsp传入的延时函数的入参范围为 0-0xffffms之间，
          如果需要延时的时长超出这个范围，
          需要多次调用pRsp10MsDelayFunc完成延时 */
        while(ulTotalDelayMs>RSP_MAX_DELALY_MS)
        {
            iReturnVal |= (*pRsp10MsDelayFunc)(RSP_MAX_DELALY_MS);
            ulTotalDelayMs = ulTotalDelayMs - RSP_MAX_DELALY_MS;
        }
        iReturnVal |= (*pRsp10MsDelayFunc)(ulTotalDelayMs);
    }
    if (0==iReturnVal)
        return OK;
    else
        return ERROR;
}

__attribute__((visibility("hidden"))) int taskDelay(int interval)
{
    return bspDelay(interval);
}
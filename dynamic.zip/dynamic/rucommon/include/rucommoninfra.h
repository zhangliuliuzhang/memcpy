#ifndef _RUCOMMON_INFRA_H_INCLUDE_
#define _RUCOMMON_INFRA_H_INCLUDE_
#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"

#define dbgErr zte_printf_s
#define dbgInfoEx zte_printf_s
#define dbgInfo zte_printf_s

#define V2PT_TICK 10
#define DELAY           0x0002
#define    MAX_HASH_TABLE_LEN 43
#define    GET_HASH_KEY(tid) ((tid) % MAX_HASH_TABLE_LEN)
#define RSP_MAX_DELALY_MS (0XFFFF)

#define TRACE_DLL_V(F,V)
#define TRACE_DLL_F(args ... )


typedef struct task_s
{
    int check;
    int taskid;
    char *name;
    pthread_t pthrid;
    pthread_attr_t attr;
    struct sched_param prv_priority;
    int (*entry_point) (int, int, int, int, int, int, int, int, int, int);
    int parms[10];
    int static_task;    /* Flag indicating if task control block allocated dynamically ( == 0 )*/
    int flags;
    int state;
    int vxw_priority;
    /* struct task_s *suspend_list; use waiting instead*/
    struct task_s *nxt_susp;    /* Next task control block in list of tasks waiting on object*/
    int delete_safe_count;        /* Nesting level for number of taskSafe calls*/
    /* Mutex and Condition variable for task delete 'pend'*/
    pthread_mutex_t tdelete_lock;
    pthread_cond_t t_deletable;

    /* Mutex and Condition variable for task delete 'broadcast'*/
    pthread_mutex_t dbcst_lock;
    pthread_cond_t delete_bcplt;

    /* Mutex and Condition variable for task suspend and resume'*/
    pthread_mutex_t  tsuspend_lock;
    pthread_cond_t  tsuspendable;

    /* First task control block in list of tasks waiting on this task (for deletion purposes)*/
    struct task_s *first_susp;

    /* Next task control block in list*/
    struct task_s *nxt_task;
    struct task_s *nxt_task_hash;
    /* the task waits this objects:*/
    #if 0
    #ifdef _USE_SEM_FUTEX_
    struct v2pt_sema4 *waiting;
    #else
    struct v2lsem *waiting;
    #endif
    #endif
    struct v2lsem *waiting;
    pthread_mutex_t *waiting_m;
    /*task var*/
    //struct taskVar *    pTaskVar;    /* 0x9c: ptr to task variable list */

    UINT16        swapInMask;    /* 0x58: task's switch in hooks */
    UINT16        swapOutMask;    /* 0x5a: task's switch out hooks */
    #if 0
    #ifdef _USE_SEM_FUTEX_
    struct v2pt_sema4 * pend_sem;   /* 任务阻塞在某个信号量上   */
    #endif
    #endif
    int lock_num;                   /* taskLock的调用次数       */
    int oldpriority;                /* 调用taskLock之前的优先级 */

    /*/增加这几个成员是为了一些需要访问vxworks TCB控制块的应用代码能够编过*/
    int            reserved1;    /* 0x100: possible user extension */
    int            reserved2;    /* 0x104: possible user extension */
    int            spare1;        /* 0x108: possible user extension */
    int            spare2;        /* 0x10c: possible user extension */
    int            spare3;        /* 0x110: possible user extension */
    int            spare4;        /* 0x114: possible user extension */
    unsigned int        status;        /* 0x3c: status of task */
    //REG_SET    regs;        /* 0x11c: register set */
    //REG_SET *  pExcRegSet;    /* 0xd8: exception regSet ptr or NULL */
    int           options;    /* 0x38: task option bits */
    unsigned int        priority;    /* 0x40: task's current priority */
    unsigned int        priNormal;    /* 0x44: task's normal priority */

    char *        pStackBase;    /* 0x78: points to bottom of stack */
    char *        pStackLimit;    /* 0x7c: points to stack limit */
    char *        pStackEnd;    /* 0x80: points to init stack limit */

    char * file_name;
    int  line_no;
} WIND_TCB;


#ifdef __cplusplus
}
#endif

#endif
#include "sfp_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "sfp.h"

static UINT32 g_sSfpRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetSfpInfoAdapt(UINT32 cmd, UCHAR ucOptId, T_RruSfpInfo *ptDiagCfg)
{
    return BspGetSfpInfo(ucOptId, ptDiagCfg);
}

static UINT32 BspGetQsfpInfoAdapt(UINT32 cmd, UCHAR ucOptId, T_RruQsfpInfo *ptDiagCfg)
{
    return BspGetQsfpInfo(ucOptId, ptDiagCfg);
}

static UINT32 BspGetSfpSosStaAdapt(UINT32 cmd, UCHAR ucOptId, T_OptSosInfo *ptStatus)
{
    return BspGetSfpSosSta(ucOptId, ptStatus);
}

static UINT32 BspGetOptRxPowerAlarmAdapt(UINT32 cmd, UINT32 ulOptId)
{
    return BspGetOptRxPowerAlarm(ulOptId);
}

static UINT32 BspGetOptTxPowerAlarmAdapt(UINT32 cmd, UINT32 ulOptId)
{
    return BspGetOptTxPowerAlarm(ulOptId);
}

static UINT32 BspGetSfpMaximalUsedbleSpeedAdapt(UINT32 cmd, UINT32 ulOptId)
{
    return BspGetSfpMaximalUsedbleSpeed(ulOptId);
}

static UINT32 BspGetSfpProtocolAdapt(UINT32 cmd, UINT32 optId)
{
    return BspGetSfpProtocol(optId);
}

static UINT32 BspGetOptSignalRateAlarmAdapt(UINT32 cmd, UINT32 ulOptId)
{
    return BspGetOptSignalRateAlarm(ulOptId);
}

static UINT32 BspGetSfpDigiDiagInfoAdapt(UINT32 cmd, UINT32 ulOptId, T_SfpDigiDiagInfo *ptDiagInfo)
{
    return BspGetSfpDigiDiagInfo(ulOptId, ptDiagInfo);
}

/* void->UINT32 */
static UINT32 BspPrintSfpInfoAdapt(UINT32 cmd, UCHAR ucOptId)
{
    BspPrintSfpInfo(ucOptId);
    return BSP_OK;
}

static UINT32 BspGetSfpZteIdentityAdapt(UINT32 cmd, UINT32 ucOptId, UINT32 *pStatus)
{
    return BspGetSfpZteIdentity(ucOptId, pStatus);
}

static UINT32 BspGetSfpCdrStatusAdapt(UINT32 cmd, UINT32 optId, UINT8 *pStatus)
{
    return BspGetSfpCdrStatus(optId, pStatus);
}

static UINT32 BspGetSfpInitStatusAdapt(UINT32 cmd, UINT32 ulIndex)
{
    return BspGetSfpInitStatus(ulIndex);
}

__attribute((constructor)) void _sfp_adapt_init_()
{
    if (NOTREGIST == g_sSfpRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_SFP_INFO, BspGetSfpInfoAdapt);
        BspRegistService(BSP_CMD_GET_QSFP_INFO, BspGetQsfpInfoAdapt);
        BspRegistService(BSP_CMD_GET_SFP_SOS_STA, BspGetSfpSosStaAdapt);
        BspRegistService(BSP_CMD_GET_OPT_RX_POWER_ALARM, BspGetOptRxPowerAlarmAdapt);
        BspRegistService(BSP_CMD_GET_OPT_TX_POWER_ALARM, BspGetOptTxPowerAlarmAdapt);
        BspRegistService(BSP_CMD_GET_SFP_MAXIMAL_USEDBLE_SPEED, BspGetSfpMaximalUsedbleSpeedAdapt);
        BspRegistService(BSP_CMD_GET_SFP_PROTOCOL, BspGetSfpProtocolAdapt);
        BspRegistService(BSP_CMD_GET_OPT_SIGNAL_RATE_ALARM, BspGetOptSignalRateAlarmAdapt);
        BspRegistService(BSP_CMD_GET_SFP_DIGI_DIAG_INFO, BspGetSfpDigiDiagInfoAdapt);
        BspRegistService(BSP_CMD_PRINT_SFP_INFO, BspPrintSfpInfoAdapt);
        BspRegistService(BSP_CMD_GET_SFP_ZTE_IDENTITY, BspGetSfpZteIdentityAdapt);
        BspRegistService(BSP_CMD_GET_SFP_CDR_STATUS, BspGetSfpCdrStatusAdapt);
        BspRegistService(BSP_CMD_GET_SFP_INIT_STATUS, BspGetSfpInitStatusAdapt);

        g_sSfpRegistFlag = ISREGIST;
    }
}

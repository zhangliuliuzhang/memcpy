#include "uartdrv_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "uartmon485.h"

static UINT32 g_sUartdrvRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspMonUartRecvAdapt(UINT32 cmd, UINT8 *buf, UINT32 len)
{
    return BspMonUartRecv(buf, len);
}

static UINT32 BspGetMonRxStatusAdapt(UINT32 cmd)
{
    return BspGetMonRxStatus();
}

static UINT32 BspMonUartIoctlAdapt(UINT32 cmd, UINT32 command, UINT32 para)
{
    return BspMonUartIoctl(command, para);
}

static UINT32 BspMonUartSendAdapt(UINT32 cmd, UINT8 *buf, UINT32 len)
{
    return BspMonUartSend(buf, len);
}

__attribute((constructor)) void _uartdrv_adapt_init_()
{
    if (NOTREGIST == g_sUartdrvRegistFlag)
    {
        BspRegistService(BSP_CMD_MON_UART_RECV, BspMonUartRecvAdapt);
        BspRegistService(BSP_CMD_GET_MON_RX_STATUS, BspGetMonRxStatusAdapt);
        BspRegistService(BSP_CMD_MON_UART_IOCTL, BspMonUartIoctlAdapt);
        BspRegistService(BSP_CMD_MON_UART_SEND, BspMonUartSendAdapt);

        g_sUartdrvRegistFlag = ISREGIST;
    }
}

#ifdef DYNAMIC_API_TEST
/* 这个文件原则上不对高层提供接口，这里全是调试使用 */
#include "mts_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "mts_common.h"

static UINT32 g_sMtsRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static INT32 mcucallAdapt(UINT32 cmd, int chip,const char * fun,INT32 *pRet)
{
    return mcucall(chip, fun, pRet);
}

__attribute((constructor)) void _mts_adapt_init_()
{
    if (NOTREGIST == g_sMtsRegistFlag)
    {
        BspRegistService(BSP_CMD_MCUCALL, mcucallAdapt);

        g_sMtsRegistFlag = ISREGIST;
    }
}
#endif
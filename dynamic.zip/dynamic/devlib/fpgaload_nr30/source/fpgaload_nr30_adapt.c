#include "fpgaload_nr30_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "fpgaloadprocess.h"

static UINT32 g_sFpgaload_nr30RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetWriteXmlToProtectEnableAdapt(UINT32 cmd)
{
    return BspGetWriteXmlToProtectEnable();
}

static UINT32 BspGetDspSoftVersionAdapt(UINT32 cmd, CHAR *pcDspSoftVer, UCHAR ucSizeofBytes)
{
    return BspGetDspSoftVersion(pcDspSoftVer, ucSizeofBytes);
}

static UINT32 BspGetModuleVerErrReasonAdapt(UINT32 cmd, UINT32 ulSoftType, T_CtrlVerErrReason *ptModuleErrReason)
{
    return BspGetModuleVerErrReason(ulSoftType, ptModuleErrReason);
}

static UINT32 FlushRuSwToProtectAdapt(UINT32 cmd)
{
    return FlushRuSwToProtect();
}

static UINT32 BspGetVerProtectTypeAdapt(UINT32 cmd)
{
    return BspGetVerProtectType();
}

static UINT32 BspGetVerProtectAddrAdapt(UINT32 cmd)
{
    return BspGetVerProtectAddr();
}

static UINT32 BspGetCpuVerErrReasonAdapt(UINT32 cmd, T_CpuErrReason *ptCpuErrReason)
{
    return BspGetCpuVerErrReason(ptCpuErrReason);
}

static UINT32 BspGetPackVerDataAdapt(UINT32 cmd, char *pcFileName, UINT32 ulVerOffset, T_VerFileHeader *ptVerHeader, BYTE *pbyImgBuf)
{
    return BspGetPackVerData(pcFileName, ulVerOffset, ptVerHeader, pbyImgBuf);
}

static UINT32 BspGetFpgaLoadStatusAdapt(UINT32 cmd, UINT32 ulIndex)
{
    return BspGetFpgaLoadStatus(ulIndex);
}

/* BOOLEAN->UINT32 */
static UINT32 BspShowProtectFpgaVerAdapt(UINT32 cmd)
{
    return BspShowProtectFpgaVer();
}

/* BOOLEAN->UINT32 */
static UINT32 BspShowProtectCpuVerAdapt(UINT32 cmd)
{
    return BspShowProtectCpuVer();
}

static UINT32 BspFlushProtectToFileSystemAdapt(UINT32 cmd)
{
    return BspFlushProtectToFileSystem();
}

static UINT32 BspGetFlushSysVerToProFlagAdapt(UINT32 cmd, INT32 *uJudgeFlag)
{
    return BspGetFlushSysVerToProFlag(uJudgeFlag);
}

static UINT32 BspGetCpuSoftVersionAdapt(UINT32 cmd, CHAR *pcCpuSoftVer, UCHAR ucSizeofBytes)
{
    return BspGetCpuSoftVersion(pcCpuSoftVer, ucSizeofBytes);
}

static UINT32 BspGetFpgaVerErrReasonAdapt(UINT32 cmd, T_CtrlVerErrReason *ptFpgaErrReason)
{
    return BspGetFpgaVerErrReason(ptFpgaErrReason);
}

static UINT32 BspGetVerProtectLenAdapt(UINT32 cmd)
{
    return BspGetVerProtectLen();
}

static UINT32 BspGetPackVerInfoAdapt(UINT32 cmd, char *pcFileName, UINT32 ulVerIndex, UINT32 *pulVerOffset, T_VerFileHeader *ptVerHeader)
{
    return BspGetPackVerInfo(pcFileName, ulVerIndex, pulVerOffset, ptVerHeader);
}

static UINT32 BspGetFpgaSoftVersionAdapt(UINT32 cmd, CHAR *pcFpgaVer, UCHAR ucSizeofBytes)
{
    return BspGetFpgaSoftVersion(pcFpgaVer, ucSizeofBytes);
}

static UINT32 BspIsSupportFlashProtectAdapt(UINT32 cmd)
{
    return BspIsSupportFlashProtect();
}

static UINT32 BspGetModuleSoftInfoAdapt(UINT32 cmd, UINT32 ulSoftType, T_VER_INFO* ptVerInfo)
{
    return BspGetModuleSoftInfo(ulSoftType, ptVerInfo);
}

static UINT32 BspSetBootStartStepAdapt(UINT32 cmd, UINT32 ulMode)
{
    return BspSetBootStartStep(ulMode);
}

__attribute((constructor)) void _fpgaload_nr30_adapt_init_()
{
    if (NOTREGIST == g_sFpgaload_nr30RegistFlag)
    {
        BspRegistService(BSP_CMD_GET_WRITE_XML_TO_PROTECT_ENABLE, BspGetWriteXmlToProtectEnableAdapt);
        BspRegistService(BSP_CMD_GET_DSP_SOFT_VERSION, BspGetDspSoftVersionAdapt);
        BspRegistService(BSP_CMD_GET_MODULE_VER_ERR_REASON, BspGetModuleVerErrReasonAdapt);
        BspRegistService(BSP_CMD_FLUSH_RU_SW_TO_PROTECT, FlushRuSwToProtectAdapt);
        BspRegistService(BSP_CMD_GET_VER_PROTECT_TYPE, BspGetVerProtectTypeAdapt);
        BspRegistService(BSP_CMD_GET_VER_PROTECT_ADDR, BspGetVerProtectAddrAdapt);
        BspRegistService(BSP_CMD_GET_CPU_VER_ERR_REASON, BspGetCpuVerErrReasonAdapt);
        BspRegistService(BSP_CMD_GET_PACK_VER_DATA, BspGetPackVerDataAdapt);
        BspRegistService(BSP_CMD_GET_FPGA_LOAD_STATUS, BspGetFpgaLoadStatusAdapt);
        BspRegistService(BSP_CMD_SHOW_PROTECT_FPGA_VER, BspShowProtectFpgaVerAdapt);
        BspRegistService(BSP_CMD_SHOW_PROTECT_CPU_VER, BspShowProtectCpuVerAdapt);
        BspRegistService(BSP_CMD_FLUSH_PROTECT_TO_FILE_SYSTEM, BspFlushProtectToFileSystemAdapt);
        BspRegistService(BSP_CMD_GET_FLUSH_SYS_VER_TO_PRO_FLAG, BspGetFlushSysVerToProFlagAdapt);
        BspRegistService(BSP_CMD_GET_CPU_SOFT_VERSION, BspGetCpuSoftVersionAdapt);
        BspRegistService(BSP_CMD_GET_FPGA_VER_ERR_REASON, BspGetFpgaVerErrReasonAdapt);
        BspRegistService(BSP_CMD_GET_VER_PROTECT_LEN, BspGetVerProtectLenAdapt);
        BspRegistService(BSP_CMD_GET_PACK_VER_INFO, BspGetPackVerInfoAdapt);
        BspRegistService(BSP_CMD_GET_FPGA_SOFT_VERSION, BspGetFpgaSoftVersionAdapt);
        BspRegistService(BSP_CMD_IS_SUPPORT_FLASH_PROTECT, BspIsSupportFlashProtectAdapt);
        BspRegistService(BSP_CMD_GET_MODULE_SOFT_INFO, BspGetModuleSoftInfoAdapt);
        BspRegistService(BSP_CMD_SET_BOOT_START_STEP, BspSetBootStartStepAdapt);

        g_sFpgaload_nr30RegistFlag = ISREGIST;
    }
}

#include "armdboot_new_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "dualbootapi.h"

static UINT32 g_sArmdboot_newRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetBootVersionAdapt(UINT32 cmd, CHAR *pcBootVer, UCHAR ucSizeofBytes)
{
    return BspGetBootVersion(pcBootVer, ucSizeofBytes);
}

static UINT32 BspBootLoadAdapt(UINT32 cmd, UCHAR *pucLogicDataBuf, UINT32 ulBufLen)
{
    return BspBootLoad(pucLogicDataBuf, ulBufLen);
}

__attribute((constructor)) void _armdboot_new_adapt_init_()
{
    if (NOTREGIST == g_sArmdboot_newRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_BOOT_VERSION, BspGetBootVersionAdapt);
        BspRegistService(BSP_CMD_BOOT_LOAD, BspBootLoadAdapt);

        g_sArmdboot_newRegistFlag = ISREGIST;
    }
}

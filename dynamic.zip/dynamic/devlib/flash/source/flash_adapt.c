#include "flash_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "flash.h"

static UINT32 g_sFlashRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetFlashEraseSectorSizeAdapt(UINT32 cmd)
{
    return BspGetFlashEraseSectorSize();
}

static UINT32 BspFlashReadAdapt(UINT32 cmd, UINT32 ulOffset, UCHAR *pucBuff, UINT32 ulLen)
{
    return BspFlashRead(ulOffset, pucBuff, ulLen);
}

__attribute((constructor)) void _flash_adapt_init_()
{
    if (NOTREGIST == g_sFlashRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_FLASH_ERASE_SECTOR_SIZE, BspGetFlashEraseSectorSizeAdapt);
        BspRegistService(BSP_CMD_FLASH_READ, BspFlashReadAdapt);

        g_sFlashRegistFlag = ISREGIST;
    }
}

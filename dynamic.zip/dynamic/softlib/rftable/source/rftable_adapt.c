#include "rftable_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "rftable.h"

static UINT32 g_sRftableRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetCaliFileLoadStringAdapt(UINT32 cmd, UINT32 *pulAlarmed, INT8 *pucCaliFileString)
{
    return BspGetCaliFileLoadString(pulAlarmed, pucCaliFileString);
}

__attribute((constructor)) void _rftable_adapt_init_()
{
    if (NOTREGIST == g_sRftableRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_CALI_FILE_LOAD_STRING, BspGetCaliFileLoadStringAdapt);

        g_sRftableRegistFlag = ISREGIST;
    }
}

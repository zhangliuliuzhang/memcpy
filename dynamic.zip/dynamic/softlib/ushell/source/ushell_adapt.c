#ifdef DYNAMIC_API_TEST
/* 这个文件原则上不对高层提供接口，这里全是调试使用 */
#include "ushell_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "ushellapi.h"

static UINT32 g_sUshellRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static int ushell_initAdapt(UINT32 cmd)
{
    return ushell_init();
}

__attribute((constructor)) void _ushell_adapt_init_()
{
    if (NOTREGIST == g_sUshellRegistFlag)
    {
        BspRegistService(BSP_CMD_USHELL_INIT, ushell_initAdapt);

        g_sUshellRegistFlag = ISREGIST;
    }
}
#endif
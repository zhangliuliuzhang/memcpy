#include "systemcall_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"

static UINT32 g_sSystemcallRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspNetDeviceCloseAdapt(UINT32 cmd, const char *eth)
{
    return BspNetDeviceClose(eth);
}

static UINT32 BspNetDeviceOpenAdapt(UINT32 cmd, const char *eth)
{
    return BspNetDeviceOpen(eth);
}

__attribute((constructor)) void _systemcall_adapt_init_()
{
    if (NOTREGIST == g_sSystemcallRegistFlag)
    {
        BspRegistService(BSP_CMD_NET_DEVICE_CLOSE, BspNetDeviceCloseAdapt);
        BspRegistService(BSP_CMD_NET_DEVICE_OPEN, BspNetDeviceOpenAdapt);

        g_sSystemcallRegistFlag = ISREGIST;
    }
}

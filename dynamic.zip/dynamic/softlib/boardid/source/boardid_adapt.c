#include "boardid_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"

static UINT32 g_sBoardidRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspThresholdNameToIdAdapt(UINT32 cmd, UCHAR *pucThresholdName)
{
    return BspThresholdNameToId(pucThresholdName);
}

static UINT32 BspDevNameToIdAdapt(UINT32 cmd, const UCHAR *pucDevName)
{
    return BspDevNameToId(pucDevName);
}

__attribute((constructor)) void _boardid_adapt_init_()
{
    if (NOTREGIST == g_sBoardidRegistFlag)
    {
        BspRegistService(BSP_CMD_THRESHOLD_NAME_TO_ID, BspThresholdNameToIdAdapt);
        BspRegistService(BSP_CMD_DEV_NAME_TO_ID, BspDevNameToIdAdapt);

        g_sBoardidRegistFlag = ISREGIST;
    }
}

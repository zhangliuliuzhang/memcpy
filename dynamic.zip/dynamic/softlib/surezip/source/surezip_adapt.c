#include "surezip_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "lzmaapi.h"

static UINT32 g_sSurezipRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

/* int->UINT32 返回值全正数，不会有问题*/
static int LzmaGetHeaderInfoAdapt(UINT32 cmd, unsigned char *srcbuf, unsigned long BufLength,T_lzma_header *ptLocalHeader)
{
    return LzmaGetHeaderInfo(srcbuf, BufLength, ptLocalHeader);
}

__attribute((constructor)) void _surezip_adapt_init_()
{
    if (NOTREGIST == g_sSurezipRegistFlag)
    {
        BspRegistService(BSP_CMD_LZMA_GET_HEADER_INFO, LzmaGetHeaderInfoAdapt);

        g_sSurezipRegistFlag = ISREGIST;
    }
}

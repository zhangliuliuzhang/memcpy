#include "rruinfo_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "rruinfo.h"

static UINT32 g_sRruinfoRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetRruPathDeratingPowerAdapt(UINT32 cmd, UINT32 ulTxChan, UINT32 *pValue)
{
    return BspGetRruPathDeratingPower(ulTxChan, pValue);
}

static UINT32 BspAdpGetRruPibNumAdapt(UINT32 cmd, UINT32 *pValue)
{
    return BspAdpGetRruPibNum(pValue);
}

static UINT32 BspGetHardwareChangeIdAdapt(UINT32 cmd)
{
    return BspGetHardwareChangeId();
}

static UINT32 BspGetPlusAndPlayVerRestrictAdapt(UINT32 cmd, char *verRestrict, UINT32 bufLen)
{
    return BspGetPlusAndPlayVerRestrict(verRestrict, bufLen);
}

static UINT32 BspAdpGetRruPaNumAdapt(UINT32 cmd,  UINT32 *pValue)
{
    return BspAdpGetRruPaNum(pValue);
}

static UINT32 BspGetRruInfoAdapt(UINT32 cmd, UINT32 ulType, UINT32 index, T_BspDevInfo *ptDevInfo)
{
    return BspGetRruInfo(ulType, index, ptDevInfo);
}

static UINT32 BspGetModuleNumInfoAdapt(UINT32 cmd, T_ModuleNumInfo *ptModuleNumInfo)
{
    return BspGetModuleNumInfo(ptModuleNumInfo);
}

static UINT32 BspGetModuleBarCodeInfoAdapt(UINT32 cmd, UINT32 ulUnitIndex, UINT32 ulUnitType, CHAR *pBarInfo, UINT32 ulBarLen)
{
    return BspGetModuleBarCodeInfo(ulUnitIndex, ulUnitType, pBarInfo, ulBarLen);
}

static UINT32 BspGetRruBoardTypeAdapt(UINT32 cmd)
{
    return BspGetRruBoardType();
}

static UINT32 BspGetPwrTypeAdapt(UINT32 cmd, UINT32 pwrNo)
{
    return BspGetPwrType(pwrNo);
}

static UINT32 BspGetRfPllNumAdapt(UINT32 cmd, T_BSP_RfPllNum *ptRfPllNum)
{
    return BspGetRfPllNum(ptRfPllNum);
}

static UINT32 BspGetModuleGroupIdAdapt(UINT32 cmd)
{
    return BspGetModuleGroupId();
}

static UINT32 BspGetRruInventoryAdapt(UINT32 cmd, T_BspInventoryInfo *ptDevInfo)
{
    return BspGetRruInventory(ptDevInfo);
}

static UINT32 BspGetFpgaVerSoftTypeAdapt(UINT32 cmd)
{
    return BspGetFpgaVerSoftType();
}

static UINT32 BspGetRxChanNumAdapt(UINT32 cmd)
{
    return BspGetRxChanNum();
}

static UINT32 BspGetTxChanNumAdapt(UINT32 cmd)
{
    return BspGetTxChanNum();
}

static UINT32 BspGetRruTypeAdapt(UINT32 cmd)
{
    return BspGetRruType();
}

static UINT32 BspSetPlusAndPlaySwidAdapt(UINT32 cmd, UINT32 swId)
{
    return BspSetPlusAndPlaySwid(swId);
}

static UINT32 BspGetBandValByCenterFreqAdapt(UINT32 cmd, UINT32 bspchn, UINT32 dir, UINT32 Freq, UINT32 *freqBandType)
{
    return BspGetBandValByCenterFreq(bspchn, dir, Freq, freqBandType);
}

static UINT32 BspGetFpgaVerComparFlagAdapt(UINT32 cmd)
{
    return BspGetFpgaVerComparFlag();
}

static UINT32 BspSetExtraFilterCfgAdapt(UINT32 cmd, UINT32 ulChannel, UINT32 ulBand, UINT32 ulDir, UINT32 ulStartFreqKHz, UINT32 ulEndFreqKHz)
{
    return BspSetExtraFilterCfg(ulChannel, ulBand, ulDir, ulStartFreqKHz, ulEndFreqKHz);
}

static UINT32 BspGetAntNumAdapt(UINT32 cmd)
{
    return BspGetAntNum();
}

static UINT32 BspGetAauBarCodeIdAdapt(UINT32 cmd, UINT8* pCode)
{
    return BspGetAauBarCodeId(pCode);
}

static UINT32 BspGetOptNumAdapt(UINT32 cmd)
{
    return BspGetOptNum();
}

static UINT32 BspGetRruTypeInfoAdapt(UINT32 cmd, UINT32 len, UINT8 *rruTypeStr)
{
    return BspGetRruTypeInfo(len, rruTypeStr);
}

static UINT32 BspGetVersionLoadTypeAdapt(UINT32 cmd)
{
    return BspGetVersionLoadType();
}

static UINT32 BspGetRpuNumAdapt(UINT32 cmd)
{
    return BspGetRpuNum();
}

static UINT32 BspGetRruRfModuleInfoNewAdapt(UINT32 cmd, UINT32 ulChannel, T_RruRfModuleInfoNew *ptRfModuleInfo)
{
    return BspGetRruRfModuleInfoNew(ulChannel, ptRfModuleInfo);
}

static UINT32 BspGetBoardLgcTypeAdapt(UINT32 cmd)
{
    return BspGetBoardLgcType();
}

static UINT32 BspGetPlusAndPlayEnableAdapt(UINT32 cmd)
{
    return BspGetPlusAndPlayEnable();
}

static UINT32 BspGetFreqBandNumAdapt(UINT32 cmd, UINT32 uChan, UINT32 uDir, UINT32 freq)
{
    return BspGetFreqBandNum(uChan, uDir, freq);
}

static UINT32 BspGetBandFreqRangeByCenterFreqAdapt(UINT32 cmd, UINT32 dir, UINT32 freqBandType, UINT32 *startFreq, UINT32 *endFreq)
{
    return BspGetBandFreqRangeByCenterFreq(dir, freqBandType, startFreq, endFreq);
}

static UINT32 BspIsSupportDeratingPowAdapt(UINT32 cmd)
{
    return BspIsSupportDeratingPow();
}

static UINT32 BspGetRruPathRatedPowerAdapt(UINT32 cmd, UINT32 ulTxChan, UINT32 *pValue )
{
    return BspGetRruPathRatedPower(ulTxChan, pValue);
}

static UINT32 BspGetRruAddInventoryAdapt(UINT32 cmd, T_BspAddInventoryInfo *ptAddAssetInfo)
{
    return BspGetRruAddInventory(ptAddAssetInfo);
}

static UINT32 BspGetRruRfModuleInfoAdapt(UINT32 cmd, UINT32 ulChannel, T_RruRfModuleInfo *ptRfModuleInfo)
{
    return BspGetRruRfModuleInfo(ulChannel, ptRfModuleInfo);
}

static UINT32 BspAdpGetRruPwrNumAdapt(UINT32 cmd, UINT32 *pValue)
{
    return BspAdpGetRruPwrNum(pValue);
}

static UINT32 BspGetAAUPidAdapt(UINT32 cmd, UINT32 *radarModel, UINT8 *pid)
{
    return BspGetAAUPid(radarModel, pid);
}

static UINT32 BspGetDryctNumAdapt(UINT32 cmd)
{
    return BspGetDryctNum();
}

static UINT32 BspGetBoardTypeIdAdapt(UINT32 cmd)
{
    return BspGetBoardTypeId();
}

static UINT32 BspGetPlusAndPlaySwidAdapt(UINT32 cmd, UINT32 *swId)
{
    return BspGetPlusAndPlaySwid(swId);
}

static UINT32 BspAdpGetRruDflNumAdapt(UINT32 cmd, UINT32 *pValue)
{
    return BspAdpGetRruDflNum(pValue);
}

static UINT32 BspSupportantiInterferenceAdapt(UINT32 cmd)
{
    return BspSupportantiInterference();
}

static UINT32 BspGetBoardGroupIdAdapt(UINT32 cmd)
{
    return BspGetBoardGroupId();
}

static UINT32 BspGetRruAntRatedPowerAdapt(UINT32 cmd, UINT32 ulTxAnt, UINT32 *pValue)
{
    return BspGetRruAntRatedPower(ulTxAnt, pValue);
}

static UINT32 BspGetBoardInfo_16Adapt(UINT32 cmd, T_HARDWARE_MODULE_INFO_16 *pBoardInfo)
{
    return BspGetBoardInfo_16(pBoardInfo);
}

static UINT32 BspGetSfpNumAdapt(UINT32 cmd)
{
    return BspGetSfpNum();
}

__attribute((constructor)) void _rruinfo_adapt_init_()
{
    if (NOTREGIST == g_sRruinfoRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_RRU_PATH_DERATING_POWER, BspGetRruPathDeratingPowerAdapt);
        BspRegistService(BSP_CMD_ADP_GET_RRU_PIB_NUM, BspAdpGetRruPibNumAdapt);
        BspRegistService(BSP_CMD_GET_HARDWARE_CHANGE_ID, BspGetHardwareChangeIdAdapt);
        BspRegistService(BSP_CMD_GET_PLUS_AND_PLAY_VER_RESTRICT, BspGetPlusAndPlayVerRestrictAdapt);
        BspRegistService(BSP_CMD_ADP_GET_RRU_PA_NUM, BspAdpGetRruPaNumAdapt);
        BspRegistService(BSP_CMD_GET_RRU_INFO, BspGetRruInfoAdapt);
        BspRegistService(BSP_CMD_GET_MODULE_NUM_INFO, BspGetModuleNumInfoAdapt);
        BspRegistService(BSP_CMD_GET_MODULE_BAR_CODE_INFO, BspGetModuleBarCodeInfoAdapt);
        BspRegistService(BSP_CMD_GET_RRU_BOARD_TYPE, BspGetRruBoardTypeAdapt);
        BspRegistService(BSP_CMD_GET_PWR_TYPE, BspGetPwrTypeAdapt);
        BspRegistService(BSP_CMD_GET_RF_PLL_NUM, BspGetRfPllNumAdapt);
        BspRegistService(BSP_CMD_GET_MODULE_GROUP_ID, BspGetModuleGroupIdAdapt);
        BspRegistService(BSP_CMD_GET_RRU_INVENTORY, BspGetRruInventoryAdapt);
        BspRegistService(BSP_CMD_GET_FPGA_VER_SOFT_TYPE, BspGetFpgaVerSoftTypeAdapt);
        BspRegistService(BSP_CMD_GET_RX_CHAN_NUM, BspGetRxChanNumAdapt);
        BspRegistService(BSP_CMD_GET_TX_CHAN_NUM, BspGetTxChanNumAdapt);
        BspRegistService(BSP_CMD_GET_RRU_TYPE, BspGetRruTypeAdapt);
        BspRegistService(BSP_CMD_SET_PLUS_AND_PLAY_SWID, BspSetPlusAndPlaySwidAdapt);
        BspRegistService(BSP_CMD_GET_BAND_VAL_BY_CENTER_FREQ, BspGetBandValByCenterFreqAdapt);
        BspRegistService(BSP_CMD_GET_FPGA_VER_COMPAR_FLAG, BspGetFpgaVerComparFlagAdapt);
        BspRegistService(BSP_CMD_SET_EXTRA_FILTER_CFG, BspSetExtraFilterCfgAdapt);
        BspRegistService(BSP_CMD_GET_ANT_NUM, BspGetAntNumAdapt);
        BspRegistService(BSP_CMD_GET_AAU_BAR_CODE_ID, BspGetAauBarCodeIdAdapt);
        BspRegistService(BSP_CMD_GET_OPT_NUM, BspGetOptNumAdapt);
        BspRegistService(BSP_CMD_GET_RRU_TYPE_INFO, BspGetRruTypeInfoAdapt);
        BspRegistService(BSP_CMD_GET_VERSION_LOAD_TYPE, BspGetVersionLoadTypeAdapt);
        BspRegistService(BSP_CMD_GET_RPU_NUM, BspGetRpuNumAdapt);
        BspRegistService(BSP_CMD_GET_RRU_RF_MODULE_INFO_NEW, BspGetRruRfModuleInfoNewAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_LGC_TYPE, BspGetBoardLgcTypeAdapt);
        BspRegistService(BSP_CMD_GET_PLUS_AND_PLAY_ENABLE, BspGetPlusAndPlayEnableAdapt);
        BspRegistService(BSP_CMD_GET_FREQ_BAND_NUM, BspGetFreqBandNumAdapt);
        BspRegistService(BSP_CMD_GET_BAND_FREQ_RANGE_BY_CENTER_FREQ, BspGetBandFreqRangeByCenterFreqAdapt);
        BspRegistService(BSP_CMD_IS_SUPPORT_DERATING_POW, BspIsSupportDeratingPowAdapt);
        BspRegistService(BSP_CMD_GET_RRU_PATH_RATED_POWER, BspGetRruPathRatedPowerAdapt);
        BspRegistService(BSP_CMD_GET_RRU_ADD_INVENTORY, BspGetRruAddInventoryAdapt);
        BspRegistService(BSP_CMD_GET_RRU_RF_MODULE_INFO, BspGetRruRfModuleInfoAdapt);
        BspRegistService(BSP_CMD_ADP_GET_RRU_PWR_NUM, BspAdpGetRruPwrNumAdapt);
        BspRegistService(BSP_CMD_GET_AAU_PID, BspGetAAUPidAdapt);
        BspRegistService(BSP_CMD_GET_DRYCT_NUM, BspGetDryctNumAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_TYPE_ID, BspGetBoardTypeIdAdapt);
        BspRegistService(BSP_CMD_GET_PLUS_AND_PLAY_SWID, BspGetPlusAndPlaySwidAdapt);
        BspRegistService(BSP_CMD_ADP_GET_RRU_DFL_NUM, BspAdpGetRruDflNumAdapt);
        BspRegistService(BSP_CMD_SUPPORTANTI_INTERFERENCE, BspSupportantiInterferenceAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_GROUP_ID, BspGetBoardGroupIdAdapt);
        BspRegistService(BSP_CMD_GET_RRU_ANT_RATED_POWER, BspGetRruAntRatedPowerAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_INFO_16, BspGetBoardInfo_16Adapt);
        BspRegistService(BSP_CMD_GET_SFP_NUM, BspGetSfpNumAdapt);

        g_sRruinfoRegistFlag = ISREGIST;
    }
}

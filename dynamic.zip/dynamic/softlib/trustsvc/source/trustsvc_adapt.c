#include "trustsvc_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "sign_verify.h"

static UINT32 g_sTrustsvcRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspCheckSystemVerSignAdapt(UINT32 cmd, UCHAR *pucVerName, UINT32 ulCurTmp)
{
    return BspCheckSystemVerSign(pucVerName, ulCurTmp);
}

__attribute((constructor)) void _trustsvc_adapt_init_()
{
    if (NOTREGIST == g_sTrustsvcRegistFlag)
    {
        BspRegistService(BSP_CMD_CHECK_SYSTEM_VER_SIGN, BspCheckSystemVerSignAdapt);

        g_sTrustsvcRegistFlag = ISREGIST;
    }
}

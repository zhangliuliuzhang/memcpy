#include "vxadapt_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "vxadp.h"
#include "zprintf.h"

static UINT32 g_sVxadaptRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

/* ULONG->UINT32 */
static UINT32 RspDelayFuncInstallAdapt(UINT32 cmd, ULONG (*pDelay10MsFunc)(UINT32 cmd, USHORT ulDelayMs))
{
    return RspDelayFuncInstall(pDelay10MsFunc);
}

/* void->UINT32 */
static UINT32 blockticksigAdapt(UINT32 cmd)
{
    blockticksig();
    return BSP_OK;
}

/* void->UINT32 */
static UINT32 inet_ntoa_bAdapt(UINT32 cmd, in_addr *inetAddress, char *pString)
{
    INPUT_POINTER_CHECK(inetAddress);
    inet_ntoa_b(*inetAddress, pString);
    return BSP_OK;
}

/* INT->UINT32 */
static UINT32 intLockAdapt(UINT32 cmd)
{
    return intLock();
}

/* 返回值指针，大改造 */
static UINT32 taskNameAdapt(UINT32 cmd, int tid, CHAR **pTaskName)
{
    INPUT_POINTER_CHECK(pTaskName);
    *pTaskName = taskName(tid);
    return BSP_OK;
}

/* int->UINT32 */
static UINT32 intDisableAdapt(UINT32 cmd, int irq)
{
    return intDisable(irq);
}

/* int->UINT32 */
static UINT32 taskIdListGetAdapt(UINT32 cmd, int idList[], int maxTasks)
{
    return taskIdListGet(idList, maxTasks);
}

/* 返回结构体指针，改造为出参 */
static UINT32 taskTcbAdapt(UINT32 cmd, int tid, WIND_TCB **pTaskTcb)
{
    INPUT_POINTER_CHECK(pTaskTcb);
    *pTaskTcb = taskTcb(tid);
    return BSP_OK;
}

/* STATUS->UINT32 */
static UINT32 sysAuxClkRateSetAdapt(UINT32 cmd, int ticksPerSecond)
{
    return sysAuxClkRateSet(ticksPerSecond);
}

/* STATUS->UINT32 */
static UINT32 intConnectAdapt(UINT32 cmd, VOIDFUNCPTR *vector, VOIDFUNCPTR routine, int parameter)
{
    return intConnect(vector, routine, parameter);
}

/* STATUS->UINT32 */
static UINT32 sysAuxClkConnectAdapt(UINT32 cmd, FUNCPTR routine, int arg)
{
    return sysAuxClkConnect(routine, arg);
}

/* VOID->UINT32 */
static UINT32 sysAuxClkEnableAdapt(UINT32 cmd)
{
    sysAuxClkEnable();
    return BSP_OK;
}

/* int->UINT32 */
static int taskSpawnAdapt(UINT32 cmd, const char *name, int pri, int opts, int stksize,int (*funcptr) (UINT32 cmd, int, int, int, int, int, int, int, int, int,int), int arg1, int arg2, int arg3, int arg4,int arg5, int arg6, int arg7, int arg8, int arg9, int arg10)
{
    return taskSpawn(name, pri, opts, stksize, funcptr, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
}

/* 返回值ULONG,64位下大概率使用64bit，放到出参 */
static UINT32 tickGetAdapt(UINT32 cmd, ULONG *pTickGet)
{
    INPUT_POINTER_CHECK(pTickGet);
    *pTickGet = tickGet();
    return BSP_OK;
}

/* INT->UINT32 */
static UINT32 intUnlockAdapt(UINT32 cmd, int LockKey)
{
    return intUnlock(LockKey);
}

/* int->UINT32 */
static UINT32 intEnableAdapt(UINT32 cmd, int irq)
{
    return intEnable(irq);
}

/* STATUS->UINT32 */
static UINT32 taskDelayAdapt(UINT32 cmd, int interval)
{
    return taskDelay(interval);
}

/* int->UINT32 */
static UINT32 sysClkRateGetAdapt(UINT32 cmd)
{
    return sysClkRateGet();
}

__attribute((constructor)) void _vxadapt_adapt_init_()
{
    if (NOTREGIST == g_sVxadaptRegistFlag)
    {
        BspRegistService(BSP_CMD_RSP_DELAY_FUNC_INSTALL, RspDelayFuncInstallAdapt);
        BspRegistService(BSP_CMD_BLOCKTICKSIG, blockticksigAdapt);
        BspRegistService(BSP_CMD_INET_NTOA_B, inet_ntoa_bAdapt);
        BspRegistService(BSP_CMD_INT_LOCK, intLockAdapt);
        BspRegistService(BSP_CMD_TASK_NAME, taskNameAdapt);
        BspRegistService(BSP_CMD_INT_DISABLE, intDisableAdapt);
        BspRegistService(BSP_CMD_TASK_ID_LIST_GET, taskIdListGetAdapt);
        BspRegistService(BSP_CMD_TASK_TCB, taskTcbAdapt);
        BspRegistService(BSP_CMD_SYS_AUX_CLK_RATE_SET, sysAuxClkRateSetAdapt);
        BspRegistService(BSP_CMD_INT_CONNECT, intConnectAdapt);
        BspRegistService(BSP_CMD_SYS_AUX_CLK_CONNECT, sysAuxClkConnectAdapt);
        BspRegistService(BSP_CMD_SYS_AUX_CLK_ENABLE, sysAuxClkEnableAdapt);
        BspRegistService(BSP_CMD_TASK_SPAWN, taskSpawnAdapt);
        BspRegistService(BSP_CMD_TICK_GET, tickGetAdapt);
        BspRegistService(BSP_CMD_INT_UNLOCK, intUnlockAdapt);
        BspRegistService(BSP_CMD_INT_ENABLE, intEnableAdapt);
        BspRegistService(BSP_CMD_TASK_DELAY, taskDelayAdapt);
        BspRegistService(BSP_CMD_SYS_CLK_RATE_GET, sysClkRateGetAdapt);

        g_sVxadaptRegistFlag = ISREGIST;
    }
}

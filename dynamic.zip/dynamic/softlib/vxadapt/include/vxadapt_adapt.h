#ifndef _VXADAPT_ADAPT_H_INCLUDE_
#define _VXADAPT_ADAPT_H_INCLUDE_

typedef struct
{
    unsigned long s_addr;
}in_addr;

#endif

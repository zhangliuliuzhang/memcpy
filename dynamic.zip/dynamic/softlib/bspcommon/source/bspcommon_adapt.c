#include <stddef.h>
#include "bspcommon_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bspcommon.h"
#include "bspcomm.h"
#include "bsppub.h"

static UINT32 g_sBspcommonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

/* INT->UINT32 */
static UINT32 BspSystemAdapt(UINT32 cmd, const CHAR *pcCommand)
{
    return BspSystem(pcCommand);
}

static UINT32 BspGetPaVoltAdjustTypeAdapt(UINT32 cmd, UINT32 ulIndex)
{
    return BspGetPaVoltAdjustType(ulIndex);
}

static UINT32 BspInstallSystemCallBackAdapt(UINT32 cmd, BSP_SYSTEM_CALLBACK pfSystem)
{
    return BspInstallSystemCallBack(pfSystem);
}

__attribute((constructor)) void _bspcommon_adapt_init_()
{
    if (NOTREGIST == g_sBspcommonRegistFlag)
    {
        BspRegistService(BSP_CMD_SYSTEM, BspSystemAdapt);
        BspRegistService(BSP_CMD_GET_PA_VOLT_ADJUST_TYPE, BspGetPaVoltAdjustTypeAdapt);
        BspRegistService(BSP_CMD_INSTALL_SYSTEM_CALL_BACK, BspInstallSystemCallBackAdapt);

        g_sBspcommonRegistFlag = ISREGIST;
    }
}

#include "hallib_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "devdrv_clk.h"
#include "devdrv_att.h"

static UINT32 g_sHallibRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetClkPllSysLdAdapt(UINT32 cmd, UINT32 devId)
{
    return BspGetClkPllSysLd(devId);
}

static UINT32 BspGetClkPllSysLd3Adapt(UINT32 cmd, UINT32 devId)
{
    return BspGetClkPllSysLd3(devId);
}

static UINT32 BspGetPrxAttAdapt(UINT32 cmd, UINT32 chn, INT32 *pVal)
{
    return BspGetPrxAtt(chn, pVal);
}

static UINT32 BspGetClkPllSysLd4Adapt(UINT32 cmd, UINT32 devId)
{
    return BspGetClkPllSysLd4(devId);
}

static UINT32 BspGetRxAttAdapt(UINT32 cmd, UINT32 chn, INT32 *pVal)
{
    return BspGetRxAtt(chn, pVal);
}

static UINT32 BspGetClkPllSysLd2Adapt(UINT32 cmd, UINT32 devId)
{
    return BspGetClkPllSysLd2(devId);
}

/* VOID->UINT32 */
static UINT32 attshowAdapt(UINT32 cmd)
{
    attshow();
    return BSP_OK;
}

static int BspLoadModulesAdapt(UINT32 cmd)
{
    return BspLoadModules();
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 tempAdapt(UINT32 cmd, UINT8 *devIdName)
{
    return temp(devIdName);
}
#endif

__attribute((constructor)) void _hallib_adapt_init_()
{
    if (NOTREGIST == g_sHallibRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_CLK_PLL_SYS_LD, BspGetClkPllSysLdAdapt);
        BspRegistService(BSP_CMD_GET_CLK_PLL_SYS_LD3, BspGetClkPllSysLd3Adapt);
        BspRegistService(BSP_CMD_GET_PRX_ATT, BspGetPrxAttAdapt);
        BspRegistService(BSP_CMD_GET_CLK_PLL_SYS_LD4, BspGetClkPllSysLd4Adapt);
        BspRegistService(BSP_CMD_GET_RX_ATT, BspGetRxAttAdapt);
        BspRegistService(BSP_CMD_GET_CLK_PLL_SYS_LD2, BspGetClkPllSysLd2Adapt);
        BspRegistService(BSP_CMD_ATTSHOW, attshowAdapt);
        BspRegistService(BSP_CMD_LOAD_MODULES, BspLoadModulesAdapt);

#ifdef DYNAMIC_API_TEST
        /* 测试接口注册 */
        BspRegistService(BSP_CMD_TEMP, tempAdapt);
#endif

        g_sHallibRegistFlag = ISREGIST;
    }
}

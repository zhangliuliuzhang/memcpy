#include "ledctrl_a_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "ledctrlapi.h"

static UINT32 g_sLedctrl_aRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspRecoverLedCtrlAdapt(UINT32 cmd)
{
    return BspRecoverLedCtrl();
}

static UINT32 BspDisableLedCtrlAdapt(UINT32 cmd)
{
    return BspDisableLedCtrl();
}

static UINT32 BspLedCtrlAdapt(UINT32 cmd, UINT32 ledName, UINT32 operation)
{
    return BspLedCtrl(ledName, operation);
}

__attribute((constructor)) void _ledctrl_a_adapt_init_()
{
    if (NOTREGIST == g_sLedctrl_aRegistFlag)
    {
        BspRegistService(BSP_CMD_RECOVER_LED_CTRL, BspRecoverLedCtrlAdapt);
        BspRegistService(BSP_CMD_DISABLE_LED_CTRL, BspDisableLedCtrlAdapt);
        BspRegistService(BSP_CMD_LED_CTRL, BspLedCtrlAdapt);

        g_sLedctrl_aRegistFlag = ISREGIST;
    }
}

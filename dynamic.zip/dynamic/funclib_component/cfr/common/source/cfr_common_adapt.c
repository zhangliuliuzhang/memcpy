#include "cfr_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "cfrcommon.h"

static UINT32 g_sCfr_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetCfrDisableAdapt(UINT32 cmd, UINT32 bspChn)
{
    return BspSetCfrDisable(bspChn);
}

static UINT32 BspSetCfrEnableAdapt(UINT32 cmd, UINT32 bspChn)
{
    return BspSetCfrEnable(bspChn);
}

static UINT32 BspSetCfrGateByCoefAdapt(UINT32 cmd, UINT32 ulChn, DOUBLE dCfrPara)
{
    return BspSetCfrGateByCoef(ulChn, dCfrPara);
}

static UINT32 BspSetCfrCpgParaAdapt(UINT32 cmd, UINT32 bspChn)
{
    return BspSetCfrCpgPara(bspChn);
}

static UINT32 BspSetCfrCpgDelayAdapt(UINT32 cmd, UINT32 bspChn)
{
    return BspSetCfrCpgDelay(bspChn);
}

__attribute((constructor)) void _cfr_common_adapt_init_()
{
    if (NOTREGIST == g_sCfr_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_SET_CFR_DISABLE, BspSetCfrDisableAdapt);
        BspRegistService(BSP_CMD_SET_CFR_ENABLE, BspSetCfrEnableAdapt);
        BspRegistService(BSP_CMD_SET_CFR_GATE_BY_COEF, BspSetCfrGateByCoefAdapt);
        BspRegistService(BSP_CMD_SET_CFR_CPG_PARA, BspSetCfrCpgParaAdapt);
        BspRegistService(BSP_CMD_SET_CFR_CPG_DELAY, BspSetCfrCpgDelayAdapt);

        g_sCfr_commonRegistFlag = ISREGIST;
    }
}

#include "cfr_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "cfr_ic4_2.h"

static UINT32 g_sCfr_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetNBCarrModeAdapt(UINT32 cmd, UINT32 ulChan, UINT32 ulCarr, UINT32 ulMode)
{
    return BspSetNBCarrMode(ulChan, ulCarr, ulMode);
}

static UINT32 BspSetUmtsCpgCoefAdapt(UINT32 cmd, UINT32 bspChan, UINT32 radioMod, UINT32 bandWidth, UINT32 cfgflag)
{
    return BspSetUmtsCpgCoef(bspChan, radioMod, bandWidth, cfgflag);
}

static UINT32 BspCfrClrHwCpgRamAdapt(UINT32 cmd, UINT32 bspChnChgMask)
{
    return BspCfrClrHwCpgRam(bspChnChgMask);
}

__attribute((constructor)) void _cfr_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sCfr_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_SET_N_B_CARR_MODE, BspSetNBCarrModeAdapt);
        BspRegistService(BSP_CMD_SET_UMTS_CPG_COEF, BspSetUmtsCpgCoefAdapt);
        BspRegistService(BSP_CMD_CFR_CLR_HW_CPG_RAM, BspCfrClrHwCpgRamAdapt);

        g_sCfr_ic4_2RegistFlag = ISREGIST;
    }
}

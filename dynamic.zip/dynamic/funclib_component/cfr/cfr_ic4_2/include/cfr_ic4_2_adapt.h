#ifndef _CFR_IC4_2_ADAPT_H_INCLUDE_
#define _CFR_IC4_2_ADAPT_H_INCLUDE_


#endif

#include "gnss_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "gnssapi.h"

static UINT32 g_sGnss_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGNSSDrvStatusGetAdapt(UINT32 cmd, UINT32 index, UINT32 radioMode, T_GNSS_RECEIVER_STATE *pGNSSRcvStatus)
{
    return BspGNSSDrvStatusGet(index, radioMode, pGNSSRcvStatus);
}

static UINT32 BspGnssAlarmStatusAdapt(UINT32 cmd, UINT32 index, T_GNSS_ALARM_STATUS *ptGnssAlarmStatus)
{
    return BspGnssAlarmStatus(index, ptGnssAlarmStatus);
}

static UINT32 BspRegisterGnssCallbackAdapt(UINT32 cmd, UINT32 index, UINT32 radioMode, FUNC_BUF_CTRL pFunc)
{
    return BspRegisterGnssCallback(index, radioMode, pFunc);
}

static UINT32 BspConfigGnssAdapt(UINT32 cmd, UINT32 radioMode, T_GNSS_PARA_CFG *ptGnssParaCfg)
{
    return BspConfigGnss(radioMode, ptGnssParaCfg);
}

__attribute((constructor)) void _gnss_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sGnss_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_GNSS_DRV_STATUS_GET, BspGNSSDrvStatusGetAdapt);
        BspRegistService(BSP_CMD_GNSS_ALARM_STATUS, BspGnssAlarmStatusAdapt);
        BspRegistService(BSP_CMD_REGISTER_GNSS_CALLBACK, BspRegisterGnssCallbackAdapt);
        BspRegistService(BSP_CMD_CONFIG_GNSS, BspConfigGnssAdapt);

        g_sGnss_ic4_2RegistFlag = ISREGIST;
    }
}

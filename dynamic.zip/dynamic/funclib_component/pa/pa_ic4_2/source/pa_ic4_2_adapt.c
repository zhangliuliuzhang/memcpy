#include "pa_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "paapi.h"
#include "pa_ic4_2_gridvolt.h"

static UINT32 g_sPa_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetPaNormalFlagAdapt(UINT32 cmd, UINT32 chan, UINT32 normalFlag)
{
    return BspSetPaNormalFlag(chan, normalFlag);
}

static UINT32 BspSetPaVibasByChanAdapt(UINT32 cmd, UINT32 index, UINT32 paChan)
{
    return BspSetPaVibasByChan(index, paChan);
}

static UINT32 BspSetPaVibasAdapt(UINT32 cmd, UINT32 index)
{
    return BspSetPaVibas(index);
}

static UINT32 BspSetPaFddSwitchAdapt(UINT32 cmd, UINT32 chan,UINT32 sw)
{
    return BspSetPaFddSwitch(chan, sw);
}

static UINT32 BspGetPaSwitchAdapt(UINT32 cmd, UINT32 chan)
{
    return BspGetPaSwitch(chan);
}

static UINT32 BspSetPaSwitchAdapt(UINT32 cmd, UINT32 chan, UINT32 sw)
{
    return BspSetPaSwitch(chan, sw);
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 showpagridvoltAdapt(UINT32 cmd, UINT32 loopStart,UINT32 loopEnd,UINT32 chanStart,UINT32 chanEnd)
{
    showpagridvolt(loopStart, loopEnd, chanStart, chanEnd);
    return BSP_OK;
}
#endif

__attribute((constructor)) void _pa_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sPa_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_SET_PA_NORMAL_FLAG, BspSetPaNormalFlagAdapt);
        BspRegistService(BSP_CMD_SET_PA_VIBAS_BY_CHAN, BspSetPaVibasByChanAdapt);
        BspRegistService(BSP_CMD_SET_PA_VIBAS, BspSetPaVibasAdapt);
        BspRegistService(BSP_CMD_SET_PA_FDD_SWITCH, BspSetPaFddSwitchAdapt);
        BspRegistService(BSP_CMD_GET_PA_SWITCH, BspGetPaSwitchAdapt);
        BspRegistService(BSP_CMD_SET_PA_SWITCH, BspSetPaSwitchAdapt);

#ifdef DYNAMIC_API_TEST
        /* 测试接口注册 */
        BspRegistService(BSP_CMD_SHOWPAGRIDVOLT, showpagridvoltAdapt);
#endif

        g_sPa_ic4_2RegistFlag = ISREGIST;
    }
}

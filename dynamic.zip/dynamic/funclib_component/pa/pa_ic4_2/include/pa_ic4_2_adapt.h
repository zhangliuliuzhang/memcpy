#ifndef _PA_IC4_2_ADAPT_H_INCLUDE_
#define _PA_IC4_2_ADAPT_H_INCLUDE_


#endif

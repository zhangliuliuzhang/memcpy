#ifndef _PWR_A_ADAPT_H_INCLUDE_
#define _PWR_A_ADAPT_H_INCLUDE_


#endif

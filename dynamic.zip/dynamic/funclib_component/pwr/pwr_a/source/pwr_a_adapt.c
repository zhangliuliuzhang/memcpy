#include "pwr_a_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "pwrapi.h"
#include "pwr_a.h"

static UINT32 g_sPwr_aRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetPaVoltAdapt(UINT32 cmd, UINT32 index, INT32 volt)
{
    return BspSetPaVolt(index, volt);
}

static UINT32 BspGetPowerSupplyInsufficientAdapt(UINT32 cmd, UINT32 *pStatus)
{
    return BspGetPowerSupplyInsufficient(pStatus);
}

static UINT32 BspGetPwrProtectInfoAdapt(UINT32 cmd, UINT32 index, UINT32 ulInterChan, UINT32 *uiStatus)
{
    return BspGetPwrProtectInfo(index, ulInterChan, uiStatus);
}

static UINT32 BspPwrCutCheckAdapt(UINT32 cmd)
{
    return BspPwrCutCheck();
}

static UINT32 BspGetHighOverTempAlmStatusAdapt(UINT32 cmd, UINT32 *pStatus)
{
    return BspGetHighOverTempAlmStatus(pStatus);
}

static UINT32 BspGetPwrCurrAdapt(UINT32 cmd, UINT32 index, INT32 *pCurr)
{
    return BspGetPwrCurr(index, pCurr);
}

static UINT32 BspGetVindownIsEffectiveAdapt(UINT32 cmd)
{
    return BspGetVindownIsEffective();
}

static UINT32 BspGetBoardVinTypeAdapt(UINT32 cmd, UINT32 index, UINT32 *type)
{
    return BspGetBoardVinType(index, type);
}

static UINT32 BspGetBoardVoltAdapt(UINT32 cmd, UINT32 index, INT32 *pVolt)
{
    return BspGetBoardVolt(index, pVolt);
}

static UINT32 BspGetPwrTempAdapt(UINT32 cmd, UINT32 index, INT32 *pTemp)
{
    return BspGetPwrTemp(index, pTemp);
}

static UINT32 BspGetPwrVoltAdapt(UINT32 cmd, UINT32 index, INT32 *pVolt)
{
    return BspGetPwrVolt(index, pVolt);
}

/* INT32->UINT32 */
static UINT32 BspGetPaVoltAdapt(UINT32 cmd, UINT32 index)
{
    return BspGetPaVolt(index);
}

static UINT32 BspGetPowerStatusAdapt(UINT32 cmd)
{
    return BspGetPowerStatus();
}

static UINT32 BspGetMonitorPwrVoltOutAdapt(UINT32 cmd, UINT32 index, INT32 *pVolt)
{
    return BspGetMonitorPwrVoltOut(index, pVolt);
}

static UINT32 BspCtrlPmAdapt(UINT32 cmd, UINT32 index, UINT32 sw)
{
    return BspCtrlPm(index, sw);
}

static UINT32 BspGetRruConsumedPowerAdapt(UINT32 cmd, UINT32 index, INT32 *pPower)
{
    return BspGetRruConsumedPower(index, pPower);
}

static UINT32 BspGetModuleStatusAdapt(UINT32 cmd, ULONG ulModuleId, ULONG *pulModuleStatus)
{
    return BspGetModuleStatus(ulModuleId, pulModuleStatus);
}

__attribute((constructor)) void _pwr_a_adapt_init_()
{
    if (NOTREGIST == g_sPwr_aRegistFlag)
    {
        BspRegistService(BSP_CMD_SET_PA_VOLT, BspSetPaVoltAdapt);
        BspRegistService(BSP_CMD_GET_POWER_SUPPLY_INSUFFICIENT, BspGetPowerSupplyInsufficientAdapt);
        BspRegistService(BSP_CMD_GET_PWR_PROTECT_INFO, BspGetPwrProtectInfoAdapt);
        BspRegistService(BSP_CMD_PWR_CUT_CHECK, BspPwrCutCheckAdapt);
        BspRegistService(BSP_CMD_GET_HIGH_OVER_TEMP_ALM_STATUS, BspGetHighOverTempAlmStatusAdapt);
        BspRegistService(BSP_CMD_GET_PWR_CURR, BspGetPwrCurrAdapt);
        BspRegistService(BSP_CMD_GET_VINDOWN_IS_EFFECTIVE, BspGetVindownIsEffectiveAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_VIN_TYPE, BspGetBoardVinTypeAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_VOLT, BspGetBoardVoltAdapt);
        BspRegistService(BSP_CMD_GET_PWR_TEMP, BspGetPwrTempAdapt);
        BspRegistService(BSP_CMD_GET_PWR_VOLT, BspGetPwrVoltAdapt);
        BspRegistService(BSP_CMD_GET_PA_VOLT, BspGetPaVoltAdapt);
        BspRegistService(BSP_CMD_GET_POWER_STATUS, BspGetPowerStatusAdapt);
        BspRegistService(BSP_CMD_GET_MONITOR_PWR_VOLT_OUT, BspGetMonitorPwrVoltOutAdapt);
        BspRegistService(BSP_CMD_CTRL_PM, BspCtrlPmAdapt);
        BspRegistService(BSP_CMD_GET_RRU_CONSUMED_POWER, BspGetRruConsumedPowerAdapt);
        BspRegistService(BSP_CMD_GET_MODULE_STATUS, BspGetModuleStatusAdapt);

        g_sPwr_aRegistFlag = ISREGIST;
    }
}

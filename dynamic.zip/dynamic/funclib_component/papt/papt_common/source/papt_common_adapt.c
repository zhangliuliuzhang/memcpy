#include "papt_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"

static UINT32 g_sPapt_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

/* INT32->UINT32 这里高层只判断是否为0，强转可行*/
static UINT32 BspPaProAlmRecoverAdapt(UINT32 cmd, UINT32 ulPaProAlmType, UINT64 u64EventAlmMask)
{
    return BspPaProAlmRecover(ulPaProAlmType, u64EventAlmMask);
}

static UINT32 BspGetPaProPastAlmAdapt(UINT32 cmd, T_PaProInputParam *ptPaProParam, T_PaProFlagOutput *ptPaProOutput)
{
    return BspGetPaProPastAlm(ptPaProParam, ptPaProOutput);
}

__attribute((constructor)) void _papt_common_adapt_init_()
{
    if (NOTREGIST == g_sPapt_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_PA_PRO_ALM_RECOVER, BspPaProAlmRecoverAdapt);
        BspRegistService(BSP_CMD_GET_PA_PRO_PAST_ALM, BspGetPaProPastAlmAdapt);

        g_sPapt_commonRegistFlag = ISREGIST;
    }
}

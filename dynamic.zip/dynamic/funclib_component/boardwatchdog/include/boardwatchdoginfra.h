#ifndef _BOARD_WATCH_DOG_INFRA_H_INCLUDE_
#define _BOARD_WATCH_DOG_INFRA_H_INCLUDE_
#ifdef __cplusplus 
extern "C" { 
#endif

#include "bspbasetype.h"
#include "regtbl.h"
#define dbgErr zte_printf_s
#define dbgInfoEx zte_printf_s
UINT32 IcHalWrReg(UINT32 chip, E_IC_REG_FUNCID_DEF regIdx, UINT32 ulOffset, UINT32 val);
UINT32 IcHalRdReg(UINT32 chip, E_IC_REG_FUNCID_DEF regIdx, UINT32 ulOffset, UINT32* pVal);
UINT32 BspHalAdaptCfgSetCrmFifteenthRecordReg(UINT32 regVal, UINT32 bitStart, UINT32 bitEnd);
UINT32 BspHalAdaptCfgGetCrmFifteenthRecordReg(UINT32 bitStart, UINT32 bitEnd, UINT32 *pRegVal);
UINT32 BspHalAdaptCrmRecRegSet(UINT32 ulOffset, UINT32 ulBitStart, UINT32 ulBitEnd, UINT32 ulInitRec);

#ifdef __cplusplus
}
#endif

#endif




#include "operatingregister.h"
#include "boardwatchdoginfra.h"

static UINT32 GetPhyAdrr(E_IC_REG_FUNCID_DEF regIdx)
{
    unsigned long phyAddr = 0;
    switch(regIdx)
    {
        case WD_REG_LOAD:
        {
            phyAddr = 0xC8004580;
            break;
        }
        case WD_REG_LOCK:
        {
            phyAddr = 0xDC104C00;
            break;
        }
        case WD_REG_COUNTROL:
        {
            phyAddr = 0xDC104008;
            break;
        }
        case CRM_M0_KERNEL_RSV_RESET_REC14:
        {
            phyAddr = 0xD4C00178;
            break;
        }
        case CRM_M0_KERNEL_RSV_RESET_REC13:
        {
            phyAddr = 0xD4C00174;
            break;
        }
        default:
        {
            zte_printf_s("[%s] regIdx is error.\n", __FUNCTION__);
            break;
        }
    }
    return phyAddr;
}

UINT32 IcHalWrReg(UINT32 chip, E_IC_REG_FUNCID_DEF regIdx, UINT32 ulOffset, UINT32 val)
{
    unsigned long phyAddr = GetPhyAdrr(regIdx);
    IcHalWrIc(phyAddr + ulOffset, val);
    return BSP_OK;
}

UINT32 IcHalRdReg(UINT32 chip, E_IC_REG_FUNCID_DEF regIdx, UINT32 ulOffset, UINT32* pVal)
{
    if (NULL == pVal)
    {
        return BSP_ERROR;
    }
    unsigned long phyAddr = GetPhyAdrr(regIdx);
    *pVal = IcHalRdIc(phyAddr + ulOffset);
    return BSP_OK;
}

UINT32 BspHalAdaptCfgSetCrmFifteenthRecordReg(UINT32 regVal, UINT32 bitStart, UINT32 bitEnd)
{
    UINT32 val = 0;
    UINT32 mask = 0;
    if (BSP_ERROR == IcHalRdReg(0, CRM_M0_KERNEL_RSV_RESET_REC14, 4, &val))
    {
        zte_printf_s("[%s] read error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    mask = (1 << (bitEnd - bitStart + 1)) - 1;
    val &= ~(mask << bitStart);
    val |= (regVal & mask) << bitStart;
    if (BSP_ERROR == IcHalWrReg(0, CRM_M0_KERNEL_RSV_RESET_REC14, 4, val))
    {
        zte_printf_s("[%s] write error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspHalAdaptCfgGetCrmFifteenthRecordReg(UINT32 bitStart, UINT32 bitEnd, UINT32 *pRegVal)
{
    UINT32 mask = 0;
    if (BSP_ERROR == IcHalRdReg(0, CRM_M0_KERNEL_RSV_RESET_REC14, 4, pRegVal))
    {
        zte_printf_s("[%s] write error.\n", __FUNCTION__);
        return BSP_ERROR;        
    }
    mask = (1 << (bitEnd - bitStart + 1)) - 1;
    *pRegVal = (*pRegVal >> bitStart) & mask;
    return BSP_OK;
}

UINT32 BspHalAdaptCrmRecRegSet(UINT32 ulOffset, UINT32 ulBitStart, UINT32 ulBitEnd, UINT32 ulInitRec)
{
    UINT32 val = 0;
    UINT32 mask = 0;
    if (BSP_ERROR == IcHalRdReg(0, CRM_M0_KERNEL_RSV_RESET_REC13, ulOffset, &val))
    {
        zte_printf_s("[%s] read error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    mask = (1 << (ulBitEnd - ulBitStart + 1)) - 1;
    val &= ~(mask << ulBitStart);
    val |= (ulInitRec & mask) << ulBitStart;
    if (BSP_ERROR == IcHalWrReg(0, CRM_M0_KERNEL_RSV_RESET_REC13, ulOffset, val))
    {
        zte_printf_s("[%s] write error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}
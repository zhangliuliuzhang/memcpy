#include "pimc_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "pimcapi.h"

static UINT32 g_sPimc_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspPimCheckFreqAdapt(UINT32 cmd, UINT32 bspChn, UINT32 uFreq)
{
    return BspPimCheckFreq(bspChn, uFreq);
}

static UINT32 BspPimDataReadAdapt(UINT32 cmd, UINT32 bspChn, UINT32 *pPimVal)
{
    return BspPimDataRead(bspChn, pPimVal);
}

static UINT32 BspPimSwitchAdapt(UINT32 cmd, UINT32 bspChn, UINT32 uSwitch)
{
    return BspPimSwitch(bspChn, uSwitch);
}

static UINT32 BspPimcStopAdapt(UINT32 cmd, UINT32 bspChn, UINT32 bandId)
{
    return BspPimcStop(bspChn, bandId);
}

static UINT32 BspPimcStartAdapt(UINT32 cmd, UINT32 bspChn, UINT32 bandId)
{
    return BspPimcStart(bspChn, bandId);
}

__attribute((constructor)) void _pimc_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sPimc_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_PIM_CHECK_FREQ, BspPimCheckFreqAdapt);
        BspRegistService(BSP_CMD_PIM_DATA_READ, BspPimDataReadAdapt);
        BspRegistService(BSP_CMD_PIM_SWITCH, BspPimSwitchAdapt);
        BspRegistService(BSP_CMD_PIMC_STOP, BspPimcStopAdapt);
        BspRegistService(BSP_CMD_PIMC_START, BspPimcStartAdapt);

        g_sPimc_ic4_2RegistFlag = ISREGIST;
    }
}

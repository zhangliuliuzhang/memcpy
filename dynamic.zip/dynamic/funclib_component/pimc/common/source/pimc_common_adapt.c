#include "pimc_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "pimccommon.h"

static UINT32 g_sPimc_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetPimcDpdSamplingRateAdapt(UINT32 cmd, UINT32 bspChn, UINT32 *pDpdSamplingRate)
{
    return BspGetPimcDpdSamplingRate(bspChn, pDpdSamplingRate);
}

static UINT32 BspGetPimcDpdFreOffsetAdapt(UINT32 cmd, UINT32 bspChn, INT32 *pDpdFreOffset)
{
    return BspGetPimcDpdFreOffset(bspChn, pDpdFreOffset);
}

__attribute((constructor)) void _pimc_common_adapt_init_()
{
    if (NOTREGIST == g_sPimc_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_PIMC_DPD_SAMPLING_RATE, BspGetPimcDpdSamplingRateAdapt);
        BspRegistService(BSP_CMD_GET_PIMC_DPD_FRE_OFFSET, BspGetPimcDpdFreOffsetAdapt);

        g_sPimc_commonRegistFlag = ISREGIST;
    }
}

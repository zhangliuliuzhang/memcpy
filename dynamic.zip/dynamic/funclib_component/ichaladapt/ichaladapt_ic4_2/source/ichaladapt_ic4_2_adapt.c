#include "ichaladapt_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "ichaladapt_ic4_2.h"

static UINT32 g_sIchaladapt_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspOptSetSpectrumShareAdapt(UINT32 cmd, UINT32 cellId, UINT32 specShare)
{
    return BspOptSetSpectrumShare(cellId, specShare);
}

static UINT32 BspHalAdaptSampleDlCfr1Adapt(UINT32 cmd, UINT32 uiDifChan, UINT32 uiPosSel)
{
    return BspHalAdaptSampleDlCfr1(uiDifChan, uiPosSel);
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 BspHalAdaptSetFrSelectAdapt(UINT32 cmd, UINT32 difChan, T_BspHalAdaptFrTypeCfg *pFrTypeCfg)
{
    return BspHalAdaptSetFrSelect(difChan, pFrTypeCfg);
}

static UINT32 BspHalAdaptSetUlCarrGainSwAdapt(UINT32 cmd, UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw)
{
    return BspHalAdaptSetUlCarrGainSw(difChan, radioMode, carrIndex, sw);
}

static UINT32 BspHalAdaptSetFrSelectByDirAdapt(UINT32 cmd, UINT32 difChan, UINT32 dir)
{
    return BspHalAdaptSetFrSelectByDir(difChan, dir);
}

static UINT32 BspHalAdaptSetGsmCellInfoAdapt(UINT32 cmd, T_GsmCellInfo *gsmCellInfo)
{
    return BspHalAdaptSetGsmCellInfo(gsmCellInfo);
}

static UINT32 BspHalAdaptPsyncCfgAdapt(UINT32 cmd, UINT32 psyncMode)
{
    return BspHalAdaptPsyncCfg(psyncMode);
}

static UINT32 BspHalAdaptSetDlCarrGainSwAdapt(UINT32 cmd, UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw)
{
    return BspHalAdaptSetDlCarrGainSw(difChan, radioMode, carrIndex, sw);
}
#endif

__attribute((constructor)) void _ichaladapt_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sIchaladapt_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_OPT_SET_SPECTRUM_SHARE, BspOptSetSpectrumShareAdapt);
        BspRegistService(BSP_CMD_HAL_ADAPT_SAMPLE_DL_CFR1, BspHalAdaptSampleDlCfr1Adapt);

#ifdef DYNAMIC_API_TEST
        BspRegistService(BSP_CMD_HAL_ADAPT_SET_FR_SELECT, BspHalAdaptSetFrSelectAdapt);
        BspRegistService(BSP_CMD_HAL_ADAPT_SET_UL_CARR_GAIN_SW, BspHalAdaptSetUlCarrGainSwAdapt);
        BspRegistService(BSP_CMD_HAL_ADAPT_SET_FR_SELECT_BY_DIR, BspHalAdaptSetFrSelectByDirAdapt);
        BspRegistService(BSP_CMD_HAL_ADAPT_SET_GSM_CELL_INFO, BspHalAdaptSetGsmCellInfoAdapt);
        BspRegistService(BSP_CMD_HAL_ADAPT_PSYNC_CFG, BspHalAdaptPsyncCfgAdapt);
        BspRegistService(BSP_CMD_HAL_ADAPT_SET_DL_CARR_GAIN_SW, BspHalAdaptSetDlCarrGainSwAdapt);
#endif

        g_sIchaladapt_ic4_2RegistFlag = ISREGIST;
    }
}

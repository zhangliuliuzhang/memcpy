#include "freqcfg_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "freqcfg_ic4_2_analyse.h"
#include "bsppub.h"
#include "freqcfg_ic4_2.h"

static UINT32 g_sFreqcfg_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetTsgSwitchAdapt(UINT32 cmd, UINT32 chan, UINT32 carr, UINT32 carrRadio, UINT32 isOn)
{
    return BspSetTsgSwitch(chan, carr, carrRadio, isOn);
}

static UINT32 BspSetRxRfCfgAdapt(UINT32 cmd, UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
    return BspSetRxRfCfg(chan, pRfCfgPara);
}

static UINT32 BspIsExistTxLinkAdapt(UINT32 cmd, UINT32 bspChan, UINT32 *txCarrNum)
{
    return BspIsExistTxLink(bspChan, txCarrNum);
}

static UINT32 BspGetCenterFreqAdapt(UINT32 cmd, UINT32 dir, UINT32 chan)
{
    return BspGetCenterFreq(dir, chan);
}

static UINT32 BspSetTxRfCfgAdapt(UINT32 cmd, UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
    return BspSetTxRfCfg(chan, pRfCfgPara);
}

static UINT32 BspSetTxRxCarrFreqAdapt(UINT32 cmd, UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, UINT32 dir,UINT32 carrFreq)
{
    return BspSetTxRxCarrFreq(bspChan, carrNo, radioMode, dir, carrFreq);
}

static UINT32 BspSetUmtsCarrFreqAdapt(UINT32 cmd, UINT32 bspChan, UINT32 dir, UINT32 umtsCarrNo, INT32 freqOffset)
{
    return BspSetUmtsCarrFreq(bspChan, dir, umtsCarrNo, freqOffset);
}

static UINT32 BspSetUmtsTxNcoAdapt(UINT32 cmd, UINT32 chanId, UINT32 carrNo, INT32 swFreqOffset)
{
    return BspSetUmtsTxNco(chanId, carrNo, swFreqOffset);
}

static UINT32 BspAnalyseRfcCfgFreqCarrInfoAdapt(UINT32 cmd, T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    return BspAnalyseRfcCfgFreqCarrInfo(pCarrInfoAllChans);
}

static UINT32 BspChangePllCfgPreAnalyseAdapt(UINT32 cmd, UINT32 trx, T_RfCfgParaAllChan *allChanCfgInfo , T_PllChangeInfoAllChan *allChanChangeInfo)
{
    return BspChangePllCfgPreAnalyse(trx, allChanCfgInfo, allChanChangeInfo);
}

static UINT32 BspResourceAllocRptAdapt(UINT32 cmd, T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    return BspResourceAllocRpt(pCarrInfoAllChans);
}

static UINT32 BspSetUmtsDlFilterCoefAdapt(UINT32 cmd, UINT32 bspChan, UINT32 radioMod, UINT32 carrNo, UINT32 bandWidth)
{
    return BspSetUmtsDlFilterCoef(bspChan, radioMod, carrNo, bandWidth);
}

static UINT32 BspGetPublicDlFilterParaAdapt(UINT32 cmd, UINT32 bspChan, UINT32 carrNo, UINT32 radioMod, T_carrFilterPara *carrPara)
{
    return BspGetPublicDlFilterPara(bspChan, carrNo, radioMod, carrPara);
}

static UINT32 BspIsFreqCfgDynamicAdapt(UINT32 cmd)
{
    return BspIsFreqCfgDynamic();
}

static UINT32 BspSetTsgTdmInfoAdapt(UINT32 cmd, T_Tsg_TdmInfo *ptTdmInfo)
{
    return BspSetTsgTdmInfo(ptTdmInfo);
}

static UINT32 BspIsExistRxLinkAdapt(UINT32 cmd, UINT32 bspChan, UINT32 *rxCarrNum)
{
    return BspIsExistRxLink(bspChan, rxCarrNum);
}

static UINT32 BspResourceAllocCfgAdapt(UINT32 cmd, UINT32 dir, UINT32 rfChan, T_RfChanCfgEn *pRfChanCfgEn)
{
    return BspResourceAllocCfg(dir, rfChan, pRfChanCfgEn);
}

static UINT32 BspSetGsmCellInfoAdapt(UINT32 cmd, T_GsmCellInfo *gsmCellInfo)
{
    return BspSetGsmCellInfo(gsmCellInfo);
}

static UINT32 BspUpdateVswrCompsAdapt(UINT32 cmd, UINT32 uBspChan, UINT32 uFreqKHz)
{
    return BspUpdateVswrComps(uBspChan, uFreqKHz);
}

static UINT32 BspPreAnalyseCarrInfoAdapt(UINT32 cmd, T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    return BspPreAnalyseCarrInfo(pCarrInfoAllChans);
}

static UINT32 BspGetRcfCoefByBandWithAdapt(UINT32 cmd, UINT32 bspChan, UINT32 radioMod, UINT32 bandWidth)
{
    return BspGetRcfCoefByBandWith(bspChan, radioMod, bandWidth);
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 BspResourceAllocClrAdapt(UINT32 cmd, UINT32 dir)
{
    return BspResourceAllocClr(dir);
}
#endif

__attribute((constructor)) void _freqcfg_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sFreqcfg_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_SET_TSG_SWITCH, BspSetTsgSwitchAdapt);
        BspRegistService(BSP_CMD_SET_RX_RF_CFG, BspSetRxRfCfgAdapt);
        BspRegistService(BSP_CMD_IS_EXIST_TX_LINK, BspIsExistTxLinkAdapt);
        BspRegistService(BSP_CMD_GET_CENTER_FREQ, BspGetCenterFreqAdapt);
        BspRegistService(BSP_CMD_SET_TX_RF_CFG, BspSetTxRfCfgAdapt);
        BspRegistService(BSP_CMD_SET_TX_RX_CARR_FREQ, BspSetTxRxCarrFreqAdapt);
        BspRegistService(BSP_CMD_SET_UMTS_CARR_FREQ, BspSetUmtsCarrFreqAdapt);
        BspRegistService(BSP_CMD_SET_UMTS_TX_NCO, BspSetUmtsTxNcoAdapt);
        BspRegistService(BSP_CMD_ANALYSE_RFC_CFG_FREQ_CARR_INFO, BspAnalyseRfcCfgFreqCarrInfoAdapt);
        BspRegistService(BSP_CMD_CHANGE_PLL_CFG_PRE_ANALYSE, BspChangePllCfgPreAnalyseAdapt);
        BspRegistService(BSP_CMD_RESOURCE_ALLOC_RPT, BspResourceAllocRptAdapt);
        BspRegistService(BSP_CMD_SET_UMTS_DL_FILTER_COEF, BspSetUmtsDlFilterCoefAdapt);
        BspRegistService(BSP_CMD_GET_PUBLIC_DL_FILTER_PARA, BspGetPublicDlFilterParaAdapt);
        BspRegistService(BSP_CMD_IS_FREQ_CFG_DYNAMIC, BspIsFreqCfgDynamicAdapt);
        BspRegistService(BSP_CMD_SET_TSG_TDM_INFO, BspSetTsgTdmInfoAdapt);
        BspRegistService(BSP_CMD_IS_EXIST_RX_LINK, BspIsExistRxLinkAdapt);
        BspRegistService(BSP_CMD_RESOURCE_ALLOC_CFG, BspResourceAllocCfgAdapt);
        BspRegistService(BSP_CMD_SET_GSM_CELL_INFO, BspSetGsmCellInfoAdapt);
        BspRegistService(BSP_CMD_UPDATE_VSWR_COMPS, BspUpdateVswrCompsAdapt);
        BspRegistService(BSP_CMD_PRE_ANALYSE_CARR_INFO, BspPreAnalyseCarrInfoAdapt);
        BspRegistService(BSP_CMD_GET_RCF_COEF_BY_BAND_WITH, BspGetRcfCoefByBandWithAdapt);

#ifdef DYNAMIC_API_TEST
        BspRegistService(BSP_CMD_RESOURCE_ALLOC_CLR, BspResourceAllocClrAdapt);
#endif
        g_sFreqcfg_ic4_2RegistFlag = ISREGIST;
    }
}

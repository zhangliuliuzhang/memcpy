#include "freqcfg_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "freqcfgcommon.h"
#include "freqcfgapi.h"

static UINT32 g_sFreqcfg_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspHandlePreLoReCfgAdapt(UINT32 cmd, UINT32 trx, UINT32 chan)
{
    return BspHandlePreLoReCfg(trx, chan);
}

static UINT32 BspSetNbTxFreqOffsetAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrNo, INT32 offset)
{
    return BspSetNbTxFreqOffset(bspChn, carrNo, offset);
}

static UINT32 BspSetCenterFreqAdapt(UINT32 cmd, UINT32 dir, UINT32 chan, UINT32 freq)
{
    return BspSetCenterFreq(dir, chan, freq);
}

static UINT32 BspGetLoFreqAdapt(UINT32 cmd, UINT32 dir, UINT32 chan)
{
    return BspGetLoFreq(dir, chan);
}

static UINT32 BspSetNbRxFreqOffsetAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrNo, INT32 offset)
{
    return BspSetNbRxFreqOffset(bspChn, carrNo, offset);
}

static UINT32 BspSetTransceiverLoFreqAdapt(UINT32 cmd, UINT32 trx, UINT32 chan, UINT32 freq)
{
    return BspSetTransceiverLoFreq(trx, chan, freq);
}

static UINT32 BspGetRfCfgCarrSumAdapt(UINT32 cmd, UINT32 dir, UINT32 chan)
{
    return BspGetRfCfgCarrSum(dir, chan);
}

static UINT32 BspHandlePostLoReCfgAdapt(UINT32 cmd, UINT32 trx, UINT32 chan)
{
    return BspHandlePostLoReCfg(trx, chan);
}

static UINT32 BspRfCfgInfoCollectAdapt(UINT32 cmd)
{
    return BspRfCfgInfoCollect();
}

__attribute((constructor)) void _freqcfg_common_adapt_init_()
{
    if (NOTREGIST == g_sFreqcfg_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_HANDLE_PRE_LO_RE_CFG, BspHandlePreLoReCfgAdapt);
        BspRegistService(BSP_CMD_SET_NB_TX_FREQ_OFFSET, BspSetNbTxFreqOffsetAdapt);
        BspRegistService(BSP_CMD_SET_CENTER_FREQ, BspSetCenterFreqAdapt);
        BspRegistService(BSP_CMD_GET_LO_FREQ, BspGetLoFreqAdapt);
        BspRegistService(BSP_CMD_SET_NB_RX_FREQ_OFFSET, BspSetNbRxFreqOffsetAdapt);
        BspRegistService(BSP_CMD_SET_TRANSCEIVER_LO_FREQ, BspSetTransceiverLoFreqAdapt);
        BspRegistService(BSP_CMD_GET_RF_CFG_CARR_SUM, BspGetRfCfgCarrSumAdapt);
        BspRegistService(BSP_CMD_HANDLE_POST_LO_RE_CFG, BspHandlePostLoReCfgAdapt);
        BspRegistService(BSP_CMD_RF_CFG_INFO_COLLECT, BspRfCfgInfoCollectAdapt);

        g_sFreqcfg_commonRegistFlag = ISREGIST;
    }
}

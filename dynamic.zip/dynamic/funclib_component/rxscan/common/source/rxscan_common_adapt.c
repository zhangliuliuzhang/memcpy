#include "rxscan_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "rxscanapi.h"

static UINT32 g_sRxscan_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetRxScanDataAdapt(UINT32 cmd, UINT32 count, T_RxScan *pRxScanData)
{
    return BspGetRxScanData(count, pRxScanData);
}

static UINT32 BspRxScanParaReInitAdapt(UINT32 cmd)
{
    return BspRxScanParaReInit();
}

static UINT32 BspGetRxScanFreqAdapt(UINT32 cmd, UINT32 bspRxChn, UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep)
{
    return BspGetRxScanFreq(bspRxChn, pStartFreq, pStopFreq, pStep);
}

static UINT32 BspRxScanCalAdapt(UINT32 cmd, UINT32 bspRxChn, UINT32 band, UINT32 antStat, UINT32 cellStat)
{
    return BspRxScanCal(bspRxChn, band, antStat, cellStat);
}

static UINT32 BspRxScanSampleAdapt(UINT32 cmd, UINT32 bspRxChn, UINT32 band)
{
    return BspRxScanSample(bspRxChn, band);
}

static UINT32 BspRestRxScanDataAdapt(UINT32 cmd)
{
    return BspRestRxScanData();
}

static UINT32 BspRxScanDpdStatusAdapt(UINT32 cmd, UINT32 bspRxChn, UINT32 bspTxChn, UINT32 * pDpdFlag)
{
    return BspRxScanDpdStatus(bspRxChn, bspTxChn, pDpdFlag);
}

__attribute((constructor)) void _rxscan_common_adapt_init_()
{
    if (NOTREGIST == g_sRxscan_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_RX_SCAN_DATA, BspGetRxScanDataAdapt);
        BspRegistService(BSP_CMD_RX_SCAN_PARA_RE_INIT, BspRxScanParaReInitAdapt);
        BspRegistService(BSP_CMD_GET_RX_SCAN_FREQ, BspGetRxScanFreqAdapt);
        BspRegistService(BSP_CMD_RX_SCAN_CAL, BspRxScanCalAdapt);
        BspRegistService(BSP_CMD_RX_SCAN_SAMPLE, BspRxScanSampleAdapt);
        BspRegistService(BSP_CMD_REST_RX_SCAN_DATA, BspRestRxScanDataAdapt);
        BspRegistService(BSP_CMD_RX_SCAN_DPD_STATUS, BspRxScanDpdStatusAdapt);

        g_sRxscan_commonRegistFlag = ISREGIST;
    }
}

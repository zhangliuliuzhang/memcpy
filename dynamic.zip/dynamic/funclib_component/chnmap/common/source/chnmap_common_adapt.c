#include "chnmap_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "chnmapapi.h"

static UINT32 g_sChnmap_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetSfpTypeByLgcIdAdapt(UINT32 cmd, UINT32 sfpIndex)
{
    return BspGetSfpTypeByLgcId(sfpIndex);
}

static UINT32 BspGetOptRaidoByPhyOptAdapt(UINT32 cmd, UINT32 phyOpt, UINT32 *radioMode, UINT32 *optPro)
{
    return BspGetOptRaidoByPhyOpt(phyOpt, radioMode, optPro);
}

static UINT32 BspGetMcsCarrIdMapAdapt(UINT32 cmd, T_McsCarrIdMap *pMap, UINT32 *num)
{
    return BspGetMcsCarrIdMap(pMap, num);
}

static UINT32 BspSetMcsCarrIdMapAdapt(UINT32 cmd, T_McsCarrIdMap *pMap, UINT32 num)
{
    return BspSetMcsCarrIdMap(pMap, num);
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 BspGetRxBspChanNumAdapt(UINT32 cmd)
{
    return BspGetRxBspChanNum();
}

static UINT32 BspGetTxBspChanNumAdapt(UINT32 cmd)
{
    return BspGetTxBspChanNum();
}
#endif

__attribute((constructor)) void _chnmap_common_adapt_init_()
{
    if (NOTREGIST == g_sChnmap_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_SFP_TYPE_BY_LGC_ID, BspGetSfpTypeByLgcIdAdapt);
        BspRegistService(BSP_CMD_GET_OPT_RAIDO_BY_PHY_OPT, BspGetOptRaidoByPhyOptAdapt);
        BspRegistService(BSP_CMD_GET_MCS_CARR_ID_MAP, BspGetMcsCarrIdMapAdapt);
        BspRegistService(BSP_CMD_SET_MCS_CARR_ID_MAP, BspSetMcsCarrIdMapAdapt);

#ifdef DYNAMIC_API_TEST
        BspRegistService(BSP_CMD_GET_RX_BSP_CMD_CHAN_NUM, BspGetRxBspChanNumAdapt);
        BspRegistService(BSP_CMD_GET_TX_BSP_CMD_CHAN_NUM, BspGetTxBspChanNumAdapt);
#endif

        g_sChnmap_commonRegistFlag = ISREGIST;
    }
}

#include "chnmap_a_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "chnmapapi.h"

static UINT32 g_sChnmap_aRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetPwrIdxByBspChanAdapt(UINT32 cmd, UINT32 bspChan, UINT32 *pPwrIdx)
{
    return BspGetPwrIdxByBspChan(bspChan, pPwrIdx);
}

__attribute((constructor)) void _chnmap_a_adapt_init_()
{
    if (NOTREGIST == g_sChnmap_aRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_PWR_IDX_BY_BSP_CHAN, BspGetPwrIdxByBspChanAdapt);

        g_sChnmap_aRegistFlag = ISREGIST;
    }
}

#ifndef _DIF_LOG_STUBS_H_INCLUDE_
#define _DIF_LOG_STUBS_H_INCLUDE_

#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"

VOID IcHalApiSetHalLogLevel(UINT32 uiLogLevel);


#ifdef __cplusplus
}
#endif


#endif /* _DIF_LOG_STUBS_H_INCLUDE_ */
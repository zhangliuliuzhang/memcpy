#ifndef _ICHAL_OPT_LOGRECORD_STUBS_H_INCLUDE_
#define _ICHAL_OPT_LOGRECORD_STUBS_H_INCLUDE_

#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"

UINT32 IcHalApiSetOptLogLevel(UINT32 ulLogLevel);


#ifdef __cplusplus
}
#endif


#endif /* _ICHAL_OPT_LOGRECORD_STUBS_H_INCLUDE_ */
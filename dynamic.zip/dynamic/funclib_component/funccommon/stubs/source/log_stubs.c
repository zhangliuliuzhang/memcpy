#include "dif_hal_log.h"
#include "ichal_opt_logrecord.h"

VOID IcHalApiSetHalLogLevel(UINT32 uiLogLevel)
{
    return;
}

UINT32 IcHalApiSetOptLogLevel(UINT32 ulLogLevel)
{
    return BSP_OK;
}

UINT32 BspGetAreaLogLevel(UINT32 area)
{
    return BSP_OK;
}
#include "funccommon_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "funccommon_chncfg.h"
#include "funccommonapi.h"

static UINT32 g_sFunccommonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetRxCenterFreqCfgAdapt(UINT32 cmd, UINT32 rfchn)
{
    return BspGetRxCenterFreqCfg(rfchn);
}

static UINT32 BspSetEcpriUdpPortAdapt(UINT32 cmd, UINT32 ecpriPort, UINT32 roePort)
{
    return BspSetEcpriUdpPort(ecpriPort, roePort);
}

static UINT32 BspRruLinkPwrOffChkByVerActAdapt(UINT32 cmd, UINT32 *pIsPwrOff)
{
    return BspRruLinkPwrOffChkByVerAct(pIsPwrOff);
}

static UINT32 BspChkCevaVersionStatusAdapt(UINT32 cmd)
{
    return BspChkCevaVersionStatus();
}

static UINT32 BspGetFpgaAntiIntfModeAdapt(UINT32 cmd)
{
    return BspGetFpgaAntiIntfMode();
}

static UINT32 BspUpdateCarrCfgFlagAdapt(UINT32 cmd, UINT32 bspChan, UINT32 dir, T_RfCfgPara *rfCfg)
{
    return BspUpdateCarrCfgFlag(bspChan, dir, rfCfg);
}

static UINT32 BspGetCarrierNumAdapt(UINT32 cmd)
{
    return BspGetCarrierNum();
}

static UINT32 BspCheckFpgaStatusAdapt(UINT32 cmd, UINT32 *status, UINT8 *strInfo, UINT32 strLen)
{
    return BspCheckFpgaStatus(status, strInfo, strLen);
}

static UINT32 BspSetRruCfgPara_5GAdapt(UINT32 cmd, UINT32 rfChn, T_RruVswrInfo *pRruVswrInfo)
{
    return BspSetRruCfgPara_5G(rfChn, pRruVswrInfo);
}

static UINT32 BspRruLinkPwrOffRecCfgAdapt(UINT32 cmd)
{
    return BspRruLinkPwrOffRecCfg();
}

static UINT32 BspGetProcessStrategyAdapt(UINT32 cmd, UINT32 socMap, UINT32 socNum, UINT32 *delaTime, UINT32 *pOutSocStrategy)
{
    return BspGetProcessStrategy(socMap, socNum, delaTime, pOutSocStrategy);
}

/* VOID->UINT32 */
static UINT32 BspSetTsgModeAdapt(UINT32 cmd, UINT8 enable)
{
    BspSetTsgMode(enable);
    return BSP_OK;
}

static UINT32 BspGetRruSupportCarrNumAdapt(UINT32 cmd, UINT32 uChn, UINT32 uBand, UINT32 uMode)
{
    return BspGetRruSupportCarrNum(uChn, uBand, uMode);
}

static UINT32 BspSetEcpriUdpPortDefaultAdapt(UINT32 cmd)
{
    return BspSetEcpriUdpPortDefault();
}

static UINT32 BspSetCellAntInfoAdapt(UINT32 cmd, T_FddCellAntInfo *pCellAntInfo)
{
    return BspSetCellAntInfo(pCellAntInfo);
}

/* 枚举E_BoardOptProType->UINT32*/
static UINT32 BspGetOptProTypeAdapt(UINT32 cmd, UINT32 optIndex)
{
    return BspGetOptProType(optIndex);
}

static UINT32 BspGetVirtualCarrNoOffsetParaAdapt(UINT32 cmd, UINT32 *offset, UINT32 *mod)
{
    return BspGetVirtualCarrNoOffsetPara(offset, mod);
}

static UINT32 BspProcessStategyAdapt(UINT32 cmd, UINT32 rpuId)
{
    return BspProcessStategy(rpuId);
}

static UINT32 BspSetResetTypeCauseAdapt(UINT32 cmd, UINT32 resetType, UINT32 cause)
{
    return BspSetResetTypeCause(resetType, cause);
}

static UINT32 BspSetCarrActiveStatusAdapt(UINT32 cmd, UINT32 ulChan, UINT32 dir, UINT32 ulRadioMode, UINT32 ulCarrNo, UINT32 ulActSta)
{
    return BspSetCarrActiveStatus(ulChan, dir, ulRadioMode, ulCarrNo, ulActSta);
}

static UINT32 BspGetPowonStrategyAdapt(UINT32 cmd)
{
    return BspGetPowonStrategy();
}

static UINT32 BspSetCarrAntPortNumAdapt(UINT32 cmd, T_RruCfgCarrAntPortInfo *stRruCarrPortCfg)
{
    return BspSetCarrAntPortNum(stRruCarrPortCfg);
}

static UINT32 BspSetNtfRssiSwitchAdapt(UINT32 cmd, UINT32 sw)
{
    return BspSetNtfRssiSwitch(sw);
}

static UINT32 BspSetNtfAvoidFlagAdapt(UINT32 cmd, UINT32 ntfAvoidFlag)
{
    return BspSetNtfAvoidFlag(ntfAvoidFlag);
}

static UINT32 BspGetSharePowerRisingLevelAdapt(UINT32 cmd, UINT32 *quotaLimit)
{
    return BspGetSharePowerRisingLevel(quotaLimit);
}

static UINT32 BspGetSharePowerTimeGapAdapt(UINT32 cmd, UINT32 *timeLimit)
{
    return BspGetSharePowerTimeGap(timeLimit);
}

static UINT32 BspRruLinkPwrOffChkAdapt(UINT32 cmd, UINT32 *pIsPwrOff, UINT8 *pDesc, UINT32 descLen)
{
    return BspRruLinkPwrOffChk(pIsPwrOff, pDesc, descLen);
}

static UINT32 BspResetDeviceAdapt(UINT32 cmd, OSS_ULONG devId, UINT32 resetType, UINT32 cause)
{
    return BspResetDevice(devId, resetType, cause);
}

static UINT32 BspRruLinkBreakTimeClrAdapt(UINT32 cmd)
{
    return BspRruLinkBreakTimeClr();
}

/* VOID->UINT32 */
static UINT32 BspBoardResetAdapt(UINT32 cmd)
{
    BspBoardReset();
    return BSP_OK;
}

__attribute((constructor)) void _funccommon_adapt_init_()
{
    if (NOTREGIST == g_sFunccommonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_RX_CENTER_FREQ_CFG, BspGetRxCenterFreqCfgAdapt);
        BspRegistService(BSP_CMD_SET_ECPRI_UDP_PORT, BspSetEcpriUdpPortAdapt);
        BspRegistService(BSP_CMD_RRU_LINK_PWR_OFF_CHK_BY_VER_ACT, BspRruLinkPwrOffChkByVerActAdapt);
        BspRegistService(BSP_CMD_CHK_CEVA_VERSION_STATUS, BspChkCevaVersionStatusAdapt);
        BspRegistService(BSP_CMD_GET_FPGA_ANTI_INTF_MODE, BspGetFpgaAntiIntfModeAdapt);
        BspRegistService(BSP_CMD_UPDATE_CARR_CFG_FLAG, BspUpdateCarrCfgFlagAdapt);
        BspRegistService(BSP_CMD_GET_CARRIER_NUM, BspGetCarrierNumAdapt);
        BspRegistService(BSP_CMD_CHECK_FPGA_STATUS, BspCheckFpgaStatusAdapt);
        BspRegistService(BSP_CMD_SET_RRU_CFG_PARA_5G, BspSetRruCfgPara_5GAdapt);
        BspRegistService(BSP_CMD_RRU_LINK_PWR_OFF_REC_CFG, BspRruLinkPwrOffRecCfgAdapt);
        BspRegistService(BSP_CMD_GET_PROCESS_STRATEGY, BspGetProcessStrategyAdapt);
        BspRegistService(BSP_CMD_SET_TSG_MODE, BspSetTsgModeAdapt);
        BspRegistService(BSP_CMD_GET_RRU_SUPPORT_CARR_NUM, BspGetRruSupportCarrNumAdapt);
        BspRegistService(BSP_CMD_SET_ECPRI_UDP_PORT_DEFAULT, BspSetEcpriUdpPortDefaultAdapt);
        BspRegistService(BSP_CMD_SET_CELL_ANT_INFO, BspSetCellAntInfoAdapt);
        BspRegistService(BSP_CMD_GET_OPT_PRO_TYPE, BspGetOptProTypeAdapt);
        BspRegistService(BSP_CMD_GET_VIRTUAL_CARR_NO_OFFSET_PARA, BspGetVirtualCarrNoOffsetParaAdapt);
        BspRegistService(BSP_CMD_PROCESS_STATEGY, BspProcessStategyAdapt);
        BspRegistService(BSP_CMD_SET_RESET_TYPE_CAUSE, BspSetResetTypeCauseAdapt);
        BspRegistService(BSP_CMD_SET_CARR_ACTIVE_STATUS, BspSetCarrActiveStatusAdapt);
        BspRegistService(BSP_CMD_GET_POWON_STRATEGY, BspGetPowonStrategyAdapt);
        BspRegistService(BSP_CMD_SET_CARR_ANT_PORT_NUM, BspSetCarrAntPortNumAdapt);
        BspRegistService(BSP_CMD_SET_NTF_RSSI_SWITCH, BspSetNtfRssiSwitchAdapt);
        BspRegistService(BSP_CMD_SET_NTF_AVOID_FLAG, BspSetNtfAvoidFlagAdapt);
        BspRegistService(BSP_CMD_GET_SHARE_POWER_RISING_LEVEL, BspGetSharePowerRisingLevelAdapt);
        BspRegistService(BSP_CMD_GET_SHARE_POWER_TIME_GAP, BspGetSharePowerTimeGapAdapt);
        BspRegistService(BSP_CMD_RRU_LINK_PWR_OFF_CHK, BspRruLinkPwrOffChkAdapt);
        BspRegistService(BSP_CMD_RESET_DEVICE, BspResetDeviceAdapt);
        BspRegistService(BSP_CMD_RRU_LINK_BREAK_TIME_CLR, BspRruLinkBreakTimeClrAdapt);
        BspRegistService(BSP_CMD_BOARD_RESET, BspBoardResetAdapt);

        g_sFunccommonRegistFlag = ISREGIST;
    }
}

#include "funccommon_a_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "funccommon_a.h"

static UINT32 g_sFunccommon_aRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetDryContactStatusAdapt(UINT32 cmd, T_RruDryContactInfo *pInfo)
{
    return BspGetDryContactStatus(pInfo);
}

static UINT32 BspGetRadioStandardAdapt(UINT32 cmd)
{
    return BspGetRadioStandard();
}

static UINT32 BspIsClkSupportSwAdapt(UINT32 cmd)
{
    return BspIsClkSupportSw();
}

static UINT32 BspSetRadioStandardAdapt(UINT32 cmd, UINT32 stdRadio)
{
    return BspSetRadioStandard(stdRadio);
}

static UINT32 BspIsClkCauseUnLockAdapt(UINT32 cmd)
{
    return BspIsClkCauseUnLock();
}

/* UINT8->UINT32 */
static UINT32 BspGetCpuIdAdapt(UINT32 cmd)
{
    return BspGetCpuId();
}

static UINT32 BspIsMtsTransceiverAdapt(UINT32 cmd, UINT32 *uIsMtsTrans)
{
    return BspIsMtsTransceiver(uIsMtsTrans);
}

static UINT32 BspGetCurrClkTypeAdapt(UINT32 cmd)
{
    return BspGetCurrClkType();
}

static UINT32 BspSwClkTypeAdapt(UINT32 cmd, UINT32 type)
{
    return BspSwClkType(type);
}

static UINT32 BspIsPllFreqNormalAdapt(UINT32 cmd)
{
    return BspIsPllFreqNormal();
}

/* UINT16->UINT32 */
static UINT32 BspSubFrameNumGetAdapt(UINT32 cmd)
{
    return BspSubFrameNumGet();
}

/* UINT8->UINT32 */
static UINT32 BspGetCoreIdAdapt(UINT32 cmd)
{
    return BspGetCoreId();
}

static UINT32 BspGetDiskFreeAdapt(UINT32 cmd)
{
    return BspGetDiskFree();
}

static UINT32 BspGetFpgaMaxTempResultAdapt(UINT32 cmd, INT32 *lMaxTemp)
{
    return BspGetFpgaMaxTempResult(lMaxTemp);
}

static UINT32 BspCheckPllStatusAdapt(UINT32 cmd, OSS_ULONG ulDevId)
{
    return BspCheckPllStatus(ulDevId);
}

static UINT32 BspIsClkAllowSwAdapt(UINT32 cmd)
{
    return BspIsClkAllowSw();
}

static UINT32 BspGetRfTempByChanBandAdapt(UINT32 cmd, UINT32 ulChan, UINT32 ulBand, INT32 *pTemp)
{
    return BspGetRfTempByChanBand(ulChan, ulBand, pTemp);
}

static UINT32 BspGetDeviceStatusAdapt(UINT32 cmd, OSS_ULONG devId)
{
    return BspGetDeviceStatus(devId);
}

static UINT32 BspGetTxFaultFromMtsUnByChanAdapt(UINT32 cmd, UINT32 *uRegVal, UINT32 *uStatus)
{
    return BspGetTxFaultFromMtsUnByChan(uRegVal, uStatus);
}

static UINT32 BspIsPllUnLockAdapt(UINT32 cmd)
{
    return BspIsPllUnLock();
}

static UINT32 BspGetTxFaultFromMtsByChanAdapt(UINT32 cmd, UINT32 uChan, UINT32 *uRegVal, UINT32 *uStatus)
{
    return BspGetTxFaultFromMtsByChan(uChan, uRegVal, uStatus);
}

static UINT32 BspOptNetCfgSemPostAdapt(UINT32 cmd)
{
    return BspOptNetCfgSemPost();
}

static UINT32 BspGetOptNetCfgStatusAdapt(UINT32 cmd)
{
    return BspGetOptNetCfgStatus();
}

/* VOID->UINT32 */
static UINT32 BspSetFpgaReLoadFlagAdapt(UINT32 cmd, UINT32 fpgaLoadFlag)
{
    BspSetFpgaReLoadFlag(fpgaLoadFlag);
    return BSP_OK;
}

static UINT32 BspGetPhysAddrAdapt(UINT32 cmd, T_BSP_PHYSICAL_ADDR *ptHwAddr)
{
    return BspGetPhysAddr(ptHwAddr);
}

/* 返回值为结构体指针，转为出参*/
static UINT32 BspGetCfgInfoAdapt(UINT32 cmd, T_RruCfgInfo **rruCfgInfo)
{
    INPUT_POINTER_CHECK(rruCfgInfo);
    *rruCfgInfo = BspGetCfgInfo();
    return BSP_OK;
}

static UINT32 BspGetMch1IpAdapt(UINT32 cmd, UINT8 *pAddr)
{
    return BspGetMch1Ip(pAddr);
}

static UINT32 BspGetSerdesAndCpriStatusAdapt(UINT32 cmd, UINT32 *pSerdesCpriStatus)
{
    return BspGetSerdesAndCpriStatus(pSerdesCpriStatus);
}

static UINT32 BspGetMch2IpAdapt(UINT32 cmd, UINT8 *pAddr)
{
    return BspGetMch2Ip(pAddr);
}

static UINT32 BspGetRruIpAdapt(UINT32 cmd, UINT32 index)
{
    return BspGetRruIp(index);
}

static UINT32 BspGetFsIpAdapt(UINT32 cmd)
{
    return BspGetFsIp();
}

static UINT32 BspGetDataNetLinkStateAdapt(UINT32 cmd, UINT32 *pNetStatus)
{
    return BspGetDataNetLinkState(pNetStatus);
}

static UINT32 BspGetMchMasterAdapt(UINT32 cmd)
{
    return BspGetMchMaster();
}

static UINT32 BspDtiControlAdapt(UINT32 cmd, T_BSP_DEV_PARA *pPara)
{
    return BspDtiControl(pPara);
}

static UINT32 BSPGetHardIDAdapt(UINT32 cmd)
{
    return BSPGetHardID();
}

static UINT32 BspGetDiskTotalSizeAdapt(UINT32 cmd)
{
    return BspGetDiskTotalSize();
}

static UINT32 BspSetOptNetCfgStatusAdapt(UINT32 cmd, UINT32 optCfgStatus)
{
    return BspSetOptNetCfgStatus(optCfgStatus);
}

static UINT32 BspSetCfgInfoAdapt(UINT32 cmd, T_RruCfgInfo *pTRruCfgInfo)
{
    return BspSetCfgInfo(pTRruCfgInfo);
}

static UINT32 BspSetBootpInfoAdapt(UINT32 cmd, T_RruCfgInfo *pRruCfgInfo)
{
    return BspSetBootpInfo(pRruCfgInfo);
}

static UINT32 BspGetRootDirAdapt(UINT32 cmd, CHAR *pcDirBuf,UINT32 len)
{
    return BspGetRootDir(pcDirBuf, len);
}

static UINT32 BspOptNetCfgSemWaitAdapt(UINT32 cmd)
{
    return BspOptNetCfgSemWait();
}

static UINT32 BspGetHardIdAdapt(UINT32 cmd)
{
    return BspGetHardId();
}

static UINT32 BspGetBoardInitStatusAdapt(UINT32 cmd)
{
    return BspGetBoardInitStatus();
}

static UINT32 BspGetBbuUniqueIdAdapt(UINT32 cmd, UCHAR *uniqueId)
{
    return BspGetBbuUniqueId(uniqueId);
}

static UINT32 BspSetBbuUniqueIdAdapt(UINT32 cmd, UCHAR uniqueId, UCHAR secondSet)
{
    return BspSetBbuUniqueId(uniqueId, secondSet);
}

static UINT32 BspGetBbuUniqueIdExAdapt(UINT32 cmd, UCHAR *uniqueId,  UCHAR ucFunction)
{
    return BspGetBbuUniqueIdEx(uniqueId, ucFunction);
}

static UINT32 BspSetBbuUniqueIdExAdapt(UINT32 cmd, UCHAR uniqueIdInput, UCHAR secondSet, UCHAR ucFunction)
{
    return BspSetBbuUniqueIdEx(uniqueIdInput, secondSet, ucFunction);
}

static UINT32 BspSetAntiThefLockFlagAdapt(UINT32 cmd, UINT32 mode, UCHAR lockFlag)
{
    return BspSetAntiThefLockFlag(mode, lockFlag);
}

static UINT32 BspGetAntiThefLockFlagAdapt(UINT32 cmd, ULONG mode)
{
    return BspGetAntiThefLockFlag(mode);
}

__attribute((constructor)) void _funccommon_a_adapt_init_()
{
    if (NOTREGIST == g_sFunccommon_aRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_DRY_CONTACT_STATUS, BspGetDryContactStatusAdapt);
        BspRegistService(BSP_CMD_GET_RADIO_STANDARD, BspGetRadioStandardAdapt);
        BspRegistService(BSP_CMD_IS_CLK_SUPPORT_SW, BspIsClkSupportSwAdapt);
        BspRegistService(BSP_CMD_SET_RADIO_STANDARD, BspSetRadioStandardAdapt);
        BspRegistService(BSP_CMD_IS_CLK_CAUSE_UN_LOCK, BspIsClkCauseUnLockAdapt);
        BspRegistService(BSP_CMD_GET_CPU_ID, BspGetCpuIdAdapt);
        BspRegistService(BSP_CMD_IS_MTS_TRANSCEIVER, BspIsMtsTransceiverAdapt);
        BspRegistService(BSP_CMD_GET_CURR_CLK_TYPE, BspGetCurrClkTypeAdapt);
        BspRegistService(BSP_CMD_SW_CLK_TYPE, BspSwClkTypeAdapt);
        BspRegistService(BSP_CMD_IS_PLL_FREQ_NORMAL, BspIsPllFreqNormalAdapt);
        BspRegistService(BSP_CMD_SUB_FRAME_NUM_GET, BspSubFrameNumGetAdapt);
        BspRegistService(BSP_CMD_GET_CORE_ID, BspGetCoreIdAdapt);
        BspRegistService(BSP_CMD_GET_DISK_FREE, BspGetDiskFreeAdapt);
        BspRegistService(BSP_CMD_GET_FPGA_MAX_TEMP_RESULT, BspGetFpgaMaxTempResultAdapt);
        BspRegistService(BSP_CMD_CHECK_PLL_STATUS, BspCheckPllStatusAdapt);
        BspRegistService(BSP_CMD_IS_CLK_ALLOW_SW, BspIsClkAllowSwAdapt);
        BspRegistService(BSP_CMD_GET_RF_TEMP_BY_CHAN_BAND, BspGetRfTempByChanBandAdapt);
        BspRegistService(BSP_CMD_GET_DEVICE_STATUS, BspGetDeviceStatusAdapt);
        BspRegistService(BSP_CMD_GET_TX_FAULT_FROM_MTS_UN_BY_CHAN, BspGetTxFaultFromMtsUnByChanAdapt);
        BspRegistService(BSP_CMD_IS_PLL_UN_LOCK, BspIsPllUnLockAdapt);
        BspRegistService(BSP_CMD_GET_TX_FAULT_FROM_MTS_BY_CHAN, BspGetTxFaultFromMtsByChanAdapt);
        BspRegistService(BSP_CMD_OPT_NET_CFG_SEM_POST, BspOptNetCfgSemPostAdapt);
        BspRegistService(BSP_CMD_GET_OPT_NET_CFG_STATUS, BspGetOptNetCfgStatusAdapt);
        BspRegistService(BSP_CMD_SET_FPGA_RE_LOAD_FLAG, BspSetFpgaReLoadFlagAdapt);
        BspRegistService(BSP_CMD_GET_PHYS_ADDR, BspGetPhysAddrAdapt);
        BspRegistService(BSP_CMD_GET_CFG_INFO, BspGetCfgInfoAdapt);
        BspRegistService(BSP_CMD_GET_MCH1_IP, BspGetMch1IpAdapt);
        BspRegistService(BSP_CMD_GET_SERDES_AND_CPRI_STATUS, BspGetSerdesAndCpriStatusAdapt);
        BspRegistService(BSP_CMD_GET_MCH2_IP, BspGetMch2IpAdapt);
        BspRegistService(BSP_CMD_GET_RRU_IP, BspGetRruIpAdapt);
        BspRegistService(BSP_CMD_GET_FS_IP, BspGetFsIpAdapt);
        BspRegistService(BSP_CMD_GET_DATA_NET_LINK_STATE, BspGetDataNetLinkStateAdapt);
        BspRegistService(BSP_CMD_GET_MCH_MASTER, BspGetMchMasterAdapt);
        BspRegistService(BSP_CMD_DTI_CONTROL, BspDtiControlAdapt);
        BspRegistService(BSP_CMD_BSP_GET_HARD_ID, BSPGetHardIDAdapt);
        BspRegistService(BSP_CMD_GET_DISK_TOTAL_SIZE, BspGetDiskTotalSizeAdapt);
        BspRegistService(BSP_CMD_SET_OPT_NET_CFG_STATUS, BspSetOptNetCfgStatusAdapt);
        BspRegistService(BSP_CMD_SET_CFG_INFO, BspSetCfgInfoAdapt);
        BspRegistService(BSP_CMD_SET_BOOTP_INFO, BspSetBootpInfoAdapt);
        BspRegistService(BSP_CMD_GET_ROOT_DIR, BspGetRootDirAdapt);
        BspRegistService(BSP_CMD_OPT_NET_CFG_SEM_WAIT, BspOptNetCfgSemWaitAdapt);
        BspRegistService(BSP_CMD_GET_HARD_ID, BspGetHardIdAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_INIT_STATUS, BspGetBoardInitStatusAdapt);
        BspRegistService(BSP_CMD_GET_BBU_UNIQUE_ID, BspGetBbuUniqueIdAdapt);
        BspRegistService(BSP_CMD_SET_BBU_UNIQUE_ID, BspSetBbuUniqueIdAdapt);
        BspRegistService(BSP_CMD_GET_BBU_UNIQUE_ID_EX, BspGetBbuUniqueIdExAdapt);
        BspRegistService(BSP_CMD_SET_BBU_UNIQUE_ID_EX, BspSetBbuUniqueIdExAdapt);
        BspRegistService(BSP_CMD_SET_ANTI_THEF_LOCK_FLAG, BspSetAntiThefLockFlagAdapt);
        BspRegistService(BSP_CMD_GET_ANTI_THEF_LOCK_FLAG, BspGetAntiThefLockFlagAdapt);

        g_sFunccommon_aRegistFlag = ISREGIST;
    }
}

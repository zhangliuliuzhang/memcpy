#include "dpd_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "dpdapi.h"
#include "dpdcommon.h"

static UINT32 g_sDpd_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetOnlinePimPowerLevelAdapt(UINT32 cmd, UINT32 percent)
{
    return BspSetOnlinePimPowerLevel(percent);
}

static UINT32 BspSetPimDataAdapt(UINT32 cmd, T_PimOnline *pimOnlineData)
{
    return BspSetPimData(pimOnlineData);
}

static UINT32 BspGetOnlinePim2Adapt(UINT32 cmd, UINT32 rxchnNo, UINT32 *carrNum, T_PimOnlineReportItemDsp *pimOnlineItem)
{
    return BspGetOnlinePim2(rxchnNo, carrNum, pimOnlineItem);
}

static UINT32 BspSetOnlinePimModeAdapt(UINT32 cmd, UINT32 mode)
{
    return BspSetOnlinePimMode(mode);
}

static UINT32 BspSetOnlinePimDpdAdapt(UINT32 cmd, UINT32 clearLutFlag)
{
    return BspSetOnlinePimDpd(clearLutFlag);
}

static UINT32 BspIsSupportDpdVswrAdapt(UINT32 cmd, UINT32 chan)
{
    return BspIsSupportDpdVswr(chan);
}

static UINT32 BspGetDspVerStatusAdapt(UINT32 cmd)
{
    return BspGetDspVerStatus();
}

static UINT32 BspStartOnlinePim2Adapt(UINT32 cmd, UINT32 chan)
{
    return BspStartOnlinePim2(chan);
}

static UINT32 setWaitDspModeAdapt(UINT32 cmd, UINT32 wait_dsp_mode)
{
    return setWaitDspMode(wait_dsp_mode);
}

__attribute((constructor)) void _dpd_common_adapt_init_()
{
    if (NOTREGIST == g_sDpd_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_SET_ONLINE_PIM_POWER_LEVEL, BspSetOnlinePimPowerLevelAdapt);
        BspRegistService(BSP_CMD_SET_PIM_DATA, BspSetPimDataAdapt);
        BspRegistService(BSP_CMD_GET_ONLINE_PIM2, BspGetOnlinePim2Adapt);
        BspRegistService(BSP_CMD_SET_ONLINE_PIM_MODE, BspSetOnlinePimModeAdapt);
        BspRegistService(BSP_CMD_SET_ONLINE_PIM_DPD, BspSetOnlinePimDpdAdapt);
        BspRegistService(BSP_CMD_IS_SUPPORT_DPD_VSWR, BspIsSupportDpdVswrAdapt);
        BspRegistService(BSP_CMD_GET_DSP_VER_STATUS, BspGetDspVerStatusAdapt);
        BspRegistService(BSP_CMD_START_ONLINE_PIM2, BspStartOnlinePim2Adapt);
        BspRegistService(BSP_CMD_SET_WAIT_DSP_MODE, setWaitDspModeAdapt);

        g_sDpd_commonRegistFlag = ISREGIST;
    }
}

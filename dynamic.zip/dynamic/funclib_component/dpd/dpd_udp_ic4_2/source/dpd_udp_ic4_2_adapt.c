#include "dpd_udp_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "dpdapi.h"
#include "dpd_app.h"
#include "dsp_dbg.h"

static UINT32 g_sDpd_udp_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetAcStaAdapt(UINT32 cmd, UINT32 chan)
{
    return BspGetAcSta(chan);
}

static UINT32 BspDpdTsExpQueryAdapt(UINT32 cmd, T_DpdTsExpQueryResult *queryResult)
{
    return BspDpdTsExpQuery(queryResult);
}

static UINT32 BspGetDpdStatusAdapt(UINT32 cmd, UINT32 chan, UINT32 *status)
{
    return BspGetDpdStatus(chan, status);
}

static UINT32 BspGetPtsLmsStaAdapt(UINT32 cmd, T_DpdLmsStatusAck *lmsPtsStatus)
{
    return BspGetPtsLmsSta(lmsPtsStatus);
}

static UINT32 BspStartDpdAdapt(UINT32 cmd, UINT32 chan,UINT32 bandId)
{
    return BspStartDpd(chan, bandId);
}

static UINT32 BspNoiseCheckStartAdapt(UINT32 cmd, UINT32 slotindex)
{
    return BspNoiseCheckStart(slotindex);
}

static UINT32 BspGetOnlinePimAdapt(UINT32 cmd, UINT32 bspChn, UINT32 bandNo, INT32 *pimVal, INT32 *mutiPimVal, INT32 *noiseVal, UINT16 *rxPimFreq, UINT16 *rhoVal)
{
    return BspGetOnlinePim(bspChn, bandNo, pimVal, mutiPimVal, noiseVal, rxPimFreq, rhoVal);
}

static UINT32 BspInitDpdAdapt(UINT32 cmd, UINT32 Chan, UINT32 bandId)
{
    return BspInitDpd(Chan, bandId);
}

static UINT32 BspStartPtsLmsStartAdapt(UINT32 cmd)
{
    return BspStartPtsLmsStart();
}

static UINT32 BspGetPimOnlineRruInfoAdapt(UINT32 cmd, T_DpdPimOnlineHwRruInfo *PimOnlineRruInfo)
{
    return BspGetPimOnlineRruInfo(PimOnlineRruInfo);
}

static UINT32 acGetDpdStrAcDspAdapt(UINT32 cmd, UINT32 index, INT32 data0, INT32 data1, INT32 data2, INT32 data3)
{
    return acGetDpdStrAcDsp(index, data0, data1, data2, data3);
}

static UINT32 BspGetDpdLutDowmNumAdapt(UINT32 cmd, UINT32 chan, INT32 *pNum)
{
    return BspGetDpdLutDowmNum(chan, pNum);
}

static UINT32 BspGetNoiseCheckStaAdapt(UINT32 cmd, T_DpdDpdNoiseStaAck *pimOnlineNoiseCheckSta)
{
    return BspGetNoiseCheckSta(pimOnlineNoiseCheckSta);
}

static UINT32 BspDpdMsgPimDpdStartAdapt(UINT32 cmd, UINT32 chan)
{
    return BspDpdMsgPimDpdStart(chan);
}

static UINT32 BspMsgInsOnLineCalAdapt(UINT32 cmd, UINT32 uiBandWidth, UINT32 OnlineInsType, UINT32 uiSampleRate, UINT32 uMode)
{
    return BspMsgInsOnLineCal(uiBandWidth, OnlineInsType, uiSampleRate, uMode);
}

static UINT32 BspPimOnlineEnergyCalStartAdapt(UINT32 cmd, T_DpdPimOnlineEnergyCalCtrl *pimOnlineEngCalCtrl)
{
    return BspPimOnlineEnergyCalStart(pimOnlineEngCalCtrl);
}

static UINT32 BspGetDspCallChainAdapt(UINT32 cmd, UINT32 *pData)
{
    return BspGetDspCallChain(pData);
}

static UINT32 BspGetPimOnlineCheckStaAdapt(UINT32 cmd, UINT32 *PimOnlineCheckSta)
{
    return BspGetPimOnlineCheckSta(PimOnlineCheckSta);
}

static UINT32 acGetDpdStrAcDspInfoAdapt(UINT32 cmd, UINT32 index, INT32 data0, INT32 data1, UINT8 *pAcDspBufStr)
{
    return acGetDpdStrAcDspInfo(index, data0, data1, pAcDspBufStr);
}

static UINT32 BspStartAcCalcAdapt(UINT32 cmd, UINT32 chan)
{
    return BspStartAcCalc(chan);
}

static UINT32 BspGetVswrStaAdapt(UINT32 cmd, UINT32 chan, UINT32 acType)
{
    return BspGetVswrSta(chan, acType);
}

static UINT32 BspClearDpdAdapt(UINT32 cmd, UINT32 chan, UINT32 bandId)
{
    return BspClearDpd(chan, bandId);
}

static UINT32 BspSetDpdParaModeAdapt(UINT32 cmd, UINT32 chan, UINT32 bandId, INT32 modesel)
{
    return BspSetDpdParaMode(chan, bandId, modesel);
}

static UINT32 BspGetPimOnlineChkResultAdapt(UINT32 cmd, T_DpdPimOnlineCheckResultAck *pimOnlineCheckRes)
{
    return BspGetPimOnlineChkResult(pimOnlineCheckRes);
}

static UINT32 BspDpdTsQueryAdapt(UINT32 cmd, UINT32 para)
{
    return BspDpdTsQuery(para);
}

static UINT32 BspDpdSetPowAdjInfoAdapt(UINT32 cmd, UINT32 chan, UINT32 bandId)
{
    return BspDpdSetPowAdjInfo(chan, bandId);
}

static UINT32 BspStartOnlinePimAdapt(UINT32 cmd, UINT32 BspChn, UINT32 BandNo, UINT32 order, UINT32 Mode)
{
    return BspStartOnlinePim(BspChn, BandNo, order, Mode);
}

static UINT32 BspGetDpdPimStateAdapt(UINT32 cmd, UINT32 chan, UINT32 freqNo)
{
    return BspGetDpdPimState(chan, freqNo);
}

static UINT32 BspGetDpdFixDlyStatAdapt(UINT32 cmd, UINT32 chan)
{
    return BspGetDpdFixDlyStat(chan);
}

static UINT32 BspDpdMsgSetFrameSlotCfgAdapt(UINT32 cmd, UINT32 slotIndex, UINT32 gpNum)
{
    return BspDpdMsgSetFrameSlotCfg(slotIndex, gpNum);
}

static UINT32 BspStopDpdAdapt(UINT32 cmd, UINT32 chan, UINT32 bandId)
{
    return BspStopDpd(chan, bandId);
}

static UINT32 BspDpdTsCtrlAdapt(UINT32 cmd, UINT32 para, UINT32 ctrl, UINT32 gpNum)
{
    return BspDpdTsCtrl(para, ctrl, gpNum);
}

static UINT32 BspDpdUpdateRruInfoAdapt(UINT32 cmd, UINT32 exceptType, UINT32 exceptMask)
{
    return BspDpdUpdateRruInfo(exceptType, exceptMask);
}

__attribute((constructor)) void _dpd_udp_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sDpd_udp_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_GET_AC_STA, BspGetAcStaAdapt);
        BspRegistService(BSP_CMD_DPD_TS_EXP_QUERY, BspDpdTsExpQueryAdapt);
        BspRegistService(BSP_CMD_GET_DPD_STATUS, BspGetDpdStatusAdapt);
        BspRegistService(BSP_CMD_GET_PTS_LMS_STA, BspGetPtsLmsStaAdapt);
        BspRegistService(BSP_CMD_START_DPD, BspStartDpdAdapt);
        BspRegistService(BSP_CMD_NOISE_CHECK_START, BspNoiseCheckStartAdapt);
        BspRegistService(BSP_CMD_GET_ONLINE_PIM, BspGetOnlinePimAdapt);
        BspRegistService(BSP_CMD_INIT_DPD, BspInitDpdAdapt);
        BspRegistService(BSP_CMD_START_PTS_LMS_START, BspStartPtsLmsStartAdapt);
        BspRegistService(BSP_CMD_GET_PIM_ONLINE_RRU_INFO, BspGetPimOnlineRruInfoAdapt);
        BspRegistService(BSP_CMD_AC_GET_DPD_STR_AC_DSP, acGetDpdStrAcDspAdapt);
        BspRegistService(BSP_CMD_GET_DPD_LUT_DOWM_NUM, BspGetDpdLutDowmNumAdapt);
        BspRegistService(BSP_CMD_GET_NOISE_CHECK_STA, BspGetNoiseCheckStaAdapt);
        BspRegistService(BSP_CMD_DPD_MSG_PIM_DPD_START, BspDpdMsgPimDpdStartAdapt);
        BspRegistService(BSP_CMD_MSG_INS_ON_LINE_CAL, BspMsgInsOnLineCalAdapt);
        BspRegistService(BSP_CMD_PIM_ONLINE_ENERGY_CAL_START, BspPimOnlineEnergyCalStartAdapt);
        BspRegistService(BSP_CMD_GET_DSP_CALL_CHAIN, BspGetDspCallChainAdapt);
        BspRegistService(BSP_CMD_GET_PIM_ONLINE_CHECK_STA, BspGetPimOnlineCheckStaAdapt);
        BspRegistService(BSP_CMD_AC_GET_DPD_STR_AC_DSP_INFO, acGetDpdStrAcDspInfoAdapt);
        BspRegistService(BSP_CMD_START_AC_CALC, BspStartAcCalcAdapt);
        BspRegistService(BSP_CMD_GET_VSWR_STA, BspGetVswrStaAdapt);
        BspRegistService(BSP_CMD_CLEAR_DPD, BspClearDpdAdapt);
        BspRegistService(BSP_CMD_SET_DPD_PARA_MODE, BspSetDpdParaModeAdapt);
        BspRegistService(BSP_CMD_GET_PIM_ONLINE_CHK_RESULT, BspGetPimOnlineChkResultAdapt);
        BspRegistService(BSP_CMD_DPD_TS_QUERY, BspDpdTsQueryAdapt);
        BspRegistService(BSP_CMD_DPD_SET_POW_ADJ_INFO, BspDpdSetPowAdjInfoAdapt);
        BspRegistService(BSP_CMD_START_ONLINE_PIM, BspStartOnlinePimAdapt);
        BspRegistService(BSP_CMD_GET_DPD_PIM_STATE, BspGetDpdPimStateAdapt);
        BspRegistService(BSP_CMD_GET_DPD_FIX_DLY_STAT, BspGetDpdFixDlyStatAdapt);
        BspRegistService(BSP_CMD_DPD_MSG_SET_FRAME_SLOT_CFG, BspDpdMsgSetFrameSlotCfgAdapt);
        BspRegistService(BSP_CMD_STOP_DPD, BspStopDpdAdapt);
        BspRegistService(BSP_CMD_DPD_TS_CTRL, BspDpdTsCtrlAdapt);
        BspRegistService(BSP_CMD_DPD_UPDATE_RRU_INFO, BspDpdUpdateRruInfoAdapt);

        g_sDpd_udp_ic4_2RegistFlag = ISREGIST;
    }
}

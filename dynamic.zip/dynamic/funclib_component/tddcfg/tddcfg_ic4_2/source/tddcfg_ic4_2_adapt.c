#include "tddcfg_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "tddcfgapi.h"
#include "tddcfg_ic4_2_dbg.h"

static UINT32 g_sTddcfg_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetUlTddSelAdapt(UINT32 cmd, UINT32 bspChan)
{
    return BspSetUlTddSel(bspChan);
}

static UINT32 BspSetDlTddSelAdapt(UINT32 cmd, UINT32 bspChan)
{
    return BspSetDlTddSel(bspChan);
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 BspUpdateTddCfgAdapt(UINT32 cmd, UINT32 groupId)
{
    return BspUpdateTddCfg(groupId);
}

static UINT32 BspGetTddSwitchResultAdapt(UINT32 cmd, UINT32 groupId,UINT32 *result)
{
    return BspGetTddSwitchResult(groupId, result);
}

static UINT32 test_TddCfgAdapt(UINT32 cmd, UINT32 groupId, UINT32 radioMode, UINT32 chanMask)
{
    return test_TddCfg(groupId, radioMode, chanMask);
}
#endif

__attribute((constructor)) void _tddcfg_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sTddcfg_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_SET_UL_TDD_SEL, BspSetUlTddSelAdapt);
        BspRegistService(BSP_CMD_SET_DL_TDD_SEL, BspSetDlTddSelAdapt);

#ifdef DYNAMIC_API_TEST
        BspRegistService(BSP_CMD_UPDATE_TDD_CFG, BspUpdateTddCfgAdapt);
        BspRegistService(BSP_CMD_GET_TDD_SWITCH_RESULT, BspGetTddSwitchResultAdapt);
        BspRegistService(BSP_CMD_TEST__TDD_CFG, test_TddCfgAdapt);
#endif

        g_sTddcfg_ic4_2RegistFlag = ISREGIST;
    }
}

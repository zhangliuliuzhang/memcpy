#include "rruability_fdd_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "optctrlapi.h"
#include "rruability_fdd.h"

static UINT32 g_sRruability_fddRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetTopoCascadeNumAdapt(UINT32 cmd)
{
    return BspGetTopoCascadeNum();
}

static UINT32 BspGetDlDelayCmpAbilityAdapt(UINT32 cmd)
{
    return BspGetDlDelayCmpAbility();
}

static UINT32 BspGetFuRuIf1AbiltyAdapt(UINT32 cmd, VOID *pRruAbilityFuInfo, UINT32 dataLen)
{
    return BspGetFuRuIf1Abilty(pRruAbilityFuInfo, dataLen);
}

static UINT32 BspGetOptSpeedListAbilityAdapt(UINT32 cmd, T_OptSpeedList *ptSpeedList)
{
    return BspGetOptSpeedListAbility(ptSpeedList);
}

static UINT32 BspGetUlDelayCmpAbilityAdapt(UINT32 cmd)
{
    return BspGetUlDelayCmpAbility();
}

__attribute((constructor)) void _rruability_fdd_adapt_init_()
{
    if (NOTREGIST == g_sRruability_fddRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_TOPO_CASCADE_NUM, BspGetTopoCascadeNumAdapt);
        BspRegistService(BSP_CMD_GET_DL_DELAY_CMP_ABILITY, BspGetDlDelayCmpAbilityAdapt);
        BspRegistService(BSP_CMD_GET_FU_RU_IF1_ABILTY, BspGetFuRuIf1AbiltyAdapt);
        BspRegistService(BSP_CMD_GET_OPT_SPEED_LIST_ABILITY, BspGetOptSpeedListAbilityAdapt);
        BspRegistService(BSP_CMD_GET_UL_DELAY_CMP_ABILITY, BspGetUlDelayCmpAbilityAdapt);

        g_sRruability_fddRegistFlag = ISREGIST;
    }
}

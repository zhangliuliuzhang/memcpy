#include "rruability_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "rruabilityapi.h"

static UINT32 g_sRruability_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

/* 枚举T_RruForm->UINT32 */
static UINT32 BspGetRruFormAdapt(UINT32 cmd, UINT32 bandNo)
{
    return BspGetRruForm(bandNo);
}

static UINT32 BspGetRruAbilityInfoAdapt(UINT32 cmd, UINT32 fuIndex, VOID *pRruChlAbilityFuInfo, UINT32 dataLen)
{
    return BspGetRruAbilityInfo(fuIndex, pRruChlAbilityFuInfo, dataLen);
}

static UINT32 BspGetRruChlAbilityInfoAdapt(UINT32 cmd, BYTE chan, BYTE dir, UINT32 fuIndex, VOID *pRruChlAbilityFuInfo, UINT32 dataLen)
{
    return BspGetRruChlAbilityInfo(chan, dir, fuIndex, pRruChlAbilityFuInfo, dataLen);
}

__attribute((constructor)) void _rruability_common_adapt_init_()
{
    if (NOTREGIST == g_sRruability_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_RRU_FORM, BspGetRruFormAdapt);
        BspRegistService(BSP_CMD_GET_RRU_ABILITY_INFO, BspGetRruAbilityInfoAdapt);
        BspRegistService(BSP_CMD_GET_RRU_CHL_ABILITY_INFO, BspGetRruChlAbilityInfoAdapt);

        g_sRruability_commonRegistFlag = ISREGIST;
    }
}

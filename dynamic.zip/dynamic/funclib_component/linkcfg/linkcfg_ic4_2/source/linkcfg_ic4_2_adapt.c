#include "linkcfg_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "linkcfgapi.h"

static UINT32 g_sLinkcfg_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetGapSymbolNumAdapt(UINT32 cmd, UINT32 gapNum)
{
    return BspSetGapSymbolNum(gapNum);
}

static UINT32 BspSetRepeatPeriodAdapt(UINT32 cmd, UINT32 periodType)
{
    return BspSetRepeatPeriod(periodType);
}

static UINT32 BspSetCarrSwitchAdapt(UINT32 cmd, UINT32 chan, UINT32 radio, UINT32 carr, UINT32 trx, UINT32 isOn)
{
    return BspSetCarrSwitch(chan, radio, carr, trx, isOn);
}

static UINT32 BspSetSrsSymbolNumAdapt(UINT32 cmd, UINT32 srsNum)
{
    return BspSetSrsSymbolNum(srsNum);
}

__attribute((constructor)) void _linkcfg_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sLinkcfg_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_SET_GAP_SYMBOL_NUM, BspSetGapSymbolNumAdapt);
        BspRegistService(BSP_CMD_SET_REPEAT_PERIOD, BspSetRepeatPeriodAdapt);
        BspRegistService(BSP_CMD_SET_CARR_SWITCH, BspSetCarrSwitchAdapt);
        BspRegistService(BSP_CMD_SET_SRS_SYMBOL_NUM, BspSetSrsSymbolNumAdapt);

        g_sLinkcfg_ic4_2RegistFlag = ISREGIST;
    }
}

#include "linkcfg_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "linkcfgapi.h"

static UINT32 g_sLinkcfg_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetCarrSwitchAdapt(UINT32 cmd, UINT32 chan, UINT32 radio, UINT32 carr, UINT32 trx, UINT32 *isOn)
{
    return BspGetCarrSwitch(chan, radio, carr, trx, isOn);
}

static UINT32 BspSetRfFpgaBitmapAdapt(UINT32 cmd, UINT32 carrNo, UINT32 radioMode, UINT32 isON)
{
    return BspSetRfFpgaBitmap(carrNo, radioMode, isON);
}

static UINT32 BspSetFftaParaAdapt(UINT32 cmd, T_CellFftaPara *ptInfo)
{
    return BspSetFftaPara(ptInfo);
}

static UINT32 BspSetIfBbPrachParaAdapt(UINT32 cmd, T_IfBbPrachPara *ifBbPrachPara)
{
    return BspSetIfBbPrachPara(ifBbPrachPara);
}

static UINT32 BspSetIfBbPrachParaV2Adapt(UINT32 cmd, T_IfBbPrachParaV2 *ifBbPrachParaV2)
{
    return BspSetIfBbPrachParaV2(ifBbPrachParaV2);
}

static UINT32 BspSetErsScaleAdapt(UINT32 cmd, UINT32 ulCarrNo, INT32 lCellReRefPwr, UINT32 ulBandWith, UINT32 ulRbNum)
{
    return BspSetErsScale(ulCarrNo, lCellReRefPwr, ulBandWith, ulRbNum);
}

static UINT32 BspSetPrachParaAdapt(UINT32 cmd, T_CellPrachPara *ptInfo)
{
    return BspSetPrachPara(ptInfo);
}

__attribute((constructor)) void _linkcfg_common_adapt_init_()
{
    if (NOTREGIST == g_sLinkcfg_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_CARR_SWITCH, BspGetCarrSwitchAdapt);
        BspRegistService(BSP_CMD_SET_RF_FPGA_BITMAP, BspSetRfFpgaBitmapAdapt);
        BspRegistService(BSP_CMD_SET_FFTA_PARA, BspSetFftaParaAdapt);
        BspRegistService(BSP_CMD_SET_IF_BB_PRACH_PARA, BspSetIfBbPrachParaAdapt);
        BspRegistService(BSP_CMD_SET_IF_BB_PRACH_PARA_V2, BspSetIfBbPrachParaV2Adapt);
        BspRegistService(BSP_CMD_SET_ERS_SCALE, BspSetErsScaleAdapt);
        BspRegistService(BSP_CMD_SET_PRACH_PARA, BspSetPrachParaAdapt);

        g_sLinkcfg_commonRegistFlag = ISREGIST;
    }
}

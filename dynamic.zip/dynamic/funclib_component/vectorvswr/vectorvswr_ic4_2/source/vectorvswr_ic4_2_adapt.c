#include "vectorvswr_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "ru_univdef.h"
#include "vectorvswrcommon.h"
#include "vectorvswr_ic4_2.h"
#include "zprintf.h"

static UINT32 g_sVectorvswr_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetVswrTaoAdapt(UINT32 cmd, UINT32 ulTxChan, T_VswrTaoInfo *pVswrTao)
{
    return BspGetVswrTao(ulTxChan, pVswrTao);
}

static UINT32 BspStartOnlineVswrAdapt(UINT32 cmd, UINT32 rfChan, UINT32 bandId, T_VswrPosCalcPara *para)
{
    INPUT_POINTER_CHECK(para);
    return BspStartOnlineVswr(rfChan, bandId, *para);
}

static UINT32 BspGetOnlineVswrStatusAdapt(UINT32 cmd, UINT32 rfChan, UINT32 bandId, UINT32 *state)
{
    return BspGetOnlineVswrStatus(rfChan, bandId, state);
}

static UINT32 BspGetAveragePhaseAdapt(UINT32 cmd, UINT32 rfChan, UINT32 bandid, INT32 *value)
{
    return BspGetAveragePhase(rfChan, bandid, value);
}

__attribute((constructor)) void _vectorvswr_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sVectorvswr_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_GET_VSWR_TAO, BspGetVswrTaoAdapt);
        BspRegistService(BSP_CMD_START_ONLINE_VSWR, BspStartOnlineVswrAdapt);
        BspRegistService(BSP_CMD_GET_ONLINE_VSWR_STATUS, BspGetOnlineVswrStatusAdapt);
        BspRegistService(BSP_CMD_GET_AVERAGE_PHASE, BspGetAveragePhaseAdapt);

        g_sVectorvswr_ic4_2RegistFlag = ISREGIST;
    }
}

#include "powerctrl_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "powerctrlapi.h"
#include "powerctrl_ic4_2.h"
#include "powerctrl_comps_ic4_2.h"
#include "powerctrl_ic4_2_dbg.h"

static UINT32 g_sPowerctrl_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetFwdCpIfTssiAdapt(UINT32 cmd, UINT32 bspChn, UINT32 ulBand, INT32 *pFwdCpIfTssiDbm)
{
    return BspGetFwdCpIfTssi(bspChn, ulBand, pFwdCpIfTssiDbm);
}

static UINT32 BspGetTempGainCompsAdapt(UINT32 cmd, UINT32 chanNo, UINT32 type, INT32 *pComps)
{
    return BspGetTempGainComps(chanNo, type, pComps);
}

static UINT32 BspGetTxIfTssiAdapt(UINT32 cmd, UINT32 bspChn, UINT32 ulBand, INT32 *pTxIfTssiDbm)
{
    return BspGetTxIfTssi(bspChn, ulBand, pTxIfTssiDbm);
}

static UINT32 BspGetScalarVswrAdapt(UINT32 cmd, UINT32 chan, UINT32 *pVswrVal)
{
    return BspGetScalarVswr(chan, pVswrVal);
}

static UINT32 BspSetPowLevelAdapt(UINT32 cmd, UINT32 ulChan, UINT32 ulPowLevel)
{
    return BspSetPowLevel(ulChan, ulPowLevel);
}

/* void->UINT32*/
static UINT32 powshowAdapt(UINT32 cmd)
{
    powshow();
    return BSP_OK;
}

static UINT32 BspSetUmtsTxCarrPowAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrIdx, UINT32 carrdb)
{
    return BspSetUmtsTxCarrPow(bspChn, carrIdx, carrdb);
}

/* ULONG->UINT32 已改原型函数返回值*/
static UINT32 BspGetThresholdAdapt(UINT32 cmd, UINT32 chn, OSS_ULONG ulThresholdId, UINT32 *pulHighVal, UINT32 *pulLowVal)
{
    return BspGetThreshold(chn, ulThresholdId, pulHighVal, pulLowVal);
}

static UINT32 BspTxOpenLoopPowCailAdapt(UINT32 cmd, UINT32 chanNo)
{
    return BspTxOpenLoopPowCail(chanNo);
}

static UINT32 BspGetTempThresholdAdapt(UINT32 cmd, UINT32 ulChan, UINT32 ulThresholdId, INT32 *plWarning, INT32 *plResume)
{
    return BspGetTempThreshold(ulChan, ulThresholdId, plWarning, plResume);
}

static UINT32 BspSetNbicSwitchAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrNo, UINT32 sw)
{
    return BspSetNbicSwitch(bspChn, carrNo, sw);
}

static UINT32 BspGetTxOpenRlAdapt(UINT32 cmd, UINT32 Index, INT32 *pTxOpenRl)
{
    return BspGetTxOpenRl(Index, pTxOpenRl);
}

static UINT32 BspRxOpenLoopPowCailAdapt(UINT32 cmd, UINT32 chanNo)
{
    return BspRxOpenLoopPowCail(chanNo);
}

static UINT32 BspGetTxOpenLoopPwrDiffAdapt(UINT32 cmd, UINT32 chanNo, INT32* attVal)
{
    return BspGetTxOpenLoopPwrDiff(chanNo, attVal);
}

static UINT32 BspRxShutSwitchByCarrAdapt(UINT32 cmd, UINT32 uChn, UINT32 ulCarr, UINT32 uSwitch)
{
    return BspRxShutSwitchByCarr(uChn, ulCarr, uSwitch);
}

static UINT32 BspGetPaVswrValAdapt(UINT32 cmd, UINT32 ulChan, UINT32 ulFreqBand, UINT32 ulPaOrAntenaMode)
{
    return BspGetPaVswrVal(ulChan, ulFreqBand, ulPaOrAntenaMode);
}

static UINT32 BspAdpGetPwrVoltLimitDownAdapt(UINT32 cmd, UINT32 ulIndex, UINT32 *pVoltDown)
{
    return BspAdpGetPwrVoltLimitDown(ulIndex, pVoltDown);
}

static UINT32 BspSetRxAnfCfgAdapt(UINT32 cmd, T_RxAnfCfg *ptRxAnfCfg, UINT32 ulCount)
{
    return BspSetRxAnfCfg(ptRxAnfCfg, ulCount);
}

static UINT32 BspAdpGetPwrVoltLimitUpAdapt(UINT32 cmd, UINT32 ulIndex, UINT32 *pVoltUp)
{
    return BspAdpGetPwrVoltLimitUp(ulIndex, pVoltUp);
}

static UINT32 BspGetUmtsTxCarrPowAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrNo)
{
    return BspGetUmtsTxCarrPow(bspChn, carrNo);
}

static UINT32 BspTempParaUpdateAdapt(UINT32 cmd)
{
    return BspTempParaUpdate();
}

static UINT32 BspGetRssiPowAdapt(UINT32 cmd, UINT32 chan,UINT32 radio, UINT32 carr, INT32 *pBbPow)
{
    return BspGetRssiPow(chan, radio, carr, pBbPow);
}

static UINT32 BspFbOpenLoopPowCailAdapt(UINT32 cmd, UINT32 chanNo)
{
    return BspFbOpenLoopPowCail(chanNo);
}

static UINT32 BspGetTssiPowInfoAdapt(UINT32 cmd, UINT32 chan, UINT32 radio, UINT32 carr, INT32 *pTssiDbm, INT32 *pTssiDbfs)
{
    return BspGetTssiPowInfo(chan, radio, carr, pTssiDbm, pTssiDbfs);
}

static UINT32 BspGetTssiTcpwAdapt(UINT32 cmd, UINT32 chan, T_TxDualPow *fwd, T_TxDualPow *rev, UINT32 *num)
{
    return BspGetTssiTcpw(chan, fwd, rev, num);
}

static UINT32 BspSetTmaGainAdapt(UINT32 cmd, UINT32 uAntNo, UINT32 uTmaGain)
{
    return BspSetTmaGain(uAntNo, uTmaGain);
}

static UINT32 BspGetPaDefaultVoltAdapt(UINT32 cmd, UINT32 ulChan, UINT32 *pVolt)
{
    return BspGetPaDefaultVolt(ulChan, pVolt);
}

static UINT32 BspGetPaGainByVoltAdapt(UINT32 cmd, UINT32 ulChanSel, UINT32 ulBand, UINT32 ulPaVolt, UINT32 ulCfgPower, DOUBLE *pCfrPara, INT32 *ulPaGain)
{
    return BspGetPaGainByVolt(ulChanSel, ulBand, ulPaVolt, ulCfgPower, pCfrPara, ulPaGain);
}

static UINT32 BspGetPaVoltByCfgPowerAdapt(UINT32 cmd, UINT32 ulChanSel, UINT32 ulBand, UINT32 ulCfgPower, UINT32 ulVoltFlag, UINT32 *pVolt, DOUBLE *pCfrPara, INT32 *ulPaGain)
{
    return BspGetPaVoltByCfgPower(ulChanSel, ulBand, ulCfgPower, ulVoltFlag, pVolt, pCfrPara, ulPaGain);
}

static UINT32 BspSetTxCompCenterFreqAdapt(UINT32 cmd, UINT32 ulChan, UINT32 ulFreqBand, UINT32 ulFreq)
{
    return BspSetTxCompCenterFreq(ulChan, ulFreqBand, ulFreq);
}

static UINT32 BspGetBbTssiPowAdapt(UINT32 cmd, UINT32 chan, UINT32 radio, UINT32 carr, INT32 *pBbPow)
{
    return BspGetBbTssiPow(chan, radio, carr, pBbPow);
}

static UINT32 BspGetBoardTempAdapt(UINT32 cmd, UINT32 index, INT32 *pTemp)
{
    return BspGetBoardTemp(index, pTemp);
}

/* VOID->UINT32*/
static UINT32 rssiAdapt(UINT32 cmd, UINT32 rssiType)
{
    rssi(rssiType);
    return BSP_OK;
}

static UINT32 BspGetRevCpIfTssiAdapt(UINT32 cmd, UINT32 bspChn, UINT32 ulBand, INT32 *pRevCpIfTssiDbm)
{
    return BspGetRevCpIfTssi(bspChn, ulBand, pRevCpIfTssiDbm);
}

static UINT32 BspGetNbicSwitchAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrNo, UINT32 *sw)
{
    return BspGetNbicSwitch(bspChn, carrNo, sw);
}

static UINT32 BspGetTssiTcpwFlagAdapt(UINT32 cmd, UINT32 bspChn, UINT32 ulBand, T_TxDualPow *ptDualPow, UINT32 *ulValidFlag)
{
    return BspGetTssiTcpwFlag(bspChn, ulBand, ptDualPow, ulValidFlag);
}

static UINT32 BspTxCaliProcAdapt(UINT32 cmd, UINT32 TxRfGroup, UINT32 ulBand, INT32 lAttValue)
{
    return BspTxCaliProc(TxRfGroup, ulBand, lAttValue);
}

static UINT32 BspSetCarrPowAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode)
{
    return BspSetCarrPow(bspChn, carrIndex, carrPow, radioMode);
}

static UINT32 BspGetDl60msTagStateAdapt(UINT32 cmd, UINT32 bspChn)
{
    return BspGetDl60msTagState(bspChn);
}

static UINT32 BspSetCarrCfgPowAdapt(UINT32 cmd, UINT32 bspChn, UINT32 carrNo, UINT32 carrPow, UINT32 radioMode)
{
    return BspSetCarrCfgPow(bspChn, carrNo, carrPow, radioMode);
}

static UINT32 BspGetPaTempAdapt(UINT32 cmd, UINT32 bspChn, INT32 *patmp)
{
    return BspGetPaTemp(bspChn, patmp);
}

static UINT32 BspGetBbTssiTcpwAdapt(UINT32 cmd, UINT32 chan, UINT32 radio, UINT32 carr, INT32 *pTssi, INT32 *pTcpw)
{
    return BspGetBbTssiTcpw(chan, radio, carr, pTssi, pTcpw);
}

__attribute((constructor)) void _powerctrl_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sPowerctrl_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_GET_FWD_CP_IF_TSSI, BspGetFwdCpIfTssiAdapt);
        BspRegistService(BSP_CMD_GET_TEMP_GAIN_COMPS, BspGetTempGainCompsAdapt);
        BspRegistService(BSP_CMD_GET_TX_IF_TSSI, BspGetTxIfTssiAdapt);
        BspRegistService(BSP_CMD_GET_SCALAR_VSWR, BspGetScalarVswrAdapt);
        BspRegistService(BSP_CMD_SET_POW_LEVEL, BspSetPowLevelAdapt);
        BspRegistService(BSP_CMD_POWSHOW, powshowAdapt);
        BspRegistService(BSP_CMD_SET_UMTS_TX_CARR_POW, BspSetUmtsTxCarrPowAdapt);
        BspRegistService(BSP_CMD_GET_THRESHOLD, BspGetThresholdAdapt);
        BspRegistService(BSP_CMD_TX_OPEN_LOOP_POW_CAIL, BspTxOpenLoopPowCailAdapt);
        BspRegistService(BSP_CMD_GET_TEMP_THRESHOLD, BspGetTempThresholdAdapt);
        BspRegistService(BSP_CMD_SET_NBIC_SWITCH, BspSetNbicSwitchAdapt);
        BspRegistService(BSP_CMD_GET_TX_OPEN_RL, BspGetTxOpenRlAdapt);
        BspRegistService(BSP_CMD_RX_OPEN_LOOP_POW_CAIL, BspRxOpenLoopPowCailAdapt);
        BspRegistService(BSP_CMD_GET_TX_OPEN_LOOP_PWR_DIFF, BspGetTxOpenLoopPwrDiffAdapt);
        BspRegistService(BSP_CMD_RX_SHUT_SWITCH_BY_CARR, BspRxShutSwitchByCarrAdapt);
        BspRegistService(BSP_CMD_GET_PA_VSWR_VAL, BspGetPaVswrValAdapt);
        BspRegistService(BSP_CMD_ADP_GET_PWR_VOLT_LIMIT_DOWN, BspAdpGetPwrVoltLimitDownAdapt);
        BspRegistService(BSP_CMD_SET_RX_ANF_CFG, BspSetRxAnfCfgAdapt);
        BspRegistService(BSP_CMD_ADP_GET_PWR_VOLT_LIMIT_UP, BspAdpGetPwrVoltLimitUpAdapt);
        BspRegistService(BSP_CMD_GET_UMTS_TX_CARR_POW, BspGetUmtsTxCarrPowAdapt);
        BspRegistService(BSP_CMD_TEMP_PARA_UPDATE, BspTempParaUpdateAdapt);
        BspRegistService(BSP_CMD_GET_RSSI_POW, BspGetRssiPowAdapt);
        BspRegistService(BSP_CMD_FB_OPEN_LOOP_POW_CAIL, BspFbOpenLoopPowCailAdapt);
        BspRegistService(BSP_CMD_GET_TSSI_POW_INFO, BspGetTssiPowInfoAdapt);
        BspRegistService(BSP_CMD_GET_TSSI_TCPW, BspGetTssiTcpwAdapt);
        BspRegistService(BSP_CMD_SET_TMA_GAIN, BspSetTmaGainAdapt);
        BspRegistService(BSP_CMD_GET_PA_DEFAULT_VOLT, BspGetPaDefaultVoltAdapt);
        BspRegistService(BSP_CMD_GET_PA_GAIN_BY_VOLT, BspGetPaGainByVoltAdapt);
        BspRegistService(BSP_CMD_GET_PA_VOLT_BY_CFG_POWER, BspGetPaVoltByCfgPowerAdapt);
        BspRegistService(BSP_CMD_SET_TX_COMP_CENTER_FREQ, BspSetTxCompCenterFreqAdapt);
        BspRegistService(BSP_CMD_GET_BB_TSSI_POW, BspGetBbTssiPowAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_TEMP, BspGetBoardTempAdapt);
        BspRegistService(BSP_CMD_RSSI, rssiAdapt);
        BspRegistService(BSP_CMD_GET_REV_CP_IF_TSSI, BspGetRevCpIfTssiAdapt);
        BspRegistService(BSP_CMD_GET_NBIC_SWITCH, BspGetNbicSwitchAdapt);
        BspRegistService(BSP_CMD_GET_TSSI_TCPW_FLAG, BspGetTssiTcpwFlagAdapt);
        BspRegistService(BSP_CMD_TX_CALI_PROC, BspTxCaliProcAdapt);
        BspRegistService(BSP_CMD_SET_CARR_POW, BspSetCarrPowAdapt);
        BspRegistService(BSP_CMD_GET_DL60MS_TAG_STATE, BspGetDl60msTagStateAdapt);
        BspRegistService(BSP_CMD_SET_CARR_CFG_POW, BspSetCarrCfgPowAdapt);
        BspRegistService(BSP_CMD_GET_PA_TEMP, BspGetPaTempAdapt);
        BspRegistService(BSP_CMD_GET_BB_TSSI_TCPW, BspGetBbTssiTcpwAdapt);

        g_sPowerctrl_ic4_2RegistFlag = ISREGIST;
    }
}

#ifndef _WFS_IC4_2_ADAPT_H_INCLUDE_
#define _WFS_IC4_2_ADAPT_H_INCLUDE_


#endif

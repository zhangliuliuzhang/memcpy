#ifdef DYNAMIC_API_TEST
/* 这个文件原则上不对高层提供接口，这里全是调试使用 */
#include "wfs_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "wfs_ic4_2.h"

static UINT32 g_sWfs_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 Bsp_WfsAddCellInfoAdapt(UINT32 cmd, UINT32 cellId,UINT32 carrNo, UINT32 radioMode, UINT32 bandWidth, UINT32 txFreq, UINT32 rxFreq, UINT32 txChanMask,UINT32 rxChanMask)
{
    return Bsp_WfsAddCellInfo(cellId, carrNo, radioMode, bandWidth, txFreq, rxFreq, txChanMask, rxChanMask);
}

/* VOID->UINT32 */
static UINT32 Bsp_WfsCellBuildAdapt(UINT32 cmd, UINT32 antMask)
{
    Bsp_WfsCellBuild(antMask);
    return BSP_OK;
}

__attribute((constructor)) void _wfs_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sWfs_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD__WFS_ADD_CELL_INFO, Bsp_WfsAddCellInfoAdapt);
        BspRegistService(BSP_CMD__WFS_CELL_BUILD, Bsp_WfsCellBuildAdapt);

        g_sWfs_ic4_2RegistFlag = ISREGIST;
    }
}

#endif

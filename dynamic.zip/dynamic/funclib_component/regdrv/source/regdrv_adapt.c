#include "regdrv_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "zprintf.h"

static UINT32 g_sRegdrvRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

/* 返回ULONG类型地址，需大改造*/
static UINT32 BspGetReservedMemAddrAdapt(UINT32 cmd, UCHAR ucModuleId, ULONG *reservedMemAddr)
{
    INPUT_POINTER_CHECK(reservedMemAddr);
    *reservedMemAddr = BspGetReservedMemAddr(ucModuleId);
    return BSP_OK;
}

__attribute((constructor)) void _regdrv_adapt_init_()
{
    if (NOTREGIST == g_sRegdrvRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_RESERVED_MEM_ADDR, BspGetReservedMemAddrAdapt);

        g_sRegdrvRegistFlag = ISREGIST;
    }
}

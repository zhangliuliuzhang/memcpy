#include "operatingregister.h"
#include "sys/mman.h"
#include "fcntl.h"

#define IC_WR_MAP_MASK             (4096UL - 1)
#define MAP_SIZE 4096UL
#define MAP_MASK (MAP_SIZE - 1)
#define IC_WR_MAP_SIZE 4096UL

UINT32 IcHalRdIc(UINT32 addr)
{
    INT32 fd = 0;
    VOID *map_base = NULL;
    UCHAR *virt_addr = NULL;
    /* off_t target; */
    UINT32 cnt = 0;
    UINT32 val = 0;
    UINT32 numBytes = 0;
    UINT32 num = 1;
    if((fd = open("/dev/cachedmem", O_RDWR | O_SYNC)) == -1)
    {
        zte_printf_s("/dev/cachedmem opened.\n");
        return BSP_ERROR;
    }

    /* Map one page */
    map_base = mmap(0, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, addr & ~MAP_MASK);
    if(map_base == (void *) -1)
    {
        zte_printf_s("mmap error\n");
        close(fd);
        return BSP_ERROR;
    }

    addr = (0==(addr%4))?addr:(addr-addr%4);

    virt_addr = (UCHAR *)map_base + (addr & MAP_MASK);

    numBytes = 4*num;
    numBytes = (numBytes < (MAP_SIZE - (addr & MAP_MASK))) ? numBytes : (MAP_SIZE - (addr & MAP_MASK));
    num = numBytes/4;

    for(cnt=0; cnt<num; cnt++)
    {
        val = *((UINT32 *)virt_addr);
        if(cnt%4 == 0)
        {
            zte_printf_s("\n0x%08x:",addr);
        }
        zte_printf_s(" 0x%08x",val);
        virt_addr += 4;
        addr += 4;
    }

    zte_printf_s("\n");
    if(munmap(map_base, MAP_SIZE) == -1)
    {
        zte_printf_s("unmmap error\n");
        close(fd);
        return BSP_ERROR;
    }
    close(fd);

    return val;
}

UINT32 IcHalWrIc(UINT32 addr, UINT32 val)
{
    INT32 fd = 0;
    VOID *map_base = NULL;
    VOID *virt_addr = NULL;
    off_t target = 0;
    UINT32 cnt = 0;
    CHAR cmd[100] = {0};

    if ((fd = open("/dev/cachedmem", O_RDWR | O_SYNC)) == -1)
    {
        zte_printf_s("/dev/cachedmem opened.\n");
        return BSP_ERROR;
    }

    /* Map one page */
    map_base = mmap(0, IC_WR_MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, addr & ~IC_WR_MAP_MASK);
    if (map_base == (void *)-1)
    {
        zte_printf_s("mmap error\n");
        close(fd);
        return BSP_ERROR;
    }

    addr = (0 == (addr % 4)) ? addr : (addr - addr % 4);

    virt_addr = map_base + (addr & IC_WR_MAP_MASK);

    *((UINT32 *)virt_addr) = val;

    if (munmap(map_base, IC_WR_MAP_SIZE) == -1)
    {
        zte_printf_s("unmmap error\n");
        close(fd);
        return BSP_ERROR;
    }
    close(fd);

    return 0;
}
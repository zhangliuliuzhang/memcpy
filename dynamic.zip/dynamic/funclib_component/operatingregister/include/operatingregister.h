#ifndef _DOMEMMAP_H_INCLUDE_
#define _DOMEMMAP_H_INCLUDE_

#include "bsppub.h"

#ifdef __cplusplus 
extern "C" { 
#endif

UINT32 IcHalRdIc(UINT32 addr);
UINT32 IcHalWrIc(UINT32 addr, UINT32 val);

#ifdef __cplusplus
}
#endif

#endif




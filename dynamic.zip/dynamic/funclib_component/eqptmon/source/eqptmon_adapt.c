#include "eqptmon_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "eqptmonapi.h"

static UINT32 g_sEqptmonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspCheckLeakageWaterStateAdapt(UINT32 cmd)
{
    return BspCheckLeakageWaterState();
}

__attribute((constructor)) void _eqptmon_adapt_init_()
{
    if (NOTREGIST == g_sEqptmonRegistFlag)
    {
        BspRegistService(BSP_CMD_CHECK_LEAKAGE_WATER_STATE, BspCheckLeakageWaterStateAdapt);

        g_sEqptmonRegistFlag = ISREGIST;
    }
}

#include "boardmodle_ic42_onechip_rfctrl_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "bsppub.h"
#include "boardhardid.h"
#include "paapi.h"
#include "funccommonapi.h"

static UINT32 g_sBoardmodle_ic42_onechip_rfctrlRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetCaliFileAlarmedStringAdapt(UINT32 cmd, UINT32 *pulAlarmed, INT8 *pucCaliFileString)
{
    return BspGetCaliFileAlarmedString(pulAlarmed, pucCaliFileString);
}

static UINT32 BspGetRfFpgaMaxTempResultAdapt(UINT32 cmd, INT32 *lMaxTemp)
{
    return BspGetRfFpgaMaxTempResult(lMaxTemp);
}

static UINT32 BspGetDtxCounterAdapt(UINT32 cmd, UINT32 ulRfChnl, UINT32 *pDtxCounter)
{
    return BspGetDtxCounter(ulRfChnl, pDtxCounter);
}

static UINT32 BspStartAgcCtrlAdapt(UINT32 cmd)
{
    return BspStartAgcCtrl();
}

static UINT32 BspGetDtxChkAbilityAdapt(UINT32 cmd, UINT32 radioMode)
{
    return BspGetDtxChkAbility(radioMode);
}

static UINT32 BspGetDtxSwitchAdapt(UINT32 cmd, UINT32 bspChan, UINT32 *sw)
{
    return BspGetDtxSwitch(bspChan, sw);
}

static UINT32 BspClrDtxCounterAdapt(UINT32 cmd, UINT32 ulRfChnl)
{
    return BspClrDtxCounter(ulRfChnl);
}

static UINT32 BspSetDtxSwitchAdapt(UINT32 cmd, UINT32 bspChan, UINT32 on)
{
    return BspSetDtxSwitch(bspChan, on);
}

static VOID BspSlaveBoardHwResetAdapt(UINT32 cmd, UINT32 index)
{
    BspSlaveBoardHwReset(index);
    return BSP_OK;
}

static UINT32 BspGetModuleGroupIdParaAdapt(UINT32 cmd)
{
    return BspGetModuleGroupIdPara();
}

static UINT32 BspGetBoardGroupIdParaAdapt(UINT32 cmd)
{
    return BspGetBoardGroupIdPara();
}

static UINT32 BspGetBoardTypeIdParaAdapt(UINT32 cmd)
{
    return BspGetBoardTypeIdPara();
}

static UINT32 BspGetHardwareChangeIdParaAdapt(UINT32 cmd)
{
    return BspGetHardwareChangeIdPara();
}

static UINT32 BspGetReservedMemSizeAdapt(UINT32 cmd, UINT8 moduleId)
{
    return BspGetReservedMemSize(moduleId);
}

static UINT32 BspGetBoardResetTypeAdapt(UINT32 cmd)
{
    return BspGetBoardResetType();
}

__attribute((constructor)) void _boardmodle_ic42_onechip_rfctrl_adapt_init_()
{
    if (NOTREGIST == g_sBoardmodle_ic42_onechip_rfctrlRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_CALI_FILE_ALARMED_STRING, BspGetCaliFileAlarmedStringAdapt);
        BspRegistService(BSP_CMD_GET_RF_FPGA_MAX_TEMP_RESULT, BspGetRfFpgaMaxTempResultAdapt);
        BspRegistService(BSP_CMD_GET_DTX_COUNTER, BspGetDtxCounterAdapt);
        BspRegistService(BSP_CMD_START_AGC_CTRL, BspStartAgcCtrlAdapt);
        BspRegistService(BSP_CMD_GET_DTX_CHK_ABILITY, BspGetDtxChkAbilityAdapt);
        BspRegistService(BSP_CMD_GET_DTX_SWITCH, BspGetDtxSwitchAdapt);
        BspRegistService(BSP_CMD_CLR_DTX_COUNTER, BspClrDtxCounterAdapt);
        BspRegistService(BSP_CMD_SET_DTX_SWITCH, BspSetDtxSwitchAdapt);
        BspRegistService(BSP_CMD_SLAVE_BOARD_HW_RESET, BspSlaveBoardHwResetAdapt);
        BspRegistService(BSP_CMD_GET_MODULE_GROUP_ID_PARA, BspGetModuleGroupIdParaAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_GROUP_ID_PARA, BspGetBoardGroupIdParaAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_TYPE_ID_PARA, BspGetBoardTypeIdParaAdapt);
        BspRegistService(BSP_CMD_GET_HARDWARE_CHANGE_ID_PARA, BspGetHardwareChangeIdParaAdapt);
        BspRegistService(BSP_CMD_GET_RESERVED_MEM_SIZE, BspGetReservedMemSizeAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_RESET_TYPE, BspGetBoardResetTypeAdapt);

        g_sBoardmodle_ic42_onechip_rfctrlRegistFlag = ISREGIST;
    }
}

#include "boardmodle_ic42_onechip_vermanage_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "bsppub.h"
#include "boardhardid.h"
#include "softservicewrappervermanage.h"

static UINT32 g_sBoardmodle_ic42_onechip_vermanageRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetModuleGroupIdParaAdapt(UINT32 cmd)
{
    return BspGetModuleGroupIdPara();
}

static UINT32 BspGetBoardGroupIdParaAdapt(UINT32 cmd)
{
    return BspGetBoardGroupIdPara();
}

static UINT32 BspGetBoardTypeIdParaAdapt(UINT32 cmd)
{
    return BspGetBoardTypeIdPara();
}

static UINT32 BspGetHardwareChangeIdParaAdapt(UINT32 cmd)
{
    return BspGetHardwareChangeIdPara();
}

static UINT32 BspGetReservedMemSizeAdapt(UINT32 cmd, UINT8 moduleId)
{
    return BspGetReservedMemSize(moduleId);
}

static UINT32 BspCfgSecVerifyFunAdapt(UINT32 cmd)
{
    return BspCfgSecVerifyFun();
}

static UINT32 BspGetCpuTypeAdapt(UINT32 cmd, UINT8 *cpuType)
{
    return BspGetCpuType(cpuType);
}

__attribute((constructor)) void _boardmodle_ic42_onechip_vermanage_adapt_init_()
{
    if (NOTREGIST == g_sBoardmodle_ic42_onechip_vermanageRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_MODULE_GROUP_ID_PARA, BspGetModuleGroupIdParaAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_GROUP_ID_PARA, BspGetBoardGroupIdParaAdapt);
        BspRegistService(BSP_CMD_GET_BOARD_TYPE_ID_PARA, BspGetBoardTypeIdParaAdapt);
        BspRegistService(BSP_CMD_GET_HARDWARE_CHANGE_ID_PARA, BspGetHardwareChangeIdParaAdapt);
        BspRegistService(BSP_CMD_GET_RESERVED_MEM_SIZE, BspGetReservedMemSizeAdapt);
        BspRegistService(BSP_CMD_CFG_SEC_VERIFY_FUN, BspCfgSecVerifyFunAdapt);
        BspRegistService(BSP_CMD_GET_CPU_TYPE, BspGetCpuTypeAdapt);

        g_sBoardmodle_ic42_onechip_vermanageRegistFlag = ISREGIST;
    }
}

#include "optctrl_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "optctrlapi.h"

static UINT32 g_sOptctrl_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetOptEthNameAdapt(UINT32 cmd, UINT32 rruOpt, CHAR *ethName, UINT32 ethNameSize)
{
    return BspGetOptEthName(rruOpt, ethName, ethNameSize);
}

__attribute((constructor)) void _optctrl_common_adapt_init_()
{
    if (NOTREGIST == g_sOptctrl_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_OPT_ETH_NAME, BspGetOptEthNameAdapt);

        g_sOptctrl_commonRegistFlag = ISREGIST;
    }
}

#include "optctrl_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "optctrlapi.h"
#include "optctrl_pre_alloc.h"
#include "iqcfgapi.h"
#include "optctrl_inter_def.h"

static UINT32 g_sOptctrl_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspOptCellInfoInitAdapt(UINT32 cmd, T_CellCfgInfo *pPara)
{
    return BspOptCellInfoInit(pPara);
}

static UINT32 BspFftWinSetAdapt(UINT32 cmd, UINT32 uCellId, UINT32 uWinMode, UINT32 uTblIndex)
{
    return BspFftWinSet(uCellId, uWinMode, uTblIndex);
}

static UINT32 BspOptIqSlaveCfgAdapt(UINT32 cmd, UINT32 uCfgNum, T_IQRecord_Slave *pPara)
{
    return BspOptIqSlaveCfg(uCfgNum, pPara);
}

static UINT32 BspGetSfpTempAdapt(UINT32 cmd, UINT32 sfpId, INT32 *pTemp)
{
    return BspGetSfpTemp(sfpId, pTemp);
}

static UINT32 BspSaveOptSpeedFromAppAdapt(UINT32 cmd, UINT32 ulLogicOpt, UINT32 ulCpriRate)
{
    return BspSaveOptSpeedFromApp(ulLogicOpt, ulCpriRate);
}

static UINT32 BspGetBbuFiberPortAdapt(UINT32 cmd, UINT32 ruOptPort)
{
    return BspGetBbuFiberPort(ruOptPort);
}

static UINT32 BspOptL1CellPrachInfoInitAdapt(UINT32 cmd, UINT32 uRachNum, T_PrachCellInfo *pPara)
{
    return BspOptL1CellPrachInfoInit(uRachNum, pPara);
}

static UINT32 BspGetLogicOptByMsOptAdapt(UINT32 cmd, UINT32 *uUpLinkLogicOpt, UINT32 *uDownLinkLogicOpt)
{
    return BspGetLogicOptByMsOpt(uUpLinkLogicOpt, uDownLinkLogicOpt);
}

static UINT32 BspGetBbuShelfIndexAdapt(UINT32 cmd, UINT32 optIndex)
{
    return BspGetBbuShelfIndex(optIndex);
}

static UINT32 BspSetCsirsPortAntMapAdapt(UINT32 cmd, T_CsirsPortAntMap *csirsPortAntMap)
{
    return BspSetCsirsPortAntMap(csirsPortAntMap);
}

static UINT32 BspOamCellPreAllocAdapt(UINT32 cmd, T_DestCarrInfoAllChans* cfgInfo, T_PreAllocResult* preAllocResult)
{
    return BspOamCellPreAlloc(cfgInfo, preAllocResult);
}

static UINT32 BspGetOptStatusAdapt(UINT32 cmd, UINT32 optId)
{
    return BspGetOptStatus(optId);
}

static UINT32 BspClrAllPreAllocSourceAdapt(UINT32 cmd)
{
    return BspClrAllPreAllocSource();
}

static UINT32 BspGetOptBerAdapt(UINT32 cmd, UINT32 optIndex, UINT32 *pValue)
{
    return BspGetOptBer(optIndex, pValue);
}

static UINT32 BspSetOptTxDisableAdapt(UINT32 cmd, UINT32 ulIndex, UINT32 ulHighFlag)
{
    return BspSetOptTxDisable(ulIndex, ulHighFlag);
}

static UINT32 BspOptIqInfoCfgAdapt(UINT32 cmd, UINT32 uCfgNum, T_IQRecord_TDD *pPara)
{
    return BspOptIqInfoCfg(uCfgNum, pPara);
}

static UINT32 BspOamPreAllocReMapAdapt(UINT32 cmd, UINT32 preAllocRet)
{
    return BspOamPreAllocReMap(preAllocRet);
}

static UINT32 BspOptSetFFTParaAdapt(UINT32 cmd, UINT32 uCellId, UINT32 uDir, UINT32 uScs, T_FFTAParam *pPara)
{
    return BspOptSetFFTPara(uCellId, uDir, uScs, pPara);
}

static UINT32 BspOptCellInfoCfgAdapt(UINT32 cmd, UINT32 uCellIdx)
{
    return BspOptCellInfoCfg(uCellIdx);
}

static UINT32 BspIqCfgInitAdapt(UINT32 cmd)
{
    return BspIqCfgInit();
}

static UINT32 BspSetOptWorkModeAdapt(UINT32 cmd, UINT32 optMode)
{
    return BspSetOptWorkMode(optMode);
}

static UINT32 BspClrPreAllocAdapt(UINT32 cmd)
{
    return BspClrPreAlloc();
}

static UINT32 BspSetRfTestSwitchAdapt(UINT32 cmd, UINT32 carrNo, UINT32 radioMode, UINT32 sw)
{
    return BspSetRfTestSwitch(carrNo, radioMode, sw);
}

static UINT32 BspSetPhaCompParaAdapt(UINT32 cmd, UINT32 uCellId, UINT32 uDir, UINT32 uFreq)
{
    return BspSetPhaCompPara(uCellId, uDir, uFreq);
}

static UINT32 BspClrOptSpdChgRecordAdapt(UINT32 cmd)
{
    return BspClrOptSpdChgRecord();
}

static UINT32 BspGetOptSpdChgRecordAdapt(UINT32 cmd)
{
    return BspGetOptSpdChgRecord();
}

static UINT32 BspGetSwitchMainPhyOptFlagAdapt(UINT32 cmd)
{
    return BspGetSwitchMainPhyOptFlag();
}

static UINT32 BspGetOptSpeedAdapt(UINT32 cmd, UINT32 ulIndex)
{
    return BspGetOptSpeed(ulIndex);
}

static UINT32 BspGetCurrentFiberPortAdapt(UINT32 cmd)
{
    return BspGetCurrentFiberPort();
}

static UINT32 BspGetSfpStatusAdapt(UINT32 cmd, UINT32 sfpId)
{
    return BspGetSfpStatus(sfpId);
}

static UINT32 BspGetOptCntAdapt(UINT32 cmd, UINT32 ulType)
{
    return BspGetOptCnt(ulType);
}

static UINT32 BspGetRruIdAdapt(UINT32 cmd, UINT32 ulIndex)
{
    return BspGetRruId(ulIndex);
}

__attribute((constructor)) void _optctrl_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sOptctrl_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_OPT_CELL_INFO_INIT, BspOptCellInfoInitAdapt);
        BspRegistService(BSP_CMD_FFT_WIN_SET, BspFftWinSetAdapt);
        BspRegistService(BSP_CMD_OPT_IQ_SLAVE_CFG, BspOptIqSlaveCfgAdapt);
        BspRegistService(BSP_CMD_GET_SFP_TEMP, BspGetSfpTempAdapt);
        BspRegistService(BSP_CMD_SAVE_OPT_SPEED_FROM_APP, BspSaveOptSpeedFromAppAdapt);
        BspRegistService(BSP_CMD_GET_BBU_FIBER_PORT, BspGetBbuFiberPortAdapt);
        BspRegistService(BSP_CMD_OPT_L1_CELL_PRACH_INFO_INIT, BspOptL1CellPrachInfoInitAdapt);
        BspRegistService(BSP_CMD_GET_LOGIC_OPT_BY_MS_OPT, BspGetLogicOptByMsOptAdapt);
        BspRegistService(BSP_CMD_GET_BBU_SHELF_INDEX, BspGetBbuShelfIndexAdapt);
        BspRegistService(BSP_CMD_SET_CSIRS_PORT_ANT_MAP, BspSetCsirsPortAntMapAdapt);
        BspRegistService(BSP_CMD_OAM_CELL_PRE_ALLOC, BspOamCellPreAllocAdapt);
        BspRegistService(BSP_CMD_GET_OPT_STATUS, BspGetOptStatusAdapt);
        BspRegistService(BSP_CMD_CLR_ALL_PRE_ALLOC_SOURCE, BspClrAllPreAllocSourceAdapt);
        BspRegistService(BSP_CMD_GET_OPT_BER, BspGetOptBerAdapt);
        BspRegistService(BSP_CMD_SET_OPT_TX_DISABLE, BspSetOptTxDisableAdapt);
        BspRegistService(BSP_CMD_OPT_IQ_INFO_CFG, BspOptIqInfoCfgAdapt);
        BspRegistService(BSP_CMD_OAM_PRE_ALLOC_RE_MAP, BspOamPreAllocReMapAdapt);
        BspRegistService(BSP_CMD_OPT_SET_FFT_PARA, BspOptSetFFTParaAdapt);
        BspRegistService(BSP_CMD_OPT_CELL_INFO_CFG, BspOptCellInfoCfgAdapt);
        BspRegistService(BSP_CMD_IQ_CFG_INIT, BspIqCfgInitAdapt);
        BspRegistService(BSP_CMD_SET_OPT_WORK_MODE, BspSetOptWorkModeAdapt);
        BspRegistService(BSP_CMD_CLR_PRE_ALLOC, BspClrPreAllocAdapt);
        BspRegistService(BSP_CMD_SET_RF_TEST_SWITCH, BspSetRfTestSwitchAdapt);
        BspRegistService(BSP_CMD_SET_PHA_COMP_PARA, BspSetPhaCompParaAdapt);
        BspRegistService(BSP_CMD_CLR_OPT_SPD_CHG_RECORD, BspClrOptSpdChgRecordAdapt);
        BspRegistService(BSP_CMD_GET_OPT_SPD_CHG_RECORD, BspGetOptSpdChgRecordAdapt);
        BspRegistService(BSP_CMD_GET_SWITCH_MAIN_PHY_OPT_FLAG, BspGetSwitchMainPhyOptFlagAdapt);
        BspRegistService(BSP_CMD_GET_OPT_SPEED, BspGetOptSpeedAdapt);
        BspRegistService(BSP_CMD_GET_CURRENT_FIBER_PORT, BspGetCurrentFiberPortAdapt);
        BspRegistService(BSP_CMD_GET_SFP_STATUS, BspGetSfpStatusAdapt);
        BspRegistService(BSP_CMD_GET_OPT_CNT, BspGetOptCntAdapt);
        BspRegistService(BSP_CMD_GET_RRU_ID, BspGetRruIdAdapt);

        g_sOptctrl_ic4_2RegistFlag = ISREGIST;
    }
}

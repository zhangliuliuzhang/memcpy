#include "hotpatchmsg_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "dpdapi.h"

static UINT32 g_sHotpatchmsgRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspLoadAcHpAdapt(UINT32 cmd, UINT32 ctrl)
{
    return BspLoadAcHp(ctrl);
}

static UINT32 BspLoadDspHpAdapt(UINT32 cmd, UINT32 ctrl)
{
    return BspLoadDspHp(ctrl);
}

__attribute((constructor)) void _hotpatchmsg_adapt_init_()
{
    if (NOTREGIST == g_sHotpatchmsgRegistFlag)
    {
        BspRegistService(BSP_CMD_LOAD_AC_HP, BspLoadAcHpAdapt);
        BspRegistService(BSP_CMD_LOAD_DSP_HP, BspLoadDspHpAdapt);

        g_sHotpatchmsgRegistFlag = ISREGIST;
    }
}

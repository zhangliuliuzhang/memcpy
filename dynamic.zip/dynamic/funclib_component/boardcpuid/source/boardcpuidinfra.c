
#include "boardcpuidinfra.h"
#include "operatingregister.h"
#include "zte_slibc.h"
#include <sys/socket.h>
#include <linux/if.h>

UINT32 BspHalAdaptGetIcChipId(UINT32 *pChipIdx)
{
    UCHAR *pBaseAddr = NULL;
    UINT32 ulRpuId = 0;
    UCHAR *pAddr = NULL;

    INPUT_POINTER_CHECK(pChipIdx);

    ulRpuId = IcHalRdIc(0xD4C00160);
    *pChipIdx = (ulRpuId & 0x7);

    return BSP_OK;
}

VOID BspSetBoardIcChipIndex(UINT8 idx)
{
    return;
}

int netif_get_ip(const char *ifname, unsigned char *ipaddr)
{
    int fd;
    struct ifreq ifr;

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (-1 == fd)
    {
        dbgErr("netif_get_ip Error:Can not create a socket!\n");
        return -1;
    }
    strncpy_s(ifr.ifr_name, sizeof(ifr.ifr_name), ifname, IFNAMSIZ - 1);
    ifr.ifr_name[IFNAMSIZ - 1] = '\0';/*coverity 修改*/
    ifr.ifr_addr.sa_family = AF_INET;

    if (ioctl(fd, SIOCGIFADDR, &ifr) < 0)
    {
        dbgErr("ioctl SIOCGIFADDR:");
        close(fd);
        return -1;
    }
    close(fd);
    bcopy(&ifr.ifr_addr.sa_data[2], ipaddr, sizeof(struct in_addr));

    return 0;
}

UINT32 BspGetIp(const char *eth, unsigned char *ip)
{
    if(NULL == eth)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }
    if(NULL == ip)
    {
        dbgErr("null pointer err\n");
        return BSP_ERROR_NULL_POINTER;
    }

    if(netif_get_ip(eth, ip))
    {
        dbgErr("netif_get_ip err\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspSetCpuId(UINT32 id)
{
    return BSP_OK;
}

UINT32 BspSetCoreId(UINT32 id)
{
    return BSP_OK;
}






#ifndef _BOARDCPUID_INFRA_H_
#define _BOARDCPUID_INFRA_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

#define dbgErr zte_printf_s
#define dbgInfoEx zte_printf_s
#define dbgInfo zte_printf_s

UINT32 BspHalAdaptGetIcChipId(UINT32 *pChipIdx);
VOID BspSetBoardIcChipIndex(UINT8 idx);
UINT32 BspGetIp(const char *eth, unsigned char *ip);
UINT32 BspSetCpuId(UINT32 id);
UINT32 BspSetCoreId(UINT32 id);


#ifdef __cplusplus
}
#endif

#endif

#include "gainctrl_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "gainctrl_ic4_2.h"

static UINT32 g_sGainctrl_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspSetKdGainAdapt(UINT32 cmd, UINT32 bspChn, INT32 gain)
{
    return BspSetKdGain(bspChn, gain);
}

static UINT32 BspSetMixGainAdapt(UINT32 cmd, UINT32 chan, UINT32 band, INT32 gain)
{
    return BspSetMixGain(chan, band, gain);
}

static UINT32 BspGetTxPcGainAdapt(UINT32 cmd, UINT32 chan, UINT32 carr, UINT32 radioMode, INT32 *pGain)
{
    return BspGetTxPcGain(chan, carr, radioMode, pGain);
}

static UINT32 BspGetKdGainAdapt(UINT32 cmd, UINT32 chan, INT32 *pGain)
{
    return BspGetKdGain(chan, pGain);
}

static UINT32 BspGetTxCarrGainAdapt(UINT32 cmd, UINT32 ulBspChnl, UINT32 ulPhyCarr, INT32 *plCarrGain)
{
    return BspGetTxCarrGain(ulBspChnl, ulPhyCarr, plCarrGain);
}

static UINT32 BspSetTxPcGainAdapt(UINT32 cmd, UINT32 chan, UINT32 carr, UINT32 radioMode, INT32 gain)
{
    return BspSetTxPcGain(chan, carr, radioMode, gain);
}

static UINT32 BspGetKnGainMaxAdapt(UINT32 cmd, UINT32 chan, INT32 *pGain)
{
    return BspGetKnGainMax(chan, pGain);
}

__attribute((constructor)) void _gainctrl_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sGainctrl_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_SET_KD_GAIN, BspSetKdGainAdapt);
        BspRegistService(BSP_CMD_SET_MIX_GAIN, BspSetMixGainAdapt);
        BspRegistService(BSP_CMD_GET_TX_PC_GAIN, BspGetTxPcGainAdapt);
        BspRegistService(BSP_CMD_GET_KD_GAIN, BspGetKdGainAdapt);
        BspRegistService(BSP_CMD_GET_TX_CARR_GAIN, BspGetTxCarrGainAdapt);
        BspRegistService(BSP_CMD_SET_TX_PC_GAIN, BspSetTxPcGainAdapt);
        BspRegistService(BSP_CMD_GET_KN_GAIN_MAX, BspGetKnGainMaxAdapt);

        g_sGainctrl_ic4_2RegistFlag = ISREGIST;
    }
}

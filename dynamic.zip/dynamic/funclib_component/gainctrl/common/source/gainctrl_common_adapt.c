#include "gainctrl_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "gainctrlcommon.h"

static UINT32 g_sGainctrl_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetTxGainMaxAdapt(UINT32 cmd, UINT32 chan, INT32 *pGain)
{
    return BspGetTxGainMax(chan, pGain);
}

static UINT32 BspGetTxGainAdapt(UINT32 cmd, UINT32 chn, INT32 *pVal)
{
    return BspGetTxGain(chn, pVal);
}

static UINT32 BspGetTxGainMinAdapt(UINT32 cmd, UINT32 chan, INT32 *pGain)
{
    return BspGetTxGainMin(chan, pGain);
}

static UINT32 BspSetTxGainAdapt(UINT32 cmd, UINT32 chn, INT32 val)
{
    return BspSetTxGain(chn, val);
}

__attribute((constructor)) void _gainctrl_common_adapt_init_()
{
    if (NOTREGIST == g_sGainctrl_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_TX_GAIN_MAX, BspGetTxGainMaxAdapt);
        BspRegistService(BSP_CMD_GET_TX_GAIN, BspGetTxGainAdapt);
        BspRegistService(BSP_CMD_GET_TX_GAIN_MIN, BspGetTxGainMinAdapt);
        BspRegistService(BSP_CMD_SET_TX_GAIN, BspSetTxGainAdapt);

        g_sGainctrl_commonRegistFlag = ISREGIST;
    }
}

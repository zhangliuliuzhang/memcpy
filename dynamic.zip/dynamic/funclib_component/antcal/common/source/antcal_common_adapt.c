#include "antcal_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bspvswr.h"
#include "antcalapi.h"
#include "bsppub.h"

static UINT32 g_sAntcal_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetVswrValueIcAdapt(UINT32 cmd, T_AcVswrValue *acVswrValue)
{
    return BspGetVswrValueIc(acVswrValue);
}

static UINT32 BspSendAcStubDataAdapt(UINT32 cmd, UINT32 sw)
{
    return BspSendAcStubData(sw);
}

static UINT32 BspGetAcCarrInfoAdapt(UINT32 cmd, UINT32 carrNo, UINT32 radioMode)
{
    return BspGetAcCarrInfo(carrNo, radioMode);
}

static UINT32 BspGetVswrSeqIcAdapt(UINT32 cmd, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 *length)
{
    return BspGetVswrSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length);
}

static UINT32 BspSendAcWgtAdapt(UINT32 cmd, UINT8 upDown, UINT32 carrNo, UINT32 radioMode)
{
    return BspSendAcWgt(upDown, carrNo, radioMode);
}

static UINT32 BspStartVswrSeqCalcIcAdapt(UINT32 cmd, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType)
{
    return BspStartVswrSeqCalcIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType);
}

static UINT32 BspStartVswrWgtCalcIcAdapt(UINT32 cmd, UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChan)
{
    return BspStartVswrWgtCalcIc(acType, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, refChan);
}

static UINT32 BspRecvAcMsgAdapt(UINT32 cmd, T_Pulm2CmacAntAdjustRsp *ptInfo)
{
    return BspRecvAcMsg(ptInfo);
}

static UINT32 BspGetVswrDataCatchStaAdapt(UINT32 cmd, UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspGetVswrDataCatchSta(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

static UINT32 BspStartAcSeqCalcIc4Adapt(UINT32 cmd, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 refChan, UINT32 preciseDlyFlag, INT32 freqNcoOffset)
{
    return BspStartAcSeqCalcIc4(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, refChan, preciseDlyFlag, freqNcoOffset);
}

static UINT32 BspSetVswrParaIcAdapt(UINT32 cmd, UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChn, UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo)
{
    return BspSetVswrParaIc(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, refChn, frameNo, subframeNo, slotNo);
}

static UINT32 BspSetVswrSeqIcAdapt(UINT32 cmd, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 length, UINT32 seqMode)
{
    return BspSetVswrSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length, seqMode);
}

static UINT32 BspSetAcWgtIcAdapt(UINT32 cmd, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32 *data, UINT32 trxLength, UINT32 prachRxLength)
{
    return BspSetAcWgtIc(carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, data, trxLength, prachRxLength);
}

static UINT32 BspGetVswrSyncTimeAdapt(UINT32 cmd, UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    return BspGetVswrSyncTime(acType, syncType, syncTime);
}

static UINT32 BspInitAcDevParaAdapt(UINT32 cmd)
{
    return BspInitAcDevPara();
}

static UINT32 BspGetAcSyncTimeAdapt(UINT32 cmd, UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    return BspGetAcSyncTime(acType, syncType, syncTime);
}

static UINT32 BspStartAcRecvAdapt(UINT32 cmd, UINT16 upDown, UINT32 carrNo, UINT32 radioMode, UINT16 powerFactor)
{
    return BspStartAcRecv(upDown, carrNo, radioMode, powerFactor);
}

static UINT32 BspSendCaliChanAdapt(UINT32 cmd, UINT32 caliChan)
{
    return BspSendCaliChan(caliChan);
}

static UINT32 BspGetAcDataCatchStaAdapt(UINT32 cmd, UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspGetAcDataCatchSta(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

static UINT32 BspSetAcParaIcAdapt(UINT32 cmd, UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 referChnNo, UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo)
{
    return BspSetAcParaIc(acType, carrNo, pasteCarrFlag, deviate, bandWidth, acChnChgFlag, radioMode, referChnNo, frameNo, subframeNo, slotNo);
}

static UINT32 BspGetAcWgtIcAdapt(UINT32 cmd, UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32 *data, UINT32 *trxLength, UINT32 *prachRxLength)
{
    return BspGetAcWgtIc(socId, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, data, trxLength, prachRxLength);
}

static UINT32 BspSetAcSyncTimeAdapt(UINT32 cmd, UINT32 acType, UINT32 syncType, UINT32 syncTime, UINT32 bitMap)
{
    return BspSetAcSyncTime(acType, syncType, syncTime, bitMap);
}

static UINT32 BspSetAcSeqIcAdapt(UINT32 cmd, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 length, UINT32 seqMode)
{
    return BspSetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length, seqMode);
}

static UINT32 BspSendAcResultAdapt(UINT32 cmd, UINT8 upDown, UINT32 carrNo, UINT32 radioMode)
{
    return BspSendAcResult(upDown, carrNo, radioMode);
}

static UINT32 BspGetVswrCarrInfoAdapt(UINT32 cmd, UINT32 carrNo, UINT32 radioMode)
{
    return BspGetVswrCarrInfo(carrNo, radioMode);
}

static UINT32 BspSendAcCatchDataAdapt(UINT32 cmd, UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspSendAcCatchData(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

static UINT32 BspSendAcTddUlInslotCatchDataAdapt(UINT32 cmd, UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspSendAcTddUlInslotCatchData(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

static UINT32 BspGetAcRecvStaAdapt(UINT32 cmd, UINT32 carrNo, UINT32 radioMode)
{
    return BspGetAcRecvSta(carrNo, radioMode);
}

static UINT32 BspStartAcWgtCalcIcAdapt(UINT32 cmd, UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChan)
{
    return BspStartAcWgtCalcIc(acType, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, refChan);
}

static UINT32 BspStartAcSeqCalcIcAdapt(UINT32 cmd, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType)
{
    return BspStartAcSeqCalcIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType);
}

static UINT32 BspGetAcWgtResultIcAdapt(UINT32 cmd, UINT32 acType, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 carr, UINT32 radioMode)
{
    return BspGetAcWgtResultIc(acType, pasteCarrFlag, deviate, bandWidth, sampleRate, carr, radioMode);
}

static UINT32 BspGetAcSeqIcAdapt(UINT32 cmd, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 *length)
{
    return BspGetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length);
}

static UINT32 BspRecvAcMsgIc3Adapt(UINT32 cmd, T_Pulm2CmacAntAdjustRspIc3* ptInfo)
{
    return BspRecvAcMsgIc3(ptInfo);
}

static UINT32 BspGetVswrRecvStaAdapt(UINT32 cmd, UINT32 carrNo, UINT32 radioMode)
{
    return BspGetVswrRecvSta(carrNo, radioMode);
}

static UINT32 BspFtmGetFrameNoAdapt(UINT32 cmd)
{
    return BspFtmGetFrameNo();
}

static UINT32 BspSendAcMsgIc3Adapt(UINT32 cmd, T_Cmac2PulmAntAdjustScheInfoIc3* ptInfo)
{
    return BspSendAcMsgIc3(ptInfo);
}

static UINT32 BspSendVswrCatchDataAdapt(UINT32 cmd, UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspSendVswrCatchData(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

static UINT32 BspSendAcMsgAdapt(UINT32 cmd, T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    return BspSendAcMsg(ptInfo);
}

__attribute((constructor)) void _antcal_common_adapt_init_()
{
    if (NOTREGIST == g_sAntcal_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_VSWR_VALUE_IC, BspGetVswrValueIcAdapt);
        BspRegistService(BSP_CMD_SEND_AC_STUB_DATA, BspSendAcStubDataAdapt);
        BspRegistService(BSP_CMD_GET_AC_CARR_INFO, BspGetAcCarrInfoAdapt);
        BspRegistService(BSP_CMD_GET_VSWR_SEQ_IC, BspGetVswrSeqIcAdapt);
        BspRegistService(BSP_CMD_SEND_AC_WGT, BspSendAcWgtAdapt);
        BspRegistService(BSP_CMD_START_VSWR_SEQ_CALC_IC, BspStartVswrSeqCalcIcAdapt);
        BspRegistService(BSP_CMD_START_VSWR_WGT_CALC_IC, BspStartVswrWgtCalcIcAdapt);
        BspRegistService(BSP_CMD_RECV_AC_MSG, BspRecvAcMsgAdapt);
        BspRegistService(BSP_CMD_GET_VSWR_DATA_CATCH_STA, BspGetVswrDataCatchStaAdapt);
        BspRegistService(BSP_CMD_START_AC_SEQ_CALC_IC4, BspStartAcSeqCalcIc4Adapt);
        BspRegistService(BSP_CMD_SET_VSWR_PARA_IC, BspSetVswrParaIcAdapt);
        BspRegistService(BSP_CMD_SET_VSWR_SEQ_IC, BspSetVswrSeqIcAdapt);
        BspRegistService(BSP_CMD_SET_AC_WGT_IC, BspSetAcWgtIcAdapt);
        BspRegistService(BSP_CMD_GET_VSWR_SYNC_TIME, BspGetVswrSyncTimeAdapt);
        BspRegistService(BSP_CMD_INIT_AC_DEV_PARA, BspInitAcDevParaAdapt);
        BspRegistService(BSP_CMD_GET_AC_SYNC_TIME, BspGetAcSyncTimeAdapt);
        BspRegistService(BSP_CMD_START_AC_RECV, BspStartAcRecvAdapt);
        BspRegistService(BSP_CMD_SEND_CALI_CHAN, BspSendCaliChanAdapt);
        BspRegistService(BSP_CMD_GET_AC_DATA_CATCH_STA, BspGetAcDataCatchStaAdapt);
        BspRegistService(BSP_CMD_SET_AC_PARA_IC, BspSetAcParaIcAdapt);
        BspRegistService(BSP_CMD_GET_AC_WGT_IC, BspGetAcWgtIcAdapt);
        BspRegistService(BSP_CMD_SET_AC_SYNC_TIME, BspSetAcSyncTimeAdapt);
        BspRegistService(BSP_CMD_SET_AC_SEQ_IC, BspSetAcSeqIcAdapt);
        BspRegistService(BSP_CMD_SEND_AC_RESULT, BspSendAcResultAdapt);
        BspRegistService(BSP_CMD_GET_VSWR_CARR_INFO, BspGetVswrCarrInfoAdapt);
        BspRegistService(BSP_CMD_SEND_AC_CATCH_DATA, BspSendAcCatchDataAdapt);
        BspRegistService(BSP_CMD_SEND_AC_TDD_UL_INSLOT_CATCH_DATA, BspSendAcTddUlInslotCatchDataAdapt);
        BspRegistService(BSP_CMD_GET_AC_RECV_STA, BspGetAcRecvStaAdapt);
        BspRegistService(BSP_CMD_START_AC_WGT_CALC_IC, BspStartAcWgtCalcIcAdapt);
        BspRegistService(BSP_CMD_START_AC_SEQ_CALC_IC, BspStartAcSeqCalcIcAdapt);
        BspRegistService(BSP_CMD_GET_AC_WGT_RESULT_IC, BspGetAcWgtResultIcAdapt);
        BspRegistService(BSP_CMD_GET_AC_SEQ_IC, BspGetAcSeqIcAdapt);
        BspRegistService(BSP_CMD_RECV_AC_MSG_IC3, BspRecvAcMsgIc3Adapt);
        BspRegistService(BSP_CMD_GET_VSWR_RECV_STA, BspGetVswrRecvStaAdapt);
        BspRegistService(BSP_CMD_FTM_GET_FRAME_NO, BspFtmGetFrameNoAdapt);
        BspRegistService(BSP_CMD_SEND_AC_MSG_IC3, BspSendAcMsgIc3Adapt);
        BspRegistService(BSP_CMD_SEND_VSWR_CATCH_DATA, BspSendVswrCatchDataAdapt);
        BspRegistService(BSP_CMD_SEND_AC_MSG, BspSendAcMsgAdapt);

        g_sAntcal_commonRegistFlag = ISREGIST;
    }
}

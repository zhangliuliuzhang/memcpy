#include "antcal_ic4_2_oneic_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "antcal_ic4_2_oneic.h"

static UINT32 g_sAntcal_ic4_2_oneicRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

/* ULONG->UINT32 已改原型函数返回值*/
static UINT32 BspGetAntAmpPhaseAdapt(UINT32 cmd, ULONG ulPath, ULONG ulCarrFreq, T_PauRelativeRec *ptData)
{
    return BspGetAntAmpPhase(ulPath, ulCarrFreq, ptData);
}

static UINT32 BspSetAcBcWgtAdapt(UINT32 cmd, T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    return BspSetAcBcWgt(ptInfo);
}

static UINT32 BspDirDataLoadAdapt(UINT32 cmd, UINT32 index, UINT32 *dirData, UINT32 *dataLen)
{
    return BspDirDataLoad(index, dirData, dataLen);
}

static UINT32 BspSetAcBitMapAdapt(UINT32 cmd, UINT32 sw)
{
    return BspSetAcBitMap(sw);
}

static UINT32 BspGetProWgtAdapt(UINT32 cmd, UINT32 dir, UINT32 chanNo, UINT32 carrNo, UINT32 *pData, UINT32 *length)
{
    return BspGetProWgt(dir, chanNo, carrNo, pData, length);
}

static UINT32 BspGetTsgFreRbAdapt(UINT32 cmd, INT32 toneFreq)
{
    return BspGetTsgFreRb(toneFreq);
}

static UINT32 BspGetAcIc4MeasInfoAdapt(UINT32 cmd, UINT32 acType, T_BspAcIc4InfoDir *pAcInfo)
{
    return BspGetAcIc4MeasInfo(acType, pAcInfo);
}

__attribute((constructor)) void _antcal_ic4_2_oneic_adapt_init_()
{
    if (NOTREGIST == g_sAntcal_ic4_2_oneicRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_ANT_AMP_PHASE, BspGetAntAmpPhaseAdapt);
        BspRegistService(BSP_CMD_SET_AC_BC_WGT, BspSetAcBcWgtAdapt);
        BspRegistService(BSP_CMD_DIR_DATA_LOAD, BspDirDataLoadAdapt);
        BspRegistService(BSP_CMD_SET_AC_BIT_MAP, BspSetAcBitMapAdapt);
        BspRegistService(BSP_CMD_GET_PRO_WGT, BspGetProWgtAdapt);
        BspRegistService(BSP_CMD_GET_TSG_FRE_RB, BspGetTsgFreRbAdapt);
        BspRegistService(BSP_CMD_GET_AC_IC4_MEAS_INFO, BspGetAcIc4MeasInfoAdapt);

        g_sAntcal_ic4_2_oneicRegistFlag = ISREGIST;
    }
}

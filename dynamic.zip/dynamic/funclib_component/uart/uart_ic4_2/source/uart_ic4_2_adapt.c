#include "uart_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "bsppub.h"
#include "uart_ic4_2.h"
#include "uartapi.h"

static UINT32 g_sUart_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetExternalDryContactStatusAdapt(UINT32 cmd, T_RruDryContactInfo *pInfo)
{
    return BspGetExternalDryContactStatus(pInfo);
}

static UINT32 BspMonSendAdapt(UINT32 cmd, UINT8 *buf, UINT32 len)
{
    return BspMonSend(buf, len);
}

static UINT32 BspSetAisgVoltAdapt(UINT32 cmd, UINT32 devIndex, UINT32 pwrVoltType)
{
    return BspSetAisgVolt(devIndex, pwrVoltType);
}

static UINT32 BspFanSendAdapt(UINT32 cmd, UINT8 *buf, UINT32 len)
{
    return BspFanSend(buf, len);
}

static UINT32 BspGetAisgVoltAdapt(UINT32 cmd, UINT32 devIndex)
{
    return BspGetAisgVolt(devIndex);
}

static UINT32 BspSetAisgPwrStatusAdapt(UINT32 cmd, UINT32 devIndex, UINT32 isOn)
{
    return BspSetAisgPwrStatus(devIndex, isOn);
}

/* VOID->UINT32 */
static UINT32 BspEmbFunctionEnableAdapt(UINT32 cmd, UINT32 ulIndex)
{
    BspEmbFunctionEnable(ulIndex);
    return BSP_OK;
}

static UINT32 BspGetAisgPwrStatusAdapt(UINT32 cmd, UINT32 devIndex)
{
    return BspGetAisgPwrStatus(devIndex);
}

static UINT32 BspMonRecvAdapt(UINT32 cmd, UINT8 *buf, UINT32 len)
{
    return BspMonRecv(buf, len);
}

static UINT32 BspGetPwrShortAlarmAdapt(UINT32 cmd, UINT32 ulIndex, BYTE *ulStatus)
{
    return BspGetPwrShortAlarm(ulIndex, ulStatus);
}

static UINT32 BspAisgSetVoltRangeAdapt(UINT32 cmd, UINT32 devIndex)
{
    return BspAisgSetVoltRange(devIndex);
}

__attribute((constructor)) void _uart_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sUart_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_GET_EXTERNAL_DRY_CONTACT_STATUS, BspGetExternalDryContactStatusAdapt);
        BspRegistService(BSP_CMD_MON_SEND, BspMonSendAdapt);
        BspRegistService(BSP_CMD_SET_AISG_VOLT, BspSetAisgVoltAdapt);
        BspRegistService(BSP_CMD_FAN_SEND, BspFanSendAdapt);
        BspRegistService(BSP_CMD_GET_AISG_VOLT, BspGetAisgVoltAdapt);
        BspRegistService(BSP_CMD_SET_AISG_PWR_STATUS, BspSetAisgPwrStatusAdapt);
        BspRegistService(BSP_CMD_EMB_FUNCTION_ENABLE, BspEmbFunctionEnableAdapt);
        BspRegistService(BSP_CMD_GET_AISG_PWR_STATUS, BspGetAisgPwrStatusAdapt);
        BspRegistService(BSP_CMD_MON_RECV, BspMonRecvAdapt);
        BspRegistService(BSP_CMD_GET_PWR_SHORT_ALARM, BspGetPwrShortAlarmAdapt);
        BspRegistService(BSP_CMD_AISG_SET_VOLT_RANGE, BspAisgSetVoltRangeAdapt);

        g_sUart_ic4_2RegistFlag = ISREGIST;
    }
}

#include "uart_common_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "uartapi.h"

static UINT32 g_sUart_commonRegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetUartSelectedAdapt(UINT32 cmd, UINT32 index)
{
    return BspGetUartSelected(index);
}

static UINT32 BspGetAisgNsbtControlNumAdapt(UINT32 cmd)
{
    return BspGetAisgNsbtControlNum();
}

static UINT32 BspSetUartSelectedAdapt(UINT32 cmd, UINT32 index, UINT32 type)
{
    return BspSetUartSelected(index, type);
}

static UINT32 BspUartSendAdapt(UINT32 cmd, UINT32 index, UINT8 *buf, UINT32 len)
{
    return BspUartSend(index, buf, len);
}

static UINT32 BspUartRecvAdapt(UINT32 cmd, UINT32 index, UINT8 *buf, UINT32 len)
{
    return BspUartRecv(index, buf, len);
}

__attribute((constructor)) void _uart_common_adapt_init_()
{
    if (NOTREGIST == g_sUart_commonRegistFlag)
    {
        BspRegistService(BSP_CMD_GET_UART_SELECTED, BspGetUartSelectedAdapt);
        BspRegistService(BSP_CMD_GET_AISG_NSBT_CONTROL_NUM, BspGetAisgNsbtControlNumAdapt);
        BspRegistService(BSP_CMD_SET_UART_SELECTED, BspSetUartSelectedAdapt);
        BspRegistService(BSP_CMD_UART_SEND, BspUartSendAdapt);
        BspRegistService(BSP_CMD_UART_RECV, BspUartRecvAdapt);

        g_sUart_commonRegistFlag = ISREGIST;
    }
}

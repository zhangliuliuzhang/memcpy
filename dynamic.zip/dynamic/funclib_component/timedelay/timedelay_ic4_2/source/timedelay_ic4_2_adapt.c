#include "timedelay_ic4_2_adapt.h"
#include "bspservice_adapt.h"
#include "bsp_framework_api.h"
#include "pub_basetypedef.h"
#include "timedelayapi.h"
#include "timedelay_ic4_2_interface.h"

static UINT32 g_sTimedelay_ic4_2RegistFlag = NOTREGIST;/* 注册标志：1表示未注册，0表示已注册 */

static UINT32 BspGetBbTa3DelayAdapt(UINT32 cmd, UINT32 phyOpt)
{
    return BspGetBbTa3Delay(phyOpt);
}

static UINT32 BspSetOptCarrDelayAdapt(UINT32 cmd, UINT32 uChan, UINT32 uRadioMode, T_BspCarrDelayItem *ptCarrDelayItem)
{
    return BspSetOptCarrDelay(uChan, uRadioMode, ptCarrDelayItem);
}

static UINT32 BspSetFrameDelayAdapt(UINT32 cmd, UINT32 phyOpt, UINT32 tadv)
{
    return BspSetFrameDelay(phyOpt, tadv);
}

static UINT32 BspSetUlTimePhaseOffsetAdapt(UINT32 cmd, UINT32 carrNo, UINT32 radioMode, UINT32 value)
{
    return BspSetUlTimePhaseOffset(carrNo, radioMode, value);
}

static UINT32 BspGetBbT2aDelayAdapt(UINT32 cmd, UINT32 phyOpt)
{
    return BspGetBbT2aDelay(phyOpt);
}

static UINT32 BspSetToffsetAdapt(UINT32 cmd, UINT32 phyOpt, UINT32 toffset)
{
    return BspSetToffset(phyOpt, toffset);
}

static UINT32 BspSetCpeTxTimingAdvanceAdapt(UINT32 cmd, UINT32 cellId, UINT32 radioMod, UINT32 cpeMode)
{
    return BspSetCpeTxTimingAdvance(cellId, radioMod, cpeMode);
}

static UINT32 BspSetT12Adapt(UINT32 cmd, T_RruDelayReq *ptT12)
{
    return BspSetT12(ptT12);
}

static UINT32 BspSetFrameAlignmentAdapt(UINT32 cmd, UINT32 bandId, UINT32 radioMode, INT32 lFrameDelay)
{
    return BspSetFrameAlignment(bandId, radioMode, lFrameDelay);
}

static UINT32 BspGetOptDelayParaAdapt(UINT32 cmd, UINT32 ulIsLogVal, UINT32 ulRadioMode, T_NewRruOptDelayPara *ptOptDelayPara)
{
    return BspGetOptDelayPara(ulIsLogVal, ulRadioMode, ptOptDelayPara);
}

static UINT32 BspSetFrameAlignment_FddAdapt(UINT32 cmd, UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 lFrameDelay)
{
    return BspSetFrameAlignment_Fdd(bspChn, radioMode, carrNo, lFrameDelay);
}

static UINT32 BspSetFddNrIf1DiffTaAdapt(UINT32 cmd, UINT32 TaValue, INT32 TxDiffTa)
{
    return BspSetFddNrIf1DiffTa(TaValue, TxDiffTa);
}

static UINT32 BspSetRfAcDelayIc42Adapt(UINT32 cmd, UINT32 acType, UINT32 chanNo, INT8 delayTa, INT8 Tac, UINT32 bandWith, UINT32 radioMode, UINT32 carrNo)
{
    return BspSetRfAcDelayIc42(acType, chanNo, delayTa, Tac, bandWith, radioMode, carrNo);
}

static UINT32 BspSetTaValue_FddAdapt(UINT32 cmd, UINT32 TaValue)
{
    return BspSetTaValue_Fdd(TaValue);
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
static UINT32 BspUpdateCarrDelayAdapt(UINT32 cmd, UINT32 bspChn)
{
    return BspUpdateCarrDelay(bspChn);
}
#endif

__attribute((constructor)) void _timedelay_ic4_2_adapt_init_()
{
    if (NOTREGIST == g_sTimedelay_ic4_2RegistFlag)
    {
        BspRegistService(BSP_CMD_GET_BB_TA3_DELAY, BspGetBbTa3DelayAdapt);
        BspRegistService(BSP_CMD_SET_OPT_CARR_DELAY, BspSetOptCarrDelayAdapt);
        BspRegistService(BSP_CMD_SET_FRAME_DELAY, BspSetFrameDelayAdapt);
        BspRegistService(BSP_CMD_SET_UL_TIME_PHASE_OFFSET, BspSetUlTimePhaseOffsetAdapt);
        BspRegistService(BSP_CMD_GET_BB_T2A_DELAY, BspGetBbT2aDelayAdapt);
        BspRegistService(BSP_CMD_SET_TOFFSET, BspSetToffsetAdapt);
        BspRegistService(BSP_CMD_SET_CPE_TX_TIMING_ADVANCE, BspSetCpeTxTimingAdvanceAdapt);
        BspRegistService(BSP_CMD_SET_T12, BspSetT12Adapt);
        BspRegistService(BSP_CMD_SET_FRAME_ALIGNMENT, BspSetFrameAlignmentAdapt);
        BspRegistService(BSP_CMD_GET_OPT_DELAY_PARA, BspGetOptDelayParaAdapt);
        BspRegistService(BSP_CMD_SET_FRAME_ALIGNMENT__FDD, BspSetFrameAlignment_FddAdapt);
        BspRegistService(BSP_CMD_SET_FDD_NR_IF1_DIFF_TA, BspSetFddNrIf1DiffTaAdapt);
        BspRegistService(BSP_CMD_SET_RF_AC_DELAY_IC42, BspSetRfAcDelayIc42Adapt);
        BspRegistService(BSP_CMD_SET_TA_VALUE__FDD, BspSetTaValue_FddAdapt);

#ifdef DYNAMIC_API_TEST
        BspRegistService(BSP_CMD_UPDATE_CARR_DELAY, BspUpdateCarrDelayAdapt);
#endif

        g_sTimedelay_ic4_2RegistFlag = ISREGIST;
    }
}

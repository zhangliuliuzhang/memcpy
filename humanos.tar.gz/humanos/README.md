# AI Task OS

> AI 驱动的个人任务操作系统，帮助用户管理注意力、任务上下文、提醒节奏、任务中断现场和长期记忆。

## 核心价值

普通任务软件回答："我有哪些任务？"

AI Task OS 回答：
- 我现在该做什么？
- 我上次做到哪里？
- 我被打断时如何保存现场？
- 我回来后如何快速继续？
- 我长期不做时如何不忘？
- AI 如何帮我整理、提醒和推进？

## 技术栈

| 层级 | 技术 |
|------|------|
| 后端 | Java 21 + Spring Boot 3.3 + MyBatis-Plus + Quartz |
| 数据库 | PostgreSQL 16 + Redis 7 + MinIO |
| 前端 | React 18 + TypeScript + Vite 5 + Tailwind CSS + Zustand |
| 移动端 | Android Kotlin + WebView / 鸿蒙 ArkTS + Web 嵌入 |
| AI | OpenAI 兼容协议（可自定义 base_url） |
| 部署 | Docker Compose |

## 快速开始

### 前置依赖

| 工具 | 版本 | 说明 |
|------|------|------|
| Java JDK | 21 (LTS) | 或 Java 17 |
| Maven | 3.9+ | 后端构建 |
| Node.js | 20 LTS | 前端构建 |
| pnpm | 9+ | 前端包管理 |
| Docker | 24+ | 容器运行时 |
| Docker Compose | 2.20+ | 多容器编排 |

### 1. 克隆项目

```bash
git clone <repo-url>
cd ai-task-os
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，填入 AI_API_KEY、JWT_SECRET 等
```

### 3. 启动开发服务

```bash
# 启动基础设施（PostgreSQL + Redis + MinIO）
docker compose up -d

# 启动后端（默认 :8080）
cd backend
./mvnw spring-boot:run

# 启动前端（默认 :5173）
cd frontend
pnpm install
pnpm dev
```

### 4. 访问应用

- **Web 前端**: http://localhost:5173
- **API 文档 (Swagger)**: http://localhost:8080/swagger-ui.html
- **MinIO 控制台**: http://localhost:9001

## 项目结构

```
ai-task-os/
├── backend/                    # Java Spring Boot 后端
│   ├── src/main/java/com/taskos/
│   │   ├── common/             # 通用（config/exception/response/security/utils）
│   │   ├── user/               # 用户与鉴权
│   │   ├── task/               # 任务与会话
│   │   ├── reminder/           # 提醒引擎
│   │   ├── snapshot/           # 任务快照
│   │   ├── note/               # 笔记
│   │   ├── ai/                 # AI 网关
│   │   ├── review/             # 复习记忆
│   │   ├── notification/       # 通知
│   │   ├── file/               # 文件
│   │   └── dashboard/          # 今日驾驶舱
│   └── src/main/resources/db/migration/   # Flyway 迁移
├── frontend/                   # React Web 前端
│   └── src/
│       ├── components/         # UI 组件
│       ├── pages/              # 页面
│       ├── services/           # API 调用
│       ├── stores/             # Zustand 状态管理
│       ├── hooks/              # 自定义 hooks
│       ├── utils/              # 工具函数
│       └── types/              # TypeScript 类型
├── android/                    # Android App（轻壳）
├── harmony/                    # 鸿蒙 App（轻壳）
├── specs/                      # 规格文档（Spec-Driven Development）
│   └── 001-ai-task-os/
│       ├── spec.md             # 功能规格
│       ├── plan.md             # 技术方案
│       ├── data-model.md       # 数据模型
│       ├── contracts/          # API 契约
│       ├── tasks.md            # 任务清单
│       └── quickstart.md       # 快速上手
├── docker-compose.yml
├── Dockerfile.backend
├── Dockerfile.frontend
└── .env.example
```

## 核心闭环

```
用户输入任务 → AI 解析 → 用户确认 → 保存任务
→ 生成提醒规则 → 触发提醒事件 → 推送通知
→ 用户开始任务 → 暂停/被打断 → 保存快照
→ AI 总结当前节点 → 用户下次继续 → 恢复上次上下文
→ 长期未推进则提醒复习整理
```

## 设计文档

完整的产品规格、技术方案和任务清单见 [`specs/001-ai-task-os/`](./specs/001-ai-task-os/)。

## 开发命令

```bash
# 后端
cd backend
./mvnw clean package         # 构建
./mvnw spring-boot:run       # 运行
./mvnw test                  # 测试
./mvnw flyway:migrate        # 数据库迁移

# 前端
cd frontend
pnpm dev                     # 开发服务器
pnpm build                   # 生产构建
pnpm lint                    # 代码检查
pnpm typecheck               # 类型检查
```

## License

Personal use. All rights reserved.

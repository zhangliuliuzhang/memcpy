#!/bin/bash
# AI Task OS 一键启动脚本
# 使用方法: ./start.sh [dev|build|down]

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 检查依赖
check_dependencies() {
    log_info "检查依赖..."

    # Docker
    if ! command -v docker &> /dev/null; then
        log_error "未安装 Docker，请先安装 Docker"
        exit 1
    fi

    # Node.js
    if ! command -v node &> /dev/null; then
        log_error "未安装 Node.js，请先安装 Node.js 20+"
        exit 1
    fi

    # pnpm
    if ! command -v pnpm &> /dev/null; then
        log_info "安装 pnpm..."
        npm install -g pnpm
    fi

    # Java (可选，用于本地运行后端)
    JAVA_VERSION=$(java -version 2>&1 | head -1 | cut -d'"' -f2 | cut -d'.' -f1 2>/dev/null || echo "0")
    if [ "$JAVA_VERSION" -lt 17 ]; then
        log_warn "本地 Java 版本低于 17，将使用 Docker 运行后端"
        USE_DOCKER_BACKEND=true
    else
        USE_DOCKER_BACKEND=false
    fi

    log_info "依赖检查完成"
}

# 启动基础设施
start_infrastructure() {
    log_info "启动基础设施 (PostgreSQL + Redis + MinIO)..."

    # 检查容器是否已运行
    if docker ps | grep -q aitaskos-postgres; then
        log_info "PostgreSQL 已运行"
    else
        # 创建网络
        docker network create aitaskos-net 2>/dev/null || true

        # 创建数据目录
        mkdir -p docker-data/postgres docker-data/redis docker-data/minio

        # PostgreSQL
        docker run -d \
            --name aitaskos-postgres \
            --network aitaskos-net \
            -e POSTGRES_USER=aitaskos \
            -e POSTGRES_PASSWORD=aitaskos123 \
            -e POSTGRES_DB=aitaskos \
            -v "$(pwd)/docker-data/postgres:/var/lib/postgresql/data" \
            -p 5432:5432 \
            postgres:16-alpine

        # Redis
        docker run -d \
            --name aitaskos-redis \
            --network aitaskos-net \
            -v "$(pwd)/docker-data/redis:/data" \
            -p 6379:6379 \
            redis:7-alpine redis-server

        # MinIO
        docker run -d \
            --name aitaskos-minio \
            --network aitaskos-net \
            -e MINIO_ROOT_USER=minioadmin \
            -e MINIO_ROOT_PASSWORD=minioadmin123 \
            -v "$(pwd)/docker-data/minio:/data" \
            -p 9000:9000 \
            -p 9001:9001 \
            minio/minio server /data --console-address ":9001"

        # 等待 PostgreSQL 就绪
        log_info "等待 PostgreSQL 就绪..."
        sleep 10
        for i in {1..30}; do
            if docker exec aitaskos-postgres pg_isready -U aitaskos 2>/dev/null; then
                log_info "PostgreSQL 就绪"
                break
            fi
            sleep 1
        done
    fi
}

# 启动后端
start_backend() {
    log_info "启动后端..."

    if [ "$USE_DOCKER_BACKEND" = true ]; then
        log_info "使用 Docker 运行后端..."

        # 构建后端镜像
        if ! docker images | grep -q aitaskos-backend; then
            log_info "构建后端 Docker 镜像..."
            docker build -t aitaskos-backend -f Dockerfile.backend .
        fi

        # 运行后端容器
        docker run -d \
            --name aitaskos-backend \
            --network aitaskos-net \
            -e SPRING_PROFILES_ACTIVE=dev \
            -e DB_HOST=aitaskos-postgres \
            -e DB_PORT=5432 \
            -e DB_NAME=aitaskos \
            -e DB_USER=aitaskos \
            -e DB_PASSWORD=aitaskos123 \
            -e REDIS_HOST=aitaskos-redis \
            -e MINIO_ENDPOINT=http://aitaskos-minio:9000 \
            -p 8080:8080 \
            aitaskos-backend
    else
        log_info "本地运行后端..."
        cd backend

        # 检查 Maven Wrapper
        if [ -f "./mvnw" ]; then
            ./mvnw spring-boot:run -Dspring-boot.run.profiles=dev
        elif command -v mvn &> /dev/null; then
            mvn spring-boot:run -Dspring-boot.run.profiles=dev
        else
            log_error "未找到 Maven，请安装 Maven 或使用 Docker 模式"
            exit 1
        fi

        cd ..
    fi
}

# 启动前端
start_frontend() {
    log_info "启动前端..."
    cd frontend

    # 安装依赖
    if [ ! -d "node_modules" ]; then
        log_info "安装前端依赖..."
        pnpm install
    fi

    # 启动开发服务器
    pnpm dev &

    cd ..
    log_info "前端启动完成: http://localhost:5173"
}

# 构建生产版本
build_all() {
    log_info "构建生产版本..."

    # 构建后端
    log_info "构建后端 JAR..."
    cd backend
    if [ -f "./mvnw" ]; then
        ./mvnw clean package -DskipTests
    else
        mvn clean package -DskipTests
    fi
    cd ..

    # 构建前端
    log_info "构建前端..."
    cd frontend
    pnpm install
    pnpm build
    cd ..

    # 构建 Docker 镜像
    log_info "构建 Docker 镜像..."
    docker build -t aitaskos-backend:latest -f Dockerfile.backend .
    docker build -t aitaskos-frontend:latest -f Dockerfile.frontend .

    log_info "构建完成!"
}

# 停止所有服务
stop_all() {
    log_info "停止所有服务..."

    # 停止 Docker 容器
    docker stop aitaskos-backend aitaskos-frontend 2>/dev/null || true
    docker rm aitaskos-backend aitaskos-frontend 2>/dev/null || true

    # 停止前端进程
    pkill -f "vite" 2>/dev/null || true

    log_info "所有服务已停止"
}

# 停止基础设施
down_all() {
    stop_all

    log_info "停止并移除基础设施..."
    docker stop aitaskos-postgres aitaskos-redis aitaskos-minio 2>/dev/null || true
    docker rm aitaskos-postgres aitaskos-redis aitaskos-minio 2>/dev/null || true
    docker network rm aitaskos-net 2>/dev/null || true

    log_info "所有容器已移除"
}

# 显示帮助
show_help() {
    echo "AI Task OS 启动脚本"
    echo ""
    echo "用法: ./start.sh [命令]"
    echo ""
    echo "命令:"
    echo "  dev     启动开发环境 (默认)"
    echo "  build   构建生产版本"
    echo "  stop    停止应用服务"
    echo "  down    停止并移除所有容器"
    echo "  help    显示帮助信息"
    echo ""
    echo "服务端口:"
    echo "  前端:   http://localhost:5173"
    echo "  后端:   http://localhost:8080"
    echo "  API文档: http://localhost:8080/swagger-ui.html"
    echo "  MinIO:  http://localhost:9001 (minioadmin/minioadmin123)"
}

# 主函数
main() {
    case "${1:-dev}" in
        dev)
            check_dependencies
            start_infrastructure
            start_frontend
            log_info "======================================"
            log_info "AI Task OS 开发环境已启动!"
            log_info "前端: http://localhost:5173"
            log_info "后端: 需要手动启动 (Java 21+)"
            log_info "======================================"
            ;;
        build)
            check_dependencies
            build_all
            ;;
        stop)
            stop_all
            ;;
        down)
            down_all
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "未知命令: $1"
            show_help
            exit 1
            ;;
    esac
}

main "$@"
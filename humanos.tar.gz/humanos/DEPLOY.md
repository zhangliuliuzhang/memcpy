# AI Task OS 环境要求与部署指南

## 一、环境要求

### 必需软件

| 软件 | 版本要求 | 用途 |
|------|---------|------|
| Docker | 20.10+ | 容器运行时 |
| Docker Compose | 2.0+ | 多容器编排 (可选) |
| Node.js | 20 LTS | 前端开发/构建 |
| pnpm | 9+ | 前端包管理 |
| Java JDK | 21 (或 17) | 后端运行 |
| Maven | 3.9+ | 后端构建 (可选，可用 Docker 替代) |

### 端口占用

| 端口 | 服务 |
|------|------|
| 5173 | 前端开发服务器 |
| 8080 | 后端 API |
| 5432 | PostgreSQL |
| 6379 | Redis |
| 9000 | MinIO API |
| 9001 | MinIO 控制台 |

## 二、快速启动

### 1. 克隆项目

```bash
# 如果是从压缩包解压，跳过此步
git clone <repo-url>
cd ai-task-os
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，填入 AI_API_KEY 等配置
```

### 3. 一键启动

```bash
# 赋予执行权限
chmod +x start.sh

# 启动开发环境
./start.sh dev
```

### 4. 启动后端 (需要 Java 21)

```bash
cd backend
./mvnw spring-boot:run    # 如果有 Maven Wrapper
# 或
mvn spring-boot:run       # 如果已安装 Maven
```

## 三、手动启动步骤

### 1. 启动基础设施 (Docker)

```bash
# 创建网络
docker network create aitaskos-net

# 创建数据目录
mkdir -p docker-data/postgres docker-data/redis docker-data/minio

# PostgreSQL
docker run -d --name aitaskos-postgres --network aitaskos-net \
  -e POSTGRES_USER=aitaskos -e POSTGRES_PASSWORD=aitaskos123 \
  -e POSTGRES_DB=aitaskos -v $(pwd)/docker-data/postgres:/var/lib/postgresql/data \
  -p 5432:5432 postgres:16-alpine

# Redis
docker run -d --name aitaskos-redis --network aitaskos-net \
  -v $(pwd)/docker-data/redis:/data \
  -p 6379:6379 redis:7-alpine redis-server

# MinIO
docker run -d --name aitaskos-minio --network aitaskos-net \
  -e MINIO_ROOT_USER=minioadmin -e MINIO_ROOT_PASSWORD=minioadmin123 \
  -v $(pwd)/docker-data/minio:/data \
  -p 9000:9000 -p 9001:9001 \
  minio/minio server /data --console-address ":9001"
```

### 2. 启动后端

```bash
cd backend

# 方式1: 使用 Maven (需要 Java 21)
mvn spring-boot:run

# 方式2: 打包后运行
mvn clean package -DskipTests
java -jar target/ai-task-os-backend-0.0.1-SNAPSHOT.jar

# 方式3: 使用 Docker
docker build -t aitaskos-backend -f Dockerfile.backend ..
docker run -d --name aitaskos-backend --network aitaskos-net \
  -e DB_HOST=aitaskos-postgres -e REDIS_HOST=aitaskos-redis \
  -p 8080:8080 aitaskos-backend
```

### 3. 启动前端

```bash
cd frontend
pnpm install
pnpm dev
```

## 四、访问地址

| 服务 | 地址 |
|------|------|
| 前端 | http://localhost:5173 |
| API 文档 (Swagger) | http://localhost:8080/swagger-ui.html |
| MinIO 控制台 | http://localhost:9001 |

### 默认账号

| 服务 | 用户名 | 密码 |
|------|--------|------|
| PostgreSQL | aitaskos | aitaskos123 |
| Redis | - | (无密码) |
| MinIO | minioadmin | minioadmin123 |

## 五、环境变量说明

创建 `.env` 文件（参考 `.env.example`）：

```bash
# 数据库
POSTGRES_PASSWORD=aitaskos123

# Redis
REDIS_PASSWORD=  # 可选

# MinIO
MINIO_ROOT_USER=minioadmin
MINIO_ROOT_PASSWORD=minioadmin123

# AI 服务 (必须配置)
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=sk-xxx
AI_MODEL=gpt-4o-mini

# JWT 密钥 (生产环境请修改)
JWT_SECRET=please-change-this-to-a-secure-secret-at-least-256-bits-long
```

## 六、常见问题

### Q: 后端启动失败 "Java version error"
A: 项目需要 Java 21，请安装 JDK 21 或使用 Docker 运行

### Q: 数据库连接失败
A: 确保 PostgreSQL 容器已启动且端口 5432 未被占用

### Q: 前端无法访问后端 API
A: 检查后端是否在 8080 端口运行，检查 CORS 配置

### Q: Maven 下载依赖很慢
A: 配置阿里云镜像，在 `~/.m2/settings.xml` 中添加：

```xml
<mirrors>
  <mirror>
    <id>aliyun</id>
    <mirrorOf>central</mirrorOf>
    <url>https://maven.aliyun.com/repository/public</url>
  </mirror>
</mirrors>
```

## 七、停止服务

```bash
# 停止应用
./start.sh stop

# 停止并移除所有容器
./start.sh down
```

## 八、项目结构

```
ai-task-os/
├── backend/           # Java Spring Boot 后端
├── frontend/          # React TypeScript 前端
├── android/           # Android App (预留)
├── harmony/           # 鸿蒙 App (预留)
├── specs/             # 规格文档
├── docker-compose.yml # Docker Compose 配置
├── Dockerfile.backend # 后端 Dockerfile
├── Dockerfile.frontend# 前端 Dockerfile
├── start.sh           # 启动脚本
└── .env.example       # 环境变量模板
```
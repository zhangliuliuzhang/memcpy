import { useEffect, useState } from 'react';
import { taskApi } from '@/services/taskApi';
import { useAuthStore } from '@/stores/authStore';
import { useNavigate } from 'react-router-dom';
import type { TodayDashboardResponse, Task, TaskParseResult } from '@/types';
import { formatSmart, formatRelative, getPriorityColor, getTaskTypeLabel } from '@/utils';

export function TodayPage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();
  const [dashboard, setDashboard] = useState<TodayDashboardResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [quickInput, setQuickInput] = useState('');
  const [parseResult, setParseResult] = useState<TaskParseResult | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    loadDashboard();
  }, [isAuthenticated, navigate]);

  const loadDashboard = async () => {
    setLoading(true);
    try {
      const res = await taskApi.getTodayDashboard();
      if (res.success) {
        setDashboard(res.data);
      }
    } catch (error) {
      console.error('Failed to load dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickCreate = async () => {
    if (!quickInput.trim()) return;

    try {
      // 先解析
      const parseRes = await taskApi.parseTask(quickInput);
      if (parseRes.success) {
        setParseResult(parseRes.data);

        if (parseRes.data.needUserConfirm) {
          setShowConfirmModal(true);
        } else {
          // 直接创建
          await createTaskFromParse(parseRes.data);
        }
      }
    } catch (error) {
      console.error('Failed to parse task:', error);
    }
  };

  const createTaskFromParse = async (result: TaskParseResult) => {
    try {
      const res = await taskApi.createTask({
        title: result.title,
        taskType: result.taskType as Task['taskType'],
        startTime: result.startTime,
        deadline: result.deadline,
        estimatedMinutes: result.estimatedMinutes,
        priority: result.priority,
      });

      if (res.success) {
        setQuickInput('');
        setParseResult(null);
        setShowConfirmModal(false);
        loadDashboard();
      }
    } catch (error) {
      console.error('Failed to create task:', error);
    }
  };

  const handleStartTask = async (taskId: number) => {
    try {
      await taskApi.startTask(taskId);
      loadDashboard();
    } catch (error) {
      console.error('Failed to start task:', error);
    }
  };

  const handleResumeTask = async (taskId: number) => {
    try {
      await taskApi.resumeTask(taskId);
      navigate(`/tasks/${taskId}`);
    } catch (error) {
      console.error('Failed to resume task:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-gray-500">加载中...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* 顶部快速输入 */}
      <div className="bg-white dark:bg-gray-800 shadow-sm p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex gap-2">
            <input
              type="text"
              value={quickInput}
              onChange={(e) => setQuickInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleQuickCreate()}
              placeholder="输入任务，例如：下周五晚上8点前交开题报告，预计要写10小时"
              className="flex-1 px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
            />
            <button
              onClick={handleQuickCreate}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              创建
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* 正在进行的任务 */}
        {dashboard?.doing && dashboard.doing.length > 0 && (
          <Section title="正在进行">
            <div className="space-y-2">
              {dashboard.doing.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onAction={() => navigate(`/tasks/${task.id}`)}
                  actionText="继续"
                />
              ))}
            </div>
          </Section>
        )}

        {/* 需要恢复的任务 */}
        {dashboard?.needResume && dashboard.needResume.length > 0 && (
          <Section title="需要恢复">
            <div className="space-y-2">
              {dashboard.needResume.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onAction={() => handleResumeTask(task.id)}
                  actionText="继续"
                  highlight
                />
              ))}
            </div>
          </Section>
        )}

        {/* 今日必须处理 */}
        {dashboard?.mustDoToday && dashboard.mustDoToday.length > 0 && (
          <Section title="今日必须处理">
            <div className="space-y-2">
              {dashboard.mustDoToday.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onAction={() => handleStartTask(task.id)}
                  actionText="开始"
                />
              ))}
            </div>
          </Section>
        )}

        {/* AI 已完成 */}
        {dashboard?.aiDone && dashboard.aiDone.length > 0 && (
          <Section title="AI 已完成">
            <div className="space-y-2">
              {dashboard.aiDone.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onAction={() => navigate(`/tasks/${task.id}`)}
                  actionText="查看"
                />
              ))}
            </div>
          </Section>
        )}

        {/* 今日复习 */}
        {dashboard?.reviewItems && dashboard.reviewItems.length > 0 && (
          <Section title="今日复习">
            <div className="space-y-2">
              {dashboard.reviewItems.map((task) => (
                <TaskCard
                  key={task.id}
                  task={task}
                  onAction={() => handleStartTask(task.id)}
                  actionText="开始"
                />
              ))}
            </div>
          </Section>
        )}

        {/* 空状态 */}
        {(!dashboard || (
          (dashboard.doing?.length || 0) +
          (dashboard.needResume?.length || 0) +
          (dashboard.mustDoToday?.length || 0) +
          (dashboard.aiDone?.length || 0) +
          (dashboard.reviewItems?.length || 0)
        ) === 0) && (
          <div className="text-center py-12 text-gray-500 dark:text-gray-400">
            暂无任务，在上方输入框创建新任务吧
          </div>
        )}
      </div>

      {/* 确认弹窗 */}
      {showConfirmModal && parseResult && (
        <ConfirmModal
          result={parseResult}
          onConfirm={() => createTaskFromParse(parseResult)}
          onCancel={() => {
            setShowConfirmModal(false);
            setParseResult(null);
          }}
        />
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">{title}</h2>
      {children}
    </div>
  );
}

function TaskCard({
  task,
  onAction,
  actionText,
  highlight = false,
}: {
  task: Task;
  onAction: () => void;
  actionText: string;
  highlight?: boolean;
}) {
  return (
    <div
      className={`p-4 rounded-lg border ${
        highlight
          ? 'border-yellow-300 bg-yellow-50 dark:bg-yellow-900/20'
          : 'border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800'
      }`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <h3 className="font-medium text-gray-900 dark:text-white">{task.title}</h3>
          <div className="mt-1 flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
            <span className={getPriorityColor(task.priority)}>P{task.priority}</span>
            <span>·</span>
            <span>{getTaskTypeLabel(task.taskType)}</span>
            {task.deadline && (
              <>
                <span>·</span>
                <span>{formatSmart(task.deadline)}</span>
              </>
            )}
          </div>
        </div>
        <button
          onClick={onAction}
          className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
        >
          {actionText}
        </button>
      </div>
    </div>
  );
}

function ConfirmModal({
  result,
  onConfirm,
  onCancel,
}: {
  result: TaskParseResult;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">确认任务信息</h3>

        <div className="space-y-3 text-sm">
          <div>
            <span className="text-gray-500 dark:text-gray-400">标题：</span>
            <span className="text-gray-900 dark:text-white">{result.title}</span>
          </div>
          <div>
            <span className="text-gray-500 dark:text-gray-400">类型：</span>
            <span className="text-gray-900 dark:text-white">{getTaskTypeLabel(result.taskType)}</span>
          </div>
          {result.deadline && (
            <div>
              <span className="text-gray-500 dark:text-gray-400">截止时间：</span>
              <span className="text-gray-900 dark:text-white">{formatSmart(result.deadline)}</span>
            </div>
          )}
          {result.estimatedMinutes && (
            <div>
              <span className="text-gray-500 dark:text-gray-400">预计耗时：</span>
              <span className="text-gray-900 dark:text-white">{result.estimatedMinutes} 分钟</span>
            </div>
          )}
        </div>

        <div className="mt-6 flex justify-end gap-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded"
          >
            取消
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            确认创建
          </button>
        </div>
      </div>
    </div>
  );
}
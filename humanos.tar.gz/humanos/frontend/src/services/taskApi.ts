import { api } from './api';
import type {
  CreateTaskRequest,
  Task,
  TaskParseResult,
  TodayDashboardResponse,
  ApiResponse,
  StartTaskRequest,
} from '@/types';

export const taskApi = {
  parseTask: (text: string) =>
    api.post<TaskParseResult>('/ai/parse-task', { text }),

  createTask: (data: CreateTaskRequest) =>
    api.post<Task>('/tasks', data),

  getTask: (taskId: number) =>
    api.get<Task>(`/tasks/${taskId}`),

  getTasks: (params?: { status?: string; taskType?: string; page?: number; size?: number }) =>
    api.get<ApiResponse.PageResult<Task>>('/tasks', { params }),

  getTodayDashboard: () =>
    api.get<TodayDashboardResponse>('/tasks/today'),

  updateTask: (taskId: number, data: CreateTaskRequest) =>
    api.put<Task>(`/tasks/${taskId}`, data),

  deleteTask: (taskId: number) =>
    api.delete<void>(`/tasks/${taskId}`),

  startTask: (taskId: number, data?: StartTaskRequest) =>
    api.post<Task>(`/tasks/${taskId}/start`, data),

  pauseTask: (taskId: number, data?: { rawInput?: string; pauseReason?: string }) =>
    api.post<Task>(`/tasks/${taskId}/pause`, data),

  resumeTask: (taskId: number) =>
    api.post<Task>(`/tasks/${taskId}/resume`),

  completeTask: (taskId: number, data?: { resultSummary?: string }) =>
    api.post<Task>(`/tasks/${taskId}/complete`, data),

  cancelTask: (taskId: number, data?: { reason?: string }) =>
    api.post<Task>(`/tasks/${taskId}/cancel`, data),
};
import { api } from './api';
import type {
  LoginRequest,
  LoginResponse,
  RegisterRequest,
  User,
  UserResponse,
  RefreshTokenResponse,
} from '@/types';

export const authApi = {
  register: (data: RegisterRequest) =>
    api.post<UserResponse>('/auth/register', data),

  login: (data: LoginRequest) =>
    api.post<LoginResponse>('/auth/login', data),

  refreshToken: (refreshToken: string) =>
    api.post<RefreshTokenResponse>('/auth/refresh', { refreshToken }),

  logout: () => api.post<void>('/auth/logout'),

  getCurrentUser: () => api.get<UserResponse>('/auth/me'),
};
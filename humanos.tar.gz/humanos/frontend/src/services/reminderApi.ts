import { api } from './api';
import type {
  CreateReminderRuleRequest,
  ReminderRule,
  ReminderEvent,
  CreateSnapshotRequest,
  ResumeCardResponse,
} from '@/types';

export const reminderApi = {
  createRule: (data: CreateReminderRuleRequest) =>
    api.post<ReminderRule>('/reminders/rules', data),

  getTaskRules: (taskId: number) =>
    api.get<ReminderRule[]>(`/reminders/tasks/${taskId}/rules`),

  deleteRule: (ruleId: number) =>
    api.delete<void>(`/reminders/rules/${ruleId}`),

  getTodayReminders: () =>
    api.get<ReminderEvent[]>('/reminders/today'),

  getUpcomingReminders: (hours = 24) =>
    api.get<ReminderEvent[]>('/reminders/upcoming', { params: { hours } }),

  snoozeEvent: (eventId: number, minutes = 30) =>
    api.post<ReminderEvent>(`/reminders/events/${eventId}/snooze`, null, {
      params: { minutes },
    }),

  markEventDone: (eventId: number) =>
    api.post<void>(`/reminders/events/${eventId}/done`),

  ignoreEvent: (eventId: number) =>
    api.post<void>(`/reminders/events/${eventId}/ignore`),
};

export const snapshotApi = {
  createSnapshot: (taskId: number, data: CreateSnapshotRequest) =>
    api.post(`/ai/tasks/${taskId}/pause-with-snapshot`, data),

  getResumeCard: (taskId: number) =>
    api.get<ResumeCardResponse>(`/tasks/${taskId}/resume-card`),
};
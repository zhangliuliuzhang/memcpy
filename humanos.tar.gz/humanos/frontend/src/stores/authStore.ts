import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface User {
  id: number;
  username: string;
  email: string;
  avatarUrl?: string;
  timezone: string;
  settings: Record<string, unknown>;
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  deviceId: string | null;
  isAuthenticated: boolean;

  // Actions
  setUser: (user: User | null) => void;
  setTokens: (accessToken: string, refreshToken: string) => void;
  setDeviceId: (deviceId: string) => void;
  login: (user: User, accessToken: string, refreshToken: string, deviceId: string) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
}

// 生成设备ID
const generateDeviceId = (): string => {
  const stored = localStorage.getItem('deviceId');
  if (stored) return stored;

  const id = `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
  localStorage.setItem('deviceId', id);
  return id;
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      deviceId: generateDeviceId(),
      isAuthenticated: false,

      setUser: (user) => set({ user, isAuthenticated: !!user }),

      setTokens: (accessToken, refreshToken) =>
        set({ accessToken, refreshToken }),

      setDeviceId: (deviceId) => set({ deviceId }),

      login: (user, accessToken, refreshToken, deviceId) =>
        set({
          user,
          accessToken,
          refreshToken,
          deviceId,
          isAuthenticated: true,
        }),

      logout: () =>
        set({
          user: null,
          accessToken: null,
          refreshToken: null,
          isAuthenticated: false,
        }),

      updateUser: (updates) => {
        const { user } = get();
        if (user) {
          set({ user: { ...user, ...updates } });
        }
      },
    }),
    {
      name: 'auth-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        refreshToken: state.refreshToken,
        deviceId: state.deviceId,
      }),
    }
  )
);
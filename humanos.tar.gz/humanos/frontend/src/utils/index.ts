import { format, formatDistanceToNow, isToday, isYesterday, isTomorrow, parseISO } from 'date-fns';
import { zhCN } from 'date-fns/locale';

/**
 * 格式化日期时间
 */
export function formatDateTime(date: string | Date, pattern = 'yyyy-MM-dd HH:mm'): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return format(d, pattern, { locale: zhCN });
}

/**
 * 格式化日期
 */
export function formatDate(date: string | Date): string {
  return formatDateTime(date, 'yyyy-MM-dd');
}

/**
 * 格式化时间
 */
export function formatTime(date: string | Date): string {
  return formatDateTime(date, 'HH:mm');
}

/**
 * 智能格式化：今天/昨天/明天 + 时间
 */
export function formatSmart(date: string | Date): string {
  const d = typeof date === 'string' ? parseISO(date) : date;

  if (isToday(d)) {
    return `今天 ${format(d, 'HH:mm', { locale: zhCN })}`;
  }
  if (isYesterday(d)) {
    return `昨天 ${format(d, 'HH:mm', { locale: zhCN })}`;
  }
  if (isTomorrow(d)) {
    return `明天 ${format(d, 'HH:mm', { locale: zhCN })}`;
  }

  return format(d, 'MM-dd HH:mm', { locale: zhCN });
}

/**
 * 相对时间：几秒前、几分钟前、几小时前等
 */
export function formatRelative(date: string | Date): string {
  const d = typeof date === 'string' ? parseISO(date) : date;
  return formatDistanceToNow(d, { addSuffix: true, locale: zhCN });
}

/**
 * 格式化时长（分钟数转 x小时x分钟）
 */
export function formatDuration(minutes: number): string {
  if (minutes <= 0) return '0分钟';

  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;

  const parts: string[] = [];
  if (hours > 0) parts.push(`${hours}小时`);
  if (mins > 0) parts.push(`${mins}分钟`);

  return parts.join('') || '0分钟';
}

/**
 * 计算剩余时间（毫秒）
 */
export function getTimeRemaining(deadline: string | Date): number {
  const d = typeof deadline === 'string' ? parseISO(deadline) : deadline;
  return d.getTime() - Date.now();
}

/**
 * 格式化剩余时间
 */
export function formatTimeRemaining(deadline: string | Date): string {
  const remaining = getTimeRemaining(deadline);

  if (remaining <= 0) return '已过期';

  const seconds = Math.floor(remaining / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);

  if (days > 0) return `${days}天${hours % 24}小时`;
  if (hours > 0) return `${hours}小时${minutes % 60}分钟`;
  if (minutes > 0) return `${minutes}分钟`;
  return `${seconds}秒`;
}

// ==================== 验证器 ====================

/**
 * 验证邮箱
 */
export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

/**
 * 验证手机号（中国大陆）
 */
export function validatePhone(phone: string): boolean {
  const re = /^1[3-9]\d{9}$/;
  return re.test(phone);
}

/**
 * 验证用户名（字母数字下划线，3-20字符）
 */
export function validateUsername(username: string): boolean {
  const re = /^[a-zA-Z0-9_]{3,20}$/;
  return re.test(username);
}

/**
 * 验证密码强度（至少8位，包含字母和数字）
 */
export function validatePassword(password: string): { valid: boolean; message: string } {
  if (password.length < 8) {
    return { valid: false, message: '密码至少8位' };
  }
  if (!/[a-zA-Z]/.test(password)) {
    return { valid: false, message: '密码需包含字母' };
  }
  if (!/\d/.test(password)) {
    return { valid: false, message: '密码需包含数字' };
  }
  return { valid: true, message: '' };
}

// ==================== 其他工具 ====================

/**
 * 生成唯一ID
 */
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
}

/**
 * 防抖
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let timer: ReturnType<typeof setTimeout>;

  return function (this: unknown, ...args: Parameters<T>) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}

/**
 * 节流
 */
export function throttle<T extends (...args: unknown[]) => unknown>(
  fn: T,
  delay: number
): (...args: Parameters<T>) => void {
  let last = 0;

  return function (this: unknown, ...args: Parameters<T>) {
    const now = Date.now();
    if (now - last >= delay) {
      last = now;
      fn.apply(this, args);
    }
  };
}

/**
 * 深拷贝
 */
export function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}

/**
 * 优先级颜色
 */
export function getPriorityColor(priority: number): string {
  const colors = {
    1: 'text-red-500',
    2: 'text-orange-500',
    3: 'text-yellow-500',
    4: 'text-blue-500',
    5: 'text-gray-500',
  };
  return colors[priority as keyof typeof colors] || colors[3];
}

/**
 * 任务状态颜色
 */
export function getTaskStatusColor(status: string): string {
  const colors: Record<string, string> = {
    TODO: 'text-gray-500',
    PLANNED: 'text-blue-500',
    DOING: 'text-green-500',
    PAUSED: 'text-yellow-500',
    AI_RUNNING: 'text-purple-500',
    WAITING: 'text-orange-500',
    DONE: 'text-gray-400',
    CANCELLED: 'text-red-400',
  };
  return colors[status] || 'text-gray-500';
}

/**
 * 任务类型标签
 */
export function getTaskTypeLabel(type: string): string {
  const labels: Record<string, string> = {
    NORMAL: '普通任务',
    DEADLINE: '截止任务',
    SCHEDULED: '定时任务',
    LONG_TERM: '长期任务',
    MEMORY: '复习任务',
    AI_DELEGATED: 'AI 代理',
  };
  return labels[type] || type;
}
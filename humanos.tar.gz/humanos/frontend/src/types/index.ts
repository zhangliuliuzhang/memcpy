// ==================== 通用类型 ====================

export interface BaseEntity {
  id: number;
  createdAt: string;
  updatedAt?: string;
}

// ==================== 用户相关 ====================

export type UserStatus = 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'DELETED';

export interface User extends BaseEntity {
  username: string;
  email: string;
  phone?: string;
  avatarUrl?: string;
  status: UserStatus;
  timezone: string;
  settings: UserSettings;
}

export interface UserSettings {
  theme?: 'light' | 'dark' | 'system';
  language?: string;
  notificationEnabled?: boolean;
}

export interface UserDevice extends BaseEntity {
  userId: number;
  deviceType: 'WEB' | 'ANDROID' | 'HARMONY';
  deviceId: string;
  deviceName?: string;
  pushToken?: string;
  enabled: boolean;
  lastActiveAt?: string;
}

// ==================== 任务相关 ====================

export type TaskType = 'NORMAL' | 'DEADLINE' | 'SCHEDULED' | 'LONG_TERM' | 'MEMORY' | 'AI_DELEGATED';
export type TaskStatus = 'TODO' | 'PLANNED' | 'DOING' | 'PAUSED' | 'AI_RUNNING' | 'WAITING' | 'DONE' | 'CANCELLED';

export interface Task extends BaseEntity {
  userId: number;
  title: string;
  description?: string;
  taskType: TaskType;
  status: TaskStatus;
  priority: number;
  startTime?: string;
  deadline?: string;
  estimatedMinutes?: number;
  actualMinutes?: number;
  progress: number;
  currentSnapshotId?: number;
  lastActiveTime?: string;
  deletedAt?: string;
  version: number;
}

export interface TaskSession extends BaseEntity {
  userId: number;
  taskId: number;
  startedAt: string;
  pausedAt?: string;
  endedAt?: string;
  durationMinutes: number;
  sessionGoal?: string;
  resultSummary?: string;
  snapshotId?: number;
}

export interface TaskSnapshot extends BaseEntity {
  userId: number;
  taskId: number;
  snapshotType: 'PAUSE' | 'SWITCH' | 'AI' | 'STAGE' | 'COMPLETE';
  rawInput?: string;
  aiSummary?: string;
  currentProgress?: string;
  pauseReason?: string;
  nextAction?: string;
  openQuestions: string[];
  relatedFiles: RelatedFile[];
  relatedNotes: RelatedNote[];
}

export interface RelatedFile {
  fileId: number;
  fileName: string;
}

export interface RelatedNote {
  noteId: number;
  title: string;
}

// ==================== 笔记相关 ====================

export type NoteType = 'RAW' | 'AI_SUMMARY' | 'REVIEW';
export type SourceType = 'TEXT' | 'VOICE' | 'IMAGE' | 'FILE' | 'CODE' | 'LINK';

export interface Note extends BaseEntity {
  userId: number;
  taskId?: number;
  title: string;
  content: string;
  noteType: NoteType;
  sourceType: SourceType;
  sourceSnapshotId?: number;
}

// ==================== 提醒相关 ====================

export type RuleType = 'START' | 'DEADLINE' | 'REPEAT' | 'REVIEW' | 'INACTIVE' | 'PROGRESS' | 'AI_DONE';
export type EventStatus = 'PENDING' | 'SENT' | 'SNOOZED' | 'DONE' | 'IGNORED' | 'CANCELLED';

export interface ReminderRule extends BaseEntity {
  userId: number;
  taskId: number;
  ruleType: RuleType;
  cronExpr?: string;
  intervalMinutes?: number;
  beforeDeadlineMinutes?: number;
  triggerTime?: string;
  enabled: boolean;
}

export interface ReminderEvent extends BaseEntity {
  userId: number;
  taskId: number;
  ruleId: number;
  triggerTime: string;
  status: EventStatus;
  snoozeUntil?: string;
  message?: string;
}

// ==================== 通知相关 ====================

export type NotificationType = 'REMINDER' | 'AI_DONE' | 'REVIEW' | 'SYSTEM';
export type ActionType = 'START_TASK' | 'VIEW_TASK' | 'RESUME_TASK' | 'VIEW_NOTE' | 'CONFIRM_AI';

export interface Notification extends BaseEntity {
  userId: number;
  taskId?: number;
  reminderEventId?: number;
  notificationType: NotificationType;
  title: string;
  content: string;
  readStatus: boolean;
  actionType?: ActionType;
  actionData: Record<string, unknown>;
}

// ==================== AI 相关 ====================

export type JobType = 'PARSE' | 'SUMMARY' | 'RESUME' | 'NOTE' | 'REVIEW' | 'REMINDER_PLAN' | 'CHAT';
export type JobStatus = 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED' | 'CANCELLED';

export interface AiJob extends BaseEntity {
  userId: number;
  taskId?: number;
  snapshotId?: number;
  noteId?: number;
  jobType: JobType;
  status: JobStatus;
  inputPayload: Record<string, unknown>;
  outputPayload: Record<string, unknown>;
  errorMessage?: string;
  latencyMs?: number;
}

// ==================== 文件相关 ====================

export type FileSource = 'UPLOAD' | 'VOICE' | 'SCREENSHOT' | 'CODE';

export interface FileEntity extends BaseEntity {
  userId: number;
  taskId?: number;
  noteId?: number;
  fileName: string;
  fileType: string;
  storagePath: string;
  sizeBytes: number;
  checksum?: string;
  source: FileSource;
}

// ==================== API 请求/响应类型 ====================

export interface LoginRequest {
  login: string; // username or email
  password: string;
  deviceId: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  phone?: string;
}

export interface LoginResponse {
  user: User;
  accessToken: string;
  refreshToken: string;
  deviceId: string;
}

export interface TaskParseRequest {
  text: string;
}

export interface TaskParseResponse {
  title: string;
  taskType: TaskType;
  startTime?: string;
  deadline?: string;
  estimatedMinutes?: number;
  priority?: number;
  reminderRules?: ReminderRuleSuggestion[];
  needUserConfirm: boolean;
}

export interface ReminderRuleSuggestion {
  type: RuleType;
  description: string;
  triggerTime?: string;
  intervalMinutes?: number;
  beforeDeadlineMinutes?: number;
}

export interface CreateTaskRequest {
  title: string;
  description?: string;
  taskType: TaskType;
  startTime?: string;
  deadline?: string;
  estimatedMinutes?: number;
  priority?: number;
}

export interface PauseTaskRequest {
  inputType: 'TEXT' | 'VOICE' | 'FILE';
  content: string;
  files?: number[];
}

export interface PauseTaskResponse {
  snapshotId: number;
  summary: string;
  nextAction: string;
  reminderSuggestion?: string;
}

export interface ResumeTaskResponse {
  taskTitle: string;
  lastProgress: string;
  pauseReason?: string;
  openQuestions: string[];
  nextAction: string;
  relatedNotes: Note[];
  relatedFiles: FileEntity[];
}

export interface TodayDashboardResponse {
  doing: Task[];
  mustDoToday: Task[];
  needResume: Task[];
  aiDone: Task[];
  reviewItems: Task[];
}
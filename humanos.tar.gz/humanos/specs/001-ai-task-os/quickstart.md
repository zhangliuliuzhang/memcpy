# Quickstart: AI Task OS

**Branch**: `001-ai-task-os`
**Date**: 2026-06-23

---

## Prerequisites

| 依赖 | 版本 | 说明 |
|------|------|------|
| Java JDK | 21 (LTS) | 或 Java 17 |
| Maven | 3.9+ | 构建工具 |
| Node.js | 20 LTS | 前端构建 |
| pnpm | 9+ | 前端包管理 |
| Docker | 24+ | 容器运行时 |
| Docker Compose | 2.20+ | 多容器编排 |

---

## Quick Start (Docker Compose)

### 1. 克隆项目

```bash
git clone <repo-url>
cd ai-task-os
```

### 2. 配置环境变量

```bash
cp .env.example .env
```

编辑 `.env`：

```env
# Database
POSTGRES_PASSWORD=your-secure-password

# Redis
REDIS_PASSWORD=your-redis-password

# MinIO
MINIO_ROOT_USER=admin
MINIO_ROOT_PASSWORD=your-minio-password

# AI Service
AI_BASE_URL=https://api.openai.com/v1
AI_API_KEY=sk-xxx
AI_MODEL=gpt-4o-mini

# JWT
JWT_SECRET=your-jwt-secret-at-least-256-bits
```

### 3. 启动服务

```bash
docker compose up -d
```

### 4. 访问应用

- **Web 前端**: http://localhost
- **API 文档**: http://localhost:8080/swagger-ui.html
- **MinIO 控制台**: http://localhost:9001

### 5. 创建测试账号

```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"test","email":"test@example.com","password":"Test123456"}'
```

---

## Development Setup

### 后端开发

```bash
cd backend

# 安装依赖
mvn install

# 运行数据库迁移
mvn flyway:migrate -Dflyway.url=jdbc:postgresql://localhost:5432/aitaskos \
  -Dflyway.user=aitaskos -Dflyway.password=your-password

# 启动开发服务器
mvn spring-boot:run

# 运行测试
mvn test
```

**开发模式环境变量**（`application-dev.yml`）：

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/aitaskos
    username: aitaskos
    password: ${POSTGRES_PASSWORD}
  data:
    redis:
      host: localhost
      port: 6379
      password: ${REDIS_PASSWORD}

ai:
  openai:
    base-url: ${AI_BASE_URL:https://api.openai.com/v1}
    api-key: ${AI_API_KEY}
    model: ${AI_MODEL:gpt-4o-mini}

minio:
  endpoint: http://localhost:9000
  access-key: ${MINIO_ROOT_USER}
  secret-key: ${MINIO_ROOT_PASSWORD}
  bucket: aitaskos
```

### 前端开发

```bash
cd frontend

# 安装依赖
pnpm install

# 启动开发服务器
pnpm dev

# 构建
pnpm build

# 类型检查
pnpm typecheck

# Lint
pnpm lint
```

**环境变量**（`.env.local`）：

```env
VITE_API_BASE_URL=http://localhost:8080/api
VITE_WS_URL=ws://localhost:8080/ws
```

---

## Project Structure

```
ai-task-os/
├── backend/                    # Java Spring Boot 后端
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/taskos/
│   │   │   │   ├── TaskOsApplication.java
│   │   │   │   ├── common/           # 通用模块（config, exception, response, security, utils）
│   │   │   │   ├── user/             # 用户模块
│   │   │   │   ├── task/             # 任务模块
│   │   │   │   ├── reminder/         # 提醒模块
│   │   │   │   ├── snapshot/         # 快照模块
│   │   │   │   ├── note/             # 笔记模块
│   │   │   │   ├── ai/               # AI 模块
│   │   │   │   ├── review/           # 复习模块
│   │   │   │   ├── notification/     # 通知模块
│   │   │   │   ├── file/             # 文件模块
│   │   │   │   └── workspace/        # 工作台模块
│   │   │   └── resources/
│   │   │       ├── application.yml
│   │   │       ├── application-dev.yml
│   │   │       ├── application-prod.yml
│   │   │       └── db/migration/     # Flyway 迁移脚本
│   │   └── test/
│   └── pom.xml
│
├── frontend/                   # React Web 前端
│   ├── src/
│   │   ├── components/         # UI 组件
│   │   ├── pages/              # 页面
│   │   ├── services/           # API 调用
│   │   ├── stores/             # 状态管理（Zustand）
│   │   ├── hooks/              # 自定义 hooks
│   │   ├── utils/              # 工具函数
│   │   └── types/              # TypeScript 类型
│   ├── public/
│   ├── package.json
│   ├── pnpm-lock.yaml
│   ├── vite.config.ts
│   └── tsconfig.json
│
├── android/                    # Android App（轻壳）
│   ├── app/
│   │   ├── src/main/java/com/taskos/app/
│   │   │   ├── MainActivity.kt
│   │   │   ├── WebViewFragment.kt
│   │   │   └── NotificationService.kt
│   │   └── build.gradle.kts
│   └── build.gradle.kts
│
├── harmony/                    # 鸿蒙 App（轻壳）
│   ├── entry/
│   │   └── src/main/ets/
│   │       ├── entryability/
│   │       └── pages/
│   │           └── Index.ets
│   └── build-profile.json5
│
├── specs/                      # 规格文档
│   └── 001-ai-task-os/
│       ├── spec.md
│       ├── research.md
│       ├── data-model.md
│       ├── quickstart.md       # 本文件
│       ├── contracts/          # API 契约
│       └── tasks.md            # 任务列表（由 /speckit-tasks 生成）
│
├── docker-compose.yml
├── Dockerfile.backend
├── Dockerfile.frontend
├── .env.example
└── README.md
```

---

## Database Migrations

使用 Flyway 管理 schema 版本。

### 创建新迁移

```bash
# 在 backend/src/main/resources/db/migration/ 下创建
V002__add_task_version.sql
```

内容示例：

```sql
-- V002__add_task_version.sql
ALTER TABLE tasks ADD COLUMN version INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN version INTEGER NOT NULL DEFAULT 0;
```

### 执行迁移

```bash
mvn flyway:migrate
```

### 查看状态

```bash
mvn flyway:info
```

---

## Testing

### 后端单元测试

```bash
cd backend
mvn test
```

### 后端集成测试

```bash
mvn verify -Pintegration-test
```

需要启动 Testcontainers（PostgreSQL + Redis）。

### 前端测试

```bash
cd frontend
pnpm test
```

---

## API Documentation

启动后端后访问：

- **Swagger UI**: http://localhost:8080/swagger-ui.html
- **OpenAPI JSON**: http://localhost:8080/v3/api-docs

---

## Environment Variables

### 后端（application.yml 覆盖）

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `SPRING_PROFILES_ACTIVE` | 环境 | `dev` |
| `POSTGRES_URL` | 数据库 URL | `jdbc:postgresql://localhost:5432/aitaskos` |
| `POSTGRES_USER` | 数据库用户 | `aitaskos` |
| `POSTGRES_PASSWORD` | 数据库密码 | - |
| `REDIS_HOST` | Redis 主机 | `localhost` |
| `REDIS_PASSWORD` | Redis 密码 | - |
| `AI_BASE_URL` | AI 服务 URL | `https://api.openai.com/v1` |
| `AI_API_KEY` | AI API Key | - |
| `AI_MODEL` | 模型名 | `gpt-4o-mini` |
| `JWT_SECRET` | JWT 签名密钥 | - |
| `MINIO_ENDPOINT` | MinIO 端点 | `http://localhost:9000` |
| `MINIO_ACCESS_KEY` | MinIO 用户 | - |
| `MINIO_SECRET_KEY` | MinIO 密码 | - |

### 前端

| 变量 | 说明 |
|------|------|
| `VITE_API_BASE_URL` | API 地址 |
| `VITE_WS_URL` | WebSocket 地址 |

---

## Deployment

### Docker 镜像构建

```bash
# 后端
docker build -f Dockerfile.backend -t ai-task-os-backend:latest .

# 前端
docker build -f Dockerfile.frontend -t ai-task-os-frontend:latest .
```

### 生产部署

```bash
docker compose -f docker-compose.prod.yml up -d
```

---

## Troubleshooting

### 常见问题

**Q: 数据库连接失败**
```bash
# 检查 PostgreSQL 是否运行
docker compose ps postgres

# 查看日志
docker compose logs postgres
```

**Q: AI 调用失败**
```bash
# 检查配置
curl -I https://api.openai.com/v1/models \
  -H "Authorization: Bearer $AI_API_KEY"
```

**Q: MinIO 文件上传失败**
```bash
# 检查 bucket 是否存在
mc alias set local http://localhost:9000 admin your-password
mc ls local/
mc mb local/aitaskos
```

**Q: 前端 API 调用 CORS 错误**
确保后端配置了正确的 CORS：
```yaml
spring:
  web:
    cors:
      allowed-origins: "http://localhost:5173"
      allowed-methods: "*"
      allowed-headers: "*"
      allow-credentials: true
```

---

## Next Steps

1. 阅读 [spec.md](./spec.md) 了解完整需求
2. 阅读 [data-model.md](./data-model.md) 了解数据结构
3. 阅读 [contracts/](./contracts/) 了解 API 接口
4. 运行 `/speckit-tasks` 生成任务列表开始开发
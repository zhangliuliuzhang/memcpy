# Users & Devices API Contract

**Base URL**: `/api/users`
**Auth**: Bearer JWT 必需

---

## GET /devices

查询当前用户的所有设备。

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 2001,
        "deviceType": "WEB",
        "deviceName": "Chrome on macOS",
        "deviceId": "browser-uuid-abc",
        "pushTokenEnabled": true,
        "lastActiveAt": "2026-06-23T18:00:00Z",
        "isCurrent": true
      },
      {
        "id": 2002,
        "deviceType": "ANDROID",
        "deviceName": "Pixel 8",
        "deviceId": "android-udid-xyz",
        "pushTokenEnabled": true,
        "lastActiveAt": "2026-06-22T09:00:00Z",
        "isCurrent": false
      }
    ]
  }
}
```

---

## DELETE /devices/{id}

强制下线指定设备（吊销该设备的 refresh token）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "deviceId": 2002,
    "revokedAt": "2026-06-23T18:30:00Z"
  }
}
```

---

## PATCH /devices/{id}

更新设备配置。

### Request

```json
{
  "pushTokenEnabled": false,
  "deviceName": "My Phone"
}
```

### Response 200

```json
{
  "code": 0,
  "data": { ...更新后的设备 }
}
```

---

## GET /settings

查询用户偏好设置。

### Response 200

```json
{
  "code": 0,
  "data": {
    "theme": "auto",
    "language": "zh-CN",
    "timezone": "Asia/Shanghai",
    "reminderDefaultTime": "21:00",
    "sttEnabled": true,
    "ai": {
      "baseUrl": "https://api.openai.com/v1",
      "model": "gpt-4o-mini"
    },
    "notification": {
      "inApp": true,
      "webSse": true,
      "webPush": false,
      "androidPush": true
    },
    "reviewIntervalDays": [1, 3, 7, 14]
  }
}
```

---

## PATCH /settings

更新用户偏好设置。

### Request

```json
{
  "theme": "dark",
  "ai": {
    "baseUrl": "https://my-llm.example.com/v1"
  }
}
```

### Response 200

```json
{
  "code": 0,
  "data": { ...更新后的设置 }
}
```

---

## POST /change-password

修改密码。

### Request

```json
{
  "oldPassword": "...",
  "newPassword": "..."
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "changedAt": "2026-06-23T19:00:00Z",
    "revokedOtherDevices": true
  }
}
```

修改密码后自动吊销其他设备的 refresh token（除当前设备）。

### Errors

- `40102`: 旧密码错误
- `40001`: 新密码不符合强度要求

---

## POST /export-data

导出用户数据（合规预留接口）。

### Response 202

```json
{
  "code": 0,
  "data": {
    "jobId": "export-abc-123",
    "status": "PROCESSING",
    "estimatedTime": "5-10 minutes"
  }
}
```

导出完成后通过邮件或通知发送下载链接。

---

## DELETE /account

注销账号（软删除，30 天内可恢复）。

### Request

```json
{
  "password": "...",
  "reason": "不再使用"
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "scheduledDeletionAt": "2026-07-23T00:00:00Z"
  }
}
```
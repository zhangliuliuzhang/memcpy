# API Contracts: AI Task OS

**Branch**: `001-ai-task-os`
**Date**: 2026-06-23
**Base URL**: `/api`
**Auth**: Bearer JWT（除 `/api/auth/*` 外所有接口）

---

## Conventions

### HTTP Methods

- `GET`: 查询，无副作用
- `POST`: 创建或触发动作
- `PUT`: 全量更新
- `PATCH`: 部分更新
- `DELETE`: 删除（软删除）

### Headers

| Header | 必需 | 说明 |
|--------|------|------|
| `Authorization: Bearer <access_token>` | ✅ | 鉴权（除登录接口） |
| `X-User-Timezone` | ⚠️ 前端自动 | 时区 ID（例如 `Asia/Shanghai`） |
| `X-Device-Id` | ⚠️ App 自动 | 设备唯一标识 |
| `X-Device-Type` | ⚠️ App 自动 | `WEB` / `ANDROID` / `HARMONY` |
| `Content-Type: application/json` | ✅ | 除文件上传外 |
| `Accept-Language` | ⚠️ | 用户偏好语言（影响 AI 输出语言） |

### Response Envelope

所有响应统一格式：

```json
{
  "code": 0,
  "message": "success",
  "data": { ... },
  "traceId": "uuid-v4"
}
```

错误响应：

```json
{
  "code": 40001,
  "message": "Task not found",
  "data": null,
  "traceId": "uuid-v4"
}
```

### Error Codes

| Range | 含义 |
|-------|------|
| `0` | 成功 |
| `40001-40099` | 客户端参数错误 |
| `40100-40199` | 鉴权错误 |
| `40300-40399` | 权限错误 |
| `40400-40499` | 资源不存在 |
| `40900-40999` | 冲突（并发、状态非法） |
| `42200-42299` | 业务校验失败 |
| `50000-50099` | 服务器内部错误 |
| `50200-50299` | 第三方服务错误（AI、对象存储） |

---

## Contract Files

详细契约按模块拆分：

- [auth.md](./auth.md): 鉴权接口（注册、登录、刷新、登出）
- [tasks.md](./tasks.md): 任务接口（CRUD、状态流转、解析、暂停/恢复）
- [reminders.md](./reminders.md): 提醒接口（规则、事件、处理动作）
- [notifications.md](./notifications.md): 通知接口（站内通知、SSE 推送）
- [ai.md](./ai.md): AI 接口（解析、总结、恢复建议、笔记整理、复习卡片、对话）
- [notes.md](./notes.md): 笔记接口（CRUD、暂存箱、AI 整理）
- [files.md](./files.md): 文件接口（上传、下载、列表）
- [snapshots.md](./snapshots.md): 快照接口（时间线、详情）
- [users.md](./users.md): 用户接口（个人信息、设备管理、设置）
- [dashboard.md](./dashboard.md): 驾驶舱接口（今日任务聚合）
- [review.md](./review.md): 复习接口（今日复习、复习卡片）

---

## Common Types

### TaskType (enum)

```
NORMAL | DEADLINE | SCHEDULED | LONG_TERM | MEMORY | AI_DELEGATED
```

### TaskStatus (enum)

```
TODO | PLANNED | DOING | PAUSED | AI_RUNNING | WAITING | DONE | CANCELLED
```

### ReminderRuleType (enum)

```
START | DEADLINE | REPEAT | REVIEW | INACTIVE | PROGRESS | AI_DONE
```

### NotificationType (enum)

```
REMINDER | AI_DONE | REVIEW | SYSTEM
```

### NoteType (enum)

```
RAW | AI_SUMMARY | REVIEW
```

### Pagination

```
GET /api/resource?page=1&size=20&sort=created_at,desc

Response:
{
  "code": 0,
  "data": {
    "items": [...],
    "total": 100,
    "page": 1,
    "size": 20,
    "hasMore": true
  }
}
```

### Timestamps

所有时间字段使用 ISO 8601 格式：
- 带时区：`2026-06-26T20:00:00+08:00`
- UTC：`2026-06-26T12:00:00Z`

后端按 `X-User-Timezone` 转换。
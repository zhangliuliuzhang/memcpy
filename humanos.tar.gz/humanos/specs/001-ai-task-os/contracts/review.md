# Review API Contract

**Base URL**: `/api/review`
**Auth**: Bearer JWT 必需

---

## GET /today

今日复习项。

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 5005,
        "taskId": 5005,
        "taskTitle": "英语单词",
        "reviewDay": 3,
        "triggerTime": "2026-06-23T19:00:00+08:00",
        "cardPreview": {
          "title": "英语单词 - 3天后复习",
          "keyConceptsCount": 5,
          "recallQuestionsCount": 3
        }
      }
    ],
    "totalCount": 1,
    "pendingOverdue": 0
  }
}
```

---

## GET /cards/{taskId}

获取复习卡片内容。

### Query Parameters

| 参数 | 类型 | 说明 |
|------|------|------|
| `reviewDay` | int | 第几天复习（1/3/7/14） |

### Response 200

```json
{
  "code": 0,
  "data": {
    "taskId": 5005,
    "taskTitle": "英语单词",
    "reviewDay": 3,
    "card": {
      "title": "英语单词 - 3天后复习",
      "keyConcepts": [
        {
          "concept": "ubiquitous",
          "definition": "present everywhere",
          "recallQuestion": "用 ubiquitous 造句"
        }
      ],
      "lastSummary": "学习了一组高频词",
      "recallQuestions": [
        "Q1: 列出 3 个 ubiquitous 的同义词",
        "Q2: 这些词的语境差异？"
      ],
      "relatedNoteIds": [2030, 2031]
    },
    "generatedAt": "2026-06-20T10:00:00Z"
  }
}
```

### Errors

- `40401`: 该任务没有第 N 天的复习卡片

---

## POST /cards/{taskId}/regenerate

重新生成复习卡片（AI 重新整理）。

### Request

```json
{
  "reviewDay": 7,
  "instruction": "聚焦于应用题"
}
```

### Response 202

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9020,
    "status": "PENDING"
  }
}
```

---

## POST /events/{reminderEventId}/complete

标记复习完成。

### Response 200

```json
{
  "code": 0,
  "data": {
    "eventId": 8050,
    "status": "DONE",
    "nextReviewAt": "2026-06-30T19:00:00+08:00",
    "nextReviewDay": 7
  }
}
```

---

## GET /long-inactive

长期未碰的任务（建议整理）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 5010,
        "title": "半年前的项目",
        "lastActiveTime": "2025-12-15T10:00:00Z",
        "daysInactive": 190,
        "status": "PAUSED",
        "suggestions": [
          "archive: 归档任务",
          "review: 整理旧笔记",
          "delete: 彻底删除"
        ]
      }
    ]
  }
}
```

---

## POST /notes/refine

整理旧笔记（AI 把零散记录整合）。

### Request

```json
{
  "taskId": 5010,
  "instruction": "把所有笔记整合为一份阶段总结"
}
```

### Response 202

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9025,
    "status": "PENDING"
  }
}
```
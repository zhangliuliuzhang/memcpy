# AI API Contract

**Base URL**: `/api/ai`
**Auth**: Bearer JWT 必需

---

## Overview

AI 接口统一封装所有 AI 调用。所有 AI 输出必须为结构化 JSON，由后端按 schema 校验。

### Async Pattern

AI 调用支持两种模式：
- **同步**（小任务，<5s）：解析任务、快照总结、笔记整理
- **异步**（大任务）：用户委托 AI 任务（`POST /tasks/{id}/delegate`）

同步接口在 AI 失败时降级返回兜底结果（保留用户原文）。

---

## POST /parse-task

解析用户自然语言为任务字段。

### Request

```json
{
  "text": "下周五晚上8点前交开题报告，预计写10小时，每天晚上提醒我推进一下",
  "context": {
    "userTimezone": "Asia/Shanghai",
    "userLanguage": "zh-CN"
  }
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9001,
    "title": "完成开题报告",
    "taskType": "DEADLINE",
    "startTime": null,
    "deadline": "2026-06-26T20:00:00",
    "estimatedMinutes": 600,
    "priority": 2,
    "reminderRules": [
      {
        "type": "REPEAT",
        "description": "每天晚上提醒推进"
      },
      {
        "type": "DEADLINE",
        "description": "截止前1天提醒"
      },
      {
        "type": "DEADLINE",
        "description": "截止前3小时提醒"
      },
      {
        "type": "DEADLINE",
        "description": "截止前30分钟提醒"
      }
    ],
    "confidence": 0.95,
    "needsClarification": []
  }
}
```

### Response 200 (兜底降级)

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9001,
    "title": "下周五晚上8点前交开题报告，预计写10小时，每天晚上提醒我推进一下",
    "taskType": "NORMAL",
    "confidence": 0.0,
    "needsClarification": ["AI 解析失败，请手动补充字段"],
    "fallback": true
  }
}
```

### Errors

- `50201`: AI 服务不可用（已降级处理，仍返回 200 + fallback:true）

---

## POST /summarize-snapshot

总结用户暂停输入，生成结构化快照。

### Request

```json
{
  "taskId": 5001,
  "rawInput": "我写到第二章理论模型这里了，但是缺三篇文献，下一步要先查资料。",
  "context": {
    "taskTitle": "论文第二章",
    "taskType": "DEADLINE",
    "deadline": "2026-06-26T20:00:00+08:00",
    "recentNotes": [
      { "title": "理论模型草稿", "content": "..." }
    ]
  }
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9002,
    "snapshotId": 3001,
    "aiSummary": "你已完成第二章部分内容，当前卡在理论模型资料补充。",
    "currentProgress": "第二章理论模型部分已开始",
    "pauseReason": "资料不足",
    "nextAction": "先查找三篇相关文献，再补充理论模型部分。",
    "openQuestions": [
      "缺少三篇相关文献"
    ],
    "reminderSuggestion": "建议明天上午10点提醒你继续。"
  }
}
```

---

## POST /generate-resume-card

生成任务恢复卡片。

### Request

```json
{
  "taskId": 5001,
  "latestSnapshotId": 3001
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9003,
    "resumeCard": {
      "taskTitle": "论文第二章",
      "lastProgress": "已写到理论模型部分",
      "pauseReason": "缺少相关文献",
      "openQuestions": [
        "需要补充三篇文献",
        "理论模型逻辑还不完整"
      ],
      "nextAction": "先查找文献，再补充模型假设",
      "recommendedDuration": "20-30 分钟"
    }
  }
}
```

---

## POST /generate-reminder-plan

生成提醒计划（基于任务信息）。

### Request

```json
{
  "taskId": 5001
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9004,
    "reminderRules": [
      {
        "type": "DEADLINE",
        "beforeDeadlineMinutes": 1440,
        "message": "开题报告还有1天截止"
      },
      {
        "type": "DEADLINE",
        "beforeDeadlineMinutes": 180,
        "message": "开题报告还有3小时截止"
      },
      {
        "type": "DEADLINE",
        "beforeDeadlineMinutes": 30,
        "message": "开题报告还有30分钟截止"
      },
      {
        "type": "REPEAT",
        "cronExpr": "0 0 21 * * ?",
        "message": "推进一下开题报告"
      }
    ],
    "explanation": "基于任务类型（截止）和预计工作量（10小时 > 4小时），生成了多级提醒+每日推进提醒。"
  }
}
```

---

## POST /refine-note

把零散记录整理为结构化笔记。

### Request

```json
{
  "taskId": 5001,
  "sourceNoteIds": [2001, 2002, 2003],
  "instruction": "整理为理论模型章节的阶段总结"
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9005,
    "noteId": 2010,
    "title": "理论模型阶段总结",
    "content": "# 理论模型\n\n## 已完成\n- 第二章...\n\n## 问题清单\n- [ ] 需要补充三篇文献\n\n## 决策记录\n- ...\n\n## 下一步\n1. 查找文献\n2. 补充假设",
    "metadata": {
      "progress": "已完成第二章部分",
      "openQuestions": ["需要补充三篇文献"],
      "decisions": [],
      "stageSummary": "..."
    }
  }
}
```

---

## POST /generate-review-card

生成复习卡片。

### Request

```json
{
  "taskId": 5001,
  "reviewDay": 3,
  "context": {
    "stageSummary": "理论模型已完成",
    "keyConcepts": ["假设", "验证方法"]
  }
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "aiJobId": 9006,
    "reviewCard": {
      "title": "论文理论模型 - 3天后复习",
      "keyConcepts": [
        {
          "concept": "理论模型",
          "definition": "...",
          "recallQuestion": "你的理论模型核心假设是什么？"
        }
      ],
      "lastSummary": "理论模型部分已完成，使用了 5 篇文献。",
      "recallQuestions": [
        "Q1: 模型的关键假设是什么？",
        "Q2: 验证方法选择了什么？为什么？"
      ],
      "relatedNoteIds": [2010, 2011]
    }
  }
}
```

---

## POST /chat

AI 对话（基于当前任务上下文）。

### Request

```json
{
  "taskId": 5001,
  "message": "我上次卡在哪里了？",
  "history": [
    { "role": "user", "content": "..." },
    { "role": "assistant", "content": "..." }
  ]
}
```

### Response 200 (非流式)

```json
{
  "code": 0,
  "data": {
    "reply": "你上次卡在理论模型部分，缺少三篇相关文献。建议先查找文献。",
    "contextReferences": [
      { "type": "snapshot", "id": 3001 },
      { "type": "note", "id": 2010 }
    ]
  }
}
```

---

## GET /chat/stream

AI 对话（流式 SSE）。

### Query Parameters

| 参数 | 类型 | 说明 |
|------|------|------|
| `taskId` | long | 任务 ID |
| `message` | string | 用户消息（URL encoded） |

### Response (text/event-stream)

```
event: start
data: {"aiJobId": 9007}

event: delta
data: {"content": "你"}

event: delta
data: {"content": "上次"}

event: delta
data: {"content": "卡在"}

event: references
data: {"contextReferences": [{"type":"snapshot","id":3001}]}

event: done
data: {"aiJobId": 9007, "totalLatencyMs": 1200}
```

---

## GET /jobs/{id}

查询 AI 任务状态（用于异步结果轮询）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "id": 9002,
    "jobType": "SUMMARY",
    "status": "SUCCESS",
    "outputPayload": {
      "aiSummary": "...",
      "nextAction": "..."
    },
    "latencyMs": 1500,
    "createdAt": "2026-06-23T15:30:00Z"
  }
}
```

### Status

- `PENDING`: 排队中
- `RUNNING`: AI 处理中
- `SUCCESS`: 成功
- `FAILED`: 失败
- `CANCELLED`: 已取消

### Errors

- `40401`: Job 不存在
- `40301`: 无权访问
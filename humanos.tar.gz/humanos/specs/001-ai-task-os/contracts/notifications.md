# Notifications API Contract

**Base URL**: `/api/notifications`
**Auth**: Bearer JWT 必需

---

## GET /?...

查询通知列表。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `readStatus` | bool | - | 已读状态筛选 |
| `type` | string | - | 类型筛选（REMINDER/AI_DONE/REVIEW/SYSTEM） |
| `page` | int | 1 | 页码 |
| `size` | int | 20 | 每页数量 |

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 10001,
        "taskId": 5001,
        "notificationType": "REMINDER",
        "title": "任务即将截止",
        "content": "开题报告还有3小时截止",
        "readStatus": false,
        "actionType": "START_TASK",
        "actionData": {
          "taskId": 5001,
          "url": "/tasks/5001"
        },
        "createdAt": "2026-06-23T20:00:00Z"
      }
    ],
    "total": 5,
    "page": 1,
    "size": 20,
    "hasMore": false,
    "unreadCount": 3
  }
}
```

---

## GET /unread-count

获取未读数量（用于顶部 badge）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "total": 3,
    "byType": {
      "REMINDER": 2,
      "AI_DONE": 1,
      "REVIEW": 0,
      "SYSTEM": 0
    }
  }
}
```

---

## PATCH /{id}/read

标记单条为已读。

### Response 200

```json
{
  "code": 0,
  "data": { "id": 10001, "readStatus": true }
}
```

---

## POST /read-all

标记全部已读。

### Response 200

```json
{
  "code": 0,
  "data": { "updatedCount": 5 }
}
```

---

## DELETE /{id}

删除单条通知。

### Response 200

```json
{
  "code": 0,
  "data": null
}
```

---

## GET /stream

SSE 实时推送通道。

### Request

```
GET /api/notifications/stream
Authorization: Bearer <token>
Accept: text/event-stream
```

### Response (text/event-stream)

连接成功后服务端定期发送心跳（每 30 秒）：

```
event: ping
data: {"timestamp": "2026-06-23T20:00:00Z"}
```

新通知到达时：

```
event: notification
data: {
  "id": 10002,
  "taskId": 5001,
  "notificationType": "REMINDER",
  "title": "...",
  "content": "...",
  "actionType": "START_TASK",
  "actionData": {...},
  "createdAt": "2026-06-23T21:00:00Z"
}

event: unread-count
data: {"total": 4}
```

### Reconnection

前端使用 `EventSource` 自动重连（默认 3 秒）。服务端支持 `Last-Event-ID` header 续传。

---

## POST /device-token

注册 App 推送 token。

### Request

```json
{
  "deviceId": "abc-123",
  "platform": "ANDROID",
  "token": "<FCM token>",
  "provider": "FCM"
}
```

`platform`: `WEB` | `ANDROID` | `HARMONY`
`provider`: `FCM` | `APNS` | `HMS` | `WEB_PUSH`

### Response 200

```json
{
  "code": 0,
  "data": {
    "registered": true,
    "deviceId": "abc-123"
  }
}
```

---

## DELETE /device-token

注销推送 token（用户关闭通知权限时）。

### Request

```json
{
  "deviceId": "abc-123"
}
```

### Response 200

```json
{
  "code": 0,
  "data": { "unregistered": true }
}
```
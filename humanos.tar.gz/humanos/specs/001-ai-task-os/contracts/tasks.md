# Tasks API Contract

**Base URL**: `/api/tasks`
**Auth**: Bearer JWT 必需

---

## POST /parse

自然语言解析任务（不创建任务）。

### Request

```json
{
  "text": "下周五晚上8点前交开题报告，预计写10小时，每天晚上提醒我推进一下"
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "title": "完成开题报告",
    "description": null,
    "taskType": "DEADLINE",
    "startTime": null,
    "deadline": "2026-06-26T20:00:00",
    "estimatedMinutes": 600,
    "priority": 2,
    "reminderRules": [
      {
        "type": "REPEAT",
        "description": "每天晚上提醒推进"
      },
      {
        "type": "DEADLINE",
        "description": "截止前1天提醒"
      }
    ],
    "confidence": 0.95,
    "needsClarification": []
  }
}
```

### Response 206 (Partial)

当 AI 无法完全解析时：

```json
{
  "code": 0,
  "data": {
    "title": "做点事",
    "taskType": "NORMAL",
    "startTime": null,
    "deadline": null,
    "estimatedMinutes": null,
    "priority": 2,
    "reminderRules": [],
    "confidence": 0.3,
    "needsClarification": [
      "无法识别任务类型，请补充",
      "无法识别截止时间，请补充"
    ]
  }
}
```

### Errors

- `50201`: AI 服务不可用（前端展示"解析失败，请手动填写"）

---

## POST /

创建任务。

### Request

```json
{
  "title": "完成开题报告",
  "description": "需要完成并提交",
  "taskType": "DEADLINE",
  "startTime": null,
  "deadline": "2026-06-26T20:00:00",
  "estimatedMinutes": 600,
  "priority": 2,
  "reminderEnabled": true,
  "reviewEnabled": false,
  "reminderRules": [
    {
      "type": "REPEAT",
      "cronExpr": "0 0 21 * * ?",
      "messageTemplate": "推进一下「完成开题报告」"
    }
  ]
}
```

### Response 201

```json
{
  "code": 0,
  "data": {
    "id": 5001,
    "userId": 1001,
    "title": "完成开题报告",
    "taskType": "DEADLINE",
    "status": "TODO",
    "priority": 2,
    "startTime": null,
    "deadline": "2026-06-26T20:00:00",
    "estimatedMinutes": 600,
    "progress": 0,
    "lastActiveTime": "2026-06-23T10:00:00Z",
    "reminderEnabled": true,
    "reviewEnabled": false,
    "createdAt": "2026-06-23T10:00:00Z",
    "updatedAt": "2026-06-23T10:00:00Z",
    "version": 0,
    "reminders": [
      {
        "id": 7001,
        "ruleType": "REPEAT",
        "cronExpr": "0 0 21 * * ?",
        "enabled": true
      }
    ],
    "upcomingEvents": [
      {
        "id": 8001,
        "triggerTime": "2026-06-23T21:00:00+08:00",
        "message": "推进一下「完成开题报告」"
      }
    ]
  }
}
```

### Errors

- `40001`: 参数校验失败
- `42201`: `DEADLINE` 类型必须设置 `deadline`

---

## GET /?...

查询任务列表。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `status` | string | - | 状态筛选，逗号分隔（例如 `DOING,PAUSED`） |
| `type` | string | - | 类型筛选 |
| `priorityMin` | int | - | 最低优先级 |
| `deadlineBefore` | datetime | - | 截止时间早于 |
| `deadlineAfter` | datetime | - | 截止时间晚于 |
| `lastActiveBefore` | datetime | - | 最近活跃早于 |
| `keyword` | string | - | 标题/描述模糊搜索 |
| `includeDeleted` | bool | false | 包含回收站任务 |
| `page` | int | 1 | 页码 |
| `size` | int | 20 | 每页数量 |
| `sort` | string | `created_at,desc` | 排序 |

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 5001,
        "title": "完成开题报告",
        "taskType": "DEADLINE",
        "status": "DOING",
        "priority": 2,
        "deadline": "2026-06-26T20:00:00+08:00",
        "progress": 30,
        "lastActiveTime": "2026-06-23T14:00:00Z",
        "version": 3
      }
    ],
    "total": 42,
    "page": 1,
    "size": 20,
    "hasMore": false
  }
}
```

---

## GET /today

今日驾驶舱聚合数据。

### Response 200

```json
{
  "code": 0,
  "data": {
    "doing": [
      { "id": 5001, "title": "...", "startTime": "...", "sessionGoal": "..." }
    ],
    "mustDoToday": [
      { "id": 5002, "title": "...", "deadline": "..." }
    ],
    "needResume": [
      {
        "id": 5003,
        "title": "...",
        "lastActiveTime": "...",
        "pauseReason": "..."
      }
    ],
    "aiDone": [
      { "id": 5004, "title": "...", "aiJobId": 9001 }
    ],
    "reviewItems": [
      {
        "id": 5005,
        "title": "...",
        "reviewDay": 3,
        "triggerTime": "..."
      }
    ]
  }
}
```

---

## GET /{id}

查询任务详情。

### Response 200

```json
{
  "code": 0,
  "data": {
    "id": 5001,
    "userId": 1001,
    "title": "完成开题报告",
    "description": "需要完成并提交",
    "taskType": "DEADLINE",
    "status": "PAUSED",
    "priority": 2,
    "startTime": null,
    "deadline": "2026-06-26T20:00:00+08:00",
    "estimatedMinutes": 600,
    "actualMinutes": 180,
    "progress": 30,
    "currentSnapshot": {
      "id": 3001,
      "aiSummary": "已完成第二章部分内容，当前卡在理论模型资料补充。",
      "currentProgress": "第二章理论模型部分已开始",
      "pauseReason": "资料不足",
      "nextAction": "先查找三篇相关文献，再补充理论模型部分。",
      "openQuestions": ["缺少三篇相关文献"],
      "createdAt": "2026-06-23T14:00:00Z"
    },
    "lastActiveTime": "2026-06-23T14:00:00Z",
    "createdAt": "2026-06-22T09:00:00Z",
    "version": 3
  }
}
```

### Errors

- `40401`: 任务不存在
- `40301`: 无权访问（不属于当前用户）

---

## PATCH /{id}

更新任务字段。

### Request

```json
{
  "title": "新标题",
  "deadline": "2026-06-27T20:00:00",
  "priority": 3,
  "version": 3
}
```

`version` 必填（乐观锁）。

### Response 200

```json
{
  "code": 0,
  "data": { ...更新后的任务对象, "version": 4 }
}
```

### Errors

- `40901`: 版本冲突（前端应重新加载后重试）

---

## DELETE /{id}

软删除任务（进回收站）。

### Response 200

```json
{
  "code": 0,
  "data": { "deletedAt": "2026-06-23T15:00:00Z" }
}
```

---

## POST /{id}/restore

从回收站恢复。

### Response 200

```json
{
  "code": 0,
  "data": { ...恢复后的任务对象 }
}
```

---

## POST /{id}/start

开始任务（状态：TODO/PLANNED → DOING）。

### Request

```json
{
  "sessionGoal": "完成理论模型部分初稿"
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "taskId": 5001,
    "status": "DOING",
    "sessionId": 6001,
    "startedAt": "2026-06-23T15:00:00Z"
  }
}
```

### Errors

- `40902`: 状态非法（任务已是 DOING 或已完成）

---

## POST /{id}/pause

暂停任务（状态：DOING → PAUSED）。

### Request

```json
{
  "inputType": "TEXT",
  "content": "我写到第二章理论模型这里了，但是缺三篇文献，下一步要先查资料。",
  "files": [123, 124]
}
```

`inputType`: `TEXT` | `VOICE`

### Response 200

```json
{
  "code": 0,
  "data": {
    "taskId": 5001,
    "status": "PAUSED",
    "snapshotId": 3001,
    "sessionId": 6001,
    "pausedAt": "2026-06-23T15:30:00Z",
    "aiSummary": "你已完成第二章部分内容，当前卡在理论模型资料补充。",
    "currentProgress": "第二章理论模型部分已开始",
    "pauseReason": "资料不足",
    "nextAction": "先查找三篇相关文献，再补充理论模型部分。",
    "openQuestions": ["缺少三篇相关文献"],
    "reminderSuggestion": "建议明天上午10点提醒你继续。",
    "aiJobId": 9001
  }
}
```

### Notes

- 后端立即返回 snapshotId（使用 raw_input），AI 异步处理。
- 前端可轮询 `GET /ai/jobs/{aiJobId}` 或等待 SSE 推送获取 AI 总结。

---

## POST /{id}/resume

恢复任务（状态：PAUSED → DOING）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "taskId": 5001,
    "status": "DOING",
    "sessionId": 6002,
    "resumeCard": {
      "taskTitle": "论文第二章",
      "lastProgress": "已写到理论模型部分",
      "pauseReason": "缺少相关文献",
      "openQuestions": [
        "需要补充三篇文献",
        "理论模型逻辑还不完整"
      ],
      "nextAction": "先查找文献，再补充模型假设",
      "relatedNotes": [
        { "id": 2001, "title": "理论模型草稿", "noteType": "RAW" }
      ],
      "relatedFiles": [
        { "id": 123, "fileName": "outline.pdf", "fileType": "application/pdf" }
      ]
    }
  }
}
```

---

## POST /{id}/complete

完成任务。

### Request

```json
{
  "resultSummary": "理论模型已补充完整，共引用5篇文献。"
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "taskId": 5001,
    "status": "DONE",
    "completedAt": "2026-06-23T18:00:00Z",
    "actualMinutes": 240
  }
}
```

---

## POST /{id}/cancel

取消任务。

### Response 200

```json
{
  "code": 0,
  "data": {
    "taskId": 5001,
    "status": "CANCELLED"
  }
}
```

---

## POST /{id}/delegate

委托给 AI（状态：DOING/PAUSED → AI_RUNNING）。

### Request

```json
{
  "instruction": "帮我搜集5篇关于LLM推理的论文"
}
```

### Response 202

```json
{
  "code": 0,
  "data": {
    "taskId": 5001,
    "status": "AI_RUNNING",
    "aiJobId": 9002
  }
}
```
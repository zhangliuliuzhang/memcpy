# Dashboard API Contract

**Base URL**: `/api/dashboard`
**Auth**: Bearer JWT 必需

---

## GET /today

今日驾驶舱聚合数据（推荐前端首屏使用）。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `userTimezone` | string | from header | 时区覆盖 |

### Response 200

```json
{
  "code": 0,
  "data": {
    "date": "2026-06-23",
    "doing": [
      {
        "id": 5001,
        "title": "完成开题报告",
        "status": "DOING",
        "sessionGoal": "完成理论模型部分初稿",
        "startedAt": "2026-06-23T15:00:00Z",
        "elapsedMinutes": 45
      }
    ],
    "mustDoToday": [
      {
        "id": 5002,
        "title": "提交项目计划书",
        "deadline": "2026-06-23T20:00:00+08:00",
        "hoursUntilDeadline": 2.5
      }
    ],
    "needResume": [
      {
        "id": 5003,
        "title": "论文第二章",
        "lastActiveTime": "2026-06-20T14:00:00Z",
        "daysInactive": 3,
        "pauseReason": "缺少相关文献"
      }
    ],
    "aiDone": [
      {
        "id": 5004,
        "title": "收集论文",
        "aiJobId": 9008,
        "completedAt": "2026-06-23T16:00:00Z"
      }
    ],
    "reviewItems": [
      {
        "id": 5005,
        "title": "英语单词",
        "reviewDay": 3,
        "triggerTime": "2026-06-23T19:00:00+08:00"
      }
    ],
    "recentNotes": [
      {
        "id": 2010,
        "taskId": 5001,
        "taskTitle": "完成开题报告",
        "title": "理论模型草稿",
        "preview": "...",
        "createdAt": "2026-06-23T14:30:00Z"
      }
    ],
    "stats": {
      "totalActiveTasks": 12,
      "completedToday": 2,
      "focusTimeTodayMinutes": 120
    }
  }
}
```

---

## GET /summary

周报/月报统计（简化版）。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `period` | string | `WEEK` | `WEEK` / `MONTH` |
| `date` | date | today | 起始日期 |

### Response 200

```json
{
  "code": 0,
  "data": {
    "period": "WEEK",
    "startDate": "2026-06-17",
    "endDate": "2026-06-23",
    "stats": {
      "tasksCompleted": 8,
      "focusTimeMinutes": 720,
      "tasksResumed": 5,
      "reviewCompleted": 12,
      "newTasksCreated": 10
    },
    "byDay": [
      { "date": "2026-06-17", "focusTimeMinutes": 90, "tasksCompleted": 1 },
      { "date": "2026-06-18", "focusTimeMinutes": 120, "tasksCompleted": 2 }
    ]
  }
}
```
# Snapshots API Contract

**Base URL**: `/api/snapshots`
**Auth**: Bearer JWT 必需

---

## GET /task/{taskId}

查询任务的时间线（所有快照）。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `limit` | int | 50 | 最多返回数量 |
| `before` | datetime | - | 返回此时间之前的（分页） |

### Response 200

```json
{
  "code": 0,
  "data": {
    "taskId": 5001,
    "items": [
      {
        "id": 3005,
        "snapshotType": "PAUSE",
        "aiSummary": "已完成理论模型部分，需要补充文献。",
        "currentProgress": "理论模型部分已完成",
        "pauseReason": "缺少文献",
        "nextAction": "查找5篇相关文献",
        "openQuestions": ["需要补充三篇文献"],
        "createdAt": "2026-06-23T18:00:00Z"
      },
      {
        "id": 3004,
        "snapshotType": "PAUSE",
        "aiSummary": "...",
        "createdAt": "2026-06-22T15:00:00Z"
      },
      {
        "id": 3003,
        "snapshotType": "STAGE",
        "aiSummary": "完成第一章",
        "createdAt": "2026-06-21T10:00:00Z"
      }
    ],
    "hasMore": false,
    "nextCursor": null
  }
}
```

---

## GET /{id}

查询快照详情。

### Response 200

```json
{
  "code": 0,
  "data": {
    "id": 3005,
    "userId": 1001,
    "taskId": 5001,
    "snapshotType": "PAUSE",
    "rawInput": "我写到第二章理论模型这里了，但是缺三篇文献，下一步要先查资料。",
    "aiSummary": "你已完成第二章部分内容，当前卡在理论模型资料补充。",
    "currentProgress": "第二章理论模型部分已开始",
    "pauseReason": "资料不足",
    "nextAction": "先查找三篇相关文献，再补充理论模型部分。",
    "openQuestions": [
      "缺少三篇相关文献"
    ],
    "relatedFiles": [
      { "id": 123, "fileName": "outline.pdf" }
    ],
    "relatedNotes": [
      { "id": 2001, "title": "理论模型草稿" }
    ],
    "sessionId": 6005,
    "aiJobId": 9002,
    "createdAt": "2026-06-23T18:00:00Z"
  }
}
```

---

## GET /{id}/raw

仅获取用户原始输入（用于 AI 失败时展示原文）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "id": 3005,
    "rawInput": "我写到第二章理论模型这里了，但是缺三篇文献，下一步要先查资料。",
    "aiFailed": false
  }
}
```

---

## POST /{id}/retry-ai

重新触发 AI 总结（用户手动重试）。

### Response 202

```json
{
  "code": 0,
  "data": {
    "snapshotId": 3005,
    "aiJobId": 9010,
    "status": "PENDING"
  }
}
```
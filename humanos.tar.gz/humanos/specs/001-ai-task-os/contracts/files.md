# Files API Contract

**Base URL**: `/api/files`
**Auth**: Bearer JWT 必需

---

## POST /upload

上传文件（multipart/form-data）。

### Request

```
POST /api/files/upload HTTP/1.1
Content-Type: multipart/form-data; boundary=...
Authorization: Bearer <token>

------boundary
Content-Disposition: form-data; name="file"; filename="screenshot.png"
Content-Type: image/png

<binary data>
------boundary
Content-Disposition: form-data; name="taskId"

5001
------boundary
Content-Disposition: form-data; name="source"

SCREENSHOT
------boundary--
```

### Fields

| 字段 | 类型 | 必需 | 说明 |
|------|------|------|------|
| `file` | binary | ✅ | 文件内容 |
| `taskId` | long | - | 关联任务 |
| `noteId` | long | - | 关联笔记 |
| `source` | string | - | 来源（UPLOAD/VOICE/SCREENSHOT） |

### Response 201

```json
{
  "code": 0,
  "data": {
    "id": 125,
    "userId": 1001,
    "taskId": 5001,
    "fileName": "screenshot.png",
    "fileType": "image/png",
    "sizeBytes": 102400,
    "checksum": "sha256-abc...",
    "source": "SCREENSHOT",
    "createdAt": "2026-06-23T15:00:00Z",
    "downloadUrl": "/api/files/125/download?token=..."
  }
}
```

### Errors

- `40001`: 文件类型不在白名单
- `41301`: 文件超过 50MB 限制
- `50202`: 对象存储服务不可用

---

## GET /{id}

查询文件元数据。

### Response 200

```json
{
  "code": 0,
  "data": {
    "id": 125,
    "fileName": "screenshot.png",
    "fileType": "image/png",
    "sizeBytes": 102400,
    "source": "SCREENSHOT",
    "taskId": 5001,
    "noteId": null,
    "createdAt": "2026-06-23T15:00:00Z",
    "downloadUrl": "/api/files/125/download?token=...&expires=..."
  }
}
```

---

## GET /{id}/download

下载文件。

### Query Parameters

| 参数 | 类型 | 说明 |
|------|------|------|
| `token` | string | 签名 token（来自 `/files/{id}` 响应） |

### Response 200

```
Content-Type: <original file type>
Content-Disposition: attachment; filename="screenshot.png"
Content-Length: 102400

<binary data>
```

`token` 有效期 1 小时，单次使用。

---

## GET /?...

查询文件列表。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `taskId` | long | - | 筛选任务 |
| `noteId` | long | - | 筛选笔记 |
| `source` | string | - | 筛选来源 |
| `page` | int | 1 | |
| `size` | int | 20 | |

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 125,
        "fileName": "screenshot.png",
        "fileType": "image/png",
        "sizeBytes": 102400,
        "createdAt": "2026-06-23T15:00:00Z",
        "downloadUrl": "..."
      }
    ],
    "total": 5,
    "page": 1,
    "size": 20
  }
}
```

---

## DELETE /{id}

删除文件。

### Response 200

```json
{
  "code": 0,
  "data": null
}
```

---

## POST /voice

上传语音记录（multipart/form-data，专用接口）。

### Request

```
------boundary
Content-Disposition: form-data; name="audio"; filename="voice.webm"
Content-Type: audio/webm

<binary data>
------boundary
Content-Disposition: form-data; name="taskId"

5001
------boundary
Content-Disposition: form-data; name="transcript"

我刚想到一个想法关于理论模型
------boundary--
```

### Response 201

```json
{
  "code": 0,
  "data": {
    "fileId": 130,
    "noteId": 2050,
    "transcript": "我刚想到一个想法关于理论模型",
    "transcribeConfidence": 0.95,
    "message": "已保存到任务「完成开题报告」"
  }
}
```

### Notes

- 转文字由前端端侧 STT 完成（Web Speech API / Android SpeechRecognizer / 鸿蒙 AsrController）
- 后端只接收转写后的文本（`transcript` 字段），原音频仅用于回放
- 如果前端无法转写（浏览器不支持），`transcript` 为空，后端仅保存音频
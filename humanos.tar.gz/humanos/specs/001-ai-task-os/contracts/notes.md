# Notes API Contract

**Base URL**: `/api/notes`
**Auth**: Bearer JWT 必需

---

## POST /

创建笔记。

### Request

```json
{
  "taskId": 5001,
  "title": "理论模型草稿",
  "content": "# 理论模型\n\n...",
  "noteType": "RAW",
  "sourceType": "TEXT",
  "sourceSnapshotId": null,
  "fileIds": [123]
}
```

`taskId` 可为 null（暂存箱）。

### Response 201

```json
{
  "code": 0,
  "data": {
    "id": 2001,
    "userId": 1001,
    "taskId": 5001,
    "title": "理论模型草稿",
    "content": "# 理论模型\n\n...",
    "noteType": "RAW",
    "sourceType": "TEXT",
    "createdAt": "2026-06-23T15:00:00Z",
    "updatedAt": "2026-06-23T15:00:00Z"
  }
}
```

---

## POST /quick

快速记录（用于全局快速记录入口）。

### Request

```json
{
  "content": "刚想到一个想法",
  "sourceType": "TEXT",
  "taskBinding": {
    "type": "CURRENT_TASK",
    "taskId": 5001
  }
}
```

或

```json
{
  "content": "...",
  "sourceType": "VOICE",
  "voiceFileId": 125,
  "taskBinding": {
    "type": "INBOX"
  }
}
```

`taskBinding.type`:
- `CURRENT_TASK`: 绑定到当前 DOING 任务（需提供 taskId）
- `EXISTING_TASK`: 绑定到指定任务（需提供 taskId）
- `NEW_TASK`: 创建新任务（需提供 taskTitle，可选 taskType）
- `INBOX`: 暂存箱

### Response 201

```json
{
  "code": 0,
  "data": {
    "noteId": 2010,
    "taskId": 5001,
    "message": "已保存到任务「完成开题报告」"
  }
}
```

---

## GET /?...

查询笔记列表。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `taskId` | long | - | 筛选任务 |
| `noteType` | string | - | RAW / AI_SUMMARY / REVIEW |
| `inbox` | bool | false | 仅暂存箱（`taskId IS NULL`） |
| `keyword` | string | - | 标题/内容模糊搜索 |
| `page` | int | 1 | 页码 |
| `size` | int | 20 | 每页数量 |

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 2001,
        "taskId": 5001,
        "title": "理论模型草稿",
        "content": "...(前 200 字符)",
        "noteType": "RAW",
        "sourceType": "TEXT",
        "createdAt": "2026-06-23T15:00:00Z"
      }
    ],
    "total": 8,
    "page": 1,
    "size": 20
  }
}
```

---

## GET /{id}

查询笔记详情。

### Response 200

```json
{
  "code": 0,
  "data": {
    "id": 2001,
    "userId": 1001,
    "taskId": 5001,
    "title": "理论模型草稿",
    "content": "# 理论模型\n\n...(完整内容)",
    "noteType": "RAW",
    "sourceType": "TEXT",
    "sourceSnapshotId": null,
    "files": [
      { "id": 123, "fileName": "outline.pdf" }
    ],
    "createdAt": "2026-06-23T15:00:00Z",
    "updatedAt": "2026-06-23T15:00:00Z"
  }
}
```

---

## PATCH /{id}

更新笔记。

### Request

```json
{
  "title": "新标题",
  "content": "...",
  "taskId": 5002,
  "version": 0
}
```

`taskId` 可用于从暂存箱绑定到任务。

### Response 200

```json
{
  "code": 0,
  "data": { ...更新后的笔记, "version": 1 }
}
```

---

## DELETE /{id}

删除笔记。

### Response 200

```json
{
  "code": 0,
  "data": null
}
```

---

## POST /bind

批量绑定暂存箱笔记到任务。

### Request

```json
{
  "noteIds": [2010, 2011, 2012],
  "taskId": 5001
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "boundCount": 3,
    "taskId": 5001
  }
}
```
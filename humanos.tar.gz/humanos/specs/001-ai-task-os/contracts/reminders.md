# Reminders API Contract

**Base URL**: `/api/reminders`
**Auth**: Bearer JWT 必需

---

## GET /today

今日提醒事件。

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 8001,
        "taskId": 5001,
        "taskTitle": "完成开题报告",
        "ruleType": "DEADLINE",
        "triggerTime": "2026-06-23T20:00:00+08:00",
        "status": "PENDING",
        "message": "开题报告还有3小时截止"
      }
    ]
  }
}
```

---

## GET /upcoming

未来 N 天的提醒事件。

### Query Parameters

| 参数 | 类型 | 默认 | 说明 |
|------|------|------|------|
| `days` | int | 7 | 未来天数 |
| `taskId` | long | - | 筛选特定任务 |

### Response 200

```json
{
  "code": 0,
  "data": {
    "items": [
      {
        "id": 8001,
        "taskId": 5001,
        "triggerTime": "2026-06-23T20:00:00+08:00",
        "ruleType": "DEADLINE",
        "message": "..."
      },
      {
        "id": 8002,
        "taskId": 5001,
        "triggerTime": "2026-06-26T19:30:00+08:00",
        "ruleType": "DEADLINE",
        "message": "..."
      }
    ],
    "groupByDate": {
      "2026-06-23": [8001],
      "2026-06-26": [8002]
    }
  }
}
```

---

## POST /rules

为任务创建提醒规则（手动添加）。

### Request

```json
{
  "taskId": 5001,
  "ruleType": "REPEAT",
  "cronExpr": "0 0 21 * * ?",
  "messageTemplate": "推进一下",
  "enabled": true
}
```

不同 `ruleType` 必填字段：
- `START`: `triggerTime`
- `DEADLINE`: `beforeDeadlineMinutes`
- `REPEAT`: `cronExpr` 或 `intervalMinutes`
- `REVIEW`: `intervalMinutes`
- `INACTIVE`: `intervalMinutes`

### Response 201

```json
{
  "code": 0,
  "data": {
    "ruleId": 7002,
    "taskId": 5001,
    "ruleType": "REPEAT",
    "cronExpr": "0 0 21 * * ?",
    "enabled": true,
    "upcomingEvents": [
      {
        "id": 8005,
        "triggerTime": "2026-06-23T21:00:00+08:00"
      }
    ]
  }
}
```

---

## PATCH /rules/{id}

更新提醒规则。

### Request

```json
{
  "cronExpr": "0 0 22 * * ?",
  "enabled": false,
  "version": 0
}
```

更新规则后，系统自动重新生成未来提醒事件。

---

## DELETE /rules/{id}

删除提醒规则（同时取消未触发的提醒事件）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "cancelledEventsCount": 3
  }
}
```

---

## POST /events/{id}/snooze

稍后提醒。

### Request

```json
{
  "durationMinutes": 60
}
```

或

```json
{
  "until": "2026-06-23T22:00:00+08:00"
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "oldEventId": 8001,
    "oldEventStatus": "SNOOZED",
    "newEvent": {
      "id": 8010,
      "triggerTime": "2026-06-23T22:00:00+08:00",
      "status": "PENDING"
    }
  }
}
```

---

## POST /events/{id}/done

标记提醒完成。

### Response 200

```json
{
  "code": 0,
  "data": {
    "eventId": 8001,
    "status": "DONE",
    "processedAt": "2026-06-23T20:05:00Z"
  }
}
```

---

## POST /events/{id}/ignore

忽略提醒（不再重复触发）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "eventId": 8001,
    "status": "IGNORED"
  }
}
```

---

## POST /events/{id}/start

从提醒直接开始任务（等价于 `POST /tasks/{taskId}/start` + 标记提醒为 DONE）。

### Request

```json
{
  "sessionGoal": "完成理论模型补充"
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "eventId": 8001,
    "status": "DONE",
    "task": {
      "id": 5001,
      "status": "DOING",
      "sessionId": 6005
    }
  }
}
```
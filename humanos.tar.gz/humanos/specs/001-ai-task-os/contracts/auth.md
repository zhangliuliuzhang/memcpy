# Auth API Contract

**Base URL**: `/api/auth`

---

## POST /register

用户注册（邮箱或手机号）。

### Request

```json
{
  "username": "alice",
  "email": "alice@example.com",
  "phone": "+8613800000000",
  "password": "PlainPassword123",
  "nickname": "Alice"
}
```

至少提供 `email` 或 `phone` 其中之一。

### Response 200

```json
{
  "code": 0,
  "data": {
    "userId": 1001,
    "username": "alice",
    "email": "alice@example.com"
  }
}
```

### Errors

- `40001`: 参数错误（用户名格式、邮箱格式、密码强度不足）
- `40901`: 用户名/邮箱/手机号已存在

---

## POST /login

用户登录。

### Request

```json
{
  "account": "alice@example.com",
  "password": "PlainPassword123"
}
```

`account` 可以是 `username`、`email` 或 `phone`。

### Response 200

```json
{
  "code": 0,
  "data": {
    "userId": 1001,
    "username": "alice",
    "nickname": "Alice",
    "avatarUrl": null,
    "timezone": "Asia/Shanghai",
    "accessToken": "eyJ...",
    "refreshToken": "eyJ...",
    "expiresIn": 7200
  }
}
```

### Headers (App/Web 自动携带)

```
X-Device-Type: WEB
X-Device-Id: browser-fingerprint-uuid
X-Device-Name: Chrome on macOS
X-User-Timezone: Asia/Shanghai
X-Push-Token: <optional FCM/APNs/HMS token>
```

后端记录到 `user_devices` 表。

### Errors

- `40101`: 账号不存在
- `40102`: 密码错误
- `40301`: 账号已停用

---

## POST /refresh

刷新 access token。

### Request

```json
{
  "refreshToken": "eyJ..."
}
```

### Response 200

```json
{
  "code": 0,
  "data": {
    "accessToken": "eyJ...(new)",
    "refreshToken": "eyJ...(new, rotated)",
    "expiresIn": 7200
  }
}
```

### Errors

- `40103`: refresh token 无效
- `40104`: refresh token 已过期
- `40105`: refresh token 已被吊销

---

## POST /logout

登出当前设备（吊销当前 refresh token）。

### Request

```json
{
  "refreshToken": "eyJ..."
}
```

### Response 200

```json
{
  "code": 0,
  "data": null
}
```

---

## POST /logout-all

吊销该用户所有 refresh token（紧急下线全部设备）。

### Request

无需 body。

### Response 200

```json
{
  "code": 0,
  "data": {
    "revokedDevicesCount": 3
  }
}
```

---

## GET /me

获取当前登录用户信息（用于前端初始化）。

### Response 200

```json
{
  "code": 0,
  "data": {
    "userId": 1001,
    "username": "alice",
    "email": "alice@example.com",
    "phone": "+8613800000000",
    "nickname": "Alice",
    "avatarUrl": null,
    "timezone": "Asia/Shanghai",
    "settings": {
      "theme": "auto",
      "reminderDefaultTime": "21:00",
      "sttEnabled": true
    }
  }
}
```

---

## PATCH /me

更新当前用户信息。

### Request

```json
{
  "nickname": "Alice Wang",
  "avatarUrl": "https://...",
  "timezone": "Asia/Shanghai",
  "settings": {
    "theme": "dark"
  }
}
```

所有字段可选。

### Response 200

```json
{
  "code": 0,
  "data": { ...更新后的用户对象 }
}
```
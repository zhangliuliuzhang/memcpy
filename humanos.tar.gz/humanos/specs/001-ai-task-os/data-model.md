# Data Model: AI Task OS

**Branch**: `001-ai-task-os`
**Date**: 2026-06-23
**Source**: spec.md Key Entities + research.md Decisions 4, 5, 6, 8

---

## Overview

本文档定义 AI Task OS 的所有数据实体、字段、关系、约束和状态机。第一版采用 PostgreSQL + JSONB + Flyway schema 迁移。

---

## Entity Catalog

| Entity | 表名 | 第一版核心程度 | 说明 |
|--------|------|---------------|------|
| User | `users` | ✅ 核心 | 用户主体 |
| UserDevice | `user_devices` | ✅ 核心 | 多端设备管理 |
| LoginToken | `login_tokens` | ✅ 核心 | JWT refresh token 存储 |
| Task | `tasks` | ✅ 核心 | 任务主体 |
| TaskSession | `task_sessions` | ✅ 核心 | 开始-暂停-结束的执行片段 |
| TaskSnapshot | `task_snapshots` | ✅ 核心 | 暂停时保存的现场快照 |
| Note | `notes` | ✅ 核心 | 笔记（原始 + AI 整理） |
| ReminderRule | `reminder_rules` | ✅ 核心 | 提醒策略定义 |
| ReminderEvent | `reminder_events` | ✅ 核心 | 具体某次提醒触发 |
| Notification | `notifications` | ✅ 核心 | 站内通知 |
| AiJob | `ai_jobs` | ✅ 核心 | AI 调用记录 |
| File | `files` | ✅ 核心 | 上传文件附件 |
| TaskType | `task_types` | ⚠️ 预留 | 任务类型枚举（可内嵌） |
| TaskStatus | `task_statuses` | ⚠️ 预留 | 任务状态枚举（可内嵌） |

---

## Entity Definitions

### 1. User（用户）

**表名**: `users`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 用户 ID |
| `username` | `VARCHAR(50)` | UNIQUE, NOT NULL | 用户名 |
| `email` | `VARCHAR(255)` | UNIQUE, NOT NULL | 邮箱 |
| `phone` | `VARCHAR(20)` | UNIQUE, NULLABLE | 手机号（可选） |
| `password_hash` | `VARCHAR(255)` | NOT NULL | 密码哈希（bcrypt/argon2） |
| `avatar_url` | `VARCHAR(500)` | NULLABLE | 头像 URL |
| `nickname` | `VARCHAR(100)` | NULLABLE | 显示名（默认为 username） |
| `status` | `VARCHAR(20)` | NOT NULL, DEFAULT 'ACTIVE' | 状态（ACTIVE/SUSPENDED/DELETED） |
| `timezone` | `VARCHAR(50)` | NOT NULL, DEFAULT 'UTC' | 最后活跃时区 ID（来自前端 header） |
| `settings` | `JSONB` | NULLABLE | 用户偏好设置（JSON） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 更新时间 |
| `version` | `INTEGER` | NOT NULL, DEFAULT 0 | 乐观锁版本 |

**索引**:
- `idx_users_email` ON `(email)`
- `idx_users_phone` ON `(phone)`
- `idx_users_status` ON `(status)`

**验证规则**:
- `email`: 必须符合邮箱格式
- `password`: 最少 8 字符，最多 128 字符（哈希前）

---

### 2. UserDevice（用户设备）

**表名**: `user_devices`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 设备 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `device_type` | `VARCHAR(20)` | NOT NULL | 设备类型（WEB/ANDROID/HARMONY） |
| `device_name` | `VARCHAR(100)` | NOT NULL | 设备名（用户可自定义） |
| `device_id` | `VARCHAR(100)` | NOT NULL | 设备唯一标识（浏览器 fingerprint / Android ID / 鸿蒙 UDID） |
| `push_token` | `VARCHAR(500)` | NULLABLE | 推送 token（FCM/APNs/HMS） |
| `last_active_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 最近活跃时间 |
| `enabled` | `BOOLEAN` | NOT NULL, DEFAULT TRUE | 是否启用推送 |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |

**索引**:
- `idx_user_devices_user_id` ON `(user_id)`
- `idx_user_devices_device_id` ON `(device_id)`

---

### 3. LoginToken（登录凭据）

**表名**: `login_tokens`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | Token ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `device_id` | `BIGINT` | FK → user_devices.id, NOT NULL | 绑定设备 |
| `refresh_token` | `VARCHAR(255)` | UNIQUE, NOT NULL | Refresh token（随机生成） |
| `expires_at` | `TIMESTAMPTZ` | NOT NULL | 过期时间（创建后 30 天） |
| `revoked` | `BOOLEAN` | NOT NULL, DEFAULT FALSE | 是否已吊销 |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |

**索引**:
- `idx_login_tokens_refresh_token` ON `(refresh_token)`
- `idx_login_tokens_user_id` ON `(user_id)`

---

### 4. Task（任务）

**表名**: `tasks`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 任务 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `title` | `VARCHAR(200)` | NOT NULL | 任务标题 |
| `description` | `TEXT` | NULLABLE | 任务描述（Markdown） |
| `task_type` | `VARCHAR(20)` | NOT NULL, DEFAULT 'NORMAL' | 任务类型（见枚举） |
| `status` | `VARCHAR(20)` | NOT NULL, DEFAULT 'TODO' | 任务状态（见状态机） |
| `priority` | `INTEGER` | NOT NULL, DEFAULT 2 | 优先级（0-5，默认 2） |
| `start_time` | `TIMESTAMPTZ` | NULLABLE | 计划开始时间 |
| `deadline` | `TIMESTAMPTZ` | NULLABLE | 截止时间 |
| `estimated_minutes` | `INTEGER` | NULLABLE | 预计耗时（分钟） |
| `actual_minutes` | `INTEGER` | NULLABLE, DEFAULT 0 | 实际耗时（分钟） |
| `progress` | `INTEGER` | NOT NULL, DEFAULT 0 | 进度百分比（0-100） |
| `current_snapshot_id` | `BIGINT` | FK → task_snapshots.id, NULLABLE | 当前最新快照 |
| `last_active_time` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 最近推进时间 |
| `reminder_enabled` | `BOOLEAN` | NOT NULL, DEFAULT TRUE | 是否启用提醒 |
| `review_enabled` | `BOOLEAN` | NOT NULL, DEFAULT FALSE | 是否启用复习 |
| `ai_delegated` | `BOOLEAN` | NOT NULL, DEFAULT FALSE | 是否已委托 AI |
| `deleted_at` | `TIMESTAMPTZ` | NULLABLE | 软删除时间（回收站） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 更新时间 |
| `version` | `INTEGER` | NOT NULL, DEFAULT 0 | 乐观锁版本 |

**枚举 `task_type`**:
- `NORMAL`: 普通任务
- `DEADLINE`: 截止任务
- `SCHEDULED`: 定时开始任务
- `LONG_TERM`: 长期推进任务
- `MEMORY`: 记忆复习任务
- `AI_DELEGATED`: AI 代理任务

**枚举 `status`**（见状态机）:
- `TODO`: 待开始
- `PLANNED`: 已计划（设置了 start_time）
- `DOING`: 进行中
- `PAUSED`: 已暂停
- `AI_RUNNING`: AI 处理中（预留）
- `WAITING`: 等待用户确认（预留）
- `DONE`: 已完成
- `CANCELLED`: 已取消

**索引**:
- `idx_tasks_user_id_status` ON `(user_id, status)`
- `idx_tasks_user_id_deadline` ON `(user_id, deadline)`
- `idx_tasks_user_id_last_active` ON `(user_id, last_active_time DESC)`
- `idx_tasks_deleted_at` ON `(deleted_at)`（回收站查询）

**验证规则**:
- `title`: 非空，最多 200 字符
- `deadline`: 若 `task_type = DEADLINE`，必须设置
- `start_time`: 若 `task_type = SCHEDULED`，必须设置
- `progress`: 0 ≤ progress ≤ 100

---

### 5. TaskSession（任务会话）

**表名**: `task_sessions`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 会话 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NOT NULL | 所属任务 |
| `started_at` | `TIMESTAMPTZ` | NOT NULL | 开始时间 |
| `paused_at` | `TIMESTAMPTZ` | NULLABLE | 暂停时间 |
| `ended_at` | `TIMESTAMPTZ` | NULLABLE | 结束时间（任务完成时） |
| `duration_minutes` | `INTEGER` | NULLABLE | 本次持续时间（分钟） |
| `session_goal` | `TEXT` | NULLABLE | 本次目标（用户输入） |
| `result_summary` | `TEXT` | NULLABLE | 本次结果（用户或 AI 总结） |
| `snapshot_id` | `BIGINT` | FK → task_snapshots.id, NULLABLE | 关联的快照（暂停时） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |

**索引**:
- `idx_task_sessions_task_id` ON `(task_id, started_at DESC)`
- `idx_task_sessions_user_id` ON `(user_id, started_at DESC)`

**业务规则**:
- `ended_at` 设置后，`duration_minutes` 自动计算
- 一个任务同一时间最多一条未结束的 session（DOING 状态）

---

### 6. TaskSnapshot（任务快照）

**表名**: `task_snapshots`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 快照 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NOT NULL | 所属任务 |
| `snapshot_type` | `VARCHAR(20)` | NOT NULL | 快照类型（见枚举） |
| `raw_input` | `TEXT` | NOT NULL | 用户原始输入（保留原文） |
| `ai_summary` | `TEXT` | NULLABLE | AI 总结（JSON 字段解析后的文本） |
| `current_progress` | `TEXT` | NULLABLE | 当前进度描述 |
| `pause_reason` | `TEXT` | NULLABLE | 暂停原因 |
| `next_action` | `TEXT` | NULLABLE | 下一步动作建议 |
| `open_questions` | `JSONB` | NULLABLE | 遗留问题列表（JSON array of string） |
| `related_files` | `JSONB` | NULLABLE | 关联文件 ID 列表（JSON array of file IDs） |
| `related_notes` | `JSONB` | NULLABLE | 关联笔记 ID 列表（JSON array of note IDs） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |

**枚举 `snapshot_type`**:
- `PAUSE`: 用户主动暂停
- `SWITCH`: 用户切换任务自动触发
- `AI`: AI 完成一部分处理时保存
- `STAGE`: 用户完成阶段工作时保存
- `COMPLETE`: 任务完成时保存

**索引**:
- `idx_task_snapshots_task_id` ON `(task_id, created_at DESC)`
- `idx_task_snapshots_user_id` ON `(user_id, created_at DESC)`

**业务规则**:
- `raw_input` 永不为空（用户必须输入）
- AI 处理失败时，`ai_summary` 等字段为 NULL，前端显示 `raw_input`

---

### 7. Note（笔记）

**表名**: `notes`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 笔记 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NULLABLE | 所属任务（可为 NULL 表示暂存箱） |
| `title` | `VARCHAR(200)` | NULLABLE | 笔记标题 |
| `content` | `TEXT` | NOT NULL | Markdown 内容 |
| `note_type` | `VARCHAR(20)` | NOT NULL, DEFAULT 'RAW' | 笔记类型（见枚举） |
| `source_type` | `VARCHAR(20)` | NULLABLE | 来源类型（TEXT/VOICE/IMAGE/FILE/CODE/LINK） |
| `source_snapshot_id` | `BIGINT` | FK → task_snapshots.id, NULLABLE | 来源快照 |
| `bound_to_task_at` | `TIMESTAMPTZ` | NULLABLE | 绑定到任务的时间（暂存箱 → 任务） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 更新时间 |

**枚举 `note_type`**:
- `RAW`: 用户原始记录
- `AI_SUMMARY`: AI 整理的结构化笔记
- `REVIEW`: 复习卡片

**枚举 `source_type`**:
- `TEXT`: 文字输入
- `VOICE`: 语音转文字
- `IMAGE`: 截图/图片
- `FILE`: 上传文件
- `CODE`: 代码片段
- `LINK`: 网页链接

**索引**:
- `idx_notes_task_id` ON `(task_id, created_at DESC)`
- `idx_notes_user_id` ON `(user_id, note_type, created_at DESC)`
- `idx_notes_unbound` ON `(user_id)` WHERE `task_id IS NULL`（暂存箱）

---

### 8. ReminderRule（提醒规则）

**表名**: `reminder_rules`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 规则 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NOT NULL | 所属任务 |
| `rule_type` | `VARCHAR(20)` | NOT NULL | 规则类型（见枚举） |
| `cron_expr` | `VARCHAR(100)` | NULLABLE | Cron 表达式（REPEAT 类型） |
| `interval_minutes` | `INTEGER` | NULLABLE | 固定间隔分钟数（INACTIVE/REVIEW） |
| `before_deadline_minutes` | `INTEGER` | NULLABLE | 截止前多少分钟（DEADLINE） |
| `trigger_time` | `TIMESTAMPTZ` | NULLABLE | 单次触发时间（START 类型） |
| `message_template` | `TEXT` | NULLABLE | 提醒消息模板 |
| `enabled` | `BOOLEAN` | NOT NULL, DEFAULT TRUE | 是否启用 |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 更新时间 |

**枚举 `rule_type`**:
- `START`: 定时开始提醒
- `DEADLINE`: 截止前提醒
- `REPEAT`: 周期提醒（cron 或 interval）
- `REVIEW`: 复习提醒（间隔）
- `INACTIVE`: 长期未推进提醒
- `PROGRESS`: 阶段推进提醒
- `AI_DONE`: AI 完成提醒

**索引**:
- `idx_reminder_rules_task_id` ON `(task_id)`
- `idx_reminder_rules_user_id_enabled` ON `(user_id, enabled)`

**业务规则**:
- `DEADLINE` 类型：`before_deadline_minutes` 必须设置
- `REPEAT` 类型：`cron_expr` 或 `interval_minutes` 必须设置
- `REVIEW` 类型：`interval_minutes` 必须设置
- `INACTIVE` 类型：`interval_minutes` 必须设置
- `START` 类型：`trigger_time` 必须设置

---

### 9. ReminderEvent（提醒事件）

**表名**: `reminder_events`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 事件 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NOT NULL | 所属任务 |
| `rule_id` | `BIGINT` | FK → reminder_rules.id, NOT NULL | 所属规则 |
| `trigger_time` | `TIMESTAMPTZ` | NOT NULL | 触发时间（UTC） |
| `status` | `VARCHAR(20)` | NOT NULL, DEFAULT 'PENDING' | 状态（见枚举） |
| `message` | `TEXT` | NOT NULL | 提醒内容 |
| `snooze_until` | `TIMESTAMPTZ` | NULLABLE | 稍后提醒时间 |
| `processed_at` | `TIMESTAMPTZ` | NULLABLE | 处理时间（用户操作） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 更新时间 |

**枚举 `status`**:
- `PENDING`: 待触发
- `SENT`: 已发送通知
- `SNOOZED`: 已稍后（重新生成新事件）
- `DONE`: 已完成（用户标记完成）
- `IGNORED`: 已忽略
- `CANCELLED`: 任务完成/取消时取消

**索引**:
- `idx_reminder_events_pending` ON `(status, trigger_time)` WHERE `status = 'PENDING'`
- `idx_reminder_events_user_id` ON `(user_id, trigger_time DESC)`
- `idx_reminder_events_task_id` ON `(task_id)`

**业务规则**:
- Quartz Job 每 1 分钟扫描 `PENDING` + `trigger_time <= NOW()`
- 用户选择"稍后提醒"：创建新事件，当前事件状态改为 `SNOOZED`

---

### 10. Notification（通知）

**表名**: `notifications`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 通知 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NULLABLE | 关联任务 |
| `reminder_event_id` | `BIGINT` | FK → reminder_events.id, NULLABLE | 关联提醒事件 |
| `notification_type` | `VARCHAR(20)` | NOT NULL | 通知类型（见枚举） |
| `title` | `VARCHAR(200)` | NOT NULL | 标题 |
| `content` | `TEXT` | NOT NULL | 内容 |
| `read_status` | `BOOLEAN` | NOT NULL, DEFAULT FALSE | 是否已读 |
| `read_at` | `TIMESTAMPTZ` | NULLABLE | 阅读时间 |
| `action_type` | `VARCHAR(20)` | NULLABLE | 可执行动作类型（见枚举） |
| `action_data` | `JSONB` | NULLABLE | 动作数据（例如跳转 URL） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |

**枚举 `notification_type`**:
- `REMINDER`: 提醒通知
- `AI_DONE`: AI 完成通知
- `REVIEW`: 复习通知
- `SYSTEM`: 系统通知

**枚举 `action_type`**:
- `START_TASK`: 开始任务
- `RESUME_TASK`: 恢复任务
- `VIEW_NOTE`: 查看笔记
- `CONFIRM_AI`: 确认 AI 结果
- `DISMISS`: 仅关闭

**索引**:
- `idx_notifications_user_unread` ON `(user_id, read_status, created_at DESC)`
- `idx_notifications_user_id` ON `(user_id, created_at DESC)`

---

### 11. AiJob（AI 任务记录）

**表名**: `ai_jobs`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | AI 任务 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NULLABLE | 关联任务 |
| `snapshot_id` | `BIGINT` | FK → task_snapshots.id, NULLABLE | 关联快照 |
| `note_id` | `BIGINT` | FK → notes.id, NULLABLE | 关联笔记 |
| `job_type` | `VARCHAR(20)` | NOT NULL | 任务类型（见枚举） |
| `status` | `VARCHAR(20)` | NOT NULL, DEFAULT 'PENDING' | 状态（见枚举） |
| `input_payload` | `JSONB` | NOT NULL | 输入（JSON） |
| `output_payload` | `JSONB` | NULLABLE | 输出（JSON） |
| `raw_response` | `TEXT` | NULLABLE | AI 原始响应（调试用） |
| `error_message` | `TEXT` | NULLABLE | 错误信息 |
| `latency_ms` | `INTEGER` | NULLABLE | 耗时（毫秒） |
| `retry_count` | `INTEGER` | NOT NULL, DEFAULT 0 | 重试次数 |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |
| `updated_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 更新时间 |

**枚举 `job_type`**:
- `PARSE`: 任务解析
- `SUMMARY`: 快照总结
- `RESUME`: 恢复建议
- `NOTE`: 笔记整理
- `REVIEW`: 复习卡片生成
- `REMINDER_PLAN`: 提醒计划生成
- `CHAT`: AI 对话

**枚举 `status`**:
- `PENDING`: 待处理
- `RUNNING`: 处理中
- `SUCCESS`: 成功
- `FAILED`: 失败
- `CANCELLED`: 已取消

**索引**:
- `idx_ai_jobs_user_id` ON `(user_id, created_at DESC)`
- `idx_ai_jobs_task_id` ON `(task_id)`
- `idx_ai_jobs_status` ON `(status, created_at)` WHERE `status IN ('PENDING', 'RUNNING')`

---

### 12. File（文件）

**表名**: `files`

| 字段 | 类型 | 约束 | 说明 |
|------|------|------|------|
| `id` | `BIGSERIAL` | PK | 文件 ID |
| `user_id` | `BIGINT` | FK → users.id, NOT NULL | 所属用户 |
| `task_id` | `BIGINT` | FK → tasks.id, NULLABLE | 关联任务 |
| `note_id` | `BIGINT` | FK → notes.id, NULLABLE | 关联笔记 |
| `file_name` | `VARCHAR(255)` | NOT NULL | 原始文件名 |
| `file_type` | `VARCHAR(100)` | NOT NULL | MIME 类型 |
| `storage_path` | `VARCHAR(500)` | NOT NULL | MinIO 存储路径（bucket/key） |
| `size_bytes` | `BIGINT` | NOT NULL | 文件大小（字节） |
| `checksum` | `VARCHAR(64)` | NULLABLE | SHA-256 校验 |
| `source` | `VARCHAR(20)` | NULLABLE | 来源类型（UPLOAD/VOICE/SCREENSHOT） |
| `created_at` | `TIMESTAMPTZ` | NOT NULL, DEFAULT NOW() | 创建时间 |

**索引**:
- `idx_files_user_id` ON `(user_id, created_at DESC)`
- `idx_files_task_id` ON `(task_id)`
- `idx_files_note_id` ON `(note_id)`

**验证规则**:
- `file_type`: 必须在白名单内（见 research.md Decision 13）
- `size_bytes`: ≤ 50MB

---

## State Machines

### Task Status Flow

```
TODO ──► PLANNED ──► DOING ──► PAUSED ──► DOING ──► DONE
                  │          │          │
                  │          │          ▼
                  │          │    AI_RUNNING ──► WAITING ──► DOING/PAUSED
                  │          │
                  ▼          ▼
              CANCELLED  CANCELLED

完整转换表：
- start(): TODO → DOING, PLANNED → DOING
- pause(): DOING → PAUSED
- resume(): PAUSED → DOING
- complete(): DOING → DONE, PAUSED → DONE, AI_RUNNING → DONE, WAITING → DONE
- cancel(): any → CANCELLED (except DONE/CANCELLED)
- delegate(): DOING → AI_RUNNING, PAUSED → AI_RUNNING
- ai_complete(): AI_RUNNING → WAITING
- confirm(): WAITING → DOING
- reject(): WAITING → PAUSED
```

### ReminderEvent Status Flow

```
PENDING ──► SENT ──► DONE
                  │
                  ▼
              SNOOZED ──► (create new PENDING event)

             IGNORED
             CANCELLED
```

---

## Relationships Diagram

```
users
  │
  ├─── user_devices (1:N)
  ├─── login_tokens (1:N)
  ├─── tasks (1:N)
  │      │
  │      ├─── task_sessions (1:N)
  │      ├─── task_snapshots (1:N)
  │      ├─── notes (1:N)
  │      ├─── reminder_rules (1:N)
  │      │      │
  │      │      └─── reminder_events (1:N)
  │      │             │
  │      │             └─── notifications (1:1)
  │      ├─── files (1:N)
  │      └─── ai_jobs (1:N)
  │
  └─── notifications (1:N)
  └─── ai_jobs (1:N)
  └─── files (1:N)
  └─── notes (1:N) (暂存箱)
```

---

## Schema Migration Notes

- **Flyway** 管理所有迁移，版本号 `V001__initial_schema.sql`, `V002__add_task_version.sql` 等。
- **JSONB 字段**：`open_questions`, `related_files`, `input_payload`, `output_payload`, `settings` 等，使用 PostgreSQL JSONB 操作符查询。
- **时区**：所有 `TIMESTAMPTZ` 存储 UTC，前端按 `X-User-Timezone` header 转换展示。
- **乐观锁**：`tasks`, `users` 等核心实体有 `version` 列，更新时校验。

---

## Sample Queries

### 今日驾驶舱数据

```sql
-- 正在进行任务
SELECT * FROM tasks WHERE user_id = ? AND status = 'DOING';

-- 今日必须处理（截止时间在今天）
SELECT * FROM tasks
WHERE user_id = ? AND deadline >= CURRENT_DATE AND deadline < CURRENT_DATE + INTERVAL '1 day'
AND status NOT IN ('DONE', 'CANCELLED');

-- 需要恢复的任务（已暂停超过 1 天）
SELECT * FROM tasks
WHERE user_id = ? AND status = 'PAUSED'
AND last_active_time < NOW() - INTERVAL '1 day';

-- AI 已完成等待确认（预留）
SELECT * FROM tasks WHERE user_id = ? AND status = 'WAITING';

-- 今日复习提醒
SELECT r.task_id, t.title, r.trigger_time
FROM reminder_events r JOIN tasks t ON r.task_id = t.id
WHERE r.user_id = ? AND r.status = 'PENDING'
AND r.trigger_time >= CURRENT_DATE AND r.trigger_time < CURRENT_DATE + INTERVAL '1 day'
AND r.rule_id IN (SELECT id FROM reminder_rules WHERE rule_type = 'REVIEW');
```

### 提醒事件扫描（Quartz Job）

```sql
-- 找出到点未触发的提醒事件
SELECT id, user_id, task_id, message
FROM reminder_events
WHERE status = 'PENDING' AND trigger_time <= NOW()
FOR UPDATE SKIP LOCKED;  -- 防止并发重复触发

-- 触发后更新状态
UPDATE reminder_events SET status = 'SENT', updated_at = NOW() WHERE id = ?;
```

---

## Indexes Summary

| 表 | 索引名 | 列 | 用途 |
|----|--------|----|----|
| `users` | `idx_users_email` | `email` | 登录查询 |
| `tasks` | `idx_tasks_user_id_status` | `(user_id, status)` | 任务列表筛选 |
| `tasks` | `idx_tasks_user_id_deadline` | `(user_id, deadline)` | 截止任务查询 |
| `tasks` | `idx_tasks_user_id_last_active` | `(user_id, last_active_time DESC)` | 恢复提醒判断 |
| `task_snapshots` | `idx_task_snapshots_task_id` | `(task_id, created_at DESC)` | 时间线查询 |
| `reminder_events` | `idx_reminder_events_pending` | `(status, trigger_time)` WHERE `status='PENDING'` | Quartz 扫描 |
| `notifications` | `idx_notifications_user_unread` | `(user_id, read_status, created_at DESC)` | 未读通知查询 |
| `ai_jobs` | `idx_ai_jobs_status` | `(status, created_at)` WHERE `status IN ('PENDING','RUNNING')` | 异步队列查询 |
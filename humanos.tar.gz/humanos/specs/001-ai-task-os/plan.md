# Implementation Plan: AI Task OS

**Branch**: `001-ai-task-os` | **Date**: 2026-06-23 | **Spec**: [spec.md](./spec.md)

**Input**: Feature specification from `/specs/001-ai-task-os/spec.md`

---

## Summary

构建一个由 AI 驱动的个人任务操作系统，帮助用户管理注意力、任务上下文、提醒节奏、任务中断现场和长期记忆。核心差异化：自然语言创建任务 → AI 解析 → 任务状态流转（开始/暂停/恢复） → 任务快照 → AI 总结 → 智能提醒 → 复习记忆。

第一版采用 **模块化单体架构**（Java 21 + Spring Boot + PostgreSQL + Redis + Quartz + MinIO），前端使用 React + TypeScript，移动端使用轻原生壳（Android Kotlin + 鸿蒙 ArkTS）。AI 使用 OpenAI 兼容接口协议，`base_url` 可自定义。语音转文字使用端侧原生 SDK（Web Speech API / Android SpeechRecognizer / 鸿蒙 AsrController）。

---

## Technical Context

**Language/Version**: Java 21 (LTS) + Kotlin 2.0 + TypeScript 5.x

**Primary Dependencies**:
- 后端: Spring Boot 3.3+, Spring Security 6.x, Spring Data JPA 或 MyBatis-Plus, Quartz 2.5, Flyway, WebClient/RestClient, Lombok
- 前端: React 18, TypeScript, Vite 5, Zustand (状态管理), shadcn/ui (UI 组件), React Router, Axios, SSE Client
- 移动端: Android Jetpack Compose + WebView; 鸿蒙 ArkTS + ArkUI + Web 嵌入

**Storage**: PostgreSQL 16 (主数据库), Redis 7 (缓存 + session), MinIO (对象存储)

**Testing**: JUnit 5 + Mockito + Testcontainers (后端); Vitest + Playwright (前端)

**Target Platform**: 
- Web: Chrome 90+, Safari 14+, Firefox 100+ (降级 STT)
- Mobile Web: 响应式适配
- Android: API 26+ (Android 8.0)
- 鸿蒙: HarmonyOS 4.0+

**Project Type**: Web Application + Mobile App (轻壳)

**Performance Goals**:
- 今日驾驶舱 API P95 < 500ms
- 任务列表 API P95 < 800ms
- 提醒触发延迟 < 1 分钟
- AI 解析成功率 > 95%

**Constraints**:
- 第一版模块化单体，不拆微服务
- 端侧 STT（无云端语音服务）
- OpenAI 兼容接口单一入口（可配置 base_url）
- 仅邮箱/手机号登录（无第三方）
- 个人使用，暂不考虑合规（预留扩展点）

**Scale/Scope**:
- 单用户 10000+ 任务
- 每任务 1000+ 快照
- 预估第一版开发周期: 4-6 周

---

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

当前 constitution.md 为模板状态，无具体约束。本计划遵循以下隐式原则：

| Principle | Status | Notes |
|-----------|--------|-------|
| 模块化单体优先 | ✅ Pass | 第一版不拆微服务，后期可按模块拆分 |
| 统一 AI Gateway | ✅ Pass | 所有 AI 调用通过 `ai/` 模块封装 |
| 用户数据隔离 | ✅ Pass | 所有查询强制 `userId` 过滤 |
| 提醒持久化 | ✅ Pass | Quartz JDBC JobStore + reminder_events 表 |
| 端侧优先 | ✅ Pass | STT 使用原生 SDK，不依赖云端 |
| JSON Schema 校验 | ✅ Pass | AI 输出必须校验，失败降级 |

---

## Project Structure

### Documentation (this feature)

```text
specs/001-ai-task-os/
├── plan.md              # This file
├── research.md          # Phase 0 output (技术决策)
├── data-model.md        # Phase 1 output (数据模型)
├── quickstart.md        # Phase 1 output (快速上手)
├── contracts/           # Phase 1 output (API 契约)
│   ├── README.md
│   ├── auth.md
│   ├── tasks.md
│   ├── reminders.md
│   ├── notifications.md
│   ├── ai.md
│   ├── notes.md
│   ├── files.md
│   ├── snapshots.md
│   ├── users.md
│   ├── dashboard.md
│   └── review.md
└── tasks.md             # Phase 2 output (/speckit-tasks)
```

### Source Code (repository root)

```text
ai-task-os/
├── backend/                    # Java Spring Boot 后端
│   ├── pom.xml
│   └── src/
│       ├── main/
│       │   ├── java/com/taskos/
│       │   │   ├── TaskOsApplication.java
│       │   │   ├── common/
│       │   │   │   ├── config/
│       │   │   │   │   ├── SecurityConfig.java
│       │   │   │   │   ├── WebConfig.java
│       │   │   │   │   ├── QuartzConfig.java
│       │   │   │   │   ├── MinioConfig.java
│       │   │   │   │   └── RedisConfig.java
│       │   │   │   ├── exception/
│       │   │   │   │   ├── GlobalExceptionHandler.java
│       │   │   │   │   ├── ResourceNotFoundException.java
│       │   │   │   │   ├── BusinessException.java
│       │   │   │   │   └── ConflictException.java
│       │   │   │   ├── response/
│       │   │   │   │   ├── ApiResponse.java
│       │   │   │   │   └── ErrorCode.java
│       │   │   │   ├── security/
│       │   │   │   │   ├── JwtAuthFilter.java
│       │   │   │   │   ├── JwtService.java
│       │   │   │   │   └── UserPrincipal.java
│       │   │   │   └── utils/
│       │   │   │       ├── TimezoneUtils.java
│       │   │   │       └── JsonUtils.java
│       │   │   ├── user/
│       │   │   │   ├── controller/
│       │   │   │   ├── service/
│       │   │   │   ├── entity/
│       │   │   │   ├── mapper/
│       │   │   │   └── dto/
│       │   │   ├── task/
│       │   │   │   ├── controller/
│       │   │   │   │   └── TaskController.java
│       │   │   │   ├── service/
│       │   │   │   │   ├── TaskService.java
│       │   │   │   │   ├── TaskStateMachine.java
│       │   │   │   │   └── TaskQueryService.java
│       │   │   │   ├── entity/
│       │   │   │   ├── mapper/
│       │   │   │   └── dto/
│       │   │   ├── reminder/
│       │   │   │   ├── controller/
│       │   │   │   ├── service/
│       │   │   │   │   ├── ReminderRuleService.java
│       │   │   │   │   ├── ReminderEventService.java
│       │   │   │   │   └── ReminderGenerator.java
│       │   │   │   ├── scheduler/
│       │   │   │   │   └── ReminderScheduler.java
│       │   │   │   ├── job/
│       │   │   │   │   └── ReminderFireJob.java
│       │   │   │   ├── entity/
│       │   │   │   ├── mapper/
│       │   │   │   └── dto/
│       │   │   ├── snapshot/
│       │   │   │   ├── controller/
│       │   │   │   ├── service/
│       │   │   │   ├── entity/
│       │   │   │   ├── mapper/
│       │   │   │   └── dto/
│       │   │   ├── note/
│       │   │   │   ├── controller/
│       │   │   │   ├── service/
│       │   │   │   ├── entity/
│       │   │   │   ├── mapper/
│       │   │   │   └── dto/
│       │   │   ├── ai/
│       │   │   │   ├── controller/
│       │   │   │   │   └── AiController.java
│       │   │   │   ├── service/
│       │   │   │   │   ├── AiGatewayService.java
│       │   │   │   │   ├── AiTaskParserService.java
│       │   │   │   │   ├── AiSnapshotService.java
│       │   │   │   │   ├── AiResumeService.java
│       │   │   │   │   ├── AiNoteService.java
│       │   │   │   │   ├── AiReviewService.java
│       │   │   │   │   └── AiChatService.java
│       │   │   │   ├── prompt/
│       │   │   │   │   ├── TaskParserPrompt.java
│       │   │   │   │   ├── SnapshotSummarizerPrompt.java
│       │   │   │   │   ├── ResumeAdvisorPrompt.java
│       │   │   │   │   ├── NoteRefinerPrompt.java
│       │   │   │   │   └── ReviewCardPrompt.java
│       │   │   │   ├── client/
│       │   │   │   │   └── OpenAiClient.java
│       │   │   │   └── dto/
│       │   │   ├── review/
│       │   │   │   ├── controller/
│       │   │   │   ├── service/
│       │   │   │   ├── entity/
│       │   │   │   └── dto/
│       │   │   ├── notification/
│       │   │   │   ├── controller/
│       │   │   │   ├── service/
│       │   │   │   │   ├── NotificationService.java
│       │   │   │   │   ├── InAppChannel.java
│       │   │   │   │   ├── WebSseChannel.java
│       │   │   │   │   └── NotificationChannel.java (interface)
│       │   │   │   ├── entity/
│       │   │   │   ├── mapper/
│       │   │   │   └── dto/
│       │   │   ├── file/
│       │   │   │   ├── controller/
│       │   │   │   ├── service/
│       │   │   │   │   └── FileStorageService.java
│       │   │   │   ├── entity/
│       │   │   │   ├── mapper/
│       │   │   │   └── dto/
│       │   │   └── dashboard/
│       │   │       ├── controller/
│       │   │       └── service/
│       │   └── resources/
│       │   │   ├── application.yml
│       │   │   ├── application-dev.yml
│       │   │   ├── application-prod.yml
│       │   │   └── db/migration/
│       │   │       ├── V001__initial_schema.sql
│       │   │       ├── V002__add_indexes.sql
│       │   │       └── ...
│       └── test/
│           └── java/com/taskos/
│               ├── task/
│               ├── reminder/
│               ├── ai/
│               └── ...
│
├── frontend/                   # React Web 前端
│   ├── package.json
│   ├── pnpm-lock.yaml
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── src/
│   │   ├── main.tsx
│   │   ├── App.tsx
│   │   ├── components/
│   │   │   ├── ui/           # shadcn/ui 组件
│   │   │   ├── layout/
│   │   │   │   ├── Sidebar.tsx
│   │   │   │   ├── Header.tsx
│   │   │   │   └── AiAssistant.tsx
│   │   │   └── common/
│   │   │       ├── TaskCard.tsx
│   │   │       ├── SnapshotCard.tsx
│   │   │       ├── ReminderCard.tsx
│   │   │       └── QuickRecordButton.tsx
│   │   ├── pages/
│   │   │   ├── Login.tsx
│   │   │   ├── Dashboard.tsx         # 今日驾驶舱
│   │   │   ├── TaskList.tsx
│   │   │   ├── TaskDetail.tsx
│   │   │   ├── TaskCreate.tsx
│   │   │   ├── FocusMode.tsx
│   │   │   ├── QuickRecord.tsx
│   │   │   ├── TaskResume.tsx
│   │   │   ├── ReminderCenter.tsx
│   │   │   ├── ReviewPage.tsx
│   │   │   ├── Calendar.tsx
│   │   │   ├── AiWorkspace.tsx
│   │   │   ├── Settings.tsx
│   │   │   └── Inbox.tsx             # 暂存箱
│   │   ├── services/
│   │   │   ├── api.ts
│   │   │   ├── auth.ts
│   │   │   ├── task.ts
│   │   │   ├── reminder.ts
│   │   │   ├── notification.ts
│   │   │   ├── ai.ts
│   │   │   ├── note.ts
│   │   │   └── file.ts
│   │   ├── stores/
│   │   │   ├── authStore.ts
│   │   │   ├── taskStore.ts
│   │   │   ├── notificationStore.ts
│   │   │   └── settingsStore.ts
│   │   ├── hooks/
│   │   │   ├── useSse.ts
│   │   │   ├── useSpeechRecognition.ts
│   │   │   ├── useTimezone.ts
│   │   │   └── useTaskStateMachine.ts
│   │   ├── utils/
│   │   │   ├── dateFormat.ts
│   │   │   ├── timezone.ts
│   │   │   └── validators.ts
│   │   └── types/
│   │   │   ├── task.ts
│   │   │   ├── reminder.ts
│   │   │   ├── notification.ts
│   │   │   └── ai.ts
│   └── public/
│
├── android/                    # Android App (轻壳)
│   ├── app/
│   │   ├── src/main/
│   │   │   ├── java/com/taskos/app/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── WebViewFragment.kt
│   │   │   │   ├── NotificationService.kt
│   │   │   │   ├── SpeechService.kt
│   │   │   │   └── DeviceInfo.kt
│   │   │   ├── res/
│   │   │   └── AndroidManifest.xml
│   │   └── build.gradle.kts
│   └── build.gradle.kts
│
├── harmony/                    # 鸿蒙 App (轻壳)
│   ├── entry/
│   │   ├── src/main/
│   │   │   ├── ets/
│   │   │   │   ├── entryability/
│   │   │   │   │   └── EntryAbility.ts
│   │   │   │   └── pages/
│   │   │   │       └── Index.ets
│   │   │   └── resources/
│   │   └── build-profile.json5
│   └── hvigorfile.ts
│
├── docker-compose.yml
├── docker-compose.prod.yml
├── Dockerfile.backend
├── Dockerfile.frontend
├── .env.example
├── .gitignore
└── README.md
```

**Structure Decision**: 采用 Web Application 结构（backend + frontend 分离），移动端作为独立轻壳项目（android + harmony）。后端使用模块化单体，按业务领域拆分 `user/task/reminder/snapshot/note/ai/notification/file` 等模块，每个模块遵循 Controller-Service-Entity-Mapper-DTO 结构。

---

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

无违反情况。

---

## Phase Artifacts

| Artifact | Path | Status |
|----------|------|--------|
| research.md | `specs/001-ai-task-os/research.md` | ✅ Complete |
| data-model.md | `specs/001-ai-task-os/data-model.md` | ✅ Complete |
| contracts/ | `specs/001-ai-task-os/contracts/` | ✅ Complete (12 files) |
| quickstart.md | `specs/001-ai-task-os/quickstart.md` | ✅ Complete |

---

## Next Steps

运行 `/speckit-tasks` 生成任务列表，开始实现。
# Phase 0 Research: AI Task OS

**Branch**: `001-ai-task-os`
**Date**: 2026-06-23
**Status**: Complete

---

## Overview

本文件整合 AI Task OS 第一版的所有技术决策。所有 `NEEDS CLARIFICATION` 已在 spec.md 澄清会话中解决，此文档为澄清结果的技术延伸——把"用户层决策"细化为"工程层实现方案"。

---

## Decision 1: OpenAI 兼容接口接入方案

### Decision

使用 OpenAI 兼容的 Chat Completions 协议接入 AI 服务，`base_url` 可配置，其他参数使用默认。

### Rationale

- **解耦**：OpenAI Chat Completions 协议已成为行业事实标准，主流模型服务（OpenAI 官方、Azure OpenAI、阿里通义、智谱 GLM、Moonshot、DeepSeek、Anthropic 兼容层、自部署 vLLM/LocalAI/Ollama with `OPENAI_API_BASE`）都提供兼容接口。
- **可替换性**：用户在设置中改一个 `base_url` + `api_key` 即可切换到任意兼容服务，无需改代码。
- **成本可控**：用户可根据自身情况选择最经济的服务（自部署、国产模型、海外模型）。
- **未来扩展**：若需要多模型路由（第一版不做），只需在 AI Gateway 层增加路由逻辑，业务代码不变。

### Alternatives Considered

| 方案 | 拒绝原因 |
|------|----------|
| 单一闭源模型 SDK（例如直接用 Anthropic SDK） | 锁定厂商，与 FR-111 冲突 |
| Spring AI 抽象层 | 抽象层在 2026 年仍不够稳定，且对自定义 `base_url` 支持有限；直接用 `WebClient` + OpenAI 协议更简单可控 |
| 多模型路由 | 第一版不做，Out of Scope 已声明 |

### Implementation

- **HTTP Client**：Spring `WebClient`（响应式）或 `RestClient`（同步，Spring 6.1+），用于调用 `/v1/chat/completions`。
- **配置项**（`application.yml`）：
  ```yaml
  ai:
    openai:
      base-url: ${AI_BASE_URL:https://api.openai.com/v1}
      api-key: ${AI_API_KEY:}
      model: ${AI_MODEL:gpt-4o-mini}
      temperature: 0.3
      timeout-seconds: 30
      max-retries: 2
  ```
- **请求格式**：标准 OpenAI Chat Completions 请求（`messages` 数组、`response_format: {"type": "json_object"}`）。
- **响应解析**：`choices[0].message.content` → JSON.parse → schema 校验。
- **错误处理**：
  - HTTP 4xx：立即失败，不重试（一般是配置错误或额度不足）。
  - HTTP 5xx / 超时：按 `max-retries` 重试，指数退避。
  - JSON 解析失败：重试一次，仍失败则降级为兜底模板。
- **流式响应**：AI Chat（User Story 9）使用 `stream: true` + SSE 下发到前端。

### References

- OpenAI API Reference: Chat Completions（`/v1/chat/completions`）
- vLLM OpenAI Compatible Server: `https://docs.vllm.ai/en/latest/serving/openai_compatible_server.html`
- Ollama OpenAI Compatibility: `https://ollama.com/blog/openai-compatibility`

---

## Decision 2: 语音转文字（STT）端侧方案

### Decision

完全使用端侧原生 SDK，不依赖云端 STT。

### Rationale

已在 spec.md Q3 中决策。补充技术细节：

### Implementation

#### Web 端

```javascript
// 使用 Web Speech API (SpeechRecognition)
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = navigator.language || 'zh-CN';
recognition.continuous = false;
recognition.interimResults = true;
recognition.onresult = (event) => { /* ... */ };
recognition.start();
```

**浏览器兼容矩阵**：
| 浏览器 | 支持 | 备注 |
|--------|------|------|
| Chrome (desktop & Android) | ✅ | `webkitSpeechRecognition` |
| Edge | ✅ | 基于 Chromium |
| Safari (iOS 14.5+, macOS) | ✅ | `SpeechRecognition` |
| Firefox | ❌ | 降级为"仅文字/图片" |
| 鸿蒙 Web View | ⚠️ | 取决于内核版本，第一版按降级处理 |

**降级策略**：检测 `window.SpeechRecognition` 不存在时，UI 隐藏"语音"按钮，仅显示"文字/图片/文件"选项。

#### Android 端

```kotlin
// 使用 Android SpeechRecognizer (无需任何第三方依赖)
val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
recognizer.setRecognitionServiceLocale(Locale.getDefault())
val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
}
recognizer.startListening(intent)
```

**权限**：`android.permission.RECORD_AUDIO`（运行时申请）。

#### 鸿蒙端

```typescript
// 使用 @ohos.ai.asr (AsrController)
import { asrController } from '@kit.ASRKit';
const controller = asrController.create();
const session = await controller.startSession({
    language: 'zh-CN',
    partialResults: true
});
```

**权限**：`ohos.permission.MICROPHONE`（在 `module.json5` 中声明）。

### Alternatives Considered

| 方案 | 拒绝原因 |
|------|----------|
| OpenAI Whisper API | 与"端侧原生 + 零成本"决策冲突 |
| 阿里/百度/腾讯语音识别 | 引入额外依赖，与 FR-064 冲突 |

---

## Decision 3: 提醒时区处理方案

### Decision

前端/App 每次请求携带设备时区（`X-User-Timezone` header），后端按此时区计算提醒触发时间，并存储为用户最后活跃时区。

### Rationale

已在 spec.md Q5 中决策。补充技术细节：

### Implementation

#### 前端（Web）

```javascript
// Axios 拦截器自动添加时区 header
axios.interceptors.request.use(config => {
    config.headers['X-User-Timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return config;
});
```

#### 前端（Android）

```kotlin
// OkHttp Interceptor
class TimezoneInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val tz = TimeZone.getDefault().id // 例如 "Asia/Shanghai"
        val request = chain.request().newBuilder()
            .header("X-User-Timezone", tz)
            .build()
        return chain.proceed(request)
    }
}
```

#### 前端（鸿蒙）

```typescript
// @ohos.i18n
import { getTimeZone } from '@ohos.i18n';
const tz = getTimeZone().getID();
```

#### 后端处理

- **Filter / Interceptor**：解析 `X-User-Timezone` header，存入 `RequestContext`（ThreadLocal / Reactor Context）。
- **Quartz Job 数据**：每次 trigger 携带 `UserTimeZone`，Quartz 使用 `TimeZone` 对象计算触发时间。
- **数据库存储**：
  - `users.last_timezone` (varchar)：最后活跃时区 ID（例如 `Asia/Shanghai`）。
  - `reminder_events.trigger_time` (timestamptz)：以 UTC 存储，查询时按用户时区转换。
- **后台扫描 Job**：Quartz 默认每分钟扫描一次到点的 `reminder_events`（按 UTC 比较），生成通知。

### 时区漂移处理

- **场景**：用户长期未登录，活跃时区已变化，但后台 Job 仍按旧时区触发。
- **缓解**：用户下次登录时，前端发送新时区，后端更新 `users.last_timezone`；旧时区触发的提醒在通知正文中附注"如当前时区有变化，请重新确认"。

---

## Decision 4: 任务状态机定义

### Decision

任务状态机包含 8 个状态，按以下规则流转。

### State Machine

```
                              ┌────────────────┐
                              │    TODO        │ 待开始
                              └──────┬─────────┘
                                     │ start()
                                     ▼
                              ┌────────────────┐
              complete()      │    DOING       │ 进行中
        ┌─────────────────────│                │◀─────┐
        │                     └──────┬─────────┘      │
        │                            │ pause()        │
        │                            ▼                │
        │                     ┌────────────────┐      │
        │                     │    PAUSED      │ 已暂停
        │                     │                │      │ resume()
        │                     └──────┬─────────┘      │
        │                            │ resume()       │
        │                            └────────────────┘
        │
        │                            switch() 自动暂停
        │                                     │
        ▼                                     ▼
┌────────────────┐                   ┌────────────────┐
│     DONE       │ 已完成            │  AI_RUNNING    │ AI 处理中
└────────────────┘                   └──────┬─────────┘
                                            │ AI 完成
                                            ▼
                                     ┌────────────────┐
                                     │   WAITING      │ 等待用户确认
                                     └──────┬─────────┘
                                            │ 用户确认/拒绝
                                            └──────────────────► DOING / PAUSED

从任何状态都可以：
  - cancel()    → CANCELLED
  - complete()  → DONE （除 CANCELLED / DONE 外）
```

### 转换矩阵

| From \ To | TODO | PLANNED | DOING | PAUSED | AI_RUNNING | WAITING | DONE | CANCELLED |
|-----------|------|---------|-------|--------|------------|---------|------|-----------|
| TODO | - | plan | start | - | - | - | complete | cancel |
| PLANNED | unplan | - | start | - | - | - | complete | cancel |
| DOING | - | - | - | pause | delegate | - | complete | cancel |
| PAUSED | - | - | resume | - | delegate | - | complete | cancel |
| AI_RUNNING | - | - | - | - | - | ai_done | complete | cancel |
| WAITING | - | - | confirm | - | - | - | complete | cancel/reject |
| DONE | - | - | - | - | - | - | - | - |
| CANCELLED | - | - | - | - | - | - | - | - |

### 备注

- `TODO` 与 `PLANNED` 区别：`TODO` 是刚创建无明确时间，`PLANNED` 是设置了 `start_time` 等待开始。
- 第一版简化：可只实现 `TODO / DOING / PAUSED / DONE / CANCELLED`，`AI_RUNNING / WAITING / PLANNED` 预留 enum 值但不强制实现流转。

---

## Decision 5: 提醒规则与事件设计

### Decision

两层模型：`reminder_rules`（策略）+ `reminder_events`（具体某次触发）。

### Rule Types & Default Generation

| Rule Type | 触发条件 | 默认生成时机 | 第一版实现 |
|-----------|---------|-------------|-----------|
| START | 任务 `start_time` 到达 | 用户设置 `start_time` 时 | ✅ |
| DEADLINE | 截止前 N 分钟 | 截止任务创建时，按"1 天 / 3 小时 / 30 分钟"三档 | ✅ |
| REPEAT | cron 表达式或固定间隔 | 长期任务（`estimated_minutes > 240`）每天晚上 21:00 | ✅ |
| REVIEW | 任务完成后第 N 天 | 记忆型任务完成后，按"1 / 3 / 7 / 14 天"四档 | ✅ |
| INACTIVE | 长期未推进 N 天 | 长期推进任务创建时，按"3 / 7 / 14 天"三档 | ✅ |
| PROGRESS | 阶段推进提醒 | 截止任务且 `estimated_minutes > 240` 时 | ✅ |
| AI_DONE | AI 完成委托任务 | 用户触发"交给 AI"操作时 | ✅ |

### Event Lifecycle

```
PENDING  →  SENT  →  SNOOZED  →  PENDING (重新触发)
                  →  DONE
                  →  IGNORED
```

### Quartz 集成方案

- **持久化**：使用 JDBC JobStore，与业务数据库共享 PostgreSQL（不同表前缀 `qrtz_*`）。
- **触发器**：每个 `reminder_event` 创建时同步注册一个 Quartz Trigger，`trigger_time` 对应 `StartTime`。
- **恢复策略**：服务重启后 Quartz 从 `qrtz_*` 表恢复 trigger，不丢失。
- **合并 Job**：单个 `ReminderFireJob`，参数为 `eventId`，触发时：
  1. 加载 `reminder_event`，校验状态仍为 `PENDING`（避免重复触发）。
  2. 生成 `notification` 记录。
  3. 推送 Web SSE / Web Push / Android Push / 鸿蒙 Push。
  4. 更新 `reminder_event.status = SENT`。

---

## Decision 6: AI Prompt 结构与 Schema

### Prompt 模板分层

```
ai/
├── prompt/
│   ├── system/
│   │   ├── task-parser.md          # 任务解析 System Prompt
│   │   ├── snapshot-summarizer.md  # 快照总结 System Prompt
│   │   ├── resume-advisor.md       # 恢复建议 System Prompt
│   │   ├── note-refiner.md         # 笔记整理 System Prompt
│   │   ├── review-card.md          # 复习卡片 System Prompt
│   │   └── reminder-planner.md     # 提醒计划 System Prompt
│   └── template/
│       └── (动态变量占位符)
```

### System Prompt 通用规则（嵌入所有 Prompt）

```
你的输出必须遵守以下规则：
1. 仅返回一个合法的 JSON 对象，不要有任何额外文本（无 markdown 代码块标记、无注释）。
2. 所有文本字段值必须与用户输入语言保持一致（用户用中文你用中文，用户用英文你用英文，混合则混合）。
3. 时间字段使用 ISO 8601 格式（例如 2026-06-26T20:00:00），不要带时区后缀（后端会按用户时区处理）。
4. 不要编造用户未提及的事实；不确定的字段返回 null。
5. 严格遵守 schema，不要新增字段。
```

### Task Parser Output Schema

```json
{
  "type": "object",
  "properties": {
    "title": {"type": "string", "maxLength": 200},
    "description": {"type": "string"},
    "taskType": {
      "type": "string",
      "enum": ["NORMAL", "DEADLINE", "SCHEDULED", "LONG_TERM", "MEMORY", "AI_DELEGATED"]
    },
    "startTime": {"type": ["string", "null"], "format": "date-time"},
    "deadline": {"type": ["string", "null"], "format": "date-time"},
    "estimatedMinutes": {"type": ["integer", "null"], "minimum": 1, "maximum": 10080},
    "priority": {"type": "integer", "minimum": 0, "maximum": 5, "default": 2},
    "reminderRules": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "type": {"type": "string", "enum": ["START", "DEADLINE", "REPEAT", "REVIEW", "INACTIVE", "PROGRESS"]},
          "description": {"type": "string"}
        },
        "required": ["type", "description"]
      }
    },
    "confidence": {"type": "number", "minimum": 0, "maximum": 1},
    "needsClarification": {"type": "array", "items": {"type": "string"}}
  },
  "required": ["title", "taskType", "confidence"]
}
```

### Snapshot Summarizer Output Schema

```json
{
  "type": "object",
  "properties": {
    "aiSummary": {"type": "string", "maxLength": 500},
    "currentProgress": {"type": "string", "maxLength": 500},
    "pauseReason": {"type": "string", "maxLength": 200},
    "nextAction": {"type": "string", "maxLength": 300},
    "openQuestions": {"type": "array", "items": {"type": "string"}, "maxItems": 10},
    "reminderSuggestion": {"type": "string", "maxLength": 200}
  },
  "required": ["aiSummary", "currentProgress", "nextAction"]
}
```

### 兜底策略

当 AI 输出无法解析或 schema 校验失败：
1. 重试 1 次（temperature 调高 0.1）。
2. 仍失败则使用兜底模板（纯文本总结，字段值直接复制用户原文）：
   ```json
   {
     "aiSummary": "<用户原文>",
     "currentProgress": "<用户原文>",
     "pauseReason": null,
     "nextAction": "请用户补充下一步",
     "openQuestions": [],
     "reminderSuggestion": null
   }
   ```
3. 在 `ai_jobs.error_message` 中记录失败原因。

---

## Decision 7: 推送通道架构

### Decision

统一抽象 `NotificationChannel` 接口，多通道并存，站内通知保底。

### Channels

| Channel | 触发方式 | 优先级 | 第一版 |
|---------|---------|--------|--------|
| IN_APP（站内通知） | 写 `notifications` 表，驾驶舱/SSE 下发 | P0 保底 | ✅ |
| WEB_SSE（Web 实时） | 用户在线时通过 SSE 推送 | P1 实时 | ✅ |
| WEB_PUSH（浏览器推送） | Web Push API + Service Worker | P2 浏览器后台 | ⚠️ 预留接口 |
| ANDROID_PUSH | FCM / 国内厂商通道 | P2 移动后台 | ⚠️ 预留接口 |
| HARMONY_PUSH | HMS Push Kit | P2 鸿蒙后台 | ⚠️ 预留接口 |

### Implementation

```java
public interface NotificationChannel {
    String getName();
    boolean isEnabled();
    SendResult send(Notification notification, UserDevice device);
}

// 主入口
@Service
public class NotificationService {
    private final List<NotificationChannel> channels;

    public void notifyUser(Long userId, Notification notification) {
        // 1. 永远先写 IN_APP（保底）
        inAppChannel.send(notification, null);

        // 2. 遍历用户所有启用设备，按设备类型选通道
        for (UserDevice device : deviceService.findByUserId(userId)) {
            channels.stream()
                .filter(c -> c.supports(device))
                .forEach(c -> c.send(notification, device));
        }
    }
}
```

---

## Decision 8: 数据库选型与 schema 策略

### Decision

PostgreSQL 15+ + JSONB 用于动态字段，使用 Flyway 管理 schema 迁移。

### Rationale

- **关系型**：任务、用户、提醒事件之间关系明确，需要事务保证。
- **JSONB**：`task_snapshots.open_questions`、`ai_jobs.input_payload` 等动态字段用 JSONB 避免频繁 ALTER TABLE。
- **全文搜索**：第一版搜索可以用 PostgreSQL 内置 `tsvector`（中文需要 `pg_jieba` 或 `zhparser` 扩展），不引入 Elasticsearch。
- **时区**：所有 `timestamp` 列使用 `timestamptz`（带时区），统一存储 UTC。

### Index 策略

| 表 | 索引 |
|----|------|
| `tasks` | `(user_id, status)`, `(user_id, deadline)`, `(user_id, last_active_time)` |
| `reminder_events` | `(user_id, trigger_time)`, `(status, trigger_time)` |
| `task_snapshots` | `(task_id, created_at DESC)` |
| `notifications` | `(user_id, read_status, created_at DESC)` |

---

## Decision 9: 项目构建与部署

### Build

- **后端**：Maven 或 Gradle（推荐 Maven，配置更直观）。Java 21（LTS，支持虚拟线程，对高并发 SSE 友好）。
- **前端**：pnpm + Vite + React 18 + TypeScript（React 生态最成熟，符合 spec 假设）。UI 库推荐 shadcn/ui（可定制，避免 antd 重型依赖）。
- **移动端**：
  - Android：Gradle + Kotlin + Jetpack Compose（WebView 壳）
  - 鸿蒙：DevEco Studio + ArkTS + ArkUI（Web 嵌入）

### Deploy

- **开发环境**：Docker Compose（PostgreSQL + Redis + MinIO + 后端 + 前端）。
- **生产环境**：单机 Docker Compose 即可（第一版个人使用），后续可迁移 K8s。

```yaml
# docker-compose.yml 示意
services:
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: aitaskos
      POSTGRES_USER: aitaskos
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    volumes:
      - pg_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

  minio:
    image: minio/minio:latest
    command: server /data
    environment:
      MINIO_ROOT_USER: ${MINIO_USER}
      MINIO_ROOT_PASSWORD: ${MINIO_PASSWORD}
    volumes:
      - minio_data:/data

  backend:
    build: ./backend
    depends_on: [postgres, redis, minio]
    environment:
      SPRING_PROFILES_ACTIVE: prod
      AI_BASE_URL: ${AI_BASE_URL}
      AI_API_KEY: ${AI_API_KEY}

  frontend:
    build: ./frontend
    ports:
      - "80:80"
```

---

## Decision 10: 实时通信（SSE vs WebSocket）

### Decision

使用 **SSE (Server-Sent Events)**，不使用 WebSocket。

### Rationale

| 维度 | SSE | WebSocket |
|------|-----|-----------|
| 复杂度 | 低（HTTP/1.1 长连接） | 高（需独立的握手、心跳、重连逻辑） |
| 单向 vs 双向 | 服务端推送足够（通知场景） | 双向（第一版用不到） |
| Spring 支持 | `SseEmitter` 原生支持 | 需 `spring-boot-starter-websocket` |
| 浏览器兼容 | 全部主流浏览器 | 全部主流浏览器 |
| HTTP/2 友好度 | 是 | 一般 |
| 移动网络稳定性 | 较好（自动重连） | 一般 |

通知场景只需要服务端 → 客户端的单向推送（通知、AI 流式响应），SSE 完全够用。AI 对话的流式输出也使用 SSE（OpenAI 兼容协议本身就是 SSE）。

---

## Decision 11: 鉴权方案

### Decision

JWT（Access Token + Refresh Token）+ Spring Security。

### Token 策略

- **Access Token**：有效期 2 小时，存 HttpOnly Cookie + 内存（前端用于读取 user info）。
- **Refresh Token**：有效期 30 天，存 HttpOnly Cookie（防 XSS）。
- **存储**：`login_tokens` 表记录 refresh token 与用户/设备的绑定，支持主动吊销。
- **多端共存**：每个设备独立 refresh token，互不影响。

### 路由保护

```java
@Configuration
@EnableWebSecurity
public class SecurityConfig {
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable())  // 前后端分离 + JWT
            .sessionManagement(session -> session.sessionCreationPolicy(STATELESS))
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/auth/**", "/api/public/**").permitAll()
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }
}
```

### 资源所有权校验

所有 service 方法在加载 task/note/file 时，强制按 `userId` 过滤：

```java
public Task getTask(Long taskId, Long currentUserId) {
    return taskRepository.findByIdAndUserId(taskId, currentUserId)
        .orElseThrow(() -> new ResourceNotFoundException("Task not found"));
}
```

---

## Decision 12: 并发编辑冲突处理

### Decision

使用 `version` 字段（乐观锁）。

### Implementation

- 所有主要实体增加 `version` 列（integer，初始 0）。
- 每次更新 SQL 包含 `WHERE version = ?`，更新 `version = version + 1`。
- 影响行数为 0 时抛出 `OptimisticLockException`，前端收到 409 Conflict，提示用户刷新后重试。

```sql
UPDATE tasks
SET title = ?, status = ?, version = version + 1, updated_at = NOW()
WHERE id = ? AND user_id = ? AND version = ?;
```

---

## Decision 13: 文件存储与类型限制

### Decision

MinIO（S3 兼容）+ 白名单类型 + 大小限制。

### Implementation

```yaml
file:
  storage:
    type: minio  # 或 local
    endpoint: ${MINIO_ENDPOINT:http://minio:9000}
    access-key: ${MINIO_ACCESS_KEY}
    secret-key: ${MINIO_SECRET_KEY}
    bucket: aitaskos
  upload:
    max-size: 50MB
    allowed-types:
      - image/png
      - image/jpeg
      - image/webp
      - image/gif
      - audio/webm
      - audio/mp3
      - audio/wav
      - application/pdf
      - text/plain
      - text/markdown
      - text/x-markdown
      - application/json
      - application/zip
    blocked-extensions:
      - exe
      - bat
      - sh
      - js
      - msi
      - dmg
      - apk
```

---

## Decision 14: 第一版开发优先级（里程碑）

按 spec.md 阶段 1-7：

| 里程碑 | 内容 | 验收 |
|--------|------|------|
| M0 | 项目骨架（Spring Boot + Docker Compose + 数据库 + 鉴权） | 能启动，能登录 |
| M1 | 任务 CRUD + 状态机 | 能创建、开始、暂停、恢复、完成任务 |
| M2 | 任务快照 + 恢复卡片（纯文本总结，无 AI） | 能保存现场，恢复时显示上次输入 |
| M3 | 提醒规则 + 事件 + Quartz + 站内通知 | 到点能收到通知 |
| M4 | AI Gateway + 任务解析 + 快照总结 | 自然语言能解析为结构化任务 |
| M5 | 今日驾驶舱 + 任务列表 + 任务详情页 | Web 端能用 |
| M6 | 笔记与复习（固定间隔） | 能复习，能看 AI 笔记 |
| M7 | 快速记录（文字 + 语音） + AI 工作台（基础） | Web 端深度功能 |
| M8 | 移动端响应式 + Android/鸿蒙轻壳 | 多端能登录、提醒、快速记录 |

---

## Outstanding / Deferred（不在第一版解决）

- **向量记忆与 RAG**：第一版不做，仅预留接口。
- **多模型路由**：第一版不做，AI Gateway 单一 `base_url`。
- **GDPR / PIPL 合规**：第一版不做，预留扩展点。
- **第三方登录**：第一版不做，预留 OAuth2 IDP 接口。
- **代码运行沙箱**：第一版不做，工作台仅支持编辑。
- **离线模式（PWA）**：第一版简化为"在线模式，断网时显示提示"。

---

## References

- OpenAI API Reference: `https://platform.openai.com/docs/api-reference/chat`
- Spring Boot 3.x Docs: `https://docs.spring.io/spring-boot/index.html`
- Quartz Scheduler Docs: `https://www.quartz-scheduler.org/documentation/`
- MinIO Java SDK: `https://min.io/docs/minio/linux/developers/java/minio-java.html`
- PostgreSQL JSONB: `https://www.postgresql.org/docs/current/datatype-json.html`
- Web Speech API: `https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API`
- Android SpeechRecognizer: `https://developer.android.com/reference/android/speech/SpeechRecognizer`
- HMS ASR Kit: `https://developer.huawei.com/consumer/cn/doc/harmonyos-references/asr-overview-0000001078491910`
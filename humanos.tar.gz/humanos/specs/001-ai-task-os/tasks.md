# Tasks: AI Task OS

**Input**: Design documents from `/specs/001-ai-task-os/`

**Prerequisites**: plan.md ✅, spec.md ✅, research.md ✅, data-model.md ✅, contracts/ ✅, quickstart.md ✅

**Tests**: 本项目不强制 TDD，测试任务标记为可选（测试可在实现完成后补充）

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

---

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (e.g., US1, US2, US3)
- Include exact file paths in descriptions

## Path Conventions

- **Backend**: `backend/src/main/java/com/taskos/`
- **Frontend**: `frontend/src/`
- **Database**: `backend/src/main/resources/db/migration/`
- **Config**: `backend/src/main/resources/`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and basic structure

- [X] T001 Create project root structure with backend/, frontend/, android/, harmony/ directories
- [X] T002 Initialize backend with Spring Boot 3.3+ (Java 21) using Spring Initializr in backend/
- [X] T003 [P] Initialize frontend with Vite + React 18 + TypeScript + pnpm in frontend/
- [X] T004 [P] Create docker-compose.yml with PostgreSQL 16, Redis 7, MinIO services
- [X] T005 [P] Create .env.example with all required environment variables
- [X] T006 [P] Create Dockerfile.backend and Dockerfile.frontend for containerized builds
- [X] T007 [P] Create .gitignore for Java, Node, IDE files, and sensitive configs
- [X] T008 [P] Create README.md with project overview and quickstart instructions

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

### Database Schema

- [X] T009 Create Flyway migration V001__initial_schema.sql with all 12 core tables (users, user_devices, login_tokens, tasks, task_sessions, task_snapshots, notes, reminder_rules, reminder_events, notifications, ai_jobs, files) in backend/src/main/resources/db/migration/
- [X] T010 Create Flyway migration V002__add_indexes.sql with all required indexes per data-model.md

### Backend Common Infrastructure

- [X] T011 Create ApiResponse<T> wrapper class in backend/src/main/java/com/taskos/common/response/ApiResponse.java
- [X] T012 Create ErrorCode enum with all error code ranges in backend/src/main/java/com/taskos/common/response/ErrorCode.java
- [X] T013 Create GlobalExceptionHandler with @ControllerAdvice in backend/src/main/java/com/taskos/common/exception/GlobalExceptionHandler.java
- [X] T014 [P] Create custom exceptions: ResourceNotFoundException, BusinessException, ConflictException in backend/src/main/java/com/taskos/common/exception/
- [X] T015 Create application.yml with database, redis, minio, ai configuration in backend/src/main/resources/
- [X] T016 Create application-dev.yml and application-prod.yml profiles in backend/src/main/resources/

### Security & Authentication

- [X] T017 Create JwtService for token generation/validation in backend/src/main/java/com/taskos/common/security/JwtService.java
- [X] T018 Create JwtAuthFilter extending OncePerRequestFilter in backend/src/main/java/com/taskos/common/security/JwtAuthFilter.java
- [X] T019 Create UserPrincipal implementing UserDetails in backend/src/main/java/com/taskos/common/security/UserPrincipal.java
- [X] T020 Create SecurityConfig with filter chain, CSRF disabled, stateless session in backend/src/main/java/com/taskos/common/config/SecurityConfig.java

### Utility Classes

- [X] T021 [P] Create TimezoneUtils for timezone conversion in backend/src/main/java/com/taskos/common/utils/TimezoneUtils.java
- [X] T022 [P] Create JsonUtils for JSON parsing/validation in backend/src/main/java/com/taskos/common/utils/JsonUtils.java

### Frontend Foundation

- [X] T023 Install frontend dependencies: react-router-dom, axios, zustand, @radix-ui/react-*, tailwindcss
- [X] T024 Configure Tailwind CSS and shadcn/ui in frontend/
- [X] T025 Create base API client with axios interceptors (auth header, timezone header) in frontend/src/services/api.ts
- [X] T026 Create authStore with Zustand for user/auth state in frontend/src/stores/authStore.ts
- [X] T027 [P] Create common types (Task, User, etc.) in frontend/src/types/
- [X] T028 [P] Create utility functions (dateFormat, timezone, validators) in frontend/src/utils/

**Checkpoint**: Foundation ready - user story implementation can now begin in parallel

---

## Phase 3: User Story 10 - 用户登录与多端设备管理 (Priority: P1) 🎯 MVP Foundation

**Goal**: 用户可以使用邮箱或手机号注册登录，管理设备列表，确保数据隔离

**Independent Test**: 用户可以独立完成注册、登录、查看设备列表、退出登录的完整流程

### Backend Implementation for US10

- [X] T029 [P] [US10] Create User entity with all fields per data-model.md in backend/src/main/java/com/taskos/user/entity/User.java
- [X] T030 [P] [US10] Create UserDevice entity in backend/src/main/java/com/taskos/user/entity/UserDevice.java
- [X] T031 [P] [US10] Create LoginToken entity in backend/src/main/java/com/taskos/user/entity/LoginToken.java
- [X] T032 [P] [US10] Create UserMapper interface with MyBatis-Plus in backend/src/main/java/com/taskos/user/mapper/UserMapper.java
- [X] T033 [P] [US10] Create UserDeviceMapper interface in backend/src/main/java/com/taskos/user/mapper/UserDeviceMapper.java
- [X] T034 [P] [US10] Create LoginTokenMapper interface in backend/src/main/java/com/taskos/user/mapper/LoginTokenMapper.java
- [X] T035 [US10] Create RegisterRequest/LoginRequest/LoginResponse DTOs in backend/src/main/java/com/taskos/user/dto/
- [X] T036 [US10] Create UserService with register, login, refresh, logout methods in backend/src/main/java/com/taskos/user/service/UserService.java
- [X] T037 [US10] Create DeviceService for device registration/management in backend/src/main/java/com/taskos/user/service/DeviceService.java
- [X] T038 [US10] Create AuthController with /api/auth/* endpoints in backend/src/main/java/com/taskos/user/controller/AuthController.java
- [X] T039 [US10] Create UserController with /api/users/* endpoints in backend/src/main/java/com/taskos/user/controller/UserController.java
- [X] T040 [US10] Add password hashing with BCryptPasswordEncoder in UserService

### Frontend Implementation for US10

- [X] T041 [P] [US10] Create LoginPage with email/phone login form in frontend/src/pages/Login.tsx
- [X] T042 [P] [US10] Create RegisterPage with registration form in frontend/src/pages/Register.tsx
- [X] T043 [US10] Create authService with login/register/logout methods in frontend/src/services/auth.ts
- [X] T044 [US10] Implement protected route wrapper with auth check in frontend/src/App.tsx
- [X] T045 [US10] Add device registration on login (send X-Device-* headers) in frontend/src/services/api.ts

**Checkpoint**: User Story 10 complete - users can register, login, and manage devices

---

## Phase 4: User Story 1 - 自然语言创建任务 (Priority: P1) 🎯 MVP Core

**Goal**: 用户可以用自然语言创建任务，AI 解析任务字段，用户确认后保存

**Independent Test**: 用户可以在没有任何其他功能的情况下，仅通过此流程创建任务并查看任务详情

### Backend Implementation for US1

- [X] T046 [P] [US1] Create Task entity with all fields per data-model.md in backend/src/main/java/com/taskos/task/entity/Task.java
- [X] T047 [P] [US1] Create TaskMapper interface with custom query methods in backend/src/main/java/com/taskos/task/mapper/TaskMapper.java
- [X] T048 [US1] Create TaskRequest/TaskResponse/TaskParseRequest/TaskParseResponse DTOs in backend/src/main/java/com/taskos/task/dto/
- [X] T049 [US1] Create TaskService with CRUD methods in backend/src/main/java/com/taskos/task/service/TaskService.java
- [X] T050 [US1] Create TaskQueryService for list/detail queries in backend/src/main/java/com/taskos/task/service/TaskQueryService.java
- [X] T051 [US1] Create TaskController with /api/tasks/* endpoints (CRUD, parse) in backend/src/main/java/com/taskos/task/controller/TaskController.java
- [X] T052 [US1] Add userId filter to all task queries for data isolation in TaskQueryService

### AI Module for US1

- [X] T053 [P] [US1] Create AiGatewayService with OpenAI-compatible client in backend/src/main/java/com/taskos/ai/service/AiGatewayService.java
- [X] T054 [P] [US1] Create OpenAiClient with WebClient for /v1/chat/completions in backend/src/main/java/com/taskos/ai/client/OpenAiClient.java
- [X] T055 [P] [US1] Create AiJob entity in backend/src/main/java/com/taskos/ai/entity/AiJob.java
- [X] T056 [P] [US1] Create AiJobMapper interface in backend/src/main/java/com/taskos/ai/mapper/AiJobMapper.java
- [X] T057 [US1] Create TaskParserPrompt with system prompt + JSON schema in backend/src/main/java/com/taskos/ai/prompt/TaskParserPrompt.java
- [X] T058 [US1] Create AiTaskParserService with parse() method in backend/src/main/java/com/taskos/ai/service/AiTaskParserService.java
- [X] T059 [US1] Add JSON schema validation for AI response in AiTaskParserService
- [X] T060 [US1] Create AiController with /api/ai/parse-task endpoint in backend/src/main/java/com/taskos/ai/controller/AiController.java

### Frontend Implementation for US1

- [X] T061 [P] [US1] Create TaskCreatePage with natural language input + AI result confirmation in frontend/src/pages/TaskCreate.tsx
- [X] T062 [P] [US1] Create TaskDetailPage showing all task fields in frontend/src/pages/TaskDetail.tsx
- [X] T063 [US1] Create taskService with create/get/list methods in frontend/src/services/task.ts
- [X] T064 [US1] Create aiService with parseTask method in frontend/src/services/ai.ts
- [X] T065 [US1] Create taskStore for task state management in frontend/src/stores/taskStore.ts

**Checkpoint**: User Story 1 complete - users can create tasks via natural language

---

## Phase 5: User Story 2 - 任务状态流转 (Priority: P1) 🎯 MVP Core

**Goal**: 用户可以开始/暂停/恢复/完成任务，记录任务会话

**Independent Test**: 用户可以仅使用开始/暂停/恢复/完成操作跑通一个完整的任务生命周期

### Backend Implementation for US2

- [X] T066 [P] [US2] Create TaskSession entity in backend/src/main/java/com/taskos/task/entity/TaskSession.java
- [X] T067 [P] [US2] Create TaskSnapshot entity in backend/src/main/java/com/taskos/snapshot/entity/TaskSnapshot.java
- [X] T068 [P] [US2] Create TaskSessionMapper interface in backend/src/main/java/com/taskos/task/mapper/TaskSessionMapper.java
- [X] T069 [P] [US2] Create TaskSnapshotMapper interface in backend/src/main/java/com/taskos/snapshot/mapper/TaskSnapshotMapper.java
- [X] T070 [US2] Create StartTaskRequest/PauseTaskRequest/ResumeTaskResponse DTOs in backend/src/main/java/com/taskos/task/dto/
- [X] T071 [US2] Create TaskStateMachine with state transition validation in backend/src/main/java/com/taskos/task/service/TaskStateMachine.java
- [X] T072 [US2] Add start/pause/resume/complete methods to TaskService in backend/src/main/java/com/taskos/task/service/TaskService.java
- [X] T073 [US2] Create TaskSessionService for session management in backend/src/main/java/com/taskos/task/service/TaskSessionService.java
- [X] T074 [US2] Add /api/tasks/{id}/start, pause, resume, complete endpoints in TaskController
- [X] T075 [US2] Implement auto-pause on task switch (check current DOING task, pause it)

### Frontend Implementation for US2

- [X] T076 [P] [US2] Create FocusModePage with timer, session goal, pause button in frontend/src/pages/FocusMode.tsx
- [X] T077 [P] [US2] Create TaskResumePage showing resume card in frontend/src/pages/TaskResume.tsx
- [X] T078 [US2] Add start/pause/resume/complete methods to taskService in frontend/src/services/task.ts
- [X] T079 [US2] Create useTaskStateMachine hook for frontend state machine in frontend/src/hooks/useTaskStateMachine.ts

**Checkpoint**: User Story 2 complete - users can manage task lifecycle

---

## Phase 6: User Story 4 - 任务快照与 AI 总结 (Priority: P1) 🎯 MVP Core

**Goal**: 用户暂停时 AI 自动整理快照，恢复时展示 AI 生成的恢复卡片

**Independent Test**: 用户可以创建任务、开始、暂停（输入自然语言）、查看 AI 生成的快照、恢复时看到 AI 整理的恢复卡片

### Backend Implementation for US4

- [X] T080 [P] [US4] Create SnapshotSummarizerPrompt with system prompt + JSON schema in backend/src/main/java/com/taskos/ai/prompt/SnapshotSummarizerPrompt.java
- [X] T081 [P] [US4] Create ResumeAdvisorPrompt with system prompt + JSON schema in backend/src/main/java/com/taskos/ai/prompt/ResumeAdvisorPrompt.java
- [X] T082 [US4] Create AiSnapshotService with summarize() method in backend/src/main/java/com/taskos/ai/service/AiSnapshotService.java
- [X] T083 [US4] Create AiResumeService with generateResumeCard() method in backend/src/main/java/com/taskos/ai/service/AiResumeService.java
- [X] T084 [US4] Create SnapshotService with save/findById/findTimeline methods in backend/src/main/java/com/taskos/snapshot/service/SnapshotService.java
- [X] T085 [US4] Create SnapshotController with /api/snapshots/* endpoints in backend/src/main/java/com/taskos/snapshot/controller/SnapshotController.java
- [X] T086 [US4] Integrate AI summary into pause flow (async: save raw_input immediately, AI processes in background)
- [X] T087 [US4] Implement fallback when AI fails (return raw_input as aiSummary)

### Frontend Implementation for US4

- [X] T088 [P] [US4] Create SnapshotCard component showing AI summary in frontend/src/components/common/SnapshotCard.tsx
- [X] T089 [P] [US4] Create Timeline component showing all snapshots in frontend/src/components/common/Timeline.tsx
- [X] T090 [US4] Add AI job polling (or SSE notification) for async AI result in frontend/src/services/ai.ts

**Checkpoint**: User Story 4 complete - AI-powered snapshot summarization works

---

## Phase 7: User Story 3 - 智能提醒系统 (Priority: P1) 🎯 MVP Core

**Goal**: 系统自动生成提醒规则和事件，到时间触发通知

**Independent Test**: 用户可以创建一个带截止时间的任务，看到系统生成的多级提醒事件，到时间能收到通知

### Backend Implementation for US3

- [X] T091 [P] [US3] Create ReminderRule entity in backend/src/main/java/com/taskos/reminder/entity/ReminderRule.java
- [X] T092 [P] [US3] Create ReminderEvent entity in backend/src/main/java/com/taskos/reminder/entity/ReminderEvent.java
- [X] T093 [P] [US3] Create ReminderRuleMapper interface in backend/src/main/java/com/taskos/reminder/mapper/ReminderRuleMapper.java
- [X] T094 [P] [US3] Create ReminderEventMapper interface in backend/src/main/java/com/taskos/reminder/mapper/ReminderEventMapper.java
- [X] T095 [US3] Create ReminderGenerator service for auto-generating rules/events in backend/src/main/java/com/taskos/reminder/service/ReminderGenerator.java
- [X] T096 [US3] Create ReminderRuleService for CRUD operations in backend/src/main/java/com/taskos/reminder/service/ReminderRuleService.java
- [X] T097 [US3] Create ReminderEventService for event queries/updates in backend/src/main/java/com/taskos/reminder/service/ReminderEventService.java
- [X] T098 [US3] Create ReminderController with /api/reminders/* endpoints in backend/src/main/java/com/taskos/reminder/controller/ReminderController.java
- [X] T099 [US3] Configure Quartz with JDBC JobStore in backend/src/main/java/com/taskos/common/config/QuartzConfig.java
- [X] T100 [US3] Create ReminderFireJob that scans PENDING events and triggers notifications in backend/src/main/java/com/taskos/reminder/job/ReminderFireJob.java
- [X] T101 [US3] Create ReminderScheduler for scheduling Quartz jobs in backend/src/main/java/com/taskos/reminder/scheduler/ReminderScheduler.java

### Notification Module for US3

- [X] T102 [P] [US3] Create Notification entity in backend/src/main/java/com/taskos/notification/entity/Notification.java
- [X] T103 [P] [US3] Create NotificationMapper interface in backend/src/main/java/com/taskos/notification/mapper/NotificationMapper.java
- [X] T104 [US3] Create NotificationChannel interface in backend/src/main/java/com/taskos/notification/service/NotificationChannel.java
- [X] T105 [US3] Create InAppChannel (writes to DB) in backend/src/main/java/com/taskos/notification/service/InAppChannel.java
- [X] T106 [US3] Create NotificationService for multi-channel dispatch in backend/src/main/java/com/taskos/notification/service/NotificationService.java
- [X] T107 [US3] Create NotificationController with /api/notifications/* endpoints in backend/src/main/java/com/taskos/notification/controller/NotificationController.java

### Frontend Implementation for US3

- [X] T108 [P] [US3] Create ReminderCenterPage showing all reminders in frontend/src/pages/ReminderCenter.tsx
- [X] T109 [P] [US3] Create ReminderCard component with action buttons in frontend/src/components/common/ReminderCard.tsx
- [ ] T110 [US3] Add reminderService with list/process methods in frontend/src/services/reminder.ts

**Checkpoint**: User Story 3 complete - intelligent reminders work

---

## Phase 8: User Story 5 - 今日驾驶舱 (Priority: P1) 🎯 MVP Core

**Goal**: 用户登录后看到驾驶舱，回答"我现在最应该做什么"

**Independent Test**: 用户登录后看到的首页就是驾驶舱，可以从中进入新建任务、继续任务、开始专注、查看提醒等所有核心流程

### Backend Implementation for US5

- [ ] T111 [US5] Create DashboardService with getTodayData() method in backend/src/main/java/com/taskos/dashboard/service/DashboardService.java
- [ ] T112 [US5] Create DashboardController with /api/dashboard/today endpoint in backend/src/main/java/com/taskos/dashboard/controller/DashboardController.java
- [ ] T113 [US5] Implement aggregation query for: doing, mustDoToday, needResume, aiDone, reviewItems in DashboardService

### Frontend Implementation for US5

- [ ] T114 [US5] Create DashboardPage with all sections in frontend/src/pages/Dashboard.tsx
- [ ] T115 [US5] Create TaskCard component for dashboard items in frontend/src/components/common/TaskCard.tsx
- [ ] T116 [US5] Add natural language input box at top of dashboard in DashboardPage
- [ ] T117 [US5] Create layout with Sidebar, Header, AiAssistant in frontend/src/components/layout/
- [ ] T118 [US5] Wire up navigation from dashboard cards to respective pages

**Checkpoint**: User Story 5 complete - dashboard is the main entry point

---

## Phase 9: User Story 6 - 快速记录 (Priority: P2)

**Goal**: 用户可以快速记录文字/语音/文件，绑定到任务或暂存箱

**Independent Test**: 用户可以在任何页面打开快速记录，输入内容并选择绑定目标

### Backend Implementation for US6

- [ ] T119 [P] [US6] Create Note entity in backend/src/main/java/com/taskos/note/entity/Note.java
- [ ] T120 [P] [US6] Create File entity in backend/src/main/java/com/taskos/file/entity/File.java
- [ ] T121 [P] [US6] Create NoteMapper interface in backend/src/main/java/com/taskos/note/mapper/NoteMapper.java
- [ ] T122 [P] [US6] Create FileMapper interface in backend/src/main/java/com/taskos/file/mapper/FileMapper.java
- [ ] T123 [US6] Create NoteService with CRUD and bind-to-task methods in backend/src/main/java/com/taskos/note/service/NoteService.java
- [ ] T124 [US6] Create FileStorageService with MinIO integration in backend/src/main/java/com/taskos/file/service/FileStorageService.java
- [ ] T125 [US6] Configure MinIO client in backend/src/main/java/com/taskos/common/config/MinioConfig.java
- [ ] T126 [US6] Create NoteController with /api/notes/* endpoints in backend/src/main/java/com/taskos/note/controller/NoteController.java
- [ ] T127 [US6] Create FileController with /api/files/* endpoints in backend/src/main/java/com/taskos/file/controller/FileController.java
- [ ] T128 [US6] Add quick-record endpoint POST /api/notes/quick with task binding options

### Frontend Implementation for US6

- [ ] T129 [P] [US6] Create QuickRecordModal component with text/voice/file tabs in frontend/src/components/common/QuickRecordModal.tsx
- [ ] T130 [P] [US6] Create InboxPage showing unbound notes in frontend/src/pages/Inbox.tsx
- [ ] T131 [US6] Create noteService in frontend/src/services/note.ts
- [ ] T132 [US6] Create fileService in frontend/src/services/file.ts
- [ ] T133 [US6] Add useSpeechRecognition hook for Web Speech API in frontend/src/hooks/useSpeechRecognition.ts
- [ ] T134 [US6] Add global QuickRecordButton in layout that opens QuickRecordModal

**Checkpoint**: User Story 6 complete - quick recording works

---

## Phase 10: User Story 7 - AI 笔记深化与复习 (Priority: P2)

**Goal**: AI 整理笔记，固定间隔复习提醒

**Independent Test**: 用户可以手动触发 AI 笔记整理，复习提醒可以独立配置和触发

### Backend Implementation for US7

- [ ] T135 [P] [US7] Create NoteRefinerPrompt with system prompt in backend/src/main/java/com/taskos/ai/prompt/NoteRefinerPrompt.java
- [ ] T136 [P] [US7] Create ReviewCardPrompt with system prompt in backend/src/main/java/com/taskos/ai/prompt/ReviewCardPrompt.java
- [ ] T137 [US7] Create AiNoteService with refineNote() method in backend/src/main/java/com/taskos/ai/service/AiNoteService.java
- [ ] T138 [US7] Create AiReviewService with generateReviewCard() method in backend/src/main/java/com/taskos/ai/service/AiReviewService.java
- [ ] T139 [US7] Create ReviewService for review logic in backend/src/main/java/com/taskos/review/service/ReviewService.java
- [ ] T140 [US7] Create ReviewController with /api/review/* endpoints in backend/src/main/java/com/taskos/review/controller/ReviewController.java
- [ ] T141 [US7] Add review reminder generation (1/3/7/14 days) to ReminderGenerator

### Frontend Implementation for US7

- [ ] T142 [P] [US7] Create ReviewPage showing today's review items in frontend/src/pages/ReviewPage.tsx
- [ ] T143 [P] [US7] Create ReviewCard component in frontend/src/components/common/ReviewCard.tsx
- [ ] T144 [US7] Add "AI 整理笔记" button to task detail page
- [ ] T145 [US7] Add reviewService in frontend/src/services/review.ts

**Checkpoint**: User Story 7 complete - AI note refinement and review work

---

## Phase 11: User Story 8 - 多端支持 (Priority: P2)

**Goal**: Web 完整功能，移动端响应式，Android/鸿蒙轻壳

**Independent Test**: 核心闭环在四端均可独立完成

### Web Responsive for US8

- [ ] T146 [US8] Add responsive CSS for all existing pages (mobile-first approach)
- [ ] T147 [US8] Test and fix mobile viewport issues

### SSE Real-time Notifications for US8

- [ ] T148 [US8] Create WebSseChannel implementing NotificationChannel in backend/src/main/java/com/taskos/notification/service/WebSseChannel.java
- [ ] T149 [US8] Create SseController with GET /api/notifications/stream endpoint in backend/src/main/java/com/taskos/notification/controller/SseController.java
- [ ] T150 [US8] Create useSse hook for EventSource connection in frontend/src/hooks/useSse.ts

### Android Shell for US8

- [ ] T151 [P] [US8] Create Android project with Kotlin + Jetpack Compose in android/
- [ ] T152 [P] [US8] Create MainActivity with WebView in android/app/src/main/java/com/taskos/app/MainActivity.kt
- [ ] T153 [US8] Create NotificationService for FCM push in android/app/src/main/java/com/taskos/app/NotificationService.kt
- [ ] T154 [US8] Create SpeechService wrapping SpeechRecognizer in android/app/src/main/java/com/taskos/app/SpeechService.kt
- [ ] T155 [US8] Add push token registration endpoint in NotificationController

### HarmonyOS Shell for US8

- [ ] T156 [P] [US8] Create HarmonyOS project with ArkTS + ArkUI in harmony/
- [ ] T157 [P] [US8] Create Index page with Web component in harmony/entry/src/main/ets/pages/Index.ets
- [ ] T158 [US8] Implement native notification handling with HMS Push Kit
- [ ] T159 [US8] Implement ASR integration for voice input

**Checkpoint**: User Story 8 complete - multi-platform support

---

## Phase 12: User Story 9 - AI 工作台 (Priority: P3)

**Goal**: Web 端三栏工作台，Markdown 编辑，AI 对话

**Independent Test**: 用户可以在工作台编辑笔记、与 AI 对话

### Backend Implementation for US9

- [ ] T160 [P] [US9] Create AiChatService with chat() and streamChat() methods in backend/src/main/java/com/taskos/ai/service/AiChatService.java
- [ ] T161 [US9] Add GET /api/ai/chat/stream SSE endpoint in AiController

### Frontend Implementation for US9

- [ ] T162 [P] [US9] Create AiWorkspacePage with three-column layout in frontend/src/pages/AiWorkspace.tsx
- [ ] T163 [P] [US9] Create MarkdownEditor component with preview in frontend/src/components/common/MarkdownEditor.tsx
- [ ] T164 [US9] Create AiAssistantPanel component for chat in frontend/src/components/common/AiAssistantPanel.tsx
- [ ] T165 [US9] Add file/note sidebar in workspace

**Checkpoint**: User Story 9 complete - AI workspace works

---

## Phase 13: Polish & Cross-Cutting Concerns

**Purpose**: Improvements that affect multiple user stories

- [ ] T166 [P] Add comprehensive logging for all AI calls
- [ ] T167 [P] Add request/response logging filter for debugging
- [ ] T168 [P] Implement rate limiting for AI endpoints
- [ ] T169 [P] Add API documentation with Swagger/OpenAPI annotations
- [ ] T170 [P] Create seed data SQL for testing
- [ ] T171 Run quickstart.md validation (Docker Compose up, all services healthy)
- [ ] T172 [P] Security audit: verify all endpoints have userId filter
- [ ] T173 [P] Performance optimization: add caching for frequently accessed data
- [ ] T174 [P] Add unit tests for core services (optional, can be done after MVP)
- [ ] T175 [P] Add integration tests for API endpoints (optional)

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: No dependencies - can start immediately
- **Foundational (Phase 2)**: Depends on Setup completion - BLOCKS all user stories
- **User Story 10 (Phase 3)**: Depends on Foundational - required for auth
- **User Stories 1-5 (Phases 4-8)**: Depend on US10 (auth) + Foundational
- **User Stories 6-9 (Phases 9-12)**: Depend on earlier USs but can be parallelized
- **Polish (Phase 13)**: Depends on all desired user stories being complete

### User Story Dependencies

- **US10 (P1)**: Foundation for auth - must complete first
- **US1 (P1)**: Can start after US10 - creates tasks
- **US2 (P1)**: Depends on US1 (needs Task entity) - task lifecycle
- **US4 (P1)**: Depends on US2 (needs TaskSession/Snapshot) - AI summary
- **US3 (P1)**: Depends on US1 (needs Task) - reminders
- **US5 (P1)**: Depends on US1, US2, US3, US4 - aggregates all
- **US6 (P2)**: Depends on US1 (needs Task for binding) - quick record
- **US7 (P2)**: Depends on US4, US6 (needs Note/Snapshot) - AI notes
- **US8 (P2)**: Depends on US1-5 - multi-platform
- **US9 (P3)**: Depends on US1, US4 - workspace

### Parallel Opportunities

Within each user story phase:
- All [P] tasks can run in parallel
- Models/Mappers can be created in parallel
- Frontend pages can be created in parallel with backend

Across user stories:
- US1 and US3 can be parallelized (different files)
- US6 can start once US1's Task entity is ready
- US8 can start once core backend APIs are stable

---

## Parallel Example: User Story 1

```bash
# Launch all entity/mapper creation tasks together:
Task: "Create Task entity in backend/src/main/java/com/taskos/task/entity/Task.java"
Task: "Create TaskMapper interface in backend/src/main/java/com/taskos/task/mapper/TaskMapper.java"

# Launch all AI module tasks together:
Task: "Create AiGatewayService in backend/src/main/java/com/taskos/ai/service/AiGatewayService.java"
Task: "Create OpenAiClient in backend/src/main/java/com/taskos/ai/client/OpenAiClient.java"
Task: "Create AiJob entity in backend/src/main/java/com/taskos/ai/entity/AiJob.java"
```

---

## Implementation Strategy

### MVP First (US10 + US1 + US2 + US5)

1. Complete Phase 1: Setup
2. Complete Phase 2: Foundational
3. Complete Phase 3: US10 (Auth)
4. Complete Phase 4: US1 (Create Tasks with AI)
5. Complete Phase 5: US2 (Task Lifecycle)
6. Complete Phase 8: US5 (Dashboard)
7. **STOP and VALIDATE**: Core MVP loop works
8. Deploy/demo

### Incremental Delivery

1. Foundation → US10 → US1 → US2 → US5 → **MVP Demo**
2. Add US4 → US3 → US6 → Full core features
3. Add US7 → US8 → US9 → Complete product

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Each user story should be independently completable and testable
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- Avoid: vague tasks, same file conflicts, cross-story dependencies that break independence
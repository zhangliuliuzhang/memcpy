-- V002__add_indexes.sql
-- AI Task OS Database Indexes
-- Performance optimization for common queries

-- ============================================
-- USERS indexes
-- ============================================
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_status ON users(status);

-- ============================================
-- USER_DEVICES indexes
-- ============================================
CREATE INDEX idx_user_devices_user_id ON user_devices(user_id);
CREATE INDEX idx_user_devices_device_type ON user_devices(device_type);
CREATE INDEX idx_user_devices_last_active ON user_devices(last_active_at DESC);

-- ============================================
-- LOGIN_TOKENS indexes
-- ============================================
CREATE INDEX idx_login_tokens_user_id ON login_tokens(user_id);
CREATE INDEX idx_login_tokens_refresh_token ON login_tokens(refresh_token);
CREATE INDEX idx_login_tokens_expires_at ON login_tokens(expires_at);
CREATE INDEX idx_login_tokens_revoked ON login_tokens(revoked);

-- ============================================
-- TASKS indexes (most critical for performance)
-- ============================================
CREATE INDEX idx_tasks_user_id ON tasks(user_id);
CREATE INDEX idx_tasks_status ON tasks(status);
CREATE INDEX idx_tasks_task_type ON tasks(task_type);
CREATE INDEX idx_tasks_deadline ON tasks(deadline);
CREATE INDEX idx_tasks_start_time ON tasks(start_time);
CREATE INDEX idx_tasks_last_active ON tasks(last_active_time DESC);
CREATE INDEX idx_tasks_deleted_at ON tasks(deleted_at);
CREATE INDEX idx_tasks_user_status ON tasks(user_id, status);
CREATE INDEX idx_tasks_user_deadline ON tasks(user_id, deadline);
CREATE INDEX idx_tasks_user_active ON tasks(user_id, last_active_time DESC);

-- ============================================
-- TASK_SESSIONS indexes
-- ============================================
CREATE INDEX idx_task_sessions_task_id ON task_sessions(task_id);
CREATE INDEX idx_task_sessions_user_id ON task_sessions(user_id);
CREATE INDEX idx_task_sessions_started_at ON task_sessions(started_at DESC);
CREATE INDEX idx_task_sessions_task_started ON task_sessions(task_id, started_at DESC);

-- ============================================
-- TASK_SNAPSHOTS indexes
-- ============================================
CREATE INDEX idx_task_snapshots_task_id ON task_snapshots(task_id);
CREATE INDEX idx_task_snapshots_user_id ON task_snapshots(user_id);
CREATE INDEX idx_task_snapshots_created_at ON task_snapshots(created_at DESC);
CREATE INDEX idx_task_snapshots_type ON task_snapshots(snapshot_type);
CREATE INDEX idx_task_snapshots_task_created ON task_snapshots(task_id, created_at DESC);

-- ============================================
-- NOTES indexes
-- ============================================
CREATE INDEX idx_notes_user_id ON notes(user_id);
CREATE INDEX idx_notes_task_id ON notes(task_id);
CREATE INDEX idx_notes_note_type ON notes(note_type);
CREATE INDEX idx_notes_created_at ON notes(created_at DESC);
CREATE INDEX idx_notes_user_task ON notes(user_id, task_id);
CREATE INDEX idx_notes_user_created ON notes(user_id, created_at DESC);

-- ============================================
-- REMINDER_RULES indexes
-- ============================================
CREATE INDEX idx_reminder_rules_user_id ON reminder_rules(user_id);
CREATE INDEX idx_reminder_rules_task_id ON reminder_rules(task_id);
CREATE INDEX idx_reminder_rules_rule_type ON reminder_rules(rule_type);
CREATE INDEX idx_reminder_rules_enabled ON reminder_rules(enabled);
CREATE INDEX idx_reminder_rules_user_enabled ON reminder_rules(user_id, enabled);

-- ============================================
-- REMINDER_EVENTS indexes (critical for scheduler)
-- ============================================
CREATE INDEX idx_reminder_events_user_id ON reminder_events(user_id);
CREATE INDEX idx_reminder_events_task_id ON reminder_events(task_id);
CREATE INDEX idx_reminder_events_rule_id ON reminder_events(rule_id);
CREATE INDEX idx_reminder_events_status ON reminder_events(status);
CREATE INDEX idx_reminder_events_trigger_time ON reminder_events(trigger_time);
CREATE INDEX idx_reminder_events_snooze_until ON reminder_events(snooze_until);
CREATE INDEX idx_reminder_events_pending_trigger ON reminder_events(status, trigger_time);
CREATE INDEX idx_reminder_events_user_pending ON reminder_events(user_id, status);

-- ============================================
-- NOTIFICATIONS indexes
-- ============================================
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_task_id ON notifications(task_id);
CREATE INDEX idx_notifications_read_status ON notifications(read_status);
CREATE INDEX idx_notifications_created_at ON notifications(created_at DESC);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, read_status);
CREATE INDEX idx_notifications_user_created ON notifications(user_id, created_at DESC);

-- ============================================
-- AI_JOBS indexes
-- ============================================
CREATE INDEX idx_ai_jobs_user_id ON ai_jobs(user_id);
CREATE INDEX idx_ai_jobs_task_id ON ai_jobs(task_id);
CREATE INDEX idx_ai_jobs_status ON ai_jobs(status);
CREATE INDEX idx_ai_jobs_job_type ON ai_jobs(job_type);
CREATE INDEX idx_ai_jobs_created_at ON ai_jobs(created_at DESC);
CREATE INDEX idx_ai_jobs_user_status ON ai_jobs(user_id, status);
CREATE INDEX idx_ai_jobs_pending ON ai_jobs(status) WHERE status IN ('PENDING', 'RUNNING');

-- ============================================
-- FILES indexes
-- ============================================
CREATE INDEX idx_files_user_id ON files(user_id);
CREATE INDEX idx_files_task_id ON files(task_id);
CREATE INDEX idx_files_note_id ON files(note_id);
CREATE INDEX idx_files_created_at ON files(created_at DESC);
CREATE INDEX idx_files_user_task ON files(user_id, task_id);

-- ============================================
-- JSONB indexes (for JSON queries)
-- ============================================
CREATE INDEX idx_users_settings ON users USING GIN (settings);
CREATE INDEX idx_task_snapshots_open_questions ON task_snapshots USING GIN (open_questions);
CREATE INDEX idx_task_snapshots_related_files ON task_snapshots USING GIN (related_files);
CREATE INDEX idx_task_snapshots_related_notes ON task_snapshots USING GIN (related_notes);
CREATE INDEX idx_notifications_action_data ON notifications USING GIN (action_data);
CREATE INDEX idx_ai_jobs_input_payload ON ai_jobs USING GIN (input_payload);
CREATE INDEX idx_ai_jobs_output_payload ON ai_jobs USING GIN (output_payload);
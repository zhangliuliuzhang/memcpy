-- V001__initial_schema.sql
-- AI Task OS Initial Database Schema
-- PostgreSQL 16 with TIMESTAMPTZ (UTC), JSONB, Optimistic Locking

-- ============================================
-- ENUM TYPES (using CHECK constraints for compatibility)
-- ============================================

-- ============================================
-- 1. USERS
-- ============================================
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    phone VARCHAR(20) NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    avatar_url VARCHAR(500) NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'INACTIVE', 'SUSPENDED', 'DELETED')),
    timezone VARCHAR(50) NOT NULL DEFAULT 'Asia/Shanghai',
    settings JSONB NOT NULL DEFAULT '{}',
    version INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE users IS '用户表';
COMMENT ON COLUMN users.settings IS '用户配置JSON: {theme, notification_enabled, language, etc.}';

-- ============================================
-- 2. USER_DEVICES
-- ============================================
CREATE TABLE user_devices (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_type VARCHAR(20) NOT NULL CHECK (device_type IN ('WEB', 'ANDROID', 'HARMONY')),
    device_id VARCHAR(100) NOT NULL,
    device_name VARCHAR(100) NULL,
    push_token VARCHAR(500) NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    last_active_at TIMESTAMPTZ NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(user_id, device_id)
);

COMMENT ON TABLE user_devices IS '用户设备表，支持多端登录';

-- ============================================
-- 3. LOGIN_TOKENS
-- ============================================
CREATE TABLE login_tokens (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_id BIGINT NOT NULL REFERENCES user_devices(id) ON DELETE CASCADE,
    refresh_token VARCHAR(500) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    revoked BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE login_tokens IS '登录令牌表，JWT refresh token 存储';

-- ============================================
-- 4. TASKS
-- ============================================
CREATE TABLE tasks (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    task_type VARCHAR(20) NOT NULL DEFAULT 'NORMAL' CHECK (task_type IN ('NORMAL', 'DEADLINE', 'SCHEDULED', 'LONG_TERM', 'MEMORY', 'AI_DELEGATED')),
    status VARCHAR(20) NOT NULL DEFAULT 'TODO' CHECK (status IN ('TODO', 'PLANNED', 'DOING', 'PAUSED', 'AI_RUNNING', 'WAITING', 'DONE', 'CANCELLED')),
    priority INTEGER NOT NULL DEFAULT 2 CHECK (priority BETWEEN 1 AND 5),
    start_time TIMESTAMPTZ NULL,
    deadline TIMESTAMPTZ NULL,
    estimated_minutes INTEGER NULL CHECK (estimated_minutes > 0),
    actual_minutes INTEGER NULL DEFAULT 0 CHECK (actual_minutes >= 0),
    progress INTEGER NOT NULL DEFAULT 0 CHECK (progress BETWEEN 0 AND 100),
    current_snapshot_id BIGINT NULL,
    last_active_time TIMESTAMPTZ NULL,
    deleted_at TIMESTAMPTZ NULL,
    version INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE tasks IS '任务表';
COMMENT ON COLUMN tasks.task_type IS '任务类型: NORMAL普通, DEADLINE截止, SCHEDULED定时, LONG_TERM长期, MEMORY复习, AI_DELEGATED AI代理';
COMMENT ON COLUMN tasks.status IS '任务状态: TODO待开始, PLANNED已计划, DOING进行中, PAUSED暂停, AI_RUNNING AI处理中, WAITING等待用户, DONE完成, CANCELLED取消';
COMMENT ON COLUMN tasks.current_snapshot_id IS '当前最新快照ID，用于恢复任务上下文';

-- ============================================
-- 5. TASK_SESSIONS
-- ============================================
CREATE TABLE task_sessions (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ NOT NULL,
    paused_at TIMESTAMPTZ NULL,
    ended_at TIMESTAMPTZ NULL,
    duration_minutes INTEGER NOT NULL DEFAULT 0 CHECK (duration_minutes >= 0),
    session_goal TEXT NULL,
    result_summary TEXT NULL,
    snapshot_id BIGINT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE task_sessions IS '任务会话表，记录每次开始-暂停/结束的时间段';
COMMENT ON COLUMN task_sessions.snapshot_id IS '暂停时关联的快照ID';

-- ============================================
-- 6. TASK_SNAPSHOTS
-- ============================================
CREATE TABLE task_snapshots (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    snapshot_type VARCHAR(20) NOT NULL CHECK (snapshot_type IN ('PAUSE', 'SWITCH', 'AI', 'STAGE', 'COMPLETE')),
    raw_input TEXT NULL,
    ai_summary TEXT NULL,
    current_progress TEXT NULL,
    pause_reason TEXT NULL,
    next_action TEXT NULL,
    open_questions JSONB NOT NULL DEFAULT '[]',
    related_files JSONB NOT NULL DEFAULT '[]',
    related_notes JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE task_snapshots IS '任务快照表，保存任务中断现场';
COMMENT ON COLUMN task_snapshots.snapshot_type IS '快照类型: PAUSE暂停, SWITCH切换, AI交给AI, STAGE阶段完成, COMPLETE任务完成';
COMMENT ON COLUMN task_snapshots.open_questions IS '遗留问题JSON数组';
COMMENT ON COLUMN task_snapshots.related_files IS '关联文件JSON数组: [{file_id, file_name}]';
COMMENT ON COLUMN task_snapshots.related_notes IS '关联笔记JSON数组: [{note_id, title}]';

-- ============================================
-- 7. NOTES
-- ============================================
CREATE TABLE notes (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NULL REFERENCES tasks(id) ON DELETE SET NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    note_type VARCHAR(20) NOT NULL DEFAULT 'RAW' CHECK (note_type IN ('RAW', 'AI_SUMMARY', 'REVIEW')),
    source_type VARCHAR(20) NOT NULL DEFAULT 'TEXT' CHECK (source_type IN ('TEXT', 'VOICE', 'IMAGE', 'FILE', 'CODE', 'LINK')),
    source_snapshot_id BIGINT NULL REFERENCES task_snapshots(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE notes IS '笔记表，支持原始记录和AI整理笔记';
COMMENT ON COLUMN notes.task_id IS '关联任务ID，NULL表示暂存箱笔记';
COMMENT ON COLUMN notes.note_type IS '笔记类型: RAW原始记录, AI_SUMMARY AI整理, REVIEW复习卡片';
COMMENT ON COLUMN notes.source_type IS '来源类型: TEXT文字, VOICE语音, IMAGE图片, FILE文件, CODE代码, LINK链接';

-- ============================================
-- 8. REMINDER_RULES
-- ============================================
CREATE TABLE reminder_rules (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    rule_type VARCHAR(20) NOT NULL CHECK (rule_type IN ('START', 'DEADLINE', 'REPEAT', 'REVIEW', 'INACTIVE', 'PROGRESS', 'AI_DONE')),
    cron_expr VARCHAR(100) NULL,
    interval_minutes INTEGER NULL CHECK (interval_minutes > 0),
    before_deadline_minutes INTEGER NULL CHECK (before_deadline_minutes > 0),
    trigger_time TIMESTAMPTZ NULL,
    enabled BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE reminder_rules IS '提醒规则表，定义提醒策略';
COMMENT ON COLUMN reminder_rules.rule_type IS '规则类型: START定时开始, DEADLINE截止提醒, REPEAT周期重复, REVIEW复习提醒, INACTIVE长期未推进, PROGRESS进度提醒, AI_DONE AI完成';
COMMENT ON COLUMN reminder_rules.cron_expr IS 'Cron表达式，用于周期提醒';
COMMENT ON COLUMN reminder_rules.interval_minutes IS '间隔分钟数，用于周期提醒';
COMMENT ON COLUMN reminder_rules.before_deadline_minutes IS '截止前多少分钟提醒';
COMMENT ON COLUMN reminder_rules.trigger_time IS '单次提醒触发时间';

-- ============================================
-- 9. REMINDER_EVENTS
-- ============================================
CREATE TABLE reminder_events (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
    rule_id BIGINT NOT NULL REFERENCES reminder_rules(id) ON DELETE CASCADE,
    trigger_time TIMESTAMPTZ NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'SENT', 'SNOOZED', 'DONE', 'IGNORED', 'CANCELLED')),
    snooze_until TIMESTAMPTZ NULL,
    message TEXT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE reminder_events IS '提醒事件表，具体某次提醒';
COMMENT ON COLUMN reminder_events.status IS '状态: PENDING待发送, SENT已发送, SNOOZED稍后提醒, DONE已完成, IGNORED已忽略, CANCELLED已取消';
COMMENT ON COLUMN reminder_events.snooze_until IS '稍后提醒的新触发时间';

-- ============================================
-- 10. NOTIFICATIONS
-- ============================================
CREATE TABLE notifications (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NULL REFERENCES tasks(id) ON DELETE SET NULL,
    reminder_event_id BIGINT NULL REFERENCES reminder_events(id) ON DELETE SET NULL,
    notification_type VARCHAR(20) NOT NULL CHECK (notification_type IN ('REMINDER', 'AI_DONE', 'REVIEW', 'SYSTEM')),
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    read_status BOOLEAN NOT NULL DEFAULT FALSE,
    action_type VARCHAR(20) NULL CHECK (action_type IN ('START_TASK', 'VIEW_TASK', 'RESUME_TASK', 'VIEW_NOTE', 'CONFIRM_AI')),
    action_data JSONB NOT NULL DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE notifications IS '站内通知表';
COMMENT ON COLUMN notifications.notification_type IS '通知类型: REMINDER提醒, AI_DONE AI完成, REVIEW复习, SYSTEM系统';
COMMENT ON COLUMN notifications.action_type IS '可执行动作类型';
COMMENT ON COLUMN notifications.action_data IS '动作数据JSON: {task_id, snapshot_id, etc.}';

-- ============================================
-- 11. AI_JOBS
-- ============================================
CREATE TABLE ai_jobs (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NULL REFERENCES tasks(id) ON DELETE SET NULL,
    snapshot_id BIGINT NULL REFERENCES task_snapshots(id) ON DELETE SET NULL,
    note_id BIGINT NULL REFERENCES notes(id) ON DELETE SET NULL,
    job_type VARCHAR(20) NOT NULL CHECK (job_type IN ('PARSE', 'SUMMARY', 'RESUME', 'NOTE', 'REVIEW', 'REMINDER_PLAN', 'CHAT')),
    status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'RUNNING', 'SUCCESS', 'FAILED', 'CANCELLED')),
    input_payload JSONB NOT NULL DEFAULT '{}',
    output_payload JSONB NOT NULL DEFAULT '{}',
    error_message TEXT NULL,
    latency_ms INTEGER NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE ai_jobs IS 'AI任务表，记录AI处理任务';
COMMENT ON COLUMN ai_jobs.job_type IS 'AI任务类型: PARSE解析任务, SUMMARY快照总结, RESUME恢复建议, NOTE笔记整理, REVIEW复习卡片, REMINDER_PLAN提醒计划, CHAT对话';
COMMENT ON COLUMN ai_jobs.input_payload IS '输入数据JSON';
COMMENT ON COLUMN ai_jobs.output_payload IS '输出数据JSON';
COMMENT ON COLUMN ai_jobs.latency_ms IS '处理耗时毫秒';

-- ============================================
-- 12. FILES
-- ============================================
CREATE TABLE files (
    id BIGSERIAL PRIMARY KEY,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id BIGINT NULL REFERENCES tasks(id) ON DELETE SET NULL,
    note_id BIGINT NULL REFERENCES notes(id) ON DELETE SET NULL,
    file_name VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    storage_path VARCHAR(500) NOT NULL,
    size_bytes BIGINT NOT NULL CHECK (size_bytes >= 0),
    checksum VARCHAR(100) NULL,
    source VARCHAR(20) NOT NULL DEFAULT 'UPLOAD' CHECK (source IN ('UPLOAD', 'VOICE', 'SCREENSHOT', 'CODE')),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE files IS '文件表，存储任务附件';
COMMENT ON COLUMN files.file_type IS '文件类型MIME或分类';
COMMENT ON COLUMN files.source IS '来源: UPLOAD上传, VOICE录音, SCREENSHOT截图, CODE代码';
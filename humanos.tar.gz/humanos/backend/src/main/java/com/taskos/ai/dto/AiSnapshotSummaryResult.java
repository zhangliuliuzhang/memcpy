package com.taskos.ai.dto;

import lombok.Data;

import java.util.List;

/**
 * AI 快照总结结果
 */
@Data
public class AiSnapshotSummaryResult {

    private String summary;

    private String currentProgress;

    private String pauseReason;

    private String nextAction;

    private List<String> openQuestions;

    private String reminderSuggestion;
}
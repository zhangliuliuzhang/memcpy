package com.taskos.user.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.taskos.common.exception.ConflictException;
import com.taskos.common.exception.ResourceNotFoundException;
import com.taskos.common.response.ErrorCode;
import com.taskos.common.security.JwtService;
import com.taskos.common.security.UserPrincipal;
import com.taskos.user.dto.*;
import com.taskos.user.entity.LoginToken;
import com.taskos.user.entity.User;
import com.taskos.user.entity.UserDevice;
import com.taskos.user.mapper.LoginTokenMapper;
import com.taskos.user.mapper.UserDeviceMapper;
import com.taskos.user.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

/**
 * 用户服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class UserService extends ServiceImpl<UserMapper, User> {

    private final UserMapper userMapper;
    private final UserDeviceMapper userDeviceMapper;
    private final LoginTokenMapper loginTokenMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Value("${app.jwt.refresh-token-expiration}")
    private long refreshTokenExpiration;

    /**
     * 用户注册
     */
    @Transactional
    public UserResponse register(RegisterRequest request) {
        // 检查用户名是否存在
        if (existsByUsername(request.getUsername())) {
            throw ConflictException.usernameExists(request.getUsername());
        }

        // 检查邮箱是否存在
        if (existsByEmail(request.getEmail())) {
            throw ConflictException.emailExists(request.getEmail());
        }

        // 检查手机号
        if (request.getPhone() != null && !request.getPhone().isEmpty() && existsByPhone(request.getPhone())) {
            throw ConflictException.phoneExists(request.getPhone());
        }

        // 创建用户
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPhone(request.getPhone());
        user.setPasswordHash(passwordEncoder.encode(request.getPassword()));
        user.setStatus("ACTIVE");
        user.setTimezone(request.getTimezone());
        user.setVersion(0);

        userMapper.insert(user);

        return toUserResponse(user);
    }

    /**
     * 用户登录
     */
    @Transactional
    public LoginResponse login(LoginRequest request) {
        // 查找用户（支持用户名或邮箱登录）
        User user = findByLogin(request.getLogin());
        if (user == null) {
            throw new ResourceNotFoundException(ErrorCode.LOGIN_FAILED, "用户名或密码错误");
        }

        // 验证密码
        if (!passwordEncoder.matches(request.getPassword(), user.getPasswordHash())) {
            throw new ResourceNotFoundException(ErrorCode.LOGIN_FAILED, "用户名或密码错误");
        }

        // 检查账号状态
        if (!"ACTIVE".equals(user.getStatus())) {
            throw new ResourceNotFoundException(ErrorCode.ACCOUNT_DISABLED, "账号已被禁用");
        }

        // 注册或更新设备
        UserDevice device = registerOrUpdateDevice(user.getId(), request);

        // 生成令牌
        String accessToken = jwtService.generateAccessToken(user.getId(), user.getUsername(), device.getDeviceId());
        String refreshToken = jwtService.generateRefreshToken(user.getId(), device.getDeviceId());

        // 保存刷新令牌
        saveRefreshToken(user.getId(), device.getId(), refreshToken);

        // 构建响应
        LoginResponse response = new LoginResponse();
        response.setUser(toUserResponse(user));
        response.setAccessToken(accessToken);
        response.setRefreshToken(refreshToken);
        response.setDeviceId(device.getDeviceId());

        return response;
    }

    /**
     * 刷新令牌
     */
    @Transactional
    public TokenResponse refreshToken(String refreshToken) {
        // 验证刷新令牌
        if (!jwtService.validateToken(refreshToken) || !jwtService.isRefreshToken(refreshToken)) {
            throw new ResourceNotFoundException(ErrorCode.REFRESH_TOKEN_INVALID, "刷新令牌无效");
        }

        Long userId = jwtService.getUserId(refreshToken);
        String deviceId = jwtService.getDeviceId(refreshToken);

        // 查找令牌记录
        UserDevice device = userDeviceMapper.selectOne(
                new LambdaQueryWrapper<UserDevice>()
                        .eq(UserDevice::getUserId, userId)
                        .eq(UserDevice::getDeviceId, deviceId)
        );

        if (device == null) {
            throw new ResourceNotFoundException(ErrorCode.DEVICE_NOT_TRUSTED, "设备不受信任");
        }

        // 验证数据库中的刷新令牌
        LoginToken storedToken = loginTokenMapper.selectOne(
                new LambdaQueryWrapper<LoginToken>()
                        .eq(LoginToken::getUserId, userId)
                        .eq(LoginToken::getDeviceId, device.getId())
                        .eq(LoginToken::getRefreshToken, refreshToken)
                        .eq(LoginToken::getRevoked, false)
        );

        if (storedToken == null) {
            throw new ResourceNotFoundException(ErrorCode.REFRESH_TOKEN_INVALID, "刷新令牌已失效");
        }

        // 获取用户
        User user = userMapper.selectById(userId);
        if (user == null || !"ACTIVE".equals(user.getStatus())) {
            throw new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND, "用户不存在或已禁用");
        }

        // 撤销旧令牌
        storedToken.setRevoked(true);
        loginTokenMapper.updateById(storedToken);

        // 生成新令牌
        String newAccessToken = jwtService.generateAccessToken(user.getId(), user.getUsername(), deviceId);
        String newRefreshToken = jwtService.generateRefreshToken(user.getId(), deviceId);

        // 保存新刷新令牌
        saveRefreshToken(user.getId(), device.getId(), newRefreshToken);

        TokenResponse response = new TokenResponse();
        response.setAccessToken(newAccessToken);
        response.setRefreshToken(newRefreshToken);
        return response;
    }

    /**
     * 用户登出
     */
    @Transactional
    public void logout(Long userId, String deviceId) {
        UserDevice device = userDeviceMapper.selectOne(
                new LambdaQueryWrapper<UserDevice>()
                        .eq(UserDevice::getUserId, userId)
                        .eq(UserDevice::getDeviceId, deviceId)
        );

        if (device != null) {
            // 撤销该设备的所有刷新令牌
            loginTokenMapper.selectList(
                    new LambdaQueryWrapper<LoginToken>()
                            .eq(LoginToken::getUserId, userId)
                            .eq(LoginToken::getDeviceId, device.getId())
                            .eq(LoginToken::getRevoked, false)
            ).forEach(token -> {
                token.setRevoked(true);
                loginTokenMapper.updateById(token);
            });
        }
    }

    /**
     * 根据 ID 和设备加载用户详情（用于 Spring Security）
     */
    public UserDetails loadUserByIdAndDevice(Long userId, Long deviceId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            return null;
        }

        UserDevice device = userDeviceMapper.selectById(deviceId);
        if (device == null || !device.getEnabled()) {
            return null;
        }

        return UserPrincipal.create(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getPasswordHash(),
                user.getStatus(),
                user.getTimezone(),
                device.getId()
        );
    }

    /**
     * 获取用户信息
     */
    public UserResponse getUserInfo(Long userId) {
        User user = userMapper.selectById(userId);
        if (user == null) {
            throw ResourceNotFoundException.user(userId);
        }
        return toUserResponse(user);
    }

    // ==================== 私有方法 ====================

    private boolean existsByUsername(String username) {
        return userMapper.selectCount(
                new LambdaQueryWrapper<User>().eq(User::getUsername, username)
        ) > 0;
    }

    private boolean existsByEmail(String email) {
        return userMapper.selectCount(
                new LambdaQueryWrapper<User>().eq(User::getEmail, email)
        ) > 0;
    }

    private boolean existsByPhone(String phone) {
        return userMapper.selectCount(
                new LambdaQueryWrapper<User>().eq(User::getPhone, phone)
        ) > 0;
    }

    private User findByLogin(String login) {
        return userMapper.selectOne(
                new LambdaQueryWrapper<User>()
                        .eq(User::getUsername, login)
                        .or()
                        .eq(User::getEmail, login)
        );
    }

    private UserDevice registerOrUpdateDevice(Long userId, LoginRequest request) {
        UserDevice device = userDeviceMapper.selectOne(
                new LambdaQueryWrapper<UserDevice>()
                        .eq(UserDevice::getUserId, userId)
                        .eq(UserDevice::getDeviceId, request.getDeviceId())
        );

        if (device == null) {
            device = new UserDevice();
            device.setUserId(userId);
            device.setDeviceId(request.getDeviceId());
            device.setDeviceType(request.getDeviceType());
            device.setDeviceName(request.getDeviceName());
            device.setEnabled(true);
            userDeviceMapper.insert(device);
        } else {
            device.setDeviceName(request.getDeviceName());
            device.setLastActiveAt(Instant.now());
            userDeviceMapper.updateById(device);
        }

        return device;
    }

    private void saveRefreshToken(Long userId, Long deviceId, String refreshToken) {
        LoginToken token = new LoginToken();
        token.setUserId(userId);
        token.setDeviceId(deviceId);
        token.setRefreshToken(refreshToken);
        token.setExpiresAt(Instant.now().plusMillis(refreshTokenExpiration));
        token.setRevoked(false);
        loginTokenMapper.insert(token);
    }

    private UserResponse toUserResponse(User user) {
        UserResponse response = new UserResponse();
        response.setId(user.getId());
        response.setUsername(user.getUsername());
        response.setEmail(user.getEmail());
        response.setPhone(user.getPhone());
        response.setAvatarUrl(user.getAvatarUrl());
        response.setStatus(user.getStatus());
        response.setTimezone(user.getTimezone());
        response.setSettings(user.getSettings());
        response.setCreatedAt(user.getCreatedAt() != null ? user.getCreatedAt().toString() : null);
        return response;
    }
}
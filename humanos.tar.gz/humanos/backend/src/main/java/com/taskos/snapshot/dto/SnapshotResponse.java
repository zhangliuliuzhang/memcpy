package com.taskos.snapshot.dto;

import lombok.Data;

import java.time.Instant;
import java.util.List;

/**
 * 快照响应
 */
@Data
public class SnapshotResponse {

    private Long id;
    private Long taskId;
    private String snapshotType;
    private String rawInput;
    private String aiSummary;
    private String currentProgress;
    private String pauseReason;
    private String nextAction;
    private List<String> openQuestions;
    private List<RelatedFileDto> relatedFiles;
    private List<RelatedNoteDto> relatedNotes;
    private Instant createdAt;

    @Data
    public static class RelatedFileDto {
        private Long fileId;
        private String fileName;
    }

    @Data
    public static class RelatedNoteDto {
        private Long noteId;
        private String title;
    }
}
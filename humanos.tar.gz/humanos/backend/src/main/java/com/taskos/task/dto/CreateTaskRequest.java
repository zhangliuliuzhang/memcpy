package com.taskos.task.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.Instant;

/**
 * 创建任务请求
 */
@Data
public class CreateTaskRequest {

    @NotBlank(message = "任务标题不能为空")
    @Size(max = 255, message = "任务标题最多255个字符")
    private String title;

    @Size(max = 5000, message = "任务描述最多5000个字符")
    private String description;

    private String taskType = "NORMAL";

    private Instant startTime;

    private Instant deadline;

    private Integer estimatedMinutes;

    private Integer priority = 2;
}
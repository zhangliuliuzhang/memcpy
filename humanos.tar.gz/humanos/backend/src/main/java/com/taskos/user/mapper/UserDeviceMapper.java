package com.taskos.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.taskos.user.entity.UserDevice;
import org.apache.ibatis.annotations.Mapper;

/**
 * 用户设备 Mapper
 */
@Mapper
public interface UserDeviceMapper extends BaseMapper<UserDevice> {
}
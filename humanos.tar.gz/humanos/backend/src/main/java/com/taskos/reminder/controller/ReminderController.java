package com.taskos.reminder.controller;

import com.taskos.common.response.ApiResponse;
import com.taskos.common.security.UserPrincipal;
import com.taskos.reminder.dto.*;
import com.taskos.reminder.service.ReminderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 提醒控制器
 */
@Tag(name = "提醒", description = "提醒规则与事件管理")
@RestController
@RequestMapping("/reminders")
@RequiredArgsConstructor
public class ReminderController {

    private final ReminderService reminderService;

    @Operation(summary = "创建提醒规则")
    @PostMapping("/rules")
    public ApiResponse<ReminderRuleResponse> createRule(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody CreateReminderRuleRequest request) {
        ReminderRuleResponse rule = reminderService.createRule(principal.getId(), request);
        return ApiResponse.success(rule, "提醒规则创建成功");
    }

    @Operation(summary = "获取任务的提醒规则")
    @GetMapping("/tasks/{taskId}/rules")
    public ApiResponse<List<ReminderRuleResponse>> getTaskRules(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId) {
        List<ReminderRuleResponse> rules = reminderService.getTaskRules(principal.getId(), taskId);
        return ApiResponse.success(rules);
    }

    @Operation(summary = "删除提醒规则")
    @DeleteMapping("/rules/{ruleId}")
    public ApiResponse<Void> deleteRule(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long ruleId) {
        reminderService.deleteRule(principal.getId(), ruleId);
        return ApiResponse.success(null, "提醒规则已删除");
    }

    @Operation(summary = "获取今日提醒")
    @GetMapping("/today")
    public ApiResponse<List<ReminderEventResponse>> getTodayReminders(
            @AuthenticationPrincipal UserPrincipal principal) {
        List<ReminderEventResponse> reminders = reminderService.getTodayReminders(principal.getId());
        return ApiResponse.success(reminders);
    }

    @Operation(summary = "获取即将到来的提醒")
    @GetMapping("/upcoming")
    public ApiResponse<List<ReminderEventResponse>> getUpcomingReminders(
            @AuthenticationPrincipal UserPrincipal principal,
            @RequestParam(defaultValue = "24") int hours) {
        List<ReminderEventResponse> reminders = reminderService.getUpcomingReminders(principal.getId(), hours);
        return ApiResponse.success(reminders);
    }

    @Operation(summary = "稍后提醒")
    @PostMapping("/events/{eventId}/snooze")
    public ApiResponse<ReminderEventResponse> snoozeEvent(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long eventId,
            @RequestParam(defaultValue = "30") int minutes) {
        ReminderEventResponse event = reminderService.snoozeEvent(principal.getId(), eventId, minutes);
        return ApiResponse.success(event, "已设置稍后提醒");
    }

    @Operation(summary = "标记完成")
    @PostMapping("/events/{eventId}/done")
    public ApiResponse<Void> markEventDone(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long eventId) {
        reminderService.markEventDone(principal.getId(), eventId);
        return ApiResponse.success(null, "已标记完成");
    }

    @Operation(summary = "忽略提醒")
    @PostMapping("/events/{eventId}/ignore")
    public ApiResponse<Void> ignoreEvent(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long eventId) {
        reminderService.ignoreEvent(principal.getId(), eventId);
        return ApiResponse.success(null, "已忽略提醒");
    }
}
package com.taskos.reminder.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.Instant;

/**
 * 创建提醒规则请求
 */
@Data
public class CreateReminderRuleRequest {

    @NotNull(message = "任务ID不能为空")
    private Long taskId;

    @NotNull(message = "规则类型不能为空")
    private String ruleType; // START, DEADLINE, REPEAT, REVIEW, INACTIVE, PROGRESS

    private String cronExpr;

    private Integer intervalMinutes;

    private Integer beforeDeadlineMinutes;

    private Instant triggerTime;

    private Boolean enabled = true;
}
package com.taskos.common.exception;

import com.taskos.common.response.ErrorCode;

/**
 * 资源不存在异常
 */
public class ResourceNotFoundException extends BusinessException {

    public ResourceNotFoundException(String message) {
        super(ErrorCode.RESOURCE_NOT_FOUND, message);
    }

    public ResourceNotFoundException(ErrorCode errorCode, String message) {
        super(errorCode, message);
    }

    public static ResourceNotFoundException task(Long taskId) {
        return new ResourceNotFoundException(ErrorCode.TASK_NOT_FOUND, "任务不存在: " + taskId);
    }

    public static ResourceNotFoundException user(Long userId) {
        return new ResourceNotFoundException(ErrorCode.USER_NOT_FOUND, "用户不存在: " + userId);
    }

    public static ResourceNotFoundException snapshot(Long snapshotId) {
        return new ResourceNotFoundException(ErrorCode.SNAPSHOT_NOT_FOUND, "快照不存在: " + snapshotId);
    }

    public static ResourceNotFoundException reminderRule(Long ruleId) {
        return new ResourceNotFoundException(ErrorCode.REMINDER_RULE_NOT_FOUND, "提醒规则不存在: " + ruleId);
    }

    public static ResourceNotFoundException reminderEvent(Long eventId) {
        return new ResourceNotFoundException(ErrorCode.REMINDER_EVENT_NOT_FOUND, "提醒事件不存在: " + eventId);
    }

    public static ResourceNotFoundException file(Long fileId) {
        return new ResourceNotFoundException(ErrorCode.FILE_NOT_FOUND, "文件不存在: " + fileId);
    }

    public static ResourceNotFoundException aiJob(Long jobId) {
        return new ResourceNotFoundException(ErrorCode.AI_JOB_NOT_FOUND, "AI任务不存在: " + jobId);
    }
}
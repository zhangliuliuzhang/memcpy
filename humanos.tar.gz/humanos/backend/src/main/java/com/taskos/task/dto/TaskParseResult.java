package com.taskos.task.dto;

import lombok.Data;

import java.time.Instant;
import java.util.List;

/**
 * AI 解析任务结果
 */
@Data
public class TaskParseResult {

    private String title;
    private String taskType;
    private Instant startTime;
    private Instant deadline;
    private Integer estimatedMinutes;
    private Integer priority;
    private List<ReminderRuleSuggestion> reminderRules;
    private Boolean needUserConfirm;

    @Data
    public static class ReminderRuleSuggestion {
        private String type;
        private String description;
        private Instant triggerTime;
        private Integer intervalMinutes;
        private Integer beforeDeadlineMinutes;
    }
}
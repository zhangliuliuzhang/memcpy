package com.taskos.task.dto;

import lombok.Data;

/**
 * 取消任务请求
 */
@Data
public class CancelTaskRequest {
    private String reason;
}
package com.taskos.snapshot.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * 任务快照实体
 */
@Data
@TableName(value = "task_snapshots", autoResultMap = true)
public class TaskSnapshot {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long taskId;

    private String snapshotType;

    private String rawInput;

    private String aiSummary;

    private String currentProgress;

    private String pauseReason;

    private String nextAction;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<String> openQuestions;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<RelatedFile> relatedFiles;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private List<RelatedNote> relatedNotes;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;

    @Data
    public static class RelatedFile {
        private Long fileId;
        private String fileName;
    }

    @Data
    public static class RelatedNote {
        private Long noteId;
        private String title;
    }
}
package com.taskos.task.dto;

import lombok.Data;

/**
 * 暂停任务请求
 */
@Data
public class PauseTaskRequest {
    private String rawInput;
    private String pauseReason;
}
package com.taskos.task.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.Instant;

/**
 * 任务实体
 */
@Data
@TableName(value = "tasks", autoResultMap = true)
public class Task {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private String title;

    private String description;

    private String taskType;

    private String status;

    private Integer priority;

    private Instant startTime;

    private Instant deadline;

    private Integer estimatedMinutes;

    private Integer actualMinutes;

    private Integer progress;

    private Long currentSnapshotId;

    private Instant lastActiveTime;

    @TableLogic(value = "NULL", delval = "NOW()")
    private Instant deletedAt;

    @Version
    private Integer version;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Instant updatedAt;
}
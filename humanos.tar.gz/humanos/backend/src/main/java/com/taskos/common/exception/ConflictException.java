package com.taskos.common.exception;

import com.taskos.common.response.ErrorCode;

/**
 * 资源冲突异常
 */
public class ConflictException extends BusinessException {

    public ConflictException(String message) {
        super(ErrorCode.BAD_REQUEST, message);
    }

    public ConflictException(ErrorCode errorCode, String message) {
        super(errorCode, message);
    }

    public static ConflictException usernameExists(String username) {
        return new ConflictException(ErrorCode.USERNAME_EXISTS, "用户名已存在: " + username);
    }

    public static ConflictException emailExists(String email) {
        return new ConflictException(ErrorCode.EMAIL_EXISTS, "邮箱已被注册: " + email);
    }

    public static ConflictException phoneExists(String phone) {
        return new ConflictException(ErrorCode.PHONE_EXISTS, "手机号已被注册: " + phone);
    }

    public static ConflictException taskStatusInvalid(Long taskId, String currentStatus) {
        return new ConflictException(ErrorCode.TASK_STATUS_INVALID,
                "任务 " + taskId + " 当前状态为 " + currentStatus + "，无法执行此操作");
    }
}
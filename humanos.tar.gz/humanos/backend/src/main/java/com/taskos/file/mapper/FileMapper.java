package com.taskos.file.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.taskos.file.entity.FileEntity;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface FileMapper extends BaseMapper<FileEntity> {
}
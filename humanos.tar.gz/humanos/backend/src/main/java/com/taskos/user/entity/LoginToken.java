package com.taskos.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.Instant;

/**
 * 登录令牌实体
 */
@Data
@TableName("login_tokens")
public class LoginToken {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long deviceId;

    private String refreshToken;

    private Instant expiresAt;

    private Boolean revoked;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;
}
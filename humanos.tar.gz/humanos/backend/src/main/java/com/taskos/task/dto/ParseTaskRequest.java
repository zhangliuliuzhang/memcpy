package com.taskos.task.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * AI 解析任务请求
 */
@Data
public class ParseTaskRequest {

    @NotBlank(message = "任务描述不能为空")
    private String text;
}
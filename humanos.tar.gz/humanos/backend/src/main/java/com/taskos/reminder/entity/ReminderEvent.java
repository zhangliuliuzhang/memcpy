package com.taskos.reminder.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.Instant;

/**
 * 提醒事件实体
 */
@Data
@TableName("reminder_events")
public class ReminderEvent {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long taskId;

    private Long ruleId;

    private Instant triggerTime;

    private String status;

    private Instant snoozeUntil;

    private String message;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Instant updatedAt;
}
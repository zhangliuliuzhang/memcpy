package com.taskos.common.security;

import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * 用户认证主体
 */
@Getter
public class UserPrincipal implements UserDetails {

    private final Long id;
    private final String username;
    private final String email;
    private final String passwordHash;
    private final String status;
    private final String timezone;
    private final Long deviceId;
    private final Collection<? extends GrantedAuthority> authorities;

    public UserPrincipal(Long id, String username, String email, String passwordHash,
                          String status, String timezone, Long deviceId,
                          Collection<? extends GrantedAuthority> authorities) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
        this.status = status;
        this.timezone = timezone;
        this.deviceId = deviceId;
        this.authorities = authorities;
    }

    /**
     * 创建用户主体（包含设备信息）
     */
    public static UserPrincipal create(Long id, String username, String email, String passwordHash,
                                        String status, String timezone, Long deviceId,
                                        List<String> roles) {
        Collection<GrantedAuthority> authorities = roles == null || roles.isEmpty()
                ? Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"))
                : roles.stream()
                    .map(role -> new SimpleGrantedAuthority("ROLE_" + role.toUpperCase()))
                    .toList();

        return new UserPrincipal(id, username, email, passwordHash, status, timezone, deviceId, authorities);
    }

    /**
     * 创建用户主体（默认角色）
     */
    public static UserPrincipal create(Long id, String username, String email, String passwordHash,
                                        String status, String timezone, Long deviceId) {
        return create(id, username, email, passwordHash, status, timezone, deviceId, null);
    }

    @Override
    public String getPassword() {
        return passwordHash;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return !"SUSPENDED".equals(status);
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return "ACTIVE".equals(status);
    }
}
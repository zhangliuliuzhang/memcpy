package com.taskos.reminder.dto;

import lombok.Data;

import java.time.Instant;

/**
 * 提醒规则响应
 */
@Data
public class ReminderRuleResponse {

    private Long id;
    private Long taskId;
    private String ruleType;
    private String cronExpr;
    private Integer intervalMinutes;
    private Integer beforeDeadlineMinutes;
    private Instant triggerTime;
    private Boolean enabled;
    private Instant createdAt;
}
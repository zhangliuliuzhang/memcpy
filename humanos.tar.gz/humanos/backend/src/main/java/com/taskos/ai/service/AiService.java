package com.taskos.ai.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.taskos.ai.dto.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * AI 服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AiService {

    @Value("${app.ai.base-url}")
    private String baseUrl;

    @Value("${app.ai.api-key}")
    private String apiKey;

    @Value("${app.ai.model}")
    private String model;

    @Value("${app.ai.timeout}")
    private int timeout;

    @Value("${app.ai.max-tokens}")
    private int maxTokens;

    private final ObjectMapper objectMapper;

    private WebClient getWebClient() {
        return WebClient.builder()
                .baseUrl(baseUrl)
                .defaultHeader("Authorization", "Bearer " + apiKey)
                .defaultHeader("Content-Type", "application/json")
                .build();
    }

    /**
     * 解析自然语言任务
     */
    public AiTaskParseResult parseTask(String text, String timezone) {
        String prompt = buildTaskParsePrompt(text, timezone);

        try {
            String response = callAi(prompt);
            return parseTaskResult(response);
        } catch (Exception e) {
            log.error("AI task parse failed: {}", e.getMessage());
            // 返回默认值
            AiTaskParseResult result = new AiTaskParseResult();
            result.setTitle(text.length() > 50 ? text.substring(0, 50) : text);
            result.setTaskType("NORMAL");
            result.setPriority(2);
            result.setNeedUserConfirm(true);
            return result;
        }
    }

    /**
     * 总结快照
     */
    public AiSnapshotSummaryResult summarizeSnapshot(AiSnapshotSummaryRequest request) {
        String prompt = buildSnapshotSummaryPrompt(request);

        try {
            String response = callAi(prompt);
            return parseSummaryResult(response);
        } catch (Exception e) {
            log.error("AI snapshot summary failed: {}", e.getMessage());
            // 返回默认值
            AiSnapshotSummaryResult result = new AiSnapshotSummaryResult();
            result.setSummary(request.getRawInput());
            result.setCurrentProgress("");
            result.setPauseReason("");
            result.setNextAction("");
            result.setOpenQuestions(Collections.emptyList());
            return result;
        }
    }

    /**
     * 生成恢复建议
     */
    public String generateResumeSuggestion(String taskTitle, String lastProgress,
                                             List<String> openQuestions, String nextAction) {
        String prompt = String.format("""
            你是一个任务助手。用户要继续一个暂停的任务。

            任务名称: %s
            上次进度: %s
            遗留问题: %s
            建议下一步: %s

            请用一句话鼓励用户继续，并提醒最重要的下一步。
            回复格式：
            {"suggestion": "你的建议"}
            """,
                taskTitle,
                lastProgress != null ? lastProgress : "无记录",
                openQuestions != null ? String.join("、", openQuestions) : "无",
                nextAction != null ? nextAction : "继续推进"
        );

        try {
            String response = callAi(prompt);
            Map<String, String> map = objectMapper.readValue(response,
                    objectMapper.getTypeFactory().constructMapType(Map.class, String.class, String.class));
            return map.getOrDefault("suggestion", nextAction);
        } catch (Exception e) {
            log.error("AI resume suggestion failed: {}", e.getMessage());
            return nextAction != null ? nextAction : "继续推进任务";
        }
    }

    private String callAi(String prompt) {
        WebClient client = getWebClient();

        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);
        requestBody.put("messages", List.of(
                Map.of("role", "system", "content", getSystemPrompt()),
                Map.of("role", "user", "content", prompt)
        ));
        requestBody.put("max_tokens", maxTokens);
        requestBody.put("temperature", 0.3);

        Mono<Map> response = client.post()
                .uri("/v1/chat/completions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(Map.class);

        Map<String, Object> result = response.block(Duration.ofMillis(timeout));

        if (result != null && result.containsKey("choices")) {
            List<Map<String, Object>> choices = (List<Map<String, Object>>) result.get("choices");
            if (!choices.isEmpty()) {
                Map<String, Object> message = (Map<String, Object>) choices.get(0).get("message");
                return (String) message.get("content");
            }
        }

        throw new RuntimeException("AI response is empty");
    }

    private String getSystemPrompt() {
        return """
            你是一个任务管理助手。你的职责是：
            1. 从用户的自然语言中提取任务信息
            2. 总结任务的当前状态和下一步
            3. 给出简洁、可执行的建议

            回复必须使用 JSON 格式，不要添加任何解释。
            """;
    }

    private String buildTaskParsePrompt(String text, String timezone) {
        ZoneId zone = timezone != null ? ZoneId.of(timezone) : ZoneId.of("Asia/Shanghai");
        String now = ZonedDateTime.now(zone).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

        return String.format("""
            当前时间: %s (时区: %s)

            用户输入: "%s"

            请解析用户的任务描述，提取以下信息：
            - title: 任务标题（简洁明确）
            - taskType: 任务类型，可选值: NORMAL(普通), DEADLINE(有截止日期), SCHEDULED(定时开始), LONG_TERM(长期任务), MEMORY(复习任务)
            - startTime: 开始时间（ISO格式，如 2026-06-25T09:00:00）
            - deadline: 截止时间（ISO格式）
            - estimatedMinutes: 预估耗时（分钟）
            - priority: 优先级（1-5，1最高）
            - reminderRules: 提醒规则建议数组

            回复JSON格式：
            {
              "title": "任务标题",
              "taskType": "NORMAL",
              "startTime": null,
              "deadline": null,
              "estimatedMinutes": null,
              "priority": 2,
              "reminderRules": [],
              "needUserConfirm": false
            }
            """,
                now, timezone != null ? timezone : "Asia/Shanghai", text
        );
    }

    private String buildSnapshotSummaryPrompt(AiSnapshotSummaryRequest request) {
        return String.format("""
            任务名称: %s

            用户输入的暂停记录:
            "%s"

            之前的进度:
            %s

            最近的笔记:
            %s

            请总结并提取：
            - summary: 对暂停记录的总结
            - currentProgress: 当前进度描述
            - pauseReason: 暂停原因
            - nextAction: 建议的下一步
            - openQuestions: 遗留问题列表
            - reminderSuggestion: 提醒建议（如"建议明天上午继续"）

            回复JSON格式：
            {
              "summary": "总结",
              "currentProgress": "进度",
              "pauseReason": "原因",
              "nextAction": "下一步",
              "openQuestions": [],
              "reminderSuggestion": "提醒建议"
            }
            """,
                request.getTaskTitle(),
                request.getRawInput(),
                request.getPreviousProgress() != null ? request.getPreviousProgress() : "无",
                request.getRecentNotes() != null ? String.join("\n", request.getRecentNotes()) : "无"
        );
    }

    private AiTaskParseResult parseTaskResult(String json) {
        try {
            return objectMapper.readValue(json, AiTaskParseResult.class);
        } catch (Exception e) {
            log.error("Failed to parse AI result: {}", e.getMessage());
            AiTaskParseResult result = new AiTaskParseResult();
            result.setNeedUserConfirm(true);
            return result;
        }
    }

    private AiSnapshotSummaryResult parseSummaryResult(String json) {
        try {
            return objectMapper.readValue(json, AiSnapshotSummaryResult.class);
        } catch (Exception e) {
            log.error("Failed to parse AI summary: {}", e.getMessage());
            AiSnapshotSummaryResult result = new AiSnapshotSummaryResult();
            result.setOpenQuestions(Collections.emptyList());
            return result;
        }
    }
}
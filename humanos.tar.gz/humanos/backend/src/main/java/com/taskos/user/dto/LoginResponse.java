package com.taskos.user.dto;

import lombok.Data;

/**
 * 登录响应
 */
@Data
public class LoginResponse {

    private UserResponse user;
    private String accessToken;
    private String refreshToken;
    private String deviceId;
}
package com.taskos.user.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.Instant;

/**
 * 用户设备实体
 */
@Data
@TableName("user_devices")
public class UserDevice {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private String deviceType;

    private String deviceId;

    private String deviceName;

    private String pushToken;

    private Boolean enabled;

    private Instant lastActiveAt;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Instant updatedAt;
}
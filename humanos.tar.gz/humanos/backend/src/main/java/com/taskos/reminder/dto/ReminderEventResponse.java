package com.taskos.reminder.dto;

import lombok.Data;

import java.time.Instant;

/**
 * 提醒事件响应
 */
@Data
public class ReminderEventResponse {

    private Long id;
    private Long taskId;
    private Long ruleId;
    private Instant triggerTime;
    private String status;
    private Instant snoozeUntil;
    private String message;
    private String taskTitle;
    private Instant createdAt;
}
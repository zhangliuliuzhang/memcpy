package com.taskos.user.dto;

import lombok.Data;

/**
 * 令牌响应
 */
@Data
public class TokenResponse {

    private String accessToken;
    private String refreshToken;
}
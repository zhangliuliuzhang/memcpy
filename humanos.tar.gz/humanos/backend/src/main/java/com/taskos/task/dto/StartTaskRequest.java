package com.taskos.task.dto;

import lombok.Data;

/**
 * 开始任务请求
 */
@Data
public class StartTaskRequest {
    private String sessionGoal;
}
package com.taskos.user.entity;

import lombok.Data;

import java.util.Map;

/**
 * 用户设置
 */
@Data
public class UserSettings {
    private String theme;
    private String language;
    private Boolean notificationEnabled;
    private Map<String, Object> custom;
}
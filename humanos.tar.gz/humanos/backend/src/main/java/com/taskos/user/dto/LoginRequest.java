package com.taskos.user.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * 登录请求
 */
@Data
public class LoginRequest {

    @NotBlank(message = "登录账号不能为空")
    private String login; // username or email

    @NotBlank(message = "密码不能为空")
    private String password;

    @NotBlank(message = "设备ID不能为空")
    private String deviceId;

    private String deviceType = "WEB";
    private String deviceName;
}
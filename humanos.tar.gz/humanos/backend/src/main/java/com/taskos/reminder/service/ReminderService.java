package com.taskos.reminder.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.taskos.common.exception.BusinessException;
import com.taskos.common.exception.ResourceNotFoundException;
import com.taskos.common.response.ApiResponse;
import com.taskos.notification.entity.Notification;
import com.taskos.notification.mapper.NotificationMapper;
import com.taskos.reminder.dto.*;
import com.taskos.reminder.entity.ReminderEvent;
import com.taskos.reminder.entity.ReminderRule;
import com.taskos.reminder.mapper.ReminderEventMapper;
import com.taskos.reminder.mapper.ReminderRuleMapper;
import com.taskos.task.entity.Task;
import com.taskos.task.mapper.TaskMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * 提醒服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReminderService {

    private final ReminderRuleMapper ruleMapper;
    private final ReminderEventMapper eventMapper;
    private final TaskMapper taskMapper;
    private final NotificationMapper notificationMapper;

    /**
     * 创建提醒规则
     */
    @Transactional
    public ReminderRuleResponse createRule(Long userId, CreateReminderRuleRequest request) {
        Task task = taskMapper.selectById(request.getTaskId());
        if (task == null || !task.getUserId().equals(userId)) {
            throw ResourceNotFoundException.task(request.getTaskId());
        }

        ReminderRule rule = new ReminderRule();
        rule.setUserId(userId);
        rule.setTaskId(request.getTaskId());
        rule.setRuleType(request.getRuleType());
        rule.setCronExpr(request.getCronExpr());
        rule.setIntervalMinutes(request.getIntervalMinutes());
        rule.setBeforeDeadlineMinutes(request.getBeforeDeadlineMinutes());
        rule.setTriggerTime(request.getTriggerTime());
        rule.setEnabled(request.getEnabled() != null ? request.getEnabled() : true);

        ruleMapper.insert(rule);

        // 立即生成对应事件
        generateEventsForRule(rule, task);

        return toRuleResponse(rule);
    }

    /**
     * 获取任务的提醒规则
     */
    public List<ReminderRuleResponse> getTaskRules(Long userId, Long taskId) {
        Task task = taskMapper.selectById(taskId);
        if (task == null || !task.getUserId().equals(userId)) {
            throw ResourceNotFoundException.task(taskId);
        }

        return ruleMapper.selectList(
                new LambdaQueryWrapper<ReminderRule>()
                        .eq(ReminderRule::getTaskId, taskId)
                        .orderByDesc(ReminderRule::getCreatedAt)
        ).stream().map(this::toRuleResponse).toList();
    }

    /**
     * 获取今日提醒事件
     */
    public List<ReminderEventResponse> getTodayReminders(Long userId) {
        Instant now = Instant.now();
        Instant endOfDay = now.plus(24, ChronoUnit.HOURS);

        List<ReminderEvent> events = eventMapper.selectList(
                new LambdaQueryWrapper<ReminderEvent>()
                        .eq(ReminderEvent::getUserId, userId)
                        .between(ReminderEvent::getTriggerTime, now, endOfDay)
                        .orderByAsc(ReminderEvent::getTriggerTime)
        );

        return events.stream().map(e -> toEventResponse(e, false)).toList();
    }

    /**
     * 获取即将到来的提醒
     */
    public List<ReminderEventResponse> getUpcomingReminders(Long userId, int hours) {
        Instant now = Instant.now();
        Instant endTime = now.plus(hours, ChronoUnit.HOURS);

        List<ReminderEvent> events = eventMapper.selectList(
                new LambdaQueryWrapper<ReminderEvent>()
                        .eq(ReminderEvent::getUserId, userId)
                        .ge(ReminderEvent::getTriggerTime, now)
                        .le(ReminderEvent::getTriggerTime, endTime)
                        .in(ReminderEvent::getStatus, "PENDING", "SENT", "SNOOZED")
                        .orderByAsc(ReminderEvent::getTriggerTime)
        );

        return events.stream().map(e -> toEventResponse(e, true)).toList();
    }

    /**
     * 稍后提醒
     */
    @Transactional
    public ReminderEventResponse snoozeEvent(Long userId, Long eventId, int snoozeMinutes) {
        ReminderEvent event = eventMapper.selectById(eventId);
        if (event == null || !event.getUserId().equals(userId)) {
            throw ResourceNotFoundException.reminderEvent(eventId);
        }

        if (!"PENDING".equals(event.getStatus()) && !"SENT".equals(event.getStatus())) {
            throw new BusinessException("当前状态无法稍后提醒");
        }

        event.setStatus("SNOOZED");
        event.setSnoozeUntil(Instant.now().plus(snoozeMinutes, ChronoUnit.MINUTES));
        eventMapper.updateById(event);

        // 创建一个新的稍后提醒事件
        ReminderEvent newEvent = new ReminderEvent();
        newEvent.setUserId(userId);
        newEvent.setTaskId(event.getTaskId());
        newEvent.setRuleId(event.getRuleId());
        newEvent.setTriggerTime(event.getSnoozeUntil());
        newEvent.setStatus("PENDING");
        newEvent.setMessage(event.getMessage());
        eventMapper.insert(newEvent);

        return toEventResponse(newEvent, true);
    }

    /**
     * 标记完成
     */
    @Transactional
    public void markEventDone(Long userId, Long eventId) {
        ReminderEvent event = eventMapper.selectById(eventId);
        if (event == null || !event.getUserId().equals(userId)) {
            throw ResourceNotFoundException.reminderEvent(eventId);
        }
        event.setStatus("DONE");
        eventMapper.updateById(event);
    }

    /**
     * 忽略提醒
     */
    @Transactional
    public void ignoreEvent(Long userId, Long eventId) {
        ReminderEvent event = eventMapper.selectById(eventId);
        if (event == null || !event.getUserId().equals(userId)) {
            throw ResourceNotFoundException.reminderEvent(eventId);
        }
        event.setStatus("IGNORED");
        eventMapper.updateById(event);
    }

    /**
     * 删除提醒规则
     */
    @Transactional
    public void deleteRule(Long userId, Long ruleId) {
        ReminderRule rule = ruleMapper.selectById(ruleId);
        if (rule == null || !rule.getUserId().equals(userId)) {
            throw ResourceNotFoundException.reminderRule(ruleId);
        }

        rule.setEnabled(false);
        ruleMapper.updateById(rule);

        // 取消所有未触发的事件
        eventMapper.selectList(
                new LambdaQueryWrapper<ReminderEvent>()
                        .eq(ReminderEvent::getRuleId, ruleId)
                        .eq(ReminderEvent::getStatus, "PENDING")
        ).forEach(event -> {
            event.setStatus("CANCELLED");
            eventMapper.updateById(event);
        });
    }

    // ==================== 定时调度 ====================

    /**
     * 每分钟检查需要触发的提醒
     */
    @Scheduled(fixedRate = 60000)
    @Transactional
    public void triggerPendingReminders() {
        Instant now = Instant.now();

        List<ReminderEvent> events = eventMapper.selectList(
                new LambdaQueryWrapper<ReminderEvent>()
                        .eq(ReminderEvent::getStatus, "PENDING")
                        .le(ReminderEvent::getTriggerTime, now)
        );

        for (ReminderEvent event : events) {
            try {
                // 创建通知
                Notification notification = new Notification();
                notification.setUserId(event.getUserId());
                notification.setTaskId(event.getTaskId());
                notification.setReminderEventId(event.getId());
                notification.setNotificationType("REMINDER");
                notification.setTitle("任务提醒");
                notification.setContent(event.getMessage() != null ? event.getMessage() : "该推进任务了");
                notification.setReadStatus(false);
                notification.setActionType("START_TASK");
                notificationMapper.insert(notification);

                // 更新事件状态
                event.setStatus("SENT");
                eventMapper.updateById(event);

            } catch (Exception e) {
                log.error("Failed to trigger reminder {}: {}", event.getId(), e.getMessage());
            }
        }

        if (!events.isEmpty()) {
            log.info("Triggered {} reminder events", events.size());
        }
    }

    /**
     * 每天检查长期未推进的任务
     */
    @Scheduled(cron = "0 0 9 * * ?")
    @Transactional
    public void checkInactiveTasks() {
        Instant threshold = Instant.now().minus(3, ChronoUnit.DAYS);

        List<Task> inactiveTasks = taskMapper.selectList(
                new LambdaQueryWrapper<Task>()
                        .eq(Task::getStatus, "PAUSED")
                        .lt(Task::getLastActiveTime, threshold)
        );

        for (Task task : inactiveTasks) {
            Notification notification = new Notification();
            notification.setUserId(task.getUserId());
            notification.setTaskId(task.getId());
            notification.setNotificationType("REMINDER");
            notification.setTitle("任务久未推进");
            notification.setContent("任务「" + task.getTitle() + "」已暂停较久，是否继续？");
            notification.setReadStatus(false);
            notification.setActionType("RESUME_TASK");
            notificationMapper.insert(notification);
        }

        if (!inactiveTasks.isEmpty()) {
            log.info("Created {} inactive task notifications", inactiveTasks.size());
        }
    }

    // ==================== 私有方法 ====================

    private void generateEventsForRule(ReminderRule rule, Task task) {
        List<ReminderEvent> events = new ArrayList<>();

        switch (rule.getRuleType()) {
            case "START":
                if (task.getStartTime() != null) {
                    events.add(createEvent(rule, task, task.getStartTime(),
                            "任务「" + task.getTitle() + "」开始时间到了"));
                }
                break;

            case "DEADLINE":
                if (task.getDeadline() != null) {
                    if (rule.getBeforeDeadlineMinutes() != null) {
                        Instant triggerTime = task.getDeadline()
                                .minus(rule.getBeforeDeadlineMinutes(), ChronoUnit.MINUTES);
                        events.add(createEvent(rule, task, triggerTime,
                                "任务「" + task.getTitle() + "」还有 " + rule.getBeforeDeadlineMinutes() + " 分钟截止"));
                    } else {
                        // 默认提醒：截止前1天、3小时、30分钟
                        events.add(createEvent(rule, task,
                                task.getDeadline().minus(1, ChronoUnit.DAYS),
                                "任务「" + task.getTitle() + "」明天截止"));
                        events.add(createEvent(rule, task,
                                task.getDeadline().minus(3, ChronoUnit.HOURS),
                                "任务「" + task.getTitle() + "」3小时后截止"));
                        events.add(createEvent(rule, task,
                                task.getDeadline().minus(30, ChronoUnit.MINUTES),
                                "任务「" + task.getTitle() + "」30分钟后截止"));
                    }
                }
                break;

            case "REPEAT":
                if (rule.getIntervalMinutes() != null) {
                    Instant trigger = Instant.now().plus(rule.getIntervalMinutes(), ChronoUnit.MINUTES);
                    events.add(createEvent(rule, task, trigger,
                            "任务「" + task.getTitle() + "」推进提醒"));
                }
                break;

            case "REVIEW":
                // 复习：1天、3天、7天
                events.add(createEvent(rule, task,
                        Instant.now().plus(1, ChronoUnit.DAYS),
                        "任务「" + task.getTitle() + "」1天复习提醒"));
                events.add(createEvent(rule, task,
                        Instant.now().plus(3, ChronoUnit.DAYS),
                        "任务「" + task.getTitle() + "」3天复习提醒"));
                events.add(createEvent(rule, task,
                        Instant.now().plus(7, ChronoUnit.DAYS),
                        "任务「" + task.getTitle() + "」7天复习提醒"));
                break;

            case "TRIGGER":
                if (rule.getTriggerTime() != null) {
                    events.add(createEvent(rule, task, rule.getTriggerTime(),
                            "任务「" + task.getTitle() + "」定时提醒"));
                }
                break;
        }

        events.forEach(eventMapper::insert);
    }

    private ReminderEvent createEvent(ReminderRule rule, Task task, Instant triggerTime, String message) {
        ReminderEvent event = new ReminderEvent();
        event.setUserId(rule.getUserId());
        event.setTaskId(task.getId());
        event.setRuleId(rule.getId());
        event.setTriggerTime(triggerTime);
        event.setStatus("PENDING");
        event.setMessage(message);
        return event;
    }

    private ReminderRuleResponse toRuleResponse(ReminderRule rule) {
        ReminderRuleResponse response = new ReminderRuleResponse();
        response.setId(rule.getId());
        response.setTaskId(rule.getTaskId());
        response.setRuleType(rule.getRuleType());
        response.setCronExpr(rule.getCronExpr());
        response.setIntervalMinutes(rule.getIntervalMinutes());
        response.setBeforeDeadlineMinutes(rule.getBeforeDeadlineMinutes());
        response.setTriggerTime(rule.getTriggerTime());
        response.setEnabled(rule.getEnabled());
        response.setCreatedAt(rule.getCreatedAt());
        return response;
    }

    private ReminderEventResponse toEventResponse(ReminderEvent event, boolean includeTaskTitle) {
        ReminderEventResponse response = new ReminderEventResponse();
        response.setId(event.getId());
        response.setTaskId(event.getTaskId());
        response.setRuleId(event.getRuleId());
        response.setTriggerTime(event.getTriggerTime());
        response.setStatus(event.getStatus());
        response.setSnoozeUntil(event.getSnoozeUntil());
        response.setMessage(event.getMessage());

        if (includeTaskTitle) {
            Task task = taskMapper.selectById(event.getTaskId());
            if (task != null) {
                response.setTaskTitle(task.getTitle());
            }
        }

        response.setCreatedAt(event.getCreatedAt());
        return response;
    }
}
package com.taskos.task.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.Instant;

/**
 * 任务会话实体
 */
@Data
@TableName("task_sessions")
public class TaskSession {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long taskId;

    private Instant startedAt;

    private Instant pausedAt;

    private Instant endedAt;

    private Integer durationMinutes;

    private String sessionGoal;

    private String resultSummary;

    private Long snapshotId;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;
}
package com.taskos.snapshot.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.taskos.common.exception.ResourceNotFoundException;
import com.taskos.file.entity.FileEntity;
import com.taskos.file.mapper.FileMapper;
import com.taskos.note.entity.Note;
import com.taskos.note.mapper.NoteMapper;
import com.taskos.snapshot.dto.*;
import com.taskos.snapshot.entity.TaskSnapshot;
import com.taskos.snapshot.mapper.TaskSnapshotMapper;
import com.taskos.task.entity.Task;
import com.taskos.task.mapper.TaskMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 快照服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SnapshotService {

    private final TaskSnapshotMapper snapshotMapper;
    private final TaskMapper taskMapper;
    private final NoteMapper noteMapper;
    private final FileMapper fileMapper;

    /**
     * 创建快照
     */
    @Transactional
    public SnapshotResponse createSnapshot(Long userId, Long taskId, CreateSnapshotRequest request) {
        Task task = taskMapper.selectById(taskId);
        if (task == null || !task.getUserId().equals(userId)) {
            throw ResourceNotFoundException.task(taskId);
        }

        TaskSnapshot snapshot = new TaskSnapshot();
        snapshot.setUserId(userId);
        snapshot.setTaskId(taskId);
        snapshot.setSnapshotType(request.getSnapshotType());
        snapshot.setRawInput(request.getRawInput());
        snapshot.setCurrentProgress(request.getCurrentProgress());
        snapshot.setPauseReason(request.getPauseReason());
        snapshot.setNextAction(request.getNextAction());
        snapshot.setOpenQuestions(request.getOpenQuestions() != null ? request.getOpenQuestions() : Collections.emptyList());

        // 处理关联文件
        if (request.getRelatedFileIds() != null && !request.getRelatedFileIds().isEmpty()) {
            List<TaskSnapshot.RelatedFile> relatedFiles = request.getRelatedFileIds().stream()
                    .map(fileId -> {
                        FileEntity file = fileMapper.selectById(fileId);
                        if (file != null) {
                            TaskSnapshot.RelatedFile rf = new TaskSnapshot.RelatedFile();
                            rf.setFileId(fileId);
                            rf.setFileName(file.getFileName());
                            return rf;
                        }
                        return null;
                    })
                    .filter(f -> f != null)
                    .toList();
            snapshot.setRelatedFiles(relatedFiles);
        } else {
            snapshot.setRelatedFiles(Collections.emptyList());
        }

        // 处理关联笔记
        if (request.getRelatedNoteIds() != null && !request.getRelatedNoteIds().isEmpty()) {
            List<TaskSnapshot.RelatedNote> relatedNotes = request.getRelatedNoteIds().stream()
                    .map(noteId -> {
                        Note note = noteMapper.selectById(noteId);
                        if (note != null) {
                            TaskSnapshot.RelatedNote rn = new TaskSnapshot.RelatedNote();
                            rn.setNoteId(noteId);
                            rn.setTitle(note.getTitle());
                            return rn;
                        }
                        return null;
                    })
                    .filter(n -> n != null)
                    .toList();
            snapshot.setRelatedNotes(relatedNotes);
        } else {
            snapshot.setRelatedNotes(Collections.emptyList());
        }

        snapshotMapper.insert(snapshot);

        // 更新任务的当前快照ID
        task.setCurrentSnapshotId(snapshot.getId());
        taskMapper.updateById(task);

        return toSnapshotResponse(snapshot);
    }

    /**
     * 获取任务最新快照
     */
    public SnapshotResponse getLatestSnapshot(Long userId, Long taskId) {
        Task task = taskMapper.selectById(taskId);
        if (task == null || !task.getUserId().equals(userId)) {
            throw ResourceNotFoundException.task(taskId);
        }

        TaskSnapshot snapshot = snapshotMapper.selectOne(
                new LambdaQueryWrapper<TaskSnapshot>()
                        .eq(TaskSnapshot::getTaskId, taskId)
                        .orderByDesc(TaskSnapshot::getCreatedAt)
                        .last("LIMIT 1")
        );

        if (snapshot == null) {
            return null;
        }

        return toSnapshotResponse(snapshot);
    }

    /**
     * 获取恢复卡片
     */
    public ResumeCardResponse getResumeCard(Long userId, Long taskId) {
        Task task = taskMapper.selectById(taskId);
        if (task == null || !task.getUserId().equals(userId)) {
            throw ResourceNotFoundException.task(taskId);
        }

        TaskSnapshot snapshot = null;
        if (task.getCurrentSnapshotId() != null) {
            snapshot = snapshotMapper.selectById(task.getCurrentSnapshotId());
        }

        if (snapshot == null) {
            snapshot = snapshotMapper.selectOne(
                    new LambdaQueryWrapper<TaskSnapshot>()
                            .eq(TaskSnapshot::getTaskId, taskId)
                            .orderByDesc(TaskSnapshot::getCreatedAt)
                            .last("LIMIT 1")
            );
        }

        if (snapshot == null) {
            return null;
        }

        ResumeCardResponse response = new ResumeCardResponse();
        response.setTaskTitle(task.getTitle());
        response.setLastProgress(snapshot.getCurrentProgress());
        response.setPauseReason(snapshot.getPauseReason());
        response.setOpenQuestions(snapshot.getOpenQuestions());
        response.setNextAction(snapshot.getNextAction());
        response.setLastActiveTime(task.getLastActiveTime());

        // 加载关联笔记详情
        if (snapshot.getRelatedNotes() != null && !snapshot.getRelatedNotes().isEmpty()) {
            List<ResumeCardResponse.NoteSummary> notes = snapshot.getRelatedNotes().stream()
                    .map(rn -> {
                        Note note = noteMapper.selectById(rn.getNoteId());
                        if (note != null) {
                            ResumeCardResponse.NoteSummary ns = new ResumeCardResponse.NoteSummary();
                            ns.setId(note.getId());
                            ns.setTitle(note.getTitle());
                            ns.setContentPreview(note.getContent() != null && note.getContent().length() > 100
                                    ? note.getContent().substring(0, 100) + "..."
                                    : note.getContent());
                            return ns;
                        }
                        return null;
                    })
                    .filter(n -> n != null)
                    .toList();
            response.setRelatedNotes(notes);
        } else {
            response.setRelatedNotes(Collections.emptyList());
        }

        // 加载关联文件详情
        if (snapshot.getRelatedFiles() != null && !snapshot.getRelatedFiles().isEmpty()) {
            List<ResumeCardResponse.FileSummary> files = snapshot.getRelatedFiles().stream()
                    .map(rf -> {
                        FileEntity file = fileMapper.selectById(rf.getFileId());
                        if (file != null) {
                            ResumeCardResponse.FileSummary fs = new ResumeCardResponse.FileSummary();
                            fs.setId(file.getId());
                            fs.setFileName(file.getFileName());
                            fs.setFileType(file.getFileType());
                            return fs;
                        }
                        return null;
                    })
                    .filter(f -> f != null)
                    .toList();
            response.setRelatedFiles(files);
        } else {
            response.setRelatedFiles(Collections.emptyList());
        }

        return response;
    }

    private SnapshotResponse toSnapshotResponse(TaskSnapshot snapshot) {
        SnapshotResponse response = new SnapshotResponse();
        response.setId(snapshot.getId());
        response.setTaskId(snapshot.getTaskId());
        response.setSnapshotType(snapshot.getSnapshotType());
        response.setRawInput(snapshot.getRawInput());
        response.setAiSummary(snapshot.getAiSummary());
        response.setCurrentProgress(snapshot.getCurrentProgress());
        response.setPauseReason(snapshot.getPauseReason());
        response.setNextAction(snapshot.getNextAction());
        response.setOpenQuestions(snapshot.getOpenQuestions());

        if (snapshot.getRelatedFiles() != null) {
            response.setRelatedFiles(snapshot.getRelatedFiles().stream()
                    .map(rf -> {
                        SnapshotResponse.RelatedFileDto dto = new SnapshotResponse.RelatedFileDto();
                        dto.setFileId(rf.getFileId());
                        dto.setFileName(rf.getFileName());
                        return dto;
                    })
                    .toList());
        }

        if (snapshot.getRelatedNotes() != null) {
            response.setRelatedNotes(snapshot.getRelatedNotes().stream()
                    .map(rn -> {
                        SnapshotResponse.RelatedNoteDto dto = new SnapshotResponse.RelatedNoteDto();
                        dto.setNoteId(rn.getNoteId());
                        dto.setTitle(rn.getTitle());
                        return dto;
                    })
                    .toList());
        }

        response.setCreatedAt(snapshot.getCreatedAt());
        return response;
    }
}
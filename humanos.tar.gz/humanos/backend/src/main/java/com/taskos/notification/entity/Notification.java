package com.taskos.notification.entity;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.handlers.JacksonTypeHandler;
import lombok.Data;

import java.time.Instant;
import java.util.Map;

/**
 * 通知实体
 */
@Data
@TableName(value = "notifications", autoResultMap = true)
public class Notification {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long taskId;

    private Long reminderEventId;

    private String notificationType;

    private String title;

    private String content;

    private Boolean readStatus;

    private String actionType;

    @TableField(typeHandler = JacksonTypeHandler.class)
    private Map<String, Object> actionData;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;
}
package com.taskos.snapshot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.taskos.snapshot.entity.TaskSnapshot;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaskSnapshotMapper extends BaseMapper<TaskSnapshot> {
}
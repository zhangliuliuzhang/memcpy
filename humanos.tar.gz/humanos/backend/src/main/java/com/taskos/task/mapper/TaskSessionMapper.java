package com.taskos.task.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.taskos.task.entity.TaskSession;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TaskSessionMapper extends BaseMapper<TaskSession> {
}
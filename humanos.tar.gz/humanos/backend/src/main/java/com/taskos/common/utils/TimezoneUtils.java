package com.taskos.common.utils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

/**
 * 时区工具类
 * 数据库统一存储 UTC，前端展示按用户时区转换
 */
public final class TimezoneUtils {

    public static final String UTC = "UTC";
    public static final String DEFAULT_TIMEZONE = "Asia/Shanghai";
    private static final DateTimeFormatter ISO_FORMATTER = DateTimeFormatter.ISO_INSTANT;
    private static final DateTimeFormatter DISPLAY_FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private TimezoneUtils() {}

    /**
     * 将 UTC Instant 转换为指定时区的 LocalDateTime
     */
    public static LocalDateTime toLocalDateTime(Instant utcInstant, String timezone) {
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : DEFAULT_TIMEZONE);
        return LocalDateTime.ofInstant(utcInstant, zoneId);
    }

    /**
     * 将用户时区的 LocalDateTime 转换为 UTC Instant
     */
    public static Instant toUtcInstant(LocalDateTime localDateTime, String timezone) {
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : DEFAULT_TIMEZONE);
        return localDateTime.atZone(zoneId).toInstant();
    }

    /**
     * 获取指定时区的当前时间
     */
    public static Instant nowUtc() {
        return Instant.now();
    }

    /**
     * 获取指定时区的当前 LocalDate
     */
    public static LocalDate todayInTimezone(String timezone) {
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : DEFAULT_TIMEZONE);
        return LocalDate.now(zoneId);
    }

    /**
     * 获取指定时区当天的开始时间（UTC）
     */
    public static Instant startOfDayUtc(String timezone) {
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : DEFAULT_TIMEZONE);
        return LocalDate.now(zoneId)
                .atStartOfDay(zoneId)
                .toInstant();
    }

    /**
     * 获取指定时区当天的结束时间（UTC）
     */
    public static Instant endOfDayUtc(String timezone) {
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : DEFAULT_TIMEZONE);
        return LocalDate.now(zoneId)
                .plusDays(1)
                .atStartOfDay(zoneId)
                .minus(1, ChronoUnit.NANOS)
                .toInstant();
    }

    /**
     * 格式化 Instant 为 ISO 字符串
     */
    public static String formatIso(Instant instant) {
        if (instant == null) return null;
        return ISO_FORMATTER.format(instant);
    }

    /**
     * 按时区格式化展示时间
     */
    public static String formatDisplay(Instant instant, String timezone) {
        if (instant == null) return null;
        return toLocalDateTime(instant, timezone).format(DISPLAY_FORMATTER);
    }

    /**
     * 解析 ISO 字符串为 Instant
     */
    public static Instant parseIso(String isoString) {
        if (isoString == null || isoString.isEmpty()) return null;
        return Instant.parse(isoString);
    }

    /**
     * 计算两个时间之间的分钟差
     */
    public static long minutesBetween(Instant start, Instant end) {
        return ChronoUnit.MINUTES.between(start, end);
    }

    /**
     * 计算从现在到目标时间的分钟差（正数表示未来，负数表示过去）
     */
    public static long minutesFromNow(Instant target) {
        return ChronoUnit.MINUTES.between(Instant.now(), target);
    }

    /**
     * 判断时间是否在今天（按指定时区）
     */
    public static boolean isToday(Instant instant, String timezone) {
        if (instant == null) return false;
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : DEFAULT_TIMEZONE);
        LocalDate date = instant.atZone(zoneId).toLocalDate();
        return date.equals(todayInTimezone(timezone));
    }

    /**
     * 判断时间是否已过期
     */
    public static boolean isPast(Instant instant) {
        return instant != null && instant.isBefore(Instant.now());
    }

    /**
     * 获取当前时间按指定时区的 ZonedDateTime
     */
    public static ZonedDateTime nowInTimezone(String timezone) {
        ZoneId zoneId = ZoneId.of(timezone != null ? timezone : DEFAULT_TIMEZONE);
        return ZonedDateTime.now(zoneId);
    }
}
package com.taskos.task.controller;

import com.taskos.common.response.ApiResponse;
import com.taskos.common.security.UserPrincipal;
import com.taskos.task.dto.*;
import com.taskos.task.service.TaskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * 任务控制器
 */
@Tag(name = "任务", description = "任务管理接口")
@RestController
@RequestMapping("/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;

    @Operation(summary = "创建任务")
    @PostMapping
    public ApiResponse<TaskResponse> createTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody CreateTaskRequest request) {
        TaskResponse task = taskService.createTask(principal.getId(), request);
        return ApiResponse.success(task, "任务创建成功");
    }

    @Operation(summary = "获取任务详情")
    @GetMapping("/{taskId}")
    public ApiResponse<TaskResponse> getTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId) {
        TaskResponse task = taskService.getTask(principal.getId(), taskId);
        return ApiResponse.success(task);
    }

    @Operation(summary = "获取任务列表")
    @GetMapping
    public ApiResponse<ApiResponse.PageResult<TaskResponse>> getTaskList(
            @AuthenticationPrincipal UserPrincipal principal,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String taskType,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int size) {
        ApiResponse.PageResult<TaskResponse> result = taskService.getTaskList(
                principal.getId(), status, taskType, page, size);
        return ApiResponse.success(result);
    }

    @Operation(summary = "获取今日驾驶舱")
    @GetMapping("/today")
    public ApiResponse<TodayDashboardResponse> getTodayDashboard(
            @AuthenticationPrincipal UserPrincipal principal) {
        TodayDashboardResponse dashboard = taskService.getTodayDashboard(principal.getId());
        return ApiResponse.success(dashboard);
    }

    @Operation(summary = "更新任务")
    @PutMapping("/{taskId}")
    public ApiResponse<TaskResponse> updateTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId,
            @Valid @RequestBody CreateTaskRequest request) {
        TaskResponse task = taskService.updateTask(principal.getId(), taskId, request);
        return ApiResponse.success(task, "任务更新成功");
    }

    @Operation(summary = "删除任务")
    @DeleteMapping("/{taskId}")
    public ApiResponse<Void> deleteTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId) {
        taskService.deleteTask(principal.getId(), taskId);
        return ApiResponse.success(null, "任务删除成功");
    }

    @Operation(summary = "开始任务")
    @PostMapping("/{taskId}/start")
    public ApiResponse<TaskResponse> startTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId,
            @RequestBody(required = false) StartTaskRequest request) {
        String sessionGoal = request != null ? request.getSessionGoal() : null;
        TaskResponse task = taskService.startTask(principal.getId(), taskId, sessionGoal);
        return ApiResponse.success(task, "任务已开始");
    }

    @Operation(summary = "暂停任务")
    @PostMapping("/{taskId}/pause")
    public ApiResponse<TaskResponse> pauseTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId,
            @RequestBody(required = false) PauseTaskRequest request) {
        String rawInput = request != null ? request.getRawInput() : null;
        String pauseReason = request != null ? request.getPauseReason() : null;
        TaskResponse task = taskService.pauseTask(principal.getId(), taskId, rawInput, pauseReason);
        return ApiResponse.success(task, "任务已暂停");
    }

    @Operation(summary = "恢复任务")
    @PostMapping("/{taskId}/resume")
    public ApiResponse<TaskResponse> resumeTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId) {
        TaskResponse task = taskService.resumeTask(principal.getId(), taskId);
        return ApiResponse.success(task, "任务已恢复");
    }

    @Operation(summary = "完成任务")
    @PostMapping("/{taskId}/complete")
    public ApiResponse<TaskResponse> completeTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId,
            @RequestBody(required = false) CompleteTaskRequest request) {
        String resultSummary = request != null ? request.getResultSummary() : null;
        TaskResponse task = taskService.completeTask(principal.getId(), taskId, resultSummary);
        return ApiResponse.success(task, "任务已完成");
    }

    @Operation(summary = "取消任务")
    @PostMapping("/{taskId}/cancel")
    public ApiResponse<TaskResponse> cancelTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId,
            @RequestBody(required = false) CancelTaskRequest request) {
        String reason = request != null ? request.getReason() : null;
        TaskResponse task = taskService.cancelTask(principal.getId(), taskId, reason);
        return ApiResponse.success(task, "任务已取消");
    }
}
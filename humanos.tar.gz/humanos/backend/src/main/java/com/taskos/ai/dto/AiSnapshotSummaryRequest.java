package com.taskos.ai.dto;

import lombok.Data;

import java.util.List;

/**
 * AI 快照总结请求
 */
@Data
public class AiSnapshotSummaryRequest {

    private Long taskId;

    private String taskTitle;

    private String rawInput;

    private String previousProgress;

    private List<String> recentNotes;
}
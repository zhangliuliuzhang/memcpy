package com.taskos.snapshot.dto;

import lombok.Data;

import java.time.Instant;
import java.util.List;

/**
 * 任务恢复卡片响应
 */
@Data
public class ResumeCardResponse {

    private String taskTitle;
    private String lastProgress;
    private String pauseReason;
    private List<String> openQuestions;
    private String nextAction;
    private List<NoteSummary> relatedNotes;
    private List<FileSummary> relatedFiles;
    private Instant lastActiveTime;

    @Data
    public static class NoteSummary {
        private Long id;
        private String title;
        private String contentPreview;
    }

    @Data
    public static class FileSummary {
        private Long id;
        private String fileName;
        private String fileType;
    }
}
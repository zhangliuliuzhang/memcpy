package com.taskos.task.dto;

import lombok.Data;

import java.time.Instant;
import java.util.List;

/**
 * 今日驾驶舱响应
 */
@Data
public class TodayDashboardResponse {

    private List<TaskResponse> doing;
    private List<TaskResponse> mustDoToday;
    private List<TaskResponse> needResume;
    private List<TaskResponse> aiDone;
    private List<TaskResponse> reviewItems;
}
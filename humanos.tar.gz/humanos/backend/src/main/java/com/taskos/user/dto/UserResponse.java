package com.taskos.user.dto;

import com.taskos.user.entity.UserSettings;
import lombok.Data;

/**
 * 用户响应
 */
@Data
public class UserResponse {

    private Long id;
    private String username;
    private String email;
    private String phone;
    private String avatarUrl;
    private String status;
    private String timezone;
    private UserSettings settings;
    private String createdAt;
}
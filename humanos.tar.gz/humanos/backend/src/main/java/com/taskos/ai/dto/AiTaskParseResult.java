package com.taskos.ai.dto;

import lombok.Data;

import java.time.Instant;
import java.util.List;

/**
 * AI 任务解析结果
 */
@Data
public class AiTaskParseResult {

    private String title;
    private String taskType;
    private Instant startTime;
    private Instant deadline;
    private Integer estimatedMinutes;
    private Integer priority;
    private List<ReminderRuleSuggestion> reminderRules;
    private Boolean needUserConfirm;

    @Data
    public static class ReminderRuleSuggestion {
        private String type;
        private String description;
        private Instant triggerTime;
        private Integer intervalMinutes;
        private Integer beforeDeadlineMinutes;
    }
}
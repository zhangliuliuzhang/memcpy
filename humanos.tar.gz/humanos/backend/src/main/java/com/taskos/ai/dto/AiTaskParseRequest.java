package com.taskos.ai.dto;

import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * AI 任务解析请求
 */
@Data
public class AiTaskParseRequest {

    private String text;

    private String timezone;

    private String language;
}
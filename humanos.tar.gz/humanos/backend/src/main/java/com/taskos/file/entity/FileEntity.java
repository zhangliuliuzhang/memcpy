package com.taskos.file.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.Instant;

/**
 * 文件实体
 */
@Data
@TableName("files")
public class FileEntity {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long taskId;

    private Long noteId;

    private String fileName;

    private String fileType;

    private String storagePath;

    private Long sizeBytes;

    private String checksum;

    private String source;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;
}
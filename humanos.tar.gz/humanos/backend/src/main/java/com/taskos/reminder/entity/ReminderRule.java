package com.taskos.reminder.entity;

import com.baomidou.mybatisplus.annotation.*;
import lombok.Data;

import java.time.Instant;

/**
 * 提醒规则实体
 */
@Data
@TableName("reminder_rules")
public class ReminderRule {

    @TableId(type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long taskId;

    private String ruleType;

    private String cronExpr;

    private Integer intervalMinutes;

    private Integer beforeDeadlineMinutes;

    private Instant triggerTime;

    private Boolean enabled;

    @TableField(fill = FieldFill.INSERT)
    private Instant createdAt;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private Instant updatedAt;
}
package com.taskos.common.response;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 错误码枚举
 */
@Getter
@RequiredArgsConstructor
public enum ErrorCode {

    // ==================== 通用错误 1xxx ====================
    SUCCESS("0000", "操作成功"),
    BAD_REQUEST("1000", "请求参数错误"),
    INVALID_PARAMETER("1001", "参数校验失败"),
    RESOURCE_NOT_FOUND("1002", "资源不存在"),
    METHOD_NOT_ALLOWED("1003", "请求方法不支持"),
    INTERNAL_ERROR("1004", "服务器内部错误"),
    TOO_MANY_REQUESTS("1005", "请求过于频繁"),

    // ==================== 认证错误 2xxx ====================
    UNAUTHORIZED("2000", "未登录或登录已过期"),
    TOKEN_EXPIRED("2001", "令牌已过期"),
    TOKEN_INVALID("2002", "无效的令牌"),
    LOGIN_FAILED("2003", "登录失败，用户名或密码错误"),
    ACCOUNT_DISABLED("2004", "账号已被禁用"),
    ACCOUNT_SUSPENDED("2005", "账号已被暂停"),
    REFRESH_TOKEN_INVALID("2006", "刷新令牌无效"),
    DEVICE_NOT_TRUSTED("2007", "设备不受信任"),

    // ==================== 权限错误 3xxx ====================
    FORBIDDEN("3000", "无权限访问"),
    ACCESS_DENIED("3001", "拒绝访问"),
    RESOURCE_OWNER_MISMATCH("3002", "无权访问此资源"),

    // ==================== 用户错误 4xxx ====================
    USER_NOT_FOUND("4000", "用户不存在"),
    USERNAME_EXISTS("4001", "用户名已存在"),
    EMAIL_EXISTS("4002", "邮箱已被注册"),
    PHONE_EXISTS("4003", "手机号已被注册"),
    PASSWORD_MISMATCH("4004", "原密码错误"),
    SAME_PASSWORD("4005", "新密码不能与原密码相同"),

    // ==================== 任务错误 5xxx ====================
    TASK_NOT_FOUND("5000", "任务不存在"),
    TASK_STATUS_INVALID("5001", "任务状态不正确"),
    TASK_ALREADY_DONE("5002", "任务已完成"),
    TASK_ALREADY_CANCELLED("5003", "任务已取消"),
    TASK_DEADLINE_PASSED("5004", "任务已过截止时间"),
    CANNOT_START_TASK("5005", "当前状态无法开始任务"),
    CANNOT_PAUSE_TASK("5006", "当前状态无法暂停任务"),
    CANNOT_RESUME_TASK("5007", "当前状态无法恢复任务"),
    CANNOT_COMPLETE_TASK("5008", "当前状态无法完成任务"),

    // ==================== 快照错误 6xxx ====================
    SNAPSHOT_NOT_FOUND("6000", "快照不存在"),
    NO_ACTIVE_SESSION("6001", "没有进行中的会话"),

    // ==================== 提醒错误 7xxx ====================
    REMINDER_RULE_NOT_FOUND("7000", "提醒规则不存在"),
    REMINDER_EVENT_NOT_FOUND("7001", "提醒事件不存在"),
    CANNOT_SNOOZE_REMINDER("7002", "该提醒无法稍后提醒"),

    // ==================== 文件错误 8xxx ====================
    FILE_NOT_FOUND("8000", "文件不存在"),
    FILE_TOO_LARGE("8001", "文件大小超出限制"),
    FILE_TYPE_NOT_ALLOWED("8002", "不支持的文件类型"),
    FILE_UPLOAD_FAILED("8003", "文件上传失败"),

    // ==================== AI 错误 9xxx ====================
    AI_SERVICE_UNAVAILABLE("9000", "AI 服务不可用"),
    AI_PARSE_FAILED("9001", "AI 解析失败"),
    AI_TIMEOUT("9002", "AI 处理超时"),
    AI_JOB_NOT_FOUND("9003", "AI 任务不存在"),
    AI_JOB_FAILED("9004", "AI 任务执行失败");

    private final String code;
    private final String message;
}
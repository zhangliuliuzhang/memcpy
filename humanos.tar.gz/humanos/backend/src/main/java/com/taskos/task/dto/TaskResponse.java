package com.taskos.task.dto;

import lombok.Data;

import java.time.Instant;

/**
 * 任务响应
 */
@Data
public class TaskResponse {

    private Long id;
    private String title;
    private String description;
    private String taskType;
    private String status;
    private Integer priority;
    private Instant startTime;
    private Instant deadline;
    private Integer estimatedMinutes;
    private Integer actualMinutes;
    private Integer progress;
    private Long currentSnapshotId;
    private Instant lastActiveTime;
    private Integer version;
    private Instant createdAt;
    private Instant updatedAt;
}
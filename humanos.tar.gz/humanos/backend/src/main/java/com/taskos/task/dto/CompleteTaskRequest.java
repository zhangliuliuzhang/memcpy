package com.taskos.task.dto;

import lombok.Data;

/**
 * 完成任务请求
 */
@Data
public class CompleteTaskRequest {
    private String resultSummary;
}
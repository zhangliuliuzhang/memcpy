package com.taskos;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.taskos.**.mapper")
@EnableAsync
@EnableScheduling
public class TaskOsApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaskOsApplication.class, args);
    }
}

package com.taskos.ai.controller;

import com.taskos.ai.dto.*;
import com.taskos.ai.service.AiService;
import com.taskos.common.response.ApiResponse;
import com.taskos.common.security.UserPrincipal;
import com.taskos.snapshot.dto.CreateSnapshotRequest;
import com.taskos.snapshot.dto.ResumeCardResponse;
import com.taskos.snapshot.service.SnapshotService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * AI 控制器
 */
@Tag(name = "AI", description = "AI 能力接口")
@RestController
@RequestMapping("/ai")
@RequiredArgsConstructor
public class AiController {

    private final AiService aiService;
    private final SnapshotService snapshotService;

    @Operation(summary = "解析任务")
    @PostMapping("/parse-task")
    public ApiResponse<AiTaskParseResult> parseTask(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody AiTaskParseRequest request) {
        AiTaskParseResult result = aiService.parseTask(
                request.getText(),
                principal.getTimezone()
        );
        return ApiResponse.success(result);
    }

    @Operation(summary = "总结快照")
    @PostMapping("/summarize-snapshot")
    public ApiResponse<AiSnapshotSummaryResult> summarizeSnapshot(
            @AuthenticationPrincipal UserPrincipal principal,
            @Valid @RequestBody AiSnapshotSummaryRequest request) {
        AiSnapshotSummaryResult result = aiService.summarizeSnapshot(request);
        return ApiResponse.success(result);
    }

    @Operation(summary = "暂停任务并生成快照")
    @PostMapping("/tasks/{taskId}/pause-with-snapshot")
    public ApiResponse<ResumeCardResponse> pauseWithSnapshot(
            @AuthenticationPrincipal UserPrincipal principal,
            @PathVariable Long taskId,
            @Valid @RequestBody CreateSnapshotRequest request) {
        // 先创建快照
        snapshotService.createSnapshot(principal.getId(), taskId, request);

        // 调用 AI 总结
        AiSnapshotSummaryRequest summaryRequest = new AiSnapshotSummaryRequest();
        summaryRequest.setTaskId(taskId);
        summaryRequest.setRawInput(request.getRawInput());
        AiSnapshotSummaryResult summary = aiService.summarizeSnapshot(summaryRequest);

        // 更新快照的 AI 总结
        // 这里简化处理，实际可以更新快照记录

        // 返回恢复卡片
        ResumeCardResponse card = snapshotService.getResumeCard(principal.getId(), taskId);
        return ApiResponse.success(card, "任务已暂停，快照已保存");
    }
}
package com.taskos.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.taskos.user.entity.LoginToken;
import org.apache.ibatis.annotations.Mapper;

/**
 * 登录令牌 Mapper
 */
@Mapper
public interface LoginTokenMapper extends BaseMapper<LoginToken> {
}
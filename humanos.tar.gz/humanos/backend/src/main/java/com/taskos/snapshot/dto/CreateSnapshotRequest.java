package com.taskos.snapshot.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

/**
 * 创建快照请求
 */
@Data
public class CreateSnapshotRequest {

    private String snapshotType = "PAUSE";

    @NotBlank(message = "原始输入不能为空")
    private String rawInput;

    private String currentProgress;

    private String pauseReason;

    private String nextAction;

    private List<String> openQuestions;

    private List<Long> relatedFileIds;

    private List<Long> relatedNoteIds;
}
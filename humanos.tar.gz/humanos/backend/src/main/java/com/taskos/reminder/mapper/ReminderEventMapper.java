package com.taskos.reminder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.taskos.reminder.entity.ReminderEvent;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReminderEventMapper extends BaseMapper<ReminderEvent> {
}
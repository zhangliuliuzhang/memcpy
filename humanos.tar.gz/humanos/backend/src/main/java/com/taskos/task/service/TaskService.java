package com.taskos.task.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.taskos.common.exception.BusinessException;
import com.taskos.common.exception.ResourceNotFoundException;
import com.taskos.common.response.ApiResponse;
import com.taskos.common.response.ErrorCode;
import com.taskos.task.dto.*;
import com.taskos.task.entity.Task;
import com.taskos.task.entity.TaskSession;
import com.taskos.task.mapper.TaskMapper;
import com.taskos.task.mapper.TaskSessionMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

/**
 * 任务服务
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TaskService extends ServiceImpl<TaskMapper, Task> {

    private final TaskMapper taskMapper;
    private final TaskSessionMapper taskSessionMapper;

    /**
     * 创建任务
     */
    @Transactional
    public TaskResponse createTask(Long userId, CreateTaskRequest request) {
        Task task = new Task();
        task.setUserId(userId);
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setTaskType(request.getTaskType() != null ? request.getTaskType() : "NORMAL");
        task.setStatus("TODO");
        task.setPriority(request.getPriority() != null ? request.getPriority() : 2);
        task.setStartTime(request.getStartTime());
        task.setDeadline(request.getDeadline());
        task.setEstimatedMinutes(request.getEstimatedMinutes());
        task.setActualMinutes(0);
        task.setProgress(0);
        task.setVersion(0);

        taskMapper.insert(task);

        return toTaskResponse(task);
    }

    /**
     * 获取任务详情
     */
    public TaskResponse getTask(Long userId, Long taskId) {
        Task task = getTaskAndCheckOwner(userId, taskId);
        return toTaskResponse(task);
    }

    /**
     * 获取任务列表
     */
    public ApiResponse.PageResult<TaskResponse> getTaskList(Long userId, String status,
                                                              String taskType, int page, int size) {
        LambdaQueryWrapper<Task> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Task::getUserId, userId);

        if (status != null && !status.isEmpty()) {
            wrapper.eq(Task::getStatus, status);
        }

        if (taskType != null && !taskType.isEmpty()) {
            wrapper.eq(Task::getTaskType, taskType);
        }

        wrapper.orderByDesc(Task::getCreatedAt);

        Page<Task> pageResult = taskMapper.selectPage(new Page<>(page, size), wrapper);

        List<TaskResponse> list = pageResult.getRecords().stream()
                .map(this::toTaskResponse)
                .toList();

        return ApiResponse.page(list, pageResult.getTotal(), page, size);
    }

    /**
     * 获取今日驾驶舱
     */
    public TodayDashboardResponse getTodayDashboard(Long userId) {
        TodayDashboardResponse dashboard = new TodayDashboardResponse();

        // 正在进行的任务
        dashboard.setDoing(getTasksByStatus(userId, "DOING"));

        // 今日必须处理的（截止日期是今天或已过期且未完成）
        Instant now = Instant.now();
        Instant endOfToday = now.plus(24, ChronoUnit.HOURS);
        dashboard.setMustDoToday(getTasksWithDeadlineToday(userId, now, endOfToday));

        // 需要恢复的任务（PAUSED 状态）
        dashboard.setNeedResume(getTasksByStatus(userId, "PAUSED"));

        // AI 已完成等待确认（WAITING 状态）
        dashboard.setAiDone(getTasksByStatus(userId, "WAITING"));

        // 今天要复习的任务（MEMORY 类型且状态不是 DONE）
        dashboard.setReviewItems(getReviewTasks(userId));

        return dashboard;
    }

    /**
     * 更新任务
     */
    @Transactional
    public TaskResponse updateTask(Long userId, Long taskId, CreateTaskRequest request) {
        Task task = getTaskAndCheckOwner(userId, taskId);

        if ("DONE".equals(task.getStatus()) || "CANCELLED".equals(task.getStatus())) {
            throw new BusinessException(ErrorCode.TASK_ALREADY_DONE, "任务已完成或已取消，无法修改");
        }

        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        if (request.getTaskType() != null) {
            task.setTaskType(request.getTaskType());
        }
        if (request.getPriority() != null) {
            task.setPriority(request.getPriority());
        }
        task.setStartTime(request.getStartTime());
        task.setDeadline(request.getDeadline());
        task.setEstimatedMinutes(request.getEstimatedMinutes());

        taskMapper.updateById(task);

        return toTaskResponse(task);
    }

    /**
     * 删除任务（软删除）
     */
    @Transactional
    public void deleteTask(Long userId, Long taskId) {
        Task task = getTaskAndCheckOwner(userId, taskId);
        taskMapper.deleteById(task.getId());
    }

    // ==================== 状态流转方法 ====================

    /**
     * 开始任务
     */
    @Transactional
    public TaskResponse startTask(Long userId, Long taskId, String sessionGoal) {
        Task task = getTaskAndCheckOwner(userId, taskId);

        if (!canStart(task.getStatus())) {
            throw new BusinessException(ErrorCode.CANNOT_START_TASK,
                    "当前状态 " + task.getStatus() + " 无法开始任务");
        }

        // 创建会话
        TaskSession session = new TaskSession();
        session.setUserId(userId);
        session.setTaskId(taskId);
        session.setStartedAt(Instant.now());
        session.setSessionGoal(sessionGoal);
        taskSessionMapper.insert(session);

        // 更新任务状态
        task.setStatus("DOING");
        task.setLastActiveTime(Instant.now());
        taskMapper.updateById(task);

        return toTaskResponse(task);
    }

    /**
     * 检查是否可以开始
     */
    private boolean canStart(String status) {
        return "TODO".equals(status) || "PLANNED".equals(status) || "PAUSED".equals(status);
    }

    /**
     * 暂停任务
     */
    @Transactional
    public TaskResponse pauseTask(Long userId, Long taskId, String rawInput, String pauseReason) {
        Task task = getTaskAndCheckOwner(userId, taskId);

        if (!"DOING".equals(task.getStatus())) {
            throw new BusinessException(ErrorCode.CANNOT_PAUSE_TASK,
                    "当前状态 " + task.getStatus() + " 无法暂停任务");
        }

        // 查找当前活跃会话
        TaskSession session = taskSessionMapper.selectOne(
                new LambdaQueryWrapper<TaskSession>()
                        .eq(TaskSession::getTaskId, taskId)
                        .isNull(TaskSession::getEndedAt)
                        .isNull(TaskSession::getPausedAt)
                        .orderByDesc(TaskSession::getStartedAt)
                        .last("LIMIT 1")
        );

        if (session != null) {
            Instant now = Instant.now();
            session.setPausedAt(now);
            session.setDurationMinutes((int) ChronoUnit.MINUTES.between(session.getStartedAt(), now));
            session.setResultSummary(rawInput);
            taskSessionMapper.updateById(session);
        }

        // 更新任务状态
        task.setStatus("PAUSED");
        task.setLastActiveTime(Instant.now());
        taskMapper.updateById(task);

        return toTaskResponse(task);
    }

    /**
     * 恢复任务
     */
    @Transactional
    public TaskResponse resumeTask(Long userId, Long taskId) {
        Task task = getTaskAndCheckOwner(userId, taskId);

        if (!"PAUSED".equals(task.getStatus())) {
            throw new BusinessException(ErrorCode.CANNOT_RESUME_TASK,
                    "当前状态 " + task.getStatus() + " 无法恢复任务");
        }

        // 创建新会话
        TaskSession session = new TaskSession();
        session.setUserId(userId);
        session.setTaskId(taskId);
        session.setStartedAt(Instant.now());
        taskSessionMapper.insert(session);

        // 更新任务状态
        task.setStatus("DOING");
        task.setLastActiveTime(Instant.now());
        taskMapper.updateById(task);

        return toTaskResponse(task);
    }

    /**
     * 完成任务
     */
    @Transactional
    public TaskResponse completeTask(Long userId, Long taskId, String resultSummary) {
        Task task = getTaskAndCheckOwner(userId, taskId);

        if ("DONE".equals(task.getStatus()) || "CANCELLED".equals(task.getStatus())) {
            throw new BusinessException(ErrorCode.TASK_ALREADY_DONE, "任务已完成或已取消");
        }

        // 结束当前会话
        TaskSession session = taskSessionMapper.selectOne(
                new LambdaQueryWrapper<TaskSession>()
                        .eq(TaskSession::getTaskId, taskId)
                        .isNull(TaskSession::getEndedAt)
                        .orderByDesc(TaskSession::getStartedAt)
                        .last("LIMIT 1")
        );

        if (session != null) {
            Instant now = Instant.now();
            session.setEndedAt(now);
            if (session.getPausedAt() == null) {
                session.setDurationMinutes((int) ChronoUnit.MINUTES.between(session.getStartedAt(), now));
            }
            session.setResultSummary(resultSummary);
            taskSessionMapper.updateById(session);
        }

        // 计算总耗时
        Integer totalMinutes = taskSessionMapper.selectList(
                new LambdaQueryWrapper<TaskSession>()
                        .eq(TaskSession::getTaskId, taskId)
                        .isNotNull(TaskSession::getDurationMinutes)
        ).stream().mapToInt(s -> s.getDurationMinutes() != null ? s.getDurationMinutes() : 0).sum();

        // 更新任务状态
        task.setStatus("DONE");
        task.setProgress(100);
        task.setActualMinutes(totalMinutes);
        task.setLastActiveTime(Instant.now());
        taskMapper.updateById(task);

        return toTaskResponse(task);
    }

    /**
     * 取消任务
     */
    @Transactional
    public TaskResponse cancelTask(Long userId, Long taskId, String reason) {
        Task task = getTaskAndCheckOwner(userId, taskId);

        if ("DONE".equals(task.getStatus()) || "CANCELLED".equals(task.getStatus())) {
            throw new BusinessException(ErrorCode.TASK_ALREADY_CANCELLED, "任务已完成或已取消");
        }

        task.setStatus("CANCELLED");
        task.setLastActiveTime(Instant.now());
        taskMapper.updateById(task);

        return toTaskResponse(task);
    }

    // ==================== 私有方法 ====================

    private Task getTaskAndCheckOwner(Long userId, Long taskId) {
        Task task = taskMapper.selectById(taskId);
        if (task == null) {
            throw ResourceNotFoundException.task(taskId);
        }
        if (!task.getUserId().equals(userId)) {
            throw new BusinessException(ErrorCode.RESOURCE_OWNER_MISMATCH, "无权访问此任务");
        }
        return task;
    }

    private List<TaskResponse> getTasksByStatus(Long userId, String status) {
        return taskMapper.selectList(
                new LambdaQueryWrapper<Task>()
                        .eq(Task::getUserId, userId)
                        .eq(Task::getStatus, status)
                        .orderByDesc(Task::getLastActiveTime)
        ).stream().map(this::toTaskResponse).toList();
    }

    private List<TaskResponse> getTasksWithDeadlineToday(Long userId, Instant start, Instant end) {
        return taskMapper.selectList(
                new LambdaQueryWrapper<Task>()
                        .eq(Task::getUserId, userId)
                        .in(Task::getStatus, "TODO", "PLANNED", "DOING", "PAUSED")
                        .isNotNull(Task::getDeadline)
                        .between(Task::getDeadline, start, end)
                        .orderByAsc(Task::getDeadline)
        ).stream().map(this::toTaskResponse).toList();
    }

    private List<TaskResponse> getReviewTasks(Long userId) {
        return taskMapper.selectList(
                new LambdaQueryWrapper<Task>()
                        .eq(Task::getUserId, userId)
                        .eq(Task::getTaskType, "MEMORY")
                        .in(Task::getStatus, "TODO", "PLANNED", "DOING", "PAUSED")
                        .orderByAsc(Task::getLastActiveTime)
        ).stream().map(this::toTaskResponse).toList();
    }

    private TaskResponse toTaskResponse(Task task) {
        TaskResponse response = new TaskResponse();
        response.setId(task.getId());
        response.setTitle(task.getTitle());
        response.setDescription(task.getDescription());
        response.setTaskType(task.getTaskType());
        response.setStatus(task.getStatus());
        response.setPriority(task.getPriority());
        response.setStartTime(task.getStartTime());
        response.setDeadline(task.getDeadline());
        response.setEstimatedMinutes(task.getEstimatedMinutes());
        response.setActualMinutes(task.getActualMinutes());
        response.setProgress(task.getProgress());
        response.setCurrentSnapshotId(task.getCurrentSnapshotId());
        response.setLastActiveTime(task.getLastActiveTime());
        response.setVersion(task.getVersion());
        response.setCreatedAt(task.getCreatedAt());
        response.setUpdatedAt(task.getUpdatedAt());
        return response;
    }
}
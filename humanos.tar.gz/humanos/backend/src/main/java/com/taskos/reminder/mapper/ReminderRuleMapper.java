package com.taskos.reminder.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.taskos.reminder.entity.ReminderRule;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ReminderRuleMapper extends BaseMapper<ReminderRule> {
}
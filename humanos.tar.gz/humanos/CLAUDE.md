<!-- SPECKIT START -->
For additional context about technologies to be used, project structure,
shell commands, and other important information, read the current plan:
`specs/001-ai-task-os/plan.md`

Related documents:
- Spec: `specs/001-ai-task-os/spec.md`
- Research: `specs/001-ai-task-os/research.md`
- Data Model: `specs/001-ai-task-os/data-model.md`
- API Contracts: `specs/001-ai-task-os/contracts/`
- Quickstart: `specs/001-ai-task-os/quickstart.md`
<!-- SPECKIT END -->

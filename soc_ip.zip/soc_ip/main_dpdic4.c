#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <inttypes.h>

/**************************************************************************
* 函数名称: BspDoMemMap
* 功能描述: 虚拟地址映射
* 输入参数: phyAddr       :物理地址
*          size          :申请空间大小
* 输出参数: pVirAddr      :虚拟地址
* 返 回 值: 没存映射成功返回0 ，否则返回-1
* 其它说明: @2026-02-14 宋志强10099236 简化映射，自动判断32bit/64bit
*----------------------------------------------------------------------------*/
static int BspDoMemMap(off_t phyAddr, size_t size, char** ppVirAddr)
{
    int iSpaceProt = PROT_READ | PROT_WRITE;
    int iFd = -1; /* 打开内存设备的文件描述符 */
    int ret = 0;
    char* pVirAddr = NULL;
#ifdef __aarch64__
    if ((iFd = open("/dev/memnc", O_RDWR | O_SYNC)) >= 0)
#else
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) >= 0)
#endif
    {
        pVirAddr = mmap(NULL, size, iSpaceProt, MAP_SHARED, iFd, phyAddr);
        ret = close(iFd);
        if(ret !=0)
        {
            printf("close fd handle error!!\n");
        }

        if (pVirAddr == MAP_FAILED)
        {            
            printf("%s>>ParamAddr(Phy'%lu ): Open /dev/mem Error!\n",__FUNCTION__, phyAddr);
            *pVirAddr = 0;
            return -1;
        }
        *ppVirAddr = pVirAddr;

    }
    else
    {
        printf("open mem device error!\n");
        return -1;
    }
    /*printf("%s successful! >>(Phy'%lu  Vir'%p)\n",__FUNCTION__, phyAddr,pVirAddr);*/
    return 0;
}

static uint32_t BspGetDpd4Id(void)
{
    char   *pBaseAddr = NULL;
    uint32_t  ulRpuId = 0;

    if(0 == BspDoMemMap(0xD4B00000,0x1000,&pBaseAddr))
    {
        char* pAddr = pBaseAddr + 0x64;
        ulRpuId = *(volatile uint32_t*)(uintptr_t)pAddr;
        munmap((void*)pBaseAddr, 0x1000);
    }
    return (ulRpuId & 0x3);
}
static uint32_t GetRpuIp(char *ip,uint32_t size)
{
    uint32_t rpuId = BspGetDpd4Id();
    if (ip)
    {
        snprintf(ip,size,"198.33.33.%d",rpuId+2);
    }
    return (198<<24)|(33<<16)|(33<<8)|(rpuId+2);
}

static uint32_t CfgNetAddr(void)
{
    uint32_t retVal = 0;
    uint8_t  mac[6]={0x40,0x00,0xC6,0x21,0x21,0x01};

    uint8_t  ip[4]={198,33,33,1};
    uint8_t  mask[4]={0xff,0,0,0};
    uint8_t  netif[8] = "eth0";
    uint32_t tempip = GetRpuIp(NULL,0);
    mac[5] = (uint8_t)(tempip);

    ip[0] = (uint8_t)(tempip >> 24);
    ip[1] = (uint8_t)(tempip >> 16);
    ip[2] = (uint8_t)(tempip >> 8);
    ip[3] = (uint8_t)(tempip >> 0);
    
    char cmd[128] = {0};
    sprintf(cmd, "ifconfig %s down", netif);
    printf("%s\n",cmd);
    system(cmd);

    sprintf(cmd, "ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
        mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
    printf("%s\n",cmd);
    system(cmd);

    sprintf(cmd,"ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d",netif, ip[0],ip[1],ip[2],ip[3],
                mask[0],mask[1],mask[2],mask[3]);
    printf("%s\n",cmd);
    system(cmd);

    if (BspGetDpd4Id() == 1 || BspGetDpd4Id() == 3)
    {
        system("route add -net 198.33.33.100 netmask 255.255.255.255 gw 198.33.33.101 eth0");
        system("route add -net 198.33.31.100 netmask 255.255.255.255 gw 198.33.33.101 eth0"); //增加AC DSP路由
        system("route add -net 199.33.0.0 netmask 255.255.0.0 gw 198.33.33.101 eth0");
    }
    else
    {
        system("route add -net 199.33.0.0 netmask 255.255.0.0 gw 198.33.33.100 eth0");
    }

    return retVal;
}


int  main()
{
    CfgNetAddr();
    printf("hello\n");
    return 0;
}

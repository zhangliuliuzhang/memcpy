#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <inttypes.h>
/**************************************************************************
 *                        宏
 **************************************************************************/
#define GPIO_GROUP_MAX                 (1)
#define GPIO_MMAP_INITED               (uint32_t)(1)
#define ONE_REG_MAX_GPIO               (uint32_t)(16)

#define GPIO_MODE_OUTPUT               (0x00)            // 输出模式
#define GPIO_MODE_INPUT                (0x01)            // 输入模式
#define GPIO_MODE_INT                  (0x02)            // 中断模式

#define ZX211413_GPIO_REGS_SIZE        (0x1000)
#define ZX211413_GPIO_PORT_SIZE        (0x40)
#define ZX211413_GPIO_PORT_MAX         (128)

#define GPIO_CMODE_LEVEL_HIGH       0x00         /*高电平采集  */
#define GPIO_CMODE_LEVEL_LOW        0x10         /*低电平采集  */
#define GPIO_CMODE_EDGE_UP          0x20         /*上升沿平采集*/
#define GPIO_CMODE_EDGE_DOWN        0x40         /*下降沿采集  */
#define GPIO_CMODE_EDGE             0x80         /*全边缘采集  */


#define INPUT_PORT_CHECK(port)                                  \
    if(port >= ZX211413_GPIO_PORT_MAX)                          \
    {                                                           \
        printf("ERROR: [ic4.2] The pin range is 0 ~ 127 !\n"); \
        return (-1);                                       \
    }

/* 指定数据中的位域值置1 */
#define BIT_FIELD_MASK_SET(bitoff, numbit)  (((0x01 << (numbit)) - 1) << (bitoff))

/* 指定数据中的位域值清0 */
#define BIT_FIELD_MASK_CLR(bitoff, numbit)  (~(BIT_FIELD_MASK_SET(bitoff, numbit)))

#define BITS_FIELD_CFG(Var, CfgVal, bitoff, numbit)                      \
    (((Var) & BIT_FIELD_MASK_CLR(bitoff, numbit)) |                      \
    (((CfgVal) << (bitoff)) & BIT_FIELD_MASK_SET(bitoff, numbit)))

/* 从指定变量或数据中提取出指定位域的数据，并把该位域值右对齐 */
#define BITS_RIGHT_JUST_GET(val, bitoff, numbit) \
(((val) >> (bitoff)) & ((0x01 << (numbit)) - 1))

#define GPIO_SET_BIT_VAL(var, cfgVal, bit)    BITS_FIELD_CFG((var), (cfgVal), bit, 1)/* 修改1bit位的值 */
#define GPIO_GET_BIT_VAL(var, bit)            BITS_RIGHT_JUST_GET((var), bit, 1)/* TX传输FIFO中的有效数据量 */

enum eGpioRegisters {
    GPIO_DIRECTION          = 0x00,          /*输入输出     0 : input  1 : output   */
    GPIO_COLLECT_MODE       = 0x04,          /*数据采集模式 0 为边缘采集    1为电平采集        */
    GPIO_COLLECT_VOLT       = 0x08,          /*电平采集模式 0 为低电平采集  1 为高电平采集*/
    GPIO_COLLECT_POSEDGE    = 0x0C,          /*上升沿采集模式使能 0 为失能  1为使能              */
    GPIO_COLLECT_NEGEDGE    = 0x10,          /*下降沿采集模式使能 0 为失能  1为使能              */
    GPIO_INPUT_DATA         = 0x14,          /*R 输入数据, 存储 GPIO 端口输入数据            */
    GPIO_OUTPUT_SET1        = 0x18,          /*发送数据1                         */
    GPIO_OUTPUT_SET0        = 0x1C,          /*发送数据0                         */
    GPIO_OUTPUT_DATA        = 0x20,          /*R 发送数据的值                                                    */
    GPIO_INPUT_CLEAR        = 0x24,          /*输入数据清零 1 清零          0 禁止清零             */
    GPIO_INT_MASK           = 0x28,          /*中断屏蔽     1 禁止中断输出  0 允许中断输出  */
    GPIO_INT_ENABLE         = 0x2C,          /*R 中断状态                                                            */
    GPIO_INT_STATUS         = 0x30,          /*中断清零     1 清零          0 不清零                     */
    GPIO_INT_CLEAR          = 0x34,          /*使整个结构体占据 0x40 的空间                         */

    GPIO_OUTPUT_SET1_48V    = 0x58,          /*发送数据1                         */
    GPIO_OUTPUT_SET0_48V    = 0x5C,          /*发送数据0                         */
    GPIO_OUTPUT_DATA_48V    = 0x60,          /*R 发送数据的值                                         */
};

static char *s_gpioBaseAddr = NULL;
/**************************************************************************
* 函数名称: BspDoMemMap
* 功能描述: 虚拟地址映射
* 输入参数: phyAddr       :物理地址
*          size          :申请空间大小
* 输出参数: pVirAddr      :虚拟地址
* 返 回 值: 没存映射成功返回0 ，否则返回-1
* 其它说明: @2026-02-14 宋志强10099236 简化映射，自动判断32bit/64bit
*----------------------------------------------------------------------------*/
static int BspDoMemMap(off_t phyAddr, size_t size, char** ppVirAddr)
{
    int iSpaceProt = PROT_READ | PROT_WRITE;
    int iFd = -1; /* 打开内存设备的文件描述符 */
    int ret = 0;
    char* pVirAddr = NULL;
#ifdef __aarch64__
    if ((iFd = open("/dev/memnc", O_RDWR | O_SYNC)) >= 0)
#else
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) >= 0)
#endif
    {
        pVirAddr = mmap(NULL, size, iSpaceProt, MAP_SHARED, iFd, phyAddr);
        ret = close(iFd);
        if(ret !=0)
        {
            printf("close fd handle error!!\n");
        }

        if (pVirAddr == MAP_FAILED)
        {            
            printf("%s>>ParamAddr(Phy'%lu ): Open /dev/mem Error!\n",__FUNCTION__, phyAddr);
            *pVirAddr = 0;
            return -1;
        }
        *ppVirAddr = pVirAddr;

    }
    else
    {
        printf("open mem device error!\n");
        return -1;
    }
    /* printf("%s successful! >>(Phy'%lu  Vir'%p)\n",__FUNCTION__, phyAddr,pVirAddr);*/
    return 0;
}
/* Started by AICoder, pid:f2d5ct95a9q75c01410f0b2fe3079335e3e1d94b */
static uint32_t zx211413InputParaProcess(uint32_t port, uint32_t *portBase, uint32_t *bit)
{

    *portBase = (uint32_t)((port / ONE_REG_MAX_GPIO) * ZX211413_GPIO_PORT_SIZE);
    *bit      = (uint32_t)(port % ONE_REG_MAX_GPIO);
    return 0;
}

static uint32_t zx211413GetGpioReg(uint32_t offset, uint32_t *regVal)
{
    void* gpioAddr = 0;
    if(NULL == s_gpioBaseAddr)
    {
        return (-1);
    }
    gpioAddr = s_gpioBaseAddr + offset;
    *regVal = *(volatile uint32_t *)(gpioAddr);

    return 0;
}

static uint32_t zx211413SetGpioReg(uint32_t offset, uint32_t regVal)
{
    void* gpioAddr = 0;

    if(NULL == s_gpioBaseAddr)
    {
        return (-1);
    }

    gpioAddr = s_gpioBaseAddr + offset;
    *(volatile uint32_t *)(gpioAddr) = regVal;

    return 0;
}

static uint32_t zx211413SetGpioRegBit(uint32_t addr, uint32_t bit, uint32_t isHigh)
{
    uint32_t retVal = 0;
    uint32_t regVal = 0;

    /*默认将大于等于1的值都配置成1*/
    isHigh = isHigh ? 1 : 0;

    retVal = zx211413GetGpioReg(addr, &regVal);
    regVal = GPIO_SET_BIT_VAL(regVal, isHigh, bit);
    retVal |= zx211413SetGpioReg(addr,regVal);

    return retVal;
}

static uint32_t zx211413GetGpioRegBit(uint32_t addr, uint32_t bit)
{
    uint32_t regVal = 0;

    zx211413GetGpioReg(addr, &regVal);
    regVal = GPIO_GET_BIT_VAL(regVal, bit);

    return regVal;
}


static uint32_t zx211413GpioSetCollectMode(uint32_t port, uint32_t mode)
{
    uint32_t retVal          = 0;
    uint32_t bit             = 0;
    uint32_t portBase        = 0;

    INPUT_PORT_CHECK(port);
    retVal |= zx211413InputParaProcess(port, &portBase, &bit);

    switch((mode & 0xF0))
    {
        case GPIO_CMODE_LEVEL_HIGH:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_MODE, bit, 1);   /* 电平采集模式  */
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_VOLT, bit, 1);   /* 高电位采集模式 */
            break;
        case GPIO_CMODE_LEVEL_LOW:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_MODE, bit, 1);   /* 电平采集模式  */
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_VOLT, bit, 0);   /* 低电位采集模式  */
            break;
        case GPIO_CMODE_EDGE_UP:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_MODE, bit, 0);    /* 边缘采集模式  */
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_POSEDGE, bit, 1); /* 上升沿采集使能  */
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_NEGEDGE, bit, 0); /* 下降沿采集失能  */
            break;
        case GPIO_CMODE_EDGE_DOWN:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_MODE, bit, 0);    /* 边缘采集模式   */
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_POSEDGE, bit, 0); /* 上升沿采集失能 */
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_NEGEDGE, bit, 1); /* 下降沿采集使能*/
            break;
        /*该模式不确定是否适用，使用前和硬件确认*/
        case GPIO_CMODE_EDGE:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_MODE, bit, 0);    /* 边缘采集模式   */
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_POSEDGE, bit, 1); /* 上升沿采集使能*/
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_COLLECT_NEGEDGE, bit, 1); /* 下降沿采集使能*/
            break;
        default:
            break;
    }

    return retVal;
}

uint32_t _BspZteGpioSetMode(uint32_t port, uint32_t mode)
{
    uint32_t retVal          = 0;
    uint32_t bit             = 0;
    uint32_t portBase        = 0;

    printf("%s, port=%u,mode=%u\n", __func__, port, mode);
    INPUT_PORT_CHECK(port);
    retVal |= zx211413InputParaProcess(port, &portBase, &bit);

    // BspGpioSemTake();

    switch(mode & 0x0F)
    {
        case GPIO_MODE_OUTPUT:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_DIRECTION  , bit, 1);
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_INT_ENABLE , bit, 0);
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_OUTPUT_DATA, bit, 0);
            break;
        case GPIO_MODE_INPUT:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_DIRECTION , bit, 0);
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_INT_ENABLE, bit, 0);
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_INPUT_CLEAR, bit, 1);
            break;
        case GPIO_MODE_INT:
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_DIRECTION , bit, 0);
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_INT_CLEAR , bit, 1);
            retVal |= zx211413SetGpioRegBit(portBase + GPIO_INT_ENABLE, bit, 1);
            break;
        default:
            break;
    }

    retVal |= zx211413GpioSetCollectMode(port, mode);

    // BspGpioSemGive();

    return retVal;

}

uint32_t _BspZteGpioGet(uint32_t port)
{
    uint32_t regBitVal       = 0;
    uint32_t bit             = 0;
    uint32_t portBase        = 0;

    INPUT_PORT_CHECK(port);
    zx211413InputParaProcess(port, &portBase, &bit);

    // BspGpioSemTake();

    regBitVal = zx211413GetGpioRegBit(portBase + GPIO_INPUT_DATA, bit);

    // BspGpioSemGive();

    return regBitVal;
}

static uint32_t BspGetDpdicGpioData(uint32_t gpioIndex)
{
    uint32_t gpioData = 0;

    if (0 == BspDoMemMap(0xD6400000, 0x1000, &s_gpioBaseAddr))
    {
        if( 0 == _BspZteGpioSetMode(gpioIndex,1) ) //Gpio_0为输入模式
        {
            gpioData = _BspZteGpioGet(gpioIndex);//读Gpio_0的输入
            printf("%s gpioData %u\n", __FUNCTION__, gpioData);
            if((-1) == gpioData)
            {
                gpioData = 0;
            }
        }
        if(NULL != s_gpioBaseAddr)
        {
            munmap((void*)s_gpioBaseAddr, 0x1000);
        }
        s_gpioBaseAddr = NULL;
        return gpioData;
    }

    return gpioData;
}

static uint32_t BspSetDpdicPadGpio0(void)//设置GPIO_0为GPIO模式
{
    char   *pBaseAddr = NULL;
    uint32_t  cfg = 0;

    if (0 == BspDoMemMap(0xC1100000, 0x1000, &pBaseAddr))
    {
        char* pAddr = pBaseAddr + 0x0188;//GPIO_0的偏移
        cfg = *(volatile uint32_t*)(uintptr_t)pAddr;
        printf("%s cfg0 0x%08X\n", __FUNCTION__, cfg);

        cfg = GPIO_SET_BIT_VAL(cfg, 0, 9);//给bit9写0
        *(volatile uint32_t*)(uintptr_t)pAddr = cfg;

        printf("%s cfg1 0x%08X\n", __FUNCTION__, cfg);

        munmap((void*)pBaseAddr, 0x1000);
        return 0;
    }

    return (-1);
}
/* Ended by AICoder, pid:f2d5ct95a9q75c01410f0b2fe3079335e3e1d94b */
static uint32_t BspGetDpdicRpuId(void)
{
    char   *pBaseAddr = NULL;
    uint32_t  ulRpuId = 0;

    if (0 == BspDoMemMap(0xD4B00000, 0x1000, &pBaseAddr))
    {
        char* pAddr = pBaseAddr + 0x64;
        ulRpuId = *(volatile uint32_t*)(uintptr_t)pAddr;
        munmap((void*)pBaseAddr, 0x1000);
    }
    else
    {
        return 0;
    }

    return (ulRpuId & 0x7);
}

static unsigned int GetRpuIp(char *ip,unsigned int size)
{
    unsigned int rpuId = BspGetDpdicRpuId();
    if (ip)
    {
        snprintf(ip,size,"198.33.33.%d",rpuId+2);
    }
    return (198<<24)|(33<<16)|(33<<8)|(rpuId+2);
}

static uint32_t CfgNetAddr(void)
{
    uint32_t retVal = 0;
    //UINT8  mac[6]={0x00,0x01,0x0C,0x01,0x0F,0x01};
    uint8_t  mac[6]={0x40,0x00,0xC6,0x21,0x21,0x01};

    uint8_t  ip[4]={198,33,33,1};
    //UINT8  mask[4]={0xff,0xff,0xff,0};
    uint8_t  mask[4]={0xff,0,0,0};
    uint8_t  netif[8] = "eth0";
    uint32_t tempip = GetRpuIp(NULL,0);
    mac[5] = (uint8_t)(tempip);

    ip[0] = (uint8_t)(tempip >> 24);
    ip[1] = (uint8_t)(tempip >> 16);
    ip[2] = (uint8_t)(tempip >> 8);
    ip[3] = (uint8_t)(tempip >> 0);
    
    char cmd[128] = {0};
    sprintf(cmd, "ifconfig %s down", netif);
    printf("%s\n",cmd);
    system(cmd);
    sprintf(cmd, "ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
        mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
    printf("%s\n",cmd);

    system(cmd);
    sprintf(cmd,"ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d",netif, ip[0],ip[1],ip[2],ip[3],
                mask[0],mask[1],mask[2],mask[3]);
    printf("%s\n",cmd);
    system(cmd);

    if (BspGetDpdicRpuId() == 1)
    {
        system("route add -net 199.33.0.0 netmask 255.255.0.0 gw 198.33.33.100 eth0");
        if(0 == BspSetDpdicPadGpio0() && 1 == BspGetDpdicGpioData(0))
        {
            system("route add -net 198.33.33.100 netmask 255.255.255.255 gw 198.33.33.101 eth0");
            system("route add -net 198.33.31.100 netmask 255.255.255.255 gw 198.33.33.101 eth0");
        }
    }
    else
    {
        system("route add -net 199.33.0.0 netmask 255.255.0.0 gw 198.33.33.100 eth0");
    }

    return retVal;
}


int  main()
{
    CfgNetAddr();
    return 0;
}

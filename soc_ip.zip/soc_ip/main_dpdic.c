#include "stdio.h"
#include "bsppub.h"
#include <stdint.h>

static UINT32 DpdIcDoMemMap(UCHAR* uPhyAddr,UINT32 uSize,UCHAR **pVirAddr)
{
    /* 打开内存设备的文件描述符 */
    int     iSpaceProt = PROT_READ | PROT_WRITE;
    int     iFd = 0;
    if ((iFd = open("/dev/mem", O_RDWR | O_SYNC)) > 0)
    {
	    *pVirAddr = (UCHAR*)mmap(0,uSize,iSpaceProt, MAP_SHARED, iFd, (UINT32)uPhyAddr);
        if (*pVirAddr == (UCHAR*)-1)
        {
            close(iFd);
            *pVirAddr = 0;
            printf("%s>>mmap failed !\n",__FUNCTION__);
            return BSP_ERROR;
        }
    	close(iFd);
    }
    else
    {
        printf("open /dev/mem failed\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}
static uint32_t BspGetDpdIcRpuId(void)
{
    UCHAR    * pBaseAddr = NULL;
    UINT32    ulRpuId = 0;
    UCHAR    * pAddr = NULL;
    UCHAR    *pPhyAddr = (UCHAR *)0xC5B00000;

    if(BSP_OK == DpdIcDoMemMap(pPhyAddr,0x1000,&pBaseAddr))
    {
        pAddr = pBaseAddr+0x228;
        ulRpuId = (UINT32)*(volatile UINT32*)pAddr;
    }
    return ((ulRpuId & 0xF)>>0x1);
}
static UINT32 GetRpuIp(char *ip,uint32_t size)
{
    uint32_t rpuId = BspGetDpdIcRpuId();
    if (ip)
    {
        snprintf(ip,size,"198.33.33.%d",rpuId+2);
    }
    return (198<<24)|(33<<16)|(33<<8)|(rpuId+2);
}

static UINT32 CfgNetAddr(VOID)
{
    UINT32 retVal = 0;
    //UINT8  mac[6]={0x00,0x01,0x0C,0x01,0x0F,0x01};
    UINT8  mac[6]={0x40,0x00,0xC6,0x21,0x21,0x01};

    UINT8  ip[4]={198,33,33,1};
    //UINT8  mask[4]={0xff,0xff,0xff,0};
    UINT8  mask[4]={0xff,0,0,0};
    UINT8  netif[8] = "eth0";
    UINT32 tempip = GetRpuIp(NULL,0);
    mac[5] = (UINT8)(tempip);

    ip[0] = (UINT8)(tempip >> 24);
    ip[1] = (UINT8)(tempip >> 16);
    ip[2] = (UINT8)(tempip >> 8);
    ip[3] = (UINT8)(tempip >> 0);
    
    char cmd[128] = {0};
    sprintf(cmd, "ifconfig %s down", netif);
    printf("%s\n",cmd);
    system(cmd);
    sprintf(cmd, "ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
        mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
    printf("%s\n",cmd);

    system(cmd);
    sprintf(cmd,"ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d",netif, ip[0],ip[1],ip[2],ip[3],
                mask[0],mask[1],mask[2],mask[3]);
    printf("%s\n",cmd);
    system(cmd);

    system("route add -net 199.33.0.0 netmask 255.255.0.0 gw 198.33.33.100 eth0");
    return retVal;
}


int  main()
{
    CfgNetAddr();
    printf("hello\n");
    return 0;
}

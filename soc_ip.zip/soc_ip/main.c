#include "stdio.h"
#include "bsppub.h"
#include "zynqusgpio.h"

// 获取rpuid
static UINT32 BspGetSocRpuId(VOID)
{
    unsigned regVal = 0;
    //BspRegRd(0, REG_RPU_ID, 0, &regVal);
    BspZynqGpioSetMode(0,11,ZYNQ_GPIO_MODE_INPUT);
    BspZynqGpioSetMode(0,12,ZYNQ_GPIO_MODE_INPUT);
    BspZynqGpioSetMode(0,13,ZYNQ_GPIO_MODE_INPUT);
    UCHAR id0 = BspZynqGpioGet(0,11);
    UCHAR id1 = BspZynqGpioGet(0,12);
    UCHAR id2 = BspZynqGpioGet(0,13);
    regVal = (id2 << 2) | (id1 << 1) | id0;
    return regVal & 0x7;
}


static UINT32 GetRpuIp(char *ip,UINT32 size)
{
    UINT32 rpuId = BspGetSocRpuId();
    if (ip)
    {
        snprintf(ip,size,"198.33.33.%d",rpuId+2);
    }
    return (198<<24)|(33<<16)|(33<<8)|(rpuId+2);
}

static UINT32 CfgNetAddr(VOID)
{
    UINT32 retVal = 0;
    //UINT8  mac[6]={0x00,0x01,0x0C,0x01,0x0F,0x01};
    UINT8  mac[6]={0x40,0x00,0xC6,0x21,0x21,0x01};

    UINT8  ip[4]={198,33,33,1};
    //UINT8  mask[4]={0xff,0xff,0xff,0};
    UINT8  mask[4]={0xff,0,0,0};
    UINT8  netif[8] = "eth0";
    UINT32 tempip = GetRpuIp(NULL,0);
    mac[5] = (UINT8)(tempip);

    ip[0] = (UINT8)(tempip >> 24);
    ip[1] = (UINT8)(tempip >> 16);
    ip[2] = (UINT8)(tempip >> 8);
    ip[3] = (UINT8)(tempip >> 0);
    
    char cmd[128] = {0};
    sprintf(cmd, "ifconfig %s down", netif);
    printf("%s\n",cmd);
    system(cmd);
    sprintf(cmd, "ifconfig %s hw ether %02X:%02X:%02X:%02X:%02X:%02X", netif,
        mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]);
    printf("%s\n",cmd);

    system(cmd);
    sprintf(cmd,"ifconfig %s %d.%d.%d.%d netmask %d.%d.%d.%d",netif, ip[0],ip[1],ip[2],ip[3],
                mask[0],mask[1],mask[2],mask[3]);
    printf("%s\n",cmd);
    system(cmd);

    system("route add -net 199.33.0.0 netmask 255.255.0.0 gw 198.33.33.100 eth0");
    return retVal;
}


int  main()
{
    BspZynqGpioInit();

    CfgNetAddr();
    printf("hello\n");
    return 0;    
}

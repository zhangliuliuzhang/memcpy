/************************************************/
/**
 * \file main.c
 * \brief main
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include <string.h>
#include <stdarg.h>
#include <stdio.h>

#include "gd32f4xx.h"
#include "common.h"
#include "typedef.h"
#include "uartprint.h"
#include "utils.h"
#include "wdt_config.h"
#include "hal_flash.h"
#include "hal_uart.h"

#include "gpio_config.h"
#include "uart_config.h"
#include "timer_config.h"

#include "app_upgrade.h"
#include "app_download.h"

/******************************************************************
*                        宏定义
******************************************************************/

/******************************************************************
*                        数据类型
******************************************************************/
typedef  void (*pFunction)(void);
/******************************************************************
*                         全局变量定义
******************************************************************/
pFunction Jump_To_Application;
/******************************************************************
*                         外部变量声明
******************************************************************/

/******************************************************************
*                         局部函数声明
******************************************************************/

/******************************************************************
*                         函数实现
******************************************************************/

/**
  * @brief  This function jump to app code.
  * @param  None
  * @retval SUCCESS or ERROR
  */
VOID JumpToApp(UINT32 Address)
{
    UINT32 JumpAddress;
    __disable_irq();
    JumpAddress = *(__IO uint32_t*) (Address + 4);
    Jump_To_Application = (pFunction) JumpAddress;
    __set_MSP(*(__IO uint32_t*) Address);
    __disable_irq();

    Jump_To_Application();
}

/**
  * @brief  This function handle error status.
  * @param  None
  * @retval SUCCESS or ERROR
  */
VOID errorCode(VOID)
{
    UARTprintf("Enter Error Code!\r\n");
    zxUTILS_DelayNms(100);
    NVIC_SystemReset();
    while(1)
    {

    }
}

/**********************************************************************/
/**
  * \brief 初始化硬件设备
  *
  * \param none
  *
  * \retval none
  */
/**********************************************************************/
VOID InitHard(VOID)
{
    __enable_irq();
    nvic_priority_group_set(NVIC_PRIGROUP_PRE2_SUB2);
    nvic_vector_table_set(NVIC_VECTTAB_FLASH, NVIC_VECTOR_TABLE_OFFSET);

    zxDRV_InitNormalGpio();
    zxDRV_InitUart();
    zxDRV_InitTimer();
    zxDRV_InitWdt();
    InitFwUpgradeInfoFromInterFlash();
}

int main(void)
{
    UINT32 appRunSta = 0;

    /* 二级boot启动到APP起来之间控制RUN灯慢闪 */
    BspSetRunLedState(LED_RUN_SLOW_STA);

    InitHard();
    UARTprintf("Boot Version:V1.1.02\r\n");

    /*  InitHard结束，就认为二级boot不存在问题 */
    UARTprintf("second boot run flag is %d\r\n", GetSecondBootRunStatus());
    SetSecondBootRunStatus(E_FW_RUN_NORMAL); //lhf modify

    /* ============================== app ============================== */
    /* 版本监控异常流程 该流程暂时没用到，后续考虑是否保留*/
    if (E_DOWNLOADING == GetUpgradeStatus() || E_CHECK_ERR == GetUpgradeStatus())
    {
        /* 版本下载流程中异常重启 */
        UARTprintf("mcu upgrade status -> %d\r\n", GetUpgradeStatus());
        /* 擦除下载区版本,将主区版本复制到备区，这块是否考虑epld版本？？ */
        HalFlashDataMove(APP_UPGRADE_SECTOR_START, APP_UPGRADE_SECTOR_END, APP_UPGRADE_ADDR, APP_RUN_ADDR, APP_LENTH);
        SetUpgradeStatus(E_WAIT_FOR_DOWNLOAD);
        BspSetUpAreaStatus(E_SET);
        JumpToApp(APP_RUN_ADDR);
    }

    /* 版本回退流程 */
    if (E_SET == GetRevertFlag())
    {
        if(E_SET == GetAppRevertFwStatus())     /*状态判断成立，再进行版本搬运*/
        {
            UARTprintf("mcu fireware revert!\r\n");
            RevertFwVersion();
            JumpToApp(APP_RUN_ADDR);
        }
        else
        {
            BspResetRevAndUpdataSta();
        }
    }

    /* 版本升级流程 */
    if (E_SET == GetUpgradeFlag())
    {
        if (E_SET == GetAppUpFwStatus())//lhf
        {
            UARTprintf("mcu fireware updata!\r\n");
            UpgradeFwVersion();
            JumpToApp(APP_RUN_ADDR);
        }
        else
        {
            BspResetUpdataSta();
        }
    }

    /* 主备区流程 */
    appRunSta = GetAppRunStatus();
    UARTprintf("app run sta = %d\n", appRunSta);
    if(E_FW_RUN_NORMAL != appRunSta)
    {
        //回滚区和升级区来回乒乓
        if((appRunSta == E_FW_RUN_MAIN_VER) || (appRunSta == E_FW_RUN_REVERT_VER))
        {
            SetAppRunStatus(E_FW_RUN_BACKUP_VER);
            if (E_SET == GetAppUpFwStatus())
            {
                UARTprintf("\r\nrun app backup fw!\r\n");
                SetupBackupAppFw();
            }
        }
        else if(appRunSta == E_FW_RUN_BACKUP_VER)
        {
            SetAppRunStatus(E_FW_RUN_REVERT_VER);
            if(E_SET == GetAppRevertFwStatus())
            {
                UARTprintf("\r\nrun app revert fw!\r\n");
                SetupRevertAppFw();
            }
        }
    }
    else
    {
        SetAppRunStatus(E_FW_RUN_MAIN_VER);
    }

    /* fw download manage */
    DownloadFireware();

    zxDRV_FeedWdt();
    JumpToApp(APP_RUN_ADDR);

    return 0;
}

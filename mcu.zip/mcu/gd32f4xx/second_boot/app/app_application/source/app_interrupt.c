/************************************************/
/**
 * \file interrupt.c
 * \brief �ж�ʵ���ļ�
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "app_interrupt.h"

#include "uartprint.h"
#include "utils.h"

#include "hal_timer.h"
#include "gpio_config.h"
#include "wdt_config.h"

#include "app_download.h"
#include "common.h"

volatile static UINT32 delay;

/**********************************************************************/
/**
  * \brief     zxDRV_SystickISR
  *
  * \param null
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_SystickISR(VOID)
{
}

/**********************************************************************/
/**
  * \brief     zxDRV_DelayNs
  *
  * \param count:延时值
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_DelayNs(UINT32 count)
{
    delay = count * 2;

    while(0U != delay);
}

/**********************************************************************/
/**
  * \brief     zxDRV_Timer1ISR
  *
  * \param null
  *
  * \retval null
  */
/**********************************************************************/
static BYTE s_nextSlowRunLedSta = 0;
static VOID LedCtrlBy1ISR(VOID)
{
    UINT32 runLedState = 0;

    runLedState = BspGetRunLedState();
    if(runLedState == LED_RUN_SLOW_STA)
    {
        if(s_nextSlowRunLedSta == LED_SWITCH_ON)
        {
            runLedCtrl(LED_SWITCH_ON);
            s_nextSlowRunLedSta = LED_SWITCH_OFF;
        }
        else
        {
            runLedCtrl(LED_SWITCH_OFF);
            s_nextSlowRunLedSta = LED_SWITCH_ON;
        }
    }
}

VOID zxDRV_Timer1ISR(VOID)
{
    if(E_SET == HalGetTimerIntFlag(TIMER1, TIMER_INT_FLAG_UP))
    {
        HalClearTimerIntFlag(TIMER1, TIMER_INT_FLAG_UP);

        zxDRV_FeedWdt();

        LedCtrlBy1ISR();

        if (0U != delay)
        {
            delay--;
        }
    }
}

/**********************************************************************/
/**
  * \brief     UART4 串口中断挂接
  *
  * \param null
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_Uart4ISR(VOID)
{
    BYTE recvDataByte = 0;

    if(RESET != usart_interrupt_flag_get(UART4, USART_INT_FLAG_RBNE))
    {
        usart_interrupt_flag_clear(UART4, USART_INT_FLAG_RBNE);

        recvDataByte = usart_data_receive(UART4);
        ParseUartRecvByte(recvDataByte);

  }
    if(RESET != usart_interrupt_flag_get(UART4, USART_INT_FLAG_IDLE))
    {
        usart_interrupt_flag_clear(UART4,USART_INT_FLAG_IDLE);
        usart_data_receive(UART4);

        HandleUartCompleteEvent();
    }
}

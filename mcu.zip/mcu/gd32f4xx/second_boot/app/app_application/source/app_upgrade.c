/************************************************/
/**
 * \file app_upgrade.c
 * \brief 版本升级文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include <string.h>
#include "app_upgrade.h"
#include "hal_flash.h"
#include "common.h"
#include "utils.h"
#include "uartprint.h"
#include "wdt_config.h"

const char *s_secBootVersion = "V1.1.02";
static T_fwUpgradeInfo st_fwUpgradeInfo = {0};

/**
  * @brief  get fireware config info from internal flash.
  * @param  none
  * @retval fireware config info
  */
UINT32 InitFwUpgradeInfoFromInterFlash(VOID)
{
    UINT8 cmpFlag = 0;
  
    HalFlashRead(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));

    if(strcmp(s_secBootVersion, st_fwUpgradeInfo.secondBootVer) != 0)
    {
        cmpFlag = 1;
    }
    /* first init. set default value */
    if (st_fwUpgradeInfo.upgradeSta == 0xFFFFFFFF)
    {
        st_fwUpgradeInfo.upgradeFlg     = E_RESET;
        st_fwUpgradeInfo.revertFlg      = E_RESET;
        st_fwUpgradeInfo.bootRunFlg     = E_FW_RUN_NORMAL;
        st_fwUpgradeInfo.appRunFlg      = E_FW_RUN_NORMAL;
        st_fwUpgradeInfo.upgradeSta     = E_WAIT_FOR_DOWNLOAD;
        st_fwUpgradeInfo.appBackupFwSta = E_RESET;

        HalEraseFlashSectors(UPGRADE_INFO_SECTOR, UPGRADE_INFO_SECTOR);
        HalFlashWrite(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));
    }

    if(cmpFlag == 1)
    {
        strcpy(st_fwUpgradeInfo.secondBootVer, s_secBootVersion);
        HalFlashWrite(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));
    }

    return COMMON_OK;
}

T_fwUpgradeInfo GetFwUpgradeInfo(VOID)
{
    return st_fwUpgradeInfo;
}

/**
  * @brief  updata fireware config info to internal flash.
  * @param  none
  * @retval fireware config info
  */
VOID FlushFwUpgradeInfoToInterFlash(VOID)
{
    HalEraseFlashSectors(UPGRADE_INFO_SECTOR, UPGRADE_INFO_SECTOR);
    HalFlashWrite(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));
}

/**
  * @brief  set fw run status
  * @param  eRunStatus status
  * @retval none
  */
VOID SetSecondBootRunStatus(E_FW_RUN_STATUS eRunStatus)
{
    st_fwUpgradeInfo.bootRunFlg = eRunStatus;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  get fw run status
  * @param  eRunStatus status
  * @retval none
  */
E_FW_RUN_STATUS GetSecondBootRunStatus(VOID)
{
    return st_fwUpgradeInfo.bootRunFlg;
}

/**
  * @brief  将备区BOOT版本搬移至运行区，并进行运行
  * @param  none
  * @retval none
  */
UINT32 SetupBackupSecondBootFw(VOID)
{
    SetSecondBootRunStatus(E_FW_RUN_BACKUP_VER);
    zxDRV_FeedWdt();
    HalFlashDataMove(SECOND_BOOT_RUN_SECTOR, SECOND_BOOT_RUN_SECTOR, SECOND_BOOT_RUN_ADDR, SECOND_BOOT_MAIN_ADDR, SECOND_BOOT_LENTH);

    return COMMON_OK;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
VOID BspResetRevAndUpdataSta()
{
    st_fwUpgradeInfo.revertFlg = E_RESET;
    st_fwUpgradeInfo.upgradeFlg = E_RESET;
    st_fwUpgradeInfo.upgradeSta = E_UPGRADE_ERR;
    FlushFwUpgradeInfoToInterFlash();
}

VOID BspResetUpdataSta()
{
    st_fwUpgradeInfo.upgradeFlg = E_RESET;
    st_fwUpgradeInfo.upgradeSta = E_UPGRADE_ERR;
    FlushFwUpgradeInfoToInterFlash();
}
/**
  * @brief  设置升级标志位
  * @param  flg 
  * @retval none
  */
VOID SetUpgradeFlag(UINT32 flg)
{
    st_fwUpgradeInfo.upgradeFlg = flg;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取升级标志位
  * @param  eRunStatus status
  * @retval none
  */
UINT32 GetUpgradeFlag(VOID)
{
    return st_fwUpgradeInfo.upgradeFlg;
}

/**
  * @brief  设置回滚标志位
  * @param  flg 
  * @retval none
  */
VOID SetRevertFlag(UINT32 flg)
{
    st_fwUpgradeInfo.revertFlg = flg;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取回滚标志位
  * @param  eRunStatus status
  * @retval none
  */
UINT32 GetRevertFlag(VOID)
{
    return st_fwUpgradeInfo.revertFlg;
}

/**
  * @brief  设置APP运行状态
  * @param  eRunStatus status
  * @retval none
  */
VOID SetAppRunStatus(E_FW_RUN_STATUS eRunStatus)
{
    st_fwUpgradeInfo.appRunFlg = eRunStatus;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取APP运行状态
  * @param  eRunStatus status
  * @retval none
  */
E_FW_RUN_STATUS GetAppRunStatus(VOID)
{
    return st_fwUpgradeInfo.appRunFlg;
}

/**
  * @brief  设置APP升级版本状态
  * @param  status status
  * @retval none
  */
VOID BspSetUpAreaStatus(UINT32 status)
{
    st_fwUpgradeInfo.appBackupFwSta = status;
    FlushFwUpgradeInfoToInterFlash();
}

BOOLEAN IsAppUpAreaValid()
{
    UCHAR validFlag[4] = {0};

    HalFlashRead(APP_UPGRADE_ADDR, validFlag, sizeof(validFlag));
    UARTprintf("validFlag = 0x%x\n", validFlag);
    for(UINT8 loop = 0; loop < sizeof(validFlag); loop++)
    {
        if(validFlag[loop] != 0xff)
        {
            return TRUE;
        }
    }

    return FALSE;
}

BOOLEAN IsAppRevertAreaValid()
{
    UCHAR validFlag[4] = {0};

    HalFlashRead(APP_REVERT_ADDR, validFlag, sizeof(validFlag));
    for(UINT8 loop = 0; loop < sizeof(validFlag); loop++)
    {
        if(validFlag[loop] != 0xff)
        {
            return TRUE;
        }
    }

    return FALSE;
}

/* 正序CRC算法*/
UINT32 BspCaliFileCrc_PositiveSeq(UINT32 addr, UINT32 lenth)
{
    static UINT32 mcuCaliCrc = 0xffffffff;
    UINT8 data[LENTH_4K] = {0};
    UINT32 loopMax = 0;
    UINT32 loop = 0;
    UINT32 leftData = 0;

    loopMax = lenth / LENTH_4K;
    leftData = lenth % LENTH_4K;

    for(loop = 0; loop < loopMax; loop++)
    {
        HalFlashRead(addr , data, sizeof(data));
        mcuCaliCrc = CalculateCrc32(mcuCaliCrc, data, sizeof(data));
        addr += LENTH_4K;
        memset_s(data, sizeof(data), 0, LENTH_4K);
    }

    if(leftData != 0)
    {
        HalFlashRead(addr, data, leftData);
        mcuCaliCrc = CalculateCrc32(mcuCaliCrc, data, leftData);
    }

    return mcuCaliCrc;
}

/* 逆序CRC算法 */
UINT32 BspCaliFileCrc_InvertedSeq(UINT32 addr, UINT32 lenth)
{
    static UINT32 mcuCaliCrc = 0;
    UINT8 data[LENTH_4K] = {0};
    UINT32 loopMax = 0;
    UINT32 loop = 0;
    UINT32 leftData = 0;

    loopMax = lenth / LENTH_4K;
    leftData = lenth % LENTH_4K;

    for(loop = 0; loop < loopMax; loop++)
    {
        HalFlashRead(addr , data, sizeof(data));
        mcuCaliCrc = zxUTILS_Crc32(data, sizeof(data), mcuCaliCrc);
        addr += LENTH_4K;
        memset_s(data, sizeof(data), 0, LENTH_4K);
    }

    if(leftData != 0)
    {
        HalFlashRead(addr, data, leftData);
        mcuCaliCrc = zxUTILS_Crc32(data, leftData, mcuCaliCrc);
    }

    return mcuCaliCrc;
}

UINT32 BspCheckMcuVerData(UINT32 addr, UINT32 mcuLenth, UINT32 fileCrc)
{
    UINT32 mcuPosCaliCrc = 0;
    UINT32 mcuInveretCaliCrc = 0;

    mcuPosCaliCrc = BspCaliFileCrc_PositiveSeq(addr, mcuLenth);
    mcuInveretCaliCrc = BspCaliFileCrc_InvertedSeq(addr, mcuLenth);

    UARTprintf("fileCrc = 0x%x\n", fileCrc);
    UARTprintf("mcuPosCaliCrc = 0x%x\n", mcuPosCaliCrc);
    UARTprintf("mcuInveretCaliCrc = 0x%x\n", mcuInveretCaliCrc);
    if((fileCrc == mcuPosCaliCrc) || (fileCrc == mcuInveretCaliCrc))
    {
        return COMMON_OK;
    }

    return COMMON_ERROR;
}

UINT32 GetAppUpdataFwFlag(VOID)
{
    return st_fwUpgradeInfo.appBackupFwSta;
}

/**
  * @brief  获取APP备区版本状态
  * @param  none
  * @retval none
  */
    //lhf:检查APP备区尾部是否有效,
    //如果有效，校验CRC（CRC有两种，满足其中一种即认为有效）;
    //如果无效，检查标志appBackupFwSta;
UINT32 GetAppUpFwStatus(VOID)
{
    T_VerFlashInfo verInfo = {0};
    UINT32 fileCrc = 0;
    UINT32 lenth = 0;
    UINT32 addr = APP_UPGRADE_ADDR;
    UINT32 ret = 0;
    UINT16 validFlag = 0;
    UINT8 type = 0;

    if((IsAppUpAreaValid() != TRUE))
    {
        return E_RESET;
    }

    HalFlashRead(ADDR_APP_UP_INFO, (UCHAR *)&verInfo, sizeof(T_VerFlashInfo));
    fileCrc = verInfo.verCrc;
    lenth = verInfo.verLenth;
    validFlag = verInfo.validFlag;
    type = verInfo.type;
    UARTprintf("fileCrc = 0x%x\n", fileCrc);
    UARTprintf("lenth = %d\n", lenth);
    UARTprintf("validFlag = %d\n", validFlag);
    UARTprintf("type = %d\n", type);
    if((validFlag == VER_VALID_FLAG) && (lenth < APP_MAX_VER_LENTH))
    {
        if((type == MCU_OLD_TYPE) || (type == MCU_TYPE) || (type == 0xFF))
        {
            ret = BspCheckMcuVerData(addr, lenth, fileCrc);
            if(ret == COMMON_ERROR)
            {
                return E_RESET;
            }
            return E_SET;
        }
        else
        {
            return E_RESET;
        }
    }

    return st_fwUpgradeInfo.appBackupFwSta;
}

/*检测回滚区是否可用，弱化升级标志*/
UINT32 GetAppRevertFwStatus(VOID)
{
    T_VerFlashInfo verRevertInfo = {0};
    UINT32 fileCrc = 0;
    UINT32 lenth = 0;
    UINT32 addr = APP_REVERT_ADDR;
    UINT32 ret = 0;
    UINT16 validFlag = 0;
    UINT8 type = 0;

    if((IsAppRevertAreaValid() != TRUE))
    {
        return E_RESET;
    }

    HalFlashRead(ADDR_APP_REV_INFO, (UCHAR *)&verRevertInfo, sizeof(T_VerFlashInfo));
    fileCrc = verRevertInfo.verCrc;
    lenth = verRevertInfo.verLenth;
    validFlag = verRevertInfo.validFlag;
    type = verRevertInfo.type;

    if(validFlag == VER_VALID_FLAG)      /*校验标志位和版本长度*/
    {
        if(lenth >= APP_MAX_VER_LENTH)
        {
            return E_RESET;
        }
        if((type == MCU_OLD_TYPE) || (type == MCU_TYPE) || (type == 0XFF))
        {
            ret = BspCheckMcuVerData(addr, lenth, fileCrc);
            if(ret == COMMON_ERROR)
            {
                return E_RESET;
            }
            return E_SET;
        }
        else
        {
            return E_RESET;
        }
    }

    return E_SET;
}
/**
  * @brief  设置升级状态
  * @param  status 
  * @retval none
  */
VOID SetUpgradeStatus(UINT32 status)
{
    st_fwUpgradeInfo.upgradeSta = status;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取升级状态
  * @param  status 
  * @retval none
  */
UINT32 GetUpgradeStatus(VOID)
{
    return st_fwUpgradeInfo.upgradeSta;
}

/**
  * @brief  版本升级流程
  * @param  none
  * @retval none
  */
UINT32 UpgradeFwVersion(VOID)
{
    UINT32 ret = 0;
    /* 1.擦除回滚区将运行区版本搬移到回滚区 */
    zxDRV_FeedWdt();
    ret = HalFlashDataMove(APP_REVERT_SECTOR_START, APP_REVERT_SECTOR_END, APP_REVERT_ADDR, APP_RUN_ADDR, APP_LENTH);
    if(ret == COMMON_ERROR)     //lhf:搬移失败，退出，设置升级失败、清除升级标志
    {
        //SetUpgradeFlag(E_RESET);
        //SetUpgradeStatus(E_UPGRADE_ERR);//还需要设置回滚区标志 置为不可用，三个接口一起实现
        BspResetRevAndUpdataSta();
        return ret;
    }
    /* 2.置位回滚标识 */
    SetRevertFlag(E_SET);
    /* 3.将升级区版本搬移到运行区 */
    zxDRV_FeedWdt();
    ret = HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_UPGRADE_ADDR, APP_LENTH);
    if(ret == COMMON_ERROR)
    {
        BspResetUpdataSta();
        //SetUpgradeFlag(E_RESET);
        //SetUpgradeStatus(E_UPGRADE_ERR);
        zxDRV_FeedWdt();
        HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_REVERT_ADDR, APP_LENTH);

        return ret;
    }
    /* 4.清除升级标识 */
    SetUpgradeFlag(E_RESET);
    return COMMON_OK;
}

/**
  * @brief  版本回滚流程
  * @param  none
  * @retval none
  */
UINT32 RevertFwVersion(VOID)
{
    UINT32 ret = 0;

    /* 1.将回滚区版本搬移至运行区 */
    zxDRV_FeedWdt();
    ret = HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_REVERT_ADDR, APP_LENTH);
    if(ret == COMMON_OK)
    {
        BspResetRevAndUpdataSta();
    }
    /* 2.将回滚区版本搬移至升级区 */
    BspSetUpAreaStatus(E_RESET);//lhf  先设置升级区不可用
    zxDRV_FeedWdt();
    ret = HalFlashDataMove(APP_UPGRADE_SECTOR_START, APP_UPGRADE_SECTOR_END, APP_UPGRADE_ADDR, APP_REVERT_ADDR, APP_LENTH);
    if(ret == COMMON_OK)
    {
        /* 5.备区可用 */
        BspSetUpAreaStatus(E_SET);
    }

    return COMMON_OK;
}

/**
  * @brief  将备区APP版本搬移至运行区，并进行运行
  * @param  none
  * @retval none
  */
UINT32 SetupBackupAppFw(VOID)
{
    //SetAppRunStatus(E_FW_RUN_BACKUP_VER);
    zxDRV_FeedWdt();
    HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_UPGRADE_ADDR, APP_LENTH);

    return COMMON_OK;
}

UINT32 SetupRevertAppFw(VOID)
{
    //SetAppRunStatus(E_FW_RUN_BACKUP_VER);
    zxDRV_FeedWdt();
    HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_REVERT_ADDR, APP_LENTH);

    return COMMON_OK;

}

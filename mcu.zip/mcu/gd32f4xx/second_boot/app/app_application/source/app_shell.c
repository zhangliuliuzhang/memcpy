/************************************************/
/**
 * \file app_sehll.c
 * \brief shell file
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "app_shell.h"
#include "stdlib.h"
#include "string.h"
#include "shell.h"
#include "uartprint.h"
#include "uart_config.h"
#include "app_download.h"
#include "app_upgrade.h"

extern FwHead_t st_FwHead;
extern FwDownloadInfo_t st_FwInfo;

static int download(int argc, char *argv[]);
static int exitdownload(int argc, char *argv[]);
static int softver(int argc, char *argv[]);
static int showinfo(int argc, char *argv[]);
static int md(int argc, char *argv[]);
static int eraseflash(int argc, char *argv[]);
static int reboot(int argc, char *argv[]);
static int help(int argc, char *argv[]);
static int clrrunsec(int argc, char *argv[]);

static CmdList_t gs_tCmdList[] =
{
    {"download",        download,           "Download Firmware\r\n"    },
    {"exitdownload",    exitdownload,       "Exit Download Firmware\r\n"    },
    {"softver",         softver,            "Show Soft Version\r\n"    },
    {"showinfo",        showinfo,           "Show Upgrade Info\r\n"    },
    {"reboot",          reboot,             "Reboot Mcu\r\n"    },
    {"help",            help,               "Show Support Command\r\n" },
    {"md",              md,                 "Memory Display\r\n" },
    {"eraseflash",      eraseflash,         "Memory Erase, SPI Flash Download Addr\r\n" },
    {"clrrunsec",      clrrunsec,         "clrrunsec\r\n" },

};
static uint16_t gs_usCmdListLen = sizeof(gs_tCmdList) / sizeof(CmdList_t);

/**********************************************************************/
/**
  * \brief APP Shell Init
  *
  * \param none
  *
  * \retval none
  */
/**********************************************************************/
VOID AppShellInit(VOID)
{
    uint16_t i = 0;

    /* Shell Init */
    ShellInit((ShellWriteFun)zxDRV_DebugUartSendBuffer, NULL);

    /* Register Function */
    for(i = 0; i < gs_usCmdListLen; i++)
    {
        ShellCmdRegister(gs_tCmdList[i].CmdName, gs_tCmdList[i].CmdCallBack, gs_tCmdList[i].CmdHelp);
    }
}

/**********************************************************************/
/**
  * \brief cmd function, query soft version
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int softver(int argc, char *argv[])
{
    CHAR BootVersion[10] = {0};

    // GetSecondBootVersion(BootVersion);
    ShellPrint("Soft Version -> %s\r\n", BootVersion);

    return 0;
}

/**********************************************************************/
/**
  * \brief cmd function, help
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int help(int argc, char *argv[])
{
    if (argc == 1)
    {
        ShellDisplaySupportCmd();
    }

    return 0;
}

/**********************************************************************/
/**
  * \brief download  fireware
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int download(int argc, char *argv[])
{
    if (argc == 1)
    {
        ShellPrint("The uart is in download mode,please dont't type any character!!!\r\n");
        ShellPrint("Open download softver to download!!!\r\n");

        st_FwHead.crc      = 0xFFFFFFFF;
        st_FwHead.lenth    = 0;
        st_FwHead.name     = 0xFF;
        st_FwHead.type     = 0xFF;

        st_FwInfo.u32FwRecordCrc     = 0;
        st_FwInfo.u32FwRecordSize    = 0;
        st_FwInfo.u32FwRecvCrc       = 0xFFFFFFFF;
        st_FwInfo.u32FwRecvSize      = 0;
        st_FwInfo.u32WriteAddr       = 0;
        st_FwInfo.u32FwIndex         = E_FW_MAX;

        SetUartMode(UART_DOWNLOAD);
        SetDownloadStatus(DOWNLOAD_START);
    }
    else
    {
        ShellPrint("PARA ERROR!!!\r\n");
    }


    return 0;
}

/**********************************************************************/
/**
  * \brief show config info
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int showinfo(int argc, char *argv[])
{
    T_fwUpgradeInfo fwInfo = {0};

    fwInfo = GetFwUpgradeInfo();

    ShellPrint("\r\n");
    ShellPrint("FwInfo_t.upgradeFlg     = %d\r\n", fwInfo.upgradeFlg);
    ShellPrint("FwInfo_t.revertFlg      = %d\r\n", fwInfo.revertFlg);
    ShellPrint("FwInfo_t.bootRunFlg     = %d\r\n", fwInfo.bootRunFlg);
    ShellPrint("FwInfo_t.appRunFlg      = %d\r\n", fwInfo.appRunFlg);
    ShellPrint("FwInfo_t.upgradeStatus  = %d\r\n", fwInfo.upgradeSta);
    ShellPrint("FwInfo_t.appBackupFwSta = %d\r\n", fwInfo.appBackupFwSta);

    return 0;
}

static int clrrunsec(int argc, char *argv[])
{
    ClrRunSector();
    return 0;
}

/**********************************************************************/
/**
  * \brief exit download mode
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int exitdownload(int argc, char *argv[])
{
    SetUartMode(UART_END);

    return 0;
}

/**********************************************************************/
/**
  * \brief memort display
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int md(int argc, char *argv[])
{
    BYTE FwData[128];
    INT32 i,len;

    if( argc != 3 )
    {
        ShellPrint("WRONG PARA.\r\n");
        return 0;
    }

    len = strtol(argv[2],NULL,0);
    if( len < 0 || len > 128 )
    {
        return -1;
    }

    // zxDRV_Mx25lBufferRead(EXT_SPI_FLASH, FwData, strtol(argv[1],NULL,0), len);

    for(i = 0; i < len; i++)
    {
        ShellPrint("%02x ", FwData[i]);
        if( (i+1) % 16 == 0 )
        {
            ShellPrint("\r\n");
        }
    }

    return 0;
}

/**********************************************************************/
/**
  * \brief flash erase
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int eraseflash(int argc, char *argv[])
{
    if( argc != 2 )
    {
        ShellPrint("WRONG PARA.\r\n");
        return 0;
    }

    ShellPrint("Erase Begin\r\n");

    ShellPrint("Erase End\r\n");

    return 0;
}

/**********************************************************************/
/**
  * \brief reboot
  *
  * \param argc: arg num
  * \param argv: arg
  *
  * \retval none
  */
/**********************************************************************/
static int reboot(int argc, char *argv[])
{
    NVIC_SystemReset();

    return 0;
}






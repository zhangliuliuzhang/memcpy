/************************************************/
/**
 * \file app_download.c
 * \brief 版本下载实现文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "app_download.h"
#include "string.h"
#include "app_upgrade.h"
#include "app_interrupt.h"
#include "app_shell.h"
#include "wdt_config.h"
#include "hal_flash.h"
#include "hal_uart.h"
#include "uart_config.h"

#include "utils.h"
#include "uartprint.h"
#include "shell.h"

static UART_MODE_E s_UartMode = UART_NORMAL;
static DOWNLOAD_STATUS_E s_DownloadStat = DOWNLOAD_IDLE;
static UINT32 s_BootWaitTime = BOOT_WAIT_TIME;
static UINT32 s_BootUpgradeOverTime = 0;
FwHead_t st_FwHead = {0};
FwDownloadInfo_t st_FwInfo = {0};

static BYTE appVersion[180 * 1024] = {0};   /*串口升级时的版本最大空间*/

/**
  * @brief  This function set uart run mode.
  * @param  uartMode: uart mode
  * @retval none
  */
VOID SetUartMode(UART_MODE_E uartMode)
{
    s_UartMode = uartMode;
}

/**
  * @brief  This function get uart run mode.
  * @param  none
  * @retval uart mode
  */
UART_MODE_E GetUartMode(VOID)
{
    return s_UartMode;
}

/**
  * @brief  This function set download run mode.
  * @param  uartMode: uart mode
  * @retval none
  */
VOID SetDownloadStatus(DOWNLOAD_STATUS_E downloadStat)
{
    s_DownloadStat = downloadStat;
}

/**
  * @brief  This function get download run mode.
  * @param  none
  * @retval uart mode
  */
DOWNLOAD_STATUS_E GetDownloadStatus(VOID)
{
    return s_DownloadStat;
}

/**
  * @brief  This function handle uart receive data.
  * @param  recvByte: uart receive byte
  * @retval none
  */
VOID ParseUartRecvByte(BYTE recvByte)
{
    /* uart is normal mode in dafault,type any character jump to cmdline mode */
    if (GetUartMode() == UART_NORMAL)
    {
        SetUartMode(UART_CMDLINE);
        UARTprintf("\r\nThe uart is in boot cmdline mode!\r\n");
        AppShellInit();
    }
    else if (GetUartMode() == UART_CMDLINE)
    {
        /* Handle data--cmd mode */
        ShellReadDataByte(recvByte);
    }
    else if (GetUartMode() == UART_DOWNLOAD)
    {
        HandleUartDownloadEvent(recvByte);
    }
    else
    {}
}

/**
  * @brief  This function handle uart download event.
  * @param  none
  * @retval none
  */
VOID HandleUartDownloadEvent(CHAR fwByte)
{
    static BYTE FwHeadBuf[FIREWARE_HEAD_LEN] = {0};
    static BYTE FwHeadLen = 0;
    
    if (GetDownloadStatus() == DOWNLOAD_START && (fwByte == '\r' || fwByte == '\n'))
    {
        UARTprintf("The uart is in download mode,please dont't type any character!!!\r\n");
        UARTprintf("Open download softver to download!!!\r\n");
        return;
    }
    
    SetDownloadStatus(DOWNLOAD_IN_PROGESS);
    s_BootUpgradeOverTime = 0;
    
    if (FwHeadLen < FIREWARE_HEAD_LEN)
    {
        FwHeadBuf[FwHeadLen++] = fwByte;
        if (FwHeadLen == FIREWARE_HEAD_LEN)
        {
            memcpy(&st_FwHead, FwHeadBuf, sizeof(FwHead_t));

            if ( st_FwHead.name == 'Z' && st_FwHead.type == 'R' ) /* R9124 */
            {
                st_FwInfo.u32FwRecvCrc 	= st_FwHead.crc;
                st_FwInfo.u32FwRecvSize = st_FwHead.lenth;
                st_FwInfo.u32FwRecordCrc = 0;
                st_FwInfo.u32FwRecordSize = 0;
                st_FwInfo.u32FwIndex	= E_FW_R9124;
            }
            else if ( st_FwHead.name == 'Z' && st_FwHead.type == 'B' ) /* BOOT */
            {
                st_FwInfo.u32FwRecvCrc 	= st_FwHead.crc;
                st_FwInfo.u32FwRecvSize = st_FwHead.lenth;
                st_FwInfo.u32FwRecordCrc = 0;
                st_FwInfo.u32FwRecordSize = 0;
                st_FwInfo.u32FwIndex	= E_FW_BOOT;
            }
            #if 0
            else if ( st_FwHead.name == 'Z' && st_FwHead.type == 'F' ) /* EPLD */
            {
                st_FwInfo.u32FwRecvCrc 	= st_FwHead.crc;
                st_FwInfo.u32FwRecvSize = st_FwHead.lenth;
                st_FwInfo.u32FwRecordCrc = 0;
                st_FwInfo.u32FwRecordSize = 0;
                st_FwInfo.u32FwIndex	= E_FW_FPGA;
            }
            #endif
        }
    }
    else
    {
        if (st_FwInfo.u32FwIndex == E_FW_R9124)
        {
            appVersion[st_FwInfo.u32FwRecordSize] = fwByte;
            st_FwInfo.u32WriteAddr = (UINT32)appVersion;
            st_FwInfo.u32FwRecordSize++;
            st_FwInfo.u32FwRecordCrc = zxUTILS_Crc32((BYTE*)&fwByte, 1, st_FwInfo.u32FwRecordCrc);
        }
        else if (st_FwInfo.u32FwIndex == E_FW_BOOT)
        {
            appVersion[st_FwInfo.u32FwRecordSize] = fwByte;
            st_FwInfo.u32WriteAddr = (UINT32)appVersion;
            st_FwInfo.u32FwRecordSize++;
            st_FwInfo.u32FwRecordCrc = zxUTILS_Crc32((BYTE*)&fwByte, 1, st_FwInfo.u32FwRecordCrc);
        }
        #if 0
        if (st_FwInfo.u32FwIndex == E_FW_FPGA)
        {
            appVersion[st_FwInfo.u32FwRecordSize] = fwByte;
            st_FwInfo.u32WriteAddr = appVersion;
            st_FwInfo.u32FwRecordSize++;
            st_FwInfo.u32FwRecordCrc = zxUTILS_Crc32((BYTE*)&fwByte, 1, st_FwInfo.u32FwRecordCrc);
        }
        #endif
    }
}

/**
  * @brief  This function handle uart idle interrupt.
  * @param  none
  * @retval none
  */
VOID HandleUartCompleteEvent(VOID)
{
    if (GetDownloadStatus() == DOWNLOAD_IN_PROGESS)
    {
        SetDownloadStatus(DOWNLOAD_END);
    }
}

/**
  * @brief  This function updata fireware when fireware download success.
  * @param  none
  * @retval none
  */
VOID UpdataFireware(E_FW_TYPE FwType)
{
    UINT32 i;

    switch ((BYTE)FwType)
    {
        case E_FW_R9124:
        {
            /* erase old mcu fw */
            HalEraseFlashSectors(APP_UPGRADE_SECTOR_START, APP_UPGRADE_SECTOR_END);
            /* write new mcu fw */
            zxDRV_FeedWdt();
            for (i = 0; i < st_FwInfo.u32FwRecordSize; i++)
            {
                HalFlashWrite(APP_UPGRADE_ADDR + i, &appVersion[i], 1);
            }
            SetUpgradeFlag(E_SET);
            zxDRV_UartContrl(UART_DEBUG, TRUE);
            UARTprintf("Complete R9124 MCU Fireware Copy\r\n");
            UARTprintf("u32WriteAddr: 0x%x  RecordSize:%d  crc:0x%x\r\n", st_FwInfo.u32WriteAddr, st_FwInfo.u32FwRecordSize, st_FwInfo.u32FwRecordCrc);
            UARTprintf("                    ReceiveSize:%d crc:0x%x\r\n", st_FwInfo.u32FwRecvSize, st_FwInfo.u32FwRecvCrc);
            SetUartMode(UART_END);
            NVIC_SystemReset();
            break;
        }
        case E_FW_BOOT:
        {
            /* erase old boot fw */
            HalEraseFlashSectors(SECOND_BOOT_MAIN_SECTOR, SECOND_BOOT_MAIN_SECTOR);
            /* write new boot fw, write to backup sector */
            zxDRV_FeedWdt();
            HalFlashWrite(ADDR_FMC_SECTOR_5, (void *)st_FwInfo.u32WriteAddr, st_FwInfo.u32FwRecordSize);
            SetSecondBootRunStatus(E_FW_RUN_MAIN_VER);
            zxDRV_UartContrl(UART_DEBUG, TRUE);
            UARTprintf("Complete R9124 BOOT Fireware Copy\r\n");
            UARTprintf("u32WriteAddr: 0x%x  RecordSize:%d  crc:0x%x\r\n", st_FwInfo.u32WriteAddr, st_FwInfo.u32FwRecordSize, st_FwInfo.u32FwRecordCrc);
            UARTprintf("                    ReceiveSize:%d crc:0x%x\r\n", st_FwInfo.u32FwRecvSize, st_FwInfo.u32FwRecvCrc);
            SetUartMode(UART_END);
            NVIC_SystemReset();
            break;
        }
        #if 0
        case E_FW_FPGA:
        {
            HalEraseFlashSectors(APP_REVERT_SECTOR_START, APP_REVERT_SECTOR_END);
            zxDRV_FeedWdt();
            HalFlashWrite(APP_REVERT_ADDR, st_FwInfo.u32WriteAddr, st_FwInfo.u32FwRecordSize);
            SetUpgradeFlag(E_SET);
            zxDRV_UartContrl(UART_DEBUG, TRUE);
            UARTprintf("Complete R9124 MCU Fireware Copy\r\n");
            UARTprintf("u32WriteAddr: 0x%x  RecordSize:%d  crc:0x%x\r\n", st_FwInfo.u32WriteAddr, st_FwInfo.u32FwRecordSize, st_FwInfo.u32FwRecordCrc);
            UARTprintf("                    ReceiveSize:%d crc:0x%x\r\n", st_FwInfo.u32FwRecvSize, st_FwInfo.u32FwRecvCrc);
            SetUartMode(UART_END);
            NVIC_SystemReset();
        }
        #endif
        default:
        {
            break;
        }
    }
}

VOID DownloadFireware(VOID)
{	
    while (1)
    {
        zxDRV_DelayNs(1);
        s_BootUpgradeOverTime++;
        
        if (GetUartMode() == UART_END)
        {
            break;
        }
        else if (GetUartMode() == UART_NORMAL)
        {
            UARTprintf("Boot Run Time %d s...\r\n", s_BootWaitTime--);
            if (s_BootWaitTime == 0)
            {
                UARTprintf("\r\nDon't Receive Fireware,jump to App\r\n");
                break;
            }
        }
        else if (GetUartMode() == UART_DOWNLOAD && GetDownloadStatus() == DOWNLOAD_END && s_BootUpgradeOverTime >= BOOT_UPGRADE_OVER_TIME)
        {
            SetUartMode(UART_CMDLINE);
            if (st_FwInfo.u32FwRecordCrc == st_FwInfo.u32FwRecvCrc && st_FwInfo.u32FwRecordSize == st_FwInfo.u32FwRecvSize)
            {
                UARTprintf("\r\n Fireware Download Success!\r\n");
                zxDRV_UartContrl(UART_DEBUG, FALSE);
                UpdataFireware((E_FW_TYPE)st_FwInfo.u32FwIndex);
            }
            else
            {
                UARTprintf("\r\nFireware Download Fail, Erase Error Fireware!\r\n");
                memset(appVersion, 0, sizeof(appVersion));
            }
        }
        else if (UART_CMDLINE == GetUartMode())
        {
            SetAppRunStatus(E_FW_RUN_NORMAL);
        }
    }
}

VOID ClrRunSector(VOID)
{
    HalEraseFlashSectors(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END);
}

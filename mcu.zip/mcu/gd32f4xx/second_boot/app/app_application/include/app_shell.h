/************************************************/
/**
 * \file app_shell.h
 * \brief app_shell include file
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _APP_SHELL_H_
#define _APP_SHELL_H_

#include "typedef.h"

VOID AppShellInit(VOID);

#endif


/************************************************/
/**
 * \file app_download.h
 * \brief 版本下载实现头文件
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _APP_DOWNLOAD_H_
#define _APP_DOWNLOAD_H_

#include "typedef.h"

#define BOOT_WAIT_TIME           (5u)  /*boot wait time, if no updata, jump to app*/
#define BOOT_UPGRADE_OVER_TIME  (3u)  /*boot overtime, if upgrade fail, jump to app*/
#define FIREWARE_HEAD_LEN        (10u)

/*     Internal Flash
 *
 *     First Boot
 *     0x08000000 ~ 0x0800FFFF  lenth:(64k) sector 0~3
 *
 *     Upgrade info
 *     0x08010000 ~ 0x0801FFFF  lenth:(64k) sector 4
 *
 *     Second Boot running area
 *     0x08020000 ~ 0x0803FFFF  lenth:(128k) sector 5
 *     App running area
 *     0x08040000 ~ 0x0807FFFF  lenth:(256k) sector 6~7
 *
 *     Second Boot upgrade area
 *     0x08080000 ~ 0x0809FFFF  lenth:(128k) sector 8
 *     Second Boot revert area
 *     0x080A0000 ~ 0x080BFFFF  lenth:(128k) sector 9
 *
 *
 */

/*     SPI Flash
 *
 *     MCU FPGA A
 *     0x00000000 ~ 0x00600000  lenth:(6M)
 *
 *     MCU FPGA B
 *     0x00600000 ~ 0x00C00000  lenth:(6M)
 *
 *     Version upgrade temp use boot upgrade store fireware
 *     0x00E00000 ~ 0x00F00000  lenth:(1M)
 */

typedef enum
{
    UART_NORMAL,
    UART_CMDLINE,
    UART_DOWNLOAD,
    UART_END,

    UART_MODE_MAX

}UART_MODE_E;

typedef enum
{
    DOWNLOAD_IDLE,
    DOWNLOAD_START,
    DOWNLOAD_IN_PROGESS,
    DOWNLOAD_END,

    DOWNLOAD_STATUS_MAX

}DOWNLOAD_STATUS_E;

typedef enum
{
    E_FW_BOOT,
    E_FW_MCU,
    E_FW_FPGA,
    E_FW_VER_ALL,
    E_FW_R9124,

    E_FW_MAX,
}E_FW_TYPE;

#pragma pack(1)
typedef struct
{
    /* version head */
    BYTE name;
    BYTE type;
    UINT32 lenth;
    UINT32 crc;
}FwHead_t;
#pragma pack()

typedef struct
{
    UINT32 u32FwIndex;       /* 固件文件索引号 */
    UINT32 u32FwRecvSize;    /* 固件中发送的固件长度 */
    UINT32 u32FwRecordSize;  /* 实际接收记录的固件长度 */
    UINT32 u32FwRecvCrc;     /* 固件中发送的CRC32值 */
    UINT32 u32FwRecordCrc;   /* 实际计算的CRC32值 */
    UINT32 u32WriteAddr;     /* 版本下载地址 */
    UINT32 u32SecWriteAddr;  /* second 版本下载地址 */
    UINT32 u32DownLoadStat;  /* 版本是否下载成功 */
}FwDownloadInfo_t;

VOID SetUartMode(UART_MODE_E uartMode);
UART_MODE_E GetUartMode(VOID);
VOID SetDownloadStatus(DOWNLOAD_STATUS_E downloadStat);
DOWNLOAD_STATUS_E GetDownloadStatus(VOID);
VOID ParseUartRecvByte(BYTE recvByte);
VOID HandleUartDownloadEvent(CHAR fwByte);
VOID HandleUartDownloadEventAnt(CHAR fwByte);
VOID HandleUartCompleteEvent(VOID);
VOID DownloadFireware(VOID);
VOID ClrRunSector(VOID);
#endif

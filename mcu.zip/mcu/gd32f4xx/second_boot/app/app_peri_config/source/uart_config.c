/************************************************/
/**
 * \file uart_config.c
 * \brief UART 属性挂载配置文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "uart_config.h"
#include "gd32f4xx_usart.h"
#include "common.h"
#include "hal_uart.h"

_T_Uart_Tbl s_UartInitTbl[UART_MAX] =
{
    [UART_DEBUG] = { UART_DEBUG,  RCU_UART4,  UART4,  115200,  USART_RECEIVE_ENABLE,  USART_TRANSMIT_ENABLE,  USART_INT_RBNE,  UART4_IRQn,  3,  0 },
};

/**********************************************************************/
/**
  * \brief  Init UART
  *
  * \param NULL
  *
  * \retval NULL
  */
/**********************************************************************/
VOID zxDRV_InitUart(VOID)
{
    UINT32 index = 0;

    for(index = 0; index < UART_MAX; index++)
    {
        HalInitUart(s_UartInitTbl[index]);
    }

    HalEnableInt(UART4, USART_INT_IDLE);
}

/**********************************************************************/
/**
  * \brief  Convert UART index to MCU UART number
  *
  * \param ulUartIndex- uart name index, UART_DEBUG...
  *
  * \retval NULL
  */
/**********************************************************************/
UINT32 zxDRV_UartIndexToMcuId(UINT32 ulUartIndex)
{
    UINT32 tmp=0;

    for (tmp = 0; tmp < NELEMENTS(s_UartInitTbl); tmp++)
    {
        if(ulUartIndex == s_UartInitTbl[tmp].index)
        {
            return s_UartInitTbl[tmp].uartId;
        }
    }

    return COMMON_ERROR;
}

/**
    * \brief     UART发送一个字节
  *
  * \param uartIndex: UART_DEBUG......
  * \param data: ready send byte
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_UartSendByte(UINT32 uartIndex, UINT32 data)
{
    UINT32 uartId;

    uartId = zxDRV_UartIndexToMcuId(uartIndex);

    HalUartSendByte(uartId, data);
}

/**********************************************************************/
/**
    * \brief     UART发送一个string
  *
  * \param uartIndex: UART_DEBUG......
  * \param pData: ready send data address
  * \param dataLen: ready send data lenth
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_UartSendString(UINT32 uartIndex, const BYTE *string)
{
    UINT32 uartId;

    uartId = zxDRV_UartIndexToMcuId(uartIndex);

    HalUartSendString(uartId, string);
}

/**********************************************************************/
/**
    * \brief     UART enable or disable ctrl
  *
  * \param uartIndex: UART_DEBUG......
  * \param ucStat: contrl status
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_UartContrl(UINT32 uartIndex, BOOLEAN ucStat)
{
    UINT32 uartId;

    uartId = zxDRV_UartIndexToMcuId(uartIndex);

    HalUartContrl(uartId, ucStat);
}

/**********************************************************************/
/**
    * \brief debug UART发送一个定长Buffer
  *
  * \param pData: ready send data address
  * \param dataLen: ready send data lenth
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_DebugUartSendBuffer(BYTE *pData, UINT32 dataLen)
{
    UINT32 uartId;

    uartId = zxDRV_UartIndexToMcuId(UART_DEBUG);

    HalUartSendBuffer(uartId, pData, dataLen);
}

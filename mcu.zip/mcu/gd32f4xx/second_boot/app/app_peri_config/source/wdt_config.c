/************************************************/
/**
 * \file wdt_config.c
 * \brief 看门狗文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "wdt_config.h"
#include "hal_wdt.h"

#define    WDT_RELOAD_TIME_16S        (16)
/**********************************************************************/
/**
  * \brief  Init WDT
  *
  * \param NULL
  *
  * \retval NULL
  */
/**********************************************************************/
VOID zxDRV_InitWdt(VOID)
{
    HalFwdgtConfig(WDT_RELOAD_TIME_16S);
}


VOID zxDRV_FeedWdt(VOID)
{
    HalFwdgtReload();
}
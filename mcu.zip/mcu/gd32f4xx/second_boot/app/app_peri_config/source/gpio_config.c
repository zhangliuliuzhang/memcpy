/************************************************/
/**
 * \file gpio_config.c
 * \brief GPIO ���Թ��������ļ�
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "gpio_config.h"
#include "gd32f4xx_gpio.h"
#include "gd32f4xx_exti.h"

_T_Gpio_Tbl s_NormalGpioInitTbl[GPIO_NORMAL_MAX] =
{
    [GPIO_DEBUG_UART_TX] = {GPIO_DEBUG_UART_TX, RCU_GPIOC, GPIOC, GPIO_PIN_12, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_AF_8, GPIO_NO_INIT},
    [GPIO_DEBUG_UART_RX] = {GPIO_DEBUG_UART_RX, RCU_GPIOD, GPIOD, GPIO_PIN_2, GPIO_MODE_AF, GPIO_PUPD_PULLUP, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_AF_8, GPIO_NO_INIT},

    [GPIO_LED_RUN] = {GPIO_LED_RUN, RCU_GPIOD, GPIOD, GPIO_PIN_1, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_AF_NONE, GPIO_LOW},
    [GPIO_LED_ALM] = {GPIO_LED_ALM, RCU_GPIOG, GPIOG, GPIO_PIN_11, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_AF_NONE, GPIO_HIGH},

    //[GPIO_WDI] = {GPIO_WDI, RCU_GPIOF, GPIOF, GPIO_PIN_10, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_AF_NONE, GPIO_NO_INIT},

};

/**********************************************************************/
/**
  * \brief  Init normal GPIO
  *
  * \param NULL
  *
  * \retval NULL
  */
/**********************************************************************/
VOID zxDRV_InitNormalGpio(VOID)
{
    UINT32 index = 0;

    for(index = 0; index < GPIO_NORMAL_MAX; index++)
    {
        HalInitGpioNormal(s_NormalGpioInitTbl[index]);
    }
}

VOID alarmLedCtrl(UINT32 sw)
{
    HalSetGpioDataout(GPIOG, GPIO_PIN_11, sw);
}

VOID runLedCtrl(UINT32 sw)
{
    HalSetGpioDataout(GPIOD, GPIO_PIN_1, sw);
}


static UINT32 g_runLedState = LED_RUN_SLOW_STA;

UINT32 BspGetRunLedState(VOID)
{
    return g_runLedState;
}

VOID BspSetRunLedState(UINT32 state)
{
    g_runLedState = state;
}
/************************************************/
/**
 * \file uart_config.h
 * \brief UART 属性挂载配置头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _UART_CONFIG_H_
#define _UART_CONFIG_H_

#include "typedef.h"

/*UART接口相关*/
typedef enum _UART_DEF
{
    UART_DEBUG = 0,

    UART_MAX,
}REG_UART_DEF;


VOID zxDRV_InitUart(VOID);
UINT32 zxDRV_UartIndexToMcuId(UINT32 ulUartIndex);
VOID zxDRV_UartSendByte(UINT32 uartIndex, UINT32 data);
VOID zxDRV_UartSendString(UINT32 uartIndex, const BYTE *string);
VOID zxDRV_UartContrl(UINT32 uartIndex, BOOLEAN ucStat);
VOID zxDRV_DebugUartSendBuffer(BYTE *pData, UINT32 dataLen);

#endif

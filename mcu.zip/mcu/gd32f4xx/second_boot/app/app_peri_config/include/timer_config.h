/************************************************/
/**
 * \file timer_config.h
 * \brief TIMER 属性挂载配置头文件
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _TIMER_CONFIG_H_
#define _TIMER_CONFIG_H_

#include "typedef.h"

/* TIMER接口相关 */
typedef enum _NORMAL_TIMER_DEF
{
    TIMER_1_SECOND = 0,

    TIMER_NORMAL_MAX,
}REG_NORMAL_SPI_DEF;

VOID zxDRV_InitTimer(VOID);

#endif

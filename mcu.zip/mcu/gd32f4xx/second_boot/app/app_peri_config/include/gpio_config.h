/************************************************/
/**
 * \file gpio_config.h
 * \brief GPIO ���Թ�������ͷ�ļ�
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _GPIO_CONFIG_H_
#define _GPIO_CONFIG_H_

#include "typedef.h"
#include "hal_gpio.h"

/*normal GPIO�ӿ����?*/
typedef enum _GPIO_NORMAL_DEF
{
    GPIO_DEBUG_UART_TX,
    GPIO_DEBUG_UART_RX,

    GPIO_LED_RUN ,
      GPIO_LED_ALM,
    GPIO_NORMAL_MAX,
}REG_NOR_GPIO_DEF;

/*exit GPIO�ӿ����?*/
typedef enum _GPIO_EXIT_DEF
{
    GPIO,

    GPIO_EXIT_MAX,
}REG_EXIT_GPIO_DEF;

enum {
    LED_RUN_SLOW_STA = 0,
    LED_RUN_FAST_STA = 1,
    LED_RUN_ON_STA,
    LED_RUN_OFF_STA,
    LED_ALARM_ON_STA,
    LED_ALARM_OFF_STA,
};

#define  FEED_WDT()                     HalGpioToggle(GPIOE, GPIO_PIN_14)
#define  FPGA_LOAD_PROGRAM_CTR(status)  HalSetGpioDataout(GPIOA, GPIO_PIN_9, status)
#define  FPGA_LOAD_INIT_GET()           HalGetGpioDatain(GPIOA, GPIO_PIN_8)
#define  FPGA_LOAD_DONE_GET()           HalGetGpioDatain(GPIOA, GPIO_PIN_10)
#define  SPI1_CS_CTR(status)            HalSetGpioDataout(GPIOB, GPIO_PIN_12, status)
#define  SPI2_CS_CTR(status)            HalSetGpioDataout(GPIOA, GPIO_PIN_4, status)
#define  SPI3_CS_CTR(status)            HalSetGpioDataout(GPIOE, GPIO_PIN_4, status)
#define  SPI4_CS_CTR(status)            HalSetGpioDataout(GPIOF, GPIO_PIN_6, status)
#define  SPI5_CS_CTR(status)            HalSetGpioDataout(GPIOG, GPIO_PIN_8, status)

VOID zxDRV_InitNormalGpio(VOID);
VOID alarmLedCtrl(UINT32 sw);

UINT32 BspGetRunLedState(VOID);
VOID BspSetRunLedState(UINT32 state);

VOID runLedCtrl(UINT32 sw);

#endif

/************************************************/
/**
 * \file main.c
 * \brief main
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include <string.h>
#include <stdarg.h>
#include <stdio.h>

#include "gd32f4xx.h"
#include "common.h"
#include "typedef.h"
#include "utils.h"

#include "hal_flash.h"
#include "timer_config.h"
#include "wdt_config.h"

#include "app_upgrade.h"

typedef    void (*pFunction)(void);

pFunction Jump_To_Application;

/**
  * @brief  This function jump to app code.
  * @param  None
  * @retval none
  */
VOID JumpToApp(UINT32 Address)
{
    UINT32 JumpAddress;

    __disable_irq();

    JumpAddress = *(__IO uint32_t*) (Address + 4);
    Jump_To_Application = (pFunction) JumpAddress;
    __set_MSP(*(__IO uint32_t*) Address);
    Jump_To_Application();

}

/**********************************************************************/
/**
  * \brief 初始化硬件接口
  *
  * \param none
  *
  * \retval none
  */
/**********************************************************************/
VOID InitHard(VOID)
{
    nvic_priority_group_set(NVIC_PRIGROUP_PRE2_SUB2);
    nvic_vector_table_set(NVIC_VECTTAB_FLASH, NVIC_VECTOR_TABLE_OFFSET);

    zxDRV_InitTimer();
    zxDRV_InitWdt();
    InitFwUpgradeInfoFromInterFlash();
}

int main(void)
{
    InitHard();

    zxDRV_FeedWdt();
    if ((E_FW_RUN_NORMAL != GetSecondBootRunStatus()) && (TRUE == IsSecBootUpdataAreaValid()))
    {
        SetSecondBootRunStatus(E_FW_RUN_BACKUP_VER);
        SetupBackupSecondBootFw();
    }
    else
    {
        SetSecondBootRunStatus(E_FW_RUN_MAIN_VER);
    }

    zxDRV_FeedWdt();
    JumpToApp(SECOND_BOOT_RUN_ADDR);

    return 0;
}

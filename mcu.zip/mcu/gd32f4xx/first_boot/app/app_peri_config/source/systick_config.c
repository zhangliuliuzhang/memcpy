/************************************************/
/**
 * \file uart_systick.c
 * \brief SYSTICK йТпт╧ртьеДжцнд╪Ч
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "systick_config.h"
#include "common.h"
#include "hal_systick.h"

/**********************************************************************/
/**
  * \brief  Init STSTICK
  *
  * \param NULL
  *
  * \retval NULL
  */
/**********************************************************************/
VOID zxDRV_InitSystick(VOID)
{
    HalSystickConfig();
}


/************************************************/
/**
 * \file gpio_config.c
 * \brief GPIO йТпт╧ртьеДжцнд╪Ч
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "gpio_config.h"
#include "gd32f4xx_gpio.h"
#include "gd32f4xx_exti.h"

_T_Gpio_Tbl s_NormalGpioInitTbl[GPIO_NORMAL_MAX] =
{
    /*WDI config*/
    [GPIO_WDI] = {GPIO_WDI, RCU_GPIOF, GPIOF, GPIO_PIN_10, GPIO_MODE_OUTPUT, GPIO_PUPD_PULLUP, GPIO_OTYPE_PP, GPIO_OSPEED_50MHZ, GPIO_AF_NONE, GPIO_NO_INIT},

};

/**********************************************************************/
/**
  * \brief  Init normal GPIO
  *
  * \param NULL
  *
  * \retval NULL
  */
/**********************************************************************/
VOID zxDRV_InitNormalGpio(VOID)
{
    UINT32 index = 0;

    for(index = 0; index < GPIO_NORMAL_MAX; index++)
    {
        HalInitGpioNormal(s_NormalGpioInitTbl[index]);
    }
}


/************************************************/
/**
 * \file timer_config.c
 * \brief TIMER йТпт╧ртьеДжцнд╪Ч
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "timer_config.h"
#include "gd32f4xx_timer.h"
#include "hal_timer.h"

_T_Normal_Timer_Tbl s_NormalTimerInitTbl[TIMER_NORMAL_MAX] =
{
    [TIMER_500_MS] = { TIMER_500_MS,  RCU_TIMER1,  TIMER1,  RCU_TIMER_PSC_MUL4,  (20000-1),  TIMER_COUNTER_EDGE,  TIMER_COUNTER_UP,  (2500-1),  TIMER_CKDIV_DIV1,  TIMER_INT_UP, TIMER1_IRQn, 2, 1 },
};

/**********************************************************************/
/**
  * \brief  Init TIMER
  *
  * \param NULL
  *
  * \retval NULL
  */
/**********************************************************************/
VOID zxDRV_InitTimer(VOID)
{
    UINT32 index = 0;

    for(index = 0; index < TIMER_NORMAL_MAX; index++)
    {
        HalInitTimer(s_NormalTimerInitTbl[index]);
    }
}

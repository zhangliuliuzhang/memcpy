/************************************************/
/**
 * \file systick_config.h
 * \brief SYSTICK 属性挂载配置头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _SYSTICK_CONFIG_H_
#define _SYSTICK_CONFIG_H_

#include "typedef.h"

VOID zxDRV_InitSystick(VOID);

#endif




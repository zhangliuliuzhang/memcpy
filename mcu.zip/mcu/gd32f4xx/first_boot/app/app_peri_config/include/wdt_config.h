/************************************************/
/**
 * \file wdt_config.h
 * \brief 看门狗 属性挂载配置头文件
 *
 * \author 10294149
 * \date   2023.8
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef WDT_CONFIG_H_
#define WDT_CONFIG_H_

#include "typedef.h"

VOID zxDRV_InitWdt(VOID);
VOID zxDRV_FeedWdt(VOID);

#endif

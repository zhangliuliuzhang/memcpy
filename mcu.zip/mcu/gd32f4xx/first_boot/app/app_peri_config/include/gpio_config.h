/************************************************/
/**
 * \file gpio_config.h
 * \brief GPIO 属性挂载配置头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _GPIO_CONFIG_H_
#define _GPIO_CONFIG_H_

#include "typedef.h"
#include "hal_gpio.h"


/*normal GPIO接口相关*/
typedef enum _GPIO_NORMAL_DEF
{
    /* WDI config */
    GPIO_WDI,

    GPIO_NORMAL_MAX,
}REG_NOR_GPIO_DEF;

#define  FEED_WDT()    HalGpioToggle(GPIOE, GPIO_PIN_14)

VOID zxDRV_InitNormalGpio(VOID);

#endif

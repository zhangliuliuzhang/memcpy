/************************************************/
/**
 * \file app_upgrade.h
 * \brief �汾����ʵ��ͷ�ļ�
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _APP_UPGRADE_H_
#define _APP_UPGRADE_H_

#include "typedef.h"

#define NVIC_VECTOR_TABLE_OFFSET			(0)
#define BOOT_VER_LENTH                      (32)
/*     Internal Flash
 *
 *     First Boot
 *     0x08000000 ~ 0x08003FFF  lenth:(16k) sector 0
 *
 *     RESERVE
 *     0x08004000 ~ 0x08007FFF  lenth:(16k) sector 1
 * 
 *     RESERVE
 *     0x08008000 ~ 0x0800BFFF  lenth:(16k) sector 2
 * 
 *     RESERVE
 *     0x0800C000 ~ 0x0800FFFF  lenth:(16k) sector 3
 *
 *     Second Boot running area
 *     0x08010000 ~ 0x0801FFFF  lenth:(64k) sector 4
 *     Second Boot backup area
 *     0x08020000 ~ 0x0803FFFF  lenth:(128k) sector 5
 *     
 *     App running area
 *     0x08040000 ~ 0x0805FFFF  lenth:(128k) sector 6
 *     0x08060000 ~ 0x0807FFFF  lenth:(128k) sector 7
 * 
 *     App upgrade area
 *     0x08080000 ~ 0x0809FFFF  lenth:(128k) sector 8
 *     0x080A0000 ~ 0x080BFFFF  lenth:(128k) sector 9
 * 
 *     version download area
 *     0x080C0000 ~ 0x080DFFFF  lenth:(128k) sector 10
 *     0x080E0000 ~ 0x080FFFFF  lenth:(128k) sector 11
 */
 
#define UPGRADE_INFO_ADDR               ADDR_FMC_SECTOR_2
#define UPGRADE_INFO_SECTOR             CTL_SECTOR_NUMBER_2

#define SECOND_BOOT_RUN_ADDR            ADDR_FMC_SECTOR_4
#define SECOND_BOOT_RUN_SECTOR          CTL_SECTOR_NUMBER_4
#define SECOND_BOOT_MAIN_ADDR         ADDR_FMC_SECTOR_5
#define SECOND_BOOT_MAIN_SECTOR       CTL_SECTOR_NUMBER_5
#define SECOND_BOOT_LENTH               (64 * 1024)

#define APP_RUN_ADDR                    ADDR_FMC_SECTOR_6
#define APP_RUN_SECTOR_START            CTL_SECTOR_NUMBER_6
#define APP_RUN_SECTOR_END              CTL_SECTOR_NUMBER_7
#define APP_UPGRADE_ADDR                ADDR_FMC_SECTOR_8
#define APP_UPGRADE_SECTOR_START        CTL_SECTOR_NUMBER_8
#define APP_UPGRADE_SECTOR_END          CTL_SECTOR_NUMBER_9
#define APP_REVERT_ADDR                 ADDR_FMC_SECTOR_10
#define APP_REVERT_SECTOR_START         CTL_SECTOR_NUMBER_10
#define APP_REVERT_SECTOR_END           CTL_SECTOR_NUMBER_11
#define APP_LENTH                       (256*1024)

#define VERSION_DOWNLOAD_ADDR           ADDR_FMC_SECTOR_10
#define VERSION_DOWNLOAD_SECTOR_START   CTL_SECTOR_NUMBER_10
#define VERSION_DOWNLOAD_SECTOR_END     CTL_SECTOR_NUMBER_11

#define BOOT_NAME_LEN                   ( 1 )   /* Z */
#define BOOT_TYPE_LEN                   ( 1 )   /* MCU:M or FPG:F  or NAME:P TYPE:A for merge app bin*/
#define BOOT_TOTAL_LEN                  ( 4 )   /* fireware total len */
#define BOOT_CRC_LEN                    ( 4 )   /* fireware crc len */
#define BOOT_HEAD_LEN                   ( BOOT_NAME_LEN + BOOT_TYPE_LEN + BOOT_TOTAL_LEN + BOOT_CRC_LEN )  /* fireware head len */

enum
{
    E_WAIT_FOR_DOWNLOAD = 0,     /** 等待下载版本 */
    E_DOWNLOADING       = 1,     /** 下载版本中 */
    E_CHECK_OK          = 2,     /** 下载完成，检验成功 */
    E_CHECK_ERR         = 3,     /** 下载完成，检验失败 */
    E_UPGRADEING        = 4,     /** 升级版本中 */
    E_UPGRADE_OK        = 5,     /** 升级成功 */
    E_UPGRADE_ERR       = 6,     /** 升级失败 */
};

typedef enum
{
    E_FW_RUN_NORMAL      = 0,
    E_FW_RUN_MAIN_VER    = 1,
    E_FW_RUN_BACKUP_VER  = 2,

}E_FW_RUN_STATUS;

#pragma pack(1)
typedef struct
{
    UINT32 upgradeFlg;      /* 版本升级标识                     */
    UINT32 revertFlg;       /* 版本回滚标识                     */
    UINT32 bootRunFlg;      /* BOOT运行标识，主区运行/备区运行    */
    UINT32 appRunFlg;       /* APP运行标识，主区运行/备区运行     */
    UINT32 upgradeSta;      /* 版本升级状态                     */
    UINT32 appBackupFwSta;  /* APP备区版本是否可用              */
    CHAR firstBootVer[BOOT_VER_LENTH];
    CHAR secondBootVer[BOOT_VER_LENTH];
}T_fwUpgradeInfo;

#pragma pack()

UINT32 InitFwUpgradeInfoFromInterFlash(VOID);
T_fwUpgradeInfo GetFwUpgradeInfo(VOID);
VOID FlushFwUpgradeInfoToInterFlash(VOID);
VOID SetSecondBootRunStatus(E_FW_RUN_STATUS eRunStatus);
E_FW_RUN_STATUS GetSecondBootRunStatus(VOID);
UINT32 SetupBackupSecondBootFw(VOID);
VOID SetUpgradeFlag(UINT32 flg);
UINT32 GetUpgradeFlag(VOID);
VOID SetRevertFlag(UINT32 flg);
UINT32 GetRevertFlag(VOID);
VOID SetAppRunStatus(E_FW_RUN_STATUS eRunStatus);
E_FW_RUN_STATUS GetAppRunStatus(VOID);
VOID BspSetUpAreaStatus(UINT32 status);
UINT32 GetAppUpFwStatus(VOID);
VOID SetUpgradeStatus(UINT32 status);
BOOLEAN IsSecBootUpdataAreaValid(VOID);
#endif

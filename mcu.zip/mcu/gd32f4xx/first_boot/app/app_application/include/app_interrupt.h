/************************************************/
/**
 * \file interrupt.h
 * \brief 中断实现头文件
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _APP_INTERRUPT_H_
#define _APP_INTERRUPT_H_

#include "typedef.h"

VOID zxDRV_SystickISR(VOID);
VOID zxDRV_DelayNs(UINT32 count);
VOID zxDRV_Timer1ISR(VOID);
VOID zxDRV_Uart6ISR(VOID);

#endif

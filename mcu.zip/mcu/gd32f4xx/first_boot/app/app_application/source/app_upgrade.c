/************************************************/
/**
 * \file app_upgrade.c
 * \brief 版本升级文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "app_upgrade.h"
#include "hal_flash.h"
#include "string.h"
#include "common.h"
#include "utils.h"
#include "uartprint.h"
#include "wdt_config.h"

const char *s_firBootVersion = "V1.1.03";
static T_fwUpgradeInfo st_fwUpgradeInfo = {0};

BOOLEAN IsSecBootUpdataAreaValid(VOID)
{
    UINT8 validFlag[4] = {0};

    HalFlashRead(ADDR_FMC_SECTOR_5, validFlag, sizeof(validFlag));
    for(UINT8 loop = 0; loop < sizeof(validFlag); loop++)
    {
        if(validFlag[loop] != 0xFF)
        {
            return TRUE;
        }
    }
    return FALSE;
}
/**
  * @brief  get fireware config info from internal flash.
  * @param  none
  * @retval fireware config info
  */
UINT32 InitFwUpgradeInfoFromInterFlash(VOID)
{
    UINT8 cmpFlag = 0;

    HalFlashRead(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));

    if(strcmp(s_firBootVersion, st_fwUpgradeInfo.firstBootVer) != 0)
    {
        cmpFlag = 1;
    }
    /* first init. set default value */
    if (st_fwUpgradeInfo.upgradeSta == 0xFFFFFFFF)
    {
        st_fwUpgradeInfo.upgradeFlg     = E_RESET;
        st_fwUpgradeInfo.revertFlg      = E_RESET;
        st_fwUpgradeInfo.bootRunFlg     = E_FW_RUN_NORMAL;
        st_fwUpgradeInfo.appRunFlg      = E_FW_RUN_NORMAL;
        st_fwUpgradeInfo.upgradeSta     = E_WAIT_FOR_DOWNLOAD;
        st_fwUpgradeInfo.appBackupFwSta = E_RESET;

        zxDRV_FeedWdt();
        HalEraseFlashSectors(UPGRADE_INFO_SECTOR, UPGRADE_INFO_SECTOR);
        HalFlashWrite(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));
    }

    if(cmpFlag == 1)
    {
        strcpy(st_fwUpgradeInfo.firstBootVer, s_firBootVersion);
        HalFlashWrite(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));
    }

    return COMMON_OK;
}

T_fwUpgradeInfo GetFwUpgradeInfo(VOID)
{
    return st_fwUpgradeInfo;
}

/**
  * @brief  updata fireware config info to internal flash.
  * @param  none
  * @retval fireware config info
  */
VOID FlushFwUpgradeInfoToInterFlash(VOID)
{
    zxDRV_FeedWdt();
    HalEraseFlashSectors(UPGRADE_INFO_SECTOR, UPGRADE_INFO_SECTOR);
    HalFlashWrite(UPGRADE_INFO_ADDR, (UCHAR *)&st_fwUpgradeInfo, sizeof(T_fwUpgradeInfo));
}

/**
  * @brief  set fw run status
  * @param  eRunStatus status
  * @retval none
  */
VOID SetSecondBootRunStatus(E_FW_RUN_STATUS eRunStatus)
{
    st_fwUpgradeInfo.bootRunFlg = eRunStatus;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  get fw run status
  * @param  eRunStatus status
  * @retval none
  */
E_FW_RUN_STATUS GetSecondBootRunStatus(VOID)
{
    return st_fwUpgradeInfo.bootRunFlg;
}

/**
  * @brief  将备区BOOT版本搬移至运行区，并进行运行
  * @param  none
  * @retval none
  */
UINT32 SetupBackupSecondBootFw(VOID)
{
    SetSecondBootRunStatus(E_FW_RUN_BACKUP_VER);
    zxDRV_FeedWdt();
    HalFlashDataMove(SECOND_BOOT_RUN_SECTOR, SECOND_BOOT_RUN_SECTOR, SECOND_BOOT_RUN_ADDR, SECOND_BOOT_MAIN_ADDR, SECOND_BOOT_LENTH);

    return COMMON_OK;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/**
  * @brief  设置升级标志位
  * @param  flg 
  * @retval none
  */
VOID SetUpgradeFlag(UINT32 flg)
{
    st_fwUpgradeInfo.upgradeFlg = flg;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取升级标志位
  * @param  eRunStatus status
  * @retval none
  */
UINT32 GetUpgradeFlag(VOID)
{
    return st_fwUpgradeInfo.upgradeFlg;
}

/**
  * @brief  设置回滚标志位
  * @param  flg 
  * @retval none
  */
VOID SetRevertFlag(UINT32 flg)
{
    st_fwUpgradeInfo.revertFlg = flg;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取回滚标志位
  * @param  eRunStatus status
  * @retval none
  */
UINT32 GetRevertFlag(VOID)
{
    return st_fwUpgradeInfo.revertFlg;
}

/**
  * @brief  设置APP运行状态
  * @param  eRunStatus status
  * @retval none
  */
VOID SetAppRunStatus(E_FW_RUN_STATUS eRunStatus)
{
    st_fwUpgradeInfo.appRunFlg = eRunStatus;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取APP运行状态
  * @param  eRunStatus status
  * @retval none
  */
E_FW_RUN_STATUS GetAppRunStatus(VOID)
{
    return st_fwUpgradeInfo.appRunFlg;
}

/**
  * @brief  设置APP升级版本状态
  * @param  status status
  * @retval none
  */
VOID BspSetUpAreaStatus(UINT32 status)
{
    st_fwUpgradeInfo.appBackupFwSta = status;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取APP升级版本状态
  * @param  none
  * @retval none
  */
UINT32 GetAppUpFwStatus(VOID)
{
    return st_fwUpgradeInfo.appBackupFwSta;
}

/**
  * @brief  设置升级状态
  * @param  status 
  * @retval none
  */
VOID SetUpgradeStatus(UINT32 status)
{
    st_fwUpgradeInfo.upgradeSta = status;
    FlushFwUpgradeInfoToInterFlash();
}

/**
  * @brief  获取升级状态
  * @param  status 
  * @retval none
  */
UINT32 GetUpgradeStatus(VOID)
{
    return st_fwUpgradeInfo.upgradeSta;
}

/**
  * @brief  版本升级流程
  * @param  none
  * @retval none
  */
UINT32 UpgradeFwVersion(VOID)
{
    /* 1.擦除回滚区将运行区版本搬移到回滚区 */
    HalFlashDataMove(APP_REVERT_SECTOR_START, APP_REVERT_SECTOR_END, APP_REVERT_ADDR, APP_RUN_ADDR, APP_LENTH);
    /* 2.置位回滚标识 */
    SetRevertFlag(E_SET);
    /* 3.将升级区版本搬移到运行区 */
    HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_UPGRADE_ADDR, APP_LENTH);
    /* 4.清除升级标识 */
    SetUpgradeFlag(E_RESET);

    return COMMON_OK;
}

/**
  * @brief  版本回滚流程
  * @param  none
  * @retval none
  */
UINT32 RevertFwVersion(VOID)
{
    /* 1.将回滚区版本搬移至运行区 */
    HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_REVERT_ADDR, APP_LENTH);
    /* 2.将回滚区版本搬移至升级区 */
    HalFlashDataMove(APP_UPGRADE_SECTOR_START, APP_UPGRADE_SECTOR_END, APP_UPGRADE_ADDR, APP_REVERT_ADDR, APP_LENTH);
    /* 3.清除回滚标志，清除升级标识 */
    SetRevertFlag(E_RESET);
    SetUpgradeFlag(E_RESET);
    /* 4.升级状态为升级失败 */
    SetUpgradeStatus(E_UPGRADE_ERR);

    return COMMON_OK;
}

/**
  * @brief  将备区APP版本搬移至运行区，并进行运行
  * @param  none
  * @retval none
  */
UINT32 SetupBackupAppFw(VOID)
{
    SetAppRunStatus(E_FW_RUN_BACKUP_VER);
    HalFlashDataMove(APP_RUN_SECTOR_START, APP_RUN_SECTOR_END, APP_RUN_ADDR, APP_UPGRADE_ADDR, APP_LENTH);

    return COMMON_OK;
}
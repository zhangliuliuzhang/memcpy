/************************************************/
/**
 * \file interrupt.c
 * \brief 中断实现文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#include "app_interrupt.h"
#include "wdt_config.h"
#include "common.h"
#include "utils.h"

#include "hal_timer.h"


volatile static UINT32 delay;

/**********************************************************************/
/**
  * \brief     滴答定时器中断处理函数
  *
  * \param null
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_SystickISR(VOID)
{
}

/**********************************************************************/
/**
  * \brief     使用滴答定时器产生的准确延时
  *
  * \param count:延时毫秒数
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_DelayNs(UINT32 count)
{
    delay = count;

  while(0U != delay){
  }
}

/**********************************************************************/
/**
  * \brief     定时器1中断处理函数
  *
  * \param null
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_Timer1ISR(VOID)
{
    if(E_SET == HalGetTimerIntFlag(TIMER1, TIMER_INT_FLAG_UP))
    {
        HalClearTimerIntFlag(TIMER1, TIMER_INT_FLAG_UP);

        zxDRV_FeedWdt();

        if (0U != delay)
        {
            delay--;
        }
    }
}

/*HDR************************************************************************
*
* Module:      ZXMW_UTILS
*
* File:           time.c
*
* Description: This file implements time related manipulation.
*
* Interface:   zxUTILS_DelayNms()
*              zxUTILS_DelayNus()
*                            zxUTILS_DelayNns()
*
* Copyright (c) 2011. All rights reserved. ZTE USA, Inc.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/06/07   Alex Semenyshev
*              - Created
* 2012/09/07   Zhao Wei
*              - Adopted for TCM in AOU project.
*
****************************************************************************/

/* INCLUDES */
#include "utils.h"


/*lint -e722*/
/*FNC************************************************************************
*
* Function:    zxUTILS_DelayNms()
*
* Description: This function implements delay for at least specified
*              number of milliseconds (1E-3 second).
*              NOTE: delay is correct for 50MHz CPU clock with 8% accuracy.
*
* Input:       wNus - number of milliseconds.
*
* Globals:     None.
*
* Output:       None.
*
* Return:        None.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/06/11   ZHAOWEI10095452
*              - Created
*
****************************************************************************/
VOID zxUTILS_DelayNms(WORD16 wNms)
{
    WORD32 dwCountDown = (WORD32)(11100 * wNms);
      #if 0
    while (dwCountDown--)__asm__ __volatile__("" ::: "memory");
      #else
      while (dwCountDown--);
      #endif
} /* end of zxUTILS_DelayNms() */


/*FNC************************************************************************
*
* Function:    zxUTILS_DelayNus()
*
* Description: This function implements delay for at least specified
*              number of microseconds (1E-6 second).
*              NOTE: delay is correct for 50MHz CPU clock with 2% accuracy.
*
* Input:       wNus - number of microseconds.
*
* Globals:     None.
*
* Output:       None.
*
* Return:        None.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/06/07   Alex Semenyshev
*              - Created
*
****************************************************************************/
VOID zxUTILS_DelayNus(WORD16 wNus)
{
    WORD32 dwCountDown = (WORD32)(wNus * 10 + (wNus >> 1) + (wNus>> 3));
    #if 0
    while (dwCountDown--)__asm__ __volatile__("" ::: "memory");
      #else
      while (dwCountDown--);
      #endif
} /* end of zxUTILS_DelayNus() */

/*FNC************************************************************************
*
* Function:    zxUTILS_DelayNns()
*
* Description: This function implements delay for at least specified
*              number of nanoseconds (1E-9 second).
*              NOTE: delay is correct for 50MHz CPU clock.
*
* Input:       wNns - number of nanoseconds.
*
* Globals:     None.
*
* Output:       None.
*
* Return:        None.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/06/07   Alex Semenyshev
*              - Created
*
****************************************************************************/
VOID zxUTILS_DelayNns(WORD16 wNns)
{
    WORD32 dwCountDown = (WORD32)(wNns / 20);
    #if 0
    while (dwCountDown--)__asm__ __volatile__("" ::: "memory");
      #else
      while (dwCountDown--);
      #endif
} /* end of zxUTILS_DelayNns() */
/*lint +e722*/


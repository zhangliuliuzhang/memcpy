/*HDR************************************************************************
*
* Module:      ZXMW_UTILS
*
* File:           strings.c
*
* Description: This file implements reentrant string manipulation without
*              using dynamic memory allocation (using such functions as
*              sprintf() or itoa() increaes binary image size for more
*              than 25K).
*
* Interface:   zxUTILS_Int2HexString()
*              zxUTILS_GetNumOf()
*              zxUTILS_TrimLeft()
*              zxUTILS_TrimRight()
*              zxUTILS_Trim()
*              zxUTILS_CharToInt()
*
* Copyright (c) 2025. All rights reserved. ZTE CHINA, Inc.
*
* Revision History:
* --------------------------------------------------------------------------
* 2020/07/21    - refresh
*
****************************************************************************/

/* INCLUDES */
#include <string.h>
#include "utils.h"
#include "common.h"

CHAR g_acBuf[48];


/*FNC************************************************************************
*
* Function:    zxUTILS_Int2String()
*
* Description: This function converts converts an integer value to a
*              null-terminated string using the specified base and stores
*              the result in the array given by pcBuf parameter. The pcBuf
*              should be an array long enough to contain any possible value.
*               If base is 10 and value is considered as signed or unsigned
*              based on bSigned flag. Otherwise, bSigned flag is ignored
*              and value always considered as unsigned.
*              NOTE: this function is equivalent of itoa().
*
* Input:       dwVal - value to be converted to a string.
*              pcBuf - pointer to buffer where to store output string.
*              ucBase - numerical base used to represent the value as a string.
*
* Globals:     None.
*
* Output:       String representing value.
*
* Return:        Pointer to a string.
*
* Revision History:
* --------------------------------------------------------------------------
* 2020/07/21    - refresh
*
****************************************************************************/
CHAR * zxUTILS_Int2String(WORD32 dwVal, CHAR * pcBuf, BYTE ucBase, BOOLEAN bSigned)
{
    #if 0
    CHAR acDigit[] = "0123456789ABCDEF";
    CHAR * pcDigits = NULL;
    BYTE ucIdx = 0;

    /* check buffer pointer */
    if (!pcBuf)
    {
        return pcBuf;
    } /* end of if()*/

    /* set prefix */
    pcBuf[0] = 0;
    if (16 == ucBase)
    {
        strcpy(pcBuf, "0x");
        /* flag */
//        bSigned = FALSE;
    } /* end of if() */
    else if (10 == ucBase)
    {
        if (bSigned && (0L > (SWORD32)dwVal))
        {
            strcpy(pcBuf, "-");
            dwVal = (WORD32)(0L - dwVal);
        } /* end of if() */
    } /* end of else if() */
//    else
//    {
//        bSigned = FALSE;
//    }  /* end of else */
    pcDigits = pcBuf + strlen(pcBuf);

    /* make digits */
    do
    {
        pcDigits[ucIdx++] = acDigit[dwVal % ucBase];
        dwVal /= ucBase;
    } while (0 < dwVal);
    if (16 == ucBase)
    {
        while (8 > ucIdx)
        {
            pcDigits[ucIdx++] = '0';
        } /* end of while() */
    }  /* end of if() */
    pcDigits[ucIdx] = 0;

    /* revert digits */
    zxUTILS_ReverseString(pcDigits);
    #endif
    return pcBuf;

} /* end of zxUTILS_Int2String() */

/**************************************************************************
 *  º¯ÊýÃû³Æ   : zxUTILS_String2Int
 *  ¹¦ÄÜÃèÊö   : ×Ö·û´®×ªÕûÐÎ
**************************************************************************/
INT32 zxUTILS_String2Int(CHAR *str)
{
    CHAR flag = '+';
    INT32 res = 0;

    if(*str=='-')
    {
        ++str;
        flag = '-';
    }

    while(*str>=48 && *str<57)
    {
        res = 10*res+  *str++-48;
    }

    if(flag == '-')
    {
        res = -res;
    }

    return (INT32)res;
}

/**************************************************************************
 *  º¯ÊýÃû³Æ   : zxUTILS_Char2Int
 *  ¹¦ÄÜÃèÊö   : ×Ö·û×ªÕûÐÎ
**************************************************************************/
INT32 zxUTILS_Char2Int(CHAR str)
{
    INT32 res = 0;

    if( str >= 48 && str <= 57 )
    {
        res = str - 48;
    }
    else if( str >= 65 && str<=70 )
    {
        res = str - 65 + 10;
    }
    else if( str>=97 && str<=102 )
    {
        res = str - 97 + 10;
    }
    else
    {

    }

    return res;
}

/*FNC************************************************************************
*
* Function:    zxUTILS_GetNumOf()
*
* Description: This function returns number of specified bytes in buffer.
*
* Input:       pucBuf - pointer to buffer.
*              dwLen - size of buffer.
*              ucByte - byte to find in the buffer.
*
* Globals:     None.
*
* Output:       None.
*
* Return:        Number of bytes equal ucByte in the buffer.
*
* Revision History:
* --------------------------------------------------------------------------
* 2020/07/21    - refresh
*
****************************************************************************/
WORD32 zxUTILS_GetNumOf(BYTE * pucBuf, WORD32 dwLen, BYTE ucByte)
{
    WORD32 dwCount = 0;

    /* check buffer pointer */
    if (!pucBuf)
    {
        return dwCount;
    } /* end of if()*/

    /* reverse string */
    while (dwLen--)
    {
        if (pucBuf[dwLen] == ucByte)
        {
            dwCount++;
        } /* end of if() */
    }  /* end of while()*/

    return dwCount;
} /* end of zxUTILS_GetNumOf() */


CHAR *strncpy_s( CHAR *pcDst, WORD32 dwMaxSize, const CHAR *pcSrc, WORD32 dwCount )
{
    WORD32  dwIndex = 1, dwCopyNum = dwCount;
    CHAR   *pcResult = pcDst;

    if ( ( pcDst == NULL ) || ( pcSrc == NULL ) || ( dwMaxSize <= 1 ) || ( dwCount == 0 ) )
    {
        return pcResult;
    }


    if ( dwCount >= dwMaxSize )
    {
        dwCopyNum = dwMaxSize - 1;
    }

    while ( '\0' != ( *pcDst++ = *pcSrc++ ) )
    {
        /* when  *pcSrc string's number is longer than maxsize*/
        if ( dwIndex++ >= dwCopyNum )
        {
            *pcDst = '\0';

            return pcResult;
        }
    }

    /*  when  *pcSrc string's number is shorter than maxsize*/
    while ( dwIndex++ <= dwCopyNum )
    {
        *pcDst++ = '\0';
    }

    return pcResult;
}


CHAR *strcat_s( CHAR *pcDst, WORD32 dwMaxSize, const CHAR *pcSrc )
{
    WORD32  dwIndex = 0, dwCopyNum = 0;
    CHAR   *pcResult = pcDst;

    if ( ( pcDst == NULL ) || ( pcSrc == NULL ) || ( dwMaxSize == 0 ) )
    {
        return pcResult;
    }

    /* judge dwCopyNum & dwMaxSize*/
    while ( ( *pcDst++ != '\0' ) && ( ++dwCopyNum < dwMaxSize ) )
    {
    }

    if ( dwCopyNum >= dwMaxSize )
    {
        return pcResult;
    }
    dwCopyNum = dwMaxSize - dwCopyNum;

    pcDst --;
    while ( ( dwIndex++ < dwCopyNum ) && ( '\0' != ( *pcDst++ = *pcSrc++ ) ) )
    {
    }

    if ( dwIndex >= dwCopyNum )
    {
        *( pcResult + dwMaxSize - 1 ) = '\0';
    }
    return pcResult;
}


char *strcpy_s( char *pcDst, size_t dwMaxSize, const char *pcSrc )
{
    size_t  dwIndex = 0;
    char   *pcResult = pcDst;

    if ( ( pcDst == NULL ) || ( pcSrc == NULL ) || ( dwMaxSize == 0 ) )
    {
        return pcResult;
    }

    while ( ( dwIndex++ < dwMaxSize ) && ( '\0' != ( *pcDst++ = *pcSrc++ ) ) )
    {
    }

    if ( dwIndex >= dwMaxSize )
    {
        *( pcResult + dwMaxSize - 1 ) = '\0';
    }
    return pcResult;
}

//char *strcat_s( char *pcDst, size_t dwMaxSize, const char *pcSrc )
//{
//    size_t  dwIndex = 0, dwCopyNum = 0;
//    char   *pcResult = pcDst;
//
//    if ( ( pcDst == NULL ) || ( pcSrc == NULL ) || ( dwMaxSize == 0 ) )
//    {
//        return pcResult;
//    }
//
//    /* ï¿½ï¿½ï¿½ï¿½Ä¿ï¿½Ä´ï¿½ï¿½Ä³ï¿½ï¿½ï¿½ */
//    while ( ( *pcDst++ != '\0' ) && ( ++dwCopyNum < dwMaxSize ) )
//    {
//    }
//
//    if ( dwCopyNum >= dwMaxSize )
//    {
//        return pcResult;
//    }
//    dwCopyNum = dwMaxSize - dwCopyNum;  /* ï¿½ï¿½ï¿½ï¿½Ê£ï¿½ï¿½Ä»ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ */
//
//    pcDst --;
//    while ( ( dwIndex++ < dwCopyNum ) && ( '\0' != ( *pcDst++ = *pcSrc++ ) ) )
//    {
//    }
//
//    if ( dwIndex >= dwCopyNum )
//    {
//        *( pcResult + dwMaxSize - 1 ) = '\0';
//    }
//    return pcResult;
//}

//char *strncpy_s( char *pcDst, size_t dwMaxSize, const char *pcSrc, size_t dwCount )
//{
//    size_t  dwIndex = 1, dwCopyNum = dwCount;
//    char   *pcResult = pcDst;
//
//    if ( ( pcDst == NULL ) || ( pcSrc == NULL ) || ( dwMaxSize <= 1 ) || ( dwCount == 0 ) )
//    {
//        return pcResult;
//    }
//
//    /* ï¿½ï¿½ï¿½ã¿½ï¿½ï¿½ï¿½ï¿½ï¿½Ö·ï¿½ï¿½ï¿½ï¿½È£ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ */
//    if ( dwCount >= dwMaxSize )
//    {
//        dwCopyNum = dwMaxSize - 1;
//    }
//
//    while ( '\0' != ( *pcDst++ = *pcSrc++ ) )
//    {
//        /* ï¿½Ð¶Ï¿ï¿½ï¿½ï¿½ï¿½Ö·ï¿½ï¿½ï¿½ï¿½Ç·ï¿½ï¿½ï¿½ï¿½dwCopyNumï¿½ï¿½ï¿½ï¿½ï¿½Ú¾ï¿½ï¿½Ë³ï¿½ */
//        /* ï¿½ï¿½ï¿½ï¿½ï¿½Ð¶Ï·ï¿½ï¿½ï¿½Ñ­ï¿½ï¿½ï¿½ï¿½ï¿½Ú£ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½Ð¶ï¿½Ç°ï¿½Ñ¾ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½Ò»ï¿½Î£ï¿½ï¿½ï¿½ï¿½ï¿½iï¿½ï¿½ï¿½ï¿½ÖµÎª1 */
//        if ( dwIndex++ >= dwCopyNum )
//        {
//            *pcDst = '\0';
//
//            return pcResult;
//        }
//    }
//
//    /* ï¿½ï¿½ï¿½ï¿½ï¿½Ä´ï¿½ï¿½ï¿½ï¿½ï¿½Îªï¿½Ë±ï¿½ï¿½ÖºÍ¿âº¯ï¿½ï¿½ï¿½ÐµÄ½ï¿½ï¿½ï¿½Ò»ï¿½Â£ï¿½ï¿½ï¿½ï¿½ï¿½Ô´ï¿½ï¿½ï¿½ï¿½ï¿½ï¿½Ð¡ï¿½ï¿½dwCopyNumï¿½ï¿½Ê£ï¿½à²¿ï¿½ï¿½È«ï¿½ï¿½ï¿½ï¿½0 */
//    while ( dwIndex++ <= dwCopyNum )
//    {
//        *pcDst++ = '\0';
//    }
//
//    return pcResult;
//}

char *strncat_s( char *pcDst, size_t dwMaxSize, const char *pcSrc, size_t dwCount )
{
    size_t  dwIndex = 1, dwCopyNum = 0;
    char   *pcResult = pcDst;

    if ( ( pcDst == NULL ) || ( pcSrc == NULL ) || ( dwMaxSize == 0 ) || ( dwCount == 0 ) )
    {
        return pcResult;
    }

    /* judge dwCopyNum & dwMaxSize*/
    while ( ( *pcDst++ != '\0' ) && ( ++dwCopyNum < dwMaxSize ) )
    {
    }

    if ( dwCopyNum >= dwMaxSize )
    {
        return pcResult;
    }

    dwCopyNum = dwMaxSize - dwCopyNum;


    if ( dwCount >= dwCopyNum )
    {
        dwCopyNum = dwCopyNum - 1;
    }
    else
    {
        dwCopyNum = dwCount;
    }

    if(dwCopyNum == 0)
    {
       return pcResult;
    }

    pcDst --;
    while ( '\0' != ( *pcDst++ = *pcSrc++ ) )
    {
        /* when  *pcSrc string's number is longer than maxsize*/
        if ( dwIndex++ >= dwCopyNum )
        {
            *pcDst = '\0';

            return pcResult;
        }
    }

    /* when  *pcSrc string's number is shorter than maxsize*/
    while ( dwIndex++ <= dwCopyNum )
    {
        *pcDst++ = '\0';
    }

    return pcResult;
}

int memcpy_s(void * dest, long unsigned int destSize,
        const void * src, long unsigned int count)
{
    if (dest == NULL) {
        return EINVAL;
    }

    if (destSize > RSIZE_MAX) {
        return ERANGE;
    }

    if (src == NULL) {
        memset(dest, 0, destSize);
        return EINVAL;
    }

    if (destSize < count) {
        memset(dest, 0, destSize);
        return ERANGE;
    }

    memcpy(dest, src, count);

    return 0;
}

int memset_s(void *dest, long unsigned int destSize, int c, long unsigned int count)
{
    if (dest == NULL) 
    {
        return EINVAL;
    }

    if (destSize > RSIZE_MAX) 
    {
        return ERANGE;
    }

    if (destSize < count) 
    {
        memset(dest, 0, destSize);
        return ERANGE;
    }
    memset(dest, c, count);
    return 0;
}

/*HDR************************************************************************
*
* Module:      ZXMW_UTILS
*
* File:           math.c
*
* Description: This file implements useful math functions to avoid
*              extra memory consuption by standard math library.
*
* Interface:   zxUTILS_Log2()
*              zxUTILS_Pow()
*
* Copyright (c) 2011. All rights reserved. ZTE USA, Inc.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/06/07   Alex Semenyshev
*              - Created
*
****************************************************************************/

/* INCLUDES */
#include <utils.h>

#if 0
/*FNC************************************************************************
*
* Function:    zxUTILS_Log2()
*
* Description: This function implements calculation of binary logarithm
*              and returns value as integer.
*              Physical meanning of this is number of bits of the value
*              plus 1.
*
* Input:       fX - Value.
*
* Globals:     None.
*
* Output:       None.
*
* Return:        Binary logarithm.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/06/20   Alex Semenyshev
*              - Created
* 2011/11/08   Jiangbo
*              - Add protection since this function works only for integer
*                value bigger than 0.
*
****************************************************************************/
BYTE zxUTILS_Log2(WORD32 dwX)
{
    BYTE ucResult = (BYTE)31;

    ASSERT((WORD32)0 != dwX);

    while (!(dwX & (WORD32)0x80000000))
    {
        dwX = dwX << 1;
        ucResult--;
    } /* end of while() */

    return ucResult;
} /* end of zxUTILS_Log2() */


/*FNC************************************************************************
*
* Function:    zxUTILS_Pow()
*
* Description: This function implements calculation of base raised to the
*              power exponent.
*
* Input:       dwBase - base value.
*               dwExp - exponent value.
*
* Globals:     None.
*
* Output:       None.
*
* Return:        Base raised to the power exponent.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/06/20   Alex Semenyshev
*              - Created
* 2011/11/08   Jiangbo
*              - Add special case for X^0.
*
****************************************************************************/
WORD32 zxUTILS_Pow(WORD32 dwBase, WORD32 dwExp)
{
    WORD32 dwResult = dwBase;

    if ((WORD32)0 == dwExp)
    {
        return (WORD32)1;
    } /* end of if() */

    while ((-- dwExp) > (WORD32)0)
    {
        dwResult *= dwBase;
    } /* end of while() */

    return dwResult;
} /* end of zxUTILS_Pow() */
#endif
/*FNC************************************************************************
*
* Function:    zxUTILS_Interpolate()
*
* Description: This function implements linear interpolation
*
* Input:       Xcur - the current value of X.
*           Xmin - the minimum value of X.
*           Xmax - the maximum value of X.
*           Ymin - the minimum value of Y.
*           Ymax - the maximum value of Y.
*
* Globals:   None.
*
* Output:       None.
*
* Return:    the result value of interpolate.
*
* Revision History:
* --------------------------------------------------------------------------
* 2014/12/50   XuGang10167640
*              - Created
*
****************************************************************************/
SWORD32 zxUTILS_Interpolate(SWORD32 Xcur,SWORD32 Xmin,SWORD32 Ymin,SWORD32 Xmax,SWORD32 Ymax)
{
    if(Xmax == Xmin)
    {
        return Ymin;
    }
    else
    {
        return (Ymin + ((Xcur - Xmin) * (Ymax - Ymin)) / (Xmax - Xmin));
    }
}




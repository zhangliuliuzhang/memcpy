#ifndef _TYPEDEF_H_
#define _TYPEDEF_H_

#include <stddef.h>

typedef unsigned char  BYTE;
typedef unsigned short WORD16;
typedef unsigned int   WORD32;

typedef char           CHAR;
typedef signed char    SHORT;
typedef short          SWORD16;
typedef int            SWORD32;

typedef void           VOID;
typedef unsigned char  BOOLEAN;
typedef float          FLOAT;
typedef double         DOUBLE;

typedef unsigned long long    UINT64;
typedef unsigned int   UINT32;
typedef int            INT32;
typedef unsigned short UINT16;
typedef short          INT16;
typedef unsigned char  UCHAR;
typedef char           CHAR;
typedef unsigned char  UINT8;
typedef char           BOOL;

typedef enum
{
    E_RESET = 0,
    E_SET = !E_RESET,
} e_FlagStat;

typedef enum
{
    E_ON = 0,
    E_OFF = !E_ON,
} e_LedStat;

#ifndef TRUE
#define TRUE  ((BOOLEAN) 1)
#endif

#ifndef FALSE
#define FALSE ((BOOLEAN) 0)
#endif

#endif


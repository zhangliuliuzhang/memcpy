/*HDR************************************************************************
*
* Module:      ZXMW_UTILS
*
* Description: This is public header for ZXMW_UTILS module that defines
*              common data structures and functions used across SRU
*              software.
*
* Copyright (c) 2011. All rights reserved. ZTE USA, Inc.
*
* Revision History:
* --------------------------------------------------------------------------
* 2011/05/03   Alex Semenyshev
*              - Created
*
****************************************************************************/

#ifndef __UTILS_H_FILE
#define __UTILS_H_FILE

#include "typedef.h"
#include "gd32f4xx.h"

/* DEFINITIONS */
/* byte swap */
#define SWAP16(x)    ((WORD16)(((x) & (WORD16)0x00ff) <<  8)  | \
                    (((x) & (WORD16)0xff00) >>  8))

#define SWAP32(x)    ((WORD32)(((x) & (WORD32)0x000000ff) << 24) | \
                    (WORD32)(((x) & (WORD32)0x0000ff00) <<  8)  | \
                    (WORD32)(((x) & (WORD32)0x00ff0000) >>  8)  | \
                    ((WORD32)(x)) >> 24)
/* bit manipulation macros */
#define BITMASK_SET(x, y)        ((x) |= (y))
#define BITMASK_CLR(x, y)        ((x) &= ~(y))
#define BITMASK_IS_SET(x, y)    (((x) & (y)) == (y))

#define ABS(x)            (((x) > 0) ? (x) : -(x))
#ifndef MAX
#define MAX(x1, x2)        (((x1) > (x2)) ? (x1) : (x2))
#endif
#ifndef MIN
#define MIN(x1, x2)        (((x1) < (x2)) ? (x1) : (x2))
#endif
#define IN_RANGE(x, x1, x2)    ((((x) >= (x1)) && ((x) <= (x2))) || (((x) >= (x2)) && ((x) <= (x1)))) ? TRUE : FALSE
#define POW2(x) ((x) * (x))
#define POW4(x) ((x) * (x) * (x) * (x))

/* reverse bit order */
#define REVERS_8_BITS(x)    (BYTE)((BYTE)((((x) * 0x0802LU & 0x22110LU) | ((x) * 0x8020LU & 0x88440LU)) * 0x10101LU >> 16))

#define REVERS_16_BITS(x)    (WORD16)(REVERS_8_BITS((x) & 0xFF) << 8) | REVERS_8_BITS(((x) >> 8) & 0xFF)

#define REVERS_32_BITS(x)    (WORD32)(REVERS_8_BITS((x) & 0xFF) << 24) | (WORD32)(REVERS_8_BITS(((x) >> 16) & 0xFF) << 8) | \
                            (WORD32)(REVERS_8_BITS(((x) >> 8) & 0xFF) << 16) | REVERS_8_BITS(((x) >> 24) & 0xFF)

/* "in range" verification */
#define IS_IN_RANGE(x, x1, x2)    ((((x) >= (x1)) && ((x) <= (x2))) || (((x) >= (x2)) && ((x) <= (x1)))) ? TRUE : FALSE
#define IS_BEFORE_RANGE(x, x1, x2)    ((((x1) > (x2)) && ((x) > (x1))) || (((x1) < (x2)) && ((x) < (x1)))) ? TRUE : FALSE
#define IS_AFTER_RANGE(x, x1, x2)    ((((x1) > (x2)) && ((x) < (x2))) || (((x1) < (x2)) && ((x) > (x2)))) ? TRUE : FALSE


/* linear interpolation */
//#define INTERPOLATE_LINEAR(Xcur, Xmin, Ymin, Xmax, Ymax) ((SWORD32)(Ymin) + (((SWORD32)(Xcur) - (SWORD32)(Xmin)) * ((SWORD32)(Ymax) - (SWORD32)(Ymin))) / ((SWORD32)(Xmax) - (SWORD32)(Xmin)))

/* simple math macros */
#define ABS(x) (((x) > 0) ? (x) : -(x))
#define MAX_OF(x1, x2) (((x1) > (x2)) ? (x1) : (x2))
#define MIN_OF(x1, x2) (((x1) < (x2)) ? (x1) : (x2))
#define POW2(x) ((x) * (x))
#define POW4(x) ((x) * (x) * (x) * (x))


/* system assert */
#define ASSERT(bExpression)     if (!(bExpression)) zxUTILS_Assert(__FILE__, (WORD32)__LINE__)

#define CRC_TABLE_SIZE              (256)

/* FUNCTION PROTOTYPES */
/* from asset.c */
//VOID zxUTILS_Assert(CHAR * pcFile, WORD32 dwLine);

/* from crc32.c */
unsigned int CalculateCrc32(unsigned int ulInitVal, const unsigned char *pucData, unsigned int ulLen);
UINT32 zxUTILS_Crc32(UCHAR* buf, UINT32 size, UINT32 crc);
BYTE zxUTILS_CheckSum(BYTE *data, UINT32 dataLen);
/* from crc8.c */
unsigned char CalculateCrc8(const unsigned char *data, unsigned int num, unsigned char crcStart);

/* from strings.c */
CHAR * zxUTILS_Int2String(WORD32 dwVal, CHAR * pcBuf, BYTE ucBase, BOOLEAN bSigned);
INT32 zxUTILS_String2Int(CHAR *str);
INT32 zxUTILS_Char2Int(CHAR str);
WORD32 zxUTILS_GetNumOf(BYTE * pucBuf, WORD32 dwLen, BYTE ucByte);

/* from time.c */
VOID zxUTILS_DelayNms(WORD16 wNms);
VOID zxUTILS_DelayNus(WORD16 wNus);
VOID zxUTILS_DelayNns(WORD16 wNns);

/* from math.c */
//BYTE zxUTILS_Log2(WORD32 dwX);
//WORD32 zxUTILS_Pow(WORD32 dwBase, WORD32 dwExp);
SWORD32 zxUTILS_Interpolate(SWORD32 Xcur,SWORD32 Xmin,SWORD32 Ymin,SWORD32 Xmax,SWORD32 Ymax);
CHAR *strncpy_s( CHAR *pcDst, WORD32 dwMaxSize, const CHAR *pcSrc, WORD32 dwCount );
CHAR *strcat_s( CHAR *pcDst, WORD32 dwMaxSize, const CHAR *pcSrc );

char *strcpy_s( char *pcDst, size_t dwMaxSize, const char *pcSrc );
//char *strcat_s( char *pcDst, size_t dwMaxSize, const char *pcSrc );
//char *strncpy_s( char *pcDst, size_t dwMaxSize, const char *pcSrc, size_t dwCount );
char *strncat_s( char *pcDst, size_t dwMaxSize, const char *pcSrc, size_t dwCount );

#endif /* end of #ifndef __UTILS_H_FILE */


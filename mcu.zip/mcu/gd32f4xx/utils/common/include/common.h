#ifndef __COMMON_H_
#define __COMMON_H_

#include <typedef.h>
#include "uartprint.h"

#ifdef COMMON_OK
#undef COMMON_OK
#endif
#define COMMON_OK       ( 0 )

#ifdef COMMON_ERROR
#undef COMMON_ERROR
#endif
#define COMMON_ERROR            ( (WORD32)0xFFFFFFFF )

#define ERROR_INVALID_PARA      ( (UINT32)0xFF000001 )
#define ERROR_NULL_POINTER      ( (UINT32)0xFF000002 )
#define ERROR_OUT_OF_RANGE      ( (UINT32)0xFF000003 )
#define ERROR_FUNC_NOT_SUPPORT  ( (UINT32)0xFF000004 )

#define LENTH_1K        (1024)
#define LENTH_4K        (4096) /* 4*1024 */
#define LENTH_64K      (0x10000) /* 64*1024 */
#ifndef     ULONG_MAX
#define     ULONG_MAX               (0xffffffff)
#endif

#ifndef     LONG_MAX
#define     LONG_MAX               (0x7fffffff)
#endif

#ifndef min
#define min(a, b)       ((a) < (b) ? (a) : (b))
#endif

#ifndef max
#define max(a, b)       (((a) > (b)) ? (a) : (b))
#endif

/* 常用位操作相关宏定义 */
/* 根据所在位域的偏移，计算出该位域对应的掩码 */
#define BITS_MASK_GET(bitsoff, numbit) \
(((0x01 << (numbit)) - 1) << (bitsoff))


/* 从指定变量或数据中提取出指定位域的数据 */
#define BITS_GET(val, bitoff, numbit) \
((val) & BITS_MASK_GET(bitoff, numbit))

/* 修改指定数据中的位域值 */
#define BITS_SET(var, val, bitoff, numbit) \
((var) = (((var) & (~ BITS_MASK_GET(bitoff, numbit))) | (((val) << (bitoff)) & (BITS_MASK_GET(bitoff, numbit)))))

/* 指针非空检查宏，打印错误，并返回 */
#define INPUT_POINTER_CHECK_RETURN(ppointer)                              \
    if (NULL == ppointer)                                                 \
    {                                                                     \
        UARTprintf("%s:Input Pointer is NULL!\n",__func__);               \
        return ;                                        \
    }

#define INPUT_POINTER_CHECK(ppointer)    \
    if( NULL == ppointer )                 \
    {                                      \
        return ERROR_NULL_POINTER;           \
    }

#define    RETURN_CHECK(ret)  if(ret != COMMON_OK) { \
                                UARTprintf("EPLD Command Execution error!\n");   \
                                return ret; \
                                }

#define NELEMENTS(a)     (sizeof(a) / sizeof(a[0]))
#define BIT_SET(n)   (1UL << (n))    /* 对bit[n]掩码 */
#define BIT_REV(n)   (~(1UL << (n)))
/* 设置某个bit 为 1 */
#define VAR_BIT_SET(var,bitno)  (var |= (1 << (bitno)))
/* 设置某个bit 为 0 */
#define VAR_BIT_CLR(var,bitno)  (var &= ~(1 << (bitno)))
/* 指定数据中的位域值置1 */
#define BIT_FIELD_MASK_SET(bitoff, numbit)  (((0x01 << (numbit)) - 1) << (bitoff))

/* 从指定变量或数据中提取出指定位域的数据，并把该位域值右对齐 */
#define BITS_RIGHT_JUST_GET(val, bitoff, numbit) \
(((val) >> (bitoff)) & ((0x01 << (numbit)) - 1))

#define CHECK_BIT(n, pos) ((n) & (1 << (pos)))  /* 判断第pos位是否为1 */

#define RX_MODE           (0)
#define TX_MODE           (1)
#define TX0_RX1_MODE      (2)
#define TX1_RX0_MODE      (3)

#define SWITCH_OFF      (0)
#define SWITCH_ON       (1)
#define SWITCH_ON_FDD   (2)

#define LED_SWITCH_ON      (0)
#define LED_SWITCH_OFF     (1)

#define ALARN_STATUS      (1)
#define NO_ALARN_STATUS   (0)

#define DATA_INVALUE      (1)
#define DATA_VALUE        (0)

#define INVALID_STATUS                     ((UINT32)0xFFFFFFFF)

#define BSP_MAX_CHAN_NUM       (2)

#define VER_NOT_UPDATA_ACTION_STATUS       (0)
#define VER_UPDATA_ACTION_STATUS           (1)
#define VER_CRC_CHK_INIT_VAL                (0xFFFFFFFF)

#define VER_LENTH                      (44)
#define BOOT_VER_LENTH                      (32)

/* 子端告警掩码 */
#define    PWR_FPGA_VIN_DOWN_ALARM         (0x01 << 0)    /* 掉电告警 */
#define    PWR_FPGA_48V_UV_ALARM           (0x01 << 1)    /* 电源48V欠压告警 */
#define    PWR_FPGA_BOARD_UV_ALARM         (0x01 << 2)    /* 单板电源欠压告警 */
#define    DAC_STATE_ALARM                 (0x01 << 3)    /* DAC 异常告警*/
#define    PMOS_0_ALARM                    (0x01 << 4)    /* PMOS0告警 */
#define    PMOS_1_ALARM                    (0x01 << 5)    /* PMOS1告警 */
/* bit6 预留 */
/* bit7 预留 */
#define    PA_N8V_ALARM                    (0x01 << 8)    /* -8V告警（实时） */
#define    PA_N8V_HANDLE_ALARM             (0x01 << 9)    /* -8V告警（处理后） */
#define    PLL_LOCK_ALARM                  (0x01 << 10)    /* PLL失锁（实时） */
#define    PLL_LOCK_ALARM_ANTI_JITTER      (0x01 << 11)    /* PLL失锁（防抖），该告警无防抖，上报实时告警 */
#define    SYN_FR_LOST_ALARM               (0x01 << 12)    /* 同步帧头丢失告警 */
#define    ANT_MCU_120V_UV_ALARM           (0x01 << 13)   /* 天线120V欠压告警 */
#define    LEAD_WATER_ALARM                (0x01 << 14)   /* 进水告警（实时） */
#define    LEAD_WATER_ALARM_ANTI_JITTER    (0x01 << 15)   /* 进水告警（防抖后）*/

#define LED_CTRL_TYPE_FLICKER    (2)
#define LED_CTRL_TYPE_ON         (1)
#define LED_CTRL_TYPE_OFF        (0)
#define LED_RUN_CTRL             (1)
#define LED_ALM_CTRL             (2)
#define LED_ON_TIME_FAST_FLICKER   (1)
#define LED_ON_TIME_NORMAL_FLICKER (3)

#define EINVAL        (22)    /* Invalid argument */
#define ERANGE        (34)   /* Math result not representable */
#ifndef SIZE_MAX
#define SIZE_MAX      (18446744073709551615UL)
#endif
#ifndef RSIZE_MAX
#define RSIZE_MAX (SIZE_MAX >> 1)
#endif
#ifndef VER_TYPE_CPU
#define VER_TYPE_CPU             (0)
#endif
#ifndef VER_TYPE_FPGA
#define VER_TYPE_FPGA            (1)
#endif
#ifndef VER_TYPE_SECOND_BOOT
#define VER_TYPE_SECOND_BOOT     (2)
#endif

int memset_s(void *dest, long unsigned int destSize, int c, long unsigned int count);
int memcpy_s(void * dest, long unsigned int destSize, const void * src, long unsigned int count);

#define STRTOUL_CHECK(Ret)                                      \
    if ((ULONG_MAX == (Ret)))                                   \
    {                                                           \
        UARTprintf("%s: strtoul return error!\n", __func__); \
    }

#define STRTOL_CHECK(Ret)                                       \
    if ((LONG_MAX == (Ret)))                                    \
    {                                                           \
        UARTprintf("%s: strtol return error!\n", __func__);  \
    }
#endif

/*****************************************************************************
* 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rftable_common.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了校准表公共信息内部的定义的头文件定义
* 注意事项 : 无
* 作    者 : 崔文会
* 创建日期 : 2014-06-20 17:00:00
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 崔文会
* 修改日戳: 2014-06-20 17:00:00
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef RFTABLE_COMMON_H_
#define RFTABLE_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "stdio.h"
#include "typedef.h"
/**************************************************************************
*                        宏常量                                          *
**************************************************************************/
#define TBL_CALI_TABLE_COMMON_LEN                   25
#ifndef NEW_MULTIBAND_PROPER_RFTBL
#define TBL_MAX_CHAN_FREQBAND (3UL)
#else
#define TBL_MAX_CHAN_FREQBAND (3UL)
#endif		
#define TBL_MAX_CHAN_CLASSNUM                       3
#define TBL_PATH_NUM                                (1)

#if defined (_UP_128_) || defined (_UP_128_S_)
#define TBL_MAX_PA_CHAN_NUM                         128
#define TBL_MAX_TX_CHAN_NUM                         128
#define TBL_MAX_RX_CHAN_NUM                         128
#else
#define TBL_MAX_PA_CHAN_NUM                         2//64
#define TBL_MAX_TX_CHAN_NUM                         2//64
#define TBL_MAX_RX_CHAN_NUM                         2//64
#endif

#define TBL_MAX_LINE_LEN                            1024
#define TBL_MAX_FREQ_RECORD_NUM                     2500
#define TBL_MAX_FREQ_RECORD_NUM_HF               30000
#define TBL_MAX_VOLT_RECORD_NUM                     10
#define TBL_MAX_TEMP_RECORD_NUM                     40

#define TBL_PA_FREQ_GROUP_MAX                       5       /*支持的最大频率组*/
#define TBL_PA_FREQ_GROUP_NUM                       3       /*发射频点、反馈频点、接收频点，共三个点*/

#define TBL_DVGA_FREQ_GROUP_MAX                     5       /*支持的最大频率组*/
#define TBL_DVGA_FREQ_GROUP_NUM                     3       /*发射频点、反馈频点、接收频点，共三个点*/

#define TBL_SEARCH_KEYWORD_NO_ORDER                 0 /*不必依照次序搜索*/
#define TBL_SEARCH_KEYWORD_ORDER                    1 /*必须依照次序搜索*/

#define TBL_SEARCH_KEYWORD_DEFAULT                  0 /*默认未搜索到*/
#define TBL_SEARCH_KEYWORD_SUCC                     1 /*搜素到关键字段*/

#define TBL_KEYWORD_PUBLIC_PROP                     0 /*公共的关键字段*/
#define TBL_KEYWORD_PRIVATE_PROP                    1 /*私有的关键字段，例如通道相关字段*/
#define TBL_KEYWORD_OTHER_PROP                      2 /*其它的关键字段*/

/* 文本处理 */
#define TBL_CALI_FILE_NAME                          80
#define TBL_KEYWORD_LEN                             160
#define TBL_COMMENT_CHAR                            '#'
#define TBL_FILE_SYS                                0
#define TBL_PROPECT_SYS                             1
#define TBL_FILE_DIR                                "/ata/"

#ifndef OUT
#define OUT
#endif

#ifndef IN
#define IN
#endif

#define TBL_LOAD_UNLOAD                             -1
#define TBL_LOAD_END                                0
#define TBL_LOAD_FAIL                               1
#define TBL_LOAD_SUCC                               2

#define TBL_PA_VOLT_GAIN_ITEM                       5
#define TBL_PA_DAC_SET_ITEM                         (4*5)

#define V1                                          1     /*校准文件版本号V1*/
#define V6                                          6     /*校准文件版本号V6*/
#define V7                                          7     /*校准文件版本号V7*/
#define V10                                         10     /*校准文件版本号V7*/ 

#define SampleRate_100M                        122.88    /* 100MNR的基带下的采样率是122.88Mbps*/


typedef enum e_TblTypeDefine
{
    TBL_KIND_OF_TXGAIN =0,
    TBL_KIND_OF_TxFWD,    
    TBL_KIND_OF_TxREV,
    TBL_KIND_OF_TXIQ,
    TBL_KIND_OF_TXCALI,
    TBL_KIND_OF_VSWRPARAM,
    TBL_KIND_OF_VSWRPROC,
    TBL_KIND_OF_RXRSSI,
    TBL_KIND_OF_RXCALI,
    TBL_KIND_OF_PAVOLTGAIN,
    TBL_KIND_OF_PADACSET,
    TBL_KIND_OF_PATEMPGAIN,
    TBL_KIND_OF_TRXTEMPGAIN,
    TBL_KIND_OF_PATEMPALM,
    TBL_KIND_OF_TRXTEMPALM,  
    TBL_KIND_OF_PWRTEMPALM,
    TBL_KIND_OF_CPATT,
    TBL_KIND_OF_RXAMPGAIN,
    TBL_KIND_OF_PABASICINFO,
    TBL_KIND_OF_PADRAINADJ,
    TBL_KIND_OF_PAGAINTEMPTBL,
    TBL_KIND_OF_PARL,
    TBL_KIND_OF_CALPHASE,
    TBL_KIND_OF_CALGAIN,
    TBL_KIND_OF_FILTERGAIN,
    TBL_KIND_OF_PAUAMP,
    TBL_KIND_OF_PAUPHASE,
    TBL_KIND_OF_PAURELATIVEAMP,
    TBL_KIND_OF_PAURELATIVEPHASE,  
    TBL_KIND_OF_PACURRCALI,
    TBL_KIND_OF_MBAGAIN,
    TBL_KIND_OF_IDEALCODEBOOK,
    TBL_KIND_OF_TXCALCODEBOOK,
    TBL_KIND_OF_RXCALCODEBOOK,
    TBL_KIND_OF_TXOPENRL,
    TBL_KIND_OF_TXGAIN_HW,
    TBL_KIND_OF_SINGLECODEBOOK,
    TBL_KIND_OF_PWRCALI,
    TBL_KIND_OF_PAENSAVADJ,
    TBL_KIND_OF_TXACCAL,
    TBL_KIND_OF_RXISOCAL,
    TBL_KIND_OF_IDEALACRFCODEBOOK,
    TBL_KIND_OF_IDEALAMPRFCODEBOOK,
    TBL_KIND_OF_IDEALDVDHRFCODEBOOK,
    TBL_KIND_OF_IDEALNBRFCODEBOOK,
    TBL_KIND_OF_IDEALWBRFCODEBOOK,
    TBL_KIND_OF_RXLOOKUPTAB,
    TBL_KIND_OF_TXLOOKUPTAB,
    TBL_KIND_OF_FILTERDELAY,
    TBL_KIND_OF_ANTDELAY,
    TBL_KIND_OF_RX0DELAY, 
    TBL_KIND_OF_TXGAINERROR,
    TBL_KIND_OF_TxFWD_DB,
    TBL_KIND_OF_DVGATEMPGAIN,
    TBL_KIND_OF_UDC,//UDC
    TBL_KIND_OF_PMIPHASEINFO,
    TBL_KIND_OF_DSAATT,
    TBL_KIND_OF_TXFWDANALOG,
    TBL_KIND_OF_TXREVANALOG,
    TBL_KIND_OF_RxREV,
    TBL_KIND_OF_RFBRIDGE,
    NUM_TBL_KIND_NUM,
} eTblTypeDefine;

#define TBL_TXGAIN_PRN             (0x01<<TBL_KIND_OF_TXGAIN)
#define TBL_TXFWD_PRN              (0x01<<TBL_KIND_OF_TxFWD)
#define TBL_TXREV_PRN              (0x01<<TBL_KIND_OF_TxREV)
#define TBL_TXIQ_PRN               (0x01<<TBL_KIND_OF_TXIQ)
#define TBL_TXCALI_PRN             (0x01<<TBL_KIND_OF_TXCALI)
#define TBL_VSWRPARAM_PRN          (0x01<<TBL_KIND_OF_VSWRPARAM)
#define TBL_RXRSSI_PRN             (0x01<<TBL_KIND_OF_RXRSSI)
#define TBL_RXCALI_PRN             (0x01<<TBL_KIND_OF_RXCALI)
#define TBL_VSWRPROC_PRN           (0x01<<TBL_KIND_OF_VSWRPROC)
#define TBL_PAVOLTGAIN_PRN         (0x01<<TBL_KIND_OF_PAVOLTGAIN)
#define TBL_PADACSET_PRN           (0x01<<TBL_KIND_OF_PADACSET)
#define TBL_PATEMPGAIN_PRN         (0x01<<TBL_KIND_OF_PATEMPGAIN)
#define TBL_TRXTEMPGAIN_PRN        (0x01<<TBL_KIND_OF_TRXTEMPGAIN)
#define TBL_PATEMPALM_PRN          (0x01<<TBL_KIND_OF_PATEMPALM)
#define TBL_TRXTEMPALM_PRN         (0x01<<TBL_KIND_OF_TRXTEMPALM)
#define TBL_PWRTEMPALM_PRN         (0x01<<TBL_KIND_OF_PWRTEMPALM)
#define TBL_CPATT_PRN              (0x01<<TBL_KIND_OF_CPATT)
#define TBL_RXAMPGAIN_PRN          (0x01<<TBL_KIND_OF_RXAMPGAIN)
#define TBL_PABASICINFO_PRN        (0x01<<TBL_KIND_OF_PABASICINFO)
#define TBL_PADRAINADJ_PRN         (0x01<<TBL_KIND_OF_PADRAINADJ)
#define TBL_PAGAINTEMPTBL_PRN      (0x01<<TBL_KIND_OF_PAGAINTEMPTBL)
#define TBL_PARL_PRN               (0x01<<TBL_KIND_OF_PARL)
#define TBL_CALPHASE_PRN           (0x01<<TBL_KIND_OF_CALPHASE)
#define TBL_CALGAIN_PRN            (0x01<<TBL_KIND_OF_CALGAIN)
#define TBL_FILTERGAIN_PRN         (0x01<<TBL_KIND_OF_FILTERGAIN)
#define TBL_PAUAMP_PRN             (0x01<<TBL_KIND_OF_PAUAMP)
#define TBL_PAUPHASE_PRN           (0x01<<TBL_KIND_OF_PAUPHASE)
#define TBL_PAURELATIVEAMP_PRN     (0x01<<TBL_KIND_OF_PAURELATIVEAMP)
#define TBL_PAURELATIVEPHASE_PRN   (0x01<<TBL_KIND_OF_PAURELATIVEPHASE)
#define TBL_PACURCALI_PRN          (0x01<<TBL_KIND_OF_PACURRCALI)
#define TBL_MBAGAIN_PRN            (0x01<<TBL_KIND_OF_MBAGAIN)
#define TBL_IDEALCODEBOOK_PRN      (0x01<<TBL_KIND_OF_IDEALCODEBOOK)
#define TBL_TXCALCODEBOOK_PRN   TBL_IDEALCODEBOOK_PRN
#define TBL_RXCALCODEBOOK_PRN  TBL_IDEALCODEBOOK_PRN
#define TBL_TXOPENRL_PRN             TBL_PARL_PRN /*跟刘航确认，二者互斥*/
#define TBL_SINGLECODEBOOK_PRN  TBL_KIND_OF_SINGLECODEBOOK
#define TBL_PWRCALI_PRN         TBL_PARL_PRN
#define TBL_PAENSAVADJ_PRN         (0x01<<TBL_KIND_OF_PADACSET)
#define TBL_RXREV_PRN           TBL_TXREV_PRN

/*
注意：1.新的文件不能在上面添加，否则造成32位溢出告警;
      2.新的文件只能在下面添加，注意需要强制转换成UINT64;
*/
#define TBL_TXACCAL_PRN          (UINT64)((UINT64)0x01<<TBL_KIND_OF_TXACCAL)
#define TBL_RXISOCAL_PRN         (UINT64)((UINT64)0x01<<TBL_KIND_OF_RXISOCAL)


#define TBL_IDEALACRFCODEBOOK_PRN    (UINT64)((UINT64)1<<TBL_KIND_OF_IDEALACRFCODEBOOK  )
#define TBL_IDEALAMPRFCODEBOOK_PRN   (UINT64)((UINT64)1<<TBL_KIND_OF_IDEALAMPRFCODEBOOK )
#define TBL_IDEALDVDHRFCODEBOOK_PRN  (UINT64)((UINT64)1<<TBL_KIND_OF_IDEALDVDHRFCODEBOOK)
#define TBL_IDEALNBRFCODEBOOK_PRN    (UINT64)((UINT64)1<<TBL_KIND_OF_IDEALNBRFCODEBOOK  )
#define TBL_IDEALWBRFCODEBOOK_PRN    (UINT64)((UINT64)1<<TBL_KIND_OF_IDEALWBRFCODEBOOK  )
#define TBL_RXLOOKUPTAB_PRN          (UINT64)((UINT64)1<<TBL_KIND_OF_RXLOOKUPTAB        )
#define TBL_TXLOOKUPTAB_PRN          (UINT64)((UINT64)1<<TBL_KIND_OF_TXLOOKUPTAB        )
#define TBL_FILTERDELAY_PRN          (UINT64)((UINT64)1<<TBL_KIND_OF_FILTERDELAY        )
#define TBL_ANTDELAY_PRN             (UINT64)((UINT64)1<<TBL_KIND_OF_ANTDELAY           )
#define TBL_RX0DELAY_PRN             (UINT64)((UINT64)1<<TBL_KIND_OF_RX0DELAY           )
#define TBL_TXFWD_DB_PRN             (UINT64)((UINT64)1<<TBL_KIND_OF_TxFWD_DB           )
#define TBL_DVGATEMPGAIN_PRN         (UINT64)((UINT64)1<<TBL_KIND_OF_DVGATEMPGAIN       )
#define TBL_UDC_PRN                  (UINT64)((UINT64)1<<TBL_KIND_OF_UDC)//UDC
#define TBL_PMIPHASEINFO_PRN         (UINT64)((UINT64)1<<TBL_KIND_OF_PMIPHASEINFO)
#define TBL_DSAATT_PRN               (UINT64)((UINT64)1<<TBL_KIND_OF_DSAATT)
#define TBL_TXFWDANALOG_PRN          (UINT64)((UINT64)1<<TBL_KIND_OF_TXFWDANALOG)
#define TBL_TXREVANALOG_PRN          (UINT64)((UINT64)1<<TBL_KIND_OF_TXREVANALOG)
#define TBL_RFBRIDGE_PRN             (UINT64)((UINT64)1<<TBL_KIND_OF_RFBRIDGE)

#ifndef CHECK_RET_WARNING
#define CHECK_RET_WARNING(_isWarn, fmt, ...) do { \
            if (_isWarn) UARTprintf("(%d) warning! > "fmt"\n", __LINE__, ##__VA_ARGS__); \
        } while(0)
#endif

#define SNPRINTF_CHECK(_snpRet, _snpLen) \
CHECK_RET_WARNING((((_snpRet) < (INT32)0) || ((_snpRet) > (_snpLen))), "snprintf ret'%d max'%d!", (_snpRet), (_snpLen))

#define FCLOSE_CHECK(_fclsRet) \
CHECK_RET_WARNING(((_fclsRet) != (INT32)0), "fclose ret'%d!", (_fclsRet))

#define TBL_PRINT(tblprnid,tblprnmask,tblinfo)       \
{                                                    \
    if( tblprnid & tblprnmask )                      \
        UARTprintf tblinfo;                             \
}

#define _COMPSFLE_CHECK_INPUT_TX_CHAN(chan)    \
if ((chan) >= BspGetTxChannel())               \
{                                              \
    UARTprintf("chan error!\n",__FUNCTION__);      \
    return BSP_ERROR_INVALID_PARA;             \
}

#define _COMPSFLE_CHECK_INPUT_RX_CHAN(chan)    \
if ((chan) >= BspGetRxChannel())               \
{                                              \
    UARTprintf("chan error!\n",__FUNCTION__);      \
    return BSP_ERROR_INVALID_PARA;             \
}

#define TBL_CHAN_VALID_CHECK(ch)     \
{                                    \
    if ((ch) >= TBL_MAX_TX_CHAN_NUM) \
    {                                \
        UARTprintf("%s,line%d, "#ch"=%d check ERROR!\n", __FUNCTION__, __LINE__, (ch));\
        return COMMON_ERROR;\
    }                                \
}

#define TBL_BAND_VALID_CHECK(band) \
{\
    if ((band) >= TBL_MAX_CHAN_FREQBAND) \
    {\
        UARTprintf("%s,line%d, "#band"=%d check ERROR!\n", __FUNCTION__, __LINE__, (band));\
        return COMMON_ERROR;\
    }\
}

#define TBL_LENGTH_CHECK(ulLineLen)  \
if(ulLineLen == 0||ulLineLen > TBL_MAX_LINE_LEN)  \
{\
    UARTprintf("%s(%d)>>strlen out of Range!\n",__FUNCTION__,__LINE__);  \
    return COMMON_ERROR;  \
}

#define GET_INT_VAL_FUNCTION_BODY(ptt,num,dropfunc,ptText,pch) \
{\
    const CHAR *pchKeyStr = NULL;\
    INT32 lCnt = num;\
    INT32 *pbuf = (ptt);\
    UINT32 (*func)(T_TextTrans *ptText,const CHAR *pch) = (dropfunc);\
    if (pbuf && (pchKeyStr = strchr(pch,']'))) \
    {\
        pchKeyStr++;\
        for ( ; lCnt > 0 && *pchKeyStr != '\0'; lCnt--, pbuf++) \
        {\
            *pbuf = strtol(pchKeyStr,(CHAR**)&pchKeyStr,0);\
            STRTOL_CHECK(*pbuf); \
        }\
    }\
    return (func) ? ((*func)(ptText,pch)) : 0;\
}

CHAR * _Bspstrtrimr_ex(CHAR * pchBuf);
CHAR * _Bspstrtriml_ex(CHAR * pchBuf);

#define GET_STR_VAL_FUNCTION_BODY(tt,num,dropfunc,ptText,pch) \
{\
    CHAR *pchKeyStr = NULL;\
    CHAR *pbuf = (tt);\
    UINT32 (*func)(T_TextTrans *ptText, const CHAR *pch) = (dropfunc);\
    INT32 lSnpRet = 0;                                                 \
    if (pbuf && (pchKeyStr = ((CHAR *)strchr(pch,']'))))\
    {\
        pchKeyStr++;\
        _Bspstrtriml_ex(_Bspstrtrimr_ex(pchKeyStr));\
        lSnpRet = snprintf(pbuf, num, "%s\0", pchKeyStr);\
        SNPRINTF_CHECK(lSnpRet, num);                                \
    }\
    return (func) ? ((*func)(ptText,pch)) : 0;\
}

#define IDEALRFCODEBOOK_PATH_INDEX_CHECK(index, num) \
{\
    if(index >= num)\
    {\
        return COMMON_ERROR;\
    }\
}

/**************************************************************************
*                           数据类型                                      *
**************************************************************************/
#pragma pack(1)
typedef enum e_TblkeyWordPub
{
    TBL_PUB_KW_V = 0,
    TBL_PUB_KW_INFO,
    TBL_PUB_KW_DATE,
    TBL_PUB_KW_OPERATOR,
    TBL_PUB_KW_CHECKER,
    TBL_PUB_KW_PATHNUM,
    TBL_PUB_KW_PATHPROP,
    TBL_PUB_KW_END,
    NUM_TBL_KW_PUB,
} eTblKeyWordPub;

typedef struct tagT_adjTableHeader
{
    UINT32 ulVer;                                        /*校准表的版本号*/
    UINT32 ulPathNum;                                    /*校准中存放的通道数目*/
    char aucInfo[TBL_CALI_TABLE_COMMON_LEN];           /*校准表的生成日期*/
    char aucDate[TBL_CALI_TABLE_COMMON_LEN];           /*校准表的生成日期*/
    char aucOperator[TBL_CALI_TABLE_COMMON_LEN];       /*校准表生成人员*/
    char aucChecker[TBL_CALI_TABLE_COMMON_LEN];        /*校准表检查人员*/
} TCommHeader;

typedef struct tagT_FreqRecord
{
    INT32   lFreq;      /* 频点 */
    INT32   lCompVal;   /* 各通道补偿值 */
    INT32   lBoardTemp;
    INT32   lPaTemp;
} T_FreqRecord;

typedef struct tagT_TxIqCaliRecord
{
    INT32   lFreq;
    INT32   lIOffset;                                /* I 路偏置电流校准参数 */
    INT32   lQOffset;                                /* Q 路偏置电流校准参数 */
    INT32   lIAmp;                                   /* I 路增益校准参数 */
    INT32   lQAmp;                                   /* Q 路增益校准参数 */
    INT32   lIPhase;                                 /* I 路相位校准参数 */
    INT32   lQPhase;                                 /* Q 路相位校准参数 */
    INT32   lBoardTemp;                              /* 单板温度*/
} T_TxIqCaliRecord;

typedef struct tagT_VswrParamRecord
{
    INT32   lFreq;
    INT32   lS11_Real;
    INT32   lS11_Imag;
    INT32   lS22_Real;
    INT32   lS22_Imag;
    INT32   lSt_Real;
    INT32   lSt_Imag;
} T_VswrParamCaliRecord, T_VswrRecord;


typedef struct tagT_VswrProcRecord
{
    INT32   lFreq;
    INT32   lS11_Real;
    INT32   lS11_Imag;
    INT32   lS22_Real;
    INT32   lS22_Imag;
    INT32   lSt_Real;
    INT32   lSt_Imag;
} T_VswrProcCaliRecord;

typedef struct tagT_PaVoltGainRecord
{
    INT32   lVolt;
    INT32   lGain[TBL_PA_VOLT_GAIN_ITEM];
} T_PaVoltGainRecord;

typedef struct tagT_PaDacSetDrainVoltRecord
{
    UINT32 ulPaChan;
    UINT32 ulPaPower;
    UINT32 ulPaDrainVolt;
    INT32  lPaTemp;
    INT32  lPaTempFix;
} T_PaDacSetDrainVoltRecord;

typedef struct tagT_PaDacSetGridVoltRecord
{
    UINT32 ulPaChan;
    UINT32 ulDacPhyIndex;
    UINT32 ulDacChanIndex;
    UINT32 ulGridVoltType;
    UINT32 ulGridVoltDataDef;
    INT32  lGridVoltTempFixDef;
    INT32 ulGridVoltLower;
    INT32 ulGridVoltUpper;
    INT32  lPointAndCoefficient[TBL_PA_DAC_SET_ITEM];
    INT32 lGridVoltDataDefDiff;
} T_PaDacSetGridVoltRecord;

typedef struct tagT_TempRecord
{
    INT32  lTemp;
    INT32  lTxGain;
    INT32  lTxFwd;
    INT32  lTxRev;
    INT32  lTxCali;
    INT32  lRxCali;
    INT32  lRxRssiM;
    INT32  lRxRssiD;
    INT32  lAnalogFwd;
    INT32  lAnalogRev;
}T_TempRecord, T_TrxTempGainRecord, T_PaTempGainRecord;

typedef struct tagT_DvgaTempGainRecord
{
    INT32  lTemp;
    INT32  lTxGain;
    INT32  lRxGain;
}T_DvgaTempGainRecord;

typedef struct tagT_CpAttRecord
{
    INT32  lCpAtt;
    INT32  lFreq;
    INT32  lDeta;
    INT32  lBoardTemp;
    INT32  lPaTemp;
}T_CpAttRecord;

typedef struct tagT_DsaAttRecord
{
    INT32  lDsaAtt;
    INT32  lFreq;
    INT32  lDeta;
    INT32  lBoardTemp;
    INT32  lPaTemp;
}T_DsaAttRecord;

typedef struct tagT_AnalogRecord
{
    INT32  lFreq;
    INT32  lPower;
    INT32  lVoltage;
    INT32  lBoardTemp;
    INT32  lPaTemp;
}T_AnalogRecord;

typedef struct tagT_RxAmpGainRecord
{
    INT32  lBypassDeta;
}T_RxAmpGainRecord;

typedef struct tagT_TblInitParam
{
    UINT32 ulTxChanNum;                              /* 下行通道数 */
    UINT32 ulRxChanNum;                              /* 上行通道数 */
    UINT32 ulPaPhyNum;                               /* PA物理数目，从资产信息文件中获取*/
    UINT32 ulSubNum;                                 /* 子板数 */
    INT32  lValMin[NUM_TBL_KIND_NUM];                /* 射频校准值下限 */
    INT32  lValMax[NUM_TBL_KIND_NUM];                /* 射频校准值上限 */
    UINT32 ulCaliLoadPath;                           /* 从文件系统获取，从保护区获取*/
}T_CaliTblInitParam;

typedef struct tagT_CaliTblInitFile
{
    UINT32 ulFileNum;                                /* 文件数目 */
    UINT32 FileMenu[NUM_TBL_KIND_NUM];               /* 支持文件菜单 */
    UINT32 SubFileNum[NUM_TBL_KIND_NUM];             /* 子文件数目 */
    T_CaliTblInitParam InitParam[NUM_TBL_KIND_NUM];  /* 初始化参数 */
    UINT32 IsErrAlm[NUM_TBL_KIND_NUM];               /* 加载错误时是否告警 */
    UINT32 FilePaths[NUM_TBL_KIND_NUM][2];           /* 加载路径,裸区,文件系统 */
}T_CaliTblInitFile;

/* 文本处理 */
typedef struct tagT_TextTrans
{
    CHAR acFileName[TBL_CALI_FILE_NAME];             /* 当前的应用文件名称*/
    CHAR acFileNameInSysFile[TBL_CALI_FILE_NAME];    /* 文件系统中的校准文件名 */
    CHAR acFileNameInProcFile[TBL_CALI_FILE_NAME];   /* 保护区释放到内存中的校准文件名*/
    CHAR acFileDesc[TBL_CALI_FILE_NAME];             /* 校准文件相应的描述信息 */
    FILE *fp;                                        /* 校准文件描述符 */
    CHAR *txtInfo;
    UINT32 txtInfoSize;
} T_TextTrans;


typedef UINT32 (*Execut_Func)(T_TextTrans *ptText, const CHAR *pch);
typedef UINT32 (*Execut_FuncFlash)(const UCHAR *pucData, CHAR *pchLine,UINT32 *pulLength);

typedef struct tagTblKeyWord
{
	UINT32 ulIndex;
	UINT32 ulVer;      /*字段版本号*/
	char aucKeyWord[TBL_KEYWORD_LEN];
	UCHAR ucSearchOrderFlag;
	UCHAR ucSearchResultFlag;
    Execut_Func pFunc;
    Execut_FuncFlash pFuncFlash;
} TTblKeyWord;

typedef struct tagT_CommonFreqInfo
{
    UINT32 ulStart;
    UINT32 ulEnd;
}T_CommonFreqInfo;


typedef struct tagT_RruTblInfoSet
{
    UINT32         ulPhyAddr;         /* 存储开始地址 */
    UINT32         ulPhySize;         /* 存储大小 */
    UINT32         (*PhyRd)(UINT32 ulOffset,UCHAR *pucBuf,UINT32 ulLen); /* 读数据接口 */
    UINT32         (*PhyWr)(UINT32 ulOffset,UCHAR *pucBuf,UINT32 ulLen); /* 写数据接口 */
    const UCHAR    *pToFsDir;    /* 裸区导出到FS的文件路径(/tmp/?) */
    const UCHAR    *pToMediumDir; /* FS导入到裸区的源文件路径(/ata/?) */
}T_RruTblInfoSet;


typedef struct tagT_RruTblLoadCfg
{
    UINT32            ulInit;
    T_RruTblInfoSet   tInfoSet;
}T_RruTblLoadCfg;


typedef struct tagT_RttDelayRecord    		/*用于filterdelay,antdelay,rx0delay的文件解析*/
{
	UINT32			ulTempOfPath;  		/*温度通道*/
	UINT32			ulFreq;		 		/*频点*/
	INT32			lDelay; 			/*时延*/		
}T_RttDelayRecord;

typedef UINT32 (*FUNC_SET_RF_TBL_TEXT_TRANS)(T_TextTrans *tText);
typedef struct tagT_RfTblTextTransSet
{
    UINT32 ulFileType;
    FUNC_SET_RF_TBL_TEXT_TRANS pSetRfTblTextFunc;
}T_RfTblTextTransSet;

#pragma pack()

/**************************************************************************
*                             函数声明                                    *
**************************************************************************/
CHAR * _BspTblGetParam(VOID);
UINT64 _BspGetTblPrnMask(VOID);
UINT32 _BspTextTransExit(T_TextTrans *ptText);
UINT32 _BspLineRead(T_TextTrans *ptText,CHAR *pchLine);
UINT32  _BspGetRecordFromStr_Raw(CHAR *pachStr,INT32 *pawNum,UINT32 wCnt);
UINT32 _BspSearchKeyWord(TTblKeyWord *ptKeyWords, UINT32 ulKWNum, T_TextTrans  *ptText,CHAR *pchLine);
UINT32 _BspPrintKwInfo(TTblKeyWord *ptKwInfo, UINT32 ulNum);
UINT32 _BspSetRfTblTextTrans(UINT32 ulFileType, T_TextTrans *tText);
UINT32 _BspTblCaliInit(T_CaliTblInitParam *ptParam);
VOID   BspSetCaliLoadPath(UINT32 flag);
UINT32 BspGetPaChnlSumOfAllSoc(VOID);
DOUBLE BspNs2Tc100M(DOUBLE dfNs);
CHAR * _BspStrReplace(CHAR * pchBuf, const CHAR *src, CHAR dst);
CHAR * _Bspstrtriml_ex(CHAR * pchBuf);
UINT32 _BspSetPwrCaliTextTrans(T_TextTrans *tText);
UINT32 _BspSetVswrProcTextTrans(T_TextTrans *tText);
UINT32 _BspSetTxAcCalTextTrans(T_TextTrans *tText);
UINT32 _BspSetRxIsoCalTextTrans(T_TextTrans *tText);
UINT32 _BspSetIdealWbCodeBookTextTrans(T_TextTrans *tText);
UINT32 _BspSetIdealNbCodeBookTextTrans(T_TextTrans *tText);
UINT32 _BspSetIdealAmpCodeBookTextTrans(T_TextTrans *tText);
UINT32 _BspSetIdealDvDhRfCodeBookTextTrans(T_TextTrans *tText);
UINT32 _BspSetIdealAcRfCodeBookTextTrans(T_TextTrans *tText);
UINT32 _BspSetRxLookUpTabTextTrans(T_TextTrans *tText);
UINT32 _BspSetTxLookUpTabTextTrans(T_TextTrans *tText);
INT32 BspAtoi(const char *str, INT32 base);
#ifdef __cplusplus
}
#endif

#endif


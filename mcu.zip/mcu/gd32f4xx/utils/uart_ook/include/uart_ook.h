
#ifndef RFS_MSG_H
#define RFS_MSG_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
#include "typedef.h"
#include "common.h"
#include "eeprom.h"
#include "rruinfo.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define RFS_MSG_ACK_OK                  (UINT8)(0x0)
#define RFS_MSG_ACK_ERROR               (UINT8)(0x1)
#define RFS_MSG_ACK_NOT_SUPPORT         (UINT8)(0x2)
#define RFS_MSG_ACK_CHECK_ERROR         (UINT8)(0x3)
#define RFS_MSG_ACK_LINK_ERROR          (UINT8)(0x4)

#define NO_NEED_UPGRADE    (0x0)
#define NEED_UPGRADE       (0x1)
#define RF_TBL_DATA_START_ADDR          (1024)

#define SUB_FRAME_SYMBOL_NUM   (14)
#define FRAME_SLOT_MAX_NUM     (10)

#define OOK_MSG_EMPTY       (0)
#define OOK_MSG_READY       (1)

#define OOK_LINK_SUCCESS    (1)
#define BAR_CODE_LENTH       (20)

#define OOK_VER_PACKAGE_NUM        (230)
#define ook_htonl(x) ((UINT32)((((UINT32)(x) & 0xFF000000U) >> 24) | \
                                 (((UINT32)(x) & 0x00FF0000U) >> 8)  | \
                                 (((UINT32)(x) & 0x0000FF00U) << 8)  | \
                                 (((UINT32)(x) & 0x000000FFU) << 24)))
#define ook_ntohl(x) ook_htonl(x)


#define ook_ntohs(x) ((UINT16)((((UINT16)(x) & 0xFF00U) >> 8)  | \
                                 (((UINT16)(x) & 0x00FFU) << 8)))

#define ook_htons(x) ook_ntohs(x)
#define WFS_VERSION_FLAG        (1)
#define RF_CHAN_NUM             (2)
/**************************************************************************
 *                        消息结构体
 **************************************************************************/
enum
{
    RECV_BUF_FREE = 0,
    RECV_BUF_WRITING,
    RECV_BUF_READY,
};

#define RFS_WFS_MSG_TYPE      (225)
enum E_RfsMsgType
{
    RFS_MSG_LINK_BEGIN,

    RFS_MSG_LINK_ACK,                   /* 建联 */
    RFS_MSG_HEART_BEAT,                 /* 心跳 */
    RFS_MSG_RF_SWITCH_CTRL,             /* 射频开关控制 */
    RFS_MSG_LED_CTRL,                   /* LED控制 */
    RFS_MSG_GRID_VOLT_CTRL,             /* 栅压控制 */
    RFS_MSG_OFF_LINE_PARA_DOWN_REQ,     /* 离线参数表下载请求 */
    RFS_MSG_OFF_LINE_PARA_DOWN_LOAD,    /* 离线参数表下载 */
    RFS_MSG_OFF_LINE_PARA_UP_REQ,       /* 离线参数表上传请求 */
    RFS_MSG_OFF_LINE_PARA_UP_LOAD,      /* 离线参数表上传 */
    RFS_MSG_TEST_COMMAND_REQ,           /* 维侧接口请求 */
    RFS_MSG_VERSION_COMPARE_INFO,       /* 版本比较信息 */
    RFS_MSG_VERSION_DOWNLOAD,           /* 版本下载 */
    RFS_MSG_VERSION_ACTION,             /* 版本激活 */
    RFS_MSG_TIME_DELAY_MEASURE,         /* 时延测量 */
    RFS_MSG_RESET_TYPE,                 /* 复位类型 */
    RFS_MSG_TDD_CTRL,                   /* TDD配置 */
    RFS_MSG_BEAMWIDTH_CTRL,             /* 波束配置 */
    RFS_MSG_PA_VOLT_CTRL,               /* 漏压设置 */
    RFS_MSG_TEAM_AND_VOLT_QUERY,        /* 温度电压查询 */
    RFS_MSG_ALM_QUERY,                  /* 告警信息查询 */
    RFS_MSG_SW_STATUS_QUERY,            /* 开关状态查询 */
    RFS_MSG_CLR_ALM,                    /* 告警信息清除 */
    RFS_MSG_GET_ANALOG_VOLT,            /* 模拟检波电压读取 */
    RFS_MSG_GET_RRU_INFO,               /* 资产信息的上报*/
    RFS_MSG_GET_GRID_VOLT,              /* 栅压上报*/
    RFS_MSG_SWITCH_MODE_CTRL,           /* 组合开关控制 */

    RFS_MSG_MAX,
};

enum E_RfsWfsMsgType
{
    RFS_WFS_MSG_BOARD_INFO,               /* 工装单板信息上报 */
    RFS_WFS_MSG_AD_VAL,                   /* 读取电流检测AD */
    RFS_WFS_MSG_CURR_VAL,                 /* 读取电流检测芯片的电流值 */
    RFS_WFS_MSG_RFTBL_CRC,                /* 工装离线表CRC校验*/

    RFS_WFS_MSG_MAX,
};

enum E_RfsMsgLinkSubType
{
    RFS_MSG_LINK_ESTABLISH_REQ,
    RFS_MSG_LINK_ESTABLISH,
};

enum E_RfsMsgRruInfoSubType
{
    RFS_MSG_VERSION_INFO,
    RFS_MSG_RRU_INFO,
    RFS_MSG_BOARD_INFO,
    RFS_MSG_PWR_INFO,
    RFS_MSG_PA_INFO,
    RFS_MSG_DFL_INFO,
    RFS_MSG_ANT_INFO,

    RFS_MSG_RRU_SUB_MAX,
};

enum
{
    RADIO_STANDARD_5G_FLAG = 0,
    RADIO_STANDARD_LTE_TDD_FLAG = 1,
    RADIO_STANDARD_45G_FLAG = 2,

    RADIO_STANDARD_MAX_FLAG,
};

/*帧头*/
typedef struct
{
    UINT8 startFlag1; /* [0]:0x7E */
    UINT8 startFlag2; /* [1]:0xEF */
    UINT8 version : 4;
    UINT8 reserved1 : 4;
    UINT8 reserved2;
    UINT16 dataLength;
    UINT8 dataCrc; /* x8 + x5 + x4 + 1 */
    UINT8 headSum;
} T_RfsFrameHead;

/*消息头*/
typedef struct T_RfsMsgHead
{
    UINT8 msgType;
    UINT8 msgSubType;
    UINT8 serialNo;
    UINT8 msgInfoLength;
    UINT8 reserve[4];
} T_RfsMsgHead;

/*接受消息的接结构体*/
typedef struct
{
    T_RfsFrameHead frameHead;
    UINT8 frameData[248];
} T_RfsFrame;

typedef struct Queue
{
    UINT32 start; /* 这里的读写是以这个变量为视角, uart中断写, timer中断读 */
    UINT32 end;
    UINT32 size;
    UINT32 capacity;
    UINT8 datas[512];
} Queue;

typedef struct T_MsgReceive
{
    UINT32 bufState; /* 0:free, 1:writing, 2:ready for read, 3:reading */
    UINT32 recvdLen;
    T_RfsFrame frame;
} T_MsgReceive;

typedef struct T_RfsCommAck
{
    UINT8 ackData;
}T_RfsCommAck;

#pragma pack(1)
typedef struct T_RfsLinkRequest
{
    UINT32 randCode;            /*32位随机码*/
    UINT32 moduleGroupId;       /*母端模块组ID*/
    UINT32 boardGroupId;        /*母端单板组ID*/
    UINT32 boardTypeId;         /*母端单板类型ID*/
    UINT32 hwChangeId;          /*母端硬件变更ID*/
    UINT32 mcuLenth;
    UINT32 fpgaLenth;
    UINT8 reserve[8];
} T_RfsLinkRequest;

typedef struct T_RfsLinkReqAck
{
    UINT32 moduleGroupId;
    UINT32 boardGroupId;
    UINT32 boardTypeId;
    UINT32 hwChangeId;
    UINT8  rfsBrdType[32];      /*子端单板类型*/
    UINT8  cpuVer[44];          /*子端CPU版本号*/
    UINT8  fpgaVer[44];         /*子端FPGA版本号*/
    UINT32 fpgaDevType;         /*子端FPGA器件类型 0-紫光*/
    UINT32 rfTblSize;           /*子端离线参数大小*/
    UINT32 rfTblCrc32;          /*子端离线参数CRC*/
    UINT8 ackData;
    UINT8  cpuUpgradeFlag;      /*子端CPU版本升级状态 0-正常，1-失败*/
    UINT8  fpgaUpgradeFlag;     /*子端FPGA版本升级状态 0-正常，1-失败*/
    UINT8 cpuType;
    UINT8 rfChanNum;
    UINT8 reserve[15];
} T_RfsLinkReqAck;

typedef struct T_RfsRfSwitchCtrl
{
     UINT8 chan;
     UINT8 switchType; /* pa/lna... */
     UINT8 onOffType;
     UINT16 delayMs; /* 限制最多延时30s */
     UINT8 reserve[3];
} T_RfsRfSwitchCtrl;

typedef struct T_LedCtrl
{
    UINT8 ledType;    /*alm/run*/
    UINT8 ctrlType;   /*0-常灭，1-常亮， 2-闪烁*/
    UINT16 onTimeMs;   /*这个是亮的时间？？？待确认*/
    UINT16 offTimeMs;
    UINT8 reserve1;
    UINT8 reserve2;
}T_LedCtrl;

typedef struct T_RfsDacChipCtrl {
     UINT8 dacChipIdx;
     UINT8 innerChan;
     INT16 voltmV;
     UINT8 reserve[4];
} T_RfsDacChipCtrl;

typedef struct T_RfTblUpLoadAck
{
    UINT8 ackInfo;            /*响应结果*/
    UINT8 compareResult;      /*比较结果*/
    UINT32 fileSize;           /*离线参数文件大小*/
    UINT32 fielCrc32;         /*文件的CRC值*/
    UINT8 reserve[4];
}T_RfTblUpLoadAck;

typedef struct T_RfTblUpLoadData
{
    UINT32 dataOffset;
    UINT8 dataSize;
    UINT8 fileType;
    UINT8 reserve[2];
} T_RfTblUpLoadData;


typedef struct T_RfTblUpLoadDataAck
{
    UINT8 ackInfo;
    UINT8 reserve[4];
    UINT32 dataOffset;
    UINT8 dataSize;
    UINT8 data[230];
}T_RfTblUpLoadDataAck;

typedef struct T_RfTblDownLoadData
{
    UINT8 reserve[4];       /*预留*/
    UINT8 fileType;
    UINT32 dataOffset;      /*地址偏移*/
    UINT8  dataSize;        /*一包数据的大小*/
    UINT8  data[230];       /*数据*/
}T_RfTblDownLoadData;

typedef struct T_RfTblDownLoadDataAck
{
    UINT8  ackData;
    UINT32 fileSize;
    UINT32 crc32;
    UINT8  reserve[4];
} T_RfTblDownLoadDataAck;

typedef struct T_RfTblUpLoadReq
{
    UINT32 fileSize;
    UINT32 crc32;    /*文件的CRC值*/
    UINT8 fileType;
    UINT8 reserve[3];
}T_RfTblUpLoadReq;

typedef struct T_RfTblDownLoadReq
{
    UINT32 fileSize;
    UINT32 crc32;    /*文件的CRC值*/
    UINT8 fileType;
    UINT8 reserve[3];
}T_RfTblDownLoadReq;

typedef struct T_RfTblDownLoadAck
{
    UINT8 ackResult;
    UINT8 compareResult;        /*离线参数表对比结果, 0：比较结果一样，不需要升级文件,1：比较结果不一样，需要升级文件*/
    UINT32 fileSize;            /*子端离线参数表文件实际大小*/
    UINT32 crc32;                /*子端离线参数文件实际CRC*/
    UINT8 reserve[4];
}T_RfTblDownLoadAck;

typedef struct T_RfTestCommandReq
{
    UINT8 cmdBuff[240];/* data */
}T_RfTestCommandReq;

typedef struct T_RfTestCommandAck
{
    UINT8 printBuff[239];/* data */
    UINT8 result;
}T_RfTestCommandAck;

typedef struct T_RfsVerInfoCfg
{
    UINT8 cpuCmpResult;
    UINT8 cpuVer[44];
    UINT32 cpuCrc32;
    UINT8 fpgaCmpResult;
    UINT8 fpgaVer[44];
    UINT32 fpgaCrc32;
    UINT8 reserve[4];
} T_RfsVerInfoCfg;

typedef struct T_RfsVerDownload
{
    UINT8 verType;
    UINT8 reserve[4];
    UINT32 dataOffset;
    UINT8 dataSize;
    UINT8 data[230];
} T_RfsVerDownload;

typedef struct T_RfsVerDownloadAck
{
    UINT8 ackData;
    UINT32 fileSize;
    UINT32 crc32;
    UINT8 reserve[4];
} T_RfsVerDownloadAck;

typedef struct T_RfsVerAct
{
    UINT8 cpuVerActFlag;        /*0-不激活，1-激活*/
    UINT8 fpgaVerActFlag;       /*0-不激活，1-激活*/
    UINT8 secBootVerActFlag;   /*boot版本激活标志 0:不激活 1:激活*/
    UINT8 reserve[4];
} T_RfsVerAct;

typedef struct T_RfsRfCableDlyMeasure
{
    UINT8 action;       /*1-开始，2-结束*/
    UINT8 reserve[3];
    UINT32 dlyNs;       /*单位ns*/
} T_RfsRfCableDlyMeasure;


typedef struct T_RfsResetCtrl
{
    UINT8 rstType;    /*1 - 软复位*/
    UINT8 reserve[3];
} T_RfsResetCtrl;

typedef struct tagT_RfsTddCfg
{
    UINT8 radioMode;
    UINT8 lteSubFrame;
    UINT8 lteSpeSubFrame;
    UINT8 nrUeAdv;
    UINT8 dlUlSwNum;
    UINT32 dlUlSwPeriod[4];
    UINT8 dlSymbolNum[4];
    UINT8 ulSymbolNum[4];
    UINT8 reserve[8];
}T_RfsTddCfg;

typedef struct tagT_RfsBeamwidthCfg
{
    UINT8 beamwidth;
    UINT8 reserve[3];
}T_RfsBeamwidthCfg;

typedef struct tagT_RfsPaVoltSet
{
    UINT16 volt;
    UINT8 reserve[2];
}T_RfsPaVoltSet;

typedef struct tagT_RfsTempVoltInfo
{
    UINT8 ackData;
    INT16 boardTemp;
    INT16 paTemp[2];
    UINT8 reserve1[4];
    INT16 pwrTemp;
    UINT32 pwrVout;
    UINT8 reserve2[4];
}T_RfsTempVoltInfo;

typedef struct tagT_RfsAlmInfo
{
    UINT8 ackData;
    UINT32 almState;
    UINT32 almEvent;
    UINT8 reserve[8];
}T_RfsAlmInfo;

typedef struct tagT_RfsSwitchSta
{
    UINT8 ackData;
    UINT16 rfSwTestMode;
    UINT16 rfSwSta;
    UINT8 reserve[4];
}T_RfsSwitchSta;

typedef struct tagT_RfsClrAlmSta
{
    UINT32 clrAlmState;
    UINT32 clrAlmEvent;
    UINT8 reserve[3];
}T_RfsClrAlmSta;

typedef struct tagT_RfsGetAnalogVolt
{
    UINT8 chan;
    UINT8 direction;
    UINT8 reserve[3];
}T_RfsGetAnalogVolt;

typedef struct tagT_RfsGetAnalogVoltAck
{
    UINT8 ackData;
    UINT32 volt;
    INT32 paTemp;
    UINT8 vaildFlag;
    UINT8 reserve[4];
}T_RfsGetAnalogVoltAck;

typedef struct tagT_DacGridVoltPara
{
    UINT8 dacChipIdx;
    UINT8 dacChan;
    UINT8 reserve[2];
} T_DacGridVoltPara;

typedef struct tagT_DacGridVoltAck
{
    UINT8 ackData;
    INT16 gridVoltMv;
    UINT8 reserve;
}T_DacGridVoltAck;

typedef struct tagT_RfsWfsBoardInfoAck
{
    UINT8 ackData;
    UINT32 moduleGroupId;
    UINT32 boardGroupId;
    UINT32 boardTypeId;
    UINT32 hwChangeId;
    UINT32 hwCustomIdAId;
    UINT32 hwCustomIdBId;
    UINT16 bomidCrc;
    UINT8 dacTestResult;
    UINT8 mcuTestResult;
    UINT8 epldTestResult;
    UINT8 epldId;
    UINT8 txLogicChanNum;
    UINT8 cpuVer[VER_LENTH];
    UINT8 fpgaVer[VER_LENTH];
    UINT8 firBootVer[BOOT_VER_LENTH];
    UINT8 secBootVer[BOOT_VER_LENTH];
    UINT8 barCode[BAR_CODE_LENTH];
    UINT8 resver[4];
}T_RfsWfsBoardInfoAck;

typedef struct tagT_RfsWfsGetAdValPara
{
    UINT8 chipIndex;
    UINT8 adcChan;
    UINT8 resver1[2];
}T_RfsWfsGetAdValPara;

typedef struct tagT_RfsWfsAdValAck
{
    UINT8 ackData;
    UINT32 adVal;
    UINT8 resver[3];
}T_RfsWfsAdValAck;

typedef struct tagT_RfsWfsCurrPara
{
    UINT8 chipIndex;
    UINT8 adcChan;
    UINT8 resver1[2];
}T_RfsWfsCurrPara;

typedef struct tagT_RfsWfsCurrAck
{
    UINT8 ackData;
    UINT32 currVal;
    UINT8 resver1[2];
}T_RfsWfsCurrAck;

typedef struct tagT_RfsWfsRfTblCrcCheck
{
    UINT8 fileType;
    UINT8 resver[3];
}T_RfsWfsRfTblCrcCheck;

typedef struct T_RfsGetRruinfo
{
    UINT8 filedIndex;
}T_RfsGetRruinfo;

typedef struct tagT_SwitchModeCtrl
{
    UINT8 bspChan;
    UINT8 swModeType;
    UINT8 reserve[6];
} T_SwitchModeCtrl;

typedef struct T_EachRfsMsg {
    union {
        UINT8 data[240]; /* T_RfsFrame.frameData - sizeof(T_RfsMsgHead) = 248 - 8*/

        T_RfsCommAck ack;      /*响应*/

        T_RfsLinkRequest linkReq;    /*建联请求*/
        T_RfsLinkReqAck  linkReqAck;    /*建联请求响应*/

        T_RfsRfSwitchCtrl rfSwitchCtrl;   /*射频开关*/

        T_LedCtrl ledCtrl;     /*LED控制*/

        T_RfsDacChipCtrl rfDacCtrl;     /*栅压控制*/

        T_RfTblDownLoadReq rfTblDownLoadReq;
        T_RfTblDownLoadAck rfTblDownLoadAck;
        T_RfTblDownLoadData rfTblDownLoadProc;          /*离线参数表下载*/
        T_RfTblDownLoadDataAck rfTblDownLoadProcAck;


        T_RfTblUpLoadReq rfTblUpLoadReq;    /*离线参数表请求*/
        T_RfTblUpLoadAck rfTblUpLoadAck;    /*离线参数表响应*/
        T_RfTblUpLoadData rfTblUpLoadData;
        T_RfTblUpLoadDataAck rfTblUpLoadDataAck;   /*离线参数表上传*/

        T_RfTestCommandReq testCmdReq;    /*调试接口请求*/
        T_RfTestCommandAck testCmdAck;    /*调试接口响应*/

        T_RfsVerInfoCfg verInfoCfg;     /*版本比较*/

        T_RfsVerDownload verDownLoad;   /*版本下载*/
        T_RfsVerDownloadAck verDownLoadAck;    /*版本下载响应*/

        T_RfsVerAct verAction;                  /*版本激活*/

        T_RfsRfCableDlyMeasure dlyMeasure;      /*时延测量*/

        T_RfsResetCtrl resetCtrl;              /*复位控制*/
        T_RfsTddCfg tddCfg;                    /* TDD配置 */
        T_RfsBeamwidthCfg beamwidthCfg;        /* 波束配置 */
        T_RfsPaVoltSet paVoltCtrl;             /* 漏压设置 */
        T_RfsTempVoltInfo teamAndVoltInfo;     /* 温度电压查询响应 */
        T_RfsAlmInfo almInfo;                  /* 告警信息查询响应 */
        T_RfsSwitchSta switchSta;              /* 开关状态查询响应 */
        T_RfsClrAlmSta clrAlmSta;              /* 告警清除 */
        T_RfsGetAnalogVolt analogVolt;         /* 模拟检波电压读取 */
        T_RfsGetAnalogVoltAck analogVoltAck;   /* 模拟检波电压读取响应 */
        T_DacGridVoltPara gridVoltPara;        /* 栅压读取 */
        T_DacGridVoltAck gridVoltAck;          /* 栅压读取响应 */

        T_RfsGetRruinfo getRruInfo;            /* 资产表信息上报 */
        T_RruInfo rruInfo;
        T_BoardInfo boardInfo;
        T_PwrInfo pwrInfo;
        T_PaInfo paInfo;
        T_DflInfo difInfo[MAX_FILED_INDEX];
        T_AntInfo antInfo;

        T_SwitchModeCtrl switchModeCtrl;       /* 组合开关消息 */

        /* 工装消息 */
        T_RfsWfsBoardInfoAck wfsBoardInfoAck;
        T_RfsWfsGetAdValPara wfsAdValPara;
        T_RfsWfsAdValAck wfsAdValAck;
        T_RfsWfsCurrPara wfsCurrPara;
        T_RfsWfsCurrAck wfsCurrAck;
        T_RfsWfsRfTblCrcCheck wfsRfTblCrcCheck;

        };
} T_EachRfsMsg;

typedef struct tagT_MsgSendPara
{
    VOID (*pSendMsgProc)(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
}T_MsgSendPara;

typedef struct tagT_MsgRruInfoPara
{
    VOID (*pSendRruInfoPara)(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 fieldIndex);
}T_MsgRruInfoPara;

typedef struct T_RfsMsg {
    T_RfsMsgHead head;
    T_EachRfsMsg msgInfo;
} T_RfsMsg;

typedef struct T_MsgSend {
    T_RfsFrameHead frameHead;
    T_RfsMsg rfsMsg;
} T_MsgSend;

typedef VOID (* pSendMsgProc)(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
typedef UINT32 (*OOK_SwitchCtrl)(UINT32 chan, UINT32 paType, UINT16 sw, UINT16 reasonType);
typedef UINT32 (*OOK_LedCtrl)(UINT32 ledType, UINT32 ctrlType, UINT32 onTimeMs);
typedef UINT32 (*OOK_VerDownLoad)(UINT32 verType, UINT32 offset, UINT8 *data, UINT32 length);
typedef UINT32 (*OOK_GetRfSwitchSta)(UINT16 *pswitchStatus);
typedef UINT32 (*OOK_GetMamualMode)(UINT16 *pmamulMode);
typedef UINT32 (*OOK_VerClrSector)(UINT32 verType);
typedef UINT32 (*OOK_TddCtrl)(T_RfsTddCfg *ptddCtrlCfg);
typedef UINT32 (*OOK_GetFpgaVer)(CHAR *fpgaver);
typedef UINT32 (*OOK_GetSoftVer)(CHAR *softver);
typedef UINT32 (*OOK_GetFirBootVer)(UINT8 *firBootVerver, UINT32 length);
typedef UINT32 (*OOK_GetSecBootVer)(UINT8 *secBootVer, UINT32 length);
typedef UINT32 (*OOK_GetAllAlmStatus)(UINT32 *palarmState, UINT32 *palarmEvent);
typedef UINT32 (*OOK_ClrAlmStatus)(UINT32 clrAlmState, UINT32 clrAlmEvent);
typedef UINT32 (*OOK_GetAmc7836Curr)(UINT32 devIndex, BYTE adcSel, UINT32 *pCurr);
typedef UINT32 (*OOK_GetAmc7836CurrAd)(UINT32 devIndex, BYTE adcSel, UINT32 *pAdVal);
typedef UINT32 (*OOK_RfSwitchCtrl)(UINT32 chanType, UINT8 direction);
typedef UINT32 (*OOK_GetPaTempAndAnalogVolt)(UINT8 chan, UINT8 *pDataVaildFlag, UINT32 *pAnalogVolt, INT32 *pPaTemp);
typedef UINT32 (*OOK_SetBeamwidthCfg)(UINT8 beamwidth);
typedef VOID (*OOK_ClrHeratBeatTimeCnt)(VOID);
typedef VOID (*OOK_GetBoardBarCode)(UINT8 *buff, UINT8 size);
typedef UINT32 (*OOK_SetSwMode)(UINT8 chan, UINT8 swMode);
typedef UINT32 (*OOK_CheckMcuVerData)(UINT32 crc, UINT32 lenth);
typedef VOID (*OOK_UpdataVerInfo)(UINT8 sector, UINT32 lenth, UINT32 Crc);
typedef UINT32 (*OOK_CheckSndBootRunVerCrc)(VOID);
typedef UINT32 (*OOK_CloseAllSwitch)(VOID);
typedef struct T_OokFuncPara
{
    OOK_SwitchCtrl pSwitchCtrl; /* data */
    OOK_LedCtrl pLedCtrl;
    OOK_VerDownLoad pVerDownLoad;
    OOK_TddCtrl pTddCtrl;
    OOK_GetRfSwitchSta pGetRfSwitchSta;
    OOK_GetMamualMode pGetMamualMode;
    OOK_VerClrSector pVerClrSector;
    OOK_GetFpgaVer   pGetFpgaVer;
    OOK_GetSoftVer   pGetSoftVer;
    OOK_GetFirBootVer pGetFirBootVer;
    OOK_GetSecBootVer pGetSecBootVer;
    OOK_GetAllAlmStatus pGetAllAlmStatus;
    OOK_ClrAlmStatus pClrAlmStatus;
    OOK_GetAmc7836Curr pGetAmc7836Curr;
    OOK_GetAmc7836CurrAd pGetAmc7836CurrAd;
    OOK_RfSwitchCtrl pRfSwitchCtrl;
    OOK_GetPaTempAndAnalogVolt pGetPaTempAndAnalogVolt;
    OOK_SetBeamwidthCfg pSetBeamwidthCfg;
    OOK_ClrHeratBeatTimeCnt pClrHeratBeatTimeCnt;
    OOK_GetBoardBarCode pGetBoardBarCode;
    OOK_SetSwMode pSetSwMode;
    OOK_CheckMcuVerData pCheckMcuVerData;
    OOK_UpdataVerInfo pUpdataVerInfo;
    OOK_CheckSndBootRunVerCrc pCheckSndBootRunVerCrc;
    OOK_CloseAllSwitch pCloseAllSwitch;
}T_OOK_ACTION_FUNC;
#pragma pack()


/**************************************************************************
 *                        函数声明
 **************************************************************************/
VOID BspSetOokFuncPara(T_OOK_ACTION_FUNC *ookFuncPara);

UINT32 BspRevLinkReq(VOID);
void BspHandleRevMsg();
VOID SendCnt();
UINT32 BspSendMsgProc(T_MsgReceive *recv);
UINT8 CalculateCheckSum(T_RfsFrameHead *head);
UINT32 CreateFrame(UINT8 *datas, UINT32 dataSize, T_RfsFrame *frame);
BOOL HasReadyMsg();
void GetReadyMsg(UINT8 *data, UINT32 dataSize);
UINT32 GetFrameHeadSumErrorCnt();
UINT32 GetFrameCrcErrorCnt();

void BspPushReceivedData(UINT8 data);
VOID BspSetOokTestPrintFlag(UINT8 flag);
UINT8 BspGetOokTestPrintFlag();
UINT8 BspGetOokStatus();
VOID BspSetOokStatus(UINT8 status);
UINT32 BspGetFpgaLenth();
UINT8 BspGetLinkStatus();
VOID BspSetLinkStatus(UINT8 status);
UINT8 BspGetWfsFlag();
VOID BspSetWfsFlag(UINT8 flag);
VOID BspCtrlHeartBeat(UINT32 sw);
void BspHandleOokRevMsg();
void BspSaveRecOokData(UINT8 data);
VOID HandleOokCompleteEvent(VOID);
VOID BspSetMcuVerCrc(UINT32 crc);
UINT32 BspGetOffLineInfoIndex(T_ModuleInfoHead *pHeadInfo, UINT8 fileType);
VOID BspSendOokAck(UINT8 msgType, UINT8 msgAckResult, UINT8 serialNo);
UINT32 BspGetModuleGroupId(VOID);
UINT32 BspGetBoardGroupId(VOID);
UINT32 BspGetBoardTypeId(VOID);
UINT32 BspGetHardwareChangeId(VOID);
UINT32 BspUpdataFlashRftblInfo(UINT8 fileType, UINT32 crc32, UINT32 fileSize);
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif

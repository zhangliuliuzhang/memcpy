/*****************************************************************************
* 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rftable_padacset.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了padacset头文件定义
* 注意事项 : 无
* 作    者 : 崔文会
* 创建日期 : 2014-06-20 17:00:00
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 崔文会
* 修改日戳: 2014-06-20 17:00:00
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _RFTABLE_PADACSET_BASE_H_
#define _RFTABLE_PADACSET_BASE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "rftbl_common.h"


/**********************************************************************
*                        宏常量                                          *
**********************************************************************/
#define TBL_PA_DAC_SET_MAX_V                            10  /*本模块支持的校准表最高版本，高版本可以向低版本兼容*/
#define TBL_PA_DAC_SET_NUM                              2  /* 支持表文件数目 8*/
#define TBL_PA_MAX_PHY_NUM                              4
#define TBL_PA_DAC_MAX_NUM                              16
#define TBL_PA_DRAIN_VOLT_COL                           5
#define TBL_PA_GRID_VOLT_TYPE                           3
#define TBL_PA_GRID_VOLT_FIX_COL                        8
#define TBL_PA_MAX_FREQ_NUM                             (10)    /* 最大频段数量 */

#define BSP_MAX_CHAN_NUM    (2)
/*******************************************************************
*                       数据类型                                       *
********************************************************************/
typedef struct tagT_PaDacSetHeader
{
    UINT32 ulDacNum;
    UINT32 ulDacPath[TBL_PA_DAC_MAX_NUM];
    UINT32 aGridVoltN[2];
    UINT32 ulClassNum;
    UINT32 pathIndex[TBL_PA_MAX_FREQ_NUM][BSP_MAX_CHAN_NUM + 1];
    UINT32 paFreq[TBL_PA_MAX_FREQ_NUM][TBL_MAX_CHAN_CLASSNUM + 1];
} T_PaDacSetCaliHeader;


typedef struct tagPaDacSetCaliPath
{
    UINT32                       ulPathLoadFlag;
    UINT32                       ulRecordNum;/*记录了1个功放有几个DAC*/
    T_PaDacSetGridVoltRecord    *ptRecord;
} T_PaDacSetCaliPath;

typedef struct tagPaDacSetCaliData
{
    TCommHeader                 tComHeader;
    T_PaDacSetCaliHeader        tHeader;
    T_PaDacSetCaliPath          tCali[TBL_MAX_CHAN_CLASSNUM];  /* 所有通道数据混合一块,解析完成后不再使用 */
    T_PaDacSetCaliPath          *pCaliPath[TBL_MAX_CHAN_CLASSNUM]; /* 拆分成按通道存储,解析后使用此数据 */
} T_PaDacSetCaliData;

/**************************************************************************
*                         全局函数声明                                   *
**************************************************************************/
UINT32 BspPaDacSetCalibInit(UINT32 ulIndex);
T_PaDacSetCaliData * _BspGetPaDacSetCalibData(UINT32 ulIndex);
//UINT32 _BspSetPaDacSetTextTrans(T_TextTrans *tText);
VOID _BspPaDacSetReloadEn(VOID);
//coverity[cert_dcl37_c_violation:SUPPRESS]
UINT32 _BspPaDacSetConvertV2(UINT32 ulSubFileNo,UINT32 ulIniChan, UINT32 dstChan, UINT32 ulChanNum);
//coverity[cert_dcl37_c_violation:SUPPRESS]
UINT32 _BspPaDacSetConvert(UINT32 ulSubFileNo,UINT32 ulIniChan, UINT32 ulChanNum);
//coverity[cert_dcl37_c_violation:SUPPRESS]
UINT32 _BspPaDacSetChipMap(UINT32 ulSubFileNo,UINT32 ulAbsoluteChip, UINT32 ulRelativeChip);



VOID BspSetMultySubFileProcessFlag(UINT32 flag);
UINT32 BspGetMultySubFileProcessFlag(VOID);
UINT32 BspSetPaVibasByChan(UINT32 index, UINT32 paChan);
UINT32 BspSetAllPaVibas();
VOID BspSetPaVibasSw(UINT8 sw);
UINT8 BspGetPaVibasSw();
UINT32 BspClrPaVibasByChan(UINT32 index, UINT32 paChan);
#ifdef __cplusplus
}
#endif

#endif


#ifndef _RRUINFO_BASE_H_
#define _RRUINFO_BASE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "rftbl_common.h"
#include "typedef.h"


/**********************************************************************
*                        宏常量                                          *
**********************************************************************/
#define KEY_WORLD_MAX_LENGTH       (128)
#define MAX_STRING_LENTH_TYPE0      (20)
#define MAX_STRING_LENTH_TYPE1      (12)
#define MAX_FILED_INDEX             (2)


/*******************************************************************
*                       数据类型                                       *
********************************************************************/
typedef VOID (*FIELD_GET_FUNC)(UINT8 filedIndex, char *pucInfo, UINT8 lenth);
typedef struct T_KeyWorldMatch
{
    char keyWord[KEY_WORLD_MAX_LENGTH];
    UINT8 flag;
    FIELD_GET_FUNC pFuncGetField;
}T_KeyWorldMatch;

#pragma pack(1)
//[Version:0]
typedef struct T_VersionInfo
{
    UINT8 ackData;
    UINT8 versionFlag;
    UINT8 versionInfo;
}T_VersionInfo;

//[Rru:0]
typedef struct T_RruInfo
{
    UINT8 ackData;
    UINT8 rruBarCode[MAX_STRING_LENTH_TYPE0];
    UINT8 vendorUnitFamilyType[10];
    UINT8 vendorUnitTypeNumber[MAX_STRING_LENTH_TYPE0];
    UINT8 vendorUnitPid[8];
    UINT8 verdorUnitPidFlag;
    UINT8 rruPaNum;
    UINT8 rruDflNum;
    UINT8 rruPwrNum;
    UINT8 rruPibNum;
    UINT8 rruAntNum;
    UINT8 antNum;
    UINT32 rruRatedPowerTx;
    UINT8 bomCode[MAX_STRING_LENTH_TYPE0];
    UINT8 supplerCode[MAX_STRING_LENTH_TYPE0];
    UINT8 productTime[MAX_STRING_LENTH_TYPE1];
    UINT32 serviceTime;
    UINT8 lastServiceDate[MAX_STRING_LENTH_TYPE1];
    UINT8 vendorName[MAX_STRING_LENTH_TYPE0];
}T_RruInfo;

//[Board:0]
typedef struct T_BoardInfo
{
    UINT8 ackData;
    UINT8 boardBarCode[MAX_STRING_LENTH_TYPE0];
    UINT8 boardName[MAX_STRING_LENTH_TYPE0];
    UINT8 productTime[MAX_STRING_LENTH_TYPE1];
    UINT32 serviceTime;
    UINT8 lastServiceDate[MAX_STRING_LENTH_TYPE1];
    UINT8 vendorName[MAX_STRING_LENTH_TYPE0];
}T_BoardInfo;

//[Pwr:0]
typedef struct T_PwrInfo
{
    UINT8 ackData;
    UINT8 pwrBarCode[MAX_STRING_LENTH_TYPE0];
    UINT8 pwrType[8];
    UINT32 defaultPwrVolt;
    UINT32 pwrVoltUp;
    UINT32 pwrVoltDown;
    UINT32 pwrFactoryId;
    UINT8 productTime[MAX_STRING_LENTH_TYPE1];
    UINT32 serviceTime;
    UINT8 lastServiceDate[MAX_STRING_LENTH_TYPE1];
    UINT8 vendorName[MAX_STRING_LENTH_TYPE0];
}T_PwrInfo;

//[Pa:0]
typedef struct T_PaInfo
{
    UINT8 ackData;
    UINT8 paBarCode[MAX_STRING_LENTH_TYPE0];
    UINT8 boardName[MAX_STRING_LENTH_TYPE0];
    UINT8 paPath;
    UINT8 paTxFreq[MAX_STRING_LENTH_TYPE0];
    UINT32 paFactoryId;
    UINT8 productTime[MAX_STRING_LENTH_TYPE1];
    UINT32 serviceTime;
    UINT8 lastServiceDate[MAX_STRING_LENTH_TYPE1];
    UINT8 vendorName[MAX_STRING_LENTH_TYPE0];
}T_PaInfo;

//[Dfl:0]
typedef struct T_DflInfo
{
    UINT8 ackData;
    UINT8 dflBarCode[48];
    UINT8 boardName[MAX_STRING_LENTH_TYPE0];
    UINT8 dflAntNum;
    UINT8 dflRxFreq[MAX_STRING_LENTH_TYPE0];
    UINT8 dflTxFreq[MAX_STRING_LENTH_TYPE0];
    UINT32 dflFactoryId;
    UINT8 productTime[MAX_STRING_LENTH_TYPE1];
    UINT32 serviceTime;
    UINT8 lastServiceDate[MAX_STRING_LENTH_TYPE1];
    UINT8 vendorName[MAX_STRING_LENTH_TYPE0];
}T_DflInfo;

//[Ant:0]
typedef struct T_AntInfo
{
    UINT8 ackData;
    UINT8 antBarCode[MAX_STRING_LENTH_TYPE0];
    UINT8 boardName[MAX_STRING_LENTH_TYPE0];
    UINT8 antNum;
    UINT32 antFactoryId;
    UINT8 productTime[MAX_STRING_LENTH_TYPE1];
    UINT32 serviceTime;
    UINT8 lastServiceDate[MAX_STRING_LENTH_TYPE1];
    UINT8 vendorName[MAX_STRING_LENTH_TYPE0];
}T_AntInfo;

typedef struct T_RruProPertyInfo
{
    T_VersionInfo VersionInfo;
    T_RruInfo RruInfo;
    T_BoardInfo BoardInfo;
    T_PwrInfo PwrInfo;
    T_PaInfo PaInfo;
    T_DflInfo DflInfo[MAX_FILED_INDEX];
    T_AntInfo AntInfo;

}T_RruProPertyInfo;
#pragma pack()
/**************************************************************************
*                         全局函数声明                                   *
**************************************************************************/
VOID printRruInfo();
UINT32 BspRruinfoInit(VOID);
T_RruProPertyInfo *BspGetRruPropertyInfo();
#ifdef __cplusplus
}
#endif

#endif

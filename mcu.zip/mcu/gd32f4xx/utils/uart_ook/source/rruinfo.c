#include <stdio.h>
#include <string.h>
#include "typedef.h"
#include "common.h"
#include "eeprom.h"
#include "rftbl_common.h"
#include "rruinfo.h"
/******************************************************************
*                        宏定义
******************************************************************/


/******************************************************************
*                         全局变量定义
******************************************************************/
UINT8 g_rruInfoEndFlag = 0;
UINT8 g_filedIndex = 0;
T_RruProPertyInfo s_RruProInfo;
/**************************************************************************
*                         函数声明                                   *
**************************************************************************/
static VOID BspGetVerFlag(UINT8 filedIndex, char *buff, UINT8 lenth);

/******************************************************************
*                        数据类型
******************************************************************/

/******************************************************************
*                         函数实现
******************************************************************/
static UINT8 GetFiledIndex()
{
    return g_filedIndex;
}

static VOID SetFiledIndex(UINT8 index)
{
    g_filedIndex = index;
}

T_RruProPertyInfo *BspGetRruPropertyInfo()
{
    return &s_RruProInfo;
}
/******************************************************************
*                         单字段函数实现
******************************************************************/
static VOID BspGetVerFlag(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.VersionInfo.versionFlag = (UINT8)strtoul(buff, NULL, 16);
}

static VOID BspGetVerInfo(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.VersionInfo.versionInfo = (UINT8)strtoul(buff, NULL, 16);
}

/******************************************************************
*                         单字段函数实现 [Rru:0]
******************************************************************/
static VOID BspGetBarCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.rruBarCode, NELEMENTS(s_RruProInfo.RruInfo.rruBarCode), buff, lenth);
}

static VOID BspGetFamilyType(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.vendorUnitFamilyType, NELEMENTS(s_RruProInfo.RruInfo.vendorUnitFamilyType), buff, lenth);
}

static VOID BspGetTypeNum(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.vendorUnitTypeNumber, NELEMENTS(s_RruProInfo.RruInfo.vendorUnitTypeNumber), buff, lenth);
}

static VOID BspGetPid(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.vendorUnitPid, NELEMENTS(s_RruProInfo.RruInfo.vendorUnitPid), buff, lenth);
}

static VOID BspGetPidFlag(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.verdorUnitPidFlag = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetPaNum(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.rruPaNum = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetDifNum(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.rruDflNum = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetPwrNum(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.rruPwrNum = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetRruAntNum(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.rruAntNum = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetAntNum(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.antNum = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetTxRatePwr(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.rruRatedPowerTx = strtoul(buff, NULL, 0);
}

static VOID BspGetBomCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.bomCode, NELEMENTS(s_RruProInfo.RruInfo.bomCode), buff, lenth);
}

static VOID BspGetSupplerCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.supplerCode, NELEMENTS(s_RruProInfo.RruInfo.supplerCode), buff, lenth);
}

static VOID BspGetProductTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.productTime, NELEMENTS(s_RruProInfo.RruInfo.productTime), buff, lenth);
}

static VOID BspGetServiceTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.RruInfo.serviceTime = strtoul(buff, NULL, 0);
}

static VOID BspGetLastServiceDate(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.lastServiceDate, NELEMENTS(s_RruProInfo.RruInfo.lastServiceDate), buff, lenth);
}

static VOID BspGetVendorName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.RruInfo.vendorName, NELEMENTS(s_RruProInfo.RruInfo.vendorName), buff, lenth);
}

/******************************************************************
*                         单字段函数实现 [Board:0]
******************************************************************/
static VOID BspGetBoardBarCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.BoardInfo.boardBarCode, NELEMENTS(s_RruProInfo.BoardInfo.boardBarCode), buff, lenth);
}

static VOID BspGetBoardName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.BoardInfo.boardName, NELEMENTS(s_RruProInfo.BoardInfo.boardName), buff, lenth);
}

static VOID BspGetBoarProductTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.BoardInfo.productTime, NELEMENTS(s_RruProInfo.BoardInfo.productTime), buff, lenth);
}

static VOID BspGetBoarServiceTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.BoardInfo.serviceTime = strtoul(buff, NULL, 0);
}

static VOID BspGetBoarLastServiceDate(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.BoardInfo.lastServiceDate, NELEMENTS(s_RruProInfo.BoardInfo.lastServiceDate), buff, lenth);
}

static VOID BspGetBoarVendorName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.BoardInfo.vendorName, NELEMENTS(s_RruProInfo.BoardInfo.vendorName), buff, lenth);
}

/******************************************************************
*                         单字段函数实现 [Pwr:0]
******************************************************************/
static VOID BspGetPwrBarCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PwrInfo.pwrBarCode, NELEMENTS(s_RruProInfo.PwrInfo.pwrBarCode), buff, lenth);
}

static VOID BspGetPwrType(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PwrInfo.pwrType, NELEMENTS(s_RruProInfo.PwrInfo.pwrType), buff, lenth);
}

static VOID BspGetDefaultPwrVolt(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PwrInfo.defaultPwrVolt = strtoul(buff, NULL, 0);
}

static VOID BspGetPwrVoltUp(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PwrInfo.pwrVoltUp = strtoul(buff, NULL, 0);
}

static VOID BspGetPwrVoltDown(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PwrInfo.pwrVoltDown = strtoul(buff, NULL, 0);
}

static VOID BspGetPwrFactoryId(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PwrInfo.pwrFactoryId = strtoul(buff, NULL, 0);
}

static VOID BspGetPwrProductTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PwrInfo.productTime, NELEMENTS(s_RruProInfo.PwrInfo.productTime), buff, lenth);
}

static VOID BspGetPwrServiceTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PwrInfo.serviceTime = strtoul(buff, NULL, 0);
}

static VOID BspGetPwrLastServiceDate(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PwrInfo.lastServiceDate, NELEMENTS(s_RruProInfo.PwrInfo.lastServiceDate), buff, lenth);
}

static VOID BspGetPwrVendorName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PwrInfo.vendorName, NELEMENTS(s_RruProInfo.PwrInfo.vendorName), buff, lenth);
}

/******************************************************************
*                         单字段函数实现 [Pa:0]
******************************************************************/
static VOID BspGetPaBarCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PaInfo.paBarCode, NELEMENTS(s_RruProInfo.PaInfo.paBarCode), buff, lenth);
}

static VOID BspGetPaBoardName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PaInfo.boardName, NELEMENTS(s_RruProInfo.PaInfo.boardName), buff, lenth);
}

static VOID BspGetPaPath(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PaInfo.paPath = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetPaTxFreq(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PaInfo.paTxFreq, NELEMENTS(s_RruProInfo.PaInfo.paTxFreq), buff, lenth);
}

static VOID BspGetPaFactoryId(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PaInfo.paFactoryId = strtoul(buff, NULL, 0);
}

static VOID BspGetPaProductTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PaInfo.productTime, NELEMENTS(s_RruProInfo.PaInfo.productTime), buff, lenth);
}

static VOID BspGetPaServiceTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.PaInfo.serviceTime = strtoul(buff, NULL, 0);
}

static VOID BspGetPaLastServiceDate(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PaInfo.lastServiceDate, NELEMENTS(s_RruProInfo.PaInfo.lastServiceDate), buff, lenth);
}

static VOID BspGetPaVendorName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.PaInfo.vendorName, NELEMENTS(s_RruProInfo.PaInfo.vendorName), buff, lenth);
}

/******************************************************************
*                         单字段函数实现 [Dfl:0]
******************************************************************/
static VOID BspGetDflBarCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.DflInfo[0].dflBarCode, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].dflBarCode), buff, lenth);
    memcpy_s(s_RruProInfo.DflInfo[1].dflBarCode, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].dflBarCode), buff, lenth);
}

static VOID BspGetDflBoardName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.DflInfo[0].boardName, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].boardName), buff, lenth);
    memcpy_s(s_RruProInfo.DflInfo[1].boardName, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].boardName), buff, lenth);
}

static VOID BspGetDflAntNum(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.DflInfo[0].dflAntNum = (UINT8)strtoul(buff, NULL, 0);
    s_RruProInfo.DflInfo[1].dflAntNum = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetDflRxFreq(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.DflInfo[0].dflRxFreq, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].dflRxFreq), buff, lenth);
    memcpy_s(s_RruProInfo.DflInfo[1].dflRxFreq, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].dflRxFreq), buff, lenth);
}

static VOID BspGetDflTxFreq(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.DflInfo[0].dflTxFreq, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].dflTxFreq), buff, lenth);
    memcpy_s(s_RruProInfo.DflInfo[1].dflTxFreq, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].dflTxFreq), buff, lenth);
}

static VOID BspGetDflFactoryId(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.DflInfo[0].dflFactoryId = strtoul(buff, NULL, 0);
    s_RruProInfo.DflInfo[1].dflFactoryId = strtoul(buff, NULL, 0);
}

static VOID BspGetDflProductTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.DflInfo[0].productTime, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].productTime), buff, lenth);
    memcpy_s(s_RruProInfo.DflInfo[1].productTime, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].productTime), buff, lenth);
}

static VOID BspGetDflServiceTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.DflInfo[0].serviceTime = strtoul(buff, NULL, 0);
    s_RruProInfo.DflInfo[1].serviceTime = strtoul(buff, NULL, 0);
}

static VOID BspGetDflLastServiceDate(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.DflInfo[0].lastServiceDate, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].lastServiceDate), buff, lenth);
    memcpy_s(s_RruProInfo.DflInfo[1].lastServiceDate, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].lastServiceDate), buff, lenth);
}

static VOID BspGetDflVendorName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.DflInfo[0].vendorName, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].vendorName), buff, lenth);
    memcpy_s(s_RruProInfo.DflInfo[1].vendorName, NELEMENTS(s_RruProInfo.DflInfo[filedIndex].vendorName), buff, lenth);
}

/******************************************************************
*                         单字段函数实现 [Ant:0]
******************************************************************/
static VOID BspGetAntBarCode(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.AntInfo.antBarCode, NELEMENTS(s_RruProInfo.AntInfo.antBarCode), buff, lenth);
}

static VOID BspGetAntBoardName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.AntInfo.boardName, NELEMENTS(s_RruProInfo.AntInfo.boardName), buff, lenth);
}

static VOID BspGetAntNum_Ant(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.AntInfo.antNum = (UINT8)strtoul(buff, NULL, 0);
}

static VOID BspGetAntFactoryId(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.AntInfo.antFactoryId = strtoul(buff, NULL, 0);
}

static VOID BspGetAntProductTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.AntInfo.productTime, NELEMENTS(s_RruProInfo.AntInfo.productTime), buff, lenth);
}

static VOID BspGetAntServiceTime(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    s_RruProInfo.AntInfo.serviceTime = strtoul(buff, NULL, 0);
}

static VOID BspGetAntLastServiceDate(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.AntInfo.lastServiceDate, NELEMENTS(s_RruProInfo.AntInfo.lastServiceDate), buff, lenth);
}

static VOID BspGetAntVendorName(UINT8 filedIndex, char *buff, UINT8 lenth)
{
    INPUT_POINTER_CHECK_RETURN(buff);
    memcpy_s(s_RruProInfo.AntInfo.vendorName, NELEMENTS(s_RruProInfo.AntInfo.vendorName), buff, lenth);
}

T_KeyWorldMatch rruInfoDscp[] =
{
    //Version:2
    {"VersionFlag", 0, BspGetVerFlag},
    {"VersionInfo", 0, BspGetVerInfo},

    //Rru:18
    {"RruBarCode", 0, BspGetBarCode},
    {"VendorUnitFamilyType", 0, BspGetFamilyType},
    {"VendorUnitTypeNumber", 0, BspGetTypeNum},
    {"VendorUnitPid", 0, BspGetPid},
    {"VerdorUnitPidFlag", 0, BspGetPidFlag},
    {"RruPaNum", 0, BspGetPaNum},
    {"RruDflNum", 0, BspGetDifNum},
    {"RruPwrNum", 0, BspGetPwrNum},
    {"RruPibNum", 0, BspGetRruAntNum},
    {"RruAntNum", 0, BspGetRruAntNum},
    {"AntNum", 0, BspGetAntNum},
    {"RruRatedPowerTx", 0, BspGetTxRatePwr},
    {"BomCode", 0, BspGetBomCode},
    {"SupplerCode", 0, BspGetSupplerCode},
    {"ProductTime", 0, BspGetProductTime},
    {"ServiceTime", 0, BspGetServiceTime},
    {"LastServiceDate", 0, BspGetLastServiceDate},
    {"VendorName", 0, BspGetVendorName},

    //Board:6
    {"BoardBarCode", 0, BspGetBoardBarCode},
    {"BoardName", 0, BspGetBoardName},
    {"ProductTime", 0, BspGetBoarProductTime},
    {"ServiceTime", 0, BspGetBoarServiceTime},
    {"LastServiceDate", 0, BspGetBoarLastServiceDate},
    {"VendorName", 0, BspGetBoarVendorName},

    //[Pwr:0]:12
    {"PwrBarCode", 0, BspGetPwrBarCode},
    {"BoardName", 0, NULL},
    {"PwrType", 0, BspGetPwrType},
    {"PwrVer", 0, NULL},
    {"SupprotConsumedPower", 0, NULL},
    {"DefaultPwrVolt(mV)", 0, BspGetDefaultPwrVolt},
    {"PwrVoltUp(mV)", 0, BspGetPwrVoltUp},
    {"PwrVoltDown(mV)", 0, BspGetPwrVoltDown},
    {"PwrFactoryId", 0, BspGetPwrFactoryId},
    {"ProductTime", 0, BspGetPwrProductTime},
    {"ServiceTime", 0, BspGetPwrServiceTime},
    {"LastServiceDate", 0, BspGetPwrLastServiceDate},
    {"VendorName", 0, BspGetPwrVendorName},

    //[Pa:0] 9
    {"PaBarCode", 0, BspGetPaBarCode},
    {"BoardName", 0, BspGetPaBoardName},
    {"PaPath", 0, BspGetPaPath},
    {"PaTxFreq", 0, BspGetPaTxFreq},
    {"PaFactoryId", 0, BspGetPaFactoryId},
    {"ProductTime", 0, BspGetPaProductTime},
    {"ServiceTime", 0, BspGetPaServiceTime},
    {"LastServiceDate", 0, BspGetPaLastServiceDate},
    {"VendorName", 0, BspGetPaVendorName},

    //[Dfl:0] 11
    {"DflBarCode", 0, BspGetDflBarCode},
    {"BoardName", 0, BspGetDflBoardName},
    {"DflAntNum", 0, BspGetDflAntNum},
    {"DflRxFreq", 0, BspGetDflRxFreq},
    {"DflTxFreq", 0, BspGetDflTxFreq},
    {"LanGain(0.01dB)", 0, NULL},
    {"DflFactoryId", 0, BspGetDflFactoryId},
    {"ProductTime", 0, BspGetDflProductTime},
    {"ServiceTime", 0, BspGetDflServiceTime},
    {"LastServiceDate", 0, BspGetDflLastServiceDate},
    {"VendorName", 0, BspGetDflVendorName},

    //[Ant:0] 9
    {"AntBarCode", 0, BspGetAntBarCode},
    {"BoardName", 0, BspGetAntBoardName},
    {"AppType", 0, NULL},
    {"AntNum", 0, BspGetAntNum_Ant},
    {"AntFactoryId", 0, BspGetAntFactoryId},
    {"ProductTime", 0, BspGetAntProductTime},
    {"ServiceTime", 0, BspGetAntServiceTime},
    {"LastServiceDate", 0, BspGetAntLastServiceDate},
    {"VendorName", 0, BspGetAntVendorName},
};

//删除字符中的[]
void removeBrackets(char* str)
 {
    int len = strlen(str);

    INPUT_POINTER_CHECK_RETURN(str);
    // 移动字符位置
    int i, j;
    for (i = 0, j = 0; i < len; i++) {
        if (str[i] != '[' && str[i] != ']') {
            str[j++] = str[i];
        }
    }

    // 添加字符串结束符
    str[j] = '\0';
}

//删除字符后面的空格
void removeStrRightSpace(char *str)
{
    UINT32 loop = 0;
    UINT32 len = 0;

    INPUT_POINTER_CHECK_RETURN(str);
    len = strlen(str);
    for(loop = len -1; loop >= 0; loop++)
    {
        if(str[loop] == ' ')
        {
            str[loop] = '\0';
        }
        else
        {
            break;
        }
    }
}

static UINT32 BspGetVersionInfoIndex(char *buff, UINT32 *index)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(buff);
    INPUT_POINTER_CHECK(index);

    for(loop = 0; loop < NELEMENTS(rruInfoDscp); loop++)
    {
        if(rruInfoDscp[loop].flag == 1)
        {
            continue;
        }

        if(strcmp(buff, rruInfoDscp[loop].keyWord) == 0)
        {
            *index = loop;
            rruInfoDscp[loop].flag = 1;
            break;
        }
    }

    if(loop >= NELEMENTS(rruInfoDscp))
    {
        UARTprintf("not find key world OR keyworld has been set [%s]\n", buff);
        return COMMON_ERROR;
    }

    return COMMON_OK;
}

UINT8 fineFiledIndex(char* str)
{
    char *position = NULL;
    UINT8 index = 0;

    position = strchr(str, ':');
    if(position != NULL)
    {
        index = strtol(position + 1, NULL, 0);
    }

    return index;
}

UINT32 BspRruinfoInit(VOID)
{
    UINT8 fieldIndex = 0;
    UINT32 index = 0;
    UINT8 lenth = 0;
    UINT32 ret = 0;
    CHAR  achLine[TBL_MAX_LINE_LEN] = {0};         /* 保存一行的文本 */
    CHAR *token;
    T_TextTrans tText = {
        .acFileDesc = "",
        .acFileName = "",
        .acFileNameInProcFile = "",
        .acFileNameInSysFile = "",
        .fp = NULL,
        .txtInfo = (CHAR *)BspGetRruInfoTxtData(),
        .txtInfoSize = BspGetRruInfoLenth()};

    if(tText.txtInfo == NULL)
    {
        return COMMON_ERROR;
    }

    for(g_rruInfoEndFlag = 0; ;)
    {
        memset(achLine, 0, TBL_MAX_LINE_LEN);
        ret = _BspLineRead(&tText, achLine);        /*长度小于3，注释# 会被筛选出来*/
        if (COMMON_ERROR == ret)
        {
            UARTprintf("rruinfo.txt analysis finished!\n");
            break;
        }

        if(achLine[0] == '[')
        {
            // 删除文本中的[]符号;
            removeBrackets(achLine);
            //找到索引
            fieldIndex = fineFiledIndex(achLine);
            SetFiledIndex(fieldIndex);
        }
        else
        {
            token = strtok(achLine, "=");
            if(GetFiledIndex() == 1)
            {
                continue;
            }
            removeStrRightSpace(token);   //去除关键字中的空格
            ret = BspGetVersionInfoIndex(token, &index);

            if(ret == COMMON_ERROR)
            {
                continue;
            }
            token = strtok(NULL, "\n");

            if(strcmp(token, "INVALID_VALUE") == 0)
            {
                continue;
            }
            if(rruInfoDscp[index].pFuncGetField != NULL)
            {
                fieldIndex = GetFiledIndex();
                lenth = strlen(token);
                token[lenth + 1] = '\0';
                lenth += 1;
                rruInfoDscp[index].pFuncGetField(fieldIndex, token, lenth);
            }
        }
    }

    return COMMON_OK;
}

VOID printRruInfo()
{
    UARTprintf("*************[Version:0]**************\n");
    UARTprintf("VersionFlag = %d\n", s_RruProInfo.VersionInfo.versionFlag);
    UARTprintf("VersionInfo = %d\n", s_RruProInfo.VersionInfo.versionInfo);
    UARTprintf("*************[Rru:0]**************\n");
    UARTprintf("RruBarCode = %s\n", s_RruProInfo.RruInfo.rruBarCode);
    UARTprintf("VendorUnitFamilyType = %s\n", s_RruProInfo.RruInfo.vendorUnitFamilyType);
    UARTprintf("vendorUnitTypeNumber = %s\n", s_RruProInfo.RruInfo.vendorUnitTypeNumber);
    UARTprintf("vendorUnitPid = %s\n", s_RruProInfo.RruInfo.vendorUnitPid);
    UARTprintf("verdorUnitPidFlag = %d\n", s_RruProInfo.RruInfo.verdorUnitPidFlag);
    UARTprintf("rruPaNum = %d\n", s_RruProInfo.RruInfo.rruPaNum);
    UARTprintf("rruDflNum = %d\n", s_RruProInfo.RruInfo.rruDflNum);
    UARTprintf("rruPwrNum = %d\n", s_RruProInfo.RruInfo.rruPwrNum);
    UARTprintf("rruPibNum = %d\n", s_RruProInfo.RruInfo.rruPibNum);
    UARTprintf("rruAntNum = %d\n", s_RruProInfo.RruInfo.rruAntNum);
    UARTprintf("antNum = %d\n", s_RruProInfo.RruInfo.antNum);
    UARTprintf("rruRatedPowerTx = %d\n", s_RruProInfo.RruInfo.rruRatedPowerTx);
    UARTprintf("bomCode = %s\n", s_RruProInfo.RruInfo.bomCode);
    UARTprintf("supplerCode = %s\n", s_RruProInfo.RruInfo.supplerCode);
    UARTprintf("productTime = %s\n", s_RruProInfo.RruInfo.productTime);
    UARTprintf("serviceTime = %d\n", s_RruProInfo.RruInfo.serviceTime);
    UARTprintf("lastServiceDate = %s\n", s_RruProInfo.RruInfo.lastServiceDate);
    UARTprintf("vendorName = %s\n", s_RruProInfo.RruInfo.vendorName);
    UARTprintf("*************[Board:0]**************\n");
    UARTprintf("boardBarCode = %s\n", s_RruProInfo.BoardInfo.boardBarCode);
    UARTprintf("boardName = %s\n", s_RruProInfo.BoardInfo.boardName);
    UARTprintf("productTime = %s\n", s_RruProInfo.BoardInfo.productTime);
    UARTprintf("serviceTime = %d\n", s_RruProInfo.BoardInfo.serviceTime);
    UARTprintf("lastServiceDate = %s\n", s_RruProInfo.BoardInfo.lastServiceDate);
    UARTprintf("vendorName = %s\n", s_RruProInfo.BoardInfo.vendorName);
    UARTprintf("*************[Pwr:0]**************\n");
    UARTprintf("pwrBarCode = %s\n", s_RruProInfo.PwrInfo.pwrBarCode);
    UARTprintf("pwrType = %s\n", s_RruProInfo.PwrInfo.pwrType);
    UARTprintf("defaultPwrVolt = %dmV\n", s_RruProInfo.PwrInfo.defaultPwrVolt);
    UARTprintf("pwrVoltUp = %dmV\n", s_RruProInfo.PwrInfo.pwrVoltUp);
    UARTprintf("pwrVoltDown = %dmV\n", s_RruProInfo.PwrInfo.pwrVoltDown);
    UARTprintf("pwrFactoryId = %d\n", s_RruProInfo.PwrInfo.pwrFactoryId);
    UARTprintf("productTime = %s\n", s_RruProInfo.PwrInfo.productTime);
    UARTprintf("serviceTime = %d\n", s_RruProInfo.PwrInfo.serviceTime);
    UARTprintf("lastServiceDate = %s\n", s_RruProInfo.PwrInfo.lastServiceDate);
    UARTprintf("vendorName = %s\n", s_RruProInfo.PwrInfo.vendorName);
    UARTprintf("*************[Pa:0]**************\n");
    UARTprintf("paBarCode = %s\n", s_RruProInfo.PaInfo.paBarCode);
    UARTprintf("boardName = %s\n", s_RruProInfo.PaInfo.boardName);
    UARTprintf("paPath = %d\n", s_RruProInfo.PaInfo.paPath);
    UARTprintf("paTxFreq = %s\n", s_RruProInfo.PaInfo.paTxFreq);
    UARTprintf("pwrFactoryId = %d\n", s_RruProInfo.PaInfo.paFactoryId);
    UARTprintf("productTime = %s\n", s_RruProInfo.PaInfo.productTime);
    UARTprintf("serviceTime = %d\n", s_RruProInfo.PaInfo.serviceTime);
    UARTprintf("lastServiceDate = %s\n", s_RruProInfo.PaInfo.lastServiceDate);
    UARTprintf("vendorName = %s\n", s_RruProInfo.PaInfo.vendorName);
    UARTprintf("*************[Dfl:0]**************\n");
    UARTprintf("dflBarCode = %s\n", s_RruProInfo.DflInfo[0].dflBarCode);
    UARTprintf("boardName = %s\n", s_RruProInfo.DflInfo[0].boardName);
    UARTprintf("dflAntNum = %d\n", s_RruProInfo.DflInfo[0].dflAntNum);
    UARTprintf("dflRxFreq = %s\n", s_RruProInfo.DflInfo[0].dflRxFreq);
    UARTprintf("dflTxFreq = %s\n", s_RruProInfo.DflInfo[0].dflTxFreq);
    UARTprintf("dflFactoryId = %d\n", s_RruProInfo.DflInfo[0].dflFactoryId);
    UARTprintf("productTime = %s\n", s_RruProInfo.DflInfo[0].productTime);
    UARTprintf("serviceTime = %d\n", s_RruProInfo.DflInfo[0].serviceTime);
    UARTprintf("lastServiceDate = %s\n", s_RruProInfo.DflInfo[0].lastServiceDate);
    UARTprintf("vendorName = %s\n", s_RruProInfo.DflInfo[0].vendorName);
    UARTprintf("*************[Dfl:1]**************\n");
    UARTprintf("dflBarCode = %s\n", s_RruProInfo.DflInfo[1].dflBarCode);
    UARTprintf("boardName = %s\n", s_RruProInfo.DflInfo[1].boardName);
    UARTprintf("dflAntNum = %d\n", s_RruProInfo.DflInfo[1].dflAntNum);
    UARTprintf("dflRxFreq = %s\n", s_RruProInfo.DflInfo[1].dflRxFreq);
    UARTprintf("dflTxFreq = %s\n", s_RruProInfo.DflInfo[1].dflTxFreq);
    UARTprintf("dflFactoryId = %d\n", s_RruProInfo.DflInfo[1].dflFactoryId);
    UARTprintf("productTime = %s\n", s_RruProInfo.DflInfo[1].productTime);
    UARTprintf("serviceTime = %d\n", s_RruProInfo.DflInfo[1].serviceTime);
    UARTprintf("lastServiceDate = %s\n", s_RruProInfo.DflInfo[1].lastServiceDate);
    UARTprintf("vendorName = %s\n", s_RruProInfo.DflInfo[1].vendorName);
    UARTprintf("*************[Ant:0]**************\n");
    UARTprintf("antBarCode = %s\n", s_RruProInfo.AntInfo.antBarCode);
    UARTprintf("boardName = %s\n", s_RruProInfo.AntInfo.boardName);
    UARTprintf("antNum = %d\n", s_RruProInfo.AntInfo.antNum);
    UARTprintf("antFactoryId = %d\n", s_RruProInfo.AntInfo.antFactoryId);
    UARTprintf("productTime = %s\n", s_RruProInfo.AntInfo.productTime);
    UARTprintf("serviceTime = %d\n", s_RruProInfo.AntInfo.serviceTime);
    UARTprintf("lastServiceDate = %s\n", s_RruProInfo.AntInfo.lastServiceDate);
    UARTprintf("vendorName = %s\n", s_RruProInfo.AntInfo.vendorName);
}


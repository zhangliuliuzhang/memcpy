/*****************************************************************************
* 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rftable_common.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了公共处理部分
* 注意事项 : 无
* 作    者 : 崔文会
* 创建日期 : 2014-06-20 17:00:00
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 崔文会
* 修改日戳: 2014-06-20 17:00:00
* 变更说明: 创建
*----------------------------------------------------------------------------
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "rftbl_common.h"
#include "common.h"
#include "typedef.h"
#include "utils.h"
/**************************************************************************
*                         宏                                               *
**************************************************************************/

/**************************************************************************
*                             数据类型                                     *
**************************************************************************/

/**************************************************************************
*                          全局变量定义                                    *
**************************************************************************/
static T_CaliTblInitParam g_tTblParam = {0};

static UINT64  g_sulPrnMask = 0;                             /*保存打印屏蔽位*/
static T_RfTblTextTransSet s_RfTblTextSet[] =
{

   {TBL_KIND_OF_PWRCALI,             _BspSetPwrCaliTextTrans },

   {TBL_KIND_OF_TXCALI,              NULL},
   {TBL_KIND_OF_VSWRPROC,            _BspSetVswrProcTextTrans},
   {TBL_KIND_OF_RXCALI,              NULL},
   {TBL_KIND_OF_TXACCAL,             _BspSetTxAcCalTextTrans},
   {TBL_KIND_OF_RXISOCAL,            _BspSetRxIsoCalTextTrans},
   {TBL_KIND_OF_IDEALWBRFCODEBOOK,   _BspSetIdealWbCodeBookTextTrans},
   {TBL_KIND_OF_IDEALNBRFCODEBOOK,   _BspSetIdealNbCodeBookTextTrans},
   {TBL_KIND_OF_IDEALAMPRFCODEBOOK,  _BspSetIdealAmpCodeBookTextTrans},
   {TBL_KIND_OF_IDEALDVDHRFCODEBOOK, _BspSetIdealDvDhRfCodeBookTextTrans},
   {TBL_KIND_OF_IDEALACRFCODEBOOK,   _BspSetIdealAcRfCodeBookTextTrans},
   {TBL_KIND_OF_RXLOOKUPTAB,         _BspSetRxLookUpTabTextTrans},
   {TBL_KIND_OF_TXLOOKUPTAB,         _BspSetTxLookUpTabTextTrans},

};

/**************************************************************************
 *                        外部变量声明
**************************************************************************/

/**************************************************************************
*                         局部函数声明                                      *
**************************************************************************/

/**************************************************************************
*                         函数实现                                        *
**************************************************************************/
/**************************************************************************
 * 函数名称: BspAtoi
 * 功能描述: 字符串转换成整数，做必要的代码检查
 * 输入参数: str    - 待转换的字符串
 *           base   - 转换的进制，0表示根据字符串自动识别
 * 输出参数: 无
 * 返 回 值: INT32 - 转换后的有符号整数值
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
INT32 BspAtoi(const char *str, INT32 base)
{
    long int tmpVal = 0;
    INT32 ret = 0;

    tmpVal = strtol(str, NULL, base);
    ret = tmpVal;
    if(ret >= LONG_MAX)
    {
        ret = 0;
    }
    return ret;
}

/******************************************************************************
* 函数名称   : _BspTblCaliInit
* 功能描述   : 校准表初始化
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ptParam--初始化参数
* 输出参数   : 无
* 返 回 值   : COMMON_OK,加载成功；其它，加载失败；
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 _BspTblCaliInit(T_CaliTblInitParam *ptParam)
{
    if( NULL == ptParam )
        return COMMON_ERROR;
    (void)memcpy_s( (VOID*)&g_tTblParam, sizeof(T_CaliTblInitParam), ptParam, sizeof(T_CaliTblInitParam));
    return COMMON_OK;
}

/******************************************************************************
* 函数名称   : _BspTblGetParam
* 功能描述   : 返回校准表参数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 校准表参数指针
* 返 回 值   : COMMON_OK,加载成功；其它，加载失败；
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
CHAR *_BspTblGetParam(VOID)
{
    return (CHAR*)&g_tTblParam;
}

/******************************************************************************
* 函数名称   : _BspTextTransExit
* 功能描述   : 校准文本解析退出
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : data-传入校准文件名称以及路径
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 _BspTextTransExit(T_TextTrans *ptText)
{
    UINT32 ulRetVal = COMMON_OK;
    INT32 iTmpRet = 0;
    if ((NULL != ptText) && (NULL != ptText->fp))
    {
        iTmpRet = fclose(ptText->fp);
        FCLOSE_CHECK(iTmpRet);
        ptText->fp = NULL;
    }
    return ulRetVal;
}

/******************************************************************************
* 函数名称   : _BspStrReplace
* 功能描述   : 字符替换
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : pchBuf-传入待处理的字符串
* 输出参数   : 无
* 返 回 值   : 按照要求处理后的字符串
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
CHAR * _BspStrReplace(CHAR * pchBuf, const CHAR *src, CHAR dst)
{
    CHAR *tmpbuf = pchBuf;

    while (*tmpbuf != '\0')
    {
        if (strchr(src, *tmpbuf))
        {
            *tmpbuf = dst;
        }
        tmpbuf++;
    }

    return pchBuf;
}
/******************************************************************************
* 函数名称   : _Bspstrtrimr_ex
* 功能描述   : 去除空格
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : pchBuf-传入待处理的字符串
* 输出参数   : 无
* 返 回 值   : 按照要求处理后的字符串
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
CHAR * _Bspstrtrimr_ex(CHAR * pchBuf)
{
    UINT32 ulLoop = 0;
    INT32  ulLen = 0;
    CHAR  tmp[TBL_MAX_LINE_LEN] = {0};

    ulLen = strnlen(pchBuf,TBL_MAX_LINE_LEN);

    if(ulLen >= (TBL_MAX_LINE_LEN-1))
        return pchBuf;

    memset(tmp,0x00,TBL_MAX_LINE_LEN);

    if (ulLen < 0)
    {
        UARTprintf("strnlen(%s) error :%d \n", pchBuf, ulLen);
        return pchBuf;
    }

    for(ulLoop = 0;ulLoop < (UINT32)ulLen;ulLoop++)
    {
        if (pchBuf[ulLoop] !=' ')
            break;
    }
    if (ulLoop < (UINT32)ulLen) {
        strncpy_s(tmp, sizeof(tmp), (pchBuf + ulLoop), (ulLen - ulLoop));
    }
    strncpy_s(pchBuf, TBL_MAX_LINE_LEN, tmp, ulLen);
    return pchBuf;
}
/******************************************************************************
* 函数名称   : _Bspstrtriml_ex
* 功能描述   : 去除空格
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : pchBuf-传入待处理的字符串
* 输出参数   : 无
* 返 回 值   : 按照要求处理后的字符串
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
CHAR * _Bspstrtriml_ex(CHAR * pchBuf)
{
    UINT32 ulLoop = 0;
    INT32  len = 0;
    CHAR  tmp[TBL_MAX_LINE_LEN] = {0};

    len = strnlen(pchBuf,TBL_MAX_LINE_LEN);
    if(len >= (TBL_MAX_LINE_LEN-1))
        return pchBuf;

    memset(tmp,0x00,TBL_MAX_LINE_LEN);

    if (len < 0)
    {
        UARTprintf("strnlen(%s) error :%d \n", pchBuf, len);
        return pchBuf;
    }

    for(ulLoop = 0;ulLoop < (UINT32)len;ulLoop++)
    {
        if (pchBuf[len-ulLoop-1] !=' ')
            break;
    }
    if (ulLoop < (UINT32)len) {
        strncpy_s(tmp, sizeof(tmp), pchBuf, (len - ulLoop));
    }
    strncpy_s(pchBuf, TBL_MAX_LINE_LEN, tmp, len);
    return pchBuf;
}

/**
 * 找到下一行的结束位置。
 */
UINT32 findNextLineEnd(char *data, UINT32 dataSize) {
    for (UINT32 i = 0; i < dataSize; i++) {
        if (data[i] == '\r' || data[i] == '\n') {
            return i;
        }
    }

    return dataSize;
}

/**
 * 从数据段中读取一行数据。
 */
UINT32 GetOneLineData(T_TextTrans *ptText, char *data, UINT32 dataSize)
{
    UINT32 loop = 0;
    const char lineEnd = '\n';
    const char dataEnd = '\0';
    char chr = 0;
    UINT32 inputSize = 0;

    INPUT_POINTER_CHECK(ptText);
    INPUT_POINTER_CHECK(data);
    INPUT_POINTER_CHECK(ptText->txtInfo);

    if ((ptText->txtInfoSize == 0) || (dataSize == 0))
    {
        return COMMON_ERROR;
    }

    memset(data, 0, dataSize);

    inputSize = ptText->txtInfoSize;
    for (loop = 0; (loop < dataSize - 1) && (loop < inputSize); ++loop)
    {
        chr = ptText->txtInfo[loop];
        data[loop] = chr;
        if ((chr == lineEnd) || (chr == dataEnd))
        {
            loop += 1;
            break;
        }
    }

    ptText->txtInfo += loop;
    ptText->txtInfoSize -= loop;

    return COMMON_OK;
}


UINT32 _BspLineRead(T_TextTrans *ptText,CHAR *pchLine)
{
    UINT32 ulLen = 0;

    if (NULL == ptText || NULL == pchLine)
    {
        return COMMON_ERROR;
    }

    memset(pchLine,0,TBL_MAX_LINE_LEN);

    for(;;)
    {
        if (GetOneLineData(ptText, pchLine, TBL_MAX_LINE_LEN) != COMMON_OK)
        {
            return COMMON_ERROR;
        }
        _BspStrReplace(pchLine, "\r\n", '\0');
        //coverity[cert_int31_c_violation:SUPPRESS]
        ulLen= strnlen(_Bspstrtriml_ex(_Bspstrtrimr_ex(pchLine)),TBL_MAX_LINE_LEN);
        if( ulLen <= 3 || pchLine[0] == TBL_COMMENT_CHAR )
        {
            continue;                                       /* 空行 或 注释行 */
        }
        break;
    }
    return COMMON_OK;
}

/******************************************************************************
* 函数名称   : _BspGetRecordFromStr_Raw
* 功能描述   : 解析字符串
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : pachStr--字符串，wCnt-解析数据数目
* 输出参数   : pawNum-解析出来的实际数目
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 _BspGetRecordFromStr_Raw(CHAR *pachStr,INT32 *pawNum,UINT32 wCnt)
{
    CHAR  *pchHolder;
    UINT32 ulCount;

    if (NULL == pachStr || NULL == pawNum)
    {
        return (INT32)COMMON_ERROR;
    }

    /* 需要解决2个问题:
       一是有小数点存在的参数获取; X
       二是最后1个数只有1位时直接退出了; ok
     */
    pchHolder = pachStr;
    ulCount = 0;
    while (*pchHolder != '\0' && *pchHolder != '\r' && *pchHolder != '\n')
    {
        if (isspace(*pchHolder))
        {
            pchHolder++;
            continue;
        }
        if (ulCount >= (UINT32)wCnt)
        {
            break;
        }

        pawNum[ulCount++] = strtol(pchHolder, &pchHolder, 0);
    }

    return ulCount;
}
/******************************************************************************
* 函数名称   : _BspGetPrnMask
* 功能描述   : 获取打印屏蔽位
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 打印屏蔽位
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT64 _BspGetTblPrnMask(VOID)
{
    return g_sulPrnMask;
}

/******************************************************************************
* 函数名称   : _BspSearchKeyWord
* 功能描述   : 搜索校准文件键值
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : data-校准文件当前文件信息位置记录
               pchLine--校准文件某行的信息
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 _BspSearchKeyWord(TTblKeyWord *ptKeyWords, UINT32 ulKWNum, T_TextTrans  *ptText,CHAR *pchLine)
{
    UINT32 ulKwLoop = 0;
    CHAR  *pchKeyStr = NULL;
    int len = 0;

    for (ulKwLoop=0; ulKwLoop < ulKWNum; ulKwLoop++, ptKeyWords++)
    {
        pchKeyStr = strstr((const CHAR*)pchLine, (const CHAR*)ptKeyWords->aucKeyWord);
        if (NULL == pchKeyStr)
        {
            /* 关键字不区分大小写 */
            //coverity[cert_exp37_c_violation:SUPPRESS]
            len = strnlen(ptKeyWords->aucKeyWord,TBL_MAX_LINE_LEN);
            if (len >= 0)
            {
                //coverity[cert_exp37_c_violation:SUPPRESS]
                if (strncasecmp(pchLine, ptKeyWords->aucKeyWord, len))
                {
                    continue;
                }
            }
        }
        if (NULL != ptKeyWords->pFunc)
        {
            ptKeyWords->ucSearchResultFlag = TBL_SEARCH_KEYWORD_SUCC;
            ptKeyWords->pFunc(ptText, pchLine);
            break;
        }
    }

    return COMMON_OK;
}

/******************************************************************************
* 函数名称   : _BspPaDrainAdjKwInfo
* 功能描述   : 打印表的键值访问结果
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : COMMON_OK,加载成功；其它，加载失败；
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 _BspPrintKwInfo(TTblKeyWord *ptKwInfo, UINT32 ulNum)
{
    UINT32 ulLoop=0;
    CHAR  aucState[2][10]={"Dirty","Clean"};

    INPUT_POINTER_CHECK(ptKwInfo);
    for (ulLoop = 0; ulLoop < ulNum; ulLoop++)
    {
        UARTprintf("%s = %s\n", ptKwInfo[ulLoop].aucKeyWord,
            ptKwInfo[ulLoop].ucSearchResultFlag?aucState[0]:aucState[1]);
    }
    return COMMON_OK;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: COMMON_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月28日 10090699    创建
 **************************************************************************/
UINT32 _BspSetRfTblTextTrans(UINT32 ulFileType, T_TextTrans *tText)
{
    UINT32 ulRet = COMMON_OK;
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(tText);

    for(loop = 0; loop < NELEMENTS(s_RfTblTextSet); loop++)
    {
        if(ulFileType == s_RfTblTextSet[loop].ulFileType)
        {
            if(NULL == s_RfTblTextSet[loop].pSetRfTblTextFunc)
            {
                ulRet = COMMON_OK;
            }
            else
            {
                ulRet = s_RfTblTextSet[loop].pSetRfTblTextFunc(tText);
            }
            break;
        }
    }

    if(loop >= NELEMENTS(s_RfTblTextSet))
    {
        return COMMON_ERROR;
    }

    return ulRet;
}

VOID BspSetCaliLoadPath(UINT32 flag)
{
    g_tTblParam.ulCaliLoadPath = (flag==TBL_FILE_SYS)?TBL_FILE_SYS:TBL_PROPECT_SYS;
}

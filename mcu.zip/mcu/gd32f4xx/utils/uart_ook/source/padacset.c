/*****************************************************************************
* 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rftable_padacset.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功放栅压、漏压校准文件的解析
* 注意事项 : 无
* 作    者 : 崔文会
* 创建日期 : 2014-06-20 17:00:00
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "padacset.h"
#include "common.h"
#include "typedef.h"
#include "eeprom.h"
#include "amc7836.h"
/**************************************************************************
*                         宏                                              *
**************************************************************************/
#define  GRID_VOLT_RECORD_MAX        (TBL_PA_GRID_VOLT_TYPE*TBL_MAX_TX_CHAN_NUM)
#define CONVERSIN_FACTOR_TEMP        (100)
UINT8 errno = 0;
UINT8 s_paVibasSw = SWITCH_ON;
/**************************************************************************
*                         数据类型                                         *
**************************************************************************/
typedef enum e_TblKeyWordPubPaDacSet
{
    TBL_PADACSET_KW_V        = TBL_PUB_KW_V,
    TBL_PADACSET_KW_DATE     = TBL_PUB_KW_DATE,
    TBL_PADACSET_KW_OPERATOR = TBL_PUB_KW_OPERATOR,
    TBL_PADACSET_KW_CHECKER  = TBL_PUB_KW_CHECKER,
    TBL_PADACSET_KW_PATHNUM  = TBL_PUB_KW_PATHNUM,
    TBL_PADACSET_KW_PATHPROP = TBL_PUB_KW_PATHPROP,
    TBL_PADACSET_KW_FILEEND  = TBL_PUB_KW_END,
} eTblKeyWordPubPaDacSet;

typedef enum e_TblKeyWordHeaderPaDacSet
{
    TBL_PADACSET_KW_DAC_NUM = 0,
    TBL_PADACSET_KW_DAC_PATH,
    TBL_PADACSET_KW_GRIDVOLT_ROW,
    TBL_PADACSET_KW_GRIDVOLT_N,
    TBL_PADACSET_KW_GRIDVOLT_PATH_INDEX,
    TBL_PADACSET_KW_GRIDVOLT_PA_FREQ,
    TBL_PADACSET_KW_GRIDVOLT_CLASS_NUM,
    NUM_TBL_KW_PADACSET_HEADER
}eTblKeyWordHeaderPaDacSet;

typedef enum e_TblkeyWordPathPaDacSet
{
    TBL_PADACSET_KW_GRIDVOLT_DATA_S0,
    TBL_PADACSET_KW_GRIDVOLT_DATA_E0,
    TBL_PADACSET_KW_GRIDVOLT_CLASS_E0,
    TBL_PADACSET_KW_GRIDVOLT_DATA_S1,
    TBL_PADACSET_KW_GRIDVOLT_DATA_E1,
    TBL_PADACSET_KW_GRIDVOLT_CLASS_E1,
    TBL_PADACSET_KW_GRIDVOLT_DATA_S2,
    TBL_PADACSET_KW_GRIDVOLT_DATA_E2,
    TBL_PADACSET_KW_GRIDVOLT_CLASS_E2,

    NUM_TBL_KW_PADACSET,
} eTblKeyWordPathPaDacSet;

#define PADACSET_TBL_KW_FIELD_SET(fieldid,field)  \
            {TBL_PADACSET_KW_##fieldid,V6,field,TBL_SEARCH_KEYWORD_NO_ORDER,TBL_SEARCH_KEYWORD_DEFAULT,PADACSET_##fieldid}

#define _GET_PADACSET_DATA(idx)       (((idx) >= TBL_PA_DAC_SET_NUM) ? NULL: gptPaDacSetCaliData[idx])

#define _GET_COMHEADER_INTNUM(tt)     ((NULL != gptPaDacSetCaliData[0]) ? (sizeof(gptPaDacSetCaliData[0]->tComHeader.tt) / sizeof(UINT32)) : COMMON_ERROR)
#define _GET_COMHEADER_STRNUM(tt)     ((NULL != gptPaDacSetCaliData[0]) ? (sizeof(gptPaDacSetCaliData[0]->tComHeader.tt)/sizeof(UCHAR)) : COMMON_ERROR)
#define _GET_COMHEADER_TT(tt)         ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (gptPaDacSetCaliData[sulPaDacSetIndex]->tComHeader.tt) : 0)
#define _GET_COMHEADER_PP(tt)         ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (&gptPaDacSetCaliData[sulPaDacSetIndex]->tComHeader.tt) : NULL)

#define _GET_HEADER_INTNUM(tt)        ((NULL != gptPaDacSetCaliData[0]) ? (sizeof(gptPaDacSetCaliData[0]->tHeader.tt) / sizeof(UINT32)) : COMMON_ERROR)
#define _GET_HEADER_STRNUM(tt)        ((NULL != gptPaDacSetCaliData[0]) ? (sizeof(gptPaDacSetCaliData[0]->tHeader.tt) / sizeof(UCHAR)) : COMMON_ERROR)
#define _GET_HEADER_TT(tt)            ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (gptPaDacSetCaliData[sulPaDacSetIndex]->tHeader.tt) : 0)
#define _GET_HEADER_PP(tt)            ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (&gptPaDacSetCaliData[sulPaDacSetIndex]->tHeader.tt) : NULL)

#define _GET_PATHINFO_INTNUM(class,path,tt) ((NULL != gptPaDacSetCaliData[0]) ? (sizeof(gptPaDacSetCaliData[0]->pCaliPath[class][path].tt)/sizeof(UINT32)) : COMMON_ERROR)
#define _GET_PATHINFO_STRNUM(class,path,tt) ((NULL != gptPaDacSetCaliData[0]) ? (sizeof(gptPaDacSetCaliData[0]->pCaliPath[class][path].tt)/sizeof(UCHAR)) : COMMON_ERROR)
#define _GET_PATHINFO_TT(class,path,tt)     ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (path < TBL_MAX_TX_CHAN_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (gptPaDacSetCaliData[sulPaDacSetIndex]->pCaliPath[class][path].tt) : 0)
#define _GET_PATHINFO_PP(class,path,tt)     ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (path < TBL_MAX_TX_CHAN_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (&gptPaDacSetCaliData[sulPaDacSetIndex]->pCaliPath[class][path].tt) : NULL)

#define _GET_CALI_INTNUM(class,tt)          (sizeof(gptPaDacSetCaliData[0]->tCali[class].tt)/sizeof(UINT32))
#define _GET_CALI_STRNUM(class,tt)          (sizeof(gptPaDacSetCaliData[0]->tCali[classss].tt)/sizeof(UCHAR))
#define _GET_CALI_TT(class,tt)              ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (gptPaDacSetCaliData[sulPaDacSetIndex]->tCali[class].tt) : 0)
#define _GET_CALI_PP(class,tt)              ((((sulPaDacSetIndex) < TBL_PA_DAC_SET_NUM) && (NULL != gptPaDacSetCaliData[sulPaDacSetIndex])) ? (&gptPaDacSetCaliData[sulPaDacSetIndex]->tCali[class].tt) : NULL)

#define COMPS_FUNC_DEC(fieldid)      UINT32 PADACSET_##fieldid(T_TextTrans *ptText, const CHAR *pch)
#define COMPS_FUNC_INT_DEC(fieldid)  COMPS_FUNC_DEC(fieldid)
#define COMPS_FUNC_STR_DEC(fieldid)  COMPS_FUNC_DEC(fieldid)

#define COMPS_FUNC_INT_IMP(fieldid,ptt,num,dropfunc)   \
UINT32 PADACSET_##fieldid(T_TextTrans *ptText, const CHAR *pch) \
{\
    const CHAR *pchKeyStr = NULL;\
    INT32 lCnt = num;\
    INT32 *pbuf = (INT32*)(ptt);\
    UINT32 (*func)(T_TextTrans *ptText, const CHAR *pch) = (dropfunc);\
    if (pbuf && (pchKeyStr = strchr(pch,']'))) \
    {\
        pchKeyStr++;\
        for ( ; lCnt > 0 && *pchKeyStr != '\0'; lCnt--, pbuf++) \
        {\
            errno = 0;\
            *pbuf = strtol(pchKeyStr,(CHAR**)&pchKeyStr,0);\
            if(errno != 0)\
            {\
               UARTprintf("strtoul error.\n");\
            }\
        }\
    }\
    UARTprintf("\n");\
    return (func) ? ((*func)(ptText,pch)) : 0;\
}
static void _search_index(const CHAR *pch, const CHAR *pchKeyStr, INT32 *index);
/* ptt 二维数组
 * num1 一维的数量
 * num2 二维的数量 */
#define FUZZY_COMPS_FUNC_INT_IMP(fieldid,num1,ptt,num2,dropfunc)   \
UINT32 PADACSET_##fieldid(T_TextTrans *ptText, const CHAR *pch) \
{\
    const CHAR *pchKeyStr = NULL;\
    INT32 lCnt = num2;\
    INT32 *pbuf = (INT32*)(ptt);\
    INT32 index = 0;\
    UINT32 (*func)(T_TextTrans *ptText, const CHAR *pch) = (dropfunc);\
    if (pbuf && (pchKeyStr = strchr(pch,']'))) \
    {\
        _search_index(pch, pchKeyStr, &index);\
        if (index < num1) {\
            pbuf = pbuf + (index * lCnt);\
        }\
        pchKeyStr++;\
        for ( ; lCnt > 0 && *pchKeyStr != '\0'; lCnt--, pbuf++) \
        {\
            errno = 0;\
            *pbuf = strtol(pchKeyStr,(CHAR**)&pchKeyStr,0);\
            if(errno != 0)\
            {\
               UARTprintf("strtoul error.\n");\
            }\
        }\
    }\
    UARTprintf("\n");\
    return (func) ? ((*func)(ptText,pch)) : 0;\
}

#define COMPS_FUNC_STR_IMP(fieldid,tt,num,dropfunc)   \
UINT32 PADACSET_##fieldid(T_TextTrans *ptText, const CHAR *pch) \
{\
    CHAR *pchKeyStr = NULL;\
    CHAR *pbuf = (tt);\
    INT32 lCnt = num;\
    INT32  snprtRet = 0;\
    UINT32 (*func)(T_TextTrans *ptText, const CHAR *pch) = (dropfunc);\
    if (pbuf && (pchKeyStr = ((CHAR *)strchr(pch,']')))&&(lCnt > 0))\
    {\
        pchKeyStr++;\
        _Bspstrtriml_ex(_Bspstrtrimr_ex(pchKeyStr));\
        snprtRet = snprintf(pbuf, num, "%s", pchKeyStr);\
        SNPRINTF_CHECK(snprtRet, num);\
    }\
    return (func) ? ((*func)(ptText,pch)) : 0;\
}

/**************************************************************************
*                         全局变量定义                                    *
**************************************************************************/
static T_PaDacSetCaliData      *gptPaDacSetCaliData[TBL_PA_DAC_SET_NUM] ={0};
TTblKeyWord             g_satPaDacSetKeyWordHead[NUM_TBL_KW_PADACSET_HEADER]={0};
TTblKeyWord             g_satPaDacSetKeyWordPath[TBL_MAX_TX_CHAN_NUM][NUM_TBL_KW_PADACSET]={0};
static UINT32            g_sulPaDacSetLoadEndFlag = TBL_LOAD_UNLOAD;
static UINT32            g_sulPaDacSetSection = 0;
static UINT32            sulPaDacSetIndex = 0;
static UINT32            sulPaDacSetPath = 0;
static UINT32            sulCaliDataClass = 0;

T_TextTrans             g_stPaDacSet =
{
    "/ata/cali/PaDacSet.txt",
    "/ata/cali/PaDacSet.txt",
    "/tmp/cali/PaDacSet.txt",
    "pa dac set calib file",
    NULL,
    NULL,
    0,
};

/**************************************************************************
 *                        外部变量声明
**************************************************************************/

/**************************************************************************
*                         局部函数声明                                      *
**************************************************************************/
COMPS_FUNC_INT_DEC(V);
COMPS_FUNC_STR_DEC(DATE);
COMPS_FUNC_STR_DEC(OPERATOR);
COMPS_FUNC_STR_DEC(CHECKER);
COMPS_FUNC_INT_DEC(PATHNUM);
COMPS_FUNC_INT_DEC(FILEEND);

COMPS_FUNC_INT_DEC(DAC_NUM);
COMPS_FUNC_INT_DEC(DAC_PATH);
COMPS_FUNC_INT_DEC(GRIDVOLT_ROW);
COMPS_FUNC_INT_DEC(GRIDVOLT_N);
COMPS_FUNC_INT_DEC(GRIDVOLT_PATH_INDEX);
COMPS_FUNC_INT_DEC(GRIDVOLT_PA_FREQ);
COMPS_FUNC_INT_DEC(GRIDVOLT_CLASS_NUM);

COMPS_FUNC_DEC(GRIDVOLT_DATA_S0);
COMPS_FUNC_DEC(GRIDVOLT_DATA_E0);
COMPS_FUNC_DEC(GRIDVOLT_CLASS_E0);
COMPS_FUNC_DEC(GRIDVOLT_DATA_S1);
COMPS_FUNC_DEC(GRIDVOLT_DATA_E1);
COMPS_FUNC_DEC(GRIDVOLT_CLASS_E1);
COMPS_FUNC_DEC(GRIDVOLT_DATA_S2);
COMPS_FUNC_DEC(GRIDVOLT_DATA_E2);
COMPS_FUNC_DEC(GRIDVOLT_CLASS_E2);

TTblKeyWord g_atPaDacSetKeyWordPub[NUM_TBL_KW_PUB] =
{
    PADACSET_TBL_KW_FIELD_SET(V,"[V]"),
    PADACSET_TBL_KW_FIELD_SET(DATE,"[DATE]"),
    PADACSET_TBL_KW_FIELD_SET(OPERATOR,"[TestPersonName]"),
    PADACSET_TBL_KW_FIELD_SET(CHECKER,"[checkedPersonName]"),
    PADACSET_TBL_KW_FIELD_SET(PATHNUM,"[PathNum]"),
    PADACSET_TBL_KW_FIELD_SET(FILEEND,"[END]"),
};

TTblKeyWord g_atPaDacSetKeyWordHeader[NUM_TBL_KW_PADACSET_HEADER] =
{
    PADACSET_TBL_KW_FIELD_SET(DAC_NUM,"[Pa Dac Number]"),
    PADACSET_TBL_KW_FIELD_SET(DAC_PATH,"[Pa Dac Path]"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_ROW,"[PA DAC Data Vs Temperature]"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_N,"[n Value]"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_PATH_INDEX,"[PathIndex"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_PA_FREQ,"[PaFreq"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_CLASS_NUM,"[GateClassNum]"),
};

TTblKeyWord g_atPaDacSetKeyWordModule[NUM_TBL_KW_PADACSET] =
{
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_DATA_S0,"<DATA>"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_DATA_E0,"</DATA>"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_CLASS_E0,"[CLASSEND]"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_DATA_S1,"<DATA>"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_DATA_E1,"</DATA>"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_CLASS_E1,"[CLASSEND]"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_DATA_S2,"<DATA>"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_DATA_E2,"</DATA>"),
    PADACSET_TBL_KW_FIELD_SET(GRIDVOLT_CLASS_E2,"[CLASSEND]"),
};

/**************************************************************************
*                         函数实现                                        *
**************************************************************************/
static void _search_index(const CHAR *pch, const CHAR *pchKeyStr, INT32 *index)
{
    INPUT_POINTER_CHECK_RETURN(pch);
    INPUT_POINTER_CHECK_RETURN(pchKeyStr);
    INPUT_POINTER_CHECK_RETURN(index);
    *index = 0;
    if (*pchKeyStr == *pch)
    {
        return;
    }
    pchKeyStr--;
    while (*pchKeyStr != *pch && *pchKeyStr != '[')
    {
        if (isdigit(*pchKeyStr) == 0)
        {
            *index = BspAtoi(pchKeyStr + 1, 10);
            break;
        }
        pchKeyStr--;
    }
}

/******************************************************************************
* 函数名称   : PADACSET_SetSection
* 功能描述   : 区域号累加
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
static UINT32 PADACSET_SetSection(T_TextTrans *ptText, const CHAR *pch)
{
    g_sulPaDacSetSection++;
    return COMMON_OK;
}
//COMPS_FUNC_INT_IMP(GRIDVOLT_N, _GET_HEADER_PP(aGridVoltN), _GET_HEADER_INTNUM(aGridVoltN), NULL);
UINT32 PADACSET_GRIDVOLT_N(T_TextTrans *ptText, const CHAR *pch)
{
    const CHAR *pchKeyStr = NULL;
    INT32 lCnt = _GET_HEADER_INTNUM(aGridVoltN);
    INT32 *pbuf = (INT32*)(_GET_HEADER_PP(aGridVoltN));

    if (pbuf && (pchKeyStr = strchr(pch,']')))
    {
        pchKeyStr++;
        for ( ; lCnt > 0 && *pchKeyStr != '\0'; lCnt--, pbuf++)
        {
            errno=0;
            *pbuf = strtol(pchKeyStr,(CHAR**)&pchKeyStr,0);
            if(errno != 0)
            {
                UARTprintf("strtoul error.\n");
            }
        }
    }
    UARTprintf("\n");
    if(_GET_COMHEADER_TT(ulVer) < 10)
    {
        return PADACSET_SetSection(ptText,pch);
    }
    else
    {
        return 0;
    }
}

/******************************************************************************
* 函数名称   : _SearchAndMapKeyWordPub
* 功能描述   : 搜索校准文件公共的键值
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ptText-校准文件当前文件信息位置记录
               pchLine--校准文件某行的信息
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
static UINT32 _SearchAndMapKeyWordPub(T_TextTrans  *ptText,CHAR *pchLine)
{
    TTblKeyWord *ptKeyWords = g_atPaDacSetKeyWordPub;
    UINT32       ulKWNum = NUM_TBL_KW_PUB;
    return _BspSearchKeyWord(ptKeyWords, ulKWNum, ptText, pchLine);
}
/******************************************************************************
* 函数名称   : _SearchAndMapKeyWordPath
* 功能描述   : 搜索校准文件私有的键值
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ptText--校准文件当前文件信息位置记录
               pchLine--校准文件某行的信息
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
static UINT32 _SearchAndMapKeyWordPath(T_TextTrans  *ptText,CHAR *pchLine)
{
    TTblKeyWord *ptKeyWords = g_satPaDacSetKeyWordPath[sulPaDacSetPath];
    UINT32       ulKWNum = NUM_TBL_KW_PADACSET;
    return _BspSearchKeyWord(ptKeyWords, ulKWNum, ptText, pchLine);
}


static UINT32 _SearchAndMapKeyWordHeader(T_TextTrans  *ptText,CHAR *pchLine)
{
    TTblKeyWord *ptKeyWords = g_satPaDacSetKeyWordHead;
    UINT32       ulKWNum = NUM_TBL_KW_PADACSET_HEADER;
    return _BspSearchKeyWord(ptKeyWords, ulKWNum, ptText, pchLine);
}
/******************************************************************************
* 函数名称   : _BspSearchAndMapKeyWord
* 功能描述   : 搜索校准文件键值
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ptText--校准文件当前文件信息位置记录
               pchLine--校准文件某行的信息
               ulFlag--0，公共键值；1-私有键值；
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 _BspSearchAndMapKeyWord(T_TextTrans  *ptText,UINT32 ulFlag, CHAR *pchLine)
{
    if (0 == ulFlag)
    {
        _SearchAndMapKeyWordPub(ptText,pchLine);
    }
    else if (1 == ulFlag)
    {
        _SearchAndMapKeyWordHeader(ptText,pchLine);
    }
    else
    {
        _SearchAndMapKeyWordPath(ptText, pchLine);
    }
    return COMMON_OK;
}

static UINT32 s_PaDacPathValidNum = 0;
VOID BspRecoredPaDacValidPathNum(UINT32 pathNum)
{
    s_PaDacPathValidNum = pathNum;
}

/******************************************************************************
* 函数名称   : PADACSET_GetValidPathNum
* 功能描述   : 获取通道数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 通道数
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 PADACSET_GetValidPathNum(VOID)
{
    UINT32 *pulPathNum = _GET_COMHEADER_PP(ulPathNum);
    UINT32 ulFilePathNum = 0;
    UINT32 ulBoardPaNum = 2;//BspGetPaNum(); 这里需要修改，在初始化按机型做区分，4.0是在rruinfo中获取的
    UINT32 ulValidPathNum = 0;

    ulFilePathNum = (pulPathNum != NULL) ? *pulPathNum : 0;

    ulValidPathNum = (ulFilePathNum >= ulBoardPaNum) ? ulFilePathNum : ulBoardPaNum;
    BspRecoredPaDacValidPathNum(ulValidPathNum);

    return ulValidPathNum;
}

/******************************************************************************
* 函数名称   : PADACSET_GetGridVoltRowDataNum
* 功能描述   : 获取栅压行数据数目
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输?霾问?   : 无
* 返 回 值   : 最大行数
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
static UINT32 PADACSET_GetGridVoltRowNum(VOID)
{
    //UINT32 *pulPathNum = _GET_COMHEADER_PP(ulPathNum);
    //return TBL_PA_GRID_VOLT_TYPE*(*pulPathNum);
    UINT32 dacNum = _GET_HEADER_TT(ulDacNum);
    UINT32 rowNum = 0;
    UINT32 loop;
    for (loop = 0; loop < dacNum; loop++)
    {
        rowNum += _GET_HEADER_TT(ulDacPath[loop]);
    }
    return rowNum;
}
/******************************************************************************
* 函数名称   : PADACSET_GetGridVoltColNum
* 功能描述   : 获取栅压列数据数目
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 最大列数
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
static UINT32 PADACSET_GetGridVoltColNum(VOID)
{
    UINT32 *pulN0 = _GET_HEADER_PP(aGridVoltN[0]);
    UINT32 *pulN1 = _GET_HEADER_PP(aGridVoltN[1]);
    if((NULL == pulN0) || (NULL == pulN1))
    {
    	return COMMON_ERROR;
    }

    return *pulN0 + *pulN1 + TBL_PA_GRID_VOLT_FIX_COL;
}

/******************************************************************************
* 函数名称   : PADACSET_GetGridVoltClassNum
* 功能描述   : 获取栅压class数据数目
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 最大列数
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
static UINT32 PADACSET_GetGridVoltClassNum(VOID)
{
    UINT32 *pulClassNum = _GET_HEADER_PP(ulClassNum);

    if(NULL == pulClassNum )
    {
        return 0;
    }
    else if(*pulClassNum == 0)
    {
        *pulClassNum = 1;  /* 兼容老版本没有这个字段的情况 */
        return 1;
    }
    else
    {
        return *pulClassNum;
    }
}

/******************************************************************************
* 函数名称   : PADACSET_ChkGridVoltTblResult
* 功能描述   : 检查栅压加载结果
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ulPaIndex--功放序号
* 输出参数   : 无
* 返 回 值   : COMMON_OK,加载成功；其它，加载失败；
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 PADACSET_ChkGridVoltTblResult(UINT32 class)
{
    UINT32 ulRetVal = COMMON_OK;
    UINT32 ulTheoryNum = 0;
    UINT32 ulRealNum = 0;
    UINT32 ulValidPath = 0;

    ulTheoryNum = PADACSET_GetGridVoltRowNum();
    ulRealNum   = _GET_CALI_TT(class,ulRecordNum);
    ulRetVal |= (ulRealNum > 0)?COMMON_OK: COMMON_ERROR;
#ifndef CONFIG_CFRGATERAM
    ulRetVal |= (ulTheoryNum==ulRealNum)?COMMON_OK : COMMON_ERROR;
#else
#endif
    ulValidPath = PADACSET_GetValidPathNum();
    ulRetVal |= (ulValidPath > 0) ? COMMON_OK : COMMON_ERROR;

    return ulRetVal;

}
/******************************************************************************
* 函数名称   : _BspPaDacSetChkTblResult
* 功能描述   : 检查加载结果
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : COMMON_OK,加载成功；其它，加载失败；
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 PADACSET_ChkTblResult(VOID)
{
    UINT32 ulRetVal = COMMON_OK;
    UINT32 *pulLoadFlag = NULL;
    UINT32 ulClassNum = 0;
    UINT32 loop = 0;

    ulClassNum = PADACSET_GetGridVoltClassNum();
    for(loop=0; loop<ulClassNum; loop++)
    {
       pulLoadFlag = _GET_CALI_PP(loop,ulPathLoadFlag);
       if( COMMON_OK == PADACSET_ChkGridVoltTblResult(loop))
       {
           if (NULL != pulLoadFlag)
           {
               *pulLoadFlag = TBL_LOAD_SUCC;
           }
           UARTprintf("Class %d Check [%s]\n",loop, "succ");
       }
       else
       {
           ulRetVal = COMMON_ERROR;
           if (NULL != pulLoadFlag)
           {
               *pulLoadFlag = TBL_LOAD_FAIL;
           }
           UARTprintf("Class %d Check [%s]\n",loop, "fail");
       }
    }

    return ulRetVal;
}
UINT32 g_DataEndFlag = 0;
static UINT32 PADACSET_GridVoltStart(T_TextTrans *ptText, const CHAR *pch)
{
    UINT32 ulRetVal = COMMON_OK;
    CHAR  achLine[TBL_MAX_LINE_LEN] = {0};         /* 保存一行的文本 */
    UINT32 ulRowDataSize = 0;
    UINT32 ulColDataSize = 0;
    /* UINT32 ulClassNum = 0; */
    UINT32 ulCnt = 0;
    UINT32 ulColumn = 0;
    T_PaDacSetGridVoltRecord * ptRecord = NULL;
    T_PaDacSetCaliPath *ptPath = NULL;

    ulRowDataSize = PADACSET_GetGridVoltRowNum();
    ulColDataSize = PADACSET_GetGridVoltColNum();

    ptPath = &gptPaDacSetCaliData[sulPaDacSetIndex]->tCali[sulCaliDataClass];
    ptRecord = (T_PaDacSetGridVoltRecord*)malloc(sizeof(T_PaDacSetGridVoltRecord) * ulRowDataSize);
    if (NULL == ptRecord)
    {
        return COMMON_ERROR;
    }
    memset(ptRecord, 0, sizeof(T_PaDacSetGridVoltRecord) * ulRowDataSize);

    ptPath->ptRecord = ptRecord;
    ulColumn = ulColDataSize;

    for(g_DataEndFlag = 0;;)
    {
        ulRetVal = _BspLineRead(ptText, achLine);
        if (COMMON_ERROR == ulRetVal)
        {
            break;
        }

        _BspSearchAndMapKeyWord(ptText, g_sulPaDacSetSection, achLine);
        if( 1 == g_DataEndFlag)
        {
            break;
        }

        if (ulCnt < ulRowDataSize)
        {
            _BspGetRecordFromStr_Raw(achLine,(INT32*)ptRecord,ulColumn);
            ptRecord++;
            ulCnt++;
        }
        ptPath->ulRecordNum++;
    }
    return COMMON_OK;
}

static UINT32 PADACSET_GridVoltEnd(T_TextTrans *ptText, const CHAR *pch)
{
    UINT32 *pulRecordNum = _GET_CALI_PP(sulCaliDataClass,ulRecordNum);
    g_DataEndFlag = 1;

    UARTprintf("recordnum %d\n", pulRecordNum ? *pulRecordNum : -1);
    return COMMON_OK;
}

static UINT32 PADACSET_GridVoltClassEnd(T_TextTrans *ptText, const CHAR *pch)
{
    if ((sulCaliDataClass+1) < TBL_MAX_CHAN_CLASSNUM)
    {
        sulCaliDataClass++;
    }

    return COMMON_OK;
}
/******************************************************************************
* 函数名称   : PADACSET_VarInit
* 功能描述   : 校准文本解析初始化
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
******************************************************************************/
static UINT32 PADACSET_VarInit(UINT32 ulIndex, T_TextTrans *ptText)
{
    UINT32 ulLoop;

    if (NULL == ptText)
    {
        return COMMON_ERROR;
    }


    for (ulLoop = 0; (ulLoop < 3) && (NULL == gptPaDacSetCaliData[ulIndex]); ulLoop++)
    {
        gptPaDacSetCaliData[ulIndex] = malloc(sizeof(T_PaDacSetCaliData));
    }
    if (NULL == gptPaDacSetCaliData[ulIndex])
    {
        return COMMON_ERROR;
    }
    memset(gptPaDacSetCaliData[ulIndex], 0, sizeof(T_PaDacSetCaliData));
    g_stPaDacSet.txtInfo  = (CHAR *)BspGetDacTxtInfo();
    g_stPaDacSet.txtInfoSize = BspGetDacTxtLen();

    memcpy(ptText, &g_stPaDacSet, sizeof(T_TextTrans));

    sulPaDacSetIndex = ulIndex;
    sulPaDacSetPath = 0;
    g_sulPaDacSetLoadEndFlag = TBL_LOAD_UNLOAD;
    g_sulPaDacSetSection = 0;
    sulCaliDataClass = 0;

    for (ulLoop = 0; (ulLoop < 3) && (NULL == gptPaDacSetCaliData[ulIndex]); ulLoop++)
    {
        gptPaDacSetCaliData[ulIndex] = malloc(sizeof(T_PaDacSetCaliData));
    }
    if (NULL == gptPaDacSetCaliData[ulIndex])
    {
        return COMMON_ERROR;
    }
    memset(gptPaDacSetCaliData[ulIndex], 0, sizeof(T_PaDacSetCaliData));
    memset((VOID *)&g_satPaDacSetKeyWordHead, 0, sizeof(g_satPaDacSetKeyWordHead));
    memset((VOID*)&g_satPaDacSetKeyWordPath, 0, sizeof(g_satPaDacSetKeyWordPath));

    memcpy(g_satPaDacSetKeyWordHead, g_atPaDacSetKeyWordHeader, sizeof(g_atPaDacSetKeyWordHeader));
    for (ulLoop = 0; ulLoop < TBL_MAX_TX_CHAN_NUM; ulLoop++)
    {
        memcpy(g_satPaDacSetKeyWordPath[ulLoop], g_atPaDacSetKeyWordModule, sizeof(g_atPaDacSetKeyWordModule));
    }

    return COMMON_OK;
}

static void BspInitMem(void *mem, size_t memSize)
{
    memset(mem, 0, memSize);
}

static UINT32 PADACSET_TransByPath_Mem(VOID)
{
    UINT32 loop = 0;
    UINT32 loopx = 0;
    UINT32 chan = 0;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    /* T_PaDacSetGridVoltRecord *ptRecordx = NULL; */
    /* T_PaDacSetCaliPath *pRecord = NULL; */
    T_PaDacSetCaliPath *pPath = NULL;
    UINT32 *pulLoadFlag = NULL;

    UINT32 ulValidPathNum = PADACSET_GetValidPathNum();
    UINT32 ulValidClassNum = PADACSET_GetGridVoltClassNum();

    if ((_GET_PADACSET_DATA(sulPaDacSetIndex)==NULL)||(sulPaDacSetIndex >= TBL_PA_DAC_SET_NUM))
    {
        return COMMON_ERROR;
    }


    UARTprintf("ulValidClassNum %d\n", ulValidClassNum);

    for(loopx=0; loopx<ulValidClassNum; loopx++)
    {
        pulLoadFlag = _GET_CALI_PP(loopx, ulPathLoadFlag);
        if (NULL == pulLoadFlag || *pulLoadFlag != TBL_LOAD_SUCC)
        {
            return COMMON_ERROR;
        }
        /* 先释放后分配内存 */
        if (_GET_PADACSET_DATA(sulPaDacSetIndex)->pCaliPath[loopx])
        {
            for (chan = 0; chan < ulValidPathNum; chan++)
            {
                if (_GET_PATHINFO_TT(loopx,chan,ptRecord))
                {
                    free(_GET_PATHINFO_TT(loopx, chan,ptRecord));
                }
            }
            free(_GET_PADACSET_DATA(sulPaDacSetIndex)->pCaliPath[loopx]);
        }
        pPath = (T_PaDacSetCaliPath *)malloc(ulValidPathNum*sizeof(T_PaDacSetCaliPath));
        if (pPath == NULL)
        {
            return COMMON_ERROR;
        }
        //coverity[cert_int30_c_violation:SUPPRESS]
        memset(pPath, 0, ulValidPathNum * sizeof(T_PaDacSetCaliPath));
        _GET_PADACSET_DATA(sulPaDacSetIndex)->pCaliPath[loopx] = pPath;

        /* 统计各通道记录数 */
        ptRecord = _GET_CALI_TT(loopx,ptRecord);
        if (NULL == ptRecord)
        {
            UARTprintf("Error! ptRecord cannot NULL;\n");
            return COMMON_ERROR;
        }

        for (loop = 0; loop < _GET_CALI_TT(loopx, ulRecordNum); loop++, ptRecord++)
        {
            if (ptRecord->ulPaChan >= ulValidPathNum)
            {
                continue;
            }
            pPath[ptRecord->ulPaChan].ulRecordNum++;
        }

        /* 给各通道的记录分配内存 */
        for (chan = 0; chan < ulValidPathNum; chan++)
        {
            pPath[chan].ptRecord = (T_PaDacSetGridVoltRecord *)malloc(pPath[chan].ulRecordNum*sizeof(T_PaDacSetGridVoltRecord));
            BspInitMem(pPath[chan].ptRecord, pPath[chan].ulRecordNum*sizeof(T_PaDacSetGridVoltRecord));
        }
    }
    return COMMON_OK;
}

static UINT32 PADACSET_TransByPath(UINT32 ulIndex)
{
    UINT32 loop = 0;
    UINT32 chan = 0;
    UINT32 loopx = 0;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    T_PaDacSetGridVoltRecord *ptRecordx = NULL;
    T_PaDacSetCaliPath *pRecord = NULL;
    T_PaDacSetCaliPath *pPath = NULL;
    UINT32 pathRecordNum[3][TBL_MAX_TX_CHAN_NUM] = {0};
    UINT32 ulValidPathNum = PADACSET_GetValidPathNum();
    UINT32 ulValidClassNum = PADACSET_GetGridVoltClassNum();

    if(ulIndex >= TBL_PA_DAC_SET_NUM)
    {
        return COMMON_ERROR;
    }
    /* 获取各通道的记录 */
    if( COMMON_OK != PADACSET_TransByPath_Mem() )
    {
        return COMMON_ERROR;
    }

    for(loopx=0; loopx<ulValidClassNum; loopx++)
    {
        ptRecord = _GET_CALI_TT(loopx, ptRecord);
        if (NULL == ptRecord)
        {
            UARTprintf("Error! ptRecord cannot NULL\n");
            return COMMON_ERROR;
        }

        for (loop = 0; loop < _GET_CALI_TT(loopx, ulRecordNum); loop++,ptRecord++)
        {
            chan = ptRecord->ulPaChan;
            if (chan < ulValidPathNum )
            {
                pRecord = gptPaDacSetCaliData[ulIndex]->pCaliPath[loopx] + chan;
                if( pathRecordNum[loopx][chan] <pRecord ->ulRecordNum )
                {
                    ptRecordx = pRecord ->ptRecord +  pathRecordNum[loopx][chan];
                    memcpy(ptRecordx, ptRecord, sizeof(T_PaDacSetGridVoltRecord));
                    pathRecordNum[loopx][chan]++;
                }
            }
        }

        if (NULL != _GET_PADACSET_DATA(ulIndex))
        {
            pPath = _GET_PADACSET_DATA(ulIndex)->pCaliPath[loopx];
        }
        else
        {
            pPath = NULL;
        }
        if (NULL == pPath)
        {
            return COMMON_ERROR;
        }

        /* 校验结果 */
        for (chan = 0; chan < ulValidPathNum; chan++)
        {
            if (pathRecordNum[loopx][chan] == pPath[chan].ulRecordNum)
            {
                UARTprintf("PaDacSet Path[%d] Class[%d] Load Succ.\n",chan,loopx);
            }
            else
            {
                UARTprintf("PaDacSet Path[%d] Class[%d] Load Fail.\n",chan,loopx);
            }
        }
    }

    return COMMON_OK;
}

/******************************************************************************
* 函数名称   : _BspPaDacSetLoad
* 功能描述   : PaDacSet.txt校准文本加载函数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : data-校准文件当前文件信息位置记录
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
UINT32 _BspPaDacSetLoad(T_TextTrans  *ptText)
{
    UINT32 ulRetVal = COMMON_OK;
    CHAR  achLine[TBL_MAX_LINE_LEN] = {0};         /* 保存一行的文本 */
    UINT32 loop = 0;
    for(;;)
    {
        ulRetVal = _BspLineRead(ptText, achLine );
        if( COMMON_ERROR == ulRetVal || TBL_LOAD_END == g_sulPaDacSetLoadEndFlag)
        {
            break;
        }
        _BspSearchAndMapKeyWord(ptText, g_sulPaDacSetSection, achLine);
        loop++;

    }
    return COMMON_OK;
}

/******************************************************************************
* 函数名称   : BspPaDacSetCalibInit
* 功能描述   : PaDacSet.txt校准文本解析初始化
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
******************************************************************************/
UINT32 BspPaDacSetCalibInit(UINT32 ulIndex)
{
    UINT32 ulRetVal = COMMON_OK;
    T_TextTrans   tText = {0};

    if (ulIndex >= TBL_PA_DAC_SET_NUM)
    {
        return COMMON_ERROR;
    }

    ulRetVal = PADACSET_VarInit(ulIndex, &tText);
    if (ulRetVal != COMMON_OK)
    {
        return COMMON_ERROR;
    }

    if (COMMON_OK == ulRetVal)
    {
        ulRetVal = _BspPaDacSetLoad(&tText);
        _BspTextTransExit(&tText);
        ulRetVal |= PADACSET_ChkTblResult();
        ulRetVal |= PADACSET_TransByPath(ulIndex);
    }

    return ulRetVal;
}

UINT32 _BspSetPaDacSetTextTrans(T_TextTrans *tText)
{
    INPUT_POINTER_CHECK(tText);
    memcpy(g_stPaDacSet.acFileName, tText->acFileName, sizeof(g_stPaDacSet.acFileName));
    memcpy(g_stPaDacSet.acFileNameInProcFile, tText->acFileNameInProcFile, sizeof(g_stPaDacSet.acFileNameInProcFile));
    memcpy(g_stPaDacSet.acFileNameInSysFile, tText->acFileNameInSysFile, sizeof(g_stPaDacSet.acFileNameInSysFile));

    return COMMON_OK;
}

/******************************************************************************
* 函数名称   : _BspGetPaDacSetCalibData
* 功能描述   :
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 指针
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2014-06-20 16:36 创建
******************************************************************************/
T_PaDacSetCaliData * _BspGetPaDacSetCalibData(UINT32 ulIndex)
{
    return _GET_PADACSET_DATA(ulIndex);
}


/* 公共键值处理函数-版本 */
COMPS_FUNC_INT_IMP(V, _GET_COMHEADER_PP(ulVer), _GET_COMHEADER_INTNUM(ulVer), NULL)

/* 公共键值处理函数-日期 */
COMPS_FUNC_STR_IMP(DATE, _GET_COMHEADER_TT(aucDate), _GET_COMHEADER_STRNUM(aucDate), NULL)

/* 公共键值处理函数-执行者 */
COMPS_FUNC_STR_IMP(OPERATOR, _GET_COMHEADER_TT(aucOperator), _GET_COMHEADER_STRNUM(aucOperator), NULL)

/* 公共键值处理函数-检查者 */
COMPS_FUNC_STR_IMP(CHECKER, _GET_COMHEADER_TT(aucChecker), _GET_COMHEADER_STRNUM(aucChecker), NULL)

/* 公共键值处理函数-校准文件包括的通道数目 */
COMPS_FUNC_INT_IMP(PATHNUM, _GET_COMHEADER_PP(ulPathNum), _GET_COMHEADER_INTNUM(ulPathNum), PADACSET_SetSection)

/* 公共键值处理函数-结束字符 */
COMPS_FUNC_INT_IMP(FILEEND, NULL, 0, NULL)


/* 文件私有头部-DAC数 */
COMPS_FUNC_INT_IMP(DAC_NUM, _GET_HEADER_PP(ulDacNum), _GET_HEADER_INTNUM(ulDacNum), NULL)
/* 文件私有头部-DAC通道数 */
COMPS_FUNC_INT_IMP(DAC_PATH, _GET_HEADER_PP(ulDacPath), _GET_HEADER_INTNUM(ulDacPath), NULL)
/* 文件私有部分-row */
COMPS_FUNC_INT_IMP(GRIDVOLT_ROW, NULL, 0, NULL)
/* 文件私有部分-n value 单独定义了一个函数 */
//COMPS_FUNC_INT_IMP(GRIDVOLT_N, _GET_HEADER_PP(aGridVoltN), _GET_HEADER_INTNUM(aGridVoltN), NULL);
FUZZY_COMPS_FUNC_INT_IMP(GRIDVOLT_PATH_INDEX, TBL_PA_MAX_FREQ_NUM, _GET_HEADER_PP(pathIndex), _GET_HEADER_INTNUM(pathIndex[0]), NULL)
FUZZY_COMPS_FUNC_INT_IMP(GRIDVOLT_PA_FREQ, TBL_PA_MAX_FREQ_NUM, _GET_HEADER_PP(paFreq), _GET_HEADER_INTNUM(paFreq[0]), NULL)
/* class num */
COMPS_FUNC_INT_IMP(GRIDVOLT_CLASS_NUM, _GET_HEADER_PP(ulClassNum), _GET_HEADER_INTNUM(ulClassNum), PADACSET_SetSection)

/* 文件正常部分 */
COMPS_FUNC_INT_IMP(GRIDVOLT_DATA_S0, NULL, 0, PADACSET_GridVoltStart)
COMPS_FUNC_INT_IMP(GRIDVOLT_DATA_E0, NULL, 0, PADACSET_GridVoltEnd)
COMPS_FUNC_INT_IMP(GRIDVOLT_CLASS_E0, NULL, 0, PADACSET_GridVoltClassEnd)
COMPS_FUNC_INT_IMP(GRIDVOLT_DATA_S1, NULL, 0, PADACSET_GridVoltStart)
COMPS_FUNC_INT_IMP(GRIDVOLT_DATA_E1, NULL, 0, PADACSET_GridVoltEnd)
COMPS_FUNC_INT_IMP(GRIDVOLT_CLASS_E1, NULL, 0, PADACSET_GridVoltClassEnd)
COMPS_FUNC_INT_IMP(GRIDVOLT_DATA_S2, NULL, 0, PADACSET_GridVoltStart)
COMPS_FUNC_INT_IMP(GRIDVOLT_DATA_E2, NULL, 0, PADACSET_GridVoltEnd)
COMPS_FUNC_INT_IMP(GRIDVOLT_CLASS_E2, NULL, 0, PADACSET_GridVoltClassEnd)


#if 0
/******************************************************************************
* 函数名称   : _BspPaDacSetReloadEn
* 功能描述   : 文件重新加载的使能
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
* 输出参数   : 无
* 返 回 值   : 无；
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), zhaoyun@2014-11-18 19:32 创建
******************************************************************************/
VOID _BspPaDacSetReloadEn(VOID)
{

}
#endif

/******************************************************************************
* 函数名称   : _BspPaDacSetConvert
* 功能描述   : 数据信道覆盖，保证从片的数据放在从0开始位置。
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ulSubFileNo：子文件编号；
            ulIniChan：覆盖数据的起始通道
            ulChanNum：覆盖数据的通道数目
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2017-05-01 16:36 创建
******************************************************************************/
UINT32 _BspPaDacSetConvert(UINT32 ulSubFileNo,UINT32 ulIniChan, UINT32 ulChanNum)
{

    UINT32 ulRet = COMMON_OK;
    UINT32 ulTmp = 0;
    UINT32 ulLoop = 0;
    UINT32 ulLoopx = 0;
    UINT32 ulValidClassNum = PADACSET_GetGridVoltClassNum();
    T_PaDacSetCaliPath * pCaliPath = NULL;
    ulTmp = ulIniChan + ulChanNum;
    
    if( 0 == ulIniChan )
    {
        return ulRet;
    }

    if( (ulTmp > TBL_MAX_TX_CHAN_NUM) || (ulSubFileNo>= TBL_PA_DAC_SET_NUM) )
    {
        ulRet = COMMON_ERROR;
        return ulRet;
    }
    for(ulLoopx=0; ulLoopx<ulValidClassNum; ulLoopx++)
    {
        pCaliPath = gptPaDacSetCaliData[ulSubFileNo]->pCaliPath[ulLoopx];

        for( ulLoop=0; ulLoop<ulChanNum; ulLoop++ )
        {
            memcpy((VOID*)(pCaliPath+ulLoop), (VOID*)(pCaliPath+ulLoop+ulIniChan), sizeof(T_PaDacSetCaliPath));
        }
    }

    return ulRet;
}

UINT32 _BspPaDacSetConvertV2(UINT32 ulSubFileNo,UINT32 ulIniChan, UINT32 dstChan, UINT32 ulChanNum)
{

    UINT32 ulRet = COMMON_OK;
    UINT32 ulTmp = 0;
    UINT32 ulLoop = 0;
    UINT32 ulLoopx = 0;
    UINT32 ulValidClassNum = PADACSET_GetGridVoltClassNum();
    T_PaDacSetCaliPath * pCaliPath = NULL;
    ulTmp = ulIniChan + ulChanNum;
    
    if( 0 == ulIniChan )
    {
        return ulRet;
    }

    if( (ulTmp > TBL_MAX_TX_CHAN_NUM) || (ulSubFileNo>= TBL_PA_DAC_SET_NUM)  || ((dstChan+ulChanNum) > TBL_MAX_TX_CHAN_NUM))
    {
        ulRet = COMMON_ERROR;
        return ulRet;
    }
    for(ulLoopx=0; ulLoopx<ulValidClassNum; ulLoopx++)
    {
        pCaliPath = gptPaDacSetCaliData[ulSubFileNo]->pCaliPath[ulLoopx];

        for( ulLoop=0; ulLoop<ulChanNum; ulLoop++ )
        {
            memcpy((VOID*)(pCaliPath+ulLoop+dstChan), (VOID*)(pCaliPath+ulLoop+ulIniChan), sizeof(T_PaDacSetCaliPath));
        }
    }

    return ulRet;
}

/******************************************************************************
* 函数名称   : _BspPaDacSetChipMap
* 功能描述   : 芯片编号的替换，保证从片SOC的DAC数目从0编号
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : ulSubFileNo：子文件编号；
            ulAbsoluteChip：绝对芯片编号
            ulRelativeChip：相对芯片编号，从0开始
* 输出参数   : 无
* 返 回 值   : COMMON_OK - 成功
*              其他   - 错误码
* 其它说明   : 无
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 崔文会@2017-05-01 16:36 创建
******************************************************************************/
UINT32 _BspPaDacSetChipMap(UINT32 ulSubFileNo,UINT32 ulAbsoluteChip, UINT32 ulRelativeChip)
{
    UINT32 ulRet = COMMON_OK;
    UINT32 Loopx = 0;
    UINT32 Loopy = 0;
    /* UINT32 Loop =0; */
    UINT32 Num = 0;
    T_PaDacSetCaliPath *ptPath = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    UINT32 ulValidClassNum = PADACSET_GetGridVoltClassNum();

    if( ulSubFileNo>= TBL_PA_DAC_SET_NUM )
    {
        ulRet = COMMON_ERROR;
        return ulRet;
    }
    for(Loopy=0; Loopy<ulValidClassNum; Loopy++)
    {
        ptPath = gptPaDacSetCaliData[ulSubFileNo]->pCaliPath[Loopy];

        for(Num=0;Num<PADACSET_GetValidPathNum();Num++)
        {
            for( Loopx=0; Loopx<ptPath ->ulRecordNum; Loopx++ )
            {
                ptRecord = ptPath ->ptRecord+ Loopx;
                if( ptRecord ->ulDacPhyIndex == ulAbsoluteChip )
                {
                    ptRecord ->ulDacPhyIndex = ulRelativeChip;
                }
            }
            ptPath++;
        }
    }

    return ulRet;
}

static UINT32 s_multySubFileProcessFlag = 0;
VOID BspSetMultySubFileProcessFlag(UINT32 flag)
{
    s_multySubFileProcessFlag = flag;
}
#if 0
UINT32 BspGetMultySubFileProcessFlag(VOID)
{
    return s_multySubFileProcessFlag;
}


UINT32 BspGetSubFileExistStatus(UINT32 fileType, UINT32 subIndex)
{
    UINT8 *pBuf = NULL;
    INT32 tmpRet = 0;
    INT32 snpRet = 0;
    CHAR filePath[64] = {0};
    UINT8 aucTmpName[32] = {0};

    if (BspGetMultySubFileProcessFlag() != SWITCH_ON)
    {
        return COMMON_OK;
    }

    if (fileType == TBL_KIND_OF_PADACSET)
    {
        pBuf = strstr(g_stPaDacSet.acFileNameInProcFile, ".txt");
        memcpy(aucTmpName, (uintptr_t)pBuf - (uintptr_t)g_stPaDacSet.acFileNameInProcFile, g_stPaDacSet.acFileNameInProcFile, (uintptr_t)pBuf - (uintptr_t)g_stPaDacSet.acFileNameInProcFile);
        snpRet = snprintf(filePath, sizeof(filePath), "%s%d%s", aucTmpName, subIndex, ".txt");
        SNPRINTF_S_CHECK(snpRet,sizeof(filePath));
        UARTprintf("the filepath:[%s]\r\n",filePath);

        if (COMMON_OK != access(filePath,F_OK))
        {
            UARTprintf("%s>> test file [%s] exist! the part of board does not participate in the test ...\r\n",__func__,filePath);
            return COMMON_ERROR;
        }
    }

    return COMMON_OK;
}
#endif

static UINT32 GetParaInfoIndex(T_PaDacSetGridVoltRecord *ptRecord, UINT32 pointNum, INT32 data)
{
    UINT32 loop = 0;
    INT32  tempInf = 0;

    INPUT_POINTER_CHECK(ptRecord);
    for (loop = 0; loop < pointNum; loop++)
    {
        tempInf = ptRecord->lPointAndCoefficient[loop];
        if (data <= tempInf)
        {
            break;
        }
    }

    return loop;
}

static UINT32 getAllTempPointData(T_PaDacSetGridVoltRecord *ptRecord, INT32 *tempData, UINT32 pointNum)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(ptRecord);
    INPUT_POINTER_CHECK(tempData);
    for(loop = 0; loop < pointNum; loop++)
    {
        tempData[loop] = ptRecord->lPointAndCoefficient[loop];
    }

    return COMMON_OK;
}

static UINT32 getAllTempCoefData(T_PaDacSetGridVoltRecord *ptRecord, INT32 *tempData, UINT32 coefNum, UINT32 pointNum)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(ptRecord);
    INPUT_POINTER_CHECK(tempData);
    for(loop = 0; loop < coefNum; loop++)
    {
        tempData[loop] = ptRecord->lPointAndCoefficient[pointNum + loop];
    }

    return COMMON_OK;
}

static INT32 getFinalDacData(T_PaDacSetGridVoltRecord *ptRecord, INT32 dacData)
{
    INPUT_POINTER_CHECK(ptRecord);

    if(dacData < ptRecord->ulGridVoltLower)
    {
        dacData = ptRecord->ulGridVoltLower;
    }

    if(dacData > ptRecord->ulGridVoltUpper)
    {
        dacData = ptRecord->ulGridVoltUpper;
    }

    return dacData;
}

VOID BspSetPaVibasSw(UINT8 sw)
{
    s_paVibasSw = sw;
}

UINT8 BspGetPaVibasSw()
{
    return s_paVibasSw;
}

UINT32 BspSetPaVibasByChan(UINT32 index, UINT32 paChan)
{
    INT32  dacData = 0;
    INT32  tempOfDacData = 0;
    INT32  tempPoint[10] = {0};
    INT32  tempCoef[10]  = {0};
    INT32  rdTemp  = 0;
    UINT32 dacChan = 0;
    UINT32 loop = 0;
    UINT32 pointNum  = 0;
    UINT32 coefNum  = 0;
    UINT32 stdInfIndex = 0;
    UINT32 currInfIndex = 0;
    UINT8 num = 0;
    T_PaDacSetCaliData *dacSetInfo = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;

    if(BspGetPaVibasSw() == SWITCH_OFF)
    {
        return COMMON_OK;
    }

    dacSetInfo = _BspGetPaDacSetCalibData(index);        /* 获取写表数据 */
    INPUT_POINTER_CHECK(dacSetInfo);
    INPUT_POINTER_CHECK(dacSetInfo->pCaliPath[0]);

    ptRecord = dacSetInfo->pCaliPath[0][paChan].ptRecord;   /* 解析后的paChan通道数据 */
    INPUT_POINTER_CHECK(ptRecord);

    if(BspGetAmc7836Temp(0, 0, &rdTemp) == COMMON_ERROR)  /*获取DAC温度*/
    {
        UARTprintf(" pachan[%d] get dac temp err!\n", paChan);
        //return COMMON_ERROR;
    }

    for (num = 0; num < dacSetInfo->pCaliPath[0][paChan].ulRecordNum; num++)
    {
        dacChan       = ptRecord->ulDacChanIndex;       /* DAC通道索引 */
        dacData       = ptRecord->ulGridVoltDataDef;    /* 基准电压 */
        tempOfDacData = ptRecord->lGridVoltTempFixDef;  /* 基准温度 */

        pointNum = dacSetInfo->tHeader.aGridVoltN[0];   /* 折点温度点数 */
        coefNum = dacSetInfo->tHeader.aGridVoltN[1];    /* 补偿系数种类数 */

        if ((pointNum + coefNum) > NELEMENTS(ptRecord->lPointAndCoefficient))    /* 是否溢出 */
        {
            UARTprintf("over flow err!\n");/* 停止整个paChan配置 */
            break;
        }

        getAllTempPointData(ptRecord, tempPoint, pointNum);                   /* 取出所有补偿系数 */
        getAllTempCoefData(ptRecord, tempCoef, coefNum, pointNum);           /* 取出所有补偿系数 */

        stdInfIndex  = GetParaInfoIndex(ptRecord, pointNum, tempOfDacData);    /* 找出基准值落在哪段折线上 */
        currInfIndex = GetParaInfoIndex(ptRecord, pointNum, rdTemp);            /* 找出当前温度落在哪段折线上 */

        if (currInfIndex > stdInfIndex)                 /* 计算当前温度的DAC值 */
        {
            for (loop = stdInfIndex; loop < currInfIndex; loop++)
            {
                /*  (折点温度-基准温度) * 补偿系数 */
                dacData += (((tempPoint[loop] - tempOfDacData) * tempCoef[loop]) / CONVERSIN_FACTOR_TEMP);
                tempOfDacData = tempPoint[loop];
            }
        }
        else if (currInfIndex < stdInfIndex)
        {
            for (loop = stdInfIndex; loop > currInfIndex; loop--)
            {
                /*  (折点温度-基准温度) * 补偿系数 */
                dacData += (((tempPoint[loop-1] - tempOfDacData) * tempCoef[loop]) / CONVERSIN_FACTOR_TEMP);
                tempOfDacData = tempPoint[loop-1];
            }
        }
        else
        {
            loop = currInfIndex;
        }

        dacData += (((rdTemp - tempOfDacData) * tempCoef[loop]) / CONVERSIN_FACTOR_TEMP);
        dacData = getFinalDacData(ptRecord, dacData);

        zxDRV_Amc7836SetPaGridDac(0, dacChan, dacData);//设置DAC值
        ptRecord++;
    }

    return COMMON_OK;
}

UINT32 BspClrPaVibasByChan(UINT32 index, UINT32 paChan)
{
    UINT32 dacChan = 0;
    UINT8 num = 0;
    T_PaDacSetCaliData *dacSetInfo = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;

    if (paChan >= BSP_MAX_CHAN_NUM)
    {
        return COMMON_ERROR;
    }

    dacSetInfo = _BspGetPaDacSetCalibData(index);        /* 获取写表数据 */
    INPUT_POINTER_CHECK(dacSetInfo);
    INPUT_POINTER_CHECK(dacSetInfo->pCaliPath[0]);

    ptRecord = dacSetInfo->pCaliPath[0][paChan].ptRecord;   /* 解析后的paChan通道数据 */
    INPUT_POINTER_CHECK(ptRecord);

    for (num = 0; num < dacSetInfo->pCaliPath[0][paChan].ulRecordNum; num++)
    {
        dacChan  = ptRecord->ulDacChanIndex;       /* DAC通道索引 */
        zxDRV_Amc7836SetPaGridDac(0, dacChan, 0);//设置DAC值
        ptRecord++;
    }

    return COMMON_OK;
}

UINT32 BspSetAllPaVibas()
{
    UINT32 ret = 0;
    UINT8 loop = 0;

    for(loop = 0; loop < BSP_MAX_CHAN_NUM; loop++)
    {
        ret |= BspSetPaVibasByChan(0, loop);
    }

    return ret;
}


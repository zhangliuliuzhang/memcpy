/*****************************************************************************
 * 版权所有(C) 2023, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : uart_ook.c
 * 文件标识 : {[N/A]}
 * 内容摘要 :
 * 注意事项 : 无
 * 作    者 : 王威 10263627
 * 创建日期 : 2023年08月25日16:22:51
 * 当前版本 : Ver1.0
 */
#include <string.h>
#include "typedef.h"
#include "uart_ook.h"
#include "common.h"
#include "hal_uart.h"
#include "gd32f4xx_usart.h"
#include "utils.h"
#include "eeprom.h"
#include "app_upgrade.h"
#include "uartprint.h"
#include "hal_flash.h"
#include "dh250.h"
#include "cmdline.h"
#include "fpga_xininx.h"
#include "amc7836.h"
#include "app_flash_manage.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define MAX_OOK_DATA_NUM    (256)
#define PRINT_FLAG_OPEN      (1)
#define PRINT_FLAG_CLOSE     (0)

#define OOK_INPUT_POINTER_CHECK(ppointer, msgType, serialNo)                           \
    if (NULL == ppointer)                                      \
    {                                                           \
        BspSendOokAck(msgType, RFS_MSG_ACK_ERROR, serialNo);    \
        return;                                                 \
    }                                                           \

#define OOK_PARA_TBL_INDEX_CHECK(index, msgType, serialNo)                           \
    if (index >= EEPROM_FILE_TYPE_MAX)                                      \
    {                                                           \
        UARTprintf("Index = %d is Err!\n", index);  \
        BspSendOokAck(msgType, RFS_MSG_ACK_CHECK_ERROR, serialNo);    \
        return ;                                                 \
    }                                                           \

#define OOK_LINK_CHECK(msgType, serialNo)                           \
    if (BspGetLinkStatus() != OOK_LINK_SUCCESS)                                      \
    {                                                           \
        UARTprintf("Link Fail!\n");  \
        BspSendOokAck(msgType, RFS_MSG_ACK_LINK_ERROR, serialNo);    \
        return ;                                                 \
    }                                                           \
/**************************************************************************
 *                        变量声明
 **************************************************************************/
static Queue s_uartRecvBuf = {
    .start = 0,
    .end = 0,
    .size = 0,
    .capacity = sizeof(s_uartRecvBuf.datas) / sizeof(s_uartRecvBuf.datas[0]),
    .datas = {0}
};

static UINT32 s_headSumErrCnt = 0;
static UINT32 s_crcErrCnt = 0;
static T_MsgReceive  s_msg;
static T_MsgSend s_msg_send;
static T_OOK_ACTION_FUNC *s_ookFuncPara = NULL;
static UINT8 ookData[MAX_OOK_DATA_NUM] = {0,};
static UINT16 dataNum = 0;
static UINT16 OokRecvNum = 0;
static UINT8 s_ookLinkState = 0;
static UINT32 s_randCode = 0;
UINT8 ookHandleData[MAX_OOK_DATA_NUM] = {0, };
UINT8 g_ookFinshFlag = 0;
static UINT32 s_mcuVerCrc = 0;
UINT8 s_wfsFlag = 0;                /*工装标志*/
/**************************************************************************
 *                        函数声明
 **************************************************************************/
static void CreateFrameHead(T_RfsFrameHead *head, UINT8 *datas, UINT16 dataSize);
static void FrameDataCopy(UINT8 *dest, UINT32 destSize, const UINT8 *src, UINT32 srcSize);
static UINT8 CalculateCrc(const UINT8 *datas, UINT32 dataSize);
VOID BspBuildLinkAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspSendHeartBeatAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspRfCtrlProc(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspLedCtrlAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspGridVoltCtrl(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspOffLineParaDownAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspOffLineParaDownLoad(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspOffLineParaUpAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspOffLineParaUpLoad(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspTestCmdAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspVersionCompareInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspVersionDownLoadAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspVersionActionAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspTimeDelayMeasuerAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspBoardResetCtrlAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspTddCtrlCfgAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspBeamwidthCfgAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspSetPaVoltAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspGetTeapAndVoltInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspGetAlmInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspGetSwitchStatusAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspClrAlmStatusAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspGetAnalogVoltAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspGetGridVoltAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspSwitchModeCtrl(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspSendRruInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspWfsBoardInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspWfsAdValAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspWfsCurrValAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
VOID BspWfsRfTblCrcCheck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo);
UINT8 CalculateCheckSum(T_RfsFrameHead *head);
UINT32 BspSendMsgProc(T_MsgReceive *recv);
VOID BspSendMsgOokProc(T_RfsFrame *recv);
VOID BspSendRruInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index);
VOID BspSendRruBoardInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index);
VOID BspSendRruPwrInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index);
VOID BspSendRruPaInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index);
VOID BspSendRruDflInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index);
VOID BspSendRruAntInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index);
/**************************************************************************
 *                        函数实现
 **************************************************************************/
T_MsgSendPara s_msgSendInfo[RFS_MSG_MAX] =
{
    [RFS_MSG_LINK_ACK]                = {BspBuildLinkAck},
    [RFS_MSG_HEART_BEAT]              = {BspSendHeartBeatAck},
    [RFS_MSG_RF_SWITCH_CTRL]          = {BspRfCtrlProc},
    [RFS_MSG_LED_CTRL]                = {BspLedCtrlAck},
    [RFS_MSG_GRID_VOLT_CTRL]          = {BspGridVoltCtrl},
    [RFS_MSG_OFF_LINE_PARA_DOWN_REQ]  = {BspOffLineParaDownAck},
    [RFS_MSG_OFF_LINE_PARA_DOWN_LOAD] = {BspOffLineParaDownLoad},
    [RFS_MSG_OFF_LINE_PARA_UP_REQ]    = {BspOffLineParaUpAck},
    [RFS_MSG_OFF_LINE_PARA_UP_LOAD]   = {BspOffLineParaUpLoad},
    [RFS_MSG_TEST_COMMAND_REQ]        = {BspTestCmdAck},
    [RFS_MSG_VERSION_COMPARE_INFO]    = {BspVersionCompareInfoAck},
    [RFS_MSG_VERSION_DOWNLOAD]        = {BspVersionDownLoadAck},
    [RFS_MSG_VERSION_ACTION]          = {BspVersionActionAck},
    [RFS_MSG_TIME_DELAY_MEASURE]      = {BspTimeDelayMeasuerAck},
    [RFS_MSG_RESET_TYPE]              = {BspBoardResetCtrlAck},
    [RFS_MSG_TDD_CTRL]                = {BspTddCtrlCfgAck},
    [RFS_MSG_BEAMWIDTH_CTRL]          = {BspBeamwidthCfgAck},
    [RFS_MSG_PA_VOLT_CTRL]            = {BspSetPaVoltAck},
    [RFS_MSG_TEAM_AND_VOLT_QUERY]     = {BspGetTeapAndVoltInfoAck},
    [RFS_MSG_ALM_QUERY]               = {BspGetAlmInfoAck},
    [RFS_MSG_SW_STATUS_QUERY]         = {BspGetSwitchStatusAck},
    [RFS_MSG_CLR_ALM]                 = {BspClrAlmStatusAck},
    [RFS_MSG_GET_ANALOG_VOLT]         = {BspGetAnalogVoltAck},
    [RFS_MSG_GET_RRU_INFO]            = {BspSendRruInfoAck},
    [RFS_MSG_GET_GRID_VOLT]           = {BspGetGridVoltAck},
    [RFS_MSG_SWITCH_MODE_CTRL]        = {BspSwitchModeCtrl},
};

T_MsgSendPara s_wfsMsgSendInfo[RFS_WFS_MSG_MAX] =
{
    [RFS_WFS_MSG_BOARD_INFO]           = {BspWfsBoardInfoAck},
    [RFS_WFS_MSG_AD_VAL]               = {BspWfsAdValAck},
    [RFS_WFS_MSG_CURR_VAL]             = {BspWfsCurrValAck},
    [RFS_WFS_MSG_RFTBL_CRC]            = {BspWfsRfTblCrcCheck},
};

/* Started by AICoder, pid:m80f22be8d0e7a5145a10bfea0fb7f1258605a2b */
T_MsgRruInfoPara s_rruInfoSubType[RFS_MSG_RRU_SUB_MAX] =
{
    [RFS_MSG_VERSION_INFO]           = { NULL },    /* 预留字段 */
    [RFS_MSG_RRU_INFO]               = { BspSendRruInfo },
    [RFS_MSG_BOARD_INFO]             = { BspSendRruBoardInfo },
    [RFS_MSG_PWR_INFO]               = { BspSendRruPwrInfo },
    [RFS_MSG_PA_INFO]                = { BspSendRruPaInfo },
    [RFS_MSG_DFL_INFO]               = { BspSendRruDflInfo },
    [RFS_MSG_ANT_INFO]               = { BspSendRruAntInfo },
};
/* Ended by AICoder, pid:m80f22be8d0e7a5145a10bfea0fb7f1258605a2b */

UINT8 s_msgSubType = 0;
VOID BspSetMsgSubType(UINT8 msgSubType)
{
    s_msgSubType = msgSubType;
}

UINT8 BspGetMsgSubType(VOID)
{
    return s_msgSubType;
}

UINT8 BspGetOokStatus()
{
    return g_ookFinshFlag;
}

VOID BspSetOokStatus(UINT8 status)
{
    g_ookFinshFlag = status;
}

static T_OOK_ACTION_FUNC *BspGetOokFuncPara(VOID)
{
    return s_ookFuncPara;
}

VOID BspSetOokFuncPara(T_OOK_ACTION_FUNC *p_ookFuncPara)
{
    if(p_ookFuncPara == NULL)
    {
        return;
    }
    s_ookFuncPara = p_ookFuncPara;
}

VOID BspSetLinkStatus(UINT8 status)
{
    s_ookLinkState = status;
}

UINT8 BspGetLinkStatus()
{
    return s_ookLinkState;
}

UINT32 BspGetMcuVerCrc()
{
    return s_mcuVerCrc;
}

VOID BspSetMcuVerCrc(UINT32 crc)
{
    s_mcuVerCrc = crc;
}

VOID BspSetWfsFlag(UINT8 flag)
{
    s_wfsFlag = flag;
}

UINT8 BspGetWfsFlag()
{
    return s_wfsFlag;
}

/**************************************************************************
 *                        方案一：中断收，定时器取，while 处理
 **************************************************************************/
BOOL QueueIsEmpty(Queue *queue)
{
    if (queue == NULL)
    {
        return TRUE;
    }

    return queue->size == 0;
}

void QueuePush(Queue *queue, UINT8 data)    /*以字节为单位，往data中存储数据*/
{

    queue->datas[queue->end++] = data;
    queue->size++;

    if (queue->end >= queue->capacity)   /*超过接受的最大范围，从头读取？*/
    {
        queue->end = 0;
    }
}

UINT8 QueuePop(Queue *queue)  /*从队列中取数据，取出来一个，队列长度减少？*/
{
    UINT8 top = 0;

    if (queue == NULL)
    {
        return 0;
    }

    top = queue->datas[queue->start++];
    queue->size--;
    if (queue->start >= queue->capacity)
    {
        queue->start = 0;
    }
    return top;
}

void BspPushReceivedData(UINT8 data)       /*通过串口中断触发，往MEM0 里面存数据*/
{
    QueuePush(&s_uartRecvBuf, data);    /*一次最多也就存512字节，存满了会从0开始重新覆盖存*/
}

UINT32 GetFrameHeadSumErrorCnt()
{
    return s_headSumErrCnt;
}

UINT32 GetFrameCrcErrorCnt()
{
    return s_crcErrCnt;
}

static T_MsgReceive *GetRecvFrame()
{
    return &s_msg;
}

static T_MsgSend *GetSendFrame()
{
    return &s_msg_send;
}

static BOOL DoesRecvHaveFrameStartFlag(T_MsgReceive *recv)
{
    const UINT8 frameStartFlag1 = 0x7E;
    const UINT8 frameStartFlag2 = 0xEF;
    static UINT8 lastRecv = 0;
    UINT32 curRecv = 0;

    if (recv == NULL)
    {
        return FALSE;
    }

    if (recv->bufState != RECV_BUF_FREE)   /*状态是free的时候，才往下走，就是说处理消息时，消息状态必须是在fee的时候，才能开始解析？*/
    {
        return TRUE;
    }

    while (!QueueIsEmpty(&s_uartRecvBuf))   /*对串口来的消息解析，指导出现7eef，如果没有就返回false*/
    {
        curRecv = QueuePop(&s_uartRecvBuf);
        if ( (lastRecv == frameStartFlag1) && (curRecv == frameStartFlag2) )  /*校验消息头部是否是0x7eef*/
        {
            recv->frame.frameHead.startFlag1 = frameStartFlag1;
            recv->frame.frameHead.startFlag2 = frameStartFlag2;
            recv->recvdLen = sizeof(frameStartFlag1) + sizeof(frameStartFlag2);
            recv->bufState = RECV_BUF_WRITING;    /*来数据了，置于正在写的状态*/
            lastRecv = curRecv;
            return TRUE;
        }
        lastRecv = curRecv;
    }

    return FALSE;
}

static BOOL DoesRecvMsgHeadDone(T_MsgReceive *recv)   /*往recv这个指针中填充头部数据，完成后，s_uartRecvBuf头部数据就被剔除了*/
{
    UINT8 *recvBuf = NULL;
    const UINT32 expRecvLen = sizeof(T_RfsFrameHead);    /*填充的是头部*/

    if (recv == NULL)
    {
        return FALSE;
    }

    recvBuf = (UINT8 *)&recv->frame;

    while ( (recv->recvdLen < expRecvLen) && (!QueueIsEmpty(&s_uartRecvBuf)) )
    {
        recvBuf[recv->recvdLen++] = QueuePop(&s_uartRecvBuf);    /*把串口中的消息，往recv->frame中搬*/
    }

    return (recv->recvdLen >= expRecvLen);
}

static BOOL IsMsgHeadValid(T_RfsFrameHead *head)
{
    UINT8 calcHeadSum = 0;

    if (head == NULL)
    {
        return FALSE;
    }

    calcHeadSum = CalculateCheckSum(head);

    return ( (head->headSum == calcHeadSum) && (head->dataLength <= sizeof(((T_RfsFrame *)NULL)->frameData)) );
}

static BOOL DoesRecvAllDataDone(T_MsgReceive *recv)
{
    UINT8 *recvBuf = NULL;
    UINT32 loop = 0;

    if (recv == NULL)
    {
        return FALSE;
    }
    const UINT32 expRecvLen = sizeof(T_RfsFrameHead) + recv->frame.frameHead.dataLength;

    UARTprintf("expRecvLen = %d, recv dataLength = 0x%x\n", expRecvLen, recv->frame.frameHead.dataLength);


    recvBuf = (UINT8 *)&recv->frame;

    UARTprintf("s_uartRecvBuf.size = %d\n", s_uartRecvBuf.size);

    while ( (recv->recvdLen < expRecvLen) && (!QueueIsEmpty(&s_uartRecvBuf)) )
    {
        recvBuf[recv->recvdLen++] = QueuePop(&s_uartRecvBuf); /*这里将串口剩下来的数据存到recv->frame中*/
    }

    UARTprintf("recv->recvdLen = %d\n", recv->recvdLen);

    if(BspGetOokTestPrintFlag() == PRINT_FLAG_OPEN)
    {
        for (loop = 0; loop < recv->recvdLen; loop++)
        {
            if(loop % 8 == 0)
            {
                UARTprintf("\n");
            }
            UARTprintf("0x%02x  ", recvBuf[loop]);
        }
    }
    return (recv->recvdLen >= expRecvLen);
}

static BOOL IsRecvCrcCorrect(const T_RfsFrame *recvData)
{
    const UINT8 crcStartVal = 0xFF;
    const UINT8 *crcStartAddr = NULL;
    UINT32 crcLen = 0;
    UINT8 dataCrc = 0;
    UINT8 calCrc = 0;
    UINT8 loop = 0;

    if (recvData == NULL)
    {
        return FALSE;
    }

    crcStartAddr = (const UINT8 *)recvData->frameData;
    crcLen = recvData->frameHead.dataLength;
    dataCrc = recvData->frameHead.dataCrc;
    calCrc = CalculateCrc8(crcStartAddr, crcLen, crcStartVal);
    UARTprintf("dataCrc = 0x%x, calCrc = 0x%x\n", dataCrc, calCrc);
    if(dataCrc != calCrc)
    {
        for(loop = 0; loop < crcLen; loop++)
        {
            if(loop % 8 == 0)
            {
                UARTprintf("\n");
            }
            UARTprintf("%02x  ", recvData->frameData[loop]);
        }
    }
    return dataCrc == calCrc;
}

static UINT32 RecvMsgDrop(T_MsgReceive *recv)
{
    INPUT_POINTER_CHECK(recv);

    memset_s(recv, sizeof(T_MsgReceive), 0, sizeof(T_MsgReceive));
    recv->bufState = RECV_BUF_FREE;

    return COMMON_OK;
}

UINT32 BspSendMsgProc(T_MsgReceive *recv)
{
    T_RfsMsgHead *rfMsg = NULL;
    T_EachRfsMsg *reqRfMsg = NULL;
    UINT8 *msg = NULL;
    UINT8 msgType = 0;
    UINT8 serialNo = 0;
    UINT32 retVal = 0;
    UINT8 msgSubType = 0;

    INPUT_POINTER_CHECK(recv);
    msg = (UINT8 *)&recv->frame;
    rfMsg = (T_RfsMsgHead *)(msg + sizeof(T_RfsFrameHead));
    reqRfMsg = (T_EachRfsMsg* )(msg + sizeof(T_RfsFrameHead) + sizeof(T_RfsMsgHead));

    msgType = rfMsg->msgType;
    msgSubType = rfMsg->msgSubType;
    serialNo = rfMsg->serialNo;

    if (RFS_WFS_MSG_TYPE == msgType)
    {
        if (msgSubType < RFS_WFS_MSG_MAX)
        {
            if(s_wfsMsgSendInfo[msgSubType].pSendMsgProc != NULL)
            {
                s_wfsMsgSendInfo[msgSubType].pSendMsgProc(reqRfMsg, msgSubType,serialNo);
            }
        }
    }
    else
    {
        if (msgType < RFS_MSG_MAX)
        {
            if(s_msgSendInfo[msgType].pSendMsgProc != NULL)
            {
                s_msgSendInfo[msgType].pSendMsgProc(reqRfMsg, msgType,serialNo);
            }
        }
    }

    return retVal;
}

void BspHandleRevMsg() /*处理祯头消息，并存储接受到消息到s_msg中*/
{
    T_MsgReceive *recvd = GetRecvFrame();    /*一次中断，完成从串口获取的266个字节的数据处理？这里是否是要结构体数组？*/

    if(recvd == NULL)
    {
        return;
    }

    if (!DoesRecvHaveFrameStartFlag(recvd))
    {
        return ;
    }

    if (!DoesRecvMsgHeadDone(recvd))    /*完成这部s_uartRecvBuf头部数据就被剔除了*/
    {
        return ;
    }

    if (!IsMsgHeadValid(&recvd->frame.frameHead))    /*头部数据的CRC校验*/
    {
        s_headSumErrCnt++;
        RecvMsgDrop(recvd);    /*校验不过的数据丢弃*/
        return ;
    }

    if (!DoesRecvAllDataDone(recvd))
    {
        return ;
    }

    if (!IsRecvCrcCorrect(&recvd->frame))
    {
        s_crcErrCnt++;
        RecvMsgDrop(recvd);
        return ;
    }

    recvd->bufState = RECV_BUF_READY;

    BspSendMsgProc(recvd);
    RecvMsgDrop(recvd);
}


static void FrameDataCopy(UINT8 *dest, UINT32 destSize, const UINT8 *src, UINT32 srcSize)
{
    UINT32 copySize = min(destSize, srcSize);
    memcpy_s(dest, copySize, src, copySize);
}

BOOL HasReadyMsg()
{
    return s_msg.bufState == RECV_BUF_READY;
}

void GetReadyMsg(UINT8 *data, UINT32 dataSize)
{
    if (s_msg.bufState == RECV_BUF_READY)
    {
        memcpy_s(data, dataSize, s_msg.frame.frameData, s_msg.frame.frameHead.dataLength);
        RecvMsgDrop(&s_msg);
    }
}

UINT32 CreateFrame(UINT8 *datas, UINT32 dataSize, T_RfsFrame *frame)
{
    INPUT_POINTER_CHECK(datas);
    INPUT_POINTER_CHECK(frame);

    if (dataSize > sizeof(frame->frameData))
    {
        return COMMON_ERROR;
    }

    CreateFrameHead(&frame->frameHead, datas, dataSize);
    FrameDataCopy(frame->frameData, sizeof(frame->frameData), datas, dataSize);

    return COMMON_OK;
}

/**************************************************************************
 *                        方案二：空闲中断收，while 处理
 **************************************************************************/
VOID HandleOokCompleteEvent(VOID)
{
    memcpy_s(ookHandleData, dataNum, ookData, dataNum);
    memset_s(ookData, dataNum ,0, dataNum);
    OokRecvNum = dataNum;
    dataNum = 0;
    BspSetOokStatus(OOK_MSG_READY);
}

T_RfsFrame *BspGetOokData(VOID)
{
    return (T_RfsFrame *)ookHandleData;
}

void BspSaveRecOokData(UINT8 data)
{
    if(dataNum >= MAX_OOK_DATA_NUM)
    {
        dataNum = 0;
    }

    ookData[dataNum] = data;
    dataNum++;
}

static BOOL IsRecvOokCrcCorrect(T_RfsFrame *recvd)
{
    const UINT8 crcStartVal = 0xFF;
    const UINT8 *crcStartAddr = NULL;
    UINT32 crcLen = 0;
    UINT8 dataCrc = 0;
    UINT8 calCrc = 0;
    UINT16 loop = 0;
    UINT8 *data = NULL;

    if (recvd == NULL)
    {
        return FALSE;
    }

    data = (UINT8 *)recvd;
    crcStartAddr = (const UINT8 *)recvd->frameData;
    crcLen = ook_ntohs(recvd->frameHead.dataLength);
    dataCrc = recvd->frameHead.dataCrc;

    calCrc = CalculateCrc8(crcStartAddr, crcLen, crcStartVal);

    if(crcLen > MAX_OOK_DATA_NUM)
    {
        UARTprintf("!!!!!!!!!!!!!!!!err!!!!!!!!!!\n");
    }

    if(dataCrc != calCrc)
    {
        UARTprintf("ook crc err!\n");
        for(loop = 0; loop < sizeof(T_RfsFrame); loop++)
        {
            if(loop % 8 == 0)
            {
                UARTprintf("\n");
            }
            UARTprintf("%02x  ", *data);
            data++;
        }
    }

    return dataCrc == calCrc;

}

void BspHandleOokRevMsg()
{
    T_RfsFrame *recvd = BspGetOokData();

    if(recvd == NULL)
    {
        return;
    }

    if(!IsRecvOokCrcCorrect(recvd))
    {
        UARTprintf("rev ook msg crc err!\n");
        memset_s(ookHandleData, MAX_OOK_DATA_NUM, 0, MAX_OOK_DATA_NUM);
        OokRecvNum = 0;
        return;
    }

    BspSendMsgOokProc(recvd);
    memset_s(ookHandleData, MAX_OOK_DATA_NUM, 0, MAX_OOK_DATA_NUM);
    OokRecvNum = 0;
}

/**************************************************************************
 *                        消息处理函数接口
 **************************************************************************/
UINT32 g_fpgaLenth = 0;
UINT32 g_mcuLenth = 0;
VOID BspSetFpgaLenth(UINT32 lenth)
{
    g_fpgaLenth = lenth;
}

UINT32 BspGetFpgaLenth()
{
    return g_fpgaLenth;
}

VOID BspSetMcuLenth(UINT32 lenth)
{
    g_mcuLenth = lenth;
}

UINT32 BspGetMcuLenth()
{
    return g_mcuLenth;
}

static void CreateFrameHead(T_RfsFrameHead *head, UINT8 *datas, UINT16 dataSize)
{
    const UINT8 frameStartFlag1 = 0x7E;
    const UINT8 frameStartFlag2 = 0xEF;

    if ((head == NULL) || (datas == NULL))
    {
        return ;
    }

    head->startFlag1 = frameStartFlag1;
    head->startFlag2 = frameStartFlag2;
    head->version = 1;
    head->reserved1 = 0;
    head->reserved2 = 0;
    head->dataLength = ook_htons(dataSize);
    head->dataCrc = CalculateCrc(datas, dataSize);
    head->headSum = CalculateCheckSum(head);
}

VOID SendOokMsg(VOID *send, UINT16 dataLength)
{
    BYTE sendData[MAX_OOK_DATA_NUM] = {0,};   /*一包数据最大256字节*/

    if(send == NULL)
    {
        return;
    }

    memcpy_s(sendData, dataLength, send, dataLength);
    HalUartSendBuffer(UART3, &sendData[0], dataLength);
}

static VOID FillRfMsgHead(T_RfsMsg *rfsMsg, UINT8 msgType, UINT8 msgInfoLenth, UINT8 serialNo)
{
    rfsMsg->head.msgType = msgType;
    rfsMsg->head.msgSubType = BspGetMsgSubType();
    rfsMsg->head.serialNo = serialNo;      /*母端传来的数字，原数带回*/
    rfsMsg->head.msgInfoLength = msgInfoLenth;
    rfsMsg->head.reserve[0] = 0;
    rfsMsg->head.reserve[1] = 0;
    rfsMsg->head.reserve[2] = 0;
    rfsMsg->head.reserve[3] = 0;
}

VOID BspSendHeartBeatAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    OOK_LINK_CHECK(msgType, serialNo);

    BspSendOokAck(msgType, RFS_MSG_ACK_OK, serialNo);
}

VOID BspSendOokAck(UINT8 msgType, UINT8 msgAckResult, UINT8 serialNo)
{
    UINT16 lenth = 0;
    T_MsgSend *ookSend = GetSendFrame();

    INPUT_POINTER_CHECK_RETURN(ookSend);
    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));
    ookSend->rfsMsg.msgInfo.ack.ackData = msgAckResult;

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsCommAck), serialNo);
    lenth = sizeof(T_RfsCommAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth );   //将填充好的信息发送，并且传回相应消息
}

VOID BspBuildLinkAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT32 fpgaLenth = 0;
    UINT32 mcuLenth = 0;
    UINT8 rfsBrdType[32] = "R9124S S26";       /*类型还不知怎么获取，先随便写一个*/
    UINT8 lenth = 0;
    CHAR softVer[VER_LENTH] = {0,};
    CHAR fpgaVer[VER_LENTH] = {0,};
    T_MsgSend *ookSend = GetSendFrame();
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

#if !defined _BSP_MCU_WFS
    if(BspGetLinkStatus() == OOK_LINK_SUCCESS)
    {
        /*已经建联成功的情况下，再次收到建联请求，子端进行复位*/
        UARTprintf("already established!,reboot MCU!\n");
        if(pFuncPara->pCloseAllSwitch != NULL)
        {
            pFuncPara->pCloseAllSwitch();
        }
        NVIC_SystemReset();
    }
#endif
    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    if(pFuncPara->pLedCtrl != NULL)
    {
        pFuncPara->pLedCtrl(LED_RUN_CTRL, LED_CTRL_TYPE_FLICKER, 300);
    }

    if(pFuncPara->pGetFpgaVer != NULL)
    {
        pFuncPara->pGetFpgaVer(fpgaVer);
    }

    if(pFuncPara->pGetSoftVer != NULL)
    {
        pFuncPara->pGetSoftVer(softVer);
    }

    s_randCode = ook_ntohl(reqRfMsg->linkReq.randCode);
    fpgaLenth = ook_ntohl(reqRfMsg->linkReq.fpgaLenth);
    mcuLenth = ook_ntohl(reqRfMsg->linkReq.mcuLenth);
    BspSetFpgaLenth(fpgaLenth);
    BspSetMcuLenth(mcuLenth);

    ookSend->rfsMsg.msgInfo.linkReqAck.moduleGroupId = ook_htonl(BspGetModuleGroupId());
    ookSend->rfsMsg.msgInfo.linkReqAck.boardGroupId = ook_htonl(BspGetBoardGroupId());
    ookSend->rfsMsg.msgInfo.linkReqAck.boardTypeId = ook_htonl(BspGetBoardTypeId());
    ookSend->rfsMsg.msgInfo.linkReqAck.hwChangeId = ook_htonl(BspGetHardwareChangeId());

    memcpy_s(ookSend->rfsMsg.msgInfo.linkReqAck.rfsBrdType, sizeof(ookSend->rfsMsg.msgInfo.linkReqAck.rfsBrdType), rfsBrdType, sizeof(rfsBrdType));
    memcpy_s(ookSend->rfsMsg.msgInfo.linkReqAck.cpuVer, sizeof(ookSend->rfsMsg.msgInfo.linkReqAck.cpuVer), softVer, sizeof(softVer));
    memcpy_s(ookSend->rfsMsg.msgInfo.linkReqAck.fpgaVer, sizeof(ookSend->rfsMsg.msgInfo.linkReqAck.fpgaVer), fpgaVer, sizeof(fpgaVer));

    ookSend->rfsMsg.msgInfo.linkReqAck.cpuUpgradeFlag = (UINT8)GetUpgradeFlag();
    ookSend->rfsMsg.msgInfo.linkReqAck.fpgaUpgradeFlag = (UINT8)GetUpgradeFlag();
    ookSend->rfsMsg.msgInfo.linkReqAck.rfChanNum = RF_CHAN_NUM;
    ookSend->rfsMsg.msgInfo.linkReqAck.fpgaDevType = 0;         /*这里要网络字节序*/
    ookSend->rfsMsg.msgInfo.linkReqAck.rfTblSize = ook_htonl(0x12345);
    ookSend->rfsMsg.msgInfo.linkReqAck.rfTblCrc32 = ook_htonl(0x12345);
    ookSend->rfsMsg.msgInfo.linkReqAck.ackData = RFS_MSG_ACK_OK;

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsLinkReqAck), serialNo);
    lenth = sizeof(T_RfsLinkReqAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);

    BspSetLinkStatus(OOK_LINK_SUCCESS);
    UARTprintf("ooksend fill finished, link success!\n");
}

VOID BspRfCtrlProc(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    T_OOK_ACTION_FUNC *pFuncPara = NULL;
    UINT8 chan = 0;
    UINT8 switchType = 0;
    UINT8 sw = 0;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    switchType = reqRfMsg->rfSwitchCtrl.switchType;
    sw = reqRfMsg->rfSwitchCtrl.onOffType;
    chan = reqRfMsg->rfSwitchCtrl.chan;

    if (pFuncPara->pSwitchCtrl != NULL)
    {
        pFuncPara->pSwitchCtrl(chan, switchType, sw, 0);
    }

    BspSendOokAck(msgType, RFS_MSG_ACK_OK, serialNo);

}

VOID BspLedCtrlAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    UINT32 ledType = 0;
    UINT32 ctrlType = 0;
    UINT32 onTimeMs = 0;
    UINT32 offTimeMs = 0;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);
    ledType = reqRfMsg->ledCtrl.ledType;
    ctrlType = reqRfMsg->ledCtrl.ctrlType;
    onTimeMs = ook_ntohs(reqRfMsg->ledCtrl.onTimeMs);
    offTimeMs = ook_ntohs(reqRfMsg->ledCtrl.offTimeMs);
    UARTprintf("ledType = %d, ctrlType = %d, onTimeMs = %d, offTimeMs = %d\n", ledType, ctrlType, onTimeMs,offTimeMs);

    if (pFuncPara->pLedCtrl != NULL)
    {
        pFuncPara->pLedCtrl(ledType, ctrlType, onTimeMs);
    }

    BspSendOokAck(msgType, msgAckResult, serialNo);

}

VOID BspGridVoltCtrl(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    T_MsgSend *ookSend = GetSendFrame();
    UINT8 chipIndex = 0;
    UINT8 innerChan = 0;
    UINT16 lenth = 0;
    INT16 voltMv = 0;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);
    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    chipIndex = reqRfMsg->rfDacCtrl.dacChipIdx;
    innerChan = reqRfMsg->rfDacCtrl.innerChan;
    voltMv = ook_ntohs(reqRfMsg->rfDacCtrl.voltmV);

    UARTprintf("ook set grid volt = %dmv\n", voltMv);
    zxDRV_Amc7836SetPaGridDac(chipIndex, innerChan, voltMv);
    ookSend->rfsMsg.msgInfo.ack.ackData = RFS_MSG_ACK_OK;

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsCommAck), serialNo);
    lenth = sizeof(T_RfsCommAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);
    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);
}

static BOOLEAN IsFileFisrtWrite(T_ModuleInfoHead *pHeadInfo, UINT32 index, UINT8 fileType)
{
    if(pHeadInfo == NULL)
    {
        return FALSE;
    }

    if((pHeadInfo->tParaInfo[index+1].ulFileLenth == 0) || (pHeadInfo->tParaInfo[index+1].ulFileLenth == INVALID_STATUS))
    {
        return TRUE;
    }

    return FALSE;
}

UINT32 BspGetOffLineInfoIndex(T_ModuleInfoHead *pHeadInfo, UINT8 fileType)
{
    UINT32 loop = 0;
    UINT32 index = 0;

    INPUT_POINTER_CHECK(pHeadInfo);
    for(loop = 0; loop < EEPROM_FILE_TYPE_MAX; loop++)
    {
        if(fileType == pHeadInfo->tParaInfo[loop].fileType)
        {
            index = loop;
            break;
        }

        /*文件第一次写入判断*/
        if((pHeadInfo->tParaInfo[loop].ulFileLenth != 0) && (pHeadInfo->tParaInfo[loop].ulFileLenth != INVALID_STATUS))
        {
            if(IsFileFisrtWrite(pHeadInfo, loop, fileType))
            {
                index = loop + 1;
                break;
            }
        }
    }

    if(loop >= EEPROM_FILE_TYPE_MAX)
    {
        UARTprintf("eeprom has no file!\n");
        index = COMMON_ERROR;
    }

    UARTprintf("BspGetOffLineInfoIndex >>> index = %d\n", index);
    return index;
}

VOID BspOffLineParaUpAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    T_MsgSend *ookSend = GetSendFrame();
    UINT32 crc32Data = 0;
    UINT32 fileSize = 0;
    UINT32 index = 0;
    UINT32 revCrc = 0;
    UINT16 lenth = 0;
    UINT8 fileType = 0;
    T_ModuleInfoHead *pHeadInfo = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));
    pHeadInfo = BspGetModuleInfoHead();
    OOK_INPUT_POINTER_CHECK(pHeadInfo, msgType, serialNo);

    fileType = reqRfMsg->rfTblUpLoadReq.fileType;
    index = BspGetOffLineInfoIndex(pHeadInfo, fileType);
    OOK_PARA_TBL_INDEX_CHECK(index, msgType, serialNo);
    crc32Data = pHeadInfo->tParaInfo[index].ulCrc32;
    fileSize = pHeadInfo->tParaInfo[index].ulFileLenth;
    revCrc = ook_ntohl(reqRfMsg->rfTblUpLoadReq.crc32);
    UARTprintf("fileType = %d, fileSize = 0x%x, crc32Data = 0x%x\n",fileType, fileSize, crc32Data);

    if(revCrc == crc32Data)
    {
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.compareResult = NO_NEED_UPGRADE;
    }
    else
    {
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.compareResult = NEED_UPGRADE;
    }

    if((INVALID_STATUS == fileSize) || (INVALID_STATUS == crc32Data))
    {
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.fileSize = ook_htonl(0);
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.fielCrc32 = ook_htonl(0);
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.ackInfo = RFS_MSG_ACK_ERROR;
    }
    else
    {
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.fileSize = ook_htonl(fileSize);
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.fielCrc32 = ook_htonl(crc32Data);
        ookSend->rfsMsg.msgInfo.rfTblUpLoadAck.ackInfo = RFS_MSG_ACK_OK;
    }

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfTblUpLoadAck), serialNo);
    lenth = sizeof(T_RfTblUpLoadAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspOffLineParaDownAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 lenth = 0;
    UINT8 fileType = 0;
    UINT8 pageLeft = 0;
    UINT8 wfsFlag = 0;
    UINT32 DownLoadFileSize = 0;
    UINT32 DownLoadCrc32 = 0;
    UINT32 localCrc32 = 0;
    UINT32 localFileSize = 0;
    UINT32 offSet = 0;
    UINT32 pageNum = 0;
    UINT32 startAddr = 0;
    UINT32 index = 0;
    UINT32 tmpIndex = 0;
    T_ModuleInfoHead *pHeadInfo = NULL;
    T_MsgSend *ookSend = GetSendFrame();

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));
    DownLoadFileSize = ook_ntohl(reqRfMsg->rfTblDownLoadReq.fileSize);
    DownLoadCrc32 = ook_ntohl(reqRfMsg->rfTblDownLoadReq.crc32);
    fileType = reqRfMsg->rfTblDownLoadReq.fileType;

    pHeadInfo = BspGetModuleInfoHead();
    OOK_INPUT_POINTER_CHECK(pHeadInfo, msgType, serialNo);

    //找到该文件在数组中的位置
    index = BspGetOffLineInfoIndex(pHeadInfo, fileType);
    if(index == COMMON_ERROR)
    {
        index = 0;
    }

    localFileSize = pHeadInfo->tParaInfo[index].ulFileLenth;
    localCrc32 = pHeadInfo->tParaInfo[index].ulCrc32;

    UARTprintf("localFileSize = %d, localCrc32 = 0x%x\n", localFileSize, localCrc32);
    UARTprintf("From Dpdic filesize = %d, crc32 = 0x%x fileType = %d\n", DownLoadFileSize, DownLoadCrc32, fileType);

    wfsFlag = BspGetWfsFlag();   /* 工装下载取消对比，解决文件写到一半发生异常后，再次写入无法触发的问题 */
    if((localFileSize == DownLoadFileSize) && (localCrc32 == DownLoadCrc32) && (wfsFlag != WFS_VERSION_FLAG))
    {
        ookSend->rfsMsg.msgInfo.rfTblDownLoadAck.compareResult = NO_NEED_UPGRADE;
    }
    else
    {
        //更新flash备份数据
        BspUpdataFlashRftblInfo(fileType, DownLoadCrc32, DownLoadFileSize);
        ookSend->rfsMsg.msgInfo.rfTblDownLoadAck.compareResult = NEED_UPGRADE;
        if((localCrc32 == INVALID_STATUS) || (localCrc32 == 0))       /*系统中没有这个文件 */
        {
            UARTprintf("init file head info\n");
            if(index == 0)
            {
                offSet = RF_TBL_DATA_START_ADDR;
            }
            else
            {
                tmpIndex = index - 1;
                offSet = pHeadInfo->tParaInfo[tmpIndex].ulOffset;                   /*上一个文件的起始地址*/
                pageLeft = (pHeadInfo->tParaInfo[tmpIndex].ulFileLenth % 256);
                pageNum = (pHeadInfo->tParaInfo[tmpIndex].ulFileLenth / 256);
                if(pageLeft == 0)
                {
                    offSet += pHeadInfo->tParaInfo[tmpIndex].ulFileLenth;
                }
                else
                {
                    offSet += (pageNum + 1) * 256;
                }
            }

            startAddr = offSet;
            UARTprintf("startAddr = 0x%x\n", startAddr);
            BspSetOffLineHeadInfo(index, fileType, DownLoadFileSize, DownLoadCrc32, startAddr); /*更新ee的信息和全局变量*/
        }
        else
        {
            BspUpGradeOffLineHeadInfo(index, DownLoadFileSize, DownLoadCrc32);
        }
    }

    ookSend->rfsMsg.msgInfo.rfTblDownLoadAck.ackResult = RFS_MSG_ACK_OK;
    ookSend->rfsMsg.msgInfo.rfTblDownLoadAck.fileSize = ook_htonl(localFileSize);  /*这里要转成网络字节序*/
    ookSend->rfsMsg.msgInfo.rfTblDownLoadAck.crc32 = ook_htonl(localCrc32);     /*这里要转成网络字节序*/

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfTblDownLoadAck), serialNo);
    lenth = sizeof(T_RfTblDownLoadAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);
    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend ,lenth);
}

/*****************************************************************************
 *  函数名称   : FillRfTblData(*)
 *  功能描述   : 填充离线参数表数据包
 *  输入参数   : 数据的结构体指针
 *  输出参数   : 无
 *  返 回 值   : 无
 *----------------------------------------------------------------------------
 */
static VOID BspReadRfTblData(UINT32 addr, UINT8 dataSize, UINT8 *data)
{
    BspReadEepromData(addr, dataSize, data);
}

VOID FillRfTblData(T_RfTblUpLoadDataAck *rfTblUpLoadDataAck, UINT32 dataOffset, UINT8 dataSize)
{

    BspReadRfTblData(dataOffset, dataSize, rfTblUpLoadDataAck->data);

    rfTblUpLoadDataAck->ackInfo = RFS_MSG_ACK_OK;
    rfTblUpLoadDataAck->dataSize = dataSize;
    rfTblUpLoadDataAck->dataOffset = ook_htonl(dataOffset);

}

VOID BspOffLineParaUpLoad(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    T_MsgSend *ookSend = GetSendFrame();
    UINT32 lenth = 0;
    UINT32 dataOffset = 0;
    UINT32 baseAddr = 0;
    UINT32 rdAddr = 0;
    UINT32 index = 0;
    UINT8 dataSize = 0;
    UINT8 fileType = 0;
    T_ModuleInfoHead *pHeadInfo = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    fileType = reqRfMsg->rfTblUpLoadData.fileType;
    dataOffset = ook_ntohl(reqRfMsg->rfTblUpLoadData.dataOffset);
    dataSize = reqRfMsg->rfTblUpLoadData.dataSize;

    pHeadInfo = BspGetModuleInfoHead();
    OOK_INPUT_POINTER_CHECK(pHeadInfo, msgType, serialNo);

    UARTprintf("BspOffLineParaUpLoad fileType = %d\n", fileType);
    index = BspGetOffLineInfoIndex(pHeadInfo, fileType);
    PARA_TBL_INDEX_CHECK_RETURN(index);
    baseAddr = pHeadInfo->tParaInfo[index].ulOffset;
    rdAddr = baseAddr + dataOffset;
    UARTprintf("baseAddr = 0x%x, rdAddr = 0x%x\n", baseAddr, rdAddr);
    /*填充数据*/
    FillRfTblData(&ookSend->rfsMsg.msgInfo.rfTblUpLoadDataAck, rdAddr, dataSize);

    /*填充消息头*/
    lenth = sizeof(T_RfTblUpLoadDataAck);   /*每包长度，都按照240字节*/
    FillRfMsgHead(&ookSend->rfsMsg, msgType, lenth, serialNo);

    lenth += sizeof(T_RfsMsgHead);
    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);
    SendOokMsg((VOID *)ookSend , lenth );   //将填充好的信息发送，并且传回相应消息
}

VOID BspOffLineParaDownLoad(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 dataSize = 0;
    UINT8 *pData = NULL;
    UINT8 lenth = 0;
    UINT8 fileType = 0;
    UINT32 dataOffset = 0;
    UINT32 wrAddr = 0;
    UINT32 index = 0;
    static UINT32 crcInitValue = 0;
    static UINT32 fileSize = 0;
    T_ModuleInfoHead *pHeadInfo = NULL;
    T_MsgSend *ookSend = GetSendFrame();

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    dataOffset = ook_ntohl(reqRfMsg->rfTblDownLoadProc.dataOffset);
    dataSize = reqRfMsg->rfTblDownLoadProc.dataSize;
    pData = reqRfMsg->rfTblDownLoadProc.data;
    fileType = reqRfMsg->rfTblDownLoadProc.fileType;

    pHeadInfo = BspGetModuleInfoHead();
    OOK_INPUT_POINTER_CHECK(pHeadInfo, msgType, serialNo);

    index = BspGetOffLineInfoIndex(pHeadInfo, fileType);
    PARA_TBL_INDEX_CHECK_RETURN(index);
    wrAddr = pHeadInfo->tParaInfo[index].ulOffset + dataOffset;

    /*2.将收到的数据写入eeprom中*/
    UARTprintf("eeprom dataSize = %d, dataOffset = 0x%x, wrAddr = 0x%x\n", dataSize, dataOffset, wrAddr);
    BspWriteEepromData(wrAddr, dataSize, pData);

    ookSend->rfsMsg.msgInfo.rfTblDownLoadProcAck.ackData = RFS_MSG_ACK_OK;
    crcInitValue = CalculateCrc32(crcInitValue, pData, dataSize);
    ookSend->rfsMsg.msgInfo.rfTblDownLoadProcAck.crc32 = ook_htonl(crcInitValue);

    fileSize += dataSize;
    ookSend->rfsMsg.msgInfo.rfTblDownLoadProcAck.fileSize = ook_htonl(fileSize);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfTblDownLoadAck), serialNo);

    lenth = sizeof(T_RfTblDownLoadAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth );

}

VOID BspTestCmdAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    T_MsgSend *ookSend = GetSendFrame();
    UINT8 ookPrintSize = 0;
    UINT8 *ookPrintData = NULL;
    INT32 ret = 0;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    BspSetOokPrintSw(1);
    ret = CmdLineProcess((char *)reqRfMsg->testCmdReq.cmdBuff);  /*现在执行函数*/
    UARTprintf("test func ok!\n"); /* 无打印的维测接口数据长度问题导致母端不接收，先增加一行打印，后续优化 */
    if(ret != COMMON_OK)
    {
        ookSend->rfsMsg.msgInfo.testCmdAck.result = RFS_MSG_ACK_ERROR;
        UARTprintf("Fun Executed Err!\n");
    }
    else
    {
        ookSend->rfsMsg.msgInfo.testCmdAck.result = RFS_MSG_ACK_OK;
    }
    BspSetOokPrintSw(0);

    ookPrintSize = BspGetOokPrintSize();
    if(ookPrintSize > 238)
    {
        UARTprintf("print data size[%d] over!\n", ookPrintSize);
        ookPrintSize = 238;
    }

    ookPrintData = BspGetOokPrintData();
    memcpy_s(ookSend->rfsMsg.msgInfo.testCmdAck.printBuff, ookPrintSize, (void *)ookPrintData, ookPrintSize);//执行完成后，需要把函数执行的打印拷贝到消息中，发送出去

    FillRfMsgHead(&ookSend->rfsMsg, msgType, ookPrintSize, serialNo);
    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, sizeof(T_RfTestCommandAck) + sizeof(T_RfsMsgHead));
    SendOokMsg((VOID *)ookSend ,sizeof(T_RfTestCommandAck) + sizeof(T_RfsMsgHead) + sizeof(T_RfsFrameHead));

    BspSetOokPrintSize(0);//g_ookPrintSize = 0;
    memset_s(ookPrintData, 238, 0, 238);
}

VOID BspVersionCompareInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT32 cpuCrc32 = 0;
    UINT8 cpuCmpResult = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    UINT32 fpgaCrc32 = 0;
    UINT8 fpgaCmpResult = 0;
    UINT8 cpuVer[44] = {0};
    UINT8 fpgaVer[44] = {0};
    T_OOK_ACTION_FUNC *pFuncPara = NULL;
    /* 根据版本比对结果处理 */

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    UARTprintf("Version Compare[%d] get success!\n", msgType);
    BspMoveRevertDataToUpArea();
    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);
    cpuCrc32 = ook_ntohl(reqRfMsg->verInfoCfg.cpuCrc32);
    cpuCmpResult = reqRfMsg->verInfoCfg.cpuCmpResult;
    fpgaCmpResult = reqRfMsg->verInfoCfg.fpgaCmpResult;
    fpgaCrc32 = ook_ntohl(reqRfMsg->verInfoCfg.fpgaCrc32);

    if((cpuCmpResult == 1) && (pFuncPara->pVerClrSector != NULL))
    {
        pFuncPara->pVerClrSector(0);
    }

    if((fpgaCmpResult == 1) && (pFuncPara->pVerClrSector != NULL))
    {
        pFuncPara->pVerClrSector(1);
    }
    memcpy_s(cpuVer, 44, reqRfMsg->verInfoCfg.cpuVer, 44);
    memcpy_s(fpgaVer, 44, reqRfMsg->verInfoCfg.fpgaVer, 44);

    UARTprintf("cpuCrc32 = %d, cpuCmpResult = %d, fpgaCrc32 = %d, fpgaCmpResult = %d\n", cpuCrc32, cpuCmpResult, fpgaCrc32, fpgaCmpResult);
    UARTprintf("cpuVer = %s, fpgaVer = %s\n", cpuVer, fpgaVer);

    /* 响应消息 */
    BspSendOokAck(msgType, msgAckResult, serialNo);
}

VOID BspVersionDownLoadAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 verType = 0;
    UINT32 dataOffset = 0;
    UINT8 dataSize = 0;
    UINT8 lenth = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    UINT32 crc = 0;
    UINT32 fileSize = 0;
    T_MsgSend *ookSend = GetSendFrame();
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    UARTprintf("Version DownLoad msgtype 12 get fun success!\n");
    verType = reqRfMsg->verDownLoad.verType;
    dataOffset = ook_ntohl(reqRfMsg->verDownLoad.dataOffset);
    dataSize = reqRfMsg->verDownLoad.dataSize;

    /* 版本下载到flash*/
    if (pFuncPara->pVerDownLoad != NULL)
    {
        if(COMMON_OK != pFuncPara->pVerDownLoad(verType, dataOffset, reqRfMsg->verDownLoad.data, dataSize))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    ookSend->rfsMsg.msgInfo.verDownLoadAck.ackData = msgAckResult;
    ookSend->rfsMsg.msgInfo.verDownLoadAck.fileSize = ook_htonl(fileSize);
    ookSend->rfsMsg.msgInfo.verDownLoadAck.crc32 = ook_htonl(crc);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsVerDownloadAck), serialNo);
    lenth = sizeof(T_RfsVerDownloadAck) + sizeof(T_RfsMsgHead);
    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);
    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspVersionActionAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 cpuVerActFlag = 0;
    UINT8 fpgaVerActFlag = 0;
    UINT8 secBootVerActFlag = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    UINT32 mcuLenth = BspGetMcuLenth();
    UINT32 fileCrc = BspGetMcuVerCrc();
    UINT32 ret = 0;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);
    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);
    /* 记录激活信息 */
    cpuVerActFlag = reqRfMsg->verAction.cpuVerActFlag;
    fpgaVerActFlag = reqRfMsg->verAction.fpgaVerActFlag;
    secBootVerActFlag = reqRfMsg->verAction.secBootVerActFlag;
    UARTprintf("cpuVerActFlag = %d, fpgaVerActFlag = %d, secBootVerActFlag = %d\n", cpuVerActFlag, fpgaVerActFlag, secBootVerActFlag);
    UARTprintf("mcuLenth = %d, fileCrc = 0x%x\n", mcuLenth, fileCrc);

    if (fpgaVerActFlag == 1)
    {
        LoadPangoEpldVer(); /* 启动EPLD版本加载 */
    }

    if (cpuVerActFlag == 1)
    {
        UARTprintf("begin check crc!\n");
        ret = pFuncPara->pCheckMcuVerData(fileCrc, mcuLenth);       /*激活之前先做对升级区数据校验*/
        if(ret == COMMON_OK)
        {
            UARTprintf("check success!\n");
            pFuncPara->pUpdataVerInfo(APP_UP_SECTOR, mcuLenth, fileCrc);
        }
        else
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
            BspSendOokAck(msgType, msgAckResult, serialNo);
            return;
        }
    }

    if (secBootVerActFlag == VER_UPDATA_ACTION_STATUS)
    {
        if(COMMON_OK == pFuncPara->pCheckSndBootRunVerCrc())
        {
            SetSecondBootRunStatus(E_FW_RUN_NORMAL);
            if(pFuncPara->pCloseAllSwitch != NULL)
            {
                pFuncPara->pCloseAllSwitch();
            }
            NVIC_SystemReset();
        }
        else
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }
    BspSendOokAck(msgType, msgAckResult, serialNo);     /* 先响应消息，cpu激活需要复位 */
    if((cpuVerActFlag == 1) || (fpgaVerActFlag == 1))
    {
        if(pFuncPara->pCloseAllSwitch != NULL)
        {
            pFuncPara->pCloseAllSwitch();
        }
        NVIC_SystemReset();
    }
}

VOID BspTimeDelayMeasuerAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 action = 0;
    UINT32 dlyNs = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;

    OOK_LINK_CHECK(msgType, serialNo);
    /* 记录信息 */
    action = reqRfMsg->dlyMeasure.action;
    dlyNs = ook_ntohl(reqRfMsg->dlyMeasure.dlyNs);
    UARTprintf("action = %d, dlyNs = %d\n", action, dlyNs);

    if (action == 1)
    {
        /* 开始 */
    }
    else if (action == 0)
    {
        /* 结束 */
    }

    /* 要做啥，只是上报消息OK吗？ */

    /* 响应消息 */
    BspSendOokAck(msgType, msgAckResult, serialNo);
}

VOID BspBoardResetCtrlAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 rstType = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;
    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);
    /* 记录激活信息 */
    rstType = reqRfMsg->resetCtrl.rstType;
    UARTprintf("rstType = %d\n", rstType);
    /* 先响应消息再复位 */
    BspSendOokAck(msgType, msgAckResult, serialNo);
    /* 复位 */
    if(pFuncPara->pCloseAllSwitch != NULL)
    {
        pFuncPara->pCloseAllSwitch();
    }
    NVIC_SystemReset();
}

UINT8 ChecktddCtrlCfg(T_RfsTddCfg *pTddCtrlCfg)
{
    const UINT8 dlUlSwNumMaxVal = 2;
    const UINT8 dlUlSwNumMinVal = 1;

    if (pTddCtrlCfg == NULL)
    {
        return RFS_MSG_ACK_CHECK_ERROR;
    }
    if (pTddCtrlCfg->radioMode >= RADIO_STANDARD_MAX_FLAG)
    {
        return RFS_MSG_ACK_CHECK_ERROR;
    }
    if ((pTddCtrlCfg->dlUlSwNum < dlUlSwNumMinVal) || (pTddCtrlCfg->dlUlSwNum > dlUlSwNumMaxVal))
    {
        return RFS_MSG_ACK_CHECK_ERROR;
    }

    return RFS_MSG_ACK_OK;
}

VOID BspTddCtrlCfgAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    T_RfsTddCfg tddCtrlCfg = {0};
    UINT32 loop = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;
    const UINT32 periodMaxNum = 4;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    UARTprintf("test msgtype 16 get fun success!\n");
    tddCtrlCfg.radioMode = reqRfMsg->tddCfg.radioMode;
    tddCtrlCfg.lteSubFrame = reqRfMsg->tddCfg.lteSubFrame;          /*LTE子帧配比编号 0-6*/
    tddCtrlCfg.lteSpeSubFrame = reqRfMsg->tddCfg.lteSpeSubFrame;    /*LTE特殊子帧配比编号 0-9*/
    tddCtrlCfg.nrUeAdv = reqRfMsg->tddCfg.nrUeAdv;                  /*NR上行提前量*/
    tddCtrlCfg.dlUlSwNum = reqRfMsg->tddCfg.dlUlSwNum;              /*1-单周期，2-双周期*/
    UARTprintf("radioMode = %d, lteSubFrame = %d, lteSpeSubFrame = %d, nrUeAdv = %d, dlUlSwNum = %d\n", 
                tddCtrlCfg.radioMode, tddCtrlCfg.lteSubFrame, tddCtrlCfg.lteSpeSubFrame, tddCtrlCfg.nrUeAdv, tddCtrlCfg.dlUlSwNum);
    msgAckResult = ChecktddCtrlCfg(&tddCtrlCfg);
    if (msgAckResult != RFS_MSG_ACK_OK)
    {
        BspSendOokAck(msgType, msgAckResult, serialNo);
        return;
    }

    for (loop = 0; loop < periodMaxNum; loop++)
    {
        tddCtrlCfg.dlUlSwPeriod[loop] = ook_ntohl(reqRfMsg->tddCfg.dlUlSwPeriod[loop]);
        tddCtrlCfg.dlSymbolNum[loop] = reqRfMsg->tddCfg.dlSymbolNum[loop];
        tddCtrlCfg.ulSymbolNum[loop] = reqRfMsg->tddCfg.ulSymbolNum[loop];
    }

    if (pFuncPara->pTddCtrl != NULL)
    {
        if(COMMON_OK != pFuncPara->pTddCtrl(&tddCtrlCfg))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    BspSendOokAck(msgType, msgAckResult, serialNo);
}

VOID BspBeamwidthCfgAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 beamwidth = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    UARTprintf("test msgtype 17 get fun success!\n");
    /* 记录激活信息 */
    beamwidth = reqRfMsg->beamwidthCfg.beamwidth;
    if (pFuncPara->pSetBeamwidthCfg != NULL)
    {
        if(COMMON_OK != pFuncPara->pSetBeamwidthCfg(beamwidth))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    UARTprintf("beamwidth = %d\n", beamwidth);

    /* 响应消息 */
    BspSendOokAck(msgType, msgAckResult, serialNo);
}

VOID BspSetPaVoltAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT16 goalVolt = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    UINT32 ret= 0;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);
    UARTprintf("msgtype 18 get!\n");
    /* 记录激活信息 */
    goalVolt = ook_ntohs(reqRfMsg->paVoltCtrl.volt);
    if((goalVolt < PA_VOLT_MIN_VAL) || (goalVolt > PA_VOLT_MAX_VAL))
    {
        UARTprintf("volt value invalid!\n");
        BspSendOokAck(msgType, RFS_MSG_ACK_ERROR, serialNo);
        return;
    }

    ret = BspSetPaVoltByStep(0, goalVolt);
    if(ret == COMMON_ERROR)
    {
        BspSendOokAck(msgType, RFS_MSG_ACK_ERROR, serialNo);
        return;
    }

    /* 响应消息 */
    BspSendOokAck(msgType, msgAckResult, serialNo);
    return;
}

VOID BspGetTeapAndVoltInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    INT16 boardTemp = 500;
    INT16 paTemp[2] = {500, 500}; /* 温度目前获取不到，先按照50度上报 */
    INT32 tmpTemp = 500;
    INT16 pwrTemp = 500;
    UINT32 pwrVout = 0;
    UINT32 lenth = 0;
    T_MsgSend *ookSend = GetSendFrame();
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    BspDh250VoutGet(0, (INT32 *)&pwrVout);
    BspDh250GetTemp(0, &pwrTemp);
    BspGetAmc7836Temp(0, 0, &tmpTemp);   /*AMC7836只支持一个通道温度检测*/
    paTemp[0] = (INT16)tmpTemp;
    BspGetAmc7836Temp(0, 0, &tmpTemp);
    paTemp[1] = (INT16)tmpTemp;

    boardTemp = paTemp[0];    /*todo: 前期板子上没有tmp451芯片，先暂时用DAC温度代替单板温度*/
    ookSend->rfsMsg.msgInfo.teamAndVoltInfo.ackData = msgAckResult;
    ookSend->rfsMsg.msgInfo.teamAndVoltInfo.pwrTemp = ook_htons(pwrTemp);
    ookSend->rfsMsg.msgInfo.teamAndVoltInfo.pwrVout = ook_htonl(pwrVout);
    ookSend->rfsMsg.msgInfo.teamAndVoltInfo.boardTemp = ook_htons(boardTemp);
    ookSend->rfsMsg.msgInfo.teamAndVoltInfo.paTemp[0] = ook_htons(paTemp[0]);
    ookSend->rfsMsg.msgInfo.teamAndVoltInfo.paTemp[1] = ook_htons(paTemp[1]);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsTempVoltInfo), serialNo);
    lenth = sizeof(T_RfsTempVoltInfo) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspGetAlmInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT32 almState = 0;
    UINT32 almEvent = 0;
    UINT32 lenth = 0;
    T_MsgSend *ookSend = GetSendFrame();
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    if (pFuncPara->pGetAllAlmStatus != NULL)
    {
        if(COMMON_OK != pFuncPara->pGetAllAlmStatus(&almState, &almEvent))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    ookSend->rfsMsg.msgInfo.almInfo.ackData = msgAckResult;
    ookSend->rfsMsg.msgInfo.almInfo.almState = ook_htonl(almState); /* 先按照无告警上报，告警接口后续开发 */
    ookSend->rfsMsg.msgInfo.almInfo.almEvent = ook_htonl(almEvent);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsAlmInfo), serialNo);
    lenth = sizeof(T_RfsAlmInfo) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspGetSwitchStatusAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT16 rfSwTestMode = 0;
    UINT16 rfSwSta = 0;
    UINT32 lenth = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_MsgSend *ookSend = GetSendFrame();
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    if (pFuncPara->pTddCtrl != NULL)
    {
        if(COMMON_OK != pFuncPara->pGetRfSwitchSta(&rfSwSta))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    if (pFuncPara->pTddCtrl != NULL)
    {
        if(COMMON_OK != pFuncPara->pGetMamualMode(&rfSwTestMode))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    ookSend->rfsMsg.msgInfo.switchSta.ackData = msgAckResult;       /* 版本实际信息 */
    ookSend->rfsMsg.msgInfo.switchSta.rfSwTestMode = ook_htons(rfSwTestMode);
    ookSend->rfsMsg.msgInfo.switchSta.rfSwSta = ook_htons(rfSwSta);

    UARTprintf("rfSwTestMode = %d,rfSwSta = %d\n", rfSwTestMode, rfSwSta);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsSwitchSta), serialNo);
    lenth = sizeof(T_RfsSwitchSta) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspClrAlmStatusAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT32 clrAlmState = 0;
    UINT32 clrAlmEvent = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);
    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    UARTprintf("test msgtype 22 get fun success!\n");
    UARTprintf("clrAlmState0 = 0x%x clrAlmEvent0 = 0x%x!\n", reqRfMsg->clrAlmSta.clrAlmState, reqRfMsg->clrAlmSta.clrAlmEvent);
    clrAlmState = ook_ntohl(reqRfMsg->clrAlmSta.clrAlmState);
    clrAlmEvent = ook_ntohl(reqRfMsg->clrAlmSta.clrAlmEvent);
    UARTprintf("clrAlmState = 0x%x clrAlmEvent = 0x%x!\n", clrAlmState, clrAlmEvent);

    if (pFuncPara->pClrAlmStatus != NULL)
    {
        if(COMMON_OK != pFuncPara->pClrAlmStatus(clrAlmState, clrAlmEvent))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    BspSendOokAck(msgType, msgAckResult, serialNo);
}

VOID BspGetAnalogVoltAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT16 chan = 0;
    UINT32 analogVolt = 0;
    INT32 paTemp = 0;
    UINT8 vaildFlag = 0;
    UINT32 lenth = 0;
    UINT8 direction = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    T_MsgSend *ookSend = GetSendFrame();
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    chan = reqRfMsg->analogVolt.chan;
    direction = reqRfMsg->analogVolt.direction;

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    if (pFuncPara->pRfSwitchCtrl != NULL)
    {
        if(COMMON_OK != pFuncPara->pRfSwitchCtrl(chan, direction))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    if (pFuncPara->pGetPaTempAndAnalogVolt != NULL)
    {
        if(COMMON_OK != pFuncPara->pGetPaTempAndAnalogVolt(chan, &vaildFlag, &analogVolt, &paTemp))
        {
            msgAckResult = RFS_MSG_ACK_ERROR;
        }
    }

    ookSend->rfsMsg.msgInfo.analogVoltAck.vaildFlag = vaildFlag;
    ookSend->rfsMsg.msgInfo.analogVoltAck.paTemp = ook_htonl(paTemp);
    ookSend->rfsMsg.msgInfo.analogVoltAck.volt = ook_htonl(analogVolt);

    UARTprintf("vaildFlag = %d, paTemp = %d, analogVolt = %d, chan = %d, direction = %d, msgAckResult = %d\n", 
            vaildFlag, paTemp, analogVolt, chan, direction, msgAckResult);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsGetAnalogVoltAck), serialNo);
    lenth = sizeof(T_RfsGetAnalogVoltAck) + sizeof(T_RfsMsgHead);
    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);
    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspSendRruInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index)
{
    INPUT_POINTER_CHECK_RETURN(msgInfo);
    INPUT_POINTER_CHECK_RETURN(propertyInfo);

    msgInfo->rruInfo.ackData = 0;
    memcpy_s(msgInfo->rruInfo.rruBarCode, NELEMENTS(msgInfo->rruInfo.rruBarCode), propertyInfo->RruInfo.rruBarCode, NELEMENTS(propertyInfo->RruInfo.rruBarCode));
    UARTprintf("des[%s], sorce[%s]\n", msgInfo->rruInfo.rruBarCode, propertyInfo->RruInfo.rruBarCode);
    memcpy_s(msgInfo->rruInfo.vendorUnitFamilyType, NELEMENTS(msgInfo->rruInfo.vendorUnitFamilyType), propertyInfo->RruInfo.vendorUnitFamilyType, NELEMENTS(propertyInfo->RruInfo.vendorUnitFamilyType));
    memcpy_s(msgInfo->rruInfo.vendorUnitTypeNumber, NELEMENTS(msgInfo->rruInfo.vendorUnitTypeNumber), propertyInfo->RruInfo.vendorUnitTypeNumber, NELEMENTS(propertyInfo->RruInfo.vendorUnitTypeNumber));
    memcpy_s(msgInfo->rruInfo.vendorUnitPid, NELEMENTS(msgInfo->rruInfo.vendorUnitPid), propertyInfo->RruInfo.vendorUnitPid, NELEMENTS(propertyInfo->RruInfo.vendorUnitPid));
    msgInfo->rruInfo.verdorUnitPidFlag = propertyInfo->RruInfo.verdorUnitPidFlag;
    msgInfo->rruInfo.rruPaNum = propertyInfo->RruInfo.rruPaNum;
    msgInfo->rruInfo.rruDflNum = propertyInfo->RruInfo.rruDflNum;
    msgInfo->rruInfo.rruPwrNum = propertyInfo->RruInfo.rruPwrNum;
    msgInfo->rruInfo.rruPibNum = propertyInfo->RruInfo.rruPibNum;
    msgInfo->rruInfo.rruAntNum = propertyInfo->RruInfo.rruAntNum;
    msgInfo->rruInfo.antNum = propertyInfo->RruInfo.antNum;
    msgInfo->rruInfo.rruRatedPowerTx = ook_htonl(propertyInfo->RruInfo.rruRatedPowerTx);
    memcpy_s(msgInfo->rruInfo.bomCode, NELEMENTS(msgInfo->rruInfo.bomCode), propertyInfo->RruInfo.bomCode, NELEMENTS(propertyInfo->RruInfo.bomCode));
    memcpy_s(msgInfo->rruInfo.supplerCode, NELEMENTS(msgInfo->rruInfo.supplerCode), propertyInfo->RruInfo.supplerCode, NELEMENTS(propertyInfo->RruInfo.supplerCode));
    memcpy_s(msgInfo->rruInfo.productTime, NELEMENTS(msgInfo->rruInfo.productTime), propertyInfo->RruInfo.productTime, NELEMENTS(propertyInfo->RruInfo.productTime));
    msgInfo->rruInfo.serviceTime = ook_htonl(propertyInfo->RruInfo.serviceTime);
    memcpy_s(msgInfo->rruInfo.lastServiceDate, NELEMENTS(msgInfo->rruInfo.lastServiceDate), propertyInfo->RruInfo.lastServiceDate, NELEMENTS(propertyInfo->RruInfo.lastServiceDate));
    memcpy_s(msgInfo->rruInfo.vendorName, NELEMENTS(msgInfo->rruInfo.vendorName), propertyInfo->RruInfo.vendorName, NELEMENTS(propertyInfo->RruInfo.vendorName));
}

VOID BspSendRruBoardInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index)
{
    INPUT_POINTER_CHECK_RETURN(msgInfo);
    INPUT_POINTER_CHECK_RETURN(propertyInfo);

    msgInfo->boardInfo.ackData = 0;
    memcpy_s(msgInfo->boardInfo.boardBarCode, NELEMENTS(msgInfo->boardInfo.boardBarCode), propertyInfo->BoardInfo.boardBarCode, NELEMENTS(propertyInfo->BoardInfo.boardBarCode));
    memcpy_s(msgInfo->boardInfo.boardName, NELEMENTS(msgInfo->boardInfo.boardName), propertyInfo->BoardInfo.boardName, NELEMENTS(propertyInfo->BoardInfo.boardName));
    memcpy_s(msgInfo->boardInfo.productTime, NELEMENTS(msgInfo->boardInfo.productTime), propertyInfo->BoardInfo.productTime, NELEMENTS(propertyInfo->BoardInfo.productTime));
    msgInfo->boardInfo.serviceTime = ook_htonl(propertyInfo->BoardInfo.serviceTime);
    memcpy_s(msgInfo->boardInfo.lastServiceDate, NELEMENTS(msgInfo->boardInfo.lastServiceDate), propertyInfo->BoardInfo.lastServiceDate, NELEMENTS(propertyInfo->BoardInfo.lastServiceDate));
    memcpy_s(msgInfo->boardInfo.vendorName, NELEMENTS(msgInfo->boardInfo.vendorName), propertyInfo->BoardInfo.vendorName, NELEMENTS(propertyInfo->BoardInfo.vendorName));
}

VOID BspSendRruPwrInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index)
{
    INPUT_POINTER_CHECK_RETURN(msgInfo);
    INPUT_POINTER_CHECK_RETURN(propertyInfo);

    msgInfo->pwrInfo.ackData = 0;
    memcpy_s(msgInfo->pwrInfo.pwrBarCode, NELEMENTS(msgInfo->pwrInfo.pwrBarCode), propertyInfo->PwrInfo.pwrBarCode, NELEMENTS(propertyInfo->PwrInfo.pwrBarCode));
    memcpy_s(msgInfo->pwrInfo.pwrType, NELEMENTS(msgInfo->pwrInfo.pwrType), propertyInfo->PwrInfo.pwrType, NELEMENTS(propertyInfo->PwrInfo.pwrType));
    msgInfo->pwrInfo.defaultPwrVolt = ook_htonl(propertyInfo->PwrInfo.defaultPwrVolt);
    msgInfo->pwrInfo.pwrVoltUp = ook_htonl(propertyInfo->PwrInfo.pwrVoltUp);
    msgInfo->pwrInfo.pwrVoltDown = ook_htonl(propertyInfo->PwrInfo.pwrVoltDown);
    msgInfo->pwrInfo.pwrFactoryId = ook_htonl(propertyInfo->PwrInfo.pwrFactoryId);
    memcpy_s(msgInfo->pwrInfo.productTime, NELEMENTS(msgInfo->pwrInfo.productTime), propertyInfo->PwrInfo.productTime, NELEMENTS(propertyInfo->PwrInfo.productTime));
    msgInfo->pwrInfo.serviceTime = ook_htonl(propertyInfo->PwrInfo.serviceTime);
    memcpy_s(msgInfo->pwrInfo.lastServiceDate, NELEMENTS(msgInfo->pwrInfo.lastServiceDate), propertyInfo->PwrInfo.lastServiceDate, NELEMENTS(propertyInfo->PwrInfo.lastServiceDate));
    memcpy_s(msgInfo->pwrInfo.vendorName, NELEMENTS(msgInfo->pwrInfo.vendorName), propertyInfo->PwrInfo.vendorName, NELEMENTS(propertyInfo->PwrInfo.vendorName));
}

VOID BspSendRruPaInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index)
{
    INPUT_POINTER_CHECK_RETURN(msgInfo);
    INPUT_POINTER_CHECK_RETURN(propertyInfo);

    msgInfo->paInfo.ackData = 0;
    memcpy_s(msgInfo->paInfo.paBarCode, NELEMENTS(msgInfo->paInfo.paBarCode), propertyInfo->PaInfo.paBarCode, NELEMENTS(propertyInfo->PaInfo.paBarCode));
    memcpy_s(msgInfo->paInfo.boardName, NELEMENTS(msgInfo->paInfo.boardName), propertyInfo->PaInfo.boardName, NELEMENTS(propertyInfo->PaInfo.boardName));
    msgInfo->paInfo.paPath = propertyInfo->PaInfo.paPath;
    memcpy_s(msgInfo->paInfo.paTxFreq, NELEMENTS(msgInfo->paInfo.paTxFreq), propertyInfo->PaInfo.paTxFreq, NELEMENTS(propertyInfo->PaInfo.paTxFreq));
    msgInfo->paInfo.serviceTime = ook_htonl(propertyInfo->PaInfo.serviceTime);
    memcpy_s(msgInfo->paInfo.productTime, NELEMENTS(msgInfo->paInfo.productTime), propertyInfo->PaInfo.productTime, NELEMENTS(propertyInfo->PaInfo.productTime));
    memcpy_s(msgInfo->paInfo.lastServiceDate, NELEMENTS(msgInfo->paInfo.lastServiceDate), propertyInfo->PaInfo.lastServiceDate, NELEMENTS(propertyInfo->PaInfo.lastServiceDate));
    memcpy_s(msgInfo->paInfo.vendorName, NELEMENTS(msgInfo->paInfo.vendorName), propertyInfo->PaInfo.vendorName, NELEMENTS(propertyInfo->PaInfo.vendorName));
}

VOID BspSendRruDflInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index)
{
    INPUT_POINTER_CHECK_RETURN(msgInfo);
    INPUT_POINTER_CHECK_RETURN(propertyInfo);

    msgInfo->difInfo[index].ackData = 0;
    memcpy_s(msgInfo->difInfo[index].dflBarCode, NELEMENTS(msgInfo->difInfo[index].dflBarCode), propertyInfo->DflInfo[index].dflBarCode, NELEMENTS(propertyInfo->DflInfo[index].dflBarCode));
    memcpy_s(msgInfo->difInfo[index].boardName, NELEMENTS(msgInfo->difInfo[index].boardName), propertyInfo->DflInfo[index].boardName, NELEMENTS(propertyInfo->DflInfo[index].boardName));
    msgInfo->difInfo[index].dflAntNum = msgInfo->difInfo[index].dflAntNum;
    memcpy_s(msgInfo->difInfo[index].dflRxFreq, NELEMENTS(msgInfo->difInfo[index].dflRxFreq), propertyInfo->DflInfo[index].dflRxFreq, NELEMENTS(propertyInfo->DflInfo[index].dflRxFreq));
    memcpy_s(msgInfo->difInfo[index].dflTxFreq, NELEMENTS(msgInfo->difInfo[index].dflTxFreq), propertyInfo->DflInfo[index].dflTxFreq, NELEMENTS(propertyInfo->DflInfo[index].dflTxFreq));
    msgInfo->difInfo[index].dflFactoryId = ook_htonl(msgInfo->difInfo[index].dflFactoryId);
    memcpy_s(msgInfo->difInfo[index].productTime, NELEMENTS(msgInfo->difInfo[index].productTime), propertyInfo->DflInfo[index].productTime, NELEMENTS(propertyInfo->DflInfo[index].productTime));
    msgInfo->difInfo[index].serviceTime = ook_htonl(msgInfo->difInfo[index].serviceTime);
    memcpy_s(msgInfo->difInfo[index].lastServiceDate, NELEMENTS(msgInfo->difInfo[index].lastServiceDate), propertyInfo->DflInfo[index].lastServiceDate, NELEMENTS(propertyInfo->DflInfo[index].lastServiceDate));
    memcpy_s(msgInfo->difInfo[index].vendorName, NELEMENTS(msgInfo->difInfo[index].vendorName), propertyInfo->DflInfo[index].vendorName, NELEMENTS(propertyInfo->DflInfo[index].vendorName));
}

VOID BspSendRruAntInfo(T_EachRfsMsg *msgInfo, T_RruProPertyInfo *propertyInfo, UINT8 index)
{
    INPUT_POINTER_CHECK_RETURN(msgInfo);
    INPUT_POINTER_CHECK_RETURN(propertyInfo);

    msgInfo->antInfo.ackData = 0;
    memcpy_s(msgInfo->antInfo.antBarCode, NELEMENTS(msgInfo->antInfo.antBarCode), propertyInfo->AntInfo.antBarCode, NELEMENTS(propertyInfo->AntInfo.antBarCode));
    memcpy_s(msgInfo->antInfo.boardName, NELEMENTS(msgInfo->antInfo.boardName), propertyInfo->AntInfo.boardName, NELEMENTS(propertyInfo->AntInfo.boardName));
    msgInfo->antInfo.antNum = propertyInfo->AntInfo.antNum;
    msgInfo->antInfo.antFactoryId = ook_htonl(msgInfo->antInfo.antFactoryId);
    memcpy_s(msgInfo->antInfo.productTime, NELEMENTS(msgInfo->antInfo.productTime), propertyInfo->AntInfo.productTime, NELEMENTS(propertyInfo->AntInfo.productTime));
    msgInfo->antInfo.serviceTime = ook_htonl(msgInfo->antInfo.serviceTime);
    memcpy_s(msgInfo->antInfo.lastServiceDate, NELEMENTS(msgInfo->antInfo.lastServiceDate), propertyInfo->AntInfo.lastServiceDate, NELEMENTS(propertyInfo->AntInfo.lastServiceDate));
    memcpy_s(msgInfo->antInfo.vendorName, NELEMENTS(msgInfo->antInfo.vendorName), propertyInfo->AntInfo.vendorName, NELEMENTS(propertyInfo->AntInfo.vendorName));
}

VOID BspSendRruInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 index = 0;
    UINT8 msgSubType = 0;
    UINT32 lenth = 0;

    T_MsgSend *ookSend = GetSendFrame();
    T_RruProPertyInfo *propertyInfo = BspGetRruPropertyInfo();

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_INPUT_POINTER_CHECK(propertyInfo, msgType, serialNo);
    OOK_INPUT_POINTER_CHECK(ookSend, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    msgSubType = BspGetMsgSubType();
    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    if(msgSubType < RFS_MSG_RRU_SUB_MAX)
    {
        if(s_rruInfoSubType[msgSubType].pSendRruInfoPara != NULL)
        {
            s_rruInfoSubType[msgSubType].pSendRruInfoPara(&(ookSend->rfsMsg.msgInfo), propertyInfo, index);
        }
    }

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RruInfo), serialNo);
    lenth = sizeof(T_RruInfo) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);
    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);
    UARTprintf("ooksend fill finished, lenth = %d\n", lenth);
}

VOID BspGetGridVoltAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 chipIndex = 0;
    UINT8 dacChan = 0;
    UINT16 lenth = 0;
    INT16 gridVoltMv = 0;
    INT32 tmpVoltMw = 0;
    T_MsgSend *ookSend = GetSendFrame();

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_INPUT_POINTER_CHECK(ookSend, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    chipIndex = reqRfMsg->gridVoltPara.dacChipIdx;
    dacChan = reqRfMsg->gridVoltPara.dacChan;
    zxDRV_Amc7836GetPaGridDac(chipIndex, dacChan, &tmpVoltMw);
    gridVoltMv = (INT16)tmpVoltMw;
    UARTprintf("ook Get grid: chipIndex = %d, dacChan = %d, volt = %dmv\n", chipIndex, dacChan, gridVoltMv);

    ookSend->rfsMsg.msgInfo.gridVoltAck.gridVoltMv = ook_htons(gridVoltMv);
    ookSend->rfsMsg.msgInfo.gridVoltAck.ackData = RFS_MSG_ACK_OK;

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_DacGridVoltAck), serialNo);
    lenth = sizeof(T_DacGridVoltAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);
    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspSwitchModeCtrl(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 chan = 0;
    UINT8 swType = 0;
    UINT32 ret = 0;
    T_MsgSend *ookSend = GetSendFrame();
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    OOK_INPUT_POINTER_CHECK(ookSend, msgType, serialNo);
    OOK_LINK_CHECK(msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));
    chan = reqRfMsg->switchModeCtrl.bspChan;
    swType = reqRfMsg->switchModeCtrl.swModeType;

    if(pFuncPara->pSetSwMode != NULL)
    {
        ret = pFuncPara->pSetSwMode(chan, swType);
    }

    if(ret == COMMON_ERROR)
    {
        BspSendOokAck(msgType, RFS_MSG_ACK_ERROR, serialNo);
    }
    else
    {
        BspSendOokAck(msgType, RFS_MSG_ACK_OK, serialNo);
    }
}

VOID BspWfsBoardInfoAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 lenth = 0;
    CHAR softVer[VER_LENTH] = {0,};
    CHAR fpgaVer[VER_LENTH] = {0,};
    UINT8 firBootVer[BOOT_VER_LENTH] = {0,};
    UINT8 secBootVer[BOOT_VER_LENTH] = {0,};
    UINT8 barCode[BAR_CODE_LENTH] = {0,};
    T_MsgSend *ookSend = GetSendFrame();
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));
    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    if(pFuncPara->pGetFpgaVer != NULL)
    {
        pFuncPara->pGetFpgaVer(fpgaVer);
    }

    if(pFuncPara->pGetSoftVer != NULL)
    {
        pFuncPara->pGetSoftVer(softVer);
    }

    if(pFuncPara->pGetFirBootVer != NULL)
    {
        pFuncPara->pGetFirBootVer(firBootVer, VER_LENTH);
    }

    if(pFuncPara->pGetSecBootVer != NULL)
    {
        pFuncPara->pGetSecBootVer(secBootVer, VER_LENTH);
    }

    if(pFuncPara->pGetBoardBarCode != NULL)
    {
        pFuncPara->pGetBoardBarCode(barCode, sizeof(barCode));
    }
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.moduleGroupId = ook_htonl(BspGetModuleGroupId());
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.boardGroupId = ook_htonl(BspGetBoardGroupId());
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.boardTypeId = ook_htonl(BspGetBoardTypeId());
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.hwChangeId = ook_htonl(BspGetHardwareChangeId());
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.hwCustomIdAId = ook_htonl(BspGetCustomHwIdA());
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.hwCustomIdBId = ook_htonl(BspGetCustomHwIdB());

    memcpy_s(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.cpuVer, sizeof(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.cpuVer), softVer, sizeof(softVer));
    memcpy_s(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.fpgaVer, sizeof(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.fpgaVer), fpgaVer, sizeof(fpgaVer));
    memcpy_s(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.firBootVer, sizeof(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.firBootVer), firBootVer, sizeof(firBootVer));
    memcpy_s(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.secBootVer, sizeof(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.secBootVer), secBootVer, sizeof(secBootVer));
    memcpy_s(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.barCode, sizeof(ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.barCode), barCode, sizeof(barCode));

    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.dacTestResult = 0;
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.mcuTestResult = 0;
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.epldTestResult = 0;
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.epldId = 2;
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.txLogicChanNum = 2;
    ookSend->rfsMsg.msgInfo.wfsBoardInfoAck.ackData = RFS_MSG_ACK_OK;

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsWfsBoardInfoAck), serialNo);
    lenth = sizeof(T_RfsWfsBoardInfoAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);

    lenth += sizeof(T_RfsFrameHead);
    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspWfsAdValAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 adcChan = 0;
    UINT8 chipIndex = 0;
    UINT8 lenth = 0;
    UINT32 adVal = 0;
    T_MsgSend *ookSend = GetSendFrame();

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    UARTprintf("test msgsubtype 1 get fun success!\n");
    adcChan = reqRfMsg->wfsAdValPara.adcChan;
    chipIndex = reqRfMsg->wfsAdValPara.chipIndex;
    UARTprintf("chipIndex = %d, adcChan = %d\n", chipIndex, adcChan);

    BspWfsGetAmc7836CurrAd(chipIndex, adcChan, &adVal);

    ookSend->rfsMsg.msgInfo.wfsAdValAck.adVal = ook_htonl(adVal);
    UARTprintf("adVal = %d\n", adVal);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsWfsAdValAck), serialNo);
    lenth = sizeof(T_RfsWfsAdValAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);
    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspWfsCurrValAck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 adcChan = 0;
    UINT8 chipIndex = 0;
    UINT8 lenth = 0;
    UINT32 currVal = 0;
    T_MsgSend *ookSend = GetSendFrame();
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);

    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));

    pFuncPara = BspGetOokFuncPara();
    OOK_INPUT_POINTER_CHECK(pFuncPara, msgType, serialNo);

    UARTprintf("test msgsubtype 2 get fun success!\n");
    adcChan = reqRfMsg->wfsCurrPara.adcChan;
    chipIndex = reqRfMsg->wfsCurrPara.chipIndex;
    UARTprintf("chipIndex = %d, adcChan = %d\n", chipIndex, adcChan);

    if(pFuncPara->pGetAmc7836Curr != NULL)
    {
        pFuncPara->pGetAmc7836Curr(chipIndex, adcChan, &currVal);
    }

    ookSend->rfsMsg.msgInfo.wfsCurrAck.currVal = ook_htonl(currVal);
    UARTprintf("currVal = %d\n", currVal);

    FillRfMsgHead(&ookSend->rfsMsg, msgType, sizeof(T_RfsWfsCurrAck), serialNo);
    lenth = sizeof(T_RfsWfsCurrAck) + sizeof(T_RfsMsgHead);

    CreateFrameHead(&ookSend->frameHead, (UINT8 *)&ookSend->rfsMsg, lenth);
    lenth += sizeof(T_RfsFrameHead);

    SendOokMsg((VOID *)ookSend , lenth);   //将填充好的信息发送，并且传回相应消息
}

VOID BspWfsRfTblCrcCheck(T_EachRfsMsg *reqRfMsg, UINT8 msgType, UINT8 serialNo)
{
    UINT8 fileType = 0;
    UINT8 msgAckResult = RFS_MSG_ACK_OK;
    UINT32 ret = 0;
    T_MsgSend *ookSend = GetSendFrame();

    OOK_INPUT_POINTER_CHECK(reqRfMsg, msgType, serialNo);
    memset_s(ookSend, sizeof(T_MsgSend), 0, sizeof(T_MsgSend));
    UARTprintf("WFS msg CRC check get success!\n");

    fileType = reqRfMsg->wfsRfTblCrcCheck.fileType;
    ret = BspCheckOffLinePara(fileType);
    if(ret == COMMON_ERROR)
    {
        msgAckResult = RFS_MSG_ACK_ERROR;
    }

    BspSendOokAck(msgType, msgAckResult, serialNo);
}

static UINT8 s_heartBeatSw = 0;

VOID BspCtrlHeartBeat(UINT32 sw)
{
    s_heartBeatSw = sw;
}

static VOID CtrlRunLedByMsgType(VOID)
{
    T_OOK_ACTION_FUNC *pFuncPara = NULL;

    pFuncPara = BspGetOokFuncPara();
    INPUT_POINTER_CHECK_RETURN(pFuncPara);

    if (BspGetLinkStatus() != OOK_LINK_SUCCESS)
    {
        return;
    }

    if(pFuncPara->pClrHeratBeatTimeCnt != NULL)
    {
        pFuncPara->pClrHeratBeatTimeCnt();
    }
}

VOID BspSendMsgOokProc(T_RfsFrame *recv)
{
    T_RfsMsgHead *rfMsg = NULL;
    T_EachRfsMsg *reqRfMsg = NULL;
    UINT8 *msg = NULL;
    UINT8 msgType = 0;
    UINT8 serialNo = 0;
    UINT8 msgSubType = 0;

    INPUT_POINTER_CHECK_RETURN(recv);
    msg = (UINT8 *)recv;
    rfMsg = (T_RfsMsgHead *)(msg + sizeof(T_RfsFrameHead));
    reqRfMsg = (T_EachRfsMsg* )(msg + sizeof(T_RfsFrameHead) + sizeof(T_RfsMsgHead));

    msgType = rfMsg->msgType;
    msgSubType = rfMsg->msgSubType;
    serialNo = rfMsg->serialNo;
    UARTprintf("****ook rev msgtype[%d] success****\n", msgType);

    msgType = rfMsg->msgType;
    BspSetMsgSubType(msgSubType);

    if(s_heartBeatSw != 0)
    {
        return;
    }

    if (RFS_WFS_MSG_TYPE == msgType)
    {
        if (msgSubType < RFS_WFS_MSG_MAX)
        {
            if(s_wfsMsgSendInfo[msgSubType].pSendMsgProc != NULL)
            {
                CtrlRunLedByMsgType();
                s_wfsMsgSendInfo[msgSubType].pSendMsgProc(reqRfMsg, msgType,serialNo);
            }
        }
    }
    else
    {
        if (msgType < RFS_MSG_MAX)
        {
            if(s_msgSendInfo[msgType].pSendMsgProc != NULL)
            {
                CtrlRunLedByMsgType();
                s_msgSendInfo[msgType].pSendMsgProc(reqRfMsg, msgType,serialNo);
            }
        }
        else
        {
            UARTprintf("ook msgType[%d] Err\n", msgType);
            /*todo : 这里要加后处理，后续再看怎么加*/
            BspSendOokAck(msgType, RFS_MSG_ACK_NOT_SUPPORT, serialNo);
        }
    }
    UARTprintf("****ook send msgtype[%d] success****\n", msgType);

}

UINT8 CalculateCheckSum(T_RfsFrameHead *head)
{
    UINT8 *chkSumStart = NULL;
    UINT8 *chkSumEnd = NULL;
    UINT8 *chkAddr = NULL;
    UINT8 chkSum = 0;

    if (head == NULL)
    {
        return 0;
    }

    chkSumStart = (UINT8 *)head + sizeof(head->startFlag1) + sizeof(head->startFlag2);
    chkSumEnd = (UINT8 *)(&head->headSum);

    for (chkAddr = chkSumStart; chkAddr < chkSumEnd; ++chkAddr)
    {
        chkSum += *chkAddr;
    }

    return chkSum;
}

static UINT8 CalculateCrc(const UINT8 *datas, UINT32 dataSize)
{
    const UINT8 crcStartVal = 0xFF;

    if (datas == NULL)
    {
        return crcStartVal;
    }

    return CalculateCrc8(datas, dataSize, crcStartVal);
}




/*****************************************************************************
 * 版权所有(C) 2019, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : utils
 * 文件名称 : uartprint.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 文件提供了UART打印功能
 * 注意事项 :
 * 作    者 : 宋飞
 * 创建日期 : 2019-10-30
 * 当前版本 : V1.0
 *----------------------------------------------------------------------------
 */

#ifndef __UARTPRINT_H__
#define __UARTPRINT_H__

#include <stdarg.h>
#include "typedef.h"
#include "gd32f4xx_usart.h"


//#define  _CMDLINE_CONFIG            1
//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

#define DEBUG_LOG

//*****************************************************************************
//
// Prototypes for the APIs.
//
//*****************************************************************************
extern int32_t UARTCharGet(uint32_t ui32Base);
extern int UARTgets(CHAR *pcBuf, uint32_t ui32Len);
extern CHAR UARTgetc(void);
extern int UARTwrite(const CHAR *pcBuf, uint32_t ui32Len);
extern void UARTprintf(const CHAR *pcString, ...);
extern void CmdLineUartprintf(const CHAR *pcString, ...);
extern void UARTvprintf(const CHAR *pcString, va_list vaArgP);
extern BOOLEAN UARTCharsAvail(uint32_t ui32Base);
extern BOOLEAN UARTCharPutNonBlocking(uint32_t ui32Base, CHAR ucData);
extern INT32 UARTCharGetNonBlocking(UINT32 ui32Base);

UINT8 BspSetOokPrintSw(UINT8 flag);
UINT8 BspSetOokPrintSize(UINT8 size);
UINT8 BspGetOokPrintFlag(VOID);
UINT8 BspGetOokPrintSize(VOID);
UINT8 *BspGetOokPrintData();

UINT8 BspGetOokTestPrintFlag();
VOID BspSetOokTestPrintFlag(UINT8 flag);


//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif // __UARTPRINT_H__

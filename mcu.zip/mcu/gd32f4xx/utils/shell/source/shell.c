#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include "shell.h"

#include "uartprint.h"

/*>  */
static Shell_t gs_Shell;

/**
 * @brief shellç’æ¿ç¶é˜å——å½¶é›æˆ’æŠ?
 *
 * @param recordCmd é—‡ï¿½ç‘•ä½½î†‡è¤°æ› æ®‘é›æˆ’æŠ?
 * @param cmdLen é—‡ï¿½ç‘•ä½½î†‡è¤°æ›æ‡¡æµ ã‚‡æ®‘é—€å?å®?
 *
 */
static ErrCode_e shellRecordCmd(char *recordCmd, uint8_t cmdLen)
{
    if (recordCmd == NULL)
    {
        return SHELL_COMMON_ERROR;
    }

    if( gs_Shell.history.hisCmdNum > SHELL_HISTORY_MAX_NUMBER )
    {
        return SHELL_HIS_FULL;
    }

    if ( cmdLen > SHELL_CMD_MAX_LEN )
    {
        return SHELL_HIS_TOO_LONG;
    }

    if( gs_Shell.history.hisCmdNum == 0 || strcmp(recordCmd, gs_Shell.history.hisCmd[gs_Shell.history.hisCmdPosWr-1]) )
    {
        memset(gs_Shell.history.hisCmd[gs_Shell.history.hisCmdPosWr], '\0', SHELL_CMD_MAX_LEN);
        strncpy(gs_Shell.history.hisCmd[gs_Shell.history.hisCmdPosWr], recordCmd, cmdLen);
        gs_Shell.history.hisCmdNum++;
        gs_Shell.history.hisCmdPosWr++;
        gs_Shell.history.hisCmdPosRd = gs_Shell.history.hisCmdPosWr;
    }

    gs_Shell.history.hisCmdPosRd = gs_Shell.history.hisCmdPosWr;

    return SHELL_CMD_SUCCESS;
}

/**
 * @brief shellé‘¾å³°å½‡ç’æ¿ç¶é˜å——å½¶é›æˆ’æŠ¤
 *
 * @param recordCmd é—‡ï¿½ç‘•ä½½å¹é™æ ?î†‡è¤°æ› æ®‘é›æˆ’æŠ?
 * @param cmdLen é—‡ï¿½ç‘•ä½½å¹é™æ ?î†‡è¤°æ›æ‡¡æµ ã‚‡æ®‘é—€å?å®?
 * @param dir é‘¾å³°å½‡é‚ç‘°æ‚œ
 *
 */
static ErrCode_e shellGetRecordCmd(char *recordCmd, int8_t *cmdLen, CmdDir_e dir)
{
    if(strlen(recordCmd)+1 > SHELL_CMD_MAX_LEN)
    {
        return SHELL_CMD_STR_TOO_LONG;
    }

    /* ç’‡è?²å½‡æ¶“å©ç«´æ¶“î„æ‡¡æµ ï¿½ */
    if( dir == CMD_UP )
    {
        if( gs_Shell.history.hisCmdPosRd > 0 )
        {
            gs_Shell.history.hisCmdPosRd--;
            strncpy(recordCmd, gs_Shell.history.hisCmd[gs_Shell.history.hisCmdPosRd], SHELL_CMD_MAX_LEN -1);
            *cmdLen = strlen(recordCmd);

            return SHELL_HIS_SUCCESS;
        }
        else
        {
            return SHELL_HIS_OVER;
        }
    }
    else  /* ç’‡è?²å½‡æ¶“å?©ç?´æ¶“î„æ‡¡æµ ï¿½ */
    {
        if( gs_Shell.history.hisCmdPosRd < gs_Shell.history.hisCmdPosWr )
        {
            gs_Shell.history.hisCmdPosRd++;
            strncpy(recordCmd, gs_Shell.history.hisCmd[gs_Shell.history.hisCmdPosRd], SHELL_CMD_MAX_LEN -1);
            *cmdLen = strlen(recordCmd);

            return SHELL_HIS_SUCCESS;
        }
        else
        {
            return SHELL_HIS_OVER;
        }
    }
}

/**
 * @brief shelléæ¬æ‡¡æµ ã‚†å½ç»€è™¹îƒ
 *
 * @param newline é‚æ‹Œî”?
 *
 */
static void shellWritePrompt(unsigned char newline)
{
    if (newline)
    {
        ShellPrint("\r\n");
    }

    if(gs_Shell.pass.shellStatus == CMD_UNLOCK)
    {
        ShellPrint(CONSOLE_PROMPTS);
    }

}

/**
 * @brief shellé’çŠ»æ«é›æˆ’æŠ¤ç›å±¾æšŸé¹ï¿?
 *
 * @param shell shellç€µç?…è–„
 * @param length é’çŠ»æ«é—€å?å®?
 */
static void shellDeleteCommandLine(uint8_t length)
{
    while (length--)
    {
        ShellPrint("\b \b");
    }
}

/**
 * @brief shell é–?ï¿½éï¿?
 *
 * @param shell shellç€µç?…è–„
 */
static void shellBackspace(void)
{
    ShellPrint("\b \b");
}

/**
 * @brief shell å¨“å‘¯â”–é›æˆ’æŠ¤ç’æ¿ç¶?
 *
 */
static void ShellClearCmd(void)
{
    memset(gs_Shell.cmd.cmdBuf, '\0', SHELL_CMD_MAX_LEN);
    gs_Shell.cmd.cmdLen = 0;
}

/**
 * @brief shell éµæ’³åµƒé›æˆ’æŠ¤
 *
 */
static void ShellDisplayCmd(void)
{
    ShellPrint("%s",gs_Shell.cmd.cmdBuf);
}

/**
 * @brief shell logo éµæ’³åµ?
 *
 */
void ShellCmdLogoPrint(void)
{
    ShellPrint("\r\n");
    ShellPrint("**********************************************\r\n");
    ShellPrint("**     Welcome to use command line.        ***\r\n");
    ShellPrint("**     Author: 10294149                    ***\r\n");
    ShellPrint("**     Version: v1.0                       ***\r\n");
    ShellPrint("**********************************************\r\n");
}

/**
 * @brief shellé’æ¿†îé–ï¿?
 *
 * @param WriteFunction shellæˆæ’³åš?é‘èŠ¥æš?
 * @param ReadFuntion shellæˆæ’³å†é‘èŠ¥æšŸé”›å±¼è…‘é‚î…ŸÄå??å¿ç¬‰é—‡ï¿½ç‘•ï¿½
 *
 */
void ShellInit(ShellWriteFun WriteFunction, ShellReadFun ReadFuntion)
{
    if( NULL != WriteFunction )
    {
        gs_Shell.fun.WriteFun = WriteFunction;
    }

    if( NULL != ReadFuntion )
    {
        gs_Shell.fun.ReadFun = ReadFuntion;
    }

    gs_Shell.pass.shellStatus = CMD_UNLOCK;
    ShellClearCmd();
    ShellCmdLogoPrint();
    shellWritePrompt(1);
}

/**
 * @brief shell display all support cmd
 *
 * @param none
 *
 */
void ShellDisplaySupportCmd(void)
{
    uint32_t i;

    for(i = 0; i < gs_Shell.CmdListNum; i++)
    {
        ShellPrint("%16s \t %s \r\n", gs_Shell.CmdList[i].CmdName, gs_Shell.CmdList[i].CmdHelp);
    }
}

/**
 * @brief shellæ©æ¶œî”‘éç…ç´¡é–æ ¬ç·?é‘ï¿½
 *
 * @param pcString shelléç…ç´¡é–æ ?ç·?é‘å“„å¼?éï¿½
 *
 */
void ShellPrint(const char *pcString, ...)
{
    #if 0
     if (gs_Shell.fun.WriteFun != NULL)
     {
        unsigned int num = 0;
        char str[256] = {0};
        va_list vaList;

        va_start(vaList,pcString);
        num = vsnprintf(str, 256, pcString, vaList);
        va_end(vaList);

        gs_Shell.fun.WriteFun(str, num);
     }
     #else
     va_list vaArgP;

    //
    // Start the varargs processing.
    //
    va_start(vaArgP, pcString);

    UARTvprintf(pcString, vaArgP);

    //
    // We're finished with the varargs now.
    //
    va_end(vaArgP);
    #endif
}

/**
 * @brief ç‘™ï½†ç€½é›æˆ’æŠ¤éªèˆµå¢½ç›ï¿?
 *
 *
 */
static ErrCode_e ShellExecute(void)
{
    char *SplitStr[10] = {0};
    int SplitStrindex = 0;
    int i;

    SplitStr[SplitStrindex] = strtok(gs_Shell.cmd.cmdBuf, SPLIT_CHAR_TOKEN);

    while(SplitStr[SplitStrindex] != NULL)
    {
        SplitStr[++SplitStrindex] = strtok(NULL, SPLIT_CHAR_TOKEN);
    }

    for ( i = 0; i < gs_Shell.CmdListNum; i++ )
    {
        if( !strcmp(gs_Shell.CmdList[i].CmdName, SplitStr[0]) )
        {
            shellWritePrompt(1);
            gs_Shell.CmdList[i].CmdCallBack(SplitStrindex, SplitStr);

            return SHELL_CMD_SUCCESS;
        }
    }

        if( i == gs_Shell.CmdListNum )
        {
                ShellPrint("\r\nerror:not support this cmd\r\n");

                return SHELL_CMD_ERROR;
        }

        return SHELL_CMD_SUCCESS;

}

/**
 * @brief å¨‰ã„¥å”½é›æˆ’æŠ¤
 *
 * @param name é›æˆ’æŠ¤éšï¿?
 * @param cmdFun é›æˆ’æŠ¤é¥ç‚¶çšŸé‘èŠ¥æš?
 * @param help é›æˆ’æŠ¤ç”¯î†¼å§ªæ·‡â„ƒä¼?
 *
 */
ErrCode_e ShellCmdRegister(char *name, ShellCmd cmdFun, char *help)
{
    CmdList_t CmdListTmp;

    if (gs_Shell.CmdListNum >= SHELL_CMD_LIST_MAX_NUM)
    {
       return SHELL_CMD_LIST_FULL;
    }

    if (strlen(name)+1 > SHELL_CMD_NAME_LEN || strlen(help)+1 > SHELL_CMD_HELP_LEN)
    {
        return SHELL_CMD_STR_TOO_LONG;
    }

    strncpy(CmdListTmp.CmdName, name, SHELL_CMD_NAME_LEN-1);
    CmdListTmp.CmdCallBack = cmdFun;
    strncpy(CmdListTmp.CmdHelp, help, SHELL_CMD_HELP_LEN-1);

    gs_Shell.CmdList[gs_Shell.CmdListNum] = CmdListTmp;
    gs_Shell.CmdListNum++;

    return SHELL_CMD_SUCCESS;
}

/**
 * @brief éºãƒ¦æ•¹é›æˆ’æŠ¤
 *
 * @param name é›æˆ’æŠ¤éšï¿?
 * @param cmdFun é›æˆ’æŠ¤é¥ç‚¶çšŸé‘èŠ¥æš?
 * @param help é›æˆ’æŠ¤ç”¯î†¼å§ªæ·‡â„ƒä¼?
 *
 */
void ShellReadDataByte(uint8_t cmdByte)
{
    switch (cmdByte)
    {
        case '\r':    /* Enter*/
        case '\n':
        {
            if( gs_Shell.cmd.cmdLen == 0 )
            {
                shellWritePrompt(1);
            }
            else
            {
                shellRecordCmd(gs_Shell.cmd.cmdBuf, gs_Shell.cmd.cmdLen);
                ShellExecute();
                ShellClearCmd();
            }
            break;
        }
        case 8: /* Backspace*/
        {
            gs_Shell.cmd.cmdLen--;
            if (gs_Shell.cmd.cmdLen < 0)
            {
                gs_Shell.cmd.cmdLen = 0;
            }
            else
            {
                shellBackspace();
                gs_Shell.cmd.cmdBuf[gs_Shell.cmd.cmdLen] = '\0';
            }
            break;
        }
        case 0x1b:
        case 0x5b:
        {
            break;
        }
        case 0x41: /* UP */
        {
            shellDeleteCommandLine(gs_Shell.cmd.cmdLen);
            ShellClearCmd();
            shellGetRecordCmd(gs_Shell.cmd.cmdBuf, &gs_Shell.cmd.cmdLen, CMD_UP);
            ShellDisplayCmd();
            break;
        }
        case 0x42: /* DOWN */
        {
            shellDeleteCommandLine(gs_Shell.cmd.cmdLen);
            ShellClearCmd();
            shellGetRecordCmd(gs_Shell.cmd.cmdBuf, &gs_Shell.cmd.cmdLen, CMD_DOWN);
            ShellDisplayCmd();
            break;
        }
        default:
        {
            /* Must be a normal character then */
            if (gs_Shell.pass.shellStatus == CMD_LOCK)
            {
                ShellPrint("%c",'*');
            }
            else
            {
                ShellPrint("%c",cmdByte);
            }
            gs_Shell.cmd.cmdBuf[gs_Shell.cmd.cmdLen++] = cmdByte;

            if(gs_Shell.cmd.cmdLen > SHELL_CMD_MAX_LEN)
            {
                ShellClearCmd();
                ShellPrint("Input Command too Long!\n");
            }
            break;
        }
    }
}

uint32_t CmdGetLockStatus(void)
{
    return gs_Shell.pass.shellStatus;
}


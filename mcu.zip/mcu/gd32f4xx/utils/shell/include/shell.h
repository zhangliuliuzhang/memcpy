#ifndef _SHELL_H_
#define _SHELL_H_

#include "shell_cfg.h"

typedef enum err_code_def
{
    SHELL_CMD_SUCCESS,
    SHELL_CMD_LIST_FULL,
    SHELL_CMD_STR_TOO_LONG,
    SHELL_CMD_ERROR,

    SHELL_HIS_SUCCESS,
    SHELL_HIS_FULL,
    SHELL_HIS_TOO_LONG,
    SHELL_HIS_OVER,

    SHELL_LOCKED,

    SHELL_COMMON_ERROR,

}ErrCode_e;

typedef enum get_cmd_dir_def
{
    CMD_UP,
    CMD_DOWN,

    CMD_DIR
}CmdDir_e;

typedef enum cmd_pass_status_def
{
    CMD_UNLOCK,
    CMD_LOCK,

    CMD_LOCK_STATUS
}CmdPassword_e;

typedef void (*ShellWriteFun)(const char *pcString, unsigned int stringLen);
typedef uint8_t (*ShellReadFun)(char *data);

typedef int (*ShellCmd)(int argc, char *argv[]);   /*< é›æˆ’æŠ¤é¥ç‚¶çšŸé‘èŠ¥æšŸéŽ¸å›?æ‹? */

typedef struct cmd_list_def
{
    char CmdName[SHELL_CMD_NAME_LEN];  /*< é›æˆ’æŠ¤éšï¿? */
    ShellCmd CmdCallBack;              /*< é›æˆ’æŠ¤é¥ç‚¶çšŸé‘èŠ¥æš? */
    char CmdHelp[SHELL_CMD_HELP_LEN];  /*< é›æˆ’æŠ¤ç”¯î†¼å§ªæ·‡â„ƒä¼? */
}CmdList_t;


typedef struct shell_def
{
    /*< è¤°æ’³å¢ é›æˆ’æŠ¤æˆæ’³å†ç’æ¿ç¶ */
    struct
    {
        char cmdBuf[SHELL_CMD_MAX_LEN];
        int8_t cmdLen;
    } cmd;

    /*< å¨‰ã„¥å”½é›æˆ’æŠ¤é’æ?„ã€? */
    CmdList_t CmdList[SHELL_CMD_LIST_MAX_NUM];
    uint8_t CmdListNum;

    // struct
    // {
    //     /* data */
    // } parser;

    /*< é˜å——å½¶é›æˆ’æŠ¤ç’æ¿ç¶? */
    struct
    {
        char hisCmd[SHELL_HISTORY_MAX_NUMBER][SHELL_CMD_MAX_LEN];
        uint8_t hisCmdNum;
        uint8_t hisCmdPosWr;
        uint8_t hisCmdPosRd;
    } history;

    struct
    {
        uint8_t shellStatus;
        char shellPass[SHELL_CMD_LIST_MAX_NUM];
    } pass;


    /*< é›æˆ’æŠ¤æˆæ’³å†æˆæ’³åš? */
    struct
    {
        ShellWriteFun WriteFun;
        ShellReadFun ReadFun;
    } fun;


} Shell_t;

void ShellInit(ShellWriteFun WriteFunction, ShellReadFun ReadFuntion);
void ShellDisplaySupportCmd(void);
void ShellPrint(const char *pcString, ...);
ErrCode_e ShellCmdRegister(char *name, ShellCmd cmdFun, char *help);
void ShellReadDataByte(uint8_t cmdByte);
uint32_t CmdGetLockStatus(void);

#endif

#ifndef _SHELL_CFG_H_
#define _SHELL_CFG_H_

#include <stdint.h>

/**
 * @brief 榛樿�よ緭鍑烘彁绀�
 */
#define CONSOLE_PROMPTS            "$$"

/**
 * @brief 榛樿�ゅ垎鍓插瓧绗�--绌烘牸鍜岄€楀彿
 */
#define SPLIT_CHAR_TOKEN          ", "

/**
 * @brief 涓€鏉�shell鍛戒护鏀�鎸佺殑鏈€澶у瓧鑺傛暟
 */
#define SHELL_CMD_MAX_LEN         (uint8_t)(64)

/**
 * @brief shell鏀�鎸佹渶澶氬懡浠ゆ暟
 */
#define SHELL_CMD_LIST_MAX_NUM    (uint8_t)(32)

/**
 * @brief shell鏀�鎸佹渶澶氬巻鍙插懡浠ゆ暟
 */
#define SHELL_HISTORY_MAX_NUMBER  (uint8_t)(10)

/**
 * @brief shell鏀�鎸佸懡浠ら暱搴�
 */
#define SHELL_CMD_NAME_LEN        (uint8_t)(32)

/**
 * @brief shell鏀�鎸佸懡浠ら暱搴﹀府鍔╀俊鎭�
 */
#define SHELL_CMD_HELP_LEN        (uint8_t)(64)



#endif

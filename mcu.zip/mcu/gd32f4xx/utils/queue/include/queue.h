/*****************************************************************************
 * 版权所有(C) 2019, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : queue
 * 文件名称 : queue.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件提供了队列功能
 * 注意事项 : 无
 * 作    者 : 10294149
 * 创建日期 : 2021-3
 * 当前版本 : V1.0
 *----------------------------------------------------------------------------
 */

 #ifndef _QUEUE_H_
 #define _QUEUE_H_

 #include "typedef.h"

#define QUEUE_SEND_TO_BACK    ( 0 )
#define QUEUE_SEND_TO_FRONT   ( 1 )
#define QUEUE_OVERWRITE       ( 2 )

 typedef struct
{
    BYTE *pHead;
    BYTE *pTail;
    BYTE *pWriteTo;
    BYTE *pReadFrom;
    UINT32 u32MessageWaiting;
    UINT32 u32Lenth;
    UINT32 u32ItemSize;
}Queue_t;

/*  example:
 *
 *  BYTE stro[4];
 *  Queue_t Queue;
 *  BYTE testSendData;
 *  BYTE testRecvData;
 *
 *  zxUTILS_QueueCreatStatic( 4, sizeof(BYTE), stro, &Queue );
 *
 *  testSendData = 7;
 *  retvle = zxUTILS_QueueGenericSend( &Queue, &testSendData );
 *
 *  retvle = zxUTILS_QueueRecvive( &Queue, &testRecvData );
 *
*/
UINT32 zxUTILS_QueueCreatStatic( BYTE queueLenth, BYTE itemSize, BYTE* pQueueStorage, Queue_t *pQueue );
UINT32 zxUTILS_QueueGenericSend( Queue_t *pQueue, const VOID * const pItemToQueue, BYTE ucCopyPos );
UINT32 zxUTILS_QueueRecvive( Queue_t *pQueue, VOID * const pBuffer );
UINT32 zxUTILS_QueueCreatStatic( BYTE queueLenth, BYTE itemSize, BYTE* pQueueStorage, Queue_t *pQueue );
UINT32 zxUTILS_QueueSend( Queue_t *pQueue, const VOID * const pItemToQueue );
UINT32 zxUTILS_QueueSendFront(Queue_t *pQueue, const VOID * const pItemToQueue );
UINT32 zxUTILS_QueueSendOverWrite( Queue_t *pQueue, const VOID * const pItemToQueue );
UINT32 zxUTILS_QueueRecvive( Queue_t *pQueue, VOID * const pBuffer );
UINT32 zxUTILS_QueueMessageWaiting( Queue_t *pQueue );
UINT32 zxUTILS_QueueSpacesAvailable( Queue_t *pQueue );
#endif

/*****************************************************************************
 * 版权所有(C) 2019, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * 模 块 名 : queue
 * 文件名称 : queue.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件提供了队列功能
 * 注意事项 : 无
 * 作    者 : 10294149
 * 创建日期 : 2021-3
 * 当前版本 : V1.0
 *----------------------------------------------------------------------------
 */

#include <string.h>
#include "queue.h"
#include "utils.h"
#include "common.h"


/**********************************************************************/
/**
  * \brief 创建静态队列
  *
  * \param queueLenth: 队列长度
  * \param itemSize: 队列项大小
    * \param pQueueStorage: 队列储存地址
  * \param pQueue: 队列结构体
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueCreatStatic( BYTE queueLenth, BYTE itemSize, BYTE* pQueueStorage, Queue_t *pQueue )
{
    INPUT_POINTER_CHECK(pQueueStorage);
    INPUT_POINTER_CHECK(pQueue);

    pQueue->pHead       = pQueueStorage;
    pQueue->u32Lenth    = queueLenth;
    pQueue->u32ItemSize = itemSize;

    pQueue->pTail = pQueue->pHead + (pQueue->u32Lenth * pQueue->u32ItemSize);

    pQueue->u32MessageWaiting = 0;

    pQueue->pWriteTo  = pQueue->pHead;
    pQueue->pReadFrom = pQueue->pHead;

    return COMMON_OK;
}

/**********************************************************************/
/**
* \brief 向静态队列中发送数据
  *
  * \param pQueue: 队列结构体
  * \param pItemToQueue: 队列项
* \param ucCopyPos: 发送位置
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueGenericSend( Queue_t *pQueue, const VOID * const pItemToQueue, BYTE ucCopyPos )
{
    INPUT_POINTER_CHECK(pQueue);
    INPUT_POINTER_CHECK(pItemToQueue);

    __disable_irq();

    if( (pQueue->u32MessageWaiting < pQueue->u32Lenth) || (ucCopyPos == QUEUE_OVERWRITE) )
    {
        if( ucCopyPos == QUEUE_SEND_TO_FRONT )
        {
            pQueue->pReadFrom -= pQueue->u32ItemSize;
            if( pQueue->pReadFrom < pQueue->pHead )
            {
                pQueue->pReadFrom = pQueue->pTail - pQueue->u32ItemSize;
            }

            memcpy( pQueue->pReadFrom, pItemToQueue, pQueue->u32ItemSize );

            __enable_irq();
            return COMMON_OK;
        }
        else
        {
            memcpy( pQueue->pWriteTo, pItemToQueue, pQueue->u32ItemSize );

            pQueue->pWriteTo += pQueue->u32ItemSize;
            if( pQueue->pWriteTo >= pQueue->pTail )
            {
                pQueue->pWriteTo = pQueue->pHead;
            }

            pQueue->u32MessageWaiting += 1;

            __enable_irq();
            return COMMON_OK;
        }
    }
    else
    {
        __enable_irq();
        /* QUEUE IS FULL */
        return COMMON_ERROR;
    }
}

/**********************************************************************/
/**
* \brief 向静态队列中发送数据--发送队列尾
  *
  * \param pQueue: 队列结构体
  * \param pItemToQueue: 队列项
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueSend( Queue_t *pQueue, const VOID * const pItemToQueue )
{
    return zxUTILS_QueueGenericSend( pQueue, pItemToQueue, QUEUE_SEND_TO_BACK );
}

/**********************************************************************/
/**
* \brief 向静态队列中发送数据--发送队列头
  *
  * \param pQueue: 队列结构体
  * \param pItemToQueue: 队列项
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueSendFront(Queue_t *pQueue, const VOID * const pItemToQueue )
{
    return zxUTILS_QueueGenericSend( pQueue, pItemToQueue, QUEUE_SEND_TO_FRONT );
}

/**********************************************************************/
/**
* \brief 向静态队列中发送数据--覆写功能
  *
  * \param pQueue: 队列结构体
  * \param pItemToQueue: 队列项
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueSendOverWrite( Queue_t *pQueue, const VOID * const pItemToQueue )
{
    return zxUTILS_QueueGenericSend( pQueue, pItemToQueue, QUEUE_OVERWRITE );
}

/**********************************************************************/
/**
* \brief 从静态队列中接收数据
  *
  * \param pQueue: 队列结构体
  * \param pBuffer: 队列项接收地址
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueRecvive( Queue_t *pQueue, VOID * const pBuffer )
{
    INPUT_POINTER_CHECK(pQueue);
    INPUT_POINTER_CHECK(pBuffer);

    __disable_irq();

    if( pQueue->u32MessageWaiting > 0 )
    {
        memcpy( pBuffer, pQueue->pReadFrom, pQueue->u32ItemSize );

        pQueue->pReadFrom += pQueue->u32ItemSize;
        if( pQueue->pReadFrom >= pQueue->pTail )
        {
            pQueue->pReadFrom = pQueue->pHead;
        }

        pQueue->u32MessageWaiting -= 1;

        __enable_irq();
        return COMMON_OK;
    }
    else
    {
        __enable_irq();
        /* QUEUE IS NULL */
        return COMMON_ERROR;
    }
}

/**********************************************************************/
/**
* \brief 从静态队列中获取还有几条消息
  *
  * \param pQueue: 队列结构体
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueMessageWaiting( Queue_t *pQueue )
{
    UINT32 ulRel = 0;

    __disable_irq();
    ulRel = pQueue->u32MessageWaiting;
    __enable_irq();

    return ulRel;
}

/**********************************************************************/
/**
* \brief 从静态队列中查看还有多少空间可用
  *
  * \param pQueue: 队列结构体
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxUTILS_QueueSpacesAvailable( Queue_t *pQueue )
{
    UINT32 ulRel = 0;

    __disable_irq();
    ulRel = pQueue->u32Lenth - pQueue->u32MessageWaiting;
    __enable_irq();

    return ulRel;
}

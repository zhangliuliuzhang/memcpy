#ifndef __LOG_H__
#define __LOG_H__

#include "common.h"
#include "typedef.h"

typedef VOID (*LogPrintfFun)(BYTE *pData, UINT32 dataLen);
typedef UINT32 (*LogSectorEraseFun)(UINT32 sector_addr);
typedef UINT32 (*LogWriteFun)(BYTE* pbuffer, UINT32 writeAddr, UINT32 num_byte_to_write);
typedef UINT32 (*LogReadFun)(BYTE* pbuffer, UINT32 read_addr, UINT32 num_byte_to_read);


#if defined (ATG_UPA_P4800) || (ATG_UPA_P1035) || (ATG_PHARE_ARR) || (R9124_S)
typedef struct
{
    /** 日志时间�?? */
    BYTE year;
    BYTE month;
    BYTE day;
    BYTE hour;
    BYTE minute;
    BYTE second;

    /** 日志内�?? */
    UINT32 temperture;
    UINT32 channelIndex;
    UINT32 channelErrCode;

}T_Log;
#endif

typedef struct
{
    UINT32 LogTotalNum;                      /** 日志总条�?? */
    UINT32 LogCurrNum;                  /** 日志当前总条�?? */
    UINT32 LogCtrlBlockAddr;            /** 日志控制块存储地址 */
    UINT32 LogStartAddr;                /** 日志存储起�?�地址 */
    UINT32 LogEndAddr;                  /** 日志存储结束地址 */
    UINT32 LogLenth;                    /** 日志大小 */
    UINT32 LogAlignLenth;                /** 日志对齐后大�? */
    UINT32 LogSectorLenth;                /** 日志擦除扇区大小 */

    UINT32 LogWriteAddr;                /** 日志写地址 */
    UINT32 LogReadAddr;                 /** 日志读地址 */

    LogSectorEraseFun EraseSectorFun;   /** 日志擦除扇区接口 */
    LogWriteFun WriteFun;               /** 日志写接�?? */
    LogReadFun ReadFun;                 /** 日志读接�?? */
}T_LogAttr;


UINT32 LogStore(T_Log log);
UINT32 LogClear(VOID);
UINT32 LogQuery(VOID);
UINT32 LogParaQuery(VOID);

#endif

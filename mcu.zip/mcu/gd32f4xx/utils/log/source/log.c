
#include "log.h"
#include "stdarg.h"
#include "stdio.h"

#include "uartprint.h"

static T_LogAttr stLogCtrlBlock;

static UINT32 LogPrintf(const CHAR *pcString, ...);


/**
 * @brief LogGetCtrlBlock
 *
 * @param VOID
 *
 */
T_LogAttr LogGetCtrlBlock(VOID)
{
    T_LogAttr tempLogAttr = {0};

    stLogCtrlBlock.ReadFun((BYTE*)&tempLogAttr, stLogCtrlBlock.LogCtrlBlockAddr, sizeof(T_LogAttr));

    return tempLogAttr;
}

/**
 * @brief Log Store
 *
 * @param log LOG
 *
 */
UINT32 LogStore(T_Log log)
{
    if (stLogCtrlBlock.WriteFun == NULL)
    {
        return COMMON_ERROR;
    }

    /* 日志溢出 */
    if (stLogCtrlBlock.LogWriteAddr >= stLogCtrlBlock.LogEndAddr)
    {
        stLogCtrlBlock.LogWriteAddr = stLogCtrlBlock.LogStartAddr;
    }

    /* 日志溢出按扇区擦�?? */
    if (stLogCtrlBlock.LogReadAddr == stLogCtrlBlock.LogWriteAddr && stLogCtrlBlock.LogCurrNum != 0)
    {
        stLogCtrlBlock.EraseSectorFun(stLogCtrlBlock.LogReadAddr);
        stLogCtrlBlock.LogReadAddr += stLogCtrlBlock.LogSectorLenth;
        if (stLogCtrlBlock.LogReadAddr >= stLogCtrlBlock.LogEndAddr)
        {
            stLogCtrlBlock.LogReadAddr = stLogCtrlBlock.LogStartAddr;
        }
        stLogCtrlBlock.LogCurrNum -= (stLogCtrlBlock.LogSectorLenth / stLogCtrlBlock.LogAlignLenth);
    }

    stLogCtrlBlock.WriteFun((BYTE* )&log, stLogCtrlBlock.LogWriteAddr, sizeof(T_Log));
    stLogCtrlBlock.LogWriteAddr += stLogCtrlBlock.LogAlignLenth;
    stLogCtrlBlock.LogCurrNum++;
    stLogCtrlBlock.EraseSectorFun(stLogCtrlBlock.LogCtrlBlockAddr);
    stLogCtrlBlock.WriteFun((BYTE*)&stLogCtrlBlock, stLogCtrlBlock.LogCtrlBlockAddr, sizeof(T_LogAttr));

    return COMMON_OK;
}

/**
 * @brief Log Store
 *
 * @param log LOG
 *
 */
UINT32 LogClear(VOID)
{
    UINT32 totalSectorCnt = 0;

    /* 擦除日志 */
    totalSectorCnt = (stLogCtrlBlock.LogEndAddr - stLogCtrlBlock.LogStartAddr) / stLogCtrlBlock.LogSectorLenth;
    for (UINT32 i = 0; i < totalSectorCnt; i++)
    {
        stLogCtrlBlock.EraseSectorFun(stLogCtrlBlock.LogStartAddr + i * stLogCtrlBlock.LogSectorLenth);
    }

    stLogCtrlBlock.LogWriteAddr = stLogCtrlBlock.LogStartAddr;
    stLogCtrlBlock.LogReadAddr  = stLogCtrlBlock.LogStartAddr;
    stLogCtrlBlock.LogCurrNum   = 0;

    stLogCtrlBlock.EraseSectorFun(stLogCtrlBlock.LogCtrlBlockAddr);
    stLogCtrlBlock.WriteFun((BYTE*)&stLogCtrlBlock, stLogCtrlBlock.LogCtrlBlockAddr, sizeof(T_LogAttr));

    return COMMON_OK;
}

static UINT32 LogPrintf(const CHAR *pcString, ...)
{
    #if 0
    UINT32 num = 0;
    BYTE str[256] = {0};
    va_list vaList;

    if (stLogCtrlBlock.PrintfFun == NULL)
    {
        return COMMON_ERROR;
    }

    va_start(vaList,pcString);
    num = vsnprintf(str, 256, pcString, vaList);
    va_end(vaList);

    stLogCtrlBlock.PrintfFun(str, num);

    return COMMON_OK;
    #else
    va_list vaArgP;

    //
    // Start the varargs processing.
    //
    va_start(vaArgP, pcString);

    UARTvprintf(pcString, vaArgP);

    //
    // We're finished with the varargs now.
    //
    va_end(vaArgP);

    return COMMON_OK;
    #endif

}

#if defined (ATG_UPA_P4800) || (ATG_UPA_P1035) || (ATG_PHARE_ARR) || (R9124_S)
static UINT32 LogShow(T_Log log)
{
    // FEED_WDT();
    LogPrintf("[%02d-%02d-%02d %02d:%02d:%02d] Temp->%d Channle%d ErrCode->%d\r\n", log.year, log.month, log.day,
                                                                log.hour, log.minute, log.second,
                                                                log.temperture, log.channelIndex, log.channelErrCode);

    return COMMON_OK;
}
#endif

/**
 * @brief Log Store
 *
 * @param logNum LOG number  0:all log
 *
 */
UINT32 LogQuery(VOID)
{
    UINT32 tmpReadAddr = 0;
    T_Log tempLog = {0};

    LogPrintf("current Log Number is:%d\r\n",stLogCtrlBlock.LogCurrNum);
    tmpReadAddr = stLogCtrlBlock.LogReadAddr;
    for (UINT32 i = 0; i < stLogCtrlBlock.LogCurrNum; i++)
    {
        if (tmpReadAddr >= stLogCtrlBlock.LogEndAddr)
        {
            tmpReadAddr = stLogCtrlBlock.LogStartAddr;
        }
        stLogCtrlBlock.ReadFun((BYTE*)&tempLog, tmpReadAddr, sizeof(T_Log));
        LogShow(tempLog);
        tmpReadAddr += stLogCtrlBlock.LogAlignLenth;
    }

    return COMMON_OK;
}

UINT32 LogParaQuery(VOID)
{
    LogPrintf("LogTotalNum:%d\r\n",stLogCtrlBlock.LogTotalNum);
    LogPrintf("LogCurrNum:%d\r\n",stLogCtrlBlock.LogCurrNum);
    LogPrintf("LogCtrlBlockAddr:0x%x\r\n",stLogCtrlBlock.LogCtrlBlockAddr);
    LogPrintf("LogStartAddr:0x%x\r\n",stLogCtrlBlock.LogStartAddr);
    LogPrintf("LogEndAddr:0x%x\r\n",stLogCtrlBlock.LogEndAddr);
    LogPrintf("LogLenth:%d\r\n",stLogCtrlBlock.LogLenth);
    LogPrintf("LogAlignLenth:%d\r\n",stLogCtrlBlock.LogAlignLenth);
    LogPrintf("LogSectorLenth:%d\r\n",stLogCtrlBlock.LogSectorLenth);
    LogPrintf("LogWriteAddr:0x%x\r\n",stLogCtrlBlock.LogWriteAddr);
    LogPrintf("LogReadAddr:0x%x\r\n",stLogCtrlBlock.LogReadAddr);

    return COMMON_OK;
}

/*****************************************************************************
 * 版权所�?(C) 2017, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * �? �? �? : softlib
 * 文件名称 : cmdline.c
 * 文件标识 : {[N/A]}
 * 内�?�摘�? : �?文件提供了命令�?�功能的源文�?
 * 注意事项 : �?
 * �?    �? : 宋�??
 * 创建日期 : 2017-10-30
 * 当前版本 : V1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * �? �? �?: $0000000(N/A)
 * �? �? �?: 宋�??
 * �?改日�?: 2017-10-30
 * 变更说明: 创建
 *----------------------------------------------------------------------------
 */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include "cmdline.h"
#include "common.h"
#include "uartprint.h"
//*****************************************************************************
//
// Defines the maximum number of arguments that can be parsed.
//
//*****************************************************************************
#ifndef CMDLINE_MAX_ARGS
#define CMDLINE_MAX_ARGS        20
#endif


static T_CmdCtrBlk tCmdCtrBlk;

//static uint32_t g_32Base = UART6;
static uint32_t g_32Base = UART4;

//*****************************************************************************
//
// An array to hold the pointers to the command line arguments.
//
//*****************************************************************************
static char *g_ppcArgv[CMDLINE_MAX_ARGS + 1];

static uint32_t cmdLockStatus = 0;

extern tCmdLineEntry g_psCmdTable[];

//*****************************************************************************
//
//! Process a command line string into arguments and execute the command.
//!
//! \param pcCmdLine points to a string that contains a command line that was
//! obtained by an application by some means.
//!
//! This function will take the supplied command line string and break it up
//! into individual arguments.  The first argument is treated as a command and
//! is searched for in the command table.  If the command is found, then the
//! command function is called and all of the command line arguments are passed
//! in the normal argc, argv form.
//!
//! The command table is contained in an array named <tt>g_psCmdTable</tt>
//! containing <tt>tCmdLineEntry</tt> structures which must be provided by the
//! application.  The array must be terminated with an entry whose \b pcCmd
//! field contains a NULL pointer.
//!
//! \return Returns \b CMDLINE_BAD_CMD if the command is not found,
//! \b CMDLINE_TOO_MANY_ARGS if there are more arguments than can be parsed.
//! Otherwise it returns the code that was returned by the command function.
//
//*****************************************************************************
int CmdLineProcess(char *pcCmdLine)
{
    char *pcChar;
    uint_fast8_t ui8Argc;
    bool bFindArg = true;
    tCmdLineEntry *psCmdEntry;

    //
    // Initialize the argument counter, and point to the beginning of the
    // command line string.
    //
    ui8Argc = 0;
    pcChar = pcCmdLine;

    //
    // Advance through the command line until a zero character is found.
    //
    while(*pcChar)
    {
        //
        // If there is a space, then replace it with a zero, and set the flag
        // to search for the next argument.
        //
        if ((*pcChar == ' ')||(*pcChar == ','))   //mod by sf,20171010
        {
            *pcChar = 0;
            bFindArg = true;
        }

        //
        // Otherwise it is not a space, so it must be a character that is part
        // of an argument.
        //
        else
        {
            //
            // If bFindArg is set, then that means we are looking for the start
            // of the next argument.
            //
            if(bFindArg)
            {
                //
                // As long as the maximum number of arguments has not been
                // reached, then save the pointer to the start of this new arg
                // in the argv array, and increment the count of args, argc.
                //
                if(ui8Argc < CMDLINE_MAX_ARGS)
                {
                    g_ppcArgv[ui8Argc] = pcChar;
                    ui8Argc++;
                    bFindArg = false;
                }

                //
                // The maximum number of arguments has been reached so return
                // the error.
                //
                else
                {
                    return(CMDLINE_TOO_MANY_ARGS);
                }
            }
        }

        //
        // Advance to the next character in the command line.
        //
        pcChar++;
    }

    //
    // If one or more arguments was found, then process the command.
    //
    if(ui8Argc)
    {
        //
        // Start at the beginning of the command table, to look for a matching
        // command.
        //
        psCmdEntry = &g_psCmdTable[0];

        //
        // Search through the command table until a null command string is
        // found, which marks the end of the table.
        //
        while(psCmdEntry->pcCmd)
        {
            //
            // If this command entry command string matches argv[0], then call
            // the function for this command, passing the command line
            // arguments.
            //
            if(!strcmp(g_ppcArgv[0], psCmdEntry->pcCmd))
            {
                return(psCmdEntry->pfnCmd(ui8Argc, g_ppcArgv));
            }

            //
            // Not found, so advance to the next entry.
            //
            psCmdEntry++;
        }
    }

    //
    // Fall through to here means that no matching command was found, so return
    // an error.
    //
    return(CMDLINE_BAD_CMD);
}

//*****************************************************************************
//
// read command line into buffer, Add by sf,20171009
//
//*****************************************************************************
int32_t readline_into_buffer (int8_t * buffer)
{
    int8_t * buffer_begin = buffer;
    int8_t input_char;
    int32_t input_len = 0;

    while(1)
    {
        if (UARTCharsAvail(g_32Base))
        {
            input_char = UARTCharGetNonBlocking(g_32Base);

            /* Special character handling*/
            switch (input_char)
            {
                case '\r':    /* Enter*/
                case '\n':
                {
                    UARTCharPutNonBlocking(g_32Base,'\n');
                    UARTCharPutNonBlocking(g_32Base,'\r');
                    if (input_len == 0)
                    {
                        CmdLineUartprintf(CONSOLE_PROMPT);
                    }
                    *buffer = '\0';
                    return (buffer-buffer_begin);
                }
                case 8: /* Backspace*/
                {
                    input_len--;
                    if (input_len < 0)
                    {
                        input_len = 0;
                        continue;
                    }
                    else
                    {
                        CmdLineUartprintf("\b \b");
                        buffer--;
                        *buffer = 0;
                    }
                    break;
                }
                default:
                {
                    /* Must be a normal character then */
                    UARTCharPutNonBlocking(g_32Base,input_char);
                    *buffer = input_char;
                    buffer++;
                    input_len++;
                    if (input_len > CONFIG_COMMAND_LEN)
                    {
                            CmdLineUartprintf("Input Command too Long!\n");
                            return -1;
                    }
                }
            }
        }
    }
}

//*****************************************************************************
//
// read command line into buffer, Add by 10294149,202103
//
//*****************************************************************************
int32_t readline_into_buffer_interrupt (int8_t * buffer, int32_t *buffer_len)
{
    UINT32 i;
    int8_t input_char;

    input_char = usart_data_receive(g_32Base);

    /* Special character handling*/
    switch (input_char)
    {
        case '\r':    /* Enter*/
        case '\n':
        {
            UARTCharPutNonBlocking(g_32Base,'\n');
            UARTCharPutNonBlocking(g_32Base,'\r');
            if (*buffer_len == 0)
            {

                CmdLineUartprintf(CONSOLE_PROMPT);
            }
            else
            {
                CmdRecordLine((CHAR*)buffer,(UINT32*)buffer_len);
            }
            buffer[*buffer_len] = '\0';
            return (*buffer_len);
        }
        case 8: /* Backspace*/
        {
            (*buffer_len)--;
            if (*buffer_len < 0)
            {
                *buffer_len = 0;
            }
            else
            {
                CmdLineUartprintf("\b \b");
                buffer[*buffer_len] = 0;
            }
            return -1;
        }
        case 0x1b:
        case 0x5b:
        {
            return -1;
        }
        case 0x41: /* UP */
        {
            if( *buffer_len != 0 )
            {
                for(i = 0; i < *buffer_len; i++)
                {
                    CmdLineUartprintf("\b \b");
                }
            }
            CmdGetRecordLine((CHAR*)buffer,(UINT32*)buffer_len,E_DIR_UP);
            CmdLineUartprintf("%s",buffer);
            return -1;
        }
        case 0x42: /* DOWN */
        {
            if( *buffer_len != 0 )
            {
                for(i = 0; i < *buffer_len; i++)
                {
                    CmdLineUartprintf("\b \b");
                }
            }
            CmdGetRecordLine((CHAR*)buffer,(UINT32*)buffer_len,E_DIR_DOWN);
            CmdLineUartprintf("%s",buffer);
            return -1;
        }
        default:
        {

            UARTCharPutNonBlocking(g_32Base,input_char);
            buffer[*buffer_len] = input_char;
            (*buffer_len)++;

            if (*buffer_len > CONFIG_COMMAND_LEN)
            {
                  *buffer_len = 0;
                    CmdLineUartprintf("Input Command too Long!\n");
                    return -1;
            }
            return -1;
        }
    }
}

void prnCmdlineLogo(void)
{
    CmdLineUartprintf("\n");
    CmdLineUartprintf("**********************************************\n");
    CmdLineUartprintf("**     Welcome to use command line.        ***\n");
    CmdLineUartprintf("**     Author: songfei                     ***\n");
    CmdLineUartprintf("**     Version: v1.0                       ***\n");
    CmdLineUartprintf("**     Build time: 20191101                ***\n");
    CmdLineUartprintf("**********************************************\n");

    if (cmdLockStatus == 1)
    {
        CmdLineUartprintf(CMD_LOCK_INFO);
    }
}


void CmdlineProcess(void)
{
    int8_t console_buffer[CONFIG_COMMAND_LEN + 1];
    int8_t iLen,iRet;

    memset(console_buffer, 0, CONFIG_COMMAND_LEN+1);

    iLen = readline_into_buffer(console_buffer);
    if (iLen > 0)
    {
        iRet = CmdLineProcess((char *)console_buffer);
        if (iRet < 0)
        {
            CmdLineUartprintf("Error: Bad Command!\n");
        }
    }
}

void CmdlineProcessFromInt(void)
{
    static int8_t console_buffer[CONFIG_COMMAND_LEN + 1];
    static int32_t console_buffer_len = 0;
  int32_t iLen,iRet;

    iLen = readline_into_buffer_interrupt(console_buffer, &console_buffer_len);
    if (iLen >= 0)
    {
        if (iLen != 0)
        {
            iRet = CmdLineProcess((char *)console_buffer);
            if (iRet < 0)
            {
                CmdLineUartprintf("Error: Bad Command!\n");
            }
        }
        memset(console_buffer, 0, CONFIG_COMMAND_LEN+1);
        console_buffer_len = 0;
    }
}



UINT32 CmdLineInit(VOID)
{
    UINT32 i;

    tCmdCtrBlk.ucWrIndex = 0;
    tCmdCtrBlk.ucRdIndex = 0;
    for(i = 0; i < RECORD_CMD_ARR_SIZE; i++)
    {
        memset(&tCmdCtrBlk.aCmdArr[i],'\0',RECORD_CDM_LEN);
    }

    return COMMON_OK;
}


UINT32 CmdRecordLine(CHAR *CmdBuffer, UINT32 *CmdbufferLen)
{
    INPUT_POINTER_CHECK(CmdBuffer);
    INPUT_POINTER_CHECK(CmdbufferLen);

    memset(tCmdCtrBlk.aCmdArr[tCmdCtrBlk.ucWrIndex],'\0',RECORD_CDM_LEN);
    strncpy(tCmdCtrBlk.aCmdArr[tCmdCtrBlk.ucWrIndex],CmdBuffer,*CmdbufferLen);
    tCmdCtrBlk.ucWrIndex++;
    tCmdCtrBlk.ucRdIndex = tCmdCtrBlk.ucWrIndex;

    if( tCmdCtrBlk.ucWrIndex >= RECORD_CMD_ARR_SIZE )
    {
        tCmdCtrBlk.ucWrIndex = 0;
    }

    return COMMON_OK;
}

UINT32 CmdGetRecordLine(CHAR *CmdBuffer, UINT32 *CmdbufferLen, E_DIR eDir)
{
    INPUT_POINTER_CHECK(CmdBuffer);
    INPUT_POINTER_CHECK(CmdbufferLen);

    /* up read */
    if( eDir == E_DIR_UP )
    {
        if( tCmdCtrBlk.ucRdIndex == 0 )
        {
            tCmdCtrBlk.ucRdIndex = RECORD_CMD_ARR_SIZE - 1;
        }
        else
        {
            tCmdCtrBlk.ucRdIndex--;
        }

        strcpy(CmdBuffer,tCmdCtrBlk.aCmdArr[tCmdCtrBlk.ucRdIndex]);
        *CmdbufferLen = strlen(tCmdCtrBlk.aCmdArr[tCmdCtrBlk.ucRdIndex]);
    }
    else /*down read*/
    {
        tCmdCtrBlk.ucRdIndex++;

        if( tCmdCtrBlk.ucRdIndex >= RECORD_CMD_ARR_SIZE )
        {
            tCmdCtrBlk.ucRdIndex = 0;
        }

        strcpy(CmdBuffer,tCmdCtrBlk.aCmdArr[tCmdCtrBlk.ucRdIndex]);
        *CmdbufferLen = strlen(tCmdCtrBlk.aCmdArr[tCmdCtrBlk.ucRdIndex]);
    }

    return COMMON_OK;
}

UINT32 CmdGetLockStatus(VOID)
{
    return cmdLockStatus;
}
//*****************************************************************************
// End the cmdline.c
//*****************************************************************************

/*****************************************************************************
 * ç‰ˆæƒæ‰€æœ?(C) 2017, ZTE Corp. RRU Bsp Platform
 *----------------------------------------------------------------------------
 * æ¨? å? å? : softlib
 * æ–‡ä»¶åç§° : cmdline.c
 * æ–‡ä»¶æ ‡è¯† : {[N/A]}
 * å†…å?¹æ‘˜è¦? : æœ?æ–‡ä»¶æä¾›äº†å‘½ä»¤è?ŒåŠŸèƒ½çš„æºæ–‡ä»?
 * æ³¨æ„äº‹é¡¹ : æ—?
 * ä½?    è€? : å®‹é??
 * åˆ›å»ºæ—¥æœŸ : 2017-10-30
 * å½“å‰ç‰ˆæœ¬ : V1.0
 *----------------------------------------------------------------------------
 * å˜æ›´è®°å½• :
 *
 * $è®°å½•1
 * å? æ›? å?: $0000000(N/A)
 * è´? ä»? äº?: å®‹é??
 * ä¿?æ”¹æ—¥æˆ?: 2017-10-30
 * å˜æ›´è¯´æ˜: åˆ›å»º
 *----------------------------------------------------------------------------
 */

#ifndef __CMDLINE_H__
#define __CMDLINE_H__

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>
#include "typedef.h"

#define CONSOLE_PROMPT "->"
#define CONFIG_COMMAND_LEN 256

#define CMD_LOCK_INFO           "please type password:"

//*****************************************************************************
//
//! Defines the value that is returned if the command is not found.
//
//*****************************************************************************
#define CMDLINE_BAD_CMD         (-10001)

//*****************************************************************************
//
//! Defines the value that is returned if there are too many arguments.
//
//*****************************************************************************
#define CMDLINE_TOO_MANY_ARGS   (-10002)

//*****************************************************************************
//
//! Defines the value that is returned if there are too few arguments.
//
//*****************************************************************************
#define CMDLINE_TOO_FEW_ARGS   (-10003)

//*****************************************************************************
//
//! Defines the value that is returned if an argument is invalid.
//
//*****************************************************************************
#define CMDLINE_INVALID_ARG   (-10004)

//*****************************************************************************
//
// Command line function callback type.
//
//*****************************************************************************
typedef unsigned int (*pfnCmdLine)(int argc, char *argv[]);

//*****************************************************************************
//
//! Structure for an entry in the command list table.
//
//*****************************************************************************
typedef struct
{
    //
    //! A pointer to a string containing the name of the command.
    //
    const char *pcCmd;

    //
    //! A function pointer to the implementation of the command.
    //
    pfnCmdLine pfnCmd;

    //
    //! A pointer to a string of brief help text for the command.
    //
    const char *pcHelp;
}
tCmdLineEntry;

#define RECORD_CMD_ARR_SIZE  (8)
#define RECORD_CDM_LEN       (128)

typedef enum
{
    E_DIR_UP,
    E_DIR_DOWN,

}E_DIR;

typedef struct _CMD_CONTROL_BLOCK
{
    BYTE ucWrIndex;
    BYTE ucRdIndex;
    CHAR aCmdArr[RECORD_CMD_ARR_SIZE][RECORD_CDM_LEN];
}T_CmdCtrBlk;


//*****************************************************************************
//
//! This is the command table that must be provided by the application.  The
//! last element of the array must be a structure whose pcCmd field contains
//! a NULL pointer.
//
//*****************************************************************************
extern tCmdLineEntry g_psCmdTable[];

//*****************************************************************************
//
// Prototypes for the APIs.
//
//*****************************************************************************
extern int CmdLineProcess(char *pcCmdLine);
extern int32_t readline_into_buffer (int8_t * buffer);
extern void prnCmdlineLogo(void);

void CmdlineProcess(void);
void CmdlineProcessFromInt(void);

UINT32 CmdLineInit(VOID);
UINT32 CmdRecordLine(CHAR *CmdBuffer, UINT32 *CmdbufferLen);
UINT32 CmdGetRecordLine(CHAR *CmdBuffer, UINT32 *CmdbufferLen, E_DIR eDir);
UINT32 CmdGetLockStatus(VOID);
//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif // __CMDLINE_H__

./CMSIS/:     通用标准软件接口
./GD32F4xx_standard_peripheral/:   外设驱动库

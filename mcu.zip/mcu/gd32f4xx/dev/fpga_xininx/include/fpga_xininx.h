/************************************************/
/**
 * \file fpga_xininx.h
 * \brief fpga_xininx
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#ifndef _FPGA_XININX_H
#define _FPGA_XININX_H

#include "typedef.h"

#define FPGA_XININX_NUM        (2)
#define FPGA_SPI_CHANNEL_NUM   (8)

typedef VOID   (*FPGA_XININX_CS_CTRL_FUNC)(BYTE status);
typedef UINT32 (*FPGA_XININX_WRITE_FUNC)( UINT32 ulPeriIndex, BYTE *sendBuffer, UINT32 lenth);
typedef UINT32 (*FPGA_XININX_READ_FUNC)( UINT32 ulPeriIndex, BYTE *sendBuffer, UINT32 lenth);

typedef VOID   (*FPGA_XININX_SET_PROB_PIN_FUNC)(BYTE pinValue);
typedef BYTE   (*FPGA_XININX_GET_INIT_PIN_FUNC)(VOID);
typedef BYTE   (*FPGA_XININX_GET_DONE_PIN_FUNC)(VOID);
typedef VOID   (*FPGA_XININX_LOAD_BIN_FUNC)(UINT32 Addr);

typedef VOID   (*SPI_FPGA_CS_CONTROL_FUNC)(BYTE status);
typedef UINT32 (*SPI_FPGA_WRITE_READ_FUNC)( UINT32 ulPeriIndex, UINT16 *sendBuffer, UINT16 *recvBuffer, UINT32 lenth);

typedef struct _T_FpgaXininx_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    FPGA_XININX_CS_CTRL_FUNC pFunCsCtrl;
    FPGA_XININX_WRITE_FUNC   pFunWriteData;
    FPGA_XININX_READ_FUNC    pFunReadData;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_FpgaXininx_Dev;

typedef struct _T_FpgaXininxLoad_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    UINT32 ulVerDownLoadAddr;
    FPGA_XININX_CS_CTRL_FUNC pFunCsCtrl;
    FPGA_XININX_WRITE_FUNC   pFunWriteData;
    FPGA_XININX_READ_FUNC    pFunReadData;
    FPGA_XININX_SET_PROB_PIN_FUNC pFunSetProbPin;
    FPGA_XININX_GET_INIT_PIN_FUNC pFunGetInitPin;
    FPGA_XININX_GET_DONE_PIN_FUNC pFunGetDonePin;
    FPGA_XININX_LOAD_BIN_FUNC pFunLoadBin;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_FpgaXininxLoad_Dev;

typedef struct _T_Fpga_Spi_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    SPI_FPGA_CS_CONTROL_FUNC pFunControlCs;
    SPI_FPGA_WRITE_READ_FUNC   pFunWriteReadData;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_Fpga_Spi_Dev;

VOID zxDRV_FpgaInit(UINT32 index, T_FpgaXininx_Dev ptFpgaXininxDev);
VOID InitEpldLoad(UINT32 index, T_FpgaXininxLoad_Dev ptFpgaXininxLoadDev);
VOID zxDRV_FpgaSpiInit(UINT32 index, T_Fpga_Spi_Dev ptFpgaSpiDev);
UINT32 zxDRV_FpgaXininxWrReg(UINT32 ulDevIndex, UINT32 addr, UINT16 value);
UINT32 zxDRV_FpgaXininxWrRegWithMask(UINT32 ulDevIndex, UINT32 addr, UINT16 value, UINT16 mask);
UINT32 zxDRV_FpgaXininxRdReg(UINT32 ulDevIndex, UINT32 addr, UINT16 *value);
UINT32 zxDRV_FpgaSpiComm(UINT32 ulDevIndex, UINT16 *sendBuffer, UINT16 *recvBuffer, UINT32 lenth);
VOID testRdFlashSta();
UINT32 PangoSpiRdIdFlag();
UINT32 LoadPangoEpldVer();
VOID PangoSpiDataRd(UINT32 page);
VOID PangoSpiWriteTest(UINT32 length);
VOID zxDRV_DelayNms(UINT32 count);
VOID HalFlashRead(UINT32 addr, UCHAR *pucBuf, UINT32 length);
VOID HalDisableInt(UINT32 uartId, UINT32 interrupt);
VOID HalEnableInt(UINT32 uartId, UINT32 interrupt);
#endif

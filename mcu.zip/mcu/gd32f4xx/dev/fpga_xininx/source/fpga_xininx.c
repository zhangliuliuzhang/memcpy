/************************************************/
/**
 * \file fpga_xininx.c
 * \brief pga_xininx FPGA驱动
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include <string.h>
#include "fpga_xininx.h"
#include "common.h"
#include "utils.h"
#include "uartprint.h"
#include "uart_ook.h"

static T_FpgaXininx_Dev s_atFpgaXininxDev[FPGA_XININX_NUM] = {0};
static T_FpgaXininxLoad_Dev s_atFpgaLoadDev[FPGA_XININX_NUM] = {0};
static T_Fpga_Spi_Dev s_atFpgaSpiDev[FPGA_SPI_CHANNEL_NUM] = {0};

/**********************************************************************/
/**
* \brief 实例抽象对象
  *
  * \param index: 器件抽象结构体
  * \param ptFpgaXininxDev: 器件抽象结构体
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_FpgaInit(UINT32 index, T_FpgaXininx_Dev ptFpgaXininxDev)
{
    s_atFpgaXininxDev[index] = ptFpgaXininxDev;
}

/**********************************************************************/
/**
* \brief 实例抽象对象
  *
  * \param index: 器件编号
  * \param ptFpgaXininxLoadDev: 器件抽象结构体
  *
  * \retval null
  */
/**********************************************************************/
VOID InitEpldLoad(UINT32 index, T_FpgaXininxLoad_Dev ptFpgaXininxLoadDev)
{
    s_atFpgaLoadDev[index] = ptFpgaXininxLoadDev;
}

/**********************************************************************/
/**
* \brief 实例抽象对象
  *
  * \param index:器件编号
  * \param ptFpgaXininxLoadDev: 器件抽象结构体
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_FpgaSpiInit(UINT32 index, T_Fpga_Spi_Dev ptFpgaSpiDev)
{
    s_atFpgaSpiDev[index] = ptFpgaSpiDev;
}

/**********************************************************************/
/**
* \brief 写FPGA的逻辑寄存器
  *
  * \param ulDevIndex: 器件编号
  * \param addr: 寄存器地址
  * \param value: 寄存器值
  *
  * \retval null
  */
/**********************************************************************/
UINT32 zxDRV_FpgaXininxWrReg(UINT32 ulDevIndex, UINT32 addr, UINT16 value)
{
    UINT32 ret = 0;
    BYTE ucSendData[6] = {0};
    T_FpgaXininx_Dev *ptFpgaXininxDev;

    ptFpgaXininxDev = &s_atFpgaXininxDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptFpgaXininxDev);

    ucSendData[0] = (BYTE)(((addr >> 15) & 0x7f));
    ucSendData[1] = (BYTE)(((addr >> 7) & 0xff));
    ucSendData[2] = (BYTE)(((addr & 0x7f) << 1));
    ucSendData[3] = 0x0;
    ucSendData[4] = (BYTE)(((value >> 8) & 0xff));
    ucSendData[5] = (BYTE)((value & 0xff));

    ptFpgaXininxDev->pFunCsCtrl(E_RESET);
    ret = ptFpgaXininxDev->pFunWriteData(ptFpgaXininxDev->ulPeriIndex, ucSendData, 6);
    ptFpgaXininxDev->pFunCsCtrl(E_SET);

    return ret;
}

/**********************************************************************/
/**
* \brief 写FPGA的逻辑寄存器
  *
  * \param ulDevIndex:器件编号
  * \param addr: 寄存器地址
  * \param value: 寄存器值
  *
  * \retval null
  */
/**********************************************************************/
UINT32 zxDRV_FpgaXininxWrRegWithMask(UINT32 ulDevIndex, UINT32 addr, UINT16 value, UINT16 mask)
{
    UINT16 regValue = 0;

    zxDRV_FpgaXininxRdReg(ulDevIndex, addr, &regValue);

    regValue &= (~mask);
    regValue |= value;

    zxDRV_FpgaXininxWrReg(ulDevIndex, addr, regValue);

    return COMMON_OK;
}

/**********************************************************************/
/**
* \brief 读FPGA的逻辑寄存器
  *
  * \param ulDevIndex: 器件编号
  * \param addr: 寄存器地址
  * \param value: 寄存器值
  *
  * \retval null
  */
/**********************************************************************/
UINT32 zxDRV_FpgaXininxRdReg(UINT32 ulDevIndex, UINT32 addr, UINT16 *value)
{
    UINT32 ret = 0;
    BYTE ucSendData[4] = {0};
    BYTE ucRecvData[2] = {0};
    T_FpgaXininx_Dev *ptFpgaXininxDev;

    ptFpgaXininxDev = &s_atFpgaXininxDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptFpgaXininxDev);

    ucSendData[0] = (BYTE)(((addr >> 15) & 0x7f) | 0x80);
    ucSendData[1] = (BYTE)(((addr >> 7) & 0xff));
    ucSendData[2] = (BYTE)(((addr & 0x7f) << 1));
    ucSendData[3] = 0x0;

    if(ptFpgaXininxDev->pFunCsCtrl == NULL)
    {
        UARTprintf("POINT NULL!\n");
        return COMMON_ERROR;
    }

    if(ptFpgaXininxDev->pFunWriteData == NULL)
    {
        UARTprintf("pFunWriteData POINT NULL!\n");
        return COMMON_ERROR;
    }

    if(ptFpgaXininxDev->pFunReadData == NULL)
    {
        UARTprintf("pFunReadData POINT NULL!\n");
        return COMMON_ERROR;
    }

    ptFpgaXininxDev->pFunCsCtrl(E_RESET);
    ret = ptFpgaXininxDev->pFunWriteData(ptFpgaXininxDev->ulPeriIndex, ucSendData, 4);
    ret |= ptFpgaXininxDev->pFunReadData(ptFpgaXininxDev->ulPeriIndex, ucRecvData, 2);
    ptFpgaXininxDev->pFunCsCtrl(E_SET);

    *value = (UINT16)((ucRecvData[0] << 8) | ucRecvData[1]);

    return ret;
}

/**********************************************************************/
/**
* \brief 写FPGA的逻辑寄存器
  *
  * \param ulDevIndex: 器件编号
  *
  * \retval null
  */
/**********************************************************************/
#define PGC_ID                               0x899
/*****************紫光 PGC7KD CPLD*********************/
#define PANGO_BYTES_PER_PAGE            (256)
#define PANGO_PAGES_PER_HEAP            (452)
#define PANGO_TOTAL_PAGE                (1808)
#define     PANGO_BYTES_PER_PAGE        (256)     /*flash一页最大256字节*/
#define     PANGO_CMD_ADD_LEN           (4)
#define     PANGO_7KD_BAK_BASE_ADDR         (891)
#define     PG_PROGRAM                      (0x20)        /*  配置页  */

/* 紫光PANGO芯片专用定义 */
/*从SPI指令集*/
#define PG_NOP                               0xFF        /* No Operation                           */
#define PG_READ                              0x30        /* Readback Configuration Memory/Register */
#define PG_RDID                              0xA1        /* Read Identification                    */
#define PG_RDSR                              0xA3        /* Read Status Register                   */
#define PG_CONFIGBIT                         0x50        /* Config Bitstream                       */
#define PG_WREN                              0x51        /* Write Enable                           */
#define PG_WRDIS                             0x52        /* Write Disable                          */
#define PG_ERASE                             0x10        /* Reset FPGA                             */
#define PG_EFlash_SLEEP                      0x70
#define PG_EFlash_WAKEUP                     0x71
#define PG_PROGRAM_UID                       0x21
#define PG_RDUID                             0xA4
#define PG_RDLOCK                            0xA5
#define PG_READ_CTL                          0x31
#define PG_ERASE_CTL                         0x12
#define PG_ERASE_PAGE                        0x11
#define PG_PROGRAM_CTL                       0x22
#define PG_RESET                             0x60
#define PG_PROGRAM_LOCK                      0x40
#define PANGO_CS_CMD                    (0x99)

static VOID PangoSpiSendByteData(UINT8 data)
{
    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[0];
    ptEpldLoadDev->pFunWriteData(ptEpldLoadDev->ulPeriIndex, &data, 1);
}

static UINT8 ReverseByte(UINT8 byte)
{
    if ((byte == 0xFF) || (byte == 0x00))
    {
        //It's very common for BitStream data to have 0xFF and 0x00
        return byte;
    }

    byte = (byte & 0x55) << 1 | (byte & 0xAA) >> 1;
    byte = (byte & 0x33) << 2 | (byte & 0xCC) >> 2;
    byte = (byte & 0x0F) << 4 | (byte & 0xF0) >> 4;

    return byte;
}

/*BSP_OK:唤醒状态；BSP_ERROR:休眠状态*/
static UINT32 IsPangoWakeUp(UINT32 rdVal)
{
    if ((rdVal & BIT_SET(19)) != 0)
    {
        return COMMON_OK;
    }
    else
    {
        return COMMON_ERROR;
    }
}

/*COMMON_OK:空闲状态  COMMON_ERROR:忙碌状态*/
static UINT32 IsPangoNotBusy(UINT32 rdVal)
{
    if ((rdVal & BIT_SET(21)) == 0)
    {
        return COMMON_OK;
    }
    else
    {
        return COMMON_ERROR;
    }
}

static UINT32 PangoSpiRdFlashSta(UINT32 index)
{
    UINT8 readTemp[4] = {0};
    UINT32 flashSta = 0;
    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[index];

    ptEpldLoadDev->pFunCsCtrl(E_RESET);

    PangoSpiSendByteData(PG_RDSR);
    PangoSpiSendByteData(PG_NOP);
    PangoSpiSendByteData(PG_NOP);
    PangoSpiSendByteData(PG_NOP);

    ptEpldLoadDev->pFunReadData(ptEpldLoadDev->ulPeriIndex, readTemp, 4);
    ptEpldLoadDev->pFunCsCtrl(E_SET);

    PangoSpiSendByteData(PG_NOP);
    PangoSpiSendByteData(PG_NOP);

    readTemp[0] = ReverseByte(readTemp[0]);
    readTemp[1] = ReverseByte(readTemp[1]);
    readTemp[2] = ReverseByte(readTemp[2]);
    readTemp[3] = ReverseByte(readTemp[3]);

    flashSta = (readTemp[3]<<24) | (readTemp[2]<<16) | (readTemp[1]<<8) | (readTemp[0]);

    return flashSta;
}

VOID testRdFlashSta()
{
    UINT32 data = 0;

    data = PangoSpiRdFlashSta(0);

    UARTprintf("test ww data = 0x%x\n", data);
}

static VOID PangoSpiSendByteCommand(UINT32 index, UINT8 cmdAddr)
{
    UINT8 waitData = 0xff;
    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[index];
    ptEpldLoadDev->pFunCsCtrl(E_RESET);
    ptEpldLoadDev->pFunWriteData(ptEpldLoadDev->ulPeriIndex, &cmdAddr, 1);
    ptEpldLoadDev->pFunCsCtrl(E_SET);

    ptEpldLoadDev->pFunWriteData(ptEpldLoadDev->ulPeriIndex, &waitData, 1);/*所有指令之间，当CS拉高时，需要至少给1个时钟*/
}

UINT32 PangoSpiRdIdFlag()
{
    UCHAR readTemp[4] = {0,};
    UINT32 idFlag = 0xffffffff;
    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[0];
    ptEpldLoadDev->pFunCsCtrl(1);
    PangoSpiSendByteData(PG_NOP);            /*所有指令之间，当CS拉高时，需要至少给1个时钟*/

    ptEpldLoadDev->pFunCsCtrl(0);

    PangoSpiSendByteData(PG_RDID);
    PangoSpiSendByteData(PG_NOP);
    PangoSpiSendByteData(PG_NOP);
    PangoSpiSendByteData(PG_NOP);

    ptEpldLoadDev->pFunReadData(ptEpldLoadDev->ulPeriIndex, readTemp, 4);

    readTemp[0] = ReverseByte(readTemp[0]);
    readTemp[1] = ReverseByte(readTemp[1]);
    readTemp[2] = ReverseByte(readTemp[2]);
    readTemp[3] = ReverseByte(readTemp[3]);

    ptEpldLoadDev->pFunCsCtrl(1);

    PangoSpiSendByteData(PG_NOP);
    PangoSpiSendByteData(0);

    idFlag = (readTemp[3]<<24)|(readTemp[2]<<16)|(readTemp[1]<<8)|(readTemp[0]);

    return idFlag;
}

static UINT32 BspCheckPangoId()
{
    UINT32 loop = 0;
    UINT32 idFlag = 0;
    UINT32 ret = COMMON_ERROR;

    for(loop = 0; loop < 5; loop++)
    {
        idFlag = PangoSpiRdIdFlag();
        UARTprintf("pango id = 0x%x\n", idFlag);
        idFlag = idFlag & 0xfff;

        if(idFlag == PGC_ID)
        {
            ret = COMMON_OK;
            break;
        }
    }

    return ret;
}

static VOID PangoSpiWriteEnable(UINT32 index)
{
    PangoSpiSendByteCommand(index, PG_WREN);
}

static VOID PangoSpiEflashWakeUp(UINT32 index)
{
    PangoSpiSendByteCommand(index, PG_EFlash_WAKEUP);
}

static VOID PangoSpiReset(UINT32 index)
{
    PangoSpiSendByteCommand(index, PG_RESET);
}

static UINT32 PangoSpiFlashWakeUp(UINT32 index)
{
    UINT32 flashState = 0;
    UINT32 loop = 0;

    PangoSpiWriteEnable(index);
    flashState = PangoSpiRdFlashSta(index);
    UARTprintf("flashState = 0x%x\n", flashState);

    if ((IsPangoNotBusy(flashState) == COMMON_OK) && (IsPangoWakeUp(flashState) != COMMON_OK))
    {
        PangoSpiEflashWakeUp(index);
        UARTprintf("wake up pango flash!\r\n");
        for(loop = 0; loop < 3; loop++)
        {
            flashState = PangoSpiRdFlashSta(index);
            if (IsPangoNotBusy(flashState) == COMMON_OK)
            {
                break;
            }
            zxDRV_DelayNms(1);//延时200us，后面找函数
        }

        if ((IsPangoNotBusy(flashState) != COMMON_OK) && (loop == 3))
        {
            UARTprintf("wake up pango err!\r\n");
            return COMMON_ERROR;
        }
        UARTprintf("wake up pango succ!\r\n");
    }

    zxDRV_DelayNms(10);
    return COMMON_OK;
}

static VOID PangoSpiDataWrite(UINT32 index, UINT8 *data, UINT32 lenth)
{
    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[index];

    ptEpldLoadDev->pFunCsCtrl(E_RESET);
    ptEpldLoadDev->pFunWriteData(ptEpldLoadDev->ulPeriIndex, data, lenth);
    ptEpldLoadDev->pFunCsCtrl(E_SET);
    PangoSpiSendByteData(PG_NOP);
}


static UINT32 BspGetPangoFlashAddr(UINT32 pageNum)
{
    UINT32 addr      = 0;
    UINT32 page      = 0;

    if(pageNum > PANGO_TOTAL_PAGE)
    {
        UARTprintf("Warning : Input Page Num[%d] is Larger Than Total Page Num!\n", pageNum);
        page = PANGO_TOTAL_PAGE;
    }
    else
    {
        page = pageNum;
    }
    addr |= ((page / PANGO_PAGES_PER_HEAP) & 0x3) << 17; //当前页在哪一个堆上
    addr |= ((page % PANGO_PAGES_PER_HEAP) & 0x1ff) << 8; //当前是哪一页
    addr |= 0; //当前页的初始地址

    return addr;
}

VOID PangoSpiDataRd(UINT32 page)
{
    UINT32 baseAddr = 0;
    UINT32 addr = 0;
    UINT32 ret = 0;
    UINT8  readData[PANGO_BYTES_PER_PAGE]  = {0};
    UINT8 sendData[8] = {0,};
    UINT32 j = 0;
    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[0];

    ret = PangoSpiFlashWakeUp(0);     //唤醒SPI
    if(ret == COMMON_ERROR)
    {
        UARTprintf("Pango Flash Busy!\n");
    }

    baseAddr = page + PANGO_7KD_BAK_BASE_ADDR; //7K的双boot基地址从891开始
    addr = BspGetPangoFlashAddr(baseAddr);//7K从891开始

    sendData[0] = PG_READ;
    sendData[1] = (addr >> 16) & 0xff;
    sendData[2] = (addr >> 8)  & 0xff;
    sendData[3] = (addr >> 0)  & 0xff;


    ptEpldLoadDev->pFunCsCtrl(E_RESET);

    ptEpldLoadDev->pFunWriteData(ptEpldLoadDev->ulPeriIndex,sendData, 8);

    ptEpldLoadDev->pFunReadData(ptEpldLoadDev->ulPeriIndex, readData, 256);

    ptEpldLoadDev->pFunCsCtrl(1);

    UARTprintf("rev findish!\n");
    UARTprintf("sendData[1] = 0x%x!\n",sendData[1]);
    UARTprintf("sendData[2] = 0x%x!\n",sendData[2]);
    UARTprintf("sendData[3] = 0x%x!\n",sendData[3]);

    for(j = 0; j < PANGO_BYTES_PER_PAGE; j++)
    {
        UARTprintf("0x%x  ", readData[j]);
        if(((j % 8) == 0) && (j != 0))
        {
            UARTprintf("\n");
        }
    }
    PangoSpiSendByteData(PG_NOP);
}

VOID PangoSpiDataRdCheck(UINT32 addr, UINT32 pageIndex)
{
    UINT32 loop = 0;
    UINT8  readData[PANGO_BYTES_PER_PAGE]  = {0};
    UINT8 sendData[8] = {0,};
    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[0];

    sendData[0] = PG_READ;
    sendData[1] = (addr >> 16) & 0xff;
    sendData[2] = (addr >> 8)  & 0xff;
    sendData[3] = (addr >> 0)  & 0xff;


    ptEpldLoadDev->pFunCsCtrl(E_RESET);

    ptEpldLoadDev->pFunWriteData(ptEpldLoadDev->ulPeriIndex,sendData, 8);

    ptEpldLoadDev->pFunReadData(ptEpldLoadDev->ulPeriIndex, readData, 256);

    ptEpldLoadDev->pFunCsCtrl(1);

    UARTprintf("***************READ page[%d]*****************\n", pageIndex);
    for(loop = 0; loop < PANGO_BYTES_PER_PAGE; loop++)
    {
        UARTprintf("0x%x  ", readData[loop]);
        if(((loop % 8) == 0) && (loop != 0))
        {
            UARTprintf("\n");
        }
    }
    UARTprintf("\n");
    PangoSpiSendByteData(PG_NOP);
}


static VOID PangoWriteDataToFlash(UINT32 length)
{

    UINT32 pageIndex = 0;
    UINT32 loop = 0;
    UINT32 baseAddr = 0;
    UINT32 addr        = 0;
    UINT32 flashBaseAddr = 0;
    UINT32 flahState = 0;
    UINT32 maxPage = length / PANGO_BYTES_PER_PAGE; //一共下发有多少页
    UINT8 leftBytes = length % PANGO_BYTES_PER_PAGE; //剩余多少字节，凑不够一整页的
    UINT8 writeData[PANGO_BYTES_PER_PAGE+PANGO_CMD_ADD_LEN] = {0};

    T_FpgaXininxLoad_Dev *ptEpldLoadDev;

    ptEpldLoadDev = &s_atFpgaLoadDev[0];
    flashBaseAddr = ptEpldLoadDev->ulVerDownLoadAddr;

    UARTprintf("EPLD flash maxPage = %d, leftByte = %d\n", maxPage, leftBytes);
    UARTprintf("write flash begin...\n");    //打印标志

    for(pageIndex = 0; pageIndex <= maxPage; pageIndex++)    //最外层的page循环
    {
        if(pageIndex != 0)
        {
            flashBaseAddr += PANGO_BYTES_PER_PAGE;
        }

        baseAddr = pageIndex + PANGO_7KD_BAK_BASE_ADDR;      //7K的双boot基地址从891开始,每次翻页，基地址+1
        addr = BspGetPangoFlashAddr(baseAddr);         //通过基地址换算出flash中的地址

        writeData[0] = PG_PROGRAM;              /*发送正式数据之前，先发送0x20 + addr 过去*/
        writeData[1] = (addr >> 16) & 0xff;
        writeData[2] = (addr >> 8)  & 0xff;
        writeData[3] = (addr >> 0)  & 0xff;

        if(pageIndex < maxPage)      /*非最后一页*/
        {
            HalFlashRead(flashBaseAddr, &writeData[PANGO_CMD_ADD_LEN], PANGO_BYTES_PER_PAGE);
        }
        else if(pageIndex == maxPage)    /*最后一页*/
        {
            if (0 == leftBytes)   /*刚好最后一页256字节*/
            {
                HalFlashRead(flashBaseAddr, &writeData[PANGO_CMD_ADD_LEN], PANGO_BYTES_PER_PAGE);
            }
            else if (0 < leftBytes)
            {
                HalFlashRead(flashBaseAddr, &writeData[PANGO_CMD_ADD_LEN], leftBytes);
            }
            else{}
        }
        else{}

        PangoSpiWriteEnable(0);   //开启flash写使能
        PangoSpiDataWrite(0, writeData, PANGO_BYTES_PER_PAGE+PANGO_CMD_ADD_LEN);   //发送数据
        memset(writeData, 0, PANGO_BYTES_PER_PAGE + PANGO_CMD_ADD_LEN);

        /*写完数据再进行状态判断*/
        for(loop = 0; loop < 10; loop++)
        {
            flahState = PangoSpiRdFlashSta(0);
            if((flahState & BIT_SET(21)) == 0)
            {
                break;
            }
            else
            {
                zxDRV_DelayNms(10);
            }
        }
    }

    UARTprintf("write flash end...\n");
    zxDRV_DelayNms(10);

}


VOID PangoSpiWriteTest(UINT32 length)
{
    PangoWriteDataToFlash(length);
}

UINT32 LoadPangoEpldVer()
{
    UINT32 length = 0;
    UINT32 ret = 0;

    length = BspGetFpgaLenth();
    HalDisableInt(UART3, USART_INT_IDLE);
    ret = BspCheckPangoId();         /*校验是否是紫光器件*/
    if(ret == COMMON_ERROR)
    {
        UARTprintf("Pango Epld Id Rd Err!\n");
        return COMMON_ERROR;
    }

    PangoSpiWriteEnable(0);
    ret = PangoSpiFlashWakeUp(0);     //唤醒SPI
    if(ret == COMMON_ERROR)
    {
        UARTprintf("Pango Epld WakeUp ERR!\n");
        return COMMON_ERROR;
    }

    PangoWriteDataToFlash(length);   //版本数据写入

    UARTprintf("reset epld!\n");
    PangoSpiReset(0);    //复位flash
    zxDRV_DelayNms(500);
    HalEnableInt(UART3, USART_INT_IDLE);
    //如果升级失败需要增加保护，将对应SPI恢复到透传模式下  ---这个步骤是否存在

    return COMMON_OK;
}

/**********************************************************************/
/**
* \brief 与FPGA的SPI通信
  *
  * \param ulDevIndex: 器件编号
  *
  * \retval null
  */
/**********************************************************************/
UINT32 zxDRV_FpgaSpiComm(UINT32 ulDevIndex, UINT16 *sendBuffer, UINT16 *recvBuffer, UINT32 lenth)
{
    T_Fpga_Spi_Dev *ptFpgaSpiDev;

    ptFpgaSpiDev = &s_atFpgaSpiDev[ulDevIndex];

    INPUT_POINTER_CHECK(sendBuffer);
    INPUT_POINTER_CHECK(recvBuffer);
    INPUT_POINTER_CHECK(ptFpgaSpiDev);

    ptFpgaSpiDev->pFunControlCs(E_RESET);

    ptFpgaSpiDev->pFunWriteReadData(ptFpgaSpiDev->ulPeriIndex, sendBuffer, recvBuffer, lenth);

    ptFpgaSpiDev->pFunControlCs(E_SET);

    return COMMON_OK;
}

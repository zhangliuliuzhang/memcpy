/************************************************/
/**
 * \file eeprom.c
 * \brief eeprom 驱动
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "amc7836.h"
#include "common.h"
#include "utils.h"
#include "uartprint.h"
#include "dh250.h"

#define AD_CALI_TIMES       (60)

static T_Amc7836_Dev s_atAmc7836Dev[AMC7836_NUM] = {0};
static UINT8 s_calitimes = AD_CALI_TIMES;
/**********************************************************************/
/**
* \brief 实例抽象对象
  *
  * \param index: 器件编号
  * \param ptAmc7836_Dev: 器件抽象结构体
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_Amc7836Init(UINT32 index, T_Amc7836_Dev ptAmc7836_Dev)
{
    s_atAmc7836Dev[index] = ptAmc7836_Dev;
}

/**********************************************************************/
/**
* \brief 读取器件ID
  *
  * \param index: 器件编号
  * \param id: 器件ID
  *
  * \retval null
  */
/**********************************************************************/
UINT32 zxDRV_Amc7836ReadChipId(UINT32 ulDevIndex, UINT16 *id)
{
    UINT16 ucTempH = 0;
    UINT16 ucTempL = 0;
    T_Amc7836_Dev *ptAmc7836_Dev;

    ptAmc7836_Dev = &s_atAmc7836Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_REG_CHIP_ID_HIGH | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_REG_CHIP_ID_LOW | AMC7836_CMD_RD, &ucTempL);

    *id = (ucTempH << 8) | ucTempL;

    return COMMON_OK;
}

/**********************************************************************/
/**
  * \brief 设置AMC7836 DAC输出
  *
  * \param ulDevIndex 器件索引
  * \param ucDacSel DAC输出引脚选择,范围0-15
  * \param ulVolt 需要设置的DAC寄存器值
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_Amc7836SetPaGridDac(UINT32 ulDevIndex, BYTE ucDacSel, INT32 usVolt)
{
    UINT16 usTmpRegVal  = 0;
    BYTE ucDacChal      = 0;
    UINT16 ucTempH      = 0;
    UINT16 ucTempL      = 0;
    T_Amc7836_Dev *ptAmc7836_Dev;

    ptAmc7836_Dev = &s_atAmc7836Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    ptAmc7836_Dev->pFunVoltSet(usVolt, &usTmpRegVal);

    ucDacChal = ucDacSel * 2;

    ucTempH = (usTmpRegVal >> 8) & 0xf;
    ucTempL = usTmpRegVal & 0xff;

    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_DAC_GRIDVOLT_HIGH + ucDacChal) | AMC7836_CMD_WR, ucTempH);
    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_DAC_GRIDVOLT_LOW + ucDacChal) | AMC7836_CMD_WR, ucTempL);

    zxUTILS_DelayNus(50);
    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_REG_UPDATA | AMC7836_CMD_WR, 1);

    return COMMON_OK;
}

/**********************************************************************/
/**
  * \brief 获取AMC7836 DAC电压值
  *
  * \param ulChipIndex 器件索引
  * \param ucDacSel DAC输出引脚选择,范围0-15
  * \param plDacVal 获取的电压值
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_Amc7836GetPaGridDac(UINT32 ulDevIndex, BYTE ucDacSel, INT32 *plDacValue)
{
    BYTE ucDacChal     = 0;
    UINT16 ucTempH     = 0;
    UINT16 ucTempL     = 0;
    UINT16 usTempData  = 0;
    T_Amc7836_Dev *ptAmc7836_Dev;

    ptAmc7836_Dev = &s_atAmc7836Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    ucDacChal = ucDacSel * 2;    /*一个通道对应两个寄存器*/

    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_DAC_GRIDVOLT_HIGH + ucDacChal) | AMC7836_CMD_RD, &ucTempH);

    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_DAC_GRIDVOLT_LOW + ucDacChal) | AMC7836_CMD_RD, &ucTempL);

    usTempData = ((ucTempH & 0xf) << 8) | (ucTempL & 0xff);

    //转换为电压值
    ptAmc7836_Dev->pFunVoltDacGet(usTempData, plDacValue);
    UARTprintf("Amc7836 dacSel %d: Reg[0x%02X~0x%02X] = 0x%04X; GridVolt(mv) = %d\r\n",
                ucDacSel, AMC7836_DAC_GRIDVOLT_LOW + ucDacChal, AMC7836_DAC_GRIDVOLT_HIGH + ucDacChal, usTempData, *plDacValue );

    return COMMON_OK;

}
/**********************************************************************/
/**
  * \brief 获取AMC7836 ADC值
  *
  * \param ulIndex 器件索引
  * \param adcSel adc通道
  * \param plAdcValue ADC值
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_Amc7836ReadAdcValue(UINT32 ulDevIndex, BYTE ucAdcSel, UINT16 *plAdcValue)
{
    BYTE ucAdcChal     = 0;
    UINT16 ucTempH     = 0;
    UINT16 ucTempL     = 0;
    UINT16 usTempData  = 0;
    T_Amc7836_Dev *ptAmc7836_Dev;

    ptAmc7836_Dev = &s_atAmc7836Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    ucAdcChal = ucAdcSel * 2;

    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_REG_UPDATA | AMC7836_CMD_WR, 0x20);
    zxUTILS_DelayNus(500);
    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_ADC_TRIGGER | AMC7836_CMD_WR, 1);
    zxUTILS_DelayNus(500);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + ucAdcChal) | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + ucAdcChal) | AMC7836_CMD_RD, &ucTempL);

    usTempData = ((ucTempH << 8) & 0xff00) | ucTempL;

    *plAdcValue = usTempData;

    return COMMON_OK;
}

#define MAX_CNT_AD_VAL      (3)
UINT32 BspGetAmc7836Temp(INT32 devIndex, BYTE adcSel, INT32 *temp)
{
    UINT32 adcVal = 0;
    UINT16 tmpVal[MAX_CNT_AD_VAL] = {0};
    UINT32 retVal = COMMON_OK;
    UINT32 loop = 0;
    float temperatur = 0.0;

    for(loop = 0; loop < MAX_CNT_AD_VAL; loop++)
    {
        retVal = zxDRV_Amc7836ReadAdcValue(devIndex, adcSel, &tmpVal[loop]);
    }

    loop = BspDataSelectMidValue(tmpVal, MAX_CNT_AD_VAL);
    adcVal = tmpVal[loop];
    temperatur = (5000 *((float)adcVal * 5 / 4096.0 - 2.5) - 500)/ 10 ;

    *temp = (INT32)(temperatur * 10); /* 温度单位由C 转换为 0.1 C */

    return retVal;
}
/**********************************************************************/
/**
  * \brief 获取AMC7836 电流
  *
  * \param ulDevIndex 器件索引
  * \param ucAdcSel adc通道
  * \param plCurr 电流值
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 BspGetAmc7836Curr(UINT32 ulDevIndex, BYTE ucAdcSel, UINT32 *plCurr)
{
    BYTE ucAdcChal    = 0;
    UINT16 ucTempH    = 0;
    UINT16 ucTempL    = 0;
    UINT16 usTempData = 0;
    FLOAT fCurrent    = 0.0;
    T_Amc7836_Dev *ptAmc7836_Dev;

    ptAmc7836_Dev = &s_atAmc7836Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    ucAdcChal = ucAdcSel * 2;

    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_ADC_TRIGGER | AMC7836_CMD_WR, 1);
    zxUTILS_DelayNus(500);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + ucAdcChal) | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + ucAdcChal) | AMC7836_CMD_RD, &ucTempL);

    usTempData = ((ucTempH << 8) & 0xff00) | ucTempL;

    fCurrent = usTempData * 5000.0 / 4096.0 / 100.0 / 0.015;

    *plCurr = (uint32_t)fCurrent;

    return COMMON_OK;
}

UINT32 BspGetAmc7836CurrAd(UINT32 devIndex, BYTE adcSel, UINT32 *pAdVal)
{
    BYTE adcChal = 0;
    UINT16 currAdValH    = 0;
    UINT16 currAdValL    = 0;
    UINT16 adData = 0;
    T_Amc7836_Dev *ptAmc7836_Dev = NULL;

    if (devIndex >= AMC7836_NUM)
    {
      UARTprintf("devIndex %d err!\n", devIndex);
      return COMMON_ERROR;
    }

    INPUT_POINTER_CHECK(pAdVal);

    ptAmc7836_Dev = &s_atAmc7836Dev[devIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    adcChal = adcSel * 2;

    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_ADC_TRIGGER | AMC7836_CMD_WR, 1);
    zxUTILS_DelayNus(500);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + adcChal) | AMC7836_CMD_RD, &currAdValH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + adcChal) | AMC7836_CMD_RD, &currAdValL);

    adData = ((currAdValH << 8) & 0xff00) | currAdValL;

    *pAdVal = (uint32_t)adData;

    return COMMON_OK;
}

VOID SetCaliTimes(UINT8 times)
{
    s_calitimes = times;
}

UINT32 BspWfsGetAmc7836CurrAd(UINT32 devIndex, BYTE adcSel, UINT32 *pAdVal)
{
    UINT32 loop = 0;
    UINT32 tmpVal = 0;
    UINT32 adVal = 0;
    UINT32 caliTimes = s_calitimes;

    INPUT_POINTER_CHECK(pAdVal);
    for(loop = 0; loop < caliTimes; loop++)
    {
        BspGetAmc7836CurrAd(devIndex, adcSel, &tmpVal);
        adVal += tmpVal;
    }

    tmpVal = adVal / caliTimes;
    *pAdVal = tmpVal;

    UARTprintf("adValue = %d\r\n", tmpVal);
    return COMMON_OK;
}

/**********************************************************************/
/**
  * \brief 获取AMC7836 电压
  *
  * \param ulDevIndex 器件索引
  * \param ucAdcSel adc通道
  * \param plCurr 电压值
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_Amc7836ReadVolt(UINT32 ulDevIndex, BYTE ucAdcSel, INT32 *plVolt)
{
    BYTE ucAdcChal    = 0;
    UINT16 ucTempH    = 0;
    UINT16 ucTempL    = 0;
    UINT16 usTempData = 0;
    T_Amc7836_Dev *ptAmc7836_Dev;

    ptAmc7836_Dev = &s_atAmc7836Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    ucAdcChal = ucAdcSel * 2;

    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_ADC_TRIGGER | AMC7836_CMD_WR, 1);
    zxUTILS_DelayNus(50);//zxUTILS_DelayNus(500);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + ucAdcChal) | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + ucAdcChal) | AMC7836_CMD_RD, &ucTempL);

    usTempData = ((ucTempH << 8) & 0xff00) | ucTempL;

    ptAmc7836_Dev->pFunVoltGet(usTempData, plVolt);

    return COMMON_OK;
}

/**********************************************************************/
/**
  * \brief 获取AMC7836 电压--特殊函数，由于需要在1ms内转换完毕4个通道值，则一次性读取完毕
  *
  * \param ulDevIndex 器件索引
  * \param ucAdcSel adc通道
  * \param plCurr 电压值
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_P4800ReadVolt(UINT32 ulDevIndex, INT32 *plTx1FwdVolt,INT32 *plTx1RevVolt,INT32 *plTx2FwdVolt,INT32 *plTx2RevVolt)
{
    UINT16 ucTempH    = 0;
    UINT16 ucTempL    = 0;
    UINT16 usTempData = 0;
    T_Amc7836_Dev *ptAmc7836_Dev;

    ptAmc7836_Dev = &s_atAmc7836Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAmc7836_Dev);

    ptAmc7836_Dev->pFunWriteReg(ptAmc7836_Dev->ulPeriIndex, AMC7836_ADC_TRIGGER | AMC7836_CMD_WR, 1);
    zxUTILS_DelayNus(500);
    /* TX1 FWD */
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + TX1_FWD_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + TX1_FWD_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempL);
    usTempData = ((ucTempH << 8) & 0xff00) | ucTempL;
    ptAmc7836_Dev->pFunVoltGet(usTempData, plTx1FwdVolt);
    UARTprintf("TX1 FWD: Reg[0x%02X~0x%02X] = 0x%04X; GridVolt(mv) = %d\r\n",
                AMC7836_ADC_DATA_HIGH + TX1_FWD_ADC_CHANNEL_SP*2, AMC7836_ADC_DATA_LOW + TX1_FWD_ADC_CHANNEL_SP*2, usTempData, *plTx1FwdVolt );
    /* TX1 REV */
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + TX1_REV_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + TX1_REV_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempL);
    usTempData = ((ucTempH << 8) & 0xff00) | ucTempL;
    ptAmc7836_Dev->pFunVoltGet(usTempData, plTx1RevVolt);
    UARTprintf("TX1 REV: Reg[0x%02X~0x%02X] = 0x%04X; GridVolt(mv) = %d\r\n",
                AMC7836_ADC_DATA_HIGH + TX1_FWD_ADC_CHANNEL_SP*2, AMC7836_ADC_DATA_LOW + TX1_REV_ADC_CHANNEL_SP*2, usTempData, *plTx1RevVolt );
    /* TX2 FWD */
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + TX2_FWD_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + TX2_FWD_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempL);
    usTempData = ((ucTempH << 8) & 0xff00) | ucTempL;
    ptAmc7836_Dev->pFunVoltGet(usTempData, plTx2FwdVolt);
    UARTprintf("TX2 FWD: Reg[0x%02X~0x%02X] = 0x%04X; GridVolt(mv) = %d\r\n",
                AMC7836_ADC_DATA_HIGH + TX1_FWD_ADC_CHANNEL_SP*2, AMC7836_ADC_DATA_LOW + TX2_FWD_ADC_CHANNEL_SP*2, usTempData, *plTx2FwdVolt );
    /* TX2 REV */
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_HIGH + TX2_REV_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempH);
    ptAmc7836_Dev->pFunReadReg(ptAmc7836_Dev->ulPeriIndex, (AMC7836_ADC_DATA_LOW + TX2_REV_ADC_CHANNEL_SP*2) | AMC7836_CMD_RD, &ucTempL);
    usTempData = ((ucTempH << 8) & 0xff00) | ucTempL;
    ptAmc7836_Dev->pFunVoltGet(usTempData, plTx2RevVolt);
    UARTprintf("TX2 REV: Reg[0x%02X~0x%02X] = 0x%04X; GridVolt(mv) = %d\r\n",
                AMC7836_ADC_DATA_HIGH + TX1_FWD_ADC_CHANNEL_SP*2, AMC7836_ADC_DATA_LOW + TX2_REV_ADC_CHANNEL_SP*2, usTempData, *plTx2RevVolt );

    return COMMON_OK;
}

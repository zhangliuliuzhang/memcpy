/************************************************/
/**
 * \file amc7836.h
 * \brief amc7836
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#ifndef _AMC7836_H
#define _AMC7836_H

#include "typedef.h"

#define AMC7836_NUM  (2)

#define AMC7836_CMD_RD                ( 0x8000 )
#define AMC7836_CMD_WR                ( 0x0000 )

#define AMC7836_REG_MAX               ( 0xC0 )

#define AMC7836_REG_CHIP_ID_LOW       ( 0x04 ) /* 0x36 */
#define AMC7836_REG_CHIP_ID_HIGH      ( 0x05 ) /* 0x0C */
#define AMC7836_REG_MANU_ID_LOW       ( 0x0C ) /* 0x51 */
#define AMC7836_REG_MANU_ID_HIGH      ( 0x0D ) /* 0x04 */

#define AMC7836_REG_UPDATA               ( 0x0F )

#define AMC7836_ADC_TRIGGER           ( 0xC0 )

#define AMC7836_ADC_DATA_LOW          ( 0x20 ) /* HIGH的低4bit + LOW的8bit */
#define AMC7836_ADC_DATA_HIGH         ( 0x21 ) /* 0x20 ~ 0x49 21个通道 16+5 */

#define AMC7836_DAC_CLR_EN_REG0       ( 0x18 ) /* DAC Clear Enable 0x18 0x19 */
#define AMC7836_DAC_CLR_EN_REG1       ( 0x19 )

#define AMC7836_TMPT_REG_LOW          ( 0x4A )  /* 温度寄存器 */
#define AMC7836_TMPT_REG_HIGH         ( 0x4B )

#define AMC7836_DAC_GRIDVOLT_LOW      ( 0x50 ) /* HIGH的低4bit + LOW的8bit */
#define AMC7836_DAC_GRIDVOLT_HIGH     ( 0x51 ) /* 0x50 ~ 0x6F 16个通道 */

#define TX1_FWD_ADC_CHANNEL_SP         ( 18 )
#define TX1_REV_ADC_CHANNEL_SP         ( 20 )
#define TX2_FWD_ADC_CHANNEL_SP         ( 17 )
#define TX2_REV_ADC_CHANNEL_SP         ( 19 )

typedef VOID (*AMC7836_CS_CONTROL_FUNC)(BYTE status);
typedef UINT32 (*AMC7836_WRITE_FUNC)( UINT32 ulPeriIndex, UINT16 usRegAddr, UINT16 usValue);
typedef UINT32 (*AMC7836_READ_FUNC)( UINT32 ulPeriIndex, UINT16 usRegAddr, UINT16 *usValue);
typedef UINT32 (*AMC7836_VOLT_DAC_SET_FUNC)(INT32 lVolt, UINT16 *pVoltReg);
typedef UINT32 (*AMC7836_VOLT_DAC_GET_FUNC)(UINT16 pVoltReg, INT32 *lVolt);
typedef UINT32 (*AMC7836_VOLT_ADC_GET_FUNC)( UINT16 usVoltReg, INT32 *plVolt);

typedef struct _T_Amc7836_Dev
{
    UINT32   ulDevIndex;       /* 芯片编号 */
    UINT32   ulPeriIndex;      /* 外设编号 */
//    UINT32   ulGridVoltType;
    AMC7836_CS_CONTROL_FUNC   pFunCsCtl;
    AMC7836_WRITE_FUNC        pFunWriteReg;
    AMC7836_READ_FUNC         pFunReadReg;
    AMC7836_VOLT_DAC_SET_FUNC pFunVoltSet;
    AMC7836_VOLT_DAC_GET_FUNC pFunVoltDacGet;
    AMC7836_VOLT_ADC_GET_FUNC pFunVoltGet;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;

} T_Amc7836_Dev;

VOID zxDRV_Amc7836Init(UINT32 index, T_Amc7836_Dev ptAmc7836_Dev);
UINT32 zxDRV_Amc7836ReadChipId(UINT32 ulDevIndex, UINT16 *id);
UINT32 zxDRV_Amc7836SetPaGridDac(UINT32 ulDevIndex, BYTE ucDacSel, INT32 usVolt);
UINT32 zxDRV_Amc7836GetPaGridDac(UINT32 ulDevIndex, BYTE ucDacSel, INT32 *plDacValue);
UINT32 zxDRV_Amc7836ReadAdcValue(UINT32 ulDevIndex, BYTE ucAdcSel, UINT16 *plAdcValue);
UINT32 BspGetAmc7836Curr(UINT32 ulDevIndex, BYTE ucAdcSel, UINT32 *plCurr);
UINT32 zxDRV_Amc7836ReadVolt(UINT32 ulDevIndex, BYTE ucAdcSel, INT32 *plVolt);
UINT32 zxDRV_P4800ReadVolt(UINT32 ulDevIndex, INT32 *plTx1FwdVolt,INT32 *plTx1RevVolt,INT32 *plTx2FwdVolt,INT32 *plTx2RevVolt);
UINT32 BspGetAmc7836Temp(INT32 devIndex, BYTE adcSel, INT32 *temp);
UINT32 BspGetAmc7836CurrAd(UINT32 devIndex, BYTE adcSel, UINT32 *pAdVal);
UINT32 BspWfsGetAmc7836CurrAd(UINT32 devIndex, BYTE adcSel, UINT32 *pAdVal);
VOID SetCaliTimes(UINT8 times);
#endif

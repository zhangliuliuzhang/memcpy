/************************************************/
/**
 * \file adt75.h
 * \brief adt75 温度传感器器件驱动头文件
 *
 * \author 10294149
 * \date   2021.4
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#ifndef _ADT75_H
#define _ADT75_H

#include "typedef.h"

#define ADT75_NUM  (5)

#define REG_TEMPERATURE   ( 0x00 )
#define REG_CONFIG        ( 0x01 )
#define REG_T_HYST        ( 0x02 )
#define REG_T_OS          ( 0x03 )
#define REG_ONE_SHOT      ( 0x04 )

typedef UINT32 (*ADT75_WRITE_FUNC)(UINT32 ulPeriIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *txBuf, UINT32 count);
typedef UINT32 (*ADT75_READ_FUNC)(UINT32 ulPeriIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *rxBuf, UINT32 count);

typedef struct _T_Adt75_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    UINT32 ulSlaveAddr;
  ADT75_WRITE_FUNC  pFunWriteData;
    ADT75_READ_FUNC        pFunReadData;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_Adt75_Dev;

VOID Adt75DevInit(UINT32 index, T_Adt75_Dev ptAdt75Dev);
UINT32 zxDRV_Adt75GetTemp(UINT32 ulDevIndex, DOUBLE *temperature);
UINT32 zxDRV_Adt75SetTHYST(UINT32 ulDevIndex, DOUBLE temper);
UINT32 zxDRV_Adt75SetTOS(UINT32 ulDevIndex, DOUBLE temper);
#endif

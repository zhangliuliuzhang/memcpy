/************************************************/
/**
 * \file adt75.c
 * \brief adt75 温度传感器器件驱动
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "adt75.h"
#include "common.h"

static T_Adt75_Dev s_atAdt75Dev[ADT75_NUM] = {0};

/**********************************************************************/
/**
* \brief 实例抽象对象
  *
  * \param index: 器件编号
  * \param ptLm75aDev: 器件抽象结构体
  *
  * \retval null
  */
/**********************************************************************/
VOID Adt75DevInit(UINT32 index, T_Adt75_Dev ptAdt75Dev)
{
    s_atAdt75Dev[index] = ptAdt75Dev;
}

/**********************************************************************/
/**
* \brief 获取温度传感器的温度
  *
  * \param ulDevIndex: 器件编号
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_Adt75GetTemp(UINT32 ulDevIndex, DOUBLE *temperature)
{
    INT16 temp = 0;
    BYTE tempReg[2] = {0};
    T_Adt75_Dev *ptAdt75Dev;

    ptAdt75Dev = &s_atAdt75Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAdt75Dev);
    INPUT_POINTER_CHECK(temperature);
    INPUT_POINTER_CHECK(ptAdt75Dev->pFunReadData);

    ptAdt75Dev->pFunReadData(ptAdt75Dev->ulPeriIndex, ptAdt75Dev->ulSlaveAddr, REG_TEMPERATURE, tempReg, 2);

    temp = (INT16)tempReg[0] << 8 | tempReg[1];
    temp = (INT16)(temp & 0xfff0) >> 4;
    *temperature = (double)temp * 0.0625;

    return COMMON_OK;
}

/**********************************************************************/
/**
* \brief 配置温度传感器THYST
  *
  * \param ulDevIndex: 器件编号
  * \param temper: 温度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_Adt75SetTHYST(UINT32 ulDevIndex, DOUBLE temper)
{
    BYTE tempReg[2] = {0};
    T_Adt75_Dev *ptAdt75Dev;

    ptAdt75Dev = &s_atAdt75Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAdt75Dev);
    INPUT_POINTER_CHECK(ptAdt75Dev->pFunWriteData);

    temper *= 16; //temper /= 0.0625;
    tempReg[0] = ((INT16)temper >> 4) & 0xFF;
    tempReg[1] = ((INT16)temper << 4) & 0xF0;

    ptAdt75Dev->pFunWriteData(ptAdt75Dev->ulPeriIndex, ptAdt75Dev->ulSlaveAddr, REG_T_HYST, tempReg, 2);

    return COMMON_OK;
}

/**********************************************************************/
/**
* \brief 配置温度传感器TOS
  *
  * \param ulDevIndex: 器件编号
  * \param temper: 温度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_Adt75SetTOS(UINT32 ulDevIndex, DOUBLE temper)
{
    BYTE tempReg[2] = {0};
    T_Adt75_Dev *ptAdt75Dev;

    ptAdt75Dev = &s_atAdt75Dev[ulDevIndex];

    INPUT_POINTER_CHECK(ptAdt75Dev);
    INPUT_POINTER_CHECK(ptAdt75Dev->pFunWriteData);

    temper *= 16; //temper /= 0.0625;
    tempReg[0] = ((INT16)temper >> 4) & 0xFF;
    tempReg[1] = ((INT16)temper << 4) & 0xF0;

    ptAdt75Dev->pFunWriteData(ptAdt75Dev->ulPeriIndex, ptAdt75Dev->ulSlaveAddr, REG_T_OS, tempReg, 2);

    return COMMON_OK;
}

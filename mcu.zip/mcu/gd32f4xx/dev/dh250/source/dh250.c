/************************************************/
/**
 * \file dh250.c
 * \brief dh250 温度传感器器件驱动
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "dh250.h"
#include "common.h"
#include <math.h>
#include "utils.h"

#define DH250_REG_READ_VOUT    (0x8B)    /*读取输出电压*/
#define DH250_REG_VOUT_MODE    (0x20)    /*读取输出电压模式*/
#define DH250_REG_SET_VOUT     (0x21)    /*设置输出电压*/
#define DH250_REG_TEMP         (0x8d)
#define PWR_TEMP_MIN_VAL       (-500)
#define PWR_TEMP_MAX_VAL       (1800)
#define PWR_TEMP_DEFAULT_VAL   (500)
#define MAX_CNT_VALID          (3)
#define MAX_TRY_CNT            (10)
#define DH250_BYTE2WORD(hi,lo)     (((UINT16)(hi) << 8) | (UINT16)(lo))

#define DH250_INDEX_CHECK(index)  if(index >= DH250_NUM)\
                                  {\
                                      UARTprintf("index[%d] is err\n", index);\
                                      return COMMON_ERROR;\
                                  }\

static T_Dh250_Dev s_atDh250Dev[DH250_NUM] = {0};

/**********************************************************************/
/**
* \brief 实例抽象对象
  *
  * \param index: 器件编号
  * \param ptLm75aDev: 器件抽象结构体
  *
  * \retval null
  */
/**********************************************************************/
UINT32 Dh250DevInit(UINT32 devIndex, T_Dh250_Dev ptDh250Dev)
{
    DH250_INDEX_CHECK(devIndex);
    s_atDh250Dev[devIndex] = ptDh250Dev;

    return COMMON_OK;
}

void dh250wr(INT32 argc, CHAR *argv[])
{
    T_Dh250_Dev *ptDh250Dev = NULL;
    BYTE value = 0;
    UINT32 index = 0;
    UINT32 reg = 0;
    UINT32 data = 0;

  if( argc != 4 )
  {
    UARTprintf("PARA NUM ERROR.\r\n");
  }

    index = strtol(argv[1],NULL,0);
    reg = strtol(argv[2],NULL,0);
    data = strtol(argv[3],NULL,0);

    value = data & 0xff;
    ptDh250Dev = &s_atDh250Dev[index];

    ptDh250Dev->pFunWriteData(ptDh250Dev->ulPeriIndex, ptDh250Dev->ulSlaveAddr, reg, &value, 1);

}

void dh250rd(INT32 argc, CHAR *argv[])
{
  T_Dh250_Dev *ptDh250Dev = NULL;
  BYTE value[8] = {0};
  UINT32 reg = 0;
  UINT32 index = 0;
  UINT32 byteNum = 0;
  UINT32 loop = 0;

  if( argc != 4 )
  {
    UARTprintf("PARA NUM ERROR.\r\n");
  }

  index = strtol(argv[1],NULL,0);
  reg = strtol(argv[2],NULL,0);
  byteNum = strtol(argv[3],NULL,0);

  ptDh250Dev = &s_atDh250Dev[index];
  if(ptDh250Dev->pFunReadData == NULL)
  {
    UARTprintf("point is null\n");
    return;
  }
  ptDh250Dev->pFunReadData(ptDh250Dev->ulPeriIndex, ptDh250Dev->ulSlaveAddr, reg, value, byteNum);

  for(loop = 0; loop < byteNum; loop++)
  {
    UARTprintf("[dh250rd]:value[%d] = 0x%x\n", loop, value[loop]);
  }
}

/* Started by AICoder, pid:9801e021c1d64a08a124a2060f6f4192 */
UINT32 BspDataSelectMidValue(UINT16 *pData, UINT32 dataLen)
{
    UINT32 loop = 0;
    UINT16 dmin = 0xFFFF;
    UINT16 dmax = 0;
    UINT32 dminidx = 0;
    UINT32 dmaxidx = 0;

    INPUT_POINTER_CHECK(pData);
    for (loop = 0; loop < dataLen; loop++)
    {
        if (pData[loop] == 0xFFFF)
        {
            continue;
        }

        if (dmin > pData[loop])
        {
            dmin = pData[loop];
            dminidx = loop;
        }

        if (dmax < pData[loop])
        {
            dmax = pData[loop];
            dmaxidx = loop;
        }
    }

    for (loop = dminidx; loop < dataLen; loop++)
    {
        GET_DATA_SELECT_IDX(loop, dminidx, dmaxidx);
    }

    return dminidx;
}
/* Ended by AICoder, pid:9801e021c1d64a08a124a2060f6f4192 */

static UINT32 Dh250GetTemp(UINT32 devIndex, INT16 *temp)
{
    BYTE tempReg[2] = {0};
    UINT16 tempRegValue[MAX_CNT_VALID] = {0};
    UINT8 loop = 0;
    UINT8 cnt = 0;
    INT32  paraN = 0;
    INT32  paraY = 0;
    DOUBLE para2pN      = 0;
    DOUBLE reportData   = 0;
    UINT32 ret = 0;
    T_Dh250_Dev *ptDh250Dev = NULL;

    DH250_INDEX_CHECK(devIndex);
    INPUT_POINTER_CHECK(temp);

    ptDh250Dev = &s_atDh250Dev[devIndex];

    for(loop = 0; loop < MAX_TRY_CNT && cnt < MAX_CNT_VALID; loop++)
    {
        ret |= ptDh250Dev->pFunReadData(ptDh250Dev->ulPeriIndex, ptDh250Dev->ulSlaveAddr, DH250_REG_TEMP, tempReg, NELEMENTS(tempReg));
        if(ret == COMMON_OK)
        {
            tempRegValue[cnt++] = DH250_BYTE2WORD(tempReg[1], tempReg[0]);
        }
    }

    if(cnt == 0)
    {
        UARTprintf("TEMP GET ERR!\n");
        return COMMON_ERROR;
    }
    loop = BspDataSelectMidValue(tempRegValue, MAX_CNT_VALID);
    if(loop >= MAX_CNT_VALID)
    {
        return COMMON_ERROR;
    }

    /* 系数N占高5bits */
    paraN = (INT32)BITS_RIGHT_JUST_GET(tempRegValue[loop],11,5);
    if (paraN & BIT_SET(4))
    {
        //负数情况下，补齐32bit的高27bit位全部置1来掩码
        paraN = (INT32)(BIT_FIELD_MASK_SET(5,27) | paraN);
    }

    /* Y占低11bits */
    paraY = (INT32)BITS_RIGHT_JUST_GET(tempRegValue[loop],0,11);
    if (paraY & BIT_SET(10))
    {
        //负数情况下，补齐32bit的高21bit位全部置1来掩码
        paraY = (INT32)(BIT_FIELD_MASK_SET(11,21) | paraY);
    }

    para2pN = pow((DOUBLE)2, (DOUBLE)paraN);
    reportData = (DOUBLE)paraY * para2pN;
    *temp = (INT16)(reportData * 10);

    return COMMON_OK;
}

/*获取输出电压2的N次方系数*/
static UINT32 Dh250GetVout2pN(UINT32 devIndex, DOUBLE *pVout2pN) /*出参不要有double,要改一下*/
{
    T_Dh250_Dev *ptDh250Dev = NULL;
    BYTE voutMode = 0;
    UINT16 tmpVal[MAX_CNT_VALID] = {0};
    INT16  sParaN = 0;
    DOUBLE dVout2pN = 0;
    UINT32 cnt = 0;
    UINT32 loop = 0;
    UINT32 ret = 0;

    DH250_INDEX_CHECK(devIndex);
    ptDh250Dev = &s_atDh250Dev[devIndex];
    INPUT_POINTER_CHECK(pVout2pN);
    INPUT_POINTER_CHECK(ptDh250Dev);

    for(loop = 0; loop < MAX_TRY_CNT && cnt < MAX_CNT_VALID; loop++)
    {
        ret = ptDh250Dev->pFunReadData(ptDh250Dev->ulPeriIndex, ptDh250Dev->ulSlaveAddr, DH250_REG_VOUT_MODE, &voutMode, 1);
        if(ret == COMMON_OK)
        {
            tmpVal[cnt] = voutMode;
            cnt++;
            voutMode = 0;
        }
    }

    if(cnt == 0)
    {
        UARTprintf("IIC ERR,GET 2PN ERR!\n");
        return COMMON_ERROR;
    }

    loop = BspDataSelectMidValue(tmpVal, MAX_CNT_VALID);
    if(loop >= MAX_CNT_VALID)
    {
        return COMMON_ERROR;
    }
    voutMode = tmpVal[loop];

    if(voutMode & 0x10)
    {
        sParaN =(voutMode & 0x1F)-0x20;
    }
    else
    {
        sParaN = voutMode & 0x001F;
    }

    dVout2pN = pow((DOUBLE)2, (DOUBLE)sParaN);
    *pVout2pN = dVout2pN;

    return COMMON_OK;
}

UINT32 Dh250VoutGet(UINT32 devIndex, INT32 *pVolt)
{
    DOUBLE vout2pN      = 0;
    DOUBLE vout        = 0;
    BYTE voltReg[2] = {0};
    UINT16 tmpVal[MAX_CNT_VALID] = {0};
    INT16 vout_Y = 0;
    UINT16 cnt = 0;
    UINT16 loop = 0;
    UINT32 ret = 0;
    T_Dh250_Dev *ptDh250Dev = NULL;

    DH250_INDEX_CHECK(devIndex);
    ptDh250Dev = &s_atDh250Dev[devIndex];
    INPUT_POINTER_CHECK(pVolt);
    INPUT_POINTER_CHECK(ptDh250Dev);

    Dh250GetVout2pN(devIndex, &vout2pN);

    for(cnt = loop = 0; loop < MAX_TRY_CNT && cnt < MAX_CNT_VALID ; loop++)
    {
        ret = ptDh250Dev->pFunReadData(ptDh250Dev->ulPeriIndex, ptDh250Dev->ulSlaveAddr, DH250_REG_READ_VOUT, voltReg, 2);
        if(ret == COMMON_OK)
        {
            tmpVal[cnt++] = DH250_BYTE2WORD(voltReg[1], voltReg[0]);
        }
    }

    if(cnt == 0)
    {
        UARTprintf("VOUT GET ERR!\n");
        return COMMON_ERROR;
    }

    loop = BspDataSelectMidValue(tmpVal, MAX_CNT_VALID);
    if(loop >= MAX_CNT_VALID)
    {
        return COMMON_ERROR;
    }

    vout_Y = tmpVal[loop];
    vout = vout_Y * vout2pN;
    *pVolt = (INT32)(vout * 1000);

    return COMMON_OK;
}

UINT32 BspDh250VoutGet(UINT32 devIndex, INT32 *pVolt)
{
    UINT32 loop = 0;
    UINT32 ret = 0;

    DH250_INDEX_CHECK(devIndex);
    INPUT_POINTER_CHECK(pVolt);
    for(loop = 0; loop < MAX_CNT_VALID; loop++)
    {
        ret = Dh250VoutGet(devIndex, pVolt);
        if(ret == COMMON_OK)
        {
            break;
        }
    }

    return ret;
}

UINT32 BspDh250VoutSet(UINT32 devIndex, INT32 volt)
{
    DOUBLE vout2pN = 1;
    INT16  voutY = 0;
    BYTE  voutData[2] = {0};
    T_Dh250_Dev *ptDh250Dev = NULL;

    DH250_INDEX_CHECK(devIndex);
    ptDh250Dev = &s_atDh250Dev[devIndex];
    Dh250GetVout2pN(devIndex, &vout2pN);
    voutY = (INT16)(((DOUBLE)volt / 1000.0) / vout2pN);

    voutData[0] = voutY & 0xFF;
    voutData[1] = (voutY >> 8) & 0xFF;

    ptDh250Dev->pFunWriteData(ptDh250Dev->ulPeriIndex, ptDh250Dev->ulSlaveAddr, DH250_REG_SET_VOUT, voutData, 2);

    return COMMON_OK;
}

UINT32 BspDh250GetTemp(UINT32 devIndex, INT16 *temp)
{
    UINT32 ret = 0;
    UINT32 loop = 0;
    INT16 tempVal = 0;

    INPUT_POINTER_CHECK(temp);
    for(loop = 0; loop < MAX_CNT_VALID; loop++)
    {
        ret = Dh250GetTemp(devIndex, &tempVal);
        if(ret == COMMON_OK)
        {
            break;
        }
    }

    if(loop >= MAX_CNT_VALID)   /*iic3次通信失败的情况下，返回最大温度值*/
    {
        *temp = PWR_TEMP_MAX_VAL;
        return COMMON_ERROR;
    }
#if defined _BSP_MCU_WFS
    *temp = tempVal;
    return COMMON_OK;
#endif

    if((tempVal < PWR_TEMP_MIN_VAL) || (tempVal > PWR_TEMP_MAX_VAL))    /* 沿用AAU策略 */
    {
        *temp = PWR_TEMP_DEFAULT_VAL;
    }
    else
    {
        *temp = tempVal;
    }

    return COMMON_OK;
}

static INT16 GetPaVoltStepValue(UINT16 originalVolt, UINT16 goalVolt)
{
    INT16 voutStep = 0;

    if(originalVolt > goalVolt)
    {
        voutStep = (-1) * PA_VOLT_STEP;
    }
    else if(originalVolt < goalVolt)
    {
        voutStep = PA_VOLT_STEP;
    }
    else
    {
        voutStep = 0;
    }

    return voutStep;
}

UINT32 BspSetPaVoltByStep(UINT32 index, UINT16 goalVolt)
{
    INT16 voutStep = 0;
    INT16 tmpVal = 0;
    UINT16 remainVolt = 0;
    UINT16 originalVolt = 0;
    UINT32 ret= 0;
    UINT32 cnt = 0;
    UINT32 loop = 0;

    if((goalVolt < PA_VOLT_MIN_VAL) || (goalVolt > PA_VOLT_MAX_VAL))
    {
        UARTprintf("volt value invalid!\n");
        return COMMON_ERROR;
    }

    ret = BspDh250VoutGet(index, (INT32 *)&originalVolt);
    if(ret == COMMON_ERROR)
    {
        UARTprintf("get originalVolt[%d] err!\n", originalVolt);
        return COMMON_ERROR;
    }

    voutStep = GetPaVoltStepValue(originalVolt, goalVolt);
    if(voutStep == 0)
    {
        UARTprintf("no need set vout!\n");
        return COMMON_OK;
    }

    cnt = abs(goalVolt - originalVolt) / PA_VOLT_STEP;
    remainVolt =  abs(goalVolt - originalVolt) % PA_VOLT_STEP;


    for(loop = 0; loop < cnt; loop++)
    {
        tmpVal = originalVolt + voutStep * (loop + 1);
        BspDh250VoutSet(index, tmpVal);
        zxUTILS_DelayNms(110);
    }
    if(remainVolt)
    {
        BspDh250VoutSet(index, goalVolt);
    }

    return COMMON_OK;
}


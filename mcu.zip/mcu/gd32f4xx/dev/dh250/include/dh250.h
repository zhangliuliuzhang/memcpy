/************************************************/
/**
 * \file adt75.h
 * \brief adt75
 * \author 10294149
 * \date   2021.4
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#ifndef _DH250_H
#define _DH250_H

#include "typedef.h"

#define DH250_NUM  (1)

#define REG_TEMPERATURE   ( 0x00 )
#define REG_CONFIG        ( 0x01 )
#define REG_T_HYST        ( 0x02 )
#define REG_T_OS          ( 0x03 )
#define REG_ONE_SHOT      ( 0x04 )

#define    PA_VOLT_STEP         (2000)
#define    PA_VOLT_MIN_VAL      (25000)
#define    PA_VOLT_MAX_VAL      (55000)

#define GET_DATA_SELECT_IDX(Loop, MinIdx, MaxIdx) \
    if (((Loop) != (MinIdx)) && ((Loop) != (MaxIdx)))   \
    {                                                   \
        return (Loop);                                  \
    }

typedef UINT32 (*DH250_WRITE_FUNC)(UINT32 ulPeriIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *txBuf, UINT32 count);
typedef UINT32 (*DH250_READ_FUNC)(UINT32 ulPeriIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *rxBuf, UINT32 count);

typedef struct _T_Dh250_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    UINT32 ulSlaveAddr;
    DH250_WRITE_FUNC pFunWriteData;
    DH250_READ_FUNC     pFunReadData;
}T_Dh250_Dev;

UINT32 Dh250DevInit(UINT32 index, T_Dh250_Dev ptDh250Dev);
UINT32 BspDh250VoutGet(UINT32 devIndex, INT32 *pVolt);
UINT32 BspDh250VoutSet(UINT32 devIndex, INT32 volt);
UINT32 BspDh250GetTemp(UINT32 devIndex, INT16 *temp);
UINT32 BspDataSelectMidValue(UINT16 *pData, UINT32 dataLen);
UINT32 BspSetPaVoltByStep(UINT32 index, UINT16 goalVolt);
void dh250rd(INT32 argc, CHAR *argv[]);
void dh250wr(INT32 argc, CHAR *argv[]);

#endif

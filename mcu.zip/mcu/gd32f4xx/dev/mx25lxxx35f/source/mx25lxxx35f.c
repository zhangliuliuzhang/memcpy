/************************************************/
/**
 * \file mx25lxxx35f.c
 * \brief SPI FLASH 器件驱动
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "mx25lxxx35f.h"
#include "common.h"

static T_Mx25lxxx_Dev s_atMx25lDev[MX25L_NUM] = {0};

/**********************************************************************/
/**
* \brief 实例抽象对象
  *
  * \param index: 器件编号
  * \param ptLm75aDev: 器件抽象结构体
  *
  * \retval null
  */
/**********************************************************************/
VOID zxDRV_Mx25lInit(UINT32 index, T_Mx25lxxx_Dev ptMx25lxxx_Dev)
{
    s_atMx25lDev[index] = ptMx25lxxx_Dev;
}

/*!
    \brief      read flash identification
    \param[in]  none
    \param[out] none
    \retval     flash identification
*/
UINT32 zxDRV_Mx25lReadId(UINT32 ulDevIndex)
{
    BYTE sendBuf[4] = {0};
    BYTE recvBuf[2] = {0};
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendBuf[0] = READ_MANU_DEV_ID;
    sendBuf[1] = 0x00;
    sendBuf[2] = 0x00;
    sendBuf[3] = 0x00;
    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 4);

    ptMx25lxxx_Dev->pFunReadData(ptMx25lxxx_Dev->ulPeriIndex, recvBuf, 2);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    if (MX25L512_ID == ((UINT32)recvBuf[0] << 8 | (UINT32)recvBuf[1]))
    {
        return MX25L512_ID;
    }

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendBuf[0] = READ_MT_MANU_DEV_ID;

    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 1);

    ptMx25lxxx_Dev->pFunReadData(ptMx25lxxx_Dev->ulPeriIndex, recvBuf, 2);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    if (MT25QL512_ID == ((UINT32)recvBuf[0] << 8 | (UINT32)recvBuf[1]))
    {
        return MT25QL512_ID;
    }

    return COMMON_ERROR;
}

/*!
    \brief      enable the write access to the flash
    \param[in]  none
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lWriteEnable(UINT32 ulDevIndex)
{
    BYTE sendData = 0;
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendData = WRITE_ENABLE;

    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, &sendData, 1);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    return COMMON_OK;
}

/*!
    \brief      enable the write access to the flash
    \param[in]  none
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lWriteDisable(UINT32 ulDevIndex)
{
    BYTE sendData = 0;
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendData = WRITE_DISABLE;

    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, &sendData, 1);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    return COMMON_OK;
}

/*!
    \brief      extFlash enter 4-byte mode
    \param[in]  none
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lEnter4ByteMode(UINT32 ulDevIndex)
{
    BYTE sendData = 0;
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendData = ENTER_4_BYTE_MODE;

    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, &sendData, 1);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    return COMMON_OK;
}

/*!
    \brief      poll the status of the write in progress(wip) flag in the flash's status register
    \param[in]  none
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lWaitForWriteEnd(UINT32 ulDevIndex)
{
    BYTE flash_status = 0;
    BYTE sendData = 0;
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendData = READ_STAT_REG;

    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, &sendData, 1);

    /* loop as long as the memory is busy with a write cycle */
  do{
        /* send a dummy byte to generate the clock needed by the flash
        and put the value of the status register in flash_status variable */
        ptMx25lxxx_Dev->pFunReadData(ptMx25lxxx_Dev->ulPeriIndex, &flash_status, 1);
  }while(E_SET == (flash_status & WIP_FLAG));

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    return COMMON_OK;
}

/*!
    \brief      poll the status of the write in progress(wip) flag in the flash's status register
    \param[in]  none
    \param[out] none
    \retval     if flag is clear return common_ok, else return common_error
*/
UINT32 zxDRV_Mx25lWaitWipFlagClear(UINT32 ulDevIndex)
{
    BYTE flash_status = 0;
    BYTE sendData = 0;
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendData = READ_STAT_REG;

    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, &sendData, 1);

    ptMx25lxxx_Dev->pFunReadData(ptMx25lxxx_Dev->ulPeriIndex, &flash_status, 1);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    if( E_SET == (flash_status & WIP_FLAG) )
    {
        return COMMON_ERROR;
    }
    else
    {
        return COMMON_OK;
    }
}

/*!
    \brief      erase the specified flash sector
    \param[in]  sector_addr: address of the sector to erase
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lSectorErase(UINT32 ulDevIndex, UINT32 sector_addr)
{
    BYTE sendBuf[5] = {0};
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    /* send write enable instruction */
    zxDRV_Mx25lWriteEnable(ulDevIndex);
    zxDRV_Mx25lWaitForWriteEnd(ulDevIndex);

    /* sector erase */
    /* select the flash: chip select low */
    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendBuf[0] = ERASE_SECTOR;
    if( ptMx25lxxx_Dev->ulFlashId == MX25L512_ID || ptMx25lxxx_Dev->ulFlashId == MT25QL512_ID )
    {
        sendBuf[1] = (sector_addr & 0xFF000000) >> 24;
        sendBuf[2] = (sector_addr & 0xFF0000) >> 16;
        sendBuf[3] = (sector_addr & 0xFF00) >> 8;
        sendBuf[4] = (sector_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 5);
    }
    else if( ptMx25lxxx_Dev->ulFlashId == MX25L128_ID )
    {
        sendBuf[1] = (sector_addr & 0xFF0000) >> 16;
        sendBuf[2] = (sector_addr & 0xFF00) >> 8;
        sendBuf[3] = (sector_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 4);
    }

    /* deselect the flash: chip select high */
    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    /* wait the end of flash writing */
    zxDRV_Mx25lWaitForWriteEnd(ulDevIndex);

    return COMMON_OK;
}

/*!
    \brief      erase the specified flash 64k block  Typ 0.34s Max 2.2s
    \param[in]  sector_addr: address of the sector to erase
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lBlock64kErase(UINT32 ulDevIndex, UINT32 block_addr)
{
    BYTE sendBuf[5] = {0};
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    /* send write enable instruction */
    zxDRV_Mx25lWriteEnable(ulDevIndex);
    zxDRV_Mx25lWaitForWriteEnd(ulDevIndex);

    /* sector erase */
    /* select the flash: chip select low */
    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendBuf[0] = ERASE_BLOCK_64K;
    if( ptMx25lxxx_Dev->ulFlashId == MX25L512_ID || ptMx25lxxx_Dev->ulFlashId == MT25QL512_ID )
    {
        sendBuf[1] = (block_addr & 0xFF000000) >> 24;
        sendBuf[2] = (block_addr & 0xFF0000) >> 16;
        sendBuf[3] = (block_addr & 0xFF00) >> 8;
        sendBuf[4] = (block_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 5);
    }
    else if( ptMx25lxxx_Dev->ulFlashId == MX25L128_ID )
    {
        sendBuf[1] = (block_addr & 0xFF0000) >> 16;
        sendBuf[2] = (block_addr & 0xFF00) >> 8;
        sendBuf[3] = (block_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 4);
    }

    /* deselect the flash: chip select high */
    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    /* wait the end of flash writing */
    zxDRV_Mx25lWaitForWriteEnd(ulDevIndex);

    return COMMON_OK;
}

/*!
    \brief      erase the specified flash 64k block  Typ 0.34s Max 2.2s
    \param[in]  sector_addr: address of the sector to erase
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lBlock64kEraseNoWait(UINT32 ulDevIndex, UINT32 block_addr)
{
    BYTE sendBuf[5] = {0};
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    /* send write enable instruction */
    zxDRV_Mx25lWriteEnable(ulDevIndex);
    zxDRV_Mx25lWaitForWriteEnd(ulDevIndex);

    /* sector erase */
    /* select the flash: chip select low */
    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendBuf[0] = ERASE_BLOCK_64K;
    if( ptMx25lxxx_Dev->ulFlashId == MX25L512_ID || ptMx25lxxx_Dev->ulFlashId == MT25QL512_ID )
    {
        sendBuf[1] = (block_addr & 0xFF000000) >> 24;
        sendBuf[2] = (block_addr & 0xFF0000) >> 16;
        sendBuf[3] = (block_addr & 0xFF00) >> 8;
        sendBuf[4] = (block_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 5);
    }
    else if( ptMx25lxxx_Dev->ulFlashId == MX25L128_ID )
    {
        sendBuf[1] = (block_addr & 0xFF0000) >> 16;
        sendBuf[2] = (block_addr & 0xFF00) >> 8;
        sendBuf[3] = (block_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 4);
    }

    /* deselect the flash: chip select high */
    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    return COMMON_OK;
}

/*!
    \brief      erase the continue flash 64k block
    \param[in]  sector_addr: address of the sector to erase
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lContinueBlock64kErase(UINT32 ulDevIndex, UINT32 block_addr, UINT16 BlockNum)
{
    UINT16 i;

    for(i = 0; i < BlockNum; i++)
  {
        zxDRV_Mx25lBlock64kErase(ulDevIndex, block_addr + FLASH_64K_BLOCK_SIZE * i);
  }

    return COMMON_OK;
}
/*!
    \brief      write more than one byte to the flash
    \param[in]  pbuffer: pointer to the buffer
    \param[in]  write_addr: flash's internal address to write
    \param[in]  num_byte_to_write: number of bytes to write to the flash
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lPageWrite(UINT32 ulDevIndex, BYTE* pbuffer, UINT32 write_addr, UINT32 num_byte_to_write)
{
    BYTE sendBuf[5] = {0};
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    /* send write enable instruction */
    zxDRV_Mx25lWriteEnable(ulDevIndex);
    zxDRV_Mx25lWaitForWriteEnd(ulDevIndex);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendBuf[0] = PAGE_PROGRAM;
    if( ptMx25lxxx_Dev->ulFlashId == MX25L512_ID || ptMx25lxxx_Dev->ulFlashId == MT25QL512_ID )
    {
        sendBuf[1] = (write_addr & 0xFF000000) >> 24;
        sendBuf[2] = (write_addr & 0xFF0000) >> 16;
        sendBuf[3] = (write_addr & 0xFF00) >> 8;
        sendBuf[4] = (write_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 5);
    }
    else if( ptMx25lxxx_Dev->ulFlashId == MX25L128_ID )
    {
        sendBuf[1] = (write_addr & 0xFF0000) >> 16;
        sendBuf[2] = (write_addr & 0xFF00) >> 8;
        sendBuf[3] = (write_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 4);
    }

    ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, pbuffer, num_byte_to_write);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    /* wait the end of flash writing */
    zxDRV_Mx25lWaitForWriteEnd(ulDevIndex);

    return COMMON_OK;
}

/*!
    \brief      write block of data to the flash
    \param[in]  pbuffer: pointer to the buffer
    \param[in]  write_addr: flash's internal address to write
    \param[in]  num_byte_to_write: number of bytes to write to the flash
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lBufferWrite(UINT32 ulDevIndex, BYTE* pbuffer, UINT32 writeAddr, UINT32 num_byte_to_write)
{
    UINT32 pageRemain;
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    pageRemain = SPI_FLASH_PAGE_SIZE - (writeAddr % SPI_FLASH_PAGE_SIZE);
    if( pageRemain > num_byte_to_write )
    {
        pageRemain = num_byte_to_write;
    }

    while(1)
    {
        zxDRV_Mx25lPageWrite(ulDevIndex, pbuffer, writeAddr, pageRemain);

        if( pageRemain == num_byte_to_write )
        {
            break;
        }
        else
        {
            pbuffer   += pageRemain;
            writeAddr += pageRemain;
            num_byte_to_write   -= pageRemain;

            if( num_byte_to_write > SPI_FLASH_PAGE_SIZE )
            {
                pageRemain = SPI_FLASH_PAGE_SIZE;
            }
            else
            {
                pageRemain = num_byte_to_write;
            }
        }
    }

    return COMMON_OK;
}

/*!
    \brief      read a block of data from the flash
    \param[in]  pbuffer: pointer to the buffer that receives the data read from the flash
    \param[in]  read_addr: flash's internal address to read from
    \param[in]  num_byte_to_read: number of bytes to read from the flash
    \param[out] none
    \retval     none
*/
UINT32 zxDRV_Mx25lBufferRead(UINT32 ulDevIndex, BYTE* pbuffer, UINT32 read_addr, UINT32 num_byte_to_read)
{
    BYTE sendBuf[5] = {0};
    T_Mx25lxxx_Dev *ptMx25lxxx_Dev;

    ptMx25lxxx_Dev = &s_atMx25lDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptMx25lxxx_Dev);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunControlCs);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunWriteData);
    INPUT_POINTER_CHECK(ptMx25lxxx_Dev->pFunReadData);

    ptMx25lxxx_Dev->pFunControlCs(E_RESET);

    sendBuf[0] = READ_DATA;
    if( ptMx25lxxx_Dev->ulFlashId == MX25L512_ID || ptMx25lxxx_Dev->ulFlashId == MT25QL512_ID )
    {
        sendBuf[1] = (read_addr & 0xFF000000) >> 24;
        sendBuf[2] = (read_addr & 0xFF0000) >> 16;
        sendBuf[3] = (read_addr & 0xFF00) >> 8;
        sendBuf[4] = (read_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 5);
    }
    else if( ptMx25lxxx_Dev->ulFlashId == MX25L128_ID )
    {
        sendBuf[1] = (read_addr & 0xFF0000) >> 16;
        sendBuf[2] = (read_addr & 0xFF00) >> 8;
        sendBuf[3] = (read_addr & 0xFF);
        ptMx25lxxx_Dev->pFunWriteData(ptMx25lxxx_Dev->ulPeriIndex, sendBuf, 4);
    }

    ptMx25lxxx_Dev->pFunReadData(ptMx25lxxx_Dev->ulPeriIndex, pbuffer, num_byte_to_read);

    ptMx25lxxx_Dev->pFunControlCs(E_SET);

    return COMMON_OK;
}

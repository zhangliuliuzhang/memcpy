/************************************************/
/**
 * \file mx25l12835f.h
 * \brief FLASH器件驱动头文件
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#ifndef _MX25LXXX35F_H
#define _MX25LXXX35F_H

#include "typedef.h"

#define MX25L_NUM  (3)

/*                     MX25L12835F
 *        FLASH--128M bit--16M byte 0x0~0xffffff
 *
 *     64k-byte *  256    = 16M  64k block  0x10000
 *     32k-byte *  512    = 16M  32k block  0x8000
 *     4k-byte  *  4096   = 16M  4k  sector 0x1000
 */

/*                     MX25L51235F
 *        FLASH--512M bit--64M byte 0x0~0x3ffffff
 *
 *     64k-byte *  1024    = 64M  64k block  0x10000
 *     32k-byte *  2018    = 64M  32k block  0x8000
 *     4k-byte  *  16384   = 64M  4k  sector 0x1000
 */

#define MX25L128_ID           ( 0xC217 )
#define MX25L512_ID           ( 0xC219 )
#define MT25QL512_ID          ( 0x20BA )

#define SPI_FLASH_PAGE_SIZE   ( 256  )
#define FLASH_32K_BLOCK_SIZE  ( 32 * 1024 )
#define FLASH_64K_BLOCK_SIZE  ( 64 * 1024)

#define READ_MANU_DEV_ID      ( 0x90u )
#define READ_MT_MANU_DEV_ID   ( 0x9Fu )
#define READ_STAT_REG         ( 0x05u )
#define WRITE_STAT_REG        ( 0x01u )
#define WRITE_ENABLE          ( 0x06u )
#define WRITE_DISABLE         ( 0x04u )
#define READ_DATA             ( 0x03u )
#define PAGE_PROGRAM          ( 0x02u )
#define ERASE_SECTOR          ( 0x20u )
#define ERASE_BLOCK_32K       ( 0x52u )
#define ERASE_BLOCK_64K       ( 0xD8u )
#define ERASE_CHIP            ( 0xC7u )
#define ENTER_4_BYTE_MODE     ( 0xB7u )
#define EXIT_4_BYTE_MODE      ( 0xE9u )

/*Flash status flag*/
#define WIP_FLAG              ( 0x01 )  /* Write In Progress (WIP) flag */
#define WEL_FLAG              ( 0x02 )  /* Write In Progress (WIP) flag */
#define DUMMY_BYTE            ( 0xA5 )

typedef VOID (*SPI_FLASH_CS_CONTROL_FUNC)(BYTE status);
typedef UINT32 (*SPI_FLASH_WRITE_FUNC)( UINT32 ulPeriIndex, BYTE *sendBuffer, UINT32 lenth);
typedef UINT32 (*SPI_FLASH_READ_FUNC)( UINT32 ulPeriIndex, BYTE *sendBuffer, UINT32 lenth);

typedef struct _T_Mx25lxxx_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    UINT32 ulFlashId;
    SPI_FLASH_CS_CONTROL_FUNC pFunControlCs;
    SPI_FLASH_WRITE_FUNC   pFunWriteData;
    SPI_FLASH_READ_FUNC    pFunReadData;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_Mx25lxxx_Dev;

VOID zxDRV_Mx25lInit(UINT32 index, T_Mx25lxxx_Dev ptMx25lxxx_Dev);
UINT32 zxDRV_Mx25lReadId(UINT32 ulDevIndex);
UINT32 zxDRV_Mx25lWriteEnable(UINT32 ulDevIndex);
UINT32 zxDRV_Mx25lWriteDisable(UINT32 ulDevIndex);
UINT32 zxDRV_Mx25lEnter4ByteMode(UINT32 ulDevIndex);
UINT32 zxDRV_Mx25lWaitForWriteEnd(UINT32 ulDevIndex);
UINT32 zxDRV_Mx25lWaitWipFlagClear(UINT32 ulDevIndex);
UINT32 zxDRV_Mx25lSectorErase(UINT32 ulDevIndex, UINT32 sector_addr);
UINT32 zxDRV_Mx25lBlock64kErase(UINT32 ulDevIndex, UINT32 block_addr);
UINT32 zxDRV_Mx25lBlock64kEraseNoWait(UINT32 ulDevIndex, UINT32 block_addr);
UINT32 zxDRV_Mx25lContinueBlock64kErase(UINT32 ulDevIndex, UINT32 block_addr, UINT16 BlockNum);
UINT32 zxDRV_Mx25lPageWrite(UINT32 ulDevIndex, BYTE* pbuffer, UINT32 write_addr, UINT32 num_byte_to_write);
UINT32 zxDRV_Mx25lBufferWrite(UINT32 ulDevIndex, BYTE* pbuffer, UINT32 writeAddr, UINT32 num_byte_to_write);
UINT32 zxDRV_Mx25lBufferRead(UINT32 ulDevIndex, BYTE* pbuffer, UINT32 read_addr, UINT32 num_byte_to_read);

#endif

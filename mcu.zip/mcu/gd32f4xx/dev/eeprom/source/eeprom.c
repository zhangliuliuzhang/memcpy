/************************************************/
/**
 * \file eeprom.c
 * \brief eeprom 驱动
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "eeprom.h"
#include "common.h"
#include "uartprint.h"
#include "utils.h"
#include "uart_ook.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define EEPROM_PAGE_MAX_NUM                 (512)
#define EEPROM_PAGE_SIZE                    (256)
#define EEPROM_INFO_HEAD_ADDR               (0x00)
#define DACSET_TXT_INFO_MAX                 (2*1024)
#define RRUIFO_TXT_INFO_SIZE                (5*1024)
#define OFF_LINE_PARA_MAX_SPACE             (15*1024)   /*暂定最带离线表的大小为15K*/
#define EEPROM_PAGE_DELAY                   (10)

/**************************************************************************
 *                        变量声明
 **************************************************************************/
static T_Eeprom_Dev s_atEepromDev[EEPROM_NUM] = {0};
T_ModuleInfoHead g_ModuleInfoHead;
static UINT8 g_dacTxtDataInfo[DACSET_TXT_INFO_MAX] = {0};
static UINT8 g_rruinfoTxtData[RRUIFO_TXT_INFO_SIZE] = {0};
static UINT32 g_dacTxtInfoLen = 0;
static UINT32 g_rruinfoTxtLenth = 0;

/**************************************************************************
 *                        函数声明
 **************************************************************************/
UINT32 BspEepromRdByPage(UINT32 addr, UINT32 lenth, UINT8 *data);

/**************************************************************************
 *                       函数实现
 **************************************************************************/
VOID BspSetDacTxtLen(UINT32 lenth)
{
    g_dacTxtInfoLen = lenth;
}

UINT32 BspGetDacTxtLen()
{
    return g_dacTxtInfoLen;
}

VOID zxDRV_EepromInit(UINT32 index, T_Eeprom_Dev tEepromDev)
{
    s_atEepromDev[index] = tEepromDev;
}

/**********************************************************************/
/**
* \brief 读取EEPROM数据 一次最大只支持255个字节读取
  *
  * \param ulDevIndex: 器件编号
  * \param addr: 读取地址
  * \param readData: 数据
  * \param lenth: 数据长度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_EepromReadData(UINT32 ulDevIndex, UINT32 addr, BYTE *readData, UINT32 lenth)
{
    BYTE deviceAddr = 0;
    BYTE pageRegAddr = 0;
    BYTE page = 0;
    T_Eeprom_Dev *ptEepromDev;
    UINT16 pageRemindLen = 0;
    UINT16 overLength = 0;

    ptEepromDev = &s_atEepromDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptEepromDev);
    INPUT_POINTER_CHECK(readData);

    if( addr > EEPROM_MAX_PAGE_NUM )
    {
        deviceAddr = EEPROM_MEMORY_ADDR_HIGH;
    }
    else
    {
        deviceAddr = EEPROM_MEMORY_ADDR_LOW;
    }

    pageRegAddr = addr % EEPROM_PAGE_SIZE;
    page = addr / EEPROM_PAGE_SIZE;
    if(page > 255)
    {
        UARTprintf("error addr is over!\n");
        return COMMON_ERROR;
    }

    pageRemindLen = EEPROM_PAGE_SIZE - pageRegAddr;  /*一页剩余的地址空间长度*/
    UARTprintf("page = %d, pageRegAddr = %d, pageRemindLen = %d\n", page, pageRegAddr, pageRemindLen);
    if( pageRemindLen >= lenth )   /*如果剩余的空间大于写入的长度，就不切页*/
    {
        ptEepromDev->pFunReadData(ptEepromDev->ulPeriIndex, deviceAddr, page, addr, readData, lenth);
    }
    else
    {
        overLength = lenth - pageRemindLen;
        ptEepromDev->pFunReadData(ptEepromDev->ulPeriIndex, deviceAddr, page, addr, readData, pageRemindLen);
        ptEepromDev->pFunReadData(ptEepromDev->ulPeriIndex, deviceAddr, page + 1, 0, readData+pageRemindLen, overLength);
    }
    return COMMON_OK;
}

/**********************************************************************/
/**
* \brief 写页 EEPROM数据
  * one page lenth is 256 byte, if write lenth exceed 256byte,
  * first byte of this page will overwrite
  *
  * \param ulDevIndex: 器件编号
  * \param addr: 写入地址
  * \param readData: 数据
  * \param lenth: 数据长度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 zxDRV_EepromWriteData(UINT32 ulDevIndex, UINT32 addr, BYTE *wrData, UINT16 lenth)
{
    BYTE deviceAddr = 0;
    BYTE pageRegAddr = 0;
    BYTE page = 0;
    T_Eeprom_Dev *ptEepromDev;
    UINT16 pageRemindLen = 0;
    UINT16 overLength = 0;

    ptEepromDev = &s_atEepromDev[ulDevIndex];

    INPUT_POINTER_CHECK(ptEepromDev);
    INPUT_POINTER_CHECK(wrData);
    if(lenth > 256)
    {
        UARTprintf("error addr is over!\n");
        return COMMON_ERROR;
    }
    if( addr > EEPROM_MAX_PAGE_NUM )
    {
        deviceAddr = EEPROM_MEMORY_ADDR_HIGH;
    }
    else
    {
        deviceAddr = EEPROM_MEMORY_ADDR_LOW;
    }

    pageRegAddr = addr % EEPROM_PAGE_SIZE;
    page = addr / EEPROM_PAGE_SIZE;
    if(page > 255)
    {
        UARTprintf("error addr is over!\n");
        return COMMON_ERROR;
    }

    pageRemindLen = EEPROM_PAGE_SIZE - pageRegAddr;  /*一页剩余的地址空间长度*/
    UARTprintf("page = %d, pageRegAddr = %d, pageRemindLen = %d\n", page, pageRegAddr, pageRemindLen);

    if( pageRemindLen >= lenth )   /*如果剩余的空间大于写入的长度，就不切页*/
    {
        ptEepromDev->pFunWriteData(ptEepromDev->ulPeriIndex, deviceAddr, page, addr, wrData, lenth);
    }
    else
    {
        overLength = lenth - pageRemindLen;
        UARTprintf("overLength = %d\n", overLength);
        ptEepromDev->pFunWriteData(ptEepromDev->ulPeriIndex, deviceAddr, page, addr, wrData, pageRemindLen);
        zxUTILS_DelayNms(100);
        ptEepromDev->pFunWriteData(ptEepromDev->ulPeriIndex, deviceAddr, page + 1, 0, wrData+pageRemindLen, overLength);
    }

    return COMMON_OK;
}


UINT32 BspReadEepromData(UINT32 addr, UINT32 lenth, UINT8 *data)
{
    //UINT32 zxDRV_EepromReadData(UINT32 ulDevIndex, UINT32 addr, BYTE *readData, UINT16 lenth)
    UINT32 retVal = COMMON_OK;

    INPUT_POINTER_CHECK(data);

    retVal = zxDRV_EepromReadData(0, addr, data, lenth);

    return retVal;
}

UINT32 BspWriteEepromData(UINT32 addr, UINT32 lenth, UINT8 *data)
{
    UINT32 retVal = COMMON_OK;

    INPUT_POINTER_CHECK(data);

    retVal = zxDRV_EepromWriteData(0, addr, data, lenth);

    return retVal;
}

UINT32 BspEepromWrByPage(UINT32 addr, UINT32 lenth, UINT8 *data)
{
    UINT32 pageNum = 0;
    UINT32 startPage = 0;
    UINT32 loop = 0;
    UINT32 deviceAddr = 0;
    UINT8 leftNum = 0;
    UINT8 pgaeAddr = 0;
    UINT32 retVal = COMMON_OK;
    T_Eeprom_Dev *ptEepromDev = NULL;

    INPUT_POINTER_CHECK(data);

    ptEepromDev = &s_atEepromDev[0];
    INPUT_POINTER_CHECK(ptEepromDev);

    startPage = addr / EEPROM_PAGE_SIZE;
    pageNum = lenth / EEPROM_PAGE_SIZE;
    leftNum = lenth % EEPROM_PAGE_SIZE;

    UARTprintf("eeprom wr:startPage = %d, pageNum = %d, leftNum = %d\n", startPage, pageNum, leftNum);
    for(loop = startPage; loop <= (pageNum + startPage); loop++)
    {
        if(loop > 255)
        {
            deviceAddr = EEPROM_MEMORY_ADDR_HIGH;
        }
        else
        {
            deviceAddr = EEPROM_MEMORY_ADDR_LOW;
        }

        ptEepromDev->pFunWriteData(ptEepromDev->ulPeriIndex, deviceAddr, loop, pgaeAddr, data, EEPROM_PAGE_SIZE);
        data += EEPROM_PAGE_SIZE;
        zxUTILS_DelayNms(10);      /*切页延时*/
    }

    if(leftNum != 0)
    {
        retVal |= ptEepromDev->pFunWriteData(ptEepromDev->ulPeriIndex, deviceAddr, pageNum + 1, pgaeAddr, data, leftNum);
    }

    return retVal;
}

UINT32 BspEepromRdByPage(UINT32 addr, UINT32 lenth, UINT8 *data)
{
    UINT32 pageNum = 0;
    UINT32 startPage = 0;
    UINT32 loop = 0;
    UINT32 deviceAddr = 0;
    UINT8 leftNum = 0;
    UINT8 pgaeAddr = 0;
    T_Eeprom_Dev *ptEepromDev = NULL;

    INPUT_POINTER_CHECK(data);

    ptEepromDev = &s_atEepromDev[0];
    INPUT_POINTER_CHECK(ptEepromDev);

    startPage = addr / EEPROM_PAGE_SIZE;    /*文件按页排满了，所以每次都会除尽*/
    pageNum = lenth / EEPROM_PAGE_SIZE;
    leftNum = lenth % EEPROM_PAGE_SIZE;

    zxUTILS_DelayNms(EEPROM_PAGE_DELAY);      /*读取数据之前先做10ms延迟*/
    for(loop = startPage; loop <= (pageNum + startPage); loop++)
    {
        if(startPage > 255)
        {
            deviceAddr = EEPROM_MEMORY_ADDR_HIGH;
        }
        else
        {
            deviceAddr = EEPROM_MEMORY_ADDR_LOW;
        }

        ptEepromDev->pFunReadData(ptEepromDev->ulPeriIndex, deviceAddr, loop, pgaeAddr, data, EEPROM_PAGE_SIZE);
        data += EEPROM_PAGE_SIZE;
        zxUTILS_DelayNms(EEPROM_PAGE_DELAY);      /*切页延时*/
    }

    if(leftNum != 0)
    {
        ptEepromDev->pFunReadData(ptEepromDev->ulPeriIndex, deviceAddr, pageNum + 1, pgaeAddr, data, leftNum);
        zxUTILS_DelayNms(EEPROM_PAGE_DELAY);      /*切页延时*/
    }

    return COMMON_OK;
}

UINT32 BspCleanEepromDataByPage(UINT32 devIndex, UINT32 startPage,  UINT32 endPage)
{
    UINT32 addr = 0;    /*每页的地址都是从0开始*/
    UINT32 loop = 0;
    UINT8 data[256] = {0,};
    UINT8 deviceAddr = 0;
    T_Eeprom_Dev *ptEepromDev = NULL;

    ptEepromDev = &s_atEepromDev[devIndex];
    INPUT_POINTER_CHECK(ptEepromDev);

    if(startPage > 255)
    {
        deviceAddr = EEPROM_MEMORY_ADDR_HIGH;
    }
    else
    {
        deviceAddr = EEPROM_MEMORY_ADDR_LOW;
    }

    for(loop = startPage; loop < endPage; loop++)
    {
        UARTprintf("start clear page [%d]\n", loop);
        addr = loop * 256;
        ptEepromDev->pFunWriteData(ptEepromDev->ulPeriIndex, deviceAddr, loop, addr, data, EEPROM_PAGE_SIZE);
        zxUTILS_DelayNms(10);
        UARTprintf("page[%d] clean finished!\n", loop);
    }

    return COMMON_OK;
}

UINT32 BspEepromByteRd(UINT32 devIndex, UINT32 addr, UINT8 *data)
{
    UINT32 retVal = COMMON_OK;

    zxDRV_EepromReadData(devIndex, addr, data, 1);
    return retVal;
}

T_ModuleInfoHead *BspGetModuleInfoHead()
{
    return &g_ModuleInfoHead;
}

UINT32 BspInitRfRableData_DacSet()
{
    UINT32 index = 0;
    UINT32 addr = 0;
    UINT32 ret = 0;
    UINT32 lenth = 0;
    T_ModuleInfoHead *pHeadInfo = NULL;

    pHeadInfo = BspGetModuleInfoHead();
    RFTBL_INPUT_POINTER_CHECK(pHeadInfo);

    index = BspGetOffLineInfoIndex(pHeadInfo, EEPROM_PA_DAC_FILE_TYPE);
    PARA_TBL_INDEX_CHECK(index);
    addr = pHeadInfo->tParaInfo[index].ulOffset;
    RTTBL_PARA_VAILD_CHECK(addr);
    lenth = pHeadInfo->tParaInfo[index].ulFileLenth;
    RTTBL_PARA_VAILD_CHECK(lenth);
    BspSetDacTxtLen(lenth);
    UARTprintf("addr = 0x%x\n", addr);
    UARTprintf("len = %d\n", lenth);
    ret = BspEepromRdByPage(addr, lenth, g_dacTxtDataInfo);
    return ret;
}

VOID InitRfTblInfo()
{
    memset_s(&g_ModuleInfoHead, sizeof(T_ModuleInfoHead), 0, sizeof(T_ModuleInfoHead));
    BspEepromRdByPage(0, sizeof(T_ModuleInfoHead), (UINT8 *)&g_ModuleInfoHead);
    memset_s(g_dacTxtDataInfo, DACSET_TXT_INFO_MAX, 0, DACSET_TXT_INFO_MAX);
    BspInitRfRableData_DacSet();
    memset_s(g_rruinfoTxtData, RRUIFO_TXT_INFO_SIZE, 0, RRUIFO_TXT_INFO_SIZE);
    BspInitRruinfoTxtData();
}

UINT8 *BspGetDacTxtInfo()
{
    return g_dacTxtDataInfo;
}

UINT32 BspMoveOfflLineHeadData(UINT8 index, INT32 changeSize)
{
    UINT32 moveDataSize = 0;
    UINT32 fileLenth = 0;
    UINT32 writeAddr = 0;
    UINT32 rdAddr = 0;
    UINT32 fileLen = 0;
    UINT32 fileCrc = 0;
    UINT8 loop = 0;
    UINT8 data[OFF_LINE_PARA_MAX_SPACE] = {0};
    T_ModuleInfoHead *pHeadInfo = NULL;

    pHeadInfo = BspGetModuleInfoHead();
    if(pHeadInfo == NULL)
    {
        return COMMON_ERROR;
    }

    if((changeSize % EEPROM_PAGE_SIZE) != 0)
    {
        moveDataSize = ((changeSize / EEPROM_PAGE_SIZE) + 1) * EEPROM_PAGE_SIZE;
    }
    else
    {
        moveDataSize = (changeSize / EEPROM_PAGE_SIZE) * EEPROM_PAGE_SIZE;
    }

    for(loop = EEPROM_FILE_TYPE_MAX - 1; loop > index; loop--)
    {
        memset_s(data, sizeof(data), 0, OFF_LINE_PARA_MAX_SPACE);
        fileLenth = pHeadInfo->tParaInfo[loop].ulFileLenth;
        if((fileLenth == 0) || (fileLenth == INVALID_STATUS))
        {
            continue;
        }
        rdAddr = pHeadInfo->tParaInfo[loop].ulOffset;       //偏移前的地址
        fileLen = pHeadInfo->tParaInfo[loop].ulFileLenth;
        UARTprintf("fielindex[%d] before addr = 0x%x, len = %d\n", loop, rdAddr, fileLen);
        if(fileLen > OFF_LINE_PARA_MAX_SPACE)
        {
            UARTprintf("Size[%d] is Over, Error\n", fileLen);
            return COMMON_ERROR;
        }

        BspEepromRdByPage(rdAddr, fileLen, data);                   //先将数据取出
        writeAddr = rdAddr + moveDataSize;
        g_ModuleInfoHead.tParaInfo[loop].ulOffset = writeAddr;      //偏移后的起始地址
        BspEepromWrByPage(writeAddr, fileLen, data);                //按照偏移向后移动
        fileCrc = pHeadInfo->tParaInfo[loop].ulCrc32;
        UARTprintf("fielindex[%d] after addr = 0x%x, fileCrc = 0x%x, len = %d\n", loop, writeAddr, fileCrc, fileLen);
    }

    return COMMON_OK;
}

VOID BspSetOffLineHeadInfo(UINT8 index, UINT8 fileType, UINT32 fileSize, UINT32 crc32, UINT32 startAddr)
{
    g_ModuleInfoHead.tParaInfo[index].fileType = fileType;
    g_ModuleInfoHead.tParaInfo[index].ulFileLenth = fileSize;
    g_ModuleInfoHead.tParaInfo[index].ulCrc32 = crc32;
    g_ModuleInfoHead.tParaInfo[index].ulOffset = startAddr;
    g_ModuleInfoHead.usFunNum++;

    BspEepromWrByPage(0, sizeof(T_ModuleInfoHead), (UINT8 *)&g_ModuleInfoHead);
}

UINT32 BspUpGradeOffLineHeadInfo(UINT8 index, UINT32 fileSize, UINT32 crc32)
{
    INT32 changeSize = 0;
    UINT32 originalSize = 0;
    UINT32 originalOffset = 0;
    UINT32 nextFielOffset = 0;
    UINT32 leftSpace = 0;
    T_ModuleInfoHead *pHeadInfo = NULL;

    pHeadInfo = BspGetModuleInfoHead();
    if(pHeadInfo == NULL)
    {
        return COMMON_ERROR;
    }
    PARA_TBL_INDEX_CHECK(index);
    originalSize = pHeadInfo->tParaInfo[index].ulFileLenth;
    originalOffset = pHeadInfo->tParaInfo[index].ulOffset;

    if(index == (EEPROM_FILE_TYPE_MAX - 1))
    {
        g_ModuleInfoHead.tParaInfo[index].ulCrc32 = crc32;
        g_ModuleInfoHead.tParaInfo[index].ulFileLenth = fileSize;
        BspEepromWrByPage(0, sizeof(T_ModuleInfoHead), (UINT8 *)&g_ModuleInfoHead);      //更新离线参数表头部
        return COMMON_OK;
    }
    nextFielOffset = pHeadInfo->tParaInfo[index + 1].ulOffset;
    changeSize = fileSize - originalSize;
    UARTprintf("changeSize = %d\n", changeSize);
    if(fileSize > originalSize)
    {
        leftSpace = (nextFielOffset - originalOffset) - originalSize;
        if(changeSize > leftSpace)      /*只有文件变大并且剩余空间不足的情况下，移动文件*/
        {
            UARTprintf("leftSpace[%d] is not enougth, move file!\n", leftSpace);
            BspMoveOfflLineHeadData(index, changeSize);
        }
    }

    g_ModuleInfoHead.tParaInfo[index].ulCrc32 = crc32;
    g_ModuleInfoHead.tParaInfo[index].ulFileLenth = fileSize;
    BspEepromWrByPage(0, sizeof(T_ModuleInfoHead), (UINT8 *)&g_ModuleInfoHead);      //更新离线参数表头部

    return COMMON_OK;
}

UINT32 BspCheckOffLinePara(UINT8 fileType)
{
    UINT32 fielSize = 0;
    UINT32 addr = 0;
    UINT32 fileCrc = 0;
    UINT32 caliCrc = INVALID_STATUS;
    UINT8 index = 0;
    UINT8 data[OFF_LINE_PARA_MAX_SPACE] = {0};
    T_ModuleInfoHead *pHeadInfo = NULL;

    pHeadInfo = BspGetModuleInfoHead();
    if(pHeadInfo == NULL)
    {
        return COMMON_ERROR;
    }

    index = BspGetOffLineInfoIndex(pHeadInfo, fileType);
    PARA_TBL_INDEX_CHECK(index);
    fielSize = pHeadInfo->tParaInfo[index].ulFileLenth;
    addr = pHeadInfo->tParaInfo[index].ulOffset;
    fileCrc = pHeadInfo->tParaInfo[index].ulCrc32;

    if(fielSize > OFF_LINE_PARA_MAX_SPACE)
    {
        UARTprintf("Size[%d] is Over,Err!\n", fielSize);
        return COMMON_ERROR;
    }
    BspEepromRdByPage(addr, fielSize, data);
    caliCrc = CalculateCrc32(caliCrc, data, fielSize);
    if(caliCrc != fileCrc)
    {
        UARTprintf("Filetype[%d] caliCrc[0x%x] fileCrc[0x%x] CRC Check Error!\n", fileType, caliCrc, fileCrc);
        return COMMON_ERROR;
    }

    UARTprintf("Filetype[%d] CRC Check Success!\n", fileType);
    return COMMON_OK;
}

UINT32 BspGetRruInfoLenth()
{
    return g_rruinfoTxtLenth;
}

VOID BspSetRruInfoLenth(UINT32 lenth)
{
    g_rruinfoTxtLenth = lenth;
}

UINT8 *BspGetRruInfoTxtData()
{
    return g_rruinfoTxtData;
}

UINT32 BspInitRruinfoTxtData()
{
    UINT32 index = 0;
    UINT32 addr = 0;
    UINT32 lenth = 0;
    UINT32 ret = 0;
    T_ModuleInfoHead *pHeadInfo = NULL;

    pHeadInfo = BspGetModuleInfoHead();
    RFTBL_INPUT_POINTER_CHECK(pHeadInfo);

    index = BspGetOffLineInfoIndex(pHeadInfo, EEPROM_RRUINFO_FILE_TYPE);
    PARA_TBL_INDEX_CHECK(index);
    addr = pHeadInfo->tParaInfo[index].ulOffset;
    RTTBL_PARA_VAILD_CHECK(addr);
    lenth = pHeadInfo->tParaInfo[index].ulFileLenth;
    RTTBL_PARA_VAILD_CHECK(lenth);
    BspSetRruInfoLenth(lenth);
    UARTprintf("rruinfo index = %d\n", index);
    UARTprintf("rruinfo addr = 0x%x\n", addr);
    UARTprintf("rruinfo len = %d\n", lenth);
    if(lenth > RRUIFO_TXT_INFO_SIZE)
    {
        lenth = RRUIFO_TXT_INFO_SIZE;
    }
    ret = BspEepromRdByPage(addr, lenth, g_rruinfoTxtData);
    return ret;
}

/*******************维侧接口*******************/
UINT32 printRftblHeadInfo(UINT8 fileType)
{
    UINT8 loop = 0;
    T_ModuleInfoHead *headInfo = NULL;

    headInfo = BspGetModuleInfoHead();

    if(headInfo == NULL)
    {
        UARTprintf("POINT IS NULL\n");
        return COMMON_ERROR;
    }

    for(loop = 0; loop < EEPROM_FILE_TYPE_MAX; loop++)
    {
        if(headInfo->tParaInfo[loop].fileType == fileType)
        {
            UARTprintf("fileType = %d\n", headInfo->tParaInfo[loop].fileType);
            UARTprintf("Crc32 = 0x%x\n", headInfo->tParaInfo[loop].ulCrc32);
            UARTprintf("FileLenth = %d\n", headInfo->tParaInfo[loop].ulFileLenth);
            UARTprintf("Offset = %d\n", headInfo->tParaInfo[loop].ulOffset);
            break;
        }
    }
    if(loop >= EEPROM_FILE_TYPE_MAX)
    {
        UARTprintf("file no exist!\n");
    }

    return COMMON_OK;
}

UINT32 printDacData()
{
    T_PaDacSetCaliData *dacData = NULL;
    UINT32 loop = 0;
    dacData = (T_PaDacSetCaliData *)_BspGetPaDacSetCalibData(0);

    INPUT_POINTER_CHECK(dacData);
    UARTprintf("*********HEAD INFO**************\n");
    UARTprintf("ver = %d\n",dacData->tComHeader.ulVer);
    UARTprintf("PathNum = %d\n",dacData->tComHeader.ulPathNum);
    UARTprintf("aucInfo = %s\n",dacData->tComHeader.aucInfo);
    UARTprintf("aucDate = %s\n",dacData->tComHeader.aucDate);
    UARTprintf("aucOperator = %s\n",dacData->tComHeader.aucOperator);
    UARTprintf("aucChecker = %s\n",dacData->tComHeader.aucChecker);

    UARTprintf("*********CALI HEAD INFO**************\n");
    UARTprintf("ulDacNum = %d\n",dacData->tHeader.ulDacNum);
    UARTprintf("ulDacPath[0] = %d\n",dacData->tHeader.ulDacPath[0]);
    UARTprintf("ulDacPath[1] = %d\n",dacData->tHeader.ulDacPath[1]);
    UARTprintf("aGridVoltN[0] = %d\n",dacData->tHeader.aGridVoltN[0]);
    UARTprintf("aGridVoltN[1] = %d\n",dacData->tHeader.aGridVoltN[1]);
    UARTprintf("ulClassNum = %d\n",dacData->tHeader.ulClassNum);
    UARTprintf("pathIndex[0] = %d\n",dacData->tHeader.pathIndex[0]);
    UARTprintf("pathIndex[1] = %d\n",dacData->tHeader.pathIndex[1]);
    UARTprintf("pathIndex[2] = %d\n",dacData->tHeader.pathIndex[2]);
    UARTprintf("paFreq[0] = %d\n",dacData->tHeader.paFreq[0]);
    UARTprintf("paFreq[1] = %d\n",dacData->tHeader.paFreq[1]);
    UARTprintf("paFreq[2] = %d\n",dacData->tHeader.paFreq[2]);
    UARTprintf("paFreq[3] = %d\n",dacData->tHeader.paFreq[3]);

    UARTprintf("*********tCali INFO 0**************\n");
    UARTprintf("ulPathLoadFlag = %d\n",dacData->tCali[0].ulPathLoadFlag);
    UARTprintf("ulRecordNum = %d\n",dacData->tCali[0].ulRecordNum);
    UARTprintf("ulDacPhyIndex = %d\n",dacData->tCali[0].ptRecord->ulDacPhyIndex);
    UARTprintf("ulDacChanIndex = %d\n",dacData->tCali[0].ptRecord->ulDacChanIndex);
    UARTprintf("ulGridVoltType = %d\n",dacData->tCali[0].ptRecord->ulGridVoltType);
    UARTprintf("ulGridVoltDataDef = %d\n",dacData->tCali[0].ptRecord->ulGridVoltDataDef);
    UARTprintf("lGridVoltTempFixDef = %d\n",dacData->tCali[0].ptRecord->lGridVoltTempFixDef);
    UARTprintf("ulGridVoltLower = %d\n",dacData->tCali[0].ptRecord->ulGridVoltLower);
    UARTprintf("ulGridVoltUpper = %d\n",dacData->tCali[0].ptRecord->ulGridVoltUpper);
    for(loop = 0; loop < TBL_PA_DAC_SET_ITEM; loop++)
    {
        UARTprintf("lPointAndCoefficient[loop] = %d\n",loop, dacData->tCali[0].ptRecord->lPointAndCoefficient[loop]);
    }
    UARTprintf("lGridVoltDataDefDiff = %d\n",dacData->tCali[0].ptRecord->lGridVoltDataDefDiff);

    UARTprintf("*********tCali INFO 1**************\n");
    UARTprintf("ulPathLoadFlag = %d\n",dacData->tCali[1].ulPathLoadFlag);
    UARTprintf("ulRecordNum = %d\n",dacData->tCali[1].ulRecordNum);
    UARTprintf("ulDacPhyIndex = %d\n",dacData->tCali[1].ptRecord->ulDacPhyIndex);
    UARTprintf("ulDacChanIndex = %d\n",dacData->tCali[1].ptRecord->ulDacChanIndex);
    UARTprintf("ulGridVoltType = %d\n",dacData->tCali[1].ptRecord->ulGridVoltType);
    UARTprintf("ulGridVoltDataDef = %d\n",dacData->tCali[1].ptRecord->ulGridVoltDataDef);
    UARTprintf("lGridVoltTempFixDef = %d\n",dacData->tCali[1].ptRecord->lGridVoltTempFixDef);
    UARTprintf("ulGridVoltLower = %d\n",dacData->tCali[1].ptRecord->ulGridVoltLower);
    UARTprintf("ulGridVoltUpper = %d\n",dacData->tCali[1].ptRecord->ulGridVoltUpper);
    for(loop = 0; loop < TBL_PA_DAC_SET_ITEM; loop++)
    {
        UARTprintf("lPointAndCoefficient[loop] = %d\n",loop, dacData->tCali[1].ptRecord->lPointAndCoefficient[loop]);
    }
    UARTprintf("lGridVoltDataDefDiff = %d\n",dacData->tCali[1].ptRecord->lGridVoltDataDefDiff);

    UARTprintf("*********tCali INFO 2**************\n");
    UARTprintf("ulPathLoadFlag = %d\n",dacData->tCali[2].ulPathLoadFlag);
    UARTprintf("ulRecordNum = %d\n",dacData->tCali[2].ulRecordNum);
    UARTprintf("ulDacPhyIndex = %d\n",dacData->tCali[2].ptRecord->ulDacPhyIndex);
    UARTprintf("ulDacChanIndex = %d\n",dacData->tCali[2].ptRecord->ulDacChanIndex);
    UARTprintf("ulGridVoltType = %d\n",dacData->tCali[2].ptRecord->ulGridVoltType);
    UARTprintf("ulGridVoltDataDef = %d\n",dacData->tCali[2].ptRecord->ulGridVoltDataDef);
    UARTprintf("lGridVoltTempFixDef = %d\n",dacData->tCali[2].ptRecord->lGridVoltTempFixDef);
    UARTprintf("ulGridVoltLower = %d\n",dacData->tCali[2].ptRecord->ulGridVoltLower);
    UARTprintf("ulGridVoltUpper = %d\n",dacData->tCali[2].ptRecord->ulGridVoltUpper);
    for(loop = 0; loop < TBL_PA_DAC_SET_ITEM; loop++)
    {
        UARTprintf("lPointAndCoefficient[loop] = %d\n",loop, dacData->tCali[2].ptRecord->lPointAndCoefficient[loop]);
    }
    UARTprintf("lGridVoltDataDefDiff = %d\n",dacData->tCali[2].ptRecord->lGridVoltDataDefDiff);

    return COMMON_OK;
}


/************************************************/
/**
 * \file eeprom.h
 * \brief eeprom
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#ifndef _EEPROM_H
#define _EEPROM_H

#include "typedef.h"
#include "rftbl_common.h"
#include "padacset.h"

/*
 *   4K bits = 512 bytes
 *   page size: 16 bytes * 32 = 512bytes
 */

/*******************************************************************
*                       宏定义                                       *
********************************************************************/
#define EEPROM_NUM  (2)

#define LENTH_256_BYTE                  ( 0xFF )
#define LENTH_PAGE_LENTH              (256)  /* 256 BYTE */

#define EEPROM_MEMORY_ADDR_LOW    ( 0xA4 )
#define EEPROM_MEMORY_ADDR_HIGH   ( 0xA6 )
#define EEPROM_INDENT_PAGE_ADDR      ( 0xB0 )

#define EEPROM_INDENT_ID_CODE            ( 0x00 ) /* 20H */
#define EEPROM_INDENT_FAMILY_CODE    ( 0x01 ) /* E0H */
#define EEPROM_INDENT_MEM_CODE        ( 0x02 ) /* 09H(4-Kbit) */

#define LENTH_1_KB                   (1024)
#define LENTH_64_KB                  LENTH_1_KB * 64
#define EEPROM_MAX_PAGE_NUM          (0xFFFF)
#define MODULE_MAX_FUNC_NUMBER  (32)                      /* 32 -- 最大功能表个数*/

#define RFTBL_INPUT_POINTER_CHECK(ppointer)                 \
    if (NULL == ppointer)                             \
    {                                                 \
        return COMMON_ERROR;                             \
    }

#define PARA_TBL_INDEX_CHECK(index)     \
{                                       \
    if(index >= EEPROM_FILE_TYPE_MAX)   \
    {                                   \
        UARTprintf("Index = %d is Err!\n", index);  \
        return COMMON_ERROR;            \
    }                                   \
}                                       \

#define PARA_TBL_INDEX_CHECK_RETURN(index)     \
{                                       \
    if(index >= EEPROM_FILE_TYPE_MAX)   \
    {                                   \
        UARTprintf("Index = %d is Err!\n", index);  \
        return ;            \
    }                                   \
}

#define RTTBL_PARA_VAILD_CHECK(paraData)    \
    if((paraData == 0xFFFFFFFF) || (paraData == 0) || (paraData == 0xFFFF))  \
    {\
        UARTprintf("para is err\n");\
        return COMMON_ERROR;    \
    }

/*******************************************************************
*                       数据类型                                       *
********************************************************************/
typedef UINT32 (*EEPROM_WRITE_FUNC)(UINT32 ulPeriIndex, UINT32 slaveAddr, BYTE page, BYTE registerAddr, BYTE *txBuf, UINT32 count);
typedef UINT32 (*EEPROM_READ_FUNC)(UINT32 ulPeriIndex, UINT32 slaveAddr, BYTE page, BYTE registerAddr, BYTE *rxBuf, UINT32 count);

typedef enum
{
    EEPROM_PA_DAC_FILE_TYPE,                /*PaDacSet.txt*/
    EEPROM_FILTER_GAIN_FILE_TYPE,           /*FilterGain.txt*/
    EEPROM_PA_BASIC_FILE_TYPE,              /*PaBasicInfo.txt*/
    EEPROM_PA_CURR_CALI_FILE_TYPE,          /*PaCurrentCali.txt*/
    EEPROM_PA_TEMP_GAIN_FILE_TYPE,          /*PaTempGain.txt*/
    EEPROM_QI_TAO_XING_FILE_TYPE,           /*qitaoxing.txt*/
    EEPROM_RRUINFO_FILE_TYPE,               /*Rruinfo.txt*/
    EEPROM_RX_RSSI_FILE_TYPE,               /*RxRssi.txt*/
    EEPROM_TX_FWD_FILE_TYPE,                /*TxFwd.txt*/
    EEPROM_TX_FWD_ANALOG_FILE_TYPE,         /*TxFwdAnalog.txt*/
    EEPROM_TX_GAIN_FILE_TYPE,               /*TxGain.txt*/
    EEPROM_TX_REV_ANALOG_FILE_TYPE,         /*TxRevAnalog.txt*/
    EEPROM_PA_ENERGY_SAVE_FILE_TYPE,        /*PaEnergySavingAdj.txt*/

    EEPROM_DPD_FILE_TYPE,     //DPD离线表

    EEPROM_FILE_TYPE_MAX,

}OFF_LINE_PARA_TYPE;

typedef struct _T_Eeprom_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    EEPROM_WRITE_FUNC pFunWriteData;
    EEPROM_READ_FUNC    pFunReadData;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_Eeprom_Dev;

typedef struct tagT_FunInfo
{
    UCHAR        fileType;            /* 离线参数表类型 */
    UINT32       ulOffset;            /* 功能表所在偏移地址 */
    UINT32       ulFileLenth;         /* 文件长度 */
    UINT32       ulCrc32;             /* 32位CRC */
}T_OffLineParaInfo;

typedef struct tagT_ModuleInfoHead
{
    UINT8      usFunNum;            /* 此区功能数 */
    T_OffLineParaInfo   tParaInfo[EEPROM_FILE_TYPE_MAX];        /* 功能表 */
}T_ModuleInfoHead;

/**************************************************************************
*                         全局函数声明                                   *
**************************************************************************/
UINT32 BspCheckOffLinePara(UINT8 fileType);
VOID zxDRV_EepromInit(UINT32 index, T_Eeprom_Dev tEepromDev);
UINT32 zxDRV_EepromReadId(UINT32 ulDevIndex, BYTE *eepromId);
UINT32 zxDRV_EepromReadData(UINT32 ulDevIndex, UINT32 addr, BYTE *readData, UINT32 lenth);
UINT32 zxDRV_EepromWriteData(UINT32 ulDevIndex, UINT32 addr, BYTE *writeData, UINT16 lenth);
UINT32 BspWriteEepromData(UINT32 addr, UINT32 lenth, UINT8 *data);
UINT32 BspCleanEepromDataByPage(UINT32 devIndex, UINT32 startPage,  UINT32 endPage);
UINT32 BspEepromRdByPage(UINT32 addr, UINT32 lenth, UINT8 *data);
UINT32 BspEepromWrByPage(UINT32 addr, UINT32 lenth, UINT8 *data);
UINT8 *BspGetDacTxtInfo();
UINT32 BspGetDacTxtLen();
UINT32 BspInitRruinfoTxtData();
UINT8 *BspGetRruInfoTxtData();
UINT32 BspGetRruInfoLenth();
UINT32 printRftblHeadInfo(UINT8 fileType);
UINT32 printDacData();
VOID InitRfTblInfo();
T_ModuleInfoHead *BspGetModuleInfoHead();
VOID BspSetOffLineHeadInfo(UINT8 index, UINT8 fileType, UINT32 fileSize, UINT32 crc32, UINT32 startAddr);
UINT32 BspUpGradeOffLineHeadInfo(UINT8 index, UINT32 fileSize, UINT32 crc32);
UINT32 BspReadEepromData(UINT32 addr, UINT32 lenth, UINT8 *data);
#endif

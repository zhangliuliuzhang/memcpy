
#include "common.h"
#include "tmp451.h"

#define TMP_CHIP_MAX_NUM    (1)
#define TEMP_RANGE_N64_191_FLAG_TMP451        (0x04)

static T_Tmp451_Dev s_atTmp451Dev[TMP_CHIP_MAX_NUM] = {0};

VOID Tmp451DevInit(UINT32 devIndex, T_Tmp451_Dev ptTmp451Dev)
{
    s_atTmp451Dev[devIndex] = ptTmp451Dev;
}

static UINT32 Tmp451TempSensorRegRead(UINT32 chipIndex, UINT32 regAddr, UINT32 *regVal)
{
    UCHAR buff[2] = {0,0};
    T_Tmp451_Dev *pTmp451Dev = NULL;

    INPUT_POINTER_CHECK(regVal);
    pTmp451Dev = &s_atTmp451Dev[chipIndex];

    pTmp451Dev->pFunReadData(pTmp451Dev->ulPeriIndex, pTmp451Dev->ulSlaveAddr, regAddr, buff, 1);

    *regVal = buff[0];

    return 0;

}

UINT32 BspGetTmp451SensorTemp(UINT32 tempAddr, INT32 *temp)
{
    UINT32 mainRegVal = 0;
    UINT32 exteRegVal = 0;
    UINT32 tempRange = 0;
    UINT32 rangeFlag = 0;
    UINT32 tempOffset = 0;
    INT32 sensorTemp = 0;


    INPUT_POINTER_CHECK(temp);
    if (0 == tempAddr)
    {
    //  pcNameStr = "LocalTemp";

        /* 0x00: 整数部分, 0x15: 小数部分 */
        Tmp451TempSensorRegRead(0, 0x00, &mainRegVal);
        Tmp451TempSensorRegRead(0, 0x15, &exteRegVal);
    }
    else
    {
    //  pcNameStr = "RemoteTemp";

        /* 0x01: 整数部分, 0x10: 小数部分 */
        Tmp451TempSensorRegRead(0, 0x01, &mainRegVal);
        Tmp451TempSensorRegRead(0, 0x10, &exteRegVal);
    }

    Tmp451TempSensorRegRead(0, 0x03, &tempRange);

    UARTprintf("BspGetTmp451SensorTemp >> mainRegVal = 0x%x, exteRegVal = 0x%x, tempRange = 0x%x, tempAddr = 0x%x\n", mainRegVal, exteRegVal, tempRange, tempAddr);

    // 配置TMP451温度传感器, ulTempRange
    // 0- Standard模式, 温度范围为 0  ~ 127度
    // 1- extended模式, 温度范围为 -64~ 191度
    rangeFlag = TEMP_RANGE_N64_191_FLAG_TMP451;
    tempRange = !!(tempRange & rangeFlag);
    if (0 == tempRange)
    {
        tempOffset = 0;
    }
    else
    {
        tempOffset = -64;
    }

    exteRegVal = (exteRegVal >> 4) & 0x0F;
    sensorTemp = (mainRegVal + tempOffset) * 10000 + exteRegVal * 625;

    *temp = sensorTemp / 1000;
    //UARTprintf("BspGetTmp451SensorTemp >> TEMP = %0.2f\n", sensorTemp / 10000.0);

    return COMMON_OK;
}

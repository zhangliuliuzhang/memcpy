/************************************************/
#ifndef _TMP451_H
#define _TMP451_H

#include "typedef.h"


typedef UINT32 (*TMP451_WRITE_FUNC)(UINT32 chipIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *txBuf, UINT32 count);
typedef UINT32 (*TMP451_READ_FUNC)(UINT32 chipIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *rxBuf, UINT32 count);


typedef struct _T_Tmp451_Dev
{
    UINT32 ulDevIndex;
    UINT32 ulPeriIndex;
    UINT32 ulSlaveAddr;
    TMP451_WRITE_FUNC pFunWriteData;
    TMP451_READ_FUNC  pFunReadData;
}T_Tmp451_Dev;

UINT32 BspGetTmp451SensorTemp(UINT32 tempAddr, INT32 *temp);
VOID Tmp451DevInit(UINT32 devIndex, T_Tmp451_Dev ptTmp451Dev);
#endif

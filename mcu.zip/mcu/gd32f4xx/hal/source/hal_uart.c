/************************************************/
/**
 * \file hal_uart.c
 * \brief UART适配层代码
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_uart.h"
#include "gd32f4xx_rcu.h"
#include "gd32f4xx_usart.h"
#include "uartprint.h"
#include "common.h"

/**********************************************************************/
/**
  * \brief     初始化UART模块时钟
  *
  * \param bank: RCU_USART1,RCU_USART2......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetUartClkEn(UINT32 bank)
{
    rcu_periph_clock_enable((rcu_periph_enum)bank);
}

/**********************************************************************/
/**
  * \brief     去初始化UART模块
  *
  * \param uartId:USART0,USART1......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalDeintUart(UINT32 uartId)
{
    usart_deinit(uartId);
}

/**********************************************************************/
/**
  * \brief 设置UART波特率
  *
  * \param uartId uart索引
  * \param baudrate 波特率
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetUartBaudrate(UINT32 uartId, UINT32 baudrate)
{
    usart_baudrate_set(uartId, baudrate);
}

/**********************************************************************/
/**
  * \brief 设置UART接收配置
  *
  * \param uartId uart索引
  * \param rxconfig 接收配置
  *
  * \retval null
  */
/**********************************************************************/
VOID HalConfigUartRecvive(UINT32 uartId, UINT32 rxconfig)
{
    usart_receive_config(uartId, rxconfig);
}

/**********************************************************************/
/**
* \brief 设置UART发送配置
  *
  * \param uartId uart索引
  * \param txconfig 接收配置
  *
  * \retval null
  */
/**********************************************************************/
VOID HalConfigUartTransmit(UINT32 uartId, UINT32 txconfig)
{
    usart_transmit_config(uartId, txconfig);
}

/**********************************************************************/
/**
  * \brief     使能UART模块
  *
  * \param uartId:USART0,USART1......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalEnableUart(UINT32 uartId)
{
    usart_enable(uartId);
}

/**********************************************************************/
/**
  * \brief     使能UART模块的中断
  *
  * \param uartId:USART0,USART1......
  * \param interrupt:USART_INT_RBNE,USART_INT_IDLE......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalEnableInt(UINT32 uartId, UINT32 interrupt)
{
    usart_interrupt_enable(uartId, (usart_interrupt_enum)interrupt);
}

VOID HalDisableInt(UINT32 uartId, UINT32 interrupt)
{
    usart_interrupt_disable(uartId, (usart_interrupt_enum)interrupt);
}

/**********************************************************************/
/**
  * \brief     获取UART模块的状态标志
  *
  * \param uartId:USART0,USART1......
  * \param flag:USART_FLAG_TBE,USART_FLAG_RBNE......
  *
  * \retval 状态标志
  */
/**********************************************************************/
UINT32 HalGetUartFlagStatus(UINT32 uartId, UINT32 flag)
{
    return usart_flag_get(uartId, (usart_flag_enum)flag);
}

/**********************************************************************/
/**
    * \brief     UART发送一个字节
  *
  * \param uartId: USART0,USART1......
  * \param data: ready send byte
  *
  * \retval null
  */
/**********************************************************************/
VOID HalUartSendByte(UINT32 uartId, UINT32 data)
{
    while(RESET == HalGetUartFlagStatus(uartId, USART_FLAG_TBE));
    usart_data_transmit(uartId, data);
}

/**********************************************************************/
/**
    * \brief     UART发送一个定长Buffer
  *
  * \param uartId: USART0,USART1......
  * \param pData: ready send data address
  * \param dataLen: ready send data lenth
  *
  * \retval null
  */
/**********************************************************************/
UINT32 HalUartSendBuffer(UINT32 uartId, BYTE *pData, UINT32 dataLen)
{
    UINT32 index;

    if(pData == NULL)
    {
        UARTprintf("INPUT POINT NULL!\n");
        return COMMON_ERROR;
    }

    for(index = 0; index < dataLen; index++)
    {
        HalUartSendByte(uartId, pData[index]);
    }

    if(BspGetOokTestPrintFlag() == 1)
    {
      for(index = 0; index < dataLen; index++)
      {
          if(index % 16 == 0)
            {
              UARTprintf("\n");
            }
            UARTprintf("0x%02x ", pData[index]);
        }
        UARTprintf("\n");
    }
    UARTprintf("ook send finished: \n");
    return COMMON_OK;
}

/**********************************************************************/
/**
    * \brief     UART发送一个string
  *
  * \param uartId: USART0,USART1......
  * \param pData: ready send data address
  * \param dataLen: ready send data lenth
  *
  * \retval null
  */
/**********************************************************************/
VOID HalUartSendString(UINT32 uartId, const BYTE *string)
{
    UINT32 index = 0;

    while(string[index] != '\0')
    {
        HalUartSendByte(uartId, string[index++]);
    }
}

/**********************************************************************/
/**
    * \brief     UART发送一个定长hex Buffer
  *
  * \param uartId: USART0,USART1......
  * \param pData: ready send data address
  * \param dataLen: ready send data lenth
  *
  * \retval null
  */
/**********************************************************************/
VOID HalUartSendHexBuffer(UINT32 uartId, BYTE *pData, UINT32 dataLen)
{
    UINT32 index;

    for(index = 0; index < dataLen; index++)
    {
    UARTprintf("%02x ",pData[index]);
    }
  UARTprintf("\r\n");
}

/**********************************************************************/
/**
    * \brief     UART enable or disable ctrl
  *
  * \param uartId: USART0,USART1......
  * \param ucStat: contrl status
  *
  * \retval null
  */
/**********************************************************************/
VOID HalUartContrl(UINT32 uartId, BOOLEAN ucStat)
{
    if(FALSE == ucStat)
    {
        /* disable USART receive and transmit */
        usart_transmit_config(uartId, USART_RECEIVE_DISABLE);
        usart_receive_config(uartId, USART_TRANSMIT_DISABLE);
    }
    else if(TRUE == ucStat)
    {
        usart_receive_config(uartId, USART_RECEIVE_ENABLE);
        usart_transmit_config(uartId, USART_TRANSMIT_ENABLE);
    }
}

/**********************************************************************/
/**
  * \brief 初始化UART
  *
  * \param _T_Uart_Tbl: 抽象属性参数
  *
  * \retval none
  */
/**********************************************************************/
VOID HalInitUart(_T_Uart_Tbl tObjUart)
{
    HalSetUartClkEn(tObjUart.clkPort);

    HalDeintUart(tObjUart.uartId);
    HalSetUartBaudrate(tObjUart.uartId, tObjUart.baudrate);
    HalConfigUartRecvive(tObjUart.uartId, tObjUart.rxConfig);
    HalConfigUartTransmit(tObjUart.uartId, tObjUart.txConfig);
    HalEnableUart(tObjUart.uartId);

    if( UART_INT_TYPE_NONE != tObjUart.intType )
    {
        HalEnableInt(tObjUart.uartId, tObjUart.intType);
        nvic_irq_enable(tObjUart.nvicIrq, tObjUart.nvicPrePrio, tObjUart.nvicSubPrio);
    }
}

//TODO: DMA 初始化  重新构建结构体进行抽象


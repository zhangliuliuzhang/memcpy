/************************************************/
/**
 * \file hal_adc.c
 * \brief ADC适配层代码
 *
 * \author 10294149
 * \date   2021.8
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_adc.h"
#include "gd32f4xx_rcu.h"
#include "gd32f4xx_adc.h"
#include "common.h"

/**********************************************************************/
/**
  * \brief 初始化ADC
  *
  * \param _T_Adc_Tbl: 抽象属性参数
  *
  * \retval none
  */
/**********************************************************************/
VOID HalInitAdcRegular(_T_Adc_Tbl tObjAdc)
{
    /* enable ADC clock */
    rcu_periph_clock_enable((rcu_periph_enum)tObjAdc.clkPort);
    /* config ADC clock */
    adc_clock_config(tObjAdc.clkPrescaler);

    adc_channel_length_config(tObjAdc.adcId, ADC_REGULAR_CHANNEL, 1);

    adc_regular_channel_config(tObjAdc.adcId, 0 ,tObjAdc.adcChannel, ADC_SAMPLETIME_144);
    adc_resolution_config(tObjAdc.adcId, ADC_RESOLUTION_12B);
    /* ADC data alignment config */
    adc_data_alignment_config(tObjAdc.adcId, ADC_DATAALIGN_RIGHT);
    adc_discontinuous_mode_config(tObjAdc.adcId, ADC_REGULAR_CHANNEL, 0);
    /* configure the ADC sync mode */
    adc_sync_mode_config(ADC_SYNC_MODE_INDEPENDENT);
    adc_external_trigger_config(tObjAdc.adcId,ADC_REGULAR_CHANNEL,EXTERNAL_TRIGGER_DISABLE);
    adc_external_trigger_config(tObjAdc.adcId,ADC_INSERTED_CHANNEL,EXTERNAL_TRIGGER_DISABLE);
    adc_special_function_config(tObjAdc.adcId, ADC_SCAN_MODE, DISABLE);
    adc_end_of_conversion_config(tObjAdc.adcId, ADC_EOC_SET_CONVERSION);
    /* enable ADC interface */
    adc_enable(tObjAdc.adcId);
    /* ADC calibration and reset calibration */
    adc_calibration_enable(tObjAdc.adcId);
}

/**********************************************************************/
/**
  * \brief
  *
  * \param
  *
  * \retval none
  */
/**********************************************************************/
UINT32 HalGetAdcValue(UINT32 adcId, UINT16 *adcData)
{
    UINT16 i;

    /* ADC software trigger enable */
  adc_software_trigger_enable(adcId, ADC_REGULAR_CHANNEL);

    for(i = 0; i < 100; i++)
  {
        if( RESET == adc_flag_get(adcId, ADC_FLAG_EOC) )
        {
            zxUTILS_DelayNus(10);
        }
        else
    {
            break;
        }
  }
    if( 100 == i )
    {
        return COMMON_ERROR;
    }

    *adcData = adc_regular_data_read(adcId);

    adc_flag_clear(adcId, ADC_STAT_EOC);

    return COMMON_OK;
}

/************************************************/
/**
 * \file hal_gpio.c
 * \brief GPIO适配层代码
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_gpio.h"
#include "gd32f4xx_rcu.h"
#include "gd32f4xx_gpio.h"
#include "gd32f4xx_exti.h"

/**********************************************************************/
/**
  * \brief 使能对应GPIO模块的时钟
  *
  * \param bank:RCU_GPIOA,RCU_GPIOB......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetGpioClkEn(UINT32 bank)
{
    rcu_periph_clock_enable((rcu_periph_enum)bank);
}

/**********************************************************************/
/**
  * \brief 设置GPIO输入输出模式和上下拉电阻
  *
  * \param bank:RCU_GPIOA,RCU_GPIOB......
  * \param mode：输入输出模式
  * \param pull_up_down:上下拉电阻
  * \param pin:管脚
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetGpioMode(UINT32 bank, UINT32 mode, UINT32 pull_up_down, UINT32 pin)
{
    gpio_mode_set(bank, mode, pull_up_down, pin);
}

/**********************************************************************/
/**
  * \brief 设置GPIO输出模式和速率
  *
  * \param bank:RCU_GPIOA,RCU_GPIOB......
  * \param otype：输出模式
  * \param speed:速率
  * \param pin:管脚
  *
  * \retval v
  */
/**********************************************************************/
VOID HalSetGpioSpeed(UINT32 bank, UCHAR otype, UINT32 speed, UINT32 pin)
{
    gpio_output_options_set(bank, otype, speed, pin);
}

/**********************************************************************/
/**
  * \brief 设置GPIO管脚输出的高低电平
  *
  * \param bank:RCU_GPIOA,RCU_GPIOB......
  * \param bit：管脚
  * \param bit_value:电平
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetGpioDataout(UINT32 bank, UINT32 bit, UCHAR bit_value)
{
    gpio_bit_write(bank, bit, (bit_status)bit_value);
}

/**********************************************************************/
/**
  * \brief 读取GPIO的高低电平状态
  *
  * \param bank:RCU_GPIOA,RCU_GPIOB......
  * \param bit：管脚
  *
  * \retval 管脚高低电平
  */
/**********************************************************************/
UCHAR HalGetGpioDatain(UINT32 bank, UINT32 bit)
{
    return gpio_input_bit_get(bank, bit);
}

/**********************************************************************/
/**
  * \brief GPIO端口状态翻转
  *
  * \param bank:RCU_GPIOA,RCU_GPIOB......
  * \param bit：管脚
  *
  * \retval null
  */
/**********************************************************************/
VOID HalGpioToggle(UINT32 bank, UINT32 bit)
{
    gpio_bit_toggle(bank, bit);
}

/**********************************************************************/
/**
  * \brief 设置GPIO备用功能
  *
  * \param bank:RCU_GPIOA,RCU_GPIOB......
  * \param afSel：备用功能
  * \param bit：管脚
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetGpioAf(UINT32 bank, UINT32 afSel, UINT32 bit)
{
    gpio_af_set(bank, afSel, bit);
}

/**********************************************************************/
/**
  * \brief 初始化GPIO为通用模式
  *
  * \param tObjNorGpio: 抽象属性参数
  *
  * \retval null
  */
/**********************************************************************/
VOID HalInitGpioNormal(_T_Gpio_Tbl tObjNorGpio)
{
    HalSetGpioClkEn(tObjNorGpio.clkPort);

    if( GPIO_MODE_AF == tObjNorGpio.mode )
    {
        HalSetGpioAf(tObjNorGpio.gpioPort, tObjNorGpio.af, tObjNorGpio.gpioBit);
    }

    HalSetGpioMode(tObjNorGpio.gpioPort, tObjNorGpio.mode, tObjNorGpio.upDowd, tObjNorGpio.gpioBit);
    if((GPIO_OTYPE_NONE != tObjNorGpio.otype) && (GPIO_SPEED_NONE != tObjNorGpio.speed))
    {
            HalSetGpioSpeed(tObjNorGpio.gpioPort, tObjNorGpio.otype, tObjNorGpio.speed,tObjNorGpio.gpioBit);
    }

    if(GPIO_NO_INIT != tObjNorGpio.def)
    {
            HalSetGpioDataout(tObjNorGpio.gpioPort, tObjNorGpio.gpioBit, tObjNorGpio.def);
    }
}

/**********************************************************************/
/**
  * \brief 初始化GPIO为中断模式
  *
  * \param tObjExitGpio: 抽象属性参数
  *
  * \retval null
  */
/**********************************************************************/
VOID HalInitGpioExit(_T_Gpio_Exit_Tbl tObjExitGpio)
{
    HalSetGpioClkEn(RCU_SYSCFG);
    HalSetGpioClkEn(tObjExitGpio.clkPort);

    HalSetGpioMode(tObjExitGpio.gpioPort, tObjExitGpio.mode, tObjExitGpio.upDowd, tObjExitGpio.gpioBit);

    nvic_irq_enable(tObjExitGpio.nvicIrq, tObjExitGpio.nvicPrePrio, tObjExitGpio.nvicSubPrio);

    syscfg_exti_line_config(tObjExitGpio.extiPort, tObjExitGpio.extiPin);

    exti_init((exti_line_enum)tObjExitGpio.exitLinex, (exti_mode_enum)tObjExitGpio.exitMode, (exti_trig_type_enum)tObjExitGpio.exitTrigType);
    exti_interrupt_flag_clear((exti_line_enum)tObjExitGpio.exitLinex);
}


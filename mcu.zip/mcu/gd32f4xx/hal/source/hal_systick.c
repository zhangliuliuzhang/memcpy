/************************************************/
/**
 * \file hal_systick.c
 * \brief systickÊÊÅä²ã´úÂë
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_systick.h"
#include "common.h"
#include "gd32f4xx.h"

/**********************************************************************/
/**
  * \brief     configure systick
  *
  * \param  null
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSystickConfig(VOID)
{
    /* setup systick timer for 1000Hz interrupts */
    if (SysTick_Config(SystemCoreClock / 1000U)){
        /* capture error */
        while (1){
        }
    }
    /* configure the systick handler priority */
    NVIC_SetPriority(SysTick_IRQn, 0x00U);
}


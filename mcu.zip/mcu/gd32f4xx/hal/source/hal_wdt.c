/************************************************/
/**
 * \file hal_adc.c
 * \brief ADC适配层代码
 *
 * \author 10294149
 * \date   2021.8
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_wdt.h"
#include "common.h"
#include "gd32f4xx.h"

/**********************************************************************/
/**
  * \brief 	configure wdt
  *
  * \param  null
  *
  * \retval null
  */
/**********************************************************************/
VOID HalFwdgtConfig(UINT16 reloadTime)
{
    UINT16 reloadValue = 0;

    /* enable IRC32K */
    rcu_osci_on(RCU_IRC32K);

    /* confiure FWDGT counter clock: 32KHz(IRC32K) / 128 = 0.25 KHz */
    reloadValue = (32000/128) * reloadTime;
    fwdgt_config(reloadValue, FWDGT_PSC_DIV128);

    /* After 16 seconds to generate a reset */
    fwdgt_enable();
}

/**********************************************************************/
/**
  * \brief 	reload wdt
  *
  * \param  null
  *
  * \retval null
  */
/**********************************************************************/
VOID HalFwdgtReload(VOID)
{
    fwdgt_counter_reload();
}

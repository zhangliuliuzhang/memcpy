/************************************************/
/**
 * \file hal_timer.c
 * \brief TIMER适配层代码
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_timer.h"
#include "gd32f4xx_rcu.h"
#include "gd32f4xx_timer.h"

/**********************************************************************/
/**
  * \brief     初始化TIMER模块时钟
  *
  * \param bank: RCU_TIMER1,RCU_TIMER2......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetTimerClkEn(UINT32 bank)
{
    rcu_periph_clock_enable((rcu_periph_enum)bank);
}

/**********************************************************************/
/**
  * \brief     去初始化TIMER模块
  *
  * \param timerId:TIMER1,TIMER2......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalDeintTimer(UINT32 timerId)
{
    timer_deinit(timerId);
}

/**********************************************************************/
/**
  * \brief     使能TIMER模块
  *
  * \param timerId:TIMER1,TIMER2......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalEnableTimer(UINT32 timerId)
{
    timer_enable(timerId);
}

/**********************************************************************/
/**
  * \brief     使能TIMER模块的中断
  *
  * \param timerId:TIMER1,TIMER2......
  * \param interrupt:TIMER_INT_UP,TIMER_INT_CH0......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalEnableTimerInt(UINT32 timerId, UINT32 interrupt)
{
    timer_interrupt_enable(timerId, interrupt);
}

VOID HalDisableTimerInt(UINT32 timerId, UINT32 interrupt)
{
    timer_interrupt_disable(timerId, interrupt);
}
/**********************************************************************/
/**
  * \brief     清除TIMER模块的中断标志位
  *
  * \param timerId:TIMER1,TIMER2......
  * \param intFlag:TIMER_INT_FLAG_UP,TIMER_INT_FLAG_CH0......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalClearTimerIntFlag(UINT32 timerId, UINT32 intFlag)
{
    timer_interrupt_flag_clear(timerId, intFlag);
}

/**********************************************************************/
/**
  * \brief     获取TIMER模块的中断标志位状态
  *
  * \param timerId:TIMER1,TIMER2......
  * \param intFlag:TIMER_INT_FLAG_UP,TIMER_INT_FLAG_CH0......
  *
  * \retval null
  */
/**********************************************************************/
e_FlagStat HalGetTimerIntFlag(UINT32 timerId, UINT32 intFlag)
{
    return (e_FlagStat)timer_interrupt_flag_get(timerId, intFlag);
}

/**********************************************************************/
/**
  * \brief 初始化Timer
  *
  * \param tObjTimer: 抽象属性参数
  *
  * \retval none
  */
/**********************************************************************/
VOID HalInitTimer(_T_Normal_Timer_Tbl tObjTimer)
{
    timer_parameter_struct timer_initpara;

    HalSetTimerClkEn(tObjTimer.clkPort);

    HalDeintTimer(tObjTimer.timerId);

    timer_initpara.prescaler         = tObjTimer.prescaler;
    timer_initpara.alignedmode       = tObjTimer.alignedmode;
    timer_initpara.counterdirection  = tObjTimer.counterdirection;
    timer_initpara.period            = tObjTimer.period;
    timer_initpara.clockdivision     = tObjTimer.clockdivision;
  timer_initpara.repetitioncounter = 0;

    timer_init(tObjTimer.timerId, &timer_initpara);

    HalEnableTimer(tObjTimer.timerId);

    if( TIMER_INT_TYPE_NONE != tObjTimer.intType )
    {
        HalEnableTimerInt(tObjTimer.timerId, tObjTimer.intType);
        nvic_irq_enable(tObjTimer.nvicIrq, tObjTimer.nvicPrePrio, tObjTimer.nvicSubPrio);
//        HalClearTimerIntFlag(tObjTimer.timerId, TIMER_INT_FLAG_UP);
    }
}

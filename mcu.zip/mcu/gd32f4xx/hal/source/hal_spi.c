/************************************************/
/**
 * \file hal_spi.c
 * \brief SPI适配层代码
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_spi.h"
#include "gd32f4xx_rcu.h"
#include "gd32f4xx_spi.h"
#include "common.h"

/**********************************************************************/
/**
  * \brief     初始化SPI模块时钟
  *
  * \param bank: RCU_SPI1,RCU_SPI2......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetSpiClkEn(UINT32 bank)
{
    rcu_periph_clock_enable((rcu_periph_enum)bank);
}

/**********************************************************************/
/**
  * \brief     去初始化SPI模块
  *
  * \param spiId:SPI0,SPI1......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalDeintSpi(UINT32 spiId)
{
    spi_i2s_deinit(spiId);
}

/**********************************************************************/
/**
  * \brief     使能SPI模块
  *
  * \param spiId:SPI0,SPI1......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalEnableSpi(UINT32 spiId)
{
    spi_enable(spiId);
}

/**********************************************************************/
/**
  * \brief     SPI模块读写一个字节
  *
  * \param spiId: SPI0,SPI1......
    * \param sendByte: 发送字节
  * \param recvData: 接收字节
  *
  * \retval null
  */
/**********************************************************************/
UINT32 HalSpiWriteReadByte( UINT32 spiId, BYTE *sendByte, BYTE *recvData )
{
    UINT32 i;

    INPUT_POINTER_CHECK(sendByte);
    INPUT_POINTER_CHECK(recvData);

    for(i = 0; i < 500; i++)
    {
        if(RESET == spi_i2s_flag_get(spiId, SPI_FLAG_TBE))
        {
            zxUTILS_DelayNus(1);
        }
        else
        {
            break;
        }
    }
    if( 500 == i )
    {
        return COMMON_ERROR;
    }
  spi_i2s_data_transmit(spiId, *sendByte);

    for(i = 0; i < 500; i++)
    {
        if(RESET == spi_i2s_flag_get(spiId, SPI_FLAG_RBNE))
        {
            zxUTILS_DelayNus(1);
        }
        else
        {
            break;
        }
    }
    if( 500 == i )
    {
        return COMMON_ERROR;
    }

  *recvData =  spi_i2s_data_receive(spiId);

    return COMMON_OK;
}

/**********************************************************************/
/**
  * \brief     SPI模块读写一个半字
  *
  * \param spiId: SPI0,SPI1......
    * \param sendByte: 发送半字
  * \param recvData: 接收半字
  *
  * \retval null
  */
/**********************************************************************/
UINT32 HalSpiWriteReadHalfWord( UINT32 spiId, UINT16 *sendHalfWord, UINT16 *recvHalfWord )
{
    UINT32 i;

    INPUT_POINTER_CHECK(sendHalfWord);
    INPUT_POINTER_CHECK(recvHalfWord);

    for(i = 0; i < 500; i++)
    {
        if(RESET == spi_i2s_flag_get(spiId, SPI_FLAG_TBE))
        {
            zxUTILS_DelayNus(1);
        }
        else
        {
            break;
        }
    }
    if( 500 == i )
    {
        return COMMON_ERROR;
    }
  spi_i2s_data_transmit(spiId, *sendHalfWord);

    for(i = 0; i < 500; i++)
    {
        if(RESET == spi_i2s_flag_get(spiId, SPI_FLAG_RBNE))
        {
            zxUTILS_DelayNus(1);
        }
        else
        {
            break;
        }
    }
    if( 500 == i )
    {
        return COMMON_ERROR;
    }

  *recvHalfWord =  spi_i2s_data_receive(spiId);

    return COMMON_OK;
}

/**********************************************************************/
/**
  * \brief 初始化SPI
  *
  * \param tObjSpi: 抽象属性参数
  *
  * \retval none
  */
/**********************************************************************/
VOID HalInitSpi(_T_Spi_Tbl tObjSpi)
{
    spi_parameter_struct spi_init_struct;

    HalSetSpiClkEn(tObjSpi.clkPort);

    HalDeintSpi(tObjSpi.spiId);

    spi_init_struct.trans_mode           = tObjSpi.transMode;
    spi_init_struct.device_mode          = tObjSpi.deviceMode;
    spi_init_struct.frame_size           = tObjSpi.frameSize;
    spi_init_struct.clock_polarity_phase = tObjSpi.clkPolarPhase;
    spi_init_struct.nss                  = tObjSpi.nss;
    spi_init_struct.prescale             = tObjSpi.prescale;
    spi_init_struct.endian               = tObjSpi.endian;

    spi_init(tObjSpi.spiId, &spi_init_struct);

    HalEnableSpi(tObjSpi.spiId);
}

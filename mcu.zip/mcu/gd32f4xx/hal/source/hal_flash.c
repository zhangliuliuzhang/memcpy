/************************************************/
/**
 * \file hal_flash.c
 * \brief FLASH适配层代码
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_flash.h"
#include "gd32f4xx_fmc.h"
#include <string.h>
/**************************************************************************
*                       如下代码为demo板移植过来的                               *
**************************************************************************/

/*!
    \brief      gets the sector of a given address
    \param[in]  address: a given address(0x08000000~0x080FFFFF)
    \param[out] none
    \retval     the sector of a given address
*/
UINT32 fmc_sector_get(UINT32 address)
{
    UINT32 sector = 0;
    if((address < ADDR_FMC_SECTOR_1) && (address >= ADDR_FMC_SECTOR_0))
    {
        sector = CTL_SECTOR_NUMBER_0;
    }
    else if((address < ADDR_FMC_SECTOR_2) && (address >= ADDR_FMC_SECTOR_1))
    {
        sector = CTL_SECTOR_NUMBER_1;
    }
    else if((address < ADDR_FMC_SECTOR_3) && (address >= ADDR_FMC_SECTOR_2))
    {
        sector = CTL_SECTOR_NUMBER_2;
    }
    else if((address < ADDR_FMC_SECTOR_4) && (address >= ADDR_FMC_SECTOR_3))
    {
        sector = CTL_SECTOR_NUMBER_3;
    }
    else if((address < ADDR_FMC_SECTOR_5) && (address >= ADDR_FMC_SECTOR_4))
    {
        sector = CTL_SECTOR_NUMBER_4;
    }
    else if((address < ADDR_FMC_SECTOR_6) && (address >= ADDR_FMC_SECTOR_5))
    {
        sector = CTL_SECTOR_NUMBER_5;
    }
    else if((address < ADDR_FMC_SECTOR_7) && (address >= ADDR_FMC_SECTOR_6))
    {
        sector = CTL_SECTOR_NUMBER_6;
    }
    else if((address < ADDR_FMC_SECTOR_8) && (address >= ADDR_FMC_SECTOR_7))
    {
        sector = CTL_SECTOR_NUMBER_7;
    }
    else if((address < ADDR_FMC_SECTOR_9) && (address >= ADDR_FMC_SECTOR_8))
    {
        sector = CTL_SECTOR_NUMBER_8;
    }
    else if((address < ADDR_FMC_SECTOR_10) && (address >= ADDR_FMC_SECTOR_9))
    {
        sector = CTL_SECTOR_NUMBER_9;
    }
    else if((address < ADDR_FMC_SECTOR_11) && (address >= ADDR_FMC_SECTOR_10))
    {
        sector = CTL_SECTOR_NUMBER_10;
    }
    else{
        sector = CTL_SECTOR_NUMBER_11;
    }
    return sector;
}

/*!
    \brief      erases the sector of a given sector number
    \param[in]  fmc_sector: a given sector number
      \arg        CTL_SECTOR_NUMBER_0: sector 0
      \arg        CTL_SECTOR_NUMBER_1: sector 1
      \arg        CTL_SECTOR_NUMBER_2: sector 2
      \arg        CTL_SECTOR_NUMBER_3：sector 3
      \arg        CTL_SECTOR_NUMBER_4: sector 4
      \arg        CTL_SECTOR_NUMBER_5: sector 5
      \arg        CTL_SECTOR_NUMBER_6: sector 6
      \arg        CTL_SECTOR_NUMBER_7：sector 7
      \arg        CTL_SECTOR_NUMBER_8: sector 8
      \arg        CTL_SECTOR_NUMBER_9: sector 9
      \arg        CTL_SECTOR_NUMBER_10: sector 10
      \arg        CTL_SECTOR_NUMBER_11：sector 11
    \param[out] none
    \retval     none
*/
VOID fmc_erase_sector(UINT32 fmc_sector)
{
    uint8_t index =0;

    /* unlock the flash program erase controller */
    fmc_unlock();
    /* clear pending flags */
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    /* wait the erase operation complete*/
    /*sector erase时间，最长450ms，最短60ms，典型时间100ms*/
    if(FMC_READY != fmc_sector_erase(fmc_sector))
    {
        for(index=0; index<100; index++)
        {
            if(FMC_READY != fmc_ready_wait())
            {
                zxUTILS_DelayNms(5);
            }
            else
            {
                break;
            }
        }
    }
    /* lock the flash program erase controller */
    fmc_lock();
}

/*!
    \brief      write 32 bit length data to a given address
    \param[in]  address: a given address(0x08000000~0x080FFFFF)
    \param[in]  length: data length
    \param[in]  data_32: data pointer
    \param[out] none
    \retval     none
*/
VOID fmc_write_32bit_data(UINT32 address, UINT32 length, UINT32* data_32)
{
    UINT32 i;
    uint8_t index=0;
    /* unlock the flash program erase controller */
    fmc_unlock();
    /* clear pending flags */
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);

    /* write data_32 to the corresponding address */
    for(i = 0; i < length; i++)
    {
        if(FMC_READY == fmc_word_program(address, data_32[i]))
        {
            address = address + 4;
        }
        else
        {
            /*word programming time min:200us,max:400us*/
            for(index=0; index<40; index++)
            {
                if(FMC_READY != fmc_ready_wait())
                {
                    zxUTILS_DelayNus(10);
                }
                else
                {
                    break;
                }
            }
        }
    }
    /* lock the flash program erase controller */
    fmc_lock();
}

/*!
    \brief      read 32 bit length data from a given address
    \param[in]  address: a given address(0x08000000~0x080FFFFF)
    \param[in]  length: data length
    \param[in]  data_32: data pointer
    \param[out] none
    \retval     none
*/
VOID fmc_read_32bit_data(UINT32 address, UINT32 length, INT32* data_32)
{
    UINT32 i;
    for(i=0; i<length; i++)
    {
        data_32[i] = *(__IO INT32*)address;
        address=address + 4;
    }
}

/*!
    \brief      write 16 bit length data to a given address
    \param[in]  address: a given address(0x08000000~0x080FFFFF)
    \param[in]  length: data length
    \param[in]  data_16: data pointer
    \param[out] none
    \retval     none
*/
UINT32 fmc_write_16bit_data(UINT32 address, UINT32 length, int16_t* data_16)
{
    //UINT32 StartSector, EndSector,i;
    UINT32 i;
    uint8_t index=0;
    /* unlock the flash program erase controller */
    fmc_unlock();
    /* clear pending flags */
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
#if 0
    /* get the number of the start and end sectors */
    StartSector = fmc_sector_get(address);
    EndSector = fmc_sector_get(address + 2*length);
    /* each time the sector number increased by 8, refer to the sector definition */
    for(i = StartSector; i < EndSector; i += 8)
    {
        if(FMC_READY != fmc_sector_erase(i))
        {
            //while(1);
            /*erase sector time:min:60ms,max:450ms,typ:100ms*/
            for(index=0; index<100; index++)
            {
                if(FMC_READY != fmc_ready_wait())
                {
                    zxUTILS_DelayNms(5);
                }
                else
                {
                    break;
                }
            }
        }
    }
#endif
    /* write data_16 to the corresponding address */
    for(i=0; i<length; i++)
    {
        if(FMC_READY == fmc_halfword_program(address, data_16[i]))
        {
            address = address + 2;
        }
        else
        {
            //while(1);
            /*word programming time min:200us,max:400us*/
            for(index=0; index<40; index++)
            {
                if(FMC_READY != fmc_ready_wait())
                {
                    zxUTILS_DelayNus(10);
                }
                else
                {
                    break;
                }
            }
        }
    }
    /* lock the flash program erase controller */
    fmc_lock();
    return 1;
}

/*!
    \brief      read 16 bit length data to a given address
    \param[in]  address: a given address(0x08000000~0x080FFFFF)
    \param[in]  length: data length
    \param[in]  data_16: data pointer
    \param[out] none
    \retval     none
*/
VOID fmc_read_16bit_data(UINT32 address, UINT32 length, int16_t* data_16)
{
    UINT32 i;
    for(i=0; i<length; i++)
    {
        data_16[i] = *(__IO int16_t*)address;
        address = address + 2;
    }
}

/*!
    \brief      write 8 bit length data to a given address
    \param[in]  address: a given address(0x08000000~0x080FFFFF)
    \param[in]  length: data length
    \param[in]  data_8: data pointer
    \param[out] none
    \retval     none
*/
UINT32 fmc_write_8bit_data(UINT32 address, UINT32 length, CHAR* data_8)
{
    //UINT32 StartSector, EndSector,i;
    UINT32 i;
    CHAR index=0;
    /* unlock the flash program erase controller */
    fmc_unlock();
    /* clear pending flags */
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
#if 0
    /* get the number of the start and end sectors */
    StartSector = fmc_sector_get(address);
    EndSector = fmc_sector_get(address + length);
    /* each time the sector number increased by 8, refer to the sector definition */
    for(i = StartSector; i <= EndSector; i += 8)
    {
        if(FMC_READY != fmc_sector_erase(i))
        {
            //while(1);
            /*erase sector time:min:60ms,max:450ms,typ:100ms*/
            for(index=0; index<100; index++)
            {
                if(FMC_READY != fmc_ready_wait())
                {
                    zxUTILS_DelayNms(5);
                }
                else
                {
                    break;
                }
            }
        }
    }
#endif
    /* write data_8 to the corresponding address */
    for(i=0; i<length; i++)
    {
        if(FMC_READY == fmc_byte_program(address, data_8[i]))
        {
            address++;
        }
        else
        {
            //while(1);
            /*word programming time min:200us,max:400us*/
            for(index=0; index<40; index++)
            {
                if(FMC_READY != fmc_ready_wait())
                {
                    zxUTILS_DelayNus(10);
                }
                else
                {
                    break;
                }
            }
        }
    }
    /* lock the flash program erase controller */
    fmc_lock();
    return 1;
}

/*!
    \brief      read 8 bit length data to a given address
    \param[in]  address: a given address(0x08000000~0x080FFFFF)
    \param[in]  length: data length
    \param[in]  data_8: data pointer
    \param[out] none
    \retval     none
*/
VOID fmc_read_8bit_data(UINT32 address, UINT32 length, CHAR* data_8)
{
    UINT32 i;

    for(i=0; i<length; i++)
    {
        data_8[i] = *(__IO CHAR*)address;
        address++;
    }
}

/**************************************************************************
*                       如下代码为平台封装的                               *
**************************************************************************/
/**********************************************************************/
/**
  * \brief 读flash
  *
  * \param addr：地址
  * \param pucBuf: 数据空间
  * \param length：读取数据长度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
VOID HalFlashRead(UINT32 addr, UCHAR *pucBuf, UINT32 length)
{
    __disable_irq();
    fmc_read_8bit_data(addr, length, (CHAR*)pucBuf);
    __enable_irq();
}

/**********************************************************************/
/**
  * \brief 读flash--一次读一个字-4字节
  *
  * \param addr：地址
  * \param pucBuf: 数据空间
  * \param length：读取数据长度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
VOID HalFlashReadWord(UINT32 addr, INT32 *pucBuf, UINT32 length)
{
    __disable_irq();
    fmc_read_32bit_data(addr, length, (INT32*)pucBuf);
    __enable_irq();
}


/**********************************************************************/
/**
  * \brief 写flash--一次写一个字-4字节
  *
  * \param addr：地址
  * \param pucBuf: 数据空间
  * \param length：写入数据长度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
VOID HalFlashWriteWord(UINT32 addr, UINT32 *pucBuf, UINT32 length)
{
    __disable_irq();
    fmc_write_32bit_data(addr, length, pucBuf);
    __enable_irq();
}

/**********************************************************************/
/**
  * \brief 写flash
  *
  * \param addr：地址
  * \param pucBuf: 数据空间
  * \param length：写入数据长度
  *
  * \retval 成功错误码
  */
/**********************************************************************/
VOID HalFlashWrite(UINT32 addr, UCHAR *pucBuf, UINT32 length)
{
    __disable_irq();
    fmc_write_8bit_data(addr, length, (CHAR*)pucBuf);
    __enable_irq();
}

/**********************************************************************/
/**
  * \brief 擦除一段FLASH空间
  *
  * \param startSecNum：起始sector
  * \param endSecNum: 结束sector
  *
  * \retval 成功错误码
  */
/**********************************************************************/
VOID HalEraseFlashSectors(UINT32 startSecNum,UINT32 endSecNum)
{
  UINT32 i;

    __disable_irq();
    for(i = startSecNum; i <= endSecNum; i += 8)
    {
        fmc_erase_sector(i);
    }
    __enable_irq();

}

/**********************************************************************/
/**
  * \brief 地址转换为sector数
  *
  * \param addr 地址
  *
  * \retval 成功错误码
  */
/**********************************************************************/
UINT32 HalFlashAddrToSector(UINT32 addr)
{
    return fmc_sector_get(addr);
}

/**
  * @brief  This function move data in MCU flash.
  * @param  destSectorStart: dest addr start sector
  * @param  destSectorEnd: dest addr end sector
  * @param  destAddr: dest addr
  * @param  srcAddr: source addr
  * @param  lenth: data lenth
  * @retval SUCCESS or ERROR
  */
UINT32 HalFlashDataMove(UINT32 destSectorStart, UINT32 destSectorEnd, UINT32 destAddr, UINT32 srcAddr, UINT32 lenth)
{
    uint8_t i;

    for(i = 0; i < 5; i++)
    {
        /* first erase sector */
        HalEraseFlashSectors(destSectorStart, destSectorEnd);
        /* second move data */
        HalFlashWriteWord(destAddr, (UINT32*)srcAddr, lenth/4);

        if( memcmp((VOID*)(destAddr),(VOID*)(srcAddr), lenth) == 0)
        {
            return COMMON_OK;
        }
    }

    return COMMON_ERROR;
}

VOID HalFlashEnableWrProtect(VOID)
{
    fmc_unlock();
    fmc_flag_clear(FMC_FLAG_END | FMC_FLAG_OPERR | FMC_FLAG_WPERR | FMC_FLAG_PGMERR | FMC_FLAG_PGSERR);
    ob_unlock();
    ob_write_protection_enable(OB_WP_4);
    ob_lock();
    fmc_lock();
}

/* Started by AICoder, pid:g9b160d965i113214e860887d0c29b3e6e762fc3 */
/*****************************************************************************
 *  函数名称   : HalFlashWriteProtectTest
 *  功能描述   : 测试闪存写保护功能，包括擦除和写入操作，并验证数据
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 使用UART打印擦除和写入后的数据，以便验证操作结果
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 HalFlashWriteProtectTest(VOID)
{
    UCHAR tmpData[10] = {0}; // 用于存储读取的数据
    UINT32 j = 0;

    // 擦除指定扇区
    fmc_erase_sector(CTL_SECTOR_NUMBER_4);

    // 打印擦除后的数据
    UARTprintf("\r\n erase after :");
    HalFlashRead(ADDR_FMC_SECTOR_4, tmpData, sizeof(tmpData));
    for (j = 0; j < sizeof(tmpData); j++)
    {
        UARTprintf(" 0x%x ", tmpData[j]);
    }

    return COMMON_OK;
}
/* Ended by AICoder, pid:g9b160d965i113214e860887d0c29b3e6e762fc3 */

VOID HalFlashDisableWrProtect(VOID)
{
    ob_unlock();
    ob_write_protection_disable(OB_WP_4);
    ob_lock();
}


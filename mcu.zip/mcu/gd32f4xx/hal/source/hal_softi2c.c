/************************************************/
/**
 * \file hal_softi2c.c
 * \brief I2C ��������
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_softi2c.h"
#include "gd32f4xx_i2c.h"
#include "string.h"

T_Soft_I2c_Tbl s_SoftI2cBus[SOFT_I2C_MAX_SUPPORT_NUM] = {0};

VOID HalSoftI2cDelay(UINT32 iicIndex);
VOID HalSoftI2cStart(UINT32 iicIndex);
VOID HalSoftI2cStop(UINT32 iicIndex);
UINT32 HalSoftI2cWaitAck(UINT32 iicIndex);
VOID HalSoftI2cSendByte(UINT32 iicIndex, UCHAR data);
UCHAR HalSoftI2cRecvByte(UINT32 iicIndex);

VOID HalSoftI2cDelay(UINT32 iicIndex)
{
    UINT32 loop = s_SoftI2cBus[iicIndex].delay;

    while(loop--)
    {
        __NOP();
    }
}

VOID HalSoftI2cStart(UINT32 iicIndex)
{
    s_SoftI2cBus[iicIndex].sdaCtrl(E_SET);
    s_SoftI2cBus[iicIndex].sclCtrl(E_SET);
    HalSoftI2cDelay(iicIndex);

    s_SoftI2cBus[iicIndex].sdaCtrl(E_RESET);
    HalSoftI2cDelay(iicIndex);
}

VOID HalSoftI2cStop(UINT32 iicIndex)
{
    s_SoftI2cBus[iicIndex].sclCtrl(E_SET);
    s_SoftI2cBus[iicIndex].sdaCtrl(E_RESET);
    HalSoftI2cDelay(iicIndex);

    s_SoftI2cBus[iicIndex].sdaCtrl(E_SET);
    HalSoftI2cDelay(iicIndex);
}

VOID HalSoftI2cAck(UINT32 iicIndex)
{
    s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
    s_SoftI2cBus[iicIndex].sdaCtrl(E_RESET);
    HalSoftI2cDelay(iicIndex);

    s_SoftI2cBus[iicIndex].sclCtrl(E_SET);
    HalSoftI2cDelay(iicIndex);
    s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
}

VOID HalSoftI2cNack(UINT32 iicIndex)
{
    s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
    s_SoftI2cBus[iicIndex].sdaCtrl(E_SET);
    HalSoftI2cDelay(iicIndex);

    s_SoftI2cBus[iicIndex].sclCtrl(E_SET);
    HalSoftI2cDelay(iicIndex);
    s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
}

// ʱ��Ϊ��״̬��ʱ�������ߵ�״̬
// ���ź���ACK ���ź���NACK
UINT32 HalSoftI2cWaitAck(UINT32 iicIndex)
{
    UINT32 count = 0;

    s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
    s_SoftI2cBus[iicIndex].sdaEx(0);
    HalSoftI2cDelay(iicIndex);

    s_SoftI2cBus[iicIndex].sclCtrl(E_SET);
    HalSoftI2cDelay(iicIndex);
    while (s_SoftI2cBus[iicIndex].sdaRead())
    {
        count++;
        if (count > 250)
        {
             UARTprintf("%s sda high\n", __func__);
            s_SoftI2cBus[iicIndex].sdaEx(1);
            HalSoftI2cStop(iicIndex);
            return 1;
        }
    }

    s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
    HalSoftI2cDelay(iicIndex);

    s_SoftI2cBus[iicIndex].sdaEx(1);
     UARTprintf("%s sda low\n", __func__);

    return 0;
}

VOID HalSoftI2cSendByte(UINT32 iicIndex, UCHAR data)
{
    UCHAR i = 0;

    // UARTprintf("%s data :0x%x!\n", __FUNCTION__, data);

    for (i = 0; i < 8; i++)
    {
        s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
        if(data & 0x80)
        {
            // UARTprintf("%s sda high\n", __FUNCTION__);
            s_SoftI2cBus[iicIndex].sdaCtrl(E_SET);
        }
        else
        {
            // UARTprintf("%s sda low\n", __FUNCTION__);
            s_SoftI2cBus[iicIndex].sdaCtrl(E_RESET);
        }
        HalSoftI2cDelay(iicIndex);
        s_SoftI2cBus[iicIndex].sclCtrl(E_SET);
        HalSoftI2cDelay(iicIndex);
        data = data << 1;
    }
}

UCHAR HalSoftI2cRecvByte(UINT32 iicIndex)
{
    UCHAR i = 0, recvData = 0;

    s_SoftI2cBus[iicIndex].sdaEx(0);

    for (i = 0; i < 8; i++)
    {
        recvData = recvData << 1;

        s_SoftI2cBus[iicIndex].sclCtrl(E_SET);
        HalSoftI2cDelay(iicIndex);

        if(s_SoftI2cBus[iicIndex].sdaRead() == E_SET)
        {
            recvData |= 0x1;
        }

        s_SoftI2cBus[iicIndex].sclCtrl(E_RESET);
        HalSoftI2cDelay(iicIndex);
    }

    s_SoftI2cBus[iicIndex].sdaEx(1);

    return recvData;
}


/**********************************************************************/
/**
* \brief i2c���߷�������
  *
  * \param i2cId: I2C0,I2C1......
  * \param slaveAddr: ��������ַ
    * \param txBuf: ��������
  * \param count: ���ݳ���
  *
  * \retval �ɹ�������
  */
/**********************************************************************/
UINT32 HalSoftI2cSendData(UINT32 iicIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *txBuf, UINT32 count)
{
    UINT32 i = 0;
    UARTprintf("%s slave addr :0x%x! , registerAddr addr :0x%x!, data :0x%x\n", __func__, slaveAddr, registerAddr, *txBuf);
    HalSoftI2cStart(iicIndex);

    HalSoftI2cSendByte(iicIndex, slaveAddr & 0xFE);
    if (HalSoftI2cWaitAck(iicIndex))
    {
        UARTprintf("%s slave addr error!\n", __func__);
        return SOFT_I2C_BUS_ERROR;
    }

    HalSoftI2cSendByte(iicIndex, registerAddr);
    if (HalSoftI2cWaitAck(iicIndex))
    {
        UARTprintf("%s register addr error!\n", __func__);
        return SOFT_I2C_BUS_ERROR;
    }

    HalSoftI2cSendByte(iicIndex, count);
    if (HalSoftI2cWaitAck(iicIndex))
    {
        UARTprintf("%s register addr error!\n", __func__);
        return SOFT_I2C_BUS_ERROR;
    }

    for(i = 0; i < count; i++)
    {
        /* data transmission */
        HalSoftI2cSendByte(iicIndex, txBuf[i]);
        UARTprintf("txBuf[%d] = 0x%x", i, txBuf[i]);
        if (HalSoftI2cWaitAck(iicIndex))
        {
            UARTprintf("%s data error!\n", __func__);
            return SOFT_I2C_BUS_ERROR;
        }
     }

   HalSoftI2cStop(iicIndex);

   return SOFT_I2C_BUS_OK;
}

/**********************************************************************/
/**
* \brief i2c���߽�������
  *
  * \param i2cId: I2C0,I2C1......
  * \param slaveAddr: ��������ַ
    * \param rxBuf: ��������
  * \param count: ���ݳ���
  *
  * \retval �ɹ�������
  */
/**********************************************************************/
UINT32 HalSoftI2cRecvData(UINT32 iicIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *rxBuf, UINT32 count)
{
    UARTprintf("%s slave addr :0x%x!\n", __func__, slaveAddr);

    HalSoftI2cStart(iicIndex);

    HalSoftI2cSendByte(iicIndex, slaveAddr & 0xFE);
    if (HalSoftI2cWaitAck(iicIndex))
    {
        UARTprintf("%s slave addr write error !\n", __func__);
        return SOFT_I2C_BUS_ERROR;
    }

    HalSoftI2cSendByte(iicIndex, registerAddr);
    if (HalSoftI2cWaitAck(iicIndex))
    {
        UARTprintf("%s register addr error!\n", __func__);
        return SOFT_I2C_BUS_ERROR;
    }

    HalSoftI2cStart(iicIndex);

    HalSoftI2cSendByte(iicIndex, slaveAddr | 0x01);
    if (HalSoftI2cWaitAck(iicIndex))
    {
        UARTprintf("%s slave addr read error!\n", __func__);
        return SOFT_I2C_BUS_ERROR;
    }

    while(count)
    {
        if(1 == count)
        {

            *rxBuf = HalSoftI2cRecvByte(iicIndex);
            HalSoftI2cNack(iicIndex);
            HalSoftI2cStop(iicIndex);

            return SOFT_I2C_BUS_OK;
        }
        else
        {
            *rxBuf = HalSoftI2cRecvByte(iicIndex);
            HalSoftI2cAck(iicIndex);

            rxBuf++;
            count-- ;
        }
    }

    HalSoftI2cStop(iicIndex);

    return SOFT_I2C_BUS_OK;
}

/**********************************************************************/
/**
  * \brief ��ʼ��I2C
  *
  * \param tObjI2c: �������Բ���
  *
  * \retval none
  */
/**********************************************************************/
VOID HalInitSoftI2c(T_Soft_I2c_Tbl *tObjI2c, UINT32 iicNum)
{
    UINT32 i = 0;

    memcpy(s_SoftI2cBus, tObjI2c, sizeof(T_Soft_I2c_Tbl) * iicNum);

    for (i = 0; i < iicNum; i++)
    {
        s_SoftI2cBus[i].sclCtrl(E_SET);
        s_SoftI2cBus[i].sdaCtrl(E_SET);
    }
}


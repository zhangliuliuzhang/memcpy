/************************************************/
/**
 * \file hal_i2c.c
 * \brief I2C ��������
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_i2c.h"
#include "gd32f4xx_rcu.h"
#include "gd32f4xx_i2c.h"

#define IIC_WAIT_MAX_TIMES      (5)
/**********************************************************************/
/**
  * \brief     ��ʼ��I2Cģ��ʱ��
  *
  * \param bank: RCU_I2C0,RCU_I2C1......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetI2cClkEn(UINT32 bank)
{
    rcu_periph_clock_enable((rcu_periph_enum)bank);
}

/**********************************************************************/
/**
  * \brief     ����I2Cģ��ͨ������
  *
  * \param i2cId:I2C0,I2C1......
  * \param clkSpeed: I2C clock speed, supports standard mode (up to 100 kHz), fast mode (up to 400 kHz)
  * \param dutycyc: I2C_DTCY_2, I2C_DTCY_16_9
  *
  * \retval null
  */
/**********************************************************************/
VOID HalConfigI2cClk(UINT32 i2cId, UINT32 clkSpeed, UINT32 dutycyc)
{
    i2c_clock_config(i2cId, clkSpeed, dutycyc);
}

/**********************************************************************/
/**
  * \brief     ����I2Cģ���ģʽ�͵�ַ
  *
  * \param i2cId:I2C0,I2C1......
  * \param mode: I2C_I2CMODE_ENABLE, I2C_SMBUSMODE_ENABLE
  * \param addformat: 7bits or 10bits
    * \param addr: I2C address
  *
  * \retval null
  */
/**********************************************************************/
VOID HalConfigI2cModeAndAddr(UINT32 i2cId, UINT32 mode, UINT32 addformat, UINT32 addr)
{
    i2c_mode_addr_config(i2cId, mode, addformat, addr);
}

/**********************************************************************/
/**
  * \brief     ʹ��I2Cģ��
  *
  * \param i2cId:I2C0,I2C1......
  *
  * \retval null
  */
/**********************************************************************/
VOID HalEnableI2c(UINT32 i2cId)
{
    i2c_enable(i2cId);
}

/**********************************************************************/
/**
    * \brief     ����I2Cģ���Ƿ���ACK�ź�
  *
  * \param i2cId: I2C0,I2C1......
  * \param ack: I2C_ACK_ENABLE,I2C_ACK_DISABLE
  *
  * \retval null
  */
/**********************************************************************/
VOID HalI2cContrlAck(UINT32 i2cId, UINT32 ack)
{
    i2c_ack_config(i2cId, ack);
}

/**********************************************************************/
/**
  * \brief ��ѯI2C״̬
  *
  * \param i2cId: I2C0,I2C1......
  * \param state: I2C_FLAG_I2CBSY,I2C_FLAG_SBSEND......
  *
  * \retval �ɹ�������
  */
/**********************************************************************/
UINT32 HalGetI2cStat (UINT32 i2cId, i2c_flag_enum state)
{
    UINT32 timeout = 10;

    if(I2C_FLAG_I2CBSY == state)
    {
        while((i2c_flag_get(i2cId, state)) && timeout--)
        {
            zxUTILS_DelayNus(1000);
        }
    }
    else
    {
        while((!i2c_flag_get(i2cId, state)) && timeout--)
        {
            zxUTILS_DelayNus(1000);
        }
    }

    if (timeout <= 0)
    {
        UARTprintf("timed out in getI2cStat: I2C_STAT=%lx\n",  i2c_flag_get(i2cId,state));
        return I2C_BUS_ERR_TIMEOUT;
    }
    return I2C_BUS_OK;
}

/**********************************************************************/
/**
* \brief eeprom iic
  *
  * \param i2cId: I2C0,I2C1......
  * \param slaveAddr:
    * \param txBuf:
  * \param count:
  *
  * \retval
  */
/**********************************************************************/
UINT32 HalEepromSendData(UINT32 i2cId, UINT32 slaveAddr, BYTE page, BYTE registerAddr, BYTE *txBuf, UINT32 count)
{
    UINT32 i;
    UINT32 ulRetVal = I2C_BUS_OK;

    /* wait until I2C bus is idle */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_I2CBSY))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx: I2cBusId = %lu, I2C_I2CBSY!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send a start condition to I2C bus */
    i2c_start_on_bus(i2cId);
    /* wait until SBSEND bit is set */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_SBSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_SBSEND timeout!\n", i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send slaveAddr and write */
      i2c_master_addressing(i2cId, slaveAddr, I2C_TRANSMITTER);
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_ADDSEND)) /* wait until ADDSEND bit is set*/
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_ADDSEND timeout!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }
    i2c_flag_clear(i2cId, I2C_FLAG_ADDSEND);

    /* send write register addr, and wait send complet */
    i2c_data_transmit(i2cId, page);   /*eeprom先发送page页地址*/

        /* wait until the transmit data buffer is empty */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
    {
         UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
         ulRetVal = I2C_BUS_ERR_TIMEOUT;
         goto I2CMasterErr;
    }

    i2c_data_transmit(i2cId, registerAddr);   /*再发送寄存器在page页的地址*/

    /* wait until the transmit data buffer is empty */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
    {
         UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
         ulRetVal = I2C_BUS_ERR_TIMEOUT;
         goto I2CMasterErr;
    }

    for(i = 0; i < count; i++)
    {
        /* data transmission */
        i2c_data_transmit(i2cId, txBuf[i]);
        /* wait until the transmit data buffer is empty */
        if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
        {
             UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
             ulRetVal = I2C_BUS_ERR_TIMEOUT;
             goto I2CMasterErr;
        }
  }

    /* send a stop condition to I2C bus */
   i2c_stop_on_bus(i2cId);

    I2CMasterErr:
    {
        i2c_stop_on_bus(i2cId);
        return ulRetVal;
    }
}

/**********************************************************************/
/**
* \brief eeprom iic receive
  *
  * \param i2cId: I2C0,I2C1......
  * \param slaveAddr:
    * \param txBuf:
  * \param count:
  *
  * \retval
  */
/**********************************************************************/
UINT32 HalEepromRecvData(UINT32 i2cId, UINT32 slaveAddr, BYTE page, BYTE registerAddr, BYTE *rxBuf, UINT32 count)
{
    UINT32 ulRetVal = I2C_BUS_OK;

    /* wait until I2C bus is idle */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_I2CBSY))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx: I2cBusId = %lu, I2C_I2CBSY!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send a start condition to I2C bus */
    i2c_start_on_bus(i2cId);
    /* wait until SBSEND bit is set */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_SBSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_SBSEND timeout!\n", i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send slaveAddr and write */
   i2c_master_addressing(i2cId, slaveAddr, I2C_TRANSMITTER);

    /* wait until ADDSEND bit is set*/
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_ADDSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_ADDSEND timeout!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }
    i2c_flag_clear(i2cId, I2C_FLAG_ADDSEND);

    i2c_data_transmit(i2cId, page);   /*这里是后面要做page页的区分*/

    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
    {
         UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
         ulRetVal = I2C_BUS_ERR_TIMEOUT;
         goto I2CMasterErr;
    }

    /* send write register addr, and wait send complet */
    i2c_data_transmit(i2cId, registerAddr);

    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
    {
         UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
         ulRetVal = I2C_BUS_ERR_TIMEOUT;
         goto I2CMasterErr;
    }

    /* send stop flag */
    i2c_stop_on_bus(i2cId);
    /* wait until I2C bus is idle */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_I2CBSY))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx: I2cBusId = %lu, I2C_I2CBSY!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send a start condition to I2C bus */
    i2c_start_on_bus(i2cId);
    /* wait until SBSEND bit is set */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_SBSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_SBSEND timeout!\n", i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send slaveAddr and read */
    i2c_master_addressing(i2cId, slaveAddr, I2C_RECEIVER);
    /* wait until ADDSEND bit is set*/
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_ADDSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_ADDSEND timeout!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }
    i2c_flag_clear(i2cId, I2C_FLAG_ADDSEND);

    while(count)
    {
        if(1 == count)
        {
            /* send a NACK for the last data byte */
            i2c_ack_config(i2cId, I2C_ACK_DISABLE);
            /* send a stop condition to I2C bus*/
            i2c_stop_on_bus(i2cId);

            zxUTILS_DelayNus(1000);

            if(I2C_CTL0(i2cId)&0x0200)
            {
                UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, wait for stop timeout!\n", i2cId);
                return I2C_BUS_ERR_TIMEOUT;
            }

            *rxBuf = i2c_data_receive(i2cId);
            i2c_ack_config(i2cId, I2C_ACK_ENABLE);

            return I2C_BUS_OK;
        }
        else
        {
            if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_RBNE))
            {
                UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_RBNE timeout!\n", i2cId);
                ulRetVal = I2C_BUS_ERR_TIMEOUT;
                goto I2CMasterErr;
            }
            /* read a data from I2C_DATA */
            *rxBuf = i2c_data_receive(i2cId);

            rxBuf++;
            count-- ;
        }
    }

    I2CMasterErr:
    {
        i2c_stop_on_bus(i2cId);
        return ulRetVal;
    }
}

/**********************************************************************/
/**
* \brief i2c���߷�������
  *
  * \param i2cId: I2C0,I2C1......
  * \param slaveAddr: ��������ַ
    * \param txBuf: ��������
  * \param count: ���ݳ���
  *
  * \retval �ɹ�������
  */
/**********************************************************************/
UINT32 HalI2cSendData(UINT32 i2cId, UINT32 slaveAddr, UINT32 registerAddr, BYTE *txBuf, UINT32 count)
{
    UINT32 i;
    UINT32 ulRetVal = I2C_BUS_OK;

    /* wait until I2C bus is idle */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_I2CBSY))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx: I2cBusId = %lu, I2C_I2CBSY!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send a start condition to I2C bus */
    i2c_start_on_bus(i2cId);
    /* wait until SBSEND bit is set */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_SBSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_SBSEND timeout!\n", i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send slaveAddr and write */
      i2c_master_addressing(i2cId, slaveAddr, I2C_TRANSMITTER);
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_ADDSEND)) /* wait until ADDSEND bit is set*/
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_ADDSEND timeout!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }
    i2c_flag_clear(i2cId, I2C_FLAG_ADDSEND);

    /* send write register addr, and wait send complet */
    i2c_data_transmit(i2cId, registerAddr);

    /* wait until the transmit data buffer is empty */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
    {
         UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
         ulRetVal = I2C_BUS_ERR_TIMEOUT;
         goto I2CMasterErr;
    }

    for(i = 0; i < count; i++)
    {
        /* data transmission */
        i2c_data_transmit(i2cId, txBuf[i]);
        /* wait until the transmit data buffer is empty */
        if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
        {
             UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
             ulRetVal = I2C_BUS_ERR_TIMEOUT;
             goto I2CMasterErr;
        }
  }

    /* send a stop condition to I2C bus */
   i2c_stop_on_bus(i2cId);

    I2CMasterErr:
    {
        i2c_stop_on_bus(i2cId);
        return ulRetVal;
    }
}

static UINT32 WaitIIcAck(UINT32 i2cId)
{
    UINT32 loop = 0;

    for(loop = 0; loop < IIC_WAIT_MAX_TIMES; loop++)
    {
        zxUTILS_DelayNus(1000);
        if((I2C_CTL0(i2cId) & 0x0200) == 0)
        {
            return I2C_BUS_OK;
        }
    }

    return I2C_BUS_ERR_TIMEOUT;
}

/**********************************************************************/
/**
* \brief i2c���߽�������
  *
  * \param i2cId: I2C0,I2C1......
  * \param slaveAddr: ��������ַ
    * \param rxBuf: ��������
  * \param count: ���ݳ���
  *
  * \retval �ɹ�������
  */
/**********************************************************************/
UINT32 HalI2cRecvData(UINT32 i2cId, UINT32 slaveAddr, UINT32 registerAddr, BYTE *rxBuf, UINT32 count)
{
    UINT32 ulRetVal = I2C_BUS_OK;

    /* wait until I2C bus is idle */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_I2CBSY))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx: I2cBusId = %lu, I2C_I2CBSY!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send a start condition to I2C bus */
    i2c_start_on_bus(i2cId);
    /* wait until SBSEND bit is set */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_SBSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_SBSEND timeout!\n", i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send slaveAddr and write */
      i2c_master_addressing(i2cId, slaveAddr, I2C_TRANSMITTER);
    /* wait until ADDSEND bit is set*/
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_ADDSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_ADDSEND timeout!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }
    i2c_flag_clear(i2cId, I2C_FLAG_ADDSEND);

    /* send write register addr, and wait send complet */
    i2c_data_transmit(i2cId, registerAddr);
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_TBE))
    {
         UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_TBE timeout!\n",i2cId);
         ulRetVal = I2C_BUS_ERR_TIMEOUT;
         goto I2CMasterErr;
    }

#if 0
电源不需要发送stop信号
    /* send stop flag */
    i2c_stop_on_bus(i2cId);
    /* wait until I2C bus is idle */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_I2CBSY))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx: I2cBusId = %lu, I2C_I2CBSY!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }
#endif

    /* send a start condition to I2C bus */
    i2c_start_on_bus(i2cId);
    /* wait until SBSEND bit is set */
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_SBSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_SBSEND timeout!\n", i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    /* send slaveAddr and read */
    i2c_master_addressing(i2cId, slaveAddr, I2C_RECEIVER);
    /* wait until ADDSEND bit is set*/
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_ADDSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_ADDSEND timeout!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }
    i2c_flag_clear(i2cId, I2C_FLAG_ADDSEND);

    /* send slaveAddr and write */
      i2c_master_addressing(i2cId, count, I2C_TRANSMITTER);
    /* wait until ADDSEND bit is set*/
    if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_ADDSEND))
    {
        UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_ADDSEND timeout!\n",i2cId);
        ulRetVal = I2C_BUS_ERR_TIMEOUT;
        goto I2CMasterErr;
    }

    while(count)
    {
        if(1 == count)
        {
            /* send a NACK for the last data byte */
            i2c_ack_config(i2cId, I2C_ACK_DISABLE);
            /* send a stop condition to I2C bus*/
            i2c_stop_on_bus(i2cId);

            if(WaitIIcAck(i2cId))
            {
                UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, wait for stop timeout!\n", i2cId);
                return I2C_BUS_ERR_TIMEOUT;
            }

            *rxBuf = i2c_data_receive(i2cId);
            i2c_ack_config(i2cId, I2C_ACK_ENABLE);

            return I2C_BUS_OK;
        }
        else
        {
            /* wait until ADDSEND bit is set*/
            if(I2C_BUS_OK != HalGetI2cStat(i2cId, I2C_FLAG_RBNE))
            {
                UARTprintf("BspI2CMasterXfer_Gd32f4xx:I2cBusId=%lu, I2C_RBNE timeout!\n", i2cId);
                ulRetVal = I2C_BUS_ERR_TIMEOUT;
                goto I2CMasterErr;
            }
            /* read a data from I2C_DATA */
            *rxBuf = i2c_data_receive(i2cId);

            rxBuf++;
            count-- ;
        }
    }

    I2CMasterErr:
    {
        i2c_stop_on_bus(i2cId);
        return ulRetVal;
    }
}

/**********************************************************************/
/**
  * \brief ��ʼ��I2C
  *
  * \param tObjI2c: �������Բ���
  *
  * \retval none
  */
/**********************************************************************/
VOID HalInitI2c(_T_I2c_Tbl tObjI2c)
{
    HalSetI2cClkEn(tObjI2c.clkPort);

    HalConfigI2cClk(tObjI2c.i2cId, tObjI2c.clkspeed, tObjI2c.dutyCyc);

    HalConfigI2cModeAndAddr(tObjI2c.i2cId, tObjI2c.mode, tObjI2c.addformat, tObjI2c.addr);

    HalEnableI2c(tObjI2c.i2cId);

    i2c_ack_config(I2C2, I2C_ACK_ENABLE);
}


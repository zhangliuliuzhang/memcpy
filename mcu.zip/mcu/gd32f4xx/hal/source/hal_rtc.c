/************************************************/
/**
 * \file hal_rtc.c
 * \brief RTC适配层代码
 *
 * \author 10294149
 * \date   2022.1
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/
#include "hal_rtc.h"
#include "gd32f4xx_rcu.h"
#include "gd32f4xx_rtc.h"
#include "gd32f4xx_pmu.h"
#include "common.h"

__IO UINT32 prescaler_a = 0;
__IO UINT32 prescaler_s = 0;

/**********************************************************************/
/**
  * \brief     使能配置RTC寄存器的备份区域
  *
  * \param none
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetRtcClkEn(VOID)
{
    rcu_periph_clock_enable(RCU_PMU);
    pmu_backup_write_enable();
}

/**********************************************************************/
/**
  * \brief     初始化RTC模块时钟源配置
  *
  * \param bank:
  *
  * \retval null
  */
/**********************************************************************/
VOID HalSetRtcClkSourceEn(E_ClkSrc clkSource)
{
    if (clkSource == E_CLK_IRC32K)
    {
        rcu_osci_on(RCU_IRC32K);
        rcu_osci_stab_wait(RCU_IRC32K);
        rcu_rtc_clock_config(RCU_RTCSRC_IRC32K);

        prescaler_s = 0x13F;
        prescaler_a = 0x63;
    }
    else if (clkSource == E_CLK_LXTAL)
    {
        rcu_osci_on(RCU_LXTAL);
        rcu_osci_stab_wait(RCU_LXTAL);
        rcu_rtc_clock_config(RCU_RTCSRC_LXTAL);

        prescaler_s = 0xFF;
        prescaler_a = 0x7F;
    }
    else
    {
        rcu_osci_on(RCU_HXTAL);
        rcu_osci_stab_wait(RCU_HXTAL);
        RCU_CFG0 |= RCU_RTC_HXTAL_DIV24;
        rcu_rtc_clock_config(RCU_RTCSRC_HXTAL_DIV_RTCDIV);

        prescaler_s = 0x1387;
        prescaler_a = 0x63;
    }

    rcu_periph_clock_enable(RCU_RTC);
    rtc_register_sync_wait();
}

/**********************************************************************/
/**
  * \brief     RTC配置时间
  *
  * \param rtcCfgTime: RTC配置的时间
  *
  * \retval null
  */
/**********************************************************************/
UINT32 HalRtcConfigTime(T_RtcTimeAttr rtcCfgTime)
{
    rtc_parameter_struct rtc_initpara = {0};

    rtc_initpara.factor_asyn = prescaler_a;
    rtc_initpara.factor_syn = prescaler_s;
    rtc_initpara.year = rtcCfgTime.year;
    rtc_initpara.month = rtcCfgTime.month;
    rtc_initpara.date = rtcCfgTime.day;
    rtc_initpara.day_of_week = rtcCfgTime.dayOfWeek;
    rtc_initpara.hour = rtcCfgTime.hour;
    rtc_initpara.minute = rtcCfgTime.minute;
    rtc_initpara.second = rtcCfgTime.second;
    rtc_initpara.am_pm = rtcCfgTime.amOrPm;
    rtc_initpara.display_format = rtcCfgTime.dispalyFormat;

    if (ERROR == rtc_init(&rtc_initpara))
    {
        return COMMON_ERROR;
    }
    else
    {
        return COMMON_OK;
    }
}

/**********************************************************************/
/**
  * \brief     获取RTC时间
  *
  * \param rtcTime: RTC时间
  *
  * \retval null
  */
/**********************************************************************/
UINT32 HalRtcGetTime(T_RtcTimeAttr *rtcTime)
{
    rtc_parameter_struct rtcPara = {0};

    rtc_current_time_get(&rtcPara);

    rtcTime->year = rtcPara.year;
    rtcTime->month = rtcPara.month;
    rtcTime->day = rtcPara.date;
    rtcTime->dayOfWeek = rtcPara.day_of_week;
    rtcTime->hour = rtcPara.hour;
    rtcTime->minute = rtcPara.minute;
    rtcTime->second = rtcPara.second;
    rtcTime->amOrPm = rtcPara.am_pm;

    return COMMON_OK;
}

/**********************************************************************/
/**
  * \brief 初始化RTC
  *
  * \param tObjRtc: 抽象属性参数
  *
  * \retval none
  */
/**********************************************************************/
VOID HalInitRtc(T_RtcTbl tObjRtc)
{
    HalSetRtcClkEn();

    HalSetRtcClkSourceEn(tObjRtc.clkSrc);

    HalRtcConfigTime(tObjRtc.rtcTime);
}

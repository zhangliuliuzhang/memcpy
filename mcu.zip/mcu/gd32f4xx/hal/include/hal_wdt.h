/************************************************/
/**
 * \file hal_wdt.h
 * \brief 独立看门狗适配头文件
 *
 * \author 10294149
 * \date   2023.8
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_WDT_H_
#define _HAL_WDT_H_

#include "typedef.h"

VOID HalFwdgtConfig(UINT16 reloadTime);
VOID HalFwdgtReload(VOID);

#endif

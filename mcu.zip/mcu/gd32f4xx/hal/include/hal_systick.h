/************************************************/
/**
 * \file hal_systick.h
 * \brief SYSTICK适配层代码头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_SYSTICK_H_
#define _HAL_SYSTICK_H_

#include "typedef.h"

VOID HalSystickConfig(VOID);

#endif

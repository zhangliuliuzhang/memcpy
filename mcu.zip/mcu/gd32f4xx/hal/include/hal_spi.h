/************************************************/
/**
 * \file hal_spi.h
 * \brief SPI适配层代码头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_SPI_H_
#define _HAL_SPI_H_

#include "typedef.h"
#include "utils.h"

typedef struct _T_Spi_Tbl_
{
    UINT32   index;
    UINT32   clkPort;
    UINT32   spiId;
    UINT32   transMode;
    UINT32   deviceMode;
    UINT32   frameSize;
    UINT32   clkPolarPhase;
    UINT32   nss;
    UINT32   prescale;
    UINT32   endian;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}_T_Spi_Tbl;

UINT32 HalSpiWriteReadByte( UINT32 spiId, BYTE *sendByte, BYTE *recvData );
UINT32 HalSpiWriteReadHalfWord( UINT32 spiId, UINT16 *sendHalfWord, UINT16 *recvHalfWord );

VOID HalInitSpi(_T_Spi_Tbl tObjSpi);

#endif

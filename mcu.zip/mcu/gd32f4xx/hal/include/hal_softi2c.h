/************************************************/
/**
 * \file hal_softi2c.h
 * \brief 软件I2C适配层代码头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_I2C_H_
#define _HAL_I2C_H_

#include "typedef.h"
#include "utils.h"
#include "uartprint.h"

#define SOFT_I2C_MAX_SUPPORT_NUM (3)

/* I2C 总线通信错误码定义 */
#define SOFT_I2C_BUS_OK          (0)     /* BSP_OK*/
#define SOFT_I2C_BUS_ERR_TIMEOUT (1)     /* timed out */
#define SOFT_I2C_BUS_ERROR       (2)     /* BSP_ERROR*/

typedef VOID (*sda_ctrl)(UCHAR status);
typedef VOID (*scl_ctrl)(UCHAR status);
typedef UCHAR (*sda_read)(VOID);
typedef VOID (*sda_exchange)(UCHAR status);

typedef struct _T_Soft_I2c_Tbl_
{
    UINT32   index;

    sda_ctrl sdaCtrl;
    scl_ctrl sclCtrl;
    sda_read sdaRead;
    sda_exchange sdaEx;
    UINT32   delay;

    UINT32   addformat;
    UINT32   addr;  /* 配置为从时使用 */
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_Soft_I2c_Tbl;


UINT32 HalSoftI2cSendData(UINT32 iicIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *txBuf, UINT32 count);
UINT32 HalSoftI2cRecvData(UINT32 iicIndex, UINT32 slaveAddr, UINT32 registerAddr, BYTE *rxBuf, UINT32 count);
VOID HalInitSoftI2c(T_Soft_I2c_Tbl *tObjI2c, UINT32 iicNum);

#endif

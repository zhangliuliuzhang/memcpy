/************************************************/
/**
 * \file hal_gpio.h
 * \brief GPIO适配层代码头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_GPIO_H_
#define _HAL_GPIO_H_

#include "typedef.h"

typedef struct _T_Gpio_Tbl_
{
    UINT32   index;
    UINT32   clkPort;
    UINT32   gpioPort;
    UINT32   gpioBit;
    UINT32   mode;
    UINT32   upDowd;
    UCHAR    otype;
    UINT32   speed;
    UINT32   af;
    UINT32   def;
}_T_Gpio_Tbl;

typedef struct _T_Gpio_Exit_Tbl_
{
    UINT32   index;
    UINT32   clkPort;
    UINT32   gpioPort;
    UINT32   gpioBit;
        UINT32   mode;
    UINT32   upDowd;
        UINT32   nvicIrq;
      UINT32   nvicPrePrio;
      UINT32   nvicSubPrio;
      UINT32   extiPort;
      UINT32   extiPin;
      UINT32   exitLinex;
      UINT32   exitMode;
      UINT32   exitTrigType;
}_T_Gpio_Exit_Tbl;

#define GPIO_OTYPE_NONE   ( 0xff )
#define GPIO_SPEED_NONE   ( 0xff )
#define GPIO_AF_NONE      ( 0xff )
#define GPIO_HIGH         ( 0x01 )
#define GPIO_LOW          ( 0x00 )
#define GPIO_NO_INIT      ( 0xff )

VOID HalSetGpioClkEn(UINT32 bank);
VOID HalSetGpioMode(UINT32 bank, UINT32 mode, UINT32 pull_up_down, UINT32 pin);
VOID HalSetGpioSpeed(UINT32 bank, UCHAR otype, UINT32 speed, UINT32 pin);
VOID HalSetGpioDataout(UINT32 bank, UINT32 bit, UCHAR bit_value);
UCHAR HalGetGpioDatain(UINT32 bank, UINT32 bit);
VOID HalGpioToggle(UINT32 bank, UINT32 bit);
VOID HalSetGpioAf(UINT32 bank, UINT32 afSel, UINT32 bit);
VOID HalInitGpioNormal(_T_Gpio_Tbl tObjNorGpio);
VOID HalInitGpioExit(_T_Gpio_Exit_Tbl tObjExitGpio);

#endif

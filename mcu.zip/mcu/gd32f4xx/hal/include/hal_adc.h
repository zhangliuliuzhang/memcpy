/************************************************/
/**
 * \file hal_adc.h
 * \brief ADCÊÊÅä²ã´úÂë
 *
 * \author 10294149
 * \date   2021.8
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_ADC_H_
#define _HAL_ADC_H_

#include "typedef.h"
#include "utils.h"

typedef struct _T_Uart_Tbl_
{
    UINT32   index;
    UINT32   clkPort;
    UINT32   clkPrescaler;
    UINT32   adcId;
    UINT32   adcChannel;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}_T_Adc_Tbl;


VOID HalInitAdcRegular(_T_Adc_Tbl tObjAdc);
UINT32 HalGetAdcValue(UINT32 adcId, UINT16 *adcData);

#endif

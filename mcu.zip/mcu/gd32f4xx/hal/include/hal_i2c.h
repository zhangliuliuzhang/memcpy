/************************************************/
/**
 * \file hal_i2c.h
 * \brief I2C��������ͷ�ļ�
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_I2C_H_
#define _HAL_I2C_H_

#include "typedef.h"
#include "utils.h"
#include "uartprint.h"


/* I2C ����ͨ�Ŵ����붨�� */
#define I2C_BUS_OK          (0)     /* BSP_OK*/
#define I2C_BUS_ERR_TIMEOUT    (1)     /* timed out */
#define I2C_BUS_ERROR       (2)     /* BSP_ERROR*/


typedef struct _T_I2c_Tbl_
{
    UINT32   index;
    UINT32   clkPort;
    UINT32   i2cId;
    UINT32   clkspeed;
    UINT32   dutyCyc;
    UINT32   mode;
    UINT32   addformat;
    UINT32   addr;  /* ����Ϊ��ʱʹ�� */
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}_T_I2c_Tbl;


VOID HalSetI2cClkEn(UINT32 bank);
VOID HalConfigI2cClk(UINT32 i2cId, UINT32 clkSpeed, UINT32 dutycyc);
VOID HalConfigI2cModeAndAddr(UINT32 i2cId, UINT32 mode, UINT32 addformat, UINT32 addr);
VOID HalEnableI2c(UINT32 i2cId);
VOID HalI2cContrlAck(UINT32 i2cId, UINT32 ack);
UINT32 HalI2cSendData(UINT32 i2cId, UINT32 slaveAddr, UINT32 registerAddr, BYTE *txBuf, UINT32 count);
UINT32 HalI2cRecvData(UINT32 i2cId, UINT32 slaveAddr, UINT32 registerAddr, BYTE *rxBuf, UINT32 count);
UINT32 HalEepromRecvData(UINT32 i2cId, UINT32 slaveAddr, BYTE page, BYTE registerAddr, BYTE *rxBuf, UINT32 count);
UINT32 HalEepromSendData(UINT32 i2cId, UINT32 slaveAddr, BYTE page, BYTE registerAddr, BYTE *txBuf, UINT32 count);


VOID HalInitI2c(_T_I2c_Tbl tObjUart);
#endif

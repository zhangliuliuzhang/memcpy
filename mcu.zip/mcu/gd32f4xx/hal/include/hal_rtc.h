/************************************************/
/**
 * \file hal_rtc.h
 * \brief RTC适配层代码头文件
 *
 * \author 10294149
 * \date   2022.1
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_RTC_H_
#define _HAL_RTC_H_

#include "typedef.h"
#include "utils.h"

typedef enum
{
    E_CLK_HXTAL,
    E_CLK_LXTAL,
    E_CLK_IRC32K,

}E_ClkSrc;

typedef struct
{
    UINT32   year;
    UINT32   month;
    UINT32   day;
    UINT32   dayOfWeek;
    UINT32   hour;
    UINT32   minute;
    UINT32   second;
    UINT32   dispalyFormat;
    UINT32   amOrPm;

}T_RtcTimeAttr;


typedef struct _T_Rtc_Tbl_
{
    E_ClkSrc clkSrc;
    T_RtcTimeAttr rtcTime;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}T_RtcTbl;

VOID HalSetRtcClkEn(VOID);
VOID HalSetRtcClkSourceEn(E_ClkSrc clkSource);
UINT32 HalRtcConfigTime(T_RtcTimeAttr rtcCfgTime);
UINT32 HalRtcGetTime(T_RtcTimeAttr *rtcTime);
VOID HalInitRtc(T_RtcTbl tObjRtc);

#endif

/************************************************/
/**
 * \file hal_timer.h
 * \brief TIMER适配层代码头文件
 *
 * \author 10294149
 * \date   2021.3
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_TIMER_H_
#define _HAL_TIMER_H_

#include "typedef.h"
#include "utils.h"

typedef struct _T_Normal_Timer_Tbl_
{
    UINT32   index;
    UINT32   clkPort;
      UINT32   timerId;
      UINT32   timerClkPrescaler;
    UINT32   prescaler;
      UINT32   alignedmode;
      UINT32   counterdirection;
      UINT32   period;
      UINT32   clockdivision;
      UINT32   intType;
      UINT32   nvicIrq;
      UINT32   nvicPrePrio;
      UINT32   nvicSubPrio;
}_T_Normal_Timer_Tbl;

#define TIMER_INT_TYPE_NONE   ( 0xff )

VOID HalClearTimerIntFlag(UINT32 timerId, UINT32 intFlag);
e_FlagStat HalGetTimerIntFlag(UINT32 timerId, UINT32 intFlag);
VOID HalEnableTimerInt(UINT32 timerId, UINT32 interrupt);
VOID HalDisableTimerInt(UINT32 timerId, UINT32 interrupt);

VOID HalInitTimer(_T_Normal_Timer_Tbl tObjTimer);

#endif

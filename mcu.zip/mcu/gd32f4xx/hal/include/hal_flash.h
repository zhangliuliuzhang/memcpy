/************************************************/
/**
 * \file hal_flash.h
 * \brief FLASH适配层代码头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_FLASH_H_
#define _HAL_FLASH_H_

#include "typedef.h"
#include "utils.h"
#include "common.h"

/* base address of the FMC sectors */
#define ADDR_FMC_SECTOR_0       ((uint32_t)0x08000000) /*!< base address of sector 0,  16 kbytes */
#define ADDR_FMC_SECTOR_1       ((uint32_t)0x08004000) /*!< base address of sector 1,  16 kbytes */
#define ADDR_FMC_SECTOR_2       ((uint32_t)0x08008000) /*!< base address of sector 2,  16 kbytes */
#define ADDR_FMC_SECTOR_3       ((uint32_t)0x0800C000) /*!< base address of sector 3,  16 kbytes */
#define ADDR_FMC_SECTOR_4       ((uint32_t)0x08010000) /*!< base address of sector 4,  64 kbytes */
#define ADDR_FMC_SECTOR_5       ((uint32_t)0x08020000) /*!< base address of sector 5, 128 kbytes */
#define ADDR_FMC_SECTOR_6       ((uint32_t)0x08040000) /*!< base address of sector 6, 128 kbytes */
#define ADDR_FMC_SECTOR_7       ((uint32_t)0x08060000) /*!< base address of sector 7, 128 kbytes */
#define ADDR_FMC_SECTOR_8       ((uint32_t)0x08080000) /*!< base address of sector 8, 128 kbytes */
#define ADDR_FMC_SECTOR_9       ((uint32_t)0x080A0000) /*!< base address of sector 9, 128 kbytes */
#define ADDR_FMC_SECTOR_10      ((uint32_t)0x080C0000) /*!< base address of sector 10,128 kbytes */
#define ADDR_FMC_SECTOR_11      ((uint32_t)0x080E0000) /*!< base address of sector 11,128 kbytes */
#define ADDR_FMC_MAX_ADDR       ((uint32_t)0x08100000)
/* Started by AICoder, pid:c16e23701d524aecb50413154009713a */
typedef enum app_sector {
    APP_RUN_SECTOR,
    APP_UP_SECTOR,
    SND_BOOT_RUN_SECTOR,
    SND_BOOT_MAIN_SECTOR,

    APP_MAX_SECTOR
} app_sector_t;
/* Ended by AICoder, pid:c16e23701d524aecb50413154009713a */

typedef struct tagT_VerFlashInfo
{
    UINT16 validFlag;
    UINT8  type;    // 0xff/0:app,1:boot,2:EPLD
    UINT8  reserve1;
    UINT32 verLenth;
    UINT32 verCrc;
    UINT32 reserve2;      /*预留字段*/
}T_VerFlashInfo;

VOID HalFlashRead(UINT32 addr, UCHAR *pucBuf, UINT32 length);
VOID HalFlashReadWord(UINT32 addr, INT32 *pucBuf, UINT32 length);
VOID HalFlashWrite(UINT32 addr, UCHAR *pucBuf, UINT32 length);
VOID HalFlashWriteWord(UINT32 addr, UINT32 *pucBuf, UINT32 length);
VOID HalEraseFlashSectors( UINT32 startSecNum,UINT32 endSecNum);
UINT32 HalFlashAddrToSector(UINT32 addr);
UINT32 HalFlashDataMove(UINT32 destSectorStart, UINT32 destSectorEnd, UINT32 destAddr, UINT32 srcAddr, UINT32 lenth);
VOID HalFlashEnableWrProtect(VOID);
UINT32 HalFlashWriteProtectTest(VOID);
VOID HalFlashDisableWrProtect(VOID);

UINT32 fmc_sector_get(UINT32 address);
VOID fmc_erase_sector(UINT32 fmc_sector);
VOID fmc_write_32bit_data(UINT32 address, UINT32 length, UINT32* data_32);
VOID fmc_read_32bit_data(UINT32 address, UINT32 length, INT32* data_32);
#endif


/************************************************/
/**
 * \file hal_uart.h
 * \brief UART适配层代码头文件
 *
 * \author 10294149
 * \date   2021.2
 *
 * \copyright 2010-2025 ZTE Corporation
 */
/************************************************/

#ifndef _HAL_UART_H_
#define _HAL_UART_H_

#include "typedef.h"

typedef struct _T_Uart_Tbl_
{
    UINT32   index;
    UINT32   clkPort;
    UINT32   uartId;
    UINT32   baudrate;
    UINT32   rxConfig;
    UINT32   txConfig;
    UINT32   intType;
    UINT32   nvicIrq;
    UINT32   nvicPrePrio;
    UINT32   nvicSubPrio;
    UINT32   reserveMuxSem;
    UINT32   reserveMuxSemTake;
    UINT32   reserveMuxSemGive;
}_T_Uart_Tbl;

#define UART_INT_TYPE_NONE   ( 0xff )

VOID HalSetUartClkEn(UINT32 bank);
VOID HalDeintUart(UINT32 uartId);
VOID HalSetUartBaudrate(UINT32 uartId, UINT32 baudrate);
VOID HalConfigUartRecvive(UINT32 uartId, UINT32 rxconfig);
VOID HalConfigUartTransmit(UINT32 uartId, UINT32 txconfig);
VOID HalEnableUart(UINT32 uartId);
VOID HalEnableInt(UINT32 uartId, UINT32 interrupt);
UINT32 HalGetUartFlagStatus(UINT32 uartId, UINT32 flag);
VOID HalUartSendByte(UINT32 uartId, UINT32 data);
UINT32 HalUartSendBuffer(UINT32 uartId, BYTE *pData, UINT32 dataLen);
VOID HalUartSendString(UINT32 uartId, const BYTE *string);
VOID HalUartSendHexBuffer(UINT32 uartId, BYTE *pData, UINT32 dataLen);
VOID HalUartContrl(UINT32 uartId, BOOLEAN ucStat);
VOID HalInitUart(_T_Uart_Tbl tObjUart);
VOID HalDisableInt(UINT32 uartId, UINT32 interrupt);
VOID HalEnableInt(UINT32 uartId, UINT32 interrupt);
#endif

/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : pimccomon.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供CFR模块配置的功能实现。
 * 注意事项 : 无
 * 作    者 : wangfei
 * 创建日期 : 2015-10-20 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: 
 * 责 任 人:
 * 修改日戳: 
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _FUNCLIB_PIMC_COMMON_H_INCLUDED_
#define _FUNCLIB_PIMC_COMMON_H_INCLUDED_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"

/**************************************************************************
 *                        宏定义                                              
 **************************************************************************/
#define PIMC_CARR_FLAG_VALID			0x1
#define PIMC_CARR_FLAG_INVALID			0x0

#define INPUT_PIMCCHN_CHECK(bspChn)                         \
{                                                           \
    UINT32 txChn = BspGetTxChannel();                       \
    UINT32 rxChn = BspGetRxChannel();                       \
    UINT32 pimcChn = BspGetPimcMaxChanNum();       \
    if (bspChn >= pimcChn)                                  \
    {                                                       \
        dbgErr("[%s]chn'%d is Error ,Over PimcChn'%d TxChn'%d RxChn'%d \n",__FUNCTION__,bspChn,pimcChn,txChn,rxChn);\
        return BSP_ERROR;                                   \
    }                                                       \
}

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef UINT32 (*PimcAntCarrRemap)(UINT32 chn,UINT32 ferq);

 
typedef struct tag_pimc_para
{
    UINT32 orderN;        /*pimc 阶数*/
    UINT32 extendedBw;    /*pimc 扩展带宽 KHZ*/ 
    UINT32 ncoStep;       /*pimc Nco KHZ步进*/
    UINT32 freOffset;      /*pimc 检测点频偏 KHZ*/
    UINT32 deltBw;        /* &bw 200K*/
    UINT32 dpdSamplingRate; /* 反馈DPD采数速率，单位KHZ */
    INT32  dpdFreOffset;    /* 反馈DPD频移，单位KHZ  */
}T_PimcPara;


typedef struct tag_pimc_freq_para
{
    UINT32 freqL;
    UINT32 freqH;
    UINT32 freqCenter;
    UINT32 freqBw;
}T_PimcFreqPara;

typedef struct tag_pimc_carr_info
{
	T_PimcFreqPara carr[2][32];/*RX:0  TX:1*/
	UINT32         carrNum[2];/*RX:0  TX:1*/
}T_PimcCarrInfo;

typedef struct tag_pimc_equation_freq_para
{
    INT32 pointL;
    INT32 pointH;
    INT32 pointCenter;
    INT32 pointBw;
    UINT32 pointFlag;
}T_PimcEquationXPoint;

typedef struct tag_pimc_point_info
{
	T_PimcEquationXPoint *pFreqPoint;
	UINT32         		pointNum;
}T_PimcPointInfo;



/**************************************************************************
 *                         函数接口
 **************************************************************************/

UINT32 BspInitPimcPara(T_PimcPara * pPimcPara ,UINT32 pimcChnNum);
UINT32 BspGetPimcOrderN(UINT32 bspChn,UINT32 *pOrderN);
UINT32 BspGetPimcDeltBw(UINT32 bspChn,UINT32 *pDeltBw);
UINT32 BspGetPimcExtendedBw(UINT32 bspChn,UINT32 *pExBw);
UINT32 BspGetPimcNcoStep(UINT32 bspChn,UINT32 *pNcoStep);
UINT32 BspGetPimcDpdSamplingRate(UINT32 bspChn,UINT32 *pDpdSamplingRate);
UINT32 BspGetPimcDpdFreOffset(UINT32 bspChn,INT32 *pDpdFreOffset);
UINT32 BspGetPimcMaxChanNum(VOID);
UINT32 BspSetPimcVailFreq(UINT32 bspChn,UINT32 bandid,UINT32 freqL,UINT32 freqH);
UINT32 BspGetPimcVailFreq(UINT32 bspChn,UINT32 bandid,T_PimcFreqPara *pPimcVailFreq);
INT32 BspGetPimcFreqOffset(UINT32 bspChn,INT32 *pFreqOffset);
UINT32 BspPimcInitCarrInfo(UINT32 bspChn);
UINT32 BspSetPimcPointInfo(UINT32 bspChn,T_PimcPointInfo * pPimcPointInfo,UINT32 pointNum);
UINT32 BspGetPimcPointInfo(UINT32 bspChn,T_PimcPointInfo * pPimcPointInfo);
UINT32 BspGetPimcVailBandNum(UINT32 bspChn,UINT32 *pPimcBandNum);
VOID BspSetPimcAntCarrRemapPtr(PimcAntCarrRemap fucptr);
UINT32 BspDupePimcCarrInfo(UINT32 disChn,UINT32 srcChn,UINT32 len);

#ifdef __cplusplus
}
#endif
#endif //_FUNCLIB_PIMC_COMMON_H_INCLUDED_



/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pimccommon.c
* 文件标识 : {[N/A]}
* 内容摘要 : pimc 模块公共功能具体实现接口
* 注意事项 : 无
* 作    者 : wangfei
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "pimccommon.h"
#include "ru_univdef.h"
#include "funccommon_chncfg.h"
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

static T_PimcFreqPara s_pimcVailFreq[BSP_MAX_TX_CHAN][MAX_BAND_NUM] = {0};/*pimc 有效频点*/
static T_PimcCarrInfo s_pimcCarrInfo[BSP_MAX_TX_CHAN][MAX_BAND_NUM] = {0};/*carr 频点*/
static T_PimcPointInfo *s_pimcPointInfo = NULL;
static T_PimcPara     *s_pimcPara = NULL ;
PimcAntCarrRemap BspGetPimcAntCarrRemapFlag = NULL ;

/**************************************************************************
 *                        宏定义
 **************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
    
/**************************************************************************
*                         函数实现
**************************************************************************/
    
/*****************************************************************************
*  函数名称   : BspInitPimcPara
*  功能描述   : 设置pimc 参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
VOID BspSetPimcAntCarrRemapPtr(PimcAntCarrRemap fucptr)
{
     BspGetPimcAntCarrRemapFlag = fucptr;
     return;
}

UINT32 BspInitPimcPara(T_PimcPara * pPimcPara,UINT32 pimcChnNum)
{
    /* UINT32 retVal       = BSP_OK; */
    UINT32 pimcMaxChn   = 0;
    UINT32 pimcChn      = 0;
    
    INPUT_POINTER_CHECK(pPimcPara);
    pimcMaxChn = BspGetPimcMaxChanNum();
    pimcChn = (pimcChnNum < pimcMaxChn)? pimcChnNum : pimcMaxChn;
    if(s_pimcPara == NULL)
    {
        s_pimcPara = (T_PimcPara *)malloc(sizeof(T_PimcPara)*pimcChn);
        if(s_pimcPara == NULL)
        {
            dbgErr("[%s]Init Pimc malloc Error \n",__FUNCTION__);
            s_pimcPara = NULL;
            return BSP_ERROR;
        }
        memset(s_pimcPara,0,sizeof(T_PimcPara)*pimcChn);
    }
    memcpy_s(s_pimcPara,(sizeof(T_PimcPara)*pimcChn),pPimcPara,(sizeof(T_PimcPara)*pimcChn));
    if(s_pimcPointInfo == NULL)
	{
    	s_pimcPointInfo = (T_PimcPointInfo *)malloc(sizeof(T_PimcPointInfo)*pimcChn);
		if(s_pimcPointInfo == NULL)
		{
			dbgErr("[%s]Init Pimc point malloc Error \n",__FUNCTION__);
			s_pimcPointInfo = NULL;
			return BSP_ERROR;
		}
		memset(s_pimcPointInfo,0,sizeof(T_PimcPointInfo)*pimcChn);

	}
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetPimcPara
*  功能描述   : 设置pimc 频点信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

static UINT32  BspGetPimcPara(UINT32 bspChn,T_PimcPara * pPimcPara)
{
    if(bspChn >= BspGetPimcMaxChanNum())
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(s_pimcPara);
    memcpy_s((char *)pPimcPara, sizeof(T_PimcPara), (char *)&s_pimcPara[bspChn], sizeof(T_PimcPara));
    return BSP_OK;
    
}

/*****************************************************************************
*  函数名称   : BspGetPimcorderN
*  功能描述   : 获取pimc 阶数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetPimcOrderN(UINT32 bspChn,UINT32 *pOrderN)
{
    T_PimcPara pimcPara = {0};
    UINT32 retVal = BSP_OK;
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pOrderN);
    
    retVal = BspGetPimcPara(bspChn,&pimcPara);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s]Pimc Get OrderN Error!PimcChn'%d \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    *pOrderN = pimcPara.orderN;   
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetPimcDeltBw
*  功能描述   : 获取pimc &deltbw
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetPimcDeltBw(UINT32 bspChn,UINT32 *pDeltBw)
{
    T_PimcPara pimcPara = {0};
    UINT32 retVal = BSP_OK;
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pDeltBw);

    retVal = BspGetPimcPara(bspChn,&pimcPara);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s]Pimc Get DeltBw Error!PimcChn'%d \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    *pDeltBw = pimcPara.deltBw;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetPimcFreqOffset
*  功能描述   : 获取pimc 频偏
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

INT32 BspGetPimcFreqOffset(UINT32 bspChn,INT32 *pFreqOffset)
{
    T_PimcPara pimcPara = {0};
    UINT32 retVal = BSP_OK;
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pFreqOffset);
    
    retVal = BspGetPimcPara(bspChn,&pimcPara);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s]Pimc Get freOffset Error!PimcChn'%d \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    *pFreqOffset = pimcPara.freOffset;   
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetPimcExtendedBw
*  功能描述   : 获取pimc 扩展带宽
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetPimcExtendedBw(UINT32 bspChn,UINT32 *pExBw)
{
    T_PimcPara pimcPara = {0};
    UINT32 retVal = BSP_OK;
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pExBw);
    
    retVal = BspGetPimcPara(bspChn,&pimcPara);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s]Pimc Get extendedBw Error!PimcChn'%d \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    *pExBw = pimcPara.extendedBw; 
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetPimcNcoStep
*  功能描述   : 获取pimc NCO步进
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetPimcNcoStep(UINT32 bspChn,UINT32 *pNcoStep)
{
    T_PimcPara pimcPara = {0};
    UINT32 retVal = BSP_OK;
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pNcoStep);
    
    retVal = BspGetPimcPara(bspChn,&pimcPara);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s]Pimc Get ncoStep Error!PimcChn'%d \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    *pNcoStep = pimcPara.ncoStep;   
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetPimcDpdSamplingRate
*  功能描述   : 获取pimc 反馈DPD采数速率，单位KHZ
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张磊@2020-07-26 16:06:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetPimcDpdSamplingRate(UINT32 bspChn,UINT32 *pDpdSamplingRate)
{
    T_PimcPara pimcPara = {0};
    UINT32 retVal = BSP_OK;
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pDpdSamplingRate);

    retVal = BspGetPimcPara(bspChn,&pimcPara);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s]: Pimc Get dpdSamplingRate Error!PimcChn'%d \n",
                __FUNCTION__,bspChn);
        return BSP_ERROR;
    }
    *pDpdSamplingRate = pimcPara.dpdSamplingRate;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetPimcDpdFreOffset
*  功能描述   : 获取pimc 反馈DPD频移，单位KHZ
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张磊@2020-07-26 16:06:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetPimcDpdFreOffset(UINT32 bspChn,INT32 *pDpdFreOffset)
{
    T_PimcPara pimcPara = {0};
    UINT32 retVal = BSP_OK;
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pDpdFreOffset);

    retVal = BspGetPimcPara(bspChn,&pimcPara);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s]: Pimc Get pDpdFreOffset Error!PimcChn'%d \n", __FUNCTION__,
            bspChn);
        return BSP_ERROR;
    }
    *pDpdFreOffset = pimcPara.dpdFreOffset;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetPimcVailFreq
*  功能描述   : 设置pimc 有效频点
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 相当于主集通道(Bsp 主集通道 0,1...)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspSetPimcVailFreq(UINT32 bspChn,UINT32 bandid,UINT32 freqL,UINT32 freqH)
{
    INPUT_PIMCCHN_CHECK(bspChn);
    if(bandid >=MAX_BAND_NUM)
    {
        return BSP_ERROR;
    }
    s_pimcVailFreq[bspChn][bandid].freqH        = freqH;
    s_pimcVailFreq[bspChn][bandid].freqL        = freqL;
    s_pimcVailFreq[bspChn][bandid].freqCenter   = (freqH + freqL)/2;
    s_pimcVailFreq[bspChn][bandid].freqBw       = freqH - freqL;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetPimcVailFreq
*  功能描述   : 设置pimc 有效信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 相当于主集通道(Bsp 主集通道 0,1...)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetPimcVailFreq(UINT32 bspChn,UINT32 bandid,T_PimcFreqPara *pPimcVailFreq)
{
    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pPimcVailFreq);
    if(bandid >=MAX_BAND_NUM)
    {
        return BSP_ERROR;
    }
    
    memcpy_s((char *)pPimcVailFreq, sizeof(T_PimcFreqPara), (char *)&s_pimcVailFreq[bspChn][bandid], sizeof(T_PimcFreqPara));
    
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetPimcMaxChan
*  功能描述   : 获取pimc 最大通道数(BSP)
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 相当于主集通道(Bsp 主集通道 0,1...)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetPimcMaxChanNum(VOID)
{
      UINT32 txChn = 0;
      UINT32 rxChn = 0;
      UINT32 pimcMaxChn =0;
      txChn = BspGetTxChannel();
      rxChn = BspGetRxChannel();
      pimcMaxChn = (txChn < rxChn)? BspGetTxChannel():BspGetRxChannel();
      pimcMaxChn = (BspGetPimcAntCarrRemapFlag == (PimcAntCarrRemap)NULL)?pimcMaxChn:rxChn;
      return pimcMaxChn;
}
/*****************************************************************************
*  函数名称   : BspSetPimcCarrInfo
*  功能描述   : 设置要计算的Pimc 载波频点信息；
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspSetPimcCarrInfo(UINT32 bspChn,T_PimcCarrInfo * pPimcCarrInfo)
{
	INPUT_PIMCCHN_CHECK(bspChn);
	INPUT_POINTER_CHECK(pPimcCarrInfo);
	memcpy_s((char *)&s_pimcCarrInfo[bspChn], sizeof(T_PimcCarrInfo), (char *)pPimcCarrInfo, sizeof(T_PimcCarrInfo));
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspDupePimcCarrInfo
*  功能描述   : 设置要计算的Pimc 载波频点信息；
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspDupePimcCarrInfo(UINT32 disChn,UINT32 srcChn,UINT32 len)
{
	UINT32 pimcchn = 0;
    pimcchn = BspGetPimcMaxChanNum();

    if((disChn >= pimcchn) ||(srcChn >= pimcchn))
    {
        return BSP_ERROR;
    }
	memmove((char *)s_pimcCarrInfo[disChn], (char *)s_pimcCarrInfo[srcChn], len);
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetPimcCarrInfo
*  功能描述   : 获取要计算的Pimc 载波频点信息；
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetPimcCarrInfo(UINT32 bspChn,T_PimcCarrInfo * pPimcCarrInfo)
{
	INPUT_PIMCCHN_CHECK(bspChn);
	INPUT_POINTER_CHECK(pPimcCarrInfo);
	memcpy_s((char *)pPimcCarrInfo, sizeof(T_PimcCarrInfo), (char *)&s_pimcCarrInfo[bspChn], sizeof(T_PimcCarrInfo));
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetPimcPointInfo
*  功能描述   : 设置要计算的Pimc 点信息；
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetPimcPointInfo(UINT32 bspChn,T_PimcPointInfo * pPimcPointInfo,UINT32 pointNum)
{
	UINT32 pointLoop = 0;
	INPUT_PIMCCHN_CHECK(bspChn);
	INPUT_POINTER_CHECK(pPimcPointInfo);
	INPUT_POINTER_CHECK(s_pimcPointInfo);
	if(s_pimcPointInfo[bspChn].pFreqPoint != NULL)
	{
		free(s_pimcPointInfo[bspChn].pFreqPoint);
		s_pimcPointInfo[bspChn].pFreqPoint = NULL;
	}
	if(s_pimcPointInfo[bspChn].pFreqPoint == NULL)
	{
		s_pimcPointInfo[bspChn].pFreqPoint = (T_PimcEquationXPoint *)malloc(sizeof(T_PimcEquationXPoint)*pointNum);
		if(s_pimcPointInfo[bspChn].pFreqPoint == NULL)
		{
			dbgErr("[%s]chn'%d pimc point malloc Error \n",__FUNCTION__,bspChn);
			s_pimcPointInfo[bspChn].pFreqPoint = NULL;
			return BSP_ERROR;
		}
		memset(s_pimcPointInfo[bspChn].pFreqPoint,0,sizeof(T_PimcEquationXPoint)*pointNum);
		s_pimcPointInfo[bspChn].pointNum = pointNum;
	}
	s_pimcPointInfo[bspChn].pointNum = pPimcPointInfo->pointNum;
	for (pointLoop = 0; pointLoop < pointNum ; pointLoop ++)
	{
		s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointBw 		= pPimcPointInfo->pFreqPoint[pointLoop].pointBw;
		s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointCenter 	= pPimcPointInfo->pFreqPoint[pointLoop].pointCenter;
		s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointH 		= pPimcPointInfo->pFreqPoint[pointLoop].pointH	;
		s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointL 		= pPimcPointInfo->pFreqPoint[pointLoop].pointL	;
		s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointFlag     = pPimcPointInfo->pFreqPoint[pointLoop].pointFlag;
	}
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetPimcCarrInfo
*  功能描述   : 获取要计算的Pimc 点信息；
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetPimcPointInfo(UINT32 bspChn,T_PimcPointInfo * pPimcPointInfo)
{
	/* UINT32 retVal = BSP_OK; */
	UINT32 pointLoop = 0;
	INPUT_PIMCCHN_CHECK(bspChn);
	INPUT_POINTER_CHECK(s_pimcPointInfo);
	INPUT_POINTER_CHECK(s_pimcPointInfo[bspChn].pFreqPoint);
	INPUT_POINTER_CHECK(pPimcPointInfo);
	INPUT_POINTER_CHECK(pPimcPointInfo->pFreqPoint);

	/*memcpy((char *)pPimcPointInfo, (char *)&s_pimcPointInfo[bspChn], sizeof(T_PimcPointInfo));*/

	pPimcPointInfo->pointNum = s_pimcPointInfo[bspChn].pointNum;
	for (pointLoop = 0; pointLoop < s_pimcPointInfo[bspChn].pointNum ; pointLoop ++)
	{
		pPimcPointInfo->pFreqPoint[pointLoop].pointBw 		= s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointBw;
		pPimcPointInfo->pFreqPoint[pointLoop].pointCenter 	= s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointCenter;
		pPimcPointInfo->pFreqPoint[pointLoop].pointH 		= s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointH;
		pPimcPointInfo->pFreqPoint[pointLoop].pointL 		= s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointL;
		pPimcPointInfo->pFreqPoint[pointLoop].pointFlag     = s_pimcPointInfo[bspChn].pFreqPoint[pointLoop].pointFlag;
	}
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetPimcCarrInfo
*  功能描述   : 获取要计算的Pimc 点信息；
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetPimcPointNum(UINT32 bspChn,UINT32 *pPointNum)
{
	/* UINT32 retVal = BSP_OK; */
	/* UINT32 pointLoop = 0; */
	INPUT_PIMCCHN_CHECK(bspChn);
	INPUT_POINTER_CHECK(s_pimcPointInfo);
	INPUT_POINTER_CHECK(s_pimcPointInfo[bspChn].pFreqPoint);
	INPUT_POINTER_CHECK(pPointNum);

	*pPointNum =  s_pimcPointInfo[bspChn].pointNum;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspPimcInitCarrInfo
*  功能描述   : 初始化Pimc载波信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspPimcInitCarrInfo(UINT32 bspChn)
{
	UINT32 retVal 	= BSP_OK;
	UINT32 carrLoop[2] = {0,0};
	T_PimcCarrInfo pimcCarrInfo = {0};
	T_RruRfCfgInfo rruCfgPara = {0};
    UINT32 channum  = 0;
    UINT32 bspchan[MAX_BAND_NUM] = {0};
    UINT32 antId = 0;
    UINT32 antChn  = 0;
    UINT32 i = 0,j= 0;
    UINT32 bspChnTemp = bspChn;
    
	INPUT_PIMCCHN_CHECK(bspChn);
    
    if((PimcAntCarrRemap)NULL != BspGetPimcAntCarrRemapFlag)
    {
        bspChnTemp = bspChn%(UINT32)4;
    }
    
    BspGetAntInfoByBspChn(bspChnTemp, TX, &antId, &antChn);
    retVal = BspGetBspChnByAntId(antId,TX,&channum,bspchan);
	if(retVal != BSP_OK)
	{
		return retVal;
	}
    for(i = 0; i<channum ;i++)
    {
    	retVal = BspGetChnlCfgCarrPara(bspchan[i], &rruCfgPara);  //  这里需要修改为高层下发的合路后的配置信息 -- ZHAOFENG 
    	if(retVal != BSP_OK)
    	{
    		return retVal;
    	}
    	for(j = 0;j <rruCfgPara.rxCfgCarrSum;j++)
    	{
    	    if((rruCfgPara.carr[j].carrRxFreq !=0 )&& (rruCfgPara.carr[j].carrRxFreq != -1))
            {   
        		pimcCarrInfo.carr[RX][carrLoop[RX]].freqCenter 	= rruCfgPara.carr[j].carrRxFreq;
        		pimcCarrInfo.carr[RX][carrLoop[RX]].freqBw 		= rruCfgPara.carr[j].carrRxBw;
        		pimcCarrInfo.carr[RX][carrLoop[RX]].freqH		= pimcCarrInfo.carr[RX][carrLoop[RX]].freqCenter + pimcCarrInfo.carr[RX][carrLoop[RX]].freqBw/2;
        		pimcCarrInfo.carr[RX][carrLoop[RX]].freqL		= pimcCarrInfo.carr[RX][carrLoop[RX]].freqCenter - pimcCarrInfo.carr[RX][carrLoop[RX]].freqBw/2;
                carrLoop[RX]++;
            }
        }
    	pimcCarrInfo.carrNum[RX] = carrLoop[RX];
        
    	for(j = 0;j <rruCfgPara.txCfgCarrSum;j++)
    	{    	
    	    if((rruCfgPara.carr[j].carrTxFreq !=0 )&& (rruCfgPara.carr[j].carrTxFreq != -1))
            {   
                /*发射天线物理调整的整机需要重新映射，例如R9222E整机*/  
            #if 0 

            {
    {0,791000,821000,0},
    {1,791000,821000,0},
    {2,791000,821000,1},
    {3,791000,821000,1},
}
            #endif 
                if((PimcAntCarrRemap)NULL != BspGetPimcAntCarrRemapFlag)
                {
                    if(BSP_OK == BspGetPimcAntCarrRemapFlag(bspChn,rruCfgPara.carr[j].carrTxFreq))
                    {
                        continue;
                    }
                }
                
        		pimcCarrInfo.carr[TX][carrLoop[TX]].freqCenter 	= rruCfgPara.carr[j].carrTxFreq;
        		pimcCarrInfo.carr[TX][carrLoop[TX]].freqBw 		= rruCfgPara.carr[j].carrTxBw;
                carrLoop[TX]++;
            }
    	}
    	pimcCarrInfo.carrNum[TX] = carrLoop[TX];        
    }
    
	retVal |= BspSetPimcCarrInfo(bspChn,&pimcCarrInfo);
	return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetPimcVailBandNum
*  功能描述   : 设置pimc 有效 BAND 个数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 相当于主集通道(Bsp 主集通道 0,1...)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspGetPimcVailBandNum(UINT32 bspChn,UINT32 *pPimcBandNum)
{
    UINT32 antId = 0;
    UINT32 antChn  = 0;
    UINT32 channum  = 0;
    UINT32 bspchan[MAX_BAND_NUM] = {0};
	UINT32 retVal 	= BSP_OK;
	T_RruRfCfgInfo rruCfgPara = {0};
    UINT32 i = 0,j =0 ;

    INPUT_PIMCCHN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pPimcBandNum);
    
    BspGetAntInfoByBspChn(bspChn, TX, &antId, &antChn);
    retVal = BspGetBspChnByAntId(antId,TX,&channum,bspchan);
	if(retVal != BSP_OK)
	{
		return retVal;
	}
    *pPimcBandNum = 0;

    for(i = 0; i<channum ;i++)
    {
        retVal = BspGetChnlCfgCarrPara(bspchan[i], &rruCfgPara);  
        if(retVal != BSP_OK)
        {
            continue;
        }
        for(j = 0; j<rruCfgPara.txCfgCarrSum ;j++)
        {
            if((rruCfgPara.carr[j].carrTxFreq != 0) &&(rruCfgPara.carr[j].carrTxFreq != -1))
            {
                *pPimcBandNum = *pPimcBandNum + 1;
                break;
            }
        } 
    }
    
    return BSP_OK;
}


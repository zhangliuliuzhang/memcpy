/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : pimc_a.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供PIMC控制接口
 * 注意事项 : 无
 * 作    者 : 10102065
 * 创建日期 : 2017-2-22 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#ifndef _FUNCLIB_PIMC_H_
#define _FUNCLIB_PIMC_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "pimcapi.h"
#include "pimccommon.h"


#define PIMC_FUNC_STARTUP 1
//UINT32 BspPicmGetState(UINT32 bspChn);

#ifdef __cplusplus
}
#endif

#endif


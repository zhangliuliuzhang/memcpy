/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : pimc_a.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : pimc控制 方案由FPGA实现参数配置，DSP实现消息以及算法，BSP流程控制
 * 注意事项 : 该模块调用有模块间调用，原因是由于方案设计导致，方案具有公用性，所以模块
 *          : 见可以调用dsp模块。与方案强相关。
 * 作    者 : 10102065
 * 创建日期 : 2017-2-22 09:54:30
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *------------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "regdrv.h"
#include "pim_ic4_2.h"
#include "chnmap_a.h"
//#include "rruinfo.h"
//#include "devdrv_lo.h"
#include "dpd_app.h"
#include "exprn.h"
#include "freqcfg_ic4_2.h"
#include "ichaladapt_ic4_2.h"
#include "paapi.h"
#include "devdrv_att.h"
#include "powerctrl_comps_ic4_2.h"
#include "rxscan_ic4_2.h"
#define PIM_DATA_TOTAL            (10)
#define PIM_DATA_MAX_TIME         (50)

static UINT32 s_PimCheckFreq = 0;


/*
UINT32 BspPimcByPass(UINT32 bspChn)
{
    return BspDpdPimcByPass(bspChn);
}

UINT32 BspPimcUnByPass(UINT32 bspChn)
{
    return BspDpdPimcUnByPass(bspChn);
}

UINT32 BspPimcClrLut(UINT32 bspChn,UINT32 bandId)
{
    return BspDpdPimcClrLut(bspChn,bandId);
}
 */
/*目前是判断在dsp侧，bsp默认开启，解决app新老流程无法复用的问题，葛美香，朱敏，汤双庆确认*/
/* UINT32 BspPimcStartJudgment(UINT32 bspChn)
{
    return PIMC_FUNC_STARTUP;
} */
UINT32 BspPimcStart(UINT32 bspChn,UINT32 bandId)
{
    return BspDpdPimcStart(bspChn, bandId);
}

UINT32 BspPimcStop(UINT32 bspChn,UINT32 bandId)
{
    return BspDpdPimcStop(bspChn, bandId);
}

UINT32 BspPimDataRead(UINT32 bspChn, UINT32 * pPimVal)
{
    UINT32 uIdx    = 0;
    UINT32 uChipId = 0;
    UINT32 uDifChn = 0;
    UINT32 uSumCnt = 0;
    UINT32 uPaSta  = 0;
    UINT32 dLineVal[PIM_DATA_TOTAL]   = {0};
    UINT32 tmpData = 0;
    UINT32 dMaxData = 0;
    UINT32 dMinData = 0;
    UINT32 maxDataIndex = 0;
	UINT32 minDataIndex = 0;
    UINT32 dTmp    = 0;
    DOUBLE dSum    = 0.0;
    UINT32 lTmp    = 0;
    UINT32 uFreq   = s_PimCheckFreq;
    INT32 uRxGain = 0;
    INT32  rxatt   = 0;
    INT32  rxvga   = 0;
    UINT32 lFullScale = 9031;//16bit满量程
    UINT32 sumNum = 0;
    INT32  PimData   = 0;

    if(NULL == pPimVal)
    {
    	return BSP_ERROR;
    }

    if (BspGetDifInfoByBspChn(bspChn,RX,&uChipId,&uDifChn) != BSP_OK)
    {
        dbgErr("[%s] DifInfoByBspChn Get Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /*先将上行VGA置为手动模式 */
    BspGetRxVga(bspChn, &rxvga);
    BspGetRxAtt(bspChn, &rxatt);
    BspSetRxScanMtsAgcSw(bspChn, 0);
    BspSetMtsAgcMode(0);
    uPaSta = BspGetPaSwitch(bspChn);
    if(SWITCH_OFF == uPaSta)
    {
        for(uIdx=0;uIdx<PIM_DATA_TOTAL;uIdx++)
        {

            if(BSP_OK == BspHalAdaptPimChkDataRpt(0,uDifChn,&tmpData))
            {   
                dLineVal[uIdx]= tmpData;
                dbgInfoEx("[%s] uDifChn%d index'%d read data=%d\n",__FUNCTION__,uDifChn,uIdx,tmpData);
                if(0 == uIdx)
                {
                    dMaxData = dLineVal[uIdx];
                    dMinData = dLineVal[uIdx];
                    maxDataIndex = 0;
                    minDataIndex = 0;
                }
                if(dLineVal[uIdx] > dMaxData)
                {
                    dMaxData = dLineVal[uIdx];
                    maxDataIndex = uIdx;
                }
                else if(dLineVal[uIdx] < dMinData)
                {
                   dMinData = dLineVal[uIdx];
                   minDataIndex = 0;
                } 	
                BspSysMsDelay(10);
            }
        }
        for(uIdx=0;uIdx<PIM_DATA_TOTAL;uIdx++)
        {
            if((uIdx!=minDataIndex) &&(uIdx != maxDataIndex))
            {
                dSum += dLineVal[uIdx]*1.0;
                sumNum++;
            }
        }
        if(sumNum != 0)
        {
            if(dSum < 1.0 )
            {
                dSum = 1.0;
            }
            lTmp =(INT32) (1000.0*log10(dSum/(sumNum*1.0))) ;
            dbgInfo("[%s] bspChn%d read pim data=%d sum'%lf count'%d\n",__FUNCTION__,bspChn,lTmp,dSum,sumNum);
        }
    }
    else if(SWITCH_ON == uPaSta)
    {
        for(uIdx=0;uIdx<PIM_DATA_MAX_TIME;uIdx++)
        {
        	if(BSP_OK == BspHalAdaptPimChkDataRpt(0,uDifChn,&tmpData))
			{
                dTmp = tmpData;
                dbgInfoEx("[%s] uDifChn%d index'%d read data=%d\n",__FUNCTION__,uDifChn,uIdx,tmpData);
	            BspSysMsDelay(1);
                //最小的一组数据抛掉，找第2小数据
	    		if(0 == uIdx)
	    		{
	    			dMinData = dTmp;
	    			continue;
	    		}
                else if(1 == uIdx)
                {
                    if(dTmp < dMinData)
                    {
                        dSum = dMinData; 
                        dMinData = dTmp; 
                    }
				    else
				    {
				        dSum = dTmp;
				    }
					continue;
                }
	    		if(dTmp < dMinData)
	    		{
                    dSum = dMinData;
                    dMinData = dTmp;
	    		}
                else if(dTmp < dSum)
                {
                    dSum  = dTmp;//确保拿到的是第2小的值
                }
			}
        }
        if(dSum < 1.0)
        {
            dSum = 1.0;
        }
        dbgInfoEx("[%s] the second minor sample result =%lf\n",__FUNCTION__,dSum);
        lTmp =(INT32) (1000.0*log10(dSum)) ;
		dbgInfo("[%s] bspChn%d read pim data=%d(times%d)\n",__FUNCTION__,bspChn,lTmp,uSumCnt);

    }
    else
    {
         dbgInfo("BspGetPaStatus PA[ulRfChanGroup=%u] ERROR!\n",bspChn);
    }


    //BspGetPimRxScanIcComp(&IcComp);

	if(BSP_OK == BspGetRssiDbmCompGain(bspChn,BSP_RADIO_STANDARD_LTE_FDD,uFreq,0,&uRxGain,COMPS_BY_FREQ_POINT_TYPE))
	{
		PimData = lTmp- lFullScale - uRxGain - rxatt - rxvga;
		*pPimVal = (UINT32)(PimData);
        dbgInfo("%s>>>pPimVal is %d\n",__FUNCTION__,*pPimVal);
	}
    /*上行VGA恢复自动模式 */
    BspSetRxScanMtsAgcSw(bspChn, 2);
    BspSetMtsAgcMode(2);
    dbgInfo("[%s] bspChn%d read pim data=%d ,uSumCnt %d,RxGain=%d,rxatt(%d),rxvga(%d)\n",__FUNCTION__,bspChn,*pPimVal,uSumCnt,uRxGain,rxatt,rxvga);
    return BSP_OK;
}


UINT32 BspPimCheckFreq(UINT32 bspChn, UINT32 uFreq)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0; 
    UINT32 loFreq = 0;
    T_BspHalAdaptPimChkInfoCfg tPimChkInfo = {0};
	
    s_PimCheckFreq = uFreq;//设置全局变量
    retVal = BspGetDifInfoByBspChn(bspChn,RX,&chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspGetDifInfoByBspChn(%d,RX) return error\n",__FUNCTION__,bspChn);
        return retVal;
    }

    loFreq = BspGetRfCenterFreq(RX,bspChn);
    if ((0 == loFreq) || (BSP_ERROR == loFreq))
    {
        dbgErr("%s>>TxChnl'%d LoFreq'%d Get Error!\n",__FUNCTION__, bspChn, loFreq);
        return BSP_ERROR;
    }
    tPimChkInfo.iOffset = (INT32)(loFreq-uFreq);
    dbgInfo("Pim Check loFreq is %d,uFreq is %d, offset is %d\n!\n",loFreq,uFreq,tPimChkInfo.iOffset);
    
    retVal = BspHalAdaptPimChkCfg(0,difChan,&tPimChkInfo); 
    return retVal;
}


UINT32 BspPimSwitch(UINT32 bspChn, UINT32 uSwitch)
{
/*     UINT32 chipId = 0;
	UINT32 difChan = 0; */
	UINT32 retVal = BSP_OK;
	
/*     retVal = BspGetDifInfoByBspChn(bspChn,RX,&chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspGetDifInfoByBspChn(%d,RX) return error\n",__FUNCTION__,bspChn);
        return retVal;
    } */

    // 默认使用频段0的
	retVal = BspHalAdaptPimPimCalcSw(uSwitch);
    return retVal;
}

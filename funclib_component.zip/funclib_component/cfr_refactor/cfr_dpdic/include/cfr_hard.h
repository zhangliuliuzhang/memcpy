/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXRAN-RHP Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_dss.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2及后续芯片的CFR模块配置功能
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2023-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_CFR_HARD_H_
#define FUNCLIB_CFR_HARD_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"
#include "ichaladapt_ic4_2.h"

#define CFR_CHN_CHANGE                   1  /* 削峰通道发生制式或带宽改配，需要更新用于计算CPG的原型系数 */
#define CFR_CHN_NO_CHANGE                0  /* 削峰通道未发生制式或带宽改配，不需要更新用于计算CPG的原型系数 */
#define CFR_CPG_HW_CAL_START             0  /* 削峰CPG系数硬件计算开始 */
#define CFR_CPG_HW_CAL_STOP              1  /* 削峰CPG系数硬件计算暂停 */

#define CPG_COEF_LEN_HALF_MAX_768      768  /* 削峰CPG系数最大半长768 */
#define SET_BIT(data, pos)           (data |= (1 << pos))   /* 将位置为pos的比特置1，pos取值从0开始 */
#define CLEAR_BIT(data, pos)         (data &= ~(1 << pos))  /* 将位置为pos的比特置0，pos取值从0开始 */
#define GET_BIT(data, pos)           ((data >> pos) & 1)    /* 获取位置为pos的比特值，pos取值从0开始 */
#define REVERSE_BIT(data, pos)       (GET_BIT(data, pos) ? CLEAR_BIT(data, pos) : SET_BIT(data, pos))    /* 将位置为pos的比特取反 */
#define WRITE_BIT(data, pos, flag)   (flag ? (SET_BIT(data, pos)) : (CLEAR_BIT(data, pos)))  /* 将位置为pos的比特置1或0，pos取值从0开始 */

UINT32 BspCfrClrHwCpgRam(UINT32 bspChnChgMask);
UINT32 BspCfrSetCpgPara_HwCal(UINT32 bspChn);
UINT32 BspGetDifChnHwMask(UINT32 *chnMask);
UINT32 BspHalAdaptGetCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara);

#ifdef __cplusplus
}
#endif

#endif


/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_dpdic.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2及后续芯片的CFR模块配置功能
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2022-02-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2022-02-17
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_CFR_DPDIC_H_INCLUDED
#define FUNCLIB_CFR_DPDIC_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"
#include "cfr_cpgcal.h"
#include "cfr_cpu.h"
#include "cfr_hard.h"
#include "cfr_cfgpara.h"
#include "cfr_dss.h"
#include "funccommon_log.h"


#ifdef __cplusplus
}
#endif
#endif

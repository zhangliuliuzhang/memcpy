/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXRAN-RHP Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_dss.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2及后续芯片的CFR模块配置功能
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2023-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_CFR_CPU_H_
#define FUNCLIB_CFR_CPU_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"

#define CFR_PI                  3.1415926535

/**************************************************************************
 *                         函数接口
 **************************************************************************/
UINT32 BspCfrCpgInit_CpuCal(UINT32 difChan);
UINT32 BspCfrSetCpgPara_CpuCal(UINT32 bspChn);
UINT32 BspSetUmtsCpgCoef(UINT32 bspChan, UINT32 radioMod, UINT32 umtsBw, UINT32 cfgflag);
FLOAT BspGetgi(UINT32 difChn,UINT32 carrRadio,UINT32 ulCarr,FLOAT giTemp,FLOAT giTempMax);
UINT32 BspSetUmtsDlFilterCpgBwByCarrBw(UINT32 difChan, UINT32 carrNo, UINT32 cpgbandWidth);

#ifdef __cplusplus
}
#endif

#endif




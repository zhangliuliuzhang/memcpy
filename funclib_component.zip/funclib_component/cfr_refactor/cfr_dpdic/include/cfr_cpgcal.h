/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXRAN-RHP Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_dss.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2及后续芯片的CFR模块配置功能
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2023-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_CFR_CPGCAL_H_
#define FUNCLIB_CFR_CPGCAL_H_

#define IC_DATA_INVALID   (UINT32)0xFFFFFFFF
#define IC_FLAG_USED     (UINT32)1
#define IC_FLAG_NOTUSED   IC_DATA_INVALID


#ifdef __cplusplus
extern "C" {
#endif


#include "bsppub.h"
#include "cfrcommon.h"


/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define CFR_FILE_NAME_LEN               128  /* 文件名称长度 */

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

typedef struct tag_ic_cfr_cpg_band_data
{
    INT32 *pCpgReal;
    INT32 *pCpgImag;
    UINT32 cpgLen;
    UINT32 *pCoef;
    UINT32 cpgVaildLen;
    UINT32 flag;
}T_IcCfrCpgBandData;

typedef struct tag_cfr_cpg_cpu_data
{
    T_IcCfrCpgBandData cfrBand[E_CFR_BAND_MAX];
    UINT32 cfrBandNum;
}T_IcCfrCpgCpuCalData;

/**************************************************************************
 *                         函数接口
 **************************************************************************/
UINT32 BspCfrCpgGetGiTempMax(UINT32 difChn, FLOAT *giTempMax);
UINT32 BspCfrCpgCfg_CpuCal(UINT32 difChn);
UINT32 BspCfrCpgGetWei(UINT32 cfrFs, UINT32 carrRadio, FLOAT *wei);
UINT32 BspCfrGetCpgVaildLen(UINT32 difChn, UINT32 *vaildlen);
UINT32 CfrGetCpgCfg_CpuCal_IC4_2(UINT32 difChn,INT16 *pCpgReal,INT16 * pCpgImag,UINT32 cfrLutLen);
UINT32 BspCfrDataSave_CpuCal(UINT32 difChn, UINT32 band, FLOAT *pCpgReal, FLOAT *pCpgImag , UINT32 dataNum, FLOAT sumBandGK,UINT32 vaildMaxLen);
UINT32 BspCfrSetBandNum(UINT32 difChn,UINT32 cfrBandNum);
UINT32 BspCfrCpgDataMemApply(VOID);
UINT32 BspCfrSetCpgParaCpuCalByRadio(UINT32 difChn, UINT32 ulCarrId, UINT32 radio, UINT32 bw);

#ifdef __cplusplus
}
#endif

#endif







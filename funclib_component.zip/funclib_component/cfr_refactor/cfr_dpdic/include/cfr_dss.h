/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXRAN-RHP Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_dss.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2及后续芯片的CFR模块配置功能
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2023-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_CFR_DSS_H_
#define FUNCLIB_CFR_DSS_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define CFR_CARR_EXIST_DSS               1  /* 削峰通道内两载波为频谱共享 */
#define CFR_CARR_NO_EXIST_DSS            0  /* 削峰通道内两载波不是频谱共享关系 */
#define CFR_START_GET_DSS_GROUP          1  /* 开始寻找一组具有DSS关系的载波 */
#define CFR_STOP_GET_DSS_GROUP           0  /* 未开始寻找一组具有DSS关系的载波 */
#define CFR_CHN_DSS_GROUP_MAX_NUM        4  /* 单通道内载波具有DSS关系的最大组数 */

#define CFR_DSS_MERGE_MIN_BW            800 /* DSS合并载波处理时，判断为频谱共享的最小重叠带宽：0.8M */
#define BSP_POWSHARE_REFRESH_CPG_ACTIONING ((UINT32)1)  /* CPG采用底层载波功率刷新CPG */

typedef UINT32 (*FUN_GET_POWCTRL_TSSI_INFO)(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs);

/**************************************************************************
 *                         函数接口
 **************************************************************************/
UINT32 BspGetCfrChanDssFlag(UINT32 difChan);
UINT32  BspSetCfrDSSCarrGroupInfo(UINT32 difChan, T_CfrChnBandInfo *pChnInfo);
UINT32 BspGetRefreshCfrCpgFlag(UINT32 bspChn, UINT32 *flag);
FUN_GET_POWCTRL_TSSI_INFO BspGetTssiPowInfoCallBackInit(void);
UINT32 BspJudgeCfrCpgRefreshCarrPow(UINT32 cpgCalcFlag, UINT32 powShareFlag, INT32 appPowMw, INT32 realPowMw, INT32 *carrPowMw);
UINT32 BspRefreshCfrCpgTbl(UINT32 bspChn);
UINT32 BspSetTssiPowInfoCallBackInit(FUN_GET_POWCTRL_TSSI_INFO pGetTssi);

#ifdef __cplusplus
}
#endif
#endif

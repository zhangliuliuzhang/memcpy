/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_cfgpara.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供CFR模块配置功能
* 注意事项 : 无
* 作    者 : 喻波10220056
* 创建日期 : 2023-07-01
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 喻波10220056
* 修改日戳: 2023-07-01
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef PLATFORM_BSP_FUNCLIB_COMPONENT_CFR_REFACTOR_CFR_DPDIC_INCLUDE_CFR_CFGPARA_H_
#define PLATFORM_BSP_FUNCLIB_COMPONENT_CFR_REFACTOR_CFR_DPDIC_INCLUDE_CFR_CFGPARA_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "cfrcommon.h"
#include "ichaladapt_ic4_2.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define CFR_EQDLY_BYPASS        1
#define CFR_ZERODLY_BYPASS      0

#define CFR_EQ_DLY              1
#define CFR_ZERO_DLY            0

#define IC_CFR_ON                   (UINT32)0x1
#define IC_CFR_OFF                  (UINT32)0x0

#define IC_CFR_OUTPUT_MODE           (UINT32)0x2  /* CFR 使能 */
#define IC_CFR_ORG_IQ_DATA_MODE     (UINT32)0x1  /* 等延时旁路 */
#define IC_CFR_INPUT_IQ_DATA_MODE   (UINT32)0x0  /* 零延时旁路 */

#define CFR_GATE_INIT_CFG_FREQ           1  /* 配频中的门限初始化 */
#define CFR_GATE_INIT_CFG_CFR            0  /* 配CFR中的门限初始化 */

#define CFR_CHN_EXIST_LV                 1  /* 削峰通道中存在LTE或NR制式载波 */
#define CFR_CHN_NO_EXIST_LV              0  /* 削峰通道中不存在LTE或NR制式载波 */

#define CFR_CPG_PHASE_1                  1  /* 削峰CPG相数，单相 */
#define CFR_CPG_PHASE_2                  2  /* 削峰CPG相数，2phase */
#define CFR_CPG_PHASE_4                  4  /* 削峰CPG相数，4phase */

#define CFR_CHAN_TDD_DX                  2  /* 削峰通道为TDD双工 */
#define CFR_CHAN_FDD_DX                  3  /* 削峰通道为FDD双工 */

#define CFR_CHAN_MAX_NUM             IC_CHAN_MAX_NUM        /* 削峰中频最大通道数 */

#define CFR_CPG_LEN_HAL_MAX_GNB         765 /* FDD机型 radiocfg.txt 中含有G或NB制式时的最大CPG半长 */
#define CFR_CPG_LEN_HAL_MAX_ULV         509 /* FDD机型 radiocfg.txt 中不包含G和NB制式时的最大CPG半长 */

#define RADIO_SUPPORT_GSM_OR_NB         (1) /* 整机无线制式支持 GSM 或 NB */

/*下一步将下面两个结构体进行合并处理*/
/*CFR动态参数TDD*/
typedef struct tagCfrDynPara_TDD
{
    FLOAT lowbound;  //IBW/OBW下边界
    FLOAT upbound;  //IBW/OBW上边界
    UINT32 cfrgate[E_CFR_THR_NUM];      //削峰门限，E_CFR_THR_NUM为3，均按3级填满，实际2级削峰，最后一级可补0
    UINT32 cfrwin[E_CFR_THR_NUM] ;      //削峰窗长
    UINT32 cfrdelt[E_CFR_THR_NUM];      //检测门限
    UINT32 cfrwinlevel[E_CFR_THR_NUM];  //削峰窗长等级
}T_CfrDynPara_TDD;

/*CFR动态参数FDD*/
typedef struct tagCfrDynPara_FDD
{
    UINT32 radio;                       //混模制式
    UINT32 lowbound;                    //通道最小带宽下边界
    UINT32 upbound;                     //通道最小带宽上边界
    UINT32 cfrgate[E_CFR_THR_NUM];      //削峰门限
    UINT32 cfrwin[E_CFR_THR_NUM] ;      //削峰窗长
    UINT32 cfrdelt[E_CFR_THR_NUM];      //检测门限
    UINT32 cfrwinlevel[E_CFR_THR_NUM];  //削峰窗长等级
}T_CfrDynPara_FDD;

/* 配置方案表(用于定义数据和配置方案的对应关系) */
typedef struct tagT_CfrGateCfgGroup
{
    UINT32   tddFddFlag;    /* TDD或FDD标志 */
    VOID*    dynPara;       /* 第1层数据地址 */
    UINT32   tblLen;        /* 第1层数据组数 */
}T_CfrGateCfgGroup;

/**************************************************************************
 *                         函数接口
 **************************************************************************/
UINT32 BspInitCfrModuleFunc(VOID);
UINT32 BspGetCfrChnBwInfo(UINT32 difchan, UINT32 bandId, UINT32 *obw,UINT32 *ibw);
UINT32 BspCfrGateInit_TDD(UINT32 difchan, T_CfrDynPara_TDD *pTddPara, UINT32 len);
UINT32 BspCfrGateInit_FDD(UINT32 difchan, T_CfrDynPara_FDD *pFddPara, UINT32 len);
UINT32 BspCfrGateInitCommon(UINT32 difchan, UINT32 radioflag, T_CfrDynPara_TDD *pTddPara, T_CfrDynPara_FDD *pFddPara, UINT32 len);
UINT32 BspCfrDymParaInit(UINT32 dymTblLen, VOID *pCfrGateCfgGroup);
UINT32 BspInitCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara);
UINT32 BspInitKiCommPara(VOID *pCfrHWCpgPara);
UINT32 BspInitKnCommPara(VOID *pCfrKnWordPara);
UINT32 BspInitCfrParPara(VOID *pCfrParPara);
UINT32 BspInitDpdParPara(VOID *pDpdParPara);
UINT32 BspSetCfrOutMode(UINT32 difChn, UINT32 mode);
UINT32 BspGetCfrCommPara(VOID *pCfrCommPara);
UINT32 BspGetCfrParPara(VOID *pCfrParPara);
UINT32 BspGetCfrKiCommPara(VOID *pCfrHWCpgPara);
UINT32 BspGetCpgFsByDifChnCommon(UINT32 difChn,UINT32 *pCfrFs);
UINT32 BspGetDpdParPara(VOID *pDpdParPara);
UINT32 BspCfrSetTddSwPara(UINT32 difChn);
UINT32 BspCfrSetCpgLen(UINT32 difChn);
UINT32 BspSetNBCarrMode(UINT32 ulChan, UINT32 ulCarr, UINT32 ulMode);
UINT32 BspSetDlyPara(UINT32 chan, UINT32 *pReservePara);
UINT32 BspGetNBCarrMode(UINT32 difChn,UINT32 ulCarr);
UINT32 BspCfrJudgeCpgMode(UINT32 difChn, UINT32 *cpgMode);
UINT32 BspInitCfrSetCpgGateBypass(void);
UINT32 BspInitRangeBandPara(void);
UINT32 BspCfrSetBbTssiCfg(UINT32 difchn);
UINT32 BspHalAdaptCfrDymParaInit(UINT32 dymTblLen, T_CfrGateCfgGroup *pCfrGateCfgGroup);


#ifdef __cplusplus
}
#endif
#endif

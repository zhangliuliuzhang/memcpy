/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_cpu.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2的CFR模块配置功能
* 注意事项 : 无
* 作    者 : 张龙10281388
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 张龙10281388
* 修改日戳: 2023-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "bsppub.h"
#include "cfr_dss.h"
#include "cfrcommon.h"
#include "cfr_cpu.h"
#include "cfr_cpgcal.h"
#include "ichaladaptcfrapi.h"
#include "cfr_cfgpara.h"
#include "cfr_dpdic.h"
#include "freqcfg_ic4_2.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"

//获取软CFR CPG系数长度
VOID BspGetCfrCpuCpgLen(T_CfrCpgPara *cfrCpgPara, UINT32 *cpgVaildLen, UINT32 ulCpgLen, UINT32 ulDelayMode)
{
    INPUT_POINTER_CHECK(cfrCpgPara);
    INPUT_POINTER_CHECK(cpgVaildLen);

    if(1 == ulDelayMode)//如果是等时延，cfr的CPG长度固定
    {
        *cpgVaildLen = ulCpgLen;
    }
    else
    {
        *cpgVaildLen = (*cpgVaildLen > cfrCpgPara->vaildLen) ? *cpgVaildLen : cfrCpgPara->vaildLen;
    }
}

//获取软CFR  Gi参数
UINT32 BspGetCfrCpuGi(T_CfrCpgPara *cfrCpgPara, FLOAT *gi, FLOAT *wei, FLOAT *giTempMax)
{
    UINT32 cnt           = 0;
    UINT32 originCoefLen = 0;
    FLOAT  ciSq          = 0.0;
    FLOAT  pci           = 0.0;
    FLOAT  giTemp        = 0.0;

    INPUT_POINTER_CHECK(cfrCpgPara);
    INPUT_POINTER_CHECK(cfrCpgPara->pCoefPara);
    INPUT_POINTER_CHECK(gi);
    INPUT_POINTER_CHECK(wei);
    INPUT_POINTER_CHECK(giTempMax);
    
    originCoefLen = cfrCpgPara->coefLen;
    
    for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
    {
        ciSq += pow(cfrCpgPara->pCoefPara[cnt], 2);
    }
  
    pci = (FLOAT)(2 * ciSq + pow(cfrCpgPara->pCoefPara[originCoefLen - 1], 2));

    giTemp = (FLOAT)(*wei / sqrt(pci));

    if (*giTempMax >= (-EPSINON) && *giTempMax <= EPSINON)
    {
        dbgInfo("[%s] error: giTempMax is zero!]\n",__FUNCTION__);
        return BSP_ERROR;
    }
    else
    {
        *gi = (FLOAT)round((giTemp / *giTempMax) * pow(2, 25) / 2609);  //按公式计算
    }

    return BSP_OK;
}            

//获取cpg系数
UINT32 BspGetCfrCpuCpgCfg(T_CfrChnBandInfo *pCfrDifChnInfo, UINT32 ulCpgLen, UINT32 ulDelayMode, FLOAT *giTempMax)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 cpgVaildLen   = 0;
    UINT32 originCoefLen = 0;
    UINT32 carrNo        = 0;
    UINT32 cnt           = 0;
    UINT32 cfrBw         = 0;
    UINT32 carrPowMw     = 0;
    UINT32 carrBw     = 0;
    UINT32 cfrFs     = 0;
    UINT32 difChan     = 0;
    UINT32 carrRadio     = 0;
    INT32 fi             = 0;
    DOUBLE tempData      = 0.0;
    FLOAT dQn            = 0.0;
    FLOAT sumBandGK      = 0.0;
    FLOAT wei            = 0.0;
    T_CfrCpgPara cfrCpgPara = {0};
    FLOAT Ki             = 0;
    UINT32 pgVaildLen     = 0;
    FLOAT gi             = 0;
    FLOAT *pCpgReal      = NULL;
    FLOAT *pCpgImag      = NULL;
    UINT32 nbCarrMode    = 0;
    UINT32 uCarrBw[BSP_MAX_CARR_NUM] = {0};
    
    INPUT_POINTER_CHECK(pCfrDifChnInfo);
    INPUT_POINTER_CHECK(pCfrDifChnInfo->usedFlag);
    INPUT_POINTER_CHECK(pCfrDifChnInfo->bandCarrNum);
    INPUT_POINTER_CHECK(giTempMax);
    
    /* kw告警修改,考虑32/64位系统, 所以用ULONG */
    pCpgReal = (FLOAT *)malloc(sizeof(FLOAT) * CFR_CPG_RAM_768);
    if (pCpgReal == NULL)
    {
        dbgInfoEx("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    pCpgImag = (FLOAT *)malloc((sizeof(FLOAT) * CFR_CPG_RAM_768));
    if (pCpgImag == NULL)
    {
        free(pCpgReal);
        pCpgReal = NULL;
        dbgInfoEx("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset(pCpgReal, 0, (sizeof(FLOAT) * CFR_CPG_RAM_768));
    memset(pCpgImag, 0, (sizeof(FLOAT) * CFR_CPG_RAM_768));


    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED);

        //bandNum ++;
        cpgVaildLen = 0;
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID);

            carrNo      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrPowMw   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            ret = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw); 
            fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;

            dbgInfo("%s>>DifChan'%d  carrIndex'%d  carrRadio'%d carrPowMw'%d carrBw'%d cfrBw'%d cfrFs'%d \n",
                    __FUNCTION__, difChan, carrLoop, carrRadio, carrPowMw, carrBw, cfrBw, cfrFs);

            dQn = 2.0 * CFR_PI * fi / cfrFs;/*KHZ*/
            Ki = (FLOAT)sqrt(carrPowMw);

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrCpgCoefCommon(difChan,cfrBw,cfrFs, &cfrCpgPara);
            CONTINUE_IF_EXP(ret != BSP_OK);

            BspGetCfrCpuCpgLen(&cfrCpgPara, &pgVaildLen, ulCpgLen, ulDelayMode);
            
            originCoefLen = cfrCpgPara.coefLen;

            if(BspGetCfrCpuGi(&cfrCpgPara, &gi, &wei, giTempMax) != BSP_OK)
            {
                free(pCpgImag);
                free(pCpgReal);
                pCpgReal = NULL;
                pCpgImag = NULL;
                continue;
            }
            
            if(RADIO_STANDARD_NB_IOT == carrRadio)
            {
                nbCarrMode = BspGetNBCarrMode(difChan,carrNo);
                
                if(nbCarrMode != NB_STANDALONE)
                {
                    gi = 0;
                }

                dbgInfo("[%s] >>> NBCarrMode:[%d]\n",__FUNCTION__,nbCarrMode);
            }

            if (BSP_RADIO_STANDARD_UMTS == carrRadio)
            {
                uCarrBw[carrNo] = carrBw;
            }

            sumBandGK += gi * Ki;

            /*要求cpg系数跟lutlen 保持一致,这里做判断以防万一出现不一致情况*/
            for (cnt = 0; cnt < originCoefLen; cnt++)
            {
                tempData = ((originCoefLen - 1 - cnt) * (-1.0) * dQn);
                pCpgReal[cnt] += ((FLOAT)(Ki * gi * cos(tempData))) * (FLOAT)cfrCpgPara.pCoefPara[cnt];
                pCpgImag[cnt] += ((FLOAT)(Ki * gi * sin(tempData))) * (FLOAT)cfrCpgPara.pCoefPara[cnt];
                dbgInfoEx("%s>>Cnt'%d Nco'%d dQn'%f  Coef'%f: cos(%f)= %f, sin(%f)= %f\n",
                          __FUNCTION__, cnt, fi, dQn, (FLOAT)cfrCpgPara.pCoefPara[cnt],
                          tempData, cos(tempData), tempData, sin(tempData));
            }
        }

        if ((sumBandGK >= (-(FLOAT)EPSINON)) && (sumBandGK <= (FLOAT)EPSINON))
        {
            ret = BSP_ERROR;
        }
        else
        {
            ret = BspCfrDataSave_CpuCal(difChan, bandLoop, pCpgReal, pCpgImag, originCoefLen, sumBandGK,cpgVaildLen);
        }
        dbgInfo("%s>>DifChan'%d BandIdx'%d sumBandGK'%f CpgInitCpuCal OK! DataSave %s!\n",
                __FUNCTION__, difChan, bandLoop, sumBandGK, (BSP_OK == ret) ? "Succ" : "Fail");

        memset_s(pCpgReal, sizeof(FLOAT)*originCoefLen, 0, sizeof(FLOAT)*originCoefLen);
        memset_s(pCpgImag, sizeof(FLOAT)*originCoefLen, 0, sizeof(FLOAT)*originCoefLen);
        sumBandGK = 0.0;
    }
}
/*****************************************************************************
*  函数名称   : BspCfrCpgInit_CpuCal
*  功能描述   : cpg 系数软计算初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-03-30 16:08:15
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgInit_CpuCal(UINT32 difChan)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 carrBw        = 0;
    UINT32 cfrBw         = 0;
    UINT32 carrPowMw     = 0;
    UINT32 carrRadio     = 0;
    UINT32 carrNo        = 0;
    UINT32 cnt           = 0;
    FLOAT Ki             = 0;
    

    FLOAT giTempMax      = 1.0;
    FLOAT gi             = 0.0;
    FLOAT sumBandGK      = 0.0;
    FLOAT ciSq           = 0.0;

    FLOAT *pCpgReal      = NULL;
    FLOAT *pCpgImag      = NULL;
    INT32 fi             = 0;
    DOUBLE tempData      = 0.0;
    FLOAT dQn            = 0.0;
    UINT32 ulDelayMode   = 0;
    UINT32 cfrFs         = 0;
    UINT32 bandNum       = 0;
    
    UINT32 nbCarrMode    = 0;
    UINT32 uCarrBw[BSP_MAX_CARR_NUM] = {0};
    UINT32 ulCpgLen      = CFR_CPG_RAM_768;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    
    T_BspHalAdaptDifCommCfrPara *difPara = NULL;
    
    INPUT_DIFCHAN_CHECK(difChan);
    difPara = BspHalAdaptGetDifCfrPara();
    if(NULL != difPara)
    {
        ulDelayMode = difPara->uiDelayEqualFlag[difChan];
        ulCpgLen = difPara->uiCpgCoefLenHalfMax[difChan];
        dbgInfo("[%s] DlyMode is %d,CPG Len is %d\n ",__FUNCTION__,ulDelayMode,ulCpgLen);
    }

    ret |= BspGetCfrFsByDifChn(difChan,&cfrFs);
    ret |= BspCfrCpgGetGiTempMax(difChan, &giTempMax);

    /* kw告警修改,考虑32/64位系统, 所以用ULONG */
    pCpgReal = (FLOAT *)malloc(sizeof(FLOAT) * CFR_CPG_RAM_768);    
    if (pCpgReal == NULL)
    {
        dbgInfo("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    pCpgImag = (FLOAT *)malloc((sizeof(FLOAT) * CFR_CPG_RAM_768));
    if (pCpgImag == NULL)
    {
        free(pCpgReal);
        pCpgReal = NULL;
        dbgInfo("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(pCpgReal, (sizeof(FLOAT) * CFR_CPG_RAM_768), 0, (sizeof(FLOAT) * CFR_CPG_RAM_768));
    memset_s(pCpgImag, (sizeof(FLOAT) * CFR_CPG_RAM_768), 0, (sizeof(FLOAT) * CFR_CPG_RAM_768));

    pCfrDifChnInfo = BspGetCfrChnInfo(difChan);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChan);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChan);
        free(pCpgImag);
        free(pCpgReal);
        pCpgImag = NULL;
        pCpgReal = NULL;
        return BSP_ERROR;
    }
    
    if (CFR_CARR_EXIST_DSS == BspGetCfrChanDssFlag(difChan))
    {
        dbgInfo("[%s]: difChan'%d  Cfr Cpg Use DSS CPU Calculation! \n", __FUNCTION__,difChan);
        ret |= BspSetCfrDSSCarrGroupInfo(difChan, pCfrDifChnInfo);
    }

    BspGetCfrCpuCpgCfg(pCfrDifChnInfo, ulCpgLen, ulDelayMode,&giTempMax);
    ret |= BspCfrSetBandNum(difChan,bandNum);

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
    {
        if (uCarrBw[carrLoop] != 0)
        {           
            ret |= BspSetUmtsDlFilterCpgBw(difChan, carrLoop, uCarrBw[carrLoop]);
        }
    }

    BspLog(LOG_LEVEL_0,"[%s] chn'%d, cfrFs'%d, giTempMax'%f, ret'%s.\n", __FUNCTION__, difChan, cfrFs, giTempMax, (BSP_OK == ret)?"OK":"Error");

    free(pCpgReal);
    free(pCpgImag);
    pCpgReal = NULL;
    pCpgImag = NULL;

    return ret;
}




/*****************************************************************************
*  函数名称   : BspCfrSetCpgPara_CpuCal
*  功能描述   : 配置削峰软件计算 CPG 系数
*  输入参数   : bspChn   - BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : IC4.2进行DSS处理的前提：通道中存在带宽严格大于30M的NR载波
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 10:42:14
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgPara_CpuCal(UINT32 bspChn)
{
    UINT32 retVal   = BSP_OK;
    UINT32 difChan  = 0;
    UINT32 chipidx  = 0;
    UINT32 index    = 0;
    UINT32 freqBand = 0;
    T_CfrChnBandInfo *pChnInfo = NULL;

    retVal = BspCfrCpgDataMemApply();
    if(retVal == BSP_ERROR)
    {
        dbgInfo("[%s]Cfr Cpg Data Apply Mem Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChan);

    pChnInfo = BspGetCfrChnInfo(difChan);
    if (pChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChan);
        return BSP_ERROR;
    }

    retVal |= BspCpgInit(difChan);

    retVal |= BspSetCpgCfg(difChan);

    return retVal;
}

UINT32 BspGetchnChgFlag(UINT32 hwChnMask, UINT32 difChn)
{
	UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;

    if (CFR_CHN_CHANGE == GET_BIT(hwChnMask, difChn))
    {
        chnChgFlag = CFR_CHN_CHANGE;
    }

    return chnChgFlag;
}

UINT32 BspGetsymNum(UINT32 uiThrSel, UINT32 uiSymNum0, UINT32 uiSymNum1)
{
	UINT32 symNum         = 0;

    if (uiThrSel == 1)
    {
        symNum = uiSymNum0;
    }
    else
    {
        symNum = uiSymNum1;
    }

    return symNum;
}

UINT32 BspSetUmtsDlFilterCpgBwByCarrBw(UINT32 difChan, UINT32 carrNo, UINT32 cpgbandWidth)
{
	UINT32 ret = BSP_OK;

    if (cpgbandWidth != 0)
    {
        ret = BspSetUmtsDlFilterCpgBw(difChan, carrNo, cpgbandWidth);
    }

    return ret;
}


INT32 BspGetCarrFi(UINT32 difChan, UINT32 radioMode,UINT32 carrNo,UINT32 bspBw,INT32 fi)
{
	INT32 fiTemp          = 0;
	T_CfrLteUmtsFreqFiOffsetInfo pUmtsInfo[MAX_TX_CHANNEL] = {0};

    if (BSP_RADIO_STANDARD_UMTS == radioMode)
    {
        BspSetUmtsDlFilterCpgBw(difChan, carrNo, bspBw);
        BspGetCfrFreqFiOffset(difChan,pUmtsInfo);
        fiTemp = pUmtsInfo[difChan].offset;
    }
    else
    {
    	fiTemp = fi;
    }

    return fiTemp;
}

UINT32 BspGetdeltPowFreq(UINT32 ratedPower,UINT32 carrPowMw,UINT32 deltPowFreq)
{
	UINT32 deltPowFreqTemp = 0;

    if (carrPowMw > 0)
    {
    	deltPowFreqTemp = (UINT32)round(10 * log10(ratedPower/carrPowMw));
    }
    else
    {
    	deltPowFreqTemp = deltPowFreq;
    }

    return deltPowFreqTemp;
}

FLOAT BspGetgi(UINT32 difChn,UINT32 carrRadio,UINT32 ulCarr,FLOAT giTemp,FLOAT giTempMax)
{
	FLOAT gi = 0.0;
	UINT32 nbCarrMode     = 0;

	if(giTempMax <= (-EPSINON) || giTempMax >= EPSINON)
	{
		gi = (FLOAT)round((giTemp / giTempMax) * pow(2, 25) / 2609);
	}

    if(RADIO_STANDARD_NB_IOT == carrRadio)
    {
        nbCarrMode = BspGetNBCarrMode(difChn,ulCarr);

        if(nbCarrMode != NB_STANDALONE)
        {
            gi = 0;
        }

        dbgInfoEx("[%s] >>> NBCarrMode:[%d]\n",__FUNCTION__,nbCarrMode);
    }

    return gi;
}


UINT32 BspGetOriginValidLen(UINT32 uiDelayEqualFlag,UINT32 vaildLen,UINT32 uiCpgCoefLenHalfMax)
{
	UINT32 originValidLen = 0;

    if(uiDelayEqualFlag == 1)//如果是等时延
    {
        if (vaildLen < 512)
        {
            originValidLen = 509;
        }
        else
        {
            originValidLen = uiCpgCoefLenHalfMax;
        }
    }
    else
    {
        originValidLen = vaildLen;
    }

    return originValidLen;
}

/*****************************************************************************
*  函数名称   : BspCfrSetUmtsCpgPara_HwCal
*  功能描述   : 设置U单边滤波后在线计算CPG系数所需参数
*  输入参数   : difChn - 中频通道, umtsBw - 单边滤波后UMTS带宽
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 与非单边滤波的削峰相比，波及以下两点：
               (1)需用高层传递的单边滤波后的U带宽匹配原型系数;
               (2)载波NCO计算：fi=原链路载波NCO-NCO1。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-12-13 22:13:11
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetUmtsCpgPara_HwCal(UINT32 difChn, UINT32 ulCarrId, UINT32 umtsBw)
{
    UINT32 ret            = BSP_OK;
    UINT32 bandLoop       = 0;
    UINT32 carrLoop       = 0;
    UINT32 cnt            = 0;
    UINT32 carrBw         = 0;
    UINT32 cfrBw          = 0;
    UINT32 cfrFs          = 0;
    UINT32 carrPowMw      = 0;
    UINT32 carrNo         = 0;
    UINT32 hwChnMask      = 0;
    UINT32 originCoefLen  = 0;
    UINT32 originValidLen = 0;
    UINT32 carrRadio      = 0;
    UINT32 staPowStepFreq = 0;
    UINT32 deltPowFreq    = 0;
    UINT32 deltPowFreqTemp    = 0;
    UINT32 ratedPower     = 0;
    UINT32 symNum         = 0;
    UINT32 uiFreqWord     = 0;
    UINT32 nbCarrMode     = 0;
    INT32 freqWord        = 0;
    INT32 fi              = 0;
    FLOAT wei             = 0.0;
    FLOAT giTemp          = 0.0;
    FLOAT giTempMax       = 1.0;
    FLOAT gi              = 0.0;
    FLOAT ciSq            = 0.0;
    FLOAT pci             = 0.0;
    UINT32 uCarrBw[BSP_MAX_CARR_NUM] = {0};
    UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptCfrParaHardCpg cfrHWCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};
    T_CfrLteUmtsFreqFiOffsetInfo pUmtsInfo[MAX_TX_CHANNEL] = {0};

    ret |= BspGetDifChnHwMask(&hwChnMask);
    ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    ret |= BspCfrCpgGetGiTempMax(difChn, &giTempMax);
    ret |= BspGetCfrKiCommPara(&cfrHWCpgPara);
    ret |= BspGetCfrCommPara(&cfrCommPara);
    ret |= BspGetRruPathRatedPower(difChn, &ratedPower);

    dbgInfoEx("[%s] cfrFs:%d, ratedPower:%d \n", __FUNCTION__, cfrFs, ratedPower);

    chnChgFlag = BspGetchnChgFlag(hwChnMask,difChn);

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    RETURN_VAL_DO_IF_EXP(pCfrDifChnInfo == NULL, BSP_ERROR, dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn));

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED);

        if (chnChgFlag == CFR_CHN_CHANGE)
        {
            ret |= BspHalAdaptCfrCleanGi(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetDlpreKiIndexDvSel(difChn, bandLoop);
            ret |= BspHalAdaptCfrSetCpgUpdateMode(difChn, bandLoop);

            symNum = BspGetsymNum(cfrCommPara.uiThrSel[difChn], cfrHWCpgPara.uiSymNum0[difChn], cfrHWCpgPara.uiSymNum1[difChn]);

            ret |= BspHalAdaptCfrSetDlpreKiIndexNum(difChn, bandLoop, symNum);
        }

        ret |= BspHalAdaptCfrCleanWord(difChn, bandLoop);

        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID);

            //fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            carrNo = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrPowMw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrRadio = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);

            fi = BspGetCarrFi(difChn,carrRadio,carrNo,umtsBw,pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi);

            deltPowFreq = 31;
            deltPowFreqTemp = 31;
            if (carrRadio == RADIO_STANDARD_GSM)
            {
                deltPowFreq = BspGetdeltPowFreq(ratedPower,carrPowMw,deltPowFreqTemp);

                ret |= BspHalAdaptGetGsmPowLevel(difChn, carrNo, carrRadio, &staPowStepFreq);
            }

            ret |= BspGetCfrCpgCoefCommon(difChn,cfrBw,cfrFs, &cfrCpgPara);

            CONTINUE_IF_EXP(ret != BSP_OK);

            CONTINUE_IF_EXP(NULL == cfrCpgPara.pCoefPara);

            originCoefLen = cfrCpgPara.coefLen;

            ciSq = 0;

            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }

            pci = (FLOAT)(2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2));

            giTemp = (FLOAT)(wei / sqrt(pci));

            RETURN_VAL_DO_IF_EXP(giTempMax >= (-EPSINON) && giTempMax <= EPSINON, BSP_ERROR, dbgInfoEx("[%s] error: giTempMax is zero!]\n",__FUNCTION__));

            gi = BspGetgi(difChn,carrRadio,carrNo,giTemp,giTempMax);

            if (BSP_RADIO_STANDARD_UMTS == carrRadio)
            {
                uCarrBw[carrNo] = carrBw;
            }

            originValidLen = BspGetOriginValidLen(cfrCommPara.uiDelayEqualFlag[difChn],cfrCpgPara.vaildLen,cfrCommPara.uiCpgCoefLenHalfMax[difChn]);

            if (chnChgFlag == CFR_CHN_CHANGE)
            {
                ret |= BspHalAdaptCfrSetGi(difChn, bandLoop, carrNo, carrRadio, (UINT32)gi);
                ret |= BspHalAdaptCfrSetOriginCoef(difChn, carrNo, carrRadio, originValidLen, &cfrCpgPara.pCoefPara[CPG_COEF_LEN_HALF_MAX_768 - originValidLen]);
                ret |= BspHalAdaptSetDlpreKiIndexGsm(difChn, carrNo, carrRadio, staPowStepFreq, deltPowFreq);
                ret |= BspHalAdaptCfrSetcfgFlag(difChn, bandLoop);
            }

            freqWord = (INT32)round(((DOUBLE)fi/cfrFs) * pow(2, 32));

            uiFreqWord = (UINT32)((freqWord < 0) ? (freqWord + pow(2,32)) : freqWord);

            dbgInfoEx("[%s] giTemp:%f, giTempMax:%f, pci:%f, freqWord:0x%x, cfrBw'%d\n",
                    __FUNCTION__, giTemp, giTempMax, pci, freqWord, cfrBw);

            dbgInfoEx("[%s] difChn'%d, carrIndex'%d, carrRadio'%d, carrPowMw'%d, carrBw'%d, carrFi:%d, wei:%f, gi:%f, uiFreqWord:%u\n",
                    __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, carrBw, fi, wei, gi, uiFreqWord);

            ret |= BspHalAdaptCfrSetWord(difChn, bandLoop, carrNo, carrRadio, uiFreqWord);
        }
    }

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
    {

    	ret |= BspSetUmtsDlFilterCpgBwByCarrBw(difChn, carrLoop, uCarrBw[carrLoop]);
    }

    BspLog(LOG_LEVEL_0,"[%s] chn'%d, cfrFs'%d, giTempMax'%f, chgFlag'%d, umtsBw'%d, ret'%s.\n",
                __FUNCTION__,difChn,cfrFs,giTempMax,chnChgFlag,umtsBw,(ret == BSP_OK)?"OK":"Error");

    return ret;
}

/**********************************************************************
* 函数名称：BspSetUmtsCpgCoef
* 功能描述：设置U单边滤波后的CPG系数
* 输入参数：参数0:bsp通道 ，参数1:制式 ，参数2:带宽，参数3:U单边滤波开启标志，1开启，0关闭
* 返 回 值: BSP_OK  - 成功;其它值为失败
* 其它说明：IC4.2未使用 cfgflag 标志
***********************************************************************/
UINT32 BspSetUmtsCpgCoef(UINT32 bspChan, UINT32 ulCarrId, UINT32 radioMod, UINT32 umtsBw, UINT32 cfgflag)
{
    UINT32 retVal   = BSP_OK;
    UINT32 difChn   = 0;
    UINT32 chipidx  = 0;
    UINT32 cpgMode  = 0;
    UINT32 freqBand = 0;
    UINT32 suspend  = CFR_CPG_HW_CAL_STOP;
    UINT32 mode     = 0;
    UINT32 ulCfrByPassMode = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    if(BSP_OK != BspGetCfrCommPara(&cfrCommPara))
    {
       dbgErr("%s Get CFR Commom Para Error!",__FUNCTION__);
       return BSP_ERROR;
    }

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipidx, &difChn);

    mode = BspGetCfrWorkMode();
    if (mode == CFR_NORMAL_MODE)
    {
        retVal = BspCfrChnInfoUpdateByBspChn(bspChan);
        if (retVal != BSP_OK)
        {
            dbgInfoEx("[%s]Cfr Get Chn Info Error \n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if((NULL == pCfrDifChnInfo) || (pCfrDifChnInfo->centerFreq == 0))
    {
        dbgInfoEx("[%s] error, get cfr commom para or Chn[%d] Info fail! \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    if(difChn < CFR_CHAN_MAX_NUM)
    {
        cpgMode = cfrCommPara.uiCpgMode[difChn];
    }
    else
    {
        dbgInfoEx("[%s] difChn out of range!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    ulCfrByPassMode = cfrCommPara.uiCfrBypassMode[difChn];
    if (CFR_ZERODLY_BYPASS == ulCfrByPassMode)
    {
        retVal |= BspCfrDisable(difChn);
        dbgInfoEx("[%s] Chn %d Cfr Bypass Mode(%d) is Zero Dly ByPass\n",__FUNCTION__,difChn,ulCfrByPassMode);
        return retVal;
    }

    if (BspGetCfrFuncFlag() == CFR_FUNC_NOT_INIT)
    {
        dbgInfoEx("[%s]FUNC CFR NOT INIT \n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspCfrDisable(difChn);
    retVal |= BspCfrGateInit(difChn);
    if (retVal != BSP_OK)
    {
        dbgInfoEx("[%s]Cfr Gate NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspSetCfrCfg(difChn);
    retVal |= BspCfrSetBbTssiCfg(difChn);
    retVal |= BspHalAdaptCfrSetSymstrGsmSel(difChn, freqBand);
    retVal |= BspHalAdaptCfrSetCpgMode(difChn, freqBand, cpgMode);

    if(cpgMode == CFR_CPG_CPU_CAL)
    {
        dbgInfoEx("[%s]: difChn'%d UMTS Filter Cfr Cpg Use CPU Calculation! \n", __FUNCTION__, difChn);

        retVal = BspCfrCpgDataMemApply();
        if(retVal == BSP_ERROR)
        {
            dbgInfoEx("[%s] Cfr Cpg Data Apply Mem Error \n", __FUNCTION__);
            BspLog(LOG_LEVEL_0, "[%s] Cfr Cpg Data Apply Mem Error \n", __FUNCTION__);
            return BSP_ERROR;
        }

        retVal |= BspCfrSetUmtsCpgPara_CpuCal(difChn, umtsBw);
        retVal |= BspSetCpgCfg(difChn);
    }
    else
    {
        dbgInfoEx("[%s]: difChn'%d UMTS Filter Cfr Cpg Use Hardware Calculation! \n", __FUNCTION__, difChn);

        retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);
        retVal |= BspCfrSetUmtsCpgPara_HwCal(difChn, umtsBw);
        suspend = CFR_CPG_HW_CAL_START;
        retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);
    }

    retVal |= BspSetCfrDelay(difChn);
    retVal |= BspCfrSetTddSwPara(difChn);
    retVal |= BspCfrSetCpgLen(difChn);
    retVal |= BspCfrEnable(difChn);

    return retVal;
}

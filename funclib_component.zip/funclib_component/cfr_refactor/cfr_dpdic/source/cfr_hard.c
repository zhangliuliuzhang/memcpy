/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_hard.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2的CFR模块配置功能
* 注意事项 : 无
* 作    者 : 张龙10281388
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 张龙10281388
* 修改日戳: 2023-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "bsppub.h"
#include "cfr_dss.h"
#include "cfr_cpgcal.h"
#include "ichaladaptcfrapi.h"
#include "cfr_hard.h"
#include "cfr_cfgpara.h"
#include "cfr_dpdic.h"
#include "ichaladapt_ic4_2.h"
#include "freqcfg_ic4_2.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"


UINT32 g_difChnChgHwMask = 0;
T_BspHalAdaptDifCommCfrPara *s_pCfrCommPara = NULL;


//获取硬CFR CPG系数长度
UINT32 BspGetCfrHwCpgLen(T_CfrCpgPara *cfrCpgPara, T_BspHalAdaptDifCommCfrPara *cfrCommPara, UINT32 *originValidLen)
{
	UINT32 difChan            = 0;

    INPUT_POINTER_CHECK(cfrCpgPara);
    INPUT_POINTER_CHECK(cfrCommPara);
    INPUT_POINTER_CHECK(originValidLen);
    
    if(cfrCommPara->uiDelayEqualFlag[difChan] == 1)//如果是等时延
    {
        if (cfrCpgPara->vaildLen < 512)
        {
            *originValidLen = 509;
        }
        else
        {
            *originValidLen = cfrCommPara->uiCpgCoefLenHalfMax[difChan];
        }
    }
    else
    {
        *originValidLen = cfrCpgPara->vaildLen;
    }
            
    return BSP_OK;
}

//获取硬CFR Gi参数
UINT32 BspGetCfrHwGi(T_CfrCpgPara *cfrCpgPara, FLOAT *gi, FLOAT *wei, FLOAT *giTempMax)
{
    UINT32 cnt            = 0;
    UINT32 originCoefLen  = 0;
    FLOAT ciSq            = 0.0;
    FLOAT pci             = 0.0;
    FLOAT giTemp          = 0.0;
      
    INPUT_POINTER_CHECK(cfrCpgPara);
    INPUT_POINTER_CHECK(cfrCpgPara->pCoefPara);
    INPUT_POINTER_CHECK(gi);
    INPUT_POINTER_CHECK(wei);
    INPUT_POINTER_CHECK(giTempMax);
    
    originCoefLen = cfrCpgPara->coefLen;  

    for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
    {
        ciSq += pow(cfrCpgPara->pCoefPara[cnt], 2);
    }
  
    pci = 2 * ciSq + pow(cfrCpgPara->pCoefPara[originCoefLen - 1], 2);

    giTemp = (FLOAT)(*wei / sqrt(pci));

    if (*giTempMax >= (-EPSINON) && *giTempMax <= EPSINON)
    {
        dbgInfo("[%s] error: giTempMax is zero!]\n",__FUNCTION__);
        return BSP_ERROR;
    }
    else
    {
        *gi = (FLOAT)round((giTemp / *giTempMax) * pow(2, 25) / 2609);
    }       

    return BSP_OK;
}

//获取硬CFR CPG系数
UINT32 BspGetCfrHwCpgCfg(T_BspHalAdaptDifCommCfrPara *cfrCommPara, FLOAT *giTempMax)
{
    UINT32 ret            = BSP_OK;
    UINT32 symNum         = 0;
    FLOAT  gi             = 0.0;
    FLOAT  wei            = 0.0;
    INT32  fi             = 0;
    UINT32 carrNo         = 0;
    UINT32 carrBw         = 0;
    UINT32 carrPowMw      = 0;
    UINT32 originValidLen = 0;
    UINT32 deltPowFreq    = 0;
    UINT32 uiFreqWord     = 0;
    UINT32 nbCarrMode     = 0;
    INT32 freqWord        = 0;
    UINT32 bandLoop       = 0;
    T_CfrCpgPara cfrCpgPara = {0};
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;
    UINT32 difChan = 0;
    UINT32 uCarrBw[BSP_MAX_CARR_NUM] = {0};
    UINT32 carrRadio      = 0;
    T_BspHalAdaptCfrParaHardCpg cfrHWCpgPara = {0};
    UINT32 cfrFs          = 0;
    UINT32 cfrBw          = 0;
    UINT32 ratedPower     = 0;
    UINT32 staPowStepFreq = 0;
    UINT32 carrLoop      = 0;

    INPUT_POINTER_CHECK(cfrCommPara);
    INPUT_POINTER_CHECK(giTempMax);
    

    ret |= BspGetCfrFsByDifChn(difChan,&cfrFs);
    ret |= BspGetCfrKiCommPara(&cfrHWCpgPara);
    ret |= BspGetRruPathRatedPower(difChan, &ratedPower);


    pCfrDifChnInfo = BspGetCfrChnInfo(difChan);
    RETURN_VAL_DO_IF_EXP(pCfrDifChnInfo == NULL, BSP_ERROR, dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChan));

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED);

        if (chnChgFlag == CFR_CHN_CHANGE)
        {
            ret |= BspHalAdaptCfrCleanGi(difChan, bandLoop);
            ret |= BspHalAdaptCfrSetDlpreKiIndexDvSel(difChan, bandLoop);
            ret |= BspHalAdaptCfrSetCpgUpdateMode(difChan, bandLoop);

            if (cfrCommPara->uiThrSel[difChan] == 1)
            {
                symNum = cfrHWCpgPara.uiSymNum0[difChan];
            }
            else
            {
                symNum = cfrHWCpgPara.uiSymNum1[difChan];
            }

            ret |= BspHalAdaptCfrSetDlpreKiIndexNum(difChan, bandLoop, symNum);
        }

        ret |= BspHalAdaptCfrCleanWord(difChan, bandLoop);
        
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID);

            fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            carrNo = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrPowMw = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;
            carrRadio = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);

            deltPowFreq = 31;
            if (carrRadio == RADIO_STANDARD_GSM)
            {
                if (carrPowMw > 0)
                {
                    deltPowFreq = (UINT32)round(10 * log10(ratedPower/carrPowMw));
                }
                
                ret |= BspHalAdaptGetGsmPowLevel(difChan, carrNo, carrRadio, &staPowStepFreq);
            }
 
            ret |= BspGetCfrCpgCoefCommon(difChan, cfrBw, cfrFs, &cfrCpgPara);
            CONTINUE_IF_EXP(ret != BSP_OK);
              
            if(BspGetCfrHwGi(&cfrCpgPara, &gi, &wei, giTempMax) != BSP_OK)
            {
                return BSP_ERROR;
            }
            
            if(RADIO_STANDARD_NB_IOT == carrRadio)
            {
                nbCarrMode = BspGetNBCarrMode(difChan,carrNo);
                
                if(nbCarrMode != NB_STANDALONE)
                {
                    gi = 0;
                }
        
                dbgInfo("[%s] >>> NBCarrMode:[%d]\n",__FUNCTION__,nbCarrMode);
            }

            if (BSP_RADIO_STANDARD_UMTS == carrRadio)
            {
                uCarrBw[carrNo] = carrBw;
            }

            BspGetCfrHwCpgLen(&cfrCpgPara, cfrCommPara, &originValidLen);
            
            if (chnChgFlag == CFR_CHN_CHANGE)
            {
                ret |= BspHalAdaptCfrSetGi(difChan, bandLoop, carrNo, carrRadio, (UINT32)gi);
                ret |= BspHalAdaptCfrSetOriginCoef(difChan, carrNo, carrRadio, originValidLen, &cfrCpgPara.pCoefPara[CPG_COEF_LEN_HALF_MAX_768 - originValidLen]);
                ret |= BspHalAdaptSetDlpreKiIndexGsm(difChan, carrNo, carrRadio, staPowStepFreq, deltPowFreq);
                ret |= BspHalAdaptCfrSetcfgFlag(difChan, bandLoop);
            }

            freqWord = round(((DOUBLE)fi/cfrFs) * pow(2, 32));

            uiFreqWord = (UINT32)((freqWord < 0) ? (freqWord + pow(2,32)) : freqWord);

            dbgInfoEx("[%s] giTempMax:%f, freqWord:0x%x, cfrBw'%d\n",
                    __FUNCTION__, *giTempMax, freqWord, cfrBw);

            dbgInfo("[%s] difChan'%d, carrIndex'%d, carrRadio'%d, carrPowMw'%d, carrBw'%d, carrFi:%d, wei:%f, gi:%f, uiFreqWord:%u\n",
                    __FUNCTION__, difChan, carrNo, carrRadio, carrPowMw, carrBw, fi, wei, gi, uiFreqWord);

            ret |= BspHalAdaptCfrSetWord(difChan, bandLoop, carrNo, carrRadio, uiFreqWord);
        }
    }
    
    return BSP_OK;
}

/** 获取削峰硬件计算存在改配的通道掩码 **/
UINT32 BspGetDifChnHwMask(UINT32 *chnMask)
{
	INPUT_POINTER_CHECK(chnMask);

	*chnMask = g_difChnChgHwMask;
	dbgInfoEx("%s|g_difChnChgHwMask: 0x%x \n",__FUNCTION__, g_difChnChgHwMask);

	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspCfrSetHwCpgCfg
*  功能描述   : 配置削峰硬件计算CPG系数所需参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 10:09:07
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetHwCpgCfg(UINT32 difChan)
{
    UINT32 ret            = BSP_OK;
    UINT32 bandLoop       = 0;
    UINT32 carrLoop       = 0;
    UINT32 freqBand       = 0;
    UINT32 cnt            = 0;
    UINT32 carrBw         = 0;
    UINT32 cfrBw          = 0;
    UINT32 cfrFs          = 0;
    UINT32 carrPowMw      = 0;
    UINT32 carrNo         = 0;
    UINT32 hwChnMask      = 0;    
    UINT32 carrRadio      = 0;
    UINT32 staPowStepFreq = 0;
    UINT32 deltPowFreq    = 0;
    UINT32 ratedPower     = 0;
    UINT32 symNum         = 0;
    UINT32 uiFreqWord     = 0;
    UINT32 nbCarrMode     = 0;
    INT32 freqWord        = 0;
    INT32 fi              = 0;
   
    FLOAT giTempMax       = 1.0;

    UINT32 uCarrBw[BSP_MAX_CARR_NUM] = {0};
    UINT32 chnChgFlag     = CFR_CHN_NO_CHANGE;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    
    T_BspHalAdaptCfrParaHardCpg cfrHWCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    ret |= BspGetDifChnHwMask(&hwChnMask);
    ret |= BspGetCfrFsByDifChn(difChan,&cfrFs);
    ret |= BspCfrCpgGetGiTempMax(difChan, &giTempMax);
    ret |= BspGetCfrKiCommPara(&cfrHWCpgPara);
    ret |= BspGetCfrCommPara(&cfrCommPara);
    ret |= BspGetRruPathRatedPower(difChan, &ratedPower); 

    dbgInfo("[%s] cfrFs:%d, ratedPower:%d \n", __FUNCTION__, cfrFs, ratedPower);

    if (CFR_CHN_CHANGE == GET_BIT(hwChnMask, difChan))
    {
        chnChgFlag = CFR_CHN_CHANGE;
    }

    pCfrDifChnInfo = BspGetCfrChnInfo(difChan);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChan);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChan);
        return BSP_ERROR;
    }
   
    if (CFR_CARR_EXIST_DSS == BspGetCfrChanDssFlag(difChan))
    {
        dbgInfo("[%s]: difChan'%d  Cfr Cpg Use DSS Hardware Calculation! \n", __FUNCTION__,difChan);
        ret |= BspHalAdaptCfrClrOriginCoefCarrInfo(difChan, freqBand);
        ret |= BspHalAdaptCfrCleanDlpreKiPowSel(difChan, freqBand);
        ret |= BspSetCfrDSSCarrGroupInfo(difChan, pCfrDifChnInfo);
    }

    BspGetCfrHwCpgCfg(&cfrCommPara, &giTempMax); 

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
    {
        if (uCarrBw[carrLoop] != 0)
        {           
            ret |= BspSetUmtsDlFilterCpgBw(difChan, carrLoop, uCarrBw[carrLoop]);
        }
    }

    BspLog(LOG_LEVEL_0,"[%s] chn'%d, cfrFs'%d, giTempMax'%f, chgFlag'%d, ret'%s.\n", __FUNCTION__, difChan, cfrFs, giTempMax, chnChgFlag, (BSP_OK==ret)?"OK":"Error");

    return ret;
}


/*****************************************************************************
*  函数名称   : BspCfrSetCpgPara_HwCal
*  功能描述   : 配置削峰硬件计算 CPG 所需参数
*  输入参数   : bspChn   - BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : IC4.2进行DSS处理的前提：通道中存在带宽严格大于30M的NR载波
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 10:43:40
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgPara_HwCal(UINT32 bspChn)
{
    UINT32 retVal   = BSP_OK;
    UINT32 freqBand = 0;
    UINT32 suspend  = CFR_CPG_HW_CAL_STOP;
    UINT32 difChan   = 0;
    UINT32 chipidx  = 0;
    UINT32 index    = 0;
    T_CfrChnBandInfo *pChnInfo = NULL;

    retVal = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    retVal |= BspHalAdaptCfrSetCpgSuspend(difChan, freqBand, suspend);  

    pChnInfo = BspGetCfrChnInfo(difChan);
    if (pChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChan);
        return BSP_ERROR;
    }

    retVal |= BspCfrSetHwCpgCfg(difChan);
    
    suspend = CFR_CPG_HW_CAL_START;
    retVal |= BspHalAdaptCfrSetCpgSuspend(difChan, freqBand, suspend); 

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspChnMaskToDif
*  功能描述   : 将BSP通道掩码转换为中频通道掩码
*  输入参数   : bspChnMask   - BSP通道掩码
*  输出参数   : difChnMask   - 中频通道掩码
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 通道号与bit位对应。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-29 10:48:26
*----------------------------------------------------------------------------
*/
UINT32 BspChnMaskToDif(UINT32 bspChnMask, UINT32 *difChnMask)
{
    UINT32 retVal         = BSP_OK;
    UINT32 chipidx        = 0;
    UINT32 bspChn         = 0;
	UINT32 difChn         = 0;
    UINT32 bitValue       = 0;
    UINT32 difChnMaskTemp = 0;

    INPUT_POINTER_CHECK(difChnMask);

    for(bspChn = 0; bspChn < BspGetTxChanNum(); bspChn++)
    {
        retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
        if (BSP_OK != retVal)
        {
            dbgInfoEx("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
            return BSP_ERROR;
        }

        bitValue = GET_BIT(bspChnMask, bspChn);
        difChnMaskTemp = WRITE_BIT(difChnMaskTemp, difChn, bitValue);
    }

    *difChnMask = difChnMaskTemp;

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCHgChnMaskToHw
*  功能描述   : 剔除改配中频通道掩码中CPG系数为软件计算的部分
*  输入参数   : difChnChgMask   - 改配中频通道掩码
*  输出参数   : difChnHwMask   - CPG系数采用硬件计算的改配中频通道掩码
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 通道号与bit位对应。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-29 15:23:06
*----------------------------------------------------------------------------
*/
UINT32 BspCHgChnMaskToHw(UINT32 difChnChgMask, UINT32 *difChnHwMask)
{
    UINT32 retVal = BSP_OK;
	UINT32 difChn = 0;

    INPUT_POINTER_CHECK(difChnHwMask);

    if(s_pCfrCommPara == NULL)
    {
        dbgInfoEx("%s>> s_pCfrCommPara not initialized!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    for(difChn = 0; difChn < BspGetTxChanNum(); difChn++)
    {
        if(CFR_CPG_CPU_CAL == s_pCfrCommPara->uiCpgMode[difChn])
        {
            difChnChgMask = CLEAR_BIT(difChnChgMask, difChn);
        }
    }

    *difChnHwMask = difChnChgMask;
    g_difChnChgHwMask = difChnChgMask;

    return retVal;
}

UINT32 BspHalAdaptDifCfrParaInit(T_BspHalAdaptDifCommCfrPara *pDifCfrPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDifCfrPara);

    s_pCfrCommPara = pDifCfrPara;

    SaveDifCfg(E_DIF_DIFPARA_CFR, (VOID*)pDifCfrPara, 1, 32);
    retVal = IcHalApiCfrCommParaInit(pDifCfrPara);

    return retVal;
}

UINT32 BspHalAdaptGetCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara)
{
    if(s_pCfrCommPara == NULL)
    {
        dbgInfo("[%s] s_pCfrCommPara is not initialized！\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy_s(pCfrCommPara, sizeof(T_BspHalAdaptDifCommCfrPara), s_pCfrCommPara, sizeof(T_BspHalAdaptDifCommCfrPara));

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrClrHwCpgRam
*  功能描述   : 清空CPG硬件计算原型系数ram以及制式与原型系数的映射关系
*  输入参数   : bspChnChgMask   - 由APP下发的BSP改配通道掩码，改配通道对应bit置1
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 当通道制式或带宽改配时由APP调用此接口。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-04-28 19:44:46
*----------------------------------------------------------------------------
*/
UINT32 BspCfrClrHwCpgRam(UINT32 bspChnChgMask)
{
    UINT32 retVal        = BSP_OK;
    UINT32 freqBand      = 0;
	UINT32 difChn        = 0;
    UINT32 difChnChgMask = 0;
    UINT32 difChnHwMask  = 0;
    UINT32 suspend       = CFR_CPG_HW_CAL_STOP;

    dbgInfoEx("[%s] The modified bspChannel mask from APP is 0x%x. \n",__FUNCTION__,bspChnChgMask);

    retVal = BspChnMaskToDif(bspChnChgMask, &difChnChgMask);
    retVal |= BspCHgChnMaskToHw(difChnChgMask, &difChnHwMask);

    dbgInfoEx("[%s] The hardware modified difChn mask is 0x%x. \n",__FUNCTION__,difChnHwMask);

    for(difChn = 0; difChn < BspGetTxChanNum(); difChn++)
    {
        if(CFR_CPG_HW_CAL == GET_BIT(difChnHwMask, difChn))
        {
            retVal |= BspHalAdaptCfrSetCpgSuspend(difChn, freqBand, suspend);
        }
    }

    retVal |= BspHalAdaptCfrSetchnChgHwMask(difChnHwMask);
    retVal |= BspHalAdaptSetCpgParaRangeCarrNum();
    retVal |= BspHalAdaptCfrSetBlock0Ram1Len();
    BspLog(LOG_LEVEL_0,"[%s] appMask'0x%x, hwMask'0x%x \n", __FUNCTION__,bspChnChgMask,difChnHwMask);

    return retVal;
}

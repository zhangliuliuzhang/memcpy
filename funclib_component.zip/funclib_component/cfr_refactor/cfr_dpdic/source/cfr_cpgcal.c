/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_cpgcal.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2中CFR模块的功能实现,主要实现的是CPG计算模式
* 注意事项 : 无
* 作    者 : 张龙10281388
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 张龙10281388
* 修改日戳: 2023-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/


#include <math.h>
#include "bspcomm.h"
#include "bsppub.h"
#include "cfr_cpgcal.h"
#include "cfrcommon.h"
#include "ichaladaptcfrapi.h"
#include "cfr_cfgpara.h"
#include "freqcfgcommon.h"
#include "cfr_dpdic.h"
#include "freqcfg_ic4_2.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static T_IcCfrCpgCpuCalData *s_cfrCpgCpuCalData = NULL;
static UINT32       s_pCfrDssEn = TRUE;

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define CFR_NO_POWER_VAL       -13700
#define ROUND(a)               ((INT32)(((a) < 0) ? ((a) - 0.5) : ((a) + 0.5)))

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/
/*** CPG系数内存申请 ***/
UINT32 BspCfrCpgDataMemApply(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChnNum    = 0;
    UINT32 chnLoop      = 0;
    UINT32 bandLoop     = 0;

    difChnNum   = BspGetCfrDifChnNum();

    if(s_cfrCpgCpuCalData == NULL)
    {
        s_cfrCpgCpuCalData = (T_IcCfrCpgCpuCalData *)malloc(sizeof(T_IcCfrCpgCpuCalData) * difChnNum);
        if(s_cfrCpgCpuCalData == NULL)
        {
            return BSP_ERROR;
        }
        memset(s_cfrCpgCpuCalData,0,(sizeof(T_IcCfrCpgCpuCalData) * difChnNum));
        for(chnLoop = 0;chnLoop < difChnNum;chnLoop ++)
        {
            for(bandLoop = 0;bandLoop < E_CFR_BAND_MAX ;bandLoop ++)
            {
                s_cfrCpgCpuCalData[chnLoop].cfrBand[bandLoop].pCpgImag = NULL;
                s_cfrCpgCpuCalData[chnLoop].cfrBand[bandLoop].pCpgReal = NULL;
                s_cfrCpgCpuCalData[chnLoop].cfrBand[bandLoop].cpgLen   = 0;
            }
        }
    }

    return retVal;
}

/*cfr CPG数据存储*/
UINT32 BspCfrCpgSaveTxtDpdic4_2(UINT32 difChn, UINT32 cfrband, DOUBLE *pDataReal, DOUBLE *pDataImg, UINT32 dataLen)
{
    FILE *fin  = NULL;
    FILE *fout = NULL;
    UINT32 dataLoop = 0;
    INT32 coef = 0;
    CHAR acFileName[CFR_FILE_NAME_LEN] = {0};
    CHAR acFileNameR[CFR_FILE_NAME_LEN] = {0};
    CHAR acFileNameI[CFR_FILE_NAME_LEN] = {0};
    INT32 sReal = 0;
    INT32 sImag = 0;
    INT32 cnt = 0;
    INT32 ret = 0;

    ret = snprintf_s(acFileName, CFR_FILE_NAME_LEN, "dpd3Cfr[%d][%d]_Coef.txt", difChn, cfrband);
    SNPRINTF_S_CHECK(ret, sizeof(acFileName));

    fout = fopen(acFileName,"w+");

    if (NULL == fout)
    {
        return BSP_ERROR;
    }

    for (dataLoop = 0; dataLoop < dataLen; dataLoop ++)
    {
        coef  = (((INT32)ROUND(pDataReal[dataLoop])&0x1FFF)<<13)|((INT32)ROUND(pDataImg[dataLoop])&0x1FFF);

        ret = fprintf(fout, "%d\n", coef);
        FPRINTF_CHECK(ret);
    }
    ret = fclose(fout);
    FCLOSE_CHECK(ret);

    ret = snprintf_s(acFileNameR, CFR_FILE_NAME_LEN, "dpd42Cfr[%d][%d]_RealCoef.txt", difChn, cfrband);
    SNPRINTF_S_CHECK(ret, CFR_FILE_NAME_LEN);
    ret = snprintf_s(acFileNameI, CFR_FILE_NAME_LEN, "dpd42Cfr[%d][%d]_ImagCoef.txt", difChn, cfrband);
    SNPRINTF_S_CHECK(ret, CFR_FILE_NAME_LEN);

    fin  = fopen(acFileNameR,"w+");

    if ((NULL == fin))
    {
       return BSP_ERROR;
    }

    fout = fopen(acFileNameI,"w+");

    if (NULL == fout)
    {
       ret = fclose(fin);
       FCLOSE_CHECK(ret);
       return BSP_ERROR;
    }
    cnt = -1;
    for (dataLoop = 0; dataLoop < dataLen; dataLoop ++)
    {
       sReal  = (INT32)ROUND(pDataReal[dataLoop]);
       sImag  = cnt*(INT32)ROUND(pDataImg[dataLoop]);
       ret = fprintf(fin, "%d\n", sReal);
       FPRINTF_CHECK(ret);
       ret = fprintf(fout, "%d\n", sImag);
       FPRINTF_CHECK(ret);
    }

    ret = fclose(fout);
    FCLOSE_CHECK(ret);
    ret = fclose(fin);
    FCLOSE_CHECK(ret);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrDataSave_CpuCal
*  功能描述   : cpg 系数保存
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙@2023-06-30 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrDataSave_CpuCal(UINT32 difChn, UINT32 band, DOUBLE *pCpgReal, DOUBLE *pCpgImag , UINT32 dataNum, DOUBLE sumBandGK,UINT32 vaildMaxLen)
{
    UINT32 loop = 0;

    INPUT_DIFCHAN_CHECK(difChn);
    INPUT_POINTER_CHECK(pCpgReal);
    INPUT_POINTER_CHECK(pCpgImag);

    if (band >= E_CFR_BAND_MAX)
    {
        dbgInfo("[%s]dif %d Band %d Error !Save Cfr Cpg Data Error \n", __FUNCTION__, difChn, band);
        return BSP_ERROR;
    }

    if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag == NULL)
    {
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag = (INT32 *)malloc(sizeof(INT32) * dataNum);

        if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag == NULL)
        {
            dbgInfo("[%s]dif %d Band %d Cfr Cpg ImagData Malloc Error \n", __FUNCTION__, difChn, band);
            free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal);
            return BSP_ERROR;
        }
    }
    memset_s(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag, sizeof(INT32)*dataNum, 0, sizeof(INT32)*dataNum);

    if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal == NULL)
    {
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal = (INT32 *)malloc(sizeof(INT32) * dataNum);

        if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal == NULL)
        {
            dbgInfo("[%s]dif %d Band %d Cfr Cpg RealData Malloc Error \n", __FUNCTION__, difChn, band);
            free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag);
            return BSP_ERROR;
        }
    }
    memset_s(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal, sizeof(INT32)*dataNum, 0, sizeof(INT32)*dataNum);

    if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef == NULL)
    {
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef = (INT32 *)malloc(sizeof(INT32) * dataNum);

        if (s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef == NULL)
        {
            dbgInfo("[%s]dif %d Band %d Cfr Cpg RealData Malloc Error \n", __FUNCTION__, difChn, band);
            free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag);
            free(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal);
            s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag = NULL;
            s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal = NULL;
            return BSP_ERROR;
        }
    }
    memset_s(s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef, sizeof(INT32)*dataNum, 0, sizeof(INT32)*dataNum);

    for (loop = 0; loop < dataNum ; loop ++)
    {
        pCpgReal[loop] = pCpgReal[loop] / sumBandGK;
        pCpgImag[loop] = pCpgImag[loop] / sumBandGK;
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal[loop] = (INT32)ROUND(pCpgReal[loop]);
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag[loop] = -1*(INT32)ROUND(pCpgImag[loop]);
        s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef[loop]    =((s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal[loop]&0x1FFF)<<16)|((s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag[loop])&0x1FFF);
        s_cfrCpgCpuCalData[difChn].cfrBand[band].flag           = IC_FLAG_USED;
        dbgInfoEx("[%s]difchn'%d band'%d cpgval'0x%x real'0x%x imag'0x%x \n",__FUNCTION__,difChn,band,s_cfrCpgCpuCalData[difChn].cfrBand[band].pCoef[loop],s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgReal[loop],s_cfrCpgCpuCalData[difChn].cfrBand[band].pCpgImag[loop]);
    }

    BspCfrCpgSaveTxtDpdic4_2(difChn,band,pCpgReal, pCpgImag, dataNum);
    s_cfrCpgCpuCalData[difChn].cfrBand[band].cpgLen = dataNum;
    s_cfrCpgCpuCalData[difChn].cfrBand[band].cpgVaildLen  = vaildMaxLen;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   :BspCfrSetBandNum
*  功能描述   :设置频段数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*            :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙@2023-06-30 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetBandNum(UINT32 difChn,UINT32 cfrBandNum)
{
    INPUT_DIFCHAN_CHECK(difChn);

    s_cfrCpgCpuCalData[difChn].cfrBandNum = cfrBandNum;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrCpgGetWei
*  功能描述   : 根据制式获取削峰CPG系数计算过程中的wei值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cfrFs - CPG速率
               carrRadio - 载波制式
*  输出参数   : wei - wei参数
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : wei用于调整载波evm均衡
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 11:13:12
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgGetWei(UINT32 cfrFs, UINT32 carrRadio, DOUBLE *wei)
{
    UINT32 retVal      = BSP_OK;
    DOUBLE weiFactor = 0.0;
    T_CfrWeiFactor cfrWeiFactor = {0};

    retVal = BspGetWeiCfrFactorCommon(cfrFs, &cfrWeiFactor);

    switch (carrRadio)
    {
        case BSP_RADIO_STANDARD_GSM:
            weiFactor = cfrWeiFactor.wei_gsm;
            break;
        case BSP_RADIO_STANDARD_UMTS:
            weiFactor = cfrWeiFactor.wei_umts;
            break;
        case BSP_RADIO_STANDARD_LTE_FDD:
            weiFactor = cfrWeiFactor.wei_lte_fdd;
            break;
        case BSP_RADIO_STANDARD_LTE_TDD:
            weiFactor = cfrWeiFactor.wei_lte_tdd;
            break;
        case BSP_RADIO_STANDARD_5G:
            weiFactor = cfrWeiFactor.wei_nr;
            break;
        case BSP_RADIO_STANDARD_5G_RESERVED:
            weiFactor = cfrWeiFactor.wei_nr;
            break;
        case BSP_RADIO_STANDARD_NB_IOT:
            weiFactor = cfrWeiFactor.wei_nb_lot;
            break;
        default:
            weiFactor = cfrWeiFactor.wei_nr;
            break;
    }
    *wei = weiFactor;

    dbgInfoEx("[%s] wei:%f, carrRadio:0x%x,  cfrFs:%d \n", __FUNCTION__, weiFactor, carrRadio, cfrFs);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrCpgGetGiTempMax
*  功能描述   : 获取削峰CPG系数计算过程中的giTemp最大值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : giTempMax - giTemp最大值
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 11:13:12
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgGetGiTempMax(UINT32 difChn, FLOAT *giTempMax)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 cnt           = 0;
    UINT32 carrRadio     = 0;
    UINT32 carrBw        = 0;
    UINT32 cfrBw         = 0;
    UINT32 cfrFs         = 0;
    UINT32 originCoefLen = 0;
    FLOAT wei            = 0.0;
    FLOAT giTemp         = 0.0;
    FLOAT giMax          = 1e-10;
    FLOAT ciSq           = 0.0;
    FLOAT pci            = 0.0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};

    INPUT_DIFCHAN_CHECK(difChn);
    INPUT_POINTER_CHECK(giTempMax);

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    ret = BspGetCfrFsByDifChn(difChn,&cfrFs);

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;

            ret = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrCpgCoefCommon(difChn,cfrBw,cfrFs, &cfrCpgPara);
            if (ret != BSP_OK)
            {
                continue;
            }

            originCoefLen = cfrCpgPara.coefLen;

            ciSq = 0;

            for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
            {
                ciSq += pow(cfrCpgPara.pCoefPara[cnt], 2);
            }

            pci = 2 * ciSq + pow(cfrCpgPara.pCoefPara[originCoefLen - 1], 2);
            giTemp = wei / sqrt(pci);

            if (giTemp >= giMax)
            {
                giMax = giTemp;
            }
        }
    }

    *giTempMax = giMax;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrCpgCfg_CpuCal
*  功能描述   : cpg配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙@2023-06-30 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCpgCfg_CpuCal(UINT32 difChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pCpgCoef = NULL;
    UINT32 ulCpgLen = 0;
    UINT32 freqBand = 0;

    pCpgCoef = s_cfrCpgCpuCalData[difChn].cfrBand[0].pCoef;
    ulCpgLen = s_cfrCpgCpuCalData[difChn].cfrBand[0].cpgVaildLen;
    if((NULL == pCpgCoef)||(0 == ulCpgLen))
    {
        dbgErr("Cpg is Null or CpgLen is %d ",ulCpgLen);
        return BSP_ERROR;
    }

    retVal  = BspHalAdaptCfrSetCpgTblCfg(difChn, freqBand, pCpgCoef, ulCpgLen);

    return retVal;
}

UINT32 BspCfrGetCpgVaildLen(UINT32 difChn, UINT32 *vaildlen)
{
    UINT32 retVal        = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 cpgVaildLen   = 0;
    UINT32 cfrBw         = 0;
    UINT32 cfrFs         = 0;
    UINT32 carrBw        = 0;
    UINT32 carrRadio     = 0;
    T_CfrCpgPara cfrCpgPara = {0};
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    INPUT_POINTER_CHECK(vaildlen);
    INPUT_DIFCHAN_CHECK(difChn);

    retVal = BspGetCfrCommPara(&cfrCommPara);

    if (cfrCommPara.uiCpgMode[difChn] == CFR_CPG_CPU_CAL)
    {
        if(s_cfrCpgCpuCalData == NULL)
        {
            dbgErr("CFR is not init!");
            return BSP_ERROR;
        }

        *vaildlen = s_cfrCpgCpuCalData[difChn].cfrBand[0].cpgVaildLen;

        return retVal;
    }

    if(cfrCommPara.uiDelayEqualFlag[difChn] == 1)//硬件计算等时延
    {
        *vaildlen = cfrCommPara.uiCpgCoefLenHalfMax[difChn];

        return retVal;
    }

    /* 硬件计算不等时延: 通道Cpg有效长度为通道中各载波原型系数有效长度最大值 */
    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    retVal |= BspGetCfrFsByDifChn(difChn,&cfrFs);

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        cpgVaildLen = 0;
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }

            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            retVal = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);

            retVal |= BspGetCfrCpgCoefCommon(difChn,cfrBw,cfrFs, &cfrCpgPara);
            if (retVal != BSP_OK)
            {
                continue;
            }

            cpgVaildLen = (cpgVaildLen > cfrCpgPara.vaildLen) ? cpgVaildLen : cfrCpgPara.vaildLen;
        }

        *vaildlen = cpgVaildLen;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : CfrGetCpgCfg_CpuCal
*  功能描述   : 获取cpg系数cpg配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 仅用于调试接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙@2023-06-30 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 CfrGetCpgCfg_CpuCal(UINT32 difChn,INT16 *pCpgReal,INT16 * pCpgImag,UINT32 cfrLutLen)
{
    UINT32 retVal = BSP_OK;
    UINT32 pCoef[CFR_CPG_RAM_768]={0};
    UINT32 coefLoop = 0;
    UINT32 freqBand = 0;

    cfrLutLen = (cfrLutLen > CFR_CPG_RAM_768)?CFR_CPG_RAM_768:cfrLutLen;
    retVal  = BspHalAdaptCfrGetCpgTblCfg(difChn, freqBand, pCoef, cfrLutLen);

    for(coefLoop = 0;coefLoop < cfrLutLen;coefLoop ++)
    {
        pCpgReal[coefLoop] = (INT16)((pCoef[coefLoop]>>16) &0x1FFF);
        pCpgImag[coefLoop] = (INT16)(pCoef[coefLoop] &0x1FFF);
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : CfrGetCpgCfg_CpuCal_IC4_2
*  功能描述   : 获取cpg系数cpg配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 仅用于调试接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 CfrGetCpgCfg_CpuCal_IC4_2(UINT32 difChn,INT16 *pCpgReal,INT16 * pCpgImag,UINT32 cfrLutLen)
{
	UINT32 retVal = BSP_OK;
	UINT32 pCoef[CFR_CPG_RAM_768]={0};
	UINT32 coefLoop = 0;
    UINT32 freqBand = 0;

	cfrLutLen = (cfrLutLen > CFR_CPG_RAM_768)?CFR_CPG_RAM_768:cfrLutLen;
	retVal  = BspHalAdaptCfrGetCpgTblCfg(difChn, freqBand, pCoef, cfrLutLen);

	for(coefLoop = 0;coefLoop < cfrLutLen;coefLoop ++)
	{
		pCpgReal[coefLoop] = (INT16)((pCoef[coefLoop]>>16) &0x1FFF);
		pCpgImag[coefLoop] = (INT16)(pCoef[coefLoop] &0x1FFF);
	}

	return retVal;
}



UINT32 BspHalAdaptGetDifCfrParaVal(UINT32 difChn,UINT32 *ulDelayMode,UINT32 *ulCpgLen)
{
    T_BspHalAdaptDifCommCfrPara *difPara = NULL;

    INPUT_POINTER_CHECK(ulDelayMode);
    INPUT_POINTER_CHECK(ulCpgLen);

    difPara = BspHalAdaptGetDifCfrPara();
    if(NULL != difPara)
    {
        *ulDelayMode = difPara->uiDelayEqualFlag[difChn];
        *ulCpgLen = difPara->uiCpgCoefLenHalfMax[difChn];
        dbgInfoEx("[%s] DlyMode is %d,CPG Len is %d\n ",__FUNCTION__,ulDelayMode,ulCpgLen);
    }

	return BSP_OK;
}

UINT32 BspCfrDataSave_CpuCalVal(UINT32 difChn, UINT32 band, FLOAT *pCpgReal, FLOAT *pCpgImag , UINT32 dataNum, FLOAT sumBandGK,UINT32 vaildMaxLen)
{
	UINT32 ret           = BSP_OK;

    INPUT_DIFCHAN_CHECK(difChn);
    INPUT_POINTER_CHECK(pCpgReal);
    INPUT_POINTER_CHECK(pCpgImag);

    if ((sumBandGK >= (-(FLOAT)EPSINON)) && (sumBandGK <= (FLOAT)EPSINON))
    {
        ret = BSP_ERROR;
    }
    else
    {
        ret = BspCfrDataSave_CpuCal(difChn, band, pCpgReal, pCpgImag, dataNum, sumBandGK,vaildMaxLen);
    }
    return ret;
}

UINT32 BspGetCalcPci(UINT32 originCoefLen,const INT32 *pCoefPara,FLOAT *pci)
{
    FLOAT ciSq           = 0.0;
    UINT32 cnt           = 0;

    INPUT_POINTER_CHECK(pCoefPara);
    INPUT_POINTER_CHECK(pci);

	for (cnt = 0; cnt < (originCoefLen - 1); cnt++)
	{
		if ((pCoefPara != NULL) && (pCoefPara[cnt] != NULL))
		{
			ciSq += pow(pCoefPara[cnt], 2);
		}
	}

	if ((pCoefPara != NULL) && (pCoefPara[originCoefLen - 1] != NULL))
	{
		*pci = (FLOAT)(2 * ciSq + pow(pCoefPara[originCoefLen - 1], 2));
	}

	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrSetCpgParaCpuCalByRadio
*  功能描述   : 设置单边滤波后软计算的CPG系数
*  输入参数   : difChn - 中频通道, umtsBw - 单边滤波后UMTS带宽
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 与非单边滤波的削峰相比,单边滤波波及以下三点:
               (1)需用高层传递的单边滤波后的带宽匹配原型系数;
               (2)U功率计算:原带宽D1,功率P1,单边滤波后带宽D2,滤波后功率P2=(D2/D1)*P1;
               (3)载波NCO计算:fi=原链路载波NCO-NCO1。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-12-13 21:54:23
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgParaCpuCalByRadio(UINT32 difChn, UINT32 ulCarrId, UINT32 radio, UINT32 bw)
{
    UINT32 ret           = BSP_OK;
    UINT32 bandLoop      = 0;
    UINT32 carrLoop      = 0;
    UINT32 carrBw        = 0;
    UINT32 cfrBw         = 0;
    UINT32 carrPowMw     = 0;
    UINT32 appPowMw      = 0;
    UINT32 realPowMw     = 0;
    INT32 tssiPowDbm     = 0;
    INT32 tssiPowDbfs    = 0;
    DOUBLE powMw         = 0.0;
    UINT32 carrRadio     = 0;
    UINT32 carrNo        = 0;
    UINT32 cnt           = 0;
    FLOAT Ki             = 0;
    FLOAT wei            = 0.0;
    FLOAT giTemp         = 0.0;
    FLOAT giTempMax      = 1.0;
    FLOAT gi             = 0.0;
    FLOAT sumBandGK      = 0.0;
    FLOAT ciSq           = 0.0;
    FLOAT pci            = 0.0;
    FLOAT *pCpgReal      = NULL;
    FLOAT *pCpgImag      = NULL;
    INT32 fi             = 0;
    DOUBLE tempData      = 0.0;
    FLOAT dQn            = 0.0;
    UINT32 ulDelayMode   = 0;
    UINT32 cfrFs         = 0;
    UINT32 bandNum       = 0;
    UINT32 cpgVaildLen   = 0;
    UINT32 originCoefLen = 0;
    UINT32 nbCarrMode    = 0;
    UINT32 uCarrBw[BSP_MAX_CARR_NUM] = {0};
    UINT32 ulCpgLen      = CFR_CPG_RAM_768;
    UINT32 cpgCalcFlag   = 0;
    UINT32 powShareFlag  = 1;
    FUN_GET_POWCTRL_TSSI_INFO pGetTssiPowInfo = NULL;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};
    T_BspHalAdaptDifCommCfrPara *difPara = NULL;
    T_CfrLteUmtsFreqFiOffsetInfo pUmtsInfo[MAX_TX_CHANNEL] = {0};

    INPUT_DIFCHAN_CHECK(difChn);

    BspHalAdaptGetDifCfrParaVal(difChn,&ulDelayMode,&ulCpgLen);

    RETURN_VAL_DO_IF_EXP(s_cfrCpgCpuCalData == NULL, BSP_ERROR, dbgInfoEx("[%s]: s_cfrCpgCpuCalData not malloc ",__FUNCTION__));

    ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
    ret |= BspCfrCpgGetGiTempMax(difChn, &giTempMax);
    ret |= BspGetRefreshCfrCpgFlag(difChn, &cpgCalcFlag);

    /* kw告警修改,考虑32/64位系统, 所以用ULONG */
    pCpgReal = (FLOAT *)malloc(sizeof(FLOAT) * CFR_CPG_RAM_768);
    RETURN_VAL_DO_IF_EXP(pCpgReal == NULL, BSP_ERROR, dbgInfoEx("[%s]cpg space malloc error \n", __FUNCTION__));

    pCpgImag = (FLOAT *)malloc((sizeof(FLOAT) * CFR_CPG_RAM_768));
    if (pCpgImag == NULL)
    {
        free(pCpgReal);
        pCpgReal = NULL;
        dbgInfoEx("[%s]cpg space malloc error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset(pCpgReal, 0, (sizeof(FLOAT) * CFR_CPG_RAM_768));
    memset(pCpgImag, 0, (sizeof(FLOAT) * CFR_CPG_RAM_768));

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfoEx("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        BspLog(LOG_LEVEL_0,"[%s] Get Cfr Chn[%d] Rf Para Error! \n", __FUNCTION__,difChn);
        free(pCpgImag);
        free(pCpgReal);
        return BSP_ERROR;
    }

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        CONTINUE_IF_EXP(pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED);

        bandNum ++;
        cpgVaildLen = 0;
        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            CONTINUE_IF_EXP(pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID);

            carrNo      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrNo;
            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            appPowMw    = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].powerMw;

            pGetTssiPowInfo = BspGetTssiPowInfoCallBackInit();
            INPUT_POINTER_CHECK(pGetTssiPowInfo);
            pGetTssiPowInfo(difChn, carrRadio, carrNo, &tssiPowDbm, &tssiPowDbfs);
            powMw = pow(10, (tssiPowDbm * 1.0 / 100 / 10));
            realPowMw = (UINT32)powMw;
            ret |= BspJudgeCfrCpgRefreshCarrPow(cpgCalcFlag, powShareFlag, appPowMw, realPowMw, &carrPowMw);
            ret = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
            fi = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFi;
            /*UMTS目前没有入参载波号，后期解决*/
            if(BSP_RADIO_STANDARD_UMTS == radio)
            {
            	ulCarrId = carrNo;
            }

            if ((0 != carrBw) && (carrRadio == radio) && (carrNo == ulCarrId))
            {
                ret |= BspGetCfrFreqFiOffset(difChn,pUmtsInfo);
                ret |= BspGetCfrRadioBwFromBspBw(carrRadio, bw, &cfrBw);

                uCarrBw[carrNo] = carrBw;
                fi = pUmtsInfo[difChn].offset;
                carrPowMw = (UINT32)((carrPowMw * bw) / carrBw);
            }

            dbgInfoEx("[%s] chn'%d, carrNo'%d, carrRadio'%d, carrPowMw'%d, appPowMw'%u, realPowMw'%u, cpgFlag'%u, carrBw'%d, cfrBw'%d, cfrFs'%d. \n",
                    __FUNCTION__, difChn, carrNo, carrRadio, carrPowMw, appPowMw, realPowMw, cpgCalcFlag, carrBw, cfrBw, cfrFs);

            dQn = 2.0 * CFR_PI * fi / cfrFs;/*KHZ*/
            Ki = (FLOAT)sqrt(carrPowMw);

            ret |= BspCfrCpgGetWei(cfrFs, carrRadio, &wei);
            ret |= BspGetCfrCpgCoefCommon(difChn,cfrBw,cfrFs, &cfrCpgPara);
            CONTINUE_IF_EXP(ret != BSP_OK);

            if(1 == ulDelayMode)//如果是等时延，cfr的CPG长度固定
            {
                cpgVaildLen = ulCpgLen;
            }
            else
            {
                cpgVaildLen = (cpgVaildLen>cfrCpgPara.vaildLen)?cpgVaildLen:cfrCpgPara.vaildLen;
            }

            originCoefLen = cfrCpgPara.coefLen;

            BspGetCalcPci(originCoefLen,cfrCpgPara.pCoefPara,&pci);

            giTemp = (FLOAT)(wei / sqrt(pci));

            gi = BspGetgi(difChn,carrRadio,carrNo,giTemp,giTempMax);

            sumBandGK += gi * Ki;

            /*要求cpg系数跟lutlen 保持一致,这里做判断以防万一出现不一致情况*/
            for (cnt = 0; cnt < originCoefLen; cnt++)
            {
                tempData = ((originCoefLen - 1 - cnt) * (-1.0) * dQn);
                if ((cfrCpgPara.pCoefPara != NULL) && (cfrCpgPara.pCoefPara[cnt] != NULL))
                {
                    pCpgReal[cnt] += ((FLOAT)(Ki * gi * cos(tempData))) * (FLOAT)cfrCpgPara.pCoefPara[cnt];
                    pCpgImag[cnt] += ((FLOAT)(Ki * gi * sin(tempData))) * (FLOAT)cfrCpgPara.pCoefPara[cnt];
                    dbgInfoEx("%s>>Cnt'%d Nco'%d dQn'%f  Coef'%f: cos(%f)= %f, sin(%f)= %f\n",
                            __FUNCTION__, cnt, fi, dQn, (FLOAT)cfrCpgPara.pCoefPara[cnt],
                            tempData, cos(tempData), tempData, sin(tempData));
                }
            }
        }

        ret = BspCfrDataSave_CpuCalVal(difChn, bandLoop, pCpgReal, pCpgImag, originCoefLen, sumBandGK,cpgVaildLen);


        dbgInfoEx("%s>>DifChnl'%d BandIdx'%d sumBandGK'%f CpgInitCpuCal OK! DataSave %s!\n",
                __FUNCTION__, difChn, bandLoop, sumBandGK, (BSP_OK == ret) ? "Succ" : "Fail");

        memset(pCpgReal, 0, sizeof(FLOAT)*originCoefLen);
        memset(pCpgImag, 0, sizeof(FLOAT)*originCoefLen);
        sumBandGK = 0.0;
    }
    ret |= BspCfrSetBandNum(difChn,bandNum);

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
    {
        ret |= BspSetUmtsDlFilterCpgBwByCarrBw(difChn, carrLoop, uCarrBw[carrLoop]);
    }

    BspLog(LOG_LEVEL_0,"[%s] chn'%d, cfrFs'%d, giTempMax'%f, bw'%d, ret'%s.\n", __FUNCTION__,difChn,cfrFs,giTempMax,bw,(ret==BSP_OK)?"OK":"Error");

    free(pCpgReal);
    free(pCpgImag);
    pCpgReal = NULL;
    pCpgImag = NULL;

    return ret;
}

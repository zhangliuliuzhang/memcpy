/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_dpdic_cfgpara.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供CFR模块配置功能
* 注意事项 : 无
* 作    者 : 喻波10220056
* 创建日期 : 2023-07-01
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 喻波10220056
* 修改日戳: 2023-07-01
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "bsppub.h"
#include "freqcfgcommon.h"
#include "ichaladaptcfrapi.h"
#include "math.h"
#include "freqcfg_ic4_2.h"
#include "funccommonapi.h"
#include "cfr_cfgpara.h"
#include "cfr_cpgcal.h"
#include "cfr_cpu.h"
#include "cfr_hard.h"
#include "cfr_dpdic.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
UINT32 g_CfrGateInitFlag = 0;
UINT32 g_pCfrDymParaTblLen = 0;
UINT32    g_aulNBCarrMode[MAX_TX_CHANNEL][BSP_MAX_CARR_NUM]={0};
T_CfrGateCfgGroup *s_pCfrGateCfgGroup = NULL;
/**************************************************************************
 *                         函数实现
 **************************************************************************/

/*****************************************************************************
*  函数名称   : BspSetCfrGateInitFlag
*  功能描述   : 配置初始化门限的时刻，配置CFR是门限初始化用CFR中的载波信息，配频传
               时延参数的时候用的载波信息为通道预存的信息，此接口只用于算法新提供
               的门限表中，自动匹配门限的方法中
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : gateFlag     - 0是配置CFR时的门限初始化，1是配频时的门限初始化
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2017-05-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrGateInitFlag(UINT32 gateFlag)
{
    g_CfrGateInitFlag = gateFlag;
    return BSP_OK;
}

UINT32 BspGetCfrGateInitFlag(UINT32 *gateFlag)
{
    INPUT_POINTER_CHECK(gateFlag);

    *gateFlag = g_CfrGateInitFlag;
    dbgInfo("[%s] g_CfrGateInitFlag:%d\n",__FUNCTION__, g_CfrGateInitFlag);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCpgMaxLen_IC4_2
*  功能描述   : 获取当前配置中最大的CPG长度
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : rfchan： 射频通道号
               difChan：中频通道号
*  输出参数   : cpgLen：最大cpg长度
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2021-05-29 14:55:24
*----------------------------------------------------------------------------/
*/
UINT32 BspGetCpgMaxLenCommon(UINT32 rfchan, UINT32 difChan, UINT32 *cpgLen)
{
    UINT32 ret = BSP_OK;
    UINT32 cpgmaxlen = 0;
    UINT32 carrLoop = 0;
    UINT32 cfrFs = 0;
    UINT32 cfrBw = 0;
    UINT32 carrBw = 0;
    UINT32 carrRadio = 0;
    UINT32 bandLoop = 0;
    T_CfrCpgPara cfrCpgPara = {0};
    T_RruBandCfgInfo *pRruRfCfgInfo = NULL;

    INPUT_POINTER_CHECK(cpgLen);

    ret = BspGetCfrFsByDifChn(difChan,&cfrFs);
    if (ret == BSP_ERROR)
    {
        dbgErr("[%s]difchan %d get fs error!\n", __FUNCTION__, difChan);
        return BSP_ERROR;
    }

    pRruRfCfgInfo = malloc(sizeof(T_RruBandCfgInfo));
    if (NULL == pRruRfCfgInfo)
    {
        dbgErr("[%s]RfChn %d RfCfgInfoMalloc Error!\n", __FUNCTION__, rfchan);
        return BSP_ERROR;
    }
    memset(pRruRfCfgInfo, 0, sizeof(T_RruBandCfgInfo));

    ret = BspGetRruTxDifCfgPara(rfchan, pRruRfCfgInfo);
    if(ret != BSP_OK)
    {
        free(pRruRfCfgInfo);
        dbgErr("[%s]RfChn %d Cfr Chn Info Update Error!\n",__FUNCTION__,rfchan);
        return BSP_ERROR;
    }

    for(bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if(pRruRfCfgInfo->info[bandLoop].bandfreq == 0)
        {
            continue;
        }
        for(carrLoop = 0 ; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
        {
            if(pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrFreq == 0)
            {
                continue;
            }
            carrBw = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrBw;
            carrRadio = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrRadio;
            ret = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
            ret |= BspGetCfrCpgCoefCommon(difChan,cfrBw,cfrFs, &cfrCpgPara);
            if(ret == BSP_OK)
            {
                cpgmaxlen = (cpgmaxlen>cfrCpgPara.vaildLen)?cpgmaxlen:cfrCpgPara.vaildLen;
            }
        }
    }
    *cpgLen = cpgmaxlen;
    free(pRruRfCfgInfo);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetDlyPara
*  功能描述   : 根据CGP长度设置中频时延
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn:中频通道号
             pRfCfgPara：载波配置
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetDlyPara(UINT32 chan, UINT32 *pReservePara)
{
    UINT32 ret         = BSP_OK;
    UINT32 cpgmaxlen   = 0;
    UINT32 bspChan     = 0;
    UINT32 difChan     = 0;
    UINT32 loop        = 0;
    UINT32 ulDelayMode = 0;
    UINT32 chipId      = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM]    = {0};
    T_BspHalAdaptDlyCfgCfrPara pDlyPara  = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    if (NULL == pReservePara)
    {
        dbgInfoEx("%s:Input Pointer is NULL,but it is ok! \n",__FUNCTION__);
    }

    if(BSP_OK != BspGetCfrCommPara(&cfrCommPara))
    {
        dbgErr("%s Get CFR Commom Para Error!",__FUNCTION__);
        return BSP_ERROR;
    }

    ret = BspGetBspChnByRfChn(chan, TX, &bspChan);
    if (BSP_OK != ret)
    {
        dbgErr("%s>>TxChnl'%d BspGetBspChnByRfChn Get Error!\n",
               __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ret = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != ret)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
               __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    BspSetCfrGateInitFlag(CFR_GATE_INIT_CFG_FREQ);

    ulDelayMode = cfrCommPara.uiDelayEqualFlag[difChan];
    if(ulDelayMode == CFR_EQ_DLY)
    {
        cpgmaxlen = cfrCommPara.uiCpgCoefLenHalfMax[difChan];
    }
    else
    {
        ret = BspGetCpgMaxLenCommon(chan,difChan, &cpgmaxlen);
        if(BSP_OK != ret)
        {
            cpgmaxlen = CFR_CPG_RAM_768;
            dbgErr("%s get cpg error!\n",__FUNCTION__);
        }
    }

    pDlyPara.uiCpgLen = cpgmaxlen;
    pDlyPara.uiCfrGrade = cfrCommPara.uiCfrGrade[difChan];
    pDlyPara.uiCpgPhase = cfrCommPara.uiCpgPhase[difChan];
    pDlyPara.uiCfrBypassMode = cfrCommPara.uiCfrBypassMode[difChan];

    ret = BspCfrGateInit(difChan);
    if (ret != BSP_OK)
    {
        dbgInfo("[%s]Cfr Gate NULL \n",__FUNCTION__);
        BspSetCfrGateInitFlag(CFR_GATE_INIT_CFG_CFR);
        return BSP_ERROR;
    }

    ret |= BspGetCfrWinLevelPara(difChan,cfrWinLevel);
    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        pDlyPara.uiCfrWinLevel[loop] = cfrWinLevel[loop];
    }
    dbgInfo("%s gradeNum:%d phaseNum:%d cpgLen:%d bypassmode:%d winlevel:%d %d %d\n",__FUNCTION__,\
            pDlyPara.uiCfrGrade,pDlyPara.uiCpgPhase,pDlyPara.uiCpgLen,pDlyPara.uiCfrBypassMode,\
            pDlyPara.uiCfrWinLevel[0],pDlyPara.uiCfrWinLevel[1],pDlyPara.uiCfrWinLevel[2]);

    ret |= BspHalAdaptSetDlyPara(difChan, &pDlyPara);
    BspSetCfrGateInitFlag(CFR_GATE_INIT_CFG_CFR);

    return ret;
}
/*****************************************************************************
*  函数名称   : BspCfrCfg
*  功能描述   : CFR削峰门限配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn     - cfr中频通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-05-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCfg(UINT32 difChan)
{
    UINT32 ret = BSP_OK;
    UINT32 freqBand = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 cfrWin[E_CFR_THR_NUM]  = {0};
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};
    INPUT_DIFCHAN_CHECK(difChan);
    ret |= BspGetCfrGatePara(difChan, cfrGate);
    ret |= BspGetCfrWinPara(difChan, cfrWin);
    ret |= BspGetCfrDeltPara(difChan, cfrDelt);
    ret |= BspGetCfrWinLevelPara(difChan,cfrWinLevel);
    ret |= BspHalAdaptSetCfrGate(difChan, freqBand, cfrGate, E_CFR_THR_NUM);
    ret |= BspHalAdaptSetCfrWin(difChan, freqBand, cfrWin, E_CFR_THR_NUM);
    ret |= BspHalAdaptSetCfrDelt(difChan, freqBand, cfrDelt, E_CFR_THR_NUM);
    ret |= BspHalAdaptSetCfrWinlevel(difChan, freqBand, cfrWinLevel, E_CFR_THR_NUM);
    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrSetSwitch
*  功能描述   : CFR 开关
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetSwitch(UINT32 difChan,UINT32 cfrOnOff)
{
    UINT32 cfrOutMode = 0;
    UINT32 freqBand = 0;
    cfrOutMode = (cfrOnOff == CFR_FUNC_ON)?IC_CFR_ON:IC_CFR_OFF;
    return BspHalAdaptSetCfrSwitch(difChan, freqBand, cfrOutMode);
}

/*****************************************************************************
*  函数名称   : BspCfrSetEnable
*  功能描述   : CFR Enable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetEnable(UINT32 difChan)
{
    return BspCfrSetSwitch(difChan, CFR_FUNC_ON);
}

/*****************************************************************************
*  函数名称   : BspCfrSetDisable
*  功能描述   : CFR Disable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetDisable(UINT32 difChan)
{
    return BspCfrSetSwitch(difChan, CFR_FUNC_OFF);
}

/*****************************************************************************
*  函数名称   : BspCfrJudgeCpgMode
*  功能描述   : 判断当前通道使用软计算或硬件计算
*  输入参数   : difChn   - 中频通道号
*  输出参数   : cpgMode  - 该通道最终使用的CP计算方式
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 公共参数表中原为软计算则保持不变；若为硬件计算，基于等时延方案考虑，
               通道载波数大于等于8且无gsm制式时，改为软件计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-12-22 09:28:57
*----------------------------------------------------------------------------
*/
UINT32 BspCfrJudgeCpgMode(UINT32 difChn, UINT32 *cpgMode)
{
    UINT32 retVal   = BSP_OK;
    UINT32 modeFlag = 0;
    UINT32 index    = 0;
    UINT32 gsmFlag  = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    if(BSP_OK != BspGetCfrCommPara(&cfrCommPara))
    {
       dbgErr("%s Get CFR Commom Para Error!",__FUNCTION__);
       return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(difChn, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("[%s] line %d: get pRfCfg Err!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    if(difChn < CFR_CHAN_MAX_NUM)
    {
        modeFlag = cfrCommPara.uiCpgMode[difChn];
    }
    else
    {
        dbgErr("[%s] difChn out of range!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if (CFR_CPG_CPU_CAL == modeFlag)
    {
        dbgInfo("[%s] difChn'%d uses the original CPU Calculation! \n",__FUNCTION__,difChn);
        *cpgMode = modeFlag;
        return retVal;
    }

    for (index = 0; index < pRfCfg->para.carrNum; index++)
    {
        if (RADIO_STANDARD_GSM == pRfCfg->para.carrInfo[index].radioMode)
        {
            gsmFlag = 1;
            break;
        }
    }

    if ((pRfCfg->para.carrNum >= 8) && (0 == gsmFlag))
    {
        dbgInfo("[%s] difChn'%d carrNum'%d changes from hardware to CPU Calculation! \n",__FUNCTION__,difChn,pRfCfg->para.carrNum);

        retVal = BspHalAdaptSetDlpreKiIndexType(difChn);
        *cpgMode = CFR_CPG_CPU_CAL;

        return retVal;
    }

    dbgInfo("[%s] difChn'%d uses the original Hardware Calculation! \n",__FUNCTION__,difChn);
    *cpgMode = CFR_CPG_HW_CAL;

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrSetCpgPara
*  功能描述   : 配置削峰 CPG 系数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn   - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 配置CFR模块接口，封装后用于给高层调用。
               通过挂接后APP调用接口名为：UINT32 BspSetCfrCpgPara(UINT32 bspChn)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetCpgPara(UINT32 bspChn)
{
    UINT32 retVal          = BSP_OK;
    UINT32 difChn          = 0;
    UINT32 chipidx         = 0;
    UINT32 mode            = 0;
    UINT32 ulCfrByPassMode = 0;
    UINT32 cpgMode         = 0;
    UINT32 freqBand        = 0;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    dbgInfo(" ======= CFR CFG START ======= \n");

    retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);

    if(BSP_OK != BspGetCfrCommPara(&cfrCommPara))
    {
       dbgErr("%s Get CFR Commom Para Error!",__FUNCTION__);
       return BSP_ERROR;
    }

    ulCfrByPassMode = cfrCommPara.uiCfrBypassMode[difChn];
    if (CFR_ZERODLY_BYPASS == ulCfrByPassMode)
    {
        retVal |= BspCfrDisable(difChn);
        dbgInfo("[%s] Chn %d Cfr Bypass Mode(%d) is Zero Dly ByPass\n",__FUNCTION__,difChn,ulCfrByPassMode);
        return retVal;
    }

    if (BspGetCfrFuncFlag() == CFR_FUNC_NOT_INIT)
    {
        dbgInfo("[%s]FUNC CFR NOT INIT \n", __FUNCTION__);
        return BSP_ERROR;
    }

    mode = BspGetCfrWorkMode();
    if (mode == CFR_NORMAL_MODE)
    {
        retVal = BspCfrChnInfoUpdateByBspChn(bspChn);
        if (retVal != BSP_OK)
        {
            dbgInfo("[%s]Cfr Get Chn Info Error \n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    retVal |= BspCfrDisable(difChn);
    retVal |= BspCfrGateInit(difChn);
    if (retVal != BSP_OK)
    {
        dbgInfo("[%s]Cfr Gate NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspSetCfrCfg(difChn);
    retVal |= BspHalAdaptSetBbTssiCfg(difChn);
    retVal |= BspHalAdaptCfrSetSymstrGsmSel(difChn, freqBand);
    retVal |= BspCfrJudgeCpgMode(difChn, &cpgMode);
    retVal |= BspHalAdaptCfrSetCpgMode(difChn, freqBand, cpgMode);

    if(cpgMode == CFR_CPG_CPU_CAL)
    {
        dbgInfoEx("[%s]: difChn'%d  Cfr Cpg Use CPU Calculation! \n", __FUNCTION__,difChn);
        retVal |= BspCfrSetCpgPara_CpuCal(bspChn);
    }
    else
    {
        dbgInfoEx("[%s]: difChn'%d  Cfr Cpg Use Hardware Calculation! \n", __FUNCTION__,difChn);
        retVal |= BspCfrSetCpgPara_HwCal(bspChn);
    }

    retVal |= BspSetCfrDelay(difChn);
    retVal |= BspCfrSetTddSwPara(difChn);
    retVal |= BspCfrSetCpgLen(difChn);
    retVal |= BspCfrEnable(difChn);

    dbgInfoEx("%s>>RfCh'%d SetCpgPara OK! CfrWorkMode(%d:NORMAL)= %d\n",
              __FUNCTION__, bspChn, CFR_NORMAL_MODE, mode);
    BspLog(LOG_LEVEL_0,"[%s] chn'%d, cpgMode'%d, ret:'%s.\n", __FUNCTION__,difChn,cpgMode,(retVal==BSP_OK)?"OK":"Error");

    dbgInfo(" ======= CFR CFG END ======= \n");

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrGetVerInfo
*  功能描述   : 获取 FPGA CFR 版本号
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip   - fpga 芯片号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGetVerInfo(UINT32 chip)
{
    UINT32 cfrVerYear = 0;
    UINT32 cfrVerData = 0;
    UINT32 cfrVerTime = 0;

    /*IcHalApiGetCfrVer(chip,&cfrVerYear,&cfrVerData,&cfrVerTime);*/
    dbgInfo("%-20s %2x-%x-%2x %2x:00 \n", "FPGA_CFR_VER:",cfrVerYear,(cfrVerData>>0x8)&0xF,cfrVerData&0xFF,cfrVerTime );
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrParaMemInfoInit_IC4_2
*  功能描述   : Dpdic4.2 CFR 所需要空间初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrParaMemInfoInitCommon(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 difChnNum = 0;
    T_CfrModule *pCfrModule = NULL;
    pCfrModule = (T_CfrModule *)BspGetCfrModuleInfo();

    INPUT_POINTER_CHECK(pCfrModule);

    difChnNum   = BspGetCfrDifChnNum();

    if(pCfrModule->cfrPara.pWinLevel != NULL)
    {
        return BSP_OK;
    }

    pCfrModule->cfrPara.pWinLevel = (T_CfrThrInfo *)malloc(sizeof(T_CfrThrInfo) * difChnNum);

    if (pCfrModule->cfrPara.pWinLevel == NULL)
    {
        free(pCfrModule->cfrPara.pWin);
        free(pCfrModule->cfrPara.pDelt);
        free(pCfrModule->cfrPara.pGate);
        pCfrModule->cfrPara.pWin    = NULL;
        pCfrModule->cfrPara.pDelt   = NULL;
        pCfrModule->cfrPara.pGate   = NULL;
        pCfrModule->initFlag = CFR_FUNC_NOT_INIT;
        dbgInfo("[%s]Cfr pWinLevel malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }
    pCfrModule->initFlag = CFR_FUNC_INIT;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrParaMemInfoInit
*  功能描述   : Dpdic4.2 CFR 所需要空间初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrParaMemInfoInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal |= BspCfrParaMemInfoInitCommon();

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetCpgFsByDifChn_IC4_2
*  功能描述   : CPG速率获取（CPG速率 = 削峰采样率 * CPG相数）
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn：中频通道号
*  输出参数   : *pCpgFs：Cpg速率
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCpgFsByDifChnCommon(UINT32 difChn,UINT32 *pCpgFs)
{
    UINT32 sampleRate = 0;
    UINT32 phaseFlag  = 0;
    UINT32 phaseNum   = 0;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    INPUT_POINTER_CHECK(pCpgFs);

    if(BSP_OK != BspGetCfrCommPara(&cfrCommPara))
    {
        dbgErr("%s Get CFR Commom Para Error!",__FUNCTION__);
        return BSP_ERROR;
    }

    sampleRate = cfrCommPara.uiCfrSample[difChn];
    phaseFlag = cfrCommPara.uiCpgPhase[difChn];

    switch (phaseFlag)
    {
        case 1:
        {
            phaseNum = CFR_CPG_PHASE_1;
            break;
        }
        case 2:
        {
            phaseNum = CFR_CPG_PHASE_2;
            break;
        }
        case 4:
        {
            phaseNum = CFR_CPG_PHASE_4;
            break;
        }
        default:
        {
            dbgErr("%s Get CFR phaseNum is invalid!\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }

    *pCpgFs = phaseNum*sampleRate;

    return BSP_OK;
}

UINT32 BspGetCfrCommPara(VOID *pCfrCommPara)
{
    UINT32 ret            = BSP_OK;

    INPUT_POINTER_CHECK(pCfrCommPara);

    ret = BspHalAdaptGetCfrCommPara(pCfrCommPara);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspInitCfrCommPara
*  功能描述   : 削峰静态参数（主体）初始化
*  读全局变量 : 无
*  写全局变量 : 将处理后的静态参数保存于全局变量 s_pCfrCommPara
*  输入参数   : pCfrCommPara - 静态参数结构体
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 根据40KM拉远能力方案，无线制式不含GSM和NB时，FDD通道CPG最大半长初始化为509。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2023-03-29 08:48:37
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrCommPara(T_BspHalAdaptDifCommCfrPara *pCfrCommPara)
{
    UINT32 stdRadio = 0;
    UINT32 chnLoop = 0;
    UINT32 gnbFlag = 0;
    INPUT_POINTER_CHECK(pCfrCommPara);

    stdRadio = BspGetRadioStandard();

    if ((BSP_RADIO_STANDARD_GSM == (stdRadio & BSP_RADIO_STANDARD_GSM)) || (BSP_RADIO_STANDARD_NB_IOT == (stdRadio & BSP_RADIO_STANDARD_NB_IOT)))
    {
        gnbFlag = RADIO_SUPPORT_GSM_OR_NB;
    }

    if (gnbFlag != RADIO_SUPPORT_GSM_OR_NB)
    {
        BspLog(LOG_LEVEL_0,"[%s] stdRadio'0x%x, newHalMaxCpgLen'%u \n", __FUNCTION__, stdRadio, CFR_CPG_LEN_HAL_MAX_ULV);

        for(chnLoop = 0; chnLoop < CFR_CHAN_MAX_NUM; chnLoop ++)
        {
            pCfrCommPara->uiCpgCoefLenHalfMax[chnLoop] = CFR_CPG_LEN_HAL_MAX_ULV;
        }
    }

    return BspHalAdaptDifCfrParaInit(pCfrCommPara);
}

UINT32 BspGetCfrKiCommPara(VOID *pCfrHWCpgPara)
{
    INPUT_POINTER_CHECK(pCfrHWCpgPara);

    BspHalAdaptGetCfrKiCommPara(pCfrHWCpgPara);

    return BSP_OK;
}

/**  削峰硬件计算Ki表等参数初始化  **/
UINT32 BspInitKiCommPara(VOID *pCfrHWCpgPara)
{
    INPUT_POINTER_CHECK(pCfrHWCpgPara);

    return BspHalAdaptCfrCommParaCpgInit(pCfrHWCpgPara);
}

/**  削峰硬件计算Kn表等参数初始化  **/
UINT32 BspInitKnCommPara(VOID *pCfrKnWordPara)
{
    INPUT_POINTER_CHECK(pCfrKnWordPara);
    return BspHalAdaptKnWordLutParaInit(pCfrKnWordPara);
}

/**  获取削峰峰均比参数  **/
UINT32 BspGetCfrParPara(VOID *pCfrParPara)
{
    INPUT_POINTER_CHECK(pCfrParPara);

    BspHalAdaptGetCfrParPara(pCfrParPara);

    return BSP_OK;
}

/**  削峰峰均比参数初始化  **/
UINT32 BspInitCfrParPara(VOID *pCfrParPara)
{
    INPUT_POINTER_CHECK(pCfrParPara);

    return BspHalAdaptCfrParCfgCommParaInit(pCfrParPara);
}

/**  获取DPD峰均比参数  **/
UINT32 BspGetDpdParPara(VOID *pDpdParPara)
{
    INPUT_POINTER_CHECK(pDpdParPara);

    BspHalAdaptGetDpdParPara(pDpdParPara);

    return BSP_OK;
}

/**  DPD峰均比参数初始化  **/
UINT32 BspInitDpdParPara(VOID *pDpdParPara)
{
    INPUT_POINTER_CHECK(pDpdParPara);

    return BspHalAdaptDpdParCfgCommParaInit(pDpdParPara);
}

/** 削峰动态参数获取 **/
UINT32 BspCfrDymParaInit(UINT32 dymTblLen, VOID *pCfrGateCfgGroup)
{
    INPUT_POINTER_CHECK(pCfrGateCfgGroup);

    BspHalAdaptCfrDymParaInit(dymTblLen,pCfrGateCfgGroup);

    return BSP_OK;
}

/** 设置在线计算BBTSSI相关配置 */
UINT32 BspCfrSetBbTssiCfg(UINT32 difchn)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSetBbTssiCfg(difchn);

    return retVal;
}

UINT32 BspHalAdaptCfrDymParaInit(UINT32 dymTblLen, T_CfrGateCfgGroup *pCfrGateCfgGroup)
{
    g_pCfrDymParaTblLen = dymTblLen;
    INPUT_POINTER_CHECK(pCfrGateCfgGroup);
    s_pCfrGateCfgGroup = pCfrGateCfgGroup;

    return BSP_OK;
}


/* 削峰门限窗长等参数初始化 */
UINT32 BspInitCfrGatePara(UINT32 difchn)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 tddFddMode = 0;
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    if(BSP_OK != BspGetCfrCommPara(&cfrCommPara))
    {
        dbgErr("%s Get CFR Commom Para Error!",__FUNCTION__);
        return BSP_ERROR;
    }

    tddFddMode = cfrCommPara.uiCfrPeakMode[difchn];

    dbgInfo("[%s] The duplex mode of difchn %d is %s. \n", __FUNCTION__, difchn, ((tddFddMode == CFR_CHAN_TDD_DX)?("TDD"):("FDD")));

    for(loop = 0; loop < g_pCfrDymParaTblLen; loop++)
    {
        if((tddFddMode == CFR_CHAN_TDD_DX) && (tddFddMode == s_pCfrGateCfgGroup[loop].tddFddFlag))
        {
            retVal = BspCfrGateInitCommon(difchn, tddFddMode, s_pCfrGateCfgGroup[loop].dynPara, NULL, s_pCfrGateCfgGroup[loop].tblLen);
            if(retVal != BSP_OK)
            {
                dbgErr("%s get cfr Dym Para Err! retVal'%d\n",__FUNCTION__,retVal);
                return BSP_ERROR;
            }
            break;
        }

        if((tddFddMode == CFR_CHAN_FDD_DX) && (tddFddMode == s_pCfrGateCfgGroup[loop].tddFddFlag))
        {
            retVal = BspCfrGateInitCommon(difchn, tddFddMode, NULL, s_pCfrGateCfgGroup[loop].dynPara, s_pCfrGateCfgGroup[loop].tblLen);
            if(retVal != BSP_OK)
            {
                dbgErr("%s get cfr Dym Para Err! retVal'%d\n",__FUNCTION__,retVal);
                return BSP_ERROR;
            }
            break;
        }
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrSetDelay
*  功能描述   : CFR时延配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn：中频通道号
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetDelay(UINT32 difChn)
{
    UINT32 ret       = BSP_OK;
    UINT32 cpgMaxlen = 0;
    UINT32 loop      = 0;
    UINT32 freqBand  = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    T_BspHalAdaptCfrDlyCalcPara pDlyPara = {0};

    ret = BspGetCfrWinLevelPara(difChn,cfrWinLevel);
    ret |= BspCfrGetCpgVaildLen(difChn, &cpgMaxlen);
    if(ret != BSP_OK)
    {
        dbgInfo("[%s]Cfr Get Cpg Len Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    pDlyPara.uiCpgLen = cpgMaxlen;

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        pDlyPara.uiCfrWinLevel[loop] = cfrWinLevel[loop];
    }

    dbgInfo("%s difChn:%d cpglen:%d winlevel:%d %d %d\n ",__FUNCTION__,difChn,pDlyPara.uiCpgLen,pDlyPara.uiCfrWinLevel[0],pDlyPara.uiCfrWinLevel[1],pDlyPara.uiCfrWinLevel[2]);
    BspLog(LOG_LEVEL_0,"[%s] difChn'%d, cpglen'%d, winlevel:%d %d %d\n",
                __FUNCTION__,difChn,cpgMaxlen,pDlyPara.uiCfrWinLevel[0],pDlyPara.uiCfrWinLevel[1],pDlyPara.uiCfrWinLevel[2]);

    ret |= BspHalAdaptCfrSetDelay(difChn, freqBand, &pDlyPara);

    return ret;
}

/* 设置TDD展宽拍数 */
UINT32 BspCfrSetTddSwPara(UINT32 difChn)
{
    UINT32 ret       = BSP_OK;
    UINT32 cpgMaxlen = 0;
    UINT32 loop      = 0;
    UINT32 freqBand  = 0;
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};
    T_BspHalAdaptCfrDlyCalcPara pDlyPara = {0};

    ret = BspGetCfrWinLevelPara(difChn,cfrWinLevel);
    ret |= BspCfrGetCpgVaildLen(difChn, &cpgMaxlen);
    if(ret != BSP_OK)
    {
        dbgInfo("[%s]Cfr Get Cpg Len Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    pDlyPara.uiCpgLen = cpgMaxlen;

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        pDlyPara.uiCfrWinLevel[loop] = cfrWinLevel[loop];
    }

    dbgInfo("%s difChn:%d cpglen:%d winlevel:%d %d %d\n ",__FUNCTION__,difChn,pDlyPara.uiCpgLen,pDlyPara.uiCfrWinLevel[0],pDlyPara.uiCfrWinLevel[1],pDlyPara.uiCfrWinLevel[2]);

    ret |= BspHalAdaptCfrSetTddsw(difChn, freqBand, &pDlyPara);

    return ret;
}

/* 设置CPG半长 */
UINT32 BspCfrSetCpgLen(UINT32 difChn)
{
    UINT32 ret       = BSP_OK;
    UINT32 cpgMaxlen = 0;
    UINT32 freqBand  = 0;

    ret |= BspCfrGetCpgVaildLen(difChn, &cpgMaxlen);
    if(ret != BSP_OK)
    {
        dbgInfo("[%s]Cfr Get Cpg Len Error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("%s difChn:%d cpglen:%d  \n ",__FUNCTION__,difChn,cpgMaxlen);

    ret |= BspHalAdaptCfrSetCpgLen(difChn, freqBand, cpgMaxlen);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspInitCfrModuleFunc
*  功能描述   : CFR 功能模块接口挂接
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrModuleFunc(VOID)
{
    UINT32 ulTmpRet         = BSP_OK;
    UINT32 ulFuncRet        = BSP_OK;
    UINT32 difChnNum        = 0;
    UINT32 difChnNumPerChip = 0;
    UINT32 chipNum          = 0;
    UINT32 speCfrCfgFlag    = 0;
    T_CfrModule *pCfrModule = NULL;
    UINT32 cfrInitFlag      = CFR_FUNC_NOT_INIT;
    UINT32 cfrVerId         = CFR_CPGCAL_CPUMODE;

    cfrVerId         = BspGetCfrFuncVerId();
    difChnNum        = BspGetDifChnTotalNum();
    difChnNumPerChip = BspGetDifChnNumPerChip();
    chipNum          = BspGetDifChipNum();
    ulTmpRet         = BspSetCfrDifChnNum(difChnNum);
    ulTmpRet        |= BspSetCfrDifChnNumPerChip(difChnNumPerChip);
    if (ulTmpRet != BSP_OK)
    {
        ulFuncRet |= BIT_SET(0);
    }

    cfrInitFlag = BspGetCfrFuncFlag();
    if (cfrInitFlag == CFR_FUNC_INIT)
    {
        return BSP_OK;
    }

    ulTmpRet  = BspCfrFuncMemInfoInit();
    ulTmpRet |= BspCfrParaMemInfoInit();
    BspCfrFsByDifBackInit(BspGetCpgFsByDifChnCommon);
    if (ulTmpRet != BSP_OK)
    {
        ulFuncRet |= BIT_SET(1);
        dbgInfo("[%s]Cfr Func Mem Error!The function module not used\n", __FUNCTION__);
    }

    pCfrModule = (T_CfrModule *)BspGetCfrModuleInfo();
    INPUT_POINTER_CHECK(pCfrModule);

    pCfrModule->cfrFunc.pGateInit   = BspInitCfrGatePara;
    pCfrModule->cfrFunc.pCfrCfg     = BspCfrCfg; /* 削峰门限、窗长等动态参数配置 */
    pCfrModule->cfrFunc.pCpgInit    = BspCfrCpgInit_CpuCal;
    pCfrModule->cfrFunc.pCpgCfg     = BspCfrCpgCfg_CpuCal;
    pCfrModule->cfrFunc.pDisable    = BspCfrSetDisable;
    pCfrModule->cfrFunc.pEnable     = BspCfrSetEnable;
    pCfrModule->cfrFunc.pCfgCpgPara = BspCfrSetCpgPara;
    pCfrModule->cfrFunc.pCfrVer     = BspCfrGetVerInfo;
    pCfrModule->cfrFunc.pCfrDelay   = BspCfrSetDelay;

    return ulFuncRet;
}

/*****************************************************************************
*  函数名称   : BspSetCfrOutMode
*  功能描述   : CFR输出模式（用于调试接口）
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn:中频通道号
               mode：输出模式，0，零延时旁路；1，等延时旁路；2，正常削峰输出；3，抵消脉冲模式
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrOutMode(UINT32 difChn, UINT32 mode)
{
    UINT32 freqBand = 0;

    return BspHalAdaptSetCfrOutMode(difChn, freqBand, mode);
}

/*****************************************************************************
*  函数名称   : BspGetCfrChnBwInfo
*  功能描述   : 获取当前配置的IBW和OBW
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               bandId:频段号
*  输出参数   : obw: obw
               ibw: ibw
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2021-05-29 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrChnBwInfo(UINT32 difchan, UINT32 bandId, UINT32 *obw,UINT32 *ibw)
{
    UINT32 ret          = BSP_OK;
    UINT32 carrNum      = 0;
    UINT32 bwSum        = 0;
    UINT32 loop         = 0;
    UINT32 freqMax      = 0;
    UINT32 carrBwMin    = 0;
    UINT32 carrBwMax    = 0;
    UINT32 carrBw       = 0;
    UINT32 carrFreq     = 0;
    UINT32 gateInitFlag = 0;
    UINT32 rfChan       = 0;
    UINT32 freqMin      = 0xFFFFFFFF;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_RruBandCfgInfo *pRruRfCfgInfo = NULL;

    INPUT_POINTER_CHECK(obw);
    INPUT_POINTER_CHECK(ibw);

    BspGetCfrGateInitFlag(&gateInitFlag);
    if(gateInitFlag != CFR_GATE_INIT_CFG_FREQ)
    {
        pCfrDifChnInfo = BspGetCfrChnInfo(difchan);
        if (pCfrDifChnInfo == NULL)
        {
            dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error!\n", __FUNCTION__, difchan);
            return BSP_ERROR;
        }
        if (pCfrDifChnInfo->usedFlag[bandId] == CFR_BAND_NOT_USED)
        {
            *obw = 0;
            dbgInfo("%s>>DifChnl'%d Band'%d CfrBandNotUsed; OBW= %d\n",
                    __FUNCTION__, difchan, bandId,*obw);
            return BSP_OK;
        }
        carrNum = pCfrDifChnInfo->bandCarrNum[bandId];
    }
    else
    {
        ret = BspGetRfChnInfoByDifChn(difchan,TX,&rfChan);
        if (BSP_OK != ret)
        {
            dbgErr("%s>>difchan'%d BspGetRfChnInfoByDifChn Get Error!\n",
                   __FUNCTION__, difchan);
            return BSP_ERROR;
        }

        pRruRfCfgInfo = malloc(sizeof(T_RruBandCfgInfo));
        if (NULL == pRruRfCfgInfo)
        {
            dbgErr("[%s]RfChn %d RfCfgInfoMalloc Error!\n", __FUNCTION__, rfChan);
            return BSP_ERROR;
        }
        memset(pRruRfCfgInfo, 0, sizeof(T_RruBandCfgInfo));

        ret = BspGetRruTxDifCfgPara(rfChan, pRruRfCfgInfo);
        if(ret != BSP_OK)
        {
            free(pRruRfCfgInfo);
            dbgErr("[%s]RfChn %d Cfr Chn Info Update Error!\n",__FUNCTION__,rfChan);
            return BSP_ERROR;
        }
        carrNum = BSP_MAX_CARR_NUM;
    }

    for(loop = 0; loop < carrNum; loop ++)
    {
        if(gateInitFlag != CFR_GATE_INIT_CFG_FREQ)
        {
            if (pCfrDifChnInfo->carrInfo[bandId][loop].powerMw == 0)
            {
                continue;
            }
            carrBw = pCfrDifChnInfo->carrInfo[bandId][loop].carrBw;
            carrFreq = pCfrDifChnInfo->carrInfo[bandId][loop].freq;
        }
        else
        {
            if(pRruRfCfgInfo->info[bandId].carr[loop].carrFreq == 0)
            {
                continue;
            }
            carrBw = pRruRfCfgInfo->info[bandId].carr[loop].carrBw;
            carrFreq = pRruRfCfgInfo->info[bandId].carr[loop].carrFreq;
        }
        dbgInfoEx("%s difchan'%d band'%d loop'%d freq'%d carrBw'%d\n",
                    __FUNCTION__,difchan,bandId,loop,carrFreq,carrBw);

        if(carrFreq < freqMin)
        {
            freqMin = carrFreq;
            carrBwMin = carrBw;
        }
        if(carrFreq > freqMax)
        {
            freqMax = carrFreq;
            carrBwMax = carrBw;
        }
        bwSum += carrBw;
    }

    *obw = bwSum;
    *ibw = (freqMax + carrBwMax/2) - (freqMin - carrBwMin/2);
    dbgInfo("%s difchan'%d band'%d OBW'%d IBW'%d\n",__FUNCTION__,difchan,bandId,*obw,*ibw);

    if(pRruRfCfgInfo != NULL)
    {
        free(pRruRfCfgInfo);
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspCfrGateInit_TDD
*  功能描述   : TDD根据obw和ibw比值自动初始化削峰动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               pTddPara:TDD规则表
               len：TDD表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 接口先实现，待算法提供具体表格后对gateinit接口单板下用新接口挂接
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 刘巨波@2021-05-29 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGateInit_TDD(UINT32 difchan, T_CfrDynPara_TDD *pTddPara, UINT32 len)
{
    UINT32 ret    = BSP_OK;
    UINT32 ibw    = 0;
    UINT32 obw    = 0;
    FLOAT bwCoef  = 0.0;
    UINT32 loop   = 0;
    UINT32 bandId = 0;
    UINT32 index  = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};
    UINT32 cfrWin[E_CFR_THR_NUM]  = {0};
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};

    ret = BspGetCfrChnBwInfo(difchan,bandId,&obw,&ibw);
    if(ret != BSP_OK)
    {
        dbgErr("%s difchan'%d band'%d get CFR BW info error!\n",__FUNCTION__,difchan,bandId);
        return BSP_ERROR;
    }

    if((obw == 0) || (ibw == 0))
    {
        dbgErr("%s difchan'%d band'%d get CFR BW info is zero, not need init gate!\n",
                __FUNCTION__,difchan,bandId);
        return BSP_OK;
    }

    bwCoef = (FLOAT)obw/(FLOAT)ibw;
    dbgInfo("%s difchan'%d band'%d bwCoef(%f)=obw(%d)/ibw(%d)\n",
            __FUNCTION__,difchan,bandId,bwCoef,obw,ibw);

    for(loop = 0; loop < len; loop++)
    {
        if((bwCoef > pTddPara[loop].lowbound) && (bwCoef <= pTddPara[loop].upbound))
        {
            index = loop;
            break;
        }
    }

    if(loop >= len)
    {
        index = len-1;
        dbgErr("%s difchan'%d band'%d bwcoef'%f not found gate,switch full bw gate!\n",__FUNCTION__,difchan,bandId,bwCoef);
    }
    dbgInfo("%s index:%d \n",__FUNCTION__,index);

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        cfrGate[loop] = pTddPara[index].cfrgate[loop];
        cfrDelt[loop] = pTddPara[index].cfrdelt[loop];
        cfrWin[loop] = pTddPara[index].cfrwin[loop];
        cfrWinLevel[loop] = pTddPara[index].cfrwinlevel[loop];
        dbgInfoEx("%s cfrGate[%d]:%d \n",__FUNCTION__,loop,cfrGate[loop]);
        dbgInfoEx("%s cfrDelt[%d]:%d \n",__FUNCTION__,loop,cfrDelt[loop]);
        dbgInfoEx("%s cfrWin[%d]:%d \n",__FUNCTION__,loop,cfrWin[loop]);
        dbgInfoEx("%s cfrWinLevel[%d]:%d \n",__FUNCTION__,loop,cfrWinLevel[loop]);
    }

    ret = BspSetCfrGatePara(difchan, cfrGate);
    ret |= BspSetCfrWinPara(difchan, cfrWin);
    ret |= BspSetCfrDeltPara(difchan, cfrDelt);
    ret |= BspSetCfrWinLevelPara(difchan, cfrWinLevel);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspGetCfrChnMixRadioInfo
*  功能描述   : 获取通道所有载波制式信息，通过或操作输出混合制式值(配置FDD削峰动态参数相关)
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
*  输出参数   : mixRadio: 通道混模制式
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 若通道只存在LTE制式或只存在NR制式时，需要对其载波数进行判断。
               若是单载波，则将制式值最高位置1；若是多载波，则不进行最高位置0。
               对于NR制式，无论获取值为0x2000还是0x4000，求取混模时均采用0x4000计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-12 10:21:14
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrChnMixRadioInfo(UINT32 difchan, UINT32 *mixRadio)
{
    UINT32 bandLoop   = 0;
    UINT32 carrLoop   = 0;
    UINT32 chnRadio   = 0;
    UINT32 chnCarrNum = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;

    INPUT_POINTER_CHECK(mixRadio);

    pCfrDifChnInfo = BspGetCfrChnInfo(difchan);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Chn[%d] Info Error!\n", __FUNCTION__, difchan);
        return BSP_ERROR;
    }

    for(bandLoop = 0; bandLoop < pCfrDifChnInfo->bandNum; bandLoop++)
    {
        for(carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_5G)
            {
                chnRadio |= RADIO_STANDARD_5G_RESERVED;
            }
            else
            {
                chnRadio |= pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            }

            if (chnCarrNum <= (UINT_MAX - 1))
            {
                chnCarrNum = chnCarrNum + 1;
            }
        }
    }

    /******  单LTE或单NR的单载波时，将混模制式最高位置1  ***********/
    if ((chnRadio == RADIO_STANDARD_LTE_FDD) || (chnRadio == RADIO_STANDARD_5G_RESERVED))
    {
        if (chnCarrNum == 1)
        {
            chnRadio |= 0x80000000;
        }
    }

    *mixRadio = chnRadio;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCfrChnMinBwInfo
*  功能描述   : 获取当前通道最小带宽(配置FDD削峰动态参数相关)
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
*  输出参数   : minBw: 通道最小带宽
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 1、当通道中包含L或V或LV制式时，求取结果为L或V或LV的最小带宽；否则求取整个通道最小带宽。
*              2、若通道中存在GSM载波且带宽为0，则将GSM带宽当做200k参与计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-12 10:21:30
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrChnMinBwInfo(UINT32 difchan, UINT32 *minBw)
{
    UINT32 bandLoop = 0;
    UINT32 carrLoop = 0;
    UINT32 lvFlag   = 0;
    UINT32 lvMinBw  = 0xFFFFFFFF;
    UINT32 splMinBw = 0xFFFFFFFF;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;

    INPUT_POINTER_CHECK(minBw);

    pCfrDifChnInfo = BspGetCfrChnInfo(difchan);
    if (pCfrDifChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Chn[%d] Info Error!\n", __FUNCTION__, difchan);
        return BSP_ERROR;
    }

    for(bandLoop = 0; bandLoop < pCfrDifChnInfo->bandNum; bandLoop++)
    {
        for(carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_VALID)
            {
                if ((pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_LTE_FDD)
                    || (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_5G)
                    || (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_5G_RESERVED))
                {
                    lvMinBw = (lvMinBw < pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw) ? lvMinBw : pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
                    lvFlag = CFR_CHN_EXIST_LV;
                }
                else if ((pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio == RADIO_STANDARD_GSM)
                        && (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw == 0))
                {
                    splMinBw = (splMinBw < 200) ? splMinBw : 200;
                }
                else
                {
                    splMinBw = (splMinBw < pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw) ? splMinBw : pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
                }
            }
        }
    }

    if (lvFlag == CFR_CHN_EXIST_LV)
    {
        *minBw = lvMinBw;
    }
    else
    {
        *minBw = splMinBw;
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSelectCfrGatePara
*  功能描述   : FDD根据混模制式和最小带宽选取对应的削峰动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               len：FDD动态参数表格大小
               pFddPara:FDD削峰动态参数表
*  输出参数   : index: 动态参数表的行索引
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-16 10:27:43
*----------------------------------------------------------------------------
*/
UINT32 BspSelectCfrGatePara(UINT32 difchan, UINT32 len, T_CfrDynPara_FDD *pFddPara, UINT32 *index)
{
    UINT32 ret         = BSP_OK;
    UINT32 chnMixRadio = 0;
    UINT32 chnMinBw    = 0;
    UINT32 loop        = 0;
    UINT32 paraIndex   = 0;

    INPUT_POINTER_CHECK(index);
    INPUT_POINTER_CHECK(pFddPara);

    ret = BspGetCfrChnMixRadioInfo(difchan, &chnMixRadio);
    ret |= BspGetCfrChnMinBwInfo(difchan, &chnMinBw);

    dbgInfo("[%s] chnMixRadio:0x%x, chnMinBw:%d \n",__FUNCTION__, chnMixRadio, chnMinBw);

    for(loop = 0; loop < len; loop++)
    {
        if(chnMixRadio == pFddPara[loop].radio)
        {
            if((chnMinBw > pFddPara[loop].lowbound) && (chnMinBw <= pFddPara[loop].upbound))
            {
                paraIndex = loop;
                break;
            }
        }
    }

    if(loop >= len)
    {
        paraIndex = len-1;
        dbgErr("%s difchan'%d mixRadio'0x%x, minBw'%d not found gate,switch the last gate!\n",__FUNCTION__,difchan,chnMixRadio,chnMinBw);
    }

    *index = paraIndex;

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrGateInit_FDD
*  功能描述   : FDD初始化削峰动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               pFddPara:FDD规则表
               len：FDD动态参数表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-08 14:21:55
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGateInit_FDD(UINT32 difchan, T_CfrDynPara_FDD *pFddPara, UINT32 len)
{
    UINT32 ret   = BSP_OK;
    UINT32 loop  = 0;
    UINT32 index = 0;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    UINT32 cfrDelt[E_CFR_THR_NUM] = {0};
    UINT32 cfrWin[E_CFR_THR_NUM]  = {0};
    UINT32 cfrWinLevel[E_CFR_THR_NUM] = {0};

    ret = BspSelectCfrGatePara(difchan, len, pFddPara, &index);

    for(loop = 0; loop < E_CFR_THR_NUM; loop++)
    {
        if(index < len)
        {
            cfrGate[loop] = pFddPara[index].cfrgate[loop];
            cfrDelt[loop] = pFddPara[index].cfrdelt[loop];
            cfrWin[loop] = pFddPara[index].cfrwin[loop];
            cfrWinLevel[loop] = pFddPara[index].cfrwinlevel[loop];
            dbgInfoEx("%s cfrGate[%d]:%d \n",__FUNCTION__,loop,cfrGate[loop]);
            dbgInfoEx("%s cfrDelt[%d]:%d \n",__FUNCTION__,loop,cfrDelt[loop]);
            dbgInfoEx("%s cfrWin[%d]:%d \n",__FUNCTION__,loop,cfrWin[loop]);
            dbgInfoEx("%s cfrWinLevel[%d]:%d \n",__FUNCTION__,loop,cfrWinLevel[loop]);
        }
    }

    ret |= BspSetCfrGatePara(difchan, cfrGate);
    ret |= BspSetCfrDeltPara(difchan, cfrDelt);
    ret |= BspSetCfrWinPara(difchan, cfrWin);
    ret |= BspSetCfrWinLevelPara(difchan, cfrWinLevel);

    return ret;
}

/*****************************************************************************
*  函数名称   : BspCfrGateInit_IC4_2
*  功能描述   : 算法提供TDD和FDD的配置动态参数规则，如门限、窗长等，后续算法提供每个
               机型表格，直接根据表格自动初始化动态参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difchan:中频通道号
               radioflag:制式标志，0:TDD 1:FDD
               pTddPara:TDD规则表
               pFddPara:FDD规则表
               len：表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 接口先实现，待算法提供具体表格后对gateinit接口单板下用新接口挂接
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波@2022-03-8 14:20:13
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGateInitCommon(UINT32 difchan, UINT32 radioflag, T_CfrDynPara_TDD *pTddPara, T_CfrDynPara_FDD *pFddPara, UINT32 len)
{
    UINT32 ret = BSP_OK;

    if(radioflag == CFR_CHAN_TDD_DX)
    {
        INPUT_POINTER_CHECK(pTddPara);
        ret = BspCfrGateInit_TDD(difchan,pTddPara,len);
    }
    else if(radioflag == CFR_CHAN_FDD_DX)
    {
        INPUT_POINTER_CHECK(pFddPara);
        ret = BspCfrGateInit_FDD(difchan,pFddPara,len);
    }
    else
    {
        dbgErr("%s radio flag is error!",__FUNCTION__);
        return BSP_ERROR;
    }

    return ret;
}

/*****************************************************************************
*  函数名称   : BspSetNBCarrMode
*  功能描述   : 设定NB 载波模式
*  读全局变量 :
*  写全局变量 :
*  输入参数   : ulChan   - Tx通道号
*             : ulCarr   - 载波号
*             : ulMode   - 载波模式
                0,1--inband; 2--guardband;  3--standalone
*  输出参数   :
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2019.12.4, 创建
*******************************************************************************/
UINT32 BspSetNBCarrMode(UINT32 ulChan, UINT32 ulCarr, UINT32 ulMode)
{
    UINT32 retVal  = BSP_OK;
    UINT32 chipidx = 0;
    UINT32 difChn  = 0;

    if((ulChan >= MAX_TX_CHANNEL)||(ulCarr >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    retVal |= BspGetDifInfoByBspChn(ulChan, TX, &chipidx, &difChn);

    if(BSP_OK == retVal)
    {
        g_aulNBCarrMode[difChn][ulCarr]=ulMode;
    }

    return retVal;
}

UINT32 BspGetNBCarrMode(UINT32 difChn,UINT32 ulCarr)
{
    UINT32 ulMode = 0;

    if((difChn >= MAX_TX_CHANNEL)||(ulCarr >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    ulMode = g_aulNBCarrMode[difChn][ulCarr];

    return ulMode;
}


/**  削峰硬件计算频段靠前摆放参数初始化  **/
UINT32 BspInitRangeBandPara(void)
{
    return BspHalAdaptCpgeParaRangeFreqInit();
}

/** 设置削峰静态门控初始化 **/
UINT32 BspInitCfrSetCpgGateBypass(void)
{
    return BspHalAdaptCfrSetCpgGateBypassInit();
}


UINT32 BspCfrHbfParaInitAll(VOID)
{
    UINT32 bspChan = 0;
    UINT32 difChn = 0;
    UINT32 chipId = 0;
    UINT32 ret = BSP_OK;
    UINT32 retVal = BSP_OK;
    for (bspChan = 0; bspChan < BspGetTxBspChanNum(); bspChan++)  /*TX*/
    {

        retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChn);
        if (BSP_OK != retVal)
        {
            dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",
               __FUNCTION__, bspChan);
               difChn = bspChan;
        }
        ret |= BspCfrHbfParaInit(difChn);
    }
    return ret;
}

UINT32 cfrcpgcoefprn(UINT32 carrRadio, UINT32 carrBw,UINT32 cpgFs)
{
    UINT32 ret = BSP_OK;
    UINT32 cfrBw = 0;
    UINT32 difChn  = 0;
    UINT32 loop = 0;
    T_CfrCpgPara cfrCpgPara = {0};
    ret = BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
    ret = BspGetCfrCpgCoefCommon(difChn,cfrBw,cpgFs, &cfrCpgPara);
    dbgInfo("cfrBw:%d cpgFs:%d vaileLen:%d coefLen:%d\n",cfrCpgPara.cfrBw,cfrCpgPara.cpgRate,cfrCpgPara.vaildLen,cfrCpgPara.coefLen);
    if(cfrCpgPara.pCoefPara ==NULL)
    {
        dbgInfo("CFR Cpg CoefPara is NULL\n ");
        return BSP_ERROR;
    }
    for(loop = 0; loop <cfrCpgPara.coefLen; loop++)
    {
        dbgInfo("%d:[%d]\n",loop,cfrCpgPara.pCoefPara[loop]);
    }
    return ret;
}

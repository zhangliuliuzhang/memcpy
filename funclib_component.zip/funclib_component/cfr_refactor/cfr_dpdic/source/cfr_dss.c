/*****************************************************************************
* 版权所有(C) 2023,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_dss.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2的CFR模块配置功能
* 注意事项 : 无
* 作    者 : 张龙10281388
* 创建日期 : 2023-06-30
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 张龙10281388
* 修改日戳: 20223-06-30
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "bsppub.h"
#include "cfr_dss.h"
#include "ichaladapt_ic4_2.h"
#include "cfr_cfgpara.h"
#include "cfr_cpu.h"
#include "cfr_cpgcal.h"
#include "cfr_dpdic.h"
#include "ichaladaptcfrapi.h"
#include "freqcfg_ic4_2.h"
#include "cfr_hard.h"
#include "freqcfgcommon.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"

UINT32 g_cfrDssGroupFlag[BSP_MAX_CARR_NUM] = {0};
UINT32 g_cfrDssCarrMap[BSP_MAX_CARR_NUM][BSP_MAX_CARR_NUM] = {0};
UINT32 g_refreshCfrCpgFlag[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
static FUN_GET_POWCTRL_TSSI_INFO pGetTssiPowInfo = NULL;

/*****************************************************************************
*  函数名称   : BspCfrInitDSSCarrGroup
*  功能描述   : 筛选出具有频谱共享关系的一组载波
*  输入参数   : row ： 全局变量 g_cfrDssCarrMap 中遍历行与列时第一个数值不为零的行号。
*  输出参数   : g_cfrDssGroupFlag ：具有频谱共享关系的载波编号对应下标置1的全局变量一维数组
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : IC4.2 削峰只考虑 LTE 或 NR 两种载波的频谱共享。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 20:33:00
*----------------------------------------------------------------------------
*/
UINT32 BspCfrInitDSSCarrGroup(UINT32 row)
{
    UINT32 retVal = BSP_OK;
    UINT32 index  = 0;

    if (row >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }

    g_cfrDssGroupFlag[row] = CFR_CARR_EXIST_DSS;

    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        if (0 == g_cfrDssCarrMap[row][index])
        {
            break;
        }

        retVal |= BspCfrInitDSSCarrGroup(g_cfrDssCarrMap[row][index]);
        g_cfrDssCarrMap[row][index] = 0;
    }

    return retVal;
}


/*****************************************************************************
*  函数名称   : BspCfrSetDssCarrInfo
*  功能描述   : 设置通道内DSS载波信息
*  输入参数   : difChn ： 中频通道号
*  输出参数   : pChnInfo ：已经将被共享载波置为无效，主载波带宽改为共享载波最左至最右宽度，
                          功率取载波中最大值，综合带宽和功率值归一到带宽较大的载波上。
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 1、IC4.2 削峰只考虑 LTE 或 NR 两种载波的频谱共享；
               2、DSS硬件计算场景才向HAL层传递载波信息用于功率的计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 21:02:13
*----------------------------------------------------------------------------
*/
UINT32 BspCfrSetDssCarrInfo(UINT32 difChn, T_CfrChnBandInfo *pChnInfo)
{
    UINT32 retVal         = BSP_OK;
    UINT32 freqBand       = 0;
    UINT32 maxBwCarrIndex = 0;
    UINT32 maxBwCarrNo    = 0;
    UINT32 maxBwCarrRadio = 0;
    UINT32 maxCarrBw      = 0;
    UINT32 maxDssFreq     = 0;
    UINT32 maxCarrPow     = 0;
    UINT32 index          = 0;
    UINT32 cpgMode        = 0;
    UINT32 minDssFreq     = 0xffffffff;
    T_BspHalAdaptCfrDssCarrInfo sharedCarr = {0};
    T_BspHalAdaptDifCommCfrPara cfrCommPara = {0};

    INPUT_POINTER_CHECK(pChnInfo);

    if(BSP_OK != BspGetCfrCommPara(&cfrCommPara))
    {
       dbgErr("%s Get CFR Commom Para Error!",__FUNCTION__);
       return BSP_ERROR;
    }

    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        if (g_cfrDssGroupFlag[index] != 0)
        {
            if (maxCarrBw < pChnInfo->carrInfo[freqBand][index].carrBw)
            {
                maxCarrBw = pChnInfo->carrInfo[freqBand][index].carrBw;
                maxBwCarrIndex = index;
            }

            if (maxCarrPow < pChnInfo->carrInfo[freqBand][index].powerMw)
            {
                maxCarrPow = pChnInfo->carrInfo[freqBand][index].powerMw;
            }

            if (maxDssFreq < (pChnInfo->carrInfo[freqBand][index].freq + (pChnInfo->carrInfo[freqBand][index].carrBw)/2))
            {
                maxDssFreq = pChnInfo->carrInfo[freqBand][index].freq + (pChnInfo->carrInfo[freqBand][index].carrBw)/2;
            }

            if (minDssFreq > (pChnInfo->carrInfo[freqBand][index].freq - (pChnInfo->carrInfo[freqBand][index].carrBw)/2))
            {
                minDssFreq = pChnInfo->carrInfo[freqBand][index].freq - (pChnInfo->carrInfo[freqBand][index].carrBw)/2;
            }

            dbgInfo("[%s] Chn'%d, index'%d, carrNo'%d, carrRadio'0x%x, carrBw'%d is DSS Carr. \n", __FUNCTION__, difChn, index, pChnInfo->carrInfo[freqBand][index].carrNo,
                    pChnInfo->carrInfo[freqBand][index].carrRadio, pChnInfo->carrInfo[freqBand][index].carrBw);
        }
    }

    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        if ((g_cfrDssGroupFlag[index] != 0) && (index != maxBwCarrIndex))
        {
            sharedCarr.uiCarrId[sharedCarr.uiCarrNum] = pChnInfo->carrInfo[freqBand][index].carrNo;
            sharedCarr.uiCarrRadio[sharedCarr.uiCarrNum] = pChnInfo->carrInfo[freqBand][index].carrRadio;
            sharedCarr.uiCarrNum += 1;

            pChnInfo->carrInfo[freqBand][index].carrFlag = CFR_CARR_INVALID;
        }
    }

    for (index = 0; index < sharedCarr.uiCarrNum; index++)
    {
        dbgInfo("[%s] Send to Hal: Chn'%d, carrNo'%d, carrRadio'0x%x. \n", __FUNCTION__, difChn, sharedCarr.uiCarrId[index], sharedCarr.uiCarrRadio[index]);
    }

    dbgInfo("[%s] Send to Hal MaxBwCarr: Chn'%d, index'%d, carrNo'%d, radio'0x%x, originBw'%d, MaxDssBw'%d(MaxFeq'%d-MinFeq'%d). \n", __FUNCTION__, difChn, maxBwCarrIndex, pChnInfo->carrInfo[freqBand][maxBwCarrIndex].carrNo,
            pChnInfo->carrInfo[freqBand][maxBwCarrIndex].carrRadio, pChnInfo->carrInfo[freqBand][maxBwCarrIndex].carrBw, (maxDssFreq - minDssFreq),maxDssFreq,minDssFreq);

    pChnInfo->carrInfo[freqBand][maxBwCarrIndex].powerMw = maxCarrPow;
    pChnInfo->carrInfo[freqBand][maxBwCarrIndex].carrBw = maxDssFreq - minDssFreq;
    maxBwCarrNo = pChnInfo->carrInfo[freqBand][maxBwCarrIndex].carrNo;
    maxBwCarrRadio = pChnInfo->carrInfo[freqBand][maxBwCarrIndex].carrRadio;

    cpgMode = cfrCommPara.uiCpgMode[difChn];
    if(cpgMode == CFR_CPG_HW_CAL)
    {
        retVal |= BspHalAdaptCfrSetDssCarrInfo(difChn, maxBwCarrNo, maxBwCarrRadio, &sharedCarr);
    }

    return retVal;
}


//筛选出具有频谱共享关系的一组载波、设置通道内DSS载波信息
UINT32  BspSetCfrDSSCarrGroupInfo(UINT32 difChan, T_CfrChnBandInfo *pChnInfo)
{
    UINT32 retVal        = BSP_OK;
    UINT32 cnt           = 0;
    UINT32 groupLoop     = 0;
    UINT32 rowLoop       = 0;
    UINT32 colLoop       = 0;
    UINT32 g_cfrDssStartedSave = 0;

    INPUT_DIFCHAN_CHECK(difChan);
    INPUT_POINTER_CHECK(pChnInfo);

    for (groupLoop = 0; groupLoop < CFR_CHN_DSS_GROUP_MAX_NUM; groupLoop++)
    {
        g_cfrDssStartedSave = CFR_STOP_GET_DSS_GROUP;

        for (rowLoop = 0; rowLoop < BSP_MAX_CARR_NUM; rowLoop++)
        {
            for (colLoop = 0; colLoop < BSP_MAX_CARR_NUM; colLoop++)
            {
                if (0 == g_cfrDssCarrMap[rowLoop][colLoop])
                {
                    break;
                }

                if ((CFR_START_GET_DSS_GROUP == g_cfrDssStartedSave) && (CFR_CARR_EXIST_DSS == g_cfrDssGroupFlag[ g_cfrDssCarrMap[rowLoop][colLoop] ]))
                {
                    retVal |= BspCfrInitDSSCarrGroup(rowLoop);
                }
                else
                {
                    retVal |= BspCfrInitDSSCarrGroup(rowLoop);
                    g_cfrDssStartedSave = CFR_START_GET_DSS_GROUP;
                }
            }
        }

        for (cnt = 0; cnt < BSP_MAX_CARR_NUM; cnt++)
        {
            if (g_cfrDssGroupFlag[cnt] != 0)
            {
                dbgInfoEx("[%s] groupLoop'%d, g_cfrDssGroupFlag: %d %d %d %d %d %d %d %d\n", __FUNCTION__, groupLoop, g_cfrDssGroupFlag[0],g_cfrDssGroupFlag[1],
                        g_cfrDssGroupFlag[2],g_cfrDssGroupFlag[3],g_cfrDssGroupFlag[4],g_cfrDssGroupFlag[5],g_cfrDssGroupFlag[6],g_cfrDssGroupFlag[7]);

                retVal |= BspCfrSetDssCarrInfo(difChan, pChnInfo);
                memset_s(g_cfrDssGroupFlag, BSP_MAX_CARR_NUM, 0, BSP_MAX_CARR_NUM);
                break;
            }
        }
    }

    for (cnt = 0; cnt < pChnInfo->bandCarrNum[0]; cnt++)
    {
        if (pChnInfo->carrInfo[0][cnt].carrFlag == CFR_CARR_INVALID)
        {
            continue;
        }

        dbgInfo("[%s] After DSS deal ChnInfo: difChn'%d, carrNo'%d, radio'0x%x, carrBw'%d, centerFeq'%d\n",__FUNCTION__,difChan,pChnInfo->carrInfo[0][cnt].carrNo,
                pChnInfo->carrInfo[0][cnt].carrRadio,pChnInfo->carrInfo[0][cnt].carrBw,pChnInfo->carrInfo[0][cnt].freq);
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspCfrCarrJudgeDss
*  功能描述   : 判断两载波是否存在频谱共享
*  输入参数   : difchan:中频通道号
               freqBand:频段号
               carrNo1:T_CfrChnBandInfo中的载波序号，非载波号
               carrNo2:T_CfrChnBandInfo中的载波序号，非载波号
               pChnInfo：削峰通道中的载波信息
*  输出参数   : dssFlag: 是否动态频谱共享标志（1：频谱共享；0：非频谱共享）
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 09:29:48
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCarrJudgeDss(UINT32 difchan, UINT32 freqBand, UINT32 carrNo1, UINT32 carrNo2, T_CfrChnBandInfo *pChnInfo, UINT32 *dssFlag)
{
    INT32 carr1FreqUp  = 0;
    INT32 carr1FreqLow = 0;
    INT32 carr2FreqUp  = 0;
    INT32 carr2FreqLow = 0;
    UINT32 carrDssflag  = CFR_CARR_NO_EXIST_DSS;

    INPUT_POINTER_CHECK(pChnInfo);
    INPUT_POINTER_CHECK(dssFlag);

    if (pChnInfo->usedFlag[freqBand] == CFR_BAND_NOT_USED)
    {
        dbgErr("[%s] Error, the band %d is not used! \n", __FUNCTION__, freqBand);
        return BSP_ERROR;
    }

    carr1FreqUp = pChnInfo->carrInfo[freqBand][carrNo1].freq + (pChnInfo->carrInfo[freqBand][carrNo1].carrBw)/2;
    carr1FreqLow = pChnInfo->carrInfo[freqBand][carrNo1].freq - (pChnInfo->carrInfo[freqBand][carrNo1].carrBw)/2;

    carr2FreqUp = pChnInfo->carrInfo[freqBand][carrNo2].freq + (pChnInfo->carrInfo[freqBand][carrNo2].carrBw)/2;
    carr2FreqLow = pChnInfo->carrInfo[freqBand][carrNo2].freq - (pChnInfo->carrInfo[freqBand][carrNo2].carrBw)/2;

    if( ((carr1FreqLow < carr2FreqLow) && ((carr1FreqUp - carr2FreqLow) > CFR_DSS_MERGE_MIN_BW)) || (((carr2FreqUp - carr1FreqLow) > CFR_DSS_MERGE_MIN_BW) && (carr2FreqUp < carr1FreqUp))
        || ((carr2FreqLow < carr1FreqLow) && ((carr2FreqUp - carr1FreqLow) > CFR_DSS_MERGE_MIN_BW)) || (((carr1FreqUp - carr2FreqLow) > CFR_DSS_MERGE_MIN_BW) && (carr1FreqUp < carr2FreqUp)) )
    {
        carrDssflag = CFR_CARR_EXIST_DSS;
        dbgInfo("[%s] difchan'%d, index'%d(carrNo'%d radio'0x%x feq:%d ~ %d) and index'%d(carrNo'%d radio'0x%x feq:%d ~ %d) is DSS.\n",__FUNCTION__,difchan,
            carrNo1,pChnInfo->carrInfo[freqBand][carrNo1].carrNo,pChnInfo->carrInfo[freqBand][carrNo1].carrRadio,carr1FreqLow,carr1FreqUp,
            carrNo2,pChnInfo->carrInfo[freqBand][carrNo2].carrNo,pChnInfo->carrInfo[freqBand][carrNo2].carrRadio,carr2FreqLow,carr2FreqUp);
    }

    *dssFlag = carrDssflag;

    return BSP_OK;
}

//
UINT32 BspJudgeDSSCarrRadio(T_CfrChnBandInfo *pChnInfo, INT32 freqBand, UINT32 loop)
{
    if ( (pChnInfo->carrInfo[freqBand][loop].carrFlag == CFR_CARR_INVALID)
                || (pChnInfo->carrInfo[freqBand][loop].carrRadio == BSP_RADIO_STANDARD_GSM)
                || (pChnInfo->carrInfo[freqBand][loop].carrRadio == BSP_RADIO_STANDARD_UMTS)
                || (pChnInfo->carrInfo[freqBand][loop].carrRadio == BSP_RADIO_STANDARD_NB_IOT))
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}
/*****************************************************************************
*  函数名称   : BspCfrInitCarrDssMap
*  功能描述   : 初始化削峰通道内载波频谱共享关系映射表
*  输入参数   : difChn ： 中频通道号
*  输出参数   : g_cfrDssCarrMap: 载波频谱共享映射表（全局变量），大小为8X8，表中数值i若不为0，
                则表示载波i与该行号对应的载波频谱共享。
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : IC4.2 削峰只考虑 LTE 或 NR 两种载波的频谱共享。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张龙10281388@2023-06-30 20:09:05
*----------------------------------------------------------------------------
*/
UINT32 BspCfrInitCarrDssMap(UINT32 difChn)
{
    UINT32 retVal    = BSP_OK;
    UINT32 rowLoop   = 0;
    UINT32 colLoop   = 0;
    UINT32 freqBand  = 0;
    UINT32 sharedNum = 0;
    UINT32 index     = 0;
    UINT32 dssFlag   = CFR_CARR_NO_EXIST_DSS;
    T_CfrChnBandInfo *pChnInfo = NULL;

    pChnInfo = BspGetCfrChnInfo(difChn);
    if (pChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chn[%d] Info Error \n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    for (index = 0; index < pChnInfo->bandCarrNum[freqBand]; index++)
    {
        if (pChnInfo->carrInfo[freqBand][index].carrFlag == CFR_CARR_INVALID)
        {
            continue;
        }

        dbgInfo("[%s] difChn'%d, index'%d, carrNo'%d, radio'0x%x, carrBw'%d, centerFeq'%d\n",__FUNCTION__,difChn,index,pChnInfo->carrInfo[freqBand][index].carrNo,
                pChnInfo->carrInfo[freqBand][index].carrRadio,pChnInfo->carrInfo[freqBand][index].carrBw,pChnInfo->carrInfo[freqBand][index].freq);
    }

    /* 使用全局变量前先进行初始化 */
    //g_cfrChnDssFlag = CFR_CARR_NO_EXIST_DSS;

    for (rowLoop = 0; rowLoop < BSP_MAX_CARR_NUM; rowLoop++)
    {
        for (colLoop = 0; colLoop < BSP_MAX_CARR_NUM; colLoop++)
        {
            g_cfrDssCarrMap[rowLoop][colLoop] = CFR_CARR_NO_EXIST_DSS;
        }
    }

    for (rowLoop = 0; rowLoop < BSP_MAX_CARR_NUM; rowLoop++)
    {
        if (BspJudgeDSSCarrRadio(pChnInfo, freqBand, rowLoop) == BSP_OK)
        {
            continue;
        }

        sharedNum = 0;
        for (colLoop = rowLoop+1; colLoop < BSP_MAX_CARR_NUM; colLoop++)
        {
            if (BspJudgeDSSCarrRadio(pChnInfo, freqBand, colLoop) == BSP_OK)
            {
                continue;
            }

            retVal |= BspCfrCarrJudgeDss(difChn, freqBand, rowLoop, colLoop, pChnInfo, &dssFlag);
            if (CFR_CARR_EXIST_DSS == dssFlag)
            {
                g_cfrDssCarrMap[rowLoop][sharedNum++] = colLoop;
            }
        }
    }

    for (index = 0; index < BSP_MAX_CARR_NUM; index++)
    {
        dbgInfoEx("[%s] %d, %d, %d, %d, %d, %d, %d, %d. \n",__FUNCTION__,g_cfrDssCarrMap[index][0],g_cfrDssCarrMap[index][1],g_cfrDssCarrMap[index][2],
                g_cfrDssCarrMap[index][3],g_cfrDssCarrMap[index][4],g_cfrDssCarrMap[index][5],g_cfrDssCarrMap[index][6],g_cfrDssCarrMap[index][7]);
    }

    return dssFlag;
}

//获取通道DSS标志
UINT32 BspGetCfrChanDssFlag(UINT32 difChan)
{
    UINT32 freqBand = 0;
    UINT32 dssFlag = 0;
    UINT32 index    = 0;

    T_CfrChnBandInfo *pChnInfo = NULL;

    pChnInfo = BspGetCfrChnInfo(difChan);
    if (pChnInfo == NULL)
    {
        dbgInfo("[%s]Get Cfr Dif Chan[%d] Info Error \n", __FUNCTION__, difChan);
        return BSP_ERROR;
    }

    for (index = 0; index < pChnInfo->bandCarrNum[freqBand]; index++)
    {
        if (((RADIO_STANDARD_5G == pChnInfo->carrInfo[freqBand][index].carrRadio) || (RADIO_STANDARD_5G_RESERVED == pChnInfo->carrInfo[freqBand][index].carrRadio))
            && (pChnInfo->carrInfo[freqBand][index].carrBw > BANDWIDTH_30M))
        {
            dssFlag = BspCfrInitCarrDssMap(difChan);
            break;
        }
    }
}

/*解决powctrl\cfr 互相调用问题*/
UINT32 BspSetTssiPowInfoCallBackInit(FUN_GET_POWCTRL_TSSI_INFO pGetTssi)
{
    pGetTssiPowInfo = pGetTssi;
    return BSP_OK;
}

FUN_GET_POWCTRL_TSSI_INFO BspGetTssiPowInfoCallBackInit(void)
{
    return pGetTssiPowInfo;
}

UINT32 BspGetRefreshCfrCpgFlag(UINT32 bspChn, UINT32 *flag)
{
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgInfoEx("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    *flag = g_refreshCfrCpgFlag[bspChn];

    return BSP_OK;
}

UINT32 BspSetRefreshCfrCpgFlag(UINT32 bspChn, UINT32 flag)
{
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgInfoEx("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    g_refreshCfrCpgFlag[bspChn] = flag;

    return BSP_OK;
}

UINT32 BspRefreshCfrCpgTbl(UINT32 bspChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 cpgMode = 0;
    UINT32 difChn = 0;
    UINT32 chipidx = 0;

    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
    retVal |= BspCfrJudgeCpgMode(difChn, &cpgMode);

    if(cpgMode == CFR_CPG_CPU_CAL)
    {
        dbgInfoEx("[%s]: difChn'%d  cfr cpg will be refreshed using real power. \n", __FUNCTION__,difChn);
        retVal |= BspSetRefreshCfrCpgFlag(bspChn, BSP_POWSHARE_REFRESH_CPG_ACTIONING);
        retVal |= BspCfrSetCpgPara_CpuCal(bspChn);
        retVal |= BspSetRefreshCfrCpgFlag(bspChn, 0);
    }

    return retVal;
}

UINT32 BspJudgeCfrCpgRefreshCarrPow(UINT32 cpgCalcFlag, UINT32 powShareFlag, INT32 appPowMw, INT32 realPowMw, INT32 *carrPowMw)
{
    INPUT_POINTER_CHECK(carrPowMw);

    *carrPowMw = ((cpgCalcFlag != 0) && (powShareFlag != 0)) ? realPowMw : appPowMw;

    return BSP_OK;
}

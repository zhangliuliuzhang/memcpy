/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : cfrcommon.c
* 文件标识 : {[N/A]}
* 内容摘要 : cfr 模块公共功能具体实现接口
* 注意事项 : 无
* 作    者 : wangfei
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "bspcomm.h"
#include "bsppub.h"
#include "cfrcommon.h"
#include "funccommon.h"
#include "rruinfo.h"
#include "funccommon_ic_gsm.h"
#include "ichaladapt_ic4_2.h"
#include "freqcfgcommon.h"
#include "ichaladaptcfrapi.h"

/**************************************************************************
 *                         全局变量定义                                                                *
 **************************************************************************/
static UINT32      s_cfrTestMode         = 0;
static UINT32      s_cfrCarrFlag         = 0;
static UINT32      s_cfrFuncVerId        = 0;
static UINT32      s_cfrDifChnNUm        = 0;
static UINT32      s_cfrDifChnNUmPerChip = 0;
static T_CfrModule s_cfrModule           = {0};
static U_CFR_CFGPARA s_cfrCfgPara[CFR_CPGCAL_MAX];
static T_CfrChnBandInfo *s_pCfrChnInfo = NULL;

static pGetCfrRamAblity s_pGetCfrHwDefFunc = NULL;
static cfr_fsByDif      s_cfrFsByDif       = NULL;
static cfr_blockNoByDif   s_cfrBlockNoByDif  = NULL;


static UINT32 g_cfrRamCfgMode = CFR_CFG_MODE_NORMAL_SOURCE;

static UINT32 g_cfrGateCfgMode = CFR_CFG_MODE_GENERAL;

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define INPUT_CPGLEN_CHECK(cpglen)                                      \
        if (cpglen > s_cfrModule.cfrPara.cpg.lutLen)                    \
        {                                                               \
            return BSP_ERROR;                                           \
        }

#define INPUT_CPGMULRATE_CHECK(cpgtype)                                 \
        if (cpgtype >=CFR_CPG_RATE_MAXTYPE)                             \
        {                                                               \
            return BSP_ERROR;                                           \
        }

#define IC_CFR_CHN_MAX_NUM      8

#define CFR_COMMON_NULL_CHK(_ptr) if ((_ptr) == NULL) {dbgInfo("%s %d ptr is null!\n", __FUNCTION__, __LINE__);}

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
static T_BwBspToCfr s_bwInfo[] =
{
    /*LTE 带宽定义*/
    {BSP_RADIO_STANDARD_LTE_TDD, 5000 , E_CFR_BW_5M},
    {BSP_RADIO_STANDARD_LTE_TDD, 10000 , E_CFR_BW_10M},
    {BSP_RADIO_STANDARD_LTE_TDD, 15000 , E_CFR_BW_15M},
    {BSP_RADIO_STANDARD_LTE_TDD, 20000 , E_CFR_BW_20M},
    {BSP_RADIO_STANDARD_LTE_TDD, 40000 , E_CFR_BW_40M},
    {BSP_RADIO_STANDARD_LTE_TDD, 60000 , E_CFR_BW_60M},
    {BSP_RADIO_STANDARD_LTE_TDD, 80000 , E_CFR_BW_80M},
    {BSP_RADIO_STANDARD_LTE_TDD, 100000, E_CFR_BW_100M},
    {BSP_RADIO_STANDARD_LTE_TDD, 200000, E_CFR_BW_200M},
#if (1)
    {BSP_RADIO_STANDARD_5G_FDD_CPE, 5000  , E_CFR_BW_5M},
    {BSP_RADIO_STANDARD_5G_FDD_CPE, 10000 , E_CFR_BW_10M},
    {BSP_RADIO_STANDARD_5G_FDD_CPE, 15000 , E_CFR_BW_15M},
    {BSP_RADIO_STANDARD_5G_FDD_CPE, 20000 , E_CFR_BW_20M},

    {BSP_RADIO_STANDARD_5G, 5000  , E_CFR_BW_5M},
    {BSP_RADIO_STANDARD_5G, 10000 , E_CFR_BW_10M},
    {BSP_RADIO_STANDARD_5G, 15000 , E_CFR_BW_15M},
    {BSP_RADIO_STANDARD_5G, 20000 , E_CFR_BW_20M},
    {BSP_RADIO_STANDARD_5G, 30000 , E_CFR_BW_30M},
    {BSP_RADIO_STANDARD_5G, 40000 , E_CFR_BW_40M},
    {BSP_RADIO_STANDARD_5G, 50000 , E_CFR_BW_50M},
    {BSP_RADIO_STANDARD_5G, 60000 , E_CFR_BW_60M},
    {BSP_RADIO_STANDARD_5G, 70000 , E_CFR_BW_70M},
    {BSP_RADIO_STANDARD_5G, 80000 , E_CFR_BW_80M},
    {BSP_RADIO_STANDARD_5G, 90000 , E_CFR_BW_90M},
    {BSP_RADIO_STANDARD_5G, 100000, E_CFR_BW_100M},
    {BSP_RADIO_STANDARD_5G, 200000, E_CFR_BW_200M},
    {BSP_RADIO_STANDARD_5G, 400000, E_CFR_BW_400M},
    {BSP_RADIO_STANDARD_5G, 25000 , E_CFR_BW_25M},
    {BSP_RADIO_STANDARD_5G, 160000 , E_CFR_BW_160M},

    {BSP_RADIO_STANDARD_FDD_5G, 5000 ,  E_CFR_BW_5M},
    {BSP_RADIO_STANDARD_FDD_5G, 10000 , E_CFR_BW_10M},
    {BSP_RADIO_STANDARD_FDD_5G, 15000 , E_CFR_BW_FDD_5G_15M},
    {BSP_RADIO_STANDARD_FDD_5G, 20000 , E_CFR_BW_FDD_5G_20M},
    {BSP_RADIO_STANDARD_FDD_5G, 30000 , E_CFR_BW_FDD_5G_30M},
    {BSP_RADIO_STANDARD_FDD_5G, 40000 , E_CFR_BW_FDD_5G_40M},
    {BSP_RADIO_STANDARD_FDD_5G, 50000 , E_CFR_BW_FDD_5G_50M},
#endif
    {BSP_RADIO_STANDARD_LTE_FDD, 1400 , E_CFR_BW_LTE_1P4M},
    {BSP_RADIO_STANDARD_LTE_FDD, 3000 , E_CFR_BW_LTE_3M},
    {BSP_RADIO_STANDARD_LTE_FDD, 5000 , E_CFR_BW_LTE_5M},
    {BSP_RADIO_STANDARD_LTE_FDD, 10000, E_CFR_BW_LTE_10M},
    {BSP_RADIO_STANDARD_LTE_FDD, 15000, E_CFR_BW_LTE_15M},
    {BSP_RADIO_STANDARD_LTE_FDD, 20000, E_CFR_BW_LTE_20M},
    {BSP_RADIO_STANDARD_NB_IOT , 200  , E_CFR_BW_NBIOT},
    {BSP_RADIO_STANDARD_GSM    , CFR_BW_INVALID  , E_CFR_BW_GSM},

    /*LTE 非标带宽 */

    {BSP_RADIO_STANDARD_LTE_FDD, 4400, E_CFR_BW_4P4M},
    {BSP_RADIO_STANDARD_LTE_FDD, 4600, E_CFR_BW_4P6M},
    {BSP_RADIO_STANDARD_LTE_FDD, 4800, E_CFR_BW_4P8M},
    {BSP_RADIO_STANDARD_LTE_FDD, 7400, E_CFR_BW_7P4M},
    {BSP_RADIO_STANDARD_LTE_FDD, 7500, E_CFR_BW_7P5M},
    {BSP_RADIO_STANDARD_LTE_FDD, 8000, E_CFR_BW_8M},
    {BSP_RADIO_STANDARD_LTE_FDD, 8800, E_CFR_BW_8P8M},
    {BSP_RADIO_STANDARD_LTE_FDD, 9200, E_CFR_BW_9P2M},
    {BSP_RADIO_STANDARD_LTE_FDD, 9600, E_CFR_BW_9P6M},

    /*UMTS 带宽（含非标） */
    {BSP_RADIO_STANDARD_UMTS, 2600, E_CFR_BW_UTMS_2P6M},
    {BSP_RADIO_STANDARD_UMTS, 2800, E_CFR_BW_UTMS_2P8M},
    {BSP_RADIO_STANDARD_UMTS, 3000, E_CFR_BW_UTMS_3P0M},
    {BSP_RADIO_STANDARD_UMTS, 3200, E_CFR_BW_UTMS_3P2M},
    {BSP_RADIO_STANDARD_UMTS, 3400, E_CFR_BW_UTMS_3P4M},
    {BSP_RADIO_STANDARD_UMTS, 3600, E_CFR_BW_UTMS_3P6M},
    {BSP_RADIO_STANDARD_UMTS, 3800, E_CFR_BW_UTMS_3P8M},
    {BSP_RADIO_STANDARD_UMTS, 4000, E_CFR_BW_UTMS_4P0M},
    {BSP_RADIO_STANDARD_UMTS, 4200, E_CFR_BW_UTMS_4P2M},
    {BSP_RADIO_STANDARD_UMTS, 4400, E_CFR_BW_UTMS_4P4M},
    {BSP_RADIO_STANDARD_UMTS, 4600, E_CFR_BW_UTMS_4P6M},
    {BSP_RADIO_STANDARD_UMTS, 4800, E_CFR_BW_UTMS_4P8M},
    {BSP_RADIO_STANDARD_UMTS, 5000, E_CFR_BW_UTMS_5P0M},
};


/**************************************************************************
 *                         函数实现
 **************************************************************************/
/* R9224H 4*80W需求*/
UINT32 BspSetCfrCfgMode(UINT32 mode)
{
    g_cfrGateCfgMode = mode;
    return BSP_OK;
}

UINT32 BspGetCfrCfgMode(VOID)
{
    return g_cfrGateCfgMode;
}

pGetCfrRamAblity BspGetCfrHwDefCallBack(VOID)
{
   return s_pGetCfrHwDefFunc;
}

UINT32 BspCfrHwDefCallBackInit(pGetCfrRamAblity pCallBackFunc)
{
    s_pGetCfrHwDefFunc = pCallBackFunc;

   return BSP_OK;
}
static cfr_fsByDif BspGetCfrFsByDifBack(VOID)
{
   return s_cfrFsByDif;
}
UINT32 BspCfrFsByDifBackInit(cfr_fsByDif pCallBackFunc)
{
    s_cfrFsByDif = pCallBackFunc;

   return BSP_OK;
}
/**************************************************************************
* 函数名称: BspSetCfrCfgPara
* 功能描述: 配置cfr cpg 所需要的参数
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2017年05月09日   wangfei    创建
**************************************************************************/
UINT32 BspSetCfrCfgPara(UINT32 cfrId,VOID *pCfgPara, UINT32 cfgNum)
{
    if(cfrId >= CFR_CPGCAL_MAX)
    {
        return BSP_ERROR;
    }
    s_cfrCfgPara[cfrId].tVoidCfg.pCfgPara   = pCfgPara;
    s_cfrCfgPara[cfrId].tVoidCfg.cfgNum     = cfgNum;
    return BSP_OK;
}
/**************************************************************************
* 函数名称: BspGetCfrCfgPara
* 功能描述: 获取cfr cpg参数
* 输入参数: CFR 版本ID
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2017年05月09日   wangfei    创建
**************************************************************************/
U_CFR_CFGPARA *BspGetCfrCfgPara(UINT32 cfrId)
{
    if (cfrId >= CFR_CPGCAL_MAX)
    {
        dbgErr("%s>>Error! CfrId Over; CfrId(0~%d)= %d\n",
               __FUNCTION__, CFR_CPGCAL_MAX - 1, cfrId);
        return NULL;
    }

    return &s_cfrCfgPara[cfrId];
}

/****************************CFR 模块内部调用 **************************************/
/*****************************************************************************
*  函数名称   : BspCfrChnInfoInit
*  功能描述   : CFR 通道配置初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspCfrChnInfoInit(VOID)
{
    UINT32 difChnNum = 0;

    if (s_pCfrChnInfo != NULL)
    {
        return BSP_OK;
    }

    difChnNum  = BspGetCfrDifChnNum();
    s_pCfrChnInfo = (T_CfrChnBandInfo *)malloc(sizeof(T_CfrChnBandInfo) * difChnNum);
    if (s_pCfrChnInfo == NULL)
    {
        dbgInfo("[%s]Cfr Chn malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(s_pCfrChnInfo, 0, sizeof(T_CfrChnBandInfo) * difChnNum);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetCfrDifChnNum
*  功能描述   : 设置cfr通道数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cfrDifChnNum
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrDifChnNum(UINT32 cfrDifChnNum)
{
    s_cfrDifChnNUm = cfrDifChnNum;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCfrModuleInfo
*  功能描述   : 获取cfr通道数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrDifChnNum(VOID)
{
    return s_cfrDifChnNUm;
}
/*****************************************************************************
*  函数名称   : BspSetCfrDifChnNumPerChip
*  功能描述   : 设置一片FPGA 支持的cfr通道数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cfrDifChnNum
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrDifChnNumPerChip(UINT32 cfrDifChnNum)
{
    s_cfrDifChnNUmPerChip = cfrDifChnNum;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCfrDifChnNumPerChip
*  功能描述   : 获取一片FPGA 支持的cfr通道数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrDifChnNumPerChip(VOID)
{
    return s_cfrDifChnNUmPerChip;
}

/*****************************************************************************
*  函数名称   : BspCfrFuncMemApply
*  功能描述   : CFR 削峰参数空间初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspCfrFuncMemApply(VOID)
{
    UINT32 difChnNum    = 0;
    /* UINT32 retVal       = BSP_OK; */

    difChnNum   = BspGetCfrDifChnNum();

    if(s_cfrModule.cfrPara.pGate != NULL)
    {
        return BSP_OK;
    }
    if(s_cfrModule.cfrPara.pWin != NULL)
    {
        return BSP_OK;
    }
    if(s_cfrModule.cfrPara.pDelt != NULL)
    {
        return BSP_OK;
    }
    s_cfrModule.cfrPara.pGate = (T_CfrThrInfo *)malloc(sizeof(T_CfrThrInfo) * difChnNum);
    CFR_COMMON_NULL_CHK(s_cfrModule.cfrPara.pGate);
    s_cfrModule.cfrPara.pWin  = (T_CfrThrInfo *)malloc(sizeof(T_CfrThrInfo) * difChnNum);
    CFR_COMMON_NULL_CHK(s_cfrModule.cfrPara.pWin);
    s_cfrModule.cfrPara.pDelt = (T_CfrThrInfo *)malloc(sizeof(T_CfrThrInfo) * difChnNum);
    CFR_COMMON_NULL_CHK(s_cfrModule.cfrPara.pDelt);

    if (s_cfrModule.cfrPara.pGate == NULL)
    {
        free(s_cfrModule.cfrPara.pWin);
        free(s_cfrModule.cfrPara.pDelt);
        s_cfrModule.cfrPara.pWin    = NULL;
        s_cfrModule.cfrPara.pDelt   = NULL;
        s_cfrModule.initFlag = CFR_FUNC_NOT_INIT;
        dbgInfo("[%s]Cfr Gate malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (s_cfrModule.cfrPara.pWin == NULL)
    {
        free(s_cfrModule.cfrPara.pGate);
        free(s_cfrModule.cfrPara.pDelt);
        s_cfrModule.cfrPara.pGate   = NULL;
        s_cfrModule.cfrPara.pDelt   = NULL;
        s_cfrModule.initFlag = CFR_FUNC_NOT_INIT;
        dbgInfo("[%s]Cfr Win malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (s_cfrModule.cfrPara.pDelt == NULL)
    {
        free(s_cfrModule.cfrPara.pWin);
        free(s_cfrModule.cfrPara.pGate);
        s_cfrModule.cfrPara.pWin    = NULL;
        s_cfrModule.cfrPara.pGate   = NULL;
        s_cfrModule.initFlag = CFR_FUNC_NOT_INIT;
        dbgInfo("[%s]Cfr Delt malloc fail \n", __FUNCTION__);
        return BSP_ERROR;
    }

    s_cfrModule.initFlag = CFR_FUNC_INIT;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspCfrFuncMmeInfoInit
*  功能描述   : CFR 所需要空间初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrFuncMemInfoInit(VOID)
{
    UINT32 ret = BSP_OK;

    ret |= BspCfrFuncMemApply();
    ret |= BspCfrChnInfoInit();

    return ret;
}

/*****************************************************************************
*  函数名称   : BspGetCfrModuleInfo
*  功能描述   : CFR 模块功能信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
T_CfrModule* BspGetCfrModuleInfo(VOID)
{
    return &(s_cfrModule);
}

/*****************************************************************************
*  函数名称   : BspGetCfrFuncFlag
*  功能描述   : 获取CFR初始化标记
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrFuncFlag(VOID)
{
    return s_cfrModule.initFlag;
}
/*****************************************************************************
*  函数名称   : BspGetCfrChnInfo
*  功能描述   : CFR 通道配置信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChn   - cfr 中频通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
T_CfrChnBandInfo *BspGetCfrChnInfo(UINT32 difChn)
{
    if (difChn >= BspGetCfrDifChnNum())
    {
        dbgErr("%s>>Error! Param Over; difCh(0~%d)= %d\n", __FUNCTION__,
               BspGetCfrDifChnNum() - 1, difChn);
        return NULL;
    }

    if (NULL == s_pCfrChnInfo)
    {
        dbgErr("%s>>Error! pCfrChnInfo cannot NULL!\n", __FUNCTION__);
        return NULL;
    }

    return &(s_pCfrChnInfo[difChn]);
}

/*****************************************************************************
*  函数名称   : BspSetCfrCpgCoef
*  功能描述   : CFR Cpg表格系数参数初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrCpgCoef(UINT32 cfrBw,const UINT32 *pfrCpgCoef, UINT32 len)
{
    INPUT_POINTER_CHECK(pfrCpgCoef);
    INPUT_CPGLEN_CHECK(len);
    s_cfrModule.cfrPara.cpg.para[cfrBw].cfrBw       = cfrBw;
    s_cfrModule.cfrPara.cpg.para[cfrBw].pCoefPara   = pfrCpgCoef;
    s_cfrModule.cfrPara.cpg.para[cfrBw].coefLen     = len;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrCpgCoef
*  功能描述   : 获取CFRCPG 系数
*  读全局变量 : 无
*  写全局变量 : 无
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrCpgCoef(UINT32 cfrBw, T_CfrCpgPara *pCpgPara)
{
    /* UINT32 ret  = BSP_OK; */
    /* UINT32 ulLoop = 0; */
    INPUT_POINTER_CHECK(pCpgPara);

    if (cfrBw == s_cfrModule.cfrPara.cpg.para[cfrBw].cfrBw)
    {
        pCpgPara->pCoefPara = s_cfrModule.cfrPara.cpg.para[cfrBw].pCoefPara;
        pCpgPara->cfrBw     = s_cfrModule.cfrPara.cpg.para[cfrBw].cfrBw;
        pCpgPara->coefLen   = s_cfrModule.cfrPara.cpg.para[cfrBw].coefLen;
        dbgInfo("[%s]Get CfrBw[%d] Cpg Para OK!\n", __FUNCTION__, cfrBw);
        return BSP_OK;
    }

    dbgInfo("[%s]Get CfrBw[%d] Cpg Para Error!\n", __FUNCTION__, cfrBw);
    return BSP_ERROR;
}

static cfr_blockNoByDif BspGetBlockNoByDifBack(VOID)
{
    return s_cfrBlockNoByDif;
}
UINT32 BspGetBlockNoByDifBackInit(cfr_blockNoByDif pCallBackFunc)
{
    s_cfrBlockNoByDif = pCallBackFunc;

    return BSP_OK;
}

UINT32 BspGetCfrBlockNoByDifChn(UINT32 difChn,UINT32 *pCfrBlock)
{
    UINT32 retVal = BSP_OK;
    UINT32 cfrBlock = 0;

    INPUT_POINTER_CHECK(pCfrBlock);
    cfr_blockNoByDif pCfrBlockNoByDif = NULL;
    pCfrBlockNoByDif = BspGetBlockNoByDifBack();
    if(pCfrBlockNoByDif == NULL)
    {
        cfrBlock = (difChn<IC_CFR_CHN_MAX_NUM)?0:1;
        *pCfrBlock = cfrBlock;
        dbgInfo("%s>>difChn'%d configure default cfr BlockNo'%d !\n",__FUNCTION__,difChn,cfrBlock);
        return retVal;
    }
    return pCfrBlockNoByDif(difChn,pCfrBlock);
}

/*****************************************************************************
*  函数名称   : BspSetCfrCpgCoef
*  功能描述   : CFR Cpg表格系数参数初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrCpgMulRateCoef(UINT32 cfrBw,const UINT32 *pfrCpgCoef, UINT32 len,UINT32 rate,UINT32 rateIdx,UINT32 vaildLen)
{
    INPUT_POINTER_CHECK(pfrCpgCoef);
    INPUT_CPGLEN_CHECK(len);
    INPUT_CPGMULRATE_CHECK(rateIdx);
    s_cfrModule.cfrPara.cpgMulRate[rateIdx].para[cfrBw].cfrBw       = cfrBw;
    s_cfrModule.cfrPara.cpgMulRate[rateIdx].para[cfrBw].pCoefPara   = pfrCpgCoef;
    s_cfrModule.cfrPara.cpgMulRate[rateIdx].para[cfrBw].coefLen     = len;
    s_cfrModule.cfrPara.cpgMulRate[rateIdx].para[cfrBw].cpgRate     = rate;
    s_cfrModule.cfrPara.cpgMulRate[rateIdx].para[cfrBw].vaildLen    = vaildLen;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrCpgCoef
*  功能描述   : 获取CFRCPG 系数
*  读全局变量 : 无
*  写全局变量 : 无
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
#ifdef DPDIC3_R8998G
UINT32 BspGetCfrCpgMulRateCoef(UINT32 cfrBw,UINT32 rate,T_CfrCpgPara *pCpgPara)
{
    /* UINT32 ret          = BSP_OK; */
    UINT32 ulLoop       = 0;
    /* UINT32 cfrBwV       = 0; */
    UINT32 cfrCpgRate   = 0;
    cfrCpgRate = rate;
    INPUT_POINTER_CHECK(pCpgPara);
    dbgInfoEx("%s: cfrCpgRate: %d\n", __FUNCTION__, cfrCpgRate);
    if(cfrBw>=(UINT32)E_CFR_RADIO_BW_MAX)
    {
        return BSP_ERROR;
    }
    for(ulLoop = 0;ulLoop <CFR_CPG_RATE_MAXTYPE;ulLoop ++ )
    {
        if ((s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cfrBw == cfrBw)&&(s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cpgRate ==rate ))
        {
            pCpgPara->pCoefPara = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].pCoefPara;
            pCpgPara->cfrBw     = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cfrBw;
            pCpgPara->coefLen   = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].coefLen;
            pCpgPara->cpgRate   = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cpgRate;
            pCpgPara->vaildLen  = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].vaildLen;
            dbgInfo("[%s]Get CfrBw[%d] Cpg Para OK!\n", __FUNCTION__, cfrBw);
            return BSP_OK;
        }
    }
    dbgInfo("[%s]Get CfrBw[%d] Cpg Para Error!\n", __FUNCTION__, cfrBw);
    return BSP_ERROR;
}
#else
UINT32 BspGetCfrCpgMulRateCoef(UINT32 difChn,UINT32 cfrBw,UINT32 rate,T_CfrCpgPara *pCpgPara)
{
    /* UINT32 ret          = BSP_OK; */
    UINT32 ulLoop         = 0;
    /* UINT32 cfrBwV          = 0; */
    //UINT32 cfrCpgRate     = 0;
    UINT32 cfrBlock = 0;

    //IcHalGetCfrBlockNoByDifChn(difChn,&cfrBlock);
    BspGetCfrBlockNoByDifChn(difChn,&cfrBlock);
    ulLoop = (cfrBlock<CFR_CPG_RATE_MAXTYPE)?cfrBlock:1;
    dbgInfo("%s>> difChn'%d, cfrBlock'%d, ulLoop'%d\n",__FUNCTION__,difChn,cfrBlock,ulLoop);

    //cfrCpgRate = rate;
    INPUT_POINTER_CHECK(pCpgPara);
    if (cfrBw >= E_CFR_RADIO_BW_MAX)
    {
        dbgErr("%s cfrBw'%d overload!\n", __FUNCTION__, cfrBw);
        return BSP_ERROR;
    }

    //按区分cpg速率修改
    //for(ulLoop = 0;ulLoop <CFR_CPG_RATE_MAXTYPE;ulLoop ++ )
    {
        if ((s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cfrBw == cfrBw)&&(s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cpgRate ==rate ))
        {
            pCpgPara->pCoefPara = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].pCoefPara;
            pCpgPara->cfrBw     = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cfrBw;
            pCpgPara->coefLen   = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].coefLen;
            pCpgPara->cpgRate   = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].cpgRate;
            pCpgPara->vaildLen  = s_cfrModule.cfrPara.cpgMulRate[ulLoop].para[cfrBw].vaildLen;
            dbgInfo("[%s]Get CfrBw[%d] Cpg Para OK!\n", __FUNCTION__, cfrBw);
            return BSP_OK;
        }
    }
    dbgInfo("[%s]Get CfrBw[%d] Cpg Para Error!\n", __FUNCTION__, cfrBw);
    return BSP_ERROR;
}
#endif
/*****************************************************************************
*  函数名称   : BspSetCfrLutLen
*  功能描述   : CFR Lut 长度
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrLutLen(UINT32 lutLen)
{
    s_cfrModule.cfrPara.cpg.lutLen = lutLen;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrLutLen
*  功能描述   : CFR Lut 长度
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrLutLen(UINT32 *pLutLen)
{
    INPUT_POINTER_CHECK(pLutLen);
    *pLutLen = s_cfrModule.cfrPara.cpg.lutLen;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetCfrCpgMode
*  功能描述   : CFR CPG 模式
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrCpgMode(UINT32 cpgMode)
{
    s_cfrModule.cfrPara.cpg.calMode = cpgMode;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrRamDepth
*  功能描述   : CFR CPG 模式
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrCpgMode(UINT32 *pCpgMode)
{
    INPUT_POINTER_CHECK(pCpgMode);
    *pCpgMode = s_cfrModule.cfrPara.cpg.calMode;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetCfrSampleRate
*  功能描述   : CFR fss 61.44/92.16,122.88,491.52
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cfrFs   61.44/92.16,122.88,491.52
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrFs(UINT32 cfrFs)
{
    s_cfrModule.cfrFs = cfrFs;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetCfrSampleRate
*  功能描述   : CFR fss 61.44/92.16,122.88,491.52
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cfrFs   61.44/92.16,122.88,491.52
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrFs(UINT32 *pCfrFs)
{
    UINT32 ulCfrFs = 0;
    UINT32 ulFuncRet = BSP_OK;

//  INPUT_POINTER_CHECK(pCfrFs);
    ulCfrFs = s_cfrModule.cfrFs;

    if (NULL != pCfrFs)
    {
        *pCfrFs = ulCfrFs;
    }
    else
    {
        ulFuncRet = ERROR_NULL_POINTER;
        dbgInfo("%s>>GetCfrFs= %d\n", __FUNCTION__, ulCfrFs);
    }

    return ulFuncRet;
}
/*****************************************************************************
*  函数名称   : BspSetCfrSampleRate
*  功能描述   : CFR fss 61.44/92.16,122.88,491.52
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cfrFs   61.44/92.16,122.88,491.52
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrFsByDifChn(UINT32 difChn,UINT32 *pCfrFs)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pCfrFs);
    cfr_fsByDif pCfrFsByDif = NULL;
    pCfrFsByDif = BspGetCfrFsByDifBack();
    if(pCfrFsByDif == NULL)
    {
        retVal |= BspGetCfrFs(pCfrFs);
        return retVal;
    }
    return pCfrFsByDif(difChn,pCfrFs);
}
/*****************************************************************************
*  函数名称   : BspSetCfrPos
*  功能描述   : CFR Pos
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 1 CFR在NCO后  2 CFR在NCO之前
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrPos(UINT32 cfrPos)
{
    s_cfrModule.cfrPos = cfrPos;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCfrPos
*  功能描述   : 1 CFR在NCO后  2 CFR在NCO之前
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 1 CFR在NCO后  2 CFR在NCO之前
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrPos(UINT32 *pcfrPos)
{
    UINT32 ulCfrPos = 0;
    UINT32 ulFuncRet = BSP_OK;

//  INPUT_POINTER_CHECK(pcfrPos);
    ulCfrPos = s_cfrModule.cfrPos;

    if (NULL != pcfrPos)
    {
        *pcfrPos = ulCfrPos;
    }
    else
    {
        ulFuncRet = ERROR_NULL_POINTER;
        dbgInfo("%s>>GetCfrPos= %d\n", __FUNCTION__, ulCfrPos);
    }

    return ulFuncRet;
}

/*****************************************************************************
*  函数名称   : BspSetCfrGatePara
*  功能描述   : 设置CFR 削峰门限参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrGatePara(UINT32 difChan, UINT32 *pCfrGate)
{
    INPUT_POINTER_CHECK(pCfrGate);
    INPUT_DIFCHAN_CHECK(difChan);
//    if(SUPPORT_GSM == BspGetSupportGsmFlag(difChan))
//    {
//        return BspSetCfrGatePara_Gsm(difChan);
//    }
    s_cfrModule.cfrPara.pGate[difChan].thrStage[E_CFR_THR_1ST] = pCfrGate[E_CFR_THR_1ST];
    s_cfrModule.cfrPara.pGate[difChan].thrStage[E_CFR_THR_2ND] = pCfrGate[E_CFR_THR_2ND];
    s_cfrModule.cfrPara.pGate[difChan].thrStage[E_CFR_THR_3RD] = pCfrGate[E_CFR_THR_3RD];
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrGatePara
*  功能描述   : 获取CFR 削峰门限参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : lCfrHbfCoef   - 表格系数
*             : ulLength      - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrGatePara(UINT32 difChan, UINT32 *pCfrGate)
{
    INPUT_POINTER_CHECK(pCfrGate);
    INPUT_DIFCHAN_CHECK(difChan);
    pCfrGate[E_CFR_THR_1ST]  =  s_cfrModule.cfrPara.pGate[difChan].thrStage[E_CFR_THR_1ST];
    pCfrGate[E_CFR_THR_2ND]  =  s_cfrModule.cfrPara.pGate[difChan].thrStage[E_CFR_THR_2ND];
    pCfrGate[E_CFR_THR_3RD]  =  s_cfrModule.cfrPara.pGate[difChan].thrStage[E_CFR_THR_3RD];
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetCfrWinPara
*  功能描述   : 设置CFR 削峰窗长参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : lCfrHbfCoef   - 表格系数
*             : ulLength      - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrWinPara(UINT32 difChan, UINT32 *pCfrWin)
{
    INPUT_POINTER_CHECK(pCfrWin);
    INPUT_DIFCHAN_CHECK(difChan);
    s_cfrModule.cfrPara.pWin[difChan].thrStage[E_CFR_THR_1ST] = pCfrWin[E_CFR_THR_1ST];
    s_cfrModule.cfrPara.pWin[difChan].thrStage[E_CFR_THR_2ND] = pCfrWin[E_CFR_THR_2ND];
    s_cfrModule.cfrPara.pWin[difChan].thrStage[E_CFR_THR_3RD] = pCfrWin[E_CFR_THR_3RD];
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrWinPara
*  功能描述   : 获取CFR 削峰窗长门限参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : lCfrHbfCoef   - 表格系数
*             : ulLength      - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrWinPara(UINT32 difChan, UINT32 *pCfrWin)
{
    INPUT_POINTER_CHECK(pCfrWin);
    INPUT_DIFCHAN_CHECK(difChan);
    pCfrWin[E_CFR_THR_1ST]  =  s_cfrModule.cfrPara.pWin[difChan].thrStage[E_CFR_THR_1ST];
    pCfrWin[E_CFR_THR_2ND]  =  s_cfrModule.cfrPara.pWin[difChan].thrStage[E_CFR_THR_2ND];
    pCfrWin[E_CFR_THR_3RD]  =  s_cfrModule.cfrPara.pWin[difChan].thrStage[E_CFR_THR_3RD];
    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BspSetCfrWinLevelPara
*  功能描述   : 设置CFR 削峰窗长级数参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrWinLevelPara(UINT32 difChan, UINT32 *pCfrWinLevel)
{
    INPUT_POINTER_CHECK(pCfrWinLevel);
    INPUT_DIFCHAN_CHECK(difChan);
    s_cfrModule.cfrPara.pWinLevel[difChan].thrStage[E_CFR_THR_1ST] = pCfrWinLevel[E_CFR_THR_1ST];
    s_cfrModule.cfrPara.pWinLevel[difChan].thrStage[E_CFR_THR_2ND] = pCfrWinLevel[E_CFR_THR_2ND];
    s_cfrModule.cfrPara.pWinLevel[difChan].thrStage[E_CFR_THR_3RD] = pCfrWinLevel[E_CFR_THR_3RD];
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrWinLevelPara
*  功能描述   : 获取CFR 削峰窗长门限参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : lCfrHbfCoef   - 表格系数
*             : ulLength      - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrWinLevelPara(UINT32 difChan, UINT32 *pCfrWinLevel)
{
    INPUT_POINTER_CHECK(pCfrWinLevel);
    INPUT_DIFCHAN_CHECK(difChan);
    pCfrWinLevel[E_CFR_THR_1ST]  =  s_cfrModule.cfrPara.pWinLevel[difChan].thrStage[E_CFR_THR_1ST];
    pCfrWinLevel[E_CFR_THR_2ND]  =  s_cfrModule.cfrPara.pWinLevel[difChan].thrStage[E_CFR_THR_2ND];
    pCfrWinLevel[E_CFR_THR_3RD]  =  s_cfrModule.cfrPara.pWinLevel[difChan].thrStage[E_CFR_THR_3RD];
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetCfrDeltPara
*  功能描述   : 设置CFR 削峰检测门限参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrDeltPara(UINT32 difChan, UINT32 *pCfrDelt)
{
    INPUT_POINTER_CHECK(pCfrDelt);
    INPUT_DIFCHAN_CHECK(difChan);
    s_cfrModule.cfrPara.pDelt[difChan].thrStage[E_CFR_THR_1ST] = pCfrDelt[E_CFR_THR_1ST];
    s_cfrModule.cfrPara.pDelt[difChan].thrStage[E_CFR_THR_2ND] = pCfrDelt[E_CFR_THR_2ND];
    s_cfrModule.cfrPara.pDelt[difChan].thrStage[E_CFR_THR_3RD] = pCfrDelt[E_CFR_THR_3RD];
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrDeltPara
*  功能描述   : 获取CFR 削峰检测门限参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrDeltPara(UINT32 difChan, UINT32 *pCfrDelt)
{
    INPUT_POINTER_CHECK(pCfrDelt);
    INPUT_DIFCHAN_CHECK(difChan);
    pCfrDelt[E_CFR_THR_1ST]  =  s_cfrModule.cfrPara.pDelt[difChan].thrStage[E_CFR_THR_1ST];
    pCfrDelt[E_CFR_THR_2ND]  =  s_cfrModule.cfrPara.pDelt[difChan].thrStage[E_CFR_THR_2ND];
    pCfrDelt[E_CFR_THR_3RD]  =  s_cfrModule.cfrPara.pDelt[difChan].thrStage[E_CFR_THR_3RD];
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetCfrNoisePara
*  功能描述   : 设置CFR 削峰噪声参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrNoisePara(UINT32 difChan, UINT32 *pCfrNoise)
{
    INPUT_POINTER_CHECK(pCfrNoise);
    INPUT_DIFCHAN_CHECK(difChan);
    s_cfrModule.cfrPara.pNoise[difChan].thrStage[E_CFR_THR_1ST] = pCfrNoise[E_CFR_THR_1ST];
    s_cfrModule.cfrPara.pNoise[difChan].thrStage[E_CFR_THR_2ND] = pCfrNoise[E_CFR_THR_2ND];
    s_cfrModule.cfrPara.pNoise[difChan].thrStage[E_CFR_THR_3RD] = pCfrNoise[E_CFR_THR_3RD];
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrDeltPara
*  功能描述   : 获取CFR 削峰检测门限参数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrNoisePara(UINT32 difChan, UINT32 *pCfrNoise)
{
    INPUT_POINTER_CHECK(pCfrNoise);
    INPUT_DIFCHAN_CHECK(difChan);
    pCfrNoise[E_CFR_THR_1ST]  =  s_cfrModule.cfrPara.pNoise[difChan].thrStage[E_CFR_THR_1ST];
    pCfrNoise[E_CFR_THR_2ND]  =  s_cfrModule.cfrPara.pNoise[difChan].thrStage[E_CFR_THR_2ND];
    pCfrNoise[E_CFR_THR_3RD]  =  s_cfrModule.cfrPara.pNoise[difChan].thrStage[E_CFR_THR_3RD];
    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BspGetCfrRadioBwFromBspBw
*  功能描述   : 获取cfrBw
*  读全局变量 : 无
*  写全局变量 : 无
*             : ulDifChan     - 中频通道号
*  输出参数   : 无
*  返 回 值   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrRadioBwFromBspBw(UINT32 radioMode, UINT32 bspBw, UINT32 *pCfrRadioBw)
{
    /* UINT32 ret  = BSP_OK; */
    UINT32 size = 0;
    UINT32 loop = 0;
    size = sizeof(s_bwInfo) / sizeof(s_bwInfo[0]);

    for (loop = 0; loop < size; loop ++)
    {
        if (radioMode == s_bwInfo[loop].radioMode)
        {
            if ((s_bwInfo[loop].bspBw == bspBw)||(s_bwInfo[loop].bspBw == CFR_BW_INVALID))
            {
                *pCfrRadioBw = s_bwInfo[loop].cfrBw;
                return BSP_OK;
            }
        }
    }

    dbgErr("%s>>RadioMode'%d BspBwKHz'%d GetCfrRadioBwFromBspBw Error!\n",
           __FUNCTION__, radioMode, bspBw);
    return BSP_ERROR;
}
/*****************************************************************************
*  函数名称   : BspGetBspBwFromCfrBw
*  功能描述   : 获取BspBw
*  读全局变量 : 无
*  写全局变量 : 无
*             : ulDifChan     - 中频通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetBspBwFromCfrBw(UINT32 radioMode, UINT32 cfrBw, UINT32 *pBspBw)
{
    /* UINT32 ret  = BSP_OK; */
    UINT32 size = 0;
    UINT32 loop = 0;
    size = sizeof(s_bwInfo) / sizeof(s_bwInfo[0]);

    for (loop = 0; loop < size; loop ++)
    {
        if (radioMode == s_bwInfo[loop].radioMode)
        {
            if (s_bwInfo[loop].cfrBw == cfrBw)
            {
                *pBspBw = s_bwInfo[loop].bspBw;
                return BSP_OK;
            }
        }
    }
    *pBspBw = 0;
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspSetCfrFuncVerId
*  功能描述   : 获取BspBw
*  读全局变量 : 无
*  写全局变量 : 无
*             : ulDifChan     - 中频通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 方案参考岳亮< R885X CFR&DPD 参数配置方案>
                <DPDIC 削峰模块BSP配置需求V1.2>
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrFuncVerId(UINT32 cfrFuncVerId)
{
    s_cfrFuncVerId = cfrFuncVerId;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCfrFuncVerId
*  功能描述   : 获取BspBw
*  读全局变量 : 无
*  写全局变量 : 无
*             : ulDifChan     - 中频通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 方案参考岳亮< R885X CFR&DPD 参数配置方案>
                <DPDIC 削峰模块BSP配置需求V1.2>
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrFuncVerId(VOID)
{
    return s_cfrFuncVerId;
}

/*****************************************************************************
*  函数名称   : BspCfrPowDbfs
*  功能描述   : cfr dbfs 转换
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrPowDbfs(UINT32 rfChn, UINT32 powr, UINT32 ulFullBit, INT32 *lpDbfs)
{
    UINT32 retVal        = 0;
    INT32 lDbfsValue     = 0;
    /* INT32 lDbFullScal    = 0;
    double dTemp         = 0.0; */
    UINT32 ratedPower    = 0;
    INPUT_POINTER_CHECK(lpDbfs);

    if(powr == 0)/*powr 功率为0 dbfs默认-200dbfs*/
    {
        *lpDbfs = -20000;
        dbgInfo("[%s]cfr powr is zeor! dbfs is default -200dbfs \n",__FUNCTION__);
        return BSP_OK;
    }
    retVal  = BspGetRruPathRatedPower(rfChn, &ratedPower);
    dbgInfoEx("%s: retVal: %d\n", __FUNCTION__, retVal);
    if(ratedPower == 0)
    {
        dbgInfo("[%s]ratedPower powr is zeor! dbfs is default -200dbfs \n",__FUNCTION__);
        *lpDbfs = -20000;
        return BSP_OK;
    }
    /*配置功率CFR dbfs计算公式 吴丹伟提供*/
    lDbfsValue = CFR_CALI_DBFS_VAL_DEF + 1000.0 *  log10((double)powr / ratedPower);
    *lpDbfs = lDbfsValue;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetCfrChnInfo
*  功能描述   : 配置削峰通道信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrChnInfo(UINT32 difChn, T_CfrChnBandInfo *pCfrChnCarrInfo)
{
    /* UINT32 retVal                           = BSP_OK;
    UINT32 carrLoop                         = 0;
    UINT32 cfrBand                          = 0;
    UINT32 cfrBandLoop                      = 0;  */
    /* INT32  cfrPowDbfs                       = 0;  */ /*载波dbfs*/
    /* UINT32 cfrBandCarrNum[E_CFR_BAND_MAX]   = {0}; *//* 频段内的载波数*/
    /* UINT32 cfrBandNum                       = 0;  */ /* 通道的频段数 ,目前暂时按照一个频段配置*/
    T_CfrChnBandInfo *pCfrChnInfo           = NULL;

    INPUT_DIFCHAN_CHECK(difChn);
    INPUT_POINTER_CHECK(pCfrChnCarrInfo);

    pCfrChnInfo = BspGetCfrChnInfo(difChn);
    if (NULL == pCfrChnInfo)
    {
        dbgErr("%s>>Error! difChnl'%d pCfrChnlInfo cannot NULL\n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    memset((VOID *)pCfrChnInfo, 0, sizeof(T_CfrChnBandInfo));
    memcpy((VOID *)pCfrChnInfo, pCfrChnCarrInfo, sizeof(T_CfrChnBandInfo));

    dbgInfoEx("%s>>DifChnl'%d Carr'%d Radio'%d GetChnlInfo OK! CarrPowMv'%d PowDbfs'%d\n",
              __FUNCTION__, difChn, pCfrChnInfo->carrInfo[0][0].carrNo,
              pCfrChnInfo->carrInfo[0][0].carrRadio,
              pCfrChnInfo->carrInfo[0][0].powerMw,
              pCfrChnInfo->carrInfo[0][0].powDbfs);
    return BSP_OK;
}
PFGetCfrCarrPow* pFGetCfrCarrPowCfg = NULL;

UINT32 BspSetCfrCarrPowCfgFunc(PFGetCfrCarrPow pFunc)
{
    pFGetCfrCarrPowCfg = pFunc;
    return BSP_OK;
}

UINT32 BspSetCfrCarrFlag(UINT32 cfrCarrFlag)
{
    s_cfrCarrFlag = cfrCarrFlag;
    return BSP_OK;
}
static UINT32 BspGetCfrCarrFlag(VOID)
{
    return s_cfrCarrFlag;
}
/*****************************************************************************
*  函数名称   : BspCfrChnInfoUpdate
*  功能描述   : 配置削峰通道配置信息更新
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrChnInfoUpdate(UINT32 rfChn)
{
    UINT32 retVal   = BSP_OK;
    UINT32 carrLoop = 0;
    UINT32 chipidx  = 0;
    UINT32 difChn   = 0;
    UINT32 difchnQtyPerChip = 0;
    UINT32 bandLoop = 0;
    UINT32 cfrBandNum = 0;
    UINT32 cfrBandCarrNum = 0;
    INT32  powDbfs    = 0;
    UINT32 powMv      = 0;
    T_RruBandCfgInfo *pRruRfCfgInfo = NULL;
    T_CfrChnBandInfo  pCfrChnInfo   = {0};

    pRruRfCfgInfo = malloc(sizeof(T_RruBandCfgInfo));
    if (NULL == pRruRfCfgInfo)
    {
        dbgErr("[%s]RfChn %d RfCfgInfoMalloc Error!\n", __FUNCTION__, rfChn);
        return BSP_ERROR;
    }
    memset(pRruRfCfgInfo, 0, sizeof(T_RruBandCfgInfo));

    retVal = BspGetRruTxDifCfgPara(rfChn, pRruRfCfgInfo);
    if(retVal != BSP_OK)
    {
        free(pRruRfCfgInfo);
        dbgErr("[%s]RfChn %d Cfr Chn Info Update Error!\n",__FUNCTION__,rfChn);
        return BSP_ERROR;
    }

    pCfrChnInfo.centerFreq = pRruRfCfgInfo->loFreq;
    for(bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if(pRruRfCfgInfo->info[bandLoop].bandfreq == 0)
        {
            pCfrChnInfo.usedFlag[bandLoop] = CFR_BAND_NOT_USED;
            continue;
        }
        cfrBandNum ++;
        cfrBandCarrNum = 0;
        pCfrChnInfo.bandFreq[bandLoop] = pRruRfCfgInfo->info[bandLoop].bandfreq;
        pCfrChnInfo.usedFlag[bandLoop] = CFR_BAND_USED;
        pCfrChnInfo.bandNum            = cfrBandNum;
        for(carrLoop = 0 ;carrLoop < BSP_MAX_CARR_NUM;carrLoop ++)
        {
            if(pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrFreq == 0)
            {
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrFlag   = CFR_CARR_INVALID;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrNo;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio  = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrRadio;
            }
            else
            {
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrFlag   = CFR_CARR_VALID;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrNo;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio  = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrRadio;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].freq       = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrFreq;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrBw     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrBw;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrFi     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrNco;
                if(NULL == pFGetCfrCarrPowCfg||BspGetCfrCarrInfoFlag())
                {
                        BspGetCarrPowCfg(rfChn,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio, &powMv);
                }
                else
                {
                       pFGetCfrCarrPowCfg(rfChn,bandLoop,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrBw, &powMv);
                }
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].powerMw    = powMv;
                BspCfrPowDbfs(rfChn, pCfrChnInfo.carrInfo[bandLoop][carrLoop].powerMw, 16, &powDbfs);
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].powDbfs      = powDbfs;
                dbgInfoEx("%s>>RfChnl'%d Carr'%d Radio'%d: CarrPowMv= %d, PowDbfs= %d\n", __FUNCTION__,
                          rfChn, pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo,
                          pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio,
                          pCfrChnInfo.carrInfo[bandLoop][carrLoop].powerMw,
                          pCfrChnInfo.carrInfo[bandLoop][carrLoop].powDbfs);
            }

            cfrBandCarrNum ++;
        }
        pCfrChnInfo.bandCarrNum[bandLoop] = cfrBandCarrNum;
    }
    retVal  = BspGetDifInfoByRfChn(rfChn, TX, &chipidx, &difChn);
    difchnQtyPerChip = BspGetCfrDifChnNumPerChip();
    difChn = chipidx*difchnQtyPerChip + difChn;
    retVal |= BspSetCfrChnInfo(difChn, &pCfrChnInfo);

    free(pRruRfCfgInfo);
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspCfrChnInfoUpdateByBspChn
*  功能描述   : 配置削峰通道配置信息更新
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspCfrChnInfoUpdateByBspChn(UINT32 bspChn)
{
    UINT32 retVal   = BSP_OK;
    UINT32 carrLoop = 0;
    UINT32 chipidx  = 0;
    UINT32 difChn   = 0;
    UINT32 difchnQtyPerChip = 0;
    UINT32 bandLoop = 0;
    UINT32 cfrBandNum = 0;
    UINT32 cfrBandCarrNum = 0;
    INT32  powDbfs    = 0;
    UINT32 powMv      = 0;
    UINT32 useFlag    = 0;

    T_RruBandCfgInfo *pRruRfCfgInfo = NULL;
    T_CfrChnBandInfo  pCfrChnInfo   = {0};

    pRruRfCfgInfo = malloc(sizeof(T_RruBandCfgInfo));
    if (NULL == pRruRfCfgInfo)
    {
        dbgErr("[%s]RfChn %d RfCfgInfoMalloc Error!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }
    memset(pRruRfCfgInfo, 0, sizeof(T_RruBandCfgInfo));

    retVal = BspGetRruTxDifCfgPara(bspChn, pRruRfCfgInfo);
    if(retVal != BSP_OK)
    {
        free(pRruRfCfgInfo);
        dbgErr("[%s]bspChn %d Cfr Chn Info Update Error!\n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    pCfrChnInfo.centerFreq = pRruRfCfgInfo->loFreq;
    for(bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if(pRruRfCfgInfo->info[bandLoop].bandfreq == 0)
        {
            pCfrChnInfo.usedFlag[bandLoop] = CFR_BAND_NOT_USED;
            continue;
        }
        if(1 == BspGetFixBandFreqFlag())
        {
            useFlag = 0;
            for(carrLoop = 0;carrLoop < BSP_MAX_CARR_NUM;carrLoop ++)
            {
                if(0 != pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrFreq)
                {
                   useFlag = 1;
                   break;
                }
            }
            if(0 == useFlag)
            {
                pCfrChnInfo.usedFlag[bandLoop] = CFR_BAND_NOT_USED;
                continue;
            }
            dbgInfoEx("bspChn %lu,bandLoop %lu usedFlag %lu\n\n",bspChn,bandLoop, pCfrChnInfo.usedFlag[bandLoop]);
        }
        cfrBandNum ++;
        pCfrChnInfo.bandFreq[bandLoop] = pRruRfCfgInfo->info[bandLoop].bandfreq;
        pCfrChnInfo.usedFlag[bandLoop] = CFR_BAND_USED;
        pCfrChnInfo.bandNum            = cfrBandNum;
        cfrBandCarrNum = 0;
        for(carrLoop = 0 ;carrLoop < BSP_MAX_CARR_NUM;carrLoop ++)
        {
            if(pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrFreq == 0)
            {
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrFlag   = CFR_CARR_INVALID;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrNo;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio  = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrRadio;
            }
            else
            {
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrFlag   = CFR_CARR_VALID;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrNo;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio  = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrRadio;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].freq       = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrFreq;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrBw     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrBw;
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrFi     = pRruRfCfgInfo->info[bandLoop].carr[carrLoop].carrNco;
                if((NULL == pFGetCfrCarrPowCfg)||BspGetCfrCarrInfoFlag())
                {
                 BspGetCarrPowCfg(bspChn,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio, &powMv);
                }
                else
                {
                     pFGetCfrCarrPowCfg(bspChn,bandLoop,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio,pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrBw, &powMv);
                }
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].powerMw    = powMv;
                BspCfrPowDbfs(bspChn, pCfrChnInfo.carrInfo[bandLoop][carrLoop].powerMw, 16, &powDbfs);
                pCfrChnInfo.carrInfo[bandLoop][carrLoop].powDbfs      = powDbfs;
                dbgInfoEx("%s>>BspChnl'%d Carr'%d Radio'%d: CarrPowMv= %d, PowDbfs= %d\n", __FUNCTION__,
                          bspChn, pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrNo,
                          pCfrChnInfo.carrInfo[bandLoop][carrLoop].carrRadio,
                          pCfrChnInfo.carrInfo[bandLoop][carrLoop].powerMw,
                          pCfrChnInfo.carrInfo[bandLoop][carrLoop].powDbfs);
            }

            cfrBandCarrNum ++;
        }
        pCfrChnInfo.bandCarrNum[bandLoop] = cfrBandCarrNum;
    }
    retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);
    difchnQtyPerChip = BspGetCfrDifChnNumPerChip();
    difChn = chipidx*difchnQtyPerChip + difChn;
    retVal |= BspSetCfrChnInfo(difChn, &pCfrChnInfo);

    free(pRruRfCfgInfo);
    return BSP_OK;
}

/*********************************对外正式接口**************************************/

/*****************************************************************************
*  函数名称   : BspCfrGateInit
*  功能描述   : CFR clip,win,delt 参数从单板返回.
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan   - cfr中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrGateInit(UINT32 difChan)
{
    if(s_cfrModule.cfrFunc.pGateInit == NULL)
    {
        dbgInfo("[%s]cfr func GateInit is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pGateInit(difChan);
}
/*****************************************************************************
*  函数名称   : BspCfrCrtReInit
*  功能描述   : FPGA筛数门限初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan   - cfr中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它不支持
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrCrtReInit(UINT32 difChan)
{
    if(s_cfrModule.cfrFunc.pCfrCtrReInit == NULL)
    {
        dbgInfoEx("[%s]cfr func CfrCtrReInit is NULL \n",__FUNCTION__);
        return BSP_OK;
    }
    return s_cfrModule.cfrFunc.pCfrCtrReInit(difChan);
}
/*****************************************************************************
*  函数名称   : BspCpgInit
*  功能描述   : cpg 参数初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCpgInit(UINT32 difChan)
{
    if(s_cfrModule.cfrFunc.pCpgInit == NULL)
    {
        dbgInfo("[%s]cfr func CpgInit is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pCpgInit(difChan);
}
/*****************************************************************************
*  函数名称   : BspCpgCfg
*  功能描述   : cpg配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCpgCfg(UINT32 difChan)
{
    if(s_cfrModule.cfrFunc.pCpgCfg == NULL)
    {
        dbgInfo("[%s]cfr func CpgCfg is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pCpgCfg(difChan);
}
/*****************************************************************************
*  函数名称   : BspCfrGateInit
*  功能描述   : CFR clip,win,delt 参数从单板返回.
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan - 中频通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrCfg(UINT32 difChan)
{
    if(s_cfrModule.cfrFunc.pCfrCfg == NULL)
    {
        dbgInfo("[%s]cfr func CfrCfg is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pCfrCfg(difChan);
}
UINT32 BspSetCfrDelay(UINT32 difChan)
{
    if(s_cfrModule.cfrFunc.pCfrDelay == NULL)
    {
        dbgInfo("[%s]cfr func CfrDelay is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pCfrDelay(difChan);
}
/*****************************************************************************
*  函数名称   : BspCfrEnable
*  功能描述   : CFR Enable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrEnable(UINT32 difChn)
{
    if(s_cfrModule.cfrFunc.pEnable == NULL)
    {
        dbgInfo("[%s]cfr func Enable is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pEnable(difChn);
}
/*****************************************************************************
*  函数名称   : BspCfrDisable
*  功能描述   : CFR Enable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrDisable(UINT32 difChn)
{
    if(s_cfrModule.cfrFunc.pDisable == NULL)
    {
        dbgInfo("[%s]cfr func Disable is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pDisable(difChn);
}



/*****************************************************************************
*  函数名称   : BspCfrOutMode
*  功能描述   : CFR Enable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : difChan       - 中频通道号
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspCfrOutMode(UINT32 difChn, UINT32 outMode)
{
    if(s_cfrModule.cfrFunc.pOutMode == NULL)
    {
        dbgInfo("[%s]cfr func Disable is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pOutMode(difChn,outMode);
}

/*****************************************************************************
*  函数名称   : BspSetCfrEnable
*  功能描述   : 对高层接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChn       - bspChn
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrEnable(UINT32 bspChn)
{
    UINT32 difChn  = 0;
    UINT32 chipIdx = 0;
    UINT32 retVal = BSP_OK;
    retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipIdx, &difChn);
    if(retVal != BSP_OK)
    {
        return BSP_ERROR;
    }
    return BspCfrEnable(difChn);
}

/*****************************************************************************
*  函数名称   : BspSetCfrDisable
*  功能描述   : CFR Enable
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChn       - bspChn
*             :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrDisable(UINT32 bspChn)
{
    UINT32 difChn  = 0;
    UINT32 chipIdx = 0;
    UINT32 retVal = BSP_OK;
    retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipIdx, &difChn);
    if(retVal != BSP_OK)
    {
        return BSP_ERROR;
    }
    return BspCfrDisable(difChn);
}

/*****************************************************************************
*  函数名称   : BspSetCfrCpgPara
*  功能描述   : CFR CPG 参数配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChn - BSP通道
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*             :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrCpgPara(UINT32 bspChn)
{
    /* UINT32 difChn = 0; */
    printf("\nBspSetCfrCpgPara bscChn(%d)\n", bspChn);
    if(s_cfrModule.cfrFunc.pCfgCpgPara == NULL)
    {
        dbgInfo("[%s]Error! CfrFunc CfrCpgPara is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pCfgCpgPara(bspChn);
}

UINT32 BspSetCfrCpgDelay(UINT32 bspChn)
{
    UINT32 ulDifChnl = 0;
    UINT32 ulChipIdx = 0;
    UINT32 ulRetVal = BSP_OK;

    if (s_cfrModule.cfrFunc.pCfrDelay == NULL)
    {
        dbgInfo("[%s]Error! CfrFunc CfrCpgDelay is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }

//  ulRetVal = BspGetBspChnByRfChn(rfChn, TX, &ulBspChnl);
    ulRetVal = BspGetDifInfoByBspChn(bspChn, TX, &ulChipIdx, &ulDifChnl);
    if (ulRetVal != BSP_OK)
    {
        dbgInfo("[%s]BspChnl'%d DifInfo Get Error!\n",
                __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    return s_cfrModule.cfrFunc.pCfrDelay(ulDifChnl); // CfrDpdic3SetDelay
}

/*****************************************************************************
*  函数名称   : BspSetCfrGateByCoef
*  功能描述   : 根据系数调整削峰门限值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : bspChn       - bspChn
*        :dCfrPara      - 调整系数
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspSetCfrGateByCoef(UINT32 bspChn, DOUBLE dCfrPara)
{
    UINT32 difChn  = 0;
    UINT32 chipIdx = 0;
    UINT32 retVal = BSP_OK;
    UINT32 cfrGate[E_CFR_THR_NUM] = {0};
    retVal  = BspGetDifInfoByBspChn(bspChn, TX, &chipIdx, &difChn);
    if(retVal != BSP_OK)
    {
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]:bspChn =%d, dCfrPara=%f\n",__FUNCTION__, bspChn, dCfrPara);

    retVal  = BspGetCfrGatePara(difChn, cfrGate);
    if(BSP_OK == retVal)
    {
        dbgInfoEx("[%s]:cfrGate1 =%d, cfrGate2=%d, cfrGate3=%d,\n",__FUNCTION__, cfrGate[0], cfrGate[1], cfrGate[2]);
        cfrGate[0]  = (UINT32)((DOUBLE)cfrGate[0]*dCfrPara  + 0.5);
        cfrGate[1]  = (UINT32)((DOUBLE)cfrGate[1]*dCfrPara  + 0.5);
        cfrGate[2]  = (UINT32)((DOUBLE)cfrGate[2]*dCfrPara  + 0.5);

        dbgInfoEx("[%s]:calculate cfrgate:cfrGate1 =%d, cfrGate2=%d, cfrGate3=%d,\n",__FUNCTION__, cfrGate[0], cfrGate[1], cfrGate[2]);

        retVal = BspHalAdaptSetCfrGate(difChn,0,cfrGate,E_CFR_THR_NUM);
    }
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetCfrVer
*  功能描述   : 获取 CFR 版本号
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chip   - fpga 芯片号
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*             :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrVer(UINT32 chip)
{
    if(s_cfrModule.cfrFunc.pCfrVer == NULL)
    {
        dbgInfo("[%s]cfr func Version is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_cfrModule.cfrFunc.pCfrVer(chip);
}

UINT32 BspSetCfrWorkMode(UINT32 cfrWorkMode)
{
    s_cfrTestMode = cfrWorkMode;
    return BSP_OK;
}

UINT32 BspGetCfrWorkMode(VOID)
{
    return s_cfrTestMode;
}

/*****************************************************************************
* 函数名称: BspGetCfrBandCarrNum
* 功能描述: 获取CFR指定制式的载波数量
* 输入参数: difChn  - 中频通道
*           band    - 频段号,E_CFR_BAND_MAX表示通道的载波数量
*           radio   - 载波制式,支持多个制式或的结果
* 输出参数: 无
* 返 回 值: BSP_OK- 成功; 其它- 失败
* 其它说明:
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrBandCarrNum(UINT32 difChn, UINT32 band, UINT32 radio, UINT32 *pCarrNum)
{
    T_CfrChnBandInfo *pCfrChnInfo = NULL;
    UINT32 bandLoop = 0;
    UINT32 carrLoop = 0;
    UINT32 bandCarrNum[E_CFR_BAND_MAX + 1] = {0};

    INPUT_POINTER_CHECK(pCarrNum);
    if (band > E_CFR_BAND_MAX)
    {
        *pCarrNum = 0;
        return BSP_ERROR;
    }

    pCfrChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrChnInfo == NULL)
    {
        *pCarrNum = 0;
        return BSP_ERROR;
    }

    for (bandLoop = 0; bandLoop < pCfrChnInfo->bandNum; bandLoop++)
    {
        if (pCfrChnInfo->usedFlag[bandLoop] != CFR_BAND_USED)
        {
            continue;
        }
        for (carrLoop = 0; carrLoop < pCfrChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if ((pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrRadio & radio) != 0)
            {
                bandCarrNum[bandLoop]++;
                bandCarrNum[E_CFR_BAND_MAX]++;
            }
        }
    }
    *pCarrNum = bandCarrNum[band];
    return BSP_OK;
}

/*****************************************************************************
* 函数名称: BspGetCfrBandCarrMaxBw
* 功能描述: 获取CFR最大带宽
* 输入参数: difChn   - 中频通道
*           band    - 频段号,E_CFR_BAND_MAX表示通道的最大带宽
*           radio   - 载波制式,支持多个制式或的结果
* 输出参数: 无
* 返 回 值: BSP_OK- 成功; 其它- 失败
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrBandCarrMaxBw(UINT32 difChn, UINT32 band, UINT32 radio, UINT32 *pCarrMaxBand)
{
    UINT32 bandLoop = 0;
    UINT32 carrLoop = 0;
    T_CfrChnBandInfo *pCfrChnInfo = NULL;
    UINT32 carrMaxBw[E_CFR_BAND_MAX + 1] = {0};

    INPUT_POINTER_CHECK(pCarrMaxBand);
    if (band > E_CFR_BAND_MAX)
    {
        *pCarrMaxBand = 0;
        return BSP_ERROR;
    }

    pCfrChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrChnInfo == NULL)
    {
        *pCarrMaxBand = 0;
        return BSP_ERROR;
    }

    for (bandLoop = 0; bandLoop < pCfrChnInfo->bandNum; bandLoop++)
    {
        if (pCfrChnInfo->usedFlag[bandLoop] != CFR_BAND_USED)
        {
            continue;
        }
        for (carrLoop = 0; carrLoop < pCfrChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if ((pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrRadio & radio) != 0)
            {
                carrMaxBw[bandLoop] = max(carrMaxBw[bandLoop], pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrBw);
                carrMaxBw[E_CFR_BAND_MAX] = max(carrMaxBw[E_CFR_BAND_MAX], pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrBw);
            }
        }
    }
    *pCarrMaxBand = carrMaxBw[band];
    return BSP_OK;
}

/*****************************************************************************
* 函数名称: BspGetCfrBandCarrMinBw
* 功能描述: 获取CFR最小带宽
* 输入参数: difChn  - 中频通道
*           band    - 频段号,E_CFR_BAND_MAX表示通道的载波数量
*           radio   - 载波制式,支持多个制式或的结果
* 输出参数: 无
* 返 回 值: BSP_OK- 成功; 其它- 失败
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrBandCarrMinBw(UINT32 difChn, UINT32 band, UINT32 radio, UINT32 *pCarrMinBand)
{
    UINT32 bandLoop = 0;
    UINT32 carrLoop = 0;
    T_CfrChnBandInfo *pCfrChnInfo = NULL;
    UINT32 carrMinBw[E_CFR_BAND_MAX + 1] = {0};

    INPUT_POINTER_CHECK(pCarrMinBand);
    if (band > E_CFR_BAND_MAX)
    {
        *pCarrMinBand = CFR_BW_INVALID;
        return BSP_ERROR;
    }
    pCfrChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrChnInfo == NULL)
    {
        *pCarrMinBand = CFR_BW_INVALID;
        return BSP_ERROR;
    }

    for (bandLoop = 0; bandLoop <= E_CFR_BAND_MAX; bandLoop++)
    {
        carrMinBw[bandLoop] = CFR_BW_INVALID;
    }

    for (bandLoop = 0; bandLoop < pCfrChnInfo->bandNum; bandLoop++)
    {
        if (pCfrChnInfo->usedFlag[bandLoop] != CFR_BAND_USED)
        {
            continue;
        }
        for (carrLoop = 0; carrLoop < pCfrChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if ((pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrRadio & radio) != 0)
            {
                carrMinBw[bandLoop] = min(carrMinBw[bandLoop], pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrBw);
                carrMinBw[E_CFR_BAND_MAX] = min(carrMinBw[E_CFR_BAND_MAX], pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrBw);
            }
        }
    }
    *pCarrMinBand = carrMinBw[band];
    return BSP_OK;
}

/*****************************************************************************
* 函数名称: BspGetCfrBandRadio
* 功能描述: 获取CFR band制式
* 输入参数: difChn   - 中频通道
*           band    - 频段号,E_CFR_BAND_MAX表示通道的载波数量
* 输出参数: 无
* 返 回 值: BSP_OK- 成功; 其它- 失败
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrBandRadio(UINT32 difChn, UINT32 band, UINT32 *pRadio)
{
    UINT32 carrLoop = 0;
    UINT32 bandLoop = 0;
    T_CfrChnBandInfo *pCfrChnInfo = NULL;
    UINT32 bandRadio[E_CFR_BAND_MAX + 1] = {0};

    INPUT_DIFCHAN_CHECK(difChn)
    if (band > E_CFR_BAND_MAX)
    {
        dbgErr("[%s]DifChn'%d band'%d Is Over Range!\n", __FUNCTION__, difChn, band);
        return BSP_ERROR;
    }

    pCfrChnInfo = BspGetCfrChnInfo(difChn);
    if (pCfrChnInfo == NULL)
    {
        *pRadio = 0;
        return BSP_ERROR;
    }

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop++)
    {
        if (pCfrChnInfo->usedFlag[bandLoop] != CFR_BAND_USED)
        {
            continue;
        }
        for (carrLoop = 0; carrLoop < pCfrChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }
            bandRadio[bandLoop] |= pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            bandRadio[E_CFR_BAND_MAX] |= pCfrChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
        }
    }
    *pRadio = bandRadio[band];
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetCfrRamDepLen
*  功能描述   : CFR RAM深度
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张昱@2018-11-11 12:08:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetCfrRamDepLen(UINT32 lutLen)
{
    s_cfrModule.cfrPara.ramDepLen = lutLen;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetCfrRamDepLen
*  功能描述   : CFR RAM深度
*  输入参数   :
*             :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 张昱@2018-11-11 12:08:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetCfrRamDepLen(UINT32 *pLutLen)
{
    INPUT_POINTER_CHECK(pLutLen);
    *pLutLen = s_cfrModule.cfrPara.ramDepLen;
    return BSP_OK;
}
/*选择CFR RAM使用方案(原根据4/5G区分不合适)*/
UINT32 BspSetCfrRamCfgMode(UINT32 ulCfgMode)
{
    g_cfrRamCfgMode = ulCfgMode;
    return BSP_OK;
}
UINT32 BspGetCfrRamCfgMode(VOID)
{
    return g_cfrRamCfgMode;
}

/*获取通道中各个载波中削峰CPG系数的有效半长最大值*/
UINT32 BspCfrGetCpgValidHalfLenMax(UINT32 difChn, UINT32 *pCpgValidHalfLenMax)
{
    UINT32 ret = BSP_OK;
    UINT32 bandLoop     = 0;
    UINT32 carrLoop     = 0;
    UINT32 carrBw       = 0;
    UINT32 cfrBw        = 0;
    UINT32 carrRadio    = 0;
    UINT32 lutLen       = 0;
    UINT32 cpgValidHalfLenMax = 0;
    UINT32 tmp = 0;
    UINT32 cfrFs = 0;
    T_CfrChnBandInfo *pCfrDifChnInfo = NULL;
    T_CfrCpgPara cfrCpgPara = {0};

    INPUT_DIFCHAN_CHECK(difChn);

    ret |= BspGetCfrLutLen(&lutLen);

    pCfrDifChnInfo = BspGetCfrChnInfo(difChn);

    if(pCfrDifChnInfo == NULL)
    {
        dbgErr("%s pCfrDifChnInfo is NULL! \n",__func__);
        return BSP_ERROR;
    }

    for (bandLoop = 0; bandLoop < E_CFR_BAND_MAX; bandLoop ++)
    {
        if (pCfrDifChnInfo->usedFlag[bandLoop] == CFR_BAND_NOT_USED)
        {
            continue;
        }

        for (carrLoop = 0; carrLoop < pCfrDifChnInfo->bandCarrNum[bandLoop]; carrLoop++)
        {
            if (pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrFlag == CFR_CARR_INVALID)
            {
                continue;
            }
            carrBw      = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrBw;
            carrRadio   = pCfrDifChnInfo->carrInfo[bandLoop][carrLoop].carrRadio;
            ret |= BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
            ret |= BspGetCfrFsByDifChn(difChn,&cfrFs);
            #ifdef DPDIC3_R8998G
            {
                ret |= BspGetCfrCpgMulRateCoef(cfrBw, cfrFs, &cfrCpgPara);
            }
            #else
            {
                ret |= BspGetCfrCpgMulRateCoef(difChn, cfrBw, cfrFs, &cfrCpgPara);
            }
            #endif

            if (ret != BSP_OK)
            {
                continue;
            }

            /*过滤出本通道CPG原型系数有效半长长度的最大值*/
            tmp = cfrCpgPara.vaildLen;
            if(tmp > cpgValidHalfLenMax)
            {
                cpgValidHalfLenMax = tmp;
            }
        }
    }

    *pCpgValidHalfLenMax = cpgValidHalfLenMax;

    dbgInfoEx("%s chn[%d] CpgValidHalfLenMax = %d\n",__func__,difChn,*pCpgValidHalfLenMax);
    return ret;
}

static UINT32 BspGetCpgMaxLen(UINT32 difChan, T_RfCfgPara *pRfCfgPara)
{
    /* UINT32 ret = BSP_OK; */
    UINT32 cpgmaxlen = 0;
    UINT32 carr = 0;
    UINT32 cfrFs = 0;
    /* UINT32 ulDelayMode = 0; */
    UINT32 cfrBw = 0;
    UINT32 carrBw = 0;
    UINT32 carrRadio = 0;
    T_CfrCpgPara cfrCpgPara = {0};

    BspGetCfrFsByDifChn(difChan,&cfrFs);
    for (carr = 0; carr < pRfCfgPara->carrNum; carr++)
    {
        carrBw = pRfCfgPara->carrInfo[carr].bandWidth;
        carrRadio = pRfCfgPara->carrInfo[carr].radioMode;
        BspGetCfrRadioBwFromBspBw(carrRadio, carrBw, &cfrBw);
#ifdef DPDIC3_R8998G
        BspGetCfrCpgMulRateCoef(cfrBw,cfrFs, &cfrCpgPara);
#else
        BspGetCfrCpgMulRateCoef(difChan,cfrBw,cfrFs, &cfrCpgPara);
#endif
        cpgmaxlen = (cpgmaxlen>cfrCpgPara.vaildLen)?cpgmaxlen:cfrCpgPara.vaildLen;
    }
    return cpgmaxlen;
}

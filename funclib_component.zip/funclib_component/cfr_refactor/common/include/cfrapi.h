#ifndef FUNCLIB_CFR_API_H_INCLUDED
#define FUNCLIB_CFR_API_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
/**************************************************************************
 *                       宏定义
 **************************************************************************/
/* 0-InBand_SamePCI 1-InBand_DiffPCI 2-guardband 3-standalone */
#define  NB_INBAND_SAMEPCI              (0)
#define  NB_INBAND_DIFFPCI              (1)
#define  NB_GUARDBAND                   (2)
#define  NB_STANDALONE                  (3)

#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_CFR_API_H_INCLUDED


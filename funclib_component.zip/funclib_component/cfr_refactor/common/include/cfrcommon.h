/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : cfrcommon.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供CFR模块配置的功能实现。
 * 注意事项 : 无
 * 作    者 : wangfei
 * 创建日期 : 2015-10-20 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef PLATFORM_BSP_FUNCLIB_COMPONENT_CFR_REFACTOR_COMMON_INCLUDE_CFRCOMMON_H_
#define PLATFORM_BSP_FUNCLIB_COMPONENT_CFR_REFACTOR_COMMON_INCLUDE_CFRCOMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "regdrv.h"
#include "chnmap_a.h"
#include "cfrapi.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/

/* 指针非空检查宏，返回 BSP_ERROR_NULL_POINTER */
#define INPUT_CFRFUNCINIT_CHECK()                                     \
    if (CFR_FUNC_NOT_INIT == BspGetCfrFuncFlag())                     \
    {                                                                 \
        dbgErr("[%s]:CFR FUNC NOT INIT!\n",__FUNCTION__);             \
        return BSP_ERROR;                                             \
    }

#define INPUT_CFRBAND_CHECK(band)                                          \
    if (band >= E_CFR_BAND_MAX)                                            \
    {                                                                    \
        dbgErr("[%s] band'%d Is Over Range! \n",__FUNCTION__,band);        \
        return BSP_ERROR;                                                \
    }

typedef enum
{
    CFR_CPGCAL_CPUMODE   = 0, /*CPG参数由CPU计算*/
    CFR_CPGCAL_HARDMODE  = 1, /*CPG参数由逻辑硬件计算*/
    CFR_CPGCAL_MIXEDMODE = 2,/*CPG 混合型计算，就是CPG硬计算和CPU计算共存*/
    CFR_CPGCAL_MAX,
}E_CFR_CPGCAL_ID;

#define CFR_TEST_MODE       1
#define CFR_NORMAL_MODE     0

#define CFR_BAND_USED       1
#define CFR_BAND_NOT_USED   0

#define CFR_CARR_VALID      1
#define CFR_CARR_INVALID    0


#define CFR_FUNC_NOT_INIT   0       /*CFR 模块未初始化*/
#define CFR_FUNC_INIT       1       /*CFR 模块初始化*/

#define CFR_FUNC_ON         0xFF
#define CFR_FUNC_OFF        0

#define CFR_FUNC_INPUT_IQ_DATA      0x0 //零延时旁路
#define CFR_FUNC_OFF_IC             0x1 //等延时旁路
#define CFR_FUNC_ON_IC              0x2 //cfr使能
#define CFR_FUNC_PULSE_DATA_OUTPUT  0x3 //抵消脉冲输出模式
#define CFR_CPG_CPU_CAL              0  //削峰CPG采用软件计算
#define CFR_CPG_HW_CAL               1  //削峰CPG采用硬件计算
#define CFR_CPG_HW_STOP             0x1 //削峰CPG硬件计算暂停
#define CFR_CPG_HW_START            0x0 //削峰CPG硬件计算启动



#define CFR_BW_INVALID      INVALID_VALUE
/*----------------------------------------------------*/
/*  削峰参数特性                                      */
/*----------------------------------------------------*/

/*CFR RAM */
#define CFR_RAM_1024     1024

/*CFR CPG RAM */
#define CFR_CPG_RAM_167     167
#define CFR_CPG_RAM_256     256
#define CFR_CPG_RAM_512     512
#define CFR_CPG_RAM_768     768
#define CFR_CPG_RAM_1024    1024
#define CFR_CPG_RAM_MAX_LEN CFR_CPG_RAM_1024

/*CFR POS  */
#define CFR_AFTER_NCO_POS    0x1
#define CFR_BEFORE_NCO_POS   0x2
/*CFR DIV  */
#define CFR_DIV_SINGLE       0x1
#define CFR_DIV_DOULE        0x2



#define CFR_SIGEL_BAND       1
#define CFR_DOUBLE_BAND      2

#define CFR_PHASE_MUL        1
#define CFR_PHASE_SIGLE      0
typedef enum
{
    E_FPGA_FS_61P44M     ,  /* 0 */
    E_FPGA_FS_92P16M     ,  /* 1 */
    E_FPGA_FS_122P88M    ,  /* 2 */
    E_FPGA_FS_245P76M    ,  /* 3 */
    E_FPGA_FS_368P64M    ,  /* 4 */
    E_FPGA_FS_491P52M    ,  /* 5 */
    E_FPGA_FS_737P28M    ,  /* 6 */
    E_FPGA_FS_MAX,
}E_FPGA_FS_INFO;

#define CFR_CALI_DBFS_VAL_DEF     -1900
#define CFR_CPG_RATE_MAXTYPE       2

#define CFR_CFG_MODE_NORMAL_SOURCE    0
#define CFR_CFG_MODE_LOW_SOURCE      1

/*根据funcset区分普通模式和隧道模式*/
#define CFR_CFG_MODE_GENERAL         0
#define CFR_CFG_MODE_TUNNEL          1

typedef UINT32 (*Cfr_Enable)(UINT32 difChan);
typedef UINT32 (*Cfr_Disable)(UINT32 difChan);
typedef UINT32 (*Cfr_OutMode)(UINT32 difChan,UINT32 outMode);
typedef UINT32 (*Cfr_GateInit)(UINT32 difChan/*T_CFR_SUBLINK_INFO* ptCfrSubLinkCfg*/);
typedef UINT32 (*Cfr_Cfg)(UINT32 difChan);
typedef UINT32 (*Cfr_CtrRnInit)(UINT32 difChan);
typedef UINT32 (*Cfr_CpgInit)(UINT32 difChan);
typedef UINT32 (*Cfr_CpgCfg)(UINT32 difChan);
typedef UINT32 (*Cfr_FuncInit)(UINT32 cfrVerId);
typedef UINT32 (*Cfr_CfgCpgPara)(UINT32 rfChan);
typedef UINT32 (*Cfr_Delay)(UINT32 difChan);
typedef UINT32 (*Cfr_Ver)(UINT32 chip);

typedef UINT32 (*cfr_fsByDif)(UINT32 difChn,UINT32 *pCfrFs);
typedef UINT32 (*cfr_blockNoByDif)(UINT32 difChn,UINT32 *pCfrBlock);
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef enum
{
    E_CFR_THR_1ST,
    E_CFR_THR_2ND,
    E_CFR_THR_3RD,
    E_CFR_THR_NUM
}E_CFR_THRESHOLD;

/*FPGA版本能力CFR模块地址*/
enum
{
    REG_CFR_MAX_CARR = 0x80,
    REG_CFR_FS_RATE  = 0x81,
    REG_CFR_BAND     = 0x82,
    REG_CFR_DIV      = 0x83,
    REG_CFR_POS      = 0x84,
};

typedef enum
{
    E_CFR_BAND0,
    E_CFR_BAND_MAX
}E_CFR_BAND_INFO;

typedef struct tag_cfr_threshold        /*削峰门限*/
{
    UINT32 thrStage[E_CFR_THR_NUM];
    FLOAT fGateCoef;
}T_CfrThrInfo;

typedef struct tag_cfr_cpg_info          /*cpg 信息*/
{
    T_CfrCpgPara    para[E_CFR_RADIO_BW_MAX];
    UINT32          lutLen;
    UINT32          calMode;
}T_CfrCpgInfo;

typedef struct tag_cfr_para    /*CFR模块需要的参数*/
{
   T_CfrThrInfo *pGate;          /*削峰门限参数*/
   T_CfrThrInfo *pWin;           /*削峰窗长参数*/
   T_CfrThrInfo *pDelt;          /*削峰检查门限参数*/
   T_CfrThrInfo *pWinLevel;      /*削峰窗长等级*/
   T_CfrThrInfo *pNoise;         /*削峰噪声参数*/
   T_CfrCpgInfo  cpg;            /*削峰cpg参数*/
   T_CfrCpgInfo  cpgMulRate[CFR_CPG_RATE_MAXTYPE];  /*多速率cpg 参数 AAU上一种带宽两种速率*/
   UINT32         ramDepLen;         /*削峰RAM深度*/
}T_CfrPara;

typedef struct tag_func_cfr
{
   Cfr_Enable       pEnable;
   Cfr_Disable      pDisable;
   Cfr_OutMode      pOutMode;
   Cfr_GateInit     pGateInit;
   Cfr_Cfg          pCfrCfg;
   Cfr_CtrRnInit    pCfrCtrReInit;
   Cfr_CpgInit      pCpgInit;
   Cfr_CpgCfg       pCpgCfg;
   Cfr_CfgCpgPara   pCfgCpgPara;   /*用于给高层接口调用 BspSetCfrCpgPara*/
   Cfr_Ver          pCfrVer;
   Cfr_Delay        pCfrDelay;
}T_CfrFunc;


typedef struct tag_cfr_module
{
   T_CfrFunc cfrFunc;
   T_CfrPara cfrPara;
   Cfr_FuncInit cfrFuncInit;
   UINT32 cfrFs;
   UINT32 cfrPos;
   UINT32 initFlag;
}T_CfrModule;

typedef struct tag_width_bsp_to_cfr
{
    UINT32 radioMode;
    UINT32 bspBw;
    UINT32 cfrBw;
}T_BwBspToCfr;

/*CPU 软计算CFR CPG信息结构体定义*/
typedef struct tag_cfr_carr_info
{
   UINT32 carrFlag;         /* 载波是否有效*/
   UINT32 carrNo;           /* 载波号   */
   UINT32 carrRadio;        /* 载波制式 */
   UINT32 freq;             /* 载波下行频点 */
   UINT32 carrBw;           /* 载波带宽*/
   INT32  carrFi;           /* 载波fi,就是载波NCO*/
   INT32  powDbfs;          /* 载波基带功率0.01dbfs 或者dbm*/
   UINT32 powerMw;          /* 载波基带功率mw*/
   UINT32 carrGi;           /* 载波Gi 因子*/
} T_CfrCarrInfo;

typedef struct tag_cfr_chn_info
{
   UINT32 centerFreq;
   T_CfrCarrInfo carr[BSP_MAX_CARR_NUM];

}T_CfrChnInfo;


typedef struct tag_cfr_difchan_info
{
    UINT32 centerFreq;                                          /*cfr通道中心频点*/
    UINT32 bandNum;                                             /*cfr通道频段数*/
    UINT32 bandCarrNum[E_CFR_BAND_MAX];                         /*cfr通道中每个频段的载波数*/
    UINT32 bandFreq[E_CFR_BAND_MAX];                            /*cfr通道中每个频段的中心频点*/
    UINT32 usedFlag[E_CFR_BAND_MAX];                            /*频段使用标记 1:使用 0:未使用*/
    T_CfrCarrInfo carrInfo[E_CFR_BAND_MAX][BSP_MAX_CARR_NUM];   /*每个频段最大8CARR计算*/
} T_CfrChnBandInfo;


typedef struct tag_cfr_cpg_factor
{
    E_CFR_RADIO_BW_INFO cfrBw;  /*载波削峰带宽*/
    INT32  wdi;              /*默认加权因子*/
    INT32  wpi;              /*PAR加权因子*/
    INT32  adj;              /*纠正因子*/
    UINT32 factorType;
}T_CfrFpgaFactor,T_CfrFactor;

typedef struct tag_cfr_cpg_factor_tbl
{
    UINT32          cfrFsRate;
    T_CfrFactor    *cfrfactortbl;
    UINT32          cfrFactorTblLen;
}T_CfrFactorTbl;

typedef union u_cfr_cfg_para{

    struct _t_pvoid_cfg_para
    {
        VOID  *pCfgPara;
        UINT32  cfgNum;
        UINT32  paraType;
    } tVoidCfg;
    struct _t_cfr_fpga_cfg_para
    {
        T_CfrFpgaFactor * pCfgPara;
        UINT32            cfgNum;
        UINT32  paraType;
    } tCfrFpgaCfg;
    struct _t_cfr_dpdic_cfg_para
    {
        T_CfrFactor *pCfgPara;
        UINT32       cfgNum;
        UINT32  paraType;
    } tCfrDpdicCfg;


}U_CFR_CFGPARA;

typedef  UINT32 (PFGetCfrCarrPow)(UINT32 uChn,UINT32 uBandId, UINT32 uCarrNo, UINT32 uCarrMode, UINT32 uCarrBw, UINT32 *pCarrPowMw);

/**************************************************************************
 *                         函数接口
 **************************************************************************/

T_CfrModule* BspGetCfrModuleInfo(VOID);
UINT32 BspGetCfrFuncFlag(VOID);
T_CfrChnBandInfo* BspGetCfrChnInfo(UINT32 difChn);
UINT32 BspSetCfrCpgCoef(UINT32 cfrBw, const UINT32 *pfrCpgCoef, UINT32 len);
UINT32 BspGetCfrCpgCoef(UINT32 cfrBw, T_CfrCpgPara *pCpgPara);
UINT32 BspSetCfrLutLen(UINT32 lutLen);
UINT32 BspGetCfrLutLen(UINT32 *pLutLen);
UINT32 BspSetCfrCpgMode(UINT32 cpgMode);
UINT32 BspGetCfrCpgMode(UINT32 *pCpgMode);
UINT32 BspSetCfrFs(UINT32 cfrFs);
UINT32 BspGetCfrFs(UINT32 *pCfrFs);
UINT32 BspSetCfrPos(UINT32 cfrPos);
UINT32 BspGetCfrPos(UINT32 *pCfrPos);
UINT32 BspSetCfrGatePara(UINT32 difChan, UINT32 *pCfrGate);
UINT32 BspGetCfrGatePara(UINT32 difChan, UINT32 *pCfrGate);
UINT32 BspSetCfrWinPara(UINT32 difChan, UINT32 *pCfrWin);
UINT32 BspGetCfrWinPara(UINT32 difChan, UINT32 *pCfrWin);
UINT32 BspSetCfrDeltPara(UINT32 difChan, UINT32 *pCfrDelt);
UINT32 BspGetCfrDeltPara(UINT32 difChan, UINT32 *pCfrDelt);
UINT32 BspSetCfrGate(UINT32 difChipIdx, UINT32 difChnIdx, UINT32 cfrGate1, UINT32 cfrGate2, UINT32 cfrGate3);
UINT32 BspSetCfrWin(UINT32 difChipIdx, UINT32 difChnIdx, UINT32 cfrWin1, UINT32 cfrWin2, UINT32 cfrWin3);
UINT32 BspSetCfrDelt(UINT32 difChipIdx, UINT32 difChnIdx, UINT32 cfrDelt1, UINT32 cfrDelt2, UINT32 cfrDelt3);
UINT32 BspSetCfrSwitch(UINT32 difChan, UINT32 ulSwitch);
UINT32 BspGetCfrRadioBwFromBspBw(UINT32 radioMode, UINT32 bspBw, UINT32 *pCfrRadioBw);
UINT32 BspGetBspBwFromCfrBw(UINT32 radioMode, UINT32 cfrBw, UINT32 *pBspBw);
UINT32 BspSetCfrFuncVerId(UINT32 cfrFuncVerId);
UINT32 BspGetCfrFuncVerId(VOID);
UINT32 BspCfrGateInit(UINT32 difChan);
UINT32 BspCpgInit(UINT32 difChan);
UINT32 BspSetCpgCfg(UINT32 difChan);
UINT32 BspSetCfrCfg(UINT32 difChan);
UINT32 BspCfrEnable(UINT32 difChan);
UINT32 BspCfrDisable(UINT32 difChan);
UINT32 BspCfrFuncMemInfoInit(VOID);
UINT32 BspSetCfrCfgPara(UINT32 cfrId,VOID *pCfgPara, UINT32 cfgNum);
UINT32 BspGetCfrDifChnNum(VOID);
UINT32 BspGetCfrVer(UINT32 chip);
UINT32 BspGetCfrDifChnNumPerChip(VOID);
UINT32 BspSetCfrChnInfo(UINT32 difChn, T_CfrChnBandInfo *pCfrChnCarrInfo);

UINT32 BspSetCfrWorkMode(UINT32 cfrWorkMode);
UINT32 BspGetCfrWorkMode(VOID);
UINT32 BspSetCfrDifChnNum(UINT32 cfrDifChnNum);
UINT32 BspCfrChnInfoUpdate(UINT32 rfChn);
UINT32 BspSetCfrDifChnNumPerChip(UINT32 cfrDifChnNum);
U_CFR_CFGPARA* BspGetCfrCfgPara(UINT32 cfrId);
UINT32 BspCfrPowDbfs(UINT32 difChn, UINT32 powr, UINT32 ulFullBit, INT32 *lpDbfs);
UINT32 BspGetCfrGate(UINT32 difChipIdx, UINT32 difChnIdx, UINT32 *cfrGate1, UINT32 *cfrGate2, UINT32 *cfrGate3);
UINT32 BspGetCfrDelt(UINT32 difChipIdx, UINT32 difChnIdx, UINT32 *cfrDelt1, UINT32 *cfrDelt2, UINT32 *cfrDelt3);
UINT32 BspGetCfrWin(UINT32 difChipIdx, UINT32 difChnIdx, UINT32 *cfrWin1, UINT32 *cfrWin2, UINT32 *cfrWin3);
UINT32 BspGetCfrBandCarrNum(UINT32 difChn, UINT32 band, UINT32 radio, UINT32 *pCarrNum);
UINT32 BspGetCfrBandRadio(UINT32 difChn,UINT32 band,UINT32 *pRadio);
UINT32 BspCfrChnInfoUpdateByBspChn(UINT32 bspChn);
UINT32 BspCfrCrtReInit(UINT32 difChan);
UINT32 BspCfrHwDefCallBackInit(pGetCfrRamAblity pCallBackFunc);
UINT32 BspGetCfrFsByDifChn(UINT32 difChn,UINT32 *pCfrFs);
UINT32 BspCfrFsByDifBackInit(cfr_fsByDif pCallBackFunc);
UINT32 BspGetBlockNoByDifBackInit(cfr_blockNoByDif pCallBackFunc);
UINT32 BspGetCfrBlockNoByDifChn(UINT32 difChn,UINT32 *pCfrBlock);
UINT32 BspSetCfrRamDepLen(UINT32 lutLen);
UINT32 BspGetCfrRamDepLen(UINT32 *pLutLen);
pGetCfrRamAblity BspGetCfrHwDefCallBack(VOID);
UINT32 BspGetCfrRamCfgMode(VOID);
UINT32 BspSetCfrRamCfgMode(UINT32 ulCfgMode);
UINT32 BspSetCfrCarrPowCfgFunc(PFGetCfrCarrPow pFunc);
UINT32 BspCfrGetCpgValidHalfLenMax(UINT32 difChn, UINT32 *pCpgValidHalfLenMax);

UINT32 BspSetCfrWinPara(UINT32 difChan, UINT32 *pCfrWin);
/*UINT32 BspGetSupportGsmFlag(UINT32 difChn);*/
UINT32 BspGetCfrCarrInfoFlag(VOID);
UINT32 BspGetFlag400M(UINT32 *flag);
UINT32 BspGetCarrNcoFreq(UINT32 dir, UINT32 chan, UINT32 bandNo);

UINT32 BspSetCfrCpgMulRateCoef(UINT32 cfrBw,const UINT32 *pfrCpgCoef, UINT32 len,UINT32 rate,UINT32 rateIdx,UINT32 vaildLen);
UINT32 BspSetCfrWinLevelPara(UINT32 difChan, UINT32 *pCfrWinLevel);
UINT32 BspSetCfrWinLevelPara(UINT32 difChan, UINT32 *pCfrWinLevel);
UINT32 BspSetCfrNoisePara(UINT32 difChan, UINT32 *pCfrNoise);
UINT32 BspGetCfrNoisePara(UINT32 difChan, UINT32 *pCfrNoise);
UINT32 BspSetCfrCarrFlag(UINT32 cfrCarrFlag);
UINT32 BspSetCfrDelay(UINT32 difChan);
UINT32 BspGetCfrBandCarrMaxBw(UINT32 difChn, UINT32 band, UINT32 radio, UINT32 *pCarrMaxBand);
UINT32 BspGetCfrBandCarrMinBw(UINT32 difChn, UINT32 band, UINT32 radio, UINT32 *pCarrMinBand);
UINT32 BspGetCfrWinLevelPara(UINT32 difChan, UINT32 *pCfrWinLevel);
UINT32 BspCfrNonGsmPow_Gsm(VOID);
UINT32 BspSetCfrDisable(UINT32 bspChn);
UINT32 BspSetCfrEnable(UINT32 bspChn);

UINT32 BspSetCfrCpgPara(UINT32 bspChn);

#ifdef __cplusplus
}
#endif
#endif //_FUNCLIB_CFR_COMMON_H_INCLUDED_


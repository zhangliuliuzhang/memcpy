/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : mts_maintenance.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 赵首祯
* 创建日期 : 2021-11-17 10:30:00
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 赵首祯
* 修改日戳: 2021-11-17 10:30:00
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "funccommon.h"
#include "mts_common.h"
#include "mts_comm.h"




/**************************************************************************
 *                            宏                                          *
 **************************************************************************/
#define  MTSOPESTA_OK    (0)
#define  MTSOPESTA_ERROR    (1)
/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                          静态变量定义                                   *
 **************************************************************************/


/******************************************************************************
 * 函数名称   : BspGetMtsOperationStatus(*)
 * 功能描述   : BSP获取MTS硬件信息(智能运维接口)
 * 读全局变量 : 无
 * 写全局变量 : 无
 * 输入参数   : Chip
 * 输出参数   : *pGetMtsStaInfo,MTS硬件状态信息
 * 返 回 值   : BSP_OK 表示正常，其它表示异常
 * 其它说明   :
 * ----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), zhaoshouzhen 10307958@2021-11-17 11:00 创建
 ******************************************************************************
 */

UINT32 BspGetMtsOperationStatus(INT32 chip, T_BspGetMtsStatusInfo *pGetMtsStaInfo)
{
    UINT32 retVal = BSP_OK;
    mtsOperationMsg MtsStaInfo = {0};

    INPUT_POINTER_CHECK(pGetMtsStaInfo);

    retVal = (UINT32)MTS_GetOperationStatus(chip, &MtsStaInfo);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>chip'%d MTS_GetOperationStatus Get Error!\n",__FUNCTION__, chip);
        return BSP_ERROR;
    }
    pGetMtsStaInfo->chip = MtsStaInfo.chip;
    pGetMtsStaInfo->chipVer = MtsStaInfo.chipVer;
    pGetMtsStaInfo->temp = MtsStaInfo.temp;
    pGetMtsStaInfo->txFreqCenter = MtsStaInfo.txFreqCenter;
    pGetMtsStaInfo->rxFreqCenter = MtsStaInfo.rxFreqCenter;
    pGetMtsStaInfo->PllLock = MtsStaInfo.PllLock;
    pGetMtsStaInfo->serdesPllSta = MtsStaInfo.serdesPllSta;
    pGetMtsStaInfo->AnalogCalSta = MtsStaInfo.AnalogCalSta;
    pGetMtsStaInfo->TxCaldelay = MtsStaInfo.TxCaldelay;
    pGetMtsStaInfo->TxQecLo = MtsStaInfo.TxQecLo;
    pGetMtsStaInfo->RxQec = MtsStaInfo.RxQec;
    pGetMtsStaInfo->FbQec = MtsStaInfo.FbQec;
    pGetMtsStaInfo->OrxQec = MtsStaInfo.OrxQec;
    pGetMtsStaInfo->TxEq = MTSOPESTA_OK;
    pGetMtsStaInfo->RxEq = MTSOPESTA_OK;
    pGetMtsStaInfo->FbEq = MTSOPESTA_OK;
    pGetMtsStaInfo->OrxEq = MTSOPESTA_OK;
    pGetMtsStaInfo->tx204cCRCSta = ((MtsStaInfo.tx204cSta) & BIT_SET(3));
    memcpy_s(pGetMtsStaInfo->ver,40,MtsStaInfo.ver,40);
    if(MtsStaInfo.tx204cSta != MTSOPESTA_OK)
    {
        pGetMtsStaInfo->tx204cSta = MTSOPESTA_ERROR;
    }
    else
    {
        pGetMtsStaInfo->tx204cSta = MTSOPESTA_OK;
    }
    if(((MtsStaInfo.RxRfPllSta) & (MtsStaInfo.TxRfPllSta) & (MtsStaInfo.AuxRfPllSta)) != MTSOPESTA_OK)
    {
        pGetMtsStaInfo->VCObandPllSta = MTSOPESTA_ERROR;
    }
    else
    {
        pGetMtsStaInfo->VCObandPllSta = MTSOPESTA_OK;
    }

    return retVal;
}

VOID PrintMtsSta(INT32 chip)
{
    T_BspGetMtsStatusInfo pGetMtsStaInfo = {0};

    BspGetMtsOperationStatus(chip, &pGetMtsStaInfo);
    dbgInfo("%s\n chip>>%d\n ver>>%s\n chipVer>>%d\n temp>>%d\n txFreqCenter>>%d\n rxFreqCenter>>%d\n PllLock>>%d\n"
            ,__FUNCTION__,pGetMtsStaInfo.chip,pGetMtsStaInfo.ver,pGetMtsStaInfo.chipVer,pGetMtsStaInfo.temp,
            pGetMtsStaInfo.txFreqCenter,pGetMtsStaInfo.rxFreqCenter, pGetMtsStaInfo.PllLock);
    dbgInfo("tx204cSta>>%d\n tx204cCRCSta>>%d\n serdesPllSta>>%d\n VCObandPllSta>>%d\n AnalogCalSta>>%d\n TxCaldelay>>%d\n"
            ,pGetMtsStaInfo.tx204cSta,pGetMtsStaInfo.tx204cCRCSta,pGetMtsStaInfo.serdesPllSta,
            pGetMtsStaInfo.VCObandPllSta,pGetMtsStaInfo.AnalogCalSta,pGetMtsStaInfo.TxCaldelay);
    dbgInfo("TxQecLo>>%d\n TxEq>>%d\n RxQec>>%d\n RxEq>>%d\n FbQec>>%d\n FbEq>>%d\n OrxQec>>%d\n OrxEq>>%d\n"
            ,pGetMtsStaInfo.TxQecLo,pGetMtsStaInfo.TxEq,pGetMtsStaInfo.RxQec,pGetMtsStaInfo.RxEq,
            pGetMtsStaInfo.FbQec,pGetMtsStaInfo.FbEq,pGetMtsStaInfo.OrxQec,pGetMtsStaInfo.OrxEq);

}

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : wfs.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bspcomm.h"
#include "boardid.h"
#include "funccommon.h"
#include "bsppub.h"
#include "mts_common.h"
#include "mts_spi.h"
#include "mts_comm.h"
#include "mts_orx.h"
#include "mts_tx.h"
#include "mts_rx.h"
#include "mts_cals.h"

#include "mts_gain.h"
#include "mts_tempsensor.h"

#include "mts_wfs.h"
#include "devdrv_transceiver.h"


/**************************************************************************
 *                            宏                                          *
 **************************************************************************/
#define  RELEASE_VERSION_SIZE    40

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                          静态变量定义                                   *
 **************************************************************************/


/******************************************************************************
 * 函数名称   : Bsp_WfsGetCaliSta_MTS(*)
 * 功能描述   : MTS命令获取rho值和aftrho值
 * 读全局变量 : 无
 * 写全局变量 : 无
 * 输入参数   : iChipID: 芯片ID
 *             iCaliModeIndex: 校准索引  RXQECDC索引值为6
 *             iChNum: chan号
 *             iSubModeIndex: 获取值索引 校准状态索引值为0
 *             *piRetVal: msg返回值
 * 输出参数   : 无
 * 返 回 值   : BSP_OK 表示正常，其它表示异常
 * 其它说明   :
 * ----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 ******************************************************************************
 */
UINT32 Bsp_WfsGetCaliSta_MTS(INT32 iChipID,INT32 iCaliModeIndex,INT32 iChNum,INT32 iSubModeIndex,INT32 *piRetVal)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(piRetVal);
    retVal = MTS_GetCaliSta(iChipID,iCaliModeIndex,iChNum,iSubModeIndex,piRetVal);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsStopTrackingCali_MTS(*)
 *  功能描述   : 对MTS一个芯片 停止跟踪校准
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip  chip id
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsStopTrackingCali_MTS(INT32 chip)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)MTS_StopTrackingCali(chip);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsStartTrackingCali_MTS(*)
 *  功能描述   : 对MTS的一个通道开启跟踪校准
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip  chip id
 *                : chan   mts chan
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsStartTrackingCali_MTS(INT32 chip, INT32 chan)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)MTS_StartChanTrackingCali(chip,chan);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSwitchAgc_MTS(*)
 *  功能描述   : 设置vga模式
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip     chip id
 *               vgamode   0:agc 1:mgc1 2:mgc2 3:manual
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsSwitchAgc_MTS(INT32 chip,UINT32 vgaMode)
{
    UINT32 retVal = BSP_OK;
    retVal = MTS_SwitchAgc(chip, vgaMode);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsMcuCall_MTS(*)
 *  功能描述   : MTS mcu命令调用
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip     chip id
 *               *func   具体命令，命令外需加""
 *               如Bsp_WfsMcuCall_MTS(0,"cali 2,sw") 具体如下
 *               cali 2,sw  打开/关闭MTS跟踪校准 sw=0关，sw=1开
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsMcuCall_MTS(int chip, char *func)
{
    INT32 callRet = 0;
    UINT32 funcRet = 0;
    INPUT_POINTER_CHECK(func);
    funcRet = (UINT32)mcucall(chip, func, &callRet);
    dbgInfoEx("%s funcRet:%#x callRet:%#x\n", __FUNCTION__, funcRet, callRet);
    funcRet |= (UINT32)callRet;
    return funcRet;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSetVgaManAttVal_MTS(*)
 *  功能描述   : mpw 0.3 数字设置 rxatt
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 数字rxatt设置值 0-31
 *  输出参数   : 无
 *  返 回 值   : fb att对应的 index值
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsSetVgaManAttVal_MTS(INT32 chip,UINT32 Chan,UINT32 VgaManAttVal)
{
    UINT32 retVal = BSP_OK;
    retVal =  MtsSetVgaManAttVal(chip, Chan, VgaManAttVal);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSetPllFreq_MTS(*)
 *  功能描述   : 设置本振频点-对外接口
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip      chip id
 *             : pllSel    pll类型，0 rx, 1 tx, 2 aux
 *             : freq      频点
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsSetPllFreq_MTS(INT32 chip, mtsPllType_t pllSel, UINT32 cfgFreq)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)MtsSetPllFreq(chip, pllSel, cfgFreq);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSetAuxSourcetoRxLink_MTS(*)
 *  功能描述   : aux做源连接到rx链路的开关控制
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip   chip id
 *             : chan     通道
 *             : sw      关0  开1
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsSetAuxSourcetoRxLink_MTS(INT32 chip, UINT32 chan, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    retVal =  (UINT32)MtsSetAuxSourcetoRxLink(chip, chan, sw);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetVgaDpdhhTh_MTS(*)
 *  功能描述   : 读取MTS dpd门限值
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip   chip id
 *             : chan     通道
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetVgaDpdhhTh_MTS(INT32 chip, UINT32 Chan)
{
    UINT32 retVal = 0;
    retVal =  MtsGetVgaDpdhhTh(chip, Chan);
    return retVal;
}
/*****************************************************************************
 *  函数名称   : Bsp_WfsSetVgaDpdhhTh_MTS(*)
 *  功能描述   : 设置MTS dpd门限值
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *            : VgaDpdhhTh 门限值 0xE3：-1dBfs（推荐），0xCA：-2dBfs，0xB4：-3dBfs
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsSetVgaDpdhhTh_MTS(INT32 chip, UINT32  Chan,UINT32  VgaDpdhhTh)
{
    UINT32 retVal = BSP_OK;
    retVal =  MtsSetVgaDpdhhTh(chip, Chan, VgaDpdhhTh);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetVgaDpdhhAlarm_MTS(*)
 *  功能描述   : 读取历史D_PD告警
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetVgaDpdhhAlarm_MTS(INT32 chip,UINT32 Chan)
{
    UINT32 retVal = BSP_OK;
    retVal =  MtsGetVgaDpdhhAlarm(chip, Chan);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsClrVgaDpdhhAlarm_MTS(*)
 *  功能描述   : 清除D_PD告警
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *            : ClrDpdhhAlm 1清，0不清
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : ClrDpdhhAlm需先配1再配0
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsClrVgaDpdhhAlarm_MTS(INT32 chip,UINT32 Chan,UINT32 ClrDpdhhAlm)
{
    UINT32 retVal = BSP_OK;
    retVal =  MtsClrVgaDpdhhAlarm(chip, Chan, ClrDpdhhAlm);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsDiagnose_MTS(*)
 *  功能描述   : 查看mts的各个模块的状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : option 1(Analog State) 2(Interface status) 3(Algorithm calibration)
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsDiagnose_MTS(INT32 chip,INT32 option)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)MtsDiagnose(chip, option);
    return retVal;
}


/*****************************************************************************
 *  函数名称   : Bsp_WfsGetRxCalIRR_MTS(*)
 *  功能描述   : 获取通道chan的IRR值,单位：dBc
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *
 *  输出参数   : *pfIRR  IRR值，单位：dBc
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetRxCalIRR_MTS(INT32 iChipID,INT32 iChNum,float *pfIRR)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pfIRR);
    retVal = (UINT32)MTS_GetRxCalIRR(iChipID, iChNum,pfIRR);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetRxDcDbfs_MTS(*)
 *  功能描述   : 获取通道chan的DC值, 单位：dBFs
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *
 *  输出参数   : *pfDbfs  DC值，单位：dBFs
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetRxDcDbfs_MTS(INT32 iChipID,INT32 iChNum,float *pfDbfs)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pfDbfs);
    retVal = (UINT32)MTS_GetRxDcDbfs(iChipID, iChNum,pfDbfs);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsEfuseReVal_MTS(*)
 *  功能描述   : 获取EFUSE信息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *  输出参数   : *EfuseVal  EFUSE信息，长度16个UINT32
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
INT32 Bsp_WfsEfuseReVal_MTS(INT32 chip,UINT32 *EfuseVal,char *TestTime,char *TestMachine, char *TestVersion)
{
    INT32 retVal = BSP_OK;
    if ((EfuseVal == NULL) || (TestTime == NULL) || (TestMachine == NULL) || (TestVersion == NULL))
    {
        dbgErr("[%s] input para err!\n",__func__);
        //coverity[cert_int31_c_violation:SUPPRESS]
        return BSP_ERROR;
    }
    retVal = MtsEfuseReVal(chip, EfuseVal);
    retVal |= MtsGetEfuseTestTime(chip, TestTime);
    retVal |= MtsGetEfuseTestMachine(chip, TestMachine);
    retVal |= MtsGetEfuseTestVersion(chip, TestVersion);

    return retVal;
}
INT32 test_Bsp_WfsEfuseReVal_MTS(INT32 chip)
{
    INT32 retVal = BSP_OK;
    UINT32 EfuseVal[16] = {0,};
    UINT32 loop = 0;
    char TestTime[64] = {0,};
    char TestMachine[50] = {0,};
    char TestVersion[50] = {0,};
    retVal = Bsp_WfsEfuseReVal_MTS(chip, EfuseVal, TestTime, TestMachine, TestVersion);
    for(loop = 0; loop<16; loop++)
    {
        dbgInfo("0x%08x ",EfuseVal[loop]);
        if(0 == ((loop+1)%4))
        {
            dbgInfo("\n");
        }
    }
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsVersionHostString_MTS(*)
 *  功能描述   : 获取MTS HOST VERSION
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : char版本指针
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsVersionHostString_MTS(CHAR* ver)
{
    CHAR *hostVer = NULL;
    INPUT_POINTER_CHECK(ver);
    hostVer = MtsVersionHostString();
    INPUT_POINTER_CHECK(hostVer);
    memcpy_s(ver,RELEASE_VERSION_SIZE,hostVer,RELEASE_VERSION_SIZE);
    return BSP_OK;
}
UINT32 test_Bsp_WfsVersionHostString_MTS(void)
{
    CHAR hostVer[RELEASE_VERSION_SIZE] = {0};
    UINT32 retVal = BSP_OK;
    //CHAR *hostVer=NULL;
    retVal = Bsp_WfsVersionHostString_MTS(hostVer);
    dbgInfo("MTS HOST VERSION IS %s \n",hostVer);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsVersionMcuString_MTS(*)
 *  功能描述   : 获取MTS MCU VERSION
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : char版本指针
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), liujubo 10258234@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsVersionMcuString_MTS(INT32 iChipID, CHAR* ver)
{
    CHAR *mcuVer = NULL;
    INPUT_POINTER_CHECK(ver);
    mcuVer = MtsVersionMcuString(iChipID);
    INPUT_POINTER_CHECK(mcuVer);
    memcpy_s(ver,RELEASE_VERSION_SIZE,mcuVer,RELEASE_VERSION_SIZE);
    return BSP_OK;
}
UINT32 test_Bsp_WfsVersionMcuString_MTS(INT32 iChipID)
{
    CHAR mcuVer[RELEASE_VERSION_SIZE] = {0};
    UINT32 retVal = BSP_OK;
    //CHAR *mcuVer = NULL;
    retVal = Bsp_WfsVersionMcuString_MTS(iChipID,mcuVer);
    dbgInfo("MTS MCU VERSION IS %s \n",mcuVer);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetPllFreq_MTS(*)
 *  功能描述: 获取MTS不同pll的频点
 *  输入参数: chip         -- 芯片号
 *          : freqBand -- 频段
 *          : pllId    -- 本振号
 *  输出参数: pFreq        -- 本振频点
 *  返 回 值: char版本指针
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *---------------------------------------------------------------------------*/
UINT32 Bsp_WfsGetPllFreq_MTS(UINT32 chipId, INT32 pllId)
{
    UINT32 freqBand = 0;
    UINT32 pllFreq = 0;

    pllFreq = BspGetTransceiverPllFreq(chipId, freqBand, pllId);
    dbgInfoEx("[%s] MTS%d bank%d PLL FREQ-[%d]\n",__func__,chipId,freqBand,pllFreq);
    return pllFreq;
}


/*****************************************************************************
 *  函数名称   : Bsp_WfsGetSocTemp_MTS(*)
 *  功能描述: 获取MTS温度
 *  输入参数: chip         -- 芯片号
 *  输出参数:
 *  返 回 值:
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *---------------------------------------------------------------------------*/
UINT32 Bsp_WfsGetSocTemp_MTS(UINT32 chipId,INT32 *pTemp)
{
    INT32 temp = 0;
    UINT32 ret =BSP_OK;
    ret = MTS_GetSocTemp(chipId, &temp);
    *pTemp = temp/10;
    dbgInfoEx("[%s] MTS%d soctemp %d  %d(°C)\n",__func__,chipId,temp,*pTemp);
    return ret;
}

UINT32 Bsp_WfsSetNcoFreq_MTS(UINT32 chipId, UINT32 chan, UINT32 dir, INT32 freq)
{
    UINT32 ret = 0;

    ret = BspSetTransceiverNcoFreq(chipId, chan, dir, freq);
    return ret;
}

INT32 Bsp_WfsGetNcoFreq_MTS(UINT32 chipId, UINT32 chan, UINT32 dir)
{
    INT32 freqNco = 0;

    freqNco = BspGetTransceiverNcoFreq(chipId, chan, dir);
    dbgInfoEx("[%s] MTS:%d freqNco:%d\n",__FUNCTION__,chipId,freqNco);
    return freqNco;
}

/**********************************************************************/
/**
 * @brief 频点修改的接口
 *
 * @param chip        chip id
 * @param txFreq      下行频点
 * @param rxFreq      上行频点
 *
 * @return   返回值
 */
/**********************************************************************/
/* Started by AICoder, pid:x051dx83d7i638c1431f0afb10f8e8198b16d2f8 */
INT32 Bsp_WfsMtsFreqChangeCali(INT32 chip, UINT32 txFreq, UINT32 rxFreq)
{
    return MTS_FreqChangeCali(chip, txFreq, rxFreq);
}
/* Ended by AICoder, pid:x051dx83d7i638c1431f0afb10f8e8198b16d2f8 */

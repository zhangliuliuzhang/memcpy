/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : mts_maintenance.h
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 赵首祯
* 创建日期 : 2021-11-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 赵首祯
* 修改日戳: 2021-11-20 10:30:00
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef PLATFORM_BSP_FUNCLIB_MTS_MTS_10_INCLUDE_MTS_MAINTENANCE_H_
#define PLATFORM_BSP_FUNCLIB_MTS_MTS_10_INCLUDE_MTS_MAINTENANCE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspGetMtsOperationStatus(INT32 chip, T_BspGetMtsStatusInfo *pGetMtsStaInfo);

#ifdef __cplusplus
}
#endif
#endif /* PLATFORM_BSP_FUNCLIB_MTS_MTS_10_INCLUDE_MTS_MAINTENANCE_H_ */

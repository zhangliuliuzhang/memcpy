/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : wfs.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "boardid.h"
#include "funccommon.h"
#include "bsppub.h"
#include "mts2_common.h"
#include "mts2_spi.h"
#include "mts2_comm.h"
#include "mts2_orx.h"
#include "mts2_tx.h"
#include "mts2_rx.h"
#include "mts2_cals.h"
#include "mts2_dsp.h"
#include "mts2_gain.h"

#include "mts2_dcp.h"
#include "mts2_wfs.h"
#include "devdrv_transceiver.h"

#include "mts2_tempsensor.h"
#include "mts2_cals.h"
/**************************************************************************
 *                            宏                                          *
 **************************************************************************/
#define  RELEASE_VERSION_SIZE    40

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                          静态变量定义                                   *
 **************************************************************************/


/******************************************************************************
 * 函数名称   : Bsp_WfsGetCaliSta_MTS(*)
 * 功能描述   : MTS命令获取rho值和aftrho值
 * 读全局变量 : 无
 * 写全局变量 : 无
 * 输入参数   : iChipID: 芯片ID
 *             iCaliModeIndex: 校准索引  RXQECDC索引值为6
 *             iChNum: chan号
 *             iSubModeIndex: 获取值索引 校准状态索引值为0
 *             *piRetVal: msg返回值
 * 输出参数   : 无
 * 返 回 值   : BSP_OK 表示正常，其它表示异常
 * 其它说明   :
 * ----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 ******************************************************************************
 */
UINT32 Bsp_WfsGetCaliSta_MTS2(INT32 iChipID,INT32 iCaliModeIndex,INT32 iChNum,INT32 iSubModeIndex,INT32 *piRetVal)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(piRetVal);
    retVal = MTS2_GetCaliSta(iChipID,iCaliModeIndex,iChNum,iSubModeIndex,piRetVal);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsStopTrackingCali_MTS(*)
 *  功能描述   : 对MTS一个芯片 停止跟踪校准
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip  chip id
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsStopTrackingCali_MTS2(INT32 chip)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)MTS2_StopTrackingCali(chip);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsStartTrackingCali_MTS(*)
 *  功能描述   : 对MTS的一个通道开启跟踪校准
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip  chip id
 *                : chan   mts chan
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsStartTrackingCali_MTS2(INT32 chip, INT32 chan)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)MTS2_StartChanTrackingCali(chip,chan);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSwitchAgc_MTS(*)
 *  功能描述   : 设置vga模式
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip     chip id
 *               vgamode   0:agc 1:mgc1 2:mgc2 3:manual
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsSwitchAgc_MTS2(INT32 chip,UINT32 vgaMode)
{
    UINT32 retVal = BSP_OK;
    retVal = MTS2_SwitchAgc(chip, vgaMode);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsMcuCall_MTS(*)
 *  功能描述   : MTS mcu命令调用
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip     chip id
 *               *func   具体命令，命令外需加""
 *               如Bsp_WfsMcuCall_MTS(0,"cali 2,sw") 具体如下
 *               cali 2,sw  打开/关闭MTS跟踪校准 sw=0关，sw=1开
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsMcuCall_MTS2(int chip, char *func)
{
    INT32 callRet = 0;
    UINT32 funcRet = 0;
    INPUT_POINTER_CHECK(func);
    funcRet = (UINT32)mts2call(chip, func, &callRet);
    dbgInfoEx("%s funcRet:%#x callRet:%#x\n", __FUNCTION__, funcRet, callRet);
    funcRet |= (UINT32)callRet;
    return funcRet;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSetVgaManAttVal_MTS(*)
 *  功能描述   : mpw 0.3 数字设置 rxatt
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 数字rxatt设置值 0-31
 *  输出参数   : 无
 *  返 回 值   : fb att对应的 index值
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsSetVgaManAttVal_MTS2(INT32 chip,UINT32 Chan,UINT32 VgaManAttVal)
{
    UINT32 retVal = BSP_OK;
    retVal =  Mts2SetVgaManAttVal(chip, Chan, VgaManAttVal);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSetPllFreq_MTS(*)
 *  功能描述   : 设置本振频点-对外接口
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip      chip id
 *             : pllSel    pll类型，0 rx, 1 tx, 2 aux
 *             : freq      频点
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsSetPllFreq_MTS2(INT32 chip, UINT32 bank, mts2PllType_t pllSel, UINT32 cfgFreq)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)Mts2SetPllFreq(chip, bank, pllSel, cfgFreq);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsSetAuxSourcetoRxLink_MTS(*)
 *  功能描述   : aux做源连接到rx链路的开关控制
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip   chip id
 *             : chan     通道
 *             : sw      关0  开1
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/

UINT32 Bsp_WfsSetAuxSourcetoRxLink_MTS2(INT32 chip, UINT32 chan, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    retVal =  (UINT32)Mts2SetAuxSourcetoRxLink(chip, chan, sw);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetVgaDpdhhTh_MTS(*)
 *  功能描述   : 读取MTS dpd门限值
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数       : chip   chip id
 *             : chan     通道
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetVgaDpdhhTh_MTS2(INT32 chip, UINT32 Chan)
{
    UINT32 retVal = 0;
    retVal =  Mts2GetVgaDpdhhTh(chip, Chan);
    return retVal;
}
/*****************************************************************************
 *  函数名称   : Bsp_WfsSetVgaDpdhhTh_MTS(*)
 *  功能描述   : 设置MTS dpd门限值
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *            : VgaDpdhhTh 门限值 0xE3：-1dBfs（推荐），0xCA：-2dBfs，0xB4：-3dBfs
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsSetVgaDpdhhTh_MTS2(INT32 chip, UINT32  Chan, UINT32 VgaDpdhhTh)
{
    UINT32 retVal = BSP_OK;
    retVal =  Mts2SetVgaDpdhhTh(chip, Chan, VgaDpdhhTh);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetVgaDpdhhAlarm_MTS(*)
 *  功能描述   : 读取历史D_PD告警
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetVgaDpdhhAlarm_MTS2(INT32 chip,UINT32 Chan)
{
    UINT32 retVal = BSP_OK;
    retVal =  Mts2GetVgaDpdhhAlarm(chip, Chan);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsClrVgaDpdhhAlarm_MTS(*)
 *  功能描述   : 清除D_PD告警
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *            : ClrDpdhhAlm 1清，0不清
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : ClrDpdhhAlm需先配1再配0
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsClrVgaDpdhhAlarm_MTS2(INT32 chip,UINT32 Chan,UINT32 ClrDpdhhAlm)
{
    UINT32 retVal = BSP_OK;
    retVal =  Mts2ClrVgaDpdhhAlarm(chip, Chan, ClrDpdhhAlm);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsDiagnose_MTS(*)
 *  功能描述   : 查看mts的各个模块的状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : option 1(Analog State) 2(Interface status) 3(Algorithm calibration)
 *  输出参数       : 无
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsDiagnose_MTS2(INT32 chip,INT32 option)
{
    UINT32 retVal = BSP_OK;
    retVal = (UINT32)Mts2Diagnose(chip, option);
    return retVal;
}


/*****************************************************************************
 *  函数名称   : Bsp_WfsGetRxCalIRR_MTS(*)
 *  功能描述   : 获取通道chan的IRR值,单位：dBc
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *
 *  输出参数   : *pfIRR  IRR值，单位：dBc
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetRxCalIRR_MTS2(INT32 iChipID,INT32 iChNum,float *pfIRR)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pfIRR);
    retVal = (UINT32)MTS2_GetRxCalIRR(iChipID, iChNum,pfIRR);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetRxDcDbfs_MTS(*)
 *  功能描述   : 获取通道chan的DC值, 单位：dBFs
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *            : chan     通道
 *
 *  输出参数   : *pfDbfs  DC值，单位：dBFs
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsGetRxDcDbfs_MTS2(INT32 iChipID,INT32 iChNum,float *pfDbfs)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pfDbfs);
    retVal = (UINT32)MTS2_GetRxDcDbfs(iChipID, iChNum,pfDbfs);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsEfuseReVal_MTS(*)
 *  功能描述   : 获取EFUSE信息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chip   chip id
 *  输出参数   : *EfuseVal  EFUSE信息，长度16个UINT32
 *  返 回 值   : BSP_OK 表示正常，”1”表示过门限告警
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsEfuseReVal_MTS2(INT32 chip,UINT32 *EfuseVal,char *TestTime, char *TestMachine, char *TestVersion)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(EfuseVal);
    INPUT_POINTER_CHECK(TestTime);
    INPUT_POINTER_CHECK(TestMachine);
    INPUT_POINTER_CHECK(TestVersion);

    retVal = (UINT32)Mts2EfuseReVal(chip, EfuseVal);
    retVal |= (UINT32)Mts2GetEfuseTestTime(chip, TestTime);
    retVal |= (UINT32)Mts2GetEfuseTestMachine(chip, TestMachine);
    retVal |= (UINT32)Mts2GetEfuseTestVersion(chip, TestVersion);

    return retVal;
}
UINT32 test_Bsp_WfsEfuseReVal_MTS2(INT32 chip)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 EfuseVal[32] = {0,};
    char TestTime[64] = {0,};
    char TestMachine[64] = {0,};
    char TestVersion[64] = {0,};

    retVal = (UINT32)Bsp_WfsEfuseReVal_MTS2(chip, EfuseVal, TestTime, TestMachine, TestVersion);
    for(loop = 0; loop<32; loop++)
    {
        dbgInfo("0x%08x ",EfuseVal[loop]);
        if(0 == ((loop+1)%4))
        {
            dbgInfo("\n");
        }
    }

    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsVersionHostString_MTS(*)
 *  功能描述   : 获取MTS HOST VERSION
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : char版本指针
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsVersionHostString_MTS2(CHAR* ver)
{
    CHAR *hostVer = NULL;
    INPUT_POINTER_CHECK(ver);
    hostVer = Mts2VersionHostString();
    INPUT_POINTER_CHECK(hostVer);
    memcpy_s(ver,RELEASE_VERSION_SIZE,hostVer,RELEASE_VERSION_SIZE);
    return BSP_OK;
}
UINT32 test_Bsp_WfsVersionHostString_MTS2(void)
{
    CHAR hostVer[RELEASE_VERSION_SIZE] = {0};
    UINT32 retVal = BSP_OK;
    //CHAR *hostVer=NULL;
    retVal = Bsp_WfsVersionHostString_MTS2(hostVer);
    dbgInfo("MTS HOST VERSION IS %s \n",hostVer);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsVersionMcuString_MTS2(*)
 *  功能描述   : 获取MTS MCU VERSION
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : char版本指针
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *----------------------------------------------------------------------------
*/
UINT32 Bsp_WfsVersionMcuString_MTS2(INT32 iChipID, CHAR* ver)
{
    CHAR *mcuVer = NULL;
    INPUT_POINTER_CHECK(ver);
    mcuVer = Mts2VersionMcuString(iChipID);
    INPUT_POINTER_CHECK(mcuVer);
    memcpy_s(ver,RELEASE_VERSION_SIZE,mcuVer,RELEASE_VERSION_SIZE);
    return BSP_OK;
}
UINT32 test_Bsp_WfsVersionMcuString_MTS2(INT32 iChipID)
{
    CHAR mcuVer[RELEASE_VERSION_SIZE] = {0};
    UINT32 retVal = BSP_OK;
    //CHAR *mcuVer = NULL;
    retVal = Bsp_WfsVersionMcuString_MTS2(iChipID,mcuVer);
    dbgInfo("MTS MCU VERSION IS %s \n",mcuVer);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetPllFreq_MTS(*)
 *  功能描述: 获取MTS不同pll的频点
 *  输入参数: chip         -- 芯片号
 *          : freqBand -- 频段
 *          : pllId    -- 本振号
 *  输出参数: null
 *  返 回 值: pFreq        -- 本振频点
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *---------------------------------------------------------------------------*/
UINT32 Bsp_WfsGetPllFreq_MTS2(UINT32 chipId, UINT32 freqBand, INT32 pllId)
{
    UINT32 pllFreq = 0;
    pllFreq = BspGetTransceiverPllFreq(chipId, freqBand, pllId);
    dbgInfoEx("[%s] MTS%d bank%d PLL FREQ-[%d]\n",__func__,chipId,freqBand,pllFreq);
    return pllFreq;
}
/*****************************************************************************
 *  函数名称   : Bsp_WfsGetSocTemp_MTS(*)
 *  功能描述: 获取MTS温度
 *  输入参数: chip         -- 芯片号
 *  输出参数:
 *  返 回 值:
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *	$0000000(N/A), heruihua 10288704@2021-02-22 11:00 创建
 *---------------------------------------------------------------------------*/
UINT32 Bsp_WfsGetSocTemp_MTS2(UINT32 chipId,INT32 *pTemp)
{
    INT32 temp = 0;
    UINT32 ret = BSP_OK;
    ret = MTS2_GetPosTemp(chipId, 18, &temp);
    *pTemp = temp/10;
    dbgInfoEx("[%s] MTS%d soctemp %d  %d(°C)\n",__func__,chipId,temp,*pTemp);
    return ret;
}

/**
******************************************************************************
* @name    Bsp_WfsMTS2_IsSysrefValid
* @brief   MTs2SysRef是否有效判断
* @param   chipId: 芯片号
* @return  BSP_OK 配置成功
*          BSP_ERROR 配置失败
* @author
* @date
******************************************************************************/
UINT32 Bsp_WfsMTS2_IsSysrefValid(INT32 chipId)
{
    if(1 == MTS2_IsSysrefValid(chipId))
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}

/**
******************************************************************************
* @name    Bsp_WfsMtS2FreqChangeBankCali
* @brief   MTs2变本振接口
* @param chip        chip id
* @param bank        bank号
* @param TxFreq      修改的tx本振频点
* @param RxFreq      修改的rx本振频点
* @return 返回值
* @author
* @date
******************************************************************************/
/* Started by AICoder, pid:r8a53s2026n56a31466e09ec20eb4212f215dca2 */
INT32 Bsp_WfsMtS2FreqChangeBankCali(INT32 chip, UINT32 bank, UINT32 txFreq, UINT32 rxFreq)
{
    return MTS2_FreqChangeBankCali(chip, bank, txFreq, rxFreq);
}
/* Ended by AICoder, pid:r8a53s2026n56a31466e09ec20eb4212f215dca2 */

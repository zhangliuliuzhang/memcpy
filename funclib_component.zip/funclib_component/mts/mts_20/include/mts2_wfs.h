/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : wfs.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了工装接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _FUNCLIB_MTS2_WFS_H_
#define _FUNCLIB_MTS2_WFS_H_

#include "mts2_common.h"

#ifdef __cplusplus
extern "C" {
#endif

UINT32 Bsp_WfsGetCaliSta_MTS2(INT32 iChipID,INT32 iCaliModeIndex,INT32 iChNum,INT32 iSubModeIndex,INT32 *piRetVal);
UINT32 Bsp_WfsStopTrackingCali_MTS2(INT32 chip);
UINT32 Bsp_WfsStartTrackingCali_MTS2(INT32 chip, INT32 chan);
UINT32 Bsp_WfsSwitchAgc_MTS2(INT32 chip,UINT32 vgaMode);
UINT32 Bsp_WfsMcuCall_MTS2(int chip, char *func);
UINT32 Bsp_WfsSetVgaManAttVal_MTS2(INT32 chip,UINT32 Chan,UINT32 VgaManAttVal);
UINT32 Bsp_WfsSetPllFreq_MTS2(INT32 chip, UINT32 bank, mts2PllType_t pllSel, UINT32 cfgFreq);
UINT32 Bsp_WfsSetAuxSourcetoRxLink_MTS2(INT32 chip, UINT32 chan, UINT32 sw);
UINT32 Bsp_WfsGetVgaDpdhhTh_MTS2(INT32 chip, UINT32 Chan);
UINT32 Bsp_WfsSetVgaDpdhhTh_MTS2(INT32 chip, UINT32  Chan,UINT32  VgaDpdhhTh);
UINT32 Bsp_WfsGetVgaDpdhhAlarm_MTS2(INT32 chip,UINT32 Chan);
UINT32 Bsp_WfsClrVgaDpdhhAlarm_MTS2(INT32 chip,UINT32 Chan,UINT32 ClrDpdhhAlm);
UINT32 Bsp_WfsDiagnose_MTS2(INT32 chip,INT32 option);
UINT32 Bsp_WfsGetRxCalIRR_MTS2(INT32 iChipID,INT32 iChNum,float *pfIRR);
UINT32 Bsp_WfsGetRxDcDbfs_MTS2(INT32 iChipID,INT32 iChNum,float *pfDbfs);
UINT32 Bsp_WfsEfuseReVal_MTS2(INT32 chip,UINT32 *EfuseVal,char *TestTime, char *TestMachine, char *TestVersion);
UINT32 test_Bsp_WfsEfuseReVal_MTS2(INT32 chip);
UINT32 Bsp_WfsVersionHostString_MTS2(CHAR* ver);
UINT32 test_Bsp_WfsVersionHostString_MTS2(void);
UINT32 Bsp_WfsVersionMcuString_MTS2(INT32 iChipID, CHAR* ver);
UINT32 test_Bsp_WfsVersionMcuString_MTS2(INT32 iChipID);
UINT32 Bsp_WfsGetPllFreq_MTS2(UINT32 chipId, UINT32 freqBand, INT32 pllId);


#ifdef __cplusplus
}
#endif
#endif 


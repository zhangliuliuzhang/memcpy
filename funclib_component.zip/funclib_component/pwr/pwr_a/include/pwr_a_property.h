

#ifndef  PWR_A_PROPERTY_H
#define PWR_A_PROPERTY_H

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "pwr_a.h"
typedef struct tag_tPwrVoltVoltAlmThre
{
    UINT32 pwrType;
    INT32  pwrAlmThre[4];
}T_PwrVoltVoltAlmThre;

UINT32 BspGetPwrEnableTime(UINT8 *pStrTime, UINT32 ulStrLen);

#ifdef __cplusplus
}
#endif


#endif /* #ifndef  PWR_A_PROPERTY_H */

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pwr_a.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了电源接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_PWR_H_
#define _FUNCLIB_PWR_H_
#define BSP_BIT(n)      (1UL << (n))  /* 对bit[n]掩码 */


#ifdef __cplusplus
extern "C" {
#endif

#include "pwrapi.h"
#include "ru_univdef.h"
#include "pwrcommon.h"
#include "funccommon_log.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/

#define MAX_FILENAME_SIZE        30
#define CRC16_PWR_INIT_VAL       0xFFFF

#define PwrUpdateFileName    "/ata/pwr.ini" /*电源版本升级状态文件*/
#define FLAG_PWR_UPDATE     "UpgreadFlag"
#define PWR_TEXTFILE_PATH     "/pwrupdate/pwr.txt"
#define PWR_VERSION_PATH      "/ata/pwr.swv"
#define PWR_VERSION_PATH_ROOT "/pwrupdate/pwr.swv"
#define PWR_VERSION_PATH1_ROOT "/pwrupdate1/pwr.swv"  /*双电源版本场景*/
#define PWR_VER_PATH_MAX_LEN    (UINT32)(50)
#define PWR_VER_PATH_SET        (UINT32)(9)
#define PWR_VER_PATH_ROOT       (UINT32)(3)

#define VERFILEHEADER   0x1
#define SUBUNITHEADER   0x2

#define UPDATE_MODE     0x0
#define UPDATE_DONE     0x1

#define PKG_UPGRADE_SUCC 0x1
#define PKG_UPGRADE_FAIL 0x2

#define SUBUNIT_VER_SAME                0
#define SUBUNIT_VER_OUTRANGE            1
#define SUBUNIT_VER_NEED_UPGRADE        2
#define SUBUNIT_NAME_NO_SAME            3
#define SUBUNIT_HARDWARE_VER_NO_SAME    4
#define SUBUNIT_MANUFACTORNO_NO_SAME    5
#define SUBUNIT_VER_OVER                6
#define SUBUNIT_VER_HEAD_CRC_FAIL       7
#define SUBUNIT_NOT_EXIT                8 /*电源砖不存在*/

#define PWR_VER_COMPARE_SUCCESS         0
#define PWR_VER_COMPARE_FAILED          1
#define PWR_VER_NEED_UPDATE             1
#define PWR_VER_NONEED_UPDATE           3
#define PWR_UPDATE_SUCCESS              1
#define PWR_UPDATE_FAILED               2

#define PWR_PARA_ERROR        1
#define PWR_CRC_ERROR         2
#define PWR_GET_SEM_ERROR     3

#define MAX_PWR_VER_NUM       10
#define PWR_HEAD_LEN          128              /*版本头长度128*/
#define MAX_VER_LINE_LEN      256              /*最大版本行长度*/
#define PWR_EEPROM_NAME_LEN   16                //大板电源，15字节
#define PWR_SUBUNIT_VER_LEN   8                 //电源组件版本号，7字节
#define PWR_SUB_NAME_LEN      11
#define PWR_SUB_NAME_LEN_MAX      16//大板电源单板名
#define PWR_SUB_SUB_NAME_LEN_MAX  32
#define PWR_SUB_VER_LEN       5
#define PWR_SOFT_VER_LEN      6
#define PWR_FACTORYNO_LEN     9                 //生产厂家，8字节
#define PWR_VER_PKG_LEN       20
#define PWR_BARCODE_LEN       13
#define PWR_MODULE_LEN        12               /*电源12位组件条码长度*/
#define MouduleVer_LEN        4
#define MAX_PWRVER_LINE_LEN   15
#define MAX_PWR_MANU_PRODUCT_INFO_LEN 20

#define EEPROM_ON_PWR_MODULE_VER_CHECK_SUM      0x20    //电源组件版本号校验和，1字节
#define EEPROM_ON_PWR_MANUFECTURER_CHECK_SUM    0x18    //生产厂家检验和，1字节
#define EEPROM_ON_PWR_NAME_CHECK_SUM            0x0F    //大板电源校验和，1字节

#define  EEPROM_ON_PWR_BARCODE                 0x12    //电源12位组件条码
#define  EEPROM_ON_PWR_MANUFECTURER_NUM        0x57    //生产厂家编号，8字节
#define  EEPROM_ON_PWR_MODULE_VER              0xA8    //电源组件版本号，7字节
#define  EEPROM_ON_PWR_AUX_MODULE_NAME         0xB7    //辅助组件名称，5字节

#define  EEPROM_ON_PWR_NAME_NEW                   0x00    /*大板电源名称 15字节*/
#define  EEPROM_ON_PWR_MANUFECTURER_NUM_NEW       0x10    //生产厂家编号，8字节
#define  PWR_MON_TYPE_NUM   10
#define  PWR_MON_CHIP_NUM   10

#define  PWR_CRC_BITS                      4
#define  PWR_CRC_AND_SUM_BITS              12
#define  PWR_HEAD_CHK_FAIL                 1
#define  PWR_SUB_PKG_CRC_CHK_FAIL(x)       (1<<(x))
#define  PWR_SUB_PKG_HEAD_CRC_CHK_FAIL     PWR_SUB_PKG_CRC_CHK_FAIL(0)
#define  PWR_SUB_PKG_MCU_CRC_CHK_FAIL      PWR_SUB_PKG_CRC_CHK_FAIL(1)

#define  PWR_SUB_PKG_SUM_CHK_FAIL(x)       (1<<(x+PWR_CRC_BITS))
#define  PWR_SUB_PKG_HEAD_SUM_CHK_FAIL     PWR_SUB_PKG_SUM_CHK_FAIL(0)
#define  PWR_SUB_PKG_MCU_SUM_CHK_FAIL      PWR_SUB_PKG_SUM_CHK_FAIL(1)
#define  PWR_SUM_CHK_FAIL_LINE(y)          ((y)<<PWR_CRC_AND_SUM_BITS)

#define  PWR_VER_CHK_FAIL                  1<<8

#define  UPDATE_TRY_TIMES                  (UINT32)(4)

/*电源过温告警添加*/
#define PWR_SLIGHT_OVER_TEMP_ALM(x)    ((UINT32)1 << (x))  /*轻微过温*/
#define PWR_OVER_TEMP_ALM(x)           ((UINT32)1 << (x))  /*严重过温*/
#define PWR_TEMP_NORMAL(x)             (~((UINT32)1<<(x))) /*温度正常*/
#define PWR_HISTORY_SET_TIME_LEN           ((UINT32)4)
#define PWR_LINE_ADDR_ERR_DBG                                    ((UINT32)0x41)  /*打印行地址错误信息*/
#define PWR_LINE_DATA_ERR_DBG                                     ((UINT32)0x44)  /*打印行数据错误信息*/
#define PWR_LINE_ADDR_LENTH                                          ((UINT32)0x02)  /*行地址字节长度*/
#define LINE_ADDR_BUF_DEFAULT_VALUE                     ((UINT32)0xff)  /*行地址读buf设置默认值*/
#define LINE_DATA_BUF_DEFAULT_VALUE                      ((UINT32)0x00)  /*行数据读buf设置默认值*/


#define PWR_UPDATE_TRY_TIMES                                       ((UINT32)0x03)  /*电源升级尝试次数*/
#define PWR_ACT_UPDATE_TRY_TIMES                           ((UINT32)0x03)  /*电源触发升级尝试次数*/
#define PWR_EXIT_UPDATE_TRY_TIMES                          ((UINT32)0x03)  /*电源退出升级尝试次数*/
#define PWR_LINE_DATA_RW_TRY_TIMES                      ((UINT32)0x03)  /*电源行数据尝试次数*/
#define PWR_LINE_ADDR_RW_TRY_TIMES                     ((UINT32)0x03)  /*电源行地址尝试次数*/

#define PWR_EETAB_BOARD_NAME_ADDR                     ((UINT32)0x00)  /*电子标签单板名称地址*/
#define PWR_EETAB_BOARD_NAME_LEN                        ((UINT32)0x10)  /*电子标签单板名称地址*/

#define PWR_NEED_UPDATE                    ((UINT32) 1)/*电源需要升级标志*/
#define PWR_NONEED_UPDATE                  ((UINT32) 0)/*电源不需要升级标志*/
#define PWR_PARSE_FILE_UPDATE_FAILED       ((UINT32) 2)/*电源解析文件中所记录电源升级失败标志*/
#define PWR_PARSE_FILE_NEED_UPDATE         ((UINT32) 3)/*电源解析文件中所记录电源需要进行升级标志*/
#define PWR_BARCODE_SAME_FLAG              ((UINT32) 1)/*获取的电源条码与电源解析文件条码相同标志*/
#define PWR_SUPPORT_SMART_POWEROFF_ABILITY ((UINT32) 0x1)/*电源已经支持智能下电标志*/
#define PWR_SELF_RESCUE_DISEN              ((UINT8)  0x0)/*电源自救去使能*/
#define PWR_SELF_RESCUE_EN                 ((UINT8)  0x1)/*电源自救使能*/

/*供电能力不足相关宏*/
/*整机是否支持供电能力不足功能*/
#define PWR_SUPPORT_VINDOWN_YES              ((UINT32)(1))
#define PWR_SUPPORT_VINDOWN_NO               ((UINT32)(0))
/*上电Vindown检测次数*/
#define PWR_VINDOWN_DETECT_CNT               ((UINT32)(5))
/*VIndown检测时间200MS*/
#define PWR_VINDOWN_DETECT_CYCLE             ((UINT32)(200))
/*读取电源过温告警后，清除告警寄存器地址*/
#define PWR_OVERTMEPWARNING_CLEAR            (0x3)

#define  PA_PWR_MAX_NUM                      (64)     /* pa电源最大数量 */

#define INPUTCURRENT_CAL_OBTAIN              (0x1)  /* 整机输入电流通过功耗除电压计算方式获取 */
#define INPUTCURRENT_OBTAIN_BY_SYSTEM        (0x0)  /* 整机输入电流通过电源系统直接获取 */
/**************************************************************************
 *                         数据类型
 **************************************************************************/
#pragma pack(1)
typedef struct tagT_PwrSubUnitHeader
{
    UINT32  ulHeaderLen;
    USHORT usSubUnitNum;
    UINT32* pulSubUnitLen;
    USHORT usCheckSum;
}T_PwrSubUnitHeader;

typedef struct tagT_PwrVoltAlmThr
{
    UINT32 pwrType;
    UINT32 voltType;
    LONG lowVoltAlmThr;
    LONG lowVoltRecThr;
    LONG highVoltAlmThr;
    LONG highVoltRecThr;
}T_PwrVoltAlmThr;

typedef struct tagT_PwrSubVerInfo
{
    UCHAR  ucSubUnitName[PWR_SUB_NAME_LEN_MAX];
    UCHAR  ucSubUnitVer[PWR_SUB_VER_LEN];
    UCHAR  ucSubUnitNo;
    UCHAR  ucManuFactoryNo[PWR_FACTORYNO_LEN];
    UCHAR  ucProgramVer[PWR_SUB_VER_LEN];
    UCHAR  ucOldProgramVer[PWR_SUB_VER_LEN];
    UCHAR  ucMinProgramVer[PWR_SUB_VER_LEN];
    UCHAR  ucMaxProgramVer[PWR_SUB_VER_LEN];
    UINT32  ulLineSize;
    UINT32  ulMinLineAddr;
    UINT32  ulMaxLineAddr;
    UINT32  ulMauLenSize;
    UINT32  ulProgramCheckSum;
    UINT32  ulFileCheckSum;
}T_PwrSubVerInfo;
/*大板电源子组件头*/
typedef struct tagT_PwrSubVerInfoNew
{
    UCHAR  ucSubUnitName[PWR_SUB_NAME_LEN_MAX];
    UCHAR  ucSubUnitVer[PWR_SUB_VER_LEN];
    UCHAR  ucSubUnitNo;
    UCHAR  ucManuFactoryNo[PWR_FACTORYNO_LEN];
    UCHAR  ucSubSubUnitName[PWR_SUB_SUB_NAME_LEN_MAX];
    UCHAR  ucProgramVer[PWR_SUB_VER_LEN];
    UCHAR  ucOldProgramVer[PWR_SUB_VER_LEN];
    UCHAR  ucMinProgramVer[PWR_SUB_VER_LEN];
    UCHAR  ucMaxProgramVer[PWR_SUB_VER_LEN];
    UINT32  ulLineSize;
    UINT32  ulMinLineAddr;
    UINT32  ulMaxLineAddr;
    UINT32  ulMauLenSize;
    UINT32  ulProgramCheckSum;
    UINT32  ulFileCheckSum;
}T_PwrSubVerInfoNew;
/* 版本头结构 */
typedef struct tagT_Ver_File_Header_Pwr {
    UINT32   ulCRC32;            /* 加上版本头之后的CRC值（从这个字段之后一直到版本末尾）*/
    UINT32   ulHeaderVersion;    /* 版本头的版本号*/
    USHORT   usVerType;          /* 版本类型: $(TypeId_001_003) */
    UCHAR    ucCpuType;          /* 版本的CPU类型: $(TypeId_001_001) */
    UCHAR    ucReserved0;        /* 0:非压缩或者压缩算法为1：压缩算法为lzma */
    UINT32   ulCompressedSize;   /* 版本压缩之后的大小(Bytes) */
    UINT32   ulCompressedCRC;    /* 版本压缩之后的CRC */
    UINT32   ulOriginalSize;     /* 版本压缩前原始大小 */
    UINT32   ulOriginalCRC;      /* 版本压缩前原始CRC */
    UINT32   ulSoftType;         /* 版本的软件板类型 */
    UCHAR    ucVerNo[VERNO_LEN]; /* 版本文件的版本号 */
    UINT32   ulCreateTime;       /* 版本创建时间 */
    UCHAR    ucPackedFile;       /* 版本是否打包标识(TypeId_001_004) */
    UCHAR    ucPackedFileNum;    /* 打包文件数目 */
    UCHAR    ucReserved1[46];    /* 保留 */
} T_VerFileHeader_Pwr;

typedef struct tagT_Ver_IR_Header_Pwr {
    UINT32   ulCRC32;            /* 加上版本头之后的CRC值（从这个字段之后一直到版本末尾）*/
    UINT32   ulHeaderVersion;    /* 版本头的版本号，第一版固定为0x01010101,三层平台版本改为0x02020202*/
} T_VerIRHeader_Pwr;

typedef struct tagT_Pwr_VerPkg_header {
    UINT32   ulPkgHeadLen;
    USHORT  usVerNum;
    UINT32   ulPkgLen[PWR_VER_PKG_LEN];
    USHORT  usCrcSum;        /*包头累加和*/
} T_Pwr_VerPkg_Pwr;

typedef struct
{
    CHAR        acName[MAX_FILENAME_SIZE]; /*  这个必须写30,与boot一致 */
    CHAR        cFlag;
    CHAR        cValue;
    CHAR        cEnd;
} TVerFileCfgInfo, *PTVerFileCfgInfo;

typedef struct T_tagPwrVerHead
{
	UINT32 ulAddr;
	CHAR   cLineData[MAX_VER_LINE_LEN];
	UCHAR  ucLineInfoSize;
}T_PwrVerHead;
#pragma pack()

/*电源名称*/
enum pwrTypeName
{
    E_togetherPwrType = 0,  /*定制电源　一个IIC访问地址　*/
    E_seperatePwrType,      /*独立电源　类9234　9224*/
    E_seperatePwrType1,     /*独立电源　类9222　　　*/
};
/*电源类型结构体*/
#define SUB_PWR_MODULE_NUM   8
typedef struct  pwr_type
{
    enum  pwrTypeName pwrTypeName ;
    UINT32 subPwrModeMaxNum;
    UINT32 pwrTopology[SUB_PWR_MODULE_NUM];
    UINT32 pwrPkgHeadChk;
    UINT32 pwrPkgCrcChk[SUB_PWR_MODULE_NUM];
    UINT32 pwrUpdateFlag[SUB_PWR_MODULE_NUM];
    UINT32 pwrForceUpdateFlag[SUB_PWR_MODULE_NUM];
} T_PwrTypeStruct;

typedef struct tagT_PwrTempAlarmDefPaPara
{
    INT32 PwrHighOverTempThreshold;  //严重过温门限 默认值
    INT32 PwrHighOverTempRechold;  //严重过温门限 恢复值
    INT32 PwrSlightOverTempThrehold;  //轻微过温门限 默认值
    INT32 PwrSlightOverTempRechold;  //轻微过温门限 恢复值
}T_PwrTempAlarmDefPaPara;

typedef struct
{
    UINT32 nodeNo;  /*电源连接器节点索引号*/
    INT32  temp;    /*电源连接器节点温度*/
}T_PwrLetNodeTemp;

typedef struct
{
    UINT32 pwrLetNodeNum;                                /* 整机电源连接器节点数目 */
    T_PwrLetNodeTemp nodeTemp[PWR_MAX_PWRLET_NODE_NUM];  /* 电源连接器节点温度 */
}T_PwrLetTemp;

typedef struct
{
    UINT32 paChanMask[PWR_MAX_TEMP_NUM];  /* 电源节点轻微过温功放降额通道掩码 */
}T_PwrOverTempDerating;

typedef struct tagT_DefPaPara
{
    UINT32 ulPaVolt[BSP_MAX_TX_CHAN];
    UINT32 uDflTxInsertLoss[BSP_MAX_TX_CHAN];/* 双工差损 */
    UINT32 ulTempdelta;
}T_DefPaPara;

typedef UINT32 (*FUNC_GET_PWR_TPLG)(T_PwrTypeStruct * pPwrTplg);
typedef UINT32 (*pStaGetFunc)(UINT32 ulIdx,  UINT32 *pStatus);
typedef UINT32 (*pStaGetAllFunc)( UINT32 *pStatus);
typedef UINT32 (*FUNC_SET_PWR_ON)(UINT32 index,BOOL bPowerOn);
typedef UINT32 (*funcPowerI2cByPassCallBack)(UINT32 flag);
typedef UINT32 (*T_PwrCfgcPara)(UINT32  index, UINT32  cmd);
typedef UINT32 (*SET_SLAVE_PORT_PAVOLT)(UINT32 chan, UINT16 volt);
typedef UINT32 (*FUNC_GET_PWR_VOLT)(UINT32 index, INT32 *pVolt);

UINT32 BspRegisterAlmStaCall(pStaGetFunc pGetStatusCall);
UINT32 BspGetPwrStatus(UINT32 index, UINT32 *pStatus);
UINT32 BspGetMonitorPwrTemp(UINT32 index, INT32 * pTemp);
UINT32 BspGetMonitorPwrIn(UINT32 index, INT32 *pPower);
UINT32 BspGetMonitorPwrOut(UINT32 index, INT32 *pPower);
UINT32 BspGetMonitorPwrVoltIn(UINT32 index, INT32 *pVolt);
UINT32 BspGetMonitorPwrVoltOut(UINT32 index, INT32 *pVolt);
UINT32 BspGetMonitorPwrNominalVout(UINT32 index, INT32 *pVolt);
UINT32 BspWrMonitorPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 ucVal);
UINT32 BspRdMonitorPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 *pucVal);
UINT32 BspGetPwrPaBestVolt(UINT32 Index, INT32* pPaBestVolt);
UINT32 BspSetPwrOn(UINT32 index,BOOL bPowerOn);
UINT32 BspErasePwrEeprom(UINT32 devId, UINT32 offset, UINT32 eepromEraseData, UINT32 Length);
UINT32 ReadEepromPwrCode(UINT32 lineNum ,UINT32 startAddr,UINT32 startLine,UINT32 lineLength);
UINT32 PwrUpdateTestNew(VOID);
UINT32 BspGetSubUnitNameNew(UCHAR *pSubUnitName);
UINT32 BspGetPwrDevId(UINT32  SubSubUnitNo);
UINT32 BspSetPwrModulePaVolt(UINT32 index,INT32 volt);
UINT32 BspGetPwrModulePaVol(UINT32 index,INT32 *volt);
UINT32 BspSetPwrTempAlmThreshold(T_PwrTempAlarmDefPaPara *pPara);
T_PwrTempAlarmDefPaPara* BspGetPwrTempAlmThreshold(VOID);
VOID BspSetPwrOnCallBackInit(FUNC_SET_PWR_ON pfSetPwrOn);
UINT32 BspCheckSubUnitVerInfo(UINT32 ulPwrDevId, UINT32 ulSubIndex);
UINT32 BspSetPwrVinUvLimit(UINT32 index, INT32 Volt);
UINT32 BspPwrUpdateInit(VOID);
UINT32 BspGetPwrBarCode(UCHAR *ptPwrBarCode);
UINT32 BspSetPwrSwCfgFunc(T_PwrCfgcPara pFunc);
UINT32 BspGetPwrTypeName(UCHAR *pPwrTypeName);
UINT32 BspGetBoardNameFromPwrEeprom(CHAR*  buf, UINT32 len );
UINT32 BspSetPwrVolt(UINT32 index, INT32 Volt);
UINT32 BspGetTmpAlarm(UINT32 index, UINT32* pAlarm);
UINT32 BspSetPwrVoltLimit(UINT32 index, UINT32 voltType, INT32 Volt);
UINT32 BspGetPwrInSym(UINT32 index, UINT32* inputSymbol);
UINT32 BspSetPwrInSym(UINT32 index, UINT32 inputSymbol);
UINT32 BspGetPwrRstDelay(UINT32 index, UINT32* delayMs);
UINT32 BspSetPwrRstDelay(UINT32 index, UINT32 delayMs);
UINT32 BspGetPwrProInfo(UINT32 index, UINT32 ulInterChan, UINT32* uiStatus);
UINT32 BspGetPwrHisInfo(UINT32 index, UINT8 *strHis, UINT32 size);
UINT32 BspSetPwrTime(UINT32 index, UINT32 strTime, UINT32 size);
UINT32 BspSavePwrPara(UINT32 index);
INT32 BspGetPaVoltRealTime(UINT32 index);
UINT32 BspCheckPowerInputSymbol(VOID);
UINT32 BspCheckPowerDownStatus(VOID);
UINT32 BspCheckPowerHistoryInfo(VOID);
VOID BspSetPwrUpdateDly(UINT32 ulDly);
UINT32 BspGetPwrUpdateDly(VOID);
UINT32 BspPwrModuleVerCompare(VOID);
UINT32 BspPwrBarcodeCompare(VOID);
UINT32 BspPrnPwrVer(UINT32 ucSubUnitNo);
UINT32 BspGetPwrBarcode(VOID);
UINT32 BspIsNewPwrType(VOID);
UINT32 PwrUpdateNeed(UINT32 *needUpdateFlag);
UINT32 BspPwrVerPathChange(UINT32 pwrVerPathFlag);
UINT32 BspChagePwrBarCode(CHAR *pwrBarCode);
UINT32 BspWriteElectronicTabToEeprom(CHAR* boardname, CHAR* mfrno, CHAR* verno);
UINT32 EepromBytesReadTest(UINT32 ulDevId, UINT32 ulAddr, UINT32 ulLen, UINT32 ulTestTime);
UINT32 BspGetPwrResetDelay(UINT32 index, UINT32 *delayMs);
UINT32 BspSetPwrResetDelay(UINT32 index, UINT32 delayMs);
UINT32 BspGetPwrOverTempAlmStatus(UINT32 index, UINT32 rfChanNum, UINT32 *pStatus);
UINT32 BspGetPwrVoltAlarm(void);
UINT32 BspSetPwrVoltAlarm(UINT32 lLowAlmThre,UINT32 lLowRecThre,UINT32 lHighAlmThre,UINT32 lHighRecThre);
UINT32 BspGetPwrIoutStatus(UINT32 index, LONG *ulStatus);
UINT32 BspGetPwrMfrInfo(UINT32 ulIndex, CHAR *pcVal, UINT32 ulByteNum);
UINT32 BspGetPaTempDelta(INT32 *plPaTempDelta);
UINT32 BspGetPwrBarCodeInfo(UINT32 ulIndex, CHAR *pcVal, UINT32 ulByteNum);
UINT32 BspPaDefaultParaInit(T_DefPaPara *pInfo,UINT32 ulNum);
UINT32 BspGetPwrSlightOverTempAlmStatus(UINT32 index, UINT32 rfchanNum, UINT32 *pStatus);
UINT32 BspGetPwrTplgCallBack(FUNC_GET_PWR_TPLG pFuncCallback);
UINT32 BspRegisterPwrOverTempAlmStaAllCall(pStaGetAllFunc pGetStatusAllCall);
UINT32 PwrDirectUpdateTest(VOID);
VOID BspSetPwrForceUpdateFlag(UINT32 index, UINT32 fUpdateFlag);
UINT32 BspSetPowerI2cByPassCallBack(funcPowerI2cByPassCallBack pFuncCallback);
UINT32 BspPwrUpdateProcInit(VOID);
VOID BspGetPwrCurrInCallbackInit(Pwr_GetInt pFunc);
void BspGetPowerInCallbackInit(Pwr_GetPowerIn pFunc);
VOID BspGetPwrVoltCallBackInit(FUNC_GET_PWR_VOLT pfGetPwrVolt);
UINT32 BspGetRruOrgConsumedPower(UINT32 index, INT32 *pPower);
UINT32 BspGetRruConsumedPower(UINT32 index, INT32 *pPower);
UINT32 BspGetPwrOrgVolt(UINT32 index, INT32 *pVolt);
UINT32 BspGetPwrVolt(UINT32 index, INT32 *pVolt);
UINT32 BspGetPwrCurr(UINT32 index, INT32 *pCurr);
UINT32 BspGetPwrSubMfr(UINT32 SubSubUnitNo,UCHAR *pucVal,UINT32 *ulByteNum);
UINT32 BspWrPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 *ucVal, UINT32 uByte);
UINT32 BspRdPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 *pucVal,UINT32 uByte);
UINT32 BspGetPwrEepromDevId(VOID);
UINT32 BspSetPwrOverCurrThreshold(UINT32 index, INT32 currThr);
UINT32 BspGetPwrOverCurrThreshold(UINT32 index, INT32 *pCurrThr);
UINT32 BspShieldPwrOverTempThreshold(UINT32 index,UINT8 data);
UINT32 BspEnablePwrOverTempThreshold(UINT32 index);
UINT32 BspGetShieldPwrOverTempStatus(UINT32 index);
UINT32 BspSetPwrOtEnable(VOID);
UINT32 BspSetPwrOtDisable(VOID);
UINT32 BspGetBoard12VLowAlm(UINT32 chipId, UINT32 *pBoardLowAlm);
UINT32 BspGetBoard48VLowAlm(UINT32 chipId, UINT32 *pBoardLowAlm);
UINT32 BspGetBoardPowerdownAlm(UINT32 chipId, UINT32 *pBoardPwrdownAlm);
UINT32 BspGetBoardN8vAlm(UINT32 *pBoardN8vAlm);
UINT32 BspSetPaPwrVoltCtrl(T_PaPwrVoltCtrlPara *pPara);
UINT32 BspSetEepromPageDly(VOID);
UINT32 BspPwrSupplyMapInit(T_PwrSupplyCfg *pwrSupplyMap);
UINT32 BspPwrInputCurrCfgInit(T_PwrInputCurrAlarmCfg *pwrInputCurrCfg);
UINT32 BspSetPwrVoltAdjustEnable(UINT32 ulIndex, UINT32 ulEnable);
UINT32 BspGetPwrVoltAdjustEnable(UINT32 ulIndex, UINT32 *pEnable);
UINT32 BspSetPwrVoltAdjustLimit(UINT32 ulIndex, INT32 ulAdjustMaxVal);
UINT32 BspGetPwrVoltAdjustLimit(UINT32 ulIndex,INT32 *pAdjustMaxVal);
UINT32 BspGetPwrVoltAdjustStep(UINT32 ulIndex, INT32 *pAdjustMaxVal);
UINT32 BspSetPwrVoltAdjustStep(UINT32 ulIndex, INT32 ulAdjustStep);
UINT32 BspGetPwrVoltAdjustLevel(UINT32 ulIndex, UINT32 *pGpioLevel);
UINT32 BspGetPwrVoltAdjustErrCnt(UINT32 ulIndex,UINT32 *pAdjustErrCnt);
UINT32 BspSetPwrVoltAdjustStatus(UINT32 ulIndex, UINT32 ulStatus);
UINT32 BspGetPwrVoltAdjustStatus(UINT32 ulIndex, UINT32 *pStatus);
UINT32 BspDetectVindownIsEffective(VOID);
UINT32 BspSetPwrMcuDeepSleepStatus(UINT32 ulOnOffFlag, UINT32 ulDelayTime);
UINT32 BspSetDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime);
UINT32 BspSetPwrShutdownDelay(UINT32 index, UINT32 delaySeconds);
UINT32 BspGetPwrMfrModelInfo(UINT32 index, UINT8 *pStrModel, UINT32 byteNum);
UINT32 BspGetPwrMfrRevisionVersion(UINT32 index, UINT8 *pStrRevision, UINT32 byteNum);
UINT32 BspSetSecondAcPwrIndex(UINT32 index);
UINT32 BspSetVoltInputIndex(UINT32 index);
UINT32 BspGetVoltInputIndex(void);
UINT32 BspGetAcPwrInputVolttype(UINT32 pwrIndex);
UINT32 BspMcuModuleVerCompare(VOID);
UINT32 BspSetPwrModuleVolt(UINT32 index, INT32 Volt);
UINT32 BspPowerStatusThreadInit(void);
UINT32 BspRruWaterLeakPostProcess(VOID);
UINT32 setSecondAcMoudle(UINT32 flag);
UINT32 BspSetPowerLowStatus(UINT32 index, UINT32 sw);
UINT32 BspGetPowerLowStatus(UINT32 index, UINT32 *status);
UINT32 BspSetPwrVoltAlarmThr(T_PwrVoltAlmThr *pPwrVoltAlmThr);
VOID BspBoardUpdatePowerWaitTime(UINT32 time);
UINT32 BspGetPwrUsrVerData(UINT32 index);
UINT32 BspSetPmbCoef(UINT32 index, UINT32 coef);
UINT32 BspSetPmbVoltGate(UINT32 index, UINT32 lowVoltMv, UINT32 highVoltMv);
UINT32 BspPwrDataWrite(VOID);
UINT32 BspWriteStringToSmartEeprom(UINT32 offset, CHAR* buf, UINT32 length);
UINT32 BspReadStringToSmartEeprom(UINT32 offset, CHAR* buf, UINT32 length);
UINT32 BspSetSmartMcuDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime);
UINT32 BspSlavePortPaVolt(UINT32 portId, UINT16 volt);
UINT32 BspSetSlavePortPaVoltCallBack(SET_SLAVE_PORT_PAVOLT pFuncCallback);
void BspSetPwrDeepSleepCallbackInit(Pwr_SetDeepSleep pFunc);
void testBspGetRpuPower();
UINT32 BspSetPwrMcuFeedDog(void);
UINT32 BspSetPwrSelfRescueEn(UINT8 enFlag);
VOID BspSetPwrVersionPath(const CHAR *pwrPath, UINT32 lenth);
UINT32 BspGetPwrPowCali(INT32 lPower, INT32 *PowK, INT32 *PowB);
UINT32 BspCaliConsumedPower(INT32 *pPower);
UINT32 BspGetMcuDevId(VOID);
UINT32 BspSetPwrMcuTempWetCapacity(UINT32 optNum, UINT32 tempWetFlag);
UINT32 BspGetPwrMcuTempWetCapacity(UINT32 *pOptNum, UINT32 *pTempWetFlag);
UINT32 BspSetPwrTempDeratingInfo(T_PwrOverTempDerating *pwrCfgInfo);
VOID BspGetGainPaChanMask(UINT32 node, UINT32 *paChanMask);
void dbgShowPwrConfig();
UINT32 BspGetPwrMcuDevIdNew(VOID);
VOID BspSetNcrPwrCallBackInit(Pwr_GetPowerIn pFunc);
UINT32 BspGetPwrTempNodeNum(VOID);
UINT32 BspCaliPwrVolt(INT32 *pVolt);
VOID BspSetStopLoopMask(UINT32 index, UINT32 bitMask);
UINT32 BspGetPaGainMask(UINT32 index);
UINT32 BspGetPowerVolt(UINT32 index, INT32 *pVolt);
VOID BspSetPaGainMask(UINT32 index, UINT32 bitMask);
UINT32 BspGetStopLoopMask(UINT32 index);
UINT32 showdbgpwrovertemp(UINT32 rfChanNum);
UINT32 BspCaliConsumedPowerByIndex(UINT32 index, INT32 *pPower);
UINT32 BspCaliPwrVoltByIndex(UINT32 index, INT32 *pVolt);
UINT32 BspGetPwrVoltCaliByIndex(UINT32 index, INT32 lVolt, INT32 *VoltK, INT32 *VoltB);
UINT32 BspGetPwrPowCaliByIndex(UINT32 index, INT32 lPower, INT32 *PowK, INT32 *PowB);
UINT32 BspSetMonitorPwrVoltOut(UINT32 index, INT32 Volt);
UINT32 prndynvoltlevel(VOID);
UINT32 setdynvoltrange(INT32 voltMin, INT32 voltMax);
UINT32 setdynvoltpara(UINT32 level, INT32 tempLow, INT32 tempHigh, INT32 destVolt);
UINT32 _BspUpdatePowerModuleNew(UINT32 ulModule);
UINT32 BspUpdatePowerWaitTime(VOID);
UINT32 BspSetPwrInputSwitch(UINT32 sw);
UINT32 BspGetPwrInputAlarmSta(UINT32 *status);
void BspSetDcTreansAlmThre(T_PwrInputAlmThre thre);
void BspSetAcAlmThre_100V(T_PwrInputAlmThre thre);
void BspSetAcAlmThre_110V(T_PwrInputAlmThre thre);
void BspSetAcAlmThre_220V(T_PwrInputAlmThre thre);
void BspSetDcAlmThre(T_PwrInputAlmThre thre);
UINT32 BspGetPwrMcuDevId(VOID);
UINT32 PwrUpdateTest(VOID);
UINT32 BspGetPwrVerPath(VOID);
void* BspPowerStatusThread(void *para);
UINT32 PwrHeadDataCheck(UINT32 ucLineInfoSize, CHAR* pcbuf);
UINT32  BspPwrPkgLoadNew(UCHAR* pucLogicDataBuf, INT32 ulBufLen);
USHORT BspASCIIToUSHORT(CHAR* pHex);
UINT32 BspSubPkgCrcChk(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen, CHAR **pulNextSubVerAddr);
UINT32  BspLoadPwrVerNew(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen);
VOID BspSetSupportPwrUpdateBoard(UINT32 flag);
UINT32 BspGetSupportPwrUpdateFlag();
UINT32 BspSetPwrUpdateTimesFromFile(UINT32 num);
UINT32 BspGetPwrUpdateTimesFromFile(UINT32 *pTimes);
UINT32 BspCreatePwrUpdateRecordFile(VOID);
UINT32 BspAddPwrUpdateTimes(VOID);
UINT32 BspChkPwrVer(VOID);
VOID BspChkIsSupportFromFile(UINT32 *needUpdateFlag);
UINT32 BspGetRgpsAndAisgPowerAlm(UINT32 chipId, UINT32 *pAisgPwrdownAlm);
UINT32 BspGetPwrSelfRescueEnFlag(void);
VOID BspSetSingleAndDoublePwrSwitchFlag(UINT32 flag);
VOID BspSetSinglePwrChanPaMask(UINT32 chanMask);
#ifdef __cplusplus
}
#endif
#endif 





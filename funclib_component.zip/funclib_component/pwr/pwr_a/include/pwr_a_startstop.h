/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pwr_a_startstop.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了电源接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef PWR_A_STARTSTOP_H
#define PWR_A_STARTSTOP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "pwrapi.h"
#include "ru_univdef.h"
#include "pwrcommon.h"
#include "bsppub.h"
#include "bspcomm.h"
#include "pwr_a.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
typedef UINT32 (*funcPwrIsNeedUpdateCallBack)(UINT32 *pUpdateFlag);
/**************************************************************************
 *                        MCU侧相关接口
 **************************************************************************/
UINT32 BspSetMcuDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime);
UINT32 BspSetMcuShutdownDelay(UINT32 index, UINT32 delaySeconds);
UINT32 BspSetMcuRxLosStatus(UINT32 index, UINT32 rxLosStatus);
UINT32 BspMcuShutdownDelay(UINT32 index, UINT32 delaySeconds);
UINT32 BspMcuDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime);
/**************************************************************************
 *                        其它接口
 **************************************************************************/
UINT32 BspGetOptRxLosStatus(UINT32 optId);
UINT32 BspClrOptRxLosStatus(UINT32 optId);
UINT32 BspGetOptAuxSrcStatus(VOID);
UINT32 BspGetPowerUpgradeFlag(UINT32 *pUpdateFlag);
UINT32 BspSetPowerUpgradeFlag(UINT32 updateFlag);
UINT32 BspGetPwrIsNeedUpdateCallBack(funcPwrIsNeedUpdateCallBack pFuncCallback);
UINT32 BspSetPwrAutoUpgradeFlag(UINT32 upgradeFlag);
UINT32 BspGetPwrAutoUpgradeFlag(VOID);
UINT32 BspSetPwrMcuEepromAddr(UINT32 addr);
UINT32 BspGetPwrMcuEepromAddr(UINT32 *pAddr);
void BspSetOptLofCnt(UINT32 val);
VOID BspSetMcuTempHumiCap(UINT32 capFlag);
#ifdef __cplusplus
}
#endif
#endif 





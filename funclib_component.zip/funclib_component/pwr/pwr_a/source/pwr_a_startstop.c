/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pwr_common.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include <ctype.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmapapi.h"
#include "pwr_a.h"
#include "devdrv_tempsensor.h"
#include "regdrv_accesstbl.h"
#include "devdrv_pwr.h"
#include "regdrv.h"
#include "pwrapi.h"
#include "vxadp.h"
#include "secure_func.h"
#include "cpri_reg.h"
#include "cpri_reg.h"
#include "pwr_a_startstop.h"
#include "optctrl_cpri_ic4_2.h"
/**************************************************************************
 *                        宏                                              *
 **************************************************************************/
#define EVENT_ALARM  1
/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
static UINT32 s_ulRxLosStatus[2] = {0};
static UINT32 s_mcuTempHumiCapFlag = 0;   /*支持MCU温湿度检测标志*/
static funcPwrIsNeedUpdateCallBack pPwrIsNeedUpdateCallBack = NULL;
static UINT32 s_pwrSupportAutoUpgrade = 0; /*电源升级支持跟随AAU大版本一起升级标志，0不支持，1支持, 默认不支持*/
/*****************************************************************************
 * 函数名称: BspSetMcuDeepSleepStatus
 * 功能描述: 设置MCU下电状态函数
 * 输入参数: index：电源片号（目前填0）
             ulOnOffFlag：电源开关机标志：0为关机，1为开机
             ulOffTime：电源下电时间，单位：分钟。
 * 输出参数: 无
 * 返 回 值: 0：成功；其它值：失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspMcuDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime)
{
    TRruDeviceDescription dev  = {0};
    T_PwrCfgPriv *pPwrCfg      = NULL;

    memset_s((void *)&dev,sizeof(dev), 0, sizeof(dev));

    (void)BspDevInfoGetByDevId(index, &dev);
    dbgInfoEx(">>>%s: MCU:dev.ulDeviceId=%d, dev.ulDeviceIndex=%d \n", __FUNCTION__, dev.ulDeviceId, dev.ulDeviceIndex);

    if((pPwrCfg = BspGetPwrCfgPriv(BspPwrDevIdToDevNo(dev.ulDeviceId))) == NULL)
    {
        dbgErr("[%s]Get Cfg Error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pPwrCfg->pSetDeepSleepStatus);

    return pPwrCfg->pSetDeepSleepStatus(dev.ulDeviceIndex, ulOnOffFlag, ulOffTime);
}

UINT32 BspSetMcuDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;
    
    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    return BspMcuDeepSleepStatus(devid,ulOnOffFlag,ulOffTime);
}

/*****************************************************************************
 * 函数名称: BspSetMcuShutdownDelay
 * 功能描述: 设置MCU延迟下电函数
 * 输入参数: index：电源片号（目前填0）
             delaySeconds：延时时间，单位：秒，最大255秒。
 * 输出参数: 无
 * 返 回 值: 0：成功；其它值：失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspMcuShutdownDelay(UINT32 index, UINT32 ulOffTime)
{
    TRruDeviceDescription dev  = {0};
    T_PwrCfgPriv *pPwrCfg      = NULL;

    memset_s((void *)&dev,sizeof(dev), 0, sizeof(dev));

    (void)BspDevInfoGetByDevId(index, &dev);
    dbgInfoEx(">>>%s: MCU:dev.ulDeviceId=%d, dev.ulDeviceIndex=%d \n", __FUNCTION__, dev.ulDeviceId, dev.ulDeviceIndex);

    if((pPwrCfg = BspGetPwrCfgPriv(BspPwrDevIdToDevNo(dev.ulDeviceId))) == NULL)
    {
        dbgErr("[%s]Get Cfg Error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pPwrCfg->pSetDeepSleepDelay);

    return pPwrCfg->pSetDeepSleepDelay(dev.ulDeviceIndex, ulOffTime);
}

UINT32 BspSetMcuShutdownDelay(UINT32 index, UINT32 delaySeconds)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    return BspMcuShutdownDelay(devid,delaySeconds);
}

/*****************************************************************************
 * 函数名称: BspSetMcuRxLosStatus
 * 功能描述: 设置MCU RX_LOS电平状态
 * 输入参数: index：电源片号（目前填0）
             rxLosStatus：RX_LOS电平状态: 0：失效，1：有效。
 * 输出参数: 无
 * 返 回 值: 0：成功；其它值：失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspMcuRxLosStatus(UINT32 index, UINT32 ulOnOffFlag)
{
    TRruDeviceDescription dev  = {0};
    T_PwrCfgPriv *pPwrCfg      = NULL;

    memset_s((void *)&dev,sizeof(dev), 0, sizeof(dev));

    (void)BspDevInfoGetByDevId(index, &dev);
    dbgInfoEx(">>>%s: MCU:dev.ulDeviceId=%d, dev.ulDeviceIndex=%d \n", __FUNCTION__, dev.ulDeviceId, dev.ulDeviceIndex);

    if((pPwrCfg = BspGetPwrCfgPriv(BspPwrDevIdToDevNo(dev.ulDeviceId))) == NULL)
    {
        dbgErr("[%s]Get Cfg Error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pPwrCfg->pSetMcuRxLosStatus);

    return pPwrCfg->pSetMcuRxLosStatus(dev.ulDeviceIndex, ulOnOffFlag);
}

UINT32 BspSetMcuRxLosStatus(UINT32 index, UINT32 rxLosStatus)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    if ( index >= 2 )
    {
        dbgErr("%s index is wrong\n",__FUNCTION__);
        return BSP_ERROR;
    }
    s_ulRxLosStatus[index] = rxLosStatus;
    return BspMcuRxLosStatus(devid, rxLosStatus);
}

static UINT32 s_ulLofCnt = 0;
/*****************************************************************************
 * 函数名称: BspGetOptRxLosStatus
 * 功能描述: 查询光口RX_LOS状态
 * 输入参数: optId：光口号
 * 输出参数: 无
 * 返 回 值: 0：没有LOS告警记录；1：有告警记录
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */

UINT32 BspGetOptRxLosStatus(UINT32 optId)
{
    UINT32 retVal   = 0;
    UINT32 ulLofCnt = 0;
    UINT32 phyNo = 0;

    phyNo = BspGetPhyNoBySfpNo(optId);
    ulLofCnt = IcHalCpriSerdesGetLofCnt(phyNo);
    if (ulLofCnt != s_ulLofCnt)
    {
        retVal = 1;
        s_ulLofCnt = ulLofCnt;
    }
    return retVal;
}

/*****************************************************************************
 * 函数名称: BspClrOptRxLosStatus
 * 功能描述: 清除光口RX_LOS状态
 * 输入参数: optId：光口号
 * 输出参数: 无
 * 返 回 值: 0：成功；其它值：失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */

UINT32 BspClrOptRxLosStatus(UINT32 optId)
{
    UINT32 retVal = BSP_OK;
    UINT32 phyNo = 0;

    phyNo = BspGetPhyNoBySfpNo(optId);
    s_ulLofCnt = IcHalCpriSerdesGetLofCnt(phyNo);
    return retVal;
}

void BspSetOptLofCnt(UINT32 val)
{
    s_ulLofCnt = val;
}

/*****************************************************************************
 * 函数名称: BspGetOptAuxSrcStatus
 * 功能描述: 查询光模块辅源状态函数
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 0：正常；1：异常
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */

UINT32 BspGetOptAuxSrcStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetPowerUpgradeFlag
 *  功能描述   : 智能启停电源在线升级前从/ata/pwrupdate.txt文件中读取电源升级标志
 *  输入参数   : 无
 *  输出参数   : *pUpdateFlag: 3电源需要升级
 *  返 回 值   : BSP_OK 成功
 *              其他    失败
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 2022.06.16, 10293702 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPowerUpgradeFlag(UINT32 *pUpdateFlag)
{
    FILE   *fp = NULL;
    struct stat st = {0};
    const  char *filename = "/ata/config/pwrupdate.txt";
    INT32  tmpRet = 0;
    UINT32 tmpVal = 0;
    INT32  baseNum = 10; /*10表示十进制*/
    CHAR   lineData[MAX_PWRVER_LINE_LEN] = {0};

    INPUT_POINTER_CHECK(pUpdateFlag);

    if((fopen_s(&fp,filename, "r+") != 0) || (fp == NULL))
    {
        dbgErr("%s>>/ata/config/pwrupdate.txt Open Failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    tmpRet = stat(filename, &st);
    if (tmpRet != 0)
    {
        tmpRet = fclose(fp);
        FCLOSE_CHECK(tmpRet);
        dbgErr("%s>>/ata/config/pwrupdate.txt does not exist!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if (!S_ISREG(st.st_mode))
    {
        tmpRet = fclose(fp);
        FCLOSE_CHECK(tmpRet);
        dbgErr("%s>>/ata/config/pwrupdate.txt not regular file!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if(fgets(lineData,MAX_PWRVER_LINE_LEN,fp) == NULL)
    {
        dbgErr("%s>>/ata/config/pwrupdate.txt Get Line Failed!\n",__FUNCTION__);
        tmpRet = fclose(fp);
        FCLOSE_CHECK(tmpRet);
        return BSP_ERROR;
    }

    tmpVal = BspAtou(lineData, baseNum);
    if(BSP_ERROR != tmpVal)
    {
        *pUpdateFlag = tmpVal;
    }
    else
    {
        dbgErr("%s>>/ata/config/pwrupdate.txt convert string error!\n",__FUNCTION__);
        tmpRet = fclose(fp);
        FCLOSE_CHECK(tmpRet);
        return BSP_ERROR;
    }
    tmpRet = fclose(fp);
    FCLOSE_CHECK(tmpRet);

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspSetPowerUpgradeFlag
 *  功能描述   : 智能启停电源升级前设置/ata/pwrupdate.txt文件中电源升级标志，
 *              除过电源升级失败BSP往文件写2，其他均由高层去写值
 *  输入参数   : updateFlag 值为3时表示需要升级，其它值不需要升级
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他    失败
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 2022.06.16, 10293702 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPowerUpgradeFlag(UINT32 updateFlag)
{
    FILE   *fp = NULL;
    const  char *filename = "/ata/config/pwrupdate.txt";
    INT32  tmpRet = 0;
    INT32  fwret = 0;
    UINT32 retFlag = 0;
    CHAR   strFlag[10] = {0};
    UINT32 ret = 0;

    if((fopen_s(&fp,filename, "w+") != 0) || (fp == NULL))
    {
        dbgErr("%s>>/ata/config/pwrupdate.txt Open Failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    tmpRet = snprintf_s(strFlag, sizeof(strFlag), "%d",updateFlag);
    SNPRINTF_S_CHECK(tmpRet,sizeof(strFlag));

    if (fseek(fp, 0, SEEK_SET) != 0)
    {
        tmpRet = fclose(fp);
        FCLOSE_CHECK(tmpRet);
        return BSP_ERROR;
    }
    fwret = fwrite(strFlag, sizeof(UINT32), 1, fp);
    if (fwret != 1)
    {
        dbgErr("%s>>write %s faild!,fwret = %d\n",__FUNCTION__,filename,fwret);
        tmpRet = fclose(fp);
        FCLOSE_CHECK(tmpRet);
        return BSP_ERROR;
    }

    tmpRet = fclose(fp);
    FCLOSE_CHECK(tmpRet);

    ret = BspGetPowerUpgradeFlag(&retFlag);
    CHECK_RETVAL(BspGetPowerUpgradeFlag, ret);
    if(retFlag != updateFlag)
    {
        dbgErr("%s>>write %s faild!,retFlag = %d\n",__FUNCTION__,filename,retFlag);
        return BSP_ERROR;
    }
    else
    {
        dbgInfo("%s>>write %s success!,retFlag = %d\n",__FUNCTION__,filename,retFlag);
    }

    return BSP_OK;
}

UINT32 BspGetPwrIsNeedUpdateCallBack(funcPwrIsNeedUpdateCallBack pFuncCallback)
{
    pPwrIsNeedUpdateCallBack = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSetPwrAutoUpgradeFlag(UINT32 upgradeFlag)
{
    s_pwrSupportAutoUpgrade = upgradeFlag;
    return BSP_OK;
}

UINT32 BspGetPwrAutoUpgradeFlag(VOID)
{
    return s_pwrSupportAutoUpgrade;
}

UINT32 BspSetPwrMcuEepromAddr(UINT32 addr)
{
    UINT32 devid = 0;
    INT32 snpRet = 0;
    CHAR  bufName[PWR_PARA_LENGTH] ={0};

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    return BspSetPwrSmartMcuEepromAddr(devid, addr);
}

UINT32 BspGetPwrMcuEepromAddr(UINT32 *pAddr)
{
    UINT32 devid = 0;
    INT32 snpRet = 0;
    CHAR  bufName[PWR_PARA_LENGTH] ={0};

    INPUT_POINTER_CHECK(pAddr);
    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    return BspGetPwrSmartMcuEepromAddr(devid, pAddr);
}

/* Started by AICoder, pid:469926fae2v21001467d08ef70f8141f1a069cdb */
UINT32 BspGetPowerModuleNum(UINT32 *num)
{
    INPUT_POINTER_CHECK(num);

    if(ERROR_NULL_POINTER == BspGetPwrModuleNum())
    {
        return BSP_ERROR;
    }
    *num = BspGetPwrModuleNum();
    dbgInfoEx("[%s]pwrModuleNum'%d\n", __FUNCTION__, *num);

    return BSP_OK;
}
/* Ended by AICoder, pid:469926fae2v21001467d08ef70f8141f1a069cdb */

/* Started by AICoder, pid:m8c27e17ecf1304144bc0848c0218a3b1e7171cb */
/*设置支持MCU温湿度检测能力标识*/
VOID BspSetMcuTempHumiCap(UINT32 capFlag)
{
    s_mcuTempHumiCapFlag = capFlag;
}

/*****************************************************************************
 * 函数名称: BspGetMcuTempHumiCap
 * 功能描述: 查询是否支持温湿度检测能力
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 0：不支持温湿度检测；1：支持温湿度检测
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */

UINT32 BspGetMcuTempHumiCap(VOID)
{
    return s_mcuTempHumiCapFlag;
}


UINT32 BspGetMcuBatchTempHumi(T_McuBatchTempHumi *batchTh)
{
    UINT32 devid = BspGetPwrMcuDevIdNew();

    INPUT_POINTER_CHECK(batchTh);
    return BspGetMcuBatchTempHumiData(devid, batchTh);
}
/* Ended by AICoder, pid:m8c27e17ecf1304144bc0848c0218a3b1e7171cb */

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pwr_common.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include <ctype.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmapapi.h"
#include "pwr_a.h"
#include "devdrv_tempsensor.h"
#include "boardid.h"
#include "regdrv_accesstbl.h"
#include "devdrv_pwr.h"
#include "regdrv.h"
#include "powerctrl_comps_ic4_2.h"
#include "pwrapi.h"
#include "vxadp.h"
#include "boardid.h"
#include "exprn.h"
#include "devdrv_eeprom.h"
#include "crc.h"
#include "rftable.h"
#include "secure_func.h"
#include "pwr_a_property.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_pwr_ic4_2.h"
#include "ichaladapt_opt_ic4_2.h"
#include "funccommon_a.h"
#include "bspcommon.h"
#include "inifileop.h"
#include "bsppub.h"
#include "chnmap_a.h"
#include "optctrlcommon.h"
#include "powerctrl_ic4_2.h"
#include "pwrcommon.h"
#include "fpgaload.h"

#define RESET_COUNT                      (10)
#define RECORD_DATA_VALUE                (0xFFFF)
#define KEY_VALUE_LEN                    (20)
#define FILE_WATER_LEAKING_RECORD_LOG    "/ata/.log/waterleakflag.ini"
#define WATER_LEAKING_TITLE              "WaterLeak"
#define WATER_LEAKING_RECORD_KEY         "isWaterLeaking"
#define WATER_LEAKING_RESET_COUNT_KEY    "resetCount"

#define BSP_PWR_UPGRADE_FILE                   "/ata/.log/upgratepwr.ini"
#define PWR_UPDATE_TITLE                       "PwrUpdateLog"
#define UPDATE_NUM_RECORD_KEY                  "UpdateNum"
#define KEY_LEN                                (5)
#define PWR_SUBUNIT_PL1500_118_PATH            "/pwrupdate/pwr1500_v1.18.swv"
#define PWR_SUBUNIT_PL2200_118_PATH            "/pwrupdate/pwr2200_v1.18.swv"
#define PWR_UPDATE_TIMES_THESHOLD              ((UINT32)(3))

static UINT32 BspSetEepromInfoSplit(UINT32 ulPwrEepromIdx, UINT32 ulAddr, UINT8 *pucBuf, UINT32 ulByteSum);
static UINT32 BspGetEepromInfoSplit(UINT32 ulPwrEepromIdx, UINT32 ulAddr, UINT8 *pucBuf, UINT32 ulByteSum);
static UINT32 BspUpdatePaVolt(VOID);
UINT32 BspSetSmartMcuDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime);

#define POWER_UPDATE_WAIT_TIME 7
#define POWER_UPDATE_WAIT_TIME_5MIN 5
#define EEPROM_ACCESS_BYTE_NUN (16)
#define POWER_UPDATE_ATTEMPTS_TIMES        (3)
#define POWER_STATUS_PROCESS_PRIORITY      (130)    /* 注册优先级130对应linux优先级97-130/3 = 54*/
static UINT32 s_uPowerStatusPeriod = 2000;   /* 2s周期 */
static UINT32 s_uPowStaThreadSw = SWITCH_ON;
static UINT32 s_uPwrAlmStatus = 0;   /* 电源告警状态 */
static T_PwrTemp s_tPwrNodeTemp = {0};   /* 电源节点温度 */
static T_PwrLetTemp s_tPwrLetNodeTemp = {0};   /* 电源连接器节点温度信息 */
static SET_SLAVE_PORT_PAVOLT pSetSlavePortPaVolt = NULL;
static T_PwrOverTempDerating *s_tPwrOverTempDeratingInfo = NULL;
static UINT32 s_singleAndDoublePwrSwitchFlag = NO_SUPPORT; /* 单双电源切换能力支持标志，默认不支持 */
static UINT32 s_singlePwrChanMaskPaOff = 0;  /* 单电源线配置下,配置掩码通知APP需要关闭哪些通道(对应频段)PA */

UINT32 ulTempNumPre[]=
{
    TPS_MCS_CORE_TEMP_NUM_PRE          ,
    TPS_MCS_IO_TEMP_NUM_PRE            ,
    TPS_98DXZ_CORE_TEMP_NUM_PRE        ,
    TPS_BBFPGA0_CORE_TEMP_NUM_PRE      ,
    TPS_BBFPGA1_CORE_TEMP_NUM_PRE      ,
    TPS_BBFPGA_1V8_VOLT_TEMP_NUM_PRE   ,  
    TPS_SWITCH_CORE_VOLT_TEMP_NUM_PRE  ,   
    TPS_AD9379_RELATED_TEMP_NUM_PRE    ,
} ;

UINT32 ulPerTempNumTotal[]=
{
    TPS_MCS_CORE_TEMP_TOTAL           ,
    TPS_MCS_IO_TEMP_TOTAL             ,
    TPS_98DXZ_CORE_TEMP_TOTAL         ,
    TPS_BBFPGA0_CORE_TEMP_TOTAL       ,
    TPS_BBFPGA1_CORE_TEMP_TOTAL       ,
    TPS_BBFPGA_1V8_VOLT_TEMP_TOTAL    ,  
    TPS_SWITCH_CORE_VOLT_TEMP_TOTAL   ,   
    TPS_AD9379_RELATED_TEMP_TOTAL     ,
};

/*供电能力不足相关挂接pwr_a*/
static T_PwrSupplyCfg  *s_pwrSupplyMapChnInfo = NULL;
static T_PwrInputCurrAlarmCfg  *s_pwrInputCurrInfo = NULL;
static UINT32 pwrVindownSupportFlag   = PWR_SUPPORT_VINDOWN_YES;  /*默认支持供电能力不足*/
static UINT32 pwrVindownEffectiveFlag = PWR_VINDOWN_EFFECTIVE_YES;  /*默认光耦没有焊反*/
static INT32 pwrVoltAll[PWR_VINDOWN_DETECT_CNT] = {0};
static UINT32 pwrVindownStatAll[PWR_VINDOWN_DETECT_CNT] = {0};
static UINT32 PwrSecondAcMoudle = 0;
static UINT32 PwrSecondAcIndex = 0;
static UINT32 PwrVoltInputIndex = 0;

static FUNC_GET_PWR_VOLT pGetPwrVolt = NULL;

const static LONG s_DefaultDcAlmThre[4] = {36000, 37000, 60000, 58000};  /* {欠压告警,欠压恢复,过压告警,过压恢复} 直流：DC */
LONG   g_aDcAlmThre[4] = {36000, 37000, 60000, 58000};  /* {欠压告警,欠压恢复,过压告警,过压恢复} 直流：DC */
LONG   g_aAcAlmThre_100V[4] = {83000, 88000, 115000, 110000};  /* {欠压告警,欠压恢复,过压告警,过压恢复} 交流：100VAC */
LONG   g_aAcAlmThre_110V[4] = {90000, 95000, 132000, 125000};  /* {欠压告警,欠压恢复,过压告警,过压恢复} 交流：110VAC */
LONG   g_aAcAlmThre_220V[4] = {140000, 147000, 300000, 291000};  /* {欠压告警,欠压恢复,过压告警,过压恢复} 交流：220VAC */
LONG   g_aDcTreansAlmThre[4] = {130000, 135000, 405000, 395000}; /* {欠压告警,欠压恢复,过压告警,过压恢复} 直流远供：DC */
LONG voltDbg = 0;/*Pile driving debugging variable*/

#define SHUT_DOWN_VOLT_THRE  (25000)/*When the input voltage is lower than 25V, the entire system will lose power.*/

T_PwrTempAlarmDefPaPara *pwrTempAlarmThreshold = NULL;  //电源模块各节点的严重/轻微过温门限告警值和恢复值

#define INPUT_INDEX_CHECK(index,maxIndexNum)                               \
     if (index >= maxIndexNum)                                             \
     {                                                                     \
         printf("%s:Input Index is Out of The Range !\n",__FUNCTION__);    \
         return BSP_ERROR;                                        \
     }
#define INPUT_SWITCH_CASE_SELECT(DevType,ulIndex)                    \
        do                                                           \
        {                                                            \
            INPUT_INDEX_CHECK(DevType,TPS_TEMP_MODE_MAX);            \
            INPUT_INDEX_CHECK(ulIndex,ulPerTempNumTotal[DevType]);   \
            ulIndex = ulIndex + ulTempNumPre[DevType];               \
        }while(0)                                                    \

#define PWR_SUBVER_LENTH_CHECK(len)                           \
{                                                             \
    if ((len) > MAX_VER_LINE_LEN)                             \
    {                                                         \
        dbgErr("Pwr SubVersion lenth %d over range!\n", len); \
        return BSP_ERROR;                                     \
    }                                                         \
}

#define INPUT_POINTER_CHECK_PWR(ppointer)                     \
if (NULL == ppointer)                                         \
{                                                             \
        dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);   \
        return BSP_ERROR;                                     \
}

#define INPUT_INDEX_CHECK_PWR(index,maxIndexNum)                               \
     if (index >= maxIndexNum)                                             \
     {                                                                     \
         dbgErr("%s:Input Pwr Index is Out of The Range !\n",__FUNCTION__);    \
         return BSP_ERROR;                                        \
     }
#define GET_CURR_VOLT_MAX_NUM  (UINT32)10
#define GET_CURR_VOLT_IDX_MAX_NUM  (UINT32)3
#define pwrupdataLog(fmt, ...)  PwrUpdateLogPrint(fmt, ##__VA_ARGS__)
static T_PaPwrVoltCtrlPara s_paPwrVoltCtrlPara = {0};
static INT32 s_paVolt[PA_PWR_MAX_NUM] = {0};         /* paVolt更新全局变量 */
static T_PaVoltUpdatePara s_paVoltUpdatePara = {0};

static FUNC_SET_PWR_ON pSetPwrOn = NULL;
static T_PmbAdcCfgPriv s_PmbCfgPriv = {NULL};

static funcPowerI2cByPassCallBack pPwrByPassFuncCallBack = NULL;
static FUNC_GET_PWR_TPLG pGetPwrTplgCallBack = NULL; /*获取电源拓扑*/
static Pwr_GetInt  pGetPwrCurrIn = NULL;
Pwr_GetPowerIn pGetPowerIn = NULL;
static Pwr_SetDeepSleep pSetDeepSleep = NULL;
static SEM_ID semPowUpdate = NULL;
static T_PwrTypeStruct s_RruPwrTplg = {0};
T_VerFileHeader_Pwr tVerHead = {0};
T_VerIRHeader_Pwr   tVerIRHead = {0};
T_Pwr_VerPkg_Pwr    tPwrVerPkg = {0};
T_PwrSubUnitHeader atPwrSubUnitHeader = {0};
T_PwrSubVerInfo    atPwrVerInfo[MAX_PWR_VER_NUM] = {0};
T_PwrSubVerInfoNew    atPwrVerInfoNew[MAX_PWR_VER_NUM] = {0};
UINT32 ulPwrPrintSwitch = 0;
UINT32 ulUpGradeFlag = 0;
UINT32 PwrSubUnitNameLen = 0; //大板电源单板名称
static UINT32 s_PwrSubSubUnitNo[SUB_PWR_MODULE_NUM] = {0x55, 0x55, 0x55, 0x55,};  //子组件编号序列
UINT32 PwrSubSubUnitNameLen = 0;  //子组件生产厂家名称长度
T_PwrVerHead g_PwrVerHead[4] = {0};

UINT32 g_PwrUpdateDly = 30;  /*整机向mcu发起升级命令到回读mcu返回的升级状态 之间的延时 实际测试不能超过100ms 不同规格预留时延上的差异*/

INT32 atPwrMonVolt[PWR_MON_TYPE_NUM][PWR_MON_CHIP_NUM] = {0};

static T_PwrCfgcPara   s_PwrSwitchCfgFun = NULL;

static UINT32 eepromPageDly   = 5;

/* CRC16校验的初值设置 */
static UINT16 s_usHeadCrcSum    = 0;
static UINT16 s_usMcuCrcSum     = 0;

/* 根据bit位屏蔽子组件版本比对，每个bit: 0:正常 1:屏蔽 */
static UINT16 s_usVerCmpSw      = 0;

UINT32 pwrVerPathFlag = 0;
const CHAR  *pwrVerPath = PWR_VERSION_PATH;
static CHAR s_pwrVerPath[PWR_VER_PATH_MAX_LEN] = {0};
static const char *s_pwrUpdateLogFileName = "/ata/.log/pwrupdatelog.txt";
static UINT32 s_pwrUpdateLogMaxSize =  0xC800;/* 文件最大50k，0xC800 = 50*1024，与APP对齐 */
static FILE *s_pwrUpdateLogfp = NULL;
T_CachedPwrTempInfo s_pwrTmpCache = {SWITCH_OFF, SWITCH_OFF, {0}, {BSP_ERROR, BSP_ERROR, BSP_ERROR, BSP_ERROR, BSP_ERROR, BSP_ERROR, BSP_ERROR, BSP_ERROR}};
UINT64 pwrTempFailedTick[PWR_NODE_TEMP_MAX_MUM][PWR_READ_FAILED_TICK_INDEX] = {0};
UINT32 pwrTempFailedFlag[PWR_NODE_TEMP_MAX_MUM] = {0};
UINT32 pwrTempAllTimeFailedFlag[PWR_NODE_TEMP_MAX_MUM] = {SWITCH_ON, SWITCH_ON, SWITCH_ON, SWITCH_ON, SWITCH_ON, SWITCH_ON, SWITCH_ON, SWITCH_ON};/*电源从上电开始一直有问题标志*/
UINT32 pwrTempFailedOver30minFlag[PWR_NODE_TEMP_MAX_MUM] = {SWITCH_OFF, SWITCH_OFF, SWITCH_OFF, SWITCH_OFF, SWITCH_OFF, SWITCH_OFF, SWITCH_OFF, SWITCH_OFF};/*电源从上电开始一直有问题标志*/
UINT32 getRetimeTempRet[PWR_NODE_TEMP_MAX_MUM] = {0};

static T_VoltThresAdjPara s_voltThresAdjPara[] =
{
    {PWR_TYPE_DC, NOT_SUPPORT_FIELD, E_PWR_TYPE_STANDARD_DC, s_DefaultDcAlmThre, g_aDcAlmThre, BspIsDcVoltAlmThresValid},
};

/* Started by AICoder, pid:i7039896f216aca146ef0ade20698f2aea37a7db */
Pwr_GetPowerIn pGetNcrPower = NULL;
VOID BspSetNcrPwrCallBackInit(Pwr_GetPowerIn pFunc)
{
    INPUT_POINTER_CHECK_RETURN(pFunc);
    pGetNcrPower = pFunc;
}
/* Ended by AICoder, pid:i7039896f216aca146ef0ade20698f2aea37a7db */

UINT32 s_isBoardUpdatePowerWaitTime = 0;
VOID BspBoardUpdatePowerWaitTime(UINT32 time)
{
    s_isBoardUpdatePowerWaitTime = time;
}
UINT32 BspUpdatePowerWaitTime(VOID)
{
    return s_isBoardUpdatePowerWaitTime;
}

/* Started by AICoder, pid:ic264y601a98b83147710821f0aa768f79306bf9 */
static FILE *BspGetRruPwrUpdateLogFp(VOID)
{
    UINT32 size = 0;
    INT32 fclsRet = 0;
    CHAR * const dirlist[1] = {"/ata/.log"};
    rsize_t dirlist_size = 1;
    const CHAR *acFileName = "/ata/.log/pwrupdatelog.txt";
    INT32 ret = 0;

    if (s_pwrUpdateLogfp == NULL)
    {
        dbgErr("%s>>Error! pFpRruPwrUpdateLog NULL\n", __FUNCTION__);
        return NULL;
    }

    size = ftell(s_pwrUpdateLogfp);
    if (size > s_pwrUpdateLogMaxSize)
    {
        dbgInfo("%s>> size:0x%x > MaxSize:0x%x\n", __FUNCTION__,size,s_pwrUpdateLogMaxSize);
        fclsRet = fclose(s_pwrUpdateLogfp);
        FCLOSE_CHECK(fclsRet);
        BspSystem("mv /ata/.log/pwrupdatelog.txt  /ata/.log/pwrupdatelog.txt.bak");

        ret = zte_fopen_s(&s_pwrUpdateLogfp, acFileName, "a+", dirlist, dirlist_size);
        if(0 != ret)
        {
            const CHAR* err_info = zte_strerror_s(zte_errno);
            dbgErr("failed to open file /ata/.log/pwrupdatelog.txt,error in detail : %s\n",err_info);
            return NULL;
        }

    }

    size = ftell(s_pwrUpdateLogfp);
    if (size > s_pwrUpdateLogMaxSize)
    {
        return NULL;
    }
    return s_pwrUpdateLogfp;
}
/* Ended by AICoder, pid:ic264y601a98b83147710821f0aa768f79306bf9 */

static void PwrUpdateLogPrint(const char *format, ...)
{
    FILE *fp = NULL;
    va_list ap;
    char strTime[20] = {0};
    time_t  timeRet = 0;

    fp = BspGetRruPwrUpdateLogFp();
    if (fp == NULL)
    {
        return ;
    }

    va_start(ap, format);
    timeRet = time(NULL);
    TIME_CHECK(timeRet);
    BspSecondToDate(strTime, sizeof(strTime), timeRet, 0);
    (void)fprintf(fp, "[%s]", strTime);
    (void)vfprintf_s(fp, format, ap);
    (void)fflush(fp);
    va_end(ap);
}

static void PwrUpdateLogOpen(void)
{
    (void)fopen_s(&s_pwrUpdateLogfp, s_pwrUpdateLogFileName, "a+");
    if (s_pwrUpdateLogfp == NULL)
    {
        dbgErr("%s fopen failed!\n", __FUNCTION__);
    }
}

static void PwrUpdateLogClose(void)
{
    if(NULL != s_pwrUpdateLogfp)
    {
        (void)fclose(s_pwrUpdateLogfp);
        s_pwrUpdateLogfp = NULL;
    }
}

static void PwrUpdateLogInit(void)
{
    BspLogFileBackup(s_pwrUpdateLogFileName, s_pwrUpdateLogMaxSize);
    PwrUpdateLogOpen();
}

/*****************************************************************************
 * 函数名称: BspIsNewPwrType(*)
 * 功能描述: 根据特性参数表判断当前整机使用的是否是大板电源
 * 输入参数: void
 * 输出参数:
 * 返 回 值: 0- 是大板电源, 其它值- 不是大板电源
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2020-07-08, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspIsNewPwrType(VOID)
{
    UINT32 uIdx = 0;
    CHAR  temp[16]  = {0};
    TRruDeviceDescription dev = {0};

    if(PwrSecondAcMoudle == 1)
    {
        uIdx = uIdx + PwrSecondAcMoudle;
    }

    (void)snprintf_s(temp,sizeof(temp),"RpdcDac%d",uIdx);
    if (BSP_OK != BspDevInfoGetByDevIdName(temp,&dev))
    {
        dbgErr("[%s]Not found %s\n", __FUNCTION__, temp);
        return BSP_ERROR;
    }

    if(DEVICE_IPD600 == dev.ulDeviceName)
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}
VOID BspSetPwrUpdateDly(UINT32 ulDly)
{
	g_PwrUpdateDly = ulDly;
}

UINT32 BspGetPwrUpdateDly(VOID)
{
	return g_PwrUpdateDly ;
}


UINT32 BspSetPwrSwCfgFunc(T_PwrCfgcPara pFunc)
{
	s_PwrSwitchCfgFun = pFunc;
    return BSP_OK;
}

VOID BspSetPwrOnCallBackInit(FUNC_SET_PWR_ON pfSetPwrOn)
{
	pSetPwrOn = pfSetPwrOn;
}

UINT32 BspSetPowerI2cByPassCallBack(funcPowerI2cByPassCallBack pFuncCallback)
{
    pPwrByPassFuncCallBack = pFuncCallback;
    return BSP_OK;
}

UINT32 BspGetPwrTplgCallBack(FUNC_GET_PWR_TPLG pFuncCallback)
{
    pGetPwrTplgCallBack = pFuncCallback;
    return BSP_OK;
}

UINT32 BspGetPwrTplg(VOID)
{
    UINT32 pwrtplgtmp80W[SUB_PWR_MODULE_NUM] = {1, 1, 1, 1,};
    T_PwrTypeStruct RruPwrTplgTemp = {0};
    if (pGetPwrTplgCallBack == NULL)
    {
        s_RruPwrTplg.pwrTypeName = E_seperatePwrType;
        s_RruPwrTplg.subPwrModeMaxNum = 3;
        memcpy_s(s_RruPwrTplg.pwrTopology, sizeof(s_RruPwrTplg.pwrTopology),\
                pwrtplgtmp80W, sizeof(pwrtplgtmp80W));
        return BSP_OK;
    }
    pGetPwrTplgCallBack(&RruPwrTplgTemp);
    s_RruPwrTplg.pwrTypeName = RruPwrTplgTemp.pwrTypeName;
    s_RruPwrTplg.subPwrModeMaxNum = RruPwrTplgTemp.subPwrModeMaxNum;
    memcpy_s(s_RruPwrTplg.pwrTopology, sizeof(s_RruPwrTplg.pwrTopology),\
            RruPwrTplgTemp.pwrTopology, sizeof(RruPwrTplgTemp.pwrTopology));
    return BSP_OK;
}
UINT32 BspCleanPwrCrcChkResult(VOID)
{
    s_RruPwrTplg.pwrPkgHeadChk = 0;
    memset_s(s_RruPwrTplg.pwrPkgCrcChk, sizeof(s_RruPwrTplg.pwrPkgCrcChk), 0, sizeof(s_RruPwrTplg.pwrPkgCrcChk));
    memset_s(s_RruPwrTplg.pwrUpdateFlag, sizeof(s_RruPwrTplg.pwrUpdateFlag), 0, sizeof(s_RruPwrTplg.pwrUpdateFlag));
    return BSP_OK;
}

VOID BspSetPwrForceUpdateFlag(UINT32 index, UINT32 fUpdateFlag)
{
   s_RruPwrTplg.pwrForceUpdateFlag[index] = fUpdateFlag;
}

UINT32 BspGetPwrForceUpdateFlag(UINT32 index)
{
   return s_RruPwrTplg.pwrForceUpdateFlag[index];
}

VOID BspGetPwrCurrInCallbackInit(Pwr_GetInt pFunc)
{
    pGetPwrCurrIn = pFunc;
}


UINT32 BspSetPaPwrVoltCtrl(T_PaPwrVoltCtrlPara *pPara)
{
    if (pPara != NULL)
    {
        memcpy(&s_paPwrVoltCtrlPara, pPara, sizeof(T_PaPwrVoltCtrlPara));
    }
    return BSP_OK;
}

T_PaPwrVoltCtrlPara *BspGetPaPwrVoltPara()
{
    return &s_paPwrVoltCtrlPara;
}
pStaGetFunc pGetPowerStatusCall = NULL;


UINT32 BspRegisterAlmStaCall(pStaGetFunc pGetStatusCall)
{
   pGetPowerStatusCall = pGetStatusCall;
   return BSP_OK;
}

UINT32 BspSetPwrTempAlmThreshold(T_PwrTempAlarmDefPaPara *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    pwrTempAlarmThreshold = pPara;

    return BSP_OK;
}

T_PwrTempAlarmDefPaPara* BspGetPwrTempAlmThreshold(VOID)
{
    return pwrTempAlarmThreshold;
}

UINT32 BspGetPwrOverTempAlmStatus(UINT32 index, UINT32 rfChanNum, UINT32 *pStatus)
{
    static UINT32 keep[PWR_TEMPALM_NUM_MAX][TBL_PWRTEMP_ALM_NUM_MAX] = {{0}}; //历史告警状态暂存
    INT32 tmp = 0;
    UINT32 rfchan  = 0;
    INT32 tempPeak = 0;//温度峰值
    INT32 tempRec = 0; //温度恢复
    UINT32 thresholdId[PWR_TEMPALM_NUM_MAX] = {BSP_THRESHOLD_ID_OVER_PWR_TEMPER,  BSP_THRESHOLD_ID_OVER_PWR1_TEMPER,
                                               BSP_THRESHOLD_ID_OVER_PWR2_TEMPER, BSP_THRESHOLD_ID_OVER_PWR3_TEMPER,
                                               BSP_THRESHOLD_ID_OVER_PWR4_TEMPER, BSP_THRESHOLD_ID_OVER_PWR5_TEMPER,
                                               BSP_THRESHOLD_ID_OVER_PWR6_TEMPER, BSP_THRESHOLD_ID_OVER_PWR7_TEMPER};

    INPUT_POINTER_CHECK(pStatus);
    RETURN_VAL_DO_IF_EXP(index >= PWR_TEMPALM_NUM_MAX, BSP_ERROR, dbgErr("%s: pwrIndex:%d is not exit!!\n",__FUNCTION__, index));
    if(BspGetPwrTemp(index, &tmp) != BSP_OK)
    {
        dbgInfoEx("[BspGetPwrTemp] index[%d] err\n", index);
        return BSP_ERROR;
    }

    for(rfchan = 0; rfchan < rfChanNum; rfchan++)
    {
        if(BspGetTempThreshold(rfchan, thresholdId[index], &tempPeak, &tempRec) != BSP_OK)
        {
            dbgErr("[%s]:pwrOverThreshold Get Failed\n", __FUNCTION__);
            return BSP_ERROR;
        }
        dbgInfoEx("temp[%d]=[%d]\t oPeak = [%d]\t oRec= [%d]\t\n", index, tmp, tempPeak, tempRec);

        if(tmp > tempPeak)
        {
            keep[index][rfchan] = 1;
            *pStatus |= PWR_OVER_TEMP_ALM(rfchan);
        }
        else if(tmp > tempRec)
        {
            if(keep[index][rfchan])
            {
                *pStatus |= PWR_OVER_TEMP_ALM(rfchan);
            }
        }
        else
        {
            keep[index][rfchan] = 0;
            *pStatus &= PWR_TEMP_NORMAL(rfchan);
        }

        dbgInfoEx("PwrIndex = %d, rfchan = %d, ChanAlarmSta = %d \n", index, rfchan, keep[index][rfchan]);
    }

    return BSP_OK;
}

/*电源严重过温告警*/
UINT32 BspGetHighOverTempAlmStatus(UINT32 *pStatus)
{
    UINT32 retVal = 0;
    UINT32 pwrindex = 0;
    UINT32 pwrTempSensorNum = 0;
    UINT32 rfChanNum = 0;
    UINT32 pwrTempAlmStatus = 0;

    INPUT_POINTER_CHECK(pStatus);

    if((BspGetPwrTempAlmChNum(&rfChanNum) != BSP_OK) || (BspGetTempAlmSensorNum(&pwrTempSensorNum) != BSP_OK))
    {
        dbgInfoEx("Get rfChanNum or pwrTempSensorNum from PwrTempAlm.txt err!!\n");
        *pStatus = 0;

        return BSP_ERROR;
    }

    for (pwrindex = 0; pwrindex < pwrTempSensorNum; pwrindex++)
    {
        dbgInfoEx("pwrTempSensorNum = %d, RfChanNum = %d\n", pwrTempSensorNum, rfChanNum);
        pwrTempAlmStatus = 0;
        retVal = BspGetPwrOverTempAlmStatus(pwrindex, rfChanNum, &pwrTempAlmStatus);
        if((BSP_OK == retVal) && (0 != pwrTempAlmStatus))
        {
            *pStatus = pwrTempAlmStatus;
        }
    }

    dbgInfoEx("OverTempStatus = 0x%08x\n", *pStatus);

    return retVal;
}

UINT32 BspSetPmbCfgPriv (T_PmbAdcCfgPriv *pPara)
{
    if (pPara != NULL)
    {
        memcpy(&s_PmbCfgPriv, pPara, sizeof(T_PmbAdcCfgPriv));
    }
    return BSP_OK;
}
T_PmbAdcCfgPriv *BspGetPmbCfgPriv()
{
    return &s_PmbCfgPriv;
}
UINT32 BspGetPwrStatus(UINT32 index, UINT32 *pStatus)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pStatus);
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrAlarm(devid, pStatus);
}

/*****************************************************************************
 *  函数名称   : BspGetPwrOverTempWarning(*)
 *  功能描述   : R9242M1821机型使用V2电源可以直接读取电源的过温告警状态
 *  输入参数   :
 *  输出参数   :
 *  返 回 值  :
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetPwrOverTempWarning(UINT32 *warnflag)
{
    UINT32 retVal = BSP_OK;
    UINT32 index = 0;
    UINT32 status = 0;
    UINT8  value  = 0;

    INPUT_POINTER_CHECK(warnflag);

    retVal |= BspGetPwrStatus(index, &status);
    CHECK_RETVAL(BspGetPwrStatus, retVal);

    if(BSP_OK != status)
    {
        retVal |= BspWrPwrRegByte(index, PWR_OVERTMEPWARNING_CLEAR, &value, 0);
        CHECK_RETVAL(BspWrPwrRegByte, retVal);
        *warnflag = BIT_SET(0);
    }
    dbgInfoEx("[%s] status = %d, warnflag = %d\n", __FUNCTION__, status, *warnflag);

    return retVal;
}

UINT32 BspGetTempStatus(UINT32 index, UINT32 *pStatus)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pStatus);
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetTmpAlarm(devid, pStatus);
}

static void BspGetIna2xxIndex(UINT32 *powIndex)
{
    UINT32 i= 0;
    int snpRet;
    UINT32 ret = 0;
    UINT32 indexTemp = 0;
    TRruDeviceDescription dev;
    char  bufName[PWR_PARA_LENGTH] = {0};
    UINT32 maxLoopVal = max(BspGetTxChannel(), BspGetRxChannel()) + 1;

    for(i = 0; i < maxLoopVal; i++)
    {
        memset_s(&dev, sizeof(dev), 0, sizeof(dev));
        memset_s(bufName, sizeof(bufName), 0, sizeof(bufName));
        snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d", i);
        SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
        ret = BspDevInfoGetByDevId(BspDevNameToId(bufName), &dev);
        if(ret != BSP_OK)
        {
            continue;
        }
        if(strcmp(dev.acDeviceName,"ina220") == 0)
        {
            indexTemp = i;
            break;
        }
    }

    if (i < maxLoopVal)
    {
        *powIndex = indexTemp;
    }

    dbgInfoEx("maxLoopVal = %d, powIndex = %d\n", maxLoopVal, *powIndex);
}

UINT32 BspGetRruOrgConsumedPower(UINT32 index, INT32 *pPower)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;
    UINT32 powIndex = index;
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pPower);

    if(PwrSecondAcMoudle == 1)
    {
        powIndex  = powIndex  + PwrSecondAcIndex;
    }

    BspGetIna2xxIndex(&powIndex);
    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",powIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    retVal |= BspGetPwrIn(devid, pPower);

    return retVal;
}

void BspGetPowerInCallbackInit(Pwr_GetPowerIn pFunc)
{
    pGetPowerIn = pFunc;
}

void BspSetPwrDeepSleepCallbackInit(Pwr_SetDeepSleep pFunc)
{
    pSetDeepSleep = pFunc;
}

/* Started by AICoder, pid:nad93g40aa48ef614e080a36906ccc499b96601d */
UINT32 BspGetRruConsumedPower(UINT32 index, INT32 *pPower)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;
    UINT32 powIndex = index;
    UINT32 retVal = 0;
    UINT32 busSta = BSP_OK;

    INPUT_POINTER_CHECK(pPower);

    if(pGetNcrPower != NULL)
    {
        return pGetNcrPower(index, pPower);
    }

    if(pGetPowerIn != NULL)
    {
        return pGetPowerIn(index, pPower);
    }

    BspGetIna2xxIndex(&powIndex);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",powIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    busSta = BspGetPwrIn(devid, pPower);
    busSta |= BspGetPwrI2cDbgSta();
    if (BSP_OK != busSta)
    {
        dbgInfoEx("[%s]Pwr Bus Error\n", __FUNCTION__);
        *pPower = 0;
        return busSta;
    }

    retVal = BspCaliConsumedPower(pPower);
    retVal |= BspLimitMaxPow(busSta, pPower);

    return retVal;
}
/* Ended by AICoder, pid:nad93g40aa48ef614e080a36906ccc499b96601d */

UINT32 BspGetRruPwrOut(UINT32 index, INT32 *pPower)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pPower);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrOut(devid,pPower);
}

void testBspGetRpuPower()
{
	INT32 tmp = 0;
	BspGetRruConsumedPower(0, &tmp);
	RedirPrintf("%s: power = %d mW\n",__FUNCTION__, tmp);
}

UINT32 BspGetPwrTempRealTime(UINT32 index, INT32 *pTemp)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pTemp);
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"TempRpdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetTempSensorInfo(devid, pTemp);
}

/*获取整机输入电压*/
UINT32 BspGetPwrOrgVolt(UINT32 index, INT32 *pVolt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;
    UINT32 powIndex = index;
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pVolt);

    BspGetIna2xxIndex(&powIndex);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",powIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    retVal |= BspGetVoltIn(devid, pVolt);
    return retVal;
}

/* Started by AICoder, pid:89227j4eadk7f22143f308be20d2830a4594139e */
VOID BspGetPwrVoltCallBackInit(FUNC_GET_PWR_VOLT pfGetPwrVolt)
{
    pGetPwrVolt = pfGetPwrVolt;
}
/* Ended by AICoder, pid:89227j4eadk7f22143f308be20d2830a4594139e */

/*获取整机输入电压*/
UINT32 BspGetPwrVolt(UINT32 index, INT32 *pVolt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;
    UINT32 powIndex = index;
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pVolt);

    if(pGetPwrVolt != NULL)
    {
         return pGetPwrVolt(index, pVolt);
    }

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    BspGetIna2xxIndex(&powIndex);
    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",powIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    retVal |= BspGetVoltIn(devid, pVolt);
    retVal |= BspCaliPwrVolt(pVolt);
    return retVal;
}

UINT32 BspSetPwrVolt(UINT32 index, INT32 Volt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrPaVolt(devid, Volt);
}

UINT32 BspSetPwrVinUvLimit(UINT32 index, INT32 Volt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrVoltLimit(devid,0,Volt);
}

UINT32 BspSetPwrOn(UINT32 index,BOOL bPowerOn)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(pSetPwrOn !=NULL)
    {
    	 return pSetPwrOn(index,bPowerOn);
    }

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPowerOn(devid,bPowerOn);
}

/* Started by AICoder, pid:153f3n3d61b1bf714bcd0ba0809c21269640f02b */
UINT32 BspGetPwrVoutAlarmStatus(UINT32 index, UINT32 *pValue)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pValue);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPowerVoutAlarmStatus(devid, pValue);
}

UINT32 BspGetPwrIoutAlarmStatus(UINT32 index, UINT32 *pValue)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pValue);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPowerIoutAlarmStatus(devid, pValue);

}

UINT32 BspGetPwrVinAlarmStatus(UINT32 index, UINT32 *pValue)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pValue);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPowerVinAlarmStatus(devid, pValue);

}

UINT32 BspGetPwrTempAlarmStatus(UINT32 index, UINT32 *pValue)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pValue);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPowerTempAlarmStatus(devid, pValue);

}

UINT32 BspGetPwrSwitchStatus(UINT32 index, UINT32 *pValue)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pValue);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPowerSwitchStatus(devid, pValue);

}

UINT32 BspGetPwrOtherAlarmStatus(UINT32 index, UINT32 *pValue)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pValue);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPowerOtherAlarmStatus(devid, pValue);
}
/* Ended by AICoder, pid:153f3n3d61b1bf714bcd0ba0809c21269640f02b */

/* 分页输出电压 */
UINT32 BspGetBoardVolt(UINT32 index, INT32 *pVolt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pVolt);
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetVoltOut(devid, pVolt);
}

/* Started by AICoder, pid:f1618w54cdtdd99143340bb1d0c4d42c93801bee */
UINT32 BspGetPowerVolt(UINT32 index, INT32 *pVolt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pVolt);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetVoltOut(devid, pVolt);
}
/* Ended by AICoder, pid:f1618w54cdtdd99143340bb1d0c4d42c93801bee */

UINT32 BspSetPwrModuleVolt(UINT32 index, INT32 Volt) //BspSetPwrVolt不符合返回值为BSP_OK或者BSP_ERROR的写法，特此更改
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    UINT32 ulRetVal = BSP_OK;
    int snpRet;
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRetVal = BspSetPwrPaVolt(devid, Volt);
    return ulRetVal;
}

UINT32 BspSavePwrInfoToFile(char *pucBuf, UINT32 length)
{
    CHAR   *FileName = "/ata/powerinfo.txt";
    FILE   *fp = NULL;
    UINT32 ulRetVal = BSP_OK;
    int fclsRet;

    INPUT_POINTER_CHECK(pucBuf);

    if (NULL == (fp = fopen(FileName, "a+")))
    {
        dbgErr("--fopen error!!!--\n");
        return BSP_ERROR;
    }
    if((fprintf(fp, "%s", pucBuf)) < 0)
    {
        dbgErr("--write failed [%s]--\n",pucBuf);
        ulRetVal = BSP_ERROR;
    }
    else
    {
        ulRetVal = BSP_OK;
    }
    dbgInfoEx("%s: ulRetVal:%d\n",__FUNCTION__, ulRetVal);
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);

    return BSP_OK;
}

UINT32 BspGetPwrInputSymbol(UINT32 index, UINT32 *inputSymbol)
{
    UINT32 ulRetVal = BSP_OK;
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(inputSymbol);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRetVal = BspGetPwrInSym(devid, inputSymbol);

    return ulRetVal;
}

UINT32 BspSetPwrInputSymbol(UINT32 index, UINT32 inputSymbol)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrInSym(devid, inputSymbol);
}

UINT32 BspGetPwrResetDelay(UINT32 index, UINT32 *delayMs)
{
    UINT32 ulRetVal = BSP_OK;
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(delayMs);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRetVal = BspGetPwrRstDelay(devid, delayMs);

    return ulRetVal;
}

UINT32 BspSetPwrResetDelay(UINT32 index, UINT32 delayMs)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrRstDelay(devid, delayMs);
}

UINT32 BspGetPwrProtectInfo(UINT32 index, UINT32 ulInterChan, UINT32* uiStatus)
{
    UINT32 ulRetVal = BSP_OK;
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRetVal = BspGetPwrProInfo(devid, ulInterChan, uiStatus);

    return ulRetVal;
}

UINT32 BspGetPwrHistoryInfo(UINT32 index, UINT8 *strHis, UINT32 size)
{
    UINT32 ulRetVal = BSP_OK;
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    ulRetVal = BspGetPwrHisInfo(devid, strHis, size);

    return ulRetVal;
}

UINT32 BspSetPwrTimeEnable(UINT32 index, UINT8 *strTime, UINT32 size)
{
    UINT32 ulRetVal = BSP_OK;
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRetVal = BspSetPwrTime(devid, *strTime, size);

    return ulRetVal;
}

UINT32 BspCheckPowerInputSymbol(VOID)
{
    UINT32 inputSymbol = 0;
    UINT32 uiRet = 0, uiLength = 0;
    char pucBuf[64] = {0};

    uiRet = BspGetPwrInputSymbol(0, &inputSymbol);
    if(BSP_OK != uiRet)
    {
        dbgErr("func:[%s] BspGetPwrInputSymbol error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    /*记录日志*/
    uiLength += snprintf(pucBuf+uiLength, sizeof(pucBuf),"Power Input Symbol: %x(0x1234:OK)\n",inputSymbol);
    dbgInfo("--BspCheckPowerInputSymbol: [%s]--\n", pucBuf);

    BspSavePwrInfoToFile(pucBuf, uiLength);

    return BSP_OK;
}

UINT32 BspCheckPowerDownStatus(VOID)
{
    UINT32 delayMs = 0;
    UINT32 uiRet = 0, uiLength = 0;
    char pucBuf[64] = {0};

    uiRet = BspGetPwrResetDelay(0, &delayMs);
    if(BSP_OK != uiRet)
    {
        dbgErr("func:[%s] BspGetPwrResetDelay error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    /*记录日志*/
    uiLength += snprintf(pucBuf+uiLength, sizeof(pucBuf), "Power Down Status(reset delay): %d(110:OK)\n",delayMs);
    dbgInfo("--BspCheckPowerDownStatus: [%s]--\n", pucBuf);

    BspSavePwrInfoToFile(pucBuf, uiLength);

    if(100 == delayMs)/*输入掉电*/
    {
        uiRet = BspSetPwrResetDelay(0, 110);
        if(BSP_OK != uiRet)
        {
            dbgErr("func:[%s] BspSetPwrResetDelay error!\n", __FUNCTION__);
            return BSP_ERROR;
        }

        /*写完后回读，确认下是否写成功*/
        uiRet = BspGetPwrResetDelay(0, &delayMs);
        if(BSP_OK != uiRet)
        {
            dbgErr("func:[%s] BspGetPwrResetDelay error!\n", __FUNCTION__);
            return BSP_ERROR;
        }
        dbgInfo("recheck delayMs[%d].\n",delayMs);
        if(110 == delayMs)
        {
            dbgInfo("BspSetPwrResetDelay 110 success.\n");
        }
        else
        {
            dbgInfo("BspSetPwrResetDelay 110 failed.\n");
        }
    }
    return BSP_OK;
}

UINT32 BspCheckPowerProtectInfo(VOID)
{
    UINT32 uiStatus = 0, uiChan = 0;
    UINT32 uiRet = 0;

    for(uiChan=0; uiChan<3; uiChan++)
    {
        uiRet = BspGetPwrProtectInfo(0,uiChan,&uiStatus);
        if(BSP_OK != uiRet)
        {
            dbgErr("func:[%s] BspGetPwrProtectInfo error!\n", __FUNCTION__);
            return BSP_ERROR;
        }
        dbgInfoEx("----chan %d----\n",uiChan);
        dbgInfoEx("chan:%d Vout OV status: %d(0:OK)\n",uiChan,uiStatus&0x1);//输出过压保护
        dbgInfoEx("chan:%d Iout OC status: %d(0:OK)\n",uiChan,uiStatus&0x2);//输出过流保护
        dbgInfoEx("chan:%d Vin UV status: %d(0:OK)\n",uiChan,uiStatus&0x4);//输入欠压保护
        dbgInfoEx("chan:%d Vin OV status: %d(0:OK)\n",uiChan,uiStatus&0x8);//输入过压保护
        dbgInfoEx("chan:%d OT warn status: %d(0:OK)\n",uiChan,uiStatus&0x10);//过温告警
        dbgInfoEx("chan:%d OT prot status: %d(0:OK)\n",uiChan,uiStatus&0x20);//过温保护
    }
    return BSP_OK;
}

UINT32 BspCheckPowerHistoryInfo(VOID)
{
    UINT8 strHis[9] = {0};
    char  pucBuf[96] = {0};
    UINT8 ucStrTimeAddr[PWR_HISTORY_SET_TIME_LEN] = {0};
    UINT32 uiRet = 0;
    UINT32 uiLength = 0;
    UINT32 loop = 0;

    uiRet = BspGetPwrHistoryInfo(0, strHis, sizeof(strHis));
    if(BSP_OK != uiRet)
    {
        dbgErr("func:[%s] BspGetPwrHistoryInfo error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    uiLength += snprintf_s(pucBuf+uiLength, sizeof(pucBuf), "BspCheckPowerHistoryInfo 0x[%x],0x[%x],0x[%x],0x[%x],0x[%x],0x[%x],0x[%x],0x[%x]\n"
    		,strHis[0],strHis[1],strHis[2],strHis[3],strHis[4],strHis[5],strHis[6],strHis[7]);
    BspSavePwrInfoToFile(pucBuf, uiLength);

    for (loop = 0; loop < sizeof(strHis); loop++)
    {
        dbgInfoEx("PWR History:\n");
        dbgInfoEx("Data[%d] : 0x%x\n", loop, strHis[loop]);
    }
    uiRet =BspGetPwrEnableTime(ucStrTimeAddr, NELEMENTS(ucStrTimeAddr));
    if(BSP_OK != uiRet)
    {
        return BSP_ERROR;
    }
    /*此处设置时间的作用是使能开关，并不要求时间的准确性*/
    uiRet = BspSetPwrTimeEnable(0, ucStrTimeAddr, PWR_HISTORY_SET_TIME_LEN);
    if(BSP_OK != uiRet)
    {
        dbgErr("func:[%s] BspSetPwrTimeEnable error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspGetBoardPwrModuleVolt(UINT32 index, INT32 *pVolt)  //BspGetBoardVolt不符合返回值为BSP_OK或者BSP_ERROR的写法，特此更改
{
    UINT32 ulRetVal = BSP_OK;
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pVolt);
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRetVal = BspGetVoltOut(devid, pVolt);
    return ulRetVal;
}

/***TPS***********/
UINT32 BspGetMonitorPwrIn(UINT32 index, INT32 *pPower)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pPower);
    
    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrIn(devid, pPower);
}

UINT32 BspGetMonitorPwrOut(UINT32 index, INT32 *pPower)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pPower);
    
    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrOut(devid, pPower);
}


UINT32 BspGetMonitorPwrTemp(UINT32 index, INT32 *pTemp)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    T_PmbAdcCfgPriv *pPmbPriv = NULL;
    int snpRet;

    INPUT_POINTER_CHECK(pTemp);
    pPmbPriv = BspGetPmbCfgPriv();
    if(NULL != pPmbPriv->pGetTemp)
    {
        return pPmbPriv->pGetTemp(index, (UINT32 *)pTemp);
    }
    
    snpRet = snprintf_s(bufName,sizeof(bufName),"TempPmb%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetTempSensorInfo(devid, pTemp);
}

UINT32 BspGetMonitorPwrDeviceTemp(UINT32 DevType,UINT32 ulIndexInput,INT32 *pTemp)
{
    char    bufName[64] ={0};
    /* UINT32  PmbAdcIdx   = 0;    */
    UINT32  devid       = 0; 
    UINT32  retVal      = BSP_OK; 
    UINT32  ulIndex     = 0;
    int snpRet;
    
    INPUT_POINTER_CHECK(pTemp);
    ulIndex     = ulIndexInput;
    INPUT_SWITCH_CASE_SELECT(DevType,ulIndex);    

    dbgInfoEx("[%s]:Select Mode %d,Num Pre %d,Total Num This Mode %d,Final Index %d,Index This Mode %d\n",\
              __func__,DevType,ulTempNumPre[DevType],ulPerTempNumTotal[DevType],ulIndex,ulIndexInput);
              
    snpRet = snprintf_s(bufName,sizeof(bufName),"TempPmb%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    dbgInfoEx("[%s]:Get BufName is %s\n",__func__,bufName);
    
    devid = BspDevNameToId(bufName);
    dbgInfoEx("[%s]:Device Id is %d\n",__func__,devid);
    
    INPUT_DEVICEID_CHECK(devid);
    retVal = BspGetTempSensorInfo(devid, pTemp);
    return retVal;
}


UINT32 BspGetMonitorPwrVoltIn(UINT32 index, INT32 *pVolt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    INPUT_POINTER_CHECK(pVolt);
    
    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    return BspGetVoltIn(devid, pVolt);
}

UINT32 BspGetMedian(UINT32 num1,UINT32 num2,UINT32 num3)
{
    UINT32 max = 0;
    UINT32 min = 0;
    UINT32 mid = 0;
    UINT32 sum = 0;

    //coverity[cert_int30_c_violation:SUPPRESS]
    sum = (num1 + num2 + num3);
    max = num1 > num2 ? num1 : num2;
    max = max > num3 ? max : num3;
    min = num1 < num2 ? num1 : num2;
    min = min < num3 ? min : num3;
    //coverity[cert_int30_c_violation:SUPPRESS]
    mid = (sum - max - min);

    return mid;
}

UINT32 BspGetMonitorPwrVoltOut(UINT32 index, INT32 *pVolt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    /*UINT32 errCount = 0;*/
    UINT32 ulRetVal = 0;
    T_PmbAdcCfgPriv *pPmbPriv = NULL;
    int snpRet;
    UINT32 count = 0;
    UINT32 middleNum = 0;
    INT32 pwrVolt[3] = {0};
    UINT32 idx = 0;

    INPUT_POINTER_CHECK(pVolt);
    pPmbPriv = BspGetPmbCfgPriv();
    if(NULL != pPmbPriv->pUout)
    {
        return pPmbPriv->pUout(index, 0, (UINT32 *)pVolt);
    }
    
    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    /*增加防抖处理:连续获取三次核电压取中值*/
    while(count < GET_CURR_VOLT_MAX_NUM)
    {
        ulRetVal = BspGetVoltOut(devid, pwrVolt+idx);
        if(0 == ulRetVal)
        {
            idx++;
        }
        if(GET_CURR_VOLT_IDX_MAX_NUM == idx)
        {
            break;
        }
        count++;
    }

    if(GET_CURR_VOLT_MAX_NUM == count)
    {
        *pVolt = 0;
        return BSP_ERROR;
    }
    else
    {
        //coverity[cert_int31_c_violation:SUPPRESS]
        middleNum = BspGetMedian(*pwrVolt,*(pwrVolt+1),*(pwrVolt+2));
        *pVolt = middleNum;
    }

    return ulRetVal;
}

/* Started by AICoder, pid:id77am5aa7p19571405d085be0f45342e2358a9f */
UINT32 BspGetMonitorPwrNominalVout(UINT32 index, INT32 *pVolt)
{
    CHAR bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    UINT32 ulRetVal = BSP_OK;
    T_PmbAdcCfgPriv *pPmbPriv = NULL;
    INT32 snpRet = 0;
    INT32 pwrVolt = 0;

    INPUT_POINTER_CHECK(pVolt);
    pPmbPriv = BspGetPmbCfgPriv();
    if(NULL != pPmbPriv->pUout)
    {
        return pPmbPriv->pUout(index, 0, (UINT32 *)pVolt);
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRetVal = BspGetNominalVoltOut(devid, &pwrVolt);
    *pVolt = pwrVolt;

    return ulRetVal;
}
/* Ended by AICoder, pid:id77am5aa7p19571405d085be0f45342e2358a9f */

UINT32 BspGetMonitorPwrCurrOut(UINT32 index, INT32 *plCrntOut)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    /*UINT32 errCount = 0;*/
    UINT32 ulRetVal = 0;
    T_PmbAdcCfgPriv *pPmbPriv = NULL;
    int snpRet;
    UINT32 count = 0;
    UINT32 middleNum = 0;
    INT32 pwrCurr[3] = {0};
    UINT32 idx = 0;

    INPUT_POINTER_CHECK(plCrntOut);
    pPmbPriv = BspGetPmbCfgPriv();
    if(NULL != pPmbPriv->pIout)
    {
        return pPmbPriv->pIout(index, 0, (UINT32 *)plCrntOut);
    }
    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    
    /*增加防抖处理:连续获取三次核电流取中值*/
    while(count < GET_CURR_VOLT_MAX_NUM)
    {
        ulRetVal = BspGetCurrOut(devid, pwrCurr+idx);
        if(0 == ulRetVal)
        {
            idx++;
        }
        if(GET_CURR_VOLT_IDX_MAX_NUM == idx)
        {
            break;
        }
        count++;
    }

    if(GET_CURR_VOLT_MAX_NUM == count)
    {
        *plCrntOut = 0;
        return BSP_ERROR;
    }
    else
    {
        //coverity[cert_int31_c_violation:SUPPRESS]
        middleNum = BspGetMedian(*pwrCurr,*(pwrCurr+1),*(pwrCurr+2));
        *plCrntOut = middleNum;
    }

    return ulRetVal;
}

UINT32 BspGetPwrCurr(UINT32 index, INT32 *pCurr)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;
    UINT32 powIndex = index;
    INPUT_POINTER_CHECK(pCurr);
    if(NULL != pGetPwrCurrIn)
    {
        return pGetPwrCurrIn(index,0,pCurr);
    }

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    BspGetIna2xxIndex(&powIndex);
    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",powIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    
    if (BSP_ERROR == BspGetCurrOut(devid, pCurr))
    {
        return BSP_ERROR;  
    }
    return BSP_OK;
}

/*单位1mv*/
UINT32 BspSetMonitorPwrVoltOut(UINT32 index, INT32 Volt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    T_PmbAdcCfgPriv *pPmbPriv = NULL;
    int snpRet;
    pPmbPriv = BspGetPmbCfgPriv();
    if(NULL != pPmbPriv->pSetVolt)
    {
        return pPmbPriv->pSetVolt(index, Volt);
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetVoltOut(devid, Volt);
}

UINT32 BspWrMonitorPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 ucVal)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspWriteRegVal(devid,ulReg,&ucVal,1);
}
UINT32 BspRdMonitorPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 *pucVal)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    snpRet = snprintf_s(bufName,sizeof(bufName),"PmbAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    
    return BspReadRegVal(devid,ulReg,pucVal,1);
}

UINT32 BspWrPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 *ucVal,UINT32 uByte)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspWriteRegVal(devid,ulReg,ucVal,uByte);
}

UINT32 BspRdPwrRegByte(UINT32 index, UINT32 ulReg,UINT8 *pucVal,UINT32 uByte)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspReadRegVal(devid,ulReg,pucVal,uByte);
}

UINT32 BspMonitorPwrDevFuncToId(const char *pucDevFuncName,UINT32 *index)
{
    UINT32 ulDevCnt = 0;
    T_PmbAdcCfg * ptPmbAdcCfgPara = NULL;

    INPUT_POINTER_CHECK(pucDevFuncName);
    INPUT_POINTER_CHECK(index);

    ptPmbAdcCfgPara = BspGetPmbAdcCfgPara();
    //coverity[cert_exp34_c_violation:SUPPRESS]
    for(ulDevCnt=0;ulDevCnt<ptPmbAdcCfgPara->cfgNum;ulDevCnt++)
    {
        dbgInfoEx("DevIdx%d,Func Name %s,Target Name %s\n",ulDevCnt,ptPmbAdcCfgPara->pCfgPara[ulDevCnt].FuncName,pucDevFuncName);    
        if (strcmp(pucDevFuncName, (CHAR *)(ptPmbAdcCfgPara->pCfgPara[ulDevCnt].FuncName)) == 0)
        {
            break;
        }
    }
    if(ulDevCnt!=ptPmbAdcCfgPara->cfgNum)
    {
        *index = ulDevCnt;
         return BSP_OK;
    }
    else
    {
        dbgErr("%s>>can't find %s 's Index Num !\n",__FUNCTION__,pucDevFuncName);
        return BSP_ERROR;
    }
   
}
UINT32 BspSetMonitorPwrDeviceVolt(UINT32 DevType,UINT32 Index,INT32 Volt)
{
    char    bufName[64] ={0};
    UINT32  PmbAdcIdx = 0;
    UINT32  ulRet = BSP_OK;
    int snpRet;
        
    switch(DevType)
    {
        case MCS_CORE_VOLT_SET:
            snpRet = snprintf_s(bufName,sizeof(bufName),"Mcs%dCore",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;            
        case MCS_IO_VOLT_SET:
            /*A9611 MCS IO电压0.92V---1*/
            snpRet = snprintf_s(bufName,sizeof(bufName),"McsIO%d",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;
        case FPGA_CORE_VOLT_SET:
            /*A9611 BBFPGA Core电压0.85V----0/1*/
            snpRet = snprintf_s(bufName,sizeof(bufName),"Fpga%dCore",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;
        default:
            dbgErr("%s>>Can't match devicetype [0x%x]!\n",__FUNCTION__,DevType);
            return BSP_ERROR;
    }
    if(BSP_OK==BspMonitorPwrDevFuncToId(bufName,&PmbAdcIdx))
    {
        dbgInfoEx("%s>>[DevType%d,Idx%d,Name %s],PmbAdcIdx%d,Volt%d\n",__FUNCTION__,DevType,Index,bufName,PmbAdcIdx,Volt);
        ulRet = BspSetMonitorPwrVoltOut(PmbAdcIdx,Volt);
        if(ulRet == BSP_OK)/*记录生效值*/
        {
            if(Index >= PWR_MON_CHIP_NUM)
            {
                dbgErr("%s>>Input para is out of array size[%dx%d] !Type %d,Idx %d\n",__FUNCTION__,PWR_MON_TYPE_NUM,PWR_MON_CHIP_NUM,\
                    DevType,Index);
                ulRet = BSP_ERROR;
            }
            else
            {
                atPwrMonVolt[DevType][Index] = Volt;
                ulRet = BSP_OK;
            }
        }
        return ulRet;
    }
    else
    {
        dbgErr("%s>>DevFuncToId Failed ![DevType%d,Idx%d,Name %s,Volt%d]\n",__FUNCTION__,DevType,Index,bufName,Volt);
        return BSP_ERROR;
    } 
}
UINT32 BspGetMonitorPwrDeviceSetVolt(UINT32 DevType,UINT32 Index,INT32 *Volt)
{
    /* UINT32 ulRet = BSP_OK; */
    
    if((DevType >= PWR_MON_TYPE_NUM)||(Index >= PWR_MON_CHIP_NUM)||(Volt == NULL))
    {
        dbgErr("%s>>Input para is out of array size[%dx%d] or point is null ![Type %d,Idx %d]\n",__FUNCTION__,PWR_MON_TYPE_NUM,PWR_MON_CHIP_NUM,\
            DevType,Index);
        return BSP_ERROR;
    }

    if(atPwrMonVolt[DevType][Index] == 0)
    {
        dbgErr("%s>>DevType %d,Index %d,Volt is 0 !\n",__FUNCTION__,DevType,Index);
        return BSP_ERROR;
    }
    else
    {
        *Volt = atPwrMonVolt[DevType][Index];
        dbgInfoEx("%s>>DevType %d,Index %d,Volt is %d !\n",__FUNCTION__,DevType,Index,*Volt);
    }
    return BSP_OK;
}
UINT32 BspGetMonitorPwrDeviceVolt(UINT32 DevType,UINT32 Index,INT32 *Volt)
{
    char    bufName[64] ={0};
    UINT32  PmbAdcIdx = 0;
    int snpRet;

    switch(DevType)
    {
        case MCS_CORE_VOLT_CURR_RELATION:
        {
            snpRet = snprintf_s(bufName,sizeof(bufName),"Mcs%dCore",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;
        }
        case MCS_IO_VOLT_CURR_RELATION:
        {
            snpRet = snprintf_s(bufName,sizeof(bufName),"McsIO%d",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;
        }
        case FPGA_CORE_VOLT_CURR_RELATION:
        {
            snpRet = snprintf_s(bufName,sizeof(bufName),"Fpga%dCore",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));      
            break;
        }
        default:
        {    
            dbgErr("%s>>Can't match devicetype [0x%x]!\n",__FUNCTION__,DevType);
            return BSP_ERROR;
        }
    }
    if(BSP_OK==BspMonitorPwrDevFuncToId(bufName,&PmbAdcIdx))
    {
        dbgInfoEx("%s>>[DevType%d,Idx%d,Name %s],PmbAdcIdx%d]\n",__FUNCTION__,DevType,Index,bufName,PmbAdcIdx);
        return BspGetMonitorPwrVoltOut(PmbAdcIdx, Volt);
    }
    else
    {
        dbgErr("%s>>DevFuncToId Failed ![DevType%d,Idx%d,Name %s,]\n",__FUNCTION__,DevType,Index,bufName);
        return BSP_ERROR;
    }
}

UINT32 BspGetMonitorPwrDeviceCurr(UINT32 DevType,UINT32 Index,INT32 *plCrntOut)
{
    char    bufName[64] ={0};
    UINT32  PmbAdcIdx = 0;
    int snpRet;
    switch(DevType)
    {
        case MCS_CORE_VOLT_CURR_RELATION:
        {
            snpRet = snprintf_s(bufName,sizeof(bufName),"Mcs%dCore",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;
        }
        case MCS_IO_VOLT_CURR_RELATION:
        {
            snpRet = snprintf_s(bufName,sizeof(bufName),"McsIO%d",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;
        }
        case FPGA_CORE_VOLT_CURR_RELATION:
        {
            snpRet = snprintf_s(bufName,sizeof(bufName),"Fpga%dCore",Index);
            SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
            break;
        }
        default:
        {    
            dbgErr("%s>>Can't match devicetype [0x%x]!\n",__FUNCTION__,DevType);
            return BSP_ERROR;
        }
    }
    if(BSP_OK==BspMonitorPwrDevFuncToId(bufName,&PmbAdcIdx))
    {
        dbgInfoEx("%s>>[DevType%d,Idx%d,Name %s],PmbAdcIdx%d]\n",__FUNCTION__,DevType,Index,bufName,PmbAdcIdx);
        return BspGetMonitorPwrCurrOut(PmbAdcIdx, plCrntOut);
    }
    else
    {
        dbgErr("%s>>DevFuncToId Failed ![DevType%d,Idx%d,Name %s]\n",__FUNCTION__,DevType,Index,bufName);
        return BSP_ERROR;
    }
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 showpmbadcpara(VOID)
{
    UINT32 ulDevCnt = 0;
    T_PmbAdcCfg * ptPmbAdcCfgPara = NULL;

    ptPmbAdcCfgPara = BspGetPmbAdcCfgPara();
    //coverity[cert_exp34_c_violation:SUPPRESS]
    for(ulDevCnt=0;ulDevCnt<ptPmbAdcCfgPara->cfgNum;ulDevCnt++)
    {
        dbgPrn("Idx%d,Func Name %s,(DevName 0x%x,DevId 0x%x,RefVolt %d)\n",ulDevCnt,ptPmbAdcCfgPara->pCfgPara[ulDevCnt].FuncName, \
            ptPmbAdcCfgPara->pCfgPara[ulDevCnt].DeviceName,ptPmbAdcCfgPara->pCfgPara[ulDevCnt].DeviceIndex, \
            ptPmbAdcCfgPara->pCfgPara[ulDevCnt].refVolt);
    }    
    return BSP_OK;
}
#endif
UINT32 BspCtrlPm(UINT32 index,UINT32 cmd)
{
    UINT32 ret = BSP_OK;
    UINT32 maxCnt = 3;  /*独立电源有一个或者两个电源砖 大板电源可以有一个获取3个电源砖*/
    UINT32 loop = 0;

    ret = BspHalAdaptMaskPwrOffAlarmReport();
    fpgaloadLog(LOAD_INFO,"[%s] s_PwrSwitchCfgFun %p index %d cmd %d\n", __FUNCTION__, s_PwrSwitchCfgFun, index, cmd);
    if(NULL != s_PwrSwitchCfgFun)
    {
        return s_PwrSwitchCfgFun(index, cmd);
    }
     for(loop = 0; loop < maxCnt; loop++)  /*如果loop大于实际数量，实际已复位而且预期会报错*/
     {
        fpgaloadLog(LOAD_INFO,"[%s] loop %d cmd %d\n", __FUNCTION__, loop, cmd);
        ret |= BspSetPwrOn(loop,cmd);
     }

     return ret;
}

/*****************************************************************************
 *  函数名称   : BspGetRemotePwrOffStatus()
 *  功能描述   : 针对特殊机型通过信令拉IIC进行远程掉电复位,此接口获取网管发起远程掉电复位控制字状态
 *  输入参数   :
 *  输出参数   :
 *  返 回 值:   BSP_OK - 收到掉电指令; BSP_ERROR - 未收到掉电指令
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetRemotePwrOffStatus(VOID)
{
    UINT32 retVal = 0;
    UINT32 pwrOffFlag = 0;

    retVal = BspHalAdaptCpriGetCpriRstReq(&pwrOffFlag);
    /*retVal |= BspHalAdaptCpriClearCpriRstReq();*/
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] No Reading PwrOffsetFlag!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(pwrOffFlag)
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

/*****************************************************************************
 *  函数名称   : BspGetRemoteCrmPwrStatus()
 *  功能描述   : 针对电源改版前机型不支持远程掉电复位，此接口获取网管发起远程掉电复位Crm 6bit状态,为1表示有掉电复位,以及Crm调电复位状态为0xf，上报给app，并执行软复位
 *  输入参数   :
 *  输出参数   :
 *  返 回 值:   BSP_OK - app执行软复位; BSP_ERROR - 不执行
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetRemoteCrmPwrStatus(VOID)
{
    UINT32 retVal = 0;
    UINT32 crmPwrAlarm = 0;
    UINT32 crmPwdRstStatus = 0;
    UINT32 crmFlag = 0;

    retVal = BspHalAdaptCrmGetPwrAlarm(&crmPwrAlarm);//获取crm内远程掉电复位检测参数
    dbgInfoEx("[%s] crmPwrAlarm: %d\n",__func__,crmPwrAlarm);

    if( BBU_PB_RRU == BspGetPbOrBbuMode() )/* 连PB检测第6bit */
    {
        crmFlag = (crmPwrAlarm & 0x40) >> 6;
        dbgInfoEx("[%s] crmFlag: %d mode:BBU_PB_RRU\n",__func__,crmFlag);
        retVal |= BspHalAdaptClrCrmPwrAlarm(6,6);//上报状态6bit位清除
    }
    else/* 直连BBU检测第7bit */
    {
        crmFlag = (crmPwrAlarm & 0x80) >> 7;
        dbgInfoEx("[%s] crmFlag: %d mode:BBU_RRU \n",__func__,crmFlag);
        retVal |= BspHalAdaptClrCrmPwrAlarm(7,7);//上报状态第7bit位清除
    }
    
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] No Reading crmPwrAlarm erro!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspHalAdaptGetCrmRmtPwdRstSrc(&crmPwdRstStatus);
    dbgInfoEx("[%s] crmPwdRstStatus: %d\n",__func__,crmPwdRstStatus);
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] get crmPwdRstStatus erro!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if((crmFlag) && (0xf == crmPwdRstStatus))//满足检测到crm内远程掉电复位控制字和Crm硬复位状态0xf，app执行软复位
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

/*****************************************************************************
 *  函数名称   : Bsp_WfsGetBoard12VLowAlm(*)
 *  功能描述   : 单板中频12V欠压告警获取接口
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK - 成功; BSP_ERROR - 失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetBoard12VLowAlm(UINT32 chipId, UINT32 *pBoardLowAlm)
{
    UINT32 retVal = 0;
    UINT32 ulBoardLowAlm = 0;
    UINT32 ulBoardAlm = 0;

    retVal = BspHalAdaptClrCrmPwrAlarm(14,14);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s] clr board 12v alm fail!\n",__func__);
        return BSP_ERROR;
    }

    retVal |= BspHalAdaptCrmGetPwrAlarm(&ulBoardAlm);
        if (retVal != BSP_OK)
    {
        dbgErr("[%s] get board 12v alm fail!\n",__func__);
        return BSP_ERROR;
    }

    ulBoardLowAlm = !(!(ulBoardAlm & BIT_SET(14)));
    if (pBoardLowAlm == NULL)
    {
    	dbgInfoEx("[%s] chip[%d] %s\n",__func__,chipId,ulBoardLowAlm==0x0?"12V OK!":"12V LOW ALM!");
    }
    else
    {
        *pBoardLowAlm = ulBoardLowAlm;
    }
    return retVal;
}
/*****************************************************************************
 *  函数名称   : Bsp_WfsGetBoard48VLowAlm(*)
 *  功能描述   : 单板中频48V欠压告警获取接口
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK - 成功; BSP_ERROR - 失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetBoard48VLowAlm(UINT32 chipId, UINT32 *pBoardLowAlm)
{
    UINT32 retVal = 0;
    UINT32 ulBoardLowAlm = 0;
    UINT32 ulBoardAlm = 0;

    retVal = BspHalAdaptClrCrmPwrAlarm(16,16);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s] clr board 48v low alm fail!\n",__func__);
        return BSP_ERROR;
    }

    retVal |= BspHalAdaptCrmGetPwrAlarm(&ulBoardAlm);
        if (retVal != BSP_OK)
    {
        dbgErr("[%s] get board 48v low alm fail!\n",__func__);
        return BSP_ERROR;
    }

    ulBoardLowAlm = !(!(ulBoardAlm & BIT_SET(16)));
    if (pBoardLowAlm == NULL)
    {
    	dbgInfoEx("[%s] chip[%d] %s\n",__func__,chipId,ulBoardLowAlm==0x0?"48V OK!":"48V LOW ALM!");
    }
    else
    {
        *pBoardLowAlm = ulBoardLowAlm;
    }
    return retVal;
}
/*****************************************************************************
 *  函数名称   : BspGetBoardPowerdownAlm(*)
 *  功能描述   : 单板中频power down告警获取接口
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK - 成功; BSP_ERROR - 失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetBoardPowerdownAlm(UINT32 chipId, UINT32 *pBoardPwrdownAlm)
{
    UINT32 retVal = 0;
    UINT32 ulBoardLowAlm = 0;
    UINT32 ulBoardAlm = 0;

    retVal |= BspHalAdaptCrmGetPwrAlarm(&ulBoardAlm);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s] get board power_down alm fail!\n",__func__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptClrCrmPwrAlarm(15,15);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s] clr board power_down alm fail!\n",__func__);
        return BSP_ERROR;
    }

    ulBoardLowAlm = !(!(ulBoardAlm & BIT_SET(15)));
    if (pBoardPwrdownAlm == NULL)
    {
    	dbgInfoEx("[%s] chip[%d] %s\n",__func__,chipId,ulBoardLowAlm==0x0?"power down test OK!":"power down ALM!");
    }
    else
    {
        *pBoardPwrdownAlm = ulBoardLowAlm;
    }
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetBoardN8vAlm(*)
 *  功能描述   : 单板中频-8v告警获取接口
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK - 成功; BSP_ERROR - 失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetBoardN8vAlm(UINT32 *pBoardN8vAlm)
{
    UINT32 retVal = 0;
    UINT32 ulBoardAlm = 0;

    retVal = BspHalAdaptCrmGetN8vAlarm(&ulBoardAlm);
    if (pBoardN8vAlm == NULL)
    {
        dbgInfoEx("[%s] %s\n",__func__,ulBoardAlm==0x0?"N8V ALM!":"N8V OK!");
    }
    else
    {
        *pBoardN8vAlm = ulBoardAlm;
    }

    return retVal;
}

/* Started by AICoder, pid:t3360b4b4481fc514da90b2810c97b1cc2432ac3 */
UINT32 BspGetN8V_OK(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 status = BSP_OK;

    ret = BspGetBoardN8vAlm(&status);
    dbgInfoEx("%s: ret[%u],status[%u]", __FUNCTION__, ret, status);
    if ((BSP_OK == ret) && (BSP_OK == status))
    {
        return BSP_ERROR;/*有-8V告警*/
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:t3360b4b4481fc514da90b2810c97b1cc2432ac3 */

/*****************************************************************************
 *  函数名称   : BspGetRgpsAndAisgPowerAlm(*)
 *  功能描述   : 22V掉电告警测试(电调）
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK - 成功; BSP_ERROR - 失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 ******************************************************************************/
UINT32 BspGetRgpsAndAisgPowerAlm(UINT32 chipId, UINT32 *pAisgPwrdownAlm)
{
    UINT32 retVal = 0;
    UINT32 ulBoardLowAlm = 0;
    UINT32 ulBoardAlm = 0;

    retVal = BspHalAdaptClrCrmPwrAlarm(21,21);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s] clr board 22V power_down alm fail!\n",__func__);
        return BSP_ERROR;
    }
    BspSysMsDelay(100);

    retVal |= BspHalAdaptCrmGetPwrAlarm(&ulBoardAlm);
        if (retVal != BSP_OK)
    {
        dbgErr("[%s] get board 22V power_down alm fail!\n",__func__);
        return BSP_ERROR;
    }

    ulBoardLowAlm = !(!(ulBoardAlm & BIT_SET(21)));
    if (pAisgPwrdownAlm == NULL)
    {
        dbgInfo("[%s] chip[%d] %s\n",__func__,chipId,ulBoardLowAlm==0x0?"22V test OK!":"22V ALM!");
    }
    else
    {
        *pAisgPwrdownAlm = ulBoardLowAlm;
    }
    return retVal;
}

UINT32 BspGetPwrSlightOverTempAlmStatus(UINT32 index, UINT32 rfchanNum, UINT32 *pStatus)
{
    static UINT32 keep[PWR_TEMPALM_NUM_MAX][TBL_PWRTEMP_ALM_NUM_MAX] = {{0}}; //历史告警状态暂存
    INT32 tmp = 0;
    INT32 tempPeak = 0;//温度峰值
    INT32 tempRec = 0; //温度恢复
    UINT32 rfchan = 0;
    UINT32 thresholdId[PWR_TEMPALM_NUM_MAX] = {BSP_THRESHOLD_ID_SLIGHTOVER_PWR_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR1_TEMPER,
                                               BSP_THRESHOLD_ID_SLIGHTOVER_PWR2_TEMPER,BSP_THRESHOLD_ID_SLIGHTOVER_PWR3_TEMPER,
                                               BSP_THRESHOLD_ID_SLIGHTOVER_PWR4_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR5_TEMPER,
                                               BSP_THRESHOLD_ID_SLIGHTOVER_PWR6_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR7_TEMPER};

    INPUT_POINTER_CHECK(pStatus);
    RETURN_VAL_DO_IF_EXP(index >= PWR_TEMPALM_NUM_MAX, BSP_ERROR, dbgErr("%s: pwrIndex:%d is not exit!!\n",__FUNCTION__, index));

    if(BspGetPwrTemp(index, &tmp) != BSP_OK)
    {
        dbgInfoEx("[BspGetPwrTemp] index[%d] err\n", index);
        return BSP_ERROR;
    }

    for(rfchan = 0; rfchan < rfchanNum; rfchan++)
    {
        if(BspGetTempThreshold(rfchan, thresholdId[index], &tempPeak, &tempRec) != BSP_OK)
        {
            dbgErr("[%s]:pwrSlightThreshold Get Failed\n", __FUNCTION__);
            return BSP_ERROR;
        }

        dbgInfoEx("temp[%d]=[%d]\tsPeak = [%d]\t sRec= [%d]\t\n", index, tmp, tempPeak, tempRec);

        if(tmp > tempPeak)
        {
            keep[index][rfchan] = 1;
            *pStatus |= PWR_SLIGHT_OVER_TEMP_ALM(rfchan);
        }
        else if(tmp > tempRec)
        {
            if(keep[index][rfchan])
            {
                *pStatus |= PWR_SLIGHT_OVER_TEMP_ALM(rfchan);
            }
        }
        else
        {
            keep[index][rfchan] = 0;
            *pStatus &= PWR_TEMP_NORMAL(rfchan);
        }

        dbgInfoEx("PwrIndex = %d, rfchan = %d, ChanAlarmSta = %d \n", index, rfchan, keep[index][rfchan]);
    }

    return BSP_OK;
}

UINT32 BspGetPowerAlmStatus(VOID)
{
    /*fdd建链后高层会判断电源状态，目前暂时无法访问电源，先屏蔽，否则上报ERROR，高层会发起复位*/
    UINT32 status  = 0;
    UINT32 pwrtempalarmstatus = 0;
    UINT32 ulPwrAlmStatus = 0;
    UINT32 retVal = 0;
    UINT32 chipIdx = 0;
    UINT32 pStatus = 0;
    UINT32 pwrindex = 0;
    UINT32 pwrTempSensorNum = 0;
    UINT32 rfChanNum = 0;

    if(NULL != pGetPowerStatusCall)
    {
        if (BSP_ERROR != pGetPowerStatusCall(0, &pStatus))
        {
            status = pStatus;
            dbgInfoEx("get power module status %d success !\n",status);
        }
        else
        {
            dbgErr("get power module status failed !\n");
            return BSP_ERROR;
        }
    }
    else
    {
        /*RRU输入掉电告警*/
        retVal = BspGetBoard12VLowAlm(chipIdx,&status);
        if((retVal == BSP_OK) && (0 != status))
        {
            ulPwrAlmStatus |= (UINT32)BSP_POWER_DOWN_ALARM;
        }

        status = BspGetPwrVoltAlarm();
        /*48V过压告警(4.2平台过压告警门限是60V,过压恢复门限是58V)
         *48V欠压告警(4.2平台欠压告警门限是36V,欠压恢复门限是37V) */
        if(status & BSP_BIT(1))  /*过压*/
        {
            ulPwrAlmStatus |= BSP_POWER_48V_HIGH_ALARM;
        }
        else if(status & BSP_BIT(0))   /*欠压*/
        {
            ulPwrAlmStatus |= BSP_POWER_48V_LOW_ALARM;
        }
        else
        {
            ;
        }

        retVal = BspGetTempAlmSensorNum(&pwrTempSensorNum);
        retVal |= BspGetPwrTempAlmChNum(&rfChanNum);

        for (pwrindex = 0; pwrindex < pwrTempSensorNum; pwrindex++)
        {
            dbgInfoEx("pwrTempSensorNum = %d, RfChanNum = %d\n", pwrTempSensorNum, rfChanNum);

            retVal |= BspGetPwrSlightOverTempAlmStatus(pwrindex, rfChanNum, &pwrtempalarmstatus);
            if((retVal == BSP_OK) && (0 != pwrtempalarmstatus))
            {
                ulPwrAlmStatus |= (UINT32)BSP_POWER_TEMP_HIGH_ALARM;
            }
        }

        dbgInfoEx("get power module status %d success !\n",ulPwrAlmStatus);

        return ulPwrAlmStatus;
    }

    return retVal;
}

UINT32 BspGetPowerStatus(VOID)
{
#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    UINT32 uPwrAlmStatus  = 0;
    uPwrAlmStatus = BspGetPowerAlmStatus();
    return uPwrAlmStatus;
#else
    return s_uPwrAlmStatus;
#endif

}

/* 获取电源温度检测点(传感器)个数 */
UINT32 BspGetPwrTempNodeNum(VOID)
{
    UINT32 loop = 0;
    static UINT32 devNum = RECORD_DATA_VALUE;
    static UINT32 nodeNum = 0;
    CHAR   *pDeviceId = NULL;
    T_HwInfo* hwInfo = NULL;

    if(RECORD_DATA_VALUE != devNum)
    {
        return nodeNum;
    }

    hwInfo = BspGetBoardPropInfo();
    INPUT_POINTER_CHECK(hwInfo);

    devNum = BspGetDevNum();
    for (loop = 0; loop < devNum; loop++)
    {
        pDeviceId = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acDeviceId;
        INPUT_POINTER_CHECK(pDeviceId);

        dbgInfoEx("[%s] deviceId:%s \n", __FUNCTION__, pDeviceId);
        if (0 == strncmp("TempRpdc", pDeviceId, 8))
        {
            nodeNum++;
        }
    }

    return nodeNum;
}

UINT32 BspUpatePowerStatus(VOID)
{
    UINT32 uPwrAlmStatus  = 0;

    uPwrAlmStatus = BspGetPowerAlmStatus();
    s_uPwrAlmStatus = uPwrAlmStatus;

    return BSP_OK;
}

/* 更新电源节点温度 */
UINT32 BspUpatePwrTemp(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 index = 0;
    INT32 pwrTemp = 0;
    UINT32 pwrTempSensorNum = 0;

    BspGetTempAlmSensorNum(&pwrTempSensorNum);
    if(0 == pwrTempSensorNum)
    {
        pwrTempSensorNum = BspGetPwrTempNodeNum();
        dbgInfoEx("[%s] pwrTempSensorNum: from .txt(%u), from rruproperty(%u) \n", __FUNCTION__, 0, pwrTempSensorNum);
    }

    s_tPwrNodeTemp.tempNum = pwrTempSensorNum;

    for(index = 0; index < pwrTempSensorNum; index++)
    {
        ret |= BspGetPwrTemp(index, &pwrTemp);

        s_tPwrNodeTemp.t_nodeTemp[index].nodeNo = index;
        s_tPwrNodeTemp.t_nodeTemp[index].temp = pwrTemp;
    }

    return ret;
}

/* 更新电源连接器节点温度 */
UINT32 BspUpdatePwrLetTemp(VOID)
{
    static CHAR dviceName[] = "TempPwrLet";
    UINT32 length = strnlen_s(dviceName, MAX_DEVICE_LEN);
    UINT32 index = 0;
    INT32  pwrLetTemp = 0;
    UINT32 pwrLetNodeNum = BspGetDeviceNodeNum(dviceName, length);
    CHAR   *barCode = NULL;
    UINT32 circCuitDamagedFlag = 0;  //电源连接器电路烧坏标志 0:正常 1:损坏
    T_BspInventoryInfo ptDevInfo = {0};
    CHAR *rruSeriesBarCode[] = {"219430980092", "219425754864", "219425448006", "219425153931", "219427446944", "219425447993", "219425153827",
                                "219425754863", "219425754862", "219425153875", "219425448029", "219430980625", "219425448001", "219425448024",
                                "219425153835", "219425153903", "219425448003", "219424062785", "219425754843", "219425448002", "219425153913",
                                "219423169631", "219424558101", "219424106806", "219425153704", "219424558010", "219423169594", "219424557994",
                                "219424403934", "219416698091", "219425341099", "219427447132", "219424385315", "219427447056", "219412884992",
                                "219410993117", "219417893453", "219424557983", "219424558013", "219422523897", "219425754529", "219425528406",
                                "219429372630", "219425153741", "219421816452", "219420268573", "219424118527"};
    UINT32 loop = 0;
    UINT32 rruNum = NELEMENTS(rruSeriesBarCode);

    (VOID)BspGetRruInventory(&ptDevInfo);
    barCode = ptDevInfo.acSerialNumber;

    for(loop = 0; loop < rruNum; loop++)
    {
        dbgInfoEx("barCode = %s, rruSeriesBarCode = %s\n", barCode, rruSeriesBarCode[loop]);
        if(BSP_OK == strcmp(barCode, rruSeriesBarCode[loop]))  //rruSeriesBarCode内为电源连接器电路烧坏的整机条码
        {
            circCuitDamagedFlag = 1;
            break;
        }
    }

    s_tPwrLetNodeTemp.pwrLetNodeNum = pwrLetNodeNum;
    for(index = 0; index < pwrLetNodeNum; index++)
    {
        s_tPwrLetNodeTemp.nodeTemp[index].nodeNo = index;

        pwrLetTemp = 0;
        if((BSP_OK == BspGetPwrInletTemp(index, &pwrLetTemp)) && (0 == circCuitDamagedFlag))
        {
            s_tPwrLetNodeTemp.nodeTemp[index].temp = pwrLetTemp;
        }
        else
        {
            s_tPwrLetNodeTemp.nodeTemp[index].temp = 0x7fffffff;
        }
    }

    return BSP_OK;
}

VOID BspSetPowStaThreadSw(UINT32 sw)
{
    s_uPowStaThreadSw = sw;
}

UINT32 BspGetPowStaThreadSw(void)
{
    return s_uPowStaThreadSw;
}

/* Started by AICoder, pid:ffa4er6579o782f146f30b00215246691a99b394 */
/*0x5a-只更新温度； 0x1-更新电源全部信息； 0x0-不更新电源温度*/
VOID BspSetPowTempThreadSw(UINT32 sw)
{
    s_pwrTmpCache.pwrTempThreadSwitch = sw;
}

UINT32 BspGetPowTempThreadSw(VOID)
{
    return s_pwrTmpCache.pwrTempThreadSwitch;
}


/*SWITCH_OFF-实时读取 SWITCH_ON-读取缓存值*/
VOID BspSetPowTempReadModeSw(UINT32 sw)
{
    s_pwrTmpCache.pwrTempCacheSwitch = sw;
}

UINT32 BspGetPowTempReadModeSw(VOID)
{
    return s_pwrTmpCache.pwrTempCacheSwitch;
}

/*电源任务未创建，则创建线程并且只更新电源温度*/
UINT32 BspEnableRdPwrTempByCache(VOID)
{
    BspSetPowTempReadModeSw(SWITCH_ON);
    BspSetPowTempThreadSw(PWR_ONLY_UPDATE_TEMP);
    return BSP_OK;
}

/*电源任务已经创建基础上增加更新电源温度的操作*/
UINT32 BspEnableRdPwrInfoByCache(VOID)
{
    BspSetPowTempReadModeSw(SWITCH_ON);
    BspSetPowTempThreadSw(SWITCH_ON);
    return BSP_OK;
}

/*实时读取电源温度*/
UINT32 BspDisableRdPwrTempByCache(VOID)
{
    BspSetPowTempReadModeSw(SWITCH_OFF);
    BspSetPowTempThreadSw(SWITCH_OFF);
    return BSP_OK;
}

/* Started by AICoder, pid:c9bd3f8468324f61451b09207093e726a0a843a5 */
UINT32 BspSetPwrReltimeTmpAvgDbgRetval(UINT32 index, UINT32 sw)
{
    if (index >= PWR_NODE_TEMP_MAX_MUM)
    {
        dbgInfo("index out of arry size[%d]\n", PWR_NODE_TEMP_MAX_MUM);
        return BSP_ERROR;
    }
    getRetimeTempRet[index] = sw;
    return BSP_OK;
}

UINT32 BspGetPwrReltimeTmpAvgDbgRetval(UINT32 index)
{
    UINT32 ret = BSP_OK;

    if (index >= PWR_NODE_TEMP_MAX_MUM)
    {
        dbgInfo("index out of arry size[%d]\n", PWR_NODE_TEMP_MAX_MUM);
        return BSP_ERROR;
    }

    if (SWITCH_ON == getRetimeTempRet[index])
    {
        ret = BSP_ERROR;
    }

    return ret;
}
/* Ended by AICoder, pid:c9bd3f8468324f61451b09207093e726a0a843a5 */

UINT32 BspGetPwrTmpAvg(UINT32 index, INT32 *pPwrTemp)
{
    UINT32 i = 0;
    INT32 pwrTmp[PWR_READ_TIMES] = {0};
    INT32 sumPwrTmp = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pPwrTemp);

    for (i = 0; i < PWR_READ_TIMES; i++)/*读3次温度*/
    {
        retVal = BspGetPwrTempRealTime(index, &pwrTmp[i]);
        retVal |= BspGetPwrReltimeTmpAvgDbgRetval(index);
        if (BSP_OK != retVal)/*只要一次温度读取失败，则使用历史值*/
        {
            dbgInfoEx("%s:get pwr[%d]Tmp failed\n", __FUNCTION__, index);
            return BSP_ERROR;
        }
        sumPwrTmp += pwrTmp[i];
        dbgInfoEx("%s:pwr[%d]Tmp [%d],sum[%d] \n", __FUNCTION__, index, pwrTmp[i], sumPwrTmp);
    }

    for (i = 0; i < PWR_READ_TIMES - 1; i++)/*相邻温度超10度则认为温度更新失败*/
    {
        if (abs(pwrTmp[i + 1] - pwrTmp[i]) >= PWR_ABNORMAL_THRESHOLD)
        {
            dbgInfoEx("%s:get pwr[%d]Tmp delta[%d]-[%d] over[%d] \n", __FUNCTION__, index, pwrTmp[i + 1], pwrTmp[i], PWR_ABNORMAL_THRESHOLD);
            return BSP_ERROR;
        }
    }

    *pPwrTemp = sumPwrTmp / PWR_READ_TIMES;/*按照平均值上报*/

    return BSP_OK;
}

UINT32 BspGetPwrTemp(UINT32 index, INT32 *pTemp)
{
#if defined(BSP_MAKE_VER) || defined(_BSP_WITH_WFS)
    return BspGetPwrTempRealTime(index, pTemp);
#else
    INPUT_POINTER_CHECK(pTemp);

    if (index >= NELEMENTS(s_pwrTmpCache.cachedTemp))
    {
        dbgInfo("index out of arry size[%d]\n", NELEMENTS(s_pwrTmpCache.cachedTemp));
        return BSP_ERROR;
    }
    if ((SWITCH_OFF == BspGetPowTempReadModeSw()) || (SWITCH_OFF == BspGetPowTempThreadSw()))
    {
        return BspGetPwrTempRealTime(index, pTemp);
    }

    *pTemp = s_pwrTmpCache.cachedTemp[index];
    return s_pwrTmpCache.tempUpdateRet[index];
#endif
}

UINT32 BspUpateOnePwrCacheTemp(UINT32 index)
{
    UINT32 ret = BSP_OK;
    INT32 pwrTemp = 0;
    UINT64 lastTime = 0;

    if (index >= NELEMENTS(s_pwrTmpCache.cachedTemp))
    {
        dbgInfo("index out of arry size[%d]\n", NELEMENTS(s_pwrTmpCache.cachedTemp));
        return BSP_ERROR;
    }

    ret = BspGetPwrTmpAvg(index, &pwrTemp);
    if (pwrTempFailedOver30minFlag[index] == SWITCH_ON)/*与方案沟通，电源超过30分钟异常,此后一直上报异常，直到RRU复位*/
    {
        s_pwrTmpCache.tempUpdateRet[index] = BSP_ERROR;
        return BSP_ERROR;
    }

    if (BSP_ERROR == ret)
    {
        if ((SWITCH_OFF == pwrTempFailedFlag[index]) || (SWITCH_ON == pwrTempAllTimeFailedFlag[index]))
        {
            pwrTempFailedTick[index][PWR_READ_FAILED_START_TICK_INDEX] = tickGet();
            pwrTempFailedFlag[index] = SWITCH_ON;
            return ret;
        }

        pwrTempFailedTick[index][PWR_READ_FAILED_END_TICK_INDEX] = tickGet();
        lastTime = pwrTempFailedTick[index][PWR_READ_FAILED_END_TICK_INDEX] - pwrTempFailedTick[index][PWR_READ_FAILED_START_TICK_INDEX];
        if (lastTime <= PWR_READ_FAILED_TIMEOUT)/*小于30min，按照历史值上报,返回BSP_OK*/
        {
            return BSP_OK;
        }
        else
        {
            pwrTempFailedOver30minFlag[index] = SWITCH_ON;
        }
    }
    else
    {
        /*只要成功一次，则重新计时*/
        pwrTempFailedFlag[index] = SWITCH_OFF;
        pwrTempFailedTick[index][PWR_READ_FAILED_START_TICK_INDEX] = 0;
        pwrTempAllTimeFailedFlag[index] = SWITCH_OFF;/*只要有一次成功，则一直失败标志释放*/
    }

    s_pwrTmpCache.cachedTemp[index] = pwrTemp;
    s_pwrTmpCache.tempUpdateRet[index] = ret;

    return ret;
}

/* 更新电源节点温度 */
UINT32 BspUpatePwrCacheTemp(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 index = 0;
    UINT32 pwrTempSensorNum = 0;
    static UINT32 UpdateTime = 0;

    UpdateTime++;
    if (0 != (UpdateTime % 5))/*10s更新周期*/
    {
        return BSP_OK;
    }

    pwrTempSensorNum = BspGetPwrTempNodeNum();

    for(index = 0; index < pwrTempSensorNum; index++)
    {
        ret |= BspUpateOnePwrCacheTemp(index);
    }

    return ret;
}
/* Ended by AICoder, pid:ffa4er6579o782f146f30b00215246691a99b394 */

void* BspPowerStatusThread(void *para)
{
    UINT64 tick1 = 0;
    UINT64 tick2 = 0;

    while (1)
    {
        tick1 = tick64Get();
        BspSysMsDelay_Sys(s_uPowerStatusPeriod);
        if ((s_uPowStaThreadSw != SWITCH_ON) || (PWR_NEED_UPDATE == BspGetPwrUpgradeFlag()))
        {
            #ifdef UT_FT_TEST
            return NULL;
            #endif
            continue;
        }

        /*更新电源温度:交付机型，进行电源温度更新；如果是首次起线程，只更新电源温度，做到无害化;*/
        if (SWITCH_OFF != BspGetPowTempThreadSw())
        {
            BspUpatePwrCacheTemp();
        }
        if (PWR_ONLY_UPDATE_TEMP == BspGetPowTempThreadSw())
        {
            #ifdef UT_FT_TEST
            return NULL;
            #endif
            continue;
        }

        BspUpatePowerStatus();  /* 更新电源告警状态 */
        BspUpatePwrTemp();
        BspUpdatePwrLetTemp();
#ifndef   MULT_PROGRESS_S
        BspUpdatePaVolt();
#endif
        tick2 = tick64Get();
        dbgInfoEx("<%s> tick1:%llu, tick1:%llu, time:%llu * 10ms\n", __FUNCTION__, tick1, tick2, (tick2-tick1));
        #ifdef UT_FT_TEST
        return NULL;
        #endif
    }
    return NULL;
}

/*电源状态任务初始化*/
UINT32 BspPowerStatusThreadInit(void)
{
    UINT32 ulRet = BSP_OK;
    INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;

    lTaskID = taskSpawn("BspPowerStatus", POWER_STATUS_PROCESS_PRIORITY, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspPowerStatusThread, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, lTaskID);
        ulRet = BSP_ERROR;
    }
    else
    {
        dbgInfo("create thread<%s> success!\n", __FUNCTION__);
    }

    return ulRet;
}

UINT32 BspSetSlavePortPaVoltCallBack(SET_SLAVE_PORT_PAVOLT pFuncCallback)
{
    pSetSlavePortPaVolt = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSlavePortPaVolt(UINT32 chan, UINT16 volt)
{
    UINT32 retVal = BSP_OK;
    UINT32 portId = 0;

    if(NULL != pSetSlavePortPaVolt)
    {
        BspGetPortIdByBspChn(chan, TX, &portId);
        return pSetSlavePortPaVolt(portId, volt);
    }
    dbgInfoEx("set slave port volt Call Back is NULL!\n");
    return retVal;
}

/* 28V电源没增加到硬件特性表，暂时直接调用ppc3xuart驱动接口, 待修改 */
UINT32 BspSetPaVolt(UINT32 index, INT32 volt)
{
    UINT32 ulPwrIndex = 0;
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;
    T_PaPwrVoltCtrlPara *pVoltPara = NULL;
    UINT32 portId = 0;
    UINT32 portSta = 0;

    ulMaxChnlSum = BspGetTxChanNum();
    if (index >= ulMaxChnlSum)
    {
        dbgErr("%s>>Para Over Error! Index(0~%d)= %d\n",
               __FUNCTION__, ulMaxChnlSum - 1, index);
        return BSP_ERROR;
    }
    if(BSP_OK != BspIsSupportRfsRemote())    /*子母端机型*/
    {
        BspGetPortIdByBspChn(index, TX, &portId);
        portSta = BspGetSlavePortStatus(portId);
        if(BSP_OK == portSta)  /*建链*/
        {
            return BspSlavePortPaVolt(index, volt);
        }
        if(0xf != portId)
        {
            dbgInfoEx("index %d portId %d\n", index, portId);
            return BSP_OK;   /*子端断链或者23通道没接*/
        }
    }

    pVoltPara = BspGetPaPwrVoltPara();
    if (pVoltPara->pSetVolt != NULL)
    {
        ulRetVal |= pVoltPara->pSetVolt(index, volt);
        dbgInfoEx("%s>>Index'%d: Ret= 0x%04X; SetVolt= %d\n",
                  __FUNCTION__, index, ulRetVal, volt);
    }    
    else
    {
        ulTmpRet = BspGetPwrIdxByBspChan(index, &ulPwrIndex);
        if (BSP_OK != ulTmpRet)
        {
            ulRetVal |= ulTmpRet;
            dbgErr("%s>>Index'%d PwrIdx Get Error! Ret= 0x%04X\n",
                   __FUNCTION__, index, ulTmpRet);
        }

        ulRetVal |= BspSetPwrVolt(ulPwrIndex, volt);
        dbgInfoEx("%s>>Index'%d PwrIdx'%d: Ret= 0x%04X; SetVolt= %d\n",
                  __FUNCTION__, index, ulPwrIndex, ulRetVal, volt);
    }
    return ulRetVal;
   
}

UINT32 BspSetPwrModulePaVolt(UINT32 index,INT32 volt)   //由于BspSetPaVolt不能返回BSP_OK或者BSP_ERROR，改造以适应静态调压方案要求
{
    UINT32 ulRetVal = BSP_OK;
    T_PaPwrVoltCtrlPara *pVoltPara = NULL;
    pVoltPara = BspGetPaPwrVoltPara();
    
    if(pVoltPara->pSetVolt != NULL)
    {
        ulRetVal = pVoltPara->pSetVolt(index,volt);
        dbgInfoEx("[%s]Set Point Volt Is %d mv\n",__FUNCTION__,volt); //后续修改为dbgInfoEx
    }    
    else
    {
        ulRetVal = BspSetPwrModuleVolt(index,volt);
        dbgInfoEx("[%s]Set Board Volt Is %d mv\n",__FUNCTION__,volt); //后续修改为dbgInfoEx
    }
    return ulRetVal;
}

UINT32 BspGetPwrModulePaVol(UINT32 index,INT32 *volt)              //由于BspGetPaVolt不能返回BSP_OK或者BSP_ERROR，改造以适应静态调压方案要求
{
    UINT32 ulRetVal = BSP_OK;
    //INT32 volt = 0;
    INPUT_POINTER_CHECK(volt);
    T_PaPwrVoltCtrlPara *pVoltPara = NULL;
    pVoltPara = BspGetPaPwrVoltPara();
    if(pVoltPara->pGetVolt != NULL)
    {
        ulRetVal = pVoltPara->pGetVolt(index,volt);
        dbgInfoEx("[%s]Get Point Volt Is %d mv\n",__FUNCTION__,*volt); 
    }
    else
    {
        ulRetVal = BspGetBoardPwrModuleVolt(index,volt);
        dbgInfoEx("[%s]Get Board Volt Is %d mv\n",__FUNCTION__,*volt); 
    }
    return ulRetVal;
}

INT32 BspGetPaVoltRealTime(UINT32 index)
{
    INT32  lPaVolt = 0;
    INT32  lGetRet = 0;
    UINT32 ulPwrIndex = 0;
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;
    T_PaPwrVoltCtrlPara *pVoltPara = NULL;

    ulMaxChnlSum = BspGetTxChanNum();
    if (index >= ulMaxChnlSum)
    {
        dbgErr("%s>>Para Over Error! Index(0~%d)= %d\n",
               __FUNCTION__, ulMaxChnlSum - 1, index);
        return BSP_ERROR;
    }

    pVoltPara = BspGetPaPwrVoltPara();
    if (pVoltPara->pGetVolt != NULL)
    {
        lGetRet = pVoltPara->pGetVolt(index, &lPaVolt);
        dbgInfoEx("%s>>Index'%d: Ret= 0x%04X; GetVolt= %d\n",
                  __FUNCTION__, index, lGetRet, lPaVolt);
    }
    else
    {
        ulTmpRet = BspGetPwrIdxByBspChan(index, &ulPwrIndex);
        if (BSP_OK != ulTmpRet)
        {
            ulRetVal |= BSP_BIT_SET(0);
            dbgErr("%s>>Index'%d PwrIdx Get Error! Ret= 0x%04X\n",
                   __FUNCTION__, index, ulTmpRet);
        }

        ulTmpRet = BspGetBoardVolt(ulPwrIndex, &lPaVolt);
        if (BSP_OK != ulTmpRet)
        {
            ulRetVal |= BSP_BIT_SET(1);
            dbgErr("%s>>Index'%d PwrIdx'%d PaVolt Get Error! Ret= 0x%04X\n",
                   __FUNCTION__, index, ulPwrIndex, ulTmpRet);
        }
        dbgInfoEx("%s>>Index'%d PwrIdx'%d: Ret= 0x%04X; GetVolt= %d\n",
                  __FUNCTION__, index, ulPwrIndex, ulRetVal, lPaVolt);
    }

    return lPaVolt;    
}

UINT32 BspSetPaVoltUpdatePara(T_PaVoltUpdatePara *pPara)
{
    if (pPara != NULL)
    {
        memcpy(&s_paVoltUpdatePara, pPara, sizeof(T_PaVoltUpdatePara));
    }
    return BSP_OK;
}

T_PaVoltUpdatePara *BspGetPaVoltUpdatePara()
{
    return &s_paVoltUpdatePara;
}

static UINT32 BspUpdatePaVolt(VOID)
{
    UINT32 retVal = BSP_OK;
    INT32  paVolt = 0;
    UINT32 paVoltNum = 0;
    UINT32 pwrIndex = 0;
    UINT32 bspchan = 0;
    T_PaPwrVoltCtrlPara *pVoltPara = NULL;
    T_PaVoltUpdatePara *pVoltUpdatePara = NULL;

    pVoltPara = BspGetPaPwrVoltPara();
    if (pVoltPara->pGetVolt != NULL)
    {
        pVoltUpdatePara = BspGetPaVoltUpdatePara();
        if(pVoltUpdatePara->pUpDatePaVolt != NULL)
        {
            pVoltUpdatePara->pUpDatePaVolt();
        }
    }
    else
    {
        retVal = BspGetPaVoltPwrNum(&paVoltNum);
        if((BSP_OK == retVal)  && (paVoltNum < PA_PWR_MAX_NUM))
        {
            for(pwrIndex = 0; pwrIndex < paVoltNum; pwrIndex++)
            {
                BspGetFirstBspChanByPwrIdx(pwrIndex, &bspchan);
                paVolt = BspGetPaVoltRealTime(bspchan);
                s_paVolt[pwrIndex] = paVolt;
                dbgInfoEx("%s>>pwrIndex = %d, bspchan = %d, volt = %d\n",__FUNCTION__, pwrIndex, bspchan, paVolt);
            }
        }
    }

    return BSP_OK;
}

/* 供高层调用，从全局标量获取pa电压 */
INT32 BspGetPaVolt(UINT32 index)
{
    INT32  lPaVolt = 0;
    UINT32 ulMaxChnlSum = 0;

    ulMaxChnlSum = BspGetTxChanNum();
    if (index >= ulMaxChnlSum)
    {
        dbgErr("%s>>Para Over Error! Index(0~%d)= %d\n",
               __FUNCTION__, ulMaxChnlSum - 1, index);
        return BSP_ERROR;
    }
#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    lPaVolt = BspGetPaVoltRealTime(index);
    return lPaVolt;
#else
    INT32  retVal = BSP_OK;
    UINT32 ulPwrIndex = 0;
    T_PaPwrVoltCtrlPara *pVoltPara = NULL;
    T_PaVoltUpdatePara *pVoltUpdatePara = NULL;
    pVoltPara = BspGetPaPwrVoltPara();
    if (pVoltPara->pGetVolt != NULL)
    {
        pVoltUpdatePara = BspGetPaVoltUpdatePara();
        if(pVoltUpdatePara->pGetPaVolt != NULL)
        {
            lPaVolt = pVoltUpdatePara->pGetPaVolt(index);
        }
        else
        {
            lPaVolt = BspGetPaVoltRealTime(index);
        }
    }
    else
    {
        retVal = BspGetPwrIdxByBspChan(index, &ulPwrIndex);
        if((retVal == BSP_OK) && (ulPwrIndex < PA_PWR_MAX_NUM))  /* bsp通道和pa电源映射正常，从bsp通道对应的电源砖全局变量获取 */
        {
            lPaVolt = s_paVolt[ulPwrIndex];
        }
        else
        {
            lPaVolt = BspGetPaVoltRealTime(index);
        }
        dbgInfoEx("%s>>retVal:%d pwrIndex:%d, index:%d, volt:%d\n",__FUNCTION__, retVal, ulPwrIndex, index, lPaVolt);
    }
    return lPaVolt;
#endif
}

UINT32 BspGetPwrMfrInfo(UINT32 ulIndex, CHAR *pcVal, UINT32 ulByteNum)
{
    UINT32 retVal = BSP_OK;
    //retVal=BspIpd600MfrModelGet(ulIndex, pcVal, ulByteNum);
    return retVal;
}

UINT32 BspGetPwrBarCodeInfo(UINT32 ulIndex, CHAR *pcVal, UINT32 ulByteNum)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet = 0;
    UINT32 key = 0;

    INPUT_POINTER_CHECK(pcVal);

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",key);  /*只是查找到设备 挂接到接口*/
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    dbgInfoEx("devid=%d\n",devid);

    return BspGetBarCode(devid,ulIndex,pcVal,ulByteNum);
}

UINT32 BspGetPwrIoutStatus(UINT32 index, LONG *ulStatus)
{
    return BSP_OK;



}

/*pa Input pwr cons*/
UINT32 BspGetRruConsumedPow (UINT32 index,UINT32 *pPower)
{
    #if 0
    INPUT_POINTER_CHECK(pPower);
    return BspPpc3xUartGetInputPower(0,0,pPower);  
    #endif
    T_PaPwrVoltCtrlPara *pVoltPara = NULL;
    INPUT_POINTER_CHECK(pPower);
    pVoltPara = BspGetPaPwrVoltPara();
    if(pVoltPara->pGetInputPwrConsu != NULL)
    {
        return pVoltPara->pGetInputPwrConsu(index,pPower);
    }
    else
    {
        return BspGetRruConsumedPower(index,(INT32 *)pPower);
    }
    
}

UINT32 BspGetPwrPaBestVolt(UINT32 Index, INT32* pPaBestVolt)
{
    INPUT_POINTER_CHECK(pPaBestVolt);
    return BspGetPaBestVolt(Index,pPaBestVolt);
}

/*************调试函数*****************/

UINT32 getMonitorPwrCurrOut(UINT32 ulIndex)
{
    INT32  plGetCrnt = 0;

    if (BSP_ERROR == BspGetMonitorPwrCurrOut(ulIndex,&plGetCrnt))
    {
        dbgErr("[%s]Get Current Out Failed !!!!\n",__func__);
        return BSP_ERROR;
    }
    dbgInfo("[%s]Get Current Out Is %d(mA)\n",__func__,plGetCrnt);
    return BSP_OK;
}

UINT32 getVoltTest(UINT32 index)
{
    INT32 ulVolt = 0;
    if (BSP_ERROR == BspGetPwrVolt(index, &ulVolt))
    {
        dbgErr("[%s]>>>>>>>>>>>>>>>>\n",__func__);
        return BSP_ERROR;
    }
    dbgInfo("[%s]>>>>>>>>>>>>>>>>%d(mV)\n",__func__,ulVolt);
    return BSP_OK;
}

static UINT32 getCurrTest(UINT32 index)
{
    INT32 ulCurr = 0;
    if (BSP_ERROR ==  BspGetPwrCurr(index, &ulCurr))
    {
        dbgErr("[%s]>>>>>>>>>>>>>>>>\n",__func__);
        return BSP_ERROR;
    }
    dbgInfo("[%s]>>>>>>>>>>>>>>>>%d(mA)\n",__func__,ulCurr);
    return BSP_OK;
}

//读取电压调试函数
UINT32 getMonitorVolt(UINT32 DevType,UINT32 Index)
{
    INT32 Volt = 0;
    if (BSP_ERROR != BspGetMonitorPwrDeviceVolt(DevType,Index,&Volt))
    {
        dbgInfo("[%s]DevType is %d,Index is %d Voltage is %d (mV)\n",__func__,DevType,Index,Volt);
        return BSP_OK;
    }
    dbgErr("[%s]DevType is %d,Index is %d Failed!\n",__func__,DevType,Index);
    return BSP_ERROR;
}


//读取电流调试函数
UINT32 getMonitorCurr(UINT32 DevType,UINT32 Index)
{
    INT32 plCrntOut = 0;
    if (BSP_ERROR != BspGetMonitorPwrDeviceCurr(DevType,Index,&plCrntOut))
    {
        dbgInfo("[%s]DevType is %d,Index is %d Current is %d (mA)\n",__func__,DevType,Index,plCrntOut);
        return BSP_OK;
    }
    dbgErr("[%s]DevType is %d,Index is %d Failed!\n",__func__,DevType,Index);
    return BSP_ERROR;
}
//获取电源芯片温度
UINT32 getTempTest(UINT32 DevType,UINT32 Index)
{
    INT32 pTemp = 0;
    if (BSP_ERROR == BspGetMonitorPwrDeviceTemp(DevType,Index,&pTemp))
    {
        dbgErr("[%s]Get Temperatur Failed !!!\n",__func__);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]Get Temp Is %d(centigrade)\n",__func__,pTemp);
    dbgInfo("[%s]Get Temp Is %5.1f(centigrade)\n",__func__,(double)pTemp/10.0);
    return BSP_OK; 
}

/**************************************************************************
* 函数名称: BspPwrCutCheck
* 功能描述: 电源严重过温告警并处理
* 输入参数: 无
* 输出参数: 无
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2019-01-7 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspPwrCutCheck(VOID)
{
    //待确定方案补充，暂时挂空函数
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetPwrOverTempAlrm
* 功能描述: TempRpdcX 过温检测告警
* 输入参数: index 电源温度检测点号,从0开始定义
* 输出参数: OverTemp TRUE :过温，FALSE：未过温
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10101715@2019-03-13 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetPwrOverTempAlrm(UINT32 ulIndex, BYTE *OverTemp)
{
    UINT32 ulRetVal = BSP_OK;	
	//待确定方案补充，暂时挂空函数
	return ulRetVal;
}

/**************************************************************************
* 函数名称: BspGetPwrTempNum
* 功能描述: 获取电源温度传感器检测 点个数
* 输入参数: 无
* 输出参数: TempNum  传感器个数
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10101715@2019-03-13 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetPwrTempNum(UINT32 *TempNum)
{
    //待确定方案补充，暂时挂空函数
	return BSP_OK;
}

/**************************************************************************
* 函数名称: BspPwrUpdateAckFlag(*)
* 功能描述: 电源升级标记设置及删除
* 输入参数: ulSwitch--1表示设置文件标记，0表示删除标记
* 输出参数: 无
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年03月27日                 刘谈10223493    创建
**************************************************************************/
UINT32 BspPwrUpdateAckFlag(UINT32 ulSwitch)
{
    UINT32 retVal = BSP_OK;

	if(1 == ulSwitch)
    {
        BspSystem("touch /ata/PwrUpdateFlag");
    }
    else
    {
        if(!access("/ata/PwrUpdateFlag",F_OK))
        {
            BspSystem("rm /ata/PwrUpdateFlag");
        }
        else
        {
            dbgInfoEx("file PwrUpdateFlag not exist.\n");
        }
    }

    return retVal;
}
/**************************************************************************
* 函数名称: BspPwrUpdateI2CBypass(*)
* 功能描述: 电源升级旁路IIC总线接口
* 输入参数: 无
* 输出参数: 无
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年03月27日                 刘谈10223493    创建
**************************************************************************/
UINT32 BspPwrUpdateI2CBypass(UINT32 ulI2cSwitch)
{

    if(!access("/ata/PwrUpdateFlag",F_OK))
    {
        dbgInfo("%s file PwrUpdateFlag ok.\n",__FUNCTION__);
        BspRegWr(0,REG_FPGA_I2C_BUS_ENABLE(PWR,0),0,ulI2cSwitch);
    }
    else
    {
        dbgInfoEx("%s file PwrUpdateFlag not exist.\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspIsExistPwrFlag(*)
* 功能描述: 电源升级是否成功标记检查
* 输入参数: 无
* 输出参数: 无
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年03月27日                 刘谈10223493    创建
**************************************************************************/
UINT32 BspIsExistPwrFlag(VOID)
{
    if(!access("/ata/PwrUpdateFlag",F_OK))
    {
        dbgInfo("%s file PwrUpdateFlag ok.\n",__FUNCTION__);
    }
    else
    {
        dbgInfoEx("%s file PwrUpdateFlag not exist.\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}
/**************************************************************************
* 函数名称: BspGetPwrEepromDevId()
* 功能描述: 获取电源组件Eeprom 设备ID号
* 输入参数:
* 输出参数: 无
* 返 回 值:
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年01月22日                 刘谈    创建
**************************************************************************/
UINT32 BspGetPwrEepromDevId(VOID)
{
    char   bufName[PWR_EEPROM_NAME_LEN] ={0};
    UINT32 devid = 0;
    int snpRet;
    UINT32 mcuUpgradeFlag = 0;

    mcuUpgradeFlag = BspGetSmartPwrMcuCfg();
    if((PwrSecondAcMoudle == 1) || (mcuUpgradeFlag == 1))
    {
        snpRet = snprintf_s(bufName, sizeof(bufName), "EepromRpdc%d", 1);
    }
    else
    {
        snpRet = snprintf_s(bufName, sizeof(bufName), "EepromRpdc");
    }

    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    return devid;
}

/**************************************************************************
* 函数名称: BspGetPwrMcuDevId()
* 功能描述: 获取电源组件MCU设备ID号
* 输入参数:
* 输出参数: 无
* 返 回 值:
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年01月22日                 刘谈    创建
**************************************************************************/
UINT32 BspGetPwrMcuDevId(VOID)
{
    char   bufName[PWR_EEPROM_NAME_LEN] ={0};
    UINT32 devid = 0;
    int snpRet;
    UINT32 index = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName, sizeof(bufName), "RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    return devid;
}

/**************************************************************************
* 函数名称: BspHexToAsc()
* 功能描述: 字符转int
* 输入参数:
* 输出参数: 无
* 返 回 值:
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年01月22日                 刘谈    创建
**************************************************************************/
UCHAR BspHexToAsc(UCHAR ucDate)
{
    if(isdigit(ucDate))
    {
        return ucDate - 48;
    }
    // 如果是字母，但不是A~F,a~f则返回
    if( ucDate < 'A' || (ucDate > 'F' && ucDate < 'a') || ucDate > 'z' )
    {
        return UCHAR_MAX;
    }
    // 如果是大/小写字母，则用数字的ASCII码减去55/87
    if(isalpha(ucDate))
    {
        return isupper(ucDate) ? ucDate - 55 : ucDate - 87;
    }

    return UCHAR_MAX;
}

/**************************************************************************
* 函数名称: BspASCIIToULONG()
* 功能描述: ASCII码转ULONG
* 输入参数:
* 输出参数: 无
* 返 回 值:
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年01月22日                 刘谈    创建
**************************************************************************/
UINT32 BspASCIIToULONG(CHAR* pHex)
{
    UINT32 ulRet = 0;

    dbgInfoEx("%d %d %d %d %d %d %d %d \n",
        pHex[0],pHex[1],pHex[2],pHex[3],pHex[4],pHex[5],pHex[6],pHex[7]);

    ulRet = ((BspHexToAsc(pHex[0])<<28) + (BspHexToAsc(pHex[1])<<24) +
        (BspHexToAsc(pHex[2])<<20) + (BspHexToAsc(pHex[3])<<16) +
        (BspHexToAsc(pHex[4])<<12) + (BspHexToAsc(pHex[5])<<8) +
        (BspHexToAsc(pHex[6])<<4) + (BspHexToAsc(pHex[7])));

    dbgInfoEx("%d %d %d %d %d %d %d %d %d \n",
        BspHexToAsc(pHex[0])<<28,BspHexToAsc(pHex[1])<<24,
        BspHexToAsc(pHex[2])<<20,BspHexToAsc(pHex[3])<<16,
        BspHexToAsc(pHex[4])<<12,BspHexToAsc(pHex[5])<<8,
        BspHexToAsc(pHex[6])<<4,BspHexToAsc(pHex[7]),ulRet);
    return ulRet;
}

/**************************************************************************
* 函数名称: BspASCIIToUSHORT()
* 功能描述: ASCII码转USHORT
* 输入参数:
* 输出参数: 无
* 返 回 值:
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年01月22日                 刘谈    创建
**************************************************************************/
USHORT BspASCIIToUSHORT(CHAR* pHex)
{
    USHORT usRet = 0;

    dbgInfoEx("%d %d %d %d\n",
        pHex[0],pHex[1],pHex[2],pHex[3]);
    usRet = ((BspHexToAsc(pHex[0])<<12) + (BspHexToAsc(pHex[1])<<8) +
        (BspHexToAsc(pHex[2])<<4) + (BspHexToAsc(pHex[3])));
    return usRet;
}

/**************************************************************************
* 函数名称: BspPwrUpdateProcInit
* 功能描述: 电源升级功能初始化
* 输入参数:
* 输出参数: 无
* 返 回 值   : RRUID
* 其它说明:
* 修改日期    版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019-01-02      V1.0      刘谈    创建
**************************************************************************/
UINT32 BspPwrUpdateProcInit(VOID)
{
    UINT32 ulRet = 0;

    semPowUpdate = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (semPowUpdate == NULL)
    {
        dbgErr("PwrUpdate semPowUpdate create fail.\n");
        return BSP_ERROR;
    }
    dbgInfo("PwrUpdate semPowUpdate create succeed.\n");
    ulRet = BspPwrUpdateI2CBypass(1);

    return ulRet;
}


UINT32 mygetline(char* pline, UINT32 ulLen, char *fp)
{
    UINT32 ulCnt=3;
    UINT32 ulLineLen = 0;
    UINT32 ulBackSpaceNum = 0;

    while(ulCnt--)
    {
        if(fp[0] != ':')
        {
            dbgInfoEx("fp[0] = %d \n",fp[0]);
            fp++;
            ulBackSpaceNum++;
        }
        else
        {
            break;
        }
    }
    if(fp[0] != ':')
    {
        dbgErr("%s getline error!",__FUNCTION__);
        return BSP_ERROR;
    }

    ulLineLen = (BspHexToAsc(fp[1])*16+BspHexToAsc(fp[2]))*2+11;
    ulLineLen = min(ulLineLen, ulLen);
    memcpy(pline,fp,ulLineLen);
    pline[ulLineLen] = '\n';
    pline[ulLineLen+1] = '\0';
    dbgInfoEx("%d %d %d\n",ulLineLen,BspHexToAsc(fp[1]),BspHexToAsc(fp[2]));

    return ulLineLen+ulBackSpaceNum;
}


/*****************************************************************************
 *  函数名称   : BspGetPwrVerInfo(*)
 *  功能描述   : 解析组件版本信息
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),   刘谈 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32  BspGetPwrVerInfo(UINT32 ulSubIndex,UCHAR* ucInfo, UINT32 ulLen, UINT32 ulLineNo)
{
    UCHAR ucSubUnitNo = 0;
    /* UINT32 ulLp = 0; */
    UINT32 ulPwrDevId = 0;
    UCHAR ucPwrVer[PWR_SUB_VER_LEN] = {0};

    ulPwrDevId = BspGetPwrMcuDevId();
    switch(ulLineNo)
    {
        case 0:
            memcpy((UCHAR*)&atPwrVerInfo[ulSubIndex].ucSubUnitName[0],ucInfo,sizeof(atPwrVerInfo[ulSubIndex].ucSubUnitName));
            atPwrVerInfo[ulSubIndex].ucSubUnitName[PWR_SUB_NAME_LEN_MAX-1] = '\0';
            break;
        case 1:
            memcpy((UCHAR*)&atPwrVerInfo[ulSubIndex].ucSubUnitVer[0],ucInfo,sizeof(atPwrVerInfo[ulSubIndex].ucSubUnitVer));
            atPwrVerInfo[ulSubIndex].ucSubUnitVer[4] = '\0';
            atPwrVerInfo[ulSubIndex].ucSubUnitNo = ucInfo[4];

            memcpy((UCHAR*)&atPwrVerInfo[ulSubIndex].ucManuFactoryNo[0],&ucInfo[5],sizeof(atPwrVerInfo[ulSubIndex].ucManuFactoryNo));
            atPwrVerInfo[ulSubIndex].ucManuFactoryNo[8] = '\0';
            break;
        case 2:
            memcpy((UCHAR*)&atPwrVerInfo[ulSubIndex].ucProgramVer[0],&ucInfo[0],sizeof(atPwrVerInfo[ulSubIndex].ucProgramVer));
            atPwrVerInfo[ulSubIndex].ucProgramVer[4] = '\0';
            memcpy((UCHAR*)&atPwrVerInfo[ulSubIndex].ucMinProgramVer[0],&ucInfo[4],sizeof(atPwrVerInfo[ulSubIndex].ucMinProgramVer));
            atPwrVerInfo[ulSubIndex].ucMinProgramVer[4] = '\0';
            memcpy((UCHAR*)&atPwrVerInfo[ulSubIndex].ucMaxProgramVer[0],&ucInfo[8],sizeof(atPwrVerInfo[ulSubIndex].ucMaxProgramVer));
            atPwrVerInfo[ulSubIndex].ucMaxProgramVer[4] = '\0';
            atPwrVerInfo[ulSubIndex].ulLineSize = ucInfo[12];
            ucSubUnitNo = atPwrVerInfo[ulSubIndex].ucSubUnitNo;
            BspGetPwrVer(ulPwrDevId, ucSubUnitNo, &ucPwrVer[0], PWR_SOFT_VER_LEN);

            memcpy((UCHAR*)&atPwrVerInfo[ulSubIndex].ucOldProgramVer[0],ucPwrVer,PWR_SUB_VER_LEN);
            atPwrVerInfo[ulSubIndex].ucOldProgramVer[4] = '\0';
            break;
        case 3:
            atPwrVerInfo[ulSubIndex].ulMinLineAddr = (ucInfo[0]<<24)+(ucInfo[1]<<16)+(ucInfo[2]<<8)+ucInfo[3];
            atPwrVerInfo[ulSubIndex].ulMaxLineAddr = (ucInfo[4]<<24)+(ucInfo[5]<<16)+(ucInfo[6]<<8)+ucInfo[7];
            atPwrVerInfo[ulSubIndex].ulMauLenSize = ucInfo[8];
            atPwrVerInfo[ulSubIndex].ulProgramCheckSum = (ucInfo[9]<<8)+ucInfo[10];
            atPwrVerInfo[ulSubIndex].ulFileCheckSum = (ucInfo[11]<<8)+ucInfo[12];
            break;
        default:
            return BSP_ERROR;
    }

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetPwrEepromAddr(*)
 *  功能描述   : 返回EEPROM写版本地址
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),  刘谈 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32  BspGetPwrEepromAddr(UINT32 ulLine, UCHAR ucRec)
{
    /* UINT32 ulAddr = 0; */
    if(0xf0 == ucRec)
    {
        return 0x200 + 0x20 * ulLine;
    }
    else
    {
        return 0x300;
    }
}

UINT32  BspSetPwrUpdateFlag(UINT32 ulSubIndex, UINT32 ulLineNum)
{
    UINT32 ulPwrDevId = 0;
    ulPwrDevId = BspGetPwrMcuDevId();
    if(4 == ulLineNum) /*读完组件版本头后，判断组件版本是否需要写入*/
    {
        if(SUBUNIT_VER_NEED_UPGRADE == BspCheckSubUnitVerInfo(ulPwrDevId, ulSubIndex))
        {
            ulUpGradeFlag = 1;
            dbgInfo("%s[%d] %d %d ulUpGradeFlag=%d\n", __FUNCTION__, __LINE__, ulSubIndex, ulLineNum, ulUpGradeFlag);
        }
        else
        {
            ulUpGradeFlag = 0;
            dbgInfo("%s[%d] %d %d ulUpGradeFlag=%d\n", __FUNCTION__, __LINE__, ulSubIndex, ulLineNum, ulUpGradeFlag);
        }
    }

    return BSP_OK;
}

UINT32 BspSetPwrVerUpdate(UINT32 ulSubIndex)
{
    UINT32 ulPwrDevId = 0;
    ulPwrDevId = BspGetPwrMcuDevId();

    dbgInfo("ulSubIndex:%d ucSubUnitNo:%d ucNowVer:%s ucProgramVer:%s \n",ulSubIndex,
        atPwrVerInfo[ulSubIndex].ucSubUnitNo,atPwrVerInfo[ulSubIndex].ucOldProgramVer,&atPwrVerInfo[ulSubIndex].ucProgramVer[0]);

    if(SUBUNIT_VER_NEED_UPGRADE == BspCheckSubUnitVerInfo(ulPwrDevId, ulSubIndex))
    {
        ulUpGradeFlag = 1;
        dbgInfoEx("%s[%d] %d ulUpGradeFlag=%d\n", __FUNCTION__, __LINE__, ulSubIndex, ulUpGradeFlag);
    }
    else
    {
        ulUpGradeFlag = 0;
        dbgInfoEx("%s[%d] %d ulUpGradeFlag=%d\n", __FUNCTION__, __LINE__, ulSubIndex, ulUpGradeFlag);
    }
	return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspWriteLineInfoToEeprom(*)
 *  功能描述   : 返回EEPROM写版本地址
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    刘谈 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspWriteLineInfoToEeprom(UINT32 ulAddr, UCHAR* pData, UINT32 ulLen)
{
    UINT32 ulLp = 3;
    UINT32 ulDevId = 0;
    UINT32 ulRetVal = BSP_OK;
    UCHAR ucData[MAX_VER_LINE_LEN] = {0};

    if(ulLen >= MAX_VER_LINE_LEN)
    {
        dbgErr("%s return Error! \n",__FUNCTION__);
        return BSP_ERROR;
    }

    ulDevId = BspGetPwrEepromDevId();
    memset((UCHAR*)&ucData[0],'\0',MAX_VER_LINE_LEN);
    while(ulLp--)
    {
        ulRetVal = BspSetEepromInfoSplit(ulDevId, ulAddr,pData, ulLen);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s Write Error!\n",__FUNCTION__);
        }
        BspSysMsDelay(10);
        ulRetVal = BspGetEepromInfoSplit(ulDevId, ulAddr,&ucData[0], ulLen);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s Read Error!\n",__FUNCTION__);
        }
        ucData[ulLen] = '\0';

        if(0 != memcmp(pData,&ucData[0],ulLen))
        {
            continue;
        }
        return BSP_OK;
    }
    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称: BspGetPwrUpdateStatus()
 * 功能描述: 获取电源版本升级状态
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月12日                  刘谈    创建
 **************************************************************************/
UINT32 BspGetPwrUpdateStatus(UINT32 ulIndex)
{
    UINT32 ulRetVal = BSP_OK;
    UCHAR ucPwrUpdateReadBack[2] = {0,0};

    ulRetVal = BspGetPwrVerUpdateStatus(ulIndex,&ucPwrUpdateReadBack[0],2);

    dbgInfo("0x%x 0x%x \n",ucPwrUpdateReadBack[0],ucPwrUpdateReadBack[1]);
    if(BSP_OK != ulRetVal)
    {
        return BSP_ERROR;
    }
    if((0==ucPwrUpdateReadBack[0])&&(0==ucPwrUpdateReadBack[1]))
    {
        return UPDATE_DONE;
    }
    if((0xAB==ucPwrUpdateReadBack[0])&&(0xCD==ucPwrUpdateReadBack[1]))
    {
        return UPDATE_MODE;
    }
    return BSP_ERROR;
}

UINT32 BspSubVerCrcCheck(UCHAR ucLineInfoSize, CHAR* pcbuf, CHAR* pcLineData)
{
    /* UCHAR ucDateSize = 0; */
    UCHAR ucCheckSum = 0;
    UCHAR ucCheckSumComp = 0;  /*校验和的补码*/
    UINT32 ulLp = 0;

    pcLineData[0] = ':';
    for(ulLp = 0; ulLp < ucLineInfoSize; ulLp++)
    {
        pcLineData[ulLp+1] = BspHexToAsc(pcbuf[1+ulLp*2])*16 + BspHexToAsc(pcbuf[2+ulLp*2]);
    }
    pcLineData[ucLineInfoSize] = '\0';

    for(ulLp = 1; ulLp < ucLineInfoSize-1; ulLp++)
    {
        ucCheckSum += pcLineData[ulLp];
    }
    dbgInfoEx("%s ucCheckSum: %d \n",__FUNCTION__,ucCheckSum);
    /*pwrupdataLog("%s ucCheckSum: %d \n",__FUNCTION__,ucCheckSum);*/
    

    ucCheckSumComp = 0x100-ucCheckSum;
    if(ucCheckSumComp != pcLineData[ucLineInfoSize-1])
    {
        dbgErr("checksum error! %d %d \n",ucCheckSum,pcLineData[ucLineInfoSize-1]);
        pwrupdataLog("checksum error! %d %d \n",ucCheckSum,pcLineData[ucLineInfoSize-1]);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetPwrActStatus(*)
 *  功能描述   : 电源版本激活状态查询
 *  输入参数   :
 *  返 回 值      : BSP_OK成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    刘谈 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPwrActStatus(VOID)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulSubIndex = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrMcuDevId();
    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {
        if((UPDATE_DONE == BspGetPwrUpdateStatus(ulPwrDevId))
           &&(SUBUNIT_VER_SAME == BspCheckSubUnitVerInfo(ulPwrDevId, ulSubIndex)))
        {
            ulRetVal |= BSP_OK;
        }
        else
        {
            ulRetVal |= BSP_ERROR;
        }
    }

    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspActPwrVer(*)
 *  功能描述   : 电源版本激活
 *  输入参数   :
 *  返 回 值      : BSP_OK成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    刘谈 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPwrActUpdateStatus(VOID)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrMcuDevId();
    ulRetVal = BspGetPwrUpdateStatus(ulPwrDevId);

    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspActPwrVer(*)
 *  功能描述   : 电源版本激活
 *  输入参数   :
 *  返 回 值      : BSP_OK成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    刘谈 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspActPwrVer(VOID)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrMcuDevId();
    ulRetVal = BspSetPwrUpdate(ulPwrDevId);

    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspPwrSubVerCrc16Check(*)
 *  功能描述   : CRC16校验
 *  输入参数   : ulLineNum：行数
 *              usCrcInit：校验初值
 *              pcLineData：待校验数据
 *              ucLineInfoSize：数据长度
 *  返 回 值   : usCrcSum： 校验结果
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    @2020-12-15 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT16 BspPwrSubVerCrc16Check(UINT32 ulLineNum, UINT16 usCrcInit, const CHAR* pcLineData, UCHAR ucLineInfoSize)
{
    UINT16  usCrcSum = usCrcInit;
    UINT32  ulLineDataSize = 0;

    pcLineData++;   /* ':' 不需要校验*/

    /* 第四行只对文件整体校验结果前的数据进行校验，后面三个字节的数据不需要校验 */
    /* 第四行数据长度需要减去冒号和三个不需要校验的字节，其他行数据长度需要减去冒号所占字节 */
    ulLineDataSize = (ulLineNum == 3) ? (ucLineInfoSize - 4):(ucLineInfoSize - 1);

    return CalculateCRC16(usCrcSum, (const unsigned char *)pcLineData, ulLineDataSize);

}

/*****************************************************************************
 *  函数名称   : BspLoadPwrVer(*)
 *  功能描述   : 解析组件版本信息
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : ulSubIndex 组件版本打包序号
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    刘谈 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32  BspLoadPwrVer(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen, UINT32* pulNextSubVerAddr)
{
    UINT32 ulLen = 0;
    INT32  lSurLen = 0;  /*剩余文件长度*/
    UINT32 ulLineNum = 0;
    char  cbuf[MAX_VER_LINE_LEN + 2] = {0};
    char  cLineData[MAX_VER_LINE_LEN] = {0};
    UCHAR ucDateSize = 0;
    UCHAR ucLineInfoSize = 0;
    UCHAR ucRecType = 0;
    UINT32 ulAddr = 0;
    UINT32 ulAddrOffSet = 0;
    UINT32 ulRetVal = 0;
    CHAR* fp = NULL;
    UINT32 ulRet = 0;
    UCHAR cCnt = 0;
    s_usHeadCrcSum = 0;
    s_usMcuCrcSum  = 0;

    RETURN_VAL_DO_IF_EXP(ulSubIndex >= NELEMENTS(atPwrVerInfo), BSP_ERROR, );
    fp = pPwrFile;
    *pulNextSubVerAddr = (uintptr_t)pPwrFile;
    INPUT_POINTER_CHECK_PWR(fp);

    dbgInfoEx("%s start! ulFileLen: %d\n",__FUNCTION__,ulFileLen);
    lSurLen = (INT32)ulFileLen;

    while(lSurLen > 6)
    {
        ulLen = mygetline(cbuf,MAX_VER_LINE_LEN,fp);
        PWR_SUBVER_LENTH_CHECK(ulLen);
        if(cbuf[0] != ':')
        {
            return BSP_ERROR;
        }

        fp = fp + ulLen;
        dbgInfoEx("--line info--%s\n",cbuf);
        ucDateSize = BspHexToAsc(cbuf[1])*16 + BspHexToAsc(cbuf[2]);
        ucRecType = BspHexToAsc(cbuf[7])*16 + BspHexToAsc(cbuf[8]);

        lSurLen = lSurLen - ucDateSize - 7;/*头部加校验为6*/
        ucLineInfoSize = ucDateSize + 6; /*加头部和校验和长度5*/
        dbgInfoEx("%s %d lSurLen:%d %d ulLineNum:%d\n",__FUNCTION__,__LINE__,lSurLen,ucLineInfoSize,ulLineNum);

        if(BSP_OK != BspSubVerCrcCheck(ucLineInfoSize,cbuf, cLineData))
        {
            ulUpGradeFlag = 0;
        }
        ulAddr = BspGetPwrEepromAddr(ulLineNum,ucRecType);
        //BspSetPwrUpdateFlag(ulSubIndex, ulLineNum);
        if((0xf0 == ucRecType)&&(ulLineNum < 4))
        {
            dbgInfoEx("--head write to cache--%s %d ulAddr: 0x%x \n",__FUNCTION__,__LINE__,ulAddr);
            //ulRet |= BspWriteLineInfoToEeprom(ulAddr,&cLineData[0],ucLineInfoSize);
            BspGetPwrVerInfo(ulSubIndex,(UCHAR*)(&cLineData[5]),ucDateSize,ulLineNum);
            g_PwrVerHead[ulLineNum].ulAddr = ulAddr;
            g_PwrVerHead[ulLineNum].ucLineInfoSize = ucLineInfoSize;           
            memcpy_s(&(g_PwrVerHead[ulLineNum].cLineData[0]),MAX_VER_LINE_LEN,&cLineData[0],ucLineInfoSize);
            s_usHeadCrcSum = BspPwrSubVerCrc16Check(ulLineNum,s_usHeadCrcSum,cLineData,ucLineInfoSize);/* 子组件头前三行+第四行文件整体校验结果前 */
            if(s_usHeadCrcSum == (UINT16)BSP_ERROR)
            {
                dbgInfo("%s %d:Crc16 Sum is 0xFFFF!\n",__FUNCTION__,__LINE__);
            }
            if(ulLineNum == 3)
            {
                BspSetPwrVerUpdate(ulSubIndex);
            }
            if(ulUpGradeFlag) /*如果不需要升级，不用写flash*/
            {
                for(cCnt = 0;cCnt < 4;cCnt++)
                {
                    ulRet |= BspWriteLineInfoToEeprom(g_PwrVerHead[cCnt].ulAddr,(UCHAR*)&(g_PwrVerHead[cCnt].cLineData[0]),g_PwrVerHead[cCnt].ucLineInfoSize);
                    dbgInfoEx("--head write to ee--%s %d ulAddr: 0x%x \n",__FUNCTION__,__LINE__,g_PwrVerHead[cCnt].ulAddr);
                }
            }
		}
        else
        {
            s_usMcuCrcSum = BspPwrSubVerCrc16Check(ulLineNum,s_usMcuCrcSum,cLineData,ucLineInfoSize);/* 子组件MCU程序部分校验 */
            if(s_usMcuCrcSum == (UINT16)BSP_ERROR)
            {
                dbgInfo("%s %d:Crc16 Sum is 0xFFFF!\n",__FUNCTION__,__LINE__);
            }
            /* 校验结果判断 */
            if(lSurLen < 6)
            {
                dbgInfoEx("Sub—Ver Mcu Program CRC Check Result！TheoryMcuCheckSum:%x,ActualMcuCrcSum:%x\n",
                            atPwrVerInfo[ulSubIndex].ulProgramCheckSum,s_usMcuCrcSum);
                if(atPwrVerInfo[ulSubIndex].ulProgramCheckSum != s_usMcuCrcSum)
                {
                    ulUpGradeFlag = 0;
                    dbgErr("Sub—Ver Mcu Program CRC Check Fail！TheoryMcuCheckSum:%x,ActualMcuCrcSum:%x\n",
                            atPwrVerInfo[ulSubIndex].ulProgramCheckSum,s_usMcuCrcSum);
                }
            }

            dbgInfoEx("--data pkg write to ee--%s %d ulAddr: 0x%x upFlag:%d\n",__FUNCTION__,__LINE__,ulAddr+ulAddrOffSet,ulUpGradeFlag);
            if(ulUpGradeFlag) /*如果不需要升级，不用写flash*/
            {
                ulRet |= BspWriteLineInfoToEeprom(ulAddr+ulAddrOffSet,(UCHAR*)(&cLineData[0]),ucLineInfoSize);
            }
            ulAddrOffSet += ucLineInfoSize;
        }
        dbgInfoEx("--pkg info-- ulFileLen:%d ucLineInfoSize:%d lSurLen:%d ulLineNum:%d\n",ulFileLen,ucLineInfoSize,lSurLen,ulLineNum);
        if(BSP_OK != ulRet)
        {
            dbgErr("%s %d write error !\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
        ulLineNum++;
    }
    *pulNextSubVerAddr = (uintptr_t)fp;
    /* CRC16校验的初值初始化 */
    s_usHeadCrcSum = 0;
    s_usMcuCrcSum  = 0;

    return ulRetVal;
}

UINT32 BspReadPwrEepromVer(UINT32 ulAddr,UINT32 ulLenth)
{
    FILE   *fp = NULL;
    INT32 fclsRet = 0;
    INT32 iWrite = 0;
    UINT32 ulDevId = 0;
    char   logFileName[32] = {0};
    UCHAR ucData[MAX_VER_LINE_LEN] = {0};
    UINT32 ulCnt = 0;
    UINT32 ulRetVal = BSP_OK;
    INT32 ret = 0;

    ret = snprintf_s(logFileName,sizeof(logFileName),"/pwr_ver.bin");
	SNPRINTF_S_CHECK(ret, sizeof(logFileName));

    fp = fopen(logFileName, "w+b");
    INPUT_POINTER_CHECK_PWR(fp);

    ulDevId = BspGetPwrEepromDevId();
    for(ulCnt = 0; ulCnt < (ulLenth/MAX_VER_LINE_LEN); ulCnt ++)
    {
        memset((UCHAR*)&ucData[0],'\0',MAX_VER_LINE_LEN);
        ulRetVal = BspGetEepromInfoSplit(ulDevId, ulAddr+(ulCnt*MAX_VER_LINE_LEN),&ucData[0], MAX_VER_LINE_LEN);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s Read Error 0!\n",__FUNCTION__);
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);            
            return BSP_ERROR;
        }
        
        iWrite = fwrite(&ucData[0], 1, MAX_VER_LINE_LEN, fp);        
        if (iWrite == 0)
        {
            dbgErr("%s Write Error 0!\n",__FUNCTION__);
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);
            return BSP_ERROR;
        }
    }
    if((ulLenth % MAX_VER_LINE_LEN)!=0)
    {
        memset((UCHAR*)&ucData[0],'\0',MAX_VER_LINE_LEN);
        ulRetVal = BspGetEepromInfoSplit(ulDevId, ulAddr+(ulCnt*MAX_VER_LINE_LEN),&ucData[0], (ulLenth % MAX_VER_LINE_LEN));
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s Read Error 1!\n",__FUNCTION__);
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);            
            return BSP_ERROR;
        }
        iWrite = fwrite(&ucData[0], 1, (ulLenth % MAX_VER_LINE_LEN), fp);        
        if (iWrite == 0)
        {
            dbgErr("%s Write Error 1!\n",__FUNCTION__);
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);
            return BSP_ERROR;
        }
    }
    dbgInfo("%s>>Read Succ !\n",__FUNCTION__);
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);

    return BSP_OK;
}

UINT32 BspActPowerIic(void)
{
	UINT32 retVal     = 0;
    UINT32 ulDly      = 30;

    ulDly = BspGetPwrUpdateDly();
    BspSysMsDelay_Sys(ulDly);

    if(UPDATE_MODE == BspGetPwrActUpdateStatus())
    {
        if(NULL != pPwrByPassFuncCallBack)
        {
            pPwrByPassFuncCallBack(1); //bypass i2c
        }
        dbgInfo("--power is update mode !!!\n");
        return BSP_ERROR;
    }
    else
    {
        dbgInfo("--power is not update mode !!!\n");
    }
    return retVal;
}
UINT32 BspPowerUpdate(void)
{
	UINT32 retVal     = 0;
	UINT32 iLoop      = 0;
    for(iLoop=0; iLoop<4; iLoop++)
    {
        retVal = BspActPwrVer();
        if(BSP_OK != retVal)
        {
            dbgInfo("iLoop = %d, BspActPwrVer error! \n",iLoop+1);
        }
        retVal = BspActPowerIic();
        if(BSP_OK != retVal)
        {
        	dbgInfo("power is in update mode, break !!!");
        	break;
        }
        /* BspSysMsDelay(300); */
    }

    if(4 == iLoop)
    {
        dbgInfo("%s: Power update mode set failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}
//电源升级操作
static UINT32 _BspUpdatePowerModule(UINT32 ulModule)
{
    /* UINT32 retVal     = 0; */
    UINT32 iLoop      = 0;
    UINT32 pwrDevIdx  = 0;
    UINT32 cmpLen     = 0;
    UINT32 ulSubIndex = ulModule;
    UINT8  pwrVerInfo[PWR_PARA_LENGTH] = {0};
    UINT32 ulSubUnitNo = 0;

    ulSubUnitNo = (UINT32)atPwrVerInfo[ulSubIndex].ucSubUnitNo;

    BspPowerUpdate();
    dbgInfo("--wait %d mins-----\n", POWER_UPDATE_WAIT_TIME);
    for(iLoop=1; iLoop <= POWER_UPDATE_WAIT_TIME*60; iLoop++)
    {
        dbgInfoEx("--cost %ds--\n", iLoop);
        sleep(1);
    }

    if(NULL != pPwrByPassFuncCallBack)
    {
        pPwrByPassFuncCallBack(0); //i2c恢复
    }

    pwrDevIdx = BspGetPwrMcuDevId();
    BspGetPwrVer(pwrDevIdx, ulSubUnitNo, &pwrVerInfo[0], NELEMENTS(pwrVerInfo));
    dbgInfo("%s: PwrIndex[%d] ==> NowVer:%s, UpdateFileVer:%s\n", __FUNCTION__, ulSubIndex, pwrVerInfo, atPwrVerInfo[ulSubIndex].ucProgramVer);
    cmpLen = min(PWR_SUB_VER_LEN, PWR_PARA_LENGTH);
    if(0 != memcmp(pwrVerInfo, atPwrVerInfo[ulSubIndex].ucProgramVer, cmpLen))
    {
        dbgErr("%s: ulSubIndex'%d update failed!\n", __FUNCTION__, ulSubIndex);
        return BSP_ERROR;
    }

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspPwrPkgLoad
* 功能描述: 电源版本加载函数
* 输入参数:
* 输出参数: 无
* 返 回 值   : RRUID
* 其它说明:
* 修改日期  版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019-01-02        V1.0           刘谈    创建
**************************************************************************/
UINT32  BspPwrPkgLoad(UCHAR* pucLogicDataBuf, INT32 ulBufLen)
{
    T_VerFileHeader_Pwr *ptVerHead = NULL;    /*版本头*/
    //T_VerIRHeader_Pwr   *ptVerIRHead = NULL;  /*TDD IR 头*/
    T_Pwr_VerPkg_Pwr   *pPwrPkgVer = NULL;   /*组件包 头*/
    UCHAR* ucHead           = NULL;
    USHORT usCrc            = 0;
    UINT32 ulLp             = 0;
    UINT32 ulSubIndex       = 0;
    UINT32 ulResult         = 0;
    UINT32 ulNextSubVerAddr = 0;
    uintptr_t pUlNextSubVerAddr = 0;
    UINT32 loop             = 0;

    INPUT_POINTER_CHECK(pucLogicDataBuf);
    if(0 != semTake(semPowUpdate, WAIT_FOREVER))
    {
        dbgErr("%s semTake error\n",__FUNCTION__);
        return PWR_GET_SEM_ERROR;
    }

    ptVerHead = (T_VerFileHeader_Pwr *)(pucLogicDataBuf);
    //coverity[cert_exp39_c_violation:SUPPRESS]
    usCrc = BspCountCrc16(0xFFFF, pucLogicDataBuf + sizeof(ptVerHead->ulCRC32), ntohl(ptVerHead->ulOriginalSize) + PWR_HEAD_LEN - sizeof(ptVerHead->ulCRC32));//电源版本包头待做校验，后边优化
    dbgInfoEx("%s: usCrc:%d\n",__FUNCTION__, usCrc);

    pPwrPkgVer = (T_Pwr_VerPkg_Pwr *)((UCHAR*)pucLogicDataBuf+sizeof(T_VerFileHeader_Pwr));

    tPwrVerPkg.ulPkgHeadLen = BspASCIIToULONG((CHAR*)pPwrPkgVer);
    tPwrVerPkg.usVerNum  = BspASCIIToUSHORT((CHAR*)pPwrPkgVer+8);

    dbgInfoEx("--pPwrPkgVer:%p ulPkgHeadLen:%d usVerNum:%d \n",pPwrPkgVer,tPwrVerPkg.ulPkgHeadLen,tPwrVerPkg.usVerNum);

    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {
        tPwrVerPkg.ulPkgLen[ulSubIndex] = BspASCIIToULONG((CHAR*)pPwrPkgVer+8*ulSubIndex+12);
        dbgInfoEx("--ulSubIndex:%d ulPkgLen:%x \n",ulSubIndex,tPwrVerPkg.ulPkgLen[ulSubIndex]);
    }
    tPwrVerPkg.usCrcSum = BspASCIIToUSHORT((CHAR*)pPwrPkgVer+8*(tPwrVerPkg.usVerNum)+12);
    /*加校验*/
    if(PwrHeadDataCheck(tPwrVerPkg.ulPkgHeadLen,(CHAR*)pPwrPkgVer) != BSP_OK)
    {
        semGive(semPowUpdate);
        return BSP_ERROR;
    }

    ucHead = (UCHAR*)pPwrPkgVer + tPwrVerPkg.ulPkgHeadLen*2;

    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {   
        for(ulLp = 0; ulLp < 3; ulLp++) /*给电源eeprom写升级文件，最多写3次*/
        {
            ulResult = BspLoadPwrVer(ulSubIndex,(CHAR *)ucHead,tPwrVerPkg.ulPkgLen[ulSubIndex],&ulNextSubVerAddr);
            if(BSP_OK == ulResult)
            {
                dbgInfo("ulSubIndex:%d write power eeprom succ or no need update ! \n",ulSubIndex);
                pUlNextSubVerAddr = (uintptr_t)ulNextSubVerAddr;
                ucHead = (UCHAR*)pUlNextSubVerAddr;
                dbgInfoEx("ucHead = %p, ulNextSubVerAddr = 0x%x \n",ucHead,ulNextSubVerAddr);
                break;
            }

            dbgInfo("ulSubIndex = %d, write power eeprom fail,try time = %d\n",ulSubIndex, ulLp+1);
        }

        if(3 == ulLp)
        {
            dbgErr("--ulSubIndex[%d]--write power eeprom version failed!--\n",ulSubIndex);
            semGive(semPowUpdate);
            return BSP_ERROR;
        }
        dbgInfoEx("ucHead = %p tPwrVerPkg.ulPkgLen[%d] = 0x%x \n",ucHead,ulSubIndex,tPwrVerPkg.ulPkgLen[ulSubIndex]);
        if(ulUpGradeFlag == 0) /*如果不需要升级，不用写flash,不用等待*/
        {
            dbgInfo("ulSubIndex:%d no need update ! continue \n",ulSubIndex);
            continue;
        }

        for(loop = 0; loop < POWER_UPDATE_ATTEMPTS_TIMES; loop++)
        {
            /* 给电源模块发起升级操作,尝试3次 */
            if(BSP_OK == _BspUpdatePowerModule(ulSubIndex))
            {
                dbgInfo("ulSubIndex:%d, updata success! times:%d!\n",ulSubIndex,loop+1);
                pwrupdataLog("%s:ulSubIndex:%d, updata success! times:%d!\n",__FUNCTION__,ulSubIndex,loop+1);
                break;
            }
            dbgInfo("ulSubIndex:%d, updata failed! times:%d\n",ulSubIndex,loop+1);
            pwrupdataLog("%s:ulSubIndex:%d, updata failed! times:%d!\n",__FUNCTION__,ulSubIndex,loop+1);
        }
        /* 3次都失败就退出升级 */
        if(POWER_UPDATE_ATTEMPTS_TIMES == loop)
        {
            semGive(semPowUpdate);
            return BSP_ERROR;
        }
    }

    semGive(semPowUpdate);
    return BSP_OK;
}

VOID BspSetPwrVersionPath(const CHAR *pwrPath, UINT32 lenth)
{
    strncpy_s((CHAR *)s_pwrVerPath, PWR_VER_PATH_MAX_LEN, pwrPath, lenth);
}

UINT32 BspPwrVerPathChange(UINT32 pwrVerPathFlag)
{
    if(pwrVerPathFlag == 0)
    {
        pwrVerPath = PWR_VERSION_PATH;
    }
    else if (pwrVerPathFlag == 2)
    {
        pwrVerPath = PWR_VERSION_PATH1_ROOT;
    }
    else if(PWR_VER_PATH_SET == pwrVerPathFlag)
    {
        pwrVerPath = s_pwrVerPath;
    }
    else if(PWR_VER_PATH_ROOT == pwrVerPathFlag)
    {
        pwrVerPath = PWR_VERSION_PATH_ROOT;
    }
    else
    {
        pwrVerPath = PWR_VERSION_PATH_ROOT;
    }
    return BSP_OK;
}

UINT32 BspGetPwrVerPath(VOID)
{
    dbgInfo("%s>>PwrVerPath = %s\n",__FUNCTION__,pwrVerPath);
    return BSP_OK;
}

/* Started by AICoder, pid:xb31bv367eqe4821493a0afd50da47212953d94a */
UINT32 BspPwrUpdateInit(VOID)
{
    UINT32 ulRet = 0;
    if (semPowUpdate != NULL)
    {
        dbgInfo("PwrUpdate semPowUpdate create succeed.\n");
        pwrupdataLog("PwrUpdate semPowUpdate create succeed.\n");
        return BSP_OK;
    }
    semPowUpdate = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (semPowUpdate == NULL)
    {
        dbgErr("PwrUpdate semPowUpdate create fail.\n");
        pwrupdataLog("PwrUpdate semPowUpdate create fail.\n");
        return BSP_ERROR;
    }
    dbgInfo("PwrUpdate semPowUpdate create succeed.\n");
    pwrupdataLog("PwrUpdate semPowUpdate create succeed.\n");

    return ulRet;
}
/* Ended by AICoder, pid:xb31bv367eqe4821493a0afd50da47212953d94a */

#ifdef BUILD_WITH_OM_FUNC
/*****************************************************************************
*  函数名称 : PwrUpdateTest(*)
*  功能描述 : 电源版本升级测试
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数 :
*  输出参数 : 无
*  返 回 值 : 错误码
*  其它说明 : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),                 刘志敬 @2011-07-14 9:40:27
*----------------------------------------------------------------------------
*/
UINT32 PwrVerUpdateTest(void)
{
    UCHAR   *pucBuffer = NULL;
    struct  stat tStatInfo;
    INT32    lVerLen = 0;
    UINT32   ulRetVal = BSP_OK;
    FILE    *fp = NULL;
    int fclsRet;

    dbgInfo("=====pwr updata test=====\n");
    INPUT_POINTER_CHECK(pwrVerPath);
    if((fopen_s(&fp,pwrVerPath, "rb") != 0) || (fp == NULL))
    {
        dbgErr("%s: open %s failed!\n",__FUNCTION__,pwrVerPath);
        return BSP_ERROR;
    }

    /* 获得电源版本文件大小 */
    if (stat(pwrVerPath, &tStatInfo) != 0)
    {
        dbgErr("pwr.swv not Exist!\n" );
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    if (!S_ISREG(tStatInfo.st_mode))
    {
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    lVerLen = tStatInfo.st_size;
    if (lVerLen <= 0)
    {
        dbgErr("File Length ERROR! error code: %s\n", zte_strerror_s(errno));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    dbgInfoEx("pwr file length :%d\n", lVerLen);

    if (NULL == (pucBuffer = (UCHAR *)malloc(lVerLen)))
    {
        dbgErr("Fail to get memory! error code: %s\n", zte_strerror_s(errno));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    /* 将电源文件装载到RAM中 */
    ulRetVal = fread(pucBuffer, 1, lVerLen, fp);
    if (ulRetVal != lVerLen)
    {
        dbgErr("Pwr file read Error");
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    /* Started by AICoder, pid:s7c38eef8bad8561466e089da071ac215f50f518 */
    /*升级前进行初始化，创建信号量*/
    if (BSP_OK !=BspPwrUpdateInit())
    {
        dbgErr("%s  error\n",__FUNCTION__);
        pwrupdataLog("%s  error\n",__FUNCTION__);
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }
    /* Ended by AICoder, pid:s7c38eef8bad8561466e089da071ac215f50f518 */

    ulRetVal = BspPwrPkgLoad(pucBuffer, lVerLen);
    s_usVerCmpSw = 0;
    if (BSP_OK != ulRetVal)
    {
        dbgErr("pwr update test fail \n");
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    dbgInfo("======pwr updata success======\n");
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);
    free(pucBuffer);
    return ulRetVal;
}
#endif

/* Started by AICoder, pid:8fdd738f60n8be014f280b664012eb2ed099a65f */
UINT32 PwrUpdateTest(VOID)
{
    UINT32 retVal = BSP_OK;
    PwrUpdateLogInit();          /*升级前打开log记录*/
    retVal = PwrVerUpdateTest();
    PwrUpdateLogClose();         /*升级后需要释放*/
    return retVal;
}
/* Ended by AICoder, pid:8fdd738f60n8be014f280b664012eb2ed099a65f */

/**************************************************************************
 * 函数名称: BspGetSubUnitName()
 * 功能描述: 获取电源组件名称
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月22日                  刘谈    创建
 **************************************************************************/
UINT32 BspGetSubUnitName(UCHAR *pSubUnitName)
{
    UINT32 ulDevId = 0;
    CHAR   uSubUnitName[PWR_SUB_NAME_LEN] = {0};
    UINT32 ulRelVal = 0;

    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, 0x0,uSubUnitName, PWR_SUB_NAME_LEN);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    uSubUnitName[PWR_SUB_NAME_LEN-1] = '\0';

    memcpy(pSubUnitName,uSubUnitName,PWR_SUB_NAME_LEN);
    dbgInfo("SubUnitName:%s \n",pSubUnitName);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetAuxSubUnitName()
 * 功能描述: 获取辅助电源组件名称
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月22日                  刘谈    创建
 **************************************************************************/
UINT32 BspGetAuxSubUnitName(UCHAR *pAuxSubUnitName)
{
    UINT32 ulDevId = 0;
    CHAR   ucAuxSubUnitName[PWR_SUB_VER_LEN] = {0};
    UINT32 ulRelVal = 0;

    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_AUX_MODULE_NAME,&ucAuxSubUnitName[0], PWR_SUB_VER_LEN);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    ucAuxSubUnitName[PWR_SUB_VER_LEN-1] = '\0';

    memcpy(pAuxSubUnitName,&ucAuxSubUnitName[0],PWR_SUB_VER_LEN);
    dbgInfo("%s \n",ucAuxSubUnitName);

    return BSP_OK;
}

/*获取完整的电源型号信息（电源组件名称+辅助电源组件名称）*/
UINT32 BspGetPwrTypeName(UCHAR *pPwrTypeName)
{
    if(BSP_OK == BspIsNewPwrType())
    {
        return BspGetPwrTypeNameNew(pPwrTypeName);
    }
    UINT32 ulDevId = 0;
    CHAR uSubUnitName[PWR_SUB_NAME_LEN_MAX] = {0};
    UINT32 ulRelVal = 0;

    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, 0x0,uSubUnitName, MAX_PWR_VER_NUM);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    dbgInfoEx("SubUnitName:%s \n",uSubUnitName);

    ulRelVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_AUX_MODULE_NAME,&uSubUnitName[10], PWR_SUB_VER_LEN);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    uSubUnitName[PWR_SUB_NAME_LEN_MAX-1]='\0';
    dbgInfoEx("PwrTypeName:%s \n",uSubUnitName);

    memcpy_s(pPwrTypeName,PWR_SUB_NAME_LEN_MAX,uSubUnitName,PWR_SUB_NAME_LEN_MAX);

    return BSP_OK;
}

/*获取完整的电源型号信息（电源组件名称）*/
UINT32 BspGetPwrTypeNameNew(UCHAR *pPwrTypeName)
{
    UINT32 ulDevId = 0;
    CHAR uSubUnitName[PWR_SUB_NAME_LEN_MAX] = {0};
    UINT32 ulRelVal = 0;
    PwrSubUnitNameLen=1;
	
    INPUT_POINTER_CHECK(pPwrTypeName);
    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, 0x0,uSubUnitName, PWR_SUB_NAME_LEN_MAX-1);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
#ifndef _BSP_WITH_WFS
    while((uSubUnitName[PwrSubUnitNameLen-1]!='\0') && (uSubUnitName[PwrSubUnitNameLen-1]!= 0x20))
    {
        PwrSubUnitNameLen++;
    }
#else
    while(uSubUnitName[PwrSubUnitNameLen-1]!='\0')
    {
        PwrSubUnitNameLen++;
    }
#endif
    PwrSubUnitNameLen--;

    uSubUnitName[PWR_SUB_NAME_LEN_MAX-1] = '\0';
    memcpy_s(pPwrTypeName,PWR_SUB_NAME_LEN_MAX-1,uSubUnitName,PWR_SUB_NAME_LEN_MAX-1);
    pPwrTypeName[PWR_SUB_NAME_LEN_MAX-1] = '\0';

    dbgInfo("PwrTypeName:%s, Len:%d \n",pPwrTypeName,PwrSubUnitNameLen);

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspGetSubUnitHareWareVersion()
 * 功能描述: 获取电源组件硬件版本号
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月22日                  刘谈    创建
 **************************************************************************/
UINT32 BspGetSubUnitHareWareVersion(UCHAR *pSubUnitVer)
{
    if(BSP_OK == BspIsNewPwrType())
    {
        return BspGetSubUnitHareWareVersionNew(pSubUnitVer);
    }
    UINT32 ulDevId = 0;
    CHAR ucSubUnitVersion[PWR_SUBUNIT_VER_LEN] = {0};
    UINT32 ulRelVal = 0;

    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_MODULE_VER,ucSubUnitVersion, PWR_SUBUNIT_VER_LEN);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    ucSubUnitVersion[PWR_SUBUNIT_VER_LEN-1] = '\0';

    memcpy(pSubUnitVer,ucSubUnitVersion,PWR_SUBUNIT_VER_LEN);
    dbgInfo("%s \n",ucSubUnitVersion);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetPwrManuFactorNo()
 * 功能描述: 获取电源厂家编号
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月22日                  刘谈    创建
 **************************************************************************/
UINT32 BspGetPwrManuFactorNo(UCHAR *pPwrManuFactorNo)
{
    if(BSP_OK == BspIsNewPwrType())
    {
        return BspGetPwrManuFactorNoNew(pPwrManuFactorNo);
    }
    UINT32 ulDevId = 0;
    /* UINT32 ulLp = 0; */
    /* UCHAR ucCheckSum = 0; */
    CHAR  ucPwrManuFactorNo[PWR_FACTORYNO_LEN] = {0};
    UINT32 ulRelVal = 0;

    ulDevId = BspGetPwrEepromDevId();

    ulRelVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_MANUFECTURER_NUM,&ucPwrManuFactorNo[0], PWR_FACTORYNO_LEN);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    ucPwrManuFactorNo[PWR_FACTORYNO_LEN-1] = '\0';

    memcpy(pPwrManuFactorNo,&ucPwrManuFactorNo[0],PWR_FACTORYNO_LEN);
    dbgInfo("%s \n",ucPwrManuFactorNo);

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspSetPwrSubVerCmpSw
 *  功能描述   : 设置电源版本子组件版本比对开关
 *  读全局变量 :
 *  写全局变量 :  s_usVerCmpSw:根据bit位屏蔽子组件版本比对，每个bit: 0:正常 1:屏蔽
 *  输入参数   :  usVerCmpSw
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),   2021-01-12 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
static UINT32 BspSetPwrSubVerCmpSw(UINT16 usVerCmpSw)
{
    s_usVerCmpSw = usVerCmpSw;

    return BSP_OK;
}

static UINT16 BspGetPwrSubVerCmpSw(VOID)
{
    return s_usVerCmpSw;
}

/**************************************************************************
 * 函数名称: BspCheckSubUnitVerInfo()
 * 功能描述: 判断组件版本是否需要升级
 * 输入参数: ulPwrDevId 电源设备编号
 *      : ulSubIndex 组件版本序号，组件在组件包中的顺序
 *      : ucSubUnitNo 组件编号
 * 输出参数: 无
 * 返 回 值  : BSP_OK:    需要升级
 *      : BSP_ERROR: 不需要升级
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月22日                   刘谈    创建
 **************************************************************************/
UINT32 BspCheckSubUnitVerInfo(UINT32 ulPwrDevId, UINT32 ulSubIndex)
{
    UCHAR ucPwrVer[PWR_SOFT_VER_LEN] = {0};
    UCHAR ucSubUnitName[PWR_SUB_NAME_LEN_MAX] = {0};
    UCHAR ucSubUnitHardWareVersion[PWR_SUBUNIT_VER_LEN] = {0};
    UCHAR ucPwrManuFactorNo[PWR_FACTORYNO_LEN] = {0};
    UCHAR ucSubUnitNo = 0;

    RETURN_VAL_DO_IF_EXP(ulSubIndex >= NELEMENTS(atPwrVerInfo), BSP_ERROR, );
    ucSubUnitNo = atPwrVerInfo[ulSubIndex].ucSubUnitNo;

    /* 增加手动屏蔽单个子组件屏蔽版本比对功能 */
    if(0 != (BIT_SET(ucSubUnitNo) & BspGetPwrSubVerCmpSw()))
    {
        dbgInfo("ucSubUnitNo:%d,Ver Comparison is blocked.\n",ucSubUnitNo);
        return SUBUNIT_VER_NEED_UPGRADE;
    }
    /* 子组件超出电源子组件范围判断 */
    if (BSP_OK != BspGetPwrVer(ulPwrDevId, (UINT32)ucSubUnitNo, ucPwrVer, PWR_SOFT_VER_LEN))
    {
        dbgErr("Ver Non-Existent,ulSubIndex:%d ucSubUnitNo:%d \n",ulSubIndex,ucSubUnitNo);
        return SUBUNIT_VER_OVER;
    }
    /* 定制电源组件名称错误判断 */
    BspGetPwrTypeName(ucSubUnitName);
    if(BSP_OK != memcmp(ucSubUnitName,&atPwrVerInfo[ulSubIndex].ucSubUnitName[0],PWR_SUB_NAME_LEN_MAX-1))
    {
        dbgErr("%s SubUnitName Diff! %s [%s] \n",__FUNCTION__,ucSubUnitName,atPwrVerInfo[ulSubIndex].ucSubUnitName);
        return SUBUNIT_NAME_NO_SAME;
    }
    /* 组件版本错误判断 */
    BspGetSubUnitHareWareVersion(ucSubUnitHardWareVersion);
    if(BSP_OK != memcmp(ucSubUnitHardWareVersion,&atPwrVerInfo[ulSubIndex].ucSubUnitVer[0],PWR_SUB_VER_LEN-1))
    {
        dbgErr("%s SubUnitVersion Diff! %s [%s] \n",__FUNCTION__,ucSubUnitHardWareVersion,atPwrVerInfo[ulSubIndex].ucSubUnitVer);
        return SUBUNIT_HARDWARE_VER_NO_SAME;
    }
    /* 生产厂家编号错误判断 */
    BspGetPwrManuFactorNo(ucPwrManuFactorNo);
    if(BSP_OK != memcmp(ucPwrManuFactorNo,&atPwrVerInfo[ulSubIndex].ucManuFactoryNo[0],PWR_FACTORYNO_LEN-1))
    {
        dbgErr("%s PwrManuFactorNo Diff! %s [%s] \n",__FUNCTION__,ucPwrManuFactorNo,atPwrVerInfo[ulSubIndex].ucManuFactoryNo);
        return SUBUNIT_MANUFACTORNO_NO_SAME;
    }
    /* 软件版本号是否相同判断 */
    if(BSP_OK == memcmp(ucPwrVer,&atPwrVerInfo[ulSubIndex].ucProgramVer[0],PWR_SUB_VER_LEN-1))
    {
        dbgErr("Ver is same,ulSubIndex:%d ucSubUnitNo:%d ucNowVer:%s ucProgramVer:%s \n",
                ulSubIndex,ucSubUnitNo,ucPwrVer,&atPwrVerInfo[ulSubIndex].ucProgramVer[0]);
        return SUBUNIT_VER_SAME;
    }
    /* 子组件版本范围是否超出电源子组件范围判断 */
    if( 0 > memcmp(ucPwrVer,&atPwrVerInfo[ulSubIndex].ucMinProgramVer[0],PWR_SUB_VER_LEN-1))
    {
        dbgErr("Out of MinVer Range,ulSubIndex:%d ucSubUnitNo:%d ucNowVer:%s ucMinProgramVer:%s \n",
                ulSubIndex,ucSubUnitNo,ucPwrVer,&atPwrVerInfo[ulSubIndex].ucMinProgramVer[0]);
        return SUBUNIT_VER_OUTRANGE;
    }

    if( 0 < memcmp(ucPwrVer,&atPwrVerInfo[ulSubIndex].ucMaxProgramVer[0],PWR_SUB_VER_LEN-1))
    {
        dbgErr("Out of MaxVer Range,ulSubIndex:%d ucSubUnitNo:%d ucNowVer:%s ucMaxProgramVer:%s \n",
                ulSubIndex,ucSubUnitNo,ucPwrVer,&atPwrVerInfo[ulSubIndex].ucMaxProgramVer[0]);
        return SUBUNIT_VER_OUTRANGE;
    }

    /* 子组件整体文件crc16校验判断 */
    if (atPwrVerInfo[ulSubIndex].ulFileCheckSum != (UINT32)s_usHeadCrcSum)
    {
        dbgErr("Sub—VER Program CRC Check Fail！ulFileCheckSum:%x,usHeadCrcSum:%x\n",
                atPwrVerInfo[ulSubIndex].ulFileCheckSum,s_usHeadCrcSum);
        return SUBUNIT_VER_HEAD_CRC_FAIL;
    }

    dbgInfo("Check OK\n");
    return SUBUNIT_VER_NEED_UPGRADE;
}
/******************************电源升级调试函数************************************/
#ifdef BUILD_WITH_OM_FUNC
/**************************************************************************
 * 函数名称: subunitinfo()
 * 功能描述: 打印组件版本信息
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月12日                  刘谈    创建
 **************************************************************************/
UINT32 subunitinfo(VOID)
{
    UINT32 ulSubIndex = 0;

    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {
        dbgInfo("ucSubUnitName:%s \n",atPwrVerInfo[ulSubIndex].ucSubUnitName);
        dbgInfo("ucSubUnitVer:%s \n",atPwrVerInfo[ulSubIndex].ucSubUnitVer);
        dbgInfo("ucSubUnitNo:%d \n",atPwrVerInfo[ulSubIndex].ucSubUnitNo);
        dbgInfo("ucManuFactoryNo:%s \n",atPwrVerInfo[ulSubIndex].ucManuFactoryNo);
        dbgInfo("ucProgramVer:%s \n",atPwrVerInfo[ulSubIndex].ucProgramVer);
        dbgInfo("ucMinProgramVer:%s \n",atPwrVerInfo[ulSubIndex].ucMinProgramVer);
        dbgInfo("ucMaxProgramVer:%s \n",atPwrVerInfo[ulSubIndex].ucMaxProgramVer);
        dbgInfo("ulMinLineAddr:0x%x \n",atPwrVerInfo[ulSubIndex].ulMinLineAddr);
        dbgInfo("ulMaxLineAddr:0x%x \n",atPwrVerInfo[ulSubIndex].ulMaxLineAddr);
        dbgInfo("ulMauLenSize:%d \n",atPwrVerInfo[ulSubIndex].ulMauLenSize);
        dbgInfo("ulProgramCheckSum:%d \n",atPwrVerInfo[ulSubIndex].ulProgramCheckSum);
        dbgInfo("ulFileCheckSum:%d \n",atPwrVerInfo[ulSubIndex].ulFileCheckSum);
    }
    return BSP_OK;
}

VOID printswitch(UINT32 ulSwitch)
{
    ulPwrPrintSwitch = ulSwitch;
}

/**************************************************************************
 * 函数名称: printpwrhardwareinfo()
 * 功能描述: eeprom中组件信息
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2019年01月12日                  刘谈    创建
 **************************************************************************/
UINT32 printpwrhardwareinfo(VOID)
{
    UCHAR aTmp[PWR_VER_PKG_LEN] = {0};

    BspGetSubUnitName(&aTmp[0]);
    BspGetAuxSubUnitName(&aTmp[0]);
    BspGetPwrManuFactorNo(&aTmp[0]);
    return BSP_OK;
}

UINT32 eepromtestread(UINT32 ulAddr,UINT32 ulByteNum)
{
    UINT32 ulDevId = 0;
    UINT32 ulRetVal = 0;
    CHAR  ucBuf[PWR_VER_PKG_LEN] = {0};

    ulDevId = BspGetPwrEepromDevId();
    ucBuf[ulByteNum] = '\0';
    ulRetVal = BspGetEepromInfo(ulDevId, ulAddr, ucBuf, ulByteNum);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s Read Error!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("Rd addr:0x%d Val:%s \n",ulAddr,ucBuf);

    return BSP_OK;
}

UINT32 pwrstauts(UINT32 ulIndex)
{
    BspGetPwrUpdateStatus(ulIndex);
    return BSP_OK;
}
UINT32 showpwrmonsetvolt(UINT32 DevType,UINT32 Index)
{
    INT32 volt = 0;
    UINT32 ulRet = BSP_OK;
    ulRet = BspGetMonitorPwrDeviceSetVolt(DevType,Index,&volt);
    dbgPrn("%s>>DevType %d,Index %d,Volt is %d !\n",__FUNCTION__,DevType,Index,volt);
    return ulRet;
}
#endif

UINT32 BspSetPwrVoltAlarm(UINT32 lLowAlmThre,UINT32 lLowRecThre,UINT32 lHighAlmThre,UINT32 lHighRecThre)
{
    g_aAcAlmThre_220V[0] = lLowAlmThre;
    g_aAcAlmThre_220V[1] = lLowRecThre;
    g_aAcAlmThre_220V[2] = lHighAlmThre;
    g_aAcAlmThre_220V[3] = lHighRecThre;
    return BSP_OK;
}

static UINT32 SetDcPwrVoltAlarmThr(T_PwrVoltAlmThr *pPwrVoltAlmThr)
{
    INPUT_POINTER_CHECK(pPwrVoltAlmThr);

    g_aDcAlmThre[0] = pPwrVoltAlmThr->lowVoltAlmThr;
    g_aDcAlmThre[1] = pPwrVoltAlmThr->lowVoltRecThr;
    g_aDcAlmThre[2] = pPwrVoltAlmThr->highVoltAlmThr;
    g_aDcAlmThre[3] = pPwrVoltAlmThr->highVoltRecThr;
    return BSP_OK;
}

UINT32 BspSetPwrVoltAlarmThr(T_PwrVoltAlmThr *pPwrVoltAlmThr)
{
    INPUT_POINTER_CHECK(pPwrVoltAlmThr);

    if (PWR_TYPE_DC == pPwrVoltAlmThr->pwrType)
    {
        SetDcPwrVoltAlarmThr(pPwrVoltAlmThr);
    }

    return BSP_OK;
}

static UINT32 BspGetDbgVolt(VOID)
{
    return voltDbg;
}

static VOID BspSetDbgVolt(UINT32 volt)
{
    voltDbg = volt;
}

VOID BspUnderVoltChk(UINT32 lVolt, UINT32 lLowAlmThre, UINT32 lLowRecThre, UINT32 *status)
{
    /*When the input voltage is less than 37V and greater than 25V, set the under-voltage alarm flag.*/
    if ((lVolt < lLowAlmThre) && (lVolt >= SHUT_DOWN_VOLT_THRE))
    {
        *status |= BSP_BIT_SET(0);
    }
    /*When the voltage is greater than or equal to 38V or lower than 25V, clear the under-voltage alarm flag.*/
    else if ((lVolt > lLowRecThre) || (lVolt < SHUT_DOWN_VOLT_THRE))
    {
        *status &= ~BSP_BIT_SET(0);
    }
    else
    {
        ;
    }
    dbgInfoEx("vin %d,lowalm %d,lowrec %d,return %#x\n", lVolt, lLowAlmThre, lLowRecThre, *status);
}

/* Started by AICoder, pid:f3d10l1735q4fe7142da0b1630595d37c699b7ee */
void BspSetDcTreansAlmThre(T_PwrInputAlmThre thre)
{
    g_aDcTreansAlmThre[0] = thre.lowAlmThre;
    g_aDcTreansAlmThre[1] = thre.lowRecThre;
    g_aDcTreansAlmThre[2] = thre.highAlmThre;
    g_aDcTreansAlmThre[3] = thre.highRecThre;
}

void BspSetAcAlmThre_100V(T_PwrInputAlmThre thre)
{
    g_aAcAlmThre_100V[0] = thre.lowAlmThre;
    g_aAcAlmThre_100V[1] = thre.lowRecThre;
    g_aAcAlmThre_100V[2] = thre.highAlmThre;
    g_aAcAlmThre_100V[3] = thre.highRecThre;
}

void BspSetAcAlmThre_110V(T_PwrInputAlmThre thre)
{
    g_aAcAlmThre_110V[0] = thre.lowAlmThre;
    g_aAcAlmThre_110V[1] = thre.lowRecThre;
    g_aAcAlmThre_110V[2] = thre.highAlmThre;
    g_aAcAlmThre_110V[3] = thre.highRecThre;
}

void BspSetAcAlmThre_220V(T_PwrInputAlmThre thre)
{
    g_aAcAlmThre_220V[0] = thre.lowAlmThre;
    g_aAcAlmThre_220V[1] = thre.lowRecThre;
    g_aAcAlmThre_220V[2] = thre.highAlmThre;
    g_aAcAlmThre_220V[3] = thre.highRecThre;
}

void BspSetDcAlmThre(T_PwrInputAlmThre thre)
{
    g_aDcAlmThre[0] = thre.lowAlmThre;
    g_aDcAlmThre[1] = thre.lowRecThre;
    g_aDcAlmThre[2] = thre.highAlmThre;
    g_aDcAlmThre[3] = thre.highRecThre;
}
/* Ended by AICoder, pid:f3d10l1735q4fe7142da0b1630595d37c699b7ee */

UINT32 BspGetPwrVoltAlarm(void)
{
    UINT32 voltType = 0;
    static UINT32 sulInputPwrAlmState = 0;
    UINT32   lVolt = 0;
    UINT32   lHighAlmThre = 0, lHighRecThre = 0;
    UINT32   lLowAlmThre = 0, lLowRecThre = 0;
    UINT32   pwrType = 0;

    if(PWR_TYPE_AC == BspGetPwrType(0))
    {
        (void)BspGetBoardVinType(0,&pwrType);
        if(PWR_TYPE_HIGH_DC == pwrType)
        {
            lLowAlmThre  = g_aDcTreansAlmThre[0];
            lLowRecThre  = g_aDcTreansAlmThre[1];
            lHighAlmThre = g_aDcTreansAlmThre[2];
            lHighRecThre = g_aDcTreansAlmThre[3];
        }
        else
        {
           voltType = BspGetPwrInputVolt(0);
           if(PWR_AC_100V == voltType)
           {
               lLowAlmThre  = g_aAcAlmThre_100V[0];
               lLowRecThre  = g_aAcAlmThre_100V[1];
               lHighAlmThre = g_aAcAlmThre_100V[2];
               lHighRecThre = g_aAcAlmThre_100V[3];

           }
           else if(PWR_AC_110V == voltType)
           {
               lLowAlmThre  = g_aAcAlmThre_110V[0];
               lLowRecThre  = g_aAcAlmThre_110V[1];
               lHighAlmThre = g_aAcAlmThre_110V[2];
               lHighRecThre = g_aAcAlmThre_110V[3];
           }
           else
           {
               lLowAlmThre  = g_aAcAlmThre_220V[0];
               lLowRecThre  = g_aAcAlmThre_220V[1];
               lHighAlmThre = g_aAcAlmThre_220V[2];
               lHighRecThre = g_aAcAlmThre_220V[3];
           }
        }
    }
    else if(PWR_TYPE_DC == BspGetPwrType(0))
    {
         lLowAlmThre  = g_aDcAlmThre[0];
         lLowRecThre  = g_aDcAlmThre[1];
         lHighAlmThre = g_aDcAlmThre[2];
         lHighRecThre = g_aDcAlmThre[3];
    }
    else
    {
        ;
    }

    if (BSP_OK != BspGetPwrVolt(0, (INT32 *)&lVolt))
    {
        dbgInfoEx("get vin failed,return %#x\n", sulInputPwrAlmState);
        return sulInputPwrAlmState;
    }

    if (0 != BspGetDbgVolt())
    {
        lVolt = BspGetDbgVolt();
    }

    /* 欠压告警 */
    BspUnderVoltChk(lVolt, lLowAlmThre, lLowRecThre, &sulInputPwrAlmState);

    /* 过压告警 */
    if(lVolt > lHighAlmThre)
    {
        sulInputPwrAlmState |= BSP_BIT_SET(1);;
    }
    else if(lVolt < lHighRecThre)
    {
        sulInputPwrAlmState &= ~BSP_BIT_SET(1);;
    }
    else
    {
        ;
    }

    dbgInfoEx("vin %d,highalm %d,highrec %d,return %#x\n", lVolt, lHighAlmThre,lHighRecThre,sulInputPwrAlmState);

    return sulInputPwrAlmState;
}

UINT32 BspGetModuleStatus(UINT32 ulModuleId, UINT32 *pulModuleStatus)
{
    #ifdef SUPPORT_UNIFIED_PWR_ALM_MACRO
    return BSP_OK;
    #else
    INPUT_POINTER_CHECK(pulModuleStatus);
    switch(ulModuleId)
    {
        case BSP_MODULE_THUNDER_BOLT:
            if(BSP_POWER_THUNDER_BOLT_ALARM & BspGetPowerStatus())
            {
                *pulModuleStatus = BSP_STATUS_ABNORMAL;
            }
            else
            {
                *pulModuleStatus = BSP_STATUS_NORMAL;
            }
            break;
        default:
            break;
    }
    return BSP_OK;
    #endif
}

UINT32 BspGetPwrWarnSta(UINT32 index, T_PwrWarnStatus *pwarnSta)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid  = 0;
    UINT32 page   = 0;
    INT32  snpRet = 0;
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    INPUT_POINTER_CHECK(pwarnSta);
    dbgInfoEx("[%s] devid  %d \n!",__FUNCTION__,devid);
    
    memset(pwarnSta, 0, sizeof(T_PwrWarnStatus));
    pwarnSta->pageNum = BspGetPwrPageNum(devid);
    BspGetPwrWarnStatus(devid, 0, PWR_ALM_TYPE_TEMP, &pwarnSta->statusTemp);
    for (page = 0; page <pwarnSta->pageNum;page++)
    {
        BspGetPwrWarnStatus(devid, page, PWR_ALM_TYPE_OVP , &pwarnSta->statusVout[page]);
        BspGetPwrWarnStatus(devid, page, PWR_ALM_TYPE_OIP , &pwarnSta->statusIout[page]);    
        BspGetPwrWarnStatus(devid, page, PWR_ALM_TYPE_MFRS, &pwarnSta->statusMfr[page]);       
    }
    BspGetPwrWarnStatus(devid, 0, PWR_ALM_TYPE_VIN, &pwarnSta->statusVin);

    BspPwrAlmClr(devid);
    return BSP_OK;
}

UINT32 BspGetPwrOIPWarnStatus(UINT32 index, UINT32 pageNo, UINT32 *pwarnSta)
{
    UINT32 ret = BSP_OK;
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid  = 0;
    INT32  snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    INPUT_POINTER_CHECK(pwarnSta);
    BspGetPwrWarnStatus(devid, pageNo, 3, pwarnSta);
    dbgInfoEx("[%s]get OIP Warn Status %d \n!",__FUNCTION__,*pwarnSta);
    if (*pwarnSta == 1) 
    {
        BspPwrAlmClr(devid);
    }
    return ret;
}

/*保存(固化)电源可调参数*/
UINT32 BspSavePwrPara(UINT32 index)
{
    UINT32 ulRetVal = BSP_OK;

    ulRetVal |= BspSavePwrAdjustPara(index);

    return ulRetVal;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 pwrwarnsta(UINT32 index)
{
    UINT32 retVal = 0;
    UINT32 loop   = 0;
    T_PwrWarnStatus warnStatus = {0,};
	
    dbgInfo("tickBegin = %d\n", tickGet());
    retVal = BspGetPwrWarnSta(index, &warnStatus);
    dbgInfo("tickEnd   = %d\n", tickGet());
    if (retVal == BSP_OK)
    {
        dbgInfo("pwr page   : %d\n", warnStatus.pageNum);	
	    dbgInfo("pwr Vin    : %d\n", warnStatus.statusVin);	
        dbgInfo("pwr Temp   : %d\n", warnStatus.statusTemp);
        for (loop = 0; loop<warnStatus.pageNum;loop++)
        {
            dbgInfo("pwr Vout(%d): %d\n", loop,warnStatus.statusVout[loop]);	
	        dbgInfo("pwr Iout(%d): %d\n", loop,warnStatus.statusIout[loop]);	
            dbgInfo("pwr Mfr (%d): %d\n", loop,warnStatus.statusMfr[loop]);		
        }
    }
    return BSP_OK;
}
#endif

/**************************************************************************
* 函数名称: BspGetPwrPowCali
* 功能描述: 电源功率校准参数获取
* 输入参数: 无
* 输出参数: PowK - 两点功耗校准斜率
            PowB - 两点功耗校准功耗偏移量
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), xm@2020-06-17 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetPwrPowCali(INT32 lPower, INT32 *PowK, INT32 *PowB)
{
    T_PwrCaliData *ptPwrCali = NULL;
    INT32 lPowK = 0;
    INT32 lPowB = 0;
    UINT32 loop = 0;
    UINT32 ulPwrIdx = 0;  //目前只有1个电源

	INPUT_POINTER_CHECK(PowK);
	INPUT_POINTER_CHECK(PowB);

    ptPwrCali = (T_PwrCaliData *)_BspGetCalibData(TBL_KIND_OF_PWRCALI,0);
    INPUT_POINTER_CHECK(ptPwrCali);
    _PWRTEMPALMFILE_LOADED_CHECK(ptPwrCali);


    if(ptPwrCali->tHeader[ulPwrIdx].ulPwrFlectionPoint == 0)
    {
        lPowK = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[4];
        lPowB = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[5];
    }
	else
	{
	    for(loop=0; loop<ptPwrCali->tHeader[ulPwrIdx].ulPwrFlectionPoint; loop++)
	    {
	        if(lPower >= ptPwrCali->tHeader[ulPwrIdx].lPwrPowerFlectionValue[loop])
	        {
	            lPowK = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[loop*6+4];
	            lPowB = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[loop*6+5];
	            break;
	        }
	    }
	    if(loop==ptPwrCali->tHeader[ulPwrIdx].ulPwrFlectionPoint)
	    {
            lPowK = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[loop*6+4];
            lPowB = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[loop*6+5];
	    }
	}
    dbgInfoEx("lPower =%d loop =%d\n", lPower,loop);
	*PowK = lPowK;
	*PowB = lPowB;
     	   
    return BSP_OK;
}

UINT32 BspCaliConsumedPower(INT32 *pPower)
{
    INT32 PowK = 0;
    INT32 PowB = 0;
    INT64 cali = 0;
    INT32 raw  = 0;

    INPUT_POINTER_CHECK(pPower);

    if(BSP_OK != BspGetPwrPowCali(*pPower,&PowK, &PowB))
    {
        PowK = 1000;
        PowB = 0;
    }
    dbgInfoEx("pow K=%d B=%d\n", PowK, PowB);

    raw = *pPower;
    cali = (INT64)raw*PowK/1000+ PowB;
    *pPower = (INT32)cali;
    dbgInfoEx("pow raw = %dmW cali = %lldmW\n",raw,cali);

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetPwrVoltCali
* 功能描述: 电源电压校准参数获取
* 输入参数: 无
* 输出参数: VoltK - 两点电压校准斜率
            VoltB - 两点电压校准电压偏移量
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), xm@2020-06-17 14:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetPwrVoltCali(INT32 lVolt, INT32 *VoltK, INT32 *VoltB)
{
    T_PwrCaliData *ptPwrCali = NULL;
    INT32 lVoltK = 0;
    INT32 lVoltB = 0;
    UINT32 loop = 0;
    UINT32 ulPwrIdx = 0;  //目前只有1个电源

	INPUT_POINTER_CHECK(VoltK);
	INPUT_POINTER_CHECK(VoltB);

    ptPwrCali = (T_PwrCaliData *)_BspGetCalibData(TBL_KIND_OF_PWRCALI,0);
    INPUT_POINTER_CHECK(ptPwrCali);
    _PWRTEMPALMFILE_LOADED_CHECK(ptPwrCali);

    if(ptPwrCali->tHeader[ulPwrIdx].ulVoltFlectionPoint == 0)
    {
        lVoltK = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[4];
        lVoltB = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[5];
    }
    else
    {
        for(loop=0; loop<ptPwrCali->tHeader[ulPwrIdx].ulVoltFlectionPoint; loop++)
        {
            if(lVolt >= ptPwrCali->tHeader[ulPwrIdx].lPwrVoltFlectionValue[loop])
            {
                lVoltK = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[loop*6+4];
                lVoltB = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[loop*6+5];
                break;
            }
        }
        if(loop==ptPwrCali->tHeader[ulPwrIdx].ulVoltFlectionPoint)
        {
            lVoltK = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[loop*6+4];
            lVoltB = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[loop*6+5];
        }
    }
    dbgInfoEx("lVolt =%d loop =%d\n", lVolt,loop);
    *VoltK = lVoltK;
    *VoltB = lVoltB;
     	   
    return BSP_OK;
}

UINT32 BspCaliPwrVolt(INT32 *pVolt)
{
    INT32 VoltK = 0;
	INT32 VoltB = 0;
	INT32 cali = 0;
	INT32 raw  = 0;
	UINT32 retVal = BSP_OK;

	INPUT_POINTER_CHECK(pVolt);

	retVal = BspGetPwrVoltCali(*pVolt, &VoltK, &VoltB);
	if (BSP_OK != retVal)
	{
        VoltK = 1000;
		VoltB = 0;
	}
	dbgInfoEx("volt K=%d B=%d\n", VoltK, VoltB);

	raw = *pVolt;
	cali = raw*VoltK/1000 + VoltB;
	*pVolt = cali;	

	dbgInfoEx("volt raw= %dmV clai = %dmV\n",raw,cali);

	return BSP_OK;
}
UINT32 BspGetPwrBarCode(UCHAR *ptPwrBarCode)
{
	UINT32 ulDevId = 0;
	CHAR  barcodeinfo[PWR_BARCODE_LEN] = {0};
	UINT32 ulRelVal = 0;

	ulDevId = BspGetPwrEepromDevId();
	ulRelVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_BARCODE,&barcodeinfo[0], PWR_BARCODE_LEN);
	if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
	barcodeinfo[PWR_BARCODE_LEN-1] = '\0';

	if(NULL != ptPwrBarCode)
	{
		memcpy(ptPwrBarCode,&barcodeinfo[0],PWR_BARCODE_LEN);
    }
	dbgInfo("%s \n",barcodeinfo);
    
	return BSP_OK;
}


/* 获取输入电压类型 */
UINT32 BspGetBoardVinType(UINT32 index, UINT32 *type)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    UINT32 typetmp = INVALID_VALUE;
    UINT32 ulRet = BSP_OK;
    int snpRet;

    INPUT_POINTER_CHECK(type);
    
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ulRet = BspGetVoltInType(devid, &typetmp);
    if(BSP_OK != ulRet)
    {
        dbgErr("Pwr Volt In Type Get Fail!\n");
        return BSP_ERROR;
    }
    dbgInfoEx("Pwr Volt In Type is %d!\n",typetmp);
    switch (typetmp)
    {
        case PWR_VOLT_IN_AC:
        {
            *type = PWR_TYPE_AC;
            break;
        }
        case PWR_VOLT_IN_HIGH_DC:
        {
            *type = PWR_TYPE_HIGH_DC;
            break;
        }
        case PWR_VOLT_IN_DC:
        {
            *type = PWR_TYPE_DC;
            break;
        }
        default:
        {
            *type = INVALID_VALUE;
            break;
        }
    }
    dbgInfoEx("Pwr Volt Type is %d!\n",*type);
    return ulRet;
}

/**************************************************************************
* 函数名称: BspGetPwrMcuDevIdNew()
* 功能描述: 获取大板电源组件MCU设备ID号
* 输入参数:
* 输出参数: 无
* 返 回 值:
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年01月22日                 贾路漫    创建
**************************************************************************/
UINT32 BspGetPwrMcuDevIdNew(VOID)
{
    char   bufName[PWR_EEPROM_NAME_LEN] ={0};
    UINT32 devid = 0;
    int snpRet;

    snpRet = snprintf_s(bufName, sizeof(bufName), "PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    return devid;
}
/*****************************************************************************
 *  函数名称   : BspActPwrVerNew(*)
 *  功能描述   : 大板电源版本激活
 *  输入参数   :
 *  返 回 值      : BSP_OK成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2020-09-22
 *----------------------------------------------------------------------------
 */
UINT32 BspActPwrVerNew(VOID)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrMcuDevIdNew();
    ulRetVal = BspSetPwrUpdate(ulPwrDevId);

    return ulRetVal;
}


/**************************************************************************
 * 函数名称: BspGetPwrManuFactorNo()
 * 功能描述: 获取电源厂家编号
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2020年09月15日                  贾路漫    创建
 **************************************************************************/
UINT32 BspGetPwrManuFactorNoNew(UCHAR *pPwrManuFactorNo)
{
    UINT32 ulDevId = 0;
    CHAR ucPwrManuFactorNo[PWR_FACTORYNO_LEN] = {0};
    UINT32 ulRelVal = 0;
    UINT32 PwrManuFactorNoNameLen = 1;

    ulDevId = BspGetPwrEepromDevId();

    ulRelVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_MANUFECTURER_NUM_NEW, ucPwrManuFactorNo, PWR_FACTORYNO_LEN-1);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }

#ifndef _BSP_WITH_WFS
    while((ucPwrManuFactorNo[PwrManuFactorNoNameLen-1]!='\0') && (ucPwrManuFactorNo[PwrManuFactorNoNameLen-1]!= 0x20))
    {
        PwrManuFactorNoNameLen++;
    }
#else
    while(ucPwrManuFactorNo[PwrManuFactorNoNameLen-1]!='\0')
    {
        PwrManuFactorNoNameLen++;
    }
#endif
    PwrManuFactorNoNameLen--;

    ucPwrManuFactorNo[PWR_FACTORYNO_LEN-1] = '\0';
    memcpy_s(pPwrManuFactorNo,PWR_FACTORYNO_LEN-1,ucPwrManuFactorNo,PWR_FACTORYNO_LEN-1);
    pPwrManuFactorNo[PWR_FACTORYNO_LEN-1] = '\0';

    dbgInfo("PwrManuFactorName:%s, len=%d\n",pPwrManuFactorNo,PwrManuFactorNoNameLen);

    return BSP_OK;
}
UINT32 BspGetPwrActUpdateStatusNew(VOID)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrMcuDevIdNew();
    ulRetVal = BspGetPwrUpdateStatus(ulPwrDevId);

    return ulRetVal;
}

UINT32 BspActPowerIicNew(void)
{
    UINT32 retVal     = 0;
    UINT32 ulDly      = 30;
    ulDly = BspGetPwrUpdateDly();
    BspSysMsDelay_Sys(ulDly);
    if(UPDATE_MODE == BspGetPwrActUpdateStatusNew())
    {
        if(NULL != pPwrByPassFuncCallBack)
        {
            pPwrByPassFuncCallBack(1); //bypass i2c
        }
        dbgInfo("--power is update mode !!!\n");
        return BSP_ERROR;
    }
    else
    {
        dbgInfo("--power is not update mode !!!\n");
    }
    return retVal;
}
UINT32 BspPowerUpdateNew(void)
{
    UINT32 retVal     = 0;
    UINT32 iLoop      = 0;
    for(iLoop=0; iLoop<UPDATE_TRY_TIMES; iLoop++)
    {
        retVal = BspActPwrVerNew();//发送升级命令
        if(BSP_OK != retVal)
        {
            dbgErr("iLoop = %d, BspActPwrVer error! \n",iLoop+1);
            pwrupdataLog("%s iLoop = %d, BspActPwrVer error! \n", __FUNCTION__, iLoop+1);
        }
        retVal = BspActPowerIicNew();//查询电源状态并旁路IIC
        if(BSP_OK != retVal)
        {
            dbgInfo("power is in update mode, break !!!");
            pwrupdataLog("%s power is in update mode, break !!!", __FUNCTION__);
            break;
        }
        BspSysMsDelay_Sys(30);
    }

    if(UPDATE_TRY_TIMES == iLoop)
    {
        dbgInfo("%s: Power update mode set failed\n", __FUNCTION__);
        pwrupdataLog("%s: Power update mode set failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetSubUnitHareWareVersionNew()
 * 功能描述: 从EEPROM中获取电源组件硬件版本号
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2020年09月15日                  贾路漫    创建
 **************************************************************************/
UINT32 BspGetSubUnitHareWareVersionNew(UCHAR *pSubUnitVer)
{
    UINT32 ulDevId = 0;
    CHAR  ucSubUnitVersion[PWR_SUBUNIT_VER_LEN] = {0};
    UINT32 ulRelVal = 0;
    UINT32 PwrHareWareVersionNameLen = 1;

    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_MODULE_VER_NEW, ucSubUnitVersion, PWR_SUBUNIT_VER_LEN-1);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }

#ifndef _BSP_WITH_WFS
    while((ucSubUnitVersion[PwrHareWareVersionNameLen-1]!='\0') && (ucSubUnitVersion[PwrHareWareVersionNameLen-1]!= 0x20))
    {
        PwrHareWareVersionNameLen++;
    }
#else
    while(ucSubUnitVersion[PwrHareWareVersionNameLen-1]!='\0')
    {
        PwrHareWareVersionNameLen++;
    }
#endif
    PwrHareWareVersionNameLen--;

    ucSubUnitVersion[PWR_SUBUNIT_VER_LEN-1] = '\0';
    memcpy_s(pSubUnitVer,PWR_SUBUNIT_VER_LEN-1,ucSubUnitVersion,PWR_SUBUNIT_VER_LEN-1);
    pSubUnitVer[PWR_SUBUNIT_VER_LEN-1] = '\0';

    dbgInfo("SubUnitHareWareVersion:%s, len=%d\n",pSubUnitVer,PwrHareWareVersionNameLen);

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetSubUnitName()
 * 功能描述: 获取大板电源名称
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2020年09月21日                  贾路漫    创建
 **************************************************************************/
UINT32 BspGetSubUnitNameNew(UCHAR *pSubUnitName)
{
    UINT32 ulDevId = 0;
    CHAR  uSubUnitName[PWR_SUB_NAME_LEN_MAX] = {0};
    UINT32 ulRelVal = 0;
    PwrSubUnitNameLen=0;

    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, 0x0, uSubUnitName, PWR_SUB_NAME_LEN_MAX);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    while( (uSubUnitName[PwrSubUnitNameLen++]!='\0') && (uSubUnitName[PwrSubUnitNameLen++]!= 0x20) ){};
    uSubUnitName[PwrSubUnitNameLen-1]='\0';
    memcpy_s(pSubUnitName,PwrSubUnitNameLen,uSubUnitName,PwrSubUnitNameLen);
    dbgInfoEx("SubUnitName:[%s] \n",pSubUnitName);
    return BSP_OK;
}

UINT32 BspGetSubUnitNameLenth(void)
{
    UINT32 ulDevId = 0;
    CHAR   uSubUnitName[PWR_SUB_NAME_LEN_MAX] = {0};
    UINT32 ulRelVal = 0;
    PwrSubUnitNameLen=0;

    ulDevId = BspGetPwrEepromDevId();
    ulRelVal = BspGetEepromInfo(ulDevId, 0x0,(CHAR *)uSubUnitName, PWR_SUB_NAME_LEN_MAX);
    if(BSP_OK != ulRelVal)
    {
        return BSP_ERROR;
    }
    while((uSubUnitName[PwrSubUnitNameLen++]!='\0') && (uSubUnitName[PwrSubUnitNameLen++]!=0x20)){};
    uSubUnitName[PwrSubUnitNameLen-1]='\0';
    dbgInfoEx("PwrSubUnitNameLen= [%d]\n",PwrSubUnitNameLen);

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetPwrDevId(UCHAR  SubSubUnitNo)
 *  功能描述   : 通过子组件编号获取DevId
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *              UCHAR  SubSubUnitNo          子组件编号
 *  返 回 值   : DevId
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2020-8-28
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPwrDevId(UINT32  SubSubUnitNo)
{
    UINT32 ret = 0;
    int snpRet = 0;
    UINT32 devid = 0;
    UINT32 ulAddr = 0;
    UINT32 index = 0;
    char   bufName[PWR_EEPROM_NAME_LEN] ={0};
    TRruDeviceDescription dev      = {0};

    if(0 == SubSubUnitNo)
    {
        snpRet = snprintf_s(bufName, sizeof(bufName), "PwrMcu");
        SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
        devid = BspDevNameToId(bufName);
        INPUT_DEVICEID_CHECK(devid);
        return devid;
    }

    for(index=0; index<SubSubUnitNo; index++)
    {
        memset((void *)&dev, 0, sizeof(dev));
        snpRet = snprintf_s(bufName, sizeof(bufName), "RpdcDac%d",0 + index);
        SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
        devid = BspDevNameToId(bufName);
        INPUT_DEVICEID_CHECK(devid);
        ret = BspDevInfoGetByDevId(devid, &dev);
        if(BSP_OK != ret)
        {
            continue;
        }
        ulAddr = strtoul(dev.acRev, NULL, 16);

        dbgInfoEx("SubSubUnitNo %d  devid %d  ulAddr %d\n", SubSubUnitNo, devid, ulAddr);

        if(ulAddr == (0x58 -1 + SubSubUnitNo))/*电源模块升级版本index和IIC地址强绑定1,2,3对应地址0x58 0x59 0x5a*/
        {
            return devid;
        }
    }

    return BSP_ERROR;
}
/*返回长度*/
UINT32 BspGetPwrSubMfr(UINT32 SubSubUnitNo,UCHAR *pucVal,UINT32 *ulByteNum)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;
    char   SubMfrBuffer[32] = {0};
    UINT32  length = 28;
    ulPwrDevId = BspGetPwrDevId(SubSubUnitNo);
    ulRetVal = BspGetPwrSubMfrInfo(ulPwrDevId,SubMfrBuffer,length);
    length = SubMfrBuffer[0];
    if(length >=31)
    {
        length = 30;
    }
    SubMfrBuffer[length+1]=0;
    memcpy_s(pucVal,length+1,&SubMfrBuffer[1],length+1);
    *ulByteNum=length;
    if(ulRetVal !=BSP_OK)
    {
        dbgErr("%s :get Submfr error",__FUNCTION__);
    }
    return ulRetVal;
}
UINT32 _BspUpdatePowerModuleNew(UINT32 ulModule)
{

    UINT32 iLoop      = 0;
    UINT32 pwrDevIdx  = 0;
    UINT32 cmpLen     = 0;
    UINT32 ulSubIndex = ulModule;
    UCHAR  pwrVerInfo[6] = {0};
    UINT32 waitTime = 0;
    UINT32 pwrVerIdx = 1;
    UINT32 mcuUpgradeFlag = 0;

    BspPowerUpdateNew();
    mcuUpgradeFlag = BspGetSmartPwrMcuCfg();
    if(mcuUpgradeFlag)
    {
        pwrVerIdx = 0;/*大板智能MCU升级,如果挂的PD1500驱动，获取MCU版本号从索引0读取，大板电源驱动从索引1读取*/
    }

    if(0 != BspUpdatePowerWaitTime())
    {
        waitTime = s_isBoardUpdatePowerWaitTime;
    }
    else
    {
        waitTime = POWER_UPDATE_WAIT_TIME;
    }
    dbgInfo("--wait %d mins-----\n", waitTime);
    for(iLoop=0; iLoop <= waitTime*60; iLoop++)
    {
        dbgInfo("^_^");
        if (iLoop %60 == 0)
        {
            dbgInfo("\n");
            dbgInfo("--cost %ds--\n", iLoop);
        }
        sleep(1);
    }

    if(NULL != pPwrByPassFuncCallBack)
    {
        pPwrByPassFuncCallBack(0); //i2c恢复
    }
    dbgInfoEx("atPwrVerInfoNew[ulSubIndex].ucSubUnitNo = [%d]", atPwrVerInfoNew[ulSubIndex].ucSubUnitNo);
    pwrupdataLog("atPwrVerInfoNew[ulSubIndex].ucSubUnitNo = [%d]", atPwrVerInfoNew[ulSubIndex].ucSubUnitNo);
    pwrDevIdx=BspGetPwrDevId(atPwrVerInfoNew[ulSubIndex].ucSubUnitNo);
    dbgInfoEx("pwrDevIdx = [%d]\n", pwrDevIdx);
    pwrupdataLog("pwrDevIdx = [%d]\n", pwrDevIdx);
    BspGetPwrVer(pwrDevIdx, 0, &pwrVerInfo[0], NELEMENTS(pwrVerInfo));
    pwrVerInfo[5]= '\0';
    dbgInfo("%s:  Result ulSubIndex[%d],PwrIndex[%d] NowVer:[%s], UpdateFileVer:[%s]\n", __FUNCTION__,ulSubIndex, atPwrVerInfoNew[ulSubIndex].ucSubUnitNo, &pwrVerInfo[ulSubIndex], &atPwrVerInfoNew[ulSubIndex].ucProgramVer[0]);
    pwrupdataLog("%s:  Result ulSubIndex[%d],PwrIndex[%d] NowVer:[%s], UpdateFileVer:[%s]\n", __FUNCTION__,ulSubIndex, atPwrVerInfoNew[ulSubIndex].ucSubUnitNo, &pwrVerInfo[ulSubIndex], &atPwrVerInfoNew[ulSubIndex].ucProgramVer[0]);
    cmpLen = 4;
    if(0 != memcmp(&pwrVerInfo[pwrVerIdx], &atPwrVerInfoNew[ulSubIndex].ucProgramVer[0], cmpLen))
    {
        dbgErr("%s: ulSubIndex'%d update failed!\n", __FUNCTION__, ulSubIndex);
        pwrupdataLog("%s: ulSubIndex'%d update failed!\n", __FUNCTION__, ulSubIndex);
        return BSP_ERROR;
    }

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspCheckSubUnitVerInfoNew()
 * 功能描述: 判断组件版本是否需要升级
 * 输入参数: ulPwrDevId 电源设备编号
 *      : ulSubIndex 组件版本序号，组件在组件包中的顺序
 *      : ucSubUnitNo 组件编号
 * 输出参数: 无
 * 返 回 值  : BSP_OK:    需要升级
 *      : BSP_ERROR: 不需要升级
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2020年09月15日                   贾路漫    创建
 **************************************************************************/
UINT32 BspCheckSubUnitVerInfoNew(UINT32 ulPwrDevId, UINT32 ulSubIndex)
{
    UCHAR ucPwrVer[PWR_SOFT_VER_LEN] = {0};
    UCHAR ucSubUnitName[PWR_SUB_NAME_LEN] = {0};
    UCHAR ucSubUnitHardWareVersion[PWR_SUBUNIT_VER_LEN] = {0};
    UCHAR ucPwrManuFactorNo[PWR_FACTORYNO_LEN] = {0};
    UCHAR ucSubSubUnitName[PWR_SUB_SUB_NAME_LEN_MAX];
    UCHAR ucSubUnitNo = 0;
    UINT32 pwrVerIdx = 1;
    UINT32 mcuUpgradeFlag = 0;

    INPUT_INDEX_CHECK_PWR(ulSubIndex, SUB_PWR_MODULE_NUM);
    ucSubUnitNo = atPwrVerInfoNew[ulSubIndex].ucSubUnitNo;

    mcuUpgradeFlag = BspGetSmartPwrMcuCfg();
    if(mcuUpgradeFlag)
    {
        pwrVerIdx = 0;/*大板智能MCU升级,如果挂的PD1500驱动，获取MCU版本号从索引0读取，大板电源驱动从索引1读取*/
        dbgInfo("Smart PwrMcu Upgrade,No Need to Check Electronic tag!\n");
    }
    else
    {
        /*对比大板名称*/
        BspGetSubUnitNameNew(ucSubUnitName);
        if(BSP_OK != memcmp(ucSubUnitName,&atPwrVerInfoNew[ulSubIndex].ucSubUnitName[0],PwrSubUnitNameLen-1))
        {
            dbgErr("%s SubUnitName Diff! %s [%s] \n",__FUNCTION__,ucSubUnitName,atPwrVerInfoNew[ulSubIndex].ucSubUnitName);
            return SUBUNIT_NAME_NO_SAME;
        }
        /*电源组件版本比对*/
        BspGetSubUnitHareWareVersionNew(ucSubUnitHardWareVersion);
        if(BSP_OK != memcmp(ucSubUnitHardWareVersion,&atPwrVerInfoNew[ulSubIndex].ucSubUnitVer[0],PWR_SUB_VER_LEN-1))
        {
            dbgErr("%s SubUnitVersion Diff! %s [%s] \n",__FUNCTION__,ucSubUnitHardWareVersion,atPwrVerInfoNew[ulSubIndex].ucSubUnitVer);
            return SUBUNIT_HARDWARE_VER_NO_SAME;
        }
        /*厂家编号对比*/
        BspGetPwrManuFactorNoNew(ucPwrManuFactorNo);
        if(BSP_OK != memcmp(ucPwrManuFactorNo,&atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo[0],PWR_FACTORYNO_LEN-1))
        {
            dbgErr("%s PwrManuFactorNo Diff! %s [%s] \n",__FUNCTION__,ucPwrManuFactorNo,atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo);
            return SUBUNIT_MANUFACTORNO_NO_SAME;
        }
        /*子组件名称比对*/
        if( (s_PwrSubSubUnitNo[ulSubIndex]!=0) && (s_RruPwrTplg.pwrTopology[s_PwrSubSubUnitNo[ulSubIndex]] == 1))//MCU不进行子组件名比对
        {
            BspGetPwrSubMfr(s_PwrSubSubUnitNo[ulSubIndex],ucSubSubUnitName,&PwrSubSubUnitNameLen);
            if(BSP_OK != memcmp(ucPwrManuFactorNo,&atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo[0],PWR_FACTORYNO_LEN-1))
            {
                dbgErr("%s PwrManuFactorNo Diff! %s [%s] \n",__FUNCTION__,ucPwrManuFactorNo,atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo);
                return SUBUNIT_MANUFACTORNO_NO_SAME;
            }
        }
        else if (s_RruPwrTplg.pwrTopology[s_PwrSubSubUnitNo[ulSubIndex]] == 0)/*模块不存在*/
        {
            dbgInfo("Check Fail,Module doesn't exist！SubIndex:%d  SubUnitNo:%d\n", ulSubIndex, ucSubUnitNo);
            return SUBUNIT_NOT_EXIT;
        }
        else /*MCU组件*/
        {
            dbgInfo("This Module is MCU !! Index:%d SubUnitNo:%d \n", ulSubIndex, ucSubUnitNo);
        }
    }

    /*版本比对*/
    ulPwrDevId=BspGetPwrDevId(ucSubUnitNo);
    BspGetPwrVer(ulPwrDevId, ucSubUnitNo, ucPwrVer, PWR_SOFT_VER_LEN);
    ucPwrVer[PWR_SOFT_VER_LEN-1] = '\0';

    if(BSP_OK == memcmp(&ucPwrVer[pwrVerIdx],&atPwrVerInfoNew[ulSubIndex].ucProgramVer[0],PWR_SUB_VER_LEN-1))
    {
        dbgErr("Ver is same,ulSubIndex:%d ucSubUnitNo:%d ucNowVer:%s ucProgramVer:%s \n",
                ulSubIndex,ucSubUnitNo,&ucPwrVer[pwrVerIdx],&atPwrVerInfoNew[ulSubIndex].ucProgramVer[0]);
        return SUBUNIT_VER_SAME;
    }

    if( memcmp(&ucPwrVer[pwrVerIdx],&atPwrVerInfoNew[ulSubIndex].ucMinProgramVer[0],PWR_SUB_VER_LEN-1) <0)
    {
        dbgErr("Out of MinVer Range,ulSubIndex:%d ucSubUnitNo:%d ucNowVer:[%s] ucMinProgramVer:[%s]\n",
                ulSubIndex,ucSubUnitNo,&ucPwrVer[pwrVerIdx],&atPwrVerInfoNew[ulSubIndex].ucMinProgramVer[0]);
        dbgErr("Out of MinVer Range value:%d \n",memcmp(ucPwrVer,&atPwrVerInfoNew[ulSubIndex].ucMinProgramVer[0],PWR_SUB_VER_LEN-1));
        return SUBUNIT_VER_OUTRANGE;
    }

    if( memcmp(&ucPwrVer[pwrVerIdx],&atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer[0],PWR_SUB_VER_LEN-1) >0)
    {
        dbgErr("Out of MaxVer Range,ulSubIndex:%d ucSubUnitNo:%d ucNowVer:%s ucMaxProgramVer:%s \n",
                ulSubIndex,ucSubUnitNo,&ucPwrVer[pwrVerIdx],&atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer[0]);
        return SUBUNIT_VER_OUTRANGE;
    }

    dbgInfo("Check OK,ulSubIndex:%d ucSubUnitNo:%d ucNowVer:%s ucProgramVer:%s \n",
        ulSubIndex,ucSubUnitNo,ucPwrVer,&atPwrVerInfoNew[ulSubIndex].ucProgramVer[0]);
    return SUBUNIT_VER_NEED_UPGRADE;
}
/*****************************************************************************
 *  函数名称   : BspSetPwrUpdateFlagNew(*)
 *  功能描述   : 大板电源通过比对设置更新标志
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫@2020-09-15  创建
 *
 *----------------------------------------------------------------------------
 */
UINT32  BspSetPwrUpdateFlagNew(UINT32 ulSubIndex, UINT32 ulLineNum)
{
    UINT32 ulPwrDevId = 0;
    UINT32 temp = 0;
    ulPwrDevId = BspGetPwrMcuDevId();
    if(4 <= ulSubIndex)
    {
        dbgInfo("%s ulSubIndex = %d, out of bound!\n", __FUNCTION__, ulSubIndex);
        pwrupdataLog("%s ulSubIndex = %d, out of bound!\n", __FUNCTION__, ulSubIndex);
        return BSP_ERROR;
    }
    if(4 == ulLineNum) /*读完组件版本头后，判断组件版本是否需要写入*/
    {
        temp = BspCheckSubUnitVerInfoNew(ulPwrDevId, ulSubIndex);
        dbgInfo("temp = %d\n",temp);
        pwrupdataLog("temp = %d\n",temp);
        dbgInfo("s_PwrSubSubUnitNo[ulSubIndex] %d\n", s_PwrSubSubUnitNo[ulSubIndex]);
        pwrupdataLog("s_PwrSubSubUnitNo[ulSubIndex] %d\n", s_PwrSubSubUnitNo[ulSubIndex]);
        dbgInfo("atPwrVerInfoNew[ulSubIndex].ucSubUnitNo =%d\n", atPwrVerInfoNew[ulSubIndex].ucSubUnitNo);
        pwrupdataLog("atPwrVerInfoNew[ulSubIndex].ucSubUnitNo =%d\n", atPwrVerInfoNew[ulSubIndex].ucSubUnitNo);
        if(SUBUNIT_VER_NEED_UPGRADE != temp)
        {
            s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]] |= PWR_VER_CHK_FAIL;
            dbgInfo("Index[%d] Subno{%d} pwrPkgCrcChk=[%d] subPkg ver chk err!!\n",\
                    ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]]);
            pwrupdataLog("Index[%d] Subno{%d} pwrPkgCrcChk=[%d] subPkg ver chk err!!\n",\
                    ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]]);
            return BSP_ERROR;
        }
        dbgInfo("%s  Index[%d] Subno{%d} pwrPkgCrcChk=%d subPkg ver chk ok!!!\n",\
                __FUNCTION__, ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex],\
                s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]]);
        pwrupdataLog("%s  Index[%d] Subno{%d} pwrPkgCrcChk=%d subPkg ver chk ok!!!\n",\
                __FUNCTION__, ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex],\
                s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]]);
    }
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetPwrVerInfoNew(*)
 *  功能描述   : 解析组件版本信息
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫@2020-09-15  创建
 *
 *----------------------------------------------------------------------------
 */
UINT32  BspGetPwrVerInfoNew(UINT32 ulSubIndex,UCHAR* ucInfo, UINT32 ulLen, UINT32 ulLineNo)
{
    UCHAR ucSubUnitNo = 0;
    UINT32 ulPwrDevId = 0;
    UCHAR ucPwrVer[PWR_SUB_VER_LEN] = {0};
    UCHAR pucVal[40]={0};

    switch(ulLineNo)
    {
        case 0:
            /*获取单板名称*/
            BspGetSubUnitNameLenth();
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucSubUnitName[0],PwrSubUnitNameLen-1,ucInfo,PwrSubUnitNameLen-1);
            atPwrVerInfoNew[ulSubIndex].ucSubUnitName[PwrSubUnitNameLen-1] = '\0';
            dbgInfoEx("ucSubUnitName=[%s]\n",atPwrVerInfoNew[ulSubIndex].ucSubUnitName);
            pwrupdataLog("ucSubUnitName=[%s]\n",atPwrVerInfoNew[ulSubIndex].ucSubUnitName);
            break;
        case 1:
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucSubUnitVer[0],sizeof(atPwrVerInfoNew[ulSubIndex].ucSubUnitVer),ucInfo,sizeof(atPwrVerInfoNew[ulSubIndex].ucSubUnitVer));
            atPwrVerInfoNew[ulSubIndex].ucSubUnitVer[4] = '\0';
            atPwrVerInfoNew[ulSubIndex].ucSubUnitNo = ucInfo[4];
            s_PwrSubSubUnitNo[ulSubIndex] = ucInfo[4];
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo[0],sizeof(atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo),&ucInfo[5],sizeof(atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo));
            atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo[8] = '\0';
            dbgInfoEx("ucSubUnitVer    = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucSubUnitVer);
            pwrupdataLog("ucSubUnitVer    = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucSubUnitVer);
            dbgInfo("ucSubUnitNo     = [%d]\n",atPwrVerInfoNew[ulSubIndex].ucSubUnitNo);
            pwrupdataLog("ucSubUnitNo     = [%d]\n",atPwrVerInfoNew[ulSubIndex].ucSubUnitNo);
            dbgInfoEx("ucManuFactoryNo = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo);
            pwrupdataLog("ucManuFactoryNo = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucManuFactoryNo);
            break;
        case 2:
            if ((s_PwrSubSubUnitNo[ulSubIndex]==0) || (s_RruPwrTplg.pwrTopology[s_PwrSubSubUnitNo[ulSubIndex]] == 0))
            {
                break;
            }
            BspGetPwrSubMfr(s_PwrSubSubUnitNo[ulSubIndex],pucVal,&PwrSubSubUnitNameLen);
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucSubSubUnitName[0],PwrSubSubUnitNameLen,&ucInfo[0],PwrSubSubUnitNameLen);
            atPwrVerInfoNew[ulSubIndex].ucSubSubUnitName[PwrSubSubUnitNameLen+1] = '\0';
            dbgInfoEx("ucSubSubUnitName=[%s]\n",atPwrVerInfoNew[ulSubIndex].ucSubSubUnitName);
            pwrupdataLog("ucSubSubUnitName=[%s]\n",atPwrVerInfoNew[ulSubIndex].ucSubSubUnitName);
            break;
        case 3:
            if (s_RruPwrTplg.pwrTopology[s_PwrSubSubUnitNo[ulSubIndex]] == 0)
            {
                break;
            }
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucProgramVer[0],sizeof(atPwrVerInfoNew[ulSubIndex].ucProgramVer),&ucInfo[0],sizeof(atPwrVerInfoNew[ulSubIndex].ucProgramVer));
            atPwrVerInfoNew[ulSubIndex].ucProgramVer[4] = '\0';
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucMinProgramVer[0],sizeof(atPwrVerInfoNew[ulSubIndex].ucMinProgramVer),&ucInfo[4],sizeof(atPwrVerInfoNew[ulSubIndex].ucMinProgramVer));
            atPwrVerInfoNew[ulSubIndex].ucMinProgramVer[4] = '\0';
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer[0],sizeof(atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer),&ucInfo[8],sizeof(atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer));
            atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer[4] = '\0';
            atPwrVerInfoNew[ulSubIndex].ulLineSize = ucInfo[12];
            ucSubUnitNo = atPwrVerInfoNew[ulSubIndex].ucSubUnitNo;
            ulPwrDevId = BspGetPwrDevId(ucSubUnitNo);
            BspGetPwrVer(ulPwrDevId, ucSubUnitNo, &ucPwrVer[0], PWR_SOFT_VER_LEN);
            memcpy_s((UCHAR*)&atPwrVerInfoNew[ulSubIndex].ucOldProgramVer[0],PWR_SUB_VER_LEN-1,&ucPwrVer[1],PWR_SUB_VER_LEN-1);
            atPwrVerInfoNew[ulSubIndex].ucOldProgramVer[4] = '\0';
            dbgInfoEx("ucProgramVer    = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucProgramVer);
            pwrupdataLog("ucProgramVer    = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucProgramVer);
            dbgInfoEx("ucMinProgramVer = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucMinProgramVer);
            pwrupdataLog("ucMinProgramVer = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucMinProgramVer);
            dbgInfoEx("ucMaxProgramVer = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer);
            pwrupdataLog("ucMaxProgramVer = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucMaxProgramVer);
            dbgInfoEx("ucOldProgramVer = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucOldProgramVer);
            pwrupdataLog("ucOldProgramVer = [%s]\n",atPwrVerInfoNew[ulSubIndex].ucOldProgramVer);
            break;
        case 4:
            atPwrVerInfoNew[ulSubIndex].ulMinLineAddr = (ucInfo[0]<<24)+(ucInfo[1]<<16)+(ucInfo[2]<<8)+ucInfo[3];
            atPwrVerInfoNew[ulSubIndex].ulMaxLineAddr = (ucInfo[4]<<24)+(ucInfo[5]<<16)+(ucInfo[6]<<8)+ucInfo[7];
            atPwrVerInfoNew[ulSubIndex].ulMauLenSize = ucInfo[8];
            atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum = (ucInfo[9]<<8)+ucInfo[10];
            atPwrVerInfoNew[ulSubIndex].ulFileCheckSum = (ucInfo[11]<<8)+ucInfo[12];
            dbgInfoEx("ulMinLineAddr       = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulMinLineAddr);
            pwrupdataLog("ulMinLineAddr       = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulMinLineAddr);
            dbgInfoEx("ulMaxLineAddr       = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulMaxLineAddr);
            pwrupdataLog("ulMaxLineAddr       = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulMaxLineAddr);
            dbgInfoEx("ulMauLenSize        = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulMauLenSize);
            pwrupdataLog("ulMauLenSize        = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulMauLenSize);
            dbgInfoEx("ulProgramCheckSum   = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
            pwrupdataLog("ulProgramCheckSum   = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
            dbgInfoEx("ulFileCheckSum      = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulFileCheckSum);
            pwrupdataLog("ulFileCheckSum      = [%d]\n",atPwrVerInfoNew[ulSubIndex].ulFileCheckSum);
            break;
        default:
            return BSP_ERROR;
    }

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : PwrHeadDataCheck
 *  功能描述   : 电源包头校验
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *              UCHAR  SubSubUnitNo          子组件编号
 *  返 回 值   : DevId
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2020-8-28
 *----------------------------------------------------------------------------
 */
UINT32 PwrHeadDataCheck(UINT32 ucLineInfoSize, CHAR* pcbuf)
{
    UINT32 ucCheckSum = 0;
    UINT32 ucCheckSumComp = 0;  /*校验和的补码*/
    UINT32 ulLp = 0;
    CHAR pcLineData[40]={0};

    for(ulLp = 0; ulLp < ucLineInfoSize; ulLp++)
    {
        pcLineData[ulLp] = BspHexToAsc(pcbuf[ulLp*2])*16 + BspHexToAsc(pcbuf[1+ulLp*2]);
    }

    for(ulLp = 0; ulLp < ucLineInfoSize-2; ulLp++)
    {
        ucCheckSum += pcLineData[ulLp];
    }
    dbgInfoEx("%s ucCheckSum: %d \n",__FUNCTION__,ucCheckSum);
    pwrupdataLog("%s ucCheckSum: %d \n",__FUNCTION__,ucCheckSum);
    if(( ucLineInfoSize >= 2) && (ucLineInfoSize<=39 ))
    {
        ucCheckSumComp =(UINT32)pcLineData[ucLineInfoSize-2]*256+pcLineData[ucLineInfoSize-1];
    }
    else
    {
        dbgErr("Head Check length erro \n");
        pwrupdataLog("Head Check length erro \n");
    }
    if(ucCheckSumComp != (0x10000-ucCheckSum))
    {
        dbgErr("checksum error! [%04X] [%04X] \n",0x10000-ucCheckSum,ucCheckSumComp);
        pwrupdataLog("checksum error! [%04X] [%04X] \n",0x10000-ucCheckSum,ucCheckSumComp);
        return BSP_ERROR;
    }
    dbgInfo("Head Check OK!\n");
    pwrupdataLog("Head Check OK!\n");
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspEraseEeprom(*)
 *  功能描述   : 擦除EEPROM
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *              UINT32 devId              器件Id
 *              UINT32 offset             写入地址
 *              UINT32 eepromEraseData    擦写值   一般为0xFF 范围是 0～255
 *              UINT32 Length             擦写长度
 *  返 回 值   : BSP_OK或BSP Error
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2020-8-28
 *----------------------------------------------------------------------------
 */
UINT32 BspErasePwrEeprom(UINT32 devId, UINT32 offset, UINT32 eepromEraseData, UINT32 Length)
{
    UINT32 ulRetVal = BSP_ERROR;
    CHAR* pCh = NULL;
    pCh = (CHAR *)malloc(Length);
    if (pCh == NULL)
    {
        return BSP_ERROR;
    }
    memset(pCh,eepromEraseData,Length);
    ulRetVal = BspSetEepromInfo(devId, offset,pCh, Length);
    free(pCh);
    return  ulRetVal;
}
UINT32 BspWriteStringToEeprom(UINT32 offset, CHAR* buf, UINT32 length)
{
    UINT32 i = 0;
    UINT32 ulDevId = 0;
    UINT32 bufLen = 0;
    UCHAR  checkSum = 0;
    UINT32 ulRetVal = 0;

    INPUT_POINTER_CHECK(buf);
    if (length >= PWR_EEPROM_NAME_LEN)
    {
        dbgErr("%s return Error! \n",__FUNCTION__);
        return BSP_ERROR;
    }

    while(*(buf+bufLen) != '\0')
    {
        bufLen++;
    }
    ulDevId = BspGetPwrEepromDevId();
    ulRetVal = BspSetEepromInfo(ulDevId, offset, buf, bufLen);
    if(length > bufLen)
    {
        ulRetVal |= BspErasePwrEeprom(ulDevId, offset+bufLen, 0x20, length-bufLen);
    }
    for (i = 0; i < length; i++)
    {
      if(i < bufLen)
      {
          checkSum = checkSum + buf[i];
      }
      else
      {
          checkSum = checkSum + 0x20;
      }
    }
    ulRetVal |= BspErasePwrEeprom(ulDevId, offset+length, checkSum,1);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s Write Error　length[%d]!\n",__FUNCTION__, bufLen);
    }
    return ulRetVal;
}
/*****************************************************************************
 *  函数名称   : BspWriteElectronicTabToEeprom(*)
 *  功能描述   : 向大板电源EEPROM中写入电子标签
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :

 *  返 回 值   : BSP_OK或BSP Error
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2020-8-28
 *----------------------------------------------------------------------------
 */
UINT32 BspWriteElectronicTabToEeprom(CHAR* boardname, CHAR* mfrno, CHAR* verno)
{
    UINT32 ulRetVal = 0;
    ulRetVal = BspWriteStringToEeprom(0x00, boardname, 15);
    ulRetVal |= BspWriteStringToEeprom(0x10, mfrno, 8);
    ulRetVal |= BspWriteStringToEeprom(0x19, verno, 7);
    return ulRetVal;
}
/*****************************************************************************
 *  函数名称   : BspWriteLineInfoToEeprom(*)
 *  功能描述   : 返回EEPROM写版本地址
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspWriteLineInfoToEepromNew(UINT32 ulAddr, UCHAR* pData, UINT32 ulLen)
{
    UINT32 ulLp = 3;
    UINT32 ulDevId = 0;
    UINT32 ulRetVal = BSP_OK;
    UCHAR ucData[MAX_VER_LINE_LEN] = {0};
    if(ulLen >= MAX_VER_LINE_LEN)
    {
        dbgErr("%s return Error! \n",__FUNCTION__);
        pwrupdataLog("%s return Error! \n",__FUNCTION__);
        return BSP_ERROR;
    }

    ulDevId = BspGetPwrEepromDevId();
    memset((UCHAR*)&ucData[0],'\0',MAX_VER_LINE_LEN);
    while(ulLp--)
    {
        ulRetVal = BspSetEepromInfoSplit(ulDevId, ulAddr,pData, ulLen);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s Write Error!\n",__FUNCTION__);
            pwrupdataLog("%s Write Error!\n",__FUNCTION__);
            dbgErr("%s Write E2prom Error Addr is %08x,  len=%d!\n",__FUNCTION__,ulAddr,ulLen);
            pwrupdataLog("%s Write E2prom Error Addr is %08x,  len=%d!\n",__FUNCTION__,ulAddr,ulLen);
        }
        BspSysMsDelay(10);

        ulRetVal = BspGetEepromInfoSplit(ulDevId, ulAddr,&ucData[0], ulLen);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("%s Read Error!\n",__FUNCTION__);
            pwrupdataLog("%s Read Error!\n",__FUNCTION__);
            dbgErr("%s Write Error Addr is %08x,  len=%d!\n",__FUNCTION__,ulAddr,ulLen);
            pwrupdataLog("%s Write Error Addr is %08x,  len=%d!\n",__FUNCTION__,ulAddr,ulLen);
        }

        ucData[ulLen] = '\0';

        if(0 != memcmp(pData,&ucData[0],ulLen))
        {
            continue;
        }
        return BSP_OK;
    }
    return BSP_ERROR;
}
/*****************************************************************************
 *  函数名称   : BspGetPwrEepromAddrNew(*)
 *  功能描述   : 返回大板电源EEPROM写版本地址
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   :
 *  返 回 值      : BSP_OK
 *  其它说明   :行号      ulLine      起始地址
 *             一        0            0x200~0x21F
 *             二        1            0x220~0x23F
 *             三        2            0x240~0x27F
 *             四        3            0x280~0x29F
 *             五        4            0x2A0~0x2BF
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),  贾路漫 @2020-08-28
 *----------------------------------------------------------------------------
 */
UINT32  BspGetPwrEepromAddrNew(UINT32 ulLine, UCHAR ucRec,UINT32 *ulpAddr)
{
    UINT32 ulAddr = 0;

    if(0xf0 == ucRec)
    {
        if( (ulLine==0) || (ulLine==1)||(ulLine==2) )/*第一行到第三行每行偏移都为0x20  (line=0,1,2)*/
        {
            ulAddr = (0x200 + 0x20 * ulLine);
        }
        else if((ulLine==3)||(ulLine==4))/*第4行（luine=3,line从0开始）写入地址为0x280*/
        {
            ulAddr = (0x200 + 0x20 * (ulLine+1));
        }
        else
        {
            *ulpAddr = 0;
            return BSP_ERROR;
        }
    }
    else
    {
        ulAddr = 0x300;
    }

    *ulpAddr = ulAddr;

    return BSP_OK;
}
UINT32 ReadEepromPwrCode(UINT32 lineNum ,UINT32 startAddr,UINT32 startLine,UINT32 lineLength)
{
    UINT32 i=0;
    UINT32 j=0;
    CHAR   ucData[40]={0};// 811 一行22字节　　810一行38字节
    UINT32 ulDevId = 0;
    UINT32 ret = 0;
    ulDevId = BspGetPwrEepromDevId();
    for(i=0;i<lineNum;i++)
    {
        ret = BspGetEepromInfo(ulDevId, (startAddr+i*lineLength),&ucData[0], lineLength);
        if(ret !=BSP_OK)
        {
            return ret;
        }
        dbgInfo("Line=[%04d]:",i+startLine);
        for(j=0;j<lineLength;j++)
        {
            dbgInfo("%02X",ucData[j]);
        }
        dbgInfo("\n");
     }
    return ret;
}

/*获取Eeprom信息*/
UINT32 BspGetPwrEepromInfo(UINT32 addr, CHAR*  buf, UINT32 len )
{
    UINT32 index=0;
    UINT32 ulDevId = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(buf);
    ulDevId = BspGetPwrEepromDevId();

    ret = BspGetEepromInfo(ulDevId, 0,&buf[0], len);
    if(ret !=BSP_OK)
    {
        return ret;
    }

    for (index = 0; index < len; index++)
    {
        if ((index % 0x10) == 0)
        {
            //coverity[cert_int30_c_violation:SUPPRESS]
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfoEx("\nEeprom[0X%04X]:%02X", addr + index, buf[index]);
        }
        //coverity[cert_str34_c_violation:SUPPRESS]
        dbgInfoEx("%02X", buf[index]);
    }
    dbgInfoEx("\n");
    return ret;
}

/*获取单板名称*/
UINT32 BspGetBoardNameFromPwrEeprom(CHAR*  pbuf, UINT32 plen )
{
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pbuf);
    if (plen > PWR_EETAB_BOARD_NAME_LEN)
    {
        plen = PWR_EETAB_BOARD_NAME_LEN;
        dbgInfo("board name lenth  must < =  16 bytes\n");
    }
    ret = BspGetPwrEepromInfo(PWR_EETAB_BOARD_NAME_ADDR, pbuf, plen);
    return ret;
}

/*****************************************************************************
 *  函数名称   : BspPwrSubVerCrc16Check(*)
 *  功能描述   : CRC16校验
 *  输入参数   : ulLineNum：行数
 *              usCrcInit：校验初值
 *              pcLineData：待校验数据
 *              ucLineInfoSize：数据长度
 *  返 回 值   : usCrcSum： 校验结果
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    @2020-12-15 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT16 BspPwrSubModuleCrcChk(UINT32 ulLineNum, UINT16 usCrcInit, const CHAR* pcLineData, UCHAR ucLineInfoSize)
{
    UINT16  usCrcSum = usCrcInit;
    UINT32  ulLineDataSize = 0;

    pcLineData++;   /* ':' 不需要校验*/

    /* 第四行只对文件整体校验结果前的数据进行校验，后面三个字节的数据不需要校验 */
    /* 第四行数据长度需要减去冒号和三个不需要校验的字节，其他行数据长度需要减去冒号所占字节 */
    ulLineDataSize = (ulLineNum == 4) ? (ucLineInfoSize - 4):(ucLineInfoSize - 1);

    return CalculateCRC16(usCrcSum, (const unsigned char *)pcLineData, ulLineDataSize);
}

static VOID BspSetPwrPkgSumChk(UINT32 index, UINT32 ulLineNum, UINT32 retSumChk)
{
    UINT32 indexPwr;
    indexPwr = s_PwrSubSubUnitNo[index];
    if (retSumChk != BSP_OK)
    {
        (void)s_RruPwrTplg.pwrPkgCrcChk[indexPwr];
        s_RruPwrTplg.pwrPkgCrcChk[indexPwr] |= PWR_SUM_CHK_FAIL_LINE(ulLineNum);
        if (ulLineNum <= 4)
        {
            s_RruPwrTplg.pwrPkgCrcChk[indexPwr] |= PWR_SUB_PKG_HEAD_SUM_CHK_FAIL;
        }
        else
        {
            s_RruPwrTplg.pwrPkgCrcChk[indexPwr] |= PWR_SUB_PKG_MCU_SUM_CHK_FAIL;
        }
    }
}

static UINT32 BspSubPkgJump(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen)
{
    UINT32 tmpIndex = 0;
    INPUT_INDEX_CHECK_PWR(ulSubIndex, SUB_PWR_MODULE_NUM);
    tmpIndex = s_PwrSubSubUnitNo[ulSubIndex];
    INPUT_INDEX_CHECK_PWR(tmpIndex, SUB_PWR_MODULE_NUM);
    dbgInfo("JUMP--Result Index  [%d]   SubNo[%d] \n", ulSubIndex, tmpIndex);
    pwrupdataLog("JUMP--Result Index  [%d]   SubNo[%d] \n", ulSubIndex, tmpIndex);
    dbgInfo("pwrUpdateFlag       [%d] \n", s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
    pwrupdataLog("pwrUpdateFlag       [%d] \n", s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
    dbgInfo("pwrForceUpdateFlag  [%d] \n", s_RruPwrTplg.pwrForceUpdateFlag[tmpIndex]);
    pwrupdataLog("pwrForceUpdateFlag  [%d] \n", s_RruPwrTplg.pwrForceUpdateFlag[tmpIndex]);
    dbgInfo("pwrPkgHeadChk       [%d] \n", s_RruPwrTplg.pwrPkgHeadChk);
    pwrupdataLog("pwrPkgHeadChk       [%d] \n", s_RruPwrTplg.pwrPkgHeadChk);
    dbgInfo("pwrPkgCrcChk        [%d] \n", s_RruPwrTplg.pwrPkgCrcChk[tmpIndex]);
    pwrupdataLog("pwrPkgCrcChk        [%d] \n", s_RruPwrTplg.pwrPkgCrcChk[tmpIndex]);

    /*电源模块不存在*/
    if (s_RruPwrTplg.pwrTopology[tmpIndex] == 0)
    {
        s_RruPwrTplg.pwrUpdateFlag[tmpIndex] = 0;
        dbgInfo("board doesn't have Index[%d] SubNo[%d] pwrUpdateFlag[%d]\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
        pwrupdataLog("board doesn't have Index[%d] SubNo[%d] pwrUpdateFlag[%d]\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
        return BSP_ERROR;
    }

    /*强制进行升级*/
    if (BspGetPwrForceUpdateFlag(tmpIndex) == 1)
    {
        s_RruPwrTplg.pwrUpdateFlag[tmpIndex] = 1;
        dbgInfo("Index[%d] SubNo[%d]  pwrUpdateFlag[%d]  force update\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
        pwrupdataLog("Index[%d] SubNo[%d]  pwrUpdateFlag[%d]  force update\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
        return BSP_OK;
    }

    /*CRC校验失败*/
    if (s_RruPwrTplg.pwrPkgCrcChk[tmpIndex] != 0)
    {
        dbgInfo("Index[%d] SubNo[%d]  pwrUpdateFlag[%d]  not need update,crc fail\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
        pwrupdataLog("Index[%d] SubNo[%d]  pwrUpdateFlag[%d]  not need update,crc fail\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
        return BSP_ERROR;
    }
    else
    {
        s_RruPwrTplg.pwrUpdateFlag[tmpIndex] = 1;
        dbgInfo("Index[%d] SubNo[%d]\n  pwrUpdateFlag[%d]  need update\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
        pwrupdataLog("Index[%d] SubNo[%d]\n  pwrUpdateFlag[%d]  need update\n", ulSubIndex, tmpIndex, s_RruPwrTplg.pwrUpdateFlag[tmpIndex]);
    }
    return BSP_OK;
}

// pPwrFile 文件索引指针　ulFileLen当前组件包长度
UINT32 BspSubPkgCrcChk(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen, CHAR **pulNextSubVerAddr)
{
    UINT32 ulLen = 0;
    INT32  lSurLen = 0; /*剩余文件长度*/
    UINT32 ulLineNum = 0;
    char  cbuf[MAX_VER_LINE_LEN + 2] = {0};
    char  cLineData[MAX_VER_LINE_LEN] = {0};
    UCHAR ucDateSize = 0;
    UCHAR ucLineInfoSize = 0;
    UCHAR ucRecType = 0;
    /*UINT32 ulAddr = 0;*/
    UINT32 ulAddrOffSet = 0;
    UINT32 ulRetVal = 0;
    CHAR* fp = NULL;
    /*UINT32 ulRet = 0;*/
    /*UCHAR cCnt = 0;*/
    UINT32 indexTest = 0;
    UINT32 retSumChk = BSP_OK;
    fp = pPwrFile;
    INPUT_POINTER_CHECK_PWR(fp);
    INPUT_POINTER_CHECK_PWR(pulNextSubVerAddr);

    dbgInfoEx("%s start! ulFileLen: %d\n",__FUNCTION__,ulFileLen);
    pwrupdataLog("%s start! ulFileLen: %d\n",__FUNCTION__,ulFileLen);
    lSurLen = (INT32)ulFileLen;
    /* CRC16校验的初值初始化 */
    s_usHeadCrcSum = 0;
    s_usMcuCrcSum  = 0;

    while(lSurLen > 6)
    {
        ulLen = mygetline(cbuf,MAX_VER_LINE_LEN,fp);
        PWR_SUBVER_LENTH_CHECK(ulLen);
        if(cbuf[0] != ':')
        {
            return BSP_ERROR;
        }

        fp = fp + ulLen;
        dbgInfoEx("%s--line info--%s\n", __FUNCTION__, cbuf);
        /*pwrupdataLog("%s--line info--%s\n", __FUNCTION__, cbuf);*/
        ucDateSize = BspHexToAsc(cbuf[1])*16 + BspHexToAsc(cbuf[2]);
        ucRecType = BspHexToAsc(cbuf[7])*16 + BspHexToAsc(cbuf[8]);

        lSurLen = lSurLen - ucDateSize - 7;/*头部加校验为6*/
        ucLineInfoSize = ucDateSize + 6; /*加头部和校验和长度5*/
        dbgInfoEx("%s %d lSurLen:%d %d ulLineNum:%d\n",__FUNCTION__,__LINE__,lSurLen,ucLineInfoSize,ulLineNum);
        /*pwrupdataLog("%s %d lSurLen:%d %d ulLineNum:%d\n",__FUNCTION__,__LINE__,lSurLen,ucLineInfoSize,ulLineNum);*/
        /*和校验结果*/
        retSumChk = BspSubVerCrcCheck(ucLineInfoSize,cbuf, cLineData);
        if((0xf0 == ucRecType)&&(ulLineNum <= 4))
        {
            ulRetVal = BspGetPwrVerInfoNew(ulSubIndex, (UCHAR *)(&cLineData[5]), ucDateSize, ulLineNum);
            BspSetPwrUpdateFlagNew(ulSubIndex, ulLineNum);
            dbgInfoEx("lineNum=[%04d]:",ulLineNum);
            /*pwrupdataLog("lineNum=[%04d]:",ulLineNum);*/
            for(indexTest=0;indexTest<ucLineInfoSize;indexTest++)
            {
                dbgInfoEx("%02X",cLineData[indexTest]);
            }
            dbgInfoEx("\n");
            BspSetPwrPkgSumChk(ulSubIndex, ulLineNum, retSumChk);
            s_usHeadCrcSum = BspPwrSubModuleCrcChk(ulLineNum,s_usHeadCrcSum,cLineData,ucLineInfoSize);/* 子组件头前三行+第四行文件整体校验结果前 */

            if(ulLineNum == 4) //大板电源组件信息0～4,此时组件信息crc校验结束
            {
                if (s_usHeadCrcSum != atPwrVerInfoNew[ulSubIndex].ulFileCheckSum)
                {
                    dbgInfo("HeadCrcSumErr: [0x%04x] {0x%04x}\n", s_usHeadCrcSum, atPwrVerInfoNew[ulSubIndex].ulFileCheckSum);
                    pwrupdataLog("HeadCrcSumErr: [0x%04x] {0x%04x}\n", s_usHeadCrcSum, atPwrVerInfoNew[ulSubIndex].ulFileCheckSum);
                    s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]] |= PWR_SUB_PKG_HEAD_CRC_CHK_FAIL;
                }
            }
        }
        else
        {
            dbgInfoEx("lineNum=[%04d]:",ulLineNum);
            /*pwrupdataLog("lineNum=[%04d]:",ulLineNum);*/
            for(indexTest=0;indexTest<ucLineInfoSize;indexTest++)
            {
                dbgInfoEx("%02X",cLineData[indexTest]);
            }
            dbgInfoEx("\n");
            s_usMcuCrcSum = BspPwrSubModuleCrcChk(ulLineNum,s_usMcuCrcSum,cLineData,ucLineInfoSize);/* 子组件MCU程序部分校验 */
            /* 校验结果判断 */
            if(lSurLen < 6)/*退出循环前，此时正常情况下lSurLen=0*/
            {

                dbgInfo("McuCrcSum: [0x%04x] {0x%04x}\n", s_usMcuCrcSum, atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
                pwrupdataLog("McuCrcSum: [0x%04x] {0x%04x}\n", s_usMcuCrcSum, atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
                if(atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum != s_usMcuCrcSum)
                {
                    s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]] |= PWR_SUB_PKG_MCU_CRC_CHK_FAIL;
                    dbgErr("McuCrcChkErr: [0x%04x] {0x%04x}\n", s_usMcuCrcSum, atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
                    pwrupdataLog("McuCrcChkErr: [0x%04x] {0x%04x}\n", s_usMcuCrcSum, atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
                }
            }
            ulAddrOffSet += ucLineInfoSize;
        }
        ulLineNum++;
    }

    if ((s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]] == 0) && \
        (s_RruPwrTplg.pwrTopology[s_PwrSubSubUnitNo[ulSubIndex]] == 1))//crc校验失败且该组建包实体存在（60Ｗ整机不存在48-02）
    {
        s_RruPwrTplg.pwrUpdateFlag[s_PwrSubSubUnitNo[ulSubIndex]] = 1;
    }

    *pulNextSubVerAddr = fp;
    pwrupdataLog("BspSubPkgCrcChk[%d], fp[%x], *pulNextSubVerAddr[%x]\n", ulRetVal, fp, *pulNextSubVerAddr);
    return ulRetVal;
}


/*****************************************************************************
 *  函数名称   : BspLoadPwrVerNew(*)
 *  功能描述   : 解析组件版本信息
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : ulSubIndex 组件版本打包序号
 *  返 回 值      : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2019-01-22 17:15:58, 创建
 *----------------------------------------------------------------------------
 */
UINT32  BspLoadPwrVerNew(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen)
{
    UINT32 ulLen = 0;
    INT32  lSurLen = 0;  /*剩余文件长度*/
    UINT32 ulLineNum = 0;
    char  cbuf[MAX_VER_LINE_LEN + 2] = {0};
    UCHAR  cLineData[MAX_VER_LINE_LEN] = {0};
    UCHAR ucDateSize = 0;
    UCHAR ucLineInfoSize = 0;
    UCHAR ucRecType = 0;
    UINT32 ulAddr = 0;
    UINT32 ulAddrOffSet = 0;
    UINT32 ulRetVal = 0;
    CHAR* fp = NULL;
    UINT32 ulRet = 0;
    /*UINT32 tmpIndex = 0;*/
    UINT32 indexTest=0;

    fp = pPwrFile;

    INPUT_POINTER_CHECK_PWR(fp);
    if (BSP_OK !=BspSubPkgJump(ulSubIndex, fp, ulFileLen))
    {
        pwrupdataLog("SubPkgJumpErr!\n");
        return BSP_ERROR;
    }
    dbgInfo("^_^ Index[%d] SubNo[%d] Start Write Eeprom\n", ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
    pwrupdataLog("^_^ Index[%d] SubNo[%d] Start Write Eeprom\n", ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
    dbgInfoEx("%s start! ulFileLen: %d\n",__FUNCTION__,ulFileLen);
    pwrupdataLog("%s start! ulFileLen: %d\n",__FUNCTION__,ulFileLen);
    lSurLen = (INT32)ulFileLen;
    dbgInfoEx("ulFileLen = %08x\n",ulFileLen);
    pwrupdataLog("ulFileLen = %08x\n",ulFileLen);

    while(lSurLen > 6)
    {
        ulLen = mygetline(cbuf,MAX_VER_LINE_LEN,fp);
        PWR_SUBVER_LENTH_CHECK(ulLen);
        if(cbuf[0] != ':')
        {
            return BSP_ERROR;
        }

        fp = fp + ulLen;
        dbgInfoEx("--line info--%s\n",cbuf);
        /*pwrupdataLog("--line info--%s\n",cbuf);*/
        ucDateSize = BspHexToAsc(cbuf[1])*16 + BspHexToAsc(cbuf[2]);
        ucRecType = BspHexToAsc(cbuf[7])*16 + BspHexToAsc(cbuf[8]);//ucRecType为0xF0说明这一行码流为文件头，否则这一行码流为MCU HEX

        lSurLen = lSurLen - ucDateSize - 7;/*头部加校验为6*/
        ucLineInfoSize = ucDateSize + 6; /*加头部和校验和长度5*/
        BspSubVerCrcCheck(ucLineInfoSize,cbuf, (CHAR *)cLineData);
        if(BspGetPwrEepromAddrNew(ulLineNum,ucRecType,&ulAddr) !=BSP_OK)
        {
            pwrupdataLog("GetPwrEepromAddrNewErr!\n");
            return BSP_ERROR;
        }
        dbgInfoEx("E");
        /*写eeprom */
        if(0xf0 == ucRecType)
        {
            ulRet |= BspWriteLineInfoToEepromNew(ulAddr,&cLineData[0],ucLineInfoSize);
            dbgInfoEx("--lineNum=[%04d]:",ulLineNum);
            /*pwrupdataLog("--lineNum=[%04d]:",ulLineNum);*/
            for(indexTest=0;indexTest<ucLineInfoSize;indexTest++)
            {
                dbgInfoEx("%02X",cLineData[indexTest]);
            }
            dbgInfoEx("\n");
        }
        else
        {
                ulRet |= BspWriteLineInfoToEepromNew(ulAddr+ulAddrOffSet,&cLineData[0],ucLineInfoSize);
                dbgInfoEx("--lineNum=[%04d]:",ulLineNum);
                /*pwrupdataLog("--lineNum=[%04d]:",ulLineNum);*/
                for(indexTest=0;indexTest<ucLineInfoSize;indexTest++)
                {
                    dbgInfoEx("%02X",cLineData[indexTest]);
                }
                dbgInfoEx("\n");
            ulAddrOffSet += ucLineInfoSize;
        }
        dbgInfoEx("--pkg info-- ulFileLen:%d ucLineInfoSize:%d lSurLen:%d ulLineNum:%d\n",ulFileLen,ucLineInfoSize,lSurLen,ulLineNum);
        /*pwrupdataLog("--pkg info-- ulFileLen:%d ucLineInfoSize:%d lSurLen:%d ulLineNum:%d\n",ulFileLen,ucLineInfoSize,lSurLen,ulLineNum);*/
        if(BSP_OK != ulRet)
        {
            dbgErr("%s %d write error !\n",__FUNCTION__,__LINE__);
            pwrupdataLog("%s %d write error !\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
        ulLineNum++;
    }
    dbgInfoEx("End line=[%04d]\n",ulLineNum);
    pwrupdataLog("End line=[%04d]\n",ulLineNum);
    dbgInfo("\n^_^ Index[%d] SubNo[%d] End Write Eeprom\n", ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
    pwrupdataLog("\n^_^ Index[%d] SubNo[%d] End Write Eeprom\n", ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspPrnPwrPkgHeadInfo(*)
 *  功能描述   : 打印升级包头部信息
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : 无
 *  返 回 值   : BSP_OK
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2021-04-10 11:21:00, 创建
 *----------------------------------------------------------------------------
 */
UINT32  BspPrnPwrPkgHeadInfo(VOID)
{
    UINT32 i = 0;
    dbgInfo("PkgHeadLen=%d\t\t SubPkgNum=%d\n",tPwrVerPkg.ulPkgHeadLen,tPwrVerPkg.usVerNum);
    for (i = 0; i< tPwrVerPkg.usVerNum; i++)
    {
        dbgInfo("subPkgLen[%d]\t\t %d\n", i, tPwrVerPkg.ulPkgLen[i]);
    }
    return BSP_OK;
}
/**************************************************************************
* 函数名称: BspPwrPkgLoadNew
* 功能描述: 电源版本加载函数
* 输入参数:
* 输出参数: 无
* 返 回 值   : RRUID
* 其它说明:
* 修改日期  版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019-01-02        V1.0           贾路漫    创建
**************************************************************************/
UINT32  BspPwrPkgLoadNew(UCHAR* pucLogicDataBuf, INT32 ulBufLen)
{
    T_Pwr_VerPkg_Pwr   *pPwrPkgVer = NULL;   /*组件包 头*/
    CHAR* ucHead           = NULL;
    UINT32 ulLp             = 0;
    UINT32 ulSubIndex       = 0;
    UINT32 ulResult         = 0;
    CHAR *ulNextSubVerAddr = NULL;
    UINT32 ulLoop           = 0;

    INPUT_POINTER_CHECK(pucLogicDataBuf);
    if(0 != semTake(semPowUpdate, WAIT_FOREVER))
    {
        dbgErr("%s semTake error\n",__FUNCTION__);
        pwrupdataLog("%s semTake error\n",__FUNCTION__);
        return PWR_GET_SEM_ERROR;
    }
    /*文件头获取以及校验*/
    dbgInfo("=====STEP3.1:CHK_PKG pwr_pkg_hear_chk start=====\n");
    pwrupdataLog("=====STEP3.1:CHK_PKG pwr_pkg_hear_chk start=====\n");
    pPwrPkgVer = (T_Pwr_VerPkg_Pwr *)((UCHAR*)(pucLogicDataBuf+sizeof(T_VerFileHeader_Pwr)));
    tPwrVerPkg.ulPkgHeadLen = BspASCIIToULONG((CHAR*)pPwrPkgVer);
    tPwrVerPkg.usVerNum  = BspASCIIToUSHORT((CHAR*)pPwrPkgVer+8);
    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {
        tPwrVerPkg.ulPkgLen[ulSubIndex] = BspASCIIToULONG((CHAR*)pPwrPkgVer+8*ulSubIndex+12);
    }
    tPwrVerPkg.usCrcSum = BspASCIIToUSHORT((CHAR*)pPwrPkgVer+8*(tPwrVerPkg.usVerNum)+12);
    BspPrnPwrPkgHeadInfo();
    if (PwrHeadDataCheck(tPwrVerPkg.ulPkgHeadLen,(CHAR*)pPwrPkgVer)!= BSP_OK)
    {
        semGive(semPowUpdate);
        s_RruPwrTplg.pwrPkgHeadChk = 1;
        pwrupdataLog("CHK_PKG pwr_pkg_hear_chk fail\n");
        return BSP_ERROR;
    }

    ucHead = (CHAR*)pPwrPkgVer + tPwrVerPkg.ulPkgHeadLen*2;
    dbgInfo("PwrPkgHead = %p\n",ucHead);
    pwrupdataLog("PwrPkgHead = %p\n",ucHead);
    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {
        for(ulLp = 0; ulLp < 3; ulLp++) /*给电源eeprom写升级文件，最多写3次*/
        {
            dbgInfo("=====STEP3.2: CHK_SUB_PKG[%d] WR_E2PROM start=====\n", ulSubIndex);
            pwrupdataLog("=====STEP3.2: CHK_SUB_PKG[%d] WR_E2PROM start=====\n", ulSubIndex);
            (void)BspSubPkgCrcChk(ulSubIndex,ucHead, tPwrVerPkg.ulPkgLen[ulSubIndex], &ulNextSubVerAddr);
            ulResult = BspLoadPwrVerNew(ulSubIndex,ucHead,tPwrVerPkg.ulPkgLen[ulSubIndex]);
            dbgInfoEx("ucHead = %p, ulNextSubVerAddr = %p \n", ucHead,ulNextSubVerAddr);
            pwrupdataLog("ucHead = %p, ulNextSubVerAddr = %p \n",ucHead,ulNextSubVerAddr);
            /*校验通过，写入成功 或者校验失败 提前退出*/
            if (BSP_OK == ulResult)
            {
                dbgInfoEx("Index:[%d] SubNo:[%d] write pwr eeprom succ! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
                pwrupdataLog("Index:[%d] SubNo:[%d] write pwr eeprom succ! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
                break;
            }
            else
            {
                if (s_RruPwrTplg.pwrUpdateFlag[s_PwrSubSubUnitNo[ulSubIndex]] == 0)
                {
                    break;
                }
            }
        }

        ucHead = ulNextSubVerAddr;
        if (BSP_OK != ulResult)
        {
            if (ulSubIndex == tPwrVerPkg.usVerNum - 1)
            {
                semGive(semPowUpdate);
                return BSP_ERROR;
            }
            continue;
        }
        dbgInfo("ucHead = %p tPwrVerPkg.ulPkgLen[%d] = 0x%x \n",ucHead,ulSubIndex,tPwrVerPkg.ulPkgLen[ulSubIndex]);
        pwrupdataLog("ucHead = 0x%x tPwrVerPkg.ulPkgLen[%d] = 0x%x \n",ucHead,ulSubIndex,tPwrVerPkg.ulPkgLen[ulSubIndex]);
        dbgInfo("=====STEP3.3:TRIG_UPDATE[%d] =====\n", ulSubIndex);
        pwrupdataLog("=====STEP3.3:TRIG_UPDATE[%d] =====\n", ulSubIndex);

        for(ulLoop = 0; ulLoop < POWER_UPDATE_ATTEMPTS_TIMES; ulLoop++)
        {
            /* 给电源模块发起升级操作,尝试3次 */
            if(BSP_OK == _BspUpdatePowerModuleNew(ulSubIndex))
            {
                dbgInfo("func:%s, ulSubIndex:%d, updata success! times:%d!\n",__FUNCTION__,ulSubIndex,ulLoop+1);
                pwrupdataLog("func%s:ulSubIndex:%d, updata success! times:%d!\n",__FUNCTION__,ulSubIndex,ulLoop+1);
                break;
            }
            dbgInfo("func:%s, ulSubIndex:%d, updata failed! times:%d\n",__FUNCTION__,ulSubIndex,ulLoop+1);
            pwrupdataLog("func:%s:ulSubIndex:%d, updata failed! times:%d!\n",__FUNCTION__,ulSubIndex,ulLoop+1);
        }
        /* 3次都失败就退出升级 */
        if(POWER_UPDATE_ATTEMPTS_TIMES == ulLoop)
        {
            semGive(semPowUpdate);
            return BSP_ERROR;
        }
    }

    semGive(semPowUpdate);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称 : PwrUpdateTestNew(*)
*  功能描述 : 大板电源升级测试
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数 :
*  输出参数 : 无
*  返 回 值 : 错误码
*  其它说明 : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),                 贾路漫 @2020-09-18
*----------------------------------------------------------------------------
*/
UINT32 PwrVerUpdateTestNew(VOID)
{
    UCHAR   *pucBuffer = NULL;
    struct  stat tStatInfo;
    INT32    lVerLen = 0;
    UINT32   ulRetVal = BSP_OK;
    FILE    *fp = NULL;
    int fclsRet;
    BspGetPwrTplg();
    BspCleanPwrCrcChkResult();

    dbgInfo("=====STRAT PWR UPDATE =====\n");
    pwrupdataLog("=====STRAT PWR UPDATE =====\n");
    INPUT_POINTER_CHECK(pwrVerPath);

    if((fopen_s(&fp,pwrVerPath, "rb")) != 0)
    {
        dbgErr("%s: open %s failed!\n",__FUNCTION__,pwrVerPath);
        pwrupdataLog("%s: open %s failed!\n",__FUNCTION__,pwrVerPath);
        if(fp != NULL)
        {
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);
        }
        return BSP_ERROR;
    }

    if(fp == NULL)
    {
        dbgErr("%s: open %s failed!\n",__FUNCTION__,pwrVerPath);
        pwrupdataLog("%s: open %s failed!\n",__FUNCTION__,pwrVerPath);
        return BSP_ERROR;
    }

    /* 获得电源版本文件大小 */
    if (stat(pwrVerPath, &tStatInfo) != 0)
    {
        dbgErr("/pwrupdate/pwr.swv not Exist!\n" );
        pwrupdataLog("/pwrupdate/pwr.swv not Exist!\n" );
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    lVerLen = tStatInfo.st_size;
    if (lVerLen <= 0)
    {
        dbgErr("File Length ERROR! error code: %s\n", zte_strerror_s(errno));
        pwrupdataLog("File Length ERROR! error code: %s\n", zte_strerror_s(errno));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    dbgInfoEx("pwr file length :%d\n", lVerLen);
    pwrupdataLog("pwr file length :%d\n", lVerLen);

    if (NULL == (pucBuffer = (UCHAR *)malloc(lVerLen)))
    {
        dbgErr("Fail to get memory! error code: %s\n", zte_strerror_s(errno));
        pwrupdataLog("Fail to get memory! error code: %s\n", zte_strerror_s(errno));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    /* 将电源文件装载到RAM中 */
    dbgInfo("=====STEP2:LOAD FILE TO MEMORY =====\n");
    pwrupdataLog("=====STEP2:LOAD FILE TO MEMORY =====\n");
    ulRetVal = fread(pucBuffer, 1, lVerLen, fp);
    if (ulRetVal != lVerLen)
    {
        dbgErr("Pwr file read Error");
        pwrupdataLog("Pwr file read Error");
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    /*升级前进行初始化，创建信号量*/
    if (BSP_OK !=BspPwrUpdateInit())
    {
        dbgErr("%s  error\n",__FUNCTION__);
        pwrupdataLog("%s  error\n",__FUNCTION__);
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    /*开始进行版本包校验以及写入EEPROM并发起升级*/
    dbgInfo("=====STEP3:CHK_PKG  WR_E2PROM  TRIG_UPDATE =====\n");
    pwrupdataLog("=====STEP3:CHK_PKG  WR_E2PROM  TRIG_UPDATE =====\n");
    ulRetVal = BspPwrPkgLoadNew(pucBuffer, lVerLen);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("pwr update test fail \n");
        pwrupdataLog("pwr update test fail \n");
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    dbgInfo("======pwr updata success======\n");
    pwrupdataLog("======pwr updata success======\n");
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);
    free(pucBuffer);
    return ulRetVal;
}

UINT32 PwrUpdateTestNew(VOID)
{
    UINT32 ulRetVal = BSP_OK;
    PwrUpdateLogInit();          /*升级前打开log记录*/
    ulRetVal = PwrVerUpdateTestNew();
    PwrUpdateLogClose();         /*升级后需要释放*/
    return ulRetVal;
}
//BspErasePwrFlash

/*****************************************************************************
 *  函数名称   : BspErasePwrModuleFlash(*)
 *  功能描述   : 大板电源直升触发擦除flash操作　D2 AB  CD
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : BSP_OK成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspErasePwrModuleFlash(UINT32 subIndex)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrDevId(subIndex);
    //coverity[cert_dcl60_cpp_violation:SUPPRESS]
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_cpp_violation:SUPPRESS]
    ulRetVal = BspErasePwrFlash(ulPwrDevId);

    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspActPwrVerDirect(*)
 *  功能描述   : 大板电源直升触发升级　D6 AB  CD
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : BSP_OK成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspActPwrUpdateDirect(UINT32 subIndex)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrDevId(subIndex);
    ulRetVal = BspSetPwrUpdate(ulPwrDevId);

    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspExitPwrUpdateDirect(*)
 *  功能描述   : 大板电源直升退出升级模式　D6 00  00
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : BSP_OK　退出成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspExitPwrUpdateDirect(UINT32 subIndex)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrDevId(subIndex);
    //coverity[cert_dcl60_cpp_violation:SUPPRESS]
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_cpp_violation:SUPPRESS]
    ulRetVal = BspQuitPwrUpdate(ulPwrDevId);

    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspGetPwrUpdateStatusDirect(*)
 *  功能描述   : 获取大板电源所处模式　D6
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : 升级模式UPDATE_MODE　　　正常模式　UPDATE_DONE
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */

UINT32 BspGetPwrUpdateStatusDirect(UINT32 subIndex)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;

    ulPwrDevId = BspGetPwrDevId(subIndex);
    ulRetVal = BspGetPwrUpdateStatus(ulPwrDevId);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspActPwrVerDirect(*)
 *  功能描述   : 设置大板电源模式（升级模式　或者　正常模式）
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  输入参数   :ulModule  升级模式UPDATE_MODE = 0　　　正常模式　UPDATE_DONE = 1
 *  返 回 值      : BSP_OK成功
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPwrUpdateMode(UINT32 subIndex, UINT32 ulModule)
{
    UINT32 ret = BSP_OK;
    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    UINT32 pwrSubIndex = atPwrVerInfoNew[subIndex].ucSubUnitNo;
    /*边界判断*/
    dbgInfo("%s: SubIndex[%d],PwrIndex[%d]  \n",  __FUNCTION__, subIndex, pwrSubIndex);
    if (ulModule == UPDATE_MODE)
    {
        ret = BspActPwrUpdateDirect(pwrSubIndex);
        dbgInfo("%s: SubIndex[%d],PwrIndex[%d] ==Trigger== Update==\n",  __FUNCTION__, subIndex, pwrSubIndex);
    }
    else
    {
        ret = BspExitPwrUpdateDirect(pwrSubIndex);
        dbgInfo("%s: SubIndex[%d],PwrIndex[%d] ==Exit== Update==\n",  __FUNCTION__, subIndex, pwrSubIndex);
    }

    return ret;
}

/*****************************************************************************
 *  函数名称   : BspWritePwrUpdateLineAddr(*)
 *  功能描述   :写行地址信息　D9
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : 升级模式UPDATE_MODE　　　正常模式　UPDATE_DONE
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspWritePwrUpdateLineAddr(UINT32 subIndex, UCHAR *pucVal,UINT32 ulByteNum)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;
    ulPwrDevId = BspGetPwrDevId(subIndex);
    //coverity[cert_dcl60_cpp_violation:SUPPRESS]
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_cpp_violation:SUPPRESS]
    ulRetVal = BspSetPwrUpdateLineAddr(ulPwrDevId, pucVal, ulByteNum);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspReadPwrUpdateLineAddr(*)
 *  功能描述   :读行地址信息　D9
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : 升级模式UPDATE_MODE　　　正常模式　UPDATE_DONE
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspReadPwrUpdateLineAddr(UINT32 subIndex, UCHAR *pucVal,UINT32 ulByteNum)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;
    ulPwrDevId = BspGetPwrDevId(subIndex);
    //coverity[cert_dcl60_cpp_violation:SUPPRESS]
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_cpp_violation:SUPPRESS]
    ulRetVal = BspGetPwrUpdateLineAddr(ulPwrDevId, pucVal, ulByteNum);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspWritePwrUpdateLineData(*)
 *  功能描述   :写行地址信息　DB
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : 升级模式UPDATE_MODE　　　正常模式　UPDATE_DONE
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspWritePwrUpdateLineData(UINT32 subIndex, UCHAR *pucVal,UINT32 ulByteNum)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;
    ulPwrDevId = BspGetPwrDevId(subIndex);
    //coverity[cert_dcl60_cpp_violation:SUPPRESS]
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_cpp_violation:SUPPRESS]
    ulRetVal = BspSetPwrUpdateLineData(ulPwrDevId, pucVal, ulByteNum);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspReadPwrUpdateLineData(*)
 *  功能描述   :写行地址信息  DB
 *  输入参数   :0---MCU  1----48v#1  2----48V#2    3----12V#1
 *  返 回 值      : 升级模式UPDATE_MODE　　　正常模式　UPDATE_DONE
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期,          操作说明)
 *  $0000000(N/A),    贾路漫 @2022-01-01
 *----------------------------------------------------------------------------
 */
UINT32 BspReadPwrUpdateLineData(UINT32 subIndex, UCHAR *pucVal,UINT32 ulByteNum)
{
    UINT32 ulPwrDevId = 0;
    UINT32 ulRetVal = 0;
    ulPwrDevId = BspGetPwrDevId(subIndex);
    //coverity[cert_dcl60_cpp_violation:SUPPRESS]
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_cpp_violation:SUPPRESS]
    ulRetVal = BspGetPwrUpdateLineData(ulPwrDevId, pucVal, ulByteNum);
    return ulRetVal;
}


/**************************************************************************
* 函数名称: BspLoadPwrAddrDirect*)
* 功能描述: 直升电源版本子组件版本写入行地址
* 输入参数:ulSubIndex 组件版本打包序号
* 输出参数: 无
* 返 回 值   : BSP_OK
* 其它说明:Start-add(w)- 0xD9-addr0-addr1--PEC-Stop
* 修改日期  版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2022-01-02        V1.0           贾路漫    创建
**************************************************************************/



/*
 *          :        10　        0010　            00　           AD020208  AD020208  AD020208  00000000             B5     '\0'
 *  byte0     byte1      2~3(Addr)      4 (Type)             5~20(16byte)                                                                 21       22
 */
static UINT32 BspGetLineInfo(CHAR* pAllLineData, CHAR* pLineAddr, CHAR* pLineData, UINT32 lineDataSize,UINT32 allLineDataSize)
{
    UINT32 index = 0;
    INPUT_POINTER_CHECK_PWR(pAllLineData);
    INPUT_POINTER_CHECK_PWR(pLineAddr);
    INPUT_POINTER_CHECK_PWR(pLineData);
    //UINT8 blockNum = 0;
    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    if ((pAllLineData[0] != ':') || (pAllLineData[allLineDataSize] != '\0'))
    {
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        //coverity[cert_str34_c_violation:SUPPRESS]
        //coverity[cert_str34_c_violation:SUPPRESS]
        dbgInfoEx("Line data err!!!  data[0] = [%d]  data [%d] = [%d]\n", pAllLineData[0], allLineDataSize, pAllLineData[allLineDataSize]);
        return BSP_ERROR;
    }
    //blockNum = pAllLineData[1];
    pLineAddr[0] = pAllLineData[2];
    pLineAddr[1] = pAllLineData[3];
    //coverity[cert_str34_c_violation:SUPPRESS]
    //coverity[cert_str34_c_violation:SUPPRESS]
    dbgInfoEx("LineAddr =[0X%02X%02X] \n", pLineAddr[0], pLineAddr[1]);
    //pLineData[0] = blockNum;
    pLineData[0] = pAllLineData[1];

    for (index =0; index < lineDataSize; index++)
    {
        pLineData[1 + index] = pAllLineData[5 + index];
    }
    dbgInfoEx("LineData =[0X");
    for (index =0; index < lineDataSize+1; index++)
    {
        //coverity[cert_str34_c_violation:SUPPRESS]
        dbgInfoEx("%02X", pLineData[index]);
    }
    dbgInfoEx("]\n");
    return BSP_OK;
}


/*消除复杂度接口*/
static VOID BspPrnLinefoDebug(UINT32 dbgErrType, CHAR* pLineInfo, CHAR* pLineInfoTemp, UINT32 bufLen)
{
    UINT32 indexTest1;
    /*打印行地址写入回读不一致时读写buf内容*/
    if (dbgErrType == PWR_LINE_ADDR_ERR_DBG)
    {
        dbgInfo("\nLineAddrWrite  Failed==========================================\n");
        dbgInfo("    lineAddr=[0X:");
        for (indexTest1 = 0; indexTest1 < bufLen; indexTest1++)
        {
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfo("%02X", pLineInfo[indexTest1]);
        }

        dbgInfo("\nlineAddrTemp=[0X");
        for (indexTest1 = 0; indexTest1 < bufLen; indexTest1++)
        {
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfo("%02X", pLineInfoTemp[indexTest1]);
        }
        dbgInfo("\nLineAddrWrite  Failed==========================================\n");
    }
    /*打印行数据写入回读不一致时读写buf内容*/
    else if (dbgErrType == PWR_LINE_DATA_ERR_DBG)
    {
        dbgInfo("\nLineDataWrite  Failed==========================================\n");
        dbgInfo("    lineData=[0X:");
        for (indexTest1 = 0; indexTest1 < bufLen; indexTest1++)
        {
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfo("%02X", pLineInfo[indexTest1]);
        }

        dbgInfo("\nlineDataTemp=[0X");
        for (indexTest1 = 0; indexTest1 < bufLen; indexTest1++)
        {
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfo("%02X", pLineInfoTemp[indexTest1]);
        }
        dbgInfo("\nLineDataWrite  Failed==========================================\n");
    }
    /*打印行信息写入回读不一致时读写buf内容*/
    else
    {
        dbgInfo("\nLineInfoWrite  Failed==========================================\n");
        dbgInfo("    lineInfo=[0X:");
        for (indexTest1 = 0; indexTest1 < bufLen; indexTest1++)
        {
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfo("%02X", pLineInfo[indexTest1]);
        }

        dbgInfo("\nlineInfoTemp=[0X");
        for (indexTest1 = 0; indexTest1 < bufLen; indexTest1++)
        {
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfo("%02X", pLineInfoTemp[indexTest1]);
        }
        dbgInfo("\nLineInfoWrite  Failed==========================================\n");
    }
}






/**************************************************************************
* 函数名称: BspLoadPwrVerDirect*)
* 功能描述: 直升电源版本子组件版本写入Flash
* 输入参数:ulSubIndex 组件版本打包序号
* 输出参数: 无
* 返 回 值   : BSP_OK
* 其它说明:pPwrFile 文件索引指针　ulFileLen当前组件包长度
* 修改日期  版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2022-01-02        V1.0           贾路漫    创建
**************************************************************************/
UINT32  BspLoadPwrVerDirect(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen)
{
    UINT32 ulLen = 0;
    INT32  lSurLen = 0;  /*剩余文件长度*/
    UINT32 ulLineNum = 0;
    char  cbuf[MAX_VER_LINE_LEN + 2] = {0};
    char  cLineData[MAX_VER_LINE_LEN] = {0};

    CHAR  lineAddr[2] = {0x00, 0x00};
    CHAR  lineAddrTemp[2] = {0x00, 0x00};
    char lineData[MAX_VER_LINE_LEN] = {0};
    char lineDataTemp[MAX_VER_LINE_LEN] = {0};
    UCHAR ucDateSize = 0;
    UCHAR ucLineInfoSize = 0;
    UCHAR ucRecType = 0;
    /*UINT32 ulAddr = 0;*/
    UINT32 ulAddrOffSet = 0;
    UINT32 ulRetVal = 0;
    CHAR* fp = NULL;
    UINT32 ulRet = 0;
    UINT32 ulRetTmp = 0;
    UINT32 tmpIndex = 0;
    UINT32 indexTest=0;
    /*UINT32 indexTest1 = 0;*/

    fp = pPwrFile;

    INPUT_POINTER_CHECK_PWR(fp);

    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    dbgInfo("^_^ Index[%d] SubNo[%d] Start Write Eeprom\n", ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
    dbgInfoEx("%s start! ulFileLen: %d\n",__FUNCTION__,ulFileLen);
    //coverity[cert_int31_c_violation:SUPPRESS]
    lSurLen = (INT32)ulFileLen;
    dbgInfoEx("ulFileLen = %08x\n",ulFileLen);

    while(lSurLen > 6)
    {
        ulLen = mygetline(cbuf,MAX_VER_LINE_LEN,fp);
        PWR_SUBVER_LENTH_CHECK(ulLen);
        if(cbuf[0] != ':')
        {
            return BSP_ERROR;
        }

        fp = fp + ulLen;
        dbgInfoEx("--line info--%s\n",cbuf);
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        ucDateSize = BspHexToAsc(cbuf[1])*16 + BspHexToAsc(cbuf[2]);
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        ucRecType = BspHexToAsc(cbuf[7])*16 + BspHexToAsc(cbuf[8]);//ucRecType为0xF0说明这一行码流为文件头，否则这一行码流为MCU HEX


        lSurLen = lSurLen - ucDateSize - 7;/*头部加校验为6*/
        //coverity[cert_int31_c_violation:SUPPRESS]
        ucLineInfoSize = ucDateSize + 6; /*加头部和校验和长度5*/
        BspSubVerCrcCheck(ucLineInfoSize,cbuf, cLineData);

        /*拆解行地址以及行数据*/
        //coverity[cert_exp37_c_violation:SUPPRESS]
        if (BspGetLineInfo(cLineData, lineAddr, lineData, ucDateSize, ucLineInfoSize) != BSP_OK)
        {
            dbgInfo("line  data  analyse failed\n");
            return BSP_ERROR;
        }


        /*写Flash*/
        if (ucRecType != 0xf0)
        {
                /*写行地址尝试3次后面加*/
            for(tmpIndex =0; tmpIndex < PWR_LINE_ADDR_RW_TRY_TIMES; tmpIndex++)
            {
                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                ulRetTmp = BspWritePwrUpdateLineAddr(s_PwrSubSubUnitNo[ulSubIndex], (UCHAR *)lineAddr, PWR_LINE_ADDR_LENTH);
                BspSysMsDelay(2);/*2ms*/
                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                ulRetTmp |= BspReadPwrUpdateLineAddr(s_PwrSubSubUnitNo[ulSubIndex], (UCHAR *)lineAddrTemp, PWR_LINE_ADDR_LENTH);

                //coverity[cert_int31_c_violation:SUPPRESS]
               if ( memcmp(lineAddr,  lineAddrTemp, PWR_LINE_ADDR_LENTH) != BSP_OK)
               {
                   //coverity[cert_exp37_c_violation:SUPPRESS]
                   BspPrnLinefoDebug(PWR_LINE_ADDR_ERR_DBG, lineAddr, lineAddr, PWR_LINE_ADDR_LENTH);
                    memset_s(lineAddrTemp, PWR_LINE_ADDR_LENTH, LINE_ADDR_BUF_DEFAULT_VALUE, PWR_LINE_ADDR_LENTH);/*清除回读addr buf*/
                   if (tmpIndex == (PWR_LINE_ADDR_RW_TRY_TIMES - 1))
                   return BSP_ERROR;
               }
               else
               {
                   memset_s(lineAddrTemp, PWR_LINE_ADDR_LENTH, LINE_ADDR_BUF_DEFAULT_VALUE, PWR_LINE_ADDR_LENTH);
                   dbgInfo("*");
                   dbgInfoEx("LineAddrWrite  OK\n");
                   break;
               }

            }
            ulRet = ulRetTmp;

                /*写行数据  尝试3次后面加*/
            for(tmpIndex =0; tmpIndex < PWR_LINE_DATA_RW_TRY_TIMES; tmpIndex++)
            {
                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                //coverity[cert_exp37_c_violation:SUPPRESS]
                ulRetTmp = BspWritePwrUpdateLineData(s_PwrSubSubUnitNo[ulSubIndex], (UCHAR *)lineData, ucDateSize +1);
                BspSysMsDelay(20);/*10ms*/
                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                //coverity[cert_exp37_c_violation:SUPPRESS]
                ulRetTmp |= BspReadPwrUpdateLineData(s_PwrSubSubUnitNo[ulSubIndex], (UCHAR *)lineDataTemp, ucDateSize +1);

                //coverity[cert_int31_c_violation:SUPPRESS]
                if ( memcmp(lineData+1,  lineDataTemp+1, ucDateSize) != BSP_OK)
                {
                    //coverity[cert_exp37_c_violation:SUPPRESS]
                    BspPrnLinefoDebug(PWR_LINE_DATA_ERR_DBG, lineAddr, lineAddr, ucDateSize +1);
                    memset_s(lineDataTemp, ucDateSize +1, LINE_DATA_BUF_DEFAULT_VALUE, ucDateSize +1);/*清除接受到的数据*/

                    if (tmpIndex == (PWR_LINE_DATA_RW_TRY_TIMES - 1))
                    return BSP_ERROR;
                }
                else
                {
                    memset_s(lineDataTemp,  ucDateSize +1, LINE_DATA_BUF_DEFAULT_VALUE, ucDateSize +1);/*清除接受到的数据*/
                    dbgInfo("=");
                    dbgInfoEx("LineDataWrite  Ok\n");
                }
            }
            ulRet |= ulRetTmp;

            dbgInfoEx("--lineNum=[%04d]:",ulLineNum);
            for(indexTest=0;indexTest<ucLineInfoSize;indexTest++)
            {
                //coverity[cert_str34_c_violation:SUPPRESS]
                dbgInfoEx("%02X",cLineData[indexTest]);
            }
            dbgInfoEx("\n");
            ulAddrOffSet += ucLineInfoSize;
        }
        dbgInfoEx("--pkg info-- ulFileLen:%d ucLineInfoSize:%d lSurLen:%d ulLineNum:%d\n",ulFileLen,ucLineInfoSize,lSurLen,ulLineNum);
        if(BSP_OK != ulRet)
        {
            dbgErr("%s LINE=[%d] pwr flash write error !\n",__FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
        ulLineNum++;
    }
    dbgInfoEx("End line=[%04d]\n",ulLineNum);
    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    dbgInfo("\n^_^ Index[%d] SubNo[%d] End Write Flash\n", ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
    return ulRetVal;
}


/**************************************************************************
* 函数名称: BspSubPkgCrcChkDirect
* 功能描述: 直升电源版本子组件校验
* 输入参数:
* 输出参数: 无
* 返 回 值   : RRUID
* 其它说明:pPwrFile 文件索引指针　ulFileLen当前组件包长度
* 修改日期  版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2022-01-02        V1.0           贾路漫    创建
**************************************************************************/
UINT32 BspSubPkgCrcChkDirect(UINT32 ulSubIndex,CHAR* pPwrFile,UINT32 ulFileLen, UINT32* pulNextSubVerAddr)
{
    UINT32 ulLen = 0;
    INT32  lSurLen = 0; /*剩余文件长度*/
    UINT32 ulLineNum = 0;
    char  cbuf[MAX_VER_LINE_LEN + 2] = {0};
    char  cLineData[MAX_VER_LINE_LEN] = {0};
    UCHAR ucDateSize = 0;
    UCHAR ucLineInfoSize = 0;
    UCHAR ucRecType = 0;
    /*UINT32 ulAddr = 0;*/
    UINT32 ulAddrOffSet = 0;
    UINT32 ulRetVal = 0;
    CHAR* fp = NULL;
    /*UINT32 ulRet = 0;*/
    /*UCHAR cCnt = 0;*/
    UINT32 indexTest = 0;
    UINT32 retSumChk = BSP_OK;
    fp = pPwrFile;
    INPUT_POINTER_CHECK_PWR(fp);

    dbgInfoEx("%s start! ulFileLen: %d\n",__FUNCTION__,ulFileLen);
    //coverity[cert_int31_c_violation:SUPPRESS]
    lSurLen = (INT32)ulFileLen;
    /* CRC16校验的初值初始化 */
    s_usHeadCrcSum = 0;
    s_usMcuCrcSum  = 0;

    while(lSurLen > 6)
    {
        ulLen = mygetline(cbuf,MAX_VER_LINE_LEN,fp);
        PWR_SUBVER_LENTH_CHECK(ulLen);
        if(cbuf[0] != ':')
        {
            return BSP_ERROR;
        }

        fp = fp + ulLen;
        dbgInfoEx("%s--line info--%s\n", __FUNCTION__, cbuf);
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        ucDateSize = BspHexToAsc(cbuf[1])*16 + BspHexToAsc(cbuf[2]);
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]
        ucRecType = BspHexToAsc(cbuf[7])*16 + BspHexToAsc(cbuf[8]);

        lSurLen = lSurLen - ucDateSize - 7;/*头部加校验为6*/
        //coverity[cert_int31_c_violation:SUPPRESS]
        ucLineInfoSize = ucDateSize + 6; /*加头部和校验和长度5*/
        dbgInfoEx("%s %d lSurLen:%d %d ulLineNum:%d\n",__FUNCTION__,__LINE__,lSurLen,ucLineInfoSize,ulLineNum);
        /*和校验结果*/
        retSumChk = BspSubVerCrcCheck(ucLineInfoSize,cbuf, cLineData);
        if((0xf0 == ucRecType)&&(ulLineNum <= 4))
        {
            //coverity[cert_exp37_c_violation:SUPPRESS]
            ulRetVal = BspGetPwrVerInfoNew(ulSubIndex, (UCHAR *)(&cLineData[5]), ucDateSize, ulLineNum);
            ulRetVal |=BspSetPwrUpdateFlagNew(ulSubIndex, ulLineNum);
            dbgInfoEx("lineNum=[%04d]:",ulLineNum);
            for(indexTest=0;indexTest<ucLineInfoSize;indexTest++)
            {
                //coverity[cert_str34_c_violation:SUPPRESS]
                dbgInfoEx("%02X",cLineData[indexTest]);
            }
            dbgInfoEx("\n");
            BspSetPwrPkgSumChk(ulSubIndex, ulLineNum, retSumChk);
            s_usHeadCrcSum = BspPwrSubModuleCrcChk(ulLineNum,s_usHeadCrcSum,cLineData,ucLineInfoSize);/* 子组件头前三行+第四行文件整体校验结果前 */

            if(ulLineNum == 4) //大板电源组件信息0～4,此时组件信息crc校验结束
            {
                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                if (s_usHeadCrcSum != atPwrVerInfoNew[ulSubIndex].ulFileCheckSum)
                {
                    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                    dbgInfo("HeadCrcSumErr: [0x%04x] {0x%04x}\n", s_usHeadCrcSum, atPwrVerInfoNew[ulSubIndex].ulFileCheckSum);
                    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                    s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]] |= PWR_SUB_PKG_HEAD_CRC_CHK_FAIL;
                }
            }
        }
        else
        {
            dbgInfoEx("lineNum=[%04d]:",ulLineNum);
            for(indexTest=0;indexTest<ucLineInfoSize;indexTest++)
            {
                //coverity[cert_str34_c_violation:SUPPRESS]
                dbgInfoEx("%02X",cLineData[indexTest]);
            }
            dbgInfoEx("\n");
            s_usMcuCrcSum = BspPwrSubModuleCrcChk(ulLineNum,s_usMcuCrcSum,cLineData,ucLineInfoSize);/* 子组件MCU程序部分校验 */
            /* 校验结果判断 */
            if(lSurLen < 6)/*退出循环前，此时正常情况下lSurLen=0*/
            {

                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                dbgInfo("McuCrcSum: [0x%04x] {0x%04x}\n", s_usMcuCrcSum, atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                if(atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum != s_usMcuCrcSum)
                {
                    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                    s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]] |= PWR_SUB_PKG_MCU_CRC_CHK_FAIL;
                    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                    dbgErr("McuCrcChkErr: [0x%04x] {0x%04x}\n", s_usMcuCrcSum, atPwrVerInfoNew[ulSubIndex].ulProgramCheckSum);
                }
            }
            ulAddrOffSet += ucLineInfoSize;
        }
        ulLineNum++;
    }

    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    if ((s_RruPwrTplg.pwrPkgCrcChk[s_PwrSubSubUnitNo[ulSubIndex]] == 0) && \
        (s_RruPwrTplg.pwrTopology[s_PwrSubSubUnitNo[ulSubIndex]] == 1))//crc校验失败且该组建包实体存在（60Ｗ整机不存在48-02）
    {
        s_RruPwrTplg.pwrUpdateFlag[s_PwrSubSubUnitNo[ulSubIndex]] = 1;
    }

    *pulNextSubVerAddr = (uintptr_t)fp;
    return ulRetVal;
}

/*触发升级3次*/
static UINT32 BspTriggerUpdateTimes(UINT32 ulSubIndex, UINT32 tryTimes)
{
    UINT32 iTimes = 0;
    UINT32 ulResult = BSP_OK;


    for (iTimes = 0; iTimes < tryTimes; iTimes++)
    {
        /*触发升级*/
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        dbgInfo("======3.2.1==Index:[%d] SubNo:[%d] triggerUpdate Start ------Times[%d]^_^! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], iTimes);
        ulResult = BspSetPwrUpdateMode(ulSubIndex, UPDATE_MODE);
        if (ulResult != BSP_OK)
        {
            //coverity[cert_ctr50_cpp_violation:SUPPRESS]
            dbgInfo("==========3.2.1_1==Index:[%d] SubNo:[%d] triggerUpdate Failed------Times[%d]! <*_*>\n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex],  iTimes);
            if (iTimes == tryTimes - 1)
            {
                /*触发升级失败，退出该子组件后续流程，切到下一个组件*/
                return BSP_ERROR;
            }
            continue;
        }

        /*延时200ms~300ms*/
        BspSysMsDelay(300);

        /*获取电源升级状态*/
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        if (BspGetPwrUpdateStatusDirect(s_PwrSubSubUnitNo[ulSubIndex]) != UPDATE_MODE)
        {
            dbgInfo("==========3.2.1_2==Index:[%d] SubNo:[%d] triggerUpdate not succeed-----Times[%d]! <*_*>\n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], iTimes);
            if (iTimes == tryTimes - 1)
            {
                /*触发升级失败，退出该子组件后续流程，切到下一个组件*/
                return BSP_ERROR;
            }
        }
        else
        {
            dbgInfo("==========3.2.1_2==Index:[%d] SubNo:[%d] triggerUpdate Succeed-----Times[%d]! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], iTimes);
            return BSP_OK;
        }
    }
        return BSP_OK;
}

/*触发退出升级3次*/
static UINT32 BspExitUpdateTimes(UINT32 ulSubIndex, UINT32 tryTimes)
{
    UINT32 iTimes = 0;
    UINT32 ulResult = BSP_OK;

    for (iTimes = 0; iTimes < tryTimes; iTimes++)
    {
        /*触发升级*/
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        dbgInfo("======3.2.4==Index:[%d] SubNo:[%d] EXitUpdate ---Times[%d]! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], iTimes);
        ulResult = BspSetPwrUpdateMode(ulSubIndex, UPDATE_DONE);
        if (ulResult != BSP_OK)
        {
            //coverity[cert_ctr50_cpp_violation:SUPPRESS]
            dbgInfo("==========3.2.4_1==Index:[%d] SubNo:[%d] EXitUpdate Failed------Times[%d]! <*_*>\n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex],  iTimes);
            if (iTimes == tryTimes - 1)
            {
                /*触发升级失败，退出该子组件后续流程，切到下一个组件*/
                return BSP_ERROR;
            }
            continue;
        }

        /*延时500ms*/
        BspSysMsDelay(500);

        /*获取电源升级状态*/
        if (BspGetPwrUpdateStatusDirect(ulSubIndex) != UPDATE_DONE)
        {
            dbgInfo("==========3.2.4_2==Index:[%d] SubNo:[%d] EXitUpdate not succeed-----Times[%d]! <*_*>\n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], iTimes);
            if (iTimes == tryTimes - 1)
            {
                /*触发升级失败，退出该子组件后续流程，切到下一个组件*/
                return BSP_ERROR;
            }
        }
        else
        {
            dbgInfo("==========3.2.4_2==Index:[%d] SubNo:[%d] EXitUpdate Succeed-----Times[%d]! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex], iTimes);
            return BSP_OK;
        }
    }
        return BSP_OK;
}


/**************************************************************************
* 函数名称: BspPwrPkgLoadNewDirect
* 功能描述: 直升电源版本加载函数
* 输入参数:
* 输出参数: 无
* 返 回 值   : RRUID
* 其它说明:
* 修改日期  版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2022-01-02        V1.0           贾路漫    创建
**************************************************************************/
UINT32  BspPwrPkgLoadDirect(UCHAR* pucLogicDataBuf, INT32 ulBufLen)
{
    T_Pwr_VerPkg_Pwr   *pPwrPkgVer = NULL;   /*组件包 头*/
    CHAR *ucHead            = NULL;
    UINT32 ulLp             = 0;
    UINT32 ulSubIndex       = 0;
    UINT32 ulResult         = 0;
    UINT32 ulResult1        = 0;
    UINT32 ulNextSubVerAddr = 0;
    uintptr_t pUlNextSubVerAddr = 0;
    /*UINT32 retVal         = 0;
    UINT32 iTimes = 0;
    UINT32  UpFlag = 0; */
    UINT32 ulPwrDevId = 0;
    UCHAR  ucPwrVer[PWR_SOFT_VER_LEN] = {0};
    INPUT_POINTER_CHECK(pucLogicDataBuf);
    if(0 != semTake(semPowUpdate, WAIT_FOREVER))
    {
        dbgErr("%s semTake error\n",__FUNCTION__);
        return PWR_GET_SEM_ERROR;
    }
    /*文件头获取以及校验*/
    dbgInfo("=====STEP3.1:CHK_PKG pwr_pkg_hear_chk start=====\n");
    pPwrPkgVer = (T_Pwr_VerPkg_Pwr *)((UCHAR*)(pucLogicDataBuf+sizeof(T_VerFileHeader_Pwr)));
    tPwrVerPkg.ulPkgHeadLen = BspASCIIToULONG((CHAR*)pPwrPkgVer);
    tPwrVerPkg.usVerNum  = BspASCIIToUSHORT((CHAR*)pPwrPkgVer+8);
    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {
        tPwrVerPkg.ulPkgLen[ulSubIndex] = BspASCIIToULONG((CHAR*)pPwrPkgVer+8*ulSubIndex+12);
    }
    tPwrVerPkg.usCrcSum = BspASCIIToUSHORT((CHAR*)pPwrPkgVer+8*(tPwrVerPkg.usVerNum)+12);
    BspPrnPwrPkgHeadInfo();
    if (PwrHeadDataCheck(tPwrVerPkg.ulPkgHeadLen,(CHAR*)pPwrPkgVer)!= BSP_OK)
    {
        semGive(semPowUpdate);
        s_RruPwrTplg.pwrPkgHeadChk = 1;
        return BSP_ERROR;
    }


    ucHead = (CHAR*)pPwrPkgVer + tPwrVerPkg.ulPkgHeadLen*2;
    dbgInfo("PwrPkgHead = %p\n",ucHead);
    for(ulSubIndex = 0; ulSubIndex < tPwrVerPkg.usVerNum; ulSubIndex++)
    {
        for(ulLp = 0; ulLp < PWR_UPDATE_TRY_TIMES; ulLp++) /*给电源Flash写升级文件，最多写3次*/
        {
            dbgInfo("=====STEP3.2: CHK_SUB_PKG[%d]  TRIG_UPDATE   and WR_Flash Start  Times[%d]=====\n", ulSubIndex, ulLp);
            dbgInfo("==3.2.0==Index:[%d] Crc Start^_^! \n",ulSubIndex);
            //coverity[cert_exp37_c_violation:SUPPRESS]
            ulResult1 = BspSubPkgCrcChkDirect(ulSubIndex,ucHead, tPwrVerPkg.ulPkgLen[ulSubIndex], &ulNextSubVerAddr);

            if (s_PwrSubSubUnitNo[ulSubIndex] == 0)
            {
                dbgInfo("========Index:[%d] SubNo:[%d] is MCU  Module   not  support  direct  update!!!!!!<*_*>! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
                break;
            }

            if (ulResult1 != BSP_OK)
            {
                /*校验失败，退出该子组件后续流程，切到下一个组件*/
                dbgInfo("==3.2.0_1==Index:[%d] SubNo:[%d] Crc Failed  OR  ver same OR  ver out of range ! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
                //coverity[cert_int31_c_violation:SUPPRESS]
                if (ulSubIndex == tPwrVerPkg.usVerNum - 1)
                {
                    semGive(semPowUpdate);
                    return BSP_ERROR;
                }
                break;
            }

            /*触发升级3次*/
            dbgInfo("==3.2.1==Index:[%d] SubNo:[%d] triggerUpdate Start ^_^! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
            if (BspTriggerUpdateTimes(ulSubIndex, PWR_ACT_UPDATE_TRY_TIMES) != BSP_OK)
            {
                dbgInfo("==3.2.1==Index:[%d] SubNo:[%d] triggerUpdate   Failed<*_*>! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
                continue;
            }
            dbgInfo("==3.2.1==Index:[%d] SubNo:[%d] triggerUpdate   Succeed^_^! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
            sleep(1);

            /*擦除Flash操作*/
            dbgInfo("==3.2.2==Index:[%d] SubNo:[%d]  Erase  Flash Start ! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
            BspErasePwrModuleFlash(s_PwrSubSubUnitNo[ulSubIndex]);
            sleep(10);

            /*写入Flash*/
            dbgInfo("==3.2.3==Index:[%d] SubNo:[%d] Write Flash Start ! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
            //coverity[cert_exp37_c_violation:SUPPRESS]
            ulResult = BspLoadPwrVerDirect(ulSubIndex,ucHead,tPwrVerPkg.ulPkgLen[ulSubIndex]);
            sleep(1);

            /*退出升级场景3次*/
            dbgInfo("==3.2.4==Index:[%d] SubNo:[%d]  ExitUpdate Start ^_^! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
            if (BspExitUpdateTimes(ulSubIndex, PWR_EXIT_UPDATE_TRY_TIMES) != BSP_OK)
            {
                dbgInfo("==3.2.4==Index:[%d] SubNo:[%d] ExitUpdate   Failed<*_*>! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);
                continue;
            }
            dbgInfo("==3.2.4==Index:[%d] SubNo:[%d] ExitUpdate   Succeed^_^! \n",ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex]);

            ulPwrDevId = BspGetPwrDevId(s_PwrSubSubUnitNo[ulSubIndex]);
            BspGetPwrVer(ulPwrDevId, 0, &ucPwrVer[0], PWR_SOFT_VER_LEN);
            ucPwrVer[5]= '\0';
            dbgInfo("%s:  Result ulSubIndex[%d],PwrIndex[%d] NowVer:[%s], UpdateFileVer:[%s]\n", \
                    __FUNCTION__, ulSubIndex, s_PwrSubSubUnitNo[ulSubIndex],  &ucPwrVer[1],  &atPwrVerInfoNew[ulSubIndex].ucProgramVer[0]);
            break;
        }/*End of 3Times*/
        //coverity[cert_int36_c_violation:SUPPRESS]
        pUlNextSubVerAddr = (uintptr_t)ulNextSubVerAddr;
        ucHead = (CHAR*)pUlNextSubVerAddr;
        if (BSP_OK != ulResult)
        {
            //coverity[cert_int31_c_violation:SUPPRESS]
            if (ulSubIndex == tPwrVerPkg.usVerNum - 1)
            {
                semGive(semPowUpdate);
                return BSP_ERROR;
            }
            continue;
        }
        dbgInfo("ucHead = %p tPwrVerPkg.ulPkgLen[%d] = 0x%x \n",ucHead,ulSubIndex,tPwrVerPkg.ulPkgLen[ulSubIndex]);
    }/*End Of SubIndex*/

    semGive(semPowUpdate);
    return BSP_OK;
}/*End of Function*/


/*****************************************************************************
*  函数名称 : PwrDirectUpdateTest(*)
*  功能描述 : 大板电源直升测试
*  包核对完成之后进入升级模式，直接进行写Flash操作，写完后退出升级模式，并回读确认
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数 :
*  输出参数 : 无
*  返 回 值 : 错误码
*  其它说明 : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),                 贾路漫 @2020-09-18
*----------------------------------------------------------------------------
*/
UINT32 PwrDirectUpdateTest(VOID)
{
    UCHAR   *pucBuffer = NULL;
    struct  stat tStatInfo;
    INT32    lVerLen = 0;
    UINT32   ulRetVal = BSP_OK;
    FILE    *fp = NULL;
    int fclsRet;
    BspGetPwrTplg();
    BspCleanPwrCrcChkResult();

    dbgInfo("=====STRAT PWR UPDATE =====\n");
    INPUT_POINTER_CHECK(pwrVerPath);

    if((fopen_s(&fp,pwrVerPath, "rb")) != 0)
    {
        dbgErr("%s: open %s failed!\n",__FUNCTION__,pwrVerPath);
        if(fp != NULL)
        {
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);
        }
        return BSP_ERROR;
    }

    if(fp == NULL)
    {
        dbgErr("%s: open %s failed!\n",__FUNCTION__,pwrVerPath);
        return BSP_ERROR;
    }

    /* 获得电源版本文件大小 */
    if (stat(pwrVerPath, &tStatInfo) != 0)
    {
        dbgErr("/pwrupdate/pwr.swv not Exist!\n" );
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    lVerLen = tStatInfo.st_size;
    if (lVerLen <= 0)
    {
        //coverity[cert_con33_c_violation:SUPPRESS]
        dbgErr("File Length ERROR! error code: %s\n", zte_strerror_s(errno));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    dbgInfoEx("pwr file length :%d\n", lVerLen);

    if (NULL == (pucBuffer = (UCHAR *)malloc(lVerLen)))
    {
        //coverity[cert_con33_c_violation:SUPPRESS]
        dbgErr("Fail to get memory! error code: %s\n", zte_strerror_s(errno));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    /* 将电源文件装载到RAM中 */
    dbgInfo("=====STEP2:LOAD FILE TO MEMORY =====\n");
    ulRetVal = fread(pucBuffer, 1, lVerLen, fp);
    if (ulRetVal != lVerLen)
    {
        dbgErr("Pwr file read Error");
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    /*升级前进行初始化，创建信号量*/
    if (BSP_OK !=BspPwrUpdateInit())
    {
        dbgErr("%s  error\n",__FUNCTION__);
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    /*开始进行版本包校验以及发起升级*/
    dbgInfo("=====STEP3:CHK_PKG  and  TRIG_UPDATE =====\n");
    ulRetVal = BspPwrPkgLoadDirect(pucBuffer, lVerLen);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("pwr update test fail \n");
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pucBuffer);
        return BSP_ERROR;
    }

    dbgInfo("======pwr updata success======\n");
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);
    free(pucBuffer);
    return ulRetVal;
}

/**************************************************************************
* 函数名称: BspGetPwrVoltCali
* 功能描述: 电源电压校准参数获取
* 输入参数: ulPwrIdx 电源片号
* 		ulType
* 输出参数: VoltK - 两点电压校准斜率
		 VoltB - 两点电压校准电压偏移量
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2019-06-04 10:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetPwrValueCali(UINT32 ulPwrIdx, UINT32 ulType, INT32 *ValueK, INT32 *ValueB)
{
	UINT32 retVal = BSP_OK;
	T_PwrCaliData *ptPwrCali = NULL;
	/* INT32 lVoltK = 0; */
	/* INT32 lVoltB = 0; */
	if(ulPwrIdx >= TBL_PWR_CALI_PWR_NUM_MAX)
	{
		dbgErr("[%s]Input Para Error! \n",__FUNCTION__);
		return BSP_ERROR;
	}

	INPUT_POINTER_CHECK(ValueK);
	INPUT_POINTER_CHECK(ValueB);

	ptPwrCali = (T_PwrCaliData *)_BspGetCalibData(TBL_KIND_OF_PWRCALI,0);
	INPUT_POINTER_CHECK(ptPwrCali);
	_PWRTEMPALMFILE_LOADED_CHECK(ptPwrCali);

	switch(ulType)
	{
		case TBL_PWRCALI_VOLT:
		  *ValueK = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[4];
		  *ValueB = ptPwrCali->tHeader[ulPwrIdx].lPwrVoltCali[5];
		  break;
		case TBL_PWRCALI_POW:
		  *ValueK = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[4];
		  *ValueB = ptPwrCali->tHeader[ulPwrIdx].lPwrPowerCali[5];
		  break;
        case TBL_PWRCALI_CURR:
		  *ValueK = ptPwrCali->tHeader[ulPwrIdx].lPwrCurrCali[4];
		  *ValueB = ptPwrCali->tHeader[ulPwrIdx].lPwrCurrCali[5];
		  break;
		default:
		  retVal = BSP_ERROR;
		  break;
	}
	return retVal;
}

/**************************************************************************
* 函数名称: BspCaliPwrValue
* 功能描述: 线性化校准电压/功率
* 输入参数:
 		ulPwrIdx 电源片号
		ulType 校准电压/功率类型
		raw 原始值
* 输出参数:
* 		pValue 输出电压/功率
*
* 返 回 值:  BSP_OK/BSP_ERROR
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2019-06-04 10:55:24    创建
*----------------------------------------------------------------------------
*/
UINT32 BspCaliPwrValue(UINT32 ulPwrIdx, UINT32 ulType, INT32 raw, INT32 *pValue)
{
	INT32 ValueK = 0;
	INT32 ValueB = 0;
	INT32 cali = 0;
	UINT32 retVal = BSP_OK;

	INPUT_POINTER_CHECK(pValue);

	retVal = BspGetPwrValueCali(ulPwrIdx, ulType, &ValueK, &ValueB);
	if (BSP_OK != retVal)
	{
		ValueK = 1000;
		ValueB = 0;
	}
	dbgInfoEx("volt K=%d B=%d\n", ValueK, ValueB);


	cali = (raw*ValueK + 500)/1000 + ValueB;
	*pValue = cali;

	dbgInfoEx("value raw= %dmV clai = %dmV\n",raw,cali);

	return BSP_OK;
}

/**************************************************************************
* 函数名称: BspPwrModuleVerCompare
* 功能描述: 电源组件版本号比对
* 输入参数: 无
* 输出参数: 无
*
* 返 回 值: PWR_VER_COMPARE_SUCCESS  //0,电源组件版本号比对一致
*          PWR_VER_COMPARE_FAILED   //1，电源组件版本号比对不一致
* 其它说明: pwr.txt与获取的电源组件版本号比对，一致则电源升级成功，不一致则电源升级失败
*          高层脚本调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00300750@2021-07-22 10:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 BspPwrModuleVerCompare(VOID)
{
    UINT32 ulPwrDevId = 0;
    char   ucPwrVer[PWR_SOFT_VER_LEN] = {0};
    FILE   *fp = NULL;
    UINT32 ModuleNum = 0;
    CHAR   lineData[MAX_PWRVER_LINE_LEN] = {0};
    UINT32 loop = 0;
    UINT32 ModuleIndex = 0;
    UINT32 UpdateFlag = 0;
    UINT32 ulRetVal = BSP_OK;
    INT32  iTmpRet = 0;
    const CHAR *textfilePath = NULL;
    struct stat st = {0};

    ulPwrDevId = BspGetPwrMcuDevId();
    memset(ucPwrVer,'\0',PWR_SOFT_VER_LEN);

    textfilePath = PWR_TEXTFILE_PATH;
    if((fopen_s(&fp,textfilePath, "r") != 0) || (fp == NULL))
    {
        dbgErr("[%s] line %d: pwr.txt Open Failed\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    iTmpRet = stat(textfilePath, &st);
    if (iTmpRet != 0)
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }
    if (!S_ISREG(st.st_mode))
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }

    if(fgets(lineData,MAX_PWRVER_LINE_LEN,fp) == NULL)
    {
        dbgErr("[%s] line %d: pwr.txt Get Line Failed\n",__FUNCTION__,__LINE__);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }

    ModuleNum = lineData[0] - '0';
    if(ModuleNum > 0 && ModuleNum <= 9)
    {
        for(loop = 0;loop < ModuleNum; loop++)
        {
            memset(lineData,'\0',MAX_PWRVER_LINE_LEN);

            if(fgets(lineData,MAX_PWRVER_LINE_LEN,fp) == NULL)
            {
                dbgErr("[%s] line %d: pwr.txt Get Line Failed\n",__FUNCTION__,__LINE__);
                iTmpRet = fclose(fp);
                FCLOSE_CHECK(iTmpRet);
                return BSP_ERROR;
            }

            ModuleIndex = lineData[0] - '0';
            /***此处为SWAPPED_ARGUMENTS误告警，参数传递顺序无误，如下抑制告警***/
            //coverity[swapped_arguments:SUPPRESS]
            ulRetVal = BspGetPwrVer(ulPwrDevId, ModuleIndex, (UCHAR *)ucPwrVer, PWR_SOFT_VER_LEN);
            if (BSP_OK != ulRetVal)
            {
                dbgErr("[%s] line %d: ucSubUnitNo:%d,PwrVer Non-Existent\n",__FUNCTION__,__LINE__,ModuleIndex);
                iTmpRet = fclose(fp);
                FCLOSE_CHECK(iTmpRet);
                return BSP_ERROR;
            }
            ucPwrVer[MouduleVer_LEN] = '\0';
            dbgInfoEx("[%s] line %d: Module:%d,NowVer:%s,UpdateVer:%s\n",__FUNCTION__,__LINE__,ModuleNum,ucPwrVer,lineData+2);

            if(strncmp(ucPwrVer,lineData+2,MouduleVer_LEN) == 0)
            {
                dbgInfoEx("[%s] line %d: Module %d Ver Compare Success\n",__FUNCTION__,__LINE__,loop);
                UpdateFlag++;
                continue;
            }
            else
            {
                dbgInfoEx("[%s] line %d: Module %d Ver Compare Failed\n",__FUNCTION__,__LINE__,loop);
                break;
            }
        }
    }

    if(UpdateFlag == ModuleNum)
    {
        dbgInfoEx("[%s] line %d: All Module Ver Compare Success\n",__FUNCTION__,__LINE__);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return PWR_VER_COMPARE_SUCCESS;
    }
    else
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return PWR_VER_COMPARE_FAILED;
    }
}

/**************************************************************************
* 函数名称: BspPwrBarcodeCompare
* 功能描述: 电源条码比对
* 输入参数: 无
* 输出参数: 无
*
* 返 回 值: UpdateFlag  电源升级标志
* 其它说明: pwr.txt与获取的电源条码比对
*          标志为0电源不需要升级，标志为1电源需要升级
*          高层脚本调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00300750@2021-07-22 10:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 BspPwrBarcodeCompare(VOID)
{
    UINT32 ulDevId = 0;
    CHAR   ucData[PWR_MODULE_LEN+1] = {0};
    FILE   *fp = NULL;
    CHAR   lineData[MAX_PWRVER_LINE_LEN] = {0};
    UINT32 UpdateFlag = 0;
    UINT32 ulRetVal = BSP_OK;
    INT32  iTmpRet = 0;
    const CHAR *textfilePath = NULL;
    struct stat st = {0};

    ulDevId = BspGetPwrEepromDevId();
    memset(ucData,'\0',PWR_MODULE_LEN+1);

    ulRetVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_BARCODE, ucData, PWR_MODULE_LEN);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("[%s] line %d: Eeprom Read Error!\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
    ucData[PWR_MODULE_LEN] = '\0';
    dbgInfoEx("[%s] line %d: Pwr Barcode :%s\n",__FUNCTION__,__LINE__,ucData);

    textfilePath = PWR_TEXTFILE_PATH;
    if((fopen_s(&fp,textfilePath, "r") != 0) || (fp == NULL))
    {
        dbgErr("[%s] line %d: pwr.txt Open Failed\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    iTmpRet = stat(textfilePath, &st);
    if (iTmpRet != 0)
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }
    if (!S_ISREG(st.st_mode))
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }

    while(!feof(fp) && fgets(lineData,MAX_PWRVER_LINE_LEN,fp) != NULL)
    {
        if(strncmp(ucData,lineData,PWR_MODULE_LEN-5) == 0)
        {
            UpdateFlag = 1;
            memset(lineData,'\0',MAX_PWRVER_LINE_LEN);
            break;
        }
        else
        {
            memset(lineData,'\0',MAX_PWRVER_LINE_LEN);
            continue;
        }
    }
    if(UpdateFlag == 1)
    {
        dbgInfo("[%s] line %d: Pwr Need Update\n",__FUNCTION__,__LINE__);
    }
    else
    {
        dbgInfo("[%s] line %d: Pwr No Need Update\n",__FUNCTION__,__LINE__);
    }

    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    return UpdateFlag;
}

/**************************************************************************
* 函数名称: BspPrnPwrVer
* 功能描述: 打印电源组件版本号
* 输入参数: ucSubUnitNo 电源组件号
* 输出参数: 无
*
* 返 回 值: BSP_ERROR或BSP_OK
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00300750@2021-07-22 10:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 BspPrnPwrVer(UINT32 ucSubUnitNo)
{
    UINT32 ulPwrDevId = 0;
    UCHAR  ucPwrVer[PWR_SOFT_VER_LEN] = {0};
    UINT32 ulRetVal = BSP_OK;

    ulPwrDevId = BspGetPwrMcuDevId();
    memset(ucPwrVer,'\0',PWR_SOFT_VER_LEN);

    ulRetVal = BspGetPwrVer(ulPwrDevId, ucSubUnitNo, ucPwrVer, PWR_SOFT_VER_LEN);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("[%s] line %d: ucSubUnitNo:%d,Ver Non-Existent\n",__FUNCTION__,__LINE__,ucSubUnitNo);
        return BSP_ERROR;
    }
    ucPwrVer[MouduleVer_LEN] = '\0';
    dbgInfo("[%s] line %d: ucSubUnitNo:%d,PwrVer:%s\n",__FUNCTION__,__LINE__,ucSubUnitNo,ucPwrVer);
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetPwrBarcode
* 功能描述: 打印整机电源组件12位条码
* 输入参数: 无
* 输出参数: 无
*
* 返 回 值: BSP_ERROR或BSP_OK
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00300750@2021-07-22 10:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 BspGetPwrBarcode(VOID)
{
    UINT32 ulDevId = 0;
    CHAR   ucData[PWR_MODULE_LEN+1] = {0};
    UINT32 ulRetVal = BSP_OK;

    ulDevId = BspGetPwrEepromDevId();
    memset(ucData,'\0',PWR_MODULE_LEN+1);

    ulRetVal = BspGetEepromInfo(ulDevId, EEPROM_ON_PWR_BARCODE, ucData, PWR_MODULE_LEN);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("[%s] line %d: Read Error!\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
    ucData[PWR_MODULE_LEN] = '\0';
    dbgInfo("[%s] line %d: Pwr Module BarCode :%s\n",__FUNCTION__,__LINE__,ucData);
    return BSP_OK;
}

/**************************************************************************
* 函数名称: PwrUpdateNeed
* 功能描述: 判断电源是否需要升级
* 输入参数: 无
* 输出参数: needUpdateFlag 电源需要升级标志
*
* 返 回 值: BSP_ERROR或BSP_OK
* 其它说明: needUpdateFlag = 1 需要电源升级
*          needUpdateFlag = 2 不需要电源升级
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00300750@2021-07-22 10:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 PwrUpdateNeed(UINT32 *needUpdateFlag)
{
    UINT32 pwrBarCodeSame = 0;
    UINT32 pwrModuleVerSame = 0;

    pwrBarCodeSame = BspPwrBarcodeCompare();
    pwrModuleVerSame = BspPwrModuleVerCompare();


    if((pwrBarCodeSame == BSP_ERROR) || (pwrModuleVerSame == BSP_ERROR))
    {
        dbgErr("[%s] line %d: Pwr BarCode Or Module Ver Compare Failed\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    if((pwrBarCodeSame == 1) && (pwrModuleVerSame == 1))
    {
        *needUpdateFlag = PWR_VER_NEED_UPDATE;
        dbgInfoEx("[%s] line %d: Pwr Need Update\n",__FUNCTION__,__LINE__);
    }
    else
    {
        *needUpdateFlag = PWR_VER_NONEED_UPDATE;
        dbgInfoEx("[%s] line %d: Pwr No Need Update\n",__FUNCTION__,__LINE__);
    }

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspChagePwrBarCode
* 功能描述: 更新整机电源12位条码
* 输入参数: pwrBarCode 电源12位条码
* 输出参数: 无
*
* 返 回 值: BSP_ERROR或BSP_OK
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00300750@2021-07-22 10:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 BspChagePwrBarCode(CHAR *pwrBarCode)
{
    UINT32 pwrBarCodeAddr = EEPROM_ON_PWR_BARCODE;
    UINT32 pwrBarCodeLen = PWR_MODULE_LEN;
    UINT32 tmpRet = BSP_OK;
    size_t bufLen = 0;
    size_t maxLength = PWR_MODULE_LEN;

    INPUT_POINTER_CHECK(pwrBarCode);

    bufLen = strnlen_s(pwrBarCode,maxLength);
    if(bufLen != maxLength)
    {
        dbgErr("[%s] line %d: PwrBarCode Input Error\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    tmpRet = BspWriteStringToEeprom(pwrBarCodeAddr,pwrBarCode,pwrBarCodeLen);
    if(tmpRet != BSP_OK)
    {
        dbgErr("[%s] line %d: PwrBarCode Write To Eeprom Error\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspSetPowerLowStatus(UINT32 index, UINT32 sw)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspPwrSetLowStatus(devid, sw);
}

UINT32 BspGetPowerLowStatus(UINT32 index, UINT32 *status)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspPwrGetLowStatus(devid, status);
}

UINT32 BspSetDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;
    UINT32 retVal = BSP_OK;

    /* 支持辅助电源, 下电接口打桩适配，不执行实际下电流程 */
    if (BspIsSupportAuxPow())
    {
        return BSP_OK;
    }

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }
    if(pSetDeepSleep != NULL)
    {
        return pSetDeepSleep(index, ulOnOffFlag, ulOffTime);
    }

    if(PWR_SUPPORT_SELF_RESCUE == BspGetPwrSelfRescueFlag())
    {
        retVal = BspSetSmartMcuDeepSleepStatus(index, ulOnOffFlag, ulOffTime);
        dbgInfoEx("Bsp Set Smart Mcu Deep Sleep Time, retVal = %d\n", retVal);
        if(BSP_ERROR == retVal)
        {
            return BSP_ERROR;
        }
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrDeepSleepStatus(devid,ulOnOffFlag,ulOffTime);
}

UINT32 BspSetSmartMcuDeepSleepStatus(UINT32 index, UINT32 ulOnOffFlag, UINT32 ulOffTime)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrDeepSleepStatus(devid,ulOnOffFlag,ulOffTime);
}

UINT32 BspGetPoweroffAbility(UINT32 index, UINT32 *ability)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 pwrInterChan = 0;
    UINT32 devid = 0;
    INT32 snpRet;

    INPUT_POINTER_CHECK(ability);
    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));

    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrSmartPoweroffAbility(devid, pwrInterChan, ability);
}

UINT32 BspGetIsSupportPwroff(VOID)
{
    UINT32 ret = 0;
    UINT32 pwrIndex = 0;
    UINT32 pwrNum = 0;
    UINT32 ability = 0;

    pwrNum = BspGetPwrModuleNum();
    for(pwrIndex = 0; pwrIndex < pwrNum; pwrIndex++)
    {
        ret = BspGetPoweroffAbility(pwrIndex, &ability);
        if((BSP_OK != ret) || (PWR_SUPPORT_SMART_POWEROFF_ABILITY != ability))
        {
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

UINT32 BspSetPowerOffSleep(UINT32 ctrl)
{
    UINT32 ret = 0;
    UINT32 pwrNum = 0;
    UINT32 pwrIndex = 0;

    pwrNum = BspGetPwrModuleNum();
    for(pwrIndex = 0; pwrIndex < pwrNum; pwrIndex++)
    {
        if(SWITCH_ON == ctrl)
        {
            ret = BspSetDeepSleepStatus(pwrIndex, SWITCH_OFF, 1440);  //拉死电源休眠24小时(1440分钟)
        }
        else
        {
            ret = BspSetDeepSleepStatus(pwrIndex, SWITCH_ON, 0);  //恢复电源为正常状态(0分钟)
        }
    }

    return ret;
}
/*****************************************************************************
 * 函数名称: BspSetPwrShutdownDelay
 * 功能描述: 设置电源延迟下电函数
 * 输入参数: index：电源片号（目前填0）
             delaySeconds：延时时间，单位：秒，最大255秒
 * 输出参数: 无
 * 返 回 值: 0：成功；其它值：失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2023-04-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPwrShutdownDelay(UINT32 index, UINT32 delaySeconds)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32 snpRet;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPowerShutdownDelay(devid, delaySeconds);
}

UINT32 BspGetPowerSupplyInsufficient(UINT32 *pStatus)
{
    UINT32 ulRet = BSP_OK;
    UINT32 chipId  = 0;
    UINT32 status = 0;
    INPUT_POINTER_CHECK(pStatus);

    ulRet = BspGetBoardPowerdownAlm(chipId, &status);
    *pStatus = status;

    dbgInfoEx("[%s] VinDownStatus = %d\n", __FUNCTION__, status);

    return ulRet;
}

UINT32 BspSetPwrOverCurrThreshold(UINT32 index, INT32 currThr)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrOverCurrThr(devid,currThr);
}
UINT32 BspGetPwrOverCurrThreshold(UINT32 index, INT32 *pCurrThr)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    INPUT_POINTER_CHECK(pCurrThr);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrOverCurrThr(devid,pCurrThr);
}

UINT32 BspShieldPwrOverTempThreshold(UINT32 index,UINT8 data)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspShieldPwrOverTempThr(devid,data);
}

UINT32 BspEnablePwrOverTempThreshold(UINT32 index)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspEnablePwrOverTempThr(devid);
}

UINT32 BspGetShieldPwrOverTempStatus(UINT32 index)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcAdc%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetShieldPwrOverTempThrStatus(devid);
}

/* 屏蔽电源的过温保护功能并固化 */
UINT32 BspSetPwrOtDisable(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 index = 0;
    UINT8 thr = 0x00;
    UINT32 pwrModuleNum = 0;  /*独立电源有一个或者两个电源砖 大板电源可以有一个或3个电源砖*/

    pwrModuleNum = BspGetPwrModuleNum();

    for(index = 0; index < pwrModuleNum; index++)
    {
        ret |= BspShieldPwrOverTempThreshold(index,thr);
    }

    return ret;
}

/* 开启电源过温保护功能，不固化 */
UINT32 BspSetPwrOtEnable(VOID)
{
    UINT32 index = 0;
    UINT32 pwrModuleNum = 0;  /*独立电源有一个或者两个电源砖 大板电源可以有一个或3个电源砖*/

    pwrModuleNum = BspGetPwrModuleNum();

    for(index = 0; index < pwrModuleNum; index++)
    {
        BspEnablePwrOverTempThreshold(index); /* 驱动该接口如果传参为开启保护，会返回错误，不使用其返回值，默认返回OK */
    }

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspPwrEepromWrite
 * 功能描述: 写电源eeprom封装接口
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A),  2018.05.15, 创建
 *----------------------------------------------------------------------------*/
static UINT32 BspSetEepromInfoSplit(UINT32 ulPwrEepromIdx, UINT32 ulAddr, UINT8 *pucBuf, UINT32 ulByteSum)
{
    UINT32 ulLoopCnt = 0;
    UINT32 ulWordSum = 0;
    UINT32 ulLeftSum = 0;
    UINT32 ulEepromOff = 0;
    UINT32 ulRetVal = BSP_OK;
    CHAR   aucTmpdata[EEPROM_ACCESS_BYTE_NUN] = {0};/*电源升级访问电源eeprom拆分为16字节，多次传输*/

    ulWordSum = ulByteSum / EEPROM_ACCESS_BYTE_NUN;
    ulLeftSum = ulByteSum % EEPROM_ACCESS_BYTE_NUN;

    for (ulLoopCnt = 0; ulLoopCnt < ulWordSum; ulLoopCnt++)
    {
        ulEepromOff = ulAddr + ulLoopCnt * EEPROM_ACCESS_BYTE_NUN;
        memcpy_s(aucTmpdata,EEPROM_ACCESS_BYTE_NUN,(pucBuf + ulLoopCnt * EEPROM_ACCESS_BYTE_NUN), EEPROM_ACCESS_BYTE_NUN);
        ulRetVal |= BspSetEepromInfo(ulPwrEepromIdx, ulEepromOff, aucTmpdata, EEPROM_ACCESS_BYTE_NUN);
    }

    if (ulLeftSum > 0)
    {
        ulEepromOff = ulAddr + ulWordSum * EEPROM_ACCESS_BYTE_NUN;
        memcpy_s(aucTmpdata,ulLeftSum,(pucBuf + ulWordSum * EEPROM_ACCESS_BYTE_NUN),ulLeftSum);
        ulRetVal |= BspSetEepromInfo(ulPwrEepromIdx, ulEepromOff, aucTmpdata, ulLeftSum);
    }

    return ulRetVal;
}

static UINT32 BspGetEepromInfoSplit(UINT32 ulPwrEepromIdx, UINT32 ulAddr, UINT8 *pucBuf, UINT32 ulByteSum)
{
    UINT32 ulLoopCnt = 0;
    UINT32 ulWordSum = 0;
    UINT32 ulLeftSum = 0;
    UINT32 ulEepromOff = 0;
    UINT32 ulRetVal = BSP_OK;
    CHAR   aucTmpdata[EEPROM_ACCESS_BYTE_NUN] = {0}; /*电源升级访问电源eeprom拆分为16字节，多次传输*/

    ulWordSum = ulByteSum / EEPROM_ACCESS_BYTE_NUN;
    ulLeftSum = ulByteSum % EEPROM_ACCESS_BYTE_NUN;
    for (ulLoopCnt = 0; ulLoopCnt < ulWordSum; ulLoopCnt++)
    {
        ulEepromOff = ulAddr + ulLoopCnt * EEPROM_ACCESS_BYTE_NUN;
        ulRetVal |= BspGetEepromInfo(ulPwrEepromIdx, ulEepromOff, aucTmpdata, EEPROM_ACCESS_BYTE_NUN);
        memcpy_s((pucBuf + ulLoopCnt * EEPROM_ACCESS_BYTE_NUN), EEPROM_ACCESS_BYTE_NUN,aucTmpdata, EEPROM_ACCESS_BYTE_NUN);
    }

    if (ulLeftSum > 0)
    {
        ulEepromOff = ulAddr + ulWordSum * EEPROM_ACCESS_BYTE_NUN;
        ulRetVal |= BspGetEepromInfo(ulPwrEepromIdx, ulEepromOff, aucTmpdata, ulLeftSum);
        memcpy_s((pucBuf + ulWordSum * EEPROM_ACCESS_BYTE_NUN), ulLeftSum, aucTmpdata, ulLeftSum);
    }

    return ulRetVal;
}

static UINT32 BspModifyEepromPageDly(UINT32 delay)
{
    eepromPageDly = delay;

    return eepromPageDly;
}

UINT32 BspSetEepromPageDly(VOID)
{
    /*电源页写的时候需要延时5ms*/
    BspSysMsDelay_Sys(eepromPageDly);
    return BSP_OK;
}

UINT32 BspSetPwrVoltAdjustEnable(UINT32 ulIndex, UINT32 ulEnable)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrAdjustEnable(devid, ulEnable);
}
UINT32 BspGetPwrVoltAdjustEnable(UINT32 ulIndex, UINT32 *pEnable)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    INPUT_POINTER_CHECK(pEnable);

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrAdjustEnable(devid, pEnable);
}

UINT32 BspSetPwrVoltAdjustLimit(UINT32 ulIndex, INT32 ulAdjustMaxVal)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrAdjustLimit(devid, ulAdjustMaxVal);
}

UINT32 BspGetPwrVoltAdjustLimit(UINT32 ulIndex,INT32 *pAdjustMaxVal)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    INPUT_POINTER_CHECK(pAdjustMaxVal);

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrAdjustLimit(devid, pAdjustMaxVal);
}

UINT32 BspGetPwrVoltAdjustStep(UINT32 ulIndex, INT32 *pAdjustStep)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    INPUT_POINTER_CHECK(pAdjustStep);

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrAdjustStep(devid, pAdjustStep);
}
UINT32 BspSetPwrVoltAdjustStep(UINT32 ulIndex, INT32 ulAdjustStep)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrAdjustStep(devid, ulAdjustStep);
}

UINT32 BspGetPwrVoltAdjustLevel(UINT32 ulIndex, UINT32 *pGpioLevel)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    INPUT_POINTER_CHECK(pGpioLevel);

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrAdjustLevel(devid, pGpioLevel);
}

UINT32 BspGetPwrVoltAdjustErrCnt(UINT32 ulIndex,UINT32 *pAdjustErrCnt)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    INPUT_POINTER_CHECK(pAdjustErrCnt);

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrAdjustErrCnt(devid, pAdjustErrCnt);
}

UINT32 BspSetPwrVoltAdjustStatus(UINT32 ulIndex, UINT32 ulStatus)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPwrAdjustStatus(devid, ulStatus);
}
UINT32 BspGetPwrVoltAdjustStatus(UINT32 ulIndex, UINT32 *pStatus)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    INPUT_POINTER_CHECK(pStatus);

    if(PwrSecondAcMoudle == 1)
    {
        ulIndex = ulIndex + PwrSecondAcIndex;
    }

    snpRet = snprintf_s(bufName,sizeof(bufName),"RpdcDac%d",ulIndex);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrAdjustStatus(devid, pStatus);
}

/*
设置单板是否支持供电能力不足功能（单板初始化）
*入参：0--不支持供电能力不足功能  1--支持供电能力不足功能
*/
UINT32 BspSetRruIsSupportVindown(UINT32 swVindown)
{
    pwrVindownSupportFlag = swVindown;

    return BSP_OK;
}

UINT32 BspGetRruIsSupportVindown(VOID)
{
    if (pwrVindownSupportFlag == PWR_SUPPORT_VINDOWN_NO)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*设置光耦是否焊反标志*/
UINT32 BspSetVindownIsEffective(UINT32 sw)
{
    pwrVindownEffectiveFlag = sw;

    return BSP_OK;
}

/*获取RRU 光耦是否焊反
 * 返回值：
 *         光耦未失效   BSP_OK
 *         光耦失效     BSP_ERROR
 * */
UINT32 BspGetVindownIsEffective(VOID)
{
    if (pwrVindownEffectiveFlag == PWR_VINDOWN_EFFECTIVE_NO)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspPwrOffMask(UINT32 PwrOff0Mask, UINT32 PwrOff1Mask)
{
    UINT32 retVal = 0;
    UINT32 cpriType = 0;

    retVal = BspHalAdaptGetCpriProtocol(&cpriType);

    switch(cpriType)
    {
        case PROCOTOL_CPRI:  //注意增加eCPRI前传和CPRI前传区分，不同前传寄存器操作不一样，暂时只有CPRI前传
        {
            retVal |= BspHalAdaptCfgPdPwrOffMask(PwrOff0Mask, PwrOff1Mask);
            break;
        }
        default:
        {
        	break;
        }
    }

    return retVal;
}

static UINT32 BspProcessVindownDat(VOID)
{
    UINT32 index = 0;
    UINT32 flagVal = 0;

    BspSetVindownIsEffective(PWR_VINDOWN_EFFECTIVE_YES);/*初始态认为光耦未焊反*/

    for (index = 0; index < PWR_VINDOWN_DETECT_CNT; index++)
    {
        if (pwrVindownStatAll[index] == 0)
        {
            return BSP_OK;
        }
    }

    for (index = 0; index < PWR_VINDOWN_DETECT_CNT; index++)
    {
        if ((pwrVoltAll[index] <= g_aDcAlmThre[0]) && (pwrVoltAll[index] >= 0))
        {
            return BSP_OK;
        }
    }

    /*此处说明5次Vindown都是高电平，且电压大于37V，可以认为光耦焊反*/
    BspSetVindownIsEffective(PWR_VINDOWN_EFFECTIVE_NO);

    flagVal = BspGetFddTddCoExistSta();  /*FDD,TDD,T+F等机型区分判别*/
    switch(flagVal)
    {
        case MODE_ONLY_FDD:  /*FDD机型,光耦焊反整机，屏蔽输入电源断掉电告警:配置为0x11进行屏蔽*/
        {
            BspPwrOffMask(1, 1);
            break;
        }
        case MODE_ONLY_TDD:  /*TDD机型,暂时预留不做屏蔽处理*/
        {
            break;
        }
        case  MODE_ONLY_TDD_FDD:  /*T+F机型,暂时预留不做屏蔽处理*/
        {
            break;
        }
        default:
        {
            break;
        }
    }

    return BSP_OK;
}

/*检测单板光耦是否焊反*/
UINT32 BspDetectVindownIsEffective(VOID)
{
    UINT32 ret  = BSP_OK;
    UINT32 pStatus = 0;
    INT32  pwrVolt = 0;
    UINT32 index = 0;

    /*step1: 获取整机是否支持供电能力*/
    if (BspGetRruIsSupportVindown() == BSP_ERROR )
    {
        return ret;/*整机不支持供电能力不足时，默认光耦无问题，不进行光耦焊反检测*/
    }

    /*step2: 读取vindown锁存状态，读取输入电压,连续检测5次*/
    for (index = 0; index < PWR_VINDOWN_DETECT_CNT; index++)
    {
        /*初始值清零处理*/
        pwrVindownStatAll[index] = 0;
        pwrVoltAll[index] = 0;

        if (BspGetPowerSupplyInsufficient(&pStatus) != BSP_OK)
        {
            dbgErr("[%s] get vin down error，vindown default effective!\n", __FUNCTION__);
            return ret; /*获取vindown状态失败时，默认光耦无问题，不进行光耦焊反检测*/
        }

        if (BspGetPwrVolt(0,&pwrVolt) != BSP_OK)
        {
            dbgErr("[%s] get pwr volt error，vindown default effective!\n", __FUNCTION__);
            return ret; /*获取输入电压失败时，默认光耦无问题，不进行光耦焊反检测*/
        }

        pwrVindownStatAll[index] = pStatus;
        pwrVoltAll[index] = pwrVolt;
        BspSysMsDelay(PWR_VINDOWN_DETECT_CYCLE);
    }
    /*step3: 如果5次Vindown持续为高且电压正常无欠压，则认为Vindown失效*/
    BspProcessVindownDat();

    return ret;
}

UINT32 BspSetPwrMcuDeepSleepStatus(UINT32 ulOnOffFlag, UINT32 ulDelayTime)
{
    UINT32 ulDevId = 0;
    UINT32 ret = 0;

    ulDevId = BspGetPwrMcuDevIdNew();
    ret = BspSetPwrMcuDeepSleepTime(ulDevId, ulOnOffFlag, ulDelayTime);

    return ret;
}

UINT32 BspGetPwrMfrModelInfo(UINT32 index, UINT8 *pStrModel, UINT32 byteNum)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32  snpRet = 0;

    INPUT_POINTER_CHECK(pStrModel);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrMfrModel(devid,pStrModel, byteNum);
}

UINT32 BspGetPwrMfrRevisionVersion(UINT32 index, UINT8 *pStrRevision, UINT32 byteNum)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32  snpRet = 0;

    INPUT_POINTER_CHECK(pStrRevision);

    if(PwrSecondAcMoudle == 1)
    {
        index = index + PwrSecondAcIndex;
    }

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"RpdcDac%d",index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetPwrMfrRevision(devid,pStrRevision, byteNum);
}

/**************************************************************************
* 函数名称: BspGetMcuDevId()
* 功能描述: 获取MCU设备ID号
* 输入参数:
* 输出参数: 无
* 返 回 值:
* 其它说明:
* 修改日期      版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2019年01月22日                 刘谈    创建
**************************************************************************/
UINT32 BspGetMcuDevId(VOID)
{
    char   bufName[PWR_EEPROM_NAME_LEN] ={0};
    UINT32 devid = 0;
    int snpRet;

    snpRet = snprintf_s(bufName, sizeof(bufName), "PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    return devid;
}

/***************************************************************************
* 函数名称: BspPrnMcuVer
* 功能描述: 打印mcu版本号
* 输入参数: ucSubUnitNo Mcu内部通道号
* 输出参数: 无
*
* 返 回 值: BSP_ERROR或BSP_OK
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 00300750@2021-07-22 10:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 BspPrnMcuVer(UINT32 ucSubUnitNo)
{
    UINT32 ulPwrDevId = 0;
    UCHAR  ucPwrVer[PWR_SOFT_VER_LEN] = {0};
    UINT32 ulRetVal = BSP_OK;

    ulPwrDevId = BspGetMcuDevId();
    memset_s(ucPwrVer, sizeof(ucPwrVer), '\0', PWR_SOFT_VER_LEN);

    ulRetVal = BspGetPwrVer(ulPwrDevId, ucSubUnitNo, ucPwrVer, PWR_SOFT_VER_LEN);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("[%s] line %d: ucSubUnitNo:%d, Ver Non-Existent\n", __FUNCTION__, __LINE__, ucSubUnitNo);
        return BSP_ERROR;
    }
    ucPwrVer[PWR_SUB_VER_LEN] = '\0';     /* 强制添加/0防止出现打印字符串溢出 */
    dbgInfo("[%s] line %d: ucSubUnitNo:%d, PwrVer:%s\n",__FUNCTION__,__LINE__,ucSubUnitNo,ucPwrVer);
    return BSP_OK;
}

UINT32 BspMcuModuleVerCompare(VOID)
{
    UINT32 ulMcuDevId = 0;
    UCHAR  ucPwrVer[PWR_SOFT_VER_LEN] = {0};
    FILE   *fp = NULL;
    UINT32 ModuleNum = 0;
    CHAR   lineData[MAX_PWRVER_LINE_LEN] = {0};
    UINT32 loop = 0;
    UINT32 ModuleIndex = 0;
    UINT32 UpdateFlag = 0;
    UINT32 ulRetVal = BSP_OK;
    INT32  iTmpRet = 0;
    const CHAR *textfilePath = NULL;
    struct stat st = {0};
	
    ulMcuDevId = BspGetMcuDevId();
    memset(ucPwrVer,'\0',PWR_SOFT_VER_LEN);

    textfilePath = PWR_TEXTFILE_PATH;
    if((fopen_s(&fp,textfilePath, "r") != 0) || (fp == NULL))
    {
        dbgErr("[%s] line %d: pwr.txt Open Failed\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    iTmpRet = stat(textfilePath, &st);
    if (iTmpRet != 0)
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }
    if (!S_ISREG(st.st_mode))
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }

    if(fgets(lineData,MAX_PWRVER_LINE_LEN,fp) == NULL)
    {
        dbgErr("[%s] line %d: pwr.txt Get Line Failed\n",__FUNCTION__,__LINE__);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return BSP_ERROR;
    }

    ModuleNum = lineData[0] - '0';
    if(ModuleNum > 0 && ModuleNum <= 9)
    {
        for(loop = 0;loop < ModuleNum; loop++)
        {
            memset(lineData,'\0',MAX_PWRVER_LINE_LEN);

            if(fgets(lineData,MAX_PWRVER_LINE_LEN,fp) == NULL)
            {
                dbgErr("[%s] line %d: pwr.txt Get Line Failed\n",__FUNCTION__,__LINE__);
                iTmpRet = fclose(fp);
                FCLOSE_CHECK(iTmpRet);
                return BSP_ERROR;
            }

            ModuleIndex = lineData[0] - '0';
            /***此处为SWAPPED_ARGUMENTS误告警，参数传递顺序无误，如下抑制告警***/
            //coverity[swapped_arguments:SUPPRESS]
            ulRetVal = BspGetPwrVer(ulMcuDevId, ModuleIndex, ucPwrVer, PWR_SOFT_VER_LEN);
            if (BSP_OK != ulRetVal)
            {
                dbgErr("[%s] line %d: ucSubUnitNo:%d,PwrVer Non-Existent\n",__FUNCTION__,__LINE__,ModuleIndex);
                iTmpRet = fclose(fp);
                FCLOSE_CHECK(iTmpRet);
                return BSP_ERROR;
            }
            ucPwrVer[MouduleVer_LEN+1] = '\0';
            dbgInfoEx("[%s] line %d: Module:%d,NowVer:%s,UpdateVer:%s\n",__FUNCTION__,__LINE__,ModuleNum,ucPwrVer,lineData+2);
            
            if(strncmp((const char *)ucPwrVer+1,lineData+2,MouduleVer_LEN) == 0)
            {
                dbgInfoEx("[%s] line %d: Module %d Ver Compare Success\n",__FUNCTION__,__LINE__,loop);
                UpdateFlag++;
                continue;
            }
            else
            {
                dbgInfoEx("[%s] line %d: Module %d Ver Compare Failed\n",__FUNCTION__,__LINE__,loop);
                break;
            }
        }
    }

    if(UpdateFlag == ModuleNum)
    {
        dbgInfoEx("[%s] line %d: All Module Ver Compare Success\n",__FUNCTION__,__LINE__);
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return PWR_VER_COMPARE_SUCCESS;
    }
    else
    {
        iTmpRet = fclose(fp);
        FCLOSE_CHECK(iTmpRet);
        return PWR_VER_COMPARE_FAILED;
    }
}

UINT32 BspSetSecondAcPwrIndex(UINT32 index)
{
    PwrSecondAcIndex = index;

    return PwrSecondAcIndex;
}

UINT32 setSecondAcMoudle(UINT32 flag)
{
    PwrSecondAcMoudle = flag;

    return PwrSecondAcMoudle;
}

static UINT32 BspGetSecondAcMoudle(void)
{
    return PwrSecondAcMoudle;
}

UINT32 BspGetAcPwrInputVolttype(UINT32 pwrIndex)
{
    UINT32 acType = BSP_OK;

    acType = BspGetPwrInputVolt(pwrIndex);

    return acType;
}


UINT32 BspGetVoltInputIndex(void)
{
    return PwrVoltInputIndex;
}

/* 9626双AC电源模块为了保证app的平台性，欠过压时返回需要读取的电源模块数 */
UINT32 BspSetVoltInputIndex(UINT32 index)
{

    PwrVoltInputIndex = index;

    return PwrVoltInputIndex;
}

UINT32 BspSetRruWaterLeakIniKeyVal(UINT32 flag, UINT32 resetCount)
{
    INT32 ret = 0;
    CHAR resetCountBuf[KEY_VALUE_LEN] = {0};
    CHAR flagBuf[KEY_VALUE_LEN] = {0};

    ret = snprintf_s(flagBuf, sizeof(flagBuf), "%u", flag);
    SNPRINTF_S_CHECK(ret, sizeof(flagBuf));
    ret = snprintf_s(resetCountBuf, sizeof(resetCountBuf), "%u", resetCount);
    SNPRINTF_S_CHECK(ret, sizeof(resetCountBuf));

    ret = ConfigSetKey(FILE_WATER_LEAKING_RECORD_LOG, WATER_LEAKING_TITLE, WATER_LEAKING_RESET_COUNT_KEY, resetCountBuf);
    ret |= ConfigSetKey(FILE_WATER_LEAKING_RECORD_LOG, WATER_LEAKING_TITLE, WATER_LEAKING_RECORD_KEY, flagBuf);
    if(BSP_OK != ret)
    {
        dbgErr("[%s]: ConfigSetKey failed, ret=%d\n", __FUNCTION__, ret);
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspRruWaterLeakPostProcess(VOID)
{
    INT32 ret = 0;
    CHAR recordKey[KEY_VALUE_LEN] = {0};
    CHAR resetCountKey[KEY_VALUE_LEN] = {0};
    INT32 recordFlag = 0;
    INT32 count = 0;

    if(BSP_ERROR == BspIsFileExist(FILE_WATER_LEAKING_RECORD_LOG))
    {
        dbgErr("[%s]LogFile is no Existing, No WaterLeakPostProcess\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ret = ConfigGetKeyEx(FILE_WATER_LEAKING_RECORD_LOG, WATER_LEAKING_TITLE, WATER_LEAKING_RECORD_KEY, recordKey, sizeof(recordKey));
    if(BSP_OK != ret)
    {
        dbgErr("%s: ConfigGetKeyEx %s failed, ret=%d\n", __FUNCTION__, WATER_LEAKING_RECORD_KEY, ret);
        return BSP_ERROR;
    }

    recordFlag = BspAtoi(recordKey, 0);
    if(TRUE == recordFlag)
    {
        ret = ConfigGetKeyEx(FILE_WATER_LEAKING_RECORD_LOG, WATER_LEAKING_TITLE, WATER_LEAKING_RESET_COUNT_KEY, resetCountKey, sizeof(resetCountKey));
        if(BSP_OK != ret)
        {
            dbgErr("%s: ConfigGetKeyEx %s failed, ret=%d\n", __FUNCTION__, WATER_LEAKING_RESET_COUNT_KEY, ret);
            return BSP_ERROR;
        }

        count = BspAtoi(resetCountKey, 0);
        if(count < RESET_COUNT)  //漏水后处理复位次数限制
        {
            count = count + 1;
            ret = BspSetRruWaterLeakIniKeyVal(TRUE, count);
            ret |= BspSetPowerOffSleep(SWITCH_ON);
        }
        else
        {
            count = 0;
            ret = BspSetRruWaterLeakIniKeyVal(FALSE, count);
            ret |= BspSetPowerOffSleep(SWITCH_OFF);
        }

        return ret;
    }
    dbgInfo("[%s]No Happening WaterLeaking\n", __FUNCTION__);

    return BSP_ERROR;
}

UINT32 BspSetPwrTempDeratingInfo(T_PwrOverTempDerating *pwrCfgInfo)
{
    INPUT_POINTER_CHECK(pwrCfgInfo);

    s_tPwrOverTempDeratingInfo = pwrCfgInfo;

    return BSP_OK;
}

//获取电源轻微过温功放通道降额掩码
/* Started by AICoder, pid:y8d50u7d9fd49841441f0b2eb0abd719f2a5a5bf */
VOID BspGetGainPaChanMask(UINT32 node, UINT32 *paChanMask)
{
    INPUT_POINTER_CHECK_RETURN(paChanMask);

    if(NULL == s_tPwrOverTempDeratingInfo)
    {
        dbgInfoEx("[%s]s_tPwrOverTempDeratingInfo is NULL,node:%d, paChanMask:0x%x\n", __FUNCTION__, node, *paChanMask);
        return ;
    }

    if(node >= PWR_MAX_TEMP_NUM)
    {
        dbgErr("[%s] node:%d, Exceed the PWR_MAX_TEMP_NUM[%d]", __FUNCTION__, node, PWR_MAX_TEMP_NUM);
        return ;
    }

    *paChanMask = s_tPwrOverTempDeratingInfo->paChanMask[node];
    dbgInfoEx("[%s]node:%d, paChanMask:0x%x\n", __FUNCTION__, node, *paChanMask);

    return ;
}
/* Ended by AICoder, pid:y8d50u7d9fd49841441f0b2eb0abd719f2a5a5bf */

/* 获取电源节点温度门限及通道掩码 */
UINT32 BspGetTempMode(T_PwrTempMode *pTempMod)
{
    UINT32 ret = BSP_OK;
    UINT32 chan = 0;
    UINT32 loop = 0;
    UINT32 index = 0;
    UINT32 chnMask = 0;
    UINT32 gainChnMask = 0;
    UINT32 chnLoop = 0;
    UINT32 nodeIndex = 0;
    INT32 warnThr = 0;
    INT32 recThr = 0;
    UINT32 devNum = 0;
    UINT32 pwrType = 1;
    CHAR *pDeviceId = NULL;
    CHAR *pPathName = NULL;
    CHAR arrMask[BAR_MAX_LENGTH] = {'\0'};
    T_HwInfo* hwInfo = NULL;
    UINT32 thresholdId = 0;
    UINT32 pwrTempSensorNum = 0;
    UINT32 overId[PWR_MAX_TEMP_NUM] = {BSP_THRESHOLD_ID_OVER_PWR_TEMPER, BSP_THRESHOLD_ID_OVER_PWR1_TEMPER, BSP_THRESHOLD_ID_OVER_PWR2_TEMPER,
                                        BSP_THRESHOLD_ID_OVER_PWR3_TEMPER, BSP_THRESHOLD_ID_OVER_PWR4_TEMPER, BSP_THRESHOLD_ID_OVER_PWR5_TEMPER,
                                        BSP_THRESHOLD_ID_OVER_PWR6_TEMPER, BSP_THRESHOLD_ID_OVER_PWR7_TEMPER};
    UINT32 slightOverId[PWR_MAX_TEMP_NUM] = {BSP_THRESHOLD_ID_SLIGHTOVER_PWR_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR1_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR2_TEMPER,
                                        BSP_THRESHOLD_ID_SLIGHTOVER_PWR3_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR4_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR5_TEMPER,
                                        BSP_THRESHOLD_ID_SLIGHTOVER_PWR6_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR7_TEMPER};

    T_PwrTempAlarmDefPaPara *pPara = NULL;

    INPUT_POINTER_CHECK(pTempMod);
    pwrType = BspGetPwrType(0);

    BspGetTempAlmSensorNum(&pwrTempSensorNum);
    if(0 == pwrTempSensorNum)
    {
        pwrTempSensorNum = BspGetPwrTempNodeNum();
        dbgInfoEx("[%s] pwrTempSensorNum: from .txt(%u), from rruproperty(%u) \n", __FUNCTION__, 0, pwrTempSensorNum);
    }

    if(pwrTempSensorNum > PWR_MAX_TEMP_NUM)
    {
        dbgInfoEx("[%s] PWR_MAX_TEMP_NUM:%u, pwrTempSensorNum(%u) out of range!\n",
                __FUNCTION__, PWR_MAX_TEMP_NUM, pwrTempSensorNum);
        return BSP_ERROR;
    }

    pTempMod->tempNum = pwrTempSensorNum;
    pTempMod->supportAbility = 0;
    devNum = BspGetDevNum();
    hwInfo = BspGetBoardPropInfo();
    INPUT_POINTER_CHECK(hwInfo);

    dbgInfoEx("[%s] pwrType:%u (0:DC,1:AC,3:HIGH_DC), pwrTempSensorNum:%u, devNum:%u \n", __FUNCTION__, pwrType, pwrTempSensorNum, devNum);

    pPara = BspGetPwrTempAlmThreshold();
    for (loop = 0; loop < devNum; loop++)
    {
        pDeviceId = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acDeviceId;
        pPathName = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acPathName;
        INPUT_POINTER_CHECK(pDeviceId);
        INPUT_POINTER_CHECK(pPathName);

        memset_s((VOID *)arrMask, sizeof(arrMask), 0, sizeof(arrMask));
        if ((nodeIndex < pwrTempSensorNum) && (0 == strncmp("TempRpdc", pDeviceId, 8)))
        {
            for(index = 0; index < BAR_MAX_LENGTH; index++)
            {
                if ('\0' != pPathName[index])
                {
                    arrMask[index] = pPathName[index];
                }
            }

            chnMask = (UINT32)BspAtoi(arrMask, 0);
            /* UINT32一共32bit */
            for(chnLoop = 0; chnLoop < 32; chnLoop++)
            {
                if (0 != ((chnMask >> chnLoop) & 1))
                {
                    chan = chnLoop;
                    break;
                }
            }

            dbgInfoEx("[%s] nodeIndex:%u, pDeviceId:%s, pPathName:%s, arrMask:%s, chnMask:0x%x, chan:%u \n",
                        __FUNCTION__, nodeIndex, pDeviceId, pPathName, arrMask, chnMask, chan);

            if(0 != chnMask)
            {
                pTempMod->supportAbility = SUPPORT;
            }
            gainChnMask = chnMask;
            BspGetGainPaChanMask(nodeIndex, &gainChnMask);  //部分机型电源轻微过温和严重过温降额通道掩码不一致
            pTempMod->t_tempMode[nodeIndex].nodeNo = nodeIndex;
            pTempMod->t_tempMode[nodeIndex].gainBitNum = gainChnMask;
            pTempMod->t_tempMode[nodeIndex].paBitNum = chnMask;
            pTempMod->t_tempMode[nodeIndex].pwrType = pwrType;
            pTempMod->t_tempMode[nodeIndex].acCuracy = 10;

            thresholdId = overId[nodeIndex];
            ret |= BspGetTempThreshold(chan, thresholdId, &warnThr, &recThr);
            if(NULL != pPara)
            {
                warnThr = pPara[nodeIndex].PwrHighOverTempThreshold;
                recThr  = pPara[nodeIndex].PwrHighOverTempRechold;
            }

            pTempMod->t_tempMode[nodeIndex].seriousThrd = warnThr;
            pTempMod->t_tempMode[nodeIndex].seriousRecThrd = recThr;
            dbgInfoEx("[%s] thresholdId:%u, seriousThrd:%d, seriousRecThrd:%d \n", __FUNCTION__, thresholdId, warnThr, recThr);

            thresholdId = slightOverId[nodeIndex];
            ret |= BspGetTempThreshold(chan, thresholdId, &warnThr, &recThr);
            if(NULL != pPara)
            {
                warnThr = pPara[nodeIndex].PwrSlightOverTempThrehold;
                recThr  = pPara[nodeIndex].PwrSlightOverTempRechold;
            }

            pTempMod->t_tempMode[nodeIndex].slightThrd = warnThr;
            pTempMod->t_tempMode[nodeIndex].slightRecThrd = recThr;
            dbgInfoEx("[%s] thresholdId:%u, slightThrd:%d, slightRecThrd:%d \n", __FUNCTION__, thresholdId, warnThr, recThr);

            nodeIndex++;
        }
    }

    return ret;
}

/* 获取电源各节点温度 */
UINT32 BspGetPwrNodeTemp(T_PwrTemp *pTemp)
{
    UINT32 ret = BSP_OK;
    UINT32 index = 0;
    UINT32 pwrTempSensorNum = 0;
    INPUT_POINTER_CHECK(pTemp);

    BspGetTempAlmSensorNum(&pwrTempSensorNum);
    if(0 == pwrTempSensorNum)
    {
        pwrTempSensorNum = BspGetPwrTempNodeNum();
        dbgInfoEx("[%s] pwrTempSensorNum: from .txt(%u), from rruproperty(%u) \n", __FUNCTION__, 0, pwrTempSensorNum);
    }

    if(pwrTempSensorNum > PWR_MAX_TEMP_NUM)
    {
        dbgInfoEx("[%s] PWR_MAX_TEMP_NUM:%u, pwrTempSensorNum(%u) out of range!\n",
                __FUNCTION__, PWR_MAX_TEMP_NUM, pwrTempSensorNum);
        return BSP_ERROR;
    }

    pTemp->tempNum = pwrTempSensorNum;

    for(index = 0; index < pwrTempSensorNum; index++)
    {
        pTemp->t_nodeTemp[index].nodeNo = s_tPwrNodeTemp.t_nodeTemp[index].nodeNo;
        pTemp->t_nodeTemp[index].temp = s_tPwrNodeTemp.t_nodeTemp[index].temp;
        dbgInfoEx("[%s] node:%u, pwrTemp:%d (0.1C) \n", __FUNCTION__,
                pTemp->t_nodeTemp[index].nodeNo, pTemp->t_nodeTemp[index].temp);
    }

    return ret;
}

/* 获取电源连接器节点温度门限等信息 */
UINT32 BspGetPwrLetCfgInfo(T_PwrLetCongfig *pwrLetTempCfg)
{
    static CHAR dviceName[] = "TempPwrLet";
    UINT32 length = strnlen_s(dviceName, MAX_DEVICE_LEN);
    UINT32 ret = 0;
    UINT32 chan = 0;
    UINT32 index = 0;
    INT32 warnThr = 0;
    INT32 recThr = 0;
    UINT32 thresholdId = 0;
    UINT32 pwrLetNodeNum = 0;
    UINT32 pwrLetTempNode[PWR_MAX_TEMP_NUM] = {BSP_THRESHOLD_ID_OVER_PWR_LET0_TEMPER, BSP_THRESHOLD_ID_OVER_PWR_LET1_TEMPER,
                                             BSP_THRESHOLD_ID_OVER_PWR_LET2_TEMPER, BSP_THRESHOLD_ID_OVER_PWR_LET3_TEMPER};
    INPUT_POINTER_CHECK(pwrLetTempCfg);

    pwrLetNodeNum = BspGetDeviceNodeNum(dviceName, length);
    if(pwrLetNodeNum > PWR_MAX_PWRLET_NODE_NUM)
    {
        dbgErr("[%s] PWR_MAX_TEMP_NUM:%u, pwrTempSensorNum(%u) out of range!\n",
                    __FUNCTION__, PWR_MAX_PWRLET_NODE_NUM, pwrLetNodeNum);
        return BSP_ERROR;
    }

    pwrLetTempCfg->pwrLetNodeNum = pwrLetNodeNum;
    for(index = 0; index < pwrLetNodeNum; index++)
    {
        pwrLetTempCfg->pwrLetTempMode[index].nodeNo = s_tPwrLetNodeTemp.nodeTemp[index].nodeNo;
        pwrLetTempCfg->pwrLetTempMode[index].pwrLetTemp = s_tPwrLetNodeTemp.nodeTemp[index].temp;

        thresholdId = pwrLetTempNode[index];
        ret |= BspGetTempThreshold(chan, thresholdId, &warnThr, &recThr);
        pwrLetTempCfg->pwrLetTempMode[index].tempThrd = warnThr;
        pwrLetTempCfg->pwrLetTempMode[index].tempRecThrd = recThr;
        pwrLetTempCfg->pwrLetTempMode[index].curacy = 10;
        dbgInfoEx("[%s] index:%d, pwrLetTemp:0x%x, slightThrd:%d, slightRecThrd:%d \n", __FUNCTION__, index,
                    s_tPwrLetNodeTemp.nodeTemp[index].temp, warnThr, recThr);
    }

    return ret;
}

static T_PwrOutLetCongfig pwrOutLetCfgRcord = {0};
UINT32 BspGetPwrOutLetConfig(T_PwrOutLetCongfig *pwrOutLetCfg)
{
    static UINT32 flag = 0;
    static CHAR dviceName[] = "TempPwrLet";
    UINT32 length = strnlen_s(dviceName, MAX_DEVICE_LEN);
    UINT32   pwrOutLetNum = 0;
    UINT32   index = 0;
    UINT32   nodeNum = 0;
    UINT32   num = 0;
    UINT32   *record = NULL;

    INPUT_POINTER_CHECK(pwrOutLetCfg);
    if(0 != flag)
    {
        memcpy_s(pwrOutLetCfg, sizeof(T_PwrOutLetCongfig), &pwrOutLetCfgRcord, sizeof(T_PwrOutLetCongfig));
        return BSP_OK;
    }

    nodeNum = BspGetDeviceNodeNum(dviceName, length);  /* 电源连接器节点数量 */
    if (nodeNum > (UINT32_MAX / sizeof(UINT32)))
    {
        dbgErr("[%s]nodeNum:%d, Malloc Out Range!\n", __FUNCTION__, nodeNum);
        return BSP_ERROR;
    }

    record = (UINT32 *) malloc(nodeNum * sizeof(UINT32));
    if (NULL == record)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(record, nodeNum * sizeof(UINT32), 0, nodeNum * sizeof(UINT32));
    if(BSP_OK != BspGetDeviceSerialCfg(dviceName, length, record, nodeNum))
    {
        free(record);
        return BSP_ERROR;
    }

    pwrOutLetNum = BspGetDeviceNum(dviceName, length);  /* 电源插座数量 */
    if(pwrOutLetNum > PWR_MAX_PWR_OUTLET_NUM)
    {
        dbgErr("[%s] PWR_OUTLET_MAX_NUM:%u, pwrOutLetNum(%u) out of range!\n",
                        __FUNCTION__, PWR_MAX_PWR_OUTLET_NUM, pwrOutLetNum);
        free(record);
        return BSP_ERROR;
    }

    pwrOutLetCfgRcord.pwrOutLetNum = pwrOutLetNum;
    for(index = 0; index < pwrOutLetNum; index++)
    {
        for(num = 0; num < nodeNum; num++)
        {
            if(index == record[num])
            {
                pwrOutLetCfgRcord.pwrOutLetMode[index].pwrOutLetNo = index;
                pwrOutLetCfgRcord.pwrOutLetMode[index].pwrLetIndexNodeNum++;
            }
        }
    }
    memcpy_s(pwrOutLetCfg, sizeof(T_PwrOutLetCongfig), &pwrOutLetCfgRcord, sizeof(T_PwrOutLetCongfig));

    flag++;
    free(record);

    return BSP_OK;
}

UINT32 paGainMask[PWR_MAX_PWR_OUTLET_NUM] = {0};     //功放降额对应的通道掩码
UINT32 closeLoopMask[PWR_MAX_PWR_OUTLET_NUM] = {0};  //停闭环对应的通道掩码
/* Started by AICoder, pid:50dfeab27eg2bb114d210916d0e41d0136d96895 */
VOID BspSetPaGainMask(UINT32 index, UINT32 bitMask)
{
    if(index >= PWR_MAX_PWR_OUTLET_NUM)
    {
        dbgInfo("[%s]index:%d,Exceed the Max\n", __FUNCTION__, index);
        return;
    }
    paGainMask[index] = bitMask;

    return;
}
/* Ended by AICoder, pid:50dfeab27eg2bb114d210916d0e41d0136d96895 */

/* Started by AICoder, pid:8887c214d321c84149b90a26106fec1f0280cb57 */
UINT32 BspGetPaGainMask(UINT32 index)
{
    if(index >= PWR_MAX_PWR_OUTLET_NUM)
    {
        dbgInfo("[%s]index:%d,Exceed the Max\n", __FUNCTION__, index);
        return 0x0;
    }

    return paGainMask[index];
}
/* Ended by AICoder, pid:8887c214d321c84149b90a26106fec1f0280cb57 */

/* Started by AICoder, pid:11c80e19f6512b9143a909c9a093c10528c90d45 */
VOID BspSetStopLoopMask(UINT32 index, UINT32 bitMask)
{
    if(index >= PWR_MAX_PWR_OUTLET_NUM)
    {
        dbgInfo("[%s]index:%d,Exceed the Max\n", __FUNCTION__, index);
        return;
    }
    closeLoopMask[index] = bitMask;

    return;
}
/* Ended by AICoder, pid:11c80e19f6512b9143a909c9a093c10528c90d45 */

/* Started by AICoder, pid:w9972f4be62281a1441809c60047fe1e62809e64 */
UINT32 BspGetStopLoopMask(UINT32 index)
{
    if(index >= PWR_MAX_PWR_OUTLET_NUM)
    {
        dbgInfo("[%s]index:%d,Exceed the Max\n", __FUNCTION__, index);
        return 0x0;
    }

    return closeLoopMask[index];
}
/* Ended by AICoder, pid:w9972f4be62281a1441809c60047fe1e62809e64 */

/* Started by AICoder, pid:x9042s0182g39e314efa0b0820aea75e2db4f036 */
/* 上报RRU整机输入电压，过压，欠压门限，对应扇区配置信息 */
UINT32 BspGetPwrInputVoltCfg(T_PwrInputVoltAlarmCfg *pwrInputVoltCfg)
{
    UINT32 index = 0;
    UINT32 pwrInputVoltNodeNum = 0;
    INT32  inputVolt = 0;
    UINT32 paGainBitMask = 0;
    UINT32 closeLoopBitMask = 0;

    INPUT_POINTER_CHECK(pwrInputVoltCfg);

    pwrInputVoltNodeNum = BspGetPwrOutLetDevNum();  /* 获取RRU整机插座数量 */
    if(pwrInputVoltNodeNum > PWR_MAX_PWR_OUTLET_NUM)
    {
        dbgErr("[%s] PWR_MAX_PWR_OUTLET_NUM:%d, pwrInputVoltNodeNum(%d) out of range!\n",
                 __FUNCTION__, PWR_MAX_PWR_OUTLET_NUM, pwrInputVoltNodeNum);
        return BSP_ERROR;
    }

    pwrInputVoltCfg->pwrInputVoltNum = pwrInputVoltNodeNum;
    pwrInputVoltCfg->deratingIsSupport = NO_SUPPORT;
    pwrInputVoltCfg->stopLoopIsSupport = NO_SUPPORT;

    for(index = 0; index < pwrInputVoltNodeNum; index++)
    {
        if(BSP_OK != BspGetPwrVolt(index, &inputVolt))
        {
            dbgErr("[%s] Get index = %d, inputVolt is Failed\n ", __FUNCTION__, index);
        }
        pwrInputVoltCfg->pwrInputVolt[index].pwrInputVoltIndex = index;
        pwrInputVoltCfg->pwrInputVolt[index].volt = inputVolt;
        pwrInputVoltCfg->pwrInputVolt[index].lowAlmThre  = g_aDcAlmThre[0];
        pwrInputVoltCfg->pwrInputVolt[index].lowRecThre  = g_aDcAlmThre[1];
        pwrInputVoltCfg->pwrInputVolt[index].highAlmThre = g_aDcAlmThre[2];
        pwrInputVoltCfg->pwrInputVolt[index].highRecThre = g_aDcAlmThre[3];

        paGainBitMask = BspGetPaGainMask(index);
        if(0 != paGainBitMask)
        {
            pwrInputVoltCfg->deratingIsSupport = SUPPORT;
            pwrInputVoltCfg->pwrInputVolt[index].paGainBitMask = paGainBitMask;
        }

        closeLoopBitMask = BspGetStopLoopMask(index);
        if(0 != closeLoopBitMask)
        {
            pwrInputVoltCfg->stopLoopIsSupport = SUPPORT;
            pwrInputVoltCfg->pwrInputVolt[index].closeLoopBitMask = closeLoopBitMask;
        }

    }

    return BSP_OK;
}
/* Ended by AICoder, pid:x9042s0182g39e314efa0b0820aea75e2db4f036 */

UINT32 BspPwrInputCurrCfgInit(T_PwrInputCurrAlarmCfg *pwrInputCurrCfg)
{
    INPUT_POINTER_CHECK(pwrInputCurrCfg);
    s_pwrInputCurrInfo = pwrInputCurrCfg;
    return BSP_OK;
}

UINT32 BspGetPwrIputCurrConfig(T_PwrInputCurrAlarmCfg *pwrInputCurrCfg)
{
    INPUT_POINTER_CHECK(pwrInputCurrCfg);
    if(NULL == s_pwrInputCurrInfo)
    {
        pwrInputCurrCfg->ability = NO_SUPPORT;
        dbgInfoEx("[%s]The RRU is not Support pwrInpuCurrMap.\n", __FUNCTION__);

        return BSP_OK;
    }

    memcpy_s(pwrInputCurrCfg, sizeof(T_PwrInputCurrAlarmCfg), s_pwrInputCurrInfo, sizeof(T_PwrInputCurrAlarmCfg));

    return BSP_OK;
}

void dbgShowPwrConfig()
{
    UINT32 index = 0;
    UINT32 node = 0;
    UINT32 temp = 0;
    UINT32 warnThr = 0;
    UINT32 recThr = 0;
    UINT32 inputVoltNum = 0;
    UINT32 pwrOutLetNum = 0;
    UINT32 pwrOutLetNo = 0;
    UINT32 pwrLetIndexNodeNum = 0;
    UINT32 pwrLetNodeNum = 0;
    UINT32 boardNum = 0;
    UINT32 supportAbility = 0;
    T_PwrOutLetCongfig pwrOutLetCfg = {0};
    T_PwrLetCongfig pwrLetCfg = {0};
    T_PwrInputVoltAlarmCfg pwrInputVoltCfg = {0};
    T_BoardAlarmCfg boardTempAlarmCfg = {0};

    BspGetPwrOutLetConfig(&pwrOutLetCfg);
    pwrOutLetNum = pwrOutLetCfg.pwrOutLetNum;
    dbgInfo("pwrOutLetNum = %d\n", pwrOutLetNum);
    for(index = 0; index < pwrOutLetNum; index++)
    {
        pwrOutLetNo = pwrOutLetCfg.pwrOutLetMode[index].pwrOutLetNo;
        pwrLetIndexNodeNum = pwrOutLetCfg.pwrOutLetMode[index].pwrLetIndexNodeNum;
        dbgInfo("index = %d,pwrOutLetNo = %d, pwrLetNodeNum = %d\n", index, pwrOutLetNo, pwrLetIndexNodeNum);
    }

    dbgInfo("========================================================\n");
    BspGetPwrLetCfgInfo(&pwrLetCfg);
    pwrLetNodeNum = pwrLetCfg.pwrLetNodeNum;
    dbgInfo("pwrLetNodeNum = %d\n", pwrLetNodeNum);
    for(index = 0; index < pwrLetNodeNum; index++)
    {
        node    = pwrLetCfg.pwrLetTempMode[index].nodeNo;
        temp    = pwrLetCfg.pwrLetTempMode[index].pwrLetTemp;
        warnThr = pwrLetCfg.pwrLetTempMode[index].tempThrd;
        recThr  = pwrLetCfg.pwrLetTempMode[index].tempRecThrd;
        dbgInfo("index:%d,nodeNo:%d,pwrLetTemp:%d,warnThr:%d recThr:%d\n", index, node, temp, warnThr, recThr);
    }

    dbgInfo("========================================================\n");
    BspGetPwrInputVoltCfg(&pwrInputVoltCfg);
    inputVoltNum = pwrInputVoltCfg.pwrInputVoltNum;
    dbgInfo("inputVoltNum:%d, deratingIsSupport:%d, stopLoopIsSupport:%d\n",
             inputVoltNum, pwrInputVoltCfg.deratingIsSupport, pwrInputVoltCfg.stopLoopIsSupport);
    for(index = 0; index < inputVoltNum; index++)
    {
        dbgInfo("index=%d, volt=%d, paGainBitMask:0x%x, closeLoopBitMask:0x%x, low:%d, lowrec:%d, high:%d, highrec:%d\n",
                  pwrInputVoltCfg.pwrInputVolt[index].pwrInputVoltIndex, pwrInputVoltCfg.pwrInputVolt[index].volt,
                  pwrInputVoltCfg.pwrInputVolt[index].paGainBitMask, pwrInputVoltCfg.pwrInputVolt[index].closeLoopBitMask,
                  pwrInputVoltCfg.pwrInputVolt[index].lowAlmThre, pwrInputVoltCfg.pwrInputVolt[index].lowRecThre,
                  pwrInputVoltCfg.pwrInputVolt[index].highAlmThre, pwrInputVoltCfg.pwrInputVolt[index].highRecThre);
    }

    dbgInfo("========================================================\n");
    BspGetBoardTempConfig(&boardTempAlarmCfg);
    boardNum = boardTempAlarmCfg.boardIcNum;
    supportAbility = boardTempAlarmCfg.supportAbility;
    dbgInfo("boardIcNum = %d, supportAbility = %d\n", boardNum, supportAbility);
    for(index = 0; index < boardNum; index++)
    {
        dbgInfo("index=%d, boardNodeNum:%d, slightAlmThre:%d, slightRecThre:%d, seriousAlmThre:%d, seriousRecThre:%d, paBitMask:0x%x, tempOffset:%d\n",
                   boardTempAlarmCfg.boardCfg[index].boardIndex, boardTempAlarmCfg.boardCfg[index].boardNodeNum,
                   boardTempAlarmCfg.boardCfg[index].slightAlmThre, boardTempAlarmCfg.boardCfg[index].slightRecThre,
                   boardTempAlarmCfg.boardCfg[index].seriousAlmThre, boardTempAlarmCfg.boardCfg[index].seriousRecThre,
                   boardTempAlarmCfg.boardCfg[index].paBitMask, boardTempAlarmCfg.boardCfg[index].boardTempOffset);
    }

    return;
}

/* 电源过温告警维测接口 */
UINT32 showdbgpwrovertemp(UINT32 rfChanNum)
{
    UINT32 index = 0;
    INT32  temp = 0;
    UINT32 rfchan  = 0;
    UINT32 tempSensorNum = 0;
    INT32  tempPeak = 0;//温度峰值
    INT32  tempRec = 0; //温度恢复
    UINT32 slightthresholdId[] = {BSP_THRESHOLD_ID_SLIGHTOVER_PWR_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR1_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR2_TEMPER,
                                    BSP_THRESHOLD_ID_SLIGHTOVER_PWR3_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR4_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR5_TEMPER,
                                    BSP_THRESHOLD_ID_SLIGHTOVER_PWR6_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR7_TEMPER};
    UINT32 overthresholdId[] = {BSP_THRESHOLD_ID_OVER_PWR_TEMPER, BSP_THRESHOLD_ID_OVER_PWR1_TEMPER, BSP_THRESHOLD_ID_OVER_PWR2_TEMPER,
                                    BSP_THRESHOLD_ID_OVER_PWR3_TEMPER, BSP_THRESHOLD_ID_OVER_PWR4_TEMPER, BSP_THRESHOLD_ID_OVER_PWR5_TEMPER,
                                    BSP_THRESHOLD_ID_OVER_PWR6_TEMPER, BSP_THRESHOLD_ID_OVER_PWR7_TEMPER};

    if(BSP_OK != BspGetTempAlmSensorNum(&tempSensorNum))
    {
        tempSensorNum = BspGetPwrTempNodeNum();
    }
    if((tempSensorNum > NELEMENTS(slightthresholdId)) || (tempSensorNum > NELEMENTS(overthresholdId)))
    {
       dbgInfo("tempSensorNum:%d is Error\n", tempSensorNum);
       return BSP_ERROR;
    }

    dbgInfo("==================slightOverTempWarning============================\n");
    for(index = 0; index < tempSensorNum; index++)
    {
        BspGetPwrTemp(index, &temp);
        for(rfchan = 0; rfchan < rfChanNum; rfchan++)
        {
            BspGetTempThreshold(rfchan, slightthresholdId[index], &tempPeak, &tempRec);
            dbgInfo("temp[%d]=[%d]\t slightPeak = [%d]\t slightRec= [%d]\t\n", index, temp, tempPeak, tempRec);
        }
    }

    dbgInfo("================== SevereOverTempWarning===========================\n");
    for(index = 0; index < tempSensorNum; index++)
    {
        BspGetPwrTemp(index, &temp);
        for(rfchan = 0; rfchan < rfChanNum; rfchan++)
        {
            BspGetTempThreshold(rfchan, overthresholdId[index], &tempPeak, &tempRec);
            dbgInfo("temp[%d]=[%d]\t overPeak = [%d]\t overRec= [%d]\t\n", index, temp, tempPeak, tempRec);
        }
    }

    return BSP_OK;
}

UINT32 BspGetPwrOutLetDevNum(VOID)
{
    static UINT32 pwrOutLetNum = 0;
    static CHAR dviceName[] = "TempPwrLet";
    UINT32 length = strnlen_s(dviceName, MAX_DEVICE_LEN);

    if(0 != pwrOutLetNum)
    {
        return pwrOutLetNum;
    }

    pwrOutLetNum = BspGetDeviceNum(dviceName, length);  /* 电源插座数量 */

    return pwrOutLetNum;
}

UINT32 BspPwrSupplyMapInit(T_PwrSupplyCfg *pwrSupplyMap)
{
    INPUT_POINTER_CHECK(pwrSupplyMap);
    s_pwrSupplyMapChnInfo = pwrSupplyMap;
    return BSP_OK;
}

UINT32 BspGetPwrSupplyAbilityCfg(T_PwrSupplyCfg *pwrSupplyMap)
{
    INPUT_POINTER_CHECK(pwrSupplyMap);
    if(NULL == s_pwrSupplyMapChnInfo)
    {
        dbgInfoEx("[%s]The RRU is not Support pwrSupplyMap\n", __FUNCTION__);
        pwrSupplyMap->supportAbility = NO_SUPPORT;

        return BSP_OK;
    }

    memcpy_s(pwrSupplyMap, sizeof(T_PwrSupplyCfg), s_pwrSupplyMapChnInfo, sizeof(T_PwrSupplyCfg));

    return BSP_OK;
}

/* Started by AICoder, pid:1f542088c15c463146ba0946d0283815f37920c9 */
/**
 * @brief 获取电源支持自动启停状态。
 *
 * 该函数检查系统是否支持辅助电源。如果支持，则返回BSP_OK。
 * 否则，它会进一步检查电源模块，并返回相应的状态。
 *
 * @return UINT32: BSP_OK表示支持自动启停，其它值不支持。
 */
UINT32 BspGetPwrSupportStatus(void)
{
    /* 检查是否支持辅助电源 */
    if (BspIsSupportAuxPow())
    {
        return BSP_OK;
    }

    /* 如果不支持辅助电源，检查电源版本，D42 1.15及以上才能支持自动启停 */
    return BspGetIsSupportPwroff();
}
/* Ended by AICoder, pid:1f542088c15c463146ba0946d0283815f37920c9 */

UINT32 BspGetPwrUsrVerData(UINT32 index)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    int snpRet;

    snpRet = snprintf_s(bufName, sizeof(bufName), "PmbAdc%d", index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspHalGetPwrUsrVerData(devid);
}

/*设置电源管理芯片系数*/
UINT32 BspSetPmbCoef(UINT32 index, UINT32 coef)
{
    char  bufName[10] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    snpRet = snprintf_s(bufName, sizeof(bufName), "PmbAdc%u", index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPmbKrScale(devid, coef);
}

/* Started by AICoder, pid:55c4d360ba22d7f1445e08c860b6901ec06364dc */
/*设置电源管理芯片允许设置的电压范围*/
UINT32 BspSetPmbVoltGate(UINT32 index, UINT32 lowVoltMv, UINT32 highVoltMv)
{
    char  bufName[10] ={0};
    UINT32 devid = 0;
    int snpRet = 0;

    snpRet = snprintf_s(bufName, sizeof(bufName), "PmbAdc%u", index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetPmbVoltRange(devid, lowVoltMv, highVoltMv);
}
/* Ended by AICoder, pid:55c4d360ba22d7f1445e08c860b6901ec06364dc */

UINT32 BspPwrDataWrite(VOID)
{
    char   bufName[PWR_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    UINT32 index = 0;
    int snpRet;

    snpRet = snprintf_s(bufName, sizeof(bufName), "PmbAdc%d", index);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspHalPwrDataWrite(devid);
}

UINT32 BspWriteStringToSmartEeprom(UINT32 offset, CHAR* buf, UINT32 length)
{
    UINT32 i = 0;
    UINT32 ulDevId = 0;
    UINT32 bufLen = 0;
    UCHAR  checkSum = 0;
    UINT32 ulRetVal = 0;
    int snpRet = 0;
    char   bufName[PWR_EEPROM_NAME_LEN] ={0};

    INPUT_POINTER_CHECK(buf);
    if (length >= PWR_EEPROM_NAME_LEN)
    {
        dbgErr("%s return Error! \n",__FUNCTION__);
        return BSP_ERROR;
    }

    while(*(buf+bufLen) != '\0')
    {
        bufLen++;
    }

    snpRet = snprintf_s(bufName, sizeof(bufName), "EepromRpdc%d", 1);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    ulDevId = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(ulDevId);

    ulRetVal = BspSetEepromInfo(ulDevId, offset, buf, bufLen);
    if(length > bufLen)
    {
        ulRetVal |= BspErasePwrEeprom(ulDevId, offset+bufLen, 0x20, length-bufLen);
    }
    for (i = 0; i < length; i++)
    {
      if(i < bufLen)
      {
          checkSum = checkSum + buf[i];
      }
      else
      {
          checkSum = checkSum + 0x20;
      }
    }
    ulRetVal |= BspErasePwrEeprom(ulDevId, offset+length, checkSum,1);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s Write Error length[%d]!\n",__FUNCTION__, bufLen);
    }
    return ulRetVal;
}

UINT32 BspReadStringToSmartEeprom(UINT32 addr, CHAR*  buf, UINT32 len)
{
    UINT32 index=0;
    UINT32 ulDevId = 0;
    UINT32 ret = BSP_OK;
    int snpRet = 0;
    char   bufName[PWR_EEPROM_NAME_LEN] ={0};
    INPUT_POINTER_CHECK(buf);

    snpRet = snprintf_s(bufName, sizeof(bufName), "EepromRpdc%d", 1);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    ulDevId = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(ulDevId);

    ret = BspGetEepromInfo(ulDevId, 0,&buf[0], len);
    if(ret !=BSP_OK)
    {
        return ret;
    }

    for (index = 0; index < len; index++)
    {
        if ((index % 0x10) == 0)
        {
            //coverity[cert_int30_c_violation:SUPPRESS]
            //coverity[cert_str34_c_violation:SUPPRESS]
            dbgInfoEx("\nEeprom[0X%04X]:%02X", addr + index, buf[index]);
        }
        //coverity[cert_str34_c_violation:SUPPRESS]
        dbgInfoEx("%02X", buf[index]);
    }
    dbgInfoEx("\n");
    return ret;
}

//D42配置3v3管脚发起整机掉电复位
UINT32 BspSetCtrlPwrReStart(VOID)
{
    return BspHalAdaptSetCrmRmtPwdRstTestEn(0x3);
}

UINT32 BspSetPwrMcuFeedDog(void)
{
    CHAR   bufName[PWR_PARA_LENGTH] = {0};
    UINT32 devid = 0;
    INT32  snpRet = 0;

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    return BspSetPowerMcuFeedDog(devid);
}

UINT32 BspSetPwrSelfRescueEn(UINT8 enFlag)
{
    CHAR   bufName[PWR_PARA_LENGTH] = {0};
    UINT32 devid = 0;
    INT32  snpRet = 0;

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    return BspSetPowerSelfRescueEn(devid, enFlag);
}

UINT32 BspGetPwrSelfRescueTimes(UINT16 *times)
{
    CHAR   bufName[PWR_PARA_LENGTH] = {0};
    UINT32 devid = 0;
    INT32  snpRet = 0;

    INPUT_POINTER_CHECK(times);
    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    return BspGetPowerSelfRescueTimes(devid, times);
}

static UINT32 BspGetPwrSelfRescueTimesTest(void)
{
    UINT32 retVal = BSP_OK;
    UINT16 times = 0;

    retVal = BspGetPwrSelfRescueTimes(&times);
    dbgInfo("Pwr Self Rescue Times = %d\n", times);
    return retVal;
}

UINT32 BspGetPwrSelfRescueEnFlag(void)
{
    CHAR   bufName[PWR_PARA_LENGTH] = {0};
    UINT32 devid = 0;
    INT32  snpRet = 0;
    UINT8  flag = 0;
    UINT32 retVal = BSP_OK;

    snpRet = snprintf_s((CHAR*)bufName,sizeof(bufName),"PwrMcu");
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);

    retVal = BspGetPowerSelfRescueEnFlag(devid, &flag);
    dbgInfo("Pwr Self Rescue En Flag = %d\n", flag);
    return retVal;
}

UINT32 BspSetPwrMcuTempWetCapacity(UINT32 optNum, UINT32 tempWetFlag)
{
    UINT32 devid = BspGetPwrMcuDevIdNew();
    return BspSetPwrMcuCapacity(devid, optNum, tempWetFlag);
}

UINT32 BspGetPwrMcuTempWetCapacity(UINT32 *pOptNum, UINT32 *pTempWetFlag)
{
    UINT32 devid = BspGetPwrMcuDevIdNew();

    INPUT_POINTER_CHECK(pOptNum);
    INPUT_POINTER_CHECK(pTempWetFlag);
    return BspGetPwrMcuCapacity(devid, pOptNum, pTempWetFlag);
}

UINT32 BspGetMcuTempHumi(INT32 *temp, INT32 *humi)
{
    UINT32 devid = BspGetPwrMcuDevIdNew();

    INPUT_POINTER_CHECK(temp);
    INPUT_POINTER_CHECK(humi);
    return BspGetMcuTempHumiData(devid, temp, humi);
}

/* Started by AICoder, pid:2e3a10a2fdx9010148e9093410a8ac3a9da638d6 */
UINT32 BspGetOptiMizaPwrTemp(UINT32 index, INT32 *optiMizaPwrTemp)
{
    UINT32 retVal = BSP_OK;
    INT32  pwrTemp = 0;
    INT32  OptiMizaTemp = 0;
    T_DefRruTempOffsetPara tempOffset = {0};
    INT32  pwrOffset = 0;
    UINT32 pwrTempType[PWR_MAX_TEMP_NUM] = {E_TEMP_TYPE_PWR, E_TEMP_TYPE_PWR1, E_TEMP_TYPE_PWR2, E_TEMP_TYPE_PWR3,
                                            E_TEMP_TYPE_PWR4, E_TEMP_TYPE_PWR5, E_TEMP_TYPE_PWR6, E_TEMP_TYPE_PWR7};
    INPUT_POINTER_CHECK(optiMizaPwrTemp);

    if(index >= PWR_MAX_TEMP_NUM)
    {
        dbgErr("[%s] PwrIndex = %d, Out of range\n", __FUNCTION__, index);
        return BSP_ERROR;
    }

    retVal = BspGetPwrTemp(index, &pwrTemp);
    CHECK_RETVAL(BspGetPwrTemp, retVal);

    BspGetTempOffset(&tempOffset);
    pwrOffset = tempOffset.powerTempOffset;
    if(0 == pwrOffset)  //如果提高偏移量为0,无需美化上报真实值
    {
        *optiMizaPwrTemp = pwrTemp;
        dbgInfoEx("[%s]pwrTemp=%d,optiMizaPwrTemp=%d, No Needing Optimiza\n", __FUNCTION__, pwrTemp, *optiMizaPwrTemp);
        return retVal;
    }

    retVal = BspRruTempOptiMiza(index, pwrTemp, pwrTempType[index], pwrOffset, &OptiMizaTemp);
    CHECK_RETVAL(BspRruTempOptiMiza, retVal);

    *optiMizaPwrTemp = OptiMizaTemp;

    return retVal;
}
/* Ended by AICoder, pid:2e3a10a2fdx9010148e9093410a8ac3a9da638d6 */

UINT32 BspGetVoltAlmThresPara(T_VoltThresAdjPara **thresAdjPara, UINT32 *paraNum)
{
    INPUT_POINTER_CHECK(thresAdjPara);
    INPUT_POINTER_CHECK(paraNum);

    *thresAdjPara = s_voltThresAdjPara;
    *paraNum = NELEMENTS(s_voltThresAdjPara);

    return BSP_OK;
}

/* Started by AICoder, pid:88a5cq468fu87aa147160bdc6026754bbed17884 */
UINT32 BspGetPwrInputCurrent(UINT32 index, INT32 *current)
{
    UINT32 ret = BSP_OK;
    INT32  power = 0;
    INT32  volt  = 0;

    INPUT_POINTER_CHECK(current);
    INPUT_POINTER_CHECK(s_pwrInputCurrInfo);

    if (SUPPORT != s_pwrInputCurrInfo->ability)
    {
        dbgInfoEx("[%s]RRU is no Support the Overcurrent detection\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (INPUTCURRENT_CAL_OBTAIN == s_pwrInputCurrInfo->testType)
    {
        ret |= BspGetRruConsumedPower(index, &power);
        ret |= BspGetPwrVolt(index, &volt);
        if ((BSP_OK != ret) || (power < 0) || (volt < 0))
        {
            dbgErr("[%s]index:%d, power:%d, volt:%d, is Error\n", __FUNCTION__, index, power, volt);
            return ret;
        }

        if (0 != volt)
        {
            *current = round(((float)power/volt)*1000);
            dbgInfoEx("[%s]index:%d, power:%d, volt:%d, current:%d\n", __FUNCTION__, index, power, volt, *current);
            return ret;
        }
    }
    else
    {
        ret |= BspGetPwrCurr(index, current);
        dbgInfoEx("[%s]index:%d,current:%d\n", __FUNCTION__, index, *current);
        return ret;
    }

    return BSP_ERROR;
}
/* Ended by AICoder, pid:88a5cq468fu87aa147160bdc6026754bbed17884 */
/*pwrIndex:电源第几路，即电源砖编号  tempType:0 副边 1源边      pTempIndex： BspGetPwrTemp的入参编号 这里写死 此处约束特性参数表*/
/* Started by AICoder, pid:k9b7a2eb7ay254414d1b0b62a055f902e8360dd3 */
UINT32 BspGetPwrTempIndex(UINT32 pwrIndex, UINT32 tempType, UINT32 *pTempIndex)
{
    INPUT_POINTER_CHECK(pTempIndex);
    *pTempIndex = pwrIndex * 2 + tempType;
    return BSP_OK;
}
/* Ended by AICoder, pid:k9b7a2eb7ay254414d1b0b62a055f902e8360dd3 */

/* Started by AICoder, pid:i47e9d9e9fm729a141120a50b0bea14492d2de42 */
UINT32 BspGetPwrVoltCaliByIndex(UINT32 index, INT32 lVolt, INT32 *VoltK, INT32 *VoltB)
{
    T_PwrCaliData *ptPwrCali = NULL;
    INT32 lVoltK = 0;
    INT32 lVoltB = 0;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(VoltK);
    INPUT_POINTER_CHECK(VoltB);

    if(index >= TBL_PWR_CALI_PWR_NUM_MAX)
    {
        dbgErr("[%s]index = %d, Exceed the MaxNum\n", __FUNCTION__, index);
        return BSP_ERROR;
    }

    ptPwrCali = (T_PwrCaliData *)_BspGetCalibData(TBL_KIND_OF_PWRCALI,0);
    INPUT_POINTER_CHECK(ptPwrCali);
    _PWRTEMPALMFILE_LOADED_CHECK(ptPwrCali);

    if(ptPwrCali->tHeader[index].ulVoltFlectionPoint == 0)
    {
        lVoltK = ptPwrCali->tHeader[index].lPwrVoltCali[4];
        lVoltB = ptPwrCali->tHeader[index].lPwrVoltCali[5];
    }
    else
    {
        for(loop=0; loop<ptPwrCali->tHeader[index].ulVoltFlectionPoint; loop++)
        {
            if(lVolt >= ptPwrCali->tHeader[index].lPwrVoltFlectionValue[loop])
            {
                lVoltK = ptPwrCali->tHeader[index].lPwrVoltCali[loop*6+4];
                lVoltB = ptPwrCali->tHeader[index].lPwrVoltCali[loop*6+5];
                break;
            }
        }
        if(loop==ptPwrCali->tHeader[index].ulVoltFlectionPoint)
        {
            lVoltK = ptPwrCali->tHeader[index].lPwrVoltCali[loop*6+4];
            lVoltB = ptPwrCali->tHeader[index].lPwrVoltCali[loop*6+5];
        }
    }
    dbgInfoEx("lVolt =%d loop =%d\n", lVolt,loop);
    *VoltK = lVoltK;
    *VoltB = lVoltB;

    return BSP_OK;
}
/* Ended by AICoder, pid:i47e9d9e9fm729a141120a50b0bea14492d2de42 */

/* Started by AICoder, pid:mfd8a7b8a2d9be814485081ac002c523210558f4 */
UINT32 BspCaliPwrVoltByIndex(UINT32 index, INT32 *pVolt)
{
    INT32 VoltK = 0;
    INT32 VoltB = 0;
    INT32 cali = 0;
    INT32 raw  = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pVolt);

    retVal = BspGetPwrVoltCaliByIndex(index, *pVolt, &VoltK, &VoltB);
    if (BSP_OK != retVal)
    {
        VoltK = 1000;
        VoltB = 0;
    }
    dbgInfoEx("volt K=%d B=%d\n", VoltK, VoltB);

    raw = *pVolt;
    cali = raw*VoltK/1000 + VoltB;
    *pVolt = cali;

    dbgInfoEx("volt raw= %dmV clai = %dmV\n",raw,cali);

    return BSP_OK;
}
/* Ended by AICoder, pid:mfd8a7b8a2d9be814485081ac002c523210558f4 */

/* Started by AICoder, pid:56e7bf24e9i8151148240a819024bd491c720fcd */
UINT32 BspGetPwrPowCaliByIndex(UINT32 index, INT32 lPower, INT32 *PowK, INT32 *PowB)
{
    T_PwrCaliData *ptPwrCali = NULL;
    INT32 lPowK = 0;
    INT32 lPowB = 0;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(PowK);
    INPUT_POINTER_CHECK(PowB);
    if(index >= TBL_PWR_CALI_PWR_NUM_MAX)
    {
        dbgErr("[%s]index = %d, Exceed the MaxNum\n", __FUNCTION__, index);
        return BSP_ERROR;
    }

    ptPwrCali = (T_PwrCaliData *)_BspGetCalibData(TBL_KIND_OF_PWRCALI,0);
    INPUT_POINTER_CHECK(ptPwrCali);
    _PWRTEMPALMFILE_LOADED_CHECK(ptPwrCali);

    if(ptPwrCali->tHeader[index].ulPwrFlectionPoint == 0)
    {
        lPowK = ptPwrCali->tHeader[index].lPwrPowerCali[4];
        lPowB = ptPwrCali->tHeader[index].lPwrPowerCali[5];
    }
    else
    {
        for(loop=0; loop<ptPwrCali->tHeader[index].ulPwrFlectionPoint; loop++)
        {
            if(lPower >= ptPwrCali->tHeader[index].lPwrPowerFlectionValue[loop])
            {
                lPowK = ptPwrCali->tHeader[index].lPwrPowerCali[loop*6+4];
                lPowB = ptPwrCali->tHeader[index].lPwrPowerCali[loop*6+5];
                break;
            }
        }
        if(loop==ptPwrCali->tHeader[index].ulPwrFlectionPoint)
        {
            lPowK = ptPwrCali->tHeader[index].lPwrPowerCali[loop*6+4];
            lPowB = ptPwrCali->tHeader[index].lPwrPowerCali[loop*6+5];
        }
    }
    dbgInfoEx("lPower =%d loop =%d\n", lPower,loop);
    *PowK = lPowK;
    *PowB = lPowB;

    return BSP_OK;
}
/* Ended by AICoder, pid:56e7bf24e9i8151148240a819024bd491c720fcd */

/* Started by AICoder, pid:48262a148cg0ced14f150ad2307a4f24c5722684 */
UINT32 BspCaliConsumedPowerByIndex(UINT32 index, INT32 *pPower)
{
    INT32 PowK = 0;
    INT32 PowB = 0;
    INT64 cali = 0;
    INT32 raw  = 0;

    INPUT_POINTER_CHECK(pPower);

    if(BSP_OK != BspGetPwrPowCaliByIndex(index, *pPower,&PowK, &PowB))
    {
        PowK = 1000;
        PowB = 0;
    }
    dbgInfoEx("pow K=%d B=%d\n", PowK, PowB);

    raw = *pPower;
    cali = (INT64)raw*PowK/1000+ PowB;
    *pPower = (INT32)cali;
    dbgInfoEx("pow raw = %dmW cali = %lldmW\n",raw,cali);

    return BSP_OK;
}
/* Ended by AICoder, pid:48262a148cg0ced14f150ad2307a4f24c5722684 */

/* Started by AICoder, pid:w7fefxf84905c32149350999402ebb022859a1c0 */
UINT32 BspSetPwrInputSwitch(UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal |= BspRegWr(0, REG_PWR_INPUT_SWITCH, 0, sw);

    return retVal;
}
/* Ended by AICoder, pid:w7fefxf84905c32149350999402ebb022859a1c0 */

/* Started by AICoder, pid:b309cha5bd3cde7148610b5460eb5416d8b5e06f */
UINT32 BspGetPwrInputAlarmSta(UINT32 *status)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(status);

    retVal |= BspRegRd(0, REG_PWR_INPUT_MONITOR, 0, status);

    dbgInfoEx("[%s]PwrInputSta:0x%x", __FUNCTION__, *status);

    return retVal;
}
/* Ended by AICoder, pid:b309cha5bd3cde7148610b5460eb5416d8b5e06f */

/* Started by AICoder, pid:l3047x52f8c6d4114dd909f9b4487b0432c23325 */
UINT32 boardSupportPwrUpdate = NO_SUPPORT;
VOID BspSetSupportPwrUpdateBoard(UINT32 flag)
{
    boardSupportPwrUpdate = flag;
    return;
}

UINT32 BspGetSupportPwrUpdateFlag()
{
    return boardSupportPwrUpdate;
}

UINT32 BspSetPwrUpdateTimesFromFile(UINT32 num)
{
    INT32 ret = 0;
    CHAR updateCount[KEY_LEN] = {0};

    if(BSP_OK != BspIsFileExist(BSP_PWR_UPGRADE_FILE))
    {
        BspLog(LOG_LEVEL_0, "%s: File is No_Exist\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ret = snprintf_s(updateCount, sizeof(updateCount), "%u", num);
    SNPRINTF_S_CHECK(ret, sizeof(updateCount));

    ret = ConfigSetKey(BSP_PWR_UPGRADE_FILE, PWR_UPDATE_TITLE, UPDATE_NUM_RECORD_KEY, updateCount);
    if(BSP_OK != ret)
    {
        dbgErr("[%s]: ConfigSetKey failed, ret=%d\n", __FUNCTION__, ret);
        return BSP_ERROR;
    }

    return BSP_OK;
}

//  获取 PwrUpgradeFlag 字段值
UINT32 BspGetPwrUpdateTimesFromFile(UINT32 *pTimes)
{
    INT32 ret = 0;
    CHAR recordKey[KEY_LEN] = {0};

    INPUT_POINTER_CHECK(pTimes);

    if(BSP_OK != BspIsFileExist(BSP_PWR_UPGRADE_FILE))
    {
        BspLog(LOG_LEVEL_0, "%s: File is No_Exist\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ret = ConfigGetKeyEx(BSP_PWR_UPGRADE_FILE, PWR_UPDATE_TITLE, UPDATE_NUM_RECORD_KEY, recordKey, sizeof(recordKey));
    if(BSP_OK != ret)
    {
        BspLog(LOG_LEVEL_0, "%s: ConfigGetKeyEx %s failed, ret=%d\n", __FUNCTION__, UPDATE_NUM_RECORD_KEY, ret);
        return BSP_ERROR;
    }

    *pTimes = BspAtoi(recordKey, 0);

    return BSP_OK;
}

UINT32 BspCreatePwrUpdateRecordFile(VOID)
{
    INT32 ret = 0;
    CHAR updateCount[KEY_LEN] = {0};

    ret = snprintf_s(updateCount, sizeof(updateCount), "%u", 0);
    SNPRINTF_S_CHECK(ret, sizeof(updateCount));

    ret = ConfigSetKey(BSP_PWR_UPGRADE_FILE, PWR_UPDATE_TITLE, UPDATE_NUM_RECORD_KEY, updateCount);
    if(BSP_OK != ret)
    {
        dbgErr("[%s]: ConfigSetKey failed, ret=%d\n", __FUNCTION__, ret);
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspAddPwrUpdateTimes(VOID)
{
    UINT32 updateCount = 0;
    UINT32 ret = BSP_OK;

    if(BSP_OK != BspIsFileExist(BSP_PWR_UPGRADE_FILE))
    {
        if(BSP_OK != BspCreatePwrUpdateRecordFile()) //创建ini文件，并设置升级次数初始值为0
        {
            BspLog(LOG_LEVEL_0, "[%s]Create the INI File is Failed\n", __FUNCTION__);
            return BSP_ERROR;
        }
        BspLog(LOG_LEVEL_0, "[%s]Create the INI File is Success\n", __FUNCTION__);
    }

    ret = BspGetPwrUpdateTimesFromFile(&updateCount);
    BspLog(LOG_LEVEL_0, "%s: updateCount[%u], ret[%u]\n", __FUNCTION__, updateCount, ret);

    if (BSP_OK != ret)/*UpdateNum字段键值获取失败*/
    {
        return BSP_ERROR;
    }

    if (PWR_UPDATE_TIMES_THESHOLD > updateCount)/*电源升级次数累加,大于等于3之后不在更新字段*/
    {
        ret = BspSetPwrUpdateTimesFromFile(updateCount + 1);
    }
    else
    {
        BspLog(LOG_LEVEL_0, "%s:updateCount[%u]\n", __FUNCTION__, updateCount);
        return BSP_ERROR;
    }
    BspLog(LOG_LEVEL_0, "%s:ret[%u]\n", __FUNCTION__, ret);

    return ret;
}

static CHAR *pwrNeedUpdateVer_48V[] = {"1.11", "1.12"};
static CHAR *pwrNeedUpdateVer_12V[] = {"1.09"};
UINT32 BspChkPwrVer(VOID)
{
    UINT32 ret = BSP_OK;
    INT strRet  = 0;
    UINT32 loop = 0;
    UINT32 pwrDevIdx = 0;
    UCHAR  pwrVerInfo[PWR_SOFT_VER_LEN] = {0};
    UINT32 pwrSubIndex = 0;

    for (pwrSubIndex = 1; pwrSubIndex <= 3; pwrSubIndex++)
    {
        memset_s(pwrVerInfo, sizeof(pwrVerInfo), 0, sizeof(pwrVerInfo));
        pwrDevIdx = BspGetPwrDevId(pwrSubIndex);
        ret = BspGetPwrVer(pwrDevIdx, 0, &pwrVerInfo[0], NELEMENTS(pwrVerInfo));
        if (BSP_OK != ret)
        {
            dbgInfo("%s: BspGetPwrVer[%u]failed\n", __FUNCTION__, pwrSubIndex);
            BspLog(LOG_LEVEL_0, "%s:BspGetPwrVer[%u]failed\n", __FUNCTION__, pwrSubIndex);
            continue;
        }

        dbgInfo("%s:pwrSubIndex:[%u], PwrVer[%s]\n", __FUNCTION__, pwrSubIndex, &pwrVerInfo[1]);
        BspLog(LOG_LEVEL_0, "%s:pwrSubIndex:[%u], PwrVer[%s]\n", __FUNCTION__, pwrSubIndex, &pwrVerInfo[1]);
        for(loop = 0; loop < NELEMENTS(pwrNeedUpdateVer_48V) && (3 != pwrSubIndex); loop++)//48V砖电源版本比对判定是否升级
        {
            strRet = memcmp((const char*)&pwrVerInfo[1], pwrNeedUpdateVer_48V[loop], 4);
            if(0 == strRet)
            {
                dbgInfo("%s:48V,pwrSubIndex:[%u], PwrVer[%s]\n", __FUNCTION__, pwrSubIndex, &pwrVerInfo[1]);
                BspLog(LOG_LEVEL_0, "%s:48V,pwrSubIndex:[%u], PwrVer[%s]\n", __FUNCTION__, pwrSubIndex, &pwrVerInfo[1]);
                return BSP_OK;
            }
        }

        for(loop = 0; loop < NELEMENTS(pwrNeedUpdateVer_12V) && (3 == pwrSubIndex); loop++)//12V砖电源版本比对判定是否升级
        {
            strRet = memcmp((const char*)&pwrVerInfo[1], pwrNeedUpdateVer_12V[loop], 4);
            if(0 == strRet)
            {
                dbgInfo("%s:12V,pwrSubIndex:[%u], PwrVer[%s]\n", __FUNCTION__, pwrSubIndex, &pwrVerInfo[1]);
                BspLog(LOG_LEVEL_0, "%s:12V,pwrSubIndex:[%u], PwrVer[%s]\n", __FUNCTION__, pwrSubIndex, &pwrVerInfo[1]);
                return BSP_OK;
            }
        }
    }
    BspLog(LOG_LEVEL_0, "%s failed No need Update!!!\n", __FUNCTION__);

    return BSP_ERROR;
}

VOID BspChkIsSupportFromFile(UINT32 *needUpdateFlag)
{
    UINT32 updateCount = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK_RETURN(needUpdateFlag);

    ret = BspGetPwrUpdateTimesFromFile(&updateCount);
    BspLog(LOG_LEVEL_0, "%s: updateCount[%u],ret[%u]\n", __FUNCTION__, updateCount, ret);

    if(BSP_OK != ret)
    {
        *needUpdateFlag = SUPPORT;
        return;
    }

    if (PWR_UPDATE_TIMES_THESHOLD <= updateCount)  /* 电源升级最多3次,不需要升级,其他情况均需升级 */
    {
        *needUpdateFlag = NO_SUPPORT;
        return;
    }

    *needUpdateFlag = SUPPORT;
    return;
}

UINT32 BspIsNeedPwrUpgrade(UINT32 *updateFlag)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 chkVerRet = BSP_OK;
    UINT32 fileSupportFlag = 0;
    CHAR *strRet = NULL;
    CHAR *strRet1 = NULL;
    CHAR pwrModuleName[PWR_SUB_NAME_LEN_MAX] = {0};

    INPUT_POINTER_CHECK(updateFlag);

    *updateFlag = PWR_NONEED_UPDATE;/*初值不用升级*/

    /*不支持电源升级的规格直接返回*/
    if(NO_SUPPORT == BspGetSupportPwrUpdateFlag())
    {
        *updateFlag = PWR_NONEED_UPDATE;
        BspSystem("rm -rf /pwrupdate/");  /*删除电源版本*/
        BspLog(LOG_LEVEL_0, "%s>>No support pwr Upgrade, delete pwr version\n", __FUNCTION__);
        return BSP_OK;
    }

    /*是否已经升级过判断：升级次数记录文件已存在且UpdateNum=字段值大于等于3时不需要升级*/
    BspChkIsSupportFromFile(&fileSupportFlag);
    if(NO_SUPPORT == fileSupportFlag)
    {
        *updateFlag = PWR_NONEED_UPDATE;
        BspSystem("rm -rf /pwrupdate/");  /*删除电源版本*/
        BspLog(LOG_LEVEL_0, "%s>>Pwr already upgrade,not need Upgrade, delete pwr version\n",__FUNCTION__);
        return BSP_OK;
    }

    /*判断是否是对应电源版本*/
    chkVerRet = BspChkPwrVer();
    if (BSP_OK != chkVerRet)
    {
        *updateFlag = PWR_NONEED_UPDATE;
        BspSystem("rm -rf /pwrupdate/");  /*删除电源版本*/
        BspLog(LOG_LEVEL_0, "%s>>Pwr is not upgrade ver, delete pwr version\n",__FUNCTION__);
        return BSP_OK;
    }

    /*判断电源版模块名称是否为PL1500-M48A和PL2200-M48A，且版本号在对应范围内*/
    retVal = BspGetSubUnitNameNew((UCHAR *)pwrModuleName);
    if(BSP_OK != retVal)
    {
        *updateFlag = PWR_NONEED_UPDATE;
        BspSystem("rm -rf /pwrupdate/");  /*删除电源版本*/
        BspLog(LOG_LEVEL_0, "%s>>BspGetSubUnitNameNew is error, delete pwr version\n",__FUNCTION__);
        return BSP_OK;
    }

    strRet = strstr(pwrModuleName, "PL1500-M48A");
    if (NULL != strRet)
    {
        *updateFlag = PWR_NEED_UPDATE;
        /*设置升级文件为：/pwrupdate/pwr1500_v1.18.swv*/
        BspSetPwrVersionPath(PWR_SUBUNIT_PL1500_118_PATH, strnlen_s(PWR_SUBUNIT_PL1500_118_PATH, PWR_VER_PATH_MAX_LEN));
        BspPwrVerPathChange(PWR_VER_PATH_SET); /*修改电源版本路径为/pwrupdate/pwr1500_v1.18.swv*/
        BspLog(LOG_LEVEL_0, "%s>>Pwr is PL1500-M48A, need Upgrade!\n",__FUNCTION__);
        return BSP_OK;
    }
    strRet1 = strstr(pwrModuleName, "PL2200-T48A");
    if (NULL != strRet1)
    {
        *updateFlag = PWR_NEED_UPDATE;
        /*设置升级文件为：/pwrupdate/pwr2200_v1.18.swv*/
        BspSetPwrVersionPath(PWR_SUBUNIT_PL2200_118_PATH, strnlen_s(PWR_SUBUNIT_PL2200_118_PATH, PWR_VER_PATH_MAX_LEN));
        BspPwrVerPathChange(PWR_VER_PATH_SET); /*修改电源版本路径为/pwrupdate/pwr2200_v1.18.swv*/
        BspLog(LOG_LEVEL_0, "%s>>Pwr is PL2200-M48A, need Upgrade!\n",__FUNCTION__);
        return BSP_OK;
    }

    *updateFlag = PWR_NONEED_UPDATE;
    BspSystem("rm -rf /pwrupdate/");  /*删除电源版本*/
    BspLog(LOG_LEVEL_0, "%s>>pwrModuleName[%s], Pwr not need Upgrade, delete pwr version\n",__FUNCTION__, pwrModuleName);

    return BSP_OK;
}

UINT32 BspPowerUpgradeStart(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 updateFlag = 0;

    BspLog(LOG_LEVEL_0, "%s Start!!!!!\n", __FUNCTION__);

    retVal = BspIsNeedPwrUpgrade(&updateFlag);
    CHECK_RETVAL(BspIsNeedPwrUpgrade, retVal);
    if(PWR_NEED_UPDATE == updateFlag)
    {
        BspLog(LOG_LEVEL_0, "%s Start Pwr Update\n", __FUNCTION__);
        /*将电源版本激活等待时间改为6min*/
        BspBoardUpdatePowerWaitTime(6);
        /*创建升级文件，升级12V电源砖过程中可能会复位因此先创建文件*/
        retVal = BspAddPwrUpdateTimes();
        if(BSP_OK != retVal)
        {
            dbgErr("%s BspAddPwrUpdateTimes err\n", __FUNCTION__);
            BspLog(LOG_LEVEL_0, "%s BspAddPwrUpdateTimes err\n", __FUNCTION__);
            return BSP_ERROR;
        }
        //给OSS置标志(时间又20min提升置30min)，为了防止电源升级过程中发生看门狗复位
        //同时BSP内部也用此标志，在电源升级过程中BspPowerStatusThread任务停止(访问电源IIC的任务停止)
        BspSetPwrUpgradeFlag(PWR_NEED_UPDATE);
        retVal = PwrUpdateTestNew();
        if(BSP_OK == retVal)
        {
            dbgInfo("%s>>Power Upgrade Success!\n",__FUNCTION__);
            BspLog(LOG_LEVEL_0, "%s>>Power Upgrade Success! Status: %#x\n",__FUNCTION__,PWR_UPDATE_SUCCESS);
            BspCtrlPm(0,0);
        }
        else
        {
            dbgInfo("%s>>Power Upgrade Failed!\n",__FUNCTION__);
            BspLog(LOG_LEVEL_0, "%s>>Power Upgrade Failed! Status: %#x\n",__FUNCTION__, PWR_UPDATE_FAILED);
        }
        //BSP内部用此标志，在电源升级完成后任务开启(此时这个标志状态OSS不会在继续获取使用)
        BspSetPwrUpgradeFlag(PWR_NONEED_UPDATE);
    }

    return retVal;
}
/* Ended by AICoder, pid:l3047x52f8c6d4114dd909f9b4487b0432c23325 */

/* 设置支持单双电源切换标志 */
VOID BspSetSingleAndDoublePwrSwitchFlag(UINT32 flag)
{
    s_singleAndDoublePwrSwitchFlag = flag;
}

/* 获取支持单双电源切换标志 */
UINT32 BspGetSingleAndDoublePwrSwitchFlag(VOID)
{
    return s_singleAndDoublePwrSwitchFlag;
}

/* 新增电源-48V输入欠压检测电路接口，BSP通过逻辑0x15寄存器获取，和高层约定，欠压上报0，正常上报1 */
UINT32 BspGetPwrVoltAlarmNew(UINT32 index, UINT32 *pVoltAlarm)
{
    UINT32 retVal = 0;
    UINT32 status = 0;

    INPUT_POINTER_CHECK(pVoltAlarm);
    retVal = BspGetPwrInputAlarmSta(&status);
    if(BSP_OK != retVal)
    {
         return BSP_ERROR;
    }

    if(0 == index)
    {
        *pVoltAlarm = (status & BIT_SET(3)) ? 0 : 1; /* 逻辑0x15寄存器的bit3表示-48V1输入欠压告警 */
    }
    else if(1 == index)
    {
        *pVoltAlarm = (status & BIT_SET(4)) ? 0 : 1; /* 逻辑0x15寄存器的bit4表示-48V2输入欠压告警 */
    }
    else
    {
        dbgInfoEx("[%s] input pwr index[%d] error!\n", __FUNCTION__, index);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] input pwr index[%d] alarm status is %d!\n", __FUNCTION__, index, *pVoltAlarm);
    return BSP_OK;
}

/* 新增控制单双线切换MOS开关接口，写0代表开关断开，1代表开关闭合,通过控制逻辑0x62寄存器*/
UINT32 BspSetPowerLineSw(UINT32 uPowSw)
{
    UINT32 retVal = 0;

    if (uPowSw > 1)
    {
        return BSP_ERROR;
        dbgInfo("[%s] input uPowSw[%d] error!\n", __FUNCTION__, uPowSw);
    }

    retVal = BspSetPwrInputSwitch(uPowSw);

    BspLog(LOG_LEVEL_0, "[%s] input uPowSw[%d]!\n", __FUNCTION__, uPowSw);
    return retVal;
}

/* 新增查询单双线切换MOS开关状态接口，通过逻辑0x62寄存器获取*/
UINT32 BspGetPowerLineSw(UINT32 *uPowSw)
{
    UINT32 retVal = 0;
    UINT32 status = 0;

    INPUT_POINTER_CHECK(uPowSw);
    retVal = BspRegRd(0, REG_PWR_INPUT_SWITCH, 0, &status);

    *uPowSw = status;
    dbgInfoEx("[%s] 0x62 status[%d], powSw is %d!\n", __FUNCTION__, status, *uPowSw);
    return retVal;
}

/*新增FPGA掉电告警开关切换接口，高层下发方式和fpga配置不同，需要BSP转换
APP下发方式：bit0为1代表选择A路，bit1为1代表选择B路，bit0和bit1都为1代表选择AB两路
FPGA配置方式：0x16寄存器的bit0和bit1一起配置，0表示切换到A路，1表示切换到B路，2表示AB两路
*/
UINT32 BspSetPowerDownSw(UINT32 uPowDownSw)
{
    UINT32 retVal = 0;
    UINT32 almSwitch = 0;
    UINT32 pwrA = 0;
    UINT32 pwrB = 0;

    retVal = BspRegRd(0, REG_PWR_INPUT_ALARM_SWITCH, 0, &almSwitch);

    pwrA = uPowDownSw & BIT_SET(0);
    pwrB = uPowDownSw & BIT_SET(1);

    if(pwrA && pwrB)
    {
        almSwitch &= ~BIT_SET(0);
        almSwitch |= BIT_SET(1);
    }
    else if(pwrA && (!pwrB))
    {
        almSwitch &= ~BIT_SET(0);
        almSwitch &= ~BIT_SET(1);
    }
    else if (pwrB && (!pwrA))
    {
        almSwitch &= ~BIT_SET(1);
        almSwitch |= BIT_SET(0);
    }
    else
    {
        dbgInfo("[%s] input para uPowDownSw[%d] is error!\n", __FUNCTION__, uPowDownSw);
        return BSP_ERROR;
    }
    retVal = BspRegWr(0, REG_PWR_INPUT_ALARM_SWITCH, 0, almSwitch);

    BspLog(LOG_LEVEL_0, "[%s] almSwitch status[%d], uPowDownSw is %d!\n", __FUNCTION__, almSwitch, uPowDownSw);
    return retVal;
}

/*新增FPGA掉电告警开关查询接口，高层下发方式和fpga配置不同，需要BSP转换
FPGA配置方式：0x16寄存器的bit0和bit1一起配置，0表示切换到A路，1表示切换到B路，2表示AB两路
给APP上报方式：bit0为1代表选择A路，bit1为1代表选择B路，bit0和bit1都为1代表选择AB两路*/
UINT32 BspGetPowerDownSw(UINT32 *uPowDownSw)
{
    UINT32 retVal = 0;
    UINT32 regValue = 0;
    UINT32 tempVal = 0;
    UINT32 powerDownSw = 0;

    INPUT_POINTER_CHECK(uPowDownSw);
    retVal = BspRegRd(0, REG_PWR_INPUT_ALARM_SWITCH, 0, &regValue);

    tempVal = regValue & 0x3;
    if(tempVal == 0)
    {
        powerDownSw = 0x1;
    }
    else if(tempVal == 1)
    {
        powerDownSw = 0x2;
    }
    else if(tempVal == 2)
    {
        powerDownSw = 0x3;
    }
    else
    {
        dbgInfoEx("[%s] read fpga reg data[%d] error!\n", __FUNCTION__, uPowDownSw);
        return BSP_ERROR;
    }
    *uPowDownSw = powerDownSw;
    dbgInfoEx("[%s] regValue uPowDownSw[%d], uPowDownSw is %d!\n", __FUNCTION__, regValue, *uPowDownSw);

    return retVal;
}

/*新增供电能力不足告警开关切换接口，按bit位定义（默认为0）
 * app下发：bit0为1代表选择A路，bit1为1代表选择B路，bit0和bit1都为1表示恢复双路输入
 * fpga的0x16寄存器，bit2表示IC1的供电告警开关选择，默认是0；bit3表示IC1的供电告警开关选择，默认是1；*/
UINT32 BspSetVinDownSw(UINT32 uVinDownSw)
{
    UINT32 retVal = 0;
    UINT32 pwrA = 0;
    UINT32 pwrB = 0;
    UINT32 regValue = 0;


    pwrA = uVinDownSw & BIT_SET(0);
    pwrB = uVinDownSw & BIT_SET(1);

    retVal |= BspRegRd(0, REG_PWR_INPUT_ALARM_SWITCH, 0, &regValue);


    if(pwrA && (!pwrB))
    {
        regValue &= ~BIT_SET(2);
        regValue &= ~BIT_SET(3);

    }
    else if((!pwrA) && pwrB)
    {
        regValue |= BIT_SET(2);
        regValue |= BIT_SET(3);
    }
    else if(pwrA && pwrB)
    {
        regValue &= ~BIT_SET(2);
        regValue |= BIT_SET(3);
    }
    else
    {
        dbgInfoEx("[%s] input uVinDownSw[%d] is error!\n", __FUNCTION__, uVinDownSw);
        return BSP_ERROR;
    }
    retVal |= BspRegWr(0, REG_PWR_INPUT_ALARM_SWITCH, 0, regValue);

    BspLog(LOG_LEVEL_0, "[%s] regValue status[%d], uVinDownSw is %d!\n", __FUNCTION__, regValue, uVinDownSw);

    return retVal;
}

/*新增单双线诊断结果配置结果，0代表双线，1代表单线。*/
UINT32 BspSetPowerLine(UINT32 cfgResult)
{
    if(cfgResult > 1)
    {
        dbgInfo("[%s] input cfgResult[%d] is error!\n", __FUNCTION__, cfgResult);
        return BSP_ERROR;
    }
    if(cfgResult == 0)
    {
        BspSetPowerLineFlag(0);
    }
    else
    {
        BspSetPowerLineFlag(1);
    }

    BspLog(LOG_LEVEL_0, "[%s] input cfgResult[%d]!\n", __FUNCTION__, cfgResult);
    return BSP_OK;
}

VOID BspSetSinglePwrChanPaMask(UINT32 chanMask)
{
    s_singlePwrChanMaskPaOff = chanMask;
    return;
}

UINT32 BspGetSinglePwrChanPaMask(VOID)
{
    return s_singlePwrChanMaskPaOff;
}

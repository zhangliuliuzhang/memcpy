/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : pwr_property.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供rru的pwr模块特性功能的实现
 * 注意事项 : 无
 * 作    者 :
 * 创建日期 : 2020-02-24
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "pwr_a_property.h"
#include "rruinfo.h"
#include "exprn.h"

static INT32   g_aDcVoltAlmThre[4] = {37000, 38000, 60000, 58000}; /* {欠压告警,欠压恢复,过压告警,过压恢复} */
static INT32   g_aAcVoltAlmThre[4] = {154000, 162000, 286000, 272000}; /* {欠压告警,欠压恢复,过压告警,过压恢复} */
static UINT8  s_strTimeAddr[PWR_HISTORY_SET_TIME_LEN] = {0x10,0x20,0x30,0x40};/* 设置时间 */
static UINT32 s_paVoltNum = 1;

UINT32 BspGetPwrVoltAlm(VOID)
{
    UINT32 ulRet = BSP_OK;
    static UINT32 sulInputPwrAlmState = 0;
    INT32 lVolt = 0;
    INT32 lLowAlmThre = 0;
    INT32 lLowRecThre = 0;
    INT32 lHighAlmThre = 0;
    INT32 lHighRecThre = 0;
    UINT32 ulPwrType = 0;

    ulPwrType = BspGetPwrType(0);

    switch(ulPwrType)
    {
        case PWR_TYPE_AC:
        {
            lLowAlmThre  = g_aAcVoltAlmThre[0];
            lLowRecThre  = g_aAcVoltAlmThre[1];
            lHighAlmThre = g_aAcVoltAlmThre[2];
            lHighRecThre = g_aAcVoltAlmThre[3];
            break;
        }
        case PWR_TYPE_DC:
        {
            lLowAlmThre  = g_aDcVoltAlmThre[0];
            lLowRecThre  = g_aDcVoltAlmThre[1];
            lHighAlmThre = g_aDcVoltAlmThre[2];
            lHighRecThre = g_aDcVoltAlmThre[3];
            break;
        }
        default:
            break;
    }

    ulRet = BspGetPwrVolt(0,&lVolt);
    if (ulRet != BSP_OK)
    {
        dbgInfoEx("get vin failed,return %#x\n", sulInputPwrAlmState);
        return sulInputPwrAlmState;
    }

    /* 欠压告警 */
    if (lVolt <= lLowAlmThre)
    {
        sulInputPwrAlmState |= BSP_BIT_SET(0);
    }
    else if (lVolt >= lLowRecThre)
    {
        sulInputPwrAlmState &= ~BSP_BIT_SET(0);
    }

    /* 过压告警 */
    if (lVolt >= lHighAlmThre)
    {
        sulInputPwrAlmState |= BSP_BIT_SET(1);
    }
    else if (lVolt <= lHighRecThre)
    {
        sulInputPwrAlmState &= ~BSP_BIT_SET(1);
    }

    dbgInfoEx("vin %d,lowalm %d,lowrec %d,highalm %d,highrec %d,return %#x\n", lVolt, lLowAlmThre, lLowRecThre, lHighAlmThre,lHighRecThre,sulInputPwrAlmState);
    return sulInputPwrAlmState;

}


/* todo */
UINT32 BspSetPwrVoltAlmThre(T_PwrVoltVoltAlmThre *ptThreValue)
{
    if (NULL == ptThreValue)
    {
        dbgErr("input pointer is null\n");
        return BSP_ERROR;
    }
    switch(ptThreValue->pwrType)
    {
        case PWR_TYPE_AC:
        {
            g_aAcVoltAlmThre[0] = ptThreValue->pwrAlmThre[0];
            g_aAcVoltAlmThre[1] = ptThreValue->pwrAlmThre[1];
            g_aAcVoltAlmThre[2] = ptThreValue->pwrAlmThre[2];
            g_aAcVoltAlmThre[3] = ptThreValue->pwrAlmThre[3];
            break;
        }
        case PWR_TYPE_DC:
        {
            g_aDcVoltAlmThre[0] = ptThreValue->pwrAlmThre[0];
            g_aDcVoltAlmThre[1] = ptThreValue->pwrAlmThre[1];
            g_aDcVoltAlmThre[2] = ptThreValue->pwrAlmThre[2];
            g_aDcVoltAlmThre[3] = ptThreValue->pwrAlmThre[3];
            break;
        }
        default:
            break;
    }

    return BSP_OK;
}

/* 电源历史记录使能时间设置 */
UINT32 BspSetPwrEnableTime(UINT8 *pStrTime, UINT32 ulStrLen)
{
    UINT32 uloop     = 0;
    UINT32 ulTimeLen = 0;

    if (NULL == pStrTime)
    {
        dbgErr("input pointer is null\n");
        return BSP_ERROR;
    }

    ulTimeLen = min(ulStrLen,PWR_HISTORY_SET_TIME_LEN);
    for(uloop = 0; uloop < ulTimeLen; uloop++)
    {
        s_strTimeAddr[uloop] = *(pStrTime + uloop);
    }

    return BSP_OK;
}

/* 获取电源历史记录使能时间 */
UINT32 BspGetPwrEnableTime(UINT8 *pStrTime, UINT32 ulStrLen)
{
    UINT32 uloop     = 0;
    UINT32 ulTimeLen = 0;

    if (NULL == pStrTime)
    {
        dbgErr("input pointer is null\n");
        return BSP_ERROR;
    }

    ulTimeLen = min(ulStrLen,PWR_HISTORY_SET_TIME_LEN);
    for(uloop = 0; uloop < ulTimeLen; uloop++)
    {
        *(pStrTime + uloop) = s_strTimeAddr[uloop];
    }

    return BSP_OK;
}

/* 从单板设置电源提供pa电压的路数 */
UINT32 BspSetpwrPaVoltNum(UINT32 paVoltNum)
{
    s_paVoltNum = paVoltNum;
    dbgInfoEx("[%s]: paVoltNum is : %d. \n",__FUNCTION__, paVoltNum);

    return BSP_OK;
}

UINT32 BspGetPaVoltNum(UINT32 *paVoltNum)
{

    if (NULL == paVoltNum)
    {
        dbgErr("input pointer is null\n");
        return BSP_ERROR;
    }

    *paVoltNum = s_paVoltNum;

    return BSP_OK;
}

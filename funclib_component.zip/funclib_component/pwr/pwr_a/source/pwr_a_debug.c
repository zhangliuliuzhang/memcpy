/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pwr_debug.c
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 : wangfei
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei
* 修改日戳: 2017-5-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "pwr_a.h"
#include "devdrv_pwr.h"

/*************************** 调试命令 *******************************/
#ifdef BUILD_WITH_OM_FUNC
/*电源模块芯片*/
UINT32 rdpwrtemp(UINT32 idx)
{
    UINT32 retVal   = BSP_OK;
    INT32  pwrTemp  = 0;
    retVal = BspGetPwrTemp(idx,&pwrTemp);
    dbgInfo("pwr %d temp = %d (0.1C)\n",idx,pwrTemp);
    return retVal;
}
/*电源监控芯片*/

/********************Tps接口测试函数********************************/
/*电源监控芯片tps53667*/
UINT32 rdmonitorpwrtemp(UINT32 idx)
{
    UINT32 retVal   = BSP_OK;
    INT32  pwrTemp  = 0;
    retVal = BspGetMonitorPwrTemp(idx,&pwrTemp);
    dbgInfo("Monitor Pwr %d temp = %lf (°C)\n",idx,((FLOAT)pwrTemp/10.0));
    return retVal;
}
#endif
VOID dbgBspGetMonitorPwrIn(UINT32 index)
{
    INT32 ulPower = 0;
    UINT32 ulRet = BSP_OK;
    
    ulRet = BspGetMonitorPwrIn(index,&ulPower);
    dbgPrn("Idx %d,Power %d, Ret 0x%x \n",index,ulPower,ulRet);
    return ;
}
VOID dbgBspGetMonitorPwrOut(UINT32 index)
{
    INT32 ulPower = 0;
    UINT32 ulRet = BSP_OK;
    
    ulRet = BspGetMonitorPwrOut(index,&ulPower);
    dbgPrn("Idx %d,Power %d, Ret 0x%x \n",index,ulPower,ulRet);
    return ;
}
VOID dbBspGetMonitorPwrVoltIn(UINT32 index)
{
    INT32 ulPower = 0;
    UINT32 ulRet = BSP_OK;
    
    ulRet = BspGetMonitorPwrVoltIn(index,&ulPower);
    dbgPrn("Idx %d,Power %d, Ret 0x%x \n",index,ulPower,ulRet);
    return ;
}

VOID dbgBspGetMonitorPwrVoltOut(UINT32 index)
{
    INT32 ulPower = 0;
    UINT32 ulRet = BSP_OK;
    
    ulRet = BspGetMonitorPwrVoltOut(index,&ulPower);
    dbgPrn("Idx %d,Power %d, Ret 0x%x \n",index,ulPower,ulRet);
    return ;
}

/* Started by AICoder, pid:tbc5d48d54v9586143980955d0b045223cc22332 */
UINT32 dbgBspGetMonitorPwrNominalVout(UINT32 index)
{
    INT32 ulVolt = 0;
    UINT32 ulRet = BSP_OK;

    ulRet = BspGetMonitorPwrNominalVout(index, &ulVolt);
    dbgPrn("Idx = %d, Volt = %dmv, Ret = %d \n",index, ulVolt, ulRet);
    return ulRet;
}
/* Ended by AICoder, pid:tbc5d48d54v9586143980955d0b045223cc22332 */

VOID dbgBspRdMonitorPwrRegByte(UINT32 index, UINT32 ulReg)
{
    UINT8 ucRegVal = 0;
    UINT32 ulRet = BSP_OK;
    
    ulRet = BspRdMonitorPwrRegByte(index,ulReg,&ucRegVal);
    dbgPrn("Idx %d,RegVal 0x%x, Ret 0x%x \n",index,ucRegVal,ulRet);
    return ;
}

UINT32 showpwrvoltinfo(VOID)
{
    UINT32 chipIndex = 0;
    UINT32 retVal = 0;
    INT32  volt   = 0;
    T_PmbAdcCfg * ptPmbAdcCfgPara = NULL;

    ptPmbAdcCfgPara = BspGetPmbAdcCfgPara();

    INPUT_POINTER_CHECK(ptPmbAdcCfgPara);
    INPUT_POINTER_CHECK(ptPmbAdcCfgPara->pCfgPara);

    for(chipIndex = 0; chipIndex < ptPmbAdcCfgPara->cfgNum; chipIndex++)
    {
        retVal = BspGetMonitorPwrVoltOut(chipIndex, &volt);
        dbgInfo("PwrVolt'[%d]:%s OutPut Get %s! Ret= %d (mV) \n",
            chipIndex, ptPmbAdcCfgPara->pCfgPara[chipIndex].FuncName,(BSP_OK == retVal) ? "Succ" : "Error", volt);
    }    
    return BSP_OK;
}

UINT32 showpwrmode(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 nodeNum = 0;
    UINT32 loop = 0;
    T_PwrTempMode *pTempMod = NULL;

    pTempMod = (T_PwrTempMode *)malloc(sizeof(T_PwrTempMode));
    INPUT_POINTER_CHECK(pTempMod);

    ret |= BspGetTempMode(pTempMod);

    nodeNum = pTempMod->tempNum;
    dbgInfo("nodeNum:%u \n", nodeNum);

    for(loop = 0; loop < nodeNum; loop++)
    {
        dbgInfo("------------------------------------ nodeNo [%u] -------------------------------------\n", pTempMod->t_tempMode[loop].nodeNo);
        dbgInfo("gainBitNum:0x%-5x paBitNum:0x%-10x pwrType:%u(0:DC,1:AC)  acCuracy:%u (0.01C) \n", pTempMod->t_tempMode[loop].gainBitNum,
                pTempMod->t_tempMode[loop].paBitNum, pTempMod->t_tempMode[loop].pwrType, pTempMod->t_tempMode[loop].acCuracy);
        dbgInfo("slightThrd:%-7d slightRecThrd:%-7d seriousThrd:%-7d seriousRecThrd:%d \n", pTempMod->t_tempMode[loop].slightThrd,
                pTempMod->t_tempMode[loop].slightRecThrd, pTempMod->t_tempMode[loop].seriousThrd, pTempMod->t_tempMode[loop].seriousRecThrd);
    }
    free(pTempMod);

    return ret;
}

UINT32 showpwrtemp(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 nodeNum = 0;
    UINT32 loop = 0;
    T_PwrTemp *pTemp = NULL;

    pTemp = (T_PwrTemp *)malloc(sizeof(T_PwrTemp));
    INPUT_POINTER_CHECK(pTemp);

    ret |= BspGetPwrNodeTemp(pTemp);

    nodeNum = pTemp->tempNum;
    dbgInfo("---------- nodeNum [%u] ---------- \n", nodeNum);

    for(loop = 0; loop < nodeNum; loop++)
    {
        dbgInfo("nodeNo:%-2u pwrTemp:%d (0.1C)\n", pTemp->t_nodeTemp[loop].nodeNo, pTemp->t_nodeTemp[loop].temp);
    }
    free(pTemp);

    return ret;
}

/* Started by AICoder, pid:pb649z8d07oe02a142a809962186aa06b317fa6d */
UINT32 prndynvoltlevel(VOID)
{
    UINT32 level = 0;
    T_icDynVoltPara *pVoltPara = NULL;
    T_icCoreVoltDynCfg *pIcDynPara = BspGetIcDynVoltPara();

    INPUT_POINTER_CHECK(pIcDynPara);
    if(NULL == pIcDynPara->pIcVoltPara)
    {
        dbgErr("Error, temp and volt para are NULL. \n");
        return BSP_ERROR;
    }

    dbgInfo("volt allow range: %umv ~ %umv\n", pIcDynPara->icVoltLowThrMv, pIcDynPara->icVoltHighThrMv);

    for (level = 0; level < pIcDynPara->tempVoltCfgNum; level++)
    {
        pVoltPara = &(pIcDynPara->pIcVoltPara[level]);
        dbgInfo("level:%-2u  IcTemp(0.1C):[%-6d ~ %5d)  Vmin(mv):%-4d  IcVolt(mv):%d\n", level, pVoltPara->tempLowThr,
                pVoltPara->tempHighThr, pVoltPara->minWorkVolt, pVoltPara->targetVolt);
    }

    return BSP_OK;
}

UINT32 setdynvoltrange(INT32 voltMin, INT32 voltMax)
{
    T_icCoreVoltDynCfg *pIcDynPara = BspGetIcDynVoltPara();
    INPUT_POINTER_CHECK(pIcDynPara);

    pIcDynPara->icVoltLowThrMv = voltMin;
    pIcDynPara->icVoltHighThrMv = voltMax;

    return BSP_OK;
}

/*不需要调整的参数填写 0*/
UINT32 setdynvoltpara(UINT32 level, INT32 tempLow, INT32 tempHigh, INT32 destVolt)
{
    T_icCoreVoltDynCfg *pIcDynPara = BspGetIcDynVoltPara();
    INPUT_POINTER_CHECK(pIcDynPara);

    if (level >= pIcDynPara->tempVoltCfgNum || (pIcDynPara->pIcVoltPara == NULL))
    {
        dbgErr("level[%d] is out of range, max level:%d!\n", level, pIcDynPara->tempVoltCfgNum);
        return BSP_ERROR;
    }

    if (tempLow != 0)
    {
        pIcDynPara->pIcVoltPara[level].tempLowThr = tempLow;
    }

    if (tempHigh != 0)
    {
        pIcDynPara->pIcVoltPara[level].tempHighThr = tempHigh;
    }

    if (destVolt != 0)
    {
        pIcDynPara->pIcVoltPara[level].targetVolt = destVolt;
    }

    prndynvoltlevel();

    return BSP_OK;
}
/* Ended by AICoder, pid:pb649z8d07oe02a142a809962186aa06b317fa6d */

/*************************** 调试命令 *******************************/
#ifdef BUILD_WITH_OM_FUNC
UINT32 volt(VOID)
{
    UINT32 retVal   = BSP_OK;
    INT32  volt  = 0;
    INT32  power = 0;
    UINT32 index = 0;
    UINT32 pwrOutLetNum = 0;
	
    pwrOutLetNum = BspGetPwrOutLetDevNum();  /* RRU整机插头个数 */
    for(index = 0; index < pwrOutLetNum; index++)
    {
        retVal = BspGetPwrVolt(index,&volt);
        retVal |= BspGetRruConsumedPower(index,&power);
        dbgInfo("index:%d, pwr volt = %dmV, power = %dmW\n", index, volt, power);
    }
	
    return retVal;
}
#endif

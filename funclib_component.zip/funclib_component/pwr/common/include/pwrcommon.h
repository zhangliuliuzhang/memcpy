/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pwrapi.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了电源对外接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_PWRCOMMON_H_
#define _FUNCLIB_PWRCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "pwrapi.h"
#include "pwr_common.h"

#define VOLT_ALM_THRES_LOWER_LIMIT           (0)
#define VOLT_ALM_THRES_LOWER_LIMIT_REC       (1)
#define VOLT_ALM_THRES_UPPER_LIMIT           (2)
#define VOLT_ALM_THRES_UPPER_LIMIT_REC       (3)
#define NOT_SUPPORT_FIELD                    (0xFFFFFFFF)
#define MARGIN_FOR_LOWER_LIMIT               (4000)
#define MARGIN_FOR_LOWER_LIMIT_REC           (2000)
#define MARGIN_FOR_LOWER_LIMIT_AND_REC       (1000)
#define MARGIN_FOR_UPPER_LIMIT_AND_REC       (2000)
#define CFG_THRES_CHK(lowerBound,val,upperBound,margin) ((lowerBound<=val) && (val<=(upperBound-margin)))
#define CFG_THRES_SELF_CHK(lower,upper,margin) (lower <= (upper-margin))
#define DPDIC_DYN_VOLT_TEMP_MIN_THR   ((INT32)(-10000))
#define DPDIC_DYN_VOLT_TEMP_MAX_THR   ((INT32)(10000))

typedef struct tagT_VoltThresAdjPara
{
    UINT32 localPwrType;          /* AC/DC */
    UINT32 voltLevel;             /* 100V/110V/220V/远供DC */
    UINT32 cfgPwrType;            /* APP下发的类型 */
    const LONG *defaultThres;     /* 默认门限 */
    LONG *cfgThres;               /* 配置门限 */
    BOOL (*pcbIsThresValid)(struct tagT_VoltThresAdjPara *thresAdjPara, T_VoltThres *voltThres);
}T_VoltThresAdjPara;

typedef struct
{
    /*温度单位0.1摄氏度; 电压单位1mv*/
    INT32 tempLowThr;      /*温度区间下限*/
    INT32 tempHighThr;     /*温度区间上限*/
    UINT32 minWorkVolt;    /*IC能正常工作最低电压*/
    INT32 targetVolt;      /*当前温度区间对应的目标核压,值为 INVALID_VALUE 时app保持现状不做调压*/
}T_icDynVoltPara;

typedef struct
{
    INT32 icVoltLowThrMv;          /*用户可设置最低核压,单位1mv*/
    INT32 icVoltHighThrMv;         /*用户可设置最高核压*/
    T_icDynVoltPara *pIcVoltPara;  /*IC温度与核压对应关系*/
    UINT32 tempVoltCfgNum;         /*IC温度与核压对应关系组数*/
}T_icCoreVoltDynCfg;

enum
{
    E_PWR_TYPE_STANDARD_DC=50,
};

VOID BspGetPwrCurrInCallbackInit(Pwr_GetInt pFunc);
UINT32 BspSetpwrPaVoltNum(UINT32 paVoltNum);
UINT32 BspGetPaVoltNum(UINT32 *paVoltNum);
UINT32 BspGetPwrSupportStatus(void);
UINT32 BspSetSmartPwrMcuCfg(UINT32 cfg);
UINT32 BspGetSmartPwrMcuCfg(VOID);
BOOL BspIsDcVoltAlmThresValid(T_VoltThresAdjPara *thresAdjPara, T_VoltThres *voltThres);
UINT32 BspGetVoltAlmThresPara(T_VoltThresAdjPara **thresAdjPara, UINT32 *paraNum);
VOID BspSetAuxPowSupport(BOOL isSupport);
BOOL BspIsSupportAuxPow(VOID);
UINT32 BspGetIcMinWorkVolt(UINT32 *pMinWorkVolt);
UINT32 BspSetSupportIcDynVoltFlag(BOOL isSupportFlag);
T_icCoreVoltDynCfg *BspGetIcDynVoltPara(VOID);
T_icCoreVoltDynCfg *BspGetMainIcDynVoltPara(VOID);
T_icCoreVoltDynCfg *BspGetSlaveIcDynVoltPara(VOID);
UINT32 BspSetIcDynVoltPara(T_icCoreVoltDynCfg *pIcDynPara);
UINT32 BspLimitMaxPow(UINT32 busSta, INT32 *pPowMw);
UINT32 BspGetPwrI2cDbgSta(VOID);
VOID BspSetPwrI2cDbg(UINT32 i2cStaDbg);

#ifdef __cplusplus
}
#endif
#endif 




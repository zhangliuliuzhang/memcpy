/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pwr_common.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2023-5-17
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2023-5-17
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/


#include <ctype.h>
#include "bspcomm.h"
#include "bsppub.h"
#include "exprn.h"
#include "pwrcommon.h"
#include "funccommon_log.h"
#include "regdrv_access.h"
#include "regaccess.h"
#include "regtbl.h"
#include "pwr_a.h"

static UINT32 s_smartPwrMcuCfg  = 0;
static UINT32 s_voltThresType = DEFAULT_VOLT_ALM_THRES;   /* 电压告警门限类型：默认/自定义 */
static BOOL s_AuxPowSupport = FALSE;  /* 支持辅助电源能力, 默认不支持 */
static BOOL s_isSupportIcDynVolt = FALSE;
static T_icCoreVoltDynCfg s_icDynVoltCfg = {0};
static UINT32 s_i2cBusDbg = BSP_OK;      /* 电源I2C总线状态调试 */

/* Started by AICoder, pid:ga1f5b3a0e28f6f14c970bb781617e0aa967f17a */
/* ==============================================================
    DPDIC核压动态调整参数配置
 ============================================================== */
 /*孟宪磊:基于主片挂了没有其他的救活主片,但是从片挂了还有主片去救,所以主片调压的范围小一点*/
static T_icDynVoltPara s_icDynVoltPara_MainIc[] =
{
    /*tempLowThr,                 tempHighThr,                 minWorkVolt, targetVolt*/
    {DPDIC_DYN_VOLT_TEMP_MIN_THR, 800,                         0,           750},
    {DPDIC_DYN_VOLT_TEMP_MIN_THR, 800,                         675,         750},
    {DPDIC_DYN_VOLT_TEMP_MIN_THR, 800,                         638,         750},
    {800,                         1000,                        0,           INVALID_VALUE},
    {800,                         1000,                        675,         INVALID_VALUE},
    {800,                         1000,                        638,         INVALID_VALUE},
    {1000,                        DPDIC_DYN_VOLT_TEMP_MAX_THR, 0,           710}, /*对于主片,温度>=100时不用关注 minWorkVolt,目标电压均为710*/
    {1000,                        DPDIC_DYN_VOLT_TEMP_MAX_THR, 675,         710},
    {1000,                        DPDIC_DYN_VOLT_TEMP_MAX_THR, 638,         710},
};

static T_icDynVoltPara s_icDynVoltPara_SlaveIc[] =
{
    /*tempLowThr,                 tempHighThr,                 minWorkVolt, targetVolt*/
    {DPDIC_DYN_VOLT_TEMP_MIN_THR, 800,                         0,           750},
    {DPDIC_DYN_VOLT_TEMP_MIN_THR, 800,                         675,         750},
    {DPDIC_DYN_VOLT_TEMP_MIN_THR, 800,                         638,         750},
    {800,                         1000,                        0,           INVALID_VALUE},
    {800,                         1000,                        675,         INVALID_VALUE},
    {800,                         1000,                        638,         INVALID_VALUE},
    {1000,                        DPDIC_DYN_VOLT_TEMP_MAX_THR, 0,           710}, /*Vmin 为0是早期芯片efuse未写入,流程按照 675 处理*/
    {1000,                        DPDIC_DYN_VOLT_TEMP_MAX_THR, 675,         710}, /*从片温度>=100,Vmin为0或675时目标电压710,Vmin为638时目标电压675*/
    {1000,                        DPDIC_DYN_VOLT_TEMP_MAX_THR, 638,         675},
};

static T_icCoreVoltDynCfg s_icVoltCfg_MainIc =
{
    .icVoltLowThrMv = 690,
    .icVoltHighThrMv = 780,
    .pIcVoltPara = s_icDynVoltPara_MainIc,
    .tempVoltCfgNum = NELEMENTS(s_icDynVoltPara_MainIc),
};

static T_icCoreVoltDynCfg s_icVoltCfg_SlaveIc =
{
    .icVoltLowThrMv = 650,
    .icVoltHighThrMv = 780,
    .pIcVoltPara = s_icDynVoltPara_SlaveIc,
    .tempVoltCfgNum = NELEMENTS(s_icDynVoltPara_SlaveIc),
};
/* Ended by AICoder, pid:ga1f5b3a0e28f6f14c970bb781617e0aa967f17a */

T_icCoreVoltDynCfg *BspGetMainIcDynVoltPara(VOID)
{
    return &s_icVoltCfg_MainIc;
}

T_icCoreVoltDynCfg *BspGetSlaveIcDynVoltPara(VOID)
{
    return &s_icVoltCfg_SlaveIc;
}

T_icCoreVoltDynCfg *BspGetIcDynVoltPara(VOID)
{
    return &s_icDynVoltCfg;
}

UINT32 BspSetIcDynVoltPara(T_icCoreVoltDynCfg *pIcDynPara)
{
    INPUT_POINTER_CHECK(pIcDynPara);

    s_icDynVoltCfg.icVoltHighThrMv   = pIcDynPara->icVoltHighThrMv;
    s_icDynVoltCfg.icVoltLowThrMv   = pIcDynPara->icVoltLowThrMv;
    s_icDynVoltCfg.tempVoltCfgNum   = pIcDynPara->tempVoltCfgNum;
    s_icDynVoltCfg.pIcVoltPara   = pIcDynPara->pIcVoltPara;

    return BSP_OK;
}

/**
 * @brief 获取电源I2C总线调试状态
 * @return 电源I2C总线调试状态
 */
UINT32 BspGetPwrI2cDbgSta(VOID)
{
    return s_i2cBusDbg;
}

/**
 * @brief 设置I2C调试状态
 * @param i2cStaDbg 电源I2C调试状态
 */
VOID BspSetPwrI2cDbg(UINT32 i2cStaDbg)
{
    s_i2cBusDbg = i2cStaDbg;
    return;
}

/* Started by AICoder, pid:t1d51h2e3125c241402708aa308f189f2dd2d806 */
/**
 * @brief 限制最大功耗
 * @param busSta 总线状态
 * @param pPowMw 功耗指针
 * @return 和最大功耗比较后的电源I2c总线状态
 */
UINT32 BspLimitMaxPow(UINT32 busSta, INT32 *pPowMw)
{
    UINT32 i2cPwr = busSta;
    INT32 maxPow = 0;
    T_BspFuRuSupportMaxPowLimitInfo fuRuSupportMaxPowLimitInfo = {0};

    INPUT_POINTER_CHECK(pPowMw);

    if (BSP_OK != BspGetRruSpecialAbility(BSP_FU_RU_MAX_POW_LIMIT, (VOID *)&fuRuSupportMaxPowLimitInfo, sizeof(T_BspFuRuSupportMaxPowLimitInfo)))
    {
        dbgInfoEx("Get RruSpecialAbility(FuId:%u) No support!", BSP_FU_RU_MAX_POW_LIMIT);
        return BSP_OK;
    }

    maxPow = fuRuSupportMaxPowLimitInfo.maxPowMw;
    if ((*pPowMw > maxPow)||(*pPowMw < 0))
    {
        *pPowMw = 0;
        i2cPwr = BSP_ERROR;
    }

    dbgInfoEx("[%s]busSta:%d, i2cPwr:%d, PowMw:%d, maxPow:%d\n", __FUNCTION__, busSta, i2cPwr, *pPowMw, maxPow);
    return i2cPwr;
}
/* Ended by AICoder, pid:t1d51h2e3125c241402708aa308f189f2dd2d806 */

UINT32 BspGetVoltThresType(VOID)
{
    return s_voltThresType;
}

static VOID BspSetVoltThresType(UINT32 voltThresType)
{
    s_voltThresType = voltThresType;
}

/* 该接口为动态调压相关需求供高层调用，D42实现动态调压功能再考虑内部实现，与APP约定目前空接口实现*/
UINT32 BspGetPaVoltByChan(UINT32 bspChan)
{
    UINT32 volt = 0;
//    volt = BspGetPaVolt(bspChan);       /*后续放开该接口需要内部解耦*/

    return volt;
}

UINT32 BspSetSmartPwrMcuCfg(UINT32 cfg)
{
    s_smartPwrMcuCfg = cfg;
    return BSP_OK;
}

UINT32 BspGetSmartPwrMcuCfg(VOID)
{
    return s_smartPwrMcuCfg;
}

BOOL BspIsDcVoltAlmThresValid(T_VoltThresAdjPara *thresAdjPara, T_VoltThres *voltThres)
{
    const LONG *defaultThres = NULL;
    BOOL isValid = TRUE;

    if((thresAdjPara == NULL) || (voltThres == NULL))
    {
        dbgErr("%s, input pointer is NULL! \n", __FUNCTION__);
        return FALSE;
    }
    defaultThres = thresAdjPara->defaultThres;
    if(defaultThres == NULL)
    {
        dbgErr("%s, defaultThres is NULL! \n", __FUNCTION__);
        return FALSE;
    }

    isValid &= CFG_THRES_CHK(defaultThres[VOLT_ALM_THRES_LOWER_LIMIT], voltThres->lowerLimit, defaultThres[VOLT_ALM_THRES_UPPER_LIMIT], MARGIN_FOR_LOWER_LIMIT);
    isValid &= CFG_THRES_CHK(defaultThres[VOLT_ALM_THRES_LOWER_LIMIT_REC], voltThres->lowerLimitRec, defaultThres[VOLT_ALM_THRES_UPPER_LIMIT], MARGIN_FOR_LOWER_LIMIT_REC);
    isValid &= CFG_THRES_CHK(defaultThres[VOLT_ALM_THRES_LOWER_LIMIT_REC], voltThres->upperLimit, defaultThres[VOLT_ALM_THRES_UPPER_LIMIT], 0);
    isValid &= CFG_THRES_CHK(defaultThres[VOLT_ALM_THRES_LOWER_LIMIT_REC], voltThres->upperLimitRec, defaultThres[VOLT_ALM_THRES_UPPER_LIMIT_REC], 0);

    isValid &= CFG_THRES_SELF_CHK(voltThres->lowerLimit, voltThres->lowerLimitRec, MARGIN_FOR_LOWER_LIMIT_AND_REC);
    isValid &= CFG_THRES_SELF_CHK(voltThres->upperLimitRec, voltThres->upperLimit, MARGIN_FOR_UPPER_LIMIT_AND_REC);
    isValid &= CFG_THRES_SELF_CHK(voltThres->lowerLimitRec, voltThres->upperLimitRec, 0);

    return isValid;
}

/* Started by AICoder, pid:y9577066eb11597140260966f0e365313110b4bb */
UINT32 BspGetVoltThresAdjParaIndex(UINT32 cfgPwrType, T_VoltThresAdjPara *thresAdjPara, UINT32 paraNum)
{
    UINT32 idx = 0;
    UINT32 localPwrType = BspGetPwrType(0);
    UINT32 vinType = 0;
    UINT32 voltLevel = NOT_SUPPORT_FIELD;

    if(thresAdjPara == NULL)
    {
        dbgErr("%s, thresAdjPara is NULL!\n", __FUNCTION__);
        return BSP_INVALID_VALUE;
    }

    if(localPwrType == PWR_TYPE_AC)
    {
        (void)BspGetBoardVinType(0, &vinType);
        if(vinType == PWR_TYPE_HIGH_DC)
        {
            voltLevel = PWR_TYPE_HIGH_DC;
        }
        else
        {
            voltLevel = BspGetPwrInputVolt(0);
        }
    }

    for(idx = 0; idx < paraNum; idx++)
    {
        if((thresAdjPara[idx].localPwrType == localPwrType) &&
           (thresAdjPara[idx].voltLevel == voltLevel) &&
           (thresAdjPara[idx].cfgPwrType == cfgPwrType))
        {
            return idx;
        }
    }
    return BSP_INVALID_VALUE;
}
/* Ended by AICoder, pid:y9577066eb11597140260966f0e365313110b4bb */

static UINT32 SetVoltThresType(T_VoltThresAdjPara *thresAdjPara)
{
    BOOL isDefaultThres = TRUE;

    INPUT_POINTER_CHECK(thresAdjPara);

    isDefaultThres &= (thresAdjPara->cfgThres[VOLT_ALM_THRES_UPPER_LIMIT] == thresAdjPara->defaultThres[VOLT_ALM_THRES_UPPER_LIMIT]);
    isDefaultThres &= (thresAdjPara->cfgThres[VOLT_ALM_THRES_LOWER_LIMIT] == thresAdjPara->defaultThres[VOLT_ALM_THRES_LOWER_LIMIT]);
    isDefaultThres &= (thresAdjPara->cfgThres[VOLT_ALM_THRES_UPPER_LIMIT_REC] == thresAdjPara->defaultThres[VOLT_ALM_THRES_UPPER_LIMIT_REC]);
    isDefaultThres &= (thresAdjPara->cfgThres[VOLT_ALM_THRES_LOWER_LIMIT_REC] == thresAdjPara->defaultThres[VOLT_ALM_THRES_LOWER_LIMIT_REC]);

    if(isDefaultThres)
    {
        BspSetVoltThresType(DEFAULT_VOLT_ALM_THRES);
    }
    else
    {
        BspSetVoltThresType(CUSTOMIZED_VOLT_ALM_THRES);
    }

    return BSP_OK;
}

UINT32 BspSetPowerThres(UINT32 cfgPwrType, T_VoltThres *voltThres)
{
    UINT32 retVal = BSP_OK;
    UINT32 thresParaIndex = 0;
    BOOL isValid = TRUE;
    UINT32 paraNum = 0;
    T_VoltThresAdjPara *thresAdjPara = NULL;

    INPUT_POINTER_CHECK(voltThres)

    retVal = BspGetVoltAlmThresPara(&thresAdjPara, &paraNum);
    if((retVal != BSP_OK) || (thresAdjPara == NULL))
    {
        dbgErr("%s, fail to get volt alarm thres adjust para!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    thresParaIndex = BspGetVoltThresAdjParaIndex(cfgPwrType, thresAdjPara, paraNum);
    if((thresParaIndex == BSP_INVALID_VALUE) || (thresParaIndex >= paraNum))
    {
        BspLog(LOG_LEVEL_0, "%s, cfgPwrType: %d is not supported! \n", __FUNCTION__, cfgPwrType);
        return BSP_ERROR;
    }

    POINTER_NULL_CHECK(thresAdjPara[thresParaIndex].pcbIsThresValid);
    isValid = thresAdjPara[thresParaIndex].pcbIsThresValid(&thresAdjPara[thresParaIndex], voltThres);
    if(!isValid)
    {
        BspLog(LOG_LEVEL_0, "%s, cfgPwrType:%d, upperLimit:%d, lowerLimit:%d, upperLimitRec:%d, lowerLimitRec:%d are invalid!\n", __FUNCTION__,
            cfgPwrType, voltThres->upperLimit, voltThres->lowerLimit, voltThres->upperLimitRec, voltThres->lowerLimitRec);
        return BSP_ERROR;
    }

    thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_UPPER_LIMIT] = voltThres->upperLimit;
    thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_LOWER_LIMIT] =  voltThres->lowerLimit;
    thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_UPPER_LIMIT_REC] = voltThres->upperLimitRec;
    thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_LOWER_LIMIT_REC] = voltThres->lowerLimitRec;

    retVal = SetVoltThresType(&thresAdjPara[thresParaIndex]);

    BspLog(LOG_LEVEL_0, "%s>>cfgPwrType: %d upperLimit:%d lowerLimit:%d upperLimitRec: %d lowerLimitRec: %d\n", __FUNCTION__,
        cfgPwrType, voltThres->upperLimit, voltThres->lowerLimit, voltThres->upperLimitRec, voltThres->lowerLimitRec);

    return retVal;
}

/* Started by AICoder, pid:ha882g20815b7cb140ca0b9230e466527c59f0cf */
UINT32 BspGetPowerThres(UINT32 cfgPwrType, T_VoltThres *voltThres)
{
    UINT32 retVal = BSP_OK;
    UINT32 thresParaIndex = 0;
    UINT32 paraNum = 0;
    T_VoltThresAdjPara *thresAdjPara = NULL;

    INPUT_POINTER_CHECK(voltThres);

    retVal = BspGetVoltAlmThresPara(&thresAdjPara, &paraNum);
    if(retVal != BSP_OK || thresAdjPara == NULL)
    {
        dbgErr("%s fail to get volt alarm thres adjust para!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    thresParaIndex = BspGetVoltThresAdjParaIndex(cfgPwrType, thresAdjPara, paraNum);
    if((thresParaIndex == BSP_INVALID_VALUE) || (thresParaIndex >= paraNum))
    {
        dbgErr("%s, cfgPwrType: %d is not supported!\n", __FUNCTION__, cfgPwrType);
        return BSP_ERROR;
    }

    voltThres->upperLimit = thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_UPPER_LIMIT];
    voltThres->lowerLimit = thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_LOWER_LIMIT];
    voltThres->upperLimitRec = thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_UPPER_LIMIT_REC];
    voltThres->lowerLimitRec = thresAdjPara[thresParaIndex].cfgThres[VOLT_ALM_THRES_LOWER_LIMIT_REC];

    return BSP_OK;
}
/* Ended by AICoder, pid:ha882g20815b7cb140ca0b9230e466527c59f0cf */

UINT32 getpwrthres(UINT32 cfgPwrType)
{
    UINT32 retVal = BSP_OK;
    T_VoltThres voltThres = {0};

    retVal = BspGetPowerThres(cfgPwrType, &voltThres);
    if (retVal == BSP_OK)
    {
        dbgInfo("upperLimit: %d, lowerLimit: %d, upperLimitRec: %d, lowerLimitRec: %d \n",
            voltThres.upperLimit, voltThres.lowerLimit, voltThres.upperLimitRec, voltThres.lowerLimitRec);
    }

    return retVal;
}

UINT32 BspGetAcPwrGroundCheckFlag(void)
{
    return BSP_OK;
}

UINT32 BspGetAcPwrGroundStatus(UINT32 index, UINT32 *status)
{
    return BSP_OK;
}

/* Started by AICoder, pid:w377ba9ae3eb3b614db70a8c525fe68ed8968f33 */
/**************************************************************************
* 函数名称: BspGetIcMinWorkVolt
* 功能描述: 获取IC可正常工作的最低核压
* 输入参数: 无
* 输出参数: pMinWorkVolt -- 正常工作最低核压
* 返 回 值: BSP_OK -- 成功;其它值为失败
* 其它说明: 回读芯片的efuse(小flash),识别最低电压
**************************************************************************/
UINT32 BspGetIcMinWorkVolt(UINT32 *pMinWorkVolt)
{
    UINT32 low  = 0;
    UINT32 high = 0;
    UINT32 vMin  = 0;

    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x9bc, &low, 28, 31);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x9c0, &high, 0,  5);

    vMin |= low;
    vMin |= (high << 4 );

    if (NULL == pMinWorkVolt)
    {
        dbgInfo("low = 0x%x, high = 0x%x, vMin_hex = 0x%x, vMin_dec = %dmv\n",
                low, high, vMin, vMin);
        return BSP_ERROR;
    }

    *pMinWorkVolt = vMin;

    return BSP_OK;
}

UINT32 BspSetSupportIcDynVoltFlag(BOOL isSupportFlag)
{
    s_isSupportIcDynVolt = isSupportFlag;
    return BSP_OK;
}

BOOL BspIsSupportIcDynVolt(VOID)
{
    return s_isSupportIcDynVolt;
}

UINT32 BspSetDpdicVolt(UINT32 dpdicNo, INT32 dpdicVolt)
{
    UINT32 retVal = BSP_OK;
    UINT32 pmbAdcIdx = 0;

    if ((dpdicVolt > s_icDynVoltCfg.icVoltHighThrMv) || (dpdicVolt < s_icDynVoltCfg.icVoltLowThrMv))
    {
        dbgErr("[%s] dpdicVolt[%d] is out of range(%d~%d)!\n",
                __FUNCTION__, dpdicVolt, s_icDynVoltCfg.icVoltLowThrMv, s_icDynVoltCfg.icVoltHighThrMv);
        return BSP_ERROR;
    }

    retVal |= BspSetMonitorPwrVoltOut(pmbAdcIdx, dpdicVolt);

    return retVal;
}

UINT32 BspGetDpdicVolt(UINT32 dpdicNo, INT32 *pdpdicVolt)
{
    UINT32 retVal = BSP_OK;
    UINT32 pmbAdcIdx = 0;
    INT32 volt = 0;

    retVal = BspGetMonitorPwrNominalVout(pmbAdcIdx, &volt);

    if ((NULL == pdpdicVolt) || (retVal != BSP_OK))
    {
        dbgInfo("IC Volt = %dmv, retVal = %d\n", volt, retVal);
        return BSP_ERROR;
    }

    *pdpdicVolt = volt;

    return retVal;
}

UINT32 BspGetDpdicDestVoltByTemp(INT32 dpdicTemp, INT32 *pdpdicVolt)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 minVolt = 0;
    T_icDynVoltPara *pDynVoltPara = NULL;

    INPUT_POINTER_CHECK(pdpdicVolt);

    if(NULL == s_icDynVoltCfg.pIcVoltPara)
    {
        *pdpdicVolt = INVALID_VALUE;
        dbgErr("[%s] Error, no para, pdicTemp'%d, *pdpdicVolt'%d\n",
                __FUNCTION__, dpdicTemp, *pdpdicVolt);
        return BSP_ERROR;
    }

    retVal |= BspGetIcMinWorkVolt(&minVolt);

    for (loop = 0; loop < s_icDynVoltCfg.tempVoltCfgNum; loop++)
    {
        pDynVoltPara = &(s_icDynVoltCfg.pIcVoltPara[loop]);

        if ((dpdicTemp >= pDynVoltPara->tempLowThr) 
            && (dpdicTemp < pDynVoltPara->tempHighThr)
            && (minVolt == pDynVoltPara->minWorkVolt))
        {
            *pdpdicVolt = pDynVoltPara->targetVolt;
            break;
        }
    }

    if(loop == s_icDynVoltCfg.tempVoltCfgNum)
    {
        *pdpdicVolt = INVALID_VALUE;
        dbgErr("voltage not found, dpdicTemp'%d, minVolt'%d\n", dpdicTemp, minVolt);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] dpdicTemp'%d, minVolt'%u, *pdpdicVolt'%d\n",
                __FUNCTION__, dpdicTemp, minVolt, *pdpdicVolt);

    return retVal;
}

/*复位核压芯片:不同bit置1复位对应IC的调压芯片*/
UINT32 BspResetDpdicVolt(UINT32 dpdicNo)
{
    BspRegBitValWr(0, REG_FPGA_WD_RSTDST, 0, 1, dpdicNo, dpdicNo); /*复位住*/
    BspRegBitValWr(0, REG_FPGA_WD_RSTDST, 0, 0, dpdicNo, dpdicNo); /*释放复位*/
    return BSP_OK;
}
/* Ended by AICoder, pid:w377ba9ae3eb3b614db70a8c525fe68ed8968f33 */

/* 接口打桩 */
UINT32 BspGetOverTempAlmStatus(T_PwrTempAlm *pwrTempInfo)
{
    INPUT_POINTER_CHECK(pwrTempInfo);

    pwrTempInfo->isSupport = NO_SUPPORT;
    return BSP_OK;
}

VOID BspSetAuxPowSupport(BOOL isSupport)
{
    s_AuxPowSupport = isSupport;
}

BOOL BspIsSupportAuxPow(VOID)
{
    return s_AuxPowSupport;
}

#ifndef _FUNC_INFO_PEOC_H_
#define _FUNC_INFO_PEOC_H_

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>
#include "service_framework.h"

#define MAX_FMT_STR (50)
#define MAX_FUNC_NUM (100)
#define MAX_FUNC_CATEGORY (200 + 1)/* 目前预留200种函数功能+1种测试接口 */

typedef struct tagFuncInfo
{
    uint32_t cmd;
    char fmt[MAX_FMT_STR];
    BspServiceFuncVarArgs serviceFunc;
    struct tagFuncInfo *next;
} T_FuncInfo;

uint32_t addFuncInfo(uint32_t cmd, const char *fmt, BspServiceFuncVarArgs serviceFunc);
T_FuncInfo *findFuncInfo(uint32_t cmd);
char* getFuncFmt(uint32_t cmd);
BspServiceFuncVarArgs getFuncServiceFunc(uint32_t cmd);
void printFuncInfo(uint32_t cmd);
void printAllFuncInfo();
void deleteFuncInfo(uint32_t cmd);
void deleteAllFuncInfo();

#ifdef __cplusplus
}
#endif

#endif
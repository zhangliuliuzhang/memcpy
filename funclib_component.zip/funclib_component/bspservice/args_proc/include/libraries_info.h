#ifndef _LIBRARIES_INFO_H_
#define _LIBRARIES_INFO_H_

#ifdef __cplusplus
extern "C" {
#endif

int BspLibrariesInfoAnalyseFromJson(void);
int BspLoadServices(void);

#ifdef __cplusplus
}
#endif

#endif
#ifndef __ARGS_PROC_H__
#define __ARGS_PROC_H__

#include <stdint.h>
#include <string>
#include <vector>
#include "service_framework_struct.h"
class ArgsProcesser
{
public:
    ArgsProcesser() = default;
    ~ArgsProcesser()
    {
        if (nullptr != _inputTlvMsgBuf)
        {
            free(_inputTlvMsgBuf);
            _inputTlvMsgBuf = nullptr;
        }
        if (nullptr != _outputTlvMsgBuf)
        {
            free(_outputTlvMsgBuf);
            _outputTlvMsgBuf = nullptr;
        }
        return;
    }

    uint32_t GetCmdFmt(uint32_t cmd);
    const char *GetFmtStr();
    uint32_t GetService(uint32_t cmd, BspServiceFuncVarArgs handle, const std::vector<uint64_t> &argsList);

private:
    /* _inputTlvBuf是需要把高层传入的所有参数都转换为TLV保存 */
    uint8_t *_inputTlvMsgBuf = nullptr;
    uint8_t *_outputTlvMsgBuf = nullptr;
    std::string _cmdFmt = ""; /* cmd对应的字符串 */
    std::string _inParaFmt = ""; /* 入参 */
    std::string _outParaFmt = "";
    const char* GetFmtByCmd(uint32_t cmd);
};

#endif
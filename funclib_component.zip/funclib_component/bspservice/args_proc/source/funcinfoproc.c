#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funcinfoproc.h"

static T_FuncInfo *funcInfoMap[MAX_FUNC_CATEGORY] = {};

// 创建一个新节点
static T_FuncInfo *createFuncInfoNode(uint32_t cmd, const char *fmt, BspServiceFuncVarArgs serviceFunc)
{
    T_FuncInfo *funcInfoNode = NULL;

    funcInfoNode = (T_FuncInfo *)malloc(sizeof(T_FuncInfo));
    if (NULL == funcInfoNode)
    {
        printf("createFuncInfoNode malloc is error.\n");
        return NULL;
    }
    
    funcInfoNode->cmd = cmd;
    if (NULL != fmt)
    {
        strncpy(funcInfoNode->fmt, fmt, MAX_FMT_STR - 1);
        funcInfoNode->fmt[MAX_FMT_STR - 1] = '\0';
    }
    if (NULL != serviceFunc)
    {
        funcInfoNode->serviceFunc = serviceFunc;
    }
    funcInfoNode->next = NULL;

    return funcInfoNode;
}

static uint32_t updateFuncInfo(uint32_t cmd, const char *fmt, BspServiceFuncVarArgs serviceFunc)
{
    uint32_t category = (cmd >> 16) & 0xFFFF;
    uint32_t index = cmd & 0xFFFF;

    if (category >= MAX_FUNC_CATEGORY || index >= MAX_FUNC_NUM)
    {
        printf("updateFuncInfo Invalid cmd: 0x%08X\n", cmd);
        return 0;
    }

    T_FuncInfo *funcInfoNode = funcInfoMap[category];
    while (funcInfoNode != NULL)
    {
        if (funcInfoNode->cmd == cmd)
        {
            if (NULL != fmt)
            {
                strncpy(funcInfoNode->fmt, fmt, MAX_FMT_STR - 1);
                funcInfoNode->fmt[MAX_FMT_STR - 1] = '\0';
            }
            if (NULL != serviceFunc)
            {
                funcInfoNode->serviceFunc = serviceFunc;
            }
            return 1;
        }
        funcInfoNode = funcInfoNode->next;
    }

    return 0;
}

uint32_t addFuncInfo(uint32_t cmd, const char *fmt, BspServiceFuncVarArgs serviceFunc)
{
    uint32_t category = (cmd >> 16) & 0xFFFF;
    uint32_t index = cmd & 0xFFFF;
    T_FuncInfo *newFuncInfo = NULL;
    T_FuncInfo *lastFuncInfo = NULL;

    if (category >= MAX_FUNC_CATEGORY || index >= MAX_FUNC_NUM)
    {
        printf("addFuncInfo Invalid cmd: 0x%08X\n", cmd);
        return 0;
    }

    if (funcInfoMap[category] == NULL)
    {
        newFuncInfo = createFuncInfoNode(cmd, fmt, serviceFunc);
        funcInfoMap[category] = newFuncInfo;
    }
    else
    {
        if (0 == updateFuncInfo(cmd, fmt, serviceFunc))
        {
            lastFuncInfo = funcInfoMap[category];
            while (lastFuncInfo->next != NULL)
            {
                lastFuncInfo = lastFuncInfo->next;
            }
            /* PS:这里要不要加一个条件，当仅想注册时，发现没有对应的fmt,就不增加这个节点？ */
            newFuncInfo = createFuncInfoNode(cmd, fmt, serviceFunc);
            lastFuncInfo->next = newFuncInfo;
        }
    }

    return 1;
}

T_FuncInfo *findFuncInfo(uint32_t cmd)
{
    uint32_t category = (cmd >> 16) & 0xFFFF;
    uint32_t index = cmd & 0xFFFF;

    if (category >= MAX_FUNC_CATEGORY || index >= MAX_FUNC_NUM)
    {
        printf("findFuncInfo Invalid cmd: 0x%08X\n", cmd);
        return NULL;
    }

    T_FuncInfo *funcInfoNode = funcInfoMap[category];
    while (funcInfoNode != NULL)
    {
        if (funcInfoNode->cmd == cmd)
        {
            return funcInfoNode;
        }
        funcInfoNode = funcInfoNode->next;
    }

    printf("findFuncInfo FuncInfo not found for cmd: 0x%08X\n", cmd);
    return NULL;
}

char* getFuncFmt(uint32_t cmd)
{
    T_FuncInfo *funcInfoNode = findFuncInfo(cmd);
    if (funcInfoNode != NULL)
    {
        return funcInfoNode->fmt;
    }
    else
    {
        printf("getFuncFmt FuncInfo not found for cmd: 0x%08X\n", cmd);
        return NULL;
    }
}

BspServiceFuncVarArgs getFuncServiceFunc(uint32_t cmd)
{
    T_FuncInfo *funcInfoNode = findFuncInfo(cmd);
    if (funcInfoNode != NULL)
    {
        return funcInfoNode->serviceFunc;
    }
    else
    {
        printf("getFuncServiceFunc FuncInfo not found for cmd: 0x%08X\n", cmd);
        return NULL;
    }
}

void printFuncInfo(uint32_t cmd)
{
    T_FuncInfo *funcInfoNode = findFuncInfo(cmd);
    if (funcInfoNode != NULL)
    {
        printf("printFuncInfo FuncInfo found: cmd=0x%08X, fmt=%s, serviceFunc=%p\n", \
            cmd, funcInfoNode->fmt, funcInfoNode->serviceFunc);
    }
    else
    {
        printf("printFuncInfo FuncInfo not found for cmd: 0x%08X\n", cmd);
    }
}

void printAllFuncInfo()
{
    for (int i = 0; i < MAX_FUNC_CATEGORY; i++)
    {
        T_FuncInfo *funcInfoNode = funcInfoMap[i];
        while (NULL != funcInfoNode)
        {
            printf("printAllFuncInfo FuncInfo: cmd = 0x%08X, fmt = %s, serviceFunc = %p\n", \
                funcInfoNode->cmd, funcInfoNode->fmt, funcInfoNode->serviceFunc);
            funcInfoNode = funcInfoNode->next;
        }
    }
}

void deleteFuncInfo(uint32_t cmd)
{
    uint32_t category = (cmd >> 16) & 0xFFFF;
    uint32_t index = cmd & 0xFFFF;

    if (category >= MAX_FUNC_CATEGORY || index >= MAX_FUNC_NUM)
    {
        printf("deleteFuncInfo Invalid cmd: 0x%08X\n", cmd);
        return;
    }

    T_FuncInfo *prevFuncInfo = NULL;
    T_FuncInfo *funcInfoNode = funcInfoMap[category];
    while (funcInfoNode != NULL)
    {
        if (funcInfoNode->cmd == cmd)
        {
            if (prevFuncInfo == NULL)
            {
                funcInfoMap[category] = funcInfoNode->next;
            }
            else
            {
                prevFuncInfo->next = funcInfoNode->next;
            }
            free(funcInfoNode);
            printf("deleteFuncInfo FuncInfo deleted for cmd: 0x%08X\n", cmd);
            return;
        }
        prevFuncInfo = funcInfoNode;
        funcInfoNode = funcInfoNode->next;
    }

    printf("deleteFuncInfo FuncInfo not found for cmd: 0x%08X\n", cmd);
}

void deleteAllFuncInfo()
{
    for (int i = 0; i < MAX_FUNC_CATEGORY; i++)
    {
        T_FuncInfo *funcInfoNode = funcInfoMap[i];
        while (funcInfoNode != NULL)
        {
            T_FuncInfo *nextFuncInfo = funcInfoNode->next;
            free(funcInfoNode);
            funcInfoNode = nextFuncInfo;
        }
        funcInfoMap[i] = NULL;
    }
    printf("deleteAllFuncInfo All FuncInfo deleted.\n");
}


/* Started by AICoder, pid:127c8d6e79s6f151495b094f700a735a93600a69 */
// 打印指定cmd的FuncInfo信息
void printFuncInfoCmd(uint32_t cmd)
{
    printf("printFuncInfoCmd: cmd = 0x%08X\n", cmd);
    printFuncInfo(cmd);

    return;
}

// 打印所有FuncInfo信息
void printAllFuncInfoCmd()
{
    printf("printAllFuncInfoCmd\n");
    printAllFuncInfo();

    return;
}

// 删除指定cmd的FuncInfo信息
void deleteFuncInfoCmd(uint32_t cmd)
{
    printf("deleteFuncInfoCmd: cmd = 0x%08X\n", cmd);
    deleteFuncInfo(cmd);

    return;
}

// 删除所有FuncInfo信息
void deleteAllFuncInfoCmd()
{
    printf("deleteAllFuncInfoCmd\n");
    deleteAllFuncInfo();

    return;
}

// 添加FuncInfo信息
void addFuncInfoCmd(uint32_t cmd, const char *fmt, BspServiceFuncVarArgs serviceFunc)
{
    printf("addFuncInfoCmd: cmd = 0x%08X, fmt = %s, serviceFunc = %p\n", cmd, fmt, serviceFunc);
    addFuncInfo(cmd, fmt, serviceFunc);

    return;
}

// 调用指定cmd的serviceFunc函数
void callServiceFuncCmd(uint32_t cmd)
{
    printf("callServiceFuncCmd: cmd = 0x%08X\n", cmd);
    BspServiceFuncVarArgs serviceFunc = getFuncServiceFunc(cmd);
    if (serviceFunc != NULL)
    {
        // 调用serviceFunc函数
        serviceFunc(cmd);
    }
    else
    {
        printf("callServiceFuncCmd: serviceFunc not found for cmd: 0x%08X\n", cmd);
    }

    return;
}
/* Ended by AICoder, pid:127c8d6e79s6f151495b094f700a735a93600a69 */

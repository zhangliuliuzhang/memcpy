#include <stdint.h>
#include <vector>
#include <memory>
#include <string>
#include <cstring>
#include <dlfcn.h>
#include "cJSON.h"
#include "args_proc.h"
#include "libraries_info.h"
#include "service_framework_struct.h"
#include "funcinfoproc.h"

#define __param0
#define __param1 cmd
#define __param2 __param1,argsList[0]
#define __param3 __param2,argsList[1]
#define __param4 __param3,argsList[2]
#define __param5 __param4,argsList[3]
#define __param6 __param5,argsList[4]
#define __param7 __param6,argsList[5]
#define __param8 __param7,argsList[6]
#define __param9 __param8,argsList[7]
#define __param10 __param9,argsList[8]
#define __param11 __param10,argsList[9]
#define __param12 __param11,argsList[10]
#define __param13 __param12,argsList[11]
#define __param14 __param13,argsList[12]
#define __param15 __param14,argsList[13]
#define __param16 __param15,argsList[14]

#define __call0 \
    case 0: \
        if(pfunc) { \
            ret = pfunc(0); \
        } \
        break;

#define __call(n) \
    case n: \
        if(pfunc) { \
            ret = pfunc(__param##n); \
        } \
        break;


uint32_t ArgsProcesser::GetService(uint32_t cmd, BspServiceFuncVarArgs pfunc, const std::vector<uint64_t> &argsList)
{
    uint32_t ret = 0;
    uint32_t argsNum = argsList.size() + 1;

    switch (argsNum)
    {
        __call0
        __call(1)
        __call(2)
        __call(3)
        __call(4)
        __call(5)
        __call(6)
        __call(7)
        __call(8)
        __call(9)
        __call(10)
        __call(11)
        __call(12)
        __call(13)
        __call(14)
        __call(15)
        __call(16)
    }
    return ret;
}

#define MAX_LIBRARIES (100)
#define MAX_FUNCTIONS (1000)
#define CMD_TEST_BASE_NUMBER (200000)

#define MAX_LIBRARY_NAME_STR (50)
#define NOT_DYNAMIC_TEST (0)
#define IS_DYNAMIC_TEST (1)
#define LIBRARY_NORMAL (0)
#define LIBRARY_TEST (1)

typedef struct tagLibraryInfo
{
    uint32_t testFlag;
    char libraryNames[MAX_LIBRARY_NAME_STR];
} T_LibraryInfo;

typedef struct tagLibraryInfoResult
{
    T_LibraryInfo sLibraryInfo[MAX_LIBRARIES];
    int libraryCount;
} T_LibraryInfoResult;

static T_LibraryInfoResult sLibraryInfoResult = {};

T_LibraryInfoResult* getLibraryInfo() 
{
    return (&sLibraryInfoResult);
}

/* 该接口只允许调用一次，否则会造成内存泄露，详见：strdup */
int BspLibrariesInfoAnalyseFromJson(void)
{
    FILE *fp = NULL;
    char *json = NULL;
    long fileSize = 0;
    cJSON *root = NULL;
    cJSON *librariesArray = NULL;
    cJSON *libraryObject = NULL;
    cJSON *functionInfoArray = NULL;
    cJSON *functionInfoObject = NULL;
    int dynamicTestFlag = NOT_DYNAMIC_TEST;
    int argsFmtCount = 0;
    int libraryCount = 0;

#ifdef DYNAMIC_API_TEST
    dynamicTestFlag = IS_DYNAMIC_TEST;
#endif
    printf("BspLibrariesInfoAnalyseFromJson dynamicTestFlag = %d\n", dynamicTestFlag);

    fp = fopen("bspservices.json", "r");
    if (fp == NULL)
    {
        printf("Failed to open file.\n");
        return 1;
    }
    fseek(fp, 0, SEEK_END);
    fileSize = ftell(fp);
    fseek(fp, 0, SEEK_SET);
    json = (char *)malloc(fileSize + 1);
    fread(json, 1, fileSize, fp);
    fclose(fp);

    root = cJSON_Parse(json);
    if (root == NULL)
    {
        printf("Failed to parse JSON.\n");
        return 1;
    }

    librariesArray = cJSON_GetObjectItem(root, "libraries");
    if (librariesArray == NULL || !cJSON_IsArray(librariesArray))
    {
        printf("Invalid libraries array.\n");
        cJSON_Delete(root);
        return 1;
    }

    cJSON_ArrayForEach(libraryObject, librariesArray)
    {
        cJSON *libraryName = cJSON_GetObjectItem(libraryObject, "name");
        if (libraryName != NULL && cJSON_IsString(libraryName))
        {
            cJSON *libraryType = cJSON_GetObjectItem(libraryObject, "type");
            if (libraryType != NULL && cJSON_IsNumber(libraryType))
            {
                sLibraryInfoResult.sLibraryInfo[libraryCount].testFlag = libraryType->valueint;
            }
            else
            {
                sLibraryInfoResult.sLibraryInfo[libraryCount].testFlag = LIBRARY_NORMAL;
            }
            if ((LIBRARY_NORMAL == sLibraryInfoResult.sLibraryInfo[libraryCount].testFlag) || \
                ((IS_DYNAMIC_TEST == dynamicTestFlag) && (LIBRARY_TEST == sLibraryInfoResult.sLibraryInfo[libraryCount].testFlag)))
            {
                strncpy(sLibraryInfoResult.sLibraryInfo[libraryCount].libraryNames, libraryName->valuestring, \
                    sizeof(sLibraryInfoResult.sLibraryInfo[libraryCount].libraryNames));
                libraryCount++;
            }
        }
        sLibraryInfoResult.libraryCount = libraryCount;

        functionInfoArray = cJSON_GetObjectItem(libraryObject, "function_info");
        if (functionInfoArray == NULL || !cJSON_IsArray(functionInfoArray))
        {
            printf("Invalid function_info array.\n");
            continue;
        }

        cJSON_ArrayForEach(functionInfoObject, functionInfoArray)
        {
            cJSON *cmd = cJSON_GetObjectItem(functionInfoObject, "cmd");
            cJSON *fmt = cJSON_GetObjectItem(functionInfoObject, "fmt");
            if (cmd != NULL && cJSON_IsString(cmd) && fmt != NULL && cJSON_IsString(fmt))
            {
                uint32_t cmdValue = strtoul(cmd->valuestring, NULL, 16);
                if ((cmdValue < CMD_TEST_BASE_NUMBER) || ((IS_DYNAMIC_TEST == dynamicTestFlag) && (cmdValue >= CMD_TEST_BASE_NUMBER)))
                {
                    argsFmtCount++;
                    if (1 != addFuncInfo(cmdValue, fmt->valuestring, NULL))
                    {
                        printf("BspLibrariesInfoAnalyseFromJson addFuncInfo:fmt Err!\n");
                    }
                }
            }
        }
    }

    for (int i = 0; i < libraryCount; i++)
    {
        printf("Library Name: %s\n", sLibraryInfoResult.sLibraryInfo[i].libraryNames);
    }

    printf("argsFmtCount = %u\n", argsFmtCount);

    cJSON_Delete(root);
    free(json);

    return 0;
}

int BspLoadServices(void)
{
    void *pHandle = NULL;

    for(int i=0; i < sLibraryInfoResult.libraryCount; i++)
    {
        pHandle = dlopen(sLibraryInfoResult.sLibraryInfo[i].libraryNames, RTLD_LAZY);
        if(NULL == pHandle)
        {
            const char* error = dlerror();
            if (error != NULL)
            {
                printf("%s dlopen error: %s，libName=%s\n", __func__, error, sLibraryInfoResult.sLibraryInfo[i].libraryNames);
            }
            continue;
        }

    }

    return 0;
}

const char* ArgsProcesser::GetFmtByCmd(uint32_t cmd)
{
    printf("ArgsProcesser::GetFmtByCmd cmd = %#x\n", cmd);
    return getFuncFmt(cmd);
}

uint32_t ArgsProcesser::GetCmdFmt(uint32_t cmd)
{
    auto fmtTemp = GetFmtByCmd(cmd);
    if (nullptr == fmtTemp)
    {
        /* 可以在这里完成判断以后，加入默认的CmdData处理 */
        /* 即使是无参函数，fmt为空串，也不会是nullptr，只有没配置的才是空 */
        return -1;
    }
    auto fmt = std::string(fmtTemp);
    /* 无参场景 */
    if (fmt.empty())
    {
        return 0;
    }
    /* 将fmt按照入参和出参按照\\o进行分割组合，存入_inParaFmt和_outParaFmt */
    const std::string delimiter = "\\o";
    int pos = fmt.find(delimiter);
    if (pos == -1)
    {
        /* 没有出参 */
        _inParaFmt = fmt;
        return 0;
    }
    /* 按照\\o拆分为出参和入参，如"%d%u%p%x%p%u%s%u\\o%p%x"，拆分后，入参是%d%u%p%x%p%u%s%u，出参是%p%x */
    _inParaFmt = fmt.substr(0, pos);
    _outParaFmt = fmt.substr(pos + delimiter.length());
    _cmdFmt = _inParaFmt + _outParaFmt;
    return 0;
}

const char *ArgsProcesser::GetFmtStr()
{
    return _cmdFmt.c_str();
}

static std::vector<std::string> SplitFmtStr(const std::string &inputStr)
{
    std::vector<std::string> tokens;

    const char delimiter = '%';
    std::string token;
    size_t startPos = 0;
    size_t endPos = 0;
    while ((endPos = inputStr.find(delimiter, startPos)) != std::string::npos)
    {
        token = inputStr.substr(startPos, endPos - startPos);
        if (!token.empty())
        {
            tokens.push_back(token);
        }
        startPos = endPos + 1;
    }

    token = inputStr.substr(startPos);
    if (!token.empty())
    {
        tokens.push_back(token);
    }
    return tokens;
}

#include <vector>
#include <map>
#include <stdint.h>
#include "service_framework.h"

using namespace std;

/* 基础服务设计为单例模式，只实例化一次，Service保存在静态存储区 */
class SingletonService
{
public:
    static SingletonService& GetInstance()
    {
        static SingletonService Service;
        return Service;
    }

    void RegistService(uint32_t cmd, BspServiceFuncVarArgs serviceFunc);
    void UnregistService(uint32_t cmd);
    BspServiceFuncVarArgs GetServiceHandle(uint32_t cmd);
private:
    map<uint32_t, BspServiceFuncVarArgs> serviceList {};
    SingletonService() = default;
    ~SingletonService() = default;
    SingletonService(const SingletonService&) = delete;
    SingletonService& operator=(const SingletonService&) = delete;
};

void SingletonService::RegistService(uint32_t cmd, BspServiceFuncVarArgs serviceFunc)
{
    auto it = serviceList.find(cmd);
    if (it == serviceList.end())
    {
        serviceList.emplace(cmd, serviceFunc);
    }
    else
    {
        it->second = serviceFunc;
        printf("BSP_SERVICE WARNING : cmd %#x exist, will be rewrite\n", cmd);
    }
    return;
}

void SingletonService::UnregistService(uint32_t cmd)
{
    auto it = serviceList.find(cmd);
    if (it == serviceList.end())
    {
        printf("BSP_SERVICE WARNING : service not exist, cmd %#x\n", cmd);
    }

    serviceList.erase(it);
    return;
}

BspServiceFuncVarArgs SingletonService::GetServiceHandle(uint32_t cmd)
{
    auto it = serviceList.find(cmd);
    if (it == serviceList.end())
    {
        printf("BSP_SERVICE ERROR : service not exist, cmd %#x\n", cmd);
        return 0;
    }

    return it->second;
}

/* 对外API封装为C接口给高层调用 */
/* 动态注册接口 */
void BspRegistService(uint32_t cmd, BspServiceFuncVarArgs serviceFunc)
{
    SingletonService::GetInstance().RegistService(cmd, serviceFunc);
    return;
}

/* 动态注销接口 */
void BspUnregistService(uint32_t cmd)
{
    SingletonService::GetInstance().UnregistService(cmd);
    return;
}

/* 获取句柄接口，不直接调用API，只拿到API的函数指针地址，为了支持可变参调用 */
BspServiceFuncVarArgs BspGetService(uint32_t cmd)
{
    /*printf("BspGetService cmd = %d\n", cmd);*/
    return SingletonService::GetInstance().GetServiceHandle(cmd);
}

#ifndef SERVICE_FRAMEWORK_H
#define SERVICE_FRAMEWORK_H

#include <stdint.h>
#include "service_framework_struct.h"
#ifdef __cplusplus
extern "C" {
#endif


void BspRegistService(uint32_t cmd, BspServiceFuncVarArgs serviceFunc);
void BspUnregistService(uint32_t cmd);
BspServiceFuncVarArgs BspGetService(uint32_t cmd);

#ifdef __cplusplus
}
#endif

#endif
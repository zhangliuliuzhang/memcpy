#ifndef SERVICE_FRAMEWORK_STRUCT_H
#define SERVICE_FRAMEWORK_STRUCT_H

#include <stdint.h>

typedef struct tagCmdData
{
    void *data;
    uint32_t dataLen;
} CmdData;

typedef uint32_t (*BspServiceFunc)(const CmdData *dataIn, CmdData *dataOut);
typedef uint32_t (*BspServiceFuncVarArgs)(uint32_t cmd, ...);

typedef BspServiceFuncVarArgs (*ServiceFuncPtr)(uint32_t cmd);

#endif
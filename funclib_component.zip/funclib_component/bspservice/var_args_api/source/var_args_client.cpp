#include <cstdarg>
#include <cstdint>
#include <vector>
#include <cstring>
#include "var_args_client.h"
#include "args_proc.h"
#include "service_framework_struct.h"
#include "service_framework.h"

static uint32_t ParseFmt(const char *format, va_list args, std::vector<uint64_t> &argsList)
{
    const char *p = format;
    while (*p)
    {
        if (*p == '%')
        {
            int temp = 0;
            ++p;
            switch (*p)
            {
            case 'h':
                if (*(p + 1) == 'h')
                {
                    /* 有符号数不能直接强转成uint64，需要进行内存拷贝保证精度不丢失 */
                    temp = va_arg(args, int);
                    argsList.push_back(0);
                    memcpy(&argsList.back(), &temp, sizeof(int));
                    ++p;
                }
                else
                {
                    temp = va_arg(args, int);
                    argsList.push_back(0);
                    memcpy(&argsList.back(), &temp, sizeof(int));
                }
                break;
            case 'l':
                if (*(p + 1) == 'l')
                {
                    argsList.push_back(static_cast<uint64_t>(va_arg(args, long long)));
                    ++p;
                }
                else
                {
                    argsList.push_back(static_cast<uint64_t>(va_arg(args, long)));
                }
                break;
            case 'd':
                temp = va_arg(args, int);
                argsList.push_back(0);
                memcpy(&argsList.back(), &temp, sizeof(int));
                break;
            case 'u':
            case 'x':
                argsList.push_back(static_cast<uint64_t>(va_arg(args, uint32_t)));
                break;
            case 's':
                argsList.push_back(reinterpret_cast<uint64_t>(va_arg(args, const char *)));
                break;
            case 'p':
                argsList.push_back(static_cast<uint64_t>(reinterpret_cast<uintptr_t>(va_arg(args, void *))));
                break;
            default:
                break;
            }
        }
        ++p;
    }

    return 0;
}

uint32_t SplCallDefaultService(uint32_t cmd, va_list arg)
{
    CmdData *dataIn = va_arg(arg, CmdData *);
    CmdData *dataOut = va_arg(arg, CmdData *);
    // return SplCallService(cmd, dataIn, dataOut); // 指针形式，待定
    return 0;
}

uint32_t SplCallServiceVarArgs(uint32_t cmd, ...)
{
    uint8_t *inputTlvBuf = nullptr;
    uint32_t inputBufLen = 0;
    uint8_t *outputTlvBuf = nullptr;
    uint32_t outputBufLen = 0;
    uint32_t ret = 0;

    std::vector<uint64_t> argsList = {};
    ArgsProcesser argsProcessor;
    va_list arg;
    va_start(arg, cmd);

    /* 1 判断cmd是否有对应的格式化字符串，如果没有，就需要使用默认的CmdData去构造入参 */
    int iRet = argsProcessor.GetCmdFmt(cmd);
    if (-1 == iRet)
    {
        printf("cmd:%#x argsProcessor.GetCmdFmt is null\r\n", cmd);
        return iRet;
        /* 走默认的CmdData格式，默认3个入参格式： cmd, cmdDataIn, cmdDataOut */
        // return SplCallDefaultService(cmd, arg);
    }

    /* 2 解析fmt，获取所有参数值，需要考虑无参场景 */
    auto format = argsProcessor.GetFmtStr();
    ParseFmt(format, arg, argsList);
    va_end(arg);

    /*printf("SplCallServiceVarArgs cmd = %u, fmt = %s\n", cmd, format);*/

    BspServiceFuncVarArgs funcHandle = NULL;
    funcHandle = BspGetService(cmd);
    if (NULL == funcHandle)
    {
        printf("SplCallServiceVarArgs cmd = %#x, funcHandle is NULL!\n", cmd);
        return SPL_ERR;
    }

    /*printf("SplCallServiceVarArgs cmd = %u 调用handle，完成函数最终调用\n", cmd);*/
    /* 3 调用handle，完成函数最终调用 */
    ret = argsProcessor.GetService(cmd, funcHandle, argsList);


    return ret;
}




#ifndef _VAR_ARGS_CLIENT_H_
#define _VAR_ARGS_CLIENT_H_

#include <stdint.h>


#ifdef __cplusplus
extern "C" {
#endif

#define SPL_OK  0
#define SPL_ERR 1

uint32_t SplCallServiceVarArgs(uint32_t cmd, ...);

#ifdef __cplusplus
}
#endif

#endif






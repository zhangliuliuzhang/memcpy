/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : iqcfg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板iq配置相关接口程序
* 注意事项 : 无
* 作    者 : 刘志敬
* 创建日期 : 2015-02-20 10:21:48
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/
#include <string.h>

#include "iqcfg.h"
#include "exprn.h"
#include "rruadp.h"
#include "bspcomm.h"
/**************************************************************************
*                        宏
**************************************************************************/
/*@@@@@@@@@@@@@@@@@@@@@@@@@@@公共宏定义@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

/***************************************************************/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD CDMA宏定义@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD UMTS宏定义@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD GSM宏定义@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD LTE宏定义@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
/*@@@@@@@@@@@@@@@@@@@@@@@@@公共数据类型@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
T_PRruIqCfgItem atIqItem_Now[BSP_MAX_IQ_ITEM_NUM] = {0};
T_PRruIqCfgItem atIqItem_Old[BSP_MAX_IQ_ITEM_NUM] = {0};

/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD CDMA数据类型@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD UMTS数据类型@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD GSM数据类型@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD LTE数据类型@@@@@@@@@@@@@@@@@@@@@@@@*/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
/*@@@@@@@@@@@@@@@@@@@@@@@@@公共全局变量@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD CDMA全局变量@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD UMTS全局变量@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD GSM全局变量@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD LTE全局变量@@@@@@@@@@@@@@@@@@@@@@@@*/
/*压缩模式配置*/

extern TIqAxcCfgNum_NR atAxcCfg_NR_Qcell[];
extern UINT32 gulMaxCfgCnt;
/**************************************************************************
*                         外部变量声明
**************************************************************************/
extern T_PRruIqCfg gIqCfgInfo_Now[MAX_CC_NUM];     /*IQ表*/
extern T_PRruIqCfg gIqCfgInfo_CMP_Now[MAX_CC_NUM]; /*IQ表保存CMP发过来的IQ配置*/
extern T_PRruIqCfg gIqCfgInfo_TCM_Now[MAX_CC_NUM]; /*IQ表保存TCM发过来的IQ配置*/

/*@@@@@@@@@@@@@@@@@@@@@@@@@公共外部变量@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD CDMA外部变量@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD UMTS外部变量@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD GSM外部变量@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD LTE外部变量@@@@@@@@@@@@@@@@@@@@@@@@*/
/**************************************************************************
*                         局部函数声明
**************************************************************************/

/*@@@@@@@@@@@@@@@@@@@@@@@@@公共局部函数@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD CDMA局部函数@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD UMTS局部函数@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD GSM局部函数@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD LTE局部函数@@@@@@@@@@@@@@@@@@@@@@@@*/
/**************************************************************************
*                         全局函数声明
**************************************************************************/

/*@@@@@@@@@@@@@@@@@@@@@@@@@公共全局函数@@@@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD CDMA全局函数@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD UMTS全局函数@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD GSM全局函数@@@@@@@@@@@@@@@@@@@@@@@@*/
/*@@@@@@@@@@@@@@@@@@@@@@@@@FDD LTE全局函数@@@@@@@@@@@@@@@@@@@@@@@@*/

/**************************************************************************
*                         函数实现
**************************************************************************/

/**************************************************************************
 * 函数名称: BspClearElecPortIqCfg
 * 功能描述: 电口配置清除
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年07月10日                          刘志敬    创建
 **************************************************************************/
VOID BspClearElecPortIqCfg(ULONG ulProductRadio, ULONG ulCnt)
{
}

/**************************************************************************
 * 函数名称: BspClearElecPortIqCfgLog
 * 功能描述: 电口配置清除log
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年07月10日                          刘志敬    创建
 **************************************************************************/
VOID BspClearElecPortIqCfgLog(ULONG ulProductRadio, ULONG ulCnt)
{
}

/**************************************************************************
 * 函数名称: BspClearElecPortCfg
 * 功能描述: 电口配置清除log
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年07月10日                          刘志敬    创建
 **************************************************************************/
VOID BspClearElecPortCfg(VOID)
{
}

/**************************************************************************
 * 函数名称: BspCheckIqCfgType
 * 功能描述: 判断配置为修改、删除还是无变化
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月19日                          刘志敬    创建
 **************************************************************************/
ULONG BspCheckIqCfgType(T_PRruIqCfgItem *ptCfg_Now, T_PRruIqCfgItem *ptCfg_Old, ULONG ulItemNum)
{
    ULONG ulCnt_Now = 0;
    ULONG ulCnt_Old = 0;
    ULONG ulLpNow = 0;
    ULONG ulLpOld = 0;
    ULONG ulSize = 0;

    ulSize = sizeof(T_PRruIqCfgItem);

    for (ulLpNow = 0; ulLpNow < ulItemNum; ulLpNow++)
    {
        if (0 == ptCfg_Now[ulLpNow].ucRadioMode)
        {
            dbgInfoEx("%s %d now cfg ulLpNow %d null! \n", __FUNCTION__, __LINE__, ulLpNow);
            break;
        }
        for (ulLpOld = 0; ulLpOld < ulItemNum; ulLpOld++)
        {
            if (0 == ptCfg_Old[ulLpOld].ucRadioMode)
            {
                dbgInfoEx("%s %d old cfg ulLpOld %d null! \n", __FUNCTION__, __LINE__, ulLpOld);
                continue;
            }
            if (BSP_OK == memcmp(&ptCfg_Now[ulLpNow], &ptCfg_Old[ulLpOld], ulSize))
            {
                dbgInfoEx("%s %d  ulLpNow %d ulLpOld %d same! \n", __FUNCTION__, __LINE__, ulLpNow, ulLpOld);
                break;
            }
        }
        if (ulLpOld == ulItemNum)
        {
            ulCnt_Now++;
            dbgInfoEx("%s %d  ulLpNow %d can't find ,ulCnt_Now = %d !\n", __FUNCTION__, __LINE__, ulLpNow, ulCnt_Now);
        }
    }
    for (ulLpOld = 0; ulLpOld < ulItemNum; ulLpOld++)
    {
        if (0 == ptCfg_Old[ulLpOld].ucRadioMode)
        {
            dbgInfoEx("%s %d old cfg ulLpOld %d null! \n", __FUNCTION__, __LINE__, ulLpOld);
            break;
        }
        for (ulLpNow = 0; ulLpNow < ulItemNum; ulLpNow++)
        {
            if (0 == ptCfg_Now[ulLpNow].ucRadioMode)
            {
                dbgInfoEx("%s %d now cfg ulLpNow %d null! \n", __FUNCTION__, __LINE__, ulLpNow);
                continue;
            }
            if (BSP_OK == memcmp(&ptCfg_Old[ulLpOld], &ptCfg_Now[ulLpNow], ulSize))
            {
                dbgInfoEx("%s %d  ulLpNow %d ulLpOld %d same! \n", __FUNCTION__, __LINE__, ulLpNow, ulLpOld);
                break;
            }
        }
        if (ulLpNow == ulItemNum)
        {
            ulCnt_Old++;
            dbgInfoEx("%s %d  ulLpOld %d can't find ,ulCnt_Old = %d !\n", __FUNCTION__, __LINE__, ulLpOld, ulCnt_Old);
        }
    }

    if ((0 == ulCnt_Now) && (0 == ulCnt_Old))
    {
        dbgInfoEx("%s %d  no change !\n", __FUNCTION__, __LINE__);
        return IQ_CFG_NO_CHANGE;
    }
    else if (0 == ulCnt_Now)
    {
        dbgInfoEx("%s %d del !\n", __FUNCTION__, __LINE__);
        return IQ_CFG_DEL;
    }
    else
    {
        dbgInfoEx("%s %d add !\n", __FUNCTION__, __LINE__);
        return IQ_CFG_ADD;
    }
    return IQ_CFG_ADD;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg_U
 * 功能描述: 电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfg_U(T_PRruIqCfgItem *ptIqCfgItem, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulIqLp = 0;
    ULONG ulIqCnt = 0;
    ULONG ulElecPortBand = 0;
    ULONG ulNestElecAddr = 0;
    T_PRruIqCfgItem *ptIqItem = NULL;

    ptIqItem = ptIqCfgItem;

    ulNestElecAddr = ulStartElecAddr;

    for (ulIqLp = 0; ulIqLp < ulLeaveIqNum; ulIqLp++)
    {
        if (PRODUCT_IQ_MODE_UMTS != ptIqItem->ucRadioMode) /*制式处理完退出*/
        {
            break;
        }

        ptIqItem++;
        ulIqCnt++;
    }

    ulElecPortBand = ELEC_PORT_DEF_BYTE_4UMTS;
    //FpgaRegWrite(0,FPGA_UMTS_IQ_BAND,0x0a);

    if (ulIqCnt) /*IQ条数不为0时，才配置电口*/
    {
        //FpgaRegWrite(0,FPGA_UMTS_IQ_START_ODD,ulNestElecAddr);
        //FpgaRegWrite(0,FPGA_UMTS_IQ_END_ODD,ulNestElecAddr+ulElecPortBand-1);
        //FpgaRegWrite(0,FPGA_UMTS_IQ_START_EVEN,ulNestElecAddr);
        //FpgaRegWrite(0,FPGA_UMTS_IQ_END_EVEN,ulNestElecAddr+ulElecPortBand-1);

        ulNestElecAddr = ulNestElecAddr + ulElecPortBand;
    }

    dbgInfoEx("%s %d ulNestElecAddr = %d \n", __FUNCTION__, __LINE__, ulNestElecAddr);
    *pulIqItemNum = ulIqCnt;
    return ulNestElecAddr;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg_G
 * 功能描述: 电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfg_G(T_PRruIqCfgItem *ptIqCfgItem, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulIqLp = 0;
    ULONG ulIqCnt = 0;
    ULONG ulNestElecAddr = 0;
    T_PRruIqCfgItem *ptIqItem = NULL;

    ptIqItem = ptIqCfgItem;

    ulNestElecAddr = ulStartElecAddr;

    for (ulIqLp = 0; ulIqLp < ulLeaveIqNum; ulIqLp++)
    {
        if (PRODUCT_IQ_MODE_GSM != ptIqItem->ucRadioMode) /*制式处理完退出*/
        {
            break;
        }

        ptIqItem++;
        ulIqCnt++;
    }

    if (ulIqCnt) /*IQ条数不为0时，才配置电口*/
    {
        //FpgaRegWrite(0,FPGA_GSM_IQ_START_ODD,ulNestElecAddr);
        //FpgaRegWrite(0,FPGA_GSM_IQ_END_ODD,ulNestElecAddr+ELEC_PORT_DEF_BYTE_GSM-1);
        //FpgaRegWrite(0,FPGA_GSM_IQ_START_EVEN,ulNestElecAddr);
        //FpgaRegWrite(0,FPGA_GSM_IQ_END_EVEN,ulNestElecAddr+ELEC_PORT_DEF_BYTE_GSM-1);

        ulNestElecAddr = ulNestElecAddr + ELEC_PORT_DEF_BYTE_GSM;
    }

    dbgInfoEx("%s %d ulNestElecAddr = %d \n", __FUNCTION__, __LINE__, ulNestElecAddr);
    *pulIqItemNum = ulIqCnt;
    return ulNestElecAddr;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg_C
 * 功能描述: 电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfg_C(T_PRruIqCfgItem *ptIqCfgItem, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulIqLp = 0;
    ULONG ulIqCnt = 0;
    ULONG ulNestElecAddr = 0;
    T_PRruIqCfgItem *ptIqItem = NULL;

    ptIqItem = ptIqCfgItem;

    ulNestElecAddr = ulStartElecAddr;

    for (ulIqLp = 0; ulIqLp < ulLeaveIqNum; ulIqLp++)
    {
        if (PRODUCT_IQ_MODE_CDMA != ptIqItem->ucRadioMode) /*制式处理完退出*/
        {
            break;
        }

        ptIqItem++;
        ulIqCnt++;
    }

    if (ulIqCnt) /*IQ条数不为0时，才配置电口*/
    {
        //FpgaRegWrite(0,FPGA_CDMA_IQ_START_ODD,ulNestElecAddr);
        //FpgaRegWrite(0,FPGA_CDMA_IQ_END_ODD,ulNestElecAddr+ELEC_PORT_DEF_BYTE_CMDA-1);
        //FpgaRegWrite(0,FPGA_CDMA_IQ_START_EVEN,ulNestElecAddr);
        //FpgaRegWrite(0,FPGA_CDMA_IQ_END_EVEN,ulNestElecAddr+ELEC_PORT_DEF_BYTE_CMDA-1);

        ulNestElecAddr = ulNestElecAddr + ELEC_PORT_DEF_BYTE_CMDA;
    }

    dbgInfoEx("%s %d ulNestElecAddr = %d \n", __FUNCTION__, __LINE__, ulNestElecAddr);
    *pulIqItemNum = ulIqCnt;
    return ulNestElecAddr;
}

/**************************************************************************
 * 函数名称: BspGetElecPortDefByte_LTE
 * 功能描述: LTE电口摆放长度
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年03月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspGetElecPortDefByte_LTE(UCHAR ucBandWidth)
{
    ULONG ulElecPortByte = BSP_ERROR;

    switch (ucBandWidth)
    {
    case LTE_BAND_5M:
    case LTE_BAND_10M:
    {
        ulElecPortByte = ELEC_PORT_DEF_BYTE_LTE_10M;
        break;
    }
    case LTE_BAND_15M:
    case LTE_BAND_20M:
    {
        ulElecPortByte = ELEC_PORT_DEF_BYTE_LTE_20M;
        break;
    }
    default:
    {
        dbgInfo("%s Cannot Find Lte BandWith = %d! \n", __FUNCTION__, ucBandWidth);
    }
    }
    dbgInfo("%s,line:%d,ucBandWidth = %d\n", __FUNCTION__, __LINE__, ucBandWidth);
    return ulElecPortByte;
}

/**************************************************************************
 * 函数名称: BspGetElecPortDefByte_LTE
 * 功能描述: LTE电口摆放长度
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年03月15日                          刘志敬    创建
 **************************************************************************/
USHORT BspGetElecPortBandWidthCfg_LTE(UCHAR ucBandWidth)
{
    USHORT usBandWidthCfg = 0xffff;

    switch (ucBandWidth)
    {
    case LTE_BAND_5M:
    case LTE_BAND_10M:
    {
        usBandWidthCfg = 0x5;
        break;
    }
    case LTE_BAND_15M:
    {
        usBandWidthCfg = 0x6;
        break;
    }
    case LTE_BAND_20M:
    {
        usBandWidthCfg = 0x7;
        break;
    }
    default:
    {
        dbgInfo("%s Cannot Find Lte BandWith = %d! \n", __FUNCTION__, ucBandWidth);
    }
    }

    dbgInfo("%s,line:%d,ulBandWidthCfg = %d\n", __FUNCTION__, __LINE__, usBandWidthCfg);
    return usBandWidthCfg;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg_FDL
 * 功能描述: 电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfg_L(T_PRruIqCfgItem *ptIqCfgItem, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulIqLp = 0;
    ULONG ulIqCnt = 0;
    ULONG ulAddrOffset = 0;
    ULONG ulNestElecAddr = 0;
    ULONG ulTxChan = 0;
    ULONG ulElecPortByte = 0;
    USHORT usWidthCfg = 0;
    T_PRruIqCfgItem *ptIqItem = NULL;

    ptIqItem = ptIqCfgItem;

    ulNestElecAddr = ulStartElecAddr;

    for (ulIqLp = 0; ulIqLp < ulLeaveIqNum; ulIqLp++)
    {
        if ((PRODUCT_IQ_MODE_LTE_FDD != ptIqItem->ucRadioMode) &&
            (PRODUCT_IQ_MODE_LTE_TDD != ptIqItem->ucRadioMode))
        {
            break;
        }
        if (TX != ptIqItem->ucTxOrRx) /*按照发射配置电口，收发仅配置一组*/
        {
            ptIqItem++;
            ulIqCnt++;
            continue;
        }
        if (ptIqItem->ucePortNum % 2) /*不处理奇数电口组号*/
        {
            ptIqItem++;
            ulIqCnt++;
            continue;
        }
        ulElecPortByte = BspGetElecPortDefByte_LTE(ptIqItem->ucBandWidth);
        if (BSP_ERROR == ulElecPortByte)
        {
            ptIqItem++;
            ulIqCnt++;
            continue;
        }

        ulAddrOffset = ptIqItem->ucePortNum / 2;
        usWidthCfg = BspGetElecPortBandWidthCfg_LTE(ptIqItem->ucBandWidth);
        if (0xffff == usWidthCfg)
        {
            dbgInfo("%s,%d\n", __FUNCTION__, __LINE__);
            ptIqItem++;
            ulIqCnt++;
            continue;
        }

        //FpgaRegWrite(0,FPGA_LTE_IQ_BAND_A+ulAddrOffset,usWidthCfg); /*目前默认为20M 2天线*/

        //FpgaRegWrite(0,FPGA_LTE_IQ_BAND_A_START_ODD+2*ulAddrOffset,ulNestElecAddr);
        //FpgaRegWrite(0,FPGA_LTE_IQ_BAND_A_END_ODD+2*ulAddrOffset,ulNestElecAddr+ulElecPortByte-1);

        ulNestElecAddr = ulNestElecAddr + ulElecPortByte;
        ptIqItem++;
        ulIqCnt++;

        ulTxChan = BspGetChanNum_L(ptIqItem->usRruAntNo);
    }

    dbgInfoEx("%s %d ulNestElecAddr = %d \n", __FUNCTION__, __LINE__, ulNestElecAddr);
    *pulIqItemNum = ulIqCnt;
    return ulNestElecAddr;
}

/**************************************************************************
 * 函数名称: BspGetElecPortDefByte_NB
 * 功能描述: NB电口摆放长度
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2018年02月27日                          刘志敬    创建
 **************************************************************************/
ULONG BspGetElecPortDefByte_NB(VOID)
{
    ULONG ulElecPortByte = 0;

    ulElecPortByte = ELEC_PORT_DEF_BYTE_NB;
    return ulElecPortByte;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg_NB
 * 功能描述: 电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2018年02月27日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfg_NB(T_PRruIqCfgItem *ptIqCfgItem, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulIqLp = 0;
    ULONG ulIqCnt = 0;
    ULONG ulNestElecAddr = 0;
    ULONG ulElecPortByte = 0;
    ULONG ulNbCellNum = 0;
    ULONG ulAxcSumNum = 0;
    ULONG ulElecByte = 0;
    T_PRruIqCfgItem *ptIqItem = NULL;

    ptIqItem = ptIqCfgItem;

    ulNestElecAddr = ulStartElecAddr;

    for (ulIqLp = 0; ulIqLp < ulLeaveIqNum; ulIqLp++)
    {
        if (PRODUCT_IQ_MODE_NB_IOT != ptIqItem->ucRadioMode)
        {
            break;
        }
        if (TX != ptIqItem->ucTxOrRx) /*按照发射配置电口，收发仅配置一组*/
        {
            ptIqItem++;
            ulIqCnt++;

            dbgInfo("%s %d ulNbCellNum = %d! \n", __FUNCTION__, __LINE__, ulNbCellNum);
            continue;
        }
        if (ptIqItem->ucePortNum % 2) /*不处理奇数电口组号*/
        {
            ptIqItem++;
            ulIqCnt++;

            dbgInfo("%s %d ulNbCellNum = %d! \n", __FUNCTION__, __LINE__, ulNbCellNum);
            continue;
        }
        ulElecPortByte = BspGetElecPortDefByte_NB();

        dbgInfo("%s %d ulNbCellNum = %d! %d %d  \n",
                __FUNCTION__, __LINE__, ulNbCellNum, ptIqItem->ucTxOrRx, ptIqItem->ucePortNum);
        ulNbCellNum++;
        ptIqItem++;
        ulIqCnt++;
    }

    if (0 != ulNbCellNum)
    {
        dbgInfo("%s %d ulNbCellNum = %d! \n", __FUNCTION__, __LINE__, ulNbCellNum);
        ulAxcSumNum = ulNbCellNum * 2;
        //FpgaRegWrite(0, FPGA_DIFF_COMP_AXC_SUM, ulAxcSumNum);   /* 配置异厂家AXC总数 */

        ulElecByte = ulNbCellNum * ulElecPortByte;

        //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_START_ODD, ulStartElecAddr);
        //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_END_ODD, ulStartElecAddr + ulElecByte - 1);
        //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_START_EVEN, ulStartElecAddr);
        //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_END_EVEN, ulStartElecAddr + ulElecByte - 1);

        dbgInfo("%s %d ulStartElecAddr = %d! \n", __FUNCTION__, __LINE__, ulStartElecAddr);
    }
    ulNestElecAddr = ulStartElecAddr + ulElecByte;

    dbgInfoEx("%s %d ulNestElecAddr = %d \n", __FUNCTION__, __LINE__, ulNestElecAddr);
    dbgInfoEx("%s %d ulIqCnt = %d \n", __FUNCTION__, __LINE__, ulIqCnt);

    *pulIqItemNum = ulIqCnt;
    return ulNestElecAddr;
}

/**************************************************************************
 * 函数名称: BspGetElecPortCfgIndex_NR
 * 功能描述: 返回NR电口摆放表需要
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2018年09月24日                          刘志敬    创建
 **************************************************************************/
ULONG BspGetElecPortCfgIndex_NR(T_PRruIqCfgItem *ptIqCfgItem)
{
    ULONG ulLp = 0;

    for (ulLp = 0; ulLp < gulMaxCfgCnt; ulLp++)
    {
        if (atAxcCfg_NR_Qcell[ulLp].ucBandWidth != ptIqCfgItem->ucBandWidth)
        {
            dbgInfoEx("%s line:%d ucBandWidth = %d\n", __FUNCTION__, __LINE__, ptIqCfgItem->ucBandWidth);
            continue;
        }
        if (atAxcCfg_NR_Qcell[ulLp].ucSampleRate != ptIqCfgItem->ucSampleRate)
        {
            dbgInfoEx("%s line:%d ucBandWidth = %d\n", __FUNCTION__, __LINE__, ptIqCfgItem->ucBandWidth);
            continue;
        }
        return ulLp;
    }

    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg_NR
 * 功能描述: 电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfg_NR(T_PRruIqCfgItem *ptIqCfgItem, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulIqLp = 0;
    ULONG ulIqCnt = 0;
    ULONG ulBandOffset = 0;
    ULONG ulNextElecAddr = 0;
    ULONG ulTxChan = 0;
    ULONG ulCfgIndex = 0;
    ULONG ulElecPortByte = 0;
    USHORT usWidthCfg = 0;
    ULONG ulSampleLp = 0;

    ULONG ulIqByteNum = 0;
    UCHAR ucLand0CfgFlag = 0;
    UCHAR ucLand1CfgFlag = 0;
    T_PRruIqCfgItem *ptIqItem = NULL;

    ucLand0CfgFlag = 0;
    ucLand1CfgFlag = 0;

    ptIqItem = ptIqCfgItem;

    ulNextElecAddr = ulStartElecAddr;

    for (ulIqLp = 0; ulIqLp < ulLeaveIqNum; ulIqLp++)
    {
        if (PRODUCT_IQ_MODE_NR != ptIqItem->ucRadioMode)
        {
            dbgInfoEx("%s %d \n", __FUNCTION__, __LINE__);
            break;
        }
        if (TX != ptIqItem->ucTxOrRx) /*按照发射配置电口，收发仅配置一组*/
        {
            ptIqItem++;
            ulIqCnt++;

            dbgInfoEx("%s %d \n", __FUNCTION__, __LINE__);
            continue;
        }

        ulCfgIndex = BspGetElecPortCfgIndex_NR(ptIqItem);
        if (BSP_ERROR == ulCfgIndex)
        {
            ptIqItem++;
            ulIqCnt++;
            continue;
        }

        ulBandOffset = ptIqItem->ucePortNum;
        for (ulSampleLp = 0; ulSampleLp < atAxcCfg_NR_Qcell[ulCfgIndex].uc30P32MCnt; ulSampleLp++)
        {
            ulElecPortByte = ELEC_PORT_DEF_BYTE_NR_30P72M;
            usWidthCfg = 7;

            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A+ulBandOffset,usWidthCfg); /*目前默认为20M 2天线*/

            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A_START_ODD + 2*ulBandOffset,(USHORT)ulNextElecAddr);
            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A_END_ODD + 2*ulBandOffset,(USHORT)(ulNextElecAddr+ulElecPortByte-1));

            if (24 > ulBandOffset)
            {
                if (ucLand0CfgFlag == 0)
                {
                    ucLand0CfgFlag = 1;
                    //FpgaRegWrite(0,ELEC_PORT_BAND0_NR_START,(USHORT)ulNextElecAddr);
                }
                //FpgaRegWrite(0,ELEC_PORT_BAND0_NR_END,(USHORT)(ulNextElecAddr+ulElecPortByte-1));
            }
            if (24 <= ulBandOffset)
            {
                if (ucLand1CfgFlag == 0)
                {
                    ucLand1CfgFlag = 1;
                    //FpgaRegWrite(0,ELEC_PORT_BAND1_NR_START,(USHORT)ulNextElecAddr);
                }
                //FpgaRegWrite(0,ELEC_PORT_BAND1_NR_END,(USHORT)(ulNextElecAddr+ulElecPortByte-1));
            }

            ulNextElecAddr = ulNextElecAddr + ulElecPortByte;
            ulIqByteNum += ELEC_PORT_DEF_BYTE_NR_30P72M;

            ulTxChan = BspGetChanNum_L(ptIqItem->usRruAntNo);

            ulBandOffset++;
        }

        for (ulSampleLp = 0; ulSampleLp < atAxcCfg_NR_Qcell[ulCfgIndex].uc23P04MCnt; ulSampleLp++)
        {
            ulElecPortByte = ELEC_PORT_DEF_BYTE_NR_23P04M;
            usWidthCfg = 6;

            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A+ulBandOffset,usWidthCfg);
            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A_START_ODD + 2*ulBandOffset,(USHORT)ulNextElecAddr);
            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A_END_ODD + 2*ulBandOffset,(USHORT)(ulNextElecAddr+ulElecPortByte-1));

            if (24 > ulBandOffset)
            {
                if (ucLand0CfgFlag == 0)
                {
                    ucLand0CfgFlag = 1;
                    //FpgaRegWrite(0,ELEC_PORT_BAND0_NR_START,(USHORT)ulNextElecAddr);
                }
                //FpgaRegWrite(0,ELEC_PORT_BAND0_NR_END,(USHORT)(ulNextElecAddr+ulElecPortByte-1));
            }
            if (24 <= ulBandOffset)
            {
                if (ucLand1CfgFlag == 0)
                {
                    ucLand1CfgFlag = 1;
                    //FpgaRegWrite(0,ELEC_PORT_BAND1_NR_START,(USHORT)ulNextElecAddr);
                }
                //FpgaRegWrite(0,ELEC_PORT_BAND1_NR_END,(USHORT)(ulNextElecAddr+ulElecPortByte-1));
            }

            ulNextElecAddr = ulNextElecAddr + ulElecPortByte;
            ulIqByteNum += ELEC_PORT_DEF_BYTE_NR_23P04M;

            ulTxChan = BspGetChanNum_L(ptIqItem->usRruAntNo);

            ulBandOffset++;
        }

        for (ulSampleLp = 0; ulSampleLp < atAxcCfg_NR_Qcell[ulCfgIndex].uc15P36MCnt; ulSampleLp++)
        {
            ulElecPortByte = ELEC_PORT_DEF_BYTE_NR_15P36M;
            usWidthCfg = 4;

            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A+ulBandOffset,usWidthCfg);
            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A_START_ODD + 2*ulBandOffset,(USHORT)ulNextElecAddr);
            //FpgaRegWrite(0,FPGA_NR_IQ_BAND_A_END_ODD + 2*ulBandOffset,(USHORT)(ulNextElecAddr+ulElecPortByte-1));

            if (24 > ulBandOffset)
            {
                if (ucLand0CfgFlag == 0)
                {
                    ucLand0CfgFlag = 1;
                    //FpgaRegWrite(0,ELEC_PORT_BAND0_NR_START,(USHORT)ulNextElecAddr);
                }
                //FpgaRegWrite(0,ELEC_PORT_BAND0_NR_END,(USHORT)(ulNextElecAddr+ulElecPortByte-1));
            }
            if (24 <= ulBandOffset)
            {
                if (ucLand1CfgFlag == 0)
                {
                    ucLand1CfgFlag = 1;
                    //FpgaRegWrite(0,ELEC_PORT_BAND1_NR_START,(USHORT)ulNextElecAddr);
                }
                //FpgaRegWrite(0,ELEC_PORT_BAND1_NR_END,(USHORT)(ulNextElecAddr+ulElecPortByte-1));
            }

            ulNextElecAddr = ulNextElecAddr + ulElecPortByte;
            ulIqByteNum += ELEC_PORT_DEF_BYTE_NR_15P36M;

            ulTxChan = BspGetChanNum_L(ptIqItem->usRruAntNo);

            ulBandOffset++;
        }

        ptIqItem++;
        ulIqCnt++;
    }

    if (BspGetOptSpeed_Qcell() == ELEC_PORT_OPT_SPEED_25G)
    {
        //FpgaRegWrite(0,ELEC_PORT_FACTOR_NR_START,OPT_25G_ZIP_FACTOR_NR_START);
        //FpgaRegWrite(0,ELEC_PORT_FACTOR_NR_END,OPT_25G_ZIP_FACTOR_NR_END);
    }
    else if (BspGetOptSpeed_Qcell() == ELEC_PORT_OPT_SPEED_10G)
    {
        //FpgaRegWrite(0,ELEC_PORT_FACTOR_NR_START,OPT_10G_ZIP_FACTOR_NR_START);
        //FpgaRegWrite(0,ELEC_PORT_FACTOR_NR_END,OPT_10G_ZIP_FACTOR_NR_END);
    }
    else
    {
        dbgInfo("%s,%d:Opt Speed Not Found, Zip Factor Cfg Failed.\n", __FUNCTION__, __LINE__);
    }

    dbgInfoEx("%s %d ulNextElecAddr = %d \n", __FUNCTION__, __LINE__, ulNextElecAddr);
    *pulIqItemNum = ulIqCnt;

    return ulNextElecAddr;
}

/**************************************************************************
 * 函数名称: BspGetElecPortDefByteDm
 * 功能描述: 异厂家电口摆放长度
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年08月15日                    plz    创建
 **************************************************************************/
ULONG BspGetElecPortDefByte_Dm(UCHAR ucBandWidth)
{
    ULONG ulElecPortByte = BSP_ERROR;

    switch (ucBandWidth)
    {
    case IQ_WIDTH_5M:
    {
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_5M;
        break;
    }
    case IQ_WIDTH_10M:
    {
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_10M;
        break;
    }
    case IQ_WIDTH_15M:
    {
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_15M;
        break;
    }
    case IQ_WIDTH_20M:
    {
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_20M;
        break;
    }
    case IQ_WIDTH_25M:
    {
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_25M;
        break;
    }
    default:
    {
        dbgInfo("%s:Cannot Find Dm BandWith = %d! \n", __FUNCTION__, ucBandWidth);
    }
    }
    return ulElecPortByte;
}

/**************************************************************************
 * 函数名称: BspGetElecPortDefByte_Gm
 * 功能描述: 异厂家电口摆放长度
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年08月15日                    plz    创建
 **************************************************************************/
ULONG BspGetElecPortDefByte_Gm(VOID)
{
    ULONG ulElecPortByte = 0;

    T_DMFreqCfgPara *pGmFreqPara = NULL;
    // pGmFreqPara = BspGetFreqPara_GM();
    /* 根据PRM下发的载波带宽信息判断10M还是20M */

    switch (pGmFreqPara->ulBandWidth[0])
    {
    case 5000:
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_5M;
        break;
    case 10000:
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_10M;
        break;
    case 15000:
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_15M;
        break;
    case 20000:
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_20M;
        break;
    case 25000:
        ulElecPortByte = ELEC_PORT_DEF_BYTE_DM_25M;
        break;
    default:
        break;
    }

    return ulElecPortByte;
}

/*****************************************************************************
*  函数名称   : BspGetAxcSumNum_DM
*  功能描述   : 获取异厂家载波AXC总数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*  输出参数   : 无
*  返 回 值   : 
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  plz@2016-6-9 14:58:07  创建
*----------------------------------------------------------------------------
*/
ULONG BspGetAxcSumNum_DM(T_PRruIqCfgItem *ptIqCfgItem)
{
    ULONG ulTxChan = 0;
    ULONG ulAxcSumNum = 0;
    if (ulTxChan >= BspGetTxChannel())
    {
        dbgInfo("%s ulTxChan %d error! \n", __FUNCTION__, ulTxChan);
        return BSP_ERROR;
    }
    for (ulTxChan = 0; ulTxChan < BspGetTxChannel(); ulTxChan += 2)
    {
        switch (BspGetChanRadioStandard(ulTxChan))
        {
        case BSP_RADIO_STANDARD_GM:
        case BSP_RADIO_STANDARD_GM | BSP_RADIO_STANDARD_LTE_FDD:
        case BSP_RADIO_STANDARD_GM | BSP_RADIO_STANDARD_LTE_FDD | BSP_RADIO_STANDARD_NB_IOT:
        {
            ulAxcSumNum += BspGetAxcNum_GM(ulTxChan);
            break;
        }
        default:
            break;
        }
    }
    return ulAxcSumNum;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg_GM
 * 功能描述: 异厂家GSM合载波走FDD配置时电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年08月15日                     plz    创建
 **************************************************************************/
ULONG BspSetElecPortCfg_GM(T_PRruIqCfgItem *ptIqCfgItem, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulNestElecAddr = 0;
    ULONG ulAxcSumNum = 0;
    ULONG ulElecByte = 0;
    USHORT usFpgaDate = 0;

    ulAxcSumNum = BspGetAxcSumNum_DM(ptIqCfgItem);

    //FpgaRegRead(0, FPGA_DIFF_COMP_AXC_SUM, &usFpgaDate);   /* 配置异厂家AXC总数 */
    //FpgaRegWrite(0, FPGA_DIFF_COMP_AXC_SUM, usFpgaDate+ulAxcSumNum);   /* 配置异厂家AXC总数 */

    ulElecByte = BspGetElecPortDefByte_Gm(); /* 异厂家电口BYTE数 */

    if (0 == usFpgaDate)
    {
        //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_START_ODD,ulStartElecAddr);
        //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_START_EVEN,ulStartElecAddr);
    }
    //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_END_ODD, ulStartElecAddr + ulElecByte - 1);
    //FpgaRegWrite(0,FPGA_DIFF_COMP_IQ_END_EVEN, ulStartElecAddr + ulElecByte - 1);

    ulNestElecAddr = ulStartElecAddr + ulElecByte;

    dbgInfo("%s %d ulStartElecAddr = %d! \n", __FUNCTION__, __LINE__, ulStartElecAddr);

    *pulIqItemNum = 2;
    return ulNestElecAddr;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfgByRadio
 * 功能描述: 根据制式进行电口IQ配置摆放，同时返回此制式的IQ条数
 * 输入参数: ulIqRadio           产品IQ制式
 *                       : ptIqCfg             IQ配置
 * 输出参数: pulIqItemNum   此制式的IQ条数
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfgByRadio(ULONG ulIqRadio, T_PRruIqCfgItem *ptIqCfg, ULONG ulLeaveIqNum, ULONG *pulIqItemNum, ULONG ulStartElecAddr)
{
    ULONG ulNestElecAddr = 0;

    /*将下一个电口位置默认为开始地址，避免未赋值出现异常*/
    ulNestElecAddr = ulStartElecAddr;

    dbgInfoEx("%s %d ulIqRadio = %d \n", __FUNCTION__, __LINE__, ulIqRadio);
    switch (ulIqRadio)
    {
    case PRODUCT_IQ_MODE_UMTS:
    {
        ulNestElecAddr = BspSetElecPortCfg_U(ptIqCfg, ulLeaveIqNum, pulIqItemNum, ulStartElecAddr);
        break;
    }
    case PRODUCT_IQ_MODE_GSM:
    {
        ulNestElecAddr = BspSetElecPortCfg_G(ptIqCfg, ulLeaveIqNum, pulIqItemNum, ulStartElecAddr);
        break;
    }
    case PRODUCT_IQ_MODE_CDMA:
    {
        ulNestElecAddr = BspSetElecPortCfg_C(ptIqCfg, ulLeaveIqNum, pulIqItemNum, ulStartElecAddr);
        break;
    }
    case PRODUCT_IQ_MODE_LTE_FDD:
    case PRODUCT_IQ_MODE_LTE_TDD:
    {
        ulNestElecAddr = BspSetElecPortCfg_L(ptIqCfg, ulLeaveIqNum, pulIqItemNum, ulStartElecAddr);
        break;
    }
    case PRODUCT_IQ_MODE_NB_IOT:
    {
        ulNestElecAddr = BspSetElecPortCfg_NB(ptIqCfg, ulLeaveIqNum, pulIqItemNum, ulStartElecAddr);
        break;
    }
    case PRODUCT_IQ_MODE_NR:
    {
        ulNestElecAddr = BspSetElecPortCfg_NR(ptIqCfg, ulLeaveIqNum, pulIqItemNum, ulStartElecAddr);
        break;
    }
    case PRODUCT_IQ_MODE_GSM_MERGECARRIER:
    {
        ulNestElecAddr = BspSetElecPortCfg_GM(ptIqCfg, ulLeaveIqNum, pulIqItemNum, ulStartElecAddr);
        break;
    }
    default:
    {
        break;
    }
    }
    return ulNestElecAddr;
}

/**************************************************************************
 * 函数名称: BspCheckRepeatIq
 * 功能描述: 查询IQ当前列表是否存在重复IQ
 * 输入参数: 
 * 输出参数: BSP_ERROR ptIqCfg与当前IQ列表中记录存在重复，不需要保存
 *         : BSP_OK    新IQ配置，需要保存
 *         :
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年06月05日                  刘志敬    创建
 **************************************************************************/
ULONG BspCheckRepeatIq(T_PRruIqCfgItem *ptIqItemList, T_PRruIqCfgItem *ptIqCfg, ULONG ulNum)
{
    ULONG ulLp = 0;

    for (ulLp = 0; ulLp < ulNum; ulLp++)
    {
        if (0 == memcmp((UCHAR *)&ptIqItemList[ulLp], (UCHAR *)ptIqCfg, sizeof(T_PRruIqCfgItem)))
        {
            return BSP_ERROR;
        }
    }
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspUpDateNowIqItem
 * 功能描述: 更新当前IQ条目，双CC配置
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月25日                          刘志敬    创建
 **************************************************************************/
ULONG BspUpDateNowIqItem(VOID)
{
    ULONG ulLp = 0;
    ULONG ulIqItemNum = 0;
    ULONG ulCCIndex = 0;
    ULONG ulIqRadio = PRODUCT_IQ_MODE_UMTS;
    ULONG ulEPortNum = 0;
    T_PRruIqCfgItem *ptIqItem = NULL;

    ptIqItem = atIqItem_Now;

    memset(atIqItem_Now, 0, sizeof(atIqItem_Now));

    for (ulIqRadio = PRODUCT_IQ_MODE_UMTS; ulIqRadio < PRODUCT_IQ_MODE_MAX; ulIqRadio++)
    {
        for (ulEPortNum = 0; ulEPortNum < MAX_EPORT_NUM; ulEPortNum++)
        {
            for (ulCCIndex = 0; ulCCIndex < MAX_CC_NUM; ulCCIndex++)
            {
                for (ulLp = 0; ulLp < gIqCfgInfo_Now[ulCCIndex].ulNum; ulLp++)
                {
                    if ((PRODUCT_IQ_MODE_LTE_FDD != gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucRadioMode) &&
                        (PRODUCT_IQ_MODE_LTE_TDD != gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucRadioMode) &&
                        (PRODUCT_IQ_MODE_NR != gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucRadioMode))
                    {
                        if (0 != ulEPortNum)
                        {
                            continue;
                        }
                        if (ulIqRadio == gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucRadioMode)
                        {
                            if (BSP_OK == BspCheckRepeatIq(atIqItem_Now, &gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp], ulIqItemNum))
                            {
                                dbgInfoEx("%s %d ulIqRadio = %d ulCCIndex = %d ulLp = %d \n",
                                          __FUNCTION__, __LINE__, ulIqRadio, ulCCIndex, ulLp);
                                memcpy_s(ptIqItem, sizeof(T_PRruIqCfgItem), &gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp], sizeof(T_PRruIqCfgItem));
                                ptIqItem++;
                                ulIqItemNum++;
                            }
                        }
                    }
                    else if ((PRODUCT_IQ_MODE_LTE_FDD == gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucRadioMode) ||
                             (PRODUCT_IQ_MODE_LTE_TDD == gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucRadioMode))
                    {
                        if (PRODUCT_IQ_MODE_LTE_FDD != ulIqRadio)
                        {
                            continue;
                        }
                        if (ulEPortNum == gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucePortNum)
                        {
                            if (BSP_OK == BspCheckRepeatIq(atIqItem_Now, &gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp], ulIqItemNum))
                            {
                                dbgInfoEx("%s %d ulIqRadio = %d ulCCIndex = %d ulLp = %d \n",
                                          __FUNCTION__, __LINE__, ulIqRadio, ulCCIndex, ulLp);
                                memcpy_s(ptIqItem, sizeof(T_PRruIqCfgItem), &gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp], sizeof(T_PRruIqCfgItem));
                                ptIqItem++;
                                ulIqItemNum++;
                            }
                        }
                    }

                    else
                    {
                        if (PRODUCT_IQ_MODE_NR != ulIqRadio)
                        {
                            continue;
                        }
                        if (ulEPortNum == gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp].ucePortNum)
                        {
                            if (BSP_OK == BspCheckRepeatIq(atIqItem_Now, &gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp], ulIqItemNum))
                            {
                                dbgInfoEx("%s %d ulIqRadio = %d ulCCIndex = %d ulLp = %d \n",
                                          __FUNCTION__, __LINE__, ulIqRadio, ulCCIndex, ulLp);
                                memcpy_s(ptIqItem, sizeof(T_PRruIqCfgItem), &gIqCfgInfo_Now[ulCCIndex].atIqItem[ulLp], sizeof(T_PRruIqCfgItem));
                                ptIqItem++;
                                ulIqItemNum++;
                            }
                        }
                    }
                }
            }
        }
    }
    dbgInfoEx("%s %d ulIqItemNum = %d \n", __FUNCTION__, __LINE__, ulIqItemNum);
    return ulIqItemNum;
}

/**************************************************************************
 * 函数名称: BspSetElecPortCfg
 * 功能描述: 电口IQ配置摆放
 * 输入参数: 
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年06月15日                          刘志敬    创建
 **************************************************************************/
ULONG BspSetElecPortCfg(VOID)
{
    ULONG ulLeaveIqNum = 0; /*未处理的IQ条数*/
    ULONG ulIqRadio = 0;
    ULONG ulStartElecAddr = 0;
    ULONG ulNestElecAddr = 0;
    ULONG ulIqItemNum = 0;
    ULONG ulChangeType = 0;
    T_PRruIqCfgItem *patIqItem = NULL;

    /*更新所有CC配置列表并排序*/
    ulLeaveIqNum = BspUpDateNowIqItem();

    patIqItem = &atIqItem_Now[0];

    ulChangeType = BspCheckIqCfgType(&atIqItem_Now[0], &atIqItem_Old[0], BSP_MAX_IQ_ITEM_NUM);

    if (IQ_CFG_NO_CHANGE == ulChangeType)
    {
        dbgInfo("%s iq no change!\n", __FUNCTION__);
    }
    else
    {
        BspClearElecPortCfg();

        for (ulIqRadio = PRODUCT_IQ_MODE_UMTS; ulIqRadio < PRODUCT_IQ_MODE_MAX; ulIqRadio++)
        {
            dbgInfoEx("%s %d ulIqRadio = %d ucRadioMode = %d \n",
                      __FUNCTION__, __LINE__, ulIqRadio, patIqItem->ucRadioMode);

            if (ulIqRadio == patIqItem->ucRadioMode)
            {
                ulNestElecAddr = BspSetElecPortCfgByRadio(ulIqRadio, patIqItem, ulLeaveIqNum, &ulIqItemNum, ulStartElecAddr);
                dbgInfoEx("%s %d ulLeaveIqNum = %d ulIqItemNum = %d startaddr = %d nestaddr = %d \n",
                          __FUNCTION__, __LINE__, ulLeaveIqNum, ulIqItemNum, ulStartElecAddr, ulNestElecAddr);

                patIqItem += ulIqItemNum;
                ulStartElecAddr = ulNestElecAddr;
                if (ulLeaveIqNum > ulIqItemNum) /*未处理IQ条数大于当前处理的IQ条数*/
                {
                    ulLeaveIqNum -= ulIqItemNum;
                }
                else
                {
                    dbgInfoEx("%s %d ulLeaveIqNum = %d ulIqItemNum = %d startaddr = %d nestaddr = %d \n",
                              __FUNCTION__, __LINE__, ulLeaveIqNum, ulIqItemNum, ulStartElecAddr, ulNestElecAddr);

                    break;
                }
            }

            dbgInfoEx("%s %d startaddr = %d nestaddr = %d \n", __FUNCTION__, __LINE__, ulStartElecAddr, ulNestElecAddr);
        }
    }
    dbgInfoEx("%s %d ulLeaveIqNum = %d ulIqItemNum = %d startaddr = %d nestaddr = %d \n",
              __FUNCTION__, __LINE__, ulLeaveIqNum, ulIqItemNum, ulStartElecAddr, ulNestElecAddr);

    memcpy_s(atIqItem_Old, sizeof(atIqItem_Old), atIqItem_Now, sizeof(atIqItem_Old));
    return BSP_OK;
}

/*============================================================================
  函数名称 : iqinfo_BbuPbPRu()
  函数功能 : 打印  BBU -PB -PRU 相关机型的iq消息
  实现算法 : 无
  全局变量 :
  输入参数 : pbyData         消息体，wLen -- 消息长度
  返 回 值 : BSP_ERROR    失败
  BSP_OK     成功
  ------------------------------------------------------------------------------
  修改记录:
  日 期       版本号    修改人     修改内容
  2014-05-21  1.0       yc    修改
  ==============================================================================*/
VOID iqinfo_BbuPbPRu(VOID)
{
    ULONG ulLoop;
    ULONG ulCcIdxLoop;
    T_PRruIqCfgItem *ptItem;
    T_PRruIqCfg *ptIqCfg = NULL;
    dbgInfo("*********************************************************************************\n");
    dbgInfo("***********************IQ Config Receive from BBU********************************\n");
    dbgInfo("*********************************************************************************\n");
    dbgInfo("Radio -- 2:UMTS;3:GSM;4:TD;5:CDMA;6:FDD_LTE;7:TDD_LTE;17:UM;18:GM;19:CM\n");
    dbgInfo("Zip   -- 1:Compress;0:UnCompress;\n");
    dbgInfo("DL/UL -- 0:DL;1:UL;\n");
    dbgInfo("Source Radio Zip DL/UL BandWidth SampleRate AntNo CarrNo EPortNum FiberGroupId Rev1 Rev2 Rev3\n");
    for (ulCcIdxLoop = 0; ulCcIdxLoop < MAX_CC_NUM; ulCcIdxLoop++)
    {

        ptIqCfg = &gIqCfgInfo_CMP_Now[ulCcIdxLoop];
        if ((ptIqCfg->ulNum <= BSP_MAX_RRU_IQ_NUM) && (ptIqCfg->ulNum > 0))
        {
            for (ulLoop = 0; ulLoop < ptIqCfg->ulNum; ulLoop++)
            {
                ptItem = &ptIqCfg->atIqItem[ulLoop];
                dbgInfo("%-5s %-5d %-3d %-5d %-9d %-10d %-5d %-6d %-8d %-12d %-4d %-4d %-4d\n",
                        "CMP", ptItem->ucRadioMode, ptItem->ucZipFlag, ptItem->ucTxOrRx,
                        ptItem->ucBandWidth, ptItem->ucSampleRate, ptItem->usRruAntNo, ptItem->ucRruCarrierNo,
                        ptItem->ucePortNum, ptItem->FiberGroupId,
                        ptItem->ucVbpFiberNo, ptItem->ucRev2, ptItem->ucRev3);
            }
        }
        ptIqCfg = &gIqCfgInfo_TCM_Now[ulCcIdxLoop];
        if ((ptIqCfg->ulNum <= BSP_MAX_RRU_IQ_NUM) && (ptIqCfg->ulNum > 0))
        {
            for (ulLoop = 0; ulLoop < ptIqCfg->ulNum; ulLoop++)
            {
                ptItem = &ptIqCfg->atIqItem[ulLoop];
                dbgInfo("%-5s %-5d %-3d %-5d %-9d %-10d %-5d %-6d %-8d %-12d %-4d %-4d %-4d\n",
                        "TCM", ptItem->ucRadioMode, ptItem->ucZipFlag, ptItem->ucTxOrRx,
                        ptItem->ucBandWidth, ptItem->ucSampleRate, ptItem->usRruAntNo, ptItem->ucRruCarrierNo,
                        ptItem->ucePortNum, ptItem->FiberGroupId,
                        ptItem->ucVbpFiberNo, ptItem->ucRev2, ptItem->ucRev3);
            }
        }
        ptIqCfg = &gIqCfgInfo_Now[ulCcIdxLoop];
        if ((ptIqCfg->ulNum <= BSP_MAX_RRU_IQ_NUM) && (ptIqCfg->ulNum > 0))
        {
            for (ulLoop = 0; ulLoop < ptIqCfg->ulNum; ulLoop++)
            {
                ptItem = &ptIqCfg->atIqItem[ulLoop];
                dbgInfo("%-5s %-5d %-3d %-5d %-9d %-10d %-5d %-6d %-8d %-12d %-4d %-4d %-4d\n",
                        ulCcIdxLoop ? "cc1" : "cc0", ptItem->ucRadioMode, ptItem->ucZipFlag, ptItem->ucTxOrRx,
                        ptItem->ucBandWidth, ptItem->ucSampleRate, ptItem->usRruAntNo, ptItem->ucRruCarrierNo,
                        ptItem->ucePortNum, ptItem->FiberGroupId,
                        ptItem->ucVbpFiberNo, ptItem->ucRev2, ptItem->ucRev3);
            }
        }
    }

    dbgInfo("*********************************************************************************\n");
    dbgInfo("****************************Total IQ Config**********************************\n");
    dbgInfo("*********************************************************************************\n");
    dbgInfo("dbgInfo iq item!!!\n");

    dbgInfo("Radio Zip DL/UL BandWidth SampleRate AntNo CarrNo EPortNum FiberGroupId Rev1 Rev2 Rev3\n");
    for (ulLoop = 0; ulLoop < BSP_MAX_IQ_ITEM_NUM; ulLoop++)
    {
        ptItem = &atIqItem_Now[ulLoop];

        if (0 == ptItem->ucRadioMode)
        {
            break;
        }
        dbgInfo("%-5d %-3d %-5d %-9d %-10d %-5d %-6d %-8d %-12d %-4d %-4d %-4d\n",
                ptItem->ucRadioMode, ptItem->ucZipFlag, ptItem->ucTxOrRx,
                ptItem->ucBandWidth, ptItem->ucSampleRate, ptItem->usRruAntNo, ptItem->ucRruCarrierNo,
                ptItem->ucePortNum, ptItem->FiberGroupId,
                ptItem->ucVbpFiberNo, ptItem->ucRev2, ptItem->ucRev3);
    }
}

/*============================================================================
  函数名称 : iqinfo_BbuPRu()
  函数功能 : 打印BBU-PRU相关机型的信息
  实现算法 : 无
  全局变量 :
  输入参数 : pbyData         消息体，wLen -- 消息长度
  返 回 值 : BSP_ERROR    失败
  BSP_OK     成功
  ------------------------------------------------------------------------------
  修改记录:
  ==============================================================================*/
VOID iqinfo_BbuPRu(VOID)
{
}

/*============================================================================
  函数名称 : iqinfo()
  函数功能 : 打印iq消息
  实现算法 : 无
  全局变量 :
  输入参数 : pbyData         消息体，wLen -- 消息长度
  返 回 值 : BSP_ERROR    失败
  BSP_OK     成功
  ------------------------------------------------------------------------------
  修改记录:
  日 期       版本号    修改人     修改内容
  2014-05-21  1.0       yc    修改
  ==============================================================================*/
VOID iqinfo(VOID)
{
    if (BBU_PB_RRU == BspGetEthCfgMode())
    {
        iqinfo_BbuPbPRu();
    }
    if (BBU_CONNECTION_RRU == BspGetEthCfgMode())
    {
        iqinfo_BbuPRu();
    }
}

#ifdef BUILD_WITH_OM_FUNC

VOID testiq5G(VOID)
{
    T_PRruIqCfg tIqCfg1 =
        {8,
         {
             {15, 1, 0, SAMPLE_RATE_107P52M, 1, IQ_WIDTH_100M, 0, 0, 0, 0, 0, 0},
             {15, 1, 0, SAMPLE_RATE_107P52M, 2, IQ_WIDTH_100M, 0, 4, 0, 0, 0, 0},
             {15, 1, 1, SAMPLE_RATE_107P52M, 1, IQ_WIDTH_100M, 0, 8, 0, 0, 0, 0},
             {15, 1, 1, SAMPLE_RATE_107P52M, 2, IQ_WIDTH_100M, 0, 12, 0, 0, 0, 0},
             {15, 1, 0, SAMPLE_RATE_107P52M, 4, IQ_WIDTH_100M, 0, 12, 0, 0, 0, 0},
             {15, 1, 0, SAMPLE_RATE_107P52M, 8, IQ_WIDTH_100M, 0, 8, 0, 0, 0, 0},
             {15, 1, 1, SAMPLE_RATE_107P52M, 4, IQ_WIDTH_100M, 0, 4, 0, 0, 0, 0},
             {15, 1, 1, SAMPLE_RATE_107P52M, 8, IQ_WIDTH_100M, 0, 0, 0, 0, 0, 0},

         }};
    memcpy_s(&gIqCfgInfo_Now[0], sizeof(T_PRruIqCfg), &tIqCfg1, sizeof(T_PRruIqCfg));

    BspSetElecPortCfg();
}

VOID testiqcfg_97(VOID)
{
    T_PRruIqCfg tIqCfg1 =
        {18,
         {
             {7, 1, 0, 4, 1, 5, 22, 4, 0, 0, 0, 0},
             {7, 1, 0, 4, 2, 5, 22, 5, 0, 0, 0, 0},
             {7, 1, 1, 4, 1, 5, 22, 4, 0, 0, 0, 0},
             {7, 1, 1, 4, 2, 5, 22, 5, 0, 0, 0, 0},

             {7, 1, 0, 4, 4, 5, 22, 6, 0, 0, 0, 0},
             {7, 1, 0, 4, 8, 5, 22, 7, 0, 0, 0, 0},
             {7, 1, 1, 4, 4, 5, 22, 6, 0, 0, 0, 0},
             {7, 1, 1, 4, 8, 5, 22, 7, 0, 0, 0, 0},

             {6, 1, 0, 4, 16, 5, 0, 0, 0, 0, 0, 0},
             {6, 1, 0, 4, 32, 5, 0, 1, 0, 0, 0, 0},
             {6, 1, 1, 4, 16, 5, 0, 0, 0, 0, 0, 0},
             {6, 1, 1, 4, 32, 5, 0, 1, 0, 0, 0, 0},

             {6, 1, 0, 4, 64, 5, 0, 2, 0, 0, 0, 0},
             {6, 1, 0, 4, 128, 5, 0, 3, 0, 0, 0, 0},
             {6, 1, 1, 4, 64, 5, 0, 2, 0, 0, 0, 0},
             {6, 1, 1, 4, 128, 5, 0, 3, 0, 0, 0, 0},

             {19, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0},
             {19, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
         }};
    memcpy_s(&gIqCfgInfo_Now[0], sizeof(T_PRruIqCfg), &tIqCfg1, sizeof(T_PRruIqCfg));
}

VOID testiqcfg_97a(VOID)
{
    T_PRruIqCfg tIqCfg1 =
        {14,
         {
             {7, 1, 0, 4, 1, 5, 22, 4, 0, 0, 0, 0},
             {7, 1, 0, 4, 2, 5, 22, 5, 0, 0, 0, 0},
             {7, 1, 1, 4, 1, 5, 22, 4, 0, 0, 0, 0},
             {7, 1, 1, 4, 2, 5, 22, 5, 0, 0, 0, 0},

             {7, 1, 0, 4, 4, 5, 22, 6, 0, 0, 0, 0},
             {7, 1, 0, 4, 8, 5, 22, 7, 0, 0, 0, 0},
             {7, 1, 1, 4, 4, 5, 22, 6, 0, 0, 0, 0},
             {7, 1, 1, 4, 8, 5, 22, 7, 0, 0, 0, 0},

             {6, 1, 0, 4, 64, 5, 0, 2, 0, 0, 0, 0},
             {6, 1, 0, 4, 128, 5, 0, 3, 0, 0, 0, 0},
             {6, 1, 1, 4, 64, 5, 0, 2, 0, 0, 0, 0},
             {6, 1, 1, 4, 128, 5, 0, 3, 0, 0, 0, 0},

             {19, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0},
             {19, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
         }};
    memcpy_s(&gIqCfgInfo_Now[0], sizeof(T_PRruIqCfg), &tIqCfg1, sizeof(T_PRruIqCfg));

    BspSetElecPortCfg();
}

VOID testiqcfg_97b(VOID)
{
    T_PRruIqCfg tIqCfg1 =
        {10,
         {
             {7, 1, 0, 4, 4, 5, 22, 6, 0, 0, 0, 0},
             {7, 1, 0, 4, 8, 5, 22, 7, 0, 0, 0, 0},
             {7, 1, 1, 4, 4, 5, 22, 6, 0, 0, 0, 0},
             {7, 1, 1, 4, 8, 5, 22, 7, 0, 0, 0, 0},

             {6, 1, 0, 4, 64, 5, 0, 2, 0, 0, 0, 0},
             {6, 1, 0, 4, 128, 5, 0, 3, 0, 0, 0, 0},
             {6, 1, 1, 4, 64, 5, 0, 2, 0, 0, 0, 0},
             {6, 1, 1, 4, 128, 5, 0, 3, 0, 0, 0, 0},

             {19, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0},
             {19, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
         }};
    memcpy_s(&gIqCfgInfo_Now[0], sizeof(T_PRruIqCfg), &tIqCfg1, sizeof(T_PRruIqCfg));

    BspSetElecPortCfg();
}

VOID testiqcfg_80d(VOID)
{
    T_PRruIqCfg tIqCfg1 =
        {12,
         {
             {6, 1, 0, 4, 1, 5, 0, 0, 0, 0, 0, 0},
             {6, 1, 0, 4, 2, 5, 0, 1, 0, 0, 0, 0},
             {6, 1, 1, 4, 1, 5, 0, 0, 0, 0, 0, 0},
             {6, 1, 1, 4, 2, 5, 0, 1, 0, 0, 0, 0},

             {6, 1, 0, 4, 4, 5, 0, 4, 0, 0, 0, 0},
             {6, 1, 0, 4, 8, 5, 0, 5, 0, 0, 0, 0},
             {6, 1, 1, 4, 4, 5, 0, 4, 0, 0, 0, 0},
             {6, 1, 1, 4, 8, 5, 0, 5, 0, 0, 0, 0},

             {6, 1, 0, 4, 4, 5, 1, 6, 0, 0, 0, 0},
             {6, 1, 0, 4, 8, 5, 1, 7, 0, 0, 0, 0},
             {6, 1, 1, 4, 4, 5, 1, 6, 0, 0, 0, 0},
             {6, 1, 1, 4, 8, 5, 1, 7, 0, 0, 0, 0},
         }};
    memcpy_s(&gIqCfgInfo_Now[0], sizeof(T_PRruIqCfg), &tIqCfg1, sizeof(T_PRruIqCfg));

    BspSetElecPortCfg();
}

#endif

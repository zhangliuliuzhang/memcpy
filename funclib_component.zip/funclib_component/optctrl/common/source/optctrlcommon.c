/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : optctrlcommon.c
 * 文件标识 : {[N/A]}
 * 内容摘要 :
 * 注意事项 : 无
 * 作    者   : 10206930
 * 创建日期 : 2017-5-5 17:33:16
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 10206930
 * 修改日戳:  2017-5-5 17:33:16
 * 变更说明: 创建文件

 *----------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "bspcomm.h"
#include "rruinfo.h"
#include "optctrlapi.h"
#include "funccommon.h"
#include "optctrlcommon.h"
#include "funccommon_log.h"
#include "optctrlcommon.h"
#include "exprn.h"
#include "ichaladapt_ic4_2.h"
#include "bspcommon.h"
#ifndef MULT_PROGRESS_S
#include "sfp.h"
#endif

// #define BBU_FRAMER_INVALID    0xFF
#define BBU_FRAMER_SPEC          1

#define IP2INT32(ip)    (((UINT32)ip[0] << 24) | ((UINT32)ip[1] << 16) |   \
                         ((UINT32)ip[2] << 8)  | ((UINT32)ip[3] << 0))
#define MAC2INT64(mac)  (((UINT64)mac[0] << 40) | ((UINT64)mac[1] << 32) | \
                         ((UINT64)mac[2] << 24) | ((UINT64)mac[3] << 16) | \
                         ((UINT64)mac[4] << 8)  | ((UINT64)mac[5] << 0))
        
#define RRU_OPT_CHK(opt)         \
do                               \
{                                \
    if ((opt) >= BspGetOptNum()) \
    {                            \
        return BSP_ERROR;        \
    }                            \
}while (0)

UINT32 g_ulDynamicTcp = 0;
typedef struct tagT_OptNetInfo
{
    UINT32 isMain;
    UINT32 rruOpt;
    UINT32 bbuOpt;
    UINT32 bbuIp;
    UINT64 bbuMac;
    UINT32 bbuFramer;
    UINT8  carrNo[32]; /* 1-valid */
    struct tagT_OptNetInfo *next;
}T_OptNetInfo;

/* static T_BbPara BbParaTest = {1,1,1,1,7,1,1,1,1}; */

//extern UINT32 optBootpNum ;            //   xinzhcccccccccczzzzzzzzzzzzzzzzzzzzzzz
//extern UINT32 optEthInfoNum ;
//extern T_OPT_ETH_INFO *pOptEthInfo;

#define SCALE_CONFIG_PROCESS_PRIORITY    (51)  /* 注册优先级130对应linux优先级97-51/3 = 80*/
#define SCALE_CONFIG_ENABLE              1
#define SCALE_CONFIG_DISABLE             0
static UINT32 s_ulOptCtrlMainSlaveBrdFlag = 0;
static UINT32 s_ulLimitTransferSupportFlag = 0;
static UINT32 s_ulAxcLimitTransferMode = 255;
static UINT32 g_ulScaleCfg = SCALE_CONFIG_ENABLE;
static UINT32 g_TDDOptSupportRingWorkModeFlag = 0;    /* TDD支持环网标志， 0不支持环网，1支持环网*/
pLimitTransferModeAnalyze g_pLimitTransferAnalyzeFunc = NULL;

//#define MAX_OPT_NUM   9
static UINT32 s_optBootpFlag[MAX_OPT_NUM] = {0,0,0};
static UINT32 s_ulEthNameErrRetFlag[MAX_OPT_NUM] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
static UINT32 s_defaultPrbsType = OPT_PRBS31;
static UINT32 s_procotolChgFlag = 0;
static T_OPT_ETH_INFO s_opt_eth_info[MAX_OPT_NUM] = 
{
   /*rruOpt   eth*/
    {0,      "eth1"},
    {1,      "eth1"},
    {2,      "eth1"},
    {3,      "eth1"},
    {4,      "eth1"},
    {5,      "eth1"},
    {6,      "eth1"},
    {7,      "eth1"},
    {8,      "eth1"},
};

static UINT32 optBootpNum = 1;//缺省单光口bootp
static UINT32 optEthInfoNum = NELEMENTS(s_opt_eth_info);
static T_OPT_ETH_INFO *pOptEthInfo = s_opt_eth_info;
static UINT32 s_TcpLinkMaxNum = 1;
static UINT32 optAdaptState[MAX_OPT_NUM] = {0};
static UINT32 optEcpriSwitch[MAX_OPT_NUM] = {0};
static UINT32 optAdaptStateMask = 0;
static UINT32 optUncfgState[MAX_OPT_NUM] = {0};

static T_OptNetInfo *s_pOptNetInfo = NULL;
static T_eCpriAlmMsg *eCpriAlmMsg = NULL;
static T_OPT_IQ_COMPRESSION_FACTOR s_IqComFactor = {0};
static UINT32 s_supportOtdrModelFlag = NO_SUPPORT_OTDR_MODEL;

UINT32 RruTopologyModelFlag = 0xffff;/*RRU连接PB 或连接BBU拓扑结构区分全局变量*/
UINT32 g_diffTopologyMode = 0xFFFFFFFF;
static UINT32 g_OpticDelaySupport = 0;    /* 支持光纤时延修正能力 */
FUNC_IQ_INFO_SHOW pOptIqInfoShowCallBack = NULL;
FUNC_OPT_MIBS_INFO_GET pOptEcpriMibsInfoCallBack = NULL;
FUNC_BOARD_OPT_INFO_SHOW pBoardOptInfoShowCallBack = NULL;

FUNC_GET_PACK_OPT pGetPackOptCallBack = NULL;
FUNC_INFORM_BOOTP pInformBootpInfo = NULL;
FUNC_BOOTP_OP pBootpOpFunc = NULL;
FUNC_LINK_LOG_OP pLinkLogOpFunc = NULL;
FUNC_GET_SFP_TYPE_CHANGE_FLAG pGetSfpTypeChangeFlag = NULL;
FUNC_GET_IF1_20MNR_RATE_STA pGetIf120MNrRateSta = NULL;

FUNC_BSP_CHECK_OTDR_STATUS pFun_BspCheckOtdrStatus = NULL;
FUNC_BSP_CHECK_OTDR pFun_BspCheckOtdr = NULL;
FUNC_BSP_GET_OTDR_RET pFun_BspGetOtdrRet = NULL;
static OptVirtualAbsentCallback pOptVirtualAbsentFuncCallBack = NULL;

/* static UINT32 linkTaskEnableFlag = 1; */

static T_OptNetInfo *AddOptNetInfo(T_OptNetInfo **pOptNet,UINT32 rruOpt,UINT32 isMain,UINT32 bbuOpt,UINT8 *bbuIp,UINT8 *bbuMac)
{
    T_OptNetInfo *tmpOptNet = NULL;
    
    tmpOptNet = malloc(sizeof(T_OptNetInfo));
    if (tmpOptNet == NULL)
    {
        dbgErr("%s malloc failed\n",__FUNCTION__);
        return tmpOptNet;
    }
    memset(tmpOptNet,0,sizeof(T_OptNetInfo));

    tmpOptNet->rruOpt = rruOpt;
    tmpOptNet->bbuOpt = bbuOpt;
    if (bbuIp)
    {
        tmpOptNet->bbuIp  = IP2INT32(bbuIp);
    }
    if (bbuMac)
    {
        tmpOptNet->bbuMac = MAC2INT64(bbuMac);
    }
    tmpOptNet->isMain = isMain;
    tmpOptNet->next = NULL;
    tmpOptNet->bbuFramer = BBU_FRAMER_INVALID;

    *pOptNet = tmpOptNet;
    return tmpOptNet;
}

static UINT32 ModifyOptNetInfo(T_OptNetInfo **pOptNet,UINT32 rruOpt,UINT32 isMain,UINT32 bbuOpt,UINT8 *bbuIp,UINT8 *bbuMac)
{
    T_OptNetInfo *tmpOptNet = *pOptNet;
    
    tmpOptNet->rruOpt = rruOpt;
    tmpOptNet->bbuOpt = bbuOpt;
    tmpOptNet->bbuIp  = IP2INT32(bbuIp);
    tmpOptNet->bbuMac = MAC2INT64(bbuMac);
    tmpOptNet->isMain = isMain;

    return BSP_OK;
}

static UINT32 GetOptNetBbuFramerNum(UINT32 *pBbuFramer, UINT32 maxNum)
{
    UINT32 num = 0;
    UINT32 loop = 0;
    UINT32 found = 0;
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    
    while (pOptNet)
    {
        if (num >= maxNum)
        {
            break;
        }

        if (pOptNet->bbuFramer != 0 && pOptNet->bbuFramer != BBU_FRAMER_INVALID)
        {
            for (found = loop = 0; loop < num; loop++)
            {
                if (pBbuFramer[loop] == pOptNet->bbuFramer)
                {
                    found = 1;
                    break;
                }
            }

            if (found != 1)
            {
                pBbuFramer[num++] = pOptNet->bbuFramer;
            }
        }
        pOptNet = pOptNet->next;
    }

    return num;
}

static UINT32 GetOptNetMainOpt(UINT32 bbuFramer)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;

    while (pOptNet)
    {
        if (pOptNet->bbuFramer == bbuFramer && pOptNet->isMain == TRUE)
        {
            if (pOptNet->bbuFramer != 0 && pOptNet->bbuFramer != BBU_FRAMER_INVALID)
            {
                return pOptNet->rruOpt;
            }
        }
        pOptNet = pOptNet->next;
    }
    return BSP_ERROR;
}

UINT32 BspAddOptNetInfo(UINT32 rruOpt,UINT32 isMain,UINT32 bbuOpt,UINT8 *bbuIp,UINT8 *bbuMac)
{
    UINT32 retVal;
    T_OptNetInfo *prevOptNet = NULL;
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    RRU_OPT_CHK(rruOpt);
    
    if (pOptNet == NULL)
    {
        return AddOptNetInfo(&s_pOptNetInfo,rruOpt,isMain,bbuOpt,bbuIp,bbuMac) ? BSP_OK : BSP_ERROR;
    }

    while (pOptNet)
    {
        prevOptNet = pOptNet;
        if (rruOpt == pOptNet->rruOpt)
        {
            break;
        }
        pOptNet = pOptNet->next;
    }
    
    if (pOptNet)
    {
        retVal = ModifyOptNetInfo(&pOptNet,rruOpt,isMain,bbuOpt,bbuIp,bbuMac);
    }
    else
    {
        retVal = AddOptNetInfo(&pOptNet,rruOpt,isMain,bbuOpt,bbuIp,bbuMac) ? BSP_OK : BSP_ERROR;
        if (retVal == BSP_OK)
        {
            prevOptNet->next = pOptNet;
        }
    }
    return retVal;
}

UINT32 BspDelOptNetInfo(UINT32 rruOpt)
{
    /* UINT32 retVal; */
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    T_OptNetInfo *prev = NULL;

    while (pOptNet)
    {
        prev = pOptNet;
        if (rruOpt == pOptNet->rruOpt)
        {
            break;
        }
        pOptNet = pOptNet->next;
    }

    if (pOptNet)
    {
        prev->next = pOptNet->next;
        pOptNet->next = NULL;
        free(pOptNet);
        pOptNet = NULL;
    }

    return BSP_OK;
}

UINT32 BspAddOptNetCarrNo(UINT32 rruOpt,UINT32 carrNo)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    RRU_OPT_CHK(rruOpt);
    
    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            break;
        }
        pOptNet = pOptNet->next;
    }
    if (pOptNet == NULL)
    {
        pOptNet = AddOptNetInfo(&pOptNet,rruOpt,FALSE,BSP_ERROR,NULL,NULL);
    }

    if (pOptNet == NULL)
    {
        return BSP_ERROR;
    }

    if (carrNo >= NELEMENTS(pOptNet->carrNo))
    {
        return BSP_ERROR;
    }

    pOptNet->carrNo[carrNo] = 1;
    return BSP_OK;
}

/************************************************************************
 *  函数名称: BspSetMainOptNet
 *  功能描述: 设置光口为主光口
 *  入参说明:
 *  返 回 值:
 *  其它说明:
-------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), dumin10126090@2018-4-19, 创建
-------------------------------------------------------------------------
*/
UINT32 BspSetMainOptNet(UINT32 rruOpt)
{
    UINT32 ulRet = BSP_FAIL;
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    UINT32 framerNo = BBU_FRAMER_INVALID;

    dbgInfoEx("%s rruOpt=%d\n",__FUNCTION__,rruOpt);
    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            pOptNet->isMain = TRUE;
            ulRet = BSP_OK;
            framerNo = pOptNet->bbuFramer;
            break;
        }
        pOptNet = pOptNet->next;
    }
    if (framerNo == BBU_FRAMER_INVALID)
    {
        return ulRet;
    }
    dbgInfoEx("%s rruOpt=%d framerNo=%d\n",__FUNCTION__,rruOpt,framerNo);

    pOptNet = s_pOptNetInfo;
    while (pOptNet)
    {
        if (rruOpt != pOptNet->rruOpt && framerNo == pOptNet->bbuFramer)
        {
            pOptNet->isMain = FALSE;
        }
        pOptNet = pOptNet->next;
    }
    
    return ulRet;
}

// 返回值BSP_OK: 允许清除OptNetInfo中的主光口isMain标志
static UINT32 BspGetMainOptClrValidFlag(UINT32 ulRruOpt, UINT32 ulFramerNo, T_OptNetInfo *ptOptNet)
{
    UINT32 ulTcpLinkNum = 0;
    UINT32 ulRetVal = BSP_OK;

    if (NULL == ptOptNet)
    {
        dbgErr("%s>>Error! pOptNet cannot NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRetVal = BSP_ERROR;
    ulTcpLinkNum = BspGetTcpLinkNum();
    if (ulRruOpt != ptOptNet->rruOpt)
    {
        if (ulTcpLinkNum <= 1)
        {
            ulRetVal = BSP_OK;
        }
        else
        {
            /* FramerNo Invalid不处理 */
            if (ulFramerNo != BBU_FRAMER_INVALID)
            {
                if (ulFramerNo == ptOptNet->bbuFramer)
                {
                    ulRetVal = BSP_OK;
                }
            }
        }
    }

    dbgInfoEx("%s>>RruOpt'%d FramerNo'%d TcpSum'%d: ClrFlag(0:OK)= 0x%02X\n",
              __FUNCTION__, ulRruOpt, ulFramerNo, ulTcpLinkNum, ulRetVal);
    return ulRetVal;
}

UINT32 BspSetOptNetMainOpt(UINT32 ulRruOpt)
{
    UINT32 ulRetVal = BSP_ERROR;
    UINT32 ulFramerNo = BBU_FRAMER_INVALID;
    T_OptNetInfo *pOptNet = s_pOptNetInfo;

    while (pOptNet)
    {
        if (ulRruOpt == pOptNet->rruOpt)
        {
            ulRetVal = BSP_OK;
            pOptNet->isMain = TRUE;
            ulFramerNo = pOptNet->bbuFramer;
            break;
        }
        pOptNet = pOptNet->next;
    }

    pOptNet = s_pOptNetInfo;
    while (pOptNet)
    {
        if (BSP_OK == BspGetMainOptClrValidFlag(ulRruOpt, ulFramerNo, pOptNet))
        {
            pOptNet->isMain = FALSE;
        }
        pOptNet = pOptNet->next;
    }
    
    dbgInfoEx("%s>>RruOpt'%d FramerNo'%d: MainOpt Set %s!\n", __FUNCTION__,
              ulRruOpt, ulFramerNo, (ulRetVal) ? " Error" : "Succ");
    return ulRetVal;
}

UINT32 BspIsMainOptNet(UINT32 rruOpt)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            return pOptNet->isMain;
        }
        pOptNet = pOptNet->next;
    }
    return FALSE;
}

UINT32 BspIsSlaveOptNet(UINT32 rruOpt)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            return !pOptNet->isMain;
        }
        pOptNet = pOptNet->next;
    }
    return FALSE;
}

UINT32 BspGetOptBbuIp(UINT32 rruOpt)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            return pOptNet->bbuIp;
        }
        pOptNet = pOptNet->next;
    }
    return BSP_ERROR;
}

UINT32 BspGetOptBbuMacAndIp(UINT32 rruOpt,UINT8 *bbuIp,UINT8 *bbuMac)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            if (bbuIp)
            {
                bbuIp[0] =  (pOptNet->bbuIp >> 24) & 0xFF;
                bbuIp[1] =  (pOptNet->bbuIp >> 16) & 0xFF;
                bbuIp[2] =  (pOptNet->bbuIp >> 8)  & 0xFF;
                bbuIp[3] =  (pOptNet->bbuIp >> 0)  & 0xFF;
            }
            if (bbuMac)
            {
                bbuMac[0] = (pOptNet->bbuMac >> 40) & 0xFF;
                bbuMac[1] = (pOptNet->bbuMac >> 32) & 0xFF;
                bbuMac[2] = (pOptNet->bbuMac >> 24) & 0xFF;
                bbuMac[3] = (pOptNet->bbuMac >> 16) & 0xFF;
                bbuMac[4] = (pOptNet->bbuMac >> 8)  & 0xFF;
                bbuMac[5] = (pOptNet->bbuMac >> 0)  & 0xFF;
            }
            return BSP_OK;
        }
        pOptNet = pOptNet->next;
    }
    return BSP_ERROR;
}

UINT32 BspSetOptBbuFramer(UINT32 rruOpt, UINT32 framerNo)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;

    if (framerNo > BBU_FRAMER_INVALID)
    {
        return BSP_ERROR;
    }

    if (framerNo == 0)
    {
        framerNo = BBU_FRAMER_INVALID;
    }

    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            pOptNet->bbuFramer = framerNo;
            return BSP_OK;
        }
        pOptNet = pOptNet->next;
    }

    return BSP_ERROR;
}

UINT32 BspGetOptBbuFramer(UINT32 rruOpt)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    UINT32 framerNo = BBU_FRAMER_INVALID;

    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            framerNo = pOptNet->bbuFramer;
            break;
        }
        pOptNet = pOptNet->next;
    }
    
    return framerNo;
}

UINT32 __attribute__((weak))BspSaveOptBootpInfo(VOID)
{
    return BSP_OK;
}

UINT32 BspSetOptBbuPort(UINT32 rruOpt,UINT32 bbuPort)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;

    while (pOptNet)
    {
        if (rruOpt == pOptNet->rruOpt)
        {
            pOptNet->bbuOpt = bbuPort;
            return BSP_OK;
        }
        pOptNet = pOptNet->next;
    }
    return BSP_ERROR;
}

UINT32 setCsirsPortAntMap \
(UINT8 carr,UINT32 bdWidth,UINT32 portAntNum,UINT8 map0,UINT8 map1,UINT8 map2,UINT8 map3)
{
    T_CsirsPortAntMap para = {0};
    para.carrNo             = carr;
    para.bandWidth          = bdWidth;
    para.csirsPortAntNum    = portAntNum;
    para.csirsPortAntMap[0] = map0;
    para.csirsPortAntMap[1] = map1;
    para.csirsPortAntMap[2] = map2;
    para.csirsPortAntMap[3] = map3;
    return BspSetCsirsPortAntMap(&para);
}

UINT32 BspGetEcpriAlmMsg(T_eCpriAlmMsg **msg)
{
    INPUT_POINTER_CHECK(msg);
    INPUT_POINTER_CHECK(eCpriAlmMsg);
    *msg = eCpriAlmMsg;
    return BSP_OK;
}

UINT32 BspInitEcpriAlmMsg(T_eCpriAlmMsg *msg)
{
    INPUT_POINTER_CHECK(msg);
    if (eCpriAlmMsg)
    {
        free(eCpriAlmMsg);
        eCpriAlmMsg = NULL;
    }

    eCpriAlmMsg = (T_eCpriAlmMsg *)malloc(sizeof(T_eCpriAlmMsg));
    INPUT_POINTER_CHECK(eCpriAlmMsg);
    
    memcpy(eCpriAlmMsg, msg, sizeof(T_eCpriAlmMsg));
    return BSP_OK;
}
/*设置整机默认支持prbs类型*/
UINT32 BspGetSupportDefaultPrbsType(VOID)
{
    return s_defaultPrbsType;
}

/*获取整机默认支持prbs类型*/
UINT32 BspSetSupportDefaultPrbsType(UINT32 prbsType)
{
    s_defaultPrbsType = prbsType;
    return BSP_OK;
}
/* Started by AICoder, pid:qa61ef2038f6e2414b8e0a7760add7194aa1fcd3 */
/*更新cdr计数接口打桩*/
UINT32 BspUpdateCdrCnt(VOID)
{
    return BSP_OK;
}
/*cdr异常接口打桩*/
UINT32 BspGetCdrErr(UINT64 *pu64EventBits)
{
    INPUT_POINTER_CHECK(pu64EventBits);
    return BSP_OK;
}
/* Ended by AICoder, pid:qa61ef2038f6e2414b8e0a7760add7194aa1fcd3 */
/*设置内环/或外环，参数：loopMode 0-内环/1-外环，其他值-返回BSP_ERROR  返回值：BSP_OK/BSP_ERROR 注：A2.byte111写入0x01内环回，写4外环回*/
UINT32 BspSetOptLoopTestMode(UINT32 optNo, UINT32 loopMode)
{
    UINT32 ret = BSP_OK;
    #ifndef MULT_PROGRESS_S
    ret =  BspSetSfpLoopBackMode(optNo, loopMode);
    #endif
    return ret;
}

/*解内环环回/或解外环环回 参数：optNo 光口号  返回值：BSP_OK/BSP_ERROR  注：A2.byte111写入0x00解环回*/
UINT32 BspClrOptLoopTestMode(UINT32 optNo)
{
    UINT32 ret = BSP_OK;
    #ifndef MULT_PROGRESS_S
    ret = BspClrSfpLoopBackMode(optNo);
    #endif
    return ret;
}

/*获取内环/或外环状态，出参：0-内环，1-外环，2-正常状态即解环回状态，-1-获取寄存器值为异常值 返回值：BSP_OK/BSP_ERROR*/
UINT32 BspGetOptLoopTestMode(UINT32 optNo, UINT32 *status)
{
    UINT32 ret = BSP_OK;
    #ifndef MULT_PROGRESS_S
    ret = BspGetSfpLoopBackMode(optNo, status);
    #endif
    return ret;
}

/*存储自适应成功时的速率*/
static UINT32 aaxOptSpeed[2] = {0};
VOID BspSaveAaxOptSpeed(VOID)
{
    UINT32 index = 0;
    
    for(index = 0; index < 2; index++)
    {
        aaxOptSpeed[index] = BspGetOptSpeed(index);
        dbgInfo("%s: aaxOptSpeed[%d] = %d\n", __FUNCTION__, index, aaxOptSpeed[index]);
    }
}

UINT32 BspGetAaxOptSpeed(UINT32 optId)
{
    if (2 <= optId)
    {
        dbgErr("%s:optId[%d] err \n", __FUNCTION__, optId);
        return BSP_ERROR;
    }
    return aaxOptSpeed[optId];
}

UINT32 BspGetOptBerthresholdByBbu(UINT32 threShold, UINT32 timeTicks, UINT32 optSpeed)
{
    UINT32 optBerthreshold = 0;
    DOUBLE optSerdesRate = SERDES_RATE_24G33_D;
    
    if (0 == threShold)/*网管0--0  1--1e-10*/
    {
        dbgInfo("%s:optBerthreshold[%d]\n", __FUNCTION__, optBerthreshold);
        return optBerthreshold;
    }
    
    switch (optSpeed)
    {
        case BSP_OPT_SPEED_6P1440G:
        {
            optSerdesRate = SERDES_RATE_6G14_D;
            break;
        }
        case BSP_OPT_SPEED_9P8304G:
        {
            optSerdesRate = SERDES_RATE_9G83_D;
            break;
        }
        case BSP_OPT_SPEED_10P1376G:
        {
            optSerdesRate = SERDES_RATE_10G13_D;
            break;
        }
        case BSP_OPT_SPEED_24P33024G:
        {
            optSerdesRate = SERDES_RATE_24G33_D;
            break;
        }
        default:
        {
            break;
        }
        
    }
    optBerthreshold = (UINT32)(optSerdesRate * timeTicks / 1000.0);
    dbgInfo("%s:optSpeed[%d], optSerdesRate[%f], timeTicks[%d], optBerthreshold[%d]\n", __FUNCTION__, optSpeed, optSerdesRate, timeTicks, optBerthreshold);
    
    return optBerthreshold;
}

UINT32 BspGetEthNameErrRetFlag(UINT32 ulRruOpt)
{
    if (ulRruOpt >= MAX_OPT_NUM)
    {
        dbgErr("%s>>Param Error! RruOpt(0~%d)= %d\n", __FUNCTION__,
               MAX_OPT_NUM - 1, ulRruOpt);
        return 0; /* 入参越界, 返回默认值 0 */
    }
    
    return s_ulEthNameErrRetFlag[ulRruOpt];
}

UINT32 BspSetEthNameErrRetFlag(UINT32 ulRruOpt, UINT32 ulRetFlag)
{
    if (ulRruOpt >= MAX_OPT_NUM)
    {
        dbgErr("%s>>Param Error! RruOpt(0~%d)= %d\n", __FUNCTION__,
               MAX_OPT_NUM - 1, ulRruOpt);
        return BSP_ERROR;
    }

    s_ulEthNameErrRetFlag[ulRruOpt] = ulRetFlag;
//  dbgInfo("%s>>OptMaxSum'%d: ErrRetFlag[%d]= %d\n", __FUNCTION__,
//           MAX_OPT_NUM, ulRruOpt, s_ulEthNameErrRetFlag[ulRruOpt]);

    return BSP_OK;
}

UINT32 BspSetOptEthInfo(UINT32 bootpOptNum,T_OPT_ETH_INFO *ethInfo,UINT32 num)
{
    optBootpNum = bootpOptNum;
    pOptEthInfo = ethInfo;
    optEthInfoNum = num;
    return BSP_OK;
}

UINT32 BspGetOptEthShare(UINT32 rruOpt,UINT32 *pOptMask)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pOptMask);
    
    if (rruOpt >= MAX_OPT_NUM)
    {
        dbgErr("%s>>RruOpt'%d OptEthName Get Error!\n", __FUNCTION__, rruOpt);
        return BSP_ERROR;
    }
    
    for (loop = 0; loop < optEthInfoNum; loop++)
    {
        if (rruOpt == pOptEthInfo[loop].rruOpt)
        {
            *pOptMask = pOptEthInfo[loop].isShare;
            return BSP_OK;
        }
    }
    
    return BSP_ERROR;
}

UINT32 BspGetOptEthName(UINT32 rruOpt, CHAR *ethName, UINT32 ethNameSize)       
{
    UINT32 loop = 0;
    UINT32 ulGetErrRetFlag = 0;
    UINT32 ulFunRet = BSP_OK;
    INT32  lSprnRet = 0;

    INPUT_POINTER_CHECK(pOptEthInfo);
    
    if (rruOpt >= MAX_OPT_NUM)
    {
        dbgInfoEx("%s>>RruOpt'%d OptEthName Get Error!\n", __FUNCTION__, rruOpt);
        return BSP_ERROR;
    }
    
    for (loop = 0; loop < optEthInfoNum; loop++)
    {
        if (rruOpt == pOptEthInfo[loop].rruOpt)
        {
            lSprnRet = snprintf_s(ethName, ethNameSize,"%s\0", pOptEthInfo[loop].ethName);
            SNPRINTF_S_CHECK(lSprnRet, ethNameSize);

            return BSP_OK;
        }
    }

    lSprnRet = snprintf_s(ethName, ethNameSize, "%s", "eth1"); // 找不到时网卡名称返回"eth1"
    SNPRINTF_S_CHECK(lSprnRet, ethNameSize);

    ulGetErrRetFlag = BspGetEthNameErrRetFlag(rruOpt);
    if (0 == ulGetErrRetFlag)
    {
        ulFunRet = BSP_OK;
    }
    else
    {
        ulFunRet = BSP_ERROR;
    }

    return ulFunRet;
}

UINT32 setOptBootpFlag(UINT32 optId,UINT32 flag)
{
    UINT32 optMask = 0;
    UINT32 optNum = 0;
    UINT32 loop;
    if (BSP_OK != BspGetOptEthShare(optId,&optMask))
    {
        optMask = 0;
    }
    if (optMask == 0)
    {
        optMask |= (1 << optId);
    }
 
    optNum = min(BspGetOptNum(), MAX_OPT_NUM);
    for (loop = 0; loop < optNum; loop++)
    {
        if (optMask & (1 << loop))
        {
            s_optBootpFlag[loop] = flag;
            dbgInfoEx("%s loop'%d flag'%d optMask'0x%x optNum'%d\n",
                __FUNCTION__,loop,flag,optMask,optNum);
        }
    }

    return BSP_OK;
}

UINT32 BspGetBootpFlag(UINT32 rruOpt)
{
    if (MAX_OPT_NUM <= rruOpt)
    {
        dbgErr("%s>>RruOpt'%d BootpFlag Get Error!\n", __FUNCTION__, rruOpt);
        return BSP_ERROR;
    }
    
    return s_optBootpFlag[rruOpt];
}

UINT32 BspSetBootpFlag(UINT32 rruOpt, UINT32 flag)         
{
    UINT32 isOk = 0;
    if (MAX_OPT_NUM <= rruOpt)
    {
        dbgErr("%s>>RruOpt'%d BootpFlag Set Error!\n", __FUNCTION__, rruOpt);
        return BSP_ERROR;
    }

    if (1 == flag)
    {
        isOk = 1;   
    }
    else
    {
        isOk = 0; 
    }

    return setOptBootpFlag(rruOpt, isOk);
}

static UINT32 GetMasterOptShare(UINT32 optMask)
{
    UINT32 loop;
    UINT32 mOpt = 0;
    UINT32 linkId = 0;
    UINT32 optExist = BSP_ERROR;

    for (loop = 0; loop < MAX_OPT_NUM; loop++)
    {
        if ((optMask & (1 << loop)) == 0)
        {
            continue;
        }
    
        if ((BspGetOptStatus(loop) & (BSP_OPT_ERR_NO_EXIST | BSP_OPT_ERR_LOP)) == 0)
        {
            optExist = loop;
        }
    
        mOpt = loop;
        linkId = BspGetOptBbuFramer(loop);
        if (linkId == BBU_FRAMER_INVALID)
        {
            dbgInfoEx("%s opt=%d linkId is invalid\n",__FUNCTION__,loop);
            continue;
        }
    
        mOpt = BspGetMasterOpt(linkId);
        dbgInfoEx("%s opt=%d linkId=%d mOpt=%d\n",__FUNCTION__,loop,linkId,mOpt);
    
        if (mOpt != BSP_ERROR)
        {
            optExist = mOpt;
            break;
        }
    }

    mOpt = (optExist == BSP_ERROR) ? mOpt : optExist;
    dbgInfoEx("%s optExist=%d mOpt=%d\n",__FUNCTION__,optExist,mOpt);
    return mOpt;
}

UINT32 BspGetBootpOptNum(VOID)                    
{
    return optBootpNum;
}

UINT32 BspGetBootpOptNo(UINT32 *pBootpOpt, UINT32 num)      
{
    UINT32 loop = 0;
    UINT32 cnt = 0;
    UINT32 flag = 0;
    UINT32 mOpt = 0;
        
    if (num == 0)
    {
        dbgErr("%s>>Param Error! Num Cannot Be 0\n", __FUNCTION__);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pBootpOpt);
    
    if (num == 1)
    {
        *pBootpOpt = BspGetCurrentFiberPort();
        return BSP_OK;
    }   

    if (num != BspGetBootpOptNum())
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pOptEthInfo);

    for(flag = cnt = loop = 0;loop < optEthInfoNum && cnt < num;loop++)
    {
        if (flag & (1 << pOptEthInfo[loop].rruOpt))
        {
            dbgInfoEx("%s>>Lp'%d Cnt'%d Flag'0x%02X %s: Opt= %d\n", __FUNCTION__,
                      loop, cnt, flag, pOptEthInfo[loop].ethName,
                      pOptEthInfo[loop].rruOpt);
            continue;
        }
        if (pOptEthInfo[loop].isShare == 0)
        {
            flag |= (1<<pOptEthInfo[loop].rruOpt);
            pBootpOpt[cnt++] = pOptEthInfo[loop].rruOpt;
            dbgInfoEx("%s>>Lp'%d Cnt'%d Flag'0x%02X %s'%d: BootpOpt= %d\n",
                      __FUNCTION__, loop, cnt, flag, pOptEthInfo[loop].ethName,
                      pOptEthInfo[loop].rruOpt, pOptEthInfo[loop].rruOpt);
            continue;
        }

        flag |= pOptEthInfo[loop].isShare;
        mOpt = GetMasterOptShare(pOptEthInfo[loop].isShare);
        pBootpOpt[cnt++] = mOpt;
        dbgInfoEx("%s>>Lp'%d Cnt'%d Flag'0x%02X %s'%d mOpt'%d: BootpOpt= %d\n",
                  __FUNCTION__, loop, cnt, flag, pOptEthInfo[loop].ethName,
                  pOptEthInfo[loop].rruOpt, mOpt, mOpt);
    }

    return BSP_OK;  
}

UINT32 DbgGetBootpOptNo(VOID)      
{
    UINT32 ulOptIdx = 0;
    UINT32 ulEthOptNo = 0;
    UINT32 ulOptMaxSum = 0;
    UINT32 ulEthNameLen = 0;
    UINT32 ulBootpOptSum = 0;
    UINT32 ulFunRet = BSP_OK;
    UINT32 aulBootpOpt[MAX_OPT_NUM] = {0};
    CHAR   aucEthName[MAX_OPT_NUM][32] = {0};

    ulOptMaxSum = BspGetOptNum();
    ulBootpOptSum = BspGetBootpOptNum();
    if  ((0 == ulBootpOptSum) || (ulBootpOptSum >= MAX_OPT_NUM))
    {
        dbgErr("%s>>Error! BootpOptSum Over; BootpOptSum(1~%d)= %d\n",
               __FUNCTION__, MAX_OPT_NUM - 1, ulBootpOptSum);
        return ulFunRet;
    }

    for (ulOptIdx = 0; ulOptIdx < ulOptMaxSum; ulOptIdx++)
    {
        ulEthNameLen = sizeof(aucEthName[ulOptIdx]) - 1;
        aucEthName[ulOptIdx][ulEthNameLen] = '\0';
        BspGetOptEthName(ulOptIdx, aucEthName[ulOptIdx], ulEthNameLen);
    }

    ulFunRet = BspGetBootpOptNo(aulBootpOpt, ulBootpOptSum);
    for (ulOptIdx = 0; ulOptIdx < ulBootpOptSum; ulOptIdx++)
    {
        ulEthOptNo = pOptEthInfo[ulOptIdx].rruOpt;
        dbgInfo("%s>>OptMaxSum'%d BootpSum'%d EthOptNo'%d %s: BootpOpt[%d]= %d\n",
                __FUNCTION__, ulOptMaxSum, ulBootpOptSum, ulEthOptNo,
                aucEthName[ulEthOptNo], ulOptIdx, aulBootpOpt[ulOptIdx]);
    }

    return ulFunRet;
}

UINT32 BspSetTcpLinkMaxNum(UINT32 linkNum)
{
    s_TcpLinkMaxNum = linkNum;
    return BSP_OK;
}

UINT32 BspGetTcpLinkMaxNum()
{
    return s_TcpLinkMaxNum;
}

UINT32 BspGetTcpLinkNum()
{
    UINT32 linkNum = 1;
    UINT32 link[MAX_OPT_NUM] = {0};

    if(IS_NCR == BspIsNcr())
    {
        return 2;
    }
    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
    	return 1;
    }

    if (BspGetTcpLinkMaxNum() == 1)
    {
        return 1;
    }

    linkNum = GetOptNetBbuFramerNum(link, MAX_OPT_NUM);
    dbgInfoEx("%s>>TcpLinkNum= %d\n", __FUNCTION__, linkNum);
    return linkNum;
}

UINT32 BspGetTcpLinkId(UINT32 *pLinkId,UINT32 linkNum)
{
    UINT32 retVal;
    UINT32 link[MAX_OPT_NUM] = {0};
    UINT32 loop;
    INPUT_POINTER_CHECK(pLinkId);

    if(IS_NCR == BspIsNcr())
    {
        for(loop = 0; loop < linkNum; loop++)
        {
            *(pLinkId + loop) = loop + 1;
        }
        return 0;
    }

    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    { 
        for(loop = 0; loop < linkNum; loop++)
        {
         *(pLinkId + loop) = 0;
        }
    	return 0;
    }
    if (linkNum == 0 || linkNum > MAX_OPT_NUM)
    {
        dbgErr("[%s,%d] arg2:%d error\n",__FUNCTION__,__LINE__,linkNum);
        return BSP_ERROR;
    }
	if(0 == g_ulDynamicTcp)
    {
        if (BspGetTcpLinkMaxNum() == 1)
       {
            *pLinkId = BBU_FRAMER_SPEC;
            return BSP_OK;
        }
    }
    retVal = GetOptNetBbuFramerNum(link, linkNum);
    if (retVal != linkNum)
    {
        dbgErr("[%s,%d] real %d != expect %d\n",__FUNCTION__,__LINE__,retVal,linkNum);
        return BSP_ERROR;
    }

    memcpy(pLinkId, link, sizeof(UINT32)*linkNum);
    for (loop = 0; loop < linkNum; loop++)
    {
        dbgInfoEx("[%d] %d  ", loop, pLinkId[loop]);
    }
    dbgInfoEx("\n");
    return BSP_OK;
}

static UINT32 CheckBbuFramerIndex(UINT32 framerNo)
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;

    if (framerNo == 0 || framerNo >= BBU_FRAMER_INVALID)
    {
        return BSP_ERROR;
    }
    
    while (pOptNet)
    {
        if (framerNo == pOptNet->bbuFramer)
        {
            return BSP_OK;
        }
        pOptNet = pOptNet->next;
    }

    return BSP_ERROR;
}

UINT32 BspGetMasterOpt(UINT32 linkId)
{
    UINT32 mOpt = 0;
    UINT32 mOptLinkId = 0;

    if(IS_NCR == BspIsNcr())
    {
        return linkId - 1;
    }

    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
    	return 0;
    }

    if (BspGetTcpLinkMaxNum() == 1)
    {
        return BspGetCurrentFiberPort();
    }

    if (BSP_OK != CheckBbuFramerIndex(linkId))
    {
        dbgInfoEx("%s>>LinkId'%d: LinkId Check Error!\n", __FUNCTION__, linkId);
        return BSP_ERROR;
    }

    if (BspGetTcpLinkNum() == 1)
    {
        mOpt = BspGetCurrentFiberPort();
        mOptLinkId = BspGetOptLinkId(mOpt);
        dbgInfoEx("%s>>LinkId= %d, TcpLinkNum= 1, mOpt= %d, mOptLinkId= %d\n",
                  __FUNCTION__, linkId, mOpt, mOptLinkId);
        if (linkId == mOptLinkId)
        {
            return mOpt;
        }
    }

    mOpt = GetOptNetMainOpt(linkId);
    dbgInfoEx("%s>>LinkId= %d, MasterOpt= %d\n", __FUNCTION__, linkId, mOpt);
    return mOpt;
}

UINT32 BspGetOptLinkId(UINT32 phyOpt)
{
    if(IS_NCR == BspIsNcr())
    {
        return phyOpt + 1;
    }

    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
    	return 0;
    }

    if(0 == g_ulDynamicTcp)
    {
         if (BspGetTcpLinkMaxNum() == 1)
        {
             return BBU_FRAMER_SPEC;
        }
	}
    return BspGetOptBbuFramer(phyOpt);
}

UINT32 BspSetOptAdpatMask(UINT32 mask)
{
    optAdaptStateMask = mask;
    return BSP_OK;
}

UINT32 BspGetOptAdaptState()
{
    UINT32 loop;

    for (loop = 0; loop < MAX_OPT_NUM; loop++)
    {
        if (optAdaptStateMask & (1 << loop))
        {
            if (optAdaptState[loop] != BSP_OK)
            {
                return BSP_ERROR;
            }
        }
    }
    return BSP_OK;
}

UINT32 BspSetOptAdaptState(UINT32 optIndex,UINT32 state)
{
    if (optIndex >= MAX_OPT_NUM)
    {
        return BSP_ERROR;
    }

    optAdaptState[optIndex] = state;
    return BSP_OK;
}

UINT32 BspSetOptEcpriSwitch(UINT32 optId,UINT32 en)
{
    if (optId >= MAX_OPT_NUM)
    {
        return BSP_ERROR;
    }
    optEcpriSwitch[optId] = en;

    return BSP_OK;
}

UINT32 BspGetOptEcpriSwitch(UINT32 optId)
{
    if (optId >= MAX_OPT_NUM)
    {
        return BSP_ERROR;
    }

    return optEcpriSwitch[optId];
}

UINT32 BspGetOptCfg(UINT32 optIndex)
{
    UINT32 cfgState = 0;
	if (optIndex >= MAX_OPT_NUM)
	{
		return 0;
	}
    cfgState = optUncfgState[optIndex] ? FALSE : TRUE;
    return cfgState;
}

UINT32 BspSetOptCfg(UINT32 optIndex,UINT32 isUncfg)
{
	if (optIndex >= MAX_OPT_NUM)
	{
		return BSP_ERROR;
	}
    optUncfgState[optIndex] = isUncfg;
    return BSP_OK;
}

UINT32 BspIqInfoShowCallback(FUNC_IQ_INFO_SHOW pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pOptIqInfoShowCallBack = pFunc;
    return BSP_OK;
}

FUNC_IQ_INFO_SHOW BspGetIqInfoShowCallback()
{
    return pOptIqInfoShowCallBack;
}

UINT32 BspEcpriMibsCallback(FUNC_OPT_MIBS_INFO_GET pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pOptEcpriMibsInfoCallBack = pFunc;
    return BSP_OK;
}

FUNC_OPT_MIBS_INFO_GET BspGetEcpriMibsCallback()
{
    return pOptEcpriMibsInfoCallBack;
}

UINT32 BspBoardOptInfoCallback(FUNC_BOARD_OPT_INFO_SHOW pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pBoardOptInfoShowCallBack = pFunc;
    return BSP_OK;
}

UINT32 BspPacketOptGetFuncResiter(FUNC_GET_PACK_OPT pFunc)
{
    pGetPackOptCallBack = pFunc;
    return BSP_OK;
}

UINT32 BspGetPacketOpt(UINT8 *pMac,UINT32 *pOpt)
{
    if (pGetPackOptCallBack == NULL)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pMac);
    INPUT_POINTER_CHECK(pOpt);
    return pGetPackOptCallBack(pMac,pOpt);
}

UINT32 BspInformBootpOk(UINT32 flag)
{
    if (pInformBootpInfo == NULL)
    {
        return BSP_ERROR;
    }
    return pInformBootpInfo(flag);
}

UINT32 BspInformBootpFuncResiter(FUNC_INFORM_BOOTP pFunc)
{
    pInformBootpInfo = pFunc;
    return BSP_OK;
}

UINT32 BspGetSfpTypeChangeFlagCallInit(FUNC_GET_SFP_TYPE_CHANGE_FLAG pFunc)
{
    pGetSfpTypeChangeFlag = pFunc;
    return BSP_OK;
}

UINT32 BspGetIf1Nr20MSampleRateStateCallInit(FUNC_GET_IF1_20MNR_RATE_STA pFunc)
{
    pGetIf120MNrRateSta = pFunc;
    return BSP_OK;
}

UINT32 BspGetIf1Nr20MSampleRateSta(BOOL *pSupport)
{
    UINT32 retVal = BSP_ERROR;

    if (NULL != pSupport)
    {
        if (NULL != pGetIf120MNrRateSta)
        {
            return pGetIf120MNrRateSta(pSupport);
        }
    }

    return retVal;
}
/*****************************************************************************
 * 函数名称: BspGetSfpTypeChangeFlag(*)
 * 功能描述: 获取光模块类型改变标志
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK- 无发生改变, 其它- 光模块类型发生了改变
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095 @2021-05-22, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetSfpTypeChangeFlag(VOID)
{
    UINT32 ulChangeFlag = 0;

    if ((FUNC_GET_SFP_TYPE_CHANGE_FLAG)NULL != pGetSfpTypeChangeFlag)
    {
        ulChangeFlag = pGetSfpTypeChangeFlag();
    }

    dbgInfoEx("%s>>SfpTypeChangeFlag= 0x%04X\n", __FUNCTION__, ulChangeFlag);

    return ulChangeFlag;
}

VOID PrnOptNetInfo()
{
    T_OptNetInfo *pOptNet = s_pOptNetInfo;
    UINT32 loop;

    dbgInfo("rruOpt bbuFramer bbuOpt isMain bbuIp      bbuMac         carrNo\n");
    while (pOptNet)
    {
        dbgInfo("%-6d %-9d 0x%-4x %-6d 0x%08x 0x%012llx ",pOptNet->rruOpt,pOptNet->bbuFramer,
            pOptNet->bbuOpt,pOptNet->isMain,pOptNet->bbuIp,pOptNet->bbuMac);
        for (loop = 0; loop < BspGetCarrierNum(); loop++)
        {
            dbgInfo("%d",pOptNet->carrNo[loop]);
        }
        dbgInfo("\n");
        pOptNet = pOptNet->next;
    }
}

UINT32 optbootpinfo()
{
    UINT32 loop;
    UINT32 num;
    UINT32 bootpOpt[MAX_OPT_NUM] = {0};
    
    dbgInfo("opt  ethName  shareMask\n");
    for (loop = 0; loop < optEthInfoNum; loop++)
    {
        dbgInfo("%-3d  %-7s  %#x\n", pOptEthInfo[loop].rruOpt,
        pOptEthInfo[loop].ethName, pOptEthInfo[loop].isShare);
    }
    
    num = BspGetBootpOptNum();
    BspGetBootpOptNo(bootpOpt, num);
    dbgInfo("BootpOpt[%d]: ", num);
    for (loop = 0; loop < min(num,MAX_OPT_NUM); loop++)
    {
        dbgInfo("%d  ", bootpOpt[loop]);
    }
    dbgInfo("\n");

    return BSP_OK;
}

UINT32 tcplinkinfo()
{
    UINT32 ulLoop = 0;
    UINT32 ulCfgMaxLinkSum = 0;
    UINT32 ulCurrRdLinkNum = 0;
    UINT32 tcplink[MAX_OPT_NUM] = {0};

    ulCfgMaxLinkSum = BspGetTcpLinkMaxNum();
    ulCurrRdLinkNum = BspGetTcpLinkNum();
    BspGetTcpLinkId(tcplink, ulCurrRdLinkNum);
    dbgInfo("DefCfgTcpLinkSum'%d  GetTcpLinkNum'%d\n", ulCfgMaxLinkSum, ulCurrRdLinkNum);
    for (ulLoop = 0; ulLoop < min(ulCurrRdLinkNum, MAX_OPT_NUM); ulLoop++)
    {
        dbgInfo("LinkId= %d, MainOpt= %d\n", tcplink[ulLoop], BspGetMasterOpt(tcplink[ulLoop]));
    }
    return BSP_OK;
}

UINT32 BspBoardBootpOpCallBackInit(FUNC_BOOTP_OP pFunc)
{
    pBootpOpFunc = pFunc;
    return BSP_OK;
}

UINT32 BspGetBootpLogInfo(UINT32 bootpFlag,UINT32 optId,UINT32 itemId,UINT8 *pInfo,UINT32 num)
{
    UINT32 retVal = BSP_OK;
    if (pInfo == NULL)
    {
        return BSP_ERROR;
    }
    if (pBootpOpFunc == NULL)
    {
        return BSP_ERROR;
    }
    retVal = pBootpOpFunc(bootpFlag,optId,itemId,pInfo,num);
    dbgInfoEx("[%s:%d,%d,%d] %s\n",__FUNCTION__,bootpFlag,optId,itemId,pInfo);
    return retVal;
}

VOID bspbootplog(UINT32 bootpFlag,UINT32 optId)
{
    UINT8 data[128] = {0};
    UINT32 num = sizeof(data);
    UINT32 loop;
    dtsLogEx("%s %d,%d\n",__FUNCTION__,bootpFlag,optId);
    for (loop = 0; loop < BOOTP_LOG_NUM_MAX; loop++)
    {
        if (BSP_OK != BspGetBootpLogInfo(bootpFlag,optId,loop,data,num))
        {
            break;
        }
        dbgInfo("%s\n",data);
        dtsLog("%s\n",data);
    }
 }

UINT32 BspBoardLinkLogCallBackInit(FUNC_LINK_LOG_OP pFunc)
{
    pLinkLogOpFunc = pFunc;
    return BSP_OK;
}

UINT32 BspGetLinkLogInfo(UINT32 count,UINT32 itemId,UINT8 *pInfo,UINT32 num)
{
    UINT32 retVal = BSP_OK;
    if (pInfo == NULL)
    {
        return BSP_ERROR;
    }
    if (pLinkLogOpFunc == NULL)
    {
        return BSP_ERROR;
    }
    retVal = pLinkLogOpFunc(count,itemId,pInfo,num);
    dbgInfoEx("[%s:%d,%d] %s\n",__FUNCTION__,count,itemId,pInfo);
    return retVal;
}

UINT32 getLinkLogTestFlag()
{
    UINT32 fileLen = 0;
    //if (linkTaskEnableFlag == 0x2d2d)
    //{
    //    return 1;
    //}
    fileLen = BspGetFileLen("/.blog/bsplinklogtest");
    if (fileLen == 16)
    {
        return 1;
    }
    if (fileLen == 128)
    {
        return 2;
    }
    return 0;
}
UINT32 BspLinkLogTask(void)
{
    UINT32 retVal = 0; 
    UINT32 count = 0;
    UINT32 itemId = 0;
    UINT8  data[128] = {0};
    UINT32 num = 0;
    char   strTime[20] = {0};
    UINT32 tmSec = 0;

    count = 0;
    num = sizeof(data);
    while (1)
    {
        taskDelay(100);
        if (getLinkLogTestFlag() == 1)
        {
            continue;
        }
        if (getLinkLogTestFlag() == 2)
        {
            dbgInfo("%s exit\n",__FUNCTION__);
            break;
        }
        count++;
        for (itemId = 0; itemId < LINK_LOG_NUM_MAX; itemId++)
        {
            memset(data,0,(size_t)num);
            retVal = BspGetLinkLogInfo(count,itemId,data,num);
            if (retVal == LINK_LOG_RET_NONE)
            {
                continue;
            }
            if (retVal != LINK_LOG_RET_OK)
            {
                break;
            }

            tmSec = time(NULL);
            if((tmSec) == (time_t)(-1))
            {
                dbgErr("%s(%d) warning! > time ret'%u! \n", __FUNCTION__, __LINE__, tmSec);
            }
            BspSecondToDate(strTime, 20, tmSec, 0);
            dbgInfoEx("[linklog][%s]%s\n",strTime,data);
            //record log info to ram
            BspHistorySnapShotAdd((char *)data,num);
        }
    }
    return BSP_OK;
}

UINT32 BspLinkLogTaskInit(void)
{
    INT32  iTmpRet = 0;
    UINT32 funcRet = 0;
    char taskName[] = "linklogtask";
    FUNCPTR pFuncTask = NULL;

    pFuncTask = (FUNCPTR)BspLinkLogTask;
    iTmpRet = taskSpawn(taskName, 150, 0, 10240, pFuncTask, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (ERROR != iTmpRet)
    {
        funcRet = BSP_OK;
        dbgInfo("\n %s Create Succ! Ret= 0x %X\n", __FUNCTION__, iTmpRet);
    }
    else
    {
        funcRet = BSP_ERROR;
        dbgErr("\n %s Create Error! Ret= 0x %X\n", __FUNCTION__, iTmpRet);
    }

    return funcRet;
}

VOID bsplinklog(UINT32 count)
{
    UINT8 data[128] = {0};
    UINT32 num = 128;
    UINT32 loop;
    dtsLogEx("%s %d\n",__FUNCTION__,count);
    for (loop = 0; loop < LINK_LOG_NUM_MAX; loop++)
    {
        if (BSP_OK != BspGetLinkLogInfo(count,loop,data,num))
        {
            break;
        }
        dbgInfo("%s\n",data);
        dtsLog("%s\n",data);
    }
 }

VOID BspOptCommonInfoShow()
{
    if (pBoardOptInfoShowCallBack)
    {
        pBoardOptInfoShowCallBack();
    }

    dbgInfo("========================================\n");
    PrnOptNetInfo();
    dbgInfo("========================================\n");
    optbootpinfo();
    dbgInfo("========================================\n");
    tcplinkinfo();
    dbgInfo("========================================\n");
}
/* Started by AICoder, pid:rcd0fl859deec2214af9095c3027fa0f3735ec96 */
UINT32 BspSetDiffPbOrBbuMode(UINT32 uiModeFlag)
{
    g_diffTopologyMode = uiModeFlag;
    return BSP_OK;
}
/* Ended by AICoder, pid:rcd0fl859deec2214af9095c3027fa0f3735ec96 */
/*****************************************************************************
 *  函数名称   : BspSetPbOrBbuMode(*)
 *  功能描述   : 设置当前PRU 连的是BBU还是PB
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   : RRU公共接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
  */
UINT32 BspSetPbOrBbuMode(UINT32 uiModeFlag)
{
	RruTopologyModelFlag = uiModeFlag;
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetPbOrBbuMode(*)
 *  功能描述   : 获取当前PRU 连的是BBU还是PB
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   : RRU公共接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
  */
/* Started by AICoder, pid:4d945z6f2009cda14aae0939c0796b07bcd92e1f */
UINT32 BspGetPbOrBbuMode(VOID)
{
    if(0xFFFFFFFF != g_diffTopologyMode)
    {
        return g_diffTopologyMode;
    }

    return RruTopologyModelFlag;
}
/* Ended by AICoder, pid:4d945z6f2009cda14aae0939c0796b07bcd92e1f */
/* Started by AICoder, pid:qa606w23bfn5f8614de30a84902d5e1d06e06893 */
/*按lane获取cdr的锁定状态*/
/*为解决UT编译冲突而引入，原接口：UINT32 BspGetOptCdrStatus(UINT32 laneId, UINT32 *status)*/
UINT32 BspGetOptCdrStatusCopy(UINT32 laneId, UINT32 *status)
{
    UINT32 tmp = BSP_OK;
    UINT32 cdrSta = BSP_ERROR;

    INPUT_POINTER_CHECK(status);

    tmp = BspHalAdaptLycaGetCdrStatus(0,laneId);
    dbgInfoEx("%s: tmp = %d\n", __FUNCTION__, tmp);
    dbgInfoEx("%s: tmp = %d\n", __FUNCTION__, tmp);
    if(1 == tmp)  /*1表示锁定 0表示失锁*/
    {
        cdrSta = BSP_OK;
    }
    *status = cdrSta;
    dbgInfoEx("BspGetOptCdrStatus laneId %d status %d\n", laneId, *status);
    dbgInfoEx("BspGetOptCdrStatus laneId %d status %d\n", laneId, *status);
    if(BSP_OK != cdrSta)
    {
        BspLog(LOG_LEVEL_0,"%s laneId %d status %d\n",__FUNCTION__, laneId, *status);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:qa606w23bfn5f8614de30a84902d5e1d06e06893 */

/*为解决UT编译冲突而引入，原接口：UINT32 BspHalAdaptPcsGetLinkPcsSta(UINT32 ulPhyOpt, UINT32 *pStatus)*/
UINT32 BspHalAdaptPcsGetLinkPcsStaCopy(UINT32 ulPhyOpt, UINT32 *pStatus)
{
    return IcHalApiGetLinkPcsSta(ulPhyOpt, pStatus);
}

/*****************************************************************************
 *  函数名称   : BspGetPruLinkUpStatus(*)
 *  功能描述   : 获取当前PRU 建链状态
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: RRU_LINK_UP(1)          建链
 *            RRU_LINK_DOWN(0)     不建链
 *  其它说明   : RRU公共接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), , 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPruLinkUpStatus(VOID)
{
    UINT32 ulVal = 0;
    UINT32 ulStatus = 0;
    UINT32 ulRetVal = 0;
    UINT32 ulIndex = 0;
    UINT32 ulNum = 0;
    UINT32 mainOpt = 0;
    UINT32 cdrSta = BSP_ERROR;
    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
        for(ulIndex = 0; ulIndex < 15; ulIndex++)
        {
            BspSysMsDelay(10);
            BspGetOptCdrStatusCopy(0, &cdrSta);// laneId固定写死0。
            dbgInfoEx("%s: cdrSta = %d\n", __FUNCTION__, cdrSta);
            dbgInfoEx("%s: cdrSta = %d\n", __FUNCTION__, cdrSta);
            ulRetVal = BspHalAdaptPcsGetLinkPcsStaCopy(0, &ulStatus);
            dbgInfoEx("%s: ulStatus = %d\n", __FUNCTION__, ulStatus);
            dbgInfoEx("%s: ulStatus = %d\n", __FUNCTION__, ulStatus);
            CHECK_RETVAL_PRN(BspHalAdaptPcsGetLinkPcsSta, ulRetVal);
            if((0x3 == ulStatus) && (BSP_OK == cdrSta))
            {
                ulNum++;
                dbgInfoEx("%s: ulNum = %d\n", __FUNCTION__, ulNum);
                dbgInfoEx("%s: ulNum = %d\n", __FUNCTION__, ulNum);
            }
            else
            {
                ulNum = 0;
            }
            if(5 == ulNum)
            {
                return RRU_LINK_UP;
            }
        }
        return RRU_LINK_DOWN;
    }
    else if(RRU_BBU == BspGetPbOrBbuMode())
    {
        ulVal = BspGetRruId(0);
        if((0 < ulVal)&&(254 > ulVal))
        {
            return RRU_LINK_UP;
        }
        return RRU_LINK_DOWN;
    }
    else if (RRU_BBU_EP214 == BspGetPbOrBbuMode())
    {
        BspHalAdaptGetMainPhyOpt(&mainOpt);
        ulVal = BspGetRruId(mainOpt);
        if((BSP_ERROR != mainOpt) && ((0 < ulVal)&&(254 > ulVal)))
        {
            return RRU_LINK_UP;
        }
        return RRU_LINK_DOWN;
    }
    else
    {
        return RRU_LINK_DOWN;
    }
}

// 初始化注册回调使用
UINT32 BspLimitTransferAnalyzeCallBackInit(pLimitTransferModeAnalyze pAnalyzeFunc)
{
    g_pLimitTransferAnalyzeFunc = pAnalyzeFunc; // IcHalApiLimitTransferCtrlWordAnalyze

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetLimitTransferSupportFlag(*)
 * 功能描述: 配置LimitTransferSupport 标志
 * 输入参数: ulSupportFlag - 配置支持标志; 0- 普通传输模式, 1- 极限传输模式;
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其它- 失败
 * 其它说明: LimitTransferSupport标志默认 LIMIT_TRANSFER_SUPPORT_NOT(0)
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLimitTransferSupportFlag(UINT32 ulSupportFlag)
{
    s_ulLimitTransferSupportFlag = ulSupportFlag;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetLimitTransferSupportFlag(*)
 * 功能描述: 获取 LimitTransferSupport 标志
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 0- 支持普通传输模式, 1- 支持极限传输模式
 * 其它说明: LimitTransferSupport标志默认 LIMIT_TRANSFER_SUPPORT_NOT(0)
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLimitTransferSupportFlag(VOID)
{
    return s_ulLimitTransferSupportFlag;
}

/*****************************************************************************
 * 函数名称: BspSetRruBoardMainSlaveFlag(*)
 * 功能描述: 配置LimitTransferSupport 标志
 * 输入参数: ulBoardFlag - 设置单板主从标志; 0: 主控, 1: 从板;
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其它- 失败
 * 其它说明: 主从单板上电初始化时配置, 主控单板配置为0, 从板配置为1;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *----------------------------------------------------------------------------
 */
UINT32 BspSetRruBoardMainSlaveFlag(UINT32 ulBoardFlag)
{
    s_ulOptCtrlMainSlaveBrdFlag = ulBoardFlag;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetRruBoardMainSlaveFlag(*)
 * 功能描述: 获取 RruBoardMainSlave 标志
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 单板主从标志: 0- 主控, 1- 从板;
 * 其它说明: 主从单板上电初始化时配置, 主控单板配置为0, 从板配置为1;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *----------------------------------------------------------------------------
 */
UINT32 BspGetRruBoardMainSlaveFlag(VOID)
{
    return s_ulOptCtrlMainSlaveBrdFlag;
}

/*****************************************************************************
 * 函数名称: BspLimitTransferCtrlWordAnalyze(*)
 * 功能描述: 解析LimitTransferCtrlWord 模式
 * 输入参数: ulAnalyzeType - 类型选择
 *           0: 从控制字中解析, 防抖处理后锁存到静态变量, 不再解析, 返回静态变量状态;
 *              用于AXC 摆放图样等配置处理流程;
 *           1: 实时从控制字中解析, 无防抖处理, 不锁存到静态变量中, 函数返回实时状态;
 *              用于APP轮训任务实时读取状态, 读取到状态发生变化后直接复位整机;
 * 输出参数: 无
 * 返 回 值: 0- 普通传输模式, 1- 极限传输模式, 其它值- 无效模式
 * 其它说明: BSP调用解析(Type=0)- 传输模式需要在光口速率自适应结束OK后解析
 *           APP调用解析(Type=1)- 轮训任务读取BSP返回传输模式是否状态变化, 变化立即复位AAU；
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *----------------------------------------------------------------------------
 */
UINT32 BspLimitTransferCtrlWordAnalyze(UINT32 ulAnalyzeType)
{
    UINT32 ulTryCnts = 0;
    UINT32 ulGetTrsrMode = 0;
    UINT32 ulSupportFlag = 0;
    UINT32 ulAnalyzeMode = 250;
    UINT32 ulTrsrModeRet = 255;

    ulSupportFlag = BspGetLimitTransferSupportFlag();
    if (LIMIT_TRANSFER_SUPPORT_YES != ulSupportFlag)
    {
        ulTrsrModeRet = 0;
    //  BspSetLimitTransferMode(0); // 是否需要配置成普通传输模式???
        dbgInfoEx("%s>>Type'%d Donnot Support LimitTransfer; RetMode= %d\n",
                  __FUNCTION__, ulAnalyzeType, ulTrsrModeRet);
        return ulTrsrModeRet; // 不支持极限传输功能, 直接返回普通传输模式
    }

    if (NULL == g_pLimitTransferAnalyzeFunc)
    {
        ulTrsrModeRet = 255;
        dbgErr("%s>>Type'%d pLimitTransferFunc Init Error! RetMode= %d\n",
               __FUNCTION__, ulAnalyzeType, ulTrsrModeRet);
        return ulTrsrModeRet; // 初始化异常直接退出;
    }

    if (0 == ulAnalyzeType)
    {
        ulGetTrsrMode = BspGetLimitTransferMode();
        if (ulGetTrsrMode < LIMIT_TRANSFER_MODE_INVALID)
        {
            ulTrsrModeRet = ulGetTrsrMode;
            dbgInfoEx("%s>>Type'%d PastMode Get Succ! LimitTransferMode= %d\n",
                      __FUNCTION__, ulAnalyzeType, ulTrsrModeRet);
            return ulTrsrModeRet; // 传输模式已经配置成功, 直接返回历史的传输模式;
        }

        // 传输模式解析时防抖处理: 在BSP 光口速率自适应结束OK 后,
        // 从控制字中解析, 读取底层状态, 防抖周期100ms, 防抖两次;
        for (ulTryCnts = 0; ulTryCnts < 3; ulTryCnts++)
        {
            // 0- 普通传输模式, 1- 极限传输模式, 其它值- 无效模式
            ulAnalyzeMode = g_pLimitTransferAnalyzeFunc();
        //  ulAnalyzeMode = IcHalApiLimitTransferCtrlWordAnalyze(); // 直接调用???
            if ((ulAnalyzeMode < LIMIT_TRANSFER_MODE_INVALID) && (0 != ulTryCnts))
            {
                break;
            }
            BspSysMsDelay(100);
        }
        
        if (ulTryCnts < 3)
        {
            ulTrsrModeRet = ulAnalyzeMode;
            BspSetLimitTransferMode(ulAnalyzeMode);
        }
        else
        {
            ulTrsrModeRet = 255;
        }
    }
    else
    {
        // 0- 普通传输模式, 1- 极限传输模式, 其它值- 无效模式
        ulAnalyzeMode = g_pLimitTransferAnalyzeFunc();
        if (ulAnalyzeMode < LIMIT_TRANSFER_MODE_INVALID)
        {
            ulTrsrModeRet = ulAnalyzeMode;
        }
        else
        {
            ulTrsrModeRet = 255;
        }
    }

    dbgInfoEx("%s>>Type'%d TryCnt'%d: LimitTransferMode= Get'%d Ret'%d\n", __FUNCTION__,
              ulAnalyzeType, ulTryCnts, ulAnalyzeMode, ulTrsrModeRet);
    return ulTrsrModeRet;
}

/*****************************************************************************
 * 函数名称: BspSetLimitTransferMode(*)
 * 功能描述: 配置LimitTransferMode
 * 输入参数: ulTransferMode - 极限传输模式
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其它- 失败
 * 其它说明: LimitTransfer Mode 默认255, 无效状态
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLimitTransferMode(UINT32 ulTransferMode)
{
    UINT32 ulFunRet = BSP_OK;

    s_ulAxcLimitTransferMode = ulTransferMode;
    IcHalApiSetLimitTransferMode(ulTransferMode);
    
    return ulFunRet;
}

/*****************************************************************************
 * 函数名称: BspGetLimitTransferMode(*)
 * 功能描述: 获取 LimitTransferMode
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 0- 普通传输模式, 1- 极限传输模式, 其它值- 无效模式
 * 其它说明: 从静态变量中获取, 调用此函数时先判断函数返回值是否有效;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLimitTransferMode(VOID)
{
    UINT32 ulGetTrsrMode = 250;
    UINT32 ulTrsrModeRet = 251;

    ulGetTrsrMode = s_ulAxcLimitTransferMode;
    if (ulGetTrsrMode < LIMIT_TRANSFER_MODE_INVALID)
    {
        ulTrsrModeRet = ulGetTrsrMode;
    }
    else
    {
        ulTrsrModeRet = 255;
    }
    dbgInfoEx("%s>>LimitTransferMode= Get'%d Ret'%d\n", __FUNCTION__,
              s_ulAxcLimitTransferMode, ulTrsrModeRet);

    return ulTrsrModeRet;
}
UINT32 scalecfgon_dpdic42(VOID)
{
    g_ulScaleCfg = SCALE_CONFIG_ENABLE;
    return g_ulScaleCfg;
}
UINT32 scalecfgoff_dpdic42(VOID)
{
    g_ulScaleCfg = SCALE_CONFIG_DISABLE;
    return g_ulScaleCfg;
}

static VOID BspScaleConfigureProcess(VOID)
{
    UINT32 ret = BSP_OK;
    while(1)
    {
        if(SCALE_CONFIG_DISABLE == g_ulScaleCfg)
        {
            BspSysMsDelay_Sys(10);
            continue;
        }
		dbgInfoEx("<%s> bsp scale configure information:%d\n", __FUNCTION__, ret);
        ret = BspHalApiUpdateScale();
        ret |= BspHalAdaptUpdateRoeState();
        if(BSP_OK != ret)
        {
            dbgInfoEx("<%s> bsp scale configure failed! lErrcode:%d\n", __FUNCTION__, ret);
        }
        BspSysMsDelay_Sys(10);
    }
}
/**************************************************************************
 * 函数名称： BspScaleConfigThreadInit
 * 功能描述： scale因子配置线程
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2023/01/30    V1.1     00300750        创建
 **************************************************************************/
UINT32 BspScaleConfigThreadInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;

    lTaskID = taskSpawn("BspScaleCfg", SCALE_CONFIG_PROCESS_PRIORITY, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspScaleConfigureProcess, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgErr("create thread <%s> failed! lErrcode:%d\n", __FUNCTION__, lTaskID);
        ulRet = BSP_ERROR;
    }
    else
    {
        dbgErr("create thread <%s> success!\n", __FUNCTION__);
    }
    return ulRet;
}

UINT32 gSmartPwroffOptTestFlag = 0;

UINT32 BspSetSmartPwroffOptTestEn(UINT32 uFlag)
{
    gSmartPwroffOptTestFlag = uFlag;
    return BSP_OK;
}

UINT32 BspGetSmartPwroffOptTestFlag(VOID)
{
    return gSmartPwroffOptTestFlag;
}

UINT32 BspSetTddSupportRingModeWorkFlag(UINT32 flag)
{
    g_TDDOptSupportRingWorkModeFlag = flag;
    return BSP_OK;
}
UINT32 BspGetTddSupportRingModeWorkFlag(void)
{
    return g_TDDOptSupportRingWorkModeFlag;

}

/*单板下传递是否支持光纤时延修正能力的标志 */
UINT32 BspSetOpticDelaySupportFlag(UINT32 ulFlag)
{
    g_OpticDelaySupport = ulFlag;
    return BSP_OK;
}
UINT32 BspGetOpticDelaySupportFlag(void)
{
    return g_OpticDelaySupport;
}
/**************************************************************************
 * 函数名称： BspSetElecPortType
 * 功能描述： 压缩因子主从片之间byte对齐:设置每个通道的电口组号配置属性，按照bit提供
 * 输入参数：  reportFlag  ：上报标志，0：不上报 1：上报
 *           elecPortType ：对应频段通道的bit位为1
 * 输出参数： 无
 * 返 回 值： BSP_OK
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspSetElecPortType(UINT32 *reportFlag, UINT32 *elecPortType)
{

    s_IqComFactor.reportFlag   = *reportFlag;
    s_IqComFactor.elecPortType = *elecPortType;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称： BspGetElecPortType
 * 功能描述： 压缩因子主从片之间byte对齐:设置每个通道的电口组号配置属性，按照bit提供
 * 输入参数：  reportFlag  ：上报标志，0：不上报 1：上报
 *           elecPortType ：对应频段通道的bit位为1
 * 输出参数： 无
 * 返 回 值： BSP_OK
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspGetElecPortType(UINT32 *pReportFlag, UINT32 *pElecPortType)
{

    *pReportFlag   = s_IqComFactor.reportFlag;
    *pElecPortType = s_IqComFactor.elecPortType;

    dbgInfoEx("reportFlag = %d elecPortType = %x\n", *pReportFlag,*pElecPortType);

    return BSP_OK;
}

UINT32 BspSetProcotolChgFlag(UINT32 flag)
{
    s_procotolChgFlag = flag;
    return s_procotolChgFlag;
}

UINT32 BspGetProcotolChgFlag(void)
{
    return s_procotolChgFlag;
}
/* Started by AICoder, pid:vdc5cv4a3eu3dd014cfd0b3a60a9aa0e76a32475 */
/*D42不支持*/
UINT32 BspIsSupportClearData(VOID)
{
    return NOT_SUP_OPT_CLR_DATA_D42;
}
/*D42空接口*/
UINT32 BspSetDlAntDataClr(UINT32 localChanNo, UINT32 cellIdx, UINT32 laneSwitch)
{
    return BSP_OK;
}
/* Ended by AICoder, pid:vdc5cv4a3eu3dd014cfd0b3a60a9aa0e76a32475 */

/* Started by AICoder, pid:280b8e5b38r8edb1466309eb707bfd410e9047bf */
UINT32 BspCheckOtdrParameters(const T_OTDR_DETECT_PARA *i_ptOtdrConf)
{
    BspLog(LOG_LEVEL_0, "start OTDR step1: checkstatus \n");
    if(NULL != pFun_BspCheckOtdrStatus)
    {
        if(NULL != i_ptOtdrConf)
        {
            BspLog(LOG_LEVEL_0, "%s i_ptOtdrConf position = 0x%x\n", __FUNCTION__, i_ptOtdrConf->ui32Position);
            return pFun_BspCheckOtdrStatus(i_ptOtdrConf);
        }
        
    }
    return BSP_OK;
}

UINT32 BspRunOtdrDetection(const T_OTDR_DETECT_PARA *i_ptOtdrConf)
{
    BspLog(LOG_LEVEL_0, "start OTDR step2: run check \n");
    if(NULL != pFun_BspCheckOtdr)
    {
        if(NULL != i_ptOtdrConf)
        {
            BspLog(LOG_LEVEL_0, "%s ui32Version 0x%x ui32Transid 0x%x ui32Position  0x%x ActionType 0x%x TestType 0x%x \
            Mode 0x%x ulDistance 0x%x ulDuration 0x%x ulPulseWidth 0x%x ulCodeWidth 0x%x ulCodeLen 0x%x ulWaveLen 0x%x dIor 0x%x dBsl 0x%x \n"
            , __FUNCTION__, i_ptOtdrConf->ui32Version,i_ptOtdrConf->ui32Transid,i_ptOtdrConf->ui32Position,i_ptOtdrConf->ActionType,
            i_ptOtdrConf->TestType,i_ptOtdrConf->Mode,i_ptOtdrConf->ulDistance,i_ptOtdrConf->ulDuration,i_ptOtdrConf->ulPulseWidth,
            i_ptOtdrConf->ulCodeWidth,i_ptOtdrConf->ulCodeLen,i_ptOtdrConf->ulWaveLen,i_ptOtdrConf->dIor,i_ptOtdrConf->dBsl);
            
            return pFun_BspCheckOtdr(i_ptOtdrConf);
        }
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:280b8e5b38r8edb1466309eb707bfd410e9047bf */

//D42空接口
BOOL BspIsSupportOtdr(UINT32 i_OptId)
{
    return BSP_OK;
}

/* Started by AICoder, pid:m6533ef9cez2427144b40a8390a3705b7cf626b2 */
UINT32 BspGetOtdrFiles(UINT32 i_OptNo, T_OTDR_DETECT_RESULT_FILE *ptResultFiles)
{
    BspLog(LOG_LEVEL_0, "start OTDR step3: Get files \n");
    if(NULL != pFun_BspGetOtdrRet)
    {
        BspLog(LOG_LEVEL_0, "%s, optid = %d\n", __FUNCTION__, i_OptNo);
        return pFun_BspGetOtdrRet(i_OptNo, ptResultFiles);
    }
    return BSP_OK;
}

UINT32 BspSetModelSupportOtdr(UINT32 supportFlag)
{
    s_supportOtdrModelFlag = supportFlag;
    BspLog(LOG_LEVEL_0, "%s, supportflag = %d\n", __FUNCTION__, s_supportOtdrModelFlag);
    return BSP_OK;
}

BOOL BspModelIsSupportOtdr(VOID)
{
    BspLog(LOG_LEVEL_0, "%s, supportflag = %d\n", __FUNCTION__, s_supportOtdrModelFlag);
    if(SUPPORT_OTDR_MODEL == s_supportOtdrModelFlag)
    {
        return TRUE;
    }
    return FALSE;
}

VOID BspSetOptVirtualAbsentFuncCallBack(OptVirtualAbsentCallback callback) 
{
    pOptVirtualAbsentFuncCallBack = callback;
}


UINT32 BspSetOptVirtualAbsentStat(UINT32 optId, UINT32 status)
{
    if (pOptVirtualAbsentFuncCallBack != NULL) {
        return pOptVirtualAbsentFuncCallBack(optId, status);
    }
    return BSP_ERROR;
}

UINT32 BspSetOTDRCallBack(FUNC_BSP_CHECK_OTDR_STATUS pBspCheckOtdrStatus, FUNC_BSP_CHECK_OTDR pBspCheckOtdr, FUNC_BSP_GET_OTDR_RET pBspGetOtdrRet)
{
    pFun_BspCheckOtdrStatus = pBspCheckOtdrStatus;
    pFun_BspCheckOtdr = pBspCheckOtdr;
    pFun_BspGetOtdrRet = pBspGetOtdrRet;
    return BSP_OK;
}

/* Ended by AICoder, pid:m6533ef9cez2427144b40a8390a3705b7cf626b2 */

/* Started by AICoder, pid:bb401e8fd4tc0181484c09e67036fe0eb119d2de */
UINT32 BspCfgCamera(T_CameraCfg* pCamera, UINT32 num)
{
    return BSP_OK;
}

UINT32 BspSupportCameraModel(VOID)
{
    return BSP_OK;
}
/* Ended by AICoder, pid:bb401e8fd4tc0181484c09e67036fe0eb119d2de */

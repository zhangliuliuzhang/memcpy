/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : optctrlcommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了光口控制公共接口声明
* 注意事项 : 无
* 作    者 :   10206930
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10206930
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_OPTCTRLCFGCOMMON_H_
#define _FUNCLIB_OPTCTRLCFGCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "optctrlapi.h"
#include "funccommon_log.h"


#define BOOTP_LOG_NUM_MAX        32

#define LINK_LOG_RET_OK          0
#define LINK_LOG_RET_NONE        1
#define LINK_LOG_RET_ERR         -1
#define LINK_LOG_NUM_MAX         128
#define BBU_FRAMER_INVALID       0xFF

#define INTERNEL_LOOP_BACK                (0)/*内部环回*/
#define EXTERNEL_LOOP_BACK                (1)/*外部环回*/
#define NOT_LOOP_BACK                     (2)/*非环回*/

#define RRU_LINK_UP                       (1)  /* RRU建链 */
#define RRU_LINK_DOWN                     (0)  /* RRU不建链 */

#define NOT_SUP_OPT_CLR_DATA_D42         0

#define OPT_CELL_NUM                     64

#define SUPPORT_OTDR_MODEL            (UINT32)(1)
#define NO_SUPPORT_OTDR_MODEL         (UINT32)(0)

typedef UINT32 (*FUNC_SCALE_CALC)(INT32 refVal, UINT32 *pscaleVal);

enum
{
    ECPRI_ALM_MSG_PWRDWN = 0,
    ECPRI_ALM_MSG_RSTRSP,
    ECPRI_ALM_MSG_NUM
};

typedef struct T_OptAddrInfo
{
    UINT32        addrBase;
    UINT32        addrLof;
    UINT32        LofBase;
    UINT32        LofStep;
    UINT32        LosBase;
    UINT32        LosStep;
    UINT32        LopBase;
    UINT32        LopStep;
    UINT32        RruIdAddr;
    UINT32        RruIdRange;
    UINT32        addrSwitch;
    UINT32        addrBbuFiberPort;
}T_OptAddrInfo;

typedef struct T_OptCtrlInfo
{
    UINT32        maxBbFpgaNum;
    UINT32        maxSfpNum;
    UINT32        optNumPerSfp;
    UINT32        bbFpgaNumPerSfp;
    UINT32        sfpNumPerBbFpga;
    UINT32        crossFlag;
    UINT32        initFlag;

    T_OptAddrInfo para;
    struct T_OptCtrlInfo *next;
}T_OptCtrlInfo;

typedef struct T_OPT_SWITCH_FUNC
{
    UINT32 (*pLinkToFpga)(UINT32);
    UINT32 (*pBbFpgaNum)(VOID);
    UINT32 (*pOptNumOfBbFpga)(VOID);
    UINT32 (*pOptNumOfSfp)(VOID);
    UINT32 (*pSfpNumOfBbFpga)(VOID);
    UINT32 (*pBbFpgaNumOfSfp)(VOID);
    UINT32 init;
    UINT32 specMaskFlag;
}T_OPT_SWITCH_FUNC;


typedef struct tagT_eCpriAlmMsg
{
    UINT32 (*pMsgFill)(UINT32 rruOpt,UINT32 msgType);
}T_eCpriAlmMsg;

typedef enum
{
    E_AAU_OPT_STATUS_CTRL_LOW_FREQ = 0,
    E_AAU_OPT_STATUS_CTRL_HGH_FREQ = 1,
}E_AAU_OPT_STATUS_CTRL_TYPE;

#pragma pack(4)
typedef struct T_OPT_ETH_INFO
{
    UINT32 rruOpt;
    const char *ethName; /* 网卡名称 */
    UINT32 isShare;  /* 0:独立bootp,非0:光口号掩码,多光口共享网卡 */
}T_OPT_ETH_INFO;
#pragma pack()

typedef struct T_OPT_IQ_COMPRESSION_FACTOR
{
    // NR上行压缩因子主从片之间byte对齐
    UINT32 reportFlag;        /* reportFlag  ：上报标志，0：不上报 1：上报 */
    UINT32 elecPortType;      /* elecPortType ：对应频段通道的bit位为1 */

}T_OPT_IQ_COMPRESSION_FACTOR;

typedef struct T_OPT_MIB_STATISTIC_INFO
{
    UINT32 rxUnicastPkts;      /* 接收单播包数统计 */   /*CC0-CC16共同支持*/
    UINT32 txUnicastPkts;      /* 发送单播包数统计 */        /*CC0-CC16共同支持*/
    UINT32 txGoodBytes;        /* 发送的好的字节数*/  /*仅CC16支持*/
    UINT32 rxGoodBytes;        /* 接收的好的字节数*/  /*仅CC16支持*/
    UINT32 rxBroadcastPkts;    /* 接收广播包数统计 */     /*仅CC0支持*/
    UINT32 txBroadcastPkts;    /* 发送广播包数统计 */         /*仅CC0支持*/
}T_OPT_MIB_STATISTIC_INFO;

typedef struct T_DbxOptCellInfo
{
    T_CellCfgInfo optCellInfo;
    T_PrachCellInfo optPrachInfo;
} T_DbxOptCellInfo;

typedef enum
{
    ECPRI_SHOW_MIB_STATISTIC_TYPE_CPU  = 0,
    ECPRI_SHOW_MIB_STATISTIC_TYPE_FPGA = 1,
} OPT_MIB_STATISTIC_TYPE;

typedef UINT32 (*FUNC_OPT_MIBS_INFO_GET)(UINT32 type, T_OPT_MIB_STATISTIC_INFO *info);
typedef UINT32 (*FUNC_IQ_INFO_SHOW)(INT8 *strInfo, UINT32 length);
typedef VOID (*FUNC_BOARD_OPT_INFO_SHOW)(VOID);

typedef UINT32 (*FUNC_GET_SFP_TYPE_CHANGE_FLAG)(VOID);
typedef UINT32 (*FUNC_GET_PACK_OPT)(UINT8 *pMac,UINT32 *pOpt);
typedef UINT32 (*FUNC_INFORM_BOOTP)(UINT32 flag);
typedef UINT32 (*FUNC_BOOTP_OP)(UINT32 bootpFlag,UINT32 optId,UINT32 itemId,UINT8 *pInfo,UINT32 num);
typedef UINT32 (*FUNC_LINK_LOG_OP)(UINT32 count,UINT32 itemId,UINT8 *pInfo,UINT32 num);
typedef UINT32 (* FUN_BspScaleConfigProcess)(VOID);
typedef UINT32 (*FUNC_GET_IF1_20MNR_RATE_STA)(BOOL *pSupport);

typedef UINT32 (*FUNC_BSP_CHECK_OTDR_STATUS)(const T_OTDR_DETECT_PARA *i_ptOtdrConf);
typedef UINT32 (*FUNC_BSP_CHECK_OTDR)(const T_OTDR_DETECT_PARA *i_ptOtdrConf);
typedef UINT32 (*FUNC_BSP_GET_OTDR_RET)(UINT32 i_OptNo, T_OTDR_DETECT_RESULT_FILE *ptResultFiles);
typedef UINT32 (*OptVirtualAbsentCallback)(UINT32 optId, UINT32 status);

/* KW */
VOID bspbootplog(UINT32 bootpFlag,UINT32 optId);
VOID bsplinklog(UINT32 count);

UINT32 BspInitAauOptStatusCtrlTypeCfg(UINT32 type);
UINT32 BspSetOptCtrlSwitchFuncInit(T_OPT_SWITCH_FUNC *pFunc);
UINT32 BspCalcScaleValCallback(FUNC_SCALE_CALC pFunc);

UINT32 BspAddOptNetCarrNo(UINT32 rruOpt,UINT32 carrNo);
UINT32 BspAddOptNetInfo(UINT32 rruOpt,UINT32 isMain,UINT32 bbuOpt,UINT8 *bbuIp,UINT8 *bbuMac);
UINT32 BspDelOptNetInfo(UINT32 rruOpt);
UINT32 BspIsMainOptNet(UINT32 rruOpt);
UINT32 BspIsSlaveOptNet(UINT32 rruOpt);
UINT32 BspGetOptBbuIp(UINT32 rruOpt);
UINT32 BspGetOptBbuMacAndIp(UINT32 rruOpt,UINT8 *bbuIp,UINT8 *bbuMac);
UINT32 BspSetOptBbuFramer(UINT32 rruOpt,UINT32 framerNo);
UINT32 BspGetOptBbuFramer(UINT32 rruOpt);
UINT32 BspSetOptBbuPort(UINT32 rruOpt,UINT32 bbuPort);
UINT32 BspSetOptEcpriSwitch(UINT32 optId,UINT32 en);

UINT32 BspSetBbuFiberPort(UINT32 ruOptPort,UINT32 bbuPort);

UINT32 BspGetEcpriAlmMsg(T_eCpriAlmMsg **msg);
UINT32 BspInitEcpriAlmMsg(T_eCpriAlmMsg *msg);
UINT32 BspSetOptEthInfo(UINT32 bootpOptNum,T_OPT_ETH_INFO *ethInfo,UINT32 num);
UINT32 BspSetTcpLinkMaxNum(UINT32 linkNum);
UINT32 BspSetOptAdaptState(UINT32 optIndex,UINT32 state);
UINT32 BspSetOptAdpatMask(UINT32 mask);
UINT32 BspGetOptLinkId(UINT32 phyOpt);
UINT32 BspGetOptCfg(UINT32 optIndex);
UINT32 BspGetOptEthShare(UINT32 rruOpt,UINT32 *pOptMask);

UINT32 BspSetUlBcWgtParaToBb(UINT32 adWeightUlAntComb[],UINT32 size);

UINT32 BspIqInfoShowCallback(FUNC_IQ_INFO_SHOW pFunc);
FUNC_IQ_INFO_SHOW BspGetIqInfoShowCallback();
UINT32 BspEcpriMibsCallback(FUNC_OPT_MIBS_INFO_GET pFunc);
FUNC_OPT_MIBS_INFO_GET BspGetEcpriMibsCallback();
UINT32 BspBoardOptInfoCallback(FUNC_BOARD_OPT_INFO_SHOW pFunc);

VOID BspOptCommonInfoShow();
UINT32 BspPacketOptGetFuncResiter(FUNC_GET_PACK_OPT pFunc);
UINT32 BspInformBootpOk(UINT32 flag);
UINT32 BspInformBootpFuncResiter(FUNC_INFORM_BOOTP pFunc);
UINT32 DbgGetBootpOptNo(VOID);
UINT32 BspSetMainOptNet(UINT32 rruOpt);
UINT32 BspSetOptNetMainOpt(UINT32 rruOpt);
UINT32 BspSetOptSwitchCw(UINT32 bbuPort);

UINT32 BspBoardBootpOpCallBackInit(FUNC_BOOTP_OP pFunc);
UINT32 BspBoardLinkLogCallBackInit(FUNC_LINK_LOG_OP pFunc);
UINT32 BspGetTcpLinkMaxNum();
UINT32 BspSetEthNameErrRetFlag(UINT32 ulRruOpt, UINT32 ulRetFlag);
UINT32 BspLinkLogTaskInit(void);
UINT32 BspGetOptEcpriSwitch(UINT32 optId);

UINT32 BspSetOptMacAddr(UINT8* pStr, UINT32 optId);
STATUS taskDelay(int interval);
int taskSpawn (const char *name, int priority, int options, int stackSize,
        FUNCPTR entryPt, int arg1, int arg2, int arg3,
        int arg4, int arg5, int arg6, int arg7,
        int arg8, int arg9, int arg10);
UINT32 BspGetSfpTypeChangeFlagCallInit(FUNC_GET_SFP_TYPE_CHANGE_FLAG pFunc);
UINT32 BspScaleConfigThreadInit(VOID);
UINT32 BspGetOptStatus(UINT32 optId);
UINT32 BspGetOptStatusForOptAdpt(UINT32 optId);
VOID BspConfigFrDir(VOID);

typedef UINT32(*pLimitTransferModeAnalyze)(VOID);
UINT32 BspLimitTransferAnalyzeCallBackInit(pLimitTransferModeAnalyze pAnalyzeFunc);
UINT32 BspSetRruBoardMainSlaveFlag(UINT32 ulBoardFlag);
UINT32 BspSetLimitTransferSupportFlag(UINT32 ulSupportFlag);

// UINT32 BspGetRruBoardMainSlaveFlag(VOID);                     // 在Bsppub.h中声明;
// UINT32 BspGetLimitTransferSupportFlag(VOID);                  // 在Bsppub.h中声明;
// UINT32 BspLimitTransferCtrlWordAnalyze(UINT32 ulAnalyzeType); // 在Bsppub.h中声明;
// UINT32 BspSetLimitTransferMode(UINT32 ulTransferMode);        // 在Bsppub.h中声明;
// UINT32 BspGetLimitTransferMode(VOID);                         // 在Bsppub.h中声明;
UINT32 BspSetTddSupportRingModeWorkFlag(UINT32 ulFlag);
UINT32 BspSetOpticDelaySupportFlag(UINT32 ulFlag);
UINT32 BspGetTddSupportRingModeWorkFlag(void);
UINT32 BspGetIf1Nr20MSampleRateStateCallInit(FUNC_GET_IF1_20MNR_RATE_STA pFunc);
UINT32 BspGetIf1Nr20MSampleRateSta(BOOL *pSupport);
UINT32 BspSetElecPortType(UINT32 *reportFlag, UINT32 *elecPortType);
UINT32 BspSetProcotolChgFlag(UINT32 flag);
UINT32 BspGetProcotolChgFlag(void);
UINT32 BspSetDlAntDataClr(UINT32 localChanNo, UINT32 cellIdx, UINT32 laneSwitch);
UINT32 scalecfgon_dpdic42(VOID);
UINT32 scalecfgoff_dpdic42(VOID);
UINT32 BspGetPruLinkUpStatus(VOID);
UINT32 BspGetOptCdrStatusCopy(UINT32 laneId, UINT32 *status);
UINT32 BspHalAdaptPcsGetLinkPcsStaCopy(UINT32 ulPhyOpt, UINT32 *pStatus);
UINT32 BspRcdOptCommonInfo(void);
UINT32 BspSetOptVirtualAbsentStat(UINT32 optId, UINT32 status);
UINT32 BspSetModelSupportOtdr(UINT32 supportFlag);
UINT32 BspSetOTDRCallBack(FUNC_BSP_CHECK_OTDR_STATUS pBspCheckOtdrStatus, FUNC_BSP_CHECK_OTDR pBspCheckOtdr, FUNC_BSP_GET_OTDR_RET pBspGetOtdrRet);
VOID BspSetOptVirtualAbsentFuncCallBack(OptVirtualAbsentCallback callback);
UINT32 BspSetDiffPbOrBbuMode(UINT32 uiModeFlag);

#ifdef __cplusplus
}
#endif

#endif /* _FUNCLIB_OPTCTRLCFGCOMMON_H_ */



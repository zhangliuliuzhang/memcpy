/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : optctrl.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 
 * 注意事项 : 无
 * 作    者   : 10090699
 * 创建日期 : 2017-3-2 17:26:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 10090699
 * 修改日戳: 2017-3-2 17:26:34
 * 变更说明: 创建文件

 *----------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "bspcomm.h"

#include "bsppub.h"

//#include "ntl_nacc_xmac_api.h" /*DPDIC4编译修改*/

//#include "ichalcomm.h" /*DPDIC4编译修改*/
//#include "ntl_l2ss.h" /*DPDIC4编译修改*/
//#include "ecpridrv.h" /*DPDIC4编译修改*/
//#include "opt_carr_attribute.h" /*DPDIC4编译修改*/


//#include "vcell_proc.h" /*DPDIC4编译修改*/
#include "optctrlapi.h"
//#include "roe.h" /*DPDIC4编译修改*/
//#include "ntl_l2ss_api.h" /*DPDIC4编译修改*/
//#include "roecw.h" /*DPDIC4编译修改*/
#include "optctrl_inter_def.h"
#include "optctrl_ecpri_ic4_2.h"

#define CHECK_QID_ID(qid)    \
        do \
        {    \
            if((qid) >= MAX_L2SS_ROE_QID_NUM)   \
            {                                    \
                IC_PRN_ERR("EcpriCfg","CHECK_QID_ID error\n");\
                return BSP_ERROR;   \
            }    \
        }while(0)

#define CHECK_ECPRI_TDMCHN_ID(tdmChn)    \
        do \
        {    \
            if(((tdmChn) > MAX_L2SS_ROE_TDM_ID) || ((tdmChn) < MIN_L2SS_ROE_TDM_ID))   \
            {                                    \
                IC_PRN_ERR("EcpriCfg","CHECK_ECPRI_TDMCHN_ID error\n");\
                return BSP_ERROR;   \
            }    \
        }while(0)

    /*DPDIC4编译修改*/
#if 0
T_EcpriCellStreamInfo tNtlEcpriCellStreamInfo = {0};

typedef T_PhyToRoeERSFastCfgAll T_PhyToRoeFastParaCfg;
#endif

/*DPDIC4编译修改*/
#if 0
UINT32 BspGetCellAntFlowInfo(T_EcpriCellStreamInfo *pEcpriStreamInfo,UINT32 dir,T_EcpriCellFlowInfo *pEcpriCellFlowInfo)
{
    UINT32 cellIdx;
    UINT32 streamNum; /*决定下面赋值的下标个数*/ 
    UINT32 iqAntMask = 0;
    UINT32 antNo = 0;
    UINT32 prachNo = 0;
    UINT32 tdmChn=  0;
    UINT32 tdmChip = 0;
    UINT32 tdmSeq = 0;
    UINT32 tdmPos = 0;
    UINT32 idx;
    UINT32 optId = 0;
    UINT32 addDelFlag;
    UINT32 radioIdx;
    UINT32 combInfo = 0;
	UINT32 flowId = 0;
	UINT32 combIdx = 0;
    UINT32 iqCombMaxTmp = 0;
	UINT32 iqCombMax[MAX_ANT_NUM]    = {0,};
	UINT32 prachCombMax[MAX_ANT_NUM] = {0,};
	UINT32 prachNoArry[MAX_CELL_COMB_NUM];  /*在子小区里面统计PrachNo*/
		
    INPUT_POINTER_CHECK(pEcpriStreamInfo);
    INPUT_POINTER_CHECK(pEcpriCellFlowInfo);
	
	memset(iqCombMax,0,sizeof(iqCombMax));
	memset(prachCombMax,0,sizeof(prachCombMax));
	memset(prachNoArry,0,sizeof(prachNoArry));
	
    streamNum = pEcpriStreamInfo->streamNum;
    pEcpriCellFlowInfo->cellIndex = pEcpriStreamInfo->cellIndex;
    cellIdx = pEcpriCellFlowInfo->cellIndex;
    
    CHECK_ECPRI_CELL_ID(cellIdx);
    addDelFlag = BspGetCellAddDelFlag(cellIdx);   
        
    if(streamNum > MAX_STREAM_NUM)
    {
    	IC_PRN_ERR("EcpriCfg","%s streamNum beyond falid\n",__FUNCTION__);
        return BSP_ERROR;
    }
	

	radioIdx = BspGetRadioIdxByType(pEcpriStreamInfo->radioMode);
     
    for(idx = 0; idx < streamNum; idx++)
    {
		antNo = pEcpriStreamInfo->streamNo[idx];
        flowId = pEcpriStreamInfo->FlowId[idx];    		 /*传入到实际的flow值，不包括bit7的扩展位*/
        combInfo = pEcpriStreamInfo->combInfo[idx];  
			
		iqAntMask |= (1<<antNo);

        if(flowId < 64) /*iq， 通过flowid来判断是否是iq */
        {
        	/*某个小区的一个天线上的多个载波为合并载波*/
			combIdx = (1 == combInfo) ? (pEcpriStreamInfo->combIdx[idx]):(0);
			CHECK_ECPRI_FLOW_COMB_IDX(combIdx);
			
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].antNo = antNo;            
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].optIdByAnt =  pEcpriStreamInfo->lpOptNo[idx];
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].flowId =  pEcpriStreamInfo->FlowId[idx];
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].msgType = pEcpriStreamInfo->msgType[idx];     
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].radioIdx = radioIdx;
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].combInfo = pEcpriStreamInfo->combInfo[idx];
			if(1 == combInfo) /*合并小区*/
			{
            	pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].locCarrId = pEcpriStreamInfo->combIdx[idx];
			}
			else
			{
				pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].locCarrId = pEcpriStreamInfo->locCarrId[idx];
			}
			
            #if 1
            if (BSP_ERROR == ResMng_LocalCell_BspGetGfCellCarrTdmInfo(dir,OAM_CELL_IF1_TYPE,cellIdx,antNo,combIdx,&tdmChn,&tdmChip,&tdmSeq,&tdmPos))
            {
                IC_PRN_ERR("EcpriCfg","%s get cell[%d] dir[%d] antIdx[%d] iq tdm chn falied\n",__FUNCTION__,cellIdx,dir,antNo);
                return BSP_ERROR;
            }
            #else /*打桩*/
            tdmChn = 3;
            tdmSeq = idx;
            #endif
            
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].tdmChn = tdmChn;
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].tdmSeq = tdmSeq;
            
            if(BSP_ERROR == BspGetRoeOptIdformTdmChn(tdmChn,&optId))
            {
                IC_PRN_ERR("EcpriCfg","%s BspGetRoeOptIdformTdmChn TX falied tdmChn[%d]\n",__FUNCTION__,tdmChn);
                return BSP_ERROR;
            }
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].tdmChnOptPort = optId;
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].addDelFlag = addDelFlag;
                
            pEcpriCellFlowInfo->tCellAntIqFlowInfo[antNo][dir][combIdx].validFlag = 1;

            
			pEcpriCellFlowInfo->antIqMask[dir] |= (1<<antNo);
			
			//iqCombMax[antNo]++;
			if(iqCombMax[antNo] < (combIdx+1))
			{
				iqCombMax[antNo] = combIdx+1;
			}
        }
        else if(RX == dir)/*prach 上行 flowid 从64开始编*/
        {
            /*以频点为维度的时候，prachNo表示4个频点中的索引
              以天线为维度的时候，prachNo表示基带天线号*/
			combIdx = (1 == combInfo) ? (pEcpriStreamInfo->combIdx[idx]):(0);
			CHECK_ECPRI_FLOW_COMB_IDX(combIdx);
			
			prachNo = prachNoArry[combIdx]++;  
			CHECK_ECPRI_ANT_ID(prachNo);
			
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].optIdByAnt =  pEcpriStreamInfo->lpOptNo[idx];
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].flowId =  pEcpriStreamInfo->FlowId[idx];
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].msgType = pEcpriStreamInfo->msgType[idx];
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].radioIdx = radioIdx;
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].locCarrId = pEcpriStreamInfo->locCarrId[idx];
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].combInfo = pEcpriStreamInfo->combInfo[idx];
			if(1 == combInfo) /*合并小区*/
			{
            	pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].locCarrId = pEcpriStreamInfo->combIdx[idx];
			}
			else
			{
				pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].locCarrId = pEcpriStreamInfo->locCarrId[idx];
			}
			
            #if 1
            /*传入prachNo为频点编号*/
            if (BSP_ERROR == ResMng_LocalCell_BspGetPrachGfCellCarrTdmInfo(dir,cellIdx,combIdx,0,prachNo,&tdmChn,&tdmChip,&tdmSeq))
            {
                IC_PRN_ERR("EcpriCfg","%s get cell[%d] dir[%d] freq[%d] prach tdm chn falied\n",__FUNCTION__,cellIdx,dir,prachNo);
                return BSP_ERROR;
            }
            #else
            tdmChn = 4;
            tdmSeq = idx;
            #endif

            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].tdmChn = tdmChn;
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].tdmSeq = tdmSeq;
            
            if(BSP_ERROR == BspGetRoeOptIdformTdmChn(tdmChn,&optId))
            {
                IC_PRN_ERR("EcpriCfg","%s BspGetRoeOptIdformTdmChn RX falied tdmChn[%d]\n",__FUNCTION__,tdmChn);
                return BSP_ERROR;
            }
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].tdmChnOptPort = optId;
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].addDelFlag = addDelFlag;

            
            pEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].validFlag = 1;
			
			prachCombMax[prachNo]++; /*该频点的prach的子载波数统计*/
			
        }
		else
		{
		
			IC_PRN_ERR("EcpriCfg","%s %d %d abnormal falied\n",__FUNCTION__,cellIdx,dir);
			return BSP_ERROR;
		}
       
    }
    for(idx = 0; idx < MAX_ANT_NUM; idx++)
    {
        if(iqCombMaxTmp <= iqCombMax[idx])
        {
            iqCombMaxTmp = iqCombMax[idx];
        }
    }
    pEcpriCellFlowInfo->iqCombNum[dir] = iqCombMaxTmp;

	IC_PRN_INFO("EcpriCfg","%s cell %d dir %d pEcpriCellFlowInfo->iqCombNum = %d\n",__FUNCTION__,cellIdx,dir,pEcpriCellFlowInfo->iqCombNum[dir]);

	if(0 == dir)
	{
		pEcpriCellFlowInfo->prachCombNum = prachCombMax[0];
		IC_PRN_INFO("EcpriCfg","%s cell %d pEcpriCellFlowInfo->prachCombNum = %d\n",__FUNCTION__,cellIdx,pEcpriCellFlowInfo->prachCombNum);
	}
    return BSP_OK;
}
#endif

/*DPDIC4编译修改*/
#if 0
UINT32 BspEcpriCellIqFlowInit(T_EcpriCellFlowInfo *ptEcpriCellFlowInfo,UINT32 dir)
{

    UINT32 ret     = BSP_OK;
    UINT32 antIdx     = 0;
    UINT32 cellIdx = 0;
    UINT32 antNo = 0;
    UINT32 tdmChn = 0;
    UINT32 tdmChip = 0;
    UINT32 tdmSeq = 0;
    UINT32 tdmPos = 0;
    UINT32 iqFlowId = 0;
    UINT32 roeTblIdx = 0;
    UINT8 srcIp[4] ={0};
    UINT8 srcMac[6] ={0};
    UINT8 dstIp[4] ={0};
    UINT8 dstMac[6] ={0};    
    UINT32 elpNo = 0;
    UINT32 addDelFlag = 0;
    UINT32 optId= 0;
    UINT32 roeId = 0;
    UINT32 msgType = 3;
    UINT32 locCarrId = 0;
	UINT32 combInfo = 0;
    UINT32 cidExt = 0;
    UINT32 lenExt = 0;
	UINT32 combNum;
	UINT32 combIdx;
	
    INPUT_POINTER_CHECK(ptEcpriCellFlowInfo);

    dir = dir&0x01;
    cellIdx = ptEcpriCellFlowInfo->cellIndex;
    CHECK_ECPRI_CELL_ID(cellIdx);

    addDelFlag = BspGetCellAddDelFlag(cellIdx);
    /*ROE 按照小区配置保存 */
    for(antIdx = 0; antIdx < MAX_ANT_NUM; antIdx++)
    {
        if (0 != (ptEcpriCellFlowInfo->antIqMask[dir] & BIT_SET(antIdx)))
        {    
			combNum = ptEcpriCellFlowInfo->iqCombNum[dir];
			//CHECK_ECPRI_FLOW_COMB_IDX(combNum);
			if(combNum > MAX_CELL_COMB_NUM)
			{
				dbgInfo("%s flow comb combNum[%d] error\n",__FUNCTION__,combNum);
				return BSP_ERROR;
			}
			for(combIdx = 0;combIdx < combNum; combIdx++)
            {
	            if ((BSP_ERROR == BspGetCellAntRoePort(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&optId)) 
	                || (BSP_ERROR == BspGetCellAntOptPort(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&elpNo)))
	            {
					IC_PRN_ERR("EcpriCfg","%s BspGetCellAntRoePort || BspGetCellAntOptPort failed cellIdx[%d] antIdx[%d] dir[%d] combIdx[%d]\n",
						__FUNCTION__,cellIdx,antIdx,dir,combIdx);
	                return BSP_ERROR;
	            }

	            CHECK_ECPRI_OPT_PORT_ID(elpNo);

	            if (BSP_ERROR == BspGetRoePortIdformOptId(optId,&roeId))
	            {	            
					IC_PRN_ERR("EcpriCfg","%s BspGetRoePortIdformOptId falied optId[%d]\n",__FUNCTION__,optId);
	                return BSP_ERROR;
	            }           
	            
	            CHECK_ROE_PROCESS_UNIT(roeId);

	             /*源MAC和源IP，应该是bootp阶段来设置,默认选择光口0 目的MAC和目的IP，根据光口来查询*/                                    
	            /*打桩通过bootp来获取*/
	            //BspGetEcpriMacIp(srcIp,srcMac);               
	            BspGetEcpriOptLocalMacIp(elpNo,srcIp,srcMac); 
	            BspGetEcpriOptPeerMacIp(elpNo,dstIp,dstMac); 
	             
	            if( (BSP_ERROR == BspGetCellAntFlowId(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&iqFlowId))
	                || ( BSP_ERROR == BspGetCellAntMsgType(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&msgType))
	                ||( BSP_ERROR == BspGetCellAntLenExtLocCarrId(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&locCarrId))
	                ||( BSP_ERROR == BspGetCellAntLenExtCombInfo(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&combInfo))
	                ||( BSP_ERROR == BspGetCellAntCidExt(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&cidExt))
	                )
	                
	            {    
	            
					IC_PRN_ERR("EcpriCfg","%s get iqFlowId|msgType|locCarrId|combInfo|cidExt failed cellIdx[%d] antIdx[%d] dir[%d] combIdx[%d]\n",
						__FUNCTION__,cellIdx,antIdx,dir,combIdx);
	                return BSP_ERROR;
	            }
				
				lenExt = ( combInfo << 3 ) | locCarrId;
	            
	            BspGetCellAntTdmInfo(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&tdmChn,&tdmSeq);     
	            CHECK_ECPRI_TDMCHN_ID(tdmChn);
	            CHECK_QID_ID(tdmSeq);  
	            roeTblIdx = tdmSeq;  
	            BspSetEcpriRoeIpMac(roeId,dir,roeTblIdx,srcMac,srcIp,dstMac,dstIp);
	            
	            /*roe 字段配置*/
	            if(TX == dir) /*下行*/
	            {
	                /*通过查询到的tdmseq，获取到该flow的在roe的表项位置，该表项位置是需要l2ss 将报文替换掉的qid*/
	                //NtlL2ssGetQidFromFlowId(roeId,iqFlowId,&qid);                              
	                
	                /*转换后的qid设置为flowid，demapper去查qid的表,下行的报文的flowid也已经被替换为qid了*/
	                BspSetEcpriRoeFlowPara(roeId,dir,roeTblIdx,roeTblIdx,msgType,lenExt,addDelFlag);

	                IC_PRN_INFO("EcpriCfg","\n\n %s TX cellIdx[%d] antIdx[%d] combIdx[%d] flow[%d] Roe roePort[%d] tdmChn[%d] roeTblIdx[%d]\n",
	                    __FUNCTION__,cellIdx,antIdx,combIdx,iqFlowId,roeId,tdmChn,roeTblIdx);

	                
	            }
	            else /*RX 上行*/
	            {   
	              
	                /*flowId 光口告诉mapper的flowid表项的序号tdmpos,上行要填写报文的真正的flowid*/
	                iqFlowId |= ((cidExt & 0x01) << 7); /*上行配置cid 需要加入扩展*/

	                BspSetEcpriRoeFlowPara(roeId,dir,roeTblIdx,iqFlowId,msgType,lenExt,addDelFlag);
	                
	                IC_PRN_INFO("EcpriCfg","\n\n %s RX cellIdx[%d] antIdx[%d] combIdx[%d] flow[%d] Roe roePort[%d] tdmChn[%d] roeTblIdx[%d]\n",
	                            __FUNCTION__,cellIdx,antIdx,combIdx,iqFlowId,roeId,tdmChn,roeTblIdx);
	            }

	            /*roe配置*/
	            BspInitRoeEcpriChnProperty(roeId);
	            BspSetRoeEcpriFlowPathByDir(roeId,dir,roeTblIdx,1,addDelFlag);           
				
				BspSetEcpriFlowMap(dir,tdmChn-MIN_L2SS_ROE_TDM_ID,tdmSeq,cellIdx,antIdx,combIdx,iqFlowId,1);
			}
            
        }    
    }
    return ret;

}
#endif

/*DPDIC4编译修改*/
#if 0
UINT32 BspEcpriCellPrachFlowInit(T_EcpriCellFlowInfo *ptEcpriCellFlowInfo)
{

    UINT32 ret     = BSP_OK;
    UINT32 prachNo     = 0;
    UINT32 cellIdx = 0;
    UINT32 tdmChn = 0;
    UINT32 tdmChip = 0;
    UINT32 tdmSeq = 0;
    UINT32 roeTblIdx = 0;
    UINT32 tdmPos = 0;
    UINT32 prachFlowId = 0;
    UINT32 msgType = 3;
    UINT8 srcIp[4] ={0};
    UINT8 srcMac[6] ={0};
    UINT8 dstIp[4] ={0};
    UINT8 dstMac[6] ={0};    
    UINT32 elpNo = 0;
    UINT32 addDelFlag = 0;
    UINT32 roeOptId= 0;
    UINT32 roeId = 0;
    UINT32 locCarrId = 0;
    UINT32 cidExt = 0;
    UINT32 lenExt = 0;
	UINT32 combInfo = 0;
	UINT32 combNum = 0;	
	UINT32 combIdx;
	
    INPUT_POINTER_CHECK(ptEcpriCellFlowInfo);
    cellIdx = ptEcpriCellFlowInfo->cellIndex;
    CHECK_ECPRI_CELL_ID(cellIdx);
    
    addDelFlag = BspGetCellAddDelFlag(cellIdx);

	combNum = ptEcpriCellFlowInfo->prachCombNum;
	//CHECK_ECPRI_FLOW_COMB_IDX(combNum);
	if(combNum > MAX_CELL_COMB_NUM)
	{
		dbgInfo("%s flow comb combNum[%d] error\n",__FUNCTION__,combNum);
		return BSP_ERROR;
	}
	for(combIdx = 0; combIdx < combNum; combIdx++)
    {
	    for(prachNo = 0; prachNo < MAX_ANT_NUM; prachNo++)
	    {
	        if (0 != (ptEcpriCellFlowInfo->tCellAntPrachFlowInfo[prachNo][combIdx].validFlag ))
	        {    
	            if ((BSP_ERROR == BspGetCellAntRoePort(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&roeOptId))
	                 || (BSP_ERROR == BspGetCellAntOptPort(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&elpNo)))
	            {
					IC_PRN_ERR("EcpriCfg","%s BspGetCellAntRoePort || BspGetCellAntOptPort failed cellIdx[%d] prachNo[%d] combIdx[%d]\n",
						__FUNCTION__,cellIdx,prachNo,combIdx);

					return BSP_ERROR;
	            }
	                 
	            CHECK_ECPRI_OPT_PORT_ID(elpNo);
	                 
	            if (BSP_ERROR == BspGetRoePortIdformOptId(roeOptId,&roeId))
	            {
					IC_PRN_ERR("EcpriCfg","%s BspGetRoePortIdformOptId falied optId[%d]\n",__FUNCTION__,roeOptId);
	                return BSP_ERROR;
	            }           
	            CHECK_ROE_PROCESS_UNIT(roeId);

	           
	             /*源MAC和源IP，应该是bootp阶段来设置,默认选择光口0 目的MAC和目的IP，根据光口来查询*/                                    
	            /*打桩通过bootp来获取*/
	            //BspGetEcpriMacIp(srcIp,srcMac);   
	            BspGetEcpriOptLocalMacIp(elpNo,srcIp,srcMac); 
	            BspGetEcpriOptPeerMacIp(elpNo,dstIp,dstMac); 
	             
	            if( ( BSP_ERROR == BspGetCellAntFlowId(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&prachFlowId))
	                ||(BSP_ERROR == BspGetCellAntMsgType(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&msgType))
	                ||( BSP_ERROR == BspGetCellAntLenExtLocCarrId(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&locCarrId))
	                ||( BSP_ERROR == BspGetCellAntLenExtCombInfo(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&combInfo))
	                ||( BSP_ERROR == BspGetCellAntCidExt(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&cidExt))
	                )
	            {    
	            
					IC_PRN_ERR("EcpriCfg","%s get iqFlowId|msgType|locCarrId|combInfo|cidExt failed cellIdx[%d] prachNo[%d] combIdx[%d]\n",
						__FUNCTION__,cellIdx,prachNo,combIdx);
	                return BSP_ERROR;
	            }

				lenExt = ( combInfo << 3 ) | locCarrId;

	            BspGetCellAntTdmInfo(E_PRACH_FLOW,cellIdx,prachNo,RX,combIdx,&tdmChn,&tdmSeq);         
	            CHECK_ECPRI_TDMCHN_ID(tdmChn);            
	            CHECK_QID_ID(tdmSeq);    

	            roeTblIdx = tdmSeq;
	            BspSetEcpriRoeIpMac(roeId,RX,roeTblIdx,srcMac,srcIp,dstMac,dstIp);                


	           
	             /*flowId 光口告诉mapper的flowid表项的序号tdmpos,上行要填写报文的真正的flowid*/           
	            prachFlowId |= ((cidExt & 0x01) << 7); /*上行配置cid 需要加入扩展*/
	            BspSetEcpriRoeFlowPara(roeId,RX,roeTblIdx,prachFlowId,msgType,lenExt,addDelFlag);
	            
	            BspInitRoeEcpriChnProperty(roeId);
	            BspSetRoeEcpriFlowPathByDir(roeId,RX,roeTblIdx,1,addDelFlag);   
				
	            BspSetEcpriFlowMap(RX,tdmChn-MIN_L2SS_ROE_TDM_ID,tdmSeq,cellIdx,prachNo,combIdx,prachFlowId,2);
				
	            IC_PRN_INFO("EcpriCfg","\n\n %s RX cellIdx[%d] prachNo[%d] combIdx[%d] flow[%d] Roe roePort[%d] tdmChn[%d] roeTblIdx[%d]\n",
	                                __FUNCTION__,cellIdx,prachNo,combIdx,prachFlowId,roeId,tdmChn,roeTblIdx);
	            
	        }    
	    }
	}
    return ret;

}
#endif



/**********************************************************************
* 函数名称：HalIcConnectRelationInit
* 功能描述：高层配置光口信息接口实现
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
typedef struct
{
	UINT32 cellIndex;
	UINT32 antActiveMask;//激活
	UINT32 optIdByAnt[16]; //本IC的0~15
	UINT32 cellFlowId[16];
	UINT32 pranchFlowId[16];
}T_EcpriCellInfo;

************************************************************************/
UINT32 NtlL2ssEcpriCellInfoInit(UINT32 cellIdx,T_EcpriCellStreamInfo *pEcpriStreamInfo,UINT32 dir)
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 ret     = BSP_OK;
	//UINT32 assertCheck = 0;
    T_EcpriCellFlowInfo *ptEcpriCellFlow = NULL;
        
    INPUT_POINTER_CHECK(pEcpriStreamInfo);    
    dir = dir&0x01;

    /* ======== 保存App下发的EcpriCellStream数据信息, 测试使用 ========= */
//  memcpy(&tNtlEcpriCellStreamInfo, pEcpriStreamInfo, sizeof(T_EcpriCellStreamInfo));
    memcpy_s((VOID *)&tNtlEcpriCellStreamInfo, sizeof(T_EcpriCellStreamInfo), (VOID *)pEcpriStreamInfo, sizeof(T_EcpriCellStreamInfo));
    /* ================================================================= */

    //BspIcHalShowMem((UINT8 *)pEcpriStreamInfo,sizeof(T_EcpriCellStreamInfo));
    //cellIdx = pEcpriStreamInfo->cellIndex;
    CHECK_ECPRI_CELL_ID(cellIdx);

    ptEcpriCellFlow = BspGetEcpriPktInfo(cellIdx);
    INPUT_POINTER_CHECK(ptEcpriCellFlow);    

	//memset(ptEcpriCellFlow,0,sizeof(T_EcpriCellFlowInfo));
	if((1==cellIdx) && (1==dir))
	{
		//assertCheck = 2;
		;
	}
    BspGetCellAntFlowInfo(pEcpriStreamInfo,dir,ptEcpriCellFlow);
    
    if(RX == dir)
    {    
        BspEcpriCellIqFlowInit(ptEcpriCellFlow,RX);
        BspEcpriCellPrachFlowInit(ptEcpriCellFlow);
    }
    else
    {
        BspEcpriCellIqFlowInit(ptEcpriCellFlow,TX);
    }
	
	//PrnEcpriFlowInfo(cellIdx,0);
	return ret;
#endif
    return BSP_OK;
}

// 打印App下发的EcpriCellStream数据信息
UINT32 PrnEcpriCellStreamInfo(VOID)
{
    /*DPDIC4编译修改*/
#if 0
    UINT8 *pucStreamInfoAddr = NULL;

    pucStreamInfoAddr = (UINT8 *)&tNtlEcpriCellStreamInfo;

    BspIcHalShowMem(pucStreamInfoAddr, sizeof(T_EcpriCellStreamInfo));
#endif
	return BSP_OK;
}

/**********************************************************************
* 函数名称：Ntll2ssCfgEcpriIqPathByCellAntIndx
* 功能描述：高层按照小区天线方向进行配置L2SS IQ的ECPRI的通路
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 Ntll2ssCfgEcpriIqPathByCellAntIndx(UINT32 cellIdx,UINT32 antIdx,UINT32 dir,UINT32 combIdx)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 elpNo = 0;
    UINT32 roeOptId = 0;
    UINT32 roeIdx = 0;
    UINT32 srcOptNo = 0;
    UINT32 dstOptNo = 0;
    UINT8  dstMac[6] = {0};
    UINT8  dstIp[4] ={0};
    UINT32 vid = 0;
    UINT32 lvTapIdx = 0;
    UINT32 iqFlowId = 0;
    UINT32 msgType = 3;
    UINT32 ntlWorkMode = 0;
    UINT32 ret = BSP_OK;
    UINT32 addDelFlag = 0;
    UINT32 qid = 0;
    UINT32 hashIdx = 0;
    UINT32 locCarrId = 0;
	UINT32 combInfo = 0;
    UINT32 cidExt = 0;
	UINT32 lenExt = 0;
    UINT32 lpmAddr;
    
    CHECK_ECPRI_CELL_ID(cellIdx);
    CHECK_ECPRI_ANT_ID(antIdx);
    dir = dir&0x01;
    
    /*该小区天线的对应的opt的外端口*/
    if (BSP_ERROR ==  BspGetCellAntOptPort(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&elpNo))
    {
        IC_PRN_ERR("EcpriCfg","%s BspGetCellAntOptPort cellidx[%d] antIdx[%d] dir[%d] combIdx[%d] falied\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx);    
        return BSP_ERROR;
    }

    /*该小区天线的roe的内l2ss端口*/
    if (BSP_ERROR == BspGetCellAntRoePort(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&roeOptId))
    {
        IC_PRN_ERR("EcpriCfg","%s BspGetCellAntRoePort cellidx[%d] antIdx[%d] dir[%d] combIdx[%d] falied\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx);    
        return BSP_ERROR;
    }       
    
    /*该小区天线的iq的flow id*/
    if( BSP_ERROR == BspGetCellAntFlowId(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&iqFlowId))
    {    
        IC_PRN_ERR("EcpriCfg","%s BspGetCellAntIqFlowId cellidx[%d] antIdx[%d] dir[%d] combIdx[%d] falied\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx);
        return BSP_ERROR;
    }    

   
    /*该小区天线的iq的msgType*/
    if( BSP_ERROR == BspGetCellAntMsgType(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&msgType))
    {    
        IC_PRN_ERR("EcpriCfg","%s BspGetCellAntMsgType cellidx[%d] antIdx[%d] dir[%d] combIdx[%d] falied\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx);
        return BSP_ERROR;
    }    


    addDelFlag = BspGetCellAddDelFlag(cellIdx);
    if( ADD_FLAG == addDelFlag)
    {
        if (BSP_ERROR == BspGetRoeIdxFormOptId(roeOptId,&roeIdx))
        {
            IC_PRN_ERR("EcpriCfg","%s BspGetRoeIdxFormOptId get roeOptIdx falied,roeOptId[%d]\n",__FUNCTION__,roeOptId);    
            return BSP_ERROR;
        } 
        IC_PRN_INFO("EcpriCfg","%s add cfg cellIdx[%d] antIdx[%d] dir[%d] combIdx[%d] flowId[%d]\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx,iqFlowId);
        
        BspGetCellAntLenExtLocCarrId(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&locCarrId);
		BspGetCellAntLenExtCombInfo(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&combInfo);
        BspGetCellAntCidExt(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&cidExt);
		
		lenExt = ( combInfo << 3 ) | locCarrId;
        if(TX == dir) /*TX*/
        {             
        #if 0
            BspGetCellAntTdmInfo(E_IQ_FLOW,cellIdx,antIdx,dir,&tdmChn,&tdmSeq);  
            qid = roeIdx * 32 + tdmSeq ; /*一个roe通道可以处里32个flow，qid的分配考虑低5bit 表示flow的编号位置，高表示通道，在L2SS统一编制分配*/
        #endif        
            /*下行分配qid*/
            if(BSP_ERROR == NtlGetL2ssQid(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&qid))
            {
                IC_PRN_ERR("EcpriCfg","%s NtlGetL2ssQid cellidx[%d] antIdx[%d] dir[%d] combIdx[%d] falied\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx);    
                return BSP_ERROR;
            }
            
            /*后续VID要动态分配*/
            //vid = L2SS_ECPRI_ETH_IP_VLAN + (cellIdx * 16 * 2 + antIdx);
            srcOptNo = elpNo;
            dstOptNo = roeOptId;

            /*获取目的MAC和IP*/
            BspGetEcpriOptLocalMacIp(elpNo,&dstIp,&dstMac);
#if 0
            if(0 == elpNo)
            {
                vid = L2SS_ECPRI_DL_VLAN_START + roeIdx; /*内端口编号来确定VLAN*/
                lvTapIdx = NtlL2ssGetEcpriLvTapIdx(TX,roeIdx);
                
            }
            else if(4 == elpNo)
            {
                vid = L2SS_ECPRI_DL_VLAN_START + roeIdx + 4; /*内端口编号来确定VLAN*/
                lvTapIdx = NtlL2ssGetEcpriLvTapIdx(TX,roeIdx + 4);
                
            }
            else
            {                
                printf("%s can not find vlan",__FUNCTION__);
            }
#endif

            NtlL2ssGetEcpriVlanIdInfo(dir,elpNo,roeOptId,&vid,&lvTapIdx);
            
            IC_PRN_INFO("EcpriCfg","dstMacAddr is %2x-%2x-%2x-%2x-%2x-%2x\n",dstMac[0],dstMac[1],dstMac[2],dstMac[3],dstMac[4],dstMac[5]);
            IC_PRN_INFO("EcpriCfg","vid[%d] srcOptNo[%d] dstOptNo[%d] iqflowId[%d]\n",vid,srcOptNo,dstOptNo,iqFlowId);

            ret = NtlL2ssInitDlIqEcpriFlow(vid,lvTapIdx,srcOptNo,dstMac,dstOptNo,iqFlowId,msgType,qid,lenExt,cidExt,&lpmAddr);

        }
        else /*RX */
        {
           /*上行分配qid*/
            if(BSP_ERROR == NtlGetL2ssQid(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,&qid))
            {
                IC_PRN_ERR("EcpriCfg","%s NtlGetL2ssQid cellidx[%d] antIdx[%d] dir[%d] combIdx[%d] falied\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx);    
                return BSP_ERROR;
            }
            
            srcOptNo = roeOptId;
            dstOptNo = elpNo; 
            
            /*获取目的MAC和IP*/
            BspGetEcpriOptPeerMacIp(elpNo,&dstIp,&dstMac);
#if 0
            if(0 == elpNo)
            {
                vid = L2SS_ECPRI_UL_VLAN_START + roeIdx; /*内端口编号来确定VLAN*/
                lvTapIdx = NtlL2ssGetEcpriLvTapIdx(RX,roeIdx);
            }
            else if(4 == elpNo)
            {
                vid = L2SS_ECPRI_UL_VLAN_START + roeIdx + 4; /*内端口编号来确定VLAN*/
                lvTapIdx = NtlL2ssGetEcpriLvTapIdx(RX,roeIdx + 4);
            }
            else
            {                
                printf("%s can not find vlan",__FUNCTION__);
            }
#endif     

            NtlL2ssGetEcpriVlanIdInfo(dir,elpNo,roeOptId,&vid,&lvTapIdx);

            IC_PRN_INFO("EcpriCfg","dstMacAddr is %2x-%2x-%2x-%2x-%2x-%2x\n",dstMac[0],dstMac[1],dstMac[2],dstMac[3],dstMac[4],dstMac[5]);           
            IC_PRN_INFO("EcpriCfg","vid[%d] srcOptNo[%d] dstOptNo[%d] iqflowId[%d]\n",vid,srcOptNo,dstOptNo,iqFlowId);

            if(BSP_OK == NtlL2ssGetUlPhyPortbyFlow(E_IQ_FLOW,cellIdx,antIdx,iqFlowId,combIdx,&hashIdx))
        	{
				IC_PRN_INFO("EcpriCfg","%s cell[%d] rx ant[%d] combIdx[%d] flow[%d] hashIdx[%d]\n",__FUNCTION__,cellIdx,antIdx,combIdx,iqFlowId,hashIdx);
        	}
			else
			{
				IC_PRN_ERR("EcpriCfg","%s cell[%d] rx ant[%d] combIdx[%d] flow[%d] failed\n",__FUNCTION__,cellIdx,antIdx,combIdx,iqFlowId);
			}
            ret = NtlL2ssInitUlIqEcpriFlow(vid,lvTapIdx,srcOptNo,dstMac,dstOptNo,iqFlowId,msgType,qid,lenExt,cidExt,hashIdx,&lpmAddr);      

        }

		
        if(ret == BSP_OK)
        {
            /*保存当前的vlan*/
			IC_PRN_INFO("EcpriCfg","BspSetCellAntL2ssInfo vid=%d\n",vid);
            BspSetCellAntL2ssInfo(E_IQ_FLOW,cellIdx,antIdx,dir,combIdx,vid,qid,hashIdx,lpmAddr);
        }
        else
        {
            IC_PRN_ERR("EcpriCfg","%s create cellIdx[%d] antIdx[%d] dir[%d] combIdx[%d] vlan[%d] failed\n",__FUNCTION__,cellIdx,antIdx,dir,combIdx,vid);
        }
    }
    else if ( DEL_FLAG == addDelFlag )
    {
    
        IC_PRN_INFO("EcpriCfg","%s del cfg\n",__FUNCTION__);
        /*删除*/
    }

    return ret;
#endif
    return BSP_OK;
}

/**********************************************************************
* 函数名称：Ntll2ssCfgEcpriPrachPathByCellAntIndx
* 功能描述：高层按照小区天线方向进行配置L2SS IQ的ECPRI的通路
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 Ntll2ssCfgEcpriPrachPathByCellAntIndx(UINT32 cellIdx,UINT32 prachidx,UINT32 combIdx)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 elpNo = 0;
    UINT32 roeOptId = 0;
    UINT32 srcOptNo = 0;
    UINT32 dstOptNo = 0;
    UINT8  dstMac[6] = {0};
    UINT8  dstIp[4] ={0};
    UINT32 vid = 0;
    UINT32 lvTapIdx = 0;
    UINT32 prachFlowId = 0;
    UINT32 msgType = 3;
    UINT32 ntlWorkMode = 0;
    UINT32 ret = BSP_OK;
    UINT32 addDelFlag = 0;
    UINT32 roeIdx = 0;
    UINT32 qid = 0;
    UINT32 hashIdx = 0;
    UINT32 lenExt = 0;
	UINT32 locCarrId = 0;
	UINT32 combInfo = 0;
    UINT32 cidExt;
    UINT32 lpmAddr;
    UINT32 temp = 0;
	
    CHECK_ECPRI_CELL_ID(cellIdx);
    
    /*该小区天线的对应的opt的外逻辑端口*/
    BspGetCellAntOptPort(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&elpNo);

    /*该小区天线的roe的内端口*/
    temp = BspGetCellAntRoePort(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&roeOptId);
    dbgInfoEx("%s[%d] temp:%#x\n", __FUNCTION__, __LINE__, temp);

    BspGetRoeIdxFormOptId(roeOptId,&roeIdx);             

    /*该小区天线的prach的flow id*/
    BspGetCellAntFlowId(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&prachFlowId);

    /*该小区天线的iq的msgType*/
    BspGetCellAntMsgType(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&msgType);
    
    addDelFlag = BspGetCellAddDelFlag(cellIdx);
    if( ADD_FLAG == addDelFlag)
    {
        /*上行分配qid*/
        if(BSP_ERROR == NtlGetL2ssQid(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&qid))
        {
            IC_PRN_ERR("EcpriCfg","%s NtlGetL2ssQid cellidx[%d] prachidx[%d] combIdx[%d] falied\n",__FUNCTION__,cellIdx,prachidx,combIdx);    
            return BSP_ERROR;
        }
		
		BspGetCellAntLenExtLocCarrId(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&locCarrId);
		BspGetCellAntLenExtCombInfo(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&combInfo);
        BspGetCellAntCidExt(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,&cidExt);
		
		lenExt = ( combInfo << 3 ) | locCarrId;
        
        IC_PRN_INFO("EcpriCfg","%s add cfg cellIdx[%d] prachidx[%d] dir[%d] combIdx[%d]\n",__FUNCTION__,cellIdx,prachidx,RX,combIdx);          
        
        //vid = L2SS_ECPRI_UL_VLAN_START + 64 + prachidx;
        srcOptNo = roeOptId;
        dstOptNo = elpNo;           
        BspGetEcpriOptPeerMacIp(elpNo,&dstIp,&dstMac);
        
        IC_PRN_INFO("EcpriCfg","dstMacAddr is %2x-%2x-%2x-%2x-%2x-%2x\n",dstMac[0],dstMac[1],dstMac[2],dstMac[3],dstMac[4],dstMac[5]);           
        IC_PRN_INFO("EcpriCfg","vid[%d] srcOptNo[%d] dstOptNo[%d] prachFlowId[%d]\n",vid,srcOptNo,dstOptNo,prachFlowId);                 
#if 0
        if(0 == elpNo)
        {
            vid = L2SS_ECPRI_UL_VLAN_START + roeIdx; /*内端口编号来确定VLAN*/
            lvTapIdx = NtlL2ssGetEcpriLvTapIdx(RX,roeIdx);
            
        }
        else if(4 == elpNo)
        {
            vid = L2SS_ECPRI_UL_VLAN_START + roeIdx + 4; /*内端口编号来确定VLAN*/
            lvTapIdx = NtlL2ssGetEcpriLvTapIdx(RX,roeIdx + 4);
        }
        else
        {
            printf("%s can not find vlan",__FUNCTION__);
        }
#endif            
        NtlL2ssGetEcpriVlanIdInfo(RX,elpNo,roeOptId,&vid,&lvTapIdx);
		if(0 == vid)
		{
			IC_PRN_INFO("EcpriCfg","vid =0\n");
		}
        NtlL2ssGetEcpriVlanIdInfo(RX,elpNo,roeOptId,&vid,&lvTapIdx);
		
        if(BSP_OK == NtlL2ssGetUlPhyPortbyFlow(E_PRACH_FLOW,cellIdx,prachidx,prachFlowId,combIdx,&hashIdx))
		{
			IC_PRN_INFO("EcpriCfg","%s cell[%d] rx prachidx[%d] combIdx[%d] prachFlowId[%d] hashIdx[%d]\n",__FUNCTION__,cellIdx,prachidx,combIdx,prachFlowId,hashIdx);
		}
		else
		{
			IC_PRN_ERR("EcpriCfg","%s cell[%d] rx prachidx[%d] combIdx[%d] prachFlowId[%d] failed\n",__FUNCTION__,cellIdx,prachidx,combIdx,prachFlowId);
		}   
		
        ret = NtlL2ssInitUlIqEcpriFlow(vid,lvTapIdx,srcOptNo,dstMac,dstOptNo,prachFlowId,msgType,qid,lenExt,cidExt,hashIdx,&lpmAddr);      
        if(ret == BSP_OK)
        {
            /*保存当前的vlan*/                  
            BspSetCellAntL2ssInfo(E_PRACH_FLOW,cellIdx,prachidx,RX,combIdx,vid,qid,hashIdx,lpmAddr);
        }
		else
        {
            IC_PRN_ERR("EcpriCfg","%s create cellIdx[%d] prachidx[%d] combIdx[%d] vlan[%d] failed\n",__FUNCTION__,cellIdx,prachidx,combIdx,vid);
        }
    }
    else if ( DEL_FLAG == addDelFlag )
    {        
        IC_PRN_INFO("EcpriCfg","%s del cfg\n",__FUNCTION__);
        /*删除*/
    }
    return ret;
#endif
    return BSP_OK;
}

/**********************************************************************
* 函数名称：BspSetEcpriPathByCellIndx
* 功能描述：高层按照小区配置ecpri通路,给高层提供的接口
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 NtlL2ssSetEcpriPathByCellIndx(UINT32 cellIdx)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 antIdx;
	UINT32 prachidx;
    UINT32 ret = 0;
    UINT32 dir = 0;
    UINT32 flag = 0;
    UINT32 combInfoNum = 0;
	UINT32 combIdx = 0;
	
    CHECK_ECPRI_CELL_ID(cellIdx);

    /*IQ配置*/
   
    for(antIdx = 0; antIdx < MAX_ANT_NUM; antIdx++)
    {
    	combInfoNum = BspGetCellCombInfoNum(E_IQ_FLOW,cellIdx,TX);
		for(combIdx=0; combIdx<combInfoNum; combIdx++)
        {
	        flag = BspGetCellAntCfgValidFlag(E_IQ_FLOW,cellIdx,antIdx,TX,combIdx);
	        if( 1 == flag )
	        {
	            ret |= Ntll2ssCfgEcpriIqPathByCellAntIndx(cellIdx,antIdx,TX,combIdx);
	        }
		}
    }

    for(antIdx = 0; antIdx < MAX_ANT_NUM; antIdx++)
    {
    
	   combInfoNum = BspGetCellCombInfoNum(E_IQ_FLOW,cellIdx,RX);
	   for(combIdx=0; combIdx<combInfoNum; combIdx++)
	   {
	       flag = BspGetCellAntCfgValidFlag(E_IQ_FLOW,cellIdx,antIdx,RX,combIdx);
	       if( 1 == flag )
	       {
	           ret |= Ntll2ssCfgEcpriIqPathByCellAntIndx(cellIdx,antIdx,RX,combIdx);
	       }
	   }
    }

	combInfoNum = BspGetCellCombInfoNum(E_PRACH_FLOW,cellIdx,RX);
	for(combIdx=0; combIdx<combInfoNum; combIdx++)
	{
		for(prachidx = 0; prachidx < MAX_ANT_NUM; prachidx++)
		{
			flag = BspGetCellAntCfgValidFlag(E_PRACH_FLOW,cellIdx,prachidx,combIdx,RX);
			if( 1 == flag )
			{
			   ret |= Ntll2ssCfgEcpriPrachPathByCellAntIndx(cellIdx,prachidx,combIdx);
			}
		}
	}
    return ret;
#endif
    return BSP_OK;
}

/**********************************************************************
* 函数名称：NtlL2ssCfgIqEcpriPath
* 功能描述：查询所有小区填写和光口的表项进行配置
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/
UINT32 NtlL2ssCfgL2ssEcpriPath()
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 cellIdx;
    UINT32 antIdx;
    UINT32 ret = 0;
    UINT32 dir = 0;
    
    for(cellIdx = 0; cellIdx < MAX_CELL_NUM; cellIdx++)
    {
        NtlL2ssSetEcpriPathByCellIndx(cellIdx);
    }
    
    return BSP_OK;
#endif
    return BSP_OK;
}

UINT32 NtlL2ssSetEcpriPathCtrl(UINT32 ctrl)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 antIdx;
    UINT32 ret = 0;
    UINT32 dir = 0;
    UINT32 port = 0;
    UINT32 cellIdx = 0;
    UINT32 flag = 0;
	UINT32 combInfoNum;
	UINT32 combIdx;
	UINT32 pport;
	UINT32 lport;
	
	/*关闭8个端口*/
	/*
	for(pport = 0; pport < 8; pport++) //远程硬复位修改2020.04.03
	{
		NtlXmacDisable(pport);
        NtlL2ssTrxpDisable(pport);
	}*/
	
    for(cellIdx = 0; cellIdx < MAX_CELL_NUM; cellIdx++ )
    {
        for(antIdx = 0; antIdx < MAX_ANT_NUM; antIdx++)
        {
            combInfoNum = BspGetCellCombInfoNum(E_IQ_FLOW,cellIdx,dir);
            for(combIdx=0; combIdx<combInfoNum; combIdx++)
            {
                if(BSP_ERROR == BspGetCellAntOptPort(E_IQ_FLOW,cellIdx,antIdx,0,combIdx,&lport))
                {
                    dbgInfo("BspGetCellAntOptPort iq cellIdx[%d] antIdx[%d] dir[%d] combIdx[%d] get failed\n",cellIdx,antIdx,dir,combIdx);
                    optCtrlLog(LOG_INFO,"[NtlL2ssSetEcpriPathCtrl] iq cellIdx[%d] antIdx[%d] dir[%d] combIdx[%d] get failed\n",cellIdx,antIdx,dir,combIdx);
                    continue;
                }
                for(pport = lport; pport < (lport + 4); pport++)
                {
                    ret |= NtlXmacEnable(pport);
                    ret |= NtlL2ssTrxpEnable(pport);
                    IC_PRN_INFO("EcpriCfg","lport: %d, xmac iq port[%d] en succ\n",lport, pport);
                }
                
            }
        }
    }
	
    /*暂时端口先都打开，后续再关联变量*/
#if 0
    for(port = 0; port < 8; port++ )
    {
        NtlXmacEnable(port);
        NtlL2ssTrxpEnable(port);
    }

#endif
    NtlL2ssTrxpEnable(34);
    NtlL2ssTrxpEnable(36);
    NtlL2ssTrxpEnable(38);
    NtlL2ssTrxpEnable(40);

    optCtrlLog(LOG_INFO,"[%s]ctrl %d, FuncEnd\n",__FUNCTION__, ctrl);
    return ret;
#endif
    return BSP_OK;
}

/**********************************************************************
* 函数名称：NtlL2ssSetEcpriPathEn
* 功能描述：开启对应的所有端口
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/

UINT32 NtlL2ssSetEcpriPathEn()
{
    return NtlL2ssSetEcpriPathCtrl(1);
}

/**********************************************************************
* 函数名称：NtlL2ssCfgIqEcpriPath
* 功能描述：关闭对应的所有端口
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
************************************************************************/

UINT32 NtlL2ssSetEcpriPathDisEn()
{
    return NtlL2ssSetEcpriPathCtrl(0);
}
#if 0
UINT32 tstOptEcpriSet()
{
    T_EcpriCellStreamInfo tPara = {0};

    tPara.cellIndex = 0;
    tPara.streamNum = 4;
    
    tPara.streamNo[0] = 0;
    tPara.streamNo[1] = 1;
    tPara.streamNo[2] = 2;
    tPara.streamNo[3] = 3;

    tPara.FlowId[0] = 0;
    tPara.FlowId[1] = 1;
    tPara.FlowId[2] = 2;
    tPara.FlowId[3] = 3;

    tPara.msgType[0] = 3;
    tPara.msgType[1] = 3;
    tPara.msgType[2] = 3;
    tPara.msgType[3] = 3;

    tPara.lpOptNo[0] = 0;
    tPara.lpOptNo[1] = 0;
    tPara.lpOptNo[2] = 0;
    tPara.lpOptNo[3] = 0;
   
    BspOptEcpriCellInfoInit(&tPara,TX);

    tPara.cellIndex = 0;
    tPara.streamNum = 3;
    
    tPara.streamNo[0] = 0;
    tPara.streamNo[1] = 1;
    tPara.streamNo[2] = 16; /*prach*/
  
    tPara.FlowId[0] = 0;
    tPara.FlowId[1] = 1;
    tPara.FlowId[2] = 2; /*prach*/

    tPara.msgType[0] = 0;
    tPara.msgType[1] = 0;
    tPara.msgType[2] = 3; /*prach*/
    
    tPara.lpOptNo[0] = 0;
    tPara.lpOptNo[1] = 0;
    tPara.lpOptNo[2] = 0; /*prach*/

    BspOptEcpriCellInfoInit(&tPara,RX);   
   
    return BSP_OK;
}
#endif
UINT32 cfgOptEcpri(UINT32 cellId)
{
    /*DPDIC4编译修改*/
#if 0
    T_EcpriCellStreamInfo tPara = {0};
	UINT32 ant;


	HalIcCellTakePosId(cellId);

    tPara.cellIndex = cellId;
    tPara.radioMode = BSP_RADIO_STANDARD_5G;
    tPara.streamNum = 16; /*一个小区4个flow，共64个flow*/
    for(ant=0;ant<16;ant++)
    {
	    tPara.streamNo[ant] = (UINT8)ant; /*antno*/
	    tPara.FlowId[ant] = ant + 16 * (HalIcPadGetChipId()%4);        
	    tPara.msgType[ant] = 3;
	    tPara.lpOptNo[ant] = 0;  
		tPara.combInfo[ant] = 0;
		tPara.locCarrId[ant] = 0; 
		tPara.combIdx[ant] = 0;
    } 
  
    BspOptEcpriCellInfoInit(&tPara,TX);

    tPara.cellIndex = cellId;
    tPara.radioMode = BSP_RADIO_STANDARD_5G;
    tPara.streamNum = 17; /*一个小区4个flow，共64个flow*/
    for(ant=0;ant<16;ant++)
    {
	    tPara.streamNo[ant] = (UINT8)ant; /*antno*/
	    tPara.FlowId[ant] = ant + 16 * (HalIcPadGetChipId()%4);        
	    tPara.msgType[ant] = 3;
	    tPara.lpOptNo[ant] = 0;  
		tPara.combInfo[ant] = 0;
		tPara.locCarrId[ant] = 0; 
		tPara.combIdx[ant] = 0;
    }

	/*parch*/
	tPara.streamNo[16] = (UINT8)ant; 
	tPara.FlowId[16] = 64 + 16 * (HalIcPadGetChipId()%4); 	   
	tPara.msgType[16] = 3;
	tPara.lpOptNo[16] = 0;  
	tPara.combInfo[16] = 0;
	tPara.locCarrId[16] = 0; 
	tPara.combIdx[16] = 0;
	
    BspOptEcpriCellInfoInit(&tPara,RX);   
#endif
    return BSP_OK;
}



UINT32 cfgOptEcpri_NR_Comb(UINT32 cellIdx, UINT32 uTest)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 ant = 0;
	UINT32 combFlowIdx = 0; 
	UINT8 idx;
    T_EcpriCellStreamInfo tPara = {0};

    /*cell nr tx */
    tPara.cellIndex = cellIdx;
    tPara.radioMode = BSP_RADIO_STANDARD_5G;
    tPara.streamNum = 64; /*一个小区4个flow，共64个flow*/
    for(ant=0;ant<16;ant++)
    {
    	for(combFlowIdx=0;combFlowIdx<MAX_CELL_DL_COMB_NUM;combFlowIdx++)
        {
        	idx = ant*MAX_CELL_DL_COMB_NUM + combFlowIdx;
	        tPara.streamNo[idx] = idx; /*antno*/
	        tPara.FlowId[idx] = ant + 16 * (HalIcPadGetChipId()%4);        
	        tPara.msgType[idx] = 3;
	        tPara.lpOptNo[idx] = 0;  
			tPara.combInfo[idx] = 1;
			tPara.locCarrId[idx] = combFlowIdx; /*0,1,2,3*/
			
			tPara.carrAnt[idx] = ant; 	   
    	}
    }
    
    BspOptEcpriCellInfoInit(&tPara,TX);

    /*cell nr rx */
    tPara.cellIndex = cellIdx;
    tPara.streamNum = 49 + uTest;              /*16 + test 个 prach*/
    tPara.radioMode = BSP_RADIO_STANDARD_5G;    

    for(ant=0;ant<16;ant++)
    {
    	for(combFlowIdx=0;combFlowIdx<MAX_CELL_UL_COMB_NUM;combFlowIdx++)
        {
        	idx = ant*MAX_CELL_UL_COMB_NUM + combFlowIdx;
	        tPara.streamNo[idx] = idx; /*antno*/
	        tPara.FlowId[idx] = ant + 16 * (HalIcPadGetChipId()%4);        
	        tPara.msgType[idx] = 3;
	        tPara.lpOptNo[idx] = 0;  
			tPara.combInfo[idx] = 1;
			tPara.locCarrId[idx] = combFlowIdx; /*0,1,2*/
    	}
    }

    tPara.streamNo[48] = 48; /*antno*/
    tPara.FlowId[48] = 64 + HalIcPadGetChipId()%4;
    tPara.msgType[48] = 3;
    tPara.lpOptNo[48] = 0;
	tPara.combInfo[48] = 0;
	tPara.locCarrId[48] = cellIdx; /*comb =0 的打桩为 cellidx*/
	
    tPara.streamNo[49] = 49; /*antno*/
    tPara.FlowId[49] = 96 + HalIcPadGetChipId()%4 ;
    tPara.msgType[49] = 3;
    tPara.lpOptNo[49] = 0;
	tPara.combInfo[48] = 0;
	tPara.locCarrId[48] = cellIdx; /*comb =0 的打桩为 cellidx*/
	
    BspOptEcpriCellInfoInit(&tPara,RX);   
#endif
    return BSP_OK;
}

UINT32 cfgOptEcpri_NR(UINT32 cellIdx, UINT32 uTest)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 idx = 0;
    T_EcpriCellStreamInfo tPara = {0};

    /*cell nr tx */
    tPara.cellIndex = cellIdx;
    tPara.radioMode = BSP_RADIO_STANDARD_5G;
    tPara.streamNum = 16;
    for(idx=0;idx<16;idx++)
    {
        tPara.streamNo[idx] = idx; /*antno*/
        tPara.FlowId[idx] = idx + 16 * (HalIcPadGetChipId()%4);          
        tPara.msgType[idx] = 3;
        tPara.lpOptNo[idx] = 0; 
		tPara.combInfo[idx] = 0;
		tPara.locCarrId[idx] = cellIdx; /*comb =0 的打桩为 cellidx*/
		
    }
    
    BspOptEcpriCellInfoInit(&tPara,TX);

    /*cell nr rx */
    tPara.cellIndex = cellIdx;
    tPara.streamNum = 17 + uTest; /*16 + 1 prach*/
    tPara.radioMode = BSP_RADIO_STANDARD_5G;    

    for(idx=0;idx<16;idx++)
    {
        tPara.streamNo[idx] = idx; /*antno*/
        tPara.FlowId[idx] = idx + 16 * (HalIcPadGetChipId()%4);           
        tPara.msgType[idx] = 3;
        tPara.lpOptNo[idx] = 0;   
		tPara.combInfo[idx] = 0;
		tPara.locCarrId[idx] = cellIdx; /*comb =0 的打桩为 cellidx*/
    }

    tPara.streamNo[16] = 16; /*antno*/
    tPara.FlowId[16] = 64 + HalIcPadGetChipId()%4;
    tPara.msgType[16] = 3;
    tPara.lpOptNo[16] = 0;
	tPara.combInfo[idx] = 0;
	tPara.locCarrId[idx] = cellIdx; /*comb =0 的打桩为 cellidx*/
	
    
    tPara.streamNo[17] = 17; /*antno*/
    tPara.FlowId[17] = 96 + HalIcPadGetChipId()%4 ;
    tPara.msgType[17] = 3;
    tPara.lpOptNo[17] = 0;
	tPara.combInfo[idx] = 0;
	tPara.locCarrId[idx] = cellIdx; /*comb =0 的打桩为 cellidx*/
	
    BspOptEcpriCellInfoInit(&tPara,RX);   
#endif
    return BSP_OK;
}


/*cellIdx从1开始*/
UINT32 cfgOptEcpri_LTE(UINT32 cellIdx)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 idx = 0;
    T_EcpriCellStreamInfo tPara = {0};

    /*cell nr tx */
    tPara.cellIndex = cellIdx;
    tPara.radioMode = BSP_RADIO_STANDARD_LTE_TDD;
    tPara.streamNum = 16;
    for(idx=0;idx<16;idx++)
    {
        tPara.streamNo[idx] = idx; /*antno*/
        tPara.FlowId[idx] = idx + 16 * (HalIcPadGetChipId()%4);        
        tPara.msgType[idx] = 3;
        tPara.lpOptNo[idx] = 4;   
		tPara.combInfo[idx] = 0;
		tPara.locCarrId[idx] = cellIdx; /*comb =0 的打桩为 cellidx*/
    }
    
    BspOptEcpriCellInfoInit(&tPara,TX);

    /*cell nr rx */
    tPara.cellIndex = cellIdx;
    tPara.radioMode = BSP_RADIO_STANDARD_LTE_TDD;
    tPara.streamNum = 17; /*16 + 1 prach*/
    for(idx=0;idx<16;idx++)
    {
        tPara.streamNo[idx] = idx; /*antno*/
        tPara.FlowId[idx] = idx + 16 * (HalIcPadGetChipId()%4);       
        tPara.msgType[idx] = 3;
        tPara.lpOptNo[idx] = 4;    
		tPara.combInfo[idx] = 0;
		tPara.locCarrId[idx] = cellIdx; /*comb =0 的打桩为 cellidx*/
    }

    tPara.streamNo[16] = 16; /*antno*/
    tPara.FlowId[16] = 64 + cellIdx;        
    tPara.msgType[16] = 3;
    tPara.lpOptNo[16] = 4;
	tPara.combInfo[idx] = 0;
	tPara.locCarrId[idx] = cellIdx; /*comb =0 的打桩为 cellidx*/
	
    BspOptEcpriCellInfoInit(&tPara,RX);   
#endif
    return BSP_OK;
}




void optMacbsp(UINT32 logicOpt, UINT32 uTestFlag)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 idx   = 0;
    UINT32 uIcId = 0;
    T_OptConnectRelation tTemp = {0,};

    BYTE localMac[4][6]={
    		{0x40, 0x00, 0xc3,0x21,0x1F,0x01},
			{0x40, 0x00, 0xc3,0x21,0x1F,0x05},
			{0x40, 0x00, 0xc3,0x21,0x1F,0x09},
			{0x40, 0x00, 0xc3,0x21,0x1F,0x0d},
    };
    BYTE peerMac[4][6]={
    		{0x40, 0x00, 0xc3,0x21,0x20,0x01},
			{0x40, 0x00, 0xc3,0x21,0x20,0x05},
			{0x40, 0x00, 0xc3,0x21,0x20,0x09},
			{0x40, 0x00, 0xc3,0x21,0x20,0x0d},
    };

    BYTE localIP[4][4] = {
    		{0xc3,0x21,0x1F,0x01},
			{0xc3,0x21,0x1F,0x05},
    		{0xc3,0x21,0x1F,0x09},
			{0xc3,0x21,0x1F,0x0d},
    };    //195.33.31.1
    BYTE peerIP[4][4]={
    		{0xc3,0x21,0x20,0x01},
			{0xc3,0x21,0x20,0x05},
			{0xc3,0x21,0x20,0x09},
			{0xc3,0x21,0x20,0x0d},
    };       //195.33.32.1

    memset(&tTemp,0,sizeof(T_OptConnectRelation));
    uIcId = HalIcPadGetChipId()%4;
/*逻辑端口的MAC,IP,加框槽和逻辑端口号 */
    tTemp.peerOptInfo.logicOptId = logicOpt;
    tTemp.peerOptInfo.ShelfNo = 1;
    tTemp.peerOptInfo.uRackNo = 2;
    tTemp.peerOptInfo.slotNo = 3;
    tTemp.peerOptInfo.phyOptBitMap = 0xf;

    
    tTemp.localOptInfo.logicOptId = logicOpt;
    tTemp.localOptInfo.ShelfNo = 2;
    tTemp.localOptInfo.uRackNo = 3;
    tTemp.localOptInfo.slotNo = 4;
    tTemp.localOptInfo.phyOptBitMap = 0xf;
    
    if(1 == uTestFlag)
    {
        memmove(&(tTemp.peerMac),peerMac[uIcId],sizeof(peerMac[uIcId]));
        memmove(&(tTemp.localMac),localMac[uIcId],sizeof(peerMac[uIcId]));
        memmove(&(tTemp.peerIp),peerIP[uIcId],sizeof(peerIP[uIcId]));
        memmove(&(tTemp.localIp),localIP[uIcId],sizeof(localIP[uIcId]));
    }
    else
    {
        memmove(&(tTemp.localMac),peerMac[uIcId],sizeof(peerMac[uIcId]));
        memmove(&(tTemp.peerMac),localMac[uIcId],sizeof(peerMac[uIcId]));
        memmove(&(tTemp.localIp),peerIP[uIcId],sizeof(peerIP[uIcId]));
        memmove(&(tTemp.peerIp),localIP[uIcId],sizeof(localIP[uIcId]));
    }

    tTemp.optTransSpeed = 3; //25G from bsp macro
    tTemp.optTransProtocal = 1;//from bsp
    tTemp.flag = 1;//1=valid；
    
    //bspFUN  
    BspOptConnectRelationInit(&tTemp);
#endif
}


/*DPDIC4编译修改*/
#if 0
T_NtlCwChnCfg g_NtlCwChnCfg[MAX_ROE_CW_TX_RX_CHN_NUM] = {0}; /**/
#endif
#if 0
/*********单板下给平台传递ecpri CW业务的通道参数*************/
UINT32 BspSetEcpriCwChnCfg(T_NtlCwChnCfg *ptNtlCwChnCfg,UINT32 num)
{
    /*DPDIC4编译修改*/

	UINT32 idx;
	INPUT_POINTER_CHECK(ptNtlCwChnCfg);

	if(num > MAX_ROE_CW_TX_RX_CHN_NUM)
	{
		printf("%s failed num[%d]\n",__FUNCTION__,num);
		return BSP_ERROR;
	}
	memset(g_NtlCwChnCfg,0,sizeof(g_NtlCwChnCfg));
	
	for(idx=0;idx<num;idx++)
	{
		memcpy(&(g_NtlCwChnCfg[idx]),&(ptNtlCwChnCfg[idx]),sizeof(T_NtlCwChnCfg));
	}

	return BSP_OK;
}

/*********通过CW业务类型获取CW的通道参数*************/
UINT32 BspGetCwChnCfgByCwType(UINT32 cwType,T_NtlCwChnCfg *ptNtlCwChnCfg,UINT32 *pNum)
{
    /*DPDIC4编译修改*/

	UINT32 idx;
	UINT32 idx1 = 0;
	
	INPUT_POINTER_CHECK(ptNtlCwChnCfg);
	INPUT_POINTER_CHECK(pNum);
	
	for(idx=0;idx<NELEMENTS(g_NtlCwChnCfg);idx++)
	
{
		if((cwType == g_NtlCwChnCfg[idx].chnTpe) && (1 == g_NtlCwChnCfg[idx].chnVaild) )
		{
			memcpy(&(ptNtlCwChnCfg[idx1]),&g_NtlCwChnCfg[idx],sizeof(T_NtlCwChnCfg));
			idx1++;
		}
	}
	
	if(0 == idx1)
	{
		return BSP_ERROR;
	}
	else
	{
		*pNum = idx1;
		return OK;
	}

    return BSP_OK;
}
#endif
/********根据方向，来获取cw空闲的通道*************/
UINT32 BspGetCwChnFreeCfgIdxByCwKey(UINT32 cwDir,UINT32 *pIdx)
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 idx;

	INPUT_POINTER_CHECK(pIdx);

	for(idx = 0;idx < NELEMENTS(g_NtlCwChnCfg);idx++)

	{
		if((0 == g_NtlCwChnCfg[idx].chnVaild) && (cwDir == g_NtlCwChnCfg[idx].chnDir))
		{
			break;
		}
	}

	if(idx >= NELEMENTS(g_NtlCwChnCfg))
	{
		*pIdx = 0;
		return BSP_ERROR;
	}
	else
	{
		*pIdx = idx;
		return OK;
	}
#endif
    return BSP_OK;
}


UINT32 BspSetCwChnHiPowCfg(UINT32 optLgNo,UINT32 flowId)
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 idx;
	UINT32 cwIdx = 0;

	if(BSP_OK != BspGetCwChnFreeCfgIdxByCwKey(RX,&cwIdx))
	{
		printf("%s no free space failed\n", __FUNCTION__);
		return BSP_ERROR;
	}

	g_NtlCwChnCfg[cwIdx].chnTpe = CW_CHN_HI_POW_TYPE;
	g_NtlCwChnCfg[cwIdx].chnExtLp = optLgNo;
	g_NtlCwChnCfg[cwIdx].chnFlowId = flowId;
	g_NtlCwChnCfg[cwIdx].chnVaild = 1;
	return BSP_OK;
#endif
    return BSP_OK;
}

UINT32 showcwcfg()
{
    /*DPDIC4编译修改*/
#if 0
    UINT8 outPutValStr[100] = {0,};
	UINT32 idx = 0;
    int snpRet = 0;
	for(idx = 0;idx < NELEMENTS(g_NtlCwChnCfg);idx++)
	{
		IcHalDbgPrn("idx,chn,dir,type,eport,iport,udport,flowid,vaild",0,9,6,0);

		snpRet = snprintf_s(outPutValStr,sizeof(outPutValStr),"%d,%d,%d,%d,%d,%d,%d,%d,%d",
		g_NtlCwChnCfg[idx].idx,
		g_NtlCwChnCfg[idx].chnNo,
		g_NtlCwChnCfg[idx].chnDir,
		g_NtlCwChnCfg[idx].chnTpe,
		g_NtlCwChnCfg[idx].chnExtLp,
		g_NtlCwChnCfg[idx].chnInnPp,
		g_NtlCwChnCfg[idx].chnUdpPort,
		g_NtlCwChnCfg[idx].chnFlowId,
		g_NtlCwChnCfg[idx].chnVaild);
        SNPRINTF_S_CHECK(snpRet, sizeof(outPutValStr));

		IcHalDbgPrn("idx,chn,dir,type,eport,iport,udport,flowid,vaild",outPutValStr,9,6,1);
	}
#endif
	return BSP_OK;
}

/*********ecpri远程复位的接口*************/
UINT32 NtlSetEcpriRRst(UINT8 *pDestMac1,UINT8 *pDestMac2)
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 srcPort = 0;
	UINT32 dstPort = 0;
	UINT32 roeChn = 0;  /*roe 4个通道中的哪个通道 */
	UINT32 flowId = 0;	
	UINT32 udpPort = 0;
	UINT32 rstType = ROE_CW_LSAR_RESET; /*lsar 复位*/
	T_NtlCwChnCfg tNtlCwChnCfg[MAX_ROE_CW_CHN_NUM];
	UINT32 num  = 0;
	UINT32 port = 0;

	INPUT_POINTER_CHECK(pDestMac1);
	INPUT_POINTER_CHECK(pDestMac2);
	memset(&(tNtlCwChnCfg[0]),0,sizeof(tNtlCwChnCfg));

	//远程掉电复位寄存器配置
	HalIcCrmSetPwrDownRstScr(3);
	HalIcCrmSetRemoteHardRstScr(3);

	if(BSP_ERROR == BspGetCwChnCfgByCwType(CW_CHN_RRST_TYPE,&(tNtlCwChnCfg[0]),&num))
	{
		dbgErr("%s BspGetCwChnCfgByCwType func failed\n",__FUNCTION__);
		return BSP_ERROR;
	}	
	/*rrst 只涉及一个通道，参数取这个通道即可*/
	srcPort = tNtlCwChnCfg[0].chnExtLp;
	dstPort = tNtlCwChnCfg[0].chnInnPp;
	flowId = tNtlCwChnCfg[0].chnFlowId;
	roeChn = tNtlCwChnCfg[0].chnNo;
	udpPort = tNtlCwChnCfg[0].chnUdpPort;
	
	//NtlL2ssTrxpDisable(tNtlCwChnCfg[0].chnInnPp); //控制字内端口控制
	L2ssTrxpDisable(tNtlCwChnCfg[0].chnInnPp,1);
    
	/*rrst 只涉及一个通道,但是配置了两个pDestMac的传输通道*/
	NtlInitEcpriRRstVid(0,srcPort,dstPort,pDestMac1,udpPort,flowId);
	NtlInitEcpriRRstVid(1,srcPort,dstPort,pDestMac2,udpPort,flowId);
	
	BspInitRoeIrRRst(roeChn,rstType,udpPort,flowId);

	dbgInfo("%s chn[%d] sp[%d] dp[%d] flowid[%d]",
		__FUNCTION__,roeChn,srcPort,dstPort,flowId);
	
	dbgInfo("%s mac1[%02x:%02x:%02x:%02x:%02x:%02x]\n",
		__FUNCTION__,pDestMac1[0],pDestMac1[1],pDestMac1[2],
		pDestMac1[3],pDestMac1[4],pDestMac1[5]);
	
	dbgInfo("%s mac2[%02x:%02x:%02x:%02x:%02x:%02x]\n",
		__FUNCTION__,pDestMac2[0],pDestMac2[1],pDestMac2[2],
		pDestMac2[3],pDestMac2[4],pDestMac2[5]);
	
	//打开端口0，下发IQ后自动会打开，不需要在这里设置，
	//NtlL2ssTrxpEnable(tNtlCwChnCfg[0].chnInnPp);   //控制字内端口控制
	L2ssTrxpEnable(tNtlCwChnCfg[0].chnInnPp,1);

	//XMAC和TRPG端口控制
	for(port = 0; port < e_TRXP8; port++)
	{
		NtlL2ssTrxpEnable(port);
		NtlXmacEnable(port);
	}

	/*NtlL2ssTrxpDisable(34);
	NtlL2ssTrxpDisable(36);
	NtlL2ssTrxpDisable(38);
	NtlL2ssTrxpDisable(40);*/
  optCtrlLog(LOG_INFO,"[%s] mac0[%02x:%02x:%02x:%02x:%02x:%02x],mac1[%02x:%02x:%02x:%02x:%02x:%02x] \n",__FUNCTION__,
	              pDestMac1[0],pDestMac1[1],pDestMac1[2],pDestMac1[3],pDestMac1[4],pDestMac1[5],
	              pDestMac2[0],pDestMac2[1],pDestMac2[2],pDestMac2[3],pDestMac2[4],pDestMac2[5]);
#endif
	return BSP_OK;
}

UINT32 tstRrst()
{
	/*打桩的MAC*/
	UINT8 mac[][6] = {
						  {0x40,0x00,0x01,0x02,0x03,0x04},
						  {0x40,0x00,0x11,0x12,0x13,0x14},
					 };
						  
	return NtlSetEcpriRRst((UINT8 *)&(mac[0][0]),(UINT8 *)&(mac[1][0]));
}

/*********ECPRI ERS配置的接口 <algerzder> *************/
UINT32 NtlSetEcpriERS()
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 srcPort = 0;
	UINT32 dstPort = 0;
	UINT32 roeChn = 0;  /*roe 4个通道中的哪个通道 */
	UINT32 flowId = 0;	
	UINT32 udpPort = 0;
	UINT32 ersPayLoadBytes = 0;
    UINT32 aRoeChInfo[MAX_ROE_CW_CHN_NUM] = {0,};
	T_NtlCwChnCfg tNtlCwChnCfg[MAX_ROE_CW_CHN_NUM];
	UINT32 num  = 0;
	UINT32 idx;
	T_NtlIpV4Mac tIpMac;
	
	memset(&tIpMac,0,sizeof(tIpMac));
	memset(&(tNtlCwChnCfg[0]),0,sizeof(tNtlCwChnCfg));
	
	if(BSP_ERROR == BspGetCwChnCfgByCwType(CW_CHN_ERS_TYPE,&(tNtlCwChnCfg[0]),&num))
	{
		dbgErr("%s BspGetCwChnCfgByCwType func failed\n",__FUNCTION__);
		return BSP_OK;   /* 郭勇确认，不需要CW业务的返回值不返回error */
	}	

	for(idx=0;idx<num;idx++)
	{
		L2ssTrxpDisable(tNtlCwChnCfg[idx].chnInnPp,1); //控制字内端口
	}
	
	ersPayLoadBytes = sizeof(T_PhyToRoeFastParaCfg);
	
	/*ers 涉及多个通道，多个通道获取每个通道的参数，并配置*/
	for(idx=0;idx<num;idx++)
	{
		srcPort = tNtlCwChnCfg[idx].chnExtLp;
		dstPort = tNtlCwChnCfg[idx].chnInnPp;
		flowId = tNtlCwChnCfg[idx].chnFlowId;
		roeChn = tNtlCwChnCfg[idx].chnNo;
		udpPort = tNtlCwChnCfg[idx].chnUdpPort;

		BspGetEcpriOptLocalMacIp(srcPort,&(tIpMac.localIpv4[0]),&(tIpMac.localMac[0])); 
		
		aRoeChInfo[idx] = roeChn;
		NtlInitEcpriErsVid(idx,srcPort,dstPort,(UINT8 *)&(tIpMac.localMac[0]),udpPort,flowId);
	
		/*关闭opt的组解帧通道时钟*/
		IcHalOptSetFrmClkGateVal(roeChn,0);
		
		BspInitRoeDemapperErs(roeChn,udpPort,flowId,ersPayLoadBytes);

		dbgInfo("%s idx[%d] chn[%d] sp[%d] dp[%d] flowid[%d] ersBytes[%d]\n",
			__FUNCTION__,idx,roeChn,srcPort,dstPort,flowId,ersPayLoadBytes);
		
		dbgInfo("%s dst mac[%02x:%02x:%02x:%02x:%02x:%02x]\n",
			__FUNCTION__,tIpMac.localMac[0],tIpMac.localMac[1],tIpMac.localMac[2],
			tIpMac.localMac[3],tIpMac.localMac[4],tIpMac.localMac[5]);
	}
	HalIcSetRoeChnInfo(aRoeChInfo,num);

	for(idx=0;idx<num;idx++)
	{
		L2ssTrxpEnable(tNtlCwChnCfg[idx].chnInnPp,1); //控制字内端口
	}
    
    optCtrlLog(LOG_INFO,"[%s]FuncEnd\n",__FUNCTION__);
#endif
	return BSP_OK;
}


/*测试ers通路配置，<algerzder>*/
UINT32 tstErsCfg()
{
    /*DPDIC4编译修改*/
#if 0
	/*打桩的MAC*/
	UINT8 srcMac[6] = {0x40,0x01,0xac,0xfe,0x02,0x28}; /*rru*/
	UINT8 srcIp[4]  =  {0xc0,0xfe,0x00,0x01};  /*rru*/

	UINT8 dstMac[6] = {0x40,0x01,0xac,0xfe,0x02,0x13}; /*bbu*/
	UINT8 dstIp[4]  =  {0xc0,0xfe,0x03,0x04}; /*bbu*/
	
	BspSetEcpriOptLocalMacIp(0,srcIp,srcMac);
	BspSetEcpriOptPeerMacIp(0,dstIp,dstMac);	
	
	BspSetEcpriOptLocalMacIp(4,srcIp,srcMac);
	BspSetEcpriOptPeerMacIp(4,dstIp,dstMac);

	return NtlSetEcpriERS();
#endif
    return BSP_OK;
}

/*测试roe cw ram 的读, <algerzder>*/
UINT32 tstRdErsRam(UINT32 chn)
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 idx = 0;
	T_PhyToRoeERSFastCfgAll tfastCfgTmp;
	T_PhyToRoeERSFastCfgAll *tfastCfg = &tfastCfgTmp;

	memset(tfastCfg,0,sizeof(T_PhyToRoeERSFastCfgAll));
	BspRdRoeErsRam(chn,(UINT8 *)tfastCfg,sizeof(T_PhyToRoeERSFastCfgAll));

	//tfastCfg->ZeroZone[0] = (htonl)(tfastCfg->ZeroZone[0]);
	//tfastCfg->ZeroZone[1] = (htonl)(tfastCfg->ZeroZone[1]);

	printf("zeroZone[0] = 0x%08x\n",tfastCfg->ZeroZone[0]);
	printf("zeroZone[1] = 0x%08x\n",tfastCfg->ZeroZone[1]);

	for(idx=0;idx<8;idx++)
	{
		printf("lte_erspara[%d].ucChipID = 0x%08x\n",idx,(tfastCfg->tLteErspara[idx].ucChipID));
		printf("lte_erspara[%d].ucLocalCarrID = 0x%02x\n",idx,tfastCfg->tLteErspara[idx].ucLocalCarrID);
		printf("lte_erspara[%d].ucScaleEnable = 0x%02x\n",idx,tfastCfg->tLteErspara[idx].ucScaleEnable);
		printf("lte_erspara[%d].ucScale = 0x%02x\n",idx,tfastCfg->tLteErspara[idx].ucScale);
		printf("lte_erspara[%d].ucRbOffsetFre0 = 0x%02x\n",idx,tfastCfg->tLteErspara[idx].ucRbOffsetFre0);
		printf("lte_erspara[%d].ucRbOffsetFre1 = 0x%02x\n",idx,tfastCfg->tLteErspara[idx].ucRbOffsetFre1);
	}

	for(idx=0;idx<8;idx++)
	{
		printf("tNrErspara[%d].ucChipID = 0x%08x\n",idx,(tfastCfg->tNrErspara[idx].ucChipID));
		printf("tNrErspara[%d].ucLocalCarrID = 0x%02x\n",idx,tfastCfg->tNrErspara[idx].ucLocalCarrID);
		printf("tNrErspara[%d].ucScaleEnable = 0x%02x\n",idx,tfastCfg->tNrErspara[idx].ucScaleEnable);
		printf("tNrErspara[%d].ucScale = 0x%02x\n",idx,tfastCfg->tNrErspara[idx].ucScale);
		printf("tNrErspara[%d].ucRbOffsetFre0 = 0x%02x\n",idx,tfastCfg->tNrErspara[idx].ucRbOffsetFre0);
		printf("tNrErspara[%d].ucRbOffsetFre1 = 0x%02x\n",idx,tfastCfg->tNrErspara[idx].ucRbOffsetFre1);
	}
	return BSP_OK;
#endif
    return BSP_OK;
}



/*测试opt cw -> roe demapper -> roe mapper -> roe cw ram, ers通路测试，<algerzder>*/
UINT32 tstErsloopBack(UINT32 chn,UINT32 flowId,UINT32 cnt)
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 udpPort = 3153;
	UINT32 msgType = 0;
	UINT8 srcMac[6] = {0x40,0x01,0xac,0xfe,0x02,0x28}; /*rru*/
	UINT8 srcIp[4]  =  {0xc0,0xfe,0x00,0x01};  /*rru*/

	UINT8 dstMac[6] = {0x40,0x01,0xac,0xfe,0x02,0x13}; /*bbu*/
	UINT8 dstIp[4]  =  {0xc0,0xfe,0x03,0x04}; /*bbu*/

	T_NtlIpV4Mac tIpMac;	
	t_CwContainerInfo *ptCwContainerInfo = NULL;

	ptCwContainerInfo = RoeGetCwContainerPara(CW_ERS);
	INPUT_POINTER_CHECK(ptCwContainerInfo);
	
	memset(&tIpMac,0,sizeof(T_NtlIpV4Mac));
	
	BspInitRoeDemapperErs(chn,udpPort,flowId,sizeof(T_PhyToRoeFastParaCfg));

	memcpy(&(tIpMac.localMac[0]),srcMac,6);
	memcpy(&(tIpMac.localIpv4[0]),srcIp,4);

	memcpy(&tIpMac.peerMac[0],dstMac,6);
	memcpy(&tIpMac.peerIpv4[0],dstIp,4);
	
	BspInitRoeMapperErs(chn,&tIpMac,udpPort,msgType,flowId,sizeof(T_PhyToRoeFastParaCfg));

	tstInitCwData(cnt);
	tstSetCwPara(ptCwContainerInfo->cwNsStart,ptCwContainerInfo->cwNsNum,ptCwContainerInfo->cwXsIdx);
	IcHalOptCfgCwRamTstData(chn);
	
    /*控制字通道环回*/
	RoeSetEthCwLoopBack(0x12,1);
#endif
	return BSP_OK;
		
}

/*DPDIC4编译修改*/
#if 0
UINT32 g_ecpriHiPowRtpPPort = e_TRXP5;
#endif
UINT32 BspSetEcpriHiPowRptPort(UINT32 port)
{
    /*DPDIC4编译修改*/
#if 0
	g_ecpriHiPowRtpPPort = port;
	return BSP_OK;
#endif
    return BSP_OK;
}

UINT32 BspGetEcpriHiPowRptPort()
{
    /*DPDIC4编译修改*/
#if 0
	return g_ecpriHiPowRtpPPort;
#endif
    return BSP_OK;
}


UINT32 NtlSetEcpriHiPowRpt()
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 srcPport = 0;
	UINT32 dstLport = 0;
	UINT32 roeChn = 0;  /*roe 4个通道中的哪个通道 */
	UINT32 flowId = 0;	
	UINT32 udpPort = 0;
	UINT32 num  = 0;
	UINT32 idx;
	UINT32 msgType = 0;
	UINT32 pPort = 0;
	UINT32 hashIdx = 0;
	T_NtlIpV4Mac tIpMac;
	T_NtlCwChnCfg tNtlCwChnCfg[MAX_ROE_CW_CHN_NUM];
	
	memset(&tIpMac,0,sizeof(tIpMac));
	memset(&(tNtlCwChnCfg[0]),0,sizeof(tNtlCwChnCfg));
	
	if(BSP_ERROR == BspGetCwChnCfgByCwType(CW_CHN_HI_POW_TYPE,&(tNtlCwChnCfg[0]),&num))
	{
		dbgErr("%s BspGetCwChnCfgByCwType func failed\n",__FUNCTION__);
		return BSP_OK;   /* 郭勇确认，不需要CW业务的返回值不返回error */
	}	

	for(idx=0;idx<num;idx++)
	{
		L2ssTrxpDisable(tNtlCwChnCfg[idx].chnInnPp,0); //控制字内端口
	}
	
	
	/*ers 涉及多个通道，多个通道获取每个通道的参数，并配置*/
	for(idx=0;idx<num;idx++)
	{
		srcPport = tNtlCwChnCfg[idx].chnInnPp;
		dstLport = tNtlCwChnCfg[idx].chnExtLp;
		flowId = tNtlCwChnCfg[idx].chnFlowId;
		roeChn = tNtlCwChnCfg[idx].chnNo;
		udpPort = tNtlCwChnCfg[idx].chnUdpPort;
		pPort = BspGetEcpriHiPowRptPort();
		// if(pPort >= dstLport)
		// {
		// 	hashIdx = pPort - dstLport;
		// }
		
		BspGetEcpriOptLocalMacIp(dstLport,&(tIpMac.localIpv4[0]),&(tIpMac.localMac[0])); 
		BspGetEcpriOptPeerMacIp(dstLport,&(tIpMac.peerIpv4[0]),&(tIpMac.peerMac[0])); 	
		
		NtlInitEcpriHiPowVid(idx,srcPport,dstLport,&(tIpMac.peerMac[0]),udpPort,flowId,hashIdx);
		dbgInfo("%s dst mac[%02x:%02x:%02x:%02x:%02x:%02x]\n",
			__FUNCTION__,
			(tIpMac.peerMac[0]),(tIpMac.peerMac[1]),(tIpMac.peerMac[2]),
			(tIpMac.peerMac[3]),(tIpMac.peerMac[4]),(tIpMac.peerMac[5])
			);
		
		BspInitRoeMapperHiPowRpt(roeChn,&tIpMac,udpPort,msgType,flowId);
		
		dbgInfo("%s idx[%d] chn[%d] sp[%d] dp[%d] flowid[%d]\n",
			__FUNCTION__,idx,roeChn,srcPport,dstLport,flowId);
		
		/*初始化opt控制字通道上传HiPow*/
		IcHalOptCfgCwHiPow(roeChn);

	}

	for(idx=0;idx<num;idx++)
	{
		L2ssTrxpEnable(tNtlCwChnCfg[idx].chnInnPp,0); //控制字内端口
	}

    optCtrlLog(LOG_INFO,"[%s]FuncEnd\n",__FUNCTION__);
#endif
	return BSP_OK;
}



UINT32 NtlSetEcpriHiPowRptEn(UINT32 en)
{
    /*DPDIC4编译修改*/
#if 0
	UINT32 roeChn = 0;  /*roe 4个通道中的哪个通道 */
	UINT32 num  = 0;
	UINT32 idx;
	
	T_NtlCwChnCfg tNtlCwChnCfg[MAX_ROE_CW_CHN_NUM];
	

	memset(&(tNtlCwChnCfg[0]),0,sizeof(tNtlCwChnCfg));
	
	if(BSP_ERROR == BspGetCwChnCfgByCwType(CW_CHN_HI_POW_TYPE,&(tNtlCwChnCfg[0]),&num))
	{
		dbgErr("%s BspGetCwChnCfgByCwType func failed\n",__FUNCTION__);
		return BSP_OK;   /* 郭勇确认，不需要CW业务的返回值不返回error */
	}	

	for(idx=0;idx<num;idx++)
	{
		roeChn = tNtlCwChnCfg[idx].chnNo;
		RoeMapperCwSetChnEn(roeChn,(en & 0x01));
	}
#endif
	return BSP_OK;
}

/*测试opt cw -> roe demapper -> roe mapper -> roe cw ram, ers通路测试，<algerzder>*/
UINT32 tstHiPowCwRpt()
{
    /*DPDIC4编译修改*/
#if 0
	UINT8 srcMac[6] = {0x40,0x01,0xac,0xfe,0x02,0x28}; /*rru*/
	UINT8 srcIp[4]  =  {0xc0,0xfe,0x00,0x01};  /*rru*/

	UINT8 dstMac[6] = {0x40,0x01,0xac,0xfe,0x02,0x13}; /*bbu*/
	UINT8 dstIp[4]  =  {0xc0,0xfe,0x03,0x04}; /*bbu*/
	
	BspSetEcpriOptLocalMacIp(0,srcIp,srcMac);
	BspSetEcpriOptPeerMacIp(0,dstIp,dstMac);	
	
	BspSetEcpriOptLocalMacIp(4,srcIp,srcMac);
	BspSetEcpriOptPeerMacIp(4,dstIp,dstMac);	
	
	NtlSetEcpriHiPowRpt();
	return BSP_OK;
#endif
    return BSP_OK;
}


UINT32 BspSetCsirsPortAntMap(T_CsirsPortAntMap *csirsPortAntMap)
{
    return BSP_OK;
}
#if 0
UINT32 BspGetCurrentFiberPort(VOID)
{
    return BSP_OK;
}

UINT32 BspGetOptStatus(UINT32 optId)
{
    return BSP_OK;
}
#endif

UINT32 BspSetOptCarrSwitch(UINT32 carrNo,UINT32 radioMode,UINT32 isOn)
{
    return BSP_OK;
}

UINT32 BspSetRfTestSwitch(UINT32 carrNo,UINT32 radioMode,UINT32 sw)
{
    return BSP_OK;
}

/* Started by AICoder, pid:zc217947591711f1418408faa0a96e0ba9788905 */
FUNC_CALLED_OPTFPGA_UMTS_ROE_MACIP_CFG pGetOptFpgaUmtsRoeMacIpCall = NULL;

UINT32 BspOptFpgaRoeMacIpCfgCall(FUNC_CALLED_OPTFPGA_UMTS_ROE_MACIP_CFG pGetUmtsRoeMacIpCfgCall)
{
    pGetOptFpgaUmtsRoeMacIpCall = pGetUmtsRoeMacIpCfgCall;
   return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetRoeOptLinkPara
*  功能描述   : MCS方向ROE报文
*  输入参数   :
*  输出参数   : 无
*  返  回  值: BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspSetRoeOptLinkPara(T_RoeOptLinkParaRecord *roeOptLinkPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(roeOptLinkPara);

    //不区分制式，LV&NB均走ROE
    if (pGetOptFpgaUmtsRoeMacIpCall != NULL)
    {
        retVal = pGetOptFpgaUmtsRoeMacIpCall(roeOptLinkPara);
    }

    return retVal;
}
/* Ended by AICoder, pid:zc217947591711f1418408faa0a96e0ba9788905 */

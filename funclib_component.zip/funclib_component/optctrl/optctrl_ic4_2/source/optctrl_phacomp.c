#include "bsppub.h"
#include "bspcomm.h"
#include "dyn_mem_alloc.h"
#include "ichaladaptbspapi.h"
#include "optctrl_cfg.h"
#include "exprn.h"
#include "freqcfg_ic4_2.h"
#include "funccommon_log.h"

static UINT32 s_auPhaCmpTbl_100M30k[] = {
		0x7FFF0000,
		0x7FFFFEF4,
		0x7FFCFDE8,
		0x7FF6FCDC,
		0x7FEEFBD0,
		0x7FE5FAC4,
		0x7FD9F9B8,
		0x7FCAF8AC,
		0x7FBAF7A1,
		0x7FA7F695,
		0x7F92F58A,
		0x7F7BF47F,
		0x7F62F374,
		0x7F47F269,
		0x7F29F15F,
		0x7F0AF055,
		0x7EE8EF4B,
		0x7EC4EE41,
		0x7E9DED38,
		0x7E75EC2F,
		0x7E4AEB26,
		0x7E1EEA1E,
		0x7DEFE916,
		0x7DBEE80E,
		0x7D8AE707,
		0x7D55E601,
		0x7D1DE4FA,
		0x7CE4E3F4,
		0x7CA8E2EF,
		0x7C6AE1EA,
		0x7C2AE0E6,
		0x7BE8DFE2,
		0x7BA3DEDF,
		0x7B5DDDDC,
		0x7B14DCDA,
		0x7ACADBD9,
		0x7A7DDAD8,
		0x7A2ED9D8,
		0x79DDD8D8,
		0x798AD7D9,
		0x7935D6DB,
		0x78DED5DE,
		0x7885D4E1,
		0x7829D3E5,
		0x77CCD2E9,
		0x776CD1EF,
		0x770BD0F5,
		0x76A7CFFC,
		0x7642CF04,
		0x75DACE0D,
		0x7570CD17,
		0x7505CC21,
		0x7497CB2C,
		0x7428CA39,
		0x73B6C946,
		0x7342C854,
		0x72CDC763,
		0x7255C673,
		0x71DCC584,
		0x7160C496,
		0x70E3C3A9,
		0x7063C2BD,
		0x6FE2C1D3,
		0x6F5FC0E9,
		0x6EDAC000,
		0x6E53BF18,
		0x6DCABE32,
		0x6D3FBD4D,
		0x6CB3BC68,
		0x6C24BB85,
		0x6B94BAA3,
		0x6B02B9C3,
		0x6A6EB8E3,
		0x69D8B805,
		0x6940B728,
		0x68A7B64C,
		0x680BB571,
		0x676EB498,
		0x66D0B3C0,
		0x662FB2E9,
		0x658DB214,
		0x64E9B140,
		0x6443B06D,
		0x639BAF9C,
		0x62F2AECC,
		0x6247ADFE,
		0x619AAD31,
		0x60ECAC65,
		0x603CAB9B,
		0x5F8BAAD2,
		0x5ED7AA0A,
		0x5E23A944,
		0x5D6CA880,
		0x5CB4A7BD,
		0x5BFAA6FC,
		0x5B3FA63C,
		0x5A82A57E,
		0x59C4A4C1,
		0x5904A406,
		0x5843A34C,
		0x5780A294,
		0x56BCA1DD,
		0x55F6A129,
		0x552EA075,
		0x54659FC4,
		0x539B9F14,
		0x52CF9E66,
		0x52029DB9,
		0x51349D0E,
		0x50649C65,
		0x4F939BBD,
		0x4EC09B17,
		0x4DEC9A73,
		0x4D1799D1,
		0x4C409930,
		0x4B689892,
		0x4A8F97F5,
		0x49B49759,
		0x48D896C0,
		0x47FB9628,
		0x471D9592,
		0x463D94FE,
		0x455D946C,
		0x447B93DC,
		0x4398934D,
		0x42B392C1,
		0x41CE9236,
		0x40E891AD,
		0x40009126,
		0x3F1790A1,
		0x3E2D901E,
		0x3D438F9D,
		0x3C578F1D,
		0x3B6A8EA0,
		0x3A7C8E24,
		0x398D8DAB,
		0x389D8D33,
		0x37AC8CBE,
		0x36BA8C4A,
		0x35C78BD8,
		0x34D48B69,
		0x33DF8AFB,
		0x32E98A90,
		0x31F38A26,
		0x30FC89BE,
		0x30048959,
		0x2F0B88F5,
		0x2E118894,
		0x2D178834,
		0x2C1B87D7,
		0x2B1F877B,
		0x2A228722,
		0x292586CB,
		0x28278676,
		0x27288623,
		0x262885D2,
		0x25288583,
		0x24278536,
		0x232684EC,
		0x222484A3,
		0x2121845D,
		0x201E8418,
		0x1F1A83D6,
		0x1E168396,
		0x1D118358,
		0x1C0C831C,
		0x1B0682E3,
		0x19FF82AB,
		0x18F98276,
		0x17F28242,
		0x16EA8211,
		0x15E281E2,
		0x14DA81B6,
		0x13D1818B,
		0x12C88163,
		0x11BF813C,
		0x10B58118,
		0x0FAB80F6,
		0x0EA180D7,
		0x0D9780B9,
		0x0C8C809E,
		0x0B818085,
		0x0A76806E,
		0x096B8059,
		0x085F8046,
		0x07548036,
		0x06488027,
		0x053C801B,
		0x04308012,
		0x0324800A,
		0x02188004,
		0x010C8001,
		0x00008000,
		0xFEF48001,
		0xFDE88004,
		0xFCDC800A,
		0xFBD08012,
		0xFAC4801B,
		0xF9B88027,
		0xF8AC8036,
		0xF7A18046,
		0xF6958059,
		0xF58A806E,
		0xF47F8085,
		0xF374809E,
		0xF26980B9,
		0xF15F80D7,
		0xF05580F6,
		0xEF4B8118,
		0xEE41813C,
		0xED388163,
		0xEC2F818B,
		0xEB2681B6,
		0xEA1E81E2,
		0xE9168211,
		0xE80E8242,
		0xE7078276,
		0xE60182AB,
		0xE4FA82E3,
		0xE3F4831C,
		0xE2EF8358,
		0xE1EA8396,
		0xE0E683D6,
		0xDFE28418,
		0xDEDF845D,
		0xDDDC84A3,
		0xDCDA84EC,
		0xDBD98536,
		0xDAD88583,
		0xD9D885D2,
		0xD8D88623,
		0xD7D98676,
		0xD6DB86CB,
		0xD5DE8722,
		0xD4E1877B,
		0xD3E587D7,
		0xD2E98834,
		0xD1EF8894,
		0xD0F588F5,
		0xCFFC8959,
		0xCF0489BE,
		0xCE0D8A26,
		0xCD178A90,
		0xCC218AFB,
		0xCB2C8B69,
		0xCA398BD8,
		0xC9468C4A,
		0xC8548CBE,
		0xC7638D33,
		0xC6738DAB,
		0xC5848E24,
		0xC4968EA0,
		0xC3A98F1D,
		0xC2BD8F9D,
		0xC1D3901E,
		0xC0E990A1,
		0xC0009126,
		0xBF1891AD,
		0xBE329236,
		0xBD4D92C1,
		0xBC68934D,
		0xBB8593DC,
		0xBAA3946C,
		0xB9C394FE,
		0xB8E39592,
		0xB8059628,
		0xB72896C0,
		0xB64C9759,
		0xB57197F5,
		0xB4989892,
		0xB3C09930,
		0xB2E999D1,
		0xB2149A73,
		0xB1409B17,
		0xB06D9BBD,
		0xAF9C9C65,
		0xAECC9D0E,
		0xADFE9DB9,
		0xAD319E66,
		0xAC659F14,
		0xAB9B9FC4,
		0xAAD2A075,
		0xAA0AA129,
		0xA944A1DD,
		0xA880A294,
		0xA7BDA34C,
		0xA6FCA406,
		0xA63CA4C1,
		0xA57EA57E,
		0xA4C1A63C,
		0xA406A6FC,
		0xA34CA7BD,
		0xA294A880,
		0xA1DDA944,
		0xA129AA0A,
		0xA075AAD2,
		0x9FC4AB9B,
		0x9F14AC65,
		0x9E66AD31,
		0x9DB9ADFE,
		0x9D0EAECC,
		0x9C65AF9C,
		0x9BBDB06D,
		0x9B17B140,
		0x9A73B214,
		0x99D1B2E9,
		0x9930B3C0,
		0x9892B498,
		0x97F5B571,
		0x9759B64C,
		0x96C0B728,
		0x9628B805,
		0x9592B8E3,
		0x94FEB9C3,
		0x946CBAA3,
		0x93DCBB85,
		0x934DBC68,
		0x92C1BD4D,
		0x9236BE32,
		0x91ADBF18,
		0x9126C000,
		0x90A1C0E9,
		0x901EC1D3,
		0x8F9DC2BD,
		0x8F1DC3A9,
		0x8EA0C496,
		0x8E24C584,
		0x8DABC673,
		0x8D33C763,
		0x8CBEC854,
		0x8C4AC946,
		0x8BD8CA39,
		0x8B69CB2C,
		0x8AFBCC21,
		0x8A90CD17,
		0x8A26CE0D,
		0x89BECF04,
		0x8959CFFC,
		0x88F5D0F5,
		0x8894D1EF,
		0x8834D2E9,
		0x87D7D3E5,
		0x877BD4E1,
		0x8722D5DE,
		0x86CBD6DB,
		0x8676D7D9,
		0x8623D8D8,
		0x85D2D9D8,
		0x8583DAD8,
		0x8536DBD9,
		0x84ECDCDA,
		0x84A3DDDC,
		0x845DDEDF,
		0x8418DFE2,
		0x83D6E0E6,
		0x8396E1EA,
		0x8358E2EF,
		0x831CE3F4,
		0x82E3E4FA,
		0x82ABE601,
		0x8276E707,
		0x8242E80E,
		0x8211E916,
		0x81E2EA1E,
		0x81B6EB26,
		0x818BEC2F,
		0x8163ED38,
		0x813CEE41,
		0x8118EF4B,
		0x80F6F055,
		0x80D7F15F,
		0x80B9F269,
		0x809EF374,
		0x8085F47F,
		0x806EF58A,
		0x8059F695,
		0x8046F7A1,
		0x8036F8AC,
		0x8027F9B8,
		0x801BFAC4,
		0x8012FBD0,
		0x800AFCDC,
		0x8004FDE8,
		0x8001FEF4,
		0x80000000,
		0x8001010C,
		0x80040218,
		0x800A0324,
		0x80120430,
		0x801B053C,
		0x80270648,
		0x80360754,
		0x8046085F,
		0x8059096B,
		0x806E0A76,
		0x80850B81,
		0x809E0C8C,
		0x80B90D97,
		0x80D70EA1,
		0x80F60FAB,
		0x811810B5,
		0x813C11BF,
		0x816312C8,
		0x818B13D1,
		0x81B614DA,
		0x81E215E2,
		0x821116EA,
		0x824217F2,
		0x827618F9,
		0x82AB19FF,
		0x82E31B06,
		0x831C1C0C,
		0x83581D11,
		0x83961E16,
		0x83D61F1A,
		0x8418201E,
		0x845D2121,
		0x84A32224,
		0x84EC2326,
		0x85362427,
		0x85832528,
		0x85D22628,
		0x86232728,
		0x86762827,
		0x86CB2925,
		0x87222A22,
		0x877B2B1F,
		0x87D72C1B,
		0x88342D17,
		0x88942E11,
		0x88F52F0B,
		0x89593004,
		0x89BE30FC,
		0x8A2631F3,
		0x8A9032E9,
		0x8AFB33DF,
		0x8B6934D4,
		0x8BD835C7,
		0x8C4A36BA,
		0x8CBE37AC,
		0x8D33389D,
		0x8DAB398D,
		0x8E243A7C,
		0x8EA03B6A,
		0x8F1D3C57,
		0x8F9D3D43,
		0x901E3E2D,
		0x90A13F17,
		0x91264000,
		0x91AD40E8,
		0x923641CE,
		0x92C142B3,
		0x934D4398,
		0x93DC447B,
		0x946C455D,
		0x94FE463D,
		0x9592471D,
		0x962847FB,
		0x96C048D8,
		0x975949B4,
		0x97F54A8F,
		0x98924B68,
		0x99304C40,
		0x99D14D17,
		0x9A734DEC,
		0x9B174EC0,
		0x9BBD4F93,
		0x9C655064,
		0x9D0E5134,
		0x9DB95202,
		0x9E6652CF,
		0x9F14539B,
		0x9FC45465,
		0xA075552E,
		0xA12955F6,
		0xA1DD56BC,
		0xA2945780,
		0xA34C5843,
		0xA4065904,
		0xA4C159C4,
		0xA57E5A82,
		0xA63C5B3F,
		0xA6FC5BFA,
		0xA7BD5CB4,
		0xA8805D6C,
		0xA9445E23,
		0xAA0A5ED7,
		0xAAD25F8B,
		0xAB9B603C,
		0xAC6560EC,
		0xAD31619A,
		0xADFE6247,
		0xAECC62F2,
		0xAF9C639B,
		0xB06D6443,
		0xB14064E9,
		0xB214658D,
		0xB2E9662F,
		0xB3C066D0,
		0xB498676E,
		0xB571680B,
		0xB64C68A7,
		0xB7286940,
		0xB80569D8,
		0xB8E36A6E,
		0xB9C36B02,
		0xBAA36B94,
		0xBB856C24,
		0xBC686CB3,
		0xBD4D6D3F,
		0xBE326DCA,
		0xBF186E53,
		0xC0006EDA,
		0xC0E96F5F,
		0xC1D36FE2,
		0xC2BD7063,
		0xC3A970E3,
		0xC4967160,
		0xC58471DC,
		0xC6737255,
		0xC76372CD,
		0xC8547342,
		0xC94673B6,
		0xCA397428,
		0xCB2C7497,
		0xCC217505,
		0xCD177570,
		0xCE0D75DA,
		0xCF047642,
		0xCFFC76A7,
		0xD0F5770B,
		0xD1EF776C,
		0xD2E977CC,
		0xD3E57829,
		0xD4E17885,
		0xD5DE78DE,
		0xD6DB7935,
		0xD7D9798A,
		0xD8D879DD,
		0xD9D87A2E,
		0xDAD87A7D,
		0xDBD97ACA,
		0xDCDA7B14,
		0xDDDC7B5D,
		0xDEDF7BA3,
		0xDFE27BE8,
		0xE0E67C2A,
		0xE1EA7C6A,
		0xE2EF7CA8,
		0xE3F47CE4,
		0xE4FA7D1D,
		0xE6017D55,
		0xE7077D8A,
		0xE80E7DBE,
		0xE9167DEF,
		0xEA1E7E1E,
		0xEB267E4A,
		0xEC2F7E75,
		0xED387E9D,
		0xEE417EC4,
		0xEF4B7EE8,
		0xF0557F0A,
		0xF15F7F29,
		0xF2697F47,
		0xF3747F62,
		0xF47F7F7B,
		0xF58A7F92,
		0xF6957FA7,
		0xF7A17FBA,
		0xF8AC7FCA,
		0xF9B87FD9,
		0xFAC47FE5,
		0xFBD07FEE,
		0xFCDC7FF6,
		0xFDE87FFC,
		0xFEF47FFF,
		0x00007FFF,
		0x010C7FFF,
		0x02187FFC,
		0x03247FF6,
		0x04307FEE,
		0x053C7FE5,
		0x06487FD9,
		0x07547FCA,
		0x085F7FBA,
		0x096B7FA7,
		0x0A767F92,
		0x0B817F7B,
		0x0C8C7F62,
		0x0D977F47,
		0x0EA17F29,
		0x0FAB7F0A,
		0x10B57EE8,
		0x11BF7EC4,
		0x12C87E9D,
		0x13D17E75,
		0x14DA7E4A,
		0x15E27E1E,
		0x16EA7DEF,
		0x17F27DBE,
		0x18F97D8A,
		0x19FF7D55,
		0x1B067D1D,
		0x1C0C7CE4,
		0x1D117CA8,
		0x1E167C6A,
		0x1F1A7C2A,
		0x201E7BE8,
		0x21217BA3,
		0x22247B5D,
		0x23267B14,
		0x24277ACA,
		0x25287A7D,
		0x26287A2E,
		0x272879DD,
		0x2827798A,
		0x29257935,
		0x2A2278DE,
		0x2B1F7885,
		0x2C1B7829,
		0x2D1777CC,
		0x2E11776C,
		0x2F0B770B,
		0x300476A7,
		0x30FC7642,
		0x31F375DA,
		0x32E97570,
		0x33DF7505,
		0x34D47497,
		0x35C77428,
		0x36BA73B6,
		0x37AC7342,
		0x389D72CD,
		0x398D7255,
		0x3A7C71DC,
		0x3B6A7160,
		0x3C5770E3,
		0x3D437063,
		0x3E2D6FE2,
		0x3F176F5F,
		0x40006EDA,
		0x40E86E53,
		0x41CE6DCA,
		0x42B36D3F,
		0x43986CB3,
		0x447B6C24,
		0x455D6B94,
		0x463D6B02,
		0x471D6A6E,
		0x47FB69D8,
		0x48D86940,
		0x49B468A7,
		0x4A8F680B,
		0x4B68676E,
		0x4C4066D0,
		0x4D17662F,
		0x4DEC658D,
		0x4EC064E9,
		0x4F936443,
		0x5064639B,
		0x513462F2,
		0x52026247,
		0x52CF619A,
		0x539B60EC,
		0x5465603C,
		0x552E5F8B,
		0x55F65ED7,
		0x56BC5E23,
		0x57805D6C,
		0x58435CB4,
		0x59045BFA,
		0x59C45B3F,
		0x5A825A82,
		0x5B3F59C4,
		0x5BFA5904,
		0x5CB45843,
		0x5D6C5780,
		0x5E2356BC,
		0x5ED755F6,
		0x5F8B552E,
		0x603C5465,
		0x60EC539B,
		0x619A52CF,
		0x62475202,
		0x62F25134,
		0x639B5064,
		0x64434F93,
		0x64E94EC0,
		0x658D4DEC,
		0x662F4D17,
		0x66D04C40,
		0x676E4B68,
		0x680B4A8F,
		0x68A749B4,
		0x694048D8,
		0x69D847FB,
		0x6A6E471D,
		0x6B02463D,
		0x6B94455D,
		0x6C24447B,
		0x6CB34398,
		0x6D3F42B3,
		0x6DCA41CE,
		0x6E5340E8,
		0x6EDA4000,
		0x6F5F3F17,
		0x6FE23E2D,
		0x70633D43,
		0x70E33C57,
		0x71603B6A,
		0x71DC3A7C,
		0x7255398D,
		0x72CD389D,
		0x734237AC,
		0x73B636BA,
		0x742835C7,
		0x749734D4,
		0x750533DF,
		0x757032E9,
		0x75DA31F3,
		0x764230FC,
		0x76A73004,
		0x770B2F0B,
		0x776C2E11,
		0x77CC2D17,
		0x78292C1B,
		0x78852B1F,
		0x78DE2A22,
		0x79352925,
		0x798A2827,
		0x79DD2728,
		0x7A2E2628,
		0x7A7D2528,
		0x7ACA2427,
		0x7B142326,
		0x7B5D2224,
		0x7BA32121,
		0x7BE8201E,
		0x7C2A1F1A,
		0x7C6A1E16,
		0x7CA81D11,
		0x7CE41C0C,
		0x7D1D1B06,
		0x7D5519FF,
		0x7D8A18F9,
		0x7DBE17F2,
		0x7DEF16EA,
		0x7E1E15E2,
		0x7E4A14DA,
		0x7E7513D1,
		0x7E9D12C8,
		0x7EC411BF,
		0x7EE810B5,
		0x7F0A0FAB,
		0x7F290EA1,
		0x7F470D97,
		0x7F620C8C,
		0x7F7B0B81,
		0x7F920A76,
		0x7FA7096B,
		0x7FBA085F,
		0x7FCA0754,
		0x7FD90648,
		0x7FE5053C,
		0x7FEE0430,
		0x7FF60324,
		0x7FFC0218,
		0x7FFF010C,
} ;
static UINT32 s_auPhaCmpBaseVal_100M30K[] = {
		11,
		148,
		285,
		422,
		559,
		696,
		65,
		202,
		339,
		476,
		613,
		750,
		119,
		256,
		395,
		532,
		669,
		38,
		175,
		312,
		449,
		586,
		723,
		92,
		229,
		366,
		503,
		640
};
static UINT32 s_auPhaCmpBaseVal_100M15K[] = {
    20,
    294,
    568,
    74,
    348,
    622,
    128,
    404,
    678,    
    184,
    458,
    732,
    238,
    512
};
/****************************************************************
* 函数名称: BspSetBranchPhaCompValue
* 函数说明： 根据上下行方向，计算最终相位补偿值
* 输入参数：
*   dir     方向
*   phaCompBaseVal    相位基准值
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
* 
*****************************************************************/
UINT32 BspSetBranchPhaCompValue(UINT32 dir, UINT32 phaCompBaseVal)
{
    UINT32 tmpVal = phaCompBaseVal;
    if (dir == RX) {
        tmpVal = phaCompBaseVal & 0xffff;
        if (tmpVal == 0x8000) {
            tmpVal = (~tmpVal + 0) & 0xffff;
        } else {
            tmpVal = (~tmpVal + 1) & 0xffff;
        }
        tmpVal |= (phaCompBaseVal & 0xffff0000);
    }
    return tmpVal;
}

/****************************************************************
* 函数名称: BspCalcNrPhaCompVal
* 函数说明： 根据子载波间隔，方向，频点信息计算NR小区的相位补偿值
* 输入参数：
*   scs   子载波间隔
*   dir     方向
*   freq    频点
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
* 
*****************************************************************/
UINT32 BspCalcNrPhaCompVal(UINT32 scs, UINT32 dir, UINT32 freq, UINT32* symPhaCompBuff, UINT32 phaCompSymNum)
{
    UINT32 phaCompBaseValNum = 0;
    UINT32 phaCompFiniValNum = 0;
    UINT32 symIdx = 0;
    UINT32 baseIdx = 0;

    INPUT_POINTER_CHECK(symPhaCompBuff);

    if (scs == CELL_CARR_SCS_30K) { /*注意如果是15k子载波间隔　FNR也支持的话，这个表要对应修改*/
        phaCompBaseValNum = sizeof(s_auPhaCmpBaseVal_100M30K) / sizeof(s_auPhaCmpBaseVal_100M30K[0]);
        phaCompFiniValNum = sizeof(s_auPhaCmpTbl_100M30k) / sizeof(s_auPhaCmpTbl_100M30k[0]);
        if (phaCompBaseValNum > phaCompSymNum) {
            dbgErr("%s phaCompBaseValNum : %u, phaCompSymNum :%u, phaCompFiniValNum: %u\r\n", __FUNCTION__, phaCompBaseValNum, phaCompSymNum, phaCompFiniValNum);
            return BSP_ERROR;
        }
        
        for (symIdx = 0; symIdx < phaCompBaseValNum; symIdx++) {
            // 5 代表啥含义
            baseIdx = ((freq / 5) * s_auPhaCmpBaseVal_100M30K[symIdx]) % phaCompFiniValNum;
            // baseIdx 不会越界
            symPhaCompBuff[symIdx] = BspSetBranchPhaCompValue(dir, s_auPhaCmpTbl_100M30k[baseIdx]);
        }

        for (symIdx = phaCompBaseValNum; symIdx < phaCompSymNum; symIdx++) {
            symPhaCompBuff[symIdx] = symPhaCompBuff[symIdx % phaCompBaseValNum];
            dbgInfoEx("symIdx %d  symPhaCompBuff[symIdx] %d\n",symIdx,symPhaCompBuff[symIdx]);
        }
    }
    else if (scs == CELL_CARR_SCS_15K) {
        phaCompBaseValNum = sizeof(s_auPhaCmpBaseVal_100M15K)/sizeof(s_auPhaCmpBaseVal_100M15K[0]);
        phaCompFiniValNum = sizeof(s_auPhaCmpTbl_100M30k)/sizeof(s_auPhaCmpTbl_100M30k[0]);
        if (phaCompBaseValNum > phaCompSymNum) {
            dbgErr("%s phaCompBaseValNum : %u, phaCompSymNum :%u, phaCompFiniValNum: %u\r\n", __FUNCTION__, phaCompBaseValNum, phaCompSymNum, phaCompFiniValNum);
            return BSP_ERROR;
        }

        for (symIdx = 0; symIdx < phaCompBaseValNum; symIdx++ ) {
            baseIdx = ((freq / 5) * s_auPhaCmpBaseVal_100M15K[symIdx]) % phaCompFiniValNum;
            symPhaCompBuff[symIdx] = BspSetBranchPhaCompValue(dir, s_auPhaCmpTbl_100M30k[baseIdx % phaCompFiniValNum]);
        }

        for (symIdx = phaCompBaseValNum; symIdx < phaCompSymNum; symIdx++) {
            symPhaCompBuff[symIdx] = symPhaCompBuff[symIdx % phaCompBaseValNum];
        }
    }
    else {
        dbgErr("%s| scs val[%d] not support !\r\n",__func__,scs);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*保存相位补偿光口小区频点信息到单边滤波NCO2变量*/

/* Started by AICoder, pid:qd85ea1efd9346c142f10ad990777d4f54d778e8 */
void BspSavePhaCompFreqPara(UINT32 uCellId, UINT32 ulDir, UINT32 uFreq)
{
    UINT32 ret = BSP_OK;
    UINT32 ulChanLoop = 0;
    UINT32 ulMaxChanNum = BspGetTxChannel();
    T_CellCfgInfo tOptCellPara = {0};
    T_FilterChnInfo *filterChnInfo = NULL;

    ret = BspGetOptCellInfoByCellId(uCellId, &tOptCellPara);

    if (BSP_OK == ret)
    {
        if (ulDir == TX)
        {
            filterChnInfo = BspGetFilterChnInfoMem(tOptCellPara.cellAntRadioMode);
            ulMaxChanNum = BspGetTxChannel();
        }
        else
        {
            filterChnInfo = BspGetUlFilterChnInfoMem(tOptCellPara.cellAntRadioMode);
            ulMaxChanNum = BspGetRxChannel();
        }

        if (NULL != filterChnInfo)
        {
            for (ulChanLoop = 0; ulChanLoop < ulMaxChanNum; ulChanLoop++)
            {
                if ((tOptCellPara.cellAntMask[ulDir] & BIT_SET(ulChanLoop)) != 0)
                {
                    filterChnInfo[ulChanLoop].carrInfo[tOptCellPara.cellCarrNo].nco2 = uFreq;
                    BspLog(LOG_LEVEL_0, "%s ulChanLoop=%d, carrNo %d uDir=%d, uFreq=%d\n",
                           __FUNCTION__, ulChanLoop, tOptCellPara.cellCarrNo, ulDir, uFreq);
                }
            }
        }
        else
        {
            BspLog(LOG_LEVEL_0, "%s get slider mem fail uCellId=%d, uDir=%d, uFreq=%d\n",
                   __FUNCTION__, uCellId, ulDir, uFreq);
        }
    }
    else
    {
        BspLog(LOG_LEVEL_0, "%s get OptCell fail uCellId=%d, uDir=%d, uFreq=%d\n",
               __FUNCTION__, uCellId, ulDir, uFreq);
    }
}
/* Ended by AICoder, pid:qd85ea1efd9346c142f10ad990777d4f54d778e8 */
/****************************************************************
* 函数名称: BspSetPhaCompPara
* 函数说明： 配置相位补偿　（目前看RRU没有相位补偿功能，aau上此接口作相位补偿，3.0上此接口用作高铁频偏补偿
* 　　　　　4.2如果沿用3.0rru的用法,此接口对app就不暴露，bsp内部使用）  BspSetPhaseCompWeightIc
* 输入参数：
*   cellId  bbu下发的小区ID
*   dir     方向
*   freq    频点
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
* 
*****************************************************************/
UINT32 BspSetPhaCompPara(UINT32 uCellId, UINT32 uDir, UINT32 uFreq)
{
    UINT32  scs = 0;
    UINT32  symNum = 0;
    UINT32  optCellId = 0; /* 光口小区ID*/
    UINT32* symPhaCompBuff = NULL;
    UINT32  radioMode = 0;

    BspLog(LOG_LEVEL_0,"%s uCellId=%d, uDir=%d, uFreq=%d\n", __FUNCTION__, uCellId, uDir, uFreq);
    /*保存单边滤波使用相位补偿频点*/
    BspSavePhaCompFreqPara(uCellId, uDir, uFreq);

    /* 从光口小区映射中获取小区ID到光口小区的映射值 TODO: 需要场景预置模块提供小区ID到光口小区ID的映射 */
    optCellId = uCellId;
    /* 获取制式, 如果不是NR 制式,则直接返回 */
    if(BspHalAdaptGetCellRadioMode(optCellId, &radioMode))
    {
        dbgErr("%s invoke BspHalAdaptGetCellRadioMode failed\r\n", __FUNCTION__);
        return BSP_ERROR;       
    }
    /* 非NR制式,无需配置相位补偿 注意如果FNR支持IF1 应该也需要相位补偿*/
    if (!(radioMode & (BSP_RADIO_STANDARD_5G|BSP_RADIO_STANDARD_FDD_5G)))
    {
        return BSP_OK;
    }
    /* 获取小区子载波间隔和TTI周期符号数 */
    if (BspHalAdaptGetPhaCompParaScsSymNum(optCellId, &scs, &symNum) != BSP_OK) {
        dbgErr("%s invoke BspHalAdaptGetPhaCompParaScsSymNum failed\r\n", __FUNCTION__);
        return BSP_ERROR;
    }

    DYN_MEM_ALLOC(symPhaCompBuff, sizeof(UINT32) * symNum);
    if (symPhaCompBuff == NULL) {
        return BSP_ERROR;
    }
    /* 计算相位补偿值 */
    if (BspCalcNrPhaCompVal(scs, uDir, uFreq, symPhaCompBuff, symNum) != BSP_OK) {
        DYN_MEM_FREE(symPhaCompBuff);
        dbgErr("%s invoke BspCalcNrPhaCompVal failed\r\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /* 配置相位补偿信息 TODO: 需要HAL层提供配置光口小区的相位补偿值 */
    if (BspHalAdaptCfgPhaCompVal(optCellId, uDir, symPhaCompBuff, symNum) != BSP_OK) {
        DYN_MEM_FREE(symPhaCompBuff);
        dbgErr("%s invoke BspHalAdaptCfgPhaCompVal failed\r\n", __FUNCTION__);
        return BSP_ERROR;
    }

    DYN_MEM_FREE(symPhaCompBuff);
	BspLog(LOG_LEVEL_0,"%s uCellId=%d, scs=%d, symNum=%d\n", __FUNCTION__, uCellId, scs, symNum);
    return BSP_OK;
}


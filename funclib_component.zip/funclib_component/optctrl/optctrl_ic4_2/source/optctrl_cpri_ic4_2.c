/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : optctrl_cpri_dpdic3
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件提供了单板光口相关功能（由于光口功能复杂，特从单板控制中抽取出来）
 * 注意事项 : 无
 * 作    者 : 崔文会
 * 创建日期 : 2014-05-12 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 崔文会
 * 修改日戳: 2014-05-12 10:28:34
 * 变更说明: 创建文件，DPDIC 单板光口相关功能

 *----------------------------------------------------------------------------
 */

/* linux 系统头文件 */
#include <fcntl.h>
#include <linux/sysctl.h>
#include <sys/mman.h>
#include <pthread.h>
#include <errno.h>

/* bsp公共头文件 */
#include "bsppub.h"
//#include "bspcomm.h"
#include "funccommon.h"
#include "funccommon_a.h"
#include "exprn.h"
#include "optctrlapi.h"
#include "optctrl_cpri_ic4_2.h"
#include "optadpt.h"
#include "ichal_opt_api.h"
#include "optctrlcommon.h"
#include "bspcommon.h"
#ifndef MULT_PROGRESS_S
#include "sfp.h"
#include "boardid.h"
#include "devdrv_tempsensor.h"
#endif
#include "timedelay_ic4_2.h"
#include "opt_pcs_api.h"
#include "opt_pma_api.h"
#include "dlyapi.h"
#include "bsppub.h"
#include "rruinfo.h"

FUNC_OPTADAPT_POST   pOptAdaptPostFunc    = NULL;  /*此处先保留，暂时不使用*/

#define SET_OPT_CFG_CNT_MAX   (10)
#define OPT_LOCK_TYR_TIMES 10
#define INVALID_RRUID (254)
#define OPT_UNIFORM_ENABLE_FLAG   (0)
#define RRU_PARA_FILE_RUREDUNDANCY_MODE   "/ata/rru/para/redundancy.ini"
#define INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack)      \
    if(ulLen >= (length-1))                               \
    {                                                              \
        free(pTmp);                                               \
        free(ptOptDiag);                                          \
        free(ptNetPack);                                          \
        return BSP_ERROR;                                         \
    }
#define TDD_OPT_WORK_MODE_ALONE 1   /*单级*/
#define IP_NUM 4

typedef struct tagT_TopNetMap
{
    UINT32 bspTopNet;   /* BSP对高层的组网模式 */
    UINT32 halTopNet;   /* Hal对BSP的组网模式 */
}T_TopNetMap;

/*需要hal提供对应的组网模式对应关系*/
static T_TopNetMap s_bspTopNetMap[] =
{
    {BSP_OPT_WORK_MODE_CASCADE_NORMAL,NET_MODE_CASCADE_NORMAL},
    {BSP_OPT_WORK_MODE_NORMAL,       NET_MODE_RING},   /*FDD 环网*/
    {BSP_OPT_WORK_MODE_CASCADE,      NET_MODE_CASCADE},
    {BSP_OPT_WORK_MODE_MAIN_SLAVE,   NET_MODE_M_S},
    {BSP_OPT_WORK_MODE_SHARE,        NET_MODE_LOAD_SHARE},
    {BSP_OPT_WORK_MODE_RING,         NET_MODE_RING},   /*TDD 环网*/
    /*{BSP_OPT_WORK_MODE_RING_CHAIN,   0xff}, 4.2不支持*/
    /*{BSP_OPT_WORK_MODE_SHARE_CASCADE,0xff}, 4.2不支持*/
    {BSP_OPT_WORK_MODE_SHARE_RING,   NET_MODE_LOAD_SHARE_AND_RING},
    {BSP_OPT_WORK_MODE_NORMAL,   NET_MODE_STAR},  /*tdd使用 普通模式*/
};

UINT32 g_phyNoSfpNoMapLink[4] = {0,0,0,0}; /*数组下标表示光笼编号，元素值表示对应的物理光口号(serdes lane)*/
T_OPTRATE_SERDES_PARAM g_OptRateSerdesCfg[OPT_SERDES_LANE_MAX_NUM]= {0};
UINT32 g_ulFecModeChange[OPTMAXNUM] = {0};

UINT32 g_ulQSfpType[OPTMAXNUM] = {0};
UINT32 g_ulSfpType[OPTMAXNUM] = {0};
UINT32 g_ulSfpChangeFlag[OPTMAXNUM] = {0};
UINT32 g_ulQsfpToSfpChange[OPTMAXNUM] = {0};
UINT32 g_ulSpeedMaskList = 0xff;
UINT32 g_ulOptSpdChgFlag[OPTMAXNUM] = {0};
UINT32 lastMainOpt = 0;
UINT32 g_ulQSfpLongExistCnt[OPTMAXNUM] = {0};
UINT32 g_lastMainOptNo = 0xff;
HGOptCheckCall g_HGOptSpeedFlag = NULL;
UINT32 g_ulRingFlag = OPT_NOT_SUPPORT_RING;
UINT32 g_ulShareFlag = OPT_NOT_SUPPORT_RING;
UINT32 g_ulSupportDualBbuFlag = OPT_NOT_SUPPORT_DUAL_BBU;

UINT32 g_ulOptFrTestModeEn = 0;
UINT32 g_ulOptInnerCpriFrModeEn = 0;
UINT32 g_ulOptPcsCfgEn = 0;
static BSP_BBX_IQINFO_CALLBACK_FUNCPTR pBspShowIqInfoCallBack = NULL;
/*区分是否支持环网*/
UINT32 g_ulSetPhyFlag = 0xff;
static UINT32 g_ulDefaultNetworkMode = NET_MODE_CASCADE_NORMAL;  /*组网模式未下发之前返回0，避免OSS走进异常流程*/

static UINT32 ulMainOptChangeflag = 0;  /* 记录倒换时是否由双上联到恢复状态 */
static UINT32 ulForceSetMainOpt = OPT_FORCE_AUTO;  /* 固定主光口标志，默认自由竞争 */
static UINT32 s_lastMainOpt = BSP_ERROR;
static UINT32 s_currMainOpt = BSP_ERROR;
UINT32 s_reverseSwitchoverSw = SWITCH_OFF;  /* 强制反向倒换使能变量 */
UINT32 s_reverseTime = 3000;     /* 反向倒换释放时间 */
UINT32 swCfgIqEnCnt = 40;      /* 倒换后txsw延时开时间，默认4S 40*100ms */
static E_LYCA_PRBS_MODE s_prbsMode = LYCA_PRBS9;
static UINT32 s_SetOptCfgCnt = 0;
static UINT32 s_cpriCfgIqCloseSetFlag = 1;  /* 双BBU下，固定主光口释放前不进行末级打开数据操作 */

UINT32 _SetOptCpriCfgCmUxSelCntX = 0;
UINT32 _SetOptCpriCfgCmUxSelCntY = 0;
T_RRUOptMapRelation g_rruOptMapRelation = {0};
UINT32 g_rruId[MAX_OPT_NUM] = {0};
static FUNC_GET_IP_ADDR pFuncGetIpAddr = NULL;
static FUNC_GET_RRU_ID pFuncGetRruId = NULL;
UINT32 g_supportDoubleBBUMainSlaveFlag = NOT_SUPPORT_DOUBLE_BBU_MAIN_SLAVE; /*此标志为高层识别出双bbu场景下发的标志*/
UINT32 g_priorityLinkByPhy0Flag  = NOT_TRY_LINK_WITH_PHY0;
UINT32 g_ulBbuPortSpeFlag = 0;   /*启动后默认设置的BBUPort控制字特殊处理标志==1  主片和单片在初始化时设置*/
static UINT32 s_BitTotal[HDLC_TYPE_NUM] =
{
    [0]  = HDLC_RATE0K,
    [1]  = HDLC_RATE960K,
    [2]  = HDLC_RATE1920K,
    [3]  = HDLC_RATE2400K,
    [4]  = HDLC_RATE3840K,
    [5]  = HDLC_RATE4800K,
    [6]  = HDLC_RATE7680K,
};

UINT32 pcsMask = BSP_QCELL_PCS_MASK;
VOID BspSetPcsMaskForQcell(UINT32 mask)
{
    pcsMask = mask;
}
/*****************************************************************************
 *  函数名称   : (*)
 *  功能描述   : 配置打印放开
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : x = 非0，则立即强制放开打印
 *  输入参数   : y = 非0，则在10s内放开一次打印（视调用周期定）
 *  输出参数   :
 *  返 回 值   : 无
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  
 *----------------------------------------------------------------------------
 *****************************************************************************/
VOID _SetOptCpriCfgCmUxSelCntXY(UINT32 x, UINT32 y)
{
    _SetOptCpriCfgCmUxSelCntX = x;
    _SetOptCpriCfgCmUxSelCntY = y ? 2000 : 1;
}

VOID BspSetOptRingFlag(UINT32 ulFlag)
{
    UINT32 ringFlag = (ulFlag & (0xf));
    UINT32 shareFlag = ((ulFlag >> 4) & (0xf));

    g_ulRingFlag = ringFlag;
    g_ulShareFlag = shareFlag; /* 负荷分担标志 */
    IcHalApiSetFDDRingMode(ringFlag);
}

/*区分是否支持环网*/
UINT32 BspGetOptRingFlag(VOID)
{
    return g_ulRingFlag;
}

/*区分是否支持负荷分担*/
UINT32 BspGetOptShareFlag(VOID)
{
    return g_ulShareFlag;
}

/*区分是否支持3.0+4.2混连*/
VOID BspSetOptFrTestModeEn(UINT32 ulFlag)
{
    g_ulOptFrTestModeEn = ulFlag;
}

/*区分是否支持3.0+4.2混连*/
UINT32 BspGetOptFrTestModeEn(VOID)
{
    return g_ulOptFrTestModeEn;
}

/*板件速率切换切自环*/
VOID BspSetOptInnerCpriFrModeEn(UINT32 flag)
{
    g_ulOptInnerCpriFrModeEn = flag;
}

UINT32 BspGetOptInnerCpriFrModeEn(VOID)
{
    return g_ulOptInnerCpriFrModeEn;
}

/*区分是否支持双BBU*/
VOID BspSetSupportDualBbuFlag(UINT32 ulFlag)
{
    g_ulSupportDualBbuFlag = ulFlag;
}

/*区分是否支持双BBU*/
UINT32 BspGetSupportDualBbuFlag(VOID)
{
    return g_ulSupportDualBbuFlag;
}

/*获取pcs配置使能*/
UINT32 BspGetOptPcsCfgEn(void)
{
    return g_ulOptPcsCfgEn ;
}

/*通过BSP组网模式获取HAL组网模式*/
UINT32 BspGetHalTopNetByBspTopNet(UINT32 ulBspTopNet,UINT32 *ulHalTopNet)
{
    UINT32 loop = 0;
    UINT32 num = NELEMENTS(s_bspTopNetMap);
    UINT32 procotol = 0;

    INPUT_POINTER_CHECK(ulHalTopNet);
    for(loop = 0; loop < num; loop++)
    {
        if(ulBspTopNet == s_bspTopNetMap[loop].bspTopNet)
        {
            *ulHalTopNet = s_bspTopNetMap[loop].halTopNet;
            dbgInfoEx("[%s] bsp top net is %d, hal top net is %d\n",__FUNCTION__,ulBspTopNet,*ulHalTopNet);
            break;			
        }
    }

    if(loop == num)
    {
        dbgErr("[%s] bsp get hal top net fail!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    procotol = BspGetOptCpriProtocol(0);
    if((PROCOTOL_IR == procotol)&&(BSP_OPT_WORK_MODE_NORMAL == ulBspTopNet))
    {
        *ulHalTopNet = NET_MODE_STAR;   /*TDD的1 表示普通模式*/
    }

    return BSP_OK;
}
/*通过hal组网模式获取bsp组网模式*/
UINT32 BspGetBspTopNetByHalTopNet(UINT32 ulHalTopNet,UINT32 *ulBspTopNet)
{
    UINT32 loop = 0;
    UINT32 num = NELEMENTS(s_bspTopNetMap);
    UINT32 protocol = 0;

    INPUT_POINTER_CHECK(ulBspTopNet);
    protocol =  BspGetOptCpriProtocol(0);
    for(loop = 0; loop < num; loop++)
    {
        if(ulHalTopNet == s_bspTopNetMap[loop].halTopNet)
        {

            *ulBspTopNet = s_bspTopNetMap[loop].bspTopNet;
            dbgInfoEx("[%s] bsp top net is %d, hal top net is %d\n",__FUNCTION__,*ulBspTopNet,ulHalTopNet);
            break;			
        }
    }
    if(loop == num)
    {
        dbgErr("[%s] bsp get bsp top net fail!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* 环网底层只有一个值 对外组网却区分TDD/FDD*/
    if((NET_MODE_RING == ulHalTopNet)&&(PROCOTOL_IR == protocol))
    {
        *ulBspTopNet = BSP_OPT_WORK_MODE_RING;
    }
    return BSP_OK;
}
/*预留从单板下修改bsp和hal组网的对应关系*/
UINT32 BspModifyTopNet(T_TopNetMap *pBoardTopNet, UINT32 ulLen)
{
    UINT32 ulLoop      = 0;
    UINT32 ulTopNetLoop = 0;
    UINT32 ulTopNetCnt  = 0;
    
    ulTopNetCnt = sizeof(s_bspTopNetMap) / sizeof(s_bspTopNetMap[0]);
    for(ulLoop = 0; ulLoop < ulLen; ulLoop++)
    {
        for(ulTopNetLoop = 0; ulTopNetLoop < ulTopNetCnt; ulTopNetLoop ++)
        {
            if(pBoardTopNet[ulLoop].bspTopNet != s_bspTopNetMap[ulTopNetLoop].bspTopNet)
            {
                continue;
            }
            if(pBoardTopNet[ulLoop].halTopNet != s_bspTopNetMap[ulTopNetLoop].halTopNet)
            {
                s_bspTopNetMap[ulTopNetLoop].halTopNet = pBoardTopNet[ulLoop].halTopNet;
            }
        }
    }

    return BSP_OK;
}

UINT32 BspSetPhyNoBySfpNo(UINT32 sfpNo,UINT32 phyNo)   /*光笼转换成物理光口号，部分机型光笼编号和serdes lane编号有交叉*/
{
	if(sfpNo >=OPTMAXNUM)
	{
		return BSP_ERROR;
	}
	g_phyNoSfpNoMapLink[sfpNo] = phyNo;
	(VOID)BspHalAdaptSetPhyNoBySfpNo(sfpNo,phyNo);
	return BSP_OK;
}

UINT32 BspGetPhyNoBySfpNo(UINT32 sfpNo)   /*光笼转换成物理光口号，部分机型光笼编号和serdes lane编号有交叉*/
{
	if(sfpNo >=OPTMAXNUM)
	{
		return BSP_ERROR;
	}
	return g_phyNoSfpNoMapLink[sfpNo];
}

UINT32 BspSetSerdesParaByPhyNo(UINT32 phyNo,T_OPTRATE_SERDES_PARAM *pOptRatePara)   /*目前看用作上下联光口的serdes参数不区分lane 预留光口号入参*/
{
	if(phyNo >=OPT_SERDES_LANE_MAX_NUM)
	{
		return BSP_ERROR;
	}
	(void)memcpy_s(&g_OptRateSerdesCfg[phyNo],sizeof(T_OPTRATE_SERDES_PARAM),pOptRatePara,sizeof(T_OPTRATE_SERDES_PARAM));

	return BSP_OK;
}
UINT32 BspGetSfpNoByPhyNo(UINT32 phyOptNo)   /*物理光口号转换成光笼号，部分机型光笼编号和serdes lane编号有交叉*/
{
    UINT32 loop = 0;
    if(phyOptNo >= OPT_SERDES_LANE_MAX_NUM)
    {
        return BSP_ERROR;
    }
    for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++ )
    {
        if(g_phyNoSfpNoMapLink[loop] == phyOptNo)
        {
        	return loop;
        }
    }
    return BSP_ERROR;
}
UINT32 BspGetSerdesParaByPhyNo(UINT32 phyNo,T_OPTRATE_SERDES_PARAM *pPara)
{
	if(phyNo >=OPT_SERDES_LANE_MAX_NUM)
	{
		return BSP_ERROR;
	}
	memcpy_s(pPara,sizeof(T_OPTRATE_SERDES_PARAM),&g_OptRateSerdesCfg[phyNo],sizeof(T_OPTRATE_SERDES_PARAM));

	return BSP_OK;
}

UINT32 BspGetOptFecChangeFlag(UINT32 ulIndex)
{
    return g_ulFecModeChange[ulIndex];
}
/****************************************************************************
*  函数名称   : BspGetLogicPort()
*  功能描述   : 通过物理光口号获取逻辑光口号
*  输入参数   : phyOpt　物理光口号
*  输出参数   : 无
*  返 回 值   : 所使用的主光口号，编号从0开始
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A) , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetLogicPort(UINT32 phyOpt)
{
    return BspHalAdaptGetLogOpt(phyOpt);
}
/****************************************************************************
*  函数名称   : BspGetPhyPort()
*  功能描述   : 通过逻辑光口号获取物理光口号
*  输入参数   : logicOpt　逻辑光口号
*  输出参数   : 无
*  返 回 值   : 所使用的主光口号，编号从0开始
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A) , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetPhyPort(UINT32 logicOpt)
{
    return BspHalAdaptGetPhyOpt(logicOpt);
}
/****************************************************************************
*  函数名称   : BspGetCurrFiberPort(*)
*  功能描述   : 获取当前使用的光口（主光口）
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 所使用的主光口号，编号从0开始
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10076963@2017-04-24 , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetCurrFiberPort(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 phyMainOpt = 0;
    UINT32 sfpNo = 0;
    
    /*先解析出物理主光口号，然后从物理光口映射得到逻辑光口*/
    retVal = BspHalAdaptGetMainPhyOpt(&phyMainOpt);
    if ((retVal != BSP_OK) || (phyMainOpt == BSP_ERROR))
    {
        dbgInfoEx("%s>>PhyMainOpt'%d Get Error! FunRet= %d\n",
                  __FUNCTION__, phyMainOpt, retVal);
        if(BspGetTddSupportRingModeWorkFlag() == 1)
        {
            return lastMainOpt; /*规避oss收到光口号>8时,bootp流程卡住问题,无法识别出主光口时特殊处理*/
        }
        return 0;
    }
    
    sfpNo = BspGetSfpNoByPhyNo(phyMainOpt);
    lastMainOpt = sfpNo;

    return sfpNo;
}

/****************************************************************************
*  函数名称   : BspGetBbuFiberPort(*)
*  功能描述   : 获取RRU物理光口对应的BBU侧光口号
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulRruOptPort --物理光口号
*  输出参数   : 无
*  返 回 值   : BBU侧光口号，BSP_ERROR-错误
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10076963@2017-04-24 , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetBbuFiberPort(UINT32 ulRruOptPort)//iq配置
{
    UINT32 ulLogNo = 0;
    UINT32 ulPhyNo = 0;
    UINT32 bbuPort = 0;

    ulPhyNo = BspGetMainPhyOpt();
    if(BSP_ERROR == ulPhyNo)
    {
        BspLog(LOG_LEVEL_0,"%s: ulRruOptPort %d bbuport 00\n", __FUNCTION__,ulRruOptPort);
        return 0;
    }
    else
    {
        ulPhyNo = BspGetPhyNoBySfpNo(ulRruOptPort);
        ulLogNo = BspGetLogicPort(ulPhyNo);
        if(BSP_ERROR == ulLogNo)  /*映射关系识别不到*/
        {
            BspLog(LOG_LEVEL_0,"%s: ulRruOptPort %d bbuport 01\n", __FUNCTION__, ulRruOptPort);
            return 0;
        }
    }

    if(PROCOTOL_CPRI == BspGetOptCpriProtocol(0))
    {
        bbuPort = BspHalAdaptGetBbuCpriFiberPort(ulLogNo);
    }
    else
    {
        bbuPort = BspHalAdaptGetBbuFiberPort(ulLogNo);
    }

    return bbuPort;
}

/****************************************************************************
*  函数名称   : BspGetBBUOptPort(*)
*  功能描述   : 获取RRU物理光口对应的BBU侧光口号
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulRruOptPort --物理光口号
*  输出参数   : 无
*  返 回 值   : BBU侧光口号，BSP_ERROR-错误
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10076963@2017-04-24 , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetBBUOptPort(UINT32 ulRruOptPort)
{
	return BspGetBbuFiberPort(ulRruOptPort);
}

/****************************************************************************
*  函数名称   : BspGetRruIdRange(*)
*  功能描述   : 获取光口对应的Id Range
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulIndex - 光口号
*  输出参数   : 无
*  返 回 值   : IdRange, BSP_ERROR-错误
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10076963@2017-04-24 , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetRruIdRange(UINT32 ulIndex)//时延
{
    if(IS_NCR == BspIsNcr())
    {
        return 0xff;
    }
    return BspHalAdaptGetTddUplinkRruIdRange();

}
/****************************************************************************
*  函数名称   : BspGetRruLinkInd(*)
*  功能描述   : 获取光口对应的LinkId
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : LindId,BSP_ERROR-错误
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10076963@2017-04-24 , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetRruLinkInd(UINT32 ulIndex)//时延
{
    UINT32 rruId = 0;
    UINT32 rruIdRange = 0;

    if(IS_NCR == BspIsNcr())
    {
        rruId = BspGetRruId(ulIndex);
        rruIdRange = BspGetRruIdRange(ulIndex);
        if(rruId <= rruIdRange)
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
	return BspHalAdaptGetTddUplinkLinkInd();
}
/*****************************************************************************
 *  函数名称   : BspGetOptProtocol(*)
 *  功能描述   :获取光口协议,高层调用（从控制字解析出） OSS只需要主光口报的正常就行，辅光口不用 如果主光口异常bootp不会走到这
 *  输入参数   : BspGetBootpOptNo 的出参是这个接口入参 所以只需要像3.0 报主光口的就行
 *  输出参数   : none
 *  返 回 值     : BSP_OK
 *  其它说明   :
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),@
 *----------------------------------------------------------------------------
 */
UINT32 BspGetOptProtocol(UINT32 ulLogOpt)
{
    UINT32 ulProtocol = 0;
    UINT32 ulPhyOpt   = 0;
    UINT32 ulTemp = 0;

    if(IS_NCR == BspIsNcr())
    {
        return PROCOTOL_IR;
    }

    BspHalAdaptGetMainPhyOpt(&ulPhyOpt);
    if(BSP_ERROR == ulPhyOpt)   /*主光口异常 OSS会再发起 此时值不对不影响*/
    {
        return ulProtocol;
    }
    BspHalAdaptGetCpriAdaptedProtocol(ulPhyOpt,&ulTemp);
    if(0 == ulTemp)/*控制字0*/
    {
        ulProtocol = PROCOTOL_CPRI;
    }
    else     /*控制字0xffff*/
    {
        ulProtocol = PROCOTOL_IR;
    }
    dbgInfoEx("%s %d %d\n", __func__, ulLogOpt, ulProtocol);

    return ulProtocol;
}

UINT32 BspGetMainPhyOpt(VOID)
{
    UINT32 ulPhyOpt = 0;
    BspHalAdaptGetMainPhyOpt(&ulPhyOpt);
    return ulPhyOpt;
}

/*给APP上报逻辑主光口*/
UINT32 BspGetMainLogOpt(UINT32 *pMainLogNo)
{
    UINT32 ulRet = BSP_OK;

    INPUT_POINTER_CHECK(pMainLogNo);
    ulRet = BspHalAdaptGetMainLogicOpt(pMainLogNo);
    INPUT_OPT_CHECK(*pMainLogNo);      /*主光口解析报错时报错给APP*/
    return ulRet;
}
/*****************************************************************************
 *  函数名称   : BspSetOptCpriProtocol(*)
 *  功能描述   :新增设置光口协议的接口，内部使用，不对外，3.0上单板初始化里直接调用hal的接口IcHalOptLogicTopSetProtocol
 *  输入参数   : ulProtocol 0:cpri 1:IR qcell:0 (注意qcell选择0)
 *  输出参数   : none
 *  返 回 值     : BSP_OK
 *  其它说明   :
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),@
 *----------------------------------------------------------------------------
 */
UINT32 BspSetOptCpriProtocol(UINT32 ulProtocol)
{
	UINT32 ulRet = BSP_OK;
	dbgInfoEx("%s ulProtocol %d\n",__FUNCTION__,ulProtocol);
	BspLog(LOG_LEVEL_0,"%s: ulProtocol[%d]\n", __FUNCTION__,ulProtocol);
	ulRet |= BspHalAdaptSetCpriProtocol(ulProtocol);
	ulRet |= BspHalApiCpriSelAlignFr();/*9125二级级联上报时延异常，需要寄存器配置之后走一次初始化*/
    return ulRet;
}

/*****************************************************************************
 *  函数名称   : BspGetOptCpriProtocol(*)
 *  功能描述   :获取光口协议,提供给时延模块使用(从set对应的寄存器获取)
 *  输入参数   : 无
 *  输出参数   : none
 *  返 回 值     : BSP_OK
 *  其它说明   :
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),@
 *----------------------------------------------------------------------------
 */
UINT32 BspGetOptCpriProtocol(UINT32 ulLogOpt)
{
	UINT32 ulProtocol = 0;
	UINT32 ulRet = BSP_OK;

	ulRet = BspHalAdaptGetCpriProtocol(&ulProtocol);
	if(ulRet != BSP_OK)
	{
		dbgErr("BspGetOptCpriProtocol error\n");
		return ulRet;
	}
	dbgInfoEx("%s ulProtocol %d\n",__FUNCTION__,ulProtocol);

	return ulProtocol;
}

/*****************************************************************************
 *  函数名称   : BspSetOptTxCtrl(*)
 *  功能描述   : 设置光模块发送使能的控制权
 *  读全局变量 :
 *  写全局变量 : 无
 *  输入参数   : ulIndex    - 光口索引号
               ulHighFlag - 0:逻辑控制 1:CPU控制
 *  输出参数   : none
 *  返 回 值     : BSP_OK
 *  其它说明   : 版本公共接口函数!!与BspSetOptTxDisable配合使用，在调用BspSetOptTxDisable
 *            接口后，必须要调用该接口，释放控制权，否者导致光口控制权在CPU侧无法释放
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),10191426@2018-01-22 13:58:20,
 *----------------------------------------------------------------------------
 */
UINT32 BspSetOptTxCtrl(UINT32 uIndex, UINT32 uHigh)
{
    UINT32 uRet = BSP_OK;
    // UINT32 uTmp = 0;
    INPUT_OPT_CHECK(uIndex);
   #if 0
    uTmp = uHigh == 0 ? 0 : 1;

    uRet = FPGA_WRITE_MASK(CHIP_MC, REG_OPT_TXEN_CTRL,uTmp,9+2*uIndex,9+2*uIndex); /*REG_2_0028*/
   #endif
    return uRet;
}
/*****************************************************************************
 *  函数名称   : BspSetOptTxDisable(*)
 *  功能描述   : 设置光模块发送使能
 *                             
 *  读全局变量 :
 *  写全局变量 : 无
 *  输入参数   : ulIndex    - 光口索引号
                 ulHighFlag - 0:Enable 1:Disable
 *  输出参数   : none
 *  返 回 值   : BSP_OK
 *  其它说明   : 版本公共接口函数!!注意，该接口会获取光口发光控制权，只能在SOS
 *               功能中使用。如其他功能调用，请慎重！！
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),zhaoyun@2017-07-05 14:15:20,
 *  $0000000(N/A),10191426@2018-12-17 13:58:20,
 *----------------------------------------------------------------------------
 */
UINT32 g_ulTxDisableTestEn = 0;
void opttxdisable(UINT32 en) /*调试接口 长时间断链时屏蔽高层发起的SOS功能*/
{
    g_ulTxDisableTestEn = en;
}
UINT32 BspSetOptTxDisable(UINT32 ulIndex, UINT32 ulHighFlag)
{
    UINT32 ret = 0;
    UINT32 phyOptNo = 0;
    ULONG ulEnBit = 0;
    ULONG ulCfgBit = 0;
    ULONG ulMaskBit = 1;

    INPUT_OPT_CHECK(ulIndex);
    phyOptNo = BspGetPhyNoBySfpNo(ulIndex);
    if(g_ulTxDisableTestEn == 1) /*调试模式提前返回*/
    {
       return ret;
    }

    if (1 == ulHighFlag)
    {
        ulEnBit = 1;
        ulCfgBit = 1;
        ulMaskBit = 0;
    }
    else
    {
        ulEnBit = 0;
        ulCfgBit = 0;
        ulMaskBit = 1;
    }
    ret = IcHalBitWrReg(0, OPT_CPRI_PROTOCOL_CFG, 0x28, ulMaskBit, phyOptNo, phyOptNo);
    ret |= IcHalBitWrReg(0, OPT_CPRI_PROTOCOL_CFG, 0x341c, ulCfgBit, phyOptNo, phyOptNo);
    ret |= IcHalBitWrReg(0, OPT_CPRI_PROTOCOL_CFG, 0x341c, ulEnBit, phyOptNo+8, phyOptNo+8);

    return ret;
}

UINT32 BspGetDLinkOptNo(void)
{
    UINT32 retVal       = BSP_OK;
    UINT32 optDLinkNo   = 0;
    UINT32 optProperty  = 0;
    UINT32 optChipInter = 0;

    for(optDLinkNo = 0; optDLinkNo < 4; optDLinkNo ++)
    {
        retVal |= BspHalAdaptGetOptProperty(optDLinkNo, &optProperty, &optChipInter);
        if(optProperty == 1)
        {
            dbgInfoEx("%s:The downlink optical port number is [%d]. \n", __FUNCTION__, optDLinkNo);
            break;
        }
    }

    if(optProperty == 4)
    {
        return BSP_ERROR;
    }

    return optDLinkNo;
}

/*****************************************************************************
 *  函数名称   : BspSetNextLinkCmd()
 *  功能描述   : 设置下级RRU的环回/复位等命令
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ucLinkMode 0:下级RRU环回 1:下级RRU复位 2：正常
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 其它值为失败
 *  其它说明   : RRU公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 10076963@2017-04-28 , 创建
 *----------------------------------------------------------------------------
 */ 
UINT32 BspSetNextLinkCmd(UINT32 ucLinkMode)
{
    UINT32 retVal       = BSP_OK;
    UINT32 optDLinkNo   = 0;
    UINT32 optLogicNo   = 0;

    optDLinkNo = BspGetDLinkOptNo();
    optLogicNo = BspGetLogicPort(optDLinkNo);
    if((optDLinkNo == BSP_ERROR) || (optDLinkNo >= 4) || (optLogicNo >= 4))
    {
        dbgInfoEx("%s:The downlink optical port number[%d] ,optLogicNo[%d] is Not exist. \n", __FUNCTION__, optDLinkNo, optLogicNo);
        return BSP_ERROR;
    }

    switch(ucLinkMode)
    {
        case 0:
        {
            retVal |= BSPHalAdaptDlinkSetSendData(optLogicNo, 0xE555);
            retVal |= BSPHalAdaptDlinkSetSendDataEn(optLogicNo, 1);
            break;
        }
        case 1:
        {
            retVal |= BspHalAdaptSetOptRst(BIT_SET(optLogicNo));
            retVal |= BspHalAdaptSetOptRstEn(BIT_SET(optLogicNo));
            break;
        }
        case 2:
        {
            retVal |= BSPHalAdaptDlinkSetSendData(optLogicNo, 0);
            retVal |= BSPHalAdaptDlinkSetSendDataEn(optLogicNo, 0);
            retVal |= BspHalAdaptSetOptRst(0);
            retVal |= BspHalAdaptSetOptRstEn(0);
            break;
        }
        default:
            return BSP_ERROR;
    }
    return retVal;
}

/**********************************************************************
 * 函数名称: BspGetNextLinkResult
 * 功能描述: 读取下级RRU的状态
 * 输入参数: ucLinkMode 0:下级RRU环回 1:下级RRU复位
 * 输出参数:
 * 返 回 值: 0:设置成功  1:设置不成功或入参错误
 * 其它说明:
 * ---------------------------------------------------
 ***********************************************************************/
UINT32 BspGetNextLinkResult(UINT32 ucLinkMode)
{
    UINT32 retVal       = 1;
    UINT32 optDLinkNo   = 0;
    UINT32 ulTemp       = 0;
    UINT32 optLogicNo   = 0;
    UINT32 workMode     = 0;

    optDLinkNo = BspGetDLinkOptNo();
    optLogicNo = BspGetLogicPort(optDLinkNo);
    if((optDLinkNo == BSP_ERROR) || (optDLinkNo >= 4) || (optLogicNo >= 4))
    {
        dbgInfoEx("%s:The downlink optical port number[%d] ,optLogicNo[%d] is Not exist. \n", __FUNCTION__, optDLinkNo, optLogicNo);
        return 1;   /*app收到1会上报环回失败，收到BSP_ERROR会直接上报-1是一个异常值*/
    }
/* Started by AICoder, pid:rb8e99bae9sa59a14e4a0962b0df5f0539d81a1e */
    (void)BspHalAdaptGetCpriNetMode(&workMode);
    if((NET_MODE_LOAD_SHARE == workMode) || (NET_MODE_M_S == workMode))  /*负荷分担和主备没有下一级rru，不支持下级rru环回测试*/
    {
        dbgInfoEx("%s:The downlink optical port number[%d] ,optLogicNo[%d]. \n", __FUNCTION__, optDLinkNo, optLogicNo);
        dbgInfoEx("%s:The Cpri Net workMode is [%d]. \n",__FUNCTION__, workMode);
        return 1;   /*app收到1会上报环回失败*/
    }
/* Ended by AICoder, pid:rb8e99bae9sa59a14e4a0962b0df5f0539d81a1e */
    switch(ucLinkMode)
    {
        case 0:
        {
            retVal |= BSPHalAdaptDlinkGetSendData(optLogicNo, &ulTemp);
            if(0xE555 == (UINT16)ulTemp)
                retVal = 0;
            else
                retVal = 1;
            break;
        }
        case 1:
        {
            /*获取下级复位状态暂无接口*/
            break;
        }
        default:
        {
            dbgErr("\nInput Para. Err!");
            return 1;
        }
    }

    return retVal;
}
/*****************************************************************************
 *  函数名称   : BspSetOptWorkMode()
 *  功能描述   : 设置组网模式    ---这里注意多片机型负荷分担 从片也需要设置成双上联负荷分担组网
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulType --组网类型，bsppub.h定义，
                 BSP_OPT_WORK_MODE_NORMAL~BSP_OPT_WORK_MODE_SHARE_CASCADE
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 其它值为失败
 *  其它说明   : RRU公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 10076963@2017-04-28 , 创建
 *----------------------------------------------------------------------------
 */ 
UINT32 BspSetOptWorkMode(UINT32 ulType)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulNetMode  = 0;

    BspLog(LOG_LEVEL_0,"%s: ulType[%d]\n", __FUNCTION__,ulType);
    BspSetBbuPortSpecialFlag(0);    /*支持负荷分担的机型 光纤接错告警特殊处理标志恢复成正常值  所以bsp单板下如果调用BspSetOptWorkMode, 必须要再BspSetOptWorkMode之后设置 BspSetBbuPortSpeFlag(1);*/
#if (defined(MULT_PROGRESS_S) || defined(UT_FT_TEST))
      if(0 == BspGetRpuId())
      {
          return BSP_OK;   /*只需要主MGR*/
      }
      else
      {
           if(ulType == BSP_OPT_WORK_MODE_SHARE)      /*FDD没有负荷分担组网 需要高层正确传递*/
           {
               BspSetOptCpriRelation(1,1,1);     /*物理1和逻辑1 固定映射*/
               BspHalAdaptCpriCfgOptProperty(1,0,1,0);     /*物理1是上联*/
           }     /*切换组网时整机复位，从片必然是掉电复位 会按初始化参数配置恢复从片默认的光口映射关系*/
      }
#endif
    if(ulType == BSP_OPT_WORK_MODE_RING)
    {
    	BspHalAdaptCpriCfgTransLsarRstReqEn(0,0);  /*tdd环网默认不转发硬复位控制字*/
    }
    g_ulDefaultNetworkMode = ulType; /*高层下发时延值时更新TDD默认组网模式*/
    BspSaveOptWorkMode(ulType);  /*将高层下发的组网模式传递给时延模块 fdd使用*/
    ulRet = BspGetHalTopNetByBspTopNet(ulType,&ulNetMode);
	if(ulRet != BSP_OK)
	{
		dbgErr("ulType is error\n");
		return ulRet;
	}
	ulRet = BspHalAdaptSetCpriNetMode(ulNetMode);
	if(ulRet != BSP_OK)
	{
		dbgErr("WorkMode set error\n");
	}
    return ulRet;
}
/****************************************************************************
*  函数名称   : BspGetOptWorkMode(*)
*  功能描述   : 获取当前组网模式
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 组网模式，BSP_ERROR-错误
*  其它说明   : 版本公共接口函数
*-----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10076963@2017-04-24 , 创建
*-----------------------------------------------------------------------------
*/
UINT32 BspGetOptWorkMode(UINT32 ulIndex)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulHalNetMode  = 0;
    UINT32 ulBspNetMode  = 0xff;

    if(IS_NCR == BspIsNcr())
    {
        return TDD_OPT_WORK_MODE_ALONE;
    }

    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
        return 0;
    }

    if(BspGetTddSupportRingModeWorkFlag() == 1)
    {
        return g_ulDefaultNetworkMode;  /*oss获取的组网模式是app下发的全局变量，不再从底层寄存器获取组网模式*/
    }

    (void)BspHalAdaptGetCpriNetMode(&ulHalNetMode);
    ulRet = BspGetBspTopNetByHalTopNet(ulHalNetMode,&ulBspNetMode);
    if(ulRet != BSP_OK)
    {
         dbgErr("WorkMode get error\n");
    }

    return ulBspNetMode;
}

UINT32 BspGetDefaultOptWorkMode(UINT32 optIndex)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulHalNetMode  = 0;
    UINT32 ulBspNetMode  = 0xff;

    INPUT_PHYOPT_INDEX_CHECK(optIndex)

    (void)BspHalAdaptGetCpriNetMode(&ulHalNetMode);
    ulRet = BspGetBspTopNetByHalTopNet(ulHalNetMode,&ulBspNetMode);
    if(ulRet != BSP_OK)
    {
         dbgErr("WorkMode get error\n");
    }

    return ulBspNetMode;
}
/* 向高层上报组网方式 */
UINT32 BspReportOptWorkMode(VOID)
{
    UINT32 workMode = 0;

    workMode = BspGetDefaultOptWorkMode(0);

    return workMode;
}
/*****************************************************************************
 *  函数名称   : BspGetNextT14(*)
 *  功能描述   : 获取级联RRU的下一级的T14数据
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : RRU的下一级的T14数据
 *  其它说明   : RRU公共接口函数,暂时未使用，打桩
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 10076963@2017-04-28 , 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetNextT14(void)
{
    return BSP_OK;    
}
/*****************************************************************************
*  函数名称   : BspUpdateLcvThre(*)
*  功能描述   : LCV门限配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulSpeed -- 光口速率,
                定义在bsppub.h,BSP_OPT_SPEED_1P2288G~BSP_OPT_SPEED_24P33024G
                ulThre  -- 门限配置值
*  输出参数   : 无
*  返 回 值   : BSP_OK-成功,其他-错误
*  其它说明   : RRU公共接口函数,暂时未使用，打桩
 *工装使用申明: 工装使用接口，请注意波及
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10076963@2017-04-28 , 创建
*----------------------------------------------------------------------------
*/
UINT32 BspUpdateLcvThre(UINT32 ulSpeed, UINT32 ulThre)
{
    return BSP_OK;      
}


UINT32 BspOptAdaptPostCallback(FUNC_OPTADAPT_POST pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pOptAdaptPostFunc = pFunc;
    return BSP_OK;
}

UINT32 MOD_BOARD_OPT = 0;
VOID optprton(VOID)
{
    MOD_BOARD_OPT = 1;
}
VOID optprtoff(VOID)
{
    MOD_BOARD_OPT = 0;
}
/*****************************************************************************
*  函数名称   : BspGetOptCnt
*  功能描述   : 获取本板最多支持的光口数量
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ucType  0：用于光纤通讯用的光口   其它：其它类型的光口
*  输出参数   : 无
*  返 回 值   : 无
*  其它说明   : BSP公共接口函数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 宋志强2014-05-12 10:30:31, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetOptCnt(UINT32 ulType)
{   
    return BspGetOptNum();
}

/* Started by AICoder, pid:5f21ffdeecj2e3414c8c09ae20095e0302078dfb */
UINT32 BspAtCtrlGetIpAddrCallBack(FUNC_GET_IP_ADDR pFuncGetIpAddrTemp)
{
    pFuncGetIpAddr = pFuncGetIpAddrTemp;
    return BSP_OK;
}

UINT32 BspAtCtrlGetRruIdCallBack(FUNC_GET_RRU_ID pFuncGetRruIdTemp)
{
    pFuncGetRruId = pFuncGetRruIdTemp;
    return BSP_OK;
}

UINT32 BspSetRruIdNcr(VOID)
{
    UINT32 ret = 0;

    g_rruId[0] = 0x1;  //与OSS约定好，光口0默认为1
    if(NULL != pFuncGetRruId)
    {
        ret = pFuncGetRruId();
        if(BSP_ERROR == ret)
        {
            dbgErr("[%s]pFuncGetRruId failed(ret = %d)!\n", __FUNCTION__, ret);
            return BSP_ERROR;
        }

        g_rruId[1] = ret;
    }
    return BSP_OK;
}

/* Started by AICoder, pid:f6951re8f1x905c14f160baae0ca4147171181e5 */
UINT32 BspTransIpToHex(CHAR* pIpAddr)
{
    UINT32 ip[IP_NUM] = {0};
    UINT32 ipHex = 0;
    INT32 i = 0;
    INT32 j = 0;
    CHAR* tok;
    CHAR* tokBuf;

    if(NULL == pIpAddr)
    {
        dbgErr("[%s]input error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    tok = strtok_s(pIpAddr, ".", &tokBuf);
    while((tok != NULL) && (i < IP_NUM))
    {
        //coverity[cert_err34_c_violation:SUPPRESS] 
        ip[i++] = atoi(tok);
        tok = strtok_s(NULL, ".", &tokBuf);
    }

    for(j = 0; j < IP_NUM; j++) 
    {
        ipHex = (ipHex << 8) | ip[j];
    }
    dbgInfoEx("[%s]ipHex = %x\n", __FUNCTION__, ipHex);

    return ipHex;
}
/* Ended by AICoder, pid:f6951re8f1x905c14f160baae0ca4147171181e5 */

/* Started by AICoder, pid:b70ffhb9e0e5e6c14c8f0b9210a71b3308200048 */
UINT32 g_mtPowerSta = MT_POWER_OFF;
VOID BspSetMtPowerSta(UINT32 flag)
{
    g_mtPowerSta = flag;
    dbgInfoEx("[%s]set mt power %s.\n", __FUNCTION__, g_mtPowerSta ? "on" : "off");
    BspLog(LOG_LEVEL_0, "[%s]set mt power %s.\n", __FUNCTION__, g_mtPowerSta ? "on" : "off");
}

UINT32 BspGetMtPowerSta(VOID)
{
    return g_mtPowerSta;
}

FUNC_RESTART_MT p_restartMtFunc = NULL;

VOID BspMtRestartCallBack(FUNC_RESTART_MT pFunc)
{
    p_restartMtFunc = pFunc;
}

VOID BspRestartMt(UINT8 ucOptId)
{
    if(NULL != p_restartMtFunc)
    {
        return p_restartMtFunc(ucOptId);
    }

    return;
}

/* Ended by AICoder, pid:b70ffhb9e0e5e6c14c8f0b9210a71b3308200048 */

/* Started by AICoder, pid:k431dxf594y393d146a80bbe2052962e6150c5e5 */
UINT32 BspGetTcpServerIp(UINT8 ucOptId)
{
    UINT32 ret = 0;
    CHAR *ip = NULL;
    UINT32 ipHex = 0;

    if(0 == ucOptId)
    {
        return 0xC6210D02;  //通路2 MT的TCP IP固定为198.33.13.2
    }
    else if(1 == ucOptId)
    {
        if(MT_POWER_ON != g_mtPowerSta)
        {
            dbgInfoEx("[%s]mt power is off, PowerStaFlag = %d.\n", __FUNCTION__, g_mtPowerSta);
            return BSP_ERROR;  //子卡为非开机状态时，该ip置为无效
        }
        ip = malloc(NCR_IPADDR_LEN_MAX);
        if(NULL == ip)
        {
            return BSP_ERROR;
        }
        (VOID)memset_s(ip, NCR_IPADDR_LEN_MAX, 0, NCR_IPADDR_LEN_MAX);
        if(NULL != pFuncGetIpAddr)
        {
            ret = pFuncGetIpAddr(ip);
            if(BSP_OK != ret)
            {
                dbgErr("[%s]pFuncGetIpAddr failed(ret = %d)!\n", __FUNCTION__, ret);
                free(ip);
                return BSP_ERROR;
            }
            ipHex = BspTransIpToHex(ip);
            free(ip);
            return ipHex;
        }
        else
        {
            free(ip);
            return BSP_ERROR;
        }
    }
    else
    {
        return BSP_ERROR;
    }

}
/* Ended by AICoder, pid:k431dxf594y393d146a80bbe2052962e6150c5e5 */

/* Ended by AICoder, pid:5f21ffdeecj2e3414c8c09ae20095e0302078dfb */
/*****************************************************************************
*  函数名称   : BspGetRruId(*)
*  功能描述   : 获取RRU  ID
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulIndex -物理光口
*  输出参数   : 无
*  返 回 值   : BSP_ERROR:错误码,其他:RRUID
*  其它说明   : RRU公共接口函数
 *工装使用申明: 工装使用接口，请注意波及
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 100769632017-04-22 10:30:31, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetRruId(UINT32 ulIndex)
{
	UINT32 protocol = 0;
	UINT32 rruid = 0;
	UINT32 logNo = 0;
	UINT32 phyOpt = 0;
	UINT32 mainPhyOpt = 0;

    if(IS_NCR == BspIsNcr())
    {
        if(ulIndex < MAX_OPT_NUM)
        {
            dbgInfoEx("[%s]g_rruId[%d] = %d\n", __FUNCTION__, ulIndex, g_rruId[ulIndex]);
            return g_rruId[ulIndex];
        }
        else
        {
            dbgErr("[%s]input error, ulIndex = %d\n", __FUNCTION__, ulIndex);
            return BSP_ERROR;
        }
    }

	phyOpt = BspGetPhyNoBySfpNo(ulIndex);
	if(phyOpt == BSP_ERROR)
	{
		return INVALID_RRUID;
	}
	(VOID)BspHalAdaptGetMainPhyOpt(&mainPhyOpt);
	if(mainPhyOpt != phyOpt)
	{
		return INVALID_RRUID;
	}
	(VOID)BspHalAdaptGetMainLogicOpt(&logNo);
	protocol = BspGetOptCpriProtocol(0); /*入参没用*/
	if(protocol == PROCOTOL_CPRI)
	{
		rruid = BspHalAdaptGetCpriRruId(logNo);
	}
	else if(protocol == PROCOTOL_QCELL)
	{
		rruid = BspHalAdaptGetQcellRruId(logNo);
	}
	else
	{
		rruid = BspHalAdaptGetIrRruId(logNo);
	}

	return rruid;
}

/*****************************************************************************
*  函数名称   : BspGetQcellLinkCtrlX(*)
*  功能描述   : 上报解析的qcell控制字link_ctrl
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLogOptNo -逻辑光口号
*  输出参数   : 无
*  返 回 值   : BSP_ERROR:错误码
*  其它说明   : RRU公共接口函数
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 100769632017-04-22 10:30:31, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetQcellLinkCtrlX(UINT32 ulLogOptNo)
{ 
    return BspHalAdaptGetQcellLinkCtrlX(ulLogOptNo);
}

/*****************************************************************************
*  函数名称   : BspCpriCfgTransQcellLinkCtrlX(*)
*  功能描述   : 配置link_ctrl控制字
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLogOptNo -逻辑光口号
*  输出参数   : 无
*  返 回 值   : BSP_ERROR:错误码
*  其它说明   : RRU公共接口函数
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 100769632017-04-22 10:30:31, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspCpriCfgTransQcellLinkCtrlX(UINT32 ulLogOptNo, UINT32 ulLinkCtrlX)
{ 
    return BspHalAdaptCpriCfgTransQcellLinkCtrlX(ulLogOptNo,ulLinkCtrlX);
}

/*****************************************************************************
*  函数名称   : BspCpriCfgTransQcellRruId(*)
*  功能描述   : 配置本级RRU物理标识
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLogOptNo -逻辑光口号
*  输出参数   : 无
*  返 回 值   : BSP_ERROR:错误码
*  其它说明   : RRU公共接口函数
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 100769632017-04-22 10:30:31, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspCpriCfgTransQcellRruId(UINT32 ulLogOptNo, UINT32 ulRruId)
{ 
    return BspHalAdaptCpriCfgTransQcellRruId(ulLogOptNo,ulRruId);
}

/*****************************************************************************
*  函数名称   : BspGetFrTmVal(*)
*  功能描述   : 获取帧头诊断信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulLogOptNo -逻辑光口号
*  输出参数   : 无
*  返 回 值   : BSP_ERROR:错误码
*  其它说明   : RRU公共接口函数
*---------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 100769632017-04-22 10:30:31, 创建
*----------------------------------------------------------------------------
*/
INT32 BspGetFrTmVal(UINT32 ulCfgId, UINT32 ulMode)
{  
    return BspHalAdaptGetFrTmVal(ulCfgId,ulMode);
}

/**************************************************************************
 * 函数名称： _BspGetOptSfpMaxSpeed
 * 功能描述： 获取RU光模块支持的最大线速率,不能从光模块读取，主片编译不过
 * 输入参数： ulPhyOptId:物理光口号
 * 输出参数： pulSpd:获取速率
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 创建
 **************************************************************************/
UINT32 _BspGetOptSfpMaxSpeed(UINT32 ulPhyOptId)
{
    UINT32 ulRet = BSP_OK;

    ulRet = OPT_SPEED_24P33024G;  /*后续考虑从特性参数表获取*/
    MSG_DBG(MOD_BOARD_OPT, "ulPhyOptId%d MaxSpd[%d]\n", ulPhyOptId,ulRet);

    return ulRet;
}

/*****************************************************************************
 *  函数名称   : BspGetOptSpeed(*)
 *  功能描述   : 获取逻辑寄存器中光口速率原始值
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulIndex    - 芯片索引号
 *  输出参数   :
 *  返 回 值   : 光口速率,光口速率定义见 BspPub.h
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), yaoxiaoan@2013-01-06 10:32:56, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetOptSpeed(UINT32 ulIndex)
{
    UINT32 ulSpeed = 0;
    UINT32 ulPhyOpt = 0;            //默认为0

    INPUT_OPT_CHECK(ulIndex);

    ulPhyOpt = BspGetPhyNoBySfpNo(ulIndex);
    (VOID)BspHalAdaptCpriGetLineRate(ulPhyOpt,&ulSpeed);
    dbgInfoEx("%s>>Opt[%d],Spd[%d]\n",__FUNCTION__,ulIndex,ulSpeed);
    return ulSpeed;
}

UINT32 _BspGetOptSpeed(UINT32 ulIndex)
{
	return BspGetOptSpeed(ulIndex);
}

#ifndef MULT_PROGRESS_S
static UINT32 BspHGOptCheck(UINT32 ulIndex)
{
    if(NULL != g_HGOptSpeedFlag)
    {
        //判断是否是华工光模块
        BspHGSfpCdrWdCheck(ulIndex, 0);    
    }
    return BSP_OK;
}
#endif

UINT32 BspSetM0OptSpeed(UINT32 ulIndex, UINT32  ulSpd)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulPhyOptNo = 0;
    UINT32 loop = 0;
    UINT32 ulSerdesLaneRate =0;   /*serdes线速率*/
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};
    T_BspHalAdaptSerdesRxCfg rxSerdesPara = {0};
    T_BspHalAdaptM0RingInfoCfg m0RingPara = {0};
    INPUT_OPT_CHECK(ulIndex);

    switch(ulSpd)
    {
        case BSP_OPT_SPEED_9P8304G:
        {
            ulSerdesLaneRate = SERDES_RATE_9G83;
            break;
        }
        case BSP_OPT_SPEED_10P1376G:
        {
            ulSerdesLaneRate = SERDES_RATE_10G13;
            break;
        }
        case BSP_OPT_SPEED_24P33024G:
        {
            ulSerdesLaneRate = SERDES_RATE_24G33;
            break;
        }
    }

    ulPhyOptNo = BspGetPhyNoBySfpNo(ulIndex);   /*光笼编号转换到物理光口号*/
    ulRetVal = BspGetSerdesParaByPhyNo(ulPhyOptNo, &rateSerdesPara);
    if(ulRetVal != BSP_OK)
    {
        dbgErr("BspGetSerdesParaByPhyNo failed\n");
        return BSP_ERROR;
    }

    for(loop = 0; loop < OPT_RATE_TYPE; loop++)
    {
       if(rateSerdesPara.txRatePara[loop].rate == ulSerdesLaneRate)
       {
           memcpy_s(&rxSerdesPara, sizeof(T_BspHalAdaptSerdesRxCfg), &rateSerdesPara.rxRatePara[loop], sizeof(T_BspHalAdaptSerdesRxCfg));
           break;
       }
    }

    m0RingPara.uInfoValidFlag = BSP_D_INFO_VALID_FLAG;
    m0RingPara.optSpeed       = ulSpd;     /*光口速率*/
    m0RingPara.phaseMin       = rxSerdesPara.phaseMin;     /*minimum CDR opt phase (默认配-24)*/
    m0RingPara.phaseMax       = rxSerdesPara.phaseMax;     /*maximum CDR opt phase (53G配4，其他配24)*/
    m0RingPara.uVga           = rxSerdesPara.uVga;         /*VGA cfg (默认配3)*/
    m0RingPara.uCmtermCtrl    = rxSerdesPara.uCmtermCtrl;  /*term ctrl(默认配5)*/
    m0RingPara.algorithmSel   = 0; /*默认传0*/

    BspLog(LOG_LEVEL_0, "[BspSetM0OptSpeed] ulPhyNo:%d uInfoValidFlag:%x, optSpeed:%d, phaseMin:%d, phaseMax:%d, uVga:%d, uCmtermCtrl:%d, algorithmSel:%d\n",ulIndex, \
            m0RingPara.uInfoValidFlag, m0RingPara.optSpeed, m0RingPara.phaseMin, m0RingPara.phaseMax, m0RingPara.uVga, m0RingPara.uCmtermCtrl, m0RingPara.algorithmSel);
    BspHalAdaptSetM0SerdesRxInitInfo(ulIndex, &m0RingPara);

    return BSP_OK;
}

UINT32 BspOptFecModeChangeAdpt(UINT32 ulIndex)
{
    UINT32 ulFecMode =OPTPCS_FEC_TYPE_RSFEC528;          /*FEC模式*/

    if(g_ulFecModeChange[ulIndex] == 1)
    {
        ulFecMode = OPTPCS_FEC_TYPE_BYPASS;  /*对端状态不知道，所以需要切换尝试*/
    }
    if(OPT_SUPPORT_DUAL_BBU == BspGetSupportDualBbuFlag()) /* 支持双BBU机型固定FEC开 */
    {
        ulFecMode = OPTPCS_FEC_TYPE_RSFEC528;
    }
    g_ulFecModeChange[ulIndex] = (g_ulFecModeChange[ulIndex]+1)%2;

    return ulFecMode;
}

/*****************************************************************************
 *  函数名称   : BspSetOptSpeed(*)
 *  功能描述   : 设置逻辑寄存器中光口速率
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulIndex    - 芯片索引号
 *  输入参数   : ulIndex/ulPhyOptNo: 物理光口号(X=0-3对应物理光口0~3，X=4对应盲插未知光口)
 *           ulLineRate/ulSpd: BSP_OPT_SPEED_1P2288G          ((UINT32)0x0001)
                         BSP_OPT_SPEED_2P4576G          ((UINT32)0x0002)
                         BSP_OPT_SPEED_3P0720G          ((UINT32)0x0003)
                         BSP_OPT_SPEED_4P9152G          ((UINT32)0x0004)
                         BSP_OPT_SPEED_6P1440G          ((UINT32)0x0006)
                         BSP_OPT_SPEED_7P3728G          ((UINT32)0x0007)
                         BSP_OPT_SPEED_8P11008G         ((UINT32)0x0008)
                         BSP_OPT_SPEED_9P8304G          ((UINT32)0x000a)
                         BSP_OPT_SPEED_10P1376G         ((UINT32)0x000b)
                         BSP_OPT_SPEED_12P16512G        ((UINT32)0x000c)
                         BSP_OPT_SPEED_24P33024G        ((UINT32)0x0019)
                         BSP_OPT_SPEED_25P06752G        ((UINT32)0x001a)
                         BSP_OPT_SPEED_48P66048G        ((UINT32)0x0030)
                         BSP_OPT_SPEED_50P13504G        ((UINT32)0x0032)
 *  输出参数   :
 *  返 回 值   : BSP_OK:成功，其他:错误
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetOptSpeed(UINT32 ulIndex, UINT32  ulSpd)
{
    UINT32 ulRetVal = 0;
	UINT32 ulSerdesLaneRate =0;   /*serdes线速率*/
	UINT32 ulDiv =0;              /*分频比*/
	UINT32 ulFecMode =0;          /*FEC模式*/
	UINT32 ulProtocolType =0;     /*编码格式*/
	UINT32 ulPhyOptNo = 0;
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};
	INPUT_OPT_CHECK(ulIndex);

	switch(ulSpd)
	{
        case BSP_OPT_SPEED_6P1440G:
	    {
	        ulSerdesLaneRate = SERDES_RATE_6G14;
	        ulDiv = 40;  /*对应160*/
	        ulFecMode = OPTPCS_FEC_TYPE_BYPASS;
	        ulProtocolType = OPTPCS_CPRI_10B;/*设置8B10B*/
	        break;
	    }
	    case BSP_OPT_SPEED_9P8304G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_9G83;
	        ulDiv = 40;  /*对应160*/
	        ulFecMode = OPTPCS_FEC_TYPE_BYPASS;
	        ulProtocolType = OPTPCS_CPRI_10B;/*设置8B10B*/
	        break;
	    }
	    case BSP_OPT_SPEED_10P1376G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_10G13;
	        ulDiv = 40;  /*对应165*/
	        ulFecMode = OPTPCS_FEC_TYPE_BYPASS;
	        ulProtocolType = OPTPCS_CPRI_66B;/*设置64、66B*/
	        break;
	    }
	    case BSP_OPT_SPEED_24P33024G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_24G33;
	        ulDiv = 40;  /*对应396  396-1=0X18B*/
	        ulFecMode = OPTPCS_FEC_TYPE_RSFEC528;
	        ulProtocolType = OPTPCS_CPRI_66B;/*设置64、66B*/
	        ulFecMode = BspOptFecModeChangeAdpt(ulIndex);
	        break;
	    }
	}
    //第一步：lane 初始化
    ulPhyOptNo = BspGetPhyNoBySfpNo(ulIndex);   /*光笼编号转换到物理光口号*/
    ulRetVal = BspGetSerdesParaByPhyNo(ulPhyOptNo,&rateSerdesPara);
    if(ulRetVal != BSP_OK)
    {
        dbgErr("BspGetSerdesParaByPhyNo failed\n");
        return BSP_ERROR;
    }

    if(BSP_OK != _BspCheckPhyOptIsLop(ulPhyOptNo))
    {
        return BSP_ERROR;    /*不接光模块（电模块或者不接）不应该配置serdes*/
    }

#ifndef MULT_PROGRESS_S
    BspHGOptCheck(ulIndex);
    //关闭/打开CDR  按硬件要求调整顺序到serdes加载之前
    if(BSP_OPT_SPEED_24P33024G == BspGetSfpMaximalUsedbleSpeed(ulIndex))
    {
        if(BSP_OPT_SPEED_24P33024G == ulSpd)
        {
            BspOpenSfpCdr(ulIndex,1);  //打开CDR
        }
        else
        {
            BspOpenSfpCdr(ulIndex,0);
        }
    }
#endif
    if(BSP_ERROR == BspGetMainPhyOpt())  /*主光口未识别出来时才能关，否则级联时下联口影响上联口*/
    {
        BspHalAdaptSetCrmOptCrpiRefClkOeDisable(ulPhyOptNo);  /*切速率之前软件选择  关闭恢复钟 0xd4c00b28--0x1000*/
    }

    ulRetVal = BspHalChangeSerdesTxLaneRate(0,ulPhyOptNo,ulSerdesLaneRate,&rateSerdesPara);
    if(ulRetVal != BSP_OK)
    {
         dbgErr("BspHalChangeSerdesTxLaneRate failed\n");
    }
#ifdef _BSP_WITH_WFS
#ifndef MULT_PROGRESS_S
    if(BspIsSpecialQsfp(ulIndex) == HIGH_SPEED_CABLE_FOR_OPT)   /*高速线缆  工装急需版本 公共修改延后*/
    {
        BspHalAdaptLycaAlgorithmSel(1);
        BspChangeHighCableSpeed(&rateSerdesPara);
    }
    else
    {
        BspHalAdaptLycaAlgorithmSel(0);
    }
#endif
#endif
    ulRetVal = BspHalChangeSerdesRxLaneRate(0,ulPhyOptNo,ulSerdesLaneRate,&rateSerdesPara);
    if(ulRetVal != BSP_OK)
    {
        dbgErr("BspHalChangeSerdesRxLaneRate failed\n");
    }
    //第二步：配置lane 线速率和分频比
    ulRetVal = BspHalAdaptCpriCfgLineRate(ulPhyOptNo,ulSpd); /*暂时先这样修改　后续光口自适应再完善*/
    ulRetVal = BspHalAdaptCpriCfgLineRate(PHY_OPT_UNKNOW,ulSpd); /*暂时先这样修改　后续光口自适应再完善*/
    ulRetVal |= BspHalAdaptSetDivClk(0,ulSpd,ulDiv,ulPhyOptNo);//wric(0xd4c00b08+phyOptNo*4,395);   /*BspHalAdaptSetDivClk(BSP_OPT_SPEED_24P33024G,40);*/
    BspHalAdaptSetCrmOptCrpiRefClkLogic();     /*切速率之后，硬件选择，时钟有输出 0xd4c00b28 --0x800 */
    //第三步：关闭/打开FEC
    g_ulOptPcsCfgEn = 1;
    BspHalAdaptPcsSetGloableCfgEn(ulPhyOptNo,1);
	BspSysMsDelay(10);
    BspHalAdaptPcsSetLinkProtocol(ulPhyOptNo,ulProtocolType);   //tstPcsPrintSpeedMode
	BspSysMsDelay(10);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, RX, DISABLE);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, TX, DISABLE);
	BspSysMsDelay(10);
    BspHalAdaptPcsSetLinkFecMode(ulPhyOptNo,ulFecMode);
	BspSysMsDelay(10);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, RX, ENABLE);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, TX, ENABLE);
	BspSysMsDelay(10);
    BspHalAdaptPcsSetGloableCfgEn(ulPhyOptNo,0);
    BspSysMsDelay(10);
    (VOID)BspSetOptLosAlmFromPcs(ulPhyOptNo);  /*如果从25G 切到10.1/9.8 此寄存器不切过来 影响建链 所以流程中也必须配置*/
    BspSetOptSpdChgFlag(ulPhyOptNo,1);
    g_ulOptPcsCfgEn = 0;

    return ulRetVal;
}

#ifdef _BSP_WITH_WFS
UINT32 BspChangeHighCableSpeed(T_OPTRATE_SERDES_PARAM *pSerdesPara)
{
    UINT32 speedIndex = 0;

    INPUT_POINTER_CHECK(pSerdesPara);

    for (speedIndex = 0; speedIndex < OPT_RATE_TYPE; speedIndex++)
    {
        if(pSerdesPara->txRatePara[speedIndex].rate == SERDES_RATE_9G83)
        {
            dbgInfoEx("speed index = %d\n", speedIndex);
            break;
        }
    }
    if (speedIndex >= OPT_RATE_TYPE)
    {
        dbgInfo("not find 9.8G!\n");
        return BSP_ERROR;
    }
    dbgInfoEx("uVga %d uCmtermCtrl %d\n",pSerdesPara->rxRatePara[speedIndex].uVga,pSerdesPara->rxRatePara[speedIndex].uCmtermCtrl);
    pSerdesPara->rxRatePara[speedIndex].uVga = 3;
    pSerdesPara->rxRatePara[speedIndex].uCmtermCtrl = 5;     /*9.8G 参数由2 6 改成3 5 硬件最新要求改成3 5*/
    dbgInfoEx("uVga %d uCmtermCtrl %d\n",pSerdesPara->rxRatePara[speedIndex].uVga,pSerdesPara->rxRatePara[speedIndex].uCmtermCtrl);

    return BSP_OK;
}

#endif

UINT32 BspSetOptFecMode(UINT32 ulIndex)
{
    UINT32 ulPhyOptNo = 0;
    UINT32 ulFecMode =0;          /*FEC模式*/

    ulFecMode = OPTPCS_FEC_TYPE_RSFEC528;
    if(1 == g_ulFecModeChange[ulIndex])
    {
        ulFecMode = OPTPCS_FEC_TYPE_BYPASS;  /*对端状态不知道，所以需要切换尝试*/
    }
    g_ulFecModeChange[ulIndex] = (g_ulFecModeChange[ulIndex] + 1) % 2;

    ulPhyOptNo = BspGetPhyNoBySfpNo(ulIndex);   /*光笼编号转换到物理光口号*/
    //关闭/打开FEC
    g_ulOptPcsCfgEn = 1;
    BspHalAdaptPcsSetGloableCfgEn(ulPhyOptNo, 1);
    BspSysMsDelay(10);
    BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, RX, DISABLE);
    BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, TX, DISABLE);
    BspSysMsDelay(10);
    BspHalAdaptPcsSetLinkFecMode(ulPhyOptNo,ulFecMode);
    BspSysMsDelay(10);
    BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, RX, ENABLE);
    BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, TX, ENABLE);
    BspSysMsDelay(10);
    BspHalAdaptPcsSetGloableCfgEn(ulPhyOptNo, 0);
    BspSysMsDelay(10);
    g_ulOptPcsCfgEn = 0;

    return BSP_OK;
}
/*级联场景 第一级下联口异常 导致第二级异常 这个接口只处理下联口*/
UINT32 BspResetCrmOptCpriLane(UINT32 ulPhyNo)
{
    UINT32 ulRet0 = BSP_OK;
    UINT32 ulRet1 = BSP_OK;

    ulRet0 = BspHalAdaptGetCpriCdcResyncSta(ulPhyNo); /*CDC失步*/
    ulRet1 = BspHalAdaptGetSerdesFsmStatus(ulPhyNo);  /*状态机是否正常*/
    if((ulRet0 != BSP_OK )&&(ulRet1 == BSP_OK))
    {
        (VOID)BspHalAdaptCrmOptCpriLaneReset(ulPhyNo, 0); /*复位*/
        BspSysMsDelay(1);
        (VOID)BspHalAdaptCrmOptCpriLaneReset(ulPhyNo, 1); /*释放*/
        dbgInfoEx("BspResetCrmOptCpriLane ulPhyNo %d\n",ulPhyNo);
        BspLog(LOG_LEVEL_0,"BspResetCrmOptCpriLane ulPhyNo %d\n",ulPhyNo);
    }
    return BSP_OK;
}
UINT32 _BspReCfgOptRxSerdes(UINT32 ulIndex, UINT32  ulSpd)
{
    UINT32 ulRetVal = 0;
    UINT32 ulSerdesLaneRate =0;   /*serdes线速率*/
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};
    INPUT_OPT_CHECK(ulIndex);

    switch(ulSpd)
    {
        case BSP_OPT_SPEED_9P8304G:
        {
            ulSerdesLaneRate = SERDES_RATE_9G83;
            break;
        }
        case BSP_OPT_SPEED_10P1376G:
        {
            ulSerdesLaneRate = SERDES_RATE_10G13;
            break;
        }
        case BSP_OPT_SPEED_24P33024G:
        {
            ulSerdesLaneRate = SERDES_RATE_24G33;
            break;
        }
        default:
        {
            break;
        }
    }
    (VOID)BspResetCrmOptCpriLane(ulIndex);
    //第一步：lane 初始化
    ulRetVal = BspGetSerdesParaByPhyNo(ulIndex,&rateSerdesPara);
    if(ulRetVal != BSP_OK)
    {
        dbgErr("BspGetSerdesParaByPhyNo failed\n");
        return ERROR;
    }
    ulRetVal = BspHalChangeSerdesRxLaneRate(0,ulIndex,ulSerdesLaneRate,&rateSerdesPara);
    if(ulRetVal != BSP_OK)
    {
        dbgErr("BspHalChangeSerdesRxLaneRate failed\n");
    }

    /*serdes的RX如果异常或者重新初始化，RX的PCS有概率工作异常；当前实现没有复位RX的PCS，代码中增加PCS流程*/
    g_ulOptPcsCfgEn = 1;
    BspHalAdaptPcsSetGloableCfgEn(ulIndex, 1);
    BspHalAdaptPcsSet1XLinkCfgEn(ulIndex, RX, DISABLE);
    BspSysMsDelay(10);
    BspHalAdaptPcsSet1XLinkCfgEn(ulIndex, RX, ENABLE);
    BspHalAdaptPcsSetGloableCfgEn(ulIndex, 0);
    g_ulOptPcsCfgEn = 0;

    return ulRetVal;
}



UINT32 BspQcellGetL2ssTrxpEn(UINT32 *udPortEnPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 tempEn = 0;

    for (UINT32 portNum = 0; portNum < 16; portNum++)
    {
        tempEn = IcHalApiL2ssTrxpGetEn(portNum,TX);
        udPortEnPara[portNum] = tempEn;
    }

    return retVal;
}

UINT32 BspQcellSetL2ssTrxpEnOff(VOID)
{
    UINT32 retVal = BSP_OK;

    for (UINT32 portNum = 0; portNum < 16; portNum++)
    {

        if (1 == portNum || 15 == portNum || 3 == portNum || 13 == portNum || 2 == portNum)
        /* qcell  1和15口是debug口  不用关 */
        /*3和13口是主从信令传输的端口，2口是多片debug网口，单片和多片的板子都不需要关闭*/
        {
            continue;
        }
        
        retVal |= BspHalAdaptTrxpEnOrDisable(portNum,DISABLE);
    }
    
    return retVal;

}

UINT32 BspQcellSetL2ssTrxpEnOn(UINT32 *udPortEnPara)
{
    UINT32 retVal = BSP_OK;

    for (UINT32 portNum = 0; portNum < 16; portNum++)
    {
        if(1 == udPortEnPara[portNum])
        {
            retVal |= BspHalAdaptTrxpEnOrDisable(portNum,ENABLE);
            udPortEnPara[portNum] = 0; /* 重置0 */
            dbgInfo("open qcell l2ss trxp port:%d \n",portNum);
        }
    }
    
    return retVal;

}

/*****************************************************************************
 *  函数名称   : BspQcellSetOptSerdesRate(*)
 *  功能描述   : 设置逻辑寄存器中光口速率
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulIndex    - 芯片索引号
 *  输入参数   : ulIndex/ulPhyOptNo: 物理光口号(X=0-3对应物理光口0~3，X=4对应盲插未知光口)
 *           ulLineRate/ulSpd: BSP_OPT_SPEED_1P2288G          ((UINT32)0x0001)
                         BSP_OPT_SPEED_2P4576G          ((UINT32)0x0002)
                         BSP_OPT_SPEED_3P0720G          ((UINT32)0x0003)
                         BSP_OPT_SPEED_4P9152G          ((UINT32)0x0004)
                         BSP_OPT_SPEED_6P1440G          ((UINT32)0x0006)
                         BSP_OPT_SPEED_7P3728G          ((UINT32)0x0007)
                         BSP_OPT_SPEED_8P11008G         ((UINT32)0x0008)
                         BSP_OPT_SPEED_9P8304G          ((UINT32)0x000a)
                         BSP_OPT_SPEED_10P1376G         ((UINT32)0x000b)
                         BSP_OPT_SPEED_12P16512G        ((UINT32)0x000c)
                         BSP_OPT_SPEED_24P33024G        ((UINT32)0x0019)
                         BSP_OPT_SPEED_25P06752G        ((UINT32)0x001a)
                         BSP_OPT_SPEED_48P66048G        ((UINT32)0x0030)
                         BSP_OPT_SPEED_50P13504G        ((UINT32)0x0032)
 *  输出参数   :
 *  返 回 值   : BSP_OK:成功，其他:错误
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspQcellSetOptSerdesRate(UINT32 ulIndex, UINT32  ulSpd)
{
    UINT32 ulRetVal = 0;
	UINT32 ulSerdesLaneRate = 0;  /* serdes线速率 */
	UINT32 ulProtocolType =0;     /* 编码格式 */
    /*UINT32 ulDiv =0; */             /* 分频比 */
	UINT32 ulFecMode =0;          /* FEC模式 */
    UINT32 ulPhyOptNo = 0;
	UINT32 loop = 0;
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};
    E_OPT_WORKMODE optWorkMode = E_OPT_MODE_QCELL;
	INPUT_OPT_CHECK(ulIndex);
	switch(ulSpd)
	{
	    case BSP_OPT_SPEED_10P1376G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_10G31;
	        /* ulDiv = 40; */ /* 对应165 */
	        ulFecMode = OPTPCS_FEC_TYPE_BYPASS;
	        ulProtocolType = OPTPCS_ETH_25G_10G_5G_66B;/* 设置64、66B */
            dbgInfo("%s:  OptAdapt: SerdesRate:%d !\n", __FUNCTION__,ulSerdesLaneRate);
	        break;
	    }
	    case BSP_OPT_SPEED_24P33024G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_25G78;
	        /* ulDiv = 40; */ /* 对应396  396-1=0X18B */
	        ulFecMode = OPTPCS_FEC_TYPE_RSFEC528;
	        ulProtocolType = OPTPCS_ETH_25G_10G_5G_66B;/* 设置64、66B */
	        if(g_ulFecModeChange[ulIndex] == 1)
	        {
	        	ulFecMode = OPTPCS_FEC_TYPE_BYPASS;  /* 对端状态不知道，所以需要切换尝试 */
	        }
	        g_ulFecModeChange[ulIndex] = (g_ulFecModeChange[ulIndex]+1)%2;
            dbgInfo("%s:  OptAdapt: SerdesRate:%d !\n", __FUNCTION__,ulSerdesLaneRate);
	        break;
	    }
        default:
        {
            break;
        }
	}
    /* lane 初始化 */
    ulPhyOptNo = ulIndex;
	ulRetVal = BspGetSerdesParaByPhyNo(ulPhyOptNo,&rateSerdesPara);
    dbgInfo("%s:OptAdapt: BspGetSerdesParaByPhyNo, retVal:%d !\n", __FUNCTION__,ulRetVal);
	if(ulRetVal != BSP_OK)
	{
		dbgErr("OptAdapt: BspGetSerdesParaByPhyNo failed !\n");
		return ERROR;
	}
    for(loop = 0; loop< OPT_RATE_TYPE; loop++)
    {
        if(rateSerdesPara.txRatePara[loop].rate == ulSerdesLaneRate)
        {
            break;
        }
    }
    dbgInfo("%s: loop:%d !\n", __FUNCTION__,loop);
    if(loop == OPT_RATE_TYPE) /* 电口 */
    {
        return BSP_ERROR;
    }
#ifndef MULT_PROGRESS_S
    /* 关闭/打开CDR  按硬件要求调整顺序到serdes加载之前 ,和李玉确认25G光膜块自适应到10G时要关CDR。*/
    if(BSP_OPT_SPEED_24P33024G == BspGetSfpMaximalUsedbleSpeed(ulIndex))
    {
        if((BSP_OPT_SPEED_24P33024G == ulSpd) && (SERDES_RATE_25G78 == ulSerdesLaneRate) )
        {
            ulRetVal = BspOpenSfpCdr(ulIndex,1);  /* 打开CDR */
            dbgInfo("%s:  OptAdapt: openCdr:%d !\n", __FUNCTION__,ulRetVal);
        }
        else
        {
            BspOpenSfpCdr(ulIndex,0);
            dbgInfo("%s:  OptAdapt: closeCdr:%d !\n", __FUNCTION__,ulRetVal);
        }
    }
#endif
	ulRetVal = BspHalAdaptSetCrmOptCrpiRefClkOeDisable(ulPhyOptNo);  /* 切速率之前软件选择 关闭恢复钟 */

    /* PCS全局使能打开 */
    BspHalAdaptPcsSetGloableCfgEn(ulPhyOptNo,ENABLE);
    BspHalAdaptPcsSetPostGloableCfgEn(ulPhyOptNo,ENABLE);
	BspSysMsDelay(10);

    /* 关闭 trxp 和 xmac */
    BspHalNtlXmacCtrl(optWorkMode,ulPhyOptNo,DISABLE);
    BspQcellSetL2ssTrxpEnOff();

    /* 关闭 flow_token_en 和 tx/rx_patch_en */
    BspSysMsDelay(10);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, RX, DISABLE);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, TX, DISABLE);
    BspHalAdaptPcsFlowTokenEn(ulPhyOptNo,DISABLE);

    /* serdes 速率改配 */
	ulRetVal = BspHalChangeSerdesTxLaneRate(0,ulPhyOptNo,ulSerdesLaneRate,&rateSerdesPara);
    dbgInfo("%s:  OptAdapt: BspHalChangeSerdesTxLaneRate:%d !\n", __FUNCTION__,ulRetVal);  
    BspSysMsDelay(10);
    ulRetVal = BspHalChangeSerdesRxLaneRate(0,ulPhyOptNo,ulSerdesLaneRate,&rateSerdesPara);
    dbgInfo("%s:  OptAdapt: BspHalChangeSerdesRxLaneRate:%d !\n", __FUNCTION__,ulRetVal);

    /* PCS 配置 */
    BspHalAdaptPcsSetLinkProtocol(ulPhyOptNo,ulProtocolType);
	BspSysMsDelay(10);
    BspHalAdaptPcsSetLinkFecMode(ulPhyOptNo,ulFecMode);

    /* 打开 flow_token_en 和 tx/rx_patch_en */
    BspSysMsDelay(10);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, RX, ENABLE);
	BspHalAdaptPcsSet1XLinkCfgEn(ulPhyOptNo, TX, ENABLE);
    BspHalAdaptPcsFlowTokenEn(ulPhyOptNo,ENABLE);

    /* PCS全局使能关闭 */
	BspSysMsDelay(10);
    BspHalAdaptPcsSetGloableCfgEn(ulPhyOptNo,DISABLE);
    BspHalAdaptPcsSetPostGloableCfgEn(ulPhyOptNo,DISABLE);
    
    return ulRetVal;
}
/* Started by AICoder, pid:5190ep559bsebc914e92088a001167260cc98fa0 */
/*****************************************************************************
 *  函数名称   : BspQcellSetOptRoeRate(*)
 *  功能描述   : 设置逻辑寄存器中光口速率
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulRoeRate    - Roe速率
 *              10G填写：10000000 25G填写：25000000
 *  输出参数   :
 *  返 回 值   : BSP_OK:成功，其他:错误
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspQcellSetOptRoeRate(UINT32 ulRoeRate, UINT32 ulSpd)
{
    UINT32 ulRetVal = 0;
    /* UINT32 serdesLaneRate = 0; */
	
    switch(ulSpd)
	{
	    case BSP_OPT_SPEED_10P1376G:
	    {
	    	/* serdesLaneRate = BSP_SERDES_SPEED_10P3125G; */
	        break;
	    }
	    case BSP_OPT_SPEED_24P33024G:
	    {
	    	/* serdesLaneRate = BSP_SERDES_SPEED_25P7812G; */
	        break;
	    }
        default:
        {
            break;
        }
	}

    BspSysMsDelay(100);
    ulRetVal = BspHalAdaptRoeQcellAdjust(ulRoeRate); /* 10G填写：10000000 25G填写：25000000 */
    dbgInfo("%s:  OptAdapt: BspHalAdaptRoeQcellAdjust:%d !\n", __FUNCTION__,ulRetVal);
    return ulRetVal;
}
/* Ended by AICoder, pid:5190ep559bsebc914e92088a001167260cc98fa0 */
/*****************************************************************************
 *  函数名称   : BspQcellSetOptCpriRate(*)
 *  功能描述   : 设置逻辑寄存器中光口速率
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   : BSP_OK:成功，其他:错误
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspQcellSetOptCpriRate(UINT32 ulIndex, UINT32  ulSpd)
{
    UINT32 ulRetVal = 0;
	UINT32 serdesLaneRate = 0;    /* serdes线速率 */
	UINT32 ulDiv =0;              /* 分频比  */
	/*UINT32 ulFecMode =0;*/          /* FEC模式 */
	/*UINT32 ulProtocolType =0;*/     /* 编码格式 */
	UINT32 ulPhyOptNo = 0;
	INPUT_OPT_CHECK(ulIndex);
	switch(ulSpd)
	{
	    case BSP_OPT_SPEED_10P1376G:
	    {
	    	serdesLaneRate = BSP_SERDES_SPEED_10P3125G;
	        ulDiv = 40;  /*对应165*/
	        /*ulFecMode = OPTPCS_FEC_TYPE_BYPASS;
	        ulProtocolType = OPTPCS_ETH_25G_10G_5G_66B;*//*设置64、66B*/
	        break;
	    }
	    case BSP_OPT_SPEED_24P33024G:
	    {
	    	serdesLaneRate = BSP_SERDES_SPEED_25P7812G;
	        ulDiv = 40;  /*对应396  396-1=0X18B*/
	        /*ulFecMode = OPTPCS_FEC_TYPE_RSFEC528;
	        ulProtocolType = OPTPCS_ETH_25G_10G_5G_66B;*//*设置64、66B*/
	        if(g_ulFecModeChange[ulIndex] == 1)
	        {
	        	/*ulFecMode = OPTPCS_FEC_TYPE_BYPASS;*/  /*对端状态不知道，所以需要切换尝试*/
	        }
	        g_ulFecModeChange[ulIndex] = (g_ulFecModeChange[ulIndex]+1)%2;
	        break;
	    }
        default:
        {
            break;
        }
	}
    
    ulPhyOptNo = ulIndex;

    ulRetVal = BspHalAdaptCpriCfgLineRate(ulPhyOptNo,ulSpd); 
    dbgInfo("%s:  OptAdapt: BspHalAdaptCpriCfgLineRate:%d !\n", __FUNCTION__,ulRetVal);

    BspSysMsDelay(30);
    ulRetVal |= BspHalAdaptSetDivClk(0,serdesLaneRate,ulDiv,ulPhyOptNo);//wric(0xd4c00b08+phyOptNo*4,395);   /*BspHalAdaptSetDivClk(BSP_OPT_SPEED_24P33024G,40);*/
    dbgInfo("%s:  OptAdapt: BspHalAdaptSetDivClk:%d !\n", __FUNCTION__,ulRetVal);
    
    BspSysMsDelay(30);
    ulRetVal |= BspHalAdaptSetCrmOptECpriLaneSetDivClk(0,serdesLaneRate,ulPhyOptNo);
    dbgInfo("%s:  OptAdapt: BspHalAdaptSetCrmOptECpriLaneSetDivClk:%d !\n", __FUNCTION__,ulRetVal);

    return ulRetVal;
}
/*****************************************************************************
 *  函数名称   : BspQcellSetCrmOptCpriRefClkSoft(*)
 *  功能描述   : Qcell光口自适应流程中打开恢复钟
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   : BSP_OK:成功，其他:错误
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspQcellSetCrmOptCpriRefClkSoft(UINT32 laneIdx)
{
	 UINT32 pStatus = 0;
     UINT32 pStatusTemp = 0;
	 UINT32 uloop =0;
	 UINT32 date =0;
     UINT32 retVal = BSP_OK;
	  for(uloop=0;uloop<15;uloop++)
	  {
	  	  BspSysMsDelay(10);
	      BspHalAdaptPcsGetLinkPcsSta(0,&pStatusTemp);
          pStatus = (pStatusTemp)&(pcsMask);/* 以前是0x3f，只要低6bit，现在加上了12、13bit，变成pcsMask */
	      if(0x3 == pStatus)
	      {
	          dbgInfo("funcet %s  line %d, pStatus:%d!\n", __FUNCTION__,__LINE__,pStatus);
	      	  date++;
	      }
	      if(0x3 != pStatus)
	      {
	          dbgInfo("funcet %s  line %d, pStatus:%d!\n", __FUNCTION__,__LINE__,pStatus);
	       	  date = 0;
	      }
	      if(date == 5 )
	      {
	          dbgInfo("funcet %s  line %d, pStatus:%d!\n", __FUNCTION__,__LINE__,pStatus);
	      	  break;
	      }
	  }
	  retVal = BspHalAdaptSetCrmOptCpriRefClkSoft(laneIdx);
      dbgInfo("%s:  OptAdapt: BspHalAdaptSetCrmOptCpriRefClkSoft retVal: %d !\n", __FUNCTION__,retVal);
	  return BSP_OK;
}

/* 记录光口链接断链的状态 */
VOID BspOptRecordLinkBrokenState(VOID)
{
    BspHalAdaptRecordLinkBrokenState();
}

/*****************************************************************************
 *  函数名称   : BspQcellGetOptPcsSta(*)
 *  功能描述   : Qcell光口自适应流程获取pcs状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   : 0x3:成功，其他:错误
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspQcellGetOptPcsSta(UINT32 ulPhyOpt)
{
    UINT32 pStatus = 0;
    UINT32 pStatusTemp = 0;
    UINT32 uloop =0;
    UINT32 date =0;
    UINT32 retVal = BSP_ERROR;
    for(uloop=0;uloop<15;uloop++)
    {
        BspSysMsDelay(10);
        BspHalAdaptPcsGetLinkPcsSta(ulPhyOpt,&pStatusTemp); 
        pStatus = (pStatusTemp)&(pcsMask);/* 以前是0x3f，只要低6bit，现在加上了12、13bit，变成pcsMask */
        if(0x3 == pStatus)
        {
            date++;
        }
        if(0x3 != pStatus)
        {
            dbgInfo("judge pcsSta pre optAdapt: funcet %s  line %d, pStatus:%d!\n", __FUNCTION__,__LINE__,pStatus);
            date = 0;
        }
        if(date == 5 )
        {
            pStatus = 0x3;
            break;
        }
    }
    if (0x3 == pStatus)
    {
        retVal = BSP_OK;
    }

    if(retVal != BSP_OK && RRU_PB_BBU == BspGetPbOrBbuMode())
    {
        //pcs状态不正常时
        BspLog(LOG_LEVEL_0,"funcet %s  line %d, ulPhyOpt %d pStatus 0x%x;pcs status is not ok! \n", __FUNCTION__, __LINE__, ulPhyOpt, pStatus); //pcs状态log记录
        BspOptRecordLinkBrokenState();//光口链接断链状态记录
    
    }
    
    return retVal;
}

/* 给app用的光口状态判断接口,只通过获取一次pcs的状态判断，app那边每隔一秒调一次*/
UINT32 BspQcellGetOptSta(UINT32 ulPhyOpt)
{
    UINT32 retVal = BSP_ERROR;
    
    if( (BSP_OK == BspHalAdaptQcellAdaptGetOptLinkStatus()) && (BSP_OK == BspHalAdaptCrmOptGetCrpiRefClkSta(ulPhyOpt)))
    {
        retVal = BSP_OK;
    }  
    
    return retVal;
}

/* 注意：这个函数专门为UT覆盖率不够而写，这个接口不用，可以随意更改*/
/* Started by AICoder, pid:r7663g2bcalc77d14e5709bde0e80b4436b74687 */
UINT32 BspQcellGetOptStaTemp(UINT32 ulPhyOpt, UINT32 *pStatus)
{
    UINT32 retVal = BSP_ERROR;

    if( (0 == ulPhyOpt))
    {
        *pStatus = BIT_SET(0);
        retVal = BSP_OK;
        return retVal;
    }

    if( (1 == ulPhyOpt))
    {
        *pStatus = BIT_SET(1);
        retVal = BSP_OK;
        return retVal;
    }

    if( (2 == ulPhyOpt))
    {
        *pStatus = BIT_SET(2);
        retVal = BSP_ERROR;
        return retVal;
    }

    if( (3 == ulPhyOpt))
    {
        *pStatus = BIT_SET(3);
        retVal = BSP_ERROR;
        return retVal;
    }

    if( (4 == ulPhyOpt))
    {
        *pStatus = BIT_SET(4);
        retVal = BSP_OK;
        return retVal;
    }

    if( (5 == ulPhyOpt))
    {
        *pStatus = BIT_SET(4);
        retVal = BSP_ERROR;
        return retVal;
    }

    if( (6 == ulPhyOpt))
    {
        *pStatus = BIT_SET(4);
        retVal = BSP_OK;
        return retVal;
    }

    if( (7 == ulPhyOpt))
    {
        *pStatus = BIT_SET(4);
        retVal = BSP_OK;
        return retVal;
    }
    
    return retVal;
}
/* Ended by AICoder, pid:r7663g2bcalc77d14e5709bde0e80b4436b74687 */

/* 给bsp速率自适应用，获取15次pcs状态 */
UINT32 BspQcellGetOptStatus(UINT32 ulPhyOpt)
{
    UINT32 retVal = BSP_ERROR;

    if( (BSP_OK == BspQcellGetOptPcsSta(ulPhyOpt)) )
    {
        retVal = BSP_OK;
    }  
    
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspSetOptSpeed(*)
 *  功能描述   : 设置逻辑寄存器中光口速率
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulIndex    - 芯片索引号
 *  输入参数   : ulIndex/ulPhyOptNo: 物理光口号(X=0-3对应物理光口0~3，X=4对应盲插未知光口)
 *           ulLineRate/ulSpd: BSP_OPT_SPEED_1P2288G          ((UINT32)0x0001)
                         BSP_OPT_SPEED_2P4576G          ((UINT32)0x0002)
                         BSP_OPT_SPEED_3P0720G          ((UINT32)0x0003)
                         BSP_OPT_SPEED_4P9152G          ((UINT32)0x0004)
                         BSP_OPT_SPEED_6P1440G          ((UINT32)0x0006)
                         BSP_OPT_SPEED_7P3728G          ((UINT32)0x0007)
                         BSP_OPT_SPEED_8P11008G         ((UINT32)0x0008)
                         BSP_OPT_SPEED_9P8304G          ((UINT32)0x000a)
                         BSP_OPT_SPEED_10P1376G         ((UINT32)0x000b)
                         BSP_OPT_SPEED_12P16512G        ((UINT32)0x000c)
                         BSP_OPT_SPEED_24P33024G        ((UINT32)0x0019)
                         BSP_OPT_SPEED_25P06752G        ((UINT32)0x001a)
                         BSP_OPT_SPEED_48P66048G        ((UINT32)0x0030)
                         BSP_OPT_SPEED_50P13504G        ((UINT32)0x0032)
 *  输出参数   :
 *  返 回 值   : BSP_OK:成功，其他:错误
 *  其它说明   : 版本公共接口函数
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetOptSpeedQcell(UINT32 ulIndex, UINT32  ulSpd)
{
    UINT32 ulVal = 0;

    ulVal = BspHalAdaptCpriCfgLineRate(ulIndex,ulSpd); /*暂时先这样修改　后续光口自适应再完善*/
    return ulVal;
}

/**************************************************************************
 * 函数名称： _BspSetOptSpeed
 * 功能描述： 配置物理光口速率
 * 输入参数： ulPhyOptId:物理光口号
              ulSpd: 速率
 * 输出参数： 无
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspSetOptSpeed(UINT32 ulPhyOptId, UINT32 ulSpd)//DPDIC类型对接bbu 25g速率 FEC没有关闭的时候，而且fec类型有要求
{
    UINT32 ulOptId = 0;

    ulOptId = BspGetSfpNoByPhyNo(ulPhyOptId);
    return BspSetOptSpeed(ulOptId, ulSpd);

}

/*  光口自适应暂时注释
UINT32 _BspQcellSetOptSpeed(UINT32 ulPhyOptId, UINT32 ulSpd)//DPDIC类型对接bbu 25g速率 FEC没有关闭的时候，而且fec类型有要求
{
    return BspQcellSetOptSpeed(ulPhyOptId, ulSpd);

} */

UINT32 BspSetPValue(VOID)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 ulRet=0;
    UINT32 ethP = 0;
    UINT32 ullogicOpt = 0;

    IcHalOptNetSetTxPPoint(ullogicOpt,0,0);
    IcHalOptNetSetRxPPoint(ullogicOpt,0,0);

    //IcHalOptNetSetTxPPoint(ullogicOpt,1,ethP & 0x1f);
    //IcHalOptNetSetRxPPoint(ullogicOpt,1,ethP & 0x1f);

    //ullogicOpt = 1;
    //IcHalOptNetSetTxPPoint(ullogicOpt,1,ethP & 0x1f);
    //IcHalOptNetSetRxPPoint(ullogicOpt,1,ethP & 0x1f);    

    return ulRet;
#endif
    return BSP_OK;
}

UINT32 BspGetOptMacAddr(UINT8 *pStr, UINT32 optId)
{
    INPUT_POINTER_CHECK(pStr);

    pStr[0] = 0xa;
    pStr[1] = 0x0;
    pStr[2] = 0xd;
    pStr[3] = 0xd;
    pStr[4] = BspGetRruId(BspGetCurrentFiberPort())>>4;
    pStr[5] = BspGetRruId(BspGetCurrentFiberPort())%16;
    
    return BSP_OK;
}

UINT32 BspGetOptIpAddr(UINT8 *pStr, UINT32 optId)
{
    CHAR ethName[8] = {"eth1"}; //后续支持多光口需要从其他接口获取

    if (pStr == NULL)
    {
        return BSP_ERROR;
    }
    
    if(BspGetBootpOptNum() > 1)
	{
		BspGetOptEthName(optId,ethName,sizeof(ethName)/sizeof(ethName[0]));
	}

    return BspGetIp((const char *)ethName,pStr);
}


//获取和设置bbuShelfIndex，/*获取和设置bbuShelfIndex，和高层确认需要使用*/
UINT32 BspGetBbuShelfIndex(UINT32 optIndex)
{   
    INPUT_OPT_CHECK(optIndex);	    
    return BspGetOptBbuFramer(optIndex);
}

UINT32 BspSetBbuFramerIndex(UINT32 rruOpt,UINT32 framerNo)/*和高层确认需要使用*/
{   
    INPUT_OPT_CHECK(rruOpt);	 
    return BspSetOptBbuFramer(rruOpt, framerNo);
}


UINT32 BspSetRruMac(UINT32 rruOpt,UINT8 *mac,UINT32 size)//在optctl_a.c中返回BSP_OK。在optctrl_tdd.c，设置FPGA寄存器
{   
    return BSP_OK;
}


UINT32 BspGetFiberPortIsMain(UINT32 rruOpt)
{
    UINT32 isMain = FALSE;   

    INPUT_OPT_CHECK(rruOpt);	

    isMain = (rruOpt == BspGetCurrentFiberPort()) ? TRUE : FALSE;

    return isMain;
}

//oss在建立TCP链路后调用，bsp维护bbuframeid(linkid)和主光口项
UINT32 BspSetBootpNetInfo_Cpr(UINT32 rruOpt,UINT32 rruId,UINT8 *bbuIp)       
{   
    UINT32 isMain;   
	UINT8  mac[6] = {0xff,0xff,0xff,0xff,0xff,0xff};
    UINT32 bbuOpt = BspGetBBUOptPort(rruOpt);

	INPUT_POINTER_CHECK(bbuIp);
    dbgInfo("%s {%d,%d,%#x,%d.%d.%d.%d} enter\n",
        __FUNCTION__,rruOpt,rruId,bbuOpt,IP_EXPAND(bbuIp));
 
    isMain = BspGetFiberPortIsMain(rruOpt);
    dbgInfo("%s rruId(%d) -> rruOpt(%d) isMain=%d\n",__FUNCTION__,rruId,rruOpt,isMain);
    //BspSetRruId(rruOpt, rruId);/*FPGA寄存器*/
    //BspSetBbuFiberPort(rruOpt, bbuOpt);/*FPGA寄存器*/

    //SetBbuIpMac(rruOpt,bbuIp,mac);/*FPGA寄存器*/
    //BspSetXcSwitch(rruOpt, SWITCH_ON);/*FPGA寄存器*/

    BspAddOptNetInfo(rruOpt,isMain,bbuOpt,bbuIp,mac);/*common*/

    //BspSetRruIp(rruOpt);/*FPGA寄存器*/
    //BspEcpriAlmMsgSet(rruOpt);/*ecpri告警*/
    return BSP_OK;
}

UINT32 BspSetOptBbuFramer_Cpr(UINT32 rruOpt,UINT32 framerNo)
{
    UINT32 ulret = BSP_OK;
    ulret = BspSetOptBbuFramer(rruOpt,framerNo);
	return ulret;
}

UINT32 BspSetBootpNetInfo(UINT32 rruOpt,UINT32 rruId,UINT32 bbuOpt,UINT8 *bbuIp,UINT8 *bbuMac)       
{   
    UINT32 isMain;   
    INPUT_POINTER_CHECK(bbuIp);
    INPUT_POINTER_CHECK(bbuMac);
    dbgInfo("%s {%d,%d,%#x,%d.%d.%d.%d,%02x:%02x:%02x:%02x:%02x:%02x} enter\n",
        __FUNCTION__,rruOpt,rruId,bbuOpt,IP_EXPAND(bbuIp),MAC_EXPAND(bbuMac));

    isMain = BspGetFiberPortIsMain(rruOpt);
    dbgInfo("%s rruId(%d) -> rruOpt(%d) isMain=%d\n",__FUNCTION__,rruId,rruOpt,isMain);
    //BspSetRruId(rruOpt, rruId);/*FPGA寄存器*/
    //BspSetBbuFiberPort(rruOpt, bbuOpt);/*FPGA寄存器*/

    //SetBbuIpMac(rruOpt,bbuIp,bbuMac);/*FPGA寄存器*/
    //BspSetXcSwitch(rruOpt, SWITCH_ON);/*FPGA寄存器*/

    BspAddOptNetInfo(rruOpt,isMain,bbuOpt,bbuIp,bbuMac);/*common*/

    //BspSetRruIp(rruOpt);/*FPGA寄存器*/
    //BspEcpriAlmMsgSet(rruOpt);/*ecpri告警*/
    return BSP_OK;
	
}
UINT32 BspSetBbuFiberPort(UINT32 ruOptPort, UINT32 bbuPort)
{
    return BSP_OK;/*OSS调用打桩,BspGetBbuFiberPort s2600该寄存器只读的*/
}

/*****************************************************************************
 *  函数名称   : BspGetPhyOptAlm
 *  功能描述   : 物理光口告警上报
 *             物理光口所有告警，包括lof_hfnsync/lof/los/lop/ axc偶校验/ crc16检测/ hfn不连续/ bfn不连续/ 10ms系统帧频周期异常/ pcs status，用于CPU查询
 *             包括实时上报和事件上报。
 *  输入参数   : phyOptId: 物理光口号(0-3)
 *  输出参数   : 无
 *  返 回 值  :  物理光口告警       1-b0 normal   1-b1 alarm
 *           bit[31:16] : 事件上报      over a period of time(event)
 *           16bit同实时上报
 *           bit[15:0] : 实时上报
 *           [0]lof_hfnsync  [1]lof  [2]los  [3]lop  [4]axc even parity check  [5]crc16 check  [6]hfn unconsetive alarm
 *           [7] bfn unconsetive alarm  [8] frame period abnormal alarm  [9] serdes lof  [10]rx serdes cdc  [11]serdes status alm
 *           [12]rru id abnormal  [13]rru index abnormal  [14]ROE status alm  [15] pcs staus alm
 *  其它说明   : 0xc2410100  光口自适应检查bit0-3 bit7
 */
UINT32 BspGetPhyOptAlm(UINT32 phyOptId)
{
	 UINT32 alm = 0;
	 alm = BspHalAdaptGetCpriPhyOptAlm(phyOptId);

	 return alm;
}
UINT32 BspClrPhyOptAlm(UINT32 phyOptId,UINT32 ulAlmMask)
{
    (void)BspHalAdaptClrCpriPhyOptAlm(phyOptId,ulAlmMask);
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspGetPhyOptAlm
 *  功能描述   : 逻辑光口告警上报
 *           逻辑光口16bit告警，包括lof_hfnsync/lof/los/lop/ axc偶校验/ crc16检测/ hfn不连续/ bfn不连续/ 10ms系统帧频周期异常/pcs_status，用于CPU查询。
 *           包括实时上报和事件上报。 对于roe告警，只有4个上联口有效
 *  输入参数   : logOptId: 逻辑光口号(0-3)
 *  输出参数   : 无
 *  返 回 值  :  逻辑光口告警       1-b0 normal   1-b1 alarm
 *           bit[31:16] : 事件上报      over a period of time(event)
 *           16bit同实时上报
 *           bit[15:0] : 实时上报
 *           [0]lof_hfnsync  [1]lof  [2]los  [3]lop  [4]axc even parity check  [5]crc16 check  [6]hfn unconsetive alarm
 *           [7] bfn unconsetive alarm  [8] frame period abnormal alarm  [9] serdes lof  [10]rx serdes cdc  [11]serdes status alm
 *           [12]rru id abnormal  [13]rru index abnormal  [14]ROE status alm  [15] pcs staus alm
 *  其它说明   : 0xc2410000
 */
UINT32 BspGetLogOptAlm(UINT32 logOptId)
{
	 UINT32 alm = 0;
	 alm = BspHalAdaptGetCpriLogOptAlm(logOptId);

	 return alm;
}
/*0xc2410004 对应bit先写0后写1表示清除，ulAlmMask表示要清除哪些告警*/
UINT32 BspClrLogOptAlm(UINT32 logOptId,UINT32 ulAlmMask)
{
    (void)BspHalAdaptClrCpriLogOptAlm(logOptId,ulAlmMask);
    return BSP_OK;
}

UINT32 BspGetPcsAlmSta(UINT32 phyOptId)
{
    UINT32 laneId = 0;
    UINT32 pcsSta = 0;
    UINT32 serdesId = 0;  /*4.2 只有一个ip核*/
    UINT32 pcsLaneId = 0;
    UINT32 retVal = 0;

    laneId = phyOptId; /*物理光口号即是serdes的laneid*/
    pcsLaneId = serdesId * 4 + laneId;
    retVal = BspHalAdaptPcsGetLinkPcsSta(pcsLaneId,&pcsSta);
    dbgInfoEx("[%s] phyOptId %d pcsSta 0x%x \n", __FUNCTION__, phyOptId, pcsSta);
    if(pcsSta != 0x3)
    {
        BspLog(LOG_LEVEL_0,"[%s] phyOptId %d pcsSta 0x%x \n", __FUNCTION__, phyOptId, pcsSta);
    }
    if(((pcsSta&0x3f) == 0x3)&&(retVal == BSP_OK))  /*只检查bit0-5，其他bit异常联系硬件 排查，规避最近出现的手动停自适应恢复的问题*/
    {
       return BSP_OK;
    }

    return BSP_ERROR;
}

/*检测接光模块的光口的pcs*/
UINT32 BspGetOptPcsAlmSta(UINT32 phyOptId)
{
    UINT32 pcsSta = BSP_ERROR;

#ifndef MULT_PROGRESS_S	
    UINT32 sfpType = 0;
    UINT32 optIndex = 0;

    optIndex = BspGetSfpNoByPhyNo(phyOptId);	
    sfpType = BspIsSpecialQsfp(optIndex); 
    if(QSFP_FOR_ETH != sfpType)
    {
        pcsSta = BspGetPcsAlmSta(phyOptId); 
    }
#endif
    return pcsSta;
}

/**************************************************************************
 * 函数名称： _BspSaveOptSpeedRecord
 * 功能描述： 记录此次光口成功的速率
 * 输入参数： ulPhyOptId:物理光口号
              ulSpd: 速率
 * 输出参数： 无
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32  _BspSaveOptSpeedRecord(UINT32 ulPhyOptId,UINT32 ulSpd)
{
    (void)BspSaveLastMatchOptSpeed(ulPhyOptId,ulSpd);
    return BSP_OK;
}

/**************************************************************************
 * 函数名称： BspSaveOptLastMatchTopologyRecord
 * 功能描述： 记录此次光口成功时连接PB还是BBU
 * 输入参数： ulPhyOptId:物理光口号
              ulTopology:  上联口拓扑关系连PB还是BBU的基带板
 * 输出参数： 无
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32  BspSaveOptLastMatchTopologyRecord(UINT32 ulPhyOptId,UINT32 ulTopology)
{
    (void)BspSaveLastMatchTopology(ulPhyOptId,ulTopology);
    return BSP_OK;
}
/**************************************************************************
 * 函数名称： _BspGetOptSpeedRecord
 * 功能描述： 记录上次光口成功的速率
 * 输入参数： ulPhyOptId:物理光口号
 * 输出参数： pulSpd:获取速率
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspGetOptSpeedRecord(UINT32 ulPhyOptId)
{
	UINT32 ulSpeed = 0;
	UINT32 ulRet = BSP_OK;
	ulRet = BspLoadLastMatchOptSpeed(ulPhyOptId,&ulSpeed);
	if(ulRet == BSP_OK)
	{
		dbgInfoEx("%s ulPhyOptId %d ulSpeed 0x%x\n",__FUNCTION__,ulPhyOptId,ulSpeed);
	}
	else
	{
		dbgErr("%s ulPhyOptId %d failed\n", __FUNCTION__,ulPhyOptId);
	}
    return ulSpeed;
}

/**************************************************************************
 * 函数名称： BspGetOptLastTopology
 * 功能描述： 记录上次光口成功建链时的拓扑连接，上联口是连接的PB还是BBU基带板出光口
 * 输入参数： ulPhyOptId:物理光口号
 * 输出参数： pulSpd:获取速率
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 BspGetOptLastTopology(UINT32 ulPhyOptId)
{
	UINT32 ulLastTopology = RRU_PB_BBU;
	UINT32 ulRet = BSP_OK;
	ulRet = BspLoadLastMatchOptTopology(ulPhyOptId,&ulLastTopology);
	if(ulRet == BSP_OK)
	{
		dbgInfo("%s ulPhyOptId %d ulLastTopology 0x%x\n",__FUNCTION__,ulPhyOptId,ulLastTopology);
	}
	else
	{
		dbgErr("%s ulLastTopology %d failed\n", __FUNCTION__,ulLastTopology);
	}
    return ulLastTopology;
}

/*VOID _BspTrytoCfgOptSpeed(VOID)
{
    ULONG ulLoop = 0;
    ULONG ulRet = BSP_OK;
    ULONG ulSpdRecord[2] = {0};

	 仅加载上联光口速率
    ulSpdRecord[0]=_BspGetOptSpeedRecord(0);
     尝试10次重配上次保持的光口速率
    for(ulLoop = 0;ulLoop < OPT_LOCK_TYR_TIMES; ulLoop++)
    {
        if (1 == BspGetFpgaReLoadFlag())
        {
            BspSetOptWorkMode(BSP_OPT_WORK_MODE_CASCADE);
        }
        ulRet = _BspPllLockCheck(); 待实现
        if(BSP_OK == ulRet)
        {
            dbgInfo("%s: BspGetOptStatus %d (%dG)(TryTimes = %d)\n",__FUNCTION__,ulRet,ulSpdRecord[0],ulLoop);
            break;
        }
        else
        {
            BspSetOptSpeed(0,ulSpdRecord[0]);
            BspSetOptSpeed(1,ulSpdRecord[0]);
            BspSysMsDelay(300);
            dbgInfo("%s: Sys Try to Opt(%dG)(TryTimes = %d)\r",__FUNCTION__,ulSpdRecord[0],ulLoop);
        }
    }
}*/

/*****************************************************************************
 *  函数名称   : _BspGetOptSpeedMask(*)
 *  功能描述   : 获取光口速率列表,从单板特性参数表获取
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruAsset - RRU资产信息
 *  返 回 值   : 其他 - 成功; INVALID_VALUE - 失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 _BspGetOptSpeedMask()
{
	return BspGetOptSpeedMask();
}

/*按lane获取cdr的锁定状态*/
/* Started by AICoder, pid:64adf8d55ded47d78ed3126220b47ea3 */
UINT32 BspGetOptCdrStatus(UINT32 laneId, UINT32 *status)
{
    UINT32 tmp = BSP_OK;
    UINT32 cdrSta = BSP_ERROR;

    INPUT_POINTER_CHECK(status);

    tmp = BspHalAdaptLycaGetCdrStatus(0,laneId);
    if(1 == tmp)  /*1表示锁定 0表示失锁*/
    {
        cdrSta = BSP_OK;
    }
    *status = cdrSta;
    dbgInfoEx("BspGetOptCdrStatus laneId %d status %d\n", laneId, *status);
    if(BSP_OK != cdrSta)
    {
        BspLog(LOG_LEVEL_0,"%s laneId %d status %d\n",__FUNCTION__, laneId, *status);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:64adf8d55ded47d78ed3126220b47ea3 */

/**************************************************************************
 * 函数名称： _BspCheckPhyOptState
 * 功能描述： 获取RU物理光口告警事件记录  --先清后读
 * 输入参数： ulPhyOptId:物理光口号 物理光口号(0-3)
 * 输出参数： 无
 * 返 回 值： 其他:光口状态，BSP_ERROR:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
    bit[15:0] : 实时上报
    [0]lof_hfnsync  [1]lof  [2]los  [3]lop  [4]axc even parity check  [5]crc16 check  [6]hfn unconsetive alarm
    [7] bfn unconsetive alarm  [8] frame period abnormal alarm  [9] serdes lof  [10]rx serdes cdc  [11]serdes status alm
    [12]rru id abnormal  [13]rru index abnormal  [14]ROE status alm  [15] pcs staus alm
    bit[31:16] : 事件上报      16bit同实时上报
 **************************************************************************/
UINT32 _BspCheckPhyOptState(UINT32 ulPhyOptId)
{
	UINT32 ulRet = BSP_OK;
	UINT32 ulTmp = BSP_OK;

	(VOID)BspClrPhyOptAlm(ulPhyOptId,0xffffffff); /* 0xc2410104*/
	BspSysMsDelay(10);
	ulRet = BspGetPhyOptAlm(ulPhyOptId);  /* 0xc2410100*/
	ulRet &= 0x028f;  /*只检查状态*/  /*出现pcs serdes cdr正常cpri正常 但是无法建链 增加serdes lof告警检查*/
	dbgInfoEx("%s after clr ulPhyOptId %d ulRet 0x%x\n",__FUNCTION__,ulPhyOptId,ulRet);
	ulTmp = BspGetPcsAlmSta(ulPhyOptId);
	ulRet |= ulTmp;
	ulTmp = BspHalAdaptGetOptLosStatus(ulPhyOptId);
	dbgInfoEx("serdesip Los %d\n",ulTmp);
	ulRet |= ulTmp;
	ulTmp = BspHalAdaptGetOptLofStatus(ulPhyOptId);
	dbgInfoEx("serdesip Lof %d\n",ulTmp);
	ulRet |= ulTmp;
	ulTmp = 0;
	BspGetOptCdrStatus(ulPhyOptId, &ulTmp);
	dbgInfoEx("cdr sta %d\n",ulTmp);
	ulRet |= ulTmp;

	return ulRet;
}

/*检查物理光口状态 除pcs*/
UINT32 BspCheckPhyOptStateNew(UINT32 ulPhyOptId)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulTmp = BSP_OK;

    (VOID)BspClrPhyOptAlm(ulPhyOptId,0xffffffff); /* 0xc2410104*/
    BspSysMsDelay(10);
    ulRet = BspGetPhyOptAlm(ulPhyOptId);  /* 0xc2410100*/
    ulRet &= 0x028f;  /*只检查状态*/  /*出现pcs serdes cdr正常cpri正常 但是无法建链 增加serdes lof告警检查*/
    dbgInfoEx("%s after clr ulPhyOptId %d ulRet 0x%x\n",__FUNCTION__,ulPhyOptId,ulRet);
    ulTmp = BspHalAdaptGetOptLosStatus(ulPhyOptId);
    dbgInfoEx("serdesip Los %d\n",ulTmp);
    ulRet |= ulTmp;
    ulTmp = BspHalAdaptGetOptLofStatus(ulPhyOptId);
    dbgInfoEx("serdesip Lof %d\n",ulTmp);
    ulRet |= ulTmp;

    return ulRet;
}
/**************************************************************************
 * 函数名称： _BspCheckPhyOptState
 * 功能描述： 获取RU物理光口告警事件记录  --先清后读
 * 输入参数： ulPhyOptId:物理光口号 物理光口号(0-3)
 * 输出参数： 无
 * 返 回 值： 其他:光口状态，BSP_ERROR:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
    bit[15:0] : 实时上报
    [0]lof_hfnsync  [1]lof  [2]los  [3]lop  [4]axc even parity check  [5]crc16 check  [6]hfn unconsetive alarm
    [7] bfn unconsetive alarm  [8] frame period abnormal alarm  [9] serdes lof  [10]rx serdes cdc  [11]serdes status alm
    [12]rru id abnormal  [13]rru index abnormal  [14]ROE status alm  [15] pcs staus alm
    bit[31:16] : 事件上报      16bit同实时上报
 **************************************************************************/
UINT32 _BspCheckLogicOptState(UINT32 ulLogOptId)
{
	UINT32 ulRet = BSP_OK;

	(VOID)BspClrLogOptAlm(ulLogOptId,0xffffffff); /*检测 bit0-3 7  0xc2410004*/
	BspSysMsDelay(10);
	ulRet = BspGetLogOptAlm(ulLogOptId);  /*0xc2410000*/
	dbgInfoEx("%s after clr ulLogOptId %d ulRet 0x%x\n",__FUNCTION__,ulLogOptId,ulRet);
	ulRet = ulRet&0x028f028f;

	return ulRet;
}

/*调试接口 停止速率切换 或者指定某个速率进行切换*/
/*bit 9 10 24 对应9.8(0x200) 10.1(0x400) 25(0x1000000)*/
VOID BspSetRruOptSurportSpeedList(UINT32 mask)
{
    g_ulSpeedMaskList = mask;
}
/**************************************************************************
 * 函数名称： _BspGetRRUOptSurportSpeedList
 * 功能描述： 获取RU光口支持的速率列表
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 速率List
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspGetRruOptSurportSpeedList(VOID)
{
    UINT32 ulRet = 0;
    ulRet = _BspGetOptSpeedMask();
    if(g_ulSpeedMaskList != 0xff)
    {
        ulRet = g_ulSpeedMaskList;
    }
    MSG_DBG(MOD_BOARD_OPT, "%s speedmask[0x%x]\n", __FUNCTION__,ulRet);
    return ulRet;
}

/**************************************************************************
 * 函数名称： _BspCheckPhyOptIsLop
 * 功能描述： 获取RU物理光口当前状态是否为LOP
 * 输入参数： ulPhyOptId:物理光口号
 * 输出参数： 无
 * 返 回 值： BSP_OK:IS LOP，其他: NO LOP
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspCheckPhyOptIsLop(UINT32 ulPhyOptId)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulSta = BSP_OK;
    UINT32 ulSfpId = 0;


#ifndef MULT_PROGRESS_S
    UINT32 ulSfpType = 0;

    if (BspGetSfpInitStatus(ulPhyOptId) == 0)
    {
        return BSP_ERROR;
    }

    ulSfpId =  BspGetSfpNoByPhyNo(ulPhyOptId);
    if(ulSfpId == BSP_ERROR)
    {
        return  BSP_ERROR;
    }
    ulSta = BspGetOptStatusForOptAdpt(ulSfpId);
    if (BSP_OPT_ERR_NO_EXIST != (ulSta&BSP_OPT_ERR_NO_EXIST))
    {
        ulSfpType =  BspIsSpecialQsfp(ulSfpId); /*在位才判断 否则光口自适应任务一直访问会有大量打印*/
    }
    if(1 == ulSfpType)   /*电模块不能进行自适应动作，自适应流程里直接当不在位一样处理*/
    {
        return  BSP_ERROR;
    }
#endif
    ulSta = BspGetOptStatusForOptAdpt(ulSfpId);
    MSG_DBG(MOD_BOARD_OPT, "Opt[%d],status[0x%x]\n", ulPhyOptId, ulSta);
    if (BSP_OPT_ERR_NO_EXIST == (ulSta&BSP_OPT_ERR_NO_EXIST))
    {
/*        (VOID)BspHalAdaptSetCrmOptCrpiRefClkOeDisable(ulPhyOptId);*/
        return  BSP_ERROR;
    }
    if(ulSta & BSP_OPT_ERR_LOP)
    {
/*    	(VOID)BspHalAdaptSetCrmOptCrpiRefClkOeDisable(ulPhyOptId);*/  /*会影响另外一条lane 配置成硬件选择恢复钟，硬件就会根据实际情况决定有无输出*/
        ulRet = BSP_ERROR;
    }

    return ulRet;
}
/**************************************************************************
 * 函数名称： _BspOptAdptPreProcess
 * 功能描述： 设置自适应预处理
 * 输入参数： ulPhyOptId:物理光口号
 * 输出参数： 无
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspOptAdptPreProcess(UINT32 ulPhyOptId)
{
    if (NULL != pOptAdaptPostFunc)
    {
        pOptAdaptPostFunc(0);
    }
    return BSP_OK;

}
/**************************************************************************
 * 函数名称： _BspOptAdptPostProcess
 * 功能描述： 设置自适应后处理
 * 输入参数： ulPhyOptId:物理光口号
 * 输出参数： 无
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspOptAdptPostProcess(UINT32 ulPhyOptId)
{
    if (NULL != pOptAdaptPostFunc)
    {
        pOptAdaptPostFunc(1);
    }
    return BSP_OK;
}
/**************************************************************************
 * 函数名称： _BspOptSpeedIsEqual
 * 功能描述： 光口之间速率是否需要保持一致
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： BSP_OK:一致，其他:不一致
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspOptSpeedIsEqual(void)
{
    /* to do */
    return 0;
}
/**************************************************************************
 * 函数名称： _BspOptIsSync
 * 功能描述： 光口是否同步
 * 输入参数： ulPhyOptId:物理光口号
 * 输出参数： 无
 * 返 回 值： BSP_OK:同步，其他:不同步
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspOptIsSync(UINT32 ulPhyOptId)
{
    UINT32 ulId = 1;
    UINT32 ulState = 0;
    UINT32 ulLoop = 0;
    UINT32 ulSync = 0;
    UINT32 ulRet = BSP_OK;

    INPUT_PHYOPT_INDEX_CHECK(ulPhyOptId);

    for(ulLoop = 0; ulLoop <3; ulLoop++)
    {
        ulId = BspGetRruId(ulPhyOptId);
        dbgInfoEx("%s: ulId: %d\n", __FUNCTION__, ulId);
        ulState = BspGetOptStatusForOptAdpt(ulPhyOptId);
        if(0 == (ulState & (BSP_OPT_ERR_LOF | BSP_OPT_ERR_LOS)))
        {
            /* sync */
            ulSync++;
        }
        else
        {
            ulSync = 0;
        }
    }
    MSG_DBG(MOD_BOARD_OPT, "opt[%d],sync[%d]\n", ulPhyOptId, ulSync);
    (3 == ulSync) ? (ulRet = BSP_OK) : (ulRet = BSP_ERROR);

    CHECK_MSG_ERR(ulRet, MOD_BOARD_OPT, "<not sync>,opt[%d]\n", ulPhyOptId);
    return ulRet;
}
UINT32 _BspOptAdptInfoInit(VOID)
{
    T_OptAdaptInfo Info;
    T_OptAdaptInfo *pInfo = &Info;

    pInfo->ulDelay[OPT_ADPT_PRE_TWO_OPT_STATE] = 500;
    pInfo->ulDelay[OPT_ADPT_TWO_OPT_STATE] = 1000;
    pInfo->ulDelay[OPT_ADPT_POST_TWO_OPT_STATE] = 500;
    pInfo->ulDelay[OPT_ADPT_PRE_ONE_OPT_STATE] = 200;
    pInfo->ulDelay[OPT_ADPT_ONE_OPT_STATE] = 500;
    pInfo->ulDelay[OPT_ADPT_POST_ONE_OPT_STATE] = 200;
    pInfo->ulDelay[OPT_ADPT_STATE_OK] = 200;
    pInfo->pFuncDelayMs = BspSysMsDelay;
    pInfo->pFuncSaveOptSpeedRecord = _BspSaveOptSpeedRecord;
    pInfo->pFuncGetOptSpeedRecord = _BspGetOptSpeedRecord;
    pInfo->pFuncGetOptSfpMaxSpeed = _BspGetOptSfpMaxSpeed;
    pInfo->pFuncGetRruOptSurportSpeedList = _BspGetRruOptSurportSpeedList;
    pInfo->pFuncCheckPhyOptState = _BspCheckPhyOptState;
    pInfo->pFuncCheckLogicOptState = _BspCheckLogicOptState;
    pInfo->pFuncCheckPhyOptIsLop = _BspCheckPhyOptIsLop;
    pInfo->pFuncCheckExtSysClkLockState = BspCheckSysPllState;
    pInfo->pFuncOptAdptPreProcess = _BspOptAdptPreProcess;
    pInfo->pFuncOptAdptPostProcess = _BspOptAdptPostProcess;
    pInfo->pFuncOptSpeedIsEqual = _BspOptSpeedIsEqual;
    pInfo->pFuncSetOptSpeed = _BspSetOptSpeed;
    pInfo->pFuncReCfgOptRxSerdes = _BspReCfgOptRxSerdes;
    pInfo->pFuncGetOptSpeed = _BspGetOptSpeed;
    pInfo->pFuncGetOptWorkMode = BspGetDefaultOptWorkMode;
    pInfo->pFuncOptIsSync = _BspOptIsSync;
    pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_PRE_TWO_OPT_STATE] = 2;  /*缩短时间  没必要多次读取 同步GA修改*/
    pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_TWO_OPT_STATE] = 1;
    pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_POST_TWO_OPT_STATE] = 1;
    pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_PRE_ONE_OPT_STATE] = 2;
    pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_ONE_OPT_STATE] = 2;   /*准备增加次数 预留足够时间给rx配置*/
    pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_POST_ONE_OPT_STATE] = 1;
    pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_STATE_OK] = 1;
    _BspOptAdptInit(pInfo);
    //testopt();
    return BSP_OK;
}

/*光口自适应打印开关*/
UINT32 optadptexprnadd(VOID)
{
    optprton();
    exprnadd("_BspCheckPhyOptState");
    exprnadd("_BspCheckLogicOptState");
    exprnadd("_BspSingleOptAdptCheck");
    exprnadd("_BspDoubleOptAdptCheck");
    exprnadd("BspGetPcsAlmSta");
    exprnadd("BspOptAlmCollect");
    return BSP_OK;
}
UINT32 optadptexprnquit(VOID)
{
    optprtoff();
    exprnquit();
    return BSP_OK;
}

/*************************************************
 * 光口自适应调试接口
 * (1)sfpNo-phyOptNo-logOptNo 对应关系，物理主光口、逻辑主光口
 * (2)物理光口、逻辑光口状态告警、在位状态
 * (3)当前组网模式
 * (4)信令复位命令
 * (5)下联口是否需要初始化Tx
 * (6)物理光口pcs serdes参数
 * (7)自适应开关
 * (8)serdes状态查询，接收serdes初始化
 * (9)pcs配置参数查询、pcs告警状态
 * **********************************************/

char optadptPrintInfo[][60]=
{
    "UINT32 BspGetMainPhyOpt(VOID)",
    "UINT32 BspGetLogicPort(UINT32 phyOpt)",
    "UINT32 BspGetPhyPort(UINT32 logicOpt)",
    "UINT32 BspGetOptProtocol(UINT32 ulLogOpt)",
    "UINT32 BspGetOptWorkMode(VOID)",
    "UINT32 BspGetOptStatus(UINT32 optId)",  //bit0:not_exist bit8:tx_fault bit2:lof bit9:los bit10:lop
    "UINT32 _BspCheckPhyOptIsLop(UINT32 ulPhyOptId)",
    "UINT32 BspGetOptSpeedSetFlag(UINT32 ulPhyOpt)",
    "UINT32 BspGetOptFecChangeFlag(UINT32 optId)",
    "UINT32 _BspCheckPhyOptState(UINT32 ulPhyOptId)",
    "UINT32 _BspCheckLogicOptState(UINT32 ulLogOptId)",
    "showserdespara",
    "optprton/optprtoff",
    "optadpton/optadptoff",
    "lycaserdescheckstatus (lycaserdeshelp lycaserdeshelp3)",
    "lycaserdescheckrate/showlycafw/lycaserdescheckinitstatus",
    "tstPcsInfoShow",
    "UINT32 tstShowPcsStatus(UINT32 ulPhyOpt)",
    "optmapprn",
    "IcHalApiGetLycaSoftResetFlag",
    "BspGetClkAndOptReLoadFlag",
    "s_serdesRxInitedFlag",
    "optadptexprnadd",
    "optadptexprnquit",
    "BspOptAlmCollect",
    "_BspSetRruOptSurportSpeedList"
};

void optadpthelp()
{
	UINT32 loop = 0;
	for(loop = 0; loop < NELEMENTS(optadptPrintInfo);loop++)
	{
	    dbgInfo("%s\n",optadptPrintInfo[loop]);
	}
}

VOID optmapprn(VOID)
{
    UINT32 loop = 0;
    UINT32 phyOptNo = 0;
    UINT32 logOptNo = 0;
    UINT32 mainPhyOptNo = 0;
    UINT32 mainLogOptNo = 0;

    dbgInfo("opt map:\n");
    dbgInfo("sfpNo   phyNo   logNo\n");
    for(loop = 0;loop < OPTMAXNUM; loop++)
    {
        phyOptNo = BspGetPhyNoBySfpNo(loop);
        logOptNo = BspGetLogicPort(phyOptNo);
        dbgInfo("%d   %d   %d\n",loop,phyOptNo,logOptNo);
    }
    mainPhyOptNo = BspGetMainPhyOpt();
    mainLogOptNo = BspGetLogicPort(mainPhyOptNo);
    dbgInfo("mainPhyOptNo %d mainLogOptNo %d\n",mainPhyOptNo,mainLogOptNo);

}
UINT32 BspSetOptSwitchCw(UINT32 bbuPort)
{
    return BSP_OK;
}

#ifndef MULT_PROGRESS_S
UINT32 BspGetOptBer(UINT32 optIndex, UINT32 *pValue)
{
    UINT32 ulPhyOpt = 0;
    UINT32 uOptSpeed = 0;
    INT32 uOptBer = 0;
    UINT32 uOptBerA0 = 0;
    UINT32 uOptBerA1 = 0;
    UINT32 uOptSta = 0;

    INPUT_OPT_CHECK(optIndex);
    ulPhyOpt = BspGetPhyNoBySfpNo(optIndex);
    uOptSpeed = BspGetOptSpeed(optIndex);
    /* if lop alarm report 100% */
    uOptSta = BspGetOptStatusForOptAdpt(optIndex);
    if(uOptSta & BSP_OPT_ERR_LOP)
    {
        *pValue = 1000000000;
        dbgInfoEx("%s,phyopt[%d] have lop alarm opt ber = %d\n",__FUNCTION__,ulPhyOpt,*pValue);
        return BSP_OK;
    }
    /* 1. judgement 8B/10B or 64B/66B    calculate optber ;
    8B/10B  ------9.8304G
    64B/66B ------10.1376G、24.33024G
    */
     switch(uOptSpeed)
     {
         case BSP_OPT_SPEED_9P8304G:
         {
             uOptBerA0 = BspHalAdaptCpriGetStaCvCnt(ulPhyOpt);
             BspSysMsDelay(1000);
             uOptBerA1 = BspHalAdaptCpriGetStaCvCnt(ulPhyOpt);
            break;
         }
         case BSP_OPT_SPEED_10P1376G:
         case BSP_OPT_SPEED_24P33024G:
         {
             uOptBerA0 = BspHalAdaptCpriGetStaShcCvCnt(ulPhyOpt);
             BspSysMsDelay(1000);
             uOptBerA1 = BspHalAdaptCpriGetStaShcCvCnt(ulPhyOpt);
             break;
         }
         default:
         {
             break;
         }
     }
     uOptBer = uOptBerA1 - uOptBerA0;
    if(uOptBer < 0)
    {
        uOptBer += 0xffffffff;
    }
    if(uOptBer > 1000000000)
    {
        *pValue = 1000000000;
    }
    else
    {
        *pValue = uOptBer;
    }

    dbgInfoEx("%s,phyopt[%d]  opt ber = %d\n",__FUNCTION__,ulPhyOpt,*pValue);
	return BSP_OK;
}


UINT32 BspGetSfpTemp(UINT32 sfpId, INT32* pTemp)
{
    /* UINT32 ret          = BSP_OK; */
    char   bufName[10] ={0};
    UINT32 devid        = 0;
    INT32  snprtRet     = 0;

    INPUT_POINTER_CHECK(pTemp);
    snprtRet = snprintf_s(bufName, sizeof(bufName),"TempSfp%d",sfpId);
    SNPRINTF_S_CHECK(snprtRet,sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspGetTempSensorInfo(devid, pTemp);
}

VOID getsfptemp(VOID)
{
    UINT32 sfpId   = 0;
    UINT32 retVal  = 0;
    INT32 tempVal = 0;

    for(sfpId = 0; sfpId < 2; sfpId++)
    {
        retVal = BspGetSfpTemp(sfpId, &tempVal);
        if(BSP_OK != retVal)
        {
            dbgErr("[%s]Error! sfpId'%d, retVal = 0x%04x\n", __FUNCTION__, sfpId, retVal);
        }
        else
        {
           dbgInfo("[%s]sfpId'%d, Temp = %d(0.1C)\n", __FUNCTION__, sfpId, tempVal);
        }
    }
}

/* 1 光模块处于虚假不存在状态 0 虚假不存在状态无效*/
UINT32 BspSetOptVirtualAbsentConf(UINT32 optId, UINT32 status)
{
    BspLog(LOG_LEVEL_0, "%s, optId = %d, status = %d\n", __FUNCTION__, optId, status);
    return BspSetOptVirtualAbsent(optId, status);
}

UINT32 BspGetOptVirtualAbsentConf(UINT32 optId)
{
    return BspGetOptVirtualAbsent(optId);
}

#endif

/*级联时获取当前整机在第几级 TDD机型使用*/
UINT8 BspGetRruLinkInfo(void)
{
    UINT8 ucTemp = 0xff;
    UINT8 ucReverseTemp = 0xff;
    UINT32 uProtocol = 0;
    UINT32 uFiberPort = 0;
    UINT32 ulDir = 0;

    uFiberPort = BspGetCurrentFiberPort();
    ucTemp = BspGetRruId(uFiberPort) & 0xff;
    uProtocol = BspGetOptCpriProtocol(0);
    BspHalAdaptCpriGetRruDirection(&ulDir);

    dbgInfoEx("RruId  %d  ucProtocol %d\n",ucTemp,uProtocol);
    if((uProtocol == PROCOTOL_IR)&&(ucTemp > 0)&&(ucTemp < 254))  //IR 且rru 合法
    {
        if(ulDir == TX)  /*环网时反向*/
        {
            ucReverseTemp = ucTemp%16;
            ucTemp = 0xf - ucReverseTemp + 1;
            return ucTemp%16;
        }
        return ucTemp%16;
    }
    else
    {
        if(uProtocol == PROCOTOL_CPRI)
        {
            return 1; /* R9614级联8862需求，tdd机型切CPRI协议，app也会使用此接口，返回0xff APP时延流程失败 */
        }
        else
        {
            return 0xff;
        }
    }
}
UINT32 BspSetOptCpriSetCrcMask(VOID)
{
   UINT32 logOptNo = 0;
   UINT32 retVal = 0;

   for(logOptNo = 0; logOptNo <= LOG_OPT_UNKNOW; logOptNo++)  /*四个逻辑光口加一个盲插口*/
   {
       retVal |= BspHalAdaptOptCpriSetCrcMask(logOptNo,0,0x03fffff9);
   }
   return retVal;
}

/*光模块切成电模块或者开始没插后边插上电模块时的配置接口*/
UINT32 BspQsfpParaCfg(UINT32 ulOptIndex)
{
    UINT32 ulPhyNo = 0;
    UINT32 ulRet = BSP_OK;
    FUNC_QSFPNTL_INIT pQsfpNtlInit = NULL;

    INPUT_OPT_CHECK(ulOptIndex);
    pQsfpNtlInit = BspGetQsfpNtlInitCallBack();
    if(NULL == pQsfpNtlInit)
    {
        dbgErr("[%s] pQsfpNtlInit is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulPhyNo =  BspGetPhyNoBySfpNo(ulOptIndex);
    dbgInfoEx("ulOptIndex %d ulPhyNo %d\n",ulOptIndex , ulPhyNo);
    BspLog(LOG_LEVEL_0,"*********[%s] enter ulOptIndex %d**************\n",__FUNCTION__,ulOptIndex);
    ulRet = pQsfpNtlInit(ulPhyNo);
    BspSysMsDelay(3000);  /*需要延时几秒 网口才能正常*/

    return ulRet;
}

/*判断当前光口是否需要配置成电模块当网口使用*/
UINT32 IsQsfpNeedCfg(UINT32 ulOptIndex)
{
    UINT32 pcsLaneId = 0;
    UINT32 pcsSta = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 xmacSpd0 = 0;
    UINT32 xmacSpd1 = 0;

    INPUT_OPT_CHECK(ulOptIndex);
    pcsLaneId = BspGetPhyNoBySfpNo(ulOptIndex);
    ulRetVal = BspHalAdaptPcsGetLinkPcsSta(pcsLaneId,&pcsSta);

    if(ulRetVal != BSP_OK)
    {
        dbgErr("phy or pcs status check error\n");
        return BSP_ERROR;
    }
    dbgInfoEx("ulOptIndex %d pcsLaneId %d pcsSta 0x%x ,g_ulQSfpType %d\n",ulOptIndex,pcsLaneId,pcsSta,g_ulQSfpType[ulOptIndex]);
    /*产线偶现有软复位起来之后 网口不通  用户态增加phy芯片复位动作 要想生效必须要配置一次 正式版本需要支持1000M 100M自适应再放开 否则可能把boot配置的1000M 改成100M*/
    if(g_ulQSfpType[ulOptIndex] < 5) /*等于5 表示从切成电模块开始计数，连续5次都是电模块，才认为是电模块*/
    {
        g_ulQSfpLongExistCnt[ulOptIndex] = 0;
        return BSP_ERROR;
    }
    if(g_ulQSfpType[ulOptIndex] == 5) /*等于5 表示从切成电模块开始计数，连续5次都是电模块， 上电或者切换之后必配一次 不管boot配否 因为phy pcs状态监控不了L2SS vlan状态*/
    {
        return BSP_OK;
    }
    if(g_ulQSfpType[ulOptIndex] > 8) /*配置完成之后监控几次 状态不正常就重配 但是不一直监控 否则一直会有IIC访问*/
    {
        g_ulQSfpLongExistCnt[ulOptIndex]++;
        if(10 == g_ulQSfpLongExistCnt[ulOptIndex])   /*连着10次之后读一次*/
        {
            xmacSpd0 = BspHalAdaptlXmacGetPortSpeed(pcsLaneId);
#ifndef MULT_PROGRESS_S
            xmacSpd1 = BspGetCfgMacSpeed(ulOptIndex);
#endif
            g_ulQSfpLongExistCnt[ulOptIndex] = 0;
        }
        if((xmacSpd0 != xmacSpd1)&&(BSP_ERROR !=xmacSpd1))   /*故障： 两个整机先插网线 交换接电脑一端  没有lop告警  计数不增加 不感知变化  但是link的xmac速率变了*/
        {
            dbgInfo("ulOptIndex %d pcsLaneId %d xmacSpd0 %d xmacSpd1 %d\n",ulOptIndex, pcsLaneId, xmacSpd0, xmacSpd1);
            BspLog(LOG_LEVEL_0,"ulOptIndex %d pcsLaneId %d xmacSpd0 %d xmacSpd1 %d\n",ulOptIndex, pcsLaneId, xmacSpd0, xmacSpd1);
            return BSP_OK;
        }
        else
        {
            return BSP_ERROR;
        }
    }
    BspLog(LOG_LEVEL_0,"ulOptIndex %d pcsLaneId %d pcsSta 0x%x ,g_ulQSfpType %d\n",ulOptIndex,pcsLaneId,pcsSta,g_ulQSfpType[ulOptIndex]);
    if(((pcsSta&0x0000003) != 0x0000003))
    {
        return BSP_OK;
    }
#ifndef MULT_PROGRESS_S
    UINT32 ulSta = 0;
    ulRetVal = BspGetSfpPhyStatus(ulOptIndex,&ulSta);  /*检查phy芯片的状态，放到最后是为了减少IIC访问*/
    dbgInfoEx("phy sta 0x%x\n",ulSta);
    if((ulSta&0x30) != 0x30)  /*100M 接网线时0xf4,不接网线时0x34*/
    {
        return BSP_OK;
    }
#endif
    return BSP_ERROR;
}

static UINT32 BspJudgeReCfgOptSerdes(void)
{
    UINT32 phyOpt = 0;
    UINT32 optSpeed = 0;
    UINT32 enSta = 0;

    BspHalAdaptGetMainPhyOpt(&phyOpt);
    if(BSP_ERROR == phyOpt)
    {
        return BSP_OK;  /*主光口未识别之前不需要判断配置*/
    }
    BspHalAdaptCpriGetLineRate(phyOpt,&optSpeed);
    BspHalAdaptPcsEventOutCtrlEn(phyOpt, &enSta);
    if((optSpeed == BSP_OPT_SPEED_24P33024G) && (enSta == OPT_UNIFORM_ENABLE_FLAG))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*是否是从电模块切成光模块，切连续5次读到是光模块时需要切成光模块配置*/
UINT32 BspSfpParaCfg(UINT32 ulOptIndex)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulXmacId = 0;
    FUNC_QSFPNTL_INIT pQsfpNtlInit = NULL;

    INPUT_OPT_CHECK(ulOptIndex);
    pQsfpNtlInit = BspGetQsfpNtlInitCallBack();
    if(NULL == pQsfpNtlInit)
    {
        dbgErr("[%s] pQsfpNtlInit is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulXmacId = BspGetPhyNoBySfpNo(ulOptIndex);
    if(((g_ulSfpType[ulOptIndex] == 5)&&(g_ulQsfpToSfpChange[ulOptIndex] == 1)) || (BspJudgeReCfgOptSerdes() == BSP_ERROR)) /*不能一直配，每次切换之后连读到5次光模块时配一下，后边不再配*/
    {
       dbgInfoEx("ulOptIndex %d xmacId %d is Sfp \n",ulOptIndex,ulXmacId);
       BspSetM0ThreadStartFlag(0);
       (VOID)BspHalAdaptTrxpEnOrDisable(ulXmacId,0);
       (VOID)BspHalAdaptXmacEnOrDisable(ulXmacId,0);
       ulRet = pQsfpNtlInit(ulXmacId+4); /*PCS恢复正常配置*/
       g_ulQsfpToSfpChange[ulOptIndex] = 0;
    }

    return ulRet;
}

/*电模块热插拔 光电模块切换处理*/
UINT32 BspSfpQsfpCfgProcess(VOID)
{
    UINT32 ulRet = BSP_OK;
#ifndef MULT_PROGRESS_S
    UINT32 ulOptNum = 0;
    UINT32 ulOptIndex = 0;
    UINT32 ulOptSta = 0;
    UINT32 ulSfpType = 0;
    UINT32 ulXmacId = 0;
    UINT32 ulMaxCnt = 8;   /*连续读取次数*/

    ulOptNum = BspGetOptNum();
    for(ulOptIndex = 0; ulOptIndex < ulOptNum; ulOptIndex++)
    {
        if(ulOptIndex >= OPTMAXNUM)
        {
            continue;
        }
        ulSfpType = 0;  /*每次读之前清0  opt2没插 opt1插着会影响opt2判断*/
        ulOptSta = BspGetOptStatusForOptAdpt(ulOptIndex);
        if (BSP_OPT_ERR_NO_EXIST != (ulOptSta&BSP_OPT_ERR_NO_EXIST)) /*先保证电模块或者光模块在位，否则IIC访问太过频繁*/
        {
            if(BSP_OPT_ERR_LOP != (ulOptSta&BSP_OPT_ERR_LOP))
            {
                 ulSfpType = BspIsSpecialQsfp((UCHAR)ulOptIndex); /*在位才判断 否则光口自适应任务一直访问会有大量打印*/
            }
            if(ulSfpType == 1)
            {
                if(g_ulSfpChangeFlag[ulOptIndex] == 0)  /*上一次是光模块这一次是电模块，上电最开始按默认光模块处理*/
                {
                    g_ulQSfpType[ulOptIndex] = 0;
                    g_ulQsfpToSfpChange[ulOptIndex] = 0;
                }
                g_ulQSfpType[ulOptIndex]++;  /*连续读到是电模块计数*/
                g_ulSfpType[ulOptIndex] = 0; /*光模块计算清0，此时已经确认是电模块，清0是为了方便后续累加*/
                g_ulSfpChangeFlag[ulOptIndex] = 1;
                if(g_ulQSfpType[ulOptIndex] > ulMaxCnt)
                {
                    g_ulQSfpType[ulOptIndex] = ulMaxCnt+1;
                }
            }
            else
            {
               if(g_ulSfpChangeFlag[ulOptIndex] == 1)  /*上一次是电模块，这一次没有插或者接光模块*/
               {
                   g_ulSfpType[ulOptIndex] = 0;
                   g_ulQsfpToSfpChange[ulOptIndex] = 1;  /*电模块切到光模块，需要重配pcs，只有切换的时候才能配，反复配置会影响光口状态*/
               }
                g_ulSfpChangeFlag[ulOptIndex] = 0;
                g_ulSfpType[ulOptIndex]++;   /*连续读到是光模块计数*/
                g_ulQSfpType[ulOptIndex] = 0;
                if(g_ulSfpType[ulOptIndex] > ulMaxCnt)
                {
                    g_ulSfpType[ulOptIndex] = ulMaxCnt+1;
                }
            }
        }
        else  /*不在位时计数清0*/
        {
            ulXmacId = BspGetPhyNoBySfpNo(ulOptIndex);
            g_ulQSfpType[ulOptIndex] = 0;
            g_ulSfpType[ulOptIndex] = 0;
            ulRet = BspHalAdaptTrxpEnOrDisable(ulXmacId,0);  /*电模块从一个口换到另一个口，原来那个口需要关闭*/
            ulRet |= BspHalAdaptXmacEnOrDisable(ulXmacId,0);
        }
    }

    for(ulOptIndex = 0; ulOptIndex < ulOptNum; ulOptIndex++)
    {
        ulOptSta = BspGetOptStatusForOptAdpt(ulOptIndex);
        if (BSP_OPT_ERR_NO_EXIST != (ulOptSta&BSP_OPT_ERR_NO_EXIST)) /*先保证电模块或者光模块接着在*/
        {
            ulRet = IsQsfpNeedCfg(ulOptIndex);
            if(ulRet == BSP_OK)
            {
                BspSetM0ThreadStartFlag(0);
                ulRet = BspQsfpParaCfg(ulOptIndex);
            }
            else
            {
                ulRet = BspSfpParaCfg(ulOptIndex);
            }
        }
    }
#endif
    return ulRet;
}
UINT32 g_ulBlindMapMode = 0;
VOID BspSetBlindMapMode(UINT32 mode)
{
    g_ulBlindMapMode = mode;
}
UINT32 BspGetBlindMapMode(VOID)
{
    return g_ulBlindMapMode;
}

UINT32 BspSetCpriOptProperty(UINT32 ulFlag, UINT32 ulPhyOptNo)
{
    UINT32 ulOptWorkMode = 0;
    UINT32 ulRet = BSP_OK;
    UINT32 ulBlindMode = 0;
    UINT32 ulOptRingFlag = 0;
    UINT32 ulOptShareFlag = 0;

    ulBlindMode = BspGetBlindMapMode();
    ulOptRingFlag = BspGetOptRingFlag();
    ulOptShareFlag = BspGetOptShareFlag();
    if((ulBlindMode == 0)||(ulOptRingFlag == OPT_SUPPORT_RING)||(ulOptShareFlag == OPT_SUPPORT_SHARE))  /*非盲插或者支持环网不配置 ulOptRingFlag 为0表示不支持环网 1表示支持  这里不在单独定义宏以注释为准*/
    {
        return BSP_OK;
    }
    ulOptWorkMode = BspGetDefaultOptWorkMode(0);
    if((ulOptWorkMode != BSP_OPT_WORK_MODE_CASCADE)&&(ulOptWorkMode != BSP_OPT_WORK_MODE_CASCADE_NORMAL))
    {
        ulRet = BspHalAdaptCpriCfgOptProperty(0,2,0,0);  /*防止提前返回 走不到最后一步*/
        ulRet |= BspHalAdaptCpriCfgOptProperty(1,2,0,0);
        return ulRet;  /*非级联不需要强制设置*/
    }
    if(ulFlag == 1)
    {
        dbgInfoEx("ulFlag %d ulPhyOptNo %d",ulFlag,ulPhyOptNo);
        ulRet = BspHalAdaptCpriCfgOptProperty(1-ulPhyOptNo,1,1,0);  /*级联盲插需要指定下联口，前提是主光口已经识别出来 这块不影响网口*/
    }
    else  /*防止光口倒换，所以一旦物理主光口识别不出来立马就恢复自动识别状态，保证上联口正常*/
    {
        ulRet = BspHalAdaptCpriCfgOptProperty(0,2,0,0);
        ulRet |= BspHalAdaptCpriCfgOptProperty(1,2,0,0);
    }

    return ulRet;
}

UINT32 BspGetLogicOptByMsOpt(UINT32 *uUpLinkLogicOpt, UINT32 *uDownLinkLogicOpt)
{
    UINT32 uSecndPhyOptPort = 0;
    UINT32 uMainPhyOptPort = 0;

    if((NULL == uUpLinkLogicOpt) || (NULL == uDownLinkLogicOpt))
    {
        return BSP_ERROR;
    }

    (VOID)BspHalAdaptGetMainPhyOpt(&uMainPhyOptPort);
    if(BSP_ERROR == uMainPhyOptPort)
    {
        dbgErr("%s>>>Get MainOpt Error!", __FUNCTION__);
        return BSP_ERROR;
    }
    uSecndPhyOptPort = 1 - uMainPhyOptPort;
    *uUpLinkLogicOpt = BspGetLogicPort(uMainPhyOptPort);
    *uDownLinkLogicOpt = BspGetLogicPort(uSecndPhyOptPort);

    dbgInfoEx("%s uMainPhyOptPort:%d, uUpLinkLogicOpt:%d, uSecndPhyOptPort:%d, uDownLinkLogicOpt%d\n",
                    __FUNCTION__,uMainPhyOptPort,*uUpLinkLogicOpt,uSecndPhyOptPort,*uDownLinkLogicOpt);

    return BSP_OK;
}

#ifndef MULT_PROGRESS_S
UINT32 BspCheckSfpCdrStatus(UINT32 index)
{
    UINT32 maxSpeed = 0;
    UINT32 optSpeed = 0;
    UINT32 retVal = 0;
    UINT32 flag = 0;

    maxSpeed = BspGetSfpMaximalUsedbleSpeed(index);
    optSpeed = BspGetOptSpeed(index);
    dbgInfo("optid %d maxSpeed %d optSpeed  %d\n",index,maxSpeed,optSpeed);
    if(maxSpeed == BSP_OPT_SPEED_24P33024G)
    {
       if(optSpeed == BSP_OPT_SPEED_24P33024G)
       {
            flag = 2;
       }
       else
       {
           flag = 1;
       }
    }
    if(flag != 0)
    {
        retVal = BspOpenSfpCdr(index,flag-1);
    }
    return retVal;
}
#endif

/* Started by AICoder, pid:qa817tf59fb0c9f149770a6af0b76e2cdf080440 */
UINT32 BspGetPriorityReg(void)
{
    UINT32 cntVal[8] = {0};

    // 读取特定地址的寄存器值
    BspHalAdaptDpdicRegRd(0, 0xc24031bc, 0, &cntVal[0]);
    BspHalAdaptDpdicRegRd(0, 0xc2402220, 0, &cntVal[1]);
    BspHalAdaptDpdicRegRd(0, 0xc24020c4, 0, &cntVal[2]);
    BspHalAdaptDpdicRegRd(0, 0xc24020c8, 0, &cntVal[3]);
    BspHalAdaptDpdicRegRd(0, 0xc2404808, 0, &cntVal[4]);
    BspHalAdaptDpdicRegRd(0, 0xc2404a08, 0, &cntVal[5]);
    BspHalAdaptDpdicRegRd(0, 0xc240c82c, 0, &cntVal[6]);
    BspHalAdaptDpdicRegRd(0, 0xc240ca2c, 0, &cntVal[7]);

    BspLog(LOG_LEVEL_0, "0xc24031bc:%#x, 0xc2402220:%#x, 0xc24020c4:%#x, 0xc24020c8:%#x, "
           "0xc2404808:%#x, 0xc2404a08:%#x, 0xc240c82c:%#x, 0xc240ca2c:%#x\n",
           cntVal[0], cntVal[1], cntVal[2], cntVal[3], cntVal[4], cntVal[5], cntVal[6], cntVal[7]);

    for (UINT32 loop = 0; loop < 8; ++loop)
    {
        BspHalAdaptDpdicRegRd(0, 0xc2404000, 4 * loop, &cntVal[loop]);
        BspLog(LOG_LEVEL_0, "0xc2404000[%u]: %#x\n", loop, cntVal[loop]);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:qa817tf59fb0c9f149770a6af0b76e2cdf080440 */

/*BspGetFpgaReLoadFlag cmake顺序限制 编译不过这里不添加*/
UINT32 BspOptAlmCollect(VOID)
{
    UINT32 optNo = 0;
    UINT32 phyOptNo = 0;
    UINT32 optSta = 0;
    UINT32 logOptNo = 0;
    UINT32 retVal = BSP_OK;
    UINT32 protocol = 0;
    UINT32 workMode = 0;
    UINT32 serdesRate = 0;
    UINT32 cpriRate = 0;
    UINT32 fecMode = 0;
    UINT32 blindMode = 0;
    UINT32 regVal[3] = {0};
    UINT32 regVal1= 0;
    UINT32 cntVal[15] = {0};
    UINT32 clkStatus = 0;
    UINT32 pcsSta = 0;
    UINT32 cdrSta = 0;
    UINT32 m0status = 0;
    UINT32 m0Core0Sta0 = 0;
    UINT32 m0Core1Sta0 = 0;
    UINT32 m0Core0Ctrl0 = 0;
    UINT32 m0Core1Ctrl0 = 0;
    UINT32 m0Core0Sta1 = 0;
    UINT32 m0Core1Sta1 = 0;
    UINT32 m0Core0Ctrl1 = 0;
    UINT32 m0Core1Ctrl1 = 0;
    UINT32 m0Run0 = 0;
    UINT32 m0Run1 = 0;

#ifndef MULT_PROGRESS_S
    UINT32 sfpType = 0;
#endif
/*物理光口告警*/
    BspLog(LOG_LEVEL_0,"\n");
    dbgInfoEx("************************[%s] enter************************\n",__FUNCTION__);
    BspLog(LOG_LEVEL_0,"************************[%s] enter************************\n",__FUNCTION__);
    BspHalAdapGetGetM0RunStatus(&m0Core0Sta0, &m0Core1Sta0, &m0Core0Ctrl0, &m0Core1Ctrl0);
    for(optNo = 0; optNo < OPTMAXNUM; optNo++)
    {
        dbgInfoEx("\n");
        dbgInfoEx("************************optNo %d start************************\n",optNo);
        BspLog(LOG_LEVEL_0,"************************optNo %d start************************\n",optNo);
#ifndef MULT_PROGRESS_S
        sfpType = BspIsSpecialQsfp(optNo);
        if(sfpType == 1)
        {
            dbgInfoEx("optNo %d is Qsfp \n",optNo);
            BspLog(LOG_LEVEL_0,"optNo %d is Qsfp \n",optNo);
            dbgInfoEx("************************optNo %d end************************\n",optNo);
            BspLog(LOG_LEVEL_0,"************************optNo %d end************************\n",optNo);
            continue;   /*电模块不需要记录*/
        }
#endif
        optSta = BspGetOptStatusForOptAdpt(optNo);
        dbgInfoEx("BspGetOptStatus optNo %d, optSta 0x%x \n",optNo,optSta);
        BspLog(LOG_LEVEL_0,"BspGetOptStatus optNo %d, optSta 0x%x \n",optNo,optSta);

        phyOptNo = BspGetPhyNoBySfpNo(optNo);
        if(_BspCheckPhyOptIsLop(phyOptNo) != BSP_OK)
        {
            dbgInfoEx("optNo %d is not Exist or Lop \n",optNo);
            BspLog(LOG_LEVEL_0,"optNo %d is notExist or Lop \n",optNo);  /*有光功率或不在位告警就不需要往下记录*/
            dbgInfoEx("************************optNo %d end************************\n",optNo);
            BspLog(LOG_LEVEL_0,"************************optNo %d end************************\n",optNo);
            continue;
        }
        BspLog(LOG_LEVEL_0,"--------------------Phy Alm--------------------\n");
        dbgInfoEx("--------------------Phy Alm--------------------\n");
        /*物理光口相关状态*/
        logOptNo = BspHalAdaptGetLogOpt(phyOptNo);
        (VOID)BspClrPhyOptAlm(phyOptNo,0xffffffff); /* 0xc2410104*/
        BspSysMsDelay(10);
        retVal = BspGetPhyOptAlm(phyOptNo);  /* 0xc2410100*/
        retVal &= 0x028f028f;  /*既检查状态也检查事件*/  /*出现pcs serdes cdr正常cpri正常 但是无法建链 增加serdes lof告警检查*/
        dbgInfoEx("phyOptNo %d almSta 0x%x\n",phyOptNo,retVal);
        BspLog(LOG_LEVEL_0,"phyOptNo %d almSta 0x%x\n",phyOptNo,retVal);
        BspHalAdaptPcsGetLinkPcsSta(phyOptNo, &pcsSta);
        BspLog(LOG_LEVEL_0,"pcs laneid %d alm 0x%x\n", phyOptNo, pcsSta);
        dbgInfoEx("pcs laneid %d alm 0x%x\n", phyOptNo, pcsSta);
        cdrSta = BspHalAdaptLycaGetCdrStatus(0, phyOptNo);
        dbgInfoEx("serdes cdr lane %d alm 0x%x\n", phyOptNo, cdrSta);
        BspLog(LOG_LEVEL_0,"serdes cdr lane %d alm 0x%x\n", phyOptNo, cdrSta);
        retVal = BspHalAdaptGetOptLosStatus(phyOptNo);
        dbgInfoEx("serdesip Los %d\n",retVal);
        BspLog(LOG_LEVEL_0,"serdesip Los %d\n",retVal);
        retVal = BspHalAdaptGetOptLofStatus(phyOptNo);
        dbgInfoEx("serdesip Lof %d\n",retVal);
        BspLog(LOG_LEVEL_0,"serdesip Lof %d\n",retVal);
        retVal = BspHalAdaptGetCpriPhyFsm(phyOptNo);
        dbgInfoEx("fsm %d\n",retVal);
        BspLog(LOG_LEVEL_0,"fsm %d\n",retVal);
        BspLog(LOG_LEVEL_0,"--------------------Log Alm--------------------\n");
        dbgInfoEx("--------------------Log Alm--------------------\n");
        /*逻辑光口相关状态*/
        retVal =  _BspCheckLogicOptState(logOptNo);

        dbgInfoEx("logOptNo %d almSta 0x%x\n",logOptNo,retVal);
        BspLog(LOG_LEVEL_0,"logOptNo %d almSta 0x%x\n",logOptNo,retVal);
        retVal = BspHalAdaptGetCpriLogFsm(logOptNo);
        dbgInfoEx("fsm %d\n",retVal);
        BspLog(LOG_LEVEL_0,"fsm %d\n",retVal);
        retVal = BspHalAdaptGetCpriCdcResyncSta(phyOptNo);
        dbgInfoEx("CDC resync %d\n",retVal);
        BspLog(LOG_LEVEL_0,"CDC resync %d\n",retVal);

        BspHalAdaptDpdicRegRd(0,0xc2412334, 0, &regVal[0]); /*是否帧头自震荡*/
        BspHalAdaptDpdicRegRd(0,0xc24031d8, 0, &regVal[1]); /*光口上下联属性*/
        BspHalAdaptDpdicRegRd(0,0xc24031dc, 0, &regVal[2]); /*光口上下联属性*/
        dbgInfoEx("0xc2412334: 0x%x 0xc24031d8: 0x%x  0xc24031dc: 0x%x\n", regVal[0], regVal[1], regVal[2]);
        BspLog(LOG_LEVEL_0,"0xc2412334: 0x%x 0xc24031d8: 0x%x  0xc24031dc: 0x%x\n", regVal[0], regVal[1], regVal[2]);
        BspHalAdaptDpdicRegRd(0,0xc2405cb0,0,&regVal[0]);  /*信令路由*/
        BspHalAdaptDpdicRegRd(0,0xc2405cb4,0,&regVal[1]);  /*信令路由*/
        BspLog(LOG_LEVEL_0,"roe: 0xc2405cb0: 0x%x  0xc2405cb4: 0x%x\n",regVal[0],regVal[1]);
        BspHalAdaptDpdicRegRd(0,0xc2405cb8,0,&regVal[0]);  /*信令路由*/
        BspHalAdaptDpdicRegRd(0,0xc2405cbc,0,&regVal[1]);  /*信令路由*/
        BspLog(LOG_LEVEL_0,"roe: 0xc2405cb8: 0x%x  0xc2405cbc: 0x%x\n",regVal[0],regVal[1]);
        BspHalAdaptDpdicRegRd(0,0xc2404c90,0,&regVal[0]);  /*cpri环回bit0*/
        BspHalAdaptDpdicRegRd(0,0xc2404d90,0,&regVal[1]);  /*cpri环回bit0*/
        BspLog(LOG_LEVEL_0,"roe: 0xc2404c90: 0x%x  0xc2404d90: 0x%x\n",regVal[0],regVal[1]);
        dbgInfoEx("************************optNo %d end************************\n",optNo);
        BspLog(LOG_LEVEL_0,"************************optNo %d end************************\n",optNo);
    }
    dbgInfoEx("\n");
    dbgInfoEx("************************common start************************\n");
    BspLog(LOG_LEVEL_0,"************************common start************************\n");
    BspHalAdaptGetMainPhyOpt(&phyOptNo);
    protocol = BspGetOptCpriProtocol(0);
    workMode = BspGetDefaultOptWorkMode(0);
    blindMode = BspGetBlindMapMode();
    BspHalAdaptGetSysLd(0,&clkStatus);
    m0status = BspGetM0ThreadStartFlag();
    BspHalAdapGetGetM0RunStatus(&m0Core0Sta1, &m0Core1Sta1,&m0Core0Ctrl1, &m0Core1Ctrl1);
    m0Run0 = m0Core0Sta1 - m0Core0Sta0;
    m0Run1 = m0Core1Sta1 - m0Core1Sta0;
    dbgInfoEx("mainOptNo %d protocol %d(0: cpri 1: IR) workMode %d  blindMode %d clkStatus %d M0:%d M0Run0:%d M0Run1:%d m0Core0Ctrl1:%d m0Core1Ctrl1:%d tick %llu\n",phyOptNo,protocol,workMode,blindMode,clkStatus, m0status, m0Run0, m0Run1, m0Core0Ctrl1, m0Core1Ctrl1, tick64Get());
    BspLog(LOG_LEVEL_0,"mainOptNo %d protocol %d(0: cpri 1: IR) workMode %d blindMode %d clkStatus %d M0:%d M0Run0:%d M0Run1:%d m0Core0Ctrl1:%d m0Core1Ctrl1:%d tick %llu\n",phyOptNo,protocol,workMode,blindMode,clkStatus, m0status, m0Run0, m0Run1, m0Core0Ctrl1, m0Core1Ctrl1,tick64Get());

    if(phyOptNo != BSP_ERROR)
    {
        BspHalAdaptDpdicRegRd(0,0xc240314c,phyOptNo*4,&regVal[0]);   /*HDLC*/
        BspHalAdaptDpdicRegRd(0,0xc240318c,phyOptNo*4,&regVal[1]);   /*P值*/
        dbgInfoEx("mainOptNo %d HDLC 0x%x Pvalue 0x%x \n",phyOptNo,regVal[0],regVal[1]);
        BspLog(LOG_LEVEL_0,"mainOptNo %d HDLC 0x%x Pvalue 0x%x \n",phyOptNo,regVal[0],regVal[1]);
        regVal[0] = 0;
        regVal[1] = 0;
    }
    for(optNo = 0; optNo < OPTMAXNUM; optNo++)
    {
         phyOptNo = BspGetPhyNoBySfpNo(optNo);
         logOptNo = BspHalAdaptGetLogOpt(phyOptNo);
         BspHalAdaptGetLycaSerdesRate(0, phyOptNo,&serdesRate);
         BspHalAdaptCpriGetLineRate(phyOptNo,&cpriRate);
         BspHalAdaptPcsGetLinkFecMode(phyOptNo,&fecMode);
         BspHalAdaptDpdicRegRd(0,0xd4c00b28,0,&regVal[0]);  /*恢复钟选择 BspHalAdaptSetCrmOptCrpiRefClkLogic*/
         BspHalAdaptDpdicRegRd(0,0xc2403010,phyOptNo*4,&regVal[1]);  /*解析得到的优先级控制字 FDD机型使用*/
         BspHalAdaptDpdicRegRd(0,0xc24031c4, 0, &regVal1);  /*强发优先级控制字只有逻辑2口 解析得到的优先级控制字 FDD机型使用*/
         dbgInfoEx("optNo %d phyOptNo %d serdesRate %d  cpriRate %d  fecMode %d RefClk 0x%x TxPriority 0x%x [0xc24031c4]:0x%x\n",optNo,phyOptNo,serdesRate,cpriRate,fecMode,regVal[0],regVal[1],regVal1);
         BspLog(LOG_LEVEL_0,"optNo %d phyOptNo %d serdesRate %d  cpriRate %d  fecMode %d RefClk 0x%x TxPriority 0x%x [0xc24031c4]:0x%x\n",optNo,phyOptNo,serdesRate,cpriRate,fecMode,regVal[0],regVal[1],regVal1);
         regVal[0] = 0;
         regVal[1] = 0;
    }

    BspHalAdaptDpdicRegRd(0,0xc240c320,0*4,&cntVal[0]);
    BspHalAdaptDpdicRegRd(0,0xc240c320,1*4,&cntVal[1]);
    BspHalAdaptDpdicRegRd(0,0xc240c320,2*4,&cntVal[2]);

    BspHalAdaptDpdicRegRd(0,0xc240c340,0*4,&cntVal[3]);
    BspHalAdaptDpdicRegRd(0,0xc240c340,1*4,&cntVal[4]);
    BspHalAdaptDpdicRegRd(0,0xc240c340,2*4,&cntVal[5]);

    BspHalAdaptDpdicRegRd(0,0xc240c360,0*4,&cntVal[6]);
    BspHalAdaptDpdicRegRd(0,0xc240c360,1*4,&cntVal[7]);
    BspHalAdaptDpdicRegRd(0,0xc240c360,2*4,&cntVal[8]);

    BspHalAdaptDpdicRegRd(0,0xc24020c4,0*4,&cntVal[9]);
    BspHalAdaptDpdicRegRd(0,0xc24020c4,1*4,&cntVal[10]);

    BspHalAdaptDpdicRegRd(0,0xc2404808,0,    &cntVal[11]);
    BspHalAdaptDpdicRegRd(0,0xc2404808,0x100,&cntVal[12]);
    BspHalAdaptDpdicRegRd(0,0xc2404808,0x200,&cntVal[13]);

    BspHalAdaptDpdicRegRd(0,0xc240ca88,0,&cntVal[14]);

    dbgInfoEx("[optStaPrint]:\n lopsta[log0]:%#x, lopsta[log1]:%#x, lopsta[log2]:%#x, \n lofsta[log0]:%#x, lofsta[log1]:%#x, lofsta[log2]:%#x, \n lossta[log0]:%#x, lossta[log1]:%#x, lossta[log2]:%#x,\n physta[phy0]:%#x, physta[phy1]:%#x, \n, logsta[log0]:%#x, logsta[log1]:%#x,logsta[log2]:%#x, log2alarm:%#x\n",
            cntVal[0], cntVal[1], cntVal[2],cntVal[3], cntVal[4], cntVal[5],cntVal[6], cntVal[7], cntVal[8],cntVal[9], cntVal[10], cntVal[11],cntVal[12], cntVal[13], cntVal[14]);
    BspLog(LOG_LEVEL_0,"[optStaPrint]:\n lopsta[log0]:%#x, lopsta[log1]:%#x, lopsta[log2]:%#x, \n lofsta[log0]:%#x, lofsta[log1]:%#x, lofsta[log2]:%#x, \n lossta[log0]:%#x, lossta[log1]:%#x, lossta[log2]:%#x,\n physta[phy0]:%#x, physta[phy1]:%#x, \n, logsta[log0]:%#x, logsta[log1]:%#x,logsta[log2]:%#x, log2alarm:%#x\n",
            cntVal[0], cntVal[1], cntVal[2],cntVal[3], cntVal[4], cntVal[5],cntVal[6], cntVal[7], cntVal[8],cntVal[9], cntVal[10], cntVal[11],cntVal[12], cntVal[13], cntVal[14]);
    (VOID)BspGetPriorityReg();
    dbgInfoEx("************************common end************************\n");
    BspLog(LOG_LEVEL_0,"************************common end************************\n");
    dbgInfoEx("************************[%s] end************************\n",__FUNCTION__);
    BspLog(LOG_LEVEL_0,"************************[%s] end************************\n",__FUNCTION__);
    BspLog(LOG_LEVEL_0,"\n");
    return BSP_OK;
}

/*获取光口速率切换记录 第一次上电高层会先清除*/
UINT32 BspGetOptSpdChgRecord(VOID)
{
    UINT32 regVal = 0;
    UINT32 retVal = 0;

    (VOID)BspHalAdaptDpdicRegRd(0,0xd4c0016c,0,&regVal);
    if(regVal&0xff)
    {
        retVal |= BIT_SET(0);  /*低8bit对应光笼子0*/
    }
    if(regVal&0xff00)
    {
        retVal |= BIT_SET(1); /*高8bit对应光笼子1*/
    }
    dbgInfoEx("regVal: 0x%x retVal: 0x%x \n ",regVal,retVal);
    if(retVal != 0)
    {   /*返回值非0 表示切换过速率  此时才需要记录log 否则重复log 过多，高层调用太过频繁*/
        BspLog(LOG_LEVEL_0,"%s regVal: 0x%x retVal: 0x%x \n ",__FUNCTION__,regVal,retVal);
    }
    return retVal;
}

VOID BspSetOptSpdChgFlag(UINT32 phyOptNo, UINT32 flag)
{
    if(phyOptNo >= OPTMAXNUM)
    {
        return;
    }
    g_ulOptSpdChgFlag[phyOptNo] = flag;
    return;
}
/*0xd4c0016c 上电默认值是0x00000000*/
UINT32 BspSetOptSpdChgRecord(UINT32 phyOptNo)
{
    UINT32 regVal = 0;
    UINT32 sfpNo = 0;
    UINT32 retVal = 0;

    if(phyOptNo >= OPTMAXNUM)
    {
        return BSP_ERROR;
    }
    if(g_ulOptSpdChgFlag[phyOptNo] == 0)  /*未切换过速率  光口状态是正常的*/
    {
       return BSP_ERROR;
    }
    sfpNo = BspGetSfpNoByPhyNo(phyOptNo);
    if(sfpNo == BSP_ERROR)
    {
        return sfpNo;
    }
    (VOID)BspHalAdaptDpdicRegRd(0,0xd4c0016c,0,&regVal);
    if(sfpNo == 0)
    {
        retVal |= BIT_SET(0);  /*低8bit对应光笼子0*/
    }
    else
    {
        retVal |= BIT_SET(8); /*高8bit对应光笼子1*/
    }
    (VOID)BspHalAdaptDpdicRegWr(0,0xd4c0016c,0,retVal);
    BspSetOptSpdChgFlag(phyOptNo,0);    /*切换过速率才正常  这里把标志清掉，方便下一次记录*/
    BspLog(LOG_LEVEL_0,"%s phyOptNo %d SfpNo %d\n ",__FUNCTION__,phyOptNo,sfpNo);

    return BSP_OK;
}
/*提供给高层清除 光口速率切换记录*/
UINT32 BspClrOptSpdChgRecord(VOID)
{
    UINT32 regVal0 = 0;
    UINT32 regVal1 = 0;

    (VOID)BspHalAdaptDpdicRegRd(0,0xd4c0016c,0,&regVal0);
    regVal1 = regVal0&0xffff0000;   /*清bit0-15*/
    (VOID)BspHalAdaptDpdicRegWr(0,0xd4c0016c,0,regVal1);

    dbgInfoEx("regVal0: 0x%x regVal1: 0x%x \n ",regVal0,regVal1);
    BspLog(LOG_LEVEL_0,"%s regVal0: 0x%x regVal1: 0x%x \n ",__FUNCTION__,regVal0,regVal1);

    return BSP_OK;
}

/*FDD恢复时钟拔掉光纤没有关断问题增加 25时直接由pcs送给cpri的编码同步指示产生los,而非从cpri解析，cpri根据接收的超帧头解析处理产生los*/
UINT32 BspSetOptLosAlmFromPcs(UINT32 optNo)
{
    UINT32 fecMode = 0;
    UINT32 retVal = BSP_OK;
    UINT32 fecEn = 0;

    retVal = BspHalAdaptPcsGetLinkFecMode(optNo,&fecMode);
    if(fecMode != OPTPCS_FEC_TYPE_BYPASS)
    {
        fecEn = 1;  /*FEC 开的时候 设置1*/
    }
    retVal |= BspHalAdaptCpriCfgFecEn(optNo,fecEn);        /*根据速率设置 los 从pcs解析 而不从cpri解帧*/

    return retVal;
}

/*给光口传递当前配置的光口速率*/
UINT32 BspSetAxcArrangeTypeByRate(UINT32 ulPhyOpt)
{
    UINT32 ulSpd = 0;
    UINT32 ulPastMode = LIMIT_TRANSFER_MODE_NORMAL;

    (VOID)BspHalAdaptCpriGetLineRate(ulPhyOpt,&ulSpd);
    ulPastMode = BspGetLimitTransferMode();
    if (LIMIT_TRANSFER_MODE_EXTEND == ulPastMode)
    {
        (VOID)BspHalAdaptAxcArrangeTypeByBspRate(ulPhyOpt,ulSpd, MODE_EXTREME_EXTEND);
    }
    else
    {
        (VOID)BspHalAdaptAxcArrangeTypeByBspRate(ulPhyOpt,ulSpd, MODE_NORMAL);
    }

    return BSP_OK;
}

UINT32 BspSetMultSerdesRxInit(UINT32 ulPhyOpt)
{
    UINT32 uRet = BSP_OK;
    UINT32 uIdx = 0;
    UINT32 ulVga = 0;
    UINT32 ulCmtermCtrl = 4; /*serdes rxinit default parameter*/
    UINT32 ulStatus = 0;

    uRet |= IcHalApiGetSerdesRxInitPara(ulPhyOpt, &ulVga, &ulCmtermCtrl);
    for(uIdx = 0; uIdx <= SERDES_RXINIT_MAX; uIdx++)
    {
        uRet |= IcHalApiTestLycaInitRx((ulPhyOpt / SERDES_LANE_MAX), (ulPhyOpt % SERDES_LANE_MAX), -24, 24, ulVga, ulCmtermCtrl); /* -24:phaseMin 24:phaseMax*/
        uRet |= IcHalApiLycaTccSwitch((ulPhyOpt / SERDES_LANE_MAX), (ulPhyOpt % SERDES_LANE_MAX));
        uRet |= IcHalApiGetLinkPcsSta(ulPhyOpt, &ulStatus);
        ulStatus = ulStatus & PCS_NORMAL;
        dbgInfo("ulStatus = %u\n", ulStatus);
        if(PCS_NORMAL == ulStatus)
        {
            uRet = BSP_OK;
            break;
        }
    }
    return uRet;
}

/*获取光纤自环状态*/
UINT32 BspGetOptLoopSta(UINT32 phyOpt)
{
    UINT32 ret = BSP_OK;
    UINT32 oriPhyOpt = 0;
    UINT32 logicOpt = 0;
    UINT32 cpuCfgEn = 0;
    UINT32 sw = 0;
    UINT32 isHoldover = 0;
    UINT32 mainPhyOpt = 0;
    UINT32 property = 0;
    UINT32 propertyCfgEn = 0;
    UINT32 chipInterConn = 0;
    UINT32 swInfo = 0;
    UINT32 swRdFrSel = 0;
    UINT32 swAlign = 0;
    UINT32 protocol = 0;
    UINT32 testWord = 0;  /*cw*/
    UINT32 testCheckWord = 0;
    UINT32 idx = 0;
    UINT32 ldb = 1500; /*电差损*/
    DOUBLE accuracy = 100.0; /*精度*/

    ret |= IcHalApiCpriGetCfgRelation(logicOpt, &oriPhyOpt, &cpuCfgEn);
    phyOpt = (oriPhyOpt >= OPT_MAX) ? phyOpt : oriPhyOpt;

    ret |= IcHalApiCpriGetMapConfig(&sw, &isHoldover, &mainPhyOpt);
    ret |= IcHalApiCpriMapConfig(ENABLE, ENABLE, phyOpt);  /*r9125 主光口会是opt1*/

    ret |= IcHalApiCpriGetCfgOptProperty(phyOpt, &property, &propertyCfgEn, &chipInterConn);
    ret |= IcHalApiGetSwAlignFrSel(logicOpt, &swInfo);

    ret |= IcHalApiCpriSetRelation(logicOpt, phyOpt, ENABLE);
    ret |= IcHalApiCpriCfgOptProperty(phyOpt, 0, ENABLE, 0);
    /*bit0-sync with fr or chip head; bit4-bypass align or through align.*/
    if((swInfo & 0x11) != 0)
    {
        ret |= IcHalApiSwAlignFrSel(logicOpt, swRdFrSel, swAlign);
        swRdFrSel = (swInfo & 0x1);
        swAlign = (swInfo & 0x10);
    }

    ret |= IcHalApiLycaInitTx((phyOpt / SERDES_LANE_MAX), (phyOpt % SERDES_LANE_MAX), 9830400, ldb/accuracy); /*9.8G*/
    ret |= IcHalApiPcsSetGloableCfgEn(phyOpt, ENABLE);
    BspSysMsDelay(10);
    ret |= IcHalApiPcsSetLinkProtocol(phyOpt, OPTPCS_CPRI_10B);
    BspSysMsDelay(10);
    ret |= IcHalApiPcsSet1XLinkEn(phyOpt, RX, DISABLE);
    ret |= IcHalApiPcsSet1XLinkEn(phyOpt, TX, DISABLE);
    BspSysMsDelay(10);
    ret |= IcHalApiPcsSetLinkFecMode(phyOpt, OPTPCS_FEC_TYPE_BYPASS);
    BspSysMsDelay(10);
    ret |= IcHalApiPcsSet1XLinkEn(phyOpt, RX, ENABLE);
    ret |= IcHalApiPcsSet1XLinkEn(phyOpt, TX, ENABLE);
    BspSysMsDelay(10);
    ret |= IcHalApiPcsSetGloableCfgEn(phyOpt, DISABLE);

    ret |= IcHalApiCpriSetFrTestMode(logicOpt, SWITCH_ON);

    /*axcSel:[0-5], axcMask:[0xffffffff],represents 32bit enable.*/
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 0, 0xffffffff);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 1, 0xffffffff);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 2, 0xffffffff);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 3, 0xffffffff);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 4, 0xffffffff);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 5, 0xffffffff);
    ret |= IcHalApiSwTestGenEn(2,ENABLE); /*Sw2*/
    ret |= IcHalApiCpriTxDataType(logicOpt, ENABLE, 0); /*prbs data*/
    ret |= IcHalApiCpriCfgTxPrbsMode(logicOpt, 1, 1); /*PRBS30, prbs with 0*/

    ret |= BspSetMultSerdesRxInit(phyOpt);
    ret |= IcHalApiGetCpriProtocol(&protocol);

    for(idx = 0; idx < 3; idx++) /*发三次随机控制字防抖*/
    {
        testWord = (UINT32)zte_rand_s();
        testWord = testWord&0xffff; /*取0-15bit*/

        if(PROCOTOL_CPRI == protocol)
        {
            ret |= IcHalApiOptCpriSetFsTypeData(logicOpt, SWITCH_ON, testWord);
            BspSysMsDelay(1000); /*1s*/
            ret |= IcHalApiOptCpriGetFsTypeData(logicOpt, &testCheckWord);
        }
        else
        {
            ret |= IcHalApiOptCpriDLinkSetSendDataEn(logicOpt, SWITCH_ON);
            ret |= IcHalApiOptCpriDLinkSetSendData(logicOpt, testWord);
            BspSysMsDelay(1000);
            ret |= IcHalApiOptCpriDLinkGetRegVal(logicOpt, &testCheckWord);
        }

        if(testWord != testCheckWord)
        {
            BspLog(LOG_LEVEL_0,"testWord=[0x%08x],testCheckWord=[0x%08x], RRU is not in self loop mode!\n", testWord, testCheckWord);
            dbgInfo("testWord=[0x%08x],testCheckWord=[0x%08x], RRU is not in self loop mode!\n", testWord, testCheckWord);
            ret |= BSP_ERROR;
            break;
        }
    }

    /*关闭发送cpriPrbs*/
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 0, 0);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 1, 0);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 2, 0);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 3, 0);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 4, 0);
    ret |= IcHalApiCpriMaskDataGen(logicOpt, 5, 0);
    ret |= IcHalApiSwTestGenEn(2,0);
    ret |= IcHalApiCpriTxDataType(logicOpt, 0, 0);

    ret |= IcHalApiCpriSetRelation(logicOpt, oriPhyOpt, cpuCfgEn);
    ret |= IcHalApiCpriMapConfig(sw, isHoldover, mainPhyOpt);
    ret |= IcHalApiCpriCfgOptProperty(phyOpt, property, propertyCfgEn, chipInterConn);
    ret |= IcHalApiSwAlignFrSel(logicOpt, swRdFrSel, swAlign);
    ret |= IcHalApiOptCpriSetFsTypeData(logicOpt, SWITCH_OFF, 0);
    ret |= IcHalApiOptCpriDLinkSetSendData(logicOpt, 0);
    ret |= IcHalApiOptCpriDLinkSetSendDataEn(logicOpt, SWITCH_OFF);
    ret |= IcHalApiCpriSetFrTestMode(logicOpt, SWITCH_OFF);

    return ret;
}

UINT32 BspGetOptLoopStaCw(UINT32 ulPhyOpt)
{
    UINT32 uRet = BSP_OK;
    UINT32 ulOriPhyOpt = 0;
    UINT32 ulLogicOpt = 0;
    UINT32 ulCpuCfgEn = 0;
    UINT32 ulSw = 0;
    UINT32 uIsHoldover = 0;
    UINT32 uMainPhyOpt = 0;
    UINT32 ulProperty = 0;
    UINT32 ulPropertyCfgEn = 0;
    UINT32 ulChipInterConn = 0;
    UINT32 ulSwInfo = 0;
    UINT32 ulSwRdFrSel = 0;
    UINT32 ulSwAlign = 0;
    UINT32 ulProtocol = 0;
    UINT32 ulTestWord = 0x0F0F;  /*cw*/
    UINT32 ulTestCheckWord = 0;

    uRet |= IcHalApiCpriGetCfgRelation(ulLogicOpt, &ulOriPhyOpt, &ulCpuCfgEn);
    ulPhyOpt = (ulOriPhyOpt >= OPT_MAX) ? ulPhyOpt : ulOriPhyOpt;

    uRet |= IcHalApiCpriGetMapConfig(&ulSw, &uIsHoldover, &uMainPhyOpt);
    uRet |= IcHalApiCpriMapConfig(ENABLE, ENABLE, ulPhyOpt);

    uRet |= IcHalApiCpriGetCfgOptProperty(ulPhyOpt, &ulProperty, &ulPropertyCfgEn, &ulChipInterConn);
    uRet |= IcHalApiGetSwAlignFrSel(ulLogicOpt, &ulSwInfo);

    uRet |= IcHalApiCpriSetRelation(ulLogicOpt, ulPhyOpt, ENABLE);
    uRet |= IcHalApiCpriCfgOptProperty(ulPhyOpt, 0, ENABLE, 0);
    /*bit0-sync with fr or chip head; bit4-bypass align or through align.*/
    if((ulSwInfo & 0x11) != 0)
    {
        uRet |= IcHalApiSwAlignFrSel(ulLogicOpt, ulSwRdFrSel, ulSwAlign);
        ulSwRdFrSel = (ulSwInfo & 0x1);
        ulSwAlign = (ulSwInfo & 0x10);
    }

    uRet |= IcHalApiCpriSetFrTestMode(ulLogicOpt, SWITCH_ON);
    uRet |= IcHalApiGetCpriProtocol(&ulProtocol);
    if(PROCOTOL_CPRI == ulProtocol)
    {
        uRet |= IcHalApiOptCpriSetFsTypeData(ulLogicOpt, SWITCH_ON, ulTestWord);
        uRet |= BspSetMultSerdesRxInit(ulPhyOpt);
        uRet |= IcHalApiOptCpriGetFsTypeData(ulLogicOpt, &ulTestCheckWord);
    }
    else
    {
        uRet |= IcHalApiOptCpriDLinkSetSendDataEn(ulLogicOpt, SWITCH_ON);
        uRet |= IcHalApiOptCpriDLinkSetSendData(ulLogicOpt, ulTestWord);
        uRet |= BspSetMultSerdesRxInit(ulPhyOpt);
        uRet |= IcHalApiOptCpriDLinkGetRegVal(ulLogicOpt, &ulTestCheckWord);
    }

    uRet |= IcHalApiCpriSetRelation(ulLogicOpt, ulOriPhyOpt, ulCpuCfgEn);
    uRet |= IcHalApiCpriMapConfig(ulSw, uIsHoldover, uMainPhyOpt);
    uRet |= IcHalApiCpriCfgOptProperty(ulPhyOpt, ulProperty, ulPropertyCfgEn, ulChipInterConn);
    uRet |= IcHalApiSwAlignFrSel(ulLogicOpt, ulSwRdFrSel, ulSwAlign);
    uRet |= IcHalApiOptCpriSetFsTypeData(ulLogicOpt, SWITCH_OFF, 0);
    uRet |= IcHalApiOptCpriDLinkSetSendData(ulLogicOpt, 0);
    uRet |= IcHalApiOptCpriDLinkSetSendDataEn(ulLogicOpt, SWITCH_OFF);
    uRet |= IcHalApiCpriSetFrTestMode(ulLogicOpt, SWITCH_OFF);

    if(ulTestWord != ulTestCheckWord)
    {
        dbgInfo("ulTestWord=[%u],ulTestCheckWord=[%u], RRU is not in self loop mode!\n", ulTestWord, ulTestCheckWord);
        uRet |= BSP_ERROR;
    }
    else
    {
        dbgInfo("ulTestWord=[%u],ulTestCheckWord=[%u], RRU is in self loop mode!\n", ulTestWord, ulTestCheckWord);
        uRet = BSP_OK;
    }
    
    return uRet;
}


UINT32 BspSetHGOptSpeedCallBack(HGOptCheckCall HGOptFlag)
{
    g_HGOptSpeedFlag = HGOptFlag;
    return BSP_OK;
}

UINT32 BspGetOptPhyStatus(UINT32 optId, UINT32 *lopAlrm, UINT32 *losAlrm, UINT32 *lofAlrm)
{
    UINT32 optSta  = 0;
    UINT32 sfpNo = 0;
    INPUT_PHYOPT_INDEX_CHECK(optId);

    sfpNo = BspGetSfpNoByPhyNo(optId);
    optSta = BspGetOptStatus(sfpNo);
    if(optSta == BSP_ERROR)
    {
        return BSP_ERROR;
    }

    *lopAlrm = !!(optSta & BSP_OPT_ERR_LOP) ;
    *losAlrm = !!(optSta & BSP_CPRI_ERR_LOS);
    *lofAlrm = !!(optSta & BSP_OPT_ERR_LOF);

    dbgInfoEx("[%s]: optId[%d], optSta[%d], lopAlrm[%d], losAlrm[%d], lofAlrm[%d]. \n",
            __FUNCTION__, optId, optSta, *lopAlrm, *losAlrm, *lofAlrm);
    return BSP_OK;
}

/*获取物理主光口对应的光笼子编号 OSS用来当BspGetRruId的入参*/
UINT32 BspGetRruMsOptId(UINT8 *pucRruMsOptId)
{
    UINT32 retVal = BSP_OK;
    UINT32 phyMainOpt = 0;
    UINT32 sfpNo = 0;

    INPUT_POINTER_CHECK(pucRruMsOptId);
    *pucRruMsOptId = 0;

    /*先解析出物理主光口号*/
    retVal = BspHalAdaptGetMainPhyOpt(&phyMainOpt);
    if ((retVal != BSP_OK) || (phyMainOpt == BSP_ERROR))
    {
        dbgErr("%s>>PhyMainOpt'%d Get Error! FunRet= %d\n",
               __FUNCTION__, phyMainOpt, retVal);
        return BSP_OK; /*参照3.0 固定返回OK*/
    }

    sfpNo = BspGetSfpNoByPhyNo(phyMainOpt);
    *pucRruMsOptId = (UINT8)sfpNo;

     return BSP_OK;
}

/**************************************************************************
 * 函数名称： BspGetRruMSOptID
 * 功能描述： 获取RRU光口主备状态
 * 输入参数： *pRruMsOptId:上报主光口号
 * 返 回 值： BSP_OK:成功，其他:错误
 * 其它说明： 无
 **************************************************************************/
UINT32 BspGetRruMSOptID(UCHAR *pRruMsOptId)
{
    if(NULL == pRruMsOptId)
    {
        return BSP_ERROR;
    }
    *pRruMsOptId = BspGetCurrFiberPort();  /*主光口对应的光笼编号*/

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetReverseDirection
*  功能描述   : 获取RRU的倒换方向(主备链路上报)
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :'0'-RRU在BBU的主链路上
*              '1'-RRU在BBU的从链路上
*             :指示RRU倒向:
*             :0 - 倒向BBU光口0
*             :1 - 倒向BBU光口1
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 10229672 2019-05-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetReverseDirection()
{
    UINT32 dir = 0;
    UINT32 optWorkMode = 0;

    optWorkMode = BspGetDefaultOptWorkMode(0);
    if((BSP_OPT_WORK_MODE_NORMAL == optWorkMode)||(BSP_OPT_WORK_MODE_RING == optWorkMode))
    {
        BspHalAdaptCpriGetRruDirection(&dir);
        return dir;
    }
    else
    {
        return dir;
    }
}
/*倒换时中频告警屏蔽*/
UINT32 BspOptLogicPortPowProtectSel(VOID)
{
    UINT32 ulLogOpt = 0;
    UINT32 ulWorkMode = 0;
    UINT32 ulPhyOpt = 0;
    UINT32 ulOptSta = 0;

    ulWorkMode = BspGetOptWorkMode(0);
    BspHalAdaptGetMainLogicOpt(&ulLogOpt);
    if(ulLogOpt == BSP_ERROR)
    {
        if(BSP_OPT_WORK_MODE_SHARE == ulWorkMode)
        {
            BspHalAdaptCpriCfgMidfreqAlmShutDataEn(0,SWITCH_ON);
            BspHalAdaptCpriCfgMidfreqAlmShutDataEn(1,SWITCH_ON);
        }
        return BSP_ERROR;
    }
    BspHalAdaptCpriMidFreqBfnSel(ulLogOpt); /*中频帧号来源选择*/
    BspHalAdaptCpriPsyncBfnSel(ulLogOpt);   /*Psync帧号来源选择*/
    BspHalDifPaOffOptAlmMaskPaptCfg(ulLogOpt);  /*光口中频关功放告警掩码*/
    //BspHalAdaptCpriSetSW2FrDelay();

    if(BSP_OPT_WORK_MODE_SHARE != ulWorkMode)
    {
        if(ulLogOpt == 0)
        {
            BspHalAdaptCpriCfgMidfreqAlmShutDataEn(0,SWITCH_ON);
            BspHalAdaptCpriCfgMidfreqAlmShutDataEn(1,SWITCH_OFF);
        }
        if(ulLogOpt == 1)
        {
             BspHalAdaptCpriCfgMidfreqAlmShutDataEn(1,SWITCH_ON);
             BspHalAdaptCpriCfgMidfreqAlmShutDataEn(0,SWITCH_OFF);
        }
    }
    else   /*负荷分担 光口有lop  不需要使能*/
    {
         ulPhyOpt = BspHalAdaptGetPhyOpt(ulLogOpt);
         BspHalAdaptCpriCfgMidfreqAlmShutDataEn(ulLogOpt,SWITCH_ON);
         ulOptSta = _BspCheckPhyOptState(1-ulPhyOpt);
         if(BSP_OK != ulOptSta)
         {
             BspHalAdaptCpriCfgMidfreqAlmShutDataEn(1-ulLogOpt,SWITCH_OFF);
         }
         else
         {
             BspHalAdaptCpriCfgMidfreqAlmShutDataEn(1-ulLogOpt,SWITCH_ON);
         }
    }

    return BSP_OK;
}

UINT32 BspAdaptChangeSerdesSpeed(UINT32 sfp, UINT32  ulSpd)
{
    UINT32 ulRetVal = 0;
	UINT32 ulSerdesLaneRate =0;   /*serdes线速率*/
	UINT32 ulPhyOptNo = 0;
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};
	INPUT_OPT_CHECK(sfp);

    BspLog(LOG_LEVEL_0,"%s@%d>sfp %d, speed %d In\n", __func__, __LINE__, sfp, ulSpd);
	switch(ulSpd)
	{
	    case BSP_OPT_SPEED_9P8304G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_9G83;
	        break;
	    }
	    case BSP_OPT_SPEED_10P1376G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_10G13;
	        break;
	    }
	    case BSP_OPT_SPEED_24P33024G:
	    {
	    	ulSerdesLaneRate = SERDES_RATE_24G33;
	        break;
	    }
        default:
        {
            dbgErr("%s@%d>SerdesLaneRate %d is not in list\n", __func__, __LINE__,ulSpd);
            BspLog(LOG_LEVEL_0,"%s@%d>SerdesLaneRate %d is not in list\n", __func__, __LINE__, ulSpd);
            return BSP_ERROR;
        }
	}
    //第一步：lane 初始化
    ulPhyOptNo = BspGetPhyNoBySfpNo(sfp);   /*光笼编号转换到物理光口号*/
    ulRetVal = BspGetSerdesParaByPhyNo(ulPhyOptNo,&rateSerdesPara);
    BspLog(LOG_LEVEL_0,"%s@%d>sfp %d, speed %d ulPhyOptNo %d, BspGetSerdesParaByPhyNo ulRetVal %d\n",\
                         __func__, __LINE__, sfp, ulSpd, ulPhyOptNo, ulRetVal);
    if(ulRetVal != BSP_OK)
    {
        dbgErr("%s@%d>BspGetSerdesParaByPhyNo failed\n", __func__, __LINE__);
        BspLog(LOG_LEVEL_0,"%s@%d>sfp %d, speed %d ulPhyOptNo %d, BspGetSerdesParaByPhyNo Failed Return\n",\
                         __func__, __LINE__, sfp, ulSpd, ulPhyOptNo);
        return BSP_ERROR;
    }

    ulRetVal = _BspCheckPhyOptIsLop(ulPhyOptNo);
    BspLog(LOG_LEVEL_0,"%s@%d>sfp %d, speed %d ulPhyOptNo %d, _BspCheckPhyOptIsLop ulRetVal %d\n",\
                         __func__, __LINE__, sfp, ulSpd, ulPhyOptNo, ulRetVal);
    if(BSP_OK != ulRetVal)
    {
        BspLog(LOG_LEVEL_0,"%s@%d>sfp %d, speed %d ulPhyOptNo %d, _BspCheckPhyOptIsLop Failed Return\n",\
                        __func__, __LINE__, sfp, ulSpd, ulPhyOptNo);
        return BSP_ERROR;    /*不接光模块（电模块或者不接）不应该配置serdes*/
    }

    ulRetVal = BspHalChangeSerdesRxLaneRate(0,ulPhyOptNo,ulSerdesLaneRate,&rateSerdesPara);
    BspLog(LOG_LEVEL_0,"%s@%d>sfp %d, speed %d ulPhyOptNo %d, BspHalChangeSerdesRxLaneRate ulRetVal %d\n",\
                        __func__, __LINE__, sfp, ulSpd, ulPhyOptNo, ulRetVal);
    if(ulRetVal != BSP_OK)
    {
        dbgErr("%s@%d>BspHalChangeSerdesRxLaneRate failed\n", __func__, __LINE__);
    }
    BspLog(LOG_LEVEL_0,"%s@%d>sfp %d, speed %d ulPhyOptNo %d, BspHalChangeSerdesRxLaneRate ulRetVal %d\n",\
                    __func__, __LINE__, sfp, ulSpd, ulPhyOptNo, ulRetVal);
    return ulRetVal;
}

/*光口没告警和时钟锁定不等价，主光口识别出来才有恢复钟输出  时钟才能锁定,但是主光口识别出来不一定就能时钟锁定*/
UINT32 BspCheckSysPllState(VOID)
{
    UINT32 clkStatus = 0;
    UINT32 ulRet = BSP_OK;

    ulRet = BspHalAdaptGetSysLd(0,&clkStatus);
    dbgInfoEx("clkStatus %d mainopt %d\n",clkStatus,BspGetMainPhyOpt());
    if(ulRet != BSP_OK)
    {
       return BSP_ERROR;
    }
    if(clkStatus != 0)/*跟数字确认我们只用LD0判断 0表示锁定*/
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}
/*判断光口的映射关系是否识别出来了  0xc2403520 返回0xb 表示映射关系还没识别出来*/
UINT32 BspGetOptMapStatus(UINT32 logOpt)
{
    UINT32 tmp0 = 0;
    UINT32 tmp1 = 0;
    UINT32 tmp2 = 0;

    tmp0 = BspHalAdaptGetPhyOpt(logOpt);
    BspSysMsDelay(10);
    tmp1 = BspHalAdaptGetPhyOpt(logOpt);
    BspSysMsDelay(10);
    tmp2 = BspHalAdaptGetPhyOpt(logOpt);
    dbgInfoEx("logopt0 tmp0 %d tmp1 %d tmp2 %d\n",tmp0,tmp1,tmp2);
    if((tmp0 != VIRTUAL_OPT)&&(tmp1 != VIRTUAL_OPT)&&(tmp2 != VIRTUAL_OPT))
    {
         return BSP_OK;  /*连续两次结果都为非b*/
    }

    return BSP_ERROR;
}

/*光口信令来源选择*/
UINT32 BspSetOptCpriCfgCmUxSel(VOID)
{
    UINT32 mainPhyOpt = 0;
    UINT32 mainLogOpt = 0;
    UINT32 slaveLogOpt = 0;

    BspHalAdaptGetMainPhyOpt(&mainPhyOpt);  /*主光口状态寄存器0xc2403410*/
    if(mainPhyOpt == BSP_ERROR)  /* 光口处于holdover态度*/
    {
        return BSP_ERROR;
    }
    mainLogOpt = BspHalAdaptGetLogOpt(mainPhyOpt);
    if(BSP_ERROR != mainLogOpt)
    {
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_0,mainLogOpt); /* 信令路由选择 上联逻辑口是0 1  第一个参数是总共四个信令口*/
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_1,1-mainLogOpt);
    }
    slaveLogOpt = BspHalAdaptGetLogOpt(1- mainPhyOpt);
    if( _SetOptCpriCfgCmUxSelCntX || !(_SetOptCpriCfgCmUxSelCntY % 2030))
    {
        BspLog(LOG_LEVEL_1,"[%s]:mainPhyOpt[%d], slaveLogOpt[%d] \n", __FUNCTION__, mainPhyOpt, slaveLogOpt);
    }
    _SetOptCpriCfgCmUxSelCntY++;

    if(BSP_ERROR != slaveLogOpt)
    {
        if(slaveLogOpt < LOG_OPT_2)
        {
            slaveLogOpt = LOG_OPT_2;
        }
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_2,slaveLogOpt); /* 信令路由选择 下联逻辑口是2 3 总和是5*/
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_3,5-slaveLogOpt);
    }

    return BSP_OK;
}
/*判断当前时刻主光口状态是否满足从双上联切回正常模式的状态 需要满足主光口非holdover 且光口映射正常*/
UINT32 BspJudgeMainOptStatus(VOID)
{
    UINT32 mainPhyOpt = 0;
    UINT32 retVal = BSP_OK;

    BspHalAdaptGetMainPhyOpt(&mainPhyOpt);  /*主光口状态寄存器0xc2403410*/
    dbgInfoEx("mainopt %d\n",mainPhyOpt);
    if(mainPhyOpt == BSP_ERROR)  /* 光口处于holdover态度*/
    {
        return BSP_ERROR;
    }
    retVal = BspGetOptMapStatus(LOG_OPT0);
    if(retVal == BSP_OK)
    {
        return BSP_OK;  /*任意一个连续两次结果都为非b*/
    }
    retVal = BspGetOptMapStatus(LOG_OPT1);
    if(retVal == BSP_OK)
    {
        return BSP_OK;  /*任意一个连续两次结果都为非b*/
    }

    return BSP_ERROR;
}


UINT32 BspSetDownLinkOpt(UINT32 phyOpt)
{
    UINT32 retVal = BSP_OK;

    if(BSP_OK == BspJudgeMainOptStatus()) /*映射关系识别出来之后才能恢复*/
    {
        BspSetOptCpriCfgCmUxSel();
        retVal = BspHalAdaptCpriCfgOptProperty(1-phyOpt,1,1,0);  //释放光口属性寄存器（0xc24031d8--0xc24031e4）
    }

    return retVal;
}

UINT32 BspSetDoubleUpLinkOpt(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptCpriCfgOptProperty(0,0,1,0);   /*主光口未识别前强制设置双上联口*/
    retVal |= BspHalAdaptCpriCfgOptProperty(1,0,1,0);

    return retVal;
}

static UINT32 BspSetOptBindRelation(UINT32 phyOpt)
{
    UINT32 mainLogOptNo = 0;
    UINT32 slaveLogOptNo = 0;

    mainLogOptNo = BspGetLogicPort(phyOpt);
    if(mainLogOptNo > LOG_OPT1)
    {
        return BSP_ERROR;
    }
    slaveLogOptNo = BspHalAdaptGetLogOpt(1 - phyOpt);
    if((slaveLogOptNo > LOG_OPT3) || (slaveLogOptNo < LOG_OPT2))
    {
        return BSP_ERROR;
    }

    if(BspGetTddSupportRingModeWorkFlag() == 1)
    {
        BspSetOptCpriCwOptBindCfg(mainLogOptNo,slaveLogOptNo);
        BspSetOptCpriCwOptBindCfg(slaveLogOptNo,mainLogOptNo);
        if(g_lastMainOptNo != mainLogOptNo)
        {
            g_lastMainOptNo = mainLogOptNo;
            BspLog(LOG_LEVEL_0,"%s:phyOpt  = %d, mainLogOptNo = %d, slaveLogOptNo = %d\n",
                    __FUNCTION__,phyOpt, mainLogOptNo, slaveLogOptNo);
        }
    }

    return BSP_OK;
}

static UINT32 BspSetOptCfgFormCpri(void)
{
    UINT32 retVal = BSP_OK;

    if((BspGetIrCaseCadeCpriFlag() == IR_CASECADE_CPRI_FLAG) && (s_SetOptCfgCnt < SET_OPT_CFG_CNT_MAX))
    {
        s_SetOptCfgCnt ++;
        retVal |= BspHalAdaptCpriSetSerdesCdcRxStableWind(0,0x10);
        retVal |= BspHalAdaptCpriSetSerdesCdcRxStableWind(1,0x10);
        retVal |= BspHalAdaptSwCfgIqCloseEn(0, DISABLE, TX);
        retVal |= BspHalAdaptSwCfgIqCloseEn(1, DISABLE, TX);
    }

    return retVal;
}

/* 对应接口BspSetOptCfgFormCpri,异常时清0 */
UINT32 BspClrOptCfgCnt(void)
{
    s_SetOptCfgCnt = 0;

    return s_SetOptCfgCnt;
}

/*光口配置双上联和光口自震荡 为主光口识别做准备*/
UINT32 BspSetOptFrAndProperty(UINT32 sw,UINT32 phyOpt)
{
    UINT32 ulRet = BSP_OK;
    UINT32 optWorkMode = BspGetOptWorkMode(0);

    if((sw == SWITCH_ON) || (optWorkMode == BSP_OPT_WORK_MODE_MAIN_SLAVE))/*主备两个光口都是上联口，不需要自震荡*/
    {
        BspSetOptCfgFormCpri();/*cpri协议操作的动作需要在切换到IR时打开，正常时配置10次*/
        if(BSP_OK == BspJudgeMainOptStatus()) /*映射关系识别出来之后才能恢复*/
        {
            BspSetOptCpriCfgCmUxSel();
            BspHalAdaptCpriSetFrTestMode(LOG_OPT0,DISABLE);
            BspHalAdaptCpriSetFrTestMode(LOG_OPT1,DISABLE);  /*去掉帧头自震荡*/
            if(optWorkMode != BSP_OPT_WORK_MODE_SHARE)   /*符合分担固定是双上联*/
            {
                 ulRet = BspHalAdaptCpriCfgOptProperty(1-phyOpt,1,1,0);  //释放光口属性寄存器（0xc24031d8--0xc24031e4）
            }
            else
            {
                 ulRet = BspHalAdaptCpriCfgOptProperty(1-phyOpt,0,1,0);
            }
            BspSetOptBindRelation(phyOpt);
        }
    }
    else
    {
        BspClrOptCfgCnt();
        BspHalAdaptCpriSetFrTestMode(LOG_OPT0,ENABLE);
        BspHalAdaptCpriSetFrTestMode(LOG_OPT1,ENABLE); /*开始解析出来的帧头不稳，送给pcs，pcs检测到异常，触发pcs复位，对端会检测到异常，然后pcs收到的信号就有告警。所以先自震荡，不用外部*/
        ulRet = BspHalAdaptCpriCfgOptProperty(0,0,1,0);   /*主光口未识别前强制设置双上联口*/
        BspSysMsDelay(100);
        ulRet |= BspHalAdaptCpriCfgOptProperty(1,0,1,0);
    }

    return ulRet;
}

/* 从flash读取配置双BBU标志 */
UINT32 BspGetDunDancyMode(VOID)
{
    UINT32  ulOffset = 0;
    UINT32  ulBufSize = 4;
    CHAR *pBuf = NULL;
    static UINT32 ruRedundancyMode = BSP_ERROR;

    if(BSP_ERROR != ruRedundancyMode)
    {
        dbgInfoEx("%s DunDancyMode:%d\n", __FUNCTION__, ruRedundancyMode);
        return ruRedundancyMode;
    }
    pBuf = (CHAR *)malloc(ulBufSize);
    if(NULL == pBuf)
    {
        dbgInfo("%s malloc failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s(pBuf, ulBufSize, 0, ulBufSize);

    if (BSP_OK != BspLoadFileNew(RRU_PARA_FILE_RUREDUNDANCY_MODE, pBuf, ulOffset, ulBufSize))
    {
        dbgInfo("%s BspLoadFile failed\n", __FUNCTION__);
        free(pBuf);
        return BSP_ERROR;
    }

    memcpy_s(&ruRedundancyMode, sizeof(ruRedundancyMode), pBuf, ulBufSize);
    dbgInfo("%s DunDancyMode:%d\n", __FUNCTION__, ruRedundancyMode);
    BspLog(LOG_LEVEL_0,"%s DunDancyMode:%d\n", __FUNCTION__, ruRedundancyMode);
    free(pBuf);

    return ruRedundancyMode;
}

UINT32 BspSetCpriCfgIqCloseSetFlag(UINT32 flag)
{
    s_cpriCfgIqCloseSetFlag = flag;
    return s_cpriCfgIqCloseSetFlag;
}

UINT32 BspGetCpriCfgIqCloseSetFlag()
{
    return s_cpriCfgIqCloseSetFlag;
}
UINT32 BspCpriCfgIqCloseEn(UINT32 ulEn)
{
    UINT32 logOptLoop = 0;

    for (logOptLoop = 0; logOptLoop < OPT_MAX; logOptLoop++)
    {
        /* ulEn:DISABLE打开逻辑口的上下行数据， ENABLE关闭逻辑口的上下行数据 */
        IcHalApiCpriCfgIqCloseEn(logOptLoop, ulEn, RX);
        IcHalApiCpriCfgIqCloseEn(logOptLoop, ulEn, TX);
    }

    return BSP_OK;
}

UINT32 BspSoftenRruIndexrClose()
{
    UINT32 resetType = 0;

    resetType = BspGetBoardResetType();
    if(BSP_APP_SOFT_RESET == resetType || BSP_LOCAL_REBOOT == resetType || BSP_OMC_HARD_RESET== resetType)
    {
        BspLog(LOG_LEVEL_0,"**BspSoftenRruIndexrClose not close resetType:%d**\n",resetType);
        return BSP_OK;
    }
    if(BBU_REDUNDANCY_MODE == BspGetDunDancyMode())
    {
        BspHalAdaptSoftenRruIndexrCw(1);
        BspCpriCfgIqCloseEn(ENABLE); /*ENABLE关闭逻辑口的上下行数据*/
        BspSetCpriCfgIqCloseSetFlag(0);
        BspLog(LOG_LEVEL_0,"**BspSoftenRruIndexrClose**\n");
    }

    return BSP_OK;
}

/* 清IQ */
UINT32 BspIqCfgClear(VOID)
{
    UINT32 ret = BSP_OK;
    ret = BspHalAdaptSw2TblClr();
    BspLog(LOG_LEVEL_0,"**BspIqCfgClear**\n");
    return ret;
}

UINT32 BspClearLocalIqCfg(VOID)
{
    return BSP_OK;
}

/* 重配IQ */
UINT32 BspRecfgOptIq(VOID)
{
    UINT32 ret = BSP_OK;
    ret = BspHalAdaptReCfgSw2Tbl();
    BspLog(LOG_LEVEL_0,"**BspRecfgOptIq**\n");
    return ret;
}

/* 强制反向倒换使能开关， 1：开， 0：关 */
VOID BspSetReverseSwitchoverSw(UINT32 sw)
{
    s_reverseSwitchoverSw = sw;
    BspLog(LOG_LEVEL_0,"**BspSetReverseSwitchoverSw sw:%d**\n", sw);
}

UINT32 BspGetForceSetMainOptMode()
{
    return ulForceSetMainOpt;
}

UINT32 BspGetCurrReverseMainOpt()
{
    return s_currMainOpt;
}

/* Started by AICoder, pid:s5af0fdc54rf12d14561097340e8193e4568cf10 */
UINT32 BspDelayOpenTxSwCfgIq(VOID)
{
    UINT32 delayTime = swCfgIqEnCnt *100;
    BspSysMsDelay(delayTime);
    if(ulMainOptChangeflag == 1)
    {
        BspHalAdaptSwCfgIqCloseEn(0, DISABLE, TX);
        BspHalAdaptSwCfgIqCloseEn(1, DISABLE, TX);
        BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty SwCfgIqEn delayTime:%d * (0.1S) tick:%llu\n", delayTime,tick64Get());
    }
    else
    {
        BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty Not SwCfgIqEn\n");
    }

    return BSP_OK;
}

UINT32 BspDelayOpenTxSwCfgIqThreadInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    static INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;
#ifndef UT_FT_TEST
    lTaskID = taskSpawn("BspDelayOpenTxSwCfgIq", 100, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspDelayOpenTxSwCfgIq, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
#endif
    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgInfo("!!! Creat BspChkOptSwitchoverThread Error !!!\n");
        ulRet = BSP_ERROR;
    }

    return ulRet;
}
/* Ended by AICoder, pid:s5af0fdc54rf12d14561097340e8193e4568cf10 */

UINT32 BspReleaseReverseMainOpt(UINT32 ulPhyOptNo)
{
    BspSysMsDelay(s_reverseTime);
    ulForceSetMainOpt = OPT_FORCE_AUTO;
    if(s_currMainOpt != s_lastMainOpt)
    {
        s_lastMainOpt = BSP_ERROR;
    }
    BspLog(LOG_LEVEL_0,"**BspReleaseReverseMainOpt s_currMainOpt:%d, s_lastMainOpt:%d**\n", s_currMainOpt, s_lastMainOpt);
    return BSP_OK;
}

UINT32 BspReleaseReverseMainOptThreadInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    static INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;

    lTaskID = taskSpawn("BspReleaseReverseMainOpt", 100, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspReleaseReverseMainOpt, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgInfo("!!! Creat BspChkOptSwitchoverThread Error !!!\n");
        ulRet = BSP_ERROR;
    }

    return ulRet;
}

/* 强设反向主光口 */
UINT32 BspForceReverseMainOpt(UINT32 ulPhyOptNo)
{
    BspSetOptCpriRelation(LOG_OPT1,ulPhyOptNo,1);
    BspSetOptCpriRelation(LOG_OPT2,1 - ulPhyOptNo,1);
    BspSetOptCpriRelation(LOG_OPT0,0,0);
    BspHalAdaptCpriCfgOptProperty(ulPhyOptNo,0,1,0);   /*设置上次主光口的反向光口为上联口*/
    BspHalAdaptCpriCfgOptProperty(1 - ulPhyOptNo,1,1,0);
    BspHalAdaptCpriSetFrTestMode(LOG_OPT1,ENABLE);

    return BSP_OK;
}

/* 强制反向倒换3S，双BBU拔主控板100ms异常，需要全部倒换 */
UINT32 BspReverseSwitchover()
{
    if(SWITCH_ON != s_reverseSwitchoverSw || -1 == s_lastMainOpt)
    {
        return BSP_OK;
    }
    if(ulForceSetMainOpt != OPT_FORCE_AUTO)
    {
        return BSP_OK;
    }
    ulForceSetMainOpt = 2;
    s_currMainOpt = 1 - s_lastMainOpt;
    BspLog(LOG_LEVEL_0,"**BspReverseSwitchover lastMainOpt:%d**\n",s_lastMainOpt);
    BspReleaseReverseMainOptThreadInit();
    return BSP_OK;
}

/* Started by AICoder, pid:h218a15c15yef941436008a9a0a28675ef08a0bb */
UINT32 BspSetMainOptFrAndProperty(UINT32 setMainOpt)
{
    UINT32 ulRet = BSP_OK;

    if(setMainOpt == OPT_FORCE_OPT0)
    {
        BspSetOptCpriRelation(LOG_OPT1,PHY_OPT0,1);
        BspSetOptCpriRelation(LOG_OPT2,PHY_OPT1,1);
        BspSetOptCpriRelation(LOG_OPT0,0,0);
        BspSetOptCpriRelation(LOG_OPT3,0,0);
        BspHalAdaptCpriCfgOptProperty(0,0,1,0);  /*设置光口0为上联口*/
        BspHalAdaptCpriCfgOptProperty(1,1,1,0);
        BspHalAdaptCpriSetFrTestMode(LOG_OPT1,ENABLE);
        BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty ForceSetMainOpt OPT_FORCE_OPT0**\n");
    }
    else if(setMainOpt == OPT_FORCE_OPT1)
    {
        BspSetOptCpriRelation(LOG_OPT1,PHY_OPT1,1);
        BspSetOptCpriRelation(LOG_OPT2,PHY_OPT0,1);
        BspSetOptCpriRelation(LOG_OPT0,0,0);
        BspSetOptCpriRelation(LOG_OPT3,0,0);
        BspHalAdaptCpriCfgOptProperty(1,0,1,0);  /*设置光口0为上联口*/
        BspHalAdaptCpriCfgOptProperty(0,1,1,0);
        BspHalAdaptCpriSetFrTestMode(LOG_OPT1,ENABLE);
        BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty ForceSetMainOpt OPT_FORCE_OPT1**\n");
    }
    else if(setMainOpt == OPT_FORCE_REVERSE)
    {
        BspForceReverseMainOpt(s_currMainOpt);
    }
    else
    {
        BspHalAdaptCpriSetFrTestMode(LOG_OPT0,ENABLE);
        BspHalAdaptCpriSetFrTestMode(LOG_OPT1,ENABLE); /*开始解析出来的帧头不稳，送给pcs，pcs检测到异常，触发pcs复位，对端会检测到异常，然后pcs收到的信号就有告警。所以先自震荡，不用外部*/
        ulRet = BspHalAdaptCpriCfgOptProperty(0,0,1,0);   /*主光口未识别前强制设置双上联口*/
        ulRet |= BspHalAdaptCpriCfgOptProperty(1,0,1,0);
        BspSetOptCpriRelation(LOG_OPT0,PHY_OPT0,1);
        BspSetOptCpriRelation(LOG_OPT1,PHY_OPT1,1);
        BspSetOptCpriRelation(LOG_OPT2,0,0);
        BspSetOptCpriRelation(LOG_OPT3,0,0);
    }

    return ulRet;
}

/* 高层调用，获取RRU在第几级 */
UINT32 BspGetOptRruIndex(UINT32 *rruIndex)
{
    UINT32 ret = BSP_OK;
    UINT32 optRruindex = BSP_ERROR;

    INPUT_POINTER_CHECK(rruIndex);
    ret = BspHalAdaptGetMainOptRruIndex(&optRruindex);
    *rruIndex = optRruindex;
    BspLog(LOG_LEVEL_0,"BspGetOptRruIndex rruIndex:%d\n", optRruindex);
    dbgInfo("BspGetOptRruIndex rruIndex:%d\n", optRruindex);

    return ret;
}
/* Ended by AICoder, pid:h218a15c15yef941436008a9a0a28675ef08a0bb */

/* 固定主光口0 */
UINT32 BspForceSetMainOpt(UINT32 ulPhyOptNo)
{
    UINT32 mainPhyOptNo = 0;
    UINT32 resetType = 0;

    BspHalAdaptGetMainPhyOpt(&mainPhyOptNo);
    resetType = BspGetBoardResetType();
    BspLog(LOG_LEVEL_0,"BspForceSetMainOpt Current mainPhyOptNo:%d, forceMainOpt:%d resetType:%d\n", mainPhyOptNo, ulPhyOptNo, resetType);
    if(BSP_APP_SOFT_RESET == resetType || BSP_LOCAL_REBOOT == resetType || BSP_OMC_HARD_RESET== resetType || ulPhyOptNo == mainPhyOptNo)
    {
        return BSP_OK;
    }
    if(0 == ulPhyOptNo)
    {
        ulForceSetMainOpt = OPT_FORCE_OPT0;
    }
    else if(1 == ulPhyOptNo)
    {
        ulForceSetMainOpt = OPT_FORCE_OPT1;
    }
    else
    {
        ulForceSetMainOpt = OPT_FORCE_AUTO;
        BspLog(LOG_LEVEL_0,"BspForceSetMainOpt error forceMainOpt:%d \n", ulPhyOptNo);
        return BSP_ERROR;
    }
    qcelloptadptoff();
    BspSysMsDelay(20);
    ulMainOptChangeflag = 0;
    BspSetMainOptFrAndProperty(ulForceSetMainOpt);
    BspSysMsDelay(500);
    qcelloptadpton();

    return BSP_OK;
}

UINT32 BspReleaseMainOptForceSet(UINT32 ulPhyOptNo)
{
    UINT32 mainPhyOptNo = 0;

    ulForceSetMainOpt = OPT_FORCE_AUTO;
    BspHalAdaptGetMainPhyOpt(&mainPhyOptNo);
    ulMainOptChangeflag = 0;  /* 固定主光口0失败，释放时走恢复流程，防止光口属性未恢复断链 */
    BspHalAdaptSoftenRruIndexrCw(0);
    BspCpriCfgIqCloseEn(DISABLE); /*DISABLE打开逻辑口的上下行数据*/
    BspSetCpriCfgIqCloseSetFlag(1);
    BspLog(LOG_LEVEL_0,"**BspReleaseMainOptForceSet  mainPhyOptNo:%d **\n", mainPhyOptNo);

    return BSP_OK;
}

UINT32 BspSetSwCfgIqDelay(UINT8 cfgIqDly)
{
    UINT32 ulRet = BSP_OK;
    if(cfgIqDly >= 10 && cfgIqDly <= 60)
    {
        swCfgIqEnCnt = cfgIqDly;
        dbgInfo("%s swCfgIqEnCnt:%d cfgIqDly:%d * 0.1S\n",__FUNCTION__, swCfgIqEnCnt, cfgIqDly);
        BspLog(LOG_LEVEL_0,"%s swCfgIqEnCnt:%d cfgIqDly:%d * 0.1S\n",__FUNCTION__, swCfgIqEnCnt, cfgIqDly);
    }
    else if(cfgIqDly > 60 && cfgIqDly <= 255)
    {
        swCfgIqEnCnt = 60;
        dbgInfo("%s swCfgIqEnCnt:%d cfgIqDly:%d Delay 6S\n",__FUNCTION__, swCfgIqEnCnt, cfgIqDly);
        BspLog(LOG_LEVEL_0,"%s swCfgIqEnCnt:%d cfgIqDly:%d Delay 6S\n",__FUNCTION__, swCfgIqEnCnt, cfgIqDly);
    }
    else
    {
        swCfgIqEnCnt = 10;
        dbgInfo("%s swCfgIqEnCnt:%d cfgIqDly:%d Delay 1S\n",__FUNCTION__, swCfgIqEnCnt, cfgIqDly);
        BspLog(LOG_LEVEL_0,"%s swCfgIqEnCnt:%d cfgIqDly:%d Delay 1S\n",__FUNCTION__, swCfgIqEnCnt, cfgIqDly);
    }
    return ulRet;
}

UINT32 BspPrnSwCfgIqDelay()
{
    dbgInfo("%s swCfgIqEnCnt:%d CfgIqDelay:%d * 0.1S\n",__FUNCTION__, swCfgIqEnCnt, swCfgIqEnCnt+1);
    return BSP_OK;
}

UINT32 BspAdaptCpriCfgTxPriority(UINT32 phyOpt, UINT32 optWorkMode, UINT32 txPriority)
{
    const UINT32 loopCnt = 30;
    UINT32 index = 0;

    if (optWorkMode == BSP_OPT_WORK_MODE_NORMAL)
    {
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_2, txPriority&0xff, OPT_TX_PRIORITY_FORCE);
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_3, txPriority&0xff, OPT_TX_PRIORITY_FORCE);
        if(BBU_REDUNDANCY_MODE == BspGetDunDancyMode())
        {
            BspDelayOpenTxSwCfgIqThreadInit();
        }
        else
        {
            BspHalAdaptSwCfgIqCloseEn(0, DISABLE, TX);
            BspHalAdaptSwCfgIqCloseEn(1, DISABLE, TX);
            BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty SwCfgIqEn\n");
        }
        for(index = 0; index < loopCnt; index++)
        {
            BspSysMsDelay(100);         /*强发控制字3S， 取消自震荡后延时1s 避免来回切自震荡 乒乓*/
            BspCfgFrameDataByMainOpt();
            if(index == 15 && BSP_ERROR == BspGetOptTxPriorityStatus(phyOpt)) /* 1.5S检测控制字，防止BBU强倒未响应 */
            {
                BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty phyMainOpt[%d], 1.5S ulTxPriority err\n", phyOpt);
                break;
            }
        }
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_2, 0xff, OPT_TX_PRIORITY_AUTO);  /*去掉强发控制字*/
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_3, 0xff, OPT_TX_PRIORITY_AUTO);
    }
    else
    {
        if(optWorkMode == BSP_OPT_WORK_MODE_CASCADE)
        {
            BspHalAdaptCpriCfgTxPriority(LOG_OPT_2, txPriority&0xff, OPT_TX_PRIORITY_FORCE);
            BspHalAdaptCpriCfgTxPriority(LOG_OPT_3, txPriority&0xff, OPT_TX_PRIORITY_FORCE);
            BspSetOptBindRelation(phyOpt);
        }
        BspHalAdaptSwCfgIqCloseEn(0, DISABLE, TX);
        BspHalAdaptSwCfgIqCloseEn(1, DISABLE, TX);
        BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty SwCfgIqEn\n");
        for(index = 0; index < loopCnt; index++)
        {
            BspSysMsDelay(100);         /*强发控制字3S， 取消自震荡后延时1s 避免来回切自震荡 乒乓*/
            BspCfgFrameDataByMainOpt();
            if(index == 15 && BSP_ERROR == BspGetOptTxPriorityStatus(phyOpt)) /* 1.5S检测控制字，防止BBU强倒未响应 */
            {
                BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty phyMainOpt[%d], 1.5S ulTxPriority err\n", phyOpt);
                break;
            }
        }
    }

    return BSP_OK;
}

/*FDD光口配置双上联和光口自震荡 为主光口识别做准备*/
UINT32 BspSetFddOptFrAndProperty(UINT32 sw,UINT32 phyMainOpt)
{
    UINT32 ulRet = BSP_OK;
    UINT32 optWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);
    UINT32 ulTxPriority = 0;
    UINT32 ulTxPriority1 = 0;
    UINT32 currMainPhyOpt = 0;

    if((sw == SWITCH_ON) || (optWorkMode == BSP_OPT_WORK_MODE_MAIN_SLAVE))/*主备两个光口都是上联口，不需要自震荡*/
    {
        ulTxPriority = BspHalAdaptGetFddPriority(phyMainOpt);
        BspSysMsDelay(100);
        ulTxPriority1 = BspHalAdaptGetFddPriority(phyMainOpt);
        if(ulTxPriority != ulTxPriority1 || ulTxPriority == 0xff || ulTxPriority1 == 0xff)
        {
            return ulRet;
        }
        if(0 == ulMainOptChangeflag)
        {
            if(BSP_OK == BspJudgeMainOptStatus()) /*映射关系识别出来之后才能恢复*/
            {
                BspHalAdaptCpriSetSerdesCdcRxStableWind(0,0x10);
                BspHalAdaptCpriSetSerdesCdcRxStableWind(1,0x10);
                BspHalAdaptCpriSetFrTestMode(LOG_OPT0,DISABLE);
                BspHalAdaptCpriSetFrTestMode(LOG_OPT1,DISABLE);  /*去掉帧头自震荡*/
                BspHalAdaptCpriCfgOptProperty(phyMainOpt,0,1,0);
                ulRet = BspHalAdaptCpriCfgOptProperty(1-phyMainOpt,1,1,0);  //释放光口属性寄存器（0xc24031d8--0xc24031e4）
                BspSetOptBindRelation(phyMainOpt);

                BspSetOptCpriRelation(LOG_OPT0,phyMainOpt,1);
                BspSetOptCpriRelation(LOG_OPT2,1-phyMainOpt,1);
                BspSetOptCpriRelation(LOG_OPT1,0,0);

                /* 打开下联逻辑口的上下行数据 */
                IcHalApiCpriCfgIqCloseEn(0, DISABLE, RX);
                IcHalApiCpriCfgIqCloseEn(0, DISABLE, TX);
                BspHalAdaptRoeIqSetFlowEnOrDis(RX, 0, 0, ENABLE); /* 打开接收信令 */
                s_lastMainOpt = phyMainOpt;  /* 反向倒换记录主光口 */

                BspHalAdaptCfgSwSrcAlignFr(1); /*上行对齐帧头选择   传逻辑主光口+1*/
                BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty phyMainOpt[%d], ulTxPriority[%#x], workMode[%d], tick[%llu]\n", phyMainOpt, ulTxPriority, optWorkMode, tick64Get());

                BspHalAdaptGetMainPhyOpt(&currMainPhyOpt);
                if(phyMainOpt != currMainPhyOpt)
                {
                    BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty phyMainOpt[%d], currMainPhyOpt[%d]\n", phyMainOpt, currMainPhyOpt);
                    return ulRet;
                }
                ulMainOptChangeflag = 1;
                ulRet |= BspAdaptCpriCfgTxPriority(phyMainOpt, optWorkMode, ulTxPriority);
            }
        }
    }
    else if(sw == SWITCH_OFF)
    {
        if(1 == ulMainOptChangeflag)
        {
            BspLog(LOG_LEVEL_0,"**BspSetFddOptFrAndProperty from OptOK to double uplink**tick[%llu]\n", tick64Get()); /* 记录倒换开始时刻 */
        }
        ulMainOptChangeflag = 0;
        BspReverseSwitchover();  /* 强制3S反向倒换开启判断 */

        BspHalAdaptSwCfgIqCloseEn(0, ENABLE, TX);
        BspHalAdaptSwCfgIqCloseEn(1, ENABLE, TX);
        BspSetMainOptFrAndProperty(ulForceSetMainOpt);
        BspHalAdaptCpriSetSerdesCdcRxStableWind(0,0x4);
        BspHalAdaptCpriSetSerdesCdcRxStableWind(1,0x4);
    }

    return ulRet;
}

/* Started by AICoder, pid:514e5f3e25t7d72149280861407faf5a5c79ecd6 */
/**
 * @brief  判断光模块工作模式并设置反向倒换时间参数
 * 
 * 该函数根据主/从光模块速度及当前工作模式决定是否需要设置反向倒换时间参数。
 * 当检测到10.1376G速率时，将反向倒换时间设置为5000ms。
 * 
 * @param mainSpd   主光模块当前工作速率（单位：Mbps）
 * @param slaveSpd  从光模块当前工作速率（单位：Mbps）
 * 
 * @note   函数仅在以下条件满足时执行核心逻辑：
 *         1. 光模块处于正常工作模式
 *         2. 主/从模块速率均非零
 * 
 * @note   反向倒换时间参数(s_reverseTime)为全局变量，需确保线程安全
 */
VOID BspJudgeOptSpeed(UINT32 mainSpd, UINT32 slaveSpd)
{
    /* 静态变量用于保存上次检测到的状态值 */
    static UINT32 lastMainSpd = 0xff;
    static UINT32 lastSlaveSpd = 0xff;
    static UINT32 lastWorkMode = 0xff;

    /* 获取光模块当前工作模式 */
    UINT32 optWorkMode = BspGetOptWorkMode(0);

    /* 检测工作模式是否发生变更 */
    if (lastWorkMode != optWorkMode)
    {
        /* 工作模式变更时重置反向倒换时间为默认值 */
        s_reverseTime = 3000;

        /* 更新保存的工作模式状态 */
        lastWorkMode = optWorkMode;
    }

    /* 参数有效性检查或异常模式处理 */
    if ((mainSpd == 0) || (slaveSpd == 0) || (optWorkMode != BSP_OPT_WORK_MODE_NORMAL))
    {
        return;
    }

    /* 检测速率是否发生变更 */
    if ((lastMainSpd != mainSpd) || (lastSlaveSpd != slaveSpd))
    {
        /* 更新保存的速率值 */
        lastMainSpd = mainSpd;
        lastSlaveSpd = slaveSpd;

        /* 特殊速率处理：当检测到10.1376G速率时设置反向倒换时间 */
        if ((mainSpd == BSP_OPT_SPEED_10P1376G) || (slaveSpd == BSP_OPT_SPEED_10P1376G))
        {
            s_reverseTime = 5000;  // 设置5秒反向倒换时间
            BspLog(LOG_LEVEL_0, "[%s]set reverse time 5000\n", __FUNCTION__);
        }
        else
        {
            s_reverseTime = 3000;  // 默认反向倒换时间
        }
    }
}
/* Ended by AICoder, pid:514e5f3e25t7d72149280861407faf5a5c79ecd6 */

/*用于状态机跳转时的条件判断*/
UINT32 BspJudgeOptStaByOptWorkMode()
{
    UINT32 optWorkMode = 0;
    UINT32 retVal = BSP_OK;

    optWorkMode = BspGetOptWorkMode(0);
    if((optWorkMode != BSP_OPT_WORK_MODE_CASCADE)&&(optWorkMode != BSP_OPT_WORK_MODE_CASCADE_NORMAL)&&(optWorkMode != BSP_OPT_WORK_MODE_NORMAL)&&(optWorkMode != BSP_OPT_WORK_MODE_RING)&& (BSP_OPT_WORK_MODE_MAIN_SLAVE != optWorkMode)&&(optWorkMode != BSP_OPT_WORK_MODE_SHARE))
    {
        retVal = BSP_ERROR;
    }

    return retVal;
}

UINT32 BspSetOptControlAlarmClr(void)
{
    UINT32 retVal        = BSP_OK;
    UINT32 logicOptIndex = 0;

    for(logicOptIndex = 0; logicOptIndex < 4; logicOptIndex ++)
    {
        retVal |= BspOptManualSetLopAlarm(logicOptIndex,1,0);
        retVal |= BspOptManualSetLosAlarm(logicOptIndex,1,0);
        retVal |= BspOptManualSetLofAlarm(logicOptIndex,1,0);
    }

    return retVal;
}

UINT32 BspSetOptControlAlarmAuto(void)
{
    UINT32 retVal        = BSP_OK;
    UINT32 logicOptIndex = 0;

    for(logicOptIndex = 0; logicOptIndex < 4; logicOptIndex ++)
    {
        retVal |= BspOptManualSetLopAlarm(logicOptIndex,0,0);
        retVal |= BspOptManualSetLosAlarm(logicOptIndex,0,0);
        retVal |= BspOptManualSetLofAlarm(logicOptIndex,0,0);
    }

    return retVal;
}

static UINT32 setPhyFlag(UINT32 flag)
{
    g_ulSetPhyFlag = flag;

    return g_ulSetPhyFlag;
}
/* Started by AICoder, pid:711b4p36f3w8c8714e5f09c0c0aa3b25a0e7568c */
static UINT32 BspGetSerdesRateByOptSpeed(UINT32 optId)
{
    UINT32 optSpeed = BSP_OPT_SPEED_24P33024G;
    UINT32 optSerdesRate = SERDES_RATE_24G33;
    optSpeed = BspGetAaxOptSpeed(optId);
    switch(optSpeed)
    {
        case BSP_OPT_SPEED_6P1440G:
        {
            optSerdesRate = SERDES_RATE_6G14;
            break;
        }
        case BSP_OPT_SPEED_9P8304G:
        {
            optSerdesRate = SERDES_RATE_9G83;
            break;
        }
        case BSP_OPT_SPEED_10P1376G:
        {
            optSerdesRate = SERDES_RATE_10G13;
            break;
        }
        case BSP_OPT_SPEED_24P33024G:
        {
            optSerdesRate = SERDES_RATE_24G33;
            break;
        }
        default:
        {
            break;
        }
    }

    dbgInfo("%s:optSpeed[%d] = [%d], optSerdesRate[%d]\n", __FUNCTION__, optId, optSpeed, optSerdesRate);
    return optSerdesRate;
}

/*设置serdes内环/或serdes外环
 *optId：光口号
 *loopMode: 0 - serdes内环， 1 - serdes外环
 *返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspSetSerdesLoopTestMode(UINT32 optId, UINT32 loopMode)
{
    UINT32 ret = BSP_OK;
    UINT32 ulPhyOptNo = 0xff;
    UINT32 optSerdesRate = SERDES_RATE_24G33;
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};

    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/

    /*设置模式*/
    ret = IcHalApiSetSerdesLoopMode(ulPhyOptNo, loopMode, SWITCH_ON);
    if (BSP_ERROR == ret)
    {
        BspLog(LOG_LEVEL_0,"%s:set mode failed,optId[%d],ulPhyOptNo[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, loopMode, ret);
        return BSP_ERROR;
    }

    /*外环时初始化接收*/
    if (EXTERNEL_LOOP_BACK == loopMode)
    {
        ret = BspGetSerdesParaByPhyNo(ulPhyOptNo,&rateSerdesPara);
        if(ret != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s:BspGetSerdesParaByPhyNo failed\n");
            return BSP_ERROR;
        }
        optSerdesRate = BspGetSerdesRateByOptSpeed(optId);
        ret = BspHalChangeSerdesRxLaneRate(0,ulPhyOptNo, optSerdesRate, &rateSerdesPara);
        if(ret != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s:BspHalChangeSerdesRxLaneRate failed\n");
            return BSP_ERROR;
        }
    }

    BspSysMsDelay(2000);
    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, loopMode, ret);
    return ret;
}

/*获取serdes检测结果
 *optId：光口号
 *pResult：出参，校验结果，0-正常，其他-异常
 *返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspSerdesTestCheckResult(UINT32 optId, UINT32 *pResult)
{
    UINT32 ret = BSP_OK;
    UINT32 ulPhyOptNo = 0xff;
    UINT32 status = BSP_OK;

    INPUT_POINTER_CHECK(pResult);
    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/
    status = IcHalApiCheckLoopStatus(ulPhyOptNo);
    *pResult = status;
    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],*pResult[0x%x],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, *pResult, ret);
    return ret;
}

/*获取serdes内环或外环状态
 *optId：光口号
 *出参：2正常 0内环 1外环
 *返回值：BSP_OKBSP_ERROR
 */
UINT32 BspGetSerdesLoopTestMode(UINT32 optId, UINT32 *pResult)
{
    UINT32 ret = BSP_OK;
    UINT32 ulPhyOptNo = 0xff;
    UINT32 status = BSP_OK;

    INPUT_POINTER_CHECK(pResult);
    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/
    status = IcHalApiGetSerdesLoopMode(ulPhyOptNo);
    *pResult = status;

    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],*pResult[0x%x] [0:inner-loopback,1:outside-loopback,2:normal,-1:errsta],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, *pResult, ret);
    return ret;
}

/*解serdes内环环回/或解serdes外环环回
 *optId：光口号
 *返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspClrSerdesLoopTestMode(UINT32 optId)
{
    UINT32 ret = BSP_OK;
    UINT32 ulPhyOptNo = 0xff;
    UINT32 optSerdesStatus = 0;

    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/

    ret = BspGetSerdesLoopTestMode(optId, &optSerdesStatus);
    if (NOT_LOOP_BACK != optSerdesStatus)
    {
        ret |= IcHalApiSetSerdesLoopMode(ulPhyOptNo, optSerdesStatus, SWITCH_OFF);
        if (BSP_ERROR == ret)
        {
            BspLog(LOG_LEVEL_0,"%s:set mode failed,optId[%d],ulPhyOptNo[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, optSerdesStatus, ret);
            return BSP_ERROR;
        }
    }
    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],optSerdesStatus[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, optSerdesStatus, ret);

    return ret;
}


/*查看所有光口serdes是否处于环回状态，处于环回状态则解环回*/
UINT32 BspGetSerdesLoopStatusToInitClk(UINT32 *pResult)
{
    UINT32 optId = 0;
    UINT32 ret = BSP_OK;
    UINT32 optSerdesStatus[2] = {NOT_LOOP_BACK, NOT_LOOP_BACK};
    UINT32 ulPhyOptNo = 0xff;

    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/

    INPUT_POINTER_CHECK(pResult);
    *pResult = BSP_OK;/*默认不用加载时钟，出参返回BSP_OK*/
    for (optId = 0; optId < 2; optId++)
    {
        ret |= BspGetSerdesLoopTestMode(optId, &optSerdesStatus[optId]);
        if (NOT_LOOP_BACK != optSerdesStatus[optId])
        {
            ret |= IcHalApiSetSerdesLoopMode(ulPhyOptNo, optSerdesStatus[optId], SWITCH_OFF);/*处于环回状态，进行解环回*/
            *pResult = BSP_ERROR;
        }
    }
    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],optSerdesStatus0~1[%d,%d],*pResult[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, optSerdesStatus[0], optSerdesStatus[1], *pResult, ret);
    return ret;
}
/* Ended by AICoder, pid:711b4p36f3w8c8714e5f09c0c0aa3b25a0e7568c */
/*aax 光口定界需求相关接口*/
static VOID BspSaveAaxPrbsMode(E_LYCA_PRBS_MODE prbsMode)
{
    s_prbsMode = prbsMode;
}

static E_LYCA_PRBS_MODE BspGetAaxPrbsMode(VOID)
{
    return s_prbsMode;
}

static VOID BspClrAaxPrbsMode(VOID)
{
    BspSaveAaxPrbsMode(LYCA_PRBS9);
}

/*
 * 是否支持PRBS协议接口说明（RRU/AAU
 * prbsType：PRBS类型，31对应PRBS31，28对应PRBS28
 * 返回值：BSP_OK-支持，其他-不支持
 * */
UINT32 BspGetIsSupportPrbsType(UINT32 prbsType)
{
    if ((OPT_PRBS28 != prbsType) && (OPT_PRBS31 != prbsType))
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*
 * 测试准备接口说明（RRU/AAU）
 * 返回值：BSP_OK/BSP_ERROR
 */

UINT32 BspOptLoopTestPreProc(VOID)
{
    BspSaveAaxOptSpeed();
    optadptoff();/*停光口自适应*/
    BspSetOptRateAutoDisable();/*停环网倒换任务*/

    return BSP_OK;
}

/*
 * 测试结束接口说明（RRU/AAU）
 * 返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspOptLoopTestPostProc(VOID)
{
    optadpton();  /* 开启光口自适应 */
    BspSetOptRateAutoEnable();  /* 开启倒换任务 */
    BspClrAaxPrbsMode();/*整个流程跑完清存储的prbsMode*/
    dbgInfo("%s is enter\n", __FUNCTION__);
    BspLog(LOG_LEVEL_0, "%s> isenter \n", __FUNCTION__);

    return BSP_OK;
}

/*RRU 断链自环log记录*/
UINT32 BspGetOptLoopTestLog(UINT32 optId, UCHAR *pPara, UINT32 num)
{
    INPUT_POINTER_CHECK(pPara);

    if(num >=256)
    {
        return BSP_ERROR;
    }
    /*记录信息待逐步补充 */

    return BSP_OK;
}

/*PRBS控制接口（RRU）
 * optId: 光口号，从0开始
 * prbsType：PRBS类型，31对应PRBS31，28对应PRBS28
 * ctrl：1-开启，0-停止
 * 返回值：BSP_OK/BSP_ERROR
 */

UINT32 BspPrbsTestCtrl(UINT32 optId, UINT32 prbsType, UINT32 ctrl)
{
    UINT32 ret = BSP_ERROR;
    UINT32 ulPhyOptNo = 0xff;
    E_LYCA_PRBS_MODE prbsMode = LYCA_PRBS9;
    if (OPT_PRBS28 == prbsType)
    {
        prbsMode = LYCA_PRBS28;
    }
    else if (OPT_PRBS31 == prbsType)
    {
        prbsMode = LYCA_PRBS31;
    }
    else
    {
        BspLog(LOG_LEVEL_0,"%s: input prbs Type [%d] error\n", __FUNCTION__, prbsType);
        return BSP_ERROR;
    }
    
    BspSaveAaxPrbsMode(prbsMode);/*保存prbsMode*/
    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/
    ret = IcHalApiOptSendPrbs(ulPhyOptNo, prbsMode, ctrl);
    BspLog(LOG_LEVEL_0,"%s: prbsMode[%d] %s\n", __FUNCTION__, prbsMode, ctrl ? "on" : "off");

    return ret;
}

/*
 * PRBS误码清除接口（RRU）
 * optId: 光口号，从0开始
 * 返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspPrbsTestClrResult(UINT32 optId)
{
    UINT32 ret = BSP_ERROR;
    E_LYCA_PRBS_MODE prbsMode = LYCA_PRBS9;
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};
    UINT32 ulPhyOptNo = 0xff;
    UINT32 optSerdesRate = SERDES_RATE_24G33;
    
    prbsMode = BspGetAaxPrbsMode();

    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/
    /*接收初始化*/
    ret = BspGetSerdesParaByPhyNo(ulPhyOptNo,&rateSerdesPara);
    if(ret != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"BspGetSerdesParaByPhyNo failed\n");
        return BSP_ERROR;
    }
    optSerdesRate = BspGetSerdesRateByOptSpeed(optId);
    ret = BspHalChangeSerdesRxLaneRate(0,ulPhyOptNo, optSerdesRate, &rateSerdesPara);
    if(ret != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"BspHalChangeSerdesRxLaneRate failed\n");
        return BSP_ERROR;
    }

    /*清prbs误码，返回值不使用*/
    ret = IcHalApiOptRxPrbsResult(ulPhyOptNo, prbsMode, 1, 1);
    BspLog(LOG_LEVEL_0,"%s: ulPhyOptNo[%d] prbsMode[%d] ret0[%d] \n", __FUNCTION__, ulPhyOptNo, prbsMode, ret);

    return BSP_OK;
}

/*
 * PRBS校验结果接口（RRU）
 * optId: 光口号，从0开始
 * pResult：出参，校验结果，0-正常，其他-异常
 * 返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspPrbsTestCheckResult(UINT32 optId, UINT32 *pResult)
{
    UINT32 ret = BSP_ERROR;
    E_LYCA_PRBS_MODE prbsMode = LYCA_PRBS9;
    UINT32 ulPhyOptNo = 0xff;

    INPUT_POINTER_CHECK(pResult);
    prbsMode = BspGetAaxPrbsMode();
    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/

    /*查询prbs误码*/
    ret = IcHalApiOptRxPrbsResult(ulPhyOptNo, prbsMode, 1, 0);
    BspLog(LOG_LEVEL_0,"%s: ulPhyOptNo[%d] prbsMode[%d] ret0[%d] \n", __FUNCTION__, ulPhyOptNo, prbsMode, ret);
    if (BSP_ERROR == ret)
    {
        BspLog(LOG_LEVEL_0,"%s: IcHalApiOptRxPrbsResult failed \n", __FUNCTION__);
        return BSP_ERROR;
    }
    *pResult = ret;
    BspLog(LOG_LEVEL_0,"%s: prbsMode[%d] ,result[0x%x]\n", __FUNCTION__, prbsMode, *pResult);

    return BSP_OK;
}

/*
 * PRBS校验误码率结果接口（RRU）
 * optId: 光口号，从0开始
 * threShold:误码门限，0：0，1：1e-10
 * timeTicks：持续时间，单位：10ms
 * pResult：出参，校验结果，0-正常，1-异常
 * 返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspPrbsTestCheckBerResult(UINT32 optId,UINT32 threShold,UINT32 timeTicks, UINT32 *pResult)
{
    UINT32 ret = BSP_ERROR;
    E_LYCA_PRBS_MODE prbsMode = LYCA_PRBS9;
    UINT32 ulPhyOptNo = 0xff;
    UINT32 berThreshold = 0;
    UINT32 berNum = 0;/*误码数*/
    UINT32 optSpeed = BSP_OPT_SPEED_24P33024G;

    INPUT_POINTER_CHECK(pResult);
    if (0 == timeTicks)
    {
        BspLog(LOG_LEVEL_0,"%s: timeTicks[%d] Error \n", __FUNCTION__, timeTicks);
        return BSP_ERROR;
    }
    prbsMode = BspGetAaxPrbsMode();
    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/

    /*查询prbs误码*/
    ret = IcHalApiOptRxPrbsResult(ulPhyOptNo, prbsMode, 1, 0);
    BspLog(LOG_LEVEL_0,"%s: ulPhyOptNo[%d] prbsMode[%d] ret0[%d] \n", __FUNCTION__, ulPhyOptNo, prbsMode, ret);
    if (BSP_ERROR == ret)
    {
        BspLog(LOG_LEVEL_0,"%s: IcHalApiOptRxPrbsResult failed \n", __FUNCTION__);
        return BSP_ERROR;
    }
    berNum = ret;
    
    optSpeed = BspGetAaxOptSpeed(optId);
    berThreshold = BspGetOptBerthresholdByBbu(threShold, timeTicks, optSpeed);
    if (berNum > berThreshold)
    {
        *pResult = 1;/*误码率超限*/
    }
    else
    {
        *pResult = 0;/*误码率未超限*/
    }
    BspLog(LOG_LEVEL_0,"%s:berNum[%d],berThreshold[%d],*pResult[%d]\n", __FUNCTION__, berNum, berThreshold,*pResult);
    return BSP_OK;
}

/*设置aax serdes环回时创建文件*/
const char aaxSerdesFileName[36] = "/ata/.aaxOptSerdesFile";
static UINT32 BspCreateAaxFile(VOID)
{
    FILE *fp = NULL;
    INT32 retVal;

    fp = fopen(aaxSerdesFileName, "w+b");
    if (fp == NULL)
    {
        BspLog(LOG_LEVEL_0,"%s: create %s failed\n", __FUNCTION__, aaxSerdesFileName);
        return BSP_ERROR;
    }
    retVal = fclose(fp);
    if (0 != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s: close %s failed\n", __FUNCTION__, aaxSerdesFileName);
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*查询aax serdes文件，有文件的话加载时钟*/
UINT32 BspChkAaxSerdesFile()
{
    INT32 retVal;
    UINT32 ret = BSP_OK;

    retVal = access(aaxSerdesFileName, F_OK);
    if (0 != retVal)/*文件不存在*/
    {
        ret = BSP_ERROR;
    }

    BspLog(LOG_LEVEL_0,"%s: file[%s] %s ,ret[%d]\n", __FUNCTION__, aaxSerdesFileName, (retVal == 0) ? "exists" : "not exists" ,ret);
    return ret;
}
/*
 * 删除aax serdes文件*/
UINT32 BspDeleteAaxFile()
{
    INT32 retVal;
    UINT32 ret = BSP_OK;

    retVal = unlink(aaxSerdesFileName);
    if (retVal != 0)
    {
        ret = BSP_ERROR;
    }
    BspLog(LOG_LEVEL_0,"%s: unlink %s %s,ret[%d]\n", __FUNCTION__, aaxSerdesFileName, (retVal == 0) ? "success" : "failed", ret);
    return ret;
}
/*设置serdes内环/或serdes外环
 *optId：光口号
 *loopMode: 0 - serdes内环， 1 - serdes外环
 *返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspSetAaxSerdesLoopTestMode(UINT32 optId, UINT32 loopMode)
{
    UINT32 ret = BSP_OK;
    UINT32 ulPhyOptNo = 0xff;
#ifndef MULT_PROGRESS_S
    UINT32 optSerdesRate = SERDES_RATE_24G33;
    UINT32 loop = 0;
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};

    BspLog(LOG_LEVEL_0,"%s:enter,optId[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, loopMode, ret);

    if (QSFP_FOR_ETH == BspIsSpecialQsfp(optId))/*电模块设置模式直接报错*/
    {
        BspLog(LOG_LEVEL_0,"%s:set sfp_eth mode failed,optId[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, loopMode, ret);
        return BSP_ERROR;
    }

    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/
    /*创建aax文件*/
    ret = BspCreateAaxFile();
    if (BSP_ERROR == ret)
    {
        BspLog(LOG_LEVEL_0,"%s:BspCreateAaxFile failed,optId[%d],ulPhyOptNo[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, loopMode, ret);
        return BSP_ERROR;
    }

    /*设置模式*/
    ret = IcHalApiSetSerdesLoopMode(ulPhyOptNo, loopMode, SWITCH_ON);
    if (BSP_ERROR == ret)
    {
        BspLog(LOG_LEVEL_0,"%s:set mode failed,optId[%d],ulPhyOptNo[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, loopMode, ret);
        return BSP_ERROR;
    }

    /*外环时初始化接收*/
    if (EXTERNEL_LOOP_BACK == loopMode)
    {
        ret = BspGetSerdesParaByPhyNo(ulPhyOptNo,&rateSerdesPara);
        if(ret != BSP_OK)
        {
            BspLog(LOG_LEVEL_0,"%s:BspGetSerdesParaByPhyNo failed\n", __FUNCTION__);
            return BSP_ERROR;
        }
        optSerdesRate = BspGetSerdesRateByOptSpeed(optId);
        for(loop = 0; loop < OPT_RATE_TYPE; loop++)
        {
           if(rateSerdesPara.txRatePara[loop].rate == optSerdesRate)
           {
               BspLog(LOG_LEVEL_0,"%s:txRateParaRate[%d] = %d\n", __FUNCTION__, loop, optSerdesRate);
               break;
           }
        }
        if (OPT_RATE_TYPE == loop)
        {
            BspLog(LOG_LEVEL_0,"%s:get txRateParaRate failed\n", __FUNCTION__);
            return BSP_ERROR;
        }
        BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],vag[%d],ucmCtrl[%d] \n", __FUNCTION__, optId, rateSerdesPara.rxRatePara[loop].uVga, rateSerdesPara.rxRatePara[loop].uCmtermCtrl);
        BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],min[%d],max[%d] \n", __FUNCTION__, optId, rateSerdesPara.rxRatePara[loop].phaseMin, rateSerdesPara.rxRatePara[loop].phaseMax);
        ret |= IcHalApiLycaInitRx(0, ulPhyOptNo, &rateSerdesPara.rxRatePara[loop]);
    }
#endif
    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],loopMode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, loopMode, ret);
    return ret;
}


/*解serdes内环环回/或解serdes外环环回
 *optId：光口号
 *返回值：BSP_OK/BSP_ERROR
 */
UINT32 BspClrAaxSerdesLoopTestMode(UINT32 optId)
{
    UINT32 ret = BSP_OK;
#ifndef MULT_PROGRESS_S
    UINT32 ulPhyOptNo = 0xff;

    if (QSFP_FOR_ETH == BspIsSpecialQsfp(optId))/*电模块设置模式直接报错*/
    {
        BspLog(LOG_LEVEL_0,"%s:clr sfp_eth mode failed,optId[%d],ret[%d] \n", __FUNCTION__, optId, ret);
        return BSP_ERROR;
    }

    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/
    ret = IcHalApiSetSerdesLoopMode(ulPhyOptNo, INTERNEL_LOOP_BACK, SWITCH_OFF);
    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],mode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, INTERNEL_LOOP_BACK, ret);
    ret |= IcHalApiSetSerdesLoopMode(ulPhyOptNo, EXTERNEL_LOOP_BACK, SWITCH_OFF);
    BspLog(LOG_LEVEL_0,"%s:exit,optId[%d],ulPhyOptNo[%d],mode[%d],ret[%d] \n", __FUNCTION__, optId, ulPhyOptNo, EXTERNEL_LOOP_BACK, ret);
#endif

    return ret;
}

/*判断CDR状态*/
UINT32 BspGetCdrLockStatus(UINT32 optId)
{
    UINT32 ret = BSP_OK;
    UINT32 ulPhyOptNo = 0xff;

#ifndef MULT_PROGRESS_S
    if (QSFP_FOR_ETH == BspIsSpecialQsfp(optId))/*电模块设置模式直接报错*/
    {
        BspLog(LOG_LEVEL_0,"%s:clr sfp_eth mode failed,optId[%d],ret[%d] \n", __FUNCTION__, optId, ret);
        return BSP_ERROR;
    }
#endif
    ulPhyOptNo = BspGetPhyNoBySfpNo(optId);   /*光笼编号转换到物理光口号*/
    ret = BspHalAdaptLycaGetCdrStatus(0, ulPhyOptNo);

    if (1 == ret)/*锁定*/
    {
        BspLog(LOG_LEVEL_0,"%s:[%d],GetCdrStatus lock, ret[%d] \n", __FUNCTION__, optId, ret);
        return BSP_OK;
    }

    BspLog(LOG_LEVEL_0,"%s:optId[%d],GetCdrStatus failed or not lock, ret[%d] \n", __FUNCTION__, optId, ret);
    return BSP_ERROR;
}

UINT32 BspIsSupportAaxTestMode(UINT32 testType)
{
    UINT32 retVal = BSP_ERROR;

    switch(testType)
    {
        case AAXINTERLOOPBACK:
        case AAXOUTERLOOPBACK:
        case AAXPRBSLOOPBACK:
        case AAX_INTER_SERDES_LOOPBACK:
            retVal = BSP_OK;
            break;
        default:
            dbgErr("[%s]no suppurt! testType = %d\n", __FUNCTION__, testType);
            retVal = BSP_ERROR;
            break;
    }

    return retVal;
}

/* Started by AICoder, pid:n01a25795da690514d980a8d9002be3f92d3feab */
UINT32 BspSetAaxLoopTestMode(UINT32 optNo, UINT32 testType)
{
    UINT32 ret = BSP_OK;
    BspLog(LOG_LEVEL_0,"%s:enter,optNo[%d],testType[%d]\n", __FUNCTION__, optNo, testType);
    
#ifndef MULT_PROGRESS_S
    switch (testType) {
        case AAXINTERLOOPBACK:
            ret = BspSetOptLoopTestMode(optNo, INTERNEL_LOOP_BACK);
            break;
        case AAXOUTERLOOPBACK:
            ret = BspSetOptLoopTestMode(optNo, EXTERNEL_LOOP_BACK);
            break;
        case AAX_OUTER_SERDES_LOOPBACK:
            ret = BspSetAaxSerdesLoopTestMode(optNo, EXTERNEL_LOOP_BACK);
            break;
        case AAX_INTER_SERDES_LOOPBACK:
            ret = BspSetAaxSerdesLoopTestMode(optNo, INTERNEL_LOOP_BACK);
            break;
        case AAXPRBSLOOPBACK:
            BspLog(LOG_LEVEL_0,"%s:testType[%d] do nothing\n", __FUNCTION__, testType);
            break;
        default:
            ret = BSP_ERROR;
            BspLog(LOG_LEVEL_0,"%s:testType[%d] not found,ret[%d]\n", __FUNCTION__, testType, ret);
            break;
    }
#endif
    
    BspLog(LOG_LEVEL_0,"%s:exit,optNo[%d],testType[%d],ret[%d]\n", __FUNCTION__, optNo, testType, ret);
    
    return ret;
}
/* Ended by AICoder, pid:n01a25795da690514d980a8d9002be3f92d3feab */

/* Started by AICoder, pid:g951dqb419q0fb714b7c0a5bd0c11521a5a7f54c */
UINT32 BspClrAaxLoopTestMode(UINT32 optNo, UINT32 testType)
{
    UINT32 ret = BSP_OK;
    BspLog(LOG_LEVEL_0,"%s:enter,optNo[%d],testType[%d]\n", __FUNCTION__, optNo, testType);
    
    switch (testType) {
        case AAXINTERLOOPBACK:
        case AAXOUTERLOOPBACK:
            ret = BspClrOptLoopTestMode(optNo);
            break;
        case AAX_INTER_SERDES_LOOPBACK:
        case AAX_OUTER_SERDES_LOOPBACK:
            ret = BspClrAaxSerdesLoopTestMode(optNo);
            break;
        case AAXPRBSLOOPBACK:
            BspLog(LOG_LEVEL_0,"%s:testType[%d] do nothing\n", __FUNCTION__, testType);
            break;
        default:
            ret = BSP_ERROR;
            BspLog(LOG_LEVEL_0,"%s:testType[%d] not found,ret[%d]\n", __FUNCTION__, testType, ret);
            break;
    }
    
    BspLog(LOG_LEVEL_0,"%s:exit,optNo[%d],testType[%d],ret[%d]\n", __FUNCTION__, optNo, testType, ret);

    return ret;
}
/* Ended by AICoder, pid:g951dqb419q0fb714b7c0a5bd0c11521a5a7f54c */

/*AAX环回结果查询*/
/* Started by AICoder, pid:w6d70uc1efxe2b6148730beda035dc233108163b */
UINT32 BspAaxTestCheckBerResult(UINT32 optNo, UINT32 testType, UINT32 thre, UINT32 timeTicks, UINT32 *pResult)
{
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pResult);
    BspLog(LOG_LEVEL_0,"%s:enter,optNo[%d],testType[%d],thre[%d],timeTicks[%d]\n", __FUNCTION__, optNo, testType, thre, timeTicks);
    
    switch (testType) {
        case AAXINTERLOOPBACK:
        case AAXPRBSLOOPBACK:
            ret = BspPrbsTestCheckBerResult(optNo, thre, timeTicks, pResult);
            break;
        case AAX_INTER_SERDES_LOOPBACK:
            ret = BspSerdesTestCheckResult(optNo, pResult);
            break;
        case AAXOUTERLOOPBACK:
        case AAX_OUTER_SERDES_LOOPBACK:
            BspLog(LOG_LEVEL_0,"%s:testType[%d] do nothing\n", __FUNCTION__, testType);
            break;
        default:
            ret = BSP_ERROR;
            BspLog(LOG_LEVEL_0,"%s:testType[%d] not found,ret[%d]\n", __FUNCTION__, testType, ret);
            break;
    }
    
    BspLog(LOG_LEVEL_0,"%s:exit,optNo[%d],testType[%d],ret[%d]\n", __FUNCTION__, optNo, testType, ret);
    
    return ret;
}
/* Ended by AICoder, pid:w6d70uc1efxe2b6148730beda035dc233108163b */

UINT32 BspSetOptControlAlarmByOptAlarm(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulOptNum = 0;
    UINT32 ulLogicOptIndex = 0;
    UINT32 ulPhyOptIndex = 0;
    UINT32 ulLopAlarm = 0;
    UINT32 ulLosAlarm = 0;
    UINT32 ulLofAlarm = 0;
    UINT32 times = 10;
    UINT32 timesIndex = 0;
    UINT32 cnt = 0;

    ulOptNum = BspGetOptNum();
    if(ulOptNum > OPTMAXNUM)
    {
        ulOptNum = OPTMAXNUM;
    }

    for(ulPhyOptIndex = 0; ulPhyOptIndex < ulOptNum; ulPhyOptIndex++)
    {
        if(ulPhyOptIndex == g_ulSetPhyFlag)
        {
            continue;
        }
        ulLogicOptIndex = BspGetLogicPort(ulPhyOptIndex);
        if(ulLogicOptIndex  > 3)
        {
            dbgErr("[%s]: ulLogicOptIndex[%d]. \n", __FUNCTION__, ulLogicOptIndex);
            continue;
        }
        cnt = BspHalAdaptGetCpriFsmJumpCnt(ulPhyOptIndex);
        dbgInfoEx("%s: cnt[%d]. \n", __FUNCTION__, cnt);
        retVal |= BspGetOptPhyStatus(ulPhyOptIndex, &ulLopAlarm, &ulLosAlarm, &ulLofAlarm);
        for(timesIndex = 0; timesIndex < times; timesIndex ++)
        {
            /* Started by AICoder, pid:p1724r1c678e4f6147700b5110c66c19bd219f02 */
            if((ulLopAlarm == 1) || (ulLosAlarm == 1) || (ulLofAlarm == 1))
            {
                BspHalAdaptCpriSetFrByLoadShare(ulLogicOptIndex, ENABLE);
                BspHalCpriSwAlignFrSel(ulLogicOptIndex, 0, 0);
                BspSysMsDelay(20);
            }
            else
            {
                BspHalAdaptCpriSetFrByLoadShare(ulLogicOptIndex, DISABLE);
                BspHalCpriSwAlignFrSel(ulLogicOptIndex, 1, 0);
                continue;
            }
            /* Ended by AICoder, pid:p1724r1c678e4f6147700b5110c66c19bd219f02 */
            retVal |= BspGetOptPhyStatus(ulPhyOptIndex, &ulLopAlarm, &ulLosAlarm, &ulLofAlarm);
        }

        retVal |= BspOptManualSetLopAlarm(ulLogicOptIndex,1,ulLopAlarm);
        retVal |= BspOptManualSetLosAlarm(ulLogicOptIndex,1,ulLosAlarm);
        retVal |= BspOptManualSetLofAlarm(ulLogicOptIndex,1,ulLofAlarm);

        dbgInfoEx("[%s]:ulPhyOptIndex[%d], ulLogicOptIndex[%d], ulLopAlarm[%d], ulLosAlarm[%d], ulLofAlarm[%d], cnt[%d]. \n",
                    __FUNCTION__, ulPhyOptIndex, ulLogicOptIndex, ulLopAlarm, ulLosAlarm, ulLofAlarm, cnt);
    }

    return retVal;
}

UINT32 BspSetOptControlAlarm(UINT32 preState, UINT32 nextState)
{
    UINT32 retVal = BSP_OK;

    if((preState == OPT_ADPT_STATE_OK) && (nextState == OPT_ADPT_STATE_OK))
    {
        retVal |= BspSetOptControlAlarmByOptAlarm();
    }
    else if((preState != OPT_ADPT_STATE_OK) && (nextState == OPT_ADPT_STATE_OK))
    {
        retVal |= BspSetOptControlAlarmClr();
    }
    else if((preState == OPT_ADPT_STATE_OK) && (nextState != OPT_ADPT_STATE_OK))
    {
        retVal |= BspSetOptControlAlarmClr();
    }

    return retVal;
}

UINT32 BspGetOptTxPriorityStatus(UINT32 phyNo)
{
   UINT32 regVal = 0;
   UINT32 procotol = 0;

    procotol = BspGetOptCpriProtocol(0);
    if(procotol != PROCOTOL_CPRI)
    {
        return BSP_OK;   /*只有cpri 才使用此控制字进行判断*/
    }
    regVal = BspHalAdaptGetFddPriority(phyNo);
    if((regVal != 0x38)&&(regVal != 0xc7)&&(regVal != 0x83)&&(regVal != 0x7c))  /*这些寄存器自带含义 直接表示是否合法更直观 不再单独定义宏*/
    {
        return BSP_ERROR;
    }
    else
    {
       return BSP_OK;
    }
}
/*当前是否处于 TDD或者FDD 环网组网*/
UINT32 BspIsRingOptWorkMode(VOID)
{
    UINT32 optWorkMode = 0;
    UINT32 retVal = BSP_OK;

    optWorkMode = BspGetDefaultOptWorkMode(0);
    if((optWorkMode != BSP_OPT_WORK_MODE_NORMAL)&&(optWorkMode != BSP_OPT_WORK_MODE_RING))
    {
        retVal = BSP_ERROR;
    }

    return retVal;
}

/*解决3.0+4.2 异速率建链断链问题，增加主光口异常配置双上联自震荡，主光口正常时去掉自震荡*/
UINT32 BspSetOptCpriFrTestMode(UINT32 cfgEn)
{
    UINT32 cfgFlag = 0;

    cfgFlag = BspGetOptFrTestModeEn();
    if(OPT_FR_TESTMODE_ON != cfgFlag)
    {
         return BSP_OK;
    }
    if(ENABLE == cfgEn)
    {
        BspHalAdaptCpriSetFrTestMode(LOG_OPT0,ENABLE);
        BspHalAdaptCpriSetFrTestMode(LOG_OPT1,ENABLE);
    }
    else
    {
        BspHalAdaptCpriSetFrTestMode(LOG_OPT0,DISABLE);
        BspHalAdaptCpriSetFrTestMode(LOG_OPT1,DISABLE);
    }

    return BSP_OK;
}

UINT32 BspSetOptCpriFrLoopMode(UINT32 cfgEn)
{
    UINT32 enFlag =0;

    dbgInfoEx("%s %d\n", __func__, cfgEn);
    enFlag =  BspGetOptInnerCpriFrModeEn();
    if(OPT_INNER_CPRI_FR_LOOP_MODE_OFF == enFlag)  /*只有4T 700M 900M有混连*/
    {
         dbgInfoEx("BspSetOptCpriFrLoopMode not need\n");
          return BSP_OK;
    }

    if(ENABLE == cfgEn)
    {
        dbgInfoEx("doule opt loop enable\n");
        BspHalAdaptCpriInternalLoopback(LOG_OPT0,ENABLE);
        BspHalAdaptCpriInternalLoopback(LOG_OPT1,ENABLE);
    }
    else
    {
        dbgInfoEx("doule opt loop disbale\n");
        BspHalAdaptCpriInternalLoopback(LOG_OPT0,DISABLE);
        BspHalAdaptCpriInternalLoopback(LOG_OPT1,DISABLE);
    }

    return BSP_OK;
}


/*判断当前光笼号获取的RRUID是否合法*/
UINT32 BspCheckRruIdVaild(UINT32 ulIndex) 
{ 
     if((0 == BspGetRruId(ulIndex))||(254 == BspGetRruId(ulIndex))||(255 == BspGetRruId(ulIndex)))   /*0 254 255 为非法值*/
     { 
         return BSP_ERROR; 
     } 
     else 
     { 
          return BSP_OK; 
     } 
} 

/*预留 单板差异化处理记录信息*/
VOID BspInitShowIqInfoToBbxCallBack(BSP_BBX_IQINFO_CALLBACK_FUNCPTR pFuncCallback)
{
    pBspShowIqInfoCallBack=pFuncCallback;
}


/*光口状态记录*/
UINT32 BspIqShowInfo_Test(char *strIqInfo, UINT32 length)
{
    INPUT_POINTER_CHECK(strIqInfo);
#ifndef MULT_PROGRESS_S	
    char *pTmp = NULL;
    UINT32  aulData[16] = {0};
    UINT32   ulLen  = 0;
    T_RruSfpInfo* ptOptDiag = NULL;
    T_NetPacketInfo* ptNetPack = NULL;
    UCHAR  acString[20] = {0};
    INT32  ulLoop = 0;
    INT32 logNo = 0;

    ptOptDiag = (T_RruSfpInfo*)malloc(sizeof(T_RruSfpInfo));
    INPUT_POINTER_CHECK(ptOptDiag);

    ptNetPack = (T_NetPacketInfo*)malloc(sizeof(T_NetPacketInfo));
    if (NULL == ptNetPack)
    {
        free(ptOptDiag);
        return BSP_ERROR;
    }
    pTmp =(char*)malloc(SCHAR_MAX);
    if (NULL == pTmp)
    {
        free(ptOptDiag);
        free(ptNetPack);
        return BSP_ERROR;
    }
    memset(ptNetPack,0,sizeof(T_NetPacketInfo));
    memset(strIqInfo,0,length);
    memset(pTmp,0,SCHAR_MAX);

    ulLen += sprintf_s(pTmp,SCHAR_MAX,"No0:-- No1:-- No2:--\n");
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
    strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    aulData[0] = BspGetDefaultOptWorkMode(0);  /*组网模式*/
    aulData[1] = BspGetCurrFiberPort();  /*主光口对应的光笼号*/
    aulData[2] = BspGetOptSpeed(0) & 0xFF;  /*光口线速率*/
    aulData[3] = BspGetOptSpeed(1) & 0xFF;
    aulData[4] = BspGetSfpMaximalUsedbleSpeed(0) &(UINT32)0xFF;
    aulData[5] = BspGetSfpMaximalUsedbleSpeed(1) &(UINT32)0xFF;
    aulData[6] = BspGetMainPhyOpt(); /* 获取主光口号 */
    ulLen += sprintf_s(pTmp,SCHAR_MAX,"OptWorkMode:0x%x CurrFiberPort:0x%x OptRate0:0x%x OptRate1:0x%x OptMaxRate0:0x%x OptMaxRate1:0x%x PhyMainPort:%#x\n",
        aulData[0], aulData[1], aulData[2], aulData[3],aulData[4], aulData[5], aulData[6]);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
    strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    aulData[0] = BspGetOptCpriProtocol(0);
	ulLen += sprintf_s(pTmp,SCHAR_MAX,"Protocol:%d(0:Cpri,1:IR) OptMap:-- \n", aulData[0] /*, aulData[1]*/);
	if(ulLen>=(length-(UINT32)1))
	{
		free(pTmp);
		free(ptOptDiag);
		free(ptNetPack);
		return BSP_ERROR;
	}
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

	aulData[0] = BspCheckSysPllState();
	ulLen += sprintf_s(pTmp,SCHAR_MAX, "Clk0:%d Clk1:- Clk2:- Clk3:- Clk4:- Clk5:- Clk6:- Clk7:- Clk8:- Clk9:-\n",aulData[0]);//时钟如何添加
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    //Opt0
    aulData[0] = BspGetOptStatus(0);
    memset(ptOptDiag,0,sizeof(T_RruSfpInfo));
    BspGetSfpInfo(0, ptOptDiag);
    //添加光模块条码
    memcpy_s(acString, 16, ptOptDiag->acVendorSN, 16);
    for(ulLoop=(INT32)15;ulLoop>=(INT32)0;ulLoop--)
    {
      if(acString[ulLoop]!=(UCHAR)(' '))
      {
    	  acString[ulLoop+(INT32)1]=(UCHAR)('\0');
          break;
      }
    }
    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:0 Status:0x%x SendPwr:%d RevPwr:%d Speed:%dMbps TxBias:%dmA\n",
        aulData[0], ptOptDiag->tSfpDigiDiagInfo.ulTxPower/((UINT32)10), ptOptDiag->tSfpDigiDiagInfo.ulRxPower/((UINT32)10),
        ptOptDiag->ucSignalingRate*(UCHAR)100, ptOptDiag->tSfpDigiDiagInfo.ulTxBiasCurrent/(UINT32)500);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
    strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    ulLen += sprintf_s(pTmp,SCHAR_MAX,"Opt:0 Temp:%d RemoteKm:%dkm VendorSN:%s Volt:%d*100uV\n",
        ptOptDiag->tSfpDigiDiagInfo.lTransceiverTemp/((UINT32)256), ptOptDiag->uc9umKmLinkLength,acString,ptOptDiag->tSfpDigiDiagInfo.ulVoltage);

    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
    strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    BspHalAdaptPcsGetLinkPcsSta(0,&aulData[0]); /*PCS*/
    aulData[1] = 0;  /*CDR*/
    aulData[2] = 0;  /*眼高*/
    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:0 pcs:0x%x cdr:0x%x nrz: %d--\n",aulData[0], aulData[1],aulData[2]);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    aulData[0] = BspHalAdaptGetOptSyncStatus(0); //物理光口状态机 209c
    logNo = BspHalAdaptGetLogOpt(0);
    if(logNo == -1)
    {
    	aulData[1] = -1;
    	aulData[5] = -1;
    }
    else
    {
        aulData[1] = _BspCheckLogicOptState(logNo);//逻辑光口告警上报
        BspHalAdaptDpdicRegRd(0,0xc2408014,logNo*4,&aulData[5]);//IQ组网告警掩码
    }
    aulData[2] = BspHalAdaptGetOptLosStatus(0);//LOS统计寄存器
    aulData[3] = BspHalAdaptGetOptLopStatus(0);//LOP统计寄存器
    aulData[4] = BspHalAdaptGetOptLofStatus(0);//LOF统计寄存器
    aulData[5] = 0; //DpdIcHalAddrRegRd(0,0x8ff08100,0,&aulData[5]);//IQ组网告警掩码

    ulLen += sprintf_s(pTmp,SCHAR_MAX,"Opt:0 PhyOptStatus:0x%x LogOptAlm:0x%x LosAlmCnt:0x%x\n",
    aulData[0],aulData[1],aulData[2]);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

     ulLen += sprintf_s(pTmp,SCHAR_MAX,"Opt:0 LopAlmCnt:0x%x LofAlmCnt:0x%x IQNetAlmMask:0x%x\n",
        aulData[3],aulData[4],aulData[5]);
     INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    aulData[0] = BspGetRruId(0);
    /* 加优先级控制字 */
    aulData[1] = BspHalAdaptGetFddPriority(0);
    aulData[2] = BspHalAdaptGetFddPriority(1);
    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:0 RruId:0x%x RruIndex:-- Priority:%#x %#x -- RX_startup:-- TX_startup:--\n",
		aulData[0]&(UINT32)0xff, aulData[1], aulData[2]);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:0 OptLofAlmCnt:-- LinkLofAlmCnt:-- OptErr:-- OptKErrCnt:--\n");
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:0 OptPaFrameCnt:-- OptPaAlamCnt:--\n");
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    //Opt1
    aulData[0] = BspGetOptStatus(1);
    memset(ptOptDiag,0,sizeof(T_RruSfpInfo));
    BspGetSfpInfo(1, ptOptDiag);
    //添加光模块条码
    memcpy_s(acString, 16, ptOptDiag->acVendorSN, 16);
    for(ulLoop=(INT32)15;ulLoop>= (INT32)0;ulLoop--)
    {
      if(acString[ulLoop]!=(UCHAR)' ')
      {
    	  acString[ulLoop+(INT32)1]=(UCHAR)'\0';
          break;
      }
    }
    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:1 Status:0x%x SendPwr:%d RevPwr:%d Speed:%dMbps TxBias:%dmA\n",
        aulData[0], ptOptDiag->tSfpDigiDiagInfo.ulTxPower/((UINT32)10), ptOptDiag->tSfpDigiDiagInfo.ulRxPower/((UINT32)10),
        ptOptDiag->ucSignalingRate*(UCHAR)100, ptOptDiag->tSfpDigiDiagInfo.ulTxBiasCurrent/(UINT32)500);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
    strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    ulLen += sprintf_s(pTmp,SCHAR_MAX,"Opt:1 Temp:%d RemoteKm:%dkm VendorSN:%s Volt:%d*100uV\n",
        ptOptDiag->tSfpDigiDiagInfo.lTransceiverTemp/((UINT32)256), ptOptDiag->uc9umKmLinkLength,acString,ptOptDiag->tSfpDigiDiagInfo.ulVoltage);
   /* SNPRINTF_S_CHECK(snprntfs_ret, sizeof(pTmp));
    ulLen += (ULONG)snprntfs_ret;*/
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
    strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    BspHalAdaptPcsGetLinkPcsSta(1,&aulData[0]); /*PCS*/
    aulData[1] = 0;  /*CDR*/
    aulData[2] = 0;  /*眼高*/
    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:1 pcs:0x%x cdr:0x%x nrz: %d--\n",aulData[0], aulData[1],aulData[2]);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    //IcHalRdReg(0,0x8ff020b0,0,&aulData[0]);//物理光口状态机
    aulData[0] = BspHalAdaptGetOptSyncStatus(1); //物理光口状态机 209c
    logNo = BspHalAdaptGetLogOpt(1);
    if(logNo == -1)
    {
    	aulData[1] = -1;
    	aulData[5] = -1;
    }
    else
    {
    aulData[1] = _BspCheckLogicOptState(logNo);//逻辑光口告警上报
    BspHalAdaptDpdicRegRd(0,0xc2408014,logNo*4,&aulData[5]);//IQ组网告警掩码
    }
    aulData[2] = BspHalAdaptGetOptLosStatus(1);//LOS统计寄存器
    aulData[3] = BspHalAdaptGetOptLopStatus(1);//LOP统计寄存器
    aulData[4] = BspHalAdaptGetOptLofStatus(1);//LOF统计寄存器


    ulLen += sprintf_s(pTmp,SCHAR_MAX,"Opt:1 PhyOptStatus:0x%x LogOptAlm:0x%x LosAlmCnt:0x%x\n",
    aulData[0],aulData[1],aulData[2]);

    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

     ulLen += sprintf_s(pTmp,SCHAR_MAX,"Opt:1 LopAlmCnt:0x%x LofAlmCnt:0x%x IQNetAlmMask:0x%x\n",
        aulData[3],aulData[4],aulData[5]);
    if(ulLen>=(length-(UINT32)1))
	{
		free(pTmp);
		free(ptOptDiag);
		free(ptNetPack);
		return BSP_ERROR;
	}
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    aulData[0] = BspGetRruId(1);
    /* 优先级控制字 */
    aulData[1] = BspHalAdaptGetFddPriority(0);
    aulData[2] = BspHalAdaptGetFddPriority(1);
    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:1 RruId:0x%x RruIndex:-- Priority:%#x %#x-- RX_startup:-- TX_startup:--\n",
		aulData[0]&(UINT32)0xff, aulData[1], aulData[2]);
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:1 OptLofAlmCnt:-- LinkLofAlmCnt:-- OptErr:-- OptKErrCnt:--\n");
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    ulLen += sprintf_s(pTmp,SCHAR_MAX, "Opt:1 OptPaFrameCnt:-- OptPaAlamCnt:--\n");
    INPUT_IQLEN_CHECK(ulLen,length,pTmp,ptOptDiag,ptNetPack);
	strncat_s(strIqInfo,length,pTmp,SCHAR_MAX);

    free(pTmp);
	free(ptOptDiag);
	free(ptNetPack);
#endif	
	return BSP_OK;
}

UINT32 BspIqShowInfo(INT8 *strIqInfo, UINT32 length)
{
    if (pBspShowIqInfoCallBack != NULL)
    {
       return pBspShowIqInfoCallBack((char *)strIqInfo, length);
    }
    else
    {
        dbgInfoEx("%s,function connect !\n",__FUNCTION__);
        BspIqShowInfo_Test((char *)strIqInfo,length);
    }

    return BSP_OK;
}

/*测试接口*/
ULONG BspIqShowInfoTest(VOID)
 {
    char *stringInfo = NULL;
    int check;

    stringInfo = (char*)malloc(2400);
    if(NULL == stringInfo)
    {
        RedirPrintf("%s %d The malloc is failed!\n",__FUNCTION__,__LINE__);
      return BSP_ERROR;
    }
    memset(stringInfo,0,2400);

    check = BspIqShowInfo((INT8 *)stringInfo,2400);
    if(BSP_OK == check)
    {
        RedirPrintf("%s\n",stringInfo);
        free(stringInfo);
        return BSP_OK;
    }
    else
    {
        RedirPrintf("%s\n",stringInfo);
        RedirPrintf("%s %d The recall of BspIqShowInfo is errror!\n",__FUNCTION__,__LINE__);
        free(stringInfo);
        return BSP_ERROR;
    }
 }


UINT32 BspSetRingnetShortCircuit(UINT32 flag)
{
    UINT32 retVal   = BSP_OK;
    UINT32 logOptNo = 0;
    UINT32 phyOptNo = 0;
    UINT32 slaOptNo = 0;

    retVal |= BspHalAdaptGetMainPhyOpt(&phyOptNo);
    if(phyOptNo == BSP_ERROR)
    {
        dbgInfo("%s: The active optical interface is not identified. \n", __FUNCTION__);
        return BSP_ERROR;
    }

    slaOptNo = 1 - phyOptNo;
    logOptNo = BspHalAdaptGetLogOpt(slaOptNo);
    retVal |= BspSetOptCpriSetFrameLoopBack(logOptNo, flag);
    BspSysMsDelay(100);

    BspLog(LOG_LEVEL_0,"%s: phyOptNo[%d], slaOptNo[%d], logOptNo[%d]. \n", __FUNCTION__, phyOptNo, slaOptNo, logOptNo);
    dbgInfoEx("%s: phyOptNo[%d], slaOptNo[%d], logOptNo[%d]. \n", __FUNCTION__, phyOptNo, slaOptNo, logOptNo);
    return retVal;
}

/**************************************************************************
 * 函数名称： BspClearOptData
 * 功能描述： 清除残余光口数据，提供给高层调用
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： BSP_OK
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspClearOptData(VOID)
{
    UINT32 retVal = BSP_OK;
    
    if((OPT_SUPPORT_DUAL_BBU == BspGetSupportDualBbuFlag()) || (1 == BspGetTddSupportRingModeWorkFlag()))
    {
        retVal = BspSetCpriCfgCasTransMode(1, 1); /*复位前恢复成 向级联光口转发的控制字来源为主光口*/
    }

    return retVal;
}


/*获取BBU光口 RRU光笼 RRU物理逻辑口对应关系  因为存在插拔过程APP调用 所以只BspGetBbuFiberPort 无法正确反应映射关系 依赖于高层下发的IQ里的BBU端口号信息*/
UINT32 BspSetOptMapNet4LoadShare_IR(UINT32 BBUGlobalOptID0, UINT32 BBUGlobalOptID1, T_RRUOptMapRelation *OptMap)
{
    UINT32 loop = 0;
    UINT32 bbuPort = 0;
    UINT32 mainLogNo = 0;
    T_RRUOptMapRelation tmpPara = {0};
    UINT32 firstRec = 0xff;

    BspLog(LOG_LEVEL_0,"%s bbuport 0x%x 0x%x\n", __FUNCTION__, BBUGlobalOptID0, BBUGlobalOptID1);
    INPUT_POINTER_CHECK(OptMap);
    BspHalAdaptCpriCfgOptProperty(0,0,1,0);/*高层负荷分担才调用 这里直接配置双上联 切组网的时候在倒换任务再改配回去*/
    BspHalAdaptCpriCfgOptProperty(1,0,1,0);
    BspSysMsDelay(500);    /*确保映射关系生效*/
    tmpPara.BBUOptID[0] = BspGetBbuFiberPort(0);
    tmpPara.BBUOptID[1] = BspGetBbuFiberPort(1);
    (VOID)BspSaveBbuGlobalOptPort(BBUGlobalOptID0, BBUGlobalOptID1);
    if((0xff !=  BBUGlobalOptID0)||(0xff !=  BBUGlobalOptID1))
    {
        for(loop = 0; loop < OPTMAXNUM; loop++)
        {
             bbuPort = BspGetBbuFiberPort(loop);
             BspLog(LOG_LEVEL_0,"%s  sfpNo %d bbuPort 0x%x\n", __FUNCTION__, loop, bbuPort);
             if( BBUGlobalOptID0 == bbuPort)
             {
                  firstRec = loop;
                  tmpPara.BBUOptID[loop] = bbuPort;
                  if(0 == tmpPara.BBUOptID[1-loop])
                  {
                      tmpPara.BBUOptID[1-loop] =  BBUGlobalOptID1;
                  }
                  break;
             }
         }
         if(0xff == firstRec)
         {
             for(loop = 0; loop < OPTMAXNUM; loop++)
             {
                  bbuPort = BspGetBbuFiberPort(loop);
                  BspLog(LOG_LEVEL_0,"%s ssfpNo %d bbuPort 0x%x\n", __FUNCTION__, loop, bbuPort);
                  if( BBUGlobalOptID1 == bbuPort)
                  {
                       firstRec = loop;
                       tmpPara.BBUOptID[loop] = bbuPort;
                       if(0 == tmpPara.BBUOptID[1-loop])
                       {
                           tmpPara.BBUOptID[1-loop] =  BBUGlobalOptID0;
                       }
                       break;
                  }
              }
         }
    }
    else
    {
         return BSP_ERROR;
    }
    BspSetOptCpriRelation(0,0,1);     /*物理0和逻辑0 固定映射*/
    BspSetOptCpriRelation(1,1,1);     /*物理1和逻辑1 固定映射*/
    BspSetOptCpriRelation(2,2,1);     /*物理0和逻辑0 固定映射*/
    BspSetOptCpriRelation(3,3,1);     /*物理1和逻辑1 固定映射*/
    /*主片的lane2 lane3是片间cpri 关掉告警上报*/
    BspOptManualSetLopAlarm(2,1,0);   /*复位接口会恢复*/
    BspOptManualSetLosAlarm(2,1,0);
    BspOptManualSetLofAlarm(2,1,0);
    BspOptManualSetLopAlarm(3,1,0);
    BspOptManualSetLosAlarm(3,1,0);
    BspOptManualSetLofAlarm(3,1,0);
    /*主片逻辑光口3---从片上联逻辑光口0   物理上 IC0的lane3对应IC1的lane0 初始化时IC0 已经phy3--log3 IC1 phy0-log0*/
    /*主片逻辑光口2---从片上联逻辑光口1   物理上 IC0的lane2对应IC1的lane1 上边已经将IC0的物理2和逻辑2绑定  */
    /*IC1的物理0和逻辑0的固定映射 由cpri初始化参数完成，物理1的上联属性设置 物理1和逻辑1的映射关系设置 放到设置负荷分担组网的时候 因为有lane自救切换 还不能放到切换的时候*/
    BspHalAdaptCpriCfgOptProperty(2,1,1,1);     /*lane2设置为下联 IR切组网会复位 初始化重新配置成默认*/
    tmpPara.uValidFlag = 0xa5;
    tmpPara.uRruNetMode = BspGetOptWorkMode(0);
    tmpPara.uRruExternalLaneNum = BspGetOptNum();
    BspHalAdaptGetMainLogicOpt(&mainLogNo);
    INPUT_OPT_CHECK(mainLogNo);   /*主光口异常时报错返回*/
    tmpPara.uRruMasterLoigcOpt = mainLogNo;
    tmpPara.uRruReferencePhyOpt = BspHalAdaptGetBaseDelayLogOpt();     /*基准光口 物理和逻辑11对应*/
    tmpPara.uRruUpLinkReferencePhyOpt = BspHalAdaptGetCpriBifGfRxChanFr();     /*上行基准光口*/
    tmpPara.PhyOptID[0] = BspGetPhyNoBySfpNo(0);
    tmpPara.PhyOptID[1] = BspGetPhyNoBySfpNo(1);
    tmpPara.LogicOptID[0] = tmpPara.PhyOptID[0];     /*ic0的逻辑和物理一一对应 所以这里不从底层再读*/
    tmpPara.LogicOptID[1] = tmpPara.PhyOptID[1];
    dbgInfoEx("%s  %d %d %d %d  %d %d %d  %d %d\n", __FUNCTION__, tmpPara.uRruNetMode,  tmpPara.uRruExternalLaneNum, tmpPara.uRruMasterLoigcOpt, tmpPara.uRruReferencePhyOpt,
            tmpPara.uRruUpLinkReferencePhyOpt, tmpPara.PhyOptID[0], tmpPara.PhyOptID[1], tmpPara.BBUOptID[0], tmpPara.BBUOptID[1]);
    memcpy_s(OptMap, sizeof(T_RRUOptMapRelation), &tmpPara, sizeof(T_RRUOptMapRelation));
    BspLog(LOG_LEVEL_0,"%s  %d %d %d %d %d %d %d  %d %d %d %d\n", __FUNCTION__, tmpPara.uRruNetMode,  tmpPara.uRruExternalLaneNum, tmpPara.uRruMasterLoigcOpt, tmpPara.uRruReferencePhyOpt,
            tmpPara.uRruUpLinkReferencePhyOpt, tmpPara.PhyOptID[0], tmpPara.PhyOptID[1], tmpPara.BBUOptID[0], tmpPara.BBUOptID[1], tmpPara.LogicOptID[0], tmpPara.LogicOptID[1]);

    return BSP_OK;
}

void getsharenet(UINT32 bbuPort0, UINT32 bbuPort1)
{
   T_RRUOptMapRelation tmp = {0};
   UINT32 retVal = BSP_OK;

   retVal = BspSetOptMapNet4LoadShare_IR(bbuPort0, bbuPort1, &tmp);
   dbgInfo("bbuPort %d bbuPort1 %d retVal %d\n", bbuPort0, bbuPort1,retVal);

   return;
}

/*高层下发之前底层上边的map映射关系*/
UINT32 BspSetLoadShareOptMapRelation(T_RRUOptMapRelation *OptMap)
{
    INPUT_POINTER_CHECK(OptMap);
    BspLog(LOG_LEVEL_0,"%s enter\n", __FUNCTION__);
    memset_s(&g_rruOptMapRelation, sizeof(T_RRUOptMapRelation), 0, sizeof(T_RRUOptMapRelation));
    memcpy_s(&g_rruOptMapRelation, sizeof(T_RRUOptMapRelation), OptMap, sizeof(T_RRUOptMapRelation));
    BspHalAdaptSetBaseDelayLogOpt(g_rruOptMapRelation.uRruReferencePhyOpt);    /*基准光口要下发到从MGR和从片  光口计算时延需要*/
    BspHalAdaptSetMainLogOptOnMaster(g_rruOptMapRelation.uRruMasterLoigcOpt);

    /* Started by AICoder, pid:a3da5td6c912ab114ed10876c0081100d56761aa */
    if(0 == BspGetRpuId())
    {
        /*此函数app只会在从进程调用，增加RpuId限制只在主片从进程生效*/
        BspHalAdaptCpriBifGfRxChanFr(g_rruOptMapRelation.uRruUpLinkReferencePhyOpt);
        BspHalAdaptCfgSwSrcAlignFr(g_rruOptMapRelation.uRruUpLinkReferencePhyOpt+1);
        BspLog(LOG_LEVEL_0,"%s uRruUpLinkReferencePhyOpt[%d]. \n", __FUNCTION__, g_rruOptMapRelation.uRruUpLinkReferencePhyOpt);
    }
    /* Ended by AICoder, pid:a3da5td6c912ab114ed10876c0081100d56761aa */

    return BSP_OK;
}

void prnsharemap(void)
{
    dbgInfo("vaildFlag %d\n", g_rruOptMapRelation.uValidFlag);
    dbgInfo("rruNetMode %d\n", g_rruOptMapRelation.uRruNetMode);
    dbgInfo("ruExternalLaneNum %d\n", g_rruOptMapRelation.uRruExternalLaneNum);
    dbgInfo("masterLoigcOpt %d\n", g_rruOptMapRelation.uRruMasterLoigcOpt);
    dbgInfo("ruReferencePhyOpt %d\n", g_rruOptMapRelation.uRruReferencePhyOpt);
    dbgInfo("sfp0-logNo%d  sfp1-logNo%d \n", g_rruOptMapRelation.LogicOptID[0],g_rruOptMapRelation.LogicOptID[1]);
    dbgInfo("sfp0-phyNo%d  sfp1-phyNo%d \n", g_rruOptMapRelation.PhyOptID[0],g_rruOptMapRelation.PhyOptID[1]);
    dbgInfo("sfp0-bbuPort0x%x  sfp1-bbuPort0x%x \n", g_rruOptMapRelation.BBUOptID[0],g_rruOptMapRelation.BBUOptID[1]);
    return;
}

/*****************************************************************************
 *  函数名称   : BspPrnHdlcRate
 *  功能描述   : 打印hdlc 速率
 *  输入参数   : 无
 *  输出参数   : hdlc 速率
 *          000:noHDLC;001:960K;010:1.92M;011:2.4M;100:3.84M;101:4.8M;110:7.68M;111:invalid
 *  返 回 值  :  BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 */
UINT32 BspPrnHdlcRate()
{
    UINT32 hdlcCfgVal = 0;
    UINT32 hdlcRate = 0;
    hdlcCfgVal = BspHalAdaptGetOptHdlcRate();
    hdlcRate = s_BitTotal[hdlcCfgVal];
    dbgInfo("%s HdlcCfgVal:%d HdlcRate:%dK\n", __FUNCTION__, hdlcCfgVal, hdlcRate);
    return BSP_OK;
}

/** 提供给高层调用IC底层接口，获取采样率和axc虚拟资源**/
UINT32 BspAxcAllocGetSmpByBw(UINT32 bw, UINT32 radioMode, UINT32 *sampleRate, UINT32 *axcStart, UINT32 *axcNum)
{
    UINT32 retVal = BSP_OK;
    retVal |= IcHalApiAxcAllocGetSmpByBw(bw, radioMode, sampleRate, axcStart, axcNum);
    return retVal;
}

UINT32 BspGetGfCheckFlag(VOID)
{
    return BspHalAdaptGetGfCheckFlag();
}

/*睡眠小区专项治理*/
/* Started by AICoder, pid:d60013b8d8x6fa11480a0b04d0fc2810c7d5e738 */
UINT32 BspOptVerifyT12Cfg(UINT32 bspNetMode, UINT32 ta, UINT32 fwdT12, UINT32 revT12)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipTransDly = 0;
    UINT32 chipTrandly_dl = 0;
    UINT32 chipTrandly_ul = 0;
    UINT32 halNetMode = 0;

    retVal = BspGetCurrChipTransmitDly(&chipTrandly_dl,&chipTrandly_ul);     /*这个参数只在从片有*/
    retVal |= BspGetHalTopNetByBspTopNet(bspNetMode, &halNetMode);
    chipTransDly = chipTrandly_dl;
    retVal |= BspHalAdaptOptVerifyT12Cfg(halNetMode, chipTransDly, ta, fwdT12, revT12);

    return retVal;
}
/* Ended by AICoder, pid:d60013b8d8x6fa11480a0b04d0fc2810c7d5e738 */


/*读取光口的告警状态计数 用于判断中间对外主光口是否发生过异常*/
UINT32 BspGetOptCpriSerdesAlmCnt(OPT_SERDES_STA type, UINT32 *pCnt)
{
    UINT32 phyMainOpt = 0;

    INPUT_POINTER_CHECK(pCnt);
    BspHalAdaptGetMainPhyOpt(&phyMainOpt);
    if (BSP_ERROR == phyMainOpt)
    {
        return BSP_ERROR;
    }

    switch (type)
    {
        case SERDES_LOS_STA:
            *pCnt = BspHalAdaptCpriSerdesGetLosCnt(phyMainOpt);
            break;
        case SERDES_LOP_STA:
            *pCnt = BspHalAdaptCpriSerdesGetLopCnt(phyMainOpt);
            break;
        case SERDES_LOF_STA:
            *pCnt = BspHalAdaptCpriSerdesGetLofCnt(phyMainOpt);
            break;
        default:
            break;
    }

    dbgInfoEx("%s phyopt %d cnt %d\n", __func__, phyMainOpt, *pCnt);

    return BSP_OK;
}

UINT32 g_ulMainOptChgSta = SWITCH_OFF;  /*未切换 切换标志未设置*/
UINT32 g_ulUpOptDataEn = SWITCH_ON;    /*数据打开 未保护 保护未使能*/
UINT32 g_ulFrLoopCfgFlag = 0;
void testSetOptStaEn(UINT32 chgSta, UINT32 dataEn)
{
    g_ulMainOptChgSta = chgSta;
    g_ulUpOptDataEn = dataEn;
}
/*1. 主光口状态变化 且 软件保护未开 且标志未置  对APP设置标志有效
2 保护使能 且 主光口正常  对APP设置标志有效*/
/* Started by AICoder, pid:na4e0xc217l8e66146c609db00013325e102ce2d */
UINT32 BspSetMainPhyOptChangeState(UINT32 currMainNo, UINT32 recMainNo)
{
    if (SWITCH_ON_R == recMainNo)
    {
        return BSP_OK;  /* 上电首次 不触发流程 */
    }
    if (currMainNo != recMainNo)
    {
       BspLog(LOG_LEVEL_0,"%s currMainNo %d recMainNo %d tick %d\n", __func__, currMainNo,recMainNo, tickGet());
    }
    if (((currMainNo != recMainNo)&&(BSP_ERROR != recMainNo)) &&
        (SWITCH_ON == g_ulUpOptDataEn) &&
        (SWITCH_OFF == g_ulMainOptChgSta))
    {/*主光口状态从好到坏（需要关注支持盲插机型，0->1,1->0，都认为出现过异常） 且 软件保护未使能 且 对外主光口状态切换标志未设置*/
        g_ulMainOptChgSta = SWITCH_ON;
        BspLog(LOG_LEVEL_0,"%s case0 %d\n",__func__, g_ulMainOptChgSta);
    }

    if ((SWITCH_OFF == g_ulUpOptDataEn) &&
        (BSP_ERROR != currMainNo))/*主光口正常 且 软件保护使能，对APP设置对外主光口状态切换标志为true*/
    {
        g_ulMainOptChgSta = SWITCH_ON;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:na4e0xc217l8e66146c609db00013325e102ce2d */
//返回0 - 对外主光口状态未切换 返回1 -对外主光口状态切换  频繁调用不能加log
/* Started by AICoder, pid:n6b44za762g0195144f8081f104d6a091184b5b2 */
UINT32 BspGetMainPhyOptChangeState(VOID)
{
    return g_ulMainOptChgSta;
}
/* Ended by AICoder, pid:n6b44za762g0195144f8081f104d6a091184b5b2 */

//2. 清除对外主光口状态切换标志的接口
/* Started by AICoder, pid:bf5bau9c23655b914f230a02101bd409d405e6ea */
UINT32 BspClrMainPhyOptChangeState(VOID)
{
    BspLog(LOG_LEVEL_0,"%s\n",__func__);
    g_ulMainOptChgSta = SWITCH_OFF;
    return BSP_OK;
}
/* Ended by AICoder, pid:bf5bau9c23655b914f230a02101bd409d405e6ea */

/*3.设置/清除软件保护的接口（内部实现为打开/关闭片间光口的下行IQ数据）
enable:  1- 打开上联逻辑光口数据； 0- 关闭上联逻辑光口数据  0xc2408004*/
/* Started by AICoder, pid:bd93fe1a8ag780d141740b98c0b0bc2d58500a9a */
UINT32 BspSetUpOptDataEn(UINT32 enable)
{
    UINT32 retVal = BSP_OK;
    UINT32 sw = 0;
    /* Started by AICoder, pid:4929fcbbd7tc38914ac40b129048a10c84c981df */
    UINT32 phyNo = 0;
    UINT32 optProperty = 0;
    UINT32 optInterConn = 0;
    UINT32 logNo = 0;
    /* Started by AICoder, pid:4929fcbbd7tc38914ac40b129048a10c84c981df */
    BspLog(LOG_LEVEL_0,"%s %d\n",__func__,enable);
    g_ulUpOptDataEn = enable;
    sw = 1 - enable;    /*底层接口1关 0开*/
    /* Started by AICoder, pid:9929fpbbd7xc38914ac40b129048a11c84c081df */
    for(phyNo = 0; phyNo < OPT_PCS_LANE_MAX_NUM; phyNo++)
    {
        retVal = BspHalAdaptGetOptProperty(phyNo, &optProperty, &optInterConn);
        dbgInfoEx("laneId %d optProperty(0-up 1-down) %d optInterConn(0-out 1-inner) %d\n", phyNo, optProperty, optInterConn);
        if((BSP_OK == retVal)&&(1 == optInterConn))   /*主片上执行所以这不再判断上下联属性  sgmii执行也不影响 所以不判断速率*/
        {
             logNo = BspHalAdaptGetLogOpt(phyNo);
             if((2 == logNo)||(3 == logNo))   /*片间下联逻辑口只能是2 3其他都是非法值*/
             {
                  BspLog(LOG_LEVEL_0,"%s phyNo %d logNo %d\n",__func__, phyNo, logNo);
                  retVal |= BspHalAdaptCpriCfgIqCloseEn(logNo, sw, TX);  /*只关片间下联口*/
             }
        }
    }
    /* Ended by AICoder, pid:9929fpbbd7xc38914ac40b129048a11c84c081df */
    return retVal;
}
/* Ended by AICoder, pid:bd93fe1a8ag780d141740b98c0b0bc2d58500a9a */
UINT32 BspGetUpOptDataEn(VOID)
{
    return g_ulUpOptDataEn;
}
/* Started by AICoder, pid:44f74s50aep33a814e43099e20b14a6aec90d250 */
UINT32 BspCfgCpriFrLoopModeAndLoopBack(VOID)
{
    UINT32 phyOpt = 0;
    UINT32 loop = 0;
    UINT32 maxTry = 3;
    UINT32 enFlag = 0;
    UINT32 ringFlag = 0;
    UINT32 shareFlag = 0;
    UINT32 retVal = BSP_OK;

    enFlag = BspGetOptInnerCpriFrModeEn();   /*和原有倒换任务的机型区分开*/
    if (OPT_INNER_CPRI_FR_LOOP_MODE_OFF == enFlag)
    {
        return BSP_OK;
    }
    // 单片机型不需要
    if (BspGetRpuNum() < 2)
    {
        return BSP_OK;
    }
    ringFlag = BspGetOptRingFlag();
    shareFlag = BspGetOptShareFlag();
    if((ringFlag == OPT_NOT_SUPPORT_RING) && (shareFlag == OPT_NOT_SUPPORT_RING))
    {
         retVal = BSP_ERROR;    /*既不支持环网也不支持负荷分担，原来进不来 就到此接口return error,在外边一层倒换任务提前返回*/
    }
    BspHalAdaptGetMainPhyOpt(&phyOpt);
    dbgInfoEx("%s enter phyOpt %d\n", __func__,phyOpt);
    if (BSP_ERROR == phyOpt)
    {   /* 主光口异常立即切自震荡和环回 */
        if(0 == g_ulFrLoopCfgFlag)
        {
              BspLog(LOG_LEVEL_0,"%s: ENABLE FLAG %d tick %d\n", __FUNCTION__, g_ulFrLoopCfgFlag, tickGet());
        }
        if(BSP_OK != retVal)
        {  /*支持环网或者负荷分担的机型 在倒换任务里有配置自震荡 不在这里重复配置   特别注意纯TDD机型不论单片多片配置环网和主备时不切自震荡*/
            BspHalAdaptCpriSetFrTestMode(LOG_OPT0, ENABLE);     /*初始化时可以恢复此配置IcHalOptMeasureInit-IcHalOptCpriFrCfg-IcHalCpriSetFrTestMode*/
            BspHalAdaptCpriSetFrTestMode(LOG_OPT1, ENABLE);
        }
        BspHalAdaptCpriInternalLoopback(LOG_OPT0, ENABLE);
        BspHalAdaptCpriInternalLoopback(LOG_OPT1, ENABLE);
        g_ulFrLoopCfgFlag = 1;
    }
    else
    {
        for (loop = 0; loop < maxTry; loop++)
        {
            phyOpt = BspGetMainPhyOpt();
            dbgInfoEx("%s phyOpt %d \n", __func__, phyOpt);
            if (BSP_ERROR == phyOpt)   /* 从正常到不正常的切换时刻 */
            {
                BspLog(LOG_LEVEL_0,"%s: ERROR FLAG %d tick %d\n", __FUNCTION__, g_ulFrLoopCfgFlag, tickGet());
                break;
            }
            BspSysMsDelay(10);
        }

        if (loop == maxTry)  /* 防抖之后再去掉 */
        {
            if(1 == g_ulFrLoopCfgFlag)
            {
                BspLog(LOG_LEVEL_0,"%s: DISABLE FLAG %d tick %d\n", __FUNCTION__, g_ulFrLoopCfgFlag, tickGet());
            }
            BspHalAdaptCpriInternalLoopback(LOG_OPT0, DISABLE);
            BspHalAdaptCpriInternalLoopback(LOG_OPT1, DISABLE);
            if(BSP_OK != retVal)
            {
                BspHalAdaptCpriSetFrTestMode(LOG_OPT0, DISABLE);
                BspHalAdaptCpriSetFrTestMode(LOG_OPT1, DISABLE);
            }
        }
        g_ulFrLoopCfgFlag = 0;
    }

    return retVal;
}
/* Ended by AICoder, pid:44f74s50aep33a814e43099e20b14a6aec90d250 */


VOID BspSetSupportDoubleBBUMainSlaveFlag(UINT32 flag)
{
    BspLog(LOG_LEVEL_0,"%s flag %d\n",__func__, flag);
    g_supportDoubleBBUMainSlaveFlag = flag;
}

UINT32 BspGetSupportDoubleBBUMainSlaveFlag(VOID)
{
    return g_supportDoubleBBUMainSlaveFlag;
}

VOID BspSetpriorityLinkByPhy0Flag(UINT32 flag)
{
    BspLog(LOG_LEVEL_0,"%s flag %d\n",__func__, flag);
    g_priorityLinkByPhy0Flag = flag;
}

UINT32 BspGetpriorityLinkByPhy0Flag(VOID)
{
    return g_priorityLinkByPhy0Flag;
}
/*手动设置屏蔽片间光口告警上报
 * QCELL多片机型主片上片间lane是1
 * CPRI无此告警控制字 关了也不影响，这里不区分IR和CPRI了
 * sgmii无此功能，关了也不影响*/
UINT32 BspManualCloseChipInterOptAlm(UINT32 phyNo)
{
    UINT32 optProperty = 0;
    UINT32 optInterConn = 0;
    UINT32 retVal = BSP_OK;
    UINT32 logNo = 0;

     /* ulOptProperty : 0-表示上联, 1-表示下联, 2-表示未知态, 3-表示无光态
        ulOptInterConn: 1-表示CHIP间互联光口，与ulPropertyCfgEn 无关 */
     retVal = BspHalAdaptGetOptProperty(phyNo, &optProperty, &optInterConn);
     dbgInfoEx("%s phyNo %d optProperty %d, optInterConn %d\n", __FUNCTION__, phyNo, optProperty, optInterConn);
     if(1 == optInterConn)
     {
          logNo = BspGetLogicPort(phyNo);
          dbgInfoEx("%s phyNo %d logNo %d\n", __FUNCTION__, phyNo, logNo);
          if(logNo <= LOG_OPT_3)    /*有映射关系才执行*/
          {
              retVal |= BspOptManualSetLopAlarm(logNo,1,0);
              retVal |= BspOptManualSetLosAlarm(logNo,1,0);
              retVal |= BspOptManualSetLofAlarm(logNo,1,0);
          }
     }

     return retVal;
}

UINT32 BspInitChipInterOptAlmEn(VOID)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 rpuId = 0;
    UINT32 rpuNum = 0;

    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
        return BSP_OK;   /*qcell 接PB 先不需要如下流程*/
    }
    if(PROCOTOL_IR != BspGetOptCpriProtocol(0))
    {
        return BSP_OK;
    }
    (VOID)BspHalAdaptGetIcChipId(&rpuId);
    if(rpuId > 0)   /*从片不区分用没有 是sgmii还是cpri 四个口全屏蔽掉*/
    {
        retVal = BspSetOptControlAlarmClr();
        return retVal;
    }
    rpuNum = BspGetRpuNum();
    if(rpuNum < 2)
    {
         return BSP_OK;    /*单片机型无此问题  主片从MGR也从此处提前返回*/
    }
    for(loop = 0; loop < SERDES_LANE_MAX; loop++)   /*lane*/
    {
       retVal |= BspManualCloseChipInterOptAlm(loop);
    }
    return retVal;
}
/* Started by AICoder, pid:n4e9f4a3de92aab1486e0ab720f662163ab189fd */
void BspSetBbuPortSpecialFlag(UINT32 flag)
{
    g_ulBbuPortSpeFlag = flag;
}

UINT32 BspGetBbuPortSpecialFlag(void)
{
    return g_ulBbuPortSpeFlag;
}
/* Ended by AICoder, pid:n4e9f4a3de92aab1486e0ab720f662163ab189fd */
/*支持负荷分担的机型，g_ulBbuPortSpeFlag=1 且当前组网为级联组网且RRU是正向第一级 且有效的逻辑下联口收到的BBUPort控制字！=0（有效值） 则软配 否则自动控制控制字转发*/
/* Started by AICoder, pid:i8d4eh348ad7f051471509f5707c007c34712215 */
void BspSetBbuPortSpecialCtrl(void)
{
     UINT32 support = 0;
     UINT32 optWorkMode = 0;
     UINT32 mainPhyOpt = 0;
     UINT32 optDir = 0;
     UINT32 linkInfo = 0;
     UINT32 slavePhyOpt = 0xf;
     UINT32 slavelogOpt = 0;
     UINT32 protocol = 0;

     protocol = BspGetOptCpriProtocol(0);    /*cpri无此问题  这里是防止协议自适应机型进去*/
     support = BspGetOptShareFlag();

     if((OPT_SUPPORT_SHARE != support)||(PROCOTOL_IR != protocol))    /*主控BSP进行支持负荷分担组网的多片机型的识别*/
     {
         dbgInfoEx("BspSetBbuPortSpecialCtrl not need\n");
         return;  /*不涉及此问题*/
     }
     if(0 == g_ulBbuPortSpeFlag)  /*恢复之后不用往下走*/
     {
         BspHalAdaptSoftCfgTxBbuport(2,0);
         BspHalAdaptSoftCfgTxBbuport(3,0);
         return;
     }
     mainPhyOpt = BspGetMainPhyOpt();
     if(BSP_ERROR == mainPhyOpt)
     {
         /*自动控制*/
         BspHalAdaptSoftCfgTxBbuport(2,0);
         BspHalAdaptSoftCfgTxBbuport(3,0);
         return;
     }
     slavePhyOpt = 1 - mainPhyOpt;
     slavelogOpt = BspGetLogicPort(slavePhyOpt);   /*负荷分担目前逻辑和物理光口有手动设置映射 不会存在找不到逻辑口 级联有可能*/
     if(slavelogOpt < LOG_OPT2)
     {
          BspLog(LOG_LEVEL_0,"%s: slavelogOpt %d uplink\n", __FUNCTION__, slavelogOpt);
          return;    /*这时候还是上联属性 不做处理，控制字自己转自己的接收  不会转另一个口的   这个地方目前是靠光口自适应到step6和倒换任务的间隔保证的，负荷分担下软复位启动后设为级联但是在倒换任务之前还是双上联*/
     }
     if(slavelogOpt >= LOG_OPT_UNKNOW)   /*RRU侧如果下联口异常，读取的控制字是0  而对端BBU 检测告警识别到0 0xff 不会上报告警，所以这里不再校验控制字的有效性 下联口读到的值直接送给BBU 场景对应RRU侧的RX异常，但是TX自震荡，这样BBU的接收通路还是正常的*/
     {
         /*自动控制*/
         BspHalAdaptSoftCfgTxBbuport(2,0);
         BspHalAdaptSoftCfgTxBbuport(3,0);
         return;
     }
     BspHalAdaptCpriGetRruDirection(&optDir);   /*0是正向*/
     linkInfo = BspGetRruLinkInfo();      /*TDD机型当前处于的级数*/
     optWorkMode = BspGetDefaultOptWorkMode(0);
     dbgInfoEx("bbuport cfg slavelogOpt %d  optDir %d linkInfo %d  optWorkMode %d\n", slavelogOpt,optDir,linkInfo,optWorkMode);
     BspLog(LOG_LEVEL_0,"%s: bbuport cfg slavelogOpt %d optDir %d linkInfo %d  optWorkMode %d\n", __FUNCTION__, slavelogOpt,optDir,linkInfo,optWorkMode);
     if((1 == linkInfo)&&((BSP_OPT_WORK_MODE_CASCADE ==  optWorkMode)||(BSP_OPT_WORK_MODE_CASCADE_NORMAL ==  optWorkMode))&&(0  == optDir))
     {/*启动后默认设置的BBUPort控制字特殊处理标志==1*/  /*当前组网为级联组网且RRU是正向第一级*/
         /*手动控制*/
         BspHalAdaptSoftCfgTxBbuport(slavelogOpt,1);   /*组网下发肯定是在版本升级复位之前，这块不用额外考虑寄存器恢复流程  新版本在if(0 == g_ulBbuPortSpeFlag) 已经能恢复  协议切换会中间会有断链if(BSP_ERROR == mainPhyOpt) 能恢复 */
         return;
     }
     else
     {
         /*自动控制*/
         BspHalAdaptSoftCfgTxBbuport(2,0);
         BspHalAdaptSoftCfgTxBbuport(3,0);
         return;
     }
}
/* Ended by AICoder, pid:i8d4eh348ad7f051471509f5707c007c34712215 */

#include "bsppub.h"
#include "bspcomm.h"
#include <math.h>
#include "rruinfo.h"
#include "ichaladaptbspapi_opt.h"
#include "optctrl_inter_def.h"
#include "funccommon_a.h"
#include "ichaladapt_opt_ic4_2.h"

#define PHY_PWR_VAL (400000)     /*TDD定标最大功率*/
#define PHY_PWR_VAL_FDD (20000)  /*FDD定标最大功率*/
#define STITCH_MODE_CARR_NUM 3
#define NONE_STITCH_MODE_CARR_NUM 1
#define MAX_REF_POWER 1100

typedef struct tagT_ErsScaleInfo
{
    INT32 ersIndexMin;
    INT32 ersIndexMax;
    UINT32 scaleValMin;
    UINT32 scaleValMax;
    UINT32 indexSegNum;
    UINT32 ersIndexSegVal[32];
}T_ErsScaleInfo;

/*下表内容每行80个值，方便查找*/
static UINT8 s_ScaleTbl[342] =
{
    7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 7 , 6 , 6 , 6,  6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 ,
    6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 6 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 ,
    5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 5 , 4 ,
    4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 ,
    4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 4 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 ,
    3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 3 , 2 ,
    2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 ,
    2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 2 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 ,
    1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1 , 1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1
};

static T_ErsScaleInfo stErsScaleInfo = {
    -100, 300, 3, 8, 6, 
    {38, 99, 159, 219, 279, 301}
};
static T_ErsScaleInfo stErsScaleInfo_Fdd = {
    0, 200, 2, 6, 5,
    {19, 79, 139, 199, 201}
};/*表格中scale因子已经减1*/
static FUNC_GetPowSumFromBoard pFuncGetPowSumFromBoard = NULL;
static UINT32 s_CalScaleUsingTxPwr = 0;
/****************************************************************
* 函数名称: BspGetAntPowSumFromBoardCall
* 函数说明： scale因子计算时TDD机型和FDD机型基准功率有差异，从3.0看主要有三类（不适合在公共实现）
　　　　　　　FDD机型取对应小区所在所有通道的NR的载波功率之和　TDD机型取对应小区所在所有通道的标称功率之和　　还有降功率的特殊处理
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*        创建
*
*****************************************************************/
UINT32 BspGetAntPowSumFromBoardCall(FUNC_GetPowSumFromBoard pFunc)
{
    pFuncGetPowSumFromBoard = pFunc;
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspLookupScalebyErsVal
* 函数说明： 根据表索引，查表获取功率增益
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
* 
*****************************************************************/
UINT32 BspLookupScalebyErsVal(UINT32 radioMode, INT32 ersVal, UINT32 *pscale)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(pscale);
    if (BSP_RADIO_STANDARD_FDD_5G == radioMode)  /*保持与已有平台一致命名，方便对比*/
    {
        for (loop = 0; loop < stErsScaleInfo_Fdd.indexSegNum; loop++)
        {
            if( ersVal < (INT32)(stErsScaleInfo_Fdd.ersIndexSegVal[loop]))
            {
                *pscale = stErsScaleInfo_Fdd.scaleValMax - loop;
                return BSP_OK;
            }
        }
        *pscale = stErsScaleInfo_Fdd.scaleValMin;
        return BSP_OK;
    }
    for (loop = 0; loop < stErsScaleInfo.indexSegNum; loop++) 
    {
        if (ersVal < (INT32)(stErsScaleInfo.ersIndexSegVal[loop])) 
        {
            *pscale = stErsScaleInfo.scaleValMax - loop;
            return BSP_OK;
        }
    }
    *pscale = stErsScaleInfo.scaleValMin;
    return BSP_OK;    
}
/****************************************************************
* 函数名称: BspTddGetAntPowSumByAntMask
* 函数说明： TDD nr IF1小区所在天线标称功率之和
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*
*****************************************************************/
UINT32 BspTddGetAntPowSumByAntMask(UINT32 antMask)
{
    UINT32 powSum = 0;
    UINT32 txChanNum = 0;
    UINT32 chanLoop = 0;
    UINT32 chanRatedPow = 0;

    txChanNum = BspGetTxChannel();
    for (chanLoop = 0; chanLoop < txChanNum; chanLoop++)
    {
        (VOID)BspGetRruPathRatedPower(chanLoop, &chanRatedPow); /*t+f 机型使用aulRatedPowerPath字段无法正确获取通道标称功率*/
        if (BIT_SET(chanLoop) & antMask)
        {
            powSum += chanRatedPow;
        }
    }
    return powSum;
}
/****************************************************************
* 函数名称: BspFddGetAntPowSumByAntMask
* 函数说明：FDD nr if1小区所在天线所有nr载波的配置功率之和
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*
*****************************************************************/
UINT32 BspFddGetAntPowSumByAntMask(UINT32 antMask, UINT32 carrNo, UINT32 cellId)
{
    UINT32 chnloop = 0;
    UINT32 powSum = 0;
    UINT32 pow = 0;
    UINT32 tmpRet = BSP_OK;
    UINT32 antNum = 0;

    /*scale因子只有IF1需要配置，IF0不需要配置，配置了也不影响 */
    BspGetAntNumByCellId(cellId, TX, &antNum);
    for(chnloop = 0; chnloop < BspGetTxChannel(); chnloop++)
    {
        if(BIT_SET(chnloop) & antMask)
        {
            pow = 0;
            tmpRet = BspGetCfgCarrPow(chnloop, carrNo, BSP_RADIO_STANDARD_FDD_5G, &pow); /*4.2上FNR 采用0x4000 后续BspGetCfgCarrPow获取bbu实际下发的功率值 而非可能降额之后的值*/
            if(BSP_OK != tmpRet)
            {
                continue;
            }
            if(antNum > 0)
            {
                powSum = pow * antNum;   /*antMask表示本小区在本IC上的天线掩码,antNum 表示本小区在所有IC的总天线数，一个小区的功率一样 所以直接乘以天线数，如果antNum= 0,表明高层没下发这个小区的天线数信息,还按原来流程计算*/
                break;
            }
            powSum +=  pow;
        }
    }
    return powSum;
}
/****************************************************************
* 函数名称: BspCalcNrScaleVal
* 函数说明： 根据数字参考功率，计算数字定标补偿增益（NR)
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
* 
*****************************************************************/
UINT32 BspCalcNrScaleVal(UINT32 radioMode,UINT32 antMask,UINT32 carrNo, UINT32 refVal, UINT32* scaleVal, UINT32 cellId)
{
    DOUBLE ersVal  = 0;
    UINT32 ersIndex = 0;
    UINT32 ratedPwrPm  = PHY_PWR_VAL; /* 整机额定功率 */
    UINT32 baseBandPwrP0 = 0;
    INPUT_POINTER_CHECK(scaleVal);

    if (BSP_RADIO_STANDARD_FDD_5G == radioMode)  /*入参只会是NR制式*/
    {
        ratedPwrPm = PHY_PWR_VAL_FDD;
        baseBandPwrP0 = BspFddGetAntPowSumByAntMask(antMask,carrNo,cellId);
    }
    else
    {
        ratedPwrPm = PHY_PWR_VAL;
        baseBandPwrP0 = BspTddGetAntPowSumByAntMask(antMask);
    }
    if(pFuncGetPowSumFromBoard !=NULL)
    {
        pFuncGetPowSumFromBoard(radioMode,antMask,&ratedPwrPm,&baseBandPwrP0);/*预留单板差异化处理*/
    }
    if(0 != BspGetCalScaleUsingTxPwr())
    {
        baseBandPwrP0 = BspGetCalScaleUsingTxPwr();
    }
    if (baseBandPwrP0 == 0) {
        return BSP_ERROR;
    }
    ersVal = 100 * log10((DOUBLE)baseBandPwrP0 / (DOUBLE)ratedPwrPm);
    ersIndex = (UINT32)((DOUBLE)refVal - ersVal); // ersIndex 要向下取整
    return BspLookupScalebyErsVal( radioMode,ersIndex, scaleVal);
}
/****************************************************************
* 函数名称: BspCalcLteScaleVal
* 函数说明： 根据数字参考功率，计算数字定标补偿增益（LTE)　（只有if1才有数字功率定标，3.0上实际lte暂时无此功能
* 　　　　　４.2注意跟着需求修改
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
* 
*****************************************************************/
UINT32 BspCalcLteScaleVal(UINT32 antMask, UINT32 ulCarrNo, UINT32 ulRadioMode, UINT32 refVal, UINT32 portNum, UINT32* scaleVal, UINT32 cellId)
{
    UINT32 ret = BSP_OK;
    UINT32 pow = 0; /* 小区配置功率 mw*/
    UINT32 i = 0;
    FLOAT  powDbm = 0.0; /* 整机额定功率 */
    FLOAT  txErsDbm = 0.0; 
    FLOAT  portDbm = 0.0;
    INT32  ersIndex = 0;
    UINT32 cfgPow = 0;
    UINT32 maxChan = BspGetTxChannel();
    FLOAT transVal = 0.0;
    UINT32 antNum = 0;

    if (refVal > MAX_REF_POWER) {
        dbgErr("BspCalcLteScaleVal refVal [%u], value error\n", refVal);
        return BSP_ERROR;
    }
    if (portNum > 4) /*portNum最大值为4*/
    {
        dbgErr("BspCalcLteScaleVal portNum [%u] value error\n", portNum);
        return BSP_ERROR;
    }

    BspGetAntNumByCellId(cellId, TX, &antNum);
    if(ulRadioMode == BSP_RADIO_STANDARD_LTE_FDD)
    {
        for (i = 0; i < maxChan; i++)
         {
             if (antMask & (1<<i))
             {
                 cfgPow = 0;
                 ret = BspGetCfgCarrPow(i, ulCarrNo, BSP_RADIO_STANDARD_LTE_FDD, &cfgPow);
                 if (ret != BSP_OK)
                 {
                     continue;
                 }
                 if(antNum > 0)
                 {
                     pow = cfgPow * antNum;
                     break;
                 }
                 pow += cfgPow;
             }
         }
    }
    else
    {
        pow = BspGetRruFullPowByAntMaskType(antMask);
    }
    if(0 != BspGetCalScaleUsingTxPwr())
    {
        pow = BspGetCalScaleUsingTxPwr();
    }
    if (pow == 0)
    {
        dbgErr("%s: carr: 0x%x, totalCfgPow is 0\n", __FUNCTION__, ulCarrNo);
        return BSP_ERROR;
    }
    powDbm = (FLOAT)(10 * log10((double)pow));
    txErsDbm = (refVal - 600.0) / 10.0;
    portDbm = (FLOAT)10 * log10(portNum);
    transVal = txErsDbm - powDbm + portDbm;
    if(transVal >= -43.0)
    {
        ersIndex = (INT32)(10 * (transVal + 43)) + 30;
    }
    else
    {
        ersIndex = (INT32)(transVal + 73);
    }
    if(ersIndex < 30)
    {
        ersIndex += 1;
    }
    else
    {
        ersIndex += 10;
    }
    BspGetLteScaleValByErsIndex(ersIndex, scaleVal);
    return BSP_OK;
}

UINT32 BspSetCalScaleUsingTxPwr(UINT32 uInPut)
{
    s_CalScaleUsingTxPwr = uInPut;
    return BSP_OK;
}

UINT32 BspGetCalScaleUsingTxPwr(void)
{
    return s_CalScaleUsingTxPwr;
}

/****************************************************************
* 函数名称: BspOptSetFFTPara
* 函数说明： 数字功率定标
* 输入参数：
*   cellId  业务小区ID
*   dir     方向
*   scs    子载波间隔
*   para  数字定标参数
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
* 
*****************************************************************/
UINT32 BspOptSetFFTPara(UINT32 uCellId,UINT32 uDir, UINT32 uScs, T_FFTAParam *pPara)
{
    UINT32 optCellId = 0;
    UINT32 antMask = 0;
    UINT32 cellStitchMode = 0; /* 小区拼接方式 */
    UINT32 carrNum = 0;
    UINT32 loop = 0;
    UINT32 radioMode = 0;
    UINT32 scaleVal = 0;
    UINT32 carrNo = 0;
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pPara);
    if (uDir == RX) {
        return BSP_OK;
    }

    optCellId = uCellId;  /*拼接之后的cellid, 传给光口之后底层会自行转换*/
    if (BspHalAdaptGetCellAntMask(optCellId, uDir, &antMask) != BSP_OK) {
        dbgErr("execute BspHalAdaptGetCellAntMask error, optCellId [%u]\n", optCellId);
        return BSP_ERROR;       
    }

    if (BspHalAdaptGetCellCaMode(optCellId, &cellStitchMode) != BSP_OK) {
        dbgErr("execute BspHalAdaptGetCellCaMode error, optCellId [%u]\n", optCellId);
        return BSP_ERROR;             
    }
    /* 1 为载波拼接模式， 0： 非拼接场景 */
    carrNum = cellStitchMode == 1 ? STITCH_MODE_CARR_NUM : NONE_STITCH_MODE_CARR_NUM;
    if (BspHalAdaptGetCellRadioMode(optCellId, &radioMode) != BSP_OK) {
        dbgErr("execute BspHalAdaptGetCellRadioMode error, optCellId [%u]\n", optCellId);
        return BSP_ERROR;
    }
    retVal = BspHalAdaptGetCarrNoByOptCellId(optCellId,&carrNo);
    if(retVal != BSP_OK)
    {
        dbgErr("execute BspHalAdaptGetCarrNoByOptCellId error, optCellId [%u]\n", optCellId);
        return BSP_ERROR;
    }
    retVal |= BspSetCalScaleUsingTxPwr(pPara->fftaTxPwr);
    BspLog(LOG_LEVEL_0,"%s,cellId =[%u], radioMode =[%#x],fftaTxPwr=[%u]\r\n",__FUNCTION__,optCellId, radioMode, pPara->fftaTxPwr);
    for (loop = 0; loop < carrNum; loop++) {
        if ((radioMode == BSP_RADIO_STANDARD_5G)|| (radioMode == BSP_RADIO_STANDARD_FDD_5G)) {
            BspLog(LOG_LEVEL_0,"%s,cellId =[%u], radioMode =[%#x],antMask = [%u],Ers= [%u], loop=[%u]\r\n",\
                    __FUNCTION__,optCellId, radioMode, antMask,pPara->dlErs[loop], loop);
            if (BspCalcNrScaleVal(radioMode,antMask,carrNo, pPara->dlErs[loop], &scaleVal, uCellId) != BSP_OK) {
                dbgErr("execute BspCalcNrScaleVal error, antMask [%u], ersVal [%u]\n", antMask, pPara->dlErs[loop]);
                return BSP_ERROR;
            }
        } else if ((radioMode == BSP_RADIO_STANDARD_LTE_FDD) || (radioMode == BSP_RADIO_STANDARD_LTE_TDD)) {
            BspLog(LOG_LEVEL_0,"%s,cellId =[%u], radioMode =[%#x],antMask = [%u],Ers= [%u], pPara->portNum[loop]=[%u]\r\n",\
                    __FUNCTION__,optCellId, radioMode, antMask,pPara->dlErs[loop], pPara->portNum[loop]);
            if (BspCalcLteScaleVal(antMask, carrNo, radioMode, pPara->dlErs[loop], pPara->portNum[loop], &scaleVal, uCellId) != BSP_OK) {
                dbgErr("execute BspCalcLteScaleVal error, antMask [%u], dlErs [%u], portNum [%u]\n", 
                    antMask, pPara->dlErs[loop], pPara->portNum[loop]);
                return BSP_ERROR;                
            }
        } else { /* 非LTE 和NR 则直接返回OK  */
            return BSP_OK;
        }
        dbgInfo("%s,cellId =[%u], radioMode =[%#x],dir = [%u], loop=[%u], scaleVal = [%u]\r\n",\
                __FUNCTION__,optCellId, radioMode, uDir, loop, scaleVal);
        BspLog(LOG_LEVEL_0,"%s,cellId =[%u], radioMode =[%#x],dir = [%d],uScs = [%u], loop=[%u], scaleVal = [%u]\r\n",\
                __FUNCTION__,optCellId, radioMode, uDir,uScs, loop, scaleVal);
        if (BspHalAdaptSetCellErsInfo(optCellId, loop, cellStitchMode, scaleVal) != BSP_OK) {
            dbgErr("execute BspHalAdaptSetCellErsInfo error, optCellId [%u], loop [%u],cellStitchMode [%u], scaleVal [%u]\n", 
                optCellId, loop, cellStitchMode, scaleVal);
            return BSP_ERROR;
        }
    }
    return BSP_OK;
}

UINT32 BspOptSetFFTParaUwb(UINT32 uCellId,UINT32 uDir, UINT32 uScs, T_FFTAParam *pPara)
{
    return BspOptSetFFTPara(uCellId, uDir, uScs, pPara);
}

/* Started by AICoder, pid:08fa738b1cf1486aba7b11d99af60389 */
VOID BspGetLteScaleValByErsIndex(INT32 ersIndex, UINT32 *scaleVal)
{
    if(NULL == scaleVal)
    {
        return;
    }
    if (ersIndex < 0) {
        *scaleVal = s_ScaleTbl[0];
    } else if(ersIndex >= NELEMENTS(s_ScaleTbl)) {
        *scaleVal = s_ScaleTbl[NELEMENTS(s_ScaleTbl) - 1];
    } else {
        *scaleVal = s_ScaleTbl[ersIndex];
    }
}
/* Ended by AICoder, pid:08fa738b1cf1486aba7b11d99af60389 */

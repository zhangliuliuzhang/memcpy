/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : optadpt.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件提供了单板双光口自适应流程中相关功能接口，这部分属于IC特性的功能，固单独抽取出来
 * 注意事项 : 无
 * 作    者 : 王飞     创建
 * 创建日期 : 2015-01-16 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: wangfei
 * 修改日戳: 2015-01-17 10:28:34
 * 变更说明: 创建文件，DPDIC 光口自适应流程及接口

 *----------------------------------------------------------------------------
 */
/* linux 系统头文件 */
#include <fcntl.h>
#include <linux/sysctl.h>
#include <sys/mman.h>
#include <pthread.h>
#include <errno.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "funccommon.h"
#include "optadpt.h"
#include "optctrl_cpri_ic4_2.h"
#include "ichaladapt_ic4_2.h"
#include "optctrlcommon.h"
#include "timedelay_ic4_2.h"
#include "opt_pcs_api.h"
#include "vxadp.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "psyncdrv.h"
#include "freqcfgcommon.h"
#include "timedelay_ic4_2_interface.h"
#ifndef MULT_PROGRESS_S
#include "sfp.h"
#endif

#define MAX_FRAME_NUM              (1024)
#define BIT_NUM_PER_BYTE           (32)
#define MAX_OUTOFSYNC_ANT_NUM      (8)
#define BITMAP_MAX_NUM             (64)
#define INVALID_FRAME_NO           (0xFFFF)
#define IF(x)    if(x)
extern UINT32 MOD_BOARD_OPT;
UINT8 OptSpeedLsit[] =
{
    BSP_OPT_SPEED_1P2288G,
    BSP_OPT_SPEED_2P4576G,
    BSP_OPT_SPEED_3P0720G,
    BSP_OPT_SPEED_4P9152G,
    BSP_OPT_SPEED_6P1440G,
    BSP_OPT_SPEED_9P8304G,
    BSP_OPT_SPEED_10P1376G,
    BSP_OPT_SPEED_12P16512G,
    BSP_OPT_SPEED_24P33024G,
};

UINT32 g_ulOptCtr = FUNCLIB_OPT_ADPT_ENABLE;
UINT32 g_ulCloseTxFlag = 0;
UINT32 g_ulQsfpCtr = FUNCLIB_OPT_ADPT_ENABLE;
UINT32 g_qcellUlOptCtr = FUNCLIB_OPT_ADPT_ENABLE;
UINT32 g_ringOptSwitch = FUNCLIB_OPT_ADPT_DISABLE;/*实际停止倒换生效标识*/
UINT32 g_fixMainOptCtr = FUNCLIB_OPT_ADPT_DISABLE;
UINT32 g_cfgPriorityCtr = FUNCLIB_OPT_ADPT_ENABLE;
UINT32 g_qcellNeed10G = 1;/* qcell机型是否需要配置10G速率、0：不需要 1：需要 */
ULONG g_ulOptAdptSameStageStep = 0;
UINT32 g_ulAnotherOptSetSpeedFlag[OPTMAXNUM] = {0};  /*下联口是只配rx 还是tx/rx 整个重配的标志*/
UINT32 g_ulAnotherOptSetFecModeFlag[OPTMAXNUM] = {0};  /* 下联口自适应配置fecmode的标志 */
UINT32 g_ulAnotherOptSetSpeedCnt[OPTMAXNUM] = {0};   /*统计下联口RX配置次数，超过门限执行整体复位 进行下联自救  测试环境出现过TX异常导致第二级不建链 原因未定位需要规避*/
UINT32 g_ulOptTxPriSendCnt = 0;  /*强发控制字次数计算  下联口TX正常 RX异常时需要依赖此计数 关闭强发*/
UINT32 g_ulOptTxPriOffCnt = 0;
UINT32 g_ulUpLinkOptSpeedCfgCnt = 0;   /*上联口切速率计数*/
static UINT32 s_SwitchMainPhyOptFlag = 0;
static UINT32 g_SwitchoverFlag = 0;
UINT32 s_LastMainPhyOpt = 0xff;
static UINT32 s_LastMainBbuPort = 0xff;
static UINT32 s_SwitchMainPhyOptFlagLogCnt = 0; /* FDD倒换标志记录log计数 */
static UINT32 s_LastBaseLogOptForShare = 0xff;
static UINT32 s_CurrBaseLogOptForShare = 0xff;
UINT32 s_LastUpBaseLogOptForShare = 0xff;
UINT32 s_CurrUpBaseLogOptForShare = 0xff;
UINT32 g_ulSwCnt = 0;  /*主光口非holdover 但控制字异常计数统计*/
static FUNC_CHECK_RRUIDRANGE s_CheckRruIdRange = NULL;
static FUN_CLEAR_CARR_GAIN pClearCarrGain = NULL;
static UINT32 s_OptSwitchoverFlag = 0;
UINT32 g_ulOptStatus = FUNCLIB_OPT_ADPT_ENABLE;
UINT32 g_support2bbuMainSlaveFlag = NOT_SUPPORT_2BBU_MAIN_SLAVE; /*此标志为支持双bbu的机型标志*/

static UINT32 s_downOptNormalTime = 0x0;
UINT32 g_ulM0ThreadStartFlag = 0;   /*m0中断处理是否启动的标志 按lane处理*/
UINT32 s_DetectSw = 0;              /* 倒换时间log任务开关标志 */
UINT32 s_detectLogTime = 100;       /* 倒换时间log任务记录间隔，默认100ms */
UINT32 lastStageLogSw = 0;          /* 倒换时间log末级是否记录标志，0末级不记录，1末级记录 */
static UINT32 s_optSpeddListCpri = 0;
UINT32 g_ulCurrOptWorkMode = BSP_OPT_WORK_MODE_CASCADE_NORMAL;
UINT32 g_ulLastOptWorkMode = BSP_OPT_WORK_MODE_CASCADE_NORMAL;
T_UtdoaSuperFrameCfg s_pUtSuperFrameCfg = {0};
static UINT32 s_protocolAdaptCnt = 0;
static UINT32 s_GetRruIdTimes = 0;
static UINT32 s_firstProtocol = PROCOTOL_IR;
static UINT32 s_protocolAdaptTimes = 0;
static UINT32 s_irCascadeCpriFlag = 0;
static UINT32 s_bitmap[BITMAP_MAX_NUM] = {0};
UINT32 g_ulAnotherOptCntStop = 0;   /*增加维测桩，排查下联长时间不建链整体重配之后恢复建链的问题*/
static FUN_SET_BBU_SUPER_FRAMENO pSetBbuSuperFrameNo = NULL;
static FUN_COPY_OUTOFPSYNC_PARA_TO_KO pCopyOutOfPsyncParaToKo = NULL;
static FUN_SWITCH_SLAVE_OPT_ADAPT_STA pSwitchSlaveOptAdaptSta = NULL;
#define RETVAL_CHECK_STSTE(retVal, state)                                        \
    if(retVal == state)                                                          \
    {                                                                            \
        dbgInfoEx("%s: status[%u] is ok! \n", __FUNCTION__, state);              \
        return state;                                                            \
    }

#define RETVAL_CHANGE_OPT_SPEED                                                  \
    if(retVal == BSP_ERROR)                                                      \
    {                                                                            \
        /*底层状态正常RRUID异常认为是异常锁定需要去状态1切速率*/                    \
        BspLog(LOG_LEVEL_0,"%s(%d) RRUID is ERROR！\n", __FUNCTION__,__LINE__);  \
        return OPT_ADPT_TWO_OPT_STATE;                                           \
    }

#define SERDES_MAXTRY_CNT          (100)
#define PHY_OPT_0                  (0)
#define PHY_OPT_1                  (1)
#define OPT_SYNC_OK                (4)
#define TXPRI_ERR_CNT              (10)
#define TXPRI_SEND_MAX_CNT         (20)
#define RX_RETRY_MAX_CNT           (8)
#define UPLINK_OPT_RETRY_MAX_CNT   (5)

static UINT32 BspDetectThreadInit(VOID);
UINT32 DetectLogon(UINT32 time);

/*通知M0不要启动之后需要延迟等MO上一次完成配置(包住M0的配置时间即可)*/
UINT32 BspSetM0ThreadStartFlag(UINT32 flag)
{
	UINT32 retVal = 0;
    UINT32 ringFlag = 0;
    UINT32 coreLoop = 0;
    UINT32 ulM0AckCnt = 100;
    T_M0VerLoadInfo tM0verInfo = {0};
    UINT32 coreFlag = 0;

    ringFlag = BspGetOptRingFlag();
    if(OPT_NOT_SUPPORT_RING == ringFlag || BspGetOptCpriProtocol(0) == PROCOTOL_IR)   /* 非环网和TDD机型不执行此动作 */
    {
        return BSP_OK;
    }
    g_ulM0ThreadStartFlag = flag;
    BspLog(LOG_LEVEL_0, "%s,M0ThreadStartFlag:%d\n", __FUNCTION__, flag);

    retVal = BspGetMainM0VerLoadInfo(&tM0verInfo);
    for(coreLoop = 0; coreLoop < tM0verInfo.coreNum; coreLoop++)
    {
        if(tM0verInfo.coreLoadInfo[coreLoop].ceneType == E_M0_VERSION_UBR)
        {
            coreFlag = 1; /*找到单板初始化加载过M0版本的机型coreFlag写1*/
            break;
        }
    }

    if(coreFlag == 1)
    {
        /*opt接口未防护，单板初始化时未加载M0访问接口MGR异常*/
        BspHalAdaptCtrlM0SerdesRxinit(flag); /* M0serdes接收初始化，传参 1：使能  0：去使能 */

        for(int ulM0AckLoop = 0; ulM0AckLoop < ulM0AckCnt; ulM0AckLoop++)
        {
            BspSysMsDelay(50);
            /*opt接口未防护，单板初始化时未加载M0访问接口MGR异常*/
            if(BSP_OK == BspHalAdaptGetM0SerdesRxinitAck())
            {
                BspLog(LOG_LEVEL_0, "%s,ulM0AckLoop:%d OK\n", __FUNCTION__, ulM0AckLoop);
                return BSP_OK;
            }
        }

        for(coreLoop = 0; coreLoop < tM0verInfo.coreNum; coreLoop++)
        {
            if(tM0verInfo.coreLoadInfo[coreLoop].ceneType == E_M0_VERSION_UBR)
            {
                retVal |= BspHalAdaptLoadM0CoreVersion(tM0verInfo.coreLoadInfo[coreLoop].coreId, tM0verInfo.coreLoadInfo[coreLoop].ceneType);
                BspLog(LOG_LEVEL_0, "%s: coreId=%d ceneType:%d load OK ! \n", __FUNCTION__, tM0verInfo.coreLoadInfo[coreLoop].coreId,tM0verInfo.coreLoadInfo[coreLoop].ceneType);
            }
        }
    }

    g_ulM0ThreadStartFlag = 0;
    BspLog(LOG_LEVEL_0, "%s,loadM0Version %d \n",__FUNCTION__,retVal);

    return BSP_ERROR;
}

/* Started by AICoder, pid:k00c8y3b63ga83114d660aaa902b0e3c626155fe */
UINT32 BspGetM0ThreadStartFlag(VOID)
{
    UINT32 m0Core0Sta = 0;
    UINT32 m0Core1Sta = 0;
    UINT32 m0Core0Ctrl = 0;
    UINT32 m0Core1Ctrl = 0;

    BspHalAdapGetGetM0RunStatus(&m0Core0Sta, &m0Core1Sta, &m0Core0Ctrl, &m0Core1Ctrl);/* 获取M0使能状态 */
    dbgInfoEx("%s,sta:[%d, %d]; ctrl:[%d, %d]\n",__FUNCTION__, m0Core0Sta, m0Core1Sta, m0Core0Ctrl, m0Core1Ctrl);
    if(1 == m0Core0Ctrl && 1 == m0Core1Ctrl)
    {
        g_ulM0ThreadStartFlag = 1; /* M0两个核均使能，将M0使能flag置1 */
    }
    else
    {
        if(g_ulM0ThreadStartFlag == 1)
        {
            BspLog(LOG_LEVEL_0, "%s,g_ulM0ThreadStartFlag change, m0Core0Ctrl:%d, m0Core1Ctrl:%d\n",__FUNCTION__, m0Core0Ctrl, m0Core1Ctrl);
        }
        g_ulM0ThreadStartFlag = 0;
    }

    return g_ulM0ThreadStartFlag;
}
/* Ended by AICoder, pid:k00c8y3b63ga83114d660aaa902b0e3c626155fe */

VOID stopAnotherOptCnt(UINT32 stopEn)
{
    g_ulAnotherOptCntStop = stopEn;
}
/**************************************************************************
 * 函数名称： optadpton/optadptoff
 * 功能描述： 光口速率自适应开关
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 工装使用
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
VOID optadpton(VOID)
{
    g_ulOptCtr = FUNCLIB_OPT_ADPT_ENABLE;
}
VOID optadptoff(VOID)
{
    g_ulOptCtr = FUNCLIB_OPT_ADPT_DISABLE;
    BspSetM0ThreadStartFlag(0);  /*停MO 任务*/
}
VOID qcelloptadpton(VOID)
{
    g_qcellUlOptCtr = FUNCLIB_OPT_ADPT_ENABLE;
}
VOID qcelloptadptoff(VOID)
{
    g_qcellUlOptCtr = FUNCLIB_OPT_ADPT_DISABLE;
}
VOID qsfpon(VOID)
{
    g_ulQsfpCtr = FUNCLIB_OPT_ADPT_ENABLE;
}
VOID qsfpoff(VOID)
{
    g_ulQsfpCtr = FUNCLIB_OPT_ADPT_DISABLE;
}

VOID cfgtxPriorityon(VOID)
{
    g_cfgPriorityCtr = FUNCLIB_OPT_ADPT_ENABLE;
}

VOID cfgtxPriorityoff(VOID)
{
    g_cfgPriorityCtr = FUNCLIB_OPT_ADPT_DISABLE;
}
VOID setringOptSwitch(UINT32 flag)
{
    g_ringOptSwitch = flag;
}

/*解决optctrl\powerctrl 互相调用问题*/
VOID BspClearCarrGainCallBackInit(FUN_CLEAR_CARR_GAIN pClearGain)
{
    pClearCarrGain = pClearGain;
}

/* 设置QCELL是否需要配置10G速率的标志 */
VOID BspQcellSetNeed10gFlag(UINT32 flag)
{
    g_qcellNeed10G = flag;
}

UINT32 BspQcellGetNeed10gFlag(VOID)
{
    return g_qcellNeed10G;
}

/*双光口是否都是不在位或者无光*/
UINT32 IsAllOptLop(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckPhyOptIsLop);

    if ((BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(PHY_OPT_0))) && \
        (BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(PHY_OPT_1))))
    {
        MSG_ERR(MOD_BOARD_OPT,"[Both opt]detect no exit\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*双光口是否都有光*/
UINT32 IsNoneOptLop(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckPhyOptIsLop);

    if ((BSP_OK == (pInfo->pFuncCheckPhyOptIsLop(PHY_OPT_0))) && \
        (BSP_OK == (pInfo->pFuncCheckPhyOptIsLop(PHY_OPT_1))))
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

/*是否两个物理口都有物理告警 状态异常*/
UINT32 IsAllPhyOptStaError(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckPhyOptState);

    if ((BSP_OK != (pInfo->pFuncCheckPhyOptState(PHY_OPT_0))) && \
        (BSP_OK != (pInfo->pFuncCheckPhyOptState(PHY_OPT_1))))
    {
        MSG_ERR(MOD_BOARD_OPT,"[Both opt]PhyOptState error\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*是否两个物理口都无物理告警*/
UINT32 IsAllPhyOptStaOk(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckPhyOptState);
    if ((BSP_OK == (pInfo->pFuncCheckPhyOptState(PHY_OPT_0))) && \
        (BSP_OK == (pInfo->pFuncCheckPhyOptState(PHY_OPT_1))))
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

/*是否两个逻辑口都有告警*/
UINT32 IsAllLogOptStaError(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 mainPhyOptNo = 0;
    UINT32 logOptNo0 = 0;
    UINT32 logOptNo1 = 0;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckLogicOptState);

    BspHalAdaptGetMainPhyOpt(&mainPhyOptNo);
    INPUT_PHYOPT_INDEX_CHECK(mainPhyOptNo);
    logOptNo0 = BspHalAdaptGetLogOpt(PHY_OPT_0);
    logOptNo1 = BspHalAdaptGetLogOpt(PHY_OPT_1);

    if ((BSP_OK != (pInfo->pFuncCheckLogicOptState(logOptNo0))) && \
        (BSP_OK != (pInfo->pFuncCheckLogicOptState(logOptNo1))))
    {
        MSG_ERR(MOD_BOARD_OPT,"[Both opt]LogicOptState error\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}
/*是否两个逻辑口都无告警*/
UINT32 IsAllLogOptStaOk(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 mainPhyOptNo = 0;
    UINT32 logOptNo0 = 0;
    UINT32 logOptNo1 = 0;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckLogicOptState);

    BspHalAdaptGetMainPhyOpt(&mainPhyOptNo);
    INPUT_PHYOPT_INDEX_CHECK(mainPhyOptNo);

    logOptNo0 = BspHalAdaptGetLogOpt(PHY_OPT_0);
    logOptNo1 = BspHalAdaptGetLogOpt(PHY_OPT_1);

    if ((BSP_OK == (pInfo->pFuncCheckLogicOptState(logOptNo0))) && \
        (BSP_OK == (pInfo->pFuncCheckLogicOptState(logOptNo1))))
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}

UINT32 IsAllOptStaErr(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckPhyOptState);
    /* 检查在位光口同步状态 */
    if(BSP_ERROR == IsAllPhyOptStaError())
    {
        return BSP_OK;
    }
    else if ((BSP_OK !=  pInfo->pFuncCheckLogicOptState(0))
        && (BSP_OK !=  pInfo->pFuncCheckLogicOptState(1))) /*IsAllLogOptStaError 和原代码不等价*/
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}


/* 找不到一个告警状态（除了pcs）正常的上联口*/
UINT32 IsAllOptStaErrNew(VOID)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckLogicOptState);

    if ((BSP_OK != BspCheckPhyOptStateNew(0)) && \
        (BSP_OK != BspCheckPhyOptStateNew(1)))  /*两个物理口都异常 是否两个物理口都有物理告警 状态异常 把pcs检测拆出来了*/
    {
        return BSP_ERROR;
    }
    if ((BSP_OK !=  pInfo->pFuncCheckLogicOptState(0))  /*两个逻辑口都异常*/
        && (BSP_OK !=  pInfo->pFuncCheckLogicOptState(1)))
    {
        return BSP_ERROR;
    }
    else
    {
        return BSP_OK;
    }
}

/*切换光口速率之后 检查是否一个光口正常  找上联口 原始延时的1s不变 如果pcs正常代表速率匹配，如果还有告警多延迟等待 避免反复切速率*/
UINT32 checkAllOptSta(VOID)
{
    UINT32 loop = 0;
    UINT32 maxTry = 8;   /*最多尝试8次 1.2s*/

    for(loop = 0; loop < maxTry; loop++)
    {
        if((BSP_OK == BspGetOptPcsAlmSta(0))||(BSP_OK == BspGetOptPcsAlmSta(1)))  /*有一个正常就不用判断另一个*/
        {
            if(BSP_ERROR == IsAllOptStaErrNew())
            {
                BspLog(LOG_LEVEL_0,"%s,loop %d\n",__FUNCTION__,loop);
                dbgInfo("%s,loop %d\n",__FUNCTION__,loop);
                BspSysMsDelay(150);
                continue;
            }
            else
            {
                return BSP_OK;   /*至少有一个口 逻辑和物理都正常*/
            }
        }
        else
        {
            return BSP_ERROR;  /*两个光口pcs都不正常，说明上联口速率不匹配 直接去切速率*/
        }
    }

    return BSP_ERROR;
}
/*判断是否为未配置的RRU RANGE*/
UINT32 IsNoConfigRruIdRange(void)
{
    UINT32 direction      = 0;
    UINT32 rruIdRange     = 0;
    UINT32 rruId = 0;
    UINT32 logNo = 0;
    /* Started by AICoder, pid:q8d3bd1956cc7d81449c082fa03f14191420c378 */
    if(PROCOTOL_CPRI == BspGetOptCpriProtocol(0))
    {
         (VOID)BspHalAdaptGetMainLogicOpt(&logNo);   /*当前逻辑主光口*/
         rruId = BspHalAdaptGetCpriRruId(logNo);
         dbgInfoEx("%s(%d): logNo%d rruId%d\n", __FUNCTION__,__LINE__,logNo,rruId);
         if((rruId >= 200)&&(rruId <= 211))
         {
              return BSP_OK;  /*无配置光口  注意针对无配置光口如果不开自发现 下发的也是255这种值*/
         }
         return BSP_ERROR;    /*不用再切速率*/
    }
    /* Ended by AICoder, pid:q8d3bd1956cc7d81449c082fa03f14191420c378 */
    rruIdRange = BspGetRruIdRange(0);
    BspHalAdaptCpriGetRruDirection(&direction);
   /*BspLog(LOG_LEVEL_0,"%s(%d): dir%d RruIdRange%d\n", __FUNCTION__,__LINE__,direction,rruIdRange);*/
    dbgInfoEx("%s(%d): dir%d RruIdRange%d\n", __FUNCTION__,__LINE__,direction,rruIdRange);
    if(((rruIdRange & 0xf) ==  0xf) && (direction == 0))/*只有正向且RRURANGE为0xf情况下未BBU未配置*/
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}

UINT32 IsRruIdRangeOK(VOID)
{
    if (pSwitchSlaveOptAdaptSta != NULL)
    {
        return BSP_OK;
    }

    if (s_CheckRruIdRange) /*处理单上联接双光纤场景*/
    {
        if(BspCheckAllOptRruId() == BSP_ERROR)
        {
            return BSP_ERROR;
        }
        if (IsNoConfigRruIdRange() ==  BSP_ERROR) /*识别到有配置光口 或者识别不到*/
        {
            /*有一个光口物理和逻辑都没告警，则转到单光口自适应*/
            return BSP_OK;
        }
        else if (IsNoneOptLop() != BSP_OK) /*识别到未配置光口，单光口都在位，不切速率*/
        {
            return BSP_OK;
        }
        else if(g_ulUpLinkOptSpeedCfgCnt > UPLINK_OPT_RETRY_MAX_CNT)
        {
            return BSP_OK;
        }
        else
        {
            g_ulUpLinkOptSpeedCfgCnt++;   /*至少有一个口没告警 且BspGetRruIdRange 为0xf 未配置光口 且不是单光口 计数用于多次循环找不到有配置光口 认为对端没接有配置光口*/
            BspLog(LOG_LEVEL_0,"%s: g_ulUpLinkOptSpeedCfgCnt%d\n", __FUNCTION__, g_ulUpLinkOptSpeedCfgCnt);
            dbgInfo("%s: g_ulUpLinkOptSpeedCfgCnt%d\n", __FUNCTION__, g_ulUpLinkOptSpeedCfgCnt);
            return BSP_ERROR;
        }
    }
    else
    {
        return BSP_OK;
    }
}

UINT32 IsOptTxPriorityOK(VOID)
{
    UINT32 ulTxPriorityLoop = 0;
    UINT32 ulTxPriorityCnt = 5;  /* 异速率判断环网光口无告警但控制字无效循环n次后切光口速率 */
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckPhyOptState);
    if (BspGetOptCpriProtocol(0) == PROCOTOL_CPRI) /*处理FDD环网光口无告警，但控制字无效场景*/
    {
        for(ulTxPriorityLoop = 0; ulTxPriorityLoop < ulTxPriorityCnt; ulTxPriorityLoop++)
        {
            if(((BSP_OK ==  pInfo->pFuncCheckPhyOptState(PHY_OPT_0)) && (BSP_OK == BspGetOptTxPriorityStatus(PHY_OPT_0))) \
                || ((BSP_OK ==  pInfo->pFuncCheckPhyOptState(PHY_OPT_1)) && (BSP_OK == BspGetOptTxPriorityStatus(PHY_OPT_1))))
            {
                return BSP_OK;
            }
            MSG_DBG(MOD_BOARD_OPT, "ulTxPriorityLoop %d \n", ulTxPriorityLoop);
            BspLog(LOG_LEVEL_0, "ulTxPriorityLoop %d \n", ulTxPriorityLoop);
            pInfo->pFuncDelayMs(10);
        }
        return BSP_ERROR;
    }
    else
    {
        return BSP_OK;
    }
}

UINT32 IsRruIdAndPriorityOK(VOID)
{
    if ((BSP_OK == IsRruIdRangeOK()) && (BSP_OK == IsOptTxPriorityOK())) /*处理单上联接双光纤场景 和 异速率环网光口无告警但控制字无效场景*/
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}


/*****************************************************************************
 *  函数名称   : BspGetOptSpeedSetFlag
 *  功能描述   : 根据速率查询掩码位
 *----------------------------------------------------------------------------
 */
UINT32 BspGetOptSpeedSetFlag(UINT32 ulPhyOpt)
{
    return g_ulAnotherOptSetSpeedFlag[ulPhyOpt];
}

UINT32 BspSetSwitchMainPhyOptFlag(UINT32 ulFlag)
{
    UINT32 optWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);

    if(PROCOTOL_CPRI == BspGetOptCpriProtocol(0))
    {
        s_SwitchMainPhyOptFlag = ulFlag;
    }
    else if(((1 == BspGetTddSupportRingModeWorkFlag()) && (BSP_OPT_WORK_MODE_RING == optWorkMode)) || (BSP_OPT_WORK_MODE_MAIN_SLAVE == optWorkMode)|| (BSP_OPT_WORK_MODE_SHARE == optWorkMode))
    {
        s_SwitchMainPhyOptFlag = ulFlag;
    }

    return BSP_OK;
}

UINT32 BspGetSwitchMainPhyOptFlag(VOID)
{
    UINT32 tmp = 0;

    tmp = s_SwitchMainPhyOptFlag;
    if((PROCOTOL_CPRI == BspGetOptCpriProtocol(0))&&(1 == s_SwitchMainPhyOptFlag))
    {
        s_SwitchMainPhyOptFlag = 0;   /*FDD上报之后清0*/
    }
    return tmp;
}

UINT32 BspSetSwitchoverFlag(UINT32 flag)
{
    g_SwitchoverFlag = flag;
    return BSP_OK;
}
/* Started by AICoder, pid:n3ecflcfc6uec4214277097b401c1b1d877204fc */
/*判断光口是否已完成停了自适应*/
UINT32 BspGetOptAdptStatus(VOID)
{
    UINT32 ringFlag = OPT_NOT_SUPPORT_RING;
    UINT32 retVal = FUNCLIB_OPT_ADPT_ENABLE;

    ringFlag = BspGetOptRingFlag();
    if(ringFlag == OPT_NOT_SUPPORT_RING)
    {
        if(g_ulOptStatus == FUNCLIB_OPT_ADPT_DISABLE)
        {
            retVal = FUNCLIB_OPT_ADPT_DISABLE;
        }
    }
    else
    {
        if((g_ringOptSwitch == FUNCLIB_OPT_ADPT_DISABLE) && (g_ulOptStatus == FUNCLIB_OPT_ADPT_DISABLE))
        {
            retVal = FUNCLIB_OPT_ADPT_DISABLE;
        }
    }

    return retVal;
}

UINT32 BspOptSupportLoopTest(UINT32 optId, UINT32 *pSupportFlag)
{
    UINT32 ulOptPpoint = 0xff;
    UINT32 protocol = PROCOTOL_CPRI;

    INPUT_POINTER_CHECK(pSupportFlag);
    *pSupportFlag = 1;

    protocol = BspGetOptCpriProtocol(0);
    if(protocol == PROCOTOL_IR)
    {
        if(BSP_OK == BspHalAdaptCpriGetRxPPoint(&ulOptPpoint))
        {
            if(ulOptPpoint == 0)
            {
                *pSupportFlag = 0;
            }
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:n3ecflcfc6uec4214277097b401c1b1d877204fc */
UINT32 BspGetSwitchoverFlag(UINT32 *flag)
{
    INPUT_POINTER_CHECK(flag);

    *flag = g_SwitchoverFlag;
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetOptSpeedMaskBit
 *  功能描述   : 根据速率查询掩码位
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulOptSpd-查询速率
 *  输出参数   : 查询掩码
 *  返 回 值   :
 *  其它说明   :BSP可以1~6G逐次排列，可以与上报速率格式定义不同
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 2017/04/22    V1.1     10076963          修改
 *----------------------------------------------------------------------------
 */
UINT32 BspGetOptSpeedMaskBit(UINT32 ulOptSpd)
{
    UINT32 ulSpeedMaskBit = 0;
    UINT32 ulLoop = 0;

    for(ulLoop = 0; ulLoop < sizeof(OptSpeedLsit); ulLoop++)
    {
        if(OptSpeedLsit[ulLoop] == ulOptSpd)
        {
            MSG_DBG(MOD_BOARD_OPT, "loop = %d, spd = %d\n", ulLoop, ulOptSpd);
            ulSpeedMaskBit = OptSpeedLsit[ulLoop]-1;
            break;
        }
    }

    if(ulLoop == sizeof(OptSpeedLsit))
    {
        MSG_ERR(MOD_BOARD_OPT, "default spd = %d\n", BSP_OPT_SPEED_9P8304G);
        ulSpeedMaskBit = BSP_OPT_SPEED_9P8304G -1;
    }
    return ulSpeedMaskBit;
}
/*****************************************************************************
 *  函数名称   : BspGetOptSpeedByMaskBit
 *  功能描述   : 根据掩码位查询对应速率
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulSpeedMaskBit-查询掩码
 *  输出参数   : 对应速率
 *  返 回 值   :
 *  其它说明   :BSP可以1~6G逐次排列，可以与上报速率格式定义不同
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetOptSpeedByMaskBit(UINT32 ulSpeedMaskBit)
{
    UINT32 ulOptSpd = 0;
    UINT32 ulLoop = 0;
    for(ulLoop = 0; ulLoop < sizeof(OptSpeedLsit); ulLoop++)
    {
        if(ulSpeedMaskBit == (OptSpeedLsit[ulLoop] - 1))
        {
            ulOptSpd = OptSpeedLsit[ulLoop];
            MSG_DBG(MOD_BOARD_OPT, "loop = %d, spd = %d\n", ulLoop, ulOptSpd);
            break;
        }
    }
    
    if(ulLoop == sizeof(OptSpeedLsit))
    {
        MSG_ERR(MOD_BOARD_OPT, "default spd = %d\n", BSP_OPT_SPEED_9P8304G);
        ulOptSpd = BSP_OPT_SPEED_9P8304G;
    }    
    return ulOptSpd;
}
/*cpri线速率转serdes线速率*/
UINT32 BspGetSerdesRateByCpriRate(UINT32 ulSpd)
{
    UINT32 ulSerdesLaneRate  = SERDES_RATE_24G33;

    switch(ulSpd)
    {
        case BSP_OPT_SPEED_9P8304G:
        {
            ulSerdesLaneRate = SERDES_RATE_9G83;
            break;
        }
        case BSP_OPT_SPEED_10P1376G:
        {
           ulSerdesLaneRate = SERDES_RATE_10G13;
            break;
        }
        case BSP_OPT_SPEED_24P33024G:
        {
            ulSerdesLaneRate = SERDES_RATE_24G33;
            break;
        }
        default:
        {
            ulSerdesLaneRate = SERDES_RATE_24G33;
            break;
        }
    }
    return ulSerdesLaneRate;
}

ULONG _BspSingleOptAdptCheck(void)
{
    ULONG ulPhyOpt = 0;
    ULONG ulLogOpt = 0;
    ULONG ulCnt0 = 0;
    ULONG ulCnt1 = 0;
    ULONG ulLoop = 0;
    ULONG ulMainSpd = 0;
    UINT32 ulSupportFlag = 0;
    UINT32 ulPastMode = 0;

    MSG_DBG(MOD_BOARD_OPT, "%s enter\n", __FUNCTION__);
    (VOID)BspHalAdaptGetMainPhyOpt(&ulPhyOpt);
    if (BSP_ERROR == ulPhyOpt)
    {
        MSG_ERR(MOD_BOARD_OPT, "%s Get MainPhyOpt failed\n", __FUNCTION__);
        return OPT_ADPT_PRE_TWO_OPT_STATE;
   }
    BspHalAdaptGetMainLogicOpt(&ulLogOpt);
    if (BSP_OK != g_tOptAutoAdaptInfo.pFuncCheckLogicOptState(ulLogOpt))
    {
        MSG_ERR(MOD_BOARD_OPT, "%s Check MainLogOpt failed\n", __FUNCTION__);
        return OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    ulCnt0 = BspHalAdaptGetCpriFsmJumpCnt(ulPhyOpt);   /*serdes 异常时不累加 判断不准确*/
    for(ulLoop = 0;ulLoop < 5 ;ulLoop ++)
    {
        BspSysMsDelay(100);
        ulCnt1 = BspHalAdaptGetCpriFsmJumpCnt(ulPhyOpt);
        dbgInfoEx("ulPhyOpt %d ulCnt1 %d\n",ulPhyOpt,ulCnt1);
    }
    if(ulCnt1 != ulCnt0)
    {
        MSG_ERR(MOD_BOARD_OPT, "%s CpriFsm Jump\n", __FUNCTION__);
        return OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    BspHalAdaptSetCrmOptCrpiRefClkLogic();
    BspHalAdaptCpriGetLineRate(ulPhyOpt,&ulMainSpd);
    ulSupportFlag = BspGetLimitTransferSupportFlag();
    if (LIMIT_TRANSFER_SUPPORT_YES == ulSupportFlag)
    {
        ulPastMode = BspGetLimitTransferMode();
        if (LIMIT_TRANSFER_MODE_EXTEND == ulPastMode)
        {
            BspHalAdaptAxcArrangeTypeByBspRate(ulPhyOpt,ulMainSpd, MODE_EXTREME_EXTEND);
        }
        else
        {
            BspHalAdaptAxcArrangeTypeByBspRate(ulPhyOpt,ulMainSpd, MODE_NORMAL);
        }
    }
    else
    {
        BspHalAdaptAxcArrangeTypeByBspRate(ulPhyOpt,ulMainSpd, MODE_NORMAL);
    }

    return OPT_ADPT_STATE_OK;
}

UINT32 BspJudgeDownlinkOptSpeed(UINT32 ulAppSpd, UINT32 ulSlaveSpd, UINT32 ulMainSpd)
{
    UINT32 ulRet = BSP_OK;

    if(ulAppSpd == 0) /*TDD 不会下此参数，FDD 会下发，在未下发之前默认值是0*/
    {
        if (PROCOTOL_CPRI != BspGetOptCpriProtocol(0))
        {
            /*此时必须要同速率，防止的是测试插拔光纤导致两个光口的速率配置有差异 下联口和下一级刚好又适配上了  会导致速率不符合配置预期*/
            if(ulSlaveSpd != ulMainSpd)
            {
                ulRet =  BSP_ERROR;
            }
        }
    }
    else
    {
        if(ulAppSpd != ulSlaveSpd)  /*对FDD 机型而言，建链之后必现要和高层下发的速率保持一致*/
        {
            ulRet =  BSP_ERROR;
        }
    }

    return ulRet;
}

ULONG _BspDoubleOptAdptCheck(void)  /*这个后续再扩展系列接口，现在只针对级联设计*/
{
    ULONG ulMainPhyOpt = 0;
    ULONG ulSlavePhyOpt = 0;
    ULONG ulMainLogOpt = 0;
    ULONG ulSlaveLogOpt = 0;
    ULONG ulCnt0 = 0;
    ULONG ulCnt1 = 0;
    ULONG ulLoop = 0;
    ULONG ulJumpSta = 0;
    ULONG ulOptLoop = 0;
    UINT32 ulSlaveSpd = 0;
    UINT32 ulMainSpd = 0;
    UINT32 mainAppSpd = 0;
    UINT32 ulAppSpd = 0;
    UINT32 ulSupportFlag = 0;
    UINT32 ulPastMode = 0;
    UINT32 ulMaxCnt = 3;  /*状态机跳转读数次数*/

    MSG_DBG(MOD_BOARD_OPT, "%s enter\n", __FUNCTION__);
    (VOID)BspHalAdaptGetMainPhyOpt(&ulMainPhyOpt);
    if (BSP_ERROR == ulMainPhyOpt)
    {
        MSG_ERR(MOD_BOARD_OPT, "%s Get MainPhyOpt failed\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s Get MainPhyOpt failed\n", __FUNCTION__);
        return OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    ulSlavePhyOpt = 1- ulMainPhyOpt;

    if( RRU_BBU == BspGetPbOrBbuMode() )
    {
        return _BspSingleOptAdptCheck();
    }

    if(BSP_OK != g_tOptAutoAdaptInfo.pFuncCheckPhyOptIsLop(ulSlavePhyOpt))
    {  /*但是下一级没接RRU 采用单光口判断*/
    	 return _BspSingleOptAdptCheck();
    }
    ulMainLogOpt = BspHalAdaptGetLogOpt(ulMainPhyOpt);
    ulSlaveLogOpt = BspHalAdaptGetLogOpt(ulSlavePhyOpt);
    dbgInfoEx("ulMainLogOpt %d ulSlaveLogOpt %d\n",ulMainPhyOpt,ulSlaveLogOpt);
/*    BspLog(LOG_LEVEL_0,"ulMainLogOpt %d ulSlaveLogOpt %d\n",ulMainPhyOpt,ulSlaveLogOpt);*/
    BspHalAdaptCpriGetLineRate(ulSlavePhyOpt,&ulSlaveSpd);
    BspHalAdaptCpriGetLineRate(ulMainPhyOpt,&ulMainSpd);
    mainAppSpd = BspLoadOptSpeedFromApp(ulMainPhyOpt);
    ulAppSpd = BspLoadOptSpeedFromApp(ulSlavePhyOpt);
    BspJudgeOptSpeed(mainAppSpd, ulAppSpd);
    dbgInfoEx("ulMainSpd %d ulSlaveSpd %d ulAppSpd %d\n",ulMainSpd,ulSlaveSpd,ulAppSpd);
/*    BspLog(LOG_LEVEL_0,"ulMainSpd %d ulSlaveSpd %d ulAppSpd %d\n",ulMainSpd,ulSlaveSpd,ulAppSpd);*/
    if (BSP_OK != g_tOptAutoAdaptInfo.pFuncCheckPhyOptState(ulMainPhyOpt))
    {
        MSG_ERR(MOD_BOARD_OPT, "%s ulMainPhyOpt %d state invalid\n", __FUNCTION__,ulMainPhyOpt);
        BspLog(LOG_LEVEL_0,"%s ulMainPhyOpt %d state invalid\n", __FUNCTION__,ulMainPhyOpt);
        return OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    if (BSP_OK != g_tOptAutoAdaptInfo.pFuncCheckPhyOptState(ulSlavePhyOpt))
    {
        MSG_ERR(MOD_BOARD_OPT, "%s ulSlavePhyOpt %d state invalid\n", __FUNCTION__,ulSlavePhyOpt);
        BspLog(LOG_LEVEL_0,"%s ulSlavePhyOpt %d state invalid\n", __FUNCTION__,ulSlavePhyOpt);
        return OPT_ADPT_PRE_ONE_OPT_STATE;
    }

    for(ulOptLoop = 0; ulOptLoop < OPTMAXNUM; ulOptLoop++)
    {
        ulCnt0 = 0;
        ulCnt1 = 0;
        ulCnt0 = BspHalAdaptGetCpriFsmJumpCnt(ulOptLoop);   /*serdes 异常时不累加 判断不准确*/
        for(ulLoop = 0;ulLoop < ulMaxCnt ;ulLoop ++)
        {
            BspSysMsDelay(100);
            ulCnt1 = BspHalAdaptGetCpriFsmJumpCnt(ulOptLoop);
        }
        dbgInfoEx("ulPhyOpt %d ulCnt1 %d\n",ulOptLoop,ulCnt1);
        if(ulCnt1 != ulCnt0)
        {
            ulJumpSta = ulJumpSta& BIT_SET(ulOptLoop);
        }
    }
    MSG_DBG(MOD_BOARD_OPT, "opt ulJumpSta 0x%x\n", ulJumpSta);
    if(ulJumpSta == 3)
    {
        return OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    else if(ulJumpSta == 1 || ulJumpSta == 2 )
    {
        return OPT_ADPT_PRE_ONE_OPT_STATE;
    }
    else
    {
        BspHalAdaptSetCrmOptCrpiRefClkLogic(); /*遇到过 恢复钟关闭但是能从bbu登录*/
        if(ulSlaveSpd != ulMainSpd) /*异速率级联*/
        {
            BspHalAdaptCpriCfgTulFixedValue(0x25F);
            BspHalAdaptCpriCfgUlNetTrasBypass(ulMainLogOpt,1);  /*异速率级联 同速率切换 IQ转发的模式需要对应切换*/
            BspHalAdaptCpriCfgUlNetTrasBypass(ulSlaveLogOpt,1);
            BspHalAdaptCpriCfgDlNetTrasBypass(ulMainLogOpt,1);
            BspHalAdaptCpriCfgDlNetTrasBypass(ulSlaveLogOpt,1);
            BspHalAdaptCpriUlFrameAlignFrSel(ulSlaveLogOpt,1);
        }
        else
        {
            BspHalAdaptCpriCfgTulFixedValue(0x5);
            BspSetCpriCfgNetTrasMode(ulMainLogOpt,0);
            BspSetCpriCfgNetTrasMode(ulSlaveLogOpt,0);
            BspSetCpriUlFrameAlignFrSelByMode(ulSlaveLogOpt,2);
        }

        if(BSP_ERROR == BspJudgeDownlinkOptSpeed(ulAppSpd, ulSlaveSpd, ulMainSpd))  /*(1)运行过程中异速率级联且 下联口速率不符合预期，说明速率有改变  (2)放在最后是因为第一级软复位起来的话 也会异速率*/
        {
            return OPT_ADPT_ONE_OPT_STATE;  /*直接到有配置动作的地方 否则不会触发自适应  一直在空转最后到ok态循环*/
        }
        /*光口状态正常后配置光口cpri线速率给光口 光口自适应里配置的时候 可能逻辑主光口没识别出来报错  后边建链又不重配了*/
        ulSupportFlag = BspGetLimitTransferSupportFlag();
        if (LIMIT_TRANSFER_SUPPORT_YES == ulSupportFlag)
        {
            ulPastMode = BspGetLimitTransferMode();
            if (LIMIT_TRANSFER_MODE_EXTEND == ulPastMode)
            {
                BspHalAdaptAxcArrangeTypeByBspRate(ulMainPhyOpt,ulMainSpd,MODE_EXTREME_EXTEND);
                BspHalAdaptAxcArrangeTypeByBspRate(ulSlavePhyOpt,ulSlaveSpd,MODE_EXTREME_EXTEND);
            }
            else
            {
                BspHalAdaptAxcArrangeTypeByBspRate(ulMainPhyOpt,ulMainSpd,MODE_NORMAL);
                BspHalAdaptAxcArrangeTypeByBspRate(ulSlavePhyOpt,ulSlaveSpd,MODE_NORMAL);
            }
        }
        else
        {
            BspHalAdaptAxcArrangeTypeByBspRate(ulMainPhyOpt,ulMainSpd,MODE_NORMAL);
            BspHalAdaptAxcArrangeTypeByBspRate(ulSlavePhyOpt,ulSlaveSpd,MODE_NORMAL);
        }

        return OPT_ADPT_STATE_OK;
    }
}

UINT32 BspOptAdptCheckByWorkMode(UINT32 ulOptWorkMode)
{
    UINT32 ulFiniteState = 0;

    if(ulOptWorkMode == BSP_OPT_WORK_MODE_RING_CHAIN)
    {
        ulFiniteState =  _BspSingleOptAdptCheck();
    }
    else if((ulOptWorkMode == BSP_OPT_WORK_MODE_RING) || (BSP_OPT_WORK_MODE_MAIN_SLAVE == ulOptWorkMode))
    {
        ulFiniteState = BspRingNetWorkCheck();
    }
    else
    {
        if(BSP_OK != BspCheckAllOptRruId() && pSwitchSlaveOptAdaptSta == NULL)    /*所有光口的ruid 都是0 254 255 则直接跳到OPT_ADPT_PRE_TWO_OPT_STATE 这里存在告警正常 主光口正常 但是rruid异常场景*/
        {   /*9264M7290级联频配置，一端接有配置一端接无配置，整机重启后先和有配置光口建链0--1--2--3--4  主光口抖动直接又切成双上联倒换到无配置口 无法恢复*/
            return OPT_ADPT_PRE_TWO_OPT_STATE;
        }
        ulFiniteState = _BspDoubleOptAdptCheck();
    }

    return ulFiniteState;
}

/**************************************************************************
 * 函数名称： _BspOptAdptCheck
 * 功能描述： 光口状态检查
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 状态值
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
ULONG _BspOptAdptCheck(void)
{
    ULONG ulOptWorkMode = 0;
    ulOptWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);
    ULONG ulFiniteState = 0;
    CHAR devNameStr[] = "PllSys";
    BspSetBbuPortSpecialCtrl();
    if( BSP_ERROR == BspCheckPllStatus((uintptr_t)devNameStr) )
    {
    	BspHalAdaptSetCrmOptCrpiRefClkLogic(); /*qcell遇到 光口是好的 恢复钟是关闭的问题*/
        MSG_ERR(MOD_BOARD_OPT, "PllSys unLocked \n");
        if(BSP_OK != BspIsRingOptWorkMode())
        {
            return OPT_ADPT_PRE_TWO_OPT_STATE;    /*主时钟失锁直接跳转到pre-two  环网需要特殊处理，防止不必要的状态跳转 影响倒换时间*/
        }
    }

    ulFiniteState = BspOptAdptCheckByWorkMode(ulOptWorkMode);

    return ulFiniteState;
}

ULONG BspOptAdptCheck(VOID)
{
    return _BspOptAdptCheck();
}

/*单上联接双光纤场景支持注册*/
VOID BspRegisterCheckRruIdRangeCallBack(FUNC_CHECK_RRUIDRANGE pFunc)
{
    s_CheckRruIdRange = pFunc;
}

UINT32 BspCheckRruIdIsOk(void)
{
    UINT32 retVal         = BSP_OK;
    UINT32 MainRruId      = 0;
    UINT32 slaveRruId     = 0;
    UINT32 mainFiberPort  = 0;
    UINT32 slaveFiberPort = 1;
    UINT32 direction      = 0;
    UINT32 rruIdRange     = 0;
    UINT32 sfpNo = 0;

    MainRruId = BspGetRruId(mainFiberPort);
    slaveRruId = BspGetRruId(slaveFiberPort);

    if(((MainRruId > 0) && (MainRruId < 254)) || ((slaveRruId > 0) && (slaveRruId < 254)))
    {
        BspHalAdaptGetMainPhyOpt(&mainFiberPort);
        sfpNo = BspGetSfpNoByPhyNo(mainFiberPort);
        if(sfpNo >= OPTMAXNUM)
        {
            return BSP_ERROR;
        }
        MainRruId = BspGetRruId(sfpNo);
        retVal |= BspHalAdaptCpriGetRruDirection(&direction);
        rruIdRange = BspGetRruIdRange(0);

        BspLog(LOG_LEVEL_0,"%s: mainFiberPort[%d], slaveFiberPort[%d], sfpNo[%d], MainRruId[%d], slaveRruId[%d], direction[%d], rruIdRange[%d]. \n",
                __FUNCTION__, mainFiberPort, slaveFiberPort, sfpNo, MainRruId, slaveRruId, direction, rruIdRange);

        if((direction == 0) && (rruIdRange >= MainRruId))
        {
            return retVal;
        }
        else if((direction == 1) && (rruIdRange <= MainRruId))
        {
            return retVal;
        }
    }

    BspLog(LOG_LEVEL_0,"%s: mainFiberPort[%d], slaveFiberPort[%d], sfpNo[%d], MainRruId[%d], slaveRruId[%d], direction[%d], rruIdRange[%d]. \n",
            __FUNCTION__, mainFiberPort, slaveFiberPort, sfpNo, MainRruId, slaveRruId, direction, rruIdRange);
    return BSP_ERROR;
}

ULONG BspRingNetWorkCheck(void)
{
    if(BspCheckRruIdIsOk() == BSP_OK)
    {
        return _BspDoubleOptAdptCheck();
    }

    return OPT_ADPT_PRE_TWO_OPT_STATE;
}

static UINT32 BspGetTddRingFromFdd(void)
{
    UINT32 ulRingFlag = 0;

    ulRingFlag = BspGetOptRingFlag();
    if((ulRingFlag == OPT_SUPPORT_RING) && (BspGetTddSupportRingModeWorkFlag() == 0))
    {
        return BSP_OK;  /*条件成立认为是支持FDD环网机型*/
    }

    return BSP_ERROR; /*支持TDD环网机型*/
}

static UINT32 BspCheckPhyRruIdIsOk(UINT32 phyOpt)
{
    UINT32 rruId = 0;

#ifdef _BSP_WITH_WFS
    /*工装测试光口锁定时BBU光口协议默认是CPRI，IR协议机型获取不到RRUID*/
    return BSP_OK;
#endif

    rruId = BspGetRruId(phyOpt);
    if((rruId == 0) || (rruId > 253))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspCheckAllOptRruId(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 optNum = BspGetOptNum();
    UINT32 loop = 0;

    for(loop = 0; loop < optNum; loop ++)
    {
        retVal = BspCheckPhyRruIdIsOk(loop);
        if(retVal == BSP_OK)
        {
            break;/*有一个rruid正常即认为正常*/
        }
    }

    return retVal;
}

ULONG _BspOptAdptPreTwo(void)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 ulOptFrModeEn = 0;
    UINT32 retVal = BSP_OK;
    ulOptFrModeEn = BspGetOptFrTestModeEn();

    /*两个光口OPT0,OPT1光模块都不在位或者有LOP告警（这里读取的是cpri光口状态告警），跳转到状态机--双光口速率自适应pre接口*/
    if (BSP_ERROR == IsAllOptLop())
    {
        MSG_DBG(MOD_BOARD_OPT, "[Both opt]detect no exit\n");
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }

    /* OPT0,OPT1 光口都出现告警(这里检测的是物理光口告警事件记录)则进行速率切换配置，只要有一个光口正常或则进入状态机-单光口自适应接口中 */
    if ((BSP_OK == pInfo->pFuncCheckPhyOptState(0)) || \
         (BSP_OK == pInfo->pFuncCheckPhyOptState(1)))
    {
        retVal = BspCheckAllOptRruId();
        RETVAL_CHANGE_OPT_SPEED

     /*增加时钟判断的目的在于 环网时上一次的主光口可能没有告警，但是本次预期的主光口有告警，需要进pretwo 将rx配置起来 避免不必要的跳转*/
     /*级联这里不做要求是因为现象不一样，此步只需要保证告警正常即可 防止出现没告警，但是主光口还没识别出来 走了重配流程*/
        if((BSP_OK == BspIsRingOptWorkMode())||(BspGetTddRingFromFdd() == BSP_OK)||(OPT_FR_TESTMODE_ON == ulOptFrModeEn))
        {
            if(BSP_ERROR != BspGetMainPhyOpt())
            {
                return OPT_ADPT_POST_TWO_OPT_STATE;
            }
        }
        else
        {
            if (s_CheckRruIdRange) /*处理单上联接双光纤场景*/
            {
                BspLog(LOG_LEVEL_0,"%s(%d)\n", __FUNCTION__,__LINE__);
                dbgInfo("%s(%d)\n", __FUNCTION__,__LINE__);
                /*如果是未配置光口或者只有一个光口在位*/
                if ((IsNoConfigRruIdRange() ==  BSP_ERROR) || (IsNoneOptLop() != BSP_OK)||(g_ulUpLinkOptSpeedCfgCnt > UPLINK_OPT_RETRY_MAX_CNT))
                {
                    /*有一个光口物理和逻辑都没告警，则转到单光口自适应*/
                    return OPT_ADPT_POST_TWO_OPT_STATE;
                }
            }
            else
            {
                /*有一个光口物理和逻辑都没告警，则转到单光口自适应*/
                return OPT_ADPT_POST_TWO_OPT_STATE;
            }
        }
    }
    g_ulOptAdptSameStageStep += 1;
    if ((g_ulOptAdptSameStageStep >= pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_PRE_TWO_OPT_STATE])) /*状态防抖*/
    {
        return OPT_ADPT_TWO_OPT_STATE;
    }
    else
    {
        return OPT_ADPT_PRE_TWO_OPT_STATE;
    }
}

static UINT32 BspCheckRruIdInSerdesCfg(void)
{
    UINT32 workMode = BspGetDefaultOptWorkMode(0);
    UINT32 mainOpt = BspGetMainPhyOpt();
    UINT32 rruId = 0;
    const UINT32 abnormalRruIdMax = 254;
    const UINT32 abnormalRruIdMin = 0;

    if((workMode == BSP_OPT_WORK_MODE_RING) || (BSP_OPT_WORK_MODE_MAIN_SLAVE == workMode))
    {
         if(BspCheckRruIdIsOk() == BSP_OK)
         {
              BspLog(LOG_LEVEL_0,"mainopt %d\n",BspGetMainPhyOpt());
              return  OPT_ADPT_POST_TWO_OPT_STATE;
         }
     }
     else
     {
        rruId = BspGetRruId(mainOpt);
        BspLog(LOG_LEVEL_0,"mainopt %d, rruid %d\n", mainOpt, rruId);
        if ((rruId > abnormalRruIdMin) && (rruId < abnormalRruIdMax))
        {
            return  OPT_ADPT_POST_TWO_OPT_STATE;
        }
     }

    return BSP_ERROR;
}

/*为了缩短环网倒换时间，在AdptTwo 中先尝试接收初始化*/
UINT32 BspOptRxSerdesCfgInAdptTwo(VOID)
{
    UINT32 ulCpriSpd = 0;
    UINT32 ulLoop = 0;
    UINT32 ulOptIndex = 0;
    UINT32 ulMaxTryCnt = 10;   /*接收重配最大次数*/
    UINT32 ulSerdesLaneRate = 0;
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    T_OPTRATE_SERDES_PARAM rateSerdesPara = {0};
    UINT32 ulRxSerdesCfgCnt[OPTMAXNUM] = {0};
    UINT32 state = 0;
    UINT32 workMode = BspGetDefaultOptWorkMode(0);

    if((workMode == BSP_OPT_WORK_MODE_RING) || (BSP_OPT_WORK_MODE_MAIN_SLAVE == workMode))
    {
        ulMaxTryCnt = 1; /*TDD环网和主备组网，不需要此处重配10次*/
    }

    ulCpriSpd = BspGetOptSpeed(0);
    for(ulLoop = 0; ulLoop < ulMaxTryCnt; ulLoop++)
    {
        BspLog(LOG_LEVEL_0,"ulLoop %d\n",ulLoop);
        for(ulOptIndex = 0; ulOptIndex < OPTMAXNUM; ulOptIndex++)
        {
            if(BSP_ERROR == pInfo->pFuncCheckPhyOptIsLop(ulOptIndex))
            {
                BspLog(LOG_LEVEL_0,"ulOptIndex %d not exist\n",ulOptIndex);
                continue;
            }
            if(BSP_ERROR != BspGetMainPhyOpt())
            {
                state = BspCheckRruIdInSerdesCfg();
                RETVAL_CHECK_STSTE(state, OPT_ADPT_POST_TWO_OPT_STATE)
            }
            if(BSP_OK != pInfo->pFuncCheckPhyOptState(ulOptIndex)) /*0.2s*/
            {
                if(ulRxSerdesCfgCnt[ulOptIndex] > RX_RETRY_MAX_CNT)
                {
                    break;
                }
                if(1 == BspGetM0ThreadStartFlag()) /* 待增加M0正常运行标志 */
                {
                    BspSysMsDelay(500);  /*MO正常运行rx配置时才能延时，如果已经通知MO停止 则不需要等待*/
                }
                else
                {
                    BspGetSerdesParaByPhyNo(ulOptIndex,&rateSerdesPara);
                    ulCpriSpd = pInfo->pFuncGetOptSpeedRecord(ulOptIndex);
                    ulSerdesLaneRate = BspGetSerdesRateByCpriRate(ulCpriSpd);
                    BspHalChangeSerdesRxLaneRate(0,ulOptIndex,ulSerdesLaneRate,&rateSerdesPara);  /* 中间这几步 0.4s*/
                }
                BspLog(LOG_LEVEL_0,"_BspOptAdptTwo ulOptIndex %d ulLoop %d ulCpriSpd %d\n",ulOptIndex,ulLoop,ulCpriSpd);
                ulRxSerdesCfgCnt[ulOptIndex]++;
             }
        }
    }
    if((BSP_ERROR == IsAllPhyOptStaError()) || (BSP_ERROR == BspGetMainPhyOpt()))
    {
        BspLog(LOG_LEVEL_0,"_BspOptAdptTwo need all cfg\n");  /*两个口都还有告警*/
        return OPT_ADPT_STATE_MAX;
    }
    else
    {
        BspLog(LOG_LEVEL_0,"_BspOptAdptTwo jump\n");
        return OPT_ADPT_POST_TWO_OPT_STATE;  /*都无告警 如果经过上面步骤  主光口还没正常且还有一个光口异常则全配*/
    }
}
UINT32 BspTddRingAntiJitter(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 times  = 25;
    UINT32 index  = 0;
    UINT32 workMode = BspGetDefaultOptWorkMode(0);

    if(BSP_OPT_WORK_MODE_MAIN_SLAVE == workMode)
    {
        times = 8;/*次数循环用于还未倒换时切速率，影响倒换时间，主备只有一级，等待20次可满足*/
        if(SUPPORT_DOUBLE_BBU_MAIN_SLAVE == BspGetSupportDoubleBBUMainSlaveFlag())
        {
            times = 25;
            BspLog(LOG_LEVEL_0,"BspTddRingAntiJitter 2bbu wait 20s\n");
        }
    }

    if((workMode == BSP_OPT_WORK_MODE_RING) || (BSP_OPT_WORK_MODE_MAIN_SLAVE == workMode))
    {
        MSG_DBG(MOD_BOARD_OPT,"Set Two Opt Upper Link success\n");
        retVal |= BspSetOptControlAlarmByOptAlarm();

        for (index = 0; index < times; index ++)  /*实测重配一次需要1.5s左右*/
        {
            if (OPT_ADPT_POST_TWO_OPT_STATE == BspOptRxSerdesCfgInAdptTwo())
            {
                return OPT_ADPT_POST_TWO_OPT_STATE;
            }
            retVal |= BspSetOptControlAlarmByOptAlarm();
            BspSysMsDelay(50);
        }
        retVal |= BspSetOptControlAlarmAuto();
    }

    return OPT_ADPT_TWO_OPT_STATE;
}

UINT32 BspAdaptChangeSerdesSpeed(UINT32 sfp, UINT32  ulSpd);

UINT32 bbutestTimeDelay = 1000;
UINT32 _BspOptAdptSimpleForSmartPwrOff(UINT32 ulOptNum)
{
    UINT32 ulOptIndex = 0;
    UINT32 ulOptSfpSpd = 0;
    UINT32 retry = 0;
    UINT32 status = 0;
    UINT32 retValX = 0;
    
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    
    BspLog(LOG_LEVEL_0,"%s Enter time= %ld\n", "BbuOptTest", tickGet());
    //for循环防抖10次，每次延时100ms
    for(ulOptIndex = 0; ulOptIndex < ulOptNum; ulOptIndex++)
    {
       if(BSP_OK == pInfo->pFuncCheckPhyOptIsLop(ulOptIndex)) /*无光或者不在位 不执行*/
       {
           BspLog(LOG_LEVEL_0,"%s Opt%d time1 = %ld\n", "BbuOptTest", ulOptIndex, tickGet());
           ulOptSfpSpd=pInfo->pFuncGetOptSpeed(ulOptIndex);
           BspSetM0ThreadStartFlag(0);
           for(retry = 0; retry < 10; retry++)
           {
                retValX = BspAdaptChangeSerdesSpeed(ulOptIndex, ulOptSfpSpd);//重配RX Serdes的接口
                pInfo->pFuncDelayMs(bbutestTimeDelay);   
                status = pInfo->pFuncCheckPhyOptState(ulOptIndex);//读取光口告警信息的接口
                BspLog(LOG_LEVEL_0,"%s Opt%d, OptSfpSpd %d, retValX %d, status 0x%08X\n", "BbuOptTest", \
                        ulOptIndex,ulOptSfpSpd,retValX, status);
                if(BSP_OK == status)
                {
                    BspLog(LOG_LEVEL_0,"%s Opt%d time2 = %ld\n", "BbuOptTest", ulOptIndex, tickGet());
                    break;
                }
           }
        }
    }
    BspLog(LOG_LEVEL_0,"%s Return retryCount=%d,time = %ld\n", "BbuOptTest", retry,tickGet());
    return OPT_ADPT_POST_TWO_OPT_STATE;//2
}
/**************************************************************************
 * 函数名称： _BspOptAdptTwo
 * 功能描述： 双光口速率自适应
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 状态值
 * 其它说明： 无
 * 修改日期   版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 gul_adpttwodelay = 1;
UINT32 _BspOptAdptTwo(void)
{
    UINT32 ulState = OPT_ADPT_TWO_OPT_STATE;
    UINT32 ulLoop = 0;
    UINT32 ulOptSpd = 0;
    UINT32 ulOptSfpSpd1 = 0;
    UINT32 ulOptSfpSpd2 = 0;
    UINT32 ulMaxSpdBit=0;
    UINT32 ulRruSpdList=0;
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 ulOptIndex = 0;
    UINT32 ulOptNum = BspGetOptNum(); 
    UINT32 ulRet = OPT_ADPT_STATE_MAX;
    UINT32 fecLoop = 0;
    UINT32 fecLoopCnt = 0;

    BspLog(LOG_LEVEL_0,"%s@%d>Enter\n", __func__, __LINE__);

    if(ulOptNum > OPTMAXNUM) 
    {
        ulOptNum = OPTMAXNUM;
    }	 
    /*两个光口OPT0,OPT1光模块都不在位，跳转到状态机--双光口速率自适应pre接口*/

    if(BSP_ERROR == IsAllOptLop())
    {
        MSG_DBG(MOD_BOARD_OPT, "[Both opt]detect no exit\n");
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }

    ulState = BspTddRingAntiJitter();
    RETVAL_CHECK_STSTE(ulState, OPT_ADPT_POST_TWO_OPT_STATE)

    if(BSP_OK == BspIsRingOptWorkMode())
    {
        ulRet = BspOptRxSerdesCfgInAdptTwo();
        if(ulRet != OPT_ADPT_STATE_MAX)
        {
            return ulRet;
        }
    }

	if(BspGetSmartPwroffOptTestFlag())//电源智能启停，bbu测试光口关断时使用
	{
	    return _BspOptAdptSimpleForSmartPwrOff(ulOptNum);//2
    }

    /* 选择自适应速率列表 */
    for(ulOptIndex = 0; ulOptIndex < ulOptNum; ulOptIndex++)
    {
        ulOptSfpSpd2 = pInfo->pFuncGetOptSfpMaxSpeed(ulOptIndex);
        if(ulOptSfpSpd1 < ulOptSfpSpd2)
        {
            ulOptSfpSpd1 = ulOptSfpSpd2;
        }
    }/*找到最大速率*/
    ulRruSpdList = pInfo->pFuncGetRruOptSurportSpeedList();
    ulMaxSpdBit =  BspGetOptSpeedMaskBit(ulOptSfpSpd1); 
    MSG_DBG(MOD_BOARD_OPT, "RRU speed List%x OptMaxSpdBit%d \n",ulRruSpdList,ulMaxSpdBit);
    /* 遍历速率List配置 */
    for(ulLoop = 0; ulLoop <= ulMaxSpdBit; ulLoop++)
    {
        if(0x0==(ulRruSpdList & (0x01 << ulLoop)))
        {   /* not surport this speed */
            //MSG_ERR(MOD_BOARD_OPT, "speed List%x OptMaxSpdBit%d ,skip bit%d \n",ulRruSpdList,ulMaxSpdBit,ulLoop);
            continue;
        }
        ulOptSpd = BspGetOptSpeedByMaskBit(ulLoop);
        MSG_DBG(MOD_BOARD_OPT, "change speed to %d \n", ulOptSpd);
        if(ulOptSpd > BSP_OPT_SPEED_10P1376G)
        {
            fecLoopCnt = 2;
        }
        else
        {
            fecLoopCnt = 1;
        }
        for(fecLoop = 0; fecLoop < fecLoopCnt; fecLoop++)
        {
            for(ulOptIndex = 0; ulOptIndex < ulOptNum; ulOptIndex++)
            {
                if(BSP_OK == pInfo->pFuncCheckPhyOptIsLop(ulOptIndex))
                {
                    BspSetM0ThreadStartFlag(0);
                    pInfo->pFuncSetOptSpeed(ulOptIndex, ulOptSpd);
                }
            }
            pInfo->pFuncDelayMs(1000*gul_adpttwodelay);   /*无光或者不在位 不执行 减少执行时间*/
            BspSetCpriOptProperty(0,0);  /*上联口没识别之前都应该是自动识别 防止单上联配置接双光纤 两个口属性设置之后无法竞争正确的主光口*/
            BspLog(LOG_LEVEL_0,"%s(%d): ulOptSpd%d\n", __FUNCTION__,__LINE__,ulOptSpd);
            dbgInfo("%s(%d): ulOptSpd%d\n", __FUNCTION__,__LINE__,ulOptSpd);
            /* 检查在位光口同步状态 */
            if(BSP_ERROR == checkAllOptSta())
            {
                continue;
            }
            else
            {
                if (BSP_OK == IsRruIdAndPriorityOK()) /*处理单上联接双光纤场景 和 异速率环网光口无告警但控制字无效场景*/
                {
                    /*有一个光口物理和逻辑都没告警，则转到单光口自适应*/
                    return OPT_ADPT_POST_TWO_OPT_STATE;
                }
                else
                {
                    continue;
                }
            }
        }
    }
    return  OPT_ADPT_PRE_TWO_OPT_STATE;/*所有速率都没有成功，跳转到状态机--双光口速率自适应pre接口*/
}

ULONG _BspOptAdptPostTwo(void)
{
    ULONG ulPhyOpt = 0;
    ULONG ulPhyOptSpd = 0;
    UINT32 ulIndex = 0;

    g_ulUpLinkOptSpeedCfgCnt = 0;   /*执行0 1 之后认为上联口正常*/
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    if ((BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(0))) && \
        (BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(1))))
    {
		MSG_ERR(MOD_BOARD_OPT, "[Both opt]detect no exit\n");
        return  OPT_ADPT_PRE_TWO_OPT_STATE;     /*两个光口OPT0,OPT1光模块都不在位，跳转到状态机--双光口速率自适应接口*/
    }

    /*OPT0,OPT1 光口都出现告警则进行速率切换配置，只要有一个光口正常则进入状态机-单光口自适应接口中*/
    if ((BSP_OK != pInfo->pFuncCheckPhyOptState(0)) && \
         (BSP_OK != pInfo->pFuncCheckPhyOptState(1))) /* (BSP_OK != g_tOptAutoAdaptInfo.pFuncCheckExtSysClkLockState())*/
    {
        return  OPT_ADPT_PRE_TWO_OPT_STATE;/*所有速率上一步尝试过都没有成功，跳转到状态机--双光口速率自适应pre接口*/
    }
    else  /*只要有一个光口正常则进入状态机-单光口自适应接口中*/
    {
        if ((BSP_OK != pInfo->pFuncCheckLogicOptState(0)) &&
            (BSP_OK != pInfo->pFuncCheckLogicOptState(1))) /*RruId 两个逻辑光口都不合法，进行速率切换*/
        {
            return  OPT_ADPT_TWO_OPT_STATE;
        }
        else
        {
            g_ulOptAdptSameStageStep += 1;
        }
    }
    if (g_ulOptAdptSameStageStep < g_tOptAutoAdaptInfo.ulJitterAvoidTimes4FuncState[OPT_ADPT_POST_TWO_OPT_STATE])
    {
        return OPT_ADPT_POST_TWO_OPT_STATE;
    }
    else
    {
        BspHalAdaptGetMainPhyOpt(&ulPhyOpt);
        /*有一个RruId 光口合法，跳转到状态机--单光口速率自适应接口*/
        if (BSP_ERROR != ulPhyOpt)
        {
            /* 获取主光口速率 */
            ulIndex = BspGetSfpNoByPhyNo(ulPhyOpt);
            ulPhyOptSpd = pInfo->pFuncGetOptSpeed(ulIndex);
            MSG_DBG(MOD_BOARD_OPT,"phy Main (PhyOpt%d) adpt OK,speed = %d G\n", ulPhyOpt, ulPhyOptSpd);
            /* 仅记录上联光口速率 */
            pInfo->pFuncSaveOptSpeedRecord(ulPhyOpt, ulPhyOptSpd);
            (VOID)BspSetOptLosAlmFromPcs(ulPhyOpt);  /*网管设置25G时 版本升级实际实验也可能不切速率*/
            BspSetOptSpdChgRecord(ulPhyOpt);
            BspSetAxcArrangeTypeByRate(ulPhyOpt);
            g_ulAnotherOptSetSpeedCnt[ulPhyOpt] = 0;
            if (BspGetOptCpriProtocol(0) == PROCOTOL_IR)
            {
                (VOID)BspHalAdaptSetCpriLineRate(ulPhyOpt,ulPhyOptSpd);
                #ifndef _SH_TF_20KM_T12_
                (VOID)BspHalAdaptUpdateFrCfg();
                #endif
                BspLog(LOG_LEVEL_0,"%s@%d>cfg Line Rate & FrCfg\n",__func__, __LINE__);
            }
        }

        return OPT_ADPT_PRE_ONE_OPT_STATE;
    }
}
/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日 尧小安00109169    创建
 **************************************************************************/
ULONG _BspIsNeedSlaveOptAdaptByWorkMode(void)
{
    ULONG ulWorkMode = 0;
    ulWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);

    if (pSwitchSlaveOptAdaptSta != NULL)
    {
        return pSwitchSlaveOptAdaptSta();
    }

    if( RRU_BBU == BspGetPbOrBbuMode() )
    {
 	   return SWITCH_OFF;
    }

    if(BSP_OPT_WORK_MODE_RING_CHAIN == ulWorkMode)
    {
        return SWITCH_OFF;
    }
    else
    {
        return SWITCH_ON;   /**待确认*/
    }
}
ULONG _BspOptAdptPreOne(void)
{
    ULONG ulAdptOptNo = 0;
    ULONG ulMainPhyOptNo = 0;
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    /* ULONG ulWorkMode = 0; */

    /* 级联、环网、环加链 此状态机不使能，直接跳转到 check状态机 */
    if (SWITCH_OFF == _BspIsNeedSlaveOptAdaptByWorkMode())
    {
        /* 这里处理下联光口的配置，下联光口在这里应该默认是逻辑辅光口
           为防止异速率配置在自适应完成前下发，这里额外增加处理*/
        /* 复制光口/serdes的线速率、加解扰、信令流速配置等 */
#if 0
        ULONG ulDownLinkDiffFlag = 0;
        ULONG ulDownLinkDiffSpd = 0;
        BspCopyLogicOptCfg(DPDIC_M, OPT_M, DPDIC_M, OPT_S);
        g_tOptAutoAdaptInfo.pFuncGetDownLinkDiffSpdFlag(&ulDownLinkDiffFlag, &ulDownLinkDiffSpd);

        if (ulDownLinkDiffFlag)
        {
            /* 仅更改光口/serdes的线速率，但加解扰、信令流速配置等保持 */
            BspSetLogicOptSpeed(DPDIC_M, OPT_S, ulDownLinkDiffSpd);
        }
#endif
        return OPT_ADPT_POST_ONE_OPT_STATE;
    }

    /*两个光口OPT0,OPT1光模块都不在位，跳转到状态机--双光口速率自适应pre接口*/
    if ((BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(0))) && \
        (BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(1))))
    {
    	 MSG_ERR(MOD_BOARD_OPT,"[Both opt]detect no exit\n");
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    /******************原本以下是针对双上联场景的处理，但是4.2 双光口自适应的时候下联口可能没初始化成功，会导致下一级RRU无法建链，所以级联场景需要监控下联口***********************/
    /*OPT0,OPT1 光口都出现告警则跳转到状态机--双光口速率自适应pre接口*/
    if ((BSP_OK != pInfo->pFuncCheckPhyOptState(0)) && \
        (BSP_OK != pInfo->pFuncCheckPhyOptState(1)))
    {
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    else /*OPT0或OPT1 有一个光口正常，则进行另外一个异常光口自适应*/
    {
        (VOID)BspHalAdaptGetMainPhyOpt(&ulMainPhyOptNo);
        if(ulMainPhyOptNo == BSP_ERROR)
        {
            return  OPT_ADPT_PRE_TWO_OPT_STATE;
        }
        ulAdptOptNo = 1-ulMainPhyOptNo;  /*这里已经识别出主物理光口，上联口只能是0和1，2、3是下联口*/
        /* ulWorkMode = pInfo->pFuncGetOptWorkMode(0); */
        if(BSP_ERROR == pInfo->pFuncCheckPhyOptIsLop(ulAdptOptNo))
        {
            /*这里针对的是单板下配置的是级联模式，但是实际星型或者没接下一级，接电模块（直接ERROR）或者不接光纤(有不在位或者LOP告警)，此时不管下一级，如果下联口无LOP告警，必然已接
            由于4.2 serdes的缺陷，双光口自适应时下联口的serdes 大概率会初始化失败，而按原有方案，上联口正常之后不会重新配置下联口，所以要监控下联口*/
            if(BSP_OK == BspJudgeOptStaByOptWorkMode())
            {
                dbgInfoEx("AdpOptNo#%d check lop error! now is not real CASCADE\n", ulAdptOptNo);
                return OPT_ADPT_STATE_OK;
            }
            MSG_ERR(MOD_BOARD_OPT,"AdpOptNo#%d check lop error!\n", ulAdptOptNo);
            return OPT_ADPT_PRE_ONE_OPT_STATE;
        }
        if (BSP_OK == pInfo->pFuncCheckPhyOptState(ulAdptOptNo)) /*获取异常物理光口状态以及物理光口号*/
        {
        	MSG_ERR(MOD_BOARD_OPT,"Both opt state detect normal \n");
            return OPT_ADPT_POST_ONE_OPT_STATE;
        }
        else
       {
            g_ulOptAdptSameStageStep += 1;
       }
    }

    if( (g_ulOptAdptSameStageStep>=g_tOptAutoAdaptInfo.ulJitterAvoidTimes4FuncState[OPT_ADPT_PRE_ONE_OPT_STATE]))
    {
        return OPT_ADPT_ONE_OPT_STATE;
    }
    else
    {
        return OPT_ADPT_PRE_ONE_OPT_STATE;
    }
}

/*判断下联口需要配置的速率*/
UINT32 BspJudgeDownlinkOptCfgSpeed(UINT32 ulMainPhyOptNo)
{
    UINT32 ulMainSpd = 0;
    UINT32 ulSlaveSpd = 0;
    UINT32 ulMainFecMode = 0;
    UINT32 ulSlaveFecMode= 0;
    UINT32 ulSlaveSerdesSpd = 0;
    UINT32 ulMainSerdesSpd = 0;
    UINT32 ulOptIndex = 0;
    UINT32 ulAppUpLinkSpd = 0;
    UINT32 ulAppDownLinkSpd = 0;
    UINT32 ulAppDownLinkSerdesSpd = 0;
    UINT32 ulSpeed = 0;

    ulOptIndex = 1- ulMainPhyOptNo;
    INPUT_PHYOPT_INDEX_CHECK(ulOptIndex);   /*入参检查 防止数组越界*/
    ulAppUpLinkSpd = BspLoadOptSpeedFromApp(ulMainPhyOptNo);
    ulAppDownLinkSpd = BspLoadOptSpeedFromApp(ulOptIndex);
    MSG_DBG(MOD_BOARD_OPT, "ulAppUpLinkSpd %d ulAppDownLinkSpd %d\n",ulAppUpLinkSpd, ulAppDownLinkSpd);
    BspHalAdaptCpriGetLineRate(ulMainPhyOptNo,&ulMainSpd);
    MSG_DBG(MOD_BOARD_OPT, "ulMainPhyOptNo %d ulOptSpd %d\n",ulMainPhyOptNo, ulMainSpd);
    BspHalAdaptCpriGetLineRate(ulOptIndex,&ulSlaveSpd);
    MSG_DBG(MOD_BOARD_OPT, "ulSlavePhyOptNo %d ulSlaveSpd %d\n",ulOptIndex, ulSlaveSpd);
    BspHalAdaptGetLycaSerdesRate(0,ulMainPhyOptNo,&ulMainSerdesSpd);
    BspHalAdaptGetLycaSerdesRate(0,ulOptIndex,&ulSlaveSerdesSpd);
    MSG_DBG(MOD_BOARD_OPT, "ulMainPhyOptNo serdesrate %d ulSlavePhyOptNo serdesrate %d\n",ulMainSerdesSpd, ulSlaveSerdesSpd);
    /*同速率级联 或者高层还未下发速率 先按同速率级联进行配置  TDD机型没有异速率级联，不调用BspSaveOptSpeedFromApp 速率都是0*/
    if((ulAppUpLinkSpd == 0)||(ulAppDownLinkSpd == 0)||(ulAppUpLinkSpd == ulAppDownLinkSpd))
    {
        BspHalAdaptPcsGetLinkFecMode(ulMainPhyOptNo,&ulMainFecMode);
        BspHalAdaptPcsGetLinkFecMode(ulOptIndex,&ulSlaveFecMode);
        MSG_DBG(MOD_BOARD_OPT, "ulMainPhyOptNo fec %d ulSlavePhyOptNo fec %d\n",ulMainFecMode, ulSlaveFecMode);
        if(ulMainSpd != ulSlaveSpd)
        {
            g_ulAnotherOptSetSpeedFlag[ulOptIndex] = 1;  /*上下联cpri线速率不一致，全配*/
        }
        if(ulMainFecMode != ulSlaveFecMode)
        {
            g_ulAnotherOptSetSpeedFlag[ulOptIndex] = 1;  /*上下联口fec模式不一样，全配*/
        }
        if(ulMainSerdesSpd != ulSlaveSerdesSpd)
        {
             g_ulAnotherOptSetSpeedFlag[ulOptIndex] = 1;  /*上下联serdes线速率不一致，全配*/
         }
        ulSpeed = ulMainSpd;
    }
    else /*异速率级联*/
    {
        if(ulSlaveSpd != ulAppDownLinkSpd)
        {
             g_ulAnotherOptSetSpeedFlag[ulOptIndex] = 1;  /*下联口还不是高层下发的配置cpri速率时 全配*/
        }
        ulAppDownLinkSerdesSpd = BspGetSerdesRateByCpriRate(ulAppDownLinkSpd);
        if(ulSlaveSerdesSpd != ulAppDownLinkSerdesSpd)
        {
            g_ulAnotherOptSetSpeedFlag[ulOptIndex] = 1;  /* serdes线速率不符合预期时，全配*/
        }
        if(BSP_OPT_SPEED_24P33024G == ulAppDownLinkSpd)
        {
            g_ulAnotherOptSetFecModeFlag[ulOptIndex] = 1;
        }
        ulSpeed = ulAppDownLinkSpd; /*异速率级联*/
    }
    MSG_DBG(MOD_BOARD_OPT, "ulOptIndex %d ulSpeed %d\n",g_ulAnotherOptSetSpeedFlag[ulOptIndex],ulSpeed);
    if(g_ulAnotherOptSetSpeedCnt[ulOptIndex] > SERDES_MAXTRY_CNT)  /*只配RX 下一级长时间无法建链*/
    {
        BspLog(LOG_LEVEL_0,"ulOptIndex %d selfsave \n",ulOptIndex);
        g_ulAnotherOptSetSpeedFlag[ulOptIndex] = 1;  /*下联口自救*/
    }
    return ulSpeed;
}
/*AdptOne 过程中防抖*/
UINT32 BspSameStepProcessInAdptOne(VOID)
{
    g_ulOptAdptSameStageStep += 1;
    if( (g_ulOptAdptSameStageStep >= g_tOptAutoAdaptInfo.ulJitterAvoidTimes4FuncState[OPT_ADPT_ONE_OPT_STATE]))
    {
        return OPT_ADPT_POST_ONE_OPT_STATE;
    }
    else
    {
        BspLog(LOG_LEVEL_0,"g_ulOptAdptSameStageStep %d\n",g_ulOptAdptSameStageStep);
        MSG_DBG(MOD_BOARD_OPT,"g_ulOptAdptSameStageStep %d\n",g_ulOptAdptSameStageStep);
        return OPT_ADPT_ONE_OPT_STATE;
    }
}

/*AdptOne 配置下联口速率*/
VOID BspAnotherOptSetSpeed(UINT32 ulOptIndex, UINT32 ulOptSpd)
{
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 m0StartFlag = BspGetM0ThreadStartFlag();
    /* Started by AICoder, pid:k233bz6234vb2cc1465f0b3b705df708166427de */
    if(ulOptIndex >= OPTMAXNUM)
    {
        return;
    }
    /* Ended by AICoder, pid:k233bz6234vb2cc1465f0b3b705df708166427de */
    if(0 == g_ulAnotherOptSetSpeedFlag[ulOptIndex])
    {
        /* Started by AICoder, pid:hac3358858p9f801427a09a610336d058a842c88 */
        if(0 == g_ulAnotherOptCntStop)  /*默认值时原有逻辑不变 维测时跳过此步*/
        {
            g_ulAnotherOptSetSpeedCnt[ulOptIndex]++;
        }
        /* Ended by AICoder, pid:hac3358858p9f801427a09a610336d058a842c88 */
        BspLog(LOG_LEVEL_0,"ulOptIndex %d rx ulOptSpd %d g_ulM0ThreadStartFlag %d\n", ulOptIndex, ulOptSpd, m0StartFlag);
        /* 获取MO是否启动 启动之后MO配 启动之前CPU配  保证建链 第一次需要cpu配置两个口建链之后通知MO启动*/
        if(1 == m0StartFlag)
        {
            BspSysMsDelay(500);
        }
        else
        {
            BspLog(LOG_LEVEL_0,"ulOptIndex %d rx ulOptSpd %d\n", ulOptIndex, ulOptSpd);
            pInfo->pFuncReCfgOptRxSerdes(ulOptIndex, ulOptSpd);
            if(1 == g_ulAnotherOptSetFecModeFlag[ulOptIndex]) /* 异速率环网下联口25G光口速率时，自适应fec模式 */
            {
                BspSetOptFecMode(ulOptIndex);
            }
        }
    }
    else
    {
        BspLog(LOG_LEVEL_0,"ulOptIndex %d ulOptSpd %d \n", ulOptIndex, ulOptSpd);
        BspSetM0ThreadStartFlag(0);
        pInfo->pFuncSetOptSpeed(ulOptIndex, ulOptSpd);/*需要完全重配下联口*/
        g_ulAnotherOptSetSpeedCnt[ulOptIndex] = 0;  /*整体重配之后计数清0*/
    }
    g_ulAnotherOptSetSpeedFlag[ulOptIndex] = 0;
    g_ulAnotherOptSetFecModeFlag[ulOptIndex] = 0;
    pInfo->pFuncDelayMs(500);
}

VOID BspForceCfgTxPriority(UINT32 ulPhyOpt)
{
    UINT32 ulRingFlag = 0;

    ulRingFlag = BspGetOptRingFlag();
    if(ulRingFlag == OPT_NOT_SUPPORT_RING)
    {/*下联口异常 固定转发主光口控制字给第二级*/
        BspLog(LOG_LEVEL_0,"BspForceCfgTxPriority %d\n",ulPhyOpt);
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_2,0x38,1);
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_3,0x38,1);
    }
}
UINT32 BspJudgeAdptOneState(UINT32 ulMainPhyOpt)
{
    UINT32 ulSlaveSpd = 0;
    UINT32 ulMainSpd = 0;
    UINT32 ulSlavePhyOpt = 0;
    UINT32 ulAppSpd = 0;
    UINT32 ulRet = BSP_OK;

    ulSlavePhyOpt = 1-ulMainPhyOpt;
    BspHalAdaptCpriGetLineRate(ulSlavePhyOpt,&ulSlaveSpd);
    BspHalAdaptCpriGetLineRate(ulMainPhyOpt,&ulMainSpd);
    ulAppSpd = BspLoadOptSpeedFromApp(ulSlavePhyOpt);
    ulRet = BspJudgeDownlinkOptSpeed(ulAppSpd, ulSlaveSpd, ulMainSpd);

    if(ulRet == BSP_ERROR)
    {
        return BSP_ERROR;
    }
    if(BSP_OK == IsAllPhyOptStaOk())
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}

UINT32 BspSetOptSpeedListCpri(UINT32 speedlist)
{
    s_optSpeddListCpri = speedlist;

    return BSP_OK;
}

UINT32 BspGetDownOptSpeedList(void)
{
    UINT32 speedList = TDD_OPT_SPEED_LIST_IR;
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    speedList = pInfo->pFuncGetRruOptSurportSpeedList();
    if(s_optSpeddListCpri != 0)
    {
        speedList = s_optSpeddListCpri;
    }

    return speedList;
}
/**************************************************************************
 * 函数名称： _BspOptAdptOne（ BspOptAdptSome  圈复杂度问题保持原名)
 * 功能描述： 部分光口速率自适应（已有光口同步）
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 状态值
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 _BspOptAdptOne(void)
{
    UINT32 ulLoop = 0;
    UINT32 ulOptSpd = 0;
    UINT32 ulOptSfpSpd1 = 0;
    UINT32 ulMaxSpdBit=0;
    UINT32 ulRRUSpdList=0;
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 ulOptIndex=0;
    ULONG ulMainPhyOptNo = 0;
    /* ULONG ulMainLogOptNo = 0; */
    ULONG ulSlaveLogOptNo = 0;
    UINT32 ulSpeed = 0;

    /* 级联、环网、环加链 此状态机不使能，直接跳转到 check状态机 */
    if (SWITCH_OFF == _BspIsNeedSlaveOptAdaptByWorkMode())
    {
#if 0
        /* 这里处理下联光口的配置，下联光口在这里应该默认是逻辑辅光口
           为防止异速率配置在自适应完成前下发，这里额外增加处理
        */
        /* 复制光口/serdes的线速率、加解扰、信令流速配置等 */
        BspCopyLogicOptCfg(DPDIC_M, OPT_M, DPDIC_M, OPT_S);
        g_tOptAutoAdaptInfo.pFuncGetDownLinkDiffSpdFlag(&ulDownLinkDiffFlag, &ulDownLinkDiffSpd);

        if (ulDownLinkDiffFlag)
        {
            /* 仅更改光口/serdes的线速率，但加解扰、信令流速配置等保持 */
            BspSetLogicOptSpeed(DPDIC_M, OPT_S, ulDownLinkDiffSpd);
        }
#endif
        return OPT_ADPT_POST_ONE_OPT_STATE;
    }

    /*两个光口OPT0,OPT1光模块都不在位，跳转到状态机--双光口速率自适应接口*/
    if (BSP_ERROR == IsAllOptLop())
    {
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }

    /*OPT0,OPT1 光口都出现告警或者LMK04821没有锁定，则跳转到状态机--双光口速率自适应接口*/
    if (BSP_ERROR == IsAllPhyOptStaError())
    {
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }
    else /*OPT0或OPT1 有一个光口正常，则进行另外一个异常光口自适应*/
    {
        (VOID)BspHalAdaptGetMainPhyOpt(&ulMainPhyOptNo);
        if(ulMainPhyOptNo >= OPTMAXNUM)   /*主光口状态校验*/
        {
             return  OPT_ADPT_PRE_TWO_OPT_STATE;
        }
        /* ulMainLogOptNo = BspHalAdaptGetLogOpt(ulMainPhyOptNo); */
        ulOptIndex = 1-ulMainPhyOptNo;  /*这里已经识别出主物理光口，上联口只能是0和1，2、3是下联口*/
        if(pInfo->pFuncCheckPhyOptIsLop(ulOptIndex)) /*另一个口不在位 下边的流程可能无法跳出 应对自适应流程中间拔掉后级的场景*/
        {
            return  OPT_ADPT_STATE_OK;   /*此时主光口正常，直接跳到最后*/
        }

        if(BSP_OK == BspJudgeAdptOneState(ulMainPhyOptNo)) /*两个物理光口都合法*/
        {
            BspLog(LOG_LEVEL_0,"[Both opt]OptState valid\n");
            return BspSameStepProcessInAdptOne();
        }

        /*未同步光口自适应配置*/
        ulOptSfpSpd1 = pInfo->pFuncGetOptSfpMaxSpeed(ulOptIndex);
        ulRRUSpdList = BspGetDownOptSpeedList();
        ulMaxSpdBit  = BspGetOptSpeedMaskBit(ulOptSfpSpd1);
        MSG_DBG(MOD_BOARD_OPT, "RRU speed List%x OptMaxSpdBit%d \n",ulRRUSpdList,ulMaxSpdBit);
        /* 遍历速率List配置 */
        for(ulLoop = 0; ulLoop <= ulMaxSpdBit; ulLoop++)
         {
              if(BSP_OK == BspJudgeOptStaByOptWorkMode())  /*级联需要考虑上下两级的互相影响，其他组网模式还需要对应处理*/
              {
                  ulSpeed = BspJudgeDownlinkOptCfgSpeed(ulMainPhyOptNo);
              }

              if(0x0==(ulRRUSpdList & (0x01 << ulLoop)))
              {
                  /* not surport this speed */
                 continue;
              }
              ulOptSpd = BspGetOptSpeedByMaskBit(ulLoop);
              if(ulOptSpd != ulSpeed)
              {
                  continue;
              }
              MSG_DBG(MOD_BOARD_OPT, "change speed to %d \n", ulOptSpd);
              BspAnotherOptSetSpeed(ulOptIndex, ulOptSpd); /* 配置下联口光口速率 */
              ulSlaveLogOptNo = BspHalAdaptGetLogOpt(ulOptIndex);
              if ((BSP_OK !=  pInfo->pFuncCheckPhyOptState(ulOptIndex))||(ulSlaveLogOptNo == BSP_ERROR))
              {
                  BspForceCfgTxPriority(ulMainPhyOptNo);
                  MSG_ERR(MOD_BOARD_OPT,"phyopt %d sta error,  ulSlaveLogOptNo %d\n",ulOptIndex,ulSlaveLogOptNo);
                  continue ;
              }
              if (BSP_ERROR == IsAllLogOptStaError()) /*RruId 2个逻辑光口都不合法，则跳转到状态机--双光口速率自适应接口*/
              {
                  MSG_ERR(MOD_BOARD_OPT,"[Both opt]LogicOptState invalid\n");
                  return OPT_ADPT_PRE_TWO_OPT_STATE;
              }
              else if (BSP_OK == IsAllLogOptStaOk()) /*RruId 两个逻辑光口都合法，跳转到状态机--光口检测接口*/
              {
                  BspLog(LOG_LEVEL_0,"[Both opt]OptState valid\n");
                  return BspSameStepProcessInAdptOne();
              }
              else/*有一个RruId 光口合法，跳转到状态机--单光口速率自适应接口*/
              {
                  continue;
              }
            }/*异常光口所有速率都没有成功，跳转到状态机--单光口速率自适应接口*/
            return OPT_ADPT_ONE_OPT_STATE;
        }
}

UINT32 BspSetM0FlagAndSpd(VOID)
{
    UINT32 ulMainPhyOptNo = 0;
    UINT32 ulIndex = 0;
    UINT32 ulUpLinkOptSpd = 0;
    UINT32 ulDownLinkOptSpd = 0;
    UINT32 optWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);

    if((PROCOTOL_IR == BspGetOptCpriProtocol(0)) || (BSP_OPT_WORK_MODE_NORMAL != optWorkMode))
    {
        return BSP_OK;
    }
    (VOID)BspHalAdaptGetMainPhyOpt(&ulMainPhyOptNo);
    ulIndex = BspGetSfpNoByPhyNo(ulMainPhyOptNo);
    ulUpLinkOptSpd = BspGetOptSpeed(ulIndex);
    ulDownLinkOptSpd = BspGetOptSpeed(1 - ulIndex);
    if((BSP_OPT_SPEED_24P33024G == ulUpLinkOptSpd && BSP_OPT_SPEED_24P33024G == ulDownLinkOptSpd)  \
       || (BSP_OPT_SPEED_10P1376G == ulUpLinkOptSpd && BSP_OPT_SPEED_10P1376G == ulDownLinkOptSpd) \
       || (BSP_OPT_SPEED_24P33024G == ulUpLinkOptSpd && BSP_OPT_SPEED_10P1376G == ulDownLinkOptSpd) \
       || (BSP_OPT_SPEED_10P1376G == ulUpLinkOptSpd && BSP_OPT_SPEED_24P33024G == ulDownLinkOptSpd))
    {
        BspSetM0OptSpeed(ulIndex, ulUpLinkOptSpd);
        BspSetM0OptSpeed(1 - ulIndex, ulDownLinkOptSpd);
        BspSetM0ThreadStartFlag(1);  /*两口都正常才通知M0启动 即使最后一级单光口 也需要另一端接上光纤建链之后再启动M0*/
    }
    return BSP_OK;
}

/* 如果FDD机型环网,配置完速率，走打开M0流程 */
UINT32 BspStartM0ByWorkMode(VOID)
{
    if(PROCOTOL_IR == BspGetOptCpriProtocol(0) || (1 == BspGetM0ThreadStartFlag()))
    {
        return BSP_OK;
    }
    BspSetM0FlagAndSpd();

    return BSP_OK;
}

ULONG _BspOptAdptPostOne(void)
{
    ULONG ulPhyOptSpd = 0;
    ULONG ulMainLogOptNo = 0;
    ULONG ulMainPhyOptNo = 0;
    ULONG ulSlavePhyOptNo = 0;
    ULONG ulSlaveLogOptNo = 0;
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 ulIndex = 0;

    /* 级联、环网、环加链 此状态机不使能，直接跳转到 check状态机 */
    if (SWITCH_OFF == _BspIsNeedSlaveOptAdaptByWorkMode())
    {
#if 0
        /* 这里处理下联光口的配置，下联光口在这里应该默认是逻辑辅光口
           为防止异速率配置在自适应完成前下发，这里额外增加处理
        */
        /* 复制光口/serdes的线速率、加解扰、信令流速配置等 */
        BspCopyLogicOptCfg(DPDIC_M, OPT_M, DPDIC_M, OPT_S);
        g_tOptAutoAdaptInfo.pFuncGetDownLinkDiffSpdFlag(&ulDownLinkDiffFlag, &ulDownLinkDiffSpd);

        if (ulDownLinkDiffFlag)
        {
            /* 仅更改光口/serdes的线速率，但加解扰、信令流速配置等保持 */
            BspSetLogicOptSpeed(DPDIC_M, OPT_S, ulDownLinkDiffSpd);
        }
		BspSetOptBindInfobyPara(0,3,DPDIC_M); /*光口3绑定到光口0*/
		dbgInfo("Bsp Set Opt3 Bind to Opt0 InfobyPara success\n");
#endif
        return OPT_ADPT_STATE_OK;
    }

    /*两个光口OPT0,OPT1光模块都不在位，跳转到状态机--双光口速率自适应接口*/
    if ((BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(0))) && \
        (BSP_ERROR == (pInfo->pFuncCheckPhyOptIsLop(1))))
    {
    	 MSG_ERR(MOD_BOARD_OPT,"[Both opt]detect no exit\n");
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }

    /*OPT0,OPT1 光口都出现告警或系统时钟没有锁定，则跳转到状态机--双光口速率自适应接口*/
/*    if (BSP_OK != pInfo->pFuncCheckExtSysClkLockState())
    {
        return  OPT_ADPT_PRE_TWO_OPT_STATE;
    }*/
    //else /*OPT0或OPT1 有一个光口正常，则进行另外一个异常光口自适应*/
    {
        (VOID)BspHalAdaptGetMainPhyOpt(&ulMainPhyOptNo);
        ulMainLogOptNo = BspHalAdaptGetLogOpt(ulMainPhyOptNo);
        ulSlavePhyOptNo = 1 - ulMainPhyOptNo;
        ulSlaveLogOptNo = BspHalAdaptGetLogOpt(ulSlavePhyOptNo);
        if(ulMainPhyOptNo == BSP_ERROR)
        {
            return OPT_ADPT_PRE_TWO_OPT_STATE;
        }
        if(ulSlaveLogOptNo == BSP_ERROR)
        {
            return OPT_ADPT_PRE_ONE_OPT_STATE;
        }
        if ((BSP_OK != pInfo->pFuncCheckLogicOptState(ulMainLogOptNo))
            && (BSP_OK != pInfo->pFuncCheckLogicOptState(ulSlaveLogOptNo))) /*RruId 两个逻辑光口都不合法，则跳转到状态机--双光口速率自适应接口*/
        {
            return OPT_ADPT_PRE_TWO_OPT_STATE;
        }
        else if ((BSP_OK == pInfo->pFuncCheckLogicOptState(ulMainLogOptNo))
                 && (BSP_OK == pInfo->pFuncCheckLogicOptState(ulSlaveLogOptNo))) /*RruId 两个逻辑光口都合法，跳转到状态机--光口检测接口*/
        {
            g_ulOptAdptSameStageStep += 1;
        }
        else/*有一个RruId 光口合法，跳转到状态机--单光口速率自适应接口*/
        {
            return OPT_ADPT_ONE_OPT_STATE;
        }
    }

    if (g_ulOptAdptSameStageStep > pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_POST_ONE_OPT_STATE])
    {
        (VOID)BspHalAdaptGetMainPhyOpt(&ulMainPhyOptNo);
        if (BSP_ERROR != ulMainPhyOptNo)
        {
            INPUT_PHYOPT_INDEX_CHECK(1-ulMainPhyOptNo);
            /* 获取主光口速率 */
        	ulIndex = BspGetSfpNoByPhyNo(ulMainPhyOptNo);
            ulPhyOptSpd = pInfo->pFuncGetOptSpeed(1-ulIndex);
            MSG_ERR(MOD_BOARD_OPT,"phy Main (PhyOpt%d) adpt OK,speed = %d G\n", ulMainPhyOptNo, ulPhyOptSpd);
            /* 记录下联联光口速率 */
            g_tOptAutoAdaptInfo.pFuncSaveOptSpeedRecord(1-ulMainPhyOptNo, ulPhyOptSpd);
            (VOID)BspSetOptLosAlmFromPcs(1-ulMainPhyOptNo); /*网管设置25G时 版本升级实际实验也可能不切速率*/
            BspSetOptSpdChgRecord(1-ulMainPhyOptNo);
            BspSetAxcArrangeTypeByRate(1-ulMainPhyOptNo);
            g_ulAnotherOptSetSpeedCnt[1-ulMainPhyOptNo] = 0;
            if(BspGetOptCpriProtocol(0) == PROCOTOL_IR)
            {
                (VOID)BspHalAdaptSetCpriLineRate(1-ulMainPhyOptNo,ulPhyOptSpd);
                #ifndef _SH_TF_20KM_T12_
                (VOID)BspHalAdaptUpdateFrCfg();
                #endif
                BspLog(LOG_LEVEL_0,"%s@%d>cfg Line Rate & FrCfg\n",__func__, __LINE__);
            }
            BspSetM0FlagAndSpd();
        }
        return OPT_ADPT_STATE_OK;
    }
    else
    {
        return OPT_ADPT_POST_ONE_OPT_STATE;
    }
}

UINT32 g_BspOptAutoAdaptProcess = 1;
void BspOptAutoAdaptProcessOn(UINT32 val)
{
    g_BspOptAutoAdaptProcess = val;
}

UINT32 g_ulCurrMainOpt = BSP_ERROR;
UINT32 g_ulLastMainOpt = BSP_ERROR;
UINT32 BspGetMainOptChgRecord(VOID)
{
    UINT32 ulRet = BSP_OK;
    /*断链 从holdover到识别到主光口*/
    if((g_ulLastMainOpt == BSP_ERROR)&&(g_ulCurrMainOpt != BSP_ERROR))
    {
        ulRet = BSP_ERROR;
    }
    /*主光口倒换*/
    if(g_ulLastMainOpt == 1 - g_ulCurrMainOpt)
    {
        ulRet = BSP_ERROR;
    }

    return ulRet;
}
UINT32 BspSetNbicAccClrByMainOptSta(UINT32 ulPhyOpt)
{
    UINT32 ulRet0 = BSP_OK;
    UINT32 ulRet1 = BSP_OK;

    g_ulCurrMainOpt = ulPhyOpt;
    dbgInfoEx("**g_ulCurrMainOpt %d g_ulLastMainOpt %d **\n",g_ulCurrMainOpt,g_ulLastMainOpt);
    ulRet0 = BspGetMainOptChgRecord();
    g_ulLastMainOpt = g_ulCurrMainOpt;
    if(ulRet0 == BSP_ERROR)
    {
        ulRet1 = BspHalAdaptSetNbicAccClr();
        dbgInfoEx("**BspHalAdaptSetNbicAccClr **\n");
        BspLog(LOG_LEVEL_0,"**BspHalAdaptSetNbicAccClr **\n");  /*切换才记录*/
    }
    return ulRet1;
}

UINT32 BspSetOptTxPriority(UINT32 ulState, UINT32 ulPhyOpt)
{
    UINT32 ulTxPriority = 0;
    UINT32 ulRingFlag = 0;

    ulRingFlag = BspGetOptRingFlag();
    if((ulRingFlag == OPT_SUPPORT_RING) && (BspGetOptCpriProtocol(0) == PROCOTOL_CPRI))
    {
        return BSP_OK;   /*FDD环网不需要*/
    }
    if((ulPhyOpt == BSP_ERROR)||(ulState == OPT_ADPT_STATE_OK))  /*主光口异常或者双光口正常，此时关闭强制转发控制字为下次做准备*/
    {
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_2,0xff,0);  /*自动识别*/
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_3,0xff,0);
        g_ulOptTxPriSendCnt = 0;
        return BSP_OK;
    }
    if(ulRingFlag == OPT_NOT_SUPPORT_RING)
    {
        return BSP_OK;   /*非FDD环网不需要*/
    }

    if(g_ulOptTxPriSendCnt > TXPRI_SEND_MAX_CNT)  /*下联口TX正常，RX异常场景 不能一直强发*/
    {
        BspLog(LOG_LEVEL_0,"**BspSetOptTxPriority **\n");
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_2,0xff,0);  /*自动识别*/
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_3,0xff,0);
        return BSP_OK;
    }
    g_ulOptTxPriSendCnt++;
    ulTxPriority = BspHalAdaptGetFddPriority(ulPhyOpt);
    if(BSP_OK == BspGetOptTxPriorityStatus(ulPhyOpt))
    {
        BspLog(LOG_LEVEL_0,"**ulPhyOpt %d  ulTxPriority 0x%x**\n",ulPhyOpt,ulTxPriority);
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_2,ulTxPriority&0xff,1);
        BspHalAdaptCpriCfgTxPriority(LOG_OPT_3,ulTxPriority&0xff,1);
    }

    return BSP_OK;
}

UINT32 IsMainOptRruIdRangeOK(UINT32 ulPhyOpt)
{
    /* Started by AICoder, pid:71b45m261b5d09d1487309683090570f94b8da56 */
    if(PROCOTOL_CPRI == BspGetOptCpriProtocol(0))
    {  /*单光口 或者主光口是有效配置口  或者主光口是无效配置口但是尝试次数已经达到最大*/
         if ((IsNoneOptLop() != BSP_OK) || (IsNoConfigRruIdRange() ==  BSP_ERROR)||(g_ulUpLinkOptSpeedCfgCnt > UPLINK_OPT_RETRY_MAX_CNT))
         {
              return BSP_OK;
         }
         return BSP_ERROR;
    }
    /* Started by AICoder, pid:71b45m261b5d09d1487309683090570f94b8da56 */
    if (s_CheckRruIdRange) /*处理单上联接双光纤场景*/
    {
        MSG_DBG(MOD_BOARD_OPT, "%s(%d): mainopt%d\n", __FUNCTION__,__LINE__,ulPhyOpt);
        if ((IsNoneOptLop() != BSP_OK) || ((IsNoConfigRruIdRange() ==  BSP_ERROR) && (BspGetRruIdRange(0) !=  0x0))||(g_ulUpLinkOptSpeedCfgCnt > UPLINK_OPT_RETRY_MAX_CNT)) /*只插了一个光口或者主光口是配置光口*/
        {
            MSG_DBG(MOD_BOARD_OPT, "%s(%d): RruIdRange%d\n", __FUNCTION__,__LINE__,BspGetRruIdRange(0));
            return BSP_OK;
        }
        else
        {
            return BSP_ERROR;
        }
    }
    else
    {
        return BSP_OK;
    }
}

UINT32 IsOptAdptStatOK(UINT32 ulState, UINT32 ulNextState)
{
    if ((OPT_ADPT_STATE_OK == ulState) && (OPT_ADPT_STATE_OK == ulNextState))
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}
/* Started by AICoder, pid:5b6dal5eb77c3a5141fc081a5085c113fd14cabc */
UINT32 BspCtrlOptAlarm(UINT32 state, UINT32 nextState)
{
    UINT32 retVal = BSP_OK;
    UINT32 workMode = 0;
    
    (void)BspHalAdaptGetCpriNetMode(&workMode);

    if ((1 == BspGetTddSupportRingModeWorkFlag()) || (NET_MODE_LOAD_SHARE == workMode ))
    {
        retVal = BspSetOptControlAlarm(state, nextState);
    }

    return retVal;
}
/* Ended by AICoder, pid:5b6dal5eb77c3a5141fc081a5085c113fd14cabc */
static VOID BspSfpQsfpCfg(VOID)
{
    if(FUNCLIB_OPT_ADPT_ENABLE == g_ulQsfpCtr)
    {
        BspSfpQsfpCfgProcess();  /*执行时间0.5s左右 电模块热插拔*/
    }
}

static VOID BspAdptSetOptCpriCfgCmUxSel(VOID)
{
    UINT32 ringFlag = 0;

    ringFlag = BspGetOptRingFlag();  /*是否支持环网*/
    if(ringFlag == OPT_NOT_SUPPORT_RING)
    {
        BspSetOptCpriCfgCmUxSel();
    }
}
/*单板起来如果光模块处于环回状态，进行一次解环回操作*/
static VOID BspOptClrLoopBackTest(VOID)
{
    #ifndef MULT_PROGRESS_S
    UINT32 loopStatus = 0;
    UINT32 optNo = 0;
    /*光模块环回处理*/
    for(optNo = 0; optNo < 2; optNo++)
    {
        if (BSP_OK == BspGetOptLoopTestMode(optNo, &loopStatus))
        {
            if (NOT_LOOP_BACK != loopStatus)
            {
                BspClrOptLoopTestMode(optNo);
            }
        }
        //BspPrbsTestCtrl(optNo, OPT_PRBS28, 0);/*关prbs操作 临时回退*/
        //BspPrbsTestCtrl(optNo, OPT_PRBS31, 0);
    }
    /*serdes环回文件存在，进行一次接环回操作*/
    if (BSP_ERROR == BspChkAaxSerdesFile())/*文件不存在，不进行后续操作*/
    {
            BspLog(LOG_LEVEL_0,"%s:AaxSerdesFile not exists \n", __FUNCTION__);
            return;
    }
    for(optNo = 0; optNo < 2; optNo++)/*解环回*/
    {
        BspClrSerdesLoopTestMode(optNo);
    }
    BspDeleteAaxFile();
    #endif
}

UINT32 BspSoftenHdlcRateCapability()
{
    UINT32 ulRet = BSP_OK;
    /*将来需求下来FDD机型都支持7.68M时,去掉判断条件及else代码*/
    if(OPT_SUPPORT_DUAL_BBU == BspGetSupportDualBbuFlag()) /* 支持双BBU机型支持7.68M Hdlc能力上报 */
    {
        ulRet = BspHalAdaptSoftenHdlcRateCapabilityCw(0x7);
        dbgInfoEx("**BspHalAdaptSoftenHdlcRateCapabilityCw **\n");
    }
    else
    {
        ulRet = BspHalAdaptSoftenHdlcRateCapabilityCw(0x0);
        dbgInfoEx("**BspHalAdaptClrHdlcRateCapability **\n");
    }
    return ulRet;
}

/* Started by AICoder, pid:61f24282c7sa7d914c310b96e022f52871794bb6 */
/* FDD环网初始化开启光口状态log记录 */
VOID DetectLogonInit(VOID)
{
    UINT32 ringFlag = 0;

    ringFlag = BspGetOptRingFlag();
    if((ringFlag == OPT_SUPPORT_RING) && (BspGetOptCpriProtocol(0) == PROCOTOL_CPRI))
    {
        DetectLogon(20);
    }
    return;
}
/* Ended by AICoder, pid:61f24282c7sa7d914c310b96e022f52871794bb6 */

/**************************************************************************
 * 函数名称： _BspOptAdptInit
 * 功能描述： 光口速率自适应接口
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
static void * _BspOptAutoAdaptProcess(void *para)
{
    UINT32 ulState = OPT_ADPT_PRE_TWO_OPT_STATE;
    UINT32 ulNextState = OPT_ADPT_PRE_TWO_OPT_STATE;
    UINT32 ulOptNum = BspGetOptNum(); 	
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;
    UINT32 ulOptOk = 0;
    UINT32 ulOptOkCnt = 10;  /*log 不能一直记录*/
    UINT32 ulRet = 0;
    UINT32 protocol = 0;
    UINT32 ulSupportFlag = 0;
    UINT32 ulPhyOpt = 0;

    /* BSP小版本让任务空转 */
    #ifdef BSP_MAKE_VER
    optadptoff();
    #endif
    if(1 != pInfo->ulInited)
    {
        MSG_ERR(MOD_BOARD_OPT, "not init\n");
        sleep(2);
        return NULL;
    }
    if(ulOptNum > OPTMAXNUM) 
    {
        ulOptNum = OPTMAXNUM;
    }
    DetectLogonInit();
    protocol = BspGetOptCpriProtocol(0);
    BspSoftenRruIndexrClose();
    /*尝试配置上一次的光口速率，减少级联中RRU光口自适应的时间 时钟锁定判断有问题 暂时不放开*/
    /* _BspTrytoCfgOptSpeed();*/
    BspOptClrLoopBackTest();/*单板起来如果光模块处于环回状态，进行一次解环回操作；如果serdes环回文件存在进行一次解环回操作，并删除文件*/
    while(1)
    {
        if (0==g_BspOptAutoAdaptProcess)
        {
            break;
        }
        BspSfpQsfpCfg();
        if(FUNCLIB_OPT_ADPT_DISABLE == g_ulOptCtr)
        {
            g_ulOptStatus = FUNCLIB_OPT_ADPT_DISABLE; //实际自适应状态
            pInfo->pFuncDelayMs(1000);
            continue;
        }

        g_ulOptStatus = FUNCLIB_OPT_ADPT_ENABLE;

        BspProtocolAdapt();

        MSG_DBG(MOD_BOARD_OPT, "*************** present ulState = %d ******************\n",ulState);
        switch (ulState)
        {
            case OPT_ADPT_PRE_TWO_OPT_STATE:  /*等待lop告警消除*/
            {
                ulNextState = _BspOptAdptPreTwo();/*光口不在位，或者有LOP告警(或者所有速率都有告警)*/
                break;
            }
           case OPT_ADPT_TWO_OPT_STATE:  /*盲插自适应，寻找上联口（同步设置上下联物理光口）*/
           {
                ulNextState = _BspOptAdptTwo();/*光口在位，且cpri状态无lop告警，但是物理光口有告警事件记录*/
                break;
            }
            case OPT_ADPT_POST_TWO_OPT_STATE:
            {
                ulNextState = _BspOptAdptPostTwo();/*光口在位+无LOP+至少有一个光口无物理光口告警事件记录*/
                break;
            }
            case OPT_ADPT_PRE_ONE_OPT_STATE:
            {
                ulNextState = _BspOptAdptPreOne();/*状态机--单光口自适应pre接口*/
                break;
            }
            case OPT_ADPT_ONE_OPT_STATE:
            {
                ulNextState = _BspOptAdptOne();/*状态机--单光口自适应接口*/
                break;
            }
            case OPT_ADPT_POST_ONE_OPT_STATE:
            {
                ulNextState = _BspOptAdptPostOne();/*状态机--单光口自适应接口*/
                break;
            }
            case OPT_ADPT_STATE_OK:
            {
                ulNextState = _BspOptAdptCheck();/*状态机--光口自适应成功检测接口*/
                break;
            }
            default:
            {
                break;
            }
        }

        BspCtrlOptAlarm(ulState,ulNextState);

        if(protocol == PROCOTOL_CPRI)
        {
            ulRet = BspHalAdaptOptRoeSetHdlcRate();  /*cpri控制字正常之后 解析出来，返回0表示正常 HDLC速率自适应 FDD机型使用*/
            BspSoftenHdlcRateCapability();           /* 支持7.68M HDLC速率能力上报 */
        }
        /*级联场景如果第二级确实有异常，会导致状态机一直无法到OPT_ADPT_STATE_OK*/
        (VOID)BspHalAdaptGetMainPhyOpt(&ulPhyOpt);
        BspSetMainPhyOptChangeStateForApp(0);
        BspSetOptTxPriority(ulNextState,ulPhyOpt);  /*FDD环网时控制字转发控制*/
        BspAdptSetOptCpriCfgCmUxSel();
        BspStartM0ByWorkMode();
        BspConfigFrDir();/*根据当前P值，实时更新psync帧头偏移方向*/
        if(ulPhyOpt != BSP_ERROR)  /*能解出物理光口即认为底层基本状态正常，可以解析出P值*/
        {
           BspSetGnssGpsLogicOpt();/* GNSS从BBU获取帧号需要配置当前主逻辑光口 */
           ulSupportFlag = BspGetLimitTransferSupportFlag();
           if (LIMIT_TRANSFER_SUPPORT_YES == ulSupportFlag)
           {

               /* 光口速率自适应OK, 解析极限传输模式, 解析成功锁存到静态变量中;
                                          解析失败或BBU还未下发, 等待下个光口速率自适应轮询周期解析 */
               BspLimitTransferCtrlWordAnalyze(0);
           }
            (VOID)BspHalAdaptOptCpriCmInit();  /*需要光口锁定之后执行*/
            if (IsMainOptRruIdRangeOK(ulPhyOpt) == BSP_OK) /*处理单上联接双光纤场景*/
            {
                BspSetPcsAlarmMask();
                BspHalAdaptCpriSelfAdaptProtect(0);  /*主光口识别出来就可以放开，因为级联第二级异常状态机可能一直到不了OPT_ADPT_STATE_OK*/
                BspSetCpriOptProperty(1,ulPhyOpt);
                BspOptLogicPortPowProtectSel();  /*非环网的时候逻辑主光口在0 与之前配置一致*/
                BspUpdateShareBaseOptNo(ulPhyOpt);
            }
            BspSetOptCpriFrTestMode(DISABLE);
        }
        else
        {
            BspHalAdaptCpriSelfAdaptProtect(1); /*只要不是处于ok  预期不响应远程复位和掉电告警*/
            BspSetCpriOptProperty(0,0);
            BspSetOptCpriFrTestMode(ENABLE);
        }
        if (IsOptAdptStatOK(ulState, ulNextState) == BSP_OK)
        {
            if(ulOptOk < ulOptOkCnt)
            {
                ulOptOk ++;
                BspLog(LOG_LEVEL_0,"***************current ulState = %d next ulState = %d ulOptOk %d***************\n",ulState,ulNextState,ulOptOk);  /*环网log需求增加 只要不是一直为6 就记录*/
                BspOptAlmCollect();
            }
        }
        else
        {
            ulOptOk = 0;
            BspLog(LOG_LEVEL_0,"***************current ulState = %d next ulState = %d  ulOptOk %d***************\n",ulState,ulNextState,ulOptOk);  /*环网log需求增加 只要不是一直为6 就记录*/
            BspOptAlmCollect();
        }

        if(ulRet != 0)
        {
            ulOptOk = 0;
        }

        /* 状态切换，清除任务的防抖次数计数 */
        if(ulNextState!=ulState)
        {
            g_ulOptAdptSameStageStep = 0;
            ulState=ulNextState;
        }
        MSG_DBG(MOD_BOARD_OPT, "*************** next ulState = %d ***************\n",ulState);
        MSG_DBG(MOD_BOARD_OPT, "\n");
    }
    return NULL;
}


UINT32 BspOptBbuPbRruSetRate_10G(UINT32 ulMainPhyOptNo)
{
    UINT32 ulRet = 0;
    E_OPT_WORKMODE optWorkMode = E_OPT_MODE_QCELL;
    UINT32 udXmacId = 0;
    UINT32 udPortEnPara[16] = {0};

    if (0 == BspQcellGetNeed10gFlag())
    {
        return ulRet;
    }
    /*速率自适应流程开始关掉光口的交换和dif数据,开的地方在光口内部*/
    BspHalAdaptSetSw2TxDstPort(0);
    BspSetQcellMonitorState(1);
    BspQcellGetL2ssTrxpEn(udPortEnPara);
    ulRet = BspQcellSetOptSerdesRate(ulMainPhyOptNo, BSP_OPT_SPEED_10P1376G); /* 配置Serdes */
    BspSysMsDelay(3000);
    ulRet = BspQcellSetOptRoeRate(10000000,BSP_OPT_SPEED_10P1376G); /* roe配置 */
    BspHalNtlXmacCfgPortSpeed(udXmacId,4);/* 重配xmac */
    /* BspHalAdaptPsyncCfg(1); */
    BspHalAdaptRoeSetQcellEthAdjust(0); /* 重配mac(和ROE相关，与XMAC配置无关) */
    ulRet = BspQcellSetOptCpriRate(ulMainPhyOptNo, BSP_OPT_SPEED_10P1376G);/* cpri配置 */
    // ulRet = BspQcellSetCrmOptCpriRefClkSoft(ulMainPhyOptNo); /* 打开恢复钟 */
    BspSysMsDelay(1000);
    BspHalNtlXmacCtrl(optWorkMode,udXmacId, ENABLE);/* 打开xmac */
    BspQcellSetL2ssTrxpEnOn(udPortEnPara); 
    if ( BSP_OK == BspQcellGetOptStatus(ulMainPhyOptNo) ) /* 光口状态ok */
    {
        dbgInfo("opt adapt set 10G rate success !!\n");
        ulRet = BspQcellSetCrmOptCpriRefClkSoft(ulMainPhyOptNo); /* 打开恢复钟 */
        BspHalAdaptSetNbicAccClr(); // 清除NBIC，QCELL预添加，和宏站保持一致
    }
    
    return ulRet;
}

UINT32 BspOptBbuPbRruSetRate_25G(UINT32 ulMainPhyOptNo)
{
    UINT32 ulRet = 0;
    E_OPT_WORKMODE optWorkMode = E_OPT_MODE_QCELL;
    UINT32 udXmacId = 0;
    UINT32 udPortEnPara[16] = {0};

    BspHalAdaptSetSw2TxDstPort(0);
    BspSetQcellMonitorState(1);
    BspQcellGetL2ssTrxpEn(udPortEnPara);
    ulRet = BspQcellSetOptSerdesRate(ulMainPhyOptNo, BSP_OPT_SPEED_24P33024G);
    BspSysMsDelay(3000);
    ulRet = BspQcellSetOptRoeRate(25000000,BSP_OPT_SPEED_24P33024G);
    BspHalNtlXmacCfgPortSpeed(udXmacId,5);
    /* BspHalAdaptPsyncCfg(1); */
    BspHalAdaptRoeSetQcellEthAdjust(0);
    ulRet = BspQcellSetOptCpriRate(ulMainPhyOptNo, BSP_OPT_SPEED_24P33024G);
    // ulRet = BspQcellSetCrmOptCpriRefClkSoft(ulMainPhyOptNo); /* 打开恢复钟 */
    BspSysMsDelay(1000);
    BspHalNtlXmacCtrl(optWorkMode,udXmacId, ENABLE);
    BspQcellSetL2ssTrxpEnOn(udPortEnPara);
    if ( BSP_OK == BspQcellGetOptStatus(ulMainPhyOptNo) ) /* 光口状态ok */
    {
        dbgInfo("opt adapt set 25G rate success !!\n");
        ulRet = BspQcellSetCrmOptCpriRefClkSoft(ulMainPhyOptNo); /* 打开恢复钟 */
        BspHalAdaptSetNbicAccClr(); // 清除NBIC，QCELL预添加，和宏站保持一致
    }
    
    return ulRet;

}

/* Started by AICoder, pid:z1fd0vb45d1c315142300a7610c1db1786f24d86 */
typedef struct tagT_RoeSpeedCfg
{
    UINT32 ulSpeedIdx;
    UINT32 ulRoeSpeed;
}T_RoeSpeedCfg;

T_RoeSpeedCfg tRoeSpeedCfgList[] ={
    {1, 1250000},
    {2, 2500000},
    {3, 3072000},
    {4, 4915200},
    {5, 6144000},
    {6, 12165120},
    {7, 25000000},
};

#define ROE_SPEED_MIN_INDEX (tRoeSpeedCfgList[0].ulSpeedIdx)
#define ROE_SPEED_MAX_INDEX (tRoeSpeedCfgList[NELEMENTS(tRoeSpeedCfgList) - 1].ulSpeedIdx)

/*****************************************************************************
 *  函数名称   : BspOptRruSetRoeModeRate
 *  功能描述   : 提供给APP的接口，配置ROE速率
 *  输入参数   : ptOptRoeModeInfo
 *  输出参数   : 无
 *  返 回 值   : BSP_OK(正常)，其他错误码1-7(异常)
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspOptRruSetRoeModeRate(T_OptRoeModeInfo *ptOptRoeModeInfo)
{
    UINT32 ulRet                       = BSP_OK;
    UINT32 ulLoop                      = 0;
    UINT32 ulXmacId                    = 0;
    UINT32 ulSpeed                     = BSP_OPT_SPEED_24P33024G;  //光口速率
    BOOL roeSpeedCfgFlag               = FALSE;
    T_OPT_ROE_INIT_PARA optRoeInitPara = {0};

    INPUT_POINTER_CHECK(ptOptRoeModeInfo);
    BspLog(LOG_LEVEL_0,"%s>> optNo %u, roeSpeed %u, chipNumDl %u, chipNumUl %u, axcNumDl %u, axcNumUl %u\n", 
    __FUNCTION__, ptOptRoeModeInfo->ulMainPhyOptNo, ptOptRoeModeInfo->ulRoeSpeed, ptOptRoeModeInfo->ulChipNumDl,
    ptOptRoeModeInfo->ulChipNumUl, ptOptRoeModeInfo->ulAxcNumDl, ptOptRoeModeInfo->ulAxcNumUl);
    if(ptOptRoeModeInfo->ulMainPhyOptNo > 1)
    {
        dbgErr("%s>>invalid opt no %u\n", __FUNCTION__, ptOptRoeModeInfo->ulMainPhyOptNo);
        BspLog(LOG_LEVEL_0,"%s>>invalid opt no %u\n", __FUNCTION__, ptOptRoeModeInfo->ulMainPhyOptNo);
        return BSP_SET_ROE_ROATE_ERR_INVALID_OPTNO;
    }

    if((ptOptRoeModeInfo->ulRoeSpeed >= ROE_SPEED_MIN_INDEX) && (ptOptRoeModeInfo->ulRoeSpeed <= ROE_SPEED_MAX_INDEX))
    {
        for(ulLoop = 0; ulLoop < NELEMENTS(tRoeSpeedCfgList); ulLoop++)
        {
            if(ptOptRoeModeInfo->ulRoeSpeed == tRoeSpeedCfgList[ulLoop].ulSpeedIdx)
            {
                optRoeInitPara.roeChanPara[0].rate = tRoeSpeedCfgList[ulLoop].ulRoeSpeed;
                roeSpeedCfgFlag = TRUE;
            }
        }
    }
    if(!roeSpeedCfgFlag)
    {
        dbgErr("%s>>invalid roe speed %u\n", __FUNCTION__, ptOptRoeModeInfo->ulRoeSpeed);
        BspLog(LOG_LEVEL_0,"%s>>invalid roe speed %u\n", __FUNCTION__, ptOptRoeModeInfo->ulRoeSpeed);
        return BSP_SET_ROE_ROATE_ERR_INVALID_SPEED;
    }
    if((ptOptRoeModeInfo->ulAxcNumDl > AXC_MAX_NUM) || (ptOptRoeModeInfo->ulAxcNumUl > AXC_MAX_NUM))
    {
        dbgErr("%s>>invalid axcnumdl %u, axcnumul %u\n", __FUNCTION__, ptOptRoeModeInfo->ulAxcNumDl, ptOptRoeModeInfo->ulAxcNumUl);
        BspLog(LOG_LEVEL_0,"%s>>invalid axcnumdl %u, axcnumul %u\n", __FUNCTION__, 
               ptOptRoeModeInfo->ulAxcNumDl, ptOptRoeModeInfo->ulAxcNumUl);
        return BSP_SET_ROE_ROATE_ERR_INVALID_AXCNUM;
    }

    optRoeInitPara.optWorkMode = E_OPT_MODE_ROE;
    optRoeInitPara.chanMask    = 0x1;
    optRoeInitPara.cwAccu      = 0x1;
    optRoeInitPara.chipNum     = ptOptRoeModeInfo->ulChipNumDl - 1;
    optRoeInitPara.axcDlNum    = ptOptRoeModeInfo->ulAxcNumDl;
    optRoeInitPara.axcUlNum    = ptOptRoeModeInfo->ulAxcNumUl;

    BspHalNtlXmacCtrl(E_OPT_MODE_ROE,ulXmacId, DISABLE);  //固定返回BSP_OK，无需check
    if(0 == BspHalAdaptGetBbuRoeT12())  //方案变更，app多次调用，只有首次需要做时延测量初始化
    {
        ulRet = BspHalAdaptOptQcellInit(&optRoeInitPara);
        if(BSP_OK != ulRet)
        {
            dbgErr("%s>>opt qcell init fail\n", __FUNCTION__);
            BspLog(LOG_LEVEL_0,"%s>>opt qcell init fail\n", __FUNCTION__);
            return BSP_SET_ROE_ROATE_ERR_CELL_INIT;
        }
    }

    ulRet = BspQcellSetOptCpriRate(ptOptRoeModeInfo->ulMainPhyOptNo, ulSpeed);
    if(BSP_OK != ulRet)
    {
        dbgErr("%s>>set opt cpri rate fail\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s>>set opt cpri rate fail\n", __FUNCTION__);
        return BSP_SET_ROE_ROATE_ERR_CPRI_RATE;
    }

    ulRet = BspHalAdaptCpriCfgMux2FrmSel(1);
    if(BSP_OK != ulRet)
    {
        dbgErr("%s>>cfg cpri fr sel fail\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s>>cfg cpri fr sel fail\n", __FUNCTION__);
        return BSP_SET_ROE_ROATE_ERR_CFG_FRMSEL;
    }

    BspSysMsDelay(1000);
    BspHalNtlXmacCtrl(E_OPT_MODE_ROE,ulXmacId, ENABLE);  //固定返回BSP_OK，无需check
    if(BSP_OK == BspQcellGetOptStatus(ptOptRoeModeInfo->ulMainPhyOptNo))  /* 光口状态ok */
    {
        dbgInfo("%s>>opt adapt set 25G rate success !!\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s>>opt adapt set 25G rate success !!\n", __FUNCTION__);
        BspQcellSetCrmOptCpriRefClkSoft(ptOptRoeModeInfo->ulMainPhyOptNo); /* 打开恢复钟 */  //固定返回BSP_OK，无需check
    }
    else
    {
        dbgErr("%s>>get opt status fail\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s>>get opt status fail\n", __FUNCTION__);
        return BSP_SET_ROE_ROATE_ERR_OPT_STATUS;
    }
    
    return ulRet;
}
/* Ended by AICoder, pid:z1fd0vb45d1c315142300a7610c1db1786f24d86 */

/* Started by AICoder, pid:i5437j099es361d1483308d4b0679f12f720ba92 */
UINT32 testSetQcellRate10G(UINT32 ulMainPhyOptNo)
{
    UINT32 ret = 0;

    if (OPTMAXNUM <= ulMainPhyOptNo)
    {
        dbgInfo("opt Number is biger than OPTMAXNUM !!\n");
        return BSP_ERROR;
    }

    dbgInfo(" >>>>>>>>>>>>>>>>>> set opt rate <<<<<<<<<<<<<<<<<<<<<<< \n");
    dbgInfo("Set Rate 10G Start\n");
    ret = BspOptBbuPbRruSetRate_10G(ulMainPhyOptNo);
    dbgInfo("Set Rate 10G End, ret:%d\n", ret);
    dbgInfo(" >>>>>>>>>>>>>>>>>> set opt rate <<<<<<<<<<<<<<<<<<<<<<< \n");

    return ret;
}
/* Ended by AICoder, pid:i5437j099es361d1483308d4b0679f12f720ba92 */

/* Started by AICoder, pid:b39dcm08c0kf8b514d2b0bf9d09f18192c6002c0 */
UINT32 testSetQcellRate25G(UINT32 ulMainPhyOptNo)
{
    UINT32 ret = 0;

/* Started by AICoder, pid:21cd4xb6a1f604214dcb0841c03898028d054487 */
    if (OPTMAXNUM <= ulMainPhyOptNo)
    {
        dbgInfo("opt Number is biger than OPTMAXNUM !!\n");
        return BSP_ERROR;
    }
/* Ended by AICoder, pid:21cd4xb6a1f604214dcb0841c03898028d054487 */

    dbgInfo(" >>>>>>>>>>>>>>>>>> set opt rate <<<<<<<<<<<<<<<<<<<<<<< \n");
    dbgInfo("Set Rate 25G Start\n");
    ret = BspOptBbuPbRruSetRate_25G(ulMainPhyOptNo);
    dbgInfo("Set Rate 25G End, ret:%d\n", ret);
    dbgInfo(" >>>>>>>>>>>>>>>>>> set opt rate <<<<<<<<<<<<<<<<<<<<<<< \n");

    return ret;
}

/* Started by AICoder, pid:kbe94l577dy47af14cfc0b79303c471b882061c8 */
VOID qcellopthelp(VOID)
{
    dbgInfo(">>>>>>>>>>>>>>>>>>>> qcell opt func info <<<<<<<<<<<<<<<<<<<<< \n");
    dbgInfo(">>>>>>>>>> testSetQcellRate25G(UINT32 ulMainPhyOptNo) \n");
    dbgInfo(">>>>>>>>>> testSetQcellRate10G(UINT32 ulMainPhyOptNo) \n");
    dbgInfo(">>>>>>>>>> qcelloptadpton(VOID) \n");
    dbgInfo(">>>>>>>>>> qcelloptadptoff(VOID) \n");
    dbgInfo(">>>>>>>>>> BspSetOptRateAutoDisable(VOID) \n");
    dbgInfo(">>>>>>>>>> BspSetOptRateAutoEnable(VOID) \n");
}
/* Ended by AICoder, pid:kbe94l577dy47af14cfc0b79303c471b882061c8 */

/* Ended by AICoder, pid:b39dcm08c0kf8b514d2b0bf9d09f18192c6002c0 */

UINT32 BspSetOptRateAutoDisable(VOID)
{
    g_qcellUlOptCtr = FUNCLIB_OPT_ADPT_DISABLE;
    return BSP_OK;
}

UINT32 BspSetOptRateAutoEnable(VOID)
{
    g_qcellUlOptCtr = FUNCLIB_OPT_ADPT_ENABLE;
    return BSP_OK;
}

UINT32 BspFixingCurrentMainOpt(UINT32 fixingFlag)
{
    g_fixMainOptCtr = fixingFlag;
    return BSP_OK;
}

UINT32 BspGetOptRateAutoStopState(VOID)
{
    if(FUNCLIB_OPT_ADPT_STOP == g_qcellUlOptCtr )
    {
        return 1;
    }
    return 0;
}
UINT32 BspCheckPhyOptIsLop(UINT32 ulPhyOptId)
{
	return _BspCheckPhyOptIsLop(ulPhyOptId);
}
UINT32 uiM0FirstSwitch = 1;
UINT32 BspSetOptMonitorM0(VOID)
{
	if(uiM0FirstSwitch)
	{
		BspHalAdaptSetSw2TxDstPort(0);
	    uiM0FirstSwitch = 0;
	}
	return BspHalAdaptOptMonitorM0();
}

UINT32 BspGetQcellMonitorState(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal = BspHalAdaptOptGetQcellMonitorState();
    return retVal;
}
VOID BspSetQcellMonitorState(UINT32 ulVal)
{
	BspHalAdapOptSetQcellMonitoState(ulVal);
    return ;
}

/* Started by AICoder, pid:g43eaq4f18l5a9014e7e0a3b50fd240e4235f796 */
UINT32 BspHalGetSuperFrameAdjustFlag(VOID)
{
    return  BspHalGetQcellSuperFrameAdjustFlag();
}
/* Ended by AICoder, pid:g43eaq4f18l5a9014e7e0a3b50fd240e4235f796 */

UINT32 BspSetOptQcellHdReset(UINT32 ulSwitch)
{
	return BspHalAdaptOptQcellHdResetInit(ulSwitch);
}

UINT32 BspSetQcellNrCompSwTable(UINT32 rate)
{
    return BspHalAdaptSetQcellNrCompSwTable(rate);
}

/**************************************************************************
 * 函数名称： _BspOptBbuPbRruAutoAdaptProcess
 * 功能描述： 光口速率自适应接口
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
static void * _BspOptBbuPbRruAutoAdaptProcess(void *para)
{
    UINT32 udXmacId = 0;
    UINT32 ulMaxSpeed = 0;
    ULONG ulMainPhyOptNo = 0;
    UINT32 ulRet = 0;	
    E_OPT_WORKMODE optWorkMode = E_OPT_MODE_QCELL;
    UINT32 udPortEnPara[16] = {0};
#ifndef MULT_PROGRESS_S
    ulMaxSpeed = BspGetSfpMaximalUsedbleSpeed(ulMainPhyOptNo); /*获取光模块速率*/
    (VOID)BspCheckSfpCdrStatus(ulMainPhyOptNo);      /*下来看*/
#endif

    /* 关闭DAC数据，后续添加 */
    /* 尝试配置上次速率， 读取速率，后续添加 */

    BspHalAdaptOptQcellHdResetInit(0);/*未来防止二三级组网自适应提前复位，先关，后面由APP再打开*/
    while(1)
    { 
        /* 速率自适应开关 */
        if(FUNCLIB_OPT_ADPT_DISABLE == g_qcellUlOptCtr)
        {
            BspSysMsDelay(100);
            g_qcellUlOptCtr = FUNCLIB_OPT_ADPT_STOP;
            break;
        }

        BspSysMsDelay(100);
        if ( (BSP_OK == BspHalAdaptQcellAdaptGetOptLinkStatus()) && (BSP_OK == BspHalAdaptCrmOptGetCrpiRefClkSta(ulMainPhyOptNo)) )
        {     
            dbgInfoEx(" OptAdapt: opt sta ok ulRet=%u ! \n", ulRet);
           // BspHalAdaptOptQcellHdResetInit(1);
            continue;
        }

         /*光口有光无光判断*/
        BspSysMsDelay(100); 
        if (BSP_ERROR == _BspCheckPhyOptIsLop(0))
        {
            dbgInfo(" OptAdapt: sfp no light ! \n");
            continue;
        }
        
        if (BSP_OPT_SPEED_10P1376G == ulMaxSpeed) 
        {   
        	BspHalAdaptSetSw2TxDstPort(0);
            /* BspHalAdaptOptQcellHdResetInit(0); */
            BspQcellGetL2ssTrxpEn(udPortEnPara);/* 速率自适应前获取trxp口en情况 */
            ulRet = BspQcellSetOptSerdesRate(ulMainPhyOptNo, BSP_OPT_SPEED_10P1376G); /* 配置Serdes */
            BspSysMsDelay(3000); 
            ulRet = BspQcellSetOptRoeRate(10000000,BSP_OPT_SPEED_10P1376G); /* roe配置 */
            BspHalNtlXmacCfgPortSpeed(udXmacId,4); /* 配置Xmac：10G是4 ，25G是5 森全：放到roe后*/
            /* BspHalAdaptPsyncCfg(1);  影响DIMIMO大遍历，张震沟通，注释掉 */
            BspHalAdaptRoeSetQcellEthAdjust(0); /* 重配mac */
            ulRet = BspQcellSetOptCpriRate(ulMainPhyOptNo, BSP_OPT_SPEED_10P1376G);/* cpri配置 */
            /* 打开DAC数据，后续添加 */
            BspSysMsDelay(1000); 
            BspHalNtlXmacCtrl(optWorkMode,udXmacId, ENABLE);
            BspQcellSetL2ssTrxpEnOn(udPortEnPara);
            if ( BSP_OK == BspQcellGetOptStatus(ulMainPhyOptNo) ) /* 光口状态ok */
            {
                ulRet = BspQcellSetCrmOptCpriRefClkSoft(ulMainPhyOptNo); /* 打开恢复钟 */
                BspHalAdaptSetNbicAccClr(); // 清除NBIC，QCELL预添加，和宏站保持一致
                dbgInfo(" spf_10G_adptTo_10G, succe! \n");
                continue;
            }
                
         
        }
        else if(BSP_OPT_SPEED_24P33024G == ulMaxSpeed)
        {
        	BspHalAdaptSetSw2TxDstPort(0);
            /* BspHalAdaptOptQcellHdResetInit(0); */
            BspQcellGetL2ssTrxpEn(udPortEnPara);
            ulRet = BspQcellSetOptSerdesRate(ulMainPhyOptNo, BSP_OPT_SPEED_24P33024G);
            BspSysMsDelay(3000); 
            ulRet = BspQcellSetOptRoeRate(25000000,BSP_OPT_SPEED_24P33024G); 
            BspHalNtlXmacCfgPortSpeed(udXmacId,5); 
            /* BspHalAdaptPsyncCfg(1);   */
            BspHalAdaptRoeSetQcellEthAdjust(0);
            ulRet = BspQcellSetOptCpriRate(ulMainPhyOptNo, BSP_OPT_SPEED_24P33024G);    
            
            /* 打开DAC数据，后续添加 */
            BspSysMsDelay(1000); 
            BspHalNtlXmacCtrl(optWorkMode,udXmacId, ENABLE);
            BspQcellSetL2ssTrxpEnOn(udPortEnPara); 
            if ( (BSP_OK == BspQcellGetOptStatus(ulMainPhyOptNo))  ) 
            {
                BspQcellSetCrmOptCpriRefClkSoft(ulMainPhyOptNo);/* 打开恢复钟 */
                BspHalAdaptSetNbicAccClr(); // 清除NBIC，QCELL预添加，和宏站保持一致
                dbgInfo("spf_25G_adptTo_25G succe!! \n");
                continue;
            } 

            if(0 == BspQcellGetNeed10gFlag())/* 12T不配10G参数 */
            {
                continue;
            }
                
            dbgInfo(" spf_25G_adptTo_25G failed, start to spf_25G_adptTo_10G!! \n");
            BspQcellGetL2ssTrxpEn(udPortEnPara);
            ulRet = BspQcellSetOptSerdesRate(ulMainPhyOptNo,BSP_OPT_SPEED_10P1376G);
            BspSysMsDelay(3000); 
            ulRet = BspQcellSetOptRoeRate(10000000,BSP_OPT_SPEED_10P1376G);
            BspHalNtlXmacCfgPortSpeed(udXmacId,4); 
            /* BspHalAdaptPsyncCfg(1); */
            BspHalAdaptRoeSetQcellEthAdjust(0);
            ulRet = BspQcellSetOptCpriRate(ulMainPhyOptNo, BSP_OPT_SPEED_10P1376G);             
            /* 打开DAC数据，后续添加 */
            BspSysMsDelay(1000); 
            BspHalNtlXmacCtrl(optWorkMode,udXmacId, ENABLE);
            BspQcellSetL2ssTrxpEnOn(udPortEnPara);
            if ( BSP_OK == BspQcellGetOptStatus(ulMainPhyOptNo) )
            {
                BspQcellSetCrmOptCpriRefClkSoft(ulMainPhyOptNo);/* 打开恢复钟 */
                BspHalAdaptSetNbicAccClr(); // 清除NBIC，QCELL预添加，和宏站保持一致
                dbgInfo("  spf_25G_adptTo_10G succe!! \n"); 
                continue;
            }   

        }
        else
        {
            dbgInfo(" sfp model rate neither 10G nor 25G ! \n");
            continue;

        }

        /*把建链的光口速率写入/ata/optspeed.conf 中 , 后续添加*/
        /* BspSaveLastMatchOptSpeed(); */
    }
    return NULL;
}


/**************************************************************************
 * 函数名称： _BspOptBbuPbRruAutoAdaptProcess
 * 功能描述： 光口速率自适应接口
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 optStaCheckFlag = 1;

UINT32 BspQcellSetOptStaCheckFlag(UINT32 flag)
{
    optStaCheckFlag = flag;
    return BSP_OK;
}

UINT32 BspQcellGetOptStaCheckFlag(VOID)
{
    return optStaCheckFlag;
}

static void * _BspOptQcellCheckOptStaProcess(void *para)
{
    UINT32 checkTimes = 0;
    
    while(1)
    {

        BspSysMsDelay(20);

        if (0 == optStaCheckFlag)
        {
            continue;
        }
        
        if (BSP_ERROR == _BspCheckPhyOptIsLop(0))
        {
            checkTimes = checkTimes + 1;
        }
        else
        {
            checkTimes = 0;
        }

        if(5 <= checkTimes)/* 5次防抖 */
        {
            BspHalAdaptSetCrmOptCrpiRefClkOeDisable(0);/* 关掉恢复钟 */
            checkTimes = 0;
        }
        
    }
    return NULL;
}


static void * _BspQcellCheckOptPsyncSynProcess(void *para)
{
    while(1)
    {
        BspSysMsDelay(3000);
        BspApiRebuildPsyncSyn();
    }
    return NULL;
}
/**************************************************************************
 * 函数名称： _BspOptAdptInit
 * 功能描述： 光口速率自适应信息注册
 * 输入参数： ulOpt:光口号
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2017/04/22  V1.1      10076963        创建
 **************************************************************************/
UINT32 _BspOptAdptInit(T_OptAdaptInfo *pInfo)
{
    T_OptAdaptInfo *pOptInfo = &g_tOptAutoAdaptInfo;
    
    INPUT_POINTER_CHECK(pInfo);

    pOptInfo->ulDelay[OPT_ADPT_PRE_TWO_OPT_STATE] = pInfo->ulDelay[OPT_ADPT_PRE_TWO_OPT_STATE];
    pOptInfo->ulDelay[OPT_ADPT_TWO_OPT_STATE] = pInfo->ulDelay[OPT_ADPT_TWO_OPT_STATE];
    pOptInfo->ulDelay[OPT_ADPT_POST_TWO_OPT_STATE] = pInfo->ulDelay[OPT_ADPT_POST_TWO_OPT_STATE];
    pOptInfo->ulDelay[OPT_ADPT_PRE_ONE_OPT_STATE] = pInfo->ulDelay[OPT_ADPT_PRE_ONE_OPT_STATE];
    pOptInfo->ulDelay[OPT_ADPT_POST_ONE_OPT_STATE] = pInfo->ulDelay[OPT_ADPT_POST_ONE_OPT_STATE];
    pOptInfo->ulDelay[OPT_ADPT_ONE_OPT_STATE] = pInfo->ulDelay[OPT_ADPT_ONE_OPT_STATE];    
    pOptInfo->ulDelay[OPT_ADPT_STATE_OK] = pInfo->ulDelay[OPT_ADPT_STATE_OK];
    pOptInfo->pFuncDelayMs = pInfo->pFuncDelayMs;
    pOptInfo->pFuncSaveOptSpeedRecord = pInfo->pFuncSaveOptSpeedRecord;
    pOptInfo->pFuncGetOptSpeedRecord = pInfo->pFuncGetOptSpeedRecord;
    pOptInfo->pFuncGetOptSfpMaxSpeed = pInfo->pFuncGetOptSfpMaxSpeed;
    pOptInfo->pFuncGetRruOptSurportSpeedList = pInfo->pFuncGetRruOptSurportSpeedList;
    pOptInfo->pFuncCheckPhyOptState = pInfo->pFuncCheckPhyOptState;
    pOptInfo->pFuncCheckPhyOptIsLop = pInfo->pFuncCheckPhyOptIsLop;
    pOptInfo->pFuncCheckLogicOptState = pInfo->pFuncCheckLogicOptState;
    pOptInfo->pFuncOptAdptPreProcess = pInfo->pFuncOptAdptPreProcess;
    pOptInfo->pFuncOptAdptPostProcess = pInfo->pFuncOptAdptPostProcess;
    pOptInfo->pFuncOptSpeedIsEqual = pInfo->pFuncOptSpeedIsEqual;
    pOptInfo->pFuncSetOptSpeed = pInfo->pFuncSetOptSpeed;
    pOptInfo->pFuncReCfgOptRxSerdes = pInfo->pFuncReCfgOptRxSerdes;
    pOptInfo->pFuncGetOptSpeed = pInfo->pFuncGetOptSpeed;
    pOptInfo->pFuncOptIsSync = pInfo->pFuncOptIsSync;
    pOptInfo->pFuncGetOptWorkMode = pInfo->pFuncGetOptWorkMode;
    pOptInfo->pFuncCheckExtSysClkLockState = pInfo->pFuncCheckExtSysClkLockState ;
    pOptInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_ONE_OPT_STATE] =  pInfo->ulJitterAvoidTimes4FuncState[OPT_ADPT_ONE_OPT_STATE];

    pOptInfo->ulInited = 1;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称： _BspOptAdptThreadInit
 * 功能描述： 光口速率自适应进程接口
 * 输入参数： ulOpt:光口号
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 _BspOptAdptThreadInit(void)
{    
	pthread_t th_id = 0;
	UINT32     ulRet = BSP_OK;

	ulRet = pthread_create(&th_id, NULL, _BspOptAutoAdaptProcess, NULL);
    
	if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
    }
    else
    {
        dbgErr("create thread<%s> success!\n",__FUNCTION__);
    }
	return ulRet;
    
}

/**************************************************************************
 * 函数名称： _BspOptBbuPbRruAdptThreadInit
 * 功能描述： qcell光口速率自适应进程接口
 * 输入参数： ulOpt:光口号
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 _BspOptBbuPbRruAdptThreadInit(void)
{    
	pthread_t th_id = 0;
	UINT32     ulRet = BSP_OK;

	ulRet = pthread_create(&th_id, NULL, _BspOptBbuPbRruAutoAdaptProcess, NULL);

	if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
    }
    else
    {
        dbgErr("create thread<%s> success!\n",__FUNCTION__);
    }
	return ulRet;
    
}

/**************************************************************************
 * 函数名称： _BspQcellOptStaCheckThreadInit
 * 功能描述： qcell光口速率光口状态检测线程
 * 输入参数： ulOpt:光口号
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 _BspQcellOptStaCheckThreadInit(void)
{    
	pthread_t th_id = 0;
	UINT32     ulRet = BSP_OK;

	ulRet = pthread_create(&th_id, NULL, _BspOptQcellCheckOptStaProcess, NULL);

	if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
    }
    else
    {
        dbgErr("create thread<%s> success!\n",__FUNCTION__);
    }
	return ulRet;
    
}

/**************************************************************************
 * 函数名称： BspQcellCheckOptPsyncSynThreadInit
 * 功能描述： qcell光口监控同步Psync帧号线程
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 BspQcellCheckOptPsyncSynThreadInit(void)
{   
	UINT32     ulRet = BSP_OK;

#if defined(BSP_MAKE_VER) || defined(_BSP_WITH_WFS) 
    /* 工装不启用该线程 */
    return ulRet;
#else
    pthread_t th_id = 0;

    ulRet = pthread_create(&th_id, NULL, _BspQcellCheckOptPsyncSynProcess, NULL);
#endif

	if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
    }
    else
    {
        dbgErr("create thread<%s> success!\n",__FUNCTION__);
    }
	return ulRet;
    
}

/*PCS告警异常处理*/
UINT32 BspSetPcsAlarmMask(void)
{
    UINT32 ret          = BSP_OK;
    UINT32 sfpNum       = 0;
    UINT32 loop         = 0;
    UINT32 mainOpt      = 0;

    sfpNum  = BspGetSfpNum();
    mainOpt = BspGetMainPhyOpt();

    for(loop = 0; loop < sfpNum; loop ++)
    {
        if(loop == mainOpt)
        {
            ret |= BspSetPcsDataAlarmMask(loop,0xe);
            ret |= BspSetPcsAmpAlarmMask(loop,0xf);
        }
        else
        {
            ret |= BspSetPcsDataAlarmMask(loop,0x1f);
            ret |= BspSetPcsAmpAlarmMask(loop,0x1f);
        }
    }

    return ret;
}

UINT32 BspBifGfCrmRxReset(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptBifGfCrmRxReset();

    return retVal;
}

UINT32 BspJudgeOptSwitchByWorkMode(UINT32 workMode, UINT32 phyOpt)
{
    UINT32 logOpt = 0;
    UINT32 bbuPort = 0xff;
    UINT32 optRingFlag = 0;

    if(BspGetSwitchMainPhyOptFlag() == 1)
    {
        /* 规避短时间内倒换2次，app只能感知到一次 */
        return BSP_OK;
    }

    optRingFlag = BspGetOptShareFlag();
    if((BSP_OPT_WORK_MODE_SHARE == workMode)&&(OPT_SUPPORT_SHARE == optRingFlag))
    {
        if(PROCOTOL_IR == BspGetOptCpriProtocol(0))
        {
            logOpt = BspGetLogicPort(phyOpt);
            bbuPort = BspHalAdaptGetBbuFiberPort(logOpt);    /*符合分担需要通知高层 接的bbu端口是否变化 交叉光纤主光口可能不变*/
            if(0xff == s_LastMainBbuPort)   /*第一次读取*/
            {
                BspLog(LOG_LEVEL_0,"%s: lastBbuPort[%d], currBbuPort[%d]. \n", __FUNCTION__, s_LastMainBbuPort, bbuPort);
                 s_LastMainBbuPort = bbuPort;
            }
            if(0xff == s_LastBaseLogOptForShare)      /*基准光口*/
            {
                BspLog(LOG_LEVEL_0,"%s: lastBaseOptNo[%d], currBaseOptNo[%d]. \n", __FUNCTION__, s_LastBaseLogOptForShare, s_CurrBaseLogOptForShare);
                s_LastBaseLogOptForShare = s_CurrBaseLogOptForShare;
            }

            /* Started by AICoder, pid:3d20fzcf1cn262c14467085d704d270b3115e104 */
            if(0xff == s_LastUpBaseLogOptForShare)      /*上行基准光口*/
            {
                BspLog(LOG_LEVEL_0,"%s: lastUpBaseOptNo[%d], currUpBaseOptNo[%d]. \n", __FUNCTION__, s_LastUpBaseLogOptForShare, s_CurrUpBaseLogOptForShare);
                s_LastUpBaseLogOptForShare = s_CurrUpBaseLogOptForShare;
            }
            /* Ended by AICoder, pid:3d20fzcf1cn262c14467085d704d270b3115e104 */
        }

        if(s_LastMainBbuPort != bbuPort)
        {
            BspLog(LOG_LEVEL_0,"%s: lastBbuPort[%d], currBbuPort[%d]. \n", __FUNCTION__, s_LastMainBbuPort, bbuPort);
            s_LastMainBbuPort = bbuPort;   /*变化时更新*/
            return BSP_ERROR;
        }
        if(s_LastBaseLogOptForShare != s_CurrBaseLogOptForShare)        /*调试时注意初次建链时主光口的识别会比基准光口识别出来的早 但高层流程要保证配时延前基准光口已经报上去 这里应该没问题*/
        {
            BspLog(LOG_LEVEL_0,"%s: lastBaseOptNo[%d], currBaseOptNo[%d]. \n", __FUNCTION__, s_LastBaseLogOptForShare, s_CurrBaseLogOptForShare);
            s_LastBaseLogOptForShare = s_CurrBaseLogOptForShare;   /*变化时更新*/
            return BSP_ERROR;
        }

        /* Started by AICoder, pid:d47c3w7958i9c7f14bda0b9fd049fa0f4da6e2d5 */
        if(s_LastUpBaseLogOptForShare != s_CurrUpBaseLogOptForShare)        /*调试时注意初次建链时主光口的识别会比基准光口识别出来的早 但高层流程要保证配时延前基准光口已经报上去 这里应该没问题*/
        {
            BspLog(LOG_LEVEL_0,"%s: lastUpBaseOptNo[%d], currUpBaseOptNo[%d]. \n", __FUNCTION__, s_LastUpBaseLogOptForShare, s_CurrUpBaseLogOptForShare);
            s_LastUpBaseLogOptForShare = s_CurrUpBaseLogOptForShare;   /*变化时更新*/
            return BSP_ERROR;
        }
        /* Ended by AICoder, pid:d47c3w7958i9c7f14bda0b9fd049fa0f4da6e2d5 */
    }
    if(BSP_OPT_WORK_MODE_RING == workMode)
    {
          /*这里成哥建议增加倒换方向变化也上报倒换  应该交叉光纤 但是主光口不变的场景*/
         dbgInfoEx("wait add\n");
    }
    return BSP_OK;
}
/*记录主光口倒换标志  负荷分担基准光口变化也要通知到高层*/
UINT32 BspSetMainOptSwitchRecord(UINT32 phyOpt)
{
    UINT32 ulAppUpLinkSpd = 0;
    UINT32 ulAppDownLinkSpd = 0;
    UINT32 workMode = BspGetOptWorkMode(0);

    (VOID)BspSetNbicAccClrByMainOptSta(phyOpt);
    if(phyOpt != BSP_ERROR)
    {
        if(s_LastMainPhyOpt == 0xff)
        {
            s_LastMainPhyOpt = phyOpt; /*第一次记录*/
        }
        else
        {   /*主光口变化  或者符合分担场景主光口没变 但是光口连接的bbu端口变化了，BspGetSwitchMainPhyOptFlag:规避短时间内倒换2次，app只能感知到一次 */
            if(((s_LastMainPhyOpt != phyOpt) || (BSP_OK != BspJudgeOptSwitchByWorkMode(workMode, phyOpt)))&& (BspGetSwitchMainPhyOptFlag() == 0)) /* 规避短时间内倒换2次，app只能感知到一次 */
            {
                BspSetSwitchMainPhyOptFlag(1);  /*APP TS用 目前先这样实现 环网可能需要优化*/
                BspSetSwitchoverFlag(1);        /* APP异速率环网设增益用 */
                s_SwitchMainPhyOptFlagLogCnt = 0;
                s_LastMainPhyOpt = phyOpt;
                BspLog(LOG_LEVEL_0,"%s: lastMainPhyOpt[%d], currMainPhyOpt[%d]. \n", __FUNCTION__, s_LastMainPhyOpt, phyOpt);
                ulAppUpLinkSpd = BspLoadOptSpeedFromApp(phyOpt);
                ulAppDownLinkSpd = BspLoadOptSpeedFromApp(1- phyOpt);
                if(ulAppUpLinkSpd != 0 && ulAppDownLinkSpd != 0 && ulAppUpLinkSpd != ulAppDownLinkSpd)
                {
                    if(NULL != pClearCarrGain)
                    {
                        pClearCarrGain();  /* 异速率环网检测到主光口发生变化时清除载波增益 */
                    }
                }
            }
        }
    }

    if((s_LastMainPhyOpt != 0xff)&&((phyOpt == BSP_ERROR)||(s_SwitchMainPhyOptFlag == 1)))
    {
        //BspSetSwitchMainPhyOptFlag(0);  /*高层清*/
        if(PROCOTOL_CPRI != BspGetOptCpriProtocol(0) || s_SwitchMainPhyOptFlagLogCnt % 20 == 0) /* FDD倒换这里log记录太频繁 */
        {
            BspLog(LOG_LEVEL_0,"*************** s_LastMainPhyOpt %d ulPhyOpt %d s_SwitchMainPhyOptFlag %d  s_LastMainBbuPort %d***************\n",s_LastMainPhyOpt,phyOpt,s_SwitchMainPhyOptFlag, s_LastMainBbuPort);  /*切换才记录 不变表示一直卡在这*/
        }
        s_SwitchMainPhyOptFlagLogCnt++;
    }

    return phyOpt;
}

/*TDD:判断当前是否需要设置双上联和自震荡来识别出主光口*/
UINT32 BspGetTddOptFrAndPropertySw(UINT32 phyOpt)
{
    UINT32 swFlag = 0;/*默认值是0，不再有10次防抖，加快环网倒换时间*/
    UINT32 optWorkMode = BspGetOptWorkMode(0);
    UINT32 syncStatus = BspHalAdaptGetOptSyncStatus(phyOpt);

    BspLog(LOG_LEVEL_0,"[%s]:phyOpt[%d], SyncStatus[%d]. \n",__FUNCTION__, phyOpt, syncStatus);
    if(phyOpt != BSP_ERROR)
    {
         if(BSP_ERROR == BspCheckRruIdIsOk())
         {
             g_ulSwCnt++;
         }
         else
         {
             if(OPT_SYNC_OK == BspHalAdaptGetOptSyncStatus(phyOpt))
             {
                 BspSetOptCpriCfgCmUxSel();
                 swFlag = 1;
             }
             g_ulSwCnt = 0;
         }
         if(g_ulSwCnt > TXPRI_ERR_CNT)
         {
             swFlag = 0;
             g_ulSwCnt = 0;
             dbgInfoEx("TxPriority phyOpt %d\n",phyOpt);
             BspLog(LOG_LEVEL_0,"BspGetOptFrAndPropertySw phyOpt %d TxPriority error\n",phyOpt);
         }
    }
    else
    {
        swFlag = 0;
        g_ulSwCnt = 0;
    }

    if((BSP_OPT_WORK_MODE_MAIN_SLAVE == optWorkMode)||(BSP_OPT_WORK_MODE_SHARE == optWorkMode))
    {
        swFlag = 0; /*如果是主备或者负荷分担则需要一直配置双上联*/
    }
    return swFlag;
}

/*判断当前是否需要设置双上联和自震荡来识别出主光口*/
UINT32 BspGetOptFrAndPropertySw(UINT32 phyOpt)
{
    UINT32 swFlag = 0;

    if(phyOpt != BSP_ERROR)
    {
         if(BSP_ERROR == BspGetOptTxPriorityStatus(phyOpt)) /*正常0x38 0xc7 0x83 0x7c*/
         {
             g_ulSwCnt++;
             swFlag = 2;   /* 控制字异常防抖 */
         }
         else
         {
             if(OPT_SYNC_OK == BspHalAdaptGetOptSyncStatus(phyOpt))  /*主光口识别到 且控制字是0x38 或者0x7c 且状态机正常 才说明上联口已经正常 另外那个可以设置为下联口*/
             {
                 swFlag = 1;
             }
             g_ulSwCnt = 0;
         }
         if(g_ulSwCnt > TXPRI_ERR_CNT)  /*主光口解析到 但是控制字异常 说明原来的主光口还没丢*/
         {
             swFlag = 0;
             g_ulSwCnt = 0;
             if(PROCOTOL_CPRI == BspGetOptCpriProtocol(0))
             {
               /* 控制字没识别关断逻辑口0的上下行数据 */
               IcHalApiCpriCfgIqCloseEn(0, ENABLE, RX);
               IcHalApiCpriCfgIqCloseEn(0, ENABLE, TX);
               BspHalAdaptRoeIqSetFlowEnOrDis(RX, 0, 0, DISABLE); /* 关闭接收信令 */
             }
             dbgInfoEx("TxPriority phyOpt %d\n",phyOpt);
             BspLog(LOG_LEVEL_0,"BspGetOptFrAndPropertySw phyOpt %d swFlag %d TxPriority error\n",phyOpt,swFlag);
         }
    }
    else
    {
        swFlag = 0;
        g_ulSwCnt = 0;
    }
     
    return swFlag;
}

VOID BspSetOptSwitchoverFlag(UINT32 flag)
{
    s_OptSwitchoverFlag = flag;
}

/* 根据主从光口控制字判断末级 */
UINT32 BspGetRruLastStageByPriority(UINT32 *isLastStage)
{
    UINT32 phyOpt = 0;
    UINT32 secondPhyOpt = 0;
    UINT32 mainOptPriority = 0xff;
    UINT32 secondOptPriority = 0xff;

    BspHalAdaptGetMainPhyOpt(&phyOpt);
    secondPhyOpt = (phyOpt == PHY_OPT0) ? PHY_OPT1 : PHY_OPT0;
    mainOptPriority = BspHalAdaptGetFddPriority(phyOpt);
    secondOptPriority = BspHalAdaptGetFddPriority(secondPhyOpt);
    if(((mainOptPriority ==0x38) && (secondOptPriority ==0xC7)) ||
       ((mainOptPriority ==0xC7) && (secondOptPriority ==0x38)) ||
       ((mainOptPriority ==0x38) && (secondOptPriority ==0xFF)) ||
       ((mainOptPriority ==0xC7) && (secondOptPriority ==0xFF)))
    {
        *isLastStage = RRU_IS_LAST_STAGE;
    }
    else
    {
        *isLastStage = 0;
    }

    return BSP_OK;
}

UINT32 BspCfgFrameDataByMainOpt(void)
{
    UINT32 logOptLoop = 0;
    UINT32 rruStatus = 0;
    UINT32 phyOpt = 0;
    UINT32 secondPhyOpt = 0;
    UINT32 secondLgcOpt = 0;
    UINT32 hdlcRate = 0;
    UINT32 cmStatus = 0;
    static UINT32 rruStatusOld = 0xff;

    if(0 == BspGetCpriCfgIqCloseSetFlag())
    {
        return BSP_ERROR;
    }
    BspHalAdaptGetMainPhyOpt(&phyOpt);
    if((phyOpt != PHY_OPT0) && (phyOpt != PHY_OPT1))
    {
        BspLog(LOG_LEVEL_0,"[%s]phyOpt Get Err!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(PROCOTOL_CPRI == BspGetOptCpriProtocol(0) && BSP_ERROR == BspGetOptTxPriorityStatus(phyOpt)) /*正常0x38 0xc7 0x83 0x7c*/
    {
        return BSP_ERROR;  /* 主光口识别，控制字无效，防止打开数据 */
    }
    secondPhyOpt = (phyOpt == PHY_OPT0) ? PHY_OPT1 : PHY_OPT0;  /* 获取非主光口的另外一个物理光口号 */

    secondLgcOpt = IcHalApiGetLogOpt(secondPhyOpt);   /* 物理光口号转逻辑光口号 */
    if(secondLgcOpt >= OPT_MAX)
    {
        dbgInfoEx("[%s]secondLgcOpt Get Err!\n",__FUNCTION__);
        return BSP_ERROR;
    }

//    IcHalApiCpriGetRruLastStageFlag(&rruStatus);
    BspGetRruLastStageByPriority(&rruStatus);
    dbgInfoEx("[%s]secondPhyOpt(%d), secondLgcOpt(%d), rruStatus(%d)\n",__FUNCTION__, secondPhyOpt, secondLgcOpt, rruStatus);
    if(rruStatusOld != rruStatus)   /*TDD 不用0x38控制字 这里一直是相等*/
    {
        rruStatusOld = rruStatus;
        if (rruStatus == RRU_IS_LAST_STAGE)
        {
            BspHalAdaptCpriLastStageCm(ENABLE);
            for (logOptLoop = 0; logOptLoop < OPT_MAX; logOptLoop++)
            {
                if (logOptLoop == secondLgcOpt)
                {
                    /* 关断下联逻辑口的上下行数据 */
                    IcHalApiCpriCfgIqCloseEn(logOptLoop, ENABLE, RX);
                    IcHalApiCpriCfgIqCloseEn(logOptLoop, ENABLE, TX);
                }
                else
                {
                    /* 打开下联逻辑口的上下行数据 */
                    IcHalApiCpriCfgIqCloseEn(logOptLoop, DISABLE, RX);
                    IcHalApiCpriCfgIqCloseEn(logOptLoop, DISABLE, TX);
                }
            }
            BspLog(LOG_LEVEL_0,"[%s] open log(0-4) date close log%d date\n",__FUNCTION__,secondLgcOpt);
        }
        else
        {
            BspHalAdaptCpriLastStageCm(DISABLE);
            for (logOptLoop = 0; logOptLoop < OPT_MAX; logOptLoop++)
            {
                /* 打开下联逻辑口的上下行数据 */
                IcHalApiCpriCfgIqCloseEn(logOptLoop, DISABLE, RX);
                IcHalApiCpriCfgIqCloseEn(logOptLoop, DISABLE, TX);
            }
            BspLog(LOG_LEVEL_0,"[%s] open log(0-4) date\n",__FUNCTION__);
        }
        hdlcRate = BspHalAdaptGetOptHdlcRate();
        cmStatus = BspHalAdaptGetCpriLastStageCmStatus();
        BspLog(LOG_LEVEL_0,"[%s] hdlcRate[%u], cmStatus[%u]\n", __FUNCTION__, hdlcRate, cmStatus);
    }

    return BSP_OK;
}


UINT32 BspSetOptProperty(UINT32 phyOpt, UINT32 optWorkMode)
{
    UINT32 mainRruId = 0;
    UINT32 retVal = BSP_OK;
    UINT32 sfpNo = 0;

    if((BspGetTddSupportRingModeWorkFlag() == 1) && (PROCOTOL_IR == BspGetOptCpriProtocol(0)))
    {
        if((phyOpt != BSP_ERROR) && (BSP_OPT_WORK_MODE_MAIN_SLAVE != optWorkMode))
        {
            sfpNo = BspGetSfpNoByPhyNo(phyOpt);
            if(BSP_ERROR == sfpNo)
            {
                return BSP_ERROR;
            }
            mainRruId = BspGetRruId(sfpNo);
            if((mainRruId == 0) || (mainRruId >= 254))
            {
                retVal |= BspChangeOptProperty(0, phyOpt);
            }
        }

        retVal |= BspSetOptControlAlarmByOptAlarm(); /*软件报告警,硬件告警已关闭*/
    }

    return retVal;
}

UINT32 BspSetMainOptByForceMode(UINT32 phyOpt)
{
    UINT32 forcePhyOpt = phyOpt;

    if(BspGetForceSetMainOptMode() == OPT_FORCE_OPT0 && phyOpt == 1)
    {
        BspForceSetMainOpt(0);   /* 固定主光口0失败，主光口1没丢，重设一次 */
        forcePhyOpt = 0;
    }
    if(BspGetForceSetMainOptMode() == OPT_FORCE_REVERSE && phyOpt != BSP_ERROR)
    {
        forcePhyOpt = BspGetCurrReverseMainOpt();   /* 反向倒换，防止主光口识别原光口 */
    }

    return forcePhyOpt;
}

VOID BspOptCpriCwOptBindInit(VOID)
{
   if(OPT_SUPPORT_DUAL_BBU == BspGetSupportDualBbuFlag()) /* 支持双BBU机型固定FEC开 */
   {
       BspSetCpriCfgCasTransMode(1,0);
       BspSetOptCpriCwOptBindCfg(0,2);
       BspSetOptCpriCwOptBindCfg(2,0);
       BspSetOptCpriCwOptBindCfg(1,3);
       BspSetOptCpriCwOptBindCfg(3,1);
    }
}

UINT32 BspShareModeBandOpt(VOID)
{
    UINT32 mainLogOpt = 0;
    UINT32 retVal = BSP_OK;

    BspHalAdaptGetMainLogicOpt(&mainLogOpt);
    if(mainLogOpt != BSP_ERROR)
    {
        BspSetUpDownLinkOptNum(1, 0, 2);
        /* 负荷分担控制字转发需要绑定到主逻辑口，否则主逻辑口切换到1会有异常告警 */
        retVal |= BspSetOptCpriCwOptBindCfg(0, 1);
        retVal |= BspSetOptCpriCwOptBindCfg(1, 0);
        retVal |= BspSetOptCpriCwOptBindCfg(2, mainLogOpt);
        retVal |= BspSetOptCpriCwOptBindCfg(3, mainLogOpt);
    }

    return retVal;
}


/* Started by AICoder, pid:m75fbv8cbazeabe1416c0bd540a2ac51d5a3de19 */
UINT32 BspCheckLofCloseTx(VOID)
{
    UINT32 retVal  = BSP_OK;
#ifndef MULT_PROGRESS_S
    UINT32 optNum = 0;
    UINT32 phyOptIndex = 0;
    UINT32 lopAlarm = 0;
    UINT32 losAlarm = 0;
    UINT32 lofAlarm = 0;
    UINT32 times = 5;
    UINT32 timesIndex = 0;
    UINT32 closeTimes = 10;
    UINT32 sfpNo = 0;

    optNum = BspGetOptNum();
    if(optNum > OPTMAXNUM)
    {
        optNum = OPTMAXNUM;
    }

    g_ulCloseTxFlag ++;
    /*tdd一次倒换任务进入BspChangeOptProperty在0.5-0.6s之间
    临时改动 双bbu下需要4s内再关光一次 */
    if(SUPPORT_DOUBLE_BBU_MAIN_SLAVE == BspGetSupportDoubleBBUMainSlaveFlag())
    {
        closeTimes = 3;
    }

    if(g_ulCloseTxFlag <= (closeTimes))
    {
        return BSP_OK;
    }

    for(phyOptIndex = 0; phyOptIndex < optNum; phyOptIndex++)
    {
        retVal = BspGetOptPhyStatus(phyOptIndex, &lopAlarm, &losAlarm, &lofAlarm);
        for(timesIndex = 0; timesIndex < times; timesIndex ++)
        {
            if(lofAlarm == 1)
            {
                BspSysMsDelay(20);
            }
            else
            {
                break;
            }
            retVal |= BspGetOptPhyStatus(phyOptIndex, &lopAlarm, &losAlarm, &lofAlarm);
        }

        sfpNo = BspGetSfpNoByPhyNo(phyOptIndex);
        /* 检测到lof告警关光100ms,规避拔RRU RX光纤bbu收不到告警问题 */
        if((lofAlarm == 1) && (0x1 != BspIsSpecialQsfp(sfpNo)) && (0 == BspGetOptVirtualAbsentConf(sfpNo)))
        {
            BspCtrlDownLinkOptSta(phyOptIndex, 1);
            BspLog(LOG_LEVEL_0,"[%s]: lofAlarm: %d,  g_ulCloseTxFlag: %d closeTimes = %d, \n", __FUNCTION__, lofAlarm, g_ulCloseTxFlag, closeTimes);
        }
        dbgInfoEx("%s: phyOptIndex[%d]. \n", __FUNCTION__, phyOptIndex);
        BspSysMsDelay(100);  /* 延时100MS后打开，足够时间让BBU检测到lop */
        BspCtrlDownLinkOptSta(0, 0);
    }
    g_ulCloseTxFlag = 0;
#endif
    return retVal;
}
/* Started by AICoder, pid:cda40w270al3e71146110b6ef0477304e8666cba */
UINT32 g_ulAxcProEnable = ENABLE;

VOID BspSetAxcProEnable(UINT32 flag)
{
    g_ulAxcProEnable = flag;
}
/* Ended by AICoder, pid:cda40w270al3e71146110b6ef0477304e8666cba */
/* Ended by AICoder, pid:m75fbv8cbazeabe1416c0bd540a2ac51d5a3de19 */
UINT32 BspSetMainPhyOptChangeStateForApp(UINT32 scene)   /*这里要把9614e d4排除掉 本次不交付*/
{
    UINT32 currMainNo = 0;
    static UINT32 recMainNo = 2;

    if ((BspGetRpuNum() < 2)||(ENABLE != g_ulAxcProEnable))    // 单片机型不需要 特定机型不需要
    {
        return BSP_OK;
    }
    BspHalAdaptGetMainPhyOpt(&currMainNo);
    if ((FUNCLIB_OPT_ADPT_DISABLE == g_ringOptSwitch)&&(0 == scene))
    {
        BspSetMainPhyOptChangeState(currMainNo,recMainNo);
        recMainNo = currMainNo;
    }
    else if ((FUNCLIB_OPT_ADPT_ENABLE == g_ringOptSwitch)&&(0 != scene))  /*else if避免先起自适应 再起倒换切换的时刻 2个分支都执行*/
    {
        BspSetMainPhyOptChangeState(currMainNo,recMainNo);
        recMainNo = currMainNo;
    }
    else
    {
        dbgInfoEx("not need this function\n");
    }
    return BSP_OK;
}

/* Started by AICoder, pid:m6b88a2f2eu6d98146d40ba5a039765b5e236065 */
UINT32 BspCheckPhy0ChangeMain(UINT32 mainPhyNo)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 mainLog = 0;
    T_OptAdaptInfo *pInfo = &g_tOptAutoAdaptInfo;

    INPUT_POINTER_CHECK(pInfo->pFuncCheckPhyOptState);
    INPUT_POINTER_CHECK(pInfo->pFuncCheckLogicOptState);
    
    if(BSP_OK == pInfo->pFuncCheckPhyOptState(PHY_OPT_0))
    {
        mainLog =  BspGetLogicPort(mainPhyNo);
        BspLog(LOG_LEVEL_0, "%s  mainlogNo = %d\n", __FUNCTION__, mainLog);
        if (BSP_OK == pInfo->pFuncCheckLogicOptState(1 - mainLog))
        {
            retVal = BSP_OK;
        }
    }

    return retVal;
}

UINT32 BspLinkWithPhy0Priority(VOID)
{
    UINT32 phyOpt = 0;
    UINT32 retVal = BSP_OK;

    phyOpt = BspGetMainPhyOpt();
    if(BSP_ERROR == phyOpt)
    {
        return retVal;
    }
    else if (PHY_OPT_0 == phyOpt)
    {
        BspSetpriorityLinkByPhy0Flag(NOT_TRY_LINK_WITH_PHY0);
        BspLog(LOG_LEVEL_0, "%s main opt = 0, ok!\n", __FUNCTION__);
        return retVal;
    }
    else
    {
        BspLog(LOG_LEVEL_0, "%s  main opt = %d, check 0\n", __FUNCTION__, phyOpt);
        if (BSP_OK == BspCheckPhy0ChangeMain(phyOpt))
        {
            BspLog(LOG_LEVEL_0, "%s change mainphy to 0!\n", __FUNCTION__);
            /*设置0上联 1下联修改主光口为0*/
            retVal = BspHalAdaptCpriCfgOptProperty(0,0,1,0);
            retVal |= BspHalAdaptCpriCfgOptProperty(1,1,1,0); 
        }
        BspSetpriorityLinkByPhy0Flag(NOT_TRY_LINK_WITH_PHY0);
    }
    return retVal;
}
/* Ended by AICoder, pid:m6b88a2f2eu6d98146d40ba5a039765b5e236065 */


UINT32 BspTryLinkWithPhy0(VOID)
{
    if ((TRY_LINK_WITH_PHY0 == BspGetpriorityLinkByPhy0Flag()) && (SUPPORT_2BBU_MAIN_SLAVE == BspGetSupport2BbuMainSlaveFlag()))
    {
        BspLinkWithPhy0Priority();
    }
    return BSP_OK;
}

/*环网时光口倒换任务*/
VOID BspChkOptSwitchoverIsr(VOID)
{
    UINT32 phyOpt = 0;
    UINT32 swFlag = 0;
    UINT32 optWorkMode = 0;
    UINT32 optSwitchoverTimes = 0;
    UINT32 uTimes = 20;  /* TDD倒换任务保持200ms */
    UINT32 retVal = BSP_OK;

/* BSP小版本让任务空转 */
#ifdef BSP_MAKE_VER
    g_qcellUlOptCtr = FUNCLIB_OPT_ADPT_DISABLE;
#endif

    if(PROCOTOL_IR != BspGetOptCpriProtocol(0)) /* 非FDD环网固定信令路由 */
    {
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_0,LOG_OPT_0);
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_1,LOG_OPT_1);
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_2,LOG_OPT_2);
        BspHalAdaptCpriCfgCmUxSel(LOG_OPT_3,LOG_OPT_3);
        BspOptCpriCwOptBindInit();
    }
    while(1)
    {
        if(RRU_PB_BBU == BspGetPbOrBbuMode())
        {
            break;   /*qcell 接PB 不需要如下流程*/
        }
        BspSysMsDelay(10);

        if(FUNCLIB_OPT_ADPT_DISABLE == g_qcellUlOptCtr || g_fixMainOptCtr == FUNCLIB_OPT_ADPT_ENABLE)
        {
            g_ringOptSwitch = FUNCLIB_OPT_ADPT_DISABLE;
            BspSysMsDelay(1000);
            continue;
        }
        g_ringOptSwitch = FUNCLIB_OPT_ADPT_ENABLE;

        BspSetMainPhyOptChangeStateForApp(1);
        retVal = BspCfgCpriFrLoopModeAndLoopBack();
        if(BSP_OK != retVal)
        {
            dbgInfoEx("not support double uplink\n");
            continue;
        }

        if(PROCOTOL_IR == BspGetOptCpriProtocol(0))
        {
            if(optSwitchoverTimes >= uTimes)
            {
                BspHalAdaptGetMainPhyOpt(&phyOpt);
                optWorkMode = BspGetOptWorkMode(0);
                if((BspGetTddSupportRingModeWorkFlag() == 1) && ((BSP_OPT_WORK_MODE_RING == optWorkMode) || (BSP_OPT_WORK_MODE_MAIN_SLAVE == optWorkMode)))
                {
                    swFlag = BspGetTddOptFrAndPropertySw(phyOpt);
                    BspChangeOptProperty(swFlag, phyOpt);

                }
                else
                {
                    if(BSP_OPT_WORK_MODE_SHARE == optWorkMode)
                    {
                        (VOID)BspShareModeBandOpt();
                        /*负荷分担需要上报倒换标志*/
                        BspSysMsDelay(100);
                        BspSetMainOptSwitchRecord(phyOpt);
                    }
                    swFlag = BspGetOptFrAndPropertySw(phyOpt);
                    BspSetOptFrAndProperty(swFlag, phyOpt);
                }
            }
            BspTryLinkWithPhy0();
        }
        else /* fdd流程 */
        {
            BspHalAdaptGetMainPhyOpt(&phyOpt);
            BspSetMainOptSwitchRecord(phyOpt);
            phyOpt = BspSetMainOptByForceMode(phyOpt);
            swFlag = BspGetOptFrAndPropertySw(phyOpt);
            BspSetFddOptFrAndProperty(swFlag, phyOpt);
        }

        if(optSwitchoverTimes >= uTimes)
        {
            optSwitchoverTimes = 0;
            BspSetOptProperty(phyOpt, optWorkMode);
            (VOID)BspCfgFrameDataByMainOpt();
        }
        optSwitchoverTimes++;

        dbgInfoEx("swFlag %d\n",swFlag);
#ifdef UT_FT_TEST
        return;
#endif
    }
}

UINT32 BspSetGnssGpsLogicOpt(void)
{
    UINT32 mainLogicOpt = 0;
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptGetMainLogicOpt(&mainLogicOpt);
    if (BSP_OK != g_tOptAutoAdaptInfo.pFuncCheckLogicOptState(mainLogicOpt))
    {
        BspLog(LOG_LEVEL_0, "%s Check MainLogOpt failed, mainLogicOpt[%d]. \n", __FUNCTION__, mainLogicOpt);
        return BSP_ERROR;
    }

    retVal |= BspSetCpriGpsFrSel(mainLogicOpt);
    retVal |= BspSetCpriGpsBfnSel(mainLogicOpt);

    return retVal;
}

UINT32 BspCtrlDownLinkOptSta(UINT32 downLinkOpt, UINT32 close)
{
    UINT32 retVal = BSP_OK;
    UINT32 optMask = 0;
    UINT32 optBitVal = 0;
    INPUT_PHYOPT_INDEX_CHECK(downLinkOpt)

    if(1 == close)
    {
     /* 打开前两个光口的掩码 */
        optMask = 0;
        optBitVal = BIT_SET(downLinkOpt);
    }
    else
    {
        optMask = 3;
        optBitVal = 0;
    }

    retVal |= BspSetOptCpriCfgSfpTxDisable(optBitVal,optBitVal);
    retVal |= BspSetOptCpriCfgIoTxDisableMask(optMask);

    return retVal;
}

/*双上联时绑定逻辑光口和物理光口关系： O:0,1:1*/
UINT32 BspSetOpttRelarionAlrm(UINT32 mainPhy)
{
    UINT32 retVal = BSP_OK;
    UINT32 optWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);

    if((BSP_OPT_WORK_MODE_MAIN_SLAVE == optWorkMode) && (mainPhy != BSP_ERROR))
    {
        if(SUPPORT_DOUBLE_BBU_MAIN_SLAVE == BspGetSupportDoubleBBUMainSlaveFlag())
        {
            retVal |= BspSetOptCpriRelation(0,0,1);
            retVal |= BspSetOptCpriRelation(1,1,1);
        }
        else
        {
            retVal |= BspSetOptCpriRelation(0,mainPhy,1);
            retVal |= BspSetOptCpriRelation(1,1 - mainPhy,1);
        }
        
        retVal |= BspSetOptCpriRelation(2,0,0);
    }
    else
    {
        retVal |= BspSetOptCpriRelation(0,0,1);
        retVal |= BspSetOptCpriRelation(1,1,1);
        retVal |= BspSetOptCpriRelation(2,0,0);
    }
    
    retVal |= BspSetOptCfgOptBindValid(0 ,0x0000000f);
    retVal |= BspCtrlDownLinkOptSta(0,0);

    s_downOptNormalTime = 0;
    return retVal;
}

/*主光口0时绑定逻辑光口和物理光口关系： O:0,2:1，末级且有lof告警时关闭光口输出再打开，解决IC主光口切换不报下联口告警故障 */
static UINT32 BspSetMainOpt0Relation(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulLopAlarm = 0;
    UINT32 ulLosAlarm = 0;
    UINT32 ulLofAlarm = 0;
    UINT32 lastRru = 0;

    retVal |= BspSetOptCpriRelation(0,0,1);
    retVal |= BspSetOptCpriRelation(1,0,0);
    retVal |= BspSetOptCpriRelation(2,1,1);
    retVal |= BspSetOptCpriCwOptBindCfg(0,2);
    retVal |= BspSetOptCpriCwOptBindCfg(2,0);
    retVal |= BspGetOptPhyStatus(1, &ulLopAlarm, &ulLosAlarm, &ulLofAlarm);
    retVal |= BspSetOptCpriGetRruLastStageFlag(&lastRru);
#ifndef MULT_PROGRESS_S
    if((ulLofAlarm == 1) && ((lastRru & 0x1) == 1) && (0x1 != BspIsSpecialQsfp(1)))
    {
        s_downOptNormalTime ++;
        BspLog(LOG_LEVEL_0,"time[%d]\n", s_downOptNormalTime);
        if(s_downOptNormalTime <= 3)
        {
            retVal |= BspCtrlDownLinkOptSta(1,1);
        }
        else if(s_downOptNormalTime <= 20)
        {
            retVal |= BspCtrlDownLinkOptSta(0,0);
        }
        else
        {
            s_downOptNormalTime = 0;
        }
    }
    else
    {
        s_downOptNormalTime = 0;
        retVal |= BspCtrlDownLinkOptSta(0,0);
    }
#endif
    return retVal;
}

/*主光口1时绑定逻辑光口和物理光口关系： O:0,2:1，末级且有lof告警时关闭光口输出再打开，解决IC主光口切换不报下联口告警故障 */
static UINT32 BspSetMainOpt1Relation(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulLopAlarm = 0;
    UINT32 ulLosAlarm = 0;
    UINT32 ulLofAlarm = 0;
    UINT32 lastRru = 0;

    retVal |= BspSetOptCpriRelation(2,0,1);
    retVal |= BspSetOptCpriRelation(1,1,1);
    retVal |= BspSetOptCpriRelation(0,0,0);
    retVal |= BspSetOptCpriCwOptBindCfg(1,0x2);
    retVal |= BspSetOptCpriCwOptBindCfg(2,0x1);
    retVal |= BspGetOptPhyStatus(0, &ulLopAlarm, &ulLosAlarm, &ulLofAlarm);
    retVal |= BspSetOptCpriGetRruLastStageFlag(&lastRru);
#ifndef MULT_PROGRESS_S
    if((ulLofAlarm == 1) && ((lastRru & 0x1) == 1) && ((0x1 != BspIsSpecialQsfp(0))))
    {
        s_downOptNormalTime ++;
        BspLog(LOG_LEVEL_0,"time[%d]\n", s_downOptNormalTime);
        if(s_downOptNormalTime <= 3)
        {
            retVal |= BspCtrlDownLinkOptSta(0,1);
        }
        else if(s_downOptNormalTime <= 20)
        {
            retVal |= BspCtrlDownLinkOptSta(0,0);
        }
        else
        {
            s_downOptNormalTime = 0;
        }
    }
    else
    {
        s_downOptNormalTime = 0;
        retVal |= BspCtrlDownLinkOptSta(0,0);
    }
#endif
    return retVal;
}

/*环网时光口倒换任务初始化*/
UINT32 BspChangeOptProperty(UINT32 swFlag, UINT32 phyOpt)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s : %d  swFlag [%d], phyOpt[%d]. \n", __FUNCTION__ ,  __LINE__,  swFlag, phyOpt);
    if(swFlag == 0)
    {
        retVal |= BspSetDoubleUpLinkOpt();
        retVal |= BspSetOpttRelarionAlrm(phyOpt);
        retVal |= BspCheckLofCloseTx();
        BspLog(LOG_LEVEL_0,"time[%d]\n", s_downOptNormalTime);
    }
    else
    {
        BspSetOptCfgOptBindValid(1 ,0x0000000f);
        if(phyOpt == 0)
        {
            retVal |= BspSetDownLinkOpt(phyOpt);
            retVal |= BspSetMainOpt0Relation();
        }
        else if(phyOpt == 1)
        {
            retVal |= BspSetDownLinkOpt(phyOpt);
            retVal |= BspSetMainOpt1Relation();
        }
        else
        {
            dbgInfo("%s : %d  swFlag [%d], phyOpt[%d]. \n", __FUNCTION__ ,  __LINE__,  swFlag, phyOpt);
            BspLog(LOG_LEVEL_0, "%s : %d  swFlag [%d], phyOpt[%d]. \n", __FUNCTION__ ,  __LINE__,  swFlag, phyOpt);
        }
    }
    BspSysMsDelay(100);
    BspSetMainOptSwitchRecord(phyOpt);

    return retVal;
}

UINT32 BspChkOptSwitchOverThreadInit(VOID)
{
    UINT32 ulRet = BSP_OK;
    static INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;
    UINT32 ringFlag = 0;
    UINT32 shareFlag = 0;
    UINT32 enFlag = 0;

    ringFlag = BspGetOptRingFlag();  /*是否支持环网*/
    shareFlag = BspGetOptShareFlag();
    enFlag = BspGetOptInnerCpriFrModeEn();
    /*既不支持环网又不支持符合分担时不启动倒换任务*/
    if((ringFlag == OPT_NOT_SUPPORT_RING) && (shareFlag == OPT_NOT_SUPPORT_RING)&&(OPT_INNER_CPRI_FR_LOOP_MODE_OFF == enFlag))
    {
        return BSP_OK;
    }
    if (lTaskID != ((INT32)BSP_ERROR))
    {
        return BSP_ERROR;
    }

    lTaskID = taskSpawn("BspChkOptSwitchoverThread", 100, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspChkOptSwitchoverIsr, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgInfo("!!! Creat BspChkOptSwitchoverThread Error !!!\n");
        ulRet = BSP_ERROR;
    }

    return ulRet;
}


UINT32 BspInitOptInfoStatusThread(VOID)
{
    UINT32 retVal = BSP_OK;

#ifndef MULT_PROGRESS_S
    retVal |= BspGetOptSupportWayCallBack((SFP_FUNC_GETOPTSUPPORTWAY)BspGetOptSupportWayFlag);
    retVal |= BspSetSfpInfoUpdateSw(OPT_EEPROM_INFO_UPDATE);
    retVal |= BspSfpModuleInfoUpdate();
#endif

    return retVal;
}

/*****************************************************************************
 * 函数名称: BspSetSuperFrameNo
 * 功能描述: 三 超帧号同步功能实现
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSuperFrameNo(T_UtdoaSuperFrameCfg * pUtdoaSuperFrameCfg)
{
	UINT32 ulFrameNo = 0;
	UINT32 ulSuperFrameNo = 0;
	UINT32 psyncFrameNo = 0;
    UINT32 retVal = BSP_OK;
    UINT32 uiSecondpsyncFrameNo = 0;
    UINT32 uiLocalSuperFrameNo = 0;
	/*保存维测*/
	memcpy_s(&s_pUtSuperFrameCfg,sizeof(T_UtdoaSuperFrameCfg),pUtdoaSuperFrameCfg,sizeof(T_UtdoaSuperFrameCfg));
    BspSysMsDelay(12);//规避主片和从片帧头调整量不一致的问题
	psyncFrameNo = BspGetSynPsyncFrameNo();
    if(psyncFrameNo > 1021)//芯片不允许1023帧配置超帧号
    {
        BspSysMsDelay(42);
        psyncFrameNo = BspGetSynPsyncFrameNo();
    }
	ulSuperFrameNo = pUtdoaSuperFrameCfg->ulSuperFrameNo;
	ulFrameNo = pUtdoaSuperFrameCfg->ulFrameNo;
    if(ulFrameNo > psyncFrameNo)
    {
        ulSuperFrameNo++;
        if(ulSuperFrameNo > 1023)
        {
            ulSuperFrameNo = 0;
        }
    }
	retVal = BspSetSynPsyncSuperFrameNo(ulSuperFrameNo);

    BspSysMsDelay(12);//超帧号配置完成后，需要等下一个帧生效
	 /*超帧号校验流程*/
	uiLocalSuperFrameNo = BspHalAdaptGetSynPsyncSuperFrameNo();
	uiSecondpsyncFrameNo = BspGetSynPsyncFrameNo();
	if( (uiLocalSuperFrameNo == ulSuperFrameNo) && (uiSecondpsyncFrameNo >= psyncFrameNo) )
	{
		return BSP_OK;
	}
	if( (uiLocalSuperFrameNo == ulSuperFrameNo) && (uiSecondpsyncFrameNo < psyncFrameNo) )
	{
		retVal = BspSetSynPsyncSuperFrameNo( (uiLocalSuperFrameNo+1) %1024  );
		return retVal;
	}
	if( (uiLocalSuperFrameNo ==  ((ulSuperFrameNo+1) %1024)) && (uiSecondpsyncFrameNo < psyncFrameNo))
	{
		return BSP_OK;
	}

	return BSP_ERROR;
}

/*BSP上报给APP获取超帧号接口*/
UINT32 BspGetSynPsyncSuperFrameNo(VOID)
{
    UINT32 ulLocalSuperFrameNo  = 0;
    UINT32 ulSecondSuperFrameNo = 0;
    UINT32 ulTryTimes = 0;

    /*获取超帧号采用ABA的方式获取，保证两个超帧号数据在同一时间段内没有发生进位*/
    for(ulTryTimes = 0; ulTryTimes < 3; ulTryTimes++)
    {
        ulLocalSuperFrameNo = BspHalAdaptGetSynPsyncSuperFrameNo();
        ulSecondSuperFrameNo = BspHalAdaptGetSynPsyncSuperFrameNo();
        if(ulLocalSuperFrameNo == ulSecondSuperFrameNo)
        {
            break;
        }
    }
    /*尝试3次获取，3次失败后停止尝试且不发消息*/
    if(3 == ulTryTimes)
    {
        return BSP_ERROR;
    }
    return ulSecondSuperFrameNo;
}

static UINT32 BspGetlogOptAlarmCurr(UINT32 phyOpt)
{
    UINT32 logOpt = 0;
    UINT32 logOptAlarmCurr = 0;

    //物理转逻辑
    logOpt = BspHalAdaptGetLogOpt(phyOpt);
    if (logOpt == BSP_ERROR)
    {
        logOptAlarmCurr = 0x5a5a;
    }
    else
    {
        logOptAlarmCurr = BspHalAdaptGetCpriLogOptAlm(logOpt);
        logOptAlarmCurr &= 0x28f;
    }
    return logOptAlarmCurr;
}

UINT32 BspLastStageIsOK()
{
    UINT32 retVal = BSP_ERROR;
    UINT32 clkStatus = 0;
    UINT32 rruStatus = 0;
    UINT32 mainPhyOpt = 0;

    BspHalAdaptDpdicRegRd(0,0xc2403410,0,&mainPhyOpt);
    IcHalApiCpriGetRruLastStageFlag(&rruStatus);
    BspHalAdaptGetSysLd(0,&clkStatus);
    if (rruStatus == RRU_IS_LAST_STAGE && mainPhyOpt != 0xff && clkStatus == 0)
    {
        retVal = BSP_OK;
    }

    return retVal;
}

UINT32 DetectLogon(UINT32 time)
{
    if(time != 0)
    {
        s_detectLogTime = time;
    }
    if(1 == s_DetectSw)
    {
        return BSP_OK;
    }
    dbgInfo("DetectLogon \n");
    s_DetectSw = 1;
    BspDetectThreadInit();
    return BSP_OK;
}

UINT32 DetectLogoff(VOID)
{
    s_DetectSw = 0;
    return BSP_OK;
}

static UINT32 BspGetDetectSw(VOID)
{
    return s_DetectSw;
}

VOID HalIcDetectThread(VOID)
{
    UINT32 firstProrityCurr = 0;
    UINT32 secndProrityCurr = 0;
    UINT32 firstPrority = 0xff;
    UINT32 secndPrority = 0xff;
    UINT32 mainPhyOptCurr = 0;
    UINT32 mainPhyOpt = 0;
    UINT32 testModeCurr = 0;
    UINT32 testMode = 0;
    UINT32 opt0_pcs_sta = 0;
    UINT32 opt0_pcs_sta_curr = 0;
    UINT32 opt1_pcs_sta = 0;
    UINT32 opt1_pcs_sta_curr = 0;
    UINT32 opt0_cdc_cnt = 0;
    UINT32 opt0_cdc_cnt_curr = 0;
    UINT32 opt1_cdc_cnt = 0;
    UINT32 opt1_cdc_cnt_curr = 0;
    UINT32 opt0_fsm_cnt = 0;
    UINT32 opt1_fsm_cnt = 0;
    UINT32 logOpt0AlarmCurr = 0;
    UINT32 logOpt0Alarm = 0;
    UINT32 logOpt1AlarmCurr = 0;
    UINT32 logOpt1Alarm = 0;
    UINT32 phy0Start = 0;
    UINT32 phy0End = 0;
    UINT32 phy1Start = 0;
    UINT32 phy1End = 0;
    UINT32 phy0StatusCurr = 0;
    UINT32 phy0Status = 0;
    UINT32 phy1StatusCurr = 0;
    UINT32 phy1Status = 0;
    UINT32 clkStatusCurr = 0;
    UINT32 clkStatus = 0;
    UINT32 index = 0;
    UINT32 clk1StatusCurr = 0;
    UINT32 clk1Status = 0;
    UINT32 clk21StatusCurr = 0;
    UINT32 clk21Status = 0;
    UINT32 clkSelCurr = 0;
    UINT32 clkSel = 0;
    UINT32 oriPhyOpt = 0;
    UINT32 cpuCfgEn = 0;
    UINT32 logOptMap = 0;
    UINT32 logOptMapCurr = 0;
    UINT32 opt0link = 0;
    UINT32 opt1link = 0;
    UINT32 optlink = 0;
    UINT32 optlinkCurr = 0;
    UINT32 Opt0SyncSta = 0;
    UINT32 Opt1SyncSta = 0;
    UINT32 Opt0SyncStaCurr = 0;
    UINT32 Opt1SyncStaCurr = 0;
    UINT32 txsw = 0;
    UINT32 txswCurr = 0;
    UINT32 optWorkMode = 0;
    while(BspGetDetectSw() == 1)
    {
        /* Started by AICoder, pid:lf96afcaf0e5f4814e500af060cb79400bd35d11 */
        BspSysMsDelay(s_detectLogTime);
        optWorkMode = BspGetDefaultOptWorkMode(0);
        if(BSP_OPT_WORK_MODE_NORMAL != optWorkMode) /* 组网不是FDD环网，不记录 */
        {
            continue;
        }
        index++; /* 倒换时log时间不准,增加次数记录 */
        if(lastStageLogSw == 0 && BSP_OK == BspLastStageIsOK()) /* 末级主光口正常不记录log */
        {
            continue;
        }
        BspHalAdaptDpdicRegRd(0,0xc2403010,0*4,&firstProrityCurr);
        BspHalAdaptDpdicRegRd(0,0xc2403010,1*4,&secndProrityCurr);
        BspHalAdaptDpdicRegRd(0,0xc2403410,0,&mainPhyOptCurr);
        BspHalAdaptDpdicRegRd(0,0xc2412334,0,&testModeCurr);
        if(_BspCheckPhyOptIsLop(0) == BSP_OK)
        {
            BspHalAdaptDpdicRegRd(0,0xc2402670,0,&opt0_cdc_cnt_curr);
            BspHalAdaptDpdicRegRd(0,0xC3E00050,0,&opt0_pcs_sta_curr);
            BspHalAdaptDpdicRegRd(0,0xC3E00050,0,&opt0_pcs_sta_curr);
            Opt0SyncStaCurr = BspHalAdaptGetOptSyncStatus(0);
            logOpt0AlarmCurr = BspGetlogOptAlarmCurr(0);
        }
        if(_BspCheckPhyOptIsLop(1) == BSP_OK)
        {
            BspHalAdaptDpdicRegRd(0,0xc2402674,0,&opt1_cdc_cnt_curr);
            BspHalAdaptDpdicRegRd(0,0xC3E00054,0,&opt1_pcs_sta_curr);
            BspHalAdaptDpdicRegRd(0,0xC3E00054,0,&opt1_pcs_sta_curr);
            Opt1SyncStaCurr = BspHalAdaptGetOptSyncStatus(1);
            logOpt1AlarmCurr = BspGetlogOptAlarmCurr(1);
        }
        /* Ended by AICoder, pid:lf96afcaf0e5f4814e500af060cb79400bd35d11 */

        BspHalAdaptDpdicRegRd(0,0xC2408010,0,&txswCurr);
        BspHalAdaptDpdicRegRd(0,0xc24031d8, 0, &opt0link); /*光口上下联属性*/
        BspHalAdaptDpdicRegRd(0,0xc24031dc, 0, &opt1link); /*光口上下联属性*/
        optlinkCurr = ((opt1link & 0xFF) << 8) | (opt0link & 0xFF);
        BspHalAdapGetM0InitSerdesCnt(&phy0Start, &phy0End, &phy1Start, &phy1End);
        BspHalAdaptGetSysLd(0,&clkStatusCurr);
        BspHalAdaptGetSysLd(1,&clk1StatusCurr);
        IcHalBitRdReg(0, DLPOST_CPU_PAPT_DATAOFF_UNUS_STATUS, 0, &clk21StatusCurr, 21U, 21U);
        BspHalAdaptDpdicRegRd(0,0xC2403408,0,&clkSelCurr);
        phy0StatusCurr = ((phy0Start & 0xFFFF) << 16) | (phy0End & 0xFFFF);
        phy1StatusCurr = ((phy1Start & 0xFFFF) << 16) | (phy1End & 0xFFFF);
        logOptMapCurr = 0;
        for(UINT32 lopOptLoop = 0; lopOptLoop < 4; lopOptLoop++)
        {
            BspGetOptCpriRelation(lopOptLoop, &oriPhyOpt, &cpuCfgEn);
            logOptMapCurr |= ((oriPhyOpt & 0xF) << (4*lopOptLoop)) | ((cpuCfgEn & 0xF) << (16 + 4*lopOptLoop));
        }
        if(((firstProrityCurr - firstPrority) + (secndProrityCurr - secndPrority)
          + (mainPhyOpt - mainPhyOptCurr) + (testModeCurr - testMode)
          + (opt0_pcs_sta - opt0_pcs_sta_curr) + (opt1_pcs_sta - opt1_pcs_sta_curr)
          + (phy0Status - phy0StatusCurr) + (phy1Status - phy1StatusCurr)
          + (logOpt0Alarm - logOpt0AlarmCurr) + (logOpt1Alarm - logOpt1AlarmCurr)
          + (logOptMap - logOptMapCurr) + (optlink - optlinkCurr)
          + (opt0_cdc_cnt - opt0_cdc_cnt_curr) + (opt1_cdc_cnt - opt1_cdc_cnt_curr)
          + (Opt0SyncSta - Opt0SyncStaCurr) + (Opt1SyncSta - Opt1SyncStaCurr) != 0)
          || (txswCurr != txsw) || (clkStatusCurr != clkStatus)
          || (clk1StatusCurr != clk1Status) || (clk21StatusCurr != clk21Status)
          || (clkSel != clkSelCurr))
        {
            firstPrority = firstProrityCurr;
            secndPrority = secndProrityCurr;
            mainPhyOpt   = mainPhyOptCurr;
            testMode     = testModeCurr;
//            opt0_cdc_cnt = opt0_cdc_cnt_curr;
//            opt1_cdc_cnt = opt1_cdc_cnt_curr;
            opt0_pcs_sta = opt0_pcs_sta_curr;
            opt1_pcs_sta = opt1_pcs_sta_curr;
            logOpt0Alarm = logOpt0AlarmCurr;
            logOpt1Alarm = logOpt1AlarmCurr;
            phy0Status = phy0StatusCurr;
            phy1Status = phy1StatusCurr;
            logOptMap = logOptMapCurr;
            optlink = optlinkCurr;
            Opt0SyncSta = Opt0SyncStaCurr;
            Opt1SyncSta = Opt1SyncStaCurr;
            txsw = txswCurr;
            clkStatus = clkStatusCurr;
            clk1Status = clk1StatusCurr;
            clk21Status = clk21StatusCurr;
            clkSel = clkSelCurr;
            BspHalAdaptDpdicRegRd(0,0xc24020c4,0,&opt0_fsm_cnt);
            BspHalAdaptDpdicRegRd(0,0xc24020c8,0,&opt1_fsm_cnt);
            BspLog(LOG_LEVEL_0,"i(%dms):%d tick[%llu] main[%d] testM[0x%02x] 2P[0x%02x] 1P[0x%02x] M0[%d] txsw[0x%x] link[0x%04x] optMap[0x%08x] log0Alm[0x%08x] log1Alm[0x%08x] 0Pcs[0x%08x] 1Pcs[0x%08x] 0Cdc[0x%08x -> 0x%08x] 1Cdc[0x%08x -> 0x%08x] 0SyncSta[0x%08x] 1SyncSta[0x%08x] 0Fsm[0x%08x] 1Fsm[0x%08x] phy0[0x%08x] phy1[0x%08x] clk0[0x%x] clk22[0x%x] clk21[0x%x] clkSel[0x%08x]\n",
                    s_detectLogTime, index, tick64Get(), mainPhyOpt, testMode, secndPrority, firstPrority, g_ulM0ThreadStartFlag, txsw, optlink, logOptMap, logOpt0Alarm, logOpt1Alarm, opt0_pcs_sta, opt1_pcs_sta,\
                    opt0_cdc_cnt, opt0_cdc_cnt_curr, opt1_cdc_cnt, opt1_cdc_cnt_curr, Opt0SyncSta, Opt1SyncSta, opt0_fsm_cnt, opt1_fsm_cnt, phy0Status, phy1Status, clkStatus, clk1Status, clk21Status, clkSel);
            opt0_cdc_cnt = opt0_cdc_cnt_curr;
            opt1_cdc_cnt = opt1_cdc_cnt_curr;
        }
#ifdef UT_FT_TEST
        return;
#endif
    }
    return;
}

/* 倒换时间记录调试任务 */
static UINT32 BspDetectThreadInit(VOID)
{
    pthread_t th_id = 0;
    UINT32    ulRet = BSP_OK;
#ifdef UT_FT_TEST
        return BSP_OK;
#endif
    ulRet = pthread_create(&th_id, NULL, (void *)HalIcDetectThread, NULL);
    if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, ulRet);
    }
    else
    {
        dbgInfo("create thread<%s> success!\n", __FUNCTION__);
    }

    return ulRet;
}

/* 如果FDD机型组网模式由非环网变为环网，切为自动转发 */
static UINT32 CfgTxPrioityByWorkMode(VOID)
{
    UINT32 optWorkMode = 0;
    static UINT32 lastOptWorkMode = BSP_OPT_WORK_MODE_CASCADE_NORMAL;
    static UINT32 curOptWorkMode  = BSP_OPT_WORK_MODE_CASCADE_NORMAL;

    optWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);
    curOptWorkMode = optWorkMode;
    if(lastOptWorkMode != curOptWorkMode)
    {
        BspLog(LOG_LEVEL_0,"%s OptWorkMode is change:LastWorkMode:%d CurrWorkMode:%d\n", __FUNCTION__, lastOptWorkMode, curOptWorkMode);
        if ((lastOptWorkMode == BSP_OPT_WORK_MODE_CASCADE_NORMAL) && (curOptWorkMode == BSP_OPT_WORK_MODE_NORMAL))
        {
            BspHalAdaptCpriCfgTxPriority(LOG_OPT_2, 0xff, OPT_TX_PRIORITY_AUTO);
            BspHalAdaptCpriCfgTxPriority(LOG_OPT_3, 0xff, OPT_TX_PRIORITY_AUTO);
        }
        lastOptWorkMode = curOptWorkMode;
    }

    return BSP_OK;
}

VOID BspCfgTxPriorityIsr(VOID)
{
    UINT32 optWorkMode = 0;
    UINT32 phyMainOpt  = 0;
    UINT32 txPriority  = 0;
    UINT32 txPriority1 = 0;
    const UINT32 txPriSndCnt = 40;
    const UINT32 txPriOffCnt = 3;

/* BSP小版本让任务空转 */
#ifdef BSP_MAKE_VER
    g_cfgPriorityCtr = FUNCLIB_OPT_ADPT_DISABLE;
#endif

    while (1)
    {
        optWorkMode = g_tOptAutoAdaptInfo.pFuncGetOptWorkMode(0);
        BspHalAdaptGetMainPhyOpt(&phyMainOpt);

        if(FUNCLIB_OPT_ADPT_DISABLE == g_cfgPriorityCtr)
        {
            BspSysMsDelay(1000);
            continue;
        }

        if (phyMainOpt == BSP_ERROR)
        {
            BspSysMsDelay(200);
            continue;
        }

        if (BSP_OPT_WORK_MODE_CASCADE_NORMAL == optWorkMode)
        {
            if(BSP_ERROR == BspGetOptTxPriorityStatus(phyMainOpt))
            {
                continue;
            }

            txPriority = BspHalAdaptGetFddPriority(phyMainOpt);
            BspSysMsDelay(100);
            txPriority1 = BspHalAdaptGetFddPriority(phyMainOpt);
            if(txPriority != txPriority1)
            {
                continue;
            }

            if (g_ulOptTxPriSendCnt < txPriSndCnt)
            {
                BspHalAdaptCpriCfgTxPriority(LOG_OPT_2, txPriority&0xff, OPT_TX_PRIORITY_FORCE);
                BspHalAdaptCpriCfgTxPriority(LOG_OPT_3, txPriority&0xff, OPT_TX_PRIORITY_FORCE);
                g_ulOptTxPriSendCnt++;
            }
            else
            {
                if (g_ulOptTxPriOffCnt < txPriOffCnt)
                {
                    BspHalAdaptCpriCfgTxPriority(LOG_OPT_2, 0xff, OPT_TX_PRIORITY_AUTO);
                    BspHalAdaptCpriCfgTxPriority(LOG_OPT_3, 0xff, OPT_TX_PRIORITY_AUTO);
                    g_ulOptTxPriOffCnt++;
                }
                else
                {
                    g_ulOptTxPriSendCnt = 0;
                    g_ulOptTxPriOffCnt = 0;
                }
            }
        }
        BspSysMsDelay(1000);
        CfgTxPrioityByWorkMode();
    }

}

UINT32 BspCfgTxPriorityThreadInit(VOID)
{
    UINT32 ret = BSP_OK;
    static INT32  taskID = (INT32)BSP_ERROR;
    UINT32 taskStack = 10;
    UINT32 ringFlag = 0;

    ringFlag = BspGetOptRingFlag();  /*是否支持环网*/
    if((ringFlag == OPT_NOT_SUPPORT_RING) || (BspGetOptCpriProtocol(0) == PROCOTOL_IR))
    {
        return BSP_OK;
    }

    if (taskID != ((INT32)BSP_ERROR))
    {
        return BSP_ERROR;
    }

    taskID = taskSpawn("BspCfgTxPriorityIsr", 100, 0, (1024 * taskStack),
                        (FUNCPTR)BspCfgTxPriorityIsr, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    if (BSP_ERROR == (UINT32)taskID)
    {
        dbgInfo("!!! Creat BspCfgTxPriorityIsr Error !!!\n");
        ret = BSP_ERROR;
    }

    return ret;
}

UINT32 BspSetIrCaseCadeCpriFlag(UINT32 flag)
{
    s_irCascadeCpriFlag = flag;
    return s_irCascadeCpriFlag;
}

UINT32 BspGetIrCaseCadeCpriFlag(void)
{
    return s_irCascadeCpriFlag;
}

UINT32 BspSaveProtocol(UINT32 optProtocol)
{
    FILE *fp  = NULL;
    INT32 retVal = 0;
    CHAR * const dirlist[1] = {"/"};
    rsize_t dirlist_size = 1;
    const CHAR *protocol = "/ata/protocol.txt";

    retVal = zte_fopen_s(&fp, protocol, "w+", dirlist, dirlist_size);
    if(0 != retVal)
    {
        dbgErr("failed to open file protocol.txt,error in detail\n");
        return BSP_ERROR;
    }

    retVal = fprintf(fp,"%d", optProtocol);
    FPRINTF_CHECK(retVal);

    retVal = fclose(fp);
    FCLOSE_CHECK(retVal);

    return BSP_OK;
}

UINT32 BspReadProtocol(UINT32 *optProtocol)
{
    FILE *fp  = NULL;
    INT32 retVal = 0;
    CHAR * const dirlist[1] = {"/"};
    rsize_t dirlist_size = 1;
    const CHAR *protocol = "/ata/protocol.txt";
    UINT32 readSize = 0;

    BspLog(LOG_LEVEL_0, "%s,enter optProtocol:%d\n", __FUNCTION__, *optProtocol);
    retVal = zte_fopen_s(&fp, protocol, "r", dirlist, dirlist_size);
    if(0 != retVal)
    {
        dbgErr("failed to open file protocol.txt,error in detail\n");
        *optProtocol = PROCOTOL_IR;
        return BSP_ERROR;
    }

    readSize = fread(optProtocol, 1, (size_t)1, fp);
    if (readSize != 1)
    {
        dbgErr("%s>>Read %s Error!\n", __FUNCTION__, protocol);
        retVal = fclose(fp);
        FCLOSE_CHECK(retVal);
        return BSP_ERROR;
    }
    *optProtocol = *optProtocol - '0';
    BspLog(LOG_LEVEL_0, "%s,end optProtocol:%d\n", __FUNCTION__, *optProtocol);
    retVal = fclose(fp);
    FCLOSE_CHECK(retVal);

    return BSP_OK;
}

/* Started by AICoder, pid:83a245661b264edeb3d71c0ba0fb803a */
/* Started by AI-VerifyCI-KwCov, pid:83a245661b264edeb3d71c0ba0fb803a */
UINT32 BspCheckProCotolChg(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 optProtocol = PROCOTOL_CPRI;

    retVal = BspReadProtocol(&optProtocol);
    if(retVal != BSP_OK) // Check the return value of BspReadProtocol
    {
        BspLog(LOG_LEVEL_0, "%s,Read optProtocol Error。\n", __FUNCTION__);
        return retVal;
    }
    else if(optProtocol != s_firstProtocol)
    {
        BspLog(LOG_LEVEL_0, "%s,OptProtocol changed, Begin pwr off.\n", __FUNCTION__);
        BspSetProcotolChgFlag(1);/*1表示协议发生变化*/
        /*次数需要记录复位原因，后续增加*/
        BspCtrlPm(0,0); /*协议发生变化时掉电，app流程未建链无法走到方案建议放到bsp掉电*/
    }

    return retVal;
}
/* Ended by AI-VerifyCI-KwCov, pid:83a245661b264edeb3d71c0ba0fb803a */
/* Ended by AICoder, pid:83a245661b264edeb3d71c0ba0fb803a */

UINT32 BspProtocolAdapt(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 optProtocol = PROCOTOL_CPRI;
    T_OPT_ROE_INIT_PARA roePara = {0};
    static UINT32 currProtocol = 0xffff;    /*当前配置到寄存器的协议*/

    if(0xffff == currProtocol)
    {
        currProtocol = s_firstProtocol;   /*整机启动只赋值一次*/
    }
    if((IsAllOptLop() == BSP_OK) && (s_protocolAdaptTimes < 50) && (BspGetIrCaseCadeCpriFlag() == IR_CASECADE_CPRI_FLAG))
    {
        s_protocolAdaptCnt ++;
        retVal = BspCheckAllOptRruId();
        if((s_protocolAdaptCnt >= 20)||(BSP_OK == retVal))    /*RRUID正常就可以进入，不用必须等计数*/
        {
            BspLog(LOG_LEVEL_0, "%s,enter optProtocolAdapt currProtocol %d \n", __FUNCTION__, currProtocol);
            retVal = BspCheckAllOptRruId();    /*这里不去掉 一是防抖 而是去掉整体逻辑要变 否则有kw/cov告警*/
            if(retVal != BSP_OK)
            {
                s_protocolAdaptTimes ++;
                optProtocol = currProtocol;
                s_GetRruIdTimes = 0;
                if(optProtocol == PROCOTOL_IR)
                {
                    BspClrOptCfgCnt();/*切换协议时清零*/
                    retVal |= BspSetOptCpriProtocol(PROCOTOL_CPRI);
                    roePara.optWorkMode = E_OPT_MODE_CPRI;
                    BspHalAdaptOptRoeInitCfg(&roePara);
                    (VOID)BspSetOptCpriSetCrcMask();
                    currProtocol = PROCOTOL_CPRI;    /*当前协议相关的东西配置完了 再记录协议*/
                }
                else
                {
                    BspClrOptCfgCnt();/*切换协议时清零*/
                    retVal |= BspSetOptCpriProtocol(PROCOTOL_IR);
                    roePara.optWorkMode = E_OPT_MODE_IR;
                    BspHalAdaptOptRoeInitCfg(&roePara);
                    retVal = BspHalAdaptCpriCfgTransLsarRstReqEn(0,0);  /*原来配置1,0 表示默认转发，现在临时回退成默认值，规避拔掉光纤之后级联整机发生硬复位*/
                    BspHalAdaptCfgTddLcvEnable(0xf);
                    currProtocol = PROCOTOL_IR;    /*当前协议相关的东西配置完了 再记录协议*/
                }
            }
            else
            {
                BspCheckProtocol(currProtocol);
            }
            s_protocolAdaptCnt = 0;
        }
    }
    else
    {
        s_GetRruIdTimes = 0;
        s_protocolAdaptCnt = 0;
    }

    return retVal;
}

UINT32 BspCheckProtocol(UINT32 currProtocol)
{
    UINT32 retVal = BSP_OK;

    s_GetRruIdTimes ++;
    BspLog(LOG_LEVEL_0,"%s :s_GetRruIdTimes[%d]. \n", __FUNCTION__, s_GetRruIdTimes);
    /*BBU开站时会有误码，增加5次防抖减少误掉电*/
    if(s_GetRruIdTimes == 5)
    {
        s_GetRruIdTimes = 0;
        retVal |= BspSaveProtocol(currProtocol);
        retVal |= BspCheckProCotolChg();
    }

    return retVal;
}

UINT32 BspFirstSetProtocol(void)
{
    UINT32 optProtocol = PROCOTOL_IR;
    UINT32 retVal = BSP_OK;

    //BspMkdir("/ata/protocolAdapt/");
    retVal = BspReadProtocol(&optProtocol);
    s_firstProtocol = optProtocol;
    if((retVal == BSP_ERROR) || (optProtocol == PROCOTOL_IR))
    {
        BspSaveProtocol(PROCOTOL_IR);
        optProtocol = E_OPT_MODE_IR;
        BspHalCpriFrameAlignRdFrSel(0, 1);
        BspHalCpriFrameAlignRdFrSel(1, 1);
        BspHalCpriFrameAlignRdFrSel(2, 1);
        BspHalCpriFrameAlignRdFrSel(3, 1);
        BspCfgRoeCmCfgProtocol(E_OPT_MODE_IR);
    }
    else
    {
        //BspSaveProtocol(PROCOTOL_CPRI);
        //BspSetOptCpriProtocol(PROCOTOL_CPRI);
        //(VOID)BspSetOptCpriSetCrcMask();//fdd需要配置CRC掩码
        optProtocol = E_OPT_MODE_CPRI;
        BspHalCpriFrameAlignRdFrSel(0, 0);
        BspHalCpriFrameAlignRdFrSel(1, 0);
        BspHalCpriFrameAlignRdFrSel(2, 0);
        BspHalCpriFrameAlignRdFrSel(3, 0);
        BspCfgRoeCmCfgProtocol(E_OPT_MODE_CPRI);
    }

    return optProtocol;
}

VOID BspSetBbuSuperFrameNoCallBackInit(FUN_SET_BBU_SUPER_FRAMENO pAntcalPtr)
{
    pSetBbuSuperFrameNo = pAntcalPtr;
}

VOID BspCopyOutOfPsyncParaToKoCallBackInit(FUN_COPY_OUTOFPSYNC_PARA_TO_KO pAntcalPtr)
{
    pCopyOutOfPsyncParaToKo = pAntcalPtr;
}

UINT32 BspSwitchSlaveOptAdaptStaCallBackInit(FUN_SWITCH_SLAVE_OPT_ADAPT_STA pSlaveOptAdaptPtr)
{
    pSwitchSlaveOptAdaptSta = pSlaveOptAdaptPtr;
    return BSP_OK;
}
/* Started by AICoder, pid:v19fb9bc60s147514703098a604b5a424d68e0db */
UINT32 BspSetDlGpEnAllChan(UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 chan = 0;
    UINT32 radio = 0;
    UINT32 carrNo = 0;
    UINT32 radioMode = 0;
    UINT32 txChanNum = BspGetTxChannel();
    T_ChanRfCfgPara *pRfCfg = NULL;
    dbgInfo("%s>> start! \n", __FUNCTION__);

    radioMode = BspGetCarrRadioMixMode();
    if((RADIO_STANDARD_45G == radioMode) || (RADIO_STANDARD_LTE_TDD == radioMode))
    {
        radioMode = RADIO_STANDARD_LTE_TDD; 
    }
    if(RADIO_STANDARD_5G == radioMode)
    {
        radioMode = RADIO_STANDARD_5G; 
    }

    for (chan = 0; chan < txChanNum; chan++)
    {
        pRfCfg = GetRfCfgPara(chan, TX);
        if(NULL == pRfCfg)
        {
            continue;
        }

        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            carrNo = pRfCfg->para.carrInfo[loop].carrNo;
            radio = pRfCfg->para.carrInfo[loop].radioMode;

            if(radioMode == pRfCfg->para.carrInfo[loop].radioMode)
            {
                retVal |= BspHalAdaptSetDlGpEn(chan, radio,carrNo, sw);
                dbgInfo("carrNo'%d,radio'0x%x,sw'%d\n", carrNo, radio, sw);
            }
        }
        dbgInfo("\n");
    }
    return retVal;
}
/* Ended by AICoder, pid:v19fb9bc60s147514703098a604b5a424d68e0db */
/****************************************************************
* 函数名称: BspSetElectronicSw
* 函数说明: 电子开关，使能中断，给高层使用
* 输入参数:
*
* 输出参数
* 返回参数： BSP_OK,  BSP_ERROR
* 修改说明：
*****************************************************************/
UINT32 BspSetElectronicSw(UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 halPsyncInt10IntNo = 60; //246在中频内部映射的中断号

    if(SWITCH_ON == sw)
    {
        BspUpdateTddIoVariablePara(0,E_VSWR_TYPE_STOP); /*配置io时序:tx_timg\tx_actimg*/
        BspSetDlGpEnAllChan(SWITCH_ON);/*链路GP常开*/
        IcHalPsyncTimSetIntMask(halPsyncInt10IntNo,SWITCH_OFF);  /*打开对应中断输出*/
    }
    else
    {
        IcHalPsyncTimSetIntMask(halPsyncInt10IntNo,SWITCH_ON);    /*屏蔽对应中断输出*/
        BspUpdateTddIoVariablePara(0,E_AC_TYPE_STOP);   /* 恢复正常tdd时序*/
        BspSetDlGpEnAllChan(SWITCH_OFF);/*链路GP恢复正常tdd*/
    }

    return retVal;
}

UINT32 BspSetIoBitmapAllChn(VOID)
{
    UINT32 chnLoop = 0;
    UINT32    loop = 0;
    UINT32  retVal = BSP_OK;

    for (chnLoop = 0; chnLoop < MAX_OUTOFSYNC_ANT_NUM; chnLoop++)
    {
        for(loop = 0; loop < BITMAP_MAX_NUM; loop++)
        {
            retVal |= BspSetPaBitmap(chnLoop, loop, s_bitmap[loop]);
            retVal |= BspSetTxEnBitmap(chnLoop, loop, s_bitmap[loop]);
            retVal |= BspSetAmpBitmap(chnLoop, loop, s_bitmap[loop]);
            retVal |= BspSetLnaBitmap(chnLoop, loop, s_bitmap[loop]);
            retVal |= BspSetRxEnBitmap(chnLoop, loop, 0);  /*rxen  在这个功能时   固定选择rx_timing  早点打开 */
        }
    }

    return retVal;
}

UINT32 BspSetBitMapFrIdAllChn(UINT32 frId)
{
    UINT32 chnLoop = 0;
    UINT32  retVal = BSP_OK;
    
    dbgInfoEx("%s >> BitMapFrId = %d \n", __FUNCTION__,frId);

    for (chnLoop = 0; chnLoop < MAX_OUTOFSYNC_ANT_NUM; chnLoop++)
    {
        BspHalAdaptSetUePaFrameId(chnLoop, frId);
        BspHalAdaptSetUeLnaFrameId(chnLoop, frId);
        BspHalAdaptSetUeTxEnFrameId(chnLoop, frId);
        BspHalAdaptSetUeRxEnFrameId(chnLoop, frId);
        BspHalAdaptSetUeAmpFrameId(chnLoop, frId);
    }
    dbgInfoEx("%s >> end! \n", __FUNCTION__);
    return retVal;
}


static UINT32 BspSetBitmap( UINT32 startFrameNo, UINT32 frameNum)
{
    UINT32 startIndex = 0;
    UINT32 startBitMap = 0;
    UINT32 endIndex = 0;
    UINT32 endBitMap = 0;
    UINT32 index = 0;

    /* 新bitmap对应的帧号字（1024bit -> 2048bit）,Bbu下发的为1024bit需要转换为2048bit,每个地址能存放32个帧号 */
    startIndex = (startFrameNo*2) / BIT_NUM_PER_BYTE;
    startBitMap = (startFrameNo*2) % BIT_NUM_PER_BYTE;
    endIndex = (startFrameNo*2 + frameNum*2) / BIT_NUM_PER_BYTE;
    endBitMap = (startFrameNo*2 + frameNum*2) % BIT_NUM_PER_BYTE;

    for(index = 0; index < BITMAP_MAX_NUM; index++)
    {
        /* 换算bitmap位图 tx和rx的位图互斥 */
        if(index == startIndex)
        {
            s_bitmap[index] = (0xffffffff << startBitMap) & 0xffffffff;
        }
        if(index == endIndex)
        {
            if(startIndex == endIndex)
            {
                s_bitmap[index] = (~((0xffffffff << endBitMap)) & s_bitmap[index]);
            }
            else
            {
                s_bitmap[index] = (~((0xffffffff << endBitMap)) & 0xffffffff);
            }
        }
        if(startIndex < index && endIndex > index)
        {
            s_bitmap[index] = 0xffffffff;
        }
        if((startIndex > index || endIndex < index) || (0 == frameNum))
        {
            s_bitmap[index] = 0;
        }
        dbgInfo("index = %d, Bitmap = 0x%x \n", index, s_bitmap[index]);
    }

    return BSP_OK;
}

/****************************************************************
* 函数名称: BspOutOfSyncDetectPara
* 函数说明: 失步干扰检测,提供给高层使用
* 输入参数: 高层下发的帧号参数等
*
* 输出参数
* 返回参数： BSP_OK,  BSP_ERROR
* 修改说明：
*****************************************************************/
UINT32 BspOutOfSyncDetectPara(T_OutOfSyncDetect *pOutOfSyncDetect)
{
    UINT16 frameNum = 0;
    UINT16 startFrameNo = 0;
    UINT32 bbuSuperFrameNo = 0;
    UINT32 rruSuperFrameNo = 0;
    UINT32 retVal = BSP_OK;
    UINT32 frId = 0;
    UINT32 bitMapFrId = 0;
    UINT32 radioMode = 0;
    INT32 frVal = 0;
    UINT32 frDir = 0;

    INPUT_POINTER_CHECK(pOutOfSyncDetect);

    bbuSuperFrameNo = (UINT32)pOutOfSyncDetect->superFrameFlag;
    frameNum = pOutOfSyncDetect->frameNum;
    startFrameNo = pOutOfSyncDetect->startFrameNo;
    dbgInfoEx("[%s] startFrameNo = %d\n", __FUNCTION__, pOutOfSyncDetect->startFrameNo);

    if((startFrameNo >= MAX_FRAME_NUM) && (startFrameNo != INVALID_FRAME_NO))
    {
        dbgErr("startFrameNo[%d] is ERR!\n", startFrameNo);
        return BSP_ERROR;
    }

    radioMode = BspGetCarrRadioMixMode();
    if(RADIO_STANDARD_45G == radioMode)
    {
        radioMode = RADIO_STANDARD_LTE_TDD;  /*混模仅需要LTE 支持失步干扰检测*/
    }
    frVal = BspGetFrameAlignmentVal(0, radioMode);
    if((frVal < 0) && (0 != startFrameNo))
    {
        startFrameNo -= 1;
    }
    dbgInfo("[%s] frVal = %d startFrameNo = %d\n", __FUNCTION__,frVal, startFrameNo);

    BspHalAdaptGetGlobleOutFrDir(&frDir);
    if(1 == frDir)
    {
        startFrameNo += 1;
    }
    dbgInfo("%s >> BbuSuperFrameNo = %d frameNum = %d startFrameNo = %d radioMode = %d frVal = %d frDir = %d\n",
             __FUNCTION__,bbuSuperFrameNo, frameNum, startFrameNo, radioMode, frVal,frDir);
    BspLog(LOG_LEVEL_0,"%s >> BbuSuperFrameNo = %d frameNum = %d startFrameNo = %d radioMode = %d frVal = %d frDir = %d\n",
             __FUNCTION__,bbuSuperFrameNo, frameNum, startFrameNo, radioMode, frVal,frDir);
    
    if(NULL != pSetBbuSuperFrameNo)
    {
        pSetBbuSuperFrameNo(bbuSuperFrameNo);
    }

    if(NULL != pCopyOutOfPsyncParaToKo)
    {
        pCopyOutOfPsyncParaToKo(radioMode);
    }

    retVal |= BspSetBitmap( startFrameNo, frameNum);
    retVal |= BspSetIoBitmapAllChn();/*bitmap配置*/
    rruSuperFrameNo = BspHalAdaptGetSynPsyncSuperFrameNo();

    if((rruSuperFrameNo >= bbuSuperFrameNo) && ((bbuSuperFrameNo + MAX_FRAME_NUM - rruSuperFrameNo)> 5))
    {
        dbgErr(" bbuSuperFrameNo[%d] rruSuperFrameNo[%d] ERR!\n", bbuSuperFrameNo, rruSuperFrameNo);
        BspUpdateTddIoVariablePara(0,E_AC_TYPE_STOP);   /* 恢复正常tdd时序*/
        BspSetDlGpEnAllChan(SWITCH_OFF);/*链路GP恢复正常tdd*/
        return BSP_ERROR;
    }
    if(rruSuperFrameNo >= bbuSuperFrameNo)
    {
        bbuSuperFrameNo += MAX_FRAME_NUM;
    }
    BspHalAdaptGetWirelessFrId(&frId);
    bitMapFrId = (((frId + (bbuSuperFrameNo - rruSuperFrameNo)*1024)%4096)/1024)*1024;  /*IC的bitmap使能周期是40s，超帧号的周期是10s，为了使bitmap使能周期和超帧号同步*/
    dbgInfo(" bbuSuperFrameNo[%d] rruSuperFrameNo[%d] frId[%d] bitMapFrId[%d]\n", bbuSuperFrameNo, rruSuperFrameNo,frId,bitMapFrId);
    BspLog(LOG_LEVEL_0," bbuSuperFrameNo[%d] rruSuperFrameNo[%d] frId[%d] bitMapFrId[%d]\n", bbuSuperFrameNo, rruSuperFrameNo,frId,bitMapFrId);
    retVal |= BspSetBitMapFrIdAllChn(bitMapFrId);/*bitmap使能帧号配置*/

    return retVal;
}

/****************************************************************
 * 函数名称: dbgOutOfSyncDetectPara
 * 功能描述: 调试接口，用于检测同步异常参数
 * 输入参数: superFrameNo - 超帧号
 *         frameNum - 帧号
 *         startFrameNo - 起始帧号
 *         slotNo - 插槽号
 * 输出参数: 无
 * 返回 值: BSP_OK/BSP_ERROR
*****************************************************************/
UINT32 dbgOutOfSyncDetectPara(UINT32 superFrameNo, UINT32 frameNum, UINT32 startFrameNo, UINT32 slotNo)
{
    T_OutOfSyncDetect outOfSyncDetect = {
        .superFrameFlag = superFrameNo,
        .frameNum = frameNum,
        .startFrameNo = startFrameNo,
        .slotNo = slotNo
    };

    return BspOutOfSyncDetectPara(&outOfSyncDetect);
}


/*根据单双光口建链 采用不同策略给hal下发当前基准光口 同时记录当前基准光口  双上联光纤不等长则必须通过光口帧头鉴相决定基准光口才能正常处理延时补偿*/
void BspUpdateShareBaseOptNo(UINT32 phyNo)
{
    UINT32 workMode = 0;
    UINT32 maxDly2Point = 0;
    UINT32 minDly3Point = 0;
    UINT32 logNo = 0;

    workMode = BspGetOptWorkMode(0);
    logNo = BspGetLogicPort(phyNo);
    if(BSP_OPT_WORK_MODE_SHARE != workMode)    /*非负荷分担不需要此流程*/
    {
        s_CurrBaseLogOptForShare = logNo;
        s_CurrUpBaseLogOptForShare = logNo;
        BspHalAdaptSetBaseDelayLogOpt(logNo);
        BspHalAdaptCpriBifGfRxChanFr(logNo);
        BspHalAdaptCfgSwSrcAlignFr(logNo+1); /*上行对齐帧头选择   传逻辑主光口+1*/
        BspHalAdaptCpri2PointFrSel();    /*底层接口会区分组网*/
        /* Started by AICoder, pid:c83e3kdb16s214c14b5e084ea0654b0630e35c2e */
        if(BSP_OPT_WORK_MODE_MAIN_SLAVE == workMode)
        {
            BspHalAdaptCpriOptBindSel(2, logNo);   /*其它组网模式2，3口数据来源固定选择0*/
            BspHalAdaptCpriOptBindSel(3, logNo);
        }
        else
        {
            BspHalAdaptCpriOptBindSel(2, 0);   /*其它组网模式2，3口数据来源固定选择0*/
            BspHalAdaptCpriOptBindSel(3, 0);
        }
        /* Ended by AICoder, pid:c83e3kdb16s214c14b5e084ea0654b0630e35c2e */
        return ;
    }
    if((BSP_OK == IsAllPhyOptStaOk())&&(BSP_OK == IsAllLogOptStaOk()))   /*双光口正常 当鉴相值小于20us时，认为当前下行最晚2点是光口1；当鉴相是为大于10ms-20us，认为当前下行最晚2点是光口0 其它鉴相值说明当前光纤不等长超过了IC容忍范围 */
    {
        maxDly2Point = BspHalAdaptGetMaxDelay2Point();
        minDly3Point = BspHalAdaptGetMinDelay3Point();
        s_CurrBaseLogOptForShare = maxDly2Point;
        s_CurrUpBaseLogOptForShare = minDly3Point;
        BspHalAdaptSetBaseDelayLogOpt(maxDly2Point);
        /* 符合分担从交叉转发改成组网转发，此处不需要配置 */
        //BspHalAdaptSetSW2TXDownlinkFrSel(maxDly2Point);   /*配置交叉表还会配置 切级联不影响 和森全确认这里只影响异速率级联所以9164切组网不影响*/
        BspHalAdaptCpriOptBindSel(0, 0);
        BspHalAdaptCpriOptBindSel(1, 1);
        BspHalAdaptCpriOptBindSel(2, 1);   /*符合分担时逻辑2，3口数据来源都选择基准光口 切组网时在单板初始化恢复*/
        BspHalAdaptCpriOptBindSel(3, 0);   /*单板初始化 额外配置一遍*/
        BspHalAdaptCpriCfgIqCloseEn(2, DISABLE, TX);/* 打开逻辑2，3的下行数据 */
        BspHalAdaptCpriCfgIqCloseEn(3, DISABLE, TX);
        BspHalAdaptCpriBifGfRxChanFr(minDly3Point);
        BspHalAdaptCpri2PointFrSel();
        BspHalAdaptCfgSwSrcAlignFr(minDly3Point+1);   /*SW源端对齐帧头选择baseOptNo,对应接口：IcHalApiCfgSwSrcAlignFr*/
    }
    else/*单光口建链的时候主光口就是基准光口*/
    {
        s_CurrBaseLogOptForShare = logNo;
        s_CurrUpBaseLogOptForShare = logNo;
        BspHalAdaptSetBaseDelayLogOpt(logNo);
        BspHalAdaptCfgSwSrcAlignFr(logNo+1);    /*SW源端对齐帧头选择baseOptNo,对应接口：IcHalApiCfgSwSrcAlignFr*/
        BspHalAdaptCpriOptBindSel(0, 0);
        BspHalAdaptCpriOptBindSel(1, 1);
        BspHalAdaptCpriOptBindSel(2, logNo);   /*符合分担时逻辑2，3口数据来源都选择基准光口*/
        BspHalAdaptCpriOptBindSel(3, logNo);   /*单板初始化 额外配置一遍*/
        if(logNo == 0)
        {
            /* 关2开3，避免数据干扰 */
            BspHalAdaptCpriCfgIqCloseEn(2, ENABLE, TX);
            BspHalAdaptCpriCfgIqCloseEn(3, DISABLE, TX);
        }
        else
        {
            BspHalAdaptCpriCfgIqCloseEn(2, DISABLE, TX);
            BspHalAdaptCpriCfgIqCloseEn(3, ENABLE, TX);
        }
        BspHalAdaptCpriBifGfRxChanFr(logNo);
        BspHalAdaptCpri2PointFrSel();
    }
    return ;
}

/*设置当前光口是交换转发mode=1 还是IQ转发 mode=0*/
void BspSetCpriCfgNetTrasMode(UINT32 logNo, UINT32 mode)
{
    BspHalAdaptCpriCfgUlNetTrasBypass(logNo, mode);
    BspHalAdaptCpriCfgDlNetTrasBypass(logNo, mode);
    return ;
}
/*数据上行合并时，读64chip帧头选择*/
UINT32 BspSetCpriUlFrameAlignFrSelByMode(UINT32 logNo, UINT32 cfgVal)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptCpriUlFrameAlignFrSel(logNo, cfgVal);

    return retVal;
}

/* Started by AICoder, pid:oe327yfb37kd32f1422e0a88c0c19a0708e58ef7 */
/*Gf问题对高层接口*/
VOID BspGfTdmCheckForQcell(VOID)
{
    return BspHalAdaptGfTdmCheckForQcell();
}
/* Ended by AICoder, pid:oe327yfb37kd32f1422e0a88c0c19a0708e58ef7 */

VOID BspSetSupport2BbuMainSlaveFlag(UINT32 flag)
{
    g_support2bbuMainSlaveFlag = flag;
}

UINT32 BspGetSupport2BbuMainSlaveFlag(VOID)
{
    return g_support2bbuMainSlaveFlag;
}

/* Started by AICoder, pid:7ecdc1e9f7u33961412b099cd0bf805e2102f640 */
/****************************************************************
 * 函数名称: BspQcellCheckIqRes
 * 函数说明: Qcell主从机型，芯片能力限制，NR电口组号，从片不能在主片前面，校验是否符合这条限制
 * 输入参数: iqTblLen
 *          pRruIqCfgInfo
 * 输出参数： pRruIqResult 预留参数，后续可能要返回IQ资源冲突的小区信息
 * 返回参数： BSP_OK（IQ无冲突）, 非0（IQ有冲突）
 * 修改说明： Creat @2026-03-12
 *****************************************************************/
UINT32 BspQcellCheckIqRes(UINT32 iqTblLen, T_PRruIqCfgItem_BSP *pRruIqCfgInfo, T_PRruIqResultItem_BSP *pRruIqResult)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pRruIqCfgInfo);
    INPUT_POINTER_CHECK(pRruIqResult);
    retVal = BspHalAdaptQcellCheckIqRes(iqTblLen, pRruIqCfgInfo, pRruIqResult);
    return retVal;
}

/****************************************************************
 * 函数名称: BspGetQcellTxIqSwitchFlag
 * 函数说明: Qcell主片，这个接口返回app配置的下行数据 主片/从片 开关状态
 * 输入参数: icId 0-主片;1-从片 
 * 输出参数：
 * 返回参数： 0/1/ BSP_ERROR
 * 修改说明： Creat @2026-03-16
 *****************************************************************/
UINT32 BspGetQcellTxIqSwitchFlag(UINT32 icId)
{
    UINT32 retVal = BSP_OK;
    retVal = BspHalAdaptGetQcellTxIqSwitchFlag(icId);
    return retVal;
}

/****************************************************************
 * 函数名称: BspQcellCpriIqTxSwitch
 * 函数说明: Qcell主片，根据 光口搜索帧头/app配置IQ，主片/从片 控制下行数据开关
 * 输入参数:
 *          funcId 0-opt;1-app
 *          icId 0-主片;1-从片
 *          en
 * 输出参数：
 * 返回参数： BSP_OK,  BSP_ERROR
 * 修改说明： Creat @2026-03-16
 *****************************************************************/
UINT32 BspQcellCpriIqTxSwitch(UINT32 icId, UINT32 en)
{
    UINT32 retVal = BSP_OK;
    UINT32 funcId = 1;//跟广雷确认固定配1
    retVal = BspHalAdaptQcellCpriIqTxSwitch(funcId, icId, en);
    return retVal;
}
/* Ended by AICoder, pid:7ecdc1e9f7u33961412b099cd0bf805e2102f640 */

/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : optctrl.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 
 * 注意事项 : 无
 * 作    者   : 10090699
 * 创建日期 : 2017-3-2 17:26:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 10090699
 * 修改日戳: 2017-3-2 17:26:34
 * 变更说明: 创建文件

 *----------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "bspcomm.h"
#include "optctrlapi.h"
#include "optctrl_ntl_ic4_2.h"
#include "optctrl_inter_def.h"
#include "regdrv.h"
#include "regdrv_pintbl.h"
#include "funccommon.h"
#include "ichaladapt_ic4_2.h"
//#include "pub_ntl.h"
//#include "ntl_l2ss_agency.h"
//#include "ntl_l2ss.h"
//#include "ntl_eth_head.h"
//#include "ntl_l2ss_reg.h"
//#include "bsppub.h"
//#include "regtbl.h"
/*DPDIC4编译修改*/
#if 0
T_NTLDrvParam gtNtlDrviParam = {0};
#endif

/**************************************************************************
函数名称:  NtlL2ssRegMap
功能描述:  NTL寄存器空间映射
输入参数:  ptNtlDrvParam 参见T_NTLDrvParam
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：
修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
2017-11-22      V1.0     shejingui          创建
**************************************************************************/
/*DPDIC4编译修改*/
#if 0
UINT32 NtlL2ssRegMap(T_NTLDrvParam *ptNtlDrvParam,UINT32 phyL2ssAddr,UINT32 phyl2ssAddrSize)
{
    UINT32   virAddr = 0;
    UINT32   ulSpaceProt = PROT_READ | PROT_WRITE;
    INT32 ifile = -1;
#if 0

    if ((ifile = open("/dev/mem", O_RDWR | O_SYNC)) < 0)
    {
        dbgErr("open /dev/mem failed\n");
        return BSP_ERROR;
    }

    virAddr = mmap((VOID *)NULL, phyl2ssAddrSize, ulSpaceProt, MAP_SHARED, ifile, phyL2ssAddr);
    if(0 == virAddr)
    {
        dbgErr("%s mmap error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    
    close(ifile);
#endif
    //DpdIcHalGetVirAddrbyRegIdx(0,NTL_REG_BASE,0,&virAddr);    
#if 0
    DpdIcHalGetAddrPhyToVir(0,phyL2ssAddr,&virAddr);
    wrphyic(0,0x91000000,0x12345678);
    printf("test 0x%08x\n",*(UINT32 *)virAddr);
    wrphyic(0,0x91000000,0x78563412);
    printf("test 0x%08x\n",*(UINT32 *)virAddr);

    *(UINT32 *)(virAddr + 0x4FFFF00) = 0x5a5a5a5a;

    rdphyic(0,0x95FFFF00,1);
    
    *(UINT32 *)(virAddr + 0x4FFFF00) = 0xa5a5a5a5;

    rdphyic(0,0x95FFFF00,1);
#endif    
	DpdIcHalGetAddrPhyToVir(0,phyL2ssAddr,&virAddr);
    
    dbgInfo("%s DpdIcHalGetAddrPhyToVir mmap ok,viraddr[0x%08x]\n",__FUNCTION__,virAddr);

    ptNtlDrvParam->l2ssDrvParam.regVirAddr = virAddr;
    ptNtlDrvParam->xmacDrvParam.regVirAddr = virAddr;
    ptNtlDrvParam->tPtpDrvParam.regVirAddr = virAddr;

    printf("%s:l2ss reg baseaddr = 0x%08x\n",__FUNCTION__,virAddr);

    return BSP_OK;
}
#endif

/*DPDIC4编译修改*/
#if 0
UINT32 L2ssInit(T_L2ssDrvParam *pl2ssDrvParam)
{
    INPUT_POINTER_CHECK(pl2ssDrvParam);

    NtlL2ssCfgBaseAddr(pl2ssDrvParam->regVirAddr);
    if(BSP_OK !=  NtlL2ssInit(pl2ssDrvParam))
    {
        dbgErr("%s failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    /*CPU Agency ceva,r8  初始化*/
    if(BSP_OK !=  NtlL2ssCpuAgentInit(0x6,&(pl2ssDrvParam->tL2ssCpuAgentDrvParam)))
    {
        dbgErr("%s failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    /*关闭ceva,R8的端口，CEVA,R8加载完之后，自己开启*/
    NtlL2ssAgentPortEn(0x6,0);

    /*设置板间ETH的初始化*/
    if(BSP_OK !=  NtlL2ssSetInnerEthIpVlan(L2SS_INNER_ETH_IP_VLAN))
    {
        dbgErr("%s failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /*配置本地198网段的VLAN的IP VLAN 9,10*/
    dbgInfo("%s init succ\n",__FUNCTION__);
    return BSP_OK;
}
#endif

/*DPDIC4编译修改*/
#if 0
UINT32 XmacInit(T_XmacParamStruct *pXmacDrvParam)
{
    UINT32 ret = -1;
    UINT32 idx = 0;

    INPUT_POINTER_CHECK(pXmacDrvParam);

    NtlXMacCfgBaseAddr(pXmacDrvParam->regVirAddr);
    for(idx = 0;idx < NACC_XMAC_NUM;idx ++)
    {
        if(!isXmacPortHwValid(idx))
        {
            continue;
        }

        if(pXmacDrvParam->atXmacDrvParam[idx].bEnable)
        {
            ret = NaccXmacInit(&(pXmacDrvParam->atXmacDrvParam[idx]));
            if(BSP_OK != ret)
            {
                dbgErr("%s NaccXmacInit %d failed\n",__FUNCTION__,idx);
                return BSP_ERROR;
            }
        }
    }

    dbgInfo("%s init succ!\n",__FUNCTION__);
    return BSP_OK;
}
#endif

/*DPDIC4编译修改*/
#if 0
UINT32 PtpInit(T_PtpDrvParam *ptPtpDrvParam)
{
    INPUT_POINTER_CHECK(ptPtpDrvParam);
    
    NtlPtpCfgBaseAddr(ptPtpDrvParam->regVirAddr);
   
    NaccPtpInit(ptPtpDrvParam);
    
    dbgInfo("%s init succ! 0x%08x \n",__FUNCTION__,ptPtpDrvParam->regVirAddr);
    return BSP_OK;
}
#endif

/**************************************************************************
函数名称:  BspNtlInit(*)
功能描述:  单板下NTL全部初始化
输入参数:  无
输出参数:  无
返 回 值:  BSP_OK /  RETURN_ERROR
其它说明：

修改日期      版本号      修改人          修改内容
-----------------------------------------------------------------------
2012-9-19      V1.0        CAIKY             创建
**************************************************************************/
UINT32 HalIcNtlInit(void)
{
    /*DPDIC4编译修改*/
#if 0
    UINT32 udRet = 0;
    UINT32 udCnt = 0;
    UINT32 udClusterId = 0;
    UINT8 aucSelfIpAddr[20];
    UINT32 ulMchIpAddr = 0;
    UINT8 aucDstMac[6] = {0x40,0x00,0xc0,0xfe,0x01,0x10};
    UINT8 aucSrcMac[6] = {0x40,0x00,0xc0,0xfe,0x06,0x10};
    UINT32 udStatus = 0;
    UINT32 udTryTime = 0;

    printf("BspNtlL2ssInit:Start!\n");
    /* 清零NTL单板层句柄 */
    memset((UINT8 *)&gtNtlDrviParam, 0, sizeof(T_NTLDrvParam));

    if(BSP_OK != NtlL2ssRegMap((T_NTLDrvParam *)(&gtNtlDrviParam),0x91000000,1024*1024*70)) /*大小70M*/
    {
        dbgErr("%s error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("gtNtlDrviParam->tPtpDrvParam.regVirAddr = 0x%08x\n",gtNtlDrviParam.tPtpDrvParam.regVirAddr);
    if(BSP_OK != NtlCfgParaInit((T_NTLDrvParam *)&gtNtlDrviParam)) /*大小70M*/
    {
        dbgErr("%s error\n",__FUNCTION__);
        return BSP_ERROR;
    }
#if 0
    if(BSP_OK != PtpInit(&(gtNtlDrviParam.tPtpDrvParam)))
    {
        dbgErr("%s BspInitXmac failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
#endif


    /* STEP 7 -- NTL初始化 */
    if(BSP_OK != L2ssInit(&(gtNtlDrviParam.l2ssDrvParam)))
    {
        dbgErr("%s BspInitL2ss failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
#if 1
    /* IP MAC 初始化 */
  //  BspSetEth0IpMacAddr();

    if(BSP_OK != XmacInit(&(gtNtlDrviParam.xmacDrvParam)))
    {
        dbgErr("%s BspInitXmac failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    /*关闭所有XMAC，高层打开，或者手动打开*/
    NtlL2ssDisEnAllXmac();

    /*水位控制开启*/
    NtlL2ssTrxpEnable(46);
    NtlL2ssTrxpEnable(10);
    NtlL2ssTrxpEnable(11);
    NtlL2ssTrxpEnable(8); /*打开8 black hole端口*/

    /*打开debug口的 XMAC 10,11端口*/    
    NtlXmacEnable(10);
    NtlXmacEnable(11);
    NtlXmacEnable(8);    /*打开8 black hole端口*/
 
	/*ecpri 资源初始化*/
    NtlL2ssResMngExportInit();
	BspInitEcpriPktInfo();
    /*8端口的MAC，待光口全部初始化完成之后，才能打开*/
    dbgInfo("BspNtlInit:Done!\n");
#endif    
    return BSP_OK;
#endif
    return BSP_OK;
}

#define BSP_OPT_CPRI_MODE_MAX_TYPE (9)

static T_CpriModeSwitchCfgFunc *s_cpriModeSwitchCfgFunc= NULL;

UINT32 BspSetCpriModeSwitchCfgFunc(T_CpriModeSwitchCfgFunc *pCpriModeSwitchCfgFunc)
{
    INPUT_POINTER_CHECK(pCpriModeSwitchCfgFunc);
    s_cpriModeSwitchCfgFunc = pCpriModeSwitchCfgFunc;
    return BSP_OK;
}

T_CpriModeSwitchCfgFunc *BspGetCpriModeSwitchCfgFunc(void)
{
    return s_cpriModeSwitchCfgFunc;
}

static T_CpriModeLaneRoutePara  s_CpriModeLaneRoutePara[BSP_OPT_CPRI_MODE_MAX_TYPE] = {0};
UINT32 BspSetLaneRoutePara(T_CpriModeLaneRoutePara* tpara, UINT32 num)
{
    INPUT_POINTER_CHECK(tpara);
    memcpy_s(s_CpriModeLaneRoutePara, sizeof(T_CpriModeLaneRoutePara)*num, tpara, sizeof(T_CpriModeLaneRoutePara)*num);
    return BSP_OK;
}

static UINT32 s_CpriModeLaneRoutePath = 0;
static UINT32 BspSetLaneRoutePath(UINT32 path)
{
    s_CpriModeLaneRoutePath = path;
    return BSP_OK;
}

UINT32 BspGetLaneRoutePath(VOID)
{
    return s_CpriModeLaneRoutePath;
}

/*cpri切换：主片获取soc加载状态*/
UINT32 BspIsAllSocLoadSucc(UINT32 *status)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 socLoadRet = 0;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(status);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetSlaveSocLoadStatus)
    {
        retVal = pCpriModeFunc->pGetSlaveSocLoadStatus(&socLoadRet);
    }
    *status = socLoadRet;

    return retVal;
}

/*cpri切换：主片获取soc加载状态*/
UINT32 BspIsSocLoadSuccByChipId(UINT32 rpuId, UINT32 *status)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 socLoadRet = 0;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(status);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetSocLoadStatusByChipId)
    {
        retVal = pCpriModeFunc->pGetSocLoadStatusByChipId(rpuId,&socLoadRet);
    }
    *status = socLoadRet;

    return retVal;
}

/*cpri切换：主片获取soc加载状态*/
UINT32 BspGetCpriModeLaneRoutePath(UINT32 *path)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 laneRoutePath = 0;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(path);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetCpriModeLaneRoutePathNo)
    {
        retVal = pCpriModeFunc->pGetCpriModeLaneRoutePathNo(&laneRoutePath);
    }
    *path = laneRoutePath;

    return retVal;
}

/*cpri切换：主片获取soc加载状态*/
UINT32 BspSetCpriModeLaneRoutePath(UINT32 path)
{
    UINT32 retVal = BSP_ERROR;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pSetCpriModeLaneRoutePathNo)
    {
        retVal = pCpriModeFunc->pSetCpriModeLaneRoutePathNo(path);
    }

    return retVal;
}

/*cpri切换：主片获取soc加载状态*/
UINT32 BspGetCpriModeLaneRouteTryingTimes(UINT32 *times)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 tryingTimes = 0;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(times);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetCpriModeLaneRouteTryingTimes)
    {
        retVal = pCpriModeFunc->pGetCpriModeLaneRouteTryingTimes(&tryingTimes);
    }
    *times = tryingTimes;

    return retVal;
}

/*cpri切换：主片获取soc加载状态*/
UINT32 BspSetCpriModeLaneRouteTryingTimes(UINT32 times)
{
    UINT32 retVal = BSP_ERROR;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pSetCpriModeLaneRouteTryingTimes)
    {
        retVal = pCpriModeFunc->pSetCpriModeLaneRouteTryingTimes(times);
    }

    return retVal;
}

UINT32 BspIsSupportCpriModeSwitch(UINT32 *ablity)
{
    UINT32 retVal = BSP_OK;
    UINT32 isSupport = 0;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(ablity);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    if (pCpriModeFunc == NULL)
    {
        *ablity = SWITCH_OFF;
        dbgInfoEx("%s>> this board not support cpri-mode-switch!\r\n",__func__);
        return BSP_ERROR;
    }

    isSupport = pCpriModeFunc->cpriModeSwitchAblity;
    *ablity = isSupport;

    return retVal;
}
/*主片获取rstCauseRoute*/
UINT32 BspGetCpriModeRstCauseRouteTry(UINT32 *tryFlag)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 rstCauseRoute = 0;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(tryFlag);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetRstCauseRouteTry)
    {
        retVal = pCpriModeFunc->pGetRstCauseRouteTry(&rstCauseRoute);
    }
    *tryFlag = rstCauseRoute;
    return retVal;
}

/*主片设置rstCauseRoute*/
UINT32 BspSetCpriModeRstCauseRouteTry(UINT32 tryFlag)
{
    UINT32 retVal = BSP_ERROR;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pSetRstCauseRouteTry)
    {
        retVal = pCpriModeFunc->pSetRstCauseRouteTry(tryFlag);
    }
    return retVal;
}

/*主片获取PreFaultPos*/
UINT32 BspGetCpriModePreFaultPos(UINT32 *faultPos)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 preFaultPos = 0;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(faultPos);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetPreFaultPos)
    {
        retVal = pCpriModeFunc->pGetPreFaultPos(&preFaultPos);
    }
    *faultPos = preFaultPos;
    return retVal;
}

/*主片设置PreFaultPos*/
UINT32 BspSetCpriModePreFaultPos(UINT32 faultPos)
{
    UINT32 retVal = BSP_ERROR;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pSetPreFaultPos)
    {
        retVal = pCpriModeFunc->pSetPreFaultPos(faultPos);
    }
    return retVal;
}



/*主片获取IndependentFlag*/
UINT32 BspGetCpriModeIndependentFlag(UINT32 *independentFlag)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 flag = 0xf;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;
    INPUT_POINTER_CHECK(independentFlag);

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetIndependentFlag)
    {
        retVal = pCpriModeFunc->pGetIndependentFlag(&flag);
    }
    BspLog(LOG_INFO,LOG_LEVEL_0,"%s retVal %d flag %d\n", __func__, retVal, flag);
    if((BSP_OK == retVal)&&(flag <= 1))    /*返回值校验+出参校验*/
    {
        *independentFlag = flag;
    }
    else
    {
        *independentFlag = 1;
    }

    return retVal;
}



/*主片设置IndependentFlag*/
UINT32 BspSetCpriModeIndependentFlag(UINT32 independentFlag)
{
    UINT32 retVal = BSP_ERROR;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;

    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pSetIndependentFlag)
    {
        retVal = pCpriModeFunc->pSetIndependentFlag(independentFlag);
    }

    return retVal;
}


UINT32 BspGetOptCpriModePathLaneRoutePara(UINT32 path, T_CpriModeLaneRoutePara* tpara)
{
    UINT32 loopx = 0;
    UINT32 loopy = 0;
    INPUT_POINTER_CHECK(tpara);

    if (path >= BSP_OPT_CPRI_MODE_MAX_TYPE)
    {
        return BSP_ERROR;
    }

    BspSetLaneRoutePath(path);
    tpara->chipNum = s_CpriModeLaneRoutePara[path].chipNum;
    tpara->magic = s_CpriModeLaneRoutePara[path].magic;
    tpara->version = s_CpriModeLaneRoutePara[path].version;
    tpara->crc = s_CpriModeLaneRoutePara[path].crc;
    tpara->routePath = s_CpriModeLaneRoutePara[path].routePath;
    tpara->resv1 = s_CpriModeLaneRoutePara[path].resv1;
    for (loopx = 0; loopx < s_CpriModeLaneRoutePara[path].chipNum; loopx++)
    {
        tpara->chipSerdesPara[loopx].chipId = s_CpriModeLaneRoutePara[path].chipSerdesPara[loopx].chipId;
        tpara->chipSerdesPara[loopx].serdesNum = s_CpriModeLaneRoutePara[path].chipSerdesPara[loopx].serdesNum;
        for (loopy = 0; loopy < s_CpriModeLaneRoutePara[path].chipSerdesPara[loopx].serdesNum; loopy++)
        {
            tpara->chipSerdesPara[loopx].serdesPara[loopy].serdesPortId = s_CpriModeLaneRoutePara[path].chipSerdesPara[loopx].serdesPara[loopy].serdesPortId;
            tpara->chipSerdesPara[loopx].serdesPara[loopy].serdesModeType = s_CpriModeLaneRoutePara[path].chipSerdesPara[loopx].serdesPara[loopy].serdesModeType;
            tpara->chipSerdesPara[loopx].serdesPara[loopy].serdesProp = s_CpriModeLaneRoutePara[path].chipSerdesPara[loopx].serdesPara[loopy].serdesProp;
        }
    }

    return BSP_OK;
}
UINT32 BspGetOptCpriModePathParaFromRam(T_CpriModeLaneRoutePara* tpara)
{
    T_CpriModeLaneRoutePara tmpPara = {0};
    INPUT_POINTER_CHECK(tpara);
    UINT32 retVal = BSP_OK;
    retVal = BspHalAdaptGetPathPara((UINT32 *)&tmpPara, sizeof(T_CpriModeLaneRoutePara));
    if((BSP_OK != retVal)||(0x5a5a != tmpPara.magic))
    {
        return BSP_ERROR;
    }
    memcpy_s(tpara,sizeof(T_CpriModeLaneRoutePara),&tmpPara,sizeof(T_CpriModeLaneRoutePara));
    return BSP_OK;
}


UINT32 BspSetSlaveIcLoadSta(VOID)
{
    return BSP_OK;
}

/*高层通过写GPIO 通知主片 0x52寄存器 从片加载状态*/
UINT32 BspSetSlaveIcLoadStatus(UINT32 socLoadSta)
{
    UINT32 retVal = BSP_OK;
    UINT32 rpuId  = 0;
    UINT32 regPinVal = 0;

    regPinVal = !(!socLoadSta);
    rpuId = BspGetRpuId();
    if(0 != rpuId)
    {
        retVal = BspRegPinWr(IC_LOAD_STA, regPinVal);
    }
    BspLog(LOG_LEVEL_0,"%s>> rpuId:%d set soc load flag[appflag:%d] [regVal:%d]\r\n",__func__,rpuId,socLoadSta,regPinVal);

    return retVal;
}
UINT32 BspGetCpriModeLaneRouteNewPath(T_AllInnerSerdesDownStatus *innerSerdesDownStatus, UINT32 *newPath)
{
    UINT32 retVal = BSP_ERROR;
    T_CpriModeSwitchCfgFunc *pCpriModeFunc = NULL;

    INPUT_POINTER_CHECK(innerSerdesDownStatus);
    INPUT_POINTER_CHECK(newPath);
    pCpriModeFunc = BspGetCpriModeSwitchCfgFunc();
    INPUT_POINTER_CHECK(pCpriModeFunc);

    if (NULL != pCpriModeFunc->pGetCpriModeLaneRouteNewPathNo)
    {
        retVal = pCpriModeFunc->pGetCpriModeLaneRouteNewPathNo(innerSerdesDownStatus, newPath);
    }
    // *newPath = laneRoutePath;

    return retVal;
}
VOID showlaneroutecurr(VOID)
{
    UINT32 loopx = 0;
    UINT32 loopy = 0;
    UINT32 serdesPortId = 0;
    UINT32 serdesModeType = 0;
    UINT32 serdesProp = 0;
    UINT32 laneRoutePath = 0;
    laneRoutePath = BspGetLaneRoutePath();
    dbgInfo("[path]:%d\r\n",laneRoutePath);
    dbgInfo("[Magic]:%#x [struc_version]:%d [crc]:%#x [Path] %d\r\n",s_CpriModeLaneRoutePara[laneRoutePath].magic,s_CpriModeLaneRoutePara[laneRoutePath].version,
           s_CpriModeLaneRoutePara[laneRoutePath].crc,s_CpriModeLaneRoutePara[laneRoutePath].routePath);
    dbgInfo("################### [chipNum]:%d ######################\r\n",s_CpriModeLaneRoutePara[laneRoutePath].chipNum);
    for (loopx = 0; loopx < s_CpriModeLaneRoutePara[laneRoutePath].chipNum; loopx++)
    {
        dbgInfo("[chipId]:%d [serdesNum]:%d\r\n",s_CpriModeLaneRoutePara[laneRoutePath].chipSerdesPara[loopx].chipId,s_CpriModeLaneRoutePara[laneRoutePath].chipSerdesPara[loopx].serdesNum);
        for (loopy = 0; loopy < s_CpriModeLaneRoutePara[laneRoutePath].chipSerdesPara[loopx].serdesNum; loopy++)
        {
            serdesPortId = s_CpriModeLaneRoutePara[laneRoutePath].chipSerdesPara[loopx].serdesPara[loopy].serdesPortId;
            serdesModeType = s_CpriModeLaneRoutePara[laneRoutePath].chipSerdesPara[loopx].serdesPara[loopy].serdesModeType;
            serdesProp = s_CpriModeLaneRoutePara[laneRoutePath].chipSerdesPara[loopx].serdesPara[loopy].serdesProp;
            dbgInfo("[serdesPortId]:%d [serdesModeType]:%d [serdesProp]:%d\r\n",serdesPortId,serdesModeType,serdesProp);
        }
        dbgInfo("--------------------- chipIdx:%d ---------------------\r\n",loopx);
    }
}

VOID showlaneroutebypath(UINT32 laneRoutePath)
{
    UINT32 loopx = 0;
    UINT32 loopy = 0;
    UINT32 serdesPortId = 0;
    UINT32 serdesModeType = 0;
    UINT32 serdesProp = 0;
    T_CpriModeLaneRoutePara routePara = {0};

    if (laneRoutePath > BSP_OPT_CPRI_MODE_MAX_TYPE)
    {
        dbgErr("laneRoutePath:%d over range!\r\n",laneRoutePath);
        return;
    }

    BspGetOptCpriModePathLaneRoutePara(laneRoutePath, &routePara);

    dbgInfo("[path]:%d\r\n",laneRoutePath);
    dbgInfo("[Magic]:%#x [struc_version]:%d [routeParacrc]:%#x [RoutePath] %d [resv1] %d\r\n",routePara.magic,routePara.version,routePara.crc, routePara.routePath,routePara.resv1);
    dbgInfo("################### [chipNum]:%d ######################\r\n",routePara.chipNum);
    for (loopx = 0; loopx < routePara.chipNum; loopx++)
    {
        dbgInfo("[chipId]:%d [serdesNum]:%d\r\n",routePara.chipSerdesPara[loopx].chipId,routePara.chipSerdesPara[loopx].serdesNum);
        for (loopy = 0; loopy < routePara.chipSerdesPara[loopx].serdesNum; loopy++)
        {
            serdesPortId = routePara.chipSerdesPara[loopx].serdesPara[loopy].serdesPortId;
            serdesModeType = routePara.chipSerdesPara[loopx].serdesPara[loopy].serdesModeType;
            serdesProp = routePara.chipSerdesPara[loopx].serdesPara[loopy].serdesProp;
            dbgInfo("[serdesPortId]:%d [serdesModeType]:%d [serdesProp]:%d\r\n",serdesPortId,serdesModeType,serdesProp);
        }
        dbgInfo("--------------------- chipIdx:%d ---------------------\r\n",loopx);
    }
}
UINT32 g_ulCurRoutePath = 0xff;
VOID BspRecordCpriModeCurRoutePath(UINT32 laneRoutePath)
{
    g_ulCurRoutePath = laneRoutePath;
}
UINT32 BspGetCpriModeCurrRoutePath(VOID)
{
    return g_ulCurRoutePath;
}

UINT32 BspGetLaneRoutePathFromFlash(UINT32 *path)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(path);
    retVal = BspGetLaneSelfSaveFileFromFlash(LANEROUTEPATH_INDEX, path);
    BspLog(LOG_LEVEL_0,"%s retVal %d *path %d\n", __func__, retVal, *path);
    return retVal;
}

UINT32 BspSetLaneRoutePathFromFlash(UINT32 path)
{
    UINT32 retVal = BSP_OK;
    retVal  = BspSetLaneSelfSaveFileFromFlash(LANEROUTEPATH_INDEX, path);
    return retVal;
}

UINT32 BspGetLaneRouteTryingTimesFromFlash(UINT32 *times)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(times);
    retVal = BspGetLaneSelfSaveFileFromFlash(TRYTIMES_INDEX, times);
    return retVal;
}

UINT32 BspSetLaneRouteTryingTimesFromFlash(UINT32 times)
{
    UINT32 retVal = BSP_OK;
    retVal  = BspSetLaneSelfSaveFileFromFlash(TRYTIMES_INDEX, times);
    return retVal;
}
/*LaneRouteTryDyingWords=1 每次自救掉电复位请求时置1，在复位完成后由APP清零，用于复位阶段告警的美化“单板初始化”*/
UINT32 BspGetRstCauseRouteTryFromFlash(UINT32 *tryFlag)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(tryFlag);
    retVal = BspGetLaneSelfSaveFileFromFlash(DYINGWORDS_INDEX, tryFlag);
    return retVal;
}
UINT32 BspSetRstCauseRouteTryFromFlash(UINT32 tryFlag)
{
    UINT32 retVal = BSP_OK;

    retVal  = BspSetLaneSelfSaveFileFromFlash(DYINGWORDS_INDEX, tryFlag);
    return retVal;
}

/*PreFaultPos 无符号整形，取值0~5，意义：前一次复位前诊断的故障点在连接拓扑中的顺序编号，用于识别连续两次故障不是同一故障点，
 * 保证3次防抖都是相同故障点才进行链路规则切换 本次复位原因和上次PreFaultPos不同则需要更新PreFaultPos的同时，清除PathTryTime=0*/
UINT32 BspGetPreFaultPosFromFlash(UINT32 *faultPos)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(faultPos);
    retVal = BspGetLaneSelfSaveFileFromFlash(PREFAULTPOS_INDEX, faultPos);
    return retVal;
}
UINT32 BspSetPreFaultPosFromFlash(UINT32 faultPos)
{
    UINT32 retVal = BSP_OK;
    retVal  = BspSetLaneSelfSaveFileFromFlash(PREFAULTPOS_INDEX, faultPos);
    return retVal;
}
/*当独立标志=1，则使用独立lane方案（对于支持独立方案的机型，文件不存在时，默认使用独立方案；不支持独立方案的机型则这个字段始终=0）
        支持独立lane方案的机型，在IndependentFlag =1且连续3次掉电复位仍存在片间互联lane故障（SGMII或者IQ lane故障）
        则切换到IndependentFlag =0按照合一lane方案执行 */
UINT32 BspGetIndependentFlagFromFlash(UINT32 *independentFlag)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(independentFlag);
    retVal = BspGetLaneSelfSaveFileFromFlash(INDEPENDENTFLAG_INDEX, independentFlag);
    return retVal;
}
UINT32 BspSetIndependentFlagFromFlash(UINT32 independentFlag)
{
    UINT32 retVal = BSP_OK;

    retVal  = BspSetLaneSelfSaveFileFromFlash(INDEPENDENTFLAG_INDEX, independentFlag);
    return retVal;
}

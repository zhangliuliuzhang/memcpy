#include "bsppub.h"
#include "bspcomm.h"
#include "optctrl_inter_def.h"
#include "optctrlapi.h"
#include "secure_func.h"
#include "funccommon_a.h"
#include "optctrl_cpri_ic4_2.h"
#include "timedelay_ic4_2.h"
#include "regdrv.h"
#include "regdrv_accesstbl.h"
#include "ichal_opt_api.h"
#include "optctrlcommon.h"
#include "timedelayapi.h"
#include "dif_dly_comp.h"
#include "timedelay_ic4_2_interface.h"
#include "dlyapi.h"
#include "rruinfo.h"
#include "funccommon_fpga.h"

/* 缓存最大小区个数 */
#define DEBUG_MAX_RECORD_NUM 16
#define MAX_IQ_RECORD_MAX_NUM 96
/* 1 BspOptEcpriCellInfoInit 接口维测记录*/
UINT32 BspOptEcpriCellInfoInit_CntS[OPT_ADPT_DIR_MAX+DEBUG_MAX_RECORD_NUM]={0};
UINT32 BspOptEcpriCellInfoInit_RetValS[OPT_ADPT_DIR_MAX]={0};

/* 2 BspOptCellInfoInit 接口比较特殊，需要多个变量标记*/
UINT32 BspOptCellInfoInit_CntS[1+DEBUG_MAX_RECORD_NUM]={0};
UINT32 BspOptCellInfoInit_RetValS[1]={0};

/* 3 BspInitOptCfgInfo 接口维测记录*/
UINT32 BspInitOptCfgInfo_Cnt=0;
UINT32 BspInitOptCfgInfo_RetVal=0;

/* 4 BspOptL1CellPrachInfoInit 接口维测记录*/
UINT32 BspOptL1CellPrachInfoInit_Cnt=0;
UINT32 BspOptL1CellPrachInfoInit_RetVal=0;
UINT32 BspOptL1CellPrachInfoInit_RachNum=0;

/* 5 BspOptCellInfoCfg 接口维测记录*/

/* 6 BspInitOptCpriParam 接口维测记录*/
UINT32 BspInitOptCpriParam_Cnt=0;
UINT32 BspInitOptCpriParam_RetVal=0;

/* 7 BspOptCpriInit 接口维测记录*/
UINT32 BspOptCpriInit_Cnt=0;
UINT32 BspOptCpriInit_RetVal=0;

/* 8 BspOptCpriInit 接口维测记录*/
UINT32 BspOptMeasureInit_Cnt=0;
UINT32 BspOptMeasureInit_RetVal=0;

/* 保存配置到HAL层的整机制式 */
static UINT32 s_SetToHalRadioStandard = 0;
static UINT32 s_ScaleThreadFlag = 0;
T_DbxOptCellInfo* g_sOptCellInfo[OPT_CELL_NUM] = {0};
/* static FUNC_GET_MAIN_PORT s_pBspGetMainPort = NULL; */
static FUNC_GET_OPT_STATUS s_pBspGetOptStatus = NULL;
/* static FUNC_CREATE_KU5P s_pBspCreate_ku5p = NULL; */


typedef struct T_OptIqSample {
    UINT32 radioMode;
    UINT32 bandWidth;
    UINT32 sample;
} T_OptIqSample;

#if 0
static T_OptIqSample  iqSampleTbl[] = {
    {0x20, 10000, 30720},
    {0x20, 20000, 30720},
    {0x2000, 20000, 30720},
    {0x2000, 30000, 30720},
    {0x2000, 40000, 46080},
    {0x2000, 50000, 61440},
    {0x2000, 60000, 61440},
    {0x2000, 70000, 92160},
    {0x2000, 80000, 92160},
    {0x2000, 90000, 122880},
    {0x2000, 100000, 122880}
};
#endif

/*funclib负责将采样率枚举值转换为具体采样率数值 */
static UINT32 s_OptSampleRateInfo[OAM_CELL_CARR_SAMPLERATE_MAX] =
{
    30720,
    46080,
    61440,
    76800,
    92160,
    122880,
    153600,
    184320,
    245760,
    23040,
};

typedef struct T_IqRecordBspBackup
{
    /*16ant*4cell = 单独IC支持64个 IQ*/
    UINT32 ulCfgNum;
    T_IQRecord_BSP tIqRecord[MAX_IQ_RECORD_MAX_NUM];
}TIqRecordBspBackup;
TIqRecordBspBackup g_IqRecordBspBackup = {0};
TIqRecordBspBackup g_RachIqRecordBspBackup = {0};

typedef struct T_SlaveIqRecordBspBackup
{
    /*16ant*4cell = 单独IC支持64个 IQ*/
    UINT32 ulCfgNum;
    T_IQRecord_Slave *tIqRecord;
}TSlaveIqRecordBspBackup;
TSlaveIqRecordBspBackup g_SalveIqRecordBspBackup = {0};
T_IQRecord_Slave *g_pTmpIqRecord = NULL;
UINT32 g_ulBspLoadOptSpeed[OPTMAXNUM] = {0};
UINT32 g_ulMainPhyOptFromApp = 0;
static FUNC_InitStoredCarrWgt pBspInitStoredCarrWgt = NULL;
static FUNC_DELTE_CARR_CLOSE_AAC pDelteCarrCloseAac = NULL;

UINT32 BspInitStoredCarrWgtCallback(FUNC_InitStoredCarrWgt pInitStoredCarrWgt)
{
    pBspInitStoredCarrWgt = pInitStoredCarrWgt;

    return BSP_OK;
}

/* Started by AICoder, pid:e3936c0fa4t74b41491c08dda05e8f108465b99f */
UINT32 BspDelteCarrCloseAacCallback(FUNC_DELTE_CARR_CLOSE_AAC pCallBack)
{
    pDelteCarrCloseAac = pCallBack;
    return BSP_OK;
}
/* Ended by AICoder, pid:e3936c0fa4t74b41491c08dda05e8f108465b99f */

#if 0  /*ecpr接口先屏蔽掉*/
/***************************************************************ecpri satrt*****************************************************************/
/**********************************************************************
* BspSetOptAntFlowMapInfo
* 功能描述：设置天线和Flow 映射关系，针对ECPRI协议
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
************************************************************************/
UINT32 BspSetOptAntFlowMapInfo(T_OptAntFlowMapInfo*  optAntFlowMapInfoArr, UINT32 mapArrSize)
{
    return BspHalAdaptSetOptAntFlowMapInfo(optAntFlowMapInfoArr, mapArrSize);
}

/**********************************************************************
* 函数名称：BspSetOptLinkTbl
* 功能描述：mcs-dpdic ecpri的物理连接关系配置
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------
* 2016/05/30       V1.0      Yaoziqiang            创建
************************************************************************/
UINT32 BspSetOptLinkTbl(T_Opt_Link_Tbl *pOptlink,UINT32 LinkNum)
{
    return BspHalAdaptSetOptLinkTbl(pOptlink, LinkNum);
}

/**********************************************************************
* BspOptEcpriCellInfoInit
* 功能描述：高层按照小区配置ecpri通路,给高层提供的接口
* 输入参数：
* 输出参数：
* 返 回 值：
* 其他说明：
* 修改日期        版本号       修改人            修改内容
* ----------------------------------------------------------------------*/
UINT32 BspOptEcpriCellInfoInit(T_EcpriCellStreamInfo *pPara,UINT32 dir)
{
    if(OPT_ADPT_DIR_MAX <= dir)
    {
        BspOptEcpriCellInfoInit_CntS[OPT_ADPT_DIR_MAX+0]++;
        dbgErr("%s:input data'%d out of range\n", __func__, dir);
        return BSP_ERROR;
    }
    BspOptEcpriCellInfoInit_CntS[dir]++;
    BspOptEcpriCellInfoInit_RetValS[dir] = BspHalAdaptInitOptEcpriCellInfo(pPara, dir);
    return BspOptEcpriCellInfoInit_RetValS[dir];
}

#endif

/*****************************************************************************
*  函数名称   : BspAcWgtSwitchByChnMap
*  功能描述   : 给APP提供的，配置PRACH 天线权值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : acType :AC 权值类型; uAntMask：天线掩码;uSwitch：
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), yeyouan@2021-04-28 14:55:24 created
*----------------------------------------------------------------------------
*/
UINT32 BspAcWgtSwitchByChnMap(UINT32 acType, UINT32 uAntMask, UINT32 uSwitch)
{
	return BspHalAdaptAcWgtSwitchByChnMap(acType, uAntMask, uSwitch);
}


#if 0
/* Ecpri流量周期上报，3.0中为空实现，4.0保留，如有需求，待后续完善 */
UINT32 BspClrOptEcpriPktsInfo(UINT32 optId)
{

    return BSP_OK;
}
UINT32 BspGetOptEcpriPktsInfo(UINT32 optId,T_EcpriPktsStat *pStat)
{
    /* 此函数4.0作废，保留目的是为了APP编译能过，待APP删除调用，同步清理 */
    return BSP_OK;
}

/* 光口下行联合采数接口 */
UINT32 BspSetEcpriPowThrodEn(UINT32 uEnable)
{
    //return BspHalAdaptSetCwHiPowRptEn(uEnable); 目前没有ecpri暂不考虑
}

/* 光口下行联合采数接口，4.0中已不需要，为保持和3.0流程一致，保留，内部为空 */
UINT32 BspSetCwHiPowRtpCfg(T_CwHiPowRtpInfo *ptCwHiPowRtpInfo, UINT32 num)
{
    /* 已在单板初始化中配置过，不需要高层更新 */
	//return BspHalAdaptSetCwHiPowRptCfg(ptCwHiPowRtpInfo, num);
	return BSP_OK;
}

/* 远程硬复位 */
UINT32 BspSetEcpriRemoteRst(UINT8 *pDestMac1,UINT8 *pDestMac2)
{
    return BspHalAdaptSetEcpriRemoteRst(pDestMac1, pDestMac2);
}
#endif
/***************************************************************ecpri end*****************************************************************/
#if 0//高铁可能使用，先屏蔽掉
VOID BspSetCreateKu5pCallBack(FUNC_CREATE_KU5P pFunc)
{
    s_pBspCreate_ku5p = pFunc;
}
UINT32 BspBbuToKu5pCfg(UINT32 ulCellIndex)
{
    if(s_pBspCreate_ku5p)
    {
        return s_pBspCreate_ku5p(ulCellIndex);
    }
    return BSP_OK;
}
#endif
VOID PrintOptCntSRetValS(VOID)
{
    UINT32 loop = 0;
    dbgInfo("\n1: BspOptEcpriCellInfoInit\n");
    /* 1 BspOptEcpriCellInfoInit 接口维测记录*/
    for(loop = 0; loop < OPT_ADPT_DIR_MAX+DEBUG_MAX_RECORD_NUM; loop++)
        dbgInfo("BspOptEcpriCellInfoInit: loop'%3d, CntS'%6d\n",       loop, BspOptEcpriCellInfoInit_CntS[loop]);
    for(loop = 0; loop < OPT_ADPT_DIR_MAX; loop++)
        dbgInfo("BspOptEcpriCellInfoInit: loop'%3d, RetValS'0x%08X(0-Good)\n", loop, BspOptEcpriCellInfoInit_RetValS[loop]);

    dbgInfo("\n2 BspOptCellInfoInit \n");
    /* 2 BspOptCellInfoInit 接口维测记录*/
    for(loop = 0; loop < 1+DEBUG_MAX_RECORD_NUM; loop++)
        dbgInfo("BspOptCellInfoInit: loop'%3d, CntS'%6d\n",      loop, BspOptCellInfoInit_CntS[loop]);
    for(loop = 0; loop < 1; loop++)
        dbgInfo("BspOptCellInfoInit: loop'%3d, RetValS'0x%08X(0-Good)\n", loop, BspOptCellInfoInit_RetValS[loop]);

        dbgInfo("\n3 BspInitOptCfgInfo \n");
        /* 3 BspInitOptCfgInfo 接口维测记录*/
        dbgInfo("BspInitOptCfgInfo: Cnt'%d\n",          BspInitOptCfgInfo_Cnt);
        dbgInfo("BspInitOptCfgInfo: RetVal'0x%08X(0-Good)\n", BspInitOptCfgInfo_RetVal);

        dbgInfo("\n4 BspOptL1CellPrachInfoInit \n");
        /* 4 BspOptL1CellPrachInfoInit 接口维测记录*/
        dbgInfo("BspOptL1CellPrachInfoInit: Cnt'%d\n",         BspOptL1CellPrachInfoInit_Cnt);
        dbgInfo("BspOptL1CellPrachInfoInit: RetVal'0x%08X(0-Good)\n", BspOptL1CellPrachInfoInit_RetVal);
        dbgInfo("BspOptL1CellPrachInfoInit: RachNum'%d\n",     BspOptL1CellPrachInfoInit_RachNum);

    dbgInfo("\n5 BspOptCellInfoCfg \n");
    /* 5 BspOptCellInfoCfg 接口维测记录*/
}
VOID PrintOptCellInfo(T_CellCfgInfo* cellInfo)
{
    if (!cellInfo)
    {
        return;
    }
    dbgInfo("cellIndex: %u\r\n", cellInfo->cellIndex);
    dbgInfo("cellAdFlag: %u\r\n", cellInfo->cellAdFlag);
    dbgInfo("cellMcsId: %u\r\n", cellInfo->cellMcsId);
    dbgInfo("cellLocalCarrNo: %u\r\n", cellInfo->cellLocalCarrNo);
    dbgInfo("cellBw[0]: %u, cellBw[1]: %u\r\n", cellInfo->cellBw[0], cellInfo->cellBw[1]);
    dbgInfo("cellIFType: %u\r\n", cellInfo->cellIFType);
    dbgInfo("cellBearType: %u\r\n", cellInfo->cellBearType);
    dbgInfo("cellSCSBitMap: %#x\r\n", cellInfo->cellSCSBitMap);
    dbgInfo("cellTTI: %u\r\n", cellInfo->cellTTI);
    dbgInfo("cellAntRadioMode: %#x\r\n", cellInfo->cellAntRadioMode);
    dbgInfo("cellCarrNo: %u\r\n", cellInfo->cellCarrNo);
    dbgInfo("cellAntMask[0]: %#x, [1]: %#x\r\n", cellInfo->cellAntMask[0],cellInfo->cellAntMask[1]);
    dbgInfo("cellULCompressMode: %u\r\n", cellInfo->cellULCompressMode);
    dbgInfo("cellDLDeCompressMode: %u\r\n", cellInfo->cellDLDeCompressMode);
    dbgInfo("cellTxSymbolBit[0]: %u,[1]: %u\r\n", cellInfo->cellTxSymbolBit[0], cellInfo->cellTxSymbolBit[1]);
    dbgInfo("cellRxSymbolBit[0]: %u,[1]: %u\r\n", cellInfo->cellRxSymbolBit[0],cellInfo->cellRxSymbolBit[1]);
    dbgInfo("cellIQPkgOLEN[0]: %u,[1]: %u\r\n", cellInfo->cellIQPkgOLEN[0],cellInfo->cellIQPkgOLEN[1]);
    dbgInfo("iqSampleRate: %u\r\n", cellInfo->iqSampleRate);
    dbgInfo("cellgScn: %u\r\n", cellInfo->cellgScn);
    dbgInfo("cellSsbValid: %u\r\n", cellInfo->cellSsbValid);
    dbgInfo("fftaCpType: %u\r\n", cellInfo->fftaCpType);
    dbgInfo("cellCAMode: %u\r\n", cellInfo->cellCAMode);
    dbgInfo("cellPrachDagcEn: %u\r\n", cellInfo->cellPrachDagcEn);
    dbgInfo("celltax: %u\r\n", cellInfo->tax);
    dbgInfo("-------------------------------------------------------------------------\r\n");
}

VOID PrintOptPrachInfo(T_PrachCellInfo* prachInfo)
{
    if (prachInfo == NULL)
    {
        dbgErr("invalid input param prach info\r\n");
        return;
    }
    dbgInfo("cellIndex [%u]\r\n", prachInfo->cellIndex);
    dbgInfo("prachConfigIndex [%u]\r\n", prachInfo->prachConfigIndex);
    dbgInfo("prachCommpress [%u]\r\n", prachInfo->prachCommpress);
    dbgInfo("prachPktOlen [%u]\r\n", prachInfo->prachPktOlen);
    dbgInfo("prachAntMask [%#x]\r\n", prachInfo->prachAntMask);
    dbgInfo("prachFreqOffSet [%u]\r\n", prachInfo->prachFreqOffSet[0]);
    dbgInfo("prachBBACWeight [%u]\r\n", prachInfo->prachBBACWeight[0]);
    dbgInfo("prachRFACWeight [%u]\r\n", prachInfo->prachRFACWeight[0]);
    dbgInfo("prachSCSBitMap [%#x]\r\n", prachInfo->prachSCSBitMap);
    dbgInfo("prachFreqNum [%u]\r\n", prachInfo->prachFreqNum);
    dbgInfo("-------------------------------------------------------------------------\r\n");
}

VOID PrintOptCellCfgSt(T_DbxOptCellInfo* cellInfo)
{
    if (cellInfo == NULL)
    {
        dbgErr("invalid input param cellInfo\r\n");
        return;
    }
    PrintOptCellInfo(&cellInfo->optCellInfo);
    PrintOptPrachInfo(&cellInfo->optPrachInfo);
}
VOID PrintOptCellInfoUsingCellId(UINT32 cellId)
{
    UINT32 loop = 0;
    UINT32 cellBufSize = 0;
    cellBufSize = sizeof(g_sOptCellInfo) / sizeof(g_sOptCellInfo[0]);

    for(loop = 0; loop < cellBufSize; loop++)
    {
        if (g_sOptCellInfo[loop] == (T_DbxOptCellInfo*)NULL)
        {
            continue;
        }

        if (g_sOptCellInfo[loop]->optCellInfo.cellIndex != cellId)
        {
            continue;
        }
        PrintOptCellCfgSt(g_sOptCellInfo[loop]);
    }
}

VOID PrintOptCellTips(VOID)
{
    UINT32 loopI = 0;
    UINT32 cellBufSize = 0;
    cellBufSize = sizeof(g_sOptCellInfo) / sizeof(g_sOptCellInfo[0]);

    for(loopI = 0; loopI < cellBufSize; loopI++)
    {
        if (g_sOptCellInfo[loopI] == (T_DbxOptCellInfo*)NULL)
        {
            continue;
        }
        dbgInfo("Index [%u], cellId [%u],cell type  [%u], carrNo [%u], radio [%u], bw [%u], Tx antMask %d Rx antMask %d cellAddr [%p], prachAddr [%p]\r\n",
                loopI, g_sOptCellInfo[loopI]->optCellInfo.cellIndex, g_sOptCellInfo[loopI]->optCellInfo.cellIFType, g_sOptCellInfo[loopI]->optCellInfo.cellCarrNo,
                g_sOptCellInfo[loopI]->optCellInfo.cellAntRadioMode, g_sOptCellInfo[loopI]->optCellInfo.cellBw[0],g_sOptCellInfo[loopI]->optCellInfo.cellAntMask[1],
				g_sOptCellInfo[loopI]->optCellInfo.cellAntMask[0],&g_sOptCellInfo[loopI]->optCellInfo, &g_sOptCellInfo[loopI]->optPrachInfo);
    }
}

INT32 BspGetStoreIndexUsingCellId(UINT32 cellId)
{
    UINT32 cellBufSize = 0;
    INT32  freeIndex = -1;
    INT32 index = 0;
    cellBufSize = sizeof(g_sOptCellInfo) / sizeof(g_sOptCellInfo[0]);

    for (index = 0; index < cellBufSize; index++)
    {
        if (g_sOptCellInfo[index] == NULL)
        {
            if (freeIndex == -1)
            {
                freeIndex = index;
            }
            continue;
        }
        if (g_sOptCellInfo[index]->optCellInfo.cellIndex == cellId)
        {
            return index;
        }
    }

    if (freeIndex < 0)
    {
        dbgErr("have no free space store cell info\r\n");
        return freeIndex;
    }
    else
    {
        g_sOptCellInfo[(UINT32)freeIndex] = (T_DbxOptCellInfo*)malloc(sizeof(T_DbxOptCellInfo));
        (void)memset_s(g_sOptCellInfo[(UINT32)freeIndex], sizeof(T_DbxOptCellInfo), 0, sizeof(T_DbxOptCellInfo));
        return freeIndex;
    }
}

static char* g_sOptHelp [] = {
    "PrintOptCellInfoUsingCellId cellId celid [0~31]",
    "PrintOptCellTips",
    "PrintOptPrachInfo prachAddr\r\n",
    "PrintOptCellInfo cellAddr\r\n",
    "PrintOptCntSRetValS\n",
    "PrnIqCfg\n",
    "PrnSlaveIqCfg\n",
};

void opthelp(void)
{
    UINT32 loopI = 0;
    for (loopI = 0; loopI < sizeof(g_sOptHelp) / sizeof(g_sOptHelp[0]); loopI++)
    {
        dbgInfo("%s\r\n", g_sOptHelp[loopI]);
    }
}

UINT32 BspRecOptCellInfo(T_CellCfgInfo* cellInfo)
{
    INT32 index = 0;
    INPUT_POINTER_CHECK(cellInfo);
    index = BspGetStoreIndexUsingCellId(cellInfo->cellIndex);
    if (index < 0)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(g_sOptCellInfo[index]);
    (void)memcpy_s(&g_sOptCellInfo[index]->optCellInfo, sizeof(T_CellCfgInfo), cellInfo, sizeof(T_CellCfgInfo));

    /*释放删除小区的资源*/
    if(g_sOptCellInfo[index]->optCellInfo.cellAdFlag == 2)
    {
    	BspLog(LOG_LEVEL_0,"%s enter,cellIdx=%d free ok\n",  __FUNCTION__, g_sOptCellInfo[index]->optCellInfo.cellIndex);
    	free(g_sOptCellInfo[index]);
    	g_sOptCellInfo[index] = NULL;
    }
    return BSP_OK;
}

/* Started by AICoder, pid:ye252t54a575cd7145250b11e097a23b60b0fd1b */
UINT32 BspGetOptCellInfoByCarr(UINT32 ulChan, UINT32 ulDir, UINT32 carrId, UINT32 ulRadio, T_CellCfgInfo* cellInfo)
{
	UINT32 index = 0;
    // 检查输入指针是否为空
	INPUT_POINTER_CHECK(cellInfo);

	if(ulDir > TX)
	{
		return BSP_ERROR;
	}

    for (index = 0; index < OPT_CELL_NUM; index++)
    {
        if (NULL != g_sOptCellInfo[index])
        {
            if (((BIT_SET(ulChan) & (g_sOptCellInfo[index]->optCellInfo.cellAntMask[ulDir])) != 0) &&
                 (g_sOptCellInfo[index]->optCellInfo.cellAntRadioMode == ulRadio) &&
                 (carrId == g_sOptCellInfo[index]->optCellInfo.cellCarrNo))
            {
                (void)memcpy_s(cellInfo, sizeof(T_CellCfgInfo), &g_sOptCellInfo[index]->optCellInfo, sizeof(T_CellCfgInfo));
                break;
            }
        }
    }

    if (OPT_CELL_NUM == index)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:ye252t54a575cd7145250b11e097a23b60b0fd1b */

/* Started by AICoder, pid:b2a83oc899nb8a3140220a79f09efe25f986c11e */
UINT32 BspGetOptCellInfoByCellId(UINT32 ulCellId, T_CellCfgInfo* cellInfo)
{
    UINT32 index = 0;

    // 检查输入指针是否为空
    INPUT_POINTER_CHECK(cellInfo);

    for (index = 0; index < OPT_CELL_NUM; index++)
    {
        if (g_sOptCellInfo[index] != NULL)
        {
            if (g_sOptCellInfo[index]->optCellInfo.cellIndex == ulCellId)
            {
                (void)memcpy_s(cellInfo, sizeof(T_CellCfgInfo), &g_sOptCellInfo[index]->optCellInfo, sizeof(T_CellCfgInfo));
                break;
            }
        }
    }

    if (index == OPT_CELL_NUM)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:b2a83oc899nb8a3140220a79f09efe25f986c11e */


UINT32 BspGetIF1CarrDelay(UINT32 chan,UINT32 dir,UINT32 carrMode,UINT32 carrId,T_Delay *t_Para)
{
    UINT32 ret = BSP_OK;
    UINT32 dlT2a = 0;
    UINT32 ulTa3 = 0;
    UINT32 If1diffTime = 0;
    UINT32 ulTaValue = 0;
    T_RruDelayReq tRruDelay = {0};
    T_CellCfgInfo tCellInfo = {0};
  
    INPUT_POINTER_CHECK(t_Para);

    ret |= BspGetTaDelay(&ulTaValue);
    ret |= BspGetT12T34Delay(&tRruDelay);
    ret |= IcHalGetT2aTa3Dly(carrMode, TX, &dlT2a);
    ret |= IcHalGetT2aTa3Dly(carrMode, RX, &ulTa3);
    ret |= BspGetOptCellInfoByCarr(chan, dir, carrId, carrMode, &tCellInfo);
    If1diffTime= IcHalGetL1MaxDly(dir);

    if(BSP_ERROR == ret || tCellInfo.cellIFType != E_OPT_IF1)
    {
        return BSP_ERROR;
    }

    if(0 == tCellInfo.tax)
    {
        tCellInfo.tax = 112500;
    }

    if(TX == dir)
    {
        t_Para->fwdDly = ulTaValue + tCellInfo.tax - tRruDelay.ulMainT12 - dlT2a - If1diffTime;
        t_Para->revDly =  ulTaValue + tCellInfo.tax - tRruDelay.ulSlaveT12 - dlT2a - If1diffTime;
        dbgInfoEx("ulTaValue %d tax %d t12main %d  t12slave %d  t2a %d If1diffTime %d carrdelayFwd %d carrdelayRev %d \n", ulTaValue,
                tCellInfo.tax, tRruDelay.ulMainT12, tRruDelay.ulSlaveT12, dlT2a, If1diffTime, t_Para->fwdDly, t_Para->revDly);
    }
    else
    {
        t_Para->fwdDly =  ulTaValue + tCellInfo.tax - tRruDelay.ulmainT34 - ulTa3 - If1diffTime;
        t_Para->revDly =  ulTaValue + tCellInfo.tax - tRruDelay.ulslaveT34 - ulTa3 - If1diffTime;
        dbgInfoEx("ulTaValue %d tax %d t34main %d  t34slave %d  ta3 %d f1diffTime %d carrdelayFwd %d carrdelayRev %d \n", ulTaValue,
                tCellInfo.tax, tRruDelay.ulmainT34, tRruDelay.ulslaveT34, ulTa3, If1diffTime, t_Para->fwdDly, t_Para->revDly);
    }


    return BSP_OK;
}

UINT32 BspRecOptPrachInfo(T_PrachCellInfo* prachCfg)
{
    INT32 index = 0;
    INPUT_POINTER_CHECK(prachCfg);

    index = BspGetStoreIndexUsingCellId(prachCfg->cellIndex);
    if (index < 0)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(g_sOptCellInfo[index]);
    (void)memcpy_s(&g_sOptCellInfo[index]->optPrachInfo, sizeof(T_PrachCellInfo), prachCfg, sizeof(T_PrachCellInfo));
    return BSP_OK;
}


/****************************************************************
* 函数名称: BspConvertDlCompressModeToHal
* 函数说明： BSP convert bbu config compress mode to hal nedd compress mode
* 输入参数：cellIFType :IF type
*          ulCfgCompressMode:input compress mode
* 输出参数：no
* 返回参数：after convert compress mode
* 修改说明：
*     10294055   creat
*
*****************************************************************/

UINT32 BspConvertCompressModeToHal(UINT32 cellIFType, UINT32 ulCfgCompressMode)
{
    UINT32 ulHalCompressMode = OPT_COMPRESS_15_AGC;

    if(cellIFType == E_OPT_IF0)   /*lte 0代表15比特 1代表9比特  TDD NR的由高层转换*/
     {
         if (ulCfgCompressMode == 1)
         {
             ulHalCompressMode = OPT_COMPRESS_9_AGC;
         }
         else if(ulCfgCompressMode == 2)
         {
             ulHalCompressMode = OPT_COMPRESS_16_AGC;
         }
         else
         {
             ulHalCompressMode = OPT_COMPRESS_15_AGC;
         }
     }
     if(cellIFType == E_OPT_IF1)  /*IF1 FNR高层才从IQ识别到压缩模式 传给bsp，然后转换给光口*/
     {
         if (ulCfgCompressMode == 9)
         {
             ulHalCompressMode = OPT_COMPRESS_9_AGC; /*5*/
         }
         if (ulCfgCompressMode == 0)
         {
             ulHalCompressMode = OPT_COMPRESS_8_ALAW; /*3*/
         }
     }
     return ulHalCompressMode;
}

static VOID InitStoredCarrWgtWhenDelCell(UINT32 cellAdFlag, UINT32 logicCarrNo, UINT32 radioMode)
{
    if (cellAdFlag == CARR_FLAG_DEL)
    {
        if (pBspInitStoredCarrWgt != NULL)
        {
            pBspInitStoredCarrWgt(logicCarrNo, radioMode);
        }
    }
}

UINT32 BspSetRvsTax(UINT32 uCellId,UINT32 uRadioMode,INT32 rvsTaxDL,INT32 rvsTaxUL)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0,"%s enter,cellIdx=%d, radio=%#x,rvsTaxDL=%d rvsTaxUL=%d \n",  __FUNCTION__, uCellId, uRadioMode, rvsTaxDL, rvsTaxUL);
    dbgInfo("%s enter,cellIdx=%d, radio=%#x,rvsTaxDL=%d rvsTaxUL=%d \n",  __FUNCTION__, uCellId, uRadioMode, rvsTaxDL, rvsTaxUL);
    retVal = BspHalAdapSetRvsTax(uCellId, uRadioMode, rvsTaxDL,rvsTaxUL);

    return retVal;
}
/* FDD LTE NR BBU下发压缩模式定义
#define ZIPFLAG_15BIT            (WORD16)0
#define ZIPFLAG_9BIT             (WORD16)1
#define ZIPFLAG_12BIT            (WORD16)2
#define ZIPFLAG_7BIT             (WORD16)3
#define ZIPFLAG_8BIT             (WORD16)4
NR：
#define UNZIPFLAG (WORD16)0
#define ZIPFLAG_9BIT (WORD16)1
#define ZIPFLAG_7BIT (WORD16)3
#define ZIPFLAG_8BIT (WORD16)4
*/
UINT32 BspGetFddCompressModeFromBbuToOptHal(UINT32 ulBbuCmpIndex)
{
    UINT32 ulHalCompressMode[] = {OPT_COMPRESS_15_AGC, OPT_COMPRESS_9_AGC, OPT_COMPRESS_12_AGC, OPT_COMPRESS_7_ALAW, OPT_COMPRESS_8_ALAW};

    if(ulBbuCmpIndex < NELEMENTS(ulHalCompressMode))
    {
        return ulHalCompressMode[ulBbuCmpIndex];
    }
    return ulHalCompressMode[0];
}

/* Started by AICoder, pid:v154e8b124t9a0d14dbb0b17b01cdb22b0e4c4d0 */
UINT32 BspCfgCellModeFpga(T_CellCfgInfo *pPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 cellCarrNo = 0;
    UINT32 cellRadioMode = 0;
    UINT32 cellTxAntMask = 0;
    UINT32 cellRxAntMask = 0;
    T_FpgaInfoInit *pFpgaInfo = NULL;

    INPUT_POINTER_CHECK(pPara);
    pFpgaInfo = BspGetFpgaInfo();
    INPUT_POINTER_CHECK(pFpgaInfo);
    INPUT_POINTER_CHECK(pFpgaInfo->pFuncCfgCellModeFpga);

    cellCarrNo    = pPara -> cellCarrNo;
    cellRadioMode = pPara -> cellAntRadioMode;
    cellTxAntMask = pPara -> cellAntMask[TX];
    cellRxAntMask = pPara -> cellAntMask[RX];

    retVal = pFpgaInfo->pFuncCfgCellModeFpga(cellCarrNo, cellRadioMode, cellTxAntMask, cellRxAntMask);

    return retVal;
}
/* Ended by AICoder, pid:v154e8b124t9a0d14dbb0b17b01cdb22b0e4c4d0 */

UINT32 BspOptCellInfoInit(T_CellCfgInfo *pPara)
{
    UINT32 txResIndex = 0;
    UINT32 rxResIndex = 0;
    UINT32 ta         = 0;
    INPUT_POINTER_CHECK(pPara);
    /* 记录下发配置小区信息 */
    BspRecOptCellInfo(pPara);

    /* 日志记录 */
    BspLog(LOG_LEVEL_0,"%s enter,cellIdx=%d,cellIFType=%d,cellAdFlag=%d,bw=%d,radio=%#x,carrNo=%d,samrate=%d tax=%d rvsTax[0]=%d rvsTax[1]=%d resv[0]=%d dlcompress %d ulcompress %d pattenType %d cellAntNum %d CopyType %d bandFrmAdj %d\n",
            __FUNCTION__, pPara->cellIndex, pPara->cellIFType, pPara->cellAdFlag, pPara->cellBw[0], pPara->cellAntRadioMode, pPara->cellCarrNo, pPara->iqSampleRate,pPara->tax, pPara->rvsTax[0], pPara->rvsTax[1], pPara->resv[0], \
            pPara->cellDLDeCompressMode,pPara->cellULCompressMode,pPara->pattenType,pPara->cellAntNum[1], pPara->carrCopyType, pPara->bandFrmAdj);
    /* 打印 */
    dbgInfo("%s enter,cellIdx=%d,cellAdFlag=%d,bw=%d,radio=%#x,carrNo=%d,samrate=%d tax=%d rvsTax[0]=%d rvsTax[1]=%d resv[0]=%d pattenType=%d CopyType=%d bandFrmAdj %d\n",
            __FUNCTION__, pPara->cellIndex, pPara->cellAdFlag, pPara->cellBw[0], pPara->cellAntRadioMode, pPara->cellCarrNo, pPara->iqSampleRate,
            pPara->tax, pPara->rvsTax[0], pPara->rvsTax[1], pPara->resv[0], pPara->pattenType, pPara->carrCopyType, pPara->bandFrmAdj);

    InitStoredCarrWgtWhenDelCell(pPara->cellAdFlag, pPara->cellCarrNo, pPara->cellAntRadioMode);
    if (BSP_RADIO_STANDARD_AIOT == pPara->cellAntRadioMode)
    {
        BspCfgCellModeFpga(pPara);
    }
     /* LTE IF1采样率转换 */
    if((pPara->cellAntRadioMode == BSP_RADIO_STANDARD_LTE_TDD)&&(pPara->cellIFType == E_OPT_IF1))
    {
        if(pPara->iqSampleRate < OAM_CELL_CARR_SAMPLERATE_MAX)
        {
            pPara->iqSampleRate = s_OptSampleRateInfo[pPara->iqSampleRate];
        }
    }

    /* 4.0如果使用场景预置,则资源位置由场景预置指定,否则光口Hal自己分配资源 ,4,2上不由funclib制定资源位置,和菲哥确认不需要将光口资源位置填充给光口小区
    BspGetPreAllocResInde不需要调用*/
    /* 压缩模式转换  压缩模式转换规则待细化确认，需要高层下发代表压缩模式含义的值　　hal将这个值转换成写到具体寄存器值,具体规则待细化*/
    if((pPara->cellAntRadioMode == BSP_RADIO_STANDARD_LTE_TDD)&&(pPara->cellIFType == E_OPT_IF0))   /*lte 0代表15比特 1代表9比特  TDD NR的由高层转换*/
    {
        pPara->cellDLDeCompressMode = BspConvertCompressModeToHal(pPara->cellIFType,pPara->cellDLDeCompressMode);
        pPara->cellULCompressMode   = BspConvertCompressModeToHal(pPara->cellIFType,pPara->cellULCompressMode);
    }
    /*FDD LTE NR BSP直接由BBU下发值转换为OptHal层值 */
    if((pPara->cellAntRadioMode==BSP_RADIO_STANDARD_FDD_5G)||(pPara->cellAntRadioMode == BSP_RADIO_STANDARD_LTE_FDD)||(pPara->cellAntRadioMode == BSP_RADIO_STANDARD_NB_IOT))
    {
        pPara->cellDLDeCompressMode = BspGetFddCompressModeFromBbuToOptHal(pPara->cellDLDeCompressMode);
        pPara->cellULCompressMode   = BspGetFddCompressModeFromBbuToOptHal(pPara->cellULCompressMode);
    }

    ta = BspGetTa();
    if((pPara->cellAntRadioMode == BSP_RADIO_STANDARD_5G)&&(pPara->cellIFType == E_OPT_IF1))
    {
    	pPara->tax = pPara->tax-ta; /*TDD if1 下发的是总提前量，要减去TA，才是tax*/
    }
    /*if config info has IF1 cell ,start BspScaleConfigThreadInit */
    if((pPara->cellIFType == E_OPT_IF1) && (s_ScaleThreadFlag == 0))
    {
        BspScaleConfigThreadInit();
        s_ScaleThreadFlag = 1;
    }
    BspOptCellInfoInit_CntS[0]++;
    BspOptCellInfoInit_RetValS[0] = BspHalAdaptOptCellInfoInit(pPara, txResIndex, rxResIndex); /*不传资源位置给hal　这两个字段先保留，hal如果不用则预留，hal如果用，这两个参数初始值为0*/

    /* 日志记录 */
    BspLog(LOG_LEVEL_0,"%s exit,cellIdx=%d,samrate=%d cellDLDeCompressMode %d cellULCompressMode %d ret=%d\n", __FUNCTION__,
            pPara->cellIndex, pPara->iqSampleRate, pPara->cellDLDeCompressMode,pPara->cellULCompressMode,BspOptCellInfoInit_RetValS[0]);

    return BspOptCellInfoInit_RetValS[0];
}

/****************************************************************
* 函数名称: BspInitOptCpriParam
* 函数说明： cpri 配置参数初始化，执行的动作在BspInitOptCfgInfo里边
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspInitOptCpriParam(T_BspHalAdaptOptCpriInfo *OptCpriInfo)
{
    INPUT_POINTER_CHECK(OptCpriInfo);
    BspInitOptCpriParam_Cnt++;
    BspInitOptCpriParam_RetVal=BspHalAdaptOptCpriParamInit(OptCpriInfo);
    return BspInitOptCpriParam_RetVal;
}
/****************************************************************
* 函数名称: BspOptCpriInit
* 函数说明： 配置cpri的初始化参数
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspOptCpriInit(void)
{
	BspOptCpriInit_Cnt++;
	BspOptCpriInit_RetVal=BspHalAdaptOptCpriInit();
    return BspOptCpriInit_RetVal;
}

/****************************************************************
* 函数名称: BspCheckOptCellStatus
* 函数说明： 检查光口小区状态是否异常(光口AXC/prach偶现配置失败问题，提供APP后处理)
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10229672   创建
*
*****************************************************************/
UINT32 BspCheckOptCellStatus(UINT32 *pCheckResult)
{
    return BspHalAdaptOptCheckBifGfTblCfg(pCheckResult);
}

/****************************************************************
* 函数名称: BspCheckOptPseudoIQStatus
* 函数说明： 检查光口小区状态是否异常(光口AXC/prach偶现配置失败问题，提供APP后处理)
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10229672   创建
*
*****************************************************************/
UINT32 BspCheckOptPseudoIQStatus(UINT32 *pCheckResult)
{
    return BspHalAdaptOptPseudoIQCheck(pCheckResult);
}

/****************************************************************
* 函数名称: BspInitOptCfgInfo
* 函数说明： 光口上电初始化(配置光口链路)
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspInitOptCfgInfo(void)
{
    T_BspHalAdaptOptInitCfgInfo initPara = {0};
    BspInitOptCfgInfo_Cnt++;
    BspInitOptCfgInfo_RetVal=BspHalAdaptOptInit(&initPara);
    return BspInitOptCfgInfo_RetVal;
}
/****************************************************************
* 函数名称: BspOptMeasureInit
* 函数说明:空口帧头输出选择: 选择输出IcHalApiOptInit光口产生的帧头或管脚送入的fr作为空口帧头
* 输入参数：uCpriOrEcpri　光口协议类型   uCpriOrEcpri: 0-CPRI  1-ECPRI
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*        创建
*
*****************************************************************/
UINT32 BspOptMeasureInit(UINT32 uCpriOrEcpri)
{
	BspOptMeasureInit_Cnt++;
	BspOptMeasureInit_RetVal = BspHalAdaptMeasureInit(uCpriOrEcpri);
    return BspOptMeasureInit_RetVal;
}

UINT32 BspGetOptCellNum(void)
{
    /* 待HAL层提供接口 */
    return BSP_OK;
}

UINT32 BspOptL1CellPrachInfoInit(UINT32 uRachNum,T_PrachCellInfo *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    BspRecOptPrachInfo(pPara);

    /* 日志记录 */
    BspLog(LOG_LEVEL_0,"%s:%d,%d,%d,%d,0x%08X,%d,%d,%d,%d,%d\n", __FUNCTION__,
            pPara->cellIndex, pPara->prachConfigIndex, pPara->prachCommpress, pPara->prachPktOlen,
            pPara->prachAntMask, pPara->prachFreqOffSet[0],pPara->prachBBACWeight[0],
            pPara->prachRFACWeight[0],pPara->prachSCSBitMap, pPara->prachFreqNum);
    dbgInfo("%s:%d,%d,%d,%d,0x%08X,%d,%d,%d,%d,%d\n", __FUNCTION__,
            pPara->cellIndex, pPara->prachConfigIndex, pPara->prachCommpress, pPara->prachPktOlen,
            pPara->prachAntMask, pPara->prachFreqOffSet[0],pPara->prachBBACWeight[0],
            pPara->prachRFACWeight[0],pPara->prachSCSBitMap, pPara->prachFreqNum);

    BspOptL1CellPrachInfoInit_Cnt++;
    BspOptL1CellPrachInfoInit_RachNum = uRachNum;
    BspOptL1CellPrachInfoInit_RetVal = BspHalAdaptOptL1CellPrachInfoInit(pPara, uRachNum);

    /* 日志记录 */
    BspLog(LOG_LEVEL_0,"%s exit,cellIdx=%d ret=%d\n", __FUNCTION__,
            pPara->cellIndex, BspOptL1CellPrachInfoInit_RetVal);

    return BspOptL1CellPrachInfoInit_RetVal;
}

/* 配置整机制式(单模/混模)到光口HAL层 此处要添加fdd制式 具体规则还需要和hal商量 hal暂时还不确认，接口先保留*/
static UINT32 BspSetRadioStandardToHal(VOID)
{
    UINT32 radioMode = 0;
    UINT32 retVal = BSP_OK;

    if(!s_SetToHalRadioStandard)
    {
        /* 获取整机制式 */
        radioMode = (UINT32)BspGetRadioStandard();
        s_SetToHalRadioStandard = radioMode;
        retVal = BspHalAdaptSetCellCfgMode(radioMode);
        dbgInfoEx("%s s_SetToHalRadioStandard=%#x retVal=%#x\n",__func__, s_SetToHalRadioStandard, retVal);
    }
    return retVal;
}
/**************************************************************************
* 函数名称: BspChangeFrRule()
* 功能描述: psync帧头偏移方向配置
* 输入参数: 无
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: ０表示向前偏　１表示向后偏
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
VOID BspChangeFrRule(VOID)
{
    UINT32 pval = 0;
    UINT32 dir = RX;
    UINT32 procotol = 0;
    UINT32 mainopt = 0;

    (VOID)BspHalAdaptGetMainLogicOpt(&mainopt);
    (VOID)BspHalAdaptGetCpriProtocol(&procotol);
    pval = BspHalAdaptGetPPoint(mainopt);
    if ((pval < 53)&&(procotol != PROCOTOL_CPRI))
    {
    	dir = TX;
    }

    BspHalAdaptSetGlobleOutFrDir(dir);
    dbgInfo("%s,mainopt=%d,pval=%d\n", __FUNCTION__, mainopt, pval);
    return;
}

/* Started by AICoder, pid:m035brd10a2d243149d709d6e071143fb0750184 */
VOID BspConfigFrDir(VOID)
{
    UINT32 pval = 0;
    UINT32 dir = RX;
    UINT32 protocol = 0;
    UINT32 mainopt = 0;
    UINT32 frDir = RX;

    (VOID)BspHalAdaptGetMainLogicOpt(&mainopt);
    (VOID)BspHalAdaptGetCpriProtocol(&protocol);
    (VOID)BspHalAdaptGetGlobleOutFrDir(&frDir);

    if((protocol != PROCOTOL_IR)||(mainopt == BSP_ERROR))
    {
        return;
    }
    pval = BspHalAdaptGetPPoint(mainopt);

    if (pval < 53)
    {
        dir = TX;
    }
    else
    {
        dir = RX;
    }

    if(frDir != dir)
    {
        BspHalAdaptSetGlobleOutFrDir(dir);
    }

    dbgInfoEx("%s,mainopt=%d,pval=%d, frDir=%d\n", __FUNCTION__, mainopt, pval, frDir);
    return;
}
/* Ended by AICoder, pid:m035brd10a2d243149d709d6e071143fb0750184 */

/**************************************************************************
* 函数名称: BspOptCellInfoCfg()
* 功能描述: 光口小区配置
* 输入参数: cellId: 小区id
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明:
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspOptCellInfoCfg(UINT32 cellId)
{
	UINT32 ret = BSP_OK;

    BspLog(LOG_LEVEL_0,"%s enter,cellId=%d\n", __FUNCTION__, cellId);
    /*rru有小区劈裂，cellid是通过载波号 制式 小区号移位拼接成，值很大无法*/
    (VOID)BspChangeFrRule();/*4.2上还需要此接口psync帧头偏移方向配置　刘建开确认*/
    (VOID)BspSetRadioStandardToHal();
    ret = BspHalAdaptOptCellCfg(cellId);

    BspLog(LOG_LEVEL_0,"%s exit,cellId=%d ret=%d\n", __FUNCTION__, cellId, ret);

    return ret;
}

/**************************************************************************
* 函数名称: BspOptCellInfoDelte()
* 功能描述: 光口小区配置删除
* 输入参数: cellId: 小区id
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明:
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspOptCellInfoDelte(UINT32 cellId)
{
	UINT32 ret = BSP_OK;

    BspLog(LOG_LEVEL_0,"%s enter,cellId=%d\n", __FUNCTION__, cellId);
    /*rru有小区劈裂，cellid是通过载波号 制式 小区号移位拼接成，值很大无法*/
    ret = BspHalAdaptOptCellDelte(cellId);
    if(pDelteCarrCloseAac != NULL)
    {
        pDelteCarrCloseAac(0);/* 临时增加规避流程 */
    }

    BspLog(LOG_LEVEL_0,"%s exit,cellId=%d ret=%d\n", __FUNCTION__, cellId, ret);

    return ret;
}

/**************************************************************************
* 函数名称: BspOptCellInfoCfg()
* 功能描述: 当前整机配置的光口速率，用于AXC配置时计算算AXC使用
* 输入参数: ulOpt: 逻辑光口号
           ulCpriRate:速率
           ulLineRate/ulSpd: BSP_OPT_SPEED_1P2288G          ((UINT32)0x0001)
                         BSP_OPT_SPEED_2P4576G          ((UINT32)0x0002)
                         BSP_OPT_SPEED_3P0720G          ((UINT32)0x0003)
                         BSP_OPT_SPEED_4P9152G          ((UINT32)0x0004)
                         BSP_OPT_SPEED_6P1440G          ((UINT32)0x0006)
                         BSP_OPT_SPEED_7P3728G          ((UINT32)0x0007)
                         BSP_OPT_SPEED_8P11008G         ((UINT32)0x0008)
                         BSP_OPT_SPEED_9P8304G          ((UINT32)0x000a)
                         BSP_OPT_SPEED_10P1376G         ((UINT32)0x000b)
                         BSP_OPT_SPEED_12P16512G        ((UINT32)0x000c)
                         BSP_OPT_SPEED_24P33024G        ((UINT32)0x0019)
                         BSP_OPT_SPEED_25P06752G        ((UINT32)0x001a)
                         BSP_OPT_SPEED_48P66048G        ((UINT32)0x0030)
                         BSP_OPT_SPEED_50P13504G        ((UINT32)0x0032)
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: 解决底层建链配置速率是配AXC不同步的问题
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspSaveOptSpeedFromApp(UINT32 ulOpt, UINT32 ulCpriRate) /*需要向高层确认入参的含义 3.0有传4*/
{
    UINT32 ulPhyPort = 0;
    UINT32 ret = BSP_OK;

    BspLog(LOG_LEVEL_0,"%s enter,ulOpt=%d,ulCpriRate=%d\n", __FUNCTION__,ulOpt,ulCpriRate);
    ulPhyPort = BspGetPhyNoBySfpNo(ulOpt);  /*从目前现象看 是光笼子的编号*/
    if(ulPhyPort >= OPTMAXNUM)
    {
        dbgErr("%s>>ulLogicOpt is error. Opt[%d] Speed!\n",__FUNCTION__,ulPhyPort);
        return BSP_ERROR;
    }
    g_ulBspLoadOptSpeed[ulPhyPort] = ulCpriRate;
    dbgInfo("BspSaveOptSpeedFromApp phyOpt = %d logicOpt = %d optSpeed = %d\n",ulPhyPort,ulOpt,ulCpriRate);
    ret = BspHalAdaptSetCpriLineRate(ulPhyPort,ulCpriRate);
    #ifndef _SH_TF_20KM_T12_
    (VOID)BspHalAdaptUpdateFrCfg();
    #endif
    BspLog(LOG_LEVEL_0,"%s@%d>cfg Line Rate & FrCfg\n",__func__, __LINE__);
    return ret;
}
/*获取高层下发的上下联光口的光口速率 异速率级联需要使用*/
UINT32 BspLoadOptSpeedFromApp(UINT32 ulPhyPort)
{
    if(ulPhyPort >= OPTMAXNUM)
    {
        dbgErr("%s>>ulLogicOpt is error. Opt[%d] Speed!\n",__FUNCTION__,ulPhyPort);
        return BSP_ERROR;
    }
    return g_ulBspLoadOptSpeed[ulPhyPort] ;
}

/**************************************************************************
* 函数名称: BspOptIqInfoSave()
* 功能描述: funclib 保存高层下发的iq配置
* 输入参数: uCfgNum: iq条数　pPara: iQ配置信息
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明:
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspOptIqInfoSave(UINT32 uCfgNum, T_IQRecord_BSP *pCellInfo)
{
    INPUT_POINTER_CHECK(pCellInfo);
    if(uCfgNum >= MAX_IQ_RECORD_MAX_NUM)
    {
        dbgErr("[%s] IQNum'%d is over!",__FUNCTION__,uCfgNum);
        return BSP_ERROR;
    }
    (void)memset_s(g_IqRecordBspBackup.tIqRecord, MAX_IQ_RECORD_MAX_NUM*sizeof(T_IQRecord_BSP), 0, MAX_IQ_RECORD_MAX_NUM*sizeof(T_IQRecord_BSP));
    memcpy_s(g_IqRecordBspBackup.tIqRecord,uCfgNum*sizeof(T_IQRecord_BSP),pCellInfo,uCfgNum*sizeof(T_IQRecord_BSP));
    g_IqRecordBspBackup.ulCfgNum = uCfgNum;
    return BSP_OK;
}

UINT32 BspOptRachIqInfoSave(UINT32 uCfgNum, T_IQRecord_BSP *pCellInfo)
{
    INPUT_POINTER_CHECK(pCellInfo);
    if(uCfgNum >= MAX_IQ_RECORD_MAX_NUM)
    {
        dbgErr("[%s] IQNum'%d is over!",__FUNCTION__,uCfgNum);
        return BSP_ERROR;
    }
    (void)memset_s(g_RachIqRecordBspBackup.tIqRecord, MAX_IQ_RECORD_MAX_NUM*sizeof(T_IQRecord_BSP), 0, MAX_IQ_RECORD_MAX_NUM*sizeof(T_IQRecord_BSP));
    memcpy_s(g_RachIqRecordBspBackup.tIqRecord,uCfgNum*sizeof(T_IQRecord_BSP),pCellInfo,uCfgNum*sizeof(T_IQRecord_BSP));
    g_RachIqRecordBspBackup.ulCfgNum = uCfgNum;
    return BSP_OK;
}

UINT32 BspOptSlaveIqInfoSave(UINT32 uCfgNum, T_IQRecord_Slave *pIqRecord)
{
    INPUT_POINTER_CHECK(pIqRecord);
    if(uCfgNum >= MAX_IQ_RECORD_MAX_NUM)  /*芯片最大能力是48载波 48*2*/
    {
        dbgErr("[%s] IQNum'%d is over!\n",__FUNCTION__,uCfgNum);
        free(g_pTmpIqRecord);
        g_pTmpIqRecord = NULL;
        return BSP_ERROR;
    }
    if(g_pTmpIqRecord == NULL)
    {
        g_pTmpIqRecord = (T_IQRecord_Slave*)malloc(sizeof(T_IQRecord_Slave)*MAX_IQ_RECORD_MAX_NUM);
    }
    if(g_pTmpIqRecord == NULL)
    {
        dbgErr("[%s] pTmpIqRecord malloc failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    (void)memset_s(g_pTmpIqRecord, MAX_IQ_RECORD_MAX_NUM*sizeof(T_IQRecord_Slave), 0, MAX_IQ_RECORD_MAX_NUM*sizeof(T_IQRecord_Slave));
    g_SalveIqRecordBspBackup.tIqRecord = g_pTmpIqRecord;
    memcpy_s(g_SalveIqRecordBspBackup.tIqRecord,uCfgNum*sizeof(T_IQRecord_Slave),pIqRecord,uCfgNum*sizeof(T_IQRecord_Slave));
    g_SalveIqRecordBspBackup.ulCfgNum = uCfgNum;
    return BSP_OK;
}

void PrnIqCfg(void)
{
    UINT32 ulItem = 0;
    dbgInfo("Total iq item=%d\n",g_IqRecordBspBackup.ulCfgNum);
    for(ulItem=0;ulItem< g_IqRecordBspBackup.ulCfgNum;ulItem++)
    {
       dbgInfo("Item %d [fiberNo %d, dir %d, carrMode 0x%x, antNo %d, carrNo %d, axcStartNo %d, axcNum %d, chipInfo %d, adddelFlag %d]\n",
              ulItem,
			  g_IqRecordBspBackup.tIqRecord[ulItem].fiberNo,
			  g_IqRecordBspBackup.tIqRecord[ulItem].dir,
			  g_IqRecordBspBackup.tIqRecord[ulItem].carrMode,
			  g_IqRecordBspBackup.tIqRecord[ulItem].antNo,
			  g_IqRecordBspBackup.tIqRecord[ulItem].carrNo,
			  g_IqRecordBspBackup.tIqRecord[ulItem].axcStartNo,
			  g_IqRecordBspBackup.tIqRecord[ulItem].axcNum,
			  g_IqRecordBspBackup.tIqRecord[ulItem].chipInfo,
			  g_IqRecordBspBackup.tIqRecord[ulItem].adddelFlag
             );
    }
}

void PrnRachIqCfg(void)
{
    UINT32 ulItem = 0;
    dbgInfo("Total iq item=%d\n",g_RachIqRecordBspBackup.ulCfgNum);
    for(ulItem=0;ulItem< g_RachIqRecordBspBackup.ulCfgNum;ulItem++)
    {
       dbgInfo("Item %d [fiberNo %d, dir %d, carrMode 0x%x, antNo %d, carrNo %d, axcStartNo %d, axcNum %d, chipInfo %d, adddelFlag %d]\n",
        ulItem,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].fiberNo,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].dir,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].carrMode,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].antNo,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].carrNo,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].axcStartNo,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].axcNum,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].chipInfo,
        g_RachIqRecordBspBackup.tIqRecord[ulItem].adddelFlag );
    }
}

void PrnSlaveIqCfg(void)
{
    UINT32 ulItem = 0;
    dbgInfo("Total iq item=%d\n",g_SalveIqRecordBspBackup.ulCfgNum);
    for(ulItem=0;ulItem< g_SalveIqRecordBspBackup.ulCfgNum;ulItem++)
    {
       dbgInfo("Item %d [ruRackNo %d, dir %d, carrMode %d, antNo 0x%x, carrNo %d, srcFiberNo %d, srcAxcStartNo %d, axcNum %d, "
              "srcchipInfo %d, destFiberNo %d  destAxcStartNo %d destchipInfo %d adddelFlag %d]\n",
              ulItem,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].ruRackNo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].dir,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].carrMode,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].antNo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].carrNo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].srcFiberNo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].srcAxcStartNo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].axcNum,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].srcchipInfo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].destFiberNo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].destAxcStartNo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].destchipInfo,
              g_SalveIqRecordBspBackup.tIqRecord[ulItem].adddelFlag
             );
    }
}

/**************************************************************************
* 函数名称: BspIqCfgInit()
* 功能描述: IQ配置初始化
* 输入参数: 无
* 输出参数:　无
* 返 回 值   : BSP_Ok
* 其它说明:  IC4.２要支持增量，hal不能直接清除IQ的资源和存储信息
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2021年5月11日 10258234         创建
**************************************************************************/
UINT32 BspIqCfgInit(VOID)
{
    return BSP_OK; /*刘健开确认，4.2上没有３.0资源初始化清除的动作*/
}

/* iq 中光口号转换给光口需要的光口号*/
UINT32 BspOptIqFiberNoConvert(UINT32 fiberNo)
{
    UINT32 workMode = 0;
    UINT32 iqOptNo = 0;
    UINT32 phyOpt = 0;

    if((RRU_PB_BBU == BspGetPbOrBbuMode())||(RRU_BBU == BspGetPbOrBbuMode()))
    {
        return fiberNo;   /*qcell 不做处理*/
    }
    if (fiberNo >= OPTMAXNUM)
    {
        dbgErr("fiberNo is inVaild\n");
        return BSP_ERROR;
    }
    workMode = BspGetDefaultOptWorkMode(0);
    if(BSP_OPT_WORK_MODE_SHARE == workMode)
    {
        iqOptNo = fiberNo;    /*负荷分担正式版透传光口号即可*/
    }
    else
    {
        iqOptNo = 0;   /*其他组网都是0*/
        if(SUPPORT_DOUBLE_BBU_MAIN_SLAVE == BspGetSupportDoubleBBUMainSlaveFlag())
        {
            phyOpt = BspGetPhyNoBySfpNo(fiberNo);
            iqOptNo = BspGetLogicPort(phyOpt);
            BspLog(LOG_LEVEL_0,"%s, fiberNo = %d, iqNo = %d",__FUNCTION__, fiberNo, iqOptNo);
        }
    }

    return iqOptNo;
}
/**************************************************************************
* 函数名称: BspOptIqInfoCfg()
* 功能描述: IQ配置信息存储(后续正式改的时候BspOptIqInfoCfg(UINT32 uCfgNum, T_IQRecord_TDD *pPara)
* 输入参数: uCfgNum: iq条数　pPara: iQ配置信息
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: IC4.２要支持增量，T_IQRecord_BSP里包含IQ增删标志
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspOptIqInfoCfg(UINT32 uCfgNum, T_IQRecord_TDD *pPara)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    T_IQRecord_BSP *iqPara = NULL;

    INPUT_POINTER_CHECK(pPara);
    iqPara = (T_IQRecord_BSP*)malloc(uCfgNum*sizeof(T_IQRecord_BSP));
    if(NULL == iqPara)
    {
        dbgErr("%s iqPara malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(loop = 0; loop < uCfgNum; loop++)
    {
    	iqPara[loop].fiberNo =     BspOptIqFiberNoConvert(pPara[loop].fiberNo);
    	iqPara[loop].dir =         pPara[loop].dir;
    	iqPara[loop].carrMode =    pPara[loop].carrMode;
        if( (pPara[loop].carrMode == BSP_RADIO_STANDARD_UMTS) ||
            (pPara[loop].carrMode == BSP_RADIO_STANDARD_GSM)||
            (pPara[loop].carrMode == BSP_RADIO_STANDARD_NB_IOT) )
        {
            iqPara[loop].antNo = BIT_SET(pPara[loop].antNo);
        }
        else
        {
            iqPara[loop].antNo =   pPara[loop].antNo;
        }
    	iqPara[loop].carrNo =      pPara[loop].carrNo;
    	iqPara[loop].axcNum =      pPara[loop].axCNo;
    	iqPara[loop].axcStartNo =  pPara[loop].axCIndex;
    	iqPara[loop].chipInfo =    pPara[loop].chipInfo;
        #ifdef FUNCLIB_ADS
	    iqPara[loop].adddelFlag =    1;
        #else
        iqPara[loop].adddelFlag = pPara[loop].adddelFlag;
        #endif
        dbgInfo("[%s] fiberNo:%d dir:%d carrMode:%d antNo:%d carrNo:%d axcStartNo:%d axcNum:%d chipInfo:%d adddelFlag:%d\n",__FUNCTION__,
        iqPara[loop].fiberNo,iqPara[loop].dir,iqPara[loop].carrMode,iqPara[loop].antNo,iqPara[loop].carrNo,iqPara[loop].axcStartNo,
        iqPara[loop].axcNum,iqPara[loop].chipInfo,iqPara[loop].adddelFlag);
        BspLog(LOG_LEVEL_0, "[%s] fiberNo:%d dir:%d carrMode:%d antNo:%d carrNo:%d axcStartNo:%d axcNum:%d chipInfo:%d adddelFlag:%d\n",__FUNCTION__,
                iqPara[loop].fiberNo,iqPara[loop].dir,iqPara[loop].carrMode,iqPara[loop].antNo,iqPara[loop].carrNo,iqPara[loop].axcStartNo,
                iqPara[loop].axcNum,iqPara[loop].chipInfo,iqPara[loop].adddelFlag);
    }
	(void)BspOptIqInfoSave(uCfgNum,iqPara);         /*funclib保存一份配置*/
    ret = BspHalAdaptOptSwTblAssign(uCfgNum,iqPara);//先保存,光口小区配置时再配置IQ
    if(ret != BSP_OK)
    {
        dbgErr("[%s] ret'%d Opt IQ CFG FAIL!\n",__FUNCTION__,ret);
    }

    free(iqPara);

    return ret;
}

/**************************************************************************
* 函数名称: BspOptRachIqInfoCfg()
* 功能描述: 给光口下发Rach交叉表，软劈裂场景需要使用
* 输入参数: uCfgNum: iq条数　pPara: iQ配置信息
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: IC4.２要支持增量，T_IQRecord_BSP里包含IQ增删标志
* 修改日期         修改人            修改内容
**************************************************************************/
UINT32 BspOptRachIqInfoCfg(UINT32 uCfgNum, T_IQRecord_TDD *pPara)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    T_IQRecord_BSP *iqPara = NULL;

    INPUT_POINTER_CHECK(pPara);
    iqPara = (T_IQRecord_BSP*)malloc(uCfgNum*sizeof(T_IQRecord_BSP));
    if(NULL == iqPara)
    {
        dbgErr("%s iqPara malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(loop = 0; loop < uCfgNum; loop++)
    {
        iqPara[loop].fiberNo =  BspOptIqFiberNoConvert(pPara[loop].fiberNo);
        iqPara[loop].dir =      pPara[loop].dir;
        iqPara[loop].carrMode = pPara[loop].carrMode;
        if( (pPara[loop].carrMode == BSP_RADIO_STANDARD_UMTS) ||
            (pPara[loop].carrMode == BSP_RADIO_STANDARD_GSM) ||
            (pPara[loop].carrMode == BSP_RADIO_STANDARD_NB_IOT) )
        {
            iqPara[loop].antNo = BIT_SET(pPara[loop].antNo);
        }
        else
        {
            iqPara[loop].antNo =   pPara[loop].antNo;
        }
        iqPara[loop].carrNo =      pPara[loop].carrNo;
        iqPara[loop].axcNum =      pPara[loop].axCNo;
        iqPara[loop].axcStartNo =  pPara[loop].axCIndex;
        iqPara[loop].chipInfo =    pPara[loop].chipInfo;
        iqPara[loop].adddelFlag = pPara[loop].adddelFlag;
        dbgInfo("[%s] fiberNo:%d dir:%d carrMode:%d antNo:%d carrNo:%d axcStartNo:%d axcNum:%d chipInfo:%d adddelFlag:%d\n",__FUNCTION__,
        iqPara[loop].fiberNo,iqPara[loop].dir,iqPara[loop].carrMode,iqPara[loop].antNo,iqPara[loop].carrNo,iqPara[loop].axcStartNo,
        iqPara[loop].axcNum,iqPara[loop].chipInfo,iqPara[loop].adddelFlag);
    }

    (void)BspOptRachIqInfoSave(uCfgNum,iqPara); /*funclib保存一份配置*/
    ret = BspHalAdaptOptRachSwTblAssign(uCfgNum,iqPara);//先保存,光口小区配置时再配置IQ
    if(ret != BSP_OK)
    {
        dbgErr("[%s] ret'%d Opt IQ CFG FAIL!\n",__FUNCTION__,ret);
    }

    free(iqPara);

    return ret;
}

static UINT32 BspFpgaOptCfg(UINT32 uCfgNum, T_IQRecord_Slave *slaveiqPara)
{
    UINT32 retVal = BSP_OK;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    if (NULL != pFpgaInfo && NULL != pFpgaInfo->pFuncCfgFpgaAiotOptInfo)
    {
        retVal = pFpgaInfo->pFuncCfgFpgaAiotOptInfo(uCfgNum, slaveiqPara);
    }

    return retVal;
}

/*异速率级联 支链IQ下发  + 负荷分担组网多片机型 片间IQ下发*/
UINT32 BspOptIqSlaveCfg(UINT32 uCfgNum, T_IQRecord_Slave *pPara)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    T_IQRecord_Slave *slaveiqPara = NULL;
    UINT32 workMode = 0;

    INPUT_POINTER_CHECK(pPara);
    ret = BspOptSlaveIqInfoSave(uCfgNum, pPara);

    slaveiqPara = (T_IQRecord_Slave*)malloc(uCfgNum * sizeof(T_IQRecord_Slave));
    if(NULL == slaveiqPara)
    {
        dbgErr("%s slaveiqPara malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    (void)memset_s(slaveiqPara, uCfgNum * sizeof(T_IQRecord_Slave), 0, uCfgNum * sizeof(T_IQRecord_Slave));
    workMode = BspGetDefaultOptWorkMode(0);
    for(loop = 0; loop < uCfgNum; loop++)
    {
        slaveiqPara[loop].srcFiberNo     = 0; /* 支链IQ srcFiberNo 高层下发的是主光口号，单上联固定配成0 */
        if(RRU_PB_BBU == BspGetPbOrBbuMode())
        {
            slaveiqPara[loop].srcFiberNo = pPara[loop].srcFiberNo;
        }
        slaveiqPara[loop].ruRackNo       = pPara[loop].ruRackNo;
        slaveiqPara[loop].dir            = pPara[loop].dir;
        slaveiqPara[loop].carrMode       = pPara[loop].carrMode;
        slaveiqPara[loop].antNo          = pPara[loop].antNo;
        slaveiqPara[loop].carrNo         = pPara[loop].carrNo;
        slaveiqPara[loop].srcAxcStartNo  = pPara[loop].srcAxcStartNo;
        slaveiqPara[loop].axcNum         = pPara[loop].axcNum;
        slaveiqPara[loop].srcchipInfo    = pPara[loop].srcchipInfo;
        if(BSP_OPT_WORK_MODE_SHARE == workMode)     /*多片机型负荷分担下联用2个口  单片机型不存在配置配置片间IQ交叉表*/
        {
            slaveiqPara[loop].srcFiberNo     = pPara[loop].srcFiberNo;
            if(pPara[loop].srcFiberNo == 0)
            {
                slaveiqPara[loop].destFiberNo    = 3;
            }
            else
            {
                slaveiqPara[loop].destFiberNo    = 2;
            }
        }
        else
        {
            slaveiqPara[loop].destFiberNo    = 2;
        }
        slaveiqPara[loop].destAxcStartNo = pPara[loop].destAxcStartNo;
        slaveiqPara[loop].destchipInfo   = pPara[loop].destchipInfo;
        slaveiqPara[loop].adddelFlag     = pPara[loop].adddelFlag;
        dbgInfo("[%s] srcFiberNo:%d ruRackNo %d dir:%d carrMode:%d antNo:%d carrNo:%d srcAxcStartNo:%d axcNum:%d srcchipInfo:%d destFiberNo %d,destAxcStartNo %d destchipInfo %d, adddelFlag:%d\n",
        __FUNCTION__,pPara[loop].srcFiberNo,pPara[loop].ruRackNo,pPara[loop].dir,pPara[loop].carrMode,pPara[loop].antNo,pPara[loop].carrNo,pPara[loop].srcAxcStartNo,
            pPara[loop].axcNum,pPara[loop].srcchipInfo,pPara[loop].destFiberNo,pPara[loop].destAxcStartNo, pPara[loop].destchipInfo,pPara[loop].adddelFlag);
        BspLog(LOG_LEVEL_0, "[%s] srcFiberNo:%d ruRackNo %d dir:%d carrMode:%d antNo:%d carrNo:%d srcAxcStartNo:%d axcNum:%d srcchipInfo:%d destFiberNo %d,destAxcStartNo %d destchipInfo %d, adddelFlag:%d\n",
                __FUNCTION__,pPara[loop].srcFiberNo,pPara[loop].ruRackNo,pPara[loop].dir,pPara[loop].carrMode,pPara[loop].antNo,pPara[loop].carrNo,pPara[loop].srcAxcStartNo,
                pPara[loop].axcNum,pPara[loop].srcchipInfo,pPara[loop].destFiberNo,pPara[loop].destAxcStartNo, pPara[loop].destchipInfo,pPara[loop].adddelFlag);

    }
    (void)BspFpgaOptCfg(uCfgNum, slaveiqPara);//FPGA配置，d42无需关注
    BspHalAdaptOptCrsSwTblCfg(uCfgNum, slaveiqPara);

    free(slaveiqPara);
    slaveiqPara = NULL;

    return ret;
}

/**************************************************************************
* 函数名称: BspGetOptStatus()
* 功能描述: cpri光口告警状态上报，app调用
* 输入参数: optId: 逻辑光口号
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: 参照3.0　由于不同机型光口结构可能有差异，所以在此增加了回调
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspGetOptStatus(UINT32 optId)
{
	UINT32 ulRet  = BSP_OK;
	UINT32 optSta = 0;
	UINT32 ioSta = 0;
	UINT32 phyOptNo = 0;
	UINT32 maxSfpNum = 2;

    if(IS_NCR == BspIsNcr())
    {
        return BSP_OK;
    }

	if(optId >= maxSfpNum)
	{
		return BSP_ERROR;
	}
	ioSta = BspRegPinRd(REG_BB_FPGA_OPT0_TX_FAULT_ALM + optId);  //2531  光模块，电模块都可以检测到
	if(ioSta == 1)
	{
	    optSta |= BSP_OPT_ERR_TX_FAULT;
	}
	ioSta = BspRegPinRd(REG_BB_FPGA_SFP0_NO_EXIST_ALM + optId);  //2531  光模块，电模块都可以检测到
	if(ioSta == 1)
	{
	    optSta |= BSP_OPT_ERR_NO_EXIST;
	}

/*otdr光模块 虚不在位 认为不在位*/
#ifndef MULT_PROGRESS_S
    if(0 != BspGetOptVirtualAbsentConf(optId) )
    {
        optSta |= BSP_OPT_ERR_NO_EXIST;
    }
#endif

	phyOptNo = BspGetPhyNoBySfpNo(optId);
	if(phyOptNo == BSP_ERROR)
	{
		return BSP_OPT_ERR_OTHER;
	}
	ulRet = BspHalAdaptGetOptLopStatus(phyOptNo);
	if(ulRet != BSP_OK)
	{
	    optSta |= BSP_OPT_ERR_LOP;
	}
	ulRet = BspHalAdaptGetOptLosStatus(phyOptNo);
	if(ulRet != BSP_OK)
	{
	    optSta |= BSP_CPRI_ERR_LOS;
	}
	ulRet |= BspHalAdaptGetOptLofStatus(phyOptNo);
	if(ulRet != BSP_OK)
	{
	    optSta |= BSP_OPT_ERR_LOF;
	}
    return optSta;
}

/**************************************************************************
* 函数名称: BspGetOptStatusForOptAdpt()
* 功能描述: cpri光口告警状态上报，光口自适应调用
* 输入参数: optId: 逻辑光口号
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: 参照3.0　由于不同机型光口结构可能有差异，所以在此增加了回调
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspGetOptStatusForOptAdpt(UINT32 optId)
{
    UINT32 ulRet  = BSP_OK;
    UINT32 optSta = 0;
    UINT32 ioSta = 0;
    UINT32 phyOptNo = 0;
    UINT32 maxSfpNum = 2;

    if(optId >= maxSfpNum)
    {
        return BSP_ERROR;
    }

    ioSta = BspRegPinRd(REG_BB_FPGA_SFP0_NO_EXIST_ALM + optId);  //2531  光模块，电模块都可以检测到
    if(ioSta == 1)
    {
        optSta |= BSP_OPT_ERR_NO_EXIST;
    }

    /*otdr光模块 虚不在位 认为不在位*/
#ifndef MULT_PROGRESS_S
    if(0 != BspGetOptVirtualAbsentConf(optId) )
    {
        optSta |= BSP_OPT_ERR_NO_EXIST;
    }
#endif

    phyOptNo = BspGetPhyNoBySfpNo(optId);
    if(phyOptNo == BSP_ERROR)
    {
        return BSP_OPT_ERR_OTHER;
    }
    ulRet = BspHalAdaptGetOptLopStatus(phyOptNo);
    if(ulRet != BSP_OK)
    {
        optSta |= (BSP_OPT_ERR_LOP | BSP_OPT_ERR_LOS);
    }
    ulRet = BspHalAdaptGetOptLosStatus(phyOptNo);
    if(ulRet != BSP_OK)
    {
        optSta |= BSP_CPRI_ERR_LOS;
    }
    ulRet |= BspHalAdaptGetOptLofStatus(phyOptNo);
    if(ulRet != BSP_OK)
    {
        optSta |= BSP_OPT_ERR_LOF;
    }
    return optSta;
}

UINT32 BspGetSfpStatus(UINT32 sfpId)
{
    return  BspGetOptStatus(sfpId);
}
VOID BspGetOptStatusCallBack(FUNC_GET_OPT_STATUS pFunc)
{
    s_pBspGetOptStatus = pFunc;
}

/**************************************************************************
* 函数名称: BspGetCurrentFiberPort()
* 功能描述: 主光口获取上报　app调用
* 输入参数: 无
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: 参照3.0　由于不同机型光口结构可能有差异，所以在此增加了回调
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2022年1月29日          创建
**************************************************************************/
UINT32 BspGetCurrentFiberPort(VOID)
{
	return BspGetCurrFiberPort();
}

/**************************************************************************
* 函数名称: FDD BspGetLogicOptIdBySfpNo()
* 功能描述: 根据鼠笼号获取逻辑光口号　app调用
* 输入参数: 无
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: 参照3.0　由于不同机型光口结构可能有差异，所以在此增加了回调
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2024年5月13日          创建
**************************************************************************/
UINT32 BspGetLogicOptIdBySfpNo(UINT32 ulSfpNo, UINT32 *LogicOptId)
{
    UINT32 ulPhyNo = 0;

    INPUT_OPT_CHECK(ulSfpNo);
    INPUT_POINTER_CHECK(LogicOptId);

    ulPhyNo = BspGetPhyNoBySfpNo(ulSfpNo);
    *LogicOptId = BspGetLogicPort(ulPhyNo);

    return BSP_OK;
}

/**************************************************************************
* 函数名称: TDD BspGetOptDirectByRingOptId_Cpri()
* 功能描述: FDD 通过光笼号获取对应的正反向　app调用
* 输入参数: 无
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明:
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2024年5月13日          创建
**************************************************************************/
UINT32 BspGetOptDirectByRingOptId_Cpri(UINT32 sfpNo, UINT32 *optDirect)
{
    UINT32 regVal = 0;
    UINT32 phyNo = 0;
    UINT32 retVal =BSP_ERROR;

    phyNo = BspGetPhyNoBySfpNo(sfpNo);
    if(BSP_ERROR == phyNo)   /*单板参数不错这里不会错*/
   {
       return BSP_ERROR;
   }
    regVal = BspHalAdaptGetFddPriority(phyNo);

    if((regVal == 0x38)||(regVal == 0x7c))   /*FDD非环网 只有0x38 只有正向*/
    {
         *optDirect = 0;   /*正向*/
          retVal = BSP_OK;
    }
    if((regVal == 0x83)||(regVal == 0xc7))
    {
         *optDirect = 1;   /*反向*/
         retVal = BSP_OK;
    }
    dbgInfoEx("%s sfpNo %d phyNo %d regVal %d *optDirect %d\n", __FUNCTION__, sfpNo, phyNo, regVal, *optDirect);

    return retVal;     /*此口没接光纤或者断链 控制字会是0xff*/
}

/**************************************************************************
* 函数名称: TDD BspGetLogicOptIdByGlobalOptID_IR()
* 功能描述: 根据BBU全局光口号查找对应的逻辑光口号　app调用
* 输入参数: 无
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明: 参照3.0　由于不同机型光口结构可能有差异，所以在此增加了回调
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2024年5月13日          创建
**************************************************************************/
UINT32 BspGetLogicOptIdByGlobalOptID_IR(UINT32 bbuPortNo, UINT32 *logicOptID)
{
    UINT32 loop = 0;
    UINT32 bbuPort = 0;
    UINT32 phyNo = 0;

    phyNo = BspGetMainPhyOpt();
    if(BSP_ERROR == phyNo)
    {
         return BSP_ERROR;  /*主光口识别异常 表示断链*/
    }
    for(loop = 0; loop < OPTMAXNUM; loop++)
    {
         bbuPort = BspGetBbuFiberPort(loop);
         if(bbuPortNo == bbuPort)
         {
              phyNo = BspGetPhyNoBySfpNo(loop);
              if(BSP_ERROR == phyNo)   /*单板参数不错这里不会错*/
              {
                  return BSP_ERROR;
              }
              *logicOptID = BspGetLogicPort(phyNo);
              dbgInfoEx("%s sfpNo %d phyNo %d bbuPort %d *logicOptID %d\n", __FUNCTION__, loop, phyNo, bbuPort, *logicOptID);
              return BSP_OK;
         }
    }

    return BSP_ERROR;
}
/**************************************************************************
* 函数名称: BspSetOptSpeedPara()
* 功能描述: APP配置光口速率参数等
* 输入参数: pBbuOptPara 光口速率参数
* 输出参数:　无
* 返 回 值: BSP_Ok
* 其它说明:
* 修改日期         修改人            修改内容
* ------------------------------------------------------------------------
* 2024年5月13日          创建
**************************************************************************/
UINT32 BspSetOptSpeedPara(T_BbuOptInfo *pBbuOptPara)
{
    INPUT_POINTER_CHECK(pBbuOptPara);

    BspLog(LOG_LEVEL_0,"%s, enter\n",  __FUNCTION__);
    return IcHalApiSetBbuOptPara(pBbuOptPara);
}

/* 上行联合采数-开始采数 */
UINT32 BspUpSmpL2dStart(UINT32 uCellId, UINT32 uDirRev,UINT32 uAnt, UINT32 uDifOrGfTmp, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum)
{
    return BspHalAdaptUpCombSmpDataL2dStart(uCellId,uDirRev,uAnt,uDifOrGfTmp,uSlot,uStartSym,uSymbNum);
}
/* 上行联合采数-保存数据 */
UINT32 BspUpCombSmpL2dDataSave(UINT32 uCellId,UINT32 uDifOrGfTmp)
{
    return BspHalAdaptUpCombSmpDataL2dSave(uCellId,uDifOrGfTmp);
}

  /**************************************************************************
  * 函数名称: BspGetChipId()
  * 功能描述: 获取芯片ID和DIE ID
  * 输入参数: 无
  * 输出参数: *pChipIdx:芯片ID
  *          *pDieIdx:DIE ID
  * 返 回 值   : BSP_Ok
  * 其它说明:  IC4.0暂时返回空接口，后续实现
  * 修改日期         修改人            修改内容
  * ------------------------------------------------------------------------
  * 2021年5月11日 10258234         创建
  **************************************************************************/
UINT32 BspGetChipId(UINT32 *pChipIdx,UINT32 *pDieIdx)
{
    return BSP_OK;
}

UINT32 BspFftWinSet(UINT32 uCellId,UINT32 uWinMode,UINT32 uTblIndex)
{
    UINT32 uRet = BSP_ERROR;
    dbgInfoEx("[%s] cellId is %d,Fft win mode is %d,tbl%d\n", __FUNCTION__, uCellId,uWinMode,uTblIndex);

    uRet = IcHalFftWinSet( uCellId, uWinMode, uTblIndex);

    return uRet;
}

UINT32 BspTwoFrePrachGetRbNum(UINT32 uPrachConfigIndex,UINT32 uScs,UINT32 uPrachScs)
{
    UINT32 retVal = BSP_OK;

     retVal = BspHalApiTwoFrePrachGetRbNum(uPrachConfigIndex, uScs,uPrachScs);
     return retVal;
}

UINT32 BspSetRachModeFlag(UINT32 uCellIndex,UINT32 uFlag)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalApiSetRachModeFlag(uCellIndex, uFlag);
    return retVal;
}
/*高层下发高层获取的主光口对应的光笼子编号 BspGetRruMSOptID*/
UINT32 BspSetMainOptFromApp(UINT32 mainOpt)
{
    UINT32 phyNo = 0;
    
    g_ulMainPhyOptFromApp = mainOpt;
    BspLog(LOG_LEVEL_0,"%s, mainOpt %d\n",__FUNCTION__,mainOpt);
    phyNo = BspGetPhyNoBySfpNo(mainOpt);
    if(phyNo == BSP_ERROR)
    {
        return BSP_ERROR;
    }
    BspHalAdaptSetMainPhyOpt(phyNo, mainOpt);
    return BSP_OK;
}
/*回传高层下发的主光口号对应的光笼子号*/
UINT32 BspGetMainOptFromApp(VOID)
{
     return g_ulMainPhyOptFromApp;
}

UINT32 BspSetSleepCellMasterPort(UINT32 mainOpt)
{
    BspHalAdaptSetSleepCellMasterPort(mainOpt);
    return BSP_OK;
}

UINT32 BspUlSleepCellCheck(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode)
{
    return BspHalAdaptUlSleepCellCheck(uiDifChan, uiCarrId, uiRadioMode);
}

UINT32 BspDlSleepCellCheck(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode)
{
    return BspHalAdaptDlSleepCellCheck(uiDifChan, uiCarrId, uiRadioMode);
}

/* Started by AICoder, pid:w12a86c4fby2c8514ac4088be16efa8508620c66 */
UINT32 BspCheckBifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return BspHalAdaptCheckBifCarrDly(pDlyCfgInfo);
}

UINT32 BspCheckGfCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return BspHalAdaptCheckGfCarrDly(pDlyCfgInfo);
}

UINT32 BspCheckDifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return BspHalAdaptCheckDifCarrDly(pDlyCfgInfo);
}

UINT32 BspCheckFftCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo)
{
    INPUT_POINTER_CHECK(pDlyCfgInfo);
    return BspHalAdaptCheckFftCarrDly(pDlyCfgInfo);
}

UINT32 BspTxSleepCellCheckGate(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return BspHalAdaptTxSleepCellCheckGate(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspRxSleepCellCheckGate(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return BspHalAdaptRxSleepCellCheckGate(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspTxSleepCellCheckNco(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return BspHalAdaptTxSleepCellCheckNco(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspRxSleepCellCheckNco(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return BspHalAdaptRxSleepCellCheckNco(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspTxSleepCellCheckBank(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return BspHalAdaptTxSleepCellCheckBank(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

UINT32 BspRxSleepCellCheckBank(UINT32 uiChanId, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiErrFlg)
{
    INPUT_POINTER_CHECK(puiErrFlg);
    return BspHalAdaptRxSleepCellCheckBank(uiChanId, uiCarrId, uiRadioMode, puiErrFlg);
}

/* Started by AICoder, pid:yc799vfb9fz1ae31408b0ad080544f5e8064e5d8 */
UINT32 ProcessTOffset(T_SleepCheckCarrDelay* carrDelay, T_OptDormantCellCfgInfo* outCellCfg, UINT32 workMode, INT32 chipTrandly_dl, INT32 chipTrandly_ul)
{
    UINT32 chipId = BspGetRpuId();
    UINT32 logNo = 0;

    INPUT_POINTER_CHECK(carrDelay);
    INPUT_POINTER_CHECK(outCellCfg);

    /* TF机型 FDD从片以及 TDD从片 toffset值不为0 */
    if (carrDelay->toffset[0] != 0 || carrDelay->toffset[1] != 0)
    {
        if (workMode == BSP_OPT_WORK_MODE_SHARE)
        {
            if (chipId == 0)
            {
                BspHalAdaptGetMainLogicOpt(&logNo);
                if (logNo < 2)
                {
                    outCellCfg->t12[0] = carrDelay->t12[logNo];
                    outCellCfg->t34[0] = carrDelay->t34[logNo];
                    outCellCfg->toffset[0] = carrDelay->toffset[logNo] - chipTrandly_dl - chipTrandly_ul;
                    outCellCfg->toffset[1] = carrDelay->toffset[(logNo == 0 ? 1 : 0)] - chipTrandly_dl - chipTrandly_ul;
                }
            }
            else
            {
                logNo = BspHalAdaptGetBaseDelayLogOpt();
                if (logNo < 2)
                {
                    outCellCfg->t12[0] = carrDelay->t12[logNo];
                    outCellCfg->t34[0] = carrDelay->t34[logNo];
                    outCellCfg->toffset[0] = carrDelay->toffset[logNo] - chipTrandly_dl - chipTrandly_ul;
                    outCellCfg->toffset[1] = carrDelay->toffset[logNo] - chipTrandly_dl - chipTrandly_ul;
                }
            }
        }
        else
        {
            outCellCfg->t12[0] = carrDelay->t12[0];
            outCellCfg->t34[0] = carrDelay->t34[0];
            outCellCfg->toffset[0] = carrDelay->toffset[0] - chipTrandly_dl - chipTrandly_ul;
        }
    }
    else
    {
        outCellCfg->t12[0] = carrDelay->t12[0];
        outCellCfg->t34[0] = carrDelay->t34[0];
        outCellCfg->t12[1] = carrDelay->t12[1];
        outCellCfg->t34[1] = carrDelay->t34[1];
        outCellCfg->toffset[0] = 537;
        outCellCfg->toffset[1] = 537;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:yc799vfb9fz1ae31408b0ad080544f5e8064e5d8 */

UINT32 BspInitOptDormantCellCfg(T_CellCfgInfo* cellCfg, T_SleepCheckCarrDelay* carrDelay, T_OptDormantCellCfgInfo* outCellCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 workMode = BspGetOptWorkMode(0);
    UINT32 halNetMode = 0;
    UINT32 chipTrandly_dl = 0;
    UINT32 chipTrandly_ul = 0;

    INPUT_POINTER_CHECK(cellCfg);
    INPUT_POINTER_CHECK(outCellCfg);
    INPUT_POINTER_CHECK(carrDelay);

    BspGetCurrChipTransmitDly(&chipTrandly_dl,&chipTrandly_ul);
    retVal = BspGetHalTopNetByBspTopNet(workMode,&halNetMode);
    outCellCfg->netMode = halNetMode;
    outCellCfg->cellId = cellCfg->cellIndex;
    outCellCfg->cellCarrNo = cellCfg->cellCarrNo;
    outCellCfg->cellRadioMode = cellCfg->cellAntRadioMode;
    outCellCfg->cellBw[RX] = cellCfg->cellBw[RX];
    outCellCfg->cellBw[TX] = cellCfg->cellBw[TX];

    /* 压缩模式转换  压缩模式转换规则待细化确认，需要高层下发代表压缩模式含义的值　　hal将这个值转换成写到具体寄存器值,具体规则待细化*/
    if((cellCfg->cellAntRadioMode == BSP_RADIO_STANDARD_LTE_TDD)&&(cellCfg->cellIFType == E_OPT_IF0))   /*lte 0代表15比特 1代表9比特  TDD NR的由高层转换*/
    {
        outCellCfg->cellCompressMode[TX] = BspConvertCompressModeToHal(cellCfg->cellIFType,cellCfg->cellDLDeCompressMode);
        outCellCfg->cellCompressMode[RX]   = BspConvertCompressModeToHal(cellCfg->cellIFType,cellCfg->cellULCompressMode);
    }
    /*FDD LTE NR BSP直接由BBU下发值转换为OptHal层值 */
    if((cellCfg->cellAntRadioMode==BSP_RADIO_STANDARD_FDD_5G)||(cellCfg->cellAntRadioMode == BSP_RADIO_STANDARD_LTE_FDD)||(cellCfg->cellAntRadioMode == BSP_RADIO_STANDARD_NB_IOT))
    {
        outCellCfg->cellCompressMode[TX] = BspGetFddCompressModeFromBbuToOptHal(cellCfg->cellDLDeCompressMode);
        outCellCfg->cellCompressMode[RX] = BspGetFddCompressModeFromBbuToOptHal(cellCfg->cellULCompressMode);
    }

    outCellCfg->cellAntMask[RX] = cellCfg->cellAntMask[RX];
    outCellCfg->cellAntMask[TX] = cellCfg->cellAntMask[TX];

    outCellCfg->cellSCSBitMap = cellCfg->cellSCSBitMap;
    outCellCfg->cellIFType = cellCfg->cellIFType;

    outCellCfg->cellLnetwkDlys[RX] = cellCfg->cellLnetwkDlys[RX];
    outCellCfg->cellLnetwkDlys[TX] = cellCfg->cellLnetwkDlys[TX];
    outCellCfg->cellTax = cellCfg->tax;
    if((cellCfg->cellAntRadioMode == BSP_RADIO_STANDARD_5G)&&(cellCfg->cellIFType == E_OPT_IF1))
    {
        outCellCfg->cellTax = cellCfg->tax-BspGetTa(); /*TDD if1 下发的是总提前量，要减去TA，才是tax*/
    }
    outCellCfg->cellRvsTax[TX] = cellCfg->rvsTax[TX];
    outCellCfg->cellRvsTax[RX] = cellCfg->rvsTax[RX];
    outCellCfg->bandFrmAdj = cellCfg->bandFrmAdj;
    //outCellCfg->FrTmVal = cellCfg->orginalCellIndex;

    outCellCfg->ta = carrDelay->ta;
    outCellCfg->rxTa = carrDelay->rxTa;
    outCellCfg->lnetwkDlys[RX] = carrDelay->lnetwkDlys[RX];
    outCellCfg->lnetwkDlys[TX] = carrDelay->lnetwkDlys[TX];
    outCellCfg->cellRamDlyFwd[RX] = carrDelay->carrDelay.dwPrmUPDelay;
    outCellCfg->cellRamDlyFwd[TX] = carrDelay->carrDelay.dwPrmDLDelay;
    outCellCfg->cellRamDlyRvs[RX] = carrDelay->carrDelay.dwSecUPDelay;
    outCellCfg->cellRamDlyRvs[TX] = carrDelay->carrDelay.dwSecDLDelay;
    outCellCfg->t2a = carrDelay->t2a;
    outCellCfg->ta3 = carrDelay->ta3;
    outCellCfg->chipTransDly[RX] = chipTrandly_ul;
    outCellCfg->chipTransDly[TX] = chipTrandly_dl;

    (void)ProcessTOffset(carrDelay, outCellCfg, workMode, chipTrandly_dl, chipTrandly_ul);

   return retVal;
}

UINT32 BspSleepCellCheckBifCarrDly(T_CellCfgInfo *pPara, T_SleepCheckCarrDelay* carrDelay)
{
    UINT32 retVal = BSP_OK;
    T_OptDormantCellCfgInfo outCellCfg = {0};

    INPUT_POINTER_CHECK(pPara);
    INPUT_POINTER_CHECK(carrDelay);

    retVal = BspInitOptDormantCellCfg(pPara, carrDelay, &outCellCfg);

    retVal |= BspCheckBifCarrDly(&outCellCfg);

    return retVal;
}

UINT32 BspSleepCellCheckGfCarrDly(T_CellCfgInfo *pPara, T_SleepCheckCarrDelay* carrDelay)
{
    UINT32 retVal = BSP_OK;
    T_OptDormantCellCfgInfo outCellCfg = {0};

    INPUT_POINTER_CHECK(pPara);
    INPUT_POINTER_CHECK(carrDelay);

    retVal = BspInitOptDormantCellCfg(pPara, carrDelay, &outCellCfg);

    retVal |= BspCheckGfCarrDly(&outCellCfg);

    return retVal;
}

UINT32 BspSleepCellCheckDifCarrDly(T_CellCfgInfo *pPara, T_SleepCheckCarrDelay* carrDelay)
{
    UINT32 retVal = BSP_OK;
    T_OptDormantCellCfgInfo outCellCfg = {0};

    INPUT_POINTER_CHECK(pPara);
    INPUT_POINTER_CHECK(carrDelay);

    retVal = BspInitOptDormantCellCfg(pPara, carrDelay, &outCellCfg);

    retVal |= BspCheckDifCarrDly(&outCellCfg);

    return retVal;
}

UINT32 BspSleepCellCheckFftCarrDly(T_CellCfgInfo *pPara, T_SleepCheckCarrDelay* carrDelay)
{
    UINT32 retVal = BSP_OK;
    T_OptDormantCellCfgInfo outCellCfg = {0};

    INPUT_POINTER_CHECK(pPara);
    INPUT_POINTER_CHECK(carrDelay);

    retVal = BspInitOptDormantCellCfg(pPara, carrDelay, &outCellCfg);

    retVal |= BspCheckFftCarrDly(&outCellCfg);

    return retVal;
}
/* Ended by AICoder, pid:w12a86c4fby2c8514ac4088be16efa8508620c66 */

/* Started by AICoder, pid:efd17f54f4f14c7ab94e9aa3ad6c6037 */
VOID BspGetAntNumByCellId(UINT32 cellId, UINT32 dir, UINT32 *antNum)
{
    UINT32 index = 0;
    UINT32 cellBufSize = 0;

    if((NULL == antNum) || (dir > 1))
    {
        return;
    }
    cellBufSize = sizeof(g_sOptCellInfo) / sizeof(g_sOptCellInfo[0]);
    for (index = 0; index < cellBufSize; index++)
    {
        if (g_sOptCellInfo[index] == NULL)
        {
            continue;
        }
        if (g_sOptCellInfo[index]->optCellInfo.cellIndex == cellId)
        {
            *antNum = g_sOptCellInfo[index]->optCellInfo.cellAntNum[dir];
            break;
        }
    }
}
/* Ended by AICoder, pid:efd17f54f4f14c7ab94e9aa3ad6c6037 */

UINT32 BspOptCheckAxc(UINT32 cellId, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    retVal = BspHalAdaptOptCheckAxc(cellId, radioMode);
    return retVal;
}

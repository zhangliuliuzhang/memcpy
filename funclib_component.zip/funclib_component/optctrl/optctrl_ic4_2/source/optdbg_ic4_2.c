/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : optadpt.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件提供了光口模块的调试接口
 * 注意事项 : 无
 * 作    者 :      创建
 * 创建日期 : 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人:  
 * 修改日戳: 
 * 变更说明: 创建文件，

 *----------------------------------------------------------------------------
 */
#if 0
#include "optdbg_ic4_2.h"
static UINT32 tstGetOptSample(UINT32 radioMode, UINT32 bandWidth)
{
    UINT32 ll = 0;
    for (ll = 0; ll < (sizeof(iqSampleTbl) / sizeof(iqSampleTbl[0])); ll++) {
        if (iqSampleTbl[ll].radioMode == radioMode && iqSampleTbl[ll].bandWidth == bandWidth) {
            return iqSampleTbl[ll].sample;;
        }
    }
    return 122880;
}

UINT32 tstBspInitCellCfgInfo(UINT32 cellId, UINT32 radioMode, UINT32 bw, UINT32 chanMask)
{
    UINT32 index = 0;
    T_CellCfgInfo cellCfgInfo = {0};

    cellCfgInfo.cellIndex = cellId;
    cellCfgInfo.cellAdFlag = 1; // 0: blank 1:cfg, 2: del, 3: tti
    cellCfgInfo.cellMcsId = 0;
    cellCfgInfo.cellLocalCarrNo = 0;
    cellCfgInfo.cellBw[0] = bw;
    cellCfgInfo.cellBw[1] = bw;
    cellCfgInfo.cellIFType = 1;
    cellCfgInfo.cellBearType = 1;    /* E_OPT_CPRI, E_OPT_ECPRI*/
    if(radioMode == BSP_RADIO_STANDARD_LTE_TDD)
    {
        cellCfgInfo.cellSCSBitMap = 1;
        cellCfgInfo.cellTTI = 0;
    }
    else
    {
        cellCfgInfo.cellSCSBitMap = 2;
        cellCfgInfo.cellTTI = 1;
    }
    cellCfgInfo.iqSampleRate = tstGetOptSample(radioMode, bw);

    cellCfgInfo.cellAntRadioMode = radioMode;
    cellCfgInfo.cellCarrNo = 0;
    cellCfgInfo.cellAntMask[0] = chanMask;
    cellCfgInfo.cellAntMask[1] = chanMask;
    cellCfgInfo.cellIQPkgOLEN[0] = 828;
    cellCfgInfo.cellIQPkgOLEN[1] = 828;
    cellCfgInfo.cellULCompressMode = 13; /* FFTA 8ALW 压缩  */
    cellCfgInfo.cellDLDeCompressMode = 13; /* FFTA 8ALW 压缩 */

    for(index = 0; index < 14; index++)
    {
        cellCfgInfo.cellTxSymbolBit[index] = 1;
        cellCfgInfo.cellRxSymbolBit[index] = 1;
    }
    cellCfgInfo.cellgScn = 0;
    cellCfgInfo.cellSsbValid = 0;
    cellCfgInfo.fftaCpType = 0;
    cellCfgInfo.cellCAMode = 0;
    cellCfgInfo.cellPrachDagcEn = 0;

    return BspOptCellInfoInit(&cellCfgInfo);
}

UINT32 tstBspInitPrachCfgInfo(UINT32 cellId, UINT32 radioMode, UINT32 bw, UINT32 chanMask)
{
    T_PrachCellInfo prachCellInfo = {0};

    prachCellInfo.cellIndex = cellId;
    prachCellInfo.prachPktOlen = 672;
    prachCellInfo.prachCommpress = 14;

    if(bw == 20000 && radioMode == BSP_RADIO_STANDARD_LTE_TDD)
    {
        prachCellInfo.prachConfigIndex = 0;
        prachCellInfo.prachFreqOffSet[0] = 0;
        prachCellInfo.prachSCSBitMap = 1;
        prachCellInfo.prachFreqNum = 1;
    }
    else
    {
        prachCellInfo.prachConfigIndex = 159;
        prachCellInfo.prachFreqOffSet[0] = 2;
        prachCellInfo.prachFreqOffSet[1] = 0;
        prachCellInfo.prachSCSBitMap = 3;
        prachCellInfo.prachFreqNum = 1;
    }
    prachCellInfo.prachAntMask = chanMask;

    return BspOptL1CellPrachInfoInit(1, &prachCellInfo);
}

UINT32 BspSetOptTddCfg(T_CarrTddIndCfg* tddCfg, UINT32 tddNum)
{
    return BspHalAdaptOptCfgTdd(tddCfg, tddNum);
}

UINT32 tstBspSetOptTddCfg()
{
	T_CarrTddIndCfg tddCfgArr[2] = {0};
	tddCfgArr[0].uiTddCfgId = 0;
	tddCfgArr[1].uiTddCfgId = 1;
	tddCfgArr[0].uiCarrNo = 0;
	tddCfgArr[1].uiCarrNo = 0;
	tddCfgArr[0].uiRadioMode = BSP_RADIO_STANDARD_5G;
	tddCfgArr[1].uiRadioMode = BSP_RADIO_STANDARD_LTE_TDD;
	tddCfgArr[0].uiChanMask = 0xffffffff;
	tddCfgArr[1].uiChanMask = 0xffffffff;
	tddCfgArr[0].uiDlUlSwNum = 1;
	tddCfgArr[1].uiDlUlSwNum = 2;
	tddCfgArr[0].uiDlUlSwPeriod[0] = 5000;
	tddCfgArr[1].uiDlUlSwPeriod[0] = 3000;
	tddCfgArr[1].uiDlUlSwPeriod[1] = 2000;
	tddCfgArr[0].uiDlSymbolNum[0] = 104;
	tddCfgArr[1].uiDlSymbolNum[0] = 24;
	tddCfgArr[0].uiUlSymbolNum[0] = 32;
	tddCfgArr[1].uiUlSymbolNum[0] = 16;
	tddCfgArr[1].uiDlSymbolNum[1] = 28;
	tddCfgArr[1].uiUlSymbolNum[1] = 0;

	return BspSetOptTddCfg(tddCfgArr, sizeof(tddCfgArr)/sizeof(tddCfgArr[0]));
}


void tstBspOptCellNew(UINT32 cellId)
{
    if (tstBspInitCellCfgInfo(cellId, BSP_RADIO_STANDARD_5G, 100000, 0x1) != BSP_OK) {
        dbgErr("Init Cell Config error\n");
        return ;
    }

    if (tstBspInitPrachCfgInfo(cellId, BSP_RADIO_STANDARD_5G, 100000, 0x1) != BSP_OK) {
        dbgErr("Init Prach Cell Config error\n");
        return ;
    }

    if (tstBspSetOptTddCfg() != BSP_OK) {
        dbgErr("Set Tdd Config error\n");
        return ;
    }
	if (BspOptCellInfoCfg(cellId) != BSP_OK) {
        dbgErr("config cell infomation error\n");
        return ;
    }
}

VOID tstBspL2ssLoopBackEn(UINT32 enable)
{
    NtlXmacDisable(8);
    if(0 == enable)
	{
		L2ssTrxpCfgLoopBack(0,0);
	}
	else
	{
		L2ssTrxpCfgLoopBack(0,5);
		L2ssTrxpCfgLoopBack(0,8);
	}
    NtlXmacEnable(8);
}
#endif

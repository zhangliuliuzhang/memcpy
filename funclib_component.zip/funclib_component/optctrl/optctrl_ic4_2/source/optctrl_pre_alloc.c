#include "bsppub.h"
#include "bspcomm.h"
#include "optctrlapi.h"
#include <stdio.h>
#include "optctrl_pre_alloc.h"
#include "dyn_mem_alloc.h"
#include "secure_func.h"
#include "ichaladapt_ic4_2.h"
#include "freqcfgcommon.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "freqcfg_ic4_2.h"

#define PRE_ALLOC_MAX_CARR_NUM  64      /*最大预制64载波*/

#define RADIO_MODE_LTE (RADIO_STANDARD_LTE_FDD | RADIO_STANDARD_LTE_TDD)
#define IsLteMode(radioMode) ((radioMode) & RADIO_MODE_LTE)

#define NEED_CFG_STATUS (1)
#define NO_NEED_CFG_STATUS (0)
#define IF(x) if(x)
/* 使用场景预置功能开关 */
static UINT32 g_aUsePreAllocFlg = 0;
/* 当前预置场景信息 */
static T_BspHalAdaptPreAllocCarrInfo* gs_curPreAllocInfo = NULL;
static T_BspHalAdaptPreAllocCarrInfo* gs_boardPreAllocInfo = NULL;
static UINT32 gs_rruTypeInfo = 0;

/* 调试打印开关 */
static UINT32 s_preallocdbgPrnSw = 0;

/* 维测用，版本稳定后可删除 */
static T_DestCarrInfoAllChans *s_dbgPreAllocInfo = NULL;
static T_PreAllocResult s_dbgPreAllocResult = {0};
static UINT32 saveAppPreAllocInfo(T_DestCarrInfoAllChans *info);
static UINT32 saveAppPreAllocResult(T_PreAllocResult *result);
VOID DbgRecordPreAllocInfo(UINT32 preCfgRet);
VOID PrnChanGroupCellCarrInfo(T_BspHalAdaptAllCellCarrInfo *pInfo);
VOID DbgRecordAppCarrInfo(T_DestCarrInfoAllChans* cfgInfo);
VOID DbgRecordPreAllocResult(T_PreAllocResult* preAllocResult);

/* 载波映射结果 */
static T_AllChanCarrMapInfo gs_currAllCarrMapInfo = {0}; /* 保存上一次生效的载波映射信息，方便问题定位调试 */
static T_AllChanCarrMapInfo gs_lastAllCarrMapInfo = {0}; /* 保存当前已生效的载波映射信息 */
static T_AllChanCarrMapInfo gs_AllCarrMapInfo = {0};     /* 保存APP下发配置，计算的载波映射信息结果，暂时不会生效，等APP激活 */
static BOOL g_isSuccessPreAlloc = FALSE;                 /* 是否成功做过预分析 */

/* 该机型支持几个频段，频段对应的天线通道掩码信息，上电后，board进行初始化 RRU最多8T 这里使用bit8-9 表征TDD FDD T+F机型  */
static T_ChanMaskInfo  gs_chanMaskInfo = {
    .txChanMaskNum = 1,
    .txChanMaskInfo[0] = 0xff,
    .rxChanMaskNum = 1,
    .rxChanMaskInfo[0] = 0xff
};

UINT32 BspSetPreAllocBandInfo(T_ChanMaskInfo* bandInfo)
{
    INPUT_POINTER_CHECK(bandInfo);
    (void)memcpy_s(&gs_chanMaskInfo, sizeof(T_ChanMaskInfo), bandInfo, sizeof(T_ChanMaskInfo));
    return BSP_OK;
}

UINT32 BspGetPreAllocBandInfo(T_ChanMaskInfo* bandInfo)
{
    INPUT_POINTER_CHECK(bandInfo);
    (void)memcpy_s(bandInfo, sizeof(T_ChanMaskInfo), &gs_chanMaskInfo, sizeof(T_ChanMaskInfo));
    return BSP_OK;
}

UINT32 isOnlyNrOrLte(T_BspPreSenceAllocCarrInfo* preAllocBwInfo, UINT32 radioMode)
{
    UINT32 loop = 0;
    UINT32 tddNrNum = 0;
    UINT32 lteNum = 0;
    UINT32 fddNrNum = 0;
    UINT32 flag = 0;

    INPUT_POINTER_CHECK(preAllocBwInfo);
    for(loop = 0; loop < MAX_CARR_BAND_TYPE_NUM; loop++)
    {
        tddNrNum += preAllocBwInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[loop];
        fddNrNum+= preAllocBwInfo->carrInfo[FDDNR_CARR_TYPE].carrNum[loop];
        lteNum+= preAllocBwInfo->carrInfo[LTE_CARR_TYPE].carrNum[loop];   /*lte没区分带宽其实只有loop为0时有数*/
    }
    if(radioMode == BSP_RADIO_STANDARD_5G)
    {
        if((tddNrNum >0)&&( fddNrNum+lteNum == 0))
        {
            flag = 1;
        }
    }
   if(radioMode == BSP_RADIO_STANDARD_LTE_TDD)
    {
        if((lteNum >0)&&( fddNrNum+tddNrNum == 0))
        {
            flag = 1;
        }
    }

   return flag;
}
/*LV处于非del状态的载波中radioMode下小于bandwidth的载波个数*/
UINT32 getCarrNumLowThanBandWidth(T_BspPreSenceAllocCarrInfo* preAllocCfgInfo, UINT32 radioMode, UINT32 bandWidth)
{
    UINT32 carrCnt = 0;

    INPUT_POINTER_CHECK(preAllocCfgInfo);
    if(radioMode == BSP_RADIO_STANDARD_5G)
    {
        if(bandWidth == BANDWIDTH_100M)
        {
            carrCnt = preAllocCfgInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_0]+preAllocCfgInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_1]+preAllocCfgInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_2] ;
        }
        else if(bandWidth == BANDWIDTH_80M)
        {
            carrCnt = preAllocCfgInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_1]+preAllocCfgInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_2];
        }
        else
        {
            carrCnt = preAllocCfgInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_2];
        }
    }
    if(radioMode == BSP_RADIO_STANDARD_FDD_5G)
    {
        if(bandWidth == BANDWIDTH_60M)
        {
            carrCnt = preAllocCfgInfo->carrInfo[FDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_0]+preAllocCfgInfo->carrInfo[FDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_1];
        }
        else
        {
            carrCnt = preAllocCfgInfo->carrInfo[FDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_1];
        }
    }
    if((radioMode != BSP_RADIO_STANDARD_5G)&&(radioMode != BSP_RADIO_STANDARD_FDD_5G))
    {
        carrCnt = preAllocCfgInfo->carrInfo[LTE_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_0];
    }
    return carrCnt;
}

/****************************************************************
* 函数名称: BspInitBoardPreAllocParaToHal
* 函数说明：给hal设置当前单板下的协议类型和真实天线数（注意ubr填真实天线）
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*    创建
*
*****************************************************************/
UINT32 BspInitBoardPreAllocParaToHal(UINT32 uCprType, UINT32 uAntMask)
{
    (void)BspHalAdaptSetResPreAllocPara(uCprType,uAntMask);
    return BSP_OK;
}
/****************************************************************
* 函数名称: BspInitBoardPreAllocInfo
* 函数说明：设置当前单板下的预制场景和整机类型
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*    创建
*
*****************************************************************/
UINT32 BspInitBoardPreAllocInfo(T_BspHalAdaptPreAllocCarrInfo* preAllocInfo,UINT32 rruType)
{
    INPUT_POINTER_CHECK(preAllocInfo);
    /* 根据规格预先设置场景预置信息，保证能包住大部分配置需求。部分机型实际上只需要一种场景就可以包住，主要是TDD机型存在切换 */
    gs_boardPreAllocInfo = preAllocInfo;
    gs_rruTypeInfo = rruType;
    return BSP_OK;
}
/****************************************************************
* 函数名称: BspGetCurrPreAllocInfo
* 函数说明：获取当前单板下的预制场景和整机类型
* 输入参数：
* 输出参数：preAllocInfo: 预制的场景信息　rruTpye: 整机大类　T F T+F
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*    创建
*****************************************************************/
UINT32 BspGetBoardPreAllocInfo(T_BspHalAdaptPreAllocCarrInfo** preAllocInfo, UINT32* rruTpye)
{
    INPUT_POINTER_CHECK(preAllocInfo);
    INPUT_POINTER_CHECK(rruTpye);

    if (gs_boardPreAllocInfo == NULL) {
        return BSP_ERROR; /*board 未预置 */
    }
    *preAllocInfo = gs_boardPreAllocInfo;
    *rruTpye = gs_rruTypeInfo;

    return BSP_OK;
}
/****************************************************************
* 函数名称: BspPreAllocCompatibleAnalysis
* 函数说明： 比较2种场景配置，判断是否兼容
* 输入参数： supportPreAllocBwInfo 当前支持的场景 preCfgInfo 下发的场景配置
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
/* Started by AICoder, pid:b81e3227ece24f76a126893c595daeb8 */
/* Started by AI-VerifyCI-CodeComplexity, pid:b81e3227ece24f76a126893c595daeb8 */ 
UINT32 BspPreAllocCompatibleAnalysis(T_BspHalAdaptPreAllocCarrInfo* supportPreAllocSenceInfo, T_BspPreSenceAllocCarrInfo* preCfgInfo, BOOL* analysisRet)
{
    UINT32 senceType = 0;
    UINT32 cnt[3] = {0};

    INPUT_POINTER_CHECK(supportPreAllocSenceInfo); /* RU 支持的场景 */
    INPUT_POINTER_CHECK(preCfgInfo); /* 当前载波配置 */
    INPUT_POINTER_CHECK(analysisRet);

    senceType = supportPreAllocSenceInfo->senceType;
    if ((senceType == FDD_PREALLOC_SENCE) || (senceType == FDD_PREALLOC_SENCE_IF1))
    {
        /*FDD场景已经是芯片最大能力，48载波(IF0 和 IF1)一定可以支持纯FDD机型  载波配置信息里要含有当前整机的类型信息*/
        RETURN_VAL_DO_IF_EXP(preCfgInfo->rruType == FDD_TYPE, BSP_OK, *analysisRet = TRUE);
    }

    if ((senceType == TDDFDD_PREALLOC_SENCE) || (senceType == TDDFDD_PREALLOC_SENCE_TLTE_IF1))
    {
        /*T+F场景只给T+F机型用，现在可包住各规格的需求  载波配置信息里要含有当前整机的类型信息*/
        RETURN_VAL_DO_IF_EXP(preCfgInfo->rruType == TDDFDD_TYPE, BSP_OK, *analysisRet = TRUE);
    }
    if ((senceType == TDD_PREALLOC_ONLY80MNR_SENCE) && (preCfgInfo->rruType == QCELL_TYPE))
    {
        *analysisRet = TRUE;                    /*QCELL机型固定场景6*/
        return BSP_OK;
    }
    IF (senceType == TDDFDD_PREALLOC_SENCE_NCR)
    {
        *analysisRet = TRUE;                    /*NCR机型固定场景10*/
        return BSP_OK;
    }
    if((senceType == TDD_PREALLOC_ONLY100MNR_SENCE)||(senceType == TDD_PREALLOC_100M20M_SENCE))/*TDD 3*100M  FDD和T+F 不会选到这个场景，只考虑TDD 此时可以支持单NR和LV没有带宽限制*//*TDD NR 2*100M+4*20一样*/
    {
        cnt[0]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_5G, 100000);
        cnt[1]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_LTE_TDD, 20000);
        if(((cnt[0]+cnt[1]) <= (supportPreAllocSenceInfo->preAllocInfo[TDDNR_SRC_TYPE].uAntNum+supportPreAllocSenceInfo->preAllocInfo[LTE_SRC_TYPE].uAntNum))
            &&(cnt[0]<=(supportPreAllocSenceInfo->preAllocInfo[TDDNR_SRC_TYPE].uAntNum)))
        {
            *analysisRet = TRUE;
            return BSP_OK;
        }
    }
    if(senceType == TDD_PREALLOC_ONLY80MNR_SENCE)/*TDD 4*80M  FDD和T+F 不会选到这个场景，只考虑TDD 此时可以支持单NR和LV没有带宽限制*/
    {
        cnt[0]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_5G, 10000);
        cnt[1]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_5G, 80000);
        cnt[2]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_LTE_TDD, 20000);
        if(((cnt[1]+cnt[2]) <= supportPreAllocSenceInfo->preAllocInfo[TDDNR_SRC_TYPE].uAntNum)&&(cnt[0] == cnt[1]))
        {
            *analysisRet = TRUE;
            return BSP_OK;
        }
    }
    if(senceType == TDD_PREALLOC_60M20M_SENCE)/*/* TDD NR 4*60M+4*20  FDD和T+F 不会选到这个场景，只考虑TDD 此时可以支持单NR和LV没有带宽限制*/
    {
        cnt[0]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_5G, 100000);
        cnt[1]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_5G, 60000);
        cnt[2]= getCarrNumLowThanBandWidth(preCfgInfo, BSP_RADIO_STANDARD_LTE_TDD, 20000);
        if((((cnt[1]+cnt[2]) <= supportPreAllocSenceInfo->preAllocInfo[TDDNR_SRC_TYPE].uAntNum+supportPreAllocSenceInfo->preAllocInfo[LTE_SRC_TYPE].uAntNum))&&(cnt[0] == cnt[1])
        &&(cnt[1]<=supportPreAllocSenceInfo->preAllocInfo[TDDNR_SRC_TYPE].uAntNum))
        {
            *analysisRet = TRUE;
            return BSP_OK;
        }
    }
    if(senceType == TDD_PREALLOC_ONLY20MLTE_SENCE) /*TDD 6*20M lte 只能支持TDD LTE单模*/
    {
        if((isOnlyNrOrLte(preCfgInfo,BSP_RADIO_STANDARD_LTE_TDD))&& (preCfgInfo->carrInfo[LTE_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_0] <= supportPreAllocSenceInfo->preAllocInfo[TDDNR_SRC_TYPE].uAntNum))
        {
            *analysisRet = TRUE;
            return BSP_OK;
        }
    }

    *analysisRet = FALSE;
    return BSP_OK;
}
/* Ended by AI-VerifyCI-CodeComplexity, pid:b81e3227ece24f76a126893c595daeb8 */
/* Ended by AICoder, pid:b81e3227ece24f76a126893c595daeb8 */ 

/*将底层hal场景预制数组改成统一结构*/
UINT32 BspConVertHalPreAllocList(T_PreAlloc_BaseInfo *pPreAllocListInfo,T_PreAllocBaseInfo *pPreAllocInfo)
{
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(pPreAllocListInfo);
    INPUT_POINTER_CHECK(pPreAllocListInfo);

    pPreAllocInfo->uMode = pPreAllocListInfo->uMode;
    pPreAllocInfo->uScs = pPreAllocListInfo->uScs;
    pPreAllocInfo->uAntNum = pPreAllocListInfo->uAntNum;
    pPreAllocInfo->uIfType = pPreAllocListInfo->uIfType;
    pPreAllocInfo->uBw = pPreAllocListInfo->uBw;
    pPreAllocInfo->uAllocType = pPreAllocListInfo->uAllocType;
    return ret;
}
/****************************************************************
* 函数名称: BspGetPreAllocSenceInfo
* 函数说明：将从底层获取到的场景　　转换成统一的格式方便funclib查询遍历
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*        创建
*
*****************************************************************/
UINT32 BspGetPreAllocSenceInfo(T_BspHalAdaptPreAllocCarrInfo* ptPreSenceInfo,UINT32 senceNum, UINT32* pSenceNum)
{
    UINT32 cnt = 0;
    UINT32 loop = 0;
    UINT32 type = 0;
    UINT32 ret  = 0;
    T_PreAllocInfo *pPreAllocList = NULL;
    T_PreAlloc_BaseInfo *tmpBaseInfo = NULL;

    INPUT_POINTER_CHECK(ptPreSenceInfo);
    INPUT_POINTER_CHECK(pSenceNum);

    ret =  BspHalAdaptGetPreAllocSenceList(&pPreAllocList, &cnt);
    if(ret != BSP_OK)
    {
        dbgErr("BspHalAdaptGetPreAllocSenceList error\n");
        return ret;
    }
    if(cnt >= senceNum)
    {
        dbgErr("BspHalAdaptGetPreAllocSenceList  cnt error\n");
        return BSP_ERROR;
    }
    *pSenceNum = cnt;
    for(loop = 0; loop < cnt; loop++)
    {
        ptPreSenceInfo[loop].senceType = loop;
        for(type = 0; type < PRE_ALLOC_INFO_TYPE; type++)
        {
            if(pPreAllocList[loop].atInfo[type].uMode == BSP_RADIO_STANDARD_5G)
            {
                tmpBaseInfo = &pPreAllocList[loop].atInfo[type];
                BspConVertHalPreAllocList(tmpBaseInfo,&ptPreSenceInfo[loop].preAllocInfo[TDDNR_SRC_TYPE]);
            }
            else if(pPreAllocList[loop].atInfo[type].uMode == BSP_RADIO_STANDARD_FDD_5G)
            {
                tmpBaseInfo = &pPreAllocList[loop].atInfo[type];
                BspConVertHalPreAllocList(tmpBaseInfo,&ptPreSenceInfo[loop].preAllocInfo[FDDNR_SRC_TYPE]);
            }
            else if((pPreAllocList[loop].atInfo[type].uMode == BSP_RADIO_STANDARD_LTE_FDD)||
            ((pPreAllocList[loop].atInfo[type].uMode == BSP_RADIO_STANDARD_LTE_TDD)&&(pPreAllocList[loop].atInfo[type].uIfType == OAM_CELL_IF0_TYPE))) /*如果纯NR  这里实际上在赋０*/
            {
                tmpBaseInfo = &pPreAllocList[loop].atInfo[type];
                BspConVertHalPreAllocList(tmpBaseInfo,&ptPreSenceInfo[loop].preAllocInfo[LTE_SRC_TYPE]);
            }
            else if((pPreAllocList[loop].atInfo[type].uMode == BSP_RADIO_STANDARD_LTE_TDD)&&(pPreAllocList[loop].atInfo[type].uIfType == OAM_CELL_IF1_TYPE))
            {
                tmpBaseInfo = &pPreAllocList[loop].atInfo[type];
                BspConVertHalPreAllocList(tmpBaseInfo,&ptPreSenceInfo[loop].preAllocInfo[LTE_IF1_SRC_TYPE]);
            }
        }
    }
    return BSP_OK;
}
/****************************************************************
* 函数名称: BspValidPreAllocListSearchOptimalScene
* 函数说明：从有效场景中，寻找最优场景
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*        创建
*
*****************************************************************/
UINT32 BspValidPreAllocListSearchOptimalScene(T_BspHalAdaptPreAllocCarrInfo* supportPreAllocList[], UINT32 preAllocNum,
        T_BspPreSenceAllocCarrInfo* preAllocCarrInfo, T_BspHalAdaptPreAllocCarrInfo** outAllocInfo)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(supportPreAllocList);
    INPUT_POINTER_CHECK(preAllocCarrInfo);
    INPUT_POINTER_CHECK(outAllocInfo);
    /* 最优规则：这里暂时判断纯TDD，纯FDD和T+F  只有一个场景不用选 */
    /*（1）如果当前配置是混模  优先先混模配置，不要选到单NR场景下，走到这个接口说明之前单板下预制的不满足，或者之前的场景不满足，要切换了
     *（2）如果支持的场景既有单模场景又有混模场景，优先选择混模*/
    if(preAllocCarrInfo->rruType == TDD_TYPE)
    {
      for(loop= 0; loop< preAllocNum;loop++)
      {
          if(supportPreAllocList[loop]->senceType == TDD_PREALLOC_100M20M_SENCE)
          {
              *outAllocInfo =  supportPreAllocList[loop];
              return BSP_OK;
          }
      }
      for(loop= 0; loop< preAllocNum;loop++)
      {
          if(supportPreAllocList[loop]->senceType == TDD_PREALLOC_60M20M_SENCE)
          {
              *outAllocInfo =  supportPreAllocList[loop];
              return BSP_OK;
          }
      }
    }

    *outAllocInfo = supportPreAllocList[0];
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspSearchOptimalPreAllocUsingPreCfg
* 函数说明：给定场景的配置，从支持的场景列表中，选出最优的场景返回
* 输入参数： preAllocBwInfo 载波配置信息
* 输出参数： outAllocInfo 找到的场景信息
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*        创建
*
*****************************************************************/
UINT32 BspSearchOptimalPreAllocUsingPreCfg(T_BspPreSenceAllocCarrInfo* preSenceAllocCarrInfo,
        T_BspHalAdaptPreAllocCarrInfo* boardPreAlloc, T_BspHalAdaptPreAllocCarrInfo** outAllocInfo, BOOL* outStatus)
{
    T_BspHalAdaptPreAllocCarrInfo preAllocList[PRE_ALLOC_SENCE_NUM] = {0}; /* Ru上支持的场景预置列表，需要HAL提供 */
    UINT32  preAllocListNum = 0;
    UINT32 loop = 0;
    BOOL  compatible = FALSE;
    T_BspHalAdaptPreAllocCarrInfo** validPreAllocList = NULL; /* 有效的场景列表，需要从该表中找最优的场景 */
    UINT32 validPreAllocNum = 0;

    INPUT_POINTER_CHECK(preSenceAllocCarrInfo);
    INPUT_POINTER_CHECK(outAllocInfo);
    INPUT_POINTER_CHECK(outStatus);

    if (boardPreAlloc != NULL)
    {
        /* 从board下发的预置信息中查,是否支持 */
        (void)BspPreAllocCompatibleAnalysis(boardPreAlloc, preSenceAllocCarrInfo, &compatible);
        if (compatible == TRUE)
        {
            *outAllocInfo = boardPreAlloc;
            *outStatus = TRUE;
            return BSP_OK;
        }
    }
    /* 从HAL支持的列表中,选择最优的场景 　并转成统一的格式　提供给hal层使用*/
    if (BspGetPreAllocSenceInfo(preAllocList,PRE_ALLOC_SENCE_NUM, &preAllocListNum) != BSP_OK) {
        dbgErr("Exec BspSearchOptimalPreAllocUsingPreCfg->BspGetPreAllocSenceInfo error, preAllocList Is Null\n");
        return BSP_ERROR;
    }
    DYN_MEM_ALLOC(validPreAllocList, sizeof(T_BspHalAdaptPreAllocCarrInfo*) * preAllocListNum);
    if (validPreAllocList == NULL) {
        dbgErr("Alloc Memory error, alloc failed\n");
        return BSP_ERROR;
    }

    for (loop = 0; loop < preAllocListNum; loop++) {
        (void)BspPreAllocCompatibleAnalysis(preAllocList + loop, preSenceAllocCarrInfo, &compatible);
        if(compatible == FALSE) {
            continue;
        }
        validPreAllocList[validPreAllocNum++] = preAllocList + loop;
    }
    if (validPreAllocNum == 0) {
        *outStatus = FALSE;  /* 未找到合适场景 */
    } else {
        *outStatus = TRUE;
        /* 从有效的场景列表中，查找最优的场景 */
        (void)BspValidPreAllocListSearchOptimalScene(validPreAllocList, validPreAllocNum, preSenceAllocCarrInfo, outAllocInfo);
    }
    DYN_MEM_FREE(validPreAllocList);
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspPreCfgAndEffectPreAllocAnalysis
* 函数说明：将生效的场景和新下发的场景配置进行场景预置分析，将分析结果返回
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspPreCfgAndEffectPreAllocAnalysis(T_BspPreSenceAllocCarrInfo* preAllocCfgInfo, /* 下发的配置 */
        T_BspHalAdaptPreAllocCarrInfo* effectivePreAllocCfg,  /* 生效的场景 */
        T_BspHalAdaptPreAllocCarrInfo* boardPreAlloc,  /* 预置的场景 */
        T_BspHalAdaptPreAllocCarrInfo** outPreAllocBwInfo,/* 返回的最优场景 */
                                                        UINT32* analysisRet)
{
    BOOL presetRet = FALSE;

    INPUT_POINTER_CHECK(preAllocCfgInfo);
    INPUT_POINTER_CHECK(outPreAllocBwInfo);
    INPUT_POINTER_CHECK(analysisRet);
    INPUT_POINTER_CHECK(effectivePreAllocCfg);

    /* 当前生效的场景是否和下发场景是否兼容 */
    (void)BspPreAllocCompatibleAnalysis(effectivePreAllocCfg, preAllocCfgInfo, &presetRet);

    /* 下发的场景配置信息和当前生效的场景是一致的 */
    if (presetRet == TRUE) {
        *outPreAllocBwInfo = effectivePreAllocCfg;
        *analysisRet = PRE_ALLOC_TYPE_SUPPORT;
        return BSP_OK;
    }
    /* 从board下发 + hal支持的场景列表中选择场景 */
    if (BspSearchOptimalPreAllocUsingPreCfg(preAllocCfgInfo, boardPreAlloc, outPreAllocBwInfo, &presetRet) != BSP_OK) {
        dbgErr("Exec BspSearchOptimalPreAllocUsingPreCfg error \n");
        return BSP_ERROR;
    }
    /* 场景切换 */
    if (presetRet == TRUE) {
        *analysisRet = PRE_ALLOC_TYPE_CHG_SCENE;
    } else {
        *outPreAllocBwInfo = NULL;
        *analysisRet = PRE_ALLOC_TYPE_NOT_SUPPORT;
    }
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspPreAllocAnalysis
* 函数说明：场景预置分析
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspPreAllocAnalysis(T_BspPreSenceAllocCarrInfo* preAllocCfgInfo, T_BspHalAdaptPreAllocCarrInfo* effictivePreAlloc,
        T_BspHalAdaptPreAllocCarrInfo* boardPreAlloc, T_BspHalAdaptPreAllocCarrInfo** outPreAllocBwInfo, UINT32* analysisRet)
{
    BOOL presetRet = FALSE;
    INPUT_POINTER_CHECK(preAllocCfgInfo);
    INPUT_POINTER_CHECK(outPreAllocBwInfo);
    INPUT_POINTER_CHECK(analysisRet);
    /* 从场景列表中找 */
    if (effictivePreAlloc == NULL) {
        /* 当前无生效的场景，则根据配置找最优场景 */
        if (BspSearchOptimalPreAllocUsingPreCfg(preAllocCfgInfo, boardPreAlloc, outPreAllocBwInfo, &presetRet) != BSP_OK) {
            dbgErr("Exec BspSearchOptimalPreAllocUsingPreCfg error \n");
            return BSP_ERROR;
        }

        if (presetRet == TRUE) {
            *analysisRet = PRE_ALLOC_TYPE_CHG_SCENE; /*第一次找到的场景从无到有　认为是场景切换的动作*/
        } else {
            *outPreAllocBwInfo = NULL;
            *analysisRet = PRE_ALLOC_TYPE_NOT_SUPPORT;
        }
        return BSP_OK;
    }
    return BspPreCfgAndEffectPreAllocAnalysis(preAllocCfgInfo, effictivePreAlloc, boardPreAlloc, outPreAllocBwInfo, analysisRet);
}

/****************************************************************
* 函数名称: BspDefinedCellPreAllloc
* 函数说明：根据XML下发的载波能力，从支持的场景列表中，选择预置场景（4.2上无此功能）
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspDefinedCellPreAllloc(T_PreAllocCfgInfo* xmlPreCfgInfo)
{
    /*后续要弱化funcset（表征支持的载波制式和数量）的作用，所以4.2上不再使用此信息进行预制，接口保留保证高层流程统一*/
    INPUT_POINTER_CHECK(xmlPreCfgInfo);
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspConvAppChanCarrCfgInfo
* 函数说明：将APP下发的载波配置信息，转换成BSP FuncLib层处理的载波信息（滤掉删除的载波信息转换目的在于Bsp 方便处理),用来判断使用的场景
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspConvAppChanCarrCfgInfo(T_BspHalAdaptAllCellCarrInfo* appChanCarrCfg, UINT32 rruType, T_BspPreSenceAllocCarrInfo* preAllocCarrInfo)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(appChanCarrCfg);
    INPUT_POINTER_CHECK(preAllocCarrInfo);
    if (appChanCarrCfg->carrNum > MAX_ALL_CARR_NUM) {
        dbgErr("Exec BspConvAppChanCarrCfgInfo error, carrNum large than %d\n", MAX_ALL_CARR_NUM);
        return BSP_ERROR;
    }

    (void)memset_s(preAllocCarrInfo, sizeof(T_BspPreSenceAllocCarrInfo), 0, sizeof(T_BspPreSenceAllocCarrInfo));
    preAllocCarrInfo->rruType = rruType;  //表征TDD FDD 和T+F机型
    for (loop = 0; loop < appChanCarrCfg->carrNum; loop++) {
        if(appChanCarrCfg->carrInfo[loop].delOrAddFlag == CARR_STATUS_DEL)
        {
            continue;
        }
        preAllocCarrInfo->carrTotalNum++;
        if (BSP_RADIO_STANDARD_5G == appChanCarrCfg->carrInfo[loop].radioMode) {
            if(appChanCarrCfg->carrInfo[loop].bandWidth > 80000)
            {
                preAllocCarrInfo->carrInfo[TDDNR_CARR_TYPE].bandWidth[CARR_BANDWIDTH_TYPE_0] = BANDWIDTH_100M;
                preAllocCarrInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_0]++;
            }
            else if((appChanCarrCfg->carrInfo[loop].bandWidth > 60000)&&(appChanCarrCfg->carrInfo[loop].bandWidth <= 80000))
            {
                preAllocCarrInfo->carrInfo[TDDNR_CARR_TYPE].bandWidth[CARR_BANDWIDTH_TYPE_1] = BANDWIDTH_80M;
                preAllocCarrInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_1]++;
            }
            else
            {
                preAllocCarrInfo->carrInfo[TDDNR_CARR_TYPE].bandWidth[CARR_BANDWIDTH_TYPE_2] = BANDWIDTH_60M;
                preAllocCarrInfo->carrInfo[TDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_2]++;
            }
        } else if (BSP_RADIO_STANDARD_FDD_5G == appChanCarrCfg->carrInfo[loop].radioMode) {
            if(appChanCarrCfg->carrInfo[loop].bandWidth > 20000)
            {
                preAllocCarrInfo->carrInfo[FDDNR_CARR_TYPE].bandWidth[CARR_BANDWIDTH_TYPE_0] = BANDWIDTH_60M;
                preAllocCarrInfo->carrInfo[FDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_0]++;
            }
            else
            {
                preAllocCarrInfo->carrInfo[FDDNR_CARR_TYPE].bandWidth[CARR_BANDWIDTH_TYPE_1] = BANDWIDTH_20M;
                preAllocCarrInfo->carrInfo[FDDNR_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_1]++;
            }
        }
        else  {
            preAllocCarrInfo->carrInfo[LTE_CARR_TYPE].bandWidth[CARR_BANDWIDTH_TYPE_0] = BANDWIDTH_20M;
            preAllocCarrInfo->carrInfo[LTE_CARR_TYPE].carrNum[CARR_BANDWIDTH_TYPE_0]++;
        }
    }
     return BSP_OK;
}


//过滤高层下发的配置，将GUN滤掉，同时不再区分通道组进行统计，因为4.2上按资源总数进行预制分析，不再按通道进行
UINT32 BspGetLvAppCarr(T_DestCarrInfo* appChanCarrCfg, UINT32 carrChan, T_BspHalAdaptAllCellCarrInfo* outCellCarrInfo)
{
    UINT32 outCarrIndex = 0;
    INPUT_POINTER_CHECK(appChanCarrCfg);
    INPUT_POINTER_CHECK(outCellCarrInfo);

    outCarrIndex = outCellCarrInfo->carrNum;
    if(appChanCarrCfg->radioMode&(BSP_RADIO_STANDARD_UMTS|BSP_RADIO_STANDARD_GSM|BSP_RADIO_STANDARD_NB_IOT))
    {
        dbgInfoEx("GUN Carr does not need analyze,del carr does not need analyze\n");
        return BSP_ERROR;
    }
       else
       {
           outCellCarrInfo->carrInfo[outCarrIndex].carrNo = appChanCarrCfg->carrNo;
           outCellCarrInfo->carrInfo[outCarrIndex].radioMode = appChanCarrCfg->radioMode;
        outCellCarrInfo->carrInfo[outCarrIndex].freq = appChanCarrCfg->freq;
           outCellCarrInfo->carrInfo[outCarrIndex].bandWidth = appChanCarrCfg->bandWidth;
           outCellCarrInfo->carrInfo[outCarrIndex].delOrAddFlag = appChanCarrCfg->delOrAddFlag;
           outCellCarrInfo->carrInfo[outCarrIndex].chanNo = carrChan;
           outCellCarrInfo->carrNum++;
       }

    return BSP_OK;
}
UINT32 BspAddAppCarrToOutBuf(T_CellCarrInfo* appChanCarrCfg, UINT32 carrChan, T_GroupCellCarrInfo* outCellCarrInfo)
{
    UINT32 loopI = 0;
    UINT32 outCarrIndex = 0;
    INPUT_POINTER_CHECK(appChanCarrCfg);
    INPUT_POINTER_CHECK(outCellCarrInfo);
    for (loopI = 0; loopI < outCellCarrInfo->carrNum; loopI++)
    {
        if (appChanCarrCfg->carrNo == outCellCarrInfo->carrInfo[loopI].carrNo &&
                appChanCarrCfg->radioMode == outCellCarrInfo->carrInfo[loopI].radioMode)
        {
            //coverity[cert_int31_c_violation:SUPPRESS]
            //coverity[cert_int34_c_violation:SUPPRESS]
            outCellCarrInfo->carrInfo[loopI].chanMask |= (1 << carrChan);
            return BSP_OK;
        }
    }
    outCarrIndex = outCellCarrInfo->carrNum;
    if (outCarrIndex >= MAX_CARR_NUM)
    {
        dbgErr("%s> appCarrNum over bsp max carr num\r\n", __FUNCTION__);
        return BSP_ERROR;
    }
    outCellCarrInfo->carrInfo[outCarrIndex].carrNo = appChanCarrCfg->carrNo;
    outCellCarrInfo->carrInfo[outCarrIndex].radioMode = appChanCarrCfg->radioMode;
    outCellCarrInfo->carrInfo[outCarrIndex].freq = appChanCarrCfg->freq;
    outCellCarrInfo->carrInfo[outCarrIndex].bandWidth = appChanCarrCfg->bandWidth;
    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_int34_c_violation:SUPPRESS]
    outCellCarrInfo->carrInfo[outCarrIndex].chanMask = (1 << carrChan);
    outCellCarrInfo->carrNum++;
    return BSP_OK;

}
/****************************************************************
* 函数名称: BspConvertCarrCfgToCellCfg
* 函数说明：根据天线掩码，将APP下发的载波配置，转换成Bsp使用的载波配置（主要是APP 参数可能会变)
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspConvertCarrCfgToCellCfg( T_BspHalAdaptAllCellCarrInfo* chanCarrCfgArr, T_GroupCellCarrInfo* outCellCarrInfo)
{
    UINT32 loop = 0;
    UINT32 outCarrIndex = 0;
    T_GroupCellCarrInfo* tmp = NULL;

    INPUT_POINTER_CHECK(chanCarrCfgArr);
    INPUT_POINTER_CHECK(outCellCarrInfo);

    tmp = (T_GroupCellCarrInfo*)malloc(sizeof(T_GroupCellCarrInfo));
    if (tmp == NULL)
    {
        dbgErr("%s> alloc memory failed\r\n", __FUNCTION__);
        return BSP_ERROR;
    }
    (void)memset_s(tmp, sizeof(T_GroupCellCarrInfo), 0, sizeof(T_GroupCellCarrInfo));

    for (loop = 0; loop < chanCarrCfgArr->carrNum; loop++)
    {
        if(chanCarrCfgArr->carrInfo[loop].delOrAddFlag != CARR_STATUS_DEL)
        {
            (void)BspAddAppCarrToOutBuf(&chanCarrCfgArr->carrInfo[loop], chanCarrCfgArr->carrInfo[loop].chanNo,  tmp);
        }
    }

    for (loop = 0; loop < tmp->carrNum; loop++)
    {
        if(outCarrIndex < MAX_CARR_NUM)
        {
            (void)memcpy_s(&outCellCarrInfo->carrInfo[outCarrIndex], sizeof(T_CellCarrInfo),
                        &tmp->carrInfo[loop], sizeof(T_CellCarrInfo));
                //coverity[cert_int30_c_violation:SUPPRESS]
            ++outCarrIndex;
            outCellCarrInfo->carrNum = outCarrIndex;
        }
        else
        {
            free(tmp);
            return BSP_ERROR;
        }
    }
    free(tmp);
    return BSP_OK;
}
/****************************************************************
* 函数名称: BspGetNrAndLteCarrCfgInfo
* 函数说明：将APP下发的载波配置，转换成Bsp使用的载波配置（滤掉GUN载波)
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspGetNrAndLteCarrCfgInfo(T_DestCarrInfoChan* chanCarrCfgArr, UINT32 chanNum, T_BspHalAdaptAllCellCarrInfo* outCellCarrInfo)
{
    UINT32 loopI = 0;
    UINT32 loopJ = 0;
    UINT32 outCarrIndex = 0;
    T_BspHalAdaptAllCellCarrInfo* tmp = NULL;
    INPUT_POINTER_CHECK(chanCarrCfgArr);
    INPUT_POINTER_CHECK(outCellCarrInfo);

    if (chanNum == 0)
    {
        return BSP_ERROR;
    }

    tmp = (T_BspHalAdaptAllCellCarrInfo*)malloc(sizeof(T_BspHalAdaptAllCellCarrInfo));
    if (tmp == NULL)
    {
        dbgErr("%s> alloc memory failed\r\n", __FUNCTION__);
        return BSP_ERROR;
    }
    (void)memset_s(tmp, sizeof(T_BspHalAdaptAllCellCarrInfo), 0, sizeof(T_BspHalAdaptAllCellCarrInfo));

    for (loopI = 0; loopI < chanNum; loopI++)
    {
        for (loopJ = 0; loopJ < chanCarrCfgArr[loopI].carrNum; loopJ++)
        {/*高层下天线个数 每个天线的配置信息，这里把每个通道的每个载波遍历一遍*/
            (void)BspGetLvAppCarr(&chanCarrCfgArr[loopI].carrInfo[loopJ], chanCarrCfgArr[loopI].chanNo,  tmp);
        }
    }
     /*下面进行的是copy的过程*/
    for (loopI = 0; loopI < tmp->carrNum; loopI++)
    {
        (void)memcpy_s(&outCellCarrInfo->carrInfo[outCarrIndex], sizeof(T_CellCarrInfo),&tmp->carrInfo[loopI], sizeof(T_CellCarrInfo));
         if(outCellCarrInfo->carrInfo[outCarrIndex].radioMode == BSP_RADIO_STANDARD_5G) /*后续从光口小区获取高层下发*/
         {
             outCellCarrInfo->carrInfo[outCarrIndex].carrScs = OAM_CELL_CARR_SCS_30K;
             outCellCarrInfo->carrInfo[outCarrIndex].ifType = OAM_CELL_IF0_TYPE;
         }
         else
         {
             outCellCarrInfo->carrInfo[outCarrIndex].carrScs = OAM_CELL_CARR_SCS_15K;
             outCellCarrInfo->carrInfo[outCarrIndex].ifType = OAM_CELL_IF1_TYPE;
         }
         ++outCarrIndex;
         outCellCarrInfo->carrNum = outCarrIndex;
    }
    free(tmp);
    return BSP_OK;
}

/*载波映射处理资源位置分配不再由funclib底层处理，接口要对应适配*/
#if 0


UINT32 BspConvCarrMapToCarrCfgSt(T_CarrMapRet* carrMapInfo, T_CellCarrInfo* carrCfg)
{
    INPUT_POINTER_CHECK(carrMapInfo);
    INPUT_POINTER_CHECK(carrCfg);

    carrCfg->carrNo = carrMapInfo->carrNo;
    carrCfg->radioMode = carrMapInfo->radioMode;
    carrCfg->freq = carrMapInfo->freq;
    carrCfg->bandWidth = carrMapInfo->bandWidth;
    return BSP_OK;
}

UINT32 BspGetCarrIndexFromCarrCfgList(T_CellCarrInfo* carrCfg, T_CellCarrInfo* carrCfgArr, UINT32 carrCfgNum, UINT32* index)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(carrCfg);
    INPUT_POINTER_CHECK(carrCfgArr);
    INPUT_POINTER_CHECK(index);

    for (loop = 0; loop < carrCfgNum; loop++) {
        if (carrCfg->carrNo == carrCfgArr[loop].carrNo &&
            carrCfg->radioMode == carrCfgArr[loop].radioMode) {
            *index = loop;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/****************************************************************
* 函数名称: BspUpdatePreAllocCarrMapIndex
* 函数说明：更新光口载波号和载波之间的关系
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspUpdatePreAllocCarrMapIndex(T_PreAllocAssocCarrMapInfo* preAllocCarrMapStatusArr, UINT32 maxPreAllocStatusNum,
                                        UINT32 optCarrNo, UINT32 carrMapIndex)
{
    UINT32 loop;
    INPUT_POINTER_CHECK(preAllocCarrMapStatusArr);
    for (loop = 0; loop < maxPreAllocStatusNum; loop++) {
        if (preAllocCarrMapStatusArr[loop].optCarrNo == optCarrNo) {
            if (carrMapIndex == INVALID_UINT32) {
                preAllocCarrMapStatusArr[loop].mapFlag = INVALID_MAP_FLAG;
                preAllocCarrMapStatusArr[loop].carrMapIndex = carrMapIndex;
            } else {
                preAllocCarrMapStatusArr[loop].mapFlag = VALID_MAP_FLAG;
                preAllocCarrMapStatusArr[loop].carrMapIndex = carrMapIndex;
            }
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

UINT32 BspGetPreAllocCarrMapIndex(T_PreAllocAssocCarrMapInfo* preAllocCarrMapStatusArr, UINT32 maxPreAllocStatusNum,
                                        UINT32 optCarrNo, UINT32* carrMapIndex)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(preAllocCarrMapStatusArr);
    INPUT_POINTER_CHECK(carrMapIndex);

    for (loop = 0; loop < maxPreAllocStatusNum; loop++) {
        if (preAllocCarrMapStatusArr[loop].optCarrNo == optCarrNo) {
            *carrMapIndex = preAllocCarrMapStatusArr[loop].carrMapIndex;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}


/****************************************************************
* 函数名称: BspSetCarrMapHelpMapRetInfo
* 函数说明：将生效载波和配置载波的交集数据写入载波映射表
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspSetCarrMapHelpMapRetInfo(T_AllCarrMapHelpInfo* carrMapHelpInfo, T_BspHalAdaptAllChanCarrMapRet* effCarrMapRet, T_CellCarrInfo* carrCfgArr, UINT32 carrCfgNum)
{
    UINT32 loop = 0;
    UINT32 index = 0;
    UINT32 optCarrNo = 0;
    UINT32 lteNum = 0;
    UINT32 nrNum = 0;
    T_CellCarrInfo tmpCarrCfg = {0};
    T_CarrMapRet*  CarrMapRet = NULL;

    INPUT_POINTER_CHECK(carrMapHelpInfo);
    INPUT_POINTER_CHECK(carrCfgArr);

    if (effCarrMapRet == NULL) {
        return BSP_OK;
    }
    CarrMapRet  = effCarrMapRet->preAllocResult;
    //lteCarrMapRet = effCarrMapRet->carrMapInfo + carrMapHelpInfo->maxNrCarrNum;

    /* 遍历所有载波，比较2次载波配置，将删除的载波过滤掉 */
    for (loop = 0; loop < carrMapHelpInfo->maxNrCarrNum+carrMapHelpInfo->maxLteCarrNum; loop++) {
        if (CarrMapRet[loop].validFlag != VALID_CARR_FLAG) {
            continue;
        }
        (void)BspConvCarrMapToCarrCfgSt(&CarrMapRet[loop], &tmpCarrCfg);
        index = INVALID_UINT32;
        (void)BspGetCarrIndexFromCarrCfgList(&tmpCarrCfg, carrCfgArr, carrCfgNum,&index);
        if (index == INVALID_UINT32) {
            carrMapHelpInfo->CarrMapRetPtr[loop].validFlag = INVALID_CARR_FLAG; /* clear delete status carr map */
            continue;
        }
        (void)memcpy_s(&carrMapHelpInfo->CarrMapRetPtr[loop], sizeof(T_CarrMapRet), &CarrMapRet[loop], sizeof(T_CarrMapRet));
        nrNum++;

        /* 光口载波状态是已映射 */
        optCarrNo = CarrMapRet[loop].optCarrNo;
        (void)BspUpdatePreAllocCarrMapIndex(carrMapHelpInfo->preAllocMapCarrStatus, carrMapHelpInfo->maxNrCarrNum, optCarrNo, loop);
    }
    carrMapHelpInfo->nrCarrNum = nrNum;
    carrMapHelpInfo->lteCarrNum = lteNum;
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspGetCarrMapIndexUsingBandWidth
* 函数说明：从最小带宽开始匹配，获取满足条件带宽的数据索引
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspGetNrCarrMapIndexUsingBandWidth(UINT32 bandWidth, UINT32 mapFlag, T_AllCarrMapHelpInfo* carrMapHelpInfo, UINT32* index)
{
    INT32 loop = 0;
    INT32 startIndex = 0;

    INPUT_POINTER_CHECK(carrMapHelpInfo);
    INPUT_POINTER_CHECK(index);

    startIndex = (INT32)carrMapHelpInfo->maxNrCarrNum - 1;
    for (loop = startIndex; loop >= 0; loop--) {
        if ((carrMapHelpInfo->preAllocMapCarrStatus[loop].mapFlag == mapFlag) &&
            (carrMapHelpInfo->preAllocMapCarrStatus[loop].bandWidth >= bandWidth)) {
            *index = carrMapHelpInfo->preAllocMapCarrStatus[loop].optCarrNo;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

UINT32 BspGetLteCarrMapIndexUsingBandWidth(UINT32 bandWidth, UINT32 mapFlag, T_AllCarrMapHelpInfo* carrMapHelpInfo, UINT32* index)
{
    INT32 loop = 0;
    INT32 startIndex = 0;

    INPUT_POINTER_CHECK(carrMapHelpInfo);
    INPUT_POINTER_CHECK(index);

    startIndex = carrMapHelpInfo->maxLteCarrNum+ carrMapHelpInfo->maxNrCarrNum - 1; //先查询LTE本身的位置，再查询NR空闲的位置,通过LTE和NR资源位置的摆放来实现先后顺序
    for (loop = startIndex; loop >= 0; loop--) {
        if ((carrMapHelpInfo->preAllocMapCarrStatus[loop].mapFlag == mapFlag) &&
            (carrMapHelpInfo->preAllocMapCarrStatus[loop].bandWidth >= bandWidth)) {
            *index = carrMapHelpInfo->preAllocMapCarrStatus[loop].optCarrNo;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}


/****************************************************************
* 函数名称: BspEnterNrCarrCfgMap
* 函数说明：NR载波映射
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspEnterNrCarrCfgMap(T_CellCarrInfo* carrCfgInfo, T_AllCarrMapHelpInfo* carrMapHelpInfo)
{
    UINT32 optCarrNo = INVALID_UINT32;
    UINT32 carrIndex = INVALID_UINT32;
    UINT32 chgCarrIndex = INVALID_UINT32;
    INPUT_POINTER_CHECK(carrCfgInfo);
    INPUT_POINTER_CHECK(carrMapHelpInfo);

    (void)BspGetCompCarrMapIndex(carrCfgInfo, carrMapHelpInfo->CarrMapRetPtr, carrMapHelpInfo->maxNrCarrNum, &carrIndex);
    if (carrIndex == INVALID_UINT32) {
        dbgErr("Exec BspEnterNrCarrCfgMap error, can't find carr info carrNo [%u], radioMode [%u]\n",
            carrCfgInfo->carrNo, carrCfgInfo->radioMode);
        return BSP_ERROR;
    }

    /* 已映射 */
    if (carrMapHelpInfo->CarrMapRetPtr[carrIndex].mapFlag == VALID_MAP_FLAG) {
        return BSP_OK;
    }

    /* 根据带宽，找一个未用过的位置 */
    (void)BspGetNrCarrMapIndexUsingBandWidth(carrCfgInfo->bandWidth, INVALID_MAP_FLAG, carrMapHelpInfo, &optCarrNo);
    if (optCarrNo != INVALID_UINT32) {
        carrMapHelpInfo->CarrMapRetPtr[carrIndex].optCarrNo = optCarrNo;
        carrMapHelpInfo->CarrMapRetPtr[carrIndex].difCarrNo = optCarrNo;
        carrMapHelpInfo->CarrMapRetPtr[carrIndex].mapFlag = VALID_MAP_FLAG;
        carrMapHelpInfo->CarrMapRetPtr[carrIndex].bandWidth = carrCfgInfo->bandWidth;
        carrMapHelpInfo->CarrMapRetPtr[carrIndex].freq = carrCfgInfo->freq;

        (void)BspUpdatePreAllocCarrMapIndex(carrMapHelpInfo->preAllocMapCarrStatus, carrMapHelpInfo->maxNrCarrNum,
                                        optCarrNo, carrIndex);
        carrMapHelpInfo->nrCarrNoMapNum--;
        return BSP_OK;
    }
    /* 满足带宽条件的空闲位置找不到时，则需要找到一个符合条件的载波位置，将载波进行交换 */
    (void)BspGetNrCarrMapIndexUsingBandWidth(carrCfgInfo->bandWidth, VALID_MAP_FLAG, carrMapHelpInfo, &optCarrNo);

    if (optCarrNo == INVALID_UINT32) {
        /* 理论上一定能找到一个位置进行交换，如果找不到，则说明运行异常。*/
        dbgErr("Exec BspEnterNrCarrCfgMap error, can't find avaliable carr map\n");
        return BSP_ERROR;
    }

    /* 根据光口载波ID获取逻辑载波位置*/
    (void)BspGetPreAllocCarrMapIndex(carrMapHelpInfo->preAllocMapCarrStatus, carrMapHelpInfo->maxNrCarrNum,
                                        optCarrNo, &chgCarrIndex);
    if (chgCarrIndex == INVALID_UINT32) {
        /* 理论上一定能找到一个位置进行交换，如果找不到，则说明运行异常。*/
        dbgErr("Exec BspEnterNrCarrCfgMap error, carr change index invalid map\n");
        return BSP_ERROR;
    }
    carrMapHelpInfo->CarrMapRetPtr[carrIndex].optCarrNo = optCarrNo;
    carrMapHelpInfo->CarrMapRetPtr[carrIndex].difCarrNo = optCarrNo;
    carrMapHelpInfo->CarrMapRetPtr[carrIndex].exchaneFlag = NO_CARR_CHG_FALG;
    carrMapHelpInfo->CarrMapRetPtr[carrIndex].bandWidth = carrCfgInfo->bandWidth;
    carrMapHelpInfo->CarrMapRetPtr[carrIndex].freq = carrCfgInfo->freq;
    carrMapHelpInfo->CarrMapRetPtr[carrIndex].mapFlag = VALID_MAP_FLAG;

    /* 更新光口载波和逻辑载波位置映射关系 */
    (void)BspUpdatePreAllocCarrMapIndex(carrMapHelpInfo->preAllocMapCarrStatus, carrMapHelpInfo->maxNrCarrNum,
                                        optCarrNo, carrIndex);

    carrMapHelpInfo->CarrMapRetPtr[chgCarrIndex].mapFlag = INVALID_MAP_FLAG;
    carrMapHelpInfo->CarrMapRetPtr[chgCarrIndex].exchaneFlag = CARR_CHG_FALG;
    carrMapHelpInfo->CarrMapRetPtr[chgCarrIndex].optCarrNo = INVALID_UINT32;
    carrMapHelpInfo->CarrMapRetPtr[chgCarrIndex].difCarrNo = INVALID_UINT32;
    carrMapHelpInfo->isCarrChg = 1; /* 载波已经交换 */

    return BSP_OK;
}

/****************************************************************
* 函数名称: BspEnterLteCarrCfgMap
* 函数说明：Lte载波映射
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspEnterNewLteCarrCfgMap(T_CellCarrInfo* carrCfgInfo, T_AllCarrMapHelpInfo* chanCarrMapHelpInfo)
{
    UINT32 loop = 0;
    UINT32 optCarrNo = INVALID_UINT32;
    INPUT_POINTER_CHECK(carrCfgInfo);
    INPUT_POINTER_CHECK(chanCarrMapHelpInfo);
    /* 新增载波影射的场景下， */
    (void)BspGetLteCarrMapIndexUsingBandWidth(carrCfgInfo->bandWidth, INVALID_MAP_FLAG, chanCarrMapHelpInfo, &optCarrNo);
    if (optCarrNo == INVALID_UINT32) {
        dbgErr("Exec BspEnterLteCarrCfgMap error, inavaliable optCarrNo, no free space [%d]\n", optCarrNo);
        return BSP_ERROR;
    }

    for (loop = 0; loop < chanCarrMapHelpInfo->maxLteCarrNum; loop++) {
        if (chanCarrMapHelpInfo->CarrMapRetPtr[loop].validFlag != VALID_CARR_FLAG) {
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].carrNo = carrCfgInfo->carrNo;
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].radioMode = carrCfgInfo->radioMode;
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].freq = carrCfgInfo->freq;
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].bandWidth = carrCfgInfo->bandWidth;

            chanCarrMapHelpInfo->CarrMapRetPtr[loop].optCarrNo = optCarrNo;
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].difCarrNo = optCarrNo;
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].validFlag = VALID_CARR_FLAG;
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].mapFlag = VALID_MAP_FLAG;
            chanCarrMapHelpInfo->CarrMapRetPtr[loop].exchaneFlag = NO_CARR_CHG_FALG;
            (void)BspUpdatePreAllocCarrMapIndex(chanCarrMapHelpInfo->preAllocMapCarrStatus, chanCarrMapHelpInfo->maxLteCarrNum,
                                        optCarrNo, loop);
            chanCarrMapHelpInfo->lteCarrNum++;
            return BSP_OK;
        }
    }
    dbgErr("Exec BspEnterLteCarrCfgMap error, no free space\n");
    return BSP_ERROR;
}

/****************************************************************
* 函数名称: BspGetRadioInfoFromAppCarrCfgInfo
* 函数说明：将下发载波配置按制式提取
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspGetRadioInfoFromAppCarrCfgInfo(T_BspHalAdaptAllCellCarrInfo* appCarrCfg, UINT32 radioMode,
                                            T_CellCarrInfo* outArr[], UINT32 maxArrNum, UINT32* realNum)
{
    UINT32 loop = 0;
    UINT32 radioNum = 0;
    INPUT_POINTER_CHECK(appCarrCfg);
    INPUT_POINTER_CHECK(outArr);
    INPUT_POINTER_CHECK(realNum);

    for (loop = 0; loop < appCarrCfg->carrNum; loop++) {
        if ((appCarrCfg->carrInfo[loop].radioMode & radioMode) && radioNum < maxArrNum) {
            outArr[radioNum++] = &appCarrCfg->carrInfo[loop];
        }
    }
    *realNum = radioNum;
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspLteCarrMapHanlder
* 函数说明：LTE载波映射处理
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspLteCarrMapHanlder(T_CellCarrInfo*  carrCfgArr[], UINT32 carrNum, T_AllCarrMapHelpInfo* chanCarrMapHelpInfo)
{
    UINT32 loop = 0;
    UINT32 index = 0;
    INPUT_POINTER_CHECK(carrCfgArr);
    INPUT_POINTER_CHECK(chanCarrMapHelpInfo);
    /* carr Map handler */
    for (loop = 0; loop < carrNum; loop++) {
        index = INVALID_UINT32;
        (void)BspGetCompCarrMapIndex(carrCfgArr[loop], chanCarrMapHelpInfo->CarrMapRetPtr, chanCarrMapHelpInfo->maxLteCarrNum+chanCarrMapHelpInfo->maxNrCarrNum, &index);
        if (index != INVALID_UINT32) {
            /*  UPDATE 对于LTE 制式，找到对应的值后，直接更新带宽，理论上20M 都能包住 */
            if (chanCarrMapHelpInfo->CarrMapRetPtr[index].bandWidth != carrCfgArr[loop]->bandWidth) {
                chanCarrMapHelpInfo->CarrMapRetPtr[index].bandWidth = carrCfgArr[loop]->bandWidth;
            }
            chanCarrMapHelpInfo->CarrMapRetPtr[index].freq = carrCfgArr[loop]->freq;
        } else {
            /* 增加载波映射 Add  */
            if (BspEnterNewLteCarrCfgMap(carrCfgArr[loop], chanCarrMapHelpInfo) != BSP_OK) {
                dbgErr("Exec BspLteCarrMapAnalysisHanlder->BspEnterNewLteCarrCfgMap error\n");
                return BSP_ERROR;
            }
        }
    }
    return BSP_OK;
}

int BspSortCellCarrInfoByBandWidthAsc(const void* p1, const void* p2)
{
    T_CellCarrInfo* carrCfg1 = NULL;
    T_CellCarrInfo* carrCfg2 = NULL;
    carrCfg1 = *(T_CellCarrInfo**)(p1);
    carrCfg2 = *(T_CellCarrInfo**)(p2);
    /* 按带宽大小进行升序 */
    if (carrCfg1->bandWidth > carrCfg2->bandWidth) {
        return 1;
    } else if (carrCfg1->bandWidth == carrCfg2->bandWidth) {
        return 0;
    } else {
        return -1;
    }
}

UINT32 BspGetFreeIndexFromCarrMap(T_CarrMapRet* carrMapRetArr, UINT32 maxMapRetNum, UINT32* index)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(carrMapRetArr);
    INPUT_POINTER_CHECK(index);
    for (loop = 0; loop < maxMapRetNum; loop++) {
        if (carrMapRetArr[loop].validFlag != VALID_CARR_FLAG) {
            *index = loop;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

UINT32 BspPreHandlerNrCarrMap(T_CellCarrInfo*  carrCfgArr[], UINT32 carrNum, T_AllCarrMapHelpInfo* carrMapHelpInfo)
{
    UINT32 loop = 0;
    UINT32 index = 0;
    UINT32 optCarrNo = 0;

    INPUT_POINTER_CHECK(carrCfgArr);
    INPUT_POINTER_CHECK(carrMapHelpInfo);

    if (carrNum > carrMapHelpInfo->maxNrCarrNum) {
        dbgErr("Exec BBspPreHandlerCarrMap error carrNum over capacity, cfgNum [%u], capacity [%u]\n",
            carrNum, carrMapHelpInfo->maxNrCarrNum);
        return BSP_ERROR;
    }

    for (loop = 0; loop < carrNum; loop++) {
        index = INVALID_UINT32;
        (void)BspGetCompCarrMapIndex(carrCfgArr[loop], carrMapHelpInfo->CarrMapRetPtr, carrMapHelpInfo->maxNrCarrNum, &index);
        if (index != INVALID_UINT32) {
            /* HOLD +UPDATE 都不会触发重映射*/
            carrMapHelpInfo->CarrMapRetPtr[index].exchaneFlag = NO_CARR_CHG_FALG;
            carrMapHelpInfo->CarrMapRetPtr[index].bandWidth = carrCfgArr[loop]->bandWidth;
        } else {
            /* ADD */
            index = INVALID_UINT32;
            (void)BspGetFreeIndexFromCarrMap(carrMapHelpInfo->CarrMapRetPtr, carrMapHelpInfo->maxNrCarrNum, &index);
            if (index == INVALID_UINT32) {
                dbgErr("Exec BBspPreHandlerCarrMap error no free space for adding carr, carrNum [%u], maxCarrNum [%u]\n",
                    carrNum, carrMapHelpInfo->maxNrCarrNum);
                return BSP_ERROR;
            }
            carrMapHelpInfo->CarrMapRetPtr[index].validFlag = VALID_CARR_FLAG;
            carrMapHelpInfo->CarrMapRetPtr[index].carrNo = carrCfgArr[loop]->carrNo;
            carrMapHelpInfo->CarrMapRetPtr[index].radioMode = carrCfgArr[loop]->radioMode;
            carrMapHelpInfo->CarrMapRetPtr[index].freq = carrCfgArr[loop]->freq;
            carrMapHelpInfo->CarrMapRetPtr[index].bandWidth = carrCfgArr[loop]->bandWidth;

            carrMapHelpInfo->CarrMapRetPtr[index].optCarrNo = INVALID_UINT32;
            carrMapHelpInfo->CarrMapRetPtr[index].difCarrNo = INVALID_UINT32;
            carrMapHelpInfo->CarrMapRetPtr[index].mapFlag = INVALID_MAP_FLAG;
            carrMapHelpInfo->CarrMapRetPtr[index].exchaneFlag = NO_CARR_CHG_FALG;
            carrMapHelpInfo->nrCarrNum++;
            carrMapHelpInfo->nrCarrNoMapNum++;
        }
    }
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspNrCarrMapHanlder
* 函数说明：NR载波映射处理
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspNrCarrMapHanlder(T_CellCarrInfo*  carrCfgArr[], UINT32 carrNum, T_AllCarrMapHelpInfo* carrMapHelpInfo)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(carrCfgArr);
    INPUT_POINTER_CHECK(carrMapHelpInfo);

#if 0
    /* 载波映射预处理 */
    if (BspPreHandlerNrCarrMap(carrCfgArr, carrNum, carrMapHelpInfo) != BSP_OK) {
        dbgErr("Exec BspNrCarrMapHanlder->BspPreHandlerNrCarrMap error\n");
        return BSP_ERROR;
    }
    /* 未映射数量不为0, 需要映射 */
    while (carrMapHelpInfo->nrCarrNoMapNum > 0) {
        for (loop = 0; loop < carrNum; loop++) {
            if (BspEnterNrCarrCfgMap(carrCfgArr[loop], carrMapHelpInfo) != BSP_OK) {
                dbgErr("Exec BspNrCarrMapHanlder->BspEnterNrCarrCfgMap error\n");
                return BSP_ERROR;
            }
        }
    }
#endif
    return BSP_OK;
}
#endif
/****************************************************************
* 函数名称: BspCarrMapAnalysisHanlder
* 函数说明：载波映射分析后处理,这里不能再把NR和LTE分开处理，因为NR和LTE各自内部不需要交换，只有LTE占用了NR资源，然后新增NR且LTE删除,NR位置不够用时才需要把LTE交换
*         传给hal选择的场景、当前的配置，从hal返回需要交换的载波
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/

UINT32 BspCarrMapAnalysisHanlder(T_BspHalAdaptAllCellCarrInfo* appCarrCfg, T_BspHalAdaptPreAllocCarrInfo* preAllocBwInfo, T_AllChanCarrMapInfo* presetCarrMapRet)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    T_GroupCellCarrInfo outCellCarrInfo = {0};

    INPUT_POINTER_CHECK(appCarrCfg);
    INPUT_POINTER_CHECK(preAllocBwInfo);
    INPUT_POINTER_CHECK(presetCarrMapRet);

    (void)BspConvertCarrCfgToCellCfg(appCarrCfg,&outCellCarrInfo);
    for(loop = 0; loop< outCellCarrInfo.carrNum; loop++)
    {

#if 0
        index = 0xff;
        loop1 = presetCarrMapRet->chanCarrMapRet.carrNum;
        BspGetCompCarrMapIndex(appCarrCfg->carrInfo[loop0],currAppCarrCfg,&index); /*与上次配置相比较，add hold */
        if(index == 0xff) /*add*/
        {
            ret = BspHalAdaptGetPreAllocCarrMapResult(appCarrCfg->carrInfo[loop0],preAllocBwInfo,&preAllocResult);
            dbgInfoEx("carrNo %d carrMode%d chanNo %d is new add\n",appCarrCfg->carrInfo[loop0].carrNo,appCarrCfg->carrInfo[loop0].radioMode,appCarrCfg->carrInfo[loop0].chanNo);
            (void)memcpy_s(presetCarrMapRet->chanCarrMapRet.preAllocResult[loop1],sizeof(T_PreAllocCarrResult),preAllocResult,sizeof(T_PreAllocCarrResult));
            presetCarrMapRet->chanCarrMapRet.carrNum++;
        }
        else/*hold或者change*/
        {
            dbgInfoEx("carrNo %d carrMode%d chanNo %d is hold or change\n",appCarrCfg->carrInfo[loop0].carrNo,appCarrCfg->carrInfo[loop0].radioMode,appCarrCfg->carrInfo[loop0].chanNo);
        }
#endif
    }

    return ret;
}

UINT32 BspInitCarrMapHelpInfo(T_AllCarrMapHelpInfo* carrMapHelpInfo, T_BspHalAdaptPreAllocCarrInfo* preAllocBwInfo,
        T_BspHalAdaptAllChanCarrMapRet* charCarrMapInfo)
{
    INPUT_POINTER_CHECK(carrMapHelpInfo);
    INPUT_POINTER_CHECK(preAllocBwInfo);
    INPUT_POINTER_CHECK(charCarrMapInfo);

    carrMapHelpInfo->preSence = preAllocBwInfo->senceType;
    carrMapHelpInfo->maxNrCarrNum =  preAllocBwInfo->preAllocInfo[0].uAntNum; //nr最大载波数
    carrMapHelpInfo->maxLteCarrNum = preAllocBwInfo->preAllocInfo[1].uAntNum; //lte最大载波数

    carrMapHelpInfo->nrCarrNum = 0;
    carrMapHelpInfo->lteCarrNum = 0;
    carrMapHelpInfo->nrCarrNoMapNum = 0;   /* NR 载波未映射的数量  */
    carrMapHelpInfo->lteCarrNoMapNum = 0;  /* LTE 载波未映射的数量 */

    return BSP_OK;
}

/****************************************************************
* 函数名称: BspPreAllocPreAnalysisUsingChanCarrCfg
* 函数说明：根据当前的载波配置信息，进行场景预分析
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspPreAllocPreAnalysisUsingCarrCfg(T_BspHalAdaptAllCellCarrInfo* appCarrCfg, T_BspHalAdaptPreAllocCarrInfo* boardPreAlloc,UINT32 rruType,
                                            T_AllChanCarrMapInfo* effectCarrMapRet, T_AllChanCarrMapInfo* presetCarrMapRet)
{
    /* BOOL isFirstPreset = FALSE; */
    UINT32 preAllocStatus = 0;
    T_BspHalAdaptPreAllocCarrInfo* effectPreAlloc = NULL; /* 已生效的场景 */
    T_BspHalAdaptPreAllocCarrInfo* outAnalysisPreAlloc = NULL; /* 分析后的场景 */
    T_BspPreSenceAllocCarrInfo presetCfg = {0};
    T_BspHalAdaptPreAllocCarrInfo* usePreAllocCarrInfo = NULL;

    INPUT_POINTER_CHECK(appCarrCfg);
    INPUT_POINTER_CHECK(presetCarrMapRet);

    if (effectCarrMapRet == NULL) {
        /* isFirstPreset = TRUE; */
    } else {
        effectPreAlloc = &effectCarrMapRet->preAllocCarrInfo;
    }

    /* 将下发配置转换为HAL使用结构  删除掉lv处于del状态的载波*/
    (void)BspConvAppChanCarrCfgInfo(appCarrCfg,rruType, &presetCfg);
    /* 根据下发配置，进行场景预置分析 */
    if (BspPreAllocAnalysis(&presetCfg, effectPreAlloc, boardPreAlloc, &outAnalysisPreAlloc, &preAllocStatus) != BSP_OK) {
        dbgErr("Exec BspPreAllocPreAnalysisUsingChanCarrCfg->BspPreAllocAnalysis error\n");
        return BSP_ERROR;
    }

    if (preAllocStatus == PRE_ALLOC_TYPE_NOT_SUPPORT) {
       // usePreAllocBwInfo = &presetCfg;
        dbgErr("preAlloc failed ! preCfgRet :%d ([0:SUPPORT 1:CHG_CARR 2:CHG_SCENE 3:NOT_SUPPORT])",preAllocStatus);
          return BSP_ERROR;  //场景预制失败，直接返回，高层报错，认为此时场景不支持 和4.0对比有差异
    } else {
        usePreAllocCarrInfo = outAnalysisPreAlloc;
    }
#if 0
    /* 载波映射初始化 */
      if (BspInitCarrMapHelpInfo(&carrMapHelpInfo, usePreAllocBwInfo,
          &presetCarrMapRet->chanCarrMapRet, preAllocMapCarrStatus, BSP_PRE_ALLOC_MAX_BAND_NUM) != BSP_OK) {
          dbgErr("Exec BspPreAllocPreAnalysisUsingChanCarrCfg->BspInitCarrMapHelpInfo error\n");
          return BSP_ERROR;
      }
      /* old 载波映射复制到 new 载波映射区 */
      if (preAllocStatus == PRE_ALLOC_TYPE_SUPPORT && isFirstPreset != TRUE) {
          (void)BspSetCarrMapHelpMapRetInfo(&carrMapHelpInfo, &effectCarrMapRet->chanCarrMapRet, appCarrCfg->carrInfo, appCarrCfg->carrNum);
      }
    /* 进行载波映射处理,funclib从hal查询分配的结果，不再自己记录维护资源占用的位置 */
    if (BspCarrMapAnalysisHanlder(appCarrCfg,usePreAllocBwInfo, presetCarrMapRet) != BSP_OK) {
        dbgErr("Exec BspPreAllocPreAnalysisUsingChanCarrCfg->BspCarrMapAnalysisHanlder error\n");
        return BSP_ERROR;
    }
#endif
    (void)memcpy_s(&presetCarrMapRet->preAllocCarrInfo, sizeof(T_BspHalAdaptPreAllocCarrInfo), usePreAllocCarrInfo, sizeof(T_BspHalAdaptPreAllocCarrInfo));
    if (presetCarrMapRet->chanCarrMapRet.carrNum != 0 && preAllocStatus == PRE_ALLOC_TYPE_SUPPORT) {
        presetCarrMapRet->preCfgRet = PRE_ALLOC_TYPE_CHG_CARR;
    } else {
        presetCarrMapRet->preCfgRet = preAllocStatus;
    }
    if((presetCarrMapRet->preAllocCarrInfo.senceType == TDDFDD_PREALLOC_SENCE) || (presetCarrMapRet->preAllocCarrInfo.senceType == TDDFDD_PREALLOC_SENCE_TLTE_IF1)) /*默认传250ns*/
    {
        (VOID)BspHalAdaptSetTaMode(E_OPT_TA_Mode25);
    }
    dbgInfo("preCfgRet:%d ([0:SUPPORT 1:CHG_CARR 2:CHG_SCENE 3:NOT_SUPPORT])\n",presetCarrMapRet->preCfgRet);
    return BSP_OK;
}

/****************************************************************
* 函数名称: BspGetAllCarrMapInfo
* 函数说明：获取已生效的载波映射信息,第一次是空
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspGetAllCarrMapInfo(T_AllChanCarrMapInfo** carrMapInfo)
{
    INPUT_POINTER_CHECK(carrMapInfo);

    if(gs_currAllCarrMapInfo.isFirstPreset != 0)
    {
        *carrMapInfo = &gs_currAllCarrMapInfo;  //上一次生效的载波映射
    }
    return BSP_OK;
}

UINT32 BspUpdatePreAllocResultUsingCarrNo(UINT32 carrNo, UINT32 radioMode,UINT32 chanNo, T_PreAllocResult* preAllocResult)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(preAllocResult);
    for (loop = 0; loop < preAllocResult->carrNum; loop++) {
        if ((preAllocResult->preAllocResult[loop].carrNo == carrNo) &&
            (preAllocResult->preAllocResult[loop].radioMode == radioMode)&&(preAllocResult->preAllocResult[loop].txChanMask == chanNo)) {
            break;
        }
    }
    if (loop >= PRE_ALLOC_CARR_MAX_NUM) { /*后续此处还要修改*/
        dbgErr("Exec BspGetPreAllocResultIndexUsingCarrNo Error, can't find avaliable position\n");
        return BSP_ERROR;
    }
    if (loop >= preAllocResult->carrNum) {
        preAllocResult->carrNum++;
    }
    preAllocResult->preAllocResult[loop].carrNo = carrNo;
    preAllocResult->preAllocResult[loop].radioMode = radioMode;
    preAllocResult->preAllocResult[loop].txChanMask = chanNo;
    dbgInfo("[%d] carr exchange carrNo[%d] radioMode[%d] chanNo[%d]\n", loop,
                preAllocResult->preAllocResult[loop].carrNo,
                preAllocResult->preAllocResult[loop].radioMode,preAllocResult->preAllocResult[loop].txChanMask);

    return BSP_OK;
}

UINT32 BspCalcPreAllocAndCarrMapRet(T_AllChanCarrMapInfo* newCarrMapInfo, T_PreAllocResult* preAllocResult)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK(newCarrMapInfo);
    INPUT_POINTER_CHECK(preAllocResult);

    if (newCarrMapInfo->preCfgRet  > preAllocResult->preCfgRet) {
        preAllocResult->preCfgRet = newCarrMapInfo->preCfgRet;
    }
    /* 只需要将载波交换的信息返回 */
    if (preAllocResult->preCfgRet > PRE_ALLOC_TYPE_CHG_CARR) {
        return BSP_OK;
    }
    /* 将交换状态载波返回 */
    for (loop = 0; loop < newCarrMapInfo->chanCarrMapRet.carrNum; loop++) {
            if(BspUpdatePreAllocResultUsingCarrNo(newCarrMapInfo->chanCarrMapRet.preAllocResult[loop].carrNo,
                                                        newCarrMapInfo->chanCarrMapRet.preAllocResult[loop].radioMode, newCarrMapInfo->chanCarrMapRet.preAllocResult[loop].txChanMask,preAllocResult)) {
                dbgErr("Exec BspCalcPreAllocAndCarrMapRet->BspUpdatePreAllocResultUsingCarrNo error carrNo [%u], radioMode [%x]\n",
                        newCarrMapInfo->chanCarrMapRet.preAllocResult[loop].carrNo,
                        newCarrMapInfo->chanCarrMapRet.preAllocResult[loop].radioMode);
                return BSP_ERROR;
            }
    }
    return BSP_OK;
}
/****************************************************************
* 函数名称: BspCarrMapPreAnalysis
* 函数说明：场景分析 载波交换分析
* 输入参数：carrCfgInfo: lv载波信息　outCarrMapInfo: 分析结果　preAllocResult: 场景状态、交换的载波信息
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
* 创建
*****************************************************************/
UINT32 BspCarrMapPreAnalysis(T_BspHalAdaptAllCellCarrInfo* carrCfgInfo, UINT32 dir,T_AllChanCarrMapInfo* outCarrMapInfo, T_PreAllocResult* preAllocResult)
{
    T_BspHalAdaptPreAllocCarrInfo *boardPreAlloc = NULL;
    T_AllChanCarrMapInfo* carrMapInfo = NULL;
    UINT32 rruType = 0;
    UINT32 ulRet   = BSP_OK;

    INPUT_POINTER_CHECK(carrCfgInfo);
    INPUT_POINTER_CHECK(outCarrMapInfo);
    INPUT_POINTER_CHECK(preAllocResult);

    /* 根据单板信息预制的场景*/
    ulRet = BspGetBoardPreAllocInfo(&boardPreAlloc,&rruType);
    if(ulRet != BSP_OK)
    {
        dbgErr("BspGetBoardPreAllocInfo error \n");
    }
    /* 找到当前生效的载波映射,第一次无生效的数据 */
    (void)BspGetAllCarrMapInfo(&carrMapInfo); /*TDD机型需要考虑载波映射*/
    /* 场景预分析和载波映射 */
    if (BspPreAllocPreAnalysisUsingCarrCfg(carrCfgInfo, boardPreAlloc,rruType, carrMapInfo, outCarrMapInfo) != BSP_OK) {
        dbgErr("Exec BspChanGroupCarrMapPreAnalysis->BspPreAllocPreAnalysisUsingChanCarrCfg error\n");
        return BSP_ERROR;
    }
    /* 上报载波映射结果，返回消息 */
    if (BspCalcPreAllocAndCarrMapRet(outCarrMapInfo, preAllocResult) != BSP_OK) {
        dbgErr("Exec BspChanGroupCarrMapPreAnalysis->BspCalcPreAllocAndCarrMapRet error\n");
        return BSP_ERROR;
    }
    return BSP_OK;
}


/*设置UMTS载波复制接口*/
UINT32 BspSet8TFddUmtsVirCellFlag(UINT32 isVirCell)
{
    return BspHalAdaptSetFddUmtsVirCellFlag(isVirCell);
}


void BspInitAllCarrMapInfo()
{
    (void)memset_s(&gs_AllCarrMapInfo, sizeof(T_AllChanCarrMapInfo), 0, sizeof(T_AllChanCarrMapInfo));
}
void BspInitCurrAllCarrMapInfo()
{
    (void)memset_s(&gs_currAllCarrMapInfo, sizeof(gs_currAllCarrMapInfo), 0, sizeof(T_AllChanCarrMapInfo));
}


static UINT32 BspIsNeedCfgPreAlloc(UINT32 trx, T_BspHalAdaptPreAllocCarrInfo* preAlloc)
{
    T_AllChanCarrMapInfo* carrMapInfo = NULL;

    if (preAlloc == (T_BspHalAdaptPreAllocCarrInfo*)NULL)
    {
        return NO_NEED_CFG_STATUS;
    }
    /* 获取本次已配置的场景 */
    if (BspGetAllCarrMapInfo(&carrMapInfo) != BSP_OK)
    {
        return NEED_CFG_STATUS;
    }
    /*上电第一次没有已经生效的场景*/
    if (carrMapInfo == (T_AllChanCarrMapInfo*)NULL)
    {
        return NEED_CFG_STATUS;
    }

    /* 比较2种场景配置是否一样 */
    if (preAlloc->senceType!= carrMapInfo->preAllocCarrInfo.senceType)
    {
        return NEED_CFG_STATUS;
    }

    return NO_NEED_CFG_STATUS;
}

/****************************************************************
* 函数名称: BspActivatePresetCarrMapCfg
* 函数说明：激活场景映射
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspActivatePresetCarrMapCfg()
{
    T_AllChanCarrMapInfo* carrMapInfo = NULL;
    T_BspHalAdaptAllChanCarrMapRet chanCarrMap = {0};
    T_BspHalAdaptPreAllocCarrInfo  preAlloc = {0};
    T_BspHalAdaptPreAllocCarrInfo* preAllowCarrInfo = NULL;

    if (g_isSuccessPreAlloc != TRUE)
    {
        dbgErr("please invoke BspOamCellPreAlloc before invoking remap\n");
        return BSP_ERROR;
    }
    carrMapInfo = &gs_AllCarrMapInfo;
    preAllowCarrInfo = &carrMapInfo->preAllocCarrInfo;
    chanCarrMap = carrMapInfo->chanCarrMapRet;
    (void)memcpy_s(&preAlloc, sizeof(T_BspHalAdaptPreAllocCarrInfo), preAllowCarrInfo, sizeof(T_BspHalAdaptPreAllocCarrInfo));
    if(carrMapInfo->preCfgRet > PRE_ALLOC_TYPE_CHG_CARR){/*场景切换*/
        if (BspHalAdaptCfgPreAllocSence(&preAlloc) != BSP_OK) {
            dbgErr("Exec BspActivatePresetCarrMapCfg->BspIcHalAdaptCfgPreAllocSence error\n");
            return BSP_ERROR;
        }
        /* 分配TDM前，先打开中频未使用资源静态门控 */
        (VOID)BspHalAdaptDifUnuseResGateCtrl(TX, SWITCH_ON);
        (VOID)BspHalAdaptDifUnuseResGateCtrl(RX, SWITCH_ON);
        if(BspHalAdaptTdmMapCfg()!= BSP_OK)/*通知中频进行了场景切换*/
        {
            dbgErr("BspHalAdaptTdmMapCfg error\n");
            return BSP_ERROR;
        }

        /* 分配TDM后，关闭中频未使用资源静态门控 */
        (VOID)BspHalAdaptDifUnuseResGateCtrl(TX, SWITCH_OFF);
        (VOID)BspHalAdaptDifUnuseResGateCtrl(RX, SWITCH_OFF);
    }
    else if(carrMapInfo->preCfgRet == PRE_ALLOC_TYPE_CHG_CARR)/*场景不切换　载波交换*/
    {
        if (BspHalAdaptCfgPreAllocCarrMap(&chanCarrMap, 1) != BSP_OK) {
            dbgErr("Exec BspActivatePresetCarrMapCfg->BspIcHalAdaptCfgPreAllocCarrMap error\n");
            return BSP_ERROR;
        }
    }
    else
    {
        dbgInfo("curr AllocSence is support, not need cfg\n");
    }

    dbgInfo("Config PreAlloc is finished,Chose Hal SenceNo [%u]\r\n",preAllowCarrInfo->senceType);
    BspLog(LOG_LEVEL_0,"Config PreAlloc is finished, Index [%u]\r\n",  preAllowCarrInfo->senceType);

    /* 使用场景预置分配资源为TRUE */
    BspSetUsePreAllocSw(1);
    gs_AllCarrMapInfo.isFirstPreset = 1;
    /* 更新最新的载波映射信息 */
    (void)memcpy_s(&gs_lastAllCarrMapInfo, sizeof(T_AllChanCarrMapInfo), &gs_currAllCarrMapInfo, sizeof(T_AllChanCarrMapInfo));
    (void)memcpy_s(&gs_currAllCarrMapInfo, sizeof(T_AllChanCarrMapInfo), &gs_AllCarrMapInfo, sizeof(T_AllChanCarrMapInfo));

    return BSP_OK;
}

/****************************************************************
* 函数名称: BspOamPreAllocReMap
* 函数说明：重配载波映射
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
*     10294055   创建
*
*****************************************************************/
UINT32 BspOamPreAllocReMap(UINT32 preRet)
{
    BspLog(LOG_LEVEL_0,"%s enter. preRet:%d\n",__FUNCTION__, preRet);

    return BspActivatePresetCarrMapCfg();
}

/****************************************************************
* 函数名称: BspOamCellPreAlloc
* 函数说明：场景预分析
* 输入参数：cfgInfo:下发的载波配置信息   preAllocResult:　场景切换、不变、载波交换，以及载波交换的载波信息
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
* 4.2上场景预制资源分配判断条件中包含子载波间隔和IF类型，现有接口中高层下发的配置不包含这些信息，和高层及IC讨论，暂时先不考虑这些，对高层可能需要新增接口下发
 *上下行资源对称，不再区分上下行进行处理
 *和4.0不同，RRU下发的T_DestCarrInfoAllChans有GUN载波信息，配频预分析用的也是这个结构体，需要过滤掉
 *TDD时分，不可能存在1T2R这种场景，只有FDD2T 4T有 还存在1发2收 收发隔离 还存在只发不收 交叉分集只有GUN有不影响场景预制,FDD在4.2上没有场景预制
*****************************************************************/
UINT32 BspOamCellPreAlloc(T_DestCarrInfoAllChans* cfgInfo, T_PreAllocResult* preAllocResult)
{
    T_BspHalAdaptAllCellCarrInfo appCarrCfgInfo = {0}; /* 下发的载波配置信息 */
    T_AllChanCarrMapInfo* presetMapInfo = NULL; /* 保存当前下发的载波映射信息 */

    INPUT_POINTER_CHECK(cfgInfo);
    INPUT_POINTER_CHECK(preAllocResult);

    /* 高层下发的载波信息加入bsplog.txt */
    DbgRecordAppCarrInfo(cfgInfo);
    /* 维测，记录最近一次高层下发预置全量载波信息，版本稳定后可删除 */
    saveAppPreAllocInfo(cfgInfo);

    g_isSuccessPreAlloc = FALSE;
    BspInitAllCarrMapInfo();
    (void)memset_s(preAllocResult, sizeof(T_PreAllocResult), 0, sizeof(T_PreAllocResult));

    /* 根据获取本次所有载波配置信息 把GUN载波信息过滤掉 */
    if(BspGetNrAndLteCarrCfgInfo(cfgInfo->txCarrInfo, cfgInfo->txChanNum, &appCarrCfgInfo) != BSP_OK) {
        dbgErr(">>BspOamCellPreAlloc error, carrinfo is invalid\r\n");
        return BSP_ERROR;
    }
    if(s_preallocdbgPrnSw)
    {
        PrnCellCarrInfo(&appCarrCfgInfo);
    }
    presetMapInfo = &gs_AllCarrMapInfo;
    if (BspCarrMapPreAnalysis(&appCarrCfgInfo, TX, presetMapInfo, preAllocResult) != BSP_OK) {
        dbgErr(">>BspOamCellPreAlloc error, carr map failed\r\n");
        return BSP_ERROR;
    }

    g_isSuccessPreAlloc = TRUE;
    /* 保存最近一次的预置结果 */
    saveAppPreAllocResult(preAllocResult);
    /* 预置场景选择及载波映射结果加入bsplog.txt */
    DbgRecordPreAllocInfo(preAllocResult->preCfgRet);
    /* 预置场景选择及载波映射结果打印 */
    BspDoingCarrMapInfoShow();
    /* 预置场景向高层返回的结果及交换载波信息加入bsplog.txt */
    DbgRecordPreAllocResult(preAllocResult);

    return BSP_OK;
}

UINT32 BspGetPreAllocResIndex(UINT32 carrNo, UINT32 radioMode, UINT32 dir, UINT32 chanMask, UINT32* resIndex)
{
#if 0
    UINT32 chanLoop = 0;
    UINT32 loopI = 0;
    T_AllChanCarrMapInfo* chanGroupCarrMapInfo = NULL;
    T_CarrMapRet* carrMapRet = NULL;

    INPUT_POINTER_CHECK(resIndex);
    if (dir == TX) {
        chanGroupCarrMapInfo = &gs_AllCarrMapInfo;
    } else {
        chanGroupCarrMapInfo = &gs_AllCarrMapInfo;
    }

    carrMapRet = chanGroupCarrMapInfo->chanCarrMapRet.carrMapInfo;
    for (loopI = 0; loopI < MAX_CARR_NUM; loopI++) {
        if ((carrMapRet[loopI].validFlag == VALID_CARR_FLAG) &&
        (carrMapRet[loopI].mapFlag == VALID_MAP_FLAG) &&
            (carrMapRet[loopI].carrNo == carrNo) &&
            (carrMapRet[loopI].radioMode == radioMode)) {
            *resIndex = carrMapRet[loopI].optCarrNo;
            return BSP_OK;
        }
    }
    dbgErr("Exec BspGetPreAllocDifCarrNo error, can't find logic carrNo %u [%u]\n", carrNo);
#endif
    return BSP_ERROR;
}
#if 0
UINT32 BspChanMaskUsingChanNo(UINT32 chanNo, UINT32 dir, UINT32* chanMask)
{
    UINT32 loop = 0;
    UINT32 chanNum = 0;
    UINT32* chanMaskArr = NULL;
    INPUT_POINTER_CHECK(chanMask);
    if (dir == TX) {
        chanNum = gs_chanMaskInfo.txChanMaskNum;
        chanMaskArr = &gs_chanMaskInfo.txChanMaskInfo[0];
    } else {
        chanNum = gs_chanMaskInfo.rxChanMaskNum;
        chanMaskArr = &gs_chanMaskInfo.rxChanMaskInfo[0];
    }
    for (loop = 0; loop < chanNum; loop++) {
        if (*(chanMaskArr + loop) & (0x1 << chanNo)) {
            *chanMask = *(chanMaskArr + loop);
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}
//4.2 中频资源足够，没有场景预制，资源分配不和光口预制关联，不需要此接口
UINT32 BspGetPreAllocDifCarrNo(UINT32 dir, UINT32 difChan, UINT32 radioMode, UINT32 carrNo, UINT32* difCarrNo)
{
    UINT32 chanMask = 0;
    if (BspChanMaskUsingChanNo(difChan, dir, &chanMask) != BSP_OK) {
        dbgErr("Exec BspGetPreAllocDifCarrNo->BspChanMaskUsingChanNo error, get chan mask failed diffChan [%d], dir[%d]\n", difChan, dir);
        return BSP_ERROR;
    }
    return BspGetPreAllocResIndex(carrNo, radioMode, dir, chanMask, difCarrNo);
}
#endif
/****************************************************************
* 函数名称: BspClrPreAlloc
* 函数说明：场景切换时资源回收
* 输入参数：
* 输出参数：
* 返回参数：BSP_OK,  BSP_ERROR
* 修改说明：
* 创建
*****************************************************************/
UINT32 BspClrPreAlloc(void)
{
    BspLog(LOG_LEVEL_0,"%s happened!\n", __FUNCTION__);

    (VOID)BspHalAdaptClrPreAlloc();
    (VOID)BspHalAdaptResourceAllocClr(TX);
    (VOID)BspHalAdaptResourceAllocClr(RX);
    return BSP_OK;
}
UINT32 BspClrAllPreAllocSource(VOID)
{
    BspLog(LOG_LEVEL_0,"%s happened!\n", __FUNCTION__);

    (VOID)BspHalAdaptClrPreAlloc();   /*光口资源*/

    BspDlyDlDtxOutSelDataSaveAndOff();
    (VOID)BspHalAdaptDtxClrAllRoute();

    (VOID)BspHalAdaptResourceAllocClr(TX);  /*中频资源*/
    (VOID)BspHalAdaptResourceAllocClr(RX);
    (VOID)BspInitCurrAllCarrMapInfo();
    (VOID)BspClearTxRxRfCfg();    /*清射频大包*/
    BspClrFarmCfg();    /* 清除农网配置 */
    (VOID)BspClrSideFilterNco();  /*清除单边滤波上下行偏置NCO和频点NCO*/

    return BSP_OK;
}
VOID BspSetUsePreAllocSw(UINT32 sw)
{
    g_aUsePreAllocFlg = sw;
}

UINT32 BspIsUsePreAlloc(VOID)
{
    return g_aUsePreAllocFlg;
}

void BspPntPreAllocCfgInfo(T_BspHalAdaptPreAllocCarrInfo* preAllocCarrInfo)
{
    int space = 32;
    int loop = 0;
    if (preAllocCarrInfo == NULL) {
        return ;
    }
    dbgInfo("%8s%2c%4s%2c%4s%2c%6s%2c%6s%2c%6s%2c%6s\n","senceType",space,"radioMode",space,"scs",space,"antNum",space,"ifType"
            ,space,"bandWidth",space,"allocType");
    for(loop = 0; loop < PRE_ALLOC_INFO_TYPE; loop++ )
    {
    // 打印场景预置内容
    dbgInfo("0x%08x%2c%5d%2c%6d%2c%5d%2c%6d%2c%9d%2c%6d\n",
            preAllocCarrInfo->senceType, space, preAllocCarrInfo->preAllocInfo[loop].uMode, space,
            preAllocCarrInfo->preAllocInfo[loop].uScs, space, preAllocCarrInfo->preAllocInfo[loop].uAntNum, space,
            preAllocCarrInfo->preAllocInfo[loop].uIfType, space, preAllocCarrInfo->preAllocInfo[loop].uBw, space,
            preAllocCarrInfo->preAllocInfo[loop].uAllocType);
    }
}


void BspPreAllocCapShow(UINT32 dir)
{
    int loop = 0;
    int space = 32;
    T_BspHalAdaptPreAllocCarrInfo* preAllocBwInfo = NULL;

    if (gs_curPreAllocInfo == NULL) {
        dbgInfo("No Xml PreAlloc Configure\n");
        return ;
    }

    if (dir == TX) {
        preAllocBwInfo = gs_curPreAllocInfo;
        dbgInfo("Tx\n");
    } else {
        preAllocBwInfo = gs_curPreAllocInfo;
        dbgInfo("Rx\n");
    }
    for(loop = 0; loop < PRE_ALLOC_INFO_TYPE; loop++ )
    {
    // 打印场景预置内容
    dbgInfo("0x%08x%2c%5d%2c%6d%2c%6d%2c%6d%2c%6d%2c%6d\n",
        preAllocBwInfo->senceType, space, preAllocBwInfo->preAllocInfo[loop].uMode, space,
        preAllocBwInfo->preAllocInfo[loop].uScs, space, preAllocBwInfo->preAllocInfo[loop].uAntNum, space,
        preAllocBwInfo->preAllocInfo[loop].uIfType, space, preAllocBwInfo->preAllocInfo[loop].uBw, space,
        preAllocBwInfo->preAllocInfo[loop].uAllocType);
    }
 }

void BspPntCarrMapRetInfo(T_CarrMapRet* carrMapRetArr, UINT32 arrNum)
{
    int space = 32;
    int i = 0;
    if (carrMapRetArr == NULL) {
        return ;
    }
    // head
    dbgInfo("%6s%2c%6s%2c%6s%2c%6s%2c%6s%2c%10s%2c%10s%2c%10s\n", "carrNo", space, "Radio", space,
        "Bw", space, "Freq", space, "ResIdx", space, "MapFlg", space, "ChgFlg", space, "chanMask");

    // content
    for (i = 0; i < arrNum; i++) {
        if (carrMapRetArr[i].validFlag == INVALID_MAP_FLAG) {
            continue;
        }
        dbgInfo("%6d%2c%#6x%2c%6d%2c%6d%2c%6d%2c0x%08x%c0x%08x%2c%08x\n", carrMapRetArr[i].carrNo, space,
            carrMapRetArr[i].radioMode, space, carrMapRetArr[i].bandWidth, space,
            carrMapRetArr[i].freq, space, carrMapRetArr[i].optCarrNo, space,
            carrMapRetArr[i].mapFlag, space, carrMapRetArr[i].exchaneFlag, space, carrMapRetArr[i].chanMask);
    }
}

void BspPntPreAllocAndCarrMapInfo(T_AllChanCarrMapInfo* allCarrMapInfo)
{
    T_CarrMapRet*  carrMapRetInfo = NULL;
    T_BspHalAdaptPreAllocCarrInfo* preAllocCarrInfo = NULL;

    preAllocCarrInfo = &allCarrMapInfo->preAllocCarrInfo;
    carrMapRetInfo = (T_CarrMapRet *)allCarrMapInfo->chanCarrMapRet.preAllocResult;
    if (allCarrMapInfo == NULL) {
        return;
    }
    // 打印载波对应的场景信息
    dbgInfo("----------------------------------------------------------------------------------------------------------------\n");
    BspPntPreAllocCfgInfo(preAllocCarrInfo);
    dbgInfo("\n");
    // 打印载波映射结果
    BspPntCarrMapRetInfo(carrMapRetInfo, MAX_ALL_CARR_NUM);
    dbgInfo("\n");
}

void BspCurrCarrMapInfoShow(UINT32 dir)
{
    if (dir == TX) {
        dbgInfo("Print Curr Carr Map Info, TX :\n");
        BspPntPreAllocAndCarrMapInfo(&gs_currAllCarrMapInfo);
    } else {
        dbgInfo("Print Curr Carr Map Info, RX :\n");
        BspPntPreAllocAndCarrMapInfo(&gs_currAllCarrMapInfo);
    }
}

void BspLastCarrMapInfoShow(UINT32 dir)
{
    if (dir == TX) {
        dbgInfo("Print Last Carr Map Info, TX :\n");
        BspPntPreAllocAndCarrMapInfo(&gs_lastAllCarrMapInfo);
    } else {
        dbgInfo("Print Last Carr Map Info, RX :\n");
        BspPntPreAllocAndCarrMapInfo(&gs_lastAllCarrMapInfo);
    }
}

void BspDoingCarrMapInfoShow(void)
{
        dbgInfo("Print Doing Carr Map Info:\n");
        BspPntPreAllocAndCarrMapInfo(&gs_AllCarrMapInfo);
}

/* 用于保存场景预置之后的载波分配情况 */
VOID DbgRecordPreAllocInfo(UINT32 preCfgRet)
{
#if 0
    T_AllChanCarrMapInfo* presetMapInfo = NULL;
    T_CarrMapRet* carrMapRet = NULL;
    UINT32 loopI = 0;
    /* 如果预置成功，则记录当前场景及载波映射结果 */
    if(preCfgRet == 0 || preCfgRet == 1 || preCfgRet == 2 || preCfgRet == 3 )
    {
        /* 为减少log数据量，暂时仅记录天线组0的下行方向的信息 */
        presetMapInfo = &gs_chanGroupCarrMapInfo.txChanGroupCarrMapInfo.chanGroupCarrMapInfo[0].chanGrpCarrMapInfo;

        /* 为减少log数据量，带宽用单位MHz记录 */
        BspLog(LOG_LEVEL_0,"CurPrealloc: index:%d nr:%d lte:%d bw:%d-%d-%d-%d-%d-%d-%d-%d\n",
                    presetMapInfo->preAllocBwInfo.index,
                    presetMapInfo->preAllocBwInfo.nrNum,
                    presetMapInfo->preAllocBwInfo.lteNum,
                    presetMapInfo->preAllocBwInfo.bandWidth[0]/1000,
                    presetMapInfo->preAllocBwInfo.bandWidth[1]/1000,
                    presetMapInfo->preAllocBwInfo.bandWidth[2]/1000,
                    presetMapInfo->preAllocBwInfo.bandWidth[3]/1000,
                    presetMapInfo->preAllocBwInfo.bandWidth[4]/1000,
                    presetMapInfo->preAllocBwInfo.bandWidth[5]/1000,
                    presetMapInfo->preAllocBwInfo.bandWidth[6]/1000,
                    presetMapInfo->preAllocBwInfo.bandWidth[7]/1000
        );
        BspLog(LOG_LEVEL_0,"CarrMap: nr:%d lte:%d [%d-%d],[%d-%d],[%d-%d],[%d-%d],[%d-%d],[%d-%d],[%d-%d],[%d-%d]\n",
                    presetMapInfo->chanCarrMapRet.nrCarrNum,
                    presetMapInfo->chanCarrMapRet.lteCarrNum,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[0].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[0].optCarrNo,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[1].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[1].optCarrNo,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[2].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[2].optCarrNo,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[3].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[3].optCarrNo,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[4].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[4].optCarrNo,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[5].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[5].optCarrNo,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[6].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[6].optCarrNo,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[7].bandWidth/1000,
                    presetMapInfo->chanCarrMapRet.carrMapInfo[7].optCarrNo);

        carrMapRet = presetMapInfo->chanCarrMapRet.carrMapInfo;
        for (loopI = 0; loopI < MAX_CARR_NUM; loopI++)
        {
            if((carrMapRet[loopI].validFlag == VALID_CARR_FLAG) && (carrMapRet[loopI].mapFlag == VALID_MAP_FLAG))
            {
                BspLog(LOG_LEVEL_0,"[%d] carrNo:%d radio:%d freq=%d bw:%d mask:%#x resIdx:%d\n",loopI,
                            carrMapRet[loopI].carrNo,carrMapRet[loopI].radioMode,carrMapRet[loopI].freq,
                            carrMapRet[loopI].bandWidth/1000, carrMapRet[loopI].chanMask,carrMapRet[loopI].optCarrNo);
            }
        }
    }
#  endif
    return;
}

/* 用于保存高层下发的用于场景预置的载波信息  FDD RRU机型包含GUN 所以载波数要以最大载波数16进行记录*/
VOID DbgRecordAppCarrInfo(T_DestCarrInfoAllChans* cfgInfo)
{
    UINT32 chan = 0;

    BspLog(LOG_LEVEL_0,"BspOamCellPreAlloc enter. txChanNum=%d\n", cfgInfo->txChanNum);
    for(chan=0; chan<cfgInfo->txChanNum; chan++)
    {
        BspLog(LOG_LEVEL_0,"AppInfo:[chan%d][%d] %d|%d-%d|%d-%d|%d-%d|%d-%d|%d-%d|%d-%d|%d-%d|%d%d|%d-%d|%d-%d|%d-%d|%d-%d|%d-%d|%d-%d|%d-%d|%d\n",
                    cfgInfo->txCarrInfo[chan].chanNo,
                    cfgInfo->txCarrInfo[chan].carrNum,
                    cfgInfo->txCarrInfo[chan].carrInfo[0].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[0].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[1].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[1].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[2].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[2].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[3].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[3].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[4].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[4].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[5].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[5].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[6].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[6].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[7].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[7].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[8].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[8].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[9].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[9].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[10].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[10].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[11].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[11].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[12].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[12].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[13].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[13].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[14].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[14].bandWidth/1000,
                    cfgInfo->txCarrInfo[chan].carrInfo[15].carrNo,
                    cfgInfo->txCarrInfo[chan].carrInfo[15].bandWidth/1000
                    );
    }
    return;
}

/* 用于保存场景预置后向高层返回的预置结果及交换载波信息 */
VOID DbgRecordPreAllocResult(T_PreAllocResult* preAllocResult)
{
    UINT32 loop = 0;
    for(loop=0;loop<preAllocResult->carrNum;loop++)
    {
        BspLog(LOG_LEVEL_0,"ExchangeCarr: CarrNo:%d chanMask:%#x radio:%d\n",
                preAllocResult->preAllocResult[loop].carrNo,
                preAllocResult->preAllocResult[loop].txChanMask,
                preAllocResult->preAllocResult[loop].radioMode);
    }
    BspLog(LOG_LEVEL_0,"BspOamCellPreAlloc exit. result:%d carrNum:%d\n", preAllocResult->preCfgRet, preAllocResult->carrNum);
    return;
}

void tstBspCellPreAlloc()
{
    int i = 0;
    T_DestCarrInfoAllChans *allChanCfgs = NULL;
    T_PreAllocResult   preAllocRet = {0};

    allChanCfgs = (T_DestCarrInfoAllChans *)malloc(sizeof(T_DestCarrInfoAllChans));
    if (allChanCfgs == NULL)
    {
        return;
    }
    memset_s(allChanCfgs, sizeof(T_DestCarrInfoAllChans), 0, sizeof(T_DestCarrInfoAllChans));
    allChanCfgs->txChanNum = 4;
    allChanCfgs->rxChanNum = 4;

    for (i = 0; i < allChanCfgs->txChanNum; i++) {
        allChanCfgs->txCarrInfo[i].chanNo = i;
        allChanCfgs->txCarrInfo[i].carrNum = 3;
        allChanCfgs->txCarrInfo[i].carrInfo[0].carrNo = 0;
        allChanCfgs->txCarrInfo[i].carrInfo[0].radioMode = RADIO_STANDARD_5G;
        allChanCfgs->txCarrInfo[i].carrInfo[0].freq = 2700000;
        allChanCfgs->txCarrInfo[i].carrInfo[0].bandWidth = 100000;

        allChanCfgs->txCarrInfo[i].carrInfo[1].carrNo = 1;
        allChanCfgs->txCarrInfo[i].carrInfo[1].radioMode = RADIO_STANDARD_5G;
        allChanCfgs->txCarrInfo[i].carrInfo[1].freq = 2700000;
        allChanCfgs->txCarrInfo[i].carrInfo[1].bandWidth = 60000;

        allChanCfgs->txCarrInfo[i].carrInfo[2].carrNo = 3;
        allChanCfgs->txCarrInfo[i].carrInfo[2].radioMode = RADIO_STANDARD_LTE_TDD;
        allChanCfgs->txCarrInfo[i].carrInfo[2].freq = 2700000;
        allChanCfgs->txCarrInfo[i].carrInfo[2].bandWidth = 20000;
    }
    for (i = 0; i < allChanCfgs->rxChanNum; i++) {
        allChanCfgs->rxCarrInfo[i].chanNo = i;
        allChanCfgs->rxCarrInfo[i].carrNum = 3;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].carrNo = 0;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].radioMode = RADIO_STANDARD_5G;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].freq = 2700000;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].bandWidth = 100000;

        allChanCfgs->rxCarrInfo[i].carrInfo[1].carrNo = 1;
        allChanCfgs->rxCarrInfo[i].carrInfo[1].radioMode = RADIO_STANDARD_5G;
        allChanCfgs->rxCarrInfo[i].carrInfo[1].freq = 2700000;
        allChanCfgs->rxCarrInfo[i].carrInfo[1].bandWidth = 60000;

        allChanCfgs->rxCarrInfo[i].carrInfo[2].carrNo = 4;
        allChanCfgs->rxCarrInfo[i].carrInfo[2].radioMode = RADIO_STANDARD_LTE_TDD;
        allChanCfgs->rxCarrInfo[i].carrInfo[2].freq = 2700000;
        allChanCfgs->rxCarrInfo[i].carrInfo[2].bandWidth = 20000;
    }
    /* 场景预分析 */
    if (BspOamCellPreAlloc(allChanCfgs, &preAllocRet) != BSP_OK) {
        free(allChanCfgs);
        dbgErr("BspOamCellPreAlloc error\n");
        return;
    }
    free(allChanCfgs);
    dbgInfo("PreAllocRet : %u, exchange carrNum:%u\n", preAllocRet.preCfgRet, preAllocRet.carrNum);
    for (i = 0; i < preAllocRet.carrNum; i++) {
        dbgInfo("carrNo: %u, radio: 0x%8x, txMask: 0x%8x, rxMask: 0x%8x\n", preAllocRet.preAllocResult[i].carrNo,
            preAllocRet.preAllocResult[i].radioMode, preAllocRet.preAllocResult[i].txChanMask, preAllocRet.preAllocResult[i].rxChanMask);
    }

    /* 场景预分析重配 */
    if(preAllocRet.preCfgRet)
    {
        BspHalAdaptClrPreAlloc();
    }
    BspOamPreAllocReMap(preAllocRet.preCfgRet);
}

void tstBspCellPreAllocNr100M()
{
    int i = 0;
    T_DestCarrInfoAllChans *allChanCfgs = NULL;
    T_PreAllocResult   preAllocRet = {0};

    allChanCfgs = (T_DestCarrInfoAllChans *)malloc(sizeof(T_DestCarrInfoAllChans));
    if (allChanCfgs == NULL)
    {
        return;
    }
    memset_s(allChanCfgs, sizeof(T_DestCarrInfoAllChans), 0, sizeof(T_DestCarrInfoAllChans));
#ifdef FUNCLIB_ADS
    allChanCfgs->txChanNum = 1;
    allChanCfgs->rxChanNum = 1;
#else
    allChanCfgs->txChanNum = 32;
    allChanCfgs->rxChanNum = 32;
#endif

    for (i = 0; i < allChanCfgs->txChanNum; i++) {
        allChanCfgs->txCarrInfo[i].chanNo = i;
        allChanCfgs->txCarrInfo[i].carrNum = 1;
        allChanCfgs->txCarrInfo[i].carrInfo[0].carrNo = 0;
        allChanCfgs->txCarrInfo[i].carrInfo[0].radioMode = RADIO_STANDARD_5G;
        allChanCfgs->txCarrInfo[i].carrInfo[0].freq = 2700000;
        allChanCfgs->txCarrInfo[i].carrInfo[0].bandWidth = 100000;

    }
    for (i = 0; i < allChanCfgs->rxChanNum; i++) {
        allChanCfgs->rxCarrInfo[i].chanNo = i;
        allChanCfgs->rxCarrInfo[i].carrNum = 1;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].carrNo = 0;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].radioMode = RADIO_STANDARD_5G;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].freq = 2700000;
        allChanCfgs->rxCarrInfo[i].carrInfo[0].bandWidth = 100000;

    }
    /* 场景预分析 */
    if (BspOamCellPreAlloc(allChanCfgs, &preAllocRet) != BSP_OK) {
        free(allChanCfgs);
        dbgErr("BspOamCellPreAlloc error\n");
        return;
    }
    free(allChanCfgs);
    dbgInfo("PreAllocRet : %u, exchange carrNum:%u\n", preAllocRet.preCfgRet, preAllocRet.carrNum);
    for (i = 0; i < preAllocRet.carrNum; i++) {
        dbgInfo("carrNo: %u, radio: 0x%8x, txMask: 0x%8x, rxMask: 0x%8x\n", preAllocRet.preAllocResult[i].carrNo,
            preAllocRet.preAllocResult[i].radioMode, preAllocRet.preAllocResult[i].txChanMask, preAllocRet.preAllocResult[i].rxChanMask);
    }

    /* 场景预分析重配 */
    if(preAllocRet.preCfgRet)
    {
        BspHalAdaptClrPreAlloc();
    }
    BspOamPreAllocReMap(preAllocRet.preCfgRet);
}

static T_DestCarrInfoAllChans *BspGetDbgPreAllocInfoMem(void)
{
    if (s_dbgPreAllocInfo == NULL)
    {
        s_dbgPreAllocInfo = (T_DestCarrInfoAllChans *)malloc(sizeof(T_DestCarrInfoAllChans));
        if (s_dbgPreAllocInfo == NULL)
        {
            return NULL;
        }
        zte_memset_s(s_dbgPreAllocInfo, sizeof(T_DestCarrInfoAllChans), 0, sizeof(T_DestCarrInfoAllChans));
    }
    return s_dbgPreAllocInfo;
}

static UINT32 saveAppPreAllocInfo(T_DestCarrInfoAllChans *info)
{
    T_DestCarrInfoAllChans *dbgPreAllocInfo = BspGetDbgPreAllocInfoMem();
    INPUT_POINTER_CHECK(dbgPreAllocInfo);
    memset(dbgPreAllocInfo, 0, sizeof(T_DestCarrInfoAllChans));
    memcpy_s(dbgPreAllocInfo, sizeof(T_DestCarrInfoAllChans), info, sizeof(T_DestCarrInfoAllChans));
    return BSP_OK;
}
static UINT32 saveAppPreAllocResult(T_PreAllocResult *result)
{
    memset(&s_dbgPreAllocResult, 0, sizeof(T_PreAllocResult));
    memcpy_s(&s_dbgPreAllocResult, sizeof(T_PreAllocResult), result, sizeof(T_PreAllocResult));
    return BSP_OK;
}

UINT32 showapppreallocresult(VOID)
{
    UINT32 carr = 0;

    dbgInfo("PREALLOC RESULT = \n");
    dbgInfo("preCfgRet=%d\n", s_dbgPreAllocResult.preCfgRet);
    dbgInfo("carrNum=%d\n", s_dbgPreAllocResult.carrNum);

    for(carr=0; carr<s_dbgPreAllocResult.carrNum; carr++)
    {
        dbgInfo(" ----  carr%d start ---- \n",carr);
        dbgInfo("    carrNo=%d\n",s_dbgPreAllocResult.preAllocResult[carr].carrNo);
        dbgInfo("    radioMode=%d\n",s_dbgPreAllocResult.preAllocResult[carr].radioMode);
        dbgInfo("    txChanMask=%d\n",s_dbgPreAllocResult.preAllocResult[carr].txChanMask);
        dbgInfo(" ----  carr%d   end---- \n",carr);
    }

    return BSP_OK;
}

static UINT32 showappprealloc(UINT32 dir, UINT32 chan)
{
    UINT32 loopCarr = 0;
    T_DestCarrInfoChan *pChanCarrInfo = NULL;
    UINT32 loopChan = 0;
    T_DestCarrInfoAllChans *dbgPreAllocInfo = BspGetDbgPreAllocInfoMem();
    INPUT_POINTER_CHECK(dbgPreAllocInfo);

    if(dir >= PRX || chan >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }

    if(TX == dir)
    {
        pChanCarrInfo = dbgPreAllocInfo->txCarrInfo;
    }
    else
    {
        pChanCarrInfo = dbgPreAllocInfo->rxCarrInfo;
    }

    dbgInfo("%s%d(totalChan:%d) PREALLOC INFO is : \n",dir==TX?"TX":"RX",chan,
    dir==TX?dbgPreAllocInfo->txChanNum:dbgPreAllocInfo->rxChanNum);
    for(loopChan=0; loopChan<BSP_MAX_CHAN_NUM; loopChan++)
    {
        if(pChanCarrInfo[loopChan].chanNo == chan && pChanCarrInfo[loopChan].carrNum)
        {
            dbgInfo("carr delOrAddFlag carrId     carrFreq carrBw carrRadio\n");
            for(loopCarr=0;loopCarr<pChanCarrInfo[loopChan].carrNum;loopCarr++)
            {
                dbgInfo("%4d %12d %6d %12d %6d %9d\n",loopCarr,
                pChanCarrInfo[loopChan].carrInfo[loopCarr].delOrAddFlag,
                pChanCarrInfo[loopChan].carrInfo[loopCarr].carrNo,
                pChanCarrInfo[loopChan].carrInfo[loopCarr].freq,
                pChanCarrInfo[loopChan].carrInfo[loopCarr].bandWidth,
                pChanCarrInfo[loopChan].carrInfo[loopCarr].radioMode);
            }
        }
    }

    return BSP_OK;
}

VOID preallochelp(VOID)
{
    UINT32 loopI = 0;
    CHAR*  usage [] = {
        "BspPreAllocCapShow dir TX:1,RX 0  get xml preset scene",
        "BspLastCarrMapInfoShow dir  TX:1,RX 0 get last  effective carrier map info",
        "BspCurrCarrMapInfoShow dir  TX:1,RX 0 get current effective carrier map info",
        "showappprealloc dir,chan",
        "preallocdbgprnswitch sw",
        "showapppreallocresult"
    };
    for (loopI = 0; loopI < sizeof(usage) / sizeof(usage[0]); loopI++)
    {
        dbgInfo("%s\r\n", usage[loopI]);
    }
}

VOID PrnCellCarrInfo(T_BspHalAdaptAllCellCarrInfo *pInfo)
{
    UINT32 loop = 0;

    if(NULL == pInfo || pInfo->carrNum >= MAX_ALL_CARR_NUM)
    {
        dbgErr("input para err! \n");
        return;
    }

    dbgInfo("%s print:\n", __FUNCTION__);
    dbgInfo("-----------------------------------------------\n");
    dbgInfo("carrNum:  %d\n", pInfo->carrNum);
    for(loop=0; loop<pInfo->carrNum; loop++)
    {
        dbgInfo("[%d] carrNo[%d] radioMode[%#x] freq[%d] bandWidth[%d]　chanNo[%d] hold-0/add-1/del-2[%d] \n", loop,
               pInfo->carrInfo[loop].carrNo, pInfo->carrInfo[loop].radioMode,
               pInfo->carrInfo[loop].freq, pInfo->carrInfo[loop].bandWidth,pInfo->carrInfo[loop].chanNo,pInfo->carrInfo[loop].delOrAddFlag);
    }
    dbgInfo("-----------------------------------------------\n");

    return;
}

VOID preallocdbgprnswitch(UINT32 sw)
{
    s_preallocdbgPrnSw = sw;
    return;
}




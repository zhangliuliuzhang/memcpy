/*****************************************************************************
* 版权所有(C) 2015, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : optctrl_ntl_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者   : 10090699
* 创建日期 : 2017-3-2 17:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-3-2 17:26:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_OPTCTRL_NTL_DPDIC4_H_
#define _FUNCLIB_OPTCTRL_NTL_DPDIC4_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "optctrlapi.h"

#define LANEROUTEPATH           "LaneRoutePath"
#define TRYTIMES                "LaneRouteTryTimes"
#define PREFAULTPOS             "PreFaultPos"
#define INDEPENDENTFLAG         "IndependentFlag"
#define DYINGWORDS              "LaneRouteTryDyingWords"
typedef enum{
    LANEROUTEPATH_INDEX = 0,
    TRYTIMES_INDEX,
    PREFAULTPOS_INDEX,
    INDEPENDENTFLAG_INDEX,
    DYINGWORDS_INDEX,
}E_PATH_ROUTE;
#define  SERDES_LANE_DEPENDENT    (1)
#define  SERDES_LANE_INDEPENDENT  (0)

typedef UINT32 (*GetSocLoadStatus)(UINT32 *status);
typedef UINT32 (*GetSocLoadStatusByChipId)(UINT32 chipId, UINT32 *status);
typedef UINT32 (*GetCpriModeLaneRoutePathNo)(UINT32 *path);
typedef UINT32 (*SetCpriModeLaneRoutePathNo)(UINT32 path);
typedef UINT32 (*GetCpriModeLaneRouteTryingTimes)(UINT32 *times);
typedef UINT32 (*SetCpriModeLaneRouteTryingTimes)(UINT32 times);
typedef UINT32 (*GetCpriModeSupportAblity)(UINT32 *ablity);
typedef UINT32 (*GetRstCauseRouteTry)(UINT32 *tryFlag);
typedef UINT32 (*SetRstCauseRouteTry)(UINT32 tryFlag);
typedef UINT32 (*GetPreFaultPos)(UINT32 *faultPos);
typedef UINT32 (*SetPreFaultPos)(UINT32 faultPos);
typedef UINT32 (*GetIndependentFlag)(UINT32 *flag);
typedef UINT32 (*SetIndependentFlag)(UINT32 flag);
typedef UINT32 (*GetCpriModeLaneRouteNewPathNo)(T_AllInnerSerdesDownStatus *innerSerdesDownStatus, UINT32 *newPath);

typedef struct tagT_CpriModeSwitchCfgFunc
{
    UINT32 cpriModeSwitchAblity;
    GetSocLoadStatus                 pGetSlaveSocLoadStatus;
    GetSocLoadStatusByChipId         pGetSocLoadStatusByChipId;
    GetCpriModeLaneRoutePathNo       pGetCpriModeLaneRoutePathNo;
    SetCpriModeLaneRoutePathNo       pSetCpriModeLaneRoutePathNo;
    GetCpriModeLaneRouteTryingTimes  pGetCpriModeLaneRouteTryingTimes;
    SetCpriModeLaneRouteTryingTimes  pSetCpriModeLaneRouteTryingTimes;
    GetRstCauseRouteTry              pGetRstCauseRouteTry;
    SetRstCauseRouteTry              pSetRstCauseRouteTry;
    GetPreFaultPos                   pGetPreFaultPos;
    SetPreFaultPos                   pSetPreFaultPos;
    GetIndependentFlag               pGetIndependentFlag;
    SetIndependentFlag               pSetIndependentFlag;
    GetCpriModeLaneRouteNewPathNo pGetCpriModeLaneRouteNewPathNo;
}T_CpriModeSwitchCfgFunc;

UINT32 BspSetCpriModeSwitchCfgFunc(T_CpriModeSwitchCfgFunc *pCpriModeSwitchCfgFunc);
UINT32 BspSetLaneRoutePara(T_CpriModeLaneRoutePara* tpara, UINT32 num);
UINT32 BspGetOptCpriModePathParaFromRam(T_CpriModeLaneRoutePara* tpara);
UINT32 BspGetCpriModeIndependentFlag(UINT32 *pFlag);
VOID BspRecordCpriModeCurRoutePath(UINT32 laneRoutePath);
UINT32 BspGetCpriModeCurrRoutePath(VOID);
UINT32 BspGetLaneRoutePathFromFlash(UINT32 *path);
UINT32 BspSetLaneRoutePathFromFlash(UINT32 path);
UINT32 BspGetLaneRouteTryingTimesFromFlash(UINT32 *times);
UINT32 BspSetLaneRouteTryingTimesFromFlash(UINT32 times);
UINT32 BspGetRstCauseRouteTryFromFlash(UINT32 *tryFlag);
UINT32 BspSetRstCauseRouteTryFromFlash(UINT32 tryFlag);
UINT32 BspGetPreFaultPosFromFlash(UINT32 *faultPos);
UINT32 BspSetPreFaultPosFromFlash(UINT32 faultPos);
UINT32 BspGetIndependentFlagFromFlash(UINT32 *independentFlag);
UINT32 BspSetIndependentFlagFromFlash(UINT32 independentFlag);
UINT32 BspSetLaneSelfSaveFileFromFlash(UINT32 fieldType, UINT32 value);
UINT32 BspGetLaneSelfSaveFileFromFlash(UINT32 fieldType, UINT32 *value);
T_CpriModeSwitchCfgFunc *BspGetCpriModeSwitchCfgFunc(void);
VOID showlaneroutecurr(VOID);
UINT32 BspGetLaneRoutePath(VOID);
UINT32 BspIndependentLaneSelfSaveFileInit(UINT32 path);

#ifdef __cplusplus
}
#endif
#endif /* _FUNCLIB_OPTCTRL_H_ */




/***************************************************************************** 
* 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardctrl.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板光口相关的头文件
* 注意事项 : 无
* 作    者 : 崔文会
* 创建日期 : 2014-05-12
* 当前版本 : Ver2.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 崔文会
* 修改日戳: 2014-05-12 10:20:16
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "optctrlapi.h"
#ifndef _OPT_ADAPT_H_
#define _OPT_ADAPT_H_

#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************
*                          宏定义		                                  *
**************************************************************************/
enum OPT_STATE{
    OPT_ADPT_PRE_TWO_OPT_STATE,
    OPT_ADPT_TWO_OPT_STATE ,
    OPT_ADPT_POST_TWO_OPT_STATE,
    OPT_ADPT_PRE_ONE_OPT_STATE,
    OPT_ADPT_ONE_OPT_STATE,
    OPT_ADPT_POST_ONE_OPT_STATE,
    OPT_ADPT_STATE_OK,
    OPT_ADPT_STATE_MAX,
};

#define FUNCLIB_OPT_ADPT_ENABLE         1   /*HAL有相同定义*/
#define FUNCLIB_OPT_ADPT_DISABLE        0
#define FUNCLIB_OPT_ADPT_STOP           2
#define OPT_EEPROM_INFO_UPDATE     (0x209)       /* 光模块信息更新掩码，在BspSetSfpInfoUpdateSw中使用，1表示需要实时更新 */
#define TDD_OPT_SPEED_LIST_IR      (0x1000600)
#define TDD_OPT_SPEED_LIST_CPRI    (0x1000620)
#define RRU_IS_LAST_STAGE          (1)
#define IR_CASECADE_CPRI_FLAG      (1)
#define SUPPORT_2BBU_MAIN_SLAVE    (1)
#define NOT_SUPPORT_2BBU_MAIN_SLAVE (0)
#ifndef INPUT_PHYOPT_INDEX_CHECK
/* 物理光口号入参检查*/
#define INPUT_PHYOPT_INDEX_CHECK(optIndex)            \
    if ((optIndex) >= OPTMAXNUM)                       \
    {                                                 \
        return BSP_ERROR;                             \
    }
#endif

#define BSP_SET_ROE_ROATE_ERR_INVALID_OPTNO   1
#define BSP_SET_ROE_ROATE_ERR_INVALID_SPEED   2
#define BSP_SET_ROE_ROATE_ERR_INVALID_AXCNUM  3
#define BSP_SET_ROE_ROATE_ERR_CELL_INIT       4
#define BSP_SET_ROE_ROATE_ERR_CPRI_RATE       5
#define BSP_SET_ROE_ROATE_ERR_CFG_FRMSEL      6
#define BSP_SET_ROE_ROATE_ERR_OPT_STATUS      7
#define AXC_MAX_NUM 192

/**************************************************************************
*                          数据结构		                                  *
**************************************************************************/
typedef struct t_OptAdaptInfo
{
    /* 基础配置 */
    UINT32 ulInited;

    /* 自适应状态的延时时间，单位ms */
    UINT32 ulDelay[OPT_ADPT_STATE_MAX]; 

    /* ms单位的延时函数 */
    void (*pFuncDelayMs)(UINT32 ulDelayMs); 
    /* 自适应状态的防抖检测次数 */
    ULONG ulJitterAvoidTimes4FuncState[OPT_ADPT_STATE_MAX];

    /* 记录上次成功速率 */
    UINT32 (*pFuncSaveOptSpeedRecord)(UINT32 ulPhyOptId,UINT32 ulSpd); 

    /* 读取上次成功速率 */
    UINT32 (*pFuncGetOptSpeedRecord)(UINT32 ulPhyOptId);

    /* 获取RU光模块支持的最大线速率 */
    UINT32 (*pFuncGetOptSfpMaxSpeed)(UINT32 ulPhyOptId); 

    /* 获取RU光口支持的速率列表 */
    UINT32 (*pFuncGetRruOptSurportSpeedList)(VOID);
    /* 获取光口工作组网模式 */
    UINT32 (*pFuncGetOptWorkMode)(UINT32 ulIndex);

    /* 获取RU物理光口当前状态 */
    UINT32 (*pFuncCheckPhyOptState)(UINT32 ulPhyOptId); 
    /* 获取RU逻辑光口当前状态 */
    UINT32 (*pFuncCheckLogicOptState)(UINT32 ulLogOptId);
    /* 获取RU物理光口当前状态是否为LOP */
    UINT32 (*pFuncCheckPhyOptIsLop)(UINT32 ulPhyOptId); 
    /* 获取RU板上系统时钟锁相环锁定状态 */
    UINT32 (*pFuncCheckExtSysClkLockState)(VOID);
    /* 设置自适应预处理 */
    UINT32 (*pFuncOptAdptPreProcess)(UINT32 ulPhyOptId); 

    /* 设置自适应后处理 */
    UINT32 (*pFuncOptAdptPostProcess)(UINT32 ulPhyOptId); 

    /* 判断光口之间速率是否需要保持一致 */
    UINT32 (*pFuncOptSpeedIsEqual)(VOID); 

    /* 配置物理光口速率 */
    UINT32 (*pFuncSetOptSpeed)(UINT32 ulPhyOptId,UINT32  ulSpd);

    /* 配置物理光口对应的RX serdes */
    UINT32 (*pFuncReCfgOptRxSerdes)(UINT32 ulPhyOptId,UINT32 ulSpd);

    /* 获取物理光口速率 */
    UINT32 (*pFuncGetOptSpeed)(UINT32 ulPhyOptId);

    /* 判断光口是否同步 */
    UINT32 (*pFuncOptIsSync)(UINT32 ulPhyOptId);

    /* PA开关控制 */
    UINT32 (*pFuncSetPaSwitchAll)(UINT32 sw);

    /* 获取每个通道的PA开关状态 */
    UINT32 (*pFuncGetPaStatusAll)(UINT32* paStatus);

    /* 恢复每个通道PA开关原先状态 */
    UINT32 (*pFuncSetPaPreStatusAll)(UINT32* paStatus);

    /* 开关mts模拟链路（断数据） */
    UINT32 (*pFuncSetMtsTxlinkSwitch)(UINT32 sw);
} T_OptAdaptInfo;

T_OptAdaptInfo g_tOptAutoAdaptInfo;

typedef VOID (*FUNC_CHECK_RRUIDRANGE)(VOID);
typedef UINT32 (*FUN_CLEAR_CARR_GAIN)(VOID);
typedef VOID (*FUN_SET_BBU_SUPER_FRAMENO)(UINT32 frameNo);
typedef UINT32 (*FUN_COPY_OUTOFPSYNC_PARA_TO_KO)(UINT32 radioMode);
typedef UINT32 (*FUN_SWITCH_SLAVE_OPT_ADAPT_STA)(VOID);
/**************************************************************************
*                          对外接口函数声明		                              *
**************************************************************************/
UINT32 _BspOptAdptThreadInit(void);
UINT32 BspSetM0ThreadStartFlag(UINT32 flag);
UINT32 BspGetM0ThreadStartFlag(VOID);
UINT32 _BspOptBbuPbRruAdptThreadInit(void);
UINT32 _BspQcellOptStaCheckThreadInit(void);
UINT32 _BspOptAdptInit(T_OptAdaptInfo *pInfo);
VOID optadpton(VOID);
VOID optadptoff(VOID);
VOID qcelloptadpton(VOID);
VOID qcelloptadptoff(VOID);
UINT32 _BspOptAdptInfoInit(VOID);
UINT32 BspGetOptSpeedSetFlag(UINT32 ulPhyOpt);
UINT32 BspSetPcsAlarmMask(void);
UINT32 BspQcellGetOptSta(UINT32 ulPhyOpt);/* app速率自适应用，获取1次pcs状态 */
UINT32 BspQcellGetOptStatus(UINT32 ulPhyOpt);/* app速率自适应用，获取15次pcs状态 */
UINT32 BspCheckPhyOptIsLop(UINT32 ulPhyOptId);
UINT32 BspOptBbuPbRruSetRate_25G(UINT32 ulMainPhyOptNo);
UINT32 BspOptBbuPbRruSetRate_10G(UINT32 ulMainPhyOptNo);
UINT32 testSetQcellRate10G(UINT32 ulMainPhyOptNo);
UINT32 testSetQcellRate25G(UINT32 ulMainPhyOptNo);
UINT32 BspGetOptRateAutoStopState(VOID);
UINT32 BspSetOptRateAutoDisable(VOID);
UINT32 BspSetOptRateAutoEnable(VOID);
UINT32 BspSetOptMonitorM0(VOID);
UINT32 BspGetQcellMonitorState(VOID);
UINT32 BspSetOptQcellHdReset(UINT32 ulSwitch);
UINT32 BspHalGetSuperFrameAdjustFlag(VOID);
UINT32 BspSetQcellNrCompSwTable(UINT32 rate);
UINT32 BspBifGfCrmRxReset(void);
UINT32 IsAllPhyOptStaError(VOID);
VOID BspClearCarrGainCallBackInit(FUN_CLEAR_CARR_GAIN pClearGain);
VOID BspRegisterCheckRruIdRangeCallBack(FUNC_CHECK_RRUIDRANGE pFunc);

UINT32 BspOptRruSetRoeModeRate(T_OptRoeModeInfo *ptOptRoeModeInfo);
UINT32 BspCfgFrameDataByMainOpt(void);
UINT32 BspChkOptSwitchOverThreadInit(void);
UINT32 BspGetSerdesRateByCpriRate(UINT32 ulSpd);
ULONG BspRingNetWorkCheck(void);
UINT32 BspCheckRruIdIsOk(void);
UINT32 BspChangeOptProperty(UINT32 swFlag, UINT32 phyOpt);
UINT32 BspInitOptInfoStatusThread(VOID);
UINT32 BspSetSuperFrameNo(T_UtdoaSuperFrameCfg *pUtdoaSuperFrameCfg);
UINT32 BspGetSynPsyncFrameNo(VOID);
UINT32 BspSetSynPsyncSuperFrameNo(UINT32 superFrameNo);
UINT32 BspHalAdaptGetSynPsyncSuperFrameNo(VOID);
UINT32 BspGetSynPsyncSuperFrameNo(VOID);
UINT32 BspCfgTxPriorityThreadInit(VOID);
UINT32 BspQcellGetNeed10gFlag(VOID);
VOID BspQcellSetNeed10gFlag(UINT32 flag);/* 设置QCELL是否需要配置10G速率的标志 */
UINT32 BspQcellGetOptStaCheckFlag(VOID);
UINT32 BspQcellSetOptStaCheckFlag(UINT32 flag);
UINT32 BspQcellCheckOptPsyncSynThreadInit(void);
UINT32 BspFirstSetProtocol(void);
UINT32 BspCheckProtocol(UINT32 currProtocol);
UINT32 BspProtocolAdapt(void);
UINT32 BspReadProtocol(UINT32 *optProtocol);
UINT32 BspGetDownOptSpeedList(void);
UINT32 BspSetOptSpeedListCpri(UINT32 speedlist);
UINT32 BspGetIrCaseCadeCpriFlag(void);
UINT32 BspSetIrCaseCadeCpriFlag(UINT32 flag);
UINT32 BspSaveProtocol(UINT32 optProtocol);
UINT32 BspSetGnssGpsLogicOpt(void);
UINT32 BspOutOfSyncDetectPara(T_OutOfSyncDetect *pOutOfSyncDetect);
UINT32 BspSetElectronicSw(UINT32 sw);
VOID BspSetBbuSuperFrameNoCallBackInit(FUN_SET_BBU_SUPER_FRAMENO pAntcalPtr);
VOID BspCopyOutOfPsyncParaToKoCallBackInit(FUN_COPY_OUTOFPSYNC_PARA_TO_KO pAntcalPtr);
UINT32 BspSwitchSlaveOptAdaptStaCallBackInit(FUN_SWITCH_SLAVE_OPT_ADAPT_STA pSlaveOptAdaptPtr);
ULONG BspOptAdptCheck(VOID);
UINT32 BspCheckProCotolChg(void);
UINT32 BspSetIoBitmapAllChn(VOID);
ULONG _BspIsNeedSlaveOptAdaptByWorkMode(void);
VOID BspChkOptSwitchoverIsr(void);
UINT32 BspGetTddOptFrAndPropertySw(UINT32 phyOpt);
UINT32 BspGetOptFrAndPropertySw(UINT32 phyOpt);
UINT32 BspFixingCurrentMainOpt(UINT32 fixingFlag);
void BspUpdateShareBaseOptNo(UINT32 phyNo);
void BspSetCpriCfgNetTrasMode(UINT32 logNo, UINT32 mode);
UINT32 BspSetCpriUlFrameAlignFrSelByMode(UINT32 logNo, UINT32 cfgVal);
UINT32 IsAllPhyOptStaOk(void);
UINT32 IsAllLogOptStaOk(void);
UINT32 BspJudgeOptSwitchByWorkMode(UINT32 workMode, UINT32 phyOpt);
UINT32 DetectLogon(UINT32 time);
UINT32 DetectLogoff(VOID);
UINT32 BspShareModeBandOpt(VOID);
VOID qcellopthelp(VOID);
UINT32 BspCheckAllOptRruId(VOID);
UINT32 IsAllOptLop(VOID);
UINT32 BspSetDlGpEnAllChan(UINT32 sw);
UINT32 BspCheckLofCloseTx(VOID);
UINT32 BspCtrlDownLinkOptSta(UINT32 downLinkOpt, UINT32 close);
UINT32 BspCtrlOptAlarm(UINT32 state, UINT32 nextState);
UINT32 BspSetMainPhyOptChangeStateForApp(UINT32 scene);
VOID setringOptSwitch(UINT32 flag);
VOID BspSetAxcProEnable(UINT32 flag);
VOID BspGfTdmCheckForQcell(VOID);
UINT32 BspLinkWithPhy0Priority(VOID);
UINT32 BspCheckPhy0ChangeMain(UINT32 mainPhyNo);
UINT32 BspSetOpttRelarionAlrm(UINT32 mainPhy);
UINT32 BspTddRingAntiJitter(VOID);
UINT32 BspTryLinkWithPhy0(VOID);
VOID stopAnotherOptCnt(UINT32 stopEn);
VOID BspSetSupport2BbuMainSlaveFlag(UINT32 flag);
UINT32 BspGetSupport2BbuMainSlaveFlag(VOID);
UINT32 IsRruIdRangeOK(VOID);
ULONG _BspDoubleOptAdptCheck(void);
#ifdef __cplusplus
}
#endif
#endif /* _OPT_ADAPT_H_ */


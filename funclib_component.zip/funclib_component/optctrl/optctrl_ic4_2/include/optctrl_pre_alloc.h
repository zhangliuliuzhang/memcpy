#ifndef _OPTCTRL_PRE_ALLOC_H_
#define _OPTCTRL_PRE_ALLOC_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "ru_univdef.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"
#define INVALID_UINT32  0xffffffff
#define VALID_CARR_FLAG  0x5A5A5A5A
#define INVALID_CARR_FLAG 0
#define VALID_MAP_FLAG  0x5A5A5A5A
#define INVALID_MAP_FLAG 0

#define CARR_CHG_FALG 0x5A5A5A5A
#define NO_CARR_CHG_FALG 0

/* 频段个数 */
#define PRE_ALLOC_BAND_NUM (8)
/*预制场景数*/
#define PRE_ALLOC_SENCE_NUM (16)
/* 天线组个数 */
#define CHAN_GRP_NUM PRE_ALLOC_BAND_NUM
/* 载波带宽分档统计 */
#define MAX_CARR_BAND_TYPE_NUM (3)
enum{
	CARR_BANDWIDTH_TYPE_0, /*tdd nr 100M　或fdd nr 60m */
	CARR_BANDWIDTH_TYPE_1, /*tdd nr 80M 或fdd nr 20m */
	CARR_BANDWIDTH_TYPE_2, /*tdd nr 80M以下 */
};
/* 载波状态 */
enum E_CARR_STATUS
{
	CARR_STATUS_HOLD,
	CARR_STATUS_ADD,
	CARR_STATUS_DEL,
	CARR_STATUS_CHG
};
/* 载波状态 */
enum E_CARR_TYPE
{
	TDDNR_CARR_TYPE,
	FDDNR_CARR_TYPE,
	LTE_CARR_TYPE,
	MAX_CARR_TYPE_NUM
};
/* 整机类型*/
enum E_RRU_TYPE
{
    FDD_TYPE,
    TDD_TYPE,
    TDDFDD_TYPE,
    QCELL_TYPE,
    MAX_RRU_TYPE
};

/* 场景预置 */
#if 0
typedef struct tag_preAllocInfo {
    UINT32 antMask;
    T_BspHalAdaptPreAllocBwInfo preAllocBwInfo;
} T_PreAllocInfo;

typedef struct tag_preAllocCfg {
    UINT32 bandNum; /* 频段个数 */
    T_PreAllocInfo preAllocInfo[PRE_ALLOC_BAND_NUM];
} T_PreAllocCfg;

typedef struct  tag_RuPreAllocInfo {
    T_PreAllocCfg  txPresetInfo;
    T_PreAllocCfg  rxPresetInfo;
} T_RuPreAllocInfo;
#endif

typedef struct T_CarrMapRet {
    UINT32 validFlag;    /* 数据有效标识 */
    UINT32 carrNo;       /* 载波号 */
    UINT32 radioMode;    /* 制式 */
    UINT32 bandWidth;    /* 带宽 */
    UINT32 freq;         /* 频点 */
    UINT32 chanMask;     /* 载波的通道掩码 */
    UINT32 optCarrNo;   /* 光口载波号 */
    UINT32 difCarrNo;   /* 中频载波号 */
    UINT32 mapFlag;     /* 映射标志 0未映射，0x5a5a已映射 */
    UINT32 exchaneFlag; /* 载波交换标志 0不需要交换，0x5a5a需要交换。在addDelFlag为hold状态有效 */
} T_CarrMapRet;

typedef struct T_ChanCarrMapInfo {
	UINT32 isFirstPreset;                           /* 是否第一次预制 */
    UINT32 preCfgRet;                               /* 场景预置状态 */
    T_BspHalAdaptPreAllocCarrInfo preAllocCarrInfo;   /* 预置的场景 */
    T_BspHalAdaptAllChanCarrMapRet chanCarrMapRet;  /* 载波映射信息 */
} T_AllChanCarrMapInfo;

/* 场景预置关联的载波映射信息 */
typedef struct T_PreAllocAssocCarrMapInfo {
    UINT32 optCarrNo;    /* 对应的光口载波号，即资源位置 */
    UINT32 bandWidth;    /* 对应的bandwidth */
    UINT32 preRadioMode;    /*此位置预制支持的制式 */
    UINT32 effectRadioMode; /* 此位置实际放的载波的制式 */
    UINT32 carrMapIndex;  /* 对应载波映射保存的位置，0xfffffff 表示未映射 */
    UINT32 mapFlag;     /* 映射生效标识 */
} T_PreAllocAssocCarrMapInfo;

/* 载波映射辅助结构 */
typedef struct T_AllCarrMapHelpInfo {
	UINT32  preSence;   /*选择的场景*/
    UINT32  nrCarrNum; /* 映射的载波数 */
    UINT32  lteCarrNum; /* 映射的载波数 */
    UINT32  nrCarrNoMapNum;   /* NR 载波未映射的数量  */
    UINT32  lteCarrNoMapNum;  /* LTE 载波未映射的数量 */
    UINT32 maxNrCarrNum;     /* 支持的最大NR载波数量 */
    UINT32 maxLteCarrNum;    /* 支持的最大LTE载波数量 */
    UINT32 isCarrChg;        /* 载波是否发生了位置交换 */
    T_CarrMapRet*  CarrMapRetPtr; /* 为了快速处理 */
    T_PreAllocAssocCarrMapInfo* preAllocMapCarrStatus;
} T_AllCarrMapHelpInfo;

typedef struct T_ChanMaskInfo {
    UINT32 txChanMaskNum;                   /* 下行通道个数 */
    UINT32 txChanMaskInfo[CHAN_GRP_NUM];    /* 下行通道掩码 */

    UINT32 rxChanMaskNum;                   /* 上行通道个数 */
    UINT32 rxChanMaskInfo[CHAN_GRP_NUM];    /* 上行通道掩码 */
} T_ChanMaskInfo;

typedef struct T_BspCarrCountInfo
{
	UINT32 carrNum[MAX_CARR_BAND_TYPE_NUM];/*对TDD NR分100 80 60M 三档 FDD NR 分60-20 20及以下*/
	UINT32 bandWidth[MAX_CARR_BAND_TYPE_NUM];
	UINT32 carrScs[MAX_CARR_BAND_TYPE_NUM];
	UINT32 ifType[MAX_CARR_BAND_TYPE_NUM];
} T_BspCarrCountInfo;
typedef struct T_BspPreSenceAllocCarrInfo
{
	UINT32 rruType;
	UINT32 carrTotalNum;
	T_BspCarrCountInfo carrInfo[MAX_CARR_TYPE_NUM];
} T_BspPreSenceAllocCarrInfo; /*去除掉删除状态载波之后的载波信息，用来分析选择哪个场景*/

UINT32 BspGetPreAllocResIndex(UINT32 carrNo, UINT32 radioMode, UINT32 dir, UINT32 chanMask, UINT32* resIndex);
UINT32 BspGetPreAllocBandInfo(T_ChanMaskInfo* bandInfo);
UINT32 BspSetPreAllocBandInfo(T_ChanMaskInfo* bandInfo);
UINT32 BspGetChanGroupCarrMapInfoUsingChanMask(UINT32 antMask, UINT32 dir, T_AllChanCarrMapInfo** carrMapInfo);
UINT32 BspOamCellPreAlloc(T_DestCarrInfoAllChans* cfgInfo, T_PreAllocResult* preAllocResult);
UINT32 BspInitBoardPreAllocInfo(T_BspHalAdaptPreAllocCarrInfo* preAllocInfo,UINT32 rruType);
VOID PrnCellCarrInfo(T_BspHalAdaptAllCellCarrInfo *pInfo);
VOID BspSetUsePreAllocSw(UINT32 sw);
void BspDoingCarrMapInfoShow(void);
UINT32 BspInitBoardPreAllocParaToHal(UINT32 uCprType, UINT32 uAntMask);
void BspInitAllCarrMapInfo();
void BspInitCurrAllCarrMapInfo();

#ifdef __cplusplus

}
#endif
#endif /* _OPTCTRL_PRE_ALLOC_H_ */

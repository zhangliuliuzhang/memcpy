#ifndef _OPTCTRL_INTER_DEF_H_
#define _OPTCTRL_INTER_DEF_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "pub_typedef.h"
#include "bsppub.h"
#include "funccommon_log.h"
#include "optctrlcommon.h"
#include "ichal_opt_api.h"

#if 0
typedef struct T_BbuFiberRecord
{
    UINT32 srcOptId;
    UINT32 ShelfNo;
    UINT32 uRackNo;
    UINT32 slotNo;
}T_OptInfo;

typedef struct
{
    T_OptInfo peerOptInfo;
    T_OptInfo localOptInfo;
    UINT8  peerMac[6];
    UINT8  localMac[6];
    UINT8  peerIp[4];
    UINT8  localIp[4];
    UINT32 optTransSpeed;
    UINT32 optTransProtocal;
    UINT32 flag; //表示是否该条光口信息有效；
}T_OptConnectRelation;

#if 0
typedef struct
{
    UINT32 cellIndex;
    UINT32 antActiveMask;//激活
    UINT32 optIdByAnt[16]; //本IC的0~15
    UINT32 cellFlowId[16];
    UINT32 pranchFlowId[16];
}T_EcpriCellInfo;
#endif



typedef struct
{
    UINT32 cellIndex;
    UINT32 streamNum; /*决定下面赋值的下标个数*/

    /*
        下行的话:
        填写IQ所在的基带天线号,

        上行的话:
        IQ填写所在的基带天线号

        1：如果PRACH按照频点来上传数据，例如按照PRACH占用4个频点来看
        PRACH填写按照有几个频点填写，
        PRACH 第一个频点 streamNo填写16，
        PRACH 第二个频点 streamNo填写17
        PRACH 第三个频点 streamNo填写18
        PRACH 第四个频点 streamNo填写19

        2：如果PRACH按照天线来上传数据，例如按照PRACH占用4个天线来看

        PRACH 在第一个天线 streamNo填写16+PRACH所在的天线号，
        PRACH 在第二个天线 streamNo填写16++PRACH所在的天线号
        PRACH 在第二个天线 streamNo填写16++PRACH所在的天线号
        PRACH 在第二个天线 streamNo填写16++PRACH所在的天线号
   */
    UINT8  streamNo[24];
    UINT8  dwOptNo[24];
    UINT32 FlowId[24];
    UINT32 msgType[24];
}T_EcpriCellStreamInfo;

typedef struct
{
    UINT32 cellIndex;
    UINT32 cellAdFlag;
    UINT32 cellBw[2];
    UINT8  cellIFType; //IF0/IF1;
    UINT8  cellBearType; //CPRI/ECPRI/ROE
    UINT8  cellSCSBitMap;
    UINT8  cellTTI;//枚举;
    UINT32 cellAntRadioMode;//小区制式
    UINT32 cellCarrNo;//一个小区内所有天线载波号一样。
    UINT32 cellAntMask[2];
    UINT32 cellULCompressMode;
    UINT32 cellDLDeCompressMode;
    UINT8  cellTxSymbolBit[112];
    UINT8  cellRxSymbolBit[112];
    UINT32 cellIQPkgMLEN[2];  /*上下行*/
    UINT32 iqSampleRate;  //ecpri IF1 需要此字段。
    UINT8  fftaCpType; //类型，normal or extern
    UINT8  resv[3];
}T_CellCfgInfo;


typedef struct T_IQRecord
{
    UINT32 fiberNo;
    UINT32 dir;
    UINT32 carrMode;
    UINT32 antNo;
    UINT32 carrNo;
    UINT32 axCNo;
    UINT32 axCIndex;
}T_IQRecord;  //TDD IQ

typedef struct
{
    UINT32 cellIndex;
    UINT32 prachConfigIndex;//0----255，表示长短码，格式出现的时刻
    UINT32 prachCommpress;
    UINT32 prachPktMlen;
    UINT32 prachAntMask;
    UINT32 prachFreqOffSet[4];// 无效值
    UINT32 prachBBACWeight[16];//ant时域权值
    UINT32 prachRFACWeight[16];
    UINT8  prachSCSBitMap;
    UINT8  prachFreqNum;
    UINT16 resv;
}T_PrachCellInfo;


typedef struct
{
    UINT32 chipNo;
    UINT32 axcPos;
    UINT32 axcLen;
}T_GroupInfo;

typedef struct
{
    UINT32 antBindNum;
    UINT32 cellId[4]; //目前最大4个绑定；紧密排列
    UINT32 antId[4];
}T_AntBindInfo;

typedef struct
{
    UINT32 prachOptId;
    T_GroupInfo prachGroupAxc[32];
    T_AntBindInfo prachAntBind[32];
    UINT32 prachTDDSlotCfg;
}T_CpriPrachPara;


typedef struct
{
    UINT32 prachTDDSlotCfg;
    UINT8  gfCompressMode;
    UINT8  gfIQBigLittleMOde;
    UINT8  gfIQSwapEnFlag;
    UINT8  resv;
}T_GFCfgPara;

typedef struct
{
    UINT8  rbIQEnableFlag;
    UINT8  rbBindType;
    UINT8  rbCarrNum;
    UINT8  resv;
}T_RbCfgPara;

typedef struct
{
    UINT32 cellIndex;
    UINT32 fftaBbAcWeight[16][300];
    UINT32 fftaRfAcWeight[16][300];
}T_FftaACWeight;


typedef struct
{
    UINT32 fftaAgcEnable;
    INT32  fftaAgcAGain;//[-8,11]
    UINT32 fftaAntMask;
    UINT32 fftaDlyCmpSampleNum;
    UINT32 fftaVgaEnable;
    UINT32 fftaOapEnable;
    UINT32 fftaFreqOffsetCompEnable;
    UINT32 fftaFreqOffset7p5KCompEnable;
    UINT32 fftaFreqOffsetCarrNum;
    UINT32 fftaAcEnable;
    UINT32 fftaPreProcessEnable;
    UINT32 fftaCompsZeroEnable;
    UINT32 fftaDLCompsZeroEnable;
    UINT32 fftaRspcEnable;
    UINT32 fftaRspcFactorValue;
    UINT32 fftaNbCpEnable;
    UINT32 fftaDtxEnable;
    UINT32 fftaTimeDomWindowEnable;
    UINT32 fftaTimeDomWindowValue[2];
    UINT8  fftaCpType; //类型，normal or extern
    UINT8  fftaACMode;
    UINT8  rsv[18];  //对齐
}T_FFTACfgPara;


#endif

typedef UINT32 (*FUNC_InitStoredCarrWgt)(UINT32 carrNo, UINT32 radioMode);
typedef UINT32 (*FUNC_DELTE_CARR_CLOSE_AAC)(UINT32 sw);

UINT32 BspOptConnectRelationInit(T_OptConnectRelation *pPara);
UINT32 BspOptEcpriCellInfoInit(T_EcpriCellStreamInfo *pPara,UINT32 dir);
UINT32 BspOptCellInfoInit(T_CellCfgInfo *pPara);
UINT32 BspCfgCellModeFpga(T_CellCfgInfo *pPara);
UINT32 BspSetRvsTax(UINT32 uCellId,UINT32 uRadioMode,INT32 rvsTaxDL,INT32 rvsTaxUL);
UINT32 BspGetOptCellNum(void);
UINT32 BspSetEcpriL2ssPathByCellIndx(UINT32 cellIdx);
UINT32 BspSetEcpriL2ssPathEn();
UINT32 BspSetEcpriL2ssPathDisEn();
UINT32 BspSetEcpriRoePathByCellIndx(UINT32 cellIdx);
UINT32 BspOptL1PrachInfoInit(T_PrachCellInfo *pPara);
UINT32 BspOptL1CellPrachInfoInit(UINT32 uRachNum,  T_PrachCellInfo *pPara);
UINT32 BspOptCpriPrachInfoInit(T_CpriPrachPara *pPara);
UINT32 BspOptGfInfoInit(T_GFCfgPara *pPara);
UINT32 BspOptRBInfoInit(T_RbCfgPara *pPara);
UINT32 BspOptAcParaCfg(T_FftaACWeight *pPara);
UINT32 BspOptFFTAParaInit(UINT32 uCellIdx,UINT32 uDir, UINT32 uScs, T_FFTACfgPara *pPara);
UINT32 BspOptCellInfoCfg(UINT32 uCellIdx);
UINT32 BspOptCellInfoDelte(UINT32 uCellIdx);
UINT32 BspFftaHwCfgInit();
UINT32 BspOptResurceManagerInit();
UINT32 BspGetCarrIfType(UINT32 uChn, UINT32 uDir, UINT32 uCarrMode,UINT32 uCarrNo, UINT32 *pIfType);
UINT32 BspGetCarrOptInfo(UINT32 uChn, UINT32 uDir, UINT32 uCarrMode,UINT32 uCarrNo, UINT32 *pSamp, UINT32 *pCompressMode);
UINT32 BspSetOptLinkTbl(Opt_Link_Tbl *pOptlink,UINT32 LinkNum);
UINT32 BspSetPhaCompPara(UINT32 uCellId, UINT32 uDir, UINT32 uFreq);
void BspSavePhaCompFreqPara(UINT32 uCellId, UINT32 ulDir, UINT32 uFreq);
UINT32 BspPreCfgL1OptByWorkMode(UINT32 uWorkMode);
UINT32 BspSetEcpriRemoteRst(UINT8 *pDestMac1,UINT8 *pDestMac2);
UINT32 BspGetPrachSolutionType();
UINT32 tstRdErsRam(UINT32 chn);
UINT32 BspBackGroundSample(UINT32 uCellId,UINT32 uDir,UINT32 uAntIndex,UINT32 uL2dNode,UINT32 uSlotIndex);
UINT32 BspBackGroundSampleStatus(VOID);
UINT32 BspInitStoredCarrWgtCallback(FUNC_InitStoredCarrWgt pInitStoredCarrWgt);
UINT32 BspGetFddCompressModeFromBbuToOptHal(UINT32 ulBbuCmpIndex);
UINT32 BspOptIqFiberNoConvert(UINT32 fiberNo);
VOID PrintOptCellInfoUsingCellId(UINT32 cellId);
VOID PrintOptCellTips(VOID);
VOID BspGetAntNumByCellId(UINT32 cellId, UINT32 dir, UINT32 *antNum);
UINT32 BspCalcLteScaleVal(UINT32 antMask, UINT32 ulCarrNo, UINT32 ulRadioMode, UINT32 refVal, UINT32 portNum, UINT32* scaleVal, UINT32 cellId);
UINT32 BspFddGetAntPowSumByAntMask(UINT32 antMask, UINT32 carrNo, UINT32 cellId);
UINT32 BspCalcNrScaleVal(UINT32 radioMode,UINT32 antMask,UINT32 carrNo, UINT32 refVal, UINT32* scaleVal, UINT32 cellId);
VOID BspGetLteScaleValByErsIndex(INT32 ersIndex, UINT32 *scaleVal);
UINT32 BspCheckBifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspCheckGfCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspCheckDifCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspCheckFftCarrDly(T_OptDormantCellCfgInfo *pDlyCfgInfo);
UINT32 BspInitOptDormantCellCfg(T_CellCfgInfo* cellCfg, T_SleepCheckCarrDelay* carrDelay, T_OptDormantCellCfgInfo* outCellCfg);
UINT32 BspConvertCompressModeToHal(UINT32 cellIFType, UINT32 ulCfgCompressMode);
typedef UINT32 (*FUNC_GET_MAIN_PORT)(VOID);
typedef UINT32 (*FUNC_GET_OPT_STATUS)(UINT32 optId);
typedef UINT32 (*FUNC_CREATE_KU5P)(UINT32 ulCellIndex);
typedef UINT32 (*FUNC_GetPowSumFromBoard)(UINT32 radio,UINT32 antmask,UINT32 *ratedPwr, UINT32 *basePwr);
UINT32 BspDelteCarrCloseAacCallback(FUNC_DELTE_CARR_CLOSE_AAC pCallBack);
UINT32 BspGetCalScaleUsingTxPwr(VOID);
UINT32 BspSetCalScaleUsingTxPwr(UINT32 uInPut);
#ifdef __cplusplus
}
#endif

#endif /* _OPT_INTERFACE_DEF_H_H_ */

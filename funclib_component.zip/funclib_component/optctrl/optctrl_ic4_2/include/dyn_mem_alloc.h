#ifndef _DYN_MEM_ALLOC_H_
#define _DYN_MEM_ALLOC_H_
#include <stdlib.h>
#include <string.h>
#define  DYN_MEM_ALLOC(ptrMem, allocByteNum) do { \
    ptrMem = (void*)malloc(allocByteNum);\
    if (ptrMem != NULL) { \
        (void)memset(ptrMem, 0, allocByteNum);\
    } \
} while(0)

#define DYN_MEM_FREE(ptrMem) do { \
    if (ptrMem != NULL) { \
        free(ptrMem); \
        ptrMem = NULL; \
    } \
} while(0)

#endif // _DYN_MEM_ALLOC_H_

/*****************************************************************************
* 版权所有(C) 2015, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : optctrl_ecpri_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者   : 10090699
* 创建日期 : 2017-3-2 17:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-3-2 17:26:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_OPTCTRL_ECPRI_IC4_H_
#define _FUNCLIB_OPTCTRL_ECPRI_IC4_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "bsppub.h"
#include "optctrlapi.h"
// #include "pub_ntl.h"
//#include "funccommon_log.h"
//#include "optctrlcommon.h"
/*天线频点方式 （以频点为基准的天线变)*/
// #define PRACH_ANT_FREQ_TYPE 0

// UINT32 PrnEcpriCellStreamInfo(VOID);
// UINT32 BspSetEcpriCwChnCfg(T_NtlCwChnCfg *ptNtlCwChnCfg,UINT32 num);
// UINT32 NtlSetEcpriRRst(UINT8 *pDestMac1,UINT8 *pDestMac2);
// UINT32 NtlSetEcpriERS();
// UINT32 NtlSetEcpriHiPowRptEn(UINT32 en);
UINT32 BspSetOptAntFlowMapInfo(T_OptAntFlowMapInfo*  optAntFlowMapInfoArr, UINT32 mapArrSize);
typedef UINT32 (*FUNC_CALLED_OPTFPGA_UMTS_ROE_MACIP_CFG)(T_RoeOptLinkParaRecord *roeOptLinkPara);
UINT32 BspOptFpgaRoeMacIpCfgCall(FUNC_CALLED_OPTFPGA_UMTS_ROE_MACIP_CFG pGetUmtsRoeMacIpCfgCall);

#ifdef __cplusplus
}
#endif
#endif /* _FUNCLIB_OPTCTRL_H_ */




/*****************************************************************************
* 版权所有(C) 2015, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : optctrl_ecpri_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者   : 10090699
* 创建日期 : 2017-3-2 17:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-3-2 17:26:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_OPTCTRL_CPRI_IC4_2_H_
#define _FUNCLIB_OPTCTRL_CPRI_IC4_2_H_
#include "ichaladapt_ic4_2.h"
#define MOD_MSG_ON   1
#define MOD_MSG_OFF  0

#ifndef OPTMAXNUM
#define OPTMAXNUM 2
#endif

#define PCS_NORMAL          (0x3)
#define SERDES_RXINIT_MAX   (3)
#define SERDES_LANE_MAX     (4)
#define NCR_IPADDR_LEN_MAX (64)

#define CHECK_MSG_ERR_RETURN(val,mod,fmt, ...) {\
    if((MOD_MSG_ON == mod) && (BSP_OK != (val))) \
    {                                                          \
        dbgInfo("[%s(L:%d)-<error>]" fmt, __FUNCTION__, __LINE__, ## __VA_ARGS__);          \
        return BSP_ERROR;                                      \
    }                                                          \
}
#define MSG_DBG(mod,fmt, ...)  {\
    if(MOD_MSG_ON == mod) \
    {                                \
        dbgInfo("[%s(L:%d)-<debug>]" fmt, __FUNCTION__, __LINE__, ## __VA_ARGS__);          \
    }                                \
}

#define MSG_ERR(mod,fmt, ...)  {\
    if(MOD_MSG_ON == mod) \
    {                                   \
        dbgInfo("[%s(L:%d)-<error>]" fmt, __FUNCTION__, __LINE__, ## __VA_ARGS__);          \
    }                                   \
}

#define CHECK_MSG_ERR(val,mod,fmt, ...) {\
    if((MOD_MSG_ON == mod) && (BSP_OK != (val))) \
    {                                                          \
        dbgInfo("[%s(L:%d)-<error>]" fmt, __FUNCTION__, __LINE__, ## __VA_ARGS__);          \
    }                                                          \
}

#ifdef __cplusplus
extern "C" {
#endif

#define OPTMAXNUM 2
#define OPT_NOT_SUPPORT_RING (0)
#define OPT_SUPPORT_RING     (1)
#define OPT_SUPPORT_SHARE    (2)

#define LOG_OPT_0            (0)
#define LOG_OPT_1            (1)
#define LOG_OPT_2            (2)
#define LOG_OPT_3            (3)

#define PHY_OPT_0            (0)
#define PHY_OPT_1            (1)

#define OPT_FR_TESTMODE_OFF   (0)
#define OPT_FR_TESTMODE_ON    (1)

#define OPT_INNER_CPRI_FR_LOOP_MODE_OFF (0)
#define OPT_INNER_CPRI_FR_LOOP_MODE_ON  (1)

#define OPT_NOT_SUPPORT_DUAL_BBU (0)
#define OPT_SUPPORT_DUAL_BBU     (1)

#define OPT_TX_PRIORITY_AUTO     (0)
#define OPT_TX_PRIORITY_FORCE    (1)

#define OPT_FORCE_AUTO        (0)
#define OPT_FORCE_OPT0        (1)  /* 固定主光口0模式 */
#define OPT_FORCE_REVERSE     (2)  /* 固定反向主光口模式 */
#define OPT_FORCE_OPT1        (3)  /* 固定主光口0模式 */

#define BBU_REDUNDANCY_MODE   (2)   /* Double BBU TYPE */

#define MT_POWER_ON  1
#define MT_POWER_OFF 0

#define NOT_TRY_LINK_WITH_PHY0    (0)
#define TRY_LINK_WITH_PHY0        (1)


#define INPUT_OPT_CHECK(opt)                        \
{                                                   \
    if((opt > BspGetOptCnt(0))||(opt >= OPTMAXNUM))                              \
    {                                               \
        return BSP_ERROR;                           \
    }                                               \
}

typedef UINT32 (*FUNC_OPTADAPT_POST)(UINT32 ulSel);
typedef UINT32 (*HGOptCheckCall)(void);
typedef UINT32 (*FUNC_GET_IP_ADDR)(CHAR* ip);
typedef UINT32 (*FUNC_GET_RRU_ID)(VOID);
typedef VOID (*FUNC_RESTART_MT)(UINT8 ucOptId);

UINT32 BspGetPhyPort(UINT32 logicOpt);
UINT32 BspGetCurrFiberPort(void);
UINT32 BspSetOptCpriProtocol(UINT32 ulProtocol);
UINT32 BspSetM0OptSpeed(UINT32 ulIndex, UINT32  ulSpd);
UINT32 BspSetOptSpeed(UINT32 ulIndex, UINT32  ulSpd);
UINT32 BspGetOptSpeed(UINT32 ulIndex);
UINT32 BspSetOptFecMode(UINT32 ulIndex);
UINT32 BspSetOptSpeedQcell(UINT32 ulIndex, UINT32  ulSpd);
UINT32 BspSetOptCpriProtocol(UINT32 ulProtocol);
UINT32 BspGetRruId(UINT32 ulIndex);
UINT32 BspGetQcellLinkCtrlX(UINT32 ulLogOptNo);
UINT32 BspCpriCfgTransQcellLinkCtrlX(UINT32 ulLogOptNo, UINT32 ulLinkCtrlX);
UINT32 BspCpriCfgTransQcellRruId(UINT32 ulLogOptNo, UINT32 ulRruId);
INT32 BspGetFrTmVal(UINT32 ulCfgId, UINT32 ulMode);
/*VOID _BspTrytoCfgOptSpeed(VOID);*/
UINT32 BspSetPhyNoBySfpNo(UINT32 sfpNo,UINT32 phyNo);
UINT32 BspGetPhyNoBySfpNo(UINT32 sfpNo);
UINT32 BspSetSerdesParaByPhyNo(UINT32 phyNo,T_OPTRATE_SERDES_PARAM *pOptRatePara);
UINT32 BspGetSerdesParaByPhyNo(UINT32 phyNo,T_OPTRATE_SERDES_PARAM *pPara);
UINT32  BspSaveOptLastMatchTopologyRecord(UINT32 ulPhyOptId,UINT32 ulTopology);
UINT32 BspGetOptLastTopology(UINT32 ulPhyOptId);
UINT32 BspGetOptCpriProtocol(UINT32 ulLogOpt);
UINT32 _BspReCfgOptRxSerdes(UINT32 ulIndex, UINT32  ulSpd);
UINT32 BspGetMainPhyOpt(VOID);
UINT32 _BspCheckPhyOptIsLop(UINT32 ulPhyOptId);
UINT32 BspGetSfpNoByPhyNo(UINT32 phyOptNo);
UINT32 BspSetOptCpriSetCrcMask(VOID);
UINT32 BspQcellGetL2ssTrxpEn(UINT32 *udPortEnPara);
UINT32 BspQcellSetL2ssTrxpEnOff(VOID);
UINT32 BspQcellSetL2ssTrxpEnOn(UINT32 *udPortEnPara);
UINT32 BspQcellSetOptSerdesRate(UINT32 ulIndex, UINT32  ulSpd);
UINT32 BspQcellSetOptRoeRate(UINT32 ulRoeRate, UINT32 ulSpd);
UINT32 BspQcellSetOptCpriRate(UINT32 ulIndex, UINT32  ulSpd);
UINT32 BspQcellSetCrmOptCpriRefClkSoft(UINT32 laneIdx);
UINT32 BspQcellGetOptPcsSta(UINT32 ulPhyOpt);
UINT32 BspGetNextLinkResult(UINT32 ucLinkMode);
UINT32 BspSetNextLinkCmd(UINT32 ucLinkMode);
UINT32 BspQsfpParaCfg(UINT32 ulOptIndex);
UINT32 BspSfpParaCfg(UINT32 ulOptIndex);
UINT32 BspSfpQsfpCfgProcess(VOID);
UINT32 BspSetCpriOptProperty(UINT32 ulFlag, UINT32 ulPhyOptNo);
VOID BspSetBlindMapMode(UINT32 mode);
UINT32 BspGetBlindMapMode(VOID);
UINT32 BspCheckSfpCdrStatus(UINT32 index);
UINT32 BspOptAlmCollect(VOID);
UINT32 BspSetOptSpdChgRecord(UINT32 phyOptNo);
VOID BspSetOptSpdChgFlag(UINT32 phyOptNo, UINT32 flag);
UINT32 BspSetOptLosAlmFromPcs(UINT32 optNo);

UINT32 BspGetOptLoopSta(UINT32 ulPhyOpt);
UINT32 BspSetAxcArrangeTypeByRate(UINT32 ulPhyOpt);
UINT32 BspOptLogicPortPowProtectSel(VOID);
UINT32 BspJudgeOptStaByOptWorkMode();
UINT32 BspIsRingOptWorkMode(VOID);
UINT32 BspGetOptTxPriorityStatus(UINT32 phyNo);
UINT32 BspGetForceSetMainOptMode();
UINT32 BspSetOptFrAndProperty(UINT32 sw, UINT32 phyOpt);
UINT32 BspSetFddOptFrAndProperty(UINT32 sw, UINT32 phyOpt);
UINT32 BspGetCurrReverseMainOpt();
UINT32 BspGetDefaultOptWorkMode(UINT32 optIndex);
UINT32 BspReportOptWorkMode(VOID);
UINT32 BspSetDownLinkOpt(UINT32 phyOpt);
UINT32 BspSetDoubleUpLinkOpt(void);
UINT32 BspSetHGOptSpeedCallBack(HGOptCheckCall HGOptFlag);
VOID BspSetOptRingFlag(UINT32 ulFlag);
UINT32 BspGetOptRingFlag(VOID);
UINT32 BspGetOptShareFlag(VOID);
VOID BspSetSupportDualBbuFlag(UINT32 ulFlag);
UINT32 BspGetSupportDualBbuFlag(VOID);
VOID BspSetOptFrTestModeEn(UINT32 ulFlag);
UINT32 BspGetOptFrTestModeEn(VOID);
UINT32 BspJudgeMainOptStatus(VOID);
UINT32 BspSetOptCpriCfgCmUxSel(VOID);
UINT32 BspCheckSysPllState(VOID);
UINT32 BspGetOptPcsCfgEn(void);
UINT32 BspSetOptCpriFrTestMode(UINT32 cfgEn);
UINT32 BspCheckPhyOptStateNew(UINT32 ulPhyOptId);
UINT32 BspGetOptPcsAlmSta(UINT32 phyOptId);
UINT32 BspCheckRruIdVaild(UINT32 ulIndex);
typedef UINT32 (*BSP_BBX_IQINFO_CALLBACK_FUNCPTR)(char* strIqInfo, UINT32 ulLength);
VOID BspInitShowIqInfoToBbxCallBack(BSP_BBX_IQINFO_CALLBACK_FUNCPTR pFuncCallback);
VOID BspOptRecordLinkBrokenState(VOID);//记录光口链接断链的状态 
UINT32 BspGetDunDancyMode(VOID);
UINT32 BspSoftenRruIndexrClose();
UINT32 BspCpriCfgIqCloseEn(UINT32 ulEn);
UINT32 BspSetCpriCfgIqCloseSetFlag(UINT32 flag);
UINT32 BspGetCpriCfgIqCloseSetFlag();
VOID BspSetRruOptSurportSpeedList(UINT32 mask);

UINT32 BspSetOptControlAlarmByOptAlarm(void);
UINT32 BspSetOptControlAlarm(UINT32 preState, UINT32 nextState);
UINT32 BspSetOptControlAlarmAuto(void);
UINT32 BspSetOptControlAlarmClr(void);
UINT32 BspSetRingnetShortCircuit(UINT32 flag);
UINT32 BspGetOptPhyStatus(UINT32 optId, UINT32 *lopAlrm, UINT32 *losAlrm, UINT32 *lofAlrm);
UINT32 BspSetMainOptSwitchRecord(UINT32 phyOpt);
VOID BspSetOptInnerCpriFrModeEn(UINT32 flag);
UINT32 BspGetOptInnerCpriFrModeEn(VOID);
UINT32 BspGetOptCdrStatus(UINT32 laneId, UINT32 *status);
UINT32 BspSetOptCpriFrLoopMode(UINT32 cfgEn);
UINT32 BspClrOptCfgCnt(void);
UINT32 BspGetLogicPort(UINT32 phyOpt);
UINT32 BspTransIpToHex(CHAR* pIpAddr);
UINT32 BspGetTcpServerIp(UINT8 ucOptId);
UINT32 BspGetOptProtocol(UINT32 ulLogOpt);
UINT32 BspSetRruIdNcr(VOID);
UINT32 BspAtCtrlGetIpAddrCallBack(FUNC_GET_IP_ADDR pFuncGetIpAddrTemp);
UINT32 BspAtCtrlGetRruIdCallBack(FUNC_GET_RRU_ID pFuncGetRruIdTemp);
UINT32 BspQcellGetOptSta(UINT32 ulPhyOpt);
UINT32 BspGetGfCheckFlag(VOID);
UINT32 BspQcellGetOptStaTemp(UINT32 ulPhyOpt, UINT32 *pStatus);
UINT32 BspSetOptProperty(UINT32 phyOpt, UINT32 optWorkMode);
UINT32 BspAxcAllocGetSmpByBw(UINT32 bw, UINT32 radioMode, UINT32 *sampleRate, UINT32 *axcStart, UINT32 *axcNum);
UINT32 BspRecOptCellInfo(T_CellCfgInfo* cellInfo);
void getsharenet(UINT32 bbuPort0, UINT32 bbuPort1);
UINT32 BspCfgCpriFrLoopModeAndLoopBack(VOID);
UINT32 BspSetUpOptDataEn(UINT32 enable);
UINT32 BspSetMainPhyOptChangeState(UINT32 currMainNo, UINT32 recMainNo);
void testSetOptStaEn(UINT32 chgSta, UINT32 dataEn);
UINT32 BspGetDLinkOptNo(void);
UINT32 BspGetPriorityReg(VOID);
UINT32 BspManualCloseChipInterOptAlm(UINT32 phyNo);
UINT32 BspInitChipInterOptAlmEn(VOID);
VOID BspSetMtPowerSta(UINT32 flag);
UINT32 BspGetMtPowerSta(VOID);
VOID BspRestartMt(UINT8 ucOptId);
VOID BspMtRestartCallBack(FUNC_RESTART_MT pFunc);
UINT32 BspGetSupportDoubleBBUMainSlaveFlag(VOID);
VOID BspSetpriorityLinkByPhy0Flag(UINT32 flag);
UINT32 BspGetpriorityLinkByPhy0Flag(VOID);
UINT32 _BspCheckLogicOptState(UINT32 ulLogOptId);
UINT32 _BspCheckPhyOptState(UINT32 ulPhyOptId);
UINT32 BspOptVerifyT12Cfg(UINT32 bspNetMode, UINT32 ta, UINT32 fwdT12, UINT32 revT12);
UINT32 BspGetHalTopNetByBspTopNet(UINT32 ulBspTopNet,UINT32 *ulHalTopNet);
void BspSetBbuPortSpecialCtrl(void);
void BspSetBbuPortSpecialFlag(UINT32 flag);
UINT32 BspChangeHighCableSpeed(T_OPTRATE_SERDES_PARAM *pSerdesPara);
UINT32 BspGetBbuPortSpecialFlag(void);
UINT32 BspSetOptVirtualAbsentConf(UINT32 optId, UINT32 status);
UINT32 BspGetOptVirtualAbsentConf(UINT32 optId);
VOID BspJudgeOptSpeed(UINT32 mainSpd, UINT32 slaveSpd);
#ifdef __cplusplus
}
#endif
#endif /* _FUNCLIB_OPTCTRL_H_ */



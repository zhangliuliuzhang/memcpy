#ifndef _OPTCTRL_CFG_H_
#define _OPTCTRL_CFG_H_

#define  CELL_CARR_SCS_15K 0
#define  CELL_CARR_SCS_30K 1
#define  CELL_CARR_SCS_60K 2
#define  CELL_CARR_SCS_120K 3
#define  CELL_CARR_SCS_INV 4

#endif /* _OPTCTRL_CFG_H_ */

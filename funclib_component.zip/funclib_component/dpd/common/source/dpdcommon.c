/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : dpd_common.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "ru_univdef.h"

#include "dpdcommon.h"
#include "funccommon.h"
#include "exprn.h"
#include "funccommon_a.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/



/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static T_OnlinePim2Param s_OnlinePim2Param      = {0};
static T_DpdModulePimCfgFunc s_DpdModuleFunc    = {0};
static UINT32 s_dpdVerStatus                    = BSP_OK;
static UINT32 s_dpdVswrSupport[BSP_MAX_TX_CHAN] = {DPD_VSWR_FUNC_NOT_SUPPORT};
static pGetDpdChn s_pGeDpdChnFunc = NULL;
static UINT32 s_acCore = BSP_ERROR;
static UINT32 s_WaitDspMode = WAIT_DSP_SLOW;
static UINT32 s_VswrMode = DSP_VSWR_NORMAL;
static UINT32 s_VswrPointNum[BSP_MAX_TX_CHAN] = {0};
static UINT32 s_VswrFreqStep = VSWR_DEFAULT_RFEQ_STEP;
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数实现
 **************************************************************************/
static pDpdGetDifInfo pFunDpdGetDifInfoByBspChnl = NULL;

UINT32 DpdGetDifInfoByBspChnlCallBackInit(pDpdGetDifInfo pCallBackFunc)
{
    pFunDpdGetDifInfoByBspChnl = pCallBackFunc;

    return BSP_OK;
}

UINT32 DpdGetDifInfoByBspChnl(UINT32 ulBspChnl, UINT32 ulTrxDir, UINT32 *pulChipId, UINT32 *pulDifChnl)
{
    UINT32 ulMaxChnlSum = 0;
    UINT32 ulIcChipId   = 0;
    UINT32 ulTmpChnlNo  = 0;
    UINT32 ulRetVal = BSP_OK;

    ulMaxChnlSum = BspGetTxChannel();

    if (NULL == pFunDpdGetDifInfoByBspChnl)
    {
        ulIcChipId  = 0;
        ulTmpChnlNo = ulBspChnl;
    }
    else
    {
        if (ulBspChnl < ulMaxChnlSum)
        {
            ulRetVal = pFunDpdGetDifInfoByBspChnl(ulBspChnl, ulTrxDir, &ulIcChipId, &ulTmpChnlNo);
        }
        else
        {
            ulIcChipId  = 0;
            ulTmpChnlNo = ulBspChnl;
        }
    }

    if (NULL != pulChipId)
    {
        *pulChipId = ulIcChipId;
    }
    if (NULL != pulDifChnl)
    {
        *pulDifChnl = ulTmpChnlNo;
    }

    return ulRetVal;
}

UINT32 BspAcCoreInit(UINT32 acCore)
{
  s_acCore = acCore;

   return BSP_OK;
}

UINT32 BspGetAcCore()
{
  return s_acCore;
}

UINT32 BspDdpChnDefCallBackInit(pGetDpdChn pCallBackFunc)
{
    s_pGeDpdChnFunc = pCallBackFunc;

   return BSP_OK;
}

UINT32 BspGetDspId(UINT32 chan)
{
	if(s_pGeDpdChnFunc != NULL)
	{
		return chan/s_pGeDpdChnFunc();
	}
    return chan/BspGetTxChannel();
}

UINT32 BspGetDspChipChan(UINT32 chan)
{
	if(s_pGeDpdChnFunc != NULL)
	{
		return chan%s_pGeDpdChnFunc();
	}
    return chan;
}
UINT32 BspGetDspVerStatus(VOID)
{
    return s_dpdVerStatus;
}
UINT32 BspSetDspVerStatus(UINT32 dspVerStatus)
{
    s_dpdVerStatus = dspVerStatus;
    return BSP_OK;
}
UINT32 BspIsSupportDpdVswr(UINT32 chan)
{
    if (DPD_VSWR_FUNC_NOT_SUPPORT == s_dpdVswrSupport[chan])
    {
        dbgInfoEx("[%s]chan=%d this board is not support\n",__FUNCTION__, chan);
        return DPD_VSWR_FUNC_NOT_SUPPORT;
    }
    if (BSP_OK != BspGetDpdVswrTblState( 0,chan))
    {
        dbgInfoEx("[%s]chan=%d calib file load failed\n",__FUNCTION__,chan);
        return DPD_VSWR_FUNC_NOT_SUPPORT;
    }
    return DPD_VSWR_FUNC_SUPPORT;
}
UINT32 BspDpdVswrEnable(UINT32 chan, UINT32 ctrl)
{
    if (chan >= NELEMENTS(s_dpdVswrSupport))
    {
        return BSP_ERROR;
    }
    s_dpdVswrSupport[chan] = ctrl;
    return BSP_OK;
}
UINT32 setWaitDspMode(UINT32 wait_dsp_mode)
{
	s_WaitDspMode = wait_dsp_mode;
	return BSP_OK;
}
UINT32 getWaitDspMode()
{
	return s_WaitDspMode;
}

UINT32 BspSetDpdVswrMode(UINT32 mode) /*0-商用 1-工装*/
{
	s_VswrMode = mode;
	return BSP_OK;
}
UINT32 BspGetDpdVswrMode()
{
	return s_VswrMode;
}
UINT32 BspSetDpdVswrPointNum(UINT32 chan, UINT32 num)
{
	dbgInfo("注意驻波点数范围\n");
	s_VswrPointNum[chan]= num;
	return BSP_OK;
}

UINT32 BspGetDpdVswrPointNum(UINT32 chan)
{
	UINT32  tmp = 0;
	tmp = s_VswrPointNum[chan];
	return tmp;
}

UINT32 BspSetDpdVswrFreqStep(UINT32 freqStep)
{
    s_VswrFreqStep = freqStep;
    return BSP_OK;
}

UINT32 BspGetDpdVswrFreqStep()
{
    return s_VswrFreqStep;
}

T_DpdModulePimCfgFunc *BspGetDpdModuleFuncVal(void)
{
    return &s_DpdModuleFunc;
}

T_OnlinePim2Param *BspGetOnlinePim2Param(void)
{
    return &s_OnlinePim2Param;
}

UINT32 BspSetOnlinePimPowerLevel(UINT32 percent)
{
    s_OnlinePim2Param.powerLevel = percent;
    BspLog(LOG_LEVEL_0, "%s: percent=%u\n", __FUNCTION__, percent);
    return BSP_OK;
}

UINT32 BspSetOnlinePimMode(UINT32 mode)
{
    s_OnlinePim2Param.mode = mode;
    BspLog(LOG_LEVEL_0, "%s: mode=%u\n", __FUNCTION__, mode);
    if (mode == ONLINE_PIM2_MODE_AUTO)
    {
        s_OnlinePim2Param.clearLutFlag = ONLINE_PIM2_NOT_CLEARLUT_DPD;
    }
    return BSP_OK;
}

UINT32 BspSetOnlinePimDpd(UINT32 clearLutFlag)
{
    s_OnlinePim2Param.clearLutFlag = clearLutFlag;
    BspLog(LOG_LEVEL_0, "%s: clearLutFlag=%u\n", __FUNCTION__, clearLutFlag);
    return BSP_OK;
}

UINT32 BspSetPimData(T_PimOnline *pimOnlineData)
{
    BspLog(LOG_LEVEL_0, "%s: func=%p\n", __FUNCTION__, s_DpdModuleFunc.setPimCfgData);
    if (s_DpdModuleFunc.setPimCfgData != NULL)
    {
        return s_DpdModuleFunc.setPimCfgData(pimOnlineData);
    }
    return BSP_OK;
}

UINT32 BspStartPimCfgAnalysis(UINT32 ctrl, INT32 slotIndex)
{
    BspLog(LOG_LEVEL_0, "%s: func=%p chan=%u slotIndex=%u\n", __FUNCTION__, s_DpdModuleFunc.startPimCfgAnalysis, ctrl, slotIndex);
    if (s_DpdModuleFunc.startPimCfgAnalysis != NULL)
    {
        return s_DpdModuleFunc.startPimCfgAnalysis(ctrl, slotIndex);
    }
    return BSP_OK;
}

UINT32 BspGetOnlinePim2(UINT32 rxchnNo, UINT32 *carrNum, T_PimOnlineReportItemDsp *pimOnlineItem)
{
    BspLog(LOG_LEVEL_0, "%s: rxchnNo=%u func=%p\n", __FUNCTION__, rxchnNo, s_DpdModuleFunc.getPimCfgItem);
    if (s_DpdModuleFunc.getPimCfgItem != NULL)
    {
        return s_DpdModuleFunc.getPimCfgItem(rxchnNo, carrNum, pimOnlineItem);
    }
    return BSP_OK;
}

UINT32 BspSetPimTsgFlag(UINT32 bspCh)
{
    return BSP_OK;
}

UINT32 BspStartOnlinePim2(UINT32 chan)
{
    return BSP_OK;
}

/* Started by AICoder, pid:e9421e42abbc4b814a93093c90aa4127a595636e */
UINT32 BspSetRfBrgVswrPreStartSta(UINT32 brgIdx, UINT32 flag)
{
    T_AllRfBridgeInfo info = {0};
    UINT32 portNum = 0;
    UINT32 port = 0;

    if(brgIdx >= VSWR_MAX_RF_BRIDGE_NUM)
    {
        dbgErr("[%s] Bridge Index is Over!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    BspGetRfBridgeInfoMap(&info);
    portNum = info.rfBridgeInfo[brgIdx].rfBridgeOutPort;
    if(portNum >= VSWR_MAX_RF_BRIDGE_PORT_NUM)
    {
        dbgErr("[%s] Get Rf Bridge Port Num is Over!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    for(port = 0; port < portNum; port++)
    {
        BspSetRfBridgeVswrPreStartSta(info.rfBridgeInfo[brgIdx].bridgePortChIdx[port], flag);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:e9421e42abbc4b814a93093c90aa4127a595636e */

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : dpdcommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了DPD对外接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_DPDCOMMON_H_
#define _FUNCLIB_DPDCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "dpdapi.h"
#include "dpd_com.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/

#define DPD_VSWR_FUNC_SUPPORT       0x1
#define DPD_VSWR_FUNC_NOT_SUPPORT   0x0
#define WAIT_DSP_FAST 0
#define WAIT_DSP_SLOW 1

#define DSP_VSWR_NORMAL         0
#define DSP_VSWR_WFS            1
#define DSP_VSWR_NORMAL_8T      2   //商用矢量驻波（DSP在GP位置加塞计算）
#define DSP_VSWR_NORMAL_SIG     5   //商用矢量驻波（不断链路数据基础上加塞计算）

#define VSWR_DEFAULT_RFEQ_STEP  360
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
    

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

typedef UINT32 (*pGetDpdChn)(VOID);

typedef UINT32 (*pDpdGetDifInfo)(UINT32 ulBspChnl, UINT32 ulTrxDir, UINT32 *pulChipId, UINT32 *pulDifChnl);

/**************************************************************************
 *                         函数实现
 **************************************************************************/
T_OnlinePim2Param *BspGetOnlinePim2Param(void);
T_DpdModulePimCfgFunc *BspGetDpdModuleFuncVal(void);

UINT32 dpdinit(UINT32 index);
UINT32 BspGetDspId(UINT32 chan);
UINT32 LoadDspBin(UINT32 dspId,UINT8 *pBuf,UINT32 bufLen);
UINT32 LoadDspAcBin(UINT32 dspId,UINT8 *pBuf,UINT32 bufLen);
UINT32 BspSetDspVerStatus(UINT32 dspVerStatus);
UINT32 BspDpdVswrEnable(UINT32 chan, UINT32 ctrl);
UINT32 BspDdpChnDefCallBackInit(pGetDpdChn pCallBackFunc);
UINT32 BspAcCoreInit(UINT32 acCore);
UINT32 BspGetAcCore();
UINT32 BspGetDspChipChan(UINT32 chan);
UINT32 setWaitDspMode(UINT32 wait_dsp_mode);
UINT32 getWaitDspMode();
UINT32 BspSetDpdVswrMode(UINT32 mode);
UINT32 BspGetDpdVswrMode();
UINT32 BspSetPimTsgFlag(UINT32 bspCh);
UINT32 BspSetDpdVswrPointNum(UINT32 chan, UINT32 num);
UINT32 BspGetDpdVswrPointNum(UINT32 chan);

UINT32 DpdGetDifInfoByBspChnlCallBackInit(pDpdGetDifInfo pCallBackFunc);
UINT32 DpdGetDifInfoByBspChnl(UINT32 ulBspChnl, UINT32 ulTrxDir, UINT32 *pulChipId, UINT32 *pulDifChnl);
UINT32 BspSetDpdVswrFreqStep(UINT32 freqStep);
UINT32 BspGetDpdVswrFreqStep();
UINT32 BspSetRfBrgVswrPreStartSta(UINT32 brgIdx, UINT32 flag);
#ifdef __cplusplus
}
#endif
#endif 




/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : brsadpt.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板的结构体、变量、参数配置
* 注意事项 : 无
* 作    者 : NR2.0
* 创建日期 : 2017-08-27
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _DSPMSG_H_
#define _DSPMSG_H_

#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "udpmsg_ic.h"
#include "dpdcommon.h"
#include "rruinfo.h"
#include "rftable_pacurrentcali.h"

#define DPD_CHAN_CHECK(chan)                     \
    if ((chan) >= BspGetTxChannel())             \
    {                                            \
        dbgErr("%s:chan error!\n",__FUNCTION__); \
        return BSP_ERROR;                        \
    }

#define MAX_DPD_MSG_BODY	(MAX_UPD_MSG_BODY-4)



#define MSG_TYPE_CTRL         		0x0000

#define MSG_TYPE_CFG          		0x4000

#define MSG_TYPE_QUERY        		0x8000
#define DSP_MSG_ID_WATCHDOG_QUERY   0x8005

#define MSG_TYPE_MAINTENANCE  		0xC000



#define MSG_OFFSET_UDP_SRCID			0
#define MSG_OFFSET_UDP_DSTID			1
#define MSG_OFFSET_UDP_MSGHOST			2
#define MSG_OFFSET_UDP_MSGTYPE			3
#define MSG_OFFSET_UDP_MSGID			4
#define MSG_OFFSET_UDP_SERIALNO		    5
#define MSG_OFFSET_UDP_LENGTH			7

// #define MSG_OFFSET_DSP_HEAD          9
// #define MSG_OFFSET_DSP_MSGTYPE       9
// #define MSG_OFFSET_DSP_ADPNUM        11
// #define MSG_OFFSET_DSP_MSGLENGTH     13
// #define MSG_OFFSET_DSP_RESERVE       15
// #define MSG_OFFSET_DSP_TOTALAPDU     17
// #define MSG_OFFSET_DSP_MSGIP         19

/* 各规格需要统一 */
#define DPD_DAT_GRP                1
#define DPD_CHAN_NUM               8
#define POW_GRADE_SUM              7
#define SYSINFO_CFG_CARR_NUM_MAX   8
#define IC_CHAN_NUM_MAX   32

#define DPD_RUN_FLAG 0x5a5a
#define DPD_STOP_FLAG 0x2d2d

#define SW_DPD_ENABLE    0x5A5A
#define SW_DPD_DISABLE   0x2D2D

#define DPD_MSG_TX_POWDATA_CHECKNUM             16
#define DPD_MSG_MAX_CARR_NUM                    16
#define DPD_MSG_MAX_BAND_NUM_PERCHN             5

#define DPD_VSWR_START                          0x00
#define DPD_VSWR_FINISH                         0x01
#define DPD_FB_SAMP_DAT_FAIL                    0x02   /*反馈采数失败*/
#define DPD_FB_CAL_DLY_FAIL                     0x03   /*反馈计算时延失败*/
#define DPD_FB_RHO_FAIL                         0x04   /*反馈RHO值不过*/
#define DPD_GFWD_R_NCO_FAIL                     0x05   /* GSM 读取反馈NCO失败*/
#define DPD_FBP_POW_LOW                         0x06   /* 基带功率过低*/
#define DPD_FWD_POW_LOW                         0x07   /* 反馈功率过低*/
#define DPD_REV_SAMP_DAT_FAIL                   0x12   /*反射采数失败*/
#define DPD_REV_CAL_DLY_FAIL                    0x13   /*反射计算时延失败*/
#define DPD_REV_RHO_FAIL                        0x14   /*反射RHO值不过*/
#define DPD_GREV_R_NCO_FAIL                     0x15   /* GSM 读取反射NCO失败*/
#define DPD_RBP_POW_LOW                         0x16   /* 基带功率过低*/
#define DPD_REV_POW_LOW                         0x17   /* 反射功率过低*/

#define RF_BRIDGE_SAMP_FINISHED                 0x11   /* 电桥机型采数完成*/
#define RF_BRIDGE_SAMP_UNFINISH                 0x22   /* 电桥机型采数未完成*/
#define RF_BRIDGE_SAMP_SUCCESS                  0x00   /* 电桥机型采数成功*/

/* 电桥机型发起驻波类型  0x11：商用驻波，0x22：驻波工装， 0x33：S12离线参数计算；0x44：在线驻波位置检测；0x55扩展*/
#define RF_BRIDGE_VSWR_FORMAL                   0x11
#define RF_BRIDGE_VSWR_PRODUCTION               0x22
#define RF_BRIDGE_VSWR_OFFLINE_CAL              0x33
#define RF_BRIDGE_VSWR_ONLINE_DETECTION         0x44

#define SEND_PA_INFO_LEN                        16
#define PIM_CHK_MAX_NUM                         10
#define ONLINE_TYPE_DL   (UINT32)0
#define ONLINE_TYPE_UL   (UINT32)1
#define ONLINE_TYPE_EVM   (UINT32)2
#define ONLINE_TYPE_EVM_FEEDBACK   (UINT32)3
#define SEND_PARAM_POINT_NUM       (UINT32)1024
#define SIG_FRE_NUM_MAX            (UINT32)1280
#define MSG_PIMOFF_ACP_NUM         (UINT32)6
#define FAST_ADJUSTVOLT_SWITCHON        (0x5a5a)    /*DSP约定开关打开*/
#define FAST_ADJUSTVOLT_SWITCHOFF       (0x2d2d)    /*DSP约定开关关闭*/

#define MSG_PA_VOLT_CTRL_GRP_MAX 4  /*单通道最大频段数量 */
#define MSG_PA_VOLT_IO_GRD_MAX 16  /*消息接口支持的最大GPIO调压档位数量 */
#define MSG_TRAP_EMBED_LUT_LEN_MAX  (UINT32)4100
#define MSG_GAIN_TUNE_TEMP_NUM_MAX (20)  /*按-40~150每10度一个温度，总共是是20个*/

#define PIMONLINEMSG_MAX_CARR_NUM 32
#define PIMONLINEMSG_MAX_CHAN_NUM 32
#define PIMONLINE_RRU_MAX_CHAN_NUM 128  //整机级最大通道数

#define MAX_POWER_LEVEL_CNT             (5)
#define MAX_POINT_PER_POWER_LEVEL       (4096)

#define CFR_STAGE_NUM_MAX        (3)

#define VSWR_SPA_NUM_MAX        1200
#define IC_DSP_CHN_MAX_NUM      8
#define VSWR_MAX_COPY_CARR_NUM  4    /* 电桥最大复制载波数 */
#define VSWR_MAX_AC_WEIGHTS_NUM 300  /* 电桥最大AC权值个数 */

#define DSP_ACTIVE_FLAG_MAX_CARRIERS 32  /* 支持的最大载波数量 */

enum MODE_TYPE
{
    DPD,
    TS ,
    SSC,
    Trapping,
    QEC,
    VSWR,
    PIMC,
    FeedEQ,
    StandardSource,
};

typedef enum IC_AC_TYPE_DEF
{
    DPD_AC_TYPE_DL   = 0, //代表下行
    DPD_AC_TYPE_UL   = 1, //代表上行
    DPD_AC_TYPE_STOP = 2, //代表结束AC
    DPD_VSWR_TYPE_FWD = 3, //代表FWD
    DPD_VSWR_TYPE_REV = 4, //代表REV
    DPD_VSWR_TYPE_STOP = 5, //代表结束VSWR
    DPD_AC_TYPE_INSLOT = 6, ///代表上行inslot
    DPD_AC_TYPE_INSLOT_DL = 7, //代表TDD下行inslot 暂不使用
    DPD_AC_TYPE_FDD_INSLOT_DL = 8, //代表FDD下行inslot
    DPD_AC_TYPE_FDD_INSLOT_UL = 9, //代表FDD上行inslot
    DPD_AC_TYPE_BRIDG_DL = 14, //代表电桥校准下行
    DPD_AC_TYPE_NUM
}IC_AC_TYPE_DEF;

/*************************** API Layer Information ****************************/

#pragma pack(1)

/* 0x01消息--DPD使能/旁路 */
typedef struct tagT_DpdMsgBypass
{
    UINT16 ctrl; /* 0x5A5A:使能;0x2D2D:旁路 */
    UINT16 type; /* 旁路类型，0:下行反馈均旁路 1:旁路下行DPD 2:旁路反馈DPD实际没有2 */
} T_DpdMsgBypass;
typedef struct tagT_DpdMsgBypassAck
{
    UINT16 result;        /* 消息处理结果 */
} T_DpdMsgBypassAck;

/* 0x02消息--DPD启动/停止 */
typedef struct tagT_DpdMsgCtrl
{
    UINT16 ctrl; /* 控制字：0x5A5A，使能；0x2D2D，禁用 */
} T_DpdMsgCtrl;
typedef struct tagT_DpdMsgCtrlAck
{
    UINT16 result;        /* 消息处理结果 */
} T_DpdMsgCtrlAck;

/* 0x1D00消息--抵消启动/停止 模拟抵消，针对接收通道*/
typedef struct tagT_DpdMsgOffsetCtrl
{
    UINT16 ctrl; /* 控制字：0x5A5A，使能；0x2D2D，禁用 */
} T_DpdMsgOffsetCtrl;
typedef struct tagT_DpdMsgOffsetCtrlAck
{
    UINT16 result;        /* 消息处理结果 */
} T_DpdMsgOffsetCtrlAck;

/* 0x1D01消息--设置模拟抵消三个阈值，从"/ata/counteract.txt"中获取 */
typedef struct tagT_DpdMsgCntrctCfg
{
    UINT32 uCntrctTH0;
    UINT32 uCntrctTH1;
    UINT32 uCntrctTH2;
} T_DpdMsgCntrctCfg;
typedef struct tagT_DpdMsgCntrctCfgAck
{
    UINT16 result;        /* 消息处理结果 */
} T_DpdMsgCntrctCfgAck;

/* 0x1D02消息--AIOT整机组网模式 */
typedef struct tagT_DpdMsgNetworkModeCfg
{
    UINT32 uNetworkMode;/* 组网模式 */
    UINT32 auiReserve1;/* 预留字段 */
    UINT32 auiReserve2;/* 预留字段 */
} T_DpdMsgNetworkModeCfg;

typedef struct tagT_DpdMsgNetworkModeCfgAck
{
    UINT16 result;        /* 消息处理结果 */
} T_DpdMsNetworkModeCfgAck;

/*0x03消息 DSP清DPD表格*/
typedef struct tagT_DpdMsgLutClr
{
}T_DpdMsgLutClr;
typedef struct tagT_DpdMsgLutClrAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgLutClrAck;

/* 0x04消息--DPD VSWR 开始控制*/
typedef struct tagT_DpdMsgVswrCtrl
{
	UINT32 vswrstartctr;
	UINT32 sigfreqstep;//频点间隔
	UINT32 sigfrenum;//频点数量
	UINT32 vswrproflag;//驻波流程：0 工装、1商用
}T_DpdMsgVswrCtrl;
typedef struct tagT_DpdMsgVswrCtrlAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgVswrCtrlAck;

/* 0x05消息--FT test */
typedef struct tagT_DpdMsgFtTest
{
    UINT16 testType;   /* 1:SPI接口测试,2:McBsp接口测试 */
    UINT16 testData;   /* 测试数据 */
}T_DpdMsgFtTest;
typedef struct tagT_DpdMsgFtTestAck
{
    UINT16 result;
}T_DpdMsgFtTestAck;

/* 0x06消息--AC启动控制*/
typedef struct tagT_DpdMsgDpctCtrl
{
} T_DpdMsgDpctCtrl;
typedef struct tagT_DpdMsgDpctCtrlAck
{
    UINT16 result;        /* 消息处理结果 */
} T_DpdMsgDpctCtrlAck;

/* 0x07消息--AC启动控制*/
typedef struct tagT_DpdMsgAcCtrl
{
} T_DpdMsgAcCtrl;
typedef struct tagT_DpdMsgAcCtrlAck
{
    UINT16 result;        /* AC 消息处理结果 启动正常：CMD_NORMAL(0x0000) 2. AC进行中：STATUS_NO(0x4444)*/
} T_DpdMsgAcCtrlAck;

/* 0x0B消息--AC参考通道H计算控制*/
typedef struct tagT_DpdMsgAcRefHCalcCtrl
{
}T_DpdMsgAcRefHCalcCtrl;

typedef struct tagT_DpdMsgAcRefHCalcCtrlAck
{
    UINT16 result;        /* AC 消息处理结果 启动正常：CMD_NORMAL(0x0000) 2. AC进行中：STATUS_NO(0x4444)*/
} T_DpdMsgAcRefHCalcCtrlAck;

/* 0x08消息--PIMC启动训练和停止训练启动预训练  */
typedef struct tagT_DpdMsgPimcCtrl
{
    UINT16 ctrl; /* 控制字：0x5A5A?PIMC启动训练;0x2D2D 停止训练;0x5555 启动预训练*/
} T_DpdMsgPimcCtrl;
typedef struct tagT_DpdMsgPimcCtrlAck
{
    UINT16 result;        /* 消息处理结果 */
} T_DpdMsgPimcCtrlAck;

/* 0x09消息--清PIMC 表格*/
typedef struct tagT_DpdMsgPimcClrTbl
{
}T_DpdMsgPimcClrTbl;
typedef struct tagT_DpdMsgPimcClrTblAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgPimcClrTblAck;

/*  0x000D号消息：开始计算AC序列*/
typedef struct tagT_DpdMsgStartAcSeqCalc
{
    UINT32 cellId;   //小区索引，0：小区0,1：小区1
    UINT32 bandWidth;//带宽
    UINT32 radioMode;//4G5G制式
    UINT32 deviate;//偏移
    UINT32 sampleRate;//采样率
    UINT32 pasteCarrFlag;//拼接标志
    UINT32 acType;//上下行
    UINT32 centerBand; //拼接场景下，中间保护带带宽，单位：KHz
    UINT32 acBandLeft;  //拼接场景下，左边有效带宽
    UINT32 acBandRight;  //拼接场景下，右边有效带宽
    UINT32 refChan; //参考通道
    UINT32 preciseDlyFlag; //精时延标志
} T_DpdMsgStartAcSeqCalc;
typedef struct tagT_DpdMsgStartAcSeqCalcAck
{
    UINT16  result;
} T_DpdMsgStartAcSeqCalcAck;

/* 0x0E消息-- pimoffline 启动  DSP收到消息后自动启动固定时延等预处理，然后开始DPD训练,不再需要3.0中cpu发起固定时延的流程*/
typedef struct tagT_DpdMsgPimOfflineStart
{
    UINT32 chan;
    UINT32 reserve[15];
}T_DpdMsgPimOfflineStart;
typedef struct tagT_DpdMsgPimOfflineStartAck
{
} T_DpdMsgPimOfflineStartAck;

/*  0x0010号消息：开始计算VSWR序列*/
typedef struct tagT_DpdMsgStartVswrSeqCalc
{
    UINT32 bandWidth;   //带宽
    UINT32 radioMode;   //4G、5G制式
    UINT32 acType;      //3:FWD计算 4:REV计算
    UINT32 deviate;     //单音频移量，单位KHZ
    UINT32 cellId;      //小区索引，0：小区0,1：小区1
    UINT32 seqType;     //序列类型，0：单音序列，1：宽带序列
} T_DpdMsgStartVswrSeqCalc;
typedef struct tagT_DpdMsgStartVswrWgtCalc
{
    UINT32 acType;      //3:FWD权值计算 4:REV权值计算
} T_DpdMsgStartVswrWgtCalc;


/* 0x11消息--启动OnlinePim  */
typedef struct tagT_DpdMsgOnlinePimCtrl
{
    UINT32 pts_start_port;
    UINT32 pts_start_freq;
    UINT32 pts_start_ctr; /* 控制字：0x5A5A：启动;0x2D2D：停止*/
} T_DpdMsgOnlinePimCtrl;
typedef struct tagT_DspDlCarrSwiInfo
{
    UINT32 uiDlSwitchFlag;      //小区闭塞标志  1:开,0:关
    UINT32 uiRadioMode;         //工作制式，按位分制式
    UINT32 uiCarrId;            //载波编号,从0开始
	UINT32 auiReserve[5];       //保留字段
}T_DspDlCarrSwiInfo;
/* 0x0032 消息，传递小区载波激活标志 */
typedef struct tagT_DspDlCellSwiInfo
{
	UINT32 uiDlValidCarrNum;              /* 下行载波个数 */
	UINT32 auiReserve[7];       //保留字段
	T_DspDlCarrSwiInfo atDlCarrSwiInfo[DPD_UDP_IC42_MAX_CARR_NUM]; /* 下行载波闭塞状态 */
}T_DspDlCellSwiInfo;
typedef struct tagT_DspDlCellSwiInfoAck
{
	UINT16 result; 
}T_DspDlCellSwiInfoAck;
typedef struct tagT_DpdMsgOnlinePimAck
{
    UINT32 result; /* 控制字：0x5A5A：启动;0x2D2D：停止*/
} T_DpdMsgOnlinePimAck;

/*0x4001消息--单个参数设置 */
typedef struct tagT_DpdMsgSetSignalPara
{
    INT32 index_modul;     /* 参数索引0 */
    INT32 index_func;      /* 参数索引1 */
    INT32 par0;      /* 参数0 */
    INT32 par1;      /* 参数1 */
    INT32 par2;      /* 参数2 */
    INT32 par3;      /* 参数3 */
    INT32 par4;      /* 参数4 */
    INT32 par5;      /* 参数5 */
    INT32 par6;      /* 参数6 */
}T_DpdMsgSetSignalPara;
typedef struct tagT_DpdMsgSetSignalParaAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSetSignalParaAck;

/*0x4002消息--设置VSWR参数*/
typedef struct tagT_DpdMsgSetVswrPara
{
    INT32  carrNco;        /* 载波NCO */
    INT32  carrType;       /* 载波制式 */
    INT32  carrIsJumpFreq; /* 载波是否跳频 */
    INT32  vswrParam;      /* 使用的校准表信息,仅8205使用 */
}T_DpdMsgSetVswrPara;
typedef struct tagT_DpdMsgSetVswrParaAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSetVswrParaAck;

/*0x4005消息--设置小区配置*/
typedef struct tagT_DlCarrierInfo
{
    UINT32 dlSwitchFlag;      /* 闭塞标志 */
    UINT32 radioMode;         /* 载波制式 */
    UINT32 carrPow;           /* 载波功率，mW */
    INT32  carrNco1;          /* 一级NCO，kHz */
    INT32  carrNco2;          /* 二级NCO，kHz */
    UINT32 carrBandWidth;     /* 载波带宽，kHz */
    UINT32 uiSubCarrierSpacing; //子载波间隔（用于 5G NR）
    UINT32 uiSsbGscn;           //SSB的GSCN（用于 5G NR）
    UINT32 uiSsbSubBeamValidL;  //SSB发送的低32bit位图（用于 5G NR）
    UINT32 uiSsbSubBeamValidH;  //SSB发送的高32bit位图（用于 5G NR）
    UINT32 uiSsbPeriod;         //SSB循环周期（用于 5G NR）
    int    iFraAHeadAdj;      //帧头调整
    UINT32 uiCarrPortNum;      /*端口号*/
    UINT32 uiCarrId;            //载波编号,从0开始
    UINT32 uiBankId;            // 中频分配的DlBankID,用于配置ap_tune处相位值
    UINT32 uiSsbRfFreq;            // SSB射频频点,单位:khz
    UINT32 carrCopyType;  /*载波复制类型 ，0：不复制；  1：复制 */
    USHORT ssbSymbolFlag;    /* SSB有效符号使能标识,1:使能; 0:去使能*/
    USHORT ssbSymbolIndex;   /* SSB有效符号位置索引,取值0~13 */
    int iReserve;                  // 保留
}T_DlCarrierInfo;

/*0x0203消息--DMIMO配置下发消息*/
typedef struct T_DmmCfgMsgPara
{
    unsigned int uiCarrDmimoSwi;      // 载波对应DMIMO功能是否使能，由高层根据BBU配置解析并下发给DSP
    unsigned int uiCarrId;            // 载波编号，和小区信息中的载波编号是一回事，用于解析DMIMO相关信息时从收到的小区信息中获取对应载波的信息
    unsigned int uiCellId;            // 当前载波所在小区ID,用来区分载波搜索偏移地址
    unsigned int uiCpId;              // 提取信息用到的rruID，实际为当前载波对应的CP内编号，按小区区分，相同小区CP内编号相同
    unsigned int uiDmimoL2dAddr;      // DMIMO时延相位信息搜索L2D起始地址,约定从起始地址往后最多偏移100个样点即可搜索到preamble头
    unsigned int uiDlPreBankId;       // 中频分配的DlPreBankID,用于配置时延值
    unsigned int uiDlPreOriDly;       // 中频配置的DlPre时延值
    unsigned int uiReserve[9];       // 保留字
} T_DmmCfgMsg;

/*0x0204消息--utdoa配置下发消息*/
typedef struct T_UtdoaCfgMsgPara
{
    UINT32 utEn;        // UTDOA使能标志，只要有一个载波使能，则置1，否则置0
    UINT32 caliPeriod;      // UTDOA的校准周期
    UINT32 offset;          // 周期内偏移
    UINT32 uiReserve[5];    // 预留
} T_UtdoaCfgMsg;
typedef struct T_FrameInfoStruct
{
 UINT32 uiTddCfgId; /*  当前是第几套TDD */
 UINT32 uiCarrNo; /* 中频载波号，用于场景预制 */
 UINT32 uiRadioMode;/* 载波制式 */
 UINT32 uiChanMask; /* 从bsp通道掩码转成中频通道掩码 */
 UINT32 uiDlUlSwNum;/* 上下行的切换次数 */
 UINT32 uiDlUlSwPeriod[MAX_UL_DL_SW_NUM];/* 每次上下行切换的周期，单位us */
 UINT32 uiDlSymbolNum[MAX_UL_DL_SW_NUM];/* 每次切换的下行符号数 */
 UINT32 uiUlSymbolNum[MAX_UL_DL_SW_NUM];/* 每次切换的上行符号数 */
}T_FrameInfo;

typedef struct tagT_DpdMsgSetCellCfgPara
{
    UINT32 dlValidCarrNum;                                /* 载波个数 */
    UINT32 loFlg;                                       /* 高低本振标志，0为低本振，1为高本振 */
    UINT32 dlLoFreq;                                      /* 本振频点信息，kHz */
    INT32  fb_nco;                                       /* 对应反馈中频，kHz */
    T_FrameInfo tFrameInfo;                             /* 帧结构配置信息 */
    T_DlCarrierInfo atDlCarrPara[DPD_UDP_IC42_MAX_CARR_NUM];  /* 下行载波配置信息 */
}T_DpdMsgSetDlCellCfgPara;

typedef struct tagT_DpdMsgSetDlCellCfgParaAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSetDlCellCfgParaAck;

/*4012 上行小区信息*/
typedef struct tagT_RruUlCellCfgPara
{
    UINT32 ulSwitchFlag;     /*上行小区闭塞标志*/
    UINT32 radioMode;
    INT32  bankNco;
    INT32  bandNco;
    UINT32 carrBandWidth;
    UINT32 carrPow;
    int    iReserve[6];
}T_RruUlCellCfgPara;
typedef struct tagT_DpdMsgSetUlCellCfgPara
{
    UINT32 ulValidCarrNum;
    UINT32 ulLoFreq;
    T_RruUlCellCfgPara tCellCfgPara[DPD_UDP_IC42_MAX_CARR_NUM];
}T_DpdMsgSetUlCellCfgPara;

typedef struct tagT_DpdMsgSetUlCellCfgParaAck{

    UINT16 result;
}T_DpdMsgSetUlCellCfgParaAck;

/*0x4016消息--发送TS信息*/
typedef struct tagT_CellTsData
{
    UINT32 carrNo;
    UINT32 cellId;
    UINT32 radioMode;
    UINT32 txFreq;
    UINT32 rxFreq;
    UINT32 txBandWitdh;
    UINT32 rxBandWitdh;
    UINT32 cfgCarrPwr;
    INT32 carrNco;
    INT32 bandNco;
    INT32 tranNco;
    INT32 fbNco;
}T_CellTsData;

typedef struct tagT_DpdMsgCellTsInfo
{
    UINT32 cellNum;
    UINT32 txLo;
    UINT32 fbLo;
    UINT32 dpdTxRate;
    UINT32 dpdFbRate;
    UINT32 dflStartFreq;
    UINT32 dflEndFreq;
    T_CellTsData cellTsData[DPD_UDP_IC42_MAX_CARR_NUM];
}T_DpdMsgCellTsInfo;

typedef struct tagT_DpdMsgCellTsInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgCellTsInfoAck;

#define PA_CURR_CALI_MAX_LINE (20)

typedef struct
{
    UINT32 ulCurrent;
    UINT32 ulAdVal;
    UINT32 ulTemp;
    UINT32 ulReserve[5];
} T_PaCurAdRecordInfo;

typedef struct
{
    UINT32 ulPaChan;
    UINT32 ulDacIndex;
    UINT32 ulAdcPath;
    UINT32 ulVbiasType;
    UINT32 ulCurrentDetectIndex;
    UINT32 ulCurrentNum;
    UINT32 ulReserve[10];
    T_PaCurAdRecordInfo curAdRecord[TBL_PA_CUR_N_VALUE];
} T_PaCurrCaliInfo;

typedef struct
{
    UINT32 ulCurAdRecordNum;
    UINT32 ulCurAdLoadFlag;
    T_PaCurrCaliInfo tPaCurrCaliInfo[PA_CURR_CALI_MAX_LINE];
} T_DpdMsgSendPaCurrCali;

typedef struct
{
    UINT16 result;
} T_DpdMsgSendPaCurrCaliAck;

typedef struct tagT_DpdMsgAcpCalResult
{
}T_DpdMsgAcpCalResult;

typedef struct tagT_DpdMsgAcpCalResultAck
{

    INT32 acp_state;               /** 当前计算状态 **/
    INT32 acp_channel;             /** 当前计算的通道 **/
    INT32 acp_left;                /** ACPR左邻带计算值 **/
    INT32 acp_right;               /** ACPR右邻带计算值 **/
    USHORT reserve[4];              /** 保留待后续扩展*/
}T_DpdMsgAcpCalResultAck;

/*0x4006消息--发送整机硬件信息*/
typedef struct T_HwTxChInfoStruct
{
    UINT32 fullPow;      /* 额定功率，mW */
    UINT32 bandNum;
    UINT32 txDflFreqL[DPD_MSG_MAX_BAND_NUM_PERCHN];    /* 发送双工器低频点，kHz */
    UINT32 txDflFreqH[DPD_MSG_MAX_BAND_NUM_PERCHN];    /* 发送双工器高频点，kHz */
    UINT32 tddNo;           /*通道对应的tdd编号*/
    UINT32 reserve[10];     /* 保留 */
}T_HwTxChInfo;
typedef struct T_HwRxChInfoStruct
{
    UINT32 bandNum;
    UINT32 rxDflFreqL[DPD_MSG_MAX_BAND_NUM_PERCHN];    /* 接收双工器低频点，kHz */
    UINT32 rxDflFreqH[DPD_MSG_MAX_BAND_NUM_PERCHN];    /* 接收双工器高频点，kHz */
    UINT32 reserve[11];     /* 保留 */
}T_HwRxChInfo;

typedef struct T_DspRouterStruct
{
    UINT32 cfrport[DPD_CHAN_NUM]; //削峰算法模块出口通道号：0~31；   blockId = uiCfrPort/8；  logicChan = uiCfrPort%8;
    UINT32 cfrportnum;            //一个中频通道号对应的削峰通道数（出于高频场景等考虑）
    UINT32 dpdport[DPD_CHAN_NUM]; //DPD算法模块出口通道号：0~31；   blockId = uiDpdPort/4；  logicChan = uiDpdPort%4;
    UINT32 dpdportnum;            //一个中频通道号对应的DPD通道数（出于高频场景、ET/DPA模式等考虑）
    UINT32 dlpostPort[DPD_CHAN_NUM]; //Dlpost模块出口通道号：0~7；   blockId = uiDlpostPort/4；  logicChan = uiDlpostPort%4;
    UINT32 dlpostPortNum; //一个中频通道号对应的Dlpost通道数
    UINT32 uiFbPort;  //反馈路由选择
    UINT32 cfrsamprate;           //出口，单位khz
    UINT32 src2samprate;          //出口，单位KHz
    UINT32 src3samprate;          //出口，单位KHz
    UINT32 fb204csamprate;        //出口，单位KHz
    UINT32 dpdmode;               //七种基础模式，对应寄存器配置值
    UINT32 etmode;                //对应寄存器
    UINT32 uiCfrBlockPortNum;     //一个cfr block使用的通道数
    UINT32 uiStagePortNum;        //一个削峰stage支持的频段数
    UINT32 uiPortType;             /** 通道子母端类型，bit[0:3]:通道就绪状态，0：未就绪，1：就绪；bit[4:7]:子母端类型，0：母端，1：子端 */
    UINT32 uiDflType;              /** 通道双工方式类型，0：TDD，1：FDD */
    UINT32 reserve[4];            //保留
}T_DspDlRouter;

#define MSG_CFR_BLK_NUM_MAX   (unsigned int)4
#define MSG_DPD_BLK_NUM_MAX   (unsigned int)8
#define MSG_DLPOST_BLK_NUM_MAX   (unsigned int)8
#define MSG_FB_CTRL_TYPE_NUM_MAX   (unsigned int)2
#define MSG_FB_CTRL_SLICE_NUM_MAX   (unsigned int)16
/** 下行链路时钟配置*/
typedef struct
{
    UINT32 cfrClk[MSG_CFR_BLK_NUM_MAX];
    UINT32 dpdClk[MSG_DPD_BLK_NUM_MAX];
    UINT32 dlpostClk[MSG_DPD_BLK_NUM_MAX];
}T_DlClkInfo;

/**反馈时间片配置*/
typedef struct
{
    UINT32 fbCtrlTypeNum;     /** 反馈时间片类型数量 */
    UINT32 fb2DlMsk[MSG_FB_CTRL_TYPE_NUM_MAX];    /** 各套控制信息对应的通道掩码 */
    UINT32 fbCtrlSliceNum[MSG_FB_CTRL_TYPE_NUM_MAX];   /** 各套控制信息包含的切片个数 */
    UINT32 fbCtrlInfo[MSG_FB_CTRL_TYPE_NUM_MAX][MSG_FB_CTRL_SLICE_NUM_MAX];  /** bit[0:15]:时间长度,bit[16:31]:控制类型： */
}T_FbCtrlInfo;

#define MSG_MAX_FREQ_NUM (8U)                       /* IC4.2支持的最大频段数 */
/* DSP路由结构体,参考 T_DifDspRoute */
typedef struct
{
    UINT32 uiCfrPort[MSG_MAX_FREQ_NUM];             /* 削峰算法模块入口通道号：0~7； D4.2 CFR只有一个block */
    UINT32 uiCfrPortNum;                            /* 一个中频通道号对应的削峰通道数（出于高频场景等考虑）*/
    UINT32 uiCfrBlockInPort[MSG_MAX_FREQ_NUM];      /* dlbank出口通道号，即cfr router0前的频段号 */
    UINT32 uiCfrBlockInPortNum;                     /* 一个中频通道号对应的dlbank通道数目 */
    UINT32 uiDpdPort[MSG_MAX_FREQ_NUM];             /* DPD算法模块出口通道号：0~7； blockId = uiDpdPort/4；logicChan = uiDpdPort%4 */
    UINT32 uiDpdPortNum;                            /* 一个中频通道号对应的DPD通道数（出于高频场景、ET/DPA模式等考虑）*/
    UINT32 uiDlpostPort[MSG_MAX_FREQ_NUM];          /* Dlpost模块出口通道号：0~7；   blockId = uiDlPostPort/4；  logicChan = uiDlPostPort%4 */
    UINT32 uiDlpostPortNum;                         /* 一个中频通道号对应的Dlpost通道数 */
    UINT32 uiFbPort;                                /* 反馈路由选择 */
    UINT32 uiCfrSampRate;                           /* 出口，单位khz */
    UINT32 uiSrc2SampRate;                          /* 出口，单位KHz */
    UINT32 uiSrc3SampRate;                          /* 出口，单位KHz */
    UINT32 uiFb204cSampRate;                        /* 出口，单位KHz */
    UINT32 uiDpdMode;                               /* dpd模式, 0:4T正常单相；1:4T简单两相；2:2T正常两相；0xff：无效 */
    UINT32 uiEtMode;                                /* D4.2暂不使用，赋无效值0xff */
    UINT32 uiCfrBlockPortNum;                       /* 一个cfr block使用的通道数 TODO:使用该参数配置削峰stage与4.0有出入 */
    UINT32 uiStagePortNum;                          /* 一个削峰stage支持的频段数 TODO:使用该参数配置削峰stage与4.0有出入 */
    UINT32 uiStageId;                               /* 每通道对应起始StageId号：0-4 */
    UINT32 uiCfrGrade;                              /* 削峰级数 0：一级 1：二级 2：三级 */
    UINT32 uiPortType;                               /** 通道子母端类型，bit[4:7]:通道就绪状态，0：未就绪，1：就绪；bit[0:3]:子母端类型，0：母端，1：子端 */
    UINT32 uiDflType;                               /** 通道双工方式类型，0：TDD，1：FDD */
    UINT32 uiReserve[15];                           /* 预留字段 */
} T_MsgDspRoute;

typedef struct tagT_DpdMsgSendRruInfo
{
    UINT32 validDlChanNum;        /* TX有效通道数*/
    UINT32 validUlChanNum;        /* RX有效通道数*/
    UINT32 moduleGrpId;           /* 模块组ID */
    UINT32 boardGrpId;        /* 单板组 */
    UINT32 boardTypeId;       /* 单板类型 */
    UINT32 hwChangeId;       /* 硬件变更ID */
    UINT32 hwDefIdA;       /* 硬件自定义ID A */
    UINT32 hwDefIdB;       /* 硬件自定义ID B */
    UINT32 paType;              /* 功放类型，PaFactoryId字段的数字部分，默认值是0 */
    UINT32 exceptReason;     /*异常原因*/
    UINT32 exceptChanMask;   /*异常掩码*/
    UINT32 rfBridgeFlag;      /*电桥机型标志*/
    UINT32 reserve[5];            /* 保留 */
    T_HwTxChInfo dlChanHwInfo[IC_CHAN_NUM_MAX];     /** 通道硬件配置信息 */
    T_MsgDspRoute dspDlRouteInfo[IC_CHAN_NUM_MAX];  /** 通道路由配置信息 */
    T_HwRxChInfo ulChanHwInfo[IC_CHAN_NUM_MAX];     /** 通道硬件配置信息 */
    T_DlClkInfo tDlClkInfo;        /** 下行链路时钟配置 */
    T_FbCtrlInfo tFbCtrlInfo;      /** 反馈时间片配置 */
}T_DpdMsgSendRruInfo;
typedef struct tagT_DpdMsgSendRruInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSendRruInfoAck;
typedef struct tagT_ACMsgSendRruInfo
{
    UINT32 fullPow;         /* 额定功率，mW */
    UINT32 paType;          /* 功放类型，0表示LDMOS，1表示GaN */
    UINT32 txDflFreqL;      /* 发送双工器低频点，kHz */
    UINT32 txDflFreqH;      /* 发送双工器高频点，kHz */
    UINT32 rxDflFreqL;      /* 接收双工器低频点，kHz */
    UINT32 rxDflFreqH;      /* 接收双工器高频点，kHz */
    UINT32 moduleGrpId;     /* 模块组ID */
    UINT32 boardGrpId;      /* 单板组 */
    UINT32 boardTypeId;     /* 单板类型 */
    UINT32 hwChangeId;      /* 硬件变更 */
    UINT32 fpgaDpdType;     /* Fpga DPD 能力，
                                高16bit：0对应单相，1对应多相；
                                低16bit：0对应单频，1对应双频
                            */
    UINT32 reserve1;         /* 驻波校准的频率间隔,即VswrParam.txt中频率步进vswrCaliFreqStep */
    UINT32 reserve2;        /* 保留字段2 */
    UINT32 reserve3;        /* 保留字段3 */
    UINT32 reserve4;        /* 保留字段4 */
    UINT32 reserve5;        /* 保留字段5 */
}T_ACMsgSendRruInfo;

typedef struct tagT_ACMsgSendRruInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_ACMsgSendRruInfoAck;

/* 0x0018消息*/
typedef struct tagT_DpdDmmCtrlMsg
{
    UINT32 uiDmmCtrlSwi; /* ，0x5A5A:开，0x2D2D:关 */
    UINT32 uiReserve[3]; /* 保留字*/
} T_DpdDmmCtrlMsg;
typedef struct tagT_DpdDmmCtrlMsgAck
{
    UINT32 result;
} T_DpdDmmCtrlMsgAck;
/*0x0202消息--控制DMIMO配置信息清零的消息*/
typedef struct
{
    unsigned int uiDmmCfgClrFlg;    /* 0:不清，1:清时延相位补偿值 */
    unsigned int uiReserve[3];      /* 保留字*/
} T_DmmCfgInfoClrMsg;
/*0x0019消息*/
typedef struct
{
    unsigned int uiFuncSwi;  /* 调压功能开关 */
    unsigned int uiTopoType;  /* 拓扑协议类型，0-cpri，1-lr，2-qcell */
    unsigned int uiChMsk;  /* 调压组包含的通道掩码，按位有效 */
    unsigned int uiVldGrdNum;  /* 有效负载档位数量 */
    unsigned int uiPaVolt[MSG_PA_VOLT_GRD_MAX];  /* 电压档位对应的电压值，对应负载档位原始电压值，单位：mv */
    unsigned int uiCfLevelNum;  /** 削峰级数 */
    unsigned int uiCFRLevelTh[MSG_PA_VOLT_GRD_MAX][3];   /* 削峰门限 */
    unsigned int uiVoltCtrlStep;  /* 电压调整步长，管脚值变化1对应的调整量，单位：mv */
    unsigned int uiVoltCtrlMax;  /* 单次最大调节量 单位：调整量(mv)/uiVoltCtrlStep */
    unsigned int uiIoAddr[3];  /* 电压控制管脚地址，物理地址，依次代表置1寄存器、置零寄存器、数据寄存器*/
    unsigned int uiIoLevelNum;  /* GPIO电压档位数目 */
    unsigned int uiIoMap[MSG_PA_VOLT_IO_GRD_MAX];  /* 每个电压档位的GPIO真值表 */
    unsigned int uiIoBitMask;  /* 电压控制管脚地址掩码，32位掩码 */
    unsigned int uiReserve[5];  /* 保留字段 */
}T_DpdSlotVoltGrpCtrlInfo;
/* 调压控制信息 */
typedef struct
{
    unsigned int uiCtrlGrpIdx;  /* 调压组ID*/
    T_DpdSlotVoltGrpCtrlInfo atVoltSlotCtrl;  /* 调压控制信息 */
}T_DpdSlotVoltCtrlInfo;

/* 调压回复消息 */
typedef struct
{
    unsigned int uwResult;  /* 消息处理结果  */
    unsigned int uiCtrlGrpIdx;  /*调压组ID*/
    unsigned int uiCtrlFlg;  /* 功能控制结果告警码 */
}T_DpdSlotVoltCtrlInfoAck;

/*0x001a消息*/
typedef struct
{
    unsigned int uiCtrlGrpNum;  /* 调压组有效数量  */
    unsigned int uiChMsk[MSG_PA_VOLT_CTRL_GRP_MAX];  /* 调压组包含的通道掩码，按位有效 */
}T_DpdSlotVoltGrpInfo;

/* 调压组回复消息 */
typedef struct
{
    unsigned short uwResult;  /* 消息处理结果  */
}T_DpdSlotVoltGrpInfoAck;

/*0x001c消息*/
typedef struct 
{
    unsigned int uiCtrlFlg;     /*预埋表提取控制标志, 0x5a5a:启动，0xFFFF：打断*/
    unsigned int uiVoltGrd;     /*预埋表提取对应的电压档位*/
    unsigned int uiChMsk;       /*预埋表提取对应的通道掩码，按位有效*/
    unsigned int uiReserve[5];  /*保留字段*/
}T_TrapEmbedLutCtrlMsg;

/*预埋表提取控制消息回复*/
typedef struct
{
    unsigned short uwResult;   /*消息处理结果*/
}T_TrapEmbedLutCtrlMsgAck;

/*0x4007消息--传递功率调整信息(功率调整计数器)*/
typedef struct tagT_DpdMsgSendPowAdjInfo
{
    UINT32 powAdjCnt;      /* 功率调整次数 */
    UINT32 reserve1;        /* 保留字段1 */
    UINT32 reserve2;        /* 保留字段2 */
    UINT32 reserve3;        /* 保留字段3 */
    UINT32 reserve4;        /* 保留字段4 */
    UINT32 reserve5;        /* 保留字段5 */
}T_DpdMsgSendPowAdjInfo;
typedef struct tagT_DpdMsgSendPowAdjInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSendPowAdjInfoAck;

/*0x4010消息---时隙配比信息下发*/
typedef struct tagT_FramePatternInfo
{
    UINT32 slotIndex;     //S时隙索引
    UINT32 gpNum;         //对应的GP符号数量
    UINT32 reserves[30];  //保留字段
} T_FramePatternInfo;
typedef struct tagT_FramePatternInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_FramePatternInfoAck;

/*0x4011消息--传递功放信息*/
typedef struct tagT_DpdMsgSendPaInfo
{
    INT8 paDesign[SEND_PA_INFO_LEN];           /* 功放类型PaBasicInfo.txt  paDesign字段*/
    INT8 ruProductTime[SEND_PA_INFO_LEN]  ;    /* 整机生产时间RruInfo.txt  ProductTime字段  功放生产时间不可靠*/
    UINT32 reserve[30];          /* 保留字段2 */
}T_DpdMsgSendPaInfo;
typedef struct tagT_DpdMsgSendPaInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSendPaInfoAck;

/*0x4015消息--传递CFR_OUT与DPD_IN的路由信息*/
typedef struct tagT_DpdMsgSendCfrDpdRouteInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSendCfrDpdRouteInfoAck;
/*0x4018消息--传递反馈链路补偿信息*/
typedef struct tagT_DpdMsgSendFwdParam
{
    UINT32 startFreq;           /* 起始频点*/
    UINT32 freqStep;            /* 步进*/
    UINT32 freqNum;             /* 频点数*/
    UINT32 bandId;            /* band编号 */
    UINT32 reserve1;            /* 保留字段2 */
    INT32  gainComp[SEND_PARAM_POINT_NUM];       /*反馈增益补偿值*/
}T_DpdMsgSendFwdParam;
typedef struct tagT_DpdMsgSendFwdParamAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSendFwdParamAck;

/*0x4019消息--传递双工器补偿信息*/
typedef struct tagT_DpdMsgSendFilterParam
{
    UINT32 startFreq;           /* 起始频点*/
    UINT32 freqStep;            /* 步进*/
    UINT32 freqNum;             /* 频点数*/
    UINT32 bandId;            /* band编号 */
    UINT32 reserve1;            /* 保留字段2 */
    INT32  gainComp[SEND_PARAM_POINT_NUM];       /*双工器增益补偿值*/
}T_DpdMsgSendFilterParam;
typedef struct tagT_DpdMsgSendFilterParamAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSendFilterParamAck;
/*0x4021消息：动态调压电源开关相关参数*/
typedef struct tagT_DpdMsgFastAdjVoltSwitch
{
    UINT32  fastAdjVoltSw;      /* 动态调压开关0x5a5a打开，0x2d2d关闭 */
    UINT32  voltStep;           /* 调压步长 mV */
    UINT32  voltPerTimeMax;     /* 单次最大调节量,电源能力 */
    UINT32  voltLevelNum;       /* GPIO电压档位数目 */
    UINT32  gpioMap[16];        /* 每个电压档位的GPIO真值表 */
}T_DpdMsgFastAdjVoltSwitch;

typedef struct tagT_DpdMsgFastAdjVoltSwitchAck
{
    UINT16 result;              /* 消息处理结果 */
}T_DpdMsgFastAdjVoltSwitchAck;

/*0x4022消息：动态调压参数配置*/
typedef struct tagT_DpdMsgFastAdjVoltPara
{
    UINT32  LevelNum;           /* 有效负载档位数量*/
    UINT32  PowerLevel[8];      /* 功率档位 */
    UINT32  PaVolt[8];          /* 电压档位 */
    UINT32  CFRLevel[8][3];     /* 削峰档位 */
    UINT32  DPDLevel[8];        /* DPD档位 */
    UINT32  SSCLevel[8];        /* SSC档位 */
    UINT32  TSGainLevel[8];     /* TS Gain档位 */
    UINT32  resv[8];            /* 保留字段 */
}T_DpdMsgFastAdjVoltPara;

typedef struct tagT_DpdMsgFastAdjVoltParaAck
{
    UINT16 result;              /* 消息处理结果 */
}T_DpdMsgFastAdjVoltParaAck;

/*0x4024消息：trap预埋表参数 */
typedef struct tagT_TrapEmbedLutDwMsg
{
    UINT32 ch;          /* 表格对应的通道号 */
    UINT32 grdVldMsk;   /* 档位有效性掩码，各档位按bit有效，1: 有效，0: 无效 */
    UINT32 reserve[6];  /* 保留字段 */
    UCHAR lutDat[MSG_TRAP_EMBED_LUT_LEN_MAX]; /** 下发的表格数据 */
}T_TrapEmbedLutDwMsg;

typedef struct tagT_TrapEmbedLutDwMsgAck
{
    UINT16 result;              /* 消息处理结果 */
}T_TrapEmbedLutDwMsgAck;

/*0x4025消息：增益相位补偿表参数 */
typedef struct{
    INT32 gainVal;  /* 增益补偿值,定标：待定 */
    INT32 phaVal;  /* 相位补偿值,定标：待定 */
    UINT32 vldFlg;  /* 有效标志，0X5A5A:有效，0x2D2D:无效 */
}T_VoltGainTuneInfo;

typedef struct tagT_VoltGainTuneTblSetMsg
{
    UINT32 reserve[64];  /* 保留字段 */
    T_VoltGainTuneInfo atTbl[MSG_GAIN_TUNE_TEMP_NUM_MAX * MSG_PA_VOLT_GRD_MAX];  /* 下发的表格数据, 排列格式为：通道*温度*档位*/
}T_VoltGainTuneTblSetMsg;

typedef struct tagT_VoltGainTuneTblSetMsgAck
{
    UINT16 result;  /* 消息处理结果 */
}T_VoltGainTuneTblSetMsgAck;

/*0x8001消息--DSP状态查询，StateCheckMsgCMD*/
/*说明wDspSta 状态 见牛坤文档说明*/
/*
无符号整数
TSK_DATA_SAMP   = (0x03)   数据采集任务
TSK_DATA_PROC   = (0x04) 数据预处理任务
TSK_DATA_CHK    = (0x05) 数据检查任务
TSK_DATA_FILT   = (0x06) 数据筛选任务
TSK_MEM_PROC    = (0x08) 记忆任务
TSK_WAITING     = (0x0C) 等待自适应启动
TSK_CAL_G3      = (0x09) 固定G3任务
TSK_FIX_DLY      = (0x0A) 固定时延任务
*/
typedef struct tagT_DpdMsgStateQuery
{
} T_DpdMsgStateQuery;

#define FIX_DLY_FINISH       0x11
#define FIX_DLY_CALC         0x22
#define FIX_DLY_UNFINISH     0xFF

typedef struct tagT_DpdMsgStateQueryRet
{
    UINT32  iDownLutCnt; /* 各档位下表数之和 */
    UINT32  iFixDlySta;  /* 固定时延状态 */
} T_DpdMsgStateQueryRet;

typedef struct tagT_DpdMsgStateQueryAck
{
    UINT32  iDownLutCnt; /* 各档位下表数之和 */
    UINT32  iFixDlySta;  /* 固定时延状态 */
    UINT32  iReserve[30];/*暂时保留*/

} T_DpdMsgStateQueryAck;

/*0x8002消息--查询DSP版本信息 */
typedef struct tagT_DpdMsgVerQuery
{
}T_DpdMsgVerQuery;
typedef struct tagT_DpdMsgVerQueryAck
{
    UINT8 *pdspVer;
}T_DpdMsgVerQueryAck;

/*0x8003消息--全局参数查询 */
typedef struct tagT_DpdMsgParamQuery
{
    UINT16 powGrd;       /* 功率等级 */
    UINT16 parType;      /* 是否查询依赖于特定通道的参数
                            0：采数相关参数
                            1：单组数据检查相关参数
                            2：数据处理相关参数
                            3：表格提取相关参数（除        DPD多项式结构）
                            4：表格结构相关参数
                            5：表格检查相关参数
                            6：小区制式相关参数
                          */
}T_DpdMsgParamQuery;

/* 参数属性为0：数据采集相关参数： */
typedef struct tagT_DpdSamplePara
{
    UINT32 freqNum;          /* 总分频段数 */
    UINT32 powGrdNum;        /* 总分档位数 */
    UINT16 sampleMode[8];    /* 最多8数据采数模式 */
    UINT16 sampleFiltFreq[8];/* 最多8组数据，各组对应的频段筛数选择 */
    UINT16 lteSampPos[8];    /* 最多8组数据，各组对应的LTE采数位置 */
    UINT16 gsmSampPos[8];    /* 最多8组数据，各组对应的GSM采数位置 */
} T_DpdSamplePara;

/* 参数属性为1：单组数据检查相关参数：*/
typedef struct tagT_DpdCheckPara
{
    UINT32 freqNum;          /* 总分频段数 */
    UINT32 powGrdNum;        /* 总分档位数 */

    FLOAT   txAbsPowMaxThr;  /* 前向合路abs过大检查门限 */
    FLOAT   txAvgPowMinThr;  /* 前向合路平均功率过小检查门限 */
    FLOAT   fbAbsPowMaxThr;  /* 反馈合路abs过大检查门限 */
    FLOAT   fbAvgPowMinThr;  /* 反馈合路平均功率过小检查门限 */
    FLOAT   demoGainAlignThrDown;  /*  IQ校正增益过小门限 */
    FLOAT   demoGainAlignThrUp;    /* IQ校正增益过大门限 */
    FLOAT   demoPhaAlignThrDown;   /* IQ校正相位过小门限 */
    FLOAT   demoPhaAlignThrUp;     /* IQ校正相位过大门限 */
    FLOAT   segAvgPowCheckThr;     /* 前向分频段分段平均功率检查门限 */
    FLOAT   fbCheckByFreqThr;      /* 反馈分频段平均功率检查门限 */
    FLOAT   bandValidThr;    /* /频段有效性判断门限 */
    DOUBLE  fbFreqDelt;      /* 反馈中频频差   默认值(-21420)-新旧本振频差 */
}T_DpdCheckPara;

/* 参数属性为2：数据处理相关参数： */
typedef struct tagT_DpdHandlePara
{
    UINT32  freqNum;       /* 总分频段数 */
    UINT32  powGrdNum;     /* 总分档位数 */

    UINT32  dlyCalStart;   /* 时延搜索起 */
    UINT32  dlyCorrNum;    /* 相关数据长度 */
    UINT32  dlySearchNum;  /* 搜索时延长度 */
    UINT32  dlyFreqErrThr; /* 频段间时延差门限 */
    UINT32  dlyGrpErrThr;  /* 多组间时延差门限 */
    FLOAT   phaFreqErrThr; /* 频段间相位对齐差门限 */
    FLOAT   gainFreqErrThr;/* 频段间增益对齐差门限 */
    FLOAT   rhoChkThr;     /* 相关系数检查门限 */
    FLOAT   absDatThr;     /* 前向绝对值 */
    FLOAT   absRatioThr;   /* 前向反馈绝对值比值 */
}T_DpdHandlePara;

/* 参数属性为3：表格提取相关参数（除DPD多项式结构）*/
typedef struct tagT_DpdTableDrawPara
{
    UINT32  freqNum;       /* 总分频段数 */
    UINT32  powGrdNum;     /* 总分档位数 */

    FLOAT   factoriaNew;   /* 新R矩阵插值比例 */
    FLOAT   factorialOld;  /* 老R矩阵插值比例 */
    FLOAT   stdNew ;       /* 信号权重 */
    FLOAT   stdOld ;       /* 标准源权重 */
    FLOAT   pwRmatrixWeight; /* 分段加权值 */
    FLOAT   rhrValue[8];     /* 各组数据生成的R矩阵加权 */
    DOUBLE  RNoiseROrg[3];   /* 各种DPD类型初始R矩阵加噪信噪比 */
    DOUBLE  RNoiseZOrg[3];   /* 各种DPD类型初始Z矩阵加噪信噪比 */
    FLOAT   stretchValue;    /* 索引拉伸值 */
    UINT32  fixValDsp;       /* 表格内容定标 */
    FLOAT   segPowIndex;     /* 分段功率计算截位 */
    FLOAT   quanlityValue;   /* 构造R矩阵数据量化 */
    FLOAT   avg;             /* 归一化均值 */
    FLOAT   variance;        /* 归一化方差 */
    FLOAT   quanlityPIndexFreq;    /* Q索引截位 */
    FLOAT   pwThr[3];        /* DPD分段门限 */
    UINT32  chanFreqNum;     /* 通道支持的频段数   0:单频段   1:双频段 */
}T_DpdTableDrawPara;


/* 参数属性为4：表格结构相关参数
 注：该参数属性，每个频段最多支持4组，具体选择哪一组表
 首先由配置类消息配置好组别，然后在通过该消息查询。
*/
typedef struct
{
    UINT32  freqNum;       /* 总分频段数 */
    UINT32  powGrdNum;     /* 总分档位数 */

    UINT32  klut[9];       /* 多项式拟合阶数 */
    UINT32  lutDly[9];     /* 表格数据时延值 */
    UINT32  indexDly[9];   /* 索引时延 */
    UINT32  constFlag[9];  /* 常数项标志 */
    UINT32  indexDlyAnotherFreq[9]; /* 另一频段索引时延 */
    UINT32  klutAnotherFreq;        /* 另一频段索引阶数 */
}T_DpdTableStuctPara;

/* 参数属性为5：表格检查参数 */
typedef struct tagT_DpdTableCheckPara
{
    UINT32  freqNum;      /* 总分频段数 */
    UINT32  powrGrdNum;   /* 总分档位数 */

    FLOAT   gainNegativeThr;   /* 表格增益需要往正向调整门限 */
    FLOAT   gainPositiveThr;   /* 表格增益需要往负向调整门限 */
    FLOAT   lutGainGateDown;   /* 表格增益过小门限 */
    FLOAT   lutGainGateUp;     /* 表格增益过大门限 */
    FLOAT   adjNStep;          /* 表格增益负向调整步进 */
    FLOAT   adjPStep;          /* 表格增益正向调整步进 */
    FLOAT   lutPeakThr;        /* 表格峰值检查门限 */
    FLOAT   lutPeakGainThr;    /* 表格峰值增益门限 */
    UINT32  maxThr;            /* I^2+Q^2大于该门限的点的最大峰值增益 */
    FLOAT   adjNStepI;         /* 表格相位负向调整步进I */
    FLOAT   adjNStepQ;         /* 表格相位负向调整步进Q */
    FLOAT   adjPStepI;         /* 表格相位正向调整步进I */
    FLOAT   adjPStepQ;         /* 表格相位正向调整步进Q */
    FLOAT   lutPhaAdjNThr;     /* 表格相位需要正向调整的门限 */
    FLOAT   lutPhaAdjPThr;     /* 表格相位需要负向调整的门限 */
    FLOAT   phaNegativeThr;    /* 表格相位过小检查门限 */
    FLOAT   phaPositiveThr;    /* 表格相位过大检查门限 */
    FLOAT   lutRhoThr;         /* 表格rho检查门限 */
    FLOAT   lutGainThrDown;    /* 表格有效性校验相关 */
    FLOAT   lutGainThrUp;      /* 表格有效性校验相关 */
    FLOAT   lutRhoValidThr;    /* 表格有效性校验相关 */
}T_DpdTableCheckPara;

/*参数属性为6，小区制式相关参数*/
typedef struct
{
    UINT32 freqNum; /* 频段总数 */
    UINT32 cellMode;/* 该通道小区制式 */
    FLOAT  carrNco[DPD_MSG_MAX_CARR_NUM];  /* 改频段16个载波的1级NCO(单位Hz)没有载波上报为0.0f*/
    UINT32 carrMode[DPD_MSG_MAX_CARR_NUM]; /* 该频段16个载波的制式配置，没有载波上报为*/
    UINT32 freqMode;   /* 该频段小区制式 */
    UINT32 gsmJump;    /* 该频段Gsm是否调频 */
}T_RxWorkModePara;

/*0x8004消息--DSP运行状态诊断参数查询 */
typedef struct tagT_DpdMsgDiagParaQuery
{
    UINT16 powGrd;         /* 功率等级 */
} T_DpdMsgDiagParaQuery;

typedef struct tagT_DpdMsgDiagParaQueryAck
{
    UINT32  freqNum;       //总分频段数
    UINT32  powGrdNum;     //总分档位数
    UINT32  sampleFaileCnt;   //DSP采数失败次数
    UINT16  fpgaModeForce; //FPGA采数模式（回读寄存器）
    UINT16  fpgaHighGate;  //FPGA筛数门限（回读寄存器）
    UINT32  txDatFloCnt;  //前向数据溢出检查不过次数（公共）
    FLOAT   txDatFlo;      //前向数据溢出值（公共）
    UINT32  txAverFailCnt;    //前向数据平均功率过小次数（公共）
    FLOAT   txAverFail;    //前向数据平均功率过小值（公共）
    UINT32  demoGainFailCnt;  //IQ校正增益检查不过次数
    FLOAT   demoGainFailVal;   //IQ校正增益检查不过值
    UINT32  demoPhaFailCnt;   //IQ校正相位检查不过次数
    FLOAT   demoPhaFailVal;    //IQ校正相位检查不过值

    FLOAT  txAbsOverFailValue;  //前向分频段峰值检查不过值
    INT32  txAbsOverFailCnt;    //前向分频段峰值检查不过次数

    UINT32  txSegCheckFailCnt;  //前向数据分16段功率检查失败次数
    FLOAT   txSegCheckFailValue[DPD_MSG_TX_POWDATA_CHECKNUM];    //前向数据分16段功率检查失败值
    UINT32  fbNoSigCnt;   //反馈数据分频段平均功率失败次数
    FLOAT   fbNoSigValue;  //反馈数据分频段平均功率失败值

    UINT32  grpDatDlyErrCnt;  //多组数之间时延波动检查不过次数
    UINT32  grpDatDlyErrVal;  //多组数之间时延波动检查不过值
    UINT32  freqDatDlyErrCnt; //频段间数据时延波动检查不过次数（公共）
    UINT32  freqDatDlyErrVal; //频段间数据时延波动检查不过值（公共）
    UINT32  phaChkFreqErrCnt; //频段间相位波动检查不过次数（公共）
    FLOAT   phaChkFreqErrVal;  //频段间相位波动检查不过值（公共）
    UINT32  gainChkFreqErrCnt;    //频段间能量波动检查不过次数（公共）
    FLOAT   gainChkFreqErrVal; //频段间能量波动检查不过值（公共）
    UINT32  rhoChkErrCnt; //数据rho值检查不过次数
    FLOAT   rhoChkErrVal;  //数据rho值检查不过值

    UINT32  getTblCnt;    //提表次数
    UINT32  lutPhaAdjCntN;    //表格相位调整负相位次数
    UINT32  lutPhaAdjCntP;    //表格相位调整正相位次数
    UINT32  lutPhaFailCnt;    //表格相位校验失败次数
    FLOAT   lutPhaNow; //表格当前相位值（角度）
    FLOAT   lutPhaFailVal; //表格相位校验失败值（角度）
    FLOAT   lutDatMaxVaule; //表格相位校验值（最大单点功率）
    FLOAT   lutDatFailMaxVaule; //最大单点功率
    UINT32  lutDatFailMaxCnt;//表格相位校验单点功率不过次数统计
    UINT32  lutGainFailCntP;  //表格增益校验正增益调整次数
    UINT32  lutGainFailCntN;  //表格增益校验负增益调整次数
    UINT32  lutGainCheckFailCnt;  //表格增益校验不过次数
    FLOAT   lutGaindB; //表格增益校验当前值（dB）
    FLOAT   lutGainFailValue;  //表格增益校验失败值
    FLOAT   maxLutVal;             //表格峰值校验当前值
    FLOAT   maxLutValFailValue;    //表格峰值校验失败值
    INT32   maxLutFailCnt;     //表格峰值校验失败次数
    FLOAT   lutRhoValue;           // 表格当前Rho值
    FLOAT   lutRhoFailValue;       // 表格Rho值校验失败数据
    UINT32  lutRhoFailCnt;        // 表格Rho值校验失败次数
    UINT32  maxGainFailCnt;       // 表格峰值最大补偿校验失败次数
    FLOAT   maxGainVal;            // 表格峰值最大补偿当前值
    FLOAT   maxGainValFailValue;   // 表格峰值最大补偿失败值
    UINT32  lutRobGainFailCnt;    //表格健壮性增益校验失败次数
    FLOAT   lutRobGainVal; //表格健壮性增益当前值（dB）
    FLOAT   lutRobGainFailVal; //表格健壮性增益校验失败（dB）
    UINT32  lutRobRhoFailCnt; //表格健壮性rho值失败次数
    FLOAT   lutRobRhoVal;  //表格健壮性rho当前值
    FLOAT   lutRobRhoFailVal;  //表格健壮性rho校验失败
    INT32   lutCheckValue; //当前表格时延值（预留）
    UINT32  lutDlyFailCnt;    //表格时延超限次数（预留）
    INT32   lutAdjValue;   //调整表格时延时的表格时延值（预留）
    UINT32  RNoiseAdjCnt; //噪声调整次数
    FLOAT   RNoisedB;  //当前R矩阵加噪值（dB）
    FLOAT   ZNoisedB;  //但前Z矩阵加噪值(dB)
    UINT32  adp1LutCnt;   //Adp1下表次数
    UINT32  adp2LutCnt;   //Adp2下表次数
    UINT32  datRhoClearLutCnt; //数据rho值检查不过清表次数
    UINT32  cpuMsgClearlutCnt; //CPU消息通知DSP清表次数
    UINT32  lutRhoClearlutCnt; //表格rho值检查不过清表次数
} T_DpdMsgDiagParaQueryAck;

/*  0x8005号消息：查询DSP看门狗*/
typedef struct tagT_DpdMsgWatchDogQuery
{
} T_DpdMsgWatchDogQuery;
typedef struct tagT_DpdMsgWatchDogQueryAck
{
    UINT16  count;
} T_DpdMsgWatchDogQueryAck;

/* 0x8006 消息, DSP和FPGA接口测试结果查询 */
typedef struct tagT_DpdMsgFtTestQuery
{
    UINT16 testType;                  //要测试的接口类型
} T_DpdMsgFtTestQuery;

typedef struct tagT_DpdMsgFtTestQueryAck
{
    UINT16 result;                   //消息处理结果
    UINT16 testResult;                   //测试结果
} T_DpdMsgFtTestQueryAck;

/* 0x8007 消息, AC 校准查询*/
typedef struct tagT_DpdMsgAcStateQuery
{
} T_DpdMsgAcStateQuery;

typedef struct tagT_DpdMsgAcStateQueryAck
{
    UINT16 cellId;
    UINT16 type;
    UINT16 state;
} T_DpdMsgAcStateQueryAck;

/*  0x8008号消息：查询DSP加载状态*/
typedef struct tagT_DpdMsgDspLoadStateQuery
{
} T_DpdMsgDspLoadStateQuery;
typedef struct tagT_DpdMsgDspLoadStateQueryAck
{
    UINT32 state;
} T_DpdMsgDspLoadStateQueryAck;

/*  0x800A号消息：查询PIMC预训练状态*/
typedef struct tagT_DpdMsgPimcPreTrainStateQuery
{
} T_DpdMsgPimcPreTrainStateQuery;
typedef struct tagT_DpdMsgPimcPreTrainStateQueryAck
{
    UINT32 state;
} T_DpdMsgPimcPreTrainStateQueryAck;

/*  0x800D号消息：查询DSP是否已经接收完AC时域数据*/
typedef struct tagT_DpdMsgChkAcDspRecvAcSeqOk
{
} T_DpdMsgChkAcDspRecvAcSeqOk;
typedef struct tagT_DpdMsgChkAcDspRecvAcSeqOkAck
{
    UINT16 uwCellId;       /* 小区标志*/
    UINT16 uwAcType;       /* AC类型 */
    UINT16 result;         /* 0x5a5a，说明正在接收AC序列；如果返回0x2d2d,说明AC序列接收完成 */
} T_DpdMsgChkAcDspRecvAcSeqOkAck;
/* 0x8011号消息：查询offline 流程中dpd完成状态*/
typedef struct tagT_DpdMsgPimDpdStateQuery
{
} T_DpdMsgPimDpdStateQuery;
typedef struct tagT_DpdMsgPimDpdStateQueryAck
{
    UINT32 chan;    /*最后一次收到发起命令的通道号*/
    UINT32 state;   /*pimoffline模块的运行状态 ready-0 busy-1*/
    UINT32 result;  /*最后一次pimoffline执行结果状态 为0表示状态正常，非零值为失败告警码*/
    INT32 acps[MSG_PIMOFF_ACP_NUM];  /*最后一次三阶互调acp: 左三阶频点fAcps[0] 右三阶频点fAcps[1] 上报值为真实值（浮点数）乘一千之后取整的结果*/
    UINT32 reserve[7];
} T_DpdMsgPimDpdStateQueryAck;

/*0x801b消息：预埋表提取完成状态*/
typedef enum
{
    TRAP_EMBED_LUT_FINISHED = 0,    /*预埋表提取已完成*/
    TRAP_EMBED_LUT_UNFINISH = 1,    /*预埋表提取未完成*/
}E_TrapEmbedProcStaMsg;
/*预埋表提取完成状态上报*/
typedef struct
{
    unsigned int uiProcSta;                    /*预埋表提取完成状态，0: 已完成，1:未完成*/
    unsigned int uiReserve[7];                 /*保留字段*/
    unsigned int auiChResult[MSG_DSP_CH_MAX];  /*通道预埋表提取处理结果, 0:提取成功，非0：提取处理告警码*/
}T_TrapEmbedLutStaMsg;
/*预埋表提取完成状态回复消息*/
typedef struct
{
    unsigned short uwResult;   /*消息处理结果*/
}T_TrapEmbedLutStaMsgAck;

/*0x801c消息：预埋表提取*/
/*Trap预埋表格上传查询接口*/
typedef struct
{
    unsigned int uiChn;        /*预埋表对应的通道*/
    unsigned int uiVoltGrd;    /*预埋表对应的档位*/
    unsigned int uiReserve[6]; /*保留字段*/
} T_TrapEmbedLutQueryMsgRx;
/*Trap预埋表格回传接口*/
typedef struct 
{
    unsigned int uiChn;                                     /*预埋表对应的通道*/
    unsigned int uiVoltGrd;                                 /*预埋表对应的档位*/
    unsigned int uiLutLen;                                  /*表格数据长度，档位:byte*/
    unsigned int uiReserve[5];                              /*保留字段*/
    unsigned char aucLutBuffer[MSG_TRAP_EMBED_LUT_LEN_MAX]; /*预埋表数据*/
}T_TrapEmbedLutQueryMsgTx;
/*预埋表提取回复消息*/
typedef struct
{
    unsigned short uwResult;   /*消息处理结果*/
}T_TrapEmbedLutQueryMsgAck;

/* 0x001E消息--多音源启停控制 */
typedef struct tagT_DpdGainCaliBwInfo
{
    UINT32 txFreqStep;   /*步进值 kHz*/
    UINT32 txFreqStart;  /*起始发射频点 kHz*/
    UINT32 txFreqEnd;    /*终止发射频点 kHz*/
    UINT32 reserve[8];   /* 保留 */
} T_DpdGainCaliBwInfo;

typedef struct tagT_DpdMultFreqInfoCfg
{
    UINT32 txTypeNum;  /*频点范围信息，最大3种*/
    T_DpdGainCaliBwInfo gainCaliBwInfo[3];
    UINT32 reserve[8];  /* 保留 */
} T_DpdMultFreqInfoCfg;

typedef struct tagT_DpdMultFreqSrcCtrlMsg
{
    UINT32 txTaskType;  /*发射多音源任务 0:停止 1:发起 2:定标*/
    T_DpdMultFreqInfoCfg multFreqInfoCfg;
} T_DpdMultFreqSrcCtrlMsg;

typedef struct tagT_DpdMultFreqRecvComMsg
{
    UINT16 result;
} T_DpdMultFreqRecvComMsg;

/* IC4.2 PIM配置分析 相关消息结构体信息 */
/* 0x001f消息--启动PIM配置分析LMS迭代 */
typedef struct tagT_DpdPimChkLmsCtrlMsg
{
    INT32 ctrl; /* 控制字：0x5A5A，加载；0x2D2D，卸载 */
} T_DpdPimChkLmsCtrlMsg;
typedef struct tagT_DpdRecvComMsg
{
    USHORT result;        /* 消息处理结果 */
} T_DpdRecvComMsg;

/* 0x0020消息--PIM配置分析启动能量计算检测 */
typedef struct tagT_DpdPimCfgEnergyCalCtrl
{
    INT32 ctrl;       /* 启动：0x5a5a, 叫停：0x2D2D */
    INT32 slotIndex;  /* PTS检测无线帧号 */
    UINT32 tddFlag;    /* 下行TDD_SW_FLAG状态标志 */
} T_DpdPimCfgEnergyCalCtrl;

/* 0x002A消息--Ts使能标识 */
typedef struct tagT_DpdTsCtrl
{
    UINT32 uiTsTypeMsk;     /** 指定类型TS掩码，每bit代表一个类型的TS：1使能，0去使能。bit0表示短时TS，bit1-bit31可扩展 */
    UINT32 uiChMsk;         /** 需要发起TS请求的通道掩码，bit0-bit31分别代表通道0-31，bit值为0表示不使能，为1表示使能 */
    UINT32 uiReserve[6];
} T_DpdT_DpdTsCtrl;

typedef struct tagT_DpdTsCtrlRes
{
    USHORT result;
} T_DpdT_DpdTsCtrlRes;

typedef struct tagT_DpdPimCfgEnergyCalRes
{
    USHORT result;
} T_DpdPimCfgEnergyCalRes;

/* 0x8020消息--LMS迭代状态查询 */
typedef struct tagT_DpdPimLmsStaMsg
{

} T_DpdPimLmsStaMsg;
typedef struct tagT_DpdPimChkLmsIterSta
{
    UINT32 lmsIterFinAllSta;  /* LMS迭代的总体完成状态:训练失败：0x33,训练中：0x22,训练完成：0x11 */
} T_DpdPimChkLmsIterSta;

/* 0x8021消息--PIM配置分析检测状态查询 */
typedef struct tagT_DpdPimChkStaCtrl
{

} T_DpdPimChkStaCtrl;
typedef struct tagT_DpdPimChkStaUpTx
{
    UINT32 pimChkCalFinSat;  /* 0x33：pim online失败,0x22：pim online计算中,0x11：pim online完成 */
} T_DpdPimChkStaUpTx;
/* 0x801F消息--查询多音源发起状态 */
typedef struct tagT_DpdPwdCaliMsg
{
    UINT32 txTaskType;  /*发射多音源任务 0:停止 1:发起 2:定标*/
} T_DpdPwdCaliMsg;

//0x8022 子端功率上报
typedef struct tagT_DpdMsgChnPowInfo
{

}T_DpdMsgChnPowInfo;

typedef struct tagT_DspMsgPerChnPowInfo
{
    UINT32 chType;          //通道子母端类型
    UINT32 isBusy;            //通道功率检测完成状态，0：已完成，1：未完成
    UINT32 chPowCalCnt;    //通道功率检测次数
    INT32  txPow;             //前向合路功率，单位:0.01db
    INT32  fbPow;             //反馈合路功率，单位:0.01db
}T_DspMsgPerChnPowInfo;

typedef struct tagT_DspMsgChnPowInfoAck
{
    UINT32 chNum;
    T_DspMsgPerChnPowInfo chPowInfo[IC_CHAN_NUM_MAX];
}T_DspMsgChnPowInfoAck;

typedef struct tagT_DpdTxFreqPowVal
{
    INT32 txTssi;
    INT32 fbPow;
    UINT32 txFreq;  /*发射频点信息 kHz*/
    INT32 reserve[5];  /* 保留 */
} T_DpdTxFreqPowVal;

typedef struct tagT_DpdPwdResult
{
    UINT32 txFreqNum;  /*实际有效频点数*/
    INT32 reserve[7];  /* 保留 */
    T_DpdTxFreqPowVal txFreqPowVal[30];
} T_DpdPwdResult;

typedef struct tagT_DpdPwdCaliResult
{
    UINT32 taskType; //1:发多音源任务；0：停多音源；2：定标任务
    UINT32 finish;   //0完成，1：未完成
    INT32  result;   //0：成功，1：失败
    T_DpdPwdResult pwdResult;
}T_PwdCaliResult;

/* 0x0C00消息--Pim_Online获取整机硬件信息 */
typedef struct tagT_PimHwDlChInfo
{
     UINT32 chipIdx;
     UINT32 chanId;
     UINT32 bandNum;  /* 发射频段数 */
     UINT32 reserve[2];
     UINT32 txDflFreqL[MAX_BAND_NUM_PER_CHAN];  /* 发送双工器低频点，kHz */
     UINT32 txDflFreqH[MAX_BAND_NUM_PER_CHAN];  /* 发送双工器高频点，kHz */
} T_PimHwDlChInfo;

typedef struct tagT_PimHwUlChInfo
{
    UINT32 chipIdx;
    UINT32 chanId;
    UINT32 bandNum;  /* 接收频段数 */
    UINT32 reserve[2];
    UINT32 rxDflFreqL[MAX_BAND_NUM_PER_CHAN];  /* 接收双工器低频点，kHz */
    UINT32 rxDflFreqH[MAX_BAND_NUM_PER_CHAN];  /* 接收双工器高频点，kHz */
} T_PimHwUlChInfo;

typedef struct tagT_PimOnlineRruInfoMsg
{
    UINT32  dlValidChNum; //整机下行有效通道数
    UINT32  ulValidChNum; //整机上行有效通道数
    T_PimHwDlChInfo dlChInfo[PIMONLINE_RRU_MAX_CHAN_NUM];
    T_PimHwUlChInfo ulChInfo[PIMONLINE_RRU_MAX_CHAN_NUM];
}T_PimOnlineRruInfoMsg;

typedef struct tagT_DpdPimOnlineRecvAck
{
    USHORT result;        /* 消息处理结果 */
} T_DpdPimOnlineRecvAck;

/* 0x0C01消息--PIM OnLine检测结果上报 */
typedef struct tagT_DpdPimOnlineResult
{

} T_DpdPimOnlineResult;

typedef struct tagT_DpdPimOnlineResultAck
{
    T_PimPowerRes pimPowerReport[MAX_BAND_NUM_PER_CHAN];
} T_DpdPimOnlineResultAck;

/*0xC001号消息：BSP采集数据控制消息*/
/* BSP通知DSP采集训练数据，DSP采集完所需训练数据后，通知BSP读取，然后处于等待状态直到BSP通知DSP继续运行。  **/
typedef struct tagT_DpdMsgSampleCtrl
{
    UINT16 OffLineSampFlg;       /* 控制字  16bit无符号数:
                            1-通知DSP采集高功率数据
                            2-通知DSP采集低功率数据
                            3-通知DSP随机采集数据
                        */
    UINT16 OffLinePos;
}T_DpdMsgSampleCtrl;

typedef struct tagT_DpdMsgSampleCtrlAck
{
    UINT16 result;  /*操作结果    回复信息约定*/
}T_DpdMsgSampleCtrlAck;

/*  0xC002号消息：BSP查询DSP采集数据是否完成消息*/
/* BSP通过该消息通查询DSP采数是否完成。 */
typedef struct tagT_DpdMsgSampleQuery
{
}T_DpdMsgSampleQuery;
typedef struct tagT_DpdMsgSampleQueryAck
{
    UINT16 state; /* 采数完成状态 */
}T_DpdMsgSampleQueryAck;

/*  0xC003号消息：DPD数据上传*/
/* BSP通过该消息通知DPD上传数据。 */
typedef struct tagT_DpdMsgUploadData
{
   UINT16   dataType;  /* 数据类型
                          0：DSP定点表上传
                          1：浮点数据上传
                          2：DSP浮点表上传
                          3：FPGA第一项表格上传
                          4：DSP表格系数上传
                          5：FPGA第二项表格上传
                          6：驻波比检测中采集到的前向数据上传
                          7：驻波比检测中采集到的反馈数据上传
                          8：驻波比检测中采集到的反射数据上传
                        */
}T_DpdMsgUploadData;

typedef struct tagT_DpdMsgUploadDataAck
{
    UCHAR data[MAX_DPD_MSG_BODY];
}T_DpdMsgUploadDataAck;

/*  0xC004号消息：BSP通知DSP退出等待状态  */
typedef struct tagT_DpdMsgSampleQuit
{
}T_DpdMsgSampleQuit;
typedef struct tagT_DpdMsgSampleQuitAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSampleQuitAck;

/*  0xC005号消息：DPD表格下载     */
/* BSP通过该消息，下载DPD表格。 */
typedef struct tagT_DpdMsgDownloadData
{
    UCHAR data[MAX_DPD_MSG_BODY];
}T_DpdMsgDownloadData;
typedef struct tagT_DpdMsgDownloadDataAck
{
    UINT16 result;   /* 回复时固定写为0x1111 */
}T_DpdMsgDownloadDataAck;


/* 0xC006 message, read/write fpga registers */
typedef struct tagT_DpdMsgFpgaCmd
{
    UINT16 cmd;               //读写标志,0x2d2d:写,0x5a5a:读
    UINT16 mask;              //默认0xffff
    UINT16 addr;              //地址
    UINT16 data;              //数据
} T_DpdMsgFpgaCmd;

typedef struct tagT_DpdMsgFpgaCmdAck
{
    UINT16 readVal;           //数据
    UINT16 result;            //消息处理结果
} T_DpdMsgFpgaCmdAck;


/* 0xC007消息--VSWR计算状态查询*/
typedef struct tagT_DpdMsgVswrQuery
{
}T_DpdMsgVswrQuery;
typedef struct tagT_SpaData{
    INT32 vswrReal;  /* VSWR检测值的实部 */
    INT32 vswrImag;  /* VSWR检测值的虚部 */
    INT32 nco;       /* DPD返回计算驻波比载波的NCO,GSM */
}T_SpaData;
typedef struct tagT_DpdMsgVswrQueryAck
{
	UINT32 iVswrCalFlag; /*Vswr计算状态*/
	UINT32 iVswrSamFlag; /*Vswr采数状态*/
	UINT32 iSpaNum;      /*有效spa个数*/
	UINT32 bandNo;       /*通道计算选择的频段索引*/
	INT32 rev[10];       /*保留字段*/
	T_SpaData spaData[SIG_FRE_NUM_MAX];
} T_DpdMsgVswrQueryAck;


/* 0xC008消息--VSWR计算状态查询*/
typedef struct tagT_DpdMsgVswrCheck
{
}T_DpdMsgVswrCheck;

typedef struct tagT_DpdMsgVswrCheckAck
{
    UINT32 state;  /*VSWR计算状态查询*/
} T_DpdMsgVswrCheckAck;

/* 0xC00F消息 */
typedef struct
{
} T_DpdMsgGetOnlinePim2Val;
typedef struct
{
    INT32                   carrNo;                     /* 载波号 */
    INT32                   radioMode;                  /* 制式 */
    INT32                   rxCarrFreq;                 /* 载波频点,KHZ */
    INT32                   rxCarrBw;                   /* 载波带宽,KHZ */
    INT32                   singleVal;                  /* 单端口Pim检测值,db */
    INT32                   singleNoiseVal;             /* 单端口Pim底噪检测值,db */
    INT32                   mutiVal;                    /* 多端口Pim检测值,db */
    INT32                   mutiNoiseVal;               /* 多端口Pim底噪检测值,db */
    INT32                   checkresult;                /* 检测结果 */
    INT32                   reserve[7];                 /* 暂时保留 */
} T_OnlinePim2ChkCarrPara;
typedef struct
{
    INT32                   result;                     /* 检测结果: 0x33:失败 0x22:计算中 0x11:成功 */
    INT32                   chkCarrNum;                 /* 有效载波数量 */
    INT32                   reserve[4];                 /* 暂时保留 */
    T_OnlinePim2ChkCarrPara carrPara[PIMONLINEMSG_MAX_CARR_NUM];  /* 载波检测结果信息 */
} T_DpdMsgGetOnlinePim2ValAck;

/*  0xC009消息--获取dpd侧字符串打印信息 */
typedef struct tagT_DpdMsgPrintStr
{
    UINT32 powGrd;           /* 档位号 */
    UINT32 index;            /* 消息类型 */
    INT32  data0;            /* 参数值 */
    INT32  data1;            /* 参数值 */
    INT32  data2;            /* 参数值 */
    INT32  data3;            /* 参数值 */
    INT32  data4;            /* 参数值 */
    INT32  data5;            /* 参数值 */
}T_DpdMsgPrintStr;

typedef struct tagT_DpdMsgPrintStrAck
{
    UCHAR data[MAX_DPD_MSG_BODY];
}T_DpdMsgPrintStrAck;

typedef struct tagAcSeqComplexData
{
	UINT16 real;//从IC寄存器中读取的，已经是带符号型
	UINT16 imag;//
}AcSeqComplexData;

/*  0x4008消息--获取dpd侧字符串打印信息 */
typedef struct tagT_DpdMsgSendAcData
{
	UINT16 uwDataLen;     //从小区索引到ACdata结尾的字节数
	UINT8  ucCeLLId;      //小区索引，0：小区0,1：小区1
	UINT8  ucAcType;      //AC数据类型，0：下行，1：上行
	UINT8  ucIterationNo; //迭代次数
	UINT8  ucGroupNo;     //组号，下行：0-8，上行固定为0 下行
	UINT16 uwAntNo;       //天线号,0表示0天线，上行有用，下行没用
	UINT8  ucDpdIcId;     //DPDIC_ID
	UINT8  uacReserve[3]; //保留
	AcSeqComplexData ComplexData[1024];
	INT32  iScale;
	INT32  iCrc;
}T_DpdMsgSendAcData;

typedef struct tagT_DpdMsgSendAcData_NEW
{
	T_DpdMsgSendAcData stDa[2];
}T_DpdMsgSendAcData_NEW;

typedef struct tagT_DpdMsgSendAcData_NEW_IC4
{
    T_DpdMsgSendAcData stDa[4];
}T_DpdMsgSendAcData_NEW_IC4;


typedef struct tagT_DpdMsgSendSlaveData
{
    UINT16 uwDataLen;     
    UINT8  ucCeLLId;      
    UINT8  ucAcType;      
    UINT8  uiBandWith;    
    UINT8  ucGroupNo;     
    UINT16 uwAntNo;       
    UINT8  uiModulTyp;     
    UINT8  uacReserve[3]; 
    AcSeqComplexData ComplexData[4096];
    INT32  iScale;
    INT32  iCrc;
}T_DpdMsgSendSlaveData;

typedef struct tagT_DpdMsgInsOnLineACCal
{
    UINT32  OnlineInsType;
    UINT32  uibandWidth;
}T_DpdMsgInsOnLineACCal;

typedef struct tagT_DpdMsgInsOnLineEVMCal
{
    UINT32  OnlineInsType;
    UINT32  uibandWidth;
    UINT32  uiSampleRate;
    UINT32  uiRadioMode;
}T_DpdMsgInsOnLineEVMCal;

typedef struct tagT_DpdMsgSendSlaveDataAck
{
    UINT16 result;
}T_DpdMsgSendSlaveDataAck;


typedef struct tagT_DpdMsgInsOnLineACCalAck
{
    UINT16 result;
}T_DpdMsgInsOnLineACCalAck;


typedef struct tagT_DpdMsgInsOnLineEVMCalAck
{
    UINT16 result;
}T_DpdMsgInsOnLineEVMCalAck;

/* 0x401a消息--消息处理结果 */
typedef struct tagT_VswrPosCalcParaAck
{
    UINT16 result;
}T_VswrPosCalcParaAck;

typedef struct tagT_DpdMsgSendAcDataAck
{
    UINT16 result;
}T_DpdMsgSendAcDataAck;

typedef struct tagT_DpdMsgSendAcDataAckIC4
{
    UINT16 result;
}T_DpdMsgSendAcDataAckIC4;

/*  0xC00A消息--查询DPCT校准状态 */
typedef struct tagT_DpdMsgDpctQuery
{
}T_DpdMsgDpctQuery;
typedef struct tagT_DpdMsgDpctQueryAck
{
    UINT16 state;
}T_DpdMsgDpctQueryAck;

/**************************************************************************/
typedef struct
{
    /* 参数属性为0：数据采集相关参数： */
    T_DpdSamplePara    t_RxSampleRelatedPara;

    /* 参数属性为1：单组数据检查相关参数：*/
    T_DpdCheckPara    t_RxDataCheckPara;

    /* 参数属性为2：数据处理相关参数： */
    T_DpdHandlePara    t_RxDataHandlePara;

    /* 参数属性为3：表格提取相关参数（除DPD多项式结构）*/
    T_DpdTableDrawPara    t_RxTableDrawPara;

    /* 参数属性为4：表格结构相关参数
    注：该参数属性，每个频段最多支持4组，具体选择哪一组表首先由配置类消息配置好组别，然后在通过该消息查询。
    */
    T_DpdTableStuctPara  t_RxTableStuctPara;

    /* 参数属性为5：表格检查参数   */
    T_DpdTableCheckPara   t_RxTableCheckPara;

    /* 参数属性为6：小区制式相关参数  */
    T_RxWorkModePara   t_RxWorkModePara;

}T_DPDParam;


/*  0x000C消息--ts启动 */
typedef struct tagT_DpdMsgTsCtrl
{
    UINT32 tstype;
    UINT32 state;
}T_DpdMsgTsCtrl;
typedef struct tagT_DpdMsgTsCtrlAck
{
    UINT16 state;
}T_DpdMsgTsCtrlAck;


/*  0x800C消息--ts查询 */
typedef struct tagT_DpdMsgTsQuery
{
    UINT16 state;
}T_DpdMsgTsQuery;
typedef struct tagT_DpdMsgTsQueryAck
{
    UINT16 state;
}T_DpdMsgTsQueryAck;

/*0x1C00消息--Dopa Cali查询*/
typedef struct tagT_DpdMsgDopaCaliQuery
{
}T_DpdMsgDopaCaliQuery;
typedef struct tagT_DpdMsgDopaCaliQueryAck
{
    UINT32 ulDopaCaliSta;     /*通道校准完成状态 0,已完成 1,进行中 0xff,失败*/
    INT32  reserve[3];        /*保留字段*/
}T_DpdMsgDopaCaliQueryAck;

/*  0x4013消息--ts使能 */
typedef struct tagT_DpdMsgTsEnable
{
    UINT16 state;
}T_DpdMsgTsEnable;
typedef struct tagT_DpdMsgTsEnableAck
{
    UINT16 state;
}T_DpdMsgTsEnableAck;


/*  0x8013消息--ts查询 */
typedef struct tagT_DpdMsgTsEnQuery
{
    UINT16 state;
}T_DpdMsgTsEnQuery;
typedef struct tagT_DpdMsgTsEnQueryAck
{
    UINT16 state;
}T_DpdMsgTsEnQueryAck;

/*0x4014消息--发送配置外扩逻辑的值 */
typedef struct tagT_DpdMsgSendRegVal
{
    UINT32 regVal;          /* 寄存器值 */
    UINT32 regAddr;         /* 寄存器地址 */
    UINT32 res[64];         /* 保留字段 */
}T_DpdMsgSendRegVal;
/*0x8014消息--查询配置外扩逻辑寄存器的值 */
typedef struct tagT_DpdMsgSendRegValAck
{
	UINT16 result;
    UINT32 regVal;          /* 寄存器值 */
    UINT32 regAddr;         /* 寄存器地址 */
    UINT32 res[64];         /* 保留字段 */
}T_DpdMsgSendRegValAck;
/*0x8016消息--TS固定时延发起申请上报 */
typedef struct
{
} T_TsRequestStaMsg;
typedef struct
{
    UINT32 result;
    UINT32 tsRequst;  /* 固定时延发起申请标志，即TS异常标志，0正常，1异常*/
    UINT32 tsRequstChanMask;  /* 通道级发起申请标志，通道掩码1通道异常，0通道正常 */
    UINT32 tsktype;    /*请求任务类型*/
    UINT16 calitype;      /*通道校准类型*/
    UINT16 calibranch;    /*校准支路号*/
    UINT32 reserve[2];     /*保留字段*/
} T_TsRequestStaMsgAck;

/*0x0014消息--节能发起DPD通道关断请求 */
typedef struct
{
    UINT32 chanmask;/*chanmask:通道掩码，1关，0开*/
    UINT32 reserve;/*保留字段*/
} T_ChanOffRequest;
typedef struct
{
    UINT16 result;
} T_ChanOffRequestAck;

/*0x8018消息--节能发起DPD通道关断请求DPD处理结果查询 */
typedef struct
{
} T_ChanOffResultQuery;
typedef struct
{
    UINT32 chanoffresult;/*1表示关断完成，0表示关断未完成*/
} T_ChanOffResultQueryAck;

typedef struct
{
	UINT8 dsp_prt_style;
	UINT8 dsp_prt_style_second;
	UINT8 dpd_pwr_index;
} T_DspMsgPrtQuery;

typedef struct tagT_DspMsgDdcCtrl
{
    UINT32 startCtrl;
}T_DspMsgDdcCtrl;
typedef struct tagT_DspMsgDdcParam
{
	T_CellInfoParm cellInfoParm;
}T_DspMsgDdcParam;
typedef struct tagT_DspMsgDdcParamAck
{
    UINT32 ddcstatus;
}T_DspMsgDdcParamAck;

/*0x8017*/
typedef struct tagT_DpdMsgGetOnlinePimVal
{
} T_DpdMsgGetOnlinePimVal;

/* 0x4020消息 -- PIM配置分析下发配置信息 */
typedef struct
{
    UINT32 carrNo;                                     /* 载波号 */
    UINT32 carrMode;                                   /* 载波制式 */
    INT32  txFreq;                                     /* 载波下行频点,单位KHZ */
    INT32  bandNco;                                    /* 载波下行频段,单位KHZ */
    INT32  txBandWidth;                                /* 载波下行带宽,单位KHZ */
    INT32  carrPow;                                    /* 载波发射功率,单位mw */
    INT32  reserve[4];                                 /* 保留 */
} T_PimOnlineItemTxDsp;
typedef struct
{
    UINT32  carrNo;                                     /* 载波号 */
    UINT32  carrMode;                                   /* 载波制式 */
    INT32   rxFreq;                                     /* 载波上行频点,单位KHZ */
    INT32   bandNco;                                    /* 载波上行频段,单位KHZ */
    INT32   rxBandWidth;                                /* 载波上行带宽,单位KHZ */
    INT32   reserve[5];                                 /* 保留 */
} T_PimOnlineItemRxDsp;

typedef struct
{
    INT32 txChnNo;                                      /* TX通道号 */
    INT32 carrNum;                                      /* 有效载波数量 */
    UINT32 txLoFlag;                                    /* 发射高低本振标志. 0:低本振  1:高本振 */
    UINT32 txLoFreq;                                    /* 发射本振频点信息. 单位KHZ */
    INT32 reserve[6];                                   /* 保留 */
    T_PimOnlineItemTxDsp pimOnlineItemTx[PIMONLINEMSG_MAX_CARR_NUM];  /* 载波信息 */
} T_PimOnlineChnTxDsp;
typedef struct
{
    INT32 rxChnNo;                                      /* RX通道号 */
    INT32 carrNum;                                      /* 有效载波数量 */
    UINT32 rxLoFlag;                                    /* 接收高低本振标志. 0:低本振  1:高本振 */
    UINT32 rxLoFreq;                                    /* 接收本振频点信息. 单位KHZ */
    INT32 reserve[6];                                   /* 保留 */
    T_PimOnlineItemRxDsp pimOnlineItemRx[PIMONLINEMSG_MAX_CARR_NUM];  /* 载波信息 */
} T_PimOnlineChnRxDsp;

typedef struct
{
    INT32 powPercent;                                   /* TS功率百分比(自动模式使用) 0:0% 1:10% 2:20% ... 10:100% */
    INT32 pimChkMode;                                   /* 0:自动模式  1:手动模式 */
    INT32 clearLutFlag;                                 /* 0-不清表,做DPD; 1-清表,做DPD; 2-不清表,不做DPD */
    INT32 txChnNum;                                     /* 下行通道数 */
    INT32 rxChnNum;                                     /* 下行通道数 */
    INT32 reserve[6];                                   /* 保留 */
    T_PimOnlineChnTxDsp txChnPimOnline[PIMONLINEMSG_MAX_CHAN_NUM];  /* 下行通道信息 */
    T_PimOnlineChnRxDsp rxChnPimOnline[PIMONLINEMSG_MAX_CHAN_NUM];  /* 上行通道信息 */
} T_DpdMsgSetOnlinePimPara;
typedef struct
{
    USHORT result;                                      /* 消息处理结果 */
    SHORT  confirminfo;                                 /* 单包消息处理结果 */
} T_DpdMsgSetOnlinePimParaAck;

/* 0x0D00消息 */
typedef struct
{
    INT32 powPercent;                                   /* TS功率百分比(自动模式使用) 0:0% 1:10% 2:20% ... 10:100% */
    INT32 pimChkMode;                                   /* 0:自动模式  1:手动模式 */
    INT32 clearLutFlag;                                 /* 0-不清表,做DPD; 1-清表,做DPD; 2-不清表,不做DPD */
    INT32 txChnNum;                                     /* 下行通道数 */
    INT32 rxChnNum;                                     /* 下行通道数 */
    INT32 reserve[6];                                   /* 保留 */
} T_DpdMsgPimOnChkModInfo;

typedef struct
{
    USHORT result;                                      /* 消息处理结果 */
} T_DpdMsgPimOnChkModInfoAck;

/* 0x0D01消息 */
typedef struct
{
    INT32 txChnNo;                                      /* TX通道号 */
    INT32 carrNum;                                      /* 有效载波数量 */
    UINT32 txLoFlag;                                    /* 发射高低本振标志. 0:低本振  1:高本振 */
    UINT32 txLoFreq;                                    /* 发射本振频点信息. 单位KHZ */
    INT32 reserve[6];                                   /* 保留 */
    T_PimOnlineItemTxDsp pimOnlineItemTx[PIMONLINEMSG_MAX_CARR_NUM];  /* 载波信息 */
} T_DpdMsgPimOnlineChnTx;

typedef struct
{
    USHORT result;                                      /* 消息处理结果 */
} T_DpdMsgPimOnlineChnTxAck;

/* 0x0D02消息 */
typedef struct
{
    INT32 rxChnNo;                                      /* RX通道号 */
    INT32 carrNum;                                      /* 有效载波数量 */
    UINT32 rxLoFlag;                                    /* 接收高低本振标志. 0:低本振  1:高本振 */
    UINT32 rxLoFreq;                                    /* 接收本振频点信息. 单位KHZ */
    INT32 reserve[6];                                   /* 保留 */
    T_PimOnlineItemRxDsp pimOnlineItemRx[PIMONLINEMSG_MAX_CARR_NUM];  /* 载波信息 */
} T_DpdMsgPimOnlineChnRx;


/* 0x000F消息 */
typedef struct
{
    UINT32 JacConjFreqSeqUpdateFlag;        /* Jac更新AC序列的标志，1为更新，0为不更新 */
    INT32 reserve[6];                         /* 保留 */
} T_DpdMsgJacUpdateAcConjFreqSeq;

typedef struct
{
    USHORT result;                                      /* 消息处理结果 */
} T_DpdMsgJacUpdateAcSeqAck;

typedef struct
{
    USHORT result;                                      /* 消息处理结果 */
} T_DpdMsgPimOnlineChnRxAck;

/* 0x4027消息*/
typedef struct tagT_ChanPaStaMsg
{
    UINT32 uiPaSta; /* 通道功放状态 1 开启 0 关闭 非上述状态返回异常 */
} T_ChanPaStaMsg;

typedef struct tagT_ChanPaStaMsAck
{
    UINT32 result;
} T_ChanPaStaMsgAck;

//0x4028 射频开关测试模式状态
typedef struct tagT_DspMsgRfIoCtrlMode
{
    UINT32 ioCtrlMode[IC_CHAN_NUM_MAX]; /** 0：轮询模式，1：强制模式 */
}T_DspMsgRfIoCtrlMode;

typedef struct tagT_DspMsgRfIoCtrlModeAck
{
    UINT16 result;
} T_DspMsgRfIoCtrlModeAck;

//0x4029 通道配置功率下发
typedef struct tagT_DspMsgChnTssiInfo
{
    UINT32 vaildFlag[IC_CHAN_NUM_MAX];/** 0x5a5a：有效，0x2d2d：无效 */
    INT32 chanTssi[IC_CHAN_NUM_MAX]; /** 下行合路TSSI功率，单位：0.01dbfs */
}T_DspMsgChnTssiInfo;
typedef struct tagT_DspMsgChnTssiInfoAck
{
    UINT16 result;
} T_DspMsgChnTssiInfoAck;

//0x402A DPD输入帧头与空口帧头间偏差量下发
typedef struct tagT_DspMsgFrDiffInfo
{
    UINT32 frDiff;       /** DPD输入帧头与空口帧头间偏差量，单位：时延点数，对应时钟为3.84M */
    UINT32 tddRamFrOffSet;
}T_DspMsgFrDiffInfo;
typedef struct tagT_DspMsgFrDiffInfoAck
{
    UINT16 result;
} T_DspMsgFrDiffInfoAck;

typedef struct
{
    UINT32 pim_chk_order_num;    /* pim检测阶数 */
    INT32 pim_chk_nco;          /* pim频点信息 */
    INT32 pim_chk_value;        /* 单端口pim检测值 */
    INT32 muti_pim_chk_value;   /* 多端口pim检测值 */
    INT32 noise_value;          /* 噪底检测值 */
}T_PimOnlineChkVal;
typedef struct tagT_DpdMsgGetOnlinePimValAck
{
    UINT32 pim_chk_result;       /* Pim Online状态 */
    UINT32 pim_chk_num;          /* 实际上传的组数 */
    T_PimOnlineChkVal pim_online_chk_val[PIM_CHK_MAX_NUM];
} T_DpdMsgGetOnlinePimValAck;

/*d003*/
typedef struct
{
	UINT8 index0;
	UINT8 index1;
	UINT8 index2;
	UINT8 index3;
	UINT8 index4;
} T_DspMsgBasePrtQuery;

typedef struct
{
	UINT8 *pStr;
} T_DspMsgBasePrtQueryAck;


/* @brief 时延测量请求标志*/
typedef struct
{
    UINT32 applyFlg; // 通道触发请求标志,0x5a5a:使能，0x2d2d：去使能
    UINT32 type;     //检测类型，0：时延测量 1：rho值计算
} T_DspMsgRfDlyMes;

typedef struct
{
    UINT16 result;
} T_DspMsgRfDlyMesAck;

typedef struct
{
}T_DspMsgRfDlyMesResult;
/* @brief 时延测量结果上报*/
typedef struct
{
    UINT32 iterSta; // 通道执行状态，0：已完成，1：进行中
    UINT32 result;   // 检测执行结果,0:成功，非0：失败
    UINT32 dlyVal;  // 时延值，单位:ns
    UINT32 rhoVal;   //rho值
    UINT32 type;    // 检测类型，0：时延测量 1：rho值计算
}T_DspMsgRfDlyMesResultAck;

/* 子母端机型功率检测开关控制 0x29*/
typedef struct
{
    UINT32 powCalChnSw; //T通道掩码 1使能 0去使能
} T_DspMsgPowCalChnSw;

typedef struct
{
    UINT16 result; // 通道触发请求标志,0x5a5a:使能，0x2d2d：去使能
} T_DspMsgPowCalChnSwAck;

/*0x0025 工装流程下发trapping配置K0增益标志*/
typedef struct tagT_DspMsgTrapMsgK0GainCtrl
{
    UINT32 trapK0GainCtrlFlg; /* 0x5A5A:trapping采数流程需要配置K0增益;0x2D2D:trapping采数流程不配置K0增益 */
}T_DspMsgTrapMsgK0GainCtrl;

typedef struct tagT_DspMsgTrapMsgK0GainCtrlAck
{
    UINT16 result;
}T_DspMsgTrapMsgK0GainCtrlAck;

/*0x0026 工装流程下发子端SSC预埋表提取开关*/
typedef struct tagT_DspMsgSscEmbedLutGenSw
{
    UINT32 sscEmbedLutGenSw;    /* 0x5A5A:DPD开关关的情况下进行SSC提表;0x2D2D:DPD开关关的情况下不进行SSC提表 */
}T_DspMsgSscEmbedLutGenSw;

typedef struct tagT_DspMsgSscEmbedLutGenSwAck
{
    UINT16 result;
}T_DspMsgSscEmbedLutGenSwAck;

/*0x402C SSC子端通道预埋表下发(一次下发一个通道所有电压档位的表)*/
typedef struct tagT_DspMsgSscEmbedLutDownload
{
    UINT32 vaildFlag;
    UINT8 sscLutHashVer[32];              /*SSC子端预埋表对应HASH版本*/
    UINT32 voltNum;                       /** 电压档位数*/
    UINT32 powNum;                        /** 功率档位数*/
    UINT32 sscVolt[5];                    /** 所有电压档位表格对应的电压档位值*/
    UINT8 sscPowIdx[5][8];               /** 功率档位索引*/
    UINT8 sscLutData[MAX_POWER_LEVEL_CNT][MAX_POINT_PER_POWER_LEVEL];            /** 当前通道所有电压档下的所有功率档位的表格 */
}T_DspMsgSscEmbedLutDownload;

/*一个通道的数据量是10+电压档位数*1024*4=10+电压档位数*4K */
typedef struct tagT_SscChanINfo
{
    UCHAR powerLevelIndex[5][8];
    UCHAR sscValue[5][4096];
} T_SscChanInfo;

typedef struct tagT_SscInfo
{
    UINT32 crc32;    /*校验码*/
    UCHAR version;   /*版本号*/
    UCHAR hashVersion[2][32];  /*哈希版本号*/
    UCHAR pathNum;  /*通道数目*/
    UCHAR vdsNum;   /*电压档位数*/
    UINT32 vdsValue[8]; /*电压档位值*/
    UCHAR powerLevelNum;/*功率档位值*/
    UCHAR reserve[8]; /*预留*/
    T_SscChanInfo tSscChanInfo[2];
} T_SscInfo;

typedef struct tagT_DspMsgMultiPacketAck
{
    INT16 confirm;  /** 多包传输时返回BSP的数据包确认信息 */
    UINT16 res;
}T_DspMsgMultiPacketAck;

/*0x402D SSC电压档位信息下发(分通道下发),用于子端预埋表选择*/
typedef struct tagT_DspMsgSscVoltGrdCfg
{
    UINT32 sscVoltGrd;  /** 当前电压档位号 */
    UINT32 reserve[3];  /** 保留字段 */
}T_DspMsgSscVoltGrdCfg;

typedef struct tagT_DspMsgSscVoltGrdCfgAck
{
    UINT16 result;
}T_DspMsgSscVoltGrdCfgAck;

/*0x002C 将下行通道的削峰门限下发给DSP */
typedef struct tagT_DspMsgCfrGateCfg
{
    UINT32 stageNum;  /* 有效削峰级数 */
    UINT32 cfrGate[CFR_STAGE_NUM_MAX];  /* 削峰门限 */
}T_DspMsgCfrGateCfg;

typedef struct tagT_DspRecvComMsg
{
    USHORT result;
} T_DspRecvComMsg;

/*0x8026 SSC子端预埋表提取中trapping迭代成功状态上报*/
typedef struct tagT_DspMsgSscLutGenTrapSta
{
}T_DspMsgSscLutGenTrapSta;

typedef struct tagT_DspMsgSscLutGenTrapStaAck
{
     UINT32 calcResult;  /** 当前通道trapping提表完成状态，0: 已完成，1:未完成, 非0则打印状态 */
     UINT32 trapResult;  /** 当前通道trapping运行结果 */
     UINT32 lutCnt;        /** 当前通道trapping提表成张数 */
}T_DspMsgSscLutGenTrapStaAck;

/*0x8027 SSC子端预埋表提取成功状态上报*/
typedef struct tagT_DspMsgSscLutGenStaUpLoad
{
    UINT32 pwdGrd; /** 待查询的功率档位号*/
    UINT32 res[3];
}T_DspMsgSscLutGenStaUpLoad;
typedef struct tagT_DspMsgSscLutGenStaUpLoadAck
{
    UINT32 result;   /** 消息处理状态*/
    UINT32 pwdGrd;  /** 预埋表对应的功率档位*/
    UINT32 proSta;  /** 待查询通道对应功率档位预埋表提取状态，0: 已完成，非0:未完成, 非0则打印状态 */
    UINT32 lutLen; /** 表格实际长度，档位:byte，此处需要上传当前档位的表格长度是为了CPU可以正常解析，单功率档的表格长度为1024/实际分档数 */
    UINT32 res[4];
    UINT8 lutBuf[4096]; /** 预埋表数据，表格最长1024*4字节 */
}T_DspMsgSscLutGenStaUpLoadAck;

/*0x8028 SSC子端预埋表对应HASH版本查询*/
typedef struct tagT_DspMsgSscLutHashVer
{
}T_DspMsgSscLutHashVer;
typedef struct tagT_DspMsgSscLutHashVerAck
{
    UINT32 result;
    UINT8 lutHashVer[32];
}T_DspMsgSscLutHashVerAck;

/*0x8029 dpd下表次数上报*/
typedef struct tagT_DspMsgDownLutCnt
{
}T_DspMsgDownLutCnt;
typedef struct tagT_DspMsgDownLutCntAck
{
    UINT32 result;
    UINT32 succCnt;      /** 当前通道DPD下表成功次数(所有档位总次数)*/
    UINT32 res[6];
}T_DspMsgDownLutCntAck;

/* 0x1803消息--电桥机型DPD VSWR 开始控制*/
typedef struct tagT_DpdMsgRfBridgeVswrCtrl
{
    UINT32 rfBrgVswrSmpStart;
    UINT32 koSmpStartFrameId;    /* ko侧多片采数同步帧号*/
    UINT32 msgVerify;            /* 高层生成矢量驻波校验标识，BSP透传*/
    UINT32 calSoftBrgNum;
    UINT32 res[8];               /* 保留字段 */
    UINT32 calRfBrgIdx[VSWR_MAX_RF_BRIDGE_NUM];
}T_DpdMsgRfBridgeVswrCtrl;

typedef struct tagT_DpdMsgRfBridgeVswrCtrlAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBridgeVswrCtrlAck;

/* 0x1807消息--电桥机型DPD VSWR 完成状态查询*/
typedef struct tagT_DpdMsgRfBridgeVswrFinishSta
{
}T_DpdMsgRfBridgeVswrFinishSta;
typedef struct tagT_DpdMsgRfBridgeVswrFinishStaAck
{
    UINT32 finishSta;            /*本片IC所有通道计算完成状态，0x11：完成      0x22：进行中，忙碌状态  */
    UINT32 smpResult;        /* 采数成功状态  0：成功     其余为上报告警码*/
    UINT32 msgVerify;          /*回传高层生成驻波发起标识*/
    INT32 res[4];
} T_DpdMsgRfBridgeVswrFinishStaAck;

/* 0x1809消息--电桥机型通知DSP数据传输完毕启动驻波计算消息*/
typedef struct tagT_DpdMsgRfBridgeStartVswrCalc
{
    UINT32 rfBridgeIdx;  /* 电桥索引 */
    UINT32 vswrType;       /*发起驻波类型  0x11：商用驻波，0x22：驻波工装，  0x33：S12离线参数计算；0x44：在线驻波位置检测；0x55扩展*/
    UINT32 spaCalcStart;  /* 开启spa计算  0x5a5a：开始计算 */
}T_DpdMsgRfBridgeStartVswrCalc;
typedef struct tagT_DpdMsgRfBridgeStartVswrCalcAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBridgeStartVswrCalcAck;

/*0x1808 电桥机型获取Rev值消息*/
typedef struct tagT_DpdMsgRfBridgeRevCalcSta
{
}T_DpdMsgRfBridgeRevCalcSta;
typedef struct
{
    UINT32 rfFreq;            /* 射频频点 */
    INT32 revCompensate_I;     /*  电桥离线参数RfBridge.txt中的S12Revx/S12Revy_real  反射信号采数点到电桥入口的补偿值 */
    INT32 revCompensate_Q;    /*  电桥离线参数RfBridge.txt中的S12Revx/S12Revy_imag */
}T_ChRevDiffCfg;
typedef  struct tagT_DpdMsgRfBridgeRevCalcStaAck
{
    UINT32 calcFinish;           /* 计算完成状态     0x11：完成    0x22：进行中，忙碌状态 */
    UINT32 vswrType;            /*发起驻波类型  0x11：商用驻波，0x22：驻波工装， 0x33：S12离线参数计算；0x44：在线驻波位置检测；0x55扩展*/ 
    UINT32 chanIdx;         /* 本次消息获取结果对应的通道号 */
    UINT32 calcResult;      /* 通道计算结果 */
    UINT32 spaNum;           /*  有效Spa个数  */
    UINT32 res[5];              /* 保留字段 */
    T_ChRevDiffCfg  chRevDiffCfg[VSWR_SPA_NUM_MAX];
}  T_DpdMsgRfBridgeRevCalcStaAck;

/*0x1804 电桥机型获取Spa值消息*/
typedef struct tagT_DpdMsgRfBridgeSpaCalcSta
{
}T_DpdMsgRfBridgeSpaCalcSta;

typedef  struct
{
    INT32 spaI;            /*  Spa实部，定标10^5  */
    INT32 spaQ;            /*  Spa虚部，定标10^5  */
    INT32 nco;             /*  Spa对应的中频NCO，Khz  */
}  T_SpaDat;
typedef  struct tagT_DpdMsgRfBridgeSpaCalcStaAck
{
    UINT32 calcFinish;           /* 计算完成状态     0x11：完成    0x22：进行中，忙碌状态 */
    UINT32 chanIdx;         /* 本次消息获取结果对应的通道号 */
    UINT32 calcResult;      /* 通道计算结果 0x0：成功 */
    UINT32 spaNum;           /*  有效Spa个数  */
    UINT32 res[5];              /* 保留字段 */
    T_SpaDat  spaData[VSWR_SPA_NUM_MAX];
}  T_DpdMsgRfBridgeSpaCalcStaAck;

/*0x002F 电桥离线参数下发消息*/
typedef struct
{
    UINT32 brgPara[VSWR_MAX_RF_BRIDGE_PORT_NUM];   /* AC计算用到电桥离线参数（电桥矩阵的逆）高位实部，低位虚部 */
    UINT32 rev[3];
}T_FreqRfBrgPara;
typedef struct tagT_DpdMsgRfBridgeOfflinePara
{
    UINT32 chnIdx;               /* 通道号 */
    UINT32 chipIdx;              /* 芯片号 */
    UINT32 rfFreqStart;          /* 双工器起始频点 */
    UINT32 freqStep;             /* 频段步进 */
    UINT32 freqNum;              /* 双工器内频点数目 */
    UINT32 portNum;              /* 端口数或者离线文件中pau字段个数 */
    UINT32 rev[8];
    T_FreqRfBrgPara tFreqBrgCfg[MAX_RF_BRIDGE_FREQ_NUM];
} T_DpdMsgRfBridgeOfflinePara;
typedef struct tagT_DpdMsgRfBridgeOfflineParaAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBridgeOfflineParaAck;

/*0x002E 电桥反射链路增益相位差信息下发消息*/
typedef struct tagT_DpdMsgRfBridgeOfflineRevPara
{
    UINT32 rfBridgeIdx;               /* 通道号 */
    UINT32 vswrType;           /*发起驻波类型  0x11：商用驻波，0x22：驻波工装， 0x33：S12离线参数计算；0x44：在线驻波位置检测；0x55扩展*/ 
    UINT32 dflStartFreq;       /* 双工器起始频点 */
    UINT32 dflEndFreq;         /* 双工器结束频点 */
    UINT32 freqStep;          /* 频段步进 */
    UINT32 dflFreqNum;        /* 双工器内频点数目 */
    T_ChRevDiffCfg bridgeRevCfg[VSWR_SPA_NUM_MAX];      /* 通道所有电桥参数下发接口*/
} T_DpdMsgRfBridgeOfflineRevPara;
typedef struct tagT_DpdMsgRfBridgeOfflineRevParaAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBridgeOfflineRevParaAck;

/*0x002D 电桥连接与通道连接关系下发消息*/
typedef struct tagT_DpdMsgRfBridgeAllRfBridgeInfo
{
    UINT32 rfBridgeNum;            /* 实际电桥个数 */
    UINT32 res[8];                 /* 保留字段 */
    T_RfBridgeInfo rfBridgeInfo[VSWR_MAX_RF_BRIDGE_NUM];    /* 电桥连接与通道连接关系下发消息 */
}T_DpdMsgRfBridgeAllRfBridgeInfo;
typedef struct tagT_DpdMsgRfBridgeAllRfBridgeInfoAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBridgeAllRfBridgeInfoAck;

/* Started by AICoder, pid:v2b50h321d3e1b114bf00bd470dc3e781e83ac7d */
/* 在线仪表功能开关消息 0x600 */
typedef struct tagT_DpdMsgInstruSwi {
    UINT32 ulFuncSwi; /** 0x5a5a: 功能开启，0x2d2d: 功能关闭 */
} T_DpdMsgInstruSwi;

typedef struct tagT_DpdMsgInstruSwiAck {
    UINT16 result;
} T_DpdMsgInstruSwiAck;

/* 在线 ACP 检测发起消息 0x601 */
typedef struct tagT_DpdMsgInstruAcpSwi {
    UINT32 ulFuncSwi;              /** 0x5a5a: 检测使能，0x2d2d: 检测去使能 */
    UINT32 ulChn;                  /** 被检测通道号 */
    UINT32 ulAcprTestBand;         /** Acpr 测试(主道)有效带宽 KHZ */
    UINT32 ulAcprOffsetBand;       /** Acpr 邻道设置带宽 KHZ */
    UINT32 ulAcprSecondOffestBand; /** Acpr 次邻道设置带宽 KHZ */
    UINT32 ulAcprDlLoFreq;         /** Acpr 下行本振频点 KHZ */
    UINT32 ulAcprCenterFreq;       /** Acpr 中心频点 KHZ */
    UINT32 ulAcprSpurDb;           /** Acpr 杂散门限，原始值 * 1000 */
    UINT32 ulAcprLenTime;          /** Acpr 数据采样时间 us */
    UINT32 ulAcprDatDlyTime;       /** Acpr 采数等待延时 us */
} T_DpdMsgInstruAcpSwi;

typedef struct tagT_DpdMsgInstruAcpSwiAck {
    UINT16 result;
} T_DpdMsgInstruAcpSwiAck;

/* 在线 ACP 检测结果上报消息 0x602 */
typedef struct tagT_DpdMsgInstruAcpStaAck {
    UINT32 ulCalcSta;   /** 检测完成状态，0: 已完成，1: 未完成 */
    INT32 iResult;      /** 检测成功标志，0: 成功，非0: 失败 */
    UINT32 ulChn;       /** 被检测通道号 */
    INT32 aiAcp[4];     /** Acp 检测结果，单位：dbc * 100, 排列格式：左邻道、右邻道、左次邻道、右次邻道 */
} T_DpdMsgInstruAcpStaAck;

typedef struct tagT_DpdMsgInstruAcpSta {
} T_DpdMsgInstruAcpSta;

/* 在线 EVM 检测发起消息 0x603 */
typedef struct tagT_DpdMsgInstruEvmSwi {
    UINT32 ulFuncSwi;      /** 0x5a5a: 检测使能，0x2d2d: 检测去使能 */
    UINT32 ulChn;          /** 被检测通道号 */
    UINT32 ulEvmCalBand;   /** 带宽 MHz */
    UINT32 ulEvmScsType;   /** SCS 类别 0: 15k, 1: 30k */
    UINT32 ulEvmModulType; /** 调制方式 16: 16QAM, 64: 64QAM, 256: 256QAM, 1024: 1024QAM */
    UINT32 ulEvmMode;      /** 制式：8192: NR, 32: LTE */
    UINT32 ulCenterFreq;   /** 中心频点 MHz，相位补偿关闭时配 0，LTE 默认无相位补偿 */
    UINT32 ulNid;          /** N_ID */
    UINT32 ulScid;         /** Scid */
    UINT32 ulRefSlotId;    /** 当前解调 slot 索引 */
    UINT32 ulDmrsAddPose;  /** 后置 DMRS 个数 */
    UINT32 ulCarrId;       /** 被测载波序号 */
    UINT32 ulSlotId;       /** 被测时隙索引 */
} T_DpdMsgInstruEvmSwi;

typedef struct tagT_DpdMsgInstruEvmSwiAck {
    UINT16 result;
} T_DpdMsgInstruEvmSwiAck;

/* 在线 EVM 检测结果上报消息 0x604 */
typedef struct tagT_DpdMsgInstruEvmStaAck {
    UINT32 ulCalcSta;  /** 检测完成状态，0: 已完成，1: 未完成 */
    INT32 iResult;     /** 检测成功标志，0: 成功，非0: 失败 */
    UINT32 ulChn;      /** 被检测通道号 */
    UINT32 ulCarrId;   /** 被测载波序号 */
    UINT32 ulSlotId;   /** 被测时隙索引 */
    UINT32 ulSymNum;   /** 时隙内符号个数 */
    INT32 iAvgEvm;     /** slot 平均 EVM 检测结果，单位：EVM * 100 */
    INT32 aiEvm[14];   /** 各符号 EVM 检测结果，单位：EVM * 100, 按照最大 14 个符号报 */
} T_DpdMsgInstruEvmStaAck;


/*  0x0021号消息：切换非标带宽开关*/
typedef struct tagT_DpdMsgNonStandardBandSw
{
    UINT32 uiSwitch;
    UINT32 uiBandWidth;
}T_DpdMsgNonStandardBandSw;

typedef struct tagT_DpdMsgNonStandardBandSwAck
{
    UINT16  result;
}T_DpdMsgNonStandardBandSwAck;

typedef struct tagT_DpdMsgAcBandInfo
{
    UINT32 carrNo;     //载波号
    UINT32 radioMode;  //载波制式
    UINT32 carrFreq;   //载波频点 kHz
    UINT32 bandWidth;  //带宽 kHz
    UINT32 bandNo;     //逻辑频段号
    UINT32 flag;
}T_DpdMsgAcBandInfo;

typedef struct tagT_DpdMsgAcBandInfoAck
{
    UINT16  result;
}T_DpdMsgAcBandInfoAck;

typedef struct tagT_DpdMsgInstruEvmSta {
} T_DpdMsgInstruEvmSta;
/* Ended by AICoder, pid:v2b50h321d3e1b114bf00bd470dc3e781e83ac7d */

/* 0x1A00 PIM校准校验启动消息 */
typedef struct
{
    UINT32 startCtrl;         //启动：0x5a5a,
    UINT32 slotIndex;            //PTS检测无线帧号
    UINT32 dtpChkChNum;          //需要检测接收的通道数；
    UINT32 dtpChkChIndex[MAX_DTP_CHAN_NUM];   //数组内容代表通道号。
}T_DPimCaliCtrlMsg;

typedef struct
{
    USHORT result;
}T_DPimCaliCtrlMsgAck;

/* 0x1A01 PIM校准校准状态查询 */
typedef struct
{
} T_DPimCalibratSta;
typedef struct
{
    UINT32 dtpCaliSta; //0x33：失败,0x22：计算中,0x11：完成
} T_DPimCalibratStaAck;

/* 0x1A02 PIM定位校验启动消息 */
typedef struct
{
    UINT32 startCtrl;   //启动：0x5a5a,
    UINT32 slotIndex;      //PTS检测无线帧号
} T_DPimMeasureCtrlMsg;

typedef struct
{
    USHORT result;
} T_DPimMeasureCtrlMsgAck;

/* 0x1A03 PIM定位校验状态查询 */
typedef struct
{
} T_DPimMeasureSta;

typedef struct
{
    UINT32 dtpMeasureSta; //0x33：失败,0x22：计算中,0x11：完成
} T_DPimMeasureStaAck;

/* 0x1A04 获取通道PIM定位最终数值 */
typedef struct
{
    UINT32 rxChan;
    UINT32 bandIndex;
} T_DPimResQueryMsg;

typedef struct
{
    UINT32 rxChan;              // Rx通道号
    UINT32 band;                // Band号,bit0对应bandindex0,bit1对应bandindex1
    INT32 dtpChkSta;            // 0x33：失败,0x22：计算中,0x11：完成
    INT32 singlePimDistance;    // 上报PIM位置，单位：米*100；
    INT32 multiPimDistance;     // 上报PIM位置，单位：米*100；
} T_DPimResQueryMsgAck;

/* 0x1A05 获取PIM定位预启动是否完成 */
typedef struct
{
} T_DPimDspReadySta;

typedef struct
{
    UINT32 dtpDspReadySta;     //0x22：未准备好, 0x11：准备好
} T_DPimDspReadyStaAck;

/* 0x1A06 PIM定位预启动消息 */
typedef struct
{
    INT32 startCtrl;        // 启动：0x5a5a,
    UINT32  tddFlagChan;      // 预启动有效通道
} T_DPimPreStartMsg;

typedef struct
{
    USHORT result;
} T_DPimPreStartMsgAck;

/*0x1800 电桥下发载波消息和AC权值*/
typedef struct
{
    UINT32 carrNo;            /* 载波号 */
    UINT32 radio;             /* 制式 */
    UINT32 acWeightsLen;      /* 权值长度 */
    UINT32 res[8];            /* 保留字段 */
    UINT32 acWeights[VSWR_MAX_AC_WEIGHTS_NUM];    /* 权值按照实部虚部排列保存 */
}T_CarrAcWeights;

typedef struct
{
    UINT32 softBrgIdx;                    /* 当前下发AC权对应的电桥索引 */
    UINT32 chipIdx;                       /* 当前下发AC权值所属的IC号 */
    UINT32 chnIdx;                        /* 电桥输入端口对应的通道号 */
    UINT32 res[8];                        /* 保留字段 */
    T_CarrAcWeights tOriginalCarrWeights; /*原始载波权值信息*/
}T_DpdMsgRfBrgVswrAcWeights;

typedef struct tagT_DpdMsgRfBrgVswrAcWeightsAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBrgVswrAcWeightsAck;

/*0x1801 下发选择的小区信息，并启动驻波预启动流程*/
typedef struct
{
    UINT32 vswrPreCalStart;                      /* 驻波预启动标志，启动：0x5a5a */
    UINT32 calSoftBrgNum;                        /* 本次参与计算的电桥个数 */
    UINT32 res[8];                               /* 保留字段 */
    UINT32 calRfBrgIdx[VSWR_MAX_RF_BRIDGE_NUM];  /* 本次参与计算的电桥索引 */
}T_DpdMsgRfBrgVswrPreStart;

typedef struct tagT_DpdMsgRfBrgVswrPreStartAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBrgVswrPreStartAck;

/*0x1802 查询预启动流程结果*/
typedef struct tagT_DpdMsgRfBrgVswrPreStaAck
{
    UINT32 calSoftBrgNum;                            /* 返回的预启动结果电桥个数 */
    UINT32 calFinishSta;                             /* 预启动完成状态，0x11：完成 其他：进行中 */
    UINT32 res[8];                                   /* 保留字段 */
    T_RfBrgVswrPreStartResult calRfBrgResult[VSWR_MAX_RF_BRIDGE_NUM];  /* 预启动结果 */
}T_DpdMsgRfBrgVswrPreStartStaAck;

/*0x1805 主动打断DSP侧驻波计算流程*/
typedef struct
{
    UINT32 vswrBreak;   /* 终止驻波计算，0x5a5a：终止计算 */
}T_DpdMsgRfBrgBreakVswr;

typedef struct tagT_DpdMsgRfBrgBreakVswrAck
{
    UINT16 result; /* 消息处理结果 */
} T_DpdMsgRfBrgBreakVswrAck;

/*0x1806 电桥驻波计算状态*/
typedef struct tagT_DpdMsgRfBrgVswrStaAck
{
    UINT32 calcFinish;           /* 计算完成状态     0x11：完成    0x22：进行中，忙碌状态 */
    UINT32 msgVerify;            /* 高层生成矢量驻波校验标识，BSP透传 */
} T_DpdMsgRfBrgVswrStaAck;
/*0x0030 NCR机型GP功放打开位置下发*/
typedef struct tagT_DpdMsgNcrGpInfo
{
    UINT32 uiNcrFlag; /* NCR标志 */
    UINT32 uiGpPaSite; /* NCR功放打开位置 */
    UINT32 uiChnDirection; /*通道方向，1表示上行，0表示下行*/
    UINT32 uiUeGapVal; /*UE提前量+UE保护间隔，ns*10*/
    UINT32 uiLinkTimeNs; /*NCR全链路延时,ns*10*/
    UINT32 res[6];
}T_DpdMsgNcrGpInfo;

typedef struct tagT_DpdMsgNcrGpInfoAck
{
    UINT16 result; /* 消息处理结果 */
}T_DpdMsgNcrGpInfoAck;

typedef struct tagT_DpdMsgSendDisPimOnlineTxInfoAck
{
    UINT16 result;       /* 消息处理结果 */
}T_DpdMsgSendDisPimOnlineInfoAck;

/*0x1E00消息 dsp发起全链路采数*/
typedef struct
{
    UINT32 uiSmpSwi;   /* 通道触发请求标志,0x5a5a:使能，0x2d2d：去使能 */
    UINT32 uiSmpPoint; /* 通道采数点位 */
    UINT32 uiDifChn;   /* 中频通道号 */
} T_MaintainSmpCtrlMsg;

typedef struct
{
    UINT16 uwResult;
} T_RecvComMsg;

/*0x1E01消息 dsp全链路采数状态查询*/
typedef struct
{
} T_MaintainSendSmpStaMsg;

typedef struct
{
    UINT32 uiSmpSta;   // 通道执行状态，0:完成,1:未完成
    INT32 iResult;             // 通道执行结果，0:成功,非0:失败
} T_MaintainSmpStaMsg;

/*0x0033消息 dpd通道启停状态查询*/
typedef struct
{
} T_DpdSwitchStaSend;

typedef struct
{
    INT32 iResult;
    UINT32 uiDpdSwitch;   // 通道启停状态查询,0x5a5a:开启，0x2d2d：关闭
} T_DpdSwitchSta;

typedef struct tagTHpiApiPDU
{
    UINT16 lenAPDU; /* length of head+msg */
	union
	{
		UINT8 headbuff[MAX_UPD_MSG_HEAD];
		TUdpApiHeader head;
	};
	union
    {
        UINT8 buf[MAX_UPD_MSG_BODY];
        /* 0x01消息 */
        T_DpdMsgBypass                   ctrlBypass;
        T_DpdMsgBypassAck                ctrlBypassAck;
        /* 0x02消息 */
        T_DpdMsgCtrl                     startCtrl;
        T_DpdMsgCtrlAck                  startCtrlAck;
        /* 0x03消息 */
        T_DpdMsgLutClr                   lutClr;
        T_DpdMsgLutClrAck                lutClrAck;
        /* 0x04消息 */
        T_DpdMsgVswrCtrl                 vswrCtrl;
        T_DpdMsgVswrCtrlAck              vswrCtrlAck;
        /* 0x05消息 */
        T_DpdMsgFtTest                   fpgaTest;
        T_DpdMsgFtTestAck                fpgaTestAck;
        /* 0x07消息 */
        T_DpdMsgAcCtrl                   acCtrl;
        T_DpdMsgAcCtrlAck                acCtrlAck;
        /* 0x0B消息 */
        T_DpdMsgAcRefHCalcCtrl           acRefHCalCtrl;
        T_DpdMsgAcRefHCalcCtrlAck        acRefHCalAck;
         /* 0x08消息 */
        T_DpdMsgPimcCtrl                 pimcCtrl;
        T_DpdMsgPimcCtrlAck              pimcCtrlAck;
         /* 0x09消息 */
        T_DpdMsgPimcClrTbl               pimcClrTbl;
        T_DpdMsgPimcClrTblAck            pimcClrTblAck;
         /* 0x0D消息 */
        T_DpdMsgStartAcSeqCalc           startAcSeqCalc;
        T_DpdMsgStartAcSeqCalcAck        startAcSeqCalcAck;
        /* 0x0E消息 */
        T_DpdMsgPimOfflineStart          pimOfflineStart;
        T_DpdMsgPimOfflineStartAck       pimOfflineStartAck;
        /* 0x000f消息 */
        T_DpdMsgJacUpdateAcConjFreqSeq   JacUpdateAcSeq;  
        T_DpdMsgJacUpdateAcSeqAck        JacUpdateAcSeqAck;

        /* 0x0010消息 */
        T_DpdMsgStartVswrSeqCalc         startVswrSeqCalc;
        /* 0x0011消息 */
        T_DpdMsgStartVswrWgtCalc         startVswrWgtCalc;
        /* 0x11消息  冲突了？？*/
        T_DpdMsgOnlinePimCtrl           onlinePimCtrl;
        T_DpdMsgOnlinePimAck            onlinePimAck;

        /* 0x0015消息 */
        T_DpdPtsLmsCtrl                 ptsLmsCtrl;
        T_DpdPtsLmsCtrlAck              ptsLmsCtrlAck;

        /* 0x0016消息--Pim_Online各通道躁低检测启动/停止 */
        T_DpdPimOnlineNoiseCtrl         pimOnlineNoiseCtrl;
        T_DpdPimOnlineNoiseAck          pimOnlineNoiseCtrlAck;

        /* 0x017消息--Pim_Online能量计算启动/停止 */
        T_DpdPimOnlineEnergyCalCtrl     pimOnlineEnergyCalCtrl;
        T_DpdPimOnlineEnergyCalAck      pimOnlineEnergyCalCtrlAck;

        /* 0x0018消息*/
        T_DpdDmmCtrlMsg         dpdDmmCtrlMsg;
        T_DpdDmmCtrlMsgAck      dpdDmmCtrlMsgAck;

        /* 0x0019消息*/
        T_DpdSlotVoltCtrlInfo     sendSlotVoltCtrlInfo;
        T_DpdSlotVoltCtrlInfoAck  sendSlotVoltCtrlInfoAck;

        /* 0x001a消息*/
        T_DpdSlotVoltGrpInfo      sendSlotVoltGrpInfo;
        T_DpdSlotVoltGrpInfoAck   sendSlotVoltGrpInfoAck;

        /*0x001b消息*/
        T_DpdHotLoadCtrl            DpdHotLoadCtrl;
        T_DpdHotLoadCtrlAck         DpdHotLoadCtrlAck;

        /*0x001c消息*/
        T_TrapEmbedLutCtrlMsg       trapEmbedLutCtrl;
        T_TrapEmbedLutCtrlMsgAck    trapEmbedLutCtrlAck;

        /* 0x001e消息*/
        T_DpdMultFreqSrcCtrlMsg      multFreqSrcCtrlMsg;
        T_DpdMultFreqRecvComMsg      multFreqRecvComMsg;

        /*0x001f消息*/
        T_DpdPimChkLmsCtrlMsg        pimChkLmsCtrlMsg;
        T_DpdRecvComMsg              pimRecvComMsg;

        /*0x0020消息*/
        T_DpdPimCfgEnergyCalCtrl     pimCfgEnergyCalCtrlMsg;
        T_DpdPimCfgEnergyCalRes      pimCfgEnergyCalRecvMsg;

        T_DpdMsgAcBandInfo              acBandInfo;
        T_DpdMsgAcBandInfoAck           acBandInfoAck;

        /*0x002A消息*/
        T_DpdT_DpdTsCtrl             tsCtrlMsg;
        T_DpdT_DpdTsCtrlRes          tsCtrlRecMsg;

        /*0X4001消息*/
        T_DpdMsgSetSignalPara            setPara;
        T_DpdMsgSetSignalParaAck         setParaAck;
        /*0X4002消息*/
        T_DpdMsgSetVswrPara              setVswrPara;
        T_DpdMsgSetVswrParaAck           setVswrParaAck;
        /*0x4005消息*/
        T_DpdMsgSetDlCellCfgPara           setCellCfgPara;
        T_DpdMsgSetDlCellCfgParaAck        setCellCfgParaAck;

        /* 0X4006消息 */
        T_DpdMsgSendRruInfo              sendRruInfo;
        T_DpdMsgSendRruInfoAck           sendRruInfoAck;
		
        T_ACMsgSendRruInfo              sendAcRruInfo;
        T_ACMsgSendRruInfoAck           sendAcRruInfoAck;
        /* 0X4007消息 */
        T_DpdMsgSendPowAdjInfo           sendPowAdjInfo;
        T_DpdMsgSendPowAdjInfoAck        sendPowAdjInfoAck;
        /* 0x4008消息 */
        T_DpdMsgSendAcData_NEW              sendAcData;
        T_DpdMsgSendAcDataAck             sendAcDataAck;

        T_DpdMsgSendAcData_NEW_IC4        sendAcDataIC4;
        T_DpdMsgSendAcDataAckIC4         sendAcDataAckIC4;
        /* 0x4010消息 */
        T_FramePatternInfo               framePatternInfo;
        T_FramePatternInfoAck            framePatternInfoAck;
        /* 0X4011消息 */
        T_DpdMsgSendPaInfo               sendPaInfo;
        T_DpdMsgSendPaInfoAck            sendPaInfoAck;
        /*0x4012消息*/
        T_DpdMsgSetUlCellCfgPara           setUlCellCfgPara;
        T_DpdMsgSetUlCellCfgParaAck        setUlCellCfgParaAck;
        /* 0x4018*/
        T_DpdMsgSendFwdParam             sendFwdParam;
        T_DpdMsgSendFwdParamAck          sendFwdParamAck;

        /* 0x4019*/
        T_DpdMsgSendFilterParam          sendFilterParam;
        T_DpdMsgSendFilterParamAck       sendFilterParamAck;

        /* 0x401a*/
        T_VswrPosCalcPara                 calcPara;
        T_VswrPosCalcParaAck              calcParaAck;

        /* 0x4020消息--PIM配置分析下发配置信息 */
        T_DpdMsgSetOnlinePimPara          setPimPara;
        T_DpdMsgSetOnlinePimParaAck       pimParaAck;

        /*0x4021*/
        T_DpdMsgFastAdjVoltSwitch         sendAdjVoltSwitchInfo;
        T_DpdMsgFastAdjVoltSwitchAck      sendAdjVoltSwitchInfoAck;

        /*0x4022*/
        T_DpdMsgFastAdjVoltPara           sendAdjVoltPara;
        T_DpdMsgFastAdjVoltParaAck        sendAdjVoltParaAck;

        /* 0x4023消息--Pim_Online获取整机级硬件信息 */
        T_DpdPimOnlineHwRruInfo          pimOnlineHwRruInfo;
        T_DspMsgMultiPacketAck           tMultiPacketAck;

        /* 0x4024消息 */
        T_TrapEmbedLutDwMsg               trapEmbedLutInfo;
        T_TrapEmbedLutDwMsgAck            trapEmbedLutInfoAck;

        /*0x4025消息 */
        T_VoltGainTuneTblSetMsg           gainTuneTblInfo;
        T_VoltGainTuneTblSetMsgAck        gainTuneTblInfoAck;

        /*4027 消息号*/
        T_ChanPaStaMsg                    dpdChanPaStaMsg;
        T_ChanPaStaMsgAck                 dpdChanPaStaAck;

        /*4028 消息*/
        T_DspMsgRfIoCtrlMode              rfIoCtrlMode;
        T_DspMsgRfIoCtrlModeAck           rfIoCtrlModeAck;

        /*4029 消息*/
        T_DspMsgChnTssiInfo                chnTssiInfo;
        T_DspMsgChnTssiInfoAck             chnTssiInfoAck;

                /*402A 消息*/
        T_DspMsgFrDiffInfo                 frDiffInfo;
        T_DspMsgFrDiffInfoAck              frDiffInfoAck;

        /* 0x8002消息 */
        T_DpdMsgVerQuery                  dspVer;
        T_DpdMsgVerQueryAck               dspVerAck;
        /* 0x8005消息 */
        T_DpdMsgWatchDogQuery             getdogCnt;
        T_DpdMsgWatchDogQueryAck          getdogCntAck;
        /* 0x8006消息 */
        T_DpdMsgFtTestQuery               fpgaTestQue;
        T_DpdMsgFtTestQueryAck            fpgaTestQueAck;
        /* 0x8007消息 */
        T_DpdMsgAcStateQuery              acStateQuery;
        T_DpdMsgAcStateQueryAck           acStateQueryAck;
        /* 0x8008消息 */
        T_DpdMsgDspLoadStateQuery         dspLoadState;
        T_DpdMsgDspLoadStateQueryAck      dspLoadStateAck;
        /* 0x800A消息 */
        T_DpdMsgPimcPreTrainStateQuery    pimcPreTrainState;
        T_DpdMsgPimcPreTrainStateQueryAck pimcPreTrainStateAck;
        /* 0x800B消息*/
        T_DpdMsgStateQuery                stateQuery;
        T_DpdMsgStateQueryAck             stateQueryAck;
        /* 0x800D消息*/
        T_DpdMsgChkAcDspRecvAcSeqOk       chkAcDspRecvAcSeqOk;
        T_DpdMsgChkAcDspRecvAcSeqOkAck    chkAcDspRecvAcSeqOkAck;

        /* 0x8011消息*/
        T_DpdMsgPimDpdStateQuery          PimDpdStateQuery;
        T_DpdMsgPimDpdStateQueryAck       PimDpdStateQueryAck;

        /* 0x8019消息 */
        T_DpdLmsStatus                    LmsStatus;
        T_DpdLmsStatusAck                 LmsStatusAck;

        /* 0x801f消息*/
        T_DpdPwdCaliMsg                   multFreqTransmitSta;
        T_PwdCaliResult                   multFreqPwdCaliRes;

        /* 0x8020消息*/
        T_DpdPimLmsStaMsg                 pimLmsStaMsg;
        T_DpdPimChkLmsIterSta             pimLmsIterStaCheck;

        /* 0x8021消息*/
        T_DpdPimChkStaCtrl                pimChkStaCtrl;
        T_DpdPimChkStaUpTx                pimChkUpTxStatus;
        /* 0x8022消息*/
        T_DpdMsgChnPowInfo                 chnPowInfo;
        T_DspMsgChnPowInfoAck              chnPowInfoAck;

        /* 0x0C00消息 */
        T_PimOnlineRruInfoMsg             pimOnlineRruInfoMsg;
        T_DpdPimOnlineRecvAck             pimOnlineRecvAck;

        /* 0x0C01消息 */
        T_DpdPimOnlineResult              pimOnlineRes;
        T_DpdPimOnlineResultAck           pimOnlineResAck;

        /* 0xC001消息 */
        T_DpdMsgSampleCtrl                sampleCtrl;
        T_DpdMsgSampleCtrlAck             sampleCtrlAck;
        /* 0xC002消息 */
        T_DpdMsgSampleQuery               sampleQue;
        T_DpdMsgSampleQueryAck            sampleQueAck;
        /* 0xC003消息 */
        T_DpdMsgUploadData                upLoad;
        T_DpdMsgUploadDataAck             upLoadAck;
        /* 0xC004消息 */
        T_DpdMsgSampleQuit                sampleQuit;
        T_DpdMsgSampleQuitAck             sampleQuitAck;
        /* 0xC005消息 */
        T_DpdMsgDownloadData              download;
        T_DpdMsgDownloadDataAck           downloadAck;
        /* 0xC006消息 */
        T_DpdMsgFpgaCmd                   fpgaCmd;
        T_DpdMsgFpgaCmdAck                fpgaCmdAck;
        /* 0xC007消息 */
        T_DpdMsgVswrQuery                 vwswrQuery;
        T_DpdMsgVswrQueryAck              vwswrQueryAck;
        /* 0xC008消息 */
        T_DpdMsgVswrCheck                 vswrCheck;
        T_DpdMsgVswrCheckAck              vswrCheckAck;
        /* 0xC009消息 */
        T_DpdMsgPrintStr                  printStr;
        T_DpdMsgPrintStrAck               printStrAck;

        /* 0xC00E消息 */
        T_DpdPimOnlineCheckResult         pimOnlineCheckRes;
        T_DpdPimOnlineCheckResultAck      pimOnlineCheckResAck;

        /* 0xC00F消息 */
        T_DpdMsgGetOnlinePim2Val         pimOnlinePim2Val;
        T_DpdMsgGetOnlinePim2ValAck      pimOnlinePim2ValAck;

        /* 0x000C消息 */
        T_DpdMsgTsCtrl                  	tsCtrl;
        T_DpdMsgTsCtrlAck                  	tsCtrlAck;
        /* 0x800C消息 */
        T_DpdMsgTsQuery                	 	tsQuery;
        T_DpdMsgTsQueryAck        			tsQueryAck;

        /* 0x1C00消息 */
        T_DpdMsgDopaCaliQuery               DopaCaliQuery;
        T_DpdMsgDopaCaliQueryAck            DopaCaliQueryAck;

        /* 0x4013消息 */
        T_DpdMsgTsEnable                  	tsEnable;
        T_DpdMsgTsEnableAck                 tsEnableAck;

        /* 0x8013消息 */
        T_DpdMsgTsEnQuery                	tsEnQuery;
        T_DpdMsgTsEnQueryAck        		tsEnQueryAck;

		/* 0X4014消息 */
		T_DpdMsgSendRegVal				 SendRegVal;
		T_DpdMsgSendRegValAck			 SendRegValAck;
		/* 0x4015消息 */
        T_DpdMsgSendCfrDpdRouteInfo      sendCfrDpdRouteInfo;
        T_DpdMsgSendCfrDpdRouteInfoAck   sendCfrDpdRouteInfoAck;
		/* 0xD008消息 */
        T_DspMsgPrtQuery                  prtQuery;

        /*0x4016消息*/
        T_DpdMsgCellTsInfo                tsInfo;
        T_DpdMsgCellTsInfoAck             tsInfoAck;

        /*0x8015消息*/
        T_DpdMsgAcpCalResult              acpCalResult;
        T_DpdMsgAcpCalResultAck           acpCalResultAck;

        T_DpdMsgSendSlaveData             SendSlaveData;
        T_DpdMsgSendSlaveDataAck          SendSlaveDataAck;

        T_DpdMsgInsOnLineACCal            InsOnLineACCal;
        T_DpdMsgInsOnLineACCalAck         InsOnLineACCalAck;

        T_DpdMsgInsOnLineEVMCal           InsOnLineEVMCal;
        T_DpdMsgInsOnLineACCalAck         InsOnLineEVMCalAck;
        /*0x8016消息*/
        T_TsRequestStaMsg                 tsDspRequest;
        T_TsRequestStaMsgAck              tsDspRequestAck;

        /*0x8017消息(pimonline检测状态查询)*/
        T_DpdPimOnlineCheckSta            pimOnlineCheckSta;
        T_DpdPimOnlineCheckStaAck         pimOnlineCheckStaAck;

        /*0x801a消息(查询躁低检测状态)*/
        T_DpdNoiseSta                     pimOnlineNoiseSta;
        T_DpdDpdNoiseStaAck               pimOnlineNoiseStaAck;
        
        /*0x801b消息*/
        T_TrapEmbedLutStaMsg              trapEmbedLutSta;
        T_TrapEmbedLutStaMsgAck           trapEmbedLutStaAck;
        
        /*0x801c消息*/
        T_TrapEmbedLutQueryMsgRx          trapEmbedLutQueryRx;
        T_TrapEmbedLutQueryMsgTx          trapEmbedLutQueryTx;
        T_TrapEmbedLutQueryMsgAck         trapEmbedLutQueryAck;

        /*0x0014消息*/
        T_ChanOffRequest                  dspChanOffRequest;
        T_ChanOffRequestAck               dspChanOffRequestAck;
        /* 0x8017消息*/
        T_DpdMsgGetOnlinePimVal           OnlinePimVal;
        T_DpdMsgGetOnlinePimValAck        OnlinePimValAck;
        /*0x8018消息*/
        T_ChanOffResultQuery             dspChanOffResultQuery;
        T_ChanOffResultQueryAck          dspChanOffResultQueryAck;

        T_DspMsgDdcCtrl                   ddcCtrl;
        T_DspMsgDdcParam                  ddcParam;
        T_DspMsgDdcParamAck               ddcParamAck;

        /*0x0200消息*/
        T_AacPermitFlgMsgTx              aacPermitFlgMsgTx;

        /*0x0201消息*/
        T_DmmCfgClrMsg                   dmmCfgClrMsg;


        /*0x0203消息*/
        T_DmmCfgMsg           dmmCfgMsg;

        /*0x0204消息，配置UTDOA消息*/
        T_UtdoaCfgMsg           utdoaCfgMsg;

        /*0x0202*/
        T_DmmCfgInfoClrMsg         dmmCfgInfoClrMsg;
        
        /*0xd003消息*/
        T_DspMsgBasePrtQuery             dspBasePrn;
        T_DspMsgBasePrtQueryAck          dspBasePrnAck;

        /*线缆时延测量 0x24*/
        T_DspMsgRfDlyMes                 rfDlyMes;
        T_DspMsgRfDlyMesAck              rfDlyMesAck;
        /*线缆时延测量 0x8025*/
        T_DspMsgRfDlyMesResult           rfDlyMesResult;
        T_DspMsgRfDlyMesResultAck        rfDlyMesResultAck;

        T_DspMsgPowCalChnSw              powCalChnSw;
        T_DspMsgPowCalChnSwAck           powCalChnSwAck;

        /*0x0025消息*/
        T_DspMsgTrapMsgK0GainCtrl        trapK0GainCtrl;
        T_DspMsgTrapMsgK0GainCtrlAck     rrapK0GainCtrlAck;

        /*0x0026消息*/
        T_DspMsgSscEmbedLutGenSw        sscLutGenSw;
        T_DspMsgSscEmbedLutGenSwAck     sscLutGenSwAck;

        /*0x002C消息*/
        T_DspMsgCfrGateCfg              cfrGateCfg;
        T_DspRecvComMsg                 recvComMsg;

        /*0x0031消息*/
        T_DpdMsgSendPaCurrCali            sendPaCurrCali;
        T_DpdMsgSendPaCurrCaliAck         sendPaCurrCaliAck;

        /*0x402c消息*/
        T_DspMsgSscEmbedLutDownload     sscLutDownLoad;
        /*0x402d消息*/
        T_DspMsgSscVoltGrdCfg           sscVoltVCfg;
        T_DspMsgSscVoltGrdCfgAck        sscVoltVCfgAck;
        /*0x8026消息*/
        T_DspMsgSscLutGenTrapSta        lutGenTrapSta;
        T_DspMsgSscLutGenTrapStaAck     lutGenTrapStaAck;
        /*0x8027消息*/
        T_DspMsgSscLutGenStaUpLoad      lutGenStaUpLoad;
        T_DspMsgSscLutGenStaUpLoadAck   lutGenStaUpLoadAck;
        /*0x8028消息*/
        T_DspMsgSscLutHashVer            sscLutHashVer;
        T_DspMsgSscLutHashVerAck         sscLutHashVerAck;
        /*0x8029消息*/
        T_DspMsgDownLutCnt                downLutCnt;
        T_DspMsgDownLutCntAck             downLutCntAck;

        /*0x1803消息*/
        T_DpdMsgRfBridgeVswrCtrl          rfBridgeVswrCtrl;
        T_DpdMsgRfBridgeVswrCtrlAck       rfBridgeVswrCtrlAck;

        /*0x1807消息*/
        T_DpdMsgRfBridgeVswrFinishSta          rfBridgeVswrFinishSta;
        T_DpdMsgRfBridgeVswrFinishStaAck       rfBridgeVswrFinishStaAck;

        /*0x1809消息*/
        T_DpdMsgRfBridgeStartVswrCalc      rfBridgeStartVswrCalc;
        T_DpdMsgRfBridgeStartVswrCalcAck   rfBridgeStartVswrCalcAck;

        /*0x1808消息*/
        T_DpdMsgRfBridgeRevCalcSta         rfBridgeRevCalcSta;
        T_DpdMsgRfBridgeRevCalcStaAck      rfBridgeRevCalcStaAck;

        /*0x1804消息*/
        T_DpdMsgRfBridgeSpaCalcSta         rfBridgeSpaCalcSta;
        T_DpdMsgRfBridgeSpaCalcStaAck      rfBridgeSpaCalcStaAck;

        /*0x1800消息*/
        T_DpdMsgRfBrgVswrAcWeights         rfBridgeVswrAcWeights;
        T_DpdMsgRfBrgVswrAcWeightsAck      rfBridgeVswrAcWeightsAck;

        /*0x1801消息*/
        T_DpdMsgRfBrgVswrPreStart          rfBridgeVswrPreStart;
        T_DpdMsgRfBrgVswrPreStartAck       rfBridgeVswrPreStartAck;

        /*0x1802消息*/
        T_DpdMsgRfBrgVswrPreStartStaAck    rfBridgeVswrPreStartStaAck;

        /*0x1805消息*/
        T_DpdMsgRfBrgBreakVswr             rfBridgeBreakVswr;
        T_DpdMsgRfBrgBreakVswrAck          rfBridgeBreakVswrAck;

        /*0x1806消息*/
        T_DpdMsgRfBrgVswrStaAck            rfBridgeVswrStaAck;
 
        /*0x002F消息*/
        T_DpdMsgRfBridgeOfflinePara        rfBridgeOfflinePara;
        T_DpdMsgRfBridgeOfflineParaAck     rfBridgeOfflineParaAck;

        /*0x002E消息*/
        T_DpdMsgRfBridgeOfflineRevPara        rfBridgeOfflineRevPara;
        T_DpdMsgRfBridgeOfflineRevParaAck     rfBridgeOfflineRevParaAck;

        /*0x002D消息*/
        T_DpdMsgRfBridgeAllRfBridgeInfo    rfBridgeAllRfBridgeInfo;
        T_DpdMsgRfBridgeAllRfBridgeInfoAck rfBridgeAllRfBridgeInfoAck;

        /*0x0030消息*/
        T_DpdMsgNcrGpInfo    NcrGpPaSitInfo;
        T_DpdMsgNcrGpInfoAck NcrGpPaSitInfoAck;

        /*0x0D00消息*/
        T_DpdMsgPimOnChkModInfo       pimOnChkModInfo;
        T_DpdMsgPimOnChkModInfoAck    pimOnChkModInfoAck;

        /*0x0D01消息*/
        T_DpdMsgPimOnlineChnTx        PimOnlineChnTxInfo;
        T_DpdMsgPimOnlineChnTxAck     PimOnlineChnTxAck;

        /*0x0D02消息*/
        T_DpdMsgPimOnlineChnRx        PimOnlineChnRxInfo;
        T_DpdMsgPimOnlineChnRxAck     PimOnlineChnRxAck;
        /* Started by AICoder, pid:u6c5fc2ff45e70914ea70b83e0479516f729ccbe */
        /* 在线仪表功能开关消息 0x600 */
        T_DpdMsgInstruSwi             InstruSwi;
        T_DpdMsgInstruSwiAck          InstruSwiAck;

        /* 在线 ACP 检测发起消息 0x601 */
        T_DpdMsgInstruAcpSwi          InstruAcpSwi;
        T_DpdMsgInstruAcpSwiAck       InstruAcpSwiAck;

        /* 在线 ACP 检测结果上报消息 0x602 */
        T_DpdMsgInstruAcpSta          InstruAcpSta;
        T_DpdMsgInstruAcpStaAck       InstruAcpStaAck;

        /* 在线 EVM 检测发起消息 0x603 */
        T_DpdMsgInstruEvmSwi          InstruEvmSwi;
        T_DpdMsgInstruEvmSwiAck       InstruEvmSwiAck;

        /* 在线 EVM 检测结果上报消息 0x604 */
        T_DpdMsgInstruEvmSta          InstruEvmSta;
        T_DpdMsgInstruEvmStaAck       InstruEvmStaAck;
        /* Ended by AICoder, pid:u6c5fc2ff45e70914ea70b83e0479516f729ccbe */

        T_DpdMsgNonStandardBandSw        nonStandardBandSw;
        T_DpdMsgNonStandardBandSwAck     nonStandardBandSwAck;

        /*0x1A00消息*/
        T_DPimCaliCtrlMsg         dtpCaliCtrl;
        T_DPimCaliCtrlMsgAck      dtpCaliCtrlAck;

        /*0x1A01消息*/
        T_DPimCalibratSta             dtpCaliSta;
        T_DPimCalibratStaAck          dtpCaliStaAck;

        /*0x1A02消息*/
        T_DPimMeasureCtrlMsg          dtpMeasureCtrl;
        T_DPimMeasureCtrlMsgAck       dtpMeasureCtrlAck;

        /*0x1A03消息*/
        T_DPimMeasureSta              dtpMeasureSta;
        T_DPimMeasureStaAck           dtpMeasureStaAck;

        /*0x1A04消息*/
        T_DPimResQueryMsg             dtpMeasureResQuery;
        T_DPimResQueryMsgAck          dtpMeasureResQueryAck;

        /*0x1A05消息*/
        T_DPimDspReadySta             dtpReadySta;
        T_DPimDspReadyStaAck          dtpReadyStaAck;

        /*0x1A06消息*/
        T_DPimPreStartMsg             dtpPreStart;
        T_DPimPreStartMsgAck          dtpPreStartAck;

        /* 0x0032消息 */
        T_DspDlCellSwiInfo            tDspDlCellActiveInfo;
        T_DspDlCellSwiInfoAck         tDspDlCellActiveInfoAck;

        /* 0x1D00消息 */
        T_DpdMsgOffsetCtrl            startOffsetCtrl;
        T_DpdMsgOffsetCtrlAck         startOffsetCtrlAck;

        /* 0x1D01消息 */
        T_DpdMsgCntrctCfg             cntrctParaCfg;
        T_DpdMsgCntrctCfgAck          cntrctParaCfgAck;

        /* 0x401C消息 */
        T_RxSetPimOnlineDisableTxChanBand        sendDisableChan;
        T_DpdMsgSendDisPimOnlineInfoAck         sendDisableChanAck;

        /*0x1E00消息 */
        T_MaintainSmpCtrlMsg          dspCatchDataQueryInfo;
        T_RecvComMsg                  dspCatchDataQueryAck;

        /*0x1E01消息 */
        T_MaintainSendSmpStaMsg       dspCatchDataStatus;
        T_MaintainSmpStaMsg           dspCatchDataStatusAck;

        /*0x0033消息*/
        T_DpdSwitchStaSend            dpdSwitchStaSend;
        T_DpdSwitchSta                dpdSwitchSta;

        /* 0x1D02消息 */
        T_DpdMsgNetworkModeCfg            networkModeCfg;
        T_DpdMsNetworkModeCfgAck          networkModeCfgAck;    

    }msg;
}THpiApiPDU;



#pragma pack()

#define DSP_HEAD_LEN				             sizeof(T_DpdMsgHead)

#define DPD_CTRL_BYPASS                          0x5A5A
#define DPD_CTRL_UNBYPASS                        0x2D2D
#define DPD_CTRL_START                           0x5A5A
#define DPD_CTRL_STOP                            0x2D2D
#define DPD_UPLOAD_OVER                          0x1111


/***************************   Hpi App MsgType Define Start ********************************/
#define DPD_MSG_DPDBYPASS                        0x0001     /* DPD使能和旁路 */
#define DPD_MSG_DPDCTRL                          0x0002     /* DPD启动和停止 */
#define DPD_MSG_CLEARLUT                         0x0003     /* DPD清表 */
#define DPD_MSG_STARTVSWR                        0x0004     /* VSWR计算启动和停止 */
#define DPD_MSG_FTTEST                           0x0005     /* 启动测试DSP和FPGA之间接口 */
#define DPD_MSG_DPCT                             0x0006     /* DPCT校准计算 */
#define DPD_MSG_START_AC_WGT_CALC                0x0007     /* 启动AC权值 */
#define DPD_MSG_START_AC_REF_CHN_H_CALC          0x000B     /* 启动AC参考通道H计算 */
#define UDP_MSG_UPDATE_AC_SEQ                    0x000F
#define DPD_MSG_PIMCCTRL                         0x0008     /* PIMC启动训练和停止训练启动预训练 */
#define DPD_MSG_PIMCCLEARTBL                     0x0009     /* 清PIMC 表格*/
#define DPD_MSG_PIMCBYPASS                       0x000A     /* PIMC使能和旁路 */
#define DPD_MSG_START_AC_SEQ_CALC                0x000D     /* 启动ACDSP计算发送序列 返回0x2D2D*/
#define DPD_MSG_DPDCTRL_PIM                      0x000E     /*PimOffline流程中DPD的发起*/
#define DPD_MSG_START_VSWR_SEQ_CALC              0x0010     /* 启动ACDSP计算VSWR发送序列 返回0x2D2D*/
#define DPD_MSG_START_VSWR_WGT_CALC              0x0011     /* 启动ACDSP计算VSWR*/
#define DPD_MSG_ONLINE_PIM_CTRL                  0x0011     /* 启停Online pim检测  待确认*/
#define DPD_MSG_INS_ONLINE_AC_CAL                0x0012     
#define DPD_MSG_INS_ONLINE_EVM_CAL               0x0013     
#define DPD_MSG_PTS_LMS_CTRL                     0x0015
#define DPD_MSG_PIM_ONLINE_NOISE_CTRL            0x0016
#define DPD_MSG_PIM_ONLINE_ENERGYCAL_CTRL        0x0017
#define DPD_MSG_DMIMO_CTRL                       0x0018     /*DMIMO软件处理控制开关 */
#define DPD_MSG_SLOT_VOLT_CTRL_CFG               0x0019     /*时隙调压控制配置*/
#define DPD_MSG_SLOT_VOLT_GRP_CFG                0x001a     /*时隙调压调压组配置*/
#define DPD_MSG_HOTLOAD_CTRL                     0x001b     /*通知AC和DSP加载热补丁*/
#define DPD_MSG_MULT_FREQ_SRC_CTRL               0x001e     /*多音源发射启停控制*/
#define DPD_MSG_PIMCONFIG_ANALYSIS_CRTL          0x001f     /*启动PIM配置分析，LMS迭代*/
#define DPD_MSG_PIMCONFIG_ENERGY_CAL             0x0020     /*PIM配置分析启动能量计算检测*/
#define DPD_MSG_NON_STANDARD_BAND_CFG            0x0021     /*非标带宽标识*/
#define DPD_MSG_AC_BAND_INFO                     0x0022     /*下发CFG信息*/

#define DPD_MSG_TS_CTRLFLAG                      0x002A     /* TS控制 */
#define DPD_MSG_CFR_GATE_CFG                     0x002C     /*  将下行通道的削峰门限下发给DSP */
#define DPD_MSG_PA_CURR_CALI                     0x0031     /*  将电流校准表信息下发给DSP */

#define DPD_MSG_SETDPDPARAM                      0x4001     /* 设置参数 */
#define DPD_MSG_SETVSWRPARAM                     0x4002     /* 设置矢量驻波参数 */
#define DPD_MSG_SETCELLCFG                       0x4005     /* 设置小区配置 */
#define DPD_MSG_SENDRRUINFO                      0x4006     /* 发送整机信息 */
#define DPD_MSG_SENDPOWADJINFO                   0x4007    /*发送功率调整信息*/
#define DPD_MSG_SEND_ACDATA                      0x4008
#define DPD_MSG_SEND_VSWRDATA                    0x4009
#define DPD_MSG_SEND_FRAMESLOT_INFO              0x4010     /*时隙配比信息下发*/
#define DPD_MSG_SENDPAINFO                   	 0x4011    /*发送功放信息*/
#define DPD_MSG_SETULCELLCFG                     0x4012    /*上行小区信息*/
#define DPD_MSG_SENDTSEN                     	 0x4013
#define DPD_MSG_SENDREGVAL                     	 0x4014
#define DPD_MSG_SEND_CFR_DPD_ROUTE               0x4015     /*发送CFR_OUT到DPD_IN路由关系*/
#define DPD_MSG_SEND_TS_INFO                     0x4016     /*发送TS消息到dsp*/
#define DPD_MSG_INS_ONLINE_SEND_AC_DATA          0x4017     
#define DPD_MSG_SENDFWDPARAM                     0x4018
#define DPD_MSG_SENDFILTERPARAM                  0x4019
#define DPD_MSG_ONLINE_SEND_FILTER_PARA          (0x401a)
#define DPD_MSG_PIMCONFIG_INFO_DISTRIBUTION      0x4020     /*PIM配置分析下发配置信息*/
#define DPD_MSG_VOLT_SCHED_SWI_CFG               0x4021
#define DPD_MSG_VOLT_SCHED_PARA_CFG              0x4022
#define DPD_MSG_PIM_ONLINE_GET_RRUINFO           0x4023
#define DPD_MSG_TBLDOWNLOAD_NEW                  0x4024
#define DPD_MSG_GAINTBLDOWNLOAD                  0x4025
#define DPD_MSG_CHAN_PASTATUS                    0x4027
#define DPD_MSG_SEND_IOCTRL_STA                  0x4028
#define DPD_MSG_SEND_CHNTSSI_INFO                0x4029
#define DPD_MSG_SEND_FRDIFF_INFO                 0x402A

#define DPD_MSG_DSPSTATE                         0x8001
#define DPD_MSG_DSPVER                           0x8002
#define DPD_MSG_GETDPDPARAM                      0x8003
#define DPD_MSG_DSPSTATUS                        0x8004
#define DPD_MSG_CHECEKWATCHDOG                   0x8005
#define DPD_MSG_TEST_GET                         0x8006     /*查询DSP和FPGA之间接口的测试结果*/
#define DPD_MSG_AC_WGT_CALC_STATE                0x8007     /*查询AC权值计算结果*/
#define DPD_MSG_DSPLOADSTATE                     0x8008     /*查询DSP加载状态*/
#define DPD_MSG_VSWR_WGT_CALC_STATE              0x8013     /*查询VSWR权值计算结果*/
#define DPD_MSG_PIMCPRETRAINSTATE                0x800A     /*查询PIMC预训练状态*/
#define DPD_MSG_DPDSTATUS                        0x800B     /*查询dpd下表数目、固定时延状态*/
#define DPD_MSG_DSP_AC_DATA_RECE_COMP            0x800D     /*查询AC DSP时域数据接收结果，返回0x5A5A，与0x4008配合使用*/
#define DPD_MSG_DPDSTATUS_PIM                    0x8011     /*PIM检测中DPD训练状态查询*/
#define DPD_MSG_TSENSTATUS                       0x8013     /*查询TS使能状态信息*/
#define DPD_MSG_GETREGVAL                        0x8014     /*查询外扩寄存器的值信息*/
#define DPD_MSG_ACPRESULT                        0x8015     /*查询acp结果*/
#define DPD_MSG_GET_ONLINE_PIM_VAL               0x8017     /* 获取Online pim检测结果*/
#define DPD_MSG_DSP_PTS_LMS_STATUS_RESULT        0x8019     /* 获取PTS_LMS迭代状态*/
#define DPD_MSG_DSP_NOISE_TEST_STATUS_RESULT     0x801a     /* 获取躁低检测状态*/
#define DPD_MSG_MULT_FREQ_TRANSMIT_RESULT        0x801f     /*多音源发起完成状态*/
#define DPD_MSG_LMS_ITERATIVETASK_QUERY          0x8020     /*LMS迭代任务查询*/
#define DPD_MSG_PIMCONFIG_ANALYSIS_STATUS_QUERY  0x8021     /*PIM配置分析检测状态查询*/
#define DPD_MSG_GET_CHNPOW                       0x8022     /*子端功率上报*/

#define DPD_MSG_PIMONLINE_RRUINFO_MSG            0x0C00
#define DPD_MSG_PIMONLINE_CHECK_RES              0x0C01     /*PIM Online检测结果上报*/

#define DPD_MSG_BSPSAMCTRL                       0xC001
#define DPD_MSG_BSPSAMDONE                       0xC002
#define DPD_MSG_TBLUPLOAD                        0xC003
#define DPD_MSG_BSPSAMSTOP                       0xC004
#define DPD_MSG_TBLDOWNLOAD                      0xC005
#define DPD_MSG_CTRL_FPGA_REG                    0xC006
#define DPD_MSG_GETVSWR                          0xC007       /*读取计算结果*/
#define DPD_MSG_CHECKSTATE                       0xC008       /*查询VSWR计算状态*/
#define DPD_MSG_GETDPDSTRINFO                    0xC009       /*dpd侧字符串打印*/
#define DPD_MSG_DPCT_QUERY                       0xC00A
#define DPD_MSG_PIMONLINE_CHECK_RESULT           0xC00E       /*PIM Online检测结果上报*/
#define DPD_MSG_PIMCONFIG_RXCARRY_CALRESULT      0xC00F       /*PIM配置分析，RX载波能量检测结果上报*/

//dsp新添加消息2018.12.26
#define DPD_MSG_DSPINFO                          0xD001
#define DPD_MSG_DSPINFO_ALL                      0xD002
#define UDP_MSG_DSP_PRINTF                       0xD003
#define DPD_MSG_TBLDOWNLOAD_CEVA                 0xD004
#define DPD_MSG_TBLUPLOAD_CEVA                   0xD005
//dsp新添加消息2019.2.19
#define UDP_MSG_TS_CTRL          			 	0x000C
#define UDP_MSG_TS_QUERY          			 	0x800C
#define UDP_MSG_DOPA_CALI_QUERY                 0x1C00

#define DPD_MSG_OFFSET_CTRL                     0x1D00     /* 模拟抵消启动和停止 */
#define DPD_MSG_CNTRCT_CFG                      0x1D01     /* 模拟抵消参数配置 */
#define DPD_MSG_NETWORKMODE_CFG                 0x1D02     /* AIOT整机组网模式配置 */

#define DPD_MSG_DSP_REQUEST_TS_EN               0x8016
#define DPD_MSG_DSP_REQUEST_CHAN_OFF            0x0014
#define DPD_MSG_DSP_QUERY_CHAN_OFF_RESULT       0x8018


#define DPD_MSG_RFMES_START                     0x0024
#define DPD_MSG_RFMES_RESULT                    0x8025

#define DPD_MSG_TRAPKOGAIN_CTRL                     0x0025
#define DPD_MSG_SSCLUT_SW                           0x0026
#define DPD_MSG_CARR_SWITCH_FLAG                    0x0032
#define DPD_MSG_SSCLUT_DOWNLOAD                     0x402C
#define DPD_MSG_SSC_VOLT_CFG                        0x402D
#define DPD_MSG_SSC_TRAPSTA_GET                     0x8026
#define DPD_MSG_SSC_GENSTA_GET                      0x8027
#define DPD_MSG_SSCLUT_HASHVER                      0x8028
#define DPD_MSG_DOWNLUT_CNT                         0x8029
#define DPD_MSG_POWERCTRL_SW                        0x0029
#define DPD_MSG_AACPERMITFLG_TX                     0x0200
#define DPD_MSG_DMM_CFGCLR                          0x0201
#define DPD_MSG_DMIMO_CFG                           0x0203     /* DMIMO配置下发消息 */
#define DPD_MSG_UTDOA_CFG                           0x0204     /* UTDOA配置下发消息 */
#define DPD_MSG_DMIMO_CFGCLR                        0x0202     /* 不区分通道控制DMIMO配置信息清零的消息*/

#define DPD_MSG_RFBRIDGE_STARTVSWR                  0x1803     /* 电桥机型VSWR计算启动和停止 */
#define DPD_MSG_RFBRIDGE_VSWR_FINISH_STA            0x1807     /* 电桥机型VSWR计算完成状态查询，暂未使用 */
#define DPD_MSG_RFBRIDGE_START_VSWR_CALC            0x1809     /* 电桥机型VSWR计算完成状态查询，暂未使用 */
#define DPD_MSG_RFBRIDGE_REV_CALC_STA               0x1808     /* 电桥机型获取Rev值消息，暂未使用 */
#define DPD_MSG_RFBRIDGE_SPA_CALC_STA               0x1804     /* 电桥机型获取Spa值消息 */
#define DPD_MSG_RFBRIDGE_OFF_LINE_PARA              0x002F     /* 电桥机型发送电桥离线文件信息，暂未使用 */
#define DPD_MSG_RFBRIDGE_OFF_LINE_REV_PARA          0x002E     /* 电桥机型反射链路增益相位差信息下发消息，暂未使用 */
#define DPD_MSG_RFBRIDGE_MAP_INFO                   0x002D     /* 电桥机型发送电桥通道映射关系信息 */
#define DPD_MSG_RFBRIDGE_AC_CARR_INFO               0x1800     /* 电桥机型发送载波信息和AC权值 */
#define DPD_MSG_RFBRIDGE_PRE_START_VSWR             0x1801     /* 电桥机型预启动驻波流程 */
#define DPD_MSG_RFBRIDGE_PRE_START_STA              0x1802     /* 电桥机型预启动驻波结果 */
#define DPD_MSG_RFBRIDGE_VSWR_BREAK                 0x1805     /* 电桥机型打断DSP侧驻波计算流程 */
#define DPD_MSG_RFBRIDGE_VSWR_STA                   0x1806     /* 电桥机型驻波计算状态查询 */

#define DPD_MSG_CATCH_LINK_DATA                     0x1E00     /* DSP全链路采数发起*/
#define DPD_MSG_CATCH_LINK_DATA_STA                 0x1E01     /* DSP全链路采数状态结果查询*/
#define DPD_MSP_GET_DPD_SWITCH                      0x0033     /* 通道启停状态查询*/

#define DPD_MSG_NCR_GP_SMP_INFO                   0x0030     /* NCR机型发送GP发数延时*/

#define DPD_MSG_PIMCONFIG_CHKINFO                 0x0D00
#define DPD_MSG_PIMCONFIG_TX_CARRINFO             0x0D01
#define DPD_MSG_PIMCONFIG_RX_CARRINFO             0x0D02

#define DPD_MSG_INSTRUSW                          0x0600    /*在线仪表功能开关*/
#define DPD_MSG_INSTRUACPSW                       0x0601    /*在线ACP检测发起消息*/
#define DPD_MSG_INSTRUACPSTA                      0x0602    /*在线ACP检测结果上报*/
#define DPD_MSG_INSTRUEVMSW                       0x0603    /*在线EVM检测发起消息*/
#define DPD_MSG_INSTRUEVMSTA                      0x0604    /*在线EVM检测结果上报*/
#define DPD_MSG_DTP_CALI_START                     (0x1A00)   /* PIM校准校验启动消息 */
#define DPD_MSG_DTP_CALI_STAT                      (0x1A01)   /* PIM校准校准状态查询 */
#define DPD_MSG_DTP_MEASURE_START                  (0x1A02)   /* PIM定位校验启动消息 */
#define DPD_MSG_DTP_MEASURE_STAT                   (0x1A03)   /* PIM定位校验状态查询 */
#define DPD_MSG_DTP_MEASURE_RESULT                 (0x1A04)   /* 获取通道PIM定位最终数值 */
#define DPD_MSG_DTP_MEASURE_READY_STAT             (0x1A05)   /* 获取PIM定位预启动是否完成 */
#define DPD_MSG_DTP_MEASURE_PRE_START              (0x1A06)   /* PIM定位预启动消息 */
#define DPD_MSG_SEND_TX_DISABLE_PIM_ONLINE_INFO    (0x401c)     /* 高层APP下发不能做在线PIM1.0的通道频段信息 */
#define MAX_DPD_DOWN_LOAD_TABLE_SIZE             (6*102*1024)


#define DPD_HTONL(a)           htonl(a)
#define DPD_HTONS(a)           htons(a)
#define DPD_NTOHL(a)           ntohl(a)
#define DPD_NTOHS(a)           ntohs(a)
#define GET_DSP_ID(chan)       (chan)


#define DPD_RD_FPGA_REG                           0x5A5A
#define DPD_WR_FPGA_REG                           0x2D2D

UINT32 DpdMsgBypass(UINT32 chan, UINT32 freqNo, UINT16 type, UINT16 ctrl);

UINT32 DpdMsgGetAcSta(UINT32 chan,UINT32 freqNo,UINT32 cellId,UINT32 type,UINT16 *pstate);

UINT32 DpdMsgStartCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl);
UINT32 DpdMsgOffsetStartCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl);
UINT32 DpdMsgCntrctCfg(UINT32 chan, UINT32 freqNo, T_DpdMsgCntrctCfg *cntrctPara);
UINT32 DpdMsgAIiotNetworkMode(T_DpdMsgNetworkModeCfg *NetworkModeCfg);
UINT32 DspMsgCtrlTs(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo, UINT32 tsType, UINT32 state);
UINT32 DspMsgQueryTs(UINT32 typeId, UINT32 ulChnlNo,UINT32 ulFreqBandNo);
UINT32 DspMsgQueryDopaCali(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo);
UINT32 DpdMsgTsEn(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo, UINT16 state);
UINT32 DpdMsgQueryTsEn(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo, UINT32 *pSta);
UINT32 DpdMsgGetVer(UINT32 chan,UINT8 *pDspVer,UINT32 verLen);
UINT32 DpdMsgGetState(UINT32 chan,UINT32 freqNo, T_DpdMsgStateQueryRet *pAck);
UINT32 DpdMsgVswrStart(UINT32 chan,UINT32 freqNo);
UINT32 DpdMsgVswrStop(UINT32 chan,UINT32 freqNo);

UINT32 DpdMsgGetVswrSta(UINT32 chan,UINT32 freqNo,UINT32 *pstate);
UINT32 MsgVswrResultProc(UINT32 vswrState);
UINT32 DpdMsgSendData(UINT32 ulChan, UINT32 ulBand, UINT16 msgType, UCHAR *pdata, UINT32 len);
UINT32 DpdMsgGetVswrVal(UINT32 chan,UINT32 freqNo, T_DpdMsgVswrQueryAck *pdata);
UINT32 DpdMsgDownloadData(UINT32 chan, TUdpApiHeader *headInfo, UCHAR *pdata,UINT32 *plen);
UINT32 DpdMsgDownloadDataNew(UINT32 chan, TUdpApiHeader *headInfo, UCHAR *pdata,UINT32 dataLen);
UINT32 DpdMsgSampleCtrl(UINT32 typeId,UINT32 chan,UINT32 freqNo,UINT32 ctrl, T_DpdMsgSampleCtrl *pdata);
UINT32 DpdMsgGetSamStatus(UINT32 typeId,UINT32 chan,UINT32 freqNo, UINT32 *pState);
UINT32 DpdMsgSetCellCfg(UINT32 chan,UINT32 freqNo,T_DpdMsgSetDlCellCfgPara *pdata);
UINT32 DpdMsgSetActiveFlag(UINT32 chan, UINT32 freqNo, T_DspDlCellSwiInfo *pdata);
UINT32 DpdMsgSetUlCellCfg(UINT32 chan,UINT32 freqNo,T_DpdMsgSetUlCellCfgPara *pdata);
UINT32 DpdMsgSendRruInfo(UINT32 chan,UINT32 freqNo, T_DpdMsgSendRruInfo *pdata);
UINT32 DpdMsgSendPowAdjInfo(UINT32 chan, UINT32 freqNo, T_DpdMsgSendPowAdjInfo * pdata);
UINT32 DpdMsgSendDmimoCtrl(UINT32 chan, UINT32 bandId, T_DpdDmmCtrlMsg * pdata);
UINT32 DpdMsgSetPara(UINT32 chan,UINT32 freqNo, T_DpdMsgSetSignalPara *pdata);
UINT32 DpdMsgPimcCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl);
UINT32 DpdMsgPimcPreTrainState(UINT32 chan,UINT32 freqNo,UINT32 *pstate);
UINT32 DpdMsgPimcClrTbl(UINT32 chan,UINT32 freqNo);
UINT32 DpdMsgPimcBypass(UINT32 chan, UINT32 freqNo, UINT32 ctrl);
UINT32 DpdMsgClrLut(UINT32 chan,UINT32 freqNo, UINT32 ctrl);
UINT32 DpdMsgTsFlagCtrl(UINT32 chanmask, UINT32 ctrl);
UINT32 DpdMsgDspLoadState(UINT32 chan,UINT32 freqNo,UINT32 *pstate);
UINT32 DpdMsgGetDpdStr(UINT32 chan,UINT32 freqNo, T_DpdMsgPrintStr *pdata);
UINT32 DpdMsgWrFpgaReg(UINT32 chan,UINT32 freqNo, UINT32 addr, UINT32 data);
UINT32 DpdMsgRdFpgaReg(UINT32 chan,UINT32 freqNo, UINT32 addr, UINT32 *pRddata);
UINT32 DpdMsgGetDog(UINT32 chan,UINT32 freqNo, UINT32 *pWatchDogCnt);
UINT32 DspMsgPrintf(UINT32 typeId, UINT32 ulChnlNo,UINT32 ulFreqBandNo,T_DspMsgPrtQuery *pDspMsgPrtQuery,UINT32 pucBufLen,UINT8 *pucBuf, UINT32 *pulLen);
UINT32 DpdMsgStartModeCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl, UINT32 mode_type);
UINT32 DpdMsgSendCfrDpdRouteInfo(UINT32 chan,UINT32 freqNo,T_DpdMsgSendCfrDpdRouteInfo *pdata);
UINT8 GetUdpSrcId();
UINT8 GetUdpDstId();
UINT32 GetAcUdpCpuId();
UINT32 GetAcUdpDspId();
UINT32 GetReqOrAck();
UINT32 BspSetBoardAcNxpOrSocFlag(VOID);
UINT32 DpdMsgDspRequireTsEn(UINT32 typeId, UINT32 chan,UINT32 freqNo,T_DpdTsExpQueryResult *dspRequst);
UINT32 DpdMsgDspChanOffRequst(UINT32 typeId, UINT32 chan,UINT32 freqNo,T_ChanOffRequest *chanOffRequst);
UINT32 DpdMsgDspChanOffStaQuery(UINT32 typeId, UINT32 chan,UINT32 freqNo, UINT32 *result);
UINT32 DspMsgBasePrintf(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo, T_DspMsgBasePrtQuery *pDspMsgPrtQuery, UINT8 *pucBuf, UINT32 *pulLen);
UINT32 DpdMsgSendFwdParam(UINT32 chan, UINT32 freqNo, T_DpdMsgSendFwdParam * pdata);
UINT32 DpdMsgSendFilterParam(UINT32 chan, UINT32 freqNo, T_DpdMsgSendFilterParam * pdata);
UINT32 DpdMsgFastAdjVoltPwrSwitchCfg(T_DpdMsgFastAdjVoltSwitch *pdata);
UINT32 DpdMsgFastAdjVoltParaCfg(T_DpdMsgFastAdjVoltPara *pdata);
UINT32 DpdMsgStartCtrlOnlinePim(UINT32 chan, UINT32 freqNo, UINT32 ctrl);
UINT32 DpdMsgGetPimVal(UINT32 chan, UINT32 freqNo, T_DpdMsgGetOnlinePimValAck *pimdata);
UINT32 DpdMsgGetAcpCalResult(UINT32 chan, T_DpdMsgAcpCalResultAck *pAcpCalResult);
VOID SetDspPrnType(UINT32 type);
UINT32 DpdMsgPimDpdStateQuery(UINT32 chan, UINT32 freqNo, T_DpdMsgPimDpdStateQueryAck *pimDdpState);
UINT32 DpdMsgStartCtrlPim(UINT32 chan, UINT32 freqNo);
//PIM Online高层流程调用接口
UINT32 DpdPtsLmsStartCtrl(UINT32 ctrl);
UINT32 DpdGetPtsLmsStatus(T_DpdLmsStatusAck *lmsStatus);
UINT32 DpdNoiseCheckStartCtrl(UINT32 slotindexssss);
UINT32 DpdGetNoiseCheckStatus(T_DpdDpdNoiseStaAck *noiseCheckSta);
UINT32 DpdPimOnlineEnergyCalCtrl(T_DpdPimOnlineEnergyCalCtrl *pimOnlineEnergyCalCtrl);
UINT32 DpdGetPimOnlineCheckSta(UINT32 *pimOnlineCheckSta);
UINT32 DpdGetPimOnlineCheckResult(T_DpdPimOnlineCheckResultAck *pimOnlineCheckRes);
UINT32 DpdGetPimOnlineCheckRes(UINT32 chan, T_DpdPimOnlineResultAck *checkRes);
UINT32 DpdPimOnlineGetRruInfo(T_DpdPimOnlineHwRruInfo *PimOnlineRruInfo);
UINT32 DpdPimOnlineRruInfoCfg(T_PimOnlineRruInfoMsg *rruCfgInfo);
UINT32 DpdMsgSlotVoltCtrlCfg(T_DpdSlotVoltCtrlInfo *pdata);
UINT32 DpdMsgSlotVoltGrpCfg(T_DpdSlotVoltGrpInfo *pdata);
UINT32 DpdMsgSendFilterPara(UINT32 chan, UINT32 freqNo, T_VswrPosCalcPara *para);
UINT32 DpdMsgDownloadGainTblData(UINT32 chan, UCHAR *pdata, UINT32 dataLen);
UINT32 DpdMsgSendPaStatus(UINT32 bspChan, T_ChanPaStaMsg * pdata);
UINT32 DpdMsgMultFreqSrcCtrl(UINT32 chan, T_DpdMultFreqSrcCtrlMsg *para);
UINT32 DpdGetPwdCaliResult(UINT32 chan, T_DpdPwdCaliMsg *launchSta, T_PwdCaliResult *para);
UINT32 DpdMsgSlotVoltTrapEmbedLutCtrl(T_TrapEmbedLutCtrlMsg *pdata);
UINT32 DpdMsgChkTrapEmbedLutSta(T_TrapEmbedLutStaMsg *pdata);
UINT32 DpdMsgSendRfIoCtrlMode(UINT32 chan, T_DspMsgRfIoCtrlMode * pdata);
UINT32 DpdMsgSendChTssiInfo(UINT32 chan, T_DspMsgChnTssiInfo * pdata);
UINT32 DpdMsgGetChnPowInfo(UINT32 chan, T_DspMsgChnPowInfoAck * pdata);
UINT32 DpdMsgSetPimOnlinePara(T_DpdMsgSetOnlinePimPara *pdata);
UINT32 DpdMsgPimConfigDistribute(T_DpdMsgSetOnlinePimPara *pdata);
UINT32 DpdMsgGetOnlinePim2Val(UINT32 chan, T_DpdMsgGetOnlinePim2ValAck *pimData);
UINT32 DpdPimCfgEnergyCalCtrl(INT32 ctrl, INT32 slotindex);
UINT32 DpdPimCfgAnalysisQuery(UINT32 *pimChkSta);
UINT32 DpdPimConfigLmsCtrl(INT32 ctrl);
UINT32 DpdPimChkLmsIterSta(VOID);
UINT32 DpdMsgSendFrDiffInfo(UINT32 bspChan, T_DspMsgFrDiffInfo * pdata);
UINT32 DpdMsgRfDlyMes(UINT32 chan, T_DspMsgRfDlyMes *pData, T_DspMsgRfDlyMesAck *pDataAck);
UINT32 DpdMsgRfDlyMesResult(UINT32 chan, T_DspMsgRfDlyMesResultAck *pDataAck);
UINT32 DpdMsgSetTrapK0GainCtrl(UINT32 bspChan, T_DspMsgTrapMsgK0GainCtrl *pdata);
UINT32 DpdMsgSetSscLutGenCtrl(UINT32 bspChan, T_DspMsgSscEmbedLutGenSw * pdata);
UINT32 DpdMsgSscLutDownload(UINT32 bspChan, T_DspMsgSscEmbedLutDownload *pdata);
UINT32 DpdMsgSetSscVoltGrdCfg(UINT32 bspChan, T_DspMsgSscVoltGrdCfg *pdata);
UINT32 DpdMsgGetSscTrapSta(UINT32 bspChan, T_DspMsgSscLutGenTrapStaAck *pData);
UINT32 DpdMsgGetSscGenStaUpLoad(UINT32 bspChan, T_DspMsgSscLutGenStaUpLoad *pData, T_DspMsgSscLutGenStaUpLoadAck *pDataAck);
UINT32 DpdMsgSscLutHashVer(UINT32 bspChan, T_DspMsgSscLutHashVerAck *pDataAck);
UINT32 DpdMsgGetDownLutCnt(UINT32 bspChan, T_DspMsgDownLutCntAck *pDataAck);
UINT32 DpdMsgPowCalChnSw(UINT32 chan, T_DspMsgPowCalChnSw *pData, T_DspMsgPowCalChnSwAck *pDataAck);
UINT32 DspMsgGetAacPermitFlgTx(T_AacPermitFlgMsgTx *aacPermitFlgMsgTx);
UINT32 DpdMsgSetCfrGateCfg(UINT32 chan, T_DspMsgCfrGateCfg *pdata);
VOID MsgResultProc(UINT16 result);
/* Started by AICoder, pid:ea19bv763bk619a142090aa6208b920299492e5b */
UINT32 DpdMsgSendInstruSw(UINT32 chan, T_DpdMsgInstruSwi *pdata);
UINT32 DpdMsgSendInstruAcpSw(UINT32 chan, T_DpdMsgInstruAcpSwi *pdata);
UINT32 DpdMsgRecvInstruAcpSta(UINT32 chan, T_DpdMsgInstruAcpStaAck *pdata);
UINT32 DpdMsgSendInstruEvmSw(UINT32 chan, T_DpdMsgInstruEvmSwi *pdata);
UINT32 DpdMsgRecvInstruEvmSta(UINT32 chan, T_DpdMsgInstruEvmStaAck *pdata);
/* Ended by AICoder, pid:ea19bv763bk619a142090aa6208b920299492e5b */
UINT32 DpdMsgVswrStart_RfBridge(T_DpdMsgRfBridgeVswrCtrl *pdata);
UINT32 DpdMsgVswrStop_RfBridge(T_DpdMsgRfBridgeVswrCtrl *pdata);
UINT32 DpdMsgGetVswrFinishSta_RfBridge(UINT32 chan, T_DpdMsgRfBridgeVswrFinishStaAck *pDataAck);
UINT32 DpdMsgStartVswrCalc_RfBridge(UINT32 rfBridgeIdx,UINT32 vswrType);
UINT32 DpdMsgGetRevVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeRevCalcStaAck *pDataAck);
UINT32 DpdMsgGetSpaVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeSpaCalcStaAck *pDataAck);
UINT32 DpdMsgSendRfBridgeParam( T_DpdMsgRfBridgeOfflinePara * pdata);
UINT32 DpdMsgSendRfBridgeRevParam( T_DpdMsgRfBridgeOfflineRevPara * pdata);
UINT32 DpdMsgSendRfBridgeMapInfo( T_DpdMsgRfBridgeAllRfBridgeInfo * pdata);
UINT32 DpdMsgDmimoSetFlag(T_DmmCfgClrMsg *pdata);
UINT32 DpdMsgSendDmmCfg(UINT32 chan, UINT32 bandId,T_DmmCfgMsg * pdata);
UINT32 DpdMsgSendUtdoaCfg(UINT32 chan, UINT32 bandId,T_UtdoaCfgMsg * pdata);
UINT32 DpdSetDmmCfgClrFlg(T_DmmCfgInfoClrMsg * pdata);
UINT32 DpdMsgNonStandardBandSw(UINT32 uiSwitch, UINT32 uiBandWidth, UINT16 *result);
UINT32 DpdMsgDtpCaliStart(T_DPimCaliCtrlMsg *dtpCaliCtrl);
UINT32 DpdMsgGetDtpCaliStat(UINT32 *dtpCaliSta);
UINT32 DpdMsgDtpMeasureStart(UINT32 startCtrl, UINT32 slotIndex);
UINT32 DpdMsgGetDtpMeasureStat(UINT32 *dtpMeasureSta);
UINT32 DpdMsgGetDtpMeasureResult(UINT32 difChan, UINT32 band, T_DPimResQueryMsgAck *dtpMeasureRes);
UINT32 DpdMsgGetDtpPreStartStat(UINT32 *dtpDspReadySta);
UINT32 DpdMsgDtpPreStart(INT32 startCtrl, UINT32 tddFlagChan);
UINT32 DpdMsgSendRfBridgeAcCarrInfo(T_DpdMsgRfBrgVswrAcWeights *pData);
UINT32 DpdMsgSendRfBrgVswrPreStart(T_DpdMsgRfBrgVswrPreStart *pData);
UINT32 DpdMsgGetRfBrgVswrPreStartSta(T_DpdMsgRfBrgVswrPreStartStaAck *pDataAck);
UINT32 DpdMsgSendRfBrgBreakVswr(void);
UINT32 DpdMsgGetRfBrgVswrSta(T_DpdMsgRfBrgVswrStaAck *pDataAck);
UINT32 DpdMsgSendPaCurrentCaliInfo(UINT32 chan,UINT32 freqNo,T_DpdMsgSendPaCurrCali *pdata);
UINT32 DpdMsgSendNcrGpInfo(UINT32 bspChan, T_DpdMsgNcrGpInfo * pdata);
UINT32 DpdMsgSendBandInfo(T_DpdMsgAcBandInfo *pdata, UINT16 *result);
UINT32 DpdMsgSendDisablePimOnlineTxChanPara(UINT32 chan, UINT32 freqNo, T_RxSetPimOnlineDisableTxChanBand *pdata);
UINT32 DpdMsgCatachDspLinkData(T_MaintainSmpCtrlMsg *pdata);
UINT32 DpdMsgGetCatchDspLinkDataResult(UINT32 *status, INT32 *result);
UINT32 DpdMsgGetDpdSwitch(UINT32 *uiswitch, INT32 *result, UINT32 chan);
#ifdef __cplusplus
}
#endif

#endif  /* _DSPMSG_H_ */

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : msgproc.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了热补丁msg相关接口
* 注意事项 : 无
* 作    者 : NR2.0
* 创建日期 : 2023-10-19
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _MSGPROC_H_
#define _MSGPROC_H_

#ifdef __cplusplus
extern "C"{
#endif
#include "bsppub.h"
#include "dsp_msg.h"

UINT32 SendHpiMsg(UINT16 chan, THpiApiPDU *pSend, THpiApiPDU *pRecv);
UINT32 SendHpiMsgAcDsp(UINT16 chan, THpiApiPDU *pSend, THpiApiPDU *pRecv);
UINT32 SendHpiMsgAcDspIC(UINT32 chan, THpiApiPDU *pSend, THpiApiPDU *pRecv);
UINT32 BspUdpMsgProc(UINT32 typeId, UINT8 *ptDpdUdpSend, UINT8 *ptDpdUdpRecv);


#ifdef __cplusplus
}
#endif

#endif  /* _MSGPROC_H_ */

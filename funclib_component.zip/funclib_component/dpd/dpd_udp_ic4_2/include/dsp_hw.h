/*********************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司。
* 
* 文件名称： DSP_HW.h
* 文件标识： 
* 内容摘要： HPI物理层头文件
* 其它说明： 
* 当前版本： 1.0
* 作    者： 
* 完成日期： 2007-06-12
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：
**********************************************************************/

#ifndef	DSP_HW_H
#define	DSP_HW_H

#ifdef __cplusplus
extern "C"
{
#endif

UINT32 DspHwInit(UINT32 dspId);
UINT32 DspMsgSnd(UINT32 dspId, UINT32 *pData, UINT32 offset, UINT32 len);
UINT32 DspMsgRev(UINT32 dspId, UINT32 *pData, UINT32 offset, UINT32 len);
UINT32 DspMemWr(UINT32 dspId, UINT32 *pData, UINT32 addr, UINT32 len);
UINT32 DspMemRd(UINT32 dspId, UINT32 *pData, UINT32 addr, UINT32 len);
UINT32 GetDspLoadFlag(UINT32 dspId);
UINT32 DspRecvIsReady(UINT32 dspId);
UINT32 DspAccessRequire(UINT32 dspId);
UINT32 DspCloseAccessLink(UINT32 dspId);

#ifdef __cplusplus
}
#endif

#endif  /* DSP_HW_H */


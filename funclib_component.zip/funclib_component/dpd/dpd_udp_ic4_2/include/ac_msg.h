/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ac_msg.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板的结构体、变量、参数配置
* 注意事项 : 无
* 作    者 : NR2.0
* 创建日期 : 2023-10-18
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _ACMSG_H_
#define _ACMSG_H_

#ifdef __cplusplus
extern "C"{
#endif
#include "bsppub.h"
#include "dsp_msg.h"

UINT32 DpdMsgGetVerAcDsp(UINT32 chan,UINT8 *pDspVer,UINT32 verLen);
UINT32 DpdMsgUploadDataAcDsp(UINT32 chan, UINT32 freqNo, UINT32 datatype, UINT8 *pdata, UINT32 *plen);
UINT32 DpdMsgGetDpdStrAcDsp(UINT32 chan,UINT32 freqNo, T_DpdMsgPrintStr *pdata);
UINT32 DpdMsgGetDpdStrAcDspInfo(UINT32 chan,UINT32 freqNo, T_DpdMsgPrintStr *pdata,UINT8 *pbyPrintArray);
UINT32 DpdMsgAcCtrl(UINT32 chan,UINT32 freqNo,UINT32 acType);
UINT32 DpdMsgGetAcWgtSta(UINT32 chan,UINT32 freqNo,UINT32 cellId,UINT32 type,UINT16 *pstate, UINT32 acType);
UINT32 DpdMsgGetDogAcDsp(UINT32 chan,UINT32 freqNo, UINT16 *pWatchDogCnt);
UINT32 DpdMsgStartAcSeqCalc(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT16 *result);
UINT32 DpdMsgStartAcSeqCalc4(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT16 *result, UINT32 refChan, UINT32 preciseDlyFlag);
UINT32 DpdMsgChkAcDspRecvAcSeqOk(UINT32 chan,UINT32 freqNo, UINT16 *result);
UINT32 DpdMsgSendAcData(UINT32 chan,UINT32 freqNo, T_DpdMsgSendAcData_NEW* data, UINT16 *result);
UINT32 MsgInsOnLineCal(UINT32 chan,UINT32 uiBandWidth,UINT32 OnlineInsType,UINT32 uiSampleRate, UINT32 uMode);
UINT32 DpdMsgSetParaAcDsp(UINT32 chan,UINT32 freqNo, T_DpdMsgSetSignalPara *pdata);
UINT32 AcMsgSendRruInfo(UINT32 chan,UINT32 freqNo, T_ACMsgSendRruInfo *pdata);

UINT32 DpdMsgGetDogAcDspIC(UINT32 chan,UINT32 freqNo, UINT16 *pWatchDogCnt);
UINT32 DpdMsgSendAcDataIc(UINT32 chan,UINT32 freqNo, T_DpdMsgSendAcData_NEW* data,UINT16* result, UINT32 acType);
UINT32 DpdMsgSendInsOnLineDataIc(UINT32 chan,UINT32 freqNo,T_DpdMsgSendSlaveData *data,UINT16* result);
UINT32 DpdMsgSendAcDataIc4(UINT32 chan,UINT32 freqNo, T_DpdMsgSendAcData_NEW_IC4* data,UINT16* result, UINT32 acType);

UINT32 AcdspMsgGetDog(UINT32 ulSocketId, UINT32 ulChnlNo,UINT32 ulFreqBandNo, UINT32 *pulWatchDogCnt);
UINT32 DpdMsgJacRefChnHCtrl(UINT32 chan,UINT32 freqNo,UINT32 acType);

UINT32 DspMsgJacUpdateAcConjFreqSeq(UINT32 chan, UINT32 JacConjFreqSeqUpdateFlag);
#ifdef __cplusplus
}
#endif

#endif  /* _ACMSG_H_ */

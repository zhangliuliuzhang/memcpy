/*********************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司。
*
* 文件名称： ac_app.h
* 文件标识：
* 内容摘要： HPI 应用层实现的实现的头文件
* 其它说明：
* 当前版本： DFPV2.0
* 作    者 ：
* 完成日期： 2023-10-18
*
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：

**********************************************************************/

#ifndef FUNCLIB_DPD_AC_APP_H
#define FUNCLIB_DPD_AC_APP_H

#include "bsppub.h"
#include "dsp_msg.h"
#include "udpmsg_ic.h"
#include "msgproc.h"

#ifdef __cplusplus

extern "C"
{
#endif

/**************************************************************************
 *                      宏定义                                         *
 **************************************************************************/

#define AC_UDP_SHELL_COMMD_RESULT              0x1000
#define AC_UDP_SHELL_COMMD_SUCCESS             (AC_UDP_SHELL_COMMD_RESULT + 0x01)
#define AC_UDP_SHELL_COMMD_MSG_ERROR           (AC_UDP_SHELL_COMMD_RESULT + 0x02)
#define AC_UDP_SHELL_COMMD_FUN_UNKNOW          (AC_UDP_SHELL_COMMD_RESULT + 0x03)
#define AC_UDP_SHELL_COMMD_OPEN_FILE_ERROR     (AC_UDP_SHELL_COMMD_RESULT + 0x04)
#define AC_UDP_SHELL_COMMD_RD_FILE_ERROR       (AC_UDP_SHELL_COMMD_RESULT + 0x05)
#define AC_UDP_SHELL_COMMD_REDIRECT_ERROR      (AC_UDP_SHELL_COMMD_RESULT + 0x06)

#define AC_CMD_LENTH        127
#define AC_CMD_PARA_NUM   10
#define AC_CMD_STDIO_INFO_LENTH   (1024 * 4)
#define MAKE_FOURCC(a,b,c,d) \
( ((ULONG)d) | ( ((ULONG)c) << 8 ) | ( ((ULONG)b) << 16 ) | ( ((ULONG)a) << 24 ) )
#define AC_CMD_FUNC       MAKE_FOURCC('@','C','M','D')

#define MSG_TYPE_SOC_AC_CMD                0x0002     //主向从发送soccmd

#define AC_DSP_RETURN_CHK_FINE                   0x2D2D
#define AC_DSP_RETURN_CHK_NOT_FINE               0x5A5A

#pragma pack(1)
/* 0x02消息--soccmd */
typedef struct tagT_CmdParam
{
    UINT32 ulmask;                      /* mask always FUNC_CMD_MASK*/
    INT8   ucCmd[AC_CMD_LENTH + 1];             /* 命令 */
    UINT32 ucRsv1[4];                     /* 备用 */
}T_AcCmdParam;

typedef struct tagT_AcMsgSocCommandAck
{
    UINT32 ulmask;                      /* mask always FUNC_CMD_MASK*/
    char   ucCmd[AC_CMD_LENTH + 1];                    /* 命令 */
    INT32  cmdRet;                     /* 函数返回值 */
    char   cmdOutInfo[AC_CMD_STDIO_INFO_LENTH + 1];              /* 输出的函数执行打印512的深度*/
    UINT32 ulFuncParams[AC_CMD_PARA_NUM];             /* 参数,最多支持10个参数 */
    UINT32 cmdErrReason;
}T_AcMsgSocCommandAck;

typedef struct tagT_SocAcMsgPDU
{
    UINT16 lenAPDU; /* length of head+msg */
    union
    {
        UINT8 headbuff[MAX_UPD_MSG_HEAD];
        TUdpApiHeader head;
    };
    union
    {
        UINT8 buf[MAX_UPD_MSG_BODY];
        /* 0x02消息 */
        T_AcCmdParam tCmdParam;
        T_AcMsgSocCommandAck tMsgSocCommandAck;
    }msg;
}TSocAcApiPDU;


typedef struct tagT_AcSocMsgPara
{
    UINT32 typeId;
    UINT8 srcId;
    UINT8 dstId;
    UINT32 len;
    UINT32 cmdLen;
}T_AcSocMsgPara;

UINT32 BspAcWgtCalcIc(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 refChan);
UINT32 BspGetAcWgtCalcSta(UINT32 chan,UINT32 acType);
UINT32 BspAcSeqCalcIc(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType);
UINT32 BspAcSeqCalcIc4(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag);
UINT32 BspMsgInsOnLineCal(UINT32 uiBandWidth,UINT32 OnlineInsType,UINT32 uiSampleRate, UINT32 uMode);
UINT32 BspAcSetRruInfo(UINT32 chan,UINT32 bandId);
UINT32 BspSendHaulBackAcDataIc(T_DpdMsgSendAcData_NEW* data, UINT32 acType);
UINT32 BspSendInsOnLineDataIc(T_DpdMsgSendSlaveData* sendData);
UINT32 BspSendHaulBackAcDataIc4(T_DpdMsgSendAcData_NEW_IC4* data, UINT32 acType);
UINT32 BspGetAcDspWatchDog(UINT32 ulTypeId, UINT32 chan, UINT32 bandId, UINT32 *pulWtdCnt);
UINT32 BspJacRefChHCalc(UINT32 acType, UINT32 carrNo);
UINT32 JacUpdateAcConjFreqSeq(UINT32 JacConjFreqSeqUpdateFlag);
UINT32 BspAcSocCmd(UINT8 chan,CHAR *cmd, UINT32* outPut);
UINT32 BspAcSetNonStandardBandSw(UINT32 uiSwitch, UINT32 uiBandWidth);
UINT32 BspAcBandInfoIc42(UINT32 carrNo,UINT32 radiomode ,UINT32 carrFreq, UINT32 bandWidth,UINT32 bandNo);
#ifdef __cplusplus
}
#endif

#endif  /* FUNCLIB_DPD_AC_APP_H */


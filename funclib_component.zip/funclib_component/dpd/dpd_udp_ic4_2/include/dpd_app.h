/*********************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司。
* 
* 文件名称： dpd_app.h
* 文件标识：
* 内容摘要： HPI 应用层实现的实现的头文件
* 其它说明：
* 当前版本： DFPV2.0
* 作    者 ： 190699
* 完成日期： 2007-06-12
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：

**********************************************************************/

#ifndef FUNCLIB_DPD_DPD_APP_H
#define FUNCLIB_DPD_DPD_APP_H
#include "dsp_msg.h"
#include "funccommon_chncfg.h"
#include "cbswcfg.h"
#include "powerctrl_ic4_2.h"
#include "regdrv.h"
#ifdef __cplusplus

extern "C"
{
#endif

/**************************************************************************
 *                      宏定义                                         *
 **************************************************************************/
#define HPI_PAYLOAD_APDU                    232
#define ALARM_CLASS_NUM                     20
#define DPD_STATE_NUM                       18

#define SAMP_CHANNEL_NUM                    2

#define POW_GRADE_SUM                       7

#define Record_MAX_CHAN_NUM                 16
#define Record_DspPrnLen                    8192
#define E_TDD_TYPE_TS                       10
#define E_TDD_TYPE_NORMAL                      2
#define E_CFG_TS_TYPE                       0
#define DPD_START                                0x5A5A
#define DPD_STOP                                 0x2D2D

#define DPD_UNBYPASS                             0x5A5A
#define DPD_BYPASS                               0x2D2D

#define DPD_OFFSET_START                         0x5A5A
#define DPD_OFFSET_STOP                          0x2D2D

#define PA_MAX_SWITCH                            2

#define ONLINE_PIM_SUCC      0x11
#define ONLINE_PIM_CALC      0x22
#define ONLINE_PIM_FAIL      0x33

#define DTP_START            (0x5A5A)

typedef struct
{
    UINT32 fl;          /* GSM跳频范围左边界,单位:KHZ */
    UINT32 fh;          /* GSM跳频范围右边界,单位:KHZ */
    UINT32 bw;          /* GSM跳频范围带宽,单位:KHZ */
    UINT32 flVir;       /* GSM跳频范围虚拟左边界,单位:KHZ */
    UINT32 fhVir;       /* GSM跳频范围虚拟右边界,单位:KHZ */
    INT32 gap;          /* 和前一个跳频范围的距离,单位:KHZ */
    UINT32 gapUsedFlag; /* gap是否被使用 */
} T_GsmHopInfo;         /* 描述GSM跳频区间 */
typedef struct
{
    UINT32 carrNo;      /* GSM载波号 */
    UINT32 centerFreq;  /* GSM载波配置中心频点 */
    UINT32 ptsFreq;     /* 计算过后的GSM频点 */
    UINT32 bw;          /* GSM带宽, */
} T_GsmCarrInfo;        /* 描述GSM载波信息 */
typedef struct
{
    UINT32 hopCnt;      /* 未合并的跳频区间数量 */
    UINT32 hopCntMerge; /* 合并后的跳频区间数量 */
    T_GsmHopInfo hopInfo[DPD_SOCKET_MAX_CARR_NUM];      /* GSM跳频区间信息 */
    UINT32 gsmCarrCnt;  /* GSM载波总数量 */
    T_GsmCarrInfo carr[DPD_SOCKET_MAX_CARR_NUM];        /* GSM载波信息,包含跳频和不跳频 */
    UINT32 bwSum;       /* 载波合并后的带宽总和 */
    UINT32 val;         /* 频率间隔 */
    T_GsmCarrInfo *hopCarr[DPD_SOCKET_MAX_CARR_NUM];    /* 指针,指向跳频载波的结构体 */
    UINT32 noHopCnt;    /* 非跳频载波数量 */
    T_GsmCarrInfo *noHopCarr[DPD_SOCKET_MAX_CARR_NUM];  /* 指针,指向非跳频载波的结构体 */
} T_GsmHopChanInfo;

typedef struct
{
    UINT8 dspprn_ucBuf[Record_MAX_CHAN_NUM][Record_DspPrnLen];   

} RecordPrnResult;

typedef struct tagT_CarrPara
{
    UINT32 carrMode;
    UINT32 carrNo;
}T_CarrPara;

typedef struct tagT_FreqCarrNcoInfo
{
    INT32 bandNco;
    INT32 carrNco;
    INT32 tranNco;
    INT32 fbNco;
}T_FreqCarrNcoInfo;

typedef UINT32 (*GetFreqFbNcoInfoFunc)(UINT32 bspchan, INT32 *pfbNco);
typedef UINT32 (*GetFreqTranNcoInfoFunc)(UINT32 bspchan, UINT32 dir, INT32 *ptranNco);
typedef UINT32 (*SetDpdSwModeInfoFunc)(UINT32 tsktype);
typedef UINT32 (*SetGainFlagFunc)(VOID);

/*************************************************************************
 *                        函数申明                                      *
 **************************************************************************/

UINT32 BspDpdPimcStart(UINT32 chan,UINT32 bandId);
UINT32 BspDpdPimcStop(UINT32 chan,UINT32 bandId);
UINT32 BspDpdPimcPreTaining(UINT32 chan,UINT32 bandId);
UINT32 BspDpdPimcPreTrainSta(UINT32 chan,UINT32 bandId);
UINT32 BspDpdPimcClrLut(UINT32 chan,UINT32 bandId);
UINT32 BspDpdPimcByPass(UINT32 chan);
UINT32 BspDpdPimcUnByPass(UINT32 chan);
UINT32 BspDpdPimcSetFreqPara(UINT32 chan,UINT32 bandId,UINT32 rxCenter,UINT32 pimcCenter,UINT32 pimcBw);
UINT32 BspDpdCtrReInit(UINT32 chan,UINT32 bandId);
UINT32 BspGetDspVswr(UINT32 chan,UINT32 bandId,INT32 *pVswrReal, INT32 *pVswrImag,INT32 *pNco);

UINT32 BspGetDspWatchDog(UINT32 ulTypeId, UINT32 ulBspChnl, UINT32 ulBandId, UINT32 *pulWtdCnt);
UINT32 BspNotifyDpdStartVswrCalc(UINT32 chan,UINT32 bandId);
UINT32 BspSampleDpdData(UINT32 typeId,UINT32 chan,UINT32 bandId, UINT8 *pBuf, UINT32 *pBufLen,
                                     UINT32 flag, UINT32 pos, const char *hostIP, const char *fileName);
UINT32 DpdMsgUploadData(UINT32 typeId,UINT32 chan,UINT32 freqNo, UINT32 datatype,UCHAR *pdata,UINT32 *plen);
///////////////////////////////////////////////////////////////////////
UINT32 DpdDfpGetHwBdType(VOID);
//UINT32 DpdDfpSetBdTypeCallBack(pGetHwBoardType pCallBackFunc);
UINT32 BspSetFixFreq(UINT32 uFixFreq);
UINT32 BspGetAcGetBwStatus(VOID);
UINT32 BspSetSampleTimes(INT32 times);
//UINT32 BspDpdSetCfrDpdRouteCfg(T_DpdMsgSendCfrDpdRouteInfo* sendCfrDpdRouteInfo);
///////////////////////////////////////////////////////////////////////

UINT32   BspSetBoardPara(UINT32 uBoardPara);
UINT32   BspGetBoardPara(VOID);
VOID  BspSetAcSetBwStatus(UINT32 udpdBwMsgFlag);
UINT32 BspGetLoFreqChanged(UINT32 dir, UINT32 chan);
UINT32 BspAdpGetDflFreqValue( UINT32 ulIndex, UINT32 ulAntNo, UINT32 ulDflChan, UINT32 ulBand, UINT32 ulTxRx, UINT32 ulFlag, UINT32 *pValue );
UINT32 DpdMsgSendTsInfo(UINT32 chan,UINT32 freqNo,T_DpdMsgCellTsInfo *pdata);
UINT32 BspDpdSendPaCurrCali(UINT32 fileNo);
UINT32 DpdMsgSetFrameSlotCfg(UINT32 chan, UINT32 freqNo, UINT32 slotIndex, UINT32 gpNum);
UINT32 BspGetDpdType(VOID);
UINT32 DpdMsgSendPaInfo(UINT32 chan, UINT32 freqNo, T_DpdMsgSendPaInfo * pdata);
UINT32 BspSetAcPhaseDiffMode(UINT32 phaDiff);
UINT32 BspGetCarrCfgBw(VOID);

UINT32 GetFreqTranNcoInfoCallBackInit(GetFreqTranNcoInfoFunc pFun);
UINT32 GetFreqFbNcoInfoCallBackInit(GetFreqFbNcoInfoFunc pFun);
UINT32 SetDpdSwModeInfoCallBackInit(SetDpdSwModeInfoFunc pFun);
UINT32 SetGainFlagCallBackInit(SetGainFlagFunc pFun);
UINT32 BspGetFpgaDpdType();
UINT32 BspGetCarrNcoInfo(UINT32 bspchan, UINT32 dir, UINT32 carrNo, UINT32 radio, T_FreqCarrNcoInfo *pFreqCarrNcoInfo);

UINT32 BspSetDpdChanOff(UINT32 chanmask);
UINT32 BspDpdChanOffStaQuery(UINT32 *chanOffResult);

UINT32 BspDpdTsEnSta(UINT32 *pSw);
UINT32 BspRfSwitchCallBack(pGetBspSetRfSwitchDelay pCallBackFunc);
UINT32 dpdpowadj(UINT32 chan, UINT32 freqNo);
UINT32 BspGetDpdFixDlyStat(UINT32 chan);
UINT32 dpdquery(UINT32 typeId, UINT32 ulChnlNo, UINT32 ulFreqBandNo);
UINT32 BspGetDpdLutDowmNum(UINT32 chan, INT32 *pNum);
UINT32 DpdDfpSetBdTypeCallBack(pGetHwBoardType pCallBackFunc);
UINT32 BspRfSwitchCallBackTdd2(pGetBspSetRfSwitchDelay pCallBackFunc);
UINT32 BspDpdSetCfrDpdRouteCfg(T_DpdMsgSendCfrDpdRouteInfo* cfrDpdRouteInfo);
UINT32 dpdts(UINT32 type, UINT32 sw);
UINT32 dpdons(UINT32 startChn,UINT32 endChn,UINT32 bandId, UINT16 type);
UINT32 dpdoffs(UINT32 startChn,UINT32 endChn,UINT32 bandId, UINT16 type);
UINT32 dpdstarts(UINT32 startChn,UINT32 endChn,UINT32 bandId);
UINT32 dpdstops(UINT32 startChn,UINT32 endChn,UINT32 bandId);
UINT32 TestAcpCal(UINT32 chan);
UINT32 showpowadjinfo(VOID);
UINT32 pimcctrl(UINT32 chan, UINT32 bandId, UINT32 ctrl);
UINT32 pimccleartbl(UINT32 chan,UINT32 bandId);
UINT32 pimcpretrainsta(UINT32 chan,UINT32 bandId);
UINT32 clearluts(UINT32 startChn,UINT32 endChn,UINT32 bandId);
UINT32 BspDpdSetPaInfo(UINT32 chan,UINT32 bandId);
UINT32 dsploadsta(UINT32 chan, UINT32 bandId);
UINT32 dpdfpgaread(UINT32 chan, UINT32 addr);
UINT32 dpdfpgawrite(UINT32 chan, UINT32 addr, UINT32 data);
UINT32 getdpdvswr(UINT32 chan,UINT32 bandId);
UINT32 gettable(UINT32 typeId,UINT32 chan,UINT32 type,const char *hostIP,const char *fileName);
UINT32 settable(UINT8 typeId,UINT32 chan, UINT8 module, UINT8 powGrd, UINT8 *hostIP,char *fileName);
UINT32 gettablei(UINT32 typeId,UINT32 chan,UINT32 type,const char *hostIP,const char *fileName);
UINT32 settablei(UINT8 typeId,UINT32 chan,UINT8 module, UINT8 powGrd, UINT8 *hostIP,char *fileName);
UINT32 dpddog(UINT32 chan);
UINT32 getdspdebug(UINT32 chan,UINT32 bandId,UINT32 powGrd);
UINT32 dspprintf(UINT32 chan,UINT8 dsp_prt_style,UINT8 dsp_prt_style_second,UINT8 dpd_pwr_index);
UINT32 sample(UINT32 typeId,UINT32 chan,UINT32 flag,UINT32 pos,const char *hostIP,const char *fileName);
UINT32 getstai(UINT32 chan,UINT32 bandId);
UINT32 getsta(UINT32 chan,UINT32 bandId,UINT32 powGrd);
UINT32 getallsta();
UINT32 getdpdparm(UINT32 chan,UINT32 bandId,UINT32 powGrd,UINT32 index);

UINT32 BspGetMultiDspVswr(UINT32 chan,UINT32 bandId,T_DpdMsgVswrQueryAck *pSpaVal);
UINT32 dpdssc(UINT32 chan, UINT32 sw);
UINT32 dpddataadj(UINT32 chan, UINT32 sw);
UINT32 getdpdsta(VOID);
UINT32 dpditermode(UINT32 chan, UINT32 sw);
UINT32 setvectpara(UINT32 chan,UINT32 bandId,INT32 iCarrNco );
UINT32 BspGetDspVswr_IC3(UINT32 chan,UINT32 bandId,INT32 *pVswrReal, INT32 *pVswrImag,INT32 *pNco);
UINT32 BspSendVswrParaToDpd(UINT32 chan,UINT32 bandId);
UINT32 BspNotifyVswrParaToDpd(UINT32 chan,UINT32 bandId,UINT32 vertype,UINT32 uNco);
UINT32 startvectorvswr(UINT32 chan,UINT32 bandId);
UINT32 getvectorcalcsta(UINT32 chan, UINT32 bandId);
UINT32 getvectorval(UINT32 chan, UINT32 bandId);


VOID dspver(UINT32 chipId);
VOID RecordResultWhen4dBProtectTrig(UINT32 chan);
VOID ShowRecordResultOF4dBProtect(UINT32 chan);

UINT32 DpdByPassCtrl(UINT32 chan, UINT32 freqNo, UINT16 type, UINT16 ctrl);
UINT32 BspGetAcpCalResult(UINT32 chan, T_DpdMsgAcpCalResultAck *pAcpCalResult);
UINT32 BspDownloadDpdTable(UINT32 chan,TUdpApiHeader *headInfo,UINT8 *hostIP,char *fileName);
UINT32 BspDownloadDpdTableNew(UINT32 chan, TUdpApiHeader *headInfo, const char *fileName);
UINT32 BspUploadDpdTable(UINT32 typeId,UINT32 chan,UINT32 bandId,UINT32 type,const char *hostIP,const char *fileName);

UINT32 BspDpdSetFwdParam(UINT32 chan,UINT32 bandId);
UINT32 BspDpdSetFilterParam(UINT32 chan,UINT32 bandId);
UINT32 DpdStartCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl);
UINT32 BspDpdSetRxCellInfo(UINT32 chan,UINT32 bandId);
UINT32 BspStartByPass(UINT32 chan, UINT32 freqNo, UINT16 type, UINT16 ctrl);
UINT32 BspDspSetFbCtrlInfo(T_BspCbSwStaTbl *pData, UINT32 num);
UINT32 BspGetTsQueryExceptInfo(UINT32 type);
UINT32 BspSetTsQueryExceptInfo(UINT32 exReason,UINT32 exMask);
UINT32 BspDpdSetDmimoCtrl(UINT32 chan,UINT32 bandId,UINT32 sw);
UINT32 BspDpdSetPaStatus(UINT32 bspChan,UINT32 sw);
UINT32 BspSetMultFreqSrcCtrl(UINT32 bspChan, T_DpdMultFreqSrcCtrlMsg *para);
UINT32 BspGetPwdCaliResult(UINT32 bspChan, T_DpdPwdCaliMsg *launchSta, T_PwdCaliResult *para);
UINT32 BspDpdSendChTssiInfo(T_TxAllChanPow *pChanPowInfo);
UINT32 BspDpdGetChnPowInfo(T_TxAllChanPow *pdata);
UINT32 BspInitDpdModulePimFunc(VOID);
UINT32 BspDpdSetFrDiffInfo(UINT32 bspChn,UINT32 frOffSetNs,UINT32 tddRamFrOffSetNs);
UINT32 BspDpdSlaveScalarVswrCtrl(UINT32 bspChan, UINT32 sw);
UINT32 BspInitRfCableDefaultDly(UINT32 *pData, UINT32 num);
UINT32 BspDpdSscLutDownload(UINT32 bspChan);
UINT32 BspDpdGetSscLutHashVer(UINT32 bspChan, T_DspMsgSscLutHashVerAck *pDataAck);
UINT32 BspDpdSetTrapK0GainCtrl(UINT32 bspChan, UINT32 ctrlFlag);
UINT32 BspDpdSetSscLutGenCtrl(UINT32 bspChan, UINT32 lutSw);
UINT32 BspDpdGetDownLutCnt(UINT32 bspChan, T_DspMsgDownLutCntAck *pDataAck);
UINT32 BspDpdMsgPowCalChnSw(UINT32 chan, UINT32 sw);
UINT32 BspDpdGetSscTrapSta(UINT32 bspChan, T_DspMsgSscLutGenTrapStaAck *pData);
UINT32 BspDpdSetSscVoltGrdCfg(UINT32 bspChan, UINT32 voltGrd);
UINT32 BspDpdSscLutUpLoad(UINT32 bspChan, UINT32 pwdGrd, T_DspMsgSscLutGenStaUpLoadAck *pDataAck);
UINT32 BspDpdSendRfBridgeMapInfo( T_AllRfBridgeInfo * pdata);
UINT32 BspDpdSetRfBridgeParam(T_DpdMsgRfBridgeOfflinePara * pdata);
UINT32 BspGetMultiDspVswr_RfBridge(UINT32 chan,T_DpdMsgRfBridgeSpaCalcStaAck *pSpaVal);
UINT32 BspGetSpaVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeSpaCalcStaAck *pDataAck);
UINT32 BspNotifyDpdStartVswrCalc_RfBridge(UINT32 rfBridgeIdx, UINT32 vswrType);
UINT32 BspGetVswrFinishSta_RfBridge(UINT32 rfBridgeIdx);
UINT32 BspGetVswrCalcSta_RfBridge(UINT32 rfBridgeIdx);
UINT32 BspGetRevVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeRevCalcStaAck *pDataAck);
UINT32 BspSetDspRfBridgeChanFlag(UINT32 difChn, UINT32 flag);
UINT32 BspGetPaStaByPaFactorId(UINT32 ulSubFileNo, UINT32 *paSta);
UINT32 BspDpdSetDmmCfgClrFlg(UINT32 sw);
UINT32 BspDpdSetDmmCfgMsg(UINT32 chan, UINT32 bandId,UINT32 CarrId,UINT32 RadioMode,UINT32 sw);
UINT32 BspDpdSetUtdoaCfgMsg(UINT32 chan, UINT32 bandId, UINT32 calibPeriodValue, UINT32 offset, UINT32 utEn);
UINT32 BspSetGsmHopCarrFreq(UINT32 flag, UINT32 gsmHopfreq, UINT32 fltFreq, UINT32 fhtFreq, T_RruRfCfgInfo *rruCfgPara);
UINT32 BspGetOnlinePimItem(UINT32 rxchnNo, UINT32 *carrNum, T_PimOnlineReportItemDsp *pimOnlineItem);
/* Started by AICoder, pid:r39e2jf00f5b1e81497f0a0630f7b20f01c99b81 */
UINT32 BspDpdSetInstruSw(UINT32 chan, UINT32 sw);
UINT32 BspDpdSetInstruAcpSw(UINT32 chan, T_DpdMsgInstruAcpSwi *pdata);
UINT32 BspDpdGetInstruAcpSta(UINT32 chan, T_DpdMsgInstruAcpStaAck *pdata);
UINT32 BspDpdSendInstruEvmSw(UINT32 chan, T_DpdMsgInstruEvmSwi *pdata);
UINT32 BspDpdGetInstruEvmSta(UINT32 chan, T_DpdMsgInstruEvmStaAck *pdata);
/* Ended by AICoder, pid:r39e2jf00f5b1e81497f0a0630f7b20f01c99b81 */
UINT32 BspSetRfBridgeAcCarrInfo(UINT32 chipIdx, UINT32 brgIdx, T_RfBridgeVswrChanInfo *pInfo);
UINT32 BspGetDspVswr_RfBridge(UINT32 chan, INT32 *pVswrReal, INT32 *pVswrImag, INT32 *pNco);
UINT32 BspDpdSetNcrGpInfo(UINT32 chan);
UINT32 BspGetDspRfBridgeChanFlag(UINT32 difChn, UINT32 *flag);
UINT32 DpdOffsetStartCtrl(UINT32 ctrl);
UINT32 BspCfgDpdCntrct(T_DpdMsgCntrctCfg *cntrctPara);
UINT32 BspSetAIiotNetworkModeToDpd(UINT32 networkMode);
UINT32 BspDpdSetDisablePimOnlineTxChanInfo(T_RxSetPimOnlineDisableTxChanBand *pTxChanPara);
UINT32 BspDpdicCatchDspData(UINT32 sw, UINT32 difChan, UINT32 pointNo);
UINT32 BspDpdicGetCatchDspDataStatus(VOID);
INT32 BspGetBandFrameAdj(UINT32 bspChan, UINT32 carrNo, UINT32 carrMode, INT32 bandAdj);

#ifdef __cplusplus
}
#endif

#endif  /* FUNCLIB_DPD_DPD_APP_H */


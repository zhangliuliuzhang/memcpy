/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : hp_msg.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了热补丁msg相关接口
* 注意事项 : 无
* 作    者 : NR2.0
* 创建日期 : 2023-10-19
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _HPMSG_H_
#define _HPMSG_H_

#ifdef __cplusplus
extern "C"{
#endif
#include "bsppub.h"

UINT32 DpdLoadAcHp(UINT32 chan, UINT32 ctrl);
UINT32 DpdLoadDspHp(UINT32 ctrl);

#ifdef __cplusplus
}
#endif

#endif  /* _HPMSG_H_ */

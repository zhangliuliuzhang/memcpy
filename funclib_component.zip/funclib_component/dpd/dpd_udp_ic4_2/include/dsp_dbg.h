/*********************************************************************
* 版权所有 (C)2001, 深圳市中兴通讯股份有限公司。
*
* 文件名称： DSP_DBG.h
* 文件标识：
* 内容摘要： HPI物理层头文件
* 其它说明：
* 当前版本： 1.0
* 作    者：
* 完成日期： 2007-06-12
*
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：
**********************************************************************/
#ifndef _DSPDBG_H_
#define _DSPDBG_H_

#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"
#include "bspcomm.h"
UINT32 dpdon(UINT32 chan, UINT32 freqNo, UINT16 type);
UINT32 dpdoff(UINT32 chan, UINT32 freqNo, UINT16 type);
UINT32 dpdstart(UINT32 chan, UINT32 freqNo);
UINT32 dpdstop(UINT32 chan, UINT32 freqNo);
UINT32 clearlut(UINT32 chan, UINT32 bandId);
UINT32 setdpdpara(UINT32 chan,
        INT32 index_modul,
        INT32 index_func,
        INT32 data0,
        INT32 data1,
        INT32 data2,
        INT32 data3,
        INT32 data4,
        INT32 data5,
        INT32 data6);
void verbase_dspver(UINT32 chipId);
void verbase_acdspver(UINT32 chipId, const CHAR *processName);
UINT32 acGetDpdStrAcDsp(UINT32 index, INT32 data0, INT32 data1, INT32 data2, INT32 data3);
UINT32 acSetParaAcDsp(INT32 index, INT32 funcIndex, INT32 par0, INT32 par1, INT32 par2);
UINT32 acUpLoadDataAcDspBin(UINT32 datatype,const char* filename);
UINT32 acGetDpdStrAcDspInfo(UINT32 index, INT32 data0, INT32 data1, UINT8 *pAcDspBufStr);
UINT32 BspSetRfBridgeAcCarrInfoTest(void);
UINT32 BspSetRfBrgVswrPreStartTest(void);
UINT32 BspGetRfBrgVswrPreStartSta(void);
UINT32 BspNotifyRfBrgDpdStartVswrTest(void);
UINT32 BspGetRfBrgVswrSpaTest(UINT32 chan);
UINT32 BspGetRfBrgVswrCalcStaTest(void);
UINT32 BspSetRfBridgeAcCarrInfoTest1(UINT32 chnNo, UINT32 carrNo, UINT32 radioMode);

#ifdef __cplusplus
}
#endif

#endif

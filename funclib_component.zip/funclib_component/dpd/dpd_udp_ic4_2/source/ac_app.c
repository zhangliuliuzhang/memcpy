/*********************************************************************
 * 版权所有 (C)2014, 深圳市中兴通讯股份有限公司。
 *
 * 文件名称： ac_app.c
 * 文件标识：
 * 内容摘要： HPI 应用层实现的实现
 * 其它说明：
 * 当前版本： 1.0
 * 作    者：
 * 完成日期： 2023-10-18
 *
 * 修改记录1：
 *    修改日期：
 *    版 本 号：
 *    修 改 人：
 *    修改内容：

 **********************************************************************/
#include "ac_app.h"
#include "ac_msg.h"
#include "dpd_app.h"
#include "dpdapi.h"

static const char *ac_app_prn = "AcApp";
#define AcPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,ac_app_prn),(level)|PM_PREFIX,##fmt)

UINT32 BspStartAcCalc(UINT32 chan)
{
    UINT32 retVal = 0;
    UINT32 dspRet = 0;

    if(1 == BspGetBoardPara())
    {
        dspRet = DpdMsgAcCtrl(chan,0,0);
        retVal = (AC_DSP_RETURN_CHK_FINE == dspRet) ? BSP_OK : BSP_ERROR;
        dbgInfoEx("[%s]DspRet 0x%08X, FuncRet 0x%08X, result:0x%04X\n",\
        __FUNCTION__, dspRet, retVal, dspRet);
    }

    return retVal;
}
//启动AC权值计算
UINT32 BspAcWgtCalcIc(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 refChan)
{
    UINT32 freqNo = 0;
    UINT32 retVal = 0;
    UINT32 dspRet = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    dbgInfoEx("[%s]acType = %d carrNo = %d refChan = %d\n", __FUNCTION__, acType, carrNo, refChan);

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    dspRet = DpdMsgAcCtrl(ulDifChnl, freqNo, acType);
    retVal = (AC_DSP_RETURN_CHK_FINE == dspRet) ? BSP_OK : BSP_ERROR;
    dbgInfoEx("[%s]DspRet 0x%08X, FuncRet 0x%08X, result:0x%04X\n",\
              __FUNCTION__, dspRet, retVal, dspRet);
    return retVal;
}

UINT32 BspGetAcSta(UINT32 chan)
{
    UINT32 acType = 0;
    return BspGetAcWgtCalcSta(chan,acType);
}

UINT32 BspGetVswrSta(UINT32 chan,UINT32 acType)
{
    return BspGetAcWgtCalcSta(chan,acType);
}

UINT32 BspGetAcWgtCalcSta(UINT32 chan,UINT32 acType)
{
    UINT16 usState = 0;
    UINT32 freqNo = 0;
    UINT32 cellId = 0;
    UINT32 type   = 0;
    UINT32 dspRet = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    dspRet = DpdMsgGetAcWgtSta(ulDifChnl, freqNo, cellId, type, &usState, acType);

    ulRetVal = (AC_DSP_RETURN_CHK_FINE == usState) ? BSP_OK : BSP_ERROR;
    dbgInfoEx("[%s]DspRet'0x%08X FuncRet'0x%08X: State= 0x%04X\n",\
              __FUNCTION__, dspRet, ulRetVal, usState);
    return ulRetVal;
}

// 非标带宽修改
/* Started by AICoder, pid:z9ed5n0e00x31a0141590a37404bff2553761365 */
UINT32 BspAcSetNonStandardBandSw(UINT32 uiSwitch, UINT32 uiBandWidth)
{
    UINT16 result = 0;
    UINT32 ulDspRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;

    ulDspRet = DpdMsgNonStandardBandSw(uiSwitch, uiBandWidth, &result);
    ulRetVal = (AC_DSP_RETURN_CHK_FINE == result) ? BSP_OK : BSP_ERROR;

    dbgInfoEx("[%s]DspRet'0x%08X FuncRet'0x%08X: Result= 0x%04X\n", __FUNCTION__, ulDspRet, ulRetVal, result);
    return ulRetVal;
}
/* Ended by AICoder, pid:z9ed5n0e00x31a0141590a37404bff2553761365 */
UINT32 BspAcSeqCalcIc(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType)
{
    UINT16 result = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulDspRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulDspRet = DpdMsgStartAcSeqCalc(ulDifChnl, freqNo, cellId, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType, &result);

    ulRetVal = (AC_DSP_RETURN_CHK_FINE == result) ? BSP_OK : BSP_ERROR;
    dbgInfoEx("[%s]DspRet'0x%08X FuncRet'0x%08X: Result= 0x%04X\n",\
              __FUNCTION__, ulDspRet, ulRetVal, result);
    return ulRetVal;
}

UINT32 BspAcSeqCalcIc4(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag)
{
    UINT16 result = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulDspRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulDspRet = DpdMsgStartAcSeqCalc4(ulDifChnl, freqNo, cellId, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType, &result,refChan,preciseDlyFlag);

    ulRetVal = (AC_DSP_RETURN_CHK_FINE == result) ? BSP_OK : BSP_ERROR;
    dbgInfoEx("[%s]DspRet'0x%08X FuncRet'0x%08X: Result= 0x%04X\n",\
              __FUNCTION__, ulDspRet, ulRetVal, result);
    return ulRetVal;
}

UINT32 BspMsgInsOnLineCal(UINT32 uiBandWidth,UINT32 OnlineInsType,UINT32 uiSampleRate, UINT32 uMode)
{
    MsgInsOnLineCal(0,uiBandWidth,OnlineInsType,uiSampleRate, uMode);
    return BSP_OK;
}

/********************************************************************************
*函数名  ：BspSetDpdParaMode
*函数作用：配置DSP进入测试模式/退出测试模式
*参数说明：chan   ：通道号
           bandId ：频带号
           modesel: 模式选择，1 进入测试模式，0 退出测试模式
********************************************************************************/
UINT32 BspSetDpdParaMode(UINT32 chan,UINT32 bandId,INT32 modesel)
{
    INT32 index    = 0x10A;//残余相差

    T_DpdMsgSetSignalPara tdpdPara = {0};
    if(chan>=BspGetTxChanNum())
    {
        dbgErr("%s>>Para Error (chan %d is out of range %d)!\n",__FUNCTION__,chan,BspGetTxChanNum());
        return BSP_ERROR;
    }

    tdpdPara.index_modul= index;
    tdpdPara.index_func= modesel;//0:表示不进行残余相差；1：表示进行残余相差
    dbgInfo("%s>>Para(chan %d,range %d,band %d,mode %d)!\n",__FUNCTION__,chan,BspGetTxChanNum(),bandId,modesel);
    DpdMsgSetParaAcDsp(chan,bandId,&tdpdPara);
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspAcSetRruInfo(*)
 *  功能描述   : 给AC DSP发送整机硬件配置信息
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspAcSetRruInfo(UINT32 chan,UINT32 bandId)
{
    UINT32 fullPower = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_ACMsgSendRruInfo sendRruInfo = {0};
    T_RruRfModuleInfo  tRfModuleInfo = {0};

    memset(&sendRruInfo, 0, sizeof(T_ACMsgSendRruInfo));

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    BspGetRruPathRatedPower( chan, &fullPower);
    BspGetRruRfModuleInfo(chan, &tRfModuleInfo);

    sendRruInfo.fullPow    = fullPower;
    sendRruInfo.paType     = BspGetPaType(chan);
    sendRruInfo.txDflFreqL = tRfModuleInfo.ulRuTxStartFreq;/*注意一下，单位是kHz*/
    sendRruInfo.txDflFreqH = tRfModuleInfo.ulRuTxEndFreq;
    sendRruInfo.rxDflFreqL = tRfModuleInfo.ulRuRxStartFreq;
    sendRruInfo.rxDflFreqH = tRfModuleInfo.ulRuRxEndFreq;

    sendRruInfo.moduleGrpId = BspGetModuleGroupId();
    sendRruInfo.boardGrpId  =  BspGetBoardGroupId();
    sendRruInfo.boardTypeId = BspGetBoardTypeId();
    sendRruInfo.hwChangeId  = BspGetHardwareChangeId();
    if (BSP_RADIO_STANDARD_LTE_TDD == BspGetRadioStandard())
    {
        sendRruInfo.fpgaDpdType = BspGetFpgaDpdType();
    }

    AcPrint(PM_DEBUG,"fullPow    : %d mW\n", sendRruInfo.fullPow);
    AcPrint(PM_DEBUG,"paType     : %d\n", sendRruInfo.paType);
    AcPrint(PM_DEBUG,"txDflFreqL : %d kHz\n", sendRruInfo.txDflFreqL);
    AcPrint(PM_DEBUG,"txDflFreqH : %d kHz\n", sendRruInfo.txDflFreqH);
    AcPrint(PM_DEBUG,"rxDflFreqL : %d kHz\n", sendRruInfo.rxDflFreqL);
    AcPrint(PM_DEBUG,"rxDflFreqH : %d kHz\n", sendRruInfo.rxDflFreqH);

    AcPrint(PM_DEBUG,"moduleGrpId: 0x%x\n", sendRruInfo.moduleGrpId);
    AcPrint(PM_DEBUG,"boardGrpId : 0x%x\n", sendRruInfo.boardGrpId);
    AcPrint(PM_DEBUG,"boardTypeId: 0x%x\n", sendRruInfo.boardTypeId);
    AcPrint(PM_DEBUG,"hwChangeId : 0x%x\n", sendRruInfo.hwChangeId);
    AcPrint(PM_DEBUG,"fpgaDpdType : 0x%x\n", sendRruInfo.fpgaDpdType);

    return AcMsgSendRruInfo(ulDifChnl, bandId, &sendRruInfo);
}

UINT32 BspSendHaulBackAcDataIc(T_DpdMsgSendAcData_NEW* data, UINT32 acType)
{
    UINT32 chan   = 0;
    UINT32 freqNo = 0;
    UINT16 result = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulResultRet = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgSendAcDataIc(ulDifChnl, freqNo, data, &result, acType);
    ulResultRet = (AC_DSP_RETURN_CHK_FINE == result) ? BSP_OK : BSP_ERROR;

    dbgInfoEx("[%s]MsgSendRet'0x%08X FuncRet'0x%08X: GetResult= 0x%04X\n",\
               __FUNCTION__, ulRetVal, ulResultRet, result);
    return ulResultRet;
}

UINT32 BspSendInsOnLineDataIc(T_DpdMsgSendSlaveData* sendData)
{
    UINT32 chan   = 0;
    UINT32 freqNo = 0;
    UINT16 result = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    /*UINT32 ulResultRet = 0;*/
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    DpdMsgSendInsOnLineDataIc(ulDifChnl, freqNo, sendData, &result);

    return BSP_OK;
}

UINT32 BspSendHaulBackAcDataIc4(T_DpdMsgSendAcData_NEW_IC4* data, UINT32 acType)
{
    UINT32 chan   = 0;
    UINT32 freqNo = 0;
    UINT16 result = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulResultRet = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgSendAcDataIc4(ulDifChnl, freqNo, data, &result, acType);
    //ulResultRet = (AC_DSP_RETURN_CHK_FINE == result) ? BSP_OK : BSP_ERROR;

    dbgInfoEx("[%s]MsgSendRet'0x%08X FuncRet'0x%08X: GetResult= 0x%04X\n",\
               __FUNCTION__, ulRetVal, ulResultRet, result);
    return ulResultRet;
}

/*****************************************************************************
 *  函数名称   : BspGetAcDspWatchDog(*)
 *  功能描述   : 获取acdsp的看门狗状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : typeId: 待确认 chan：bsp通道号 bandId：频段号
 *              ulTypeId -- NxpCpu: HEAD_TYPE_ID_NXP_ACDSP= 3
                            Dpdic : HEAD_TYPE_ID_SOC_DSP  = 0
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetAcDspWatchDog(UINT32 ulTypeId, UINT32 chan, UINT32 bandId, UINT32 *pulWtdCnt)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulWatchDogCnt = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = AcdspMsgGetDog(ulTypeId, ulDifChnl, bandId, &ulWatchDogCnt);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DspMsgWatchDog Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if (NULL != pulWtdCnt)
    {
        *pulWtdCnt = ulWatchDogCnt;
    }
    else
    {
        ulRetVal = BSP_ERROR;
        dbgInfo("%s>>TypeId'%d BspChnl'%d DifChnl'%d: GetWtdCnt= 0x%04X\n",
                __FUNCTION__, ulTypeId, chan, ulDifChnl, ulWatchDogCnt);
    }

    return ulRetVal;
}

//启动参考通道H计算
UINT32 BspJacRefChHCalc(UINT32 acType, UINT32 carrNo)
{
    UINT32 uiFreqNo  = 0;
    UINT32 retVal    = 0;
    UINT32 dspRet    = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal  = BSP_OK;

    dbgInfoEx("[%s]acType = %d carrNo = %d \n", __FUNCTION__, acType, carrNo);
    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    dspRet = DpdMsgJacRefChnHCtrl(ulDifChnl, uiFreqNo, acType);
    retVal = (AC_DSP_RETURN_CHK_FINE == dspRet) ? BSP_OK : BSP_ERROR;
    dbgInfoEx("[%s]DspRet 0x%08X, FuncRet 0x%08X, result:0x%04X\n",\
              __FUNCTION__, dspRet, retVal, dspRet);

    return retVal;
}

//通知DSP更新AC共轭频域基序列
UINT32 JacUpdateAcConjFreqSeq(UINT32 JacConjFreqSeqUpdateFlag)
{
    UINT32 retVal    = 0;
    UINT32 dspRet    = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal  = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    dspRet = DspMsgJacUpdateAcConjFreqSeq(ulDifChnl,JacConjFreqSeqUpdateFlag);
    retVal = (AC_DSP_RETURN_CHK_FINE == dspRet) ? BSP_OK : BSP_ERROR;
    dbgInfoEx("[%s]DspRet 0x%08X, FuncRet 0x%08X, result:0x%04X\n",\
              __FUNCTION__, dspRet, retVal, dspRet);

    return retVal;
}


UINT32 BspAcBandInfoIc42(UINT32 carrNo,UINT32 radiomode ,UINT32 carrFreq, UINT32 bandWidth,UINT32 bandNo)
{
    UINT16 result = 0;
    UINT32 ulDspRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;

    T_DpdMsgAcBandInfo tDpdMsgAcBandInfo = {0};
    
    tDpdMsgAcBandInfo.carrNo = carrNo;
    tDpdMsgAcBandInfo.radioMode =radiomode;
    tDpdMsgAcBandInfo.carrFreq =carrFreq;
    tDpdMsgAcBandInfo.bandWidth =bandWidth;
    tDpdMsgAcBandInfo.bandNo =bandNo;
    tDpdMsgAcBandInfo.flag =1;


    ulDspRet = DpdMsgSendBandInfo(&tDpdMsgAcBandInfo ,&result);
   
    ulRetVal = (AC_DSP_RETURN_CHK_FINE == ulDspRet) ? BSP_OK : BSP_ERROR;

    dbgInfoEx("[%s]DspRet'0x%08X FuncRet'0x%08X: Result= 0x%04X\n", __FUNCTION__, ulDspRet, ulRetVal, result);
    return ulRetVal;    
}

UINT32 SocAcMsgCmd(T_AcSocMsgPara *tAcSocMsgPara, UINT8* pbuff, UINT8* cmd)
{
    UINT32 ulMsgLen    = 0;
    UINT32 msgType     = 0;
    UINT32 retVal      = BSP_OK;
    UINT8  *pucApiBuff = NULL;
    TSocAcApiPDU *send = NULL;
    TSocAcApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(TSocAcApiPDU) + sizeof(TSocAcApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    zte_memset_s((VOID *)pucApiBuff, sizeof(TSocAcApiPDU) + sizeof(TSocAcApiPDU), 0x00, sizeof(TSocAcApiPDU) + sizeof(TSocAcApiPDU));

    send = (TSocAcApiPDU *)&pucApiBuff[0];
    recv = (TSocAcApiPDU *)&pucApiBuff[sizeof(TSocAcApiPDU)];

    msgType = MSG_TYPE_SOC_AC_CMD;
    ulMsgLen  = sizeof(T_AcCmdParam);

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = htons(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = htons(ulMsgLen);
    send->head.chan    = (UINT8)0;
    send->head.band    = (UINT8)0;

    send->head.srcId   = tAcSocMsgPara->srcId;
    send->head.dstId   = tAcSocMsgPara->dstId;
    send->head.typeId  = tAcSocMsgPara->typeId;
    send->head.recvEn  = MSG_REQ;
    zte_memcpy_s((UINT8 *)(&(send->msg.tCmdParam)), tAcSocMsgPara->cmdLen, cmd, tAcSocMsgPara->cmdLen);
#ifndef _4C_VDE_TEST_
    if (BSP_OK != BspUdpMsgProc(tAcSocMsgPara->typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, tAcSocMsgPara->typeId, msgType, retVal);
    }
#endif
    zte_memcpy_s(pbuff, tAcSocMsgPara->len, recv->msg.buf, tAcSocMsgPara->len);
    free(pucApiBuff);

    return retVal;
}

UINT32 BspParseAcCmdResult(UINT32 cmdResult)
{
    switch(cmdResult)
    {
        case AC_UDP_SHELL_COMMD_SUCCESS:
        {
            dbgInfo("Func run success\n");
            break;
        }
        case AC_UDP_SHELL_COMMD_MSG_ERROR:
        {
            dbgInfo("Func run failed,Msg Error\n");
            break;
        }
        case AC_UDP_SHELL_COMMD_FUN_UNKNOW:
        {
            dbgInfo("Func run failed,Unkown Fun name\n");
            break;
        }
        case AC_UDP_SHELL_COMMD_OPEN_FILE_ERROR:
        {
            dbgInfo("Func run failed,file open failed\n");
            break;
        }
        case AC_UDP_SHELL_COMMD_RD_FILE_ERROR:
        {
            dbgInfo("Func run failed,file read failed\n");
            break;
        }
        case AC_UDP_SHELL_COMMD_REDIRECT_ERROR:
        {
            dbgInfo("Func run failed,redirect failed\n");
            break;
        }
        default:
        {
            dbgInfo("Error,Unknow result\n");
            break;
        }
    }

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspAcSocCmd(*)
 *  功能描述   : 执行主上进行从命令的发送
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   : RRU公共接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 190699@2017-2-27, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspAcSocCmd(UINT8 chan,CHAR *cmd, UINT32* outPut)
{
    UINT8  ucSlaverId = 100;
    UINT8  ucMasterId = 2;
    UINT32 ulRet = 0;
    UINT32 loop = 0;

    T_AcCmdParam msgbody = {0};
    T_AcMsgSocCommandAck msgAck = {0};

    T_AcSocMsgPara tAcSocMsgPara = {0};

    ucMasterId = chan + 2;
    INPUT_POINTER_CHECK(cmd);
    if(0 == zte_strnlen_s(cmd, AC_CMD_LENTH))
    {
        dbgErr("%s command is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }

    zte_memcpy_s(msgbody.ucCmd, min(zte_strnlen_s(cmd, AC_CMD_LENTH), AC_CMD_LENTH), cmd, min(zte_strnlen_s(cmd, AC_CMD_LENTH), AC_CMD_LENTH));
    msgbody.ulmask = htonl(AC_CMD_FUNC);

    tAcSocMsgPara.typeId = HEAD_TYPE_ID_NXP_SOC;
    tAcSocMsgPara.srcId = ucSlaverId;
    tAcSocMsgPara.dstId = ucMasterId;
    tAcSocMsgPara.len = sizeof(T_AcMsgSocCommandAck);
    tAcSocMsgPara.cmdLen =  sizeof(T_AcCmdParam);

    ulRet = SocAcMsgCmd(&tAcSocMsgPara, (unsigned char *)&msgAck, (unsigned char *)&msgbody);

    dbgInfo("[%s])(%d) Ret = 0x%x\n", __FUNCTION__, __LINE__,ulRet);
    BspParseAcCmdResult(ntohl(msgAck.cmdErrReason));
    if(AC_UDP_SHELL_COMMD_SUCCESS == ntohl(msgAck.cmdErrReason))
    {
        msgAck.cmdOutInfo[AC_CMD_STDIO_INFO_LENTH] = 0;
        msgAck.cmdOutInfo[AC_CMD_STDIO_INFO_LENTH] = 0;

        dbgInfo("soc[%d] %s\n",chan,msgAck.ucCmd);
        dbgInfo("soc[%d] out info:\n",chan);
        dbgInfo("%s\n",msgAck.cmdOutInfo);
        dbgInfo("soc[%d] return value = %d\n",chan,ntohl(msgAck.cmdRet));
        for(loop = 0; loop < 10; loop++)
        {
           *(outPut+loop) = ntohl(msgAck.ulFuncParams[loop]);
        }
        ulRet = BSP_OK;
    }
    else
    {
        ulRet = BSP_ERROR;
        dbgErr("[%s])(%d) Ret = 0x%x\n", __FUNCTION__, __LINE__,ulRet);
    }

    return ulRet;
}

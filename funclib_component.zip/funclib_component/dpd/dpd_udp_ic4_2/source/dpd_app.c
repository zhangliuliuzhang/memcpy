/*********************************************************************
 * 版权所有 (C)2014, 深圳市中兴通讯股份有限公司。
 * 
 * 文件名称： dpd_app.c
 * 文件标识：
 * 内容摘要： HPI 应用层实现的实现
 * 其它说明：
 * 当前版本： 1.0
 * 作    者：        zfx
 * 完成日期： 2014-12-22
 * 
 * 修改记录1：
 *    修改日期：
 *    版 本 号：
 *    修 改 人：
 *    修改内容：

 **********************************************************************/
#include "math.h"
#include "bsppub.h"
#include "vxadp.h"
#include "exprn.h"
#include "dsp_dbg.h"
#include "systemcallapi.h"
#include "rruinfo.h"
#include "dpdcommon.h"
#include "funccommon.h"
#include "funccommon_a.h"
#include "dpd_app.h"
#include "dsp_msg.h"
#include "ac_msg.h"
#include "rftable.h"
#include "ichaladapt_timedelay_ic4_2.h"
#include "freqcfgcommon.h"
#include "chnmap_a.h"
#include "chnmapcommon.h"
#include "powerctrl_comps_ic4_2.h"
#include "tddcfg_ic4_2.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "freqcfg_ic4_2.h"
#include "funccommon_chncfg.h"
#include "dlyapi.h"
#include "gainctrl_ic4_2.h"
#include "freqcfgcommon.h"
#include <glob.h>
#include "timedelay_ic4_2.h"
#include "pa_ic4_2_calcpara.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define DPD_AC_FINISH                            0x2D2D
#define RF_TYPE_FA                                  0
#define RF_TYPE_D                                   2
#define MAX_BAND_NUM                                2

#define CONVERT_TO_WORD32(H16, L16)       ((((UINT32)H16) << 16) |((UINT32)L16))
#define PRETRAIN_START                           0x5A5A
#define PRETRAIN_STOP                            0x2D2D
#define DPD_UPLOAD_OVER                          0x1111

/* 错误码 */
#define DPD_START_SINGLE_CHAN_ERR                0x0001
#define DPD_STOP_TRAINING_ERR                    0x0002
#define DPD_CLEARLUT_ERR                         0x0004
#define DPD_DLY_FIX_ERR                          0x0008
#define DPD_DLY_FIX_STA_ERR                      0x0010
#define DPD_PRE_TRAINING_ERR                     0x0020
#define DPD_PRE_TRAINING_STA_ERR                 0x0040
#define DPD_STOP_DLY_FIX_ERR                     0x0080
#define DPD_SKIP_PW_ERR                          0x0080
#define DPD_START_PW_ERR                         0x0100
#define DPD_START_TRAINING_ERR                   0x0200
#define DPD_STOP_SINGLE_CHAN_ERR                 0x0400

/* DPD制式定义 */
#define DPD_RADIO_STANDARD_UMTS                  0x00
#define DPD_RADIO_STANDARD_GSM                   0x01
#define DPD_RADIO_STANDARD_GSM_UMTS              0x02
#define DPD_RADIO_STANDARD_LTEFDD                0x03
#define DPD_RADIO_STANDARD_CDMA                  0x04
#define DPD_RADIO_STANDARD_GSM_LTEFDD            0x05
#define DPD_RADIO_STANDARD_CDMA_LTEFDD           0x06
#define DPD_RADIO_STANDARD_UMTS_LTEFDD           0x07
#define DPD_RADIO_STANDARD_TDS                   0x08
#define DPD_RADIO_STANDARD_LTETDD                0x09
#define DPD_RADIO_STANDARD_TDS_TDL               0x0a
#define DPD_RADIO_STANDARD_GSM_UMTS_LTE          0x0b
#define DPD_RADIO_STANDARD_VSWR_MODE             0x10
#define DPD_RADIO_STANDARD_INIT_MODE             0xff
#define DPD_FREQ_ALL                             0xff

/*DPD PIMC 控制*/
#define DPD_PIMC_START                          0x5A5A
#define DPD_PIMC_STOP                           0x2D2D
#define DPD_PIMC_PRETAINING                     0x5555
#define DPD_PIMC_BYPASS                         0x2D2D
#define DPD_PIMC_UNBYPASS                       0x5A5A
#define DPD_PIMC_PRETRAN_FINISH                 0x11
#define DPD_PIMC_PRETRAN_UNFINISH               0xFF

/*DPD CTR 控制*/
#define DPD_CTR_REINIT                          0x5A5A
/* DPD 消息参数0x4001 idx索引号*/
#define DPD_PARA_PIMC_PARA                      0xCD
#define DPD_PARA_CTR_PARA                       0xF0


#define RFFPGA_ABILITY_DPD_SPHASE	1		/*rffpga能力寄存器中dpd单相标志的值为1*/
#define RFFPGA_ABILITY_DPD_MPHASE	2		/*rffpga能力寄存器中dpd多相标志的值为2*/
#define SOCDSP_DPD_SPHASE		0x0			/*socdsp中定义Fpga DPD 能力，
											高16bit：0对应单相，1对应多相；
											低16bit：0对应单频，1对应双频*/
#define SOCDSP_DPD_MPHASE		0x10000    	/*socdsp中定义Fpga DPD 能力，
											高16bit：0对应单相，1对应多相；
											低16bit：0对应单频，1对应双频*/

#define SSC_FILE_SOURCE_PATH      "/ata/cali/SscEmbedLut"
/* online pim */
#define ONLINE_PIM_START                         0x5A5A
#define ONLINE_PIM_STOP                          0x2D2D
#define ONLINE_PIM_3                             0x0001
#define ONLINE_PIM_5                             0x0002
#define ONLINE_PIM_7                             0x0003
#define ONLINE_PIM_9                             0x0004
/**************************************************************************
 *
 *                         外部变量声明
 **************************************************************************/
static UINT32 dpdBwMsgFlag = 0;
static UINT32 sBoardPara = 0;
static UINT32 s_dpdTsExReason = 0;
static UINT32 s_dpdTsExMask = 0;
static const char *dpd_app_prn = "DpdApp";
static INT32 s_SampleCnt = 3;
SEM_ID semIdDpdAccess;         /* 声明互斥信号量，用于保护访问DPD模块 */
UINT32 PowAdjCnt[BSP_MAX_TX_CHAN] = {0};

static T_GsmHopChanInfo *s_GsmHopChanInfo = NULL;         /* GSM跳频频段信息 */
T_FbCtrlInfo g_FbCtrlInfo = {0};

UINT32 g_ulSlaveCableRfDly[BSP_IC42_MAX_TX_CHAN_NUM] = {0};   /*射频线缆时延*/
UINT32 g_ulSlaveCableDefRfDly[BSP_IC42_MAX_TX_CHAN_NUM] = {0}; /*默认值*/
UINT32 g_ulSlavePortCableRfDly[MAX_SLAVE_PORT_NUM] = {0};
UINT32 g_ulSlavePortCableMeasFlag[MAX_SLAVE_PORT_NUM] = {0};
T_SscInfo tSscInfo = {0};
UINT32 g_ulSlaveChnPowInValidCnt[BSP_IC42_MAX_TX_CHAN_NUM] = {0};   /*记录dsp功率检测不更新计数*/
UINT32 g_ulSlaveChnPowLastCnt[BSP_IC42_MAX_TX_CHAN_NUM] = {0};     /*记录dsp功率检测计数*/
static INT32 pimCheckType = 0;
static T_DpdMsgRfBridgeSpaCalcStaAck vswrVal = {0};      /*保存从dsp获取的spa或s12参数*/
static T_DpdMsgRfBridgeSpaCalcStaAck spaVal  = {0};
static UINT32 s_rfBridgeChanFlag[IC_DSP_CHN_MAX_NUM] = {0};

/**************************************************************************
 *                         局部函数声明
 **************************************************************************/
#ifndef DPD_CHAN_CHECK
#define DPD_CHAN_CHECK(chan)                     \
    if ((chan) >= BspGetTxChannel())             \
    {                                            \
        DpdPrint(PM_ERROR,"chan error!\n",__FUNCTION__); \
        return BSP_ERROR;                        \
    }
#endif
#define DpdPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,dpd_app_prn),(level)|PM_PREFIX,##fmt)
/**************************************************************************
 *                         全局函数声明
 **************************************************************************/

/**************************************************************************
 *                         函数实现
 * 1 辅助函数
 * 2 dpd 常规控制功能(旁路、启停、清表)
 * 3 矢量驻波检测
 * 4 PIMC功能
 * 5 TS功能
 * 6 配置、参数、路由等信息下发（配置信息 ： 小区配置 帧结构 时隙配比 ts配置 调压次数+整机硬件信息：功放信息  整机硬件资产信息)
 * 7 维测(版本、状态检测、EVM ACP 下表 看门狗等)
 * 8 节能
 * 9 AC
 * 10 pim
 **************************************************************************/

/*********************************1 辅助函数*****************************************/
/**************************************************************************
 * 函数名称：BspSetSampleTimes()
 * 功能描述：设置dpd采数的次数
 * 输入参数： s_SampleCnt：次数
 * 输出参数： 无
 * 返 回 值： BSP_OK:成功；BSP_ERROR:失败
 * 其它说明： 维测使用
 * 修改日期    版本号     修改人        修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspSetSampleTimes(INT32 times)
{
	s_SampleCnt = times;
	return BSP_OK;
}

/**************************************************************************
 * 函数名称：BspGetDspCallChain()
 * 功能描述：读取DSP调用链信息
 * 输入参数： 无
 * 输出参数： pulData:调用链信息
 * 返 回 值： BSP_OK:成功；BSP_ERROR:失败
 * 其它说明： DSP调用链存放的地址为0x40310000~0x4031ffff，空间总长度64kB
 * 修改日期    版本号     修改人        修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspGetDspCallChain(UINT32 *pData)
{
    INPUT_POINTER_CHECK(pData);
    return BSP_OK;
}

/*获取反馈NCO接口挂接，当前流程中FB NCO没有用过，暂时在单板下回调实现*/
GetFreqFbNcoInfoFunc pGetFreqFbNcoInfo = NULL;
UINT32 GetFreqFbNcoInfoCallBackInit(GetFreqFbNcoInfoFunc pFun)
{
    pGetFreqFbNcoInfo = pFun;
    return BSP_OK;
}
/*获取tranceiver NCO接口挂接，Tran芯片目前没有同意挂接NCO的接口，暂时在单板下回调实现*/
GetFreqTranNcoInfoFunc pGetFreqTranNcoInfo = NULL;
UINT32 GetFreqTranNcoInfoCallBackInit(GetFreqTranNcoInfoFunc pFun)
{
    pGetFreqTranNcoInfo = pFun;
    return BSP_OK;
}

/*DOPA校准处理*/
SetDpdSwModeInfoFunc pSetDpdSwModeInfo = NULL;
/* Started by AICoder, pid:0d0f8t18c553f4014ce6088010dd0c002c35f7f0 */
UINT32 SetDpdSwModeInfoCallBackInit(SetDpdSwModeInfoFunc pFun)
{
    pSetDpdSwModeInfo = pFun;
    return BSP_OK;
}
/* Ended by AICoder, pid:0d0f8t18c553f4014ce6088010dd0c002c35f7f0 */

SetGainFlagFunc pSetGainFlag = NULL;
/* Started by AICoder, pid:ae09ehb475o5e7f14e6c0a92b074ae030f95d402 */
UINT32 SetGainFlagCallBackInit(SetGainFlagFunc pFun)
{
    pSetGainFlag = pFun;
    return BSP_OK;
}
/* Ended by AICoder, pid:ae09ehb475o5e7f14e6c0a92b074ae030f95d402 */

/**************************************************************************
 * 函数名称：BspGetFpgaDpdType()
 * 功能描述：获取dpd类型 （适用于dpd在fpga处理的机型）暂时保留
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： BSP_OK:成功；BSP_ERROR:失败
 * 其它说明： 暂时保留
 * 修改日期   版本号     修改人        修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspGetFpgaDpdType()
{
	UINT32 val = 0;
	val = BspGetDpdType();

	if (val == RFFPGA_ABILITY_DPD_SPHASE)
	{
		return SOCDSP_DPD_SPHASE;
	}
	else if (val == RFFPGA_ABILITY_DPD_MPHASE)
	{
		return SOCDSP_DPD_MPHASE;
	}
	else
	{
		return SOCDSP_DPD_SPHASE;
	}
}
/*****************************************************************************
 *  函数名称   : BspGetCarrNcoInfo(*)
 *  功能描述   : 获取对应通道载波的载波nco信息，提供给灵活配置ts小区信息下发给dsp
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : bspchan: bsp通道 dir：方向 carrNo：载波号 radio：制式
 *  输出参数   : pFreqCarrNcoInfo: tx/rx/prx nco信息
 *  返 回 值   :
 *  其它说明   :
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetCarrNcoInfo(UINT32 bspchan, UINT32 dir, UINT32 carrNo, UINT32 radio, T_FreqCarrNcoInfo *pFreqCarrNcoInfo)
{
    UINT32 loop = 0;
    UINT32 difChan = 0;
    UINT32 chipId = 0;
    UINT32 carrNum = 0;
    INT32 bandNco = 0;
    INT32 carrNco = 0;
    INT32 tranNco = 0;
    INT32 fbNco = 0;
    UINT32 bandNo = 0;
    UINT32 retVal = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    retVal = BspGetDifInfoByBspChn(bspchan, dir, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspchan);
        return BSP_ERROR;
    }

    if((pGetFreqFbNcoInfo != NULL) && (pGetFreqTranNcoInfo != NULL))
    {
        pGetFreqFbNcoInfo(bspchan,&fbNco);
        pGetFreqTranNcoInfo(bspchan,dir,&tranNco);
    }
    else
    {
        dbgErr("%s: pGetFreqFbNcoInfo or pGetFreqTranNcoInfo is NULL\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspchan,dir);
    INPUT_POINTER_CHECK(pRfCfg);
    carrNum = pRfCfg->para.carrNum;
    if (pRfCfg->para.carrNum > DPD_UDP_IC42_MAX_CARR_NUM)
    {
        dbgErr("%s>>Error! bspChnl'%d CarrSum Over; Carr(0~%d)= %d\n", __FUNCTION__,
               bspchan, DPD_UDP_IC42_MAX_CARR_NUM - 1, pRfCfg->para.carrNum);
        return BSP_ERROR;;
    }

    for(loop = 0; loop < carrNum; loop++)
    {
        if((carrNo == pRfCfg->para.carrInfo[loop].carrNo) && (radio == pRfCfg->para.carrInfo[loop].radioMode))
        {
            retVal = BspHalAdaptGetDifCarrBandNo(dir, difChan, radio, carrNo, &bandNo);
            if(BSP_OK != retVal)
            {
                dbgErr("%s>>Error! Get dir[%d] difchan[%d] difCarrNo[%d] from fail! \n",__FUNCTION__, dir, difChan, carrNo);
                return BSP_ERROR;
            }
            if(bandNo >= BSP_IC_PERCHAN_BAND_NUM)
            {
                  dbgErr("%s>>Error! bandNo[%d] error! \n",__FUNCTION__, bandNo);
                  return BSP_ERROR;
            }
            dbgInfoEx("%s>>bspchan'%d dir'%d carrNo'%d radio'%d bandNo'%d bandFreq'%d centerFreq'%d carrFreq'%d\n",__FUNCTION__,bspchan,
                    dir,carrNo,radio,bandNo,pRfCfg->bandFreq[bandNo],pRfCfg->centerFreq,pRfCfg->para.carrInfo[loop].freq);
            bandNco = pRfCfg->bandFreq[bandNo] - pRfCfg->centerFreq;
            carrNco = pRfCfg->para.carrInfo[loop].freq - pRfCfg->centerFreq - bandNco;
            if(dir == RX)
            {
                bandNco = -bandNco;
                carrNco = -carrNco;
            }
            break;
        }
    }

    if(loop >=carrNum)
    {
        dbgErr("%s>>bspchan'%d dir'%d carrNo'%d radio'%d not found carr info\n", __FUNCTION__, bspchan, dir, carrNo, radio);
        return BSP_ERROR;
    }
    pFreqCarrNcoInfo->bandNco = bandNco;
    pFreqCarrNcoInfo->carrNco = carrNco;
    pFreqCarrNcoInfo->tranNco = tranNco;
    pFreqCarrNcoInfo->fbNco = fbNco;
    dbgInfoEx("%s>>bspchan'%d dir'%d carrNo'%d radio'%d bandNco'%d carrNco'%d tranNco'%d fbNco'%d\n",
                __FUNCTION__,bspchan, dir, carrNo, radio,bandNco,carrNco,tranNco,fbNco);
    return BSP_OK;
}
UINT32 BspDspSetFbCtrlInfo(T_BspCbSwStaTbl *pData, UINT32 num)
{
    UINT32 loop = 0;
    UINT32 index = 0;
    UINT32 mask = 0;
    UINT32 antNum = 0;
    UINT32 cnt = 0;
    T_BspHalAdaptCbSwStaTbl* ptOneSwStaTbl = NULL;
    UINT32 oneStaTblLen = 0;

    INPUT_POINTER_CHECK(pData);
    g_FbCtrlInfo.fbCtrlTypeNum = num;

    for(loop = 0; loop < num; loop++)
    {
    	dbgInfoEx("********************************************\n");
        mask = 0;
        antNum = 0;
        ptOneSwStaTbl= pData[loop].pCbSwStaTbl;
        oneStaTblLen = pData[loop].tblLen;
        g_FbCtrlInfo.fbCtrlSliceNum[loop] = oneStaTblLen;
        for(index = 0; index < oneStaTblLen; index++)
        {
            if(ptOneSwStaTbl[index].uiStatus == E_RF_FWD_STATUS_FWD)
            {
                antNum++;
            }
            mask |= 1<<(ptOneSwStaTbl[index].uiChan);
        }
        if(antNum == 0)
        {
            dbgErr("antNum is 0 \n");
            return BSP_ERROR;
        }
        g_FbCtrlInfo.fb2DlMsk[loop] = mask;
        cnt = oneStaTblLen/antNum;
        for(index = 0; index < cnt; index++)
        {
            g_FbCtrlInfo.fbCtrlInfo[loop][index] = ptOneSwStaTbl[index].uiPeriod |(ptOneSwStaTbl[index].uiStatus<<16);
            dbgInfoEx("fbCtrlInfo 0x%x \n",g_FbCtrlInfo.fbCtrlInfo[loop][index]);
        }
        dbgInfoEx("fbCtrlTypeNum %d, fb2DlMsk 0x%x fbCtrlSliceNum %d \n",g_FbCtrlInfo.fbCtrlTypeNum,  g_FbCtrlInfo.fb2DlMsk[loop], g_FbCtrlInfo.fbCtrlSliceNum[loop]);
        dbgInfoEx("********************************************\n");
    }
    return BSP_OK;
}
/*********************************2 dpd 常规控制功能*****************************************/
/***************************DPD 旁路、启停、清表**********************************************/
/*****************************************************************************
 *  函数名称   : DpdByPassCtrl(*)
 *  功能描述   : dpd旁路和不旁路控制 0x0001消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 freqNo：频段号 ctrl：控制字 0x5A5A-使能，0x2D2D-禁用
 *              type（新增）：旁路类型，0:下行反馈均旁路 1:旁路下行DPD 2:旁路反馈DPD
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 内部接口，正式流程未调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 DpdByPassCtrl(UINT32 chan, UINT32 freqNo, UINT16 type, UINT16 ctrl)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0; 
    UINT32 ulRetVal = BSP_OK;

    DPD_CHAN_CHECK(chan);

     ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    } 
    ulRetVal = DpdMsgBypass(ulDifChnl,freqNo,type,ctrl);
    return ulRetVal;
}
UINT32 BspStartByPass(UINT32 chan, UINT32 freqNo, UINT16 type, UINT16 ctrl)
{
    return DpdByPassCtrl(chan, freqNo, type, ctrl);
}

/* Started by AICoder, pid:gb2b162b9b4ebff14a7d0b44205d4b19b2471050 */
UINT32 DpdOffsetStartCtrl(UINT32 ctrl)
{
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdMsgOffsetStartCtrl(0, 0, ctrl);
    return ulRetVal;
}

UINT32 BspStartDpdRxOffset(VOID)
{
    return DpdOffsetStartCtrl(DPD_OFFSET_START);
}

UINT32 BspStopDpdRxOffset(VOID)
{
    return DpdOffsetStartCtrl(DPD_OFFSET_STOP);
}
/* Ended by AICoder, pid:gb2b162b9b4ebff14a7d0b44205d4b19b2471050 */

/* 配置抵消参数 */
UINT32 BspCfgDpdCntrct(T_DpdMsgCntrctCfg *cntrctPara)
{
    return DpdMsgCntrctCfg(0, 0, cntrctPara);
}

/* Started by AICoder, pid:3a904f4d78006e8141b70a1cb066d8105ae1e6a4 */
/* AIOT整机组网模式 */
UINT32 BspSetAIiotNetworkModeToDpd(UINT32 networkMode)
{
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgNetworkModeCfg NetworkModeCfg = {0};
    NetworkModeCfg.uNetworkMode = networkMode;

    ulRetVal = DpdMsgAIiotNetworkMode(&NetworkModeCfg);
    return ulRetVal;
}
/* Ended by AICoder, pid:3a904f4d78006e8141b70a1cb066d8105ae1e6a4 */

/*****************************************************************************
 *  函数名称   : DpdStartCtrl(*)
 *  功能描述   : dpd 启动和停止控制  0x0002消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 freqNo：频段号 ctrl：控制字 0x5A5A-使能，0x2D2D-禁用
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 内部接口
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 DpdStartCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    DPD_CHAN_CHECK(chan);

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    } 
    ulRetVal = DpdMsgStartCtrl(ulDifChnl, freqNo, ctrl);
    return ulRetVal;
}


UINT32 BspRecoverDpd(UINT32 chan, UINT32 bandId, UINT32 ctrl)
{
    BspLog(LOG_LEVEL_0,"%s{chan %d bandId %d switch 0x%x} \n",__FUNCTION__,chan,bandId,ctrl);
    return DpdStartCtrl(chan,bandId,ctrl);
}

/*****************************************************************************
 *  函数名称   : BspStartDpd(*)
 *  功能描述   : dpd 启动 0x0002消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 freqNo：频段号 ctrl：控制字 0x5A5A-使能，0x2D2D-禁用
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspStartDpd(UINT32 chan,UINT32 bandId)
{
    BspLog(LOG_LEVEL_0,"%s{chan %d bandId %d} \n",__FUNCTION__,chan,bandId);
    return DpdStartCtrl(chan,bandId,DPD_START);
}

/*****************************************************************************
 *  函数名称   : BspStopDpd(*)
 *  功能描述   : dpd 停止 0x0002消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 freqNo：频段号 ctrl：控制字 0x5A5A-使能，0x2D2D-禁用
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspStopDpd(UINT32 chan,UINT32 bandId)
{
    BspLog(LOG_LEVEL_0,"%s{chan %d bandId %d} \n",__FUNCTION__,chan,bandId);
    return DpdStartCtrl(chan,bandId,DPD_STOP);
}
/*****************************************************************************
 *  函数名称   : BspClearDpd(*)
 *  功能描述   : dpd 清表   0x0003消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP调用，调试接口为clearlut
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspClearDpd(UINT32 chan, UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    
    BspLog(LOG_LEVEL_0,"%s{chan %d bandId %d} \n",__FUNCTION__,chan,bandId);
    return DpdMsgClrLut(ulDifChnl, bandId, 0);
}
/*********************************3 矢量驻波检测*****************************************/
/*****************************************************************************
 *  函数名称   : BspNotifyDpdStartVswrCalc(*)
 *  功能描述   : CPU通过该消息通知DSP 发起VSWR 计算  0x004消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   :  无
 *  返 回 值   :  BSP_OK 成功
 *               其他     失败
 *  其它说明   :  内部使用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zfx@2019-09-10, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspNotifyDpdStartVswrCalc(UINT32 chan,UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgVswrStart(ulDifChnl, bandId);
}

/* Started by AICoder, pid:g2657n4d43uc0b414b6a0b900087f5574ec4a83c */
UINT32 BspGetDspVswr_RfBridge(UINT32 chan, INT32 *pVswrReal, INT32 *pVswrImag, INT32 *pNco)
{
    UINT32 retVal = BSP_OK;
    INT32 cnt = 10;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pVswrReal);
    INPUT_POINTER_CHECK(pVswrImag);
    INPUT_POINTER_CHECK(pNco);
    BspSysMsDelay(500);

    for(cnt = 10; cnt > 0; cnt--)
    {
        if (BSP_OK != DpdMsgGetSpaVal_RfBridge(chan, &spaVal))
        {
            DpdPrint(PM_INFO,"cnt= %d,state = 0x%x\n",cnt, spaVal.calcFinish);
            DpdPrint(PM_ERROR,"%s>>BspChnl'%d DpdVswrVal MsgGet Error!\n", __FUNCTION__, chan);
            return BSP_ERROR;
        }

        retVal = spaVal.calcFinish;
        if(RF_BRIDGE_SAMP_FINISHED == retVal)
        {
            break;
        }
        else
        {
            BspSysMsDelay(500);
        }
    }
    if(0 >= cnt)
    {
        DpdPrint(PM_INFO,"cnt= %d,state = 0x%x\n",cnt,retVal);
        DpdPrint(PM_ERROR,"%s chn[%d] Get DpdVswrVal timeout\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    if(0 != spaVal.calcResult)
    {
        DpdPrint(PM_ERROR,"dsp vswr cal failed state = 0x%x\n",spaVal.calcResult);
        return BSP_ERROR;
    }
    if (BSP_OK != DpdMsgGetSpaVal_RfBridge(chan, &spaVal))
    {
        DpdPrint(PM_ERROR,"%s>>BspChnl'%d DpdVswrVal MsgGet Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    *pVswrReal = spaVal.spaData[0].spaI;
    *pVswrImag = spaVal.spaData[0].spaQ;
    *pNco      = spaVal.spaData[0].nco;
    dbgInfoEx("%s>> VswrReal = %d  VswrImag = %d  Nco = %d!\n", __FUNCTION__, *pVswrReal,*pVswrImag,*pNco);

    return BSP_OK;
}
/* Ended by AICoder, pid:g2657n4d43uc0b414b6a0b900087f5574ec4a83c */

/*****************************************************************************
 *  函数名称   : BspGetDspVswr(*)
 *  功能描述   : 获取DSP计算的矢量驻波 0xc007
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : pVswrReal、pVswrImag、pNco   vswr spa系数的实部虚部 nco
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : vectorvswr模块 BspCalcVswrByVector调用 BspGetDspVswr_IC3后缀去掉
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetDspVswr(UINT32 chan,UINT32 bandId,INT32 *pVswrReal, INT32 *pVswrImag,INT32 *pNco)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    INT32 cnt = 10;
    T_DpdMsgVswrQueryAck *vswrVal = NULL;
    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pVswrReal);
    INPUT_POINTER_CHECK(pVswrImag);
    INPUT_POINTER_CHECK(pNco);

    vswrVal = (T_DpdMsgVswrQueryAck *)malloc(sizeof(T_DpdMsgVswrQueryAck));
    INPUT_POINTER_CHECK(vswrVal);
    memset_s(vswrVal, sizeof(T_DpdMsgVswrQueryAck), 0, sizeof(T_DpdMsgVswrQueryAck));  //驻波返回值先初始化为0

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        free(vswrVal);
        return BSP_ERROR;
    }
    if(s_rfBridgeChanFlag[ulDifChnl] == 1)
    {
        dbgInfoEx("%s>>BspChnl'%d is belong rfBridge!\n", __FUNCTION__, chan);
        ulRetVal = BspGetDspVswr_RfBridge(ulDifChnl, pVswrReal, pVswrImag, pNco);
        free(vswrVal);
        return ulRetVal;
    }

    if (BSP_OK != DpdMsgVswrStart(ulDifChnl, bandId))
    {
        dbgInfoEx("start vswr failed \n");
        free(vswrVal);
        return BSP_ERROR;
    }

    BspSysMsDelay(500);
    //DpdPrint(PM_INFO,"start vswr cal! \n");

    for(cnt = 10; cnt > 0; cnt--)
    {
        if (BSP_OK != DpdMsgGetVswrVal(ulDifChnl, bandId, vswrVal))
        {
            dbgInfoEx("cnt= %d,state = 0x%x, SamFlag=%d\n",cnt, vswrVal->iVswrCalFlag,vswrVal->iVswrSamFlag);
            dbgInfoEx("%s>>BspChnl'%d DifChnl'%d DpdVswrVal MsgGet Error!\n",
                     __FUNCTION__, chan, ulDifChnl);
            free(vswrVal);
            return BSP_ERROR;
        }

        ulRetVal = vswrVal->iVswrCalFlag;
        if(0 == ulRetVal)
        {
            break;
        }
        else
        {
            BspSysMsDelay(500);
        }
    }
    if(0 >= cnt)
    {
        dbgInfoEx("cnt= %d,state = 0x%x\n",cnt,ulRetVal);
        dbgInfoEx("%s chn[%d] Get DpdVswrVal timeout\n", __FUNCTION__, chan);
        free(vswrVal);
        return BSP_ERROR;
    }

    if(0!=vswrVal->iVswrSamFlag)
    {
        dbgInfoEx("dsp vswr cal failed state = 0x%x\n",vswrVal->iVswrSamFlag);
        free(vswrVal);
        return BSP_ERROR;
    }
    if (BSP_OK != DpdMsgGetVswrVal(ulDifChnl, bandId, vswrVal))
    {
        dbgInfoEx("%s>>BspChnl'%d DifChan'%d DpdVswrVal MsgGet Error!\n",
                 __FUNCTION__, chan,ulDifChnl);
        free(vswrVal);
        return BSP_ERROR;
    }
    *pVswrReal = vswrVal->spaData[0].vswrReal;  /*中试不做归一化处理，正式流程也不*/
    *pVswrImag = vswrVal->spaData[0].vswrImag;
    *pNco = vswrVal->spaData[0].nco;
    dbgInfoEx("[%s] 0xc007 band no is %d\n", __FUNCTION__, vswrVal->bandNo);
    free(vswrVal);
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspGetMultiDspVswr(*)
 *  功能描述   : 获取DSP计算的矢量驻波 0xc007 工装多点检测使用
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : pVswrReal、pVswrImag、pNco   vswr spa系数的实部虚部 nco
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : vectorvswr模块 BspCalcVswrByVector调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetMultiDspVswr(UINT32 chan,UINT32 bandId,T_DpdMsgVswrQueryAck *pSpaVal)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulCnt = 10;
    T_DpdMsgVswrQueryAck *vswrVal = NULL;

    DPD_CHAN_CHECK(chan);  /*放到malloc之后有内存泄露风险*/
    vswrVal = (T_DpdMsgVswrQueryAck *)malloc(sizeof(T_DpdMsgVswrQueryAck));
    INPUT_POINTER_CHECK(vswrVal);
    memset_s(vswrVal, sizeof(T_DpdMsgVswrQueryAck), 0, sizeof(T_DpdMsgVswrQueryAck));  //驻波返回值先初始化为0

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        free(vswrVal);
        return BSP_ERROR;
    }

    if (BSP_OK != DpdMsgVswrStart(ulDifChnl,bandId))
    {
        DpdPrint(PM_ERROR,"start  vswr calc  failed \n");
        free(vswrVal);
        return BSP_ERROR;
    }
    BspSysMsDelay(5000);
    DpdPrint(PM_INFO,"start vswr cal! \n");

    for(ulCnt = 5; ulCnt > 0; ulCnt--)
    {
        if (BSP_OK != DpdMsgGetVswrVal(ulDifChnl, bandId, vswrVal))
        {
            DpdPrint(PM_INFO,"cnt= %d,state = 0x%x\n",ulCnt, vswrVal->iVswrCalFlag,vswrVal->iVswrSamFlag);
            DpdPrint(PM_ERROR,"%s>>BspChnl'%d DifChnl'%d DpdVswrVal MsgGet Error!\n",
                     __FUNCTION__, chan, ulDifChnl);
            free(vswrVal);
            return BSP_ERROR;
        }

        ulRetVal = vswrVal->iVswrCalFlag |vswrVal->iVswrSamFlag;
        if(0 == ulRetVal)
        {
            break;
        }
        else
        {
            BspSysMsDelay(2000);
        }
    }
    if(0 >= ulCnt)
    {
        DpdPrint(PM_INFO,"cnt= %d,state = 0x%x\n",ulCnt,ulRetVal);
        DpdPrint(PM_ERROR,"%s chn[%d] get sta timeout\n", __FUNCTION__, chan);
        free(vswrVal);
        return BSP_ERROR;
    }
    if (BSP_OK != DpdMsgGetVswrVal(ulDifChnl, bandId, vswrVal))
    {
        DpdPrint(PM_ERROR,"%s>>BspChnl'%d DifChnl'%d DpdVswrVal MsgGet Error!\n",
                 __FUNCTION__, chan, ulDifChnl);
        free(vswrVal);
        return BSP_ERROR;
    }
    memcpy_s((char *)pSpaVal,sizeof(T_DpdMsgVswrQueryAck),(char *)vswrVal,sizeof(T_DpdMsgVswrQueryAck));
    free(vswrVal);
    return BSP_OK;
}
/************************************4 PIMC功能*****************************************/
/*****************************************************************************
 *  函数名称   : BspPimcStart(*)
 *  功能描述   : 给DSP发送启动PIMC 0x0008消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspDpdPimcStart(UINT32 chan, UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcCtrl(ulDifChnl, bandId, DPD_PIMC_START);
}
/*****************************************************************************
 *  函数名称   : BspPimcStop(*)
 *  功能描述   : 给DSP发送停止PIMC   0x0008消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspDpdPimcStop(UINT32 chan,UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcCtrl(ulDifChnl, bandId, DPD_PIMC_STOP);
}
/*****************************************************************************
 *  函数名称   : BspPimcPreTaining(*)
 *  功能描述   : 给DSP发送PIMC 预训练 0x0008消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdPimcPreTaining(UINT32 chan,UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcCtrl(ulDifChnl, bandId, DPD_PIMC_PRETAINING);
}
/*****************************************************************************
 *  函数名称   : BspPimcClrLut(*)
 *  功能描述   : 给DSP发送PIMC 清表  0x0009
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspDpdPimcClrLut(UINT32 chan, UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcClrTbl(ulDifChnl, bandId);
}
/*****************************************************************************
 *  函数名称   : BspDpdByPass(*)
 *  功能描述   : dpd旁路 0x000a消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : chan：bsp通道号
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdPimcByPass(UINT32 chan)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcBypass(ulDifChnl, DPD_FREQ_ALL,DPD_PIMC_BYPASS);
}
/*****************************************************************************
 *  函数名称   : BspPimcUnByPass(*)
 *  功能描述   : Pimc不旁路 0x000a消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdPimcUnByPass(UINT32 chan)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcBypass(ulDifChnl, DPD_FREQ_ALL,DPD_PIMC_UNBYPASS);
}

/*****************************************************************************
 *  函数名称   : BspDpdPimcSetFreqPara(*)
 *  功能描述   : 设置pimc相关配置参数 频点 带宽等 0x4001
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号  bandId:频段号 rxCenter:接收中心频点
 *              pimcCenter:pimc中心频点 pimcBw: 带宽
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 单位KHZ
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdPimcSetFreqPara(UINT32 chan,UINT32 bandId,UINT32 rxCenter,UINT32 pimcCenter,UINT32 pimcBw)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgSetSignalPara dpdMsgPara = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    dpdMsgPara.index_modul = DPD_PARA_PIMC_PARA;
    dpdMsgPara.index_func  = rxCenter;
    dpdMsgPara.par0  = pimcCenter;
    dpdMsgPara.par1  = pimcBw;

    return DpdMsgSetPara(ulDifChnl, bandId, &dpdMsgPara);
}
/*****************************************************************************
 *  函数名称   : BspPimcPreTaining(*)
 *  功能描述   : 查询DSP发送PIMC 预训练结果 0x800a消息
 *  输入参数   : chan：bsp通道号  bandId:频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 正常
 *              其他    异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspDpdPimcPreTrainSta(UINT32 chan, UINT32 bandId)
{
    UINT32 state = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgPimcPreTrainState(ulDifChnl, bandId, &state);
    DpdPrint(PM_INFO,"PimcChnl'%d DifChnl'%d RetVal'0x%04X: PimcPreTrainState= %d\n",
             chan, ulDifChnl, ulRetVal, state);

    if (ulRetVal != BSP_OK)
    {
        return ulRetVal;
    }

    if (state == DPD_PIMC_PRETRAN_FINISH)
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}
/*发起在线pim检测*/
UINT32 BspStartOnlinePim(UINT32 bspChn, UINT32 bandNo, UINT32 order, UINT32 mode)
{
    UINT32 retVal = BSP_ERROR;
    if((order != ONLINE_PIM_3) && (order != ONLINE_PIM_5) && (order != ONLINE_PIM_7) && (order != ONLINE_PIM_9))
    {
        return retVal;
    }

    if(mode)
    {
        retVal = DpdMsgStartCtrlOnlinePim(bspChn,bandNo,ONLINE_PIM_START);
    }
    else
    {
        retVal = DpdMsgStartCtrlOnlinePim(bspChn,bandNo,ONLINE_PIM_STOP);
    }

    return retVal;
}

UINT32 BspStartPts(UINT32 bspChn, UINT32 mode)
{
    return BspStartOnlinePim(bspChn,0,1,mode);
}
/*获取在线pim的检测结果*/
UINT32 BspGetOnlinePim(UINT32 bspChn, UINT32 bandNo, INT32 *pimVal, INT32 *mutiPimVal, INT32 *noiseVal, UINT16 *rxPimFreq, UINT16 *rhoVal)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 pimChkNum = 0;
    INT32  rssiGain  = 0;
    INT32 carrFreq  = 0;
    INT32  pimThreshold = -10550;

    T_DpdMsgGetOnlinePimValAck pimdata = { 0 };

    retVal = DpdMsgGetPimVal(bspChn,bandNo,&pimdata);
    pimChkNum = pimdata.pim_chk_num;
    carrFreq = pimdata.pim_online_chk_val[0].pim_chk_nco;
    *rxPimFreq = (UINT16)((carrFreq/100) & 0xFFFF);

    if(retVal == ONLINE_PIM_SUCC)
    {
        retVal = BspGetRssiDbmCompGain(bspChn, 0x2000, (UINT32)carrFreq, 0, &rssiGain, 0);
        if(retVal != BSP_OK)
        {
            dbgErr("Get rssiGain(%d) Failed,Freq is %d\n", rssiGain, carrFreq);
        }
        else
        {
            dbgInfo("Get rssiGain(%d) Success,Freq is %d\n", rssiGain, carrFreq);
        }

        *pimVal     = (pimdata.pim_online_chk_val[0].pim_chk_value - rssiGain);
        *mutiPimVal = (pimdata.pim_online_chk_val[0].muti_pim_chk_value - rssiGain);
        *noiseVal   = (pimdata.pim_online_chk_val[0].noise_value - rssiGain);

        *pimVal     = (*pimVal < pimThreshold) ? (pimThreshold):(*pimVal);
        *mutiPimVal = (*mutiPimVal < pimThreshold) ? (pimThreshold):(*mutiPimVal);
        *noiseVal   = (*noiseVal < pimThreshold) ? (pimThreshold):(*noiseVal);
        retVal = BSP_OK;
    }
    else if(retVal == ONLINE_PIM_CALC)
    {
        *pimVal = 0;
        *mutiPimVal = 0;
        *noiseVal = 0;
        dbgInfo("[%s] the result of Pim is 0x%x\n", __FUNCTION__, retVal);
        retVal = 1;
    }
    else
    {
        *pimVal = 0;
        *mutiPimVal = 0;
        *noiseVal = 0;
        dbgInfo("[%s] the result of Pim is 0x%x\n", __FUNCTION__, retVal);
        retVal = 2;
    }

    dbgInfo("[%s] chan(%d), pimChkNum(%d), sigPimVal(%d), mutiPimVal(%d), noiseVal(%d), rxPimFreq(%d), rssiGain(%d), carrFreq(%d), pimThreshold(%d)\n",
        __FUNCTION__, bspChn, pimChkNum, *pimVal, *mutiPimVal, *noiseVal, *rxPimFreq, rssiGain, carrFreq, pimThreshold);

    return retVal;
}

UINT32 BspGetPtsData(UINT32 bspChn)
{
    INT32 pimVal = 0;
    INT32 mutiPimVal = 0;
    INT32 noiseVal = 0;
    UINT16 rxPimFreq = 0;

    return BspGetOnlinePim(bspChn, 0, &pimVal, &mutiPimVal, &noiseVal, &rxPimFreq, NULL);
}
/************************************5 TS功能*******************************************/
/*****************************************************************************
 *  函数名称   : BspTsEnCtrl(*)
 *  功能描述   : TS主动使能接口
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *          ulChanMask 通道掩码
 *          ctrl 使能标识
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/

UINT32 BspTsEnCtrl(UINT32 ulChanMask, UINT32 ctrl)
{
    BspLog(LOG_LEVEL_0,"%s{chan %d ctrl %d} \n",__FUNCTION__,ulChanMask,ctrl);
    return DpdMsgTsFlagCtrl(ulChanMask, ctrl);
}
/*****************************************************************************
 *  函数名称   : BspDpdTsCtrl(*)
 *  功能描述   : dpd TS 启动/停止 0x000c消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : para:  CFR_TS_LMS_PRE = 0x5A, 预处理初始化 CFR_TS_SHORT = 2,短周期TS CFR_TS_LONG = 3,长周期TS CFR_TS_PIM = 4 PIM检测
 *              ctrl:  CFR_TS_STOP = 0x2d2d,  叫停 CFR_TS_START = 0x5a5a, 启动  CFR_TS_IDLE = 0xFFFF, 空闲
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : TS即训练序列 APP调用，所以gpNum没用也无法删除
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdTsCtrl(UINT32 para,UINT32 ctrl,UINT32 gpNum)
{
    UINT32 typeId       = HEAD_TYPE_ID_SOC_DSP;
    UINT32 ulChnlNo     = 0;
    UINT32 ulFreqBandNo = 0;
    UINT32 state        = (SWITCH_ON == ctrl)? SW_DPD_ENABLE : SW_DPD_DISABLE;
    UINT32 tstype       = para;
    UINT32 ulChipId     = 0;
    UINT32 ulDifChnl    = 0;
    UINT32 ulRetVal     = BSP_OK;
    UINT32 ulRet     = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulChnlNo, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulChnlNo);
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:4b05ab7f589c871145390b0d80eb823ff4b0924e */
    //微ncr的TDD通道需要该处理
    if(IS_NCR == BspIsNcr() && SW_DPD_ENABLE == state)
    {
        ulRetVal = BspRegWr(0, REG_FPGA_MT_PA_SWI, 0, 0x1);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("Failed to enable PA switch in FPGA.\n");
        }
    }

    ulRet = DspMsgCtrlTs(typeId,ulDifChnl,ulFreqBandNo,tstype,state);

    if(IS_NCR == BspIsNcr() && SW_DPD_DISABLE == state)
    {
        ulRetVal = BspRegWr(0, REG_FPGA_MT_PA_SWI, 0, 0x0);
        if (BSP_OK != ulRetVal)
        {
            dbgErr("Failed to enable PA switch in FPGA.\n");
        }
    }
    /* Ended by AICoder, pid:4b05ab7f589c871145390b0d80eb823ff4b0924e */
    return ulRet;
}

/* Started by AICoder, pid:57214vdc67q38ba146a7094ad031e8184b22f39e */
UINT32 BspSetDpdSwMode(UINT32 tsktype)
{
    UINT32 retVal = BSP_OK;

    dbgInfoEx("%s tsktype:%d\n",__FUNCTION__,tsktype);
    BspLog(LOG_LEVEL_0,"%s tsktype:%d\n",__FUNCTION__,tsktype);
    if(pSetDpdSwModeInfo != NULL)
    {
        retVal = pSetDpdSwModeInfo(tsktype);
    }
    return retVal;
}
/* Ended by AICoder, pid:57214vdc67q38ba146a7094ad031e8184b22f39e */

/*****************************************************************************
 *  函数名称   : BspDpdTsSwitch(*)
 *  功能描述   : dpd ts辅助训练使能  0x4013
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : sw开关 gpNum：暂时未用
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP调用，hal接口未实现，所以先屏蔽
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdTsSwitch(UINT32 sw, UINT32 gpNum)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 bspChan = 0;
    UINT32 tddMaskFlag = 0;
    UINT32 tddIndex = 0;
    UINT32 bspChanMask = 0;
    UINT32 tddType = 0;
    UINT32 gpEn = 0;
    UINT32 ulRetVal = BSP_OK;

    if(SWITCH_ON == sw)
    {
        tddType = E_TDD_TYPE_TS;    /*10代表TS TDD*/
        gpEn = SWITCH_ON;           /*加塞时需要使能GP功能，允许在GP时隙插数*/
        /*中频加塞配置，0是DPD加载，1是AC，用于AC和DPD互斥*/
        BspHalAdaptSetAcOrTsCfgEn(E_CFG_TS_TYPE);
    }
    else
    {
        tddType = E_TDD_TYPE_NORMAL;   /*2代表正常TDD*/
        gpEn = SWITCH_OFF;              /*TS结束需要去使能GP功能*/
        if(E_INIT_TYPE_MS == BspGetInitTddNum())
        {
            return BSP_OK; /*一拖三机型GP使能不能关*/
        }
    }
    for(bspChan = 0; bspChan < BspGetTxChanNum(); bspChan++)
    {

        ulRetVal = DpdGetDifInfoByBspChnl(bspChan, TX, &ulChipId, &ulDifChnl);
        if ((BSP_OK != ulRetVal) || (BspGetChanModeType(bspChan) == 0)) /*fdd 通道不往下走*/
        {
            dbgInfoEx("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
            ulDifChnl = bspChan;
            continue;
        }
        BspHalAdaptSetTsGpEn(ulDifChnl,gpEn);
        dbgInfoEx("%s bspChan'%d difChan'%d gpEn'%d \n", __FUNCTION__,bspChan,ulDifChnl,gpEn);
        bspChanMask = BIT_SET(bspChan);
        tddIndex = BspGetTddCfgIdByChanMask(bspChanMask);
        if(BIT_SET(tddIndex) & tddMaskFlag)
        {
            dbgInfoEx("%s tddIndex'%d tddMaskFlag'%d bspChan'%d\n", __FUNCTION__,tddIndex,tddMaskFlag,bspChan);
            continue;
        }
        BspTddSwModeSel(tddIndex,tddType);
        BspUpdateTddIoVariablePara(tddIndex,tddType);
        tddMaskFlag |= BIT_SET(tddIndex);
        dbgInfoEx("%s tddIndex'%d tddMaskFlag'%d bspChan'%d tddType'%d \n", __FUNCTION__,tddIndex,tddMaskFlag,bspChan,tddType);
    }

    /*return DpdMsgTsEn(typeId,ulDifChnl,ulFreqBandNo,state);  4.2 dsp不需要感知到，只需要配置到IC*/
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspDpdTsEnSta(*)
 *  功能描述   : dpd ts辅助训练使能状态查询 0x8013消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   : pSw 开关状态
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 内部接口
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdTsEnSta(UINT32 *pSw)
{
	UINT32 ret = BSP_OK;
	UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;

	INPUT_POINTER_CHECK(pSw);
	
	ret = DpdMsgQueryTsEn(typeId, 0, 0, pSw);

	return ret;
}
/*****************************************************************************
 *  函数名称   : BspDpdTsExpQuery(*)
 *  功能描述   : DSP发起TS请求消息，TS异常时DSP发起TS请求  0x8016
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   : *queryResult: TS请求结果,是否异常+对应通道
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdTsExpQuery(T_DpdTsExpQueryResult *queryResult)
{
    UINT32 retVal = BSP_OK;
    UINT32 bspChan = 0;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT32 difChan = 0;
    UINT32 bandId = 0;
    UINT32 ulChipId = 0;
    UINT32 chanbitmask = 0;
    UINT32 difChanMask = 0;
    UINT32 tskTypeValue = 0;
    UINT32 tsSta = 0;
    UINT32 bspChanMask = 0;
    UINT16 ulCaliType = 0;
    UINT16 ulCaliBranch = 0;

    T_DpdTsExpQueryResult dspRequst = {0};

    retVal = DpdMsgDspRequireTsEn(typeId,difChan,bandId,&dspRequst);
    if(retVal != BSP_OK)
    {
        dbgErr("%s get resault is error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    tsSta = dspRequst.expFlag;
    difChanMask = dspRequst.chanmask;
    tskTypeValue = dspRequst.tsktype;
    ulCaliType = dspRequst.calitype;
    ulCaliBranch = dspRequst.calibranch;

    dbgInfoEx("%s Ts Request result: Ts Sta:%d DifChanMask:%d tskTypeValue:%d ulCaliType:%d ulCaliBranch:%d\n",__FUNCTION__,tsSta,difChanMask,tskTypeValue,ulCaliType,ulCaliBranch);
    for(bspChan = 0; bspChan < BspGetTxChanNum(); bspChan++)
    {
        retVal = DpdGetDifInfoByBspChnl(bspChan, TX, &ulChipId, &difChan);
        if (BSP_OK != retVal)
        {
            dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
            return BSP_ERROR;
        }
        chanbitmask = BIT_SET(difChan); 
        if(difChanMask & chanbitmask)
        {
            bspChanMask |= BIT_SET(bspChan);
        }
    }

    queryResult->expFlag = tsSta;
    queryResult->chanmask = bspChanMask;
    queryResult->tsktype = tskTypeValue;
    queryResult->calitype = ulCaliType;
    queryResult->calibranch = ulCaliBranch;

    dbgInfoEx("%s Ts Request result: Ts Sta:%d BspChanMask:%d tskTypeValue:%d ulCaliType:%d ulCaliBranch:%d\n",__FUNCTION__,tsSta,bspChanMask,tskTypeValue,ulCaliType,ulCaliBranch);
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspDpdTsQuery(*)
 *  功能描述   : 查询TS状态 0x800c消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : para目前没用到
 *  输出参数   :
 *  返 回 值   : 返回0代表TS完成，其它值代表未完成
 *  其它说明   : TS即训练序列，不为通道
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
/* Started by AICoder, pid:be5ddqf084s88c614acb0a66503dd5451393a20f */
UINT32 BspDpdTsQuery(UINT32 para)
{
    UINT32 typeId       = HEAD_TYPE_ID_SOC_DSP;
    UINT32 ulChnlNo     = 0;//没用到
    UINT32 ulFreqBandNo = 0;//没用到
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulRes = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulChnlNo, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulChnlNo);
        return BSP_ERROR;
    }
    //这里的查询是dsp全部通道完成后才会回传完成状态
    ulRetVal = DspMsgQueryTs(typeId, ulDifChnl, ulFreqBandNo);

    if((IS_NCR == BspIsNcr()) && (0 == ulRetVal))
    {
        ulRes = BspRegWr(0, REG_FPGA_MT_PA_SWI, 0, 0x0);
        if(BSP_OK != ulRes)
        {
            dbgErr("BspDpdTsQuery Failed to disable PA switch in FPGA.\n");
        }
    }
    return ulRetVal;
}
/* Ended by AICoder, pid:be5ddqf084s88c614acb0a66503dd5451393a20f */

/* Started by AICoder, pid:u62cb57a5ek0b4414be60bba1071b5250c184316 */
UINT32 BspDpdDopaCaliQuery(VOID)
{
    UINT32 typeId       = HEAD_TYPE_ID_SOC_DSP;
    UINT32 ulChnlNo     = 0;
    UINT32 ulFreqBandNo = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulChnlNo, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulChnlNo);
        return BSP_ERROR;
    }

    ulRetVal = DspMsgQueryDopaCali(typeId, ulDifChnl, ulFreqBandNo);

    if(ulRetVal == BSP_OK)
    {
        if(pSetGainFlag != NULL)
        {
            pSetGainFlag();
        }
    }

    return ulRetVal;
}
/* Ended by AICoder, pid:u62cb57a5ek0b4414be60bba1071b5250c184316 */

/*****************************************************************************
 *  函数名称   : BspGetAacPermitFlgMsgTx(*)
 *  功能描述   : 0x0200消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : AAC发起的DSP侧前置条件满足标志上报消息DSP发送消息体
 *  输出参数   : 无
 *  返 回 值  : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetAacPermitFlgMsgTx(T_AacPermitFlgMsgTx *aacPermitFlgMsgTx)
{
    INPUT_POINTER_CHECK(aacPermitFlgMsgTx);
    UINT32 ulRetVal = BSP_OK;
    ulRetVal = DspMsgGetAacPermitFlgTx(aacPermitFlgMsgTx);

    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>DspMsgGetAacPermitFlgTx Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(0 != aacPermitFlgMsgTx->uiAacPermitFlg)
    {
        dbgInfoEx("%s >> aacPermitFlgMsgTx->uiAacPermitFlg = %d \n",__FUNCTION__,aacPermitFlgMsgTx->uiAacPermitFlg);
    }
    for(int i = 0;i < (sizeof(aacPermitFlgMsgTx->uiReserve)/sizeof(aacPermitFlgMsgTx->uiReserve[0])); i++)
    {
        dbgInfoEx("%s >> aacPermitFlgMsgTx->uiReserve[%d] = %d \n",__FUNCTION__,i,aacPermitFlgMsgTx->uiReserve[i]);
    }

    return ulRetVal;
}

/* Started by AICoder, pid:k0e46k491amc4d7143700b2ec0b6ad125d763c1e */
/*****************************************************************************
 *  函数名称   : BspSetDspDmimoCfgClrFlg(*)
 *  功能描述   : 0x0201消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 控制DMIMO配置信息清零的消息
 *  输出参数   : 无
 *  返 回 值  : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspSetDspDmimoCfgClrFlg(T_DmmCfgClrMsg *dmimoCfgClrMsg)
{
    INPUT_POINTER_CHECK(dmimoCfgClrMsg);
    UINT32 ulRetVal = BSP_OK;
    ulRetVal = DpdMsgDmimoSetFlag(dmimoCfgClrMsg);

    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>DpdMsgDmimoSetFlag Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("%s >> uiChn = %d,uiDmmCfgClrFlg = %d \n",__FUNCTION__,dmimoCfgClrMsg->uiChn,dmimoCfgClrMsg->uiDmmCfgClrFlg);
    BspLog(LOG_LEVEL_0,"%s >> uiChn = %d,uiDmmCfgClrFlg = %d \n",__FUNCTION__,dmimoCfgClrMsg->uiChn,dmimoCfgClrMsg->uiDmmCfgClrFlg);

    return ulRetVal;
}
/* Ended by AICoder, pid:k0e46k491amc4d7143700b2ec0b6ad125d763c1e */

/* Started by AICoder, pid:d35f0ia109u3b01141ac0b155036f525ece6b689 */
INT32 BspGetBandFrameAdj(UINT32 bspChan, UINT32 carrNo, UINT32 carrMode, INT32 bandAdj)
{
    UINT32 retVal = BSP_OK;
    INT32 bandFrAdj = 0;

    //针对TDD机型
    if((BSP_RADIO_STANDARD_LTE_TDD==carrMode)||(BSP_RADIO_STANDARD_5G==carrMode))
    {
        BspLog(LOG_LEVEL_0,"%s >> carrNo:%d,carrMode:0x%x, bandAdj:%d\n",__FUNCTION__, carrNo, carrMode, bandAdj);
        return bandAdj;
    }

    /* 获取小区ID并查询调整参数 */
    retVal |= IcHalApiGetFddOriFrTmVal(bspChan, TX, carrNo, carrMode, &bandFrAdj);
    /* 错误处理 */
    if (retVal != BSP_OK)
    {
        bandFrAdj = 0;
        BspLog(LOG_LEVEL_0,"%s >> bspChan:%d,carrNo:%d,carrMode:0x%x\n",__FUNCTION__, bspChan, carrNo, carrMode);
    }

    /* 记录调试信息 */
    BspLog(LOG_LEVEL_0, "%s>>>chan[%u], carrNo[%u] ,radioMode[%#x], bandFrAdj[%d]\n",
        __FUNCTION__, bspChan, carrNo, carrMode, bandFrAdj);

    return bandFrAdj;
}
/* Ended by AICoder, pid:d35f0ia109u3b01141ac0b155036f525ece6b689 */

/************************************6 配置、参数、路由等信息下发*******************************************/
/*******************************************************************************************************
 * 分两部分，配置信息： 小区配置 帧结构 时隙配比 ts配置 调压次数
 *         整机硬件信息：功放信息  整机硬件资产信息
 ********************************************************************************************************/

/*****************************************************************************
 *  函数名称   : BspDpdSetCellInfo(*)
 *  功能描述   : 给DSP发送小区配置信息  0x4005消息
 *  输入参数   :
 *  输出参数   : chan:bsp通道号 bandId:频段号
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 下发小区配置信息(载波信息+TDD表项)
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspDpdSetCellInfo(UINT32 chan,UINT32 bandId) /*TDD不分上下行 FDD分，这个接口的名字先不动*/
{
    UINT32 loop = 0;
    UINT32 carr_loop = 0;
    UINT32 carrSum = 0;
    INT32  txLoFlg = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_RruRfCfgInfo rruCfgPara = {0};
    T_RruVswrInfo rruVswrInfo = {0};
    T_CarrTddIndCfg rruFramInfo = {0};
    T_DpdMsgSetDlCellCfgPara setCell = {0};
    UINT32 antPortNum = 0xf;
    UINT32 activeFlag = 0;
    INT32 bankNco = 0;
    UINT32 uiBankId = 0;  

    memset(&setCell, 0, sizeof(T_DpdMsgSetDlCellCfgPara));

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    txLoFlg = BspGetBdIfFreq(chan,TX);
    if(txLoFlg <=0 )
    {
        setCell.loFlg = 0;
    }
    else
    {
        setCell.loFlg = 1;
    }

    BspGetChnlCfgCarrPara(chan, &rruCfgPara);
    BspGetChnlCfgCarrPara_5G(chan,&rruVswrInfo);
    BspGetRruVswrInfo(chan, &rruVswrInfo);

    if((NOT_QCELL_MODE == BspGetPbOrBbuMode()))/* ZHYZHY需要和APP同一天合入*/
    {
        BspGetTddCfgByChan(chan,&rruFramInfo); /*参数源头BspSetTddCfgInfo 高层下发*/ 
    }
    else
    {
        BspGetTxTddCfgByChan(chan,&rruFramInfo);/* QCELL区分上下行的 */
    }
    
    
    carrSum =  rruCfgPara.txCfgCarrSum;
    if(carrSum > DPD_UDP_IC42_MAX_CARR_NUM)
    {
        carrSum = 0;
    }
    setCell.dlValidCarrNum = carrSum;
    setCell.dlLoFreq = rruCfgPara.txCenterFreq;   /*即本振频点(已减去mts自带的nco 即非0中频偏移)*/
    setCell.fb_nco = BspGetBdIfFreq(chan,PRX);   /*目前反馈中频配置为0，后续演进*/
    DpdPrint(PM_DEBUG,"validCarrNum : %d \n", setCell.dlValidCarrNum);
    DpdPrint(PM_DEBUG,"loFlg        : %d \n", setCell.loFlg);
    DpdPrint(PM_DEBUG,"loFreq       : %d kHz\n", setCell.dlLoFreq);
    BspLog(LOG_LEVEL_0,"%s{chan %d validCarrNum %d,loFlg %d,loFreq %d} \n",__FUNCTION__,chan,\
    		setCell.dlValidCarrNum,setCell.loFlg,setCell.dlLoFreq);
    /*TDD表象信息*/
    setCell.tFrameInfo.uiTddCfgId = rruFramInfo.uiTddCfgId;
    setCell.tFrameInfo.uiCarrNo = rruFramInfo.uiCarrNo;
    setCell.tFrameInfo.uiRadioMode = rruFramInfo.uiRadioMode;
    setCell.tFrameInfo.uiChanMask = rruFramInfo.uiChanMask;
    setCell.tFrameInfo.uiDlUlSwNum = rruFramInfo.uiDlUlSwNum;
    memcpy_s(setCell.tFrameInfo.uiDlUlSwPeriod,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
            rruFramInfo.uiDlUlSwPeriod, MAX_UL_DL_SW_NUM*sizeof(UINT32));
    memcpy_s(setCell.tFrameInfo.uiDlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
            rruFramInfo.uiDlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
    memcpy_s(setCell.tFrameInfo.uiUlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
            rruFramInfo.uiUlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
    DpdPrint(PM_DEBUG,"TddCfgId   : %d \n", setCell.tFrameInfo.uiTddCfgId);
    DpdPrint(PM_DEBUG,"ChanMask   : %d \n", setCell.tFrameInfo.uiChanMask);
    DpdPrint(PM_DEBUG,"DlUlSwNum  : %d \n", setCell.tFrameInfo.uiDlUlSwNum);
    DpdPrint(PM_DEBUG,"uiCarrNo  : %d \n", setCell.tFrameInfo.uiCarrNo);
    DpdPrint(PM_DEBUG,"uiRadioMode  : %d \n", setCell.tFrameInfo.uiRadioMode);
    DpdPrint(PM_DEBUG,"uiDlUlSwPeriod  : %d \n", setCell.tFrameInfo.uiDlUlSwPeriod[0]);
    DpdPrint(PM_DEBUG,"uiDlSymbolNum  : %d \n", setCell.tFrameInfo.uiDlSymbolNum[0]);
    DpdPrint(PM_DEBUG,"uiUlSymbolNum  : %d \n", setCell.tFrameInfo.uiUlSymbolNum[0]);
    BspLog(LOG_LEVEL_0,"%s{TddCfgId %d,ChanMask %d,CarrNo %d,RadioMode %d,DlUlSwNum %d,DlUlSwPeriod %d,DlSymbolNum %d,UlSymbolNum %d} \n",__FUNCTION__,\
    		setCell.tFrameInfo.uiTddCfgId,setCell.tFrameInfo.uiChanMask,setCell.tFrameInfo.uiCarrNo,setCell.tFrameInfo.uiRadioMode,\
            setCell.tFrameInfo.uiDlUlSwNum,setCell.tFrameInfo.uiDlUlSwPeriod[0],setCell.tFrameInfo.uiDlSymbolNum[0],setCell.tFrameInfo.uiUlSymbolNum[0]);

    for (loop=0; loop<carrSum; ++loop)
    {
    	UINT32 carrPow   = 0;
        INT32 nco1Offset = 0;
        BspGetCfgCarrPow(chan, rruCfgPara.carr[loop].carrTxNo, rruCfgPara.carr[loop].carrTxRadio, &carrPow);
        BspGetCarrSta(chan, TX, rruCfgPara.carr[loop].carrTxRadio, rruCfgPara.carr[loop].carrTxNo, &activeFlag);
        setCell.atDlCarrPara[loop].dlSwitchFlag = activeFlag;
        setCell.atDlCarrPara[loop].radioMode = rruCfgPara.carr[loop].carrTxRadio;
        setCell.atDlCarrPara[loop].carrPow = carrPow;
        bankNco = 0;
        bankNco = BspGetCarrNcoCfg(TX, ulDifChnl, rruCfgPara.carr[loop].carrTxNo, rruCfgPara.carr[loop].carrTxRadio);/*从hal获取(载波nco+cfr里的频段nco,其中cfrnco目前不使用，为后续预留)*/
        if(BSP_RADIO_STANDARD_NB_IOT == rruCfgPara.carr[loop].carrTxRadio)
        {
        	(void)BspGetNbFreqOffset(chan, TX, rruCfgPara.carr[loop].carrTxNo, &nco1Offset);
        }
        setCell.atDlCarrPara[loop].carrNco1 = BspGetFilterBankNco(TX, chan, rruCfgPara.carr[loop].carrTxNo, rruCfgPara.carr[loop].carrTxRadio, bankNco) + nco1Offset/1000;
        setCell.atDlCarrPara[loop].carrNco2 =BspGetBandNcoCfg(TX,ulDifChnl,rruCfgPara.carr[loop].carrTxNo,rruCfgPara.carr[loop].carrTxRadio) ;/*从hal获取dlpost中的nco，通道级*/
        setCell.atDlCarrPara[loop].carrBandWidth = BspGetFilterCarrBw(TX, chan, rruCfgPara.carr[loop].carrTxNo, rruCfgPara.carr[loop].carrTxRadio, rruCfgPara.carr[loop].carrTxBw);

        BspHalAdaptGetTxBankId(chan, rruCfgPara.carr[loop].carrTxNo, rruCfgPara.carr[loop].carrTxRadio, &uiBankId);
        setCell.atDlCarrPara[loop].uiBankId = uiBankId;
        setCell.atDlCarrPara[loop].uiCarrId = rruCfgPara.carr[loop].carrTxNo;
        setCell.atDlCarrPara[loop].carrCopyType = BspGetCarrCopyType(TX, chan,rruCfgPara.carr[loop].carrTxNo);
        setCell.atDlCarrPara[loop].iFraAHeadAdj = BspGetBandFrameAdj(chan, rruCfgPara.carr[loop].carrTxNo, rruCfgPara.carr[loop].carrTxRadio, 0);

        DpdPrint(PM_DEBUG,"========%d========\n", loop);
        DpdPrint(PM_DEBUG,"dlSwitchFlag  : 0x%x \n",  setCell.atDlCarrPara[loop].dlSwitchFlag);
        DpdPrint(PM_DEBUG,"radioMode     : 0x%x \n",  setCell.atDlCarrPara[loop].radioMode);
        DpdPrint(PM_DEBUG,"carrPow       : %d mW\n",  setCell.atDlCarrPara[loop].carrPow);
        DpdPrint(PM_DEBUG,"carrNco1      : %d kHz\n", setCell.atDlCarrPara[loop].carrNco1);
        DpdPrint(PM_DEBUG,"carrBandWidth : %d kHz\n", setCell.atDlCarrPara[loop].carrBandWidth);
        DpdPrint(PM_DEBUG,"uiBankId        : %d    \n", setCell.atDlCarrPara[loop].uiBankId);
        DpdPrint(PM_DEBUG,"uiCarrId        : %d    \n", setCell.atDlCarrPara[loop].uiCarrId);
        DpdPrint(PM_DEBUG,"uiSsbRfFreq     : %d    \n", setCell.atDlCarrPara[loop].uiSsbRfFreq);
        DpdPrint(PM_DEBUG,"carrCopyType    : %d    \n", setCell.atDlCarrPara[loop].carrCopyType);

        BspLog(LOG_LEVEL_0,"%s{dlSwitchFlag 0x%x, radioMode 0x%x,carrPow %d mW,carrNco1 %d kHz,carrBandWidth %d  kHz  uiBankId %d  uiCarrId %d  uiSsbRfFreq %d  carrCopyType %d} \n",__FUNCTION__,\
                setCell.atDlCarrPara[loop].dlSwitchFlag,setCell.atDlCarrPara[loop].radioMode,setCell.atDlCarrPara[loop].carrPow,setCell.atDlCarrPara[loop].carrNco1,\
                setCell.atDlCarrPara[loop].carrBandWidth,setCell.atDlCarrPara[loop].uiBankId,setCell.atDlCarrPara[loop].uiCarrId,setCell.atDlCarrPara[loop].uiSsbRfFreq,setCell.atDlCarrPara[loop].carrCopyType);
  
        BspGetCarrAntPortNum(chan, rruCfgPara.carr[loop].carrTxNo, &antPortNum);   /*注意端口号的传递依赖于高层，后续要正式调试*/
        setCell.atDlCarrPara[loop].uiCarrPortNum = antPortNum;
        if((BSP_RADIO_STANDARD_LTE_TDD== setCell.atDlCarrPara[loop].radioMode)||(BSP_RADIO_STANDARD_5G== setCell.atDlCarrPara[loop].radioMode)||(BSP_RADIO_STANDARD_FDD_5G== setCell.atDlCarrPara[loop].radioMode))
        {
            for(carr_loop=0;carr_loop<rruVswrInfo.uiCarrNum; carr_loop++)
            {
                if(rruVswrInfo.carr[carr_loop].uiCarrNo == rruCfgPara.carr[loop].carrTxNo )
                {
                setCell.atDlCarrPara[loop].uiSubCarrierSpacing = rruVswrInfo.carr[carr_loop].uiSubCarrierSpacing;
                setCell.atDlCarrPara[loop].uiSsbGscn = rruVswrInfo.carr[carr_loop].uiSsbGscn;
                setCell.atDlCarrPara[loop].uiSsbSubBeamValidL = rruVswrInfo.carr[carr_loop].uiSsbSubBeamValidL;
                setCell.atDlCarrPara[loop].uiSsbSubBeamValidH = rruVswrInfo.carr[carr_loop].uiSsbSubBeamValidH;
                setCell.atDlCarrPara[loop].uiSsbPeriod = rruVswrInfo.carr[carr_loop].uiSsbPeriod;
                setCell.atDlCarrPara[loop].iFraAHeadAdj = BspGetBandFrameAdj(chan, rruCfgPara.carr[loop].carrTxNo, setCell.atDlCarrPara[loop].radioMode, rruVswrInfo.carr[carr_loop].iFraAHeadAdj);
                setCell.atDlCarrPara[loop].ssbSymbolFlag = rruVswrInfo.carr[carr_loop].ssbSymbolFlag;
                setCell.atDlCarrPara[loop].ssbSymbolIndex = rruVswrInfo.carr[carr_loop].ssbSymbolIndex;
                dbgInfoEx("[%s] ssb2port test carr = %d, ssbSymbolFlag = %u, ssbSymbolIndex = %u\n",__FUNCTION__, carr_loop, rruVswrInfo.carr[carr_loop].ssbSymbolFlag, rruVswrInfo.carr[carr_loop].ssbSymbolIndex);
                /*只有NR制式需要SSB频点*/
                /* Started by AICoder, pid:s63a833078541c1144e6088270ff13171631a8cf */
                if((BSP_RADIO_STANDARD_5G == setCell.atDlCarrPara[loop].radioMode) || (BSP_RADIO_STANDARD_FDD_5G== setCell.atDlCarrPara[loop].radioMode))
                {
                    BspLog(LOG_LEVEL_0,"%s 5GNR! carry %d: SsbRfFreq = %d\n",__FUNCTION__, carr_loop, rruVswrInfo.carr[carr_loop].uiSsbFreq);
                    setCell.atDlCarrPara[loop].uiSsbRfFreq = rruVswrInfo.carr[carr_loop].uiSsbFreq;
                }
                /* Ended by AICoder, pid:s63a833078541c1144e6088270ff13171631a8cf */
                DpdPrint(PM_DEBUG,"uiSubCarrierSpacing  : %d \n",  rruVswrInfo.carr[carr_loop].uiSubCarrierSpacing);
                DpdPrint(PM_DEBUG,"uiSsbGscn            : %d \n",  rruVswrInfo.carr[carr_loop].uiSsbGscn);
                DpdPrint(PM_DEBUG,"uiSsbSubBeamValidL   : %d \n", rruVswrInfo.carr[carr_loop].uiSsbSubBeamValidL);
                DpdPrint(PM_DEBUG,"uiSsbSubBeamValidH   : %d \n", rruVswrInfo.carr[carr_loop].uiSsbSubBeamValidH);
                DpdPrint(PM_DEBUG,"uiSsbPeriod          : %d\n",  rruVswrInfo.carr[carr_loop].uiSsbPeriod);
                DpdPrint(PM_DEBUG,"iFraAHeadAdj          : %d\n",  rruVswrInfo.carr[carr_loop].iFraAHeadAdj);
                DpdPrint(PM_DEBUG,"uiSsbRfFreq          : %d\n",  rruVswrInfo.carr[carr_loop].uiSsbFreq);
                break;
                }
            }
        }
    }

    return DpdMsgSetCellCfg(ulDifChnl, bandId, &setCell);
}

/*****************************************************************************
 *  函数名称   : BspUpdateChanActiveStatus(*)
 *  功能描述   : 发送小区激活标志  0x0032消息
 *  输入参数   :
 *  输出参数   : chan:bsp通道号 bandId:频段号
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspUpdateChanActiveStatus(UINT32 chan,UINT32 bandId)
{
    UINT32 loop = 0;
    UINT32 carrSum = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_RruRfCfgInfo rruCfgPara = {0};
    T_DspDlCellSwiInfo activeFlagInfo = {0};
    UINT32 activeFlag = 0;

    zte_memset_s(&activeFlagInfo, sizeof(T_DspDlCellSwiInfo), 0, sizeof(T_DspDlCellSwiInfo));

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d ulChipId:%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan,ulChipId);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(chan, &rruCfgPara);
    
    carrSum =  rruCfgPara.txCfgCarrSum;
    if(carrSum > DPD_UDP_IC42_MAX_CARR_NUM)
    {
        carrSum = 0;
    }
    activeFlagInfo.uiDlValidCarrNum = carrSum;
    DpdPrint(PM_DEBUG,"validCarrNum : %d \n", activeFlagInfo.uiDlValidCarrNum);
    BspLog(LOG_LEVEL_0,"%s{chan %d validCarrNum %d} \n",__FUNCTION__,chan,activeFlagInfo.uiDlValidCarrNum);

    for (loop=0; loop<carrSum; ++loop)
    {
        BspGetCarrSta(chan, TX, rruCfgPara.carr[loop].carrTxRadio, rruCfgPara.carr[loop].carrTxNo, &activeFlag);
        activeFlagInfo.atDlCarrSwiInfo[loop].uiCarrId       = rruCfgPara.carr[loop].carrTxNo;
        activeFlagInfo.atDlCarrSwiInfo[loop].uiRadioMode    = rruCfgPara.carr[loop].carrTxRadio;
        activeFlagInfo.atDlCarrSwiInfo[loop].uiDlSwitchFlag = activeFlag;

        DpdPrint(PM_DEBUG,"==========%d=========\n",  loop);
        DpdPrint(PM_DEBUG,"uiCarrId      : %d   \n",  activeFlagInfo.atDlCarrSwiInfo[loop].uiCarrId      );
        DpdPrint(PM_DEBUG,"radioMode     : 0x%x \n",  activeFlagInfo.atDlCarrSwiInfo[loop].uiRadioMode   );
        DpdPrint(PM_DEBUG,"dlSwitchFlag  : 0x%x \n",  activeFlagInfo.atDlCarrSwiInfo[loop].uiDlSwitchFlag);

        BspLog(LOG_LEVEL_0,"%s{dlSwitchFlag 0x%x, radioMode 0x%x, uiCarrId %d } \n",__FUNCTION__,\
                activeFlagInfo.atDlCarrSwiInfo[loop].uiDlSwitchFlag,activeFlagInfo.atDlCarrSwiInfo[loop].uiRadioMode,\
                activeFlagInfo.atDlCarrSwiInfo[loop].uiCarrId);

    }

    return DpdMsgSetActiveFlag(ulDifChnl, bandId, &activeFlagInfo);
}

/*****************************************************************************
 *  函数名称   : BspDpdSetCellInfo(*)
 *  功能描述   : 给DSP发送小区配置信息  0x4005消息
 *  输入参数   :
 *  输出参数   : chan:bsp通道号 bandId:频段号
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 下发小区配置信息(载波信息+TDD表项)
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspDpdSetRxCellInfo(UINT32 chan,UINT32 bandId)
{
    UINT32 loop = 0;
    UINT32 carrSum = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 carrPow  = 0;
    T_RruRfCfgInfo rruCfgPara = {0};
    T_DpdMsgSetUlCellCfgPara setCell = {0};

    memset(&setCell, 0, sizeof(T_DpdMsgSetUlCellCfgPara));

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    BspGetChnlCfgCarrPara(chan, &rruCfgPara);
    carrSum =  rruCfgPara.rxCfgCarrSum;
    if(carrSum > DPD_UDP_IC42_MAX_CARR_NUM)
    {
        carrSum = 0;
    }
    setCell.ulValidCarrNum = carrSum;
    setCell.ulLoFreq = rruCfgPara.rxCenterFreq;
    DpdPrint(PM_DEBUG,"validCarrNum : %d \n", setCell.ulValidCarrNum);
    DpdPrint(PM_DEBUG,"loFreq       : %d kHz\n", setCell.ulLoFreq);
    BspLog(LOG_LEVEL_0,"%s{chan %d validCarrNum %d,loFreq %d} \n",__FUNCTION__,chan,\
    		setCell.ulValidCarrNum,setCell.ulLoFreq);

    for (loop=0; loop<carrSum; ++loop)
    {
        carrPow = 0;
        BspGetCfgCarrPow(chan, rruCfgPara.carr[loop].carrTxNo, rruCfgPara.carr[loop].carrTxRadio, &carrPow);
        setCell.tCellCfgPara[loop].ulSwitchFlag = BspGetCarrActiveStatus(chan,RX, rruCfgPara.carr[loop].carrRxRadio,rruCfgPara.carr[loop].carrRxNo);
        setCell.tCellCfgPara[loop].radioMode = rruCfgPara.carr[loop].carrRxRadio;
        setCell.tCellCfgPara[loop].carrPow = carrPow;  /*上行无载波功率，暂时和下行同步处理*/
        setCell.tCellCfgPara[loop].bankNco = BspGetCarrCarrBankNcoCfg(RX, ulDifChnl, rruCfgPara.carr[loop].carrRxNo, rruCfgPara.carr[loop].carrRxRadio);
        setCell.tCellCfgPara[loop].bandNco = BspGetCarrCarrBandNcoCfg(RX, ulDifChnl, rruCfgPara.carr[loop].carrRxNo, rruCfgPara.carr[loop].carrRxRadio);
        setCell.tCellCfgPara[loop].carrBandWidth = BspGetFilterCarrBw(RX, chan, rruCfgPara.carr[loop].carrRxNo, rruCfgPara.carr[loop].carrRxRadio, rruCfgPara.carr[loop].carrRxBw);

        DpdPrint(PM_DEBUG,"========%d========\n", loop);
        DpdPrint(PM_DEBUG,"ulSwitchFlag     : 0x%x \n",  setCell.tCellCfgPara[loop].ulSwitchFlag);
        DpdPrint(PM_DEBUG,"radioMode     : 0x%x \n",  setCell.tCellCfgPara[loop].radioMode);
        DpdPrint(PM_DEBUG,"carrPow       : %d mW\n",  setCell.tCellCfgPara[loop].carrPow);
        DpdPrint(PM_DEBUG,"carrbankNco      : %d kHz\n", setCell.tCellCfgPara[loop].bankNco);
        DpdPrint(PM_DEBUG,"carrbandNco      : %d kHz\n", setCell.tCellCfgPara[loop].bandNco);
        DpdPrint(PM_DEBUG,"carrBandWidth : %d kHz\n", setCell.tCellCfgPara[loop].carrBandWidth);
        BspLog(LOG_LEVEL_0,"%s{ulSwitchFlag 0x%x, radioMode 0x%x,carrPow %d mW,carrbankNco %d kHz,carrbandNco %d kHz,carrBandWidth %d kHz} \n",__FUNCTION__,\
                setCell.tCellCfgPara[loop].ulSwitchFlag,setCell.tCellCfgPara[loop].radioMode,setCell.tCellCfgPara[loop].carrPow,setCell.tCellCfgPara[loop].bankNco,\
                setCell.tCellCfgPara[loop].bandNco,setCell.tCellCfgPara[loop].carrBandWidth);
    }

    return DpdMsgSetUlCellCfg(ulDifChnl, bandId, &setCell);
}
/*****************************************************************************
 *  函数名称   : BspDpdSetDmimoCtrl(*)
 *  功能描述   : 给DSP发送0x0018消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetDmimoCtrl(UINT32 chan,UINT32 bandId,UINT32 sw)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdDmmCtrlMsg ctrlMsg = {0};

    memset(&ctrlMsg, 0, sizeof(T_DpdDmmCtrlMsg));

    if (chan >= BspGetTxChanNum())
    {
        dbgErr("%s>>Para Error (chan %d is out of range %d)!\n",
               __FUNCTION__, chan, BspGetTxChanNum() - 1);
        return BSP_ERROR_INVALID_PARA;
    }

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ctrlMsg.uiDmmCtrlSwi  = sw;

    DpdPrint(LOG_INFO,"BspChnl'%d DifChnl'%d: ctrlMsg.uiDmmCtrlSwi = 0x%02X\n",
             chan, ulDifChnl, ctrlMsg.uiDmmCtrlSwi );
    return DpdMsgSendDmimoCtrl(ulDifChnl, bandId, &ctrlMsg);
}

/*****************************************************************************
 *  函数名称   : BspDpdSetDmmCfgMsg(*)
 *  功能描述   : 给DSP发送0x0203消息--DMIMO配置下发消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
//ysssss
UINT32 BspDpdSetDmmCfgMsg(UINT32 chan, UINT32 bandId,UINT32 CarrId,UINT32 RadioMode,UINT32 sw)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DmmCfgMsg cfgMsg = {0};
    UINT32 cpId     = 0;
    UINT32 dmimoL2dAddr = 0;
    UINT32 cellIndex = 0;
    UINT32 uiPuiBankId = 0;
    UINT32 uiDlPreOriDly = 0;

    zte_memset_s(&cfgMsg, sizeof(T_DmmCfgMsg), 0, sizeof(T_DmmCfgMsg));

    if (chan >= BspGetTxChanNum())
    {
        dbgErr("%s>>Para Error (chan %d is out of range %d)!\n",
               __FUNCTION__, chan, BspGetTxChanNum() - 1);
        return BSP_ERROR_INVALID_PARA;
    }

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    cfgMsg.uiCarrDmimoSwi  = sw;
    cfgMsg.uiCarrId = CarrId;

    BspHalAdaptGetDmimoMasterCpId(CarrId, RadioMode, &cpId);
    cfgMsg.uiCpId  = cpId;

    BspHalAdaptGetPsyncL2dSymbolAddr(chan, CarrId, RadioMode, TX, &dmimoL2dAddr);
    cfgMsg.uiDmimoL2dAddr = dmimoL2dAddr;

    BspHalAdaptGetTxDuc0BankId(chan,CarrId,RadioMode, &uiPuiBankId);
    cfgMsg.uiDlPreBankId = uiPuiBankId;

    BspHalAdaptGetDlCarrCompDly(chan,CarrId,RadioMode,&uiDlPreOriDly);
    cfgMsg.uiDlPreOriDly = uiDlPreOriDly;

    BspHalAdaptGetCellIndex(chan,CarrId,RadioMode, TX, &cellIndex);
    cfgMsg.uiCellId = (UINT16)cellIndex;
    
    dbgInfo("%s >>cfgMsg.uiCarrDmimoSwi =%d, cfgMsg.uiCarrId = %d cfgMsg.uiCpId = %d,cfgMsg.uiDmimoL2dAddr = 0x%x,cfgMsg.uiDlPreBankId = %d,cfgMsg.uiCellId = %d ,cfgMsg.uiDlPreOriDly = %d \n",
    __FUNCTION__,cfgMsg.uiCarrDmimoSwi,cfgMsg.uiCarrId,cfgMsg.uiCpId,cfgMsg.uiDmimoL2dAddr,cfgMsg.uiDlPreBankId,cfgMsg.uiCellId,cfgMsg.uiDlPreOriDly);
    BspLog(LOG_LEVEL_0,"%s >>cfgMsg.uiCarrDmimoSwi =%d,cfgMsg.uiCarrId = %d cfgMsg.uiCpId = %d,cfgMsg.uiDmimoL2dAddr = 0x%x,cfgMsg.uiDlPreBankId = %d,cfgMsg.uiCellId = %d ,cfgMsg.uiDlPreOriDly = %d\n",
    __FUNCTION__,cfgMsg.uiCarrDmimoSwi,cfgMsg.uiCarrId,cfgMsg.uiCpId,cfgMsg.uiDmimoL2dAddr,cfgMsg.uiDlPreBankId,cfgMsg.uiCellId,cfgMsg.uiDlPreOriDly);

    DpdPrint(LOG_INFO,"cfgMsg.uiCarrId = %d: cfgMsg.uiCarrDmimoSwi = %d\n",
            cfgMsg.uiCarrId , cfgMsg.uiCarrDmimoSwi);

    return DpdMsgSendDmmCfg(chan, bandId,&cfgMsg);
}

/*****************************************************************************
 *  函数名称   : BspDpdSetDmmCfgMsg(*)
 *  功能描述   : 给DSP发送0x0204消息--UTDOA的校准周期和周期内偏移
 *  输入参数   : chan：bsp通道号 bandId：频段号 , 目前通道和bandId用不到，因为所有载波、通道的校准周期和周期内偏移是一样的
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
/* Started by AICoder, pid:i43919b43cvc4a8147080a30b001821177765341 */
UINT32 BspDpdSetUtdoaCfgMsg(UINT32 chan, UINT32 bandId, UINT32 calibPeriodValue, UINT32 offset, UINT32 utEn)
{
    T_UtdoaCfgMsg cfgMsg = {0};

    zte_memset_s(&cfgMsg, sizeof(T_UtdoaCfgMsg), 0, sizeof(T_UtdoaCfgMsg));

    cfgMsg.caliPeriod  = calibPeriodValue;
    cfgMsg.offset = offset;
    cfgMsg.utEn = utEn;

    dbgInfo("%s >>cfgMsg.caliPeriod =%d,cfgMsg.offset = %d \n",__FUNCTION__,cfgMsg.caliPeriod, cfgMsg.offset);
    BspLog(LOG_LEVEL_0,"%s >>cfgMsg.caliPeriod =%d,cfgMsg.offset = %d\n",__FUNCTION__,cfgMsg.caliPeriod, cfgMsg.offset);
    DpdPrint(LOG_INFO,"cfgMsg.caliPeriod = %d: cfgMsg.offset = %d\n",cfgMsg.caliPeriod, cfgMsg.offset);

    return DpdMsgSendUtdoaCfg(chan, bandId,&cfgMsg);
}
/* Ended by AICoder, pid:i43919b43cvc4a8147080a30b001821177765341 */



/*****************************************************************************
 *  函数名称   : BspDpdSetDmmCfgClrFlg(*)
 *  功能描述   : 给DSP发送0x0202消息 --控制DMIMO配置信息清零的消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetDmmCfgClrFlg(UINT32 sw)
{
    T_DmmCfgInfoClrMsg ctrlMsg = {0};

    zte_memset_s(&ctrlMsg, sizeof(T_DmmCfgInfoClrMsg), 0, sizeof(T_DmmCfgInfoClrMsg));

    UINT32 ulRetVal = BSP_OK;
    ctrlMsg.uiDmmCfgClrFlg = sw;

    ulRetVal = DpdSetDmmCfgClrFlg(&ctrlMsg);

    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>DpdSetDmmCfgClrFlg Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("%s >> uiDmmCfgClrFlg = %d \n",__FUNCTION__,ctrlMsg.uiDmmCfgClrFlg);
    BspLog(LOG_LEVEL_0,"%s >> uiDmmCfgClrFlg = %d \n",__FUNCTION__,ctrlMsg.uiDmmCfgClrFlg);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspDpdSetPowAdjInfo(*)
 *  功能描述   : 给DSP发送功率调整信息 0x4007消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : APP调用，动态调压
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetPowAdjInfo(UINT32 chan,UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgSendPowAdjInfo sendPowAdjInfo = {0};

    memset(&sendPowAdjInfo, 0, sizeof(T_DpdMsgSendPowAdjInfo));

    if (chan >= BspGetTxChanNum())
    {
        dbgErr("%s>>Para Error (chan %d is out of range %d)!\n",
               __FUNCTION__, chan, BspGetTxChanNum() - 1);
        return BSP_ERROR_INVALID_PARA;
    }

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if (PowAdjCnt[chan] == 0xffffffff)
    {
        PowAdjCnt[chan] = 0;
    }
    else
    {
        PowAdjCnt[chan]++;
    }
    sendPowAdjInfo.powAdjCnt  = PowAdjCnt[chan];

    DpdPrint(PM_DEBUG,"BspChnl'%d DifChnl'%d: PowAdjCnt= 0x%02X\n",
             chan, ulDifChnl, sendPowAdjInfo.powAdjCnt);
    return DpdMsgSendPowAdjInfo(ulDifChnl, bandId, &sendPowAdjInfo);
}
/*****************************************************************************
 *  函数名称   : BspDpdMsgSetFrameSlotCfg(*)
 *  功能描述   : 给DSP发送帧结构配置信息 0x4010
 *  输入参数   : slotIndex  - GP最多的S时隙下标
                gpNum      - GP个数
 *  输出参数   :
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *---------------------------------------------------------------------------- */
UINT32 BspDpdMsgSetFrameSlotCfg(UINT32 slotIndex, UINT32 gpNum)
{
    UINT32 chan  = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 freqNo = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DpdGetDifInfoByBspChnl Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    BspLog(LOG_LEVEL_0,"%s slotIndex %d, gpNum %d\n",__FUNCTION__,slotIndex,gpNum);
    return DpdMsgSetFrameSlotCfg(ulDifChnl, freqNo, slotIndex, gpNum);
}
/*****************************************************************************
 *  函数名称   : BspCellDataDpd(*)
 *  功能描述   : 给DSP发送灵活配置TS的信息，即4016消息
 *  输入参数   : chan:通道号；cellDataDsp：高层下发的小区配置消息
 *  输出参数   :
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 注意，这里目前只有TDD机型使用，同时考虑了nco在MTS中的场景 APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 创建
 *----------------------------------------------------------------------------*/
UINT32 BspCellDataDpd(UINT32 chan, T_CellDataDsp *cellDataDsp)
{
    UINT32 loop = 0;
    UINT32 cellNum = 0;
    UINT32 freqNo = 0;
    T_DpdMsgCellTsInfo cellTsInfo = {0};
    UINT32 dflStartFreq = 0;
    UINT32 dflEndFreq = 0;
    UINT32 dir = TX;
    UINT32 retVal = 0;
    UINT32 difChan = 0;
    UINT32 chipId = 0;
    UINT32 bspChan = 0;
    T_FreqCarrNcoInfo carrNcoInfo = {0};
    T_DifCfgSave* pSaveCfg = NULL;
    T_DifSamRateCommPara *p_dbgDifSamratePara = NULL;

    INPUT_POINTER_CHECK(cellDataDsp);

    retVal = BspGetBspChnByRfChn(chan, dir, &bspChan) ;
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>chan'%d BspGetBspChnByRfChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    retVal = BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    cellNum = cellDataDsp->cellNum;
    BspLog(LOG_LEVEL_0,"%s cellDataDsp->cellNum %d\n",__FUNCTION__,cellDataDsp->cellNum);
    cellTsInfo.cellNum = cellNum;

    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_SAMRATE);
    INPUT_POINTER_CHECK(pSaveCfg);
    p_dbgDifSamratePara = (T_DifSamRateCommPara *)(pSaveCfg->pAddr);
    INPUT_POINTER_CHECK(p_dbgDifSamratePara);
    cellTsInfo.dpdTxRate = p_dbgDifSamratePara->uiDpdSamRate[difChan];
    cellTsInfo.dpdFbRate = p_dbgDifSamratePara->uiCbAdcSamRate[0];
    dbgInfoEx("%s:cellTsInfo.dpdTxRate %d\n",__FUNCTION__,cellTsInfo.dpdTxRate);
    dbgInfoEx("%s:cellTsInfo.dpdFbRate %d\n",__FUNCTION__,cellTsInfo.dpdFbRate);

    cellTsInfo.txLo = BspGetLoFreqChanged(TX,chan);
    cellTsInfo.fbLo = BspGetLoFreqChanged(TX,chan);
    dbgInfoEx("%s:cellTsInfo.txLo %d\n",__FUNCTION__,cellTsInfo.txLo);

    retVal = BspAdpGetDflFreqValue(0, 0, 0, 0, dir, START_FREQ_FLAG, &dflStartFreq);
    if(BSP_OK != retVal)
    {
        dflStartFreq = 0;
    }
    retVal = BspAdpGetDflFreqValue(0, 0, 0, 0, dir, END_FREQ_FLAG, &dflEndFreq);
    if(BSP_OK != retVal)
    {
        dflEndFreq = 0;
    }
    cellTsInfo.dflStartFreq = dflStartFreq;
    cellTsInfo.dflEndFreq = dflEndFreq;


    for(loop = 0; loop < cellNum; loop++)
    {
        cellTsInfo.cellTsData[loop].carrNo = cellDataDsp->cellData[loop].carrNo;
        cellTsInfo.cellTsData[loop].cellId = cellDataDsp->cellData[loop].cellId;
        cellTsInfo.cellTsData[loop].radioMode = cellDataDsp->cellData[loop].radioMode;
        cellTsInfo.cellTsData[loop].txFreq = cellDataDsp->cellData[loop].txFreq;
        cellTsInfo.cellTsData[loop].rxFreq = cellDataDsp->cellData[loop].rxFreq;
        cellTsInfo.cellTsData[loop].txBandWitdh = cellDataDsp->cellData[loop].txBandWitdh;
        cellTsInfo.cellTsData[loop].rxBandWitdh = cellDataDsp->cellData[loop].rxBandWitdh;
        cellTsInfo.cellTsData[loop].cfgCarrPwr = cellDataDsp->cellData[loop].cfgCarrPwr;
        BspLog(LOG_LEVEL_0,"carrNo%d cellId %d radioMode%d txFreq%d  rxFreq%d txBandWitdh%d rxBandWitdh%d cfgCarrPwr%d\n",\
        		cellDataDsp->cellData[loop].carrNo,cellDataDsp->cellData[loop].cellId,cellDataDsp->cellData[loop].radioMode, \
				cellDataDsp->cellData[loop].txFreq,cellDataDsp->cellData[loop].rxFreq,cellDataDsp->cellData[loop].txBandWitdh, \
				cellDataDsp->cellData[loop].rxBandWitdh,cellDataDsp->cellData[loop].cfgCarrPwr);
        retVal = BspGetCarrNcoInfo(bspChan,TX,cellDataDsp->cellData[loop].carrNo,cellDataDsp->cellData[loop].radioMode,&carrNcoInfo);
        if(retVal != BSP_OK)
        {
            dbgErr("%s>>chan'%d carrNo'%d radio'%d get carr nco info fail!\n", __FUNCTION__, chan,
                    cellDataDsp->cellData[loop].carrNo,cellDataDsp->cellData[loop].radioMode);
            return BSP_ERROR;
        }
        cellTsInfo.cellTsData[loop].bandNco = carrNcoInfo.bandNco;
        cellTsInfo.cellTsData[loop].carrNco = carrNcoInfo.carrNco;   //KHz
        cellTsInfo.cellTsData[loop].tranNco = carrNcoInfo.tranNco;
        cellTsInfo.cellTsData[loop].fbNco = carrNcoInfo.fbNco;
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].carrNo %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].carrNo);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].cellId %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].cellId);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].radioMode %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].radioMode);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].txFreq %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].txFreq);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].txBandWitdh %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].txBandWitdh);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].cfgCarrPwr %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].cfgCarrPwr);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].bandNco %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].bandNco);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].carrNco %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].carrNco);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].tranNco %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].tranNco);
        dbgInfoEx("%s:cellTsInfo.cellTsData[%d].fbNco %d\n",__FUNCTION__,loop, cellTsInfo.cellTsData[loop].fbNco);
    }

    return DpdMsgSendTsInfo(difChan, freqNo, &cellTsInfo);
}
/*****************************************************************************
 *  函数名称   : BspGetPaStaByPaFactorId(*)
 *  功能描述   : 获取功放类型(厂家)信息，组合到资产信息里，下发给dsp
 *  输入参数   : ulSubFileNo：PaBasicInfo.txt文件序号
 *  输出参数   : paSta：功放类型信息
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 4.0新增，从Pa离线参数文件PaBasicInfo.txt解析中获取paFactoryId值，4.2待确认
 *              4.2如果仍然需要，考虑将此接口放到校准表或者rruinfo.c中
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------*/
UINT32 BspGetPaStaByPaFactorId(UINT32 ulSubFileNo, UINT32 *paSta)
{
    UCHAR paFactoryId[TBL_PA_BASIC_INFO_PA_FACTORY_ID] = {0};
    UINT32 loop = 0;
    UINT32 startlocal = 0xffff;
    UINT32 stoplocal = 0xffff;
    UINT32 cnt = 0;
    UINT32 patype = 0;
    UINT32 coef = 0;
    BspGetPaFactoryId(ulSubFileNo,TBL_PA_BASIC_INFO_PA_FACTORY_ID,paFactoryId);
    dbgInfoEx("ulPaFactoryId :%s\n",paFactoryId);
    for(loop  = 0; loop < TBL_PA_BASIC_INFO_PA_FACTORY_ID; loop++)
    {
        if(paFactoryId[loop] == '_')
        {
            startlocal = loop + 1;
        }
        if(paFactoryId[loop] == '\0')
        {
            stoplocal = loop;
            break;
        }
    }
    dbgInfoEx("startlocal = %d stoplocal = %d\n",startlocal,stoplocal);
    if((startlocal != 0xffff) && (stoplocal != 0xffff))
    {
        cnt = stoplocal - startlocal;
    }
    dbgInfoEx("cnt = %d\n",cnt);
    if(cnt == 0)
    {
        return BSP_ERROR;
    }
    for(loop = startlocal; loop < stoplocal; loop++)
    {
        coef = cnt - (loop - startlocal) -1;
        patype += ((UINT8)(paFactoryId[loop]-'0'))*pow(10,coef);
    }
    dbgInfoEx("patype = %d\n",patype);
    *paSta = patype;
    return BSP_OK;
}

static void CopyDifRoute2MsgRoute(T_BspHalAdaptDspRouter *difRoute, T_MsgDspRoute *msgRoute)
{
    UINT32 i = 0;
    UINT32 maxCnt = 0;

    INPUT_POINTER_CHECK_RETURN(difRoute);
    INPUT_POINTER_CHECK_RETURN(msgRoute);

    maxCnt = min(NELEMENTS(difRoute->uiCfrPort), NELEMENTS(msgRoute->uiCfrPort));
    for (i = 0; i < maxCnt; i++)
    {
        msgRoute->uiCfrPort[i]          = difRoute->uiCfrPort[i];
        msgRoute->uiCfrBlockInPort[i]   = difRoute->uiCfrBlockInPort[i];
        msgRoute->uiDpdPort[i]          = difRoute->uiDpdPort[i];
        msgRoute->uiDlpostPort[i]       = difRoute->uiDlpostPort[i];
    }
    msgRoute->uiCfrPortNum              = difRoute->uiCfrPortNum;
    msgRoute->uiCfrBlockInPortNum       = difRoute->uiCfrBlockInPortNum;
    msgRoute->uiDpdPortNum              = difRoute->uiDpdPortNum;
    msgRoute->uiDlpostPortNum           = difRoute->uiDlpostPortNum;
    msgRoute->uiFbPort                  = difRoute->uiFbPort;
    msgRoute->uiCfrSampRate             = difRoute->uiCfrSampRate;
    msgRoute->uiSrc2SampRate            = difRoute->uiSrc2SampRate;
    msgRoute->uiSrc3SampRate            = difRoute->uiSrc3SampRate;
    msgRoute->uiFb204cSampRate          = difRoute->uiFb204cSampRate;
    msgRoute->uiDpdMode                 = difRoute->uiDpdMode;
    msgRoute->uiEtMode                  = difRoute->uiEtMode;
    msgRoute->uiCfrBlockPortNum         = difRoute->uiCfrBlockPortNum;
    msgRoute->uiStagePortNum            = difRoute->uiStagePortNum;
    msgRoute->uiStageId                 = difRoute->uiStageId;
    msgRoute->uiCfrGrade                = difRoute->uiCfrGrade;
}

/* Started by AICoder, pid:6779cp47acf80ba149cb0903e03ff2279c139421 */
static UINT32 BspTxParaDifChanCheck(T_BspHalAdaptDifTxRoutePara *pPara, UINT32 *loopEx, UINT32 linkNum, UINT32 ulDifChnl)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pPara);
    INPUT_POINTER_CHECK(loopEx);

    for(loop = 0; loop < linkNum; loop++)
    {
        if(pPara[loop].uiDifChan == ulDifChnl)
        {
            break;
        }
    }

    if(linkNum == loop)
    {
        pPara[loop].uiTddMode = 0xf;  /* 没取到给个异常值 */
    }

    *loopEx = loop;
    return BSP_OK;
}
/* Ended by AICoder, pid:6779cp47acf80ba149cb0903e03ff2279c139421 */
/* Started by AICoder, pid:y7499rc09bx1e4c14f550943f03b27242ba61faa */
static UINT32 BspDpdFbParaSet(T_DpdMsgSendRruInfo *pSendRruInfo)
{
    UINT32 loop = 0;
    UINT32 index = 0;

    INPUT_POINTER_CHECK(pSendRruInfo);

    pSendRruInfo->tFbCtrlInfo.fbCtrlTypeNum = g_FbCtrlInfo.fbCtrlTypeNum;
    for(loop  = 0; loop < pSendRruInfo->tFbCtrlInfo.fbCtrlTypeNum; loop++)
    {
        pSendRruInfo->tFbCtrlInfo.fb2DlMsk[loop] = g_FbCtrlInfo.fb2DlMsk[loop];
        pSendRruInfo->tFbCtrlInfo.fbCtrlSliceNum[loop] = g_FbCtrlInfo.fbCtrlSliceNum[loop];
        DpdPrint(PM_DEBUG,"fb2DlMsk : 0x%x fbCtrlSliceNum %d\n", pSendRruInfo->tFbCtrlInfo.fb2DlMsk[loop], pSendRruInfo->tFbCtrlInfo.fbCtrlSliceNum[loop]);
        for(index = 0; index < pSendRruInfo->tFbCtrlInfo.fbCtrlSliceNum[loop]; index++)
        {
            if(g_FbCtrlInfo.fbCtrlInfo[loop][index] == 0)
            {
                break;  /* 只传一个通道的 */
            }
            pSendRruInfo->tFbCtrlInfo.fbCtrlInfo[loop][index] = g_FbCtrlInfo.fbCtrlInfo[loop][index];
            DpdPrint(PM_DEBUG,"fbCtrlInfo : 0x%x\n",  pSendRruInfo->tFbCtrlInfo.fbCtrlInfo[loop][index]);
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:y7499rc09bx1e4c14f550943f03b27242ba61faa */
/*****************************************************************************
 *  函数名称   : BspDpdSetRruInfo(*)
 *  功能描述   : 给DSP发送整机硬件配置信息 0x4006消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   :
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetRruInfo(UINT32 chan,UINT32 bandId)
{
    UINT32 fullPower = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 paType = 0;
    T_DpdMsgSendRruInfo *pSendRruInfo = NULL;
    T_RruRfModuleInfoNew  tRfModuleInfo = {0};
    T_BspHalAdaptDspRouter tDspRouteInfo = {0};
    UINT32 bandNum = 0;
    UINT32 index = 0;
    UINT32 tddNo = 0;
    UINT32 chanMask = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    T_BspHalAdaptDifClkPara *p_dbgDifClkPara = NULL;
    T_DifCfgSave* pSaveCfgEx = NULL;
    T_BspHalAdaptDifTxRoutePara* pPara = NULL;
    UINT32 portType = 0;
    UINT32 loopEx = 0;
    UINT32 linkNum = 0;
    UINT32 portSta = 0;
    UINT32 portId = 0;

    pSendRruInfo = (T_DpdMsgSendRruInfo *)malloc(sizeof(T_DpdMsgSendRruInfo));
    INPUT_POINTER_CHECK(pSendRruInfo);

    ulRetVal = BspGetPaStaByPaFactorId(0,&paType);
    if(ulRetVal != BSP_OK)
    {
        dbgInfoEx("%s get pafactorId error! ret = %d\n",__FUNCTION__,ulRetVal);
        paType = 0;
    }
    /*整机级信息*/
    pSendRruInfo->validDlChanNum = BspGetTxBspChanNum();
    pSendRruInfo->validUlChanNum = BspGetRxBspChanNum();
    pSendRruInfo->paType       = paType;
    pSendRruInfo->moduleGrpId  = BspGetModuleGroupId();
    pSendRruInfo->boardGrpId   =  BspGetBoardGroupId();
    pSendRruInfo->boardTypeId  = BspGetBoardTypeId();
    pSendRruInfo->hwChangeId   = BspGetHardwareChangeId();
    pSendRruInfo->hwDefIdA     = BspGetHardwareCustomId_A();
    pSendRruInfo->hwDefIdB     = BspGetHardwareCustomId_B();
    pSendRruInfo->exceptReason   = BspGetTsQueryExceptInfo(0);
    pSendRruInfo->exceptChanMask   = BspGetTsQueryExceptInfo(1);
    pSendRruInfo->rfBridgeFlag = BspGetRfBridgeSupportFlag();
    DpdPrint(PM_DEBUG,"paType     : %d\n",   pSendRruInfo->paType);
    DpdPrint(PM_DEBUG,"moduleGrpId: 0x%x\n", pSendRruInfo->moduleGrpId);
    DpdPrint(PM_DEBUG,"boardGrpId : 0x%x\n", pSendRruInfo->boardGrpId);
    DpdPrint(PM_DEBUG,"boardTypeId: 0x%x\n", pSendRruInfo->boardTypeId);
    DpdPrint(PM_DEBUG,"hwChangeId : 0x%x\n", pSendRruInfo->hwChangeId);

    pSaveCfgEx = GetDifCfgSave(E_DIF_ROUTEPARA_TX);
    if (NULL == pSaveCfgEx)
    {
        free(pSendRruInfo);
        dbgErr("[%s][%d] Input Pointer is NULL!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    pPara = (T_BspHalAdaptDifTxRoutePara*)pSaveCfgEx->pAddr;
    if (NULL == pPara)
    {
        free(pSendRruInfo);
        dbgErr("[%s][%d] Input Pointer is NULL!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    linkNum = pSaveCfgEx->difChNum;
    for(loop  = 0; loop < BspGetTxBspChanNum(); loop++)
    {
        /*通道级信息-TX*/
        BspGetRruPathRatedPower(loop, &fullPower);
        BspAdpGetBoardFreqValue(loop,0,TX,FREQ_BAND_NUM,&bandNum);
        BspGetRruRfModuleInfoNew(loop, &tRfModuleInfo);
        chanMask = BIT_SET(loop);
        tddNo = BspGetTddCfgIdByChanMask(chanMask);
        ulRetVal = DpdGetDifInfoByBspChnl(loop, TX, &ulChipId, &ulDifChnl);
        if ((BSP_OK != ulRetVal)||(ulDifChnl >= IC_CHAN_NUM_MAX))
        {
            free(pSendRruInfo);
            dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, loop);
            return BSP_ERROR;
        }
        pSendRruInfo->dlChanHwInfo[ulDifChnl].fullPow    = fullPower;
        pSendRruInfo->dlChanHwInfo[ulDifChnl].bandNum    =  bandNum;
        for(index = 0; index < bandNum; index++)
        {
            pSendRruInfo->dlChanHwInfo[ulDifChnl].txDflFreqL[index] = tRfModuleInfo.ulRuTxStartFreq[index];/*注意一下，单位是kHz*/
            pSendRruInfo->dlChanHwInfo[ulDifChnl].txDflFreqH[index] = tRfModuleInfo.ulRuTxEndFreq[index];
            DpdPrint(PM_DEBUG,"txDflFreqL : %d kHz\n", pSendRruInfo->dlChanHwInfo[ulDifChnl].txDflFreqL[index]);
            DpdPrint(PM_DEBUG,"txDflFreqH : %d kHz\n", pSendRruInfo->dlChanHwInfo[ulDifChnl].txDflFreqH[index]);
        }

        pSendRruInfo->dlChanHwInfo[ulDifChnl].tddNo = tddNo;
        DpdPrint(PM_DEBUG,"ulDifChnl: %d tddNo: %d \n",ulDifChnl, pSendRruInfo->dlChanHwInfo[ulDifChnl].tddNo);
        DpdPrint(PM_DEBUG,"fullPow    : %d mW\n", pSendRruInfo->dlChanHwInfo[ulDifChnl].fullPow);
        /*路由信息*/
        BspHalAdaptGetDspRouteInfo(ulDifChnl,bandId,&tDspRouteInfo);
        CopyDifRoute2MsgRoute(&tDspRouteInfo, &pSendRruInfo->dspDlRouteInfo[ulDifChnl]);
        BspGetPortIdByBspChn(loop, TX, &portId);
        /*实际只有9124 需要*/
        (VOID)BspGetSlavePortCfgTpye(portId,&portType);
        (VOID)BspGetSlavePortCfgSta(portId,&portSta);
        DpdPrint(PM_DEBUG,"loop %d portId %d portType %d portSta %d\n",loop, portId,portType,portSta);
        pSendRruInfo->dspDlRouteInfo[ulDifChnl].uiPortType   = (portSta<<4)|portType;
        (VOID)BspTxParaDifChanCheck(pPara, &loopEx, linkNum, ulDifChnl);
        pSendRruInfo->dspDlRouteInfo[ulDifChnl].uiDflType    = pPara[loopEx].uiTddMode;
        DpdPrint(PM_DEBUG,"uiPortType: 0x%x uiDflType %d\n", portType,pPara[loopEx].uiTddMode);
    }
    for(loop  = 0; loop < BspGetRxBspChanNum(); loop++)
    {
        /*通道级信息-RX*/
        BspGetRruRfModuleInfoNew(loop, &tRfModuleInfo);
        BspAdpGetBoardFreqValue(loop,0,RX,FREQ_BAND_NUM,&bandNum);
        ulRetVal = DpdGetDifInfoByBspChnl(loop, RX, &ulChipId, &ulDifChnl);
        if ((BSP_OK != ulRetVal)||(ulDifChnl >= IC_CHAN_NUM_MAX))
        {
            free(pSendRruInfo);
            dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, loop);
            return BSP_ERROR;
        }
        pSendRruInfo->ulChanHwInfo[ulDifChnl].bandNum    =  bandNum; /*收发可能频段不一样*/
        for(index = 0; index < bandNum;index++)
        {
            pSendRruInfo->ulChanHwInfo[ulDifChnl].rxDflFreqL[index] = tRfModuleInfo.ulRuRxStartFreq[index];/*注意一下，单位是kHz*/
            pSendRruInfo->ulChanHwInfo[ulDifChnl].rxDflFreqH[index] = tRfModuleInfo.ulRuRxEndFreq[index];
            DpdPrint(PM_DEBUG,"rxDflFreqL : %d kHz\n", pSendRruInfo->ulChanHwInfo[ulDifChnl].rxDflFreqL[index]);
            DpdPrint(PM_DEBUG,"rxDflFreqH : %d kHz\n", pSendRruInfo->ulChanHwInfo[ulDifChnl].rxDflFreqH[index]);
        }
    }
    (VOID)BspDpdFbParaSet(pSendRruInfo);
    pSaveCfg = GetDifCfgSave(E_DIF_DIFPARA_CLK);
    if (NULL == pSaveCfg)
    {
        free(pSendRruInfo);
        dbgErr("[%s][%d] Input Pointer is NULL!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    p_dbgDifClkPara = (T_BspHalAdaptDifClkPara *)(pSaveCfg->pAddr);
    if (NULL == p_dbgDifClkPara)
    {
        free(pSendRruInfo);
        dbgErr("[%s][%d] Input Pointer is NULL!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    pSendRruInfo->tDlClkInfo.cfrClk[0] = p_dbgDifClkPara->uiDlCfrClk;
    pSendRruInfo->tDlClkInfo.dpdClk[0] = p_dbgDifClkPara->uiDlDpdClk;  /*logic3-0*/
    pSendRruInfo->tDlClkInfo.dpdClk[1] = p_dbgDifClkPara->uiDlPimcClk;  /*logic3-1*/
    pSendRruInfo->tDlClkInfo.dlpostClk[0] = p_dbgDifClkPara->uiDlPostClk[0];
    pSendRruInfo->tDlClkInfo.dlpostClk[1] = p_dbgDifClkPara->uiDlPostClk[1];
    DpdPrint(PM_DEBUG,"cfrClk: %d\n", pSendRruInfo->tDlClkInfo.cfrClk[0]);
    DpdPrint(PM_DEBUG,"dpdClk0: %d\n", pSendRruInfo->tDlClkInfo.dpdClk[0]);
    DpdPrint(PM_DEBUG,"dpdClk1: %d\n", pSendRruInfo->tDlClkInfo.dpdClk[1]);
    DpdPrint(PM_DEBUG,"dlpostClk0 : %d\n", pSendRruInfo->tDlClkInfo.dlpostClk[0]);
    DpdPrint(PM_DEBUG,"dlpostClk1 : %d\n", pSendRruInfo->tDlClkInfo.dlpostClk[1]);

    ulDifChnl = 0;
    ulRetVal = DpdMsgSendRruInfo(ulDifChnl, bandId, pSendRruInfo);
    free(pSendRruInfo);

    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspDpdUpdateRruInfo
 *  功能描述   : 更新给DSP发送的整机硬件配置信息
 *  输入参数   : exceptType ：异常类型 0正常 1-204 2-光口 exceptMask： 预留
 *  输出参数   : 无
 *  返 回 值   : BSP_OK -- 成功; 其他 -- 失败
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdUpdateRruInfo(UINT32 exceptType,UINT32 exceptMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 chan = 0;
    UINT32 bandId = 0;
    UINT32 tmpMask = 0;
    UINT32 txChan = 0;

    dbgInfoEx("exceptType %d exceptMask %d\n",exceptType,exceptMask);
    BspLog(LOG_LEVEL_0,"exceptType %d exceptMask %d\n",exceptType,exceptMask);
    txChan = BspGetTxChannel();
    if(exceptType != 0)  /*非正常时 先底层写死掩码*/
    {
         tmpMask = BIT_SET(txChan)-1;
    }
    retVal |= BspSetTsQueryExceptInfo(exceptType,tmpMask);
    retVal |= BspDpdSetRruInfo(chan, bandId);
    retVal |= BspSetTsQueryExceptInfo(0,0);

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspDpdSetRruInfo(*)
 *  功能描述   : 给DSP发送功放配置信息 类型、生产时间 0x4011消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : BspInitDpd调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *---------------------------------------------------------------------------- */
UINT32 BspDpdSetPaInfo(UINT32 chan,UINT32 bandId)
{
    T_DpdMsgSendPaInfo sendPaInfo = {0};
    T_HwInfo *ptInfo = BspGetGlobalRruHwInfo();
    TPaBasicInfoCaliData *pCali = _BspGetPaBasicInfoCalibData(0);

    memset(&sendPaInfo, 0, sizeof(T_DpdMsgSendPaInfo));

    memcpy_s(sendPaInfo.ruProductTime,SEND_PA_INFO_LEN-1,ptInfo->RruInfo.aucProductTime,SEND_PA_INFO_LEN-1);
    sendPaInfo.ruProductTime[SEND_PA_INFO_LEN-1] = '\0';

    if(NULL != pCali)
    {
        memcpy_s(sendPaInfo.paDesign, SEND_PA_INFO_LEN-1, pCali->atBasicInfoPath[chan].aucPaDesign, SEND_PA_INFO_LEN-1);
        sendPaInfo.paDesign[SEND_PA_INFO_LEN-1] = '\0';
    }
    else
    {
        sendPaInfo.paDesign[0] = '\0';
    }
    DpdPrint(PM_DEBUG,"paDesign      : %s\n", sendPaInfo.paDesign);
    DpdPrint(PM_DEBUG,"ruProductTime : %s\n", sendPaInfo.ruProductTime);

    return DpdMsgSendPaInfo(chan, bandId, &sendPaInfo);
}

/*****************************************************************************
 *  函数名称   : BspDpdSetFwdParam(*)
 *  功能描述   : 给DSP发送整机反馈补偿信息
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetFwdParam(UINT32 chan,UINT32 bandId)
{
    UINT32 ulLoop  = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChn = 0;
    T_DpdMsgSendFwdParam sendFwdParam = {0};
    TTxFwdCaliData *ptTxFwdData=NULL;
    UINT32 ulFreqStep = 0;
    UINT32 ulRecordNum = 0;
    UINT32 ulStartFreq = 0;
    T_FreqRecord *ptFreqTable=NULL;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChn);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    TBL_CHAN_VALID_CHECK(chan);
    memset(&sendFwdParam, 0, sizeof(T_DpdMsgSendFwdParam));

    ptTxFwdData = (TTxFwdCaliData *)_BspGetCalibData(TBL_KIND_OF_TxFWD,0);
    _TXFWDFILE_RF_LOADED_CHECK(ptTxFwdData, chan);
    ulFreqStep = ptTxFwdData->atTxFwdCaliPath[chan].tHeader.aulRfStep[bandId];
    ptFreqTable = ptTxFwdData->atTxFwdCaliPath[chan].patRfRecord[bandId];
    ulRecordNum = ptTxFwdData->atTxFwdCaliPath[chan].aulRfRecordNum[bandId];
    ulStartFreq = ptTxFwdData->atTxFwdCaliPath[chan].tHeader.aulStartFreq[bandId];

    sendFwdParam.startFreq = ulStartFreq;
    sendFwdParam.freqStep  = ulFreqStep;
    sendFwdParam.freqNum   = ulRecordNum;
    sendFwdParam.bandId  = bandId;
    sendFwdParam.reserve1  = 0;
    dbgInfoEx("ulStartFreq = %d ulFreqStep = %d ulRecordNum = %d \n",sendFwdParam.startFreq,sendFwdParam.freqStep,sendFwdParam.freqNum);
    if(ulRecordNum >= SEND_PARAM_POINT_NUM)
    {
        return BSP_ERROR;
    }
    for(ulLoop = 0; ulLoop < ulRecordNum; ulLoop++)
    {
        sendFwdParam.gainComp[ulLoop] = ptFreqTable[ulLoop].lCompVal;
        dbgInfoEx("ulLoop = %d, sendFwdParam.gainComp[ulLoop] = %d\n",ulLoop,sendFwdParam.gainComp[ulLoop]);
    }
    return DpdMsgSendFwdParam(ulDifChn, bandId, &sendFwdParam);
}

/*****************************************************************************
 *  函数名称   : BspDpdSetFilterParam(*)
 *  功能描述   : 给DSP发送整机双工补偿信息
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetFilterParam(UINT32 chan,UINT32 bandId)
{
    UINT32 ulLoop  = 0;
    T_DpdMsgSendFilterParam sendFilterParam = {0};
    TFilterGainCaliData * pFilterData = NULL;
    UINT32 ulFreqStep = 0;
    UINT32 ulRecordNum = 0;
    UINT32 ulStartFreq = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChn = 0;
    T_FreqRecord *ptFreqTable=NULL;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChn);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    TBL_CHAN_VALID_CHECK(chan);
    memset(&sendFilterParam, 0, sizeof(T_DpdMsgSendFilterParam));

    pFilterData = _BspGetFilterGainCalibData(0);
    INPUT_POINTER_CHECK(pFilterData);
    FILTERGAIN_LOADED_CHECK(pFilterData,chan);

    ulFreqStep = pFilterData->atPath[chan].tHeader.aulRfStep[bandId];
    ptFreqTable = pFilterData->atPath[chan].patRecord[bandId];
    ulRecordNum = pFilterData->atPath[chan].aulRecordNum[bandId];
    ulStartFreq = pFilterData->atPath[chan].tHeader.aulStartFreq[bandId];

    sendFilterParam.startFreq = ulStartFreq;
    sendFilterParam.freqStep  = ulFreqStep;
    sendFilterParam.freqNum   = ulRecordNum;
    sendFilterParam.bandId  = bandId;
    sendFilterParam.reserve1  = 0;
    dbgInfoEx("ulStartFreq = %d ulFreqStep = %d ulRecordNum = %d \n",sendFilterParam.startFreq,sendFilterParam.freqStep,sendFilterParam.freqNum);
    if(ulRecordNum >= SEND_PARAM_POINT_NUM)
    {
        return BSP_ERROR;
    }
    for(ulLoop = 0; ulLoop < ulRecordNum; ulLoop++)
    {
        sendFilterParam.gainComp[ulLoop] = ptFreqTable[ulLoop].lCompVal;
        dbgInfoEx("ulLoop = %d, sendFilterParam.gainComp[ulLoop] = %d\n",ulLoop,sendFilterParam.gainComp[ulLoop]);
    }
    return DpdMsgSendFilterParam(ulDifChn, bandId, &sendFilterParam);
}

/************************************7 维测(版本、状态检测、EVM ACP 下表等)*******************************************/
/*****************************************************************************
 *  函数名称   : DpdUdpGetDspVer(*)
 *  功能描述   : 获取DSP版本号（ac或者dsp版本获取） 0x8002
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulUdpHeadTypeId - 3: HEAD_TYPE_ID_NXP_ACDSP, 0: HEAD_TYPE_ID_SOC_DSP chipId:芯片号
 *             len: 字符串长度
 *  输出参数   : pDspVer：版本信息
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 DpdUdpGetDspVer(UINT32 ulUdpHeadTypeId, UINT32 chipId, UINT8 *pDspVer, UINT32 len)
{
    UINT32 ulRetVal = BSP_OK;
    enum HEAD_TYPE eTmpHeadTypeId = HEAD_TYPE_ID_SOC_DSP;

    eTmpHeadTypeId = ulUdpHeadTypeId;
    if (HEAD_TYPE_ID_SOC_DSP == eTmpHeadTypeId)
    {
        ulRetVal = DpdMsgGetVer(chipId, pDspVer, len);
    }
    else
    {
        ulRetVal = DpdMsgGetVerAcDsp(chipId, pDspVer, len);
    }

    /* DpdAccessSemGive(semIdDpdAccess); */
    return ulRetVal;
}

UINT32 BspGetDspVer(UINT32 chipId, UINT8 *pDspVer, UINT32 len)
{
    return DpdUdpGetDspVer(HEAD_TYPE_ID_SOC_DSP, chipId, pDspVer, len);
}

UINT32 BspGetDspAcVer(UINT32 chipId, UINT8 *pDspVer, UINT32 len)
{
    return DpdUdpGetDspVer(HEAD_TYPE_ID_NXP_ACDSP, chipId, pDspVer, len);
}

/**************************************************************************
* 函数名称: BspGetDpdStatus(*)
* 功能描述: 查询dsp状态 0x8005消息
* 输入参数: chan   - 通道号
* 输出参数: status - DPD状态
* 返 回 值: bit为1表示有告警，bit为0表示正常
           bit7 - DSP工作异常告警
           其他 - 预留
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 BspGetDpdStatus(UINT32 chan, UINT32 *status)
{
    UINT32 wdtCnt = 0;
    UINT32 almCode = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    static UINT32 wdtCntHis = 0;
    UINT32 freqNo = 0;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgGetDog(ulDifChnl, freqNo, &wdtCnt);
	if (ulRetVal != BSP_OK)
	{
        if (NULL != status)
        {
            *status |= BIT_SET(7);
        }
        else
        {
            dbgErr("%s>>Error! Input Pointer Is NULL; WdtCnt= %d, Status= 0x%02lX\n",
                   __FUNCTION__, wdtCnt, BIT_SET(7));
            return ERROR_NULL_POINTER;
        }
		return BSP_ERROR;
	}
    (wdtCntHis != wdtCnt) ? (wdtCntHis = wdtCnt) : (almCode |= BIT_SET(7));
    if(almCode != 0)
    {
        if (NULL != status)
        {
            *status = almCode;
        }
        else
        {
            dbgErr("%s>>Error! Input Pointer Is NULL! WdtCnt= %d, AlmCode= 0x%02X\n",
                   __FUNCTION__, wdtCnt, almCode);
            return ERROR_NULL_POINTER;
        }
    	return BSP_ERROR;
    }
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspGetDpdFixDlyStat(*)
 *  功能描述   : 获取dpd固定时延状态  0x800b
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan     - bsp通道号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 完成; 否则未完成
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetDpdFixDlyStat(UINT32 chan)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
	T_DpdMsgStateQueryRet tAck = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

	ulRetVal = DpdMsgGetState(ulDifChnl, 0, &tAck);
	if (BSP_OK == ulRetVal)
	{
		ulRetVal = BSP_ERROR;
		if (FIX_DLY_FINISH == tAck.iFixDlySta)
		{
			ulRetVal = BSP_OK;
		}
	}
	return ulRetVal;
}
/*****************************************************************************
 *  函数名称   : BspGetAcpCalResult(*)
 *  功能描述   : 获取acp计算结果   0x8015消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan     - 通道号
 *  输出参数   : pAcpCalResult: acp计算结果
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : AAU机型使用，RRU暂时无，待进一步确认
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetAcpCalResult(UINT32 chan, T_DpdMsgAcpCalResultAck *pAcpCalResult)
{

    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    return DpdMsgGetAcpCalResult(chan, pAcpCalResult);
}
/*****************************************************************************
 *  函数名称   : BspGetDpdLutDowmNum(*)
 *  功能描述   : 获取dpd下表次数 0x800b消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan     - 通道号
 *  输出参数   : pNum     - 下表张数
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 仅T+F 高层使用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetDpdLutDowmNum(UINT32 chan, INT32 *pNum)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
	T_DpdMsgStateQueryRet tAck = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

	ulRetVal = DpdMsgGetState(ulDifChnl, 0, &tAck);
	if (NULL != pNum)
	{
        if (BSP_OK == ulRetVal)
        {
            *pNum = tAck.iDownLutCnt;
        }
        else
        {
            *pNum = 0;
        }
	}

	return ulRetVal;
}
/*****************************************************************************
 *  函数名称   : BspDownloadDpdTable(*)
 *  功能描述   : 下载hostIp 的文件 fileName 内容到dsp中dpd表格中 0xc005
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : pSem     - 信号量指针
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDownloadDpdTable(UINT32 chan,TUdpApiHeader *headInfo,UINT8 *hostIP, char *fileName)
{
    UCHAR *pBuf = NULL;
    UINT32 bufSize = 6*1024*1024;
    UINT32 filelen = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(hostIP);
    INPUT_POINTER_CHECK(fileName);

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    pBuf = (UCHAR *)malloc(bufSize);
    if(NULL == pBuf)
    {
        DpdPrint(PM_ERROR,"%s malloc failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset(pBuf,0,bufSize);

    DpdPrint(PM_INFO,"tftp get file success\n");
    if (BSP_OK != BspLoadFile(fileName,(CHAR *)pBuf,&filelen))
    {
        DpdPrint(PM_ERROR,"%s BspLoadFile failed\n",__FUNCTION__);
        free(pBuf);
        return BSP_ERROR;
    }
    DpdPrint(PM_INFO,"tftp get file filelen is %d\n",filelen);

    ulRetVal = DpdMsgDownloadData(ulDifChnl, headInfo, pBuf, &filelen);

    free(pBuf);
    return ulRetVal;
}

/*****************************************************************************
*  函数名称   : BspDownloadDpdTableNew
*  功能描述   : 读取文件 fileName 内容
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chan - 通道号
*          headInfo - 消息头信息
*          fileName - 文件名
*  输出参数   : 无
*  返 回 值 : BSP_OK 或 BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XX@2023-05-15
*----------------------------------------------------------------------------
*/
UINT32 BspDownloadDpdTableNew(UINT32 chan, TUdpApiHeader *headInfo, const char *fileName)
{
    UINT32 ulOffset = 0;
    UINT32 ulChipId = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBufSize = 4*1025;
    UINT32 ulDataSize = 4*1038;
    UINT32 ulRetVal = BSP_OK;
    UCHAR *pBuf = NULL;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(headInfo);
    INPUT_POINTER_CHECK(fileName);    

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    pBuf = (UCHAR *)malloc(ulBufSize);
    if(NULL == pBuf)
    {
        DpdPrint(PM_ERROR,"%s malloc failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s(pBuf, ulBufSize, 0, ulBufSize);

    DpdPrint(PM_INFO, "get file success\n");
    ulOffset = ulDifChnl * ulDataSize;
    if (BSP_OK != BspLoadFileNew(fileName, (CHAR *)pBuf, ulOffset, ulBufSize))
    {
        DpdPrint(PM_ERROR, "%s BspLoadFile failed\n", __FUNCTION__);
        free(pBuf);
        return BSP_ERROR;
    }
    DpdPrint(PM_INFO, "get file bufSize is %d, chan%d the first data = 0x%x, the second data = 0x%x\n", ulBufSize, ulDifChnl, *pBuf + (*(pBuf + 1) << 8) + (*(pBuf + 2) << 16) + (*(pBuf + 3) << 24), *(pBuf + 4));

    ulRetVal = DpdMsgDownloadDataNew(ulDifChnl, headInfo, pBuf, ulBufSize);

    free(pBuf);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspUploadDpdTable(*)
 *  功能描述   : 上传dsp 中的表格数据到 hostIp 的文件 fileName 中  0xc003消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : typeId: 待确认 chan：bsp通道号 bandId：频段号 type：数据类型(定点、浮点等)
 *              hostIP: rru ip filename: 数据文件名
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspUploadDpdTable(UINT32 typeId,UINT32 chan,UINT32 bandId,UINT32 type,const char *hostIP,const char *fileName)
{
    UCHAR *pBuf = NULL;
    UINT32 bufSize = 6*1024*1024;
    UINT32 datalen = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(hostIP);
    INPUT_POINTER_CHECK(fileName);

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    pBuf = (UCHAR *)malloc(bufSize);
    if (NULL == pBuf)
    {
        DpdPrint(PM_ERROR,"%s malloc failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset(pBuf,0,bufSize);

    ulRetVal = DpdMsgUploadData(typeId, ulDifChnl, bandId, type, pBuf, &datalen);
    if (BSP_OK == ulRetVal)
    {
        /*create file,copy data*/
        if (BSP_OK != BspWriteFile((const char *)pBuf,datalen,fileName))
        {
            DpdPrint(PM_ERROR,"%s BspWriteFile failed datalen is %d\n",__FUNCTION__,datalen);
            free(pBuf);
            return BSP_ERROR;
        }
        /*upload file*/
        if (BSP_OK == BspTftp(fileName, hostIP, "-p"))
        {
            DpdPrint(PM_INFO,"tftp put file success\n");
            ulRetVal = BSP_OK;
        }
        else
        {
            DpdPrint(PM_ERROR,"%s tftp put file failed\n",__FUNCTION__);
            ulRetVal = BSP_ERROR;
        }
    }
    else
    {
        DpdPrint(PM_ERROR,"%s DpdMsg UploadData error!\n", __FUNCTION__);
    }

    free(pBuf);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspSampleDpdData(*)
 *  功能描述   : 上传dsp 中的采样数据到 hostIp 的文件 fileName 中
 *              0xc001:采数启动停止 0xc002:采数状态获取 0xc003上传数据
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : typeId: 待确认 chan：bsp通道号 bandId：频段号 type：数据类型(定点、浮点等)
 *              hostIP: rru ip filename: 数据文件名 flag、pos具体含义待确认
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 内部维测使用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspSampleDpdData(UINT32 typeId, UINT32 chan, UINT32 bandId, UINT8 *pBuf, UINT32 *pBufLen,
                                        UINT32 flag, UINT32 pos, const char *hostIP, const char *fileName)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgSampleCtrl samFlag;
    UINT32 statSample = 0;
    INT32 cnt = s_SampleCnt;
    UINT16 type = 1;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pBuf);
    INPUT_POINTER_CHECK(pBufLen);
    INPUT_POINTER_CHECK(hostIP);
    INPUT_POINTER_CHECK(fileName);

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    samFlag.OffLineSampFlg = flag;
    samFlag.OffLinePos = pos;
    ulRetVal = DpdMsgSampleCtrl(typeId, ulDifChnl, bandId, 1, &samFlag);
    if (BSP_OK != ulRetVal)
    {
        DpdPrint(PM_ERROR,"%s DpdMsgSampleCtrl failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    while(cnt--)
    {
        if( BSP_OK != DpdMsgGetSamStatus(typeId, ulDifChnl, bandId, &statSample))
        {
            DpdPrint(PM_ERROR,"%s DpdMsgGetSamStatus failed\n",__FUNCTION__);
            return BSP_ERROR;
        }
        if(0x01 == statSample) /*get the experted the status then will finish*/
        {
            break;
        }
        else
        {
            DpdPrint(PM_INFO,"sample is not complete!\n");
        }
        BspSysMsDelay(1000);
    }

    if(cnt<=0)
    {
        DpdPrint(PM_ERROR,"%s sample timeout!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    DpdPrint(PM_INFO,"start upload the data!\n");
    if (BSP_OK != DpdMsgUploadData(typeId, ulDifChnl, bandId, type, pBuf, pBufLen))
    {
        DpdPrint(PM_ERROR,"%s DpdMsg UploadData Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgSampleCtrl(typeId, ulDifChnl, bandId, 0, &samFlag);
    return ulRetVal;
}

/*****************************************************************************
 *  函数名称   : BspDpdicCatchDspData(*)
 *  功能描述   : 全链路采数 dsp采数的启动与停止
 *              消息号0x1E00
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan:中频通道号 sw:开关与停止采数 0x5A5A-使能，0x2D2D-禁用 
 *               radioMode:制式 slotNo:slot号 pointNo:采数point编号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdicCatchDspData(UINT32 sw, UINT32 difChan, UINT32 pointNo)
{
    UINT32 retVal                      = BSP_OK;
    T_MaintainSmpCtrlMsg catchDataInfo = {0};

    catchDataInfo.uiSmpPoint = pointNo;
    catchDataInfo.uiSmpSwi   = sw;
    catchDataInfo.uiDifChn   = difChan;

    retVal = DpdMsgCatachDspLinkData(&catchDataInfo);

    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s  failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspDpdicCatchDspData(*)
 *  功能描述   : 全链路采数 dsp采数的状态
 *              消息号0x1E01
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdicGetCatchDspDataStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 status = 0;
    INT32 result  = 0;

    retVal = DpdMsgGetCatchDspLinkDataResult(&status, &result);

    if (BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0,"%s  failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

/*没执行完和执行失败都上报失败*/
    if((BSP_OK != status) || (BSP_OK != result))
    {
        retVal = BSP_ERROR;
        BspLog(LOG_LEVEL_0,"%s  failed status = %d, result = %d\n",__FUNCTION__, status, result);
    }

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspDpdicCatchDspData(*)
 *  功能描述   : 获取dsp dpd开关状态
 *              消息号0x0033 通道启停状态查询,0x5a5a:开启，0x2d2d：关闭
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetDpdSwitch(UINT32 chan)
{
    UINT32 retVal    = BSP_OK;
    UINT32 dpdSwitch = 0;
    INT32 result     = 0;
    UINT32 chipId    = 0;
    UINT32 difChn    = 0;

    DPD_CHAN_CHECK(chan);

    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChn);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    } 

    retVal = DpdMsgGetDpdSwitch(&dpdSwitch, &result, difChn);

    if ((BSP_OK != retVal) || (BSP_OK != result))
    {
        BspLog(LOG_LEVEL_0,"%s  failed,  retVal = %d, result = %d\n",__FUNCTION__, retVal, result);
        return BSP_ERROR;
    }

    retVal = dpdSwitch;
    BspLog(LOG_LEVEL_0,"%s  success, chan [%d] difchan [%d] switch = 0x%x\n",__FUNCTION__, chan, difChn, retVal);

    return retVal;
}

/************************************8 节能相关******************************************/
/*****************************************************************************
 *  函数名称   : BspSetDpdChanOff(*)
 *  功能描述   : 节能通知DPD关闭通道请求 0x0014
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chanmask:通道掩码，1关，0开
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspSetDpdChanOff(UINT32 chanmask)
{
    UINT32 retVal = BSP_OK;
    UINT32 bspChan = 0;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT32 difChan = 0;
    UINT32 bandId = 0;
    UINT32 ulChipId = 0;
    UINT32 chanbitmask = 0;
    UINT32 difChanMask = 0;
    UINT32 bspChanMask = chanmask;
    T_ChanOffRequest chanOffRequst = {0};

    for(bspChan = 0; bspChan < BspGetTxChanNum(); bspChan++)
    {
        retVal = DpdGetDifInfoByBspChnl(bspChan, TX, &ulChipId, &difChan);
        if (BSP_OK != retVal)
        {
            dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
            return BSP_ERROR;
        }
        chanbitmask = BIT_SET(bspChan);
        if(bspChanMask & chanbitmask)
        {
            //coverity[cert_int34_c_violation:SUPPRESS]
            difChanMask |= BIT_SET(difChan);
        }
    }
    chanOffRequst.chanmask = difChanMask;
    dbgInfo("[%s] bspchan off mask'%d, difchan off mask'%d \n",__FUNCTION__,bspChanMask,difChanMask);
    retVal = DpdMsgDspChanOffRequst(typeId,difChan,bandId,&chanOffRequst);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspSetDpdChanOff(*)
 *  功能描述   : 节能通知DPD关闭通道请求后，DPD关闭结果查询 0x8018
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : chanOffResult：1关闭成功，0关闭失败
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspDpdChanOffStaQuery(UINT32 *chanOffResult)
{
    UINT32 retVal = BSP_OK;
    UINT32 result = 0;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT32 difChan = 0;
    UINT32 bandId = 0;

    retVal = DpdMsgDspChanOffStaQuery(typeId,difChan,bandId,&result);
    if(retVal !=BSP_OK)
    {
        dbgErr("[%s] get dsp chan off result fail!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] get dsp chan off result:%d \n",__FUNCTION__,result);

    INPUT_POINTER_CHECK(chanOffResult);
    *chanOffResult = result;

    return retVal;
}
/*******************************************9 高层流程接口实现******************************************************/

/*****************************************************************************
 *  函数名称   : BspInitDpd(*)
 *  功能描述   : 给dsp下发小区信息 资产信息 功放信息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP使用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspInitDpd(UINT32 Chan,UINT32 bandId)
{
    UINT32 uRet = BSP_OK;
    UINT32 uRetTmp = BSP_OK;
    /*后续增加cellinfo 和 rruinfo的消息，暂时返回OK，5G目前使用*/
    uRetTmp = BspDpdSetRruInfo(Chan,bandId);
    if(BSP_OK != uRetTmp)
    {
        uRet = BSP_ERROR;
    }

    uRetTmp = BspDpdSetCellInfo(Chan,bandId);
    uRetTmp |= BspDpdSetRxCellInfo(Chan,bandId);
    uRetTmp |= BspDpdSetNcrGpInfo(Chan);
    (VOID)BspDpdSscLutDownload(Chan);
    if(BSP_OK != uRetTmp)
    {
        uRet = BSP_ERROR;
    }
    return uRet;
}
UINT32 BspResetDpd(UINT32 Chan,UINT32 bandId)
{
    return BSP_OK;
}
UINT32 BspRestartDpd(UINT32 chan,UINT32 bandId)
{
    return BSP_OK;
}
UINT32 BspTrainingDpd(UINT32 chan,UINT32 bandId)
{
    return BSP_OK;
}
UINT32 BspPauseDpd(UINT32 chan,UINT32 bandId)
{
    return BSP_OK;
}
UINT32 BspResumeDpd(UINT32 chan,UINT32 bandId)
{
    return BSP_OK;
}
UINT32 BspSetDpdSampChan(UINT32 chan,UINT32 bandId)
{
    /*dpdic机型使用，其他机型直接返回OK*/
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspNotifyAcOnToDpd(*)
 *  功能描述   : CPU通过该消息通知DSP AC校准是否启动
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspNotifyAcOnToDpd(UINT32 chan,UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgSetSignalPara startAc = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    startAc.index_modul = 0xB2;
    startAc.index_func  = 0x5A5A;

    return DpdMsgSetPara(ulDifChnl, bandId, &startAc);
}

/*****************************************************************************
 *  函数名称   : BspNotifyAcOffToDpd(*)
 *  功能描述   : CPU通过该消息通知DSP AC校准是否启动
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspNotifyAcOffToDpd(UINT32 chan,UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgSetSignalPara stopAc = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    stopAc.index_modul = 0xB2;
    stopAc.index_func  = 0x2D2D;

    return DpdMsgSetPara(ulDifChnl, bandId, &stopAc);
}

/********************************************************************************
*函数名  ：BspSetBoardPara
*函数作用：通过此接口兼容各规格的下发para的时候需要不需要带宽的差异。
*参数说明：uBoardPara 1,获取带宽信息; 0 不需要获取带宽信息
*         
********************************************************************************/
UINT32  BspSetBoardPara(UINT32 uBoardPara)
{
    sBoardPara = uBoardPara;
    return BSP_OK;	
}

/********************************************************************************
*函数名  ：BspSetBoardPara
*函数作用：通过此接口兼容各规格的下发para的时候需要不需要带宽的差异。
*参数说明：uBoardPara 1,获取带宽信息; 0 不需要获取带宽信息
*         
********************************************************************************/
UINT32 BspGetBoardPara(VOID)
{
    return sBoardPara ;	
}

/*ExReason: 0-正常 1-204异常重建链 2-光口异常切速率 */
UINT32 BspSetTsQueryExceptInfo(UINT32 exReason,UINT32 exMask)
{
    s_dpdTsExReason = exReason;
    s_dpdTsExMask = exMask;
    return BSP_OK;	
}

UINT32 BspGetTsQueryExceptInfo(UINT32 type)
{
    UINT32 retVal = 0;

    if(type == 0)
    {
        retVal = s_dpdTsExReason;
    }
    else
    {
        retVal = s_dpdTsExMask;
    }

    return retVal;
}

/*************************************************************************
 *  函数名称: BspSendAcParaMsg
 *  功能描述: A9815 发送AC 设置消息给DSP
 *  入参说明:
 *  返 回 值:  OK 消息正常回应； ERROR 消息异常
 *  其它说明:  高频接口
-------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 10065211@2018-3-12, 创建
-------------------------------------------------------------------------*/
UINT32 BspSendAcParaMsg(UINT32 mode) 
{
	UINT32 ulRet = 0;
	UINT32  ulFreqBw = 0;
      // DpdLog(LOG_INFO,"%s enter\n", __FUNCTION__);
        if(sBoardPara == 1)
        {        
            ulFreqBw = BspGetCarrCfgBw();
            
            if((ulFreqBw != 100000)&&(ulFreqBw != 200000)&&(ulFreqBw != 400000))
            {
                 dpdBwMsgFlag = BSP_ERROR;
                return BSP_ERROR;
            }
        }
    if(sBoardPara == 1)
    {
	    ulRet |=  setdpdpara(0, 0xa0, ulFreqBw/1000,0,0,0,0,0,0,0);  /* 与DSP 同事沟通，chan 等于0即可 */
	}
    else
    {
         ulRet |=  setdpdpara(0, 0, 0xa0, ulFreqBw/1000,0,0,0,0,0,0);  /* 与DSP 同事沟通，chan 等于0即可 */
    }
	
       dpdBwMsgFlag = ulRet;
	dbgInfoEx("\n%s, finish!!\n",__FUNCTION__);
	//DpdLog(LOG_INFO,"%s retVal = 0x%x\n", __FUNCTION__,ulRet);
	return ulRet;
}

UINT32 BspGetAcGetBwStatus(VOID)
{
    return dpdBwMsgFlag;
}

VOID  BspSetAcSetBwStatus(UINT32 udpdBwMsgFlag)
{
     dpdBwMsgFlag = udpdBwMsgFlag;
}

/*********************************10 pim*****************************************/

/*****************************************************************************
 *  函数名称   : BspGetDpdPimState(*)
 *  功能描述   : 获取dpd固定时延状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan     - 通道号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 完成; 否则未完成
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetDpdPimState(UINT32 chan,UINT32 freqNo)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    UINT32 loopEx = 0;
    UINT32 difchan = 0;
    UINT32 chipId  = 0;
    T_DpdMsgPimDpdStateQueryAck pimDdpState = {0};

    ret = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difchan);
    if (BSP_OK != ret)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    for(loopEx = 0; loopEx < 10; loopEx++)
    {
        ret = DpdMsgPimDpdStateQuery(difchan,freqNo,&pimDdpState);
        DpdPrint(PM_DEBUG,"ret %d ,chan %d state %d  result %d\n",ret, pimDdpState.chan, pimDdpState.state,pimDdpState.result);
        for(loop = 0; loop < MSG_PIMOFF_ACP_NUM; loop++)
        {
            DpdPrint(PM_DEBUG," acps[%d] = %d\n", loop,pimDdpState.acps[loop]);
        }
        if((BSP_OK != ret)||(0 != pimDdpState.state)||(0 != pimDdpState.result))    /*消息报错 或者状态异常  或者结果不正常*/
        {
            BspSysMsDelay(1000);
            continue;
        }
        break;
    }
    if(loopEx == 10)
    {
        return BSP_ERROR;
    }

	return BSP_OK;    /*udp正常 状态正常 结果正常*/
}
UINT32  BspDpdMsgPimDpdStart(UINT32 chan)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    DpdPrint(PM_DEBUG,"%s >>> APP calling chn[%d] BspDpdMsgPimDpdStart!\n",__FUNCTION__,chan);//加入高层调用的打印
    return DpdMsgStartCtrlPim(ulDifChnl,0);
}

/*****************************************************************************
 *  函数名称   : BspStartPtsLmsStart(*)
 *  功能描述   : dpd 启动 0x0015消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspStartPtsLmsStart(VOID)
{
    return DpdPtsLmsStartCtrl(DPD_START);
}

/**************************************************************************
    函数名 称： BspGetPtsLmsSta(*)
    功能 描述： 0x8019消息--定时查询PTS LMS迭代状态
    输入参数 ： 无
    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 BspGetPtsLmsSta(T_DpdLmsStatusAck *lmsPtsStatus)
{
    return DpdGetPtsLmsStatus(lmsPtsStatus);
}

/**************************************************************************
    函数名 称： BspNoiseCheckStart(*)
    功能 描述： 0x0016消息--启动PIM_OnLine各通道躁低检测

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 BspNoiseCheckStart(UINT32 slotindex)
{
    return DpdNoiseCheckStartCtrl(slotindex);
}

/**************************************************************************
    函数名 称： BspGetNoiseCheckSta(*)
    功能 描述： 0x801a消息--查询躁低检测状态

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 BspGetNoiseCheckSta(T_DpdDpdNoiseStaAck *pimOnlineNoiseCheckSta)
{
    return DpdGetNoiseCheckStatus(pimOnlineNoiseCheckSta);
}

/**************************************************************************
    函数名 称： BspPimOnlineEnergyCalStart(*)
    功能 描述： 0x0017消息--PIM_OnLine启动
    输入参数 ：
    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 BspPimOnlineEnergyCalStart(T_DpdPimOnlineEnergyCalCtrl *pimOnlineEngCalCtrl)
{
    return DpdPimOnlineEnergyCalCtrl(pimOnlineEngCalCtrl);
}

/**************************************************************************
    函数名 称： BspGetPimOnlineCheckSta(*)
    功能 描述： 0x8017消息--PIM_OnLine检测查询状态

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 BspGetPimOnlineCheckSta(UINT32 *PimOnlineCheckSta)
{
    return DpdGetPimOnlineCheckSta(PimOnlineCheckSta);
}

VOID BspSetEnVironmentPimCalType(INT32 type)
{
    pimCheckType = type;
}

INT32 BspGetEnVironmentPimCalType(VOID)
{
    return pimCheckType;
}

/**************************************************************************
    函数名 称： BspGetPimOnlineChkResult(*)
    功能 描述： 0x0C01消息--PIM_OnLine检测结果上报

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
/* Started by AICoder, pid:e7d30m8c74w6d0214ff50975901724770820b741 */
UINT32 BspGetPimOnlineChkResult(T_DpdPimOnlineCheckResultAck *pimOnlineCheckRes)
{
    UINT32 retVal   = BSP_OK;
    INT32  checkType = 0;
    UINT32 rxChan = 0;
    UINT32 carrFreq  = 0;
    INT32  rssiGain = 0;
    UINT32 bandId = 0;
    UINT32 loop = 0;
    INT32 noise = 0;
    INT32 pimpower = 0;
    INT32 pimThreshold = -10550;
    T_DpdPimOnlineResultAck *checkRes = NULL;

    INPUT_POINTER_CHECK(pimOnlineCheckRes);

    checkRes = (T_DpdPimOnlineResultAck *)malloc(sizeof(T_DpdPimOnlineResultAck));
    if(NULL == checkRes)
    {
        dbgErr("%s>>checkRes, TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(checkRes, sizeof(T_DpdPimOnlineResultAck), 0, sizeof(T_DpdPimOnlineResultAck));
    for(rxChan = 0; rxChan < min(BspGetRxChannel(), MSG_DSP_CH_MAX); rxChan++)
    {
        retVal = DpdGetPimOnlineCheckRes(rxChan, checkRes);
        if(BSP_OK != retVal)
        {
            dbgErr("[%s]>>DpdGetPimOnlineCheckRes Get Error!\n", __FUNCTION__);
            free(checkRes);

            return retVal;
        }

        for(bandId = 0; bandId < MAX_BAND_NUM_PER_CHAN; bandId++)
        {
            pimOnlineCheckRes->pimpowerresut[rxChan][bandId].noise = checkRes->pimPowerReport[bandId].noise;
            pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimfreq = checkRes->pimPowerReport[bandId].pimfreq;
            pimOnlineCheckRes->pimpowerresut[rxChan][bandId].noisecalsta = checkRes->pimPowerReport[bandId].noisecalsta;
            pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimcheckType = checkRes->pimPowerReport[bandId].pimcheckType;

            carrFreq = pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimfreq;
            if(BSP_OK != BspGetRssiDbmCompGain(rxChan, 0, carrFreq, 0, &rssiGain, COMPS_BY_FREQ_POINT_TYPE))
            {
                dbgInfoEx("[%s]>> rxChan = %d, bandId = %d, carrFreq = %d\n", __FUNCTION__, rxChan, bandId, carrFreq);
                continue;
            }
            noise = pimOnlineCheckRes->pimpowerresut[rxChan][bandId].noise - rssiGain;
            pimOnlineCheckRes->pimpowerresut[rxChan][bandId].noise = (noise < pimThreshold) ? pimThreshold:noise;
            dbgInfoEx("[%s]>> rxChan = %d, bandId = %d, noise = %d, rssiGain = %d\n", __FUNCTION__, rxChan, bandId, noise, rssiGain);

            for(loop = 0; loop < MAX_PIM_ENGCAL_TYPE; loop++)
            {
                pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimpowermax[loop] = checkRes->pimPowerReport[bandId].pimpowermax[loop];
                pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimpower[loop] = checkRes->pimPowerReport[bandId].pimpower[loop];
                pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimpowercalsta[loop] = checkRes->pimPowerReport[bandId].pimpowercalsta[loop];

                pimpower = pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimpower[loop] - rssiGain;
                pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimpower[loop] = (pimpower < pimThreshold) ? pimThreshold:pimpower;
                dbgInfoEx("[%s]>> rxChan = %d, bandId = %d, loop = %d, pimpower = %d\n", __FUNCTION__, rxChan, bandId, loop, pimpower);
            }
            if(2 == checkRes->pimPowerReport[bandId].resSta)
            {
                pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimpower[0] = 10000;
                pimOnlineCheckRes->pimpowerresut[rxChan][bandId].pimpower[1] = 10000;
            }
        }
    }
    checkType = pimOnlineCheckRes->pimpowerresut[0][0].pimcheckType;  //与方案确定只取通道0，band0的pim检测类型即可，代表整机级。
    BspSetEnVironmentPimCalType(checkType);
    free(checkRes);

    return retVal;
}
/* Ended by AICoder, pid:e7d30m8c74w6d0214ff50975901724770820b741 */
/**************************************************************************
    函数名 称： BspGetPimOnlineRruInfo(*)
    功能 描述： 0x0C00消息--PIM_OnLine获取整机级硬件信息

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
/* Started by AICoder, pid:3cbb3bd5202b4b0145c308ebe0a890760f48103f */
UINT32 BspGetPimOnlineRruInfo(T_DpdPimOnlineHwRruInfo *PimOnlineRruInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 chanId = 0;
    UINT32 bandId = 0;
    UINT32 txLoop = 0;
    UINT32 rxLoop = 0;
    T_PimOnlineRruInfoMsg *rruCfgInfo = NULL;

    if(NULL == PimOnlineRruInfo)
    {
        dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    rruCfgInfo = (T_PimOnlineRruInfoMsg *)malloc(sizeof(T_PimOnlineRruInfoMsg));
    if(NULL == rruCfgInfo)
    {
        dbgErr("%s>>rruCfgInfo, TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(rruCfgInfo, sizeof(T_PimOnlineRruInfoMsg), 0, sizeof(T_PimOnlineRruInfoMsg));
    for(chipId = 0; chipId < min(PimOnlineRruInfo->chipNum, CHIP_NUM_MAX); chipId++)
    {
        rruCfgInfo->dlValidChNum += PimOnlineRruInfo->HwRruInfo[chipId].DlChnNum;
        rruCfgInfo->ulValidChNum += PimOnlineRruInfo->HwRruInfo[chipId].UlChnNum;
    }

    for(chipId = 0; chipId < min(PimOnlineRruInfo->chipNum, CHIP_NUM_MAX); chipId++)
    {
        for(chanId = 0; chanId < min(PimOnlineRruInfo->HwRruInfo[chipId].DlChnNum, MSG_DSP_CH_MAX); chanId++)
        {
            if(txLoop == PIMONLINE_RRU_MAX_CHAN_NUM)
            {
                dbgErr("[%s]Exceed the Max Tx Range\n", __FUNCTION__);
                free(rruCfgInfo);
                return BSP_ERROR;
            }
            rruCfgInfo->dlChInfo[txLoop].chipIdx = chipId;
            rruCfgInfo->dlChInfo[txLoop].chanId = chanId;
            rruCfgInfo->dlChInfo[txLoop].bandNum = PimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[chanId].BandNum;
            for(bandId = 0; bandId < min(PimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[chanId].BandNum, MAX_BAND_NUM_PER_CHAN); bandId++)
            {
                rruCfgInfo->dlChInfo[txLoop].txDflFreqL[bandId] = PimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[chanId].TxDflFreqL[bandId];
                rruCfgInfo->dlChInfo[txLoop].txDflFreqH[bandId] = PimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[chanId].TxDflFreqH[bandId];
            }
            txLoop++;
        }
    }

    for(chipId = 0; chipId < min(PimOnlineRruInfo->chipNum, CHIP_NUM_MAX); chipId++)
    {
        for(chanId = 0; chanId < min(PimOnlineRruInfo->HwRruInfo[chipId].UlChnNum, MSG_DSP_CH_MAX); chanId++)
        {
            if(rxLoop == PIMONLINE_RRU_MAX_CHAN_NUM)
            {
                dbgErr("[%s]Exceed the Max Rx Range\n", __FUNCTION__);
                free(rruCfgInfo);
                return BSP_ERROR;
            }
            rruCfgInfo->ulChInfo[rxLoop].chipIdx = chipId;
            rruCfgInfo->ulChInfo[rxLoop].chanId = chanId;
            rruCfgInfo->ulChInfo[rxLoop].bandNum = PimOnlineRruInfo->HwRruInfo[chipId].atHwUlChInfo[chanId].BandNum;
            for(bandId = 0; bandId < min(PimOnlineRruInfo->HwRruInfo[chipId].atHwUlChInfo[chanId].BandNum, MAX_BAND_NUM_PER_CHAN); bandId++)
            {
                rruCfgInfo->ulChInfo[rxLoop].rxDflFreqL[bandId] = PimOnlineRruInfo->HwRruInfo[chipId].atHwUlChInfo[chanId].RxDflFreqL[bandId];
                rruCfgInfo->ulChInfo[rxLoop].rxDflFreqH[bandId] = PimOnlineRruInfo->HwRruInfo[chipId].atHwUlChInfo[chanId].RxDflFreqH[bandId];
            }
            rxLoop++;
        }
    }
    retVal |= DpdPimOnlineRruInfoCfg(rruCfgInfo);
    free(rruCfgInfo);

    return retVal;
}
/* Ended by AICoder, pid:3cbb3bd5202b4b0145c308ebe0a890760f48103f */
/*****************************************************************************
 *  函数名称   : BspDpdSetPaStatus(*)
 *  功能描述   : 给DSP发送0x4027消息
 *  输入参数   : bspChan:bsp通道号 SW:功放状态
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : APP调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetPaStatus(UINT32 chan,UINT32 sw)
{
    UINT32 chipId  = 0;
    UINT32 difChnl = 0;
    UINT32 retVal = BSP_OK;
    T_ChanPaStaMsg paStatus = {0};

    DPD_CHAN_CHECK(chan);
    BspLog(LOG_LEVEL_0,"%s enter,chan=%d, sw=%d \n",  __FUNCTION__, chan, sw);

    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChnl);

    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if(sw >= PA_MAX_SWITCH) /*DSP 要求入参必须是0 1 0是关闭 1是打开*/
    {
      dbgInfo("%s bspChan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
      return BSP_ERROR;
    }

    paStatus.uiPaSta  = sw;

    DpdPrint(LOG_INFO,"BspChnl'%d DifChnl'%d: paStatus.uiPaSta = 0x%02X\n",
            chan, difChnl, paStatus.uiPaSta );

    return DpdMsgSendPaStatus(difChnl, &paStatus);
}

UINT32 BspSetMultFreqSrcCtrl(UINT32 bspChan, T_DpdMultFreqSrcCtrlMsg *para)
{
    UINT32 retVal = 0;
    UINT32 chipId  = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(para);
    DPD_CHAN_CHECK(bspChan);

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal = DpdMsgMultFreqSrcCtrl(difChan, para);
    return retVal;
}

UINT32 BspGetPwdCaliResult(UINT32 bspChan, T_DpdPwdCaliMsg *launchSta, T_PwdCaliResult *para)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId  = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(launchSta);
    INPUT_POINTER_CHECK(para);
    DPD_CHAN_CHECK(bspChan);

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal |= DpdGetPwdCaliResult(difChan, launchSta, para);
    return retVal;
}

/*一拖三机型子端标量驻波检测 dsp发源控制*/
UINT32 BspDpdSlaveScalarVswrCtrl(UINT32 bspChan, UINT32 sw)
{
    UINT32 ctrlType = SWITCH_OFF;
    UINT32 retVal = BSP_OK;
    UINT32 cnt = 0;
    T_DpdMultFreqSrcCtrlMsg srcCtrl = {0};
    T_DpdPwdCaliMsg tmpCtrl = {0};
    T_PwdCaliResult tmpCtrlAck = {0};

    dbgInfoEx("%s bspchan %d sw %d\n", __FUNCTION__, bspChan, sw);
    if(SWITCH_ON == sw)
    {
        ctrlType = 3;   /*标量驻波通知dsp发双工源*/
        retVal = BspDpdMsgPowCalChnSw(bspChan,1-sw);
        if(BSP_OK != retVal)
        {
            dbgErr("dsp PowCal Enable failed\n");
            return retVal;
        }
    }
    BspDpdMsgPowCalChnSw(bspChan,1-sw);  /*通知dsp关闭功率检测*/
    srcCtrl.txTaskType = ctrlType;
    retVal = BspSetMultFreqSrcCtrl(bspChan, &srcCtrl);
    if(BSP_OK != retVal)
    {
        dbgErr("dsp tsg ctrl start/stop udp failed\n");
        return retVal;
    }

    BspSysMsDelay(500);

    tmpCtrl.txTaskType = ctrlType;

    for(cnt = 10; cnt > 0; cnt--)
    {
        if (BSP_OK != BspGetPwdCaliResult(bspChan, &tmpCtrl, &tmpCtrlAck))
        {
            dbgErr("cnt= %d,type %d finish %d result %d\n", cnt, tmpCtrlAck.taskType, tmpCtrlAck.finish,tmpCtrlAck.result);
            return BSP_ERROR;
        }
        if((BSP_OK == tmpCtrlAck.finish) && (BSP_OK == tmpCtrlAck.result))
        {
            break;
        }
        else
        {
            BspSysMsDelay(500);
        }
    }

    if(0 >= cnt)
    {
        dbgErr("%s chn[%d] Get result timeout\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    dbgInfoEx("type %d finish %d result %d\n", tmpCtrlAck.taskType, tmpCtrlAck.finish, tmpCtrlAck.result);
    if(SWITCH_OFF == sw)
    {
        retVal = BspDpdMsgPowCalChnSw(bspChan,1-sw);
        if(BSP_OK != retVal)
        {
            dbgErr("dsp PowCal Enable failed\n");
            return retVal;
        }
    }

    if((BSP_OK == tmpCtrlAck.finish) && (BSP_OK == tmpCtrlAck.result))
    {
         return BSP_OK;
    }

    return BSP_ERROR;
}

/*给dsp下发各个通道是否处于电子开关强制模式*/
UINT32 BspDpdSendRfIoCtrlMode(VOID)
{
    T_DspMsgRfIoCtrlMode  para = {0};
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 difId = 0;
    UINT32 difChnl = 0;

    for(loop = 0; loop < BspGetTxChannel(); loop++)
    {
        retVal = BspGetDifInfoByBspChn(loop, TX, &difId, &difChnl);
        if(BSP_OK != retVal)
        {
            dbgErr("chan %d BspGetDifInfoByRfChn failed\n",loop);
            return BSP_ERROR;
        }
        para.ioCtrlMode[difChnl] = BspGetChCbSwCtrlMode(loop) ;  /*  用BSP通道获取 用中频通道给dsp填充*/
    }
    retVal = DpdMsgSendRfIoCtrlMode(0,&para);

    return retVal;
}
/*给DSP下发通道的数字功率及功率是否合法*/
UINT32 BspDpdSendChTssiInfo(T_TxAllChanPow *pChanPowInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    T_DspMsgChnTssiInfo para = {0};
    UINT32 difId = 0;
    UINT32 difChnl = 0;

    INPUT_POINTER_CHECK(pChanPowInfo);
    for(loop = 0; loop < BspGetTxChannel(); loop++)
    {
        retVal = BspGetDifInfoByBspChn(loop, TX, &difId, &difChnl);
        if(BSP_OK != retVal)
        {
            dbgErr("chan %d BspGetDifInfoByRfChn failed\n",loop);
            return BSP_ERROR;
        }
        para.vaildFlag[difChnl] = pChanPowInfo->tTxPow[loop].isPowValid;
        para.chanTssi[difChnl] = pChanPowInfo->tTxPow[loop].tFwdPow.ifTssiPow;
        dbgInfoEx("chan %d vaildFlag %d chanTssi %d\n",difChnl, para.vaildFlag[difChnl], para.chanTssi[difChnl]);
    }
    retVal = DpdMsgSendChTssiInfo(0,&para);
    return retVal;
}

/*从dsp获取子端的fwd和rev*/
UINT32 BspDpdGetChnPowInfo(T_TxAllChanPow *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 difId = 0;
    UINT32 difChnl = 0;
    T_DspMsgChnPowInfoAck tmpData = {0};
    UINT32 powCalCnt = 0;
    UINT32 powCalcWay = 0;

    INPUT_POINTER_CHECK(pdata);
    retVal =  DpdMsgGetChnPowInfo(difChnl, &tmpData);
    if(retVal != BSP_OK)
    {
        dbgErr("DpdMsgGetChnPowInfo failed\n");
        return retVal;
    }
    for(loop = 0; loop < BspGetTxChannel(); loop++)
    {
        retVal = BspGetDifInfoByBspChn(loop, TX, &difId, &difChnl);
        if((BSP_OK != retVal)||(loop >= BSP_IC42_MAX_TX_CHAN_NUM))
        {
            dbgErr("chan %d BspGetDifInfoByRfChn failed\n",loop);
            return BSP_ERROR;
        }
        powCalcWay = BspGetSpePowPowCalcWayByChan(loop);
        if(powCalcWay != POW_CALC_WAY_DSP)
        {
             g_ulSlaveChnPowInValidCnt[loop] = 0;    /*切换模式时及时清0  至于其他元素 此时不使用 用的是IC检的*/
             continue;
        }
        pdata->tTxPow[loop].tFwdPow.ifTssiPow = tmpData.chPowInfo[difChnl].txPow;
        pdata->tTxPow[loop].tFwdPow.fbPow = tmpData.chPowInfo[difChnl].fbPow;
        powCalCnt = tmpData.chPowInfo[difChnl].chPowCalCnt;
        if(g_ulSlaveChnPowLastCnt[loop] != powCalCnt)   /*和上一次不一样就认为功率正常更新*/
        {
            g_ulSlaveChnPowInValidCnt[loop] = 0;
        }
        else
        {
            g_ulSlaveChnPowInValidCnt[loop]++;
            if(g_ulSlaveChnPowInValidCnt[loop] > 0xffff)
            {
                g_ulSlaveChnPowInValidCnt[loop] = 0xffff;    /*避免溢出 正常不会到这 只要正常就清0 */
            }
        }
        g_ulSlaveChnPowLastCnt[loop] = powCalCnt;
        pdata->tTxPow[loop].isPowValid = 0x5a5a;
        if(g_ulSlaveChnPowInValidCnt[loop] >= 2)      /*连着两次都不更新 认为功率检测异常*/
        {
            pdata->tTxPow[loop].isPowValid = 0x2d2d;
            dbgInfoEx("bspchan %d powcalc failed validCnt %d\n",loop, g_ulSlaveChnPowInValidCnt[loop]);
        }
    }
    return retVal;
}

UINT32 getdsppow(void)
{
    T_TxAllChanPow data = {0};
    UINT32 retVal = BSP_OK;
    retVal = BspDpdGetChnPowInfo(&data);

    return retVal;
}

/* 根据上行的频点和载波号获取对应下行的papt频点 */
static UINT32 BspGetGsmTxPtsFreq(UINT32 chan, T_RruCarrCfgInfo *carrInfo, UINT32 *ptsFreq)
{
    T_GsmHopChanInfo *chanInfo = NULL;
    UINT32 carr = 0;
    UINT32 rxBand = 0;
    UINT32 txBand = 0;

    if (NULL == s_GsmHopChanInfo || chan >= BSP_MAX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    if (BspGetBandValByCenterFreq(0, RX, carrInfo->carrRxFreq, &rxBand) != BSP_OK)
    {
        return BSP_ERROR;
    }
    chanInfo = &s_GsmHopChanInfo[chan];
    for (carr = 0; carr < chanInfo->hopCnt; carr++)
    {
        if (BspGetBandValByCenterFreq(0, TX, chanInfo->hopCarr[carr]->ptsFreq, &txBand) != BSP_OK)
        {
            continue;
        }
        if (carrInfo->carrRxNo == chanInfo->hopCarr[carr]->carrNo && txBand == rxBand)
        {
            *ptsFreq = chanInfo->hopCarr[carr]->ptsFreq;
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

static INT32 BspGetBandDiff(UINT32 rxFreq)
{
    INT32 freqDiff = 0;
    UINT32 rxBand = 0;
    UINT32 retVal = 0;
    UINT32 bandStartFreq[PRX] = {0};
    UINT32 bandEndFreq[PRX] = {0};

    retVal = BspGetBandValByCenterFreq(0, RX, rxFreq, &rxBand);
    if (retVal != BSP_OK)
    {
        return freqDiff;
    }

    retVal  = BspGetBandFreqRangeByCenterFreq(TX, rxBand, &bandStartFreq[TX], &bandEndFreq[TX]);
    retVal |= BspGetBandFreqRangeByCenterFreq(RX, rxBand, &bandStartFreq[RX], &bandEndFreq[RX]);
    if (retVal != BSP_OK)
    {
        return freqDiff;
    }

    freqDiff = bandStartFreq[RX] - bandStartFreq[TX];

    return freqDiff;
}

static UINT32 BspGetNoGsmHopCarrFl(T_RruRfCfgInfo *rruCfgPara)
{
    UINT32 carr = 0;
    UINT32 flx = 0;
    UINT32 fl = UINT32_MAX;

    for (carr = 0; carr < rruCfgPara->txCfgCarrSum; carr++)
    {
        if (rruCfgPara->carr[carr].carrTxRadio == BSP_RADIO_STANDARD_GSM && rruCfgPara->carr[carr].carrTxBw > 0)
        {
            continue;
        }
        flx = rruCfgPara->carr[carr].carrTxFreq - (rruCfgPara->carr[carr].carrTxBw / 2);
        fl = min(flx, fl);
    }

    return fl;
}

static UINT32 BspGetMutiGsmHopPtsFreq(UINT32 chan, T_RruCarrCfgInfo *carrInfo)
{
    T_GsmHopChanInfo *chanInfo = NULL;
    UINT32 carr = 0;
    UINT32 ptsFreq = NULL;

    if (s_GsmHopChanInfo == NULL || chan >= BSP_MAX_CHAN_NUM)
    {
        return carrInfo->carrTxFreq;
    }
    chanInfo = &s_GsmHopChanInfo[chan];

    for (carr = 0; carr < chanInfo->gsmCarrCnt; carr++)
    {
        if (carrInfo->carrTxNo == chanInfo->carr[carr].carrNo)
        {
            break;
        }
    }

    /* 没有找到对应载波的信息 */
    if (carr == chanInfo->gsmCarrCnt)
    {
        ptsFreq = carrInfo->carrTxFreq;
    }
    else
    {
        ptsFreq = chanInfo->carr[carr].ptsFreq;
    }

    return ptsFreq;
}

/* Started by AICoder, pid:89cb0m0c6ao2fdc14cf2091d70ffcb258d31e22c */
UINT32 BspSetDiffGsmHopCarrFreq(UINT32 flag, UINT32 gsmNoHopCarrNum, UINT32 gsmNoHopFreq[], UINT32 gsmHopFreq)
{
    UINT32 loop = 0;

    while(1)
    {
        for(loop = 0; loop < gsmNoHopCarrNum; loop++)
        {
            dbgInfoEx("flag:%d,GsmNoHopFreq[%d]:%d,gsmHopFreq:%d\n", flag, loop, gsmNoHopFreq[loop], gsmHopFreq);
            if(gsmNoHopFreq[loop] == gsmHopFreq)
            {
                if(1 == flag)  //GSM跳频载波频点在右侧开始配置
                {
                    gsmHopFreq -=BANDWIDTH_0P2M;
                }
                else  //GSM跳频载波频点在左侧开始配置
                {
                    gsmHopFreq +=BANDWIDTH_0P2M;
                }
                break;
            }
        }
        if(gsmNoHopCarrNum == loop)
        {
            return gsmHopFreq;
        }
    }
}
/* Ended by AICoder, pid:89cb0m0c6ao2fdc14cf2091d70ffcb258d31e22c */

/* Started by AICoder, pid:vfa488b574q5f28146ae0b0c805c1e33b7c4236b */
/* 一个GSM跳频载波和非跳频GSM载波频点去重 */
UINT32 BspSetGsmHopCarrFreq(UINT32 flag, UINT32 gsmHopfreq, UINT32 fltFreq, UINT32 fhtFreq, T_RruRfCfgInfo *rruCfgPara)
{
    UINT32 gsmHopCarrFreq = 0;
    UINT32 carrNo = 0;
    UINT32 gsmNoHopCarrNum = 0;
    UINT32 carrNum = 0;
    UINT32 gsmNoHopFreqRecord[BSP_MAX_CARR_NUM] = {0};  /* GSM非跳频载波频点 */

    if(NULL == rruCfgPara)
    {
        dbgErr("[%s]rruCfgPara is NULL\n", __FUNCTION__);
        return gsmHopfreq;
    }

    carrNum = min(rruCfgPara->txCfgCarrSum, BSP_MAX_CARR_NUM);
    for (carrNo = 0; carrNo < carrNum; carrNo++)
    {
        if((BSP_RADIO_STANDARD_GSM == rruCfgPara->carr[carrNo].carrTxRadio) && (0 == rruCfgPara->carr[carrNo].carrTxBw))
        {
            gsmNoHopFreqRecord[gsmNoHopCarrNum] = rruCfgPara->carr[carrNo].carrTxFreq;
            gsmNoHopCarrNum++;
        }
    }

    gsmHopCarrFreq = BspSetDiffGsmHopCarrFreq(flag, gsmNoHopCarrNum, gsmNoHopFreqRecord, gsmHopfreq);
    if(gsmHopCarrFreq < fltFreq)
    {
        gsmHopCarrFreq = fltFreq;
    }
    else if(gsmHopCarrFreq > fhtFreq)
    {
        gsmHopCarrFreq = fhtFreq;
    }
    dbgInfoEx("flag:%d,fltFreq:%d,fhtFreq:%d,gsmHopCarrFreq:%d\n", flag, fltFreq, fhtFreq, gsmHopCarrFreq);

    return gsmHopCarrFreq;
}
/* Ended by AICoder, pid:vfa488b574q5f28146ae0b0c805c1e33b7c4236b */

UINT32 BspGetTxCarrFreq(UINT32 chan, UINT32 gsmHopNum, T_RruCarrCfgInfo *carrCfgInfo, T_RruRfCfgInfo *rruCfgPara)
{
    UINT32 freq = 0;
    UINT32 flag = 0;
    UINT32 fltFreq = 0;
    UINT32 fhtFreq = 0;
    UINT32 fl = 0;
    UINT32 carrNo = 0;
    UINT32 carrRadio = 0;
    T_GsmHopChanInfo *chanInfo = NULL;

    freq = carrCfgInfo->carrTxFreq;
    carrNo = carrCfgInfo->carrTxNo;
    carrRadio = carrCfgInfo->carrTxRadio;
    /* 当前载波不是GSM跳频载波, 返回配置频点 */
    if (carrCfgInfo->carrTxRadio != BSP_RADIO_STANDARD_GSM)
    {
        return BspGetFilterCarrNco(TX, chan, carrNo, carrRadio, (INT32)freq);
    }

    if (gsmHopNum == 1)
    {
        /* 当前载波不是跳频载波, 返回配置频点 */
        if (carrCfgInfo->carrTxBw == 0)
        {
            return freq;
        }

        fltFreq = carrCfgInfo->carrTxFreq - (carrCfgInfo->carrTxBw / 2);
        fhtFreq = carrCfgInfo->carrTxFreq + (carrCfgInfo->carrTxBw / 2);
        fl   = BspGetNoGsmHopCarrFl(rruCfgPara);
        /* 含有非G跳频载波并且GSM跳频和非G跳频载波重合 */
        if (rruCfgPara->txCfgCarrSum > 1 && fltFreq > fl)
        {
            flag = 1;
        }
        /* 不含非G载波或者和非G载波未重合 */
        if (flag == 0)
        {
            freq = fltFreq;
        }
        else
        {
            freq = fhtFreq;
        }
        freq = BspSetGsmHopCarrFreq(flag, freq, fltFreq, fhtFreq, rruCfgPara);

        if (chan >= BSP_MAX_CHAN_NUM)
        {
            return freq;
        }
        chanInfo = &s_GsmHopChanInfo[chan];
        chanInfo->hopCnt = 1;
        chanInfo->hopCarr[0] = &chanInfo->carr[0];
        chanInfo->hopCarr[0]->ptsFreq = freq;
        chanInfo->hopCarr[0]->carrNo = carrCfgInfo->carrTxNo;
    }
    else
    {
        freq = BspGetMutiGsmHopPtsFreq(chan, carrCfgInfo);
    }

    return freq;
}

UINT32 BspGetRxCarrFreq(UINT32 chan, T_RruCarrCfgInfo *curCarrInfo)
{
    UINT32 ptsFreq = 0;
    UINT32 txMaxChn = BspGetTxChannel();
    UINT32 retVal = 0;
    UINT32 txChn = 0;
    UINT32 carrNo = 0;
    UINT32 carrRadio = 0;

    ptsFreq = curCarrInfo->carrRxFreq;
    carrNo = curCarrInfo->carrRxNo;
    carrRadio = curCarrInfo->carrRxRadio;
    if (curCarrInfo->carrRxRadio != BSP_RADIO_STANDARD_GSM)
    {
        return BspGetFilterCarrNco(RX, chan, carrNo, carrRadio, (INT32)ptsFreq);;
    }

    /* 分集通道号转换成主集 */
    chan = chan % txMaxChn;

    /* 先在主集通道查找, 找不到的话(收发分离1T2R等)遍历所有发射通道 */
    retVal = BspGetGsmTxPtsFreq(chan, curCarrInfo, &ptsFreq);
    if (retVal != BSP_OK)
    {
        for (txChn = 0; txChn < txMaxChn; txChn++)
        {
            retVal = BspGetGsmTxPtsFreq(txChn, curCarrInfo, &ptsFreq);
            if (retVal == BSP_OK)
            {
                break;
            }
        }
    }
    /* 失败的时候使用上行配置载波 */
    if (retVal != BSP_OK)
    {
        return ptsFreq;
    }

    /* 根据上下行频段的差值,对下行频点加上差值就成为上行频点 */
    return ptsFreq + BspGetBandDiff(curCarrInfo->carrRxFreq);
}

/* 按照左边界对载波排序 */
static void GspHopInfoBubbleSort(T_GsmHopChanInfo *chanInfo)
{
    UINT32 i = 0;
    UINT32 j = 0;
    UINT32 sorted = 0;
    T_GsmHopInfo hopInfo = {0};

    INPUT_POINTER_CHECK_RETURN(chanInfo);
    for (i = 0; i < chanInfo->hopCnt; i++)
    {
        sorted = 1;
        for (j = 0; j < chanInfo->hopCnt - i - 1; j++)
        {
            if (chanInfo->hopInfo[j].fl > chanInfo->hopInfo[j + 1].fl)
            {
                memcpy_s(&hopInfo, sizeof(T_GsmHopInfo), &chanInfo->hopInfo[j], sizeof(T_GsmHopInfo));
                memcpy_s(&chanInfo->hopInfo[j], sizeof(T_GsmHopInfo), &chanInfo->hopInfo[j + 1], sizeof(T_GsmHopInfo));
                memcpy_s(&chanInfo->hopInfo[j + 1], sizeof(T_GsmHopInfo), &hopInfo, sizeof(T_GsmHopInfo));
                sorted = 0;
            }
        }
        if (1 == sorted)
        {
            break;
        }
    }
}

static void PrintGspHopInfo(const char *callerName, T_GsmHopInfo *hopInfo, UINT32 hopCnt, UINT32 hopCntMerge)
{
    UINT32 carr = 0;

    DpdPrint(PM_INFO,"    %-15s %-15s %-15s %-15s %-15s %-15s %-15s hopCntMerge=%u(%s)\n", "fl", "fh", "bw", "flVir", "fhVir", "gap",
            "gapUsedFlag (GSM HOP REGION INFO)", hopCntMerge, callerName);
    for (carr = 0; carr < hopCnt; carr++)
    {
        DpdPrint(PM_INFO,"    %-15d %-15d %-15d %-15d %-15d %-15d %-15d\n", hopInfo[carr].fl, hopInfo[carr].fh, hopInfo[carr].bw,
            hopInfo[carr].flVir, hopInfo[carr].fhVir, hopInfo[carr].gap, hopInfo[carr].gapUsedFlag);
    }
}

/* 对于有重叠的区间执行合并动作 */
void MergeGsmHopInfo(T_GsmHopChanInfo *chanInfo)
{
    UINT32 carr = 0;
    UINT32 tmp = 0;
    UINT32 cnt = 0;

    INPUT_POINTER_CHECK_RETURN(chanInfo);

    cnt = chanInfo->hopCnt - 1;
    chanInfo->hopCntMerge = chanInfo->hopCnt;
    PrintGspHopInfo(__FUNCTION__, chanInfo->hopInfo, chanInfo->hopCnt, chanInfo->hopCntMerge);
    for (carr = 0; carr < cnt; )
    {
        if (chanInfo->hopInfo[carr].fh > chanInfo->hopInfo[carr + 1].fl)
        {
            chanInfo->hopInfo[carr].fl = min(chanInfo->hopInfo[carr].fl, chanInfo->hopInfo[carr + 1].fl);
            chanInfo->hopInfo[carr].fh = max(chanInfo->hopInfo[carr].fh, chanInfo->hopInfo[carr + 1].fh);
            memset_s(&chanInfo->hopInfo[carr + 1], sizeof(T_GsmHopInfo), 0, sizeof(T_GsmHopInfo));
            for (tmp = carr + 1; tmp < cnt; tmp++)
            {
                memcpy_s(&chanInfo->hopInfo[tmp], sizeof(T_GsmHopInfo), &chanInfo->hopInfo[tmp + 1], sizeof(T_GsmHopInfo));
                memset_s(&chanInfo->hopInfo[tmp + 1], sizeof(T_GsmHopInfo), 0, sizeof(T_GsmHopInfo));
            }
            cnt--;
            chanInfo->hopCntMerge--;
        }
        else
        {
            carr++;
        }
    }

    /* 初始化gap信息 */
    for (carr = 1; carr < chanInfo->hopCntMerge; carr++)
    {
        chanInfo->hopInfo[carr].gap = (INT32)(chanInfo->hopInfo[carr].fl) - (INT32)(chanInfo->hopInfo[carr - 1].fh);
    }

    /* 初始化flVir和fhVir信息 */
    for (carr = 0; carr < chanInfo->hopCntMerge; carr++)
    {
        if (0 == carr)
        {
            chanInfo->hopInfo[carr].flVir = chanInfo->hopInfo[carr].fl;
        }
        else
        {
            chanInfo->hopInfo[carr].flVir = chanInfo->hopInfo[carr - 1].fh;
        }
        chanInfo->hopInfo[carr].fhVir = chanInfo->hopInfo[carr].fh;
    }

    /* 初始化bw信息 */
    for (carr = 0; carr < chanInfo->hopCntMerge; carr++)
    {
        chanInfo->hopInfo[carr].bw = chanInfo->hopInfo[carr].fh - chanInfo->hopInfo[carr].fl;
        chanInfo->bwSum += chanInfo->hopInfo[carr].bw;
    }
}

static void FreqCalculate(T_GsmHopChanInfo *chanInfo)
{
    UINT32 carrNo = 0;
    UINT32 ptsFreqOrigin = 0;
    UINT32 ptsFreqAmend1 = 0;
    UINT32 ptsFreqAmend2 = 0;
    UINT32 section = 0;
    UINT32 hopCnt = 0;
    UINT32 gapSum = 0;
    UINT32 gapUsedSum = 0;

    INPUT_POINTER_CHECK_RETURN(chanInfo);
    /* 初始化频率间隔 */
    if (chanInfo->hopCnt > 1)
    {
        chanInfo->val = chanInfo->bwSum / (chanInfo->hopCnt - 1);
    }

    /* 初始化单音频点 */
    chanInfo->hopCarr[carrNo]->ptsFreq = chanInfo->hopInfo[carrNo].fl;
    chanInfo->hopInfo[carrNo].gapUsedFlag = 1;
    for (carrNo = 1; carrNo < chanInfo->hopCnt; carrNo++)
    {
        ptsFreqOrigin = chanInfo->hopCarr[carrNo - 1]->ptsFreq + chanInfo->val;
        /* 判断落在哪个虚拟区间 */
        for (section = 0; section < chanInfo->hopCntMerge; section++)
        {
            /* 左开右闭 */
            if (ptsFreqOrigin > chanInfo->hopInfo[section].flVir && ptsFreqOrigin <= chanInfo->hopInfo[section].fhVir)
            {
                break;
            }
        }
        if (section == chanInfo->hopCntMerge)
        {
            dbgErr("%s: invalid freq:%u not in virtual hop\n", __FUNCTION__, ptsFreqOrigin);
            return;
        }
        else
        {
            gapSum = 0;
            gapUsedSum = 0;
            for (hopCnt = 0; hopCnt < chanInfo->hopCntMerge; hopCnt++)
            {
                if (chanInfo->hopInfo[hopCnt].gapUsedFlag == 1)
                {
                    gapUsedSum += chanInfo->hopInfo[hopCnt].gap;
                }
            }
            for (hopCnt = 0; hopCnt <= section; hopCnt++)
            {
                gapSum += chanInfo->hopInfo[hopCnt].gap;
                chanInfo->hopInfo[hopCnt].gapUsedFlag = 1;
            }
            ptsFreqAmend1 = ptsFreqOrigin + gapSum;
            ptsFreqAmend2 = ptsFreqAmend1 - gapUsedSum;
            chanInfo->hopCarr[carrNo]->ptsFreq = ptsFreqAmend2;
        }
    }
}

/* 判断计算出来的跳频载波的pts频点和非调频载波是否一样,一样返回TRUE，不一样返回FALSE */
static UINT32 GsmHopCarrPtsFreqSameWithNoHop(UINT32 chan)
{
    T_GsmHopChanInfo *chanInfo = NULL;
    UINT32 noHopCarrNo = 0;
    UINT32 hopCarrNo = 0;

    if (NULL == s_GsmHopChanInfo || chan >= BSP_MAX_CHAN_NUM)
    {
        return FALSE;
    }

    chanInfo = &s_GsmHopChanInfo[chan];
    for (noHopCarrNo = 0; noHopCarrNo < chanInfo->noHopCnt; noHopCarrNo++)
    {
        for (hopCarrNo = 0; hopCarrNo < chanInfo->hopCnt; hopCarrNo++)
        {
            if (chanInfo->noHopCarr[noHopCarrNo]->ptsFreq == chanInfo->hopCarr[hopCarrNo]->ptsFreq)
            {
                break;
            }
        }
        if (hopCarrNo < chanInfo->hopCnt)
        {
            return TRUE;
        }
    }

    return FALSE;
}

static UINT32 BspInitGsmHopCarrInfo(UINT32 chan, UINT32 gsmHopNum, T_RruRfCfgInfo *rruCfgPara)
{
    T_GsmHopChanInfo *chanInfo = NULL;
    T_RruCarrCfgInfo *carrInfo = NULL;
    UINT32 carrNo = 0;
    UINT32 gsmCarrNo = 0;
    UINT32 baseCarr = 0;
    UINT32 noHopCarrNo = 0;
    UINT32 hopCarrNo = 0;
    UINT32 gsmCnt = 0;
    UINT32 hopCnt = 0;

    INPUT_POINTER_CHECK(rruCfgPara);
    if (NULL == s_GsmHopChanInfo)
    {
        s_GsmHopChanInfo = (T_GsmHopChanInfo *)malloc(sizeof(T_GsmHopChanInfo) * BSP_MAX_CHAN_NUM);
        if (NULL == s_GsmHopChanInfo)
        {
            dbgErr("%s: malloc failed\n", __FUNCTION__);
            return BSP_ERROR;
        }
        memset_s(s_GsmHopChanInfo, sizeof(T_GsmHopChanInfo) * BSP_MAX_CHAN_NUM, 0, sizeof(T_GsmHopChanInfo) * BSP_MAX_CHAN_NUM);
    }

    if (chan >= BSP_MAX_CHAN_NUM)
    {
        return BSP_ERROR;
    }

    chanInfo = &s_GsmHopChanInfo[chan];
    memset_s(chanInfo, sizeof(T_GsmHopChanInfo), 0, sizeof(T_GsmHopChanInfo));
    if (gsmHopNum <= 1)
    {
        return BSP_OK;
    }

    for (carrNo = 0; carrNo < rruCfgPara->txCfgCarrSum; carrNo++)
    {
        carrInfo = &rruCfgPara->carr[carrNo];
        if (BSP_RADIO_STANDARD_GSM != carrInfo->carrTxRadio)
        {
            continue;
        }
        chanInfo->carr[gsmCnt].carrNo       = carrInfo->carrTxNo;
        chanInfo->carr[gsmCnt].centerFreq   = carrInfo->carrTxFreq;
        chanInfo->carr[gsmCnt].ptsFreq      = carrInfo->carrTxFreq;   /* 单音频点先初始化成载波中心频点,后面流程中单音频点可能会变化 */
        chanInfo->carr[gsmCnt].bw           = carrInfo->carrTxBw;
        gsmCnt++;
    }
    chanInfo->gsmCarrCnt = gsmCnt;

    for (gsmCarrNo = 0; gsmCarrNo < chanInfo->gsmCarrCnt; gsmCarrNo++)
    {
        if (0 == chanInfo->carr[gsmCarrNo].bw)
        {
            chanInfo->noHopCarr[noHopCarrNo] = &chanInfo->carr[gsmCarrNo];
            noHopCarrNo++;
            continue;
        }
        chanInfo->hopCarr[hopCarrNo] = &chanInfo->carr[gsmCarrNo];
        hopCarrNo++;
        chanInfo->hopInfo[hopCnt].fl = chanInfo->carr[gsmCarrNo].centerFreq - (chanInfo->carr[gsmCarrNo].bw / 2);
        chanInfo->hopInfo[hopCnt].fh = chanInfo->carr[gsmCarrNo].centerFreq + (chanInfo->carr[gsmCarrNo].bw / 2);
        hopCnt++;
    }

    chanInfo->hopCnt = hopCnt;
    chanInfo->noHopCnt = chanInfo->gsmCarrCnt - chanInfo->hopCnt;
    if (noHopCarrNo != chanInfo->noHopCnt || hopCarrNo != chanInfo->hopCnt)
    {
        dbgErr("%s: cnt err.pointer1=%u noHopCnt=%u pointer2=%u hopCnt=%u\n", __FUNCTION__, noHopCarrNo, chanInfo->noHopCnt, hopCarrNo, chanInfo->hopCnt);
        return BSP_ERROR;
    }

    GspHopInfoBubbleSort(chanInfo);
    MergeGsmHopInfo(chanInfo);
    FreqCalculate(chanInfo);
    if (TRUE == GsmHopCarrPtsFreqSameWithNoHop(chan))
    {
        dbgInfo("%s: gsm hop carr pts freq is same with no hop carr, recalculate.\n", __FUNCTION__);
        baseCarr = chanInfo->hopCnt;
        for (carrNo = 0; carrNo < chanInfo->noHopCnt; carrNo++)
        {
            chanInfo->hopCarr[baseCarr + carrNo] = chanInfo->noHopCarr[carrNo];
        }
        chanInfo->hopCnt = chanInfo->gsmCarrCnt;
        /* 将 gapUsedFlag 设置为未使用 */
        for (carrNo = 0; carrNo < chanInfo->hopCntMerge; carrNo++)
        {
            chanInfo->hopInfo[carrNo].gapUsedFlag = 0;
        }
        FreqCalculate(chanInfo);
    }

    return BSP_OK;
}

static UINT32 BspGetGsmHopCarrNum(T_RruRfCfgInfo *rruCfgPara)
{
    UINT32 carrNo = 0;
    UINT32 num = 0;

    if (rruCfgPara == NULL)
    {
        return num;
    }

    for (carrNo = 0; carrNo < rruCfgPara->txCfgCarrSum && carrNo < DPD_UDP_IC42_MAX_CARR_NUM; carrNo++)
    {
        if (0 == rruCfgPara->carr[carrNo].carrTxFreq)
        {
            continue;
        }

        if ((BSP_RADIO_STANDARD_GSM == rruCfgPara->carr[carrNo].carrTxRadio) && (rruCfgPara->carr[carrNo].carrTxBw > 0))
        {
            num++;
        }
    }

    return num;
}

static UINT32 BspPim2GetLoFreq(UINT32 bspChn, UINT32 dir)
{
    UINT32 loFreq = 0;
    UINT32 chanNum = 0;
    T_RfPllCfgInit *rfPllCfgInit = NULL;

    chanNum = (TX == dir) ? BspGetTxChannel():BspGetRxChannel();

    if (bspChn >= chanNum)
    {
        return loFreq;
    }

    rfPllCfgInit = pGetRfPllCfgHandle(dir);
    if (NULL == rfPllCfgInit)
    {
        return loFreq;
    }

    if (BSP_FREQ_NO_CONFIGC_LO == rfPllCfgInit[bspChn].cfgSolution)
    {
        loFreq = rfPllCfgInit[bspChn].defLoFreqKHz;
    }

    return loFreq;
}

void FillDpdPim2ParaAutoMode(T_DpdMsgSetOnlinePimPara *pim2DpdParam)
{
    T_OnlinePim2Param *pim2Param = BspGetOnlinePim2Param();
    T_RruRfCfgInfo *rruCfgPara = NULL;
    T_RruRfCfgInfo *rruCfgParaAll = NULL;
    T_PimOnlineItemTxDsp *pimTxPara = NULL;
    T_PimOnlineItemRxDsp *pimRxPara = NULL;
    UINT32 chan = 0;
    UINT32 carrNo = 0;
    UINT32 gsmHopNum = 0;  /* GSM跳频载波数量 */
    UINT32 retVal = 0;
    UINT32 carrCfgPow = 0;
    UINT32 txChn = BspGetTxChannel();
    UINT32 rxChn = BspGetRxChannel();
    UINT32 maxChn = max(txChn, rxChn);
    UINT32 txCarrBw = 0;
    UINT32 rxCarrBw = 0;

    INPUT_POINTER_CHECK_RETURN(pim2DpdParam);
    rruCfgParaAll = (T_RruRfCfgInfo *)malloc(sizeof(T_RruRfCfgInfo) * maxChn);
    if (NULL == rruCfgParaAll)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return;
    }

    memset_s(rruCfgParaAll, sizeof(T_RruRfCfgInfo) * maxChn, 0, sizeof(T_RruRfCfgInfo) * maxChn);
    pim2DpdParam->powPercent   = pim2Param->powerLevel;
    pim2DpdParam->pimChkMode   = pim2Param->mode;
    pim2DpdParam->clearLutFlag = pim2Param->clearLutFlag;
    pim2DpdParam->txChnNum     = txChn;
    pim2DpdParam->rxChnNum     = rxChn;

    for (chan = 0; chan < maxChn; chan++)
    {
        BspGetChnlCfgCarrPara(chan, &rruCfgParaAll[chan]);
    }

    for (chan = 0; chan < txChn; chan++)
    {
        rruCfgPara = &rruCfgParaAll[chan];
        pim2DpdParam->txChnPimOnline[chan].txChnNo  = chan;
        pim2DpdParam->txChnPimOnline[chan].carrNum  = rruCfgPara->txCfgCarrSum;
        pim2DpdParam->txChnPimOnline[chan].txLoFlag = 0;  /*默认配置为0，后续需要标志在进行动态配置*/
        pim2DpdParam->txChnPimOnline[chan].txLoFreq = rruCfgPara->txCenterFreq;

        gsmHopNum = BspGetGsmHopCarrNum(rruCfgPara);
        BspInitGsmHopCarrInfo(chan, gsmHopNum, rruCfgPara);
        for (carrNo = 0; carrNo < rruCfgPara->txCfgCarrSum && carrNo < DPD_UDP_IC42_MAX_CARR_NUM; carrNo++)
        {
            if (0 == rruCfgPara->carr[carrNo].carrTxFreq)
            {
                continue;
            }
            pimTxPara = &pim2DpdParam->txChnPimOnline[chan].pimOnlineItemTx[carrNo];
            pimTxPara->carrNo       = rruCfgPara->carr[carrNo].carrTxNo;
            pimTxPara->carrMode     = rruCfgPara->carr[carrNo].carrTxRadio;
            pimTxPara->txFreq       = BspGetTxCarrFreq(chan, gsmHopNum, &rruCfgPara->carr[carrNo], rruCfgPara);
            pimTxPara->bandNco      = BspGetBandNcoCfg(TX, chan, rruCfgPara->carr[carrNo].carrTxNo, rruCfgPara->carr[carrNo].carrTxRadio);
            txCarrBw = BspGetFilterCarrBw(TX, chan, rruCfgPara->carr[carrNo].carrTxNo, rruCfgPara->carr[carrNo].carrTxRadio, rruCfgPara->carr[carrNo].carrTxBw);
            pimTxPara->txBandWidth  = (BSP_RADIO_STANDARD_GSM == rruCfgPara->carr[carrNo].carrTxRadio) ? 0 : txCarrBw;
            /* 单音的功率需要配置功率, 和dbtr 6看到的功率一致,不受降额等因素的影响 */
            retVal = BspGetCfgCarrPow(chan, pimTxPara->carrNo, pimTxPara->carrMode, &carrCfgPow);
            if (BSP_OK == retVal)
            {
                pimTxPara->carrPow = carrCfgPow;
            }
            else
            {
                pimTxPara->carrPow = 0;
            }
        }
    }

    for (chan = 0; chan < rxChn; chan++)
    {
        rruCfgPara = &rruCfgParaAll[chan];
        pim2DpdParam->rxChnPimOnline[chan].rxChnNo  = chan;
        pim2DpdParam->rxChnPimOnline[chan].carrNum  = rruCfgPara->rxCfgCarrSum;
        pim2DpdParam->rxChnPimOnline[chan].rxLoFlag = 0; //默认配置为0，后续需要标志在进行动态配置
        pim2DpdParam->rxChnPimOnline[chan].rxLoFreq = rruCfgPara->rxCenterFreq;
        for (carrNo = 0; carrNo < rruCfgPara->rxCfgCarrSum && carrNo < DPD_UDP_IC42_MAX_CARR_NUM; carrNo++)
        {
            if (rruCfgPara->carr[carrNo].carrRxFreq == 0)
            {
                continue;
            }
            pimRxPara = &pim2DpdParam->rxChnPimOnline[chan].pimOnlineItemRx[carrNo];
            pimRxPara->carrNo       = rruCfgPara->carr[carrNo].carrRxNo;
            pimRxPara->carrMode     = rruCfgPara->carr[carrNo].carrRxRadio;
            pimRxPara->rxFreq       = BspGetRxCarrFreq(chan, &rruCfgPara->carr[carrNo]);
            pimRxPara->bandNco      = BspGetCarrCarrBandNcoCfg(RX, chan, rruCfgPara->carr[carrNo].carrRxNo, rruCfgPara->carr[carrNo].carrRxRadio);
            rxCarrBw = BspGetFilterCarrBw(RX, chan, rruCfgPara->carr[carrNo].carrRxNo, rruCfgPara->carr[carrNo].carrRxRadio, rruCfgPara->carr[carrNo].carrRxBw);
            pimRxPara->rxBandWidth  = (BSP_RADIO_STANDARD_GSM == rruCfgPara->carr[carrNo].carrRxRadio) ? 0 : rxCarrBw;
        }
    }
    free(rruCfgParaAll);
}

/* Started by AICoder, pid:536cab5b350f44c1a12a8fe5dd704204 */
UINT32 BspGetCarrCfgByVirtualFreq(UINT32 chan, UINT32 dir, UINT32 freq, UINT32 *carrId, UINT32 *radio)
{
    UINT32 maxCarrNum = 0;
    UINT32 bandId = 0;
    UINT32 bandNum = 0;
    UINT32 startFreq = 0;
    UINT32 endFreq = 0;
    UINT32 carr = 0;
    TFreqStartEnd freqInfo = {0};
    T_RfCfgPara *pRfCfg = NULL;

    INPUT_POINTER_CHECK(carrId);
    INPUT_POINTER_CHECK(radio);
    pRfCfg = BspGetRfCfgPara(chan, dir);
    if(NULL == pRfCfg)
    {
        dbgErr("[%s]chan=%d, GetRfCfgPara Error\n" ,__FUNCTION__, chan);
        return BSP_ERROR;
    }

    maxCarrNum = pRfCfg->carrNum;
    if(0 == maxCarrNum)
    {
        dbgErr("[%s]maxCarrNum = %d,Get Error\n" ,__FUNCTION__, maxCarrNum);
        return BSP_ERROR;
    }

    bandNum = BspGetBandNumByBspChn(chan, dir);
    for(bandId = 0; bandId < bandNum; bandId++)
    {
        if(BSP_OK != BspGetFreqRange(chan, bandId, dir, &freqInfo))
        {
            dbgInfo("[%s]chan=%d, bandId=%d, Get FreqInfo Error!\n", __FUNCTION__, chan, bandId);
            continue;
        }
        startFreq = freqInfo.aulFreqStart[bandId];
        endFreq = freqInfo.aulFreqEnd[bandId];

        BspLog(LOG_LEVEL_0,"[%s]chan=%d,bandId=%d,rxFreq=%d,startFreq=%d,endFreq=%d\n", __FUNCTION__, chan, bandId, freq, startFreq, endFreq);
        if((freq > startFreq) && (freq < endFreq))
        {
            for(carr = 0; carr < maxCarrNum; carr++)
            {
                dbgInfoEx("[%s]carr=%d, carrFreq=%d\n", __FUNCTION__, carr, pRfCfg->carrInfo[carr].freq);
                if((pRfCfg->carrInfo[carr].freq > startFreq) && (pRfCfg->carrInfo[carr].freq < endFreq))
                {
                    *carrId = pRfCfg->carrInfo[carr].carrNo;
                    *radio = pRfCfg->carrInfo[carr].radioMode;
                    dbgInfoEx("[%s]carrId=%d, radio=%d\n", __FUNCTION__, *carrId, *radio);

                    return BSP_OK;
                }
            }
        }
    }

    return BSP_ERROR;
}
/* Ended by AICoder, pid:536cab5b350f44c1a12a8fe5dd704204 */

static void FillDpdPim2ParaManualMode(T_PimOnline *pimOnlineData, T_DpdMsgSetOnlinePimPara *pim2DpdParam)
{
    UINT32 chan = 0;
    UINT32 carr = 0;
    UINT32 carrId = 0;
    UINT32 carrNo = 0;
    UINT32 radio = 0;
    UINT32 rxFreq = 0;
    T_PimOnlineItemTxDsp *txCarrInfo = NULL;
    T_PimOnlineItemRxDsp *rxCarrInfo = NULL;

    INPUT_POINTER_CHECK_RETURN(pimOnlineData);
    INPUT_POINTER_CHECK_RETURN(pim2DpdParam);

    memset_s(pim2DpdParam, sizeof(T_DpdMsgSetOnlinePimPara), 0, sizeof(T_DpdMsgSetOnlinePimPara));
    pim2DpdParam->powPercent = pimOnlineData->percent;
    pim2DpdParam->pimChkMode = pimOnlineData->mode;
    pim2DpdParam->clearLutFlag = pimOnlineData->clearLutFlag;
    pim2DpdParam->txChnNum = pimOnlineData->txChnNum;
    pim2DpdParam->rxChnNum = pimOnlineData->rxChnNum;

    for (chan = 0; chan < pim2DpdParam->txChnNum; chan++)
    {
        pim2DpdParam->txChnPimOnline[chan].txChnNo = pimOnlineData->txChnPimOnline[chan].txChnNo;
        pim2DpdParam->txChnPimOnline[chan].carrNum = pimOnlineData->txChnPimOnline[chan].carrNum;
        pim2DpdParam->txChnPimOnline[chan].txLoFlag = 0;  //默认配置为0，后续需要标志在进行动态配置
        pim2DpdParam->txChnPimOnline[chan].txLoFreq = BspPim2GetLoFreq(pimOnlineData->txChnPimOnline[chan].txChnNo, TX);
        for (carr = 0; carr < pim2DpdParam->txChnPimOnline[chan].carrNum; carr++)
        {
            txCarrInfo = &pim2DpdParam->txChnPimOnline[chan].pimOnlineItemTx[carr];
            txCarrInfo->txFreq = pimOnlineData->txChnPimOnline[chan].pimOnlineItem[carr].txFreq;
            txCarrInfo->carrMode = BSP_RADIO_STANDARD_LTE_FDD;  //算法要求强制写成LTE制式
            txCarrInfo->carrPow = pimOnlineData->txChnPimOnline[chan].pimOnlineItem[carr].carriPwr;
            txCarrInfo->txBandWidth = pimOnlineData->txChnPimOnline[chan].pimOnlineItem[carr].txBandWidth;
            txCarrInfo->bandNco = BspGetTxBandNco(pimOnlineData->txChnPimOnline[chan].txChnNo);
        }
    }

    for (chan = 0; chan < pim2DpdParam->rxChnNum; chan++)
    {
        pim2DpdParam->rxChnPimOnline[chan].rxChnNo = pimOnlineData->rxChnPimOnline[chan].rxChnNo;
        pim2DpdParam->rxChnPimOnline[chan].rxLoFlag = 0;  //默认配置为0，后续需要标志在进行动态配置
        pim2DpdParam->rxChnPimOnline[chan].rxLoFreq = BspPim2GetLoFreq(pimOnlineData->rxChnPimOnline[chan].rxChnNo, RX);

        carrId = 0;
        for (carr = 0; carr < pimOnlineData->rxChnPimOnline[chan].carrNum; carr++)
        {
            rxFreq = pimOnlineData->rxChnPimOnline[chan].pimOnlineItem[carr].rxFreq;
            if(BSP_OK == BspGetCarrCfgByVirtualFreq(pimOnlineData->rxChnPimOnline[chan].rxChnNo, RX, rxFreq, &carrNo, &radio))
            {
                rxCarrInfo = &pim2DpdParam->rxChnPimOnline[chan].pimOnlineItemRx[carrId];
                rxCarrInfo->rxFreq = pimOnlineData->rxChnPimOnline[chan].pimOnlineItem[carr].rxFreq;
                rxCarrInfo->carrMode = BSP_RADIO_STANDARD_LTE_FDD;  //算法要求强制写成LTE制式
                rxCarrInfo->rxBandWidth = pimOnlineData->rxChnPimOnline[chan].pimOnlineItem[carr].rxBandWidth;
                pim2DpdParam->rxChnPimOnline[chan].carrNum += 1;
                carrId += 1;
                rxCarrInfo->bandNco = BspGetCarrCarrBandNcoCfg(RX, pimOnlineData->rxChnPimOnline[chan].rxChnNo, carrNo, radio);
            }
        }
    }
}

static void PrintGsmHopChanInfo(void)
{
    UINT32 chan = 0;
    UINT32 carr = 0;
    UINT32 txMaxChnNum = BspGetTxChannel();
    T_GsmHopChanInfo *chanInfo = NULL;

    if (s_GsmHopChanInfo == NULL)
    {
        return;
    }
    txMaxChnNum = min(txMaxChnNum, BSP_MAX_CHAN_NUM);
    for (chan = 0; chan < txMaxChnNum; chan++)
    {
        chanInfo = &s_GsmHopChanInfo[chan];
        if (0 == chanInfo->hopCnt)
        {
            continue;
        }
        DpdPrint(PM_INFO,"%-15s %-15s %-15s %-15s %-15s %-15s %-15s\n", "chan", "gsmCarrCnt", "hopCnt", "hopCntMerge", "bwSum", "val", "noHopCnt");
        DpdPrint(PM_INFO,"%-15d %-15d %-15d %-15d %-15d %-15d %-15d\n", chan, chanInfo->gsmCarrCnt, chanInfo->hopCnt, chanInfo->hopCntMerge,
                chanInfo->bwSum, chanInfo->val, chanInfo->noHopCnt);
        DpdPrint(PM_INFO,"    %-15s %-15s %-15s %-15s\n", "carrNo", "centerFreq", "ptsFreq", "bw (GSM CARR INFO)");
        for (carr = 0; carr < chanInfo->gsmCarrCnt; carr++)
        {
            DpdPrint(PM_INFO,"    %-15d %-15d %-15d %-15d\n", chanInfo->carr[carr].carrNo, chanInfo->carr[carr].centerFreq, chanInfo->carr[carr].ptsFreq,
                    chanInfo->carr[carr].bw);
        }
        PrintGspHopInfo(__FUNCTION__, chanInfo->hopInfo, chanInfo->hopCnt, chanInfo->hopCntMerge);
        DpdPrint(PM_INFO,"\n\n");
    }
}

static void PrintPimOnlinePara(T_DpdMsgSetOnlinePimPara *pdata)
{
    UINT32 chan = 0;
    UINT32 carr = 0;
    T_PimOnlineItemTxDsp *pimTxPara = NULL;
    T_PimOnlineItemRxDsp *pimRxPara = NULL;

    INPUT_POINTER_CHECK_RETURN(pdata);
    DpdPrint(PM_INFO,"%s:powPercent=%d pimChkMode=%d clearLutFlag=%d txChnNum=%d rxChnNum=%d\n", __FUNCTION__, pdata->powPercent,
            pdata->pimChkMode, pdata->clearLutFlag, pdata->txChnNum, pdata->rxChnNum);
    DpdPrint(PM_INFO,"%-10s %-10s %-10s %-10s\n", "txChnNo", "carrNum", "txLoFlag", "txLoFreq");
    for (chan = 0; chan < pdata->txChnNum; chan++)
    {
        DpdPrint(PM_INFO,"---------------------------------------------------------\n");
        DpdPrint(PM_INFO,"%-10d %-10d %-10d %-10d\n", pdata->txChnPimOnline[chan].txChnNo, pdata->txChnPimOnline[chan].carrNum,
                pdata->txChnPimOnline[chan].txLoFlag, pdata->txChnPimOnline[chan].txLoFreq);
        DpdPrint(PM_INFO,"    %-10s %-10s %-10s %-10s %-15s %-10s\n", "carrNo", "carrMode", "txFreq", "bandNco", "txBandWidth", "carrPwr");
        for (carr = 0; carr < pdata->txChnPimOnline[chan].carrNum; carr++)
        {
            pimTxPara = &pdata->txChnPimOnline[chan].pimOnlineItemTx[carr];
            DpdPrint(PM_INFO,"    %-10d %-10d %-10d %-10d %-15d %-10d\n", pimTxPara->carrNo, pimTxPara->carrMode, pimTxPara->txFreq,
                    pimTxPara->bandNco, pimTxPara->txBandWidth, pimTxPara->carrPow);
        }
    }
    DpdPrint(PM_INFO,"---------------------------------------------------------\n");

    DpdPrint(PM_INFO,"%-10s %-10s %-10s %-10s\n", "rxChnNo", "carrNum", "rxLoFlag", "rxLoFreq");
    for (chan = 0; chan < pdata->rxChnNum; chan++)
    {
        DpdPrint(PM_INFO,"---------------------------------------------------------\n");
        DpdPrint(PM_INFO,"%-10d %-10d %-10d %-10d\n", pdata->rxChnPimOnline[chan].rxChnNo, pdata->rxChnPimOnline[chan].carrNum,
                pdata->rxChnPimOnline[chan].rxLoFlag, pdata->rxChnPimOnline[chan].rxLoFreq);
        DpdPrint(PM_INFO,"    %-10s %-10s %-10s %-10s %-15s\n", "carrNo", "carrMode", "rxFreq", "bandNco", "rxBandWidth");
        for (carr = 0; carr < pdata->rxChnPimOnline[chan].carrNum; carr++)
        {
            pimRxPara = &pdata->rxChnPimOnline[chan].pimOnlineItemRx[carr];
            DpdPrint(PM_INFO,"    %-10d %-10d %-10d %-10d %-15d\n", pimRxPara->carrNo, pimRxPara->carrMode, pimRxPara->rxFreq,
                    pimRxPara->bandNco, pimRxPara->rxBandWidth);
        }
    }
    DpdPrint(PM_INFO,"---------------------------------------------------------\n");
}

static UINT32 BspSetPimConfigData(T_PimOnline *pimOnlineData)
{
    UINT32 retVal = 0;
    T_OnlinePim2Param *pim2Param = BspGetOnlinePim2Param();
    T_DpdMsgSetOnlinePimPara *pim2DpdParam = NULL;

    INPUT_POINTER_CHECK(pimOnlineData);

    pim2DpdParam = (T_DpdMsgSetOnlinePimPara *)malloc(sizeof(T_DpdMsgSetOnlinePimPara));
    if(NULL == pim2DpdParam)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(pim2DpdParam, sizeof(T_DpdMsgSetOnlinePimPara), 0, sizeof(T_DpdMsgSetOnlinePimPara));
    if (ONLINE_PIM2_MODE_AUTO == pim2Param->mode)
    {
        FillDpdPim2ParaAutoMode(pim2DpdParam);
    }
    else
    {
        FillDpdPim2ParaManualMode(pimOnlineData, pim2DpdParam);
    }

    PrintGsmHopChanInfo();
    PrintPimOnlinePara(pim2DpdParam);

    retVal = DpdMsgPimConfigDistribute(pim2DpdParam);
    free(pim2DpdParam);

    return retVal;
}

UINT32 BspGetOnlinePimItem(UINT32 rxchnNo, UINT32 *carrNum, T_PimOnlineReportItemDsp *pimOnlineItem)
{
    UINT32 retVal       = 0;
    UINT32 pimChkSta    = 0;
    UINT32 carr         = 0;
    UINT32 radioMode    = 0;
    UINT32 freq         = 0;
    UINT32 carrId       = 0;
    UINT32 bandWidth    = 0;
    INT32  rssiGain     = 0;
    CHAR pimModeStr[50] = {0};
    T_DpdMsgGetOnlinePim2ValAck *pimValAck = NULL;

    dbgInfoEx("%s: rxchnNo=0x%x\n", __FUNCTION__, rxchnNo);
    if(BSP_OK != DpdPimCfgAnalysisQuery(&pimChkSta))
    {
        dbgErr("%s: DpdPimCfgAnalysisQuery is Error\n", __FUNCTION__);

        return PIM_DPD_CALC;
    }

    if (pimChkSta != PIM_DPD_FINISH)
    {
        dbgInfoEx("%s: DpdPimCfgAnalysisQuery pimChkSta=0x%x\n", __FUNCTION__, pimChkSta);
        return pimChkSta;
    }

    pimValAck = (T_DpdMsgGetOnlinePim2ValAck *)malloc(sizeof(T_DpdMsgGetOnlinePim2ValAck));
    if (NULL == pimValAck)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return PIM_DPD_CALC;
    }

    memset_s(pimValAck, sizeof(T_DpdMsgGetOnlinePim2ValAck), 0, sizeof(T_DpdMsgGetOnlinePim2ValAck));
    if(BSP_OK != DpdMsgGetOnlinePim2Val(rxchnNo, pimValAck))
    {
        free(pimValAck);
        dbgInfoEx("%s: DpdMsgGetOnlinePim2Val Error\n", __FUNCTION__);

        return PIM_DPD_CALC;
    }
    retVal = pimValAck->result;

    if (carrNum != NULL)
    {
        *carrNum = pimValAck->chkCarrNum;
    }
    else
    {
        dbgInfo("%s: carrNum=%d\n", __FUNCTION__, pimValAck->chkCarrNum);
    }

    for (carr = 0; carr < pimValAck->chkCarrNum && carr < DPD_SOCKET_MAX_CARR_NUM; carr++)
    {
        radioMode = pimValAck->carrPara[carr].radioMode;
        freq      = pimValAck->carrPara[carr].rxCarrFreq;
        carrId    = pimValAck->carrPara[carr].carrNo;
        bandWidth = pimValAck->carrPara[carr].rxCarrBw;

        if (BSP_OK != BspGetRssiDbmCompGain(rxchnNo, radioMode, freq, 0, &rssiGain, COMPS_BY_FREQ_POINT_TYPE))
        {
            dbgInfo("Chan = %d, carrNo = %d Get RssiGain is Faliled\n", rxchnNo, carr);
            continue;
        }

        if (pimOnlineItem == NULL)
        {
            if (carr == 0)
            {
                dbgInfo("%-15s %-15s %-15s %-15s %-15s %-15s %-15s %-15s %-15s %-15s %-15s\n\n", "carriid", "radiomode", "rxBandWidth", "rxFreq",
                        "PimMulti", "PimMultiNoise", "Pimsingle", "PimsingleNoise", "checkResult", "rssiGain", "PIMmode");
            }

            memset_s(pimModeStr, sizeof(pimModeStr), 0, sizeof(pimModeStr));
            (void)snprintf_s(pimModeStr, sizeof(pimModeStr), "Pim2Check_ch(%u)_c%u", rxchnNo, carr);
            dbgInfo("%-15d %-15d %-15d %-15d %-15d %-15d %-15d %-15d %-15d %-15d %-15s\n", carrId, radioMode, bandWidth, freq,
                    pimValAck->carrPara[carr].mutiVal - rssiGain, pimValAck->carrPara[carr].mutiNoiseVal - rssiGain,
                    pimValAck->carrPara[carr].singleVal - rssiGain, pimValAck->carrPara[carr].singleNoiseVal - rssiGain,
                    pimValAck->carrPara[carr].checkresult, rssiGain, pimModeStr);
            continue;
        }
        pimOnlineItem[carr].carriId         = carrId;
        pimOnlineItem[carr].radioMode       = radioMode;
        pimOnlineItem[carr].rxBandWidth     = bandWidth;
        pimOnlineItem[carr].rxFreq          = freq;
        pimOnlineItem[carr].pimMulti        = pimValAck->carrPara[carr].mutiVal         - rssiGain;
        pimOnlineItem[carr].pimMultiNoise   = pimValAck->carrPara[carr].mutiNoiseVal    - rssiGain;
        pimOnlineItem[carr].pimSingle       = pimValAck->carrPara[carr].singleVal       - rssiGain;
        pimOnlineItem[carr].pimSingleNoise  = pimValAck->carrPara[carr].singleNoiseVal  - rssiGain;
        pimOnlineItem[carr].result          = pimValAck->carrPara[carr].checkresult;
    }
    free(pimValAck);

    return retVal;
}

static UINT32 BspPimCfgAnalysis(UINT32 ctrl, INT32 slotIndex)
{
    if(SWITCH_ON == ctrl)
    {
        return DpdPimCfgEnergyCalCtrl(DPD_START, slotIndex);
    }
    else
    {
        return DpdPimCfgEnergyCalCtrl(DPD_STOP, slotIndex);
    }
}

UINT32 BspInitDpdModulePimFunc(VOID)
{
    T_DpdModulePimCfgFunc *func = BspGetDpdModuleFuncVal();

    func->startPimCfgAnalysis     = BspPimCfgAnalysis;
    func->setPimCfgData           = BspSetPimConfigData;
    func->getPimCfgItem           = BspGetOnlinePimItem;

    return BSP_OK;
}

UINT32 BspSetDpdPimConfigLmsCtrl(UINT32 ctrl)
{
    if(SWITCH_ON == ctrl)
    {
        return DpdPimConfigLmsCtrl(DPD_START);
    }
    else
    {
        return DpdPimConfigLmsCtrl(DPD_STOP);
    }
}

UINT32 BspGetDpdPimChkLmsIterSta(VOID)
{
    return DpdPimChkLmsIterSta();
}

/*****************************************************************************
 *  函数名称   : BspDpdSetFrDiffInfo(*)
 *  功能描述   : DPD输入帧头与空口帧头间偏差量下发
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetFrDiffInfo(UINT32 bspChn,UINT32 frOffSetNs,UINT32 tddRamFrOffSetNs)
{
    T_DspMsgFrDiffInfo sendFrDiffInfo = {0,0};

    TBL_CHAN_VALID_CHECK(bspChn);
    sendFrDiffInfo.frDiff = frOffSetNs;
    sendFrDiffInfo.tddRamFrOffSet = tddRamFrOffSetNs;
    dbgInfoEx("BspChn = %d, sendFrDiffInfo.frDiff = %d sendFrDiffInfo.tddRamFrOffSet = %d \n",bspChn,
    sendFrDiffInfo.frDiff,sendFrDiffInfo.tddRamFrOffSet);

    return DpdMsgSendFrDiffInfo(bspChn, &sendFrDiffInfo);
}

/*维测使用 强制报告时延测量异常 用于触发高层二次插损流程 验证此功能使用*/
UINT32 g_uldlytestflag = 0;
void setdlytestflag(UINT32 flag)
{
    g_uldlytestflag = flag;
}

UINT32 g_ulCableLossRhoVal[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
/*如果在线测量时关功放等不具备在线测试条件 需要用插损时记录的值和状态*/
UINT32 BspGetSlaveCableLossRhoVal(UINT32 bspChan, UINT32 *pVal)
{
    INPUT_POINTER_CHECK(pVal);
    if(bspChan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    if(BSP_ERROR == g_ulCableLossRhoVal[bspChan])
    {
        return BSP_ERROR;     /*测量失败*/
    }
    *pVal = g_ulCableLossRhoVal[bspChan];

    return BSP_OK;
}
/*9124机型 射频线缆时延测量*/
UINT32 BspDpdStartRfDlyMeas(UINT32 chan)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChn = 0;
    T_DspMsgRfDlyMes tmp = {0};
    T_DspMsgRfDlyMesAck tmpAck = {0};
    T_DspMsgRfDlyMesResultAck resultAck = {0};
    UINT32 loop = 0;
    UINT32 maxTry = 10;   /*最多尝试10次*/
    UINT32 portId =0;
    INT32 mixGain = -500;

    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    BspGetMixGain(chan,0,&mixGain);
    dbgInfo("BspDpdStartRfDlyMeas chan %d\n",chan);
    g_ulSlaveCableRfDly[chan] = 0;  /*清除上一次的测量结果*/
    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChn);
    retVal |= BspGetPortIdByBspChn(chan, TX, &portId);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    if(portId >= MAX_SLAVEPORT_NUM)
    {
        return BSP_ERROR;
    }
    BspSetMixGain(chan,0,-3000);   /*切源之前关广播*/
    g_ulSlavePortCableMeasFlag[portId] = chan%2;
    tmp.applyFlg = 0x5a5a;    /*使能*/
    tmp.type = 0;    /*时延测量*/
    retVal = DpdMsgRfDlyMes(difChn, &tmp, &tmpAck);
    if((BSP_OK != retVal)||(BSP_OK != tmpAck.result))
    {
        BspSetRfCableDlyResult(chan, 1);   /*记录结果  后续流程选择插损时需要看时延测量是否成功*/
        BspSetMixGain(chan,0,mixGain);     /*恢复*/
        g_ulCableLossRhoVal[chan] = BSP_ERROR;
        dbgErr("%s chan %d udpmsg failed\n", __FUNCTION__, difChn);  /*消息报错*/
        return BSP_ERROR;
    }
    BspSysMsDelay(500);  /*发起后500ms 查询一次 最多10次*/
    for(loop = 0; loop < maxTry; loop++)
    {
        retVal = DpdMsgRfDlyMesResult(difChn, &resultAck);
        if((BSP_OK == retVal)&&(BSP_OK == resultAck.iterSta))
        {
            if(BSP_OK == resultAck.result)
            {
                g_ulSlaveCableRfDly[chan] = resultAck.dlyVal;  /*单位是ns*/
                g_ulCableLossRhoVal[chan] = resultAck.rhoVal;
                break;
            }
            else
            {
                g_ulCableLossRhoVal[chan] = 9000;
            }
        }
        BspSysMsDelay(500);  /*发起后500ms 查询一次 最多10次*/
    }
    tmp.applyFlg = 0x2d2d;    /*去使能*/
    tmp.type = 0;    /*时延测量*/
    retVal = DpdMsgRfDlyMes(difChn, &tmp, &tmpAck);
    if((loop == maxTry)||(BSP_OK != retVal))
    {
        BspSetRfCableDlyResult(chan, 1);
        BspSetMixGain(chan,0,mixGain);     /*恢复*/
        g_ulCableLossRhoVal[chan] = BSP_ERROR;
        dbgInfo("BspDpdStartRfDlyMeas chan %d failed\n",chan);
        return BSP_ERROR;
    }
    BspSetRfCableDlyResult(chan, 0);
    if(g_ulSlaveCableDefRfDly[chan] > g_ulSlaveCableRfDly[chan])
    {
        if(g_ulSlaveCableDefRfDly[chan]-g_ulSlaveCableRfDly[chan] > 1000)
        {
             BspSetRfCableDlyResult(chan, 1);
        }
    }
    BspSetMixGain(chan,0,mixGain);     /*恢复*/
    dbgInfo("BspDpdStartRfDlyMeas end %d mixGain %d\n", chan, mixGain);
    if(0 != g_uldlytestflag)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*9124 射频线缆rho值检测*/
UINT32 BspGetSlaveCableRhoVal(UINT32 bspChan,  UINT32 *pVal)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChn = 0;
    UINT32 portId = 0;
    T_DspMsgRfDlyMes tmp = {0};
    T_DspMsgRfDlyMesAck tmpAck = {0};
    T_DspMsgRfDlyMesResultAck resultAck = {0};
    UINT32 loop = 0;
    UINT32 maxTry = 10; /*最大尝试10次*/

    INPUT_POINTER_CHECK(pVal);
    retVal = DpdGetDifInfoByBspChnl(bspChan, TX, &chipId, &difChn);
    retVal |= BspGetPortIdByBspChn(bspChan, TX, &portId);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    tmp.applyFlg = 0x5a5a;    /*使能*/
    tmp.type = 1;    /*rho测量*/
    retVal = DpdMsgRfDlyMes(difChn, &tmp, &tmpAck);
    if((BSP_OK != retVal)||(BSP_OK != tmpAck.result))
    {
        return BSP_ERROR;
    }
    BspSysMsDelay(500);  /*发起后500ms 查询一次 最多10次*/
    for(loop = 0; loop < maxTry; loop++)
    {
        retVal = DpdMsgRfDlyMesResult(difChn, &resultAck);
        if((BSP_OK == retVal)&&(BSP_OK == resultAck.iterSta))
        {
            if(BSP_OK == resultAck.result)
            {
                *pVal = resultAck.rhoVal;
                dbgInfo("chan %d rhoVal %d\n", bspChan, resultAck.rhoVal);
            }
            else
            {
               *pVal = 9000;     /*dsp看到相关性异常 dsp测试其实完成了，只是结果失败*/
            }
            break;
        }
        BspSysMsDelay(500);  /*发起后500ms 查询一次 最多10次*/
    }
    if(maxTry == loop)
    {
        retVal = BSP_ERROR;     /*DSP流程没完成*/
    }
    tmp.applyFlg = 0x2d2d;    /*去使能*/
    tmp.type = 1;
    retVal |= DpdMsgRfDlyMes(difChn, &tmp, &tmpAck);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetSlaveCableRhoVal Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*获取射频线缆长度 按通道进行*/
UINT32 BspGetSlaveRfCableLen(UINT32 chan, UINT32 *pLen)
{
    UINT32 tmp = 0;
    UINT32 defVal = 0;

    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pLen);
    tmp = g_ulSlaveCableRfDly[chan];
    defVal = g_ulSlaveCableDefRfDly[chan];
    if(0 == tmp)   /*表示时延测量失败*/
    {
        *pLen = 0;
        return BSP_ERROR;
    }
    if(tmp < defVal)   /*比默认值小时*/
    {
        if((defVal - tmp) > 1000)   /*超过10ns认为失败*/
        {
            *pLen = 0;
            dbgInfo("%s chan %d tmp %d defVal %d invalid \n", __FUNCTION__, chan, tmp, defVal);
            BspLog(LOG_LEVEL_0,"%s chan %d tmp %d defVal %d invalid *pLen = 0 \n", __FUNCTION__, chan, tmp, defVal);
            return BSP_ERROR;
        }
        else
        {
            *pLen = 0;
        }
    }
    else
    {
        *pLen = (tmp - defVal)*10.0/850; /*(2*4.25)  单位是0.1m 高层使用时会再除以10*/
    }
    dbgInfo("%s chan %d tmp %d defVal %d *pLen %d\n", __FUNCTION__, chan, tmp, defVal, *pLen);
    BspLog(LOG_LEVEL_0, "%s chan %d tmp %d defVal %d *pLen %d\n", __FUNCTION__, chan, tmp, defVal, *pLen);

    return BSP_OK;
}

UINT32 showslavedly(UINT32 chan, UINT32 type)
{
    UINT32 tmp = 0;

    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    if(1 == type)
    {
        return BspGetSlaveRfCableLen(chan, &tmp);
    }
    else
    {
         dbgInfo("%s chan %d tmp %d defVal %d\n", __FUNCTION__, chan, g_ulSlaveCableRfDly[chan], g_ulSlaveCableDefRfDly[chan]);
    }

    return BSP_OK;
}

/*更新设置给中频的射频时延*/
UINT32 BspUpdateSlaveChnRfDly(UINT32 portId, UINT32 dir, UINT32 dly)
{
    UINT32 chanNum = 0;
    UINT32 chanInfo[4] = {0};
    UINT32 retVal = BSP_OK;
    UINT32 tmp = 0;
    UINT32 rfDly = 0;
    UINT32 loop = 0;

    retVal = BspGetBspChnByPortId(portId, dir, &chanNum, chanInfo);
    if(BSP_OK != retVal)
    {
         return BSP_ERROR;
    }
    if((chanInfo[0] >= BSP_IC42_MAX_TX_CHAN_NUM)||(chanInfo[1] >= BSP_IC42_MAX_TX_CHAN_NUM))
    {
        return BSP_ERROR;
    }
    if(portId >= MAX_SLAVEPORT_NUM)
    {
        return BSP_ERROR;
    }
    if(0 == g_ulSlavePortCableMeasFlag[portId])
    {
        return BSP_ERROR;
    }
    for(loop = 0; loop < chanNum; loop++)
    {
        tmp = 0;
        retVal = BspHalAdapGetDefDl204AndRfDly(chanInfo[loop], dir, &tmp);
        rfDly = tmp + dly;
        if(TX == dir)
        {
            retVal |= BspHalAdaptSetDl204AndRfDlyByChan(chanInfo[loop], rfDly);
        }
        else
        {
            retVal |= BspHalAdaptSetUl204AndRfDlyByChan(chanInfo[loop], rfDly);
        }
        retVal |= BspHalAdaptUpdateDifChanDelay(chanInfo[loop]);
        retVal |= BspUpdateCarrDlyOneChan(chanInfo[loop]);
        dbgInfo("portId %d dir %d chanInfo[loop] %d oridly %d newdly %d\n", portId, dir, chanInfo[loop], tmp, rfDly);
    }

    return retVal;
}
/*诊断上报 线缆长度  单位m*/
UINT32 BspGetRruRfCableLength(UINT32 portId, UINT32 *pLen)
{
    UINT32 dlyReult0 = 0;
    UINT32 dlyReult1 = 0;
    UINT32 len0 = 0;
    UINT32 len1 = 0;
    UINT32 retVal = BSP_OK;
    UINT32 chanNum = 0;
    UINT32 chanInfo[4] = {0};
    UINT32 rfDly = 0;

    INPUT_POINTER_CHECK(pLen);
    SLAVE_PORTID_CHECK(portId);
    retVal = BspGetBspChnByPortId(portId, TX, &chanNum, chanInfo);
    if(BSP_OK != retVal)
    {
         return BSP_ERROR;
    }
    if((chanInfo[0] >= BSP_IC42_MAX_TX_CHAN_NUM)||(chanInfo[1] >= BSP_IC42_MAX_TX_CHAN_NUM))
    {
        return BSP_ERROR;
    }
    BspGetRfCableDlyResult(chanInfo[0], &dlyReult0);
    BspGetRfCableDlyResult(chanInfo[1], &dlyReult1);
    BspGetSlaveRfCableLen(chanInfo[0],&len0);
    BspGetSlaveRfCableLen(chanInfo[1],&len1);
    dbgInfoEx("%s dlyReult0 %d dlyReult1 %d len0 %d len1 %d dly0 %d dly1 %d\n", __FUNCTION__, dlyReult0, dlyReult1, len0, len1, g_ulSlaveCableRfDly[chanInfo[0]],g_ulSlaveCableRfDly[chanInfo[1]]);
    if((BSP_OK == dlyReult0)&&(BSP_OK == dlyReult1))
    {
        *pLen = (len0 +len1)/20;
         rfDly =  (len0 +len1)*0.5*0.425;
    }
    else if((BSP_OK != dlyReult0)&&(BSP_OK != dlyReult1))
    {
        *pLen = 0;   /*两通道都失败的，子端诊断馈线长度上报：0（诊断呈现以实际结果呈现），射频链路时延：按照上次测量成功的时延，如果没有成功过，取默认215ns（50米馈线）*/
        if(0 == g_ulSlavePortCableRfDly[portId])
        {
            rfDly = 215; /*ns*/
        }
        else
        {
            rfDly =  g_ulSlavePortCableRfDly[portId];
        }
        retVal = BSP_ERROR;
    }
    else
    {
        if(BSP_OK == dlyReult0)
        {
           *pLen = len0/10;
           rfDly = len0*0.425;
        }
        else
        {
            *pLen = len1/10;
             rfDly = len1*0.425;
        }
    }
    g_ulSlavePortCableRfDly[portId] = rfDly;  /*存本次的值  下次失败用本次的值*/
    dbgInfoEx("%s rfDly %d *pLen %d\n", __FUNCTION__, rfDly, *pLen);
    if((*pLen < 1)&&(BSP_OK == retVal))
    {
        *pLen = 1;   /*单位是m 小于1m且测量成功时  都报1*/
    }
    if(1 == g_ulSlavePortCableMeasFlag[portId])   /*这个子端完成时延测量*/
    {
       BspRecordSlavePortCableLen(chanInfo[0], *pLen);
       BspRecordSlavePortCableLen(chanInfo[1], *pLen);
    }
    BspUpdateSlaveChnRfDly(portId, TX, rfDly);
    BspUpdateSlaveChnRfDly(portId, RX, rfDly);

    return retVal;
}


/*初始化默认线缆时延*/
UINT32 BspInitRfCableDefaultDly(UINT32 *pData, UINT32 num)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChn = 0;

    INPUT_POINTER_CHECK(pData);
    for(loop = 0; loop < num; loop++)
    {
        retVal |= BspGetDifInfoByBspChn(loop, TX, &chipId, &difChn);
        if ((BSP_OK != retVal) || (difChn >= BSP_IC42_MAX_TX_CHAN_NUM))
        {
            dbgErr("[%s] bspChan[%d] get difchan fail!\n",
                   __FUNCTION__, loop);
            return retVal;
        }
        dbgInfo("loop %d pData[loop] %d \n",loop, pData[loop]);
        g_ulSlaveCableDefRfDly[difChn] = pData[loop];
    }

    return BSP_OK;
}

/* 0x0025消息--工装流程下发trapping配置K0增益标志 ctrlFlag: 1需要配 0不需要配置*/
UINT32 BspDpdSetTrapK0GainCtrl(UINT32 bspChan, UINT32 ctrlFlag)
{
    T_DspMsgTrapMsgK0GainCtrl tmp = {0};
    UINT32 flag = 0x2d2d;

    if(ENABLE == ctrlFlag)
    {
        flag = 0x5a5a;
    }
    tmp.trapK0GainCtrlFlg = flag;
    return DpdMsgSetTrapK0GainCtrl(bspChan, &tmp);
}

/*0x0026工装流程下发子端SSC预埋表提取开关 lutSw 1提表 0不提表*/
UINT32 BspDpdSetSscLutGenCtrl(UINT32 bspChan, UINT32 lutSw)
{
    T_DspMsgSscEmbedLutGenSw tmp = {0};
    UINT32 flag = 0x2d2d;

    if(ENABLE == lutSw)
    {
        flag = 0x5a5a;
    }
    tmp.sscEmbedLutGenSw = flag;
    return DpdMsgSetSscLutGenCtrl(bspChan, &tmp);
}

UINT32 BspGetOriSscBinName(CHAR  *pFileName, UINT32 len)
{
    INT32 error = 0;
    UINT32 loop = 0;
    glob_t globbuf = {0};

    INPUT_POINTER_CHECK(pFileName);
    error = glob("/tmp/cali/SscEmbedLut*.bin", 0, NULL, &globbuf);
    if (error != BSP_OK)
    {
        dbgErr("Error: %d\n", error);
        globfree(&globbuf);   /*kw告警 分配的内存未释放*/
        return BSP_ERROR;
    }
    for (loop= 0; loop < globbuf.gl_pathc; loop++)
    {
        dbgInfo("%s\n", globbuf.gl_pathv[loop]);
    }
    if(globbuf.gl_pathc > 1)
    {
        dbgInfo("SscEmbedLut*.bin is more chan 1,error\n");
    }
    strncpy_s(pFileName, len, globbuf.gl_pathv[0], len);
    globfree(&globbuf);

    return BSP_OK;
}
/*解析文件到全局变量*/
UINT32 BspSscInfoParse(UINT32 ulIndex)
{
    UINT32 ret = 0;
    UINT32 datanum = 0;
    INT32 snpRet = 0;
    INT32 fopsRet = 0;
    T_SscInfo *pSscInfo = NULL;
    CHAR fileSourcePath[]= SSC_FILE_SOURCE_PATH;
    CHAR fileTemp[64] = {0};
    CHAR uSysCmd[128] = {0};
    FILE *pFile = NULL;
    CHAR tmpFileDir[64] = {"/tmp/cali/"};
    CHAR binFileName[64] = {0};
    CHAR rmFileName[64] = {"/tmp/cali/SscEmbedLut*.bin"};

    pSscInfo    =(T_SscInfo *)malloc(sizeof(T_SscInfo));
    if(NULL == pSscInfo)
    {
        dbgInfo("%s malloc failed!",__FUNCTION__);
        return BSP_ERROR;
    }

    snpRet = snprintf_s(fileTemp, sizeof(fileTemp), "%s%d%s\0", fileSourcePath, ulIndex+2, ".tar");
    SNPRINTF_S_CHECK(snpRet, sizeof(fileTemp));
    /*先把bin解析出来到tmp/cali/下 这里边的编号不一定对 --strip-components=2表示去掉压缩文件自带的ata/cali路径*/
    snpRet = snprintf_s(uSysCmd, sizeof(uSysCmd), "tar -jxvf %s --strip-components=2 -C %s\0", fileTemp, tmpFileDir);
    SNPRINTF_S_CHECK(snpRet, sizeof(uSysCmd));
    BspSystem(uSysCmd);
    dbgInfoEx("1 -- %s\n", uSysCmd);
    BspGetOriSscBinName(binFileName, 64);

    memset_s(&fileTemp, sizeof(fileTemp), 0, sizeof(fileTemp));

    snpRet = snprintf_s(fileTemp, sizeof(fileTemp), "%s%d%s\0", fileSourcePath, ulIndex+2, ".bin");
    SNPRINTF_S_CHECK(snpRet, sizeof(fileTemp));
    snpRet |= snprintf_s(uSysCmd, sizeof(uSysCmd), "mv %s %s",binFileName, fileTemp);   /*tmp/cali目录移到ata/cali下*/
    SNPRINTF_S_CHECK(snpRet, sizeof(uSysCmd));
    BspSystem(uSysCmd);
    dbgInfoEx("2 -- %s\n", uSysCmd);

    snpRet |= snprintf_s(uSysCmd, sizeof(uSysCmd), "rm %s",rmFileName);   /*去掉tmp/cali下所有ssc表*/
    SNPRINTF_S_CHECK(snpRet, sizeof(uSysCmd));
    BspSystem(uSysCmd);
    dbgInfoEx("3 -- %s\n", uSysCmd);

    fopsRet = fopen_s(&pFile, fileTemp,"rb");
    FOPEN_S_CHECK(fopsRet);

    if(pFile == NULL)
    {
        dbgErr("%s %d, fail to open file! \n", __FUNCTION__, __LINE__);
        free(pSscInfo);
        return BSP_ERROR;
    }

    datanum = fread(pSscInfo, 1, sizeof(T_SscInfo), pFile);
    if(datanum != sizeof(T_SscInfo))
    {
        dbgErr("%s, file size is %d! \n", __FUNCTION__, datanum);
        free(pSscInfo);
        snpRet = fclose(pFile);
        FCLOSE_CHECK(snpRet);

        return BSP_ERROR;
    }

    memset_s(&tSscInfo, sizeof(T_SscInfo), 0, sizeof(T_SscInfo));
    memcpy_s(&tSscInfo, sizeof(T_SscInfo), pSscInfo, sizeof(T_SscInfo));

    free(pSscInfo);
    snpRet = fclose(pFile);
    FCLOSE_CHECK(snpRet);

    return ret;
}

/*0x402c SSC子端通道预埋表下发(一次下发一个通道所有电压档位的表)*/
UINT32 BspDpdSscLutDownload(UINT32 bspChan)
{
    UINT32 ret = 0;
    UINT32 ulInDex = 0;
    UINT32 portType = 0;
    UINT32 uInnerChan = 0;
    T_DspMsgSscEmbedLutDownload *pDspMsgInfo = NULL;
    UINT32 loop = 0;
    UINT32 flag = 0x2d2d;

    if(bspChan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }

    ret |= BspGetPortIdByBspChn(bspChan, TX, &ulInDex);
    ret |= BspGetPortSlaveChnByBspChn(bspChan, TX,  &uInnerChan);
    ret |= BspGetSlavePortCfgTpye(ulInDex, &portType);

    if((BSP_OK != ret)||(0 == portType))
    {
        dbgInfo("%s chan %d not need download !\n",__FUNCTION__,bspChan);
        return BSP_OK;
    }

    ret = BspSscInfoParse(ulInDex);

    pDspMsgInfo =(T_DspMsgSscEmbedLutDownload *)malloc(sizeof(T_DspMsgSscEmbedLutDownload));
    if(NULL == pDspMsgInfo)
    {
        dbgInfo("%s malloc failed!",__FUNCTION__);
        return BSP_ERROR;
    }

    if(BSP_OK == ret)
    {
        flag = 0x5a5a;   /*子端有表就认为有效*/
    }
    pDspMsgInfo->vaildFlag = DPD_HTONL(flag);
    pDspMsgInfo->voltNum = DPD_HTONL(tSscInfo.vdsNum);
    pDspMsgInfo->powNum = DPD_HTONL(tSscInfo.powerLevelNum);
    if(uInnerChan >= 2)
    {
        free(pDspMsgInfo);
        return BSP_ERROR;
    }
    memcpy_s(pDspMsgInfo->sscLutHashVer, 32, tSscInfo.hashVersion[uInnerChan], 32);
    for(loop = 0; loop < 5; loop++)
    {
        pDspMsgInfo->sscVolt[loop] = DPD_HTONL(tSscInfo.vdsValue[loop]);
    }
    memcpy_s(pDspMsgInfo->sscPowIdx, 40, tSscInfo.tSscChanInfo[uInnerChan].powerLevelIndex, 40);
    memcpy_s(pDspMsgInfo->sscLutData, 5*4096, tSscInfo.tSscChanInfo[uInnerChan].sscValue, 5*4096);

    ret |= DpdMsgSendData(bspChan, 0, DPD_MSG_SSCLUT_DOWNLOAD, (UCHAR *)pDspMsgInfo, sizeof(T_DspMsgSscEmbedLutDownload));

    free(pDspMsgInfo);

    return ret;
}

/* Started by AICoder, pid:08b885518b6d46fcae1ddab2ac7d65d9 */
/* 0x002C消息--将下行通道的削峰门限下发给DSP */
UINT32 BspSetCfrGateCfg(UINT32 chanNo, UINT32 gateLevel, UINT32 *cfrGate)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    const UINT32 maxLevel = CFR_STAGE_NUM_MAX;
    T_DspMsgCfrGateCfg cfrGateCfg = {0};

    INPUT_POINTER_CHECK(cfrGate);

    cfrGateCfg.stageNum = (gateLevel > maxLevel) ? maxLevel : gateLevel;
    for(loop = 0; loop < cfrGateCfg.stageNum; loop++)
    {
        cfrGateCfg.cfrGate[loop] = cfrGate[loop];
    }

    retVal |= DpdMsgSetCfrGateCfg(chanNo, &cfrGateCfg);

    return retVal;
}
/* Ended by AICoder, pid:08b885518b6d46fcae1ddab2ac7d65d9 */

/* 0x402d消息--SSC电压档位信息下发(分通道下发),用于子端预埋表选择*/
UINT32 BspDpdSetSscVoltGrdCfg(UINT32 bspChan, UINT32 voltGrd)
{
   T_DspMsgSscVoltGrdCfg tmp = {0};
   tmp.sscVoltGrd = voltGrd;
   dbgInfoEx("bspChan %d voltGrd %d\n", bspChan, voltGrd);
   return DpdMsgSetSscVoltGrdCfg(bspChan, &tmp);
}

/*0x8026消息--SSC子端预埋表提取中trapping迭代成功状态上报*/
UINT32 BspDpdGetSscTrapSta(UINT32 bspChan, T_DspMsgSscLutGenTrapStaAck *pData)
{
    INPUT_POINTER_CHECK(pData);
    return DpdMsgGetSscTrapSta(bspChan, pData);
}

/*0x8027消息--SSC子端预埋表提取成功状态上报*/
UINT32 BspDpdSscLutUpLoad(UINT32 bspChan, UINT32 pwdGrd, T_DspMsgSscLutGenStaUpLoadAck *pDataAck)
{
    T_DspMsgSscLutGenStaUpLoad tmp = {0};
    INPUT_POINTER_CHECK(pDataAck);
    tmp.pwdGrd = pwdGrd;
    return DpdMsgGetSscGenStaUpLoad(bspChan, &tmp, pDataAck);
}

/*0x8028消息--SSC子端预埋表hashver上报*/
UINT32 BspDpdGetSscLutHashVer(UINT32 bspChan, T_DspMsgSscLutHashVerAck *pDataAck)
{
    INPUT_POINTER_CHECK(pDataAck);
    return DpdMsgSscLutHashVer(bspChan, pDataAck);
}

/*0x8029消息--dpd下表张数上报*/
UINT32 BspDpdGetDownLutCnt(UINT32 bspChan, T_DspMsgDownLutCntAck *pDataAck)
{
    INPUT_POINTER_CHECK(pDataAck);
    return DpdMsgGetDownLutCnt(bspChan, pDataAck);
}

void sscfileprn(void)
{
    UINT32 chanloop = 0;
    UINT32 indexloop = 0;
    UINT32 loop = 0;
    dbgInfo("crc %d \n",tSscInfo.crc32);
    dbgInfo("version %d \n",tSscInfo.version);
    dbgInfo("hashVersion %s \n",tSscInfo.hashVersion[0]);
    dbgInfo("hashVersion %s \n",tSscInfo.hashVersion[1]);
    dbgInfo("pathNum %d \n",tSscInfo.pathNum);
    dbgInfo("vdsNum %d \n",tSscInfo.vdsNum);
    dbgInfo("vdsValue %d  %d %d  %d %d  %d %d  %d\n",tSscInfo.vdsValue[0],tSscInfo.vdsValue[1],tSscInfo.vdsValue[2],
            tSscInfo.vdsValue[3],tSscInfo.vdsValue[4],tSscInfo.vdsValue[5],tSscInfo.vdsValue[6],tSscInfo.vdsValue[7]);
    dbgInfo("powerLevelNum %d \n",tSscInfo.powerLevelNum);
    for(chanloop=0; chanloop<2; chanloop++)
    {
        dbgInfo("chan %d:\n",chanloop);
        for(indexloop=0; indexloop<5; indexloop++)
        {
            dbgInfo("powerLevelIndex%d: %d %d %d %d %d %d %d %d\n",indexloop, tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][0],
                tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][1],tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][2],
                tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][3],tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][4],
                tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][5],tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][6],
                tSscInfo.tSscChanInfo[chanloop].powerLevelIndex[indexloop][7]);
        }
        dbgInfo("sscValue :\n");
        for(indexloop=0; indexloop<5; indexloop++)
        {
            for(loop=0; loop<4096; loop++)
            {
                dbgInfo("loop %4d: %d\n",loop,tSscInfo.tSscChanInfo->sscValue[indexloop][loop]);
            }
        }
    }
}

void testfile(UINT32 ulIndex)
{
    UINT32 datanum = 0;
    INT32 snpRet = 0;
    CHAR fileSourcePath[64]= SSC_FILE_SOURCE_PATH;
    CHAR fileDestPath[64]= {0};
    CHAR uSysCmd[200] = {0};
    FILE *pFile = NULL;

    snpRet = snprintf_s(fileDestPath, sizeof(fileDestPath), "%s%d%s\0", fileSourcePath, ulIndex+2, ".bin");
    SNPRINTF_S_CHECK(snpRet, sizeof(fileDestPath));

    pFile = fopen(fileDestPath,"wb");

    if(pFile == NULL)
    {
        dbgErr("%s %d, fail to open file! \n", __FUNCTION__, __LINE__);
        return ;
    }

    datanum = sizeof(T_SscInfo);
    for(int i=0+ulIndex*10; i<datanum+ulIndex*10; i++)
    {
        fwrite(&i, 1, 1, pFile);
    }
    snpRet = fclose(pFile);
    FCLOSE_CHECK(snpRet);

   // snpRet = snprintf_s(fileSourcePath, sizeof(fileSourcePath), "%s%d%s\0", SSC_FILE_SOURCE_PATH, ulIndex+2, ".tar");
    SNPRINTF_S_CHECK(snpRet, sizeof(fileSourcePath));

    snpRet = snprintf_s(uSysCmd, sizeof(uSysCmd), "tar -jcvf %s %s\0", fileSourcePath ,fileDestPath);
    SNPRINTF_S_CHECK(snpRet, sizeof(uSysCmd));
    //BspSystem(uSysCmd);

    snpRet = snprintf_s(uSysCmd, sizeof(uSysCmd), "rm -rf %s\0", fileDestPath);
    //BspSystem(uSysCmd);
    SNPRINTF_S_CHECK(snpRet, sizeof(uSysCmd));

    return ;
}

UINT32 BspDpdMsgPowCalChnSw(UINT32 chan, UINT32 sw)
{
    T_DspMsgPowCalChnSw data = {0};
    T_DspMsgPowCalChnSwAck dataAck = {0};
    UINT32 retVal = BSP_OK;
    UINT32 chanNum = 0;

    chanNum = BspGetTxChannel();
    if(SWITCH_OFF == sw)
    {
        data.powCalChnSw = 0;
    }
    else
    {
        data.powCalChnSw = (1 << chanNum)-1;
    }
    retVal = DpdMsgPowCalChnSw(chan, &data, &dataAck);

    return retVal;
}

/* Started by AICoder, pid:jf2fcve199q002314c150af2f0f9b277acf0605f */
/* Started by AICoder */    /* AI中台代码-星云 start */
/*****************************************************************************
 *  函数名称   : BspDpdSetRfBridgeParam(*)
 *  功能描述   : 给DSP发送电桥离线参数信息
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
/* Started by AICoder, pid:z9580zb32fg1e8c142180a2be0c257179c722fb9 */
UINT32 BspDpdSetRfBridgeParam(T_DpdMsgRfBridgeOfflinePara * pdata)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pdata);
    retVal = DpdMsgSendRfBridgeParam(pdata);
    return retVal;
}
/* Ended by AICoder, pid:z9580zb32fg1e8c142180a2be0c257179c722fb9 */

/*****************************************************************************
 *  函数名称   : BspDpdSendRfBridgeMapInfo(*)
 *  功能描述   : 给DSP发送电桥离线参数信息
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSendRfBridgeMapInfo( T_AllRfBridgeInfo * pdata)
{
    INPUT_POINTER_CHECK(pdata);
    return DpdMsgSendRfBridgeMapInfo( (T_DpdMsgRfBridgeAllRfBridgeInfo*) pdata);
}
/* Ended by AICoder */      /* AI中台代码-星云 end */
/* Ended by AICoder, pid:jf2fcve199q002314c150af2f0f9b277acf0605f */

/* Started by AICoder, pid:u0227u33daoc6081406b0aef700f8a168a40a934 */
/*****************************************************************************
 *  函数名称   : BspNotifyDpdStartVswr_RfBridge(*)
 *  功能描述   : 电桥机型通知DSP 发起VSWR 计算  0x1803消息
 *  输入参数   :  msgVerify  高层生成矢量驻波校验标识,  
                frameNo   ko侧多片采数同步帧号,  
                rfBridgeIdx  电桥索引号,  
                vswrType     发起驻波类型  0x11：商用驻波，0x22：驻波工装，  0x33：S12离线参数计算；0x44：在线驻波位置检测；0x55扩展
 *  输出参数   :  无
 *  返 回 值   :  BSP_OK 成功
 *               其他     失败
 *  其它说明   :  内部使用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zfx@2019-09-10, 创建
 *----------------------------------------------------------------------------*/
UINT32 BspNotifyDpdStartVswr_RfBridge(T_RfBridgeVswrCtrl *pdata)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pdata);
    retVal = DpdMsgVswrStart_RfBridge((T_DpdMsgRfBridgeVswrCtrl*)pdata);
    return retVal;
}
/* Ended by AICoder, pid:u0227u33daoc6081406b0aef700f8a168a40a934 */

UINT32 BspGetVswrFinishSta_RfBridge(UINT32 rfBridgeIdx)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 loopIdx = 0;
    UINT32 chan = 0;
    UINT32 chIndex = 0;
    T_AllRfBridgeInfo pRfBridgeMap = {0};
    T_DpdMsgRfBridgeVswrFinishStaAck vswrSta = {0};

    BspGetRfBridgeInfoMap(&pRfBridgeMap);
    dbgInfo("rfBridgeNum: %d\n",pRfBridgeMap.rfBridgeNum);

    for(loopIdx = 0; loopIdx < pRfBridgeMap.rfBridgeNum; loopIdx++)
    {
        if(pRfBridgeMap.rfBridgeInfo[loopIdx].rfBridgeIdx == rfBridgeIdx)
        {
            for(chIndex = 0; chIndex < pRfBridgeMap.rfBridgeInfo[loopIdx].rfBridgeInPort; chIndex++)
            {
                chan = pRfBridgeMap.rfBridgeInfo[loopIdx].bridgePortChIdx[chIndex];
                ulRetVal |= DpdMsgGetVswrFinishSta_RfBridge(chan, &vswrSta);
                dbgInfo("%s rfBridgeIdx = %d,chan = %d finish state = %#x finish result = %#x\n",
                        __FUNCTION__,loopIdx, chan, vswrSta.finishSta,vswrSta.smpResult);
                if (BSP_OK != ulRetVal)
                {
                    dbgErr( "%s>>rfBridgeIdx'%d DpdVswr Samples Error!\n",__FUNCTION__, rfBridgeIdx);
                    return BSP_ERROR;
                }
                if((RF_BRIDGE_SAMP_UNFINISH == vswrSta.finishSta) || (RF_BRIDGE_SAMP_SUCCESS != vswrSta.smpResult))
                {
                    dbgErr( "%s>>rfBridgeIdx'%d DpdVswr Samples Unfinished!\n",__FUNCTION__, rfBridgeIdx);
                    return BSP_ERROR;
                }
            }
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspNotifyDpdStartVswrCalc_RfBridge(UINT32 rfBridgeIdx, UINT32 vswrType)
{
    return DpdMsgStartVswrCalc_RfBridge(rfBridgeIdx, vswrType);
}

UINT32 BspGetSpaVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeSpaCalcStaAck *pDataAck)
{
    INPUT_POINTER_CHECK(pDataAck);

    if(s_rfBridgeChanFlag[chan] == 0)
    {
        dbgErr("%s>>BspChnl'%d is not belong rfBridge!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgGetSpaVal_RfBridge(chan, pDataAck);
}

UINT32 BspGetRevVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeRevCalcStaAck *pDataAck)
{
    INPUT_POINTER_CHECK(pDataAck);

    if(s_rfBridgeChanFlag[chan] == 0)
    {
        dbgErr("%s>>BspChnl'%d is not belong rfBridge!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgGetRevVal_RfBridge(chan, pDataAck);
}

/*****************************************************************************
 *  函数名称   : BspGetMultiDspVswr_RfBridge(*)
 *  功能描述   : 电桥机型获取DSP计算的矢量驻波 0x1804 工装多点检测使用
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : pVswrReal、pVswrImag、pNco   vswr spa系数的实部虚部 nco
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : vectorvswr模块 BspCalcVswrByVector调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetMultiDspVswr_RfBridge(UINT32 chan,T_DpdMsgRfBridgeSpaCalcStaAck *pSpaVal)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 cnt = 5;
    UINT32 ulRetVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pSpaVal);
    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if(s_rfBridgeChanFlag[ulDifChnl] == 0)
    {
        dbgErr("%s>>BspChnl'%d is not belong rfBridge!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    /* Started by AICoder, pid:j1e7dxc8dfs9f37143c20b1f8074af269e69cbf9 */
    BspSysMsDelay(5000);
    for(cnt = 5; cnt > 0; cnt--)
    {
        if (BSP_OK != DpdMsgGetSpaVal_RfBridge(ulDifChnl, &vswrVal))
        {
            DpdPrint(PM_ERROR,"%s>>BspChnl'%d DifChnl'%d DpdVswrVal MsgGet Error!\n",
                     __FUNCTION__, chan, ulDifChnl);
            return BSP_ERROR;
        }

        ulRetVal = vswrVal.calcFinish;
        if(RF_BRIDGE_SAMP_FINISHED == ulRetVal)
        {
            break;
        }
        else
        {
            BspSysMsDelay(2000);
        }
    }
    if(0 >= cnt)
    {
        DpdPrint(PM_INFO,"cnt= %d,state = 0x%x\n",cnt,ulRetVal);
        DpdPrint(PM_ERROR,"%s chn[%d] get sta timeout\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }
    if(0 != vswrVal.calcResult)
    {
        DpdPrint(PM_ERROR,"dsp vswr cal failed state = 0x%x\n",vswrVal.calcResult);
        return BSP_ERROR;
    }
    /* Ended by AICoder, pid:j1e7dxc8dfs9f37143c20b1f8074af269e69cbf9 */
    if (BSP_OK != DpdMsgGetSpaVal_RfBridge(ulDifChnl, &vswrVal))
    {
        DpdPrint(PM_ERROR,"%s>>BspChnl'%d DifChnl'%d DpdVswrVal MsgGet Error!\n",
                 __FUNCTION__, chan, ulDifChnl);
        return BSP_ERROR;
    }
    memcpy_s((char *)pSpaVal,sizeof(T_DpdMsgRfBridgeSpaCalcStaAck),(char *)&vswrVal,sizeof(T_DpdMsgRfBridgeSpaCalcStaAck));

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetVswrCalcSta_RfBridge(*)
 *  功能描述   : 电桥机型获取DSP计算spa 0x1804 高层查询spa是否计算完成使用
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : rfBridgeIdx：电桥索引号

 *  返 回 值   : BSP_OK, 完成; 否则未完成
 *  其它说明   : vectorvswr模块 BspCalcVswrByVector调用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 BspGetVswrCalcSta_RfBridge(UINT32 rfBridgeIdx)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 loopIdx = 0;
    UINT32 chan = 0;
    UINT32 chIndex = 0;
    T_AllRfBridgeInfo pRfBridgeMap = {0};

    BspGetRfBridgeInfoMap(&pRfBridgeMap);
    dbgInfo("rfBridgeNum: %d\n",pRfBridgeMap.rfBridgeNum);

    for(loopIdx = 0; loopIdx < pRfBridgeMap.rfBridgeNum; loopIdx++)
    {
        if(pRfBridgeMap.rfBridgeInfo[loopIdx].rfBridgeIdx == rfBridgeIdx)
        {
            for(chIndex = 0; chIndex < pRfBridgeMap.rfBridgeInfo[loopIdx].rfBridgeInPort; chIndex++)
            {
                chan = pRfBridgeMap.rfBridgeInfo[loopIdx].bridgePortChIdx[chIndex];
                ulRetVal |= DpdMsgGetSpaVal_RfBridge(chan, &vswrVal);
                dbgInfo("%s rfBridgeIdx = %d,chan = %d finish state = %#x finish result = %#x\n",
                        __FUNCTION__,loopIdx, chan, vswrVal.calcFinish,vswrVal.calcResult);
                if (BSP_OK != ulRetVal)
                {
                    dbgErr( "%s>>rfBridgeIdx'%d DpdVswr Calc Spa Error!\n",__FUNCTION__, rfBridgeIdx);
                    return BSP_ERROR;
                }
                if((RF_BRIDGE_SAMP_FINISHED != vswrVal.calcFinish) || (RF_BRIDGE_SAMP_SUCCESS != vswrVal.calcResult))
                {
                    dbgErr( "%s>>rfBridgeIdx'%d DpdVswr Calc Spa Unfinished!\n",__FUNCTION__, rfBridgeIdx);
                    return BSP_ERROR;
                }
            }
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspSetDspRfBridgeChanFlag(UINT32 difChn, UINT32 flag)
{
    if (difChn >= IC_DSP_CHN_MAX_NUM)
    {
        dbgInfo("[%s] difChn[%u] out of range!\n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    s_rfBridgeChanFlag[difChn] = flag;

    return BSP_OK;
}

/* Started by AICoder, pid:x06b4c3923q76cb14fad093e70eb911817533d15 */
UINT32 BspGetDspRfBridgeChanFlag(UINT32 difChn, UINT32 *flag)
{
    INPUT_POINTER_CHECK(flag);
    if (difChn >= IC_DSP_CHN_MAX_NUM)
    {
        dbgInfo("[%s] difChn[%u] out of range!\n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    *flag = s_rfBridgeChanFlag[difChn];

    return BSP_OK;
}
/* Ended by AICoder, pid:x06b4c3923q76cb14fad093e70eb911817533d15 */

/* Started by AICoder, pid:y125383ff98839814f9f089d316d066270c365ec */
/*****************************************************************************
 *  函数名称   : BspDpdSetInstruSw
 *  功能描述   : 给DSP发送在线仪表功能开关 0x600
 *  输入参数   : UINT32 chan - 通道号
 *               UINT32 sw - 开关状态
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetInstruSw(UINT32 chan, UINT32 sw)
{
    T_DpdMsgInstruSwi tmp = {0};
    UINT32 chipId  = 0;
    UINT32 difChnl = 0;
    UINT32 retVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChnl);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl '%d' DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if (SWITCH_ON == sw)
    {
        tmp.ulFuncSwi = 0x5a5a;
    }
    else
    {
        tmp.ulFuncSwi = 0x2d2d;
    }

    return DpdMsgSendInstruSw(difChnl, &tmp);
}

/*****************************************************************************
 *  函数名称   : BspDpdSetInstruAcpSw
 *  功能描述   : 给DSP发送在线ACP检测发起消息 0x601
 *  输入参数   : UINT32 chan - 通道号
 *               T_DpdMsgInstruAcpSwi *pdata - ACP检测数据
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetInstruAcpSw(UINT32 chan, T_DpdMsgInstruAcpSwi *pdata)
{
    UINT32 chipId  = 0;
    UINT32 difChnl = 0;
    UINT32 retVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pdata);
    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChnl);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl '%d' DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgSendInstruAcpSw(difChnl, pdata);
}

/*****************************************************************************
 *  函数名称   : BspDpdGetInstruAcpSta
 *  功能描述   : 获取ACP检测结果 0x602
 *  输入参数   : UINT32 chan - 通道号
 *               T_DpdMsgInstruAcpStaAck *pdata - ACP检测结果数据
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdGetInstruAcpSta(UINT32 chan, T_DpdMsgInstruAcpStaAck *pdata)
{
    UINT32 chipId  = 0;
    UINT32 difChnl = 0;
    UINT32 retVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pdata);
    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChnl);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl '%d' DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgRecvInstruAcpSta(difChnl, pdata);
}

/*****************************************************************************
 *  函数名称   : BspDpdSendInstruEvmSw
 *  功能描述   : 给DSP发送在线EVM检测发起消息 0x603
 *  输入参数   : UINT32 chan - 通道号
 *               T_DpdMsgInstruEvmSwi *pdata - EVM检测数据
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSendInstruEvmSw(UINT32 chan, T_DpdMsgInstruEvmSwi *pdata)
{
    UINT32 chipId  = 0;
    UINT32 difChnl = 0;
    UINT32 retVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pdata);
    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChnl);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl '%d' DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgSendInstruEvmSw(difChnl, pdata);
}

/*****************************************************************************
 *  函数名称   : BspDpdGetInstruEvmSta
 *  功能描述   : 获取EVM检测结果 0x604
 *  输入参数   : UINT32 chan - 通道号
 *               T_DpdMsgInstruEvmStaAck *pdata - EVM检测结果数据
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdGetInstruEvmSta(UINT32 chan, T_DpdMsgInstruEvmStaAck *pdata)
{
    UINT32 chipId  = 0;
    UINT32 difChnl = 0;
    UINT32 retVal = BSP_OK;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pdata);
    retVal = DpdGetDifInfoByBspChnl(chan, TX, &chipId, &difChnl);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl '%d' DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgRecvInstruEvmSta(difChnl, pdata);
}
/* Ended by AICoder, pid:y125383ff98839814f9f089d316d066270c365ec */

/* Started by AICoder, pid:9d297l8df9hc59114c4b0b6de0fd364ca138d49f */
UINT32 BspDtpCaliStart(T_DPimCalibratCtrlMsg *dtpCaliCtrl)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 loop = 0;
    T_DPimCaliCtrlMsg dspDtpCaliCtrl = {0};
    UINT32 dtpChanNum = 0;

    INPUT_POINTER_CHECK(dtpCaliCtrl);

    memset_s(&dspDtpCaliCtrl, sizeof(T_DPimCaliCtrlMsg), 0, sizeof(T_DPimCaliCtrlMsg));

    dbgInfoEx("%s>>> slotIndex'%d, dtpChkChNum'%d\n", __FUNCTION__, dtpCaliCtrl->slotIndex, dtpCaliCtrl->dtpChkChNum);
    dbgInfoEx("bspchan: ");
    for(loop = 0; loop < dtpCaliCtrl->dtpChkChNum; loop++)
    {
        retVal = BspGetDifInfoByBspChn(dtpCaliCtrl->dtpChkChIndex[loop], RX, &chipId, &difChan);
        if (retVal != BSP_OK)
        {
            dbgErr("%s>>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, dtpCaliCtrl->dtpChkChIndex[loop]);
            BspLog(LOG_LEVEL_0, "%s>>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, dtpCaliCtrl->dtpChkChIndex[loop]);
            continue;
        }
        dbgInfoEx("%5d", dtpCaliCtrl->dtpChkChIndex[loop]);

        dspDtpCaliCtrl.dtpChkChIndex[dtpChanNum] = difChan;
        dtpChanNum++;
    }
    dbgInfoEx("\n");

    dspDtpCaliCtrl.startCtrl = DTP_START;
    dspDtpCaliCtrl.slotIndex = dtpCaliCtrl->slotIndex;
    dspDtpCaliCtrl.dtpChkChNum = dtpChanNum;

    retVal = DpdMsgDtpCaliStart(&dspDtpCaliCtrl);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>DpdMsgDtpCaliStart Error!\n", __FUNCTION__);
    }

    BspLog(LOG_LEVEL_0, "%s>>>slotIndex'%d, dtpChkChNum'%d, retVal'%d\n",
        __FUNCTION__, dspDtpCaliCtrl.slotIndex, dspDtpCaliCtrl.dtpChkChNum, retVal);

    return retVal;
}
/* Ended by AICoder, pid:9d297l8df9hc59114c4b0b6de0fd364ca138d49f */

/* Started by AICoder, pid:8edcbc3495005951442f0b197041be269165a084 */
UINT32 BspGetDtpCaliStat(UINT32 *dtpCaliSta)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(dtpCaliSta);

    retVal = DpdMsgGetDtpCaliStat(dtpCaliSta);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>DpdMsgGetDtpCaliStat Error!\n", __FUNCTION__);
    }

    BspLog(LOG_LEVEL_0, "%s>>>dtpCaliSta'0x%x, retVal'%d\n", __FUNCTION__, *dtpCaliSta, retVal);

    return retVal;
}
/* Ended by AICoder, pid:8edcbc3495005951442f0b197041be269165a084 */

/* Started by AICoder, pid:yfcb656bbb692c81495608ee60343c23c4f3c30f */
UINT32 BspDtpMeasureStart(UINT32 slotIndex)
{
    UINT32 retVal = BSP_OK;

    retVal = DpdMsgDtpMeasureStart(DTP_START, slotIndex);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>DpdMsgDtpMeasureStart Error!\n", __FUNCTION__);
    }

    BspLog(LOG_LEVEL_0, "%s>>>slotIndex'%d, retVal'%d\n", __FUNCTION__, slotIndex, retVal);

    return retVal;
}
/* Ended by AICoder, pid:yfcb656bbb692c81495608ee60343c23c4f3c30f */

/* Started by AICoder, pid:2b82884cde8475c1426d0af7603342293355f02d */
UINT32 BspGetDtpMeasureStat(UINT32 *dtpMeasureSta)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(dtpMeasureSta);

    retVal = DpdMsgGetDtpMeasureStat(dtpMeasureSta);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>DpdMsgGetDtpMeasureStat Error!\n", __FUNCTION__);
    }

    BspLog(LOG_LEVEL_0, "%s>>>dtpMeasureSta'0x%x, retVal'%d\n", __FUNCTION__, *dtpMeasureSta, retVal);

    return retVal;
}
/* Ended by AICoder, pid:2b82884cde8475c1426d0af7603342293355f02d */

/* Started by AICoder, pid:ed8bbj646agd3da146c50bdbc07d8443cb3335f5 */
UINT32 BspGetDtpMeasureRes(UINT32 bspChan, UINT32 bandMapBit, INT32 *singlePimDistance, INT32 *multiPimDistance)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 bandIdx = 0;
    T_DPimResQueryMsgAck dtpResQueryMsgAck = {0};

    INPUT_POINTER_CHECK(singlePimDistance);
    INPUT_POINTER_CHECK(multiPimDistance);

    retVal = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        BspLog(LOG_LEVEL_0, "%s>>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return retVal;
    }

    for(bandIdx = 0; bandIdx < MAX_BAND_NUM; bandIdx++)
    {
        if(BIT_VAL(bandMapBit, bandIdx))
        {
            break;
        }
    }
    if(bandIdx >= MAX_BAND_NUM)
    {
        dbgErr("%s>>>bandMapBit'0x%x Error!\n", __FUNCTION__, bandMapBit);
        BspLog(LOG_LEVEL_0, "%s>>>bandMapBit'0x%x Error!\n", __FUNCTION__, bandMapBit);
        return BSP_ERROR;
    }

    retVal = DpdMsgGetDtpMeasureResult(difChan, bandIdx, &dtpResQueryMsgAck);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>bspChan'%d, DpdMsgGetDtpMeasureResult Error!\n", __FUNCTION__, bspChan);
    }

    *singlePimDistance = dtpResQueryMsgAck.singlePimDistance;
    *multiPimDistance = dtpResQueryMsgAck.multiPimDistance;

    BspLog(LOG_LEVEL_0, "%s>>>bspchan'%d, band'%d, dtpChkSta'0x%x, singlePimDistance'%d, multiPimDistance'%d, retVal'%d\n",
        __FUNCTION__, dtpResQueryMsgAck.rxChan, dtpResQueryMsgAck.band, dtpResQueryMsgAck.dtpChkSta, dtpResQueryMsgAck.singlePimDistance, dtpResQueryMsgAck.multiPimDistance, retVal);

    return retVal;
}
/* Ended by AICoder, pid:ed8bbj646agd3da146c50bdbc07d8443cb3335f5 */

/* Started by AICoder, pid:v8498u5107n2af6147e80a002009622de4651e6f */
UINT32 BspGetDtpPreStartStat(UINT32 *dtpDspReadySta)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(dtpDspReadySta);

    retVal = DpdMsgGetDtpPreStartStat(dtpDspReadySta);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>DpdMsgGetDtpPreStartStat Error!\n", __FUNCTION__);
    }

    BspLog(LOG_LEVEL_0, "%s>>>dtpDspReadySta'0x%x, retVal'%d\n", __FUNCTION__, *dtpDspReadySta, retVal);

    return retVal;
}
/* Ended by AICoder, pid:v8498u5107n2af6147e80a002009622de4651e6f */

/* Started by AICoder, pid:qde04z2ad3v4d84145e4095320a98b223f29d33d */
UINT32 BspDtpPreStart()
{
    UINT32 retVal = BSP_OK;
    UINT32 difChan = 0;

    if(BSP_OK != BspHalAdaptGetOneFddValidChan(&difChan))
    {
        difChan = 0;
    }

    retVal = DpdMsgDtpPreStart(DTP_START, difChan);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>DpdMsgDtpPreStart Error!\n", __FUNCTION__);
    }

    BspLog(LOG_LEVEL_0, "%s>>>difChan'%d, retVal'%d\n", __FUNCTION__, difChan, retVal);

    return retVal;
}
/* Ended by AICoder, pid:qde04z2ad3v4d84145e4095320a98b223f29d33d */

/* Started by AICoder, pid:m665bwef88a01f9149ee09c640345779c7f271c2 */
UINT32 BspSetRfBridgeAcCarrInfo(UINT32 chipIdx, UINT32 brgIdx, T_RfBridgeVswrChanInfo *pInfo)
{
    UINT32 retVal = BSP_OK;
    T_DpdMsgRfBrgVswrAcWeights *pData = NULL;
    UINT32 carrNum = 0;
    UINT32 carrIdx = 0;
    UINT32 chnMask = 0;
    UINT32 carrNo = 0;
    UINT32 radio = 0;
    UINT32 *pAcData = NULL;
    UINT32 lenth = 0;
    UINT32 index = 0;

    INPUT_POINTER_CHECK(pInfo);
    if(pInfo->carrNum > VSWR_MAX_RF_BRIDGE_CARR_NUM)
    {
        dbgErr("Total Carr Num is %d, Over %d!\n", pInfo->carrNum, VSWR_MAX_RF_BRIDGE_CARR_NUM);
        return BSP_ERROR;
    }
    pData = (T_DpdMsgRfBrgVswrAcWeights *)malloc(sizeof(T_DpdMsgRfBrgVswrAcWeights));
    INPUT_POINTER_CHECK(pData);
    memset_s(pData, sizeof(T_DpdMsgRfBrgVswrAcWeights), 0, sizeof(T_DpdMsgRfBrgVswrAcWeights));
    pAcData = (UINT32 *)malloc(sizeof(UINT32) * VSWR_MAX_AC_WEIGHTS_NUM);
    if(pAcData == NULL)
    {
        free(pData);
        return BSP_ERROR;
    }
    memset_s(pAcData, sizeof(UINT32) * VSWR_MAX_AC_WEIGHTS_NUM, 0, sizeof(UINT32) * VSWR_MAX_AC_WEIGHTS_NUM);

    pData->chipIdx = chipIdx;
    pData->softBrgIdx = brgIdx;
    pData->chnIdx = pInfo->chnNo;
    carrNum = pInfo->carrNum;
    chnMask = BIT_SET(pInfo->chnNo);

    for(carrIdx = 0; carrIdx < carrNum; carrIdx++)
    {
        if(pInfo->bridgeCarrInfo[carrIdx].carrType == 0) /* 原始载波 */
        {
            carrNo = pData->tOriginalCarrWeights.carrNo = pInfo->bridgeCarrInfo[carrIdx].carrNo;
            radio = pData->tOriginalCarrWeights.radio = pInfo->bridgeCarrInfo[carrIdx].radioMode;
            BspHalAdaptGetFftTxAcByAnt(carrNo, radio, chnMask, pAcData, &lenth);
            pData->tOriginalCarrWeights.acWeightsLen = lenth;
            dbgInfoEx("carr carrNo = %d, radio = %d, acWeightsLen = %d\n", carrNo, radio, lenth);
            for(index = 0; index < lenth; index++)
            {
                pData->tOriginalCarrWeights.acWeights[index] = pAcData[index];
                dbgInfoEx("index = %d, original carr acWeights = 0x%x\n", index, pData->tOriginalCarrWeights.acWeights[index]);
            }
        }
    }
    retVal = DpdMsgSendRfBridgeAcCarrInfo(pData);

    free(pData);
    free(pAcData);
    return retVal;
}
/* Ended by AICoder, pid:m665bwef88a01f9149ee09c640345779c7f271c2 */

/* Started by AICoder, pid:32d3fvd18ay031b143ea0925b09c8e5653b8ba63 */
UINT32 BspRfBridgePreStartVswr(T_AllRfBridgeVswrInfo *pInfo)
{
    UINT32 bridgeNum = 0;
    UINT32 brgIdx = 0;
    UINT32 chipIdx = 0;
    UINT32 chanNum = 0;
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;
    T_DpdMsgRfBrgVswrPreStart *pData = NULL;

    INPUT_POINTER_CHECK(pInfo);
    if(pInfo->bridgeNum > VSWR_MAX_RF_BRIDGE_NUM)
    {
        dbgErr("bridgeNum is %d, Over %d!\n", pInfo->bridgeNum, VSWR_MAX_RF_BRIDGE_NUM);
        return BSP_ERROR;
    }
    pData = (T_DpdMsgRfBrgVswrPreStart *)malloc(sizeof(T_DpdMsgRfBrgVswrPreStart));
    INPUT_POINTER_CHECK(pData);
    memset_s(pData, sizeof(T_DpdMsgRfBrgVswrPreStart), 0, sizeof(T_DpdMsgRfBrgVswrPreStart));

    chipIdx = pInfo->chipIdx;
    bridgeNum = pInfo->bridgeNum;
    pData->calSoftBrgNum = bridgeNum;
    for(brgIdx = 0; brgIdx < bridgeNum; brgIdx++)
    {
        pData->calRfBrgIdx[brgIdx] = pInfo->bridgeInfo[brgIdx].rfBridgeIdx;
        chanNum = pInfo->bridgeInfo[brgIdx].chanNum;
        if(chanNum > VSWR_MAX_RF_BRIDGE_PORT_NUM)
        {
            dbgErr("chanNum is %d, Over %d!\n", chanNum, VSWR_MAX_RF_BRIDGE_PORT_NUM);
            free(pData);
            return BSP_ERROR;
        }
        for(chan = 0; chan < chanNum; chan++)
        {
            retVal |= BspSetRfBridgeAcCarrInfo(chipIdx, pInfo->bridgeInfo[brgIdx].rfBridgeIdx,
                    (T_RfBridgeVswrChanInfo *)&pInfo->bridgeInfo[brgIdx].bridgeChanInfo[chan]);
        }
    }
    retVal |= DpdMsgSendRfBrgVswrPreStart(pData);

    free(pData);
    return retVal;
}
/* Ended by AICoder, pid:32d3fvd18ay031b143ea0925b09c8e5653b8ba63 */

/* Started by AICoder, pid:reda4vcc47s77c214495086960f4531f53b0e693 */
UINT32 BspGetRfBridgePreStartVswrSta(T_RfBrgVswrPreStartSta *pSta)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pSta);
    retVal = DpdMsgGetRfBrgVswrPreStartSta((T_DpdMsgRfBrgVswrPreStartStaAck*)pSta);
    return retVal;
}
/* Ended by AICoder, pid:reda4vcc47s77c214495086960f4531f53b0e693 */

/* Started by AICoder, pid:q883d86b315506114f290acbf035c205e8382e21 */
UINT32 BspSetRfBridgeBreakVswr(void)
{
    UINT32 retVal = BSP_OK;

    retVal = DpdMsgSendRfBrgBreakVswr();
    return retVal;
}
/* Ended by AICoder, pid:q883d86b315506114f290acbf035c205e8382e21 */

/* Started by AICoder, pid:h7890zebe2219d51426d0a2c407a941f7766735c */
UINT32 BspGetRfBridgeVswrCalcSta(UINT32 *pSta, UINT32 *pVerify)
{
    UINT32 retVal = BSP_OK;
    T_DpdMsgRfBrgVswrStaAck sta = {0};

    INPUT_POINTER_CHECK(pSta);
    INPUT_POINTER_CHECK(pVerify);
    retVal = DpdMsgGetRfBrgVswrSta(&sta);
    *pSta = sta.calcFinish;
    *pVerify = sta.msgVerify;
    return retVal;
}
/* Ended by AICoder, pid:h7890zebe2219d51426d0a2c407a941f7766735c */

/* Started by AICoder, pid:c3d01x76d1z918f14f3b0b1d4020315cb873dffb */
UINT32 BspCheckRfBridgeAcValidity(UINT32 brgIdx, UINT32 carrNo, UINT32 radio, UINT32 *pValidity)
{
    T_AllRfBridgeInfo info = {0};
    UINT32 portNum = 0;
    UINT32 port = 0;
    UINT32 chnMask = 0;
    UINT32 chan = 0;
    UINT32 *pAcData = NULL;
    UINT32 lenth = 0;
    UINT32 acIdx = 0;
    UINT32 acNum = 0;
    UINT32 invalAcNum = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pValidity);
    *pValidity = 0;
    retVal = BspGetRfBridgeInfoMap(&info);
    portNum = info.rfBridgeInfo[brgIdx].rfBridgeOutPort;
    if(portNum > VSWR_MAX_RF_BRIDGE_PORT_NUM)
    {
        dbgErr("[%s] Get Rf Bridge Port Num is Over!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pAcData = (UINT32 *)malloc(sizeof(UINT32) * VSWR_MAX_AC_WEIGHTS_NUM);
    INPUT_POINTER_CHECK(pAcData);
    memset_s(pAcData, sizeof(UINT32) * VSWR_MAX_AC_WEIGHTS_NUM, 0, sizeof(UINT32) * VSWR_MAX_AC_WEIGHTS_NUM);
    for(port = 0; port < portNum; port++)
    {
        chan = info.rfBridgeInfo[brgIdx].bridgePortChIdx[port];
        chnMask = BIT_SET(chan);
        retVal |= BspHalAdaptGetFftTxAcByAnt(carrNo, radio, chnMask, pAcData, &lenth);
        for(acIdx = 0; acIdx < lenth; acIdx++)
        {
            if(pAcData[acIdx] == 0x40000000)
            {
                invalAcNum += 1;
            }
        }
        acNum += lenth;
    }
    if(acNum == invalAcNum)
    {
        *pValidity = 1;
    }

    free(pAcData);
    return retVal;
}
/* Ended by AICoder, pid:c3d01x76d1z918f14f3b0b1d4020315cb873dffb */

/* Started by AICoder, pid:2c440ie841964ff14df108f3f0058f5a91644e9b */
UINT32 BspDpdSendPaCurrCali(UINT32 fileNo)
{
    UINT32 retVal = 0;
    UINT32 ulLineLoop = 0;
    UINT32 ulGroupLoop = 0;
    T_DpdMsgSendPaCurrCali *paCurrCali = NULL;
    T_PaCurCaliData *pCalibData = NULL;
    T_PaCurCali *paCali = NULL;
    T_PaCurAdRecord *ptCurAdRecord = NULL;

    pCalibData = (T_PaCurCaliData *)_BspGetCalibData(TBL_KIND_OF_PACURRCALI, fileNo);
    INPUT_POINTER_CHECK(pCalibData);

    paCali = &pCalibData->tPaCurCaliPath.tCurCali;
    ptCurAdRecord = pCalibData->tPaCurCaliPath.tCurCali.ptCurAdRecord;

    paCurrCali = (T_DpdMsgSendPaCurrCali *)malloc(sizeof(T_DpdMsgSendPaCurrCali));
    INPUT_POINTER_CHECK(paCurrCali);
    memset_s(paCurrCali, sizeof(T_DpdMsgSendPaCurrCali), 0, sizeof(T_DpdMsgSendPaCurrCali));

    paCurrCali->ulCurAdRecordNum = paCali->ulCurAdRecordNum;
    paCurrCali->ulCurAdLoadFlag = paCali->ulCurAdLoadFlag;

    for(ulLineLoop = 0; ulLineLoop < min(paCurrCali->ulCurAdRecordNum,PA_CURR_CALI_MAX_LINE); ulLineLoop++)
    {
        paCurrCali->tPaCurrCaliInfo[ulLineLoop].ulPaChan = ptCurAdRecord->ulPaChan;
        paCurrCali->tPaCurrCaliInfo[ulLineLoop].ulDacIndex = ptCurAdRecord->ulDacIndex;
        paCurrCali->tPaCurrCaliInfo[ulLineLoop].ulAdcPath = ptCurAdRecord->ulAdcPath;
        paCurrCali->tPaCurrCaliInfo[ulLineLoop].ulVbiasType = ptCurAdRecord->ulVbiasType;
        paCurrCali->tPaCurrCaliInfo[ulLineLoop].ulCurrentDetectIndex = ptCurAdRecord->ulCurrentDetectIndex;
        paCurrCali->tPaCurrCaliInfo[ulLineLoop].ulCurrentNum = ptCurAdRecord->ulCurrentNum;

        for(ulGroupLoop = 0; ulGroupLoop < min(paCurrCali->tPaCurrCaliInfo[ulLineLoop].ulCurrentNum,TBL_PA_CUR_N_VALUE); ulGroupLoop++)
        {
            paCurrCali->tPaCurrCaliInfo[ulLineLoop].curAdRecord[ulGroupLoop].ulCurrent = ptCurAdRecord->ulCurrent[ulGroupLoop];
            paCurrCali->tPaCurrCaliInfo[ulLineLoop].curAdRecord[ulGroupLoop].ulAdVal = ptCurAdRecord->ulAdVal[ulGroupLoop];
            paCurrCali->tPaCurrCaliInfo[ulLineLoop].curAdRecord[ulGroupLoop].ulTemp = ptCurAdRecord->ulTemp[ulGroupLoop];
        }

        ptCurAdRecord++;
    }

    retVal = DpdMsgSendPaCurrentCaliInfo(0, 0, paCurrCali);

    free(paCurrCali);
    return retVal;
}
/* Ended by AICoder, pid:2c440ie841964ff14df108f3f0058f5a91644e9b */
/*****************************************************************************
 *  函数名称   : BspDpdSetNcrGpInfo(*)
 *  功能描述   : 给DSP发送NCR的GP信息  0x0030消息
 *  输入参数   :
 *  输出参数   : chan:bsp通道号 bandId:频段号
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 下发NCR机型的GP发数位置信息
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 岳文轩@2024-12-23, 创建
 *----------------------------------------------------------------------------*/
 /* Started by AICoder, pid:z6242r00e5b05aa1488d087e20b00951de56f0dd */
UINT32 BspDpdSetNcrGpInfo(UINT32 chan)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT32 uiGpPaSite = 0;
    UINT32 uiUeValNs = 0;
    UINT32 uiUeGapValNs = 0;
    UINT32 uiFwdDir = 0;
    UINT32 uiNcrDlTxDly = 2554; //后续bsp合入后改成从接口获取
    UINT32 uiNcrDlRxDly = 2377;
    UINT32 uiTdmDly = 102;
    
    T_DpdMsgNcrGpInfo *SetNcrGpinfo = NULL;
 
    UINT32 radio = BspGetRadioStandard();

    radio = radio&RADIO_STANDARD_45G;

    SetNcrGpinfo = (T_DpdMsgNcrGpInfo *)malloc(sizeof(T_DpdMsgNcrGpInfo));
    INPUT_POINTER_CHECK(SetNcrGpinfo);
    memset_s(SetNcrGpinfo, sizeof(T_DpdMsgNcrGpInfo), 0, sizeof(T_DpdMsgNcrGpInfo));

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        free(SetNcrGpinfo);
        return BSP_ERROR;
    }
    /* Started by AICoder, pid:58c2fm0d12v3d12144910b8c70fc2156be64758d */

    SetNcrGpinfo->uiChnDirection = 1;

    if(IS_NCR == BspIsNcr())
    {
        if(BSP_OK != BspGetFwdDirByRfInfo(ulDifChnl, TX, &uiFwdDir))
        {
            dbgErr("%s>>BspChnl'%d FwdDir Get Error!\n", __FUNCTION__, ulDifChnl);
            free(SetNcrGpinfo);
            return BSP_ERROR;
        }
        dbgInfoEx("%s ulDifChnl'%d, uiFwdDir'%d\n", __FUNCTION__, ulDifChnl, uiFwdDir);

        if((0 == uiFwdDir)&& (1 == BspGetChanModeType(ulDifChnl))) //上行链路且TDD通道配置
        {
            IcHalApiGetUeAdvVal(radio, &uiUeValNs);
            IcHalApiGetUeGapVal(radio, &uiUeGapValNs);
            Para5_AdvOn_PaTxSw_NCR2(radio, E_DPD_TYPE_TS, &uiGpPaSite);
            SetNcrGpinfo->uiGpPaSite = UINT32_737_2_DOUBLE_US(uiGpPaSite * 10000)/* / (DOUBLE)737.28*/; //保留小数
            SetNcrGpinfo->uiUeGapVal = uiUeValNs + uiUeGapValNs;
        }
        SetNcrGpinfo->uiLinkTimeNs = uiNcrDlTxDly + uiNcrDlRxDly + uiTdmDly;
        SetNcrGpinfo->uiNcrFlag = 1;
        SetNcrGpinfo->uiChnDirection = uiFwdDir; //0是链路上行，1是下行方向
    }

    dbgInfoEx("%s ulDifChnl'%d uiGpPaSite'%d uiChnDirection'%d uiNcrFlag'%d uiUeGapVal'%d uiLinkTimeNs' %d\n", __FUNCTION__, ulDifChnl, SetNcrGpinfo->uiGpPaSite, SetNcrGpinfo->uiChnDirection, SetNcrGpinfo->uiNcrFlag, SetNcrGpinfo->uiUeGapVal, SetNcrGpinfo->uiLinkTimeNs);
    /* Ended by AICoder, pid:58c2fm0d12v3d12144910b8c70fc2156be64758d */
    ulRetVal = DpdMsgSendNcrGpInfo(ulDifChnl, SetNcrGpinfo);
    free(SetNcrGpinfo);
    return ulRetVal;
}
/* Ended by AICoder, pid:z6242r00e5b05aa1488d087e20b00951de56f0dd */

/* Started by AICoder, pid:i9f76q539eo5716148c9096a40b9096b83658225 */
UINT32 BspDpdSetDisablePimOnlineTxChanInfo(T_RxSetPimOnlineDisableTxChanBand *pTxChanPara)
{
    UINT32 loop = 0;
    UINT32 bandloop = 0;
    T_RxSetPimOnlineDisableTxChanBand chanPara = {0};
    if(BspGetBandVswrFlag() == 0)
    {
        dbgInfoEx("%s: the rru is not support!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pTxChanPara);
    dbgInfoEx("%s: uiNum=%u \n", __FUNCTION__, pTxChanPara->uiNum);
    chanPara.uiNum = pTxChanPara->uiNum;
    for(loop = 0; loop < BSP_MAX_DISABLE_TX_CHAN_BAND_NUM; loop++)
    {
        chanPara.atChanBand[loop].uTxChanNo = pTxChanPara->atChanBand[loop].uTxChanNo;
        chanPara.atChanBand[loop].uRxChanNo = pTxChanPara->atChanBand[loop].uRxChanNo;
        for(bandloop = 0; bandloop < MAX_RRU_BAND_NUM; bandloop++)
        {
            if(pTxChanPara->atChanBand[loop].uTxBandBit == BIT_SET(bandloop))
            {
                chanPara.atChanBand[loop].uTxBandBit = bandloop; /*高层传的是通道掩码需要转换成bandNo*/
            }
            if(pTxChanPara->atChanBand[loop].uRxBandBit == BIT_SET(bandloop))
            {
                chanPara.atChanBand[loop].uRxBandBit = bandloop; /*高层传的是通道掩码需要转换成bandNo*/
            }
        }
        dbgInfoEx("%s: chan = %u, uTxChanNo=%u uTxBandBit=%u uTxChanNo=%u uTxBandBit=%u \n", __FUNCTION__, loop,
                chanPara.atChanBand[loop].uTxChanNo, chanPara.atChanBand[loop].uTxBandBit,
                chanPara.atChanBand[loop].uRxChanNo, chanPara.atChanBand[loop].uRxBandBit);
    }
    return DpdMsgSendDisablePimOnlineTxChanPara(0, 0, &chanPara);
}
/* Ended by AICoder, pid:i9f76q539eo5716148c9096a40b9096b83658225 */
UINT32 BspReceiveRhoDataFromDsp(UINT32 chan, UINT32 freqNo, T_SelfExcitRhoDataReportItem *rhoData)
{
    return BSP_OK;
}
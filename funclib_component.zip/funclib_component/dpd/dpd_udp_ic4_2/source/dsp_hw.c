#include <sys/mman.h>
#include "stdlib.h"
#include <fcntl.h>

#include "bsppub.h"
#include "bspcomm.h"
#include "systemcallapi.h"
#include "dsp_hw.h"
#include "exprn.h"
#include "dpdcommon.h"
#define MAX_DSP_NUM                 8

#define CPUDSP_SR_BUFFER_SZ         (0x100)






static VOID *msgRevBuf = NULL;
/* static VOID *msgSndBuf = NULL; */


static UINT32 dspVersionLoad = 0xFF;


UINT32 DspAccessClose(UINT32 dspId)
{
//    return BspTcpSocketClose(dspId);
    return BSP_OK;
}

UINT32 DspRecvIsReady(UINT32 dspId)
{
    return BSP_OK;
}



UINT32 DspAccessRequire(UINT32 dspId)
{
    return BSP_OK;
}


/**************************************************************************
 * 函数名称：MemTransf()
 * 功能描述：DSP侧内存地址向CPU侧地址转换
 * (该函数仅在加载DSP版本时使用)
 * 输入参数：DSP侧地址
 * 输出参数： 无
 * 返 回 值：   CPU侧对应物理地址
 * 其它说明： 0x00800000 ~0x0083FFFF   C674x. Level 2 (L2) Cache
            将DSP侧地址映射到CPU侧(在加载DSP版本时需要进行此转换)
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2012/08/21         V1.0              秦菲            创建
 **************************************************************************/
UINT32 MemTransf(UINT32 dspAddr)
{
    return dspAddr;
}




UINT32 MemMapInit(VOID)
{
    /* UINT8 *buf; */
    /* UINT32 bufLen = CPUDSP_SR_BUFFER_SZ*2; */

    return BSP_OK;
}

VOID GenerateDspInt(UINT32 dspId)
{

}



UINT32 DspMsgSnd(UINT32 dspId, UINT32 *pData, UINT32 offset, UINT32 len)
{
    UINT32 retVal = BSP_OK;
    UINT32  size = len * sizeof(UINT32);
    UINT32 *pSndBuf;

    INPUT_POINTER_CHECK(pData);
    if(size > CPUDSP_SR_BUFFER_SZ)
    {
        dbgErr("Snd Msg size 0x%x > CPUDSP_SR_BUFFER_SZ(0x%x)\n",
            size, CPUDSP_SR_BUFFER_SZ);
        return BSP_ERROR;
    }

    pSndBuf = (UINT32*)(pData+offset);
    dbgInfoEx("%s: pSndBuf: %p\n", __FUNCTION__, pSndBuf);
    /* TCP id和dspId对应关系,后续要考虑 */
    /*dspid 目前设置为 =  tcp id */
    //retVal = BspTcpSocketSend(dspId, (UINT8 *)pSndBuf, size);
    return retVal;
}

UINT32 DspMsgRev(UINT32 dspId, UINT32 *pData, UINT32 offset, UINT32 len)
{
    UINT32  size = len * sizeof(UINT32);
    /* UINT32 *pRcvBuf; */

    INPUT_POINTER_CHECK(pData);
    if(size > CPUDSP_SR_BUFFER_SZ)
    {
        dbgErr("Rev Msg size 0x%x > CPUDSP_SR_BUFFER_SZ(0x%x)\n",
            size, CPUDSP_SR_BUFFER_SZ);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(msgRevBuf);
# if 0
    pRcvBuf = (UINT32 *)((UINT32)msgRevBuf + offset);
    memcpy((VOID*)pData,(VOID*)pRcvBuf, size);
#endif
    return BSP_OK;
}





UINT32 DspMemWr(UINT32 dspId, UINT32 *pData, UINT32 addr, UINT32 len)
{
    return BSP_OK;
}


UINT32 DspMemRd(UINT32 dspId, UINT32 *pData, UINT32 addr, UINT32 len)
{
    return BSP_OK;
}



UINT32 DspHwInit(UINT32 dspId)
{
    static UINT32 dspHwInit = 0;

    if (dspHwInit == 0)
    {
        MemMapInit();
    }

    dspHwInit |= (1<<dspId);
    return BSP_OK;
}

/**************************************************************************
 * 函数名称： LoadDspMem
 * 功能描述： 先加载dsp mem数据
 * 输入参数： dspId - 通道号
              pBuf - 加载文件的地址
              bufLen - 文件大小
 * 输出参数： pEntryPoint
 * 返 回 值： BSP_OK:成功
              其他:失败
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 LoadDspMem(UINT32 dspId,UINT8 *pBuf, UINT32 bufLen,UINT32 *pEntryPoint)
{
    return BSP_OK;
}



/**************************************************************************
 * 函数名称： LoadDspBin
 * 功能描述： 加载Dsp版本
 * 输入参数： wChannel - 通道号
 * 输出参数： 无
 * 返 回 值：    RETCODE_PASS:成功
RETCODE_ERROR:失败
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 2011-2-22                                         李超
 **************************************************************************/
UINT32 LoadDspBin(UINT32 dspId,UINT8 *pBuf,UINT32 bufLen)
{
    /* INT32 fd; */
    char  path[32] = {0};
    char  cmdExe[32] = {0};
    char  pidName[32] = {0};
    UINT32 pidNum;
    ULONG ret = 0;
    char  cmd[32] = {0};
    /* pid_t pid = -1; */
    INT32 retVal = BSP_OK;

    dspVersionLoad |= (1<<dspId);

    if (snprintf_s(path,sizeof(path),"/dsp%d.out",dspId) < 0)
    {
        dbgErr("%s snprintf_s() is error\n", __FUNCTION__);
    }
    if (snprintf_s(pidName,sizeof(pidName),"dsp%d.out",dspId) < 0)
    {
        dbgErr("%s snprintf_s() is error\n", __FUNCTION__);
    }

    if( BSP_OK == BspIsPidExisted(pidName,&pidNum))
    {
        if (snprintf_s(cmdExe,sizeof(cmdExe),"kill %d",pidNum) < 0)
        {
            dbgErr("%s snprintf_s() is error\n", __FUNCTION__);
        }
        BspSystem(cmdExe);
    }

    /*slaver dsp */
    dbgInfo("Load %s Success, star to run dsp process\n",path);
    #if 0
    pid = fork();
    switch(pid)
    {
        case -1:
        {
            dbgErr("fork failed\n");
            retVal = BSP_ERROR;
            break;
        }
        case 0:
        {
            dbgInfo("child process\n");
            memset(cmdExe,0,sizeof(cmdExe));
            snprintf(cmdExe,sizeof(cmdExe),"./dsp%d.out",dspId);
            //这是在子进程中，调用execl切换为dsp.out进程
            execl(path, cmdExe, "&", 0);  //成功不返回值，失败返回-1，由于是在子进程，如果这个切换失败，暂不可知。
            break;
        }
        default:
        {
            dbgInfo("father process\n");
            //这是在父进程中，输出相关提示信息 认为OK.
            break;
        }
    }
    #else
    ret = BspChmod(path,"750");
    if (ret != BSP_OK)
    {
        return BSP_ERROR;
    }
    if (snprintf_s(cmd,sizeof(cmd),".%s &",path) < 0)
    {
        dbgErr("%s snprintf_s() is error\n", __FUNCTION__);
    }
    BspSystem(cmd);
    #endif
    dbgInfo("Run dsp process success\n");

    dspVersionLoad &= ~(1<<dspId);
    return retVal;
}


UINT32 GetDspLoadFlag(UINT32 dspId)
{
    return dspVersionLoad&(1<<dspId);
}







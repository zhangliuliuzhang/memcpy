#include <string.h>
#include "vxadp.h"
#include "dsp_msg.h" // 包含 udpmsg_ic.h
#include "list.h"
#include "exprn.h"

#include "rruinfo.h"
#include "dpdcommon.h"
#include "funccommon.h"
#include "dpd_app.h"
#include "msgproc.h"
#include "bsppub.h"

static const char *dpd_msg_prn = "DpdMsg";
static UINT32 dpdmsgresendcount = 3;
#define MsgPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,dpd_msg_prn),(level)|PM_PREFIX, ##fmt)
#define MsgBufPrint(level,fmt...) PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,dpd_msg_prn),(level), ##fmt)

#define CREAT_BUFF(buff,send,recv)                                      \
{                                                                       \
    UINT8 *buff = NULL;                                                 \
    THpiApiPDU *send = NULL;                                            \
    THpiApiPDU *recv = NULL;                                            \
    buff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));    \
    if (NULL == buff)                                                   \
    {                                                                   \
        ulRetVal |= BIT_SET(0);                                         \
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);             \
        return ulRetVal;                                                \
    }                                                                   \
    memset((VOID *)buff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));   \
    send = (THpiApiPDU *)&buff[0];                                      \
    recv = (THpiApiPDU *)&buff[sizeof(THpiApiPDU)];                     \
}
#define RELEASE_BUFF(buff)      free(buff);




int timeOutMs=3000;
int numAPDU=0x8000;

#define DPD_UDP_SLEEP_TIMES    10
typedef enum
{
    CMD_NORMAL       = (0x0000), //操作正常
    REGISTER_WR_FAIL  = (0x1111), //FPGA寄存器读写异常
    PAR_FAIL            = (0x2222), //BSP发送命令无效，设置的参数异常
    CMD_FAIL           = (0x3333), //BSP发送命令无效，接受消息后操作结果异常
    STATUS_NO          = (0x4444), //当前状态不允许此命令
    DSP_CHK_FAIL       = (0x5555)  // DSP自检异常
} T_FAIL_STA;

UINT32 dspPrnTypeId = 0;
VOID SetDspPrnType(UINT32 type)
{
    dspPrnTypeId = type;
}

/**************************************************************************
  函数名 称： MsgResultProc
  功能 描述： 消息结果处理
  输入参数 ： chan - 通道号
  ucParaFromFile - 是否传送文件中的参数
  输出参数 ： 无
  返回值：       RETCODE_PASS                               成功
  HPI_RETCODE_NULL_PTR                 指针为空
  HPI_RETCODE_ERR_PARAM               参数错误
  HPI_LINK_SEQNUM_MISMATCH         链路不匹配
  HPI_LINK_UNKNOWN_LPDU               未知的数据包
  HPI_LINK_RETRY_EXCEED                超过最大的重发次数
  其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014//12/22                      V1.0      zfx        新建
 ***********************************************************************/
VOID MsgResultProc(UINT16 result)
{
    dbgInfoEx("result = %d\r\n",result);
}
THpiApiPDU g_send = {0,};
THpiApiPDU g_recv = {0,};
int g_dbgsendlen = 0;


/**************************************************************************
    函数名 称： DpdMsgBypass(*)
    功能 描述： 0x0001消息--DPD旁路控制
    输入参数 ： chan        - 通道号
                freqNo - 频段号
                ctrl   -  控制字：0x5A5A，使能；0x2D2D，禁用
    输出参数 ： 无
    返回值      ：       BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    * 2014/12/15                      V1.0      zfx       新建
 ***********************************************************************/
UINT32 DpdMsgBypass(UINT32 chan, UINT32 freqNo, UINT16 type, UINT16 ctrl)
{

    UINT32     retVal = BSP_OK;
    UINT16     msgType = 0;
    UINT16     msgLen = 0;
    UINT8     *pucApiBuff = NULL;

    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
      retVal |= BIT_SET(0);
      dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
      return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    msgType = DPD_MSG_DPDBYPASS;
    msgLen  = sizeof(send->msg.ctrlBypass);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;

    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.ctrlBypass.ctrl = DPD_HTONS(ctrl);
    send->msg.ctrlBypass.type = DPD_HTONS(type);

    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg error!\n",__FUNCTION__,chan);
        free(pucApiBuff);
        return retVal;
    }

   retVal = DPD_NTOHS(recv->msg.ctrlBypassAck.result);
   MsgResultProc(retVal);
   free(pucApiBuff);
   return retVal;
}

UINT32 g_DpdMsgStartCtrl0[32] = {0,};
UINT32 g_DpdMsgStartCtrl1[32] = {0,};
UINT32 g_DpdMsgStartCtrl2[32] = {0,};
UINT32 g_DpdMsgStartCtrl3[32] = {0,};
UINT32 g_DpdMsgStartCtrl4[32] = {0,};
/**************************************************************************
    函数名 称： DpdMsgStartCtrl(*)
    功能 描述： 0x0002消息--DPD功能启动/叫停
    输入参数 ： chan        - 通道号
                freqNo - 频段号
                ctrl   -  控制字：0x5A5A，使能；0x2D2D，禁用
    输出参数 ： 无
    返回值      ：       BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    * 2014/12/15                      V1.0      zfx       新建
 ***********************************************************************/
UINT32 DpdMsgStartCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl)
{
   UINT32   retVal = BSP_OK;
   UINT16   swFlag = (UINT16)ctrl;
   UINT16   msgLen = sizeof(T_DpdMsgCtrl);
   UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16   msgType = DPD_MSG_DPDCTRL;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;
   UINT32   retVal1 = BSP_OK;

   //coverity[cert_int30_c_violation:SUPPRESS]
   //coverity[cert_ctr50_cpp_violation:SUPPRESS]
   g_DpdMsgStartCtrl0[chan]++; //临时增加，方便dsp定位startdpd失败场景，后续删除
   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
   }
   memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;
   send->msg.startCtrl.ctrl = DPD_HTONS(swFlag);
   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)typeId;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;
   BspLog(LOG_LEVEL_1,"%s{chan %d bandId %d swFlag %#x} \n",__FUNCTION__,chan,freqNo,swFlag);

   if (BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
   {
       //coverity[cert_int30_c_violation:SUPPRESS]
       //coverity[cert_ctr50_cpp_violation:SUPPRESS]
       g_DpdMsgStartCtrl1[chan]++;                          //临时增加，方便dsp定位startdpd失败场景，后续删除
       //coverity[cert_ctr50_cpp_violation:SUPPRESS]
       g_DpdMsgStartCtrl2[chan] = retVal1;                  //临时增加，方便dsp定位startdpd失败场景，后续删除
       //coverity[cert_ctr50_cpp_violation:SUPPRESS]
       g_DpdMsgStartCtrl3[chan] = send->head.chan;          //临时增加，方便dsp定位startdpd失败场景，后续删除
       //coverity[cert_ctr50_cpp_violation:SUPPRESS]
       g_DpdMsgStartCtrl4[chan] = send->msg.startCtrl.ctrl; //临时增加，方便dsp定位startdpd失败场景，后续删除
       if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
       {
           retVal |= BIT_SET(1);
           dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
           free(pucApiBuff);
           return retVal;
       }
   }

   retVal = DPD_NTOHS(recv->msg.startCtrlAck.result);
   free(pucApiBuff);
   MsgResultProc(retVal);
   return retVal;
}

/*上行模拟抵消*/
/* Started by AICoder, pid:h51c8u94b6nd82a142b50bd7004d55578da2714e */
UINT32 DpdMsgOffsetStartCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl)
{
   UINT32   retVal = BSP_OK;
   UINT16   swFlag = (UINT16)ctrl;
   UINT16   msgLen = sizeof(T_DpdMsgOffsetCtrl);
   UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16   msgType = DPD_MSG_OFFSET_CTRL;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
   }
   zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU),0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;
   send->msg.startOffsetCtrl.ctrl = DPD_HTONS(swFlag);
   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)typeId;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;
   BspLog(LOG_LEVEL_1,"%s{chan %d bandId %d swFlag %#x} \n",__FUNCTION__,chan,freqNo,swFlag);

   if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
   {
       retVal |= BIT_SET(1);
       dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
       free(pucApiBuff);
       return retVal;
   }

   retVal = DPD_NTOHS(recv->msg.startCtrlAck.result);
   free(pucApiBuff);
   MsgResultProc(retVal);
   return retVal;
}
/* Ended by AICoder, pid:h51c8u94b6nd82a142b50bd7004d55578da2714e */

/* Started by AICoder, pid:y334b60ef3tc6b5140b00a7e10a5ec578dd394b4 */
/* 模拟抵消参数配置 */
UINT32 DpdMsgCntrctCfg(UINT32 chan, UINT32 freqNo, T_DpdMsgCntrctCfg *cntrctPara)
{
   UINT32   retVal = BSP_OK;
   UINT16   msgLen = sizeof(T_DpdMsgCntrctCfg);
   UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16   msgType = DPD_MSG_CNTRCT_CFG;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

   INPUT_POINTER_CHECK(cntrctPara);

   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
   }
   zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU),0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;
   send->msg.cntrctParaCfg.uCntrctTH0 = DPD_HTONL(cntrctPara->uCntrctTH0);
   send->msg.cntrctParaCfg.uCntrctTH1 = DPD_HTONL(cntrctPara->uCntrctTH1);
   send->msg.cntrctParaCfg.uCntrctTH2 = DPD_HTONL(cntrctPara->uCntrctTH2);
   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)typeId;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;
   BspLog(LOG_LEVEL_1,"%s{chan %d bandId %d TH0 %d, TH1 %d, TH2 %d} \n",\
           __FUNCTION__, chan, freqNo, cntrctPara->uCntrctTH0, cntrctPara->uCntrctTH1, cntrctPara->uCntrctTH2);

   if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
   {
       retVal |= BIT_SET(1);
       dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
       free(pucApiBuff);
       return retVal;
   }

   retVal = DPD_NTOHS(recv->msg.startCtrlAck.result);
   free(pucApiBuff);
   MsgResultProc(retVal);
   return retVal;
}
/* Ended by AICoder, pid:y334b60ef3tc6b5140b00a7e10a5ec578dd394b4 */

/* Started by AICoder, pid:j0da1914e1xfa5214bb60a1fb03e0c6a95566631 */
/**************************************************************************
函数名 称： DpdMsgAIiotNetworkMode(*)
功能 描述： 0x1D02消息--AIOT整机组网模式
输入参数 ： 
          
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgAIiotNetworkMode(T_DpdMsgNetworkModeCfg *NetworkModeCfg)
{
    UINT32   retVal = BSP_OK;
    UINT16   msgLen = sizeof(T_DpdMsgNetworkModeCfg);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_NETWORKMODE_CFG;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(NetworkModeCfg);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU),0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;
    send->msg.networkModeCfg.uNetworkMode = DPD_HTONL(NetworkModeCfg->uNetworkMode);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;
    BspLog(LOG_LEVEL_1,"%s{uNetworkMode %d} \n",\
        __FUNCTION__,  NetworkModeCfg->uNetworkMode);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.networkModeCfgAck.result);
    free(pucApiBuff);
    MsgResultProc(retVal);

    return retVal;
}
/* Ended by AICoder, pid:j0da1914e1xfa5214bb60a1fb03e0c6a95566631 */

/**************************************************************************
函数名 称： DpdMsgTsFlagCtrl(*)
功能 描述： 0x002A消息--清除DPD 表格
输入参数 ： chan        - 通道号
            ctrl   -  控制字：1，使能；0，禁用
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgTsFlagCtrl(UINT32 chanmask, UINT32 ctrl)
{
   UINT32   retVal = BSP_OK;
   UINT16   msgLen = sizeof(T_DpdMsgCtrl);
   UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16   msgType = DPD_MSG_TS_CTRLFLAG;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;
   UINT32   retVal1 = BSP_OK;

   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
   }
   memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = 0;
   send->head.band    = 0;
   send->msg.tsCtrlMsg.uiChMsk = DPD_HTONS(chanmask);
   send->msg.tsCtrlMsg.uiTsTypeMsk = DPD_HTONS(ctrl);
   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)typeId;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;

   if (BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
   {
       if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
       {
           retVal |= BIT_SET(1);
           dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
           free(pucApiBuff);
           return retVal;
       }
   }

   retVal = DPD_NTOHS(recv->msg.tsCtrlRecMsg.result);
   free(pucApiBuff);
   MsgResultProc(retVal);
   return retVal;
}
/**************************************************************************
函数名 称： DpdMsgClrLut(*)
功能 描述： 0x0003消息--清除DPD 表格
输入参数 ： chan        - 通道号
            ctrl   -  控制字：0x5A5A，使能；0x2D2D，禁用
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgClrLut(UINT32 chan,UINT32 freqNo, UINT32 ctrl)
{
   UINT32     retVal = BSP_OK;
   UINT16     msgLen = 0;
   UINT16     msgType = DPD_MSG_CLEARLUT;

   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
         retVal |= BIT_SET(0);
         dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
         return retVal;
   }

   memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

   msgLen = sizeof(send->msg.lutClr);

   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;

   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;

   retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
   if (retVal != BSP_OK)
   {
       MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(pucApiBuff);
       return retVal;
   }

   retVal = DPD_NTOHS(recv->msg.lutClrAck.result);
   MsgResultProc(retVal);
   free(pucApiBuff);
   return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgVswrStart(*)
 功能 描述： 0x0004消息--开启VSWR
 输入参数 ： chan        - 通道号
             ctrl   -  控制字：0x5A5A，使能；0x2D2D，禁用
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgVswrStart(UINT32 chan,UINT32 freqNo)
{
    UINT32   retVal = BSP_OK;
    UINT32   swFlag = (UINT16)0x5A5A;
    UINT32   freqstep = BspGetDpdVswrFreqStep();;
    UINT32   freqnum = BspGetDpdVswrPointNum(chan);
    UINT32   vswrproflag = BspGetDpdVswrMode();
    UINT32   msgLen = sizeof(T_DpdMsgVswrCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_STARTVSWR;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    //NCR机型FDD四个通道不做vswr
    if((IS_NCR == BspIsNcr()) && (chan < 4))
    {
        return BSP_ERROR;
    }

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) +sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU)  + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;
    send->head.srcId   = GetUdpSrcId();
    send->head.dstId   = GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = MSG_REQ;
    send->msg.vswrCtrl.vswrstartctr = DPD_HTONL(swFlag);
    send->msg.vswrCtrl.sigfreqstep  = DPD_HTONL(freqstep);
    send->msg.vswrCtrl.sigfrenum    = DPD_HTONL(freqnum);
    send->msg.vswrCtrl.vswrproflag  = DPD_HTONL(vswrproflag);
    send->lenAPDU                   = sizeof(send->head) +  msgLen;
    BspLog(LOG_LEVEL_1,"%s{chan %d bandId %d swFlag %#x} \n",__FUNCTION__,chan,freqNo,swFlag);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
     {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.vswrCtrlAck.result);
    free(pucApiBuff);
    MsgResultProc(retVal);
    return retVal;
}

/**************************************************************************
 * 函数名称： DpdMsgVswrStop(*)
 * 功能描述： 0x04消息--关闭VSWR
 * 输入参数： chan   - 中频通道号,
 *            freqNo -
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 对于A9622D规格射频通道号需要转换为中频通道号
 *            ctrl- 控制字：0x5A5A，使能；0x2D2D，禁用
 * 修改日期      版本号     修改人        修改内容
 * ------------------------------------------------------------------------
 * 2014/12/15     V1.0       zfx           新建
 **************************************************************************/
UINT32 DpdMsgVswrStop(UINT32 chan,UINT32 freqNo)
{
   UINT32   retVal = BSP_OK;
   /* UINT16   result; */
   UINT16   swFlag = (UINT16)0x2D2D;
   UINT16   msgLen = sizeof(T_DpdMsgCtrl);

   UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16   msgType = DPD_MSG_STARTVSWR;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
    return retVal;
}
   memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;
   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)typeId;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->msg.startCtrl.ctrl = DPD_HTONS(swFlag);
   send->lenAPDU      = sizeof(send->head) + msgLen;
   BspLog(LOG_LEVEL_1,"%s{chan %d bandId %d swFlag %#x} \n",__FUNCTION__,chan,freqNo,swFlag);

   if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
   {
       retVal |= BIT_SET(1);
       dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
              __FUNCTION__, typeId, msgType, retVal);
   }


   retVal = DPD_NTOHS(recv->msg.startCtrlAck.result);
   free(pucApiBuff);
   MsgResultProc(retVal);
   return retVal;
}
/**************************************************************************
 函数名 称： GetDspVer
 功能 描述： 0x8002消息--DSP版本查询
 输入参数 ： chan - 通道号
 pDspVer - 版本信息
 输出参数 ： 无
 返回值：       RETCODE_PASS: 成功
RETCODE_ERROR: 失败
HPI_RETCODE_NULL_PTR: 指针为空
HPI_RETCODE_ERR_PARAM: 参数错误
HPI_LINK_SEQNUM_MISMATCH:bySeqnum和发送的值不一致，链路不匹配
HPI_LINK_UNKNOWN_LPDU:未知的数据包
HPI_LINK_RETRY_EXCEED:超过最大的重发次数
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2011/01/19                      V1.0      李超        新建
***********************************************************************/
UINT32 DpdMsgGetVer(UINT32 chan,UINT8 *pDspVer,UINT32 verLen)
{
   UINT32     retVal = BSP_OK;
   /* UINT16     result; */
   UINT16     recvMsgLen = DPD_HTONL(0x1234);
   UINT16     msgLen = 0;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];


    msgLen = sizeof(send->msg.dspVer);

   send->head.msgType = DPD_HTONS(DPD_MSG_DSPVER);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)0;

   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;

   retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
   if (retVal != BSP_OK)
   {
       MsgPrint(PM_ERROR,"%s chan=%d send msg error!\n",__FUNCTION__,chan);
       free(pucApiBuff);
       return retVal;
   }
   recvMsgLen = DPD_NTOHS(recv->head.msgLen);
   memcpy_s(pDspVer,min(recvMsgLen,verLen),recv->msg.buf,min(recvMsgLen,verLen));
   free(pucApiBuff);
   return retVal;
}

/**************************************************************************
+ 函数名 称： GetAcpCalResult
+ 功能 描述： 0x8015消息--acp结果查询
+ 输入参数 ： chan - 通道号
+ T_DpdMsgAcpCalResultAck - acp结果
+ 输出参数 ： 无
+ 返回值：       RETCODE_PASS: 成功
+RETCODE_ERROR: 失败
+HPI_RETCODE_NULL_PTR: 指针为空
+HPI_RETCODE_ERR_PARAM: 参数错误
+HPI_LINK_SEQNUM_MISMATCH:bySeqnum和发送的值不一致，链路不匹配
+HPI_LINK_UNKNOWN_LPDU:未知的数据包
+HPI_LINK_RETRY_EXCEED:超过最大的重发次数
+其他说明 ： 无
+* 修改日期        版本号     修改人           修改内容
+* -----------------------------------------------
+* 2021/04/15                      V1.0      任驰        新建
+***********************************************************************/
UINT32 DpdMsgGetAcpCalResult(UINT32 chan, T_DpdMsgAcpCalResultAck *pAcpCalResult)
{
   UINT32     retVal = BSP_OK;
   UINT16     recvMsgLen = DPD_HTONL(0x1234);
   UINT16     msgLen = 0;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

    DPD_CHAN_CHECK(chan);
    INPUT_POINTER_CHECK(pAcpCalResult);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.acpCalResult);

   send->head.msgType = DPD_HTONS(DPD_MSG_ACPRESULT);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)0;

   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;

   retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
   if (retVal != BSP_OK)
   {
       MsgPrint(PM_ERROR,"%s chan=%d send msg error!\n",__FUNCTION__,chan);
       free(pucApiBuff);
       return retVal;
   }

   recvMsgLen = DPD_NTOHS(recv->head.msgLen);
   memcpy_s(pAcpCalResult, sizeof(T_DpdMsgAcpCalResultAck), &recv->msg.acpCalResultAck, recvMsgLen);
   free(pucApiBuff);

   return retVal;
}

/**************************************************************************
函数名 称： DpdMsgUploadData(*)
功能 描述： 0xC003消息--上传数据
输入参数 ： chan        - 通道号
            freqNo   -
            pdata - 参数结构体
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgUploadData(UINT32 typeId,UINT32 chan,UINT32 freqNo, UINT32 datatype,UCHAR *pdata,UINT32 *plen)
{
    /* UINT8 *pucTmpBuff = NULL; */
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16     msgLen = 0;

    UINT32     retVal = BSP_OK;
    /* UINT16     result; */

    UINT16     msgType = DPD_MSG_TBLUPLOAD;
    UINT16     swDataType = (UINT16)datatype;
    UINT32     i = 0;
    UINT16 apduNum = 0xFFFF;
    UCHAR *pbyTemp = NULL;
    UINT32 recvlen = 0;
    /* UINT32 j = 0; */
    INPUT_POINTER_CHECK(pdata);
    INPUT_POINTER_CHECK(plen);

    pbyTemp = pdata;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    while(1)
    {
        memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

        send = (THpiApiPDU *)&pucApiBuff[0];
        recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

        send->lenAPDU      = sizeof(send->head) + msgLen;
        send->head.msgType = UDPMSG_HTONS(msgType);
        send->head.numAPDU = UDPMSG_HTONS(apduNum);;
        send->head.msgLen  = UDPMSG_HTONS(msgLen);
        send->head.chan    = (UINT8)chan;
        send->head.band    = (UINT8)freqNo;

        send->head.srcId    = (UINT8)GetUdpSrcId();
        send->head.dstId    = (UINT8)GetUdpDstId();
        send->head.typeId    = (UINT8)typeId;
        send->head.recvEn    = (UINT8)GetReqOrAck();

        send->msg.upLoad.dataType = DPD_HTONS(swDataType);

        retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
        if (retVal != BSP_OK)
        {
            MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
            break;
        }

        memcpy_s(pbyTemp, min(DPD_NTOHS(recv->head.msgLen),sizeof(T_DpdMsgUploadDataAck)), &recv->msg.upLoadAck.data[0], min(DPD_NTOHS(recv->head.msgLen),sizeof(T_DpdMsgUploadDataAck)));

        pbyTemp += DPD_NTOHS(recv->head.msgLen);
        recvlen += DPD_NTOHS(recv->head.msgLen);

        /*is the last msg*/
        if(0 == DPD_NTOHS(recv->head.numAPDU))
        {
            /*last msg*/
            MsgPrint(PM_INFO,"Receive complete!Msg NO. is %d.Total length is %ld!\n", i+1,recvlen);
            *plen = recvlen;
            break;
        }
        else
        {
            apduNum = DPD_NTOHS(recv->head.numAPDU) -1;
        }

   }
   MsgResultProc(retVal);
   free(pucApiBuff);
   return retVal;
}

/**************************************************************************
函数名 称： DpdMsgDownloadData(*)
功能 描述： 0xC005消息--下传数据
输入参数 ： chan        - 通道号
            freqNo   -
            pdata - 参数结构体
            plen - 长度
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgDownloadData(UINT32 chan, TUdpApiHeader *headInfo, UCHAR *pdata,UINT32 *plen)
{
    /* UINT8 *pucTmpBuff = NULL; */
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32     retVal = 0;
    /* UINT16     result; */
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_TBLDOWNLOAD;
    UINT16 apduNum = 0xFFFF;
    UINT8 typeId = 0;
    UINT8 *pbyTemp = NULL;
    /* UINT32 recvlen = 0; */
    /* UINT32 j = 0; */
    UINT16 packetNum;
    /* UINT16 packetSize; */
    UINT16 sentdataLen = 0;

    INPUT_POINTER_CHECK(pdata);
    INPUT_POINTER_CHECK(plen);

    if((0 == *plen) || (MAX_DPD_DOWN_LOAD_TABLE_SIZE < *plen))
    {
        MsgPrint(PM_ERROR,"Table Length error!\n");
        return BSP_ERROR;
    }

    pbyTemp = pdata;
    packetNum = (UINT16)((*plen-1) / MAX_DPD_MSG_BODY + 1);
    apduNum = packetNum - 1;
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
   while(1)
   {
        memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

        send = (THpiApiPDU *)&pucApiBuff[0];
        recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

        send->head.msgType = UDPMSG_HTONS(msgType);
        send->head.numAPDU = (apduNum == (packetNum - 1))? DPD_HTONS((1<<15) | apduNum) : DPD_HTONS(apduNum);;

        if(apduNum == 0)
        {
            msgLen  = (*plen- (MAX_DPD_MSG_BODY * (packetNum - 1)));
        }
        else
        {
            msgLen = MAX_DPD_MSG_BODY;
        }

        send->head.msgLen  = UDPMSG_HTONS(msgLen);
        send->head.chan    = (UINT8)chan;
        send->head.band    = headInfo->band;

        send->head.srcId    = (UINT8)GetUdpSrcId();
        send->head.dstId    = (UINT8)GetUdpDstId();
        send->head.typeId    = headInfo->typeId;
        send->head.recvEn    = (UINT8)GetReqOrAck();
        send->head.module    = headInfo->module;
        send->head.powGrd    = headInfo->powGrd;
        send->lenAPDU      = sizeof(send->head) + msgLen;
        memcpy_s(&send->msg.download.data[0], min(msgLen,sizeof(T_DpdMsgDownloadData)), pbyTemp, min(msgLen,sizeof(T_DpdMsgDownloadData)));

        typeId = headInfo->typeId;
        retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
        if (retVal != BSP_OK)
        {
            MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
            break;
        }

        retVal = DPD_NTOHS(recv->msg.downloadAck.result);
        if(retVal != DPD_UPLOAD_OVER)
        {
            MsgPrint(PM_ERROR,"%s chan=%d recv ret 0x%04x,error!\n",__FUNCTION__,chan,msgType);
            continue;
        }

        sentdataLen += msgLen;
        if(0 == apduNum)
        {
            /*last msg*/
            MsgPrint(PM_INFO,"Send complete!.Total length is %d!\n", sentdataLen);
            break;
        }

        pbyTemp += msgLen;
        apduNum--;
   }
   MsgResultProc(retVal);
   free(pucApiBuff);

   return retVal;
}

/*****************************************************************************
*  函数名称   : DpdMsgDownloadDataNew
*  功能描述   : 0x4024消息--下传数据
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : chan - 通道号
*          headInfo - 消息头信息
*          pdata - 下传数据
*          dataLen - 下传数据长度
*  输出参数   : 无
*  返 回 值 : BSP_OK 或 BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XX@2023-05-15
*----------------------------------------------------------------------------
*/
UINT32 DpdMsgDownloadDataNew(UINT32 chan, TUdpApiHeader *headInfo, UCHAR *pdata,UINT32 dataLen)
{
    UINT32 retVal = 0;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_TBLDOWNLOAD_NEW;
    UINT8 *pbyTemp = NULL;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(headInfo);
    INPUT_POINTER_CHECK(pdata);

    if(MSG_TRAP_EMBED_LUT_LEN_MAX < dataLen)
    {
        MsgPrint(PM_ERROR, "Table Length[%d] error!\n", dataLen);
        return BSP_ERROR;
    }

    pbyTemp = pdata;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.trapEmbedLutInfo);

    //coverity[cert_exp39_c_violation:SUPPRESS]
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = chan;
    send->head.band     = 0;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->head.module   = headInfo->module;
    send->head.powGrd   = headInfo->powGrd;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    send->msg.trapEmbedLutInfo.ch = DPD_HTONL(chan);
    send->msg.trapEmbedLutInfo.grdVldMsk = DPD_HTONL(*pbyTemp + (*(pbyTemp + 1) << 8) + (*(pbyTemp + 2) << 16) + (*(pbyTemp + 3) << 24));
    memcpy_s(&send->msg.trapEmbedLutInfo.lutDat[0], dataLen - 4, pbyTemp + 4, dataLen - 4);
    dbgInfoEx("[%s] chan = %d, the first data = 0x%x, the second data = 0x%x\n", __FUNCTION__, chan, send->msg.trapEmbedLutInfo.grdVldMsk, *(pbyTemp + 4));
    dbgInfo("------------ TRAP INFO ANALYSE OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x, error!\n", __FUNCTION__, 0, msgType);
        free(pucApiBuff);
        return retVal;
    }
    dbgInfo("------------ SEND DSP MSG OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = DPD_NTOHS(recv->msg.trapEmbedLutInfoAck.result);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] Recv Msg Result = %d\r\n", __func__, retVal);
    }
    dbgInfo("------------ RECV DSP MSG OVER ------------\n");

    free(pucApiBuff);
    return retVal;
}

/*****************************************************************************
*  函数名称   : DpdMsgDownloadGainTblData
*  功能描述   : 0x4025消息--下传增益相位补偿表数据
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : pdata - 下传数据
*  输出参数   : 无
*  返 回 值 : BSP_OK 或 BSP_ERROR;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XX@2023-06-15
*----------------------------------------------------------------------------
*/
UINT32 DpdMsgDownloadGainTblData(UINT32 chan, UCHAR *pdata, UINT32 dataLen)
{
    UINT32 retVal = 0;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_GAINTBLDOWNLOAD;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.trapEmbedLutInfo);

    //coverity[cert_exp39_c_violation:SUPPRESS]
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = chan;
    send->head.band     = 0;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    dbgInfoEx("[%s] dataLen = %d!\n", __FUNCTION__, dataLen);
    memcpy_s(send->msg.gainTuneTblInfo.atTbl, dataLen, pdata, dataLen);
    dbgInfoEx("[%s] first data = %#x\n", __FUNCTION__, send->msg.gainTuneTblInfo.atTbl[0].gainVal);
    dbgInfoEx("[%s] last data = %#x\n", __FUNCTION__, send->msg.gainTuneTblInfo.atTbl[MSG_GAIN_TUNE_TEMP_NUM_MAX*MSG_PA_VOLT_GRD_MAX-1].vldFlg);
    dbgInfo("------------ TRAP INFO ANALYSE OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x, error!\n", __FUNCTION__, 0, msgType);
        free(pucApiBuff);
        return retVal;
    }
    dbgInfo("------------ SEND DSP MSG OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = DPD_NTOHS(recv->msg.gainTuneTblInfoAck.result);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] Recv Msg Result = %d\r\n", __func__, retVal);
    }
    dbgInfo("------------ RECV DSP MSG OVER ------------\n");

    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
函数名 称： DpdMsgGetDpdStr(*)
功能 描述： 0xC007消息--查询VSWR
输入参数 ： chan        - 通道号
            freqNo   -
            T_DpdMsgPrintStr - 读取的值
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetDpdStr(UINT32 chan,UINT32 freqNo, T_DpdMsgPrintStr *pdata)
{
   UINT32     retVal  = 0;
   UINT16     msgType = DPD_MSG_GETDPDSTRINFO;
   UINT16 apduNum = 0xFFFF;
   UINT16 i = 0;
   UINT16 recvTotalLen= 0;
   UINT8 *pbyTemp = NULL;
   UINT8 *pbyPrintArray = NULL;
   THpiApiPDU     *send = NULL;
   THpiApiPDU     *recv = NULL;
   UINT8   typeId =(UINT8)HEAD_TYPE_ID_SOC_ACDSP;

   if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
   {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        return BSP_ERROR;
   }
   if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
   {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        free(send);
        return BSP_ERROR;
   }
   memset((VOID *)send, 0, sizeof(THpiApiPDU));
   memset((VOID *)recv, 0, sizeof(THpiApiPDU));
   UINT16 msgLen = (UINT16)sizeof(send->msg.printStr);
   UINT16 recvsize = 0;

   if(pdata == NULL)
   {
        free(send);
        free(recv);
        return BSP_ERROR;
   }

       typeId = HEAD_TYPE_ID_SOC_DSP;


   while(1)
   {
       send->head.msgType = DPD_HTONS(msgType);
       send->head.numAPDU = DPD_HTONS(apduNum);
       send->head.msgLen  = DPD_HTONS(msgLen);
       send->head.chan      = (UINT8)chan;
       send->head.band      = (UINT8)freqNo;

       send->head.srcId    = (UINT8)GetUdpSrcId();
       send->head.dstId    = (UINT8)GetUdpDstId();
       send->head.typeId    = (UINT8)typeId;
       send->head.recvEn    = (UINT8)MSG_REQ;
       send->lenAPDU      = sizeof(send->head) + msgLen;

       send->msg.printStr.data0 = DPD_HTONL(pdata->data0);
       send->msg.printStr.data1 = DPD_HTONL(pdata->data1);
       send->msg.printStr.data2 = DPD_HTONL(pdata->data2);
       send->msg.printStr.data3 = DPD_HTONL(pdata->data3);
       send->msg.printStr.data4 = DPD_HTONL(pdata->data4);
       send->msg.printStr.data5 = DPD_HTONL(pdata->data5);
       send->msg.printStr.powGrd = DPD_HTONL(pdata->powGrd);
       send->msg.printStr.index = DPD_HTONL(pdata->index);

       retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
       if (retVal != BSP_OK)
       {
           MsgPrint(PM_ERROR,"Receive not complete!Error msg NO.: %d\n", i);
           break;
       }
       apduNum = DPD_NTOHS(recv->head.numAPDU);

       /*contruct recv data struct*/
       if(NULL ==  pbyPrintArray)
       {
           pbyPrintArray = (UCHAR *)malloc((apduNum + 1) * MAX_DPD_MSG_BODY + 1);
           if(NULL == pbyPrintArray)
           {
               free(send);
               free(recv);
               return BSP_ERROR;
           }
           memset(pbyPrintArray,0,(apduNum+1)*MAX_DPD_MSG_BODY + 1);
           pbyTemp = pbyPrintArray;
       }

       /*Receive data, data is char ,no need to htons*/
       recvsize = min(DPD_NTOHS(recv->head.msgLen),sizeof(T_DpdMsgPrintStrAck));
       if((pbyTemp - pbyPrintArray + recvsize)<((apduNum + 1) * MAX_DPD_MSG_BODY + 1))
       {
           if(sizeof(recv->msg.printStrAck)<recvsize)
           {
               free(send);
               free(recv);
               free(pbyPrintArray);
               return BSP_ERROR;
           }
              memcpy_s(pbyTemp, recvsize, &recv->msg.printStrAck.data, recvsize);
       }
       else
       {
           break;
       }

       pbyTemp += recvsize;
       recvTotalLen += recvsize;

       /*is the last msg*/
       if(0 == DPD_NTOHS(recv->head.numAPDU))
       {
           break;
       }
       else
       {
           apduNum = DPD_NTOHS(recv->head.numAPDU) -1;
       }

       i++;

   }

   if(NULL != pbyPrintArray)
   {
       RedirPrintf("DPD Info : \n %s \n",(CHAR *)pbyPrintArray);
       free(pbyPrintArray);
   }
   MsgResultProc(retVal);
   free(send);
   free(recv);

   return retVal;
}

/**************************************************************************
函数名 称： DpdMsgGetDog(*)
功能 描述： 0x8005消息--获取狗信息
输入参数 ： chan        - 通道号
            freqNo   -
            pdata - 参数结构体
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetDog(UINT32 chan,UINT32 freqNo, UINT32 *pWatchDogCnt)
{
   //THpiApiPDU send = {0,};
   //THpiApiPDU recv = {0,};
   UINT32 retVal = BSP_OK;
   UINT32 msgLen = 0;
   UINT32 msgType = 0;
   UINT8  *pucApiBuff = NULL;
   THpiApiPDU *send = NULL;
   THpiApiPDU *recv = NULL;

   INPUT_POINTER_CHECK(pWatchDogCnt);

   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
   }
   memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
   msgType = DPD_MSG_CHECEKWATCHDOG;
   msgLen  = sizeof(send->msg.getdogCnt);

   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;

   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
   send->head.recvEn    = (UINT8)MSG_REQ;

   send->lenAPDU      = sizeof(send->head) + msgLen;

   retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU*)send, (THpiApiPDU*)recv);
   if (retVal != BSP_OK)
   {
       MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(pucApiBuff);
       return retVal;
   }

   *pWatchDogCnt = DPD_NTOHS(recv->msg.getdogCntAck.count);
   MsgResultProc(retVal);
   free(pucApiBuff);
   return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSetFrameSlotCfg(*)
 功能 描述： 4010消息--时隙配比信息下发
 输入参数 ： slotIndex  - GP最多的S时隙下标
           gpNum      - GP个数
 输出参数 ： 无
 返回值      ： BSP_OK: 成功
             其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgSetFrameSlotCfg(UINT32 chan, UINT32 freqNo, UINT32 slotIndex, UINT32 gpNum)
{
    UINT32     retVal=BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SEND_FRAMESLOT_INFO;   //4010,时隙配比信息下发
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen  = sizeof(send->msg.framePatternInfo);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.framePatternInfo.slotIndex = DPD_HTONL(slotIndex);
    send->msg.framePatternInfo.gpNum = DPD_HTONL(gpNum);
    dbgInfo("%s slotIndex = %d, gpNum = %d \n", __FUNCTION__, slotIndex, gpNum);


    retVal = SendHpiMsg((UINT16)(GET_DSP_ID(chan)), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.framePatternInfoAck.result);
    MsgResultProc((UINT16)retVal);

    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
函数名 称： DpdMsgGetState(*)
功能 描述： 0x8001消息--查询DPD下表张数
输入参数 ： chan         - 通道号
      lutLevel     - 分档等级
输出参数 ：pNum         - 下表数目
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2018/06/06                      V1.0      10105163       新建
***********************************************************************/
UINT32 DpdMsgGetState(UINT32 chan,UINT32 freqNo, T_DpdMsgStateQueryRet *pAck)
{
   UINT8  *pucApiBuff = NULL;
   THpiApiPDU *send = NULL;
   THpiApiPDU *recv = NULL;
   UINT32    retVal = BSP_OK;
   UINT16    msgLen = 0;
   UINT16   msgType = 0;
   INPUT_POINTER_CHECK(pAck);

   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
   }
   memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

   msgLen = sizeof(send->msg.stateQuery);
   msgType = DPD_MSG_DPDSTATUS;

   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;

   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
   send->head.recvEn   = (UINT8)MSG_REQ;
   send->lenAPDU       = sizeof(send->head) + msgLen;

   retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
   if (retVal != BSP_OK)
   {
       MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(pucApiBuff);
       return retVal;
   }

   pAck->iDownLutCnt = DPD_NTOHL(recv->msg.stateQueryAck.iDownLutCnt);
   pAck->iFixDlySta  = DPD_NTOHL(recv->msg.stateQueryAck.iFixDlySta);

    free(pucApiBuff);

   return retVal;
}





/**************************************************************************
 函数名 称： DpdMsgGetVswrSta(*)
 功能 描述： 0xC007消息--查询VSWR
 输入参数 ： chan        - 通道号
             freqNo   -
             T_DpdMsgVswrCheckAck - 读取的值
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetVswrSta(UINT32 chan,UINT32 freqNo,UINT32 *pstate)
{
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16    msgLen = 0;
    UINT16   msgType = 0;
    UINT32    retVal = BSP_OK;
    INPUT_POINTER_CHECK(pstate);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    msgLen = sizeof(send->msg.vswrCheck);
    msgType = DPD_MSG_CHECKSTATE;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    *pstate = DPD_NTOHL(recv->msg.vswrCheckAck.state);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
函数名 称： DpdMsgSetPara(*)
功能 描述： 0x4001消息--设置单个参数
输入参数 ： chan        - 通道号
            freqNo   -
            pdata - 参数结构体
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgSetPara(UINT32 chan,UINT32 freqNo, T_DpdMsgSetSignalPara *pdata)
{
   UINT32 retVal = BSP_OK;
   /* UINT16 result; */
   UINT16 msgLen = sizeof(T_DpdMsgSetSignalPara);

   UINT8   typeId = HEAD_TYPE_ID_SOC_ACDSP;
   UINT16   msgType = DPD_MSG_SETDPDPARAM;
   UINT8    *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

   INPUT_POINTER_CHECK(pdata);

   typeId = HEAD_TYPE_ID_SOC_DSP;
   pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
   }
   memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = (THpiApiPDU *)&pucApiBuff[0];
   recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;

   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)typeId;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;

   send->msg.setPara.index_modul = DPD_HTONL(pdata->index_modul);
   send->msg.setPara.index_func = DPD_HTONL(pdata->index_func);
   send->msg.setPara.par0 =  DPD_HTONL(pdata->par0);
   send->msg.setPara.par1 = DPD_HTONL(pdata->par1);
   send->msg.setPara.par2 = DPD_HTONL(pdata->par2);
   send->msg.setPara.par3 = DPD_HTONL(pdata->par3);
   send->msg.setPara.par4 = DPD_HTONL(pdata->par4);
   send->msg.setPara.par5 = DPD_HTONL(pdata->par5);
   send->msg.setPara.par6 = DPD_HTONL(pdata->par6);


   if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
   {
       retVal |= BIT_SET(1);
       dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
              __FUNCTION__, typeId, msgType, retVal);
       free(pucApiBuff);
       return retVal;
   }

   retVal = DPD_NTOHS(recv->msg.setParaAck.result);

   free(pucApiBuff);
   MsgResultProc(retVal);
   return retVal;
}

/**************************************************************************
     函数名 称： DpdMsgPimcCtrl(*)
     功能 描述： 0x0008消息--PIMC启动训练和停止训练启动预训练
     输入参数 ： chan        - 通道号
                 freqNo - 频段号
                 ctrl   -  控制字：0x5A5A IMC启动训练;
                                   0x2D2D 停止训练;
                                   0x5555 启动预训练
     输出参数 ： 无
     返回值      ：       BSP_OK: 成功
                其他: 失败
     其他说明 ： 无
  ***********************************************************************/
 UINT32 DpdMsgPimcCtrl(UINT32 chan, UINT32 freqNo, UINT32 ctrl)
{
    UINT16 swFlag =0;
    UINT16 msgLen = 0;
    UINT16 msgType =0;
    UINT32 retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    swFlag = (UINT16)ctrl;
    msgLen = sizeof(send->msg.pimcCtrl);
    msgType = DPD_MSG_PIMCCTRL;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;

    send->msg.pimcCtrl.ctrl = DPD_HTONS(swFlag);
    send->lenAPDU      = sizeof(send->head) + msgLen;
    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.pimcCtrlAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgPimcClrTbl(*)
 功能 描述： 0x0009消息--清PIMC 表格
 输入参数 ： chan        - 通道号
             freqNo - 频段号
 输出参数 ： 无
 返回值      ：  BSP_OK: 成功
                 其他: 失败
 其他说明 ： 无
***********************************************************************/
UINT32 DpdMsgPimcClrTbl(UINT32 chan,UINT32 freqNo)
{
    UINT16     msgLen = 0;
    UINT16    msgType = 0;
    UINT32    retVal  = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.pimcClrTbl);
    msgType = DPD_MSG_PIMCCLEARTBL;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.pimcClrTblAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}



/**************************************************************************
 函数名 称： DpdMsgGetVswrVal(*)
 功能 描述： 0xC007消息--查询VSWR
 输入参数 ： chan        - 通道号
             freqNo   -
             T_DpdMsgVswrQueryAck - 读取的值
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetVswrVal(UINT32 chan,UINT32 freqNo, T_DpdMsgVswrQueryAck *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT16 msgLen = sizeof(T_DpdMsgVswrQueryAck);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_GETVSWR;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
        __FUNCTION__, typeId, msgType, retVal);
    }
    pdata->iVswrCalFlag = DPD_NTOHL(recv->msg.vwswrQueryAck.iVswrCalFlag);
    pdata->iVswrSamFlag = DPD_NTOHL(recv->msg.vwswrQueryAck.iVswrSamFlag);
    pdata->iSpaNum = DPD_NTOHL(recv->msg.vwswrQueryAck.iSpaNum);
    if(pdata->iSpaNum > SIG_FRE_NUM_MAX)
    {
        free(pucApiBuff);
        return BSP_ERROR;
    }
    for(loop = 0; loop <  pdata->iSpaNum; loop++)
    {
        pdata->spaData[loop].vswrReal = DPD_NTOHL(recv->msg.vwswrQueryAck.spaData[loop].vswrReal);
        pdata->spaData[loop].vswrImag = DPD_NTOHL(recv->msg.vwswrQueryAck.spaData[loop].vswrImag);
        pdata->spaData[loop].nco = DPD_NTOHL(recv->msg.vwswrQueryAck.spaData[loop].nco);
    }
    free(pucApiBuff);

    return retVal;
}


/**************************************************************************
 函数名 称： DpdMsgDspLoadState(*)
 功能 描述： 0x8008消息--查询DSP加载状态
 输入参数 ： chan        - 通道号
             freqNo   -
             pstate- 读取的值
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgDspLoadState(UINT32 chan,UINT32 freqNo,UINT32 *pstate)
{
    UINT16     msgLen = 0;
    UINT16    msgType = 0;
    UINT32     retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    INPUT_POINTER_CHECK(pstate);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.dspLoadState);
    msgType = DPD_MSG_DSPLOADSTATE;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    *pstate = DPD_NTOHL(recv->msg.dspLoadStateAck.state);
    free(pucApiBuff);
    return retVal;
}



/**************************************************************************
 函数名 称： DpdMsgRdFpgaReg(*)
 功能 描述： 0xC006消息--获取FPGA的寄存器的值
 输入参数 ： chan        - 通道号
             freqNo
             addr   -
             pRddata - 读取的值
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgRdFpgaReg(UINT32 chan,UINT32 freqNo, UINT32 addr, UINT32 *pRddata)
{
    UINT16     msgLen = 0;
    UINT16    msgType = 0;
    UINT16     swaddr = 0;
    UINT32     retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    INPUT_POINTER_CHECK(pRddata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];


    msgLen = sizeof(send->msg.fpgaCmd);
    msgType = DPD_MSG_CTRL_FPGA_REG;
    swaddr = (UINT16)addr;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.fpgaCmd.cmd = DPD_HTONS(DPD_RD_FPGA_REG);
    send->msg.fpgaCmd.mask = DPD_HTONS(0xFFFF);
    send->msg.fpgaCmd.addr = DPD_HTONS(swaddr);

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.fpgaCmdAck.result);
    *pRddata = DPD_NTOHS(recv->msg.fpgaCmdAck.readVal);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgWrFpgaReg(*)
 功能 描述： 0xC006消息--获取FPGA的寄存器的值
 输入参数 ： chan        - 通道号
             freqNo
             addr   -
             pRddata - 读取的值
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgWrFpgaReg(UINT32 chan,UINT32 freqNo, UINT32 addr, UINT32 data)
{
    UINT16     msgLen = 0;
    UINT16    msgType = 0;
    UINT16     swaddr = 0;
    UINT16     swdata = 0;
    UINT32     retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    msgLen = sizeof(send->msg.fpgaCmd);
    msgType = DPD_MSG_CTRL_FPGA_REG;
    swaddr = (UINT16)addr;
    swdata = (UINT16)data;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.fpgaCmd.cmd = DPD_HTONS(DPD_WR_FPGA_REG);
    send->msg.fpgaCmd.mask = DPD_HTONS(0xFFFF);
    send->msg.fpgaCmd.addr = DPD_HTONS(swaddr);
    send->msg.fpgaCmd.data = DPD_HTONS(swdata);

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.fpgaCmdAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSampleCtrl(*)
 功能 描述： 0x0C00消息--PIM_OnLine获取整机级硬件信息
 输入参数 ： PIM_OnLine获取整机级硬件信息
 输出参数 ： 无
 返回值      ：BSP_OK: 成功
              其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 *
***********************************************************************/
UINT32 DpdPimOnlineRruInfoCfg(T_PimOnlineRruInfoMsg *rruCfgInfo)
{
    UINT32   retVal = BSP_OK;
    UINT32   chanId = 0;
    UINT32   bandId = 0;
    UINT16   msgLen = sizeof(T_PimOnlineRruInfoMsg);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIMONLINE_RRUINFO_MSG;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    if(NULL == rruCfgInfo)
    {
        dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);

    send->msg.pimOnlineRruInfoMsg.dlValidChNum = DPD_HTONL(rruCfgInfo->dlValidChNum);
    for(chanId = 0; chanId < min(rruCfgInfo->dlValidChNum, PIMONLINE_RRU_MAX_CHAN_NUM); chanId++)
    {
        send->msg.pimOnlineRruInfoMsg.dlChInfo[chanId].chipIdx = DPD_HTONL(rruCfgInfo->dlChInfo[chanId].chipIdx);
        send->msg.pimOnlineRruInfoMsg.dlChInfo[chanId].chanId = DPD_HTONL(rruCfgInfo->dlChInfo[chanId].chanId);
        send->msg.pimOnlineRruInfoMsg.dlChInfo[chanId].bandNum = DPD_HTONL(rruCfgInfo->dlChInfo[chanId].bandNum);
        for(bandId = 0; bandId < min(rruCfgInfo->dlChInfo[chanId].bandNum, MAX_BAND_NUM_PER_CHAN); bandId++)
        {
            send->msg.pimOnlineRruInfoMsg.dlChInfo[chanId].txDflFreqL[bandId] = DPD_HTONL(rruCfgInfo->dlChInfo[chanId].txDflFreqL[bandId]);
            send->msg.pimOnlineRruInfoMsg.dlChInfo[chanId].txDflFreqH[bandId] = DPD_HTONL(rruCfgInfo->dlChInfo[chanId].txDflFreqH[bandId]);
        }
    }

    send->msg.pimOnlineRruInfoMsg.ulValidChNum = DPD_HTONL(rruCfgInfo->ulValidChNum);
    for(chanId = 0; chanId < min(rruCfgInfo->ulValidChNum, PIMONLINE_RRU_MAX_CHAN_NUM); chanId++)
    {
        send->msg.pimOnlineRruInfoMsg.ulChInfo[chanId].chipIdx = DPD_HTONL(rruCfgInfo->ulChInfo[chanId].chipIdx);
        send->msg.pimOnlineRruInfoMsg.ulChInfo[chanId].chanId = DPD_HTONL(rruCfgInfo->ulChInfo[chanId].chanId);
        send->msg.pimOnlineRruInfoMsg.ulChInfo[chanId].bandNum = DPD_HTONL(rruCfgInfo->ulChInfo[chanId].bandNum);
        for(bandId = 0; bandId < min(rruCfgInfo->ulChInfo[chanId].bandNum, MAX_BAND_NUM_PER_CHAN); bandId++)
        {
            send->msg.pimOnlineRruInfoMsg.ulChInfo[chanId].rxDflFreqL[bandId] = DPD_HTONL(rruCfgInfo->ulChInfo[chanId].rxDflFreqL[bandId]);
            send->msg.pimOnlineRruInfoMsg.ulChInfo[chanId].rxDflFreqH[bandId] = DPD_HTONL(rruCfgInfo->ulChInfo[chanId].rxDflFreqH[bandId]);
        }
    }

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHS(recv->msg.pimOnlineRecvAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSampleCtrl(*)
 功能 描述： 0xC001消息--启动采数状态
 输入参数 ： chan        - 通道号
             freqNo   -
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgSampleCtrl(UINT32 typeId,UINT32 chan,UINT32 freqNo,UINT32 ctrl, T_DpdMsgSampleCtrl *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = 0;
    /* UINT8 *pucTmpBuff = NULL; */
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];



    msgType = (1 == ctrl) ? DPD_MSG_BSPSAMCTRL : DPD_MSG_BSPSAMSTOP;
    msgLen = (1 == ctrl) ? sizeof(send->msg.sampleCtrl) : sizeof(send->msg.sampleQuit);

    send->head.msgType = UDPMSG_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = UDPMSG_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId = (UINT8)GetUdpSrcId();
    send->head.dstId = (UINT8)GetUdpDstId();
    send->head.typeId = (UINT8)typeId;
    send->head.recvEn = GetReqOrAck();

    send->lenAPDU = sizeof(send->head) + msgLen;

    if(1 == ctrl)
    {
        send->msg.sampleCtrl.OffLineSampFlg = DPD_HTONS(pdata->OffLineSampFlg);
        send->msg.sampleCtrl.OffLinePos = DPD_HTONS(pdata->OffLinePos);
    }
    else
    {
        /*msg body is null*/
    }
    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
                __FUNCTION__, typeId, msgType, retVal);
    }

    retVal = (1 == ctrl) ? DPD_NTOHS(recv->msg.sampleCtrlAck.result) : DPD_NTOHS(recv->msg.sampleQuitAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}



/**************************************************************************
 函数名 称： DpdMsgGetSamStatus(*)
 功能 描述： 0xC002消息--获取采数状态
 输入参数 ： chan        - 通道号
             freqNo   -
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetSamStatus(UINT32 typeId,UINT32 chan,UINT32 freqNo, UINT32 *pState)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgType = DPD_MSG_BSPSAMDONE;
    INPUT_POINTER_CHECK(pState);

    /* UINT8 *pucTmpBuff = NULL; */
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16     msgLen = 0;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    send->lenAPDU      = sizeof(send->head) + msgLen;
    send->head.msgType = UDPMSG_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = UDPMSG_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)GetReqOrAck();

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
                __FUNCTION__, typeId, msgType, retVal);
    }

    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    *pState = DPD_NTOHS(recv->msg.sampleQueAck.state);
    MsgResultProc(retVal);

    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSetCellCfg(*)
 功能 描述： 0x4005消息--设置小区配置信息
 输入参数 ： chan          - 通道号
             freqNo   - 频段号
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ： BSP_OK: 成功
             其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgSetCellCfg(UINT32 chan,UINT32 freqNo,T_DpdMsgSetDlCellCfgPara *pdata)
{
    UINT32     retVal=BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SETCELLCFG;
    UINT32     loop = 0;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen  = sizeof(send->msg.setCellCfgPara);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    for(loop=0; loop<DPD_UDP_IC42_MAX_CARR_NUM; ++loop)
    {
        send->msg.setCellCfgPara.atDlCarrPara[loop].dlSwitchFlag  = DPD_HTONL(pdata->atDlCarrPara[loop].dlSwitchFlag);
        send->msg.setCellCfgPara.atDlCarrPara[loop].radioMode     = DPD_HTONL(pdata->atDlCarrPara[loop].radioMode);
        send->msg.setCellCfgPara.atDlCarrPara[loop].carrPow       = DPD_HTONL(pdata->atDlCarrPara[loop].carrPow);
        send->msg.setCellCfgPara.atDlCarrPara[loop].carrNco1      = DPD_HTONL(pdata->atDlCarrPara[loop].carrNco1);
        send->msg.setCellCfgPara.atDlCarrPara[loop].carrNco2      = DPD_HTONL(pdata->atDlCarrPara[loop].carrNco2);
        send->msg.setCellCfgPara.atDlCarrPara[loop].carrBandWidth = DPD_HTONL(pdata->atDlCarrPara[loop].carrBandWidth);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiSubCarrierSpacing       = DPD_HTONL(pdata->atDlCarrPara[loop].uiSubCarrierSpacing);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiSsbGscn      = DPD_HTONL(pdata->atDlCarrPara[loop].uiSsbGscn);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiSsbSubBeamValidL      = DPD_HTONL(pdata->atDlCarrPara[loop].uiSsbSubBeamValidL);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiSsbSubBeamValidH      = DPD_HTONL(pdata->atDlCarrPara[loop].uiSsbSubBeamValidH);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiSsbPeriod = DPD_HTONL(pdata->atDlCarrPara[loop].uiSsbPeriod);
        send->msg.setCellCfgPara.atDlCarrPara[loop].iFraAHeadAdj = DPD_HTONL(pdata->atDlCarrPara[loop].iFraAHeadAdj);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiCarrPortNum = DPD_HTONL(pdata->atDlCarrPara[loop].uiCarrPortNum);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiBankId = DPD_HTONL(pdata->atDlCarrPara[loop].uiBankId);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiCarrId = DPD_HTONL(pdata->atDlCarrPara[loop].uiCarrId);
        send->msg.setCellCfgPara.atDlCarrPara[loop].uiSsbRfFreq = DPD_HTONL(pdata->atDlCarrPara[loop].uiSsbRfFreq);
        send->msg.setCellCfgPara.atDlCarrPara[loop].carrCopyType = DPD_HTONL(pdata->atDlCarrPara[loop].carrCopyType);
        send->msg.setCellCfgPara.atDlCarrPara[loop].ssbSymbolFlag = DPD_HTONS(pdata->atDlCarrPara[loop].ssbSymbolFlag);
        send->msg.setCellCfgPara.atDlCarrPara[loop].ssbSymbolIndex = DPD_HTONS(pdata->atDlCarrPara[loop].ssbSymbolIndex);
        dbgInfoEx("[%s] ssb2port test carr = %d, ssbSymbolFlag = %u, ssbSymbolIndex = %u\n", __FUNCTION__, loop, send->msg.setCellCfgPara.atDlCarrPara[loop].ssbSymbolFlag, send->msg.setCellCfgPara.atDlCarrPara[loop].ssbSymbolIndex);

    }
    /*载波通道级信息*/
    send->msg.setCellCfgPara.dlValidCarrNum = DPD_HTONL(pdata->dlValidCarrNum);
    send->msg.setCellCfgPara.loFlg        = DPD_HTONL(pdata->loFlg);
    send->msg.setCellCfgPara.dlLoFreq       = DPD_HTONL(pdata->dlLoFreq);
    send->msg.setCellCfgPara.fb_nco    = DPD_HTONL(pdata->fb_nco);
     /*通道级TDD表象信息*/
    send->msg.setCellCfgPara.tFrameInfo.uiTddCfgId  = DPD_HTONL(pdata->tFrameInfo.uiTddCfgId);
    send->msg.setCellCfgPara.tFrameInfo.uiCarrNo    = DPD_HTONL(pdata->tFrameInfo.uiCarrNo);
    send->msg.setCellCfgPara.tFrameInfo.uiRadioMode = DPD_HTONL(pdata->tFrameInfo.uiRadioMode);
    send->msg.setCellCfgPara.tFrameInfo.uiChanMask  = DPD_HTONL(pdata->tFrameInfo.uiChanMask);
    send->msg.setCellCfgPara.tFrameInfo.uiDlUlSwNum = DPD_HTONL(pdata->tFrameInfo.uiDlUlSwNum);
/* Started by AICoder, pid:tca9f49d93sa0d914d7b0b8030bc632018539952 */
    dbgInfoEx("[%s] uiTddCfgId:%u\n",__FUNCTION__,send->msg.setCellCfgPara.tFrameInfo.uiTddCfgId);
    dbgInfoEx("[%s] uiCarrNo:%u\n",__FUNCTION__,send->msg.setCellCfgPara.tFrameInfo.uiCarrNo);
    dbgInfoEx("[%s] uiRadioMode:%u\n",__FUNCTION__,send->msg.setCellCfgPara.tFrameInfo.uiRadioMode);
    dbgInfoEx("[%s] uiChanMask:%u\n",__FUNCTION__,send->msg.setCellCfgPara.tFrameInfo.uiChanMask);
    dbgInfoEx("[%s] uiDlUlSwNum:%u\n",__FUNCTION__,send->msg.setCellCfgPara.tFrameInfo.uiDlUlSwNum);
/* Ended by AICoder, pid:tca9f49d93sa0d914d7b0b8030bc632018539952 */
    for(loop=0; loop<MAX_UL_DL_SW_NUM; ++loop)
    {
        send->msg.setCellCfgPara.tFrameInfo.uiDlUlSwPeriod[loop] = DPD_HTONL(pdata->tFrameInfo.uiDlUlSwPeriod[loop]);
        send->msg.setCellCfgPara.tFrameInfo.uiDlSymbolNum[loop] = DPD_HTONL(pdata->tFrameInfo.uiDlSymbolNum[loop]);
        send->msg.setCellCfgPara.tFrameInfo.uiUlSymbolNum[loop] = DPD_HTONL(pdata->tFrameInfo.uiUlSymbolNum[loop]);
        dbgInfoEx("[%s] uiDlUlSwPeriod[%d]:%d",__FUNCTION__,loop,send->msg.setCellCfgPara.tFrameInfo.uiDlUlSwPeriod[loop]);
        dbgInfoEx("[%s] uiDlSymbolNum[%d]:%d",__FUNCTION__,loop,send->msg.setCellCfgPara.tFrameInfo.uiDlSymbolNum[loop]);
        dbgInfoEx("[%s] uiUlSymbolNum[%d]:%d",__FUNCTION__,loop,send->msg.setCellCfgPara.tFrameInfo.uiUlSymbolNum[loop]);
    }
    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.setCellCfgParaAck.result);
    MsgResultProc(retVal);

    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSetActiveFlag(*)
 功能 描述： 0x0032消息--传递载波激活标志信息
 输入参数 ： chan          - 通道号
             freqNo   - 频段号
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ： BSP_OK: 成功
             其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgSetActiveFlag(UINT32 chan, UINT32 freqNo, T_DspDlCellSwiInfo *pdata)
{
    UINT32     retVal=BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_CARR_SWITCH_FLAG;
    UINT32     loop = 0;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen  = sizeof(send->msg.tDspDlCellActiveInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    for(loop=0; loop<DPD_UDP_IC42_MAX_CARR_NUM; ++loop)
    {
        send->msg.tDspDlCellActiveInfo.atDlCarrSwiInfo[loop].uiCarrId        = DPD_HTONL(pdata->atDlCarrSwiInfo[loop].uiCarrId);
        send->msg.tDspDlCellActiveInfo.atDlCarrSwiInfo[loop].uiRadioMode     = DPD_HTONL(pdata->atDlCarrSwiInfo[loop].uiRadioMode);
        send->msg.tDspDlCellActiveInfo.atDlCarrSwiInfo[loop].uiDlSwitchFlag  = DPD_HTONL(pdata->atDlCarrSwiInfo[loop].uiDlSwitchFlag);
        
    }
    send->msg.tDspDlCellActiveInfo.uiDlValidCarrNum = DPD_HTONL(pdata->uiDlValidCarrNum);

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.tDspDlCellActiveInfoAck.result);
    MsgResultProc(retVal);

    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendDmmCfg(*)
 功能描述： 0x0203消息--DMIMO配置下发消息
 输入参数： difChan - 通道号
             freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendDmmCfg(UINT32 chan, UINT32 bandId,T_DmmCfgMsg * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_DMIMO_CFG;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.dmmCfgMsg);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)bandId;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dmmCfgMsg.uiCarrDmimoSwi = DPD_HTONL(pdata->uiCarrDmimoSwi);
    send->msg.dmmCfgMsg.uiCarrId = DPD_HTONL(pdata->uiCarrId);
    send->msg.dmmCfgMsg.uiCellId = DPD_HTONL(pdata->uiCellId);
    send->msg.dmmCfgMsg.uiCpId = DPD_HTONL(pdata->uiCpId);
    send->msg.dmmCfgMsg.uiDmimoL2dAddr = DPD_HTONL(pdata->uiDmimoL2dAddr);
    send->msg.dmmCfgMsg.uiDlPreBankId = DPD_HTONL(pdata->uiDlPreBankId);
    send->msg.dmmCfgMsg.uiDlPreOriDly = DPD_HTONL(pdata->uiDlPreOriDly);
    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);

    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendDmmCfg(*)
 功能描述： 0x0204消息--utdoa配置下发消息
 输入参数： difChan - 通道号
             freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
/* Started by AICoder, pid:c9e26h2f677b169145280993c0a5455e716393fd */
UINT32 DpdMsgSendUtdoaCfg(UINT32 chan, UINT32 bandId,T_UtdoaCfgMsg * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_UTDOA_CFG;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.utdoaCfgMsg);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;   // 暂时保留吧  虽然没啥用
    send->head.band    = (UINT8)bandId; // 暂时保留吧  虽然没啥用
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.utdoaCfgMsg.caliPeriod = DPD_HTONL(pdata->caliPeriod);
    send->msg.utdoaCfgMsg.offset     = DPD_HTONL(pdata->offset);
    send->msg.utdoaCfgMsg.utEn       = DPD_HTONL(pdata->utEn);
    
    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);

    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    free(pucApiBuff);
    return retVal;
}
/* Ended by AICoder, pid:c9e26h2f677b169145280993c0a5455e716393fd */

/**********************************************************************
 函数名称： DpdSetDmmCfgClrFlg(*)
 功能描述： 0x0202消息--控制DMIMO配置信息清零的消息
 输入参数： difChan - 通道号
             freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdSetDmmCfgClrFlg(T_DmmCfgInfoClrMsg * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_DMIMO_CFGCLR;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    
    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    
    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.dmmCfgInfoClrMsg);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dmmCfgInfoClrMsg.uiDmmCfgClrFlg = DPD_HTONL(pdata->uiDmmCfgClrFlg);

    retVal = SendHpiMsg(0, send, recv);
    
   
    MsgPrint(PM_INFO,"[%s]uiDmmCfgClrFlg[%d]\n",__FUNCTION__, pdata->uiDmmCfgClrFlg);

    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s send msg 0x%04x,error!\n",__FUNCTION__,msgType);
        free(pucApiBuff);
        return retVal;
    }
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}
UINT32 DpdMsgSetUlCellCfg(UINT32 chan,UINT32 freqNo,T_DpdMsgSetUlCellCfgPara *pdata)
{
    UINT32     retVal=BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SETULCELLCFG;
    UINT32     loop = 0;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU)+ sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen  = sizeof(send->msg.setCellCfgPara);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head)  +msgLen;

    for(loop=0; loop<DPD_UDP_IC42_MAX_CARR_NUM;++loop)
    {
       send->msg.setUlCellCfgPara.tCellCfgPara[loop].ulSwitchFlag  = DPD_HTONL(pdata->tCellCfgPara[loop].ulSwitchFlag);
        send->msg.setUlCellCfgPara.tCellCfgPara[loop].radioMode     = DPD_HTONL(pdata->tCellCfgPara[loop].radioMode);
        send->msg.setUlCellCfgPara.tCellCfgPara[loop].bankNco      = DPD_HTONL(pdata->tCellCfgPara[loop].bankNco);
        send->msg.setUlCellCfgPara.tCellCfgPara[loop].bandNco      = DPD_HTONL(pdata->tCellCfgPara[loop].bandNco);
        send->msg.setUlCellCfgPara.tCellCfgPara[loop].carrBandWidth   = DPD_HTONL(pdata->tCellCfgPara[loop].carrBandWidth);
        send->msg.setUlCellCfgPara.tCellCfgPara[loop].carrPow       = DPD_HTONL(pdata->tCellCfgPara[loop].carrPow);
      }

    send->msg.setUlCellCfgPara.ulValidCarrNum = DPD_HTONL(pdata->ulValidCarrNum);
    send->msg.setUlCellCfgPara.ulLoFreq          = DPD_HTONL(pdata->ulLoFreq);

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.setCellCfgParaAck.result);
    MsgResultProc(retVal);

    free(pucApiBuff);

    return retVal;
}
/**************************************************************************
 函数名 称： DpdMsgSendTsInfo(*)
 功能 描述： 0x4016消息--设置小区配置信息
 输入参数 ： chan          - 通道号
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ： BSP_OK: 成功
             其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgSendTsInfo(UINT32 chan,UINT32 freqNo,T_DpdMsgCellTsInfo *pdata)
{
    UINT32     retVal=BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SEND_TS_INFO;
    UINT32     loop = 0;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;


    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }


    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen  = sizeof(send->msg.tsInfo);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId() & 0xff;
    send->head.dstId    = (UINT8)GetUdpDstId() & 0xff;
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    for(loop=0; loop<DPD_UDP_IC42_MAX_CARR_NUM; ++loop)
    {
        send->msg.tsInfo.cellTsData[loop].cellId      = DPD_HTONL(pdata->cellTsData[loop].cellId);
        send->msg.tsInfo.cellTsData[loop].carrNo      = DPD_HTONL(pdata->cellTsData[loop].carrNo);
        send->msg.tsInfo.cellTsData[loop].radioMode     = DPD_HTONL(pdata->cellTsData[loop].radioMode);
        send->msg.tsInfo.cellTsData[loop].cfgCarrPwr      = DPD_HTONL(pdata->cellTsData[loop].cfgCarrPwr);
        send->msg.tsInfo.cellTsData[loop].txFreq      = DPD_HTONL(pdata->cellTsData[loop].txFreq);
        send->msg.tsInfo.cellTsData[loop].rxFreq      = DPD_HTONL(pdata->cellTsData[loop].rxFreq);
        send->msg.tsInfo.cellTsData[loop].txBandWitdh      = DPD_HTONL(pdata->cellTsData[loop].txBandWitdh);
        send->msg.tsInfo.cellTsData[loop].rxBandWitdh      = DPD_HTONL(pdata->cellTsData[loop].rxBandWitdh);
        send->msg.tsInfo.cellTsData[loop].bandNco = DPD_HTONL(pdata->cellTsData[loop].bandNco);
        send->msg.tsInfo.cellTsData[loop].carrNco = DPD_HTONL(pdata->cellTsData[loop].carrNco);
        send->msg.tsInfo.cellTsData[loop].tranNco = DPD_HTONL(pdata->cellTsData[loop].tranNco);
        send->msg.tsInfo.cellTsData[loop].fbNco = DPD_HTONL(pdata->cellTsData[loop].fbNco);
    }

    send->msg.tsInfo.cellNum = DPD_HTONL(pdata->cellNum);
    send->msg.tsInfo.txLo = DPD_HTONL(pdata->txLo);
    send->msg.tsInfo.fbLo = DPD_HTONL(pdata->fbLo);
    send->msg.tsInfo.dflStartFreq = DPD_HTONL(pdata->dflStartFreq);
    send->msg.tsInfo.dflEndFreq = DPD_HTONL(pdata->dflEndFreq);
    send->msg.tsInfo.dpdTxRate = DPD_HTONL(pdata->dpdTxRate);
    send->msg.tsInfo.dpdFbRate = DPD_HTONL(pdata->dpdFbRate);
    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.tsInfoAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSendRruInfo(*)
 功能 描述： 0x4006消息--发送整机信息
 输入参数 ： difChan        - 通道号
             freqNo   -
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/

UINT32 DpdMsgSendRruInfo(UINT32 chan,UINT32 freqNo, T_DpdMsgSendRruInfo *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT32 chanNum = 0;
    UINT32 loop = 0;
    UINT32 portloop = 0;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_SENDRRUINFO;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32 index = 0;
    UINT32 result = 0;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendRruInfo);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.sendRruInfo.validDlChanNum     = DPD_HTONL(pdata->validDlChanNum);
    send->msg.sendRruInfo.validUlChanNum     = DPD_HTONL(pdata->validUlChanNum);
    send->msg.sendRruInfo.paType      = DPD_HTONL(pdata->paType);
    send->msg.sendRruInfo.moduleGrpId = DPD_HTONL(pdata->moduleGrpId);
    send->msg.sendRruInfo.boardGrpId  = DPD_HTONL(pdata->boardGrpId);
    send->msg.sendRruInfo.boardTypeId = DPD_HTONL(pdata->boardTypeId);
    send->msg.sendRruInfo.hwChangeId  = DPD_HTONL(pdata->hwChangeId);
    send->msg.sendRruInfo.hwDefIdA  = DPD_HTONL(pdata->hwDefIdA);
    send->msg.sendRruInfo.hwDefIdB  = DPD_HTONL(pdata->hwDefIdB);
    send->msg.sendRruInfo.exceptReason  = DPD_HTONL(pdata->exceptReason);
    send->msg.sendRruInfo.exceptChanMask  = DPD_HTONL(pdata->exceptChanMask);
    send->msg.sendRruInfo.rfBridgeFlag  = DPD_HTONL(pdata->rfBridgeFlag);
    chanNum = pdata->validDlChanNum;
    for(loop = 0; loop < chanNum; loop++)
    {
        send->msg.sendRruInfo.dlChanHwInfo[loop].fullPow    = DPD_HTONL(pdata->dlChanHwInfo[loop].fullPow);
        send->msg.sendRruInfo.dlChanHwInfo[loop].bandNum    = DPD_HTONL(pdata->dlChanHwInfo[loop].bandNum);
        for(index = 0; index< pdata->dlChanHwInfo[loop].bandNum; index++)
        {
            send->msg.sendRruInfo.dlChanHwInfo[loop].txDflFreqL[index] = DPD_HTONL(pdata->dlChanHwInfo[loop].txDflFreqL[index]);
            send->msg.sendRruInfo.dlChanHwInfo[loop].txDflFreqH[index] = DPD_HTONL(pdata->dlChanHwInfo[loop].txDflFreqH[index]);
        }
        send->msg.sendRruInfo.dlChanHwInfo[loop].tddNo = DPD_HTONL(pdata->dlChanHwInfo[loop].tddNo);
        dbgInfoEx("loop %d tddNo %d\n",loop,send->msg.sendRruInfo.dlChanHwInfo[loop].tddNo);
        for(portloop = 0; portloop < MSG_MAX_FREQ_NUM; portloop++)
        {

            send->msg.sendRruInfo.dspDlRouteInfo[loop].uiCfrPort[portloop] = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiCfrPort[portloop]);
            send->msg.sendRruInfo.dspDlRouteInfo[loop].uiDpdPort[portloop] = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiDpdPort[portloop]);
            send->msg.sendRruInfo.dspDlRouteInfo[loop].uiDlpostPort[portloop] = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiDlpostPort[portloop]);
            send->msg.sendRruInfo.dspDlRouteInfo[loop].uiCfrBlockInPort[portloop] = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiCfrBlockInPort[portloop]);
        }
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiCfrPortNum = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiCfrPortNum);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiDpdPortNum = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiDpdPortNum);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiDlpostPortNum = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiDlpostPortNum);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiFbPort = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiFbPort);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiCfrSampRate = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiCfrSampRate);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiSrc2SampRate = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiSrc2SampRate);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiSrc3SampRate = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiSrc3SampRate);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiFb204cSampRate = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiFb204cSampRate);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiDpdMode = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiDpdMode);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiEtMode = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiEtMode);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiCfrBlockPortNum = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiCfrBlockPortNum);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiStagePortNum = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiStagePortNum);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiCfrBlockInPortNum = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiCfrBlockInPortNum);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiStageId = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiStageId);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiCfrGrade = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiCfrGrade);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiPortType = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiPortType);
        send->msg.sendRruInfo.dspDlRouteInfo[loop].uiDflType = DPD_HTONL(pdata->dspDlRouteInfo[loop].uiDflType);
    }
    chanNum = pdata->validUlChanNum;

    for(loop = 0; loop < chanNum; loop++)
    {
        send->msg.sendRruInfo.ulChanHwInfo[loop].bandNum    = DPD_HTONL(pdata->ulChanHwInfo[loop].bandNum);
        for(index = 0; index< pdata->ulChanHwInfo[loop].bandNum; index++)
        {
            send->msg.sendRruInfo.ulChanHwInfo[loop].rxDflFreqL[index] = DPD_HTONL(pdata->ulChanHwInfo[loop].rxDflFreqL[index]);
            send->msg.sendRruInfo.ulChanHwInfo[loop].rxDflFreqH[index] = DPD_HTONL(pdata->ulChanHwInfo[loop].rxDflFreqH[index]);
        }
     }

    send->msg.sendRruInfo.tFbCtrlInfo.fbCtrlTypeNum = DPD_HTONL(pdata->tFbCtrlInfo.fbCtrlTypeNum);
    for(loop = 0; loop < pdata->tFbCtrlInfo.fbCtrlTypeNum; loop++)
    {
        send->msg.sendRruInfo.tFbCtrlInfo.fb2DlMsk[loop]    = DPD_HTONL(pdata->tFbCtrlInfo.fb2DlMsk[loop]);
        send->msg.sendRruInfo.tFbCtrlInfo.fbCtrlSliceNum[loop] = DPD_HTONL(pdata->tFbCtrlInfo.fbCtrlSliceNum[loop]);
        for(index = 0; index< pdata->tFbCtrlInfo.fbCtrlSliceNum[loop]; index++)
        {
            if(pdata->tFbCtrlInfo.fbCtrlInfo[loop][index] == 0)
            {
                break;  /*只传一个通道的*/
            }
            send->msg.sendRruInfo.tFbCtrlInfo.fbCtrlInfo[loop][index] = DPD_HTONL(pdata->tFbCtrlInfo.fbCtrlInfo[loop][index]);
        }
     }
    send->msg.sendRruInfo.tDlClkInfo.cfrClk[0] = DPD_HTONL(pdata->tDlClkInfo.cfrClk[0]);
    send->msg.sendRruInfo.tDlClkInfo.dlpostClk[0] = DPD_HTONL(pdata->tDlClkInfo.dlpostClk[0]);
    send->msg.sendRruInfo.tDlClkInfo.dlpostClk[1] = DPD_HTONL(pdata->tDlClkInfo.dlpostClk[1]);
    send->msg.sendRruInfo.tDlClkInfo.dpdClk[0] = DPD_HTONL(pdata->tDlClkInfo.dpdClk[0]);
    send->msg.sendRruInfo.tDlClkInfo.dpdClk[1] = DPD_HTONL(pdata->tDlClkInfo.dpdClk[1]);

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    result = DPD_NTOHS(recv->msg.sendRruInfoAck.result);
    MsgResultProc(result);

    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendDmimoCtrl(*)
 功能描述： 0x0018消息--DMIMO软件处理控制开关
 输入参数： difChan - 通道号
             freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendDmimoCtrl(UINT32 chan, UINT32 bandId, T_DpdDmmCtrlMsg * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_DMIMO_CTRL;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.dpdDmmCtrlMsg);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)bandId;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dpdDmmCtrlMsg.uiDmmCtrlSwi = DPD_HTONL(pdata->uiDmmCtrlSwi);

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.dpdDmmCtrlMsgAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}

#define SLOT_VOLT_GPIOREGLEVEL_MAX_NUM (16)
#define SLOT_VOLT_REGLEVEL_MAX_NUM (8)
/**********************************************************************
 函数名称： DpdMsgSlotVoltCtrlCfg(*)
 功能描述： 0x0019消息--时隙调压控制配置
 输入参数： pdata - 参数结构体
 输出参数： 无
 返 回 值： BSP_OK: 成功    其他: 失败
 其他说明： 无
 修改日期：      1.0     10300780     增加0x0019时隙调压控制配置消息
***********************************************************************/
UINT32 DpdMsgSlotVoltCtrlCfg(T_DpdSlotVoltCtrlInfo *pdata)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_SLOT_VOLT_CTRL_CFG;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    if(MSG_PA_VOLT_CTRL_GRP_MAX < pdata->uiCtrlGrpIdx)
    {
        dbgErr("%s>>uiCtrlGrpNum[%d] Input Error[Max Value = 2]!\n", __FUNCTION__, pdata->uiCtrlGrpIdx);
        return BSP_ERROR;
    }
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendSlotVoltCtrlInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    /* 时隙调压控制配置信息 */
    send->msg.sendSlotVoltCtrlInfo.uiCtrlGrpIdx = DPD_HTONL(pdata->uiCtrlGrpIdx);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiFuncSwi = DPD_HTONL(pdata->atVoltSlotCtrl.uiFuncSwi);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiTopoType = DPD_HTONL(pdata->atVoltSlotCtrl.uiTopoType);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiChMsk = DPD_HTONL(pdata->atVoltSlotCtrl.uiChMsk);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiVldGrdNum = DPD_HTONL(pdata->atVoltSlotCtrl.uiVldGrdNum);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCfLevelNum = DPD_HTONL(pdata->atVoltSlotCtrl.uiCfLevelNum);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiVoltCtrlStep= DPD_HTONL(pdata->atVoltSlotCtrl.uiVoltCtrlStep);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiVoltCtrlMax = DPD_HTONL(pdata->atVoltSlotCtrl.uiVoltCtrlMax);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoAddr[0]= DPD_HTONL(pdata->atVoltSlotCtrl.uiIoAddr[0]);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoAddr[1]= DPD_HTONL(pdata->atVoltSlotCtrl.uiIoAddr[1]);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoAddr[2]= DPD_HTONL(pdata->atVoltSlotCtrl.uiIoAddr[2]);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoLevelNum = DPD_HTONL(pdata->atVoltSlotCtrl.uiIoLevelNum);
    send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoBitMask = DPD_HTONL(pdata->atVoltSlotCtrl.uiIoBitMask);

    dbgInfoEx("[%s] uiCtrlGrpIdx[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.uiCtrlGrpIdx);
    dbgInfoEx("[%s] uiFuncSwi[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiFuncSwi);
    dbgInfoEx("[%s] uiTopoType[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiTopoType);
    dbgInfoEx("[%s] uiChMsk[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiChMsk);
    dbgInfoEx("[%s] uiVldGrdNum[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiVldGrdNum);
    dbgInfoEx("[%s] uiCfLevelNum[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCfLevelNum);
    dbgInfoEx("[%s] uiVoltCtrlStep[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiVoltCtrlStep);
    dbgInfoEx("[%s] uiVoltCtrlMax[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiVoltCtrlMax);
    dbgInfoEx("[%s] uiIoAddr 0[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoAddr[0]);
    dbgInfoEx("[%s] uiIoAddr 1[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoAddr[1]);
    dbgInfoEx("[%s] uiIoAddr 2[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoAddr[2]);
    dbgInfoEx("[%s] uiIoLevelNum[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoLevelNum);
    dbgInfoEx("[%s] uiIoBitMask[%#x]\n",__func__,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoBitMask);

    dbgInfoEx("------------ PaVolt And  CFRLevel------------\n");
    for (loop = 0; loop < SLOT_VOLT_REGLEVEL_MAX_NUM; loop++)
    {
        /*电压档位对应的负载档位原始电压值，单位：mv*/
        send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiPaVolt[loop] = DPD_HTONL(pdata->atVoltSlotCtrl.uiPaVolt[loop]);
        /* 削峰门限 */
        send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCFRLevelTh[loop][0] = DPD_HTONL(pdata->atVoltSlotCtrl.uiCFRLevelTh[loop][0]);
        send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCFRLevelTh[loop][1] = DPD_HTONL(pdata->atVoltSlotCtrl.uiCFRLevelTh[loop][1]);
        send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCFRLevelTh[loop][2] = DPD_HTONL(pdata->atVoltSlotCtrl.uiCFRLevelTh[loop][2]);
        dbgInfoEx("------------ loop:%d--------------\n",loop);
        dbgInfoEx("[%s] uiPaVolt %d[%#x]\n",__func__,loop,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiPaVolt[loop]);
        dbgInfoEx("[%s] uiCFRLevelTh(%d,0)[%#x]\n",__func__,loop,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCFRLevelTh[loop][0]);
        dbgInfoEx("[%s] uiCFRLevelTh(%d,1)[%#x]\n",__func__,loop,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCFRLevelTh[loop][1]);
        dbgInfoEx("[%s] uiCFRLevelTh(%d,2)[%#x]\n",__func__,loop,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiCFRLevelTh[loop][2]);
    }

    dbgInfoEx("------------ Gpio TruthTable ------------\n");
    for (loop = 0; loop < SLOT_VOLT_GPIOREGLEVEL_MAX_NUM; loop++)
    {
        /* 真值表 */
        send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoMap[loop] = DPD_HTONL(pdata->atVoltSlotCtrl.uiIoMap[loop]);
        dbgInfoEx("[%s] uiIoMap %d[%#x]\n",__func__,loop,send->msg.sendSlotVoltCtrlInfo.atVoltSlotCtrl.uiIoMap[loop]);
    }
    dbgInfo("------------ SWITCH INFO ANALYSE OVER ------------\n");

    IcHalApiSetPsyncSlotVoltCtrl();
    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,0,msgType);
        free(pucApiBuff);
        return retVal;
    }
    dbgInfo("------------ SEND DSP MSG OVER ------------\n");
    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = DPD_NTOHL(recv->msg.sendSlotVoltCtrlInfoAck.uwResult);
    if(0 != retVal)
    {
        dbgErr("[%s] Recv Msg Result = %d\r\n",__func__,retVal);
    }
    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = DPD_NTOHL(recv->msg.sendSlotVoltCtrlInfoAck.uiCtrlFlg);
    if(0 != retVal)
    {
        dbgErr("[%s] Msg Alarm Code = %d\r\n",__func__,retVal);
    }
    dbgInfo("------------ RECV DSP MSG OVER ------------\n");

    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSlotVoltGrpCfg(*)
 功能描述： 0x001a消息--时隙调压调压组信息配置
 输入参数： pdata - 参数结构体
 输出参数： 无
 返 回 值： BSP_OK: 成功    其他: 失败
 其他说明： 无
 修改日期：      1.0     10300780     增加0x001a时隙调压调压组信息配置
***********************************************************************/
UINT32 DpdMsgSlotVoltGrpCfg(T_DpdSlotVoltGrpInfo *pdata)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_SLOT_VOLT_GRP_CFG;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendSlotVoltCtrlInfo);

    //coverity[cert_exp39_c_violation:SUPPRESS]
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    /* 时隙调压调压组配置信息 */
    send->msg.sendSlotVoltGrpInfo.uiCtrlGrpNum = DPD_HTONL(pdata->uiCtrlGrpNum);
    dbgInfoEx("[%s] uiCtrlGrpNum[%#x]\n",__func__, send->msg.sendSlotVoltGrpInfo.uiCtrlGrpNum);
    for (loop = 0; loop < MSG_PA_VOLT_CTRL_GRP_MAX; loop++)
    {
        /* 调压组包含的通道掩码 */
        send->msg.sendSlotVoltGrpInfo.uiChMsk[loop] = DPD_HTONL(pdata->uiChMsk[loop]);
        dbgInfoEx("[%s] uiChMsk %d[%#x]\n",__func__,loop,send->msg.sendSlotVoltGrpInfo.uiChMsk[loop]);
    }

    dbgInfo("------------ SWITCH INFO ANALYSE OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,0,msgType);
        free(pucApiBuff);
        return retVal;
    }
    dbgInfo("------------ SEND DSP MSG OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = DPD_NTOHS(recv->msg.sendSlotVoltGrpInfoAck.uwResult);
    if(0 != retVal)
    {
        dbgErr("[%s] Recv Msg Result = %d\r\n",__func__,retVal);
    }
    dbgInfo("------------ RECV DSP MSG OVER ------------\n");

    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendPowAdjInfo(*)
 功能描述： 0x4007消息--发送功率调整信息
 输入参数： difChan - 通道号
             freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendPowAdjInfo(UINT32 chan, UINT32 freqNo, T_DpdMsgSendPowAdjInfo * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SENDPOWADJINFO;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendPowAdjInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.sendPowAdjInfo.powAdjCnt = DPD_HTONL(pdata->powAdjCnt);

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.sendPowAdjInfoAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}
/**********************************************************************
 函数名称： DpdMsgSendPaInfo(*)
 功能描述： 0x4011消息--发送功放信息
 输入参数： difChan - 通道号
             freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendPaInfo(UINT32 chan, UINT32 freqNo, T_DpdMsgSendPaInfo * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     resLen = 0;
    UINT16     msgType = DPD_MSG_SENDPAINFO;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendPaInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId() & 0xff;
    send->head.dstId    = (UINT8)GetUdpDstId() & 0xff;
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    memcpy_s(send->msg.sendPaInfo.paDesign,SEND_PA_INFO_LEN,pdata->paDesign,sizeof(pdata->paDesign));
    memcpy_s(send->msg.sendPaInfo.ruProductTime,SEND_PA_INFO_LEN,pdata->ruProductTime,sizeof(pdata->ruProductTime));
    for(resLen = 0;resLen < 30; resLen++)
    {
        send->msg.sendPaInfo.reserve[resLen] = DPD_HTONL(pdata->reserve[resLen]);
    }

    retVal = SendHpiMsg((UINT16)(GET_DSP_ID(chan)), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.sendPaInfoAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgPimcPreTrainState(*)
 功能 描述： 0x800A消息--查询PIMC预训练状态
 输入参数 ： difChan - 中频通道号
             freqNo  -
             pstate  - 读取的值
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
                               其他: 失败
 其他说明 ： 无
***********************************************************************/
UINT32 DpdMsgPimcPreTrainState(UINT32 chan,UINT32 freqNo,UINT32 *pstate)
{
    UINT16     msgLen = 0;
    UINT16    msgType = 0;
    UINT32     retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    INPUT_POINTER_CHECK(pstate);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.pimcPreTrainState);
    msgType = DPD_MSG_PIMCPRETRAINSTATE;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    *pstate = DPD_NTOHL(recv->msg.pimcPreTrainStateAck.state);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgPimcBypass(*)
 功能 描述： 0x000A消息--PIMC旁路控制
 输入参数 ： chan        - 通道号
             freqNo - 频段号
             ctrl   -  控制字：0x5A5A，使能；0x2D2D，BYPASS
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgPimcBypass(UINT32 chan, UINT32 freqNo, UINT32 ctrl)
{
    UINT16     msgLen = 0;
    /* UINT16    msgType = 0; */
    UINT16     swFlag = 0;
    UINT32     retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    swFlag = (UINT16)ctrl;
    msgLen = sizeof(send->msg.ctrlBypass);

    send->head.msgType = DPD_HTONS(DPD_MSG_PIMCBYPASS);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->msg.ctrlBypass.ctrl = DPD_HTONS(swFlag);
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg error!\n",__FUNCTION__,chan);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.ctrlBypassAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}
/**************************************************************************
 函数名 称： MsgResultProc
 功能 描述： 消息结果处理
 输入参数 ： chan - 通道号
 ucParaFromFile - 是否传送文件中的参数
 输出参数 ： 无
 返回值：       RETCODE_PASS                               成功
 HPI_RETCODE_NULL_PTR                 指针为空
 HPI_RETCODE_ERR_PARAM               参数错误
 HPI_LINK_SEQNUM_MISMATCH         链路不匹配
 HPI_LINK_UNKNOWN_LPDU               未知的数据包
 HPI_LINK_RETRY_EXCEED                超过最大的重发次数
 其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014//12/22                      V1.0      zfx        新建
***********************************************************************/
UINT32 MsgVswrResultProc(UINT32 vswrState)
{
   UINT32 result = BSP_OK;
   switch(vswrState)
   {
       case DPD_FB_SAMP_DAT_FAIL:
           MsgPrint(PM_INFO,"FB_SAMP_DAT_FAIL!\n");
           result = BSP_ERROR;
           break;
       case DPD_FB_CAL_DLY_FAIL:
           MsgPrint(PM_INFO,"FB_CAL_DLY_FAIL! \n");
           result = BSP_ERROR;
           break;
       case DPD_FB_RHO_FAIL:
           MsgPrint(PM_INFO,"FB_RHO_FAIL! \n");
           result = BSP_ERROR;
           break;
       case DPD_GFWD_R_NCO_FAIL:
           MsgPrint(PM_INFO,"GFWD_R_NCO_FAIL! \n");
           result = BSP_ERROR;
           break;
       case DPD_FBP_POW_LOW:
           MsgPrint(PM_INFO,"FBP_POW_LOW! \n");
           result = BSP_ERROR;
           break;
       case DPD_FWD_POW_LOW:
           MsgPrint(PM_INFO,"FWD_POW_LOW! \n");
           result = BSP_ERROR;
           break;
       case DPD_REV_SAMP_DAT_FAIL:
           MsgPrint(PM_INFO,"REV_SAMP_DAT_FAIL! \n");
           result = BSP_ERROR;
           break;
       case DPD_REV_CAL_DLY_FAIL:
           MsgPrint(PM_INFO,"REV_CAL_DLY_FAIL! \n");
           result = BSP_ERROR;
           break;
       case DPD_REV_RHO_FAIL:
           MsgPrint(PM_INFO,"REV_RHO_FAIL! \n");
           result = BSP_ERROR;
           break;
       case DPD_GREV_R_NCO_FAIL:
           MsgPrint(PM_INFO,"GREV_R_NCO_FAIL! \n");
           result = BSP_ERROR;
           break;
       case DPD_RBP_POW_LOW:
           MsgPrint(PM_INFO,"RBP_POW_LOW! \n");
           result = BSP_ERROR;
           break;
       case DPD_REV_POW_LOW:
           MsgPrint(PM_INFO,"REV_POW_LOW! \n");
           result = BSP_ERROR;
           break;
       case (UINT32)-1:
           MsgPrint(PM_INFO,"return error! \n");
           result = BSP_ERROR;
           break;
       case DPD_VSWR_FINISH:
           MsgPrint(PM_INFO,"get vswr status success! \n");
           result = BSP_OK;
           break;
       default:
           MsgPrint(PM_INFO,"Unknow!result = %d\n",result);
           result = BSP_INVALID_VALUE;
           break;
   }
   return result;
}


//dsp新添加消息2018.12.26

/**************************************************************************
 * 函数名称： DpdMsgUploadDataCeva(*)
 * 功能描述： 0xD005; 消息--上传数据
 * 输入参数： chan   - 中频通道号,
              freqNo -
              pdata  - 参数结构体
              plen   - 长度
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 对于A9622D规格射频通道号需要转换为中频通道号
 * 修改日期      版本号     修改人        修改内容
 * ------------------------------------------------------------------------
 * 2014/12/15     V1.0       zfx           新建
 **************************************************************************/
UINT32 DpdMsgUploadDataCeva(UINT32 chan,UINT32 freqNo, UINT32 datatype,UCHAR *pdata,UINT32 *plen)
{
   THpiApiPDU send = {0,};
   THpiApiPDU recv = {0,};
   UINT32     retVal;
   /* UINT16     result; */
   UINT16     msgLen = sizeof(send.msg.upLoad);
   UINT16     msgType = DPD_MSG_TBLUPLOAD_CEVA;
   UINT16     swDataType = (UINT16)datatype;
   UINT32     i = 0;
   UINT16 apduNum = 0;
   UCHAR *pbyTemp = NULL;
   UINT32 recvlen = 0;
   /* UINT32 j = 0; */
   INPUT_POINTER_CHECK(pdata);
   INPUT_POINTER_CHECK(plen);

   pbyTemp = pdata;

   while(1)
   {
       send.head.msgType = DPD_HTONS(msgType);
       send.head.numAPDU = DPD_HTONS(apduNum);
       send.head.msgLen  = DPD_HTONS(msgLen);
       send.head.chan    = (UINT8)chan;
       send.head.band    = (UINT8)freqNo;
       send.lenAPDU      = sizeof(send.head) + msgLen;

       send.msg.upLoad.dataType = DPD_HTONS(swDataType);

       retVal = SendHpiMsg(GET_DSP_ID(chan), &send, &recv);
       if (retVal != BSP_OK)
       {
           MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
           break;
       }

       memcpy_s(pbyTemp, min(DPD_NTOHS(recv.head.msgLen),sizeof(T_DpdMsgUploadDataAck)), &recv.msg.upLoadAck.data[0], min(DPD_NTOHS(recv.head.msgLen),sizeof(T_DpdMsgUploadDataAck)));
       pbyTemp += DPD_NTOHS(recv.head.msgLen);
       recvlen += DPD_NTOHS(recv.head.msgLen);

       /*is the last msg*/
       if(0 == DPD_NTOHS(recv.head.numAPDU))
       {
           /*last msg*/
           MsgPrint(PM_INFO,"Receive complete!Msg NO. is %d.Total length is %ld!\n", i+1,recvlen);
           *plen = recvlen;
           break;
       }
       else
       {
           apduNum = DPD_NTOHS(recv.head.numAPDU) -1;
       }

   }
   MsgResultProc(retVal);

   return retVal;
}


/**************************************************************************
 * 函数名称： DpdMsgDownloadDataCeva(*)
 * 功能描述： 0xD004
 * 输入参数： chan   - 中频通道号,
             freqNo -
             pdata  - 参数结构体
             plen   - 长度
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 对于A9622D规格射频通道号需要转换为中频通道号
 * 修改日期      版本号     修改人        修改内容
 * ------------------------------------------------------------------------
 * 2014/12/15     V1.0       zfx           新建
 **************************************************************************/
UINT32 DpdMsgDownloadDataCeva(UINT32 chan,UINT32 freqNo, UCHAR *pdata,UINT32 *plen)
{
    UINT16     msgLen = 0;
    UINT16    msgType = 0;
    UINT16    apduNum = 0xFFFF;
    UINT16  packetNum = 0;
    /* UINT16 packetSize = 0; */
    UINT16 sentdataLen = 0;
    UINT8    *pbyTemp = NULL;
    /* UINT32    recvlen = 0; */
    UINT32     retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    INPUT_POINTER_CHECK(pdata);
    INPUT_POINTER_CHECK(plen);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.download);
    msgType = DPD_MSG_TBLDOWNLOAD_CEVA;

   if((0 == *plen) || (MAX_DPD_DOWN_LOAD_TABLE_SIZE < *plen))
   {
       MsgPrint(PM_ERROR,"Table Length error!\n");
       free(pucApiBuff);
       return BSP_ERROR;
   }

   pbyTemp = pdata;
   packetNum = (UINT16)((*plen-1) / MAX_DPD_MSG_BODY + 1);
   apduNum = 0x8000+(packetNum - 1);
   while(1)
   {
       send->head.msgType = DPD_HTONS(msgType);
       send->head.numAPDU = (apduNum == (packetNum - 1))? DPD_HTONS((1<<15) | apduNum) : DPD_HTONS(apduNum);
       if(apduNum == 0)
       {
           msgLen  = (*plen- (MAX_DPD_MSG_BODY * (packetNum - 1)));
       }
       else
       {
           msgLen = MAX_DPD_MSG_BODY;
       }
       send->head.msgLen  = DPD_HTONS(msgLen);
       send->head.chan    = (UINT8)chan;
       send->head.band    = (UINT8)freqNo;
       send->lenAPDU      = sizeof(send->head) + msgLen;

       memcpy_s(&(send->msg.download.data[0]), min(msgLen,sizeof(T_DpdMsgDownloadData)), pbyTemp, min(msgLen,sizeof(T_DpdMsgDownloadData)));

       retVal = SendHpiMsg(GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
       if (retVal != BSP_OK)
       {
           MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
           break;
       }

       retVal = DPD_NTOHS(recv->msg.downloadAck.result);
       if(retVal != DPD_UPLOAD_OVER)
       {
           MsgPrint(PM_ERROR,"%s chan=%d recv ret 0x%04x,error!\n",__FUNCTION__,chan,msgType);
           continue;
       }

       sentdataLen += msgLen;
       if(0 == apduNum)
       {
           /*last msg*/
           MsgPrint(PM_INFO,"Send complete!.Total length is %d!\n", sentdataLen);
           break;
       }

       pbyTemp += msgLen;
       if(apduNum&0x8000)
       {
           apduNum-=0x8000;
       }
       apduNum--;

   }
   MsgResultProc(retVal);
   free(pucApiBuff);
   return retVal;
}
//////////////////////////////////////////////////////////////////////////////
////////////////// Nxp 与 ACDSP之间 UdpSocket 临时放在此处 ///////////////////
//////////////////////////////////////////////////////////////////////////////


UINT32 DspMsgBasePrintf(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo,
        T_DspMsgBasePrtQuery *pDspMsgPrtQuery, UINT8 *pucBuf, UINT32 *pulLen)
{
    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *ptApiSend = NULL;
    THpiApiPDU *ptApiRecv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        ulRetVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return ulRetVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    ptApiSend = (THpiApiPDU *)&pucApiBuff[0];
    ptApiRecv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgType = UDP_MSG_DSP_PRINTF +dspPrnTypeId;
    ulMsgLen  = sizeof(T_DspMsgBasePrtQuery);

    ptApiSend->lenAPDU      = sizeof(ptApiSend->head) + ulMsgLen;
    ptApiSend->head.msgType = UDPMSG_HTONS(msgType);
    ptApiSend->head.numAPDU = 0;
    ptApiSend->head.msgLen  = UDPMSG_HTONS(ulMsgLen);
    ptApiSend->head.chan    = (UINT8)ulDifChnl;
    ptApiSend->head.band    = (UINT8)ulFreqBandNo;

    ptApiSend->head.srcId    = (UINT8)GetUdpSrcId();
    ptApiSend->head.dstId    = (UINT8)GetUdpDstId();
    ptApiSend->head.typeId    = (UINT8)typeId;
    ptApiSend->head.recvEn    = (UINT8)MSG_REQ;
    ptApiSend->msg.dspBasePrn.index0 = (UINT8)pDspMsgPrtQuery->index0;
    ptApiSend->msg.dspBasePrn.index1 = (UINT8)pDspMsgPrtQuery->index1;
    ptApiSend->msg.dspBasePrn.index2 = (UINT8)pDspMsgPrtQuery->index2;
    ptApiSend->msg.dspBasePrn.index3 = (UINT8)pDspMsgPrtQuery->index3;
    ptApiSend->msg.dspBasePrn.index4 = (UINT8)pDspMsgPrtQuery->index4;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)ptApiSend, (UINT8*)ptApiRecv))
    {
        ulRetVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, ulRetVal);
    }
    *pulLen = DPD_NTOHS(ptApiRecv->head.msgLen);
    memcpy_s(pucBuf,*pulLen,ptApiRecv->msg.buf, *pulLen);

    free(pucApiBuff);
    MsgResultProc(ulRetVal);
    return ulRetVal;
}

UINT32 DspMsgCtrlTs(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo, UINT32 tsType, UINT32 state)
{

    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;

    UINT32 retVal = BSP_OK;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgType = UDP_MSG_TS_CTRL;
    ulMsgLen  = sizeof(send->msg.tsCtrl);

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = UDPMSG_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = UDPMSG_HTONS(ulMsgLen);
    send->head.chan    = (UINT8)ulDifChnl;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;

    send->msg.tsCtrl.state = DPD_HTONL(state);
    send->msg.tsCtrl.tstype = DPD_HTONL(tsType);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }
    retVal = DPD_NTOHS(recv->msg.tsCtrlAck.state);
    dbgInfoEx("%s:state=%x\n",__FUNCTION__,retVal);

    if(retVal != 0)
    {
        retVal = BSP_ERROR;
    }
    free(pucApiBuff);
    MsgResultProc(retVal);
    return retVal;
}


UINT32 DspMsgQueryTs(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo)
{
    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;

    UINT32 retVal = BSP_OK;

    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgType = UDP_MSG_TS_QUERY;
    ulMsgLen  = 0;

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = UDPMSG_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = UDPMSG_HTONS(ulMsgLen);
    send->head.chan    = (UINT8)ulDifChnl;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;


    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }

    retVal = DPD_NTOHS(recv->msg.tsQueryAck.state);
    dbgInfoEx("%s:state=%x\n",__FUNCTION__,retVal);

    if(retVal != 0)
    {
        retVal = BSP_ERROR;
    }
    free(pucApiBuff);
    MsgResultProc(retVal);
    return retVal;
}

/* Started by AICoder, pid:lc6a2b61d6za3151492e0ace9046e456cde76451 */
UINT32 DspMsgQueryDopaCali(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo)
{
    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;

    UINT32 retVal = BSP_OK;

    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgType = UDP_MSG_DOPA_CALI_QUERY;
    ulMsgLen  = 0;

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = UDPMSG_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = UDPMSG_HTONS(ulMsgLen);
    send->head.chan    = (UINT8)ulDifChnl;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;


    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }

    retVal = DPD_NTOHS(recv->msg.DopaCaliQueryAck.ulDopaCaliSta);
    dbgInfoEx("%s:state=%x\n",__FUNCTION__,retVal);

    if(retVal != 0)
    {
        retVal = BSP_ERROR;
    }
    free(pucApiBuff);
    MsgResultProc(retVal);
    return retVal;
}
/* Ended by AICoder, pid:lc6a2b61d6za3151492e0ace9046e456cde76451 */

/**************************************************************************
 函数名 称： DpdMsgTsEn(*)
 功能 描述： 0x4013消息--发送TS开关设置
 输入参数 ： difChan        - 通道号
             freqNo   -
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgTsEn(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo, UINT16 state)
{
    UINT16 ulMsgLen  = 0;
    UINT16 msgType = 0;

    UINT32 retVal = BSP_OK;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgType = DPD_MSG_SENDTSEN;
    ulMsgLen  = sizeof(send->msg.tsEnable);

    send->lenAPDU      = (UINT16)(sizeof(send->head) + ulMsgLen);
    send->head.msgType = (UINT16)(UDPMSG_HTONS(msgType));
    send->head.numAPDU = 0;
    send->head.msgLen  = (UINT16)UDPMSG_HTONS(ulMsgLen);
    send->head.chan    = (UINT8)ulDifChnl;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   =(UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;

    send->msg.tsEnable.state = UDPMSG_HTONS(state);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }

    retVal = DPD_NTOHS(recv->msg.tsEnableAck.state);
    dbgInfoEx("%s:state=%x\n",__FUNCTION__,retVal);

    if(retVal != 0)
    {
        retVal = BSP_ERROR;
    }

    free(pucApiBuff);
    MsgResultProc((UINT16)retVal);

    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgQueryTsEn(*)
 功能 描述： 0x8014消息--发送查询TS开关设置
 输入参数 ： difChan        - 通道号
             freqNo   -
             pdata - 参数结构体
             pRecData
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgQueryTsEn(UINT32 typeId, UINT32 ulDifChnl, UINT32 ulFreqBandNo, UINT32 *pSta)
{
    UINT16 ulMsgLen  = 0;
    UINT16 msgType = 0;

    UINT32 retVal = BSP_OK;

    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgType = DPD_MSG_TSENSTATUS;
    ulMsgLen  = 0;

    send->lenAPDU      = (UINT16)(sizeof(send->head) + ulMsgLen);
    send->head.msgType = (UINT16)(UDPMSG_HTONS(msgType));
    send->head.numAPDU = 0;
    send->head.msgLen  = (UINT16)UDPMSG_HTONS(ulMsgLen);
    send->head.chan    = (UINT8)ulDifChnl;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;


    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }

    *pSta = (UINT32)DPD_NTOHS(recv->msg.tsEnQuery.state);

    dbgInfoEx("%s:state=%x\n",__FUNCTION__,*pSta);

    if(*pSta != 0)
    {
        retVal = BSP_ERROR;
    }
    free(pucApiBuff);
    MsgResultProc((UINT16)retVal);
    return retVal;
}

/**************************************************************************
函数名 称： DpdMsgDspRequireTsEn(*)
功能 描述： 0x8016--TS固定时延发起申请上报
输入参数 ： chan        - 通道号
           freqNo
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgDspRequireTsEn(UINT32 typeId, UINT32 chan,UINT32 freqNo,T_DpdTsExpQueryResult *dspRequst)
{
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(send->msg.tsDspRequest);
    UINT16     msgType = DPD_MSG_DSP_REQUEST_TS_EN;
    INPUT_POINTER_CHECK(dspRequst);

    send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
    if (send == NULL)
    {
        dbgInfo("%s send malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
    if (recv == NULL)
    {
        free(send);
        dbgInfo("%s recv malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)recv, 0 , sizeof(THpiApiPDU));

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
        __FUNCTION__, typeId, msgType, retVal);
    }
    retVal = DPD_NTOHL(recv->msg.tsDspRequestAck.result);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X get result is error! retVal= %d\n",
        __FUNCTION__,typeId, msgType, retVal);
    }
    dspRequst->expFlag = DPD_NTOHL(recv->msg.tsDspRequestAck.tsRequst);
    dspRequst->chanmask = DPD_NTOHL(recv->msg.tsDspRequestAck.tsRequstChanMask);
    dspRequst->tsktype = DPD_NTOHL(recv->msg.tsDspRequestAck.tsktype);
    dspRequst->calitype = DPD_NTOHS(recv->msg.tsDspRequestAck.calitype);
    dspRequst->calibranch = DPD_NTOHS(recv->msg.tsDspRequestAck.calibranch);
    free(send);
    free(recv);
    MsgResultProc((UINT16)retVal);
    return retVal;
}


/**************************************************************************
函数名 称： DpdMsgDspChanOffRequst(*)
功能 描述： 0x0014--节能发起DPD通道关断请求
输入参数 ： chan        - 通道号
           freqNo
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2021/10/29      V1.0      10258234       新建
***********************************************************************/
UINT32 DpdMsgDspChanOffRequst(UINT32 typeId, UINT32 chan,UINT32 freqNo,T_ChanOffRequest *chanOffRequst)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_DSP_REQUEST_CHAN_OFF;
    UINT32 chanMask = 0;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(chanOffRequst);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    //coverity[cert_exp39_c_violation:SUPPRESS]
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.dspChanOffRequest);
    //coverity[cert_exp39_c_violation:SUPPRESS]
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.chan    = (UINT8)chan;
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.band    = (UINT8)freqNo;

    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.srcId    = (UINT8)GetUdpSrcId();
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.dstId    = (UINT8)GetUdpDstId();
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    chanMask = chanOffRequst->chanmask;
    send->msg.dspChanOffRequest.chanmask = DPD_HTONL(chanMask);

    //coverity[cert_int31_c_violation:SUPPRESS]
    retVal = SendHpiMsg(GET_DSP_ID((UINT16)chan), send, recv);
    if (retVal != BSP_OK)
    {
        //coverity[cert_exp37_c_violation:SUPPRESS]
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.dspChanOffRequestAck.result);
    MsgResultProc((UINT16)retVal);

    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
函数名 称： DpdMsgDspChanOffRequst(*)
功能 描述： 0x8018--节能发起DPD通道关断请求DPD处理结果查询
输入参数 ： chan        - 通道号
           freqNo
输出参数 ： result: 1表示关断完成，0表示关断未完成
返回值      ：BSP_OK: 成功
            其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2021/10/29      V1.0      10258234       新建
***********************************************************************/
UINT32 DpdMsgDspChanOffStaQuery(UINT32 typeId, UINT32 chan,UINT32 freqNo, UINT32 *result)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_DSP_QUERY_CHAN_OFF_RESULT;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(result);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    //coverity[cert_exp39_c_violation:SUPPRESS]
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.dspChanOffResultQuery);
    //coverity[cert_exp39_c_violation:SUPPRESS]
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.chan    = (UINT8)chan;
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.band    = (UINT8)freqNo;

    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.srcId    = (UINT8)GetUdpSrcId();
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.dstId    = (UINT8)GetUdpDstId();
    //coverity[cert_int31_c_violation:SUPPRESS]
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    //coverity[cert_int31_c_violation:SUPPRESS]
    retVal = SendHpiMsg(GET_DSP_ID((UINT16)chan), send, recv);
    if (retVal != BSP_OK)
    {
        //coverity[cert_exp37_c_violation:SUPPRESS]
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    *result = DPD_NTOHL(recv->msg.dspChanOffResultQueryAck.chanoffresult);
    /* DSP返回值与预想相反，故进行取反操作 */
    *result = ((*result>0)?0:1);

    free(pucApiBuff);
    return retVal;
}

#define CREAT_BUFF(buff,send,recv)                                      \
{                                                                       \
    UINT8 *buff = NULL;                                                 \
    THpiApiPDU *send = NULL;                                            \
    THpiApiPDU *recv = NULL;                                            \
    buff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));    \
    if (NULL == buff)                                                   \
    {                                                                   \
        ulRetVal |= BIT_SET(0);                                         \
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);             \
        return ulRetVal;                                                \
    }                                                                   \
    memset((VOID *)buff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));   \
    send = (THpiApiPDU *)&buff[0];                                      \
    recv = (THpiApiPDU *)&buff[sizeof(THpiApiPDU)];                     \
}
#define RELEASE_BUFF(buff)      free(buff);


UINT32 DpdMsgDdcCtrl(UINT32 chan,UINT32 freqNo,UINT32 ddcCtrl)
{
    UINT16     msgLen = 0;
    UINT16    msgType = 0;
    UINT32     retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.ddcCtrl);
    send->msg.ddcCtrl.startCtrl = DPD_NTOHL(ddcCtrl);
    msgType = DPD_MSG_DDC_CTRL;

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = GetUdpSrcId();
    send->head.dstId   = GetUdpDstId();
    send->head.typeId  = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg((UINT16)GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
    }

    free(pucApiBuff);
    return retVal;
}


UINT32 DpdMsgDdcParam(UINT32 chan,UINT32 freqNo,T_CellInfoParm *pcellInfoParm)
{
    UINT16  msgLen = 0;
    UINT16  msgType = 0;
    UINT32  retVal = BSP_OK;
    UINT8*  pucApiBuff = NULL;
    THpiApiPDU* send = NULL;
    THpiApiPDU* recv = NULL;
    UINT32 cnt=0;
    UINT32 dagccnt=0;

    INPUT_POINTER_CHECK(pcellInfoParm);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.ddcParam);
    msgType = DPD_MSG_DDC_PARAM;

    memcpy_s((void *)&(send->msg.ddcParam.cellInfoParm), msgLen, (void *)pcellInfoParm, msgLen);

    send->msg.ddcParam.cellInfoParm.cellidx = DPD_HTONL(pcellInfoParm->cellidx);
    send->msg.ddcParam.cellInfoParm.cellStatus = DPD_HTONL(pcellInfoParm->cellStatus);
    send->msg.ddcParam.cellInfoParm.antMask = DPD_HTONL(pcellInfoParm->antMask);
    send->msg.ddcParam.cellInfoParm.ScaleGroup = DPD_HTONL(pcellInfoParm->ScaleGroup);

    send->msg.ddcParam.cellInfoParm.subtiming0_datalen = DPD_HTONL(pcellInfoParm->subtiming0_datalen);
    send->msg.ddcParam.cellInfoParm.subtiming1_datalen = DPD_HTONL(pcellInfoParm->subtiming1_datalen);
    send->msg.ddcParam.cellInfoParm.subtiming2_datalen = DPD_HTONL(pcellInfoParm->subtiming2_datalen);
    send->msg.ddcParam.cellInfoParm.subtiming3_datalen = DPD_HTONL(pcellInfoParm->subtiming3_datalen);


    for(cnt=0;cnt<32;cnt++)
    {
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming0_dataaddr_src =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming0_dataaddr_src);
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming0_dataaddr_dst =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming0_dataaddr_dst);
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming1_dataaddr_src =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming1_dataaddr_src);
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming1_dataaddr_dst =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming1_dataaddr_dst);
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming2_dataaddr_src =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming2_dataaddr_src);
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming2_dataaddr_dst =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming2_dataaddr_dst);
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming3_dataaddr_src =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming3_dataaddr_src);
        send->msg.ddcParam.cellInfoParm.antdata[cnt].subtiming3_dataaddr_dst =DPD_HTONL(pcellInfoParm->antdata[cnt].subtiming3_dataaddr_dst);

        for(dagccnt=0;dagccnt<6;dagccnt++)
        {
            send->msg.ddcParam.cellInfoParm.antdata[cnt].scale_addr[dagccnt] = DPD_HTONL(pcellInfoParm->antdata[cnt].scale_addr[dagccnt]);
        }
        //send->msg.ddcParam.rachl2dinfo.rachl2dinfo[cnt].valid = DPD_HTONL(pRachInfo->rachl2dinfo[cnt].valid);
    }
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = GetUdpSrcId();
    send->head.dstId   = GetUdpDstId();
    send->head.typeId  = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg((UINT16)GET_DSP_ID(chan), (THpiApiPDU *)send, (THpiApiPDU *)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    MsgResultProc((UINT16)DPD_NTOHL(recv->msg.ddcParamAck.ddcstatus));
    free(pucApiBuff);
    return retVal;
}
/**********************************************************************
 函数名称： DpdMsgSendFwdParam(*)
 功能描述： 0x4018消息--发送反馈补偿信息
 输入参数： difChan - 通道号
            freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendFwdParam(UINT32 chan, UINT32 freqNo, T_DpdMsgSendFwdParam * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     resLen = 0;
    UINT16     msgType = DPD_MSG_SENDFWDPARAM;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendFwdParam);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = GetUdpSrcId() & 0xff;
    send->head.dstId    = GetUdpDstId() & 0xff;
    send->head.typeId    = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.sendFwdParam.startFreq     = DPD_HTONL(pdata->startFreq);
    send->msg.sendFwdParam.freqStep      = DPD_HTONL(pdata->freqStep);
    send->msg.sendFwdParam.freqNum       = DPD_HTONL(pdata->freqNum);
    send->msg.sendFwdParam.bandId      = DPD_HTONL(pdata->bandId);
    send->msg.sendFwdParam.reserve1      = DPD_HTONL(pdata->reserve1);
    dbgInfoEx("startFreq = %d, freqStep =%d, freqNum =%d, bandId =%d, reserve1 =%d\n",pdata->startFreq,pdata->freqStep,pdata->freqNum,pdata->bandId,pdata->reserve1);//打印原始字节序
    for(resLen = 0; resLen < pdata->freqNum; resLen++)
    {
        send->msg.sendFwdParam.gainComp[resLen] = DPD_HTONL(pdata->gainComp[resLen]);
        dbgInfoEx("fwd = %d,gainComp[resLen] = %d\n",resLen,pdata->gainComp[resLen]);
    }

    retVal = SendHpiMsg((UINT16)(GET_DSP_ID(chan)), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.sendFwdParamAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendFilterParam(*)
 功能描述： 0x4019消息--发送双工器补偿信息
 输入参数： difChan - 通道号
             freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendFilterParam(UINT32 chan, UINT32 freqNo, T_DpdMsgSendFilterParam * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     resLen = 0;
    UINT16     msgType = DPD_MSG_SENDFILTERPARAM;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendFilterParam);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = GetUdpSrcId() & 0xff;
    send->head.dstId    = GetUdpDstId() & 0xff;
    send->head.typeId    = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.sendFilterParam.startFreq     = DPD_HTONL(pdata->startFreq);
    send->msg.sendFilterParam.freqStep      = DPD_HTONL(pdata->freqStep);
    send->msg.sendFilterParam.freqNum       = DPD_HTONL(pdata->freqNum);
    send->msg.sendFilterParam.bandId       = DPD_HTONL(pdata->bandId);
    send->msg.sendFilterParam.reserve1      = DPD_HTONL(pdata->reserve1);
    dbgInfoEx("startFreq = %d, freqStep =%d, freqNum =%d, bandId =%d, reserve1 =%d\n",pdata->startFreq,pdata->freqStep,pdata->freqNum,pdata->bandId,pdata->reserve1);//打印原始字节序

    for(resLen = 0; resLen < pdata->freqNum; resLen++)
    {
        send->msg.sendFilterParam.gainComp[resLen] = DPD_HTONL(pdata->gainComp[resLen]);
        dbgInfoEx("filter = %d,gainComp[resLen] = %d\n",resLen,pdata->gainComp[resLen]);
    }

    retVal = SendHpiMsg((UINT16)(GET_DSP_ID(chan)), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.sendFilterParamAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);
    return retVal;
}
#define FAST_ADJUST_VOLT_GPIOREGLEVEL_MAX_NUM (16)
#define FAST_ADJUST_VOLT_LEVEL_MAX_NUM (8)

/**********************************************************************
 函数名称： DpdMsgFastAdjVoltPwrSwitchCfg(*)
 功能描述： 0x4021消息--动态调压开关配置
 输入参数： pdata - 参数结构体
 输出参数： 无
 返 回 值： BSP_OK: 成功    其他: 失败
 其他说明： 无
 修改日期：      1.0     10288704     增加0x4021调压开关配置消息
***********************************************************************/
UINT32 DpdMsgFastAdjVoltPwrSwitchCfg(T_DpdMsgFastAdjVoltSwitch *pdata)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_VOLT_SCHED_SWI_CFG;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendAdjVoltSwitchInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    /* 快速调压开关信息 */
    send->msg.sendAdjVoltSwitchInfo.fastAdjVoltSw = DPD_HTONL(pdata->fastAdjVoltSw);
    send->msg.sendAdjVoltSwitchInfo.voltStep= DPD_HTONL(pdata->voltStep);
    send->msg.sendAdjVoltSwitchInfo.voltPerTimeMax = DPD_HTONL(pdata->voltPerTimeMax);
    send->msg.sendAdjVoltSwitchInfo.voltLevelNum = DPD_HTONL(pdata->voltLevelNum);
    dbgInfo("[%s] fastAdjVoltSw[%#x]\n",__func__,send->msg.sendAdjVoltSwitchInfo.fastAdjVoltSw);
    dbgInfo("[%s] voltStep[%#x]\n",__func__,send->msg.sendAdjVoltSwitchInfo.voltStep);
    dbgInfo("[%s] voltPerTimeMax[%#x]\n",__func__,send->msg.sendAdjVoltSwitchInfo.voltPerTimeMax);
    dbgInfo("[%s] voltLevelNum[%#x]\n",__func__,send->msg.sendAdjVoltSwitchInfo.voltLevelNum);

    /* 真值表 */
    for (loop = 0; loop < FAST_ADJUST_VOLT_GPIOREGLEVEL_MAX_NUM; loop++)
    {
        send->msg.sendAdjVoltSwitchInfo.gpioMap[loop] = DPD_HTONL(pdata->gpioMap[loop]);
        dbgInfo("[%s] gpioMap[%#x]\n",__func__,send->msg.sendAdjVoltSwitchInfo.gpioMap[loop]);
    }

    dbgInfo("------------ SWITCH INFO ANALYSE OVER ------------\n");

    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,0,msgType);
        free(pucApiBuff);
        return retVal;
    }
    dbgInfo("------------ SEND DSP MSG OVER ------------\n");

    retVal = DPD_NTOHS(recv->msg.sendAdjVoltSwitchInfoAck.result);
    MsgResultProc((UINT16)retVal);
    dbgInfo("------------ RECV DSP MSG OVER ------------\n");

    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgFastAdjVoltParaCfg(*)
 功能描述： 0x4022消息--动态调压参数配置
 输入参数： pdata - 参数结构体
 输出参数： 无
 返 回 值： BSP_OK: 成功    其他: 失败
 其他说明： 无
 修改日期：      1.0     10288704     增加0x4022调压参数配置消息
***********************************************************************/
UINT32 DpdMsgFastAdjVoltParaCfg(T_DpdMsgFastAdjVoltPara *pdata)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_VOLT_SCHED_PARA_CFG;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendAdjVoltPara);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    /* 快速调压开关信息 */
    send->msg.sendAdjVoltPara.LevelNum = DPD_HTONL(pdata->LevelNum);
    dbgInfoEx("[%s] LevelNum[%#x]\n",__func__,send->msg.sendAdjVoltPara.LevelNum);
    for (loop = 0; loop < FAST_ADJUST_VOLT_LEVEL_MAX_NUM; loop++)
    {
        send->msg.sendAdjVoltPara.PowerLevel[loop]  = DPD_HTONL(pdata->PowerLevel[loop]);
        send->msg.sendAdjVoltPara.PaVolt[loop]      = DPD_HTONL(pdata->PaVolt[loop]);
        send->msg.sendAdjVoltPara.CFRLevel[loop][0] = DPD_HTONL(pdata->CFRLevel[loop][0]);
        send->msg.sendAdjVoltPara.CFRLevel[loop][1] = DPD_HTONL(pdata->CFRLevel[loop][1]);
        send->msg.sendAdjVoltPara.CFRLevel[loop][2] = DPD_HTONL(pdata->CFRLevel[loop][2]);
        send->msg.sendAdjVoltPara.DPDLevel[loop]    = DPD_HTONL(pdata->DPDLevel[loop]);
        send->msg.sendAdjVoltPara.SSCLevel[loop]    = DPD_HTONL(pdata->SSCLevel[loop]);
        send->msg.sendAdjVoltPara.TSGainLevel[loop] = DPD_HTONL(pdata->TSGainLevel[loop]);
        dbgInfoEx("------------ loop:%d--------------\n",loop);
        dbgInfoEx("[%s] PowerLevel[%#x]\n",__func__,send->msg.sendAdjVoltPara.PowerLevel[loop]);
        dbgInfoEx("[%s] PaVolt[%#x]\n",__func__,send->msg.sendAdjVoltPara.PaVolt[loop]);
        dbgInfoEx("[%s] CFRLevel0[%#x] CFRLevel1[%#x] CFRLevel2[%#x]\n",__func__,send->msg.sendAdjVoltPara.CFRLevel[loop][0],
            send->msg.sendAdjVoltPara.CFRLevel[loop][1],send->msg.sendAdjVoltPara.CFRLevel[loop][2]);
        dbgInfoEx("[%s] DPDLevel[%#x]\n",__func__,send->msg.sendAdjVoltPara.DPDLevel[loop]);
        dbgInfoEx("[%s] SSCLevel[%#x]\n",__func__,send->msg.sendAdjVoltPara.SSCLevel[loop]);
        dbgInfoEx("[%s] TSGainLevel[%#x]\n",__func__,send->msg.sendAdjVoltPara.TSGainLevel[loop]);
    }

    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,0,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.sendAdjVoltParaAck.result);
    MsgResultProc((UINT16)retVal);

    free(pucApiBuff);

    return retVal;
}

UINT32 DpdMsgStartCtrlOnlinePim(UINT32 chan, UINT32 freqNo, UINT32 ctrl)
{
    UINT16 msgLen = 0;
    UINT32 retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16     msgType = DPD_MSG_ONLINE_PIM_CTRL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.onlinePimCtrl);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;
    send->msg.onlinePimCtrl.pts_start_port = DPD_HTONL(chan);
    send->msg.onlinePimCtrl.pts_start_freq = DPD_HTONL(freqNo);
    send->msg.onlinePimCtrl.pts_start_ctr = DPD_HTONL(ctrl);
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->head.srcId    = GetUdpSrcId();
    send->head.dstId    = GetUdpDstId();
    send->head.typeId    = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = MSG_REQ;

    retVal = SendHpiMsg((UINT16)GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHL(recv->msg.onlinePimAck.result);
    free(pucApiBuff);
    return retVal;
}

UINT32 DpdMsgGetPimVal(UINT32 chan, UINT32 freqNo, T_DpdMsgGetOnlinePimValAck *pimdata)
{
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32    retVal = BSP_OK;
    UINT16    msgLen = 0;
    UINT16   msgType = DPD_MSG_GET_ONLINE_PIM_VAL;
    UINT32   pimChkNum = 0;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.OnlinePimVal);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = GetUdpSrcId();
    send->head.dstId    = GetUdpDstId();
    send->head.typeId   = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg((UINT16)GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHL(recv->msg.OnlinePimValAck.pim_chk_result);
    pimdata->pim_chk_num = DPD_NTOHL(recv->msg.OnlinePimValAck.pim_chk_num);
    pimChkNum = pimdata->pim_chk_num;
    if((retVal == 0x11) && (pimChkNum > 0))
    {
        while(pimChkNum)
        {
            pimdata->pim_online_chk_val[pimChkNum - 1].pim_chk_order_num  = DPD_NTOHL(recv->msg.OnlinePimValAck.pim_online_chk_val[pimChkNum - 1].pim_chk_order_num);
            pimdata->pim_online_chk_val[pimChkNum - 1].pim_chk_nco        = DPD_NTOHL(recv->msg.OnlinePimValAck.pim_online_chk_val[pimChkNum - 1].pim_chk_nco);
            pimdata->pim_online_chk_val[pimChkNum - 1].pim_chk_value      = DPD_NTOHL(recv->msg.OnlinePimValAck.pim_online_chk_val[pimChkNum - 1].pim_chk_value);
            pimdata->pim_online_chk_val[pimChkNum - 1].muti_pim_chk_value = DPD_NTOHL(recv->msg.OnlinePimValAck.pim_online_chk_val[pimChkNum - 1].muti_pim_chk_value);
            pimdata->pim_online_chk_val[pimChkNum - 1].noise_value        = DPD_NTOHL(recv->msg.OnlinePimValAck.pim_online_chk_val[pimChkNum - 1].noise_value);
            pimChkNum = pimChkNum - 1;

            dbgInfo("[%s] pimChkNum(%d), order(%d), nco(%d), pimVal(%d), mutiPimVal(%d), noiseVal(%d)\n",
                __FUNCTION__, pimdata->pim_chk_num,
                pimdata->pim_online_chk_val[pimChkNum].pim_chk_order_num,
                pimdata->pim_online_chk_val[pimChkNum].pim_chk_nco,
                pimdata->pim_online_chk_val[pimChkNum].pim_chk_value,
                pimdata->pim_online_chk_val[pimChkNum].muti_pim_chk_value,
                pimdata->pim_online_chk_val[pimChkNum].noise_value);
        }
    }
    free(pucApiBuff);
    return retVal;
}


UINT32 DpdMsgPimDpdStateQuery(UINT32 chan, UINT32 freqNo, T_DpdMsgPimDpdStateQueryAck *pimDdpState)
{
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32    retVal = BSP_OK;
    UINT16    msgLen = 0;
    UINT16   msgType = DPD_MSG_DPDSTATUS_PIM;
    UINT32   loop = 0;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(T_DpdMsgPimDpdStateQueryAck);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = GetUdpSrcId();
    send->head.dstId    = GetUdpDstId();
    send->head.typeId   = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    pimDdpState->chan = (uint32_t)DPD_NTOHL((uint32_t)recv->msg.PimDpdStateQueryAck.chan);
    pimDdpState->state = (uint32_t)DPD_NTOHL((uint32_t)recv->msg.PimDpdStateQueryAck.state);
    pimDdpState->result = (uint32_t)DPD_NTOHL((uint32_t)recv->msg.PimDpdStateQueryAck.result);
    dbgInfoEx("chan %d state %d  result %d\n", pimDdpState->chan, pimDdpState->state,pimDdpState->result);
    for(loop = 0; loop < MSG_PIMOFF_ACP_NUM; loop++)
    {
        pimDdpState->acps[loop] = (uint32_t)DPD_NTOHL((uint32_t)recv->msg.PimDpdStateQueryAck.acps[loop]);
        dbgInfoEx(" pimDdpState->acps[%d] = %d\n", loop,pimDdpState->acps[loop]);
    }
    free(pucApiBuff);

    return retVal;
}

UINT32 DpdMsgStartCtrlPim(UINT32 chan, UINT32 freqNo)
{
    UINT16 msgLen = 0;
    UINT32 retVal = BSP_OK;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16 msgType = DPD_MSG_DPDCTRL_PIM;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
       retVal |= BIT_SET(0);
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    msgLen = sizeof(T_DpdMsgPimOfflineStart);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;
    send->msg.pimOfflineStart.chan = DPD_HTONL(chan);
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->head.srcId    = GetUdpSrcId();
    send->head.dstId    = GetUdpDstId();
    send->head.typeId    = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = MSG_REQ;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg error!\n",__FUNCTION__,chan);
        free(pucApiBuff);
        return retVal;
    }
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdPtsLmsStartCtrl(*)
    功能 描述： 0x0015消息--PTS LMS迭代开关
              ctrl   -  控制字：0x5A5A，使能；0x2D2D，禁用
    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdPtsLmsStartCtrl(UINT32 ctrl)
{
    UINT32   retVal = BSP_OK;
    UINT16   swFlag = (UINT16)ctrl;
    UINT16   msgLen = sizeof(T_DpdPtsLmsCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PTS_LMS_CTRL;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;
    UINT32   retVal1 = BSP_OK;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->msg.ptsLmsCtrl.ctrl = DPD_HTONS(swFlag);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
    {
        if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            retVal |= BIT_SET(1);
            dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
            free(pucApiBuff);

            return retVal;
        }
    }

    retVal = DPD_NTOHS(recv->msg.ptsLmsCtrlAck.result);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdGetPtsLmsStatus(*)
    功能 描述： 0x8019消息--定时查询PTS LMS迭代状态
    输入参数 ： chan   - 通道号
              freqNo - 频段号
    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdGetPtsLmsStatus(T_DpdLmsStatusAck *lmsStatus)
{
    UINT32   retVal = BSP_OK;
    UINT32   txchanId = 0;
    UINT16   msgLen = sizeof(T_DpdLmsStatus);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_DSP_PTS_LMS_STATUS_RESULT;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;
    UINT32   retVal1 = BSP_OK;

    INPUT_POINTER_CHECK(lmsStatus);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
    {
        if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            retVal |= BIT_SET(1);
            dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
            free(pucApiBuff);

            return retVal;
        }
    }

    lmsStatus->ptsLmsSta = DPD_NTOHL(recv->msg.LmsStatusAck.ptsLmsSta);
    for(txchanId = 0; txchanId < MAX_IC_CHIP_TX_CHAN; txchanId++)
    {
        lmsStatus->ptsLmsChanSta[txchanId] = DPD_NTOHL(recv->msg.LmsStatusAck.ptsLmsChanSta[txchanId]);
    }

    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdNoiseCheckStartCtrl(*)
    功能 描述： 0x0016消息--启动PIM_OnLine各通道躁低检测

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdNoiseCheckStartCtrl(UINT32 slotindex)
{
    UINT32   retVal = BSP_OK;
    UINT16   msgLen = sizeof(T_DpdPimOnlineNoiseCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIM_ONLINE_NOISE_CTRL;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;
    UINT32   retVal1 = BSP_OK;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    //send躁低检测无线帧号
    send->msg.pimOnlineNoiseCtrl.slotindex = DPD_HTONL(slotindex);  /*躁低检测无线帧号*/
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
    {
        if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            retVal |= BIT_SET(1);
            dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
            free(pucApiBuff);

            return retVal;
        }
    }

    free(pucApiBuff);

    return retVal;
}
/**************************************************************************
    函数名 称： DpdGetNoiseCheckStatus(*)
    功能 描述： 0x801a消息--查询躁低检测状态

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdGetNoiseCheckStatus(T_DpdDpdNoiseStaAck *noiseCheckSta)
{
    UINT32   retVal = BSP_OK;
    UINT32   rxchanId = 0;
    UINT16   msgLen = sizeof(T_DpdNoiseSta);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_DSP_NOISE_TEST_STATUS_RESULT;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;
    UINT32   retVal1 = BSP_OK;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
    {
        if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            retVal |= BIT_SET(1);
            dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
            free(pucApiBuff);

            return retVal;
        }
    }

    noiseCheckSta->noisecalfinSta = DPD_NTOHL(recv->msg.pimOnlineNoiseStaAck.noisecalfinSta);
    for(rxchanId = 0; rxchanId < MAX_IC_CHIP_RX_CHAN; rxchanId++)
    {
        noiseCheckSta->noisecalres[rxchanId].NoiseCalSta = DPD_NTOHL(recv->msg.pimOnlineNoiseStaAck.noisecalres[rxchanId].NoiseCalSta);
        noiseCheckSta->noisecalres[rxchanId].NoiseSmpSta = DPD_NTOHL(recv->msg.pimOnlineNoiseStaAck.noisecalres[rxchanId].NoiseSmpSta);
        noiseCheckSta->noisecalres[rxchanId].NoiseCalRes = DPD_NTOHL(recv->msg.pimOnlineNoiseStaAck.noisecalres[rxchanId].NoiseCalRes);
        noiseCheckSta->noisecalres[rxchanId].NoiseCalResId = DPD_NTOHL(recv->msg.pimOnlineNoiseStaAck.noisecalres[rxchanId].NoiseCalResId);
        noiseCheckSta->noisecalres[rxchanId].pimFreq = DPD_NTOHL(recv->msg.pimOnlineNoiseStaAck.noisecalres[rxchanId].pimFreq);
    }

    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdPimOnlineEnergyCalCtrl(*)
    功能 描述： 0x0017消息--PIM_OnLine启动
    输入参数 ：
    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdPimOnlineEnergyCalCtrl(T_DpdPimOnlineEnergyCalCtrl *pimOnlineEnergyCalCtrl)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 rxChanId = 0;
    UINT16   msgLen = sizeof(T_DpdPimOnlineEnergyCalCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIM_ONLINE_ENERGYCAL_CTRL;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;
    UINT32   retVal1 = BSP_OK;

    INPUT_POINTER_CHECK(pimOnlineEnergyCalCtrl);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);

    //send躁低检测无线帧号
    send->msg.pimOnlineEnergyCalCtrl.slotindex = DPD_HTONL(pimOnlineEnergyCalCtrl->slotindex);  /*躁低检测无线帧号*/
    for(chipId = 0; chipId < CHIP_NUM_MAX; chipId++)
    {
        for(rxChanId = 0; rxChanId < MAX_IC_CHIP_RX_CHAN; rxChanId++)
        {
            send->msg.pimOnlineEnergyCalCtrl.noisecalup[chipId][rxChanId].NoiseCalRes = DPD_HTONL(pimOnlineEnergyCalCtrl->noisecalup[chipId][rxChanId].NoiseCalRes);
            send->msg.pimOnlineEnergyCalCtrl.noisecalup[chipId][rxChanId].NoiseCalResId = DPD_HTONL(pimOnlineEnergyCalCtrl->noisecalup[chipId][rxChanId].NoiseCalResId);
            send->msg.pimOnlineEnergyCalCtrl.noisecalup[chipId][rxChanId].NoiseCalSta = DPD_HTONL(pimOnlineEnergyCalCtrl->noisecalup[chipId][rxChanId].NoiseCalSta);
            send->msg.pimOnlineEnergyCalCtrl.noisecalup[chipId][rxChanId].NoiseSmpSta = DPD_HTONL(pimOnlineEnergyCalCtrl->noisecalup[chipId][rxChanId].NoiseSmpSta);
            send->msg.pimOnlineEnergyCalCtrl.noisecalup[chipId][rxChanId].pimFreq = DPD_HTONL(pimOnlineEnergyCalCtrl->noisecalup[chipId][rxChanId].pimFreq);
        }
    }

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
    {
        if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            retVal |= BIT_SET(1);
            dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
            free(pucApiBuff);

            return retVal;
        }
    }

    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdGetPimOnlineCheckSta(*)
    功能 描述： 0x8017消息--PIM_OnLine检测查询状态

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdGetPimOnlineCheckSta(UINT32 *pimOnlineCheckSta)
{
    UINT32   retVal = BSP_OK;
    UINT16   msgLen = sizeof(T_DpdPimOnlineCheckSta);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_GET_ONLINE_PIM_VAL;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;
    UINT32   retVal1 = BSP_OK;

    INPUT_POINTER_CHECK(pimOnlineCheckSta);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != (retVal1 = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv)))
    {
        if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            retVal |= BIT_SET(1);
            dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
            free(pucApiBuff);

            return retVal;
        }
    }

    *pimOnlineCheckSta = DPD_NTOHL(recv->msg.pimOnlineCheckStaAck.result);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdGetPimOnlineCheckResult(*)
    功能 描述： 0xC00E消息--PIM_OnLine检测结果上报
    输入参数 ：
    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdGetPimOnlineCheckResult(T_DpdPimOnlineCheckResultAck *pimOnlineCheckRes)
{
    UINT32 retVal = BSP_OK;
    UINT32 chanId = 0;
    UINT32 bandId = 0;
    UINT32 loop = 0;
    UINT16 apduNum = 0xFFFF;
    UINT16 recvsize = 0;
    UINT16 *pbyPrintArray = NULL;
    UINT8  *pbyTemp = NULL;
    UINT16 msgLen = sizeof(T_DpdPimOnlineCheckResult);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_PIMONLINE_CHECK_RESULT;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU  *send = NULL;
    THpiApiPDU  *recv = NULL;

    INPUT_POINTER_CHECK(pimOnlineCheckRes);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    while(1)
    {
        send->head.msgType = DPD_HTONS(msgType);
        send->head.numAPDU = DPD_HTONS(apduNum);
        send->head.msgLen  = DPD_HTONS(msgLen);
        send->head.srcId   = (UINT8)GetUdpSrcId();
        send->head.dstId   = (UINT8)GetUdpDstId();
        send->head.typeId  = (UINT8)typeId;
        send->head.recvEn  = (UINT8)MSG_REQ;
        send->lenAPDU      = sizeof(send->head) + msgLen;

        if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            if(NULL != pbyPrintArray)
            {
                free(pbyPrintArray);
            }
            free(pucApiBuff);
            retVal |= BIT_SET(1);
            dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);

            return retVal;
        }

        apduNum = DPD_NTOHS(recv->head.numAPDU);
        if(NULL ==  pbyPrintArray)
        {
            pbyPrintArray = (UINT16 *)malloc((apduNum+1) * MAX_UPD_MSG_BODY + 1);
            if(NULL == pbyPrintArray)
            {
                free(pucApiBuff);
                retVal |= BIT_SET(1);
                dbgErr("%s>>TmppbyPrintArray Malloc Error!\n", __FUNCTION__);

                return retVal;
            }
            memset_s(pbyPrintArray, (apduNum+1) * MAX_UPD_MSG_BODY + 1, 0, (apduNum+1) * MAX_UPD_MSG_BODY + 1);
            pbyTemp = (UINT8 *)pbyPrintArray;
        }

        recvsize = (UINT16)DPD_NTOHS(recv->head.msgLen);
        memcpy_s(pbyTemp, recvsize, &recv->msg.pimOnlineCheckResAck, recvsize);
        pbyTemp += recvsize;

        if(0 == DPD_NTOHS(recv->head.numAPDU))
        {
            break;
        }
        else
        {
            apduNum = DPD_NTOHS(recv->head.numAPDU) -1;
        }
    };

    memcpy_s(pimOnlineCheckRes, sizeof(T_DpdPimOnlineCheckResultAck), pbyPrintArray, sizeof(T_DpdPimOnlineCheckResultAck));

    for(chanId = 0; chanId < MSG_DSP_CH_MAX; chanId++)
    {
        for(bandId = 0; bandId < MAX_BAND_NUM_PER_CHAN; bandId++)
        {
            pimOnlineCheckRes->pimpowerresut[chanId][bandId].noise = DPD_NTOHL(pimOnlineCheckRes->pimpowerresut[chanId][bandId].noise);
            pimOnlineCheckRes->pimpowerresut[chanId][bandId].noisecalsta = DPD_NTOHL(pimOnlineCheckRes->pimpowerresut[chanId][bandId].noisecalsta);
            pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimfreq = DPD_NTOHL(pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimfreq);
            pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimcheckType = DPD_NTOHL(pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimcheckType);
            for(loop = 0; loop < MAX_PIM_ENGCAL_TYPE;loop++)
            {
                pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimpower[loop] = DPD_NTOHL(pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimpower[loop]);
                pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimpowercalsta[loop] = DPD_NTOHL(pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimpowercalsta[loop]);
                pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimpowermax[loop] = DPD_NTOHL(pimOnlineCheckRes->pimpowerresut[chanId][bandId].pimpowermax[loop]);
            }
        }
    }

    free(pbyPrintArray);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdGetPimOnlineCheckRes(*)
    功能 描述： 0x0C01消息--PIM_OnLine检测结果上报
    输入参数 ：
    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdGetPimOnlineCheckRes(UINT32 chan, T_DpdPimOnlineResultAck *checkRes)
{
    UINT32   bandId = 0;
    UINT32   loop = 0;
    UINT16   msgLen = sizeof(T_DpdPimOnlineResult);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIMONLINE_CHECK_RES;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan = (UINT8)(chan);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n",__FUNCTION__, typeId, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    for(bandId = 0; bandId < MAX_BAND_NUM_PER_CHAN; bandId++)
    {
        checkRes->pimPowerReport[bandId].noise = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].noise);
        checkRes->pimPowerReport[bandId].pimfreq = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].pimfreq);
        checkRes->pimPowerReport[bandId].noisecalsta = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].noisecalsta);
        checkRes->pimPowerReport[bandId].pimcheckType = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].pimcheckType);
        checkRes->pimPowerReport[bandId].resSta = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].resSta);
        for(loop = 0; loop < MAX_PIM_ENGCAL_TYPE;loop++)
        {
            checkRes->pimPowerReport[bandId].pimpowermax[loop] = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].pimpowermax[loop]);
            checkRes->pimPowerReport[bandId].pimpower[loop] = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].pimpower[loop]);
            checkRes->pimPowerReport[bandId].pimpowercalsta[loop] = DPD_NTOHL(recv->msg.pimOnlineResAck.pimPowerReport[bandId].pimpowercalsta[loop]);
        }
    }
    free(pucApiBuff);

    return BSP_OK;
}

UINT32 DpdMsgSendData(UINT32 chan, UINT32 band, UINT16 msgType, UCHAR *pdata, UINT32 len)
{
    UINT32 retVal = BSP_OK;
    UINT16 apduNumNew = 0;
    UINT16 msgLen = 0;
    UINT16 apduNum = 0xFFFF;
    UINT8 *pbyTemp = NULL;
    UINT16 packetNum = 0;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    if(0 == len)
    {
        free(pucApiBuff);
        MsgPrint(PM_ERROR,"Table Length error!\n");

        return BSP_ERROR;
    }

    pbyTemp = (UINT8 *)pdata;
    packetNum = (UINT16)((len-1) / (MAX_UPD_MSG_BODY-4) + 1);
    apduNum = packetNum - 1;

    while(1)
    {
        apduNumNew = (1<<15)|apduNum;
        send->head.msgType = DPD_HTONS(msgType);
        send->head.numAPDU = (apduNum == (packetNum - 1))? DPD_HTONS(apduNumNew) : DPD_HTONS(apduNum);

        if(apduNum == 0)
        {
            msgLen  = (len- ((MAX_UPD_MSG_BODY-4) * (packetNum - 1)));
        }
        else
        {
            msgLen = (MAX_UPD_MSG_BODY-4);
        }

        send->head.msgLen  = DPD_HTONS(msgLen);
        send->head.chan = (UINT8)(chan);
        send->head.band = (UINT8)(band);
        send->head.srcId   = (UINT8)GetUdpSrcId();
        send->head.dstId   = (UINT8)GetUdpDstId();
        send->head.typeId  = (UINT8)typeId;
        send->head.recvEn  = (UINT8)MSG_REQ;
        send->lenAPDU      = sizeof(send->head) + msgLen;

        memcpy_s(&(send->msg.buf[0]), msgLen, pbyTemp, msgLen);

        if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
        {
            retVal |= BIT_SET(1);
            free(pucApiBuff);
            MsgPrint(PM_ERROR,"%s send msg 0x%04x,error!\n",__FUNCTION__,msgType);

            return retVal;
        }

        if(DPD_NTOHS(recv->msg.tMultiPacketAck.confirm) != BSP_OK)  //多包发送过程中有一包发送失败即整体都发送失败
        {
            retVal |= BIT_SET(1);
            dbgErr("%s>> Error! packetNum = %d  apduNum = %d Ret= %d\n",__FUNCTION__, packetNum, apduNum, retVal);
            free(pucApiBuff);

            return retVal;
        }

        if(0 == apduNum)
        {
            /*last msg*/
            MsgPrint(PM_INFO, "Send complete!\n");
            break;
        }
        pbyTemp += msgLen;
        apduNum--;
    }
    retVal = DPD_NTOHS(recv->msg.tMultiPacketAck.res);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
    函数名 称： DpdPimOnlineGetRruInfo(*)
    功能 描述： 0x4023消息--PIM_OnLine获取整机级硬件信息

    输出参数 ： 无
    返回值      ： BSP_OK: 成功
               其他: 失败
    其他说明 ： 无
    * 修改日期        版本号     修改人           修改内容
    * -----------------------------------------------
    *V1.0
 ***********************************************************************/
UINT32 DpdPimOnlineGetRruInfo(T_DpdPimOnlineHwRruInfo *rruInfo)
{
    UINT32   retVal = BSP_OK;
    UINT32   chipId = 0;
    UINT32   txchnId = 0;
    UINT32   rxchnId = 0;
    UINT32   txbandId = 0;
    UINT32   rxbandId = 0;
    UINT32   retry = 0;
    UINT16   msgType = DPD_MSG_PIM_ONLINE_GET_RRUINFO;
    UINT32   len = sizeof(T_DpdPimOnlineHwRruInfo);
    T_DpdPimOnlineHwRruInfo *pimOnlineRruInfo = NULL;

    INPUT_POINTER_CHECK(rruInfo);

    pimOnlineRruInfo = (T_DpdPimOnlineHwRruInfo *)malloc(sizeof(T_DpdPimOnlineHwRruInfo));
    if(NULL == pimOnlineRruInfo)
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>PimOnlineRruInfoBuf Malloc Error!\n", __FUNCTION__);

        return retVal;
    }

    memset_s(pimOnlineRruInfo, sizeof(T_DpdPimOnlineHwRruInfo), 0, sizeof(T_DpdPimOnlineHwRruInfo));

    pimOnlineRruInfo->chipNum = DPD_HTONL(rruInfo->chipNum);
    for(chipId = 0; chipId < rruInfo->chipNum; chipId++)
    {
        pimOnlineRruInfo->HwRruInfo[chipId].DlChnNum = DPD_HTONL(rruInfo->HwRruInfo[chipId].DlChnNum);

        for(txchnId = 0; txchnId < rruInfo->HwRruInfo[chipId].DlChnNum; txchnId++)
        {
            pimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].BandNum = DPD_HTONL(rruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].BandNum);
            pimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].FullPow = DPD_HTONL(rruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].FullPow);

            for(txbandId = 0; txbandId < rruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].BandNum; txbandId++)
            {
                pimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].TxDflFreqH[txbandId] = DPD_HTONL(rruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].TxDflFreqH[txbandId]);
                pimOnlineRruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].TxDflFreqL[txbandId] = DPD_HTONL(rruInfo->HwRruInfo[chipId].atHwDlChInfo[txchnId].TxDflFreqL[txbandId]);
            }
        }

        pimOnlineRruInfo->HwRruInfo[chipId].UlChnNum = DPD_HTONL(rruInfo->HwRruInfo[chipId].UlChnNum);

        for(rxchnId = 0; rxchnId < rruInfo->HwRruInfo[chipId].UlChnNum; rxchnId++)
        {
            pimOnlineRruInfo->HwRruInfo[chipId].atHwUlChInfo[rxchnId].BandNum = DPD_HTONL(rruInfo->HwRruInfo[chipId].atHwUlChInfo[rxchnId].BandNum);
            for(rxbandId = 0; rxbandId < rruInfo->HwRruInfo[chipId].atHwUlChInfo[rxchnId].BandNum; rxbandId++)
            {
                pimOnlineRruInfo->HwRruInfo[chipId].atHwUlChInfo[rxchnId].RxDflFreqH[rxbandId] = DPD_HTONL(rruInfo->HwRruInfo[chipId].atHwUlChInfo[rxchnId].RxDflFreqH[rxbandId]);
                pimOnlineRruInfo->HwRruInfo[chipId].atHwUlChInfo[rxchnId].RxDflFreqL[rxbandId] = DPD_HTONL(rruInfo->HwRruInfo[chipId].atHwUlChInfo[rxchnId].RxDflFreqL[rxbandId]);
            }
        }
    }

    for (retry = 0; retry < dpdmsgresendcount; retry++)
    {
        retVal = DpdMsgSendData(0, 0, msgType, (UCHAR *)pimOnlineRruInfo, len);
        if (BSP_OK == retVal)
        {
            break;
        }
    }
    if(retry == dpdmsgresendcount)
    {
        dbgErr("[%s] dpd msg send fail! retry:%u, retVal:0x%04X \n", __FUNCTION__, retry, retVal);
    }

    free(pimOnlineRruInfo);

    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSendFilterPara(*)
 功能 描述： 0x401a消息--驻波位置在线检测发送滤波器参数
 输入参数 ： chan   - 通道号    para   - 滤波器参数
 输出参数 ： 无
 返 回 值 ： BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2022/5/10      V1.0    003000750          新建
***********************************************************************/
UINT32 DpdMsgSendFilterPara(UINT32 chan, UINT32 freqNo, T_VswrPosCalcPara *para)
{
   UINT16   retVal = BSP_OK;
   UINT16   msgLen = sizeof(T_VswrPosCalcPara);
   UINT8    typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16   msgType = DPD_MSG_ONLINE_SEND_FILTER_PARA;
   THpiApiPDU   *pucApiBuff = NULL;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

   INPUT_POINTER_CHECK(para);

   pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return BSP_ERROR;
   }
   memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = &pucApiBuff[0];
   recv = &pucApiBuff[1];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;
   send->head.srcId   = GetUdpSrcId();
   send->head.dstId   = GetUdpDstId();
   send->head.typeId  = typeId;
   send->head.recvEn  = MSG_REQ;
   send->msg.calcPara.isOuterFilter = para->isOuterFilter;
   send->msg.calcPara.startFreq     = DPD_HTONL(para->startFreq);
   send->msg.calcPara.endFreq       = DPD_HTONL(para->endFreq);
   send->lenAPDU      = sizeof(send->head) + msgLen;

    dbgInfoEx("[%s] Chan[%d] isOuterFilter[%d] startFreq[%d] endFreq[%d]\n",__FUNCTION__, chan, para->isOuterFilter,
    para->startFreq,para->endFreq);

   if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
   {
       dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
       free(pucApiBuff);
       return BSP_ERROR;
   }

   retVal = DPD_NTOHS(recv->msg.calcParaAck.result);
   MsgResultProc(retVal);
   free(pucApiBuff);
   return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendPaStatus(*)
 功能描述： 0x4027消息--功放状态高层下发
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendPaStatus(UINT32 bspChan, T_ChanPaStaMsg * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_CHAN_PASTATUS;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.dpdChanPaStaMsg);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)bspChan;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dpdChanPaStaMsg.uiPaSta = DPD_HTONL(pdata ->uiPaSta);

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s bspChan=%d send msg 0x%04x,error!\n",__FUNCTION__,bspChan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.dpdChanPaStaAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendRfIoCtrlMode(*)
 功能描述： 0x4028消息--电子开关是否强制模式
 输入参数： chan -  pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendRfIoCtrlMode(UINT32 chan, T_DspMsgRfIoCtrlMode * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SEND_IOCTRL_STA;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32     loop = 0;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(T_DspMsgRfIoCtrlMode);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    for(loop = 0; loop < IC_CHAN_NUM_MAX;loop++)
    {
        send->msg.rfIoCtrlMode.ioCtrlMode[loop] = DPD_HTONL(pdata->ioCtrlMode[loop]);
    }
    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.rfIoCtrlModeAck.result);
    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendChTssiInfo(*)
 功能描述： 0x4029消息--子端数字功率下发
 输入参数： chan -  pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ***********************************************************************/
UINT32 DpdMsgSendChTssiInfo(UINT32 chan, T_DspMsgChnTssiInfo * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SEND_CHNTSSI_INFO;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32     loop = 0;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    msgLen = sizeof(T_DspMsgChnTssiInfo);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    for(loop = 0; loop < IC_CHAN_NUM_MAX;loop++)
    {
        send->msg.chnTssiInfo.vaildFlag[loop] = DPD_HTONL(pdata->vaildFlag[loop]);
        send->msg.chnTssiInfo.chanTssi[loop] = DPD_HTONL(pdata->chanTssi[loop]);
    }
    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.chnTssiInfoAck.result);
    free(pucApiBuff);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgMultFreqSrcCtrl(*)
 功能 描述： 0x001E消息--多音源启停控制
 输入参数 ：
 输出参数 ： 无
 返 回 值 ： BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2022/7/3      V1.0
***********************************************************************/
UINT32 DpdMsgMultFreqSrcCtrl(UINT32 chan, T_DpdMultFreqSrcCtrlMsg *para)
{
   UINT16 retVal = 0;
   UINT32 loop = 0;
   UINT32 txFreqTypeNum = 3;
   UINT16 msgLen = sizeof(T_DpdMultFreqSrcCtrlMsg);
   UINT8  typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16 msgType = DPD_MSG_MULT_FREQ_SRC_CTRL;
   THpiApiPDU *pucApiBuff = NULL;
   THpiApiPDU *send = NULL;
   THpiApiPDU *recv = NULL;

   INPUT_POINTER_CHECK(para);

   pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return BSP_ERROR;
   }
   memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = &pucApiBuff[0];
   recv = &pucApiBuff[1];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.srcId   = GetUdpSrcId();
   send->head.dstId   = GetUdpDstId();
   send->head.typeId  = typeId;
   send->head.recvEn  = MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;
   send->msg.multFreqSrcCtrlMsg.txTaskType     = DPD_HTONL(para->txTaskType);
   send->msg.multFreqSrcCtrlMsg.multFreqInfoCfg.txTypeNum = DPD_HTONL(para->multFreqInfoCfg.txTypeNum);
   for(loop = 0; loop < txFreqTypeNum; loop++)
   {
       send->msg.multFreqSrcCtrlMsg.multFreqInfoCfg.gainCaliBwInfo[loop].txFreqStep = DPD_HTONL(para->multFreqInfoCfg.gainCaliBwInfo[loop].txFreqStep);
       send->msg.multFreqSrcCtrlMsg.multFreqInfoCfg.gainCaliBwInfo[loop].txFreqStart = DPD_HTONL(para->multFreqInfoCfg.gainCaliBwInfo[loop].txFreqStart);
       send->msg.multFreqSrcCtrlMsg.multFreqInfoCfg.gainCaliBwInfo[loop].txFreqEnd = DPD_HTONL(para->multFreqInfoCfg.gainCaliBwInfo[loop].txFreqEnd);
   }

   if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
   {
       dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
       free(pucApiBuff);
       return BSP_ERROR;
   }

   retVal = DPD_NTOHS(recv->msg.multFreqRecvComMsg.result);
   MsgResultProc(retVal);
   free(pucApiBuff);

   return retVal;
}

/**************************************************************************
 函数名 称： DpdGetPwdCaliResult(*)
 功能 描述： 0x801F消息--查询多音源发起状态
 输入参数 ：
 输出参数 ： 无
 返 回 值 ： BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2022/7/3      V1.0
***********************************************************************/
UINT32 DpdGetPwdCaliResult(UINT32 chan, T_DpdPwdCaliMsg *launchSta, T_PwdCaliResult *para)
{
   UINT16 retVal = BSP_OK;
   UINT32 loop = 0;
   UINT32 caliFreqNum = 30;
   UINT16 msgLen = sizeof(T_DpdPwdCaliMsg);
   UINT8  typeId = HEAD_TYPE_ID_SOC_DSP;
   UINT16 msgType = DPD_MSG_MULT_FREQ_TRANSMIT_RESULT;
   THpiApiPDU *pucApiBuff = NULL;
   THpiApiPDU *send = NULL;
   THpiApiPDU *recv = NULL;

   INPUT_POINTER_CHECK(launchSta);
   INPUT_POINTER_CHECK(para);

   pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
   if (NULL == pucApiBuff)
   {
       dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
       return BSP_ERROR;
   }
   memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

   send = &pucApiBuff[0];
   recv = &pucApiBuff[1];
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);
   send->head.chan    = (UINT8)chan;
   send->head.srcId   = GetUdpSrcId();
   send->head.dstId   = GetUdpDstId();
   send->head.typeId  = typeId;
   send->head.recvEn  = MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;
   send->msg.multFreqTransmitSta.txTaskType = DPD_HTONL(launchSta->txTaskType);

   if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
   {
       dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
       free(pucApiBuff);

       return BSP_ERROR;
   }

   para->taskType = DPD_NTOHL(recv->msg.multFreqPwdCaliRes.taskType);
   para->finish = DPD_NTOHL(recv->msg.multFreqPwdCaliRes.finish);
   para->result = DPD_NTOHL(recv->msg.multFreqPwdCaliRes.result);
   para->pwdResult.txFreqNum = DPD_NTOHL(recv->msg.multFreqPwdCaliRes.pwdResult.txFreqNum);
   for(loop = 0; loop < caliFreqNum; loop++)
   {
       para->pwdResult.txFreqPowVal[loop].txTssi = DPD_NTOHL(recv->msg.multFreqPwdCaliRes.pwdResult.txFreqPowVal[loop].txTssi);
       para->pwdResult.txFreqPowVal[loop].fbPow = DPD_NTOHL(recv->msg.multFreqPwdCaliRes.pwdResult.txFreqPowVal[loop].fbPow);
       para->pwdResult.txFreqPowVal[loop].txFreq = DPD_NTOHL(recv->msg.multFreqPwdCaliRes.pwdResult.txFreqPowVal[loop].txFreq);
   }

   free(pucApiBuff);
   return retVal;
}

#define DPD_MSG_SLOT_VOLT_TRAP_CTRL              0x001c     /*时隙调压预埋表提取控制*/
#define DPD_MSG_TRAP_EMBEDLUT_STA                0x801b     /*预埋表提取完成状态*/
#define DPD_MSG_TRAP_EMBEDLUT_QUERY              0x801c     /*预埋表提取*/

/**********************************************************************
 函数名称： DpdMsgSlotVoltTrapEmbedLutCtrl(*)
 功能描述： 0x001c消息--预埋表提取控制消息
 输入参数： pdata - 参数结构体
 输出参数： 无
 返 回 值： BSP_OK: 成功    其他: 失败
 其他说明： 无
 修改日期：      1.0     10300780     增加0x001c时隙调压调压预埋表提取控制消息
***********************************************************************/
UINT32 DpdMsgSlotVoltTrapEmbedLutCtrl(T_TrapEmbedLutCtrlMsg *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_SLOT_VOLT_TRAP_CTRL;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.trapEmbedLutCtrl);

    //coverity[cert_exp39_c_violation:SUPPRESS]
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.trapEmbedLutCtrl.uiCtrlFlg = DPD_HTONL(pdata->uiCtrlFlg);
    send->msg.trapEmbedLutCtrl.uiVoltGrd = DPD_HTONL(pdata->uiVoltGrd);
    send->msg.trapEmbedLutCtrl.uiChMsk = DPD_HTONL(pdata->uiChMsk);
    dbgInfoEx("[%s] uiCtrlFlg[%#x]\n",__func__, send->msg.trapEmbedLutCtrl.uiCtrlFlg);
    dbgInfoEx("[%s] uiVoltGrd[%#x]\n",__func__, send->msg.trapEmbedLutCtrl.uiVoltGrd);
    dbgInfoEx("[%s] uiChMsk[%#x]\n",__func__, send->msg.trapEmbedLutCtrl.uiChMsk);

    dbgInfo("------------ SWITCH INFO ANALYSE OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,0,msgType);
        free(pucApiBuff);
        return retVal;
    }
    dbgInfo("------------ SEND DSP MSG OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = DPD_NTOHS(recv->msg.trapEmbedLutCtrlAck.uwResult);
    if(0 != retVal)
    {
        dbgErr("[%s] Recv Msg Result = %d\r\n",__func__,retVal);
    }
    dbgInfo("------------ RECV DSP MSG OVER ------------\n");

    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgChkTrapEmbedLutSta(*)
 功能描述： 0x801b消息--预埋表提取完成状态上报消息
 输入参数： pdata - 参数结构体
 输出参数： 无
 返 回 值： BSP_OK: 成功    其他: 失败
 其他说明： 无
 修改日期：      1.0     10300780     增加0x801b预埋表提取完成状态上报消息
***********************************************************************/
UINT32 DpdMsgChkTrapEmbedLutSta(T_TrapEmbedLutStaMsg *pdata)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_TRAP_EMBEDLUT_STA;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.trapEmbedLutSta);

    //coverity[cert_exp39_c_violation:SUPPRESS]
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;

    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.trapEmbedLutSta.uiProcSta = DPD_HTONL(pdata->uiProcSta);
    dbgInfoEx("[%s] uiProcSta[%#x]\n",__func__, send->msg.trapEmbedLutSta.uiProcSta);
    for(loop = 0; loop < MSG_DSP_CH_MAX; loop++)
    {
        send->msg.trapEmbedLutSta.auiChResult[loop] = pdata->auiChResult[loop];
        dbgInfoEx("[%s] [ch%d]auiChResult[%#x]\n",__func__, loop, send->msg.trapEmbedLutSta.auiChResult[loop]);
    }

    dbgInfo("------------ SWITCH INFO ANALYSE OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = SendHpiMsg(GET_DSP_ID(0), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,0,msgType);
        free(pucApiBuff);
        return retVal;
    }
    dbgInfo("------------ SEND DSP MSG OVER ------------\n");

    //coverity[cert_exp39_c_violation:SUPPRESS]
    retVal = DPD_NTOHS(recv->msg.trapEmbedLutStaAck.uwResult);
    if(0 != retVal)
    {
        dbgErr("[%s] Recv Msg Result = %d\r\n",__func__,retVal);
    }
    dbgInfo("------------ RECV DSP MSG OVER ------------\n");

    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgGetChnPowInfo(*)
 功能描述： 0x8022消息--子端功率读取
 输入参数： chan -  pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ***********************************************************************/
UINT32 DpdMsgGetChnPowInfo(UINT32 chan, T_DspMsgChnPowInfoAck * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_GET_CHNPOW;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32     loop = 0;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    msgLen = sizeof(T_DpdMsgChnPowInfo);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    pdata->chNum = DPD_NTOHL(recv->msg.chnPowInfoAck.chNum);
    for(loop = 0; loop < pdata->chNum; loop++)
    {
       pdata->chPowInfo[loop].chType = DPD_NTOHL(recv->msg.chnPowInfoAck.chPowInfo[loop].chType);
       pdata->chPowInfo[loop].isBusy = DPD_NTOHL(recv->msg.chnPowInfoAck.chPowInfo[loop].isBusy);
       pdata->chPowInfo[loop].chPowCalCnt = DPD_NTOHL(recv->msg.chnPowInfoAck.chPowInfo[loop].chPowCalCnt);
       pdata->chPowInfo[loop].txPow = DPD_NTOHL(recv->msg.chnPowInfoAck.chPowInfo[loop].txPow);
       pdata->chPowInfo[loop].fbPow = DPD_NTOHL(recv->msg.chnPowInfoAck.chPowInfo[loop].fbPow);
       dbgInfoEx("%d %d %d %d %d\n", pdata->chPowInfo[loop].chType, pdata->chPowInfo[loop].isBusy,
           pdata->chPowInfo[loop].chPowCalCnt, pdata->chPowInfo[loop].txPow, pdata->chPowInfo[loop].fbPow);
    }
    free(pucApiBuff);
    return retVal;
}

UINT32 DpdPimConfigLmsCtrl(INT32 ctrl)
{
    UINT32   retVal = 0;
    UINT16   msgLen = sizeof(T_DpdPimChkLmsCtrlMsg);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIMCONFIG_ANALYSIS_CRTL;
    THpiApiPDU   *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->msg.pimChkLmsCtrlMsg.ctrl = DPD_HTONL(ctrl);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n",__FUNCTION__, typeId, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHS(recv->msg.pimRecvComMsg.result);
    free(pucApiBuff);

    return retVal;
}

UINT32 DpdPimChkLmsIterSta(VOID)
{
    UINT32   retVal = 0;
    UINT16   msgLen = sizeof(T_DpdPimLmsStaMsg);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_LMS_ITERATIVETASK_QUERY;
    THpiApiPDU   *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n",__FUNCTION__, typeId, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHL(recv->msg.pimLmsIterStaCheck.lmsIterFinAllSta);
    free(pucApiBuff);

    return retVal;
}

UINT32 DpdPimCfgEnergyCalCtrl(INT32 ctrl, INT32 slotindex)
{
    UINT32   retVal = 0;
    UINT16   msgLen = sizeof(T_DpdPimCfgEnergyCalCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIMCONFIG_ENERGY_CAL;
    UINT32   tddFlag = 0;
    THpiApiPDU   *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->msg.pimCfgEnergyCalCtrlMsg.ctrl = DPD_HTONL(ctrl);
    send->msg.pimCfgEnergyCalCtrlMsg.slotIndex = DPD_HTONL(slotindex);
    if(BSP_OK != BspHalAdaptGetOneFddValidChan(&tddFlag))
    {
        tddFlag = 0;
    }
    send->msg.pimCfgEnergyCalCtrlMsg.tddFlag = DPD_HTONL(tddFlag);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n",__FUNCTION__, typeId, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHS(recv->msg.pimCfgEnergyCalRecvMsg.result);
    free(pucApiBuff);

    return retVal;
}

UINT32 DpdPimCfgAnalysisQuery(UINT32 *pimChkSta)
{
    UINT32   retVal = 0;
    UINT16   msgLen = sizeof(T_DpdPimChkStaCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIMCONFIG_ANALYSIS_STATUS_QUERY;
    THpiApiPDU   *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(pimChkSta);

    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n",__FUNCTION__, typeId, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    *pimChkSta = DPD_NTOHL(recv->msg.pimChkUpTxStatus.pimChkCalFinSat);
    dbgInfoEx("[%s]pimChkCalFinSat:0x%x\n", __FUNCTION__, *pimChkSta);

    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgSetPimOnlinePara(*)
 功能 描述： 0x4020消息--设置PIM配置信息下发
 输入参数 ：
 输出参数 ： 无
 返回值      ：   BSP_OK: 成功
                 其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
***********************************************************************/
UINT32 DpdMsgSetPimOnlinePara(T_DpdMsgSetOnlinePimPara *pdata)
{
    UINT32      retVal  = BSP_OK;
    UINT32      len  = sizeof(T_DpdMsgSetOnlinePimPara);
    UINT16      msgType = DPD_MSG_PIMCONFIG_INFO_DISTRIBUTION;
    UINT32      chanLoop= 0;
    UINT32      carr    = 0;
    T_PimOnlineChnTxDsp *pimTxData = NULL;
    T_PimOnlineChnRxDsp *pimRxData = NULL;
    T_DpdMsgSetOnlinePimPara *setOnlinePim2Para = NULL;

    INPUT_POINTER_CHECK(pdata);

    setOnlinePim2Para = (T_DpdMsgSetOnlinePimPara *)malloc(sizeof(T_DpdMsgSetOnlinePimPara));
    if(NULL == setOnlinePim2Para)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }

    setOnlinePim2Para->powPercent = DPD_HTONL(pdata->powPercent);
    setOnlinePim2Para->pimChkMode = DPD_HTONL(pdata->pimChkMode);
    setOnlinePim2Para->clearLutFlag = DPD_HTONL(pdata->clearLutFlag);
    setOnlinePim2Para->txChnNum   = DPD_HTONL(pdata->txChnNum);
    setOnlinePim2Para->rxChnNum   = DPD_HTONL(pdata->rxChnNum);

    for (chanLoop = 0; chanLoop < pdata->txChnNum; chanLoop++)
    {
        pimTxData = &setOnlinePim2Para->txChnPimOnline[chanLoop];
        pimTxData->txChnNo = DPD_HTONL(pdata->txChnPimOnline[chanLoop].txChnNo);
        pimTxData->carrNum = DPD_HTONL(pdata->txChnPimOnline[chanLoop].carrNum);
        pimTxData->txLoFlag = DPD_HTONL(pdata->txChnPimOnline[chanLoop].txLoFlag);
        pimTxData->txLoFreq = DPD_HTONL(pdata->txChnPimOnline[chanLoop].txLoFreq);
        for (carr = 0; carr < pdata->txChnPimOnline[chanLoop].carrNum; carr++)
        {
            pimTxData->pimOnlineItemTx[carr].carrNo       = DPD_HTONL(pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carr].carrNo);
            pimTxData->pimOnlineItemTx[carr].carrMode     = DPD_HTONL(pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carr].carrMode);
            pimTxData->pimOnlineItemTx[carr].txFreq       = DPD_HTONL(pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carr].txFreq);
            pimTxData->pimOnlineItemTx[carr].bandNco      = DPD_HTONL(pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carr].bandNco);
            pimTxData->pimOnlineItemTx[carr].txBandWidth  = DPD_HTONL(pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carr].txBandWidth);
            pimTxData->pimOnlineItemTx[carr].carrPow      = DPD_HTONL(pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carr].carrPow);
        }
    }
    for (chanLoop = 0; chanLoop < pdata->rxChnNum; chanLoop++)
    {
        pimRxData = &setOnlinePim2Para->rxChnPimOnline[chanLoop];
        pimRxData->rxChnNo = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].rxChnNo);
        pimRxData->carrNum = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].carrNum);
        pimRxData->rxLoFlag = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].rxLoFlag);
        pimRxData->rxLoFreq = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].rxLoFreq);
        for (carr = 0; carr < pdata->rxChnPimOnline[chanLoop].carrNum; carr++)
        {
            pimRxData->pimOnlineItemRx[carr].carrNo       = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carr].carrNo);
            pimRxData->pimOnlineItemRx[carr].carrMode     = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carr].carrMode);
            pimRxData->pimOnlineItemRx[carr].rxFreq       = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carr].rxFreq);
            pimRxData->pimOnlineItemRx[carr].bandNco      = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carr].bandNco);
            pimRxData->pimOnlineItemRx[carr].rxBandWidth  = DPD_HTONL(pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carr].rxBandWidth);
        }
    }

    retVal = DpdMsgSendData(0,0,msgType, (UCHAR *)setOnlinePim2Para, len);
    free(setOnlinePim2Para);

    return retVal;
}

/* Started by AICoder, pid:s464fn799ee87da141a808c9e0bf704113d05617 */
UINT32 DpdPimChkModInfoConfig(T_DpdMsgPimOnChkModInfo *PimOnChkModInfo)
{
    UINT32 retVal = BSP_OK;
    UINT16   msgLen = sizeof(T_DpdMsgPimOnChkModInfo);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_PIMCONFIG_CHKINFO;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(PimOnChkModInfo);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);

    send->msg.pimOnChkModInfo.powPercent = DPD_HTONL(PimOnChkModInfo->powPercent);
    send->msg.pimOnChkModInfo.pimChkMode = DPD_HTONL(PimOnChkModInfo->pimChkMode);
    send->msg.pimOnChkModInfo.clearLutFlag = DPD_HTONL(PimOnChkModInfo->clearLutFlag);
    send->msg.pimOnChkModInfo.txChnNum = DPD_HTONL(PimOnChkModInfo->txChnNum);
    send->msg.pimOnChkModInfo.rxChnNum = DPD_HTONL(PimOnChkModInfo->rxChnNum);

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHS(recv->msg.pimOnChkModInfoAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:s464fn799ee87da141a808c9e0bf704113d05617 */

/* Started by AICoder, pid:5f1e122878w59751473709d45016b9531a60f1ce */
UINT32 DpdPimOnlineChnTxConfig(T_DpdMsgPimOnlineChnTx *PimOnlineChnTxInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT16 msgLen = sizeof(T_DpdMsgPimOnlineChnTx);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_PIMCONFIG_TX_CARRINFO;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(PimOnlineChnTxInfo);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);

    send->msg.PimOnlineChnTxInfo.txChnNo = DPD_HTONL(PimOnlineChnTxInfo->txChnNo);
    send->msg.PimOnlineChnTxInfo.carrNum = DPD_HTONL(PimOnlineChnTxInfo->carrNum);
    send->msg.PimOnlineChnTxInfo.txLoFlag = DPD_HTONL(PimOnlineChnTxInfo->txLoFlag);
    send->msg.PimOnlineChnTxInfo.txLoFreq = DPD_HTONL(PimOnlineChnTxInfo->txLoFreq);

    for(loop = 0; loop < PimOnlineChnTxInfo->carrNum; loop++)
    {
        send->msg.PimOnlineChnTxInfo.pimOnlineItemTx[loop].carrNo = DPD_HTONL(PimOnlineChnTxInfo->pimOnlineItemTx[loop].carrNo);
        send->msg.PimOnlineChnTxInfo.pimOnlineItemTx[loop].carrMode = DPD_HTONL(PimOnlineChnTxInfo->pimOnlineItemTx[loop].carrMode);
        send->msg.PimOnlineChnTxInfo.pimOnlineItemTx[loop].txFreq = DPD_HTONL(PimOnlineChnTxInfo->pimOnlineItemTx[loop].txFreq);
        send->msg.PimOnlineChnTxInfo.pimOnlineItemTx[loop].bandNco = DPD_HTONL(PimOnlineChnTxInfo->pimOnlineItemTx[loop].bandNco);
        send->msg.PimOnlineChnTxInfo.pimOnlineItemTx[loop].txBandWidth = DPD_HTONL(PimOnlineChnTxInfo->pimOnlineItemTx[loop].txBandWidth);
        send->msg.PimOnlineChnTxInfo.pimOnlineItemTx[loop].carrPow = DPD_HTONL(PimOnlineChnTxInfo->pimOnlineItemTx[loop].carrPow);
    }

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHS(recv->msg.PimOnlineChnTxAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);;

    return retVal;
}
/* Ended by AICoder, pid:5f1e122878w59751473709d45016b9531a60f1ce */

/* Started by AICoder, pid:109fag503e4f22e14c5b0bd5a04f0e4030f9504e */
UINT32 DpdPimOnlineChnRxConfig(T_DpdMsgPimOnlineChnRx *PimOnlineChnRxInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT16 msgLen = sizeof(T_DpdMsgPimOnlineChnRx);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_PIMCONFIG_RX_CARRINFO;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(PimOnlineChnRxInfo);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);

    send->msg.PimOnlineChnRxInfo.rxChnNo = DPD_HTONL(PimOnlineChnRxInfo->rxChnNo);
    send->msg.PimOnlineChnRxInfo.carrNum = DPD_HTONL(PimOnlineChnRxInfo->carrNum);
    send->msg.PimOnlineChnRxInfo.rxLoFlag = DPD_HTONL(PimOnlineChnRxInfo->rxLoFlag);
    send->msg.PimOnlineChnRxInfo.rxLoFreq = DPD_HTONL(PimOnlineChnRxInfo->rxLoFreq);

    for(loop = 0; loop < PimOnlineChnRxInfo->carrNum; loop++)
    {
        send->msg.PimOnlineChnRxInfo.pimOnlineItemRx[loop].carrNo = DPD_HTONL(PimOnlineChnRxInfo->pimOnlineItemRx[loop].carrNo);
        send->msg.PimOnlineChnRxInfo.pimOnlineItemRx[loop].carrMode = DPD_HTONL(PimOnlineChnRxInfo->pimOnlineItemRx[loop].carrMode);
        send->msg.PimOnlineChnRxInfo.pimOnlineItemRx[loop].rxFreq = DPD_HTONL(PimOnlineChnRxInfo->pimOnlineItemRx[loop].rxFreq);
        send->msg.PimOnlineChnRxInfo.pimOnlineItemRx[loop].bandNco = DPD_HTONL(PimOnlineChnRxInfo->pimOnlineItemRx[loop].bandNco);
        send->msg.PimOnlineChnRxInfo.pimOnlineItemRx[loop].rxBandWidth = DPD_HTONL(PimOnlineChnRxInfo->pimOnlineItemRx[loop].rxBandWidth);
    }

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",__FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHS(recv->msg.PimOnlineChnRxAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);;

    return retVal;
}
/* Ended by AICoder, pid:109fag503e4f22e14c5b0bd5a04f0e4030f9504e */

/* Started by AICoder, pid:v4628w49e7y599c14c1f09c6703b2f3c7af12020 */
UINT32 DpdMsgPimCheckModeInfo(T_DpdMsgSetOnlinePimPara *pdata)
{
    UINT32 retVal = 0;
    T_DpdMsgPimOnChkModInfo *PimOnChkModInfo = NULL;

    INPUT_POINTER_CHECK(pdata);

    PimOnChkModInfo = (T_DpdMsgPimOnChkModInfo *)malloc(sizeof(T_DpdMsgPimOnChkModInfo));
    if(NULL == PimOnChkModInfo)
    {
        dbgErr("%s>>PimOnChkModInfo, TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(PimOnChkModInfo, sizeof(T_DpdMsgPimOnChkModInfo), 0, sizeof(T_DpdMsgPimOnChkModInfo));
    PimOnChkModInfo->powPercent = pdata->powPercent;
    PimOnChkModInfo->pimChkMode = pdata->pimChkMode;
    PimOnChkModInfo->clearLutFlag = pdata->clearLutFlag;
    PimOnChkModInfo->txChnNum   = pdata->txChnNum;
    PimOnChkModInfo->rxChnNum   = pdata->rxChnNum;

    retVal = DpdPimChkModInfoConfig(PimOnChkModInfo);
    if(BSP_OK != retVal)
    {
        BspLog(LOG_LEVEL_0, "DpdPimChkModInfoConfig retVal= %d\n", retVal);
        free(PimOnChkModInfo);
        return BSP_ERROR;
    }

    free(PimOnChkModInfo);
    return BSP_OK;
}
/* Ended by AICoder, pid:v4628w49e7y599c14c1f09c6703b2f3c7af12020 */

/* Started by AICoder, pid:yc0ceu323cse9d114a730875d0cfc5443184fa70 */
UINT32 DpdMsgPimCheckChnTxInfo(T_DpdMsgSetOnlinePimPara *pdata)
{
    UINT32 retVal = 0;
    UINT32 chanLoop = 0;
    UINT32 carrLoop = 0;
    T_DpdMsgPimOnlineChnTx *PimOnlineChnTxInfo = NULL;

    INPUT_POINTER_CHECK(pdata);

    PimOnlineChnTxInfo = (T_DpdMsgPimOnlineChnTx *)malloc(sizeof(T_DpdMsgPimOnlineChnTx));
    if(NULL == PimOnlineChnTxInfo)
    {
        dbgErr("%s>>PimOnlineChnTxInfo, TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(PimOnlineChnTxInfo, sizeof(T_DpdMsgPimOnlineChnTx), 0, sizeof(T_DpdMsgPimOnlineChnTx));
    for(chanLoop = 0; chanLoop < pdata->txChnNum; chanLoop++)
    {
        PimOnlineChnTxInfo->txChnNo = pdata->txChnPimOnline[chanLoop].txChnNo;
        PimOnlineChnTxInfo->carrNum = pdata->txChnPimOnline[chanLoop].carrNum;
        PimOnlineChnTxInfo->txLoFlag = pdata->txChnPimOnline[chanLoop].txLoFlag;
        PimOnlineChnTxInfo->txLoFreq = pdata->txChnPimOnline[chanLoop].txLoFreq;
        for (carrLoop = 0; carrLoop < pdata->txChnPimOnline[chanLoop].carrNum; carrLoop++)
        {
            PimOnlineChnTxInfo->pimOnlineItemTx[carrLoop].carrNo      = pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carrLoop].carrNo;
            PimOnlineChnTxInfo->pimOnlineItemTx[carrLoop].carrMode    = pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carrLoop].carrMode;
            PimOnlineChnTxInfo->pimOnlineItemTx[carrLoop].txFreq      = pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carrLoop].txFreq;
            PimOnlineChnTxInfo->pimOnlineItemTx[carrLoop].bandNco     = pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carrLoop].bandNco;
            PimOnlineChnTxInfo->pimOnlineItemTx[carrLoop].txBandWidth = pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carrLoop].txBandWidth;
            PimOnlineChnTxInfo->pimOnlineItemTx[carrLoop].carrPow     = pdata->txChnPimOnline[chanLoop].pimOnlineItemTx[carrLoop].carrPow;
        }
        retVal = DpdPimOnlineChnTxConfig(PimOnlineChnTxInfo);
        if(BSP_OK != retVal)
        {
            BspLog(LOG_LEVEL_0, "chan = %d, DpdPimOnlineChnTxConfig retVal= %d\n", chanLoop, retVal);
            free(PimOnlineChnTxInfo);
            return BSP_ERROR;
        }
    }

    free(PimOnlineChnTxInfo);
    return BSP_OK;
}
/* Ended by AICoder, pid:yc0ceu323cse9d114a730875d0cfc5443184fa70 */

/* Started by AICoder, pid:o5e5cq46e2g4516144600969c0d0b7450153718e */
UINT32 DpdMsgPimCheckChnRxInfo(T_DpdMsgSetOnlinePimPara *pdata)
{
    UINT32 retVal = 0;
    UINT32 chanLoop = 0;
    UINT32 carrLoop = 0;
    T_DpdMsgPimOnlineChnRx *PimOnlineChnRxInfo = NULL;

    INPUT_POINTER_CHECK(pdata);

    PimOnlineChnRxInfo = (T_DpdMsgPimOnlineChnRx *)malloc(sizeof(T_DpdMsgPimOnlineChnRx));
    if(NULL == PimOnlineChnRxInfo)
    {
        dbgErr("%s>>PimOnlineChnRxInfo, TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(PimOnlineChnRxInfo, sizeof(T_DpdMsgPimOnlineChnRx), 0, sizeof(T_DpdMsgPimOnlineChnRx));
    for(chanLoop = 0; chanLoop < pdata->rxChnNum; chanLoop++)
    {
        PimOnlineChnRxInfo->rxChnNo = pdata->rxChnPimOnline[chanLoop].rxChnNo;
        PimOnlineChnRxInfo->carrNum = pdata->rxChnPimOnline[chanLoop].carrNum;
        PimOnlineChnRxInfo->rxLoFlag = pdata->rxChnPimOnline[chanLoop].rxLoFlag;
        PimOnlineChnRxInfo->rxLoFreq = pdata->rxChnPimOnline[chanLoop].rxLoFreq;
        for (carrLoop = 0; carrLoop < pdata->rxChnPimOnline[chanLoop].carrNum; carrLoop++)
        {
            PimOnlineChnRxInfo->pimOnlineItemRx[carrLoop].carrNo      = pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carrLoop].carrNo;
            PimOnlineChnRxInfo->pimOnlineItemRx[carrLoop].carrMode    = pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carrLoop].carrMode;
            PimOnlineChnRxInfo->pimOnlineItemRx[carrLoop].rxFreq      = pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carrLoop].rxFreq;
            PimOnlineChnRxInfo->pimOnlineItemRx[carrLoop].bandNco     = pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carrLoop].bandNco;
            PimOnlineChnRxInfo->pimOnlineItemRx[carrLoop].rxBandWidth = pdata->rxChnPimOnline[chanLoop].pimOnlineItemRx[carrLoop].rxBandWidth;
        }
        retVal = DpdPimOnlineChnRxConfig(PimOnlineChnRxInfo);
        if(BSP_OK != retVal)
        {
            BspLog(LOG_LEVEL_0, "chan = %d, DpdPimOnlineChnRxConfig retVal= %d\n", chanLoop, retVal);
            free(PimOnlineChnRxInfo);
            return BSP_ERROR;
        }
    }

    free(PimOnlineChnRxInfo);
    return BSP_OK;
}
/* Ended by AICoder, pid:o5e5cq46e2g4516144600969c0d0b7450153718e */

UINT32 DpdMsgPimConfigDistribute(T_DpdMsgSetOnlinePimPara *pdata)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pdata);

    retVal = DpdMsgPimCheckModeInfo(pdata);
    CHECK_RETVAL(DpdMsgPimCheckModeInfo, retVal);

    retVal = DpdMsgPimCheckChnTxInfo(pdata);
    CHECK_RETVAL(DpdMsgPimCheckChnTxInfo, retVal);

    retVal = DpdMsgPimCheckChnRxInfo(pdata);
    CHECK_RETVAL(DpdMsgPimCheckChnRxInfo, retVal);

    return retVal;
}

/**************************************************************************
  函数名 称： DpdMsgGetOnlinePim2Val
  功能 描述： 0xCOOF消息--查询PIM检测的PIM值
  输入参数 ：
  输出参数 ： pimData-PIM值
  返回值：       BSP_OK: 成功
                BSP_ERROR: 失败
其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 *
 ***********************************************************************/
UINT32 DpdMsgGetOnlinePim2Val(UINT32 chan, T_DpdMsgGetOnlinePim2ValAck *pimData)
{
    UINT32  retVal = BSP_OK;
    UINT16  msgLen = sizeof(T_DpdMsgGetOnlinePim2Val);
    UINT32  typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16  msgType = DPD_MSG_PIMCONFIG_RXCARRY_CALRESULT;
    UINT32  carr = 0;
    THpiApiPDU   *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(pimData);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n",__FUNCTION__, typeId, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    pimData->result = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.result);
    pimData->chkCarrNum = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.chkCarrNum);
    for (carr = 0; carr < pimData->chkCarrNum; carr++)
    {
        pimData->carrPara[carr].carrNo          = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].carrNo);
        pimData->carrPara[carr].radioMode       = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].radioMode);
        pimData->carrPara[carr].rxCarrFreq      = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].rxCarrFreq);
        pimData->carrPara[carr].rxCarrBw        = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].rxCarrBw);
        pimData->carrPara[carr].singleVal       = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].singleVal);
        pimData->carrPara[carr].singleNoiseVal  = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].singleNoiseVal);
        pimData->carrPara[carr].mutiVal         = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].mutiVal);
        pimData->carrPara[carr].mutiNoiseVal    = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].mutiNoiseVal);
        pimData->carrPara[carr].checkresult     = DPD_NTOHL(recv->msg.pimOnlinePim2ValAck.carrPara[carr].checkresult);
    }

    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendFrDiffInfo(*)
 功能描述： 0x402A消息--DPD输入帧头与空口帧头间偏差量下发
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendFrDiffInfo(UINT32 bspChan, T_DspMsgFrDiffInfo * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SEND_FRDIFF_INFO;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.frDiffInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)bspChan;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.frDiffInfo.frDiff = DPD_HTONL(pdata ->frDiff);
    send->msg.frDiffInfo.tddRamFrOffSet = DPD_HTONL(pdata ->tddRamFrOffSet);
    dbgInfoEx("[%s] Chan[%d] FrDiff[%d] TddRamFrOffSet[%d]\n",__FUNCTION__, bspChan, pdata ->frDiff,
    pdata ->tddRamFrOffSet);
    BspLog(LOG_LEVEL_1,"%s{chan %d FrDiff[%d],TddRamFrOffSet[%d]} \n",__FUNCTION__, bspChan, 
    pdata ->frDiff,pdata ->tddRamFrOffSet);

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s bspChan=%d send msg 0x%04x,error!\n",__FUNCTION__,bspChan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.frDiffInfoAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgRfDlyMes(*)
 功能描述： 0x0024消息--9124 射频线缆时延测量发起
 输入参数： chan-通道号  pData-发起使能  pDataAck--消息回应
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 ***********************************************************************/
UINT32 DpdMsgRfDlyMes(UINT32 chan, T_DspMsgRfDlyMes *pData, T_DspMsgRfDlyMesAck *pDataAck)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_RFMES_START;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pDataAck);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.rfDlyMes);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;
    send->msg.rfDlyMes.applyFlg = DPD_HTONL(pData->applyFlg);
    send->msg.rfDlyMes.type = DPD_HTONL(pData->type);
    MsgPrint(PM_DEBUG,"[%s] chan[%d] applyFlg[%d] type [%d]\n", __FUNCTION__, chan, pData->applyFlg, pData->type);

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s bspChan=%d send msg 0x%04x,error!\n",__FUNCTION__, chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    pDataAck->result  = DPD_NTOHS(recv->msg.rfDlyMesAck.result);
    MsgPrint(PM_DEBUG,"result %d\n", pDataAck->result);
    free(pucApiBuff);

    return retVal;
}


/**********************************************************************
 函数名称： DpdMsgSetTrapK0GainCtrl(*)
 功能描述： 0x0025消息--工装流程下发trapping配置K0增益标志
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSetTrapK0GainCtrl(UINT32 bspChan, T_DspMsgTrapMsgK0GainCtrl * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_TRAPKOGAIN_CTRL;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16 ackdata = 0;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
      retVal |= BIT_SET(0);
      dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
      return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    msgLen = sizeof(send->msg.trapK0GainCtrl);

    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)bspChan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;
    send->msg.trapK0GainCtrl.trapK0GainCtrlFlg = DPD_HTONL(pdata->trapK0GainCtrlFlg);
    MsgPrint(PM_DEBUG,"[%s] Chan[%d] trapK0GainCtrlFlg[%d]\n",__func__, bspChan, pdata->trapK0GainCtrlFlg);

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, bspChan, msgType);
        free(pucApiBuff);
        return retVal;
    }

    ackdata = DPD_NTOHS(recv->msg.rrapK0GainCtrlAck.result);
    MsgResultProc(ackdata);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSetSscLutGenCtrl(*)
 功能描述： 0x0026消息--工装流程下发子端SSC预埋表提取开关
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSetSscLutGenCtrl(UINT32 bspChan, T_DspMsgSscEmbedLutGenSw * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SSCLUT_SW;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16 ackdata = 0;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    msgLen = sizeof(send->msg.sscLutGenSw);

    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)bspChan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;
    send->msg.sscLutGenSw.sscEmbedLutGenSw = DPD_HTONL(pdata->sscEmbedLutGenSw);
    dbgInfoEx("[%s] Chan[%d] sscEmbedLutGenSw[%d]\n",__func__, bspChan, pdata->sscEmbedLutGenSw);

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, bspChan, msgType);
        free(pucApiBuff);
        return retVal;
    }

    ackdata = DPD_NTOHS(recv->msg.sscLutGenSwAck.result);
    MsgResultProc(ackdata);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgRfDlyMes(*)
 功能描述： 0x8025消息--9124 射频线缆时延测量结果查询
 输入参数：
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 ***********************************************************************/
UINT32 DpdMsgRfDlyMesResult(UINT32 chan, T_DspMsgRfDlyMesResultAck *pDataAck)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_RFMES_RESULT;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pDataAck);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    msgLen = sizeof(send->msg.rfDlyMesResult);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;
    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s bspChan=%d send msg 0x%04x,error!\n",__FUNCTION__, chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    pDataAck->iterSta = DPD_NTOHL(recv->msg.rfDlyMesResultAck.iterSta);
    pDataAck->result  = DPD_NTOHL(recv->msg.rfDlyMesResultAck.result);
    pDataAck->dlyVal  = DPD_NTOHL(recv->msg.rfDlyMesResultAck.dlyVal);
    pDataAck->rhoVal = DPD_NTOHL(recv->msg.rfDlyMesResultAck.rhoVal);
    pDataAck->type = DPD_NTOHL(recv->msg.rfDlyMesResultAck.type);
    MsgPrint(PM_DEBUG,"iterSta %d result %d dlyVal %d rhoVal %d type %d\n", pDataAck->iterSta, pDataAck->result, pDataAck->dlyVal, pDataAck->rhoVal, pDataAck->type);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSetCfrGateCfg(*)
 功能描述： 0x002C消息--将下行通道的削峰门限下发给DSP
 输入参数： chan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容
 ***********************************************************************/
UINT32 DpdMsgSetCfrGateCfg(UINT32 chan, T_DspMsgCfrGateCfg *pdata)
{
    UINT32     retVal = BSP_OK;
    UINT32     loop = 0;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_CFR_GATE_CFG;
    UINT16     ackdata = 0;
    THpiApiPDU *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    const UINT32 maxLevel = CFR_STAGE_NUM_MAX;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    msgLen = sizeof(send->msg.cfrGateCfg);
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)chan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    send->msg.cfrGateCfg.stageNum = DPD_HTONL(pdata->stageNum);
    MsgPrint(PM_DEBUG,"[%s]Chan[%d],stageNum[%d]\n",__FUNCTION__, chan, pdata->stageNum);

    pdata->stageNum = (pdata->stageNum > maxLevel) ? maxLevel : pdata->stageNum;
    for(loop = 0; loop < pdata->stageNum; loop++)
    {
        send->msg.cfrGateCfg.cfrGate[loop] = DPD_HTONL(pdata->cfrGate[loop]);
        MsgPrint(PM_DEBUG,"[%s]Chan[%d],cfrGate[%d] = %d\n",__FUNCTION__, chan, loop, pdata->cfrGate[loop]);
    }

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, chan, msgType);
        free(pucApiBuff);
        return retVal;
    }

    ackdata = DPD_NTOHS(recv->msg.recvComMsg.result);
    MsgResultProc(ackdata);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSetSscVoltGrdCfg(*)
 功能描述： 0x402d消息--SSC电压档位信息下发(分通道下发),用于子端预埋表选择
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSetSscVoltGrdCfg(UINT32 bspChan, T_DspMsgSscVoltGrdCfg *pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SSC_VOLT_CFG;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16 ackdata = 0;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    msgLen = sizeof(send->msg.sscVoltVCfg);
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)bspChan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;
    send->msg.sscVoltVCfg.sscVoltGrd = DPD_HTONL(pdata->sscVoltGrd);
    MsgPrint(PM_DEBUG,"[%s] Chan[%d] uiSscVoltGrd[%d]\n",__func__, bspChan, pdata->sscVoltGrd);

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, bspChan, msgType);
        free(pucApiBuff);
        return retVal;
    }

    ackdata = DPD_NTOHS(recv->msg.sscVoltVCfgAck.result);
    MsgResultProc(ackdata);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgGetSscTrapSta(*)
 功能描述： 0x8026消息--SSC子端预埋表提取中trapping迭代成功状态上报
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgGetSscTrapSta(UINT32 bspChan, T_DspMsgSscLutGenTrapStaAck *pData)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SSC_TRAPSTA_GET;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pData);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    msgLen = sizeof(send->msg.lutGenTrapSta);
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)bspChan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, bspChan, msgType);
        free(pucApiBuff);
        return retVal;
    }
    pData->calcResult = DPD_NTOHL(recv->msg.lutGenTrapStaAck.calcResult);
    pData->trapResult = DPD_NTOHL(recv->msg.lutGenTrapStaAck.trapResult);
    pData->lutCnt = DPD_NTOHL(recv->msg.lutGenTrapStaAck.lutCnt);
    MsgPrint(PM_DEBUG, "calcResult %d trapResult %d lutCnt %d\n", pData->calcResult, pData->trapResult, pData->lutCnt);
    MsgResultProc(retVal);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgGetSscGenStaUpLoad(*)
 功能描述： 0x8027消息--SSC子端预埋表提取成功状态上报 及数据上传
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgGetSscGenStaUpLoad(UINT32 bspChan, T_DspMsgSscLutGenStaUpLoad *pData, T_DspMsgSscLutGenStaUpLoadAck *pDataAck)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SSC_GENSTA_GET;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    msgLen = sizeof(send->msg.lutGenStaUpLoad);

    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)bspChan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;
    send->msg.lutGenStaUpLoad.pwdGrd = DPD_HTONL(pData->pwdGrd);

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, bspChan, msgType);
        free(pucApiBuff);
        return retVal;
    }
    pDataAck->result = DPD_NTOHL(recv->msg.lutGenStaUpLoadAck.result);
    pDataAck->pwdGrd = DPD_NTOHL(recv->msg.lutGenStaUpLoadAck.pwdGrd);
    pDataAck->proSta = DPD_NTOHL(recv->msg.lutGenStaUpLoadAck.proSta);
    pDataAck->lutLen = DPD_NTOHL(recv->msg.lutGenStaUpLoadAck.lutLen);
    memcpy_s(pDataAck->lutBuf, sizeof(pDataAck->lutBuf), recv->msg.lutGenStaUpLoadAck.lutBuf, sizeof(recv->msg.lutGenStaUpLoadAck.lutBuf));
    MsgPrint(PM_DEBUG, "%s result=%d pwdGrd %d proSta %d lutLen %d!\n", __FUNCTION__, pDataAck->result,  pDataAck->pwdGrd,  pDataAck->proSta, pDataAck->lutLen);
    MsgResultProc(pDataAck->result);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSscLutHashVer(*)
 功能描述： 0x8028消息--SSC子端预埋表hashver
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSscLutHashVer(UINT32 bspChan, T_DspMsgSscLutHashVerAck *pDataAck)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SSCLUT_HASHVER;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16 ackdata = 0;

    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    msgLen = sizeof(send->msg.sscLutHashVer);
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)bspChan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, bspChan, msgType);
        free(pucApiBuff);
        return retVal;
    }
    pDataAck->result = DPD_NTOHL(recv->msg.sscLutHashVerAck.result);
    memcpy_s(pDataAck->lutHashVer,sizeof(pDataAck->lutHashVer), recv->msg.sscLutHashVerAck.lutHashVer, sizeof(recv->msg.sscLutHashVerAck.lutHashVer));
    ackdata = DPD_NTOHS(recv->msg.sscLutHashVerAck.result);
    MsgPrint(PM_DEBUG, "%s result=%d lutHashVer %s !\n", __FUNCTION__, pDataAck->result, pDataAck->lutHashVer);
    MsgResultProc(ackdata);
    free(pucApiBuff);

    return retVal;
}


/**********************************************************************
 函数名称： DpdMsgGetDownLutCnt(*)
 功能描述： 0x8029消息--下表张数获取
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值 ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期   版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgGetDownLutCnt(UINT32 bspChan, T_DspMsgDownLutCntAck *pDataAck)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_DOWNLUT_CNT;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    msgLen = sizeof(send->msg.downLutCnt);
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.chan     = (UINT8)bspChan;
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, bspChan, msgType);
        free(pucApiBuff);
        return retVal;
    }
    pDataAck->result = DPD_NTOHL(recv->msg.downLutCntAck.result);
    pDataAck->succCnt = DPD_NTOHL(recv->msg.downLutCntAck.succCnt);
    MsgPrint(PM_DEBUG, "%s result=%d succCnt %d !\n", __FUNCTION__, pDataAck->result, pDataAck->succCnt);
    MsgResultProc(pDataAck->result);
    free(pucApiBuff);

    return retVal;
}


/**********************************************************************
 函数名称： DpdMsgPowCalChnSw(*)
 功能描述： 0x0029消息--9124 子母端机型功率检测开关
 输入参数： chan-通道号  pData-发起使能  pDataAck--消息回应
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 ***********************************************************************/
UINT32 DpdMsgPowCalChnSw(UINT32 chan, T_DspMsgPowCalChnSw *pData, T_DspMsgPowCalChnSwAck *pDataAck)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_POWERCTRL_SW;
    THpiApiPDU  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pDataAck);

    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    msgLen = sizeof(send->msg.powCalChnSw);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;
    send->msg.powCalChnSw.powCalChnSw = DPD_HTONL(pData->powCalChnSw);

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s bspChan=%d send msg 0x%04x,error!\n",__FUNCTION__, chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    pDataAck->result  = DPD_NTOHS(recv->msg.powCalChnSwAck.result);
    MsgPrint(PM_INFO,"result %d\n", pDataAck->result);
    free(pucApiBuff);

    return retVal;
}

/* Started by AICoder, pid:fca4ab15fe7f48c69969f7764fb30836 */
/**************************************************************************
 函数名 称： DspMsgGetAacPermitFlgTx
 功能 描述： 0x0200消息
 输入参数 ： aacPermitFlgMsgTx - AAC发起的DSP侧前置条件满足标志上报消息DSP发送消息体
 输出参数 ： 无
 返回值      BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DspMsgGetAacPermitFlgTx(T_AacPermitFlgMsgTx *aacPermitFlgMsgTx)
{
   UINT32     retVal = BSP_OK;
   UINT16     msgLen = sizeof(T_AacPermitFlgMsgTx);
   UINT8    *pucApiBuff = NULL;
   UINT32    reserveIndex = 0;
   THpiApiPDU   *send = NULL;
   THpiApiPDU   *recv = NULL;

   INPUT_POINTER_CHECK(aacPermitFlgMsgTx);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];



   send->head.msgType = DPD_HTONS(DPD_MSG_AACPERMITFLG_TX);
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(msgLen);

   send->head.srcId    = (UINT8)GetUdpSrcId();
   send->head.dstId    = (UINT8)GetUdpDstId();
   send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
   send->head.recvEn    = (UINT8)MSG_REQ;
   send->lenAPDU      = sizeof(send->head) + msgLen;

   retVal = SendHpiMsg(0, send, recv);
   if (retVal != BSP_OK)
   {
       MsgPrint(PM_ERROR,"%s send msg error!\n",__FUNCTION__);
       free(pucApiBuff);
       return retVal;
   }

   aacPermitFlgMsgTx->uiAacPermitFlg = DPD_NTOHL(recv->msg.aacPermitFlgMsgTx.uiAacPermitFlg);
   MsgPrint(PM_DEBUG,"aacPermitFlgMsgTx->uiAacPermitFlg %d\n", aacPermitFlgMsgTx->uiAacPermitFlg);

   for(reserveIndex = 0; reserveIndex < (sizeof(aacPermitFlgMsgTx->uiReserve)/sizeof(aacPermitFlgMsgTx->uiReserve[0])); reserveIndex++)
   {
        aacPermitFlgMsgTx->uiReserve[reserveIndex] = DPD_NTOHL(recv->msg.aacPermitFlgMsgTx.uiReserve[reserveIndex]);
        MsgPrint(PM_DEBUG,"aacPermitFlgMsgTx->uiReserve[%d] = %d\n", reserveIndex, aacPermitFlgMsgTx->uiReserve[reserveIndex]);
   }
        
   free(pucApiBuff);
   return retVal;
}
/* Ended by AICoder, pid:fca4ab15fe7f48c69969f7764fb30836 */

/* Started by AICoder, pid:m4cea6897fj1fef14e460bd482947752a361c337 */
/* Started by AICoder */    /* AI中台代码-星云 start */
/**************************************************************************
 函数名 称： DpdMsgVswrStart_RfBridge(*)
 功能 描述： 0x1803消息--电桥机型开启VSWR
 输入参数 ：
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgVswrStart_RfBridge(T_DpdMsgRfBridgeVswrCtrl *pdata)
{
    UINT32   retVal = BSP_OK;
    UINT32   swFlag = 0x5A5A;
    UINT32   brgIdx = 0;
    UINT32   msgLen = sizeof(T_DpdMsgRfBridgeVswrCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_RFBRIDGE_STARTVSWR;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    if(pdata->calSoftBrgNum > VSWR_MAX_RF_BRIDGE_NUM)
    {
        dbgErr("calSoftBrgNum = %d,is over!\n", pdata->calSoftBrgNum);
        return BSP_ERROR;
    }
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) +sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU)  + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId();
    send->head.dstId   = GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = MSG_REQ;
    /* Started by AICoder, pid:h98c9we924q6fc4147ce08b800c324149016598a */
    send->msg.rfBridgeVswrCtrl.rfBrgVswrSmpStart = DPD_HTONL(swFlag);
    send->msg.rfBridgeVswrCtrl.koSmpStartFrameId = DPD_HTONL(pdata->koSmpStartFrameId);
    send->msg.rfBridgeVswrCtrl.calSoftBrgNum = DPD_HTONL(pdata->calSoftBrgNum);
    send->msg.rfBridgeVswrCtrl.msgVerify  = DPD_HTONL(pdata->msgVerify);
    dbgInfoEx("%s{calSoftBrgNum %d koSmpStartFrameId %d msgVerify %d swFlag %#x} \n",
           __FUNCTION__, pdata->calSoftBrgNum, pdata->koSmpStartFrameId, pdata->msgVerify, swFlag);
    for(brgIdx = 0; brgIdx < pdata->calSoftBrgNum; brgIdx++)
    {
        send->msg.rfBridgeVswrCtrl.calRfBrgIdx[brgIdx] = DPD_HTONL(pdata->calRfBrgIdx[brgIdx]);
        dbgInfoEx("calRfBrgIdx = %d\n", pdata->calRfBrgIdx[brgIdx]);
    }
    /* Ended by AICoder, pid:h98c9we924q6fc4147ce08b800c324149016598a */
    send->lenAPDU                   = sizeof(send->head) +  msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
     {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.rfBridgeVswrCtrlAck.result);
    free(pucApiBuff);
    MsgResultProc(retVal);
    return retVal;
}


/**************************************************************************
 函数名 称： DpdMsgVswrStop_RfBridge(*)
 功能 描述： 0x1800消息--电桥机型停止VSWR
 输入参数 ： msgVerify        - 消息校验标志，类似流水号，高层生成透传给DSP即可
           frameNo            帧号
           rfBridgeIdx        电桥索引
           ctrl   -  控制字：0x5A5A，使能；0x2D2D，禁用
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgVswrStop_RfBridge(T_DpdMsgRfBridgeVswrCtrl *pdata)
{
    UINT32   retVal = BSP_OK;
    UINT32   swFlag = (UINT16)0x2D2D;
    UINT32   brgIdx = 0;
    UINT32   msgLen = sizeof(T_DpdMsgRfBridgeVswrCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_RFBRIDGE_STARTVSWR;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    if(pdata->calSoftBrgNum > VSWR_MAX_RF_BRIDGE_NUM)
    {
        dbgErr("calSoftBrgNum = %d,is over!\n", pdata->calSoftBrgNum);
        return BSP_ERROR;
    }
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) +sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU)  + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId();
    send->head.dstId   = GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = MSG_REQ;
    send->msg.rfBridgeVswrCtrl.rfBrgVswrSmpStart = DPD_HTONL(swFlag);
    /* Started by AICoder, pid:0d1b17b2bbo536d148e108b7f030901e990638eb */
    send->msg.rfBridgeVswrCtrl.calSoftBrgNum = DPD_HTONL(pdata->calSoftBrgNum);
    send->msg.rfBridgeVswrCtrl.koSmpStartFrameId    = DPD_HTONL(pdata->koSmpStartFrameId);
    send->msg.rfBridgeVswrCtrl.msgVerify  = DPD_HTONL(pdata->msgVerify);
    for(brgIdx = 0; brgIdx < pdata->calSoftBrgNum; brgIdx++)
    {
        send->msg.rfBridgeVswrCtrl.calRfBrgIdx[brgIdx] = DPD_HTONL(pdata->calRfBrgIdx[brgIdx]);
        dbgInfoEx("calRfBrgIdx = %d\n", pdata->calRfBrgIdx[brgIdx]);
    }
    send->lenAPDU                   = sizeof(send->head) +  msgLen;
    dbgInfoEx("%s{calSoftBrgNum %d koSmpStartFrameId %d msgVerify %d swFlag %#x} \n",
           __FUNCTION__, pdata->calSoftBrgNum, pdata->koSmpStartFrameId, pdata->msgVerify, swFlag);
    /* Ended by AICoder, pid:0d1b17b2bbo536d148e108b7f030901e990638eb */

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
     {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.rfBridgeVswrCtrlAck.result);
    free(pucApiBuff);
    MsgResultProc(retVal);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgGetVswrFinishSta_RfBridge(*)
 功能 描述： 0x1807消息--电桥机型Vswr采数完成状态查询消息
 输入参数 ： rfBridgeIdx        电桥索引

 输出参数 ： pDataAck
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetVswrFinishSta_RfBridge(UINT32 chan, T_DpdMsgRfBridgeVswrFinishStaAck *pDataAck)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_RFBRIDGE_VSWR_FINISH_STA;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    THpiApiPDU      *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    msgLen = sizeof(T_DpdMsgRfBridgeVswrFinishSta);

    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.chan     = (UINT8)chan;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)typeId;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR, "%s bspChan=%d send msg 0x%04x,error!\n", __FUNCTION__, chan, msgType);
        free(pucApiBuff);
        return retVal;
    }
    pDataAck->finishSta = DPD_NTOHL(recv->msg.rfBridgeVswrFinishStaAck.finishSta);
    pDataAck->smpResult = DPD_NTOHL(recv->msg.rfBridgeVswrFinishStaAck.smpResult);
    pDataAck->msgVerify = DPD_NTOHL(recv->msg.rfBridgeVswrFinishStaAck.msgVerify);
    
    dbgInfoEx( "%s finishSta=%d smpResult=%d msgVerify=%d !\n", __FUNCTION__, pDataAck->finishSta, pDataAck->smpResult, pDataAck->msgVerify);
    free(pucApiBuff);

    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgStartVswrCalc_RfBridge(*)
 功能 描述： 0x1809消息--电桥机型通知dsp数据传输完毕启动驻波计算消息
 输入参数 ： 无
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgStartVswrCalc_RfBridge(UINT32 rfBridgeIdx,UINT32 vswrType)
{
    UINT32   retVal = BSP_OK;
    UINT32   swFlag = (UINT16)0x5A5A;     /* 开启spa计算 0x5a5a：开始计算 */
    UINT32   msgLen = sizeof(T_DpdMsgRfBridgeStartVswrCalc);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_RFBRIDGE_START_VSWR_CALC;
    UINT8    *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) +sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU)  + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId();
    send->head.dstId   = GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = MSG_REQ;
    send->msg.rfBridgeStartVswrCalc.rfBridgeIdx  = DPD_HTONL(rfBridgeIdx);
    send->msg.rfBridgeStartVswrCalc.vswrType = DPD_HTONL(vswrType);
    send->msg.rfBridgeStartVswrCalc.spaCalcStart    = DPD_HTONL(swFlag);
    send->lenAPDU                   = sizeof(send->head) +  msgLen;
    dbgInfoEx("%s{rfBridgeIdx %d vswrType 0x%x swFlag %#x} \n",
           __FUNCTION__,rfBridgeIdx,vswrType,swFlag);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
     {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.rfBridgeStartVswrCalcAck.result);
    free(pucApiBuff);
    MsgResultProc(retVal);
    return retVal;
}

/**************************************************************************
 函数名 称： DpdMsgGetRevVal_RfBridge
 功能 描述： 0x1808消息--电桥机型获取Rev值消息
 输入参数 ： 

 输出参数 ： pDataAck
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
/* Started by AICoder, pid:774fbm5e53e4810144a60b2140f23163d4a1f0fd */
UINT32 DpdMsgGetRevVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeRevCalcStaAck *pDataAck)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT16 msgLen = sizeof(T_DpdMsgRfBridgeRevCalcSta);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_RFBRIDGE_REV_CALC_STA;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
        __FUNCTION__, typeId, msgType, retVal);
    }
    pDataAck->calcFinish = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.calcFinish);
    pDataAck->vswrType = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.vswrType);
    pDataAck->chanIdx = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.chanIdx);
    pDataAck->calcResult = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.calcResult);
    pDataAck->spaNum = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.spaNum);
    dbgInfoEx("%s{calcFinish 0x%x vswrType 0x%x chanIdx %d calcResult %d spaNum %d} \n",
           __FUNCTION__,pDataAck->calcFinish,pDataAck->vswrType,pDataAck->chanIdx,pDataAck->calcResult,pDataAck->spaNum);
    if((pDataAck->spaNum > VSWR_SPA_NUM_MAX) || (pDataAck->calcFinish == RF_BRIDGE_SAMP_UNFINISH) || (pDataAck->calcResult != RF_BRIDGE_SAMP_SUCCESS)) 
    {
        free(pucApiBuff);
        return BSP_ERROR;
    }
    for(loop = 0; loop <  pDataAck->spaNum; loop++)
    {
        pDataAck->chRevDiffCfg[loop].rfFreq = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.chRevDiffCfg[loop].rfFreq);
        pDataAck->chRevDiffCfg[loop].revCompensate_I = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.chRevDiffCfg[loop].revCompensate_I);
        pDataAck->chRevDiffCfg[loop].revCompensate_Q = DPD_NTOHL(recv->msg.rfBridgeRevCalcStaAck.chRevDiffCfg[loop].revCompensate_Q);
    }
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:774fbm5e53e4810144a60b2140f23163d4a1f0fd */
/**************************************************************************
 函数名 称： DpdMsgGetSpaVal_RfBridge
 功能 描述： 0x1804消息--电桥机型获取Spa值消息
 输入参数 ：

 输出参数 ： pDataAck
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
 * 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetSpaVal_RfBridge(UINT32 chan, T_DpdMsgRfBridgeSpaCalcStaAck *pDataAck)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT16 msgLen = sizeof(T_DpdMsgRfBridgeSpaCalcSta);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_RFBRIDGE_SPA_CALC_STA;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
        __FUNCTION__, typeId, msgType, retVal);
    }
    pDataAck->calcFinish = DPD_NTOHL(recv->msg.rfBridgeSpaCalcStaAck.calcFinish);
    pDataAck->chanIdx = DPD_NTOHL(recv->msg.rfBridgeSpaCalcStaAck.chanIdx);
    pDataAck->calcResult = DPD_NTOHL(recv->msg.rfBridgeSpaCalcStaAck.calcResult);
    pDataAck->spaNum = DPD_NTOHL(recv->msg.rfBridgeSpaCalcStaAck.spaNum);
    dbgInfoEx("%s{calcFinish 0x%x chanIdx %d calcResult %d spaNum %d} \n",
           __FUNCTION__,pDataAck->calcFinish,pDataAck->chanIdx,pDataAck->calcResult,pDataAck->spaNum);
    if(pDataAck->spaNum > VSWR_SPA_NUM_MAX)
    {
        free(pucApiBuff);
        return BSP_ERROR;
    }
    for(loop = 0; loop <  pDataAck->spaNum; loop++)
    {
        pDataAck->spaData[loop].spaI = DPD_NTOHL(recv->msg.rfBridgeSpaCalcStaAck.spaData[loop].spaI);
        pDataAck->spaData[loop].spaQ = DPD_NTOHL(recv->msg.rfBridgeSpaCalcStaAck.spaData[loop].spaQ);
        pDataAck->spaData[loop].nco = DPD_NTOHL(recv->msg.rfBridgeSpaCalcStaAck.spaData[loop].nco);
    }
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendRfBridgeParam(*)
 功能描述：0x002F消息--发送电桥离线文件信息
 输入参数： difChan - 通道号
            freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendRfBridgeParam( T_DpdMsgRfBridgeOfflinePara * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     resLen = 0;
    UINT16     msgType = DPD_MSG_RFBRIDGE_OFF_LINE_PARA;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32 port = 0;

    INPUT_POINTER_CHECK(pdata);
    if((pdata->freqNum > MAX_RF_BRIDGE_FREQ_NUM) || (pdata->portNum > VSWR_MAX_RF_BRIDGE_PORT_NUM))
    {
        dbgErr("freqNum = %d, portNum = %d, is over!\n", pdata->freqNum, pdata->portNum);
        return BSP_ERROR;
    }
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.rfBridgeOfflinePara);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId    = GetUdpSrcId() & 0xff;
    send->head.dstId    = GetUdpDstId() & 0xff;
    send->head.typeId    = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;
    /* Started by AICoder, pid:f03e9jd9045ecb1145950a6dd0c3c4168b3501c8 */
    send->msg.rfBridgeOfflinePara.chnIdx     = DPD_HTONL(pdata->chnIdx);
    send->msg.rfBridgeOfflinePara.chipIdx = DPD_HTONL(pdata->chipIdx);
    send->msg.rfBridgeOfflinePara.rfFreqStart     = DPD_HTONL(pdata->rfFreqStart);
    send->msg.rfBridgeOfflinePara.freqStep        = DPD_HTONL(pdata->freqStep);
    send->msg.rfBridgeOfflinePara.freqNum         = DPD_HTONL(pdata->freqNum);
    send->msg.rfBridgeOfflinePara.portNum         = DPD_HTONL(pdata->portNum);
    dbgInfoEx("chnIdx = %d, chipIdx = 0x%x startFreq = %d, freqStep =%d, freqNum =%d, portNum =%d \n",
               pdata->chnIdx,pdata->chipIdx,pdata->rfFreqStart,pdata->freqStep,pdata->freqNum,pdata->portNum);
    for(resLen = 0; resLen < pdata->freqNum; resLen++)
    {
        for(port = 0; port < pdata->portNum; port++)
        {
            send->msg.rfBridgeOfflinePara.tFreqBrgCfg[resLen].brgPara[port] = DPD_HTONL(pdata->tFreqBrgCfg[resLen].brgPara[port]);
        }
    }
    /* Ended by AICoder, pid:f03e9jd9045ecb1145950a6dd0c3c4168b3501c8 */

    retVal = SendHpiMsg((UINT16)(GET_DSP_ID(0)), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s send msg 0x%04x,error!\n",__FUNCTION__,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.rfBridgeOfflineParaAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);
    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgSendRfBridgeRevParam(*)
 功能描述：0x002E消息--发送电桥离线文件信息
 输入参数： difChan - 通道号
            freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
/* Started by AICoder, pid:cf49061796a1083143840a0a20526668e8955f2a */
UINT32 DpdMsgSendRfBridgeRevParam( T_DpdMsgRfBridgeOfflineRevPara * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     resLen = 0;
    UINT16     msgType = DPD_MSG_RFBRIDGE_OFF_LINE_REV_PARA;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.rfBridgeOfflineRevPara);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId    = GetUdpSrcId() & 0xff;
    send->head.dstId    = GetUdpDstId() & 0xff;
    send->head.typeId    = HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.rfBridgeOfflineRevPara.rfBridgeIdx     = DPD_HTONL(pdata->rfBridgeIdx);
    send->msg.rfBridgeOfflineRevPara.vswrType = DPD_HTONL(pdata->vswrType);
    send->msg.rfBridgeOfflineRevPara.dflStartFreq     = DPD_HTONL(pdata->dflStartFreq);
    send->msg.rfBridgeOfflineRevPara.dflEndFreq     = DPD_HTONL(pdata->dflEndFreq);
    send->msg.rfBridgeOfflineRevPara.freqStep      = DPD_HTONL(pdata->freqStep);
    send->msg.rfBridgeOfflineRevPara.dflFreqNum       = DPD_HTONL(pdata->dflFreqNum);
    dbgInfoEx("rfBridgeIdx = %d, vswrType = 0x%x startFreq = %d,endFreq = %d, freqStep =%d, freqNum =%d \n",
               pdata->rfBridgeIdx,pdata->vswrType,pdata->dflStartFreq,pdata->dflEndFreq,pdata->freqStep,pdata->dflFreqNum);
    for(resLen = 0; resLen < pdata->dflFreqNum; resLen++)
    {
        send->msg.rfBridgeOfflineRevPara.bridgeRevCfg[resLen].rfFreq = DPD_HTONL(pdata->bridgeRevCfg[resLen].rfFreq);
        send->msg.rfBridgeOfflineRevPara.bridgeRevCfg[resLen].revCompensate_I = DPD_HTONL(pdata->bridgeRevCfg[resLen].revCompensate_I);
        send->msg.rfBridgeOfflineRevPara.bridgeRevCfg[resLen].revCompensate_Q = DPD_HTONL(pdata->bridgeRevCfg[resLen].revCompensate_Q);
        dbgInfoEx("Freq = %d,revCompensate_I = %d,revCompensate_Q = %d\n",
        pdata->bridgeRevCfg[resLen].rfFreq,pdata->bridgeRevCfg[resLen].revCompensate_I,pdata->bridgeRevCfg[resLen].revCompensate_Q);
    }

    retVal = SendHpiMsg((UINT16)(GET_DSP_ID(0)), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s send msg 0x%04x,error!\n",__FUNCTION__,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.rfBridgeOfflineRevParaAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);
    return retVal;
}
/* Ended by AICoder, pid:cf49061796a1083143840a0a20526668e8955f2a */

/**********************************************************************
 函数名称： DpdMsgSendRfBridgeMapInfo(*)
 功能描述：0x002D消息--电桥连接与通道连接关系下发消息
 输入参数： chan - 通道号
            freqNo  -
             pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendRfBridgeMapInfo( T_DpdMsgRfBridgeAllRfBridgeInfo * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     resLen = 0;
    UINT32     icIndex= 0;
    UINT16     msgType = DPD_MSG_RFBRIDGE_MAP_INFO;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.rfBridgeAllRfBridgeInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId    = GetUdpSrcId() & 0xff;
    send->head.dstId    = GetUdpDstId() & 0xff;
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.rfBridgeAllRfBridgeInfo.rfBridgeNum     = DPD_HTONL(pdata->rfBridgeNum);
    dbgInfoEx("rfBridgeNum = %d \n",pdata->rfBridgeNum);
    for(resLen = 0; resLen < pdata->rfBridgeNum; resLen++)
    {
        send->msg.rfBridgeAllRfBridgeInfo.rfBridgeInfo[resLen].rfBridgeIdx = DPD_HTONL(pdata->rfBridgeInfo[resLen].rfBridgeIdx);
        send->msg.rfBridgeAllRfBridgeInfo.rfBridgeInfo[resLen].rfBridgeInPort = DPD_HTONL(pdata->rfBridgeInfo[resLen].rfBridgeInPort);
        send->msg.rfBridgeAllRfBridgeInfo.rfBridgeInfo[resLen].rfBridgeOutPort = DPD_HTONL(pdata->rfBridgeInfo[resLen].rfBridgeOutPort);
        dbgInfoEx("rfBridgeIdx = %d,rfBridgeInPort = %d,rfBridgeOutPort = %d \n",pdata->rfBridgeInfo[resLen].rfBridgeIdx,
        pdata->rfBridgeInfo[resLen].rfBridgeInPort,pdata->rfBridgeInfo[resLen].rfBridgeOutPort);
    
        for(icIndex = 0; icIndex < pdata->rfBridgeInfo[resLen].rfBridgeInPort; icIndex++)
        {
            send->msg.rfBridgeAllRfBridgeInfo.rfBridgeInfo[resLen].bridgePortIcIdx[icIndex] = DPD_HTONL(pdata->rfBridgeInfo[resLen].bridgePortIcIdx[icIndex]);
            send->msg.rfBridgeAllRfBridgeInfo.rfBridgeInfo[resLen].bridgePortChIdx[icIndex] = DPD_HTONL(pdata->rfBridgeInfo[resLen].bridgePortChIdx[icIndex]);
            dbgInfoEx("bridgePortIcIdx[%d] = %d,bridgePortChIdx[%d] = %d \n",icIndex,pdata->rfBridgeInfo[resLen].bridgePortIcIdx[icIndex],icIndex,pdata->rfBridgeInfo[resLen].bridgePortChIdx[icIndex]);
        }
    }

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv ))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.sendFwdParamAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);
    
    return retVal;
}
/* Ended by AICoder, pid:m4cea6897fj1fef14e460bd482947752a361c337 */

/* Started by AICoder, pid:t6a1c8d6210734314bc009b8b0ee2147c820fab8 */
/**************************************************************************
 函数名 称： DpdMsgDmimoSetFlag
 功能 描述： 0x0201消息
 输入参数 ： pdata - 控制DMIMO配置信息清零的消息
 输出参数 ： 无
 返回值      BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 DpdMsgDmimoSetFlag(T_DmmCfgClrMsg *pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(T_DmmCfgClrMsg);;
    UINT16     msgType = DPD_MSG_DMM_CFGCLR;
    THpiApiPDU *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    send->msg.dmmCfgClrMsg.uiChn = DPD_HTONL(pdata->uiChn);
    send->msg.dmmCfgClrMsg.uiDmmCfgClrFlg = DPD_HTONL(pdata->uiDmmCfgClrFlg);

    MsgPrint(PM_INFO,"[%s]Chan[%d],uiDmmCfgClrFlg[%d]\n",__FUNCTION__, pdata->uiChn, pdata->uiDmmCfgClrFlg);

    retVal = SendHpiMsg(0, send, recv);
    if (retVal != BSP_OK)
    {
       MsgPrint(PM_ERROR,"%s send msg error!\n",__FUNCTION__);
       free(pucApiBuff);
       return retVal;
    }

    free(pucApiBuff);

    return retVal;
}
/* Started by AICoder, pid:t6a1c8d6210734314bc009b8b0ee2147c820fab8 */

/* Started by AICoder, pid:pe0aet1ae15b46314c9d0800130a1e476f11cc3d */
/**********************************************************************
 * 函数名称： DpdMsgSendInstruSw
 * 功能描述： 0x600消息--在线仪表功能开关
 * 输入参数：
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 无
 * 修改日期        版本号     修改人           修改内容
 * ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendInstruSw(UINT32 chan, T_DpdMsgInstruSwi *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_INSTRUSW;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    (void)memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.InstruSwi);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->head.chan    = (UINT8)chan;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.InstruSwi.ulFuncSwi = DPD_HTONL(pdata->ulFuncSwi);
    dbgInfoEx("%s ulFuncSwi = %d \n", __func__, pdata->ulFuncSwi);
    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8 *)send, (UINT8 *)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId '%d' MsgType '0x%04X' MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.InstruSwiAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 * 函数名称： DpdMsgSendInstruAcpSw
 * 功能描述： 0x601消息--在线ACP检测发起
 * 输入参数：
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 无
 * 修改日期        版本号     修改人           修改内容
 * ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendInstruAcpSw(UINT32 chan, T_DpdMsgInstruAcpSwi *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_INSTRUACPSW;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    (void)memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.InstruAcpSwi);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->head.chan    = (UINT8)chan;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    (void)memcpy_s(&send->msg.InstruAcpSwi, sizeof(T_DpdMsgInstruAcpSwi), pdata, sizeof(T_DpdMsgInstruAcpSwi));

    dbgInfoEx("%s ulFuncSwi = %d ulChn %d ulAcprTestBand %d ulAcprOffsetBand %d\n",
              __func__, pdata->ulFuncSwi, pdata->ulChn, pdata->ulAcprTestBand, pdata->ulAcprOffsetBand);
    dbgInfoEx("ulAcprSecondOffestBand = %d ulAcprDlLoFreq %d ulAcprCenterFreq %d ulAcprSpurDb %d\n",
              pdata->ulAcprSecondOffestBand, pdata->ulAcprDlLoFreq, pdata->ulAcprCenterFreq, pdata->ulAcprSpurDb);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8 *)send, (UINT8 *)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId '%d' MsgType '0x%04X' MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.InstruAcpSwiAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 * 函数名称： DpdMsgRecvInstruAcpSta
 * 功能描述： 0x602消息--在线ACP结果上报
 * 输入参数：
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 无
 * 修改日期        版本号     修改人           修改内容
 * ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgRecvInstruAcpSta(UINT32 chan, T_DpdMsgInstruAcpStaAck *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_INSTRUACPSTA;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    (void)memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.InstruAcpSta);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->head.chan    = (UINT8)chan;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8 *)send, (UINT8 *)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId '%d' MsgType '0x%04X' MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    (void)memcpy_s(pdata, sizeof(T_DpdMsgInstruAcpStaAck), &recv->msg.InstruAcpStaAck, sizeof(T_DpdMsgInstruAcpStaAck));

    dbgInfoEx("%s ulCalcSta %d iResult %d ulChn %d aiAcp %d %d %d %d\n",
              __func__, pdata->ulCalcSta, pdata->iResult, pdata->ulChn,
              pdata->aiAcp[0], pdata->aiAcp[1], pdata->aiAcp[2], pdata->aiAcp[3]);

    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 * 函数名称： DpdMsgSendInstruEvmSw
 * 功能描述： 0x603消息--在线EVM检测发起
 * 输入参数：
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 无
 * 修改日期        版本号     修改人           修改内容
 * ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendInstruEvmSw(UINT32 chan, T_DpdMsgInstruEvmSwi *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_INSTRUEVMSW;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    (void)memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.InstruEvmSwi);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->head.chan    = (UINT8)chan;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    (void)memcpy_s(&send->msg.InstruEvmSwi, sizeof(T_DpdMsgInstruEvmSwi), pdata, sizeof(T_DpdMsgInstruEvmSwi));

    dbgInfoEx("%s ulFuncSwi = %d ulChn %d ulEvmCalBand %d ulEvmScsType %d\n",
              __func__, pdata->ulFuncSwi, pdata->ulChn, pdata->ulEvmCalBand, pdata->ulEvmScsType);
    dbgInfoEx("ulEvmModulType = %d ulEvmMode %d ulCenterFreq %d ulNid %d\n",
              pdata->ulEvmModulType, pdata->ulEvmMode, pdata->ulCenterFreq, pdata->ulNid);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8 *)send, (UINT8 *)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId '%d' MsgType '0x%04X' MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.InstruEvmSwiAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 * 函数名称： DpdMsgRecvInstruEvmSta
 * 功能描述： 0x604消息--在线EVM结果上报
 * 输入参数：
 * 输出参数： 无
 * 返回值  ： BSP_OK: 成功, 其他: 失败
 * 其他说明： 无
 * 修改日期        版本号     修改人           修改内容
 * ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgRecvInstruEvmSta(UINT32 chan, T_DpdMsgInstruEvmStaAck *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_INSTRUEVMSTA;
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    const UINT32 slotNum = 14;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    (void)memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.InstruEvmSta);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->head.chan    = (UINT8)chan;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8 *)send, (UINT8 *)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId '%d' MsgType '0x%04X' MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    (void)memcpy_s(pdata, sizeof(T_DpdMsgInstruEvmStaAck), &recv->msg.InstruEvmStaAck, sizeof(T_DpdMsgInstruEvmStaAck));

    dbgInfoEx("%s ulCalcSta %d iResult %d ulChn %d ulCarrId %d ulSlotId %d ulSymNum %d iAvgEvm %d\n",
              __func__, pdata->ulCalcSta, pdata->iResult, pdata->ulChn, pdata->ulCarrId, pdata->ulSlotId, pdata->ulSymNum, pdata->iAvgEvm);

    for (UINT32 loop = 0; loop < slotNum; ++loop)
    {
        dbgInfoEx("slot %d -- evm %d\n", loop, pdata->aiEvm[loop]);
    }

    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:pe0aet1ae15b46314c9d0800130a1e476f11cc3d */

/* Started by AICoder, pid:y17ddv32fdb065014b480846a0a96d7ddb43f143 */
UINT32 DpdMsgNonStandardBandSw(UINT32 uiSwitch, UINT32 uiBandWidth, UINT16 *result)
{
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32 retVal = 0;
    UINT16 msgType = DPD_MSG_NON_STANDARD_BAND_CFG; // 0x0021
    UINT32 loop = 0;
    UINT8 *data = NULL;

    INPUT_POINTER_CHECK(result);

    if (NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n", __FUNCTION__);
        free(send);
        return BSP_ERROR;
    }

    zte_memset_s((void *)send, sizeof(THpiApiPDU), 0 , sizeof(THpiApiPDU));
    zte_memset_s((void *)recv, sizeof(THpiApiPDU), 0 , sizeof(THpiApiPDU));

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen = DPD_HTONS(sizeof(send->msg.nonStandardBandSw));
    send->head.srcId = GetUdpSrcId() & 0xff;
    send->head.dstId = GetUdpDstId() & 0xff;
    send->head.recvEn = MSG_REQ;
    send->msg.nonStandardBandSw.uiSwitch = DPD_HTONL(uiSwitch);
    send->msg.nonStandardBandSw.uiBandWidth = DPD_HTONL(uiBandWidth);
    send->lenAPDU = sizeof(send->head) + sizeof(send->msg.nonStandardBandSw);
    send->head.typeId = HEAD_TYPE_ID_SOC_ACDSP;

    dbgInfoEx("[%s] head.srcId 0x%08X, dstId 0x%08X, typeId 0x%08X, recvEn %d, sendLenAPDU %d\n",
              __FUNCTION__, send->head.srcId, send->head.dstId, send->head.typeId, send->head.recvEn, send->lenAPDU);

    retVal = SendHpiMsgAcDsp(GET_DSP_ID(0), send, recv);

    if (retVal != BSP_OK)
    {
        dbgErr("[%s] chan=%d send msg 0x%04x, error!\n", __FUNCTION__, 0, msgType);
        free(send);
        free(recv);
        return retVal;
    }

    data = (UINT8 *)((VOID *)&(recv->head));
    for (loop = 0; loop < recv->lenAPDU; loop++)
    {
        dbgInfoEx("[%s] data %3d: 0x%02X\n", __FUNCTION__, loop, data[loop]);
    }

    for (loop = 0; loop < 2; loop++)
    {
        dbgInfoEx("[%s] buf %3d: 0x%02X\n", __FUNCTION__, loop, recv->msg.buf[loop]);
    }

    dbgInfoEx("[%s] headInfo 0x%04x, result.count: 0x%04X\n", __FUNCTION__,
              recv->head.msgType, recv->msg.startAcSeqCalcAck.result);

    *result = DPD_NTOHS(recv->msg.nonStandardBandSwAck.result);
    MsgResultProc(retVal);

    free(send);
    free(recv);
    return retVal;
}
/* Ended by AICoder, pid:y17ddv32fdb065014b480846a0a96d7ddb43f143 */

/* Started by AICoder, pid:x2165971fa047a4142ba0bae809cde7a54c70590 */
UINT32 DpdMsgSendBandInfo(T_DpdMsgAcBandInfo *pdata, UINT16 *result)
{
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32 retVal = 0;
    UINT16 msgType = DPD_MSG_AC_BAND_INFO; // 0x0022
    UINT32 loop = 0;
    UINT8 *data = NULL;

    INPUT_POINTER_CHECK(pdata);

    if (NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n", __FUNCTION__);
        free(send);
        return BSP_ERROR;
    }

    zte_memset_s((void *)send, sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU));
    zte_memset_s((void *)recv, sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU));

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen = DPD_HTONS(sizeof(send->msg.acBandInfo));
    send->head.srcId = GetUdpSrcId() & 0xff;
    send->head.dstId = GetUdpDstId() & 0xff;
    send->head.recvEn = MSG_REQ;
    send->msg.acBandInfo.carrNo = DPD_HTONL(pdata->carrNo);
    send->msg.acBandInfo.radioMode = DPD_HTONL(pdata->radioMode);
    send->msg.acBandInfo.carrFreq = DPD_HTONL(pdata->carrFreq);
    send->msg.acBandInfo.bandWidth = DPD_HTONL(pdata->bandWidth);
    send->msg.acBandInfo.bandNo = DPD_HTONL(pdata->bandNo);
    send->msg.acBandInfo.flag = DPD_HTONL(pdata->flag);

    // (void)memcpy_s(&send->msg.acBandInfo, sizeof(T_DpdMsgAcBandInfo), pdata, sizeof(T_DpdMsgAcBandInfo));

    send->lenAPDU = sizeof(send->head) + sizeof(send->msg.acBandInfo);
    send->head.typeId = HEAD_TYPE_ID_SOC_ACDSP;

    dbgInfoEx("[%s] head.srcId 0x%08X, dstId 0x%08X, typeId 0x%08X, recvEn %d, sendLenAPDU %d\n",
              __FUNCTION__, send->head.srcId, send->head.dstId, send->head.typeId, send->head.recvEn, send->lenAPDU);

    retVal = SendHpiMsgAcDsp(GET_DSP_ID(0), send, recv);

    if (retVal != BSP_OK)
    {
        dbgErr("[%s] chan=%d send msg 0x%04x, error!\n", __FUNCTION__, 0, msgType);
        free(send);
        free(recv);
        return retVal;
    }

    data = (UINT8 *)((VOID *)&(recv->head));
    for (loop = 0; loop < recv->lenAPDU; loop++)
    {
        dbgInfoEx("[%s] data %3d: 0x%02X\n", __FUNCTION__, loop, data[loop]);
    }

    for (loop = 0; loop < 2; loop++)
    {
        dbgInfoEx("[%s] buf %3d: 0x%02X\n", __FUNCTION__, loop, recv->msg.buf[loop]);
    }

    dbgInfoEx("[%s] headInfo 0x%04x, result.count: 0x%04X\n", __FUNCTION__,
              recv->head.msgType, recv->msg.acBandInfoAck.result);

    *result = DPD_NTOHS(recv->msg.acBandInfoAck.result);
    MsgResultProc(retVal);

    free(send);
    free(recv);
    return retVal;
}
/* Ended by AICoder, pid:x2165971fa047a4142ba0bae809cde7a54c70590 */

/* Started by AICoder, pid:s8794r4198594cd147b90a55b019a2627cd22cf4 */
UINT32 DpdMsgDtpCaliStart(T_DPimCaliCtrlMsg *dtpCaliCtrl)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = sizeof(T_DPimCaliCtrlMsg);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_DTP_CALI_START;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32 index = 0;

    INPUT_POINTER_CHECK(dtpCaliCtrl);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>>malloc error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dtpCaliCtrl.startCtrl = DPD_HTONL(dtpCaliCtrl->startCtrl);
    send->msg.dtpCaliCtrl.slotIndex = DPD_HTONL(dtpCaliCtrl->slotIndex);
    send->msg.dtpCaliCtrl.dtpChkChNum = DPD_HTONL(dtpCaliCtrl->dtpChkChNum);
    for(index = 0; index < dtpCaliCtrl->dtpChkChNum; index++)
    {
        send->msg.dtpCaliCtrl.dtpChkChIndex[index] = DPD_HTONL(dtpCaliCtrl->dtpChkChIndex[index]);
    }

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.dtpCaliCtrlAck.result);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:s8794r4198594cd147b90a55b019a2627cd22cf4 */

/* Started by AICoder, pid:4979ewb5eft06c1140a809b6408519591604329c */
UINT32 DpdMsgGetDtpCaliStat(UINT32 *dtpCaliSta)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(T_DPimCalibratSta);
    UINT16     msgType = DPD_MSG_DTP_CALI_STAT;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(dtpCaliSta)

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    *dtpCaliSta = DPD_NTOHL(recv->msg.dtpCaliStaAck.dtpCaliSta);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:4979ewb5eft06c1140a809b6408519591604329c */

/* Started by AICoder, pid:ycdeba0a80ab71c140b80a0ba094405d65d6e6e0 */
UINT32 DpdMsgDtpMeasureStart(UINT32 startCtrl, UINT32 slotIndex)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(T_DPimMeasureCtrlMsg);
    UINT16     msgType = DPD_MSG_DTP_MEASURE_START;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8 *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    send->head.msgType  = DPD_HTONS(msgType);
    send->head.numAPDU  = 0;
    send->head.msgLen   = DPD_HTONS(msgLen);
    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId   = typeId;
    send->head.recvEn   = (UINT8)MSG_REQ;
    send->lenAPDU       = sizeof(send->head) + msgLen;

    send->msg.dtpMeasureCtrl.startCtrl = DPD_HTONL(startCtrl);
    send->msg.dtpMeasureCtrl.slotIndex = DPD_HTONL(slotIndex);

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
       dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
       free(pucApiBuff);
       return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.dtpMeasureCtrlAck.result);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:ycdeba0a80ab71c140b80a0ba094405d65d6e6e0 */

/* Started by AICoder, pid:pf223uc1b0n08c714a240939a0ad18577324f071 */
UINT32 DpdMsgGetDtpMeasureStat(UINT32 *dtpMeasureSta)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(T_DPimMeasureSta);
    UINT16     msgType = DPD_MSG_DTP_MEASURE_STAT;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(dtpMeasureSta);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    *dtpMeasureSta = DPD_NTOHL(recv->msg.dtpMeasureStaAck.dtpMeasureSta);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:pf223uc1b0n08c714a240939a0ad18577324f071 */

/* Started by AICoder, pid:97570n400esc1d01459d099cc0ba98515cd9a73c */
UINT32 DpdMsgGetDtpMeasureResult(UINT32 difChan, UINT32 band, T_DPimResQueryMsgAck *dtpMeasureRes)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(T_DPimResQueryMsg);
    UINT16     msgType = DPD_MSG_DTP_MEASURE_RESULT;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(dtpMeasureRes);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.band    = 0;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dtpMeasureResQuery.rxChan = DPD_HTONL(difChan);
    send->msg.dtpMeasureResQuery.bandIndex = DPD_HTONL(band);
    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    dtpMeasureRes->rxChan = DPD_NTOHL(recv->msg.dtpMeasureResQueryAck.rxChan);
    dtpMeasureRes->band = DPD_NTOHL(recv->msg.dtpMeasureResQueryAck.band);
    dtpMeasureRes->dtpChkSta = DPD_NTOHL(recv->msg.dtpMeasureResQueryAck.dtpChkSta);
    dtpMeasureRes->singlePimDistance = DPD_NTOHL(recv->msg.dtpMeasureResQueryAck.singlePimDistance);
    dtpMeasureRes->multiPimDistance = DPD_NTOHL(recv->msg.dtpMeasureResQueryAck.multiPimDistance);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:97570n400esc1d01459d099cc0ba98515cd9a73c */

/* Started by AICoder, pid:z0705v45fbkd81d141c208b000e0f458e104519e */
UINT32 DpdMsgGetDtpPreStartStat(UINT32 *dtpDspReadySta)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(T_DPimDspReadySta);
    UINT16     msgType = DPD_MSG_DTP_MEASURE_READY_STAT;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    INPUT_POINTER_CHECK(dtpDspReadySta);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    *dtpDspReadySta = DPD_NTOHL(recv->msg.dtpReadyStaAck.dtpDspReadySta);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:z0705v45fbkd81d141c208b000e0f458e104519e */

/* Started by AICoder, pid:9cc77b8a36b79e7144750a25a07dab5a44f6534e */
UINT32 DpdMsgDtpPreStart(INT32 startCtrl, UINT32 difChan)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = sizeof(T_DPimPreStartMsg);
    UINT16     msgType = DPD_MSG_DTP_MEASURE_PRE_START;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8      *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dtpPreStart.startCtrl = DPD_HTONL(startCtrl);
    send->msg.dtpPreStart.tddFlagChan = DPD_HTONL(difChan);

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.dtpPreStartAck.result);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:9cc77b8a36b79e7144750a25a07dab5a44f6534e */

/* Started by AICoder, pid:pcd90u8417fccea14cce0bb84150ca162be318b3 */
/**********************************************************************
 函数名称： DpdMsgSendRfBridgeAcCarrInfo(*)
 功能描述： 0x1800消息--电桥下发载波消息和AC权值
 输入参数： pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendRfBridgeAcCarrInfo(T_DpdMsgRfBrgVswrAcWeights *pData)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     acIndex = 0;
    UINT16     msgType = DPD_MSG_RFBRIDGE_AC_CARR_INFO;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pData);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.rfBridgeVswrAcWeights);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.rfBridgeVswrAcWeights.softBrgIdx = DPD_HTONL(pData->softBrgIdx);
    send->msg.rfBridgeVswrAcWeights.chipIdx = DPD_HTONL(pData->chipIdx);
    send->msg.rfBridgeVswrAcWeights.chnIdx = DPD_HTONL(pData->chnIdx);
    dbgInfoEx("softBrgIdx = %d, chipIdx = %d, chnIdx = %d\n", pData->softBrgIdx, pData->chipIdx, pData->chnIdx);
    send->msg.rfBridgeVswrAcWeights.tOriginalCarrWeights.carrNo = DPD_HTONL(pData->tOriginalCarrWeights.carrNo);
    send->msg.rfBridgeVswrAcWeights.tOriginalCarrWeights.radio = DPD_HTONL(pData->tOriginalCarrWeights.radio);
    send->msg.rfBridgeVswrAcWeights.tOriginalCarrWeights.acWeightsLen = DPD_HTONL(pData->tOriginalCarrWeights.acWeightsLen);
    dbgInfoEx("original carr carrNo = %d, radio = %d, acWeightsLen = %d\n",
                pData->tOriginalCarrWeights.carrNo, pData->tOriginalCarrWeights.radio, pData->tOriginalCarrWeights.acWeightsLen);
    for(acIndex = 0; acIndex < pData->tOriginalCarrWeights.acWeightsLen; acIndex++)
    {
        if(acIndex >= VSWR_MAX_AC_WEIGHTS_NUM)
        {
            free(pucApiBuff);
            return BSP_ERROR;
        }
        send->msg.rfBridgeVswrAcWeights.tOriginalCarrWeights.acWeights[acIndex] = DPD_HTONL(pData->tOriginalCarrWeights.acWeights[acIndex]);
        dbgInfoEx("acIndex = %d, original carr acWeights = 0x%x\n", acIndex, pData->tOriginalCarrWeights.acWeights[acIndex]);
    }

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.rfBridgeVswrAcWeightsAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:pcd90u8417fccea14cce0bb84150ca162be318b3 */

/* Started by AICoder, pid:q03f5f5313913f1144220a79c0ef947f09785b87 */
/**********************************************************************
 函数名称： DpdMsgSendRfBrgVswrPreStart(*)
 功能描述： 0x1801消息--下发选择的小区信息，并启动驻波预启动流程
 输入参数： pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendRfBrgVswrPreStart(T_DpdMsgRfBrgVswrPreStart *pData)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     swFlag = 0x5A5A;     /* 开启spa计算 0x5a5a：开始计算 */
    UINT32     brgIdx = 0;
    UINT16     msgType = DPD_MSG_RFBRIDGE_PRE_START_VSWR;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pData);
    if(pData->calSoftBrgNum > VSWR_MAX_RF_BRIDGE_NUM)
    {
        dbgErr("calSoftBrgNum = %d,is over!\n", pData->calSoftBrgNum);
        return BSP_ERROR;
    }
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.rfBridgeVswrPreStart);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.rfBridgeVswrPreStart.vswrPreCalStart = DPD_HTONL(swFlag);
    send->msg.rfBridgeVswrPreStart.calSoftBrgNum = DPD_HTONL(pData->calSoftBrgNum);
    dbgInfoEx("calSoftBrgNum = %d\n", pData->calSoftBrgNum);
    for(brgIdx = 0; brgIdx < pData->calSoftBrgNum; brgIdx++)
    {
        send->msg.rfBridgeVswrPreStart.calRfBrgIdx[brgIdx] = DPD_HTONL(pData->calRfBrgIdx[brgIdx]);
        dbgInfoEx("calRfBrgIdx = %d\n", pData->calRfBrgIdx[brgIdx]);
    }

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.rfBridgeVswrPreStartAck.result);
    dbgInfoEx("result = %d\n", retVal);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:q03f5f5313913f1144220a79c0ef947f09785b87 */

/* Started by AICoder, pid:me024f5f2fmf84714c260979f0724a79be62fa3c */
/**********************************************************************
 函数名称： DpdMsgGetRfBrgVswrPreStartSta(*)
 功能描述： 0x1802消息--查询预启动流程结果
 输入参数： pDataAck   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgGetRfBrgVswrPreStartSta(T_DpdMsgRfBrgVswrPreStartStaAck *pDataAck)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT16 msgLen = sizeof(T_DpdMsgRfBrgVswrPreStartStaAck);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_RFBRIDGE_PRE_START_STA;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
        __FUNCTION__, typeId, msgType, retVal);
    }
    pDataAck->calSoftBrgNum = DPD_NTOHL(recv->msg.rfBridgeVswrPreStartStaAck.calSoftBrgNum);
    pDataAck->calFinishSta = DPD_NTOHL(recv->msg.rfBridgeVswrPreStartStaAck.calFinishSta);
    dbgInfoEx("%s, calSoftBrgNum %d, calFinishSta %d\n", __FUNCTION__, pDataAck->calSoftBrgNum, pDataAck->calFinishSta);
    if(pDataAck->calSoftBrgNum > VSWR_MAX_RF_BRIDGE_NUM)
    {
        free(pucApiBuff);
        return BSP_ERROR;
    }
    for(loop = 0; loop < pDataAck->calSoftBrgNum; loop++)
    {
        pDataAck->calRfBrgResult[loop].rfBrgIdx = DPD_NTOHL(recv->msg.rfBridgeVswrPreStartStaAck.calRfBrgResult[loop].rfBrgIdx);
        pDataAck->calRfBrgResult[loop].rfBrgResult = DPD_NTOHL(recv->msg.rfBridgeVswrPreStartStaAck.calRfBrgResult[loop].rfBrgResult);
        dbgInfoEx("%s, rfBrgIdx %d, rfBrgResult %d\n", __FUNCTION__, recv->msg.rfBridgeVswrPreStartStaAck.calRfBrgResult[loop].rfBrgIdx,
                recv->msg.rfBridgeVswrPreStartStaAck.calRfBrgResult[loop].rfBrgResult);
    }
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:me024f5f2fmf84714c260979f0724a79be62fa3c */

/* Started by AICoder, pid:7923dx478el08e314d660b07e099d863b2818ef4 */
/**********************************************************************
 函数名称： DpdMsgSendRfBrgBreakVswr(*)
 功能描述： 0x1805消息--主动打断DSP侧驻波计算流程
 输入参数： pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgSendRfBrgBreakVswr(void)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     swFlag = (UINT16)0x5A5A;     /* 开启spa计算 0x5a5a：开始计算 */
    UINT16     msgType = DPD_MSG_RFBRIDGE_VSWR_BREAK;
    UINT32     typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.rfBridgeBreakVswr);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = GetUdpSrcId() & 0xff;
    send->head.dstId   = GetUdpDstId() & 0xff;
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.rfBridgeBreakVswr.vswrBreak = DPD_HTONL(swFlag);

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.rfBridgeBreakVswrAck.result);
    MsgResultProc((UINT16)retVal);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:7923dx478el08e314d660b07e099d863b2818ef4 */

/* Started by AICoder, pid:u05edu2e59p0475142d008486094876b5839b099 */
/**********************************************************************
 函数名称： DpdMsgGetRfBrgVswrSta(*)
 功能描述： 0x1806消息--查询驻波计算结果
 输入参数： pDataAck   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容
 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgGetRfBrgVswrSta(T_DpdMsgRfBrgVswrStaAck *pDataAck)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = sizeof(T_DpdMsgRfBrgVswrStaAck);
    UINT32 typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16 msgType = DPD_MSG_RFBRIDGE_VSWR_STA;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pDataAck);
    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
        __FUNCTION__, typeId, msgType, retVal);
    }
    pDataAck->calcFinish = DPD_NTOHL(recv->msg.rfBridgeVswrStaAck.calcFinish);
    pDataAck->msgVerify = DPD_NTOHL(recv->msg.rfBridgeVswrStaAck.msgVerify);
    dbgInfoEx("%s, calFinishSta %d, msgVerify %d!\n", __FUNCTION__, pDataAck->calcFinish, pDataAck->msgVerify);

    free(pucApiBuff);
    return retVal;
}
/* Ended by AICoder, pid:u05edu2e59p0475142d008486094876b5839b099 */

/* Started by AICoder, pid:c24feo5a76l53cc1411c094d21274906fcf06e9c */
UINT32 DpdMsgSendPaCurrentCaliInfo(UINT32 chan,UINT32 freqNo,T_DpdMsgSendPaCurrCali *pdata)
{
    UINT32 retVal = BSP_OK;
    UINT16 msgLen = 0;
    UINT16 msgType = DPD_MSG_PA_CURR_CALI;
    UINT32 i = 0;
    UINT32 j = 0;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    T_DpdMsgSendPaCurrCali *sendData = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    zte_memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen  = sizeof(send->msg.sendPaCurrCali);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId() & 0xff;
    send->head.dstId    = (UINT8)GetUdpDstId() & 0xff;
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    sendData = &send->msg.sendPaCurrCali;
    sendData->ulCurAdRecordNum = DPD_HTONL(pdata->ulCurAdRecordNum);
    sendData->ulCurAdLoadFlag = DPD_HTONL(pdata->ulCurAdLoadFlag);

    dbgInfoEx("ulCurAdRecordNum:%d, ulCurAdLoadFlag:%d\n", pdata->ulCurAdRecordNum,pdata->ulCurAdLoadFlag);
    dbgInfoEx("PaPath DacIndex AdcPath VbiasType CurrentDetectInde CurrentNum Current0 ADValue0 Temp0 Current1 ADValue1 Temp1 Current2 ADValue2 Temp2 Current3 ADValue3 Temp3 Current4 ADValue4 Temp4\n");

    for (i = 0; i < min(pdata->ulCurAdRecordNum,PA_CURR_CALI_MAX_LINE); i++)
    {
        dbgInfoEx("%-5d  %-5d  %-5d  %-5d  %-5d  %-5d  ",
                pdata->tPaCurrCaliInfo[i].ulPaChan,pdata->tPaCurrCaliInfo[i].ulDacIndex,pdata->tPaCurrCaliInfo[i].ulAdcPath,pdata->tPaCurrCaliInfo[i].ulVbiasType,pdata->tPaCurrCaliInfo[i].ulCurrentDetectIndex,pdata->tPaCurrCaliInfo[i].ulCurrentNum);
        sendData->tPaCurrCaliInfo[i].ulPaChan = DPD_HTONL(pdata->tPaCurrCaliInfo[i].ulPaChan);
        sendData->tPaCurrCaliInfo[i].ulDacIndex = DPD_HTONL(pdata->tPaCurrCaliInfo[i].ulDacIndex);
        sendData->tPaCurrCaliInfo[i].ulAdcPath = DPD_HTONL(pdata->tPaCurrCaliInfo[i].ulAdcPath);
        sendData->tPaCurrCaliInfo[i].ulVbiasType = DPD_HTONL(pdata->tPaCurrCaliInfo[i].ulVbiasType);
        sendData->tPaCurrCaliInfo[i].ulCurrentDetectIndex = DPD_HTONL(pdata->tPaCurrCaliInfo[i].ulCurrentDetectIndex);
        sendData->tPaCurrCaliInfo[i].ulCurrentNum = DPD_HTONL(pdata->tPaCurrCaliInfo[i].ulCurrentNum);

        for (j = 0; j < min(pdata->tPaCurrCaliInfo[i].ulCurrentNum,TBL_PA_CUR_N_VALUE); j++)
        {
            dbgInfoEx("%-5d  %-5d  %-5d  ",pdata->tPaCurrCaliInfo[i].curAdRecord[j].ulCurrent,pdata->tPaCurrCaliInfo[i].curAdRecord[j].ulAdVal,pdata->tPaCurrCaliInfo[i].curAdRecord[j].ulTemp);
            sendData->tPaCurrCaliInfo[i].curAdRecord[j].ulCurrent = DPD_HTONL(pdata->tPaCurrCaliInfo[i].curAdRecord[j].ulCurrent);
            sendData->tPaCurrCaliInfo[i].curAdRecord[j].ulAdVal = DPD_HTONL(pdata->tPaCurrCaliInfo[i].curAdRecord[j].ulAdVal);
            sendData->tPaCurrCaliInfo[i].curAdRecord[j].ulTemp = DPD_HTONL(pdata->tPaCurrCaliInfo[i].curAdRecord[j].ulTemp);
        }
        dbgInfoEx("\n");
    }

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }
    retVal = DPD_NTOHS(recv->msg.sendPaCurrCaliAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);

    return retVal;
}
/* Ended by AICoder, pid:c24feo5a76l53cc1411c094d21274906fcf06e9c */

/**********************************************************************
 函数名称： DpdMsgSendPaStatus(*)
 功能描述： 0x0030消息--GP发数延时参数下发
 输入参数： bspchan -  pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
 /* Started by AICoder, pid:ta557i60f0va16d1469f08b9e085df5b85d28296 */
UINT32 DpdMsgSendNcrGpInfo(UINT32 bspChan, T_DpdMsgNcrGpInfo * pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_NCR_GP_SMP_INFO;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.NcrGpPaSitInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)bspChan;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.NcrGpPaSitInfo.uiGpPaSite = DPD_HTONL(pdata->uiGpPaSite);
    send->msg.NcrGpPaSitInfo.uiNcrFlag = DPD_HTONL(pdata->uiNcrFlag);
    send->msg.NcrGpPaSitInfo.uiChnDirection = DPD_HTONL(pdata->uiChnDirection);
    send->msg.NcrGpPaSitInfo.uiUeGapVal = DPD_HTONL(pdata->uiUeGapVal);
    send->msg.NcrGpPaSitInfo.uiLinkTimeNs = DPD_HTONL(pdata->uiLinkTimeNs);

    retVal = SendHpiMsg(GET_DSP_ID(bspChan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s bspChan=%d send msg 0x%04x,error!\n",__FUNCTION__,bspChan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.NcrGpPaSitInfoAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}
/* Ended by AICoder, pid:ta557i60f0va16d1469f08b9e085df5b85d28296 */

/* Started by AICoder, pid:67cb6oa671l89ce1488108e6d08dbf8e33646c0f */
UINT32 DpdMsgSendDisablePimOnlineTxChanPara(UINT32 chan, UINT32 freqNo, T_RxSetPimOnlineDisableTxChanBand *pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT32     loop = 0;
    UINT16     msgType = DPD_MSG_SEND_TX_DISABLE_PIM_ONLINE_INFO;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendDisableChan);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)HEAD_TYPE_ID_SOC_DSP;
    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.sendDisableChan.uiNum = DPD_HTONL(pdata->uiNum);
    for(loop = 0; loop < BSP_MAX_DISABLE_TX_CHAN_BAND_NUM; loop++)
    {
        send->msg.sendDisableChan.atChanBand[loop].uTxChanNo = DPD_HTONL(pdata->atChanBand[loop].uTxChanNo);
        send->msg.sendDisableChan.atChanBand[loop].uTxBandBit = DPD_HTONL(pdata->atChanBand[loop].uTxBandBit);
        send->msg.sendDisableChan.atChanBand[loop].uRxChanNo = DPD_HTONL(pdata->atChanBand[loop].uRxChanNo);
        send->msg.sendDisableChan.atChanBand[loop].uRxBandBit = DPD_HTONL(pdata->atChanBand[loop].uRxBandBit);
    }

    retVal = SendHpiMsg(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s bspChan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.sendDisableChanAck.result);
    MsgResultProc(retVal);
    free(pucApiBuff);
    return retVal;
}
/* Ended by AICoder, pid:67cb6oa671l89ce1488108e6d08dbf8e33646c0f */

/**********************************************************************
 函数名称： DpdMsgCatachDspLinkData(*)
 功能描述： 0x1E00消息--全链路采数 dsp采数的启动与停止
 输入参数： difChan -  pdata   - 参数结构体
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgCatachDspLinkData(T_MaintainSmpCtrlMsg *pdata)
{
    UINT32 retVal      = BSP_OK;
    UINT16 msgLen      = 0;
    UINT16 msgType     = DPD_MSG_CATCH_LINK_DATA;
    UINT32 typeId      = HEAD_TYPE_ID_SOC_DSP;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    
    msgLen = sizeof(send->msg.dspCatchDataQueryInfo);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.dspCatchDataQueryInfo.uiSmpSwi   = DPD_HTONL(pdata->uiSmpSwi);
    send->msg.dspCatchDataQueryInfo.uiSmpPoint = DPD_HTONL(pdata->uiSmpPoint);
    send->msg.dspCatchDataQueryInfo.uiDifChn   = DPD_HTONL(pdata->uiDifChn);

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.dspCatchDataQueryAck.uwResult);
    MsgResultProc(retVal);
    free(pucApiBuff);

    return retVal;
}

/**********************************************************************
 函数名称： DpdMsgGetCatchDspLinkDataResult(*)
 功能描述： 0x1E01消息--全链路采数 dsp采数的启动与停止
 输入参数： *status 通道执行状态 0:完成,1:未完成   *result 通道执行结果 0:成功,非0:失败
 输出参数： 无
 返回值  ： BSP_OK: 成功, 其他: 失败
 其他说明： 无
 修改日期        版本号     修改人           修改内容

 ----------------------------------------------------------------------
 ***********************************************************************/
UINT32 DpdMsgGetCatchDspLinkDataResult(UINT32 *status, INT32 *result)
{
    UINT32 retVal      = BSP_OK;
    UINT16 msgLen      = 0;
    UINT16 msgType     = DPD_MSG_CATCH_LINK_DATA_STA;
    UINT32 typeId      = HEAD_TYPE_ID_SOC_DSP;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;

    INPUT_POINTER_CHECK(status);
    INPUT_POINTER_CHECK(result);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    
    msgLen = sizeof(send->msg.dspCatchDataStatus);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = 0;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    *status = DPD_NTOHL(recv->msg.dspCatchDataStatusAck.uiSmpSta);
    *result = DPD_NTOHL(recv->msg.dspCatchDataStatusAck.iResult);

    MsgResultProc(retVal);
    free(pucApiBuff);

    return retVal;

}

UINT32 DpdMsgGetDpdSwitch(UINT32 *uiswitch, INT32 *result, UINT32 chan)
{
    UINT32 retVal      = BSP_OK;
    UINT16 msgLen      = 0;
    UINT16 msgType     = DPD_MSP_GET_DPD_SWITCH;
    UINT32 typeId      = HEAD_TYPE_ID_SOC_DSP;
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;

    INPUT_POINTER_CHECK(uiswitch);
    INPUT_POINTER_CHECK(result);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    
    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];
    
    msgLen = sizeof(send->msg.dpdSwitchStaSend);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = chan;
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    retVal = BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>>typeId'%d MsgType'0x%04X MsgProc Error!\n", __FUNCTION__, typeId, msgType);
        free(pucApiBuff);
        return retVal;
    }

    *uiswitch = DPD_NTOHL(recv->msg.dpdSwitchSta.uiDpdSwitch);
    *result = DPD_NTOHL(recv->msg.dpdSwitchSta.iResult);

    MsgResultProc(retVal);
    free(pucApiBuff);

    return retVal;

}

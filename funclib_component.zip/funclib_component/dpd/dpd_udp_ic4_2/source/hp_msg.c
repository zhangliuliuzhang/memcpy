#include "hp_msg.h"
#include "msgproc.h"

UINT32 DpdLoadAcHp(UINT32 chan, UINT32 ctrl)
{
    UINT32   retVal = 0;
    UINT16   msgLen = sizeof(T_DpdHotLoadCtrl);
    UINT8    typeId = HEAD_TYPE_ID_SOC_ACDSP;
    UINT16   msgType = DPD_MSG_HOTLOAD_CTRL;
    THpiApiPDU   *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  =  DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;

    send->head.srcId   = (UINT8)GetAcUdpCpuId();
    send->head.dstId   = (UINT8)GetAcUdpDspId();
    send->head.typeId  = (UINT8)typeId;

    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;
    send->msg.DpdHotLoadCtrl.ctrl = DPD_HTONL(ctrl);

    if(BSP_OK != SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv))
    {
        dbgErr("%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__, chan, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHL(recv->msg.DpdHotLoadCtrlAck.result);
    free(pucApiBuff);

    return retVal;
}

UINT32 DpdLoadDspHp(UINT32 ctrl)
{
    UINT32   retVal = 0;
    UINT16   msgLen = sizeof(T_DpdHotLoadCtrl);
    UINT32   typeId = HEAD_TYPE_ID_SOC_DSP;
    UINT16   msgType = DPD_MSG_HOTLOAD_CTRL;
    THpiApiPDU   *pucApiBuff = NULL;
    THpiApiPDU   *send = NULL;
    THpiApiPDU   *recv = NULL;

    pucApiBuff = (THpiApiPDU *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if(NULL == pucApiBuff)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);

        return BSP_ERROR;
    }
    memset_s((VOID *)pucApiBuff, sizeof(THpiApiPDU) + sizeof(THpiApiPDU), 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = &pucApiBuff[0];
    recv = &pucApiBuff[1];
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->msg.DpdHotLoadCtrl.ctrl = DPD_HTONL(ctrl);
    send->head.srcId   = (UINT8)GetUdpSrcId();
    send->head.dstId   = (UINT8)GetUdpDstId();
    send->head.typeId  = (UINT8)typeId;
    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    if(BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error!\n",__FUNCTION__, typeId, msgType);
        free(pucApiBuff);

        return BSP_ERROR;
    }

    retVal = DPD_NTOHS(recv->msg.DpdHotLoadCtrlAck.result);
    free(pucApiBuff);

    return retVal;
}

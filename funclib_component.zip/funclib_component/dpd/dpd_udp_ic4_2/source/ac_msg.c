#include "ac_msg.h"
#include "msgproc.h"
#include "funccommon_pm.h"
#include "exprn.h"

static const char *ac_msg_prn = "AcMsg";
#define MsgPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,ac_msg_prn),(level)|PM_PREFIX, ##fmt)

UINT32 DpdMsgGetVerAcDsp(UINT32 chan,UINT8 *pDspVer,UINT32 verLen)
{
    UINT32 retVal         = 0;
    /* UINT16 result         = 0; */
    UINT16 recvMsgLen     = DPD_HTONL(0x1234);
    UINT16 msgType        = 0x8002;//0x8002
    UINT32 ulPrnDspVerLen = 0;
    UINT8  prnDspVer[128] = {0};
    THpiApiPDU *send      = NULL;
    THpiApiPDU *recv      = NULL;

    if (NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        free(send);
        dbgErr("%s: malloc error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)send, 0, sizeof(THpiApiPDU));
    memset((void *)recv, 0, sizeof(THpiApiPDU));

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(sizeof(send->msg.dspVer));
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)0;

    send->head.srcId   = (UINT8)GetAcUdpCpuId();
    send->head.dstId   = (UINT8)GetAcUdpDspId();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.dspVer);
#ifdef MULT_PROGRESS_S
    send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        free(send);
        free(recv);
        dbgErr("%s chan=%d send msg error!\n",__FUNCTION__,chan);
        return retVal;
    }

    ulPrnDspVerLen = sizeof(prnDspVer);
    recvMsgLen = DPD_NTOHS(recv->head.msgLen);
    memcpy_s(prnDspVer, min(recvMsgLen, ulPrnDspVerLen), recv->msg.buf, min(recvMsgLen, ulPrnDspVerLen));

    if (NULL != pDspVer)
    {
        memcpy_s(pDspVer, min(verLen, ulPrnDspVerLen), prnDspVer, min(verLen, ulPrnDspVerLen));
    }
    else
    {
        dbgInfo("DspVer:\n%s\n", prnDspVer);
    }

    free(send);
    free(recv);
    return retVal;
}

UINT32 DpdMsgUploadDataAcDsp(UINT32 chan, UINT32 freqNo, UINT32 datatype, UINT8 *pdata, UINT32 *plen)
{
    THpiApiPDU *send     = 0;
    THpiApiPDU *recv     = 0;
    UINT32     retVal    = 0;
    UINT16     msgType   = DPD_MSG_TBLUPLOAD;
    UINT16     apduNum   = 0xFFFF;
    UINT8      *pbyTemp  = NULL;
    UINT32     recvlen   = 0;
    UINT32     sendLoop  = 0;
    UINT32     firstSend = 0;

    INPUT_POINTER_CHECK(plen);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         free(send);
         return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));

    pbyTemp = pdata;
    while(1)
    {
        send->head.msgType = DPD_HTONS(msgType);
        send->head.numAPDU = DPD_HTONS(apduNum);
        send->head.msgLen  = DPD_HTONS(sizeof(send->msg.upLoad));
        send->head.chan    = (UINT8)chan;
        send->head.band    = (UINT8)freqNo;

        send->head.srcId   = (UINT8)GetAcUdpCpuId();
        send->head.dstId   = (UINT8)GetAcUdpDspId();

        send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

        send->head.recvEn  = (UINT8)MSG_REQ;
        send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.upLoad);

        send->msg.upLoad.dataType = DPD_HTONS((UINT16)datatype);
        sendLoop++;
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
        retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
        if (retVal != BSP_OK)
        {
           dbgErr("[%s]*****Receive not complete!Error msg NO.: %d*****\n",__FUNCTION__,sendLoop);
           break;
        }
        else
        {
            dbgInfoEx("[%s]*****sendLoop = %d, send apduNum 0x%04X, receive apduNum %d*****\n",
                    __FUNCTION__,sendLoop, DPD_NTOHS(send->head.numAPDU), DPD_NTOHS(recv->head.numAPDU));
        }

        /*Receive data, data is char ,no need to htons*/
        recvlen = min(DPD_NTOHS(recv->head.msgLen) - sizeof(recv->head),sizeof(T_DpdMsgUploadDataAck));
        //KILL KW
        if(recvlen > sizeof(T_DpdMsgUploadDataAck))
        {
            dbgErr("[%s]*****sendLoop %d, Receive length Error %d*****\n",__FUNCTION__,sendLoop,recvlen);
            break;
        }
        //KILL KW
        memcpy_s((VOID*)pbyTemp, recvlen, (VOID*)recv->msg.upLoadAck.data, recvlen);
        pbyTemp += recvlen; //累加recvlen
        *plen += recvlen;   //累加recvlen
        dbgInfoEx("[%s]*****recvTotalLen %d*****\n",__FUNCTION__,*plen);
        if(0 == firstSend)
        {
            firstSend = 1;
            apduNum = DPD_NTOHS(recv->head.numAPDU);
        }
        /*is the last msg*/
        if(0 == DPD_NTOHS(recv->head.numAPDU))
        {
           break;
        }
        else
        {
           apduNum--;
        }

    }

    MsgResultProc(retVal);
    free(send);
    free(recv);
    return retVal;
}

UINT32  g_recvmsgmark1=0;
UINT32  g_recvmsgmark2=0;
UINT32 DpdMsgGetDpdStrAcDsp(UINT32 chan,UINT32 freqNo, T_DpdMsgPrintStr *pdata)
{
    UINT32     retVal         = 0;
    UINT16     msgType        = DPD_MSG_GETDPDSTRINFO;
    UINT16     apduNum        = 0xFFFF;
    UINT16     i = 0;
    UINT16     recvTotalLen   = 0;
    UINT8      *pbyTemp       = NULL;
    UINT8      *pbyPrintArray = NULL;
    THpiApiPDU *send          = NULL;
    THpiApiPDU *recv          = NULL;
    UINT16      apduNumTotal  =  0;

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         free(send);
         return BSP_ERROR;
    }
   memset((VOID *)send, 0, sizeof(THpiApiPDU));
   memset((VOID *)recv, 0, sizeof(THpiApiPDU));
   UINT16 msgLen = (UINT16)sizeof(send->msg.printStr);
   UINT16 recvsize = 0;

   if(pdata == NULL)
   {
        free(send);
        free(recv);
        return BSP_ERROR;
   }

    while(1)
    {
        send->head.msgType = DPD_HTONS(msgType);
        send->head.numAPDU = DPD_HTONS(apduNum);
        send->head.msgLen  = DPD_HTONS(msgLen);
        send->head.chan    = (UINT8)chan;
        send->head.band    = (UINT8)freqNo;

        send->head.srcId   = (UINT8)GetAcUdpCpuId();
        send->head.dstId   = (UINT8)GetAcUdpDspId();

       send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

        send->head.recvEn  = (UINT8)MSG_REQ;
        send->lenAPDU      = sizeof(send->head) + msgLen;

        send->msg.printStr.powGrd = DPD_HTONL(pdata->powGrd);
        send->msg.printStr.index  = DPD_HTONL(pdata->index);
        send->msg.printStr.data0  = DPD_HTONL(pdata->data0);
        send->msg.printStr.data1  = DPD_HTONL(pdata->data1);
        send->msg.printStr.data2  = DPD_HTONL(pdata->data2);
        send->msg.printStr.data3  = DPD_HTONL(pdata->data3);
        send->msg.printStr.data4  = DPD_HTONL(pdata->data4);
        send->msg.printStr.data5  = DPD_HTONL(pdata->data5);
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
        retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
        if (retVal != BSP_OK)
        {
           dbgErr("[%s]*****Receive not complete!Error msg NO.: %d*****\n",__FUNCTION__,i);
           break;
        }
        dbgInfoEx("[%s]*****Receive complete!*****\n",__FUNCTION__);
        apduNum = DPD_NTOHS(recv->head.numAPDU);
        dbgInfoEx("[%s]*****sendLoop = %d, send apduNum 0x%04X, receive apduNum %d*****\n",
                __FUNCTION__,i, DPD_NTOHS(send->head.numAPDU), DPD_NTOHS(recv->head.numAPDU));
        /*contruct recv data struct*/
        if(NULL ==  pbyPrintArray)
        {
           pbyPrintArray = (UCHAR *)malloc((apduNum + 1) * MAX_DPD_MSG_BODY + 1);
           if(NULL == pbyPrintArray)
           {
               free(send);
               free(recv);
               return BSP_ERROR;
           }
           memset(pbyPrintArray,0,(apduNum+1)*MAX_DPD_MSG_BODY + 1);
           pbyTemp = pbyPrintArray;
           apduNumTotal= apduNum + 1 ;
           dbgInfoEx("[%s]*****malloc apduNumTotal=%d*****\n",__FUNCTION__,apduNumTotal);
        }

        /*Receive data, data is char ,no need to htons*/
        recvsize = min(DPD_NTOHS(recv->head.msgLen) - sizeof(recv->head),sizeof(T_DpdMsgPrintStrAck));
       if((pbyTemp - pbyPrintArray + recvsize)<(apduNumTotal * MAX_DPD_MSG_BODY + 1))
       {
           if(sizeof(recv->msg.printStrAck)<recvsize)
           {
               g_recvmsgmark1++;
               free(send);
               free(recv);
               free(pbyPrintArray);
               return BSP_ERROR;
           }
        memcpy_s(pbyTemp, recvsize, recv->msg.printStrAck.data, recvsize);
       }
       else
       {
           g_recvmsgmark2++;
           break;
       }

        pbyTemp += recvsize;
        recvTotalLen += recvsize;
        dbgInfoEx("[%s]*****recvsize %d*****\n",__FUNCTION__,recvsize);
        dbgInfoEx("[%s]*****recvTotalLen %d*****\n",__FUNCTION__,recvTotalLen);
        /*is the last msg*/
        if(0 == DPD_NTOHS(recv->head.numAPDU))
        {
           break;
        }
        else
        {
            apduNum = DPD_NTOHS(recv->head.numAPDU) -1;
        }
        i++;
    }

    if(NULL != pbyPrintArray)
    {
        RedirPrintf("DPD Info : \n %s \n",(UINT8*)pbyPrintArray);
        free(pbyPrintArray);
    }
    MsgResultProc(retVal);

    free(send);
    free(recv);
    return retVal;
}

UINT32 g_recvmsgmark3 = 0;
UINT32 g_recvmsgmark4 = 0;
UINT32 DpdMsgGetDpdStrAcDspInfo(UINT32 chan,UINT32 freqNo, T_DpdMsgPrintStr *pdata,UINT8 *pbyPrintArray)
{
    UINT32     retVal         = 0;
    UINT16     msgType        = DPD_MSG_GETDPDSTRINFO;
    UINT16     apduNum        = 0xFFFF;
    UINT16     loopSel        = 0;
    UINT16     recvTotalLen   = 0;
    UINT8      *pbyTemp       = NULL;
    THpiApiPDU *send          = NULL;
    THpiApiPDU *recv          = NULL;
    UINT16     apduNumTotal   = 0;
    UINT32     firstRun       = 0;
    UINT16     recvsize       = 0;

    INPUT_POINTER_CHECK(pbyPrintArray);
    if(pdata == NULL)
    {
        return BSP_ERROR;
    }
    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        free(send);
        return BSP_ERROR;
    }
    memset((VOID *)send, 0, sizeof(THpiApiPDU));
    memset((VOID *)recv, 0, sizeof(THpiApiPDU));
    UINT16 msgLen = (UINT16)sizeof(send->msg.printStr);

    while(1)
    {
        send->head.msgType = DPD_HTONS(msgType);
        send->head.numAPDU = DPD_HTONS(apduNum);
        send->head.msgLen  = DPD_HTONS(msgLen);
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->head.chan    = (UINT8)chan;
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->head.band    = (UINT8)freqNo;
        send->head.srcId   = (UINT8)GetAcUdpCpuId();
        send->head.dstId   = (UINT8)GetAcUdpDspId();
        send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

        send->head.recvEn = MSG_REQ;
        send->lenAPDU       = sizeof(send->head) + msgLen;
        send->msg.printStr.powGrd = DPD_HTONL(pdata->powGrd);
        send->msg.printStr.index  = DPD_HTONL(pdata->index);
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->msg.printStr.data0  = DPD_HTONL(pdata->data0);
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->msg.printStr.data1  = DPD_HTONL(pdata->data1);
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->msg.printStr.data2  = DPD_HTONL(pdata->data2);
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->msg.printStr.data3  = DPD_HTONL(pdata->data3);
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->msg.printStr.data4  = DPD_HTONL(pdata->data4);
        //coverity[cert_int31_c_violation:SUPPRESS]
        send->msg.printStr.data5  = DPD_HTONL(pdata->data5);
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
        //coverity[cert_int31_c_violation:SUPPRESS]
        retVal = SendHpiMsgAcDsp((UINT16)GET_DSP_ID(chan), send, recv);
        if (retVal != BSP_OK)
        {
            dbgErr("[%s]*****Receive not complete!Error msg NO.: %d*****\n",__FUNCTION__,loopSel);
            break;
        }
        apduNum = DPD_NTOHS(recv->head.numAPDU);
        if(firstRun == 0)
        {
            apduNumTotal= apduNum + 1;
            pbyTemp = pbyPrintArray;
            firstRun = 1;
        }

        recvsize = min(DPD_NTOHS(recv->head.msgLen) - sizeof(recv->head),sizeof(T_DpdMsgPrintStrAck));
        if((pbyTemp - pbyPrintArray + recvsize)<(apduNumTotal * MAX_DPD_MSG_BODY + 1))
        {
            if(sizeof(recv->msg.printStrAck)<recvsize)
            {
                g_recvmsgmark3++;
                free(send);
                free(recv);
                return BSP_ERROR;
            }
            memcpy_s(pbyTemp, recvsize, recv->msg.printStrAck.data, recvsize);
        }
        else
        {
            g_recvmsgmark4++;
            break;
        }

        pbyTemp += recvsize;
        recvTotalLen += recvsize;
        if(0 == DPD_NTOHS(recv->head.numAPDU))
        {
            break;
        }
        else
        {
            apduNum = DPD_NTOHS(recv->head.numAPDU) -1;
        }
        loopSel++;
    }

    free(send);
    free(recv);
    return BSP_OK;
}

/**************************************************************************
函数名 称： DpdMsgACCtrl(*)
功能 描述： 0x0007消息--启动AC权值计算
输入参数 ： chan        - 通道号
            freqNo
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgAcCtrl(UINT32 chan,UINT32 freqNo,UINT32 acType)
{
   THpiApiPDU *send = NULL;
   THpiApiPDU *recv = NULL;

   send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
   if(NULL == send)
   {
       dbgErr("%s: pointer send malloc error.\n", __FUNCTION__);
       return BSP_ERROR;
   }
   recv   = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
   if(NULL == recv)
   {
       free(send);
       dbgErr("%s: pointer recv malloc error.\n", __FUNCTION__);
       return BSP_ERROR;
   }

   memset((void *)send, 0 , sizeof(THpiApiPDU));
   memset((void *)recv, 0 , sizeof(THpiApiPDU));

   UINT32     retVal  = 0;
   /* UINT16     result  = 0; */
   UINT16     msgType = DPD_MSG_START_AC_WGT_CALC;//0x0007

   if((acType <= DPD_AC_TYPE_STOP)||(acType  == DPD_AC_TYPE_INSLOT)||(acType  == DPD_AC_TYPE_FDD_INSLOT_DL)||(acType  == DPD_AC_TYPE_FDD_INSLOT_UL)||(acType  == DPD_AC_TYPE_BRIDG_DL))
   {
       msgType = DPD_MSG_START_AC_WGT_CALC;//0x0007
       send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.acCtrl));
       send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.acCtrl);
   }
   else
   {
       msgType = DPD_MSG_START_VSWR_WGT_CALC;//0x0011
       send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.startVswrWgtCalc));
       send->msg.startVswrWgtCalc.acType = DPD_HTONL(acType);
       send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.startVswrWgtCalc);
   }

   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;

   send->head.srcId    = (UINT8)GetAcUdpCpuId();
   send->head.dstId    = (UINT8)GetAcUdpDspId();
   send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

   send->head.recvEn    = (UINT8)MSG_REQ;
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
   retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
   if (retVal != BSP_OK)
   {
       dbgErr("%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
   }

   retVal = DPD_NTOHS(recv->msg.acCtrlAck.result);
   MsgResultProc(retVal);
   free(send);
   free(recv);

   return retVal;
}

/**************************************************************************
函数名 称： UdpJacUpdateAcSeq(*)
功能 描述： 0x0D03消息-- Jac更新上行AC序列的标志，JacUpdateAcSeqFlag ：1为更新，0为不更新 
输入参数 ： chan        - 通道号
            freqNo
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DspMsgJacUpdateAcConjFreqSeq(UINT32 chan, UINT32 JacConjFreqSeqUpdateFlag)
{
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
    if(NULL == send)
    {
        dbgErr("%s: pointer send malloc error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    recv   = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
    if(NULL == recv)
    {
        free(send);
        dbgErr("%s: pointer recv malloc error.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    zte_memset_s((void *)send, sizeof(THpiApiPDU), 0 , sizeof(THpiApiPDU));
    zte_memset_s((void *)recv, sizeof(THpiApiPDU), 0 , sizeof(THpiApiPDU));

    UINT32     retVal  = 0;
    /* UINT16     result  = 0; */
    UINT16     msgType = UDP_MSG_UPDATE_AC_SEQ;//0x000F

    send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.JacUpdateAcSeq));
    send->msg.JacUpdateAcSeq.JacConjFreqSeqUpdateFlag = DPD_HTONL(JacConjFreqSeqUpdateFlag);
    send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.JacUpdateAcSeq);

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.chan    = (UINT8)chan;

    send->head.srcId    = (UINT8)GetAcUdpCpuId();
    send->head.dstId    = (UINT8)GetAcUdpDspId();
    send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

    send->head.recvEn    = (UINT8)MSG_REQ;
#ifdef MULT_PROGRESS_S
    send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(send);
        free(recv);
        return retVal;
    }

    retVal = DPD_NTOHS(recv->msg.JacUpdateAcSeqAck.result);
    MsgResultProc(retVal);
    free(send);
    free(recv);
 
    return retVal;
}


/**************************************************************************
函数名 称： DpdMsgGetACSta(*)
功能 描述： 0x8007消息--查询AC 权值计算结果
输入参数 ： chan        - 通道号
            freqNo
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgGetAcWgtSta(UINT32 chan,UINT32 freqNo,UINT32 cellId,UINT32 type,UINT16 *pstate, UINT32 acType)
{
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT32     retVal;
    /* UINT16     result; */
    UINT16     msgLen = sizeof(send->msg.acStateQuery);
    UINT16     msgType = DPD_MSG_AC_WGT_CALC_STATE;
    INPUT_POINTER_CHECK(pstate);

    send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
    if (send == NULL)
    {
        dbgInfo("%s send malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
    if (recv == NULL)
    {
        free(send);
        dbgInfo("%s recv malloc failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)recv, 0 , sizeof(THpiApiPDU));
    if((acType <= DPD_AC_TYPE_STOP)||(acType  == DPD_AC_TYPE_INSLOT)||(acType  == DPD_AC_TYPE_FDD_INSLOT_DL)||(acType  == DPD_AC_TYPE_FDD_INSLOT_UL)||(acType  == DPD_AC_TYPE_BRIDG_DL))
    {
        msgType = DPD_MSG_AC_WGT_CALC_STATE;//0x8007
    }
    else
    {
        msgType = DPD_MSG_VSWR_WGT_CALC_STATE;//0x8013
    }

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetAcUdpCpuId();
    send->head.dstId    = (UINT8)GetAcUdpDspId();
    send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

    send->head.recvEn    = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
       free(send);
       free(recv);
       dbgErr("%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       return retVal;
    }

    cellId = DPD_NTOHS(recv->msg.acStateQueryAck.cellId);
    type = DPD_NTOHS(recv->msg.acStateQueryAck.type);
    *pstate = DPD_NTOHS(recv->msg.acStateQueryAck.state);
    dbgInfoEx("cellId %d type %d:\n",cellId,type);
    MsgResultProc(DPD_NTOHS(recv->msg.acStateQueryAck.state));
    free(send);
    free(recv);
    return retVal;
}

UINT32 DpdMsgGetDogAcDsp(UINT32 chan,UINT32 freqNo, UINT16 *pWatchDogCnt)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    /* UINT16     result  = 0; */
    UINT16     msgLen  = 0;
    UINT16     msgType = 0;
    UINT32  loop = 0;
    UINT8* data = 0;
    INPUT_POINTER_CHECK(pWatchDogCnt);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         free(send);
         return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));
    msgLen  = sizeof(send->msg.getdogCnt);
    msgType = DPD_MSG_CHECEKWATCHDOG;//0x8005

    send->head.msgType = DPD_HTONS(msgType);//0x8005
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen); //0
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetAcUdpCpuId();//100--198.33.33.100
    send->head.dstId   = (UINT8)GetAcUdpDspId();//100--198.33.31.100
    send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

    send->head.recvEn  = (UINT8)MSG_REQ;

    send->lenAPDU      = sizeof(send->head) + msgLen;//16
    dbgInfoEx("[%s]head.srcId %d, dstId %d, typeId %d, recvEn %d,lenAPDU %d\n",__FUNCTION__,\
            send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);
#ifdef MULT_PROGRESS_S
         send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
         send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);

    if (retVal != BSP_OK)
    {
        dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(send);
        free(recv);
        return retVal;
    }
    data = (UINT8*)((VOID *)&(recv->head));
    for(loop = 0; loop < recv->lenAPDU; loop++)//18字节
    {
        dbgInfoEx("[%s]data %3d:0x%02X\n", __FUNCTION__, loop, data[loop]);
    }
    for(loop = 0; loop < 2; loop++)//18字节
    {
        dbgInfoEx("[%s]buf %3d:0x%02X\n", __FUNCTION__, loop, recv->msg.buf[loop]);
    }
    dbgInfoEx("[%s]headInfo 0x%04x, getdogCntAck.count:0x%04X\n", __FUNCTION__, \
                recv->head.msgType,recv->msg.getdogCntAck.count);
    *pWatchDogCnt = DPD_NTOHS(recv->msg.getdogCntAck.count);
    MsgResultProc(retVal);
    free(send);
    free(recv);

    return retVal;
}

UINT32 DpdMsgStartAcSeqCalc(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT16 *result)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    /* UINT16     msgLen  = 0;  */
    UINT16     msgType = DPD_MSG_START_AC_SEQ_CALC;//0x000D
    UINT32     loop    = 0;
    UINT8*     data    = 0;
    INPUT_POINTER_CHECK(result);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         free(send);
         return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));

    send->head.numAPDU = 0;
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetAcUdpCpuId();//100--198.33.33.100
    send->head.dstId   = (UINT8)GetAcUdpDspId();//100--198.33.31.100
     send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

    send->head.recvEn  = (UINT8)MSG_REQ;
    if((acType <= DPD_AC_TYPE_STOP)||(acType  == DPD_AC_TYPE_INSLOT)||(acType  == DPD_AC_TYPE_FDD_INSLOT_DL)||(acType  == DPD_AC_TYPE_FDD_INSLOT_UL))
    {
        msgType = DPD_MSG_START_AC_SEQ_CALC;//0x000D
        send->head.msgType = DPD_HTONS(msgType);
        send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.startAcSeqCalc));
        send->msg.startAcSeqCalc.cellId    = DPD_HTONL(cellId);
        send->msg.startAcSeqCalc.bandWidth = DPD_HTONL(bandWidth);
        send->msg.startAcSeqCalc.radioMode = DPD_HTONL(radioMode);
        send->msg.startAcSeqCalc.pasteCarrFlag = DPD_HTONL(pasteCarrFlag);
        send->msg.startAcSeqCalc.deviate = DPD_HTONL(deviate);
        send->msg.startAcSeqCalc.sampleRate = DPD_HTONL(sampleRate);
        send->msg.startAcSeqCalc.acType= DPD_HTONL(acType);
        send->lenAPDU = sizeof(send->head) + sizeof(send->msg.startAcSeqCalc);//16
    }
    else //计算VSWR序列
    {
        msgType = DPD_MSG_START_VSWR_SEQ_CALC;//0x0010
        send->head.msgType = DPD_HTONS(msgType);
        send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.startVswrSeqCalc));
        send->msg.startVswrSeqCalc.bandWidth = DPD_HTONL(bandWidth);
        send->msg.startVswrSeqCalc.radioMode = DPD_HTONL(radioMode);
        send->msg.startVswrSeqCalc.acType = DPD_HTONL(acType);
        send->msg.startVswrSeqCalc.deviate = DPD_HTONL(deviate);
        send->msg.startVswrSeqCalc.cellId    = DPD_HTONL(cellId);
        send->msg.startVswrSeqCalc.seqType = DPD_HTONL(seqType);
        send->lenAPDU = sizeof(send->head) + sizeof(send->msg.startVswrSeqCalc);//16
    }

    dbgInfoEx("[%s]head.srcId 0x%08X, dstId 0x%08X, typeId 0x%08X, recvEn %d, sendLenAPDU %d\n",__FUNCTION__,\
               send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);
#ifdef MULT_PROGRESS_S
         send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
         send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);

    if (retVal != BSP_OK)
    {
        dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(send);
        free(recv);
        return retVal;
    }
    data = (UINT8*)((VOID *)&(recv->head));
    for(loop = 0; loop < recv->lenAPDU; loop++)//18字节
    {
        dbgInfoEx("[%s]data %3d:0x%02X\n", __FUNCTION__, loop, data[loop]);
    }
    for(loop = 0; loop < 2; loop++)//18字节
    {
        dbgInfoEx("[%s]buf %3d:0x%02X\n", __FUNCTION__, loop, recv->msg.buf[loop]);
    }
    dbgInfoEx("[%s]headInfo 0x%04x, result.count:0x%04X\n", __FUNCTION__, \
                 DPD_NTOHS(recv->head.msgType),DPD_NTOHS(recv->msg.startAcSeqCalcAck.result));
    *result = DPD_NTOHS(recv->msg.startAcSeqCalcAck.result);
    MsgResultProc(retVal);
    free(send);
    free(recv);

    return retVal;
}

UINT32 DpdMsgStartAcSeqCalc4(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT16 *result,UINT32 refChan, UINT32 preciseDlyFlag)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    UINT16     msgType = DPD_MSG_START_AC_SEQ_CALC;//0x000D
    UINT32     loop    = 0;
    UINT8*     data    = 0;
    INPUT_POINTER_CHECK(result);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         free(send);
         return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));

    send->head.numAPDU = 0;
    if (chan < UINT8_MAX)
    {
        send->head.chan    = (UINT8)chan;
    }
    if (freqNo < UINT8_MAX)
    {
        send->head.band    = (UINT8)freqNo;
    }

    send->head.srcId   = (UINT8)GetAcUdpCpuId();//100--198.33.33.100
    send->head.dstId   = (UINT8)GetAcUdpDspId();//100--198.33.31.100

    send->head.typeId  = HEAD_TYPE_ID_SOC_ACDSP;//5

    send->head.recvEn  = MSG_REQ;
    if((acType <= DPD_AC_TYPE_STOP)||(acType  == DPD_AC_TYPE_INSLOT) || (acType  == DPD_AC_TYPE_FDD_INSLOT_DL) || (acType  == DPD_AC_TYPE_FDD_INSLOT_UL) || (acType  == DPD_AC_TYPE_BRIDG_DL))
    {
        msgType = DPD_MSG_START_AC_SEQ_CALC;//0x000D
        send->head.msgType = DPD_HTONS(msgType);
        send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.startAcSeqCalc));
        send->msg.startAcSeqCalc.cellId    = DPD_HTONL(cellId);
        send->msg.startAcSeqCalc.bandWidth = DPD_HTONL(bandWidth);
        send->msg.startAcSeqCalc.radioMode = DPD_HTONL(radioMode);
        send->msg.startAcSeqCalc.pasteCarrFlag = DPD_HTONL(pasteCarrFlag);
        send->msg.startAcSeqCalc.deviate = DPD_HTONL(deviate);
        send->msg.startAcSeqCalc.sampleRate = DPD_HTONL(sampleRate);
        send->msg.startAcSeqCalc.acType = DPD_HTONL(acType);
        send->msg.startAcSeqCalc.refChan = DPD_HTONL(refChan);
        send->msg.startAcSeqCalc.preciseDlyFlag = DPD_HTONL(preciseDlyFlag);
        send->lenAPDU = sizeof(send->head) + sizeof(send->msg.startAcSeqCalc);//16
    }
    else //????VSWR????
    {
        msgType = DPD_MSG_START_VSWR_SEQ_CALC;//0x0010
        send->head.msgType = DPD_HTONS(msgType);
        send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.startVswrSeqCalc));
        send->msg.startVswrSeqCalc.bandWidth = DPD_HTONL(bandWidth);
        send->msg.startVswrSeqCalc.radioMode = DPD_HTONL(radioMode);
        send->msg.startVswrSeqCalc.acType = DPD_HTONL(acType);
        send->msg.startVswrSeqCalc.deviate = DPD_HTONL(deviate);
        send->msg.startVswrSeqCalc.cellId    = DPD_HTONL(cellId);
        send->msg.startVswrSeqCalc.seqType = DPD_HTONL(seqType);
        send->lenAPDU = sizeof(send->head) + sizeof(send->msg.startVswrSeqCalc);//16
    }

    dbgInfoEx("[%s]head.srcId 0x%08X, dstId 0x%08X, typeId 0x%08X, recvEn %d, sendLenAPDU %d\n",__FUNCTION__,\
               send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);
#ifdef MULT_PROGRESS_S
         send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
         send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    if (chan < UINT16_MAX)
    {
        retVal = SendHpiMsgAcDsp((UINT16)GET_DSP_ID(chan), send, recv);
    }

    if (retVal != BSP_OK)
    {
        dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(send);
        free(recv);
        return retVal;
    }
    data = (UINT8*)((VOID *)&(recv->head));
    for(loop = 0; loop < recv->lenAPDU; loop++)//18???
    {
        dbgInfoEx("[%s]data %3d:0x%02X\n", __FUNCTION__, loop, data[loop]);
    }
    for(loop = 0; loop < 2; loop++)//18???
    {
        dbgInfoEx("[%s]buf %3d:0x%02X\n", __FUNCTION__, loop, recv->msg.buf[loop]);
    }
    dbgInfoEx("[%s]headInfo 0x%04x, result.count:0x%04X\n", __FUNCTION__, \
                 recv->head.msgType,recv->msg.startAcSeqCalcAck.result);
    *result = DPD_NTOHS(recv->msg.startAcSeqCalcAck.result);
    MsgResultProc((UINT16)retVal);
    free(send);
    free(recv);

    return retVal;
}

UINT32 DpdMsgChkAcDspRecvAcSeqOk(UINT32 chan,UINT32 freqNo, UINT16 *result)
{
   THpiApiPDU *send   = NULL;
   THpiApiPDU *recv   = NULL;
   UINT32     retVal  = 0;
   UINT16     msgType = DPD_MSG_DSP_AC_DATA_RECE_COMP;//0x800D
   INPUT_POINTER_CHECK(result);

   if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
   {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        return BSP_ERROR;
   }
   if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
   {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        free(send);
        return BSP_ERROR;
   }
   memset((void *)send, 0 , sizeof(THpiApiPDU));
   memset((void *)recv, 0 , sizeof(THpiApiPDU));

   send->head.msgType = DPD_HTONS(msgType);//0x800D
   send->head.numAPDU = 0;
   send->head.msgLen  = DPD_HTONS(sizeof(send->msg.chkAcDspRecvAcSeqOk)); //0
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;

   send->head.srcId   = (UINT8)GetAcUdpCpuId();//100--198.33.33.100
   send->head.dstId   = (UINT8)GetAcUdpDspId();//100--198.33.31.100

   send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

   send->head.recvEn  = (UINT8)MSG_REQ;

   send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.chkAcDspRecvAcSeqOk);//16
   dbgInfoEx("[%s]head.srcId 0x%08X, dstId 0x%08X, typeId 0x%08X, recvEn %d, sendLenAPDU %d\n",__FUNCTION__,\
              send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
   retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);

   if (retVal != BSP_OK)
   {
       dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
   }
   *result = DPD_NTOHS(recv->msg.chkAcDspRecvAcSeqOkAck.result);
   MsgResultProc(retVal);
   free(send);
   free(recv);

   return retVal;
}

UINT32 DpdMsgSendAcData(UINT32 chan,UINT32 freqNo, T_DpdMsgSendAcData_NEW* data, UINT16 *result)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    UINT16     msgLen  = 0;
    UINT16     msgType = 0;
    INPUT_POINTER_CHECK(result);
    INPUT_POINTER_CHECK(data);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        free(send);
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));
    memcpy_s((VOID*)&send->msg.sendAcData, sizeof(T_DpdMsgSendAcData_NEW), (VOID*)data, sizeof(T_DpdMsgSendAcData_NEW));
    msgLen  = sizeof(send->msg.sendAcData);
    msgType = DPD_MSG_SEND_ACDATA;//0x4008;

    send->head.msgType = DPD_HTONS(msgType);//0xC01A
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen); //0
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetAcUdpCpuId();//100--198.33.33.100
    send->head.dstId   = (UINT8)GetAcUdpDspId();//100--198.33.31.100
    send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

    send->head.recvEn  = (UINT8)MSG_REQ;

    send->lenAPDU      = sizeof(send->head) + msgLen;//16
    dbgInfo("[%s]head.srcId %d, dstId %d, typeId %d, recvEn %d,lenAPDU %d\n",__FUNCTION__,\
           send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);

    if (retVal != BSP_OK)
    {
       dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
    }

    *result = DPD_NTOHS(recv->msg.sendAcDataAck.result);
    MsgResultProc(retVal);

    free(send);
    free(recv);
    return retVal;
}

UINT32 MsgInsOnLineCal(UINT32 chan,UINT32 uiBandWidth,UINT32 OnlineInsType,UINT32 uiSampleRate, UINT32 uMode)
{
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
   /*T_DpdMsgInsOnLineACCal *sendData  = NULL;*/

   send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
   if(NULL == send)
   {
       dbgErr("%s: pointer send malloc error.\n", __FUNCTION__);
       return BSP_ERROR;
   }
   recv   = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
   if(NULL == recv)
   {
       free(send);
       dbgErr("%s: pointer recv malloc error.\n", __FUNCTION__);
       return BSP_ERROR;
   }

   memset((void *)send, 0 , sizeof(THpiApiPDU));
   memset((void *)recv, 0 , sizeof(THpiApiPDU));

   UINT32     retVal  = 0;
   /* UINT16     result  = 0; */
   UINT16     msgType = DPD_MSG_INS_ONLINE_AC_CAL;//0x0012

   if((ONLINE_TYPE_UL == OnlineInsType)||(ONLINE_TYPE_DL == OnlineInsType))
      {
          msgType = DPD_MSG_INS_ONLINE_AC_CAL;//0x0012
          send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.InsOnLineACCal));
          send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.InsOnLineACCal);
          send->msg.InsOnLineACCal.OnlineInsType = DPD_HTONL(OnlineInsType);
          send->msg.InsOnLineACCal.uibandWidth = DPD_HTONL(uiBandWidth);
      }
   else if((ONLINE_TYPE_EVM == OnlineInsType)||(ONLINE_TYPE_EVM_FEEDBACK == OnlineInsType))
   {
       msgType = DPD_MSG_INS_ONLINE_EVM_CAL;//0x0013
       send->head.msgLen  = DPD_HTONS((UINT16)sizeof(send->msg.InsOnLineEVMCal));
       send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.InsOnLineEVMCal);
       send->msg.InsOnLineEVMCal.OnlineInsType = DPD_HTONL(OnlineInsType);
       send->msg.InsOnLineEVMCal.uibandWidth = DPD_HTONL(uiBandWidth);
       send->msg.InsOnLineEVMCal.uiSampleRate = DPD_HTONL(uiSampleRate);
       send->msg.InsOnLineEVMCal.uiRadioMode = DPD_HTONL(uMode);
   }
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)0;

   send->head.srcId    = (UINT8)GetAcUdpCpuId();
   send->head.dstId    = (UINT8)GetAcUdpDspId();

    send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

   send->head.recvEn    = (UINT8)MSG_REQ;
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
   retVal = SendHpiMsgAcDsp((UINT16)GET_DSP_ID(chan), send, recv);
   if (BSP_OK != retVal)
   {
       dbgErr("%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
   }

   retVal = DPD_NTOHS(recv->msg.InsOnLineACCalAck.result);
   MsgResultProc((UINT16)retVal);
   free(send);
   free(recv);

   return retVal;
}

UINT32 DpdMsgSetParaAcDsp(UINT32 chan,UINT32 freqNo, T_DpdMsgSetSignalPara *pdata)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    /* UINT16     result  = 0; */
    UINT16     msgType = DPD_MSG_SETDPDPARAM;//0x4001

    INPUT_POINTER_CHECK(pdata);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         free(send);
         return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));

    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(sizeof(send->msg.setPara));
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetAcUdpCpuId();
    send->head.dstId   = (UINT8)GetAcUdpDspId();
    send->head.typeId = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;

    send->head.recvEn  = (UINT8)MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + sizeof(send->msg.setPara);

    send->msg.setPara.index_modul = DPD_HTONL(pdata->index_modul);
    send->msg.setPara.index_func  = DPD_HTONL(pdata->index_func);
    send->msg.setPara.par0  = DPD_HTONL(pdata->par0);
    send->msg.setPara.par1  = DPD_HTONL(pdata->par1);
    send->msg.setPara.par2  = DPD_HTONL(pdata->par2);
    send->msg.setPara.par3  = DPD_HTONL(pdata->par3);
    send->msg.setPara.par4  = DPD_HTONL(pdata->par4);
    send->msg.setPara.par5  = DPD_HTONL(pdata->par5);
    send->msg.setPara.par6  = DPD_HTONL(pdata->par6);
#ifdef MULT_PROGRESS_S
        send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
        send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
    if (retVal != BSP_OK)
    {
        dbgErr("%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(send);
        free(recv);
        return retVal;
    }
    dbgInfo("\n%s:setParaAck.result 0x%08X\n",__FUNCTION__,recv->msg.setParaAck.result);
    retVal = DPD_NTOHS(recv->msg.setParaAck.result);
    MsgResultProc(retVal);
    free(send);
    free(recv);
    return retVal;
}

/**************************************************************************
 函数名 称： AcMsgSendRruInfo(*)
 功能 描述： 0x4006消息--发送整机信息
 输入参数 ： difChan        - 通道号
             freqNo   -
             pdata - 参数结构体
 输出参数 ： 无
 返回值      ：       BSP_OK: 成功
            其他: 失败
 其他说明 ： 无
 * 修改日期        版本号     修改人           修改内容
 * -----------------------------------------------
***********************************************************************/
UINT32 AcMsgSendRruInfo(UINT32 chan,UINT32 freqNo, T_ACMsgSendRruInfo *pdata)
{
    UINT32     retVal = BSP_OK;
    UINT16     msgLen = 0;
    UINT16     msgType = DPD_MSG_SENDRRUINFO;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;
    UINT16      retRecv = BSP_OK;

    INPUT_POINTER_CHECK(pdata);

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }

    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgLen = sizeof(send->msg.sendAcRruInfo);
    send->head.msgType = DPD_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen);
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId    = (UINT8)GetAcUdpCpuId();
    send->head.dstId    = (UINT8)GetAcUdpDspId();
    send->head.typeId    = HEAD_TYPE_ID_SOC_ACDSP;
    send->head.recvEn    = MSG_REQ;
    send->lenAPDU      = sizeof(send->head) + msgLen;

    send->msg.sendAcRruInfo.fullPow     = DPD_HTONL(pdata->fullPow);
    send->msg.sendAcRruInfo.paType      = DPD_HTONL(pdata->paType);
    send->msg.sendAcRruInfo.txDflFreqL  = DPD_HTONL(pdata->txDflFreqL);
    send->msg.sendAcRruInfo.txDflFreqH  = DPD_HTONL(pdata->txDflFreqH);
    send->msg.sendAcRruInfo.rxDflFreqL  = DPD_HTONL(pdata->rxDflFreqL);
    send->msg.sendAcRruInfo.rxDflFreqH  = DPD_HTONL(pdata->rxDflFreqH);
    send->msg.sendAcRruInfo.moduleGrpId = DPD_HTONL(pdata->moduleGrpId);
    send->msg.sendAcRruInfo.boardGrpId  = DPD_HTONL(pdata->boardGrpId);
    send->msg.sendAcRruInfo.boardTypeId = DPD_HTONL(pdata->boardTypeId);
    send->msg.sendAcRruInfo.hwChangeId  = DPD_HTONL(pdata->hwChangeId);
    send->msg.sendAcRruInfo.fpgaDpdType = DPD_HTONL(pdata->fpgaDpdType);
    send->msg.sendAcRruInfo.reserve1    = DPD_HTONL(pdata->reserve1);
    send->msg.sendAcRruInfo.reserve2    = DPD_HTONL(pdata->reserve2);
    send->msg.sendAcRruInfo.reserve3    = DPD_HTONL(pdata->reserve3);
    send->msg.sendAcRruInfo.reserve4    = DPD_HTONL(pdata->reserve4);
    send->msg.sendAcRruInfo.reserve5    = DPD_HTONL(pdata->reserve5);

#ifdef MULT_PROGRESS_S
    send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif
    retVal = SendHpiMsgAcDsp((UINT16)chan, send, recv);
    if (retVal != BSP_OK)
    {
        MsgPrint(PM_ERROR,"%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(pucApiBuff);
        return retVal;
    }

    retRecv = DPD_NTOHS(recv->msg.sendRruInfoAck.result);
    MsgResultProc(retRecv);

    free(pucApiBuff);
    return retVal;

}

UINT32 DpdMsgGetDogAcDspIC(UINT32 chan,UINT32 freqNo, UINT16 *pWatchDogCnt)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    /* UINT16     result  = 0; */
    UINT16     msgLen  = 0;
    UINT16     msgType = 0;
    UINT32  loop = 0;
    UINT8* data = 0;
    INPUT_POINTER_CHECK(pWatchDogCnt);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
         dbgErr("%s: malloc error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("%s: malloc error\n",__FUNCTION__);
        free(send);
        return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));
    msgLen  = sizeof(send->msg.getdogCnt);
    msgType = DPD_MSG_CHECEKWATCHDOG;//0x8005

    send->head.msgType = DPD_HTONS(msgType);//0x8005
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen); //0
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();//5----198.33.33.5
    send->head.dstId   = (UINT8)GetAcUdpDspId();  //100--198.33.31.100
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;//5
    send->head.recvEn  = (UINT8)MSG_REQ;

    send->lenAPDU      = sizeof(send->head) + msgLen;//16
    dbgInfoEx("[%s]head.srcId %d, dstId %d, typeId %d, recvEn %d,lenAPDU %d\n",__FUNCTION__,\
            send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);

    retVal = SendHpiMsgAcDspIC(GET_DSP_ID(chan), send, recv);

    if (retVal != BSP_OK)
    {
        dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
        free(send);
        free(recv);
        return retVal;
    }
    data = (UINT8*)((VOID *)&(recv->head));
    for(loop = 0; loop < recv->lenAPDU; loop++)//18字节
    {
        dbgInfoEx("[%s]data %3d:0x%02X\n", __FUNCTION__, loop, data[loop]);
    }
    for(loop = 0; loop < 2; loop++)//18字节
    {
        dbgInfoEx("[%s]buf %3d:0x%02X\n", __FUNCTION__, loop, recv->msg.buf[loop]);
    }
    dbgInfoEx("[%s]headInfo 0x%04x, getdogCntAck.count:0x%04X\n", __FUNCTION__, \
                recv->head.msgType,recv->msg.getdogCntAck.count);
    *pWatchDogCnt = DPD_NTOHS(recv->msg.getdogCntAck.count);
    MsgResultProc(retVal);
    free(send);
    free(recv);

    return retVal;
}

UINT32 DpdMsgSendAcDataIc(UINT32 chan,UINT32 freqNo, T_DpdMsgSendAcData_NEW* data,UINT16* result, UINT32 acType)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    UINT16     msgLen  = 0;
    UINT16     msgType = 0;
    INPUT_POINTER_CHECK(result);
    INPUT_POINTER_CHECK(data);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        free(send);
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));
    memcpy_s((VOID*)&send->msg.sendAcData, sizeof(T_DpdMsgSendAcData_NEW), (VOID*)data, sizeof(T_DpdMsgSendAcData_NEW));
    msgLen  = sizeof(send->msg.sendAcData);
    if((acType < DPD_AC_TYPE_STOP)||(acType  == DPD_AC_TYPE_INSLOT) ||(acType  == DPD_AC_TYPE_FDD_INSLOT_DL)||(acType  == DPD_AC_TYPE_FDD_INSLOT_UL))
    {
        msgType = DPD_MSG_SEND_ACDATA;//0x4008; AC
    }
    else
    {
        msgType = DPD_MSG_SEND_VSWRDATA;//0x4009; VSWR
    }

    send->head.msgType = DPD_HTONS(msgType);//0x4008
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen); //0
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();//5----198.33.33.5
    send->head.dstId   = (UINT8)GetAcUdpDspId();  //100--198.33.31.100
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;//5
    send->head.recvEn  = (UINT8)MSG_NONE;

    send->lenAPDU      = sizeof(send->head) + msgLen;//16
    dbgInfoEx("[%s]head.srcId %d, dstId %d, typeId %d, recvEn %d,lenAPDU %d\n",__FUNCTION__,\
           send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);

    retVal = SendHpiMsgAcDspIC(GET_DSP_ID(chan), send, recv);
    /* 需求来源：AC时间优化，取消 AC数据发包等待对端ACK。防止发送消息太快，导致对端丢包 ，强制等待10ms */
    BspSysMsDelay(10);
    if (retVal != BSP_OK)
    {
       dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
    }
    *result = DPD_NTOHS(recv->msg.sendAcDataAck.result);
    dbgInfoEx("retVal 0x%08X, sendAcDataAck.result  0x%04X\n", retVal, *result);
    //MsgResultProc(retVal);

    free(send);
    free(recv);
    return retVal;
}

UINT32 DpdMsgSendInsOnLineDataIc(UINT32 chan,UINT32 freqNo,T_DpdMsgSendSlaveData *data,UINT16* result)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    UINT16     msgLen  = 0;
    UINT16     msgType = 0;
    INPUT_POINTER_CHECK(result);
    INPUT_POINTER_CHECK(data);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        free(send);
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));
    //memcpy((VOID*)&send->msg.SendSlaveData, (VOID*)data, sizeof(T_DpdMsgSendSlaveData));
    memcpy_s((VOID*)&send->msg.SendSlaveData, sizeof(T_DpdMsgSendSlaveData),(VOID*)data, sizeof(T_DpdMsgSendSlaveData));
    msgLen  = sizeof(send->msg.SendSlaveData);

    msgType = DPD_MSG_INS_ONLINE_SEND_AC_DATA;

    send->head.msgType = DPD_HTONS(msgType);//0x4017
    send->head.msgLen  = DPD_HTONS(msgLen); //0
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen); //0
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;
    send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();//5----198.33.33.5
    send->head.dstId   = (UINT8)GetAcUdpDspId();  //100--198.33.31.100
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;//5
    send->head.recvEn  = (UINT8)MSG_NONE;
    send->lenAPDU      = sizeof(send->head) + msgLen;//16


    retVal = SendHpiMsgAcDspIC(GET_DSP_ID(chan), send, recv);
    BspSysMsDelay(40);
    if (retVal != BSP_OK)
    {
       dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
    }
    *result = DPD_NTOHS(recv->msg.SendSlaveDataAck.result);
    dbgInfoEx("retVal 0x%08X, sendAcDataAck.result  0x%04X\n", retVal, *result);

    free(send);
    free(recv);
    return retVal;
}

UINT32 DpdMsgSendAcDataIc4(UINT32 chan,UINT32 freqNo, T_DpdMsgSendAcData_NEW_IC4* data,UINT16* result, UINT32 acType)
{
    THpiApiPDU *send   = NULL;
    THpiApiPDU *recv   = NULL;
    UINT32     retVal  = 0;
    UINT16     msgLen  = 0;
    UINT16     msgType = 0;
    INPUT_POINTER_CHECK(result);
    INPUT_POINTER_CHECK(data);

    if(NULL == (send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(NULL == (recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU))))
    {
        free(send);
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((void *)send, 0 , sizeof(THpiApiPDU));
    memset((void *)recv, 0 , sizeof(THpiApiPDU));
    memcpy_s((VOID*)&send->msg.sendAcDataIC4, sizeof(T_DpdMsgSendAcData_NEW_IC4), (VOID*)data, sizeof(T_DpdMsgSendAcData_NEW_IC4));
    msgLen  = sizeof(send->msg.sendAcDataIC4);
    if((acType < DPD_AC_TYPE_STOP)||(acType  == DPD_AC_TYPE_INSLOT) ||(acType  == DPD_AC_TYPE_FDD_INSLOT_DL)||(acType  == DPD_AC_TYPE_FDD_INSLOT_UL))
    {
        msgType = DPD_MSG_SEND_ACDATA;//0x4008; AC
    }
    else
    {
        msgType = DPD_MSG_SEND_VSWRDATA;//0x4009; VSWR
    }

    send->head.msgType = DPD_HTONS(msgType);//0x4008
    send->head.numAPDU = 0;
    send->head.msgLen  = DPD_HTONS(msgLen); //0
    send->head.chan    = (UINT8)chan;
    send->head.band    = (UINT8)freqNo;

    send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();//5----198.33.33.5
    send->head.dstId   = (UINT8)GetAcUdpDspId();  //100--198.33.31.100
    send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;//3
    send->head.recvEn  = (UINT8)MSG_NONE;

    send->lenAPDU      = sizeof(send->head) + msgLen;//16
    dbgInfoEx("[%s]head.srcId %d, dstId %d, typeId %d, recvEn %d,lenAPDU %d\n",__FUNCTION__,\
           send->head.srcId,send->head.dstId,send->head.typeId,send->head.recvEn, send->lenAPDU);

    retVal = SendHpiMsgAcDspIC(GET_DSP_ID(chan), send, recv);
    /* 需求来源：AC时间优化，取消 AC数据发包等待对端ACK。防止发送消息太快，导致对端丢包 ，强制等待10ms */
    BspSysMsDelay(5);
    if (retVal != BSP_OK)
    {
       dbgErr("[%s] chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
    }
    *result = DPD_NTOHS(recv->msg.sendAcDataAckIC4.result);
    dbgInfoEx("retVal 0x%08X, sendAcDataAck.result  0x%04X\n", retVal, *result);
    //MsgResultProc(retVal);

    free(send);
    free(recv);
    return retVal;
}

/*****************************************************************************
 * 函数名称: AcdspMsgGetDog(*)
 * 功能描述: 0x8005消息--获取ACDSP狗信息
 * 输入参数: ulSocketId   - Socket Id
 *           ulDifChnl    - 通道号
 *           ulFreqBandNo - 通道号
 * 输出参数: pulWatchDogCnt - WatchDogCnt指针
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2019-01-04, 创建
 *----------------------------------------------------------------------------
 */
UINT32 AcdspMsgGetDog(UINT32 typeId, UINT32 ulChnlNo, UINT32 ulFreqBandNo, UINT32 *pulWatchDogCnt)
{
    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;
    UINT32 ulDogCntAck = 0;
    UINT32 retVal = BSP_OK;
    /* UINT8  *pucTmpBuff = NULL; */
    UINT8  *pucApiBuff = NULL;
    THpiApiPDU *send = NULL;
    THpiApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(THpiApiPDU) + sizeof(THpiApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(THpiApiPDU) + sizeof(THpiApiPDU));

    send = (THpiApiPDU *)&pucApiBuff[0];
    recv = (THpiApiPDU *)&pucApiBuff[sizeof(THpiApiPDU)];

    msgType = UDPMSG_CHECK_WATCHDOG;
    ulMsgLen  = sizeof(send->msg.getdogCnt);

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = UDPMSG_HTONS(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = UDPMSG_HTONS(ulMsgLen);
    send->head.chan    = (UINT8)ulChnlNo;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = (UINT8)GetUdpSrcId();
    send->head.dstId    = (UINT8)GetUdpDstId();
    send->head.typeId    = (UINT8)typeId;
    send->head.recvEn    = (UINT8)GetReqOrAck();


    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>typeId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
                __FUNCTION__, typeId, msgType, retVal);
    }


    ulDogCntAck = UDPMSG_NTOHS(recv->msg.getdogCntAck.count);
    if (NULL != pulWatchDogCnt)
    {
        *pulWatchDogCnt = ulDogCntAck;
    }
    else
    {
        retVal |= BIT_SET(2);
        dbgInfo("%s>>typeId'%d Msg(Type'0x%04X Len'%d) SendLen'%d DogCnt %s! DogCnt= %d\n",
                __FUNCTION__,typeId, msgType, ulMsgLen, send->lenAPDU,
                (BSP_OK == retVal) ? "Succ" : "Error", ulDogCntAck);
    }

    free(pucApiBuff);
    MsgResultProc(retVal);

    return retVal;
}

/**************************************************************************
函数名 称： DpdMsgAcRefChnHCtrl(*)
功能 描述： 0x000B消息--启动AC参考通道H计算
输入参数 ： chan        - 通道号
            freqNo
输出参数 ： 无
返回值      ：       BSP_OK: 成功
           其他: 失败
其他说明 ： 无
* 修改日期        版本号     修改人           修改内容
* -----------------------------------------------
* 2014/12/15                      V1.0      zfx       新建
***********************************************************************/
UINT32 DpdMsgJacRefChnHCtrl(UINT32 chan,UINT32 freqNo,UINT32 acType)
{
   THpiApiPDU *send = NULL;
   THpiApiPDU *recv = NULL;
   UINT32    retVal = 0;
   UINT16   msgType = DPD_MSG_START_AC_REF_CHN_H_CALC;//0x000B

   send = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
   if(NULL == send)
   {
       dbgErr("%s: pointer send malloc error.\n", __FUNCTION__);
       return BSP_ERROR;
   }
   recv = (THpiApiPDU *)malloc(sizeof(THpiApiPDU));
   if(NULL == recv)
   {
       free(send);
       dbgErr("%s: pointer recv malloc error.\n", __FUNCTION__);
       return BSP_ERROR;
   }
   memset((void *)send, 0 , sizeof(THpiApiPDU));
   memset((void *)recv, 0 , sizeof(THpiApiPDU));

   if((acType <= DPD_AC_TYPE_STOP) || (acType  == DPD_AC_TYPE_FDD_INSLOT_DL) || (acType  == DPD_AC_TYPE_FDD_INSLOT_UL) || (acType  == DPD_AC_TYPE_BRIDG_DL))
   {
       msgType           = DPD_MSG_START_AC_REF_CHN_H_CALC;//0x000B
       send->head.msgLen = DPD_HTONS((UINT16)sizeof(send->msg.acRefHCalCtrl));
       send->lenAPDU     = sizeof(send->head) + sizeof(send->msg.acRefHCalCtrl);
   }
   send->head.msgType = DPD_HTONS(msgType);
   send->head.numAPDU = 0;
   send->head.chan    = (UINT8)chan;
   send->head.band    = (UINT8)freqNo;
   send->head.srcId   = (UINT8)GetAcUdpCpuId();
   send->head.dstId   = (UINT8)GetAcUdpDspId();
   send->head.typeId  = (UINT8)HEAD_TYPE_ID_SOC_ACDSP;
   send->head.recvEn  = (UINT8)MSG_REQ;
#ifdef MULT_PROGRESS_S
   send->head.srcId   = (UINT8)GetAcUdpCpuIdIC();
   send->head.typeId  = (UINT8)HEAD_TYPE_ID_NXP_ACDSP;
#endif

   retVal = SendHpiMsgAcDsp(GET_DSP_ID(chan), send, recv);
   if (retVal != BSP_OK)
   {
       dbgErr("%s chan=%d send msg 0x%04x,error!\n",__FUNCTION__,chan,msgType);
       free(send);
       free(recv);
       return retVal;
   }
   retVal = DPD_NTOHS(recv->msg.acRefHCalAck.result);
   MsgResultProc(retVal);
   free(send);
   free(recv);

   return retVal;
}

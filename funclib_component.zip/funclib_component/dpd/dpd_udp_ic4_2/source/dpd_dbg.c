/*********************************************************************
 * 版权所有 (C)2014, 深圳市中兴通讯股份有限公司。
 * 
 * 文件名称： dpd_app.c
 * 文件标识：
 * 内容摘要：
 * 其它说明：
 * 当前版本：
 * 作   者：
 * 完成日期：
 * 
 * 修改记录1：
 *    修改日期：
 *    版 本 号：
 *    修 改 人：
 *    修改内容：

**********************************************************************/

/**************************************************************************
 *                        头文件
 **************************************************************************/
#include "math.h"
#include "bsppub.h"
#include "vxadp.h"
#include "exprn.h"
#include "systemcallapi.h"
#include "funccommon.h"
#include "dpd_app.h"
#include "dsp_msg.h"
#include "dsp_dbg.h"
#include "ac_msg.h"
#include "funccommon_carrmap.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/

#define DSP_TO_CPU_UPLOAD_DATA_SIZE_10MB 10*1024*1024
/**************************************************************************
 *                         全局变量声明
 **************************************************************************/
RecordPrnResult r_PrnResltfor4dBProtect = {0};
UINT32 r_PrnResltfor4dBProtectDatLen = 0;
static const char *dpd_dbg_prn = "DpdDbg";
#define DpdDbgPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,dpd_dbg_prn),(level)|PM_PREFIX,##fmt)

/**************************************************************************
 *                               函数实现
 **************************************************************************/
/******************************常用调试接口***********************************/
typedef UINT32(*DPD_DBG_FUNC)(INT32 p0, INT32 p1, INT32 p2, INT32 p3, INT32 p4, INT32 p5, INT32 p6, INT32 p7, INT32 p8, INT32 p9);
static struct
{
	DPD_DBG_FUNC pFunc;
    CHAR  *pcCmd;
    CHAR  *pcParaList;
    CHAR  *pcMemo;
} stDpdHelp[] =
{
    {(DPD_DBG_FUNC)dspver,         "dspver"      , "dsp芯片号"               , "查询dsp版本号"},
    {(DPD_DBG_FUNC)dpddog,         "dpddog"      , "dsp芯片号"               , "查询dsp看门狗状态"},
    {(DPD_DBG_FUNC)dpdstart,       "dpdstart"    , "通道号，频段号"           , "启动对应通道的dpd"},
    {(DPD_DBG_FUNC)dpdstarts,      "dpdstarts"   , "通道号1，通道号2，频段号"  , "启动通道1至通道2的dpd"},
    {(DPD_DBG_FUNC)dpdstop,        "dpdstop"     , "通道号，频段号"           , "停止对应通道的dpd"},
    {(DPD_DBG_FUNC)dpdstops,       "dpdstops"    , "通道号1，通道号2，频段号"  , "停止通道1至通道2的dpd"},
    {(DPD_DBG_FUNC)clearlut,       "clearlut"    , "通道号，频段号"           , "对应通道dpd清表"},
    {(DPD_DBG_FUNC)clearluts,      "clearluts"   , "通道号1，通道号2，频段号"  , "通道1至通道2 dpd清表"},
	{(DPD_DBG_FUNC)getdpdvswr,     "getdpdvswr"  ,  "通道号，频段号"           , "对应通道发起驻波检测并获取spa"},
};

UINT32 dpdhelpprn(VOID)
{
    UINT32 ulLoop;
    dbgInfo("%-6s %-20s %-40s %-20s\n",
            "cmdIdx", "testFunc", "funcParaList", "Memo");

    for (ulLoop = 0; ulLoop < NELEMENTS(stDpdHelp); ulLoop++)
    {
        dbgInfo("%-6d %-20s %-40s %-20s\n", ulLoop + 1,
        		stDpdHelp[ulLoop].pcCmd, stDpdHelp[ulLoop].pcParaList,
				stDpdHelp[ulLoop].pcMemo);
    }

    return BSP_OK;
}
/***************************************************************************
 *  函数名称  : dpdinit
 *  功能描述  : dpd初始化
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输入参数说明: 无
 *  返回值说明  : 无
 *  引用全局变量: 无
 *  修改说明    :声明在公共模块，不能删除
 *  修改日期   版本号      修改人      修改内容
*----------------------------------------------------------------------------*/
UINT32  dpdinit(UINT32 index)
{
    return 0;
}
/*********************************2 dpd 常规控制功能*****************************************/
/***************************DPD 旁路、启停、清表**********************************************/
/*****************************************************************************
 *  函数名称   : dpdonnew(*)
 *  功能描述   : dpd旁路和不旁路控制 0x0001消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 freqNo：频段号
 *              type（新增）：旁路类型，0:下行反馈均旁路 1:旁路下行DPD 2:旁路反馈DPD
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 由于相对与3.0增加了旁路类型，所以原接口无法使用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 dpdon(UINT32 chan,UINT32 bandId, UINT16 type)
{
    UINT16 ctrl = (UINT16)DPD_UNBYPASS;
    return DpdByPassCtrl(chan,bandId,type,ctrl);
}
UINT32 dpdons(UINT32 startChn,UINT32 endChn,UINT32 bandId, UINT16 type)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal = dpdon(chn, bandId, type);
    } while (++chn < chnNum);
    return retVal;
}
UINT32 dpdoff(UINT32 chan, UINT32 bandId, UINT16 type)
{
    UINT16 ctrl = (UINT16)DPD_BYPASS;
    return DpdByPassCtrl(chan,bandId,type,ctrl);
}
UINT32 dpdoffs(UINT32 startChn,UINT32 endChn,UINT32 bandId, UINT16 type)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal = dpdoff(chn, bandId, type);
    } while (++chn < chnNum);
    return retVal;
}
/*****************************************************************************
 *  函数名称   : dpdstart(*)
 *  功能描述   : dpd 启动和停止控制  0x0002消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 freqNo：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 内部接口
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 dpdstart(UINT32 chan,UINT32 bandId)
{
    return DpdStartCtrl(chan,bandId,DPD_START);
}
UINT32 dpdstarts(UINT32 startChn,UINT32 endChn,UINT32 bandId)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal = dpdstart(chn, bandId);
    } while (++chn < chnNum);
    return retVal;
}
UINT32 dpdstop(UINT32 chan,UINT32 bandId)
{
    return DpdStartCtrl(chan,bandId,DPD_STOP);
}
UINT32 dpdstops(UINT32 startChn,UINT32 endChn,UINT32 bandId)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal = dpdstop(chn, bandId);
    } while (++chn < chnNum);
    return retVal;
}
/*****************************************************************************
 *  函数名称   : clearlut(*)
 *  功能描述   : dpd 清表   0x0003消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 clearlut(UINT32 chan, UINT32 bandId)
{
   UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0; 
    UINT32 ulRetVal = BSP_OK; 

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    } 

    return DpdMsgClrLut(ulDifChnl, bandId, 0);
}
UINT32 clearluts(UINT32 startChn,UINT32 endChn,UINT32 bandId)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal = clearlut(chn, bandId);
    } while (++chn < chnNum);
    return retVal;
}
/*********************************3 矢量驻波检测*****************************************/
/*****************************************************************************
 *  函数名称   : getdpdvswr(*)
 *  功能描述   : 获取DSP计算的矢量驻波 0xc007
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 getdpdvswr(UINT32 chan,UINT32 bandId)
{
    INT32 vswrReal;
    INT32 vswrImag;
    INT32 nco;
    UINT32 retVal;
    retVal = BspGetDspVswr(chan,bandId,&vswrReal,&vswrImag,&nco);
    if(BSP_OK == retVal)
    {
        DpdDbgPrint(PM_INFO,"%s chn[%d] get vswrReal=[%d] vswrImag=[%d] nco=[%d]\n", __FUNCTION__,chan,vswrReal,vswrImag,nco);
    }
    else
    {
        DpdDbgPrint(PM_INFO,"%s chn[%d] get vswrcalc error!\n", __FUNCTION__,chan);
    }
    return retVal;
}
/*****************************************************************************
 *  函数名称   : startvectorvswr(*)
 *  功能描述   : CPU通过该消息通知DSP 发起VSWR 计算  0x004消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   :  无
 *  返 回 值   :  BSP_OK 成功
 *               其他     失败
 *  其它说明   :  内部使用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zfx@2019-09-10, 创建
 *----------------------------------------------------------------------------*/
UINT32 startvectorvswr(UINT32 chan,UINT32 bandId)
{
    return BspNotifyDpdStartVswrCalc(chan, bandId);
}
/*****************************************************************************
 *  函数名称   : getvectorcalcsta(*)
 *  功能描述   : 获取dsp矢量驻波计算的状态  0x004消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   :  无
 *  返 回 值   :  BSP_OK 成功
 *               其他     失败
 *  其它说明   :  内部使用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zfx@2019-09-10, 创建
 *----------------------------------------------------------------------------*/
UINT32 getvectorcalcsta(UINT32 chan, UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgVswrQueryAck sVserAck = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if (BSP_OK != DpdMsgGetVswrVal(ulDifChnl, bandId, &sVserAck))
    {
        dbgInfo("%s>>BspChnl'%d DifChnl'%d DpdVswrVal MsgGet Error!\n",
                __FUNCTION__, chan, ulDifChnl);
        return BSP_ERROR;
    }

    dbgInfo("VswrCalFlag state = 0x%x\n",sVserAck.iVswrCalFlag);
    dbgInfo("VswrSamFlag state = 0x%x\n",sVserAck.iVswrSamFlag);
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : getvectorval(*)
 *  功能描述   : 获取dsp矢量驻波spa实部虚部  0x004消息
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   :  无
 *  返 回 值   :  BSP_OK 成功
 *               其他     失败
 *  其它说明   :  内部使用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------*/
UINT32 getvectorval(UINT32 chan, UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgVswrQueryAck vswrVal;
    INT32 VswrReal = 0;
    INT32 VswrImag = 0;
    INT32 Nco = 0;

    DPD_CHAN_CHECK(chan);

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if (BSP_OK != DpdMsgGetVswrVal(ulDifChnl, bandId, &vswrVal))
    {
        /*DpdAccessSemGive(semIdDpdAccess);*/
        DpdDbgPrint(PM_ERROR,"%s>>BspChnl'%d DifChnl'%d DpdVswrVal MsgGet Error!\n",
                 __FUNCTION__, chan, ulDifChnl);
        return BSP_ERROR;
    }
    VswrReal = vswrVal.spaData[0].vswrReal;
    VswrImag = vswrVal.spaData[0].vswrImag;
    Nco = vswrVal.spaData[0].nco;
    dbgInfo("\nVswrReal = %d,VswrImag = %d,Nco = %d,\n",VswrReal,VswrImag,Nco);
    return BSP_OK;
}
/************************************4 PIMC功能*****************************************/
/*****************************************************************************
 *  函数名称   : pimcctrl(*)
 *  功能描述   : 给DSP发送启动、停止PIMC 0x0008消息
 *  输入参数   : chan：bsp通道号 bandId：频段号 ctrl：0x5a5a 开始  0x2d2d停止
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 pimcctrl(UINT32 chan, UINT32 bandId, UINT32 ctrl)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcCtrl(ulDifChnl, bandId, ctrl);
}
/*****************************************************************************
 *  函数名称   : pimccleartbl(*)
 *  功能描述   : 给DSP发送PIMC 清表  0x0009
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : PIMC模块调用
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 pimccleartbl(UINT32 chan,UINT32 bandId)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    return DpdMsgPimcClrTbl(ulDifChnl, bandId);
}
/*****************************************************************************
 *  函数名称   : pimcpretrainsta(*)
 *  功能描述   : 查询DSP发送PIMC 预训练结果 0x800a消息
 *  输入参数   : chan：bsp通道号  bandId:频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 正常
 *              其他    异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), zxt@2018-1-25, 创建
 *----------------------------------------------------------------------------*/
UINT32 pimcpretrainsta(UINT32 chan,UINT32 bandId)
{
    UINT32 state = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgPimcPreTrainState(ulDifChnl, bandId, &state);
    DpdDbgPrint(PM_INFO,"PimcChnl'%d DifChnl'%d RetVal'0x%04X: PimcPreTrainState= %d\n",
             chan, ulDifChnl, ulRetVal, state);

    return ulRetVal;
}
/************************************5 TS功能*******************************************/
/*****************************************************************************
 *  函数名称   : dpdts(*)
 *  功能描述   : dpd TS 启动/停止 0x000c消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : para: 含义需要与dsp确认  sw：1启动 0停止
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : TS即训练序列 APP调用，所以gpNum没用也无法删除
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 dpdts(UINT32 type, UINT32 sw)
{
    UINT32 gpNum = 1;
    return BspDpdTsCtrl(type, sw, gpNum);
}
/*****************************************************************************
 *  函数名称   : dpdtsexpquery(*)
 *  功能描述   : DSP发起TS请求消息，TS异常时DSP发起TS请求  0x8016
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 dpdtsexpquery(VOID)
{
    UINT32 retVal = BSP_OK;
    T_DpdTsExpQueryResult queryResult = {0,};
    retVal = BspDpdTsExpQuery(&queryResult);
    dbgInfo("%s Ts Request result: Ts Sta:%d BspChanMask:%d,retVal:%d\n",__FUNCTION__,queryResult.expFlag,queryResult.chanmask,retVal);
    return retVal;
}
/*****************************************************************************
 *  函数名称   : dpdquery(*)
 *  功能描述   : 查询TS状态 0x800c消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : para目前没用到
 *  输出参数   :
 *  返 回 值   : 返回0代表TS完成，其它值代表未完成
 *  其它说明   : TS即训练序列，不为通道
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 dpdquery(UINT32 typeId, UINT32 ulChnlNo, UINT32 ulFreqBandNo)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulChnlNo, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulChnlNo);
        return BSP_ERROR;
    }

	return DspMsgQueryTs(typeId,ulDifChnl, ulFreqBandNo);
}
/************************************6 配置、参数、路由等信息下发*******************************************/
UINT32 showpowadjinfo(VOID)
{
    UINT32 ulChan = 0;

    for(ulChan=0;ulChan<BspGetTxChanNum();ulChan++)
    {
        //dbgInfo("%s>>PowAdjChan %d ,Cnt %d\n",__FUNCTION__,ulChan,PowAdjCnt[ulChan]);
    }
    return BSP_OK;
}
UINT32 dpdpowadj(UINT32 chan, UINT32 freqNo)
{
	return BspDpdSetPowAdjInfo(chan,freqNo);
}
UINT32 dpdchanoff(UINT32 chanmask)
{
       return  BspSetDpdChanOff(chanmask);
}
/*TxFwd.txt*/
UINT32 dpdsetfwdpara(UINT32 chan, UINT32 freqNo)
{
       return  BspDpdSetFwdParam(chan,freqNo);
}
/*FilterGain.txt*/
UINT32 dpdsetfilterpara(UINT32 chan, UINT32 freqNo)
{
       return  BspDpdSetFilterParam(chan,freqNo);
}
UINT32 dpddlcell(UINT32 chan, UINT32 freqNo)
{
       return  BspDpdSetCellInfo(chan,freqNo);
}
UINT32 dpdulcell(UINT32 chan, UINT32 freqNo)
{
       return  BspDpdSetRxCellInfo(chan,freqNo);
}
/************************************7 维测(版本、状态检测、EVM ACP 下表等)*******************************************/
/*****************************************************************************
 *  函数名称   : dspver
 *  功能描述   : 读取dsp版本号 0x8002
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chipId:芯片id
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
VOID dspver(UINT32 chipId)
{
    UINT8  ver[DSP_VERSION_MAX_LEN] = {0};
    UINT32 retVal;

    retVal = BspGetDspVer(chipId,ver,sizeof(ver)-1);
    CHECK_RET_WARNING(retVal, "BspGetDspVer ret:%d", retVal);
    DpdDbgPrint(PM_INFO,"dsp version: %s\n",ver);
}

static void char_replace(UINT8 *buf, UINT8 src, UINT8 des)
{
    while (*buf != '\0')
    {
        if (src == *buf)
        {
            *buf = des;
        }
        buf++;
    }
}

void verbase_dspver(UINT32 chipId)
{
    UINT8  dspVer[DSP_VERSION_MAX_LEN] = {0};
    
    if (BspGetDspVer(chipId, dspVer, sizeof(dspVer)-1) == BSP_OK)
    {
        char_replace(dspVer, '\n', ' ');
        char_replace(dspVer, '\r', ' ');
        dbgInfo("DSP#%d VER     : %s\n", chipId, dspVer); 
    }
    else
    {
        dbgInfo("DSP#%d VER     : error\n", chipId);
    }
}

/*****************************************************************************
 *  函数名称   : verbase_acdspver
 *  功能描述   : 打印ACDSP版本号
 *  输入参数   : chipId - 芯片号
 *              processName - ACDSP进程名
 *  输出参数   : 无
 *  返 回 值   : 无
 *  其它说明   : 无
 *--------------------------------------------------------------------------*/
void verbase_acdspver(UINT32 chipId, const CHAR *processName)
{
    UINT8  acDspVer[DSP_VERSION_MAX_LEN] = {0};
    UINT32 pidNum = 0;
    
    if (BspIsPidExisted(processName, &pidNum) != BSP_OK)
    {
        return;
    }

    if (BspGetDspAcVer(chipId, acDspVer, sizeof(acDspVer)-1) == BSP_OK)
    {
        char_replace(acDspVer, '\n', ' ');
        char_replace(acDspVer, '\r', ' ');
        dbgInfo("ACDSP#%d VER   : %s\n", chipId, acDspVer); 
    }
    else
    {
        dbgInfo("ACDSP#%d VER   : error\n", chipId);
    }
}

/*****************************************************************************
 *  函数名称   : dsploadsta
 *  功能描述   : 查询dsp加载状态 0x8008
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan：bsp通道号 bandId：频段号
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 dsploadsta(UINT32 chan, UINT32 bandId)
{
    UINT32 state = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgDspLoadState(ulDifChnl, bandId, &state);
    DpdDbgPrint(PM_INFO,"BspChnl'%d DifChnl'%d: DspLoadState= %d\n", chan, ulDifChnl, state);

    return ulRetVal;
}
/**************************************************************************
* 函数名称: dpddog(*)
* 功能描述: 查询dsp状态 0x8005消息
* 输入参数: chan   - 0
* 输出参数:
* 返 回 值: watchdog bit为1表示有告警，bit为0表示正常
           bit7 - DSP工作异常告警
           其他 - 预留
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2017-02-16 14:55:24    创建
*----------------------------------------------------------------------------*/
UINT32 dpddog(UINT32 chan)
{
    UINT32 watchdog = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgGetDog(ulDifChnl, 0, &watchdog);
    DpdDbgPrint(PM_INFO, "%s>>BspChnl'%d DifChnl'%d Ret'0x%08X: WatchDog= 0x%04X\n",
             __FUNCTION__, chan, ulDifChnl, ulRetVal, watchdog);

    return ulRetVal;
}
UINT32 dpdoffsta(VOID)
{
	UINT32 ulRetVal = 0;
    return BspDpdChanOffStaQuery(&ulRetVal);
}
/*****************************************************************************
 *  函数名称   : sample(*)
 *  功能描述   : 上传dsp 中的采样数据到 hostIp 的文件 fileName 中
 *              0xc001:采数启动停止 0xc002:采数状态获取 0xc003上传数据
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : typeId: dsp、asdcp等类型id，HEAD_TYPE_ID_SOC_DSP chan：bsp通道号 flag：数据类型 pos：采数位置
 *              type：数据类型(定点、浮点等)  hostIP: rru ip filename: 数据文件名 flag、pos具体含义待确认
 *  输出参数   :
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   : 内部维测使用
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 sample(UINT32 typeId,UINT32 chan,UINT32 flag,UINT32 pos,const char *hostIP,const char *fileName)
{
    UCHAR *pBuf = NULL;
    UINT32 bufSize = 6*1024*1024;
    UINT32 datalen = 0;
    UINT32 retVal;
    /* UINT32 statSample = 0; */

    DPD_CHAN_CHECK(chan);

    pBuf = (UCHAR *)malloc(bufSize);
    if(NULL == pBuf)
    {
        DpdDbgPrint(PM_ERROR,"%s malloc failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if (BSP_OK != BspSampleDpdData(typeId,chan,0,pBuf,&datalen,flag,pos,hostIP,fileName))
    {
        DpdDbgPrint(PM_ERROR,"%s BspSampleDpdData failed\n",__FUNCTION__);
        free(pBuf);
        return BSP_ERROR;
    }

    /*create file,copy data*/
    if (BSP_OK != BspWriteFile((const char *)pBuf,datalen,fileName))
    {
        DpdDbgPrint(PM_ERROR,"%s BspWriteFile failed datalen is %d\n",__FUNCTION__,datalen);
        free(pBuf);
        return BSP_ERROR;
    }
    /*upload file*/
    if(BSP_OK == BspTftp(fileName, hostIP, "-p"))
    {
        DpdDbgPrint(PM_INFO,"tftp put file success\n");
        retVal = BSP_OK;
    }
    else
    {
        DpdDbgPrint(PM_ERROR,"%s tftp put file failed\n",__FUNCTION__);
        retVal = BSP_ERROR;
    }

    free(pBuf);
    return retVal;
}
/*****************************************************************************
 *  函数名称   : gettable(*)
 *  功能描述   : 上传dsp 中的表格数据到 hostIp 的文件 fileName 中  0xc003消息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : typeId: 待确认 chan：bsp通道号 bandId：频段号 type：数据类型(定点、浮点等)
 *              hostIP: rru ip filename: 数据文件名
 *  输出参数   : 无
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 gettable(UINT32 typeId,UINT32 chan,UINT32 type,const char *hostIP,const char *fileName)
{
    return BspUploadDpdTable(typeId,chan,0,type,hostIP,fileName);
}
UINT32 gettablei(UINT32 typeId,UINT32 chan,UINT32 type,const char *hostIP,const char *fileName)
{
    return BspUploadDpdTable(typeId,chan,0,type,hostIP,fileName);
}
/*****************************************************************************
 *  函数名称   : settable(*)
 *  功能描述   : 下载hostIp 的文件 fileName 内容到dsp中dpd表格中 0xc005
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : pSem     - 信号量指针
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 settable(UINT8 typeId,UINT32 chan, UINT8 module, UINT8 powGrd, UINT8 *hostIP,char *fileName)
{
    TUdpApiHeader headInfo = {0};
    headInfo.typeId = typeId;
    headInfo.band = 0;
    headInfo.module = module;
    headInfo.powGrd = powGrd;
    return BspDownloadDpdTable(chan,&headInfo,hostIP,fileName);
}

UINT32 settablei(UINT8 typeId,UINT32 chan,UINT8 module, UINT8 powGrd, UINT8 *hostIP,char *fileName)
{
    TUdpApiHeader headInfo = {0};
    headInfo.typeId = typeId;
    headInfo.band = 0;
    headInfo.module = module;
    headInfo.powGrd = powGrd;
    return BspDownloadDpdTable(chan,&headInfo,hostIP,fileName);
}
#if 0
/*****************************************************************************
 *  函数名称   : dpdfpgawrite(*)
 *  功能描述   : dsp和fpga通信 读写
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : pSem     - 信号量指针
 *  返 回 值   : BSP_OK, 无异常; 否则异常
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------*/
UINT32 dpdfpgawrite(UINT32 chan, UINT32 addr, UINT32 data)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgWrFpgaReg(ulDifChnl, 0, addr, data);
    return ulRetVal;
}

UINT32 dpdfpgaread(UINT32 chan, UINT32 addr)
{
    UINT32 data = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgRdFpgaReg(ulDifChnl, 0, addr, &data);
    if (ulRetVal == BSP_OK)
    {
        DpdDbgPrint(PM_INFO,"BspChnl'%d DifChnl'%d: Reg[0x%04X]= 0x%04X\n", chan, ulDifChnl, addr, data);
        return data;
    }
    return ulRetVal;
}
#endif

/*********************************2 dpd 通用参数设置和查询功能****************************************/
UINT32 setdpdpara(UINT32 chan,
        INT32 index_modul,
        INT32 index_func,
        INT32 data0,
        INT32 data1,
        INT32 data2,
        INT32 data3,
        INT32 data4,
        INT32 data5,
        INT32 data6)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgSetSignalPara tdpdPara;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    tdpdPara.index_modul = index_modul;
    tdpdPara.index_func = index_func;
    tdpdPara.par0 = data0;
    tdpdPara.par1 = data1;
    tdpdPara.par2 = data2;
    tdpdPara.par3 = data3;
    tdpdPara.par4 = data4;
    tdpdPara.par5 = data5;
    tdpdPara.par6 = data6;

    ulRetVal = DpdMsgSetPara(ulDifChnl, 0, &tdpdPara);
    return ulRetVal;
}
/*自由打印*/
UINT32 getdpdstrinfo(UINT32 chan,UINT32 bandId,
    UINT32 powGrd,
    UINT32 index,
    INT32 data0,
    INT32 data1,
    INT32 data2,
    INT32 data3,
    INT32 data4,
    INT32 data5)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    T_DpdMsgPrintStr dpdstr;

    DPD_CHAN_CHECK(chan);

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        RedirPrintf("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    dpdstr.powGrd = powGrd;
    dpdstr.index = index;
    dpdstr.data0 = data0;
    dpdstr.data1 = data1;
    dpdstr.data2 = data2;
    dpdstr.data3 = data3;
    dpdstr.data4 = data4;
    dpdstr.data5 = data5;

    ulRetVal = DpdMsgGetDpdStr(ulDifChnl, bandId, &dpdstr);
    return ulRetVal;
}

UINT32 getsta(UINT32 chan,UINT32 bandId,UINT32 powGrd)
{
    return  getdpdstrinfo(chan,bandId,powGrd,0,0,0,0,0,0,0);
}

UINT32 getdspdebug(UINT32 chan,UINT32 bandId,UINT32 powGrd)
{
    return  getdpdstrinfo(chan,bandId,powGrd,1,0,0,0,0,0,0);
}

UINT32 getdpdparm(UINT32 chan,UINT32 bandId,UINT32 powGrd,UINT32 index)
{
    return  getdpdstrinfo(chan,bandId,powGrd,2,index,0,0,0,0,0);
}

UINT32 getstai(UINT32 chan,UINT32 bandId)
{
    return  0;
}

UINT32 getallsta()
{
    return  0;
}
/*DSP基础配置打印（cell、HW、cfg）0xD003消息*/
UINT32 dspprnbase(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;
	UINT8 ucBuf[8192]={0};
	UINT32 ulLen=0;
	UINT32 typeId = 0;
	UINT32 i = 0;
	T_DspMsgBasePrtQuery tDspMsgBasePrtQuery={0};
	tDspMsgBasePrtQuery.index0        = index0;
	tDspMsgBasePrtQuery.index1        = index1;
	tDspMsgBasePrtQuery.index2        = index2;
	tDspMsgBasePrtQuery.index3        = index3;
	tDspMsgBasePrtQuery.index4        = index4;

    ulRetVal = DpdGetDifInfoByBspChnl(0, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl DifInfoByBspChn Get Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

	ulRetVal = DspMsgBasePrintf(typeId,ulDifChnl,0,&tDspMsgBasePrtQuery,ucBuf,&ulLen);
	for(i=0;i<ulLen;i++)
	{
		dbgPrn("%c",ucBuf[i]);
	}
	dbgPrn("\n");
	SetDspPrnType(0); /*获取完成之后恢复默认态*/

	return  ulRetVal;
}
/*LMS自由打印 0xD004消息*/
UINT32 dspprndpd(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(1); /*0xd004-oxd003,消息结构体一致，所以复用结构体，只修改消息号*/
	return dspprnbase(index0, index1, index2, index3, index4);
}
/*PIMC自由打印 0xD005消息*/
UINT32 dspprnpimc(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(2);
	return dspprnbase(index0, index1, index2, index3, index4);
}
/*PIMC online自由打印 0xD006消息*/
UINT32 dspprnpimon(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(3);
	return dspprnbase(index0, index1, index2, index3, index4);
}
/*PIMC offline自由打印 0xD007消息*/
UINT32 dspprnpimoff(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(4);
	return dspprnbase(index0, index1, index2, index3, index4);
}
/*SSC自由打印 0xD008消息*/
UINT32 dspprnssc(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(5);
	return dspprnbase(index0, index1, index2, index3, index4);
}
/*TRAP自由打印 0xD009消息*/
UINT32 dspprntrap(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(6);
	return dspprnbase(index0, index1, index2, index3, index4);
}
/*TS自由打印 0xD00A消息*/
UINT32 dspprnts(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(7);
	return dspprnbase(index0, index1, index2, index3, index4);
}
/*VSWR自由打印 0xD004B消息*/
UINT32 dspprnvswr(UINT32 index0,UINT8 index1,UINT8 index2,UINT8 index3,UINT8 index4)
{
	SetDspPrnType(8);
	return dspprnbase(index0, index1, index2, index3, index4);
}

//获取DPD的状态信息
UINT32 getdpdsta(VOID)
{
    UINT32  retVal;
    //dbgInfo("====================== Dpd State Info ======================\n");
    retVal = getdpdstrinfo(0,0,0,7,0,0,0,0,0,0);
    //dbgInfo("============================================================\n");

    return retVal;
}
UINT32 dpdssc(UINT32 chan, UINT32 sw)
{
    UINT32 temp = 0;
    UINT32 ulRet = 0;
    if(0 == sw)
    {
        temp = 0x2d2d;  //ssc 关闭
    }
    else
    {
        temp = 0x5a5a; //ssc 打开
    }
    ulRet = setdpdpara(chan,22,8,temp,0,0,0,0,0,0);
    return ulRet;
}
UINT32 dpddataadj(UINT32 chan, UINT32 sw)
{
    UINT32 temp = 0;
    UINT32 ulRet = 0;
    if(0 == sw)
    {
        temp = 0x2d2d;  /*关闭目标向量二次对齐*/
    }
    else
    {
        temp = 0x5a5a; /*打开关闭目标向量二次对齐*/
    }
    ulRet = setdpdpara(chan,3,51,temp,0,0,0,0,0,0);
    return ulRet;
}
/*sw:0 --反向迭代   1--正向迭代*/
UINT32 dpditermode(UINT32 chan, UINT32 sw)
{
    UINT32 ulRet = 0;
    ulRet = setdpdpara(chan,3,22,sw,0,0,0,0,0,0);
    return ulRet;
}

UINT32 TestAcpCal(UINT32 chan)
{
    T_DpdMsgAcpCalResultAck AcpCalResult = {0};
    UINT32 ret = BSP_OK;

    ret = BspGetAcpCalResult(chan, &AcpCalResult);
    dbgInfoEx("BspGetAcpCalResult, acp_state is : %d\n", AcpCalResult.acp_state);
    dbgInfoEx("BspGetAcpCalResult, acp_channel is : %d\n", AcpCalResult.acp_channel);
    dbgInfoEx("BspGetAcpCalResult, acp_left is : %d\n", AcpCalResult.acp_left);
    dbgInfoEx("BspGetAcpCalResult, acp_right is : %d\n", AcpCalResult.acp_right);
    return ret;
}

/*********** AC-DSP TestFunc ***********
    acdspdog
    acdspver
    acSeqCalc
    acSendAcData 1
    acSendAcData 0
    acGetAcWgtStatus
    acSetParaAcDsp 0xe6,0
    acGetDpdStrAcDsp 0x11,1,16
    acUpLoadDataAcDsp 0x1e
    acChkAcDspRecvAcSeqOk
    acStartAcWgtCalc
*****************************************/
UINT32 acdspdog(UINT32 chan, UINT32 freqNo)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT16 WatchDogCnt = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgGetDogAcDsp(ulDifChnl, freqNo, &WatchDogCnt);
    dbgInfo("%s>>BspChnl'%d ChipId'%d DifChnl'%d Ret'0x%08X: WatchDogCnt= 0x%04X\n",
            __FUNCTION__, chan, ulChipId, ulDifChnl, ulRetVal, WatchDogCnt);

    return ulRetVal;
}

UINT32 acdspdogic(UINT32 chan, UINT32 freqNo)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT16 WatchDogCnt = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgGetDogAcDspIC(ulDifChnl, freqNo, &WatchDogCnt);
    dbgInfo("%s>>BspChnl'%d ChipId'%d DifChnl'%d Ret'0x%08X: WatchDogCnt= 0x%04X\n",
            __FUNCTION__, chan, ulChipId, ulDifChnl, ulRetVal, WatchDogCnt);

    return ulRetVal;
}

UINT32 acdspver(VOID)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    return DpdMsgGetVerAcDsp(ulDifChnl, NULL, 0);
}

UINT32 acSeqCalc(UINT32 chan, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bw, UINT32 sampleRate, UINT32 mode, UINT32 acType)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal  = BSP_OK;
    UINT32 freqNo    = carr;
    UINT32 cellId    = carr;
    UINT32 radioMode = (0 == mode) ? BSP_RADIO_STANDARD_5G : mode;//默认5G模式
    UINT32 bandWidth = (0 == bw)   ? BANDWIDTH_100M : bw;         //默认100M
    UINT16 result    = 0;
    UINT32 seqType   = 1;
    UINT32 refchan   = 0;
    UINT32 preciseDlyFlag = 0;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgStartAcSeqCalc4(ulDifChnl, freqNo, cellId, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType, &result, refchan, preciseDlyFlag);
    dbgInfo("%s>>BspChnl'%d ChipId'%d DifChnl'%d Ret'0x%08X: Result= 0x%04X\n",
            __FUNCTION__, chan, ulChipId, ulDifChnl, ulRetVal, result);

    return ulRetVal;
}

VOID acGetAcWgtStatus(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 type,UINT32 acType)
{
    UINT16 usState = 0;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(chan, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, chan);
        return;
    }

    ulRetVal = DpdMsgGetAcWgtSta(ulDifChnl, freqNo, cellId, type, &usState,acType);
    dbgInfo("%s>>BspChnl'%d DifChnl'%d Ret'0x%08X: State= 0x%04X\n",
            __FUNCTION__, chan, ulDifChnl, ulRetVal, usState);
    return;
}

//acSetParaAcDsp 0xe6,0
UINT32 acSetParaAcDsp(INT32 index, INT32 funcIndex, INT32 par0, INT32 par1, INT32 par2)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgSetSignalPara data = {0};

    data.index_modul = index;
    data.index_func  = funcIndex;
    data.par0 = par0;
    data.par1 = par1;
    data.par2 = par2;

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    return DpdMsgSetParaAcDsp(ulDifChnl, 0, &data);
}
UINT32 acsetdsppara(INT32 index, INT32 funcIndex, INT32 par0, INT32 par1, INT32 par2)
{
    return acSetParaAcDsp(index, funcIndex, par0, par1, par2);
}


//acGetDpdStrAcDsp 0x11,1,16
UINT32 acGetDpdStrAcDsp(UINT32 index, INT32 data0, INT32 data1, INT32 data2, INT32 data3)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgPrintStr data = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        RedirPrintf("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    data.powGrd = 0;/* 档位号 */
    data.index = index; /* 消息类型 */
    data.data0 = data0; /* 参数值 */
    data.data1 = data1;
    data.data2 = data2;
    data.data3 = data3;
    data.data4 = 0;
    data.data5 = 0;

    return DpdMsgGetDpdStrAcDsp(ulDifChnl, 0, &data);
}

UINT32 acGetDpdStrAcDspInfo(UINT32 index, INT32 data0, INT32 data1, UINT8 *pAcDspBufStr)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    T_DpdMsgPrintStr data = {0};

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }
    data.powGrd = 0;    /* 档位号 */
    data.index  = index; /* 消息类型 */
    data.data0  = data0; /* 参数值 */
    data.data1  = data1;
    data.data2  = 0;
    data.data3  = 0;
    data.data4  = 0;
    data.data5  = 0;

    ulRetVal = DpdMsgGetDpdStrAcDspInfo(ulDifChnl, 0, &data, pAcDspBufStr);
    return ulRetVal;
}

UINT32 testacGetDpdStrAcDspInfo(UINT32 index, INT32 data0, INT32 data1)
{
    UINT8 *pbyPrintArray = NULL;
    UINT32 retVal = BSP_OK;

    pbyPrintArray = (UCHAR *)malloc(65536 * MAX_DPD_MSG_BODY + 1);
    if(NULL == pbyPrintArray)
    {
        dbgErr("[%s]malloc error!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    retVal = acGetDpdStrAcDspInfo(index, data0, data1, pbyPrintArray);

    dbgInfo("%s\n",pbyPrintArray);
    free(pbyPrintArray);
    return retVal;
}

UINT32 acgetdspinfo(UINT32 index,INT32 data0,INT32 data1, INT32 data2, INT32 data3)
{
    return acGetDpdStrAcDsp(index, data0, data1, data2, data3);
}

UINT32 acUpLoadDataAcDspBin(UINT32 datatype,const char* filename)
{
    UINT8* data    = 0;
    UINT32 length  = 0;
    UINT32 wrLength  = 0;
    UINT32 bufSize = DSP_TO_CPU_UPLOAD_DATA_SIZE_10MB;
    FILE   *fp     = NULL;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    INT32 fret = 0;
    INPUT_POINTER_CHECK(filename);

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    if (NULL == (fp = fopen(filename, "wb+")))
    {
        dbgErr("[%s]open file error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    data = (UINT8 *)malloc(bufSize);
    if (NULL==data)
    {
        fret = fclose(fp);
        FCLOSE_CHECK(fret);
        dbgErr("[%s]malloc error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(data,0,bufSize);

    ulRetVal = DpdMsgUploadDataAcDsp(ulDifChnl, 0, datatype, data, &length);
    if (ulRetVal == BSP_ERROR)
    {
        fret = fclose(fp);
        FCLOSE_CHECK(fret);
        free(data);
        dbgErr("%s>>BspChnl'%d DifChnl'%d DpdMsgDataAcDsp Upload Error!\n",
               __FUNCTION__, ulBspChnl, ulDifChnl);
        return BSP_ERROR;
    }

    wrLength = fwrite(data, 1, length, fp);
    if (wrLength != length)
    {
        fret = fclose(fp);
        FCLOSE_CHECK(fret);
        free(data);
        dbgErr("%s>>fail to write %s\n", __FUNCTION__,filename);
        return ERROR;
    }
    fret = fclose(fp);
    FCLOSE_CHECK(fret);
    free(data);

    return ulRetVal;
}

UINT32 acgetdspdata(UINT32 datatype,const char* filename)
{
    INPUT_POINTER_CHECK(filename);
    return acUpLoadDataAcDspBin(datatype,filename);
}
VOID acStartAcWgtCalc(UINT32 acType)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulFreqNo  = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return;
    }

    ulRetVal = DpdMsgAcCtrl(ulDifChnl, ulFreqNo, acType);
    dbgInfo("%s>>BspChnl'%d DifChnl'%d FreqNo'%d: FuncRet= 0x%08X\n",
            __FUNCTION__, ulBspChnl, ulDifChnl, ulFreqNo, ulRetVal);
}
//acUpLoadDataAcDsp 0x1e
UINT32 acUpLoadDataAcDsp(UINT32 datatype)
{
    UINT8* data    = 0;
    UINT32 length  = 0;
    UINT32 loop    = 0;
    UINT32 bufSize = 10*1024*1024;
    FILE   *fp     = NULL;
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulBspChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    INT32 fret = 0;
    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

	if (NULL == (fp = fopen("/acUpLoadDataAcDsp.txt", "w+")))
    {
        dbgErr("[%s]open file error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    data = (UCHAR *)malloc(bufSize);
    if (data == NULL)
    {
        fret = fclose(fp);
         FCLOSE_CHECK(fret);
        dbgErr("[%s] malloc data failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(data,0,bufSize);

    ulRetVal = DpdMsgUploadDataAcDsp(ulDifChnl, 0, datatype, data, &length);

    fret = fprintf(fp, "\n[%s]***********totalLength %d, upLoadData(HEX)***********\n", __FUNCTION__, length);
    FPRINTF_CHECK(fret);
    for(loop = 0; loop < length; loop++)
    {
        if(0 == loop % 16)
        {
            fret = fprintf(fp, "\nIndex %6d:", loop);
            FPRINTF_CHECK(fret);
        }
        fret = fprintf(fp, "%02X ", data[loop]);
        FPRINTF_CHECK(fret);
    }
    fret = fprintf(fp, "\n*******************************\n\n");
    FPRINTF_CHECK(fret);
    fret = fclose(fp);
    FCLOSE_CHECK(fret);
    free(data);

    return ulRetVal;
}

UINT32 acChkAcDspRecvAcSeqOk(UINT32 ulBspChnl, UINT32 freqNo)
{
    UINT16 usResult = 0;
    UINT32 ulChipId = 0;
    UINT32 ulDifChnl = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulBspChnl, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulBspChnl);
        return BSP_ERROR;
    }

    ulRetVal = DpdMsgChkAcDspRecvAcSeqOk(ulDifChnl, freqNo, &usResult);
    dbgInfo("%s>>BspChnl'%d ChipId'%d DifChnl'%d Ret'0x%08X: Result= 0x%04X\n",
            __FUNCTION__, ulBspChnl, ulChipId, ulDifChnl, ulRetVal, usResult);

    return ulRetVal;
}
/*APP编译不过，打桩*/
UINT32 dspprintf(UINT32 chan,UINT8 dsp_prt_style,UINT8 dsp_prt_style_second,UINT8 dpd_pwr_index)
{
    return BSP_OK;
}
/*APP编译不过，打桩*/
UINT32 dspprintf_record(UINT32 chan,UINT8 dsp_prt_style,UINT8 dsp_prt_style_second,UINT8 dpd_pwr_index)
{
    return BSP_OK;
}
/*APP编译不过，打桩*/
VOID RecordResultWhen4dBProtectTrig(UINT32 chan)
{
    return ;
}

static UINT32 getwtd(UINT32 typeId, UINT32 ulChnlNo, UINT32 ulFreqBandNo)
{
    UINT32 ulChipId  = 0;
    UINT32 ulDifChnl = 0;
    UINT32 WatchDogCnt = 0;
    UINT32 ulRetVal = BSP_OK;

    ulRetVal = DpdGetDifInfoByBspChnl(ulChnlNo, TX, &ulChipId, &ulDifChnl);
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>BspChnl'%d DifInfoByBspChn Get Error!\n", __FUNCTION__, ulChnlNo);
        return BSP_ERROR;
    }

    ulRetVal = AcdspMsgGetDog(typeId, ulDifChnl, ulFreqBandNo, &WatchDogCnt);
    dbgInfo("%s>>TypeId'%d BspChnl'%d ChipId'%d DifChnl'%d Ret'0x%08X: GetWtd= 0x%04X\n",
            __FUNCTION__, typeId, ulChnlNo, ulChipId, ulDifChnl, ulRetVal, WatchDogCnt);

    return ulRetVal;
}

static UINT32 testSetFrDiffInfo(UINT32 bspChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn    = 0;
    UINT32 chipidx   = 0;
    UINT32 frOffSetNs = 0; 
    UINT32 tddRamFrOffSetNs = 0;
    T_DspMsgFrDiffInfo sendFrDiffInfo = {0,0};
    
    TBL_CHAN_VALID_CHECK(bspChn);
    retVal = BspGetDifInfoByBspChn(bspChn, TX, &chipidx, &difChn);

    if(BSP_OK != retVal)
    {
        dbgErr("%s bspChn=%d BspGetDifInfoByBspChn fail! \n", __func__, bspChn);
        return retVal;
    }

    BspHalAdaptGetFrTmValInChan(difChn, &frOffSetNs, &tddRamFrOffSetNs);
    
    sendFrDiffInfo.frDiff = frOffSetNs;
    sendFrDiffInfo.tddRamFrOffSet = tddRamFrOffSetNs;
    dbgInfo("BspChn = %d, sendFrDiffInfo.frDiff = %d sendFrDiffInfo.tddRamFrOffSet = %d \n",bspChn,
    sendFrDiffInfo.frDiff,sendFrDiffInfo.tddRamFrOffSet);

    return DpdMsgSendFrDiffInfo(bspChn, &sendFrDiffInfo);
}
/* Started by AICoder, pid:d41e6gcf65ob7931456c08993036a45309b1b04e */
UINT32 ShowRev(UINT32 chan)
{
    UINT32 ret = BSP_OK;
    INT32 revCompensate_I = 0;
    INT32 revCompensate_Q = 0;
    UINT32 rfFreq = 0;
    T_DpdMsgRfBridgeRevCalcStaAck *pSpaVal = NULL;
    UINT32 spaNum = 0;
    UINT32 ulLoop = 0;

    pSpaVal = (T_DpdMsgRfBridgeRevCalcStaAck *)malloc(sizeof(T_DpdMsgRfBridgeRevCalcStaAck));
    INPUT_POINTER_CHECK(pSpaVal);
    memset_s(pSpaVal, sizeof(T_DpdMsgRfBridgeRevCalcStaAck), 0, sizeof(T_DpdMsgRfBridgeRevCalcStaAck));

    ret = BspGetRevVal_RfBridge(chan,pSpaVal);
    if(BSP_OK != ret)
    {
        dbgErr("Fail to Get Spa From Dsp!\n");
        free(pSpaVal);
        return ret;
    }
    spaNum = pSpaVal->spaNum;
    dbgInfo("chan %d spaNum:%d vswrType 0x%x calcFinish 0x%x calcResult %d \n", pSpaVal->chanIdx, spaNum,pSpaVal->vswrType,pSpaVal->calcFinish,pSpaVal->calcResult);
    for(ulLoop = 0; ulLoop < spaNum; ulLoop++)
    {
        rfFreq = pSpaVal->chRevDiffCfg[ulLoop].rfFreq;
        revCompensate_I = pSpaVal->chRevDiffCfg[ulLoop].revCompensate_I;
        revCompensate_Q = pSpaVal->chRevDiffCfg[ulLoop].revCompensate_Q;
        dbgInfo(" rfFreq = %d, revCompensate_I=%d, revCompensate_Q=%d\n", rfFreq, revCompensate_I, revCompensate_Q);
    }
    free(pSpaVal);
    return ret;
}


UINT32 ShowSpa(UINT32 chan)
{
    UINT32 ret = BSP_OK;
    INT32 spaI = 0;
    INT32 spaQ = 0;
    INT32 nco = 0;
    T_DpdMsgRfBridgeSpaCalcStaAck *pSpaVal = NULL;
    UINT32 spaNum = 0;
    UINT32 ulLoop = 0;

    pSpaVal = (T_DpdMsgRfBridgeSpaCalcStaAck *)malloc(sizeof(T_DpdMsgRfBridgeSpaCalcStaAck));
    INPUT_POINTER_CHECK(pSpaVal);
    memset_s(pSpaVal, sizeof(T_DpdMsgRfBridgeSpaCalcStaAck), 0, sizeof(T_DpdMsgRfBridgeSpaCalcStaAck));

    ret = BspGetMultiDspVswr_RfBridge(chan,pSpaVal);
    if(BSP_OK != ret)
    {
        dbgErr("Fail to Get Spa From Dsp!\n");
        free(pSpaVal);
        return ret;
    }
    spaNum = pSpaVal->spaNum;
    dbgInfo("chan %d spaNum:%d calcFinish 0x%x calcResult %d \n", pSpaVal->chanIdx, spaNum,pSpaVal->calcFinish,pSpaVal->calcResult);
    for(ulLoop = 0; ulLoop < spaNum; ulLoop++)
    {
        spaI = pSpaVal->spaData[ulLoop].spaI;
        spaQ = pSpaVal->spaData[ulLoop].spaQ;
        nco = pSpaVal->spaData[ulLoop].nco;
        dbgInfo(" spaI = %d, spaQ=%d, nco=%d\n", spaI, spaQ, nco);
    }
    free(pSpaVal);
    return ret;
}
/* Ended by AICoder, pid:d41e6gcf65ob7931456c08993036a45309b1b04e */

/* Started by AICoder, pid:s8913ubfc9g18d2148b10900b071c8327a57c6cd */
UINT32 BspSetRfBridgeAcCarrInfoTest(void)
{
    T_DpdMsgRfBrgVswrAcWeights data = {0};
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    data.softBrgIdx = 0;
    data.chipIdx = 0;
    data.chnIdx = 2;
    data.tOriginalCarrWeights.carrNo = 0;
    data.tOriginalCarrWeights.radio = 0x20;
    data.tOriginalCarrWeights.acWeightsLen = 10;
    for(loop = 0; loop < 10; loop++)
    {
        data.tOriginalCarrWeights.acWeights[loop] = loop;
    }
    retVal = DpdMsgSendRfBridgeAcCarrInfo(&data);
    return retVal;
}
/* Ended by AICoder, pid:s8913ubfc9g18d2148b10900b071c8327a57c6cd */

/* Started by AICoder, pid:ra86fkb3ffbdb6d14ddf0a09c05d8219cf83698f */
UINT32 BspSetRfBrgVswrPreStartTest(void)
{
    T_DpdMsgRfBrgVswrPreStart data = {0};
    UINT32 retVal = BSP_OK;

    data.vswrPreCalStart = 0x5a5a;
    data.calSoftBrgNum = 1;
    data.calRfBrgIdx[0] = 0;
    retVal = DpdMsgSendRfBrgVswrPreStart(&data);
    return retVal;
}
/* Ended by AICoder, pid:ra86fkb3ffbdb6d14ddf0a09c05d8219cf83698f */

/* Started by AICoder, pid:n6a9ek86b2sdaaf147000a9850c8701bd0187041 */
UINT32 BspGetRfBrgVswrPreStartSta(void)
{
    T_DpdMsgRfBrgVswrPreStartStaAck data = {0};
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    retVal = DpdMsgGetRfBrgVswrPreStartSta(&data);
    dbgInfoEx("calSoftBrgNum = %d, calFinishSta %d\n", data.calSoftBrgNum, data.calFinishSta);
    for(loop = 0; loop < data.calSoftBrgNum; loop++)
    {
        dbgInfoEx("loop = %d, calRfBrgIdx = %d, calRfBrgResult = %d\n", loop,
                data.calRfBrgResult[loop].rfBrgIdx, data.calRfBrgResult[loop].rfBrgResult);
    }
    return retVal;
}
/* Ended by AICoder, pid:n6a9ek86b2sdaaf147000a9850c8701bd0187041 */

/* Started by AICoder, pid:dd3664062dn7a3d14d1a0b67c020c81a3bf52a92 */
UINT32 BspNotifyRfBrgDpdStartVswrTest(void)
{
    T_DpdMsgRfBridgeVswrCtrl data = {0};
    UINT32 retVal = BSP_OK;

    data.rfBrgVswrSmpStart = 0x5a5a;
    data.koSmpStartFrameId = 1;
    data.calSoftBrgNum = 1;
    data.msgVerify = 3;
    data.calRfBrgIdx[0] = 0;
    retVal = DpdMsgVswrStart_RfBridge(&data);
    return retVal;
}
/* Ended by AICoder, pid:dd3664062dn7a3d14d1a0b67c020c81a3bf52a92 */

/* Started by AICoder, pid:x9ea57cef50f9f514ca20901908f1417f2b999c5 */
UINT32 BspGetRfBrgVswrSpaTest(UINT32 chan)
{
    T_DpdMsgRfBridgeSpaCalcStaAck *data = NULL;
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    data = (T_DpdMsgRfBridgeSpaCalcStaAck *)malloc(sizeof(T_DpdMsgRfBridgeSpaCalcStaAck));
    INPUT_POINTER_CHECK(data);
    memset_s(data, sizeof(T_DpdMsgRfBridgeSpaCalcStaAck), 0, sizeof(T_DpdMsgRfBridgeSpaCalcStaAck));
    retVal = DpdMsgGetSpaVal_RfBridge(chan, data);
    dbgInfoEx("calcFinish = %d, chanIdx = %d, calcResult = %d, spaNum = %d\n", data->calcFinish, data->chanIdx, data->calcResult, data->spaNum);
    for(loop = 0; loop < data->spaNum; loop++)
    {
        dbgInfoEx("loop%d spaI = %d, spaQ = %d, nco = %d\n", loop, data->spaData[loop].spaI, data->spaData[loop].spaQ, data->spaData[loop].nco);
    }
    free(data);
    return retVal;
}
/* Ended by AICoder, pid:x9ea57cef50f9f514ca20901908f1417f2b999c5 */

/* Started by AICoder, pid:oa5fba79f2g6fac147cd0b65e06b591b4d234396 */
UINT32 BspGetRfBrgVswrCalcStaTest(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 sta = 0;
    UINT32 verify = 0;

    retVal = BspGetRfBridgeVswrCalcSta(&sta, &verify);
    dbgInfoEx("calcFinish = %d, verify = %d!\n", sta, verify);
    return retVal;
}
/* Ended by AICoder, pid:oa5fba79f2g6fac147cd0b65e06b591b4d234396 */

/* Started by AICoder, pid:s5621hbbeah86d114fdb08598070e3184319bc9f */
UINT32 BspSetRfBridgeAcCarrInfoTest1(UINT32 chnNo, UINT32 carrNo, UINT32 radioMode)
{
    T_RfBridgeVswrChanInfo info = {0};
    UINT32 retVal = BSP_OK;

    info.chnNo = chnNo;
    info.carrNum = 1;
    info.bridgeCarrInfo[0].carrType = 0;
    info.bridgeCarrInfo[0].carrNo = carrNo;
    info.bridgeCarrInfo[0].radioMode = radioMode;
    retVal = BspSetRfBridgeAcCarrInfo(0, 0, &info);
    return retVal;
}
/* Ended by AICoder, pid:s5621hbbeah86d114fdb08598070e3184319bc9f */

#include "msgproc.h"
#include "udpmsg_ic.h"
#include "exprn.h"

static UINT32 udpmsgresendcount = 3;

UINT32 SendHpiMsg(UINT16 chan, THpiApiPDU *pSend, THpiApiPDU *pRecv)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    for(loop = 0; loop < udpmsgresendcount; loop++)
    {
        retVal = BspUdpSocketMsgProc(HEAD_TYPE_ID_SOC_DSP,(TUdpMsgPDU *) pSend, (TUdpMsgPDU *)pRecv);
        if(retVal == BSP_OK)
        {
            break;
        }
    }
    if(loop == udpmsgresendcount)
    {
        dbgErr("[%s] udp msg proc fail! loop%d,Ret= 0x%04X,send msg 0x%04x, rev msg 0x%04x\n",
        __FUNCTION__,loop,retVal,pSend->head.msgType,pRecv->head.msgType);
    }
    return retVal;
}

UINT32 SendHpiMsgAcDsp(UINT16 chan, THpiApiPDU *pSend, THpiApiPDU *pRecv)
{
    UINT32 retVal = 0;
    UINT32 loop = 0;
    UINT32 typeId = HEAD_TYPE_ID_SOC_ACDSP;

#ifdef MULT_PROGRESS_S
    typeId = HEAD_TYPE_ID_NXP_ACDSP;
#endif

    for(loop = 0; loop < udpmsgresendcount; loop++)
    {
        retVal =  BspUdpSocketMsgProc(typeId, (TUdpMsgPDU *)pSend, (TUdpMsgPDU *)pRecv);
        dbgInfoEx("[%s]Addr %p, headInfo 0x%04X, count :0x%04X\n", __FUNCTION__, (void*)pRecv, pRecv->head.msgType, pRecv->msg.getdogCntAck.count);

        if(retVal == BSP_OK)
        {
            break;
        }
    }

    if(loop == udpmsgresendcount)
    {
        dbgErr("[%s] udp msg proc fail! loop%d,Ret= 0x%04X,send msg 0x%04x, rev msg 0x%04x\n",
        __FUNCTION__, loop, retVal, pSend->head.msgType, pRecv->head.msgType);
    }

    return retVal;
}

UINT32 SendHpiMsgAcDspIC(UINT32 chan, THpiApiPDU *pSend, THpiApiPDU *pRecv)
{
    UINT32 retVal = 0;
    UINT32 loop = 0;

    for(loop = 0; loop < udpmsgresendcount; loop++)
    {
        retVal =  BspUdpSocketMsgProc(HEAD_TYPE_ID_SOC_ACDSP, (TUdpMsgPDU *) pSend, (TUdpMsgPDU *)pRecv);
        dbgInfoEx("[%s]Addr %p, headInfo 0x%04X, count :0x%04X\n", __FUNCTION__, (void*)pRecv, pRecv->head.msgType, pRecv->msg.getdogCntAck.count);
        if(retVal == BSP_OK)
        {
            break;
        }
    }

    if(loop == udpmsgresendcount)
    {
        dbgErr("[%s] udp msg proc fail! loop%d,Ret= 0x%04X,send msg 0x%04x, rev msg 0x%04x\n",
        __FUNCTION__, loop, retVal, pSend->head.msgType, pRecv->head.msgType);
    }

    return retVal;
}

UINT32 BspUdpMsgProc(UINT32 typeId, UINT8 *ptDpdUdpSend, UINT8 *ptDpdUdpRecv)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 loop = 0;
    for(loop = 0; loop < udpmsgresendcount; loop++)
    {
        //coverity[cert_exp36_c_violation:SUPPRESS]
        ulRetVal = BspUdpSocketMsgProc(typeId, (TUdpMsgPDU *)ptDpdUdpSend, (TUdpMsgPDU *)ptDpdUdpRecv);
        if (BSP_OK == ulRetVal)
        {
            break;
        }
    }
    if(loop == udpmsgresendcount)
    {
        dbgErr("%s>>SocketId'%d DpdUdpMsg Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, ulRetVal);
        dbgErr("[%s] udp msg proc fail! loop%d,Ret= 0x%04X,send msg 0x%02x%02x, rev msg 0x%02x%02x\n",
    __FUNCTION__,loop,ulRetVal,ptDpdUdpSend[2],ptDpdUdpSend[3],ptDpdUdpRecv[2],ptDpdUdpRecv[3]);
    }
   return ulRetVal;
}

#include "hp_app.h"
#include "hp_msg.h"
#include "dpdapi.h"


UINT32 BspLoadAcHp(UINT32 ctrl)
{
    UINT32 ret = 0;

    if(SWITCH_ON == ctrl)
    {
        ret = DpdLoadAcHp(0, DPD_HOTLOAD);
    }
    else
    {
        ret = DpdLoadAcHp(0, DPD_HOTUNLOAD);
    }

    return ret;
}

UINT32 BspLoadDspHp(UINT32 ctrl)
{
    UINT32 ret = 0;

    if(SWITCH_ON == ctrl)
    {
        ret = DpdLoadDspHp(DPD_HOTLOAD);
    }
    else
    {
        ret = DpdLoadDspHp(DPD_HOTUNLOAD);
    }

    return ret;
}

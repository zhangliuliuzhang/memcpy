/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : ledctrl.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : LED点灯控制
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-2-22 09:54:30
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *------------regdrv----------------------------------------------------------------
 */
#include "bsppub.h"
#include "regdrv.h"
#include "ledctrl_a.h"
#include "vxadp.h"

#ifndef BSP_BIT
#define BSP_BIT(a)    (1 << (a))
#endif

#define KDA_PWM_RUN   0x4441002D
#define  LED_NORMAL     0
#define  LED_DISABLE    1

/* 记录过驻波的天线位图 多个通道公用一个VSWR灯，有一个通道点亮，这个灯就亮，所有通道灭，才灭 */
static UINT32 s_rfVswrMap = 0; 

UINT32 g_ulLedMask = LED_NORMAL;


#define LED_MAX_NUM       55

#define  LED_NORMAL     0
#define  LED_DISABLE    1


#define  LED_UNKNOW      0
#define  LED_RED        (1<<0)
#define  LED_GREEN      (1<<1)


UINT32 g_ulLedType[LED_MAX_NUM]={
		LED_UNKNOW,
		LED_GREEN,//0x1 BSP_LED_ID_RUN,GREEN
		LED_RED,//0x2 BSP_LED_ID_ALM
		(LED_RED|LED_GREEN),//0x3 BSP_LED_ID_LINK0
		(LED_RED|LED_GREEN),//0x4 BSP_LED_ID_LINK1
		(LED_RED|LED_GREEN),//0x5 BSP_LED_ID_LINK2
		(LED_RED|LED_GREEN),//0x6 BSP_LED_ID_LINK3
		LED_RED,//0x7 BSP_LED_ID_RF0/BSP_LED_ID_VSWR
		LED_RED,//0x8 BSP_LED_ID_RF1
		LED_RED,//0x9 BSP_LED_ID_RF2
		LED_RED,//0xa BSP_LED_ID_RF3
		LED_UNKNOW,//0xb
		LED_UNKNOW,//0xc
		LED_UNKNOW,//0xd
		LED_UNKNOW,//0xe
		LED_UNKNOW,//0xf
		LED_GREEN,//0x10 BSP_LED_ID_ACT,GREEN
		LED_GREEN,//0x11 BSP_LED_ID_RADIO 小区指示
		LED_UNKNOW,//0x12
		LED_UNKNOW,//0x13
		LED_GREEN, //0x14
		LED_UNKNOW,//0x15
		LED_UNKNOW,//0x16
		LED_RED,//0x17 BSP_LED_ID_RF4
		LED_RED,//0x18 BSP_LED_ID_RF5
		LED_RED,//0x19 BSP_LED_ID_RF6
		LED_RED,//0x1a BSP_LED_ID_RF7
		LED_RED,//0x1b BSP_LED_ID_RF8
		LED_RED,//0x1c BSP_LED_ID_RF9
        LED_RED,//0x1d BSP_LED_ID_RF10
        LED_RED,//0x1e BSP_LED_ID_RF11
        LED_RED,//0x1f BSP_LED_ID_RF12
        LED_RED,//0x20 BSP_LED_ID_RF13
        LED_RED,//0x21 BSP_LED_ID_RF14
        LED_RED,//0x22 BSP_LED_ID_RF15
        (LED_RED|LED_GREEN),//0x23 BSP_LED_ID_LINK4
        (LED_RED|LED_GREEN),//0x24 BSP_LED_ID_LINK5
        (LED_RED|LED_GREEN),//0x25 BSP_LED_ID_LINK6
        (LED_RED|LED_GREEN),//0x26 BSP_LED_ID_LINK7
        LED_RED,//0x27 BSP_LED_ID_RF16
        LED_RED,//0x28 BSP_LED_ID_RF17
        LED_RED,//0x29 BSP_LED_ID_RF18
        LED_RED,//0x2a BSP_LED_ID_RF19
        LED_RED,//0x2b BSP_LED_ID_RF20
        LED_RED,//0x2c BSP_LED_ID_RF21
        LED_RED,//0x2d BSP_LED_ID_RF22
        LED_RED,//0x2e BSP_LED_ID_RF23
        LED_RED,//0x2f BSP_LED_ID_RF24
        LED_RED,//0x30 BSP_LED_ID_RF25
        LED_RED,//0x31 BSP_LED_ID_RF26
        LED_RED,//0x32 BSP_LED_ID_RF27
        LED_RED,//0x33 BSP_LED_ID_RF28
        LED_RED,//0x34 BSP_LED_ID_RF29
        LED_RED,//0x35 BSP_LED_ID_RF30
        LED_RED,//0x36 BSP_LED_ID_RF31
};

UINT32 g_ulLedCtrlMask[LED_MAX_NUM]={0};

/**************************************************************************
 * 函数名称: LedIdIsSuport
 * 功能描述: 判断是否支持该LedId
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:  1：支持
 *           0：不支持
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 LedIdIsSuport(ULONG ulLedId)
{
    UINT32 loop = 0;
    UINT32 ledIdtable[] =
    {
            BSP_LED_ID_RUN,
            BSP_LED_ID_ALM,
            BSP_LED_ID_ACT,
            BSP_LED_ID_LINK0,
            BSP_LED_ID_LINK1,
            BSP_LED_ID_LINK2,
            BSP_LED_ID_LINK3,
            BSP_LED_ID_LINK4,
            BSP_LED_ID_LINK5,
            BSP_LED_ID_LINK6,
            BSP_LED_ID_LINK7,
            BSP_LED_ID_RF0 ,
            BSP_LED_ID_RF1 ,
            BSP_LED_ID_RF2 ,
            BSP_LED_ID_RF3 ,
            BSP_LED_ID_RF4 ,
            BSP_LED_ID_RF5 ,
            BSP_LED_ID_RF6 ,
            BSP_LED_ID_RF7 ,
            BSP_LED_ID_RF8 ,
            BSP_LED_ID_RF9 ,
            BSP_LED_ID_RF10,
            BSP_LED_ID_RF11,
            BSP_LED_ID_RF12,
            BSP_LED_ID_RF13,
            BSP_LED_ID_RF14,
            BSP_LED_ID_RF15,
            BSP_LED_ID_RF16,
            BSP_LED_ID_RF17,
            BSP_LED_ID_RF18,
            BSP_LED_ID_RF19,
            BSP_LED_ID_RF20,
            BSP_LED_ID_RF21,
            BSP_LED_ID_RF22,
            BSP_LED_ID_RF23,
            BSP_LED_ID_RF24,
            BSP_LED_ID_RF25,
            BSP_LED_ID_RF26,
            BSP_LED_ID_RF27,
            BSP_LED_ID_RF28,
            BSP_LED_ID_RF29,
            BSP_LED_ID_RF30,
            BSP_LED_ID_RF31,
            BSP_LED_ID_DPI,
    };

    UINT32 LedIdNum = NELEMENTS(ledIdtable);

    for(loop=0; loop<LedIdNum; loop++)
    {
        if(ulLedId == ledIdtable[loop])
        {
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述: 提供给高层接口，用于点灯，屏蔽红灯/绿灯
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
ULONG BspLedCtrlSetDisable(ULONG ulLedId,ULONG ulFlag)
{
	ULONG ulLedType=0;


	if(LedIdIsSuport(ulLedId) == BSP_OK)
	{
		g_ulLedCtrlMask[ulLedId] = ulFlag;
		ulLedType = g_ulLedType[ulLedId];
		/* led off */
		if(ulLedType == (LED_RED|LED_GREEN))
		{
			if(LED_DISABLE_RED & ulFlag)
			{
				BspLedCtrl(ulLedId,SWITCH_OFF_R);
			}
			if(LED_DISABLE_GREEN & ulFlag)
			{
				BspLedCtrl(ulLedId,SWITCH_OFF_G);
			}
		}
		else if((ulLedType==LED_RED)&&(ulFlag&LED_DISABLE_RED))
		{
			BspLedCtrl(ulLedId,SWITCH_OFF);
		}
		else if((ulLedType==LED_GREEN)&&(ulFlag&LED_DISABLE_GREEN))
		{
			BspLedCtrl(ulLedId, SWITCH_OFF);
		}
		else if(ulFlag==LED_ENABLE)
		{
			dbgInfoEx("%s %d %d led enable\n", __FUNCTION__, __LINE__, ulLedId);
		}
		else
		{
			dbgErr("%s %d %d param error\n", __FUNCTION__, __LINE__, ulLedId);
		}
		return BSP_OK;
	}
	else
	{
		dbgErr("%s %d %d param error\n", __FUNCTION__, __LINE__, ulLedId);
		return BSP_ERROR;
	}
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述: 内部接口，用于屏蔽OSS点灯的接口
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
ULONG BspLedCtrlGetDisable(ULONG ulLedId, ULONG ulOperation)
{
	ULONG ulFlag=0;
	ULONG ulLedType=0;


	if(LedIdIsSuport(ulLedId) == BSP_OK)
	{
		ulFlag = g_ulLedCtrlMask[ulLedId] ;
		ulLedType = g_ulLedType[ulLedId];

		/* led off */
		if(ulLedType == (LED_RED|LED_GREEN))
		{
			if((LED_DISABLE_RED&ulFlag)&&(SWITCH_ON_R==ulOperation))
			{
				return LED_DISABLE;
			}
			if((LED_DISABLE_GREEN&ulFlag)&&(SWITCH_ON_G==ulOperation))
			{
				return LED_DISABLE;
			}
		}
		else if((ulLedType==LED_RED)&&(ulFlag&LED_DISABLE_RED)&&(SWITCH_ON==ulOperation))
		{
			return LED_DISABLE;
		}
		else if((ulLedType==LED_GREEN)&&(ulFlag&LED_DISABLE_GREEN)&&(SWITCH_ON==ulOperation))
		{
			return LED_DISABLE;
		}
		return LED_NORMAL;

	}
	return BSP_ERROR;
}


typedef UINT32 (*pPwmCtrlFunc)(UINT32 ulSwitch);

pPwmCtrlFunc pPwmCtrlCall = NULL;

#ifdef BUILD_WITH_OM_FUNC
UINT32 BspPwmCtrlCall(pPwmCtrlFunc pSetPwmCtrlCall)
{
	pPwmCtrlCall = pSetPwmCtrlCall;
   return BSP_OK;
}

#endif

/*****************************************************************************
*  函数名称   : PwmLedCtrl(*)
*  功能描述   :PMW点灯控制
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : flag：0-关闭PMW点灯，1-打开PMW点灯
*  输出参数   : 无
*  返 回 值   : BSP_OK 成功,BSP_ERROR 出错
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 陈溪溪@2018-11-01 11:14:27 创建
*----------------------------------------------------------------------------
*/
UINT32 PwmLedCtrl_dra62x(UINT32 flag)
{
	int iLedFd = getKdaFd();

	if(-1 != iLedFd)
	{
		if(ioctl(iLedFd, KDA_PWM_RUN, flag) < 0)
		{
		    dbgInfo("%s ioctl kda pwm error!\n",__FUNCTION__);
		}
	}
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspLedInit(*)
*  功能描述   :LED初始化配置，关闭PMW点灯
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK 成功,BSP_ERROR 出错
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 陈溪溪@2018-11-01 11:14:27 创建
*----------------------------------------------------------------------------
*/
UINT32  BspLedInit(VOID)
{
	if(pPwmCtrlCall != NULL)
	{
		pPwmCtrlCall(SWITCH_OFF);
	}

    return BSP_OK;
}

/**************************************************************************
* 函数名称: SetLed?(*)
* 功能描述:
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2017年2月22日 10090699   创建
**************************************************************************/
static UINT32 SetLedRun(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_RUN, isOn);
}

static UINT32 SetLedRunSlowFlash(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_RUN_SLOW, isOn);
}

static UINT32 SetLedAlm(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_ALM, isOn);
}

static UINT32 SetLedVswr(UINT32 isOn)
{
    dbgInfoEx ("%s  isOn = 0x%x\n",__FUNCTION__,isOn);
    return BspRegPinWr(REG_LED_VSWR, isOn);
}

static UINT32 SetLedDpi(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_DPI, isOn);
}

static UINT32 SetLedAct(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_ACT, isOn);
}

static UINT32 SetLedOpt0Green(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT0_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_OPT0_GREEN, isOn);
}

static UINT32 SetLedOpt0Red(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT0_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_OPT0_RED, isOn);
}

static UINT32 SetLedOpt1Green(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT1_CPUEN, ENABLE); 
    return BspRegPinWr(REG_LED_OPT1_GREEN, isOn);
}

static UINT32 SetLedOpt1Red(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT1_CPUEN, ENABLE); 
    return BspRegPinWr(REG_LED_OPT1_RED, isOn);
}

static UINT32 SetLedOpt2Green(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT2_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_OPT2_GREEN, isOn);
}

static UINT32 SetLedOpt2Red(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT2_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_OPT2_RED, isOn);
}
static UINT32 SetLedOpt3Green(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT3_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_OPT3_GREEN, isOn);
}

static UINT32 SetLedOpt3Red(UINT32 isOn)
{
    BspRegPinWr(REG_LED_OPT3_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_OPT3_RED, isOn);
}


static UINT32 SetLedRgpsGreen(UINT32 isOn)
{
    BspRegPinWr(REG_LED_RGPS_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_RGPS_GREEN, isOn);
}

static UINT32 SetLedRgpsRed(UINT32 isOn)
{
    BspRegPinWr(REG_LED_RGPS_CPUEN, ENABLE);
    return BspRegPinWr(REG_LED_RGPS_RED, isOn);
}

static UINT32 SetLedLteGreen(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_LTE_GREEN, isOn);
}

static UINT32 SetLedLteRed(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_LTE_RED, isOn);
}

static UINT32 SetLedNrGreen(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_NR_GREEN, isOn);
}

static UINT32 SetLedNrRed(UINT32 isOn)
{
    return BspRegPinWr(REG_LED_NR_RED, isOn);
}

static UINT32 LedRunCtrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    /* A9631A规格RUNLED支持点灯透传和慢闪模式, 透传
       模式下慢闪需关闭; 慢闪模式下透传模式无需关心 */
    switch (state)
    {
        case SWITCH_OFF:
        {
        //  SetLedRunSlowFlash(SWITCH_OFF);
            SetLedRun(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
        //  SetLedRunSlowFlash(SWITCH_OFF);
            SetLedRun(SWITCH_ON);
            break;
        }
        case SWITCH_OFF_SLOW_FLASH:
        {
            SetLedRunSlowFlash(SWITCH_OFF);
            break;
        }
        case SWITCH_ON_SLOW_FLASH:
        {
            SetLedRunSlowFlash(SWITCH_ON);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}

static UINT32 LedOpt0Ctrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    switch (state)
    {
        case SWITCH_OFF:
        {
            SetLedOpt0Green(SWITCH_OFF);
            SetLedOpt0Red(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
            SetLedOpt0Green(SWITCH_ON);
            SetLedOpt0Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_R:
        {
            SetLedOpt0Green(SWITCH_OFF);
            SetLedOpt0Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_G:
        {
            SetLedOpt0Green(SWITCH_ON);
            SetLedOpt0Red(SWITCH_OFF);
            break;
        }
        case SWITCH_OFF_R:
        {
            SetLedOpt0Red(SWITCH_OFF);
            break;
        }
        case SWITCH_OFF_G:
        {
            SetLedOpt0Green(SWITCH_OFF);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}

static UINT32 LedOpt1Ctrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    switch (state)
    {
        case SWITCH_OFF:
        {
            SetLedOpt1Green(SWITCH_OFF);
            SetLedOpt1Red(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
            SetLedOpt1Green(SWITCH_ON);
            SetLedOpt1Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_R:
        {
            SetLedOpt1Green(SWITCH_OFF);
            SetLedOpt1Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_G:
        {
            SetLedOpt1Green(SWITCH_ON);
            SetLedOpt1Red(SWITCH_OFF);
            break;
        }
        case SWITCH_OFF_R:
        {
            SetLedOpt1Red(SWITCH_OFF);
            break;
        }
        case SWITCH_OFF_G:
        {
            SetLedOpt1Green(SWITCH_OFF);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}

static UINT32 LedOpt2Ctrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    switch (state)
    {
        case SWITCH_OFF:
        {
            SetLedOpt2Green(SWITCH_OFF);
            SetLedOpt2Red(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
            SetLedOpt2Green(SWITCH_ON);
            SetLedOpt2Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_R:
        {
            SetLedOpt2Green(SWITCH_OFF);
            SetLedOpt2Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_G:
        {
            SetLedOpt2Green(SWITCH_ON);
            SetLedOpt2Red(SWITCH_OFF);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}

static UINT32 LedOpt3Ctrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    switch (state)
    {
        case SWITCH_OFF:
        {
            SetLedOpt3Green(SWITCH_OFF);
            SetLedOpt3Red(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
            SetLedOpt3Green(SWITCH_ON);
            SetLedOpt3Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_R:
        {
            SetLedOpt3Green(SWITCH_OFF);
            SetLedOpt3Red(SWITCH_ON);
            break;
        }
        case SWITCH_ON_G:
        {
            SetLedOpt3Green(SWITCH_ON);
            SetLedOpt3Red(SWITCH_OFF);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}


static UINT32 LedRgpsCtrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    switch (state)
    {
        case SWITCH_OFF:
        {
            SetLedRgpsGreen(SWITCH_OFF);
            SetLedRgpsRed(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
            SetLedRgpsGreen(SWITCH_ON);
            SetLedRgpsRed(SWITCH_ON);
            break;
        }
        case SWITCH_ON_R:
        {
            SetLedRgpsGreen(SWITCH_OFF);
            SetLedRgpsRed(SWITCH_ON);
            break;
        }
        case SWITCH_ON_G:
        {
            SetLedRgpsGreen(SWITCH_ON);
            SetLedRgpsRed(SWITCH_OFF);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}
static UINT32 LedLteCtrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    switch (state)
    {
        case SWITCH_OFF:
        {
            SetLedLteGreen(SWITCH_OFF);
            SetLedLteRed(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
            SetLedLteGreen(SWITCH_ON);
            SetLedLteRed(SWITCH_ON);
            break;
        }
        case SWITCH_ON_R:
        {
            SetLedLteGreen(SWITCH_OFF);
            SetLedLteRed(SWITCH_ON);
            break;
        }
        case SWITCH_ON_G:
        {
            SetLedLteGreen(SWITCH_ON);
            SetLedLteRed(SWITCH_OFF);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}

static UINT32 LedNrCtrl(UINT32 state)
{
    UINT32 retVal = BSP_OK;

    switch (state)
    {
        case SWITCH_OFF:
        {
            SetLedNrGreen(SWITCH_OFF);
            SetLedNrRed(SWITCH_OFF);
            break;
        }
        case SWITCH_ON:
        {
            SetLedNrGreen(SWITCH_ON);
            SetLedNrRed(SWITCH_ON);
            break;
        }
        case SWITCH_ON_R:
        {
            SetLedNrGreen(SWITCH_OFF);
            SetLedNrRed(SWITCH_ON);
            break;
        }
        case SWITCH_ON_G:
        {
            SetLedNrGreen(SWITCH_ON);
            SetLedNrRed(SWITCH_OFF);
            break;
        }
        default:
        {
            break;
        }
    }

    return retVal;
}
static UINT32 LedVswrCtrl(UINT32 ledName, UINT32 operation)
{
    UINT32 rfAnt = 0;
    if(ledName <= BSP_LED_ID_RF3)
    {
        rfAnt = ledName - BSP_LED_ID_RF0;
    }
    else if (ledName <= BSP_LED_ID_RF15)
    {
        rfAnt = ledName - BSP_LED_ID_RF4 + 4;
    }
    else
    {
        rfAnt = ledName - BSP_LED_ID_RF16 + 16;
    }

    /* 仅支持最多32天线 */
    s_rfVswrMap = (operation == SWITCH_ON) ? (s_rfVswrMap|BSP_BIT(rfAnt)) :(s_rfVswrMap& (~BSP_BIT(rfAnt)));
    dbgInfoEx("%s s_rfVswrMap = 0x%x\n",__FUNCTION__,s_rfVswrMap);
    SetLedVswr(s_rfVswrMap ? SWITCH_ON : SWITCH_OFF);

    return BSP_OK;
}


static UINT32 g_ulLedSwitchCtrl = 0;
#define LED_CTRL_SWITCH_FLAG  (0x5a5a5a5a)

UINT32 BspSwitchLedToDefState(UINT32 uSwitch)
{
	/* UINT32  ulTxChan = 0; */
    if(SWITCH_OFF == uSwitch)
    {
    	g_ulLedSwitchCtrl = 0;
    }
    else
    {
    	g_ulLedSwitchCtrl = LED_CTRL_SWITCH_FLAG;
    	/* 除了RUN/ALARM灯外，都置为灭状态 */
    	LedOpt0Ctrl(SWITCH_OFF);/* opt 0 */
    	LedOpt1Ctrl(SWITCH_OFF);/* opt 1 */
    	LedOpt2Ctrl(SWITCH_OFF);/* opt 2 */
        LedOpt3Ctrl(SWITCH_OFF);/* opt 3 */
    	SetLedVswr(SWITCH_OFF);/* 驻波灯 */
    	SetLedAct(SWITCH_OFF); /* act */
    	LedRgpsCtrl(SWITCH_OFF); /* act */
    }

    return BSP_OK;
}

VOID BspCloseLedVswr(VOID)
{
    SetLedVswr(SWITCH_OFF);/* 驻波灯 */
}

UINT32 BspDisableLedCtrl()
{
	g_ulLedMask = LED_DISABLE;
	return BSP_OK;
}

UINT32 BspRecoverLedCtrl()
{
	g_ulLedMask = LED_NORMAL;
	return BSP_OK;
}
UINT32 BspLedGetDisable()
{
	return g_ulLedMask;
}
UINT32 BspGetLedCtrlSwitch()
{
	if(LED_CTRL_SWITCH_FLAG == g_ulLedSwitchCtrl)
	{
		return SWITCH_OFF;
	}
	else
	{
		return SWITCH_ON;
	}
}

static UINT32 SetVswrLedCtrl(UINT32 ledName, UINT32 operation)
{
    UINT32 retVal = BSP_OK;

    if ((ledName <= BSP_LED_ID_RF3) || ((ledName >= BSP_LED_ID_RF4) && (ledName <= BSP_LED_ID_RF15)) || ((ledName >= BSP_LED_ID_RF16) && (ledName <= BSP_LED_ID_RF31)))
    {
        dbgInfoEx("%s>> set chan[%d]vswr led ctrl[%d]\r\n",__func__,ledName,operation);
        retVal = LedVswrCtrl(ledName, operation);
    }
    else
    {
        dbgErr("%s: The led device is not exist, ledName = %x\n", __FUNCTION__, ledName);
        retVal = BSP_ERROR_DEVICE_NOT_EXIST;
    }

    return retVal;
}

UINT32 SetLedStatus(UINT32 ledName, UINT32 operation)
{
    switch (ledName)
    {
        case BSP_LED_ID_RUN: /* LedRun */
        {
            LedRunCtrl(operation);
            break;
        }
        case BSP_LED_ID_ALM: /* LedAlm */
        {
            SetLedAlm(operation);
            break;
        }
        case BSP_LED_ID_LINK0:  /*OPT0*/
        {
            LedOpt0Ctrl(operation);
            break;
        }
        case BSP_LED_ID_LINK1:  /*OPT1*/
        {
            LedOpt1Ctrl(operation);
            break;
        }
        case BSP_LED_ID_LINK2:  /*OPT2*/
        {
            LedOpt2Ctrl(operation);
            break;
        }
        case BSP_LED_ID_LINK3:  /*OPT3*/
        {
            LedOpt3Ctrl(operation);
            break;
        }
        case BSP_LED_ID_ACT:  /*ACT*/
        {
            SetLedAct(operation);
            /*TrackPrn(TPRN_MOD_OTHER,"ACT led %s\n",(SWITCH_ON==ulOperation)?"on":"off");*/
            break;
        }
        case BSP_LED_ID_RGPS:  /*RGPS*/
        {
            LedRgpsCtrl(operation);
            break;
        }
        case BSP_LED_ID_CELL_M:  /*LTE*/
        {
            LedLteCtrl(operation);
            break;
        }
        case BSP_LED_ID_CELL_S:  /*NR*/
        {
            LedNrCtrl(operation);
            break;
        }
        case BSP_LED_ID_DPI:  /*NR*/
        {
            SetLedDpi(operation);
            break;
        }
        default:
        {
            return SetVswrLedCtrl(ledName,operation);
        }
    }

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspLedCtrl(*)
* 功能描述: LED控制
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2017年2月22日 10090699   创建
**************************************************************************/
UINT32 BspLedCtrl(UINT32 ledName, UINT32 operation)
{   
    UINT32 ret = BSP_ERROR;


    /* 在软复位前，将LED灯控制开关关闭，然后将灯置为默认态 */
    if ((ledName != BSP_LED_ID_RUN) && (ledName != BSP_LED_ID_ALM))
    {
        if (SWITCH_OFF == BspGetLedCtrlSwitch())
        {
            return BSP_OK;
        }
    }

    if(LED_DISABLE == BspLedGetDisable())
    {
    	dbgInfoEx("Led OperationFlag Disable!!!\n");
        return BSP_OK;
    }
    if(LED_DISABLE == BspLedCtrlGetDisable(ledName,operation))
    {
    	dbgInfoEx("Led OperationFlag Disable，OMC in ctrl!!!\n");
        return BSP_OK;
    }
    
    ret = SetLedStatus(ledName, operation);

    return ret;
}


/**************************************************************************
* 函数名称: BspLedCtrl_Ntf(*)
* 功能描述: LED控制
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2017年2月22日 10090699   创建
**************************************************************************/
UINT32 BspLedCtrl_Ntf(UINT32 ledName, UINT32 operation)
{
    return SetLedStatus(ledName, operation);
}

/**************************************************************************
* 函数名称: BspLedCtrl_NCR(*)
* 功能描述: LED控制
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 2017年2月22日 10090699   创建
**************************************************************************/
UINT32 BspLedCtrl_NCR(UINT32 ledName, UINT32 operation)
{
    return SetLedStatus(ledName, operation);
}

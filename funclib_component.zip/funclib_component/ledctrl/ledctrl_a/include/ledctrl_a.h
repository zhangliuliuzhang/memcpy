/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : ledctrl.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供LED点灯接口
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-2-22 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#ifndef _FUNCLIB_LEDCTRL_H_
#define _FUNCLIB_LEDCTRL_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "ledctrlapi.h"

UINT32 BspLedInit(VOID);
UINT32 PwmLedCtrl_dra62x(UINT32 flag);
ULONG  BspLedCtrlSetDisable(ULONG ulLedId,ULONG ulFlag);
ULONG  BspLedCtrlGetDisable(ULONG ulLedId, ULONG ulOperation);
UINT32 BspSwitchLedToDefState(UINT32 uSwitch);
VOID   BspCloseLedVswr(VOID);
UINT32 SetLedStatus(UINT32 ledName, UINT32 operation);
UINT32 BspLedCtrl_Ntf(UINT32 ledName, UINT32 operation);
UINT32 BspLedCtrl_NCR(UINT32 ledName, UINT32 operation);

#ifdef __cplusplus
}
#endif

#endif


/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rruability_tdd.c
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 : wangfei10102065
* 创建日期 : 2018-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei10102065
* 修改日戳: 2018-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "rruability_tdd.h"
#include "funccommonapi.h"
#include "rruinfo.h"
#include "exprn.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/


/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
T_RruAbilityInfo s_rruAbilityInfo[] =
{
    {BSP_FU_RU_SUPP_RADIOMODE       ,BspGetFuRuSuppRadioMode },
    {BSP_FU_RU_9BITCOMPRESS         ,BspGetFuRu9BitComperess },
    {BSP_FU_RU_LTE_UPDELAY          ,BspGetFuRuUpDeleyAbilty },
    {BSP_FU_RU_CARR_CAP             ,BspGetRruCarrRangeCapture},/*RU支持的载波号范围信息*/
    {BSP_FU_RU_PA_BASE_INFO,         BspGetRuPaBaseInfo},

};

static T_RruChanAbilityInfo s_rruChnAbilityInfo[] =
{
    {BSP_FU_RUCHL_CARRIER           ,BspGetFuTddRuChanCarrier   },
};

T_RruSpecialAbilityInfo rruSpAbilityInfo[] =
{
    {BSP_FU_RU_VSWR_POS_ONLINE      , BspGetVswrPosOnlineDetectAbility },
    {BSP_FU_RU_DIG_PHASE_SHIFT_ALM  , BspGetDigitalPhaseShifterAlarmAbility},
    {BSP_FU_RU_PWR_ONOFF_AVOID,       BspGetPwrAutoOnOffAbilit},
    {BSP_FU_RU_IF0_IF1_SPLIT        , BspGetIF0IF1SplitAbility},
    {BSP_FU_RU_MAX_POW_LIMIT        , BspGetRruMaxPowLimitAbility},
    {BSP_FU_RU_SUPPORT_VSWR_DERATING, BspGetSupportVswrDeratingAbility},
};

static UINT32 s_rruCarrNumCfg[RADIOMODE_INDEX_MAX]={0};
static UINT32 s_supportRadioMode     = 0;/* 支持的工作制式 */
static UINT32 s_support9BitCompress  = 0;
static UINT32 s_ulDelayCmp           = OPT_FIBER_BUFF_ABILITY_20KM;
static UINT32 s_supportVswrPosOnlineDetection = 0; /* 支持在线驻波位置检测标志, 1:支持, 0:不支持 */
static UINT32 s_supportVswrGateReset = 0;/* 支持驻波门限重置标志, 1:支持, 0:不支持 */
static T_RruFreqIdCaCap *s_pRruCarrRangeCap = NULL;  /*RRU支持的载波号范围信息上报*/
static T_RruFreqIdCaCap s_rruCarrRangeCapInfo = {0};
static UINT32 s_supportDigitalPhaseShifterAlarm = 0; /* 支持数字移相器告警, 1:支持, 0:不支持 */
static INT32 s_pwrOffLowestTemp = 150;
static UINT32 s_suppPwrAvoidFlag = NO_SUPP_PWR_AUTO_ON_OFF_AVOID;
static UINT32 s_suppPllAvoidFlag = NO_SUPP_PWR_AUTO_ON_OFF_AVOID;
/*默认值设置为 非R9614 S26/R9614E M1826/R9626E M1826外的其他平台机型的情况*/
static UINT32 s_supportIF0IF1Flag = SUPPORT_IF0_ONLY;   /*其他机型支持IF0 不支持IF1*/
static UINT32 s_supportSampleRate = SUPPORT_ALLRATE_ALLBANDWIDTH; /*其余机型支持IF0全部采样率*/
static UINT32 s_supportMaxPowLimitFlag = NO_SUPPORT; /* RRU整机是否支持最大功耗限制, 1:支持, 0:不支持 */
static INT32 s_maxPowMw = 5000000;                   /* 最大限制功耗 单位 mw 默认值5000W */
static UINT32 s_supportVswrDerating = 0;             /* 支持变更过驻波降额策略, 1:支持, 0:不支持 */
static INT32 s_vswrDeratingThre = 30;                /* 驻波降额门限，单位0.1 */
static INT32 s_vswrRecoveryThre = 20;                /* 驻波恢复门限，单位0.1 */

/**************************************************************************
 * 函数名称: BspGetRruSupportRadioMode
 * 功能描述: 获取RRU支持的制式
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruSupportRadioMode(VOID)
{
    return s_supportRadioMode;
}
/**************************************************************************
 * 函数名称: BspSetRruSupportRadioMode
 * 功能描述: 设置RRU支持的制式
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruSupportRadioMode(UINT32 supportRadioMode)
{
    s_supportRadioMode = supportRadioMode;
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuSuppRadioMode (*)
*  功能描述   : 获取SuppRadioMode整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuSuppRadioMode(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuSupportRadioMode     fuRuSupportRadioMode = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuSupportRadioMode))
    {
        return BSP_ERROR;
    }
    memset(&fuRuSupportRadioMode, 0,sizeof(T_BspFuRuSupportRadioMode));

    fuRuSupportRadioMode.usSupportRadioMode = (UINT16)BspGetRruSupportRadioMode();

    memcpy(pRruAbilityFuInfo,&fuRuSupportRadioMode,sizeof(T_BspFuRuSupportRadioMode));
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetRruSupport9BitCompress
 * 功能描述: 获取RRU 支持9bit压缩
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruSupport9BitCompress(VOID)
{
    return s_support9BitCompress;
}
/**************************************************************************
 * 函数名称: BspSetRruSupport9BitCompress
 * 功能描述: RRU 9bit压缩
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruSupport9BitCompress (UINT32 support9BitCompress)
{
    s_support9BitCompress  = support9BitCompress;

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRu9BitComperess (*)
*  功能描述   : 获取9BitComperess整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRu9BitComperess(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRu9BitCompress   fuRu9BitCompress = {0};;
    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRu9BitCompress))
    {
        return BSP_ERROR;
    }
    memset(&fuRu9BitCompress,0,sizeof(T_BspFuRu9BitCompress));
    /*是否支持9bit压缩 0-不支持，1-支持*/
    fuRu9BitCompress.ucSupport9BitCompress = BspGetRruSupport9BitCompress();
    memcpy(pRruAbilityFuInfo,&fuRu9BitCompress,sizeof(T_BspFuRu9BitCompress));
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetCarrNumCfg
*  功能描述   :
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-04-02 18:33:43 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetCarrNumCfg(UINT32 radioType)
{
    return s_rruCarrNumCfg[radioType];
}
/*****************************************************************************
*  函数名称   : BspSetCarrNumCfg
*  功能描述   : 判断类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-04-02 18:33:43 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetCarrNumCfg(UINT32 radioType, UINT32 carrNum)
{
    s_rruCarrNumCfg[radioType] = carrNum;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetCarrierNumbyRadio
 * 功能描述: RRU 获取带宽信息
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/
UINT32 BspGetCarrierNumbyRadio(BYTE chan,BYTE dir,T_BspFuRuChlCarrier *pFuRuChlCarrier )
{
    
    UINT32 freqBand = 0;    
    
    if(NULL == pFuRuChlCarrier)
    {
        return BSP_ERROR;
    }
    
    freqBand = BspGetFreqArea(chan,dir);/*各个频段*/
    dbgInfoEx("%s: freqBand: %d\n", __FUNCTION__, freqBand);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_UMTS_INDEX]        = BspGetCarrNumCfg(RADIOMODE_UMTS_INDEX);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_GSM_INDEX]         = BspGetCarrNumCfg(RADIOMODE_GSM_INDEX);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_TDS_INDEX]         = BspGetCarrNumCfg(RADIOMODE_TDS_INDEX);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_CDMA_INDEX]        = BspGetCarrNumCfg(RADIOMODE_CDMA_INDEX);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_LTE_FDD_INDEX]     = BspGetCarrNumCfg(RADIOMODE_LTE_FDD_INDEX);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_LTE_TDD_INDEX]     = BspGetCarrNumCfg(RADIOMODE_LTE_TDD_INDEX);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_NBIOT_INDEX]       = BspGetCarrNumCfg(RADIOMODE_NBIOT_INDEX);
    pFuRuChlCarrier->aucChlCarriNum[RADIOMODE_NR_INDEX]          = BspGetCarrNumCfg(RADIOMODE_NR_INDEX);

    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspGetFuRuChanCarrier (*)
*  功能描述   : 获取RU 载波能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuTddRuChanCarrier(UINT32 chan,UINT32 dir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuChlCarrier           fuRuChlCarrier = {0};
    /* UINT32 retVal = BSP_OK; */
    if(dataLen < sizeof(T_BspFuRuChlCarrier))
    {
        return BSP_ERROR;
    }
    memset(&fuRuChlCarrier,0,sizeof(T_BspFuRuChlCarrier));
    BspGetCarrierNumbyRadio(chan,dir,&fuRuChlCarrier);
    memcpy(pRruChlAbilityFuInfo,&fuRuChlCarrier,sizeof(T_BspFuRuChlCarrier));

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspGetUlDelayCmpAbility
 * 功能描述: 获取RRU 支持上行时延补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetUlDelayCmpAbility(VOID)
{
    return s_ulDelayCmp;
}

/**************************************************************************
 * 函数名称: BspSetUlDelayCmpAbility
 * 功能描述: RRU 上行时延补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetUlDelayCmpAbility(UINT32 ulDelayCmpIc,UINT32 ulDelayCmpFpga)
{
    if(ulDelayCmpFpga == DELAY_CMP_FUNC_NOT_SUPPORT)
    {
        s_ulDelayCmp  = ulDelayCmpIc;
        return BSP_OK;
    }
    else if(ulDelayCmpIc == DELAY_CMP_FUNC_NOT_SUPPORT)
    {
        s_ulDelayCmp  = ulDelayCmpFpga;
        return BSP_OK;
    }
    /*FPGA和IC 时延当中按照最小范围的上报*/
    s_ulDelayCmp = (ulDelayCmpIc <=ulDelayCmpFpga) ? ulDelayCmpIc : ulDelayCmpFpga;
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuUpDeleyAbilty (*)
*  功能描述   : 获取RU UpDeleyAbilty整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuUpDeleyAbilty(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuLteUpDelayAbility    fuRuLteUpDelayAbility = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    /* 上行时延能力上报 */
    if(dataLen < sizeof(T_BspFuRuLteUpDelayAbility))
    {
        return BSP_ERROR;
    }
    memset(&fuRuLteUpDelayAbility, 0, sizeof(T_BspFuRuLteUpDelayAbility));
    /* 需要根据实际情况填写从FPGA中获取的时延上报能力 */
    fuRuLteUpDelayAbility.ulRuLteUpDelayAbility = BspGetUlDelayCmpAbility();
    memcpy(pRruAbilityFuInfo,&fuRuLteUpDelayAbility,sizeof(T_BspFuRuLteUpDelayAbility));
    return BSP_OK;
}


UINT32 BspInitRruChlAblityPara(VOID)
{
    UINT32 rruChnRruAbilityNum = 0;
    UINT32 retVal = BSP_OK;    

    rruChnRruAbilityNum = NELEMENTS(s_rruChnAbilityInfo);
    retVal = BspSetRruChnAbilityInfo(s_rruChnAbilityInfo,rruChnRruAbilityNum);

    return retVal;
}

UINT32 BspInitRruAbilityPara(VOID)
{
    UINT32 rruRruAbilityNum = 0;
    UINT32 retVal = BSP_OK;

    rruRruAbilityNum = NELEMENTS(s_rruAbilityInfo);
    retVal = BspSetRruAbilityInfo(s_rruAbilityInfo,rruRruAbilityNum);

    return retVal;
}

UINT32 BspInitRruSpecialAbilityPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 rruSpecialAbilityNum = 0;

    rruSpecialAbilityNum = NELEMENTS(rruSpAbilityInfo);
    retVal = BspSetRruSpecialAbilityInfo(rruSpAbilityInfo, rruSpecialAbilityNum);

    return retVal;
}

UINT32 BspInitRruAbilityInfo(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal |= BspInitRruChlAblityPara();    
    retVal |= BspInitRruAbilityPara();
    retVal |= BspInitRruSpecialAbilityPara();

    return retVal;
}
/********************************************************************
*  函数名称   : BspInitRruAbilityFunc (*)
*  功能描述   : 初始化rru 能力上报模块
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/

UINT32 BspInitRruAbilityFunc(VOID)
{
    return BspInitRruAbilityInfo();
}

/*****************************************************************************
*  函数名称   : BspAdpGetBoardInputAisgVolt
*  功能描述   : 获取单板AISG输入电压
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulPwrType
*  输出参数   : 无
*  返 回 值   : 成功或者失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
UINT32 BspAdpGetBoardInputAisgVolt(UINT32 ulPwrType)
{
    T_HwInfo *ptInfo = NULL;

    if( ulPwrType >= AISG_PWR_NUM )
    {
        return INVALID_VALUE;
    }

    ptInfo = (T_HwInfo*)BspGetGlobalRruHwInfo();

    return ptInfo->BoardInfo.aulInputAisgVolt[ulPwrType];
}

/**************************************************************************
 * 函数名称 : BspSetVswrPosOnlineDetectionAbility
 * 功能描述 : 设置RRU支持在线驻波位置检测能力
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetVswrPosOnlineDetectionAbility(UINT32 supportFlag)
{
    s_supportVswrPosOnlineDetection = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetVswrPosOnlineDetectionAbility
 * 功能描述: 获取RRU支持在线驻波位置检测能力
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetVswrPosOnlineDetectionAbility(VOID)
{
    return s_supportVswrPosOnlineDetection;
}

/**************************************************************************
 * 函数名称 : BspSetVswrGateResetFlag
 * 功能描述 : 设置RRU支持驻波门限重置能力
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetVswrGateResetFlag(UINT32 supportFlag)
{
    s_supportVswrGateReset = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetVswrGateResetFlag
 * 功能描述: 获取RRU支持驻波门限重置能力
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetVswrGateResetFlag(VOID)
{
    return s_supportVswrGateReset;
}
/********************************************************************
*  函数名称   : BspGetVswrPosOnlineDetectAbility
*  功能描述   : 获取整机支持在线驻波位置检测和驻波门限重置能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetVswrPosOnlineDetectAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportVswrPosOnlineDetect fuRuSupportVswrPosOnlineDetect = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportVswrPosOnlineDetect))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportVswrPosOnlineDetect, sizeof(T_BspFuRuSupportVswrPosOnlineDetect), 0, sizeof(T_BspFuRuSupportVswrPosOnlineDetect));
    fuRuSupportVswrPosOnlineDetect.usSupportVswrPosOnlineDetect = (UINT16)BspGetVswrPosOnlineDetectionAbility();
    fuRuSupportVswrPosOnlineDetect.usSupportVswrGateReset = (UINT16)BspGetVswrGateResetFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportVswrPosOnlineDetect, sizeof(T_BspFuRuSupportVswrPosOnlineDetect));

    return BSP_OK;
}

UINT32 BspSetRruCarrRangeCapture(T_RruFreqIdCaCap *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    s_pRruCarrRangeCap = pPara;
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruCarrRangeCapture
*  功能描述   : 获取RRU支持的载波号范围信息
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRruCarrRangeCapture(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    if (pvRruAbilityFuInfo == NULL)
    {
        dbgErr("[%s] Get Carr Range Failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(dataLen < sizeof(T_RruFreqIdCaCap))
    {
        return BSP_ERROR;
    }
    if (s_pRruCarrRangeCap == NULL)
    {
        dbgInfoEx("[%s] Get Carr Range Failed1\n", __FUNCTION__);
        memcpy_s(pvRruAbilityFuInfo, sizeof(T_RruFreqIdCaCap), &s_rruCarrRangeCapInfo, sizeof(T_RruFreqIdCaCap));
        return BSP_OK;
    }

    memcpy_s(pvRruAbilityFuInfo, sizeof(T_RruFreqIdCaCap), s_pRruCarrRangeCap, sizeof(T_RruFreqIdCaCap));

    return BSP_OK;
}
/* Started by AICoder, pid:g45739b38cc7a8d1446f083be02d3f669cd2d67a */
/**************************************************************************
 * 函数名称 : BspSetDigitalPhaseShifterAlarmFlag
 * 功能描述 : 设置RRU支持数字移相器告警功能
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetDigitalPhaseShifterAlarmFlag(UINT32 supportFlag)
{
    s_supportDigitalPhaseShifterAlarm = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetDigitalPhaseShifterAlarmFlag
 * 功能描述: 获取RRU支持数字移相器告警功能
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetDigitalPhaseShifterAlarmFlag(VOID)
{
    return s_supportDigitalPhaseShifterAlarm;
}

/********************************************************************
*  函数名称   : BspGetDigitalPhaseShifterAlarmAbility
*  功能描述   : 获取整机支持数字移相器告警功能能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetDigitalPhaseShifterAlarmAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportDigitalPhaseShifterAlarm fuRuSupportDigitalPhaseShifterAlarm = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportDigitalPhaseShifterAlarm, sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm), 0, sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm));
    fuRuSupportDigitalPhaseShifterAlarm.usSupportDigitalPhaseShifterAlarm = (UINT16)BspGetDigitalPhaseShifterAlarmFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportDigitalPhaseShifterAlarm, sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm));

    return BSP_OK;
}
/* Ended by AICoder, pid:g45739b38cc7a8d1446f083be02d3f669cd2d67a */

/* Started by AICoder, pid:48b93wc1a802a7f14eaf0902b0a843268684bebb */
void BspSetPwrOffLowestTemp(INT32 temp)
{
    s_pwrOffLowestTemp = temp;
}

INT32 BspGetPwrOffLowestTemp(void)
{
    return s_pwrOffLowestTemp;
}

void BspSetSuppPwrAvoidFlag(UINT32 flag)
{
    s_suppPwrAvoidFlag = flag;
}

void BspSetSuppPllAvoidFlag(UINT32 flag)
{
    s_suppPllAvoidFlag = flag;
}
/* Ended by AICoder, pid:48b93wc1a802a7f14eaf0902b0a843268684bebb */

/* Started by AICoder, pid:p90b6k3992i18e5147c60b2fa023952ce48669eb */
static UINT32 BspCheckSupportPwrAvoid(void)
{
    INT32 temp = 0;

    if(NO_SUPP_PWR_AUTO_ON_OFF_AVOID == s_suppPwrAvoidFlag)
    {
        return BSP_OK;
    }
    else
    {
        (void)BspGetBoardTemp(0, &temp);
        if(temp < s_pwrOffLowestTemp)
        {
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:p90b6k3992i18e5147c60b2fa023952ce48669eb */

/* Started by AICoder, pid:z5bf8p4185o0c0f14702097c209d9810fd42ff0a */
static UINT32 BspCheckPwrSupportAutoOnOff(void)
{
    UINT32 retVal = BSP_OK;

    if((BSP_ERROR == BspCheckSupportPwrAvoid()) || (SUPP_PWR_AUTO_ON_OFF_AVOID == s_suppPllAvoidFlag))
    {
        retVal =  BSP_ERROR;
    }
    return retVal;
}
/* Ended by AICoder, pid:z5bf8p4185o0c0f14702097c209d9810fd42ff0a */

/* Started by AICoder, pid:r6cf0h32cae73d91457109d3d0533b243ec59745 */
UINT32 BspGetPwrAutoOnOffAbilit(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportPwrOnOffAvoid fuRuSupportPwrOnOffAvoid = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportPwrOnOffAvoid))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportPwrOnOffAvoid, sizeof(T_BspFuRuSupportPwrOnOffAvoid), 0, sizeof(T_BspFuRuSupportPwrOnOffAvoid));
    fuRuSupportPwrOnOffAvoid.supportPwrOnOffAvoidFlag = BspCheckPwrSupportAutoOnOff();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportPwrOnOffAvoid, sizeof(T_BspFuRuSupportPwrOnOffAvoid));

    return BSP_OK;
}
/* Ended by AICoder, pid:r6cf0h32cae73d91457109d3d0533b243ec59745 */

/* Started by AICoder, pid:nbe25hfabfo2b2d14ddf0a0ae02b2035af76e026 */
UINT32 BspGetSupportIF0IF1Flag()
{
    return s_supportIF0IF1Flag;
}

VOID BspSetSupportIF0IF1Flag(UINT32 flag)
{
    s_supportIF0IF1Flag = flag;
}

UINT32 BspGetSupprtSampleRateFlag()
{
    return s_supportSampleRate;
}

VOID BspSetSupprtSampleRateFlag(UINT32 flag)
{
    s_supportSampleRate = flag;
}

UINT32 BspGetIF0IF1SplitAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportIF0IF1Split fuRuIF0IF1SplitInfo = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportIF0IF1Split))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuIF0IF1SplitInfo, sizeof(T_BspFuRuSupportIF0IF1Split), 0, sizeof(T_BspFuRuSupportIF0IF1Split));
    fuRuIF0IF1SplitInfo.supportIF0IF1Flag = BspGetSupportIF0IF1Flag();
    fuRuIF0IF1SplitInfo.sampleRate = BspGetSupprtSampleRateFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuIF0IF1SplitInfo, sizeof(T_BspFuRuSupportIF0IF1Split));

    return BSP_OK;
}
/* Ended by AICoder, pid:nbe25hfabfo2b2d14ddf0a0ae02b2035af76e026 */

/* Started by AICoder, pid:q8ee561e8frf764140220b1e00dba25d23a812a9 */
/**
 * @brief 设置整机最大功耗限制信息
 * @param supportFlag 支持能力标志, 1:支持, 0:不支持
 * @param maxPowMw 最大限制功耗 单位 mw
 * @return BSP_OK - 成功; 其它值为失败
 */
UINT32 BspSetMaxPowLimitInfo(UINT32 supportFlag, INT32 maxPowMw)
{
    s_supportMaxPowLimitFlag = supportFlag;
    s_maxPowMw = maxPowMw;
    return BSP_OK;
}

/**
 * @brief 获取最大功耗限制能力
 * @return 支持能力标志
 */
UINT32 BspGetMaxPowLimitAbility(VOID)
{
    return s_supportMaxPowLimitFlag;
}

/**
 * @brief 获取最大功耗限制值
 * @return 最大功耗限制值 (单位: mw)
 */
INT32 BspGetMaxPow(VOID)
{
    return s_maxPowMw;
}

/**
 * @brief 获取RRU最大功耗限制能力
 * @param pvRruSupportMaxPowLimitInfo 输出结构体指针
 * @param dataLen 数据长度
 * @return BSP_OK - 成功; 其它值为失败
 */
UINT32 BspGetRruMaxPowLimitAbility(VOID *pvRruSupportMaxPowLimitInfo, UINT32 dataLen)
{
    T_BspFuRuSupportMaxPowLimitInfo fuRuSupportMaxPowLimitInfo = {0};

    INPUT_POINTER_CHECK(pvRruSupportMaxPowLimitInfo);
    if (dataLen < sizeof(T_BspFuRuSupportMaxPowLimitInfo))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }
    fuRuSupportMaxPowLimitInfo.supportMaxPowLimitFlag = s_supportMaxPowLimitFlag;
    fuRuSupportMaxPowLimitInfo.maxPowMw = s_maxPowMw;
    memcpy_s(pvRruSupportMaxPowLimitInfo, dataLen, &fuRuSupportMaxPowLimitInfo, sizeof(T_BspFuRuSupportMaxPowLimitInfo));

    return BSP_OK;
}
/* Ended by AICoder, pid:q8ee561e8frf764140220b1e00dba25d23a812a9 */

/* Started by AICoder, pid:sc4cc6f403m0ab21432008d9d0303c76a9f405ad */
/**************************************************************************
 * 函数名称 : BspSetVswrPosOnlineDetectionAbility
 * 功能描述 : 设置整机变更过驻波降额策略
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetVswrDeratingAbility(UINT32 supportFlag)
{
    s_supportVswrDerating = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetVswrPosOnlineDetectionAbility
 * 功能描述: 获取RRU整机变更过驻波降额策略能力
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetVswrDeratingAbility(VOID)
{
    return s_supportVswrDerating;
}

INT32 BspSetVswrDeratingThreshold(INT32 val)
{
    s_vswrDeratingThre = val;
    return s_vswrDeratingThre;
}

INT32 BspGetVswrDeratingThreshold(VOID)
{
    return s_vswrDeratingThre;
}

INT32 BspSetVswrRecoveryThreshold(INT32 val)
{
    s_vswrRecoveryThre = val;
    return s_vswrRecoveryThre;
}

INT32 BspGetVswrRecoveryThreshold(VOID)
{
    return s_vswrRecoveryThre;
}

UINT32 BspGetSupportVswrDeratingAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportVswrDeratingInfo fuRuSupportVswrDerating = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportVswrDeratingInfo))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportVswrDerating, sizeof(T_BspFuRuSupportVswrDeratingInfo), 0, sizeof(T_BspFuRuSupportVswrDeratingInfo));
    fuRuSupportVswrDerating.vswrDeratingFlag = BspGetVswrDeratingAbility();
    fuRuSupportVswrDerating.vswrDeratingThreshold = BspGetVswrDeratingThreshold();
    fuRuSupportVswrDerating.vswrRecoveryThreshold = BspGetVswrRecoveryThreshold();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportVswrDerating, sizeof(T_BspFuRuSupportVswrDeratingInfo));

    return BSP_OK;
}
/* Ended by AICoder, pid:sc4cc6f403m0ab21432008d9d0303c76a9f405ad */

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : rruability_tdd.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了rruablity接口声明
* 注意事项 : 无
* 作    者 :   wangfei10102065
* 创建日期 : 2018-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei10102065
* 修改日戳: 2018-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef FUNCLIB_RRUABILITY_TDD_H_
#define FUNCLIB_RRUABILITY_TDD_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "bspcomm.h"
#include "rruabilitycommon.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define NO_SUPP_PWR_AUTO_ON_OFF_AVOID        (UINT32)(0)  /*不支持电源自动启停规避处理*/
#define SUPP_PWR_AUTO_ON_OFF_AVOID           (UINT32)(1)  /*支持电源自动启停规避处理*/

/*bit0为IF0 bit1为IF1 0表示不支持 1表示支持*/
#define SUPPORT_IF0_ONLY                     (UINT32)(0x1) /*只支持IF0*/
#define SUPPORT_IF1_ONLY                     (UINT32)(0x2) /*只支持IF1*/
#define SUPPORT_IF0IF1_BOTH                  (UINT32)(0x3) /*IF0/1都支持*/

/*
bit0: 5M  7.68Mbps  bit1: 10M 15.36Mbps
bit2: 15M 23.04Mbps bit3: 20M 23.04Mbps
bit4: 15M 30.72Mbps bit5: 20M 30.72Mbps
bit6: 15M 19.2Mbps  bit7: 20M 19.2Mbps
*/
#define SUPPORT_ALLRATE_ALLBANDWIDTH         (UINT32)(0xFF) /*支持全部带宽下的所有采样率*/
#define SUPPORT_ALL_EXCEPT_19MRATE           (UINT32)(0x3F) /*支持除19.2M采样率外的其他配置 D4芯片不支持TDD LTE 19.2采样率*/
#define SUPPORT_FOR_ONLY_IF1_RATE            (UINT32)(0)    /*第一版合入 (1)R9614 S26 D4 (2)R9614E M1826 (3)R9626E M1826*/


/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数定义
 **************************************************************************/
UINT32 BspGetFuRuSuppRadioMode(VOID *pRruAbilityFuInfo,UINT32 dataLen);
UINT32 BspGetFuRu9BitComperess(VOID *pRruAbilityFuInfo,UINT32 dataLen);
UINT32 BspGetFuTddRuChanCarrier(UINT32 chan, UINT32 dir, VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetCarrNumCfg(UINT32 radioType);
UINT32 BspSetCarrNumCfg(UINT32 radioType, UINT32 carrNum);
UINT32 BspGetRruSupportRadioMode(VOID);
UINT32 BspSetRruSupportRadioMode(UINT32 supportRadioMode);
UINT32 BspGetRruSupport9BitCompress(VOID);
UINT32 BspSetRruSupport9BitCompress (UINT32 support9BitCompress);
UINT32 BspGetFuRuUpDeleyAbilty(VOID *pRruAbilityFuInfo,UINT32 dataLen);
UINT32 BspGetVswrPosOnlineDetectAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetVswrPosOnlineDetectionAbility(UINT32 supportFlag);
UINT32 BspSetVswrGateResetFlag(UINT32 supportFlag);
UINT32 BspGetRruCarrRangeCapture(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetDigitalPhaseShifterAlarmFlag(UINT32 supportFlag);
UINT32 BspGetDigitalPhaseShifterAlarmAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetPwrAutoOnOffAbilit(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
void BspSetPwrOffLowestTemp(INT32 temp);
INT32 BspGetPwrOffLowestTemp(void);
void BspSetSuppPwrAvoidFlag(UINT32 flag);
void BspSetSuppPllAvoidFlag(UINT32 flag);
UINT32 BspGetIF0IF1SplitAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetSupportIF0IF1Flag();
UINT32 BspGetSupprtSampleRateFlag();
VOID BspSetSupportIF0IF1Flag(UINT32 flag);
VOID BspSetSupprtSampleRateFlag(UINT32 flag);
UINT32 BspSetMaxPowLimitInfo(UINT32 supportFlag, INT32 maxPowMw);
UINT32 BspGetMaxPowLimitAbility(VOID);
INT32 BspGetMaxPow(VOID);
UINT32 BspGetRruMaxPowLimitAbility(VOID *pvRruSupportMaxPowLimitInfo, UINT32 dataLen);
UINT32 BspSetVswrDeratingAbility(UINT32 supportFlag);
INT32 BspSetVswrDeratingThreshold(INT32 val);
INT32 BspSetVswrRecoveryThreshold(INT32 val);
UINT32 BspGetSupportVswrDeratingAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
#ifdef __cplusplus
}
#endif
#endif 





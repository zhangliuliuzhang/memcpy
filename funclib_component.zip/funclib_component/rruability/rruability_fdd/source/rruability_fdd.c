/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rruability_fdd.c
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 : wangfei10102065
* 创建日期 : 2018-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei10102065
* 修改日戳: 2018-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "rruability_fdd.h"
#include "funccommon_carrmap.h"
#include "rruinfo.h"
#include "funccommon_a.h"
#include "freqcfgcommon.h"
#include "exprn.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
    

T_RruAbilityInfo rruAbilityInfo[] =
{
    {BSP_FU_RU_BASEINFO             ,BspGetFuRuBaseInfo      },
    {BSP_FU_RU_SUPP_RADIOMODE       ,BspGetFuRuSuppRadioMode },
    {BSP_FU_RU_RUN_RADIOMODE        ,BspGetFuRuRunRadioMode  },
    {BSP_FU_RU_FIBERPORT            ,BspGetFuRuFibrPort      },
    {BSP_FU_RU_COMBIN               ,BspGetFuRuComBin        },
    {BSP_FU_RU_AISGPORTVOIT         ,BspGetFuRuAisgPortVolt  },
    {BSP_FU_RU_DRYCONTACT           ,BspGetFuRuDryContact    },
    {BSP_FU_RU_NSBT                 ,BspGetFuRuNsbt          },
    {BSP_FU_RU_CROSSDIVERSITY       ,BspGetFuRuCrossDiversity},
    {BSP_FU_RU_9BITCOMPRESS         ,BspGetFuRu9BitComperess },
    {BSP_FU_RU_DTX                  ,BspGetFuRuDtx           },
    {BSP_FU_RU_LOCALOSCI            ,BspGetFuRuLocalOsci     },
    {BSP_FU_RU_SUPP_LOCALOSCI_CFG   ,BspGetFuRuSuppLocalOsci },
    {BSP_FU_RU_ANTJUMP              ,BspGetFuAntJump         },
    {BSP_FU_RU_AAS_WORKMODE         ,BspGetFuRuAasWorkMode   },
    {BSP_FU_RU_LTE_UPDELAY          ,BspGetFuRuUpDeleyAbilty },
	{BSP_FU_RU_IF1_Ability          ,BspGetFuRuIf1Abilty     },/*IF1处理时延上报*/
    {BSP_FU_RU_CARR_CAP             ,BspGetRruCarrRangeCapture},/*RU支持的载波号范围信息*/
    {BSP_FU_RU_PA_BASE_INFO,         BspGetRuPaBaseInfo},
};

T_RruSpecialAbilityInfo rruSpAbilityInfo[] =
{
    {BSP_FU_RU_RAISE_TPTL_GATE      ,BspGetRaiseTptlGateAbility },
    {BSP_FU_RU_RAIL_MODE            ,BspGetRruRailModeAbility   },
    {BSP_FU_RU_VSWR_POS_ONLINE      ,BspGetVswrPosOnlineDetectAbility },
    {BSP_FU_RU_MTSTEMP_PTX          ,BspGetRruMtsTempPtxAbility },
    {BSP_FU_RU_VSWR_OPTMIZE         ,BspGetRruVswrOptMizeInfo },
    {BSP_FU_RU_SPE_AVG_PAPT         ,BspGetRruAvgPaptAbility },
    {BSP_FU_RU_PWRLETTEMP_CHECK     ,BspGetRruPwrLetTempChkAbility},
    {BSP_FU_RU_OVERPOW_TO_OPENLOOP  ,BspGetRruOverPowToOpenLoopAbility},
    {BSP_FU_RU_CARROPTBIND          , BspGetRruCarrOptBindPara},
    {BSP_FU_RU_BASE_BAND_MERG       , BspGetBasebandMergAbility},
    {BSP_FU_RU_AUTO_ADJUST_VOLT     , BspGetRruAutoAdjustVoltAbility},
    {BSP_FU_RU_TEMP_COMPS_FLAG      ,BspGetTempCompsFlagAbility },
    {BSP_FU_RU_DIG_PHASE_SHIFT_ALM  ,BspGetDigitalPhaseShifterAlarmAbility},
    {BSP_FU_RU_UNION_ANT            ,BspGetSupportUnionAntAbility},
    {BSP_FU_RU_SUPPORT_BNAD_VSWR    ,BspGetRruBandVswrAbility},
    {BSP_FU_RU_MAX_POW_LIMIT        ,BspGetRruMaxPowLimitAbility},
    {BSP_FU_RU_UAEMODE_SUPPORT      ,BspGetRruUaeModeAbility},
    {BSP_FU_RU_ISOLATION_DETECTION  ,BspGetNcrIsolationDetectionAbility},
    {BSP_FU_RU_PLC_CONFIG_INFO      ,BspGetRruPlcConfigAbility},
    {BSP_FU_RU_ICPATHCHG_SUPPORT  ,BspGetSupportIcPathChgAbility},
    {BSP_FU_RU_IF0_IF1_SPLIT,        BspGetIF0IF1SplitAbility},
    {BSP_FU_RU_NTF_NEW,              BspGetNtfSolutionAbility},
    {BSP_FU_RU_SUPPORT_VSWR_DERATING, BspGetSupportVswrDeratingAbility},
    {BSP_FU_RU_UMTS_RSSI_OPTMIZE_SW ,BspGetRruUmtsRssiOptmizeSwAbility},
    {BSP_FU_RU_VSWRGATE_CHANMASK_ADAPT ,BspGetRruVswrGateChanMask},
};

T_RruChanAbilityInfo rruChnAbilityInfo[] =
{
    {BSP_FU_RUCHL_BASEINFO          ,BspGetFuRuChanBaseInfo  },
    {BSP_FU_RUCHL_BANDWIDTH         ,BspGetFuRuChanBandWidth },
    {BSP_FU_RUCHL_POWER             ,BspGetFuRuChanPower     },
    {BSP_FU_RUCHL_RADIOMODE         ,BspGetFuRuChanRadioMode },
    {BSP_FU_RUCHL_CARRIER           ,BspGetFuRuChanCarrier   },
    {BSP_FU_RUCHL_DFLGAIN           ,BspGetFuRuChanDflGain   },
};

T_BspFuRadioRuChlCarrier fuRuChlCarrier[] =
{
    {RADIO_STANDARD_UMTS,       {UMTS_BANDWIDTH_3P8M,UMTS_BANDWIDTH_4M,UMTS_BANDWIDTH_4P2M,UMTS_BANDWIDTH_4P4M,UMTS_BANDWIDTH_4P6M,UMTS_BANDWIDTH_4P8M,UMTS_BANDWIDTH_5M,0,0,0}},
    {RADIO_STANDARD_GSM,        {BANDWIDTH_0P2M,0,0,0,0,0,0,0,0,0}},
    {RADIO_STANDARD_TD_SCDMA,   {0,0,0,0,0,0,0,0,0,0}},
    {RADIO_STANDARD_CDMA,       {BANDWIDTH_1P25M,0,0,0,0,0,0,0,0,0}},
    {RADIO_STANDARD_LTE_FDD,    {LTE_BANDWIDTH_1P4M,LTE_BANDWIDTH_3M,LTE_BANDWIDTH_5M,LTE_BANDWIDTH_10M,LTE_BANDWIDTH_15M,LTE_BANDWIDTH_20M,0,0,0,0}},
    {RADIO_STANDARD_LTE_TDD,    {LTE_BANDWIDTH_1P4M,LTE_BANDWIDTH_3M,LTE_BANDWIDTH_5M,LTE_BANDWIDTH_10M,LTE_BANDWIDTH_15M,LTE_BANDWIDTH_20M,0,0,0,0}},
    {RADIO_STANDARD_WIMAX,      {0,0,0,0,0,0,0,0,0,0}},
    {RADIO_STANDARD_MICROWAVE,  {0,0,0,0,0,0,0,0,0,0}},
    {RADIO_STANDARD_5G,         {0,0,0,0,0,0,0,0,0,0}},
};

static UINT32 s_supportRadioMode     = 0;/* 支持的工作制式 */
static UINT32 s_lopoCascadeNum       = 0;/* 支持链型级联数 */
static UINT32 s_optSpeedList         = 0;
static UINT32 s_combin               = 0;
static UINT32 s_inDryContactNum      = 0;
static UINT32 s_outDryContactNum     = 0;
/* static UINT32 s_nsbtSupport          = 0; */
static UINT32 s_crossDiversity       = 0;
static UINT32 s_support9BitCompress  = 1;
static UINT32 s_supportAntJump       = 0;
static UINT32 s_aasWorkMode          = 0;
static UINT32 s_supportDtx           = 0;
static UINT32 s_ulDelayCmp           = 250;
static UINT32 s_dlDelayCmp           = 250;
static UINT32 s_rruCarrNumCfg[DIF_RADIOMODE_MAX]={0};
/* static UINT32 g_ulRruType             = 0;
static UINT32 s_rruPaTypeFlag       = 0xff; */
static UCHAR s_IsFixTax = 0;    /* 是否重新计算Tax值.0-固定值,不重新计算,1-动态计算(Tax=Tdiff+T12+T2a-Ta 取3chip整后+9chip) */
static UINT32 s_supportRaiseTptlGate = RRU_NOT_SUPPORT_RAISE_TPTL_GATE; /* 提升闭环功控门限标志, 1:支持, 0:不支持 */
static UINT32 s_support5GRMode = RRU_NOT_SUPPORT_5GR_MODE; /* RRU整机是否支持5G-R模式标志, 1:支持, 0:不支持 */
static T_BspFuRuSupportAutoAdjustVolt s_AutoVoltCfgInfo = {0}; /* RRU整机是否支持自动调压模式标志, 1:支持, 0:不支持 */
static UINT32 s_supportMtsPtxCalibration = NO_SUPPORT; /* RRU整机是否支持使用MTS温度作为反馈开环校准标志, 1:支持, 0:不支持 */
static UINT32 s_supportRruVswrOptMizeFlag = NO_SUPPORT; /* RRU整机是否支持通道驻波优化标志, 1:支持, 0:不支持 */
static UINT32 s_supportRruVswrOptMizeChanMask = 0; /* RRU整机支持驻波优化通道掩码, 1:支持, 0:不支持 */
static UINT32 s_supportRruPwrLetTempCheck = NO_SUPPORT; /* RRU整机是否支持电源连接器过温检测标志, 1:支持, 0:不支持 */
static UINT32 s_supportOverPowToOpenLoop = NO_SUPPORT; /* RRU整机是否支持模拟过功率降额3dB变更为开环定标标志, 1:支持, 0:不支持 */
static UINT32 s_supportBasebandMerg = NO_SUPPORT; /*RRU整机是否支持软劈裂基带合并能力, 1:支持, 0:不支持*/
static UINT32 s_ulIf1DiffDelay = 112000;
static UINT32 s_supportVswrPosOnlineDetection = 0; /* 支持在线驻波位置检测标志, 1:支持, 0:不支持 */
static UINT32 s_supportVswrGateReset = 0;/* 支持驻波门限重置标志, 1:支持, 0:不支持 */
static T_RruFreqIdCaCap *s_pRruCarrRangeCap = NULL;  /*RRU支持的载波号范围信息上报*/
static T_RruFreqIdCaCap s_rruCarrRangeCapInfo = {0};
static UINT32 s_supportAvgPaptSpeCtrlFlag = NO_SUPPORT; /* RRU整机是否支持dpd均值保护降额标志, 1:支持, 0:不支持 */
static UINT32 s_supportAvgPaptSpeCtrlChanMask = 0; /* RRU整机支持dpd均值保护降额通道掩码, 1:支持, 0:不支持 */
static T_BspFuRuCarrOptBindPara s_rruCarrOptBindPara = {0};
static UINT32 s_supportTempCompsFlag = 0; /* 支持在线驻波位置检测标志, 1:支持, 默认0:不支持 */
static UINT32 s_supportDigitalPhaseShifterAlarm = 0; /* 支持数字移相器告警, 1:支持, 0:不支持 */
static UINT32 s_supportUnionAnt = 0; /* 支持多通道共天线, 1:支持, 0:不支持 */
static UINT32 s_supportMaxPowLimitFlag = NO_SUPPORT; /* RRU整机是否支持最大功耗限制, 1:支持, 0:不支持 */
static INT32 s_maxPowMw = 5000000;                   /* 最大限制功耗 单位 mw 默认值5000W */
static UINT32 s_supportRruUaeMode = NO_SUPPORT; /* RRU整机是否支持阿联酋模式过温门限配置标志, 1:支持, 0:不支持 */
static UINT32 s_supportPlc = NO_SUPPORT;        /* 整机是否支持PLC */
static UINT32 s_supportRequestVer = NO_SUPPORT; /* 是否支持向PLC请求版本 */
static UINT32 s_rruPlcChipType = 0xFF;          /* RRU_PLC芯片类型(0:钜泉 2:瑞萨) */
static UINT32 s_supportIsolationDetection = SUPPORT; /* NCR机型是否支持隔离度检测配置标志, 1:支持, 0:不支持 */
UINT32 g_ulSupportIcPathChnFlag = 0;   /*是否支持IC互联关系切换 0不支持 1支持*/
/*默认值设置为 非R9614 S26/R9614E M1826/R9626E M1826外的其他平台机型的情况*/
static UINT32 s_supportIF0IF1Flag = SUPPORT_IF0_ONLY;   /*其他机型支持IF0 不支持IF1*/
static UINT32 s_supportSampleRate = SUPPORT_ALLRATE_ALLBANDWIDTH; /*其余机型支持IF0全部采样率*/
static UINT32 s_supportNtfNewSolution = NTF_SUPPORT_OLD_SOLUTION; /*硬件自检新接口支持能力*/
static UINT32 s_supportVswrDerating = 0;             /* 支持变更过驻波降额策略, 1:支持, 0:不支持 */
static INT32 s_vswrDeratingThre = 30;                /* 驻波降额门限，单位0.1 */
static INT32 s_vswrRecoveryThre = 20;                /* 驻波恢复门限，单位0.1 */
static USHORT s_supportUmtsRssiOptmize = NO_SUPPORT; /* RRU整机是否支持Umts Rssi的美化开关标志, 1:支持, 0:不支持 */
static UINT32 s_vswrGateChanMask = 0;
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
 * 函数名称: BspGetRruSupportRadioMode
 * 功能描述: 获取RRU支持的制式
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruSupportRadioMode(VOID)
{
    return s_supportRadioMode;
}
/**************************************************************************
 * 函数名称: BspSetRruSupportRadioMode
 * 功能描述: 设置RRU支持的制式
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruSupportRadioMode(UINT32 supportRadioMode)
{
    s_supportRadioMode = supportRadioMode;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetRruRaiseTptlGateAbility
 * 功能描述: 获取RRU支持提升闭环功控门限的能力信息
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetRruRaiseTptlGateAbility(VOID)
{
    return s_supportRaiseTptlGate;
}

/**************************************************************************
 * 函数名称 : BspSetRruRaiseTptlGateAbility
 * 功能描述 : 设置RRU支持提升闭环功控门限的能力
 * 输入参数 : supportRaiseTptlGate:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruRaiseTptlGateAbility(UINT32 supportRaiseTptlGate)
{
    s_supportRaiseTptlGate = supportRaiseTptlGate;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetRruBasebandMergAbility
 * 功能描述: 从全局变量获取RRU支持软劈裂基带合并的能力信息
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetRruBasebandMergAbility(VOID)
{
    return s_supportBasebandMerg;
}

/**************************************************************************
 * 函数名称 : BspSetRruBasebandMergAbility
 * 功能描述 : 设置RRU支持软劈裂基带合并的能力到全局变量
 * 输入参数 : supportBasebandMerg:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruBasebandMergAbility(UINT32 supportBasebandMerg)
{
    s_supportBasebandMerg = supportBasebandMerg;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetRruSupport5GRAbility
 * 功能描述: 获取RRU整机是否支持5G-R模式
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetRruSupport5GRAbility(VOID)
{
    return s_support5GRMode;
}

/**************************************************************************
 * 函数名称 : BspSetRruSupport5GRAbility
 * 功能描述 : 设置RRU整机是否支持5G-R模式能力
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruSupport5GRAbility(UINT32 supportFlag)
{
    s_support5GRMode = supportFlag;
    return BSP_OK;
}
/* Started by AICoder, pid:8f1c54c34ae559114c000a2b401835154051b3e5 */
/**************************************************************************
 * 函数名称: BspGetVswrGateAdaptChanMask
 * 功能描述:
 * 返 回 值: bit位 1:对应通道进行修改, 0:不修改
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetVswrGateAdaptChanMask(VOID)
{
    return s_vswrGateChanMask;
}
/* Ended by AICoder, pid:8f1c54c34ae559114c000a2b401835154051b3e5 */

/* Started by AICoder, pid:if1c57c34aw559114c000a2b401835154054b3e5 */
/**************************************************************************
 * 函数名称 : BspSetChanMaskAdaptVswrGate
 * 功能描述 : 设置RRU整机从片通道掩码进行驻波门限策略修改
 * 输入参数 : chanMask:通道掩码, bit位 1:对应通道进行修改, 0:不修改
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetChanMaskAdaptVswrGate(UINT32 chanMask)
{
    s_vswrGateChanMask = chanMask;
    return BSP_OK;
}
/* Ended by AICoder, pid:if1c57c34aw559114c000a2b401835154054b3e5 */

/**************************************************************************
 * 函数名称: BspGetRruMtsTempPtxFlag
 * 功能描述:
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetRruMtsTempPtxFlag(VOID)
{
    return s_supportMtsPtxCalibration;
}

/**************************************************************************
 * 函数名称 : BspSetRruMtsTempPtxFlag
 * 功能描述 :
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruMtsTempPtxFlag(UINT32 supportFlag)
{
    s_supportMtsPtxCalibration = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称 : BspGetRruVswrOptMizeFlag
 * 功能描述 : 获取整机是否支持通道驻波优化标识
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspGetRruVswrOptMizeFlag(VOID)
{
    return s_supportRruVswrOptMizeFlag;
}

/**************************************************************************
 * 函数名称 : BspSetRruVswrOptMizeFlag
 * 功能描述 : 设置整机是否支持通道驻波优化标识
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruVswrOptMizeFlag(UINT32 supportFlag)
{
    s_supportRruVswrOptMizeFlag = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称 : BspGetRruVswrOptMizeChanMask
 * 功能描述 : 整机获取通道驻波优化的通道掩码
 * 输入参数 : ulChanMask:通道掩码
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspGetRruVswrOptMizeChanMask(VOID)
{
    return s_supportRruVswrOptMizeChanMask;
}

/**************************************************************************
 * 函数名称 : BspSetRruVswrOptMizeChanMask
 * 功能描述 : 整机支持驻波优化的通道掩码设置
 * 输入参数 : ulChanMask:通道掩码
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruVswrOptMizeChanMask(UINT32 ulChanMask)
{
    s_supportRruVswrOptMizeChanMask = ulChanMask;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称 : BspSetAvgPaptSpeCtrlInfo
 * 功能描述 : 设置整机是否支持dpd均值保护降额信息
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持 chanMask: 支持的通道
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetAvgPaptSpeCtrlInfo(UINT32 supportFlag, UINT32 chanMask)
{
    s_supportAvgPaptSpeCtrlFlag = supportFlag;
    s_supportAvgPaptSpeCtrlChanMask = chanMask;
    return BSP_OK;
}

/**************************************************************************
* 函数名称 : BspSetRruPwrLetTempCheckFlag
* 功能描述 : 设置RRU整机支持电源连接器过温检测标志
* 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruPwrLetTempCheckFlag(UINT32 supportFlag)
{
    s_supportRruPwrLetTempCheck = supportFlag;
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetRruPwrLetTempCheckFlag
* 功能描述: RRU整机是否支持电源连接器过温检测
* 返 回 值: 1:支持, 0:不支持
* 其它说明: 无
*  **************************************************************************/
UINT32 BspGetRruPwrLetTempCheckFlag(VOID)
{
    return s_supportRruPwrLetTempCheck;
}

/**************************************************************************
* 函数名称 : BspSetIsolationDetectionFlag
* 功能描述 : 设置NCR机型支持隔离度检测配置标志
* 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
/* Started by AICoder, pid:9c081t775de1b35145e10a2790f35e0db6659e93 */
UINT32 BspSetIsolationDetectionFlag(UINT32 supportFlag)
{
    s_supportIsolationDetection = supportFlag;
    return BSP_OK;
}
/* Ended by AICoder, pid:9c081t775de1b35145e10a2790f35e0db6659e93 */
/**************************************************************************
* 函数名称: BspGetIsolationDetectionFlag
* 功能描述: NCR机型是否支持隔离度检测配置标志
* 返 回 值: 1:支持, 0:不支持
* 其它说明: 无
*  **************************************************************************/
/* Started by AICoder, pid:ae382c76e4p525e1418709b480ed0108fd74b3b0 */
UINT32 BspGetIsolationDetectionFlag(VOID)
{
    return s_supportIsolationDetection;
}
/* Ended by AICoder, pid:ae382c76e4p525e1418709b480ed0108fd74b3b0 */

/* Started by AICoder, pid:vb7f579471w7c1c14c5b094100f3db299cd43085 */
/**************************************************************************
* 函数名称 : BspSetRruAueModeFlag
* 功能描述 : 设置RRU整机支持阿联酋模式过温门限配置标志
* 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruAueModeFlag(UINT32 supportFlag)
{
    s_supportRruUaeMode = supportFlag;
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetRruAueModeFlag
* 功能描述: RRU整机是否支持阿联酋模式过温门限配置标志
* 返 回 值: 1:支持, 0:不支持
* 其它说明: 无
*  **************************************************************************/
UINT32 BspGetRruAueModeFlag(VOID)
{
    return s_supportRruUaeMode;
}
/* Ended by AICoder, pid:vb7f579471w7c1c14c5b094100f3db299cd43085 */

/* Started by AICoder, pid:t59a693e0f48adb143870968e071864e6f6948f1 */
/**************************************************************************
* 函数名称 : BspSetRruPlcSupportFlag
* 功能描述 : 设置RRU整机PLC支持情况
* 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruPlcSupportFlag(UINT32 supportFlag)
{
    s_supportPlc = supportFlag;
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetRruPlcSupportFlag
* 功能描述: RRU整机是否支持PLC
* 返 回 值: 1:支持, 0:不支持
* 其它说明: 无
*  **************************************************************************/
UINT32 BspGetRruPlcSupportFlag(VOID)
{
    return s_supportPlc;
}

/**************************************************************************
* 函数名称 : BspSetRruSupportRequestVer
* 功能描述 : 设置RRU整机是否支持向PLC请求版本情况
* 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruSupportRequestVer(UINT32 supportFlag)
{
    s_supportRequestVer = supportFlag;
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetRruSupportRequestVer
* 功能描述: 是否支持向PLC请求版本情况
* 返 回 值: 1:支持, 0:不支持
* 其它说明: 无
*  **************************************************************************/
UINT32 BspGetRruSupportRequestVer(VOID)
{
    return s_supportRequestVer;
}
/* Ended by AICoder, pid:t59a693e0f48adb143870968e071864e6f6948f1 */

/**************************************************************************
* 函数名称 : BspSetRruPlcChipType
* 功能描述 : 设置RRU整机RRU整机PLC芯片类型
* 输入参数 :
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
/* Started by AICoder, pid:ec92eo8ec7v5641141490bb720f63203adf743f4 */
UINT32 BspSetRruPlcChipType(UINT32 chipType)
{
    s_rruPlcChipType = chipType;
    return BSP_OK;
}
/* Ended by AICoder, pid:ec92eo8ec7v5641141490bb720f63203adf743f4 */

/**************************************************************************
* 函数名称: BspGetRruPlcChipType
* 功能描述: 获取RRU整机PLC芯片类型
* 返 回 值:
* 其它说明: 无
*  **************************************************************************/
/* Started by AICoder, pid:rdcd1t874dj654214a4d082fa0fc381a0e3704c9 */
UINT32 BspGetRruPlcChipType(VOID)
{
    return s_rruPlcChipType;
}
/* Ended by AICoder, pid:rdcd1t874dj654214a4d082fa0fc381a0e3704c9 */

/**************************************************************************
 * 函数名称 : BspSetRruAutoVoltAbility
 * 功能描述 : 设置RRU整机是否支持自动调压能力
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetRruAutoVoltAbility(UINT32 supportFlag, UINT32 power)
{
    s_AutoVoltCfgInfo.usSupportAutoAdjustVoltFlag = supportFlag;
    s_AutoVoltCfgInfo.rruPower = power;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetRruAutoVoltAbility
 * 功能描述: 获取RRU整机是否支持自动调压
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
T_BspFuRuSupportAutoAdjustVolt* BspGetRruAutoVoltAbility(VOID)
{
    return &s_AutoVoltCfgInfo;
}

/**************************************************************************
* 函数名称 : BspSetRruPwrLetTempCheckFlag
* 功能描述 : 设置RRU整机是否支持模拟过功率降额3dB变更为开环定标
* 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetOverPowToOpenLoopAbility(UINT32 supportFlag)
{
    s_supportOverPowToOpenLoop = supportFlag;
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetRruPwrLetTempCheckFlag
* 功能描述: 获取整机是否支持模拟过功率降额3dB变更为开环定标
* 返 回 值: 1:支持, 0:不支持
* 其它说明: 无
*  **************************************************************************/
UINT32 BspGetOverPowToOpenLoopAbility(VOID)
{
    return s_supportOverPowToOpenLoop;
}

/**************************************************************************
 * 函数名称: BspGetTopoCascadeNum
 * 功能描述: 获取RRU支持链型级联数
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetTopoCascadeNum(VOID)
{
    return s_lopoCascadeNum;
}
/**************************************************************************
 * 函数名称: BspSetRruSupportRadioMode
 * 功能描述: 设置RRU支持链型级联数
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetTopoCascadeNum(UINT32 topoCascadeNum)
{
    s_lopoCascadeNum = topoCascadeNum;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetOptSpeedListAbility
 * 功能描述: 获取RRU光口支持的速率
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetOptSpeedListAbility(T_OptSpeedList *ptSpeedList)
{
    UINT32 idx    = 0;    
    INPUT_POINTER_CHECK(ptSpeedList);

     /*bit[5:0],从bit0开始，依次代表1G/2G/3G/4G/6G/10G*/

    for(idx = 0; idx < MAX_OPT_NUM; idx++)
    {
        if(idx < BspGetOptNum())
        {
            ptSpeedList->aulOptSpeed[idx] = s_optSpeedList;
        }
        else
        {
             ptSpeedList->aulOptSpeed[idx] = 0;
        }
    }
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspSetOptSpeedListAbility
 * 功能描述: 获取RRU光口支持的速率
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetOptSpeedListAbility(UINT32 optSpeedList)
{
    s_optSpeedList = optSpeedList;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetRruCombin
 * 功能描述: 获取RRU并柜支持
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruCombin(VOID)
{
    return s_combin ;
}
/**************************************************************************
 * 函数名称: BspSetRruCombin
 * 功能描述: RRU并柜支持
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruCombin(UINT32 ulCombin)
{
    s_combin = ulCombin;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspAdpGetBoardInputAisgVolt
*  功能描述   : 获取单板AISG输入电压
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulPwrType
*  输出参数   : 无
*  返 回 值   : 成功或者失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*----------------------------------------------------------------------------
*/
UINT32 BspAdpGetBoardInputAisgVolt(UINT32 ulPwrType)
{
    T_HwInfo *ptInfo = NULL;

    if( ulPwrType >= AISG_PWR_NUM )
    {
        return INVALID_VALUE;
    }

    ptInfo = (T_HwInfo*)BspGetGlobalRruHwInfo();

    return ptInfo->BoardInfo.aulInputAisgVolt[ulPwrType];
}

/**************************************************************************
 * 函数名称: BspGetRruInDryContactNum
 * 功能描述: 获取RRU输入干接点
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruInDryContactNum(VOID)
{
    return s_inDryContactNum ;
}
/**************************************************************************
 * 函数名称: BspGetRruOutDryContactNum
 * 功能描述: 获取RRU输出干接点
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruOutDryContactNum(VOID)
{
    return s_outDryContactNum ;
}
/**************************************************************************
 * 函数名称: BspSetRruDryContactNum
 * 功能描述: RRU干接点数
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruDryContactNum (UINT32 inDryContactNum ,UINT32 outDryContactNum )
{
    s_inDryContactNum  = inDryContactNum;
    s_outDryContactNum = outDryContactNum;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetRruNsbtSupport
 * 功能描述: 获取RRU 支持交叉分级
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruCrossDiversity(VOID)
{
    return s_crossDiversity;
}
/**************************************************************************
 * 函数名称: BspSetRruNsbtSupport
 * 功能描述: RRU 交叉分级
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruCrossDiversity (UINT32 crossDiversity)
{
    s_crossDiversity  = crossDiversity;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetRruSupport9BitCompress
 * 功能描述: 获取RRU 支持9bit压缩
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruSupport9BitCompress(VOID)
{
    return s_support9BitCompress;
}
/**************************************************************************
 * 函数名称: BspSetRruSupport9BitCompress
 * 功能描述: RRU 9bit压缩
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruSupport9BitCompress (UINT32 support9BitCompress)
{
    s_support9BitCompress  = support9BitCompress;

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetRruSupportAntJump
 * 功能描述: 获取RRU 支持天线跳转
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruSupportAntJump(VOID)
{
    return s_supportAntJump;
}
/**************************************************************************
 * 函数名称: BspSetRruSupportAntJump
 * 功能描述: RRU 天线跳转
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruSupportAntJump (UINT32 supportAntJump)
{
    s_supportAntJump  = supportAntJump;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetRruAASWorkMode
 * 功能描述: 获取RRU 支持AASmode
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruAASWorkMode(VOID)
{
    return s_aasWorkMode;
}
/**************************************************************************
 * 函数名称: BspSetRruAASWorkMode
 * 功能描述: RRU AASmode
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruAASWorkMode  (UINT32 aasWorkMode )
{
    s_aasWorkMode  = aasWorkMode ;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetRruSupportDtx
 * 功能描述: 获取RRU 支持DTX
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruSupportDtx(VOID)
{
    return s_supportDtx;
}
/**************************************************************************
 * 函数名称: BspSetRruSupportDtx
 * 功能描述: RRU DTX
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruSupportDtx (UINT32 supportDtx)
{
    s_supportDtx  = supportDtx;

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetUlDelayCmpAbility
 * 功能描述: 获取RRU 支持上行时延补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetUlDelayCmpAbility(VOID)
{
    return s_ulDelayCmp;
}
/**************************************************************************
 * 函数名称: BspSetUlDelayCmpAbility
 * 功能描述: RRU 上行时延补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetUlDelayCmpAbility (UINT32 ulDelayCmpIc,UINT32 ulDelayCmpFpga)
{
    if(ulDelayCmpFpga == DELAY_CMP_FUNC_NOT_SUPPORT)
    {
        s_ulDelayCmp  = ulDelayCmpIc;
        return BSP_OK;        
    }
    else if(ulDelayCmpIc == DELAY_CMP_FUNC_NOT_SUPPORT)
    {
        s_ulDelayCmp  = ulDelayCmpFpga;
        return BSP_OK;
    }
    /*FPGA和IC 时延当中按照最小范围的上报*/
    s_ulDelayCmp = (ulDelayCmpIc <=ulDelayCmpFpga) ? ulDelayCmpIc : ulDelayCmpFpga;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetDlDelayCmpAbility
 * 功能描述: 获取RRU 支持下行时延补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetDlDelayCmpAbility(VOID)
{
    return s_dlDelayCmp;
}
/**************************************************************************
 * 函数名称: BspSetDlDelayCmpAbility
 * 功能描述: RRU 下行时延补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetDlDelayCmpAbility (UINT32 dlDelayCmpIc,UINT32 dlDelayCmpFpga)
{
    if(dlDelayCmpFpga == DELAY_CMP_FUNC_NOT_SUPPORT)
    {
        s_dlDelayCmp  = dlDelayCmpIc;
        return BSP_OK;        
    }
    else if(dlDelayCmpIc == DELAY_CMP_FUNC_NOT_SUPPORT)
    {
        s_dlDelayCmp  = dlDelayCmpFpga;
        return BSP_OK;
    }
    /*FPGA和IC 时延当中按照最小范围的上报*/
    s_dlDelayCmp = (dlDelayCmpIc <=dlDelayCmpFpga) ? dlDelayCmpIc : dlDelayCmpFpga;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetIF1DiffDelay
 * 功能描述: 获取RRU IF1 光口处理时延
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetIF1DiffDelay(VOID)
{
    return s_ulIf1DiffDelay;
}

/**************************************************************************
 * 函数名称: BspGetIF1DiffDelay
 * 功能描述: 获取RRU IF1 光口处理时延
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetIF1DiffDelay(UINT32 ulDelayVal)
{
    s_ulIf1DiffDelay = ulDelayVal;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspSetUlDelayCmpAbility
 * 功能描述: RRU 上行时延补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruSupportLocalOsci(UINT32 ulTxChan)
{
    T_HwInfo *ptInfo = NULL;

    ptInfo = (T_HwInfo*)BspGetGlobalRruHwInfo();

    return  ptInfo->BoardInfo.aulTxTxShareLo[ulTxChan];

}

/*****************************************************************************
*  函数名称   : BspGetCarrNumCfg
*  功能描述   :
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-04-02 18:33:43 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetCarrNumCfg( UINT32 radioType)
{
    return s_rruCarrNumCfg[radioType];
}
/*****************************************************************************
*  函数名称   : BspSetCarrNumCfg
*  功能描述   : 判断类型
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-04-02 18:33:43 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetCarrNumCfg( UINT32 radioType, UINT32 carrNum )
{
    s_rruCarrNumCfg[radioType] = carrNum;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetCarrierNumAndWidth
 * 功能描述: RRU 获取带宽信息
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/
UINT32 BspGetCarrierNumAndWidth(BYTE chan,BYTE dir,T_BspFuRuChlCarrier *pFuRuChlCarrier )
{
    UINT32 workMode = 0;
    UINT32 freqBand = 0;
    UINT32 loop = 0;
    UINT32 cnt = 0;   
    UINT32 retVal = BSP_OK;
    
    if(NULL == pFuRuChlCarrier)
    {
        return BSP_ERROR;
    }
    retVal   = BspRruCarrAbility();
    workMode = BspGetRadioStandard();
    freqBand = BspGetFreqArea(chan,dir);/*各个频段*/
    dbgInfoEx("%s: freqBand: %d, retVal: %d\n", __FUNCTION__, freqBand, retVal);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_UMTS]        = BspGetCarrNumCfg(DIF_RADIOMODE_UMTS);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_GSM]         = BspGetCarrNumCfg(DIF_RADIOMODE_GSM);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_TDS]         = BspGetCarrNumCfg(DIF_RADIOMODE_TDS);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_CDMA]        = BspGetCarrNumCfg(DIF_RADIOMODE_CDMA);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_LTE_FDD]     = BspGetCarrNumCfg(DIF_RADIOMODE_LTE_FDD);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_LTE_TDD]     = BspGetCarrNumCfg(DIF_RADIOMODE_LTE_TDD);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_NBIOT]       = BspGetCarrNumCfg(DIF_RADIOMODE_NBIOT);
    pFuRuChlCarrier->aucChlCarriNum[DIF_RADIOMODE_NR]          = BspGetCarrNumCfg(DIF_RADIOMODE_NR);
    for(loop =0;loop < NELEMENTS(fuRuChlCarrier);loop++)
    {
        if(workMode & fuRuChlCarrier[loop].wChlRadioMode)
        {
            for(cnt = 0;cnt < 10;cnt++)
            {
                pFuRuChlCarrier->ausCarriBandWidth[loop*10+cnt] = fuRuChlCarrier[loop].awCarriBandWidth[cnt];
            }
        }
    }
    return BSP_OK;

}
/********************************************************************
*  函数名称   : BspGetFuRuBaseInfo (*)
*  功能描述   : 获取RUBaseInfo整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuBaseInfo(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuBaseInfo   fuRuBaseInfo;
	UINT32 len = 0;
    
    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    T_HwInfo *ptInfo = NULL;

    ptInfo = (T_HwInfo*)BspGetGlobalRruHwInfo();
    if(dataLen < sizeof(T_BspFuRuBaseInfo))
    {
        return BSP_ERROR;
    }
    memset(&fuRuBaseInfo,         0,sizeof(T_BspFuRuBaseInfo));
	len = sizeof(fuRuBaseInfo.acRuName);
    /*规格名称，含PID*/
    //strncpy(fuRuBaseInfo.acRuName,(CHAR *)ptInfo->RruInfo.aucTypeNumber,len-1);
    strncpy_s(fuRuBaseInfo.acRuName, len, (CHAR *)ptInfo->RruInfo.aucTypeNumber,BAR_MAX_LENGTH);
    /* Coverity修改，防止字符串越界 */
	fuRuBaseInfo.acRuName[len-1] = '\0';

    fuRuBaseInfo.ucRuClass    = (UCHAR)BspGetRruClass(); /*RRU类别，0-RRU,1-RSU,2-AAS,3-一体化基站*/
    fuRuBaseInfo.ucAntNum     = (UCHAR)BspGetMapAntNum();/*ANT数目,从丝印配置取*/
    fuRuBaseInfo.ucTxChlNum   = (UCHAR)BspGetTxChannel();/*TX通道数目*/
    fuRuBaseInfo.ucRxChlNum   = (UCHAR)BspGetRxChannel();/*RX通道数目*/
    fuRuBaseInfo.ucAntiTheft  = (UCHAR)BspGetAntiTheftFun();/*anti-counterfeiting and proactive theft prevention*/
    memcpy(pRruAbilityFuInfo,&fuRuBaseInfo,sizeof(T_BspFuRuBaseInfo));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuSuppRadioMode (*)
*  功能描述   : 获取SuppRadioMode整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuSuppRadioMode(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuSupportRadioMode     fuRuSupportRadioMode = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuSupportRadioMode))
    {
        return BSP_ERROR;
    }
    memset(&fuRuSupportRadioMode, 0,sizeof(T_BspFuRuSupportRadioMode));

    fuRuSupportRadioMode.usSupportRadioMode = (UINT16)BspGetRruSupportRadioMode();

    memcpy(pRruAbilityFuInfo,&fuRuSupportRadioMode,sizeof(T_BspFuRuSupportRadioMode));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuRunRadioMode (*)
*  功能描述   : 获取RunRadioMode整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuRunRadioMode(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuRunRadioMode         fuRuRunRadioMode = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuRunRadioMode))
    {
        return BSP_ERROR;
    }
    /*运行的工作制式信息*/
    memset(&fuRuRunRadioMode, 0,sizeof(T_BspFuRuRunRadioMode));
    fuRuRunRadioMode.usRunRadioMode = (UINT16)BspGetRadioStandard();
    memcpy(pRruAbilityFuInfo,&fuRuRunRadioMode,sizeof(T_BspFuRuRunRadioMode));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuFibrPort (*)
*  功能描述   : 获取FibrPort整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuFibrPort(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_OptSpeedList      speedList      = {0};
    T_BspFuRuFiberPort  fuRuFiberPort = {0};
    UINT32 loopSpeed = 0;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuFiberPort))
    {
        return BSP_ERROR;
    }
    memset(&speedList,     0,sizeof(T_OptSpeedList));
    memset(&fuRuFiberPort, 0,sizeof(T_BspFuRuFiberPort));
    fuRuFiberPort.ucFiberPortNum = (UCHAR)BspGetOptNum();/*光口数*/

    fuRuFiberPort.ucTopoCascadeNum = (UCHAR)BspGetTopoCascadeNum();/*链型组网时支持的级联数*/

    /*光口1可以自适应的速率，支持几G对应bit的填1，不支持的填0*/
    BspGetOptSpeedListAbility(&speedList);
    for(loopSpeed =0;loopSpeed < 4;loopSpeed++)
    {
        fuRuFiberPort.ausFiberPortSpeed[loopSpeed] = speedList.aulOptSpeed[loopSpeed];
    }
    memcpy(pRruAbilityFuInfo,&fuRuFiberPort,sizeof(T_BspFuRuFiberPort));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuComBin (*)
*  功能描述   : 获取ComBin整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuComBin(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuCombin  fuRuCombin = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuCombin))
    {
        return BSP_ERROR;
    }
    memset(&fuRuCombin,0,sizeof(T_BspFuRuCombin));
    /*是否支持并柜 0-不支持，1-支持*/

    fuRuCombin.ucCombin = BspGetRruCombin();
    memcpy(pRruAbilityFuInfo,&fuRuCombin,sizeof(T_BspFuRuCombin));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuAisgPortVolt (*)
*  功能描述   : 获取AisgPortVolt整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuAisgPortVolt(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    UINT32 loop           = 0;
    T_BspFuRuAisgPortVolt  fuRuAisgPortVolt = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuAisgPortVolt))
    {
        return BSP_ERROR;
    }
    memset(&fuRuAisgPortVolt,0,sizeof(T_BspFuRuAisgPortVolt));
    /*AISG口可配电压 0-0V,1-14V,2-24V,255-无效值*/
    for(loop = 0;loop < AISG_PWR_NUM;loop++)
    {
        if((UINT32)INVALID_VALUE != BspAdpGetBoardInputAisgVolt(loop))/*返回ok就支持*/
        {

            fuRuAisgPortVolt.ucAisgPortVolt |= BIT_SET(loop);
        }

    }
    memcpy(pRruAbilityFuInfo,&fuRuAisgPortVolt,sizeof(T_BspFuRuAisgPortVolt));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuDryContact (*)
*  功能描述   : 获取DryContact整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuDryContact(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuDryContact  fuRuDryContact = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuDryContact))
    {
        return BSP_ERROR;
    }
    memset(&fuRuDryContact,0,sizeof(T_BspFuRuDryContact));

    /*支持的输入干接点设备数目*/
    fuRuDryContact.ucInDryContactNum     = BspGetRruInDryContactNum();
    /*支持的输出干接点设备数目*/
    fuRuDryContact.ucOutputDryContactNum = BspGetRruOutDryContactNum();
    memcpy(pRruAbilityFuInfo,&fuRuDryContact,sizeof(T_BspFuRuDryContact));
    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspGetFuRuNsbt (*)
*  功能描述   : 获取Nsbt整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuNsbt(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuNsbt  fuRuNsbt = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuNsbt))
    {
        return BSP_ERROR;
    }
    memset(&fuRuNsbt,0,sizeof(T_BspFuRuNsbt));
    /*是否内置NSBT 0-不内置，1-内置*/
    fuRuNsbt.ucNSBT = (((UINT32)BSP_OK == BspGetNsbtIsSupport(0)) ? 1 : 0);
    memcpy(pRruAbilityFuInfo,&fuRuNsbt,sizeof(T_BspFuRuNsbt));
    return BSP_OK;

}

/********************************************************************
*  函数名称   : BspGetFuRuCrossDiversity (*)
*  功能描述   : 获取CrossDiversity整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuCrossDiversity(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuCrossDiversity       fuRuCrossDiversity = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuCrossDiversity))
    {
        return BSP_ERROR;
    }
    memset(&fuRuCrossDiversity,0,sizeof(T_BspFuRuCrossDiversity));

    fuRuCrossDiversity.ucCrossDiversity = BspGetRruCrossDiversity();;

    memcpy(pRruAbilityFuInfo,&fuRuCrossDiversity,sizeof(T_BspFuRuCrossDiversity));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRu9BitComperess (*)
*  功能描述   : 获取9BitComperess整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRu9BitComperess(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRu9BitCompress   fuRu9BitCompress = {0};;
    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRu9BitCompress))
    {
        return BSP_ERROR;
    }
    memset(&fuRu9BitCompress,0,sizeof(T_BspFuRu9BitCompress));
    /*是否支持9bit压缩 0-不支持，1-支持*/
    fuRu9BitCompress.ucSupport9BitCompress = BspGetRruSupport9BitCompress();
    memcpy(pRruAbilityFuInfo,&fuRu9BitCompress,sizeof(T_BspFuRu9BitCompress));
    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspGetFuRuDtx (*)
*  功能描述   : 获取Dtx整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/

UINT32 BspGetFuRuDtx(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuDtx  fuRuDtx = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuDtx))
    {
        return BSP_ERROR;
    }
    memset(&fuRuDtx,0,sizeof(T_BspFuRuDtx));

    fuRuDtx.ucSupportDtx = BspGetRruSupportDtx();

    memcpy(pRruAbilityFuInfo,&fuRuDtx,sizeof(T_BspFuRuDtx));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuLocalOsci (*)
*  功能描述   : 获取LocalOsci整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuLocalOsci(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    UINT32 loop = 0;
    T_BspFuRuLocalOsci fuRuLocalOsci = {0};

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuLocalOsci))
    {
        return BSP_ERROR;
    }
    memset(&fuRuLocalOsci,0,sizeof(T_BspFuRuLocalOsci));
    /*哪些通道共本振*/
    for(loop = 0;loop < BspGetTxChannel();loop++)
    {
        if (loop < NELEMENTS(fuRuLocalOsci.aulLocalOsci))
        {
            fuRuLocalOsci.aulLocalOsci[loop] = BspGetRruSupportLocalOsci(loop);
        }
    }
    memcpy(pRruAbilityFuInfo,&fuRuLocalOsci,sizeof(T_BspFuRuLocalOsci));
    return BSP_OK;

}
/********************************************************************
*  函数名称   : BspGetFuRuSuppLocalOsci (*)
*  功能描述   : 获取SuppLocalOsci整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuSuppLocalOsci(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    UINT32 loop = 0;
    T_BspFuRuSupportLocalOsci     fuRuSupportLocalOsci = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuSupportLocalOsci))
    {
        return BSP_ERROR;
    }
    memset(&fuRuSupportLocalOsci,0,sizeof(T_BspFuRuSupportLocalOsci));
    /*某通道与哪些通道可配置为共本振*/

    for(loop = 0;loop < BspGetTxChannel();loop++)
    {
        if (loop < NELEMENTS(fuRuSupportLocalOsci.aulSpportLocalOsciCfg))
        {
            fuRuSupportLocalOsci.aulSpportLocalOsciCfg[loop] =BspGetRruSupportLocalOsci(loop);
        }
    }

    memcpy(pRruAbilityFuInfo,&fuRuSupportLocalOsci,sizeof(T_BspFuRuSupportLocalOsci));
    return BSP_OK;

}

/********************************************************************
*  函数名称   : BspGetFuAntJump (*)
*  功能描述   : 获取AntJump整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuAntJump(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuAntJump  fuRuAntJump = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuAntJump))
    {
        return BSP_ERROR;
    }

    memset(&fuRuAntJump,0,sizeof(T_BspFuRuAntJump));
   
    fuRuAntJump.ucSupportAntJump = BspGetRruSupportAntJump();

    memcpy(pRruAbilityFuInfo,&fuRuAntJump,sizeof(T_BspFuRuAntJump));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuAasWorkMode (*)
*  功能描述   : 获取AasWorkMode整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuAasWorkMode (VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuAASWorkMode   fuRuAASWorkMode = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuAASWorkMode))
    {
        return BSP_ERROR;
    }
    memset(&fuRuAASWorkMode,0,sizeof(T_BspFuRuAASWorkMode));
    /*有源天线*/
    fuRuAASWorkMode.ucAASWorkMode = BspGetRruAASWorkMode();
    memcpy(pRruAbilityFuInfo,&fuRuAASWorkMode,sizeof(T_BspFuRuAASWorkMode));
    return BSP_OK;

}

/********************************************************************
*  函数名称   : BspGetFuRuUpDeleyAbilty (*)
*  功能描述   : 获取RU UpDeleyAbilty整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuUpDeleyAbilty(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuLteUpDelayAbility    fuRuLteUpDelayAbility = {0};;

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    /* 上行时延能力上报 */
    if(dataLen < sizeof(T_BspFuRuLteUpDelayAbility))
    {
        return BSP_ERROR;
    }
    memset(&fuRuLteUpDelayAbility, 0, sizeof(T_BspFuRuLteUpDelayAbility));
    /* 需要根据实际情况填写从FPGA中获取的时延上报能力 */
    fuRuLteUpDelayAbility.ulRuLteUpDelayAbility = BspGetUlDelayCmpAbility();
    memcpy(pRruAbilityFuInfo,&fuRuLteUpDelayAbility,sizeof(T_BspFuRuLteUpDelayAbility));
    return BSP_OK;
}

VOID BspSetIsFixTax(UCHAR isFixTax)
{
    s_IsFixTax = isFixTax;
}

static UCHAR BspGetIsFixTax(VOID)
{
    return s_IsFixTax;
}

/*IF1处理时延上报*/
UINT32 BspGetFuRuIf1Abilty(VOID *pRruAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuIf1Ability    fuRuIf1Ability = {0};

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    /* 上报RRU IF1处理时延 */
    if(dataLen < sizeof(T_BspFuRuIf1Ability))
    {
        return BSP_ERROR;
    }
    memset(&fuRuIf1Ability, 0, sizeof(T_BspFuRuIf1Ability));

    fuRuIf1Ability.dwIf1DiffDelay = BspGetIF1DiffDelay();/*单位：ns，为了和逻辑机型接口保持一致，实际未使用*/
    fuRuIf1Ability.isFixTAX = BspGetIsFixTax();

    memcpy(pRruAbilityFuInfo,&fuRuIf1Ability,sizeof(T_BspFuRuIf1Ability));
    return BSP_OK;
}

UINT32 BspRxSwChanToDivFlag(ULONG rxSwChan)
{
   return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuChanBaseInfo (*)
*  功能描述   : 获取RU 通道能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuChanBaseInfo(UINT32 chan,UINT32 dir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    INT32  ret       = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 loop      = 0;
    UINT32 startFreq = 0;
    UINT32 stopFreq  = 0;
    UINT32 bandflag  = 0;
    UINT32 antNo     = 0;
    UINT32 antChn    = 0;
    UINT32 bandLoop  = 0;
    UINT32 bandNum   = 0;
    UINT32 spreadBandInfo[] = {FREQ_2100M_BAND66};
    UINT32 spreadBandNum = NELEMENTS(spreadBandInfo);
    UINT32 txStartFreq[MAX_CHANBAND_NUM] = {0};
    UINT32 txEndFreq[MAX_CHANBAND_NUM]   = {0};
    UINT32 rxStartFreq[MAX_CHANBAND_NUM] = {0};
    UINT32 rxEndFreq[MAX_CHANBAND_NUM]   = {0};
    T_HwInfo *ptInfo = NULL;
    T_BspFuRuChlBaseInfo fuRuChlBaseInfo = {0};
    pGetChnBndSptInfo funGetChnBndSptInfo = NULL;

    RETURN_VAL_DO_IF_EXP(dataLen < sizeof(T_BspFuRuChlBaseInfo), BSP_ERROR, dbgErr("[%s]: dataLen failed\n", __FUNCTION__));

    funGetChnBndSptInfo = BspGetChnBndSptInfoInit();
    retVal |= BspGetAntInfoByBspChn(chan, dir, &antNo, &antChn);
    CHECK_RETVAL(BspGetAntInfoByBspChn, retVal);

    memset_s(&fuRuChlBaseInfo, sizeof(T_BspFuRuChlBaseInfo), 0,sizeof(T_BspFuRuChlBaseInfo));
    fuRuChlBaseInfo.ucAntNo = antNo;  /* 上报天线号按照1-4编号 */

    /*ANT编号*/
    ptInfo = (T_HwInfo*)BspGetGlobalRruHwInfo();
    bandNum = BspGetBandNumByBspChn(chan, dir);
    /* 标准频段编号，指示一个天线下的某个频段 */
    for(bandLoop = 0; bandLoop < min(bandNum, BSP_MAX_BAND_PER_CH); bandLoop ++)
    {
        /*get from board data */
        if(funGetChnBndSptInfo == NULL)
        {
            fuRuChlBaseInfo.aucStandardBandNo[bandLoop] = (UCHAR)ptInfo->BoardInfo.aulBoardBandFlag[chan][bandLoop];
        }
        /*get from rruproperty */
        else
        {
            if(BSP_ERROR == funGetChnBndSptInfo(chan,dir,bandLoop))
            {
                fuRuChlBaseInfo.aucStandardBandNo[bandLoop] = (UCHAR)ptInfo->BoardInfo.aulBoardBandFlag[chan][bandLoop];
            }
            else
            {
                fuRuChlBaseInfo.aucStandardBandNo[bandLoop] = (UCHAR)funGetChnBndSptInfo(chan,dir,bandLoop);
            }
        }
        
        if(TX == dir)
        {
            retVal |= BspAdpGetBoardFreqValue(chan,bandLoop,TX,START_FREQ_FLAG,   &txStartFreq[bandLoop]);
            retVal |= BspAdpGetBoardFreqValue(chan,bandLoop,TX,END_FREQ_FLAG,     &txEndFreq[bandLoop]);
        }
        if(RX == dir)
        {
            retVal |= BspAdpGetBoardFreqValue(chan,bandLoop,RX,START_FREQ_FLAG,   &rxStartFreq[bandLoop]);
            retVal |= BspAdpGetBoardFreqValue(chan,bandLoop,RX,END_FREQ_FLAG,     &rxEndFreq[bandLoop]);
        }

        //D42频段:扩频机型底层上报band

        //BspGetFilterFreqRangeModule(dir,chan, &startFreq, &stopFreq);
        retVal |= BspGetRruFreqValue(chan,bandLoop,dir,START_FREQ_FLAG,&startFreq);
        retVal |= BspGetRruFreqValue(chan,bandLoop,dir,END_FREQ_FLAG,&stopFreq);

        for(loop = 0; loop < spreadBandNum; loop++)
        {
            if(spreadBandInfo[loop] == fuRuChlBaseInfo.aucStandardBandNo[bandLoop])
            {
                if(BSP_OK == BspUpdateBandFlagByRruInfo(dir, startFreq, stopFreq, &bandflag))
                {
                    fuRuChlBaseInfo.aucStandardBandNo[bandLoop] = bandflag;
                    break;
                }
            }
        }
    }

    fuRuChlBaseInfo.ucDirection  = dir;
    fuRuChlBaseInfo.ucRfChlGroup = chan + 1;

    if(TX == dir)
    {
        ret = sprintf_s(fuRuChlBaseInfo.acStandardBandRange,80,"TX(%dKHz-%dKHz),TX(%dKHz-%dKHz)",txStartFreq[0],txEndFreq[0],txStartFreq[1],txEndFreq[1]);
        SNPRINTF_S_CHECK(ret, NELEMENTS(fuRuChlBaseInfo.acStandardBandRange));
        fuRuChlBaseInfo.ucDiversityFlag = 0;
    }
    if(RX == dir)
    {
        ret = sprintf_s(fuRuChlBaseInfo.acStandardBandRange,80,"RX(%dKHz-%dKHz),RX(%dKHz-%dKHz)",rxStartFreq[0],rxEndFreq[0],rxStartFreq[1],rxEndFreq[1]);
        SNPRINTF_S_CHECK(ret, NELEMENTS(fuRuChlBaseInfo.acStandardBandRange));
        fuRuChlBaseInfo.ucDiversityFlag = (UCHAR)BspRxSwChanToDivFlag((UINT32)chan);
    }

    memcpy_s(pRruChlAbilityFuInfo, sizeof(T_BspFuRuChlBaseInfo), &fuRuChlBaseInfo, sizeof(T_BspFuRuChlBaseInfo));

    return retVal;
}

/********************************************************************
*  函数名称   : BspGetFuRuChanBandWidth (*)
*  功能描述   : 获取RU 通道带宽能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuChanBandWidth(UINT32 chan,UINT32 dir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuChlBandWidth fuRuChlBandWidth = {0};
    UINT32 bandLoop     = 0;
    UINT32 startFreq    = 0;
    UINT32 endFreq      = 0;
    UINT32 ifBandWidth  = 0;
    UINT32 dpdBWfromBsp = 0;	
	/* UINT32 retVal           = BSP_OK; */
    if(dataLen < sizeof(T_BspFuRuChlBandWidth))
    {
        return BSP_ERROR;
    }
		
    memset(&fuRuChlBandWidth,0,sizeof(T_BspFuRuChlBandWidth));

    for(bandLoop = 0;bandLoop < BspGetBandNumByBspChn(chan,dir);bandLoop ++)
    {
        /*起始频点*/ /* 结束频点 */
        BspGetRruFreqValue(chan,bandLoop,dir,START_FREQ_FLAG,&startFreq);
        BspGetRruFreqValue(chan,bandLoop,dir,END_FREQ_FLAG,&endFreq);
        fuRuChlBandWidth.aulStartFreq[bandLoop] = startFreq;
        fuRuChlBandWidth.aulEndFreq[bandLoop]   = endFreq;

    }

    /* 通道处理带宽 BSP内部的通道组概念*/
    for(bandLoop = 0;bandLoop < BspGetBandNumByBspChn(chan,dir);bandLoop ++)
    {
        /*BspGetDPDBandWidthFromBsp(rfChn,&ulDpdBWfromBsp);TODO :DSP 带宽暂时写死，后续从单板传入*/
        dpdBWfromBsp = 100000;
        BspAdpGetBoardIfFreqRange(chan, bandLoop,dir, &ifBandWidth);
        fuRuChlBandWidth.aulChlBandWidth[bandLoop]    = ifBandWidth;
        fuRuChlBandWidth.aulChlDpdBandWidth[bandLoop] = dpdBWfromBsp;
    }
    /******************end************************/
    memcpy(pRruChlAbilityFuInfo,&fuRuChlBandWidth,sizeof(T_BspFuRuChlBandWidth));
    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspGetFuRuChanPower (*)
*  功能描述   : 获取RU 通道功率能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuChanPower(UINT32 chan,UINT32 dir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuChlPower fuRuChlPower = {0};
    UINT32 ratedPower    = 0;   
    /* UINT32 retVal    	 = BSP_OK; */
	
    if(dataLen < sizeof(T_BspFuRuChlPower))
    {
        return BSP_ERROR;
    }	
	
    memset(&fuRuChlPower,0,sizeof(T_BspFuRuChlPower));

     /* RU整机的标称功率*/
    BspGetRruPathRatedPower(chan,&ratedPower);
    fuRuChlPower.ulRuNominalPow = ratedPower;
    /* RU整机可使用标称功率 */
    fuRuChlPower.ulRuAvailNominalPow = ratedPower;
    memcpy(pRruChlAbilityFuInfo,&fuRuChlPower,sizeof(T_BspFuRuChlPower));

    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspGetFuRuChanRadioMode (*)
*  功能描述   : 获取RU 通道制式能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuChanRadioMode(UINT32 ulChan,UINT32 ulDir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuChlRadioMode         fuRuChlRadioMode = {0};
    if(dataLen < sizeof(T_BspFuRuChlRadioMode))
    {
        return BSP_ERROR;
    }
    memset(&fuRuChlRadioMode,0,sizeof(T_BspFuRuChlRadioMode));    
    fuRuChlRadioMode.usChlRadioMode = BspGetRadioStandard();
    memcpy(pRruChlAbilityFuInfo,&fuRuChlRadioMode,sizeof(T_BspFuRuChlRadioMode));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuChanCarrier (*)
*  功能描述   : 获取RU 载波能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuChanCarrier(UINT32 chan,UINT32 dir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuChlCarrier           fuRuChlCarrier = {0};
	/* UINT32 retVal = BSP_OK; */
    if(dataLen < sizeof(T_BspFuRuChlCarrier))
    {
        return BSP_ERROR;
    }
    memset(&fuRuChlCarrier,0,sizeof(T_BspFuRuChlCarrier));
    BspGetCarrierNumAndWidth(chan,dir,&fuRuChlCarrier);
    memcpy(pRruChlAbilityFuInfo,&fuRuChlCarrier,sizeof(T_BspFuRuChlCarrier));

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetFuRuChanDflGain (*)
*  功能描述   : 获取RRU通道双工器增益能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetFuRuChanDflGain(UINT32 ulChan,UINT32 ulDir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    T_BspFuRuChlDflGain           fuRuChlDflGain = {0};
    UINT32 ulDflMin   = 0;
    UINT32 ulDflMax   = 0;
     if(dataLen < sizeof(T_BspFuRuChlDflGain))
    {
        return BSP_ERROR;
    }
    memset(&fuRuChlDflGain,0,sizeof(T_BspFuRuChlDflGain));

    /* 双工器增益 无法填充，一个最小增益，一个最大增益*/
    /*BspAdpGetDflLanGain(0,&ulDflMin,&ulDflMax);  TODO :后续实现*/
    fuRuChlDflGain.aulDflGain[0] =  ulDflMin;
    fuRuChlDflGain.aulDflGain[1] =  ulDflMax;
    fuRuChlDflGain.ucDfGainContinuation = 1;
    memcpy(pRruChlAbilityFuInfo,&fuRuChlDflGain,sizeof(T_BspFuRuChlDflGain));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRaiseTptlGateAbility (*)
*  功能描述   : 获取整机提升闭环功控门限能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 巴伦老化导致下行掉增益,为减少外场故障返修率,闭环门限从6db提升至更高
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRaiseTptlGateAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportRaiseTptlGate fuRuSupportRaiseTptlGate = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuSupportRaiseTptlGate))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportRaiseTptlGate, sizeof(T_BspFuRuSupportRaiseTptlGate), 0, sizeof(T_BspFuRuSupportRaiseTptlGate));

    fuRuSupportRaiseTptlGate.usSupportRaiseTptlGate = (UINT16)BspGetRruRaiseTptlGateAbility();

    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportRaiseTptlGate, sizeof(T_BspFuRuSupportRaiseTptlGate));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruRailModeAbility (*)
*  功能描述   : 获取整机是否支持5G-R模式能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRruRailModeAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportRailMode fuRuSupportRailMode = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(fuRuSupportRailMode))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuSupportRailMode.usSupportRailMode = (UINT16)BspGetRruSupport5GRAbility();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportRailMode, sizeof(T_BspFuRuSupportRailMode));

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruVswrGateChanMask (*)
*  功能描述   : 获取RRU整机从片通道掩码进行驻波门限策略修改
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
/* Started by AICoder, pid:ib928x3890e4b9914760085ff016822b72442072 */
UINT32 BspGetRruVswrGateChanMask(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuVswrGateChanMaskAdapt chanMaskAdapt = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuVswrGateChanMaskAdapt))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    chanMaskAdapt.chanMask = BspGetVswrGateAdaptChanMask();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &chanMaskAdapt, sizeof(T_BspFuRuVswrGateChanMaskAdapt));

    return BSP_OK;
}
/* Ended by AICoder, pid:ib928x3890e4b9914760085ff016822b72442072 */

/********************************************************************
*  函数名称   : BspGetRruMtsTempPtxAbility (*)
*  功能描述   : 获取整机是否支持使用MTS温度进行反馈开环校准
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRruMtsTempPtxAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportMtsTempPtx fuRuSupportMtsPtx = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(fuRuSupportMtsPtx))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuSupportMtsPtx.usSupportMtsPtxFlag = (UINT16)BspGetRruMtsTempPtxFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportMtsPtx, sizeof(T_BspFuRuSupportMtsTempPtx));

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetBasebandMergAbility (*)
*  功能描述   : 获取整机支持软劈裂基带合并的能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetBasebandMergAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportBasebandMerg fuRuSupportBasebandMerg = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuSupportBasebandMerg))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportBasebandMerg, sizeof(T_BspFuRuSupportBasebandMerg), 0, sizeof(T_BspFuRuSupportBasebandMerg));

    fuRuSupportBasebandMerg.usSupportBasebandMerg = (UINT16)BspGetRruBasebandMergAbility();

    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportBasebandMerg, sizeof(T_BspFuRuSupportBasebandMerg));
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruVswrOptMizeInfo (*)
*  功能描述   : 获取整机是否支持驻波优化信息
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2024-02-22 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRruVswrOptMizeInfo(VOID *pvRruSupportMVswrOptMizeInfo, UINT32 dataLen)
{
    T_BspFuRuSupportVswrOptMizeInfo fuRuSupportMVswrOptMizeInfo = {0};

    INPUT_POINTER_CHECK(pvRruSupportMVswrOptMizeInfo);

    if(dataLen < sizeof(fuRuSupportMVswrOptMizeInfo))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuSupportMVswrOptMizeInfo.usSupportVswrOptMizeFlag = BspGetRruVswrOptMizeFlag();
    fuRuSupportMVswrOptMizeInfo.ulChanMask = BspGetRruVswrOptMizeChanMask();
    memcpy_s(pvRruSupportMVswrOptMizeInfo, dataLen, &fuRuSupportMVswrOptMizeInfo, sizeof(fuRuSupportMVswrOptMizeInfo));

    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspGetRruAvgPaptAbility (*)
*  功能描述   : 获取整机是否Avg 保护降额
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAvgPaptAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),
*--------------------------------------------------------------------
*/
UINT32 BspGetRruAvgPaptAbility(VOID *pvRruSupportAvgPaptInfo, UINT32 dataLen)
{
    T_BspFuRuSupportAvgPaptInfo fuRuSupportAvgPaptInfo = {0};

    INPUT_POINTER_CHECK(pvRruSupportAvgPaptInfo);
    if(dataLen < sizeof(T_BspFuRuSupportAvgPaptInfo))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }
    fuRuSupportAvgPaptInfo.usSupportAvgPaptFlag = s_supportAvgPaptSpeCtrlFlag;
    fuRuSupportAvgPaptInfo.ulChanMask = s_supportAvgPaptSpeCtrlChanMask;
    memcpy_s(pvRruSupportAvgPaptInfo, dataLen, &fuRuSupportAvgPaptInfo, sizeof(T_BspFuRuSupportAvgPaptInfo));

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruPwrLetTempChkAbility (*)
*  功能描述   : 获取整机是否支持电源连接器过温检测
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2024-02-22 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRruPwrLetTempChkAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportPwrLetTempChk fuRuSupportPwrLetTempChk = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(fuRuSupportPwrLetTempChk))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuSupportPwrLetTempChk.usSupportPwrLetTempChkFlag = (UINT16)BspGetRruPwrLetTempCheckFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportPwrLetTempChk, sizeof(T_BspFuRuSupportPwrLetTempChk));

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruUaeModeAbility (*)
*  功能描述   : 获取 整机是否支持阿联酋模式整机过温门限美化
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2024-02-22 08:19:00
*--------------------------------------------------------------------
*/
/* Started by AICoder, pid:147fef24c7de06414f510b4be02bd11e0e07b19c */
UINT32 BspGetRruUaeModeAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportUaeMode fuRuSupportUaeMode = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(fuRuSupportUaeMode))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuSupportUaeMode.usSupportUaeModeFlag = (UINT16)BspGetRruAueModeFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportUaeMode, sizeof(T_BspFuRuSupportUaeMode));
    dbgInfoEx("%s: usSupportUaeModeFlag: %d\n", __FUNCTION__, fuRuSupportUaeMode.usSupportUaeModeFlag);

    return BSP_OK;
}
/* Ended by AICoder, pid:147fef24c7de06414f510b4be02bd11e0e07b19c */

/********************************************************************
*  函数名称   : BspGetRruPlcConfigAbility (*)
*  功能描述   : 获取 整机PLC配置能力情况
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*--------------------------------------------------------------------
*/
UINT32 BspGetRruPlcConfigAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuPlcCongfigInfo fuRuPlcCfg = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(fuRuPlcCfg))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuPlcCfg.usSupportPlcFlag = (UINT16)BspGetRruPlcSupportFlag();
    fuRuPlcCfg.usSupportRequestVer = (UINT16)BspGetRruSupportRequestVer();
    fuRuPlcCfg.usPlcChipType = (UINT16)BspGetRruPlcChipType();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuPlcCfg, sizeof(T_BspFuRuPlcCongfigInfo));
    dbgInfoEx("%s: usSupportPlcFlag: %d, usSupportRequestVer: %d, usPlcChipType:%d\n",  __FUNCTION__,
                   fuRuPlcCfg.usSupportPlcFlag, fuRuPlcCfg.usSupportRequestVer, fuRuPlcCfg.usPlcChipType);

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetNcrIsolationDetectionAbility (*)
*  功能描述   : 获取 NCR机型是否支持隔离度检测
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A)
*--------------------------------------------------------------------
*/
/* Started by AICoder, pid:ed53dy3f381c57a14e1d0860204f6a18ff478a86 */
UINT32 BspGetNcrIsolationDetectionAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspSupportIsolationDetection cfgParaInfo = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(cfgParaInfo))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    cfgParaInfo.usSupportFlag = (UINT16)BspGetIsolationDetectionFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &cfgParaInfo, sizeof(T_BspSupportIsolationDetection));
    dbgInfoEx("%s: usSupportFlag: %d\n", __FUNCTION__, cfgParaInfo.usSupportFlag);

    return BSP_OK;
}
/* Ended by AICoder, pid:ed53dy3f381c57a14e1d0860204f6a18ff478a86 */
/********************************************************************
*  函数名称   : BspGetRruAutoAdjustVoltAbility (*)
*  功能描述   : 获取整机是否支持自动调压
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*--------------------------------------------------------------------
*/
UINT32 BspGetRruAutoAdjustVoltAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuSupportAutoAdjustVolt))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    T_BspFuRuSupportAutoAdjustVolt *fuRuSupportAutoAdjustVolt = BspGetRruAutoVoltAbility();
    if(NULL == fuRuSupportAutoAdjustVolt)
    {
        dbgErr("[%s]BspGetRruAutoVoltAbility\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memcpy_s(pvRruAbilityFuInfo, dataLen, fuRuSupportAutoAdjustVolt, sizeof(T_BspFuRuSupportAutoAdjustVolt));

    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruPwrLetTempChkAbility (*)
*  功能描述   : 获取整机是否支持模拟过功率降额3dB变更为开环定标
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   :
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2024-02-22 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRruOverPowToOpenLoopAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportOverPowToOpenLoop fuRuSupportOverPowToOpenLoop = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(fuRuSupportOverPowToOpenLoop))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuSupportOverPowToOpenLoop.usSupportOverPowToOpenLoopFlag = (UINT16)BspGetOverPowToOpenLoopAbility();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportOverPowToOpenLoop, sizeof(T_BspFuRuSupportOverPowToOpenLoop));

    return BSP_OK;
}

UINT32 BspInitRruChlAblityPara(VOID)
{
    UINT32 rruRruAbilityNum = 0;
    UINT32 retVal = BSP_OK;
    
    rruRruAbilityNum = NELEMENTS(rruAbilityInfo);
    retVal = BspSetRruAbilityInfo(rruAbilityInfo,rruRruAbilityNum);
    
    return retVal;
}

UINT32 BspInitRruAbilityPara(VOID)
{
    UINT32 rruChnRruAbilityNum = 0;
    UINT32 retVal = BSP_OK;    
    rruChnRruAbilityNum = NELEMENTS(rruChnAbilityInfo);
    retVal = BspSetRruChnAbilityInfo(rruChnAbilityInfo,rruChnRruAbilityNum);
    return retVal;
}

UINT32 BspInitRruSpecialAbilityPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 rruSpecialAbilityNum = 0;

    rruSpecialAbilityNum = NELEMENTS(rruSpAbilityInfo);
    retVal = BspSetRruSpecialAbilityInfo(rruSpAbilityInfo, rruSpecialAbilityNum);

    return retVal;
}

UINT32 BspInitRruAbilityInfo(VOID)
{
    UINT32 retVal = BSP_OK;
    retVal |= BspInitRruChlAblityPara();
    retVal |= BspInitRruAbilityPara();
    retVal |= BspInitRruSpecialAbilityPara();
    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspInitRruAbilityFunc (*)
*  功能描述   : 初始化rru 能力上报模块
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFUDataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/

UINT32 BspInitRruAbilityFunc(VOID)
{
    return BspInitRruAbilityInfo();
}

/**************************************************************************
 * 函数名称 : BspSetVswrPosOnlineDetectionAbility
 * 功能描述 : 设置RRU支持在线驻波位置检测能力
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetVswrPosOnlineDetectionAbility(UINT32 supportFlag)
{
    s_supportVswrPosOnlineDetection = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetVswrPosOnlineDetectionAbility
 * 功能描述: 获取RRU支持在线驻波位置检测能力
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetVswrPosOnlineDetectionAbility(VOID)
{
    return s_supportVswrPosOnlineDetection;
}

/**************************************************************************
 * 函数名称 : BspSetVswrGateResetFlag
 * 功能描述 : 设置RRU支持驻波门限重置能力
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetVswrGateResetFlag(UINT32 supportFlag)
{
    s_supportVswrGateReset = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetVswrGateResetFlag
 * 功能描述: 获取RRU支持驻波门限重置能力
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetVswrGateResetFlag(VOID)
{
    return s_supportVswrGateReset;
}
/********************************************************************
*  函数名称   : BspGetVswrPosOnlineDetectAbility
*  功能描述   : 获取整机支持在线驻波位置检测和驻波门限重置能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetVswrPosOnlineDetectAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportVswrPosOnlineDetect fuRuSupportVswrPosOnlineDetect = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportVswrPosOnlineDetect))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportVswrPosOnlineDetect, sizeof(T_BspFuRuSupportVswrPosOnlineDetect), 0, sizeof(T_BspFuRuSupportVswrPosOnlineDetect));
    fuRuSupportVswrPosOnlineDetect.usSupportVswrPosOnlineDetect = (UINT16)BspGetVswrPosOnlineDetectionAbility();
    fuRuSupportVswrPosOnlineDetect.usSupportVswrGateReset = (UINT16)BspGetVswrGateResetFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportVswrPosOnlineDetect, sizeof(T_BspFuRuSupportVswrPosOnlineDetect));

    return BSP_OK;
}

UINT32 BspSetRruCarrRangeCapture(T_RruFreqIdCaCap *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    s_pRruCarrRangeCap = pPara;
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruCarrRangeCapture
*  功能描述   : 获取RRU支持的载波号范围信息
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetRruCarrRangeCapture(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    if (pvRruAbilityFuInfo == NULL)
    {
        dbgErr("[%s] Get Carr Range Failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(dataLen < sizeof(T_RruFreqIdCaCap))
    {
        return BSP_ERROR;
    }
    if (s_pRruCarrRangeCap == NULL)
    {
        dbgInfoEx("[%s] Get Carr Range Failed1\n", __FUNCTION__);
        memcpy_s(pvRruAbilityFuInfo, sizeof(T_RruFreqIdCaCap), &s_rruCarrRangeCapInfo, sizeof(T_RruFreqIdCaCap));
        return BSP_OK;
    }

    memcpy_s(pvRruAbilityFuInfo, sizeof(T_RruFreqIdCaCap), s_pRruCarrRangeCap, sizeof(T_RruFreqIdCaCap));

    return BSP_OK;
}

/*RRU上报 是否需要BBU把FDD载波固定一个光口  TDD固定到另一个光口下发*/
UINT32 BspSetRruCarrOptBindPara(T_BspFuRuCarrOptBindPara *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    memcpy_s(&s_rruCarrOptBindPara, sizeof(T_BspFuRuCarrOptBindPara), pPara, sizeof(T_BspFuRuCarrOptBindPara));
    return BSP_OK;
}

UINT32 BspGetRruCarrOptBindPara(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    if (pvRruAbilityFuInfo == NULL)
    {
        dbgErr("[%s] Get Carr Range Failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(dataLen < sizeof(T_BspFuRuCarrOptBindPara))
    {
        return BSP_ERROR;
    }

    memcpy_s(pvRruAbilityFuInfo, sizeof(T_BspFuRuCarrOptBindPara), &s_rruCarrOptBindPara, sizeof(T_BspFuRuCarrOptBindPara));

    return BSP_OK;
}
/* Started by AICoder, pid:y533543313w51e614cea0a6760a9f95b8a808c53 */
/**************************************************************************
 * 函数名称 : BspSetTempCompsFlag
 * 功能描述 : 设置整机支持是否支持温补特殊方案
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetTempCompsFlag(UINT32 supportFlag)
{
    s_supportTempCompsFlag = supportFlag;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetTempCompsFlag
 * 功能描述: 获取整机支持是否支持温补特殊方案
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetTempCompsFlag(VOID)
{
    return s_supportTempCompsFlag;
}
/********************************************************************
*  函数名称   : BspGetTempCompsFlagAbility
*  功能描述   : 获取整机支持是否支持温补特殊方案 1:支持, 0:不支持
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetTempCompsFlagAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuTempCompsFlag fuRuTempCompsFlag = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuTempCompsFlag))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuTempCompsFlag, sizeof(T_BspFuRuTempCompsFlag), 0, sizeof(T_BspFuRuTempCompsFlag));
    fuRuTempCompsFlag.usTempCompsFlag = (UINT16)BspGetTempCompsFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuTempCompsFlag, sizeof(T_BspFuRuTempCompsFlag));

    return BSP_OK;
}
/* Ended by AICoder, pid:y533543313w51e614cea0a6760a9f95b8a808c53 */

/* Started by AICoder, pid:g45739b38cc7a8d1446f083be02d3f669cd2d67a */
/**************************************************************************
 * 函数名称 : BspSetDigitalPhaseShifterAlarmFlag
 * 功能描述 : 设置RRU支持数字移相器告警功能
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetDigitalPhaseShifterAlarmFlag(UINT32 supportFlag)
{
    s_supportDigitalPhaseShifterAlarm = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetDigitalPhaseShifterAlarmFlag
 * 功能描述: 获取RRU支持数字移相器告警功能
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetDigitalPhaseShifterAlarmFlag(VOID)
{
    return s_supportDigitalPhaseShifterAlarm;
}

/********************************************************************
*  函数名称   : BspGetDigitalPhaseShifterAlarmAbility
*  功能描述   : 获取整机支持数字移相器告警功能能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetDigitalPhaseShifterAlarmAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportDigitalPhaseShifterAlarm fuRuSupportDigitalPhaseShifterAlarm = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportDigitalPhaseShifterAlarm, sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm), 0, sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm));
    fuRuSupportDigitalPhaseShifterAlarm.usSupportDigitalPhaseShifterAlarm = (UINT16)BspGetDigitalPhaseShifterAlarmFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportDigitalPhaseShifterAlarm, sizeof(T_BspFuRuSupportDigitalPhaseShifterAlarm));

    return BSP_OK;
}
/* Ended by AICoder, pid:g45739b38cc7a8d1446f083be02d3f669cd2d67a */

/* Started by AICoder, pid:qfd6ay959cg159a144030b1c80c8426cd9e23c7f */
/**************************************************************************
 * 函数名称 : BspSetSupportUnionAntFlag
 * 功能描述 : 设置RRU支持多通道共天线
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetSupportUnionAntFlag(UINT32 supportFlag)
{
    s_supportUnionAnt = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetSupportUnionAntFlag
 * 功能描述: 获取RRU支持多通道共天线
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetSupportUnionAntFlag(VOID)
{
    return s_supportUnionAnt;
}

/********************************************************************
*  函数名称   : BspGetSupportUnionAntAbility
*  功能描述   : 获取整机支持多通道共天线能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetSupportUnionAntAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportUnionAnt fuRuSupportUnionAnt = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportUnionAnt))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportUnionAnt, sizeof(T_BspFuRuSupportUnionAnt), 0, sizeof(T_BspFuRuSupportUnionAnt));
    fuRuSupportUnionAnt.usSupportUnionAnt = (UINT16)BspGetSupportUnionAntFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportUnionAnt, sizeof(T_BspFuRuSupportUnionAnt));

    return BSP_OK;
}
/* Ended by AICoder, pid:qfd6ay959cg159a144030b1c80c8426cd9e23c7f */

/* Started by AICoder, pid:3a481d7df5a2487fbf13c1646bb5ee80 */
UINT32 BspGetRruBandVswrAbility(VOID *pRruAbilityFuInfo, UINT32 dataLen)
{
    T_RruSupportBandVswrFlag bandVswrFlag = {0};

    INPUT_POINTER_CHECK(pRruAbilityFuInfo);
    if(dataLen < sizeof(pRruAbilityFuInfo))
    {
        return BSP_ERROR;
    }

    memset_s(&bandVswrFlag, sizeof(T_RruSupportBandVswrFlag), 0, sizeof(T_RruSupportBandVswrFlag));
    bandVswrFlag.isSupportBandVswrFlag = BspGetBandVswrFlag();
    memcpy_s(pRruAbilityFuInfo, dataLen, &bandVswrFlag, sizeof(T_RruSupportBandVswrFlag));
    return BSP_OK;
}
/* Ended by AICoder, pid:3a481d7df5a2487fbf13c1646bb5ee80 */

/* Started by AICoder, pid:9dbae97c0be981d14f500a07e1c076351cd22ffe */
/**
 * @brief 设置整机最大功耗限制信息
 * @param supportFlag 支持能力标志, 1:支持, 0:不支持
 * @param maxPowMw 最大限制功耗 单位 mw
 * @return BSP_OK - 成功; 其它值为失败
 */
UINT32 BspSetMaxPowLimitInfo(UINT32 supportFlag, INT32 maxPowMw)
{
    if (maxPowMw <= 0)
    {
        dbgErr("[%s]maxPowMw:%d must be positive\n", __FUNCTION__, maxPowMw);
        return BSP_ERROR;
    }
    s_supportMaxPowLimitFlag = supportFlag;
    s_maxPowMw = maxPowMw;
    return BSP_OK;
}

/**
 * @brief 获取最大功耗限制能力
 * @return 支持能力标志
 */
UINT32 BspGetMaxPowLimitAbility(VOID)
{
    return s_supportMaxPowLimitFlag;
}

/**
 * @brief 获取最大功耗限制值
 * @return 最大功耗限制值 (单位: mw)
 */
INT32 BspGetMaxPow(VOID)
{
    return s_maxPowMw;
}

/**
 * @brief 获取RRU最大功耗限制能力
 * @param pvRruSupportMaxPowLimitInfo 输出结构体指针
 * @param dataLen 数据长度
 * @return BSP_OK - 成功; 其它值为失败
 */
UINT32 BspGetRruMaxPowLimitAbility(VOID *pvRruSupportMaxPowLimitInfo, UINT32 dataLen)
{
    T_BspFuRuSupportMaxPowLimitInfo fuRuSupportMaxPowLimitInfo = {0};

    INPUT_POINTER_CHECK(pvRruSupportMaxPowLimitInfo);
    if (dataLen < sizeof(T_BspFuRuSupportMaxPowLimitInfo))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }
    fuRuSupportMaxPowLimitInfo.supportMaxPowLimitFlag = s_supportMaxPowLimitFlag;
    fuRuSupportMaxPowLimitInfo.maxPowMw = s_maxPowMw;
    memcpy_s(pvRruSupportMaxPowLimitInfo, dataLen, &fuRuSupportMaxPowLimitInfo, sizeof(T_BspFuRuSupportMaxPowLimitInfo));

    return BSP_OK;
}
/* Ended by AICoder, pid:9dbae97c0be981d14f500a07e1c076351cd22ffe */
/* Started by AICoder, pid:4844c8e038jde4d1492b0a2ba0cf342fc3d6d8f4 */
UINT32 BspGetSupportIcPathChnFlag(void)
{
    return g_ulSupportIcPathChnFlag;
}
void BspSetSupportIcPathChnFlag(UINT32 flag)
{
    g_ulSupportIcPathChnFlag = flag;
}
UINT32 BspGetSupportIcPathChgAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportIcPathChg fuRuSupportIcPathChg = {0};
    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if (dataLen < sizeof(T_BspFuRuSupportIcPathChg))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }
    fuRuSupportIcPathChg.supportIcPathChgFlag = BspGetSupportIcPathChnFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportIcPathChg, sizeof(T_BspFuRuSupportIcPathChg));
    return BSP_OK;
}
/* Ended by AICoder, pid:4844c8e038jde4d1492b0a2ba0cf342fc3d6d8f4 */

/* Started by AICoder, pid:nbe25hfabfo2b2d14ddf0a0ae02b2035af76e026 */
UINT32 BspGetSupportIF0IF1Flag()
{
    return s_supportIF0IF1Flag;
}

VOID BspSetSupportIF0IF1Flag(UINT32 flag)
{
    s_supportIF0IF1Flag = flag;
}

UINT32 BspGetSupprtSampleRateFlag()
{
    return s_supportSampleRate;
}

VOID BspSetSupprtSampleRateFlag(UINT32 flag)
{
    s_supportSampleRate = flag;
}

/*T+F机型在fdd主片上报tdd从片的ID01能力 只用于tdd 高层只在tdd调用*/
UINT32 BspGetIF0IF1SplitAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportIF0IF1Split fuRuIF0IF1SplitInfo = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportIF0IF1Split))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuIF0IF1SplitInfo, sizeof(T_BspFuRuSupportIF0IF1Split), 0, sizeof(T_BspFuRuSupportIF0IF1Split));
    fuRuIF0IF1SplitInfo.supportIF0IF1Flag = BspGetSupportIF0IF1Flag();
    fuRuIF0IF1SplitInfo.sampleRate = BspGetSupprtSampleRateFlag();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuIF0IF1SplitInfo, sizeof(T_BspFuRuSupportIF0IF1Split));

    return BSP_OK;
}
/* Ended by AICoder, pid:nbe25hfabfo2b2d14ddf0a0ae02b2035af76e026 */

UINT32 BspSetRruNtfSolutionAbility(UINT32 solution)
{
    s_supportNtfNewSolution = solution;
    return BSP_OK;
}

UINT32 BspGetRruNtfSolutionAbility(VOID)
{
    return s_supportNtfNewSolution;
}

/********************************************************************
*  函数名称   : BspGetNtfSolutionAbility (*)
*  功能描述   : 获取硬件自检新接口支持能力
*  输入参数   : dataLen  - 整机能力功能长度
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 获取是否支持NTF新方案
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-23 08:19:00
*--------------------------------------------------------------------
*/
UINT32 BspGetNtfSolutionAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportNtfSolution fuRuSupportNtfSolution = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(T_BspFuRuSupportNtfSolution))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportNtfSolution, sizeof(T_BspFuRuSupportRaiseTptlGate), 0, sizeof(T_BspFuRuSupportRaiseTptlGate));

    fuRuSupportNtfSolution.supportNtfSolution = (UINT16)BspGetRruNtfSolutionAbility();

    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportNtfSolution, sizeof(T_BspFuRuSupportRaiseTptlGate));
    return BSP_OK;
}

/* Started by AICoder, pid:sc4cc6f403m0ab21432008d9d0303c76a9f405ad */
/**************************************************************************
 * 函数名称 : BspSetVswrPosOnlineDetectionAbility
 * 功能描述 : 设置整机变更过驻波降额策略
 * 输入参数 : supportFlag:支持能力标志, 1:支持, 0:不支持
 * 输出参数 : 无
*  返 回 值 : BSP_OK - 成功; 其它值为失败
 * 其它说明 : 无
 **************************************************************************/
UINT32 BspSetVswrDeratingAbility(UINT32 supportFlag)
{
    s_supportVswrDerating = supportFlag;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetVswrPosOnlineDetectionAbility
 * 功能描述: 获取RRU整机变更过驻波降额策略能力
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetVswrDeratingAbility(VOID)
{
    return s_supportVswrDerating;
}

INT32 BspSetVswrDeratingThreshold(INT32 val)
{
    s_vswrDeratingThre = val;
    return s_vswrDeratingThre;
}

INT32 BspGetVswrDeratingThreshold(VOID)
{
    return s_vswrDeratingThre;
}

INT32 BspSetVswrRecoveryThreshold(INT32 val)
{
    s_vswrRecoveryThre = val;
    return s_vswrRecoveryThre;
}

INT32 BspGetVswrRecoveryThreshold(VOID)
{
    return s_vswrRecoveryThre;
}

UINT32 BspGetSupportVswrDeratingAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportVswrDeratingInfo fuRuSupportVswrDerating = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuSupportVswrDeratingInfo))
    {
        return BSP_ERROR;
    }
    memset_s(&fuRuSupportVswrDerating, sizeof(T_BspFuRuSupportVswrDeratingInfo), 0, sizeof(T_BspFuRuSupportVswrDeratingInfo));
    fuRuSupportVswrDerating.vswrDeratingFlag = BspGetVswrDeratingAbility();
    fuRuSupportVswrDerating.vswrDeratingThreshold = BspGetVswrDeratingThreshold();
    fuRuSupportVswrDerating.vswrRecoveryThreshold = BspGetVswrRecoveryThreshold();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportVswrDerating, sizeof(T_BspFuRuSupportVswrDeratingInfo));

    return BSP_OK;
}

UINT32 BspSetRruUmtsRssiOptmizeAbility(USHORT supportFlag)
{
    s_supportUmtsRssiOptmize = supportFlag;
    return BSP_OK;
}

USHORT BspGetRruUmtsRssiOptmizeAbility(VOID)
{
    return s_supportUmtsRssiOptmize;
}

UINT32 BspGetRruUmtsRssiOptmizeSwAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    T_BspFuRuSupportUmtsRssiOptmize fuRuSupportRssiOptmize = {0};

    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);

    if(dataLen < sizeof(fuRuSupportRssiOptmize))
    {
        dbgErr("[%s]dataLen:%d, Get Failed\n", __FUNCTION__, dataLen);
        return BSP_ERROR;
    }

    fuRuSupportRssiOptmize.usUmtsRssiOptmizeFlag = BspGetRruUmtsRssiOptmizeAbility();
    memcpy_s(pvRruAbilityFuInfo, dataLen, &fuRuSupportRssiOptmize, sizeof(T_BspFuRuSupportUmtsRssiOptmize));

    return BSP_OK;
}

/* Ended by AICoder, pid:sc4cc6f403m0ab21432008d9d0303c76a9f405ad */

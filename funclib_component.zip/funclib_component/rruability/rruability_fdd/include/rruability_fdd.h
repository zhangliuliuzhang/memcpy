/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : rruability_fdd.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了rruablity接口声明
* 注意事项 : 无
* 作    者 :   wangfei10102065
* 创建日期 : 2018-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei10102065
* 修改日戳: 2018-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_RRUABILITY_FDD_H_
#define _FUNCLIB_RRUABILITY_FDD_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "bspcomm.h"
#include "bsppub.h"
#include "rruabilitycommon.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define DELAY_CMP_FUNC_NOT_SUPPORT             0xFFFFFFFF
#define RRU_SUPPORT_RAISE_TPTL_GATE           ((UINT32)1)  /*整机支持闭环功控门限从6db提升至更大*/
#define RRU_NOT_SUPPORT_RAISE_TPTL_GATE       ((UINT32)0)  /*整机不支持闭环功控门限从6db提升至更大*/
#define RRU_SUPPORT_5GR_MODE                  ((UINT32)1)  /*整机支持5R-R模式*/
#define RRU_NOT_SUPPORT_5GR_MODE              ((UINT32)0)  /*整机不支持5R-R模式*/

/*bit0为IF0 bit1为IF1 0表示不支持 1表示支持*/
#define SUPPORT_IF0_ONLY                     (UINT32)(0x1) /*只支持IF0*/
#define SUPPORT_IF1_ONLY                     (UINT32)(0x2) /*只支持IF1*/
#define SUPPORT_IF0IF1_BOTH                  (UINT32)(0x3) /*IF0/1都支持*/

/*
bit0: 5M  7.68Mbps  bit1: 10M 15.36Mbps
bit2: 15M 23.04Mbps bit3: 20M 23.04Mbps
bit4: 15M 30.72Mbps bit5: 20M 30.72Mbps
bit6: 15M 19.2Mbps  bit7: 20M 19.2Mbps
*/
#define SUPPORT_ALLRATE_ALLBANDWIDTH         (UINT32)(0xFF) /*支持全部带宽下的所有采样率*/
#define SUPPORT_ALL_EXCEPT_19MRATE           (UINT32)(0x3F) /*支持除19.2M采样率外的其他配置 D4芯片不支持TDD LTE 19.2采样率*/
#define SUPPORT_FOR_ONLY_IF1_RATE            (UINT32)(0)    /*第一版合入 (1)R9614 S26 D4 (2)R9614E M1826 (3)R9626E M1826*/

#define NTF_SUPPORT_NEW_SOLUTION               ((UINT32)1)
#define NTF_SUPPORT_OLD_SOLUTION               ((UINT32)0)
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数定义
 **************************************************************************/

UINT32 BspGetFuRuBaseInfo(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuSuppRadioMode(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuRunRadioMode(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuFibrPort(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuComBin(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuAisgPortVolt(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuDryContact(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuNsbt(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuCrossDiversity(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRu9BitComperess(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuDtx(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuLocalOsci(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuSuppLocalOsci(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuAntJump(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuAasWorkMode(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuUpDeleyAbilty(VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuIf1Abilty(VOID * pRruAbilityFuInfo, UINT32 dataLen);
VOID BspSetIsFixTax(UCHAR isFixTax);
UINT32 BspGetFuRuChanBaseInfo(UINT32 chan, UINT32 dir, VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuChanBandWidth(UINT32 chan, UINT32 dir, VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuChanPower(UINT32 chan, UINT32 dir, VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuChanRadioMode(UINT32 chan, UINT32 dir, VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuChanCarrier(UINT32 chan, UINT32 dir, VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetFuRuChanDflGain(UINT32 chan, UINT32 dir, VOID * pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetRruSupportRadioMode(UINT32 supportRadioMode);
UINT32 BspSetTopoCascadeNum(UINT32 topoCascadeNum);
UINT32 BspSetOptSpeedListAbility(UINT32 optSpeedList);
UINT32 BspSetRruCombin(UINT32 ulCombin);
UINT32 BspSetRruDryContactNum (UINT32 inDryContactNum ,UINT32 outDryContactNum );
UINT32 BspSetRruCrossDiversity (UINT32 crossDiversity);
UINT32 BspGetRaiseTptlGateAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetRruRaiseTptlGateAbility(UINT32 supportRaiseTptlGate);
UINT32 BspGetBasebandMergAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetRruBasebandMergAbility(UINT32 supportBasebandMerg);
UINT32 BspGetRruRailModeAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetRruMtsTempPtxAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetRruVswrOptMizeInfo(VOID *pvRruSupportMVswrOptMizeInfo, UINT32 dataLen);
UINT32 BspSetRruSupport5GRAbility(UINT32 supportFlag);
UINT32 BspSetRruUmtsRssiOptmizeAbility(USHORT supportFlag);
UINT32 BspSetRruMtsTempPtxFlag(UINT32 supportFlag);
UINT32 BspSetRruVswrOptMizeFlag(UINT32 supportFlag);
UINT32 BspSetRruVswrOptMizeChanMask(UINT32 ulChanMask);
UINT32 BspSetRruPwrLetTempCheckFlag(UINT32 supportFlag);
UINT32 BspGetRruPwrLetTempChkAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetRruAutoAdjustVoltAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetOverPowToOpenLoopAbility(UINT32 supportFlag);
UINT32 BspGetRruOverPowToOpenLoopAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetRruSupport9BitCompress (UINT32 support9BitCompress);
UINT32 BspSetRruSupportAntJump (UINT32 supportAntJump);
UINT32 BspSetRruAASWorkMode  (UINT32 aasWorkMode );
UINT32 BspSetRruSupportDtx (UINT32 supportDtx);
UINT32 BspSetDlDelayCmpAbility (UINT32 dlDelayCmpIc,UINT32 dlDelayCmpFpga);
UINT32 BspSetCarrNumCfg( UINT32 radioType, UINT32 carrNum );
UINT32 BspGetOptSpeedListAbility(T_OptSpeedList *ptSpeedList);
UINT32 BspSetVswrPosOnlineDetectionAbility(UINT32 supportFlag);
UINT32 BspGetVswrPosOnlineDetectAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetVswrGateResetFlag(UINT32 supportFlag);
UINT32 BspGetRruCarrRangeCapture(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetRruAvgPaptAbility(VOID *pvRruSupportAvgPaptInfo, UINT32 dataLen);
UINT32 BspSetAvgPaptSpeCtrlInfo(UINT32 supportFlag, UINT32 chanMask);
UINT32 BspSetRruCarrOptBindPara(T_BspFuRuCarrOptBindPara *pPara);
UINT32 BspGetRruCarrOptBindPara(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetRruAutoVoltAbility(UINT32 supportFlag, UINT32 power);
T_BspFuRuSupportAutoAdjustVolt* BspGetRruAutoVoltAbility(VOID);
UINT32 BspGetTempCompsFlagAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetTempCompsFlag(UINT32 supportFlag);
UINT32 BspSetDigitalPhaseShifterAlarmFlag(UINT32 supportFlag);
UINT32 BspGetDigitalPhaseShifterAlarmAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetSupportUnionAntAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetSupportUnionAntFlag(UINT32 supportFlag);
UINT32 BspGetDigitalPhaseShifterAlarmFlag(VOID);
UINT32 BspGetSupportUnionAntFlag(VOID);
UINT32 BspGetRruBandVswrAbility(VOID *pRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetMaxPowLimitInfo(UINT32 supportFlag, INT32 maxPowMw);
UINT32 BspGetMaxPowLimitAbility(VOID);
INT32 BspGetMaxPow(VOID);
UINT32 BspGetRruMaxPowLimitAbility(VOID *pvRruSupportMaxPowLimitInfo, UINT32 dataLen);
UINT32 BspGetRruUaeModeAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetRruAueModeFlag(UINT32 supportFlag);
UINT32 BspGetRruAueModeFlag(VOID);
UINT32 BspGetNcrIsolationDetectionAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetIsolationDetectionFlag(UINT32 supportFlag);
UINT32 BspGetIsolationDetectionFlag(VOID);
UINT32 BspGetRruPlcConfigAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetRruPlcSupportFlag(UINT32 supportFlag);
UINT32 BspGetRruPlcSupportFlag(VOID);
UINT32 BspSetRruSupportRequestVer(UINT32 supportFlag);
UINT32 BspGetRruSupportRequestVer(VOID);
UINT32 BspSetRruPlcChipType(UINT32 chipType);
UINT32 BspGetRruPlcChipType(VOID);
UINT32 BspGetSupportIcPathChgAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
void BspSetSupportIcPathChnFlag(UINT32 flag);
UINT32 BspGetIF0IF1SplitAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetSupportIF0IF1Flag();
UINT32 BspGetSupprtSampleRateFlag();
VOID BspSetSupportIF0IF1Flag(UINT32 flag);
VOID BspSetSupprtSampleRateFlag(UINT32 flag);
UINT32 BspSetRruNtfSolutionAbility(UINT32 solution);
UINT32 BspGetRruNtfSolutionAbility(VOID);
UINT32 BspGetNtfSolutionAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetVswrDeratingAbility(UINT32 supportFlag);
INT32 BspSetVswrDeratingThreshold(INT32 val);
INT32 BspSetVswrRecoveryThreshold(INT32 val);
UINT32 BspGetSupportVswrDeratingAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetRruUmtsRssiOptmizeSwAbility(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspGetVswrDeratingAbility(VOID);
INT32 BspGetVswrDeratingThreshold(VOID);
INT32 BspGetVswrRecoveryThreshold(VOID);
UINT32 BspGetRruVswrGateChanMask(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
UINT32 BspSetChanMaskAdaptVswrGate(UINT32 chanMask);
UINT32 BspGetVswrGateAdaptChanMask(VOID);

#ifdef __cplusplus
}
#endif
#endif 





/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : rruabilitycommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了RRU 能力上报对内接口声明
* 注意事项 : 无
* 作    者 :   wangfei
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_RRUABILITYCOMMON_H_
#define _FUNCLIB_RRUABILITYCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "bspcomm.h"
#include "bsppub.h"
#include "rruabilityapi.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define DELAY_CMP_FUNC_NOT_SUPPORT             0xFFFFFFFF
#define OPT_FIBER_BUFF_ABILITY_20KM         ((UINT32)200)  /* 20km拉远缓存能力 */
#define OPT_FIBER_BUFF_ABILITY_40KM         ((UINT32)255)  /* 40km拉远缓存能力 */

#define RRU_CLASS_NB_SUPPORT                6 /* D42平台支持NB规格 rruclass上报值 */
#define RRU_CLASS_NB_SUPPORT_NTN            7 /* R9005N规格 rruclass上报值 */
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef UINT32 (*RRU_FIELD_GET_FUNC)(VOID *pRruAbilityFuInfo,UINT32 dataLen);
/*RRU 能力上报*/
typedef struct tagRruAbilityInfo
{
    UINT32 fuIndex;
    RRU_FIELD_GET_FUNC pFuncGetField;
}T_RruAbilityInfo;

typedef UINT32 (*RRU_CHL_FIELD_GET_FUNC)(UINT32 chan,UINT32 dir,VOID *pRruChlAbilityFuInfo,UINT32 dataLen);
typedef struct tagRruChlAbilityInfo
{
    UINT32 fuIndex;
    RRU_CHL_FIELD_GET_FUNC pFuncGetField;
}T_RruChanAbilityInfo;

typedef UINT32 (*RRU_SPECIAL_FIELD_GET_FUNC)(VOID *pRruSpAbilityFuInfo, UINT32 dataLen);
typedef struct tagRruSpecialAbilityInfo
{
    UINT32 spFuIndex;
    RRU_SPECIAL_FIELD_GET_FUNC pSpFuncGetField;
}T_RruSpecialAbilityInfo;

typedef UINT32 (*RRU_SPECIAL_FLAG_SET_FUNC)(UINT32 flag);
typedef struct tagRruSpecialAbilitySetFlag
{
    UINT32 funcIndex;
    RRU_SPECIAL_FLAG_SET_FUNC pSpFuncSetFlag;
}T_RruSpecialAbilitySetFlag;

typedef struct tag_rruability_func
{   
   T_RruAbilityInfo     *pRruAbilityInfo;
   UINT32               rruAbilityNum;
}T_RruAbilityFunc;

typedef struct tag_rruchnability_func
{   
   T_RruChanAbilityInfo     *pRruChnAbilityInfo;
   UINT32                    rruChnAbilityNum;
}T_RruChnAbilityFunc;

typedef struct tag_rruspecialability_func
{
   T_RruSpecialAbilityInfo *ptRruSpAbilityInfo;
   UINT32                  rruSpAbilityNum;
}T_RruSpecialAbilityFunc;

typedef struct tag_rruability_module
{
   T_RruAbilityFunc     rruAbilityFunc;
   T_RruSpecialAbilityFunc  rruSpecialAbilityFunc;
   T_RruChnAbilityFunc  rruChnAbilityFunc;
}T_RruAbilityMoudle;


typedef ULONG (*RRU_CARR_ABILITY_FUNC)(VOID);
typedef UINT32 (*pGetChnBndSptInfo)(UINT32 bspchan, UINT32 dir,UINT32 bandno);

/**************************************************************************
 *                         函数定义
 **************************************************************************/
UINT32 BspRruCarrAbilityCallBackInit(RRU_CARR_ABILITY_FUNC pReset);
UINT32 BspRruCarrAbility(VOID);
UINT32 BspSetRruAbilityInfo(T_RruAbilityInfo *pRruAbility ,UINT32 rruAbilityNum);
UINT32 BspSetRruSpecialAbilityInfo(T_RruSpecialAbilityInfo *pRruSpAbility, UINT32 rruSpAbilityNum);
UINT32 BspSetRruChnAbilityInfo(T_RruChanAbilityInfo *pRruChnAbility ,UINT32 rruChnAbilityNum);
UINT32 BspInitRruAbilityFunc(VOID);
UINT32 BspInitRruForm(T_RruFormInfo *rruFormInfo, UINT32 rruFormInfoNum);
pGetChnBndSptInfo BspGetChnBndSptInfoInit(VOID);
UINT32 BspSetChnBndSptInfoInit(pGetChnBndSptInfo ptfuc);
UINT32 BspGetCarrNumCfg(UINT32 radioType);
UINT32 BspSetCarrNumCfg(UINT32 radioType, UINT32 carrNum);
UINT32 BspSetUlDelayCmpAbility (UINT32 ulDelayCmpIc,UINT32 ulDelayCmpFpga);
UINT32 BspGetUlDelayCmpAbility(VOID);
UINT32 BspGetRruClass(VOID);
UINT32 BspSetRruClass(UINT32 rruClass);
UINT32 BspSetRruCarrRangeCapture(T_RruFreqIdCaCap *pPara);
UINT32 BspSetRuPaBaseInfo(T_BspFuRuPaBaseInfo *pPara);
UINT32 BspGetRuPaBaseInfo(VOID *pvRruAbilityFuInfo, UINT32 dataLen);
#ifdef __cplusplus
}
#endif
#endif 




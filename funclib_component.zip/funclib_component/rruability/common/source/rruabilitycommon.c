/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rruabilitycommon.c
* 文件标识 : {[N/A]}
* 内容摘要 : 
* 注意事项 : 无
* 作    者 : wangfei10102065
* 创建日期 : 2018-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei10102065
* 修改日戳: 2018-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#include "rruabilitycommon.h"
#include "exprn.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
static RRU_CARR_ABILITY_FUNC    pRruCarrAbility     = NULL;
static T_RruFormInfo            *s_RruFormInfo      = NULL;
static UINT32                   s_RruFormInfoNum    = 0;
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
    

/* static T_RruAbilityInfo *s_rruAbilityInfo = NULL;
static UINT32 s_rruAbilityNum = 0;
static T_RruChanAbilityInfo *s_rruChnAbilityInfo=NULL;
static UINT32 s_rruChnAbilityNum = 0; */

static T_RruAbilityMoudle s_rruAbilityModule = {0};
static pGetChnBndSptInfo BspGetChnBndSptInfo = NULL;
static UINT32 s_rruClass = 0;/* RRU类别，0-RRU,1-RSU,2-AAS,3-一体化基站  */

static UINT32 s_OptimizeLevel = 0;/* D42 默认轻度折线  */
static T_BspFuRuPaBaseInfo s_ruPaBaseInfo = {0};
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数实现
 **************************************************************************/

/**************************************************************************
 * 函数名称: BspGetRruClass
 * 功能描述: 获取RRU类型
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明: RRU类别，0-RRU,1-RSU,2-AAS,3-一体化基站
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspGetRruClass(VOID)
{
    return s_rruClass;
}

/**************************************************************************
 * 函数名称: BspSetRruClass
 * 功能描述: 设置RRU类型
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年01月25日王飞10102065   创建
 **************************************************************************/

UINT32 BspSetRruClass(UINT32 rruClass)
{
    s_rruClass = rruClass;
    return BSP_OK;
}

/********************************************************************
*  函数名称   : BspGetRruAbilityInfo (*)
*  功能描述   : rru载波能力
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : 
*  输出参数   : 
*  返 回 值   : 
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/

UINT32 BspRruCarrAbilityCallBackInit(RRU_CARR_ABILITY_FUNC pReset)
{
    pRruCarrAbility = pReset;
    return BSP_OK;
}

UINT32 BspRruCarrAbility(VOID)
{
    if (pRruCarrAbility)
    {
        return pRruCarrAbility();
    }

    dbgInfoEx("[%s]Rru Carr Ability Error\n",__FUNCTION__);
    return BSP_ERROR;
}

UINT32 BspSetRruAbilityInfo(T_RruAbilityInfo *pRruAbility ,UINT32 rruAbilityNum)
{
    
    s_rruAbilityModule.rruAbilityFunc.pRruAbilityInfo  = pRruAbility;
    s_rruAbilityModule.rruAbilityFunc.rruAbilityNum    = rruAbilityNum;
    return BSP_OK;
}
UINT32 BspGetRruAbilityNum(VOID)
{
    return s_rruAbilityModule.rruAbilityFunc.rruAbilityNum ;
}

UINT32 BspSetRruSpecialAbilityInfo(T_RruSpecialAbilityInfo *pRruSpAbility, UINT32 rruSpAbilityNum)
{
    s_rruAbilityModule.rruSpecialAbilityFunc.ptRruSpAbilityInfo  = pRruSpAbility;
    s_rruAbilityModule.rruSpecialAbilityFunc.rruSpAbilityNum     = rruSpAbilityNum;
    return BSP_OK;
}

UINT32 BspGetRruSpecialAbilityNum(VOID)
{
    return s_rruAbilityModule.rruSpecialAbilityFunc.rruSpAbilityNum;
}

UINT32 BspSetRruChnAbilityInfo(T_RruChanAbilityInfo *pRruChnAbility ,UINT32 rruChnAbilityNum)
{    
    s_rruAbilityModule.rruChnAbilityFunc.pRruChnAbilityInfo  = pRruChnAbility;
    s_rruAbilityModule.rruChnAbilityFunc.rruChnAbilityNum    = rruChnAbilityNum;
    return BSP_OK;
}

UINT32 BspGetRruChnAbilityNum(VOID)
{
    return s_rruAbilityModule.rruChnAbilityFunc.rruChnAbilityNum;
}
UINT32 BspCheckRruAbilityFunc(VOID)
{    
    INPUT_POINTER_CHECK(s_rruAbilityModule.rruAbilityFunc.pRruAbilityInfo);
    INPUT_POINTER_CHECK(s_rruAbilityModule.rruChnAbilityFunc.pRruChnAbilityInfo);
    return BSP_OK;
}
/********************************************************************
*  函数名称   : BspGetRruAbilityInfo (*)
*  功能描述   : 获取RU整机能力信息
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFU  - 整机能力功能单元编号
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetRruAbilityInfo (UINT32 fuIndex, VOID *pRruChlAbilityFuInfo,UINT32 dataLen)
{
    UINT32 idxNum = 0;
    UINT32 loop   = 0;
    UINT32 retVal = BSP_OK;  

    INPUT_POINTER_CHECK(pRruChlAbilityFuInfo);
    retVal = BspCheckRruAbilityFunc();
    if(retVal!=BSP_OK)
    {
        return BSP_ERROR;
    }
    
    idxNum = BspGetRruAbilityNum();
    
    for(loop = 0;loop < idxNum;loop ++)
    {
        if(fuIndex == s_rruAbilityModule.rruAbilityFunc.pRruAbilityInfo[loop].fuIndex)
        {
            return s_rruAbilityModule.rruAbilityFunc.pRruAbilityInfo[loop].pFuncGetField(pRruChlAbilityFuInfo,dataLen);
        }
    }
    return BSP_ERROR;
}

/********************************************************************
*  函数名称   : BspGetRruSpecialAbility (*)
*  功能描述   : 获取RU整机特殊能力信息
*  输入参数   : ulFu - 整机能力功能单元编号
               ulFUDataLen - 数据长度
*  输出参数   : pvRruSpecialAbilityFuInfo  - 整机特殊能力功能单元结构数据
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 由于硬件原因需对功能做特殊处理; APP调用
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), XXXXXX@2023-11-22 20:32:41
*--------------------------------------------------------------------
*/
UINT32 BspGetRruSpecialAbility(UINT32 ulFu, VOID *pvRruSpecialAbilityFuInfo, UINT32 ulFUDataLen)
{
    UINT32 idxNum = 0;
    UINT32 loop   = 0;

    INPUT_POINTER_CHECK(pvRruSpecialAbilityFuInfo);
    /* platform interface other board (tdd rru etc..),but they not init it.
     * if not use dbgInfoEx, this while the screen scrolling print -_-!
     */
    if (NULL == s_rruAbilityModule.rruSpecialAbilityFunc.ptRruSpAbilityInfo)
    {
        dbgInfoEx("%s:Input Pointer is NULL!\n", __FUNCTION__);
        return ERROR_NULL_POINTER;
    }

    idxNum = BspGetRruSpecialAbilityNum();

    for(loop = 0;loop < idxNum;loop ++)
    {
        if(ulFu == s_rruAbilityModule.rruSpecialAbilityFunc.ptRruSpAbilityInfo[loop].spFuIndex)
        {
            dbgInfoEx("[%s] ulFu'%u, ulFUDataLen'%u, idxNum'%u, loop:%u \n", __FUNCTION__, ulFu, ulFUDataLen, idxNum, loop);
            return s_rruAbilityModule.rruSpecialAbilityFunc.ptRruSpAbilityInfo[loop].pSpFuncGetField(pvRruSpecialAbilityFuInfo, ulFUDataLen);
        }
    }

    return BSP_ERROR;
}

/********************************************************************
*  函数名称   : BspGetRruAbilityInfo (*)
*  功能描述   : 获取RU通道能力
*  读全局变量 : 无
*  写全局变量 :
*  输入参数   : ulFU  - 整机能力功能单元编号
*  输出参数   : pvRruAbilityFuInfo  - 整机能力功能单元结构数据
*  返 回 值   : BSP_OK或者错误码
*  其它说明   : 无
*--------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),王飞@2016-02-01 10:21:08, 创建
*--------------------------------------------------------------------
*/
UINT32 BspGetRruChlAbilityInfo(BYTE chan, BYTE dir, UINT32 fuIndex, VOID *pRruChlAbilityFuInfo, UINT32 dataLen)
{
    UINT32 idxNum   = 0;
    UINT32 loop     = 0;
    UINT32 retVal   = BSP_OK;
    INPUT_POINTER_CHECK(pRruChlAbilityFuInfo);
    
    
    retVal = BspCheckRruAbilityFunc();
    if(retVal!=BSP_OK)
    {
        return BSP_ERROR;
    }
    idxNum = BspGetRruChnAbilityNum();
    if(RX == dir )
    {
        if(chan >= BspGetRxChannel())
        {
            return BSP_ERROR;
        }
    }
    if(TX == dir )
    {
        if(chan >= BspGetTxChannel())
        {
            return BSP_ERROR;
        }
    }
    for(loop = 0;loop < idxNum;loop ++)
    {
        if(fuIndex == s_rruAbilityModule.rruChnAbilityFunc.pRruChnAbilityInfo[loop].fuIndex)
        {
            return s_rruAbilityModule.rruChnAbilityFunc.pRruChnAbilityInfo[loop].pFuncGetField(chan,dir,pRruChlAbilityFuInfo,dataLen);
        }
    }
    return BSP_ERROR;
}


UINT32 BspSetChnBndSptInfoInit(pGetChnBndSptInfo ptfuc)
{
    BspGetChnBndSptInfo = ptfuc;
    return BSP_OK;
}

pGetChnBndSptInfo BspGetChnBndSptInfoInit(VOID)
{
    return BspGetChnBndSptInfo;
}

T_RruForm BspGetRruForm(UINT32 bandNo)
{
    UINT32 i = 0;

    for (i = 0; i < s_RruFormInfoNum; i++)
    {
        if (bandNo == s_RruFormInfo[i].bandNo)
        {
            break;
        }
    }
    if (i == s_RruFormInfoNum)
    {
        return RRU_FORM_INVALID;
    }

    return s_RruFormInfo[i].rruForm;
}

UINT32 BspInitRruForm(T_RruFormInfo *rruFormInfo, UINT32 rruFormInfoNum)
{
    s_RruFormInfo       = rruFormInfo;
    s_RruFormInfoNum    = rruFormInfoNum;
    return BSP_OK;
}

/*app get Optimize Level */
UINT32 BspGetRruOptimizeLevel(VOID)
{
    return s_OptimizeLevel;
}
/*bsp set Optimize Level in board*/
void BspSetRruOptimizeLevel(UINT32 ulLevel)
{
    s_OptimizeLevel = ulLevel;
    return;
}

/*功放基础信息存储*/
/* Started by AICoder, pid:1ec86geeb5v8c1714c400aa560a64c28a139b786 */
UINT32 BspSetRuPaBaseInfo(T_BspFuRuPaBaseInfo *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    memcpy_s(&s_ruPaBaseInfo, sizeof(T_BspFuRuPaBaseInfo), pPara, sizeof(T_BspFuRuPaBaseInfo));
    return BSP_OK;
}
/*功放基础信息获取*/
UINT32 BspGetRuPaBaseInfo(VOID *pvRruAbilityFuInfo, UINT32 dataLen)
{
    INPUT_POINTER_CHECK(pvRruAbilityFuInfo);
    if(dataLen < sizeof(T_BspFuRuPaBaseInfo))
    {
        return BSP_ERROR;
    }
    memcpy_s(pvRruAbilityFuInfo, dataLen, &s_ruPaBaseInfo, sizeof(T_BspFuRuPaBaseInfo));
    return BSP_OK;
}
/* Ended by AICoder, pid:1ec86geeb5v8c1714c400aa560a64c28a139b786 */

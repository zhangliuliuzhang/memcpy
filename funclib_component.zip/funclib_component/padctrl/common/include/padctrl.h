/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : padctrl
* 文件名称 : padctrl.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了管脚复用模块对外接口函数、类型、宏声明
* 注意事项 : 无
* 作       者 : 10279092
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef _FUNCLIB_PADCTRL_H_
#define _FUNCLIB_PADCTRL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "freqcfgcommon.h"
/**************************************************************************
 *                        宏
 **************************************************************************/
#define  PAD_GPIO_1_8V     (1)   /* 1.8V通用管脚 */
#define  PAD_GPIO_3_3V     (2)   /* 3.3V通用管脚  */
#define  PAD_GPIO_LVDS     (3)   /* 差分管脚 */

#define  BB_FRAME_SELECT   (12)   /* BBFRAME功能 fr2来源为空口帧头 */

/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef struct tagT_GpioPadInfo
{
    char    padStrName[100];/* 管脚标模名字 */
    UINT32  padType;     /* 管脚类型 */
    UINT32  padStCfg;    /* ST：Schmitt trigger enable */
    UINT32  padSlCfg;    /* SL：Slew-rate-control enable */
    UINT32  padPullCfg;  /* PE：Pull UP/DOWN enable */
    UINT32  padDsCfg;    /* Driving selector*/
    UINT32  padFuncSel;  /* 复用功能选择 */
    UINT32  padCfgDone;  /* 控制上电后pad的oe信号 */
}T_GpioPadInfo;

typedef struct tagT_GpioPadInfoModify
{
    UINT32  padName;
    char    padStrName[100];/* 管脚标模名字 */
    UINT32  padType;     /* 管脚类型 */
    UINT32  padStCfg;    /* ST：Schmitt trigger enable */
    UINT32  padSlCfg;    /* SL：Slew-rate-control enable */
    UINT32  padPullCfg;  /* PE：Pull UP/DOWN enable */
    UINT32  padDsCfg;    /* Driving selector*/
    UINT32  padFuncSel;  /* 复用功能选择 */
    UINT32  padCfgDone;  /* 控制上电后pad的oe信号 */
}T_GpioPadInfoModify;

typedef struct tagT_LvdsGpioPadInfo
{
    UINT32  padName;
    char    padStrName[100];/* 管脚标模名字 */
    UINT32  padType;        /* 管脚类型 */
    UINT32  lvdsFrameHead;  /* 帧头选择 */
    UINT32  lvdsFuncSel;    /* 复用功能选择 */
}T_LvdsGpioPadInfo;

typedef struct tagT_LvdsCfgInfo
{
    UINT32  padName;
    char    padStrName[100];/* 管脚标模名字 */
    UINT32  padType;        /* 管脚类型 */
    UINT32  lvdsCfgVal;     /* 差分管脚配置值 */
}T_LvdsCfgInfo;

#define BSP_SET_PAD_REG_TBL(padName,strName,type,StCfg,SlCfg,PullCfg,DsCfg,funcSel,cfgDone) \
    [padName] =                                               \
    {                                                         \
        .padStrName              =   strName,                 \
        .padType                 =   type,                    \
        .padStCfg                =   StCfg,                   \
        .padSlCfg                =   SlCfg,                   \
        .padPullCfg              =   PullCfg,                 \
        .padDsCfg                =   DsCfg,                   \
        .padFuncSel              =   funcSel,                 \
        .padCfgDone              =   cfgDone,                 \
    }

#define BSP_SET_PAD_REG_MODIFY(name,strName,type,StCfg,SlCfg,PullCfg,DsCfg,funcSel,cfgDone) \
    {                                                         \
        .padName                 =   name,                    \
        .padStrName              =   strName,                 \
        .padType                 =   type,                    \
        .padStCfg                =   StCfg,                   \
        .padSlCfg                =   SlCfg,                   \
        .padPullCfg              =   PullCfg,                 \
        .padDsCfg                =   DsCfg,                   \
        .padFuncSel              =   funcSel,                 \
        .padCfgDone              =   cfgDone,                 \
    }
/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspInitAllPadGpio(T_GpioPadInfo *gpioPadInfo, UINT32 padInfoNum, UINT32 *PadGpioName, UINT32 padNum);

typedef UINT32 (*pad_BspPrePadInit)(T_GpioPadInfo *gpioPadInfo, UINT32 padInfoNum, UINT32 *PadGpioName, UINT32 padNum);
typedef UINT32 (*pad_BspPadAttrbuteInit)();

UINT32 BspGetPrePadInitByType(pad_BspPrePadInit pCallBackFunc);
UINT32 BspGetPadAttrbuteInitByType(pad_BspPadAttrbuteInit pCallBackFunc);
UINT32 BspSetBbFrameFunc(void);

#ifdef __cplusplus
}
#endif

#endif

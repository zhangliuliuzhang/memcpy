/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : padctrl
* 文件名称 : padctrl_ic4_2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了IC4.2管脚复用模块功能实现
* 注意事项 : 无
* 作       者 : 10279092
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "bsppub.h"
#include "bspcomm.h"
#include "padctrl.h"
#include "exprn.h"
/**************************************************************************
 *                        全局变量
 **************************************************************************/
static pad_BspPrePadInit           s_pBspPrePadInit       = NULL;
static pad_BspPadAttrbuteInit      s_pBspPadAttrbuteInit  = NULL;
/**************************************************************************
*                         函数声明
**************************************************************************/
static pad_BspPrePadInit BspGetPrePadInit(VOID);
static pad_BspPadAttrbuteInit BspGetPadAttrbuteInit(VOID);
/**************************************************************************
*                         函数定义
**************************************************************************/
/**********************************************************************
* 函数名称: BspInitAllPadGpio
* 功能描述: 初始化所有pad管脚
* 输入参数: gpioPadInfo:单板传下来的pad初始化表，PadGpioName：需要初始化pad管脚
* 输出参数: 无
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspInitAllPadGpio(T_GpioPadInfo *gpioPadInfo, UINT32 padInfoNum, UINT32 *PadGpioName, UINT32 padNum)
{
    UINT32 retVal                              = BSP_OK;
    pad_BspPrePadInit pBspPrePadInit           = NULL;
    pad_BspPadAttrbuteInit pBspPadAttrbuteInit = NULL;

    INPUT_POINTER_CHECK(gpioPadInfo);
    INPUT_POINTER_CHECK(PadGpioName);

    pBspPrePadInit      = BspGetPrePadInit();
    pBspPadAttrbuteInit = BspGetPadAttrbuteInit();

    if(pBspPrePadInit != NULL)
    {
        retVal |= pBspPrePadInit(gpioPadInfo, padInfoNum, PadGpioName, padNum);
        dbgInfoEx("The function pointer[pBspPrePadInit]  is ok.\n");
    }

    if(pBspPadAttrbuteInit != NULL)
    {
        retVal |= pBspPadAttrbuteInit();
        dbgInfoEx("The function pointer[pBspPadAttrbuteInit]  is ok.\n");
    }

    return retVal;
}

static pad_BspPrePadInit BspGetPrePadInit(VOID)
{
    return s_pBspPrePadInit;
}

UINT32 BspGetPrePadInitByType(pad_BspPrePadInit pCallBackFunc)
{
    s_pBspPrePadInit = pCallBackFunc;

    return BSP_OK;
}

static pad_BspPadAttrbuteInit BspGetPadAttrbuteInit(VOID)
{
    return s_pBspPadAttrbuteInit;
}

UINT32 BspGetPadAttrbuteInitByType(pad_BspPadAttrbuteInit pCallBackFunc)
{
    s_pBspPadAttrbuteInit = pCallBackFunc;

    return BSP_OK;
}

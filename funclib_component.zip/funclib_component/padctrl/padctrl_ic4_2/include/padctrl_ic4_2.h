/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : padctrl
* 文件名称 : padctrl.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了管脚复用模块对外接口函数、类型、宏声明
* 注意事项 : 无
* 作       者 : 10279092
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#ifndef _FUNCLIB_PADCTRL_IC4_2_H_
#define _FUNCLIB_PADCTRL_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "padctrl.h"
#include "ichaladapt_ic4_2.h"

/**************************************************************************
 *                        宏
 **************************************************************************/
#define BSP_PAD_PRINT_LOG      (0)
/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef enum E_GPIO_PAD_ATTRIBUTE
{
    IC4_2_PAD_ST     ,   /* ST属性：Schmitt trigger enable */
    IC4_2_PAD_SL     ,   /* SL属性：Slew-rate-control enable */
    IC4_2_PAD_PULL   ,   /* PE上下拉属性：Pull UP/DOWN enable */
    IC4_2_PAD_DS     ,   /* Driving selector */
    IC4_2_PAD_FUNCSEL,   /* 复用功能选择 */
    IC4_2_PAD_CFGDONE,   /* 控制上电后pad的oe信号 */

    IC4_2_PAD_MAX
}GPIO_PAD_ATTRIBUTE;

typedef struct tagT_PadAttributeInfo
{
    char    padAttriName[100];/* 管脚复用属性  */
    UINT32  (*pSetAttribute)(UINT32 Attribute, UINT32 value);
}T_PadAttributeInfo;

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspMountPadPointer(VOID);

UINT32 BspPadAttrbuteInit(VOID);
UINT32 BspPrePadInit(T_GpioPadInfo *gpioPadInfo, UINT32 padInfoNum, UINT32 *PadGpioName, UINT32 padNum);
UINT32 BspLvdsPinInit(UINT32 padName, UINT32 frameHead, UINT32 funcSel);

UINT32 BspSetPadReg(UINT32 padIoName, UINT32 value);
UINT32 BspGetPadReg(UINT32 padIoName);

#ifdef __cplusplus
}
#endif

#endif

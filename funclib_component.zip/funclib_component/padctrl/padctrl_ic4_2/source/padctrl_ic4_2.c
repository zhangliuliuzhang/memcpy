/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模  块  名 : padctrl
* 文件名称 : padctrl_ic4_2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了IC4.2管脚复用模块功能实现
* 注意事项 : 无
* 作       者 : 10279092
* 创建日期 : 2022-03-10
* 当前版本 : Ver1.0
*---------------------------------------------------------------------------*/
#include "bsppub.h"
#include "bspcomm.h"
#include "ru_basedef.h"
#include "padctrl_ic4_2.h"
#include "padctrl.h"
//#include "ichaladapt_ic4_2.h"
#include "ichaladapt_pad_ic4_2.h"
#include "fr_cfg_api.h"

/**************************************************************************
 *                        全局变量
 **************************************************************************/
T_PadAttributeInfo padAttributeInfo[IC4_2_PAD_MAX] =
{
       [IC4_2_PAD_ST]      = {"padStCfg"      , BspSetPadSt     },
       [IC4_2_PAD_SL]      = {"padStCfg"      , BspSetPadSl     },
       [IC4_2_PAD_PULL]    = {"padStrPullCfg" , BspSetPadPull   },
       [IC4_2_PAD_DS]      = {"padDsCfg"      , BspSetPadDs     },
       [IC4_2_PAD_FUNCSEL] = {"padFuncSel"    , BspSetPadFuncSel},
       [IC4_2_PAD_CFGDONE] = {"padCfgDone"    , BspSetPadCfgDone},
};

T_GpioPadInfo g_pGpioPadInfo[E_HalPadName_Max] = {0};
UINT32 g_pPadGpioName[E_HalPadName_Max] = {0};

UINT32 bspPadPrintLog     = 0;
/**************************************************************************
*                         函数声明
**************************************************************************/
static UINT32 BspSetAttribute(UINT32 attribute);
static UINT32 BspGetAllPadReg(void);
static UINT32 BspSetPrintFlag(UINT32 value);
/**************************************************************************
*                         函数定义
**************************************************************************/
/**********************************************************************
* 函数名称: BspPrePadInit
* 功能描述: pad模块信息复制到funclib
* 输入参数: gpioPadInfo:单板传下来的pad初始化表，PadGpioName：需要初始化pad管脚
* 输出参数: 无
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspPrePadInit(T_GpioPadInfo *gpioPadInfo, UINT32 padInfoNum, UINT32 *PadGpioName, UINT32 padNum)
{
    INPUT_POINTER_CHECK(gpioPadInfo);
    INPUT_POINTER_CHECK(PadGpioName);


    memcpy_s(&g_pGpioPadInfo[0], sizeof(T_GpioPadInfo) * padInfoNum, gpioPadInfo, sizeof(T_GpioPadInfo) * padInfoNum);
    memcpy_s(&g_pPadGpioName[0], sizeof(UINT32) * padNum, PadGpioName, sizeof(UINT32) * padNum);

    dbgInfoEx("%s: PadGpioName is [%d],gpioPadInfo is [%d]\n",__FUNCTION__,NELEMENTS(g_pPadGpioName),NELEMENTS(g_pGpioPadInfo));

    return BSP_OK;
}

UINT32 BspMountPadPointer(VOID)
{
    UINT32 retVal                  = BSP_OK;

    retVal |= BspGetPrePadInitByType(BspPrePadInit);
    retVal |= BspGetPadAttrbuteInitByType(BspPadAttrbuteInit);

    return retVal;
}

/**********************************************************************
* 函数名称: BspPadAttrbuteInit
* 功能描述: 将所有属性值初始化
* 输入参数: 无
* 输出参数: 无
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspPadAttrbuteInit(VOID)
{
    UINT32 retVal                  = BSP_OK;
    UINT32 loop                    = 0;

    for(loop = 0; loop < IC4_2_PAD_MAX; loop ++)
    {
        retVal |= BspSetAttribute(loop);
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspSetAttribute
* 功能描述: 将所有属性值初始化
* 输入参数: attribute：pad需要配置的功能属性，参考GPIO_PAD_ATTRIBUTE
* 输出参数: 无
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 BspSetAttribute(UINT32 attribute)
{
    UINT32 retVal                  = BSP_OK;
    UINT32 loop                    = BSP_OK;
    UINT32 padNum                  = 0;
    UINT32 attributeVal            = 0;
    T_GpioPadInfo gpioPadInfo      = {0};

    padNum = NELEMENTS(g_pPadGpioName);
    dbgInfoEx("%s padNum is [%d],attribute is [%d]\n",__FUNCTION__,padNum,attribute);
    if(attribute >= IC4_2_PAD_MAX)
    {
        dbgInfo("%s ERROR: Attribuite is over range!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    for(loop = 0; loop < padNum; loop ++)
    {
        dbgInfoEx("%s loop=[%d], g_pPadGpioName=[%d]\n",__FUNCTION__,loop,g_pPadGpioName[loop]);

        if(g_pPadGpioName[loop] > E_HalPadName_Max)
        {
            dbgInfo("%s ERROR: PadReg is over Range\n", __FUNCTION__);
            return BSP_ERROR;
        }

        gpioPadInfo = g_pGpioPadInfo[g_pPadGpioName[loop]];

        /* 此处操作与结构体T_GpioPadInfo强相关，修改时请注意  */
        if(&gpioPadInfo.padStCfg + attribute > &gpioPadInfo.padCfgDone)
        {
            dbgInfo("%s ERROR: Attribuite is over range!\n",__FUNCTION__);
            return BSP_ERROR;
        }
        attributeVal = *(&gpioPadInfo.padStCfg + attribute);
        if(attributeVal == BSP_INVALID_VALUE)
        {
            continue;
        }
        retVal |= padAttributeInfo[attribute].pSetAttribute(g_pPadGpioName[loop], attributeVal);
        dbgInfoEx("%s : [%s],val=%d. \n",__FUNCTION__,padAttributeInfo[attribute].padAttriName,attributeVal);
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspLvdsPinInit
* 功能描述: 单个差分pin管脚复用功能初始化
* 输入参数: 无
* 输出参数: 无
* 说       明: 按复用管脚个数初始化
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspLvdsPinInit(UINT32 padName, UINT32 frameHead, UINT32 funcSel)
{
    UINT32 retVal =       BSP_OK;

    retVal |= BspSetPadLvdsFrameHead(padName, frameHead);
    retVal |= BspSetPadLvdsFuncSel(padName, funcSel);

    return retVal;
}

/**********************************************************************
* 函数名称: BspSetPadReg
* 功能描述: 设置pad寄存器的值
* 输入参数: 无
* 输出参数: 无
* 说       明: 按复用管脚个数初始化
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspSetPadReg(UINT32 padIoName, UINT32 value)
{
    UINT32 retVal          = BSP_OK;

    retVal = BspHalSetPadReg(padIoName, value);

    dbgInfoEx("padIoName: %d, halPadName: %d", padIoName, padIoName);
    return retVal;
}

/**********************************************************************
* 函数名称: BspGetPadReg
* 功能描述: 获取pad寄存器的值
* 输入参数: 无
* 输出参数: 无
* 说       明: 按复用管脚个数初始化
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
UINT32 BspGetPadReg(UINT32 padIoName)
{
    UINT32 padRegVal       = 0;

    BspHalGetPadReg(padIoName, &padRegVal);

    dbgInfoEx("padIoName: %d, halPadName: %d", padIoName, padIoName);
    return padRegVal;
}

UINT32 BspGetLvdsCfgVal(UINT32 padName)
{
    UINT32 value  = 0;

    (void)BspHalGetLvdsCfgVal(padName, &value);
    dbgInfo("padName=[%d], Cfg value = %d. \n",padName, value);

    return value;
}

UINT32 BspGetLvdsPadVal(UINT32 padName)
{
    UINT32 value  = 0;

    (void)BspHalGetLvdsPadVal(padName, &value);
    dbgInfo("padName=[%d], Pad value = %d. \n",padName, value);

    return value;
}

/**********************************************************************
* 函数名称: BspGetAllPadReg
* 功能描述: 打印所有pad寄存器的值
* 输入参数: 无
* 输出参数: 无
* 说       明: 按复用管脚个数初始化
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 BspGetAllPadReg(VOID)
{
    UINT32 padRegVal       = 0;
    UINT32 loop            = 0;

    for(loop = 0; loop < NELEMENTS(g_pPadGpioName); loop++)
    {
        padRegVal = BspGetPadReg(g_pPadGpioName[loop]);

        if(bspPadPrintLog == BSP_PAD_PRINT_LOG)
        {
            dbgInfo("padIoName: %s, padRegVal: %#x \n", g_pGpioPadInfo[g_pPadGpioName[loop]].padStrName,padRegVal);
        }
        else
        {
            BspLog(LOG_LEVEL_0, "padIoName: %s, padRegVal: %#x \n",g_pGpioPadInfo[g_pPadGpioName[loop]].padStrName,padRegVal);
        }
    }

    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspSetPrintFlag
* 功能描述: 设置打印选择标志
* 输入参数: 默认bspPadPrintLog == 0，打印到前台，其他值打印到Log
* 输出参数: 无
* 说       明:
* 返  回  值: bspPadPrintLog值
************************************************************************/
static UINT32 BspSetPrintFlag(UINT32 value)
{
    bspPadPrintLog = value;

    return value;
}

UINT32 BspSetBbFrameFunc(void)
{
    UINT32 regVal = 0;
    UINT32 retVal = BSP_OK;

    /*PAD初始化寄存器,功能选择为非GPIO功能，同时选择为dlpre送出的fr2*/
    regVal = BspGetPadReg(IO_GPIO_1);
    BITS_SET (regVal,9,13,4);
    retVal |= BspSetPadReg(IO_GPIO_1, regVal);

    /*配置dlpre中fr2的来源为空口帧头*/
    retVal |= IcHalApiSetFrRouterPadFrSelByFrId(2, BB_FRAME_SELECT);

    return retVal;
}

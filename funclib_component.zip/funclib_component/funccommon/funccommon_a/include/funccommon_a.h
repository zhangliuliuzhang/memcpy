/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : funccommon_a.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _FUNCLIB_FUNCCOMMON_A_H_
#define _FUNCLIB_FUNCCOMMON_A_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "funccommon.h"
#include "ru_univdef.h"

#define PWM_MAX_NUM                 4
#define BSP_TRANSCEIVER_MTS         1
#define BSP_TRANSCEIVER_NOT_MTS     0

#define   LADAR_SCAN_OK         ((UINT32)(0))
#define   LADAR_SCAN_RUNNING    ((UINT32)(1))
#define   LADAR_SCAN_FAIL       ((UINT32)(2))

#define   LINK_OK                 (1)
#define   LINK_ERROR              (0)
#define   MAX_SLAVEPORT_NUM       (3)

#define READ_BOARD_TEMP_FLAG      (0)
#define NOT_READ_BOARD_TEMP_FLAG  (1)

#define   PA_CTRL_MODE_IO         (0)
#define   PA_CTRL_MODE_FPGA       (1)

#define BSP_RF_BRIDGE_FLAG        (0x1)
#define NTF_NO_SUPP_MULIT_TONE_VSWR     (0)
#define NTF_SUPP_MULIT_TONE_VSWR        (1)

#ifndef SLAVE_PORTID_CHECK
#define SLAVE_PORTID_CHECK(portId)                         \
    if ((portId) >= MAX_SLAVEPORT_NUM)                     \
    {                                                      \
        dbgErr("%s:portId error!\n",__FUNCTION__);            \
        return BSP_ERROR;                                  \
    }
#endif

typedef VOID (* FpgaReLoadFlagSetFun)(UINT32 fpgaLoadFlag);/*此处为单板挂接函数*/
typedef UINT32 (*FpgaReLoadFlagGetFun)(VOID);/*获取fpga重加载标志*/

typedef UINT32 (*FUNC_SYSPLLSTATUS_GET)(VOID);
typedef UINT32 (*FUNC_LOPLLSTATUS_GET)(UINT32 id);
typedef UINT32 (*FUNC_QSFPNTL_INIT)(UINT32 laneId);
typedef UINT32 (*FUNC_UPDATE_SLAVEPORT)(UINT32 portId);
typedef UINT32 (*SET_TDDCFG_TO_SALVEPORT)(UINT32 ulPortId);
typedef INT32 (*ntf_MTS_Switch)(void);
typedef struct T_TagFpgaReLoadFlagFun
{
    FpgaReLoadFlagSetFun FpgaReLoadFlagSet;
    FpgaReLoadFlagGetFun FpgaReLoadFlagGet;
    UINT32 InitFlag;
}T_FpgaReLoadFlagFun;
typedef enum  e_func_module_id
{
	FUNC_MIN_IDX,	/*0*/
	FUNC_DRY_IDX,   /*干接点*/
	FUNC_MAX_IDX,   /**/
} eFuncModuleId;
typedef struct tag_func_by_fpgaidx_item
{
    UINT32 funcIdx;            /* 功能属性 */
    UINT32 fpgaIdx;         /* FPGA/EPLD chipidx*/

}T_FuncByFpgaIdxItem;

typedef struct tag_func_by_fpgaidx
{
	T_FuncByFpgaIdxItem *pIdList;
    UINT32              idListNum;
} T_FuncByFpgaIdx;

typedef enum  e_fddTddCoExistFlag
{
	MODE_ONLY_FDD,	    /*FDD机型*/
	MODE_ONLY_TDD,      /*TDD机型*/
	MODE_ONLY_TDD_FDD,  /*T+F机型*/
	MODE_QCELL,
	MODE_MAX_NUM,
} eFddTddCoExistFlag;

typedef enum e_alarm_init_action
{
    ALARM_ACTION_TRANCEIVER_INIT,
    ALARM_ACTION_MAX_NUM = 64,
} eAlarmInitAct;

#define MAX_IC_NUM (8)
#define MAX_LANE_NUM (4)
typedef struct T_TagInnerSerdesPara
{
    UINT32 serdesLaneId;   /*端口号*/
    UINT32 serdesType;     /*SGMII或者CPRI*/
    UINT32 serdesOptProperty;  /*上下联属性*/
}T_InnerSerdesPara;

typedef struct T_TagChipSerdesPara
{
    UINT32 chipId;                               /*IC芯片号*/
    UINT32 laneNum;                              /*使用的lane数量*/
    T_InnerSerdesPara serdesPara[MAX_CHIP_NUM];  /*每条lane的参数*/
}T_ChipSerdesPara;   /*每片IC的参数*/

typedef struct T_TagUbrLaneRoute{
    UINT32 routeFlag;  /*0x5a5a表示有效传参*/
    UINT32 version;      /*结构体版本号*/
    UINT32 crc;
    UINT32 chipNum;      /*整机IC的芯片个数*/
    T_ChipSerdesPara chipSerdesPara[MAX_IC_NUM];
}T_UbrLaneRoute;    /*整机连接关系  从MO版本中解析得到*/

typedef struct T_TagVendorString{
    char VendorFamily[20];
    char VendorBand[20];
    char VendorPid[20];
}T_VendorString;

typedef struct T_TagCaliCarrFreqRecord
{
    UINT32 openLoopFreq;
    UINT32 caliFreq;
}T_CaliCarrFreqRecord;

#define BBU_FLASH_ID_LOCK_FILE "/ata/BbuUniqueIdLockFile"
#define ANTI_THEF_MODE0_VAL  (1UL << (0))  /*anti-counterfeiting, BIT0 set 1*/
#define ANTI_THEF_MODE1_VAL  (1UL << (1))  /*proactive theft prevention,BIT1 set 1*/
#define ANTI_THEF_MODE0      ((ULONG)(0))  /*anti-counterfeiting mode*/
#define ANTI_THEF_MODE1      ((ULONG)(1))  /*proactive theft prevention mode*/
#define ANTI_THEF_MODE_NUM   ((ULONG)(2))  /*anti thef mode num*/

UINT32 BspGetDspCoreIdMask();
UINT32 BspSetDspCoreIdMask(UINT32 num);
UINT32 BspInitFpgaReLoadFun(T_FpgaReLoadFlagFun *ptFpgaReLoadFlagFun);
UINT32 BspSetFuncByFpgaIdx(T_FuncByFpgaIdxItem *pList,UINT32 listNum );
UINT32 BspGetFpgaReLoadFlag(VOID);


typedef UINT32 (*pGetFpgaMaxTempFunc)(INT32 *lMaxTemp);
UINT32 BspRegisterGetFpgaMaxTempCall(pGetFpgaMaxTempFunc pGetFpgaMaxTemp);

typedef UINT32 (*pGetRfFpgaMaxTempFunc)(INT32 *lMaxTemp);
typedef UINT32 (*PrintSwitchToRgps)(VOID);

UINT32 BspRegisterGetRfFpgaMaxTempCall(pGetRfFpgaMaxTempFunc pGetRfFpgaMaxTemp);
UINT32 RegPrintSwitchToRgpsInit(PrintSwitchToRgps pPrintSwitchToRgps);
UINT32 BspSysPllStatusGetCallback(FUNC_SYSPLLSTATUS_GET pFunc);
UINT32 BspLoPllStatusGetCallback(FUNC_LOPLLSTATUS_GET pFunc);
UINT32 BspLoPllStatusGetCallback_9626(FUNC_LOPLLSTATUS_GET pFunc);

typedef UINT32 (*pFUNC_BSPISMTSTRANSCEIVER)(UINT32 *uIsMtsTrans);
typedef UINT32 (*pFUNC_BSPGETTXFAULTFROMMTSBYCHAN)(UINT32 uChan,UINT32 *uRegVal,UINT32 *uStatus);
typedef UINT32 (*pFUNC_BSPGETTXFAULTFROMMTSUNBYCHAN)(UINT32 *uRegVal,UINT32 *uStatus);
typedef UINT32 (*pGetRfTempFunc)(UINT32 ulChan,UINT32 ulBand, INT32 *pTemp);
typedef UINT32 (*FUNC_GET_BOARD_INIT_STATUS)(VOID);
typedef UINT32 (*FUNC_SET_FAN_SPEED)(UINT32 fanNo, UINT32 speed);
typedef UINT32 (*FUNC_GET_FAN_IS_OK)(UINT32 fanNo);

UINT32 BspSet_GetBoardInitStatusCallBack(FUNC_GET_BOARD_INIT_STATUS pFunc);
UINT32 BspIsMtsTransceiverCallBack(pFUNC_BSPISMTSTRANSCEIVER pFunc);
UINT32 BspGetTxFaultFromMtsByChanCallBack(pFUNC_BSPGETTXFAULTFROMMTSBYCHAN pFunc);
UINT32 BspGetTxFaultFromMtsUnByChanCallBack(pFUNC_BSPGETTXFAULTFROMMTSUNBYCHAN pFunc);
UINT32 BspSetFddTddCoExistSta(UINT32 sta);
UINT32 BspGetFddTddCoExistSta(VOID);
UINT32 BspSetRdBoardTempFlag(UINT32 flag);
UINT32 BspGetRdBoardTempFlag(VOID);
UINT32 BspSetPaCtrlMode(UINT32 flag);
UINT32 BspGetPaCtrlMode(VOID);
UINT32 BSPGetHardID(VOID);
UINT32 BspGetChanModeType(UINT32 chan);
UINT32 BspSetChanModeType(UINT32 *pPara,UINT32 num);
UINT32 BspGetDryContactStatus(T_RruDryContactInfo *pInfo);
UINT32 BspSetVectorVswrVal(UINT32 bspChn, UINT32 band, UINT32 vswrVal);
UINT32 BspGetVectorVswrVal(UINT32 bspChn, UINT32 band, UINT32 *pVswrVal);
UINT32 BspSetInitAlarmStatus(eAlarmInitAct act, UINT32 uStatus);
UINT64 BspGetInitAlarmStatus(VOID);
UINT32 BspRegisterGetRfTempCall(pGetRfTempFunc pGetRfTemp);
UINT32 BspQsfpNtlInitCallback(FUNC_QSFPNTL_INIT pFunc);
FUNC_QSFPNTL_INIT BspGetQsfpNtlInitCallBack(VOID);
const char* BspGetLogPath(VOID);
UINT32 BspGetRfPllLoFreq(UINT32 devId,UINT32 *freq);
UINT32 BspGetRfPllLoLd(UINT32 devId);
UINT32 BspSetSlavePortCfgInfo(UINT32 ulPortId, UINT32 ulPortType,UINT32 ulPortSta);
UINT32 BspLadarSetSampleSta(UINT32 bspRxChan, UINT32 sta);
UINT32 BspLadarGetSampleSta(UINT32 bspRxChan);
UINT32 BspGetChCbSwCtrlMode(UINT32 ulChan);
UINT32 BspIsClkSupportSw(VOID);
UINT32 BspIsClkCauseUnLock(VOID);
UINT32 BspIsMtsTransceiver(UINT32 *uIsMtsTrans);
UINT32 BspGetCurrClkType(VOID);
UINT32 BspSwClkType(UINT32 type);
UINT32 BspIsPllFreqNormal(VOID);
UINT32 BspIsClkAllowSw(VOID);
UINT32 BspGetTxFaultFromMtsUnByChan(UINT32 *uRegVal,UINT32 *uStatus);
UINT32 BspIsPllUnLock(VOID);
UINT32 BspGetTxFaultFromMtsByChan(UINT32 uChan,UINT32 *uRegVal,UINT32 *uStatus);
UINT32 BspGetSlavePortCfgSta(UINT32 ulChan, UINT32 *pPortSta);
UINT32 BspGetSlavePortCfgTpye(UINT32 ulChan, UINT32 *pPortType);
UINT32 BspUpdateSlavePortCallback(FUNC_UPDATE_SLAVEPORT pFunc);
UINT32 BspUpdateSlavePort(UINT32 portId);
VOID BspSetBbuUniqueIdFlashId(UINT32 Offset);
UINT32 BspGetBbuUniqueId(UCHAR *uniqueId);
UINT32 BspSetBbuUniqueId(UCHAR uniqueId, UCHAR secondSet);
ULONG BspSetRruAntiFun(VOID);
VOID BspSetAntiThefFlashId(ULONG mode, ULONG flashId);
ULONG BspGetBbuUniqueIdEx(UCHAR *uniqueId,  UCHAR ucFunction);
ULONG BspSetBbuUniqueIdEx(UCHAR uniqueIdInput, UCHAR secondSet, UCHAR ucFunction);
ULONG BspSetAntiThefLockFlag(ULONG mode, UCHAR lockFlag);
UINT32 BspGetAntiThefLockFlag(ULONG mode);
UINT32 BspSetSlavePortTddCfg(UINT32 portId);
UINT32 BspSlavePortTddCfgCallBack(SET_TDDCFG_TO_SALVEPORT pFuncCallback);
UINT32 BspGetRecordCaliCarrFreq(UINT32 chan, UINT32 type, UINT32 *pCarrFreq);
UINT32 BspRecordCaliCarrFreq(UINT32 chan, UINT32 type,UINT32 carrFreq);
UINT32 BspGetPaDrainAdjSupportFlag(VOID);
UINT32 BspSetPaDrainAdjSupportFlag(UINT32 flag);
UINT32 BspGetDeviceNodeNum(CHAR *deviceName, UINT32 charLength);
UINT32 BspGetDeviceSerialCfg(CHAR *deviceName, UINT32 charLength, UINT32 *nodeRcord, UINT32 recordLength);
UINT32 BspGetSectorMaskByDevice(UINT32 index, CHAR *deviceName, UINT32 charLength);
UINT32 BspGetDeviceNum(CHAR *deviceName, UINT32 charLength);
UINT32 BspSetSupportRfsRemoteFlag( UINT32 flag);
UINT32 BspGetPllDevStatus(OSS_ULONG devId);
UINT32 BspPllDeviceRecover(OSS_ULONG devId);
UINT32 BspGetPllDevNum(T_loInfo *ptLoInfo);
UINT32 BspSetFanSpeedCallBackInit(FUNC_SET_FAN_SPEED  pFuncSetFanSpeed);
UINT32 BspGetFanStatusCallBackInit(FUNC_GET_FAN_IS_OK  pFuncGetFanStatus);
void BspSetFanNum(UINT32 fanNum);
UINT32 BspSaveFanSpeed(UINT32 fanNo, UINT32 speed);
UINT32 BspSetRfBridgeSupportFlag(UINT32 flag);
UINT32 BspGetRfBridgeSupportFlag(VOID);
UINT32 BspGetRfBridgeInfoMap(T_AllRfBridgeInfo *pRfBridgeMap);
UINT32 BspSetRfBridgeInfoMap(T_AllRfBridgeInfo *pRfBridgeMap);
void BspSetRfBridgeVswrPreStartSta(UINT32 chan, UINT32 sta);
UINT32 BspGetRfBridgeVswrPreStartSta(UINT32 chan, UINT32 *pSta);
UINT32 BspSetThresholdBoardTempDelta(INT32 delta);
UINT32 BspSetThresholdPaTempDelta(INT32 delta);
UINT32 BspSetThresholdPwrTempDelta(INT32 delta);
UINT32 BspGetDpdicOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold);
UINT32 BspGetMcsOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold);
UINT32 BspGetBoardOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold);
UINT32 BspGetSfpOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold);
UINT32 BspGetPwrOverTempThreshold(UINT32 tempType, UINT32 voltType, OverTempThreshold *pThreshold);
UINT32 BspGetPaOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold);
UINT32 BspSetRfBridgeChanFlag(UINT32 difChn, UINT32 flag);
UINT32 BspGetRfBridgeChanFlag(UINT32 difChn, UINT32 *flag);
UINT32 BspSetUnitedArabEmiratesFlag(UINT32 flag);
UINT32 BspGetOverTempLevel(VOID);
UINT8 BspGetOptSelfTestStatus(UINT8 ucOptId);
void BspSetOptSelfTestStatus(UINT8 sta);
UINT32 BspSetNtfPowFlag(UINT32 flag);
UINT32 BspGetNtfPowFlag(void);
UINT32 BspSetTssiFwdDiffThreshold(UINT32 threshold);
UINT32 BspGetTssiFwdDiffThreshold(void);
UINT32 BspSetAdcStatusMask(UINT32 mask);
UINT32 BspGetAdcStatusMask(void);
UINT32 BspGetMTSSwitchNtf(ntf_MTS_Switch pCallBackFunc);
ntf_MTS_Switch Ntf_MTSSwitch(void);
UINT32 BspSetNtfVswrStep(UINT32 step);
UINT32 BspGetNtfVswrStep(void);
void BspSetNtfSupportMulitToneVswrFlag(UINT32 flag);
UINT32 BspGetNtfSupportMulitToneVswrFlag(void);
UINT32 BspSetNtfScalarVswrThre(UINT32 thre);
UINT32 BspGetNtfScalarVswrThre(void);
UINT32 BspSetIsSupportAac(UINT32 flag);
UINT32 BspGetIsSupportAac(VOID);
#ifdef __cplusplus
}
#endif

#endif


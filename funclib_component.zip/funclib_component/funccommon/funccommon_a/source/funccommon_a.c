/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : uart_aisg.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "bspcomm.h"
#include "ru_univdef.h"
#include "boardid.h"
#include "funccommonapi.h"
#include "systemcallapi.h"
#include "funccommon_a.h"
#include "regdrv.h"
#include "devdrv_clk.h"
#include "devdrv_lo.h"
#ifndef _4C_VDE_TEST_ 
#include "fpgaload.h"
#endif
#include "flash.h"
#include "clk_common.h"
#include "lo_common.h"
#include "ichal_common_api.h"
#include "ichaladapt_ic4_2.h"

#define DEFAULT_SLOT_NUM ((UCHAR)(1))  //默认槽位号

static T_RruCfgInfo s_rruCfgInfo = {0,};
static UINT32 s_rruAddrFlag = 0;
static UINT32 s_optNetCfgStatus = 0;
static UINT32 s_optNetOkFlag = 0;
static UINT32 s_cpuId = 0;
static UINT32 s_coreId = 0;
static UINT32 s_dspCoreMask = 0;
static UINT32 s_stdRadio = 0;
static UINT32 s_mchLocation = 0;
static T_FpgaReLoadFlagFun FpgaReLoadFlagFun={0};
static T_FuncByFpgaIdx     s_funcByFpgaIdxInfo = {0};
static UINT32 g_fddTddCoExistSta = MODE_ONLY_TDD; //0:fdd机型　１:TDD机型 2:T+F机型
static UINT32 g_rdBoardTempFlag = READ_BOARD_TEMP_FLAG; //0:需要读取 1：不需要读取
static UINT32 g_PaCtrlMode = PA_CTRL_MODE_IO;
static UINT32 g_chanModeType[MAX_TX_CHAN] = {0}; //0:fdd通道  １:tdd通道
static UINT32 s_VectorVal[MAX_TX_CHAN][MAX_CHANBAND_NUM] = {0};
static UINT64 g_InitAlarmStatus = 0;
static UINT32 s_ladarSta[MAX_RX_CHAN] = {0};
const char *s_bspLogPath = "/tmplog/bsp_log/";
UINT32 g_ulChCbSwCtrlMode[MAX_TX_CHAN]= {0};
PrintSwitchToRgps      gpPrintSwitchToRgps = NULL;
FUNC_SYSPLLSTATUS_GET pSysPllStatusGetFunc = NULL;
FUNC_LOPLLSTATUS_GET pLoPllStatusGetFunc = NULL;
FUNC_LOPLLSTATUS_GET pLoPllStatusGetFunc_9626 = NULL;
FUNC_QSFPNTL_INIT pQsfpNtlInitFunc = NULL;
FUNC_UPDATE_SLAVEPORT pUpdateSlavePort= NULL;
pFUNC_BSPISMTSTRANSCEIVER pBspIsMtsTransceiver = NULL;
pFUNC_BSPGETTXFAULTFROMMTSBYCHAN pBspGetTxFaultFromMtsByChan = NULL;
pFUNC_BSPGETTXFAULTFROMMTSUNBYCHAN pBspGetTxFaultFromMtsUnByChan = NULL;
FUNC_SET_FAN_SPEED  pSetFanSpeed = NULL;
FUNC_GET_FAN_IS_OK  pGetFanIsOk = NULL;
static FUNC_GET_BOARD_INIT_STATUS s_pFuncGetBoardInitStatus = NULL;
static UINT32 s_BbuUniqueIdFlashId = 0;     /* BBU唯一ID 的 Flash ID */
static ULONG s_AntiThefFlashId[ANTI_THEF_MODE_NUM] = {0};
static SET_TDDCFG_TO_SALVEPORT pSetTddCfgToSlavePort = NULL;

UINT32 g_ulSlavePortCfgType[MAX_SLAVEPORT_NUM] = {0,1,1};
UINT32 g_ulSlavePortCfgSta[MAX_SLAVEPORT_NUM] = {0};
T_CaliCarrFreqRecord g_ulRecordCarrFreq[MAX_TX_CHAN]= {0};
static UINT32 s_adjSupportFlag = 0;      /*0:支持静态调压；1：不支持静态调压*/
static UINT32 s_slaveSupportFlag = 0;      /*0:不支持拉远；1：支持拉远*/
static UINT32 s_rfBridgeSupportFlag = 0;      /*0:不支持电桥；1：支持电桥*/
static UINT32          s_commonPowerFlag     = 0;/*t+f机型上报tdd和fdd通道是否共用电源：0不共用，1共用*/
static T_AllRfBridgeInfo *s_rfBridgeInfo = NULL; /*电桥机型电桥与通道映射关系*/
static ULONG BspGetAntiThefFlashId(ULONG mode);
static UINT32 s_rfBridgeVswrPreStartSta[MAX_TX_CHAN] = {0};
static INT32 s_BoardTempDelta = 0; /*单板温度门限偏移量*/
static INT32 s_PaTempDelta    = 0; /*功放温度门限偏移量*/
static INT32 s_PwrTempDelta   = 0; /*电源温度门限偏移量*/
static UINT32 s_rfBridgeChanFlag[MAX_TX_CHAN] = {0};
static UINT32 s_UnitedArabEmiratesReduceTempFlag = 0; /*阿联酋降额机型标志*/
static UINT8  s_optSelfTest = 0;
static UINT32 s_ntfPowFlag = 0;
static UINT32 s_tssiFwdDiffThreshold = 0;
static UINT32 s_adcMask = 0;
static ntf_MTS_Switch s_pMTS_SwitchNtf = NULL;
static UINT32 s_ntfVswrStep = 2000;
static UINT32 s_ntfSupportMulitToneVswr = NTF_NO_SUPP_MULIT_TONE_VSWR;
static UINT32 g_slaverVerLoadSta = 0;
static UINT32 g_getSlaverVerLoadType = SUPPORT; /*只在上电时候获取一次*/
static UINT32 s_ntfScalarVswrThre = 2000000;
static UINT32 s_setIsSupportAac = NO_SUPPORT;
UINT32 BspSetCpuId(UINT32 id)
{
    s_cpuId = id;
    return BSP_OK;
}

UINT32 BspSetCoreId(UINT32 id)
{
    s_coreId = id;
    return BSP_OK;
}

UINT32 BspSetDspCoreIdMask(UINT32 num)
{
    /*****/
    s_dspCoreMask = (1 << num) - 1;
    return BSP_OK;
}

UINT32 BspSysPllStatusGetCallback(FUNC_SYSPLLSTATUS_GET pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pSysPllStatusGetFunc = pFunc;
    return BSP_OK;
}

UINT32 BspLoPllStatusGetCallback(FUNC_LOPLLSTATUS_GET pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pLoPllStatusGetFunc = pFunc;
    return BSP_OK;
}

UINT32 BspLoPllStatusGetCallback_9626(FUNC_LOPLLSTATUS_GET pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pLoPllStatusGetFunc_9626 = pFunc;
    return BSP_OK;
}

UINT32 BspQsfpNtlInitCallback(FUNC_QSFPNTL_INIT pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pQsfpNtlInitFunc = pFunc;
    return BSP_OK;
}

FUNC_QSFPNTL_INIT BspGetQsfpNtlInitCallBack(VOID)
{
    return pQsfpNtlInitFunc;
}

UINT32 BspSet_GetBoardInitStatusCallBack(FUNC_GET_BOARD_INIT_STATUS pFunc)
{
    s_pFuncGetBoardInitStatus = pFunc;
    return BSP_OK;
}

UINT32 BspGetBoardInitStatus(VOID)
{
    UINT32 retVal = BSP_OK;

    if(NULL != s_pFuncGetBoardInitStatus)
    {
        retVal = s_pFuncGetBoardInitStatus();
    }

    return retVal;
}

UINT32 BspUpdateSlavePortCallback(FUNC_UPDATE_SLAVEPORT pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pUpdateSlavePort = pFunc;
    return BSP_OK;
}

/*子端版本加载等流程*/
UINT32 BspUpdateSlavePort(UINT32 portId)
{
    UINT32 retVal = BSP_OK;
    if(NULL != pUpdateSlavePort)
    {
        retVal = pUpdateSlavePort(portId);
    }

    return retVal;
}
/****************************************************************
                          公共接口
 ****************************************************************/
UINT32 BspGetFpgaIdxByFunc(UINT32 funcIdx, UINT32 *pFpgaIdx)
{
    UINT32 ulFuncLoop = 0;
    UINT32 ulIdxFound = 0;
	INPUT_POINTER_CHECK(pFpgaIdx);

	if ((s_funcByFpgaIdxInfo.pIdList == NULL) || (s_funcByFpgaIdxInfo.idListNum == 0))
	{
        dbgInfoEx("%s>>Error! IdList Not Init;\n", __FUNCTION__);
		return BSP_ERROR;
	}

	for (ulFuncLoop = 0; ulFuncLoop < s_funcByFpgaIdxInfo.idListNum; ulFuncLoop++)
	{
		if (s_funcByFpgaIdxInfo.pIdList[ulFuncLoop].funcIdx == funcIdx)
		{
			ulIdxFound = 1;
			break;
		}
	}
	if (ulIdxFound != 1)
	{
        dbgInfoEx("%s>>Error! FuncIdx Not Found;\n", __FUNCTION__);
		return BSP_ERROR;
	}

	*pFpgaIdx = s_funcByFpgaIdxInfo.pIdList[ulFuncLoop].fpgaIdx;
    dbgInfoEx("%s>>FuncIdx'%d: ChipIdx= %d\n", __FUNCTION__,
              funcIdx, *pFpgaIdx);

	return BSP_OK;
}

UINT32 BspSetFuncByFpgaIdx(T_FuncByFpgaIdxItem *pList, UINT32 listNum)
{
    INPUT_POINTER_CHECK(pList);
    s_funcByFpgaIdxInfo.pIdList   = NULL;
    s_funcByFpgaIdxInfo.idListNum = 0;
    s_funcByFpgaIdxInfo.pIdList   = pList;
    s_funcByFpgaIdxInfo.idListNum = listNum;
    return BSP_OK;
}

UINT16 BspSubFrameNumGet(VOID)
{
    return 0;
}

UINT32 BspDbgInit(VOID)
{
    return BSP_OK;
}

UINT32 BspDtiControl(T_BSP_DEV_PARA *pPara)
{
    INPUT_POINTER_CHECK(pPara);
    return BSP_OK;
}


UINT32 BspSetCfgInfo(T_RruCfgInfo *pTRruCfgInfo)
{
    if (NULL == pTRruCfgInfo)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    memcpy(&s_rruCfgInfo, pTRruCfgInfo, sizeof(T_RruCfgInfo));
    return BSP_OK;
}

VOID setRruAddrFlag(UINT32 flag)
{
    s_rruAddrFlag = flag;
    dbgInfo("s_rruAddrFlag = %d\n", s_rruAddrFlag);
}

T_RruCfgInfo *BspGetCfgInfo(VOID)
{
    if ((s_rruAddrFlag == 0) && (s_optNetCfgStatus == 0))
    {
        /* 收到有效的配置包后才返回 */
        return NULL;
    }
    return  &s_rruCfgInfo;
}

UINT32 BspGetOptNetCfgStatus(VOID)
{
    return s_optNetCfgStatus|s_optNetOkFlag;
}

UINT32 BspSetOptNetCfgStatus(UINT32 optCfgStatus)
{
    if(optCfgStatus > 1)
    {
        return BSP_ERROR;
    }
    else
    {
        s_optNetCfgStatus = optCfgStatus;
        return BSP_OK;
    }
}

UINT32 BspGetPhysAddr(T_BSP_PHYSICAL_ADDR *ptHwAddr)
{
    INPUT_POINTER_CHECK(ptHwAddr);

    memset((UCHAR *)ptHwAddr, 0, sizeof(T_BSP_PHYSICAL_ADDR));
    
    ptHwAddr->ucSlotId = DEFAULT_SLOT_NUM;  /* 槽 */
    ptHwAddr->ucBDSId  = s_rruCfgInfo.byShelfNo; /* 框 */
    ptHwAddr->ucRFSId  = s_rruCfgInfo.byShelfNo; /* 框 */
    ptHwAddr->ucBTSId  = s_rruCfgInfo.byRackNo;  /* 架 */
    ptHwAddr->ucCpuId  = s_cpuId;
    ptHwAddr->ucCoreId = s_coreId;

    return BSP_OK;
}

UINT8 BspGetCoreId(VOID)
{
    T_BSP_PHYSICAL_ADDR hwAddr = {0,};
    BspGetPhysAddr(&hwAddr);
    return hwAddr.ucCoreId;
}

UINT8 BspGetCpuId(VOID)
{
    T_BSP_PHYSICAL_ADDR hwAddr = {0,};
    BspGetPhysAddr(&hwAddr);
#ifdef VDE_TEST
    //VDE调试要求从片CPUID固定为2
    return 2;
#else
    return hwAddr.ucCpuId;
#endif
}

UINT8 BspGetRfsDevCoreId(UINT32 rfsId)
{
    return BspGetCoreId();
}

UINT8 BspGetRfsDevCpuId(UINT32 rfsId)
{
    return BspGetCpuId();
}

UINT32 BspGetDspCoreIdMask()
{
    return s_dspCoreMask;
}

UINT32 BspGetCtrlNetMac(UINT8 *pAddr)
{
    return BSP_OK;
}
UINT32 BspGetCtrlNetIp(UINT8 *pAddr)
{
    return BSP_OK;
}

UINT32 BspGetDataNetLinkState(UINT32 *pNetStatus)
{
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetDiskTotalSize(*)
 *  功能描述   : 获取主磁盘空间的总大小
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 返回值：空间总大小
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $614001397175，曾鑫@2011-6-8，移植到BspCommon统一实现
 *----------------------------------------------------------------------------
 */
UINT32 BspGetDiskTotalSize(VOID)
{
    static UINT32 totalDiskSize = 0;
     struct statfs disk_statfs;

    if(totalDiskSize > 0)
    {
        return totalDiskSize;
    }

    if(statfs("/ata",&disk_statfs) < 0)
    {
        dbgErr("statfs /ata error\n");
        return BSP_ERROR;
    }

    totalDiskSize = (UINT32)(disk_statfs.f_bsize*disk_statfs.f_blocks);

    dbgInfo("/ata : Total bytes is %d\n", totalDiskSize);

    return totalDiskSize;

}

/*****************************************************************************
 *  函数名称   : BspGetDiskFree(*)
 *  功能描述   : 获取主磁盘空间的剩余空间
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 返回值：具体的剩余空间大小
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $614001397175，曾鑫@2011-6-8，移植到BspCommon统一实现
 *----------------------------------------------------------------------------
 */
UINT32 BspGetDiskFree(VOID)
{
    struct   statfs   disk_statfs;
    ULONG ulFreeBytes = 0;

    if(statfs("/ata",   &disk_statfs) < 0)
    {
        dbgPrn("statfs /ata error\n");
        return BSP_ERROR;
    }

    ulFreeBytes = (ULONG)(disk_statfs.f_bsize * disk_statfs.f_bavail);

    dbgPrn("/ata : Free bytes is %d\n", ulFreeBytes);

    return ulFreeBytes;

}


UINT32 BspGetFsIp(VOID)
{
    UINT32 retVal = 0;
    T_RruCfgInfo *pCfgInfo = NULL;

    pCfgInfo = BspGetCfgInfo();
    INPUT_POINTER_CHECK( pCfgInfo );

    retVal = (pCfgInfo->aRruDftGateway[3] << 0) | 
             (pCfgInfo->aRruDftGateway[2] << 8) |
             (pCfgInfo->aRruDftGateway[1] << 16) | 
             (pCfgInfo->aRruDftGateway[0] << 24);
    return retVal;
}



UINT32 BspGetMasterIp(T_BSP_HOST_IP *pHostIp)
{
    UINT32 masterId = 0;
    T_RruCfgInfo *pCfgInfo = NULL;

    if (pHostIp == NULL)
    {
        return BSP_ERROR;
    }

    pCfgInfo = BspGetCfgInfo();
    if (pCfgInfo == NULL)
    {
        return BSP_ERROR;
    }

    memcpy(pHostIp->aucHostIp[0], pCfgInfo->aMch1Ip, sizeof(pCfgInfo->aMch1Ip));/* 左主板ip */
    memcpy(pHostIp->aucHostIp[1], pCfgInfo->aMch2Ip, sizeof(pCfgInfo->aMch2Ip));/* 右主板ip */
    pHostIp->ucHostId = (UINT8)masterId;

    return BSP_OK;
}


#ifdef DPDIC3_R921X_IC
UINT32 BspGetMch1Ip(UINT8 *pAddr)
{
    T_BSP_HOST_IP hostIp = {0,};
    INT32 ret = 0;
    INPUT_POINTER_CHECK(pAddr);

    if (BSP_OK != BspGetMasterIp(&hostIp))
    {
        dbgErr("Get Mch1 Ip failed.\n");
    }
    ret = sprintf_s((INT8 *)pAddr, 20, "%d.%d.%d.%d",
		hostIp.aucHostIp[0][0], 
		hostIp.aucHostIp[0][1], 
		hostIp.aucHostIp[0][2], 
		hostIp.aucHostIp[0][3]);
    if(ret)
    {
        return BSP_OK;
    } 
    else
    {
        return BSP_ERROR;
    }
}

UINT32 BspGetMch2Ip(UINT8 *pAddr)
{
    T_BSP_HOST_IP hostIp = {0,};
    INT32 ret = 0;
    INPUT_POINTER_CHECK(pAddr);

    if (BSP_OK != BspGetMasterIp(&hostIp))
    {
        dbgErr("Get Mch2 Ip failed.\n");
    }
	 ret = sprintf_s((INT8 *)pAddr, 20, "%d.%d.%d.%d",
				 hostIp.aucHostIp[1][0], 
				 hostIp.aucHostIp[1][1], 
				 hostIp.aucHostIp[1][2], 
				 hostIp.aucHostIp[1][3]);

	 if(ret)
	 {
		 return BSP_OK;
	 } 
	 else
	 {
		 return BSP_ERROR;
	 }
}
#else
UCHAR BspIsLittleEndian(VOID)
{
    union check_endian 
    {
       UINT32 u;
       UCHAR c;
    }uce;
    uce.u = 1;
    return uce.c;
}

UINT32 BspGetMch1Ip(UINT8 *pAddr)
{
    T_BSP_HOST_IP hostIp = {0,};
    INT32 ret = 0;
    INPUT_POINTER_CHECK(pAddr);

    if (BSP_OK != BspGetMasterIp(&hostIp))
    {
        dbgErr("Get Mch1 Ip failed.\n");
    }

    if(BspIsLittleEndian())
    {
        ret = sprintf_s((char *)pAddr, 20, "%d.%d.%d.%d",
            hostIp.aucHostIp[0][3], 
            hostIp.aucHostIp[0][2], 
            hostIp.aucHostIp[0][1], 
            hostIp.aucHostIp[0][0]);
    }
    else
    {
        ret = sprintf_s((char *)pAddr, 20, "%d.%d.%d.%d",
            hostIp.aucHostIp[0][0], 
            hostIp.aucHostIp[0][1], 
            hostIp.aucHostIp[0][2], 
            hostIp.aucHostIp[0][3]);    
    }

    if(ret)
    {
        return BSP_OK;
    } 
    else
    {
        return BSP_ERROR;
    }
}

UINT32 BspGetMch2Ip(UINT8 *pAddr)
{
    T_BSP_HOST_IP hostIp = {0,};
    INT32 ret = 0;
    INPUT_POINTER_CHECK(pAddr);    

    if (BSP_OK != BspGetMasterIp(&hostIp))
    {
        dbgErr("Get Mch2 Ip failed.\n");
    }

    if(BspIsLittleEndian())
    {
        ret = sprintf_s((char *)pAddr, 20, "%d.%d.%d.%d",
            hostIp.aucHostIp[1][3], 
            hostIp.aucHostIp[1][2], 
            hostIp.aucHostIp[1][1], 
            hostIp.aucHostIp[1][0]);
    }
    else
    {
        ret = sprintf_s((char *)pAddr, 20, "%d.%d.%d.%d",
            hostIp.aucHostIp[1][0], 
            hostIp.aucHostIp[1][1], 
            hostIp.aucHostIp[1][2], 
            hostIp.aucHostIp[1][3]);
    }
    
    if(ret)
    {
        return BSP_OK;
    } 
    else
    {
        return BSP_ERROR;
    }
}
#endif

VOID BspSetMchLocation(UINT32 flag)
{
    s_mchLocation = flag;
}

UINT32 BspGetMchLocation(VOID)
{
    return s_mchLocation;
}
UINT32 BspGetMchMaster(VOID)
{
    UINT32 data = 0;
    data = BspGetMchLocation();
    if (data & (1<<1))
    {
        return 2; /* 2槽主用 */
    }
    else
    {
        return 1; /* 1槽主用 */
    }
}

UINT32 BspGetRootDir(CHAR *pcDirBuf, UINT32 len)
{
    UINT32 ulRootDirSize = 0;
    const char *pucRootDirStr = NULL;
    INT32 snRet          = 0;

    INPUT_POINTER_CHECK(pcDirBuf);
//  sprintf(pcDirBuf, "/ata/"); // sprintf(pcDirBuf, "/mnt/jffs/");

    pucRootDirStr = "/ata/";
    ulRootDirSize = strlen(pucRootDirStr);
    if (ulRootDirSize >= len)
    {
        dbgErr("%s>>Param Error! len'%d must greater than %d\n",
               __FUNCTION__, len, ulRootDirSize);
    //  return BSP_ERROR;
    }

	snRet = snprintf_s(pcDirBuf, ulRootDirSize + 1, "%s", pucRootDirStr);
    SNPRINTF_S_CHECK(snRet, ulRootDirSize + 1);
    dbgInfo("%s>>ParamLen'%d RootDirLen'%d: CurrPath= [ %s ]\n",
            __FUNCTION__, len, ulRootDirSize, pcDirBuf);
    return BSP_OK;
}

UINT32 BspGetRruIp(UINT32 index)
{
    T_RruCfgInfo   *pCfgInfo;
    UINT32         rruIp = 0;
    UINT32         loop;

    if (index == 0)
    {
        pCfgInfo = BspGetCfgInfo();
        if (pCfgInfo == NULL)
        {
            return INVALID_VALUE;
        }

        /* byte 0为最高位 */
        dbgInfo("OptEnd Ip: %d.%d.%d.%d",
            pCfgInfo->aRruIp[0],
            pCfgInfo->aRruIp[1],
            pCfgInfo->aRruIp[2],
            pCfgInfo->aRruIp[3]);

        for (loop = 0; loop < 4; loop++)
        {
            rruIp |= pCfgInfo->aRruIp[loop] << (8 * (3 - loop));
            dbgInfo("rruIp = 0x%x", rruIp);
        }
        return rruIp;
    }
    else
    {
        return INVALID_VALUE;
    }
}


// 临时适配，为了大版本编译通过
UINT32 BspGetMpuIp (VOID)
{
    /*UINT32 mpuip = (198 << 24) | (33 << 16 )|( 33 << 8 )| 100;*/
    char mpuIp[32] = {"198.33.33.100"};
    UINT32 mpuIpData = 0;
    /*UINT32 mpuIpTemp = 0;*/
    mpuIpData = inet_addr(mpuIp);
    /*mpuIpData = htonl(mpuIpTemp);*/
    
    return mpuIpData;
    
}

UINT32 BspGetSerdesAndCpriStatus(UINT32 *pSerdesCpriStatus)
{
    return BSP_OK;
}



UINT32 BspOptNetCfgSemWait(VOID)
{
    return BSP_OK;
}

UINT32 BspOptNetCfgSemPost(VOID)
{
    return BSP_OK;
}

UINT32 BspSetBootpInfo(T_RruCfgInfo *pRruCfgInfo)
{
    return BSP_OK;
}


UINT32 BspSetSwitchCtrl(UINT32 funcId, UINT32 switchFlag)
{
    return BSP_OK;
}



UINT32  BspGetRamLowAddr(void)
{
    return 0;
}


/*****************************************************************************
*  函数名称   : BSPGetHardId  fdd建链时OSS调用
*  功能描述   : 获取机架，机框，槽位号，BBU下发
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   : 返回byte0-机架号，byte1-机框号，byte2-槽位号，byte3保留
*  其它说明   : BBU下发，从配置包中读取
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 鲁侃@2010-07-27 10:49:41, 创建
*----------------------------------------------------------------------------
*/
UINT32 BSPGetHardID(VOID)
{
    T_RruCfgInfo *ptCfg = NULL;
    UINT32         hardId = 0;
    ptCfg = BspGetCfgInfo();
    INPUT_POINTER_CHECK( ptCfg );

    hardId = ((ptCfg->byRackNo  & 0x0F) << 12) |
               ((ptCfg->byRackNo  & 0xF0) << 20) |
               ((ptCfg->byShelfNo & 0x0F) << 8)  |
               ((ptCfg->bySlotNo  & 0x1F));

    return hardId;
}

UINT32 BspGetHardId(VOID)
{
    T_RruCfgInfo *pCfg = NULL;
    UINT32       hardId = 0;
    
    pCfg = BspGetCfgInfo();
    INPUT_POINTER_CHECK(pCfg);

    hardId = ((pCfg->byRackNo  & 0x0F) << 12) |
             ((pCfg->byRackNo  & 0xF0) << 20) |
             ((pCfg->byShelfNo & 0x0F) << 8)  |
             ((pCfg->bySlotNo  & 0x1F));

    return hardId;
}

UINT32 BspInitFpgaReLoadFun(T_FpgaReLoadFlagFun *ptFpgaReLoadFlagFun)
{
    INPUT_POINTER_CHECK(ptFpgaReLoadFlagFun);
    memcpy(&FpgaReLoadFlagFun,ptFpgaReLoadFlagFun,sizeof(T_FpgaReLoadFlagFun));
    return BSP_OK;
}
T_FpgaReLoadFlagFun *BspGetFpgaReLoadFun(VOID)
{
    return &FpgaReLoadFlagFun;
}
/*-----------------------------------------------------*/
VOID BspSetFpgaReLoadFlag(UINT32 fpgaLoadFlag)
{

    T_FpgaReLoadFlagFun *ptFpgaReloadFlagFun = {0};

     ptFpgaReloadFlagFun = BspGetFpgaReLoadFun();

     if(ptFpgaReloadFlagFun->FpgaReLoadFlagSet !=NULL)
    {
        ptFpgaReloadFlagFun->FpgaReLoadFlagSet(fpgaLoadFlag);
    }
     
    return ;
}
UINT32 BspGetFpgaReLoadFlag(VOID)
{
    UINT32 ulRet = BSP_OK;
    
    T_FpgaReLoadFlagFun *ptFpgaReloadFlagFun = {0};
    
    ptFpgaReloadFlagFun = BspGetFpgaReLoadFun();

    if(ptFpgaReloadFlagFun->FpgaReLoadFlagGet !=NULL)
    {
        ulRet = ptFpgaReloadFlagFun->FpgaReLoadFlagGet();
    }

    return ulRet;   
}

UINT32 BspGetDryContactStatus(T_RruDryContactInfo *pInfo)
{
    UINT32 uLoop         = 0;
    UINT32 dryContact    = 0;
    UINT32 uDryConnetNum = 2;
    UINT32 pinIdx[BSP_MAX_DRYCONTACT_NUM] = {REG_DRY_NOD_1, REG_DRY_NOD_2, REG_DRY_NOD_3, REG_DRY_NOD_4};

    INPUT_POINTER_CHECK(pInfo);

    uDryConnetNum = BspGetDryctNum();
    if (uDryConnetNum > BSP_MAX_DRYCONTACT_NUM)
    {
        uDryConnetNum = BSP_MAX_DRYCONTACT_NUM;
    }

    for (uLoop = 0; uLoop < uDryConnetNum; uLoop++)
    {
        dryContact = BspRegPinRd(pinIdx[uLoop]) ? 1 : 0;
        pInfo->ulContactData[uLoop] = dryContact;
        dbgInfoEx("%s>>Dry(Idx'%d Sum'%d) DryContact= %d\n", __FUNCTION__, uLoop, uDryConnetNum, dryContact);
    }

    return BSP_OK;
}

static T_RadioPara s_RadioPara = {NULL,NULL};

UINT32 BspInitRadioPara(T_RadioPara *para)
{
    INPUT_POINTER_CHECK(para);
    memcpy(&s_RadioPara,para,sizeof(T_RadioPara));
    

    return BSP_OK;
}


UINT32 BspSetRadioStandard(UINT32 stdRadio)
{
    if (s_RadioPara.pSetRadionMode!=NULL)
	{
	   s_stdRadio = s_RadioPara.pSetRadionMode(stdRadio);
	}
	else
	{
        s_stdRadio = stdRadio;
	}
    return BSP_OK;
}

UINT32 BspGetRadioStandard(VOID)
{

    if (s_RadioPara.pGetRadionMode!=NULL)
	{
	   s_stdRadio = s_RadioPara.pGetRadionMode();
	}
	
    return s_stdRadio;
}

/*****************************************************************************
 *  函数名称   : BspGetDeviceStatus
 *  功能描述   : 获取设备状态
 *  输入参数   : ulDevId - 器件识别号
 *  输出参数   :
 *  返 回 值:
    #define BSP_DEVICE_STATE_OK             0x0000      //工作正常
    #define BSP_DEVICE_STATE_UNINIT         0x0001      //未加载
    #define BSP_DEVICE_STATE_NOT_EXIST      0x0002      //器件未纳入设计
    #define BSP_DEVICE_STATE_LOST           0x0003      //加载后异常
    #define BSP_DEVICE_STATE_LOADING        0x0004      //固件加载中
    #define BSP_DEVICE_STATE_LOAD_FAIL      0x0005      //加载失败
    #define BSP_DEVICE_STATE_READBACK_ALM   0x0006      //器件回读失败告警
    #define BSP_DEVICE_STATE_UNLOCK_ALM     0x0007      //失锁告警
    #define BSP_DEVICE_STATE_RUN_ALM        0x0008      //函数运行失败告警
    #define BSP_DEVICE_STATE_UNRUN_ALM      0x0009      //未进行初始化告警
    #define BSP_DEVICE_STATE_VER_FAIL       0x000a      //固件版本解析失败告警
    #define BSP_DEVICE_STATE_NOT_IN         0x000b      //器件不在位
 *  其它说明   : RRU公共接口函数
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetDeviceStatus(OSS_ULONG devId)
{
    UINT32 idBase = 0;
    UINT32 idOffset = 0;
    UINT32 ret = 0;
    OSS_ULONG id = 0;
    
    BspDevIdToBase(devId, &idBase, &idOffset);
    if (devId>BSP_ID_MAX)
    {
        id = BspDevNameToId((const char *)devId);
    }
    else
    {
        id = devId;
    }
    
    switch (idBase)
    {
        case BSP_DEVICE_ID_PLL_SYS:
        {
            if (NULL != pSysPllStatusGetFunc)
           {
              ret = pSysPllStatusGetFunc();
           }
           else
           {
               ret = BspGetClkPllSysLdStatus(id);
           }
            break;
        }
        case BSP_DEVICE_ID_PLL_TX0:
        case BSP_DEVICE_ID_PLL_RX0:
        case BSP_DEVICE_ID_PLL_FB0:
        {
            if (NULL != pLoPllStatusGetFunc)
           {
              ret = pLoPllStatusGetFunc(idBase);
           }
           else
           {
               ret = BspGetLoPllLd(id);
           }
            break;
        }
        case BSP_DEVICE_ID_FPGA0:
        {
#ifndef _4C_VDE_TEST_         
            ret = BspGetFpgaLoadStatus(idOffset);
#endif
            break;
        }
        default:
        {
            ret = BSP_DEVICE_STATE_NOT_EXIST;
            break;
        }
    }
    
    return ret;
}


UINT32 BspCheckPllStatus(OSS_ULONG DevAddr)
{
    UINT32 retVal               = BSP_OK;
    OSS_ULONG devAddrVal        = DevAddr;
    UINT32 idOffset             = 0;
    UINT32 devNo                = 0;
    UINT32 idBase               = 0;
    TRruDeviceDescription dev   = {0};
    T_RfPllCfgPriv *pRfPllCfg   = NULL;

    memset((UCHAR*)&dev,0,sizeof(dev));

    if ( BSP_ID_MAX < DevAddr)
    {
        devAddrVal = BspDevNameToId((const char *)(uintptr_t)DevAddr);
    }
    if(BSP_OK != BspDevInfoGetByDevId((UINT32)devAddrVal, &dev))
    {
        return BSP_OK;
    }
    BspDevIdToBase(devAddrVal, &idBase, &idOffset);
    switch (idBase)
    {
        /* 此时钟包括所有系统相关时钟都锁定 */
        case BSP_DEVICE_ID_PLL_SYS:
        case BSP_DEVICE_ID_PLL_OPT:
        {

            if (NULL != pSysPllStatusGetFunc)
           {
                retVal = pSysPllStatusGetFunc();
           }
           else
           {
               retVal = BspGetClkPllSysLdStatus(devAddrVal);
           }
            break;
        }
        case BSP_DEVICE_ID_PLL_TX0:
        case BSP_DEVICE_ID_PLL_RX0:
        case BSP_DEVICE_ID_PLL_FB0:
        {
            if (NULL != pLoPllStatusGetFunc)
            {
                retVal = pLoPllStatusGetFunc(idBase);
            }
            else
            {
                devNo           =   BspLoPllDevIdToDevNo(dev.ulDeviceId);
                pRfPllCfg       =   BspGetRfPllCfgPriv(devNo);
                if(pRfPllCfg == NULL)
                {
                    dbgErr("[%s]Get pRfPllCfg devNo %d Error \n",__FUNCTION__,devNo);
                    return BSP_ERROR;
                }
                if(pRfPllCfg->pChkLd == NULL)
                {
                    dbgErr("[%s]pGet LoPllLd devNo %d Point NULL \n",__FUNCTION__,devNo);
                    return BSP_ERROR;
                }
                retVal = pRfPllCfg->pChkLd(dev.ulDeviceIndex);
            }
            break;
        }
        default:
        {
            dbgErr("[%s]idBase  %d ERROR! \n",__FUNCTION__,idBase);
            return BSP_ERROR_DEVICE_NOT_EXIST;
        }
    }
    return retVal;
}
/*****************************************************************************
 *  函数名称   : BspGetPllDevStatus
 *  功能描述   : 获取设备状态
 *  输入参数   : ulDevId - 器件识别号
 *  输出参数   :
 *  返 回 值:
    #define BSP_DEVICE_STATE_OK             0x0000      //工作正常
    #define BSP_DEVICE_STATE_UNINIT         0x0001      //未加载
    #define BSP_DEVICE_STATE_NOT_EXIST      0x0002      //器件未纳入设计
    #define BSP_DEVICE_STATE_LOST           0x0003      //加载后异常
    #define BSP_DEVICE_STATE_LOADING        0x0004      //固件加载中
    #define BSP_DEVICE_STATE_LOAD_FAIL      0x0005      //加载失败
    #define BSP_DEVICE_STATE_READBACK_ALM   0x0006      //器件回读失败告警
    #define BSP_DEVICE_STATE_UNLOCK_ALM     0x0007      //失锁告警
    #define BSP_DEVICE_STATE_RUN_ALM        0x0008      //函数运行失败告警
    #define BSP_DEVICE_STATE_UNRUN_ALM      0x0009      //未进行初始化告警
    #define BSP_DEVICE_STATE_VER_FAIL       0x000a      //固件版本解析失败告警
    #define BSP_DEVICE_STATE_NOT_IN         0x000b      //器件不在位
 *  其它说明   : RRU公共接口函数
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPllDevStatus(OSS_ULONG devId)
{
    UINT32 idBase = 0;
    UINT32 idOffset = 0;
    UINT32 ret = 0;
    OSS_ULONG id = devId;   

    BspDevIdToBase(devId, &idBase, &idOffset);
    if (devId>BSP_ID_MAX)
    {        
        ret = BspDevNameToId((const char *)devId);
        if((ret ==BSP_ERROR )||(ret ==BSP_ERROR_NULL_POINTER ))
        {
            return BSP_ERROR;
        }
        id  = (OSS_ULONG)ret;
    }
    
    if (NULL != pLoPllStatusGetFunc_9626)
    {
        ret = pLoPllStatusGetFunc_9626(devId);

        return ret;
    }

    if((idBase <BSP_DEVICE_ID_PLL_TX0) || (idBase >BSP_DEVICE_ID_PLL_FB0))
    {
        return BSP_ERROR;    
    }
   
     if (NULL != pLoPllStatusGetFunc)
           {
              ret = pLoPllStatusGetFunc(idBase);
           }
           else
           {
               ret = BspGetLoPllLd(id);
           }
           

    return ret;
}

/*****************************************************************************
 *  函数名称   : BspPllDeviceRecover
 *  功能描述   : 获取设备状态
 *  输入参数   : ulDevId - 器件识别号
 *  输出参数   :
 *  返 回 值:
    #define BSP_DEVICE_STATE_OK             0x0000      //工作正常
    #define BSP_DEVICE_STATE_UNINIT         0x0001      //未加载
    #define BSP_DEVICE_STATE_NOT_EXIST      0x0002      //器件未纳入设计
    #define BSP_DEVICE_STATE_LOST           0x0003      //加载后异常
    #define BSP_DEVICE_STATE_LOADING        0x0004      //固件加载中
    #define BSP_DEVICE_STATE_LOAD_FAIL      0x0005      //加载失败
    #define BSP_DEVICE_STATE_READBACK_ALM   0x0006      //器件回读失败告警
    #define BSP_DEVICE_STATE_UNLOCK_ALM     0x0007      //失锁告警
    #define BSP_DEVICE_STATE_RUN_ALM        0x0008      //函数运行失败告警
    #define BSP_DEVICE_STATE_UNRUN_ALM      0x0009      //未进行初始化告警
    #define BSP_DEVICE_STATE_VER_FAIL       0x000a      //固件版本解析失败告警
    #define BSP_DEVICE_STATE_NOT_IN         0x000b      //器件不在位
 *  其它说明   : RRU公共接口函数
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspPllDeviceRecover(OSS_ULONG devId)
{
    UINT32 idBase = 0;
    UINT32 idOffset = 0;
    UINT32 ret = 0;
    OSS_ULONG id = devId; 

    BspDevIdToBase(devId, &idBase, &idOffset);
    if (devId>BSP_ID_MAX)
    {       
        ret = BspDevNameToId((const char *)devId);
        if((ret ==BSP_ERROR )||(ret ==BSP_ERROR_NULL_POINTER ))
        {
            return BSP_ERROR;
        }
       id  = (OSS_ULONG)ret;
    }
    
    if((idBase <BSP_DEVICE_ID_PLL_TX0) || (idBase >BSP_DEVICE_ID_PLL_FB0))
    {
        return BSP_DEVICE_STATE_NOT_EXIST;    
    }
    ret = BspLoPllRecov((UINT32)id);
       
    return ret;
}


UINT32 BspGetPllDevNum(T_loInfo *ptLoInfo)
{
    return  BspGetPllDeviceNum(ptLoInfo);
}

UINT32 BspMacAddrStr2Int(char *strInMac,UINT8 *arrOutMac)
{
    char *buf = strInMac;
    char *next = buf;
    UINT8 num = 0;
    while (*buf != '\0' && num < 6)
    {
        if (*buf == ':')
        {
            buf++;
            continue;
        }
        
        arrOutMac[num] = (UINT8)strtoul(buf, &next,16);
        if (next == NULL)
        {
            break;
        }
        
        num++;
        buf = next;
    }

    if (num < 6)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspSetBbuMac(UINT8 *mac)
{
    INPUT_POINTER_CHECK(mac);
    macPrn(mac,STRLF);
    return BSP_OK;
}

UINT32 BspSetBbuIp(UINT8 *ip)
{
    INPUT_POINTER_CHECK(ip);
    ipPrn(ip,STRLF);
    return BSP_OK;
}


static pGetFpgaMaxTempFunc pGetFpgaMaxTempCall = NULL;

UINT32 BspRegisterGetFpgaMaxTempCall(pGetFpgaMaxTempFunc pGetFpgaMaxTemp)
{
    pGetFpgaMaxTempCall = pGetFpgaMaxTemp;
    return BSP_OK;
}

UINT32 BspGetFpgaMaxTempResult(INT32 *lMaxTemp)
{
    if (NULL == pGetFpgaMaxTempCall)
    {
        dbgErr("[%s]:Call Back Function Is Wrong!!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (BSP_OK != pGetFpgaMaxTempCall(lMaxTemp))
    {
        dbgErr("[%s]:Get Max Fpga Temp Failed!!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*获取Dpll3状态*/
UINT32 BspIsPllUnLock(VOID)
{ 
    return BspGetDpll3State() == BSP_ERROR ? BSP_OK:BSP_ERROR;
}

/*判断是否支持时钟切换*/
UINT32 BspIsClkSupportSw(VOID)  
{
    return BspJudgeClkType() == BSP_ERROR ? BSP_ERROR : BSP_OK;
}

/*获取Rclk0频偏状态*/
UINT32 BspIsPllFreqNormal(VOID)
{
    return BspGetDpllRclk0FreqOffsetSta(0) == BSP_ERROR ? BSP_ERROR : BSP_OK;
}

/*获取Rclk1频偏状态*/
UINT32 BspIsClkCauseUnLock(VOID)
{
    return BspGetDpllRclk1FreqOffsetSta(0) == BSP_ERROR ? BSP_OK : BSP_ERROR;
}

/*54M于19.2M晶振切换接口*/
UINT32 BspSwClkType(UINT32 type)
{
    return ClkTypeSwitch(type);
}

/*切换允许标志接口*/
UINT32 BspIsClkAllowSw(VOID)
{
    return BspGetMcsRclkSta() == BSP_ERROR ? BSP_OK : BSP_ERROR;
}


/*提供type类型*/
UINT32 BspGetCurrClkType(VOID)
{
    return GetClkFreqType();
}


//调试函数

UINT32 GetFpgaMaxTempTest(VOID)
{
    INT32 lpTemp = 0;
    if (BSP_OK != BspGetFpgaMaxTempResult(&lpTemp))
    {   
        dbgErr("[%s]:Get Max Fpga Temperature Failed!!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("[%s]The Max Temperature Is %5.2f (Centigrade)of BBFPGA\n",__FUNCTION__,lpTemp/10.0);
    return BSP_OK;
}

//调试函数
/*is ubifs readonly filesystem? 
   0:  rw
   1:  ro
   2:  filesystem mount error
 -1:  error*/
#define FS_FILESYSTEM_NOTMOUNT  2
#define FS_FILESYSTEM_READONLY   1
#define FS_FILESYSTEM_RW               0 
#define MOUNT_INFO_FILE "/proc/mounts"   

UINT32 BspCheckFsRoStatus(VOID)
{
    FILE *fd = NULL;
    char *pReadBuf = NULL;
    char acStr1[100],acStr2[100],acStr3[100],acStr4[100]; 
    //int iCmdCnt=0;
    UINT32 ret= BSP_ERROR;
    int sscfRet;
    int fclsRet;

    fd = fopen(MOUNT_INFO_FILE,"r");
    if(NULL == fd)
    {
        dbgErr("%s>>Can not open /proc/mounts\n",__FUNCTION__);  
        return BSP_ERROR;
    }
    /* 申请暂存Buf */
    pReadBuf = (char  *)malloc(0x100);
    if(NULL == pReadBuf)
    {
        fclsRet = fclose(fd);
        FCLOSE_CHECK(fclsRet);
        dbgErr("%s>>Can't malloc buf\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* 循环读取每行 */
    while (NULL != fgets(pReadBuf, 100, fd))
    {
        /*ubi0_0 /mnt/filesystem ubifs rw,sync,relatime 0 0*/
        sscfRet = sscanf(pReadBuf ,"%6s %15s %5s %2s,", acStr1, acStr2, acStr3,
    acStr4);
        SSCANF_S_CHECK(sscfRet);
        /*printf("read str = %s %s %s %s\n",acStr1, acStr2, acStr3,acStr4);*/
        if(0 == strncmp("/mnt/filesystem", acStr2, 20))
        {
            if(0 == strncmp("rw", acStr4, 10))
            {
                ret = FS_FILESYSTEM_RW;
            } 
            else if(0 == strncmp("ro", acStr4, 10))
            {
                ret = FS_FILESYSTEM_READONLY;
            }  
            break;
        }      
    } 
    /*没有找到*/
    if(BSP_ERROR == ret)
    {
        dbgErr("%s>>filesystem not mount ! \n",__FUNCTION__);
        ret = FS_FILESYSTEM_NOTMOUNT;
    }

    free(pReadBuf);
    fclsRet = fclose(fd);
    FCLOSE_CHECK(fclsRet);
    return ret;
}
UINT32 RegPrintSwitchToRgpsInit(PrintSwitchToRgps pPrintSwitchToRgps)
{  
    gpPrintSwitchToRgps = pPrintSwitchToRgps;
    return BSP_OK;
}
UINT32 RegPrintSwitchToRgps(VOID)
{
	if(gpPrintSwitchToRgps != NULL)
	{
		return gpPrintSwitchToRgps();
	}

	return BSP_OK;
}


UINT32 BspIsMtsTransceiver(UINT32 *uIsMtsTrans)
{

    INPUT_POINTER_CHECK(uIsMtsTrans);
    if (pBspIsMtsTransceiver == (pFUNC_BSPISMTSTRANSCEIVER)NULL)
    {
        return BSP_ERROR;
    }
    return pBspIsMtsTransceiver(uIsMtsTrans);
}

UINT32 BspGetTxFaultFromMtsByChan(UINT32 uChan,UINT32 *uRegVal,UINT32 *uStatus)
{
    INPUT_POINTER_CHECK(uRegVal);
    INPUT_POINTER_CHECK(uStatus);
    if (pBspGetTxFaultFromMtsByChan == (pFUNC_BSPGETTXFAULTFROMMTSBYCHAN)NULL)
    {
        return BSP_ERROR;
    }
    return pBspGetTxFaultFromMtsByChan(uChan,uRegVal,uStatus);
}

UINT32 BspGetTxFaultFromMtsUnByChan(UINT32 *uRegVal,UINT32 *uStatus)
{
    INPUT_POINTER_CHECK(uRegVal);
    INPUT_POINTER_CHECK(uStatus);
    if (pBspGetTxFaultFromMtsUnByChan == (pFUNC_BSPGETTXFAULTFROMMTSUNBYCHAN)NULL)
    {
        return BSP_ERROR;
    }
    return pBspGetTxFaultFromMtsUnByChan(uRegVal,uStatus);
}

UINT32 BspIsMtsTransceiverCallBack(pFUNC_BSPISMTSTRANSCEIVER pFunc)
{
    pBspIsMtsTransceiver = pFunc;
    return BSP_OK;
}

UINT32 BspGetTxFaultFromMtsByChanCallBack(pFUNC_BSPGETTXFAULTFROMMTSBYCHAN pFunc)
{
    pBspGetTxFaultFromMtsByChan = pFunc;
    return BSP_OK;
}

UINT32 BspGetTxFaultFromMtsUnByChanCallBack(pFUNC_BSPGETTXFAULTFROMMTSUNBYCHAN pFunc)
{
    pBspGetTxFaultFromMtsUnByChan = pFunc;
    return BSP_OK;
}

UINT32 BspSetFddTddCoExistSta(UINT32 sta)
{
	g_fddTddCoExistSta = sta;
	return BSP_OK;
}

UINT32 BspGetFddTddCoExistSta(VOID)
{
	return g_fddTddCoExistSta;
}

UINT32 BspSetRdBoardTempFlag(UINT32 flag)
{
    g_rdBoardTempFlag = flag;
    return BSP_OK;
}

UINT32 BspGetRdBoardTempFlag(VOID)
{
    return g_rdBoardTempFlag;
}

/* Started by AICoder, pid:f2beez68capb85d141840958c0dd7d04f1c88bca */
UINT32 BspSetPaCtrlMode(UINT32 flag)
{
    g_PaCtrlMode = flag;
    return BSP_OK;
}
/* Ended by AICoder, pid:f2beez68capb85d141840958c0dd7d04f1c88bca */

/* Started by AICoder, pid:f4a4dc5faeq3dad14d7a0b2510083503745575b1 */
UINT32 BspGetPaCtrlMode(VOID)
{
    return g_PaCtrlMode;
}
/* Ended by AICoder, pid:f4a4dc5faeq3dad14d7a0b2510083503745575b1 */

UINT32 BspSetChanModeType(UINT32 *pPara,UINT32 num)
{
    INPUT_POINTER_CHECK(pPara);
	memcpy_s(g_chanModeType,sizeof(g_chanModeType),pPara,num*sizeof(UINT32));;
	return BSP_OK;
}

UINT32 BspGetChanModeType(UINT32 chan)
{
	if(chan >= MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}
	return g_chanModeType[chan];
}
UINT32 BspSetVectorVswrVal(UINT32 bspChn, UINT32 band, UINT32 vswrVal)
{
    if(bspChn >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
     s_VectorVal[bspChn][band] = vswrVal;

    return BSP_OK;
}

UINT32 BspGetVectorVswrVal(UINT32 bspChn, UINT32 band, UINT32 *pVswrVal)
{
    if(bspChn >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    if(NULL != pVswrVal)
    {
        *pVswrVal = s_VectorVal[bspChn][band];
    }

    return BSP_OK;
}

/* bsp初始化异常告警特性；
 * 根据刘志敬建议，目前只获取tranceiver初始化状态，后续可根据实际需要扩展
 */
UINT32 BspSetInitAlarmStatus(eAlarmInitAct act, UINT32 uStatus)
{
    UINT64    op = 0x1;     /* 解决KW告警 */

    if(act >= ALARM_ACTION_MAX_NUM)
    {
        return BSP_ERROR;
    }

    if(BSP_OK != uStatus)
    {
        g_InitAlarmStatus |= (op << act);
    }

    return BSP_OK;
}

UINT64 BspGetInitAlarmStatus(VOID)
{
    return g_InitAlarmStatus;
}

static pGetRfTempFunc pGetRfTempCall = NULL;

UINT32 BspRegisterGetRfTempCall(pGetRfTempFunc pGetRfTemp)
{
    pGetRfTempCall = pGetRfTemp;
    return BSP_OK;
}

UINT32 BspGetRfTempByChanBand(UINT32 ulChan,UINT32 ulBand, INT32 *pTemp)
{
    if (NULL == pGetRfTempCall)
    {
        dbgInfoEx("[%s]:Call Back Function Is Wrong!!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (BSP_OK != pGetRfTempCall(ulChan, ulBand, pTemp))
    {
        dbgErr("[%s]:Get Rf Temperature Failed!!!",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

VOID BspSetLogPath(const char *pLogPath)
{
    if (NULL == pLogPath)
    {
        return;
    }
    s_bspLogPath = pLogPath;
    return;
}

const char* BspGetLogPath(VOID)
{
    return s_bspLogPath;
}

UINT32 BspGetRfPllLoFreq(UINT32 devId,UINT32 *freq)
{
    UINT32 ret      = BSP_OK;
    UINT32 devNo    = 0;
    TRruDeviceDescription dev      = {0};
    T_RfPllCfgPriv *pRfPllCfg = NULL;
    memset((void *)&dev, 0, sizeof(dev));

    ret = BspDevInfoGetByDevId(devId, &dev);

    if (BSP_OK != ret)
    {
        return ret;
    }
    devNo           =   BspLoPllDevIdToDevNo(dev.ulDeviceId);
    pRfPllCfg       =   BspGetRfPllCfgPriv(devNo);
    if(pRfPllCfg == NULL)
    {
        dbgErr("[%s]Get pRfPllCfg devNo %d Error \n",__FUNCTION__,devNo);
        return BSP_ERROR;
    }
    if(pRfPllCfg->pGetFreqNew != NULL)   /*MTS2.0 会挂接这个接口，其他trancesiver 走原来接口*/
    {
        ret = pRfPllCfg->pGetFreqNew(dev.ulDeviceIndex,dev.ulDeviceInterIndex,freq);
        return ret;
    }
    if(pRfPllCfg->pGetFreq != NULL)
    {
        ret = pRfPllCfg->pGetFreq(dev.ulDeviceIndex,freq);
        return ret;
    }
    dbgErr("[%s]pGet LoPll pGetFreq devNo %d Point NULL \n",__FUNCTION__,devNo);
    return BSP_ERROR;

}

UINT32 BspGetRfPllLoLd(UINT32 devId)
{
    UINT32 devNo = 0;
    UINT32 ret   = BSP_OK;
    TRruDeviceDescription dev = {0};
    T_RfPllCfgPriv *pRfPllCfg = NULL;

    memset((void *)&dev, 0, sizeof(dev));
    /* 单板无本振芯片时(特性表无芯片配置)，获取本振锁定状态上报锁定; 即通过
       DevId获取DevInfo失败, 认为芯片不存在, 函数返回BSP_OK(本振锁定指示) */
    ret = BspDevInfoGetByDevId(devId, &dev);
    if (BSP_OK != ret)
    {
        dbgInfoEx("%s>>DevId'%d GetDevInfo Error! LoChip Not Exist! Default Locked\n",
                  __FUNCTION__, devId);
        return BSP_OK; // return ret;
    }

    devNo     = BspLoPllDevIdToDevNo(dev.ulDeviceId);
    pRfPllCfg = BspGetRfPllCfgPriv(devNo);
    if(pRfPllCfg == NULL)
    {
        dbgErr("[%s]Get pRfPllCfg devNo %d Error \n",__FUNCTION__,devNo);
        return BSP_ERROR;
    }
    if(pRfPllCfg->pChkLdNew != NULL)
    {
        ret = pRfPllCfg->pChkLdNew(dev.ulDeviceIndex,dev.ulDeviceInterIndex);
        return ret;
    }
    if(pRfPllCfg->pChkLd != NULL)
    {
        ret = pRfPllCfg->pChkLd(dev.ulDeviceIndex);
        return ret;
    }
    dbgErr("[%s]pGet LoPllLd devNo %d Point NULL \n",__FUNCTION__,devNo);
    return BSP_ERROR;

}

UINT32 BspLadarSetSampleSta(UINT32 bspRxChan, UINT32 sta)
{
    if (bspRxChan >= MAX_RX_CHAN)
    {
        return BSP_ERROR_INVALID_PARA;
    }
    s_ladarSta[bspRxChan] = sta;
    return BSP_OK;
}

UINT32 BspLadarGetSampleSta(UINT32 bspRxChan)
{
    if (bspRxChan >= MAX_RX_CHAN)
    {
        return BSP_ERROR_INVALID_PARA;
    }
    return  s_ladarSta[bspRxChan];
}

/*当前通道是否处于强制模式 默认0为非强制模式 需要通知到DSP*/
UINT32 BspSetChCbSwCtrlMode(UINT32 ulChan, UINT32 ulMode)
{
    if (ulChan >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    g_ulChCbSwCtrlMode[ulChan] = ulMode;

    return BSP_OK;
}
UINT32 BspGetChCbSwCtrlMode(UINT32 ulChan)
{
    if (ulChan >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    return g_ulChCbSwCtrlMode[ulChan];
}

/* portId : 0 1 2 代表ABC端口   portType: 0母端   1接子端 portSta: 端口建链状态 0 断链  1建链*/
UINT32 BspSetSlavePortCfgInfo(UINT32 ulPortId, UINT32 ulPortType,UINT32 ulPortSta)
{
    if(ulPortId >= MAX_SLAVEPORT_NUM)
    {
        return BSP_ERROR;
    }
    g_ulSlavePortCfgType[ulPortId] = ulPortType;
    g_ulSlavePortCfgSta[ulPortId] = ulPortSta;

    return BSP_OK;
}

/*获取高层下发的端口类型*/
UINT32 BspGetSlavePortCfgTpye(UINT32 ulPortId, UINT32 *pPortType)
{
    /*从bsp通道到端口，再获取状态  ，bit[0:3]:端口状态  bit[4:7] 子端还是母端*/
    if(ulPortId >= MAX_SLAVEPORT_NUM)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pPortType);
    *pPortType =  g_ulSlavePortCfgType[ulPortId];
    dbgInfoEx("ulPortId %d portType %d\n", ulPortId, *pPortType);
    return BSP_OK;
}

/*获取高层下发的端口状态*/
UINT32 BspGetSlavePortCfgSta(UINT32 ulPortId, UINT32 *pPortSta)
{
    if(ulPortId >= MAX_SLAVEPORT_NUM)
    {
        return BSP_ERROR;
    }
    /*从bsp通道到端口，再获取状态  ，bit[0:3]:端口状态  bit[4:7] 子端还是母端*/
    INPUT_POINTER_CHECK(pPortSta);
    *pPortSta =  g_ulSlavePortCfgSta[ulPortId];
    dbgInfoEx("ulChan %d portType %d\n", ulPortId, *pPortSta);
    return BSP_OK;
}

VOID BspSetBbuUniqueIdFlashId(UINT32 Offset)
{
    s_BbuUniqueIdFlashId = Offset;
}

static UINT32 BspGetBbuUniqueIdOffset()
{
    return s_BbuUniqueIdFlashId;
}

// 锁定返回1,未锁定返回0
static UINT32 BspGetBbuUniqueIdLockFlag(VOID)
{
    INT32 retVal;

    retVal = access(BBU_FLASH_ID_LOCK_FILE, F_OK);
    if (retVal != 0)
    {
        return 0;
    }

    return 1;
}

// 设置锁定状态,锁定就是创建文件，否则就是删除文件
static UINT32 BspSetBbuUniqueIdLockFlag(UCHAR lockFlag)
{
    INT32 retVal;
    FILE *fp = NULL;

    if (lockFlag)
    {
        fp = fopen(BBU_FLASH_ID_LOCK_FILE, "w+b");
        if (fp == NULL)
        {
            dbgErr("%s: create %s failed\n", __FUNCTION__, BBU_FLASH_ID_LOCK_FILE);
            return BSP_ERROR;
        }
        retVal = fclose(fp);
        if (retVal != 0)
        {
            dbgErr("%s: close %s failed\n", __FUNCTION__, BBU_FLASH_ID_LOCK_FILE);
            return BSP_ERROR;
        }
    }
    else
    {
        retVal = unlink(BBU_FLASH_ID_LOCK_FILE);
        if (retVal != 0)
        {
            dbgErr("%s: unlink %s failed\n", __FUNCTION__, BBU_FLASH_ID_LOCK_FILE);
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

UINT32 BspGetBbuUniqueId(UCHAR *uniqueId)
{
    INPUT_POINTER_CHECK(uniqueId);

    if (BspGetBbuUniqueIdOffset() == 0)
    {
        // RRU 不支持
        return RRU_NOT_SUPPORT;
    }

    // 没有锁定，flash中就是无效值，返回错误
    if (BspGetBbuUniqueIdLockFlag() != 1)
    {
        return RRU_NOT_LOCK;
    }

    if (BspFlashRead(BspGetBbuUniqueIdOffset(), uniqueId, 1) != BSP_OK)
    {
        dbgErr("%s, read bbu unique id failed", __FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}

static UINT32 BspUnlockBbuUniqueId(UCHAR uniqueId, UCHAR secondSet)
{
    if (secondSet == 1 && (uniqueId == 0 || uniqueId == 0xff))
    {
        if (BspSetBbuUniqueIdLockFlag(0) == BSP_OK)
        {
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

UINT32 BspSetBbuUniqueId(UCHAR uniqueId, UCHAR secondSet)
{
    if (BspGetBbuUniqueIdOffset() == 0)
    {
        // RRU 不支持
        return RRU_NOT_SUPPORT;
    }

    // 解锁成功返回成功,不执行后续操作
    if (BspUnlockBbuUniqueId(uniqueId, secondSet) == BSP_OK)
    {
        return BSP_OK;
    }

    // 非二次烧录时，判断是否锁定
    if (secondSet == 0 && BspGetBbuUniqueIdLockFlag() == 1)
    {
        // ID已经设置过了
        return RRU_HAS_LOCKED;
    }

    if (BspFlashWrite(BspGetBbuUniqueIdOffset(), &uniqueId, 1) != BSP_OK)
    {
        dbgErr("%s, write bbu unique id failed", __FUNCTION__);
        return BSP_ERROR;
    }

    if (BspSetBbuUniqueIdLockFlag(1) != BSP_OK)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*防串码机型列表,预留暂时不用*/
T_VendorString AntiThefMode0RruList[] =
{
    {"",       "",       ""    },/*最后一个以""结尾*/
};
/*主动防盗机型列表*/
/*
 R9264 M1821
 R9264H M182126
 *当pid不用关注时，pid字段和频段写成一致
*/
T_VendorString AntiThefMode1RruList[] =
{
    {"R9264H", "M182126", "M182126"},
    {"R9264", "M1821",   "M1821"  },
    {"",       "",        ""       },
};
static ULONG BspVendorStringPointerChk(const T_VendorString *pVendorString)
{
    ULONG ret = BSP_OK;

    if (NULL == pVendorString)
    {
        dbgInfo("Line[%d], input pointer null\n", __LINE__);
        return BSP_ERROR;
    }

    if ((0 == zte_strnlen_s(pVendorString->VendorFamily, NELEMENTS(pVendorString->VendorFamily))) ||
        (0 == zte_strnlen_s(pVendorString->VendorBand, NELEMENTS(pVendorString->VendorBand)))   ||
        (0 == zte_strnlen_s(pVendorString->VendorPid, NELEMENTS(pVendorString->VendorPid))))
    {
        dbgInfo("Line[%d], strlen 0\n", __LINE__);
        ret =  BSP_ERROR;
    }

    return ret;
}

static ULONG BspGetRruIsSupportAntiThefByVendorString(const T_VendorString *pVendorString, const char *pBoardVendorString)
{
    ULONG ret = BSP_ERROR;

    INPUT_POINTER_CHECK(pBoardVendorString);
    if (BSP_ERROR == BspVendorStringPointerChk(pVendorString))
    {
        dbgInfo("BspVendorStringPointerChk failed\n");
        return BSP_ERROR;
    }

    if ((CHAR *)NULL != strstr(pBoardVendorString, pVendorString->VendorFamily)  &&
        (CHAR *)NULL != strstr(pBoardVendorString, pVendorString->VendorBand)    &&
        (CHAR *)NULL != strstr(pBoardVendorString, pVendorString->VendorPid))
    {
        dbgInfo("Line[%d],pBoardVendorString:[%s]\n", __LINE__, pBoardVendorString);
        dbgInfo("Line[%d],VendorFamily[%s],  VendorBand[%s], VendorPid[%s]\n", __LINE__, pVendorString->VendorFamily, pVendorString->VendorBand, pVendorString->VendorPid);
        ret =  BSP_OK;
    }

    return ret;
}

static ULONG BspCheckRruAntiThefList(const T_VendorString *pVendorString, UINT32 venderCnt, const char *pBoardVendorString)
{
    ULONG index = 0;
    ULONG ret = BSP_ERROR;

    INPUT_POINTER_CHECK(pBoardVendorString);
    if (BSP_ERROR == BspVendorStringPointerChk(pVendorString))
    {
        dbgInfo("BspVendorStringPointerChk failed\n");
        return BSP_ERROR;
    }

    for (index = 0; ((index < venderCnt) && (BSP_ERROR != BspVendorStringPointerChk(&pVendorString[index]))); index++)
    {
        ret = BspGetRruIsSupportAntiThefByVendorString(&pVendorString[index], pBoardVendorString);
        if (BSP_OK == ret)
        {
            dbgInfo("Line[%d],index[%d], pBoardVendorString:[%s]\n", __LINE__, index, pBoardVendorString);
            dbgInfo("Line[%d],VendorFamily[%s],  VendorBand[%s], VendorPid[%s]\n", __LINE__, pVendorString[index].VendorFamily, pVendorString[index].VendorBand, pVendorString[index].VendorPid);
            return BSP_OK;
        }
    }
    dbgInfo("Line[%d],index[%d], pBoardVendorString:[%s] not found\n", __LINE__, index, pBoardVendorString);

    return BSP_ERROR;
}

/*支持主动防盗机型
 R9264 M1821
 R9264H M182126
**/
static ULONG BspIsSupportAntiThefRru(ULONG mode)
{
    ULONG ret = BSP_ERROR;
    T_BspInventoryInfo *ptDevInfo = NULL;
    ptDevInfo = (T_BspInventoryInfo *)malloc(sizeof(T_BspInventoryInfo));
    if (ptDevInfo == NULL)
    {
        dbgInfo("ptDevInfo malloc error;\n");
        return BSP_ERROR;
    }

    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))
    {
        dbgInfo("BspIsSupportAntiThefRru mode[%d] err \n", mode);
        free(ptDevInfo);
        return BSP_ERROR;
    }

    (void)BspGetRruInventory(ptDevInfo);
    if (ANTI_THEF_MODE0 == mode)
    {
        ret = BspCheckRruAntiThefList(AntiThefMode0RruList, NELEMENTS(AntiThefMode0RruList), ptDevInfo->acVendorUnitTypeNumber);/*防串码*/
    }
    else
    {
        ret = BspCheckRruAntiThefList(AntiThefMode1RruList, NELEMENTS(AntiThefMode1RruList), ptDevInfo->acVendorUnitTypeNumber);/*主动防盗*/
    }

    dbgInfo("ptDevInfo->acVendorUnitTypeNumber :%s \n", ptDevInfo->acVendorUnitTypeNumber);
    free(ptDevInfo);

    return ret;
}

ULONG BspSetRruAntiFun(VOID)
{
    ULONG ret = BSP_OK;
    ULONG antiFunc = 0;

    if (BSP_OK == BspIsSupportAntiThefRru(ANTI_THEF_MODE0))/*anti-counterfeiting(bit0)，暂不交付*/
    {
        antiFunc = ANTI_THEF_MODE0_VAL;
    }

    if (BSP_OK == BspIsSupportAntiThefRru(ANTI_THEF_MODE1))/*proactive theft prevention(bit1)*/
    {
        antiFunc |= ANTI_THEF_MODE1_VAL;
    }

    ret = BspSetAntiTheftFun(antiFunc);

    return ret;
}


/*Unlocking, anti-counterfeiting and proactive theft prevention*/
static UINT32 BspUnlockAntiThefId(ULONG mode, UCHAR uniqueId, UCHAR secondSet)
{
    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))
    {
        dbgInfo("BspUnlockAntiThefId mode[%d] err\n", mode);
        return 1;
    }
    
    /*二次烧录且ID非法*/
    if (secondSet == 1 && (uniqueId == 0 || uniqueId == 0xff))
    {
        // 如果当前未上锁,解锁也返回成功
        if (BspGetAntiThefLockFlag(mode) == 0)
        {
            return BSP_OK;
        }
        if (BspSetAntiThefLockFlag(mode, 0) == BSP_OK)/*解锁*/
        {
            return BSP_OK;
        }
    }

    return 1;
}

/*Set AntiThef Id*/
ULONG BspSetBbuUniqueIdEx(UCHAR uniqueIdInput, UCHAR secondSet, UCHAR ucFunction)
{
    ULONG errorCode = 0xFFFFFFFF;
    UCHAR mode = ucFunction - 1;
    UCHAR uniqueId = uniqueIdInput;
    dbgInfo("%s: uniqueId[%d], secondSet[%d], ucFunction[%d] puniqueId[%p]\n", __FUNCTION__, uniqueId, secondSet, ucFunction, &uniqueId);
    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))/*ucFunction 传入参数不为2或者3，则报错*/
    {
        dbgErr("%s, mode[%d] ucFunction[%d]err\n", __FUNCTION__, mode, ucFunction);
        return errorCode;
    }

    if (BspGetAntiThefFlashId(mode) == 0)
    {
        // RRU 不支持
        return RRU_NOT_SUPPORT;
    }

    // 解锁成功返回成功,不执行后续操作   一次烧录，或者二次烧录且id有效时直接返回1进入后续烧写流程
    if (BspUnlockAntiThefId(mode, uniqueId, secondSet) == BSP_OK)
    {
        return BSP_OK;
    }

    // 不是二次烧录时判断是否锁定
    if (secondSet == 0 && BspGetAntiThefLockFlag(mode) == 1)
    {
        // ID已经设置过了
        return RRU_HAS_LOCKED;
    }
    dbgInfo("addr[0x%08x], &uniqueId[%p], uniqueId[0x%x]\n", BspGetAntiThefFlashId(mode), (void*)(&uniqueId), uniqueId);
    if (BspFlashWrite(BspGetAntiThefFlashId(mode), &uniqueId, 1) != BSP_OK)
    {
        dbgErr("%s, write bbu unique id failed\n", __FUNCTION__);
        return errorCode;
    }

    if (BspSetAntiThefLockFlag(mode, 1) != BSP_OK)
    {
        return errorCode;
    }

    return BSP_OK;
}

/*Get Antithef ID*/
ULONG BspGetBbuUniqueIdEx(UCHAR *uniqueId,  UCHAR ucFunction)
{
    ULONG errorCode = 0xFFFFFFFF;
    UCHAR mode = ucFunction - 1;
    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))/*ucFunction isn'n 2 or 3,return error*/
    {
        dbgErr("%s, mode[%d] ucFunction[%d]err\n", __FUNCTION__, mode, ucFunction);
        return errorCode;
    }

    if (uniqueId == NULL)
    {
        return errorCode;
    }

    if (BspGetAntiThefFlashId(mode) == 0)
    {
        /*RRU not support*/
        return RRU_NOT_SUPPORT;
    }

    /*If it is not locked, the value in flash is invalid and an error will be returned*/
    if (BspGetAntiThefLockFlag(mode) != 1)
    {
        return RRU_NOT_LOCK;
    }
    dbgInfo("addr[0x%08x], uniqueId[%p], *uniqueId[0x%x]\n", BspGetAntiThefFlashId(mode), (void*)uniqueId, *uniqueId);
    if (BspFlashRead(BspGetAntiThefFlashId(mode), uniqueId, 1) != BSP_OK)
    {
        dbgErr("%s, read bbu unique id failed\n", __FUNCTION__);
        return errorCode;
    }

    return BSP_OK;
}

/*Set lock flag, anti-counterfeiting and proactive theft prevention*/
ULONG BspSetAntiThefLockFlag(ULONG mode, UCHAR lockFlag)
{
    ULONG errorCode = 0xFFFFFFFF;
    UCHAR uniqueId = 0x0;

    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))
    {
        dbgInfo("BspSetAntiThefLockFlag mode[%d] err\n", mode);
        return errorCode;
    }
    
    if (0 == BspGetAntiThefFlashId(mode))
    {
        dbgInfo("BspSetAntiThefLockFlag[%d] flash addr err\n", mode);// RRU 不支持
        return errorCode;
    }
    
    if (0 == lockFlag)/*擦除操作*/
    {
        uniqueId = 0xFF;
    }
    else             /*写主动防盗标志(byte4)或者写防窜货标志(byte3)0x5a*/
    {
        uniqueId = 0x5A;
    }
    
    if (BSP_OK != BspFlashWrite(BspGetAntiThefFlashId(mode) + 2, &uniqueId, 1))
    {
        dbgErr("%s, write bbu unique id 0xff failed\n", __FUNCTION__);
        return errorCode;
    }

    return BSP_OK;
}

/*Get lock flag, anti-counterfeiting and proactive theft prevention*/
UINT32 BspGetAntiThefLockFlag(ULONG mode)
{
    INT32 retVal;
    UCHAR uniqueId = 0;

    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))
    {
        dbgInfo("BspGetAntiThefLockFlag mode[%d] err \n", mode);
        return 0;
    }
    
    if (0 == BspGetAntiThefFlashId(mode))
    {
        dbgInfo("BspGetAntiThefLockFlag[%d] flash addr err\n", mode);// RRU 不支持
        return 0;
    }
    
    retVal = BspFlashRead(BspGetAntiThefFlashId(mode) + 2, &uniqueId, 1);
    if(BSP_OK != retVal)
    {
        dbgErr("%s, BspFlashRead failed\n", __FUNCTION__);
        return 0;
    }
    dbgInfo("uniqueId[%d]\n", uniqueId);
    if (0x5A != uniqueId)
    {
        return 0;
    }
    
    return 1;
}

/*anti-counterfeiting and proactive theft prevention*/
/*Set flash address, anti-counterfeiting and proactive theft prevention*/
VOID BspSetAntiThefFlashId(ULONG mode, ULONG flashId)
{
    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))
    {
        dbgInfo("BspSetAntiThefFlashId mode[%d] err \n", mode);
        return ;
    }
    s_AntiThefFlashId[mode] = flashId;
}

static ULONG BspGetAntiThefFlashId(ULONG mode)
{
    if ((ANTI_THEF_MODE0 != mode) && (ANTI_THEF_MODE1 != mode))
    {
        dbgInfo("BspGetAntiThefFlashId mode[%d] err \n", mode);
        return 0;
    }
    return s_AntiThefFlashId[mode];
}

static VOID readAntiThefIdTest(VOID)
{
    UCHAR buf[5] = {0};
    UINT32 i = 0;
    
    dbgInfo("Addr[0x%08x]", BspGetAntiThefFlashId(0));
    for (i = 0; i < sizeof(buf) / sizeof(buf[0]); i++)
    {
        BspFlashRead(BspGetAntiThefFlashId(0) + i, &buf[i], 1);
        
    }
    
    for (i = 0; i < sizeof(buf) / sizeof(buf[0]); i++)
    {
        dbgInfo("0x%02x-", buf[i]);
    }
    
    dbgInfo("\n");
}

/*给子端配置tdd帧结构*/
UINT32 BspSlavePortTddCfgCallBack(SET_TDDCFG_TO_SALVEPORT pFuncCallback)
{
    pSetTddCfgToSlavePort = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSetSlavePortTddCfg(UINT32 portId)
{
    UINT32 retVal = BSP_OK;

    if(NULL != pSetTddCfgToSlavePort)
    {
         return pSetTddCfgToSlavePort(portId);
    }
    return retVal;
}

/*上报是否支持子端拉远的标志*/
UINT32 BspIsSupportRfsRemote(VOID)
{
    return s_slaveSupportFlag;
}

/*设置当前机型是否支持子端拉远的标志*/
UINT32 BspSetSupportRfsRemoteFlag( UINT32 flag)
{
    s_slaveSupportFlag = flag;
    return BSP_OK;
}

UINT32 BspSetPaDrainAdjSupportFlag(UINT32 flag)
{
    s_adjSupportFlag = flag;
    return BSP_OK;
}

UINT32 BspGetPaDrainAdjSupportFlag(VOID)
{
    return s_adjSupportFlag;
}

/**************************************************************************
* 函数名称: BspGetDeviceNodeNum
* 功能描述: 获取对应器件的节点个数,eg:每个电源插头对应的连接器节点数，每片IC对应的单板温度检测点等
* 输入参数: CHAR *deviceName, UINT32 charLength
* 输出参数: 无
*
* 返 回 值: 获取对应器件的节点个数
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 BspGetDeviceNodeNum(CHAR *deviceName, UINT32 charLength)
{
    UINT32 loop = 0;
    UINT32 devNum = 0;
    UINT32 deviceNodeNum = 0;
    CHAR   *deviceId = NULL;
    T_HwInfo* hwInfo = NULL;

    if(NULL == deviceName)
    {
        dbgErr("%s:Input Pointer is NULL!\n", __FUNCTION__);
        return deviceNodeNum;
    }

    devNum = BspGetDevNum();
    hwInfo = BspGetBoardPropInfo();
    if (NULL == hwInfo)
    {
        dbgErr("%s>>Get hwInfo Failed!\n", __FUNCTION__);
        return deviceNodeNum;
    }

    for (loop = 0; loop < devNum; loop++)
    {
        deviceId = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acDeviceId;
        if (0 == strncmp(deviceName, deviceId, charLength))
        {
            deviceNodeNum++;
        }
    }

    return deviceNodeNum;
}

/**************************************************************************
* 函数名称: BspGetDeviceSerialCfg
* 功能描述: 获取对应器件的节点的器件序号信息，例如电源连接器节点0，1的数组信息对应插头序号0
* 输入参数: CHAR *device, UINT32 charLength, UINT32 nodeNum,
* 输出参数:  UINT32 *nodeRcord
*
* 返 回 值:
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 BspGetDeviceSerialCfg(CHAR *deviceName, UINT32 charLength, UINT32 *nodeRcord, UINT32 recordLength)
{
    UINT32   loop = 0;
    UINT32   num = 0;
    UINT32   devNum = 0;
    UINT32   pathIndex = 0;
    CHAR     *deviceId = NULL;
    T_HwInfo* hwInfo = NULL;

    INPUT_POINTER_CHECK(deviceName);
    INPUT_POINTER_CHECK(nodeRcord);

    devNum = BspGetDevNum();
    hwInfo = BspGetBoardPropInfo();
    if (NULL == hwInfo)
    {
        dbgErr("%s>>Get hwInfo Failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for (loop = 0; loop < devNum; loop++)
    {
        deviceId = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acDeviceId;
        if (0 == strncmp(deviceName, deviceId, charLength))
        {
            pathIndex = hwInfo->BoardInfo.pDeviceInfoDscp[loop].ulPathIndex;
            if(num < recordLength)
            {
                nodeRcord[num] = pathIndex;
                num++;
            }
        }
    }

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspGetSectorMaskByDevice
* 功能描述: 获取器件对应的扇区功放掩码
* 输入参数: UINT32 index, CHAR *deviceName, UINT32 charLength
* 输出参数: 无
*
* 返 回 值: 返回扇区掩码值
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 BspGetSectorMaskByDevice(UINT32 index, CHAR *deviceName, UINT32 charLength)
{
    UINT32 loop = 0;
    UINT32 devNum = 0;
    UINT32 paBitMask = 0;
    CHAR   *deviceId = NULL;
    CHAR   *pathName = NULL;
    CHAR    arrMask[BAR_MAX_LENGTH] = {'\0'};
    T_HwInfo* hwInfo = NULL;

    if(NULL == deviceName)
    {
        dbgErr("%s:Input Pointer is NULL!\n", __FUNCTION__);
        return paBitMask;
    }

    devNum = BspGetDevNum();
    hwInfo = BspGetBoardPropInfo();
    if (NULL == hwInfo)
    {
        dbgErr("%s>>Get hwInfo Failed!\n", __FUNCTION__);
        return paBitMask;
    }

    for(loop = 0; loop < devNum; loop++)
    {
        deviceId = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acDeviceId;
        pathName = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acPathName;

        if((index == hwInfo->BoardInfo.pDeviceInfoDscp[loop].ulPathIndex) && (0 == strncmp(deviceName, deviceId, charLength)))
        {
            for(loop = 0; loop < BAR_MAX_LENGTH; loop++)
            {
                arrMask[loop] = pathName[loop];
                if('\0' == arrMask[loop])
                {
                    paBitMask = (UINT32)BspAtoi(arrMask, 0);
                    break;
                }
            }
            break;
        }
    }

    return paBitMask;
}

/**************************************************************************
* 函数名称: BspGetDeviceNum
* 功能描述: 获取对应器件个数,eg:RRU电源插头个数，RRU整机IC片个数等
* 输入参数: CHAR *deviceName, UINT32 charnum
* 输出参数: 无
*
* 返 回 值: 获取RRU对应器件的个数
* 其它说明:
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A)
*----------------------------------------------------------------------------*/
UINT32 BspGetDeviceNum(CHAR *deviceName, UINT32 charLength)
{
    UINT32 deviceNum = 0;
    UINT32 loop = 0;
    UINT32 num = 0;
    UINT32 devNum = 0;
    UINT32 pathIndex = 0;
    UINT32 deviceRecord[RRU_MAX_DEVICE_NODE_NUM] = {0};
    UINT32 record[RRU_MAX_DEVICE_NODE_NUM] = {0};
    CHAR *deviceId = NULL;
    T_HwInfo* hwInfo = NULL;

    if(NULL == deviceName)
    {
        dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);
        return deviceNum;
    }

    devNum = BspGetDevNum();
    hwInfo = BspGetBoardPropInfo();
    if (NULL == hwInfo)
    {
        dbgErr("%s>>Get hwInfo Failed!\n", __FUNCTION__);
        return deviceNum;
    }

    for (loop = 0; loop < devNum; loop++)
    {
        deviceId = hwInfo->BoardInfo.pDeviceInfoDscp[loop].acDeviceId;
        if (0 == strncmp(deviceName, deviceId, charLength))
        {
            pathIndex = hwInfo->BoardInfo.pDeviceInfoDscp[loop].ulPathIndex;
            if((num < RRU_MAX_DEVICE_NODE_NUM) && (pathIndex < RRU_MAX_DEVICE_NUM))
            {
                record[num] = pathIndex;  /* 记录rruproperty.txt中有多节点的器件序号 */
                num++;
            }
        }
    }

    for(num = 0; num < RRU_MAX_DEVICE_NODE_NUM; num++)
    {
        deviceRecord[record[num]]++;  /* 遍历记录的器件序号元素 */
    }

    for(num = 0; num < RRU_MAX_DEVICE_NODE_NUM; num++)
    {
        if(deviceRecord[num] > 0)
        {
            deviceNum++;  /* 统计器件个数 */
        }
    }

    return deviceNum;

}

UINT32 BspRecordCaliCarrFreq(UINT32 chan, UINT32 type,UINT32 carrFreq)
{
    if(chan >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    if(0 == type)  /*预开开环时载波0的频点  固定*/
    {
         g_ulRecordCarrFreq[chan].openLoopFreq = carrFreq;
    }
    else          /*插损测量时移频校准时的频点 动态变化*/
    {
        g_ulRecordCarrFreq[chan].caliFreq = carrFreq;
    }
    dbgInfo("%s chan %d type %d freq %d\n", __FUNCTION__, chan, type, carrFreq);

    return BSP_OK;
}

UINT32 BspGetRecordCaliCarrFreq(UINT32 chan, UINT32 type, UINT32 *pCarrFreq)
{
    if(chan >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pCarrFreq);
    if(0 == type)  /*预开开环时载波0的频点  固定*/
    {
        *pCarrFreq = g_ulRecordCarrFreq[chan].openLoopFreq;
    }
    else
    {
        *pCarrFreq = g_ulRecordCarrFreq[chan].caliFreq;
    }
    dbgInfoEx("%s chan %d type %d freq %d\n", __FUNCTION__, chan, type, *pCarrFreq);

    return BSP_OK;
}

static UINT32 s_fanNum = 0;
static UINT32 s_currentSpeed[PWM_MAX_NUM] = {100,100,100,100};

UINT32 BspSetFanSpeedCallBackInit(FUNC_SET_FAN_SPEED  pFuncSetFanSpeed)
{
    pSetFanSpeed = pFuncSetFanSpeed;
    return BSP_OK;
}

UINT32 BspGetFanStatusCallBackInit(FUNC_GET_FAN_IS_OK  pFuncGetFanStatus)
{
    pGetFanIsOk = pFuncGetFanStatus;
    return BSP_OK;
}
void BspSetFanNum(UINT32 fanNum)
{
    s_fanNum = fanNum;
}
UINT32 BspGetFanNum(void)
{
    return s_fanNum;
}

UINT32 BspSetFanSpeed(UINT32 fanNo, UINT32 speed)
{
    UINT32 ret = BSP_OK;

    if(NULL != pSetFanSpeed)
    {
        ret = pSetFanSpeed(fanNo, speed);
    }

    return ret;
}

/*返回值：转速, 0:0%  20:20%  40:40%  80:80%*/
UINT32 BspGetFanSpeed(UINT32 fanNo)
{
    if(fanNo >= PWM_MAX_NUM)
    {
        dbgErr("Input over range\n");
        return BSP_ERROR;
    }

    return s_currentSpeed[fanNo];
}

UINT32 BspSaveFanSpeed(UINT32 fanNo, UINT32 speed)
{
    if(fanNo >= PWM_MAX_NUM)
    {
        dbgErr("Input over range\n");
        return BSP_ERROR;
    }

    s_currentSpeed[fanNo] = speed;

    return BSP_OK;
}


UINT32 BspIsFanOK(UINT32 fanNo)
{
    UINT32 ret = BSP_OK;

    if(NULL != pGetFanIsOk)
    {
        ret =  pGetFanIsOk(fanNo);
    }

    return ret;
}

UINT32 BspGetFanAlm(UINT32 fanNo, UINT32 *pStatus)
{
    return BSP_OK;
}

UINT32 BspSetRfBridgeSupportFlag(UINT32 flag)
{
    s_rfBridgeSupportFlag = flag;
    return BSP_OK;
}

UINT32 BspGetRfBridgeSupportFlag(VOID)
{
    return s_rfBridgeSupportFlag;
}

UINT32 BspSetTFCommonPowerFlag(UINT32 flag)
{
    s_commonPowerFlag = flag;
    return BSP_OK;
}

UINT32 BspGetTFCommonPowerFlag(VOID)   /*D42 t+f机型静态调压流程中高层会调用*/
{
    return s_commonPowerFlag;
}

/* Started by AICoder, pid:w061fpa506ya09d14c570a839040e14818818c28 */
UINT32 BspSetRfBridgeInfoMap(T_AllRfBridgeInfo *pRfBridgeMap)
{
    INPUT_POINTER_CHECK(pRfBridgeMap);
    s_rfBridgeInfo = pRfBridgeMap;

    return BSP_OK;
}

UINT32 BspGetRfBridgeInfoMap(T_AllRfBridgeInfo *pRfBridgeMap)
{
    INPUT_POINTER_CHECK(pRfBridgeMap);
    INPUT_POINTER_CHECK(s_rfBridgeInfo);
    memcpy_s(pRfBridgeMap, sizeof(T_AllRfBridgeInfo), s_rfBridgeInfo, sizeof(T_AllRfBridgeInfo));
    
    return BSP_OK;
}

static UINT32 dbgShowRfBridgeInfo(VOID)
{
    UINT32 loopIdx = 0;
    T_AllRfBridgeInfo pRfBridgeMap = {};
    
    BspGetRfBridgeInfoMap(&pRfBridgeMap);
    dbgInfo("rfBridgeNum: %d\n",pRfBridgeMap.rfBridgeNum);

    for(loopIdx = 0; loopIdx < pRfBridgeMap.rfBridgeNum; loopIdx++)
    {
        dbgInfo("rfBridgeIdx=%4d  rfBridgeInPort=%4d  rfBridgeOutPort=%4d  bridgePortIcIdx[0]=%4d  bridgePortChIdx[0]=%4d  bridgePortChIdx[1]=%4d\n",loopIdx,
            pRfBridgeMap.rfBridgeInfo[loopIdx].rfBridgeInPort,
            pRfBridgeMap.rfBridgeInfo[loopIdx].rfBridgeOutPort,
            pRfBridgeMap.rfBridgeInfo[loopIdx].bridgePortIcIdx[0],
            pRfBridgeMap.rfBridgeInfo[loopIdx].bridgePortChIdx[0],
            pRfBridgeMap.rfBridgeInfo[loopIdx].bridgePortChIdx[1]);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:w061fpa506ya09d14c570a839040e14818818c28 */
/* Started by AICoder, pid:0f6cb0ac952650614a5f0992105a340fa504a4a7 */
VOID dbgShowJ204LinkState(VOID)
{
    return ;
}
/* Ended by AICoder, pid:0f6cb0ac952650614a5f0992105a340fa504a4a7 */

/* Started by AICoder, pid:n23eaw7ce8p99e9143c508b800f0ec25dd52afae */
void BspSetRfBridgeVswrPreStartSta(UINT32 chan, UINT32 sta)
{
    if(chan >= MAX_TX_CHAN)
    {
        dbgErr("chan num is over\n");
        return ;
    }
    s_rfBridgeVswrPreStartSta[chan] = sta;
}

UINT32 BspGetRfBridgeVswrPreStartSta(UINT32 chan, UINT32 *pSta)
{
    INPUT_POINTER_CHECK(pSta);
    if(chan >= MAX_TX_CHAN)
    {
        dbgErr("chan num is over\n");
        return BSP_ERROR;
    }
    *pSta = s_rfBridgeVswrPreStartSta[chan];

    return BSP_OK;
}
/* Ended by AICoder, pid:n23eaw7ce8p99e9143c508b800f0ec25dd52afae */

/* Started by AICoder, pid:q764466d0fm416b14457094a00b2233e7a1227ef */
UINT32 BspSetThresholdBoardTempDelta(INT32 delta)
{
    s_BoardTempDelta = delta;
    return BSP_OK;
}

INT32 BspGetThresholdBoardTempDelta(VOID)
{
    return s_BoardTempDelta;
}

UINT32 BspSetThresholdPaTempDelta(INT32 delta)
{
    s_PaTempDelta = delta;
    return BSP_OK;
}

INT32 BspGetThresholdPaTempDelta(VOID)
{
    return s_PaTempDelta;
}

UINT32 BspSetThresholdPwrTempDelta(INT32 delta)
{
    s_PwrTempDelta = delta;
    return BSP_OK;
}

UINT32 BspSetUnitedArabEmiratesFlag(UINT32 flag)
{
    s_UnitedArabEmiratesReduceTempFlag = flag;
    return BSP_OK;
}

UINT32 BspGetUnitedArabEmiratesFlag(VOID)
{
    return s_UnitedArabEmiratesReduceTempFlag;
}

/* Started by AICoder, pid:c713csc263ufacf140030a03e08208239be9210c */
INT32 BspGetThresholdPwrTempDelta(VOID)
{
    return s_PwrTempDelta;
}
/* Ended by AICoder, pid:q764466d0fm416b14457094a00b2233e7a1227ef */

UINT32 BspGetDpdicOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold)
{
    return BSP_ERROR;
}

UINT32 BspGetMcsOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold)
{
    return BSP_ERROR;
}

UINT32 BspGetBoardOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold)
{
    return BSP_ERROR;
}

UINT32 BspGetSfpOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold)
{
    return BSP_ERROR;
}

UINT32 BspGetPwrOverTempThreshold(UINT32 tempType, UINT32 voltType, OverTempThreshold *pThreshold)
{
    return BSP_ERROR;
}

UINT32 BspGetPaOverTempThreshold(UINT32 type, OverTempThreshold *pThreshold)
{
    return BSP_ERROR;
}
/* Ended by AICoder, pid:c713csc263ufacf140030a03e08208239be9210c */

/* Started by AICoder, pid:b57cdha6f8ub22014a200ad9b020ab2ff586e353 */
UINT32 BspSetRfBridgeChanFlag(UINT32 difChn, UINT32 flag)
{
    if (difChn >= MAX_TX_CHAN)
    {
        dbgInfo("[%s] difChn[%u] out of range!\n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    s_rfBridgeChanFlag[difChn] = flag;

    return BSP_OK;
}

UINT32 BspGetRfBridgeChanFlag(UINT32 difChn, UINT32 *flag)
{
    INPUT_POINTER_CHECK(flag);
    if (difChn >= MAX_TX_CHAN)
    {
        dbgInfo("[%s] difChn[%u] out of range!\n", __FUNCTION__, difChn);
        return BSP_ERROR;
    }

    *flag = s_rfBridgeChanFlag[difChn];

    return BSP_OK;
}
/* Ended by AICoder, pid:b57cdha6f8ub22014a200ad9b020ab2ff586e353 */

UINT32 BspGetOverTempLevel(VOID)
{
    return INVALID_VALUE;
}

UINT8 BspGetOptSelfTestStatus(UINT8 ucOptId)
{
    return s_optSelfTest;
}

void BspSetOptSelfTestStatus(UINT8 sta)
{
    s_optSelfTest = sta;
    return ;
}

/* Started by AICoder, pid:v84c4ga73fj519314af20a6690254e0e87288661 */
UINT32 BspGetOptSelfLoopStatus(VOID)
{
    return (UINT32)s_optSelfTest;
}
/* Ended by AICoder, pid:v84c4ga73fj519314af20a6690254e0e87288661 */

UINT32 BspSetNtfPowFlag(UINT32 flag)
{
    s_ntfPowFlag = flag;
    return BSP_OK;
}

UINT32 BspGetNtfPowFlag(void)
{
    return s_ntfPowFlag;
}

UINT32 BspSetTssiFwdDiffThreshold(UINT32 threshold)
{
    s_tssiFwdDiffThreshold = threshold;
    return BSP_OK;
}

UINT32 BspGetTssiFwdDiffThreshold(void)
{
    return s_tssiFwdDiffThreshold;
}

UINT32 BspSetAdcStatusMask(UINT32 mask)
{
    s_adcMask = mask;
    return BSP_OK;
}

UINT32 BspGetAdcStatusMask(void)
{
    return s_adcMask;
}

/* Started by AICoder, pid:k91eb53394o9424143550aeeb0a48b155534bd3e */
void BspSetNtfSupportMulitToneVswrFlag(UINT32 flag)
{
    s_ntfSupportMulitToneVswr = flag;
}

UINT32 BspGetNtfSupportMulitToneVswrFlag(void)
{
    return s_ntfSupportMulitToneVswr;
}
/* Ended by AICoder, pid:k91eb53394o9424143550aeeb0a48b155534bd3e */

UINT32 BspGetMTSSwitchNtf(ntf_MTS_Switch pCallBackFunc)
{
    s_pMTS_SwitchNtf = pCallBackFunc;
    return BSP_OK;
}

ntf_MTS_Switch Ntf_MTSSwitch(void)
{
    return s_pMTS_SwitchNtf;
}

/* Started by AICoder, pid:y6a934fa225185d14a2708207042fe1c36058372 */
UINT32 BspSetNtfVswrStep(UINT32 step)
{
    s_ntfVswrStep = step;
    return BSP_OK;
}

UINT32 BspGetNtfVswrStep(void)
{
    return s_ntfVswrStep;
}
/* Ended by AICoder, pid:y6a934fa225185d14a2708207042fe1c36058372 */

/* Started by AICoder, pid:e62c6y99ddb258b141820a32605004269903be6b */
UINT32 BspSetNtfScalarVswrThre(UINT32 thre)
{
    s_ntfScalarVswrThre = thre;
    return BSP_OK;
}

UINT32 BspGetNtfScalarVswrThre(void)
{
    return s_ntfScalarVswrThre;
}
/* Ended by AICoder, pid:e62c6y99ddb258b141820a32605004269903be6b */

/* Started by AICoder, pid:z4f48m8733s154e1481f0a2a103ee836a13427a2 */
UINT32 BspGetSlaverVerStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 dspSta = 0;
    UINT32 verStatus = 0;

    if(SUPPORT != g_getSlaverVerLoadType)
    {
        return g_slaverVerLoadSta;
    }
    retVal = BspGetDpdStatus(0, &dspSta);
    if(BSP_OK != retVal)
    {
        verStatus |= BIT_SET(VER_LOAD_STA_DSP);
    }

    g_slaverVerLoadSta = verStatus;
    g_getSlaverVerLoadType = NO_SUPPORT;
    return verStatus;
}
/* Ended by AICoder, pid:z4f48m8733s154e1481f0a2a103ee836a13427a2 */

/* Started by AICoder, pid:e38d1xd6d6u6baa146000b3e8088ac620e8352e9 */
UINT32 BspGetNot10MsFrCnt(VOID)
{
    UINT32 not10MsFrCnt = 0;
    UINT32 frId = 13;  //空口帧头

    BspHalAdaptGetNot10MsFrCnt(frId, &not10MsFrCnt);
    BspLog(LOG_LEVEL_0,"[%s]==not10MsFrCnt %d\n", __FUNCTION__, not10MsFrCnt);

    return not10MsFrCnt;
}

UINT32 BspSetNcrTaVal(UINT32 ulVal)
{
    BspLog(LOG_LEVEL_0,"[%s]==ulVal %d\n", __FUNCTION__, ulVal);

    return IcHalApiSetNcrTaVal(ulVal);
}

UINT32 BspSetPsyncIrqAptuneCfg(UINT32 enable)
{
    UINT32 sw = (0 == enable) ? 0 : 1;

    BspLog(LOG_LEVEL_0,"[%s]==enable %d\n", __FUNCTION__, enable);
    return IcHalApiNcrPsyncIrqAptuneCfg(sw);
}

UINT32 g_deltaTp1Threshold = 122;  //单位：Ts
UINT32 BspGetDeltaTp1Threshold(UINT32* deltaTp1Threshold)
{
    INPUT_POINTER_CHECK(deltaTp1Threshold);

    *deltaTp1Threshold = g_deltaTp1Threshold;

    return BSP_OK;
}

UINT32 BspSetDeltaTp1Threshold(UINT32 deltaTp1Threshold)
{
    if(deltaTp1Threshold > 200)
    {
        dbgErr("[%s]delta tp1 threshold %d is invaild, should be [0, 200]\n", __FUNCTION__, deltaTp1Threshold);
        return BSP_ERROR;
    }

    g_deltaTp1Threshold = deltaTp1Threshold;
    return BSP_OK;
}
/* Ended by AICoder, pid:e38d1xd6d6u6baa146000b3e8088ac620e8352e9 */

/* Started by AICoder, pid:g87f7h4d2epbef01432b09359003772e42b55978 */
UINT32 BspGetIsSupportAac(VOID)
{
    return s_setIsSupportAac;
}

UINT32 BspSetIsSupportAac(UINT32 flag)
{
    s_setIsSupportAac = flag;
    return BSP_OK;
}
/* Ended by AICoder, pid:g87f7h4d2epbef01432b09359003772e42b55978 */

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : funccommon_pm.c
* 文件标识 : {[N/A]}
* 内容摘要 : PM打印控制
* 注意事项 : 无
* 作    者 :   190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"
#include "funccommon_carrmap.h"
#include "regdrv_accesstbl.h"
#include "regdrv_access.h"
#include "funccommon.h"

/**************************************************************************
 *                        宏
 **************************************************************************/




/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
/* 模块管理结构体 */
typedef struct tagT_DifCarrMapInfo
{
    UINT32 carrNo[3];
	UINT32 carrMode[3];
	UINT32 difCarrNo[3];
	UINT32 usedFlagDif;
	UINT32 usedFlagIq;
}T_DifCarrMapInfo;

typedef struct tagT_DifCarrResource
{
    UINT32            carrResourceNum;
	UINT32            chnNum;
	T_DifCarrMapInfo  carrMapInfo[0];
}T_DifCarrResource;

static UINT32               s_ModeMapInfo[DIF_RADIOMODE_MAX] = {
	
	BSP_RADIO_STANDARD_UMTS,
	BSP_RADIO_STANDARD_GSM,
	BSP_RADIO_STANDARD_TD_SCDMA,
	BSP_RADIO_STANDARD_CDMA,
	BSP_RADIO_STANDARD_LTE_FDD,
	BSP_RADIO_STANDARD_LTE_TDD,
	BSP_RADIO_STANDARD_NB_IOT,
	BSP_RADIO_STANDARD_5G,
	BSP_RADIO_STANDARD_5G_IF0,
	BSP_RADIO_STANDARD_5G_IF1,

};

static T_RADIO_MAP s_RadioMap[RADIO_MAP_TYPE_NUM] = 
{
    {RADIO_MAP_UMTS,    BSP_RADIO_STANDARD_UMTS},
    {RADIO_MAP_GSM,     BSP_RADIO_STANDARD_GSM},
    {RADIO_MAP_LTE_FDD, BSP_RADIO_STANDARD_LTE_FDD},
    {RADIO_MAP__LTE_TDD,BSP_RADIO_STANDARD_LTE_TDD},
    {RADIO_MAP__NB_IOT, BSP_RADIO_STANDARD_NB_IOT},
    {RADIO_MAP__5G_TDD, BSP_RADIO_STANDARD_5G},
    {RADIO_MAP__5G_FDD, BSP_RADIO_STANDARD_FDD_5G},
};

#if 0
typedef enum _RADIOMODE_INDEX
{
    DIF_RADIOMODE_UMTS = 0,
    DIF_RADIOMODE_GSM,
    DIF_RADIOMODE_TDS,
    DIF_RADIOMODE_CDMA,
    DIF_RADIOMODE_LTE_FDD,
    DIF_RADIOMODE_NBIOT,
    DIF_RADIOMODE_MAX,
}RADIOMODE_INDEX;
#endif

//#define BSP_CARR_MAP_SUPPORT_MODE      (BSP_RADIO_STANDARD_GSM|BSP_RADIO_STANDARD_NB_IOT)
static UINT32 s_CarrMapSupportMode1 = 0;
static UINT32 s_CarrMapSupportMode2 = 0;
#define BSP_CARR_MAP_SUPPORT_MODE      (BSP_RADIO_STANDARD_GSM|BSP_RADIO_STANDARD_NB_IOT|s_CarrMapSupportMode2)

#define BSP_CARR_MAP_SUPPORT_MODE1     (s_CarrMapSupportMode1)/*(BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_5G)*/
#define BSP_CARR_MAP_SUPPORT_SWITCH   (1)
#define CARR_MAP_IDX_NOW     0 /* 存放IQ载波信息的index */
#define CARR_MAP_IDX_LAST    1 /* 存放中频载波信息的index */
#define BSP_BIT_MAP_ANT_MODE       (BSP_RADIO_STANDARD_5G|BSP_RADIO_STANDARD_LTE_FDD)

#define BSP_CARR_MAP_NO_USE          0
#define BSP_CARR_MAP_USED            1
#define BSP_CARR_MAP_USEING          2

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/

static T_DifCarrResource *s_CarrInfoTbl[2][DIF_RADIOMODE_MAX];
static T_CarrFrqMapInfo *s_CarrFrqMap = NULL;
static UINT32         s_CarrFrqMapNum  = 0;
T_CarrMapInfo *s_CarrMap = NULL; 
static UINT32         s_CarrMapNum  = 0;
static pGetCarrNoDymMallocFlag s_pGetCarrNoDymMallocFlag = NULL;
static pGetLteNrDifId NrgetDifId = NULL;
static UINT8 s_TsgMode = 0;
static UINT8 s_SupportTsgMode = 0;
static UINT32  s_CarrMapDelFucSupportFlag = 0;
static UINT32 s_IsSupportIf1NR = 0;

/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
 *                         局部函数声明
 **************************************************************************/

/**************************************************************************
 *                         全局函数声明
 **************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/
UINT32 BspSetCarrMapMode(UINT32 ulMode)
{
	s_CarrMapSupportMode1 = ulMode;
	return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 BspIsSupportCarrRoute(UINT32 uMode)
{
	if(uMode&BSP_CARR_MAP_SUPPORT_MODE1)
	{
		return BSP_OK;
	}
	return BSP_ERROR;
}

#endif

UINT32 BspGetCarrNoDymMallocFlag(UINT32 dir,UINT32 rmode,UINT32 carrno)
{
    if(NULL == s_pGetCarrNoDymMallocFlag)
    {
        return BSP_ERROR;
    }
    else 
    {
        return s_pGetCarrNoDymMallocFlag(dir,rmode,carrno);
    }
}

UINT32 BspSetCarrNoDymMallocFncPtr(pGetCarrNoDymMallocFlag fnc)
{
    s_pGetCarrNoDymMallocFlag = fnc;

    return BSP_OK;
}

VOID BspSetCarrMapDelFucSupportFlag(UINT32 flg)
{
     s_CarrMapDelFucSupportFlag = flg;
     return;
}

UINT32  BspGetCarrMapDelFucSupportFlag(VOID)
{
    return s_CarrMapDelFucSupportFlag;
}

UINT32 BspGetLteNrDifId(pGetLteNrDifId ptfuc)
{
    NrgetDifId = ptfuc;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspInitCarrMap(*)
 * 功能描述: 载波映射模块初始化
 * 输入参数: radioMode       - 需要共享资源的所有制式值
             ResourceNum     - 共享的资源数目
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/
UINT32 BspInitCarrMap(UINT32 dir, UINT32 radioMode, UINT32 ResourceNum)
{
    T_DifCarrResource *pTmp  = NULL;
	UINT32             flag  = 0;
	UINT32             memsz = 0;
	UINT32             chnNum= 0;
	if((dir!=TX)&&(dir!=RX))
	{
        return BSP_ERROR;
	}
	if(0 == ResourceNum)
	{
        return BSP_OK;
	}
	chnNum = BspGetBspChanNum(TX);
    /* GN共资源 */
    if((radioMode&BSP_RADIO_STANDARD_GSM)||(radioMode&BSP_RADIO_STANDARD_NB_IOT))
    {
        if((NULL == s_CarrInfoTbl[dir][DIF_RADIOMODE_GSM])&&(NULL == s_CarrInfoTbl[dir][DIF_RADIOMODE_NBIOT]))
        {
        	memsz  = sizeof(T_DifCarrResource)+chnNum*ResourceNum*sizeof(T_DifCarrMapInfo);
        	pTmp = (T_DifCarrResource*)malloc(memsz);
        	if(NULL == pTmp)
        	{
                return BSP_ERROR;
        	}
        	memset(pTmp,0,memsz);
        	pTmp->carrResourceNum = ResourceNum;
        	pTmp->chnNum          = chnNum;
        	s_CarrInfoTbl[dir][DIF_RADIOMODE_GSM]   = pTmp;
        	s_CarrInfoTbl[dir][DIF_RADIOMODE_NBIOT] = pTmp;
		}
		flag = 1;
	}
    /* LTE/NR共资源 */
	if((radioMode&BSP_RADIO_STANDARD_LTE_FDD)||(radioMode&BSP_RADIO_STANDARD_5G))
	{
		if((NULL == s_CarrInfoTbl[dir][DIF_RADIOMODE_LTE_FDD])&&(NULL == s_CarrInfoTbl[dir][DIF_RADIOMODE_NR]))
                {
			memsz  = sizeof(T_DifCarrResource)+chnNum*ResourceNum*sizeof(T_DifCarrMapInfo);
			pTmp = (T_DifCarrResource*)malloc(memsz);
			if(NULL == pTmp)
			{
				return BSP_ERROR;
			}
			memset(pTmp,0,memsz);
			pTmp->carrResourceNum = ResourceNum;
			pTmp->chnNum          = chnNum;
			s_CarrInfoTbl[dir][DIF_RADIOMODE_LTE_FDD]   = pTmp;
        	s_CarrInfoTbl[dir][DIF_RADIOMODE_NR] = pTmp;

		}
		flag = 1;
	}
    
	if(radioMode&BSP_RADIO_STANDARD_UMTS)
	{
		if(NULL == s_CarrInfoTbl[dir][DIF_RADIOMODE_UMTS])
                {
			memsz  = sizeof(T_DifCarrResource)+chnNum*ResourceNum*sizeof(T_DifCarrMapInfo);
			pTmp = (T_DifCarrResource*)malloc(memsz);
			if(NULL == pTmp)
			{
				return BSP_ERROR;
			}
			memset(pTmp,0,memsz);
			pTmp->carrResourceNum = ResourceNum;
			pTmp->chnNum          = chnNum;
			s_CarrInfoTbl[dir][DIF_RADIOMODE_UMTS] = pTmp;
		}
		flag = 1;
	}

	if(radioMode&BSP_RADIO_STANDARD_5G_IF0)
	{
		if(NULL == s_CarrInfoTbl[dir][DIF_RADIOMODE_NR_IF0])
		{
			/*抑制告警***/
            //coverity[cert_int30_c_violation:SUPPRESS]
			memsz  = sizeof(T_DifCarrResource)+chnNum*ResourceNum*sizeof(T_DifCarrMapInfo);
			pTmp = (T_DifCarrResource*)malloc(memsz);
			if(NULL == pTmp)
			{
				return BSP_ERROR;
			}
			memset(pTmp,0,memsz);
			pTmp->carrResourceNum = ResourceNum;
			pTmp->chnNum          = chnNum;
			s_CarrInfoTbl[dir][DIF_RADIOMODE_NR_IF0] = pTmp;
		}
		flag = 1;
	}
        if(radioMode&BSP_RADIO_STANDARD_5G_IF1)
	{
		if(NULL == s_CarrInfoTbl[dir][DIF_RADIOMODE_NR_IF1])
		{
		     /*抑制告警***/
            //coverity[cert_int30_c_violation:SUPPRESS]
			memsz  = sizeof(T_DifCarrResource)+chnNum*ResourceNum*sizeof(T_DifCarrMapInfo);
			pTmp = (T_DifCarrResource*)malloc(memsz);
			if(NULL == pTmp)
			{
				return BSP_ERROR;
			}
			memset(pTmp,0,memsz);
			pTmp->carrResourceNum = ResourceNum;
			pTmp->chnNum          = chnNum;
			s_CarrInfoTbl[dir][DIF_RADIOMODE_NR_IF1] = pTmp;
		}
		flag = 1;
	}

    dbgInfoEx("%s: flag: %d\n", __FUNCTION__, flag);
	return BSP_OK;
}

UINT32 BspSetCarrMapSupportInfo(UINT32 radioMode, UINT32 flag)
{
	if(1 == flag)
	{
		s_CarrMapSupportMode1 |= radioMode;
	}
	return BSP_OK;
}

UINT32 BspSetCarrMapSupportInfoEx(UINT32 radioMode, UINT32 flag)
{
	if(1 == flag)
	{
		s_CarrMapSupportMode2 |= radioMode;
	}
    
	return BSP_OK;
}

UINT32 BspGetChnNumByIqInfo(T_RuMmIqCfgItem *pIqItem)
{
	UINT32 uAntId = 0;
    UCHAR   ucRruAntNo = 0;
    
	if(NULL == pIqItem)
	{
		return BSP_ERROR;
	}
    ucRruAntNo = pIqItem->ucRruAntNo;
    
    if(BSP_BIT_MAP_ANT_MODE&pIqItem->ucRadioMode)
    {
    	uAntId = 0;
        while(ucRruAntNo)
        {
        	if(ucRruAntNo&1)
        	{
        		break;
        	}
        	uAntId++;
        	ucRruAntNo >>= 1;
        }
    }
    else
    {
    	uAntId = pIqItem->ucRruAntNo;
    }
    return uAntId;
}

UINT32 BspGetAntNumByIqInfo(T_RuMmIqCfgItem *pIqItem,UINT32 *antinfo,UINT32 *bandval)
{
	UINT32 uAntId = 0;
    UCHAR   ucRruAntNo = 0;

	if(NULL == pIqItem)
	{
		return BSP_ERROR;
	}
    ucRruAntNo = pIqItem->ucRruAntNo;
    
    if(BSP_BIT_MAP_ANT_MODE&pIqItem->ucRadioMode)
    {
    	uAntId = 0;
        while(ucRruAntNo)
        {
        	if(ucRruAntNo&1)
        	{
        		(*bandval)++;
                *antinfo++ = uAntId;
        	}
        	uAntId++;
        	ucRruAntNo >>= 1;
        }
    }

    return BSP_OK;
}

UINT32  BspGetDoubleAntBdIdx(T_RuMmIqCfgItem *pIqItem,UCHAR uDir,UINT32 *ubdMapIdx)
{
    UINT32 antbdcnt = 0;
    UINT32 antbdno[8] = {0xff};    
    UINT32 ulantidx = 0;    
    /* UINT32 ulantbdflg = 0; */
	UINT32 uDifMode = 0;
	UINT32 uRet     = BSP_OK;

	uRet = BspGetDifModeByRadioMode(pIqItem->ucRadioMode, &uDifMode);
    BspGetAntNumByIqInfo(pIqItem,antbdno,&antbdcnt);
    
    if(((UINT32)2 != antbdcnt) || (BSP_OK != uRet))
    {
        return BSP_ERROR;
    }
    
    for(ulantidx = 0;ulantidx<antbdcnt;ulantidx++)
    {
        if((antbdno[ulantidx] != 0xff) && (antbdno[ulantidx] != BspGetChnNumByIqInfo(pIqItem)))
        {
            *ubdMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*(antbdno[ulantidx]%BspGetBspChanNum(TX));
            BspLog(LOG_LEVEL_0,"Mapidex in Double Ant Band case is %d\n",*ubdMapIdx);
            dbgInfoEx("Mapidex in Double Ant Band case is %d\n",*ubdMapIdx);
            return BSP_OK;
        }
    }    

    return BSP_ERROR;

}

UINT32 BspFreeCarrMap(T_RuMmIqCfgItem *pIqItem)
{
	UINT32 uRet     = BSP_OK;
	UINT32 uDifMode = 0;
	UINT32 uIdx     = 0;
	UINT32 uDir     = 0;
	UINT32 uMapIdx  = 0;
    UINT32 ubdMapIdx = 0;
    
	if(NULL == pIqItem)
	{
		return BSP_ERROR;
	}
	uDir = pIqItem->ucFwOrRev;
	if(uDir > 1)
	{
		return BSP_ERROR;
	}
	uRet = BspGetDifModeByRadioMode(pIqItem->ucRadioMode, &uDifMode);
	if(BSP_OK == uRet)
	{
        if(NULL == s_CarrInfoTbl[uDir][uDifMode])
        {
        	return BSP_OK;
        }
        uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*(BspGetChnNumByIqInfo(pIqItem)%BspGetBspChanNum(TX));
        for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
        {
        	if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq==BSP_CARR_MAP_NO_USE)
        	{
        		continue;
        	}
            if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW]!=pIqItem->ucRadioMode)
            {
            	continue;
            }
            if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW]!=pIqItem->ucRruCarrierNo)
			{
				continue;
			}
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_NO_USE;
            //s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagDif = BSP_CARR_MAP_NO_USE;
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] = 0;
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] = 0;
            //s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_LAST] = 0;
            //s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_LAST]   = 0;

            if(BSP_OK == BspGetDoubleAntBdIdx(pIqItem,pIqItem->ucFwOrRev,&ubdMapIdx))
            {            
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_NO_USE;
                //s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagDif = BSP_CARR_MAP_NO_USE;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] = 0;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] = 0;
                //s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_LAST] = 0;
                //s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_LAST]   = 0;
            }

            break;
        }
	}
    return uRet;
}


UINT32 BspClrCarrMap(UINT32 uDifMode)
{
	UINT32 uRet        = BSP_OK;
	UINT32 uMode       = 0;
	UINT32 uIdx        = 0;
	UINT32 uDir        = 0;
	UINT32 uSourceNum  = 0;

	uRet = BspGetRadioModeByDifMode(uDifMode, &uMode);
	if(BSP_OK == uRet)
	{
		if(0==(BSP_CARR_MAP_SUPPORT_MODE&uMode))
		{
        	return BSP_OK;
		}
        if(NULL == s_CarrInfoTbl[uDir][uDifMode])
        {
        	return BSP_OK;
        }
        uDir    = TX;
        uSourceNum = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*s_CarrInfoTbl[uDir][uDifMode]->chnNum;

        for(uDir = RX; uDir <=TX; uDir ++)
        {
            for(uIdx = 0; uIdx < uSourceNum; uIdx ++)
            {
            	if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uIdx].usedFlagIq==BSP_CARR_MAP_NO_USE)
            	{
            		s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uIdx].carrMode[CARR_MAP_IDX_NOW] = 0;
                    if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uIdx].usedFlagDif==BSP_CARR_MAP_NO_USE)
                    {
                        s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uIdx].carrNo[CARR_MAP_IDX_NOW] = 0;
                        s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uIdx].carrMode[CARR_MAP_IDX_LAST] = 0;
                        s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uIdx].carrNo[CARR_MAP_IDX_LAST]   = 0;

                    }
            	}
            }
        }


	}
    return uRet;
}

UINT32 BspCmpTxRxCarrNoDymMallocFlag(T_RuMmIqCfgItem *pIqItem)
{
    UINT32  uIdx = 0 ;
    UINT32  uMapIdx  = 0;
    UINT32  uRet = BSP_ERROR;
    UINT32  uDifMode= 0;
    UINT32  uDir = (pIqItem->ucFwOrRev ==TX)?RX:TX;
    
    if(pIqItem->ucRadioMode & (BSP_RADIO_STANDARD_GSM|BSP_RADIO_STANDARD_NB_IOT))
    {
        if(BSP_ERROR == BspGetDifModeByRadioMode(pIqItem->ucRadioMode, &uDifMode))
        {
            return uRet;
        }
        
        uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*(BspGetChnNumByIqInfo(pIqItem)%BspGetBspChanNum(TX));
        
        for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
        {
            if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW]!=pIqItem->ucRadioMode)
            {
                continue;
            }
            if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW]!=pIqItem->ucRruCarrierNo)
            {
                continue;
            }
            return uIdx;
        }
    }
    
    return uRet;
}

UINT32 BspMallocCarrMap(T_RuMmIqCfgItem *pIqItem)
{
	UINT32 uRet     = BSP_OK;
	UINT32 uDifMode = 0;
	UINT32 uIdx     = 0;
	UINT32 uDir     = 0;
	UINT32 uReverDir= 0; /* 反方向 */
	UINT32 uMapIdx  = 0;
    UINT32 uIdxcvt = 0;    
	UINT32 ubdMapIdx  = 0;
    
	if(NULL == pIqItem)
	{
		return BSP_ERROR;
	}
	uDir = pIqItem->ucFwOrRev;
	uReverDir = (pIqItem->ucFwOrRev ==TX)?RX:TX;
	if(uDir > 1)
	{
		return BSP_ERROR;
	}
    
    BspLog(LOG_LEVEL_0,"IQcarrmap:mode[%d]ZIP[0x%x]TR[%d]carrno[%d]antno[%d]flag[%d]\n",pIqItem->ucRadioMode,pIqItem->ucZipFlag,\
                pIqItem->ucFwOrRev,pIqItem->ucRruCarrierNo,pIqItem->ucRruAntNo,pIqItem->ucAddDelFlag);
    
	uRet = BspGetDifModeByRadioMode(pIqItem->ucRadioMode, &uDifMode);
	if(BSP_OK == uRet)
	{
        if(NULL == s_CarrInfoTbl[uDir][uDifMode])
        {
        	return BSP_OK;
        }
        uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*(BspGetChnNumByIqInfo(pIqItem)%BspGetBspChanNum(TX));

        #if 0
		/* BSP_OK 是固定分配*/
        if(BSP_OK == BspGetCarrNoDymMallocFlag(uDir,pIqItem->ucRadioMode,pIqItem->ucRruCarrierNo))
		{
            uIdx = pIqItem->ucRruCarrierNo;
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            if(BSP_OK == BspGetDoubleAntBdIdx(pIqItem,pIqItem->ucFwOrRev,&ubdMapIdx))
            {
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            }

            
            BspLog(LOG_LEVEL_0,"IQcarrmap:NoDymMalloc\n");
	        return BSP_OK;
		}
        #endif
        //对于GN制式 如果发射映射了则以发射为准，不重新映射接收，反之同理
        uIdxcvt = BspCmpTxRxCarrNoDymMallocFlag(pIqItem);
        if( BSP_ERROR != uIdxcvt )
        {
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdxcvt].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdxcvt].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdxcvt].usedFlagIq = BSP_CARR_MAP_USED;
            
            if(BSP_OK == BspGetDoubleAntBdIdx(pIqItem,pIqItem->ucFwOrRev,&ubdMapIdx))
            {
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            }
            
            BspLog(LOG_LEVEL_0,"IQcarrmap:TxRxCarrNoDymMalloc\n");
        }
            
    
        /* 未找到,需要从IQ已使用的位置查找是否有匹配的 */
		for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
		{
			/* IQ未分配的地方暂不查找 */
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq==BSP_CARR_MAP_NO_USE)
			{
				continue;
			}
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW]!=pIqItem->ucRadioMode)
			{
				continue;
			}
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW]!=pIqItem->ucRruCarrierNo)
			{
				continue;
			}
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            
            if(BSP_OK == BspGetDoubleAntBdIdx(pIqItem,pIqItem->ucFwOrRev,&ubdMapIdx))
            {
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            }
            BspLog(LOG_LEVEL_0,"IQcarrmap1:未找到,需要从IQ已使用的位置查找是否有匹配的\n");
			return uRet;
		}
        /*  */
        for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
        {
        	/* 中频未分配的地方暂不查找 */
        	if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagDif==BSP_CARR_MAP_NO_USE)
        	{
        		continue;
        	}
        	/* IQ使用的地方暂不查找 */
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq!=BSP_CARR_MAP_NO_USE)
			{
				continue;
			}
            if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_LAST]!=pIqItem->ucRadioMode)
            {
            	continue;
            }
            if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_LAST]!=pIqItem->ucRruCarrierNo)
			{
				continue;
			}
            s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
            
            if(BSP_OK == BspGetDoubleAntBdIdx(pIqItem,pIqItem->ucFwOrRev,&ubdMapIdx))
            {
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            }
            
            BspLog(LOG_LEVEL_0,"IQcarrmap2:IQ使用的地方暂不查找\n");
            return uRet;
        }

        /* 还未找到,需要从IQ和Dif都未使用的位置分配一个 */
        for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
		{
			/* IQ已分配的地方暂不查找 */
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq!=BSP_CARR_MAP_NO_USE)
			{
				continue;
			}
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagDif!=BSP_CARR_MAP_NO_USE)
			{
				continue;
			}
			if (pIqItem->ucRadioMode & (BSP_RADIO_STANDARD_GSM|BSP_RADIO_STANDARD_NB_IOT))
            {
                if(s_CarrInfoTbl[uReverDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq!=BSP_CARR_MAP_NO_USE)
                {
                    continue;
                }

                if(s_CarrInfoTbl[uReverDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagDif!=BSP_CARR_MAP_NO_USE)
                {
                    continue;
                }
            }
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            
            if(BSP_OK == BspGetDoubleAntBdIdx(pIqItem,pIqItem->ucFwOrRev,&ubdMapIdx))
            {
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            }

            
            BspLog(LOG_LEVEL_0,"IQcarrmap3:还未找到,需要从IQ和Dif都未使用的位置分配一个\n");
			return uRet;
		}
        /* 还未找到,需要从IQ未使用,但是大包中有使用的位置分配一个 */
        for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
		{
			/* IQ已分配的地方暂不查找 */
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq!=BSP_CARR_MAP_NO_USE)
			{
				continue;
			}
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED ;
			s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagDif = 0;
            
            if(BSP_OK == BspGetDoubleAntBdIdx(pIqItem,pIqItem->ucFwOrRev,&ubdMapIdx))
            {
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW] =pIqItem->ucRadioMode;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW] =pIqItem->ucRruCarrierNo;
                s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[ubdMapIdx+uIdx].usedFlagIq = BSP_CARR_MAP_USED;
            }
            
            BspLog(LOG_LEVEL_0,"IQcarrmap4:还未找到,需要从IQ未使用,但是大包中有使用的位置分配一个\n");
			return uRet;
		}
	}
	showcarrmap(4);
    return BSP_ERROR;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 BspAllocateCarrMapByIqCfg_1(T_RuMmIqCfg *ptRruIqCfg)
{
	UINT32 uIdx = 0;
	UINT32 uRet = BSP_OK;
    if(NULL == ptRruIqCfg)
    {
        return BSP_ERROR;
    }
    for(uIdx = 0; uIdx < ptRruIqCfg->ulNum; uIdx ++)
    {
    	if(E_DEL_FLAG != ptRruIqCfg->atIqItem[uIdx].ucAddDelFlag)
    	{
    		continue;
    	}
    	if(0 == (ptRruIqCfg->atIqItem[uIdx].ucRadioMode&BSP_CARR_MAP_SUPPORT_MODE))
		{
			continue;
		}
    	uRet |= BspFreeCarrMap(&(ptRruIqCfg->atIqItem[uIdx]));
    }
    for(uIdx = 0; uIdx < ptRruIqCfg->ulNum; uIdx ++)
	{
		if(E_ADD_FLAG != ptRruIqCfg->atIqItem[uIdx].ucAddDelFlag)
		{
			continue;
		}
		if(0 == (ptRruIqCfg->atIqItem[uIdx].ucRadioMode&BSP_CARR_MAP_SUPPORT_MODE))
		{
			continue;
		}
		uRet |= BspMallocCarrMap(&(ptRruIqCfg->atIqItem[uIdx]));
	}
    return BSP_OK;
}

UINT32 BspAllocateCarrMapByIqCfg_ADFlag(T_RuMmIqCfg *ptRruIqCfg, UINT32 uADflag)
{
	UINT32 uIdx = 0;
	UINT32 uRet = BSP_OK;
    if(NULL == ptRruIqCfg)
    {
        return BSP_ERROR;
    }
    if(E_DEL_FLAG == uADflag)
    {
    	for(uIdx = DIF_RADIOMODE_UMTS; uIdx < DIF_RADIOMODE_MAX; uIdx ++)
		{
			uRet |= BspClrCarrMap(uIdx);
		}
        for(uIdx = 0; uIdx < ptRruIqCfg->ulNum; uIdx ++)
        {
        	if(E_DEL_FLAG != ptRruIqCfg->atIqItem[uIdx].ucAddDelFlag)
        	{
        		continue;
        	}
        	if(0 == (ptRruIqCfg->atIqItem[uIdx].ucRadioMode&BSP_CARR_MAP_SUPPORT_MODE))
    		{
    			continue;
    		}
        	uRet |= BspFreeCarrMap(&(ptRruIqCfg->atIqItem[uIdx]));
        }
    }
    else
    {
        for(uIdx = 0; uIdx < ptRruIqCfg->ulNum; uIdx ++)
    	{
    		if(E_ADD_FLAG != ptRruIqCfg->atIqItem[uIdx].ucAddDelFlag)
    		{
    			continue;
    		}
    		if(0 == (ptRruIqCfg->atIqItem[uIdx].ucRadioMode&BSP_CARR_MAP_SUPPORT_MODE))
    		{
    			continue;
    		}
    		uRet |= BspMallocCarrMap(&(ptRruIqCfg->atIqItem[uIdx]));
    	}
    }

    return BSP_OK;
}

#endif

void BspSetIf1NRCarrMapFlag(UINT32 ulSupport)
{
	s_IsSupportIf1NR = ulSupport;
}

UINT32 BspGetCarrMapFlag(void)
{
	return s_IsSupportIf1NR;
}

UINT32 BspAllocateCarrMapByRfCfg(UINT32 uBspChn, UINT32 uDir, T_RfCfgPara *pRfCfgPara)
{
	UINT32 uIdx     = 0;
	/* UINT32 uRet     = BSP_OK; */
	UINT32 uDifMode = 0;
	UINT32 uSrcChn  = 0;
	UINT32 uMapIdx  = 0;
	UINT32 uSrcIdx  = 0;
	UINT32 *pMapFlag= NULL;
	UINT32 uMode    = 0;
	T_DifCarrMapInfo *pInfo = NULL;
    UINT32 uCarrMap = 0;
    
    if(NULL == pRfCfgPara)
    {
        return BSP_ERROR;
    }
    pMapFlag = (UINT32*)malloc(pRfCfgPara->carrNum*sizeof(UINT32));
    if(NULL == pMapFlag)
    {
    	return BSP_ERROR;
    }
    memset(pMapFlag, 0, pRfCfgPara->carrNum*sizeof(UINT32));
    
    if(0 == BspGetCarrMapDelFucSupportFlag())
    {
        if(uBspChn>=BspGetBspChanNum(TX))
        {
            free(pMapFlag);
       	    return BSP_OK;
        }
        else
        {
            uSrcChn = uBspChn;
        }
    }
    else
    {
        if(uBspChn>=BspGetBspChanNum(TX))
        {
            uSrcChn = uBspChn%BspGetBspChanNum(TX);
        }        
        else
        {
            uSrcChn = uBspChn;
        }
    }
    
    
    for(uIdx = 0; uIdx < pRfCfgPara->carrNum; uIdx ++)
    {
        BspLog(LOG_LEVEL_0,"APP Cfg dif[%d] dir %d carrmap_case1[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uDir,uIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                    pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                    pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);

        if((UINT32)0 != pMapFlag[uIdx])
    	{
    		continue;
    	}
    	uMode = pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK;
    	if(0 == (uMode&(BSP_CARR_MAP_SUPPORT_MODE|BSP_CARR_MAP_SUPPORT_MODE1)))
		{
			continue;
		}
    	if(BSP_OK != BspGetDifModeByRadioMode(uMode, &uDifMode))
    	{
            continue;
    	}
    	if(NULL == s_CarrInfoTbl[uDir][uDifMode])
    	{
    		continue;
    	}

    	if((UINT32)0xffffffff ==  pRfCfgPara->carrInfo[uIdx].freq)
    	{
    		continue;
    	}
        
        uCarrMap = BspGetDifCarrMapPos(uDir,pRfCfgPara->carrInfo[uIdx].freq,pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK);
        uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*uSrcChn;
        pInfo   = &(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx]);
        for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uSrcIdx ++)
        {
            if(BSP_CARR_MAP_NO_USE == pInfo[uSrcIdx].usedFlagIq)
            {
            	continue;
            }
            if(pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_NOW]!=uMode)
            {
                continue;
            }
            if(pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_NOW]!=pRfCfgPara->carrInfo[uIdx].carrNo)
			{
				continue;
			}
            /* 如果之前使用过，则保持该位置 */
            
            if(ERROR_NULL_POINTER != uCarrMap)
            {
                if (uMode == BSP_RADIO_STANDARD_UMTS)
                {
                    if((BIT_SET(uSrcIdx)&uCarrMap) &&(uSrcIdx == pRfCfgPara->carrInfo[uIdx].carrNo))
                    {
                        pInfo[uSrcIdx].usedFlagDif                 = BSP_CARR_MAP_USEING;
                        pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
                        pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
                        pMapFlag[uIdx]                             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    if((BIT_SET(uSrcIdx)&uCarrMap) &&(pInfo[uSrcIdx].usedFlagDif != BSP_CARR_MAP_USEING))
                    {
                        pInfo[uSrcIdx].usedFlagDif = BSP_CARR_MAP_USEING;
                        pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
                        pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
                        pMapFlag[uIdx]             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            else
            {
                pInfo[uSrcIdx].usedFlagDif = BSP_CARR_MAP_USEING;
                pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
                pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
                pMapFlag[uIdx]             = 1;
            }
			break;
        }
        
    BspLog(LOG_LEVEL_0,"dif[%d]carrmap_case1[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uSrcIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);
    }
    
    for(uIdx = 0; uIdx < pRfCfgPara->carrNum; uIdx ++)
	{
	
    	if((UINT32)0 != pMapFlag[uIdx])
		{
			continue;
		}
        
        BspLog(LOG_LEVEL_0,"dif[%d]carrmap_case2[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                    pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                    pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);
        
    	uMode = pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK;
		if(0 == (uMode&(BSP_CARR_MAP_SUPPORT_MODE|BSP_CARR_MAP_SUPPORT_MODE1)))
		{
			continue;
		}
		if(BSP_OK != BspGetDifModeByRadioMode(uMode, &uDifMode))
		{
			continue;
		}
    	if(NULL == s_CarrInfoTbl[uDir][uDifMode])
    	{
    		continue;
    	}
        if((UINT32)0xffffffff ==  pRfCfgPara->carrInfo[uIdx].freq)
        {
            continue;
        }
        uCarrMap = BspGetDifCarrMapPos(uDir,pRfCfgPara->carrInfo[uIdx].freq,pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK);
		uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*uSrcChn;
		pInfo   = &(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx]);
		for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uSrcIdx ++)
		{
			if(BSP_CARR_MAP_USED != pInfo[uSrcIdx].usedFlagDif)
			{
				continue;
			}
			if(BSP_CARR_MAP_NO_USE != pInfo[uSrcIdx].usedFlagIq)
			{
				continue;
			}
			if(pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST]!=uMode)
			{
				continue;
			}
			if(pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]!=pRfCfgPara->carrInfo[uIdx].carrNo)
			{
				continue;
			}
			/* 如果之前使用过，则保持该位置 */

            if(ERROR_NULL_POINTER != uCarrMap)
            {
                if (uMode == BSP_RADIO_STANDARD_UMTS)
                {
                    if((BIT_SET(uSrcIdx)&uCarrMap) &&(uSrcIdx == pRfCfgPara->carrInfo[uIdx].carrNo))
                    {
                        pInfo[uSrcIdx].usedFlagDif = BSP_CARR_MAP_USEING;
                        pMapFlag[uIdx]             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    if((BIT_SET(uSrcIdx)&uCarrMap) &&(pInfo[uSrcIdx].usedFlagDif != BSP_CARR_MAP_USEING))
                    {
                        pInfo[uSrcIdx].usedFlagDif = BSP_CARR_MAP_USEING;
                        pMapFlag[uIdx]             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            else
            {
                pInfo[uSrcIdx].usedFlagDif = BSP_CARR_MAP_USEING;   
                pMapFlag[uIdx]             = 1;
            }
            
			break;
		}
        
    BspLog(LOG_LEVEL_0,"dif[%d]carrmap_case2[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uSrcIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);
	}
    for(uIdx = 0; uIdx < pRfCfgPara->carrNum; uIdx ++)
	{
		if((UINT32)0 != pMapFlag[uIdx])
		{
			continue;
		}
        
        BspLog(LOG_LEVEL_0,"dif[%d]carrmap_case3[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                    pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                    pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);
    	uMode = pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK;
		if(0 == (uMode&(BSP_CARR_MAP_SUPPORT_MODE|BSP_CARR_MAP_SUPPORT_MODE1)))
		{
			continue;
		}
		if(BSP_OK != BspGetDifModeByRadioMode(uMode, &uDifMode))
		{
			continue;
		}
    	if(NULL == s_CarrInfoTbl[uDir][uDifMode])
    	{
    		continue;
    	}
        if((UINT32)0xffffffff ==  pRfCfgPara->carrInfo[uIdx].freq)
        {
            continue;
        }
        uCarrMap = BspGetDifCarrMapPos(uDir,pRfCfgPara->carrInfo[uIdx].freq,pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK);
		uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*uSrcChn;
		pInfo   = &(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx]);
		for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uSrcIdx ++)
		{
			if((BSP_CARR_MAP_USEING == pInfo[uSrcIdx].usedFlagDif)||(BSP_CARR_MAP_NO_USE != pInfo[uSrcIdx].usedFlagIq))
			{
				continue;
			}
            /* 如果之前使用过，则保持该位置 */
            if(ERROR_NULL_POINTER != uCarrMap)
            {
                if (uMode == BSP_RADIO_STANDARD_UMTS)
                {
                    if ((BIT_SET(uSrcIdx)&uCarrMap) && (uSrcIdx == pRfCfgPara->carrInfo[uIdx].carrNo))
                    {
                        pInfo[uSrcIdx].usedFlagDif                 = BSP_CARR_MAP_USEING;
                        pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
                        pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
                        pMapFlag[uIdx]                             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
                //if((BIT_SET(uSrcIdx)&uCarrMap) &&(uSrcIdx == pRfCfgPara->carrInfo[uIdx].carrNo))
                else
                {
                    if((BIT_SET(uSrcIdx)&uCarrMap) &&(pInfo[uSrcIdx].usedFlagDif != BSP_CARR_MAP_USEING))
                    {
                        pInfo[uSrcIdx].usedFlagDif = BSP_CARR_MAP_USEING;
                        pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
                        pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
                        pMapFlag[uIdx]             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            else
            {
    			/* 如果之前使用过，则保持该位置 */
    			pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
    			pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
    			pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USEING;
    			pMapFlag[uIdx]                            = 1;
            }
			break;
		}
        
    BspLog(LOG_LEVEL_0,"dif[%d]carrmap_case3[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uSrcIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);
	}

    for(uIdx = 0; uIdx < pRfCfgPara->carrNum; uIdx ++)
	{
		if((UINT32)0 != pMapFlag[uIdx])
		{
			continue;
		}
        
        BspLog(LOG_LEVEL_0,"dif[%d]carrmap_case4[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                    pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                    pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);
    	uMode = pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK;
		if((UINT32)0 == (uMode&(BSP_CARR_MAP_SUPPORT_MODE|BSP_CARR_MAP_SUPPORT_MODE1)))
		{
			continue;
		}
		if(BSP_OK != BspGetDifModeByRadioMode(uMode, &uDifMode))
		{
			continue;
		}
    	if(NULL == s_CarrInfoTbl[uDir][uDifMode])
    	{
    		continue;
    	}
        if((UINT32)0xffffffff ==  pRfCfgPara->carrInfo[uIdx].freq)
        {
            continue;
        }
        uCarrMap = BspGetDifCarrMapPos(uDir,pRfCfgPara->carrInfo[uIdx].freq,pRfCfgPara->carrInfo[uIdx].radioMode&BSP_RADIO_STANDARD_ST_MASK);
		uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*uSrcChn;
		pInfo   = &(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx]);
		for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uSrcIdx ++)
		{
			if(BSP_CARR_MAP_USEING == pInfo[uSrcIdx].usedFlagDif)
			{
				continue;
			}
			/* 如果之前使用过，则保持该位置 */
            if(ERROR_NULL_POINTER != uCarrMap)
            {
                if (uMode == BSP_RADIO_STANDARD_UMTS)
                {
                    if((BIT_SET(uSrcIdx)&uCarrMap) &&(uSrcIdx == pRfCfgPara->carrInfo[uIdx].carrNo))
                    {
                        pInfo[uSrcIdx].usedFlagDif                 = BSP_CARR_MAP_USEING;
                        pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
                        pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
                        pMapFlag[uIdx]                             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    //if((BIT_SET(uSrcIdx)&uCarrMap) &&(uSrcIdx == pRfCfgPara->carrInfo[uIdx].carrNo))
                    if((BIT_SET(uSrcIdx)&uCarrMap) &&(pInfo[uSrcIdx].usedFlagDif != BSP_CARR_MAP_USEING))
                    {
                        pInfo[uSrcIdx].usedFlagDif = BSP_CARR_MAP_USEING;
                        pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
                        pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
                        pMapFlag[uIdx]             = 1;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            else
            {
    			/* 如果之前使用过，则保持该位置 */
    			pInfo[uSrcIdx].carrMode[CARR_MAP_IDX_LAST] = uMode;
    			pInfo[uSrcIdx].carrNo[CARR_MAP_IDX_LAST]   = pRfCfgPara->carrInfo[uIdx].carrNo;
    			pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USEING;
    			pMapFlag[uIdx]                            = 1;
            }
			break;
		}
        
    BspLog(LOG_LEVEL_0,"dif[%d]carrmap_case4[%d]:carrNo[%d]mode[0x%x]freq[%d]bw[%d]flg[%d]fset[%d]\n",uBspChn,uSrcIdx,pRfCfgPara->carrInfo[uIdx].carrNo,\
                pRfCfgPara->carrInfo[uIdx].radioMode, pRfCfgPara->carrInfo[uIdx].freq, pRfCfgPara->carrInfo[uIdx].bandWidth,\
                pRfCfgPara->carrInfo[uIdx].cfgFlag,pRfCfgPara->carrInfo[uIdx].freqOffset);
	}

    free(pMapFlag);
    /* GN共资源，这两个数组只需要处理一个即可 */
    if(BSP_CARR_MAP_SUPPORT_MODE&BSP_RADIO_STANDARD_GSM)
    {
    	if(NULL != s_CarrInfoTbl[uDir][DIF_RADIOMODE_GSM])
    	{
    		uMapIdx = s_CarrInfoTbl[uDir][DIF_RADIOMODE_GSM]->carrResourceNum*uSrcChn;
    		pInfo   = &(s_CarrInfoTbl[uDir][DIF_RADIOMODE_GSM]->carrMapInfo[uMapIdx]);
    		for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][DIF_RADIOMODE_GSM]->carrResourceNum; uSrcIdx ++)
    		{    		
                if(0 == BspGetCarrMapDelFucSupportFlag())
                {
        			if(BSP_CARR_MAP_USEING == pInfo[uSrcIdx].usedFlagDif)
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
        			}
        			else
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_NO_USE;
        			}
                }
                else
                {
    				if(BSP_CARR_MAP_NO_USE != pInfo[uSrcIdx].usedFlagDif)
    				{
    					pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
    				}
                }
    		}
    	}

    }

    if(BSP_CARR_MAP_SUPPORT_MODE1&BSP_RADIO_STANDARD_LTE_FDD)
	{
    	if(NULL != s_CarrInfoTbl[uDir][DIF_RADIOMODE_LTE_FDD])
    	{
			uMapIdx = s_CarrInfoTbl[uDir][DIF_RADIOMODE_LTE_FDD]->carrResourceNum*uSrcChn;
			pInfo   = &(s_CarrInfoTbl[uDir][DIF_RADIOMODE_LTE_FDD]->carrMapInfo[uMapIdx]);
			for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][DIF_RADIOMODE_LTE_FDD]->carrResourceNum; uSrcIdx ++)
			{
                if(0 == BspGetCarrMapDelFucSupportFlag())
                {
        			if(BSP_CARR_MAP_USEING == pInfo[uSrcIdx].usedFlagDif)
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
        			}
        			else
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_NO_USE;
        			}
                }
                else
                {
    				if(BSP_CARR_MAP_NO_USE != pInfo[uSrcIdx].usedFlagDif)
    				{
    					pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
    				}
                }
			}
    	}
	}

    if(BSP_CARR_MAP_SUPPORT_MODE1&BSP_RADIO_STANDARD_UMTS)
	{
    	if(NULL != s_CarrInfoTbl[uDir][DIF_RADIOMODE_UMTS])
    	{
			uMapIdx = s_CarrInfoTbl[uDir][DIF_RADIOMODE_UMTS]->carrResourceNum*uSrcChn;
			pInfo   = &(s_CarrInfoTbl[uDir][DIF_RADIOMODE_UMTS]->carrMapInfo[uMapIdx]);
			for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][DIF_RADIOMODE_UMTS]->carrResourceNum; uSrcIdx ++)
			{
                if(0 == BspGetCarrMapDelFucSupportFlag())
                {
        			if(BSP_CARR_MAP_USEING == pInfo[uSrcIdx].usedFlagDif)
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
        			}
        			else
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_NO_USE;
        			}
                }
                else
                {
    				if(BSP_CARR_MAP_NO_USE != pInfo[uSrcIdx].usedFlagDif)
    				{
    					pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
    				}
                }
			}
    	}
	}

    if(BSP_CARR_MAP_SUPPORT_MODE1&BSP_RADIO_STANDARD_5G_IF0)
	{
    	if(NULL != s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF0])
    	{
    		//coverity[cert_int30_c_violation:SUPPRESS]
			uMapIdx = s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF0]->carrResourceNum*uSrcChn;
			//coverity[cert_ctr50_cpp_violation:SUPPRESS]
			pInfo   = &(s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF0]->carrMapInfo[uMapIdx]);
			for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF0]->carrResourceNum; uSrcIdx ++)
			{
                if(0 == BspGetCarrMapDelFucSupportFlag())
                {
        			if(BSP_CARR_MAP_USEING == pInfo[uSrcIdx].usedFlagDif)
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
        			}
        			else
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_NO_USE;
        			}
                }
                else
                {
    				if(BSP_CARR_MAP_NO_USE != pInfo[uSrcIdx].usedFlagDif)
    				{
    					pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
    				}
                }
			}
    	}
	}


    if(BSP_CARR_MAP_SUPPORT_MODE1&BSP_RADIO_STANDARD_5G_IF1)
	{
    	if(NULL != s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF1])
    	{
    		//coverity[cert_int30_c_violation:SUPPRESS]
			uMapIdx = s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF1]->carrResourceNum*uSrcChn;
			//coverity[cert_ctr50_cpp_violation:SUPPRESS]
			pInfo   = &(s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF1]->carrMapInfo[uMapIdx]);
			for(uSrcIdx = 0; uSrcIdx < s_CarrInfoTbl[uDir][DIF_RADIOMODE_NR_IF1]->carrResourceNum; uSrcIdx ++)
			{
                if(0 == BspGetCarrMapDelFucSupportFlag())
                {
        			if(BSP_CARR_MAP_USEING == pInfo[uSrcIdx].usedFlagDif)
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
        			}
        			else
        			{
        				pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_NO_USE;
        			}
                }
                else
                {
    				if(BSP_CARR_MAP_NO_USE != pInfo[uSrcIdx].usedFlagDif)
    				{
    					pInfo[uSrcIdx].usedFlagDif                = BSP_CARR_MAP_USED;
    				}
                }
			}
    	}
	}

	showcarrmap(4);
    return BSP_OK;
}

UINT32 BspAllocateCarrMapByIqCfg(T_RuMmIqCfgItem* pIqCfg)
{
    if(NULL == pIqCfg)
    {
        return BSP_ERROR;
	}
    return BSP_OK;
}

UINT32 BspGetMaxCarrNumByMode(UINT32 uMode,UINT32 uDir)
{
    UINT32 uDifMode = 0;
	UINT32 uCarrNum = 0;
	
    if((BSP_OK==BspGetDifModeByRadioMode(uMode,&uDifMode))&&(NULL != s_CarrInfoTbl[uDir][uDifMode]))
	{
        uCarrNum = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum;
	}
	else
	{
		switch(uMode)
		{
			case BSP_RADIO_STANDARD_5G:
			case BSP_RADIO_STANDARD_LTE_FDD:
				uCarrNum = 4;
				break;
			case BSP_RADIO_STANDARD_GSM:
				uCarrNum = 8;//0903：和逻辑确认是否最大支持8个GSM载波
				break;
			case BSP_RADIO_STANDARD_NB_IOT:
				uCarrNum = 8;
				break;
			case BSP_RADIO_STANDARD_UMTS:
				uCarrNum = 4;
				break;
			default:
				uCarrNum = 0;
				break;
		}
	}

#ifdef FDDNR_RADIO
	if(BSP_RADIO_STANDARD_FDD_5G == uMode)
	{
		uCarrNum = 4;
	}
#endif
	return uCarrNum;
}

UINT32 BspGetDifCarrMapPos(UINT32 uDir, UINT32 freq,UINT32 carrmode)
{
    /* UINT32 i = 0; */
    UINT32 j = 0;
    UINT32 mapval = ERROR_NULL_POINTER;    
  
    INPUT_POINTER_CHECK(s_CarrFrqMap);
  
    for(j=0;j<s_CarrFrqMapNum;j++)        
    {    
        if((s_CarrFrqMap[j]).dir != uDir)
        {
            continue;
        }
        
        if((s_CarrFrqMap[j]).carrmode != carrmode)
        {
            continue;
        }
        
        if((freq <= s_CarrFrqMap[j].carrendfrq) &&\
            (freq >= s_CarrFrqMap[j].carrstartfrq))
        {
            return s_CarrFrqMap[j].difcarrbitmap;
        }
    }

    return mapval;    
}


UINT32 BspGetCarrMapPos(UINT32 bspchn,UINT32 carrno)
{
    UINT32 carrmap = 0;
    UINT32 j = 0;
    UINT32 mapval = ERROR_NULL_POINTER;    
  
    INPUT_POINTER_CHECK(s_CarrMap);
    if(carrno >3)
    {
        return ERROR_NULL_POINTER;
    }
    
    for(j=0;j<s_CarrMapNum;j++)        
    {            
        if(s_CarrMap[j].bspchan != bspchn)
        {
            continue;
        }

        carrmap = s_CarrMap[j].carrpos;
        mapval = BITS_RIGHT_JUST_GET(carrmap,carrno*4,4);
        break;
    }

    return mapval;    
}

UINT32 BspGetBandDefNcoOffset(UINT32 uDir, UINT32 carrfrq,INT32 *defncoffset)
{
    /* UINT32 i = 0; */
    UINT32 j = 0;
    UINT32 mapval = ERROR_NULL_POINTER;    
  
    INPUT_POINTER_CHECK(defncoffset);    
    INPUT_POINTER_CHECK(s_CarrFrqMap);

    for(j=0;j<s_CarrFrqMapNum;j++)        
    {    
        if((s_CarrFrqMap[j]).dir != uDir)
        {
            continue;
        }
          
        if((carrfrq <= s_CarrFrqMap[j].carrendfrq) &&\
            (carrfrq >= s_CarrFrqMap[j].carrstartfrq))
        {
           mapval = BSP_OK;
           *defncoffset =  s_CarrFrqMap[j].defbanknco;
           break;
        }
    }

    return mapval;    
}


/**************************************************************************
 * 函数名称: BspGetCarrDifChanByCfg(*)
 * 功能描述:根据载波频点获取中频通道号，R9222机型特有接口
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/
UINT32 BspGetCarrDifChanByCfg(UINT32 bspchan,UINT32 uDir, UINT32 freq,UINT32 carrmode,UINT32 *difchan,UINT32 carrno)
{
    /* UINT32 i = 0; */
    UINT32 j = 0;
    UINT32 mapval = ERROR_NULL_POINTER;    
  
    INPUT_POINTER_CHECK(s_CarrFrqMap);
  
    for(j=0;j<s_CarrFrqMapNum;j++)        
    {    
        if((s_CarrFrqMap[j]).dir != uDir)
        {
            continue;
        }
        
        if((s_CarrFrqMap[j]).carrmode != carrmode)
        {
            continue;
        }
        
        if((freq <= s_CarrFrqMap[j].carrendfrq) &&\
            (freq >= s_CarrFrqMap[j].carrstartfrq))
        {
            if(0 == BITS_RIGHT_JUST_GET(s_CarrFrqMap[j].mapcarr,carrno*4,4))
            {
                *difchan = BITS_RIGHT_JUST_GET(s_CarrFrqMap[j].difchan,bspchan*4,4);            
                mapval = BSP_OK;
                break;
            }
        }
    }

    return mapval;    
}

UINT32 BspInitDifCarrMapTbl(UINT32 mapnum ,T_CarrFrqMapInfo *maptbl)
{
    INPUT_POINTER_CHECK(maptbl);    

    s_CarrFrqMapNum = mapnum;
    s_CarrFrqMap = maptbl;

    return BSP_OK;
}

static VOID PrintDifCarrMapTbl(VOID)
{
    UINT32 mapNum = s_CarrFrqMapNum;
    T_CarrFrqMapInfo *mapTbl = s_CarrFrqMap;
    UINT32 i = 0;

    if (mapTbl == NULL)
    {
        return;
    }

    dbgPrn("dir carrstartfrq carrendfrq difcarrbitmap carrmode defbanknco difchan\n");
    for (i = 0; i < mapNum; i++)
    {
        dbgPrn("%-3d %-12d %-10d %-13d %-8d %-10d %d\n", mapTbl[i].dir, mapTbl[i].carrstartfrq, mapTbl[i].carrendfrq, mapTbl[i].difcarrbitmap, mapTbl[i].carrmode, mapTbl[i].defbanknco, mapTbl[i].difchan);
    }
}

UINT32 BspInitCarrMapTbl(UINT32 mapnum ,T_CarrMapInfo *maptbl)
{
    INPUT_POINTER_CHECK(maptbl);    

    s_CarrMapNum = mapnum;
    s_CarrMap = maptbl;

    return BSP_OK;
}

UINT32 BspSetDifCarrMapCfg(UINT32 mapnum,T_CarrFrqMapInfo *freqmapcfg)
{
    INPUT_POINTER_CHECK(freqmapcfg);    

    s_CarrFrqMap = freqmapcfg;
    s_CarrFrqMapNum = mapnum;

    return BSP_OK;
}

static UINT32 testGsmBitMap = 0;
static UINT32 testNbBitMap = 0;

#if 0 //清除coverity 没验证环境，调试函数，先注释
UINT32 testiqcfgmap(UINT32 uBitGsm, UINT32 uBitNb)
{
	UINT32 uIdx = 0;
	UINT32 uNum = 0;
	T_RuMmIqCfg tTmp = {0};
	uNum = 0;
    for(uIdx = 0; uIdx < 32; uIdx ++)
    {
        if(((uBitGsm>>uIdx)&1)>((testGsmBitMap>>uIdx)&1))
        {
        	tTmp.atIqItem[uNum].ucRadioMode    = BSP_RADIO_STANDARD_GSM;
        	tTmp.atIqItem[uNum].ucRruCarrierNo = (uIdx&0xf)%4;
        	tTmp.atIqItem[uNum].ucRruAntNo     = (uIdx&0xf)/4;
        	tTmp.atIqItem[uNum].ucFwOrRev      = uIdx/16;
        	tTmp.atIqItem[uNum].ucAddDelFlag   = 1;
        	uNum++;
        }
        if(((uBitGsm>>uIdx)&1)<((testGsmBitMap>>uIdx)&1))
		{
			tTmp.atIqItem[uNum].ucRadioMode    = BSP_RADIO_STANDARD_GSM;
			tTmp.atIqItem[uNum].ucRruCarrierNo = (uIdx&0xf)%4;
			tTmp.atIqItem[uNum].ucRruAntNo     = (uIdx&0xf)/4;
			tTmp.atIqItem[uNum].ucFwOrRev      = uIdx/16;
			tTmp.atIqItem[uNum].ucAddDelFlag   = 2;
			uNum++;
		}
        if(((uBitNb>>uIdx)&1)>((testNbBitMap>>uIdx)&1))
		{
			tTmp.atIqItem[uNum].ucRadioMode    = BSP_RADIO_STANDARD_NB_IOT;
			tTmp.atIqItem[uNum].ucRruCarrierNo = (uIdx&0xf)%4;
			tTmp.atIqItem[uNum].ucRruAntNo     = (uIdx&0xf)/4;
			tTmp.atIqItem[uNum].ucFwOrRev      = uIdx/16;
			tTmp.atIqItem[uNum].ucAddDelFlag   = 1;
			uNum++;
		}
		if(((uBitNb>>uIdx)&1)<((testNbBitMap>>uIdx)&1))
		{
			tTmp.atIqItem[uNum].ucRadioMode    = BSP_RADIO_STANDARD_NB_IOT;
			tTmp.atIqItem[uNum].ucRruCarrierNo = (uIdx&0xf)%4;
			tTmp.atIqItem[uNum].ucRruAntNo     = (uIdx&0xf)/4;
			tTmp.atIqItem[uNum].ucFwOrRev      = uIdx/16;
			tTmp.atIqItem[uNum].ucAddDelFlag   = 2;
			uNum++;
		}
    }
    tTmp.ulNum = uNum;
    BspAllocateCarrMapByIqCfg_1(&tTmp);
	testGsmBitMap = uBitGsm;
	testNbBitMap  = uBitNb;
	return BSP_OK;
}
#endif

#ifdef BUILD_WITH_OM_FUNC
UINT32 testrfcfg(UINT32 uBitGsm, UINT32 uBitNb)
{
	UINT32 uIdx = 0;
	UINT32 uChn = 0;
	UINT32 uDir = 0;
	UINT32 uNum = 0;
	UINT32 uStartBit = 0;
	T_RfCfgPara tTmp    = {0};
	T_CarrInfo  tCar[8] = {0};
	tTmp.carrInfo = tCar;
	uDir = TX;
	uNum = 0;
	for(uChn = 0; uChn < 2; uChn++)
	{
		uNum = 0;
		uStartBit = uDir*16 + uChn*4;
        for(uIdx = uStartBit; uIdx < (uStartBit+4); uIdx++)
        {
            if((uBitGsm>>uIdx)&1)
            {
            	tTmp.carrInfo[uNum].carrNo = uIdx - uStartBit;
            	tTmp.carrInfo[uNum].radioMode = BSP_RADIO_STANDARD_GSM;
            	uNum++;
            }
            if((uBitNb>>uIdx)&1)
			{
				tTmp.carrInfo[uNum].carrNo = uIdx - uStartBit;
				tTmp.carrInfo[uNum].radioMode = BSP_RADIO_STANDARD_NB_IOT;
				uNum++;
			}
        }
        tTmp.carrNum = uNum;
        BspAllocateCarrMapByRfCfg(uChn,TX,&tTmp);
	}
	uDir = RX;
	uNum = 0;
	for(uChn = 0; uChn < 4; uChn++)
	{
		uNum = 0;
		uStartBit = uDir*16 + uChn*4;
		for(uIdx = uStartBit; uIdx < (uStartBit+4); uIdx++)
		{
			if((uBitGsm>>uIdx)&1)
			{
				tTmp.carrInfo[uNum].carrNo = uIdx - uStartBit;
				tTmp.carrInfo[uNum].radioMode = BSP_RADIO_STANDARD_GSM;
				uNum++;
			}
			if((uBitNb>>uIdx)&1)
			{
				tTmp.carrInfo[uNum].carrNo = uIdx - uStartBit;
				tTmp.carrInfo[uNum].radioMode = BSP_RADIO_STANDARD_NB_IOT;
				uNum++;
			}
		}
		tTmp.carrNum = uNum;
		BspAllocateCarrMapByRfCfg(uChn,RX,&tTmp);
	}
    return BSP_OK;
}
UINT32 clcmapiNfo(UINT32 uMode)
{
	UINT32 uDifMode = 0;
	testGsmBitMap = 0;
	testNbBitMap  = 0;
	if((BSP_OK==BspGetDifModeByRadioMode(uMode,&uDifMode))&&(NULL != s_CarrInfoTbl[0][uDifMode]))
	{
		memset(s_CarrInfoTbl[0][uDifMode]->carrMapInfo,0,sizeof(T_DifCarrMapInfo)*s_CarrInfoTbl[0][uDifMode]->carrResourceNum*s_CarrInfoTbl[0][uDifMode]->chnNum);
		memset(s_CarrInfoTbl[1][uDifMode]->carrMapInfo,0,sizeof(T_DifCarrMapInfo)*s_CarrInfoTbl[1][uDifMode]->carrResourceNum*s_CarrInfoTbl[1][uDifMode]->chnNum);
	}
	return BSP_OK;
}

#endif
UINT32 showcarrmap(UINT32 uDifMode)
{
	UINT32 uIdx = 0;
	UINT32 uChn = 0;
	UINT32 uMap = 0;

    if (uDifMode >= DIF_RADIOMODE_MAX)
    {
        printf("DifMode %d Err\n", uDifMode);
        return BSP_ERROR;
    }
	
    printf("[0]mode [1]dir [2]chn [3]difid [4]iqcarrno [5]iqcarrmode [6]difcarrno [7]difcarrmode [8]difflag [9]iqflag\n");
	printf("\n");
	if(NULL != s_CarrInfoTbl[0][uDifMode])
	{
		uMap = 0;
		for(uChn = 0; uChn < s_CarrInfoTbl[RX][uDifMode]->chnNum;uChn++)
		{
            for(uIdx = 0; uIdx < s_CarrInfoTbl[RX][uDifMode]->carrResourceNum; uIdx++)
            {
                printf("[0]G/N\t");
                printf("[1]RX\t");
                printf("[2]%d\t",uChn);
                printf("[3]%d\t",uIdx);
                printf("[4]%d\t",s_CarrInfoTbl[RX][uDifMode]->carrMapInfo[uMap].carrNo[0]);
                printf("[5]%d\t",s_CarrInfoTbl[RX][uDifMode]->carrMapInfo[uMap].carrMode[0]);
                printf("[6]%d\t",s_CarrInfoTbl[RX][uDifMode]->carrMapInfo[uMap].carrNo[1]);
                //coverity[cert_ctr50_cpp_violation:SUPPRESS]
                dbgInfo("[7]%12x\t",s_CarrInfoTbl[RX][uDifMode]->carrMapInfo[uMap].carrMode[1]);
                printf("[8]%d\t",s_CarrInfoTbl[RX][uDifMode]->carrMapInfo[uMap].usedFlagDif);
                printf("[9]%d\n",s_CarrInfoTbl[RX][uDifMode]->carrMapInfo[uMap].usedFlagIq);
                uMap++;
            }
		}
		uMap = 0;
		for(uChn = 0; uChn < s_CarrInfoTbl[TX][uDifMode]->chnNum;uChn++)
		{
			for(uIdx = 0; uIdx < s_CarrInfoTbl[TX][uDifMode]->carrResourceNum; uIdx++)
			{
				printf("[0]G/N\t");
				printf("[1]TX\t");
				printf("[2]%d\t",uChn);
				printf("[3]%d\t",uIdx);
				printf("[4]%d\t",s_CarrInfoTbl[TX][uDifMode]->carrMapInfo[uMap].carrNo[0]);
				//coverity[cert_ctr50_cpp_violation:SUPPRESS]
				dbgInfo("[5]%x\t",s_CarrInfoTbl[TX][uDifMode]->carrMapInfo[uMap].carrMode[0]);
				printf("[6]%d\t",s_CarrInfoTbl[TX][uDifMode]->carrMapInfo[uMap].carrNo[1]);
				//coverity[cert_ctr50_cpp_violation:SUPPRESS]
				dbgInfo("[7]%12x\t",s_CarrInfoTbl[TX][uDifMode]->carrMapInfo[uMap].carrMode[1]);
				printf("[8]%d\t",s_CarrInfoTbl[TX][uDifMode]->carrMapInfo[uMap].usedFlagDif);
				printf("[9]%d\n",s_CarrInfoTbl[TX][uDifMode]->carrMapInfo[uMap].usedFlagIq);
				uMap++;
			}
		}
	}


	return BSP_OK;
}

UINT32 BspGetRruSupportCarrNum(UINT32 uChn, UINT32 uBand, UINT32 uMode)
{
    return BspGetMaxCarrNumByMode(uMode,TX);
}

UINT32 BspGetDifCarrNoByIqCfg(T_RuMmIqCfgItem* pIqCfg,UINT32* pCarrNo)
{
    UINT32 uDifMode = 0;
	UINT32 uCarrNum = 0;
	UINT32 uMapIdx  = 0;
	UINT32 uDir     = 0;
	UINT32 uIdx     = 0;
	UINT32 uFlag    = 0;

    if(NULL == pIqCfg)
    {
        return BSP_ERROR;
	}
	if(NULL == pCarrNo)
    {
        return BSP_ERROR;
	}
	if((pIqCfg->ucFwOrRev!=TX)&&(pIqCfg->ucFwOrRev!=RX))
	{
        return BSP_ERROR;
	}
	if(BSP_OK != BspGetDifModeByRadioMode(pIqCfg->ucRadioMode,&uDifMode))
	{
    	return BSP_ERROR;
	}

	if((BSP_CARR_MAP_SUPPORT_SWITCH)&&(pIqCfg->ucRadioMode&BSP_CARR_MAP_SUPPORT_MODE))
	{
		uDir = pIqCfg->ucFwOrRev;
		uFlag = 0;
		if(NULL == s_CarrInfoTbl[uDir][uDifMode])
		{
	    	*pCarrNo = BSP_MAX_CARR_NUM;
            return BSP_ERROR;
		}
		uMapIdx = s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum*(BspGetChnNumByIqInfo(pIqCfg)%BspGetBspChanNum(TX));
		dbgInfoEx("uDir%d, RadioMode%d, DifMode %d, carrno %d, uMapIdx %d  carrResourceNum%d\n",
			uDir, pIqCfg->ucRadioMode,uDifMode, pIqCfg->ucRruCarrierNo, uMapIdx, s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum);
		for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
		{
		    dbgInfoEx("uIdx%d, usedFlagIq %d, carrMode %d, carrNo %d\n", uIdx,s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq, 
				s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW], s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW]);
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq==BSP_CARR_MAP_NO_USE)
			{
				continue;
			}
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW]!=pIqCfg->ucRadioMode)
			{
				continue;
			}
			if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW]!=pIqCfg->ucRruCarrierNo)
			{
				continue;
			}
			uFlag = 1;
            break;
		}
		if(0==uFlag)
		{
			for(uIdx = 0; uIdx < s_CarrInfoTbl[uDir][uDifMode]->carrResourceNum; uIdx ++)
			{
			    dbgInfoEx("uIdx %d, usedFlagIq %d, carrMode %d, carrNo %d\n", uIdx,s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq, 
				    s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW], s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW]);
				if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagIq!=BSP_CARR_MAP_NO_USE)
				{
					continue;
				}
				if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrMode[CARR_MAP_IDX_NOW]!=pIqCfg->ucRadioMode)
				{
					continue;
				}
				if(s_CarrInfoTbl[uDir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_NOW]!=pIqCfg->ucRruCarrierNo)
				{
					continue;
				}
				uFlag = 1;
				break;
			}
		}
		if(1 == uFlag)
		{
	    	*pCarrNo = uIdx;
	    	dbgInfoEx("BspGetDifCarrNoByIqCfg Mode %d, carrno %d, ANt %d, difNo %d\n ",pIqCfg->ucRadioMode,pIqCfg->ucRruCarrierNo,pIqCfg->ucRruAntNo, *pCarrNo);
	    	return BSP_OK;
		}
		else
		{
	    	*pCarrNo = BSP_MAX_CARR_NUM;
	    	dbgInfoEx("BspGetDifCarrNoByIqCfg Mode %d, carrno %d, ANt %d, failed\n ",pIqCfg->ucRadioMode,pIqCfg->ucRruCarrierNo,pIqCfg->ucRruAntNo);
    	    return BSP_ERROR;
		}

	}
	else if((DIF_RADIOMODE_GSM == uDifMode))
	{
	    if(NULL != s_CarrInfoTbl[pIqCfg->ucFwOrRev][uDifMode])
	    {
            uCarrNum = s_CarrInfoTbl[pIqCfg->ucFwOrRev][uDifMode]->carrResourceNum;
		}
		else
		{
            uCarrNum = 4;
		}
		if(pIqCfg->ucRruCarrierNo<uCarrNum)
		{
    	    *pCarrNo = uCarrNum - (UINT32)pIqCfg->ucRruCarrierNo - 1;
		}
		else
    	{
        	*pCarrNo = (UINT32)pIqCfg->ucRruCarrierNo;
    	}
		dbgInfoEx("BspGetDifCarrNoByIqCfg Radio%d, uCarrNum %d, CarrNo %d, pCarrNo %d\n ",
			pIqCfg->ucRadioMode,uCarrNum, pIqCfg->ucRruCarrierNo, *pCarrNo);
	    
	}
	else
	{
    	*pCarrNo = (UINT32)pIqCfg->ucRruCarrierNo;
	}
    return BSP_OK;
}

/* 驻波位置检测发单音时现存配置可能干扰载波映射结果，直接使用配置载波号 */
VOID BspSetTsgMode(UINT8 enable)
{
    s_TsgMode = enable;
    dbgInfo("%s: %s(%d) tsg mode\n", __FUNCTION__, (enable == 0) ? "disable" : "enable", enable);
}

static UINT8 BspGetTsgMode(VOID)
{
    return s_TsgMode;
}

static UINT8 BspSupportTsgMode(VOID)
{
    return s_SupportTsgMode;
}

VOID BspSetSupportTsgMode(UINT8 enable)
{
    s_SupportTsgMode = enable;
}

UINT32 BspGetBspChanNum(UINT32 dir)
{
    UINT32 chnNum = 0;
	if(TX==dir)
	{
	    chnNum = BspGetTxChannel();
	}
	if(RX==dir)
	{
	    chnNum = BspGetRxLogicChanNum();
	}
    return chnNum;
}

UINT32 BspGetDifModeByRadioMode(UINT32 uMode, UINT32 *pDifMode)
{
    UINT32 uIdx = 0;
	UINT32 uNum = 0;
	UINT32 uRet = BSP_ERROR;
	if(NULL == pDifMode)
	{
        return BSP_ERROR;
	}
	uNum = sizeof(s_ModeMapInfo)/sizeof(s_ModeMapInfo[0]);
	for(uIdx = 0; uIdx < uNum; uIdx ++)
	{
        if(uMode==s_ModeMapInfo[uIdx])
        {
            *pDifMode = uIdx;
            uRet      = BSP_OK;
            break;
		}
	}
    return uRet;
}



UINT32 BspGetRadioModeByDifMode(UINT32 uDifMode, UINT32 *pMode)
{
    /* UINT32 uIdx = 0; */
	UINT32 uNum = 0;
	UINT32 uRet = BSP_ERROR;
	if(NULL == pMode)
	{
        return BSP_ERROR;
	}
	uNum = sizeof(s_ModeMapInfo)/sizeof(s_ModeMapInfo[0]);

    if(uDifMode < uNum)
    {
        *pMode = s_ModeMapInfo[uDifMode];
        uRet      = BSP_OK;
	}
    return uRet;
}

static UINT32 s_divSwitchFlag = 0;
static UINT32 s_antAlterSwitchFlag = 0;

UINT32 BspSetDivFlag(UINT32 divFlag)
{
    if(SWITCH_ON == divFlag)
    {
        s_divSwitchFlag = SWITCH_ON;
	}
	else /*if(SWITCH_OFF == divFlag)*/
	{
    	s_divSwitchFlag = SWITCH_OFF;
	}

	return BSP_OK;
}

UINT32 BspGetDivFlag(void)
{
    UINT32 divFlag = 0;
	if(SWITCH_ON == s_divSwitchFlag)
	{
        divFlag = SWITCH_ON;
	}
	else
	{
    	divFlag = SWITCH_OFF;
	}
	return divFlag;
}



#ifdef BUILD_WITH_OM_FUNC
UINT32 BspSetAntAlterFlag(UINT32 antAlterFlag)
{
    if(SWITCH_ON == antAlterFlag)
    {
    	s_antAlterSwitchFlag = SWITCH_ON;
	}
	else /*if(SWITCH_OFF == divFlag)*/
	{
		s_antAlterSwitchFlag = SWITCH_OFF;
	}

	return BSP_OK;
}

UINT32 BspGetAntAlterFlag()
{
    UINT32 antAlterFlag = 0;
	if(SWITCH_ON == s_antAlterSwitchFlag)
	{
		antAlterFlag = SWITCH_ON;
	}
	else
	{
		antAlterFlag = SWITCH_OFF;
	}
	return antAlterFlag;
}

#endif


UINT32 BspGetRxLogicChanNum()
{
    UINT32 uRxChn = 0;
    UINT32 uTxChn = 0;

    uRxChn = BspGetRxChannel();

    if(SWITCH_ON == BspGetDivFlag())
    {
        uTxChn = BspGetTxChannel();
        if(uRxChn == uTxChn)
        {
        	uRxChn *= 2;
        }
    }
	return uRxChn;
}

UINT32 BspSetCarrMap(UINT32 chn,UINT32 dir)
{
    UINT32 uDifMode = 0;
	/* UINT32 uDifCarr = 0; */
	/* UINT32 uCarrNum = 0; */
	UINT32 uIdx  = 0;
	/* UINT32 carruIdx     = 0; */
    UINT32 carrmapval = 0;
    UINT32 carroffset = 0;
    UINT32 difId = 0;
    UINT32 difChan = 0;
    /* UINT32 chanOffset = 0; */
    UINT32 carrMode = 0;
    UINT32 uMapIdx = 0;
    
    INPUT_POINTER_CHECK(s_CarrMap);
	if((dir!=TX)&&(dir!=RX))
	{
        return ERROR_NULL_POINTER;
	}

    carroffset = (dir == TX)?REG_TX_LTE_CARR_ROUTE_CFG :REG_RX_LTE_CARR_ROUTE_CFG;
#ifndef _4C_VDE_TEST_
    if ( BspGetDifInfoByBspChn(chn,dir,(UINT32*)&difId,(UINT32*)&difChan) != BSP_OK )
    {
        return BSP_ERROR;
    }
#endif
	carrMode = BSP_RADIO_STANDARD_LTE_FDD; //暂时只支持LTE
	if(BSP_OK != BspGetDifModeByRadioMode(carrMode, &uDifMode))
	{
        return BSP_ERROR;
	}
    
	if((BSP_CARR_MAP_SUPPORT_SWITCH)&&(carrMode&(BSP_CARR_MAP_SUPPORT_MODE|BSP_CARR_MAP_SUPPORT_MODE1)))
	{
		if(NULL == s_CarrInfoTbl[dir][uDifMode])
		{
			return BSP_MAX_CARR_NUM;
		}
		uMapIdx = s_CarrInfoTbl[dir][uDifMode]->carrResourceNum*(chn%BspGetBspChanNum(TX));
		for(uIdx = 0; uIdx < s_CarrInfoTbl[dir][uDifMode]->carrResourceNum; uIdx ++)
		{
    		if(s_CarrInfoTbl[dir][uDifMode]->carrMapInfo[uMapIdx+uIdx].usedFlagDif==BSP_CARR_MAP_NO_USE)
			{
                BspRegBitValWr(difId,carroffset,0x2000*difChan+(uIdx/2), 0xff, 0+4*(uIdx/2), 3+4*(uIdx/2));
			}
            else 
            {
                carrmapval = BspGetCarrMapPos(chn,s_CarrInfoTbl[dir][uDifMode]->carrMapInfo[uMapIdx+uIdx].carrNo[CARR_MAP_IDX_LAST]);
                if(carrmapval != BSP_OK)
                {
                    continue;
                }
                else 
                {  
                    BspRegBitValWr(difId,carroffset,0x2000*difChan+(uIdx/2), carrmapval, 0+4*(uIdx/2), 3+4*(uIdx/2));
                }
            }
		}
	}        

    return BSP_OK;
}

UINT32 BspGetCarrIndexByFreq(UINT32 uDir,UINT32 freq,UINT32 carrmode)
{
    UINT32 mapval = 0;
	UINT32 carrindex = 0;
	UINT32 carrnum = 0;
	UINT32 i = 0;
	
	mapval = BspGetDifCarrMapPos(uDir, freq, carrmode);
	if(mapval == ERROR_NULL_POINTER)
	{
        return 0;
	}

    carrnum = BspGetCarrierNum();
    for(i = 0; i < carrnum; i++)
    {
        if((mapval >> i) & 0x01 ) break;
	}
	carrindex = i;

	return carrindex;
}

UINT32 BspGetModeNoByRadioMode(UINT32 uMode, UINT32 *pModeNo)
{
    UINT32 uIdx = 0;
	UINT32 uRet = BSP_ERROR;
    INPUT_POINTER_CHECK(pModeNo);
	for(uIdx = 0; uIdx < RADIO_MAP_TYPE_NUM; uIdx ++)
	{
        if(uMode == s_RadioMap[uIdx].radioType)
        {
            *pModeNo = s_RadioMap[uIdx].radioNo;
            uRet      = BSP_OK;
            break;
		}
	}
    return uRet;
}

/* 根据配频预分析的全量信息生成业务载波号和载波序号之间的关系 */
static CallBackFuncGetCarrIdx s_pFuncGetCarrIdxByPreAnalyse = NULL;

UINT32 BspGetPreAnalyseCarrIdx(UINT32 dir, UINT32 bspChan, UINT32 radio, UINT32 carrNo)
{
    if(NULL != s_pFuncGetCarrIdxByPreAnalyse)
    {
        return (*s_pFuncGetCarrIdxByPreAnalyse)(dir, bspChan, radio, carrNo);
    }

    return BSP_ERROR;
}

VOID BspSetPreAnalyseCarrIdxFunc(CallBackFuncGetCarrIdx pFunc)
{
    s_pFuncGetCarrIdxByPreAnalyse = pFunc;
}

UINT32 BspUpdateCarrCfgFlag(UINT32 bspChan, UINT32 dir, T_RfCfgPara *rfCfg)
{
    return BSP_OK;
}

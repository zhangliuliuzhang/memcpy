
#include <signal.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "bspcommon.h"
#include "systemcallapi.h"
#include "vxadp.h"
#include "exprn.h"
#include "funccommon.h"
#include "ru_univdef.h"
#include "funccommonapi.h"
#include "flash.h"
#include "devdrv_clk.h"
#include "boardid.h"
#include "dualbootapi.h"
#include "regdrv_access.h"
#include "fpgaload.h"
#include "ichaladapt_crm_ic4_2.h"

#define BSP_SOC_MAX_NUM        8
#define HW_INFO_OK                 0
#define HW_INFO_ERROR              1
#define WR_CRC_FINISH_FLAG         0xa5

char * ANTI_TAMPER_FILE = "/tmp/cali/RruInfo.txt";
#define MAX_BAND_INFO_LENTH        (UINT32)(20)

#define _ASNPRINTF(dst,src)                              \
        retVal = snprintf_s(dst,sizeof(dst),"%s\0",src);     \
        SNPRINTF_S_CHECK(retVal, sizeof(dst));
#define CHECK_FLASH_ADDR(addr)                                        \
if (0 == addr)                                                        \
{                                                                     \
        printf("%s:base addr is 0,please check it!\n",__FUNCTION__);  \
        return ERROR;                                                 \
}

#define CHECK_CRC_CLR_FLASH_OFFEST_ADDR(addr)                                        \
if (CRC_CLR_FLGA_OFFSET_ADDR != addr)                                                        \
{                                                                     \
        printf("%s:crc clr flga addr is not %d,please check it!\n",__FUNCTION__, CRC_CLR_FLGA_OFFSET_ADDR);  \
        return ERROR;                                                 \
}

/* 信号量申请管理 */
typedef struct tagT_SemMgrType
{
    SEM_ID sem;
    char   owner[16];
    char   taker[32];
    UINT32 tickTake;
    UINT32 tickGive;
    struct tagT_SemMgrType *next;
}T_SemMgrType;

typedef struct tagT_PowerOnRecord
{
    UINT32 rstCount;  /* 上电次数 */
}T_PowerOnRecord;

typedef struct tagT_PowerOnRecordInfo
{
    UINT32           init;
	CHAR             fileName[64];
	T_PowerOnRecord  record;
} T_PowerOnRecordInfo;

typedef struct tagT_SlavePortBandInfo
{
    UINT32 freqBand;
    UINT32 startFreq;
    UINT32 endFreq;
}T_SlavePortBandInfo;

static SET_SLAVEPORT_SWITCH pSetSlavePortSwitch = NULL;
static SET_RRUANGLE_CFG pSetRruAntAngleCfg = NULL;
static SET_SLAVEPORT_CBSW_DSP_CFG pSetSlavePortCbSwAndDspCfg = NULL;
static GETSET_SLAVEPORT_STATUS pSlavePortStatus = NULL;
static GET_SLAVEPORT_DEVNAME pGetSlavePortDevName = NULL;
static SET_SLAVEPORT_CFG pSetSlavePortCfg = NULL;
static GET_ANTINFO_BY_PORTID pGetAntInfoBySlavePortId = NULL;
static RESET_SLAVE_PORT pResetSlavePort = NULL;
static GET_SLAVE_PORT_TEMPANDVOLT pGetSlavePortChanTempVolt = NULL;

/* 该函数指针用来标示该单板是否添加mcs静态arp，使用时在boardinit注册 zhengtong 20180417 */
pSetNetCfg pfSetNetCfg = NULL;

static UINT32 maxCarrierNum = BSP_MAX_CARR_NUM;
static UINT32 maxSlaveCarrierNum = 0;   /*子端载波能力*/
static UINT32 maxCfgLoopNum = 0xFFFF;

static FUNC_RESET_DEV pResetDevice = NULL;

static UINT32 gsResetType = 0xffff;

static UINT32 gsResetCause = 0xffff;

static SIG_HNDL pSigHndl = NULL;

static T_SemMgrType semMgrHead = {0};

static FUNC_DPDVSWR_TBL_STATE pDpdVswrTblState = NULL;

static UINT32 s_rruWorkMode = WFS_NO_TEST_MODE;

static UINT32 s_clkInitStat = 0;

static FUNC_SWITCH_FPGA pSwitchFpga = NULL;
static UINT32 switchFpgaEnable = 0;

static FUNC_PowOn_Strategy pPowOnStrategy = NULL;
static FUNC_Process_Sta pProcessSta = NULL;
static FUNC_Process_Strategy pProcessStrategy = NULL;

static FUNC_CheckFpgaStatus pCheckFpgaStatus = NULL;
static UINT32 s_checkFpgaIndex[16] = {0};
static UINT32 s_checkFpgaNum = 0;

static T_PowerOnRecordInfo  powerOnRecordInfo = {0, "", {0}};

static FUNC_FunSet_Ptr  pFuncSetPtr = NULL;

static T_EcpriUdpPortInfo s_ecpriUdpPortInfo = {{0}, NULL, NULL, 0};

static FUNC_RESET_SFP pResetSfp = NULL;

static UINT32 s_ulBspGpioRegRdWrMode = 0; // 0-默认寄存器操作模式, 0xC35A-GPIO操作模式
static UINT32 s_atgMultiFrameFlag = 0;  /* 是否支持在线改配帧结构, 1:支持, 0:不支持 */
static UINT32 s_frameStruc = BSP_ERROR; /* 帧结构, 1:20ms, other:非20ms */
static UINT32 s_optIf1taDelay = 0;
static UINT32 s_optIf1hwLinkDelay = 0;

static UINT32 g_VirtualCarrNoOffset = 0;
static UINT32 g_VirtualCarrNoMod = UINT_MAX;
static UINT32 s_innerSedesSta = 0;
static UINT32 s_innerSedesSelfSaveCnt = 0;
static UINT32 BspBoardResetFlag = 0;/* 允许BoardReset */
static UINT32 g_subPortSwSta = 0;
static UINT32 g_DflOutRangFlag = NO_SUPPORT;
static UINT32 g_SfpSelfHealFlag = NO_SUPPORT;
T_SlavePortBaseInfo g_SlavePortBaseInfo[MAX_SLAVE_PORT_NUM] = {0};
static T_SlavePortRruInfo s_SlavePortRruInfo[MAX_SLAVE_PORT_NUM] = {0};
static T_SlavePortPwrInfo s_SlavePortPwrInfo[MAX_SLAVE_PORT_NUM] = {0};
static T_SlavePortDflInfo s_SlavePortDflInfo[MAX_SLAVE_PORT_NUM][MAX_SLAVE_CHAN_NUM] = {0};
static T_SlavePortPaInfo s_SlavePortPaInfo[MAX_SLAVE_PORT_NUM] = {0};
static funcGetFanStatusCallBack pGetFanStatusCallBack = NULL;
static BSP_SUPPORT_VER_DECOUPLE_CALLBACK_FUNCPTR pSupportVerDecoupleCallback = NULL;
static funcGetPoeNumCallBack pGetPoeNumCallBack = NULL;

#define ECPRI_UDP_PORT_INIT_CHK()    if (s_ecpriUdpPortInfo.init != 1)  return BSP_ERROR
static T_VswrPosCalcPara s_vswrPosPara[BSP_MAX_CHAN_NUM][MAX_BAND_NUM] = {0};
static UINT32 s_multiVswrFlag = 0;

/* Started by AICoder, pid:faf75b0ff2h1a2d1457609af901ef53cd9c09957 */
/**
 * @brief PA电压调整标志。
 */
static UINT32 s_paVoltAdjustFlag = 0;

/**
 * @brief 获取PA电压调整标志。
 *
 * 该函数返回当前的PA电压调整标志。
 *
 * @return 当前的PA电压调整标志。
 */
UINT32 BspGetPaVoltAdjustFlag()
{
    return s_paVoltAdjustFlag;
}

/**
 * @brief 设置PA电压调整标志。
 *
 * 该函数设置当前的PA电压调整标志。
 *
 * @param flag 要设置的PA电压调整标志（0:不调整，1:调整）。
 */
void BspSetPaVoltAdjustFlag(UINT32 flag)
{
    s_paVoltAdjustFlag = flag;
}
/* Ended by AICoder, pid:faf75b0ff2h1a2d1457609af901ef53cd9c09957 */

UINT32 BspSetVswrPosCalcPara(UINT32 chan, UINT32 band, T_VswrPosCalcPara para)
{
    if(chan >= BSP_MAX_CHAN_NUM || band >= MAX_BAND_NUM)
    {
        return BSP_ERROR;
    }
    memcpy_s((void*)&s_vswrPosPara[chan][band], sizeof(T_VswrPosCalcPara), (void*)&para, sizeof(T_VswrPosCalcPara));
    return BSP_OK;
}

UINT32 BspGetVswrPosCalcPara(UINT32 chan, UINT32 band, T_VswrPosCalcPara *para)
{
    if(chan >= BSP_MAX_CHAN_NUM || band >= MAX_BAND_NUM)
    {
        return BSP_ERROR;
    }
    memcpy_s((void*)para, sizeof(T_VswrPosCalcPara), (void*)&s_vswrPosPara[chan][band], sizeof(T_VswrPosCalcPara));
    return BSP_OK;
}

void BspSetDpdMultiVswrFlag(UINT32 flag)
{
    s_multiVswrFlag = flag;
    return ;
}

UINT32 BspGetDpdMultiVswrFlag(void)
{
    return s_multiVswrFlag;
}

static VOID SemMgrInit(T_SemMgrType *semMgr,const char *owner)
{
    int snpRet;
    if (semMgr == NULL)
    {
        return ;
    }
    semMgr->sem = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (semMgr->sem)
    {
        memset(semMgr->taker,0,sizeof(semMgr->taker));
        snpRet = snprintf_s(semMgr->owner,sizeof(semMgr->owner),"%s\0",owner);
        SNPRINTF_S_CHECK(snpRet, sizeof(semMgr->owner));
        semMgr->tickTake = 0;
        semMgr->tickGive = 0;
        semMgr->next = NULL;
    }
}

static VOID SemMgrHeadInit()
{
    if (semMgrHead.sem == NULL)
    {
        SemMgrInit(&semMgrHead,"semMgr");
    }
}

static UINT32 SemMgrTake(T_SemMgrType *semMgr, UINT32 maxWait,const CHAR *taker)
{
    int snpRet = 0;
    SemMgrHeadInit();
    if (semMgr == NULL)
    {
        return BSP_ERROR;
    }

    if (semMgr->sem == NULL)
    {
        return BSP_ERROR;
    }

    semTake(semMgr->sem,(INT32)maxWait);
    semMgr->tickTake = tickGet();
    snpRet = snprintf_s(semMgr->taker,sizeof(semMgr->taker),"%s\0",taker);
    SNPRINTF_S_CHECK(snpRet, sizeof(semMgr->taker));
    return BSP_OK;
}

static UINT32 SemMgrGive(T_SemMgrType *semMgr)
{
    SemMgrHeadInit();
    if (semMgr == NULL)
    {
        return BSP_ERROR;
    }

    if (semMgr->sem == NULL)
    {
        return BSP_ERROR;
    }

    semGive(semMgr->sem);
    semMgr->tickGive = tickGet();
    memset(semMgr->taker,0,sizeof(semMgr->taker));
    return BSP_OK;
}

static T_SemMgrType *SemMgrGet(const char *owner)
{
    /* UINT32 loop; */
    T_SemMgrType *semMgr = &semMgrHead;
    T_SemMgrType *newSemMgr = NULL;
    
    if (SemMgrTake(&semMgrHead,WAIT_FOREVER,__FUNCTION__)!=BSP_OK)
    {
        return NULL;
    }

    while (semMgr->next)
    {
        if (0==strcmp(semMgr->next->owner,owner))
        {
            break;
        }
        semMgr = semMgr->next;
    }
    if (semMgr->next == NULL)
    {
        newSemMgr = (T_SemMgrType *)malloc(sizeof(T_SemMgrType));
        if (newSemMgr == NULL)
        {
            dbgInfo("%s malloc failed!\n", __FUNCTION__);
        }
        SemMgrInit(newSemMgr,owner);
        semMgr->next = newSemMgr;
    }

    SemMgrGive(&semMgrHead);
    return semMgr->next;
}

/*****************************************************************************
 *  函数名称   : BspSemMgrTake(*)
 *  功能描述   : 信号量获取
 *  输入参数   : owner - 信号量所有者,键值唯一,16Byte
              maxWait - 等待时间
              taker - 调用者
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 190699@2017-11-24, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSemMgrTake(const char *owner,UINT32 maxWait,const CHAR *taker)
{
    T_SemMgrType *semMgr = SemMgrGet(owner);
    return SemMgrTake(semMgr,maxWait,taker);
}

/*****************************************************************************
 *  函数名称   : BspSemMgrGive(*)
 *  功能描述   : 信号量释放
 *  输入参数   : owner - 信号量所有者,键值唯一,16Byte
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 190699@2017-11-24, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSemMgrGive(const char *owner)
{
    T_SemMgrType *semMgr = SemMgrGet(owner);
    return SemMgrGive(semMgr);
}

#ifdef BUILD_WITH_OM_FUNC
VOID semmgr()
{
    T_SemMgrType *pSemMgr = &semMgrHead;

    dbgInfo("%-16s %-32s %-20s %s\n","owner","taker","tick","sem");
    do
    {
        dbgInfo("%-16s %-32s %-9d->%9d %p\n",pSemMgr->owner,pSemMgr->taker,
            pSemMgr->tickTake,pSemMgr->tickGive,pSemMgr->sem);
        pSemMgr = pSemMgr->next;
    } while (pSemMgr);
}
#endif

VOID BspResetDeviceCallBackInit(FUNC_RESET_DEV pReset)
{
    pResetDevice = pReset;
}

/* 注册添加mcs静态arp的函数 zhengtong 20180417 */
VOID BspSetNetCfgCallBackInit(pSetNetCfg pCfg)
{
    pfSetNetCfg = pCfg;
}

/* 不屏蔽，允许复位 */
static UINT32 BspBoardResetEnable(VOID)
{
    BspBoardResetFlag = 0;
    return BspBoardResetFlag;
}
/* 屏蔽复位 */
VOID BspBoardResetDisable(VOID)
{
    BspBoardResetFlag = 1;
    return ;
}
static UINT32 BspBoardResetEnableShow(VOID)
{
    printf_s("Now: BoardReset Is%s\n", (0 == BspBoardResetFlag)?"Enable":"Disable");
    return BSP_OK;
}
UINT32 BspGetBoardReset(VOID)
{
    return BspBoardResetFlag;
}

VOID BspBoardReset(VOID)
{
    CHAR devNameStr[] = "Board0";
    if(1 == BspGetBoardReset())/* ==1代表屏蔽掉复位 */
    {
        dbgInfo("BspBoardReset: Rest is NOT Allowed!\n");
        return;
    }
    UINT32 cause = BSP_APP_SOFT_RESET;
    BspResetDevice((uintptr_t)devNameStr, BSP_RESET_TYPE_SOFT, cause);
}

/* Started by AICoder, pid:y7eab0dbd0jcb0914f80094ea06d36112cd9c7d7 */
UINT32 BspInitRruFileInfoBomidCheck(VOID)
{
    CHAR* bomidCheckIsExist = BspGetBomidCheckIsExist();
    if(NULL == bomidCheckIsExist)
    {
        dbgErr("%s>>NULL pointer!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if((0 == strncmp("SUPPORT",bomidCheckIsExist,7)) //通过rruinfo.txt中的BomidCheck字段判断整机是否支持“Bomid严格匹配方案”
        && (1 == BspGetHwGroupIdWarn()))                  //为1时，表明bomid未严格匹配
    {
        dbgInfo("%s >> BOMID didn't match exactly! Board Reset!\n", __FUNCTION__);
        //BspBoardReset();
        return BSP_OK;
    }
    return  BSP_OK;
}
/* Ended by AICoder, pid:y7eab0dbd0jcb0914f80094ea06d36112cd9c7d7 */

UINT32 BspResetDevice(OSS_ULONG devId, UINT32 resetType, UINT32 cause)
{
    fpgaloadLog(LOAD_INFO,"[%s] pResetDevice:%p flag:%d resetType:%d cause:%d\n", 
        __FUNCTION__, pResetDevice, BspGetBoardReset(), resetType, cause);
    if (pResetDevice)
    {
        if(1 == BspGetBoardReset())/* ==1代表屏蔽掉复位 */
        {
            dbgInfo("BspBoardReset: Rest is NOT Allowed!\n");
            return BSP_OK;
        }
        return pResetDevice(devId,resetType,cause);//BspDevReset->BspResetFpga
    }

    dbgErr("device(devId:%ld) reset callback NOT registered!\n", devId);
    return BSP_ERROR;
}

UINT32 BspSetResetTypeCause(UINT32 resetType, UINT32 cause)
{
	gsResetType = resetType;
	gsResetCause = cause;
    return BSP_OK;
}

UINT32 BspGetResetTypeCause(UINT32 *pResetType, UINT32 *pCause)
{
	*pResetType = gsResetType;
	*pCause = gsResetCause;
    return BSP_OK;
}


VOID BspDpdVswrTblStateCallBackInit(FUNC_DPDVSWR_TBL_STATE pDpdVswrTbl)
{
    pDpdVswrTblState = pDpdVswrTbl;

}
UINT32 BspGetDpdVswrTblState(UINT32 ulSubIndex, UINT32 ulChan)
{
    if (pDpdVswrTblState)
    {
        return pDpdVswrTblState(ulSubIndex,ulChan);
    }

    dbgErr("dpdVswr %d reset callback NOT registered!\n", ulChan);
    return BSP_ERROR;
}

VOID BspSignalHandleRegister(SIG_HNDL pHndl)
{
    pSigHndl = pHndl;
}

UINT32 BspSigtermHandle()
{
    if (pSigHndl)
    {
        pSigHndl(SIGTERM,NULL,NULL);
    }
    return BSP_OK;
}

UINT32 BspGetCarrierNum(VOID)
{
    return min(maxCarrierNum, BSP_MAX_CARR_NUM);
}

UINT32 BspSetCarrierNum(UINT32 carrNum)
{
    maxCarrierNum = carrNum;
    return BSP_OK;
}

/*设置子端的载波能力*/
UINT32 BspSetSlaveCarrierNum(UINT32 carrNum)
{
    maxSlaveCarrierNum = carrNum;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspSetRruWorkMode(*)
 * 功能描述: 设置RRU工作模式
 * 输入参数: rruWorkMode       WFS_NO_TEST_MODE/WFS_TEST_MODE
             
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/

UINT32 BspSetRruWorkMode(UINT32 rruWorkMode)
{
    s_rruWorkMode = rruWorkMode;
    return BSP_OK;

}
/**************************************************************************
 * 函数名称: BspGetRruWorkMode(*)
 * 功能描述: 设置RRU工作模式
 * 输入参数: rruWorkMode       WFS_NO_TEST_MODE/WFS_TEST_MODE
             
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/

UINT32 BspGetRruWorkMode(VOID)
{
    return s_rruWorkMode;
}

/**************************************************************************
* 函数名称：UINT32 BspSetNetInfo(VOID)
* 功能描述：提供给OSS的接口，用来添加mcs的静态arp
* 输入参数：
* 输出参数： 无
* 返   回  值： BSP_OK           成功
* 适用范围： BSP
* -----------------------------------------------------------------------
* 修改日期         版本号         修改人        修改内容
* 20180412      v1.0       zhengtong    create
**************************************************************************/
UINT32 BspSetNetInfo(VOID)
{
     if(NULL != pfSetNetCfg)
     {
		 pfSetNetCfg();
     }

	 return BSP_OK;
}

UINT32 BspSetClkInitStatus(UINT32 ulStat)
{
    s_clkInitStat = ulStat;
    return BSP_OK;
}
UINT32 BspGetClkInitStatus(VOID)
{
    return s_clkInitStat;
}
UINT32 BspCheckSocInitStatus(UINT32 ulCmd)
{
    //static UINT32 ulSocRstFlag = 0;
    UINT32 ulRet = 0;
 #if 0   
    //检查cmd命令
    if(ulCmd ==0xaabb)
    {
        ulRet = BspGetClkInitStatus();
    }
#else
    ulRet = BspGetClkInitStatus();
#endif
    return ulRet;
}
#if 0
static T_RadioPara s_RadioPara = {NULL};

UINT32 BspInitRadioPara(T_RadioPara *para)
{
    INPUT_POINTER_CHECK(para);
    memcpy(&s_RadioPara,para,sizeof(T_RadioPara));
    

    return BSP_OK;
}
 
/**************************************************************************
 * 函数名称: BspGetRadioCfgMode
 * 功能描述: 区分4G/5G制式的回调函数，
 
 * 输入参数:
 
 * 输出参数: 射频制式 mode： 0/1/2 分别表示5G/4G/混模。
             若规格下没有BspRadioModeInit，则.pGetRadionMode不会回调函数BspGetRadioCfg，此时s_RadioPara.pGetRadionMode==NULL，默认为5G
             若规格下有BspRadioModeInit，则根据实际情况返回：（1）若没有离线文件，返回5G，（2）若有离线文件，根据离线文件内容返回。

 
 * 返 回 值:
 *           其它   执行失败
 * 其它说明: 测试使用
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/

UINT32 BspGetRadioCfgMode(UINT32 *mode)
{
    UINT32 u32RadioMode = 0;
    INPUT_POINTER_CHECK(mode);
    if (s_RadioPara.pGetRadionMode!=NULL)
	{
	   u32RadioMode=s_RadioPara.pGetRadionMode();
	}
	else
	{
	    u32RadioMode = 0;//返回5G制式
	}
	*mode = u32RadioMode;
    return BSP_OK;
}

UINT32 testBspGetRadioCfgMode(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 u32RadioMode = 0;
    retVal =  BspGetRadioCfgMode(&u32RadioMode);
    dbgInfo("RadioMode is %d\n",u32RadioMode);  
    return retVal;
}

VOID radiomode(VOID)
{
    UINT32 ulRadioMode = 0;
    UINT32 ulTmpRet = BSP_OK;

    ulTmpRet = BspGetRadioCfgMode(&ulRadioMode);

    dbgInfo("%s>>RadioCfgMode Get %s! RadioMode(%d:5G %d:4G %d:4&5G)= %d\n", __FUNCTION__,
           (BSP_OK == ulTmpRet) ? "Succ" : "Error", RADIO_5G, RADIO_4G, RADIO_4G_5G, ulRadioMode);
}
#endif

VOID SetSwitchFpgaEnableFlag(UINT32 flag)
{
    switchFpgaEnable = flag;
}

void BspSetSwitchFpgaEnableFlag(UINT32 flag)
{
    SetSwitchFpgaEnableFlag(flag);
}

UINT32 BspSwitchFpgaVersion(VOID)
{
	if ((switchFpgaEnable & 0xff) == 0x5a)
	{
        dbgInfo("%s swflag:%#x!\n", __FUNCTION__, switchFpgaEnable);
		return ((switchFpgaEnable >> 8) & 0xff) ? BSP_ERROR : BSP_OK;
	}
	if (pSwitchFpga)
	{
        dbgInfo("%s switch fpga!\n", __FUNCTION__);
		return pSwitchFpga();
	}
	return BSP_ERROR;
}

VOID BspSwitchFpgaCallBackInit(FUNC_SWITCH_FPGA pSwitch)
{
	pSwitchFpga = pSwitch;
}

/*ata目录下打桩桩文件后，rru发生异常后不自救 */
BOOL BspRruNoNeedSelfRescue(VOID)
{
    const char *filename = "/ata/DebugStub/noselfrescue";
    if (BspIsFileExist(filename) == BSP_OK)
    {
        return TRUE;
    }
    return FALSE;
}

UINT32 BspGetCpuVersion(UINT8 *pVer,UINT32 size)
{
	char *buf = NULL;
	UINT32 len = min(size, VERNO_LEN);
	INPUT_POINTER_CHECK(pVer);
	buf = (char *)(BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP) + 0x5030);
	strncpy_s((char *)pVer,size,buf,len-1);
	//dbgInfo("pVer = %s\n", pVer);
	return BSP_OK;
}

UINT32 BspGetSwVerHead(const char *pVerFile, T_VerFileHeader *pVerHead)
{
    INT32 rdSize = 0;
    /* UINT32 retVal = BSP_OK; */
    FILE  *fp = NULL;

    INPUT_POINTER_CHECK(pVerFile);
    INPUT_POINTER_CHECK(pVerHead);

    memset(pVerHead, 0, sizeof(T_VerFileHeader));

    if (NULL == (fp = fopen(pVerFile, "rb")))
    {
         return BSP_ERROR;
    }

    rdSize = fread(pVerHead, 1, sizeof(T_VerFileHeader), fp);
    if (rdSize != sizeof(T_VerFileHeader))
    {
        (void)fclose(fp);
        return BSP_ERROR;
    }
    (void)fclose(fp);

    pVerHead->ulCompressedCRC  = ntohl(pVerHead->ulCompressedCRC);
    pVerHead->ulCompressedSize = ntohl(pVerHead->ulCompressedSize);
    pVerHead->ulCRC32          = ntohl(pVerHead->ulCRC32);
    pVerHead->ulCreateTime     = ntohl(pVerHead->ulCreateTime);
    pVerHead->ulHeaderVersion  = ntohl(pVerHead->ulHeaderVersion);
    pVerHead->ulOriginalCRC    = ntohl(pVerHead->ulOriginalCRC);
    pVerHead->ulOriginalSize   = ntohl(pVerHead->ulOriginalSize);
    pVerHead->ulSoftType       = ntohl(pVerHead->ulSoftType);
    pVerHead->usVerType        = ntohs(pVerHead->usVerType);

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspPowonStrategyRegister(*)
 * 功能描述: 设置上电策略挂接函数
 * 输入参数:

 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/

VOID BspPowonStrategyRegister(FUNC_PowOn_Strategy pFunc)
{
	pPowOnStrategy = pFunc;
}
/**************************************************************************
 * 函数名称: BspGetPowonStrategy(*)
 * 功能描述: 获取上电策略
 * 输入参数:

 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/

UINT32 BspGetPowonStrategy()
{
    if (pPowOnStrategy)
    {
    	return pPowOnStrategy();
    }
    return NULL_STRATEGY;
}
/**************************************************************************
 * 函数名称: BspPowonStrategyRegister(*)
 * 功能描述: 设置上电策略挂接函数
 * 输入参数:

 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/

VOID BspProcessStrategyRegister(FUNC_Process_Sta pFuncSta,FUNC_Process_Strategy pFunc)
{
	pProcessSta 		= pFuncSta;
	pProcessStrategy    = pFunc;
}
/**************************************************************************
 * 函数名称: BspGetProcessStrategy(*)
 * 功能描述: 获取超时处理策略
 * 输入参数:

 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/

UINT32 BspGetProcessStrategy(UINT32 socMap,UINT32 socNum,UINT32 *delaTime,UINT32 *pOutSocStrategy)
{
	UINT32 strategy[BSP_SOC_MAX_NUM] = {NULL_STRATEGY,NULL_STRATEGY,NULL_STRATEGY,NULL_STRATEGY,NULL_STRATEGY,NULL_STRATEGY,NULL_STRATEGY,NULL_STRATEGY};
	UINT32 socMin  = 0;
	INPUT_POINTER_CHECK(pOutSocStrategy);
	INPUT_POINTER_CHECK(delaTime);

    if (pProcessSta)
    {
    	return pProcessSta(socMap,socNum,delaTime,pOutSocStrategy);
    }
    socMin = min(BSP_SOC_MAX_NUM,socNum);
    memcpy(pOutSocStrategy,&strategy[0],socMin*sizeof(strategy[0]));
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspProcessStategy(*)
 * 功能描述: 进行处理策略运行
 * 输入参数:

 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年11月15日 10105163          创建
 **************************************************************************/

UINT32 BspProcessStategy(UINT32 rpuId)
{
    if (pProcessStrategy)
    {
    	return pProcessStrategy(rpuId);
    }
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetBoardOptProtocolType
 * 功能描述: 获取单板的光口协议类型
 
 * 输入参数:
 
 * 输出参数:

 * 返 回 值:
 *           E_BOARD_OPT_PRO_TYPE_CPRI 光口协议类型为CPRI
			 E_BOARD_OPT_PRO_TYPE_ECPRI 光口协议类型为ECPRI
			 E_BOARD_OPT_PRO_TYPE_CPRI_ECPRI 光口协议类型为CPRI+ECPRI
			 E_BOARD_OPT_PRO_TYPE_UNKNOWN 光口协议类型未知
 
 * 其它说明: 高层记录系统LOG时调用
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
static E_BoardOptProType g_eBoardOptProType = E_BOARD_OPT_PRO_TYPE_UNKNOWN;
E_BoardOptProType BspGetBoardOptProtocolType(VOID)
{
    return g_eBoardOptProType;
}

/**************************************************************************
 * 函数名称: BspSetBoardOptProtocolType
 * 功能描述: 设置单板的光口协议类型
 
 * 输入参数: optProType 值定义如下
             E_BOARD_OPT_PRO_TYPE_CPRI 光口协议类型为CPRI
			 E_BOARD_OPT_PRO_TYPE_ECPRI 光口协议类型为ECPRI
			 E_BOARD_OPT_PRO_TYPE_CPRI_ECPRI 光口协议类型为CPRI+ECPRI
			 E_BOARD_OPT_PRO_TYPE_UNKNOWN 光口协议类型未知
 
 * 输出参数:

 * 返 回 值:
 
 
 * 其它说明: 高层记录系统LOG时调用
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
VOID BspSetBoardOptProtocolType(E_BoardOptProType optProType)
{
    g_eBoardOptProType = optProType;
}

/**************************************************************************
 * 函数名称: BspGetOptProType
 * 功能描述: 获取光口协议类型
 
 * 输入参数:
 
 * 输出参数:

 * 返 回 值:
 *           E_OPT_PRO_TYPE_CPRI 光口协议类型为CPRI
			 E_OPT_PRO_TYPE_ECPRI 光口协议类型为ECPRI
			 E_OPT_PRO_TYPE_CPRI_ECPRI 光口协议类型为CPRI+ECPRI
			 E_OPT_PRO_TYPE_UNKNOWN 光口协议类型未知
 
 * 其它说明: 高层记录系统LOG时调用
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
static E_BoardOptProType g_aeOptProType[MAX_OPT_NUM_FOR_PRO] = {0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff};
E_BoardOptProType BspGetOptProType(UINT32 optIndex)
{
    if (optIndex >= MAX_OPT_NUM_FOR_PRO)
    {
	    return E_OPT_PRO_TYPE_UNKNOWN;
    }
    return g_aeOptProType[optIndex];
}

/**************************************************************************
 * 函数名称: BspSetOptProType
 * 功能描述: 设置光口协议类型
 
 * 输入参数: optProType 值定义如下
             E_OPT_PRO_TYPE_CPRI 光口协议类型为CPRI
			 E_OPT_PRO_TYPE_ECPRI 光口协议类型为ECPRI
			 E_OPT_PRO_TYPE_CPRI_ECPRI 光口协议类型为CPRI+ECPRI
			 E_OPT_PRO_TYPE_UNKNOWN 光口协议类型未知
 
 * 输出参数:

 * 返 回 值:
 
 
 * 其它说明: 高层记录系统LOG时调用
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
UINT32 BspSetOptProType(E_BoardOptProType optProType, UINT32 optIndex)
{
    if (optIndex >= MAX_OPT_NUM_FOR_PRO)
    {
        return BSP_ERROR;
    }
    g_aeOptProType[optIndex] = optProType;
    return BSP_OK;
}

VOID BspCheckFpgaStautsRegister(FUNC_CheckFpgaStatus pFunc,UINT32 *fpgaIndex,UINT32 fpgaNum)
{
    UINT32 loop = 0;

    if((NULL == fpgaIndex) || (fpgaNum > NELEMENTS(s_checkFpgaIndex)))
    {
        return ;
    }

    pCheckFpgaStatus = pFunc;
    for (loop = 0; loop < fpgaNum; loop++)
    {
        s_checkFpgaIndex[loop] = fpgaIndex[loop];
    }
    s_checkFpgaNum = fpgaNum;
}

UINT32 BspCheckFpgaStatus(UINT32 *status,UINT8 *strInfo,UINT32 strLen)
{
    UINT32 retVal;
    UINT32 loop;
    UINT32 strInfoSize;
    UINT32 num;
    
    if (status == NULL || strInfo == NULL || strLen < 2)
    {
        //dbgInfoEx("%s para error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    memset(strInfo,0,strLen);
    *status = 0;
    if (pCheckFpgaStatus == NULL)
    {
        //dbgInfoEx("%s no register pCheckFpgaStatus\n",__FUNCTION__);
        return BSP_OK;
    }

    strInfoSize = strLen - 1;
    num = min(s_checkFpgaNum, NELEMENTS(s_checkFpgaIndex));
    for (loop = 0; loop < num; loop++)
    {
        retVal = pCheckFpgaStatus(s_checkFpgaIndex[loop]);
        if (retVal != BSP_OK)
        {
            *status = 1;
            (void)snprintf_s((char *)strInfo,strInfoSize-strlen((const char *)strInfo),"%d:%d;",s_checkFpgaIndex[loop],retVal);
        }
    }

    //dbgInfoEx("%s status=%d strLen=%d strInfo=%s\n",__FUNCTION__,*status,strLen,strInfo);
    return BSP_OK;
}

/* 此接口是由于MCS加载ceva失败提供上层的适配接口,仅打桩 */
UINT32 BspChkCevaVersionStatus(VOID)
{
    return BSP_OK;
}


UINT32 BspInitEcpriUdpPortInfo(T_EcpriUdpPortInfo *pInfo)
{
    size_t len = sizeof(s_ecpriUdpPortInfo.portDir);
    char *pDst = NULL;
    char *pSrc = NULL;
    if (pInfo == NULL)
    {
        return BSP_ERROR;
    }

    pDst = s_ecpriUdpPortInfo.portDir;
    pSrc = pInfo->portDir;
    strncpy_s(pDst,len,pSrc,len);
    s_ecpriUdpPortInfo.portDir[len-1] = '\0';
    s_ecpriUdpPortInfo.pFuncEcpriPortCfg = pInfo->pFuncEcpriPortCfg;
    s_ecpriUdpPortInfo.pFuncRoePortCfg = pInfo->pFuncRoePortCfg;
    s_ecpriUdpPortInfo.pFuncDefPortCfg = pInfo->pFuncDefPortCfg;
    s_ecpriUdpPortInfo.init = 1;
    return BSP_OK;
}

static UINT32 SetEcpriUdpPortToFile(char *pFile,UINT32 ecpriPort,UINT32 roePort)
{
    T_EcpriUdpPort eUdpPort = {0};
    FILE *fp = NULL;

    fp = fopen(pFile,"w+");
    if (fp == NULL)
    {
        return BSP_ERROR;
    }

    eUdpPort.ecpriPort = htonl(ecpriPort);
    eUdpPort.roePort   = htonl(roePort);
    if (sizeof(T_EcpriUdpPort) != fwrite(&eUdpPort,1,sizeof(T_EcpriUdpPort),fp))
    {
        (void)fclose(fp);
        return BSP_ERROR;
    }

    (void)fclose(fp);
    return BSP_OK;
}

UINT32 BspSetEcpriUdpPort(UINT32 ecpriPort,UINT32 roePort)
{
    UINT32 ecpriPortTmp = 0;
    UINT32 roePortTmp = 0;
    UINT32 retVal = 0;
    UINT32 chgFlag = 0;
    char   *pFile = NULL;

    ECPRI_UDP_PORT_INIT_CHK();

    pFile = s_ecpriUdpPortInfo.portDir;
    if (BSP_OK == BspIsFileExist(pFile))
    {
        if (BSP_OK != BspGetEcpriUdpPort(&ecpriPortTmp,&roePortTmp))
        {
            return BSP_ERROR;
        }
    }

    if (s_ecpriUdpPortInfo.pFuncEcpriPortCfg && ecpriPort != ecpriPortTmp)
    {
        s_ecpriUdpPortInfo.pFuncEcpriPortCfg(ecpriPort);
        chgFlag |= (1 << 0);
    }

    if (s_ecpriUdpPortInfo.pFuncRoePortCfg && roePort != roePortTmp)
    {
        s_ecpriUdpPortInfo.pFuncRoePortCfg(roePort);
        chgFlag |= (1 << 1);
    }

    if (chgFlag == 0) /* no change */
    {
        return BSP_OK;
    }

    retVal = SetEcpriUdpPortToFile(s_ecpriUdpPortInfo.portDir, ecpriPort, roePort);
    return retVal;
}

UINT32 BspSetEcpriUdpPortDefault()
{
    UINT32 retVal = 0;
    char *pFile = NULL;
    ECPRI_UDP_PORT_INIT_CHK();
    if (s_ecpriUdpPortInfo.pFuncDefPortCfg)
    {
        retVal = s_ecpriUdpPortInfo.pFuncDefPortCfg();
        if (retVal == BSP_OK) /* 配置默认值时删除UDP配置文件 */
        {
            pFile = s_ecpriUdpPortInfo.portDir;
            (void)BspDeleteFile(pFile);
        }
    }
    return retVal;
}

UINT32 BspGetEcpriUdpPort(UINT32 *ecpriPort,UINT32 *roePort)
{
    /* UINT32 retVal = BSP_OK; */
    T_EcpriUdpPort eUdpPort = {0};
    FILE *fp = NULL;

    INPUT_POINTER_CHECK(ecpriPort);
    INPUT_POINTER_CHECK(roePort);
    ECPRI_UDP_PORT_INIT_CHK();

    fp = fopen(s_ecpriUdpPortInfo.portDir,"r");
    if (fp == NULL)
    {
        return BSP_ERROR;
    }

    if (sizeof(T_EcpriUdpPort) != fread(&eUdpPort,1,sizeof(T_EcpriUdpPort),fp))
    {
        (void)fclose(fp);
        return BSP_ERROR;
    }

    *ecpriPort = ntohl(eUdpPort.ecpriPort);
    *roePort   = ntohl(eUdpPort.roePort);

    (void)fclose(fp);
    return BSP_OK;
}

FUNC_SET_NTF_RSSI_SWITCH pFunSetNtfRssiSw = NULL;
VOID BspSetNtfRssiSwitchCallInit(FUNC_SET_NTF_RSSI_SWITCH pFunTmp)
{
    pFunSetNtfRssiSw = pFunTmp;
}

UINT32 BspSetNtfRssiSwitch(UINT32 sw)
{
    UINT32 ret = BSP_OK;
    if (pFunSetNtfRssiSw != NULL)
    {
        ret = pFunSetNtfRssiSw(sw);
        dbgInfo("rssi Switch = %d.\n", sw);
    }
    dbgInfo("rssi Switch call is null,sw = %d.\n", sw);
    return ret;
}
/*硬件异常跳过NTF自检过程*/
static UINT32 s_NtfAvoidFlag = 0;
UINT32 BspSetNtfAvoidFlag(UINT32 ntfAvoidFlag)
{
    s_NtfAvoidFlag = ntfAvoidFlag;

    return BSP_OK;
}

UINT32 BspGetNtfAvoidFlag(VOID)
{
    return s_NtfAvoidFlag;
}

UINT32 BspSetBdFuncSetPtr(FUNC_FunSet_Ptr pFunc)
{
    pFuncSetPtr = pFunc;
    return BSP_OK;
}
UINT32 BspGetBdFuncSetPtr(VOID)
{
    if(NULL!= pFuncSetPtr)
    {
         return pFuncSetPtr();
    }
    return BSP_OK;/*funcset 是否有 0?*/
}
UINT32 BspGetCfgLoopNum(VOID)
{
    return min(maxCfgLoopNum, maxCarrierNum);
}

UINT32 BspSetCfgLoopNum(UINT32 cfgLoopNum)
{
    maxCfgLoopNum = cfgLoopNum;
    return BSP_OK;
}

UINT32 BspClearLogFiles(VOID)
{
    BspSystem("rm /bsplog.txt");
    BspSystem("rm /bsplog.init");
    BspSystem("rm /ata/powerinfo.txt");
    BspSystem("rm -rf /ata/.bspcfg");
    BspSystem("rm -rf /ata/.log/bsp");
    BspSystem("rm -rf /ata/audit");
    BspSystem("rm -rf /ata/security");
    BspDeleteFile(OPT_SPEED_CONF_FILE);
    BspDeleteFile(OPT_TOPOLOGY_CONF_FILE);
    dbgInfo("BspClearLogFiles: clear bsplog.txt and bsplog.init and powerinfo.txt and ata/.bspcfg and ata/.log/bsp and %s and %s\n", OPT_SPEED_CONF_FILE, OPT_TOPOLOGY_CONF_FILE);
    return BSP_OK;
}

static UINT32 PowerOnRecord_ntohl(T_PowerOnRecord *pData)
{
    uint32_t tmpData = 0;
	if (pData == NULL)
	{
		return BSP_ERROR;
	}
    tmpData = pData->rstCount;
	pData->rstCount = ntohl(tmpData);
	return BSP_OK;
}

static UINT32 PowerOnRecord_htonl(T_PowerOnRecord *pData)
{
    uint32_t tmpData = 0;
	if (pData == NULL)
	{
		return BSP_ERROR;
	}

    tmpData = pData->rstCount;
	pData->rstCount = htonl(tmpData);
	return BSP_OK;
}

UINT32 BspInitPowerOnRecord(CHAR *fileName)
{
#define PWR_ON_KW_COV(a) if ((a) != 0)  dbgInfo("%s,%d:ret=%d\n",__FUNCTION__,__LINE__,(a)) 
    int fret = 0;
	FILE *fp = NULL;
	T_PowerOnRecord data = {0};
    INPUT_POINTER_CHECK(fileName);

	fret = fopen_s(&fp,fileName,"r+");
    PWR_ON_KW_COV(fret);
	if (fp != NULL)
	{
		if (sizeof(T_PowerOnRecord) != fread(&data, 1, sizeof(T_PowerOnRecord), fp))
		{
			dbgErr("%s fread error\n",__FUNCTION__);
		}
        fret = fseek(fp, 0, SEEK_SET);
        PWR_ON_KW_COV(fret);
		PowerOnRecord_ntohl(&data);
		dbgInfo("%s read data.rstCount=%d\n",__FUNCTION__,data.rstCount);
	}
    else
    {
        fret = fopen_s(&fp,fileName,"w+");
        PWR_ON_KW_COV(fret);
        if (fp == NULL)
        {
            dbgErr("%s fopen error\n",__FUNCTION__);
            return BSP_ERROR;
        }
    }
    
    data.rstCount++;
	memcpy_s(&powerOnRecordInfo.record, sizeof(T_PowerOnRecord), &data, sizeof(T_PowerOnRecord));
	strncpy_s(powerOnRecordInfo.fileName, sizeof(powerOnRecordInfo.fileName), fileName, strnlen_s(fileName,64));
	
	PowerOnRecord_htonl(&data);
	if (sizeof(T_PowerOnRecord) != fwrite(&data, 1, sizeof(T_PowerOnRecord), fp))
	{
		fret = fclose(fp);
        PWR_ON_KW_COV(fret);
		dbgErr("%s fwrite error\n",__FUNCTION__);
		return BSP_ERROR;
	}
	fret = fclose(fp);
    PWR_ON_KW_COV(fret);
    
	powerOnRecordInfo.init = 1;
	return BSP_OK;
}

UINT32 BspGetPowerOnCount(VOID)
{
	if (powerOnRecordInfo.init != 1)
	{
		return 0;
	}
	return powerOnRecordInfo.record.rstCount;
}

// GpioPinRdWrMode = BSP_PIN_REG_RDWR_MODE
UINT32 BspSetGpioPinRdWrMode(UINT32 ulRdWrMode)
{
    s_ulBspGpioRegRdWrMode = ulRdWrMode;
    return BSP_OK;
}

UINT32 BspGetGpioPinRdWrMode(VOID)
{
    return s_ulBspGpioRegRdWrMode;
}
UINT32 BspGetStartTimeSec(VOID)
{
    UINT32 startTime = 0;

    startTime = tickGet()/100 + 60;
    return startTime;
}

/**
 * is support switch atg frame structure(20ms, not 20ms)
 * s_atgMultiFrameFlag: 1-support, 0-not support
*/
UINT32 BspSetAtgMultiFrameFlag(UINT32 flag)
{
    s_atgMultiFrameFlag = (flag == TRUE) ? TRUE : FALSE;
    return BSP_OK;
}

UINT32 BspIsSupportAtgMultiFrame(void)
{
    return (s_atgMultiFrameFlag == TRUE) ? TRUE : FALSE;
}

/**
 * get frame structure, default return BSP_ERROR
 * 1: 20ms, other:not 20ms
*/
UINT32 BspSetFrameStruc(UINT32 value)
{
    s_frameStruc = value;
    return BSP_OK;
}

UINT32 BspGetFrameStruc(void)
{
    return s_frameStruc;
}

/* IC切逻辑IF1机型增加时延传递Set函数 */
UINT32 BspSetOptIf1taDelay(UINT32 taDelay)
{
    s_optIf1taDelay = taDelay;
    return BSP_OK;
}
/* IC切逻辑IF1机型增加时延传递Get函数 */
UINT32 BspGetOptIf1taDelay(void)
{
    return s_optIf1taDelay;
}

/* IC切逻辑IF1机型增加光纤时延传递Set函数 */
UINT32 BspSetOptIf1hwLinkDelay(UINT32 hwLinkDelay)
{
    s_optIf1hwLinkDelay = hwLinkDelay;
    return BSP_OK;
}
/* IC切逻辑IF1机型增加光纤时延传递Get函数 */
UINT32 BspGetOptIf1hwLinkDelay(void)
{
    return s_optIf1hwLinkDelay;
}

UINT32 BspGetVirtualCarrNoOffsetPara(UINT32 *offset, UINT32 *mod)
{
    *offset =  g_VirtualCarrNoOffset;
    *mod    =  g_VirtualCarrNoMod;
    return BSP_OK;
}

UINT32 BspSetVirtualCarrNoOffsetPara(UINT32 offset, UINT32 mod)
{
    if (0 == mod || 1 == mod)
    {
        dbgErr("[%s] Error! The divisor cannot be 0 or 1！\n",__FUNCTION__);
        return BSP_ERROR;
    }
    g_VirtualCarrNoMod    = mod;
    g_VirtualCarrNoOffset = offset;
    return BSP_OK;
}

UINT32 BspCarrBwIsTwoSegAntiInterf(UINT32 carrMode, UINT32 carrBw)
{
    if(BSP_RADIO_STANDARD_FDD_5G != carrMode)
    {
        dbgInfoEx("[%s],carrMode = %d, Only support radio mode is NR!",__FUNCTION__, carrMode);
        return BSP_ERROR;
    }

    switch (carrBw)
    {
        case BANDWIDTH_14P4M:
        case BANDWIDTH_14P04M:
        case BANDWIDTH_7P92M:
        case BANDWIDTH_6P12M:
        {
            return BSP_OK;
            break;
        }
        default:
        {
            break;
        }
    }
    dbgInfoEx("[%s],This carrBw = %d cannot support in two-segment anti-interference!\n", __FUNCTION__, carrBw);

    return BSP_ERROR;
}

UINT32 BspCarrBwIsOneSegAntiInterf(UINT32 carrMode, UINT32 carrBw)
{
    if(BSP_RADIO_STANDARD_FDD_5G != carrMode)
    {
        dbgInfoEx("[%s],Only support radio mode is NR!",__FUNCTION__);
        return BSP_ERROR;
    }
    switch (carrBw)
    {
        case BANDWIDTH_22P32M:
        case BANDWIDTH_15P84M:
        case BANDWIDTH_14P4M:
        case BANDWIDTH_7P92M:
        case BANDWIDTH_6P12M:
            return BSP_OK;
            break;
        default:
            break;
    }
    dbgInfoEx("[%s],This carrBw = %d cannot support in one-segment anti-interference!\n",__FUNCTION__, carrBw);

    return BSP_ERROR;
}

VOID BspSetInnerSerdesStatus(UINT32 status)
{
    s_innerSedesSta = status;
    return ;
}

UINT32 BspGetInnerSerdesStatus(VOID)
{
    return s_innerSedesSta;
}

/*设置 4.2 serdes片间自救的状态 这个接口只记录每次循环的状态 要给高层上报还是得依赖于计数*/
VOID BspSetInnerSerdesSelfSaveCnt(UINT32 status)
{
    if(BSP_OK != status)
    {
        s_innerSedesSelfSaveCnt++;
    }
    return;
}

/*给高层上报当前上下联口 自救计数（用于判断正常 自救中 自救失败 自救成功）*/
UINT32 BspGetInnerSerdesSelfSaveStatus(VOID)
{
    return s_innerSedesSelfSaveCnt;
}
/*软件规避电调离线参数写错,不涉及D42机型,APP为平台调用故定义为空接口*/
UINT32 BspAisgGetAntFreq(UINT16 *pAntFreq)
{
    return BSP_OK;
}

/*深休下整机连接AISG情况下不断AISG供电：D42打桩*/
UINT32 BspSetAisgLinkStatus(UINT32 sw)
{
   return BSP_OK;
}

UINT32 BspGetAisgLinkStatus(VOID)
{
    return BSP_OK;
}

UINT32 BspAisgGetAntBeam(UINT16 *pbeamwidth)
{
    return BSP_OK;
}

UINT32 BspSetSlavePortSwitchCallBack(SET_SLAVEPORT_SWITCH pFuncCallback)
{
    pSetSlavePortSwitch = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSetRruAntAngleCfgCallBack(SET_RRUANGLE_CFG pFuncCallback)
{
    pSetRruAntAngleCfg = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSetSlavePortCbSwAndDspCfgCallBack(SET_SLAVEPORT_CBSW_DSP_CFG pFuncCallback)
{
    pSetSlavePortCbSwAndDspCfg = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSlavePortStatusCallBack(GETSET_SLAVEPORT_STATUS pFuncCallback)
{
    pSlavePortStatus = pFuncCallback;
    return BSP_OK;
}

UINT32 BspGetSlavePortDevNameCallBack(GET_SLAVEPORT_DEVNAME pFuncCallback)
{
    pGetSlavePortDevName = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSetSlavePortCfgCallBack(SET_SLAVEPORT_CFG pFuncCallback)
{
    pSetSlavePortCfg = pFuncCallback;
    return BSP_OK;
}

UINT32 BspGetAntInfoBySlavePortIdCallBack(GET_ANTINFO_BY_PORTID pFuncCallback)
{
    pGetAntInfoBySlavePortId = pFuncCallback;
    return BSP_OK;
}

UINT32 BspResetSlavePortCallBack(RESET_SLAVE_PORT pFuncCallback)
{
    pResetSlavePort = pFuncCallback;
    return BSP_OK;
}

UINT32 BspGetSlavePortTempVoltCallBack(GET_SLAVE_PORT_TEMPANDVOLT pFuncCallback)
{
    pGetSlavePortChanTempVolt = pFuncCallback;
    return BSP_OK;
}


/*子端切换*/
UINT32 BspSetSlavePortSwitch(UINT32 ulSwitch)
{
    if(NULL != pSetSlavePortSwitch)
    {
         return pSetSlavePortSwitch(ulSwitch);
    }
    return BSP_OK;
}

/*波束配置*/
UINT32 BspSetRruAntAngleCfg(UINT32 ulPortTpye, UINT32 ulPortId, UINT32 ulAntAngle)
{
    if(NULL != pSetRruAntAngleCfg)
    {
         return pSetRruAntAngleCfg(ulPortTpye, ulPortId, ulAntAngle);
    }
    return BSP_OK;
}

/*硬件信息 时间片下发*/
UINT32 BspSetSlavePortCbSwAndDspCfg(VOID)
{
    if(NULL != pSetSlavePortCbSwAndDspCfg)
    {
         return pSetSlavePortCbSwAndDspCfg();
    }
    return BSP_OK;
}

/*获取子端的端口建链状态*/
UINT32 BspGetSlavePortStatus(UINT32 ulPortId)
{
    if(NULL != pSlavePortStatus)
    {
         return pSlavePortStatus(ulPortId,0,0);
    }
    return BSP_ERROR;
}

/*获取子端的端口初始化状态*/
UINT32 BspGetSlavePortInitStatus(UINT32 ulPortId)
{
    if(NULL != pSlavePortStatus)
    {
         return pSlavePortStatus(ulPortId,0,1);
    }
    return BSP_OK;
}

/*清除子端的端口初始化状态*/
UINT32 BspClrSlavePortInitStatus(UINT32 ulPortId)
{
    if(NULL != pSlavePortStatus)
    {
         return pSlavePortStatus(ulPortId,1,1);
    }
    return BSP_OK;
}
/*获取子端机型型号*/
UINT32 BspGetSlavePortDevName(UCHAR *pRruName,UINT32 ulPortId)
{
    INPUT_POINTER_CHECK(pRruName);
    if(NULL != pGetSlavePortDevName)
    {
        if(ulPortId >= MAX_SLAVE_PORT_NUM)
        {
            return BSP_ERROR;
        }
        memcpy_s(pRruName, sizeof(g_SlavePortBaseInfo[ulPortId].rruName),g_SlavePortBaseInfo[ulPortId].rruName, sizeof(g_SlavePortBaseInfo[ulPortId].rruName));
        dbgInfoEx("ulPortId %d pRruName %s\n", ulPortId, pRruName);
    }
    return BSP_OK;
}

/*设置端口状态*/
UINT32 BspSetSlavePortCfg(UINT32 ulPortId, UINT32 ulPortType,UINT32 ulPortSta)
{
    if(NULL != pSetSlavePortCfg)
    {
         return pSetSlavePortCfg(ulPortId, ulPortType, ulPortSta);
    }
    return BSP_OK;
}

/*端口号转天线号*/
UINT32 BspGetAntInfoBySlavePortId(UINT32 ulPortId, T_RU_LINK_MAP_SLAVE *pAntInfo)
{
    INPUT_POINTER_CHECK(pAntInfo);
    if(NULL != pGetAntInfoBySlavePortId)
    {
         return pGetAntInfoBySlavePortId(ulPortId, pAntInfo);
    }
    return BSP_OK;
}

/*子端掉电复位*/
UINT32 BspSetRfsDevPwrOff(UINT32 rfsId)
{
    UINT32 retVal = BSP_OK;

    if(NULL != pResetSlavePort)
    {
        retVal = pResetSlavePort(rfsId, SWITCH_ON, 1);   /*这里1代表是掉电*/
        BspSysMsDelay(100);
        retVal |= pResetSlavePort(rfsId, SWITCH_OFF, 1);
    }
    return retVal;
}

/*节能时复位住所有子端*/
UINT32 BspSetRfsDevAllPwrOff(UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    for(loop = 0; loop < MAX_SLAVE_PORT_NUM; loop++)
    {
        if(NULL != pResetSlavePort)
        {
            retVal |= pResetSlavePort(loop, sw, 1);
        }
    }

    return retVal;
}

/*一拖三机型软复位子端*/
UINT32 BspSetRfsDevResetOff(UINT32 rfsId)
{
    UINT32 retVal = BSP_OK;

    if(NULL != pResetSlavePort)
    {
        retVal = pResetSlavePort(rfsId, SWITCH_ON, 0);   /*这里0代表是软复位*/
    }
    return retVal;
}

/*获取子端通道的各种温度和电压*/
UINT32 BspGetSlavePortTempVolt(UINT32 portId, T_SlavePortTempVolt *pData)
{
   UINT32 retVal = BSP_OK;

   INPUT_POINTER_CHECK(pData);
   if(NULL != pGetSlavePortChanTempVolt)
   {
        return pGetSlavePortChanTempVolt(portId, pData);
   }
   return retVal;
}

/*获取子端状态*/
UINT32 BspGetRfsDevStatus(UINT32 rfsId, UINT32 *pStatus)
{
    UINT32 tmpSta = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pStatus);
    tmpSta = BspGetSlavePortStatus(rfsId);
    if(BSP_OK != tmpSta)  /*和SE沟通 状态1-未探测 2-上电中  预留*/
    {
        *pStatus = 4;  /*断链*/
    }
    else
    {
        *pStatus = 3; /*正常*/
    }

    return retVal;
}

UINT32 BspSetSlavePortBaseInfo(UINT32 portId, T_SlavePortBaseInfo *pPara)
{
    if(portId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(NULL == pPara)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    memcpy_s(&g_SlavePortBaseInfo[portId], sizeof(T_SlavePortBaseInfo), pPara, sizeof(T_SlavePortBaseInfo));

    return BSP_OK;
}

UINT32 BspSaveSlavePortBaseInfo(UINT32 portId, UINT32 slaveChn, UINT32 type, VOID *pPara)
{
    if(portId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(slaveChn >= MAX_SLAVE_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    if(NULL == pPara)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    switch(type)
    {
        case E_SLAVE_RRUINFO:
        {
            memcpy_s(&s_SlavePortRruInfo[portId], sizeof(T_SlavePortRruInfo), pPara, sizeof(T_SlavePortRruInfo));
            break;
        }
        case E_SLAVE_PWRINFO:
        {
            memcpy_s(&s_SlavePortPwrInfo[portId], sizeof(T_SlavePortPwrInfo), pPara, sizeof(T_SlavePortPwrInfo));
            break;
        }
        case E_SLAVE_DFLINFO:
        {
            memcpy_s(&s_SlavePortDflInfo[portId][slaveChn], sizeof(T_SlavePortDflInfo), pPara, sizeof(T_SlavePortDflInfo));
            break;
        }
        case E_SLAVE_PAINFO:
        {
            memcpy_s(&s_SlavePortPaInfo[portId], sizeof(T_SlavePortPaInfo), pPara, sizeof(T_SlavePortPaInfo));
            break;
        }
        default:
        {
            break;
        }
    }
    return BSP_OK;
}

/*获取子端的cpu类型 要通过消息获取*/
UINT32 BspGetRfsDevCpuType(UINT32 rfsId, UINT8 *cpuType)
{
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(NULL == cpuType)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    if(1 != g_SlavePortBaseInfo[rfsId].linkSta)  /*1表示建链状态正常*/
    {
        return BSP_ERROR;
    }
    *cpuType = g_SlavePortBaseInfo[rfsId].cpuType;

    return BSP_OK;
}

/*获取子端的支持通道数 要通过消息获取*/
UINT32 BspGetRfsDevRfChanNum(UINT32 rfsId)
{
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(1 != g_SlavePortBaseInfo[rfsId].linkSta)/*1表示建链状态正常*/
    {
        return BSP_ERROR;
    }
    return g_SlavePortBaseInfo[rfsId].rfChanNum;
}

/*获取子端的支持载波数 按SE要求区分制式获取*/
UINT32 BspGetRfsDevCarrierNum(UINT32 rfsId)
{
    return maxSlaveCarrierNum;
}

/*获取子端的功放温度*/
UINT32 BspGetRfsDevPaTemp(UINT32 rfsId, UINT32 ulChan, INT32 *pTemp)
{
    T_SlavePortTempVolt tmpData = {0};
    UINT32 retVal = BSP_OK;

    retVal = BspGetSlavePortTempVolt(rfsId,&tmpData);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    *pTemp = tmpData.paTemp[ulChan%2];

    return BSP_OK;
}

/*获取子端的单板温度*/
UINT32 BspGetRfsDevBoardTemp(UINT32 rfsId, INT32 *pTemp)
{
    T_SlavePortTempVolt tmpData = {0};
    UINT32 retVal = BSP_OK;

    retVal = BspGetSlavePortTempVolt(rfsId,&tmpData);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    *pTemp = tmpData.boardTemp;

    return BSP_OK;
}

/*获取子端的电源温度*/
UINT32 BspGetRfsDevPwrTemp(UINT32 rfsId, INT32 *pTemp)
{
    T_SlavePortTempVolt tmpData = {0};
    UINT32 retVal = BSP_OK;

    retVal = BspGetSlavePortTempVolt(rfsId,&tmpData);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    *pTemp = tmpData.pwrTemp;

    return BSP_OK;
}

/*获取子端的电压及告警状态*/
UINT32 BspGetRfsDevPwrVolt(UINT32 rfsId, INT32 *pVolt)
{
    T_SlavePortTempVolt tmpData = {0};
    UINT32 retVal = BSP_OK;

    retVal = BspGetSlavePortTempVolt(rfsId,&tmpData);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    *pVolt = tmpData.pwrVolt;
     if(BSP_OK != tmpData.pwrAlm)
     {
        return 1;   /*1代表欠压告警 和子端确认没有过压告警*/
     }
    return BSP_OK;
}

/*雷击状态*/
UINT32 BspGetRfsDevThunderSupportFlag(UINT32 rfsId)
{
    return BSP_OK;
}

UINT32 BspGetRfsDevModuleGroupId(UINT32 rfsId)
{
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(1 != g_SlavePortBaseInfo[rfsId].linkSta) /*1表示建链状态正常*/
    {
        return BSP_ERROR;
    }
    return g_SlavePortBaseInfo[rfsId].moduleGroupId;
}

/*id上报*/
UINT32 BspGetRfsDevBoardGroupId(UINT32 rfsId)
{
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(1 != g_SlavePortBaseInfo[rfsId].linkSta) /*1表示建链状态正常*/
    {
        return BSP_ERROR;
    }
    return g_SlavePortBaseInfo[rfsId].boardGroupId;
}

static UINT32 BspGetRfsDevBoardTypeId(UINT32 rfsId)
{
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(1 != g_SlavePortBaseInfo[rfsId].linkSta) /*1表示建链状态正常*/
    {
        return BSP_ERROR;
    }
    return g_SlavePortBaseInfo[rfsId].boardTypeId;
}

static UINT32 BspGetRfsDevHwChangeId(UINT32 rfsId)
{
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    if(1 != g_SlavePortBaseInfo[rfsId].linkSta) /*1表示建链状态正常*/
    {
        return BSP_ERROR;
    }
    return g_SlavePortBaseInfo[rfsId].hwChangeId;
}


static UINT32 BspGetRfsDevPaBandInfo(UINT32 rfsId, T_SlavePortBandInfo *pInfo)
{
    char paTxFreq[MAX_BAND_INFO_LENTH] = {0};
    UINT32 freqBand = 0;
    UINT32 startFreq = 0;
    UINT32 endFreq = 0;
    INT32 retVal = 0;

    INPUT_POINTER_CHECK(pInfo);
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    memcpy_s(paTxFreq, MAX_BAND_INFO_LENTH, s_SlavePortPaInfo[rfsId].paTxFreq, MAX_BAND_INFO_LENTH);
    retVal = sscanf_s(paTxFreq, "%u:%u %u", &freqBand, &startFreq, &endFreq);
    SSCANF_S_CHECK(retVal);
    pInfo->freqBand = freqBand;
    pInfo->startFreq = startFreq;
    pInfo->endFreq = endFreq;

    dbgInfoEx("freqBand -- %d, startFreq -- %d, endFreq -- %d\n", freqBand, startFreq, endFreq);
    return BSP_OK;
}

static UINT32 BspGetBandWidthInfo(char *str, char *band)
{
    char *start = NULL;
    char *end = NULL;
    UINT32 lenth = 0;

    INPUT_POINTER_CHECK(str);
    INPUT_POINTER_CHECK(band);

    start = strchr(str, '_');
    if(start == NULL)
    {
        dbgErr("No underscore found in string.\n");
        return BSP_ERROR;
    }
    dbgInfoEx("The start is: %s\n", start);
    start++;

    end = strchr(start, '_');
    if(end == NULL)
    {
        dbgErr("No second underscore found in string.\n");
        return BSP_ERROR;
    }
    dbgInfoEx("The end is: %s\n", end);

    lenth = end - start;
    dbgInfoEx("The lenth is: %d\n", lenth);
    strncpy_s(band, MAX_BAND_INFO_LENTH, start, lenth);
    band[lenth] = '\0';
    dbgInfoEx("The band is: %s\n", band);

    return BSP_OK;
}

/*资产信息上报*/
UINT32 BspGetRfsDevRruInventory(UINT32 rfsId, T_BspInventoryInfo *ptDevInfo)
{
    UINT32 acPower = 0;
    UINT32 band = 0;
    T_SlavePortBandInfo bandInfo = {0};
    char info[BAR_MAX_LENGTH] = {0};
    char bandWidth[MAX_BAND_INFO_LENTH] = {0};
    INT32 retVal = BSP_OK;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(ptDevInfo);
    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }

    ret = BspGetRfsDevPaBandInfo(rfsId, &bandInfo);
    CHECK_RETVAL(BspGetRfsDevPaBandInfo, ret);
    ret = BspGetFreqBandByFreqRange(TX, bandInfo.startFreq, bandInfo.endFreq, &band);
    CHECK_RETVAL(BspGetFreqBandByFreqRange, ret);
    ret = BspGetBandInfoByBandId(band, info);
    CHECK_RETVAL(BspGetBandInfoByBandId, ret);
    ret = BspGetBandWidthInfo(info, bandWidth);
    CHECK_RETVAL(BspGetBandWidthInfo, ret);

    ptDevInfo->usModuleGroupId = BspGetRfsDevModuleGroupId(rfsId);
    ptDevInfo->usBoardType = BspGetRfsDevBoardTypeId(rfsId) | (BspGetRfsDevBoardGroupId(rfsId) << 5);
    ptDevInfo->usBomId = BspGetRfsDevHwChangeId(rfsId);
    ptDevInfo->usServiceTimes = s_SlavePortRruInfo[rfsId].serviceTime;
    _ASNPRINTF(ptDevInfo->acSerialNumber, s_SlavePortRruInfo[rfsId].rruBarCode);
    _ASNPRINTF(ptDevInfo->acProduceCode, s_SlavePortRruInfo[rfsId].bomCode);
    _ASNPRINTF(ptDevInfo->acInventoryUnitType, "NULL");
    _ASNPRINTF(ptDevInfo->acVendorUnitFamilyType, s_SlavePortRruInfo[rfsId].vendorUnitFamilyType);
    if (NULL != strstr(s_SlavePortRruInfo[rfsId].vendorUnitPid, "INVALID_VALUE"))
    {
        _ASNPRINTF(ptDevInfo->acVendorUnitTypeNumber, s_SlavePortRruInfo[rfsId].vendorUnitTypeNumber);
    }
    else
    {
        retVal = snprintf_s(ptDevInfo->acVendorUnitTypeNumber, sizeof(ptDevInfo->acVendorUnitTypeNumber),
                 "%s(%s)\0", s_SlavePortRruInfo[rfsId].vendorUnitTypeNumber, s_SlavePortRruInfo[rfsId].vendorUnitPid);
        SNPRINTF_S_CHECK(retVal, sizeof(ptDevInfo->acVendorUnitTypeNumber));
    }
    _ASNPRINTF(ptDevInfo->acVersionNumber, "NULL");
    _ASNPRINTF(ptDevInfo->acVendorName, "ZTE");
    _ASNPRINTF(ptDevInfo->acDateOfManufacture, s_SlavePortRruInfo[rfsId].productTime);
    _ASNPRINTF(ptDevInfo->acDateOfLastService, s_SlavePortRruInfo[rfsId].lastServiceDate);
    _ASNPRINTF(ptDevInfo->tManufacturerData.acPowerType, s_SlavePortPwrInfo[rfsId].pwrType);
    _ASNPRINTF(ptDevInfo->tManufacturerData.acBand, bandWidth);
    acPower = s_SlavePortRruInfo[rfsId].rruRatedPowerTx / (UINT32)s_SlavePortRruInfo[rfsId].antNum / 1000;
    retVal = snprintf_s(ptDevInfo->tManufacturerData.acPower,
             sizeof(ptDevInfo->tManufacturerData.acPower), "%d*%dW\0",
             s_SlavePortRruInfo[rfsId].antNum, acPower);
    SNPRINTF_S_CHECK(retVal, sizeof(ptDevInfo->tManufacturerData.acPower));
    _ASNPRINTF(ptDevInfo->tManufacturerData.acCustomAttri, "NULL");

    return BSP_OK;
}

static UINT32 BspPrnRfsDevRruInventory(UINT32 rfsId)
{
    T_BspInventoryInfo *ptDevInfo = NULL;
    UINT32 retVal = BSP_OK;

    ptDevInfo = (T_BspInventoryInfo *)malloc(sizeof(T_BspInventoryInfo));
    if(NULL == ptDevInfo)
    {
        dbgInfo("malloc failed\n");
        return BSP_ERROR;
    }
    memset_s(ptDevInfo, sizeof(T_BspInventoryInfo), 0, sizeof(T_BspInventoryInfo));

    retVal = BspGetRfsDevRruInventory(rfsId, ptDevInfo);
    dbgInfo("rfsId                   -- %d\n", rfsId);
    dbgInfo("usModuleGroupId         -- 0x%02x\n", ptDevInfo->usModuleGroupId);
    dbgInfo("usBoardType             -- 0x%02x\n", ptDevInfo->usBoardType);
    dbgInfo("usBomId                 -- 0x%02x\n", ptDevInfo->usBomId);
    dbgInfo("usServiceTimes          -- %d\n", ptDevInfo->usServiceTimes);
    dbgInfo("acSerialNumber          -- %s\n", ptDevInfo->acSerialNumber);
    dbgInfo("acProduceCode           -- %s\n", ptDevInfo->acProduceCode);
    dbgInfo("acInventoryUnitType     -- %s\n", ptDevInfo->acInventoryUnitType);
    dbgInfo("acVendorUnitFamilyType  -- %s\n", ptDevInfo->acVendorUnitFamilyType);
    dbgInfo("acVendorUnitTypeNumber  -- %s\n", ptDevInfo->acVendorUnitTypeNumber);
    dbgInfo("acVersionNumber         -- %s\n", ptDevInfo->acVersionNumber);
    dbgInfo("acVendorName            -- %s\n", ptDevInfo->acVendorName);
    dbgInfo("acDateOfManufacture     -- %s\n", ptDevInfo->acDateOfManufacture);
    dbgInfo("acDateOfLastService     -- %s\n", ptDevInfo->acDateOfLastService);
    dbgInfo("acPowerType             -- %s\n", ptDevInfo->tManufacturerData.acPowerType);
    dbgInfo("acBand                  -- %s\n", ptDevInfo->tManufacturerData.acBand);
    dbgInfo("acPower                 -- %s\n", ptDevInfo->tManufacturerData.acPower);
    dbgInfo("acCustomAttri           -- %s\n", ptDevInfo->tManufacturerData.acCustomAttri);

    free(ptDevInfo);
    return retVal;
}

static UINT32 BspGetRfsDevDflBandInfo(UINT32 rfsId, UINT32 index, T_SlavePortBandInfo *pInfo)
{
    char dflTxFreq[MAX_BAND_INFO_LENTH] = {0};
    UINT32 freqBand = 0;
    UINT32 startFreq = 0;
    UINT32 endFreq = 0;

    INPUT_POINTER_CHECK(pInfo);
    if((rfsId >= MAX_SLAVE_PORT_NUM) || (index >= MAX_SLAVE_CHAN_NUM))
    {
        return BSP_ERROR;
    }

    memcpy_s(dflTxFreq, MAX_BAND_INFO_LENTH, s_SlavePortDflInfo[rfsId][index].dflTxFreq, MAX_BAND_INFO_LENTH);
    (void)zte_sscanf_s(dflTxFreq, "%u:%u %u", NULL, &freqBand, &startFreq, &endFreq);
    dbgInfoEx("%s freqBand %d startFreq %d endFreq %d\n", dflTxFreq,freqBand,startFreq,endFreq);
    pInfo->freqBand = freqBand;
    pInfo->startFreq = startFreq;
    pInfo->endFreq = endFreq;

    return BSP_OK;
}

/*资产信息上报，临时打桩测试*/
UINT32 BspGetRfsDevModuleInfoNew(UINT32 rfsId, UINT32 chan, T_RruRfModuleInfoNew *ptRfModuleInfo)
{
    UINT32 staBand = 0;
    T_SlavePortBandInfo bandInfo = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(ptRfModuleInfo);
    if((BSP_MAX_BAND_NUM_PER_CH <= chan) || (rfsId >= MAX_SLAVE_PORT_NUM))
    {
        return BSP_ERROR;
    }

    retVal = BspGetRfsDevDflBandInfo(rfsId, chan, &bandInfo);
    CHECK_RETVAL(BspGetRfsDevDflBandInfo, retVal);
    retVal = BspGetFreqBandByFreqRange(TX, bandInfo.startFreq, bandInfo.endFreq, &staBand);
    CHECK_RETVAL(BspGetFreqBandByFreqRange, retVal);
    ptRfModuleInfo->ulRuAntTxMaxPower = s_SlavePortRruInfo[rfsId].rruRatedPowerTx / MAX_SLAVE_CHAN_NUM;
    ptRfModuleInfo->ulRuNominalPower = s_SlavePortRruInfo[rfsId].rruRatedPowerTx / MAX_SLAVE_CHAN_NUM;
    ptRfModuleInfo->ulRuAvailNominalPower = s_SlavePortRruInfo[rfsId].rruRatedPowerTx / MAX_SLAVE_CHAN_NUM;
    ptRfModuleInfo->ulRuTxStartFreq[chan] = bandInfo.startFreq;
    ptRfModuleInfo->ulRuTxEndFreq[chan] = bandInfo.endFreq;
    ptRfModuleInfo->ulRuRxStartFreq[chan] = bandInfo.startFreq;
    ptRfModuleInfo->ulRuRxEndFreq[chan] = bandInfo.endFreq;
    ptRfModuleInfo->ulRuFreqBand = bandInfo.freqBand;
    ptRfModuleInfo->ulRuStandardBand[chan] = staBand;
    return retVal;
}

static UINT32 BspPrnRfsDevModuleInfoNew(UINT32 rfsId, UINT32 chan)
{
    T_RruRfModuleInfoNew *pRfModuleInfo = NULL;
    UINT32 retVal = BSP_OK;

    pRfModuleInfo = (T_RruRfModuleInfoNew *)malloc(sizeof(T_RruRfModuleInfoNew));
    if(NULL == pRfModuleInfo)
    {
        dbgInfo("malloc failed\n");
        return BSP_ERROR;
    }
    memset_s(pRfModuleInfo, sizeof(T_RruRfModuleInfoNew), 0, sizeof(T_RruRfModuleInfoNew));

    retVal = BspGetRfsDevModuleInfoNew(rfsId, chan, pRfModuleInfo);
    dbgInfo("rfsId                  -- %d\n", rfsId);
    dbgInfo("chan                   -- %d\n", chan);
    dbgInfo("ulRuAntTxMaxPower      -- %d\n", pRfModuleInfo->ulRuAntTxMaxPower);
    dbgInfo("ulRuNominalPower       -- %d\n", pRfModuleInfo->ulRuNominalPower);
    dbgInfo("ulRuAvailNominalPower  -- %d\n", pRfModuleInfo->ulRuAvailNominalPower);
    dbgInfo("ulRuTxStartFreq        -- %d\n", pRfModuleInfo->ulRuTxStartFreq[chan]);
    dbgInfo("ulRuTxEndFreq          -- %d\n", pRfModuleInfo->ulRuTxEndFreq[chan]);
    dbgInfo("ulRuRxStartFreq        -- %d\n", pRfModuleInfo->ulRuRxStartFreq[chan]);
    dbgInfo("ulRuRxEndFreq          -- %d\n", pRfModuleInfo->ulRuRxEndFreq[chan]);
    dbgInfo("ulRuFreqBand           -- %d\n", pRfModuleInfo->ulRuFreqBand);
    dbgInfo("ulRuStandardBand       -- %d\n", pRfModuleInfo->ulRuStandardBand[chan]);

    free(pRfModuleInfo);
    return retVal;
}

UINT32 g_ulVifDaauSpecTypeDefine = 0;
UINT32 g_ulHwBrdDigitAnalogOptSum = 0x7FFFFFFF;
UINT32 g_ulHwBrdDigitAnalogSfpSum = 0x7FFFFFFF;
UINT32 g_ulMicellBrdSfpSupportFlag = BSP_OK;
UINT32 g_auHwBrdSfpDigitAnalogFlag[MAX_OPT_NUM] = {0, 0, 0, 0, 0, 0, 0, 0};

/****************************************************************************
 *  函数名称 :  BspSetMicellSpecTypeFlag(*)
 *  功能描述 :  规格单板下配置, DAAU配置为 1, 用于平台区分DAAU和其它单板
 *  输入参数 :  ulCfgFlag   -- DaauSpecTypeFlag
 *  输出参数 :  无
 *  返 回 值 :  BSP_OK- 获取正常, 其它- 获取异常
 *  其它说明 :  默认是 0, 规格单板下配置其它值
 *---------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *---------------------------------------------------------------------------
 */
UINT32 BspSetMicellSpecTypeFlag(UINT32 ulCfgFlag)
{
    g_ulVifDaauSpecTypeDefine = ulCfgFlag;
    return BSP_OK;
}

UINT32 BspGetMicellSpecTypeFlag(VOID)
{
    return g_ulVifDaauSpecTypeDefine;
}

UINT32 BspSetDigitSfpSupportFlag(UINT32 ulCfgFlag)
{
    g_ulMicellBrdSfpSupportFlag = ulCfgFlag;
    return BSP_OK;
}

// 返回BSP_OK: 支持数字光模块, 否则不支持数字光模块;
// MiCELL20 机型BBU 和VIFE 直连, 不支持数字光模块;
UINT32 BspGetDigitSfpSupportFlag(VOID)
{
    return g_ulMicellBrdSfpSupportFlag;
}

#if(0) // APP已打桩, 待去掉APP打桩后放开
UINT32 BspGetDigitAnalogOptSum(VOID)
{
    UINT32 ulMaxSumOptRet = 0;

    if(g_ulHwBrdDigitAnalogOptSum < 0xFFFF)
    {
        ulMaxSumOptRet = g_ulHwBrdDigitAnalogOptSum;

    }
    else
    {
        ulMaxSumOptRet = BspGetOptNum();
    }

    return ulMaxSumOptRet;
}
#endif

UINT32 BspSetDigitAnalogOptSum(UINT32 ulOptSum)
{
    g_ulHwBrdDigitAnalogOptSum = ulOptSum;
    return BSP_OK;
}

UINT32 BspGetDigitAnalogSfpSum(VOID)
{
    UINT32 ulMaxSumOptRet = 0;

    if(g_ulHwBrdDigitAnalogSfpSum < 0xFFFF)
    {
        ulMaxSumOptRet = g_ulHwBrdDigitAnalogSfpSum;
    }
    else
    {
        ulMaxSumOptRet = BspGetSfpNum();
    }

    return ulMaxSumOptRet;
}

UINT32 BspSetDigitAnalogSfpSum(UINT32 ulSfpSum)
{
    g_ulHwBrdDigitAnalogSfpSum = ulSfpSum;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetSfpDigitAnalogFlag(*)
 * 功能描述: 获取光模块的硬件类型
 * 输入参数: ulOptIdx - 光口编号
 * 输出参数: 无
 * 返 回 值: 光模块的硬件类型: 0-数字光模块, 1-模拟光模块
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@ 修改日期, 操作说明)
 * $0000000(N/A), 10119095@2024-01-24, 创建
 *----------------------------------------------------------------------------
 */
#if(0) // APP已打桩, 待去掉APP打桩后放开
UINT32 BspGetSfpDigitAnalogFlag(UINT32 ulOptIdx)
{
    UINT32 ulSfpDigitAnalogFlag = 0;
    if(ulOptIdx < MAX_OPT_NUM)
    {
        ulSfpDigitAnalogFlag = g_auHwBrdSfpDigitAnalogFlag[ulOptIdx];
    }
    else
    {
        ulSfpDigitAnalogFlag = 0; // 默认为数字类型
        dbgErr("%s>>Para Over Error! OptIdx(0~%d)= %d; Ret= %d;\n", __FUNCTION__,
               MAX_OPT_NUM - 1, ulOptIdx, ulSfpDigitAnalogFlag);
    }

    return ulSfpDigitAnalogFlag;
}
#endif

UINT32 BspSetSfpDigitAnalogFlag(UINT32 ulOptIdx, UINT32 ulDigitFlag)
{
    if(ulOptIdx < MAX_OPT_NUM)
    {
        g_auHwBrdSfpDigitAnalogFlag[ulOptIdx] = ulDigitFlag;
    }
    else
    {
        dbgErr("%s>>Para Over Error! OptIdx(0~%d)= %d\n",
               __FUNCTION__, MAX_OPT_NUM - 1, ulOptIdx);
    }
    return BSP_OK;
}

/* 从Flash读，CRC的值 */
UINT32 g_antiTamperBaseAddr =  0;
UINT32 g_antiTamperOffsetAddr =  0;
UINT32 g_antiClearTamperOffsetAddr =  0;

void BspSetAntiTamperBaseAddr(UINT32 addr)
{
    g_antiTamperBaseAddr = addr;
}

UINT32 BspGetAntiTamperBaseAddr(VOID)
{
    return g_antiTamperBaseAddr;
}

void BspSetAntiTamperOffsetAddr(UINT32 addr)
{
    g_antiTamperOffsetAddr = addr;
}

UINT32 BspGetAntiTamperOffsetAddr(VOID)
{
    return g_antiTamperOffsetAddr;
}

void BspSetClearAntiTamperFlagOffsetAddr(UINT32 addr)
{
    g_antiClearTamperOffsetAddr = addr;
}

UINT32 BspGetClearAntiTamperFlagOffsetAddr(void)
{
    return g_antiClearTamperOffsetAddr;
}

UINT32 CalcFileCrc(char* pFileName, UINT32* pulCrc)
{
    UINT32 ret = BSP_ERROR;

    ret = BspCalcFileCrc(pFileName, pulCrc);

    return ret;
}

UINT32 g_hwInfoCrcCheckResult  = 0;       /* RruInfo状态标记 */

void BspSetHwInfoCrcResult(UINT32 result)
{
    g_hwInfoCrcCheckResult = result;
}

UINT32 BspGetHwInfoCrcResult(void)
{
    return g_hwInfoCrcCheckResult;
}

UINT32 WrCrcToFlash(UINT32 baseAddr, UINT32 offsetAddr, UINT16 crcVal)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    UINT16 rdbackCrc = 0;
    UINT32 wrOkFlag = 0;
    UINT8 wrFinishFlag = 0;
    UINT32 wrFinishAddr = 0;
    UINT32 crcAddr = 0;


    crcAddr = baseAddr + offsetAddr;
    wrFinishAddr = crcAddr + 2;
    WrByteToFlash(wrFinishAddr, 0xff);
    for(loop = 0; loop < 3; loop++)
    {
        WrWordToFlash(crcAddr,crcVal);
        RdWordFromFlash(crcAddr, &rdbackCrc);
        if(rdbackCrc == crcVal)
        {
            wrOkFlag = 1;
            break;
        }
    }

    if(wrOkFlag == 1)
    {
        WrByteToFlash(wrFinishAddr, WR_CRC_FINISH_FLAG);
        RdByteFromFlash(wrFinishAddr, &wrFinishFlag);
        if(wrFinishFlag != WR_CRC_FINISH_FLAG)
        {
            ret = BSP_ERROR;
            dbgErr("%s: write finish falg read back check failed! please check flash!\n", __FUNCTION__);
        }
    }
    else
    {
        ret = BSP_ERROR;
        dbgErr("%s: write crc val failed! please check flash!\n", __FUNCTION__);
    }

    BspSetHwInfoCrcResult(HW_INFO_OK);
    dbgInfo("%s: WrCRCVal: 0x%x, wrFinishFlag: 0x%x checkResult: %d \n", __FUNCTION__, crcVal, wrFinishFlag, BspGetHwInfoCrcResult());
    return ret;
}

UINT32 CheckCrc(UINT32 baseAddr, UINT32 offsetAddr, UINT16 fileCrc)
{
    UINT16 flashCrc = 0;
    UINT32 flashAddr = 0;
    UINT32 ret = BSP_ERROR;
    UINT32 loop = 0;
    UINT32 result = HW_INFO_ERROR;


    flashAddr = baseAddr+offsetAddr;
    dbgInfo("%s [%d] flashAddr: 0x%x, fileCrc: 0x%x  \n", __FUNCTION__, __LINE__, flashAddr, fileCrc);
    for(loop = 0; loop < 3; loop++)
    {
        ret = RdWordFromFlash(flashAddr, &flashCrc);
        if(ret != BSP_OK)
        {
            result = HW_INFO_OK;
            dbgErr("%s [%d] loop: %d  read finish failed! please check flash!\n", __FUNCTION__, __LINE__, loop);
            continue;
        }

        dbgInfo("%s [%d] flashAddr:0x%x flashCrc: 0x%x  \n", __FUNCTION__, __LINE__, flashAddr, flashCrc);

            if(fileCrc == flashCrc)
            {
                result = HW_INFO_OK;
                break;
            }
            else
            {
                continue;
            }
    }
    BspSetHwInfoCrcResult(result);

    dbgInfo("%s [%d] fileCrc: 0x%x, flashCrc: 0x%x ,result: %d \n",
            __FUNCTION__, __LINE__, fileCrc, flashCrc, result);

    return ret;
}

UINT32 RdCrcWrFlag(UINT32 baseAddr, UINT32 offsetAddr, UINT8 *pFlag)
{
    UINT32 rdCount = 0;
    UINT32 rdLoop = 0;
    UINT8 crcWrFlag = 0;
    UINT32 ret = BSP_ERROR;
    UINT32 wrFinishAddr = 0;


    wrFinishAddr = baseAddr + offsetAddr + 2;
    for(rdLoop = 0; rdLoop < 3; rdLoop++)
    {
        ret = RdByteFromFlash(wrFinishAddr, &crcWrFlag);
        dbgInfo("%s [%d] crcWrFlagAddr: 0x%x, crcWrFlag: 0x%x, ret = %d \n",
                __FUNCTION__, __LINE__, wrFinishAddr, crcWrFlag, ret);
        if(ret == BSP_OK && crcWrFlag == WR_CRC_FINISH_FLAG)
        {
            *pFlag = crcWrFlag;
            ret = BSP_OK;
            break;
        }
        else
        {
            rdCount++;
        }
    }

    if(rdCount == 3)
    {
        dbgInfo("%s [%d] rdCount: %d  read failed! please check flash!\n", __FUNCTION__, __LINE__, rdCount);
        ret = BSP_ERROR;
    }

    return ret;
}

/*获取byte5 CRC清除标志*/
UINT8 GetCrcAlreadClearFlag(VOID)
{
    UINT8 crcAlreadClearFlag = 0;
    UINT32 baseAddr = 0;
    UINT32 offsetAddr = 0;
    UINT32 clearCrcFlagAddr = 0;
    UINT32 ret = BSP_ERROR;

    baseAddr = BspGetAntiTamperBaseAddr();
    CHECK_FLASH_ADDR(baseAddr);
    offsetAddr = BspGetClearAntiTamperFlagOffsetAddr();
    CHECK_CRC_CLR_FLASH_OFFEST_ADDR(offsetAddr);
    clearCrcFlagAddr = baseAddr + offsetAddr;
    ret = RdByteFromFlash(clearCrcFlagAddr, &crcAlreadClearFlag);
    dbgInfo("%s:crcWrFlagAddr[0x%x], crcClrFlag[0x%x], ret[%d]\n",
        __FUNCTION__, clearCrcFlagAddr, crcAlreadClearFlag, ret);

    return crcAlreadClearFlag;
}

UINT32 InitAntiTamperFunc(VOID)
{
#if defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS)
    ;      //工装和BSP小版本防篡改功能不生效
#else
    UINT32 ret = BSP_ERROR;
    UINT32 fileCrc = 0;
    UINT32 baseAddr = 0;
    UINT32 offsetAddr = 0xd;
    UINT8 crcWrFlag = 0;

    if(BspIsFileExist(ANTI_TAMPER_FILE) != BSP_OK)
    {
        dbgInfo("[%s] This board is not support anti-tamper function!\n", __FUNCTION__);
        return BSP_OK;
    }
    else
    {
        ret = CalcFileCrc(ANTI_TAMPER_FILE, &fileCrc);
        CHECK_RETVAL(CalcFileCrc, ret);
        baseAddr = BspGetAntiTamperBaseAddr();
        CHECK_FLASH_ADDR(baseAddr);
        offsetAddr = BspGetAntiTamperOffsetAddr();
        ret = RdCrcWrFlag(baseAddr, offsetAddr, &crcWrFlag);
        dbgInfo("[%s] fileCrc: 0x%x, crcWrFlag: 0x%x, baseAddr: 0x%x, offsetAddr: 0x%x\n", __FUNCTION__, fileCrc, crcWrFlag, baseAddr, offsetAddr);
        if(ret == BSP_OK)
        {
            ret = CheckCrc(baseAddr, offsetAddr, fileCrc);
            CHECK_RETVAL(CheckCrc, ret);
        }
        else
        {
            ret = WrCrcToFlash(baseAddr, offsetAddr, fileCrc);
            CHECK_RETVAL(WrCrcToFlash, ret);
        }

    }
#endif

    return BSP_OK;
}

UINT32 InitAntiTamper(VOID)
{
#if defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS)
    ;      //工装和BSP小版本防篡改功能不生效
#else
    UINT32 ret = BSP_ERROR;
    UINT32 fileCrc = 0;
    UINT32 baseAddr = 0;
    UINT32 offsetAddr = 0xd;
    UINT8 crcWrFlag = 0;
    UINT8 rdCrcClrFlag = 0;

    rdCrcClrFlag = GetCrcAlreadClearFlag();
    BspLog(LOG_LEVEL_0,"%s rdCrcClrFlag[0x%x]\n", __FUNCTION__, rdCrcClrFlag);
    if (FOREVER_CLR_HWCRC_INFO_MODE == rdCrcClrFlag)
    {
        dbgInfo("%s: crc clear flag is 0x%x\n", __FUNCTION__, FOREVER_CLR_HWCRC_INFO_MODE);
        return BSP_OK;
    }

    if(BspIsFileExist(ANTI_TAMPER_FILE) != BSP_OK)
    {
        dbgInfo("[%s] This board is not support anti-tamper function!\n", __FUNCTION__);
        return BSP_OK;
    }
    else
    {
        ret = CalcFileCrc(ANTI_TAMPER_FILE, &fileCrc);
        CHECK_RETVAL(CalcFileCrc, ret);
        baseAddr = BspGetAntiTamperBaseAddr();
        CHECK_FLASH_ADDR(baseAddr);
        offsetAddr = BspGetAntiTamperOffsetAddr();
        ret = RdCrcWrFlag(baseAddr, offsetAddr, &crcWrFlag);
        dbgInfo("[%s] fileCrc: 0x%x, crcWrFlag: 0x%x, baseAddr: 0x%x, offsetAddr: 0x%x\n", __FUNCTION__, fileCrc, crcWrFlag, baseAddr, offsetAddr);
        if(ret == BSP_OK)
        {
            ret = CheckCrc(baseAddr, offsetAddr, fileCrc);
            CHECK_RETVAL(CheckCrc, ret);
        }
        else
        {
            ret = WrCrcToFlash(baseAddr, offsetAddr, fileCrc);
            CHECK_RETVAL(WrCrcToFlash, ret);
        }

    }
#endif

    return BSP_OK;
}

UINT32 GetTmpInfoCrc(VOID)
{
    UINT32 fileCrc = 0;

    if(BspIsFileExist(ANTI_TAMPER_FILE) != BSP_OK)
    {
        dbgInfo("[%s] There is no file named 'rruinfo' !\n", __FUNCTION__);
        return BSP_OK;
    }
    else
    {
        (void)CalcFileCrc(ANTI_TAMPER_FILE, &fileCrc);    
    }
    return fileCrc;
}


UINT32 ClearAntiTamper(VOID)
{
    UINT32 baseAddr = 0;
    UINT32 offsetAddr = 0xd;
    UINT32 wrFinishAddr = 0;

    baseAddr = BspGetAntiTamperBaseAddr();
    CHECK_FLASH_ADDR(baseAddr);
    offsetAddr = BspGetAntiTamperOffsetAddr();
    wrFinishAddr = baseAddr + offsetAddr + 2;

    WrCrcToFlash(baseAddr, offsetAddr, 0);
    WrByteToFlash(wrFinishAddr, 0xff);
    BspSetHwInfoCrcResult(HW_INFO_OK);
    
    return BSP_OK;
}

UINT8 GetCrcWrFlag(VOID)
{
    UINT8 crcWrFlag = 0;
    UINT32 baseAddr = 0;
    UINT32 offsetAddr = 0xd;
    UINT32 wrFinishAddr = 0;
    UINT32 ret = BSP_ERROR;
    
    baseAddr = BspGetAntiTamperBaseAddr();
    CHECK_FLASH_ADDR(baseAddr);
    offsetAddr = BspGetAntiTamperOffsetAddr();
    wrFinishAddr = baseAddr + offsetAddr + 2;
    ret = RdByteFromFlash(wrFinishAddr, &crcWrFlag);
    dbgInfo("%s crcWrFlagAddr: 0x%x, crcWrFlag: 0x%x, ret = %d \n",
        __FUNCTION__, wrFinishAddr, crcWrFlag, ret);

    return crcWrFlag;
}

UINT16 GetInfoCrc(VOID)
{
    UINT16 flashCrc = 0;
    UINT32 baseAddr = 0;
    UINT32 offsetAddr = 0xd;
    UINT32 flashAddr = 0;

    baseAddr = BspGetAntiTamperBaseAddr();
    CHECK_FLASH_ADDR(baseAddr);
    offsetAddr = BspGetAntiTamperOffsetAddr();
    flashAddr = baseAddr+offsetAddr;
    RdWordFromFlash(flashAddr, &flashCrc);

    dbgInfo("flashCrc: 0x%x",flashCrc);

    return flashCrc;
}

UINT32 BspCheckHwInfoCrcResult(void)
{
    return BspGetHwInfoCrcResult();
}

UINT32 WrCrcClrFlagToFlash(UINT32 baseAddr, UINT32 offsetAddr, UINT8 crcClrVal)
{
    UINT32 ret = BSP_OK;
    UINT8 rdCrcClrFlag = 0;
    UINT32 crcClrFlagAddr = 0;

    crcClrFlagAddr = baseAddr + offsetAddr;
    RdByteFromFlash(crcClrFlagAddr, &rdCrcClrFlag);
    dbgInfo("%s: addr[0x%x], oldCrcClrFlag[0x%x], inputCrcClrFlag[%d]\n", __FUNCTION__, crcClrFlagAddr, rdCrcClrFlag, crcClrVal);
    WrByteToFlash(crcClrFlagAddr, crcClrVal);
    RdByteFromFlash(crcClrFlagAddr, &rdCrcClrFlag);
    if(rdCrcClrFlag != crcClrVal)
    {
        ret = BSP_ERROR;
        dbgErr("%s: write crcClear falg read back check failed! please check flash!\n", __FUNCTION__);
    }
    BspLog(LOG_LEVEL_0,"%s: addr[0x%x], crcClrFlag[0x%x], inputCrcClrFlag[%d]\n", __FUNCTION__, crcClrFlagAddr, rdCrcClrFlag, crcClrVal);
    return ret;
}

/*入参：mode:  FOREVER_CLR_HWCRC_INFO_MODE(0xA5)清除后不再写入
              ONETIME_WRITE_HWCRC_INFO_MODE(0x5A)清除后重新写入标志  8862使用
              OVER_WRITE_HWCRC_INFO_MODE(0xFF)清除后不再写入*/
UINT32 SetCrcAlreadClearFlag(UINT8  mode)
{
    UINT32 baseAddr = 0;
    UINT32 offsetAddr = 0;
    UINT32 ret = BSP_OK;

    if ((FOREVER_CLR_HWCRC_INFO_MODE != mode) && (OVER_WRITE_HWCRC_INFO_MODE != mode))/*判断是否为0xA5或0xFF*/
    {
        dbgInfo("%s: input mode[%d] err\n", __FUNCTION__, mode);
        return BSP_ERROR;
    }

    baseAddr = BspGetAntiTamperBaseAddr();
    CHECK_FLASH_ADDR(baseAddr);
    offsetAddr = BspGetClearAntiTamperFlagOffsetAddr();
    CHECK_CRC_CLR_FLASH_OFFEST_ADDR(offsetAddr);
    ret = WrCrcClrFlagToFlash(baseAddr, offsetAddr, mode);

    return ret;
}

/*执行清除防篡改操作
 * (BYTE5写0xA5，并清除防篡改信息,mode = FOREVER_CLR_HWCRC_INFO_MODE)
 * 返回值：BSP_OK 清除成功    BSP_ERROR  清除失败
 * */
UINT32 BspUninstallAntiTamper(VOID)
{
    UINT8 rdCrcClrFlag = 0;
    UINT32 ret = BSP_OK;

    rdCrcClrFlag = GetCrcAlreadClearFlag();
    BspLog(LOG_LEVEL_0,"%s rdCrcClrFlag[0x%x]\n", __FUNCTION__, rdCrcClrFlag);
    if (FOREVER_CLR_HWCRC_INFO_MODE == rdCrcClrFlag)
    {
        dbgInfo("%s: crc clear flag is 0x%x\n", __FUNCTION__, FOREVER_CLR_HWCRC_INFO_MODE);
        return BSP_OK;
    }

    /*byte5不是0xA5,则清除防篡改信息*/
    ret = ClearAntiTamper();
    ret |= SetCrcAlreadClearFlag(FOREVER_CLR_HWCRC_INFO_MODE);/*清除完之后将byte置为0xa5*/
    return ret;
}

/*防篡改重新写入流程
 * (BYTE5写0xFF，并重新计算防篡改信息,mode = OVER_WRITE_HWCRC_INFO_MODE)
 * 返回值：BSP_OK 清除成功    BSP_ERROR  清除失败
 * */
UINT32 BspInstallAntiTamper(VOID)
{
    UINT8 rdCrcClrFlag = 0;
    UINT32 ret = BSP_OK;
    rdCrcClrFlag = GetCrcAlreadClearFlag();
    BspLog(LOG_LEVEL_0,"%s rdCrcClrFlag[0x%x]\n", __FUNCTION__, rdCrcClrFlag);
    if (OVER_WRITE_HWCRC_INFO_MODE == rdCrcClrFlag)
    {
        dbgInfo("%s: crc clear flag is 0x%x\n", __FUNCTION__, OVER_WRITE_HWCRC_INFO_MODE);
        return BSP_OK;
    }

    /*byte5不是0xff,则重新核算防篡改信息*/
    ret = ClearAntiTamper();/*先清除再写入*/
    ret |= InitAntiTamperFunc();
    ret |= SetCrcAlreadClearFlag(OVER_WRITE_HWCRC_INFO_MODE);/*计算完之后将byte置为0xFF*/
    return ret;
}

UINT32 BspGetRfsDevPwrType(UINT32 rfsId)
{
    T_BspInventoryInfo devInfo = {0};
    UINT32 retVal = BSP_OK;

    if(rfsId >= MAX_SLAVE_PORT_NUM)
    {
        return BSP_ERROR;
    }
    retVal = BspGetRfsDevRruInventory(rfsId, &devInfo);
    if(retVal != BSP_OK)
    {
        dbgInfo("[%s] Bsp Get Rfs Dev Rru Inventory Failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(strncmp("AC", devInfo.tManufacturerData.acPowerType, 2) == 0)
    {
        return PWR_TYPE_AC;
    }
    return PWR_TYPE_DC;
}

UINT32 BspBoardSetSubPortSw(UINT32 sw)
{
    sw = (sw == SWITCH_ON)?SWITCH_ON:SWITCH_OFF;
    g_subPortSwSta = sw;

    return BSP_OK;
}

UINT32 BspBoardGetSubPortSw(VOID)
{
    return g_subPortSwSta;
}


BOOL BspIsHaveMcsPhyOptByMcsId(UINT32 mcsId)
{
    return FALSE;
}

BOOL BspIsSupportInfReducedRank(VOID) /* D42机型打桩 */
{
    return FALSE;
}

UINT32 BspRecordClkStatus(T_RruClkStatusRecord *clkRecordInfo)
{
    const char *bufName = "PllSys";
    UINT32 devId = 0;
    UINT32 regVal = 0;
    TRruDeviceDescription dev = {0};

    INPUT_POINTER_CHECK(clkRecordInfo);
    memset_s(clkRecordInfo, sizeof(T_RruClkStatusRecord), 0, sizeof(T_RruClkStatusRecord));

    devId = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devId);

    if (BSP_OK != BspDevInfoGetByDevId(devId, &dev))
    {
        dbgErr("[%s] DevInfo Get Error!", __FUNCTION__);
        return BSP_ERROR;
    }

    if(strcmp(dev.acDeviceName,"au5518") == 0)
    {
        clkRecordInfo->clk5518Sta.recordValidFlag = SUPPORT;

        ClkDevRegSet(0,0xff,0);
        regVal = ClkDevRegGet(0,0x02);
        clkRecordInfo->clk5518Sta.clkX0 = regVal;

        ClkDevRegSet(0,0xff,0x6);
        regVal = ClkDevRegGet(0,0x02);
        clkRecordInfo->clk5518Sta.clk1p = regVal;

        regVal = ClkDevRegGet(0,0x06);
        clkRecordInfo->clk5518Sta.clk2pAnd3p = regVal;

        regVal = ClkDevRegGet(0,0x0a);
        clkRecordInfo->clk5518Sta.clkOCXOAnd4p = regVal;

        ClkDevRegSet(0,0xff,0);
        regVal = ClkDevRegGet(0,0x06);
        clkRecordInfo->clk5518Sta.clkFtOut = regVal;

        ClkDevRegSet(0,0xff,0xa);
        regVal = ClkDevRegGet(0,0x02);
        clkRecordInfo->clk5518Sta.pllaLock = regVal;

        regVal = ClkDevRegGet(0,0x06);
        clkRecordInfo->clk5518Sta.pllaHold = regVal;

        ClkDevRegSet(0,0xff,0xb);
        regVal = ClkDevRegGet(0,0x02);
        clkRecordInfo->clk5518Sta.pllbLock = regVal;

        regVal = ClkDevRegGet(0,0x6);
        clkRecordInfo->clk5518Sta.pllbHold = regVal;

        ClkDevRegSet(0,0xff,0xc);
        regVal = ClkDevRegGet(0,0x02);
        clkRecordInfo->clk5518Sta.pllcLock = regVal;

        regVal = ClkDevRegGet(0,0x06);
        clkRecordInfo->clk5518Sta.pllcHold = regVal;

        ClkDevRegSet(0,0xff,0xd);
        regVal = ClkDevRegGet(0,0x02);
        clkRecordInfo->clk5518Sta.plldLock = regVal;

        regVal = ClkDevRegGet(0,0x06);
        clkRecordInfo->clk5518Sta.plldHold = regVal;

        ClkDevRegSet(0,0xff,0xe);
        regVal = ClkDevRegGet(0,0x02);
        clkRecordInfo->clk5518Sta.pllftLock = regVal;

        regVal = ClkDevRegGet(0,0x06);
        clkRecordInfo->clk5518Sta.pllftHold = regVal;
    }

    if(strcmp(dev.acDeviceName,"idt8a35018d") == 0)
    {
        clkRecordInfo->clk18dSta.recordValidFlag = SUPPORT;

        regVal = ClkDevRegGet(0,0xc044);
        clkRecordInfo->clk18dSta.IN0 = regVal;

        regVal = ClkDevRegGet(0,0xc045);
        clkRecordInfo->clk18dSta.IN1 = regVal;

        regVal = ClkDevRegGet(0,0xc046);
        clkRecordInfo->clk18dSta.IN2 = regVal;

        regVal = ClkDevRegGet(0,0xc04c);
        clkRecordInfo->clk18dSta.IN8 = regVal;

        regVal = ClkDevRegGet(0,0xc054);
        clkRecordInfo->clk18dSta.DPLL0 = regVal;

        regVal = ClkDevRegGet(0,0xc057);
        clkRecordInfo->clk18dSta.DPLL3 = regVal;

        regVal = ClkDevRegGet(0,0xc059);
        clkRecordInfo->clk18dSta.DPLL5 = regVal;

        regVal = ClkDevRegGet(0,0xc05a);
        clkRecordInfo->clk18dSta.DPLL6 = regVal;

        regVal = ClkDevRegGet(0,0xc05b);
        clkRecordInfo->clk18dSta.DPLL7 = regVal;

        regVal = ClkDevRegGet(0,0xc05c);
        clkRecordInfo->clk18dSta.DPLLsy = regVal;

        regVal = ClkDevRegGet(0,0xc05d);
        clkRecordInfo->clk18dSta.Apll = regVal;
    }

    return BSP_OK;
}

FUNC_GetRru204Status pGetRru204StaRecordCall = NULL;
UINT32 BspRegisterRru204StaCall(FUNC_GetRru204Status pRru204StaCall)
{
    pGetRru204StaRecordCall = pRru204StaCall;
    return BSP_OK;
}

UINT32 BspGetRru204StaRecord(T_Rru204StatusRecord *recordInfo)
{
    INPUT_POINTER_CHECK(recordInfo);

    memset_s(recordInfo, sizeof(T_Rru204StatusRecord), 0, sizeof(T_Rru204StatusRecord));

    if(NULL != pGetRru204StaRecordCall)
    {
        if(BSP_ERROR != pGetRru204StaRecordCall(recordInfo))
        {
            dbgInfoEx("get Rru204 Status success !\n");
            return BSP_OK;
        }
        else
        {
            dbgErr("get Rru204 Status failed !\n");
            return BSP_ERROR;
        }
    }

    return BSP_ERROR;
}

/* D42 BOOT远程升级接口 */
UINT32 BspUpdatBootVer(CHAR *bootVersionPath)
{
    INPUT_POINTER_CHECK(bootVersionPath);

    return BootLoadTest(bootVersionPath);
}

/*主从架构架构机型，从设置功能状态标志，主读取状态*/
/*寄存器使用规则说明：
 * 1)逻辑寄存器通过2个16bit的寄存器实现32个bit的标志使用
  *2)每个从片使用2个连续的寄存器
  *3)主片使用连续的2*总从片个数个寄存器对应所有从片的状态寄存器
*/
UINT32 BspSetMsSyncFlagFun(UINT32 chip, UINT32 funBit, UINT32 flag)
{
    UINT32 ret = BSP_OK;

    if(funBit >= 32)
    {
        dbgErr("%s:funBit is %d!\n",__FUNCTION__, funBit);
        return BSP_ERROR;
    }

    ret = BspRegBitValWr(0, REG_FPGA_MS_FUN_SET_FLAG, chip*2+funBit/16, 1, funBit%16,  funBit%16);
    BspLog(LOG_LEVEL_0,"%s chip %d funbit %d flag %d\n", __FUNCTION__, chip, funBit, flag);
    return ret;
}

UINT32 BspGetMsSyncFlagFun(UINT32 chip, UINT32 funBit, UINT32 *flag)
{
    UINT32 ret = BSP_OK;

    if(funBit >= 32)
    {
        dbgErr("%s:funBit is %d!\n",__FUNCTION__, funBit);
        return BSP_ERROR;
    }

    INPUT_POINTER_CHECK(flag);

    ret = BspRegBitValRd(0, REG_FPGA_MS_FUN_GET_FLAG, chip*2+funBit/16, funBit%16, funBit%16, flag);

    BspLog(LOG_LEVEL_0,"%s chip %d funbit %d *flag %d\n", __FUNCTION__, chip, funBit, *flag);

    return ret;
}


UINT32 BspClearMsSyncFlagFun(UINT32 chip, UINT32 funBit)
{
    UINT32 ret = BSP_OK;

    if(funBit >= 32)
    {
        dbgErr("%s:funBit is %d!\n",__FUNCTION__, funBit);
        return BSP_ERROR;
    }

    ret |= BspRegBitValWr(0, REG_FPGA_MS_FUN_SET_FLAG, chip*2+funBit/16, 0, funBit%16,  funBit%16);
    BspSysMsDelay_Sys(10);
    ret |= BspRegBitValWr(0, REG_FPGA_MS_FUN_SET_FLAG, chip*2+funBit/16, 1, funBit%16,  funBit%16);
    BspLog(LOG_LEVEL_0,"%s chip %d funbit %d \n", __FUNCTION__, chip, funBit);
    return ret;
}

VOID BspSetDflOutRangFlag(UINT32 flag)
{
    g_DflOutRangFlag = flag;
}

BOOL BspIsSupportDflOutRangByFreq(VOID)
{
    if (g_DflOutRangFlag == SUPPORT)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

VOID BspSetSfpSelfHealFlag(UINT32 flag)
{
    g_SfpSelfHealFlag = flag;
}

BOOL BspIsSupportSfpSelfHeal(VOID)
{
    if (g_SfpSelfHealFlag == SUPPORT)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

UINT32 BspResetSfpCallBack(FUNC_RESET_SFP pGetResetSfp)
{
    pResetSfp = pGetResetSfp;

    return BSP_OK;
}

UINT32 BspOptResetSfp(UINT32 optId)
{
    if (pResetSfp != NULL)
    {
        return pResetSfp(optId);
    }

    return BSP_OK;
}
UINT32 BspGetFanStatusCallBack(funcGetFanStatusCallBack pFuncCallBack)
{
    pGetFanStatusCallBack = pFuncCallBack;
    return BSP_OK;
}

UINT32 BspGetFanStatus(UINT32 *pStatus)
{
    *pStatus = 0;
    if(NULL != pGetFanStatusCallBack)
    {
        return pGetFanStatusCallBack(pStatus);
    }

    return BSP_OK;
}

/* Started by AICoder, pid:20c6762621d44ae4b31fc178c6dffee9 */
UINT32 BspGetPoeNumCallBack(funcGetPoeNumCallBack pFuncCallBack)
{
    pGetPoeNumCallBack = pFuncCallBack;
    return BSP_OK;
}

UINT32 BspGetPoeNum(UINT32 *pPoeNum)
{
    *pPoeNum = 0;
    if(NULL != pGetPoeNumCallBack)
    {
        return pGetPoeNumCallBack(pPoeNum);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:20c6762621d44ae4b31fc178c6dffee9 */

/* 是否支持功率共享，机型隔离 */
BOOL BspIsSupportPowShare(VOID)
{
    return FALSE;
}

/**********************************************************************
* 函数名称： BspSupportRebootDecoupling
* 功能描述： 是否支持版本解耦
* 输入参数： 
* 输出参数： 0 代表不支持， 1代表支持,仅mcs片复位。默认是0 仅9650支持
* 返 回 值： uRetVal
* 其它说明： 无
**********************************************************************/
/* Started by AICoder, pid:ib413333ad6da4b142890b47605ca163beb0c31a */
UINT32 BspSupportRebootDecoupleCallBack(BSP_SUPPORT_VER_DECOUPLE_CALLBACK_FUNCPTR pFuncCallback)
{
    pSupportVerDecoupleCallback = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSupportRebootDecoupling(VOID)
{
    UINT32 uRetVal = NOT_SUPPORT_VER_DECOUPLE;

    if(NULL != pSupportVerDecoupleCallback)
    {
        return pSupportVerDecoupleCallback();
    }
    else
    {
        return uRetVal;
    }
}
/* Ended by AICoder, pid:ib413333ad6da4b142890b47605ca163beb0c31a */

/* 移相器检测需求相关接口，高层平台调用，D42打桩 */
UINT32 BspSetDpsTddCfg(T_TddCfg *pTddIndCfg)
{
    return BSP_OK;
}

UINT32 BspSetDpsFrTmVal(UINT32 bandId, INT32 iFrTmVal)
{
    return BSP_OK;
}

UINT32 BspSetDpsUeAdvTime(UINT16 val)
{
    return BSP_OK;
}

/* Started by AICoder, pid:zfc46a8d35gaa37140d4087420ebde1742a24bb3 */
UINT32 UaeTempModeFlag = 0;  //阿联酋模式过温处理标志
UINT32 BspSetUaeTempModeFlag(UINT32 flag)
{
    UaeTempModeFlag = flag;
    return BSP_OK;
}

UINT32 BspGetUaeTempModeFlag(VOID)
{
    return UaeTempModeFlag;
}
/* Ended by AICoder, pid:zfc46a8d35gaa37140d4087420ebde1742a24bb3 */

/* Started by AICoder, pid:i26f597cc0w87da14af208caf050083c5d59c1f1 */
T_DefRruTempOffsetPara rruTempOffset = {0};
VOID BspSetTempOffset(T_DefRruTempOffsetPara *offset)
{
    INPUT_POINTER_CHECK_RETURN(offset);

    memcpy_s(&rruTempOffset, sizeof(T_DefRruTempOffsetPara), offset, sizeof(T_DefRruTempOffsetPara));

    return ;
}

VOID BspGetTempOffset(T_DefRruTempOffsetPara *offset)
{
    INPUT_POINTER_CHECK_RETURN(offset);

    memcpy_s(offset, sizeof(T_DefRruTempOffsetPara), &rruTempOffset, sizeof(T_DefRruTempOffsetPara));

    return ;
}

T_TempThresholdOffsetPara tempThresholdOffset = {0};
UINT32 BspSetTempThresholdOffset(T_TempThresholdOffsetPara *offset)
{
    INPUT_POINTER_CHECK(offset);

    memcpy_s(&tempThresholdOffset, sizeof(T_TempThresholdOffsetPara), offset, sizeof(T_TempThresholdOffsetPara));

    return BSP_OK;
}

VOID BspGetTempThresholdOffset(T_TempThresholdOffsetPara *offset)
{
    INPUT_POINTER_CHECK_RETURN(offset);

    memcpy_s(offset, sizeof(T_TempThresholdOffsetPara), &tempThresholdOffset, sizeof(T_TempThresholdOffsetPara));

    return ;
}
/* Ended by AICoder, pid:i26f597cc0w87da14af208caf050083c5d59c1f1 */

/* Started by AICoder, pid:14c57da8d4127a7143f10b9ed06db4110c977707 */
UINT32 BspManualSetRruTempThresholdOffset(INT32 offset)
{
    UINT32 retVal = BSP_OK;
    T_TempThresholdOffsetPara offsetConfig = {0};

    if(NO_SUPPORT == BspGetUaeTempModeFlag())
    {
        dbgErr("NoSupport the UAE_mode, is Error\n");
        return BSP_ERROR;
    }
    offsetConfig.pwrThresholdOffset = offset;
    offsetConfig.boardThresholdOffset = offset;
    offsetConfig.paThresholdOffset = offset;
    retVal = BspSetTempThresholdOffset(&offsetConfig);

    return retVal;
}
/* Ended by AICoder, pid:14c57da8d4127a7143f10b9ed06db4110c977707 */

/* Started by AICoder, pid:eba5fxbe20y733e1413d08abf073e61b4357d807 */
UINT32 BspGetRruTempThresholdOffset(INT32 *offset)
{
    T_TempThresholdOffsetPara offsetConfig = {0};

    INPUT_POINTER_CHECK(offset);

    if(NO_SUPPORT == BspGetUaeTempModeFlag())
    {
        dbgErr("NoSupport the UAE_mode, is Error\n");
        return BSP_ERROR;
    }
    BspGetTempThresholdOffset(&offsetConfig);
    *offset = offsetConfig.pwrThresholdOffset;  //单板，功放，电源的过温门限高层统一配置一个值，所以拿其中一个上报即可
    dbgInfoEx("pwrOffset:%d,boardOffset:%d,paOffset:%d\n", offsetConfig.pwrThresholdOffset, offsetConfig.boardThresholdOffset, offsetConfig.paThresholdOffset);

    return BSP_OK;
}
/* Ended by AICoder, pid:eba5fxbe20y733e1413d08abf073e61b4357d807 */

/* Started by AICoder, pid:oadacz7804o58781405e08b170734b2b86838f44 */
/**********************************************************************
* 函数名称： BspCopySlaveVerToTmp
* 功能描述： 高层检测到从片状态异常，在复位从片之前会调用，重新拷贝一次从片的版本到tmp下，解决从片版本字节错误的规避方案（供app调用）
* 输入参数： 无
* 输出参数：
* 返 回 值： BSP_OK
* 其它说明： 无
**********************************************************************/
UINT32 BspCopySlaveVerToTmp(VOID)
{
    UINT32 ret = BSP_OK;
    BspLog(LOG_LEVEL_0,"[%s] enter \n", __FUNCTION__);

    ret = BspExtractSocVerToTmp();
    if(BSP_ERROR == ret)
    {
        dbgInfo("[%s] BspExtractSocVer failed!!!\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0,"[%s] BspExtractSocVer failed!!!\n", __FUNCTION__);

    }
    return ret;
}
/* Ended by AICoder, pid:oadacz7804o58781405e08b170734b2b86838f44 */
/* Started by AICoder, pid:8b075e926a623ae1406a0837305006307115e0ca */
/*获取IC温度。D42 app使用 sensor0 结温作为IC温度*/
UINT32 BspGetIcTemp(INT32 *lMaxTemp)
{
    UINT32 retVal = BSP_OK;
    INT32 temp0 = 0;
    INT32 temp1 = 0;

    retVal = BspHalAdaptGetIcCalibrationTemp(&temp0, &temp1); /*temp单位:0.01摄氏度*/

    if ((NULL == lMaxTemp) || (BSP_OK != retVal))
    {
        dbgInfo("[%s] IcTemp = %.2lf degree, retVal = %d\n",
                __FUNCTION__, temp0 / 100.0, retVal);
        return BSP_ERROR;
    }
    else
    {
        *lMaxTemp = temp0 / 10; /*上报高层温度单位为 0.1摄氏度*/
    }

    return retVal;
}
/* Ended by AICoder, pid:8b075e926a623ae1406a0837305006307115e0ca */

/* Started by AICoder, pid:o2756p3f0f8c4c314a680996a0f3b70fc2851ca3 */
UINT32 BspGetSocNoResetFlag(VOID)
{
    const char *filename = "/ata/nosocreset";
    if (BspIsFileExist(filename) == BSP_OK)
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}
/* Ended by AICoder, pid:o2756p3f0f8c4c314a680996a0f3b70fc2851ca3 */

/* Started by AICoder, pid:w739encd61147e414ed7085fd0c02c10ed22fa96 */
static UINT32 s_upgradeFlag = 0;
UINT32 BspSetPwrUpgradeFlag(UINT32 flag)
{
    s_upgradeFlag = flag;
    return BSP_OK;
}

UINT32 BspGetPwrUpgradeFlag(VOID)
{
    return s_upgradeFlag;
}
/* Ended by AICoder, pid:w739encd61147e414ed7085fd0c02c10ed22fa96 */

UINT32 BspGetPrachBitMapInfo(T_PrachAntBitMapInfo *ptPrachBitMapInfo)
{
    return BSP_OK;
}
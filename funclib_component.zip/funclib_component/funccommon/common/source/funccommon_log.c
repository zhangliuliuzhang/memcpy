
#include <stdarg.h>

#include "bsppub.h"
#include "bspcomm.h"

#include "funccommon.h"
#include "funccommon_a.h"

#include "bspcommon.h"
#include "zprintf.h"





#define MAX_LOG_LBL_MASK  (LOG_ERR|LOG_WARN|LOG_INFO|LOG_DBG)
#define LOG_BSP (2)

typedef struct tagT_LogCtrl
{
    UINT32  level;
    char    name[16];
}T_LogCtrl;


static T_LogCtrl logCtrl[100] = {0};
static T_LogCtrl udpmsglogCtrl[100] = {0};
static T_LogCtrl resetlogCtrl[100] = {0};

static UINT32 logFileMaxSize = 0x100000;
static UINT32 logResetFileMaxSize = 0x100000;
static FILE *fpBspLog = NULL;
static FILE *fpBspUdpMsgLog = NULL;
static FILE *fpBspResetLog[2] = {0};
static UINT32 BspLogPrintX = SWITCH_ON;

static UINT32 resetLogTime[2]= {0};
static UINT32 resetLogCycleNum = 40;
static UINT32 resetLogTimeMax = 41;
static long lLocation = 0;

static UINT32 g_BspLogFileNum = 0;
static CHAR cBspLogPrefix[BSP_LOG_MAX_STRING_LEN] = "/tmplog/bsp_log/bsplog_";
static CHAR cBspLogFileDir[BSP_LOG_MAX_STRING_LEN] = "/tmplog/bsp_log/bsplog.txt";
CHAR * const cBspPathList[2] = {"/bin/tar", "/bin/rm"};
rsize_t rBspPathListSize = 2;
UINT32 BspLogPrintDirectoryFlag = 0;
const char *s_bspLogPathToFlash = "/ata/tmplog/";
uint64_t lastTime = 0;
uint64_t curTime = 0;

VOID logprintx(UINT32 data)
{
    BspLogPrintX = data;
}

#ifdef BUILD_WITH_OM_FUNC
VOID logrestart(VOID)
{
    if (fpBspLog != NULL)
    {
        rewind(fpBspLog);
    }
}
#endif

FILE * BspGetBspLogFp(UINT32 mod)
{
    UINT32 size;

    if (mod >= NELEMENTS(logCtrl))
    {
        return NULL;
    }

    if (fpBspLog == NULL)
    {
        return NULL;
    }

    size = ftell(fpBspLog);
    if (size > logFileMaxSize)
    {
        rewind(fpBspLog);
    }

    size = ftell(fpBspLog);
    if (size > logFileMaxSize)
    {
        return NULL;
    }

    return fpBspLog;
}


UINT32 BspSetLogFileName(const CHAR *logFileName)
{
    struct timeval nowtime = {0};

    if (NULL == logFileName)
    {
        return BSP_ERROR;
    }
#ifndef MULT_PROGRESS_S
    INT32 snpRet = BSP_OK;
    const CHAR * logName = "bsplog";

    if(BSP_LOG_PRINT_TO_FLASH == BspLogPrintDirectoryFlag)
    {
        snpRet = snprintf_s(cBspLogFileDir,sizeof(cBspLogFileDir),"%s%s.txt",s_bspLogPathToFlash,logFileName);
        SNPRINTF_S_CHECK(snpRet, sizeof(cBspLogFileDir));
        if(0 != strcmp(logFileName,logName))
        {
            snpRet = snprintf_s(cBspLogPrefix,sizeof(cBspLogPrefix),"/ata/tmplog/bsplog_m_");
            SNPRINTF_S_CHECK(snpRet, sizeof(cBspLogFileDir));
        }
        else
        {
            snpRet = snprintf_s(cBspLogPrefix,sizeof(cBspLogPrefix),"/ata/tmplog/bsplog_");
            SNPRINTF_S_CHECK(snpRet, sizeof(cBspLogFileDir));
        }
    }
    else
    {
        snpRet = snprintf_s(cBspLogFileDir,sizeof(cBspLogFileDir),"%s%s.txt",BspGetLogPath(),logFileName);
        SNPRINTF_S_CHECK(snpRet, sizeof(cBspLogFileDir));
        if(0 != strcmp(logFileName,logName))
        {
            snpRet = snprintf_s(cBspLogPrefix,sizeof(cBspLogPrefix),"/tmplog/bsp_log/bsplog_m_");
            SNPRINTF_S_CHECK(snpRet, sizeof(cBspLogFileDir));
        }
    }
#endif
    gettimeofday(&nowtime, NULL);
    //coverity[declaration_with_small_time_t:SUPPRESS]
    lastTime = nowtime.tv_sec;
    return BSP_OK;
}

VOID BspLogPrint(UINT32 mod, UINT32 level, const char *format, ...)
{
    FILE       *fp;
    va_list    ap;
    //INT8       temp[400] = {0};
    char       strTime[20] = {0};
    int fprtRet, vfprtRet, ffluRet;
    time_t timeRet;

    fp = BspGetBspLogFp(mod);
    if (fp == NULL || SWITCH_OFF == BspLogPrintX)
    {
        return ;
    }

    va_start(ap, format);
    if (logCtrl[mod].level & level)
    {
        //BspSecondToDate(strTime, sizeof(strTime), time(NULL), 0);
        timeRet = time(NULL);
        TIME_CHECK(timeRet);
        BspSecondToDate(strTime, sizeof(strTime), timeRet, 0);
        //snprintf(temp,sizeof(temp),"[%s]<%s>%s",strTime,logCtrl[mod].name,format);
        fprtRet = fprintf(fp, "[%s]<%s>", strTime, logCtrl[mod].name);
        FPRINTF_CHECK(fprtRet);
        vfprtRet = vfprintf(fp, format, ap);
        VFPRINTF_CHECK(vfprtRet);
        ffluRet = fflush(fp);
        FFLUSH_CHECK(ffluRet);
    }
    va_end(ap);
}

UINT32 BspLogAdd(const CHAR *name, UINT32 levelMask)
{
    UINT32 cnt;
    int snpRet;

    if (levelMask > MAX_LOG_LBL_MASK || name == NULL)
    {
        dbgErr("ERROR Input params.\n");
        return BSP_ERROR;
    }

    for (cnt = 0; cnt < NELEMENTS(logCtrl); cnt++)
    {
        if (0 == strcmp(logCtrl[cnt].name, name))
        {
            return cnt;
        }
    }

    for (cnt = 0; cnt < NELEMENTS(logCtrl); cnt++)
    {
        if (logCtrl[cnt].name[0] == '\0')
        {
            logCtrl[cnt].level = levelMask;
            snpRet = snprintf_s(logCtrl[cnt].name,sizeof(logCtrl[cnt].name),"%s\0",name);
            SNPRINTF_S_CHECK(snpRet, sizeof(logCtrl[cnt].name));
            return cnt;
        }
    }

    dbgErr("No free module space\n");
    return BSP_ERROR;
}


UINT32 BspLogPrintInit(UINT32 maxSize)
{
    FILE   *fp;
    UINT32 loop;
    char   logFileName[32] = {0};
    int fclsRet, snpRet;

    fp = fopen("/ata/bsplogtest","r");
    if (fp != NULL)
    {
        snpRet = snprintf_s(logFileName,sizeof(logFileName),"/ata/bsplog.txt");
        SNPRINTF_S_CHECK(snpRet, sizeof(logFileName));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
    }
    else
    {
        snpRet = snprintf_s(logFileName,sizeof(logFileName),"/bsplog.txt");
        SNPRINTF_S_CHECK(snpRet, sizeof(logFileName));
    }

    for (loop = 0; loop < 3 && fpBspLog == NULL; loop++)
    {
        fpBspLog = fopen(logFileName, "w+");
        if (fpBspLog == NULL)
        {
            dbgErr("%s fopen failed!\n", __FUNCTION__);
        }
    }

    logFileMaxSize = maxSize;
    return BSP_OK;
}

/* 支持指定日志文件名称，适用于同时运行多个业务MGR的场景 */
UINT32 BspLogPrintExtInit(UINT32 maxSize, const CHAR *fileName)
{
    FILE   *fp;
    char   logFileName[32] = {0};
    char   logFileNameTemp[32] = {0};
    int fclsRet, snpRet;
    const CHAR *bspLogPath = BspGetLogPath();
    char   logFileNameBak[32] = "/ata/tmplog/bsplogbak_bak.txt";

    BspMkdir("/tmplog/");

    BspMkdir(bspLogPath);
    fp = fopen("/ata/bsplogtest","r");
    if (fp != NULL)
    {
        snpRet = snprintf_s(logFileName,sizeof(logFileName),"%s%s.txt",s_bspLogPathToFlash,fileName);
        SNPRINTF_S_CHECK(snpRet, sizeof(logFileName));
        snpRet = snprintf_s(logFileNameTemp,sizeof(logFileNameTemp),"%s%s_bak.txt",s_bspLogPathToFlash,fileName);
        SNPRINTF_S_CHECK(snpRet, sizeof(logFileNameTemp));
        if(BSP_OK == BspIsFileExist(logFileName))
        {
            if(BSP_OK == BspIsFileExist(logFileNameTemp))
            {
                 (VOID)zte_rename_s(logFileNameTemp,logFileNameBak);    /*二次备份log*/
            }
            (VOID)zte_rename_s(logFileName,logFileNameTemp);
        }
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
    }
    else
    {
        snpRet = snprintf_s(logFileName,sizeof(logFileName),"%s%s.txt",BspGetLogPath(),fileName);
        SNPRINTF_S_CHECK(snpRet, sizeof(logFileName));
    }

    /*初始化不用打开，记录时带打开动作*/
    /*
    for (loop = 0; loop < 3 && fpBspLog == NULL; loop++)
    {
        fpBspLog = fopen(logFileName, "w+");
        if (fpBspLog == NULL)
        {
            dbgErr("%s fopen failed!\n", __FUNCTION__);
        }
    }
    */

    logFileMaxSize = maxSize;
    return BSP_OK;
}

VOID setloglevel(char *name, UINT32 levelMask)
{
    UINT32 cnt;

    if (name == NULL)
    {
        return ;
    }

    if (levelMask > MAX_LOG_LBL_MASK)
    {
        return ;
    }


    for (cnt = 0; cnt < NELEMENTS(logCtrl); cnt++)
    {
        if (logCtrl[cnt].name[0] == '\0')
        {
            continue;
        }
        if (strcmp(name,"all")==0 || strcmp(name,logCtrl[cnt].name)==0)
        {
            logCtrl[cnt].level = levelMask;
            dbgInfo("set level of module %s to 0x%x\n", logCtrl[cnt].name, levelMask);
        }
    }
}

#ifdef BUILD_WITH_OM_FUNC
VOID logctrlshow(VOID)
{
    UINT32 cnt = 0;
    UINT32 lvIdx;
    UINT32 lvMask;
    UINT32 maxMask = 0;

    dbgInfo("ModuleName       | ERROR  WARN  INFO  DEBUG\n");
    for (cnt = 0; cnt < NELEMENTS(logCtrl); cnt++)
    {
        if (logCtrl[cnt].name[0] == '\0')
        {
            continue;
        }

        dbgInfo("%-16s | ", logCtrl[cnt].name);
        for (maxMask = lvIdx = 0; lvIdx < 32 && maxMask < MAX_LOG_LBL_MASK; lvIdx++)
        {
            lvMask = (logCtrl[cnt].level >> lvIdx) & 0x01;
            dbgInfo("%5d ", lvMask);
            maxMask |= BIT_SET(lvIdx);
        }
        dbgInfo("\n");
    }
}
#endif

VOID logrestart_udpmsg(VOID)
{
    if (fpBspUdpMsgLog != NULL)
    {
        rewind(fpBspUdpMsgLog);
    }
}


FILE * BspGetBspLogFp_udpmsg(UINT32 mod)
{
    UINT32 size;

    if (mod >= NELEMENTS(udpmsglogCtrl))
    {
        return NULL;
    }

    if (fpBspUdpMsgLog == NULL)
    {
        return NULL;
    }

    size = ftell(fpBspUdpMsgLog);
    if (size > logFileMaxSize)
    {
        rewind(fpBspUdpMsgLog);
    }

    size = ftell(fpBspUdpMsgLog);
    if (size > logFileMaxSize)
    {
        return NULL;
    }

    return fpBspUdpMsgLog;
}


VOID BspLogPrint_udpmsg(UINT32 mod, UINT32 level, const char *format, ...)
{
    FILE       *fp;
    va_list    ap;
    //INT8       temp[400] = {0};
    char       strTime[20] = {0};
    int fprtRet, vfprtRet, ffluRet;
    time_t timeRet;

    fp = BspGetBspLogFp_udpmsg(mod);
    if (fp == NULL)
    {
        return ;
    }

    va_start(ap, format);
    if (udpmsglogCtrl[mod].level & level)
    {
        //BspSecondToDate(strTime, sizeof(strTime), time(NULL), 0);
        timeRet = time(NULL);
        TIME_CHECK(timeRet);
        BspSecondToDate(strTime, sizeof(strTime), timeRet, 0);
        //snprintf(temp,sizeof(temp),"[%s]<%s>%s",strTime,logCtrl[mod].name,format);
        fprtRet = fprintf(fp, "[%s]<%s>", strTime, udpmsglogCtrl[mod].name);
        FPRINTF_CHECK(fprtRet);
        vfprtRet = vfprintf(fp, format, ap);
        VFPRINTF_CHECK(vfprtRet);
        ffluRet = fflush(fp);
        FFLUSH_CHECK(ffluRet);
    }
    va_end(ap);
}

UINT32 BspLogAdd_udpmsg(const CHAR *name, UINT32 levelMask)
{
    UINT32 cnt;
    int snpRet;

    if (levelMask > MAX_LOG_LBL_MASK || name == NULL)
    {
        dbgErr("ERROR Input params.\n");
        return BSP_ERROR;
    }

    for (cnt = 0; cnt < NELEMENTS(udpmsglogCtrl); cnt++)
    {
        if (0 == strcmp(udpmsglogCtrl[cnt].name, name))
        {
            return cnt;
        }
    }

    for (cnt = 0; cnt < NELEMENTS(udpmsglogCtrl); cnt++)
    {
        if (udpmsglogCtrl[cnt].name[0] == '\0')
        {
            udpmsglogCtrl[cnt].level = levelMask;
            snpRet = snprintf_s(udpmsglogCtrl[cnt].name,sizeof(udpmsglogCtrl[cnt].name),"%s\0",name);
            SNPRINTF_S_CHECK(snpRet, sizeof(udpmsglogCtrl[cnt].name));
            return cnt;
        }
    }

    dbgErr("No free module space\n");
    return BSP_ERROR;
}



UINT32 BspLogPrintInit_udpmsg(UINT32 maxSize)
{
    FILE   *fp;
    UINT32 loop;
    char   logFileName[32] = {0};
    int fclsRet, snpRet;

    fp = fopen("/ata/udpmsgdebug","r");
    if (fp != NULL)
    {
        snpRet = snprintf_s(logFileName,sizeof(logFileName),"/ata/udpmsglog.txt");
        SNPRINTF_S_CHECK(snpRet, sizeof(logFileName));
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
    }
    else
    {
        return BSP_ERROR;
    }

    for (loop = 0; loop < 3 && fpBspUdpMsgLog == NULL; loop++)
    {
        fpBspUdpMsgLog = fopen(logFileName, "w+");
        if (fpBspUdpMsgLog == NULL)
        {
            dbgErr("%s fopen failed!\n", __FUNCTION__);
        }
    }

    logFileMaxSize = maxSize;
    return BSP_OK;
}

VOID setloglevel_udpmsg(char *name, UINT32 levelMask)
{
    UINT32 cnt;

    if (name == NULL)
    {
        return ;
    }

    if (levelMask > MAX_LOG_LBL_MASK)
    {
        return ;
    }


    for (cnt = 0; cnt < NELEMENTS(udpmsglogCtrl); cnt++)
    {
        if (udpmsglogCtrl[cnt].name[0] == '\0')
        {
            continue;
        }
        if (strcmp(name,"all")==0 || strcmp(name,udpmsglogCtrl[cnt].name)==0)
        {
            udpmsglogCtrl[cnt].level = levelMask;
            dbgInfo("set level of module %s to 0x%x\n", udpmsglogCtrl[cnt].name, levelMask);
        }
    }
}

VOID logctrlshow_udpmsg(VOID)
{
    UINT32 cnt = 0;
    UINT32 lvIdx;
    UINT32 lvMask;
    UINT32 maxMask = 0;

    dbgInfo("ModuleName       | ERROR  WARN  INFO  DEBUG\n");
    for (cnt = 0; cnt < NELEMENTS(udpmsglogCtrl); cnt++)
    {
        if (udpmsglogCtrl[cnt].name[0] == '\0')
        {
            continue;
        }

        dbgInfo("%-16s | ", udpmsglogCtrl[cnt].name);
        for (maxMask = lvIdx = 0; lvIdx < 32 && maxMask < MAX_LOG_LBL_MASK; lvIdx++)
        {
            lvMask = (udpmsglogCtrl[cnt].level >> lvIdx) & 0x01;
            dbgInfo("%5d ", lvMask);
            maxMask |= BIT_SET(lvIdx);
        }
        dbgInfo("\n");
    }
}

FILE * BspGetBspResetLogFp(UINT32 mod, UINT32 type)
{
    int fprtRet;

    if (mod >= NELEMENTS(resetlogCtrl))
    {
        return NULL;
    }

    if(type >= 2)
    {
        dbgErr("Input type = %d is Illegal! Out Of Boundary!\n", type);
        return NULL;
    }

    if (resetLogTime[type] % resetLogTimeMax >= resetLogCycleNum)
    {
        rewind(fpBspResetLog[type]);
        fprtRet = fprintf(fpBspResetLog[type], "%u %ld \n", resetLogTime[type],lLocation);
        FPRINTF_CHECK(fprtRet);
    }

    return fpBspResetLog[type];
}

VOID BspResetLogPrint(UINT32 mod, UINT32 level, UINT32 type, const char *format, ...)
{
    FILE       *fp;
    va_list    ap;
    char       strTime[20] = {0};
    int fprtRet, vfprtRet, ffluRet ,fseekRet;

    time_t timeRet;

    if(mod >= 100)
    {
        dbgErr("%s>>Input mod = %d is Illegal! Out Of Boundary!\n", __FUNCTION__,mod);
        return ;
    }

    if(type >= 2)
    {
        dbgErr("%s>>Input type = %d is Illegal! Out Of Boundary!\n", __FUNCTION__,type);
        return ;
    }

    fp = BspGetBspResetLogFp(mod, type);
    if (fp == NULL || SWITCH_OFF == BspLogPrintX)
    {
        return ;
    }

    va_start(ap, format);
    if (resetlogCtrl[mod].level & level)
    {
        //BspSecondToDate(strTime, sizeof(strTime), time(NULL), 0);
        timeRet = time(NULL);
        TIME_CHECK(timeRet);
        BspSecondToDate(strTime, sizeof(strTime), timeRet, 0);
        //snprintf(temp,sizeof(temp),"[%s]<%s>%s",strTime,logCtrl[mod].name,format);
        fprtRet = fprintf(fp, "------------------------------------[%u][%s]------------------------------------\n",resetLogTime[type],(char *)strTime);
        FPRINTF_CHECK(fprtRet);
        vfprtRet = vfprintf(fp, format, ap);
        VFPRINTF_CHECK(vfprtRet);
        ffluRet = fflush(fp);
        FFLUSH_CHECK(ffluRet);
        if((resetLogTime[type] + 1U) < 0xFFFFFFFFU)
        {
            resetLogTime[type]++;
            resetLogTime[type] = (resetLogTime[type] >= 400) ? 0 : resetLogTime[type];
        }
        else
        {
            dbgErr("%s>>Unsigned Subtraction Wrap Error!\n", __FUNCTION__);
        }
        lLocation = ftell(fpBspResetLog[type]);
        if(lLocation < ((long)0))
        {
            dbgErr("%s(%d) warning! > ftell ret'%ld! \n", __FUNCTION__, __LINE__, lLocation);
        }
        fseekRet = fseek(fpBspResetLog[type], 0, SEEK_SET);
        FSEEK_CHECK(fseekRet);
        fprtRet = fprintf(fp, "%u %ld ", resetLogTime[type],lLocation);
        FPRINTF_CHECK(fprtRet);
        if(lLocation < 0)
        {
            dbgErr("%s>>ftell = %ld is Illegal!\n", __FUNCTION__,lLocation);
        }
        else
        {
            fseekRet = fseek(fpBspResetLog[type], lLocation, SEEK_SET);
            FSEEK_CHECK(fseekRet);
        }
    }
    va_end(ap);
}

UINT32 BspResetLogAdd(const CHAR *name, UINT32 levelMask)
{
    UINT32 cnt;
    int snpRet;

    if (levelMask > MAX_LOG_LBL_MASK || name == NULL)
    {
        dbgErr("ERROR Input params.\n");
        return BSP_ERROR;
    }

    for (cnt = 0; cnt < NELEMENTS(resetlogCtrl); cnt++)
    {
        if (0 == strcmp((char *)resetlogCtrl[cnt].name, name))
        {
            return cnt;
        }
    }

    for (cnt = 0; cnt < NELEMENTS(resetlogCtrl); cnt++)
    {
        if (resetlogCtrl[cnt].name[0] == '\0')
        {
            resetlogCtrl[cnt].level = levelMask;
            snpRet = snprintf_s((char *)resetlogCtrl[cnt].name,(int)sizeof(resetlogCtrl[cnt].name),"%s\0",name);
            SNPRINTF_S_CHECK(snpRet, sizeof(resetlogCtrl[cnt].name));
            return cnt;
        }
    }

    dbgErr("No free module space\n");
    return BSP_ERROR;
}


UINT32 BspResetLogPrintInit(UINT32 maxSize)
{
    FILE   *fp;
    UINT32 loop;
    UINT32 ulType;
    INT8  logFileDir[2][32] = {"/ata","/ata/.log"};
    INT8  logFileName[2][32] = {"/ata/bspresetlog.txt","/ata/.log/bspresetlog.txt"};
    int fclsRet, snpRet;

    for(ulType = 0; ulType < 2; ulType++)
    {
        fp = fopen((char *)logFileDir[ulType],(char *)"r");
        if (fp != NULL)
        {
            fclsRet = fclose(fp);
            FCLOSE_CHECK(fclsRet);
            dbgInfo("%s>> %s open succss!\n",__FUNCTION__,logFileDir[ulType]);

            for (loop = 0; loop < 3 && fpBspResetLog[ulType] == NULL; loop++)
            {
                fpBspResetLog[ulType] = fopen((char *)logFileName[ulType], (char *)"r+");
                if(fpBspResetLog[ulType] != NULL)
                {
                    snpRet = fseek(fpBspResetLog[ulType], 0, SEEK_SET);
                    FSEEK_CHECK(snpRet);
                    //coverity[cert_err34_c_violation:SUPPRESS]
                    snpRet = fscanf(fpBspResetLog[ulType],"%u %ld",&resetLogTime[ulType],&lLocation);
                    FSCANF_CHECK(snpRet);
                    snpRet = fseek(fpBspResetLog[ulType], lLocation, SEEK_SET);
                    FSEEK_CHECK(snpRet);
                }
                else
                {
                    fpBspResetLog[ulType] = fopen((char *)logFileName[ulType], (char *)"w+");
                    if(fpBspResetLog[ulType] != NULL)
                    {
                        snpRet = fprintf(fpBspResetLog[ulType], "%u %ld \n", resetLogTime[ulType],lLocation);
                        FPRINTF_CHECK(snpRet);
                    }
                }

                if (fpBspResetLog[ulType] == NULL)
                {
                    dbgErr("%s>> fopen %s failed!\n", __FUNCTION__,logFileName[ulType]);
                }
            }
        }
        else
        {
            dbgErr("%s>> %s open Err!\n",__FUNCTION__,logFileDir[ulType]);
        }

    }
    logResetFileMaxSize = maxSize;

    return BSP_OK;
}

VOID SetResetLogLevel(UINT8 *name, UINT32 levelMask)
{
    UINT32 cnt;

    if (name == NULL)
    {
        return ;
    }

    if (levelMask > MAX_LOG_LBL_MASK)
    {
        return ;
    }


    for (cnt = 0; cnt < NELEMENTS(resetlogCtrl); cnt++)
    {
        if (resetlogCtrl[cnt].name[0] == '\0')
        {
            continue;
        }
        if (strcmp((char *)name,(char *)"all")==0 || strcmp((char *)name,(char *)resetlogCtrl[cnt].name)==0)
        {
            resetlogCtrl[cnt].level = levelMask;
            dbgInfo("set level of module %s to 0x%x\n", resetlogCtrl[cnt].name, levelMask);
        }
    }
}

#ifdef BUILD_WITH_OM_FUNC
VOID LogResetCtrlShow(VOID)
{
    UINT32 cnt = 0;
    UINT32 lvIdx;
    UINT32 lvMask;
    UINT32 maxMask = 0;

    dbgInfo("ModuleName       | ERROR  WARN  INFO  DEBUG\n");
    for (cnt = 0; cnt < NELEMENTS(resetlogCtrl); cnt++)
    {
        if (resetlogCtrl[cnt].name[0] == '\0')
        {
            continue;
        }

        dbgInfo("%-16s | ", resetlogCtrl[cnt].name);
        for (maxMask = lvIdx = 0; lvIdx < 32 && maxMask < MAX_LOG_LBL_MASK; lvIdx++)
        {
            lvMask = (resetlogCtrl[cnt].level >> lvIdx) & 0x01;
            dbgInfo("%5d ", lvMask);
            maxMask |= BIT_SET(lvIdx);
        }
        dbgInfo("\n");
    }
}
#endif

INT32 BspLog(UINT32 logLevel, const CHAR *format, ...)
{
    UINT32 bspLogLevel = 0;
    INT64 size = 0;
    INT32 iRet = 0;
    CHAR cBspLogBz2Suffix[BSP_LOG_MAX_STRING_LEN];
    CHAR cBspLogBz2Dir[BSP_LOG_MAX_STRING_LEN];
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;

    bspLogLevel = BspGetAreaLogLevel(LOG_BSP);
    if(logLevel > bspLogLevel)
    {
        return BSP_OK;
    }

    iRet = BspGetLogFileLen(&size);
    if ((INT32)BSP_OK != (iRet))
    {
        dbgErr("[%s], line: %u iRet'%d Error \n", __FUNCTION__, __LINE__, (iRet));
        return BSP_INT_ERROR;
    }

    iRet = zte_strncpy_s(cBspLogBz2Dir, sizeof(cBspLogBz2Dir), cBspLogPrefix, sizeof(cBspLogPrefix));
    ZTE_SECURITY_FUNC_CHECK(iRet);

    iRet = zte_snprintf_s(cBspLogBz2Suffix, sizeof(cBspLogBz2Suffix), "%u.tar.gz", g_BspLogFileNum);
    ZTE_SECURITY_FUNC_CHECK(iRet);

    iRet = zte_strncat_s(cBspLogBz2Dir, sizeof(cBspLogBz2Dir), cBspLogBz2Suffix, sizeof(cBspLogBz2Suffix));
    ZTE_SECURITY_FUNC_CHECK(iRet);

    if (size >= BSP_LOG_MAX_SIZE)/*当前文件写满，需要压缩并新建*/
    {
        CHAR * const cCommandTarBz2[5] = {"tar", "-zcvf", cBspLogBz2Dir, cBspLogFileDir, NULL};
        rsize_t uiCommandTarBz2Len = 5;
        CHAR * const cCommandRmFile[3] = {"rm", cBspLogFileDir, NULL};
        rsize_t uiCommandRmFileLen = 3;

        iRet = zte_system_s("/bin/tar",
                            cCommandTarBz2,
                            uiCommandTarBz2Len,
                            cBspPathList,
                            rBspPathListSize);/*创建tar.bz2压缩文件*/
        ZTE_SECURITY_FUNC_CHECK(iRet);
        iRet = zte_system_s("/bin/rm",
                            cCommandRmFile,
                            uiCommandRmFileLen,
                            cBspPathList,
                            rBspPathListSize);/*删除原始log*/
        ZTE_SECURITY_FUNC_CHECK(iRet);

        struct timeval nowtime = {0};
        gettimeofday(&nowtime, NULL);
        //coverity[declaration_with_small_time_t:SUPPRESS]
        curTime = nowtime.tv_sec;
        if (curTime - lastTime > 3) /*当前压缩时间与上次压缩时间之差至少要大于3秒，才会重新压缩*/
        {
            g_BspLogFileNum +=1;
            lastTime = curTime;
        }
        if(BSP_LOG_MAX_FILE_NUM == g_BspLogFileNum)
        {
            g_BspLogFileNum = 0;
        }
        iRet = BspGetLogFileLen(&size);/*重新初始化log文件*/
    }
    if (size < BSP_LOG_MAX_SIZE)
    {

        FILE *pFile = NULL;
        iRet = zte_fopen_s(&pFile, cBspLogFileDir, "a+", cDirList, rDirListSize);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        if(pFile == NULL)
        {
            dbgErr("%s %d, fail to open file! \n", __FUNCTION__, __LINE__);
            return BSP_ERROR;
        }
        va_list arg;

        va_start(arg, format);
        struct tm timelog;
        struct tm* tm_log = NULL;
        struct timeval nowtime;
        gettimeofday(&nowtime, NULL);
        //coverity[declaration_with_small_time_t:SUPPRESS]
        time_t seconds = nowtime.tv_sec;
        memset(&timelog, 0, sizeof(timelog));
        tm_log = localtime_r(&seconds, &timelog);

        if(tm_log != NULL)
        {
            iRet = fprintf(pFile, "%04d-%02d-%02d %02d:%02d:%02d.%06ld|%d| ",
                                    tm_log->tm_year + 1900,
                                    tm_log->tm_mon+1,
                                    tm_log->tm_mday,
                                    tm_log->tm_hour,
                                    tm_log->tm_min,
                                    tm_log->tm_sec,
                                    nowtime.tv_usec,
                                    logLevel);
            FPRINTF_CHECK(iRet);
        }

        //ZTE_SECURITY_FUNC_CHECK(iRet);
        (void)zte_vfprintf_s(pFile, format, arg);
        //FPRINTF_CHECK(iRet);
        va_end(arg);
        iRet = fflush(pFile);
        FFLUSH_CHECK(iRet);
        iRet = fclose(pFile);
        FCLOSE_CHECK(iRet);
    }
    return iRet;
}

INT64 BspGetLogFileLen(INT64 *size)
{
    FILE *pFile;
    INT64 liTmpSize;
    INT32 iRet = 0;

    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;

    iRet = zte_fopen_s(&pFile, cBspLogFileDir, "rb", cDirList, rDirListSize);
    if ( pFile == NULL)
    {
        liTmpSize = 0;
    }
    else
    {
        iRet =fseek(pFile, 0, SEEK_END);
        FSEEK_CHECK(iRet);
        liTmpSize = ftell(pFile);
        if(liTmpSize < ((INT64)0))
        {
            dbgErr("%s(%d) warning! > ftell ret'%lld! \n", __FUNCTION__, __LINE__, liTmpSize);
        }
        iRet = fclose(pFile);
        FCLOSE_CHECK(iRet);
    }
    *size = liTmpSize;
    return BSP_OK;
}

UINT32 BspSetLogPrintDirFlag(UINT32 flag)
{
    BspLogPrintDirectoryFlag = flag;
    return BSP_OK;
}

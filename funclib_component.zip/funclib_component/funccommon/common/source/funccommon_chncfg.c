/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : funccommon_chncfg.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : wangfei
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "bspcomm.h"
#include "bsppub.h"
#include "funccommon_chncfg.h"
#include "ru_univdef.h"
#include "funccommon_carrmap.h"
#include "exprn.h"
#include <pthread.h>
#include "funccommonapi.h"
#include "vxadp.h"
#include "funccommon_log.h"

static UINT32 s_ulIsQcellFlag = 0xffffffff;

#define RRU_CFG_PARA_CHK_CONTINUE(a)  if ((a) == 0 || (a) == BSP_ERROR) continue

static pthread_rwlock_t s_CarrCfgWrSem = PTHREAD_RWLOCK_INITIALIZER;
static pthread_rwlock_t s_VswrCfgWrSem = PTHREAD_RWLOCK_INITIALIZER;
static pthread_rwlock_t s_FddCellAntWrSem = PTHREAD_RWLOCK_INITIALIZER;
static pthread_rwlock_t s_CarrCfgWrSem_original = PTHREAD_RWLOCK_INITIALIZER;
static pthread_rwlock_t s_carrPowRwSem = PTHREAD_RWLOCK_INITIALIZER;
static pthread_rwlock_t s_DifCfgRwSem = PTHREAD_RWLOCK_INITIALIZER;

static T_RruRfCfgInfo       *s_rruCarrCfg = NULL;
static T_RruRfCfgInfo       *s_rruCarrCfg_original = NULL;//保存真实大包配置信息传递给DSP，解决IC3.0支持GSM制式载波通道小区信息传递异常问题
static T_RruVswrInfo        *s_RruVswrCfg = NULL;
static T_FddCellAntInfo     s_CellAntCfg = {0};
static T_RruBandCfgInfo     *s_difTxCarrCfg = NULL;
/* static T_RruBandCfgInfo     s_difRxCarrCfg[BSP_MAX_TX_CHAN] = {0}; */
static T_RruCarrPowCfgInfo  *s_rruCarrPowCfg = NULL;
static UINT32              s_RruMaxCarrBw[2][BSP_MAX_TX_CHAN][DIF_RADIOMODE_MAX] = {0};
static UINT32              s_RruRadioMode = BSP_RADIO_STANDARD_5G;

static FUNC_CUSTOM_CARRCFG_CHECK pCustomCarrCfgCheck = NULL; 
static UINT32 g_ulCellActSta[BSP_MAX_TX_CHAN][PRX][PRODUCT_MODE_MAXNUM][BSP_MAX_CARR_NUM] = {0};
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/


/**************************************************************************
 *                        宏定义
 **************************************************************************/


/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数实现
 **************************************************************************/
/******************************************************************************
 *  函数名称   : RwSemInit(*)
 *  功能描述   : 读写控制结构初始化
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ptSem - 读写控制结构
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 初始化成功; 其他 - 初始化失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wangfei  @2017-7-27 11:04:48
 *-----------------------------------------------------------------------------
 */
static UINT32 RwSemInit(T_RwSem *ptSem)
{
    INPUT_POINTER_CHECK(ptSem);
    dbgInfo("in RwSemInit\n");

    if (0 != sem_init(&ptSem->RwSem, 1, 1))
    {
        dbgErr("Read&Write semaphore initializ faild!\n");
        return BSP_ERROR;
    }

    ptSem->ulInit = 1;
    ptSem->lCounter = 0;
    dbgInfo("Read&Write semaphore initializ success!\n");
    return BSP_OK;
}


UINT32 BspSetIsQcellFlag(UINT32 ulQcellFlag)
{
    s_ulIsQcellFlag = ulQcellFlag;
    return BSP_OK;
}



static UINT32 pthreadRdSemTake(pthread_rwlock_t *ptSem)
{
    INT32 lTimes = 40;
	while(lTimes--)
	{
		if(0 == pthread_rwlock_tryrdlock(ptSem))
		{
            return BSP_OK;
		}
		BspSysMsDelay_Sys(50);
	}
    return BSP_ERROR;
}

static UINT32 pthreadWrSemTake(pthread_rwlock_t *ptSem)
{
    INT32 lTimes = 40;
	while(lTimes--)
	{
		if(0 == pthread_rwlock_trywrlock(ptSem))
		{
            return BSP_OK;
		}
        BspSysMsDelay_Sys(50);
	}
    return BSP_ERROR;
}


static UINT32 pthreadRdSemGive(pthread_rwlock_t *ptSem)
{
    return pthread_rwlock_unlock(ptSem);
}

static UINT32 pthreadWrSemGive(pthread_rwlock_t *ptSem)
{
    return pthread_rwlock_unlock(ptSem);
}

T_RruCfgCarrAntPortInfo g_stRruCarrPortCfg = {0};

static T_RruRfCfgInfo *BspGetRruCarrCfgMem(void)
{
    if (s_rruCarrCfg == NULL)
    {
        s_rruCarrCfg = (T_RruRfCfgInfo *)malloc(sizeof(T_RruRfCfgInfo) * BSP_MAX_TX_CHAN);
        if (s_rruCarrCfg == NULL)
        {
            return NULL;
        }
        zte_memset_s(s_rruCarrCfg, sizeof(T_RruRfCfgInfo) * BSP_MAX_TX_CHAN, 0, sizeof(T_RruRfCfgInfo) * BSP_MAX_TX_CHAN);
    }
    return s_rruCarrCfg;
}

/******************************************************************************
 *  函数名称   : BspSetRruCfgPara(*)
 *  功能描述   : 更新RRU射频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ptRruCfgPara - 新的RRU射频配置参数
 *  输出参数   : 无
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *工装使用申明: 工装使用接口，请注意波及
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wangfei  @2017-7-27 11:04:48
 *-----------------------------------------------------------------------------
 */

UINT32 BspSetRruCfgPara(UINT32 rfChn,T_RruRfCfgInfo *pRruCfgInfo)
{
    T_RruRfCfgInfo *rruCarrCfg = BspGetRruCarrCfgMem();
    INPUT_POINTER_CHECK(rruCarrCfg);
    INPUT_POINTER_CHECK(pRruCfgInfo);
	if(rfChn >= BSP_MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}

    if(BSP_OK != pthreadWrSemTake(&s_CarrCfgWrSem)) /*(BSP_OK != WriteSemTake(&s_CarrCfgRwSem))*/
    {
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy((char *)&rruCarrCfg[rfChn], (char *)pRruCfgInfo, sizeof(T_RruRfCfgInfo));
    pthreadWrSemGive(&s_CarrCfgWrSem);
    return BSP_OK;
}

static T_RruRfCfgInfo *BspGetRruCarrCfgOriginalMem(void)
{
    if (s_rruCarrCfg_original == NULL)
    {
        s_rruCarrCfg_original = (T_RruRfCfgInfo *)malloc(sizeof(T_RruRfCfgInfo) * BSP_MAX_TX_CHAN);
        if (s_rruCarrCfg_original == NULL)
        {
            return NULL;
        }
        zte_memset_s(s_rruCarrCfg_original, sizeof(T_RruRfCfgInfo) * BSP_MAX_TX_CHAN, 0, sizeof(T_RruRfCfgInfo) * BSP_MAX_TX_CHAN);
    }
    return s_rruCarrCfg_original;
}

UINT32 BspSetRruCfgPara_original(UINT32 rfChn,T_RruRfCfgInfo *pRruCfgInfo)
{
    T_RruRfCfgInfo *rruCarrCfg_original = BspGetRruCarrCfgOriginalMem();
    INPUT_POINTER_CHECK(rruCarrCfg_original);
    INPUT_POINTER_CHECK(pRruCfgInfo);
	if(rfChn >= BSP_MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}

    if(BSP_OK != pthreadWrSemTake(&s_CarrCfgWrSem_original)) /*(BSP_OK != WriteSemTake(&s_CarrCfgRwSem))*/
    {
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy((char *)&rruCarrCfg_original[rfChn], (char *)pRruCfgInfo, sizeof(T_RruRfCfgInfo));
    pthreadWrSemGive(&s_CarrCfgWrSem_original);

    dbgInfo("%s>>BspChnl'%d\n",__FUNCTION__, rfChn);

    return BSP_OK;
}
/******************************************************************************
 *  函数名称   : BspSetRruCfgPara(*)
 *  功能描述   : 更新RRU射频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ptRruCfgPara - 新的RRU射频配置参数
 *  输出参数   : 无
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *工装使用申明: 工装使用接口，请注意波及
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wangfei  @2017-7-27 11:04:48
 *-----------------------------------------------------------------------------
 */

UINT32 BspClrRruCfgPara(UINT32 rfChn)
{
    T_RruRfCfgInfo *rruCarrCfg = BspGetRruCarrCfgMem();
    INPUT_POINTER_CHECK(rruCarrCfg);
	if(rfChn >= BSP_MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}

    if(BSP_OK != pthreadWrSemTake(&s_CarrCfgWrSem)) /*(BSP_OK != WriteSemTake(&s_CarrCfgRwSem))*/
    {
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((char *)&rruCarrCfg[rfChn], 0, sizeof(T_RruRfCfgInfo));
    pthreadWrSemGive(&s_CarrCfgWrSem);
    return BSP_OK;
}

/******************************************************************************
 *  函数名称   : BspClrRruRfCfgPara(*)
 *  功能描述   : 清除RRU射频配置参数
 *  输入参数   : bspChan -- BSP通道号; dir -- 方向（1:下行, 0:上行）
 *  输出参数   : rruCarrCfg - 新的RRU射频配置参数
 *  返 回 值   : BSP_OK: 清除成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wangfei  @2017-7-27 11:04:48
 *-----------------------------------------------------------------------------
 */
UINT32 BspClrRruRfCfgPara(UINT32 bspChan, UINT32 dir)
{
    UINT32 loop = 0;
    T_RruRfCfgInfo *rruCarrCfg = BspGetRruCarrCfgMem();

    INPUT_POINTER_CHECK(rruCarrCfg);
	if(bspChan >= BSP_MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}

    if(BSP_OK != pthreadWrSemTake(&s_CarrCfgWrSem))
    {
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (TX == dir)
    {
        rruCarrCfg[bspChan].txCfgCarrSum = 0;
        rruCarrCfg[bspChan].txCenterFreq = 0;
        rruCarrCfg[bspChan].txRfRangeMinFreq = 0;
        rruCarrCfg[bspChan].txRfRangeMaxFreq = 0;
        rruCarrCfg[bspChan].txRfRangeMinFreqB2 = 0;
        rruCarrCfg[bspChan].txRfRangeMaxFreqB2 = 0;

        for (loop = 0; loop < BSP_MAX_BAND_PER_CH; loop++)
        {
            rruCarrCfg[bspChan].txbandFreq[loop] = 0;
        }

        for (loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
        {
            rruCarrCfg[bspChan].carr[loop].carrTxNo = 0;
            rruCarrCfg[bspChan].carr[loop].carrTxFreq = 0;
            rruCarrCfg[bspChan].carr[loop].carrTxBw = 0;
            rruCarrCfg[bspChan].carr[loop].carrTxRadio = 0;
        }
    }
    else
    {
        rruCarrCfg[bspChan].rxCfgCarrSum = 0;
        rruCarrCfg[bspChan].rxCenterFreq = 0;
        rruCarrCfg[bspChan].rxRfRangeMinFreq = 0;
        rruCarrCfg[bspChan].rxRfRangeMaxFreq = 0;
        rruCarrCfg[bspChan].rxRfRangeMinFreqB2 = 0;
        rruCarrCfg[bspChan].rxRfRangeMaxFreqB2 = 0;

        for (loop = 0; loop < BSP_MAX_BAND_PER_CH; loop++)
        {
            rruCarrCfg[bspChan].rxbandFreq[loop] = 0;
        }

        for (loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
        {
            rruCarrCfg[bspChan].carr[loop].carrRxNo = 0;
            rruCarrCfg[bspChan].carr[loop].carrRxFreq = 0;
            rruCarrCfg[bspChan].carr[loop].carrRxBw = 0;
            rruCarrCfg[bspChan].carr[loop].carrRxRadio = 0;
        }
    }

    pthreadWrSemGive(&s_CarrCfgWrSem);

    return BSP_OK;
}

UINT32 BspClrRruCfgPara_original(UINT32 rfChn)
{
    T_RruRfCfgInfo *rruCarrCfg_original = BspGetRruCarrCfgOriginalMem();
    INPUT_POINTER_CHECK(rruCarrCfg_original);
	if(rfChn >= BSP_MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}

    if(BSP_OK != pthreadWrSemTake(&s_CarrCfgWrSem_original)) /*(BSP_OK != WriteSemTake(&s_CarrCfgRwSem))*/
    {
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((char *)&rruCarrCfg_original[rfChn], 0, sizeof(T_RruRfCfgInfo));
    pthreadWrSemGive(&s_CarrCfgWrSem_original);
    dbgInfo("%s>>BspChnl'%d\n",__FUNCTION__,rfChn);
    return BSP_OK;
}

static T_RruVswrInfo *BspGetRruVswrCfgMem(void)
{
    if (s_RruVswrCfg == NULL)
    {
        size_t bufLen = 0;
        bufLen = sizeof(T_RruVswrInfo) * BSP_MAX_TX_CHAN;
        s_RruVswrCfg = (T_RruVswrInfo *)malloc(bufLen);
        INPUT_POINTER_CHECK_RETURN_NULL(s_RruVswrCfg);
        memset_s(s_RruVswrCfg, bufLen, 0, bufLen);
    }
    return s_RruVswrCfg;
}

UINT32 BspSetRruCfgPara_5G(UINT32 rfChn,T_RruVswrInfo *pRruVswrInfo)
{
    T_RruVswrInfo *rruVswrCfg = BspGetRruVswrCfgMem();
    INPUT_POINTER_CHECK(rruVswrCfg);
    INPUT_POINTER_CHECK(pRruVswrInfo);
	if(rfChn >= BSP_MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}
    if(BSP_OK != pthreadWrSemTake(&s_VswrCfgWrSem)) /*(BSP_OK != WriteSemTake(&s_CarrCfgRwSem))*/
    {
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy((char *)&rruVswrCfg[rfChn], (char *)pRruVswrInfo, sizeof(T_RruVswrInfo));
    pthreadWrSemGive(&s_VswrCfgWrSem);
    return BSP_OK;
}

UINT32 BspGetChnlCfgCarrPara_5G(UINT32 rfChn, T_RruVswrInfo *pRruVswrInfo)
{
    T_RruVswrInfo *rruVswrCfg = BspGetRruVswrCfgMem();
    INPUT_POINTER_CHECK(rruVswrCfg);
    INPUT_POINTER_CHECK(pRruVswrInfo);

	if(rfChn >= BSP_MAX_TX_CHAN)
	{
		return BSP_ERROR;
	}

    if (BSP_OK != pthreadRdSemTake(&s_VswrCfgWrSem))
    {
        return BSP_ERROR;
    }
    memcpy((char *)pRruVswrInfo, (char *)&rruVswrCfg[rfChn], sizeof(T_RruVswrInfo));

    pthreadRdSemGive(&s_VswrCfgWrSem);

    return BSP_OK;
}

/* Started by AICoder, pid:1e5bau0f36r93de14b710b04b087e944762446dc */
UINT32 BspGetRruVswrInfo(UINT32 rfChn, T_RruVswrInfo *pRruVswrInfo)
{
    UINT32 carr_loop = 0;
    // NCR 1821机型做特殊处理，方案提到当前SSB配置固定写死，及其他DSP侧计算矢量驻波会用到的参数
    if(IS_NCR == BspIsNcr())
    {
        T_RruVswrInfo *rruVswrCfg = BspGetRruVswrCfgMem();
        INPUT_POINTER_CHECK(rruVswrCfg);
        INPUT_POINTER_CHECK(pRruVswrInfo);

        if(rfChn >= BSP_MAX_TX_CHAN)
        {
            return BSP_ERROR;
        }

        dbgInfo("[%s] [%d] uiCarrNum %d\n", __FUNCTION__, __LINE__, rruVswrCfg[rfChn].uiCarrNum);

        if (BSP_MAX_CARR_NUM <= rruVswrCfg[rfChn].uiCarrNum)
        {
            return BSP_ERROR;
        }

        if (BSP_OK != pthreadRdSemTake(&s_VswrCfgWrSem))
        {
            return BSP_ERROR;
        }
        for(carr_loop = 0; carr_loop < rruVswrCfg[rfChn].uiCarrNum; carr_loop++)
        {
            dbgInfo("[%s] [%d] uiSsbFreq %d\n", __FUNCTION__, __LINE__,
                            rruVswrCfg[rfChn].carr[carr_loop].uiSsbFreq);
            rruVswrCfg[rfChn].carr[carr_loop].uiSubCarrierSpacing = 0; //15khz
            // rruVswrCfg.carr[carr_loop].uiSsbGscn = 0;
            rruVswrCfg[rfChn].carr[carr_loop].uiSsbSubBeamValidL = 0;
            rruVswrCfg[rfChn].carr[carr_loop].uiSsbSubBeamValidH = 268435456;
            rruVswrCfg[rfChn].carr[carr_loop].uiSsbPeriod = 2; //20ms周期
            // rruVswrCfg.carr[carr_loop].iFraAHeadAdj;
        }
        memcpy_s((char *)pRruVswrInfo, sizeof(T_RruVswrInfo), (char *)&rruVswrCfg[rfChn], sizeof(T_RruVswrInfo));

        pthreadRdSemGive(&s_VswrCfgWrSem);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:1e5bau0f36r93de14b710b04b087e944762446dc */

UINT32 BspSetCarrAntPortNum(T_RruCfgCarrAntPortInfo *stRruCarrPortCfg)
{
    INPUT_POINTER_CHECK(stRruCarrPortCfg);

	memcpy_s((VOID*)&g_stRruCarrPortCfg, sizeof(T_RruCfgCarrAntPortInfo), (VOID*)stRruCarrPortCfg, sizeof(T_RruCfgCarrAntPortInfo));
	
	return BSP_OK;
}

UINT32 BspGetCarrAntPortNum(UINT32 chan, UINT32 carr, UINT32 *pAntPortNum)
{
	UINT32 loop = 0;
	
	INPUT_POINTER_CHECK(pAntPortNum);

    if (chan >= 32)
    {
        dbgErr("%s Index chan is outside the bounds of maximum!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    
	if(carr < BSP_MAX_CARR_NUM)
	{
		for(loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
		{
			if(carr == g_stRruCarrPortCfg.carrPort[loop].carrNo)
			{
				*pAntPortNum = g_stRruCarrPortCfg.carrPort[loop].carrPortNum[chan];
				return BSP_OK;
			}
		}	
	}

	*pAntPortNum = 0xf;
	
	return BSP_ERROR;
}


UINT32 BspSetCellAntInfo(T_FddCellAntInfo *pCellAntInfo)
{
    INPUT_POINTER_CHECK(pCellAntInfo);
	
    if(BSP_OK != pthreadWrSemTake(&s_FddCellAntWrSem)) 
    {
        dbgErr("%s write sem error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy_s((char *)&s_CellAntCfg, sizeof(T_FddCellAntInfo), (char *)pCellAntInfo, sizeof(T_FddCellAntInfo));
    pthreadWrSemGive(&s_FddCellAntWrSem);
    return BSP_OK;
}

UINT32 BspGetCellAntInfo(T_FddCellAntInfo *pCellAntInfo)
{
    INPUT_POINTER_CHECK(pCellAntInfo);
	
    if (BSP_OK != pthreadRdSemTake(&s_FddCellAntWrSem))
    {
        return BSP_ERROR;
    }
    memcpy_s((char *)pCellAntInfo, sizeof(T_FddCellAntInfo), (char *)&s_CellAntCfg, sizeof(T_FddCellAntInfo));

    pthreadRdSemGive(&s_FddCellAntWrSem);

    return BSP_OK;
}

VOID BspShowCellAntInfo(VOID)
{
     UINT32 loop = 0;
	 
     dbgInfo("Total CarrNum%d\n",s_CellAntCfg.totalCarrNum);

	 for (loop = 0; loop < s_CellAntCfg.totalCarrNum; loop++)
	 {
         dbgInfo("Carr%d, Radio%d, TxBitNumH%d, TxBitNumL%d\n", s_CellAntCfg.carr[loop].CarrNo,
		 	s_CellAntCfg.carr[loop].CarrRadio, s_CellAntCfg.carr[loop].CarrTxBitNumH,s_CellAntCfg.carr[loop].CarrTxBitNumL);
	 }
}

/******************************************************************************
 * 函数名称: BspChkRruCfgParamValid(*)
 * 功能描述: 检测RRU上载波相关的采数的合法性
 * 输入参数: trxDir - 通道类型, RX, TX
 *           carrNo - RRU射频配置载波索引
 *           ptRruCfgPara - RRU射频配置参数
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 其他- 失败
 * 其它说明: 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), liuheyu@2018-01-12 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspChkRruCfgParamValid(UINT32 ulTrxDir, UINT32 ulCarrNum, T_RruRfCfgInfo *pRruCfgPara)
{
    UINT32 ulCarrLoop  = 0;
    UINT32 ulCheckCnts = 0;
    UINT32 ulCfgCarrSum = 0;
    UINT32 ulCenterFreq = 0;
    UINT32 ulRfCarrFreq = 0;
    UINT32 ulCfgCarrIdx = 0;
    UINT32 ulCarrRadio  = 0;
    UINT32 ulChnlCarrBw = 0;
    UINT32 ulDuplexMinFreq = 0;
    UINT32 ulCustomCheckRes = BSP_OK;

    UINT32 ulDuplexMaxFreq = 0;
    //UINT32 ulMinCarrBwFreq = 0;
    //UINT32 ulMaxCarrBwFreq = 0;
    /* UINT32 ulChkResult = BSP_OK; */
    
    INPUT_POINTER_CHECK(pRruCfgPara);

	dbgInfoEx("%s Dir%d, CarrNum%d \n",__FUNCTION__,ulTrxDir,ulCarrNum);

    ulCarrNum = BspGetCarrierNum();
    if (RX == ulTrxDir)
    {
        ulCfgCarrSum = pRruCfgPara->rxCfgCarrSum;
        ulCenterFreq = pRruCfgPara->rxCenterFreq;

        ulDuplexMinFreq = pRruCfgPara->rxRfRangeMinFreq;
        ulDuplexMaxFreq = pRruCfgPara->rxRfRangeMaxFreq;
    }
    else if (TX == ulTrxDir)
    {
        ulCfgCarrSum = pRruCfgPara->txCfgCarrSum;
        ulCenterFreq = pRruCfgPara->txCenterFreq;

        ulDuplexMinFreq = pRruCfgPara->txRfRangeMinFreq;
        ulDuplexMaxFreq = pRruCfgPara->txRfRangeMaxFreq;
    }
	dbgInfoEx("%s CfgCarrSum%d, ulCenterFreq%d, ulDuplexMinFreq%d, ulDuplexMaxFreq%d\n",__FUNCTION__,ulCfgCarrSum,ulCenterFreq,ulDuplexMinFreq,ulDuplexMaxFreq);
    if (ulCfgCarrSum == 0 || ulCfgCarrSum > ulCarrNum)
    {
    	return BSP_ERROR;
    }

    for (ulCarrLoop = 0; ulCarrLoop < ulCfgCarrSum; ulCarrLoop++)
    {
        if (RX == ulTrxDir)
        {
            ulCfgCarrIdx = pRruCfgPara->carr[ulCarrLoop].carrRxNo;
            ulRfCarrFreq = pRruCfgPara->carr[ulCarrLoop].carrRxFreq;
            ulChnlCarrBw = pRruCfgPara->carr[ulCarrLoop].carrRxBw;
            ulCarrRadio  = pRruCfgPara->carr[ulCarrLoop].carrRxRadio;
        }
        else if (TX == ulTrxDir)
        {
            ulCfgCarrIdx = pRruCfgPara->carr[ulCarrLoop].carrTxNo;
            ulRfCarrFreq = pRruCfgPara->carr[ulCarrLoop].carrTxFreq;
            ulChnlCarrBw = pRruCfgPara->carr[ulCarrLoop].carrTxBw;
            ulCarrRadio  = pRruCfgPara->carr[ulCarrLoop].carrTxRadio;
        }

        //ulMinCarrBwFreq = ulRfCarrFreq - ulChnlCarrBw / 2;
        //ulMaxCarrBwFreq = ulRfCarrFreq + ulChnlCarrBw / 2;
		dbgInfoEx("%s ulCenterFreq%d, ulRfCarrFreq%d, ulChnlCarrBw%d, ulCarrRadio%d ulCfgCarrIdx'%d\n",__FUNCTION__,ulCenterFreq,ulRfCarrFreq,ulChnlCarrBw,ulCarrRadio,ulCfgCarrIdx);
        if((NULL != pCustomCarrCfgCheck)&&(ulCheckCnts < BSP_MAX_CARR_NUM) )
        {
            ulCustomCheckRes = pCustomCarrCfgCheck(ulCenterFreq,ulRfCarrFreq,ulChnlCarrBw,ulCarrRadio);
            if( BSP_OK == ulCustomCheckRes )
            {
                ulCheckCnts += 1;
            }
        }
        else 
        {
            RRU_CFG_PARA_CHK_CONTINUE(ulCenterFreq);
            RRU_CFG_PARA_CHK_CONTINUE(ulRfCarrFreq);
            //RRU_CFG_PARA_CHK_CONTINUE(ulChnlCarrBw);
            RRU_CFG_PARA_CHK_CONTINUE(ulCarrRadio);
            ulCheckCnts += 1;
        }

    }

	dbgInfoEx("%s ulCfgCarrSum%d, ulCheckCnts%d\n",__FUNCTION__,ulCfgCarrSum,ulCheckCnts);

    return (ulCfgCarrSum - ulCheckCnts);
}

/******************************************************************************
 *  函数名称   : BspCheckRruCfgParaData(*)
 *  功能描述   : 检测RRU上载波相关的采数的合法性
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspCheckRruCfgParaData(UINT32 trxDir, T_RruRfCfgInfo *pRruCfgPara)
{
    UINT32 carrIndex;
    UINT32 flag = 0;
    UINT32 ret = BSP_OK;
    
    INPUT_POINTER_CHECK(pRruCfgPara);

    for (carrIndex = 0; carrIndex < BSP_MAX_CARR_NUM; carrIndex++)
    {
        if (RX == trxDir)
        {
            if ((0 != pRruCfgPara->carr[carrIndex].carrRxFreq) &&
                (0 != pRruCfgPara->rxCenterFreq))
            {
                flag = 1;
            }
        }
        else if (TX == trxDir)
        {
            if ((0 != pRruCfgPara->carr[carrIndex].carrTxFreq) &&
                (0 != pRruCfgPara->txCenterFreq))
            {
                flag = 1;
            }
        }
    }

    /* 后续可以增加频点是否在双工器的范围的判断，不在则flag = 0 */
    
    ret = (1 == flag) ? (BSP_OK) : (BSP_ERROR);
    return ret;
}

VOID BspShowRruCfgPara(UINT32 rfChnStart, UINT32 rfChnEnd)
{
    UINT32 Cnt = 0;
    UINT32 Carr= 0;
    UINT32 ChnlMin = 0;
    UINT32 ChnlMax = 0;
    UINT32 CarrMax = 0;
    UINT32 trxMax = max(BspGetTxChannel(), BspGetRxChannel());
    T_RruRfCfgInfo *rruCarrCfg = BspGetRruCarrCfgMem();
    INPUT_POINTER_CHECK_RETURN(rruCarrCfg);

    ChnlMin = rfChnStart;
    ChnlMax = max(rfChnStart, rfChnEnd);
    ChnlMax = min(ChnlMax + 1, trxMax);             // BSP_MAX_TX_CHAN
    CarrMax = BspGetCarrierNum();                   // BSP_MAX_CARR_NUM

    for (Cnt = ChnlMin; Cnt < ChnlMax; Cnt++)
    {
        if (rruCarrCfg[Cnt].txCenterFreq == 0 && rruCarrCfg[Cnt].rxCenterFreq == 0)
        {
            continue;
        }
        dbgPrn("\n=== RfChnl'%d, CenterFreq:Tx'%d Rx'%d; Range:Tx'(%d  %d) Rx'(%d  %d) ===\n",
               Cnt, rruCarrCfg[Cnt].txCenterFreq, rruCarrCfg[Cnt].rxCenterFreq,
               rruCarrCfg[Cnt].txRfRangeMinFreq, rruCarrCfg[Cnt].txRfRangeMaxFreq,
               rruCarrCfg[Cnt].rxRfRangeMinFreq, rruCarrCfg[Cnt].rxRfRangeMaxFreq);
        for (Carr = 0; Carr < CarrMax; Carr++)
        {
            if (rruCarrCfg[Cnt].carr[Carr].carrTxRadio == 0 && rruCarrCfg[Cnt].carr[Carr].carrRxRadio == 0)
            {
                continue;
            }
            dbgPrn("carr[%d],carrPow %d;\n",Carr,rruCarrCfg[Cnt].carr[Carr].carrPow);
            dbgPrn("carrTxNo %d,carrTxFreq %d,carrTxBw %d,carrTxRadio 0x%x;\n",rruCarrCfg[Cnt].carr[Carr].carrTxNo, \
                   rruCarrCfg[Cnt].carr[Carr].carrTxFreq,rruCarrCfg[Cnt].carr[Carr].carrTxBw,rruCarrCfg[Cnt].carr[Carr].carrTxRadio);
            dbgPrn("carrRxNo %d,carrRxFreq %d,carrRxBw %d,carrRxRadio 0x%x;\n",rruCarrCfg[Cnt].carr[Carr].carrRxNo, \
                   rruCarrCfg[Cnt].carr[Carr].carrRxFreq,rruCarrCfg[Cnt].carr[Carr].carrRxBw,rruCarrCfg[Cnt].carr[Carr].carrRxRadio);
        }
    }
    return;
}

VOID BspShowRruCfgPara_original(UINT32 rfChnStart, UINT32 rfChnEnd)
{
    UINT32 Cnt = 0;
    UINT32 Carr= 0;
    UINT32 ChnlMin = 0;
    UINT32 ChnlMax = 0;
    UINT32 CarrMax = 0;
    T_RruRfCfgInfo *rruCarrCfg_original = BspGetRruCarrCfgOriginalMem();
    INPUT_POINTER_CHECK_RETURN(rruCarrCfg_original);

    ChnlMin = rfChnStart;
    ChnlMax = max(rfChnStart, rfChnEnd);
    ChnlMax = min(ChnlMax + 1, BspGetTxChannel()); // BSP_MAX_TX_CHAN
    CarrMax = BspGetCarrierNum();                  // BSP_MAX_CARR_NUM

    for (Cnt = ChnlMin; Cnt < ChnlMax; Cnt++)
    {
        dbgPrn("\n=== RfChnl'%d, CenterFreq:Tx'%d Rx'%d; Range:Tx'(%d  %d) Rx'(%d  %d) ===\n",
               Cnt, rruCarrCfg_original[Cnt].txCenterFreq, rruCarrCfg_original[Cnt].rxCenterFreq,
               rruCarrCfg_original[Cnt].txRfRangeMinFreq, rruCarrCfg_original[Cnt].txRfRangeMaxFreq,
               rruCarrCfg_original[Cnt].rxRfRangeMinFreq, rruCarrCfg_original[Cnt].rxRfRangeMaxFreq);
        for (Carr = 0; Carr < CarrMax; Carr++)
        {
            dbgPrn("carr[%d],carrPow %d;\n",Carr,rruCarrCfg_original[Cnt].carr[Carr].carrPow);
            dbgPrn("carrTxNo %d,carrTxFreq %d,carrTxBw %d,carrTxRadio 0x%x;\n",rruCarrCfg_original[Cnt].carr[Carr].carrTxNo, \
                    rruCarrCfg_original[Cnt].carr[Carr].carrTxFreq,rruCarrCfg_original[Cnt].carr[Carr].carrTxBw,rruCarrCfg_original[Cnt].carr[Carr].carrTxRadio);
            dbgPrn("carrRxNo %d,carrRxFreq %d,carrRxBw %d,carrRxRadio 0x%x;\n",rruCarrCfg_original[Cnt].carr[Carr].carrRxNo, \
                    rruCarrCfg_original[Cnt].carr[Carr].carrRxFreq,rruCarrCfg_original[Cnt].carr[Carr].carrRxBw,rruCarrCfg_original[Cnt].carr[Carr].carrRxRadio);
        }
    }
   /* return BSP_OK;*/
}
/******************************************************************************
 *  函数名称   : BspGetRruCfgPara(*)
 *  功能描述   : 获取RRU射频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetChnlCfgCarrPara(UINT32 rfChn, T_RruRfCfgInfo *pRruCfgPara)
{
    T_RruRfCfgInfo *rruCarrCfg = BspGetRruCarrCfgMem();
    INPUT_POINTER_CHECK(rruCarrCfg);
    INPUT_POINTER_CHECK(pRruCfgPara);

    if(rfChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != pthreadRdSemTake(&s_CarrCfgWrSem))
    {
        return BSP_ERROR;
    }
    memcpy((char *)pRruCfgPara, (char *)&rruCarrCfg[rfChn], sizeof(T_RruRfCfgInfo));

    pthreadRdSemGive(&s_CarrCfgWrSem);

    return BSP_OK;
}

UINT32 BspGetChnlCfgCarrPara_original(UINT32 rfChn, T_RruRfCfgInfo *pRruCfgPara)
{
    T_RruRfCfgInfo *rruCarrCfg_original = BspGetRruCarrCfgOriginalMem();
    INPUT_POINTER_CHECK(rruCarrCfg_original);
    INPUT_POINTER_CHECK(pRruCfgPara);

    if(rfChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != pthreadRdSemTake(&s_CarrCfgWrSem_original))
    {
        return BSP_ERROR;
    }
    memcpy((char *)pRruCfgPara, (char *)&rruCarrCfg_original[rfChn], sizeof(T_RruRfCfgInfo));

    pthreadRdSemGive(&s_CarrCfgWrSem_original);

    dbgInfo("%s>>BspChnl'%d\n",__FUNCTION__, rfChn);

    return BSP_OK;
}

UINT32 BspGetRruCfgPara(UINT32 rfChn, T_RruRfCfgInfo *pRruCfgPara)
{
    UINT32 tmpRet = BSP_OK;
    UINT32 funRet = BSP_OK;

    tmpRet = BspGetChnlCfgCarrPara(rfChn, pRruCfgPara);
    if (tmpRet != BSP_OK)
    {
        funRet |= tmpRet;
        dbgErr("[%s]ChnlCfgCarrPara Get Error!\n", __FUNCTION__);
    }

    tmpRet = BSP_OK;
    tmpRet |= BspCheckRruCfgParaData(RX, pRruCfgPara);
    if(rfChn < BspGetTxChannel())
    {
        tmpRet |= BspCheckRruCfgParaData(TX, pRruCfgPara);
    }
    
    if (tmpRet != BSP_OK)
    {
        funRet |= tmpRet;
        dbgInfoEx("[%s]Trx RruCfgParaData Check Error!\n", __FUNCTION__);
    }

    return funRet;
}

UINT32 BspGetRruCfgParaByDir(UINT32 rfChn, UINT32 Dir, T_RruRfCfgInfo *pRruCfgPara)
{
    UINT32 tmpRet = BSP_OK;
	UINT32 funRet = BSP_OK;

	if ((rfChn >= BspGetBspChanNum(Dir)) || (Dir > 1))
    {
        return BSP_ERROR;
    }

	INPUT_POINTER_CHECK(pRruCfgPara);

	tmpRet = BspGetChnlCfgCarrPara(rfChn, pRruCfgPara);
    if (tmpRet != BSP_OK)
    {
        funRet |= tmpRet;
        dbgErr("[%s]ChnlCfgCarrPara Get Error!\n", __FUNCTION__);
    }

	tmpRet |= BspCheckRruCfgParaData(Dir, pRruCfgPara);

	if (tmpRet != BSP_OK)
    {
        funRet |= tmpRet;
        dbgInfoEx("[%s]Trx RruCfgParaData Check Error!\n", __FUNCTION__);
    }

    return funRet;		
}

/******************************************************************************
 *  函数名称   : BspGetTxCenterFreqCfg(*)
 *  功能描述   : 获得该通道的发射的中心频点
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetTxCenterFreqCfg(UINT32 rfchn)
{
    T_RruRfCfgInfo    *ptRruCfgPara;
    UINT32            txCenterFreq;

    ptRruCfgPara = malloc(sizeof(T_RruRfCfgInfo));
    if (NULL == ptRruCfgPara)
    {
        return BSP_ERROR;
    }
    memset(ptRruCfgPara,0,sizeof(T_RruRfCfgInfo));

    if (BSP_OK != BspGetRruCfgParaByDir(rfchn, TX, ptRruCfgPara))
    {
        dbgInfoEx("Get Rru Cfg Data error.\n");
        free(ptRruCfgPara);
        return BSP_ERROR;
    }
    txCenterFreq = ptRruCfgPara->txCenterFreq;

    free(ptRruCfgPara);
    return txCenterFreq;

}

/******************************************************************************
 *  函数名称   : BspGetRxCenterFreqCfg(*)
 *  功能描述   : 获得该通道的接收的中心频点
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetRxCenterFreqCfg(UINT32 rfchn)
{
    T_RruRfCfgInfo    *ptRruCfgPara;
    UINT32            rxCenterFreq;

    ptRruCfgPara = malloc(sizeof(T_RruRfCfgInfo));
    if (NULL == ptRruCfgPara)
    {
        return BSP_ERROR;
    }
    memset(ptRruCfgPara,0,sizeof(T_RruRfCfgInfo));

    if (BSP_OK != BspGetRruCfgParaByDir(rfchn,RX,ptRruCfgPara))
    {
        dbgInfoEx("Get Rru Cfg Data error.\n");
        free(ptRruCfgPara);
        return BSP_ERROR;
    }
    rxCenterFreq = ptRruCfgPara->rxCenterFreq;

    free(ptRruCfgPara);
    return rxCenterFreq;

}

static T_RruCarrPowCfgInfo *BspGetRruCarrPowCfgMem(void)
{
    if (s_rruCarrPowCfg == NULL)
    {
        s_rruCarrPowCfg = (T_RruCarrPowCfgInfo *)malloc(sizeof(T_RruCarrPowCfgInfo) * BSP_MAX_TX_CHAN);
        if (s_rruCarrPowCfg == NULL)
        {
            return NULL;
        }
        zte_memset_s(s_rruCarrPowCfg, sizeof(T_RruCarrPowCfgInfo) * BSP_MAX_TX_CHAN, 0, sizeof(T_RruCarrPowCfgInfo) * BSP_MAX_TX_CHAN);
    }
    return s_rruCarrPowCfg;
}

/******************************************************************************
 *  函数名称   : BspSetCarrPowCfgPara(*)
 *  功能描述   : 更新RRU射频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : pRruPowInfo - RRU carr pow
 *  输出参数   : 无
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *工装使用申明: 工装使用接口，请注意波及
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wangfei  @2017-7-27 11:04:48
 *-----------------------------------------------------------------------------
 */

UINT32 BspSetCarrPowCfgPara(UINT32 rfChn,T_RruCarrPowCfgInfo *pRruPowInfo)
{
    T_RruCarrPowCfgInfo *rruCarrPowCfg = BspGetRruCarrPowCfgMem();
    INPUT_POINTER_CHECK(rruCarrPowCfg);
    INPUT_POINTER_CHECK(pRruPowInfo);

    if(rfChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != pthreadWrSemTake(&s_carrPowRwSem))
    {
        return BSP_ERROR;
    }
    memset(&rruCarrPowCfg[rfChn],0,sizeof(T_RruCarrPowCfgInfo));
    memcpy((char *)&rruCarrPowCfg[rfChn],(char *)pRruPowInfo, sizeof(T_RruCarrPowCfgInfo));

    pthreadWrSemGive(&s_carrPowRwSem);

    return BSP_OK;
}
/******************************************************************************
 *  函数名称   : BspGetCarrPowCfgPara(*)
 *  功能描述   : 获取RRU射频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wangfei  @2017-7-27 11:04:48
 *-----------------------------------------------------------------------------
 */

UINT32 BspGetCarrPowCfgPara(UINT32 rfChn,T_RruCarrPowCfgInfo *pRruPowInfo)
{
    UINT32 ret = BSP_OK;
    T_RruCarrPowCfgInfo *rruCarrPowCfg = BspGetRruCarrPowCfgMem();
    INPUT_POINTER_CHECK(rruCarrPowCfg);
    INPUT_POINTER_CHECK(pRruPowInfo);

    if(rfChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != pthreadRdSemTake(&s_carrPowRwSem))
    {
        return BSP_ERROR;
    }
    memcpy((char *)pRruPowInfo, (char *)&rruCarrPowCfg[rfChn], sizeof(T_RruCarrPowCfgInfo));

    pthreadRdSemGive(&s_carrPowRwSem);
    
    return ret;
}  
/******************************************************************************
 *  函数名称   : BspGetCarrPowCfg(*)
 *  功能描述   : 获得该通道的发射的中心频点
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetCarrPowCfg(UINT32 rfChn,UINT32 carrIdx,UINT32 radio,UINT32 *pCarrPow)
{
    UINT32 carrLoop = 0;
    /* UINT32 retVal   = BSP_OK; */
    T_RruCarrPowCfgInfo *pRruPowInfo = NULL;
#if 0
    if (carrIdx >= BSP_MAX_CARR_NUM)
    {
        dbgErr("[%s]rfChn %d carr %d error\n",__FUNCTION__,rfChn,carrIdx);
        return BSP_ERROR;
    }
#endif
    INPUT_POINTER_CHECK(pCarrPow);
    
    pRruPowInfo = malloc(sizeof(T_RruCarrPowCfgInfo));
    INPUT_POINTER_CHECK(pRruPowInfo);
    memset(pRruPowInfo,0,sizeof(T_RruCarrPowCfgInfo));

    if (BSP_OK != BspGetCarrPowCfgPara(rfChn,pRruPowInfo))
    {
        dbgErr("[%s]rfChn %d carr %d pow error\n",__FUNCTION__,rfChn,carrIdx);
        free(pRruPowInfo);
        return BSP_ERROR;
    }

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop ++)
    {
    //  dbgInfo("%s>>RfChnl'%d Carr'(%d=%d) Radio'(%d=%d) Pow'%d Get...\n", __FUNCTION__,
    //          rfChn, carrIdx, pRruPowInfo->carr[carrLoop].carrNo,
    //          radio, pRruPowInfo->carr[carrLoop].carrRadio,
    //          pRruPowInfo->carr[carrLoop].carrPow);
        if((carrIdx == pRruPowInfo->carr[carrLoop].carrNo)&&
           (radio   == pRruPowInfo->carr[carrLoop].carrRadio))
        {
            *pCarrPow = pRruPowInfo->carr[carrLoop].carrPow; //mw
            break;
        }
    }

    free(pRruPowInfo);
    if (carrLoop >= BSP_MAX_CARR_NUM)
    {
        dbgErr("%s>>RfChnl'%d Carr'%d Radio'%d CarrPow Get Error!\n",
               __FUNCTION__, rfChn, carrIdx, radio);
    }

    return BSP_OK;
}

/* 获取BBU下发的原始载波功率 */
UINT32 BspGetCfgCarrPow(UINT32 rfChn, UINT32 carrNo, UINT32 radio, UINT32 *pCarrPow)
{
    UINT32 carrLoop = 0;
    T_RruCarrPowCfgInfo *pRruPowInfo = NULL;

    pRruPowInfo = malloc(sizeof(T_RruCarrPowCfgInfo));
    INPUT_POINTER_CHECK(pRruPowInfo);
    memset(pRruPowInfo,0,sizeof(T_RruCarrPowCfgInfo));

    if (BSP_OK != BspGetCarrPowCfgPara(rfChn,pRruPowInfo))
    {
        dbgErr("[%s]rfChn %d carr %d pow error\n",__FUNCTION__,rfChn, carrNo);
        free(pRruPowInfo);
        return BSP_ERROR;
    }

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop ++)
    {
        if ((radio   == pRruPowInfo->carr[carrLoop].carrRadio) &&
            (carrNo  == pRruPowInfo->carr[carrLoop].carrNo))
        {
            break;
        }
    }

    if (carrLoop == BSP_MAX_CARR_NUM)
    {
        free(pRruPowInfo);
        dbgErr("%s>>RfChnl'%d Carr'%d Radio'%d CarrPow Get Error!\n",
               __FUNCTION__, rfChn, carrNo, radio);
        return BSP_ERROR;
    }
    if (pCarrPow)
    {
        *pCarrPow = pRruPowInfo->carr[carrLoop].cfgCarrPow;
    }
    else
    {
        dbgInfo("%s>>RfChnl'%d Carr'%d Radio'0x%x CarrPow '%u\n", __FUNCTION__, rfChn, carrNo, radio, pRruPowInfo->carr[carrLoop].cfgCarrPow);
    }
    free(pRruPowInfo);

    return BSP_OK;
}

/******************************************************************************
 *  函数名称   : BspGetChanCarrSumPow(*)
 *  功能描述   : 获得该通道的配置功率之和
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : rfChn: 射频通道号　pCarrPow:通道功率和
 *  输出参数   :
 *  返 回 值   : BSP_OK:获取成功; 其他：获取通道配置失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), @2021-8-15 16:26:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetChanCarrSumPow(UINT32 rfChn, UINT32 *pCarrPow)
{
    UINT32 carrLoop = 0;
    UINT32 carriBw = 0;
    UINT32 freq = 0;
    UINT32 carrPow = 0;
    UINT32 carrPowSum = 0;
    UINT32 carrNo = 0;
    T_RruRfCfgInfo tRruCfgInfo = {0};

    INPUT_POINTER_CHECK(pCarrPow);
    BspGetChnlCfgCarrPara(rfChn, &tRruCfgInfo);

    for (carrLoop = 0; carrLoop < tRruCfgInfo.txCfgCarrSum; carrLoop++)
    {
        carrPow = 0;
        BspGetCfgCarrPow(rfChn, tRruCfgInfo.carr[carrLoop].carrTxNo, tRruCfgInfo.carr[carrLoop].carrTxRadio, &carrPow);
        carrNo = tRruCfgInfo.carr[carrLoop].carrTxNo;
        freq = tRruCfgInfo.carr[carrLoop].carrTxFreq;
        carriBw = tRruCfgInfo.carr[carrLoop].carrTxBw;

        dbgInfoEx("[%s] carrNo'%u, freq'%u, Bw'%u, carrPow'%u. \n", __FUNCTION__, carrNo, freq, carriBw, carrPow);

        RRU_CFG_PARA_CHK_CONTINUE(freq);
        RRU_CFG_PARA_CHK_CONTINUE(carriBw);
        RRU_CFG_PARA_CHK_CONTINUE(carrPow);

        carrPowSum += carrPow;
    }

    *pCarrPow = carrPowSum;
    dbgInfoEx("[%s] chan:%u, carrPowSum:%u \n", __FUNCTION__, rfChn, carrPowSum);

    return BSP_OK;
}

UINT32 BspGetCarrRadioMode(UINT32 rfchn,UINT32 carrIndex,UINT32 dir,UINT32 *pCarrMode)
{
    T_RruRfCfgInfo *ptRruCfgPara = NULL;

    if ( carrIndex >= BSP_MAX_CARR_NUM)
    {
        dbgErr("%s carr index'%d error\n", __FUNCTION__, carrIndex);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pCarrMode);
    ptRruCfgPara = malloc(sizeof(T_RruRfCfgInfo));
    INPUT_POINTER_CHECK(ptRruCfgPara);
    
    memset(ptRruCfgPara,0,sizeof(T_RruRfCfgInfo));

    if (BSP_OK != BspGetRruCfgParaByDir(rfchn,dir,ptRruCfgPara))
    {
        dbgInfoEx("Get Rru Cfg Data error.\n");
        free(ptRruCfgPara);
        return BSP_ERROR;
    }

    if (dir == RX)
    {
        *pCarrMode = ptRruCfgPara->carr[carrIndex].carrRxRadio; 
    }
    else 
    {
        *pCarrMode = ptRruCfgPara->carr[carrIndex].carrTxRadio; 
    }

    free(ptRruCfgPara);
    return BSP_OK;
}

static T_RruBandCfgInfo *BspGetDifTxCarrCfgMem(void)
{
    if (s_difTxCarrCfg == NULL)
    {
        size_t bufLen = 0;
        bufLen = sizeof(T_RruBandCfgInfo) * BSP_MAX_TX_CHAN;
        s_difTxCarrCfg = (T_RruBandCfgInfo *)malloc(bufLen);
        INPUT_POINTER_CHECK_RETURN_NULL(s_difTxCarrCfg);
        memset_s(s_difTxCarrCfg, bufLen, 0, bufLen);
    }
    return s_difTxCarrCfg;
}
/******************************************************************************
 *  函数名称   : BspSetRruDifCfgPara(*)
 *  功能描述   : 获取RRU射频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspSetRruTxDifCfgPara(UINT32 rfChn,T_RruBandCfgInfo *pRruBandCfgPara)
{
    T_RruBandCfgInfo *difTxCarrCfg = BspGetDifTxCarrCfgMem();
    INPUT_POINTER_CHECK(difTxCarrCfg);

    if(rfChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pRruBandCfgPara);

    if (BSP_OK != pthreadWrSemTake(&s_DifCfgRwSem))
    {
        return BSP_ERROR;
    }
    memset(&difTxCarrCfg[rfChn],0,sizeof(T_RruBandCfgInfo));
    memcpy((char *)&difTxCarrCfg[rfChn],(char *)pRruBandCfgPara, sizeof(T_RruBandCfgInfo));

    pthreadWrSemGive(&s_DifCfgRwSem);
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 BspPrnRruTxDifCfgPara(UINT32 rfChn)
{
    UINT32 bandfreq = 0;
    UINT32 carrIdx = 0;
    UINT32 carrNo = 0;
    UINT32 carrFreq = 0;
    UINT32 carrPow = 0;
    UINT32 carrBw = 0;
    UINT32 carrRadio = 0;
    UINT32 carrNco = 0;
    T_RruBandCfgInfo *difTxCarrCfg = BspGetDifTxCarrCfgMem();
    INPUT_POINTER_CHECK(difTxCarrCfg);
    if(rfChn >= (UINT32)BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    bandfreq = difTxCarrCfg[rfChn].info[0].bandfreq;
    dbgInfo("bandfreq is %d KHZ \n",bandfreq);
    for (carrIdx = 0; carrIdx < BSP_MAX_CARR_NUM;carrIdx++)
    {
        carrNo = difTxCarrCfg[rfChn].info[0].carr[carrIdx].carrNo;
        carrFreq = difTxCarrCfg[rfChn].info[0].carr[carrIdx].carrFreq;
        carrPow = difTxCarrCfg[rfChn].info[0].carr[carrIdx].carrPow;
        carrBw = difTxCarrCfg[rfChn].info[0].carr[carrIdx].carrBw;
        carrRadio = difTxCarrCfg[rfChn].info[0].carr[carrIdx].carrRadio;
        carrNco = difTxCarrCfg[rfChn].info[0].carr[carrIdx].carrNco;

        dbgInfo("%s:carrNo is %d,carrFreq is %d,carrPow is %d,carrBw is %d,carrRadio is %#x,carrNco is %d \n",__FUNCTION__,carrNo,carrFreq,carrPow,carrBw,carrRadio,carrNco);
    }
    return BSP_OK;
}
#endif


/******************************************************************************
 *  函数名称   : BspGetRruDifCfgPara(*)
 *  功能描述   : 获取RRU 中频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetRruTxDifCfgPara(UINT32 rfChn,T_RruBandCfgInfo *pRruBandCfgPara)
{
    T_RruBandCfgInfo *difTxCarrCfg = BspGetDifTxCarrCfgMem();
    INPUT_POINTER_CHECK(difTxCarrCfg);

    if(rfChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pRruBandCfgPara);

    if (BSP_OK != pthreadRdSemTake(&s_DifCfgRwSem))
    {
        return BSP_ERROR;
    }
    memcpy((char *)pRruBandCfgPara, (char *)&difTxCarrCfg[rfChn], sizeof(T_RruBandCfgInfo));

    pthreadRdSemGive(&s_DifCfgRwSem);

    return BSP_OK;
}

/******************************************************************************
 *  函数名称   : BspSetChanMaxCarrBw(*)
 *  功能描述   : 获取RRU 中频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspSetChanMaxCarrBw(UINT32 uBspChn,UINT32 uDir ,UINT32 uCarrMode, UINT32 uCarrBw)
{
    if((uBspChn >= BSP_MAX_TX_CHAN)||(uCarrMode >=DIF_RADIOMODE_MAX))
    {
        dbgErr("[%s]Chn'%d Set Max Carr Bw Error \n",__FUNCTION__,uBspChn);
        return BSP_ERROR;
    }
    if((uDir!=TX)&&(uDir!=RX))
	{
        return BSP_ERROR;
	}
    switch(uCarrMode)
    {
        case DIF_RADIOMODE_UMTS:
        {
			s_RruMaxCarrBw[uDir][uBspChn][DIF_RADIOMODE_UMTS] = uCarrBw;
			break;
		}
        case DIF_RADIOMODE_LTE_FDD:
        {
			s_RruMaxCarrBw[uDir][uBspChn][DIF_RADIOMODE_LTE_FDD] = uCarrBw;
			break;
		}
		case DIF_RADIOMODE_NR:
        {
			s_RruMaxCarrBw[uDir][uBspChn][DIF_RADIOMODE_NR] = uCarrBw;
			break;
		}
		default:
		{
            break;
		}
	}
    
    return BSP_OK;
}

/******************************************************************************
 *  函数名称   : BspGetChanMaxCarrBw(*)
 *  功能描述   : 获取RRU 中频配置参数
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : ptRruCfgPara - RRU射频配置参数
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 黄钊10093419@2010-7-19 10:47:43
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetChanMaxCarrBw(UINT32 uBspChn, UINT32 uDir, UINT32 uCarrMode)
{      
    if((uBspChn >= BSP_MAX_TX_CHAN)||(uCarrMode >=DIF_RADIOMODE_MAX))
    {
        dbgInfoEx("[%s]Chn'%d Set Max Carr mode'%d Error \n",__FUNCTION__,uBspChn,uCarrMode);
        return BSP_ERROR;
    }
    if((uDir!=TX)&&(uDir!=RX))
    {
        return BSP_ERROR;
    }
    return s_RruMaxCarrBw[uDir][uBspChn][uCarrMode];
}

UINT32 BspGetTddFddAauType(VOID)
{
    return s_RruRadioMode;
}

UINT32 BspSetTddFddAauType(UINT32 radiomode)
{
	s_RruRadioMode = radiomode;
	return BSP_OK;
}
VOID BspCustomCarrCfgCheckCallBackInit(FUNC_CUSTOM_CARRCFG_CHECK pfunCallback)
{
    pCustomCarrCfgCheck = pfunCallback;
}

/******************************************************************************
 *  函数名称   : BspSetCarrActiveStatus(*)
 *  功能描述   : 设置各个载波的激活状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulChan 通道号    ulRadioMode 载波制式  ulCarrNo载波号 ulActSta激活状态 0非激活 1激活
 *  输出参数   :
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A)
 *-----------------------------------------------------------------------------
 */

UINT32 BspSetCarrActiveStatus(UINT32 ulChan,UINT32 dir, UINT32 ulRadioMode, UINT32 ulCarrNo, UINT32 ulActSta)
{
    UINT32 ulModeIndex=0;
    UINT32 index=0;

    if(ulRadioMode == RADIO_STANDARD_LTE_TDD && s_ulIsQcellFlag ==1)
    {
        if(ulCarrNo >= 22)
        {
    	     ulCarrNo = ulCarrNo - 22 ;
        }
    }

    if((ulChan >= BSP_MAX_TX_CHAN)|| dir>= PRX ||ulCarrNo >= BSP_MAX_CARR_NUM)
    {
        dbgInfoEx("[%s]Chn'%d ulCarrNo %d Error \n",__FUNCTION__,ulChan,ulCarrNo);
        return BSP_ERROR;
    }

    for(index= 0; index< PRODUCT_MODE_MAXNUM; index++)
	{
	    if((ulRadioMode>>index)==1)
	    {
	    	ulModeIndex =  index;
	        break;
	    }
    }
    if(ulActSta == 0)
    {
        ulActSta = 2; /*高层下发的0转成2*/
    }
    dbgInfoEx("%s ulRadioMode 0x%x ulModeIndex %d ulActSta %d\n",__FUNCTION__,ulRadioMode,ulModeIndex,ulActSta);
    g_ulCellActSta[ulChan][dir][ulModeIndex][ulCarrNo] = ulActSta;
    BspLog(LOG_LEVEL_0,"%s{Chn %d RadioMode 0x%x ModeIndex %d ActSta %d}\n", __FUNCTION__, ulChan,ulRadioMode,ulModeIndex,ulActSta);

    return BSP_OK;
}
/******************************************************************************
 *  函数名称   : BspGetCarrActiveStatus(*)
 *  功能描述   : 获取对应载波的激活状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulChan 通道号    ulRadioMode 载波制式  ulCarrNo载波号
 *  输出参数   : ulActSta激活状态 0非激活 1激活
 *  返 回 值   : BSP_OK:更新成功; 其他：更新失败
 *  其它说明   : 无
 *-----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A)
 *-----------------------------------------------------------------------------
 */
UINT32 BspGetCarrActiveStatus(UINT32 ulChan, UINT32 dir, UINT32 ulRadioMode, UINT32 ulCarrNo)
{
    UINT32 ulModeIndex=0;
    UINT32 index=0;
    UINT32 tmp = 0;

    if(ulRadioMode == RADIO_STANDARD_LTE_TDD && s_ulIsQcellFlag ==1)
    {
        if(ulCarrNo >= 22)
        {
    	     ulCarrNo = ulCarrNo - 22 ;
        }
    }

    if((ulChan >= BSP_MAX_TX_CHAN)|| dir>= PRX ||ulCarrNo >= BSP_MAX_CARR_NUM)
    {
        dbgInfoEx("[%s]Chn'%d ulCarrNo %d Error \n",__FUNCTION__,ulChan,ulCarrNo);
        return BSP_ERROR;
    }
    for(index= 0; index< PRODUCT_MODE_MAXNUM; index++)
    {
        if((ulRadioMode>>index)==1)
        {
            ulModeIndex =  index;
            break;
        }
    }
    tmp = g_ulCellActSta[ulChan][dir][ulModeIndex][ulCarrNo];
    if(tmp == 2)
    {
        tmp = 0;
    }
    else
    {
        tmp = 1; /*初始化认为是解闭塞状态*/
    }
    return tmp;
}

UINT32 BspGetCarrSta(UINT32 chan, UINT32 dir, UINT32 radioMode, UINT32 carrNo, UINT32 *activeFlag)
{
    UINT32 flag = 0;
    UINT32 carrSwitch = 0;

    if (NULL == activeFlag)
    {
        dbgErr("%s:Input Pointer is NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    flag = BspGetCarrActiveStatus(chan, dir, radioMode, carrNo);
    if(TRUE == BspIsFarmValidTxChan(chan, radioMode))
    {
        carrSwitch = BspGetFarmTxCarrSwitch(chan, radioMode, carrNo);
        *activeFlag = flag & carrSwitch;
    }
    else
    {
        *activeFlag = flag;
    }
    BspLog(LOG_LEVEL_0,"[%s]flag:%d, carrSwitch:%d, activeFlag:%d\n",__FUNCTION__, flag, carrSwitch, *activeFlag);

    return BSP_OK;
}

UINT32 BspGetSharePowerRisingLevel(UINT32 *quotaLimit)
{
    INPUT_POINTER_CHECK(quotaLimit);
    return BSP_OK;
}

UINT32 BspGetSharePowerTimeGap(UINT32 *timeLimit)
{
    INPUT_POINTER_CHECK(timeLimit);
    return BSP_OK;
}

/* 农网3扇区选一     */
static  UINT32   s_FarmLteTxValidCarr[MAX_TX_CHAN][MAX_CARRIERS_NUM]={0};
static  UINT32   s_FarmNrTxValidCarr[MAX_TX_CHAN][MAX_CARRIERS_NUM]={0};
static  UINT32   s_FarmNbTxValidCarr[MAX_TX_CHAN][MAX_CARRIERS_NUM]={0};
static  UINT32   s_FarmUmtsTxValidCarr[MAX_TX_CHAN][MAX_CARRIERS_NUM]={0};

static  UINT32   s_FarmLteRxValidCarr[MAX_RX_CHAN][MAX_CARRIERS_NUM]={0};
static  UINT32   s_FarmNrRxValidCarr[MAX_RX_CHAN][MAX_CARRIERS_NUM]={0};
static  UINT32   s_FarmNbRxValidCarr[MAX_RX_CHAN][MAX_CARRIERS_NUM]={0};
static  UINT32   s_FarmUmtsRxValidCarr[MAX_RX_CHAN][MAX_CARRIERS_NUM]={0};

/*****************************************************************************
*  函数名称   : BspSetFarmTxValidCarr
*  功能描述   : 农网下发共享天线选择有效载波
*  读全局变量 :
*  写全局变量 :
*  输入参数   : chan    - 通道号，农网需求下发共享天线通道号
           radioMode - 切换有效载波制式
           carrNo  -  切换有效载波载波号
          valid  -  有效开关，1是打开 0是关闭
*  输出参数   : 无
*  返 回 值  : BSP_OK标识执行成功，其余表示执行失败
*  其它说明   : eg:开关切换到LTE Cell0 载波0的位置时，RfPort4通道切换到Cell0的参数
            下发BspSetFarmTxValidCarr 3,0x10,0,1
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), shiqiao@2023-04-27 15:21:07, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetFarmTxValidCarr(UINT32 chan, UINT32 radioMode, UINT32 carrNo, UINT32 valid)
{
    if((chan >= MAX_TX_CHAN) || (carrNo>=MAX_CARRIERS_NUM))
    {
        dbgErr("[%s]Para ERROR.chan=%u,carrNo=%u\n",__FUNCTION__,chan,carrNo);
        return BSP_ERROR;
    }

    switch(radioMode)
    {
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            s_FarmLteTxValidCarr[chan][carrNo] = valid;
            break;
        }
        case BSP_RADIO_STANDARD_FDD_5G:
        {
            s_FarmNrTxValidCarr[chan][carrNo] = valid;
            break;
        }
        case BSP_RADIO_STANDARD_NB_IOT:
        {
            s_FarmNbTxValidCarr[chan][carrNo] = valid;
            break;
        }
        case BSP_RADIO_STANDARD_UMTS:
        {
            s_FarmUmtsTxValidCarr[chan][carrNo] = valid;
            break;
        }
        default:
        {
            dbgErr("%s not support %d! \n",__FUNCTION__,radioMode);
            return BSP_ERROR;
        }
    }
    return BSP_OK;
}

UINT32 BspSetFarmRxValidCarr(UINT32 chan, UINT32 radioMode, UINT32 carrNo, UINT32 valid)
{
    if((chan >= MAX_RX_CHAN) || (carrNo>=MAX_CARRIERS_NUM))
    {
        dbgErr("[%s]Para ERROR.chan=%u,carrNo=%u\n",__FUNCTION__,chan,carrNo);
        return BSP_ERROR;
    }

    switch(radioMode)
    {
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            s_FarmLteRxValidCarr[chan][carrNo] = valid;
            break;
        }
        case BSP_RADIO_STANDARD_FDD_5G:
        {
            s_FarmNrRxValidCarr[chan][carrNo] = valid;
            break;
        }
        case BSP_RADIO_STANDARD_NB_IOT:
        {
            s_FarmNbRxValidCarr[chan][carrNo] = valid;
            break;
        }
        case BSP_RADIO_STANDARD_UMTS:
        {
            s_FarmUmtsRxValidCarr[chan][carrNo] = valid;
            break;
        }
        default:
        {
            dbgErr("%s not support %d! \n",__FUNCTION__,radioMode);
            return BSP_ERROR;
        }
    }
    return BSP_OK;
}


UINT32 BspGetFarmTxCarrSwitch(UINT32 bspChan, UINT32 radioMode, UINT32 carrIdx)
{
    UINT32    sw = SWITCH_OFF;
    if((bspChan >= MAX_TX_CHAN) || (carrIdx >= MAX_CARRIERS_NUM))
    {
        return sw;
    }

    switch(radioMode)
    {
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            sw = s_FarmLteTxValidCarr[bspChan][carrIdx];
            break;
        }
        case BSP_RADIO_STANDARD_FDD_5G:
        {
            sw = s_FarmNrTxValidCarr[bspChan][carrIdx];
            break;
        }
        case BSP_RADIO_STANDARD_NB_IOT:
        {
            sw = s_FarmNbTxValidCarr[bspChan][carrIdx];
            break;
        }
        case BSP_RADIO_STANDARD_UMTS:
        {
            sw = s_FarmUmtsTxValidCarr[bspChan][carrIdx];
            break;
        }
        default:
        {
            break;
        }
    }
    return sw;
}

UINT32 BspGetFarmRxCarrSwitch(UINT32 bspChan, UINT32 radioMode, UINT32 carrIdx)
{
    UINT32    sw = SWITCH_OFF;
    if((bspChan >= MAX_RX_CHAN) || (carrIdx >= MAX_CARRIERS_NUM))
    {
        return sw;
    }

    switch(radioMode)
    {
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            sw = s_FarmLteRxValidCarr[bspChan][carrIdx];
            break;
        }
        case BSP_RADIO_STANDARD_FDD_5G:
        {
            sw = s_FarmNrRxValidCarr[bspChan][carrIdx];
            break;
        }
        case BSP_RADIO_STANDARD_NB_IOT:
        {
            sw = s_FarmNbRxValidCarr[bspChan][carrIdx];
            break;
        }
        case BSP_RADIO_STANDARD_UMTS:
        {
            sw = s_FarmUmtsRxValidCarr[bspChan][carrIdx];
            break;
        }
        default:
        {
            break;
        }
    }
    return sw;
}

BOOL BspIsFarmLteValidTxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validLteCarr = 0;

    if (chan >= MAX_TX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr<BSP_MAX_CARR_NUM;carr++)
    {
         if(s_FarmLteTxValidCarr[chan][carr])
         {
             validLteCarr++;
         }
    }

    if (validLteCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmNrValidTxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validNrCarr = 0;

    if (chan >= MAX_TX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr<BSP_MAX_CARR_NUM;carr++)
    {
         if(s_FarmNrTxValidCarr[chan][carr])
         {
             validNrCarr++;
         }
    }

    if (validNrCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmNbValidTxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validNbCarr = 0;

    if (chan >= MAX_TX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr<BSP_MAX_CARR_NUM;carr++)
    {
         if(s_FarmNbTxValidCarr[chan][carr])
         {
             validNbCarr++;
         }
    }

    if (validNbCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmUmtsValidTxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validUmtsCarr = 0;

    if (chan >= MAX_TX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr < BSP_MAX_CARR_NUM; carr++)
    {
         if(s_FarmUmtsTxValidCarr[chan][carr])
         {
             validUmtsCarr++;
         }
    }

    if (validUmtsCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmValidTxChan(UINT32 chan, UINT32 radioMode)
{
    BOOL  retVal = FALSE;
    if (chan >= MAX_TX_CHAN)
    {
        return FALSE;
    }

    switch(radioMode)
    {
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            retVal = BspIsFarmLteValidTxChan(chan);
            break;
        }
        case BSP_RADIO_STANDARD_FDD_5G:
        {
            retVal = BspIsFarmNrValidTxChan(chan);
            break;
        }
        case BSP_RADIO_STANDARD_NB_IOT:
        {
            retVal = BspIsFarmNbValidTxChan(chan);
            break;
        }
        case BSP_RADIO_STANDARD_UMTS:
        {
            retVal = BspIsFarmUmtsValidTxChan(chan);
            break;
        }
        default:
        {
            break;
        }
    }
    return  retVal;
}

BOOL BspIsFarmLteValidRxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validLteCarr = 0;

    if (chan >= MAX_RX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr<BSP_MAX_CARR_NUM;carr++)
    {
         if(s_FarmLteRxValidCarr[chan][carr])
         {
             validLteCarr++;
         }
    }

    if (validLteCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmNrValidRxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validNrCarr = 0;

    if (chan >= MAX_RX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr<BSP_MAX_CARR_NUM;carr++)
    {
         if(s_FarmNrRxValidCarr[chan][carr])
         {
             validNrCarr++;
         }
    }

    if (validNrCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmNbValidRxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validNbCarr = 0;

    if (chan >= MAX_RX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr<BSP_MAX_CARR_NUM;carr++)
    {
         if(s_FarmNbRxValidCarr[chan][carr])
         {
             validNbCarr++;
         }
    }

    if (validNbCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmUmtsValidRxChan(UINT32 chan)
{
    UINT32  carr = 0;
    UINT32  validUmtsCarr = 0;

    if (chan >= MAX_RX_CHAN)
    {
        return FALSE;
    }

    for (carr = 0; carr < BSP_MAX_CARR_NUM; carr++)
    {
         if(s_FarmUmtsRxValidCarr[chan][carr])
         {
             validUmtsCarr++;
         }
    }

    if (validUmtsCarr > 0)
    {
        return TRUE;
    }

    return FALSE;
}

BOOL BspIsFarmValidRxChan(UINT32 chan, UINT32 radioMode)
{
    BOOL  retVal = FALSE;
    if (chan >= MAX_RX_CHAN)
    {
        return FALSE;
    }

    switch(radioMode)
    {
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            retVal = BspIsFarmLteValidRxChan(chan);
            break;
        }
        case BSP_RADIO_STANDARD_FDD_5G:
        {
            retVal = BspIsFarmNrValidRxChan(chan);
            break;
        }
        case BSP_RADIO_STANDARD_NB_IOT:
        {
            retVal = BspIsFarmNbValidRxChan(chan);
            break;
        }
        case BSP_RADIO_STANDARD_UMTS:
        {
            retVal = BspIsFarmUmtsValidRxChan(chan);
            break;
        }
        default:
        {
            break;
        }
    }
    return  retVal;
}

UINT32 BspSetTxFarmingVaildCarr(T_FarmVaildCarrInfoPerChan *pframChnCarrInfo)
{
    UINT32  carr = 0;
    UINT32  shareChan = BSP_INVALID_VALUE;
    UINT32  carrNum = 0;
    UINT32  farmSectorScene = 0;
    UINT32  carrNo = 0;
    UINT32  carrRadio = 0;

    INPUT_POINTER_CHECK(pframChnCarrInfo);

    shareChan = pframChnCarrInfo->chanNo;
    carrNum = pframChnCarrInfo->carrNum;
    farmSectorScene = pframChnCarrInfo->farmingSectorScene;
    BspLog(LOG_LEVEL_0,"%s{chan=%lu,farmScene=%lu,carrNum=%lu}\n", __FUNCTION__, shareChan, farmSectorScene,carrNum);
    if((shareChan >= MAX_TX_CHAN) || (carrNum >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    memset_s(s_FarmLteTxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));
    memset_s(s_FarmNrTxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));
    memset_s(s_FarmNbTxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));
    memset_s(s_FarmUmtsTxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));

    for (carr = 0; carr<carrNum;carr++)
    {
        carrRadio = pframChnCarrInfo->carrInfo[carr].radioMode;
        carrNo = pframChnCarrInfo->carrInfo[carr].carrNo;
        BspSetFarmTxValidCarr(shareChan,carrRadio ,carrNo,farmSectorScene);
        BspLog(LOG_LEVEL_0,"%s{carrNo=%lu,radio=%lu}\n", __FUNCTION__, carrNo, carrRadio);
    }

    return BSP_OK;
}

UINT32 BspSetRxFarmingVaildCarr(T_FarmVaildCarrInfoPerChan *pframChnCarrInfo)
{
    UINT32  carr = 0;
    UINT32  shareChan = BSP_INVALID_VALUE;
    UINT32  carrNum = 0;
    UINT32  farmSectorScene = 0;
    UINT32  carrNo = 0;
    UINT32  carrRadio = 0;

    INPUT_POINTER_CHECK(pframChnCarrInfo);

    shareChan = pframChnCarrInfo->chanNo;
    carrNum = pframChnCarrInfo->carrNum;
    farmSectorScene = pframChnCarrInfo->farmingSectorScene;
    BspLog(LOG_LEVEL_0,"%s{chan=%lu,farmScene=%lu,carrNum=%lu}\n", __FUNCTION__, shareChan, farmSectorScene,carrNum);
    if((shareChan >= MAX_RX_CHAN) || (carrNum >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    memset_s(s_FarmLteRxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));
    memset_s(s_FarmNrRxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));
    memset_s(s_FarmNbRxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));
    memset_s(s_FarmUmtsRxValidCarr[shareChan], (MAX_CARRIERS_NUM * sizeof(UINT32)), 0, (MAX_CARRIERS_NUM * sizeof(UINT32)));

    for (carr = 0; carr<carrNum;carr++)
    {
        carrRadio = pframChnCarrInfo->carrInfo[carr].radioMode;
        carrNo = pframChnCarrInfo->carrInfo[carr].carrNo;
        BspSetFarmRxValidCarr(shareChan, carrRadio,carrNo,farmSectorScene);
        BspLog(LOG_LEVEL_0,"%s{carrNo=%lu,radio=%lu}\n", __FUNCTION__, carrNo, carrRadio);
    }

    return BSP_OK;
}

UINT32 testfarmcfg(UINT32 scene, UINT32 radioMode)
{
    T_FarmVaildCarrInfoPerChan  *pframChnCarrInfo = NULL;

    pframChnCarrInfo = (T_FarmVaildCarrInfoPerChan *)malloc(sizeof(T_FarmVaildCarrInfoPerChan));
    if (NULL == pframChnCarrInfo)
    {
        return BSP_ERROR;
    }

    memset_s(pframChnCarrInfo,sizeof(T_FarmVaildCarrInfoPerChan),0,sizeof(T_FarmVaildCarrInfoPerChan));

    pframChnCarrInfo->chanNo = 3;
    pframChnCarrInfo->farmingSectorScene = scene;
    pframChnCarrInfo->carrNum = 1;
    pframChnCarrInfo->carrInfo[0].carrNo = 0;
    pframChnCarrInfo->carrInfo[0].radioMode = radioMode;

    BspSetTxFarmingVaildCarr(pframChnCarrInfo);
    BspSetRxFarmingVaildCarr(pframChnCarrInfo);

    free(pframChnCarrInfo);
    return BSP_OK;
}

/* 提示词：请设计一个C函数，判断rfChnStart和rfChnEnd大小，小的赋值给rfChnStart, 大的赋值给rfChnEnd */
/* Started by AICoder, pid:f8956e08fdc741b7970cc9408ba8a347 */
void AssignChannels(UINT32 *rfChnStart, UINT32 *rfChnEnd)
{
    if ((rfChnStart == NULL) || (rfChnEnd == NULL) )
    {
        return;
    }

    if (*rfChnStart > *rfChnEnd)
    {
        UINT32 temp = *rfChnStart;
        *rfChnStart = *rfChnEnd;
        *rfChnEnd = temp;
    }
}
/* Ended by AICoder, pid:f8956e08fdc741b7970cc9408ba8a347 */

/* Started by AICoder, pid:6d9f0de8c8f44a7e96f7dbab56240057 */
/**
 * 函数名称: showrruvswrpara
 * 功能描述: 根据起始通道和结束通道，打印某结构体关于这些通道的所有信息
 * 输入参数: rfChnStart - 起始通道
 *           rfChnEnd   - 结束通道
 * 输出参数: 无
 * 返回值:    无
*/
VOID showrruvswrpara(UINT32 rfChnStart, UINT32 rfChnEnd)
{
    UINT32 chan = 0;
    UINT32 carrNum = 0;
    T_RruVswrInfo *pRruVswrCfg = NULL;

    /* 判断入参合法性 */
    if ((rfChnStart >= BSP_MAX_TX_CHAN )|| (rfChnEnd >= BSP_MAX_TX_CHAN))
    {
        return;
    }

    AssignChannels(&rfChnStart, &rfChnEnd);

    pRruVswrCfg = BspGetRruVswrCfgMem();
    if (pRruVswrCfg == NULL)
    {
        return;
    }

    for (chan = rfChnStart; chan <= rfChnEnd; ++chan)
    {
        dbgInfo("Channel %u, CarrNum %u:\n", chan, pRruVswrCfg[chan].uiCarrNum);
        /* 判断载波数量合法性 */
        if (pRruVswrCfg[chan].uiCarrNum > BSP_MAX_CARR_NUM)
        {
            continue;
        }

        for (carrNum = 0; carrNum < pRruVswrCfg[chan].uiCarrNum; ++carrNum)
        {
            dbgInfo("Carr %u:\n", carrNum);
            dbgInfo("uiCarrBitNumL: %u\n", pRruVswrCfg[chan].carr[carrNum].uiCarrBitNumL);
            dbgInfo("uiCarrBitNumH: %u\n", pRruVswrCfg[chan].carr[carrNum].uiCarrBitNumH);
            dbgInfo("uiSubCarrierSpacing: %u\n", pRruVswrCfg[chan].carr[carrNum].uiSubCarrierSpacing);
            dbgInfo("uiSsbGscn: %u\n", pRruVswrCfg[chan].carr[carrNum].uiSsbGscn);
            dbgInfo("uiSsbSubBeamValidL: %u\n", pRruVswrCfg[chan].carr[carrNum].uiSsbSubBeamValidL);
            dbgInfo("uiSsbSubBeamValidH: %u\n", pRruVswrCfg[chan].carr[carrNum].uiSsbSubBeamValidH);
            dbgInfo("uiSsbPeriod: %u\n", pRruVswrCfg[chan].carr[carrNum].uiSsbPeriod);
            dbgInfo("iFraAHeadAdj: %d\n", pRruVswrCfg[chan].carr[carrNum].iFraAHeadAdj);
            dbgInfo("ssbSymbolFlag: %u\n", pRruVswrCfg[chan].carr[carrNum].ssbSymbolFlag);
            dbgInfo("ssbSymbolIndex: %u\n", pRruVswrCfg[chan].carr[carrNum].ssbSymbolIndex);
        }
    }
}
/* Ended by AICoder, pid:6d9f0de8c8f44a7e96f7dbab56240057 */

/* Started by AICoder, pid:n720cwf09943fd5142e80ade3036271a34e6c5e1 */
VOID BspClrTxFarmCfg(VOID)
{
    UINT32 chanNum = BspGetTxChannel();
    UINT32 chan = 0;

    if (chanNum > MAX_TX_CHAN)
    {
        return;
    }

    for (chan = 0; chan < chanNum; chan++)
    {
        memset_s(s_FarmLteTxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
        memset_s(s_FarmNrTxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
        memset_s(s_FarmNbTxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
        memset_s(s_FarmUmtsTxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
    }
}
/* Ended by AICoder, pid:n720cwf09943fd5142e80ade3036271a34e6c5e1 */

/* Started by AICoder, pid:58a4cw8824709ba1434909eaf0e3da1715a665d9 */
VOID BspClrRxFarmCfg(VOID)
{
    UINT32 chanNum = BspGetRxChannel();
    UINT32 chan = 0;

    if (chanNum > MAX_RX_CHAN)
    {
        return;
    }

    for (chan = 0; chan < chanNum; chan++)
    {
        memset_s(s_FarmLteRxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
        memset_s(s_FarmNrRxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
        memset_s(s_FarmNbRxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
        memset_s(s_FarmUmtsRxValidCarr[chan], sizeof(UINT32) * MAX_CARRIERS_NUM, 0, sizeof(UINT32) * MAX_CARRIERS_NUM);
    }
}
/* Ended by AICoder, pid:58a4cw8824709ba1434909eaf0e3da1715a665d9 */

VOID BspClrFarmCfg(VOID)
{
    BspClrTxFarmCfg();
    BspClrRxFarmCfg();
}

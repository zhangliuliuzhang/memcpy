#include "bsppub.h"
#include "funccommon_fpga.h"


static T_FpgaInfoInit *pFpgaInitInfo = NULL;

UINT32 BspSetFpgaInfo(T_FpgaInfoInit *pFpgaInfo)
{
    pFpgaInitInfo = pFpgaInfo;
    return BSP_OK;
}

T_FpgaInfoInit *BspGetFpgaInfo(VOID)
{
    return pFpgaInitInfo;
}

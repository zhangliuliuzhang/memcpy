/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : FUNCCOMMON
* 文件名称 : funccommon_fpgaablity.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了FPGA能力上报接口
* 注意事项 : 无
* 作    者 : 00074246
* 创建日期 : 2018-5-15 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明:

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "regdrv_accesstbl.h"
#include "regdrv_access.h"
#include "funccommon_fpgaablity.h"

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static T_FpgaAblityInfo s_tFpgaAblityInfo = {0};
static pGetCfrRamAblity s_pGetCfrRamDefFunc = NULL;
static FUNC_GET_DTX_ABILITY pGetDtxChkAbility = NULL;

static UINT32  s_CalcFreqBandType = 0;  /* R9224_fpga 通道功率需要频段功率做和，标识是否支持频段做和的标识 */
static UINT32  s_GNCarrEnFlag = 0;  /* 切逻辑机型，GN载波使能需要按照上下行分别配置 */
static UINT32  s_GsmDivRssiSupport = 0;  /* R9214 R9224 GSM 分集RSSI 支持前台rssi查询 */

static FUNC_IS_SUPPORT_NR_BIG_BW pIsSupportNrBigBw = NULL;

/**************************************************************************
 *                         函数实现
 **************************************************************************/

pGetCfrRamAblity BspGetCfrRamDefCallBack(VOID)
{
   return s_pGetCfrRamDefFunc;
}

UINT32 BspCfrRamDefCallBackInit(pGetCfrRamAblity pCallBackFunc)
{
    s_pGetCfrRamDefFunc = pCallBackFunc;

   return BSP_OK;
}

void BspSetFreqBandType(UINT32 ulFlag)
{
	s_CalcFreqBandType = ulFlag;
}

UINT32 BspGetFreqBandType(VOID)
{
	return s_CalcFreqBandType ;
}

UINT32 BspGetGsmDivRssi(VOID)
{
	return s_GsmDivRssiSupport;
}

void BspSetGsmDivRssi(UINT32 ulFlag)
{
	s_GsmDivRssiSupport = ulFlag;
}

void BspSetGNCarrEnFlag(UINT32 ulFlag)
{
	s_GNCarrEnFlag = ulFlag;
}

UINT32 BspGetGNCarrEnFlag(VOID)
{
	return s_GNCarrEnFlag ;
}

UINT32 BspGetFpgaAblityRamVal(UINT32 uChipId, UINT32 uAddr)
{
    UINT32 uRegVal = 0;
    pGetCfrRamAblity pFuncGetCfrRamDef = NULL;

    pFuncGetCfrRamDef = BspGetCfrRamDefCallBack();
    if (NULL != pFuncGetCfrRamDef)
    {
        pFuncGetCfrRamDef(uChipId, uAddr, &uRegVal);
    }
    else
    {
        BspRegWr(uChipId, REG_FPGA_FEATURE_ROM_ADDR, 0, uAddr);
        BspRegRd(uChipId, REG_FPGA_FEATURE_ROM_DATA, 0, &uRegVal);    	
    }

	return uRegVal;
}

UINT32 BspGetFpgaAblity(UINT32 uChipId)
{
	UINT32 uRet = BSP_OK;
	UINT32 uRegVal = 0;
	UINT32 auDlyInfo[4] = {0,150,250,150};
	/* 0:10m,1:20m,2:25m,3:30m,4:40m,5:50m,6:60m,7:70m,8:80m,9:90m,10:100m. */
	UINT32 auNrBw[11] = {10000,20000,30000,40000,50000,60000,70000,80000,100000};

	uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_COMMON_VERSION);/* 版本号 */
	s_tFpgaAblityInfo.usVer = (UINT16)uRegVal;
	if ((0 != uRegVal) && (0xffff != uRegVal))
	{
		s_tFpgaAblityInfo.usFlag     = 1;
		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_COMMON_MAX_CARR_NUM);/* carrNum */
		s_tFpgaAblityInfo.usMaxCarrNum[TX] = (uRegVal>>8)&0xff;
		s_tFpgaAblityInfo.usMaxCarrNum[RX] = (uRegVal)&0xff;


		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_COMMON_TX_BAND0_CARR_NUM);/* 通道载波个数 */
		s_tFpgaAblityInfo.usBandCarrNum[TX][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(0,FEATURE_COMMON_TX_BAND1_CARR_NUM);/*  */
		s_tFpgaAblityInfo.usBandCarrNum[TX][1] = uRegVal&0xf;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_COMMON_RX_BAND0_CARR_NUM);/* 通道载波个数 */
		s_tFpgaAblityInfo.usBandCarrNum[RX][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(0,FEATURE_COMMON_RX_BAND1_CARR_NUM);/*  */
		s_tFpgaAblityInfo.usBandCarrNum[RX][1] = uRegVal&0xf;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_GSM_MAX_CARR_NUM);/* GSM载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_GSM][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(0,FEATURE_GSM_NCO_START_POS);/* GSM载波nco起始位置 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_GSM][1] = uRegVal&0xf;


		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_UMTS_MAX_CARR_NUM);/* UMTS载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_UMTS][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(0,FEATURE_UMTS_NCO_START_POS);/* UMTS载波起始位置 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_UMTS][1] = uRegVal&0xf;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NR_MAX_CARR_NUM);/* NR载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NR_NCO_START_POS);/*  NR载波nco起始位置 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR][1] = uRegVal&0xf;
		s_tFpgaAblityInfo.ulNrDtxSupport = uRegVal&0x100;/* Nr载波DTX能力上报bit8 */
		
		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NR_CARR_MAP_START_NO);/*  小带宽NR载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR][2] = uRegVal;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_LTE_MAX_CARR_NUM);/* LTE载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_LTE_FDD][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(0,FEATURE_LTE_NCO_START_POS);/* LTE载波nco起始位置 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_LTE_FDD][1] = uRegVal&0xf;
		s_tFpgaAblityInfo.ulLteDtxSupport = uRegVal&0x100;/* LTE载波DTX能力上报bit8 */

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NR_IF0_MAX_CARR_NUM);/* NR 30M载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF0][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(0,FEATURE_NR_IF0_NCO_START_POS);/* NR 30M载波nco起始位置 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF0][1] = uRegVal&0xf;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NR_IF1_MAX_CARR_NUM);/* NR 40M载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF1][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(0,FEATURE_NR_IF1_NCO_START_POS);/* NR 40M载波nco起始位置 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF1][1] = uRegVal&0xf;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NB_MAX_CARR_NUM);/* NB载波个数 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NBIOT][0] = uRegVal&0xf;
		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NB_NCO_START_POS);/* NB载波nco起始位置 */
		s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NBIOT][1] = uRegVal&0xf;
		s_tFpgaAblityInfo.ulNbDtxSupport = uRegVal&0x100;/* NB载波DTX能力上报bit8 */


		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NR_CARR_BAND);/* NR BW */
		s_tFpgaAblityInfo.usNrCarrBwInfo[0] = ((uRegVal&0xf)<11)?auNrBw[(uRegVal&0xf)]:0;
		s_tFpgaAblityInfo.usNrCarrBwInfo[1] = (((uRegVal>>4)&0xf)<11)?auNrBw[(uRegVal>>4)&0xf]:0;
		s_tFpgaAblityInfo.usNrCarrBwInfo[2] = (((uRegVal>>8)&0xf)<11)?auNrBw[(uRegVal>>8)&0xf]:0;
		s_tFpgaAblityInfo.usNrCarrBwInfo[3] = (((uRegVal>>12)&0xf)<11)?auNrBw[(uRegVal>>12)&0xf]:0;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_LTE_DELAY);/* LTE dly */
		s_tFpgaAblityInfo.usLteDlyAblity[0] = auDlyInfo[uRegVal&0x3];
		s_tFpgaAblityInfo.usLteDlyAblity[1] = auDlyInfo[(uRegVal>>8)&0x3];

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_NB_DELAY);/* NB dly */
		s_tFpgaAblityInfo.usNbDlyAblity[0] = auDlyInfo[uRegVal&0x3];
		s_tFpgaAblityInfo.usNbDlyAblity[1] = auDlyInfo[(uRegVal>>8)&0x3];

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_CFR_FS_RATE);/* cfr rate */
		s_tFpgaAblityInfo.uCfrRate = ((uRegVal&0xf)+1)*30720;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_CFR_DIV);/* CFR 单相多相标示*/
		s_tFpgaAblityInfo.usCfrType = uRegVal;
		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_CFR_POS);/*CFR和NCO位置关系标示*/
		s_tFpgaAblityInfo.usCfrPos = uRegVal;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_DPD_DIV);/* DPD 单相多相标示*/
		s_tFpgaAblityInfo.DpdType = uRegVal;

		uRegVal = BspGetFpgaAblityRamVal(uChipId,FEATURE_COMMON_DIF_BIT_FLAG);/* 中频处理带宽*/
		s_tFpgaAblityInfo.DifBitFlag = uRegVal&0x03;
		s_tFpgaAblityInfo.DifNcoStep = (uRegVal>>2)&0x03;

		uRegVal = BspGetFpgaAblityRamVal(uChipId, FEATURE_BITMAP_DTX_SUPPORT_FLAG);
		s_tFpgaAblityInfo.ulBitmapDtxSupport   = (uRegVal >> 0) & 0x01;
		s_tFpgaAblityInfo.ulDtxSelfTestSupport = (uRegVal >> 1) & 0x01;
	}

    return uRet;
}

UINT32 BspGetFpgaSupportCarrInfo(UINT32 radioMode, UINT32 *CarrNum, UINT32 *NcoPos)
{
	if(radioMode >= DIF_RADIOMODE_MAX)
	{
		return BSP_ERROR;
	}
	if((NULL==CarrNum)||(NULL==NcoPos))
	{
		return BSP_ERROR;
	}
	*CarrNum = s_tFpgaAblityInfo.usCarrInfo[radioMode][0];
	*NcoPos = s_tFpgaAblityInfo.usCarrInfo[radioMode][1];

	return BSP_OK;
}


UINT32 BspGetFpgaSupportUmtsCarrInfo(VOID)
{
	return s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_UMTS][0];
}


UINT32 BspGetFpgaSupportCarrBand(UINT32 *pNrCarrBwInfo, UINT32 BwInfoLens)
{
	UINT32 Index = 0;
	UINT32 uRegVal = 0;

	if(NULL==pNrCarrBwInfo)
	{
		return BSP_ERROR;
	}
	uRegVal = BspGetFpgaAblityRamVal(0,74);/* NR BW FEATURE_NR_CARR_BAND*/
	for(Index=0; Index<BwInfoLens; Index++)
	{
		pNrCarrBwInfo[Index] = (uRegVal>>(8*Index)) & 0xf;
		dbgInfoEx("%s: Index[%d], BW[%d]\n", __FUNCTION__, Index, pNrCarrBwInfo[Index]);
	}

	return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 BspGetCarrMapStartNo(UINT32 radioMode, UINT32 *CarrStartNo)
{
	if(radioMode >= DIF_RADIOMODE_MAX)
	{
		return BSP_ERROR;
	}
	if(NULL==CarrStartNo)
	{
		return BSP_ERROR;
	}
	*CarrStartNo = (s_tFpgaAblityInfo.usCarrInfo[radioMode][2]>>4)&0x0FFF;

	return BSP_OK;
}

#endif

UINT32 BspGetDifBitFlag(VOID)
{
	return s_tFpgaAblityInfo.DifBitFlag;
}

VOID BspGetDtxChkAbilityCallBackInit(FUNC_GET_DTX_ABILITY pfGetDtxChkAbility)
{
    pGetDtxChkAbility = pfGetDtxChkAbility;
}

UINT32 BspGetDifNcoStep(VOID)
{
	return s_tFpgaAblityInfo.DifNcoStep;
}

UINT32 BspGetDpdType(VOID)
{
	return s_tFpgaAblityInfo.DpdType;
}

UINT32 BspGetBitmapDtxSupportFlag(UINT32 ulChipId)
{
    if (1 != s_tFpgaAblityInfo.usFlag) /* 只上报告警信息 */
    {
        dbgErr("%s>>Error! ChipId'%d No Support FpgaAblity!\n",
               __FUNCTION__, ulChipId);
    }

	return s_tFpgaAblityInfo.ulBitmapDtxSupport;
}

UINT32 BspGetDtxSelfTestSupportFlag(UINT32 ulChipId)
{
    if (1 != s_tFpgaAblityInfo.usFlag) /* 只上报告警信息 */
    {
        dbgErr("%s>>Error! ChipId'%d No Support FpgaAblity!\n",
               __FUNCTION__, ulChipId);
    }

	return s_tFpgaAblityInfo.ulDtxSelfTestSupport;
}

UINT32 showfpgaablity(VOID)
{
    if(1==s_tFpgaAblityInfo.usFlag)
    {
	    dbgInfo("Version: %04x\n",s_tFpgaAblityInfo.usVer);
	    dbgInfo("Max Carr Num: Tx(%d) Rx(%d)\n",s_tFpgaAblityInfo.usMaxCarrNum[TX],s_tFpgaAblityInfo.usMaxCarrNum[RX]);
	    dbgInfo("TX Chn Max Carr Num: Band0(%d) Band1(%d)\n",s_tFpgaAblityInfo.usBandCarrNum[TX][0],s_tFpgaAblityInfo.usBandCarrNum[TX][1]);
	    dbgInfo("RX Chn Max Carr Num: Band0(%d) Band1(%d)\n",s_tFpgaAblityInfo.usBandCarrNum[RX][0],s_tFpgaAblityInfo.usBandCarrNum[RX][1]);
	    dbgInfo("Gsm     Carr Info: Num(%d) Nco Offset(%d)\n",s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_GSM][0],s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_GSM][1]);
	    dbgInfo("UMTS    Carr Info: Num(%d) Nco Offset(%d)\n",s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_UMTS][0],s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_UMTS][1]);
	    dbgInfo("NR      Carr Info: Num(%d) Nco Offset(%d)\n",s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR][0],s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR][1]);
	    dbgInfo("LTE FDD Carr Info: Num(%d) Nco Offset(%d)\n",s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_LTE_FDD][0],s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_LTE_FDD][1]);

		dbgInfo("NR30M   Carr Info: Num(%d) Nco Offset(%d)\n",s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF0][0],s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF0][1]);
		dbgInfo("NR40M   Carr Info: Num(%d) Nco Offset(%d)\n",s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF1][0],s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NR_IF1][1]);

	    dbgInfo("NB      Carr Info: Num(%d) Nco Offset(%d)\n",s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NBIOT][0],s_tFpgaAblityInfo.usCarrInfo[DIF_RADIOMODE_NBIOT][1]);
	    dbgInfo("Nr Carr Bw Info: carr0(%d) carr1(%d) carr2(%d) carr3(%d)\n",s_tFpgaAblityInfo.usNrCarrBwInfo[0],s_tFpgaAblityInfo.usNrCarrBwInfo[1],s_tFpgaAblityInfo.usNrCarrBwInfo[2],s_tFpgaAblityInfo.usNrCarrBwInfo[3]);
	    dbgInfo("Fpga Lte Dly Albity: Dl(%d us) Ul(%d us)\n",s_tFpgaAblityInfo.usLteDlyAblity[0],s_tFpgaAblityInfo.usLteDlyAblity[1]);
	    dbgInfo("Fpga Nb Dly Albity: Dl(%d us) Ul(%d us)\n",s_tFpgaAblityInfo.usNbDlyAblity[0],s_tFpgaAblityInfo.usNbDlyAblity[1]);
	    dbgInfo("Fpga Cfr Info: Work Clk: CLK(%d) Type(%d) Pos(%d)\n",s_tFpgaAblityInfo.uCfrRate,s_tFpgaAblityInfo.usCfrType,s_tFpgaAblityInfo.usCfrPos);
	    dbgInfo("Fpga Dif Info: Bit Flag(%d) Nco Step(%d)\n",s_tFpgaAblityInfo.DifBitFlag, s_tFpgaAblityInfo.DifNcoStep);
	    dbgInfo("Fpga DpdType Info: DpdType(%d)\n",s_tFpgaAblityInfo.DpdType);
	    dbgInfo("Fpga BitmapDtxSupportFlag(0:No 1:Yes)= %d\n",s_tFpgaAblityInfo.ulBitmapDtxSupport);
	    dbgInfo("Fpga DtxSelfTestSupportFlag(0:No 1:Yes)= %d\n",s_tFpgaAblityInfo.ulDtxSelfTestSupport);
	}
	else
	{
        dbgInfo("No Support Fpga Ablity\n");
	}
    return BSP_OK;
}

UINT32 BspIsFpgaSupportNrBigBwCallBackInit(FUNC_IS_SUPPORT_NR_BIG_BW ptFunc)
{
	pIsSupportNrBigBw = ptFunc;
	return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetFpgaAntiIntfMode(VOID)
 * 功能描述: FPGA机型添加抗干扰能力上报功能
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 返回值: 0-单段(正常)，1-双段，2-双段兼容单段, 3-不支持抗干扰类型
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2022年3月18日 
 **************************************************************************/
UINT32 BspGetFpgaAntiIntfMode(VOID)
{
	UINT32 uRegVal = ANTI_INTF_MODE_NOT_SUPPORT;
	UINT32 chipId = 0;
	if(pIsSupportNrBigBw != NULL)
	{
		if(IS_SUPPORT_NR_BIG_BW == pIsSupportNrBigBw())
		{
			uRegVal = BspGetFpgaAblityRamVal(chipId,FEATURE_ANTI_INTF_MODE_IF0);
		}
	}
	return uRegVal & 0xF;
}

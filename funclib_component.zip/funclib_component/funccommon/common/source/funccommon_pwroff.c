
#include "bsppub.h"
#include "bspcomm.h"
#include "vxadp.h"
#include "bspcommon.h"
#include "secure_func.h"
#include "funccommon.h"
#include "ru_univdef.h"
#include "exprn.h"
#include "systemcallapi.h"
#ifndef _4C_VDE_TEST_
#include "fpgaload.h"
#endif


#define BSP_PWR_OFF_REC_DIR        "/ata/.bspcfg/"
#define BSP_PWR_OFF_REC_FILE       "/ata/.bspcfg/pwroffrec.ini"
#define BSP_PWR_OFF_REC_TEST       "/ata/.bspcfg/pwroffrectest"
#define AAU_LINK_PWROFF_FILE       "/ata/.bspcfg/bsppwrofflog.txt"

#define BSP_PWR_OFF_MAX_CNT        40
#define BSP_PWR_OFF_DEF_ENID       0x5A
#define BSP_PWR_OFF_DEF_DISID      0x2D

#define BSP_PWR_OFF_TYPE_NO_EN     0
#define BSP_PWR_OFF_TYPE_VER_ACT   1
#define BSP_PWR_OFF_TYPE_NOR_RUN   2
#define BSP_PWR_OFF_TYPE_ROLL_BACK 3

#define PWROFF_REC_INIT_MODE_CRT   0  /* 创建 */
#define PWROFF_REC_INIT_MODE_MOD   1  /* 修改 */

#define STR_RRUCFG_INI_BAK         "/ata/RRUCFG.INI.PWROFF"

#define RRU_LINK_PWR_OFF_ENABLE_CHK()          \
{                                              \
    if (s_rruLinkPwrOffEnable != 0x5A5A)       \
    {                                          \
        return BSP_ERROR;                      \
    }                                          \
}

#define RRU_LINK_PWR_OFF_VALID_CHK()           \
{                                              \
    if (s_rruLinkPwrOffEnable != 0x5A5A)       \
    {                                          \
        return BSP_ERROR;                      \
    }                                          \
    if (s_rruLinkPwrOffInit != 0x5A5A)         \
    {                                          \
        return BSP_ERROR;                      \
    }                                          \
    if (BSP_OK == BspIsFileExist(BSP_PWR_OFF_REC_TEST)) \
    {                                          \
        return BSP_ERROR;                      \
    }                                          \
}

#define PWR_OFF_TYPE_CHK(a)  \
    if (((a) != BSP_PWR_OFF_TYPE_VER_ACT) && ((a) != BSP_PWR_OFF_TYPE_NOR_RUN) && ((a) != BSP_PWR_OFF_TYPE_ROLL_BACK)) \
    {                        \
        return BSP_ERROR;    \
    }

#define PWR_OFF_REST_TIME_CHK(rec)  if (rec.restTimes > BSP_PWR_OFF_MAX_CNT) return BSP_ERROR
#define PWR_OFF_ROLL_BACK_CHK(rec)  if (rec.isRollBack != BSP_PWR_OFF_DEF_ENID) return BSP_ERROR
#define PWR_OFF_ENABLE_ID_CHK(rec)  if (rec.isEnable != BSP_PWR_OFF_DEF_ENID) return BSP_ERROR

#define PWR_OFF_ENABLE_ID_GET(rec)  ((rec.isEnable == BSP_PWR_OFF_DEF_ENID) ? 1 : 0)
#define PWR_OFF_ROLL_BACK_GET(rec)  ((rec.isRollBack == BSP_PWR_OFF_DEF_ENID) ? 1 : 0)

#define PWR_OFF_KW_COV(a)           if ((a) != 0)  dbgInfoEx("%s,%d:ret=%d\n",__FUNCTION__,__LINE__,(a))

static UINT32 linkpwroffFileMaxSize =  0x80000;//文件大小为512K
static SEM_ID LinkPwrOffLogSem = NULL;
static FILE   *fplinkpwroffLog = NULL;
#define rrulinkpwroffLog(fmt,...)    RruLinkPwrOffLogPrint(fmt, ##__VA_ARGS__)

static VOID SetRruLinkPwrOffFileSize(UINT32 maxSize)
{
    linkpwroffFileMaxSize = maxSize;
}
static UINT32 GetRruLinkPwrOffFileSize(VOID)
{
    return linkpwroffFileMaxSize;
}

static UINT32 SemLinkPwrOffLogInit(VOID)
{
    static UINT8 s_SemLinkPwrOffLogInit = 0;

    if (1 == s_SemLinkPwrOffLogInit)
    {
        return BSP_OK;
    }

    LinkPwrOffLogSem = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (NULL == LinkPwrOffLogSem)
    {
        dbgErr("%s>>SemBCreate Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    s_SemLinkPwrOffLogInit = 1;
    return BSP_OK;
}

static UINT32 BspGetLinkPwrOffLogSem(VOID)
{
    if (BSP_OK != SemLinkPwrOffLogInit())
    {
        return BSP_ERROR;
    }
    semTake(LinkPwrOffLogSem, WAIT_FOREVER);
    return BSP_OK;
}

static UINT32 BspRlsLinkPwrOffLogSem(VOID)
{
    semGive(LinkPwrOffLogSem);
    return BSP_OK;
}

UINT32 RruLinkPwrOffLogInit(VOID)
{
    CHAR * const dirlist[1] = {"/ata/.bspcfg"};
    rsize_t dirlist_size = 1;
    const CHAR *acFileName = "/ata/.bspcfg/bsppwrofflog.txt";

    INT32 ret = zte_fopen_s(&fplinkpwroffLog, acFileName, "a+", dirlist, dirlist_size);
    if(0 != ret)
    {
        const CHAR* err_info = zte_strerror_s(zte_errno);
        dbgErr("failed to open file /ata/.bspcfg/bsppwrofflog.txt,error in detail : %s\n",err_info);
        return BSP_ERROR;
    }

    dbgInfo("%s>> Init Succ!\n", __FUNCTION__);

    return BSP_OK;
}

FILE *BspGetRruLinkPwrOffFp(VOID)
{
    UINT32 size = 0;
    INT32 fclsRet = 0;
    CHAR * const dirlist[1] = {"/ata/.bspcfg"};
    rsize_t dirlist_size = 1;
    const CHAR *acFileName = "/ata/.bspcfg/bsppwrofflog.txt";
    INT32 ret = 0;

    if (BSP_ERROR == BspGetLinkPwrOffLogSem())
    {
        dbgErr("%s>>FpgaLoadLogSem Get Error!\n", __FUNCTION__);
        return NULL;
    }
    if (fplinkpwroffLog == NULL)
    {
        BspRlsLinkPwrOffLogSem();
        dbgErr("%s>>Error! pFpRruLinkPwrOffLog NULL\n", __FUNCTION__);
        return NULL;
    }

    size = ftell(fplinkpwroffLog);
    if (size > linkpwroffFileMaxSize)
    {
        dbgInfo("%s>> size:0x%x > MaxSize:0x%x\n", __FUNCTION__,size,linkpwroffFileMaxSize);
        fclsRet = fclose(fplinkpwroffLog);
        FCLOSE_CHECK(fclsRet);
        BspSystem("mv /ata/.bspcfg/bsppwrofflog.txt  /ata/.bspcfg/bsppwrofflog.txt.bak");

        ret = zte_fopen_s(&fplinkpwroffLog, acFileName, "a+", dirlist, dirlist_size);
        if(0 != ret)
        {
            const CHAR* err_info = zte_strerror_s(zte_errno);
            dbgErr("failed to open file /ata/.bspcfg/bsppwrofflog.txt,error in detail : %s\n",err_info);
            BspRlsLinkPwrOffLogSem();
            return NULL;
        }

    }

    size = ftell(fplinkpwroffLog);
    if (size > linkpwroffFileMaxSize)
    {
        BspRlsLinkPwrOffLogSem();
    //  dbgErr("%s>>LogFileMaxSize Over!\n", __FUNCTION__);
        return NULL;
    }
    BspRlsLinkPwrOffLogSem();
    return fplinkpwroffLog;
}

VOID RruLinkPwrOffLogPrint(const char *format, ...)
{
    char  strTime[20] = {0};
    time_t timeRet;
    va_list ap;
    FILE   *fp = NULL;

    fp = BspGetRruLinkPwrOffFp();
    if (fp == NULL)
    {
        dbgErr("%s>>RruLinkPwrOffFp Get Error!\n", __FUNCTION__);
        return;
    }

    va_start(ap, format);

    timeRet = time(NULL);
    TIME_CHECK(timeRet);
    BspSecondToDate(strTime, sizeof(strTime), timeRet, 0);
    (void)fprintf(fp, "[%s]", strTime);
    (void)vfprintf_s(fp, format, ap);
    (void)fflush(fp);
    va_end(ap);
    return;
}

static UINT32 s_rruLinkPwrOffEnable = 0;
static UINT32 s_rruLinkPwrOffInit = 0;
static UINT32 s_PwrOffType = BSP_PWR_OFF_TYPE_NO_EN;

static UINT32 RruLinkPwrOffRecCfg(UINT32 mode,T_PwrOffRec rec)
{
    int fret = 0;
    FILE *fp = NULL;

    if (mode == PWROFF_REC_INIT_MODE_CRT)
    {
        BspMkdir(BSP_PWR_OFF_REC_DIR);
        fret = fopen_s(&fp, BSP_PWR_OFF_REC_FILE, "w+");
        PWR_OFF_KW_COV(fret);
    }
    else
    {
        fret = fopen_s(&fp, BSP_PWR_OFF_REC_FILE, "r+");
        PWR_OFF_KW_COV(fret);
    }
    if (fp == NULL)
    {
        dbgErr("%s open file %s failed\n",__FUNCTION__,BSP_PWR_OFF_REC_FILE);
        return BSP_ERROR;
    }

    if (sizeof(T_PwrOffRec) != fwrite((void *)&rec,1,sizeof(T_PwrOffRec),fp))
    {
        dbgErr("%s fwrite file %s failed\n",__FUNCTION__,BSP_PWR_OFF_REC_FILE);
    }
    fret = fflush(fp);
    PWR_OFF_KW_COV(fret);
    fret = fclose(fp);
    PWR_OFF_KW_COV(fret);

    return BSP_OK;
}

static UINT32 RruLinkPwrOffRecGet(T_PwrOffRec *pRetRec)
{
    int fret = 0;
    FILE *fp = NULL;
    T_PwrOffRec rec = {0};
    fret = fopen_s(&fp, BSP_PWR_OFF_REC_FILE, "r");
    PWR_OFF_KW_COV(fret);
    if (fp == NULL)
    {
        dbgErr("%s open file %s failed\n",__FUNCTION__,BSP_PWR_OFF_REC_FILE);
        return BSP_ERROR;
    }
    if (sizeof(T_PwrOffRec) != fread((void *)&rec,1,sizeof(T_PwrOffRec),fp))
    {
        dbgErr("%s fread file %s failed\n",__FUNCTION__,BSP_PWR_OFF_REC_FILE);
        fret = fclose(fp);
        PWR_OFF_KW_COV(fret);
        return BSP_ERROR;
    }
    fret = fclose(fp);
    PWR_OFF_KW_COV(fret);

    pRetRec->restTimes  = rec.restTimes;
    pRetRec->isEnable   = rec.isEnable;
    pRetRec->isRollBack = rec.isRollBack;
    pRetRec->reserve    = rec.reserve;
    return BSP_OK;
}

UINT32 BspGetRruLinkPwrOffRec(T_PwrOffRec *pRetRec)
{
    INPUT_POINTER_CHECK(pRetRec);

    return RruLinkPwrOffRecGet(pRetRec);
}

static UINT32 RruLinkPwrOffRecChk(const T_PwrOffRec *pSrcRec)
{
    UINT32 retVal = 0;
    T_PwrOffRec rec = {0};
    if (pSrcRec == NULL)
    {
        return BSP_ERROR;
    }
    if (BSP_OK != RruLinkPwrOffRecGet(&rec))
    {
        return BSP_ERROR;
    }

    if (0 != memcmp((const void *)pSrcRec,(const void *)&rec,sizeof(T_PwrOffRec)))
    {
        retVal = BSP_ERROR;
    }

    return retVal;
}

static VOID RruLinkPwrOffRecDataGet(UINT32 cfgType,T_PwrOffRec *pIn,T_PwrOffRec *pOut)
{
    if (pIn == NULL || pOut == NULL)
    {
        return ;
    }
    if (cfgType == BSP_PWR_OFF_TYPE_NOR_RUN)
    {
        pOut->restTimes = pIn->restTimes;
    }
    else if (cfgType == BSP_PWR_OFF_TYPE_VER_ACT)
    {
        pOut->restTimes = pIn->restTimes;
        pOut->isEnable  = pIn->isEnable;
    }
    else if (cfgType == BSP_PWR_OFF_TYPE_ROLL_BACK)
    {
        pOut->isRollBack = pIn->isRollBack;
    }
}
static UINT32 RruLinkPwrOffRecUpdate(UINT32 cfgType,T_PwrOffRec *pSrcRec,T_PwrOffRec *pRetRec)
{
    T_PwrOffRec rec = {0};

    if (BSP_OK != RruLinkPwrOffRecGet(&rec))
    {
        dbgErr("%s get rec failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    if (cfgType == BSP_PWR_OFF_TYPE_NOR_RUN)
    {
        PWR_OFF_REST_TIME_CHK(rec);
        if(rec.restTimes>0)
        {
        rec.restTimes = rec.restTimes - 1;
    }
    }
    else if (cfgType == BSP_PWR_OFF_TYPE_VER_ACT)
    {
        //PWR_OFF_REST_TIME_CHK(rec);
        //rec.restTimes = rec.restTimes - 1;
        rec.isEnable  = BSP_PWR_OFF_DEF_DISID;
    }
    else if (cfgType == BSP_PWR_OFF_TYPE_ROLL_BACK)
    {
        //PWR_OFF_REST_TIME_CHK(rec);
        //rec.restTimes = rec.restTimes - 1;
        rec.isRollBack = BSP_PWR_OFF_DEF_DISID;
    }
    RruLinkPwrOffRecDataGet(cfgType,pSrcRec,&rec);

    if (BSP_OK != RruLinkPwrOffRecCfg(PWROFF_REC_INIT_MODE_MOD, rec))
    {
        dbgErr("%s get rec failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pRetRec->restTimes  = rec.restTimes;
    pRetRec->isEnable   = rec.isEnable;
    pRetRec->isRollBack = rec.isRollBack;
    pRetRec->reserve    = rec.reserve;
    return BSP_OK;
}

static UINT32 RruLinkPwrOffRecGetRruCfg(const CHAR *pcFileName, T_Bsp_RruIniCfgItem *ptCpuCfg, T_Bsp_RruIniCfgItem *ptFpgCfg, T_Bsp_RruIniCfgItem *ptMgrCfg)
{
#ifndef _4C_VDE_TEST_
    if (BSP_OK != BspReadRuCfgIniFieldValue(pcFileName, FLAG_CPUVER, ptCpuCfg))
    {
        return BSP_ERROR;
    }
    if (BSP_OK != BspReadRuCfgIniFieldValue(pcFileName, FLAG_FPGAVER, ptFpgCfg))
    {
        if(BSP_OK == BspReadRuCfgIniFieldValue(pcFileName, FLAG_FPGA_NEWVER, ptFpgCfg))
        {
            //return BSP_OK;
        }
        //return BSP_ERROR;
    }
    if (BSP_OK != BspReadRuCfgIniFieldValue(pcFileName, FLAG_MGRVER, ptMgrCfg))
    {
    }
#endif
    return BSP_OK;
}
static UINT32 RruLinkPwrOffRecRollBackInit()
{
    T_PwrOffRec rec = {0};
    T_Bsp_RruIniCfgItem fpgCfgInfo = {0};
    T_Bsp_RruIniCfgItem cpuCfgInfo = {0};
    T_Bsp_RruIniCfgItem mgrCfgInfo = {0};

    if (BSP_OK != RruLinkPwrOffRecGet(&rec))
    {
        return BSP_ERROR;
    }
#ifndef _4C_VDE_TEST_
    if (BSP_OK != RruLinkPwrOffRecGetRruCfg(strCfgFileName, &cpuCfgInfo, &fpgCfgInfo, &mgrCfgInfo))
    {
        return BSP_ERROR;
    }
    if(rec.isRollBack != BSP_PWR_OFF_DEF_DISID)
    {
    if ((cpuCfgInfo.cFieldValue == FAILURE_BOOT) || (fpgCfgInfo.cFieldValue == FAILURE_BOOT) || (mgrCfgInfo.cFieldValue == FAILURE_BOOT))
    {
        rec.isRollBack = BSP_PWR_OFF_DEF_ENID;
    }
    else
    {
        rec.isRollBack = BSP_PWR_OFF_DEF_DISID;
    }

    RruLinkPwrOffRecCfg(PWROFF_REC_INIT_MODE_MOD,rec);
    }

#endif
    return BSP_OK;
}

static UINT32 RruLinkRruCfgActChk()
{
    T_Bsp_RruIniCfgItem fpgCfgInfo = {0};
    T_Bsp_RruIniCfgItem cpuCfgInfo = {0};
    T_Bsp_RruIniCfgItem mgrCfgInfo = {0};
#ifndef _4C_VDE_TEST_
    if (BSP_OK != RruLinkPwrOffRecGetRruCfg(strCfgFileName, &cpuCfgInfo, &fpgCfgInfo, &mgrCfgInfo))
    {
        return BSP_ERROR;
    }

    if ((cpuCfgInfo.cFieldValue == UPGRADE_BOOT) || (fpgCfgInfo.cFieldValue == UPGRADE_BOOT) || (mgrCfgInfo.cFieldValue == UPGRADE_BOOT))//2
    {
        return BSP_OK;
    }
#endif
    return BSP_ERROR;
}

static UINT32 RruLinkRruCfgActUpdate()
{
    UINT32 retVal = 0;
    UINT32 tmpRet = 0;
    UINT32 fret = 0;
    T_Bsp_RruIniCfgItem fpgCfgInfo = {0};
    T_Bsp_RruIniCfgItem cpuCfgInfo = {0};
    T_Bsp_RruIniCfgItem mgrCfgInfo = {0};
#ifndef _4C_VDE_TEST_
    if (BSP_OK != RruLinkPwrOffRecGetRruCfg(strCfgFileName, &cpuCfgInfo, &fpgCfgInfo, &mgrCfgInfo))
    {
        return BSP_ERROR;
    }

    /* 备份RRUCFG.INI */
    if (BspCopyFile(strCfgFileName, STR_RRUCFG_INI_BAK))
    {
        return BSP_ERROR;
    }

    if (cpuCfgInfo.cFieldValue == UPGRADE_BOOT)
    {
        tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, cpuCfgInfo.acFieldName, ACTIVE_BOOT);
        retVal |= tmpRet;
        BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI cpu to active,return %d\n",__FUNCTION__,tmpRet);
    }
    if (fpgCfgInfo.cFieldValue == UPGRADE_BOOT)
    {
        tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, fpgCfgInfo.acFieldName, ACTIVE_BOOT);
        retVal |= tmpRet;
        BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI fpga to active,return %d\n",__FUNCTION__,tmpRet);
    }
    if (mgrCfgInfo.cFieldValue == UPGRADE_BOOT)
    {
        tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, mgrCfgInfo.acFieldName, ACTIVE_BOOT);
        retVal |= tmpRet;
        BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI mgr to active,return %d\n",__FUNCTION__,tmpRet);
    }
    if (retVal != BSP_OK)
    {
        dbgErr("%s set RRUCFG.INI error!\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI error!\n",__FUNCTION__);
        /* 异常:恢复RRUCFG.INI */
        if (BspCopyFile(STR_RRUCFG_INI_BAK, strCfgFileName))
        {
            dbgErr("%s del RRUCFG.INI!\n",__FUNCTION__);
            BspLog(LOG_LEVEL_0,"%s del RRUCFG.INI!\n",__FUNCTION__);
            fret = BspDeleteFile(strCfgFileName);
            PWR_OFF_KW_COV(fret);
        }
    }
#endif
    fret = BspDeleteFile(STR_RRUCFG_INI_BAK);
    PWR_OFF_KW_COV(fret);
    BspLog(LOG_LEVEL_0,"%s return %d\n",__FUNCTION__,retVal);

    return retVal;
}

/* BSP单板预初始化调用 */
UINT32 BspRruLinkPwrOffRruCfgChk(VOID)
{
    UINT32 fret = 0;
    T_Bsp_RruIniCfgItem fpgCfgInfo = {0};
    T_Bsp_RruIniCfgItem cpuCfgInfo = {0};
    T_Bsp_RruIniCfgItem mgrCfgInfo = {0};
    T_Bsp_RruIniCfgItem fpgCfgInfoBak = {0};
    T_Bsp_RruIniCfgItem cpuCfgInfoBak = {0};
    T_Bsp_RruIniCfgItem mgrCfgInfoBak = {0};

    RRU_LINK_PWR_OFF_ENABLE_CHK();

    if (BSP_OK != RruLinkPwrOffRecGetRruCfg(STR_RRUCFG_INI_BAK, &cpuCfgInfoBak, &fpgCfgInfoBak, &mgrCfgInfoBak))
    {
        return 1;
    }
#ifndef _4C_VDE_TEST_
    if (BSP_OK != RruLinkPwrOffRecGetRruCfg(strCfgFileName, &cpuCfgInfo, &fpgCfgInfo, &mgrCfgInfo))
    {
        return 2;
    }

    /* RRUCFG.INI修改异常:
       1.存在STR_RRUCFG_INI_BAK文件;
       2.STR_RRUCFG_INI_BAK的FPGA标志是2;
       3.RRUCFG.INI的FPGA标志是2;
     */
    if ((0 == mgrCfgInfo.cFieldValue) || (0 == mgrCfgInfoBak.cFieldValue))  //非组件化机型无mgrflag
    {
        if (cpuCfgInfoBak.cFieldValue == UPGRADE_BOOT &&
            fpgCfgInfoBak.cFieldValue == UPGRADE_BOOT &&
            cpuCfgInfo.cFieldValue == UPGRADE_BOOT &&
            fpgCfgInfo.cFieldValue == UPGRADE_BOOT)
        {
            BspSetRuCfgIniFieldValue(strCfgFileName, fpgCfgInfo.acFieldName, ACTIVE_BOOT);
            BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI fpga to active\n",__FUNCTION__);
        }
    }
    else
    {
        if (cpuCfgInfoBak.cFieldValue == UPGRADE_BOOT &&
            fpgCfgInfoBak.cFieldValue == UPGRADE_BOOT &&
            mgrCfgInfoBak.cFieldValue == UPGRADE_BOOT &&
            cpuCfgInfo.cFieldValue == UPGRADE_BOOT &&
            fpgCfgInfo.cFieldValue == UPGRADE_BOOT &&
            mgrCfgInfo.cFieldValue == UPGRADE_BOOT)
        {
            BspSetRuCfgIniFieldValue(strCfgFileName, fpgCfgInfo.acFieldName, ACTIVE_BOOT);
            BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI fpga to active\n",__FUNCTION__);
            BspSetRuCfgIniFieldValue(strCfgFileName, mgrCfgInfo.acFieldName, ACTIVE_BOOT);
            BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI mgr to active\n",__FUNCTION__);
        }
    }
#endif
    fret = BspDeleteFile(STR_RRUCFG_INI_BAK);
    PWR_OFF_KW_COV(fret);
    return BSP_OK;
}


UINT32 BspRruLinkPwrOffRecCfg(VOID)
{
    T_PwrOffRec rec = {0};
    RRU_LINK_PWR_OFF_VALID_CHK();
    BspLog(LOG_LEVEL_0,"%s rec modify\n",__FUNCTION__);
    rrulinkpwroffLog("%s rec modify\n",__FUNCTION__);
    rec.restTimes  = BSP_PWR_OFF_MAX_CNT;
    rec.isEnable   = BSP_PWR_OFF_DEF_ENID;
    rec.isRollBack = 0;
    rec.reserve    = 0;
    return RruLinkPwrOffRecCfg(PWROFF_REC_INIT_MODE_MOD, rec);
}

UINT32 BspRruLinkPwrOffChk(UINT32 *pIsPwrOff,UINT8 *pDesc,UINT32 descLen)
{
    int fret = 0;
    T_PwrOffRec rec = {0};
    UINT32 restTimes = 0;
    INPUT_POINTER_CHECK(pIsPwrOff);
    INPUT_POINTER_CHECK(pDesc);

    RRU_LINK_PWR_OFF_VALID_CHK();

    if (BSP_OK != RruLinkPwrOffRecGet(&rec))
    {
        return BSP_ERROR;
    }
    dbgInfoEx("%s restTimes=%d isEnable=%#x\n",__FUNCTION__,rec.restTimes,rec.isEnable);
    BspLog(LOG_LEVEL_0,"%s restTimes=%d isEnable=%#x\n",__FUNCTION__,rec.restTimes,rec.isEnable);
    rrulinkpwroffLog("%s restTimes=%d isEnable=%#x\n",__FUNCTION__,rec.restTimes,rec.isEnable);
    /* 2.check version active state */
    *pIsPwrOff = 0;
    s_PwrOffType = BSP_PWR_OFF_TYPE_NO_EN;
    if (BSP_OK == RruLinkRruCfgActChk())//cpu、fpga状态为2
    {
        if (PWR_OFF_ENABLE_ID_GET(rec))//使能的话，是需要掉电复位，状态改为激活。不使能的话，不需要掉电复位
        {
            *pIsPwrOff = 1;
            s_PwrOffType = BSP_PWR_OFF_TYPE_VER_ACT;
        }
    }
    /* 3.检查断链运行时间是否超过门限 */
    else
    {
        /* 1.check rest times [1,6] */
        PWR_OFF_REST_TIME_CHK(rec); /* 20201223:升级场景不检查 */
        restTimes = rec.restTimes;
        if (BSP_OK == BspRruLinkBreakTimeChk(restTimes))
        {
            *pIsPwrOff = 1;
            s_PwrOffType = BSP_PWR_OFF_TYPE_NOR_RUN;
        }
    }

    dbgInfoEx("%s PwrOff:%d,count:%d,type:%d,rstcnt:%d\n",__FUNCTION__,(*pIsPwrOff),restTimes,s_PwrOffType,BspGetPowerOnCount());
    fret = snprintf_s((char *)pDesc,(rsize_t)descLen,"Pwr Off,count:%d,type:%d,rstcnt:%d\0",restTimes,s_PwrOffType,BspGetPowerOnCount());
    PWR_OFF_KW_COV(fret);
    BspLog(LOG_LEVEL_0,"%s s_PwrOffType=%d\n",__FUNCTION__,s_PwrOffType);
    rrulinkpwroffLog("%s PwrOff:%d,count:%d,type:%d,rstcnt:%d\n",__FUNCTION__,(*pIsPwrOff),restTimes,s_PwrOffType,BspGetPowerOnCount());
    return BSP_OK;
}

UINT32 BspRruLinkPwrOffChkByVerAct(UINT32 *pIsPwrOff)//建链后，版本升级激活
{
    T_PwrOffRec rec = {0};
    INPUT_POINTER_CHECK(pIsPwrOff);
    RRU_LINK_PWR_OFF_VALID_CHK();

    if (BSP_OK != RruLinkPwrOffRecGet(&rec))
    {
        return BSP_ERROR;
    }
    //PWR_OFF_REST_TIME_CHK(rec);
    //BspLog(LOG_LEVEL_0,"%s restTimes=%d isRollBack=%#x\n",__FUNCTION__,rec.restTimes,rec.isRollBack);

    if (PWR_OFF_ROLL_BACK_GET(rec))//RollBack=0x5a，是需要断电复位，状态改为回滚
    {
        *pIsPwrOff = 1;
        s_PwrOffType = BSP_PWR_OFF_TYPE_ROLL_BACK;
    }
    else
    {
        *pIsPwrOff = 0;
        s_PwrOffType = BSP_PWR_OFF_TYPE_NO_EN;
    }
    dbgInfoEx("%s PwrOff:%d,RollBack:0x%x,type:%d\n",__FUNCTION__,(*pIsPwrOff),rec.isRollBack,s_PwrOffType);
    rrulinkpwroffLog("%s PwrOff:%d,RollBack:0x%x,type:%d\n",__FUNCTION__,(*pIsPwrOff),rec.isRollBack,s_PwrOffType);
    return BSP_OK;
}

/* 单板下掉电复位前调用 */
UINT32 BspRruLinkPwrOffPreProc(VOID)
{
    UINT32 pwrOffType = 0;
    T_PwrOffRec rec = {0};
    RRU_LINK_PWR_OFF_VALID_CHK();

    pwrOffType   = s_PwrOffType;
    dbgInfo("%s pwrOffType=%d\n",__FUNCTION__,pwrOffType);
    BspLog(LOG_LEVEL_0,"%s pwrOffType=%d\n",__FUNCTION__,pwrOffType);

    s_PwrOffType = BSP_PWR_OFF_TYPE_NO_EN;
    PWR_OFF_TYPE_CHK(pwrOffType);

    /* 1.update pwroffrec.ini */
    //若为回滚状态，在复位前将isRollBack置为0x2d
    //若为激活状态，在复位前将isenable设置为0x2d
    if (BSP_OK != RruLinkPwrOffRecUpdate(pwrOffType, NULL, &rec))
    {
        dbgInfo("%s update failed\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s update failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* 2.check pwroffrec.ini update status */
    if (BSP_OK != RruLinkPwrOffRecChk(&rec))
    {
        dbgInfo("%s check error\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s check error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* 3.clear break time */
    BspRruLinkBreakTimeClrPure();
    /* 4.if version active,then try update RRUCFG.INI */
    if (pwrOffType == BSP_PWR_OFF_TYPE_VER_ACT)//是激活状态，将cpu/fpga状态2改为1
    {
        RruLinkRruCfgActUpdate();
    }

    dbgInfo("%s return ok\n",__FUNCTION__);
    BspLog(LOG_LEVEL_0,"%s return ok\n",__FUNCTION__);
    return BSP_OK;
}

static UINT32 BspSetRruLinkPwrPrn(UINT32 mode)
{
    UINT32 retVal = BSP_OK;
    if (mode)
    {
        retVal = ExPrnPad(getpid());
        exprnadd("BspRruLinkPwrOffChk");
        exprnadd("BspRruLinkBreakTimeChk");
    }
    else
    {
        exprnquit();
    }
    return retVal;
}
/* BSP单板初始完成之前调用初始化，确保是RRUCFG.INI已经完成更新 */
UINT32 BspRruLinkPwrOffInit(VOID)
{
    T_PwrOffRec rec = {0};
    T_PwrOffRec startRec = {0};
    T_PwrOffRec endRec = {0};

    RRU_LINK_PWR_OFF_ENABLE_CHK();

    if (BSP_OK != BspIsFileExist(BSP_PWR_OFF_REC_FILE))
    {
        rec.restTimes  = BSP_PWR_OFF_MAX_CNT;
        rec.isEnable   = BSP_PWR_OFF_DEF_ENID;
        rec.isRollBack = 0;
        rec.reserve    = 0;
        RruLinkPwrOffRecCfg(PWROFF_REC_INIT_MODE_CRT, rec);
        BspLog(LOG_LEVEL_0,"%s rec create %s\n",__FUNCTION__,BSP_PWR_OFF_REC_FILE);
    }

    if (BSP_OK != RruLinkPwrOffRecGet(&startRec))
    {
        return 1;
    }
    RruLinkPwrOffRecRollBackInit();
    if (BSP_OK != RruLinkPwrOffRecGet(&endRec))
    {
        return 2;
    }

    if ((startRec.restTimes != endRec.restTimes) ||
        (startRec.isEnable != endRec.isEnable))
    {
        return 3;
    }

    s_rruLinkPwrOffInit = 0x5A5A;
    //初始化"/ata/.bspcfg/bsppwrofflog.txt"
    SemLinkPwrOffLogInit();
    RruLinkPwrOffLogInit();
    BspSetRruLinkPwrPrn(1);
    return BSP_OK;
}

VOID BspRruLinkPwrOffEnable(UINT32 isEnable)
{
    s_rruLinkPwrOffEnable = isEnable;
}

UINT32 prnpwroffrec(VOID)
{
    T_PwrOffRec rec = {0};
    if (BSP_OK != RruLinkPwrOffRecGet(&rec))
    {
        return BSP_ERROR;
    }
    dbgInfo("restTimes:%d,isEnable=%#x,isRollBack=%#x\n",rec.restTimes,rec.isEnable,rec.isRollBack);
    return BSP_OK;
}

/* BSP单板预初始化时调用，确保是RRUCFG.INI未更新 */
UINT32 BspRruLinkPwrOffPreInitDefault()
{
    BspRruLinkPwrOffEnable(0x5A5A);
    return BspRruLinkPwrOffRruCfgChk();
}

/* BSP单板初始完成之前调用初始化，确保是RRUCFG.INI已经完成更新 */
UINT32 BspRruLinkPwrOffInitDefault()
{
    UINT32 retVal = 0;
    unsigned long virAddr = 0;     /*D42兼容32/64将virAddr改为unsigned long类型*/
    UINT32 ramSize = 0;

    retVal = BspRruLinkPwrOffInit();
    if (retVal != BSP_OK)
    {
        dbgErr("%s pwr off init error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspRruLinkBreakTimeMemSpace(&virAddr,&ramSize);
    if (retVal != BSP_OK)
    {
        dbgErr("%s pwr off init ok,break time init error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspRruLinkBreakTimeInit(virAddr,ramSize);
    dbgErr("%s pwr init ok,break time init %d\n",__FUNCTION__,retVal);
    return retVal;
}

UINT32 BspRruLinkPwrOffRecRestTimesInit(UINT32 isForceRst)
{
    /* isForceRst:
       0.需要检查次数是否为0，不为0不重新初始化40次，为0重新初始化40次;
       1.不需要检查次数是否为0，直接重新初始化40次;
     */
    T_PwrOffRec rec = {0};
    if (BSP_OK != RruLinkPwrOffRecGet(&rec))
    {
        return BSP_ERROR;
    }
    dbgInfo("%s ForceRst:%d,rec.restTimes=%d,\n",__FUNCTION__,isForceRst,rec.restTimes);

    if((isForceRst==1)||(rec.restTimes == 0))
    {
        rrulinkpwroffLog("%s pwr off rec.restTimes=%d\n",__FUNCTION__,rec.restTimes);
        rec.restTimes = 40;
        if (BSP_OK != RruLinkPwrOffRecCfg(PWROFF_REC_INIT_MODE_MOD, rec))
        {
            dbgErr("%s cfg rec.restTimes=%d failed\n",__FUNCTION__,rec.restTimes);
            rrulinkpwroffLog("%s cfg rec.restTimes=%d failed\n",__FUNCTION__,rec.restTimes);
            return BSP_ERROR;
        }
    }
    return BSP_OK;
}
UINT32 BspRruLinkBreakTimeClr(VOID)//给oss等调用
{
    UINT32 retVal = 0;

    retVal  = BspRruLinkPwrOffRecRestTimesInit(0);
    retVal |= BspRruLinkBreakTimeClrPure();
    rrulinkpwroffLog("%s\n",__FUNCTION__);
    return retVal;

}

UINT32 BspRruLinkPwrOffRecCfgTest(UINT8 restTimes,UINT8 isEnable,UINT8 isRollBack,UINT8 reserve)
{
    T_PwrOffRec rec = {0};
    rec.restTimes = restTimes;
    rec.isEnable  = isEnable;
    rec.isRollBack = isRollBack;
    rec.reserve = reserve;
    if (BSP_OK != RruLinkPwrOffRecCfg(PWROFF_REC_INIT_MODE_MOD, rec))
    {
        dbgErr("%s get rec failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspRruLinkRruCfgActTest(UCHAR CpuValue, UCHAR FpagValue, UCHAR MgrValue)
{
    UINT32 retVal = 0;
    UINT32 tmpRet = 0;
    UINT32 fret = 0;
    T_Bsp_RruIniCfgItem fpgCfgInfo = {0};
    T_Bsp_RruIniCfgItem cpuCfgInfo = {0};
    T_Bsp_RruIniCfgItem mgrCfgInfo = {0};

    if (BSP_OK != RruLinkPwrOffRecGetRruCfg(strCfgFileName, &cpuCfgInfo, &fpgCfgInfo, &mgrCfgInfo))
    {
        return BSP_ERROR;
    }

    /* 备份RRUCFG.INI */
    if (BspCopyFile(strCfgFileName, STR_RRUCFG_INI_BAK))
    {
        return BSP_ERROR;
    }

    switch (CpuValue)
    {
        case 0:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, cpuCfgInfo.acFieldName, NORMAL_BOOT);
             retVal |= tmpRet;
             break;
        case 1:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, cpuCfgInfo.acFieldName, ACTIVE_BOOT);
             retVal |= tmpRet;
             break;
        case 2:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, cpuCfgInfo.acFieldName, UPGRADE_BOOT);
             retVal |= tmpRet;
             break;
        case 3:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, cpuCfgInfo.acFieldName, FAILURE_BOOT);
             retVal |= tmpRet;
             break;
        default:
             break;
    }
    switch (FpagValue)
    {
        case 0:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, fpgCfgInfo.acFieldName, NORMAL_BOOT);
             retVal |= tmpRet;
             break;
        case 1:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, fpgCfgInfo.acFieldName, ACTIVE_BOOT);
             retVal |= tmpRet;
             break;
        case 2:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, fpgCfgInfo.acFieldName, UPGRADE_BOOT);
             retVal |= tmpRet;
             break;
        case 3:
             tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, fpgCfgInfo.acFieldName, FAILURE_BOOT);
             retVal |= tmpRet;
             break;
        default:
             break;
    }
    if (0 != mgrCfgInfo.cFieldValue)  //组件化机型才有mgrflag
    {
        switch (MgrValue)
        {
            case 0:
                tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, mgrCfgInfo.acFieldName, NORMAL_BOOT);
                retVal |= tmpRet;
                break;
            case 1:
                tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, mgrCfgInfo.acFieldName, ACTIVE_BOOT);
                retVal |= tmpRet;
                break;
            case 2:
                tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, mgrCfgInfo.acFieldName, UPGRADE_BOOT);
                retVal |= tmpRet;
                break;
            case 3:
                tmpRet = BspSetRuCfgIniFieldValue(strCfgFileName, mgrCfgInfo.acFieldName, FAILURE_BOOT);
                retVal |= tmpRet;
                break;
            default:
                break;
        }
    }
    if (retVal != BSP_OK)
    {
        dbgErr("%s set RRUCFG.INI error!\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s set RRUCFG.INI error!\n",__FUNCTION__);
        /* 异常:恢复RRUCFG.INI */
        if (BspCopyFile(STR_RRUCFG_INI_BAK, strCfgFileName))
        {
            dbgErr("%s del RRUCFG.INI!\n",__FUNCTION__);
            BspLog(LOG_LEVEL_0,"%s del RRUCFG.INI!\n",__FUNCTION__);
            fret = BspDeleteFile(strCfgFileName);
            PWR_OFF_KW_COV(fret);
        }
    }

    fret = BspDeleteFile(STR_RRUCFG_INI_BAK);
    PWR_OFF_KW_COV(fret);
    BspLog(LOG_LEVEL_0,"%s return %d\n",__FUNCTION__,retVal);

    return retVal;
}

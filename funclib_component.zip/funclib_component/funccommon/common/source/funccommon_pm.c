/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : funccommon_pm.c
* 文件标识 : {[N/A]}
* 内容摘要 : PM打印控制
* 注意事项 : 无
* 作    者 :   190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include <stdarg.h>

#include "bsppub.h"
#include "bspcomm.h"
#include "funccommon_pm.h"
#include "secure_func.h"

/**************************************************************************
 *                        宏
 **************************************************************************/
#define PM_ON                       1
#define PM_OFF                      0

#define MAX_PM_LEVEL_MASK           (PM_FATAL|PM_ERROR|PM_WARN|PM_INFO|PM_DEBUG)
#define MAX_PM_NUM                  100




/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
/* 模块管理结构体 */
typedef struct tagT_PmCtrl
{
    UINT32  level;
    UINT32  state;
    char    name[32];
}T_PmCtrl;

/* 打印级别及名称 */
typedef struct tagT_PmLevelInfo
{
    UINT32  level;
    const char *pDesc;
}T_PmLevelInfo;

/* 模块状态定义 */
typedef enum
{
    PM_UNUSED = 0,
    PM_USED   = 0xAA
}EModuleState;


/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/

static T_PmLevelInfo pmLevelInfo[MAX_PM_LEVEL_NUM] =
{
    {PM_DEBUG,  "PM_DEBUG"},
    {PM_INFO,   "PM_INFO"},
    {PM_WARN,   "PM_WARN"},
    {PM_ERROR,  "PM_ERROR"},
    {PM_FATAL,  "PM_FATAL"}
};


static T_PmCtrl pmCtrlData[MAX_PM_NUM] = {0,};
static UINT32  pmPrnFlag = 1;
static UINT32 pmSelfId = -1;


/**************************************************************************
 *                         外部变量声明
 **************************************************************************/

/**************************************************************************
 *                         局部函数声明
 **************************************************************************/

/**************************************************************************
 *                         全局函数声明
 **************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/
/**************************************************************************
 * 函数名称: PmPrint(*)
 * 功能描述: PM打印
 * 输入参数: pmId          - 模块号
             level     - 模块打印级别信息
             format    - 格式
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/

VOID PmPrint(UINT32 pmId, UINT32 level, const char *format, ...)
{
    va_list    ap = {0};
    char       temp[512];
    UINT32     cnt;
    int snpRet;

    if ((pmPrnFlag == 0)||(pmId >= MAX_PM_NUM))
    {
        return ;
    }

    if ((pmCtrlData[pmId].level & level) == 0)
    {
        return ;
    }

    va_start(ap, format);

    for (cnt = 0; cnt < MAX_PM_LEVEL_NUM; cnt++)
    {
        if (0 != ((0x01 << cnt) & level))
        {
            if (level&PM_PREFIX)
            {
                snpRet = snprintf_s(temp, sizeof(temp), "[%s|%s]%s", 
                    pmCtrlData[pmId].name, pmLevelInfo[cnt].pDesc, format);
                SNPRINTF_S_CHECK(snpRet, sizeof(temp));
            }
            else
            {
                snpRet = snprintf_s(temp, sizeof(temp), "%s", format);
                SNPRINTF_S_CHECK(snpRet, sizeof(temp));
            }
            /* vprintf(temp, ap); */
            (void)zte_vprintf_s((const char *)temp, ap);
            break;
        }
    }

    va_end(ap);
}

/**************************************************************************
 * 函数名称: PmAdd(*)
 * 功能描述: PM模块添加
 * 输入参数: pmId          - 模块号
             levelMask - 模块打印级别信息
             pDesc     - 模块名称
 * 输出参数: 无
 * 返 回 值: BSP_OK - 成功
             其他     - 失败
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/
static UINT32 PmAdd(UINT32 pmId, UINT32 levelMask, char *pDesc)
{
    if (pmId >= NELEMENTS(pmCtrlData) || levelMask > MAX_PM_LEVEL_MASK || pDesc == NULL)
    {
        PmPrint(pmSelfId, PM_ERROR, "ERROR Input params.\n");
        return BSP_ERROR;
    }

    if (PM_UNUSED == pmCtrlData[pmId].state)
    {
        pmCtrlData[pmId].level = levelMask;
        pmCtrlData[pmId].state = PM_USED;
        memset((VOID*)pmCtrlData[pmId].name,0,sizeof(pmCtrlData[pmId].name));
        strncpy(pmCtrlData[pmId].name, pDesc, sizeof(pmCtrlData[pmId].name) - 1);
    }
    else
    {
        PmPrint(pmSelfId, PM_WARN, "Module Exists:%d\n", pmId);
        return BSP_ERROR;
    }

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: PmAutoAdd(*)
 * 功能描述: 增加模块，不提供模块号，由打印模块返回模块号，方便
             各个模块和驱动使用
 * 输入参数: levelMask - 模块打印级别信息
             pDesc     - 模块名称
 * 输出参数: 无
 * 返 回 值: BSP_OK - 成功
             其他     - 失败
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/

UINT32 PmAutoAdd(UINT32 levelMask, const char *pmName)
{
    UINT32 cnt = 0;

    if (levelMask > MAX_PM_LEVEL_MASK || pmName == NULL)
    {
        PmPrint(pmSelfId, PM_ERROR, "ERROR Input params.\n");
        return BSP_ERROR;
    }

    for (cnt = 0; cnt < NELEMENTS(pmCtrlData); cnt++)
    {
        if (0 == strcmp(pmCtrlData[cnt].name, pmName))
        {
            //PmPrint(pmSelfId, PM_DEBUG, "Module %s has been used\n", pmName);
            return cnt;
        }
    }

    for (cnt = 0; cnt < NELEMENTS(pmCtrlData); cnt++)
    {
        if (pmCtrlData[cnt].state == PM_UNUSED)
        {
            pmCtrlData[cnt].level = levelMask;
            pmCtrlData[cnt].state = PM_USED;
            memset((VOID*)pmCtrlData[cnt].name,0,sizeof(pmCtrlData[cnt].name));
            strncpy(pmCtrlData[cnt].name, pmName, sizeof(pmCtrlData[cnt].name) - 1);
            return cnt;
        }
    }

    PmPrint(pmSelfId, PM_ERROR, "No free module space\n");
    return BSP_ERROR;
}


/**************************************************************************
 * 函数名称: PmDel(*)
 * 功能描述: 删除打印模块及打印级别控制信息
 * 输入参数: pmId          - 模块号
 * 输出参数: 无
 * 返 回 值: BSP_OK - 成功
             其他     - 失败
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/
UINT32 PmDel(UINT32 pmId)
{
    if (pmId >= MAX_PM_NUM)
    {
        PmPrint(pmSelfId, PM_ERROR, "ERROR Input params.\n");
        return BSP_ERROR;
    }

    if (pmCtrlData[pmId].state == PM_USED)
    {
        memset((VOID *)&pmCtrlData[pmId], 0, sizeof(T_PmCtrl));
        PmPrint(pmSelfId, PM_INFO, "Module %d is deleted.\n", pmId);
    }
    else
    {
        PmPrint(pmSelfId, PM_WARN, "Module %d does not exist.\n", pmId);
        return BSP_ERROR;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: PmShow(*)
 * 功能描述: 打印所有模块的打印控制信息
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/

#ifdef BUILD_WITH_OM_FUNC
VOID PmShow(VOID)
{
    UINT32 cnt = 0;
    UINT32 lvIdx;
    UINT32 lvMask;
    PmPrint(pmSelfId, PM_INFO, "Output PM Info:\n");
    PmPrint(pmSelfId, PM_INFO, "PM switch:%s\n", (pmPrnFlag == PM_OFF) ? "OFF" : "ON");
    PmPrint(pmSelfId, PM_INFO, "ModuleID |  DEBUG  INFO  WARN ERROR FATAL  | ModuleName\n");

    for (cnt = 0; cnt < NELEMENTS(pmCtrlData); cnt++)
    {
        if (pmCtrlData[cnt].state == PM_USED)
        {
            PmPrint(pmSelfId, PM_INFO, "   %2d    | ", cnt);

            for (lvIdx = 0; lvIdx < MAX_PM_LEVEL_NUM; lvIdx++)
            {
                lvMask = (pmCtrlData[cnt].level >> lvIdx) & 0x01;
                PmPrint(pmSelfId, PM_INFO, "   %1d  ", lvMask);
            }
            PmPrint(pmSelfId, PM_INFO, "  |  %s \n", pmCtrlData[cnt].name);
        }
    }
}
#endif

/**************************************************************************
 * 函数名称: PmCtrl(*)
 * 功能描述: 修改模块打印级别
 * 输入参数: pmId          - 模块号
             levelMask - 模块打印级别信息
 * 输出参数: 无
 * 返 回 值: BSP_OK - 成功
             其他     - 失败
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/
UINT32 PmCtrl(UINT32 pmId, UINT32 levelMask)
{
    UINT32 cnt = 0;

    if (levelMask > MAX_PM_LEVEL_MASK)
    {
        return BSP_ERROR;
    }

    if (pmId == 0xFF)
    {
        for (cnt = 0; cnt < NELEMENTS(pmCtrlData); cnt++)
        {
            if (pmCtrlData[cnt].state == PM_USED)
            {
                pmCtrlData[cnt].level = levelMask;
            }
        }
    }
    else if (pmId < NELEMENTS(pmCtrlData))
    {
        if (pmCtrlData[pmId].state == PM_USED)
        {
            pmCtrlData[pmId].level = levelMask;
            PmPrint(pmSelfId, PM_INFO, "Module %d, Level modified to %d \n", pmId, levelMask);
        }
        else
        {
            PmPrint(pmSelfId, PM_WARN, "Module %d is unused.\n", pmId);
        }
    }
    else
    {
        PmPrint(pmSelfId, PM_ERROR, "Wrong ModuleId or LEVEL.\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: PmAllCtrl(*)
 * 功能描述: 全局打印开关
 * 输入参数: isOn          - 全局打印控制, 0--关闭,非0--打开
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/
VOID PmAllCtrl(UINT32 isOn)
{
    pmPrnFlag = isOn;
}

/**************************************************************************
 * 函数名称: PmMaskCtrl(*)
 * 功能描述: 修改模块全局打印级别
 * 输入参数: levelMask     - 打印级别掩码
             isOn          - 全局打印控制, 0--关闭,非0--打开
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/
UINT32 PmMaskCtrl(UINT32 levelMask, UINT32 isOn)
{
    UINT32 cnt;

    if (levelMask > MAX_PM_LEVEL_MASK)
    {
        return BSP_ERROR;
    }

    for (cnt = 0; cnt < NELEMENTS(pmCtrlData); cnt++)
    {
        if (pmCtrlData[cnt].state == PM_USED)
        {
            if (isOn == PM_OFF)
            {
                pmCtrlData[cnt].level &= ~levelMask;
            }
            else
            {
                pmCtrlData[cnt].level |= levelMask;
            }
        }
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: PmInit(*)
 * 功能描述: 打印模块初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 无
 * 其它说明:
 * 修改日期         修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年4月1日 10090699          创建
 **************************************************************************/
UINT32 PmInit(VOID)
{
    memset((VOID *)pmCtrlData, 0, sizeof(pmCtrlData));
    pmSelfId = PmAutoAdd(DEFAULT_PM_LEVEL, "PM");
    return BSP_OK;
}



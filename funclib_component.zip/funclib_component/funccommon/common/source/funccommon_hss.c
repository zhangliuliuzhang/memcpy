
#include <stdarg.h>
#include "bsppub.h"
#include "bspcomm.h"

#include "funccommon.h"



/* history snap shot record */
#define HISTORY_SNAP_SHOT_REC_LEN         (128)     /* length of record */
#define HISTORY_SNAP_SHOT_REC_SIZE        (256*1024)/* mem size 256K */
#define HISTORY_SNAP_SHOT_HEAD_SIZE       (1024)    /* head size 1K */
#define HISTORY_SNAP_SHOT_REC_MAX         ((HISTORY_SNAP_SHOT_REC_SIZE-HISTORY_SNAP_SHOT_HEAD_SIZE)/HISTORY_SNAP_SHOT_REC_LEN)
#define HSITORY_SNAP_SHOT_ENABLE_ID       (0x1A2B3C4D)
#define HISTORY_SNAP_SHOT_FILE_SIZE       (512*1024)
#define HISTORY_SNAP_SHOT_SEM             "HisSnapShot"

#define HISTORY_SNAP_SHOT_CHK()   \
{                                 \
    if (snapBufInit != 1)         \
    {                             \
        return BSP_ERROR;         \
    }                             \
    if (pSnapShotHead == NULL || pSnapShotRecStart == NULL)    \
    {                             \
        return BSP_ERROR;         \
    }                             \
    if (pSnapShotHead->enableId != HSITORY_SNAP_SHOT_ENABLE_ID) \
    {                             \
        return BSP_ERROR;         \
    }                             \
}

typedef struct tagT_HistorySnapShotHead
{
    UINT32  enableId; /* enable id */
    UINT32  maxRecNum;
    UINT32  recOffset;
    UINT32  recIdx;
    UINT32  recNum;
}T_HistorySnapShotHead;

static T_HistorySnapShotHead *pSnapShotHead = NULL;
static char *pSnapShotRecStart = NULL;
static char *pSnapShotRecEnd = NULL;
static UINT32 snapBufInit = 0;


static UINT32 openHistorySnapShotFile(const char *pFile,FILE **fp)
{
    CHAR cmdTemp[128] = {0};
    UINT32 fileLen = 0;
    INT32 fopsRet = 0;
    INT32 lSnpRet = 0;

    fopsRet = fopen_s(fp,pFile,"a+");
    FOPEN_S_CHECK(fopsRet);
    if (*fp == NULL)
    {
        return BSP_ERROR;
    }

    fileLen = BspGetFileLen((char *)pFile);
    if (fileLen == ERROR_NULL_POINTER || fileLen == BSP_ERROR)
    {
        lSnpRet = fclose(*fp);
        FCLOSE_CHECK(lSnpRet);
        return BSP_ERROR;
    }

    if (fileLen < HISTORY_SNAP_SHOT_FILE_SIZE)
    {
        return BSP_OK;
    }

    lSnpRet = fclose(*fp);
    FCLOSE_CHECK(lSnpRet);

    *fp = NULL;
    lSnpRet = snprintf_s(cmdTemp,sizeof(cmdTemp)-1,"mv %s %s.bak",pFile,pFile);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(cmdTemp) - 1);

    BspSystem(cmdTemp);
    fopsRet = fopen_s(fp,pFile,"a+");
    FOPEN_S_CHECK(fopsRet);
    return BSP_OK;
}

static UINT32 closeHistorySnapShotFile(FILE **fp)
{
    INT32 lSnpRet = 0;

    lSnpRet = fclose(*fp);
    FCLOSE_CHECK(lSnpRet);
    *fp = NULL;
    return BSP_OK;
}

static UINT32 createHistorySnapShotFile(OSS_ULONG virAddr,const char *pFile)
{
    UINT32 loop;
    char *pBuf = NULL;
    FILE *fp = NULL;
    UINT32 recIdx = 0;
    UINT32 maxRecNum = 0;
    INT32  lFpfRet = 0;
    T_HistorySnapShotHead *pHead = NULL;

    // /ata/bsplinklog.txt
    openHistorySnapShotFile(pFile,&fp);
    if (fp == NULL)
    {
        dbgErr("%s>>HistorySnapShotFile Open1 Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pBuf = (char*)virAddr;
    pHead = (T_HistorySnapShotHead *)pBuf;

    if (HISTORY_SNAP_SHOT_REC_SIZE < pHead->recOffset)
    {
        dbgInfo("%s>>HeadRecOffset Over; Offset(0~%d)= %d\n", __FUNCTION__,
                HISTORY_SNAP_SHOT_REC_SIZE, pHead->recOffset);

        lFpfRet = fprintf_s(fp,"[%s]%p:EnableId:0x%x,MaxRecNum:%d,RecOffset:0x%x,RecIdx:%d,RecNum:%d\n",
                            pFile, virAddr, pHead->enableId, pHead->maxRecNum, pHead->recOffset,
                            pHead->recIdx, pHead->recNum);
        FPRINTF_CHECK(lFpfRet);

        lFpfRet = fprintf_s(fp,"RecOffset'0x%x error,over size 0x%x!!!\n",pHead->recOffset,HISTORY_SNAP_SHOT_REC_SIZE);
        FPRINTF_CHECK(lFpfRet);

        closeHistorySnapShotFile(&fp);
        return BSP_OK;
    }

    maxRecNum = (HISTORY_SNAP_SHOT_REC_SIZE - pHead->recOffset) / HISTORY_SNAP_SHOT_REC_LEN;
    maxRecNum = min(maxRecNum, HISTORY_SNAP_SHOT_REC_MAX);
    recIdx = pHead->recIdx;
    if ((pHead->recNum > maxRecNum) || (recIdx > maxRecNum))
    {
        recIdx = maxRecNum;
    }

    pBuf = pBuf + pHead->recOffset;
    dbgInfo("%s>>RecIdx'%d RecSum'%d: Addr(Vir'0x%08lX RecOff'0x%08X)= %p\n",
            __FUNCTION__, recIdx, maxRecNum, virAddr, pHead->recOffset, pBuf);
    lFpfRet = fprintf_s(fp, "[%s]VirAddr(0x%08lX 0x%08lX),EnId:0x%x,MaxRecNum:(%d %d),RecOffset:0x%x,RecIdx:(%d %d),RecNum:%d\n",
                        pFile, virAddr, (uintptr_t)&pBuf[0], pHead->enableId, pHead->maxRecNum, maxRecNum, pHead->recOffset,
                        pHead->recIdx, recIdx, pHead->recNum);
    FPRINTF_CHECK(lFpfRet);

    for (loop = 0;
         loop < recIdx;
         loop++, pBuf+=HISTORY_SNAP_SHOT_REC_LEN)
    {
        pBuf[HISTORY_SNAP_SHOT_REC_LEN - 1] = '\0';

        lFpfRet = fprintf_s(fp, "%s\n", pBuf);
        FPRINTF_CHECK(lFpfRet);
        if (ftell(fp) > HISTORY_SNAP_SHOT_FILE_SIZE)
        {
            closeHistorySnapShotFile(&fp);
            fp = NULL;
            openHistorySnapShotFile(pFile,&fp);
            if (fp == NULL)
            {
                dbgErr("%s>>HistorySnapShotFile Open2 Error!\n", __FUNCTION__);
                return BSP_ERROR;
            }
        }
    }

    lFpfRet = fclose(fp);
    FCLOSE_CHECK(lFpfRet);
    return BSP_OK;
}

UINT32 BspHistorySnapShotInit(OSS_ULONG virAddr,UINT32 size,const char *pFile)
{
    char *pBuf = NULL;

    /* need for at least 256K */
    if (virAddr == 0 || size < HISTORY_SNAP_SHOT_REC_SIZE)
    {
        dbgErr("%s>>Error! Param Over; VirAddr= 0x%08lX, Size= %d\n",
               __FUNCTION__, virAddr, size);
        return BSP_ERROR;
    }

    pBuf = (char*)virAddr;
    pSnapShotHead = (T_HistorySnapShotHead *)pBuf;

    if (pSnapShotHead->enableId == HSITORY_SNAP_SHOT_ENABLE_ID &&
        pSnapShotHead->recNum > 0)
    {
        /* write to file */
        createHistorySnapShotFile(virAddr,pFile);
    }
    pSnapShotHead->enableId   = HSITORY_SNAP_SHOT_ENABLE_ID;
    pSnapShotHead->maxRecNum  = HISTORY_SNAP_SHOT_REC_MAX;
    pSnapShotHead->recOffset  = HISTORY_SNAP_SHOT_HEAD_SIZE;
    pSnapShotHead->recIdx     = 0;
    pSnapShotHead->recNum     = 0;
    pSnapShotRecStart = pBuf + pSnapShotHead->recOffset;
    pSnapShotRecEnd   = pSnapShotRecStart + HISTORY_SNAP_SHOT_REC_MAX*HISTORY_SNAP_SHOT_REC_LEN;

    snapBufInit = 1;
    return BSP_OK;
}


static UINT32 writeHistorySnapShot(const char *pDesc,UINT32 descLen)
{
    INT32 lSnpRet = 0;
    char  *pBuf = NULL;
    char  strTemp[HISTORY_SNAP_SHOT_REC_LEN] = {0};

    HISTORY_SNAP_SHOT_CHK();

    strncpy_s(strTemp,HISTORY_SNAP_SHOT_REC_LEN-1,pDesc,descLen);
    if (pSnapShotHead->recIdx >= pSnapShotHead->maxRecNum)
    {
        pBuf = pSnapShotRecStart;
        lSnpRet = snprintf_s(pBuf,HISTORY_SNAP_SHOT_REC_LEN,"%s\0",strTemp);
        SNPRINTF_S_CHECK(lSnpRet, HISTORY_SNAP_SHOT_REC_LEN);
        pSnapShotHead->recNum++;
        pSnapShotHead->recIdx = 0;
    }
    else
    {
        pBuf = pSnapShotRecStart + pSnapShotHead->recIdx*HISTORY_SNAP_SHOT_REC_LEN;
        if (pBuf <= pSnapShotRecEnd)
        {
            lSnpRet = snprintf_s(pBuf,HISTORY_SNAP_SHOT_REC_LEN,"%s\0",strTemp);
            SNPRINTF_S_CHECK(lSnpRet, HISTORY_SNAP_SHOT_REC_LEN);
            pSnapShotHead->recNum++;
            pSnapShotHead->recIdx++;
        }
    }

    return BSP_OK;
}

UINT32 BspHistorySnapShotAdd(const char *pInfo,UINT32 infoLen)
{
    UINT32 retVal = 0;
    const char *pDesc = NULL;
    UINT32 descLen = 0;
    const char *semOwner = HISTORY_SNAP_SHOT_SEM;
    const CHAR *semFunc = __FUNCTION__;
    retVal = BspSemMgrTake(semOwner,(UINT32)WAIT_FOREVER,semFunc);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }
    pDesc  = pInfo;
    descLen= infoLen;
    retVal = writeHistorySnapShot(pDesc,descLen);
    BspSemMgrGive(semOwner);
    return retVal;
}

// ¼ÇÂ¼ÎÄ¼þ /ata/bsplinklog.txt
UINT32 PrnSnapShotHead(VOID)
{
    T_HistorySnapShotHead *ptTmpHead = NULL;

    ptTmpHead = pSnapShotHead;
    if (NULL == ptTmpHead)
    {
        dbgErr("%s>>Error! pSnapShotHead NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("%s>> SnapShotHead: VirAddr= %lu\n", __FUNCTION__,
            (OSS_ULONG)&pSnapShotHead[0]);
    dbgInfo("%s>> EnableId(En:  0x%08X)= 0x%08X\n", __FUNCTION__,
            HSITORY_SNAP_SHOT_ENABLE_ID, ptTmpHead->enableId);
    dbgInfo("%s>>MaxRecNum(Max: 0x%08X)= (0x%08X) %d\n",
            __FUNCTION__, HISTORY_SNAP_SHOT_REC_MAX,
            ptTmpHead->maxRecNum, ptTmpHead->maxRecNum);
    dbgInfo("%s>>RecOffset(Size:0x%08X)= (0x%08X) %d\n",
            __FUNCTION__, HISTORY_SNAP_SHOT_HEAD_SIZE,
            ptTmpHead->recOffset, ptTmpHead->recOffset);
    dbgInfo("%s>>SnapBufInit(1:OK)= %d; RecIdx= %d; RecNum= %d\n", __FUNCTION__,
            snapBufInit, ptTmpHead->recIdx, ptTmpHead->recNum);
    if ((NULL != pSnapShotRecStart) && (NULL != pSnapShotRecEnd))
    {
        dbgInfo("%s>>SnapShotRec: Start= %p; End= %p\n", __FUNCTION__,
                (void*)pSnapShotRecStart, (void*)pSnapShotRecEnd);
    }

    return BSP_OK;
}



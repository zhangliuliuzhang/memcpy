
#include <signal.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "bspcommon.h"
#include "vxadp.h"

#include "secure_func.h"
#include "funccommon.h"
#include "ru_univdef.h"
#include "exprn.h"

#define BRK_TIME_REC_RAM_BASE        (290*1024) /* 34K+256K=290K 高端内存BSP存储地址 */
#define BRK_TIME_REC_RAM_SIZE        (16)       /* 大小 */
#define BRK_TIME_REC_BK_UPTIME       (60)    /* B&K启动时间60秒 */
#define BRK_TIME_REC_RAM_SIZE        (16)
#define BRK_TIME_REC_ENABLE_ID       (0xA5B4C3D2)
#define BRK_TIME_REC_HOUR_SEC        (3600)
#define BRK_TIME_REC_SEM             "BrkTimeRec"
#define BRK_TIME_REC_TEST            "/ata/.bspcfg/brktimetestexit"
#define BRK_TIME_REC_TASK_TEST       "/.blog/brktimetestexit"

#define BRK_TIME_KW_COV(a)           if ((a) != 0)  dbgInfoEx("%s,%d:ret=%d\n",__FUNCTION__,__LINE__,(a)) 

#define BRK_TIME_INIT_CHK()                    \
{                                              \
    if (s_brkTimeRecInit != 0x5A5A)            \
    {                                          \
        return BSP_ERROR;                      \
    }                                          \
    if (BSP_OK == BspIsFileExist(BRK_TIME_REC_TEST)) \
    {                                          \
        return BSP_ERROR;                      \
    }                                          \
}

#define BRK_TIME_TASK_EXIT_CHK()               \
    if (BreakTimeRecTaskExitGet() == 0x2D2D)   \
    {                                          \
        return BSP_ERROR;                      \
    }

typedef struct tagT_BrkTimeRec
{
    UINT32  enableId; /* enable id */
    UINT32  brkTime;  /* 断链运行时间,单位:秒 */
    UINT32  lastBrkTime; /* 上次断链运行时间,单位:秒 */
    UINT8   res[3];   /* 预留 */
    UINT8   chkSum;   /* 校验和:覆盖前面15个字节 */
}T_BrkTimeRec;

static UINT32 s_brkTimeTaskExitFlag = 0;
static UINT32 s_brkTimeRecInit = 0;
static CHAR  *s_pBrkTimeRec = NULL;  /* 高端内存地址 */
static T_BrkTimeRec s_brkTimeRec = {0};   /* 内存存储 */

static UINT32 s_brkTimeOutVal[][4] =
{
    /* {[0]剩余掉电次数, [1]默认超时时间，[2]测试标志:0x5A5A表示有效, [3]测试超时时间} */
    {0, 24*BRK_TIME_REC_HOUR_SEC,     0, 24*BRK_TIME_REC_HOUR_SEC},
    {1, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {2, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {3, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {4, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {5, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {6, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {7, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {8, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {9, 6*BRK_TIME_REC_HOUR_SEC,      0, 6*BRK_TIME_REC_HOUR_SEC},
    {10, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {11, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {12, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {13, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {14, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {15, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {16, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {17, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {18, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {19, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {20, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {21, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {22, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {23, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {24, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {25, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {26, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {27, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {28, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {29, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {30, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {31, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {32, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {33, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {34, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {35, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {36, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {37, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {38, 6*BRK_TIME_REC_HOUR_SEC,     0, 6*BRK_TIME_REC_HOUR_SEC},
    {39, 2*BRK_TIME_REC_HOUR_SEC,     0, 2*BRK_TIME_REC_HOUR_SEC},
    {40, 1*BRK_TIME_REC_HOUR_SEC,     0, 1*BRK_TIME_REC_HOUR_SEC}
};

static UINT32 BreakTimeRecTaskExitGet();
static UINT32 BreakTimeRecGetTimeout(UINT32 restTimes);


UINT32 prnbrktime(VOID)
{
    UINT32 loop;
    UINT32 num;
    UINT32 timeout;

    if ((s_brkTimeRecInit != 0x5A5A) || (BreakTimeRecTaskExitGet() == 1))
    {
        dbgInfo("current break time: %d(s),taskState:STOP\n",s_brkTimeRec.brkTime);
    }
    else
    {
        dbgInfo("current break time: %d(s),taskState:RUNNING\n",s_brkTimeRec.brkTime);
    }
    
    dbgInfo("restTimes defTimeout testFlag testTimeout timeout\n");
    num = sizeof(s_brkTimeOutVal)/sizeof(s_brkTimeOutVal[0]);
    for (loop = 0; loop < num; loop++)
    {
        timeout = BreakTimeRecGetTimeout(s_brkTimeOutVal[loop][0]);
        dbgInfo("%-9d %-10d 0x%-6x %-11d %-7d\n",
            s_brkTimeOutVal[loop][0],
            s_brkTimeOutVal[loop][1],
            s_brkTimeOutVal[loop][2],
            s_brkTimeOutVal[loop][3],
            timeout);
    }
    return BSP_OK;
}

UINT32 setbrktime(UINT32 restTimes,UINT32 timeout)
{
    UINT32 loop;
    UINT32 num;
    num = sizeof(s_brkTimeOutVal)/sizeof(s_brkTimeOutVal[0]);
    for (loop = 0; loop < num; loop++)
    {
        if (restTimes == s_brkTimeOutVal[loop][0])
        {
            s_brkTimeOutVal[loop][2] = 0x5A5A;
            s_brkTimeOutVal[loop][3] = timeout;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

UINT32 getbrktimetest(UINT32 restTimes)
{
    UINT32 retVal = 0;
    FILE   *fp = NULL;
    int    rdLen = 0;
    int    fret = 0;
    char   *buf = NULL;
    char   key[64] = {0};
    char   *keybuf = NULL;
    fret = fopen_s(&fp,"/ata/.bspcfg/brktimeouttest","r");
    BRK_TIME_KW_COV(fret);
    if (fp == NULL)
    {
        return BSP_ERROR;
    }
    fret = fclose(fp);
    BRK_TIME_KW_COV(fret);
    fp = NULL;

    fret = fopen_s(&fp,"/ata/.bspcfg/brktimeouttest.txt","r");
    BRK_TIME_KW_COV(fret);
    if (fp == NULL)
    {
        return BSP_ERROR;
    }

    buf = malloc(512);
    if (buf == NULL)
    {
        fret = fclose(fp);
        BRK_TIME_KW_COV(fret);
        return BSP_ERROR;
    }
    memset(buf,0,512);

    rdLen = fread(buf,1,500,fp);
    if (rdLen < 10)
    {
        free(buf);
        fret = fclose(fp);
        BRK_TIME_KW_COV(fret);
        return BSP_ERROR;
    }
    buf[510] = '\0';
    buf[511] = '\0';
    fret = fclose(fp);
    BRK_TIME_KW_COV(fret);

    fret = snprintf_s(key,sizeof(key),"restTimes=%d,timeout=\0",restTimes);
    BRK_TIME_KW_COV(fret);
    keybuf = strstr(buf,key);
    if (keybuf == NULL)
    {
        free(buf);
        return BSP_ERROR;
    }

    keybuf = keybuf + strnlen_s(key,64);
    if (keybuf >= (buf + rdLen))
    {
        free(buf);
        return BSP_ERROR;
    }

    retVal = strtoul(keybuf,0,0);
    BRK_TIME_KW_COV(retVal);
    setbrktime(restTimes,retVal);

    free(buf);
    return retVal;
}

static UINT32 BreakTimeRecGetTimeout(UINT32 restTimes)
{
    UINT32 loop;
    UINT32 num;
    getbrktimetest(restTimes);

    num = sizeof(s_brkTimeOutVal)/sizeof(s_brkTimeOutVal[0]);
    for (loop = 0; loop < num; loop++)
    {
        if (restTimes == s_brkTimeOutVal[loop][0])
        {
            if (0x5A5A == s_brkTimeOutVal[loop][2])
            {
                return s_brkTimeOutVal[loop][3];
            }
            else
            {
                return s_brkTimeOutVal[loop][1];
            }
        }
    }
    return BSP_ERROR;
}

static UINT8 BreakTimeRecSum(const T_BrkTimeRec *rec)
{
    UINT8  *pBuf = NULL;
    UINT32 num = 0;
    UINT8  sum = 0;
    UINT32 loop;
    pBuf = (UINT8 *)rec;
    num  = sizeof(T_BrkTimeRec) - 1;
    for (loop = 0; loop < num; loop++, pBuf++)
    {
        sum += *pBuf;
    }
    return sum;
}

static UINT32 BreakTimeRecGet(T_BrkTimeRec *rec)
{
    UINT32 retVal = 0;
    uint32_t tmpData = 0;
    const char *semOwner = BRK_TIME_REC_SEM;
    const CHAR *semFunc = __FUNCTION__;
    if (s_pBrkTimeRec == NULL)
    {
        return BSP_ERROR;
    }
    retVal = BspSemMgrTake(semOwner,(UINT32)WAIT_FOREVER,semFunc);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }
    memcpy_s((void *)rec,sizeof(T_BrkTimeRec),(void *)s_pBrkTimeRec,sizeof(T_BrkTimeRec));
    tmpData = rec->enableId;
    rec->enableId    = ntohl(tmpData);
    tmpData = rec->brkTime;
    rec->brkTime     = ntohl(tmpData);
    tmpData = rec->lastBrkTime;
    rec->lastBrkTime = ntohl(tmpData);
    BspSemMgrGive(semOwner);
    return retVal;
}

static UINT32 BreakTimeRecSet(const T_BrkTimeRec *rec)
{
    UINT32 retVal = 0;
    uint32_t tmpData = 0;
    T_BrkTimeRec tmpRec = {0};
    const char *semOwner = BRK_TIME_REC_SEM;
    const CHAR *semFunc = __FUNCTION__;
    if (s_pBrkTimeRec == NULL)
    {
        return BSP_ERROR;
    }
    retVal = BspSemMgrTake(semOwner,(UINT32)WAIT_FOREVER,semFunc);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }
    memcpy_s((void *)&tmpRec,sizeof(T_BrkTimeRec),(const void *)rec,sizeof(T_BrkTimeRec));
    tmpData = rec->enableId;
    tmpRec.enableId    = htonl(tmpData);
    tmpData = rec->brkTime;
    tmpRec.brkTime     = htonl(tmpData);
    tmpData = rec->lastBrkTime;
    tmpRec.lastBrkTime = htonl(tmpData);
    tmpRec.chkSum      = BreakTimeRecSum(&tmpRec);
    memcpy_s((void *)s_pBrkTimeRec,sizeof(T_BrkTimeRec),(void *)&tmpRec,sizeof(T_BrkTimeRec));
    BspSemMgrGive(semOwner);
    return retVal;
}

static UINT32 BreakTimeRecChk(const T_BrkTimeRec *rec)
{
    if (rec->enableId != BRK_TIME_REC_ENABLE_ID)
    {
        return BSP_ERROR;
    }
    if (rec->chkSum != BreakTimeRecSum(rec))
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

static UINT32 BreakTimeRecClr()
{
    T_BrkTimeRec  rec = {0};
    memset_s((void*)&s_brkTimeRec, sizeof(T_BrkTimeRec), 0, sizeof(T_BrkTimeRec));
    return BreakTimeRecSet(&rec);
}

static UINT32 BreakTimeRecInit(UINT32 sec,T_BrkTimeRec *rec)
{
    T_BrkTimeRec tmpRec = {0};
    if (BSP_OK != BreakTimeRecGet(&tmpRec))
    {
        return BSP_ERROR;
    }
    if (BSP_OK != BreakTimeRecChk(&tmpRec))
    {
        memset((void *)&tmpRec, 0, sizeof(T_BrkTimeRec));
        tmpRec.enableId    = BRK_TIME_REC_ENABLE_ID;
        tmpRec.lastBrkTime = BRK_TIME_REC_BK_UPTIME;
        tmpRec.brkTime     = tmpRec.lastBrkTime + sec;
        dbgInfo("%s break time check invalid,reinit\n",__FUNCTION__);
    }
    else
    {
        tmpRec.lastBrkTime = tmpRec.brkTime + BRK_TIME_REC_BK_UPTIME;
        tmpRec.brkTime     = tmpRec.lastBrkTime + sec;
    }
    if (BSP_OK != BreakTimeRecSet(&tmpRec))
    {
        return BSP_ERROR;
    }
    memcpy_s((void *)rec,sizeof(T_BrkTimeRec),(void *)&tmpRec,sizeof(T_BrkTimeRec));
    return BSP_OK;
}

static UINT32 BreakTimeRecUpdate(UINT32 sec,T_BrkTimeRec *rec)
{
    T_BrkTimeRec tmpRec = {0};
    BRK_TIME_TASK_EXIT_CHK();
    if (BSP_OK != BreakTimeRecGet(&tmpRec))
    {
        return BSP_ERROR;
    }
    if (BSP_OK != BreakTimeRecChk(&tmpRec))
    {
        return BSP_ERROR;
    }

    tmpRec.brkTime = tmpRec.lastBrkTime + sec;
    if (BSP_OK != BreakTimeRecSet(&tmpRec))
    {
        return BSP_ERROR;
    }
    memcpy_s((void *)rec,sizeof(T_BrkTimeRec),(void *)&tmpRec,sizeof(T_BrkTimeRec));
    return BSP_OK;
}

static VOID BreakTimeRecTaskExitSet()
{
    s_brkTimeTaskExitFlag = 0x2d2d;
}
static UINT32 BreakTimeRecTaskExitGet()
{
    int fret = 0;
    FILE *fp = NULL;
    CHAR temp[32] = {0};
    UINT32 rdLen = 0;
    if (s_brkTimeTaskExitFlag == 0x2d2d)
    {
        return 1;
    }

    fret = fopen_s(&fp,BRK_TIME_REC_TASK_TEST,"r");
    BRK_TIME_KW_COV(fret);
    if (fp == NULL)
    {
        return 0;
    }

    rdLen = fread(temp,1,16,fp);
    BRK_TIME_KW_COV(rdLen);
    fret = fclose(fp);
    BRK_TIME_KW_COV(fret);

    if (rdLen == 8)
    {
        return 1;
    }
    return 0;
}

static UINT32 BspBreakTimeTask(VOID)
{
    T_BrkTimeRec  rec = {0};
    UINT32 errCnt = 0;
    UINT32 count = 0;
    UINT32 sec = 0;
    
    s_brkTimeTaskExitFlag = 0;
    sec = tickGet() / 100;
    if (BSP_OK != BreakTimeRecInit(sec,&s_brkTimeRec))
    {
        dbgErr("%s break time rec init error\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"%s break time rec init error\n",__FUNCTION__);
        BreakTimeRecTaskExitSet();
    }
    BspLog(LOG_LEVEL_0,"%s lastBrkTime=%d brkTime=%d\n",__FUNCTION__,s_brkTimeRec.lastBrkTime,s_brkTimeRec.brkTime);

    while (!BreakTimeRecTaskExitGet())
    {
        taskDelay(1000); /* 周期10S */
        count++;
        sec = tickGet() / 100;

        /* 更新内存的值 */
        s_brkTimeRec.brkTime = s_brkTimeRec.lastBrkTime + sec; 
        s_brkTimeRec.chkSum  = BreakTimeRecSum(&s_brkTimeRec);
        /* 更新高端内存的值 */
        if (BSP_OK != BreakTimeRecUpdate(sec,&rec))
        {
            errCnt++;
        }
        else
        {
            errCnt = 0;
        }
        dbgInfoEx("%s count=%d(errCnt:%d) lastBrkTime=%d brkTime=%d\n",
            __FUNCTION__,count,errCnt,rec.lastBrkTime,rec.brkTime);
    }

    BreakTimeRecClr();
    dbgInfo("%s break time task exit\n",__FUNCTION__);
    BspLog(LOG_LEVEL_0,"%s break time task exit\n",__FUNCTION__);
    return BSP_OK;
}

static UINT32 BspBreakTimeTaskInit(void)
{
    INT32  iTmpRet = 0;
    UINT32 funcRet = 0;
    char taskName[] = "brktimetask";
    FUNCPTR pFuncTask = NULL;

    pFuncTask = (FUNCPTR)BspBreakTimeTask;
    iTmpRet = taskSpawn(taskName, 153, 0, 10240, pFuncTask, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (ERROR != iTmpRet)
    {
        funcRet = BSP_OK;
        dbgInfo("\n %s Create Succ! Ret= 0x %X\n", __FUNCTION__, iTmpRet);
    }
    else
    {
        funcRet = BSP_ERROR;
        dbgErr("\n %s Create Error! Ret= 0x %X\n", __FUNCTION__, iTmpRet);
    }

    return funcRet;
}

UINT32 BspRruLinkBreakTimeChk(UINT32 restTimes)
{
    UINT32 timeout = 0;
    UINT32 brkTime = 0;
    BRK_TIME_INIT_CHK();
    BRK_TIME_TASK_EXIT_CHK();
    timeout = BreakTimeRecGetTimeout(restTimes);
    if (timeout == BSP_ERROR)
    {
        dbgErr("%s get brktime error by restTime[%d]\n",__FUNCTION__,restTimes);
        return BSP_ERROR;
    }
    brkTime = s_brkTimeRec.brkTime;
    dbgInfoEx("%s brkTime=%d timeout=%d\n",__FUNCTION__,brkTime,timeout);
    BspLog(LOG_LEVEL_0,"%s brkTime=%d timeout=%d\n",__FUNCTION__,brkTime,timeout);

    if (brkTime < timeout)
    {
        return BSP_ERROR;
    }
    
    return BSP_OK;
}

UINT32 BspRruLinkBreakTimeClrPure(VOID)
{
    BRK_TIME_INIT_CHK();
    BreakTimeRecTaskExitSet();
    BreakTimeRecClr();
    return BSP_OK;
}

UINT32 BspRruLinkBreakTimeInit(unsigned long virAddr,UINT32 size)
{
    /* need for at least 16bytes */
    if (virAddr == 0 || size < BRK_TIME_REC_RAM_SIZE)
    {
        return BSP_ERROR;
    }

    s_pBrkTimeRec = (CHAR*)virAddr;
    s_brkTimeRecInit = 0x5A5A;

    BspBreakTimeTaskInit();
    return BSP_OK;
}

UINT32 BspRruLinkBreakTimeMemSpace(unsigned long *pVirAddr,UINT32 *pMemSize)
{
    unsigned long virAddr = 0;    /*D42兼容32/64将virAddr改为unsigned long类型*/
    UINT32 ramOffset = BRK_TIME_REC_RAM_BASE; /* 34K+256K */
    UINT32 ramSize = BRK_TIME_REC_RAM_SIZE;
    INPUT_POINTER_CHECK(pVirAddr);
    INPUT_POINTER_CHECK(pMemSize);
    
    virAddr = BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP);
    if (BSP_ERROR == virAddr)
    {
        dbgErr("%s get reserve mem addr error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    *pVirAddr = virAddr + ramOffset;
    *pMemSize = ramSize;
    return BSP_OK;
}

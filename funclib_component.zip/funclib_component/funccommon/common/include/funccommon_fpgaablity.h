/*********************************************************************
* 版权所有 (C)2017, 深圳市中兴通讯股份有限公司。
* 
* 文件名称： funccommon_fpgaablity.h
* 文件标识：
* 内容摘要： FPGA版本能力上报
* 其它说明：
* 当前版本： 1.0
* 作     者：   190699
* 完成日期： 2017-04-01
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容：

**********************************************************************/
#ifndef _FUNCLIB_FUNCCOMMON_FPGAABLITY_H_INCLUDE_
#define _FUNCLIB_FUNCCOMMON_FPGAABLITY_H_INCLUDE_


#ifdef __cplusplus
extern "C"{
#endif

#include "funccommon_carrmap.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define FPGA_DIF_14_BITS        1
#define FPGA_DIF_16_BITS        2

#define FPGA_NCO_STEP_15K       1
#define FPGA_NCO_STEP_20K       2

#define IF0 0
#define IF1 1

#define ANTI_INTF_MODE_SINGLE_BAND   0 //支持单段
#define ANTI_INTF_MODE_DOUBLE_BAND   1 //支持双段
#define ANTI_INTF_MODE_SINGLE_DOUBLE 2 //双段兼容单段
#define ANTI_INTF_MODE_NOT_SUPPORT   3 //不支持抗干扰功能

#define IS_SUPPORT_NR_BIG_BW	1
#define NOT_SUPPORT_NR_BIG_BW	0

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef struct tagT_FpgaAblityInfo
{
    UINT16  usFlag;
    UINT16  usVer;
    UINT16  usMaxCarrNum[2];                   /* 两个方向，TX、RX */
	UINT16  usBandCarrNum[2][2];               /* 两个方向*两个频段 */
	UINT16  usCarrInfo[DIF_RADIOMODE_MAX][3];  /* 每种制式两个信息:0：载波个数 ，1：载波nco起始位置,2:NR载波载波映射起始索引*/
	UINT16  usNrCarrBwInfo[4];                 /* NR载波支持的带宽信息,KHZ */
	UINT16  usLteDlyAblity[2];                 /* fpga时延补偿能力，单位us，为0表示不支持上报 */
	UINT16  usNbDlyAblity[2];                  /* fpga时延补偿能力，单位us，为0表示不支持上报 */
	UINT32  ulBitmapDtxSupport;                /* bitmapDtx 支持标志, 0-不支持, 1-支持 */
	UINT32  ulDtxSelfTestSupport;              /* dtx 自检支持标志,   0-不支持, 1-支持 */
	UINT32  uCfrRate;                          /* cfr速率，KHz */
	UINT16  usCfrType;                         /* cfr类型，单相还是双相 */
	UINT16  usCfrPos;                          /* cfr位置，NCO之前还是之后 */
	UINT32  DpdType;                           /* DPD类型，单相或多相*/
	UINT32  DifBitFlag;                        /* 中频处理带宽，14bit或16bit*/
	UINT32  DifNcoStep;                        /* NCO步进，20K或15K*/
	UINT32  ulLteDtxSupport;                        /* Lte dtx 自检支持标志,   0-不支持, 1-支持 */
	UINT32  ulNbDtxSupport;                         /* Nb dtx 自检支持标志,   0-不支持, 1-支持 */
	UINT32  ulNrDtxSupport;                         /* Nr dtx 自检支持标志,   0-不支持, 1-支持 */
}T_FpgaAblityInfo;

typedef UINT32 (*FUNC_GET_DTX_ABILITY)(UINT32 radioMode);
typedef UINT32 (*FUNC_IS_SUPPORT_NR_BIG_BW)(VOID);

enum
{
	FEATURE_COMMON_VERSION 	         = 0x00,
	FEATURE_COMMON_MAX_CARR_NUM      = 0x01,
	FEATURE_COMMON_TX_BAND0_CARR_NUM = 0x02,
	FEATURE_COMMON_TX_BAND1_CARR_NUM = 0x03,
	FEATURE_COMMON_DIF_BIT_FLAG      = 0x04,
	FEATURE_COMMON_RX_BAND0_CARR_NUM = 0x06,
	FEATURE_COMMON_RX_BAND1_CARR_NUM = 0x07,
	FEATURE_GSM_MAX_CARR_NUM         = 0x20,
	FEATURE_GSM_NCO_START_POS        = 0x23,
	FEATURE_UMTS_MAX_CARR_NUM        = 0x30,
	FEATURE_UMTS_NCO_START_POS       = 0x33,
	FEATURE_NR_MAX_CARR_NUM          = 0x40,
	FEATURE_NR_LTE_MAX_CARR_NUM      = 0x41,
	FEATURE_NR_NCO_START_POS         = 0x43,
	FEATURE_BITMAP_DTX_SUPPORT_FLAG  = 0x44,
	FEATURE_NR_CARR_BAND             = 0x4A,
	FEATURE_LTE_MAX_CARR_NUM         = 0x50,
	FEATURE_NR_CARR_MAP_START_NO     = 0x51,
	FEATURE_LTE_DELAY                = 0x52,
	FEATURE_LTE_NCO_START_POS        = 0x53,
	FEATURE_NB_MAX_CARR_NUM          = 0x60,
	FEATURE_NB_GSM_MAX_CARR_NUM      = 0x61,
	FEATURE_NB_DELAY                 = 0x62,
	FEATURE_NB_NCO_START_POS         = 0x63,
	FEATURE_CFR_MAX_CARR             = 0x80,
	FEATURE_CFR_FS_RATE              = 0x81,
	FEATURE_CFR_BAND                 = 0x82,
	FEATURE_CFR_DIV                  = 0x83,
	FEATURE_CFR_POS                  = 0x84,
	FEATURE_DPD_DIV                  = 0x90,   /*DPD单相多相标志*/
	FEATURE_NR_IF0_MAX_CARR_NUM      = 0xA0,
	FEATURE_NR_IF0_NCO_START_POS     = 0xA3,
	FEATURE_NR_IF1_MAX_CARR_NUM      = 0xA4,
	FEATURE_NR_IF1_NCO_START_POS     = 0xA7,
	FEATURE_ANTI_INTF_MODE_IF0		 = 0xa1, /*IF0 支持700M频段抗干扰模式*/
	FEATURE_ANTI_INTF_MODE_IF1		 = 0xa5, /*IF1 支持700M频段抗干扰模式*/
};

/**************************************************************************
 *                         函数接口
 **************************************************************************/
UINT32 BspGetFpgaAblity(UINT32 uChipId);
UINT32 BspGetFpgaSupportCarrInfo(UINT32 radioMode, UINT32 *CarrNum, UINT32 *NcoPos);
UINT32 BspGetDifBitFlag(VOID);
UINT32 BspGetDifNcoStep(VOID);
UINT32 BspGetDpdType(VOID);
UINT32 BspCfrRamDefCallBackInit(pGetCfrRamAblity pCallBackFunc);
UINT32 BspGetFpgaSupportCarrBand(UINT32 *pNrCarrBwInfo, UINT32 BwInfoLens);
UINT32 BspGetFpgaSupportUmtsCarrInfo(VOID);
VOID BspGetDtxChkAbilityCallBackInit(FUNC_GET_DTX_ABILITY pfGetDtxChkAbility);

void BspSetFreqBandType(UINT32 ulFlag);
UINT32 BspGetFreqBandType(VOID);
void BspSetGNCarrEnFlag(UINT32 ulFlag);
UINT32 BspGetGNCarrEnFlag(VOID);
UINT32 BspGetGsmDivRssi(VOID);
void BspSetGsmDivRssi(UINT32 ulFlag);


UINT32 BspIsFpgaSupportNrBigBwCallBackInit(FUNC_IS_SUPPORT_NR_BIG_BW ptFunc);

#ifdef __cplusplus
}
#endif

#endif  /* _FUNCLIB_FUNCCOMMON_FPGAABLITY_H_INCLUDE_ */



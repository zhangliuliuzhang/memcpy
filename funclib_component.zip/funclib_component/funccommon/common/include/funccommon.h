/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : funccommon.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _FUNCLIB_FUNCCOMMON_H_
#define _FUNCLIB_FUNCCOMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bspcomm.h"
#include "funccommon_pm.h"
#include "funccommon_log.h"
#include "funccommon_hss.h"
#include "funccommonapi.h"
#include "funccommon_chncfg.h"
#include "bspcommon.h"

#define DIV_CHK_PRN_RET(denominator)                    \
if (0 == denominator)                                   \
{                                                       \
    dbgErr("[%s]denominator is invalid 0! _Line_ %d\n", \
           __FUNCTION__, __LINE__);                     \
    return ERROR;                                       \
}

#define ECPRI_UDP_PORT_DIR                 "/ata/udpport.ini"
#define ECPRI_UDP_PORT_CTRL_DEF            0xa5a6  /* NR20机型默认端口号 */
#define ECPRI_UDP_PORT_DATA_DEF            0xa5a5  /* NR20机型默认端口号 */
#define ECPRI_UDP_PORT_DEF                 3153    /* NR30机型默认端口号 */
#define ROE_UDP_PORT_DEF                   0xa5a6  /* NR30机型默认端口号 */

#define BSP_PIN_REG_RDWR_MODE              0xC35A
#define BSP_FPGA_NOT_LOAD                  0
#define STRLF                              "\n"

#define HASRELATION                        1
#define NOTHASRELATION                     0

#define MAX_SLAVE_PORT_NUM                 (3)
#define MAX_SLAVE_CHAN_NUM                 (2)


#define MAC_EXPAND(mac)  mac[0],mac[1],mac[2],mac[3],mac[4],mac[5]
#define IP_EXPAND(ip)    ip[0],ip[1],ip[2],ip[3]
#define macPrn(mac,str)  dbgInfo("%02x:%02x:%02x:%02x:%02x:%02x%s",MAC_EXPAND(mac),str)
#define ipPrn(ip,str)    dbgInfo("%d.%d.%d.%d%s",IP_EXPAND(ip),str)
#define PWR_SUPPORT_SELF_RESCUE    (1)
#define PWR_NO_SUPPORT_SELF_RESCUE (0)

typedef UINT32 (*FUNC_RESET_DEV)(OSS_ULONG devId, UINT32 resetType, UINT32 cause);
typedef void (*SIG_HNDL)(int signo, siginfo_t *info, void *context);
typedef UINT32 (*FUNC_SWITCH_FPGA)(void);

typedef UINT32 (*SET_SLAVEPORT_SWITCH)(UINT32 ulSwitch);
typedef UINT32 (*SET_RRUANGLE_CFG)(UINT32 ulPortTpye, UINT32 ulPortId, UINT32 ulAntAngle);
typedef UINT32 (*SET_SLAVEPORT_CBSW_DSP_CFG)(VOID);
typedef UINT32 (*GETSET_SLAVEPORT_STATUS)(UINT32 ulPortId, UINT32 ulCtrl, UINT32 ulType);
typedef UINT32 (*GET_SLAVEPORT_DEVNAME)(UCHAR *pRruName,UINT32 ulPortId);
typedef UINT32 (*SET_SLAVEPORT_CFG)(UINT32 ulPortId, UINT32 ulPortType,UINT32 ulPortSta);
typedef UINT32 (*GET_ANTINFO_BY_PORTID)(UINT32 ulPortId, T_RU_LINK_MAP_SLAVE *pAntInfo);
typedef UINT32 (*RESET_SLAVE_PORT)(UINT32 ulPortId, UINT32 ulSw, UINT32 ulRstType);
typedef UINT32 (*FUNC_RESET_SFP)(UINT32 optId);
typedef UINT32 (*funcGetFanStatusCallBack)(UINT32 *pStatus);

typedef UINT32(*FUNC_GetRru204Status)(T_Rru204StatusRecord *rru204RecordInfo);
typedef UINT32 (*BSP_SUPPORT_VER_DECOUPLE_CALLBACK_FUNCPTR)(VOID);

typedef UINT32 (*funcGetPoeNumCallBack)(UINT32 *pPoeNum);

typedef struct tagT_RadioPara
{
    UINT32 (*pGetRadionMode)(VOID);
	UINT32 (*pSetRadionMode)(UINT32 stdRadio);
}T_RadioPara;

typedef UINT32 (*pSetNetCfg)(VOID);

enum
{
    E_BOARD_TYPE_IF0 = 1,
    E_BOARD_TYPE_IF3,
    E_BOARD_TYPE_MAX
};

enum
{
    E_SLAVE_RRUINFO,
    E_SLAVE_PWRINFO,
    E_SLAVE_DFLINFO,
    E_SLAVE_PAINFO,
};

typedef struct tagT_EcpriUdpPort
{
    UINT32  ecpriPort;  /* ecpri udp port,NR20:控制端口和数据端口可分开,NR30:控制端口和数据端口共用 */
    UINT32  roePort;    /* roe upd port */
}T_EcpriUdpPort;

typedef struct tagT_EcpriUdpPortInfo
{
    char           portDir[32];
    UINT32 (*pFuncEcpriPortCfg)(UINT32 ecpriPort);
    UINT32 (*pFuncRoePortCfg)(UINT32 roePort);
    UINT32 (*pFuncDefPortCfg)();
    UINT32          init;
}T_EcpriUdpPortInfo;

typedef struct tagT_PwrOffRec
{
    UINT8  restTimes; /* 掉电剩余次数 */
    UINT8  isEnable;  /* 升级激活态掉电使能标志,0x5A:使能，其他:不使能 */
    UINT8  isRollBack;/* 版本回滚,0x5A:回滚,其他:没有回滚 */
    UINT8  reserve;   /* 预留 */
}T_PwrOffRec;

//广电抗干扰两段式
typedef struct tagT_CarrInfoMultiRelation
{
	UINT32 MasterCarrNo;
	UINT32 RadioMode;
	UINT8  HasRelation;
	UINT32 OtherSlaveCarrNo;
	UINT8  Rsv[10];
}T_CarrInfoMultiRelation;
typedef struct tagT_CarrInfoMultiAssociate
{
	UINT32 carrNum;
	T_CarrInfoMultiRelation carrInfoRealation;
}T_CarrInfoMultiAssociate;

#pragma pack(1)
typedef struct tagT_SlavePortBaseInfo
{
    UINT32 moduleGroupId;
    UINT32 boardGroupId;
    UINT32 boardTypeId;
    UINT32 hwChangeId;
    UINT32 rfChanNum;  /* 支持的通道数 */
    UINT8  cpuType;    /* cpu类型 */
    UINT8  linkSta;
    UINT8  rruName[32];  /*子端的单板名*/
    UINT8  res[6];
}T_SlavePortBaseInfo;

typedef struct tagT_SlavePortGetAlm
{
    UINT8 ackData;
    UINT32 almState;
    UINT32 almEvent;
    UINT8 reserve[8];
}T_SlavePortGetAlm;

typedef struct tagT_SlavePortTempVolt
{
    INT32  boardTemp;
    INT32  paTemp[2];   /*2个子端通道*/
    INT32  pwrTemp;
    UINT32 pwrVolt;
    UINT32 pwrAlm;
}T_SlavePortTempVolt;

typedef struct tagT_SlavePortRfSwitchSta
{
    UINT8 ackData;
    UINT16 rfSwTestMode;
    UINT16 rfSwSta;
    UINT8 reserve[4];
}T_SlavePortRfSwitchSta;

typedef struct tagT_SlavePortRruInfo
{
    UINT8 ackData;
    UINT8 rruBarCode[20];
    UINT8 vendorUnitFamilyType[10];
    UINT8 vendorUnitTypeNumber[20];
    char  vendorUnitPid[8];
    UINT8 verdorUnitPidFlag;
    UINT8 rruPaNum;
    UINT8 rruDflNum;
    UINT8 rruPwrNum;
    UINT8 rruPibNum;
    UINT8 rruAntNum;
    UINT8 antNum;
    UINT32 rruRatedPowerTx;
    UINT8 bomCode[20];
    UINT8 supplerCode[20];
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_SlavePortRruInfo;

typedef struct tagT_SlavePortPwrInfo
{
    UINT8 ackData;
    UINT8 pwrBarCode[20];
    UINT8 pwrType[8];
    UINT32 defaultPwrVolt;
    UINT32 pwrVoltUp;
    UINT32 pwrVoltDown;
    UINT32 pwrFactoryId;
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_SlavePortPwrInfo;

typedef struct tagT_SlavePortDflInfo
{
    UINT8 ackData;
    UINT8 dflBarCode[48];
    UINT8 boardName[20];
    UINT8 dflAntNum;
    UINT8 dflRxFreq[20];
    UINT8 dflTxFreq[20];
    UINT32 dflFactoryId;
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_SlavePortDflInfo;

typedef struct tagT_SlavePortPaInfo
{
    UINT8 ackData;
    UINT8 paBarCode[20];
    UINT8 boardName[20];
    UINT8 paPath;
    UINT8 paTxFreq[20];
    UINT32 paFactoryId;
    UINT8 productTime[12];
    UINT32 serviceTime;
    UINT8 lastServiceDate[12];
    UINT8 vendorName[20];
}T_SlavePortPaInfo;

/* Started by AICoder, pid:579a7n9df2u2da914edd095e10312824819366e2 */
typedef struct tagT_DefRruTempOffsetPara
{
    INT32 powerTempOffset;  /* 电源告警温度提高偏移量 */
    INT32 boardTempOffset;  /* 单板告警温度提高偏移量 */
    INT32 paTempOffset;     /* 功放告警温度提高偏移量 */
}T_DefRruTempOffsetPara;

typedef struct tagT_RruMatchCfg
{
    CHAR *pcTypeNumber;
    CHAR *pcPid;
}T_RruMatchCfg;

typedef struct tagT_TempThresholdOffsetPara
{
    INT32 pwrThresholdOffset;    /* 电源过温门限偏移量 */
    INT32 boardThresholdOffset;  /* 单板过温门限偏移量 */
    INT32 paThresholdOffset;     /* 功放过温门限偏移量 */
    INT32 deratingTotal;         /* 降额量 */
}T_TempThresholdOffsetPara;
/* Ended by AICoder, pid:579a7n9df2u2da914edd095e10312824819366e2 */

#pragma pack()

typedef UINT32 (*FUNC_CheckFpgaStatus)(UINT32 fpgaIndex);
typedef UINT32 (*FUNC_SET_NTF_RSSI_SWITCH)(UINT32 rssi_sw);
typedef UINT32 (*GET_SLAVE_PORT_TEMPANDVOLT)(UINT32 portId, T_SlavePortTempVolt *pData);


VOID BspSetNetCfgCallBackInit(pSetNetCfg pCfg);

UINT32 BspInitRadioPara(T_RadioPara *para);

UINT32 BspSetCpuId(UINT32 id);
UINT32 BspSetCoreId(UINT32 id);


VOID   BspResetDeviceCallBackInit(FUNC_RESET_DEV pReset);
UINT32 BspResetDevice(OSS_ULONG devId, UINT32 resetType, UINT32 cause);
VOID   BspSwitchFpgaCallBackInit(FUNC_SWITCH_FPGA pSwitch);

UINT32 BspSetCarrierNum(UINT32 carrNum);

UINT32 BspSemMgrInit();
UINT32 BspSemMgrTake(const char *owner,UINT32 maxWait,const CHAR *taker);
UINT32 BspSemMgrGive(const char *owner);
UINT32 BspSetPwrUpgradeFlag(UINT32 flag);
VOID BspSignalHandleRegister(SIG_HNDL pHndl);
typedef UINT32(*FUNC_DPDVSWR_TBL_STATE)(UINT32 ulSubIndex, UINT32 ulChan);

UINT32 BspInitPowerOnRecord(CHAR *fileName);
UINT32 BspGetPowerOnCount(VOID);
VOID BspRruLinkPwrOffEnable(UINT32 isEnable);
UINT32 BspRruLinkPwrOffInit(VOID);
UINT32 BspRruLinkPwrOffRruCfgChk(VOID);
UINT32 BspRruLinkPwrOffPreProc(VOID);
UINT32 BspRruLinkBreakTimeInit(unsigned long virAddr,UINT32 size);   /*D42兼容32/64将virAddr改为unsigned long类型*/
UINT32 BspRruLinkBreakTimeChk(UINT32 restTimes);
UINT32 BspRruLinkBreakTimeMemSpace(unsigned long *pVirAddr,UINT32 *pMemSize); /*D42兼容32/64将virAddr改为unsigned long类型*/
UINT32 BspRruLinkBreakTimeClrPure(VOID);
UINT32 BspRruLinkPwrOffPreInitDefault();
UINT32 BspRruLinkPwrOffInitDefault();
UINT32 setbrktime(UINT32 restTimes,UINT32 timeout);/* kw */
UINT32 prnbrktime(VOID);/* kw */
UINT32 prnpwroffrec(VOID);/* kw */

VOID   BspDpdVswrTblStateCallBackInit(FUNC_DPDVSWR_TBL_STATE pDpdVswrTblState);
UINT32 BspGetDpdVswrTblState(UINT32 ulSubIndex, UINT32 ulChan);
UINT32 BspSetCarrierNum(UINT32 carrNum);
UINT32 BspSetSlaveCarrierNum(UINT32 carrNum);
UINT32 BspSetRruWorkMode(UINT32 rruWorkMode);
UINT32 BspGetRruWorkMode(VOID);
UINT32 BspSetClkInitStatus(UINT32 ulStat);
UINT32 BspCheckSocInitStatus(UINT32 ulCmd);
UINT32 BspGetSwVerHead(const char *pVerFile, T_VerFileHeader *pVerHead);
typedef UINT32(*FUNC_PowOn_Strategy)(VOID);
typedef UINT32(*FUNC_Process_Sta)(UINT32 socMap,UINT32 socNum,UINT32 *delaTime,UINT32 *pOutSoc);
typedef UINT32(*FUNC_Process_Strategy)(UINT32 rupId);
VOID BspProcessStrategyRegister(FUNC_Process_Sta pFuncSta,FUNC_Process_Strategy pFunc);
VOID BspPowonStrategyRegister(FUNC_PowOn_Strategy pFunc);
VOID BspCheckFpgaStautsRegister(FUNC_CheckFpgaStatus pFunc,UINT32 *fpgaIndex,UINT32 fpgaNum);
UINT32 BspInitEcpriUdpPortInfo(T_EcpriUdpPortInfo *pInfo);
UINT32 BspGetEcpriUdpPort(UINT32 *ecpriPort,UINT32 *roePort);
UINT32 BspSetCarrMapMode(UINT32 ulMode);
void BspSetSwitchFpgaEnableFlag(UINT32 flag);
ULONG BspDeleteFile(const char *filename);
ULONG BspMkdir(const char *path);
VOID BspSetNtfRssiSwitchCallInit(FUNC_SET_NTF_RSSI_SWITCH pFunTmp);
UINT32 BspSetNtfRssiSwitch(UINT32 sw);
UINT32 BspGetRruLinkPwrOffRec(T_PwrOffRec *pRetRec);

UINT32 BspGetGpioPinRdWrMode(VOID);
UINT32 BspSetGpioPinRdWrMode(UINT32 ulRdWrMode);
UINT32 BspSetAtgMultiFrameFlag(UINT32 flag);
UINT32 BspSetFrameStruc(UINT32 value);
UINT32 BspSetOptIf1taDelay(UINT32 taDelay);
UINT32 BspGetOptIf1taDelay(VOID);
UINT32 BspSetOptIf1hwLinkDelay(UINT32 hwLinkDelay);
UINT32 BspGetOptIf1hwLinkDelay(void);
UINT32 BspGetRfChCfgFreqCarrInfo(UINT32 bspChan, UINT32 dir,UINT32 rfmode ,UINT32 carrno);
UINT32 BspCarrBwIsTwoSegAntiInterf(UINT32 carrMode, UINT32 carrBw);
UINT32 BspCarrBwIsOneSegAntiInterf(UINT32 carrMode, UINT32 carrBw);
VOID BspSetInnerSerdesStatus(UINT32 status);
VOID BspSetInnerSerdesSelfSaveCnt(UINT32 status);
typedef UINT32(*FUNC_FunSet_Ptr)(VOID);
UINT32 BspSetSlavePortSwitchCallBack(SET_SLAVEPORT_SWITCH pFuncCallback);
UINT32 BspSetRruAntAngleCfgCallBack(SET_RRUANGLE_CFG pFuncCallback);
UINT32 BspSetSlavePortCbSwAndDspCfgCallBack(SET_SLAVEPORT_CBSW_DSP_CFG pFuncCallback);
UINT32 BspSlavePortStatusCallBack(GETSET_SLAVEPORT_STATUS pFuncCallback);
UINT32 BspGetSlavePortDevNameCallBack(GET_SLAVEPORT_DEVNAME pFuncCallback);
UINT32 BspSetSlavePortCfgCallBack(SET_SLAVEPORT_CFG pFuncCallback);
UINT32 BspGetAntInfoBySlavePortIdCallBack(GET_ANTINFO_BY_PORTID pFuncCallback);
UINT32 BspGetBoardReset(VOID);
UINT32 BspResetSlavePortCallBack(RESET_SLAVE_PORT pFuncCallback);
UINT32 BspGetSlavePortTempVoltCallBack(GET_SLAVE_PORT_TEMPANDVOLT pFuncCallback);
UINT32 BspSetSlavePortBaseInfo(UINT32 rfsId, T_SlavePortBaseInfo *pPara);
UINT32 BspSaveSlavePortBaseInfo(UINT32 portId, UINT32 slaveChn,UINT32 type, VOID *pPara);
void BspSetAntiTamperBaseAddr(UINT32 addr);
UINT32 BspGetAntiTamperBaseAddr(VOID);
void BspSetAntiTamperOffsetAddr(UINT32 addr);
UINT32 BspGetAntiTamperOffsetAddr(VOID);
void BspSetClearAntiTamperFlagOffsetAddr(UINT32 addr);
UINT32 BspGetClearAntiTamperFlagOffsetAddr(void);
UINT32 InitAntiTamper(VOID);
UINT32 ClearAntiTamper(VOID);
UINT32 GetTmpInfoCrc(VOID);
UINT32 BspBoardGetSubPortSw(VOID);
UINT32 BspBoardSetSubPortSw(UINT32 sw);
UINT8 GetCrcWrFlag(VOID);
UINT16 GetInfoCrc(VOID);
// UINT32 BspGetMicellSpecTypeFlag(VOID);
// UINT32 BspGetDigitSfpSupportFlag(VOID);
UINT32 BspRegisterRru204StaCall(FUNC_GetRru204Status pRru204StaCall);
UINT32 BspSetSlavePaStatus(UINT32 chan, UINT32 sta);
UINT32 BspSetSlaveLnaStatus(UINT32 chan, UINT32 sta);
VOID BspSetDflOutRangFlag(UINT32 flag);
VOID BspSetSfpSelfHealFlag(UINT32 flag);
VOID BspBoardResetDisable(VOID);
UINT32 BspResetSfpCallBack(FUNC_RESET_SFP pGetResetSfp);
UINT32 BspGetFanStatusCallBack(funcGetFanStatusCallBack pFuncCallBack);
UINT32 BspGetFanStatus(UINT32 *pStatus);
UINT32 BspGetPwrSelfRescueFlag(void);
UINT32 BspSupportRebootDecoupleCallBack(BSP_SUPPORT_VER_DECOUPLE_CALLBACK_FUNCPTR pFuncCallback);
UINT32 BspGetUaeTempModeFlag(VOID);
UINT32 BspSetDigitAnalogSfpSum(UINT32 ulSfpSum);
UINT32 BspSetDigitAnalogOptSum(UINT32 ulOptSum);
UINT32 BspSetMicellSpecTypeFlag(UINT32 ulCfgFlag);
UINT32 BspSetDigitSfpSupportFlag(UINT32 ulCfgFlag);
UINT32 BspSetSfpDigitAnalogFlag(UINT32 ulOptIdx, UINT32 ulDigitFlag);
VOID BspSetTempOffset(T_DefRruTempOffsetPara *offset);
VOID BspGetTempOffset(T_DefRruTempOffsetPara *offset);
UINT32 BspSetTempThresholdOffset(T_TempThresholdOffsetPara *offset);
VOID BspGetTempThresholdOffset(T_TempThresholdOffsetPara *offset);
UINT32 BspGetPoeNum(UINT32 *pPoeNum);
UINT32 BspGetPoeNumCallBack(funcGetPoeNumCallBack pFuncCallBack);
UINT32 BspGetVswrPosCalcPara(UINT32 chan, UINT32 band, T_VswrPosCalcPara *para);
void BspSetDpdMultiVswrFlag(UINT32 flag);
UINT32 BspGetDpdMultiVswrFlag(void);
UINT32 BspInitRruFileInfoBomidCheck(VOID);
UINT32 BspExtractSocVerToTmp(VOID);
INT32 BspGetThresholdBoardTempDelta(VOID);
INT32 BspGetThresholdPaTempDelta(VOID);
INT32 BspGetThresholdPwrTempDelta(VOID);
UINT32 BspGetOverTempLevel(VOID);
#ifdef __cplusplus
}
#endif

#endif


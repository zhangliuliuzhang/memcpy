/*********************************************************************
* 版权所有 (C)2017, 深圳市中兴通讯股份有限公司。
* 
* 文件名称： funccommon_pm.h
* 文件标识： 
* 内容摘要： 打印模块 实现
* 其它说明： 
* 当前版本： 1.0
* 作     者：   190699
* 完成日期： 2017-04-01
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容： 

**********************************************************************/
#ifndef _FUNCLIB_FUNCCOMMON_PM_H_INCLUDE_
#define _FUNCLIB_FUNCCOMMON_PM_H_INCLUDE_


#ifdef __cplusplus
extern "C"{
#endif






/**************************************************************************
 *                          常量                                          *
 **************************************************************************/
#define MAX_PM_LEVEL_NUM                 0x05
#define PM_DEBUG                         0x01
#define PM_INFO                          0x02
#define PM_WARN                          0x04
#define PM_ERROR                         0x08
#define PM_FATAL                         0x10

#define PM_PREFIX                        0x8000

#define DEFAULT_PM_LEVEL         (PM_FATAL|PM_ERROR|PM_WARN|PM_INFO)






/**************************************************************************
 *                          宏定义                                        *
 **************************************************************************/





/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/
    











/**************************************************************************
 *                            函数原型                                    *
 **************************************************************************/
UINT32 PmInit(VOID);
UINT32 PmAutoAdd(UINT32 levelMask, const char *pmName);
VOID PmPrint(UINT32 pmId, UINT32 level, const char *format, ...);
UINT32 PmCtrl(UINT32 pmId, UINT32 levelMask);





#ifdef __cplusplus
}
#endif

#endif  /* _FUNCLIB_FUNCCOMMON_PM_H_INCLUDE_ */



/*funccommon_ic_gsm.h*/

/* cfr */
typedef UINT32 (*FUNC_BSP_SET_CFR_GATE_PARA)(UINT32 difChn);
typedef UINT32 (*FUNC_BSP_CFG_CFR_GATE)(UINT32 difChn);
typedef UINT32 (*FUNC_CFRDPDIC3CPGDATAMEMAPPLY)();
typedef UINT32 (*FUNC_CFRDPDIC3CPGCFG_HARDCAL)(UINT32 difChn);
typedef UINT32 (*FUNC_CFRDPDIC3CPGINIT_HARDCAL)(UINT32 difChn);
typedef UINT32 (*FUNC_SET_CFR_NON_GSM_POW)();
typedef UINT32 (*FUNC_CFR_CHECK_CARR_INFO)(UINT32 difChn,UINT32 band,UINT32 cfrCarrPos);
typedef UINT32 (*FUNC_CFR_GET_BW_CFG_BY_CFR_CARR_POS)(UINT32 difChn,UINT32 band,UINT32 carrCfrPos);

/* cfr diff info */
typedef UINT32 (*FUNC_GET_GSM_CARRBW)(UINT32 difchan, UINT32 dir, UINT32 carrNo, UINT32 carrRadioMode, UINT32 *carrBw);
typedef UINT32 (*FUNC_GET_GSM_CARR_FREQ)(UINT32 difchan, UINT32 dir, UINT32 carrNo, UINT32 carrRadioMode, UINT32 *carrFreq);
typedef UINT32 (*FUNC_GET_GSM_CARR_RADIO)(UINT32 difchan, UINT32 dir, UINT32 pkgIndex, UINT32 *carrRadio);
typedef UINT32 (*FUNC_GET_GSM_CFR_DIF_MAP_CARRNO)(UINT32 difchan, UINT32 dir, UINT32 origCarrNo, UINT32 carrRadioMode, UINT32 *mapCarrNo);
typedef UINT32 (*FUNC_GET_GSM_CFR_DIF_CARR_SUM)(UINT32 difchan, UINT32 dir);
typedef UINT32 (*FUNC_GET_GSM_DIF_CARRNO)(UINT32 radioMode, UINT32 difchan, UINT32 carrNo);

/*cfr debug interface*/
typedef UINT32 (*FUNC_BSP_SET_CFR_CPG_VALID_HALF_LEN)(UINT32 difChn, UINT32 value);
typedef UINT32 (*FUNC_BSP_GET_CFR_CPG_VALID_HALF_LEN)(UINT32 difChn, UINT32 *value);
typedef UINT32 (*FUNC_BSP_GET_CFR_GATE)(UINT32 difChn);
typedef UINT32 (*FUNC_BSP_SET_CFR_GATE)(UINT32 difChn, UINT32 gate0, UINT32 gate1, UINT32 gate2, UINT32 gate3);
typedef UINT32 (*FUNC_BSP_SET_CFR_8PSK_GATE)(UINT32 difChn, UINT32 gate0, UINT32 gate1, UINT32 gate2, UINT32 gate3);


typedef enum
{
    E_GSM_CFR_THR_1ST,
    E_GSM_CFR_THR_2ND,
    E_GSM_CFR_THR_3RD,
    E_GSM_CFR_THR_4TH,
    E_GSM_CFR_THR_NUM
}E_GSM_CFR_THRESHOLD;

typedef struct tag_gsm_cfr_threshold             /*削峰门限*/
{
    UINT32 gateThrStage[E_GSM_CFR_THR_NUM];      /*gate削峰门限*/
    UINT32 gateThrStage_8psk[E_GSM_CFR_THR_NUM]; /*8psk gate削峰门限*/
}T_GsmCfrThrInfo[8];/*暂时按照8通道来设计*/

/* powerctrl */
typedef UINT32 (*FUNC_BSP_TEMP_PARA_UPDATE)();
typedef UINT32 (*FUNC_BSP_RX_SHUT_SWITCH)(UINT32 uChn, UINT32 uSwitch);
typedef UINT32 (*FUNC_BSP_SET_DIVMODE_CFG)(T_RruDivModeCfgPara *ptCfgPara);
typedef UINT32 (*FUNC_BSP_SET_ANT_ALTER_CFG)(UINT32 antAlterFlag);
typedef UINT32 (*FUNC_BSP_SWITCH_PA_SLOT_SHUT)(UINT32 bspChn, UINT32 switchFlag);
typedef UINT32 (*FUNC_BSP_GET_DL60MS_TAG_STATE)(UINT32 bspChn);
typedef UINT32 (*FUNC_BSP_GET_DL_IQ_CHAN_STATE)(UINT32 bspChn);
typedef UINT32 (*FUNC_BSP_SET_FPGA_DPT_FLT_SW)(UINT32 bspChn, UINT32 ulSwitch);
typedef UINT32 (*FUNC_BSP_SET_POW_LEVEL)(UINT32 bspChn, UINT32 powLevel);
typedef UINT32 (*FUNC_BSP_SET_CARR_POW_GSM)(UINT32 bspChn, UINT32 carrIndex,UINT32 carrPow, UINT32 radioMode);
typedef UINT32 (*FUNC_BSP_SET_TSSI_POW_INFO)(UINT32 bspChn, UINT32 carrMode,UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs);
typedef UINT32 (*FUNC_BSP_SET_RSSI_POW_INFO)(UINT32 bspChn, UINT32 carrMode,UINT32 bspCarrNo, INT32 *pRssiDbm, INT32 *pRssiDbfs);
/*BSP从IC BBTSSI读取配置功率送给外扩逻辑*/
typedef UINT32 (*FUNC_SET_BBTSSI_NON_GSM_POW)();

/* freqcfg */
typedef UINT32 (*FUNC_BSP_SET_CARR_EN_FLAG)(UINT32 uChipId,UINT32 uDifChn, UINT32 carr,UINT32 uDir, UINT32 radioMode);
typedef UINT32 (*FUNC_BSP_SET_CENTER_FREQ_POINT_TO_FPGA)(UINT32 uChn, UINT32 uDir, UINT32 uFreq);
typedef UINT32 (*FUNC_BSP_SET_TX_RF_CFG_GSM)(UINT32 chan, T_RfCfgPara *pRfCfgPara);
typedef UINT32 (*FUNC_BSP_SET_RX_RF_CFG_GSM)(UINT32 chan, T_RfCfgPara *pRfCfgPara);


/* iqcfg */

/* tsg */
typedef UINT32 (*FUNC_TSG_SELECT_G)(UINT32 bspChan,UINT32 ulMode,UINT32 uCarr);


// typedef UINT32 (*Cfr_GateCfg)(UINT32 difChan/*T_CFR_SUBLINK_INFO* ptCfrSubLinkCfg*/);
typedef struct tag_gsm_cfr_module
{
    FUNC_BSP_SET_CFR_GATE_PARA          pBspSetCfrGatePara;/*初始化gate门限参数*/
    FUNC_BSP_CFG_CFR_GATE               pBspCfgCfrGate;/*配置削峰门限*/
    FUNC_CFRDPDIC3CPGDATAMEMAPPLY       pCfrDpdic3CpgDataMemApply;
    FUNC_CFRDPDIC3CPGCFG_HARDCAL        pCfrDpdic3CpgCfg_HardCal;
    FUNC_CFRDPDIC3CPGINIT_HARDCAL       pCfrDpdic3CpgInit_Hardcal;
    FUNC_SET_CFR_NON_GSM_POW            pCfrNonGsmPow;
    FUNC_CFR_CHECK_CARR_INFO            pCfrCheckCarrInfo;
    FUNC_CFR_GET_BW_CFG_BY_CFR_CARR_POS pCfrGetBwCfgByCfrCarrPos;
    FUNC_BSP_SET_CFR_CPG_VALID_HALF_LEN pBspSetCfrCpgValidHalfLenMax;
    FUNC_BSP_GET_CFR_CPG_VALID_HALF_LEN pBspGetCfrCpgValidHalfLenMax;
    FUNC_BSP_GET_CFR_GATE               pBspGetCfrGate;
    FUNC_BSP_SET_CFR_GATE               pBspSetCfrGate;
    FUNC_BSP_SET_CFR_8PSK_GATE          pBspSetCfr8pskGate;

    T_GsmCfrThrInfo                     gsmCfrThrInfo;
    /* cfr diff info */
    FUNC_GET_GSM_CARRBW                 pGetGsmCarrBw;
    FUNC_GET_GSM_CARR_FREQ              pGetGsmCarrFreq;
    FUNC_GET_GSM_CARR_RADIO             pGetGsmCarrRadio;
    FUNC_GET_GSM_CFR_DIF_MAP_CARRNO     pGetGsmCfrDifMapCarrNo;
    FUNC_GET_GSM_CFR_DIF_CARR_SUM       pGetGsmCfrDifCarrSum;
    FUNC_GET_GSM_DIF_CARRNO             pGetGsmDifCarrNo;

}T_GsmCfrModule;

typedef struct tag_gsm_power_module
{
    FUNC_BSP_TEMP_PARA_UPDATE pBspTempParaUpdate;
    FUNC_BSP_RX_SHUT_SWITCH  pBspRxShutSwitch;
    FUNC_BSP_SET_DIVMODE_CFG  pBspSetDivModeCfg;
    FUNC_BSP_SET_ANT_ALTER_CFG  pBspSetAntAlterCfg;
    FUNC_BSP_SWITCH_PA_SLOT_SHUT  pBspSwitchPaSlotShut;
    FUNC_BSP_GET_DL60MS_TAG_STATE  pBspGetDl60msTagState;
    FUNC_BSP_GET_DL_IQ_CHAN_STATE  pBspGetDlIqChanState;
    FUNC_BSP_SET_FPGA_DPT_FLT_SW  pBspSetFpgaDptFltSw;
    FUNC_BSP_SET_POW_LEVEL  pBspSetPowLevel;
    FUNC_BSP_SET_CARR_POW_GSM pBspSetCarrPowGsm;
    FUNC_BSP_SET_TSSI_POW_INFO pBspGetTssiPowInfo;
    FUNC_BSP_SET_RSSI_POW_INFO pBspGetRssiPowInfo;
    FUNC_SET_BBTSSI_NON_GSM_POW pBspGetBbtssiNonGsmPow;/*BSP从IC BBTSSI读取配置功率送给外扩逻辑*/
}T_GsmPowerModule;

typedef struct tag_gsm_freq_cfg_module
{
    FUNC_BSP_SET_CARR_EN_FLAG  pBspSetCarrEnFlag;
    FUNC_BSP_SET_CENTER_FREQ_POINT_TO_FPGA  pBspSetCenterFreqPointToFpga;
    FUNC_BSP_SET_TX_RF_CFG_GSM pBspSetTxRfCfg_Gsm;
    FUNC_BSP_SET_RX_RF_CFG_GSM pBspSetRxRfCfg_Gsm;

}T_GsmFreqCfgModule;

typedef struct tag_gsm_iq_cfg_module
{
}T_GsmIqCfgModule;

typedef struct tag_gsm_tsg_cfg_module
{
    FUNC_TSG_SELECT_G pTsgSelect_G;
}T_GsmTsgCfgModule;

typedef struct tag_ic_gsm_module
{
   T_GsmCfrModule cfrModule;
   T_GsmPowerModule powerModule;
   T_GsmFreqCfgModule freqCfgModule;
   T_GsmIqCfgModule iqCfgModule;
   T_GsmTsgCfgModule tsgCfgModule;
}T_IcGsmModule;

T_IcGsmModule* BspGetIcGsmModuleInfo(VOID);

UINT32 BspSetTssiPowInfo_Ic3_Gsm(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs);
UINT32 BspSetRssiPowInfo_Ic3_Gsm(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pRssiDbm, INT32 *pRssiDbfs);
UINT32 BspGetGsmCarrBw_Gsm(UINT32 difchan, UINT32 dir, UINT32 carrNo, UINT32 carrRadioMode, UINT32 *carrBw);
UINT32 BspGetGsmCarrFreq_Gsm(UINT32 difchan, UINT32 dir, UINT32 carrNo, UINT32 carrRadioMode, UINT32 *carrFreq);
UINT32 BspGetGsmCarrRadio_Gsm(UINT32 difchan, UINT32 dir, UINT32 carrNo, UINT32 *carrRadio);
UINT32 BspGetGsmCfrDifMapCarrNo_Gsm(UINT32 difchan, UINT32 dir, UINT32 origCarrNo, UINT32 carrRadioMode, UINT32 *mapCarrNo);
UINT32 BspGetGsmDifCarrSum_Gsm(UINT32 difchan, UINT32 dir);
UINT32 BspGetGsmDifCarrNo_Gsm(UINT32 radioMode, UINT32 difchan, UINT32 carrNo);

UINT32 BspCfgCfrGate_Gsm(UINT32 difChn);
UINT32 CfrCheckCarrInfo_Gsm(UINT32 difChn,UINT32 band,UINT32 cfrCarrPos);
UINT32 CfrGetBwCfgByCfrCarrPos_Gsm(UINT32 difChn,UINT32 band,UINT32 carrCfrPos);
UINT32 BspTempParaUpdate_Gsm(VOID);
UINT32 BspRxShutSwitch_Gsm(UINT32 uChn, UINT32 uSwitch);
UINT32 BspSetDivModeCfg_Gsm(T_RruDivModeCfgPara *ptCfgPara);
UINT32 BspSetAntAlterCfg_Gsm(UINT32 antAlterFlag);
UINT32 BspSwitchPaSlotShut_Gsm(UINT32 bspChn, UINT32 switchFlag);
UINT32 BspGetDl60msTagState_Gsm(UINT32 bspChn);
UINT32 BspGetDlIqChanState_Gsm(UINT32 bspChn);
UINT32 BspSetPowLevel_Gsm(UINT32 bspChn, UINT32 powLevel);
UINT32 BspSetCarrPow_Ic3_Gsm(UINT32 bspChn, UINT32 carrIndex,UINT32 carrPow, UINT32 radioMode);
UINT32 BspSetTxRfCfg_Ic3_Gsm(UINT32 chan, T_RfCfgPara *pRfCfgPara);
UINT32 BspSetRxRfCfg_Ic3_Gsm(UINT32 chan, T_RfCfgPara *pRfCfgPara);
UINT32 BspGetCfrCpgValidHalfLenMax_Gsm(UINT32 difChn, UINT32 *value);
UINT32 BspSetCfrCpgValidHalfLenMax_Gsm(UINT32 difChn, UINT32 value);
UINT32 BspGetCfrGate_Gsm(UINT32 difChn);
UINT32 BspSetCfrGate_Gsm(UINT32 difChn, UINT32 gate0, UINT32 gate1, UINT32 gate2, UINT32 gate3);
UINT32 BspSetCfr8pskGate_Gsm(UINT32 difChn, UINT32 gate0, UINT32 gate1, UINT32 gate2, UINT32 gate3);

/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : funccommon_chncfg.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : wangfei
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _FUNCLIB_FUNCCOMMON_CHNCFG_H_INCLUDE_
#define _FUNCLIB_FUNCCOMMON_CHNCFG_H_INCLUDE_
     
     
#ifdef __cplusplus
     extern "C"{
#endif
     
#include "semaphore.h"     
#include "rruinfo.h"


/**************************************************************************
*                          常量                                          *
**************************************************************************/    
 
 
/**************************************************************************
*                          宏定义                                        *
**************************************************************************/
#define DIF_CFG_BAND_NCO            2    /*支持2级NCO搬移*/
/**************************************************************************
*                          数据类型                                       *
**************************************************************************/


typedef struct tag_rru_carr_cfg_info
{
    UINT32 carrTxNo;
    UINT32 carrTxFreq;
    UINT32 carrTxBw;
    UINT32 carrTxRadio;
    
    UINT32 carrRxNo;
    UINT32 carrRxFreq;
    UINT32 carrRxBw;
    UINT32 carrRxRadio;

    UINT32 carrPow;
}T_RruCarrCfgInfo;

typedef struct tag_rru_cfg_info
{
    UINT32              txCfgCarrSum;
    UINT32              rxCfgCarrSum;
    UINT32              txCenterFreq;
    UINT32              rxCenterFreq;
    UINT32              txRfRangeMinFreq;
    UINT32              txRfRangeMaxFreq;
    UINT32              rxRfRangeMinFreq;
    UINT32              rxRfRangeMaxFreq;
    UINT32              txbandFreq[BSP_MAX_BAND_PER_CH]; /* 原结构体新增频段中心频点,双频段的二级NCO计算需要用到 --20190316 */
    UINT32              rxbandFreq[BSP_MAX_BAND_PER_CH]; /* 原结构体新增频段中心频点,双频段的二级NCO计算需要用到 --20190316 */
    UINT32              txRfRangeMinFreqB2; /* 原结构体新增第二个频段的滤波器范围 --20190316 */
    UINT32              txRfRangeMaxFreqB2; /* 原结构体新增第二个频段的滤波器范围 --20190316 */
    UINT32              rxRfRangeMinFreqB2; /* 原结构体新增第二个频段的滤波器范围 --20190316 */
    UINT32              rxRfRangeMaxFreqB2; /* 原结构体新增第二个频段的滤波器范围 --20190316 */
    T_RruCarrCfgInfo    carr[BSP_MAX_CARR_NUM];
}T_RruRfCfgInfo;

typedef struct tag_rru_carr_vswr_info
{
	UINT32     uiCarrNo;
    UINT32     uiCarrBitNumL;     //载波位图低32bit（R9214E）
	UINT32     uiCarrBitNumH;     //载波位图高32bit（R9214E）
	UINT32     uiSubCarrierSpacing; //子载波间隔（用于R9105 5G NR）
	UINT32     uiSsbGscn;                //SSB的GSCN（用于R9105 5G NR）
	UINT32     uiSsbSubBeamValidL;  //SSB发送的bit位图（用于R9105 5G NR）
	UINT32     uiSsbSubBeamValidH;  //SSB发送的bit位图（用于R9105 5G NR）
	UINT32     uiSsbPeriod;               //SSB循环周期（用于R9105 5G NR）
	INT32      iFraAHeadAdj;      //帧头调整
    INT32      uiSsbFreq;         //SSB射频频点，单位:khz
    UINT16     ssbSymbolFlag;     /* SSB有效符号使能标识，0 不使能，RRU不使用指示的符号索引；1 使能，矢量驻波检测使用指定的符号索引检测；*/
    UINT16     ssbSymbolIndex;    /* 使能时，该字段有效，SSB有效符号索引，当前有效值范围 0 -13*/
}T_RruCarrVswrInfo;

typedef struct tag_rru_vswr_info
{
	UINT32 uiCarrNum;
	T_RruCarrVswrInfo    carr[BSP_MAX_CARR_NUM];
}T_RruVswrInfo;




typedef struct tag_carr_ant_info
{
	UINT32     CarrNo;
	UINT32     CarrRadio;
    UINT32     CarrTxBitNumL;     //载波位图低32bit（R9214E）
	UINT32     CarrTxBitNumH;     //载波位图高32bit（R9214E）
}T_CarrAntInfo;

typedef struct tag_Fdd_Cell_Ant_info
{
	UINT32  totalCarrNum;  //总的小区个数，按照载波来
	T_CarrAntInfo    carr[BSP_MAX_CARR_NUM];
}T_FddCellAntInfo;


typedef struct tagRwSem
{
    UINT32   ulInit;
    INT32    lCounter;
    sem_t    RwSem;
} T_RwSem;





/*********************************************************************/
typedef struct tag_carr_cfg_info
{
    UINT32 carrNo;
    UINT32 carrFreq;    
    UINT32 carrPow;
    UINT32 carrBw;    
    UINT32 carrRadio;
    INT32  carrNco;    
}T_CarrCfgInfo;


typedef struct tag_dif_band_cfg_info
{
    UINT32 bandfreq;    
    T_CarrCfgInfo carr[BSP_MAX_CARR_NUM];
}T_RruDifBandInfo;

typedef struct tag_rru_band_cfg_info
{    
    UINT32 loFreq;    
    T_RruDifBandInfo   info[DIF_CFG_BAND_NCO];    
}T_RruBandCfgInfo;



/*载波功率获取结构体 高层目前没有大包配置,只能通过这个接口获取功率*/
typedef struct tag_rru_carr_pow_info
{
    UINT32 carrNo;
    UINT32 carrRadio;
    UINT32 carrPow;     // 实际的分载波功率，可能受降额的影响
    UINT32 cfgCarrPow;  // BBU下发的载波功率
}T_RruCarrPowInfo;

typedef struct tag_rru_carr_pow_cfg_info
{
      T_RruCarrPowInfo carr[BSP_MAX_CARR_NUM];
}T_RruCarrPowCfgInfo;

typedef UINT32 (*FUNC_CUSTOM_CARRCFG_CHECK)(UINT32 CenterFreq,UINT32 CarrFreq,UINT32 CarrBw,UINT32 CarrRadio);
/**************************************************************************
*                            函数原型                                    *
**************************************************************************/

UINT32 BspGetChnlCfgCarrPara(UINT32 rfChn, T_RruRfCfgInfo *pRruCfgPara);
UINT32 BspGetTxCenterFreqCfg(UINT32 rfchn);
// UINT32 BspCheckRruCfgParaData(UINT32 trxDir, T_RruRfCfgInfo *pRruCfgPara);
UINT32 BspChkRruCfgParamValid(UINT32 ulTrxDir, UINT32 ulCarrNum, T_RruRfCfgInfo *pRruCfgPara);
UINT32 BspSetRruCfgPara(UINT32 rfChn,T_RruRfCfgInfo *pRruCfgInfo);
UINT32 BspGetRruCfgPara(UINT32 rfChn,T_RruRfCfgInfo *pRruCfgPara);
UINT32 BspGetRruCfgParaByDir(UINT32 rfChn, UINT32 Dir, T_RruRfCfgInfo *pRruCfgPara);
UINT32 BspGetRruDifCfgPara(UINT32 rfChn,T_RruBandCfgInfo *pRruBandCfgPara);
UINT32 BspSetRruDifCfgPara(UINT32 rfChn,T_RruBandCfgInfo *pRruBandCfgPara);
UINT32 BspGetRruTxDifCfgPara(UINT32 rfChn,T_RruBandCfgInfo *pRruBandCfgPara);
UINT32 BspSetRruTxDifCfgPara(UINT32 rfChn,T_RruBandCfgInfo *pRruBandCfgPara);
UINT32 BspGetCarrPowCfg(UINT32 rfchn,UINT32 carrIndex,UINT32 carrRadio,UINT32 *pCarrPow);
UINT32 BspGetCarrRadioMode(UINT32 rfchn,UINT32 carrIndex,UINT32 dir,UINT32 *pCarrMode);
UINT32 BspGetCfgCarrPow(UINT32 rfChn, UINT32 carrNo, UINT32 radio, UINT32 *pCarrPow);
UINT32 BspSetCarrPowCfgPara(UINT32 rfChn,T_RruCarrPowCfgInfo *pRruPowInfo);
UINT32 BspGetCarrPowCfgPara(UINT32 rfChn,T_RruCarrPowCfgInfo *pRruPowInfo);
UINT32 BspClrRruCfgPara(UINT32 rfChn);
UINT32 BspClrRruRfCfgPara(UINT32 bspChan, UINT32 dir);
UINT32 BspGetChanMaxCarrBw(UINT32 uBspChn, UINT32 uDir, UINT32 uCarrMode);
UINT32 BspSetChanMaxCarrBw(UINT32 uBspChn,UINT32 uDir ,UINT32 uCarrMode, UINT32 uCarrBw);
UINT32 BspGetChanCarrSumPow(UINT32 rfChn, UINT32 *pCarrPow);
VOID BspCustomCarrCfgCheckCallBackInit(FUNC_CUSTOM_CARRCFG_CHECK pfunCallback);

UINT32 BspGetChnlCfgCarrPara_original(UINT32 rfChn, T_RruRfCfgInfo *pRruCfgPara);
UINT32 BspGetChnlCfgCarrPara_5G(UINT32 rfChn, T_RruVswrInfo *pRruVswrInfo);
UINT32 BspSetRruCfgPara_5G(UINT32 rfChn,T_RruVswrInfo *pRruVswrInfo);
UINT32 BspGetRruVswrInfo(UINT32 rfChn, T_RruVswrInfo *pRruVswrInfo);
UINT32 BspSetRruCfgPara_original(UINT32 rfChn,T_RruRfCfgInfo *pRruCfgInfo);
UINT32 BspClrRruCfgPara_original(UINT32 rfChn);
VOID BspShowRruCfgPara_original(UINT32 rfChnStart, UINT32 rfChnEnd);
UINT32 BspGetCarrActiveStatus(UINT32 ulChan, UINT32 dir, UINT32 ulRadioMode, UINT32 ulCarrNo);
UINT32 BspGetCarrSta(UINT32 chan, UINT32 dir, UINT32 radioMode, UINT32 carrNo, UINT32 *activeFlag);
BOOL BspIsFarmValidTxChan(UINT32 chan, UINT32 radioMode);
BOOL BspIsFarmValidRxChan(UINT32 chan, UINT32 radioMode);
UINT32 BspGetFarmTxCarrSwitch(UINT32 bspChan, UINT32 radioMode, UINT32 carrIdx);
UINT32 BspGetFarmRxCarrSwitch(UINT32 bspChan, UINT32 radioMode, UINT32 carrIdx);
UINT32 BspSetIsQcellFlag(UINT32 ulQcellFlag);
UINT32 BspGetRxCenterFreqCfg(UINT32 rfchn);
VOID BspClrFarmCfg(VOID);
VOID BspClrTxFarmCfg(VOID);
VOID BspClrRxFarmCfg(VOID);
VOID showrruvswrpara(UINT32 rfChnStart, UINT32 rfChnEnd);
#ifdef __cplusplus
     }
#endif
     
#endif  

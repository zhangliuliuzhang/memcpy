/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : funccommon.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _FUNCLIB_FUNCCOMMON_FPGA_H_
#define _FUNCLIB_FUNCCOMMON_FPGA_H_

#ifdef __cplusplus
extern "C" {
#endif

#define PRU_M (0)
#define PRU_S (1)

#define NORMAL_CHAN  (0)
#define FPGA_CHAN    (1)

#define INPUT_BSPCHN_CHECK(bspChan)  \
    if(bspChan >= BSP_MAX_CHAN_NUM)                                    \
    {                                                                \
        dbgErr("%s:Input BspTxChan is out range!\n", __FUNCTION__);  \
        return BSP_ERROR_OUT_OF_RANGE;                               \
    }

/* 用于减少接口入参数 */
typedef struct tag_FuncCarrInfo{
    UINT32 bspChn;
    UINT32 carr;
    UINT32 radioMode;
    UINT32 bandWidth;
    UINT32 ifType;
    UINT32 auiReserve;//预留字段
}T_FuncCarrInfo;

typedef UINT32 (*pBspCfgFpgaAiotOptInfo)(UINT32 uCfgNum, T_IQRecord_Slave *slaveiqPara);
typedef UINT32 (*pBspSetFpgaToffset)(UINT32 dpdicToffset);
typedef UINT32 (*pBspSetFpgaCarrRcf)(UINT32 uChipId, UINT32 uDir, T_FuncCarrInfo *pFuncCarrInfo);
typedef UINT32 (*pBspCfgFpgaCarrNco)(UINT32 difChan, UINT32 carr, UINT32 dir, UINT32 carrFreq, UINT32 centFreq);
typedef UINT32 (*pBspSetFpgaTsgSwitch)(UINT32 bspChan, UINT32 carr, UINT32 carrRadio, UINT32 isOn);
typedef UINT32 (*pBspInitFpgaPowCalc)(void);
typedef UINT32 (*pBspGetFpgaTssiPowInfo)(UINT32 bspChn, UINT32 carrMode,UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs);
typedef UINT32 (*pBspGetFpgaRssiPowInfo)(UINT32 bspChn, UINT32 bspCarrNo, UINT32 carrMode, INT32 *pRssiDbm, INT32 *pRssiDbfs);
typedef UINT32 (*pBspSetFpgaDataFresh)(UINT32 freshflag);
typedef UINT32 (*pBspGetFpgaTssiAlmStatus)(UINT32 bspChn,UINT32 *regVal);
typedef UINT32 (*pBspReadFpgaRevPow)(UINT32 bspChn, UINT32 ulBand, INT32 *ifTssiPow, INT32 *fbPow);
typedef UINT32 (*pBspReadFpgaFwdPow)(UINT32 bspChn, UINT32 ulBand, INT32 *ifTssiPow, INT32 *fbPow);
typedef UINT32 (*pBspSetFpgaCarrPow)(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode);
typedef UINT32 (*pBspSetFpgaPaSw)(UINT32 bspChan, UINT32 sw);
typedef UINT32 (*pBspGetFpgaPaSw)(UINT32 bspChan);
typedef UINT32 (*pBspSetFpgaLnaSw)(UINT32 bspChan, UINT32 sw);
typedef UINT32 (*pBspGetFpgaLnaSw)(UINT32 bspChan);
typedef UINT32 (*pBspSetFpgaRxVgaGain)(UINT32 difChan, UINT32 carrRadio, UINT32 carrNo, INT32 gain);
typedef UINT32 (*pBspCfgFpgaCellMode)(UINT32 cellCarrNo, UINT32 cellRadioMode, UINT32 cellTxAntMask, UINT32 cellRxAntMask);

typedef struct _Tag_FpgaInfoInit
{
    UINT32 txFpgaChanFlag[BSP_MAX_CHAN_NUM];
    UINT32 rxFpgaChanFlag[BSP_MAX_CHAN_NUM];
    pBspCfgFpgaAiotOptInfo          pFuncCfgFpgaAiotOptInfo;
    pBspSetFpgaToffset              pFuncSetFpgaToffset;
    pBspSetFpgaCarrRcf              pFuncSetFpgaCarrRcf;
    pBspCfgFpgaCarrNco              pFuncCfgFpgaCarrNco;
    pBspSetFpgaTsgSwitch            pFuncSetFpgaTsgSwitch;
    pBspInitFpgaPowCalc             pFuncInitFpgaPowCalc;
    pBspGetFpgaTssiPowInfo          pFuncGetFpgaTssiPowInfo;
    pBspGetFpgaRssiPowInfo          pFuncGetFpgaRssiPowInfo;
    pBspSetFpgaDataFresh            pFuncSetFpgaDataFresh;
    pBspGetFpgaTssiAlmStatus        pFuncGetFpgaTssiAlmStatus;
    pBspReadFpgaRevPow              pFuncReadFpgaRevPow;
    pBspReadFpgaFwdPow              pFuncReadFpgaFwdPow;
    pBspSetFpgaCarrPow              pFuncSetFpgaCarrPow;
    pBspSetFpgaPaSw                 pFuncSetFpgaPaSw;
    pBspGetFpgaPaSw                 pFuncGetFpgaPaSw;
    pBspSetFpgaLnaSw                pFuncSetFpgaLnaSw;
    pBspGetFpgaLnaSw                pFuncGetFpgaLnaSw;
    pBspSetFpgaRxVgaGain            pFuncSetRxVgaGainFpga;
    pBspCfgFpgaCellMode             pFuncCfgCellModeFpga;
}T_FpgaInfoInit;

UINT32 BspSetFpgaInfo(T_FpgaInfoInit *pFpgaInfo);
T_FpgaInfoInit *BspGetFpgaInfo(VOID);
UINT32 CfgCarrRcfFpga(T_FuncCarrInfo *pFuncCarrInfo, UINT32 dir);
UINT32 CfgCarrNcoFpga(T_FuncCarrInfo *pFuncCarrInfo, UINT32 dir, UINT32 carrFreq, UINT32 centFreq, UINT32 *fpgaFlag);

#ifdef __cplusplus
}
#endif

#endif


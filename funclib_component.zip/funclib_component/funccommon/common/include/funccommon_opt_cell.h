/**
 ******************************************************************************
 * Copyright (c) 2021 ZTE Corp. ZXSDR-RRU Platform BSP.
 *
 * @file        funccommon_opt_cell.h
 * @brief       光口小区公共头文件
 * @version     V1.0
 * @author      张磊10290326
 * @date        2021/01/27
 ******************************************************************************
*/

#include "bsppub.h"
#include "bspcomm.h"

#define MAX_CELL_CONFIG_NUM         8   // 支持小区的最大数量

VOID BspSetOptCellId(UINT32 cellIndex, UINT32 cellId);
VOID BspInitOptCellId(VOID);
UINT32 BspGetCellIdByIndex(UINT32 cellIndex);
UINT32 BspGetCellIndexById(UINT32 cellId);
UINT32 BspGetFirstUnusedCellIndex(VOID);

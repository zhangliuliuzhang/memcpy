/*********************************************************************
* 版权所有 (C)2017, 深圳市中兴通讯股份有限公司。
* 
* 文件名称： funccommon_log.h
* 文件标识： 
* 内容摘要： 打印模块 实现
* 其它说明： 
* 当前版本： 1.0
* 作     者：   190699
* 完成日期： 2017-04-01
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容： 

**********************************************************************/
#ifndef _FUNCLIB_FUNCCOMMON_LOG_H_INCLUDE_
#define _FUNCLIB_FUNCCOMMON_LOG_H_INCLUDE_


#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"




/**************************************************************************
 *                          常量                                          *
 **************************************************************************/
#define LOG_NONE       (0)
#define LOG_ERR        (0x1)
#define LOG_WARN       (0x2)
#define LOG_INFO       (0x4)
#define LOG_DBG        (0x8)


#define DEFAULT_LOG_LEVEL       (LOG_ERR|LOG_WARN|LOG_INFO)






/**************************************************************************
 *                          宏定义                                        *
 **************************************************************************/
#define ZTE_SECURITY_FUNC_CHECK(iRet)                                                             \
    {                                                                                             \
        if (BSP_FAIL == (INT32)(iRet))                                                            \
        {                                                                                         \
            dbgErr("[%s], line: %u, zte_s func iRet'%d Error \n", __FUNCTION__, __LINE__, (iRet));\
            return (iRet);                                                                        \
        }                                                                                         \
    }


#define MAX_LOG_LBL_MASK  (LOG_ERR|LOG_WARN|LOG_INFO|LOG_DBG)
#define LOG_NUM ((UINT32)1023)         // 日志条数目
#define LOG_LOC_BYTE ((UINT32)80)      // 位置信息的最大字符数
#define LOG_PARA_NUM ((UINT32)10)      // 参数最大个数
#define LOG_HEAD_REVERSE ((UINT32)120) // 日志头保留字符数
#define MA_LOG_FILE_NUM ((UINT32)10) // 输出log文件后缀最大值，即最多输出10个不同后缀的log文件
#define BSP_LOG_MAX_SIZE ((UINT32)2097152)  // 2M = 1024 * 1024 * 2
#define BSP_LOG_MAX_FILE_NUM ((UINT32)5) //压缩文件最大分卷数
#define BSP_LOG_MAX_STRING_LEN ((UINT32)100) //绝对路径最大字符数
#define BSP_LOG_PRINT_TO_FLASH 1

/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/
typedef enum LOG_LEVEL
{
    LOG_LEVEL_0 = 0,
    LOG_LEVEL_1 = 1,
    LOG_LEVEL_2 = 2,
    LOG_LEVEL_3 = 3,
    LOG_LEVEL_4 = 4,
    LOG_LEVEL_5 = 5,
}logLevel;





/**************************************************************************
 *                            函数原型                                    *
 **************************************************************************/
UINT32 BspLogPrintInit(UINT32 maxSize);
UINT32 BspLogPrintExtInit(UINT32 maxSize, const CHAR *fileName);

UINT32 BspLogPrintInit_udpmsg(UINT32 maxSize);


UINT32 BspLogAdd(const CHAR *name, UINT32 levelMask);
VOID BspLogPrint(UINT32 mod, UINT32 level, const char *format, ...);

VOID BspResetLogPrint(UINT32 mod, UINT32 level, UINT32 type, const char *format, ...);
UINT32 BspResetLogAdd(const CHAR *name, UINT32 levelMask);
UINT32 BspResetLogPrintInit(UINT32 maxSize);

INT32 BspLog(UINT32 logLevel, const CHAR *format, ...);
UINT32 BspSetLogFileName(const CHAR *logFileName);
INT64 BspGetLogFileLen(INT64 * size);
UINT32 BspSetLogPrintDirFlag(UINT32 flag);
UINT32 BspGetAreaLogLevel(UINT32 area);
UINT32 BspLoadAreaLogLevels(VOID);
VOID RruLinkPwrOffLogPrint(const char *format, ...);

#ifdef __cplusplus
}
#endif

#endif  /* _FUNCLIB_FUNCCOMMON_LOG_H_INCLUDE_ */



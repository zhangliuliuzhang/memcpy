/*****************************************************************************
 * 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : funccommon_ic_gsm_verify.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : ic3.0 gsm
 * 注意事项 : 无
 * 作    者 : wangjing
 * 创建日期 : 2021-12-13 09:41
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#ifndef _FUNCLIB_FUNCCOMON_IC_GSM_VERIFY_H
#define _FUNCLIB_FUNCCOMON_IC_GSM_VERIFY_H
#define SUPPORT_GSM              (1)
#define CONTAIN_NB               (1)
//coverity[cert_dcl37_c_violation:SUPPRESS]
#define EXTENDED_CFR_PRECISION   (1)

#include "bsppub.h"

UINT32 BspSetSupportGsmFlag(UINT32 difChn, UINT32 supGsm);
UINT32 BspGetSupportGsmFlag(UINT32 difChn);
UINT32 BspSetContainNBCfrFlag(UINT32 difChn, UINT32 flag);
UINT32 BspGetContainNBCfrFlag(UINT32 difChn);
UINT32 BspSetGsmDifVirtualNrBw(UINT32 ulBw);
UINT32 BspGetGsmDifVirtualNrBw(VOID);
UINT32 BspSetLowPriceGsmFlag(UINT32 isLowPrice);
UINT32 BspGetLowPriceGsmFlag(VOID);
UINT32 BspSetGsmTssiRssiFlag(UINT32 RssiTssiFlag);
UINT32 BspGetGsmTssiRssiFlag(VOID);
UINT32 BspSet6ChipAlignFlag(UINT32 is6Chip);
UINT32 BspGet6ChipAlignFlag(VOID);
UINT32 BspSetGsmCarrNum(UINT32 chn, UINT32 gsmCarrNum);
UINT32 BspGetGsmCarrNum(UINT32 chn);
UINT32 BspSetExtendedCfrPrecisionFlag(UINT32 flag);
UINT32 BspGetExtendedCfrPrecisionFlag();
UINT32 BspSetLowPriceChannelExFlag(UINT32 isLowPrice);

#endif  /*_FUNCLIB_FUNCCOMON_IC_GSM_VERIFY_H */

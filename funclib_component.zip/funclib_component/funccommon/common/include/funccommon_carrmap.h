/*********************************************************************
* 版权所有 (C)2017, 深圳市中兴通讯股份有限公司。
* 
* 文件名称： funccommon_pm.h
* 文件标识： 
* 内容摘要： 打印模块 实现
* 其它说明： 
* 当前版本： 1.0
* 作     者：   190699
* 完成日期： 2017-04-01
* 
* 修改记录1：
*    修改日期：
*    版 本 号：
*    修 改 人：
*    修改内容： 

**********************************************************************/
#ifndef _FUNCLIB_FUNCCOMMON_CARRMAP_H_INCLUDE_
#define _FUNCLIB_FUNCCOMMON_CARRMAP_H_INCLUDE_




UINT32 BspGetMSFlagByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *MSFlag);
UINT32 BspGetBspChnInfoByDifChn(UINT32 difChn, UINT32 dir,UINT32 *bspChn);
UINT32 BspGetCarrBwByRfCfg(UINT32 dir, UINT32 chan, UINT32 carrNo, UINT32 radioMode);

/* 根据配频预分析的全量信息生成业务载波号和载波序号之间的关系 */
typedef UINT32 (*CallBackFuncGetCarrIdx)(UINT32 dir, UINT32 bspChan, UINT32 radio, UINT32 carrNo);

/*
    函数名: BspGetPreAnalyseCarrIdx
    功能  :  根据载波的方向、通道、制式、业务载波号等信息获取载波序号
    返回值: >=BSP_MAX_CHAN_NUM 代表出错
            < BSP_MAX_CHAN_NUM 代表获取的载波需要
*/
UINT32 BspGetPreAnalyseCarrIdx(UINT32 dir, UINT32 bspChan, UINT32 radio, UINT32 carrNo);
VOID BspSetPreAnalyseCarrIdxFunc(CallBackFuncGetCarrIdx pFunc);

#ifdef __cplusplus
extern "C"{
#endif






/**************************************************************************
 *                          常量                                          *
 **************************************************************************/




/**************************************************************************
 *                          宏定义                                        *
 **************************************************************************/





/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/
typedef enum
{
    E_NOCHANGE_FLAG = 0, /* 该条数据不变 */
	E_ADD_FLAG,          /* 使用光口的扇区号 */
	E_DEL_FLAG           /* 不使用光口的扇区号 */
}T_AddDelFlag;

typedef enum _RADIOMODE_INDEX
{
    DIF_RADIOMODE_UMTS = 0,
    DIF_RADIOMODE_GSM,
    DIF_RADIOMODE_TDS,
    DIF_RADIOMODE_CDMA,
    DIF_RADIOMODE_LTE_FDD,
	DIF_RADIOMODE_LTE_TDD,
    DIF_RADIOMODE_NBIOT,
    DIF_RADIOMODE_NR,
	DIF_RADIOMODE_NR_IF0,
	DIF_RADIOMODE_NR_IF1,
    DIF_RADIOMODE_MAX,
}RADIOMODE_INDEX;


typedef enum
{
    RADIO_MAP_UMTS = 0,
    RADIO_MAP_GSM,     
    RADIO_MAP_LTE_FDD, 
    RADIO_MAP__LTE_TDD,
    RADIO_MAP__NB_IOT, 
    RADIO_MAP__5G_TDD, 
    RADIO_MAP__5G_FDD, 
    RADIO_MAP_TYPE_NUM
}RADIO_MAP;

typedef struct tagT_CarrFrqMapInfo
{
    UINT32  dir;
    UINT32  carrstartfrq;
    UINT32  carrendfrq;
    UINT32  difcarrbitmap;
    UINT32  carrmode;
    INT32  defbanknco;
    UINT32 difchan;
    UINT32 mapcarr;
}T_CarrFrqMapInfo;

typedef struct tagT_RADIO_MAP
{
    UINT32 radioNo;
    UINT32 radioType;
}T_RADIO_MAP;

typedef struct tagT_CarrMapInfo
{
    UINT32  dir;
    UINT32  bspchan;
    UINT32  carrno;
    UINT32  carrpos;
}T_CarrMapInfo;

typedef UINT32 (*pGetCarrNoDymMallocFlag)(UINT32 dir,UINT32 rmode,UINT32 carrno);
typedef UINT32 (*pGetLteNrDifId)(VOID);

/**************************************************************************
 *                            函数原型                                    *
 **************************************************************************/

VOID BspSetSupportTsgMode(UINT8 enable);
UINT32 BspGetDifCarrNoByIqCfg(T_RuMmIqCfgItem* pIqCfg,UINT32* pCarrNo);

UINT32 BspAllocateCarrMapByIqCfg(T_RuMmIqCfgItem* pIqCfg);

UINT32 BspGetBspChanNum(UINT32 dir);

UINT32 BspGetDifModeByRadioMode(UINT32 uMode, UINT32 *pDifMode);
UINT32 BspGetRadioModeByDifMode(UINT32 uDifMode, UINT32 *pMode);
UINT32 BspInitCarrMap(UINT32 dir, UINT32 radioMode, UINT32 ResourceNum);
UINT32 BspGetRruSupportCarrNum(UINT32 uChn, UINT32 uBand, UINT32 uMode);
UINT32 BspGetDivFlag(void);
UINT32 BspSetDivFlag(UINT32 divFlag);
UINT32 BspGetRxLogicChanNum();
UINT32 showcarrmap(UINT32 uDifMode);
UINT32 BspGetBandDefNcoOffset(UINT32 uDir, UINT32 carrfrq,INT32 *defncoffset);
UINT32 BspGetDifCarrMapPos(UINT32 uDir, UINT32 freq,UINT32 carrmode);
UINT32 BspSetDifCarrMapCfg(UINT32 mapnum,T_CarrFrqMapInfo *freqmapcfg);
UINT32 BspInitDifCarrMapTbl(UINT32 mapnum ,T_CarrFrqMapInfo *maptbl);
UINT32 BspInitCarrMapTbl(UINT32 mapnum ,T_CarrMapInfo *maptbl);
UINT32 BspSetCarrMap(UINT32 chn,UINT32 dir);//,T_RfCfgPara *pRfCfgPara);
UINT32 BspGetCarrDifChanByCfg(UINT32 bspchan,UINT32 uDir, UINT32 freq,UINT32 carrmode,UINT32 *difchan,UINT32 carrno);
UINT32 BspGetCarrIndexByFreq(UINT32 uDir,UINT32 freq,UINT32 carrmode);
UINT32 BspSetCarrNoDymMallocFncPtr(pGetCarrNoDymMallocFlag fnc);
UINT32 BspGetCarrNoDymMallocFlag(UINT32 dir,UINT32 rmode,UINT32 carrno);
UINT32 BspSetCarrMapSupportInfoEx(UINT32 radioMode, UINT32 flag);
UINT32 BspSetCarrMapSupportInfo(UINT32 radioMode, UINT32 flag);
UINT32 BspGetDifInfoByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pdifChipId, UINT32 *pdifChan);
UINT32 BspGetLteNrDifId(pGetLteNrDifId ptfuc);
VOID BspFreeCarrMapByRfCfg(UINT32 uBspChn, UINT32 uDir);
VOID BspSetCarrMapDelFucSupportFlag(UINT32 flg);
UINT32  BspGetCarrMapDelFucSupportFlag(VOID);
UINT32 BspGetCarrMapFlag(void);
void BspSetIf1NRCarrMapFlag(UINT32 ulSupport);
UINT32 BspAllocateCarrMapByRfCfg(UINT32 uBspChn, UINT32 uDir, T_RfCfgPara *pRfCfgPara);
UINT32 BspGetModeNoByRadioMode(UINT32 uMode, UINT32 *pModeNo);
#ifdef __cplusplus
}
#endif

#endif  /* _FUNCLIB_FUNCCOMMON_PM_H_INCLUDE_ */



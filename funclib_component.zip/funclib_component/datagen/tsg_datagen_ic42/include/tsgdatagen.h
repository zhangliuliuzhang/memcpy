/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : tsgcommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了TSG接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_TSGDATAGEN_H_
#define _FUNCLIB_TSGDATAGEN_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "bspbasetype.h"

#define D42_NR_FDD     0x4000
#define D42_NR_TDD     0x2000
#define D42_LTE_FDD    0x10
#define D42_LTE_TDD    0x20
#define DATAGEN_TDD_MODE       0
#define DATAGEN_FDD_MODE       1
#define DATAGEN_RRU_MODE       0
#define DATAGEN_AAU_MODE       1


//所有制式下参数
UINT32 BspSetNrDataPara(UINT32 uislot,UINT32 uiBandWidth,UINT32 uiDataType,UINT32 uiTddOrFddFlg,UINT32 uiAauOrRruFlg);
UINT32 BspSetLteDataPara(UINT32 uislot,UINT32 uiBandWidth,UINT32 uiDataType,UINT32 uiTddOrFddFlg,UINT32 uiAauOrRruFlg);

#ifdef __cplusplus
}
#endif
#endif 




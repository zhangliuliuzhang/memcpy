
#include "bspcomm.h"
#include "bsppub.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tsgdatagen_common.h"
#include "tsgdatagen.h"
#include <math.h>
#include <string.h>
#include "exprn.h"
#include "resource_alloc_info.h"

//*************************************************************************
//                          常量定义及初始化                               *
//*************************************************************************
T_EvmDataParaInfo g_EvmNrDataParaInfo[] = \
{
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_100M_MHz,DATA_RATE_122P88},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_90M_MHz ,DATA_RATE_122P88},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_80M_MHz ,DATA_RATE_92P16},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_70M_MHz ,DATA_RATE_92P16},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_60M_MHz ,DATA_RATE_61P44},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_50M_MHz ,DATA_RATE_61P44},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_40M_MHz ,DATA_RATE_46P08},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_30M_MHz ,DATA_RATE_30P72},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_20M_MHz ,DATA_RATE_30P72},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_15M_MHz ,DATA_RATE_30P72},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_10M_MHz ,DATA_RATE_15P36},
    {NR_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_5M_MHz  ,DATA_RATE_7P68},

    {LTE_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_20M_MHz,DATA_RATE_30P72},
    {LTE_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_15M_MHz,DATA_RATE_30P72},
    {LTE_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_10M_MHz,DATA_RATE_15P36},
    {LTE_DATA_MODE,RRU_DATA_MODE,DATA_BANDWIDTH_5M_MHz, DATA_RATE_7P68},

};

//*************************************************************************
//                         函数实现
//*************************************************************************
/**************************************************************************
 * 函数名称: BspGetFFTSampleRate
 * 功能描述: 获取数据速率
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGetFFTSampleRate(UINT32 uiDataMode,UINT32 uiAauMode,UINT32 uiBandWidth,UINT32 *puiSample)
{
    UINT32 loop = 0;
    UINT32 num  = 0;
    UINT32 sample = 0;
    UINT32 uiBandValidFlg = 0;

    if(NULL == puiSample)
    {
        return BSP_ERROR;
    }

    num = (sizeof(g_EvmNrDataParaInfo) / sizeof(g_EvmNrDataParaInfo[0]));
    for(loop=0; loop < num;loop++)
    {
        if((uiDataMode == g_EvmNrDataParaInfo[loop].uiNrOrLteMode)&&(uiAauMode == g_EvmNrDataParaInfo[loop].uiAauorRruMode)&&(uiBandWidth == g_EvmNrDataParaInfo[loop].uiBandWidth))
        {
            sample = g_EvmNrDataParaInfo[loop].uiSampleRate;
            *puiSample = sample ;
            dbgInfo("%s:DataRate is %u !!\n",__FUNCTION__,sample);
            break;
        }
    }
    dbgInfoEx("%s:uiDataMode= %u,uiAauMode= %u,uiBandWidth=%u!\n",__FUNCTION__,uiDataMode,uiAauMode,uiBandWidth);

    if(1 == uiBandValidFlg)
    {
        dbgInfo("%s:Donot Support This BandWidth!!!!!!!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    return BSP_OK;
}
/**************************************************************************
 * 函数名称:BspSetNrDataPara()
 * 功能描述:
 * 输入参数:uislot --slot号
         uiBandWidth --带宽
         uiDataType -- 类型 3表示3.1 4表示3.1a
         uiTddOrFddFlg -- 0x1表示FDD，0x0表示TDD
         uiAauOrRruFlg -- 0x1表示AAU，0x0表示RRU
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetNrDataPara(UINT32 uislot,UINT32 uiBandWidth,UINT32 uiDataType,UINT32 uiTddOrFddFlg,UINT32 uiAauOrRruFlg)
{
    UINT32 uiSampRate  = 0;
    UINT32 uiRadioMode = 0;
    UINT32 uiBandWithKhz = 0;
    T_NrOrLteDataPara tNrOrLteDataPara ;

    dbgInfo("%s:uislot= %u,uiBandWidth= %u,uiDataType=%u!!\n",__FUNCTION__,uislot,uiBandWidth,uiDataType);

    if(0 == uiTddOrFddFlg)
    {
        uiRadioMode = D42_NR_TDD ;
        dbgInfo("it belongs to TDD !!\n");
    }
    else
    {
        uiRadioMode = D42_NR_FDD ;
        dbgInfo("it belongs to FDD !!\n");
    }

    if(0 == uiAauOrRruFlg)
    {
        dbgInfo("it belongs to RRU !!\n");
    }
    else
    {
        dbgInfo("it belongs to AAU !!\n");
    }

    //获取数据速率
    uiBandWithKhz = uiBandWidth * 1000 ;
    if(BSP_OK == IcHalGetTxCarrSample(uiRadioMode, uiBandWithKhz, &uiSampRate))
    {
        //参数设置
        dbgInfo("uiSampRate is %d !!\n",uiSampRate);
        tNrOrLteDataPara.uiAauOrRruFlg = uiAauOrRruFlg ;
        tNrOrLteDataPara.uiBandWidth = uiBandWidth ;
        tNrOrLteDataPara.uiDataRate = uiSampRate;
        tNrOrLteDataPara.uiDataType = uiDataType;
        tNrOrLteDataPara.uiTddOrFddFlg = uiTddOrFddFlg ;
        tNrOrLteDataPara.uislot = uislot ;
        BspSetNrEvmPara(&tNrOrLteDataPara);
        return BSP_OK;
    }

    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称:BspSetLteDataPara()
 * 功能描述:
 * 输入参数:uislot --slot号
         uiBandWidth --带宽
         uiDataType -- 类型 3表示3.1 4表示3.1a
         uiTddOrFddFlg -- 0x1表示FDD，0x0表示TDD
         uiAauOrRruFlg -- 0x1表示AAU，0x0表示RRU
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetLteDataPara(UINT32 uislot,UINT32 uiBandWidth,UINT32 uiDataType,UINT32 uiTddOrFddFlg,UINT32 uiAauOrRruFlg)
{
    UINT32 uiSampRate      = 0;
    UINT32 uiRadioMode     = 0;
    UINT32 uiBandWithKhz   = 0;
    UINT32 uiDatPwrN13Dbfs = 0;
    T_NrOrLteDataPara tNrOrLteDataPara ;

    dbgInfo("%s:uislot= %u,uiBandWidth= %u,uiDataType=%u!!\n",__FUNCTION__,uislot,uiBandWidth,uiDataType);

    if(DATAGEN_TDD_MODE == uiTddOrFddFlg)
    {
        uiRadioMode = D42_LTE_TDD ;
        dbgInfo("it belongs to TDD !!\n");
    }
    else
    {
        uiRadioMode = D42_LTE_FDD ;
        dbgInfo("it belongs to FDD !!\n");
    }

    if(DATAGEN_RRU_MODE == uiAauOrRruFlg)
    {
        dbgInfo("it belongs to RRU !!\n");
    }
    else
    {
        dbgInfo("it belongs to AAU !!\n");
    }

    if((DATAGEN_FDD_MODE == uiTddOrFddFlg)&&(DATAGEN_RRU_MODE == uiAauOrRruFlg))
    {
        uiDatPwrN13Dbfs = 1 ;
    }
    else
    {
        uiDatPwrN13Dbfs = 0 ;
    }

    //获取数据速率
    uiBandWithKhz = uiBandWidth * 1000 ;
    if(BSP_OK == IcHalGetTxCarrSample(uiRadioMode, uiBandWithKhz, &uiSampRate))
    {
        //参数设置
        dbgInfo("uiSampRate is %d !!\n",uiSampRate);
        tNrOrLteDataPara.uiAauOrRruFlg = uiAauOrRruFlg ;
        tNrOrLteDataPara.uiBandWidth = uiBandWidth ;
        tNrOrLteDataPara.uiDataRate = uiSampRate;
        tNrOrLteDataPara.uiDataType = uiDataType;
        tNrOrLteDataPara.uiTddOrFddFlg = DATAGEN_FDD_MODE ;   ///TDD/FDD 都是按照FDD模式生成源文件
        tNrOrLteDataPara.uislot = uislot ;
        tNrOrLteDataPara.uiDatPwrN13DbfsFlg = uiDatPwrN13Dbfs ;
        BspSetLteEvmPara(&tNrOrLteDataPara);
        return BSP_OK;
    }

    return BSP_ERROR;
}



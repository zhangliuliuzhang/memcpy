/*
 * tsgdatagen_common.c
 *
 *  Created on: 2023年4月1日
 *      Author: 10144629
 */


#include "bspcomm.h"
#include "bsppub.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "tsgdatagen_common.h"
#include <math.h>
#include <string.h>
#include "exprn.h"

//根据配置，选择调制方式
BspQAMGenCalFunction BspQamGen[EVM_MODULE_NUM]={
        BspQPSKGen,
        BspQAM64Gen,
        BspQAM256Gen
};

//*************************************************************************
//                          常量定义及初始化                               *
//*************************************************************************
T_CellInfoModuDatGen g_atCellInfoModuDatGen ={0};

UINT32 g_uiEvmTimeData[SLOT_TIMEDATA_LEN] = {0};

//本地基序列
INT32 type1_CDM_grop[TYPE1_PORT_NUM] = {0,0,1,1,0,0,1,1};
INT32 type1_delta[TYPE1_PORT_NUM] = {0,0,1,1,0,0,1,1};
INT32 type1_Wf[TYPE1WF_K_NUM][TYPE1_PORT_NUM] =
{
        {1,1,1,1,1,1,1,1},
        {1,-1,1,-1,1,-1,1,-1}
};
INT32 type1_Wt[TYPE1WT_L_NUM][TYPE1_PORT_NUM] =
{
        {1,1,1,1,1,1,1,1},
        {1,1,1,1,-1,-1,-1,-1}
};
INT32 type2_CDM_grop[TYPE2_PORT_NUM] = {0,0,1,1,2,2,0,0,1,1,2,2};
INT32 type2_delta[TYPE2_PORT_NUM] = {0,0,2,2,4,4,0,0,2,2,4,4};
INT32 type2_Wf[TYPE2WF_K_NUM][TYPE2_PORT_NUM] =
{
        {1,1,1,1,1,1,1,1,1,1,1,1},
        {1,-1,1,-1,1,-1,1,-1,1,-1,1,-1}
};
INT32 type2_Wt[TYPE2WT_L_NUM][TYPE2_PORT_NUM] =
{
        {1,1,1,1,1,1,1,1,1,1,1,1},
        {1,1,1,1,1,1,-1,-1,-1,-1,-1,-1}
};
INT32 typeA_LbarofSingleDmrsAdd[TYPEA_SINGLE_NUM][TYPEA_SINGLE_ADD_NUM][TYPEA_SINGLE_SYMBOLS_NUM]=
{
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        },
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,7,7,9,9,9,11,11},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        },
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,7,7,6,6,6,7,7},
            {0,0,0,0,0,0,0,0,0,9,9,9,11,11},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        },
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,7,7,6,6,5,5,5},
            {0,0,0,0,0,0,0,0,0,9,9,8,8,8},
            {0,0,0,0,0,0,0,0,0,0,0,11,11,11}
        }
};
INT32 typeB_LbarofSingleDmrsAdd[TYPEB_SINGLE_NUM][TYPEB_SINGLE_ADD_NUM][TYPEB_SINGLE_SYMBOLS_NUM]=
{
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        },
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,4,4,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        },
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        },
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        }
};
INT32 typeA_LbarofDoubleDmrsAdd[TYPEA_DOUBLE_NUM][TYPEA_DOUBLE_ADD_NUM][TYPEA_DOUBLE_SYMBOLS_NUM]=
{
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}

        },
        {   {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,8,8,8,10,10}
        }
};
INT32 typeB_LbarofDoubleDmrsAdd[TYPEB_DOUBLE_NUM][TYPEB_DOUBLE_ADD_NUM][TYPEB_DOUBLE_SYMBOLS_NUM]=
{
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        },
        {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0}
        }
};

UINT8 g_ucBrev[64] = {
    0x0, 0x20, 0x10, 0x30, 0x8, 0x28, 0x18, 0x38,
    0x4, 0x24, 0x14, 0x34, 0xc, 0x2c, 0x1c, 0x3c,
    0x2, 0x22, 0x12, 0x32, 0xa, 0x2a, 0x1a, 0x3a,
    0x6, 0x26, 0x16, 0x36, 0xe, 0x2e, 0x1e, 0x3e,
    0x1, 0x21, 0x11, 0x31, 0x9, 0x29, 0x19, 0x39,
    0x5, 0x25, 0x15, 0x35, 0xd, 0x2d, 0x1d, 0x3d,
    0x3, 0x23, 0x13, 0x33, 0xb, 0x2b, 0x1b, 0x3b,
    0x7, 0x27, 0x17, 0x37, 0xf, 0x2f, 0x1f, 0x3f
};

INT32 g_aiBandIndex[BAND_NUM] = {100,90,80,70,60,50,40,30,20,15,10,5};
INT32 g_aiValidRbNum[SCS_NUM][BAND_NUM]  =
{
   {0,0,0,0,0,0,216,160,106,79,52,25},
   {273, 245,217, 0, 162, 133, 106, 78, 51,38,24,11}
};
INT32 g_aiQamType[DATA_MODE_NUM] = {0,1,2,1,2}; //0 QPSK 1 64QAM 2 256QAM
INT32 g_aiPdcchSchFill[DATA_MODE_NUM] = {1,0,0,1,1}; //1表示填充
INT32 g_aiAdjPdschPos[DATA_MODE_NUM][TM2MODE_POS_NUM][SCS_NUM][BAND_NUM] =
{
    {{{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}}},
    {{{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,108,80,53,39,26,12},
     {136, 122,108, 0, 81, 66, 53, 39, 25,19,12,5}},
     {{0,0,0,0,0,0,215,159,105,78,51,24},
     {272, 244,216, 0, 161, 132, 105, 77, 50,37,23,10}}},
    {{{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,108,80,53,39,26,12},
     {136, 122,108, 0, 81, 66, 53, 39, 25,19,12,5}},
     {{0,0,0,0,0,0,215,159,105,78,51,24},
     {272, 244,216, 0, 161, 132, 105, 77, 50,37,23,10}}},
    {{{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}}},
    {{{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}},
     {{0,0,0,0,0,0,0,0,0,0,0},
     {0,0,0,0,0,0,0,0,0,0,0}}}
};
INT32 g_aiAdjPdschLen[DATA_MODE_NUM][SCS_NUM][BAND_NUM] =
{
    {{0,0,0,0,0,0,216,160,106,79,52,25},
     {273, 245,217, 0, 162, 133, 106, 78, 51,38,24,11}},
    {{0,0,0,0,0,0,1,1,1,1,1},
     {1,1,1,0,1,1,1,1,1,1,1}},
    {{0,0,0,0,0,0,1,1,1,1,1},
     {1,1,1,0,1,1,1,1,1,1,1}},
    {{0,0,0,0,0,0,216,160,106,79,52,25},
     {273, 245,217, 0, 162, 133, 106, 78, 51,38,24,11}},
    {{0,0,0,0,0,0,216,160,106,79,52,25},
     {273, 245,217, 0, 162, 133, 106, 78, 51,38,24,11}}
};
///定标功率
INT32 g_aiDataPwrType[DATA_MODE_NUM] = {-14,-37,-37,-14,-14};
//信号位宽
INT32 g_aiDataWidth = 16;
//种子号
UINT32 g_uiRandPara = 200;
///Pdcch符号位置
UINT32 g_uiPdcchSymbolPos[PDCCH_SYMBOLE_NUM] = {0,1,2};
//Pdcch符号个数
UINT32 g_uiPdcchSymbolNum = 2 ;
//fdmon符号标志位
UINT32 g_aiPdcchFdmOnOrOff = 1;

//DMRS 时域位置配置
UINT32 g_uiDmrsMapType= 0;    ///DMRS  0表示typeA 1表示typeB
UINT32 g_uiLimits= 0;          //DMRS单双符号标志 0表示单符号 1表示双符号
UINT32 g_uiDmrsAddPos = 1;     ///DMRS 增加符号的个数 0表示不增加  1表示单符号下增加1个，双符号下增加 2个
UINT32 g_uiDmrsFirstPos= 2;   ///DMRS 第一个符号位置
UINT32 g_uiDmrsNum= 2;        //DMRS 符号个数
UINT32 g_uiDmrsAddPdschFlg = 1; //填充

//DMRS 频域位置生成配置
UINT32 g_uiCellId= 1;   ///DMRS的cellid
UINT32 g_uiDmrsType= 0;   ///DMRS的TypeA
UINT32 g_uiPortId= 0;   ///DMRS的PortId
UINT32 g_uiScId= 0;   ///DMRS的cellid


//LTE RB数目
INT32 g_aiLteValidRbNum[BAND_NUM] = {0,0,0,0,0,0,0,0,100,75,50,25};

//Pss 索引
INT32 g_aiPssUindex[PSS_INDEX_NUM] = {25,29,34};

//*************************************************************************
//                         函数实现
//*************************************************************************

/**************************************************************************
 * 函数名称: BspSetTimeDmrs
 * 功能描述: DMRS时域参数配置
 * 输入参数: uiDmrsMapType - DMRS  0表示typeA 1表示typeB
            uiLimits - DMRS单双符号标志 0表示单符号 1表示双符号
            uiDmrsAddPos - DMRS 增加符号的个数 0表示不增加  1表示单符号下增加1个，双符号下增加 2个
            uiDmrsFirstPos - DMRS 第一个符号位置
            uiDmrsAddPdschFlg - DMRS 是否填充
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetTimeDmrs(UINT32 uiDmrsMapType,UINT32 uiLimits,UINT32 uiDmrsAddPos,UINT32 uiDmrsFirstPos,UINT32 uiDmrsAddPdschFlg)
{
    g_uiDmrsMapType     = uiDmrsMapType;    ///DMRS  0表示typeA 1表示typeB
    g_uiLimits          = uiLimits;         //DMRS单双符号标志 0表示单符号 1表示双符号
    g_uiDmrsAddPos      = uiDmrsAddPos;     ///DMRS 增加符号的个数 0表示不增加  1表示单符号下增加1个，双符号下增加 2个
    g_uiDmrsFirstPos    = uiDmrsFirstPos;   ///DMRS 第一个符号位置
    g_uiDmrsAddPdschFlg = uiDmrsAddPdschFlg; //填充标志
    g_uiDmrsNum = (uiLimits + 1) + uiDmrsAddPos*(uiLimits + 1); ///DMRS符号个数计算

    dbgInfo("DMRS g_uiDmrsMapType :%d,g_uiLimits:%d,g_uiDmrsAddPos:%d,g_uiDmrsFirstPos:%d,g_uiDmrsAddPdschFlg:%d,g_uiDmrsNum:%d\n",g_uiDmrsMapType,g_uiLimits,g_uiDmrsAddPos,g_uiDmrsFirstPos,g_uiDmrsAddPdschFlg,g_uiDmrsNum);


    return BSP_OK ;
}
/**************************************************************************
 * 函数名称: BspSetFreqDmrs
 * 功能描述: DMRS频域参数配置
 * 输入参数: uiCellId - DMRS的 uiCellId
            uiDmrsType - DMRS的Type
            uiPortId - DMRS的portid
            uiScId - DMRS的ScId
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetFreqDmrs(UINT32 uiCellId,UINT32 uiDmrsType,UINT32 uiPortId,UINT32 uiScId)
{
    g_uiCellId    = uiCellId    ;
    g_uiDmrsType  = uiDmrsType  ;
    g_uiPortId    = uiPortId    ;
    g_uiScId      = uiScId      ;

    dbgInfo("DMRS g_uiCellId :%d,g_uiDmrsType:%d,g_uiPortId:%d,g_uiScId:%d\n",g_uiCellId,g_uiDmrsType,g_uiPortId,g_uiScId);

    return BSP_OK ;
 }
/**************************************************************************
 * 函数名称: BspGetNrEvmPara
 * 功能描述: 获取NREvmPara
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGetNrEvmPara()
{
    dbgInfo("DMRS First Symbol Pos :%d\n",g_uiDmrsFirstPos);
    dbgInfo("DMRS Single or Double Symbol Flag :%d !! 0:Single Symbol,1:Double Symbol\n",g_uiLimits);
    dbgInfo("DMRS DMRS Symbol Num:%d\n",g_uiDmrsNum);
    dbgInfo("DMRS Fill in Data:%d !! 1:Fill in Data,0:Donot Fill in Data\n",g_uiDmrsAddPdschFlg);
    dbgInfo("DMRS CellId:%d\n",g_uiCellId);
    dbgInfo("DMRS ScId:%d\n",g_uiScId);

    return BSP_OK ;
}

/**************************************************************************
 * 函数名称: BspSetPwrPara
 * 功能描述: 生成信号的功率设定
 * 输入参数: iPwrDbfs - 设定功率的dbfs
            uiDataWidth - 信号的位宽 如设置16，表示信号位宽是16bit，1bit是否符号，15bit是数据
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetPwrPara(INT32 iPwrDbfs,UINT32 uiDataWidth)
{
    UINT32 i ;

    for(i=0;i<DATA_MODE_NUM;i++)
    {
        g_aiDataPwrType[i] = iPwrDbfs ;
    }
    g_aiDataWidth = uiDataWidth;

    dbgInfo("iPwrDbfs:%d,iDataWidth:%d\n",iPwrDbfs,uiDataWidth);

    return BSP_OK ;
}

/**************************************************************************
 * 函数名称: g_aiPdcchFdmOnOrOff
 * 功能描述: 设定是否是fdmon
 * 输入参数: uiPdcchFdmOnOrOff - 1表示fdmon 0表示fdmoff
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetPdcchFdmOn(UINT32 uiPdcchFdmOnOrOff)
{
    g_aiPdcchFdmOnOrOff = uiPdcchFdmOnOrOff ;

    dbgInfo("g_aiPdcchFdmOnOrOff:%d\n",g_aiPdcchFdmOnOrOff);

    return BSP_OK ;
}
/**************************************************************************
 * 函数名称: BspSetPdcchPara
 * 功能描述: 设定Pdcch的索占符号位置
 * 输入参数: uiPdcchSymbolNum - 占符号的个数
            uiPdcchSymbolPos0 - 第一个位置 0表示符号0，1表示符号1
            uiPdcchSymbolPos1 - 第二个位置 0表示符号0，1表示符号1
            uiPdcchSymbolPos2 - 第二个位置 0表示符号0，1表示符号1
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetPdcchPara(UINT32 uiPdcchSymbolNum,UINT32 uiPdcchSymbolPos0,UINT32 uiPdcchSymbolPos1,UINT32 uiPdcchSymbolPos2)
{
    UINT32   i ;

    for(i=0;i<PDCCH_SYMBOLE_NUM;i++)
    {
        if(0 == i)
        {
            g_uiPdcchSymbolPos[i] =  uiPdcchSymbolPos0  ;
        }
        else if(1 == i)
        {
            g_uiPdcchSymbolPos[i] =  uiPdcchSymbolPos1  ;
        }
        else
        {
            g_uiPdcchSymbolPos[i] =  uiPdcchSymbolPos2 ;
        }
    }

    g_uiPdcchSymbolNum  = uiPdcchSymbolNum ;

    dbgInfo("uiPdcchSymbolNum:%d,uiPdcchSymbolPos0:%d,uiPdcchSymbolPos1:%d,uiPdcchSymbolPos2:%d\n",g_uiPdcchSymbolNum,g_uiPdcchSymbolPos[0],g_uiPdcchSymbolPos[1],g_uiPdcchSymbolPos[2]);

    return BSP_OK ;
}

/**************************************************************************
 * 函数名称: BspCal2power
 * 功能描述: 求2的幂次方
 * 输入参数: uiPowVal - 幂次数
 * 输出参数: 2的幂次方
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspCal2power(UINT32 uiPowVal)
{
    UINT32 uiCalVal    = 1 ;
    UINT32 i;

    for(i = 1;i <= uiPowVal ;i++ )
    {
        uiCalVal = 2 * uiCalVal ;
    }

    return uiCalVal ;
}
/**************************************************************************
 * 函数名称: BspSetNrEvmPara
 * 功能描述: 在线源参数设置在线配置
 * 输入参数: uiScs：0表示15k 1表示30k
            uislot - slot号
            uiBandWidth - 带宽
            uiDataType-0表示TM1.1 1表示TM2 2表示TM2A 3表示TM3.1 4表示TM3.1a
                        数据速率-khz
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetNrEvmPara(T_NrOrLteDataPara *ptNrOrLteDataPara)
{
    UINT32 uiBandIndex      = 0;
    UINT32 uiBandIndexLoop  = 0;
    UINT32 uiDataFftSizeTmp = 0;
    UINT32 uiSymbolLen      = 0;
    UINT32 uiValidScNum     = 0;
    UINT32 uiTm2RbPos       = 0;
    UINT32 uiAdjPdschPos    = 0;
    UINT32 uiAdjPdschLen    = 0;
    UINT32 uiScs            = 0;
    INT32 iDatPwrdbfs       = 0;
    UINT32 uiAauOrRruFlg    ;
    UINT32 uiBandWidth      ;
    UINT32 uiDataRate       ;
    UINT32 uiDataType       ;
    UINT32 uiTddOrFddFlg    ;
    UINT32 uislot           ;

    ///采数获取
    uiAauOrRruFlg = ptNrOrLteDataPara->uiAauOrRruFlg;
    uiBandWidth   = ptNrOrLteDataPara->uiBandWidth;
    uiDataRate    = ptNrOrLteDataPara->uiDataRate;
    uiDataType    = ptNrOrLteDataPara->uiDataType;
    uiTddOrFddFlg = ptNrOrLteDataPara->uiTddOrFddFlg;
    uislot        = ptNrOrLteDataPara->uislot ;

    //入参检查
    if(((SLOT_NUM-1)<uislot)||((DATA_MODE_NUM-1)<uiDataType))
    {
        dbgInfo("%s ParaMeter is error!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }

    //子载波间隔配置
    if((FDD_DATA_MODE == uiTddOrFddFlg)&&(AAU_DATA_MODE == uiAauOrRruFlg))
    {
        uiScs       = 0 ;
        iDatPwrdbfs = g_aiDataPwrType[uiDataType] ; //-14dbfs
    }
    else if((FDD_DATA_MODE == uiTddOrFddFlg)&&(RRU_DATA_MODE == uiAauOrRruFlg))
    {
        uiScs       = 0 ;
        iDatPwrdbfs = g_aiDataPwrType[uiDataType] + 1; //-13dbfs
    }
    else if((TDD_DATA_MODE == uiTddOrFddFlg)&&(AAU_DATA_MODE == uiAauOrRruFlg))
    {
        uiScs       = 1 ;
        iDatPwrdbfs = g_aiDataPwrType[uiDataType] ; //-14dbfs
    }
    else
    {
        uiScs       = 1 ;
        iDatPwrdbfs = g_aiDataPwrType[uiDataType] ; //-14dbfs
    }

    dbgInfo("%s uiScs is %u , iDatPwrdbfs is %d dbfs!\n", __FUNCTION__,uiScs,iDatPwrdbfs);

    //参数计算
    for(uiBandIndexLoop=0;uiBandIndexLoop<BAND_NUM;uiBandIndexLoop++)
    {
        if(uiBandWidth == g_aiBandIndex[uiBandIndexLoop])
        {
            uiBandIndex = uiBandIndexLoop ;
            break ;
        }
    }

    //有效点计算
    uiDataFftSizeTmp      = 256 * uiDataRate / 3840  ;
    uiSymbolLen           = uiDataFftSizeTmp / (uiScs + 1);
    uiValidScNum          = g_aiValidRbNum[uiScs][uiBandIndex] * 12;
    uiTm2RbPos            = uislot % TM2MODE_POS_NUM ;
    uiAdjPdschPos         = g_aiAdjPdschPos[uiDataType][uiTm2RbPos][uiScs][uiBandIndex] * 12 ;
    uiAdjPdschLen         = g_aiAdjPdschLen[uiDataType][uiScs][uiBandIndex] * 12 ;

    //赋值
    g_atCellInfoModuDatGen.tCellInfoCommon.uiScs               = uiScs      ; //子载波间隔 0表示15k子载波间隔 1表示30k子载波间隔
    g_atCellInfoModuDatGen.tNrorLteCellInfoCommon.iSetFixValue = iDatPwrdbfs; //定标功率
    g_atCellInfoModuDatGen.tCellInfoPdsch.uiModuleTypeSel      = g_aiQamType[uiDataType]  ; //0表示QAM64 1表示QAM256
    g_atCellInfoModuDatGen.tCellInfoDmrs.uiSlot                = uislot     ;//slot 号
    g_atCellInfoModuDatGen.tCellInfoDmrs.uiSymbolLen           = uiSymbolLen;
    g_atCellInfoModuDatGen.tCellInfoDmrs.uiValidScNum          = uiValidScNum;
    g_atCellInfoModuDatGen.tCellInfoDmrs.uiDmrsReStartPos      = (uiSymbolLen - uiValidScNum)/2 + uiAdjPdschPos - 1;
    g_atCellInfoModuDatGen.tCellInfoDmrs.uiDmrsReEndPos        = (uiSymbolLen - uiValidScNum)/2 + uiAdjPdschLen +  1;

    g_atCellInfoModuDatGen.tCellInfoPdcch.uiPdcchReLen         = 36 ;
    g_atCellInfoModuDatGen.tCellInfoPdcch.uiPdcchStartPos      = (uiSymbolLen - uiValidScNum)/2;
    g_atCellInfoModuDatGen.tCellInfoPdcch.uiPdcchSchReLen      = g_aiPdcchSchFill[uiDataType]*(uiValidScNum - g_atCellInfoModuDatGen.tCellInfoPdcch.uiPdcchReLen) ;
    g_atCellInfoModuDatGen.tCellInfoPdcch.uiPdcchFdmOnOrOff    = g_aiPdcchFdmOnOrOff ; //1表示fdmonOn 0表示fdmoff

    g_atCellInfoModuDatGen.tCellInfoPdsch.uiPdschStartPos      = (uiSymbolLen - uiValidScNum)/2 + uiAdjPdschPos;    ///pdsch的起始长度
    g_atCellInfoModuDatGen.tCellInfoPdsch.uiPdschReLen         = uiAdjPdschLen ;    ///pdsch的长度

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspNrEvmDatGenInitCfg
 * 功能描述: 初始化配置 支持手动配置
 * 输入参数: ptCellInfoModuDatGen - 入参初始化设置
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspNrEvmDatGenInitCfg(T_CellInfoModuDatGen *ptCellInfoModuDatGen)
{

    UINT32 uiScsVal                                        ;
    UINT64 uiCp0OrgCpLen                                   ;
    UINT64 uiCp1OrgCpLen                                   ;
    UINT32 uiScs                                           ;
    UINT32 i                                               ;
    UINT32 uiSymbolLen                                     ;
    UINT32 uiScsValCompare                                 ;

    //获取参数
    uiScs        = ptCellInfoModuDatGen->tCellInfoCommon.uiScs   ;
    uiSymbolLen  = ptCellInfoModuDatGen->tCellInfoDmrs.uiSymbolLen ;

    //参数计算
    uiScsVal = BspCal2power(uiScs);
    uiCp0OrgCpLen = (UINT64)((9216  / uiScsVal) + 16*64) * (15*uiScsVal) * uiSymbolLen / 1966080 ;
    uiCp1OrgCpLen = (UINT64)(9216  / uiScsVal) * (15*uiScsVal) * uiSymbolLen / 1966080 ;
    uiScsValCompare = 7*uiScsVal ;

    dbgInfoEx("%s uiScs = %d,uiScsVal = %d,uiScsValCompare = %d\n",__FUNCTION__,uiScs,uiScsVal,uiScsValCompare);

    //参数配置
    ptCellInfoModuDatGen->tNrorLteCellInfoCommon.iSignalWidthLen = g_aiDataWidth - 1 ; //默认信号为16bit有符号数据
    ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolNum       = 14 ; //符号个数
    ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolCp0Len    = uiCp0OrgCpLen ; //CP0
    ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolCp1Len    = uiCp1OrgCpLen ; //CP1
    for(i=0;i<ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolNum;i++)
    {
        if((0 == i)||(uiScsValCompare == i))
        {
            ptCellInfoModuDatGen->tCellInfoCommon.auiSymbolCpIndex[i] = 0; //CP0
        }
        else
        {
            ptCellInfoModuDatGen->tCellInfoCommon.auiSymbolCpIndex[i]   = 1 ; //CP1
        }

    }

    //Pdcch时域符号配置
    for(i=0;i<ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolNum;i++)
    {
        ptCellInfoModuDatGen->tCellInfoPdcch.uiaPdcchTimeSymbolValFlg[i] = 0;
    }
    for(i=0;i<g_uiPdcchSymbolNum;i++)
    {
        ptCellInfoModuDatGen->tCellInfoPdcch.uiaPdcchTimeSymbolValFlg[g_uiPdcchSymbolPos[i]] = 1;
    }

    //ifft 配置
    ptCellInfoModuDatGen->tFftPara.ifftsize = uiSymbolLen ;

    //DMRS 时域位置配置
    ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsMapType     = g_uiDmrsMapType;    ///DMRS时域 typeA
    ptCellInfoModuDatGen->tCellInfoDmrs.uiLimits          = g_uiLimits;         //DMRS的单符号
    ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsAddPos      = g_uiDmrsAddPos;     ///DMRS符号增加的位置
    ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsFirstPos    = g_uiDmrsFirstPos;   ///DMRS 第一个符号位置
    ptCellInfoModuDatGen->tCellInfoDmrs.uiPdschLength     = 14;   ///PdschLen
    ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsLdLength    = 14;   ///DmrsLdLength
    ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsNum         = g_uiDmrsNum;        //DMRS 符号个数
    ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsAddPdschFlg = g_uiDmrsAddPdschFlg; //填充

    //DMRS 频域位置生成配置
    ptCellInfoModuDatGen->tCellInfoDmrs.uiCellId          = g_uiCellId;   ///DMRS的cellid
    ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsType        = g_uiDmrsType;   ///DMRS的TypeA
    ptCellInfoModuDatGen->tCellInfoDmrs.uiPortId          = g_uiPortId;   ///DMRS的PortId
    ptCellInfoModuDatGen->tCellInfoDmrs.uiScId            = g_uiScId;   ///DMRS的Scid
    ptCellInfoModuDatGen->tCellInfoDmrs.iScaleTmp         = 1;          ///DMRS的幅度

    ///tNrorLteCellInfoCommon
    ptCellInfoModuDatGen->tNrorLteCellInfoCommon.uiSymbolCp0Len = uiCp0OrgCpLen;
    ptCellInfoModuDatGen->tNrorLteCellInfoCommon.uiSymbolCp1Len = uiCp1OrgCpLen;
    ptCellInfoModuDatGen->tNrorLteCellInfoCommon.uiSymbolLen    = uiSymbolLen ;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspSetRandomPara
 * 功能描述: 生成随机数据的种子设置
 * 输入参数: uiRandPara - 种子设置
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSetRandomPara(UINT32 uiRandPara)
{
    g_uiRandPara  = uiRandPara ;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGenRandomData
 * 功能描述: 生成随机数据
 * 输入参数: uiRandomDatLen - 数据长度
 * 输出参数:piRandoDmataOut -生成的随机数据
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenRandomData(UINT32 uiRandomDatLen,INT32 *piRandomDataOut)
{
    UINT32 i           ;

    srand(g_uiRandPara);
    dbgInfoEx("%s g_uiRandPara = %d\n", __FUNCTION__,g_uiRandPara);

    for (i = 0; i < uiRandomDatLen; i++)
    {
        piRandomDataOut[i] = rand();
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspQPSKGen
 * 功能描述: QPSK 调制
 * 输入参数: piOrgData - 随机数据
            uiOrgDataLen -  数据长度
 * 输出参数:pfModulRealData -频域数据实部
            pfModulImagData - 频域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspQPSKGen(INT32 *piOrgData,UINT32 uiOrgDataLen,FLOAT *pfModulRealData,FLOAT *pfModulImagData)
{

    FLOAT       fQpskCoef = 0.0;
    UINT32      uiDataLoop = 0;

    //QPSK系数
    fQpskCoef = (FLOAT)(1/sqrt(2)) ;

    //根据协议生成调制的QPSK数据
    for(uiDataLoop = 0;uiDataLoop<uiOrgDataLen;uiDataLoop++)
    {
        pfModulRealData[uiDataLoop] = fQpskCoef * (1 - 2*((piOrgData[uiDataLoop] >> 0)  & 0x1)) ;
        pfModulImagData[uiDataLoop] = fQpskCoef * (1 - 2*((piOrgData[uiDataLoop] >> 1)  & 0x1)) ;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspQAM64Gen
 * 功能描述: QAM64 调制
 * 输入参数: piOrgData - 随机数据
            uiOrgDataLen -  数据长度
 * 输出参数:pfModulRealData -频域数据实部
            pfModulImagData - 频域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspQAM64Gen(INT32 *piOrgData,UINT32 uiOrgDataLen,FLOAT *pfModulRealData,FLOAT *pfModulImagData)
{

    FLOAT       fQam64Coef = 0.0;
    UINT32      uiDataLoop = 0;

    //QAM64系数
    fQam64Coef = (FLOAT)(1/sqrt(42)) ;

    //根据协议生成调制的QAM64数据
    for(uiDataLoop = 0;uiDataLoop<uiOrgDataLen;uiDataLoop++)
    {
        pfModulRealData[uiDataLoop] = fQam64Coef * (1 - 2*((piOrgData[uiDataLoop] >> 0)  & 0x1)) * (4 - (1 - 2*((piOrgData[uiDataLoop] >> 2) & 0x1)) * (2 - (1 - 2*((piOrgData[uiDataLoop] >> 4) & 0x1))));
        pfModulImagData[uiDataLoop] = fQam64Coef * (1 - 2*((piOrgData[uiDataLoop] >> 1)  & 0x1)) * (4 - (1 - 2*((piOrgData[uiDataLoop] >> 3) & 0x1)) * (2 - (1 - 2*((piOrgData[uiDataLoop] >> 5) & 0x1))));
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspQAM256Gen
 * 功能描述: QAM256 调制
 * 输入参数: piOrgData - 随机数据
            uiOrgDataLen -  数据长度
 * 输出参数:pfModulRealData -频域数据实部
            pfModulImagData - 频域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspQAM256Gen(INT32 *piOrgData,UINT32 uiOrgDataLen,FLOAT *pfModulRealData,FLOAT *pfModulImagData)
{

    FLOAT       fQam256Coef = 0.0;
    UINT32      uiDataLoop  = 0;

    //QAM64系数
    fQam256Coef = (FLOAT)(1/sqrt(170)) ;

    for(uiDataLoop = 0;uiDataLoop<uiOrgDataLen;uiDataLoop++)
    {
        pfModulRealData[uiDataLoop] = fQam256Coef * (1 - 2*((piOrgData[uiDataLoop] >> 0)  & 0x1)) * (8 - (1 - 2*((piOrgData[uiDataLoop] >> 2) & 0x1)) * (4 - (1 - 2*((piOrgData[uiDataLoop] >> 4) & 0x1)) * (2 - (1 - 2*((piOrgData[uiDataLoop] >> 6) & 0x1)))));
        pfModulImagData[uiDataLoop] = fQam256Coef * (1 - 2*((piOrgData[uiDataLoop] >> 1)  & 0x1)) * (8 - (1 - 2*((piOrgData[uiDataLoop] >> 3) & 0x1)) * (4 - (1 - 2*((piOrgData[uiDataLoop] >> 5) & 0x1)) * (2 - (1 - 2*((piOrgData[uiDataLoop] >> 7) & 0x1)))));
    }

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspGetDmrsTimePos
 * 功能描述: 根据配置生成DMRS的时域位置
 * 输入参数: ptCellInfoModuDatGen - 计算参数入参
 * 输出参数:ptCellInfoModuDatGen - 计算参数入参
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void BspGetDmrsTimePos(T_CellInfoModuDatGen *ptCellInfoModuDatGen)
{
    UINT32 index                 ;
    UINT32 uiDmrsMapType         ; //DMRS的TypeA、B
    UINT32 uiLimits              ; //DMRS的单双符号
    UINT32 uiDmrsAddPos          ; //DMRS符号增加的位置
    UINT32 uiDmrsFirstPos        ; //DMRS 第一个符号位置
    UINT32 uiPdschLength         ; //PdschLen
    UINT32 uiDmrsLdLength        ; //DMRS TypeB的长度
    UINT32 uiDmrsNum             ; //DMRS 符号个数
    UINT32 auiDmrsPos[4] = {0}   ; //DMRS 位置
    UINT32 uiSymbolNum           ; ///符号个数

    //参数获取
    uiDmrsMapType   = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsMapType;
    uiLimits        = ptCellInfoModuDatGen->tCellInfoDmrs.uiLimits;
    uiDmrsAddPos    = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsAddPos;
    uiDmrsFirstPos  = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsFirstPos;
    uiPdschLength   = ptCellInfoModuDatGen->tCellInfoDmrs.uiPdschLength;
    uiDmrsLdLength  = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsLdLength;
    uiDmrsNum       = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsNum;
    uiSymbolNum     = ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolNum;
    dbgInfoEx("%s uiDmrsMapType = %d,uiLimits = %d,uiDmrsAddPos = %d,uiDmrsFirstPos = %d,uiPdschLength = %d,uiDmrsLdLength = %d,uiDmrsNum = %d,uiSymbolNum = %d,\n", __FUNCTION__,\
            uiDmrsMapType,uiLimits,uiDmrsAddPos,uiDmrsFirstPos,uiPdschLength,uiDmrsLdLength,uiDmrsNum,uiSymbolNum);

    //cov 告警
    if(0 == uiLimits)
    {
        if((TYPEA_SINGLE_NUM <= uiDmrsAddPos)||(TYPEB_SINGLE_NUM <= uiDmrsAddPos))
        {
            return ;
        }
    }
    if(1 == uiLimits)
    {
        if((TYPEA_DOUBLE_NUM <= uiDmrsAddPos)||(TYPEB_DOUBLE_NUM <= uiDmrsAddPos))
        {
            return ;
        }
    }


    if(0 == uiDmrsMapType)      //判断TypeA、B,TypeA
    {
        if(0 == uiLimits)           //判断单双符号
        {
            auiDmrsPos[0] = uiDmrsFirstPos;

            for(index = 1; index < uiDmrsNum; index++)
            {
                auiDmrsPos[index] = typeA_LbarofSingleDmrsAdd[uiDmrsAddPos][index][uiPdschLength-1];
            }
        }

        else if(1 == uiLimits)
        {
            auiDmrsPos[0] = uiDmrsFirstPos;
            auiDmrsPos[1] = uiDmrsFirstPos + uiLimits;
            for(index = 1; index < (INT32)uiDmrsNum/2; index++)
            {
                auiDmrsPos[index+1] = typeA_LbarofDoubleDmrsAdd[uiDmrsAddPos][index][uiPdschLength-1];
                auiDmrsPos[index+2] = auiDmrsPos[index+1] + uiLimits;
            }
        }

    }
    else   //typeB
    {
        if(0 == uiLimits)           //判断单双符号
        {
            auiDmrsPos[0] = uiDmrsFirstPos;

            for(index = 1; index < uiDmrsNum; index++)
            {
                auiDmrsPos[index] = typeB_LbarofSingleDmrsAdd[uiDmrsAddPos][index][uiDmrsLdLength-1];
            }
        }

        else if(1 == uiLimits)
        {
            auiDmrsPos[0] = uiDmrsFirstPos;
            auiDmrsPos[1] = uiDmrsFirstPos + uiLimits;
            for(index = 1; index < (INT32)uiDmrsNum/2; index++)
            {
                auiDmrsPos[index+1] = typeB_LbarofDoubleDmrsAdd[uiDmrsAddPos][index][uiDmrsLdLength-1];
                auiDmrsPos[index+2] = auiDmrsPos[index+1] + uiLimits;
            }
        }

    }

    ///先全部刷为无效
    for(index = 0; index < uiSymbolNum; index++)
    {
        ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsPosSymbolValFlg[index] = 0;
    }

    ///有效位置记录为1
    for(index = 0; index < uiDmrsNum; index++)
    {
        ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsPosSymbolValFlg[auiDmrsPos[index]] = 1;
        dbgInfoEx("%s index = %d,pos = %d\n", __FUNCTION__,index,auiDmrsPos[index]);
    }
}
/**************************************************************************
 * 函数名称: BspEvmGenerateDmrsSymb
 * 功能描述: 生成频域DMRS源
 * 输入参数: ptCellInfoModuDatGen - 计算参数入参
 * 输出参数:pxfDmrsSymbFreqReal -频域数据实部
            pxfDmrsSymbFreqImag - 频域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void BspEvmGenerateDmrsSymb(T_CellInfoModuDatGen *ptCellInfoModuDatGen,FLOAT *pxfDmrsSymbFreqReal,FLOAT *pxfDmrsSymbFreqImag)
{
    UINT32  uiCinit1=1;
    UINT32  uiCinit2;
    UINT32  uiCinit2_Var;
    UINT32  i;
    UINT32  uiMpn;
    UINT32  uijIdx;
    UINT32  uiKstart;
    INT32   iWttmp;
    INT32   iWftmp;
    UINT32 uiCellId     ;
    UINT32 uiDmrsType   ;
    UINT32 uiSymbolLen  ;
    UINT32 uiPortId     ;
    UINT32 uifreqStep   ;
    UINT32 uiSlot       ;
    UINT32 uisymb       ;
    UINT32 uiLimits     ;
    UINT32 uiScId       ;
    UINT32 uiValidScNum ;
    INT32  iScaleTmp    ;
    UINT32  *puiX1nDat   =NULL;
    UINT32  *puiX2nDat   =NULL;
    INT32   *piCnDat     =NULL;
    FLOAT   *pxfRnDatReal=NULL;
    FLOAT   *pxfRnDatImag=NULL;
    UINT32 uiDmrsReEndPos        ;
    UINT32 uiDmrsReStartPos      ;

    //参数获取
    uiCellId     = ptCellInfoModuDatGen->tCellInfoDmrs.uiCellId;
    uiDmrsType   = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsType;
    uiSymbolLen  = ptCellInfoModuDatGen->tCellInfoDmrs.uiSymbolLen;
    uiPortId     = ptCellInfoModuDatGen->tCellInfoDmrs.uiPortId;
    uiSlot       = ptCellInfoModuDatGen->tCellInfoDmrs.uiSlot;
    uisymb       = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsPos;
    uiLimits     = ptCellInfoModuDatGen->tCellInfoDmrs.uiLimits;
    uiScId       = ptCellInfoModuDatGen->tCellInfoDmrs.uiScId;
    uiValidScNum = ptCellInfoModuDatGen->tCellInfoDmrs.uiValidScNum;
    iScaleTmp    = ptCellInfoModuDatGen->tCellInfoDmrs.iScaleTmp;
    uiDmrsReStartPos = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsReStartPos;
    uiDmrsReEndPos = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsReEndPos;

    ///参数检查
    if((TYPE1WT_L_NUM <= uiLimits)||(TYPE1_PORT_NUM <= uiPortId)||(NULL == pxfDmrsSymbFreqReal)||(NULL == pxfDmrsSymbFreqImag))
    {
        return ;
    }

    //uifreqStep 生成
    if(uiDmrsType == 0)
    {
        uifreqStep = 4;
    }
    else if(uiDmrsType == 1)
    {
        uifreqStep = 6;
    }
    else
    {
        uifreqStep = 4;
    }

    uiMpn = uiValidScNum/uifreqStep*2*2;

    puiX1nDat      = (UINT32 *)malloc(sizeof(UINT32)*(uiMpn + 1600));
    if(NULL == puiX1nDat)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }
    puiX2nDat      = (UINT32 *)malloc(sizeof(UINT32)*(uiMpn + 1600));
    if(NULL == puiX2nDat)
    {
        free(puiX1nDat);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }
    piCnDat        = (INT32  *)malloc(sizeof(INT32)*uiMpn);
    if(NULL == piCnDat)
    {
        free(puiX1nDat);
        free(puiX2nDat);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }
    pxfRnDatReal   = (FLOAT  *)malloc(sizeof(FLOAT)*uiMpn/2);
    if(NULL == pxfRnDatReal)
    {
        free(puiX1nDat);
        free(puiX2nDat);
        free(piCnDat);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }
    pxfRnDatImag   = (FLOAT  *)malloc(sizeof(FLOAT)*uiMpn/2);
    if(NULL == pxfRnDatImag)
    {
        free(puiX1nDat);
        free(puiX2nDat);
        free(piCnDat);
        free(pxfRnDatReal);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }

    memset(pxfRnDatReal,0x0,sizeof(FLOAT)*uiMpn/2);
    memset(pxfRnDatImag,0x0,sizeof(FLOAT)*uiMpn/2);

    uiCinit2_Var =  131072*(uiSlot*14+uisymb+1)*(2*uiCellId+1)+2*uiCellId+uiScId;
    uiCinit2     =  uiCinit2_Var % 2147483648;

    for(i = 0; i < 31; i++)
    {
        puiX1nDat[i] = (uiCinit1>>i)&0x01;
        puiX2nDat[i] = (uiCinit2>>i)&0x01;
    }
    for(i = 31; i < (uiMpn+1600); i++)
    {
        puiX1nDat[i]  = (puiX1nDat[i-28] + puiX1nDat[i-31])%2;
        puiX2nDat[i]  = (puiX2nDat[i-28] + puiX2nDat[i-29] + puiX2nDat[i-30] + puiX2nDat[i-31])%2;
    }

    for(i = 0; i < uiMpn; i++)
    {
        piCnDat[i] = (puiX1nDat[i+1600] + puiX2nDat[i+1600])%2;
    }

    for(i = 0; i < uiMpn/2; i++)
    {
        pxfRnDatReal[i] = ((FLOAT)(1/sqrt(2)))*(1-2*piCnDat[2*i]);
        pxfRnDatImag[i] = ((FLOAT)(1/sqrt(2)))*(1-2*piCnDat[2*i+1]);
    }

    if(uiDmrsType==0)
    {
        iWttmp = type1_Wt[uiLimits][uiPortId];
    }
    else if(uiDmrsType==1)
    {
        iWttmp = type2_Wt[uiLimits][uiPortId];
    }
    else
    {
        free(puiX1nDat);
        free(puiX2nDat);
        free(piCnDat);
        free(pxfRnDatReal);
        free(pxfRnDatImag);
        return ;
    }
    for(uijIdx = 0;uijIdx < 2; uijIdx++)
    {

        if(uiDmrsType==0)
        {
            iWftmp   = type1_Wf[uijIdx][uiPortId];
            uiKstart = 2*uijIdx+type1_delta[uiPortId]+uiSymbolLen/2-uiValidScNum/2;
        }
        else if(uiDmrsType==1)
        {
            iWftmp   = type2_Wf[uijIdx][uiPortId];
            uiKstart = uijIdx+type2_delta[uiPortId]+uiSymbolLen/2-uiValidScNum/2;
        }
        else
        {
            free(puiX1nDat);
            free(puiX2nDat);
            free(piCnDat);
            free(pxfRnDatReal);
            free(pxfRnDatImag);
            return ;
        }

        for(i=uiKstart; i<(uiKstart+uiValidScNum); i=i+uifreqStep)
        {
            if((i>uiDmrsReStartPos)&&(i<uiDmrsReEndPos))
            {
                pxfDmrsSymbFreqReal[i] = iScaleTmp*iWftmp*iWttmp*pxfRnDatReal[2*(i-uiKstart)/uifreqStep+uijIdx];
                pxfDmrsSymbFreqImag[i] = iScaleTmp*iWftmp*iWttmp*pxfRnDatImag[2*(i-uiKstart)/uifreqStep+uijIdx];
            }
        }

    }

    free(puiX1nDat);
    free(puiX2nDat);
    free(piCnDat);
    free(pxfRnDatReal);
    free(pxfRnDatImag);
}

/**************************************************************************
 * 函数名称: BspGenSymbolFreqData
 * 功能描述: 生成符号级频域数据
 * 输入参数: ptCellInfoModuDatGen - 计算参数入参
             uiSymbolIndex - 符号指示
             puiOrgRandomData - 生成的随机数据
 * 输出参数:pfFreqDataReal -频域数据实部
            pfFreqDataImag - 频域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenSymbolFreqData(T_CellInfoModuDatGen *ptCellInfoModuDatGen,UINT32 uiSymbolIndex,INT32 *puiOrgRandomData,FLOAT *pfFreqDataReal,FLOAT *pfFreqDataImag)
{
    UINT32 uiSymbolLen               ;
    UINT32 uiValidScNum              ;
    UINT32 uiPdcchReLen              ;
    UINT32 uiPdcchTimeSymbolValFlg   ;
    UINT32 uiPdcchStartPos           ;
    UINT32 uiPdcchSchReLen           ;
    UINT32 uiDmrsPosSymbolValFlg     ;
    UINT32 uiDmrsAddPdschFlg         ;
    UINT32 uiModuleTypeSel           ;
    UINT32 uiPdschStartPos           ;
    UINT32 uiPdschReLen              ;
    UINT32 uiPdcchFdmOnOrOff         ;

    if(TYPEA_SINGLE_SYMBOLS_NUM <= uiSymbolIndex)
    {
        return BSP_ERROR;
    }

    ///参数获取
    uiSymbolLen              = ptCellInfoModuDatGen->tCellInfoDmrs.uiSymbolLen;
    uiValidScNum             = ptCellInfoModuDatGen->tCellInfoDmrs.uiValidScNum;
    uiPdcchStartPos          = ptCellInfoModuDatGen->tCellInfoPdcch.uiPdcchStartPos       ;
    uiPdcchReLen             = ptCellInfoModuDatGen->tCellInfoPdcch.uiPdcchReLen      ;
    uiPdcchSchReLen          = ptCellInfoModuDatGen->tCellInfoPdcch.uiPdcchSchReLen      ;
    uiPdcchTimeSymbolValFlg  = ptCellInfoModuDatGen->tCellInfoPdcch.uiaPdcchTimeSymbolValFlg[uiSymbolIndex]      ;
    uiPdcchFdmOnOrOff        = ptCellInfoModuDatGen->tCellInfoPdcch.uiPdcchFdmOnOrOff;
    uiDmrsPosSymbolValFlg    = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsPosSymbolValFlg[uiSymbolIndex];
    uiDmrsAddPdschFlg        = ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsAddPdschFlg ;  ///判断是否插花
    uiModuleTypeSel          = ptCellInfoModuDatGen->tCellInfoPdsch.uiModuleTypeSel ;    ///判断是否插花
    uiPdschStartPos          = ptCellInfoModuDatGen->tCellInfoPdsch.uiPdschStartPos ;    ///pdsch的起始长度
    uiPdschReLen             = ptCellInfoModuDatGen->tCellInfoPdsch.uiPdschReLen ;    ///pdsch的长度

    dbgInfoEx("%s uiSymbolLen = %d,uiValidScNum = %d,uiPdcchStartPos = %d,uiPdcchReLen = %d,uiPdcchSchReLen = %d,uiPdcchTimeSymbolValFlg = %d,uiDmrsPosSymbolValFlg = %d,uiDmrsAddPdschFlg = %d,uiModuleTypeSel = %d,uiPdschStartPos = %d,uiPdschReLen = %d,uiPdcchFdmOnOrOff = %d\n", __FUNCTION__,\
            uiSymbolLen,uiValidScNum,uiPdcchStartPos,uiPdcchReLen,uiPdcchSchReLen,uiPdcchTimeSymbolValFlg,uiDmrsPosSymbolValFlg,uiDmrsAddPdschFlg,uiModuleTypeSel,uiPdschStartPos,uiPdschReLen,uiPdcchFdmOnOrOff);

    if((EVM_MODULE_NUM <= uiModuleTypeSel)||(uiSymbolLen <= uiPdcchStartPos)||(uiSymbolLen <= uiPdschStartPos))
    {
        return BSP_ERROR;
    }

    //pdcch&&pdsch
    if(1 == uiPdcchTimeSymbolValFlg)
    {
        //PDCCH 调制
        BspQPSKGen(&puiOrgRandomData[uiSymbolIndex*uiValidScNum],uiPdcchReLen,&pfFreqDataReal[uiPdcchStartPos],&pfFreqDataImag[uiPdcchStartPos]);
        if(1 == uiPdcchFdmOnOrOff) //fdmon
        {
            //Pdsch
            BspQamGen[uiModuleTypeSel](&puiOrgRandomData[uiSymbolIndex*uiValidScNum+uiPdcchReLen],uiPdcchSchReLen,&pfFreqDataReal[uiPdcchStartPos+uiPdcchReLen],&pfFreqDataImag[uiPdcchStartPos+uiPdcchReLen]);
        }
    }
    //dmrs&&pdsch
    else if(1 == uiDmrsPosSymbolValFlg)
    {
        if(1 == uiDmrsAddPdschFlg)///dmrs 是否插花
        {
            BspQamGen[uiModuleTypeSel](&puiOrgRandomData[uiSymbolIndex*uiValidScNum],uiPdschReLen,&pfFreqDataReal[uiPdschStartPos],&pfFreqDataImag[uiPdschStartPos]);
        }
        ptCellInfoModuDatGen->tCellInfoDmrs.uiDmrsPos = uiSymbolIndex ;
        BspEvmGenerateDmrsSymb(ptCellInfoModuDatGen,pfFreqDataReal,pfFreqDataImag);
    }
    //pdsch
    else
    {
        BspQamGen[uiModuleTypeSel](&puiOrgRandomData[uiSymbolIndex*uiValidScNum],uiPdschReLen,&pfFreqDataReal[uiPdschStartPos],&pfFreqDataImag[uiPdschStartPos]);
    }

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspFftShift
 * 功能描述: FFTSHIFT函数
 * 输入参数: pxfDataInReal - 频域数据实部
             pxfDataInReal - 频域数据虚部
             iDatLen - 数据长度
 * 输出参数:pxfDataOutReal -频域数据实部
            pxfDataOutImag - 频域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void BspFftShift(FLOAT *pxfDataInReal,FLOAT *pxfDataInImag,FLOAT *pxfDataOutReal,FLOAT *pxfDataOutImag,INT32 iDatLen)
{
    FLOAT xfDatLeftReal;
    FLOAT xfDatLeftImag;
    FLOAT xfDatRightReal;
    FLOAT xfDatRightImag;
    FLOAT xfDatMidReal;
    FLOAT xfDatMidImag;
    INT32 i;

    for (i=0; i<iDatLen/2; i++)
    {
        xfDatLeftReal = pxfDataInReal[i];
        xfDatLeftImag = pxfDataInImag[i];
        xfDatRightReal = pxfDataInReal[i + (iDatLen/2)];
        xfDatRightImag = pxfDataInImag[i + (iDatLen/2)];

        xfDatMidReal = xfDatLeftReal;
        xfDatLeftReal = xfDatRightReal;
        xfDatRightReal = xfDatMidReal;

        xfDatMidImag = xfDatLeftImag;
        xfDatLeftImag = xfDatRightImag;
        xfDatRightImag = xfDatMidImag;

        pxfDataOutReal[i] = xfDatLeftReal;
        pxfDataOutReal[i + (iDatLen/2)]= xfDatRightReal;
        pxfDataOutImag[i] = xfDatLeftImag;
        pxfDataOutImag[i + (iDatLen/2)]= xfDatRightImag;
    }
}

/**************************************************************************
 * 函数名称: AdvPfftTran
 * 功能描述: IFFT 参数计算
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void AdvPfftTran(T_AdvPfftTranPara *ptAdvPfftTranPara)
{
    INT32 m,n,l,k,i,j,g,h,p;
    INT32 ndft_iq;
    INT32 ngrp,nbtf,nlen,nwk;
    FLOAT ftemp0,ftemp1,ftemp2,ftemp3;
    INT32 npfft = 0;
    INT32 Nfft;
    INT32 mbtf;
    INT32 ndft;
    INT32 iIfftFlg;
    FLOAT *ptr_x;
    FLOAT *ptr_w;
    FLOAT *ptr_w_dft;
    INT32 *pIdx;
    FLOAT *ptr_y;

    //参数获取
    Nfft = ptAdvPfftTranPara->Nfft;
    iIfftFlg = ptAdvPfftTranPara->iIfftFlg;
    mbtf = ptAdvPfftTranPara->mbtf;
    ndft = ptAdvPfftTranPara->ndft;
    pIdx = ptAdvPfftTranPara->pIdx;
    ptr_w = ptAdvPfftTranPara->ptr_w;
    ptr_w_dft = ptAdvPfftTranPara->ptr_w_dft;
    ptr_x = ptAdvPfftTranPara->ptr_x;
    ptr_y = ptAdvPfftTranPara->ptr_y;

    //DFT
    if(0 != ndft)
    {
        npfft = Nfft/ndft;
    }
    nlen = Nfft<<1;
    ndft_iq = ndft<<1;

    for(m=0; m<nlen; m++)
    {
        ptr_y[m] = ptr_x[pIdx[m]];
    }

    memset(ptr_x, 0x00, 2*Nfft*sizeof(FLOAT));

    m = 0;
    for(n=0; n<npfft; n++)
    {
        g = 0;
        for(k=0; k<ndft; k++)//X(k)
        {
            i = k<<1;
            for(l=0; l<ndft; l++)
            {
                j = l<<1;
                ptr_x[m+i] += ptr_y[m+j]*ptr_w_dft[g+j]-ptr_y[m+j+1]*ptr_w_dft[g+j+1];//I
                ptr_x[m+i+1] += ptr_y[m+j]*ptr_w_dft[g+j+1] + ptr_y[m+j+1]*ptr_w_dft[g+j];//Q
            }
            g += ndft_iq;
        }
        m += ndft_iq;
    }

    //FFT
    for(m=0; m<mbtf; m++)
    {
        ngrp = npfft>>(m+1);//蝶形组数
        nbtf = ndft<<(m+1);//每组蝶形长度
        nwk = ngrp<<1;//Wnk查表间隔,IQ交错*2
        h = 0;
        i = 0;
        j = nbtf>>1;
        for(n=0; n<ngrp; n++)
        {
            k = 0;
            for(l=i; l<j; l++)
            {
                g = (l-i)<<1;
                h = nbtf+g+i;
                p = g+i;
                if((p<DATA_FFT_LEN_MAX)&&(k<DATA_FFT_LEN_MAX)&&(h<DATA_FFT_LEN_MAX))
                {
                    ftemp0 = ptr_x[p];//XI
                    ftemp1 = ptr_x[p+1];//XQ
                    ftemp2 = ptr_x[h]*ptr_w[k] - ptr_x[h+1]*ptr_w[k+1];//X*Wk_I
                    ftemp3 = ptr_x[h]*ptr_w[k+1] + ptr_x[h+1]*ptr_w[k];//X*Wk_Q
                    ptr_x[p] = ftemp0 + ftemp2;
                    ptr_x[p+1] = ftemp1 + ftemp3;
                    ptr_x[h] = ftemp0 - ftemp2;
                    ptr_x[h+1] = ftemp1 - ftemp3;
                    k += nwk;
                }

            }
            i += nbtf<<1;
            j += nbtf<<1;
        }
    }

    if(1 == iIfftFlg)
    {
        for(l=0; l<Nfft; l++)
        {
            ptr_x[l] /= Nfft;
            ptr_x[Nfft+l] /= Nfft;
        }
    }
    zte_memcpy_s(ptr_y,2*Nfft*sizeof(FLOAT),ptr_x,2*Nfft*sizeof(FLOAT));

}

/**************************************************************************
 * 函数名称: AdvAcPifftTran
 * 功能描述: IFFT 封装
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void AdvAcPifftTran(FLOAT *ptr_x,T_FftPara *ptFftPara,FLOAT *ptr_y)
{
    T_AdvPfftTranPara tAdvPfftTranPara;

    tAdvPfftTranPara.Nfft = ptFftPara->ifftsize ;
    tAdvPfftTranPara.mbtf = ptFftPara->ibtfnum ;
    tAdvPfftTranPara.ndft = ptFftPara->idftsize ;
    tAdvPfftTranPara.iIfftFlg = 1;
    tAdvPfftTranPara.ptr_x = ptr_x ;
    tAdvPfftTranPara.ptr_w = ptFftPara->pftrW ;
    tAdvPfftTranPara.ptr_w_dft = ptFftPara->pfdftW ;
    tAdvPfftTranPara.pIdx  = ptFftPara->pidftidx ;
    tAdvPfftTranPara.ptr_y = ptr_y ;

    AdvPfftTran(&tAdvPfftTranPara);
}

/**************************************************************************
 * 函数名称: AdvPFftWkGen
 * 功能描述: IFFT 参数生成
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void AdvPFftWkGen(FLOAT *w, INT32 Nfft, INT32 iMode, INT32 iIfftFlg)
{
    INT32 i,j,k,h;
    FLOAT theta0,temp0;

    temp0 = (FLOAT)(-2.0*PI);
    if(0 == iMode)//Wk,fft
    {
        if(0 == iIfftFlg)
        {
            k = 0;
            for (j=0; j < Nfft; j++)
            {
                theta0 = (FLOAT)((double)temp0*(double)j/(double)Nfft);
                if(k < DATA_FFT_LEN_MAX)
                {
                    w[k] = (FLOAT)cosf(theta0);
                    w[k+1] = (FLOAT)sinf(theta0);
                }
                k += 2;
            }
        }
        else
        {
            k = 0;
            for (j=0; j < Nfft; j++)
            {
                theta0 = (FLOAT)((double)temp0*(double)j/(double)Nfft);
                if(k < DATA_FFT_LEN_MAX)
                {
                    w[k] = (FLOAT)cosf(theta0);
                    w[k+1] = (FLOAT)sinf(-theta0);
                }
                k += 2;
            }
        }

    }
    else//Wnk,dft
    {
        if(0 == iIfftFlg)
        {
            h = 0;
            for (i=0; i < Nfft; i++)
            {
                k = 0;
                for (j=0; j < Nfft; j++)
                {
                    theta0 = (FLOAT)((double)temp0*(double)(i*j)/(double)Nfft);
                    w[h+k] = (FLOAT)cosf(theta0);
                    w[h+k+1] = (FLOAT)sinf(theta0);
                    k += 2;
                }
                h += Nfft<<1;//IQ*2
            }
        }
        else
        {
            h = 0;
            for (i=0; i < Nfft; i++)
            {
                k = 0;
                for (j=0; j < Nfft; j++)
                {
                    theta0 = (FLOAT)((double)temp0*(double)(i*j)/(double)Nfft);
                    w[h+k] = (FLOAT)cosf(theta0);
                    w[h+k+1] = (FLOAT)sinf(-theta0);
                    k += 2;
                }
                h += Nfft<<1;//IQ*2
            }
        }
    }
}

/**************************************************************************
 * 函数名称: AdvPfftLenCalc
 * 功能描述: IFFT 参数生成
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void AdvPfftLenCalc(INT32 N, INT32 *mbtf, INT32 *ndft, INT32 *iMode)
{
    INT32 m,n,k;

    if( 0 == (N & (N-1)) )
    {
        *iMode = 0;//FFT
        *mbtf = (INT32)log2f(N);
        *ndft = 2;
    }
    else
    {
        *iMode = 1;//PFFT(DFT+FFT)
        m = (INT32)floorf(log2f(N));
        k = 1;
        n = 1;
        while(k != 0)
        {
            m--;
            n = (INT32)powf(2, m);
            k = N % n;
        }
        *ndft = (INT32)((FLOAT)(N) / (FLOAT)(n));
        *mbtf = m;
    }

}

/**************************************************************************
 * 函数名称: AdvPfftIdxCalc
 * 功能描述: IFFT 参数生成
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void AdvPfftIdxCalc(INT32 fftSize, INT32 mbtf, INT32 *pfftIdx)
{
    INT32 m,n,l,i,j,k,h,g,is;
    INT32 nlen = 0;
    INT32 *piTemp;

    piTemp = (INT32 *)malloc(sizeof(INT32)*(fftSize));

    if(NULL == piTemp)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }

    memset(&piTemp[0],0x0,sizeof(INT32)*(fftSize));

    for(n=0;n<fftSize;n++)
    {
        pfftIdx[n] = n;
    }
    for(m=0; m<mbtf; m++)
    {
        l = 2<<(m);//蝶形组数
        nlen = fftSize>>(m+1); //组内长度
        is = 0;//奇偶标志
        for(n=0; n<l; n++)
        {
            i = 0;
            k = (INT32)floorf(n>>1);
            h = n*nlen;
            g = k*(nlen<<1);
            for(j=0;j<nlen;j++)
            {
                piTemp[h+j] = pfftIdx[is+g+i];
                //printf("Main:m -- %2d, n -- %2d, j -- %2d, k -- %2d, idxout -- %3d, idx -- %3d, Out -- %3d.\n",m,n,j,k,n*nlen+j,i+is+k*nlen,iTemp[n*nlen+j]);
                i = i+2;
            }
            is = (is+1)%2;
        }
        zte_memcpy_s(pfftIdx, fftSize*sizeof(INT32),&piTemp[0], fftSize*sizeof(INT32));
    }
    //IQ交错索引
    for(n=0;n<fftSize;n++)
    {
        i = n<<1;
        j = piTemp[n]<<1;
        if(i < DATA_FFT_LEN_MAX)
        {
            pfftIdx[i] = j;
            pfftIdx[i+1] = j+1;
        }
    }

    free(piTemp) ;
}

/**************************************************************************
 * 函数名称: AdvPFftParaCalc
 * 功能描述: IFFT 参数生成
 * 输入参数:ptFftPara - IFFT计算参数
 * 输出参数: ptFftPara - IFFT计算参数
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
void AdvPFftParaCalc(T_FftPara *ptFftPara)
{
    AdvPfftLenCalc(ptFftPara->ifftsize, &ptFftPara->ibtfnum, &ptFftPara->idftsize, &ptFftPara->iMode);
    AdvPfftIdxCalc(ptFftPara->ifftsize, ptFftPara->ibtfnum, ptFftPara->pidftidx);
    AdvPFftWkGen(ptFftPara->pftrW, ptFftPara->ifftsize, 0, ptFftPara->ifftflag);
    AdvPFftWkGen(ptFftPara->pfdftW, ptFftPara->idftsize, 1, ptFftPara->ifftflag); //0:FFT;1:IFFT
}

/**************************************************************************
 * 函数名称: BspFreqDataToTimeData
 * 功能描述: 生成符号级时域数据
 * 输入参数:ptCellInfoModuDatGen - 计算参数
            pfFreqDataReal - 频域数据实部
            pfFreqDataImag - 频域数据虚部
 * 输出参数: pfOrgTimeDataReal - 时域数据实部
            pfOrgTimeDataImag - 时域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspFreqDataToTimeData(T_CellInfoModuDatGen *ptCellInfoModuDatGen,FLOAT *pfFreqDataReal,FLOAT *pfFreqDataImag,FLOAT *pfTimeDataReal,FLOAT *pfTimeDataImag)
{
    FLOAT *pxfFreqData = NULL ;
    FLOAT *pxfTimeData = NULL ;
    INT32 ifftsize     = 0;
    INT32 i            = 0;

    //IFFT变化转换为时域数据
    ifftsize = ptCellInfoModuDatGen->tFftPara.ifftsize ;
    dbgInfoEx("%s ifftsize = %d\n", __FUNCTION__,ifftsize);

    //IFFT空间分配
    pxfFreqData = (FLOAT *)malloc(sizeof(FLOAT)*ifftsize*2);
    if(NULL == pxfFreqData)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }
    pxfTimeData = (FLOAT *)malloc(sizeof(FLOAT)*ifftsize*2);
    if(NULL == pxfTimeData)
    {
        free(pxfFreqData);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }
    ptCellInfoModuDatGen->tFftPara.pidftidx = (INT32 *)malloc(sizeof(INT32)*ifftsize*2);
    if(NULL == ptCellInfoModuDatGen->tFftPara.pidftidx)
    {
        free(pxfFreqData);
        free(pxfTimeData);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }
    ptCellInfoModuDatGen->tFftPara.pftrW = (FLOAT *)malloc(sizeof(FLOAT)*ifftsize*2);
    if(NULL == ptCellInfoModuDatGen->tFftPara.pftrW)
    {
        free(pxfFreqData);
        free(pxfTimeData);
        free(ptCellInfoModuDatGen->tFftPara.pidftidx);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }
    ptCellInfoModuDatGen->tFftPara.pfdftW = (FLOAT *)malloc(sizeof(FLOAT)*ifftsize*2);
    if(NULL == ptCellInfoModuDatGen->tFftPara.pfdftW)
    {
        free(pxfFreqData);
        free(pxfTimeData);
        free(ptCellInfoModuDatGen->tFftPara.pidftidx);
        free(ptCellInfoModuDatGen->tFftPara.pftrW);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }
    ptCellInfoModuDatGen->tFftPara.pucRev = g_ucBrev ;
    ptCellInfoModuDatGen->tFftPara.ifftflag = 1 ; ///IFFT

    //空间清0
    memset(pxfFreqData,0,sizeof(INT32)*ifftsize*2);
    memset(pxfTimeData,0,sizeof(INT32)*ifftsize*2);
    memset(ptCellInfoModuDatGen->tFftPara.pidftidx,0,sizeof(INT32)*ifftsize*2);
    memset(ptCellInfoModuDatGen->tFftPara.pftrW,0,sizeof(FLOAT)*ifftsize*2);
    memset(ptCellInfoModuDatGen->tFftPara.pfdftW,0,sizeof(FLOAT)*ifftsize*2);

    //生成IFFT计算参数
    AdvPFftParaCalc(&(ptCellInfoModuDatGen->tFftPara));

    //数据拼接成IQ
    for(i=0;i<ifftsize;i++)
    {
        pxfFreqData[2*i]   = pfFreqDataReal[i];
        pxfFreqData[2*i+1] = pfFreqDataImag[i];
    }
    dbgInfoEx("%s pfFreqDataReal = %f,pfFreqDataImag = %f\n", __FUNCTION__,pfFreqDataReal[0],pfFreqDataImag[0]);

    //IFFT
    AdvAcPifftTran(pxfFreqData,&(ptCellInfoModuDatGen->tFftPara),pxfTimeData) ;

    //将数据拆分
    for(i=0;i<ifftsize;i++)
    {
        pfTimeDataReal[i] =  pxfTimeData[2*i] ;
        pfTimeDataImag[i] =  pxfTimeData[2*i+1] ;
    }
    dbgInfoEx("%s pfTimeDataReal = %f,pfTimeDataImag = %f\n", __FUNCTION__,pfTimeDataReal[0],pfTimeDataImag[0]);

    free(pxfFreqData);
    free(pxfTimeData);
    free(ptCellInfoModuDatGen->tFftPara.pidftidx);
    free(ptCellInfoModuDatGen->tFftPara.pftrW);
    free(ptCellInfoModuDatGen->tFftPara.pfdftW);

    return BSP_OK;

}

/**************************************************************************
 * 函数名称: BspTimeDataAddCp
 * 功能描述: 时域数据前后增加CP
 * 输入参数:ptCellInfoModuDatGen - 计算参数
            pfTimeDataReal - 时域数据实部
            pfTimeDataImag - 时域数据虚部
            uiDatLen - 数据长度
            uiSymbolIndex - 符号指示
 * 输出参数: pfOrgTimeDataReal - 时域数据实部
            pfOrgTimeDataImag - 时域数据虚部
            puiDatLen - 增加CP后的数据长度
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspTimeDataAddCp(T_CellInfoModuDatGen *ptCellInfoModuDatGen,UINT32 uiSymbolCpIndex,FLOAT *pfTimeDataReal,FLOAT *pfTimeDataImag,UINT32 *puiDatLen)
{
    UINT32    uiSymbolCpValidLen   ;
    UINT32    i                    ;
    FLOAT     *pfTimeDataRealTmp = NULL;
    FLOAT     *pfTimeDataImagTmp = NULL;
    UINT32    uiSymbolLen = 0;
    UINT32    uiSymbolCp0Len = 0;
    UINT32    uiSymbolCp1Len = 0;

    uiSymbolLen    = ptCellInfoModuDatGen->tNrorLteCellInfoCommon.uiSymbolLen ;
    uiSymbolCp0Len = ptCellInfoModuDatGen->tNrorLteCellInfoCommon.uiSymbolCp0Len ;
    uiSymbolCp1Len = ptCellInfoModuDatGen->tNrorLteCellInfoCommon.uiSymbolCp1Len ;
    //指针检查
    if((NULL == pfTimeDataReal)||(NULL == pfTimeDataImag)||(NULL == puiDatLen))
    {
        return BSP_ERROR;
    }

    dbgInfoEx("%s uiSymbolCp0Len = %u,uiSymbolCp1Len = %u,uiSymbolLen = %u,uiSymbolCpIndex = %u\n", __FUNCTION__,uiSymbolCp0Len,uiSymbolCp1Len,uiSymbolLen,uiSymbolCpIndex);

    pfTimeDataRealTmp       = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen));
    if(NULL == pfTimeDataRealTmp)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pfTimeDataImagTmp       = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen));
    if(NULL == pfTimeDataImagTmp)
    {
        free(pfTimeDataRealTmp);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset(pfTimeDataRealTmp,0x0,sizeof(FLOAT)*(uiSymbolLen));
    memset(pfTimeDataImagTmp,0x0,sizeof(FLOAT)*(uiSymbolLen));

    for(i=0;i<uiSymbolLen;i++)
    {
        pfTimeDataRealTmp[i] = pfTimeDataReal[i];
        pfTimeDataImagTmp[i] = pfTimeDataImag[i];
    }

    //获取当前符号长度长度
    if(0 == uiSymbolCpIndex)
    {
        uiSymbolCpValidLen = uiSymbolCp0Len  ;
    }
    else
    {
        uiSymbolCpValidLen = uiSymbolCp1Len  ;
    }
    //调整数据
    for(i=0;i<uiSymbolCpValidLen;i++)
    {
        pfTimeDataReal[i] = pfTimeDataRealTmp[i+uiSymbolLen-uiSymbolCpValidLen];
        pfTimeDataImag[i] = pfTimeDataImagTmp[i+uiSymbolLen-uiSymbolCpValidLen];
    }

    for(i=0;i<uiSymbolLen;i++)
    {
        pfTimeDataReal[i+uiSymbolCpValidLen] = pfTimeDataRealTmp [i] ;
        pfTimeDataImag[i+uiSymbolCpValidLen] = pfTimeDataImagTmp [i] ;
    }

    ///设置数据长度
    *puiDatLen = uiSymbolCpValidLen + uiSymbolLen;

    dbgInfoEx("%s uiSymbolCpValidLen = %u,uiSymbolLen = %u,uiDatLen = %u\n", __FUNCTION__,uiSymbolCpValidLen,uiSymbolLen,*puiDatLen);

    //空间释放
    free(pfTimeDataRealTmp);
    free(pfTimeDataImagTmp);

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspTimeDataCombine
 * 功能描述: 符号拼接
 * 输入参数:
            pfTimeDataReal - 时域数据实部
            pfTimeDataImag - 时域数据虚部
            uiDatLen - 数据长度

  * 输出参数: pfOrgTimeDataReal - 时域数据实部
            pfOrgTimeDataImag - 时域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspTimeDataCombine(FLOAT *pfTimeDataReal,FLOAT *pfTimeDataImag,UINT32 uiDatLen,FLOAT *pfOrgTimeDataReal,FLOAT *pfOrgTimeDataImag)
{
    UINT32 i ;

    //数据复制
    for(i=0;i<uiDatLen;i++)
    {
        pfOrgTimeDataReal[i] = pfTimeDataReal[i] ;
        pfOrgTimeDataImag[i] = pfTimeDataImag[i] ;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspTimeDataAvgMaxRatioCal
 * 功能描述: 峰均比计算
 * 输入参数:ptCellInfoModuDatGen - 计算参数
            pfTimeDataReal - 时域数据实部
            pfTimeDataImag - 时域数据虚部
            uiDatLen - 数据长度
            uiSymbolIndex - 符号指示
 * 输出参数: pfOrgTimeDataReal - 时域数据实部
            pfOrgTimeDataImag - 时域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspTimeDataAvgMaxRatioCal(T_CellInfoModuDatGen *ptCellInfoModuDatGen,UINT32 uiDatLen,FLOAT *pfTimeDataReal,FLOAT *pfTimeDataImag)
{
    DOUBLE   dTimeDatPwr        ;
    DOUBLE   dSumTimeDatPwr=0.0 ;
    DOUBLE   dTimeDatPwrMean=1.0;
    DOUBLE   dTimeDatPwrMax     ;
    UINT32   i                  ;
    FLOAT    fMaxMeanRatio      ;

    ///位置0的功率
    dTimeDatPwrMax = pfTimeDataReal[0] * pfTimeDataReal[0] + pfTimeDataImag[0] * pfTimeDataImag[0] ;
    dSumTimeDatPwr = dTimeDatPwrMax ;

    ///功率求和
    for(i=1;i<uiDatLen;i++)
    {
        //计算单点功率
        dTimeDatPwr    = pfTimeDataReal[i] * pfTimeDataReal[i] + pfTimeDataImag[i] * pfTimeDataImag[i];
        dSumTimeDatPwr = dSumTimeDatPwr + dTimeDatPwr ;
        if(dTimeDatPwr > dTimeDatPwrMax)
        {
            dTimeDatPwrMax = dTimeDatPwr ;
        }
    }
    ///计算平均功率
    if(0 != uiDatLen)
    {
        dTimeDatPwrMean = dSumTimeDatPwr / uiDatLen ;
    }
    //计算峰均比
    fMaxMeanRatio = 10*log10_s((dTimeDatPwrMax/dTimeDatPwrMean), 0.0);
    //log记录
    dbgInfo("%s dTimeDatPwrMeanAA = %f,dTimeDatPwrMax = %f, ratio = %f\n", __FUNCTION__,dTimeDatPwrMean,dTimeDatPwrMax,fMaxMeanRatio);

    return BSP_OK;

}

/**************************************************************************
 * 函数名称: BspDataPwrAdj
 * 功能描述: 功率定标
 * 输入参数:ptCellInfoModuDatGen - 计算参数
            pfTimeDataReal - 时域数据实部
            pfTimeDataImag - 时域数据虚部
            uiDatLen - 数据长度
 * 输出参数: pfTimeDataReal - 时域数据实部
            pfTimeDataImag - 时域数据虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspDataPwrAdj(T_CellInfoModuDatGen *ptCellInfoModuDatGen,FLOAT *pfTimeDataReal,FLOAT *pfTimeDataImag,UINT32 uiDatLen)
{
    UINT32   i                  ;
    DOUBLE   dTimeDatPwr        ;
    DOUBLE   dSumTimeDatPwr=0.0 ;
    DOUBLE   dTimeDatPwrMean=1.0;
    FLOAT    fTimeDatAmpAdj     ;
    INT32    iSetFixValue       ;
    INT32    iSignalWidthLen    ;
    FLOAT    fSignalAmp         ;
    FLOAT    fTimeDatDbfs       ;

    //参数获取
    iSetFixValue = ptCellInfoModuDatGen->tNrorLteCellInfoCommon.iSetFixValue;
    iSignalWidthLen= ptCellInfoModuDatGen->tNrorLteCellInfoCommon.iSignalWidthLen;

    ///功率求和
    for(i=0;i<uiDatLen;i++)
    {
        //计算单点功率
        dTimeDatPwr    = pfTimeDataReal[i] * pfTimeDataReal[i] + pfTimeDataImag[i] * pfTimeDataImag[i];
        dSumTimeDatPwr = dSumTimeDatPwr + dTimeDatPwr ;
    }

    ///计算平均功率
    if(0 != uiDatLen)
    {
        dTimeDatPwrMean = dSumTimeDatPwr / uiDatLen ;
    }

    fSignalAmp = powf(2, iSignalWidthLen);
    fTimeDatDbfs = 10*log10_s(dTimeDatPwrMean, 0.0) - 10*log10_s((DOUBLE)(fSignalAmp * fSignalAmp), 0.0) ;
    //信号幅度调整
    fTimeDatAmpAdj = powf(10,(iSetFixValue-fTimeDatDbfs)/20);
    dbgInfoEx("%s fTimeDatAmpAdj = %f,fTimeDatDbfs=%f,iSetFixValue=%d\n", __FUNCTION__,fTimeDatAmpAdj,fTimeDatDbfs,iSetFixValue);
    for(i=0;i<uiDatLen;i++)
    {
        pfTimeDataReal[i] = pfTimeDataReal[i]*fTimeDatAmpAdj ;
        pfTimeDataImag[i] = pfTimeDataImag[i]*fTimeDatAmpAdj ;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspCombineSymbolData
 * 功能描述: 将IQ信号拼接在一起，高I，低Q
 * 输入参数: pfTimeDataReal - 时域数据实部
            pfTimeDataImag - 时域数据虚部
            uiDatLen - 数据长度
 * 输出参数: puiTimeData - 拼接后的时域数据
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspCombineSymbolData(FLOAT *pfTimeDataReal,FLOAT *pfTimeDataImag,UINT32 uiDatLen,UINT32 *puiTimeData)
{
    UINT32     i  ;
    INT32      iTimeDataRealTmp   ;
    INT32      iTimeDataImagTmp   ;
    UINT32     uiTimeDataReal     ;
    UINT32     uiTimeDataImag     ;

    for(i=0;i<uiDatLen;i++)
    {
        iTimeDataRealTmp =  (INT32)pfTimeDataReal[i]  ;
        iTimeDataImagTmp =  (INT32)pfTimeDataImag[i]  ;

        uiTimeDataReal = (iTimeDataRealTmp & 0xffff) << 16 ;
        uiTimeDataImag = (iTimeDataImagTmp & 0xffff)  ;

        puiTimeData[i] = uiTimeDataReal | uiTimeDataImag ;
    }

    dbgInfoEx("%s TimeData = 0x%08X\n", __FUNCTION__,puiTimeData[0]);

    return BSP_OK;

}

/**************************************************************************
 * 函数名称: BspGenSlotData
 * 功能描述: 生成slot级时域数据
 * 输入参数: ptCellInfoModuDatGen - 入参
 * 输出参数: puiTimeData - 时域数据
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenSlotData(T_CellInfoModuDatGen *ptCellInfoModuDatGen,UINT32 *puiTimeData)
{
    UINT32      uiSymbolNum     = 0 ;
    UINT32      uiSymbolNumLoop = 0 ;
    UINT32      uiSymbolLen     = 0 ;
    UINT32      uiSymbolCp0Len  = 0 ;
    UINT32      uiDatLen        = 0 ;
    UINT32      uiDataSlotLen   = 0 ;
    UINT32      uiValidScNum    = 0 ;
    UINT32      uiSymbolCpIndex = 0 ;
    FLOAT      *pfFreqDataReal  = NULL ;
    FLOAT      *pfFreqDataImag  = NULL ;
    FLOAT      *pfTimeDataReal  = NULL ;
    FLOAT      *pfTimeDataImag  = NULL ;
    FLOAT      *pfOrgTimeDataReal  = NULL ;
    FLOAT      *pfOrgTimeDataImag  = NULL ;
    INT32      *puiOrgRandomData = NULL ;
    CHAR pcFileName1[30] = "/opt_timedata.txt";

    //参数获取
    uiSymbolNum              = ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolNum;
    uiSymbolCp0Len           = ptCellInfoModuDatGen->tCellInfoCommon.uiSymbolCp0Len;
    uiSymbolLen              = ptCellInfoModuDatGen->tCellInfoDmrs.uiSymbolLen;
    uiValidScNum             = ptCellInfoModuDatGen->tCellInfoDmrs.uiValidScNum;

    //申请空间
    pfFreqDataReal      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen));
    if(NULL == pfFreqDataReal)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfFreqDataImag      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen));
    if(NULL == pfFreqDataImag)
    {
        free(pfFreqDataReal);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfTimeDataReal      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
    if(NULL == pfTimeDataReal)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfTimeDataImag      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
    if(NULL == pfTimeDataImag)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    puiOrgRandomData    = (INT32 *)malloc(sizeof(UINT32)*(uiValidScNum*uiSymbolNum));
    if(NULL == puiOrgRandomData)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        free(pfTimeDataImag);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfOrgTimeDataReal   = (FLOAT *)malloc(sizeof(FLOAT)*SLOT_TIMEDATA_LEN);
    if(NULL == pfOrgTimeDataReal)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        free(pfTimeDataImag);
        free(puiOrgRandomData);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfOrgTimeDataImag   = (FLOAT *)malloc(sizeof(FLOAT)*SLOT_TIMEDATA_LEN);
    if(NULL == pfOrgTimeDataImag)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        free(pfTimeDataImag);
        free(puiOrgRandomData);
        free(pfOrgTimeDataReal);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    //根据配置生成DMRS时域信号位置
    BspGetDmrsTimePos(ptCellInfoModuDatGen);
    //生成随机数
    BspGenRandomData(uiValidScNum*uiSymbolNum,puiOrgRandomData);

    //按照符号生成频域数据
    for(uiSymbolNumLoop = 0;uiSymbolNumLoop < uiSymbolNum ;uiSymbolNumLoop++)
    {
        ///获取CP标志位
        uiSymbolCpIndex = ptCellInfoModuDatGen->tCellInfoCommon.auiSymbolCpIndex[uiSymbolNumLoop];
        ///空间清0
        memset(pfFreqDataReal,0,sizeof(FLOAT)*(uiSymbolLen));
        memset(pfFreqDataImag,0,sizeof(FLOAT)*(uiSymbolLen));
        memset(pfTimeDataReal,0,sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
        memset(pfTimeDataImag,0,sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
        //生成频域数据
        BspGenSymbolFreqData(ptCellInfoModuDatGen,uiSymbolNumLoop,puiOrgRandomData,pfFreqDataReal,pfFreqDataImag);
        //FftShift
        BspFftShift(pfFreqDataReal,pfFreqDataImag,pfFreqDataReal,pfFreqDataImag,uiSymbolLen);
        //IFFT
        BspFreqDataToTimeData(ptCellInfoModuDatGen,pfFreqDataReal,pfFreqDataImag,pfTimeDataReal,pfTimeDataImag);
        //时域信号增加CP
        BspTimeDataAddCp(ptCellInfoModuDatGen,uiSymbolCpIndex,pfTimeDataReal,pfTimeDataImag,&uiDatLen);
        //峰均比计算
        if(uiDataSlotLen < SLOT_TIMEDATA_LEN)
        {
            BspTimeDataAvgMaxRatioCal(ptCellInfoModuDatGen,uiDatLen,pfTimeDataReal,pfTimeDataImag);
        }
        //拼接
        BspTimeDataCombine(pfTimeDataReal,pfTimeDataImag,uiDatLen,&pfOrgTimeDataReal[uiDataSlotLen],&pfOrgTimeDataImag[uiDataSlotLen]);
        //位置计算
        uiDataSlotLen = uiDataSlotLen + uiDatLen ;
    }

    //功率定标
    BspDataPwrAdj(ptCellInfoModuDatGen,pfOrgTimeDataReal,pfOrgTimeDataImag,uiDataSlotLen);
    //将IQ信号拼接在一起，高I，低Q
    BspCombineSymbolData(pfOrgTimeDataReal,pfOrgTimeDataImag,uiDataSlotLen,puiTimeData);
    //记录
    WriteUintDataFile((UINT32 *)&puiTimeData[0], uiDataSlotLen, pcFileName1);

    free(pfFreqDataReal);
    free(pfFreqDataImag);
    free(pfTimeDataReal);
    free(pfTimeDataImag);
    free(puiOrgRandomData);
    free(pfOrgTimeDataReal);
    free(pfOrgTimeDataImag);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGenNrEvmData
 * 功能描述: NR在线源生成模块
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenNrEvmData()
{
    //变量初始化
    memset(g_uiEvmTimeData,0,sizeof(UINT32)*SLOT_TIMEDATA_LEN);
    //静态配置
    BspNrEvmDatGenInitCfg(&g_atCellInfoModuDatGen);
    //时域数据生成
    BspGenSlotData(&g_atCellInfoModuDatGen,g_uiEvmTimeData);

    return BSP_OK;
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/**************************************************************************
 * 函数名称: BspSignalTimeDataGen
 * 功能描述: 单音生成模块
 * 输入参数: uiDataFc
             uiDataFs
             uiDataLen
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspSignalTimeDataGen(UINT32 uiDataFc,UINT32 uiDataFs,UINT32 uiDataLen,FLOAT *pfRealData,FLOAT *pfImagData)
{
    FLOAT fDataFreqRatio ;
    FLOAT fDataFreq ;
    UINT32 i ;

    fDataFreqRatio = (FLOAT)uiDataFc / (FLOAT)uiDataFs ;
    fDataFreq = (FLOAT)(-2.0*PI) * fDataFreqRatio;

    for(i=0;i<uiDataLen;i++)
    {
        pfRealData[i] = cosf(fDataFreq*i);
        pfImagData[i] = sinf(fDataFreq*i);
    }

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspGenSignalData
 * 功能描述: 单音生成模块
 * 输入参数: uiDataFc    -- 移频值 单位khz
            uiDataFs  -- 采样率 单位khz
            uiScs -- 子载波间隔，0表示15k，1表示30k
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenSignalData(UINT32 uiScs,UINT32 uiDataFc,UINT32 uiDataFs)
{
    FLOAT *pfRealData = NULL ;
    FLOAT *pfImagData = NULL ;
    UINT32 uiScsVal = 0;
    UINT32 uiDataLen = 0;

    //空间分配
    pfRealData      = (FLOAT *)malloc(sizeof(FLOAT)*SLOT_TIMEDATA_LEN);
    if(NULL == pfRealData)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }
    pfImagData      = (FLOAT *)malloc(sizeof(FLOAT)*SLOT_TIMEDATA_LEN);
    if(NULL == pfImagData)
    {
        free(pfRealData);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }

    //参数计算
    uiScsVal = BspCal2power(uiScs);
    uiDataLen = uiDataFs / uiScsVal ;

    //变量初始化
    memset(g_uiEvmTimeData,0,sizeof(UINT32)*SLOT_TIMEDATA_LEN);
    //生成时域数据
    BspSignalTimeDataGen(uiDataFc,uiDataFs,uiDataLen,pfRealData,pfImagData);
    //功率定标调整
    BspDataPwrAdj(&g_atCellInfoModuDatGen,pfRealData,pfImagData,uiDataLen);
    //将IQ信号拼接在一起，高I，低Q
    BspCombineSymbolData(pfRealData,pfImagData,uiDataLen,g_uiEvmTimeData);

    ///空间释放
    free(pfRealData);
    free(pfImagData);

    return BSP_OK;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////
/**************************************************************************
 * 函数名称: BspGetLteEvmPara
 * 功能描述: 获取LteEvmPara
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGetLteEvmPara()
{
    dbgInfo("LTE CELLID:%d\n",g_atCellInfoModuDatGen.tLteCellInfoCommon.uiCellId);
    dbgInfo("LTE QAM TYPE :%d,3:64QAM,4:256QAM\n",g_atCellInfoModuDatGen.tLteCellInfoPdsch.uiPdschModuleTypeSel);

    return BSP_OK ;
}


/**************************************************************************
 * 函数名称:BspSetLteEvmPara()
 * 功能描述:
 * 输入参数:uislot --slot号
         uiBandWidth --带宽
         uiDataType -- 类型 3表示3.1 4表示3.1a
         uiTddOrFddFlg -- 0x1表示FDD，0x0表示TDD
         uiAauOrRruFlg -- 0x1表示AAU，0x0表示RRU
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/

UINT32 BspSetLteEvmPara(T_NrOrLteDataPara *ptNrOrLteDataPara)
{
    UINT32    uiBandIndexLoop                                  ;
    UINT32    uiBandIndex   = 0                                ;
    UINT32    uiDataFftSizeTmp                                 ;
    UINT32    uiSymbolLen                                      ;
    UINT32    uiValidScNum                                     ;
    UINT32    uiSlotLoop                                       ;
    UINT32    uiSymbolLoop                                     ;
    INT32     iDatPwrdbfs                                      ;
    UINT32    uiBandWidth                                      ;
    UINT32    uiDataRate                                       ;
    UINT32    uiDataType                                       ;
    UINT32    uiTddOrFddFlg                                    ;
    UINT32    uiDatPwrN13DbfsFlg                               ;

    ///采数获取
    uiBandWidth   = ptNrOrLteDataPara->uiBandWidth;
    uiDataRate    = ptNrOrLteDataPara->uiDataRate;
    uiDataType    = ptNrOrLteDataPara->uiDataType;
    uiTddOrFddFlg = ptNrOrLteDataPara->uiTddOrFddFlg;
    uiDatPwrN13DbfsFlg = ptNrOrLteDataPara->uiDatPwrN13DbfsFlg ;

    ///参数检查
    if(DATA_MODE_NUM <= uiDataType)
    {
        dbgInfo("%s ParaMeter is error!!!\n", __FUNCTION__);
        return BSP_ERROR ;
    }

    //参数计算
    for(uiBandIndexLoop=0;uiBandIndexLoop<BAND_NUM;uiBandIndexLoop++)
    {
        if(uiBandWidth == g_aiBandIndex[uiBandIndexLoop])
        {
            uiBandIndex = uiBandIndexLoop ;
            break ;
        }
    }

    //LTE symbolLen计算公式
    uiDataFftSizeTmp      = 256 * uiDataRate / 3840  ;
    uiSymbolLen           = uiDataFftSizeTmp ;
    uiValidScNum          = g_aiLteValidRbNum[uiBandIndex] * 12;

    ///初始化配置
    for(uiSlotLoop=0;uiSlotLoop<SLOT_NUM_PER_SUBFRAME;uiSlotLoop++)
    {
        for(uiSymbolLoop=0;uiSymbolLoop<LTE_SYMBOL_NUM;uiSymbolLoop++)
        {
            g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchSymbolValidFlg[uiSlotLoop][uiSymbolLoop] = 0;
            g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchAbstractFlg[uiSlotLoop][uiSymbolLoop] = 0;
            g_atCellInfoModuDatGen.tLteCellInfoSss.uiSssSymbolValidFlg[uiSlotLoop][uiSymbolLoop] = 0;
            g_atCellInfoModuDatGen.tLteCellInfoSss.uiPssSymbolValidFlg[uiSlotLoop][uiSymbolLoop] = 0;
            g_atCellInfoModuDatGen.tLteCellInfoPdsch.uiPdschSymbolValidFlg[uiSlotLoop][uiSymbolLoop] = 1;
            g_atCellInfoModuDatGen.tLteCrsPara.uiCrsSymbolValidFlg[uiSlotLoop][uiSymbolLoop] = 0;
        }
    }

    //ifft 配置
    g_atCellInfoModuDatGen.tFftPara.ifftsize = uiSymbolLen ;
    //Pbch 配置
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchModuleTypeSel      = 0; //QPSK调制
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchReLen              = PBCH_RB_NUM * 12 ;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchStartPos           = (uiSymbolLen - PBCH_RB_NUM * 12)/2;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchGap                = LTE_PBCH_GAP ;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchPosShiftA          = LTE_PBCH_SHIFTA ;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchPosShiftB          = LTE_PBCH_SHIFTB ;

    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchSymbolValidFlg[1][0] = 1;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchSymbolValidFlg[1][1] = 1;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchSymbolValidFlg[1][2] = 1;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchSymbolValidFlg[1][3] = 1;
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchAbstractFlg[1][0]    = 1; //符号7
    g_atCellInfoModuDatGen.tLteCellInfoPbch.uiPbchAbstractFlg[1][1]    = 1; //符号8
    //Sss 配置
    g_atCellInfoModuDatGen.tLteCellInfoSss.uiSssModuleTypeSel                = 0; //QPSK调制
    g_atCellInfoModuDatGen.tLteCellInfoSss.uiSssStartPos                     = (uiSymbolLen - LTE_SSS_LEN)/2;
    g_atCellInfoModuDatGen.tLteCellInfoSss.uiSssProtectReLen                 = LTE_SSS_PR_LEN ;
    g_atCellInfoModuDatGen.tLteCellInfoSss.uiSssReLen                        = LTE_SSS_LEN;
    ///初始化
    if(FDD_DATA_MODE==uiTddOrFddFlg)
    {
        //FDD
        g_atCellInfoModuDatGen.tLteCellInfoSss.uiSssSymbolValidFlg[0][5]         = 1 ; //Sss有效标志位
        g_atCellInfoModuDatGen.tLteCellInfoSss.uiPssSymbolValidFlg[0][6]         = 1 ; //Pss有效标志位
    }
    else
    {
        //TDD
        g_atCellInfoModuDatGen.tLteCellInfoSss.uiSssSymbolValidFlg[1][6]         = 1 ; //Sss有效标志位
        g_atCellInfoModuDatGen.tLteCellInfoSss.uiPssSymbolValidFlg[0][5]         = 0 ; //Pss有效标志位
    }

    //Pdsch配置
    g_atCellInfoModuDatGen.tLteCellInfoPdsch.uiPdschModuleTypeSel            = g_aiQamType[uiDataType]; //64QAM或256QMA调制
    g_atCellInfoModuDatGen.tLteCellInfoPdsch.uiPdschReLen                    = uiValidScNum ;
    g_atCellInfoModuDatGen.tLteCellInfoPdsch.uiPdschStartPos                 = (uiSymbolLen - uiValidScNum)/2;

    g_atCellInfoModuDatGen.tLteCellInfoPdsch.uiPdschSymbolValidFlg[0][0] = 0;
    ///common 配置
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiCellId           =  1 ;//cellid
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiStartScNum       =  (uiSymbolLen - uiValidScNum)/2;;
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiValidRbNum       =  g_aiLteValidRbNum[uiBandIndex] ;
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSymbolLen        =  uiSymbolLen ;
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSymbolNum        =  LTE_SYMBOL_NUM ;
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiValidScNum       =  uiValidScNum ;
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSymbolCp0Len     =  160 * uiDataRate /30720 ; //15k子载波
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSymbolCp1Len     =  144 * uiDataRate /30720 ;
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSubFrameNumb     =  0 ; //子帧0
    g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSlotNumPerSubFrame  =  SLOT_NUM_PER_SUBFRAME ;
    g_atCellInfoModuDatGen.tLteCellInfoCommon.auiSymbolCpIndex[0]   = 0;//cp0
    for(uiSymbolLoop=1;uiSymbolLoop<LTE_SYMBOL_NUM;uiSymbolLoop++)
    {
        g_atCellInfoModuDatGen.tLteCellInfoCommon.auiSymbolCpIndex[uiSymbolLoop] = 1 ;  //cp1
    }
    //Crs 配置
    g_atCellInfoModuDatGen.tLteCrsPara.uiCrsSymbolValidFlg[0][0] = 1;
    g_atCellInfoModuDatGen.tLteCrsPara.uiCrsSymbolValidFlg[0][4] = 1;
    g_atCellInfoModuDatGen.tLteCrsPara.uiCrsSymbolValidFlg[1][0] = 1;
    g_atCellInfoModuDatGen.tLteCrsPara.uiCrsSymbolValidFlg[1][4] = 1;
    g_atCellInfoModuDatGen.tLteCrsPara.Crs_v[0]  = 0;
    g_atCellInfoModuDatGen.tLteCrsPara.Crs_v[4]  = 3;
    g_atCellInfoModuDatGen.tLteCrsPara.Crs_v_shift = g_atCellInfoModuDatGen.tLteCellInfoCommon.uiCellId % CRS_GAP;

    ///信号位宽以及功率配置
    if(1 == uiDatPwrN13DbfsFlg)
    {
        iDatPwrdbfs = g_aiDataPwrType[uiDataType] + 1; //-13dbfs
    }
    else
    {
        iDatPwrdbfs = g_aiDataPwrType[uiDataType] ; //-14dbfs
    }
    g_atCellInfoModuDatGen.tNrorLteCellInfoCommon.iSetFixValue = iDatPwrdbfs; //功率设置为-14dbfs
    g_atCellInfoModuDatGen.tNrorLteCellInfoCommon.iSignalWidthLen = g_aiDataWidth - 1 ; //默认信号为16bit有符号数据
    g_atCellInfoModuDatGen.tNrorLteCellInfoCommon.uiSymbolCp0Len = g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSymbolCp0Len;
    g_atCellInfoModuDatGen.tNrorLteCellInfoCommon.uiSymbolCp1Len = g_atCellInfoModuDatGen.tLteCellInfoCommon.uiSymbolCp1Len;
    g_atCellInfoModuDatGen.tNrorLteCellInfoCommon.uiSymbolLen  =   uiSymbolLen ;
    dbgInfo("%s:iDatPwrdbfs = %d dbfs !\n",__FUNCTION__,iDatPwrdbfs);

    return OK;
}

/**************************************************************************
 * 函数名称: GetLteMSeq
 * 功能描述: 计算LTE的参考信号
 * 输入参数: uiSlotIndex-slot号，0---19
             uiSymIndex-symbol号，0--7
             ptCellInfoModuDatGen-参数结构体
 * 输出参数:    pxfRnRealDat -参考信号实部
             pxfRnImagDat -参考信号虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 GetLteMSeq(UINT32 uiSlotIndex,
                    UINT32 uiSymIndex,
                    T_CellInfoModuDatGen *ptCellInfoModuDatGen,
                    FLOAT *pxfRnRealDat,
                    FLOAT *pxfRnImagDat)
{
    UINT32 uiCellId;
    UINT32 uiCinit1 = 1 ,uiCinit2;
    UINT32 uiMpn, i;
    UINT32 *puiX1nDat=NULL;
    UINT32 *puiX2nDat=NULL;
    INT32 *piCnDat = NULL;

    uiMpn = RB_NUM_LTE_MAX * CRS_NUM_PER_RB * 2;
    uiCellId = ptCellInfoModuDatGen->tLteCellInfoCommon.uiCellId;

    //空间申请
    puiX1nDat      = (UINT32 *)malloc(sizeof(UINT32)*(uiMpn + 1600));
    if(NULL == puiX1nDat)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    puiX2nDat      = (UINT32 *)malloc(sizeof(UINT32)*(uiMpn + 1600));
    if(NULL == puiX2nDat)
    {
        free(puiX1nDat);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    piCnDat        = (INT32 *)malloc(sizeof(INT32)*uiMpn);
    if(NULL == piCnDat)
    {
        free(puiX1nDat);
        free(puiX2nDat);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    uiCinit2 =  1024*(7*(uiSlotIndex+1)+uiSymIndex+1)*(2*uiCellId+1)+2*uiCellId+1;

    for(i = 0; i < 31; i++)
    {
        puiX1nDat[i] = (uiCinit1>>i)&0x01;
        puiX2nDat[i] = (uiCinit2>>i)&0x01;
    }
    for(i = 31; i < (uiMpn+1600); i++)
    {
        puiX1nDat[i]  = (puiX1nDat[i-28] + puiX1nDat[i-31])%2;
        puiX2nDat[i]  = (puiX2nDat[i-28] + puiX2nDat[i-29] + puiX2nDat[i-30] + puiX2nDat[i-31])%2;
    }

    for(i = 0; i < uiMpn; i++)
    {
        piCnDat[i] = (puiX1nDat[i+1600] + puiX2nDat[i+1600])%2;
    }

    for(i = 0; i < uiMpn/2; i++)
    {
        pxfRnRealDat[i] = ((FLOAT)(1/sqrt(2)))*(1-2*piCnDat[2*i]);
        pxfRnImagDat[i] = ((FLOAT)(1/sqrt(2)))*(1-2*piCnDat[2*i+1]);
    }


    //空间释放
    free(puiX1nDat);
    free(puiX2nDat);
    free(piCnDat);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: InsertMSeq
 * 功能描述: LTE的参考信号插入
 * 输入参数:    uiSymIndex-symbol号，0--7
             pxfRealDataIn --输入实部
             pxfImagDataIn --输入虚部
             ptCellInfoModuDatGen-参数结构体
 * 输出参数:    pxfRealDataOut -参考信号实部
             pxfImagDataOut -参考信号虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
static void InsertMSeq(FLOAT *pxfRealDataIn, FLOAT *pxfImagDataIn,T_CellInfoModuDatGen *ptCellInfoModuDatGen,FLOAT *pxfRealDataOut,FLOAT *pxfImagDataOut)
{
    UINT32 uiStartScNum;
    UINT32 uiValidRbNum;
    UINT32 uiRbStartIndex;
    UINT32 uiCrsNumPerSymbol;
    UINT32 v_mod;
    UINT32 i ;
    UINT32 uiSymIndex;

    uiStartScNum = ptCellInfoModuDatGen->tLteCellInfoCommon.uiStartScNum;
    uiValidRbNum = ptCellInfoModuDatGen->tLteCellInfoCommon.uiValidRbNum;
    uiRbStartIndex = RB_NUM_LTE_MAX - uiValidRbNum;
    uiCrsNumPerSymbol = uiValidRbNum * CRS_NUM_PER_RB;
    uiSymIndex = ptCellInfoModuDatGen->tNrOrLteDataIndex.uiSymbolIndex;

    if(LTE_SYMBOL_NUM <= uiSymIndex)
    {
        return ;
    }

    v_mod = (ptCellInfoModuDatGen->tLteCrsPara.Crs_v[uiSymIndex] + ptCellInfoModuDatGen->tLteCrsPara.Crs_v_shift) % CRS_GAP;

    for(i=0; i<uiCrsNumPerSymbol; i++)
    {
        pxfRealDataOut[uiStartScNum + v_mod + CRS_GAP * i] = pxfRealDataIn[uiRbStartIndex + i];
        pxfImagDataOut[uiStartScNum + v_mod + CRS_GAP * i] = pxfImagDataIn[uiRbStartIndex + i];
    }
}


/**************************************************************************
 * 函数名称: GenLtePssSeq
 * 功能描述: 生成LTE Pss序列
 * 输入参数:    ptCellInfoModuDatGen-参数结构体
 * 输出参数:    pxfPssRealDat -Pss信号实部
             pxfPssImagDat -参考信号虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 GenLtePssSeq(
                    T_CellInfoModuDatGen *ptCellInfoModuDatGen,
                    FLOAT *pxfPssRealDat,
                    FLOAT *pxfPssImagDat
                    )
{
    UINT32 uiCellId      ;
    UINT32 uiPssIndex    ;
    UINT32 uiPssPosLoop  ;
    FLOAT  fTmpVal       ;
    ///参数获取
    uiCellId = ptCellInfoModuDatGen->tLteCellInfoCommon.uiCellId ;

    if(PSS_INDEX_NUM <= uiCellId)
    {
        return BSP_ERROR ;
    }

    uiPssIndex = g_aiPssUindex[uiCellId] ;

    for(uiPssPosLoop=0;uiPssPosLoop<31;uiPssPosLoop++)
    {
        fTmpVal = (FLOAT)((-1)*PI*uiPssIndex*uiPssPosLoop*(uiPssPosLoop+1)/63) ;
        pxfPssRealDat[uiPssPosLoop] = (FLOAT)cosf(fTmpVal);
        pxfPssImagDat[uiPssPosLoop] = (FLOAT)sinf(fTmpVal);
    }

    for(uiPssPosLoop=31;uiPssPosLoop<62;uiPssPosLoop++)
    {
        fTmpVal = (FLOAT)((-1)*PI*uiPssIndex*(uiPssPosLoop+1)*(uiPssPosLoop+2)/63) ;
        pxfPssRealDat[uiPssPosLoop] = (FLOAT)cosf(fTmpVal);
        pxfPssImagDat[uiPssPosLoop] = (FLOAT)sinf(fTmpVal);
    }

    dbgInfo("%s pxfPssRealDat[1]  = %f, pxfPssImagDat[1] = %f\n", __FUNCTION__,pxfPssRealDat[1],pxfPssImagDat[1]);
    dbgInfo("%s pxfPssRealDat[31]  = %f, pxfPssImagDat[31] = %f\n", __FUNCTION__,pxfPssRealDat[31],pxfPssImagDat[31]);

    return BSP_OK ;

}

/**************************************************************************
 * 函数名称: GenLteSssSseq
 * 功能描述: 生成Sss的S序列
 * 输入参数:
 * 输出参数:   pi_S0_Value -S0
             pi_S1_Value  -S1
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 GenLteSssSseq(INT8 *pi_S0_Value,INT8 *pi_S1_Value)
{
    INT8   x_s_val_tmp[31]    = {0,0,0,0,1} ;
    INT8   x_s_val[31]  = {0} ;
    INT32  i;

    //生成x_s_val_tmp
    for(i=0;i<26;i++)
    {
        x_s_val_tmp[i+5] = (x_s_val_tmp[i] + x_s_val_tmp[i+2]) % 2 ;
    }
    //生成x_s_val
    for(i=0;i<31;i++)
    {
        x_s_val[i] = 1- 2*x_s_val_tmp[i];
    }
    //生成x_s0_val
    for(i=0;i<31;i++)
    {
        pi_S0_Value[i] = x_s_val[i % 31];
    }
    //生成x_s1_val
    for(i=0;i<31;i++)
    {
        pi_S1_Value[i] = x_s_val[(i+1) % 31];
    }

    return BSP_OK ;

}

/**************************************************************************
 * 函数名称: GenLteSssCseq
 * 功能描述: 生成Sss的S序列
 * 输入参数:    uiCellId   - CellId
 * 输出参数:    pi_C0_Value -C0
             pi_C1_Value  -C1
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 GenLteSssCseq(UINT32 uiCellId,INT8 *pi_C0_Value,INT8 *pi_C1_Value)
{
    INT8   x_c_val_tmp[31]    = {0,0,0,0,1} ;
    INT8   x_c_val[31]  = {0} ;
    INT32  i;

    //生成x_c_val_tmp
    for(i=0;i<26;i++)
    {
        x_c_val_tmp[i+5] = (x_c_val_tmp[i] + x_c_val_tmp[i+3]) % 2 ;
    }
    //生成x_c_val
    for(i=0;i<31;i++)
    {
        x_c_val[i] = 1- 2*x_c_val_tmp[i];
    }
    //生成x_c0_val
    for(i=0;i<31;i++)
    {
        pi_C0_Value[i] = x_c_val[(i+uiCellId) % 31];
    }
    //生成x_c1_val
    for(i=0;i<31;i++)
    {
        pi_C1_Value[i] = x_c_val[(i+uiCellId+3) % 31];
    }

    return BSP_OK ;

}

/**************************************************************************
 * 函数名称: GenLteSssZseq
 * 功能描述: 生成Sss的Z序列
 * 输入参数:
 * 输出参数:    pi_Z0_Value -Z0
             pi_Z1_Value  -Z1
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 GenLteSssZseq(INT8 *pi_Z0_Value,INT8 *pi_Z1_Value)
{
    INT8   x_z_val_tmp[31]    = {0,0,0,0,1} ;
    INT8   x_z_val[31]  = {0} ;
    INT32  i;

    for(i=0;i<26;i++)
    {
        x_z_val_tmp[i+5] = (x_z_val_tmp[i] + x_z_val_tmp[i+1] + x_z_val_tmp[i+2] + x_z_val_tmp[i+4]) % 2 ;
    }
    //生成x_z_val
    for(i=0;i<31;i++)
    {
        x_z_val[i] = 1- 2*x_z_val_tmp[i];
    }
    //生成x_z0_val
    for(i=0;i<31;i++)
    {
        pi_Z0_Value[i] = x_z_val[i % 31];
    }
    //生成x_z1_val
    for(i=0;i<31;i++)
    {
        pi_Z1_Value[i] = x_z_val[(i+1) % 31];
    }

    return BSP_OK ;

}

/**************************************************************************
 * 函数名称: GenLteSssSeq
 * 功能描述: 生成LTE Sss序列
 * 输入参数:    ptCellInfoModuDatGen-参数结构体
 * 输出参数:    pxfSssRealDat -Sss信号实部
             pxfSssImagDat -Sss信号虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 GenLteSssSeq(
                    T_CellInfoModuDatGen *ptCellInfoModuDatGen,
                    FLOAT *pxfSssRealDat,
                    FLOAT *pxfSssImagDat
                    )
{
    INT8   x_s0_val[31] = {0} ;
    INT8   x_s1_val[31] = {0} ;
    INT8   x_c0_val[31] = {0} ;
    INT8   x_c1_val[31] = {0} ;
    INT8   x_z0_val[31] = {0} ;
    INT8   x_z1_val[31] = {0} ;
    UINT32  uiCellId ;
    UINT32  i        ;

    ///参数获取
    uiCellId = ptCellInfoModuDatGen->tLteCellInfoCommon.uiCellId ;

    ///////////生成S
    GenLteSssSseq(x_s0_val,x_s1_val);
    ///////////生成C
    GenLteSssCseq(uiCellId,x_c0_val,x_c1_val);
    ///////////生成Z
    GenLteSssZseq(x_z0_val,x_z1_val);

    //SSS 生成
    for(i=0;i<62;i++)
    {
        if(0 == i%2)
        {
            pxfSssRealDat[i] = (FLOAT)(x_s0_val[i/2]*x_c0_val[i/2]);
            pxfSssImagDat[i] = 0.0;
        }
        else
        {
            pxfSssRealDat[i] = (FLOAT)(x_s1_val[i/2]*x_c1_val[i/2]*x_z0_val[i/2]);
            pxfSssImagDat[i] = 0.0;
        }

    }

    dbgInfo("%s pxfSssRealDat[10] = %f, x_s0_val[5] = %d,x_c0_val[5]= %d\n", __FUNCTION__,pxfSssRealDat[10],x_s0_val[5],x_c0_val[5]);
    dbgInfo("%s pxfSssRealDat[11] = %f, x_s1_val[5] = %d,x_c1_val[5]= %d,x_z0_val[5]= %d\n", __FUNCTION__,pxfSssRealDat[11],x_s1_val[5],x_c1_val[5],x_z0_val[5]);
    dbgInfo("%s pxfSssRealDat[60] = %f, x_s0_val[30] = %d,x_c0_val[30]= %d\n", __FUNCTION__,pxfSssRealDat[60],x_s0_val[30],x_c0_val[30]);
    dbgInfo("%s pxfSssRealDat[61] = %f, x_s1_val[30] = %d,x_c1_val[30]= %d,x_z0_val[30]= %d\n", __FUNCTION__,pxfSssRealDat[61],x_s1_val[30],x_c1_val[30],x_z0_val[30]);

    return BSP_OK ;

}

/**************************************************************************
 * 函数名称: CrsRefDataGen
 * 功能描述: Crs参考信号生成
 * 输入参数:   uiSlotIndex-slot号，0---19
             uiSymIndex-symbol号，0--7
             ptCellInfoModuDatGen-参数结构体
 * 输出参数:    pxfRealDataOut -参考信号实部
             pxfImagDataOut -参考信号虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
static void CrsRefDataGen(UINT32 uiSlotIndex,UINT32 uiSymIndex,T_CellInfoModuDatGen *ptCellInfoModuDatGen, FLOAT *pxfRealDataOut,FLOAT *pxfImagDataOut)
{

    FLOAT   *pxfRnRealDat=NULL;
    FLOAT   *pxfRnImagDat=NULL;

    //空间分配
    pxfRnRealDat      = (FLOAT *)malloc(sizeof(FLOAT)*(RB_NUM_LTE_MAX * CRS_NUM_PER_RB));
    if(NULL == pxfRnRealDat)
    {
        //空间释放
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return;
    }
    pxfRnImagDat      = (FLOAT *)malloc(sizeof(FLOAT)*(RB_NUM_LTE_MAX * CRS_NUM_PER_RB));
    if(NULL == pxfRnImagDat)
    {
        //空间释放.
        free(pxfRnRealDat);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return;
    }

    ///CRS生成
    GetLteMSeq(uiSlotIndex,uiSymIndex,ptCellInfoModuDatGen,pxfRnRealDat,pxfRnImagDat);
    ///CRS填充
    InsertMSeq(pxfRnRealDat,pxfRnImagDat,ptCellInfoModuDatGen,pxfRealDataOut,pxfImagDataOut);

    //空间释放
    free(pxfRnRealDat);
    free(pxfRnImagDat);

}

/**************************************************************************
 * 函数名称: InsertLtePbchSeq
 * 功能描述: LTE的Pbch信号插入
 * 输入参数:    pxfRealDataIn --输入实部
             pxfImagDataIn --输入虚部
             ptCellInfoModuDatGen-参数结构体
 * 输出参数:    pxfRealDataOut -参考信号实部
             pxfImagDataOut -参考信号虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
static void InsertLtePbchSeq(FLOAT *pxfRealDataIn, FLOAT *pxfImagDataIn,T_CellInfoModuDatGen *ptCellInfoModuDatGen,FLOAT *pxfRealDataOut,FLOAT *pxfImagDataOut)
{
    UINT32 uiPbchReLen                                         ;
    UINT32 uiPbchGap                                           ;
    UINT32 uiPbchPosShiftA                                     ; ///Pbch偏移位置A
    UINT32 uiPbchPosShiftB                                     ; ///Pbch偏移位置B
    UINT32 uiPbchValidReLen                                    ;
    UINT32 i                                                   ;

    uiPbchReLen            = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchReLen ;    ///pbch的长度
    uiPbchGap              = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchGap ;    ///pbch的Gap
    uiPbchPosShiftA        = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchPosShiftA ;    ///pbch的偏移A
    uiPbchPosShiftB        = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchPosShiftB ;    ///pbch的偏移B

    uiPbchValidReLen       = uiPbchReLen / uiPbchGap ;

    for(i=0;i<uiPbchValidReLen;i++)
    {
        pxfRealDataOut[uiPbchGap*i + uiPbchPosShiftA] = pxfRealDataIn[uiPbchGap*i + uiPbchPosShiftA] ;
        pxfImagDataOut[uiPbchGap*i + uiPbchPosShiftA] = pxfImagDataIn[uiPbchGap*i + uiPbchPosShiftA] ;

        pxfRealDataOut[uiPbchGap*i + uiPbchPosShiftB] = pxfRealDataIn[uiPbchGap*i + uiPbchPosShiftB] ;
        pxfImagDataOut[uiPbchGap*i + uiPbchPosShiftB] = pxfImagDataIn[uiPbchGap*i + uiPbchPosShiftB] ;
    }
}

/**************************************************************************
 * 函数名称: InsertLteDc
 * 功能描述: LTE的Pbch信号插入
 * 输入参数:    pxfRealDataIn --输入实部
             pxfImagDataIn --输入虚部
             uiInsertPos -- 插入位置
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
static void InsertLteDc(FLOAT *pxfRealDataIn, FLOAT *pxfImagDataIn,UINT32 uiSymbolLen)
{
    UINT32 uiHalfSymbolLen       ;
    FLOAT *pxfRealDataTmp = NULL ;
    FLOAT *pxfImagDataTmp = NULL ;
    UINT32 i ;

    uiHalfSymbolLen = uiSymbolLen /2 ;

    //空间分配
    pxfRealDataTmp      = (FLOAT *)malloc(sizeof(FLOAT)*uiHalfSymbolLen);
    if(NULL == pxfRealDataTmp)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }
    pxfImagDataTmp      = (FLOAT *)malloc(sizeof(FLOAT)*uiHalfSymbolLen);
    if(NULL == pxfImagDataTmp)
    {
        free(pxfRealDataTmp);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return ;
    }

    //复制
    for(i=0;i<uiHalfSymbolLen;i++)
    {
        pxfRealDataTmp[i] = pxfRealDataIn[i+uiHalfSymbolLen];
        pxfImagDataTmp[i] = pxfImagDataIn[i+uiHalfSymbolLen];
    }

    for(i=0;i<uiHalfSymbolLen;i++)
    {
        pxfRealDataIn[i+uiHalfSymbolLen+1] = pxfRealDataTmp[i] ;
        pxfImagDataIn[i+uiHalfSymbolLen+1] = pxfImagDataTmp[i] ;
    }

    ///直流子载波置为1,0
    pxfRealDataIn[uiHalfSymbolLen] = 1.0;
    pxfImagDataIn[uiHalfSymbolLen] = 0.0;

    free(pxfRealDataTmp);
    free(pxfImagDataTmp);

}

/**************************************************************************
 * 函数名称: InsertLteSssOrPss
 * 功能描述: LTE的SssOrPss信号插入
 * 输入参数:    uiSymbolLen   --符号长度
 *           uiPssSymbolValidFlg      --Pss有效标志
 *           uiSssSymbolValidFlg      --Sss有效标志
 *           ptCellInfoModuDatGen --生成参数
 * 输出参数:    pfFreqDataReal --输出实部
             pfFreqDataImag --输出虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
static void InsertLteSssOrPss(UINT32 uiPssSymbolValidFlg, UINT32 uiSssSymbolValidFlg,UINT32 uiSymbolLen,T_CellInfoModuDatGen *ptCellInfoModuDatGen,FLOAT *pfFreqDataReal,FLOAT *pfFreqDataImag)
{
    UINT32 uiSssReLen        ;
    UINT32 uiSssProtectReLen ;
    UINT32 uiSssStartPos     ;

    //参数获取
    uiSssReLen              = ptCellInfoModuDatGen->tLteCellInfoSss.uiSssReLen ;
    uiSssProtectReLen       = ptCellInfoModuDatGen->tLteCellInfoSss.uiSssProtectReLen ;
    uiSssStartPos           = ptCellInfoModuDatGen->tLteCellInfoSss.uiSssStartPos ;

    if(uiSymbolLen <= uiSssStartPos)
    {
        return ;
    }

    //PSS
    if(1 == uiPssSymbolValidFlg)
    {
        ///对PBCH位置进行清0
        memset(&pfFreqDataReal[uiSssStartPos], 0x0, sizeof(FLOAT)* uiSssReLen);
        memset(&pfFreqDataImag[uiSssStartPos], 0x0, sizeof(FLOAT)* uiSssReLen);

        GenLtePssSeq(ptCellInfoModuDatGen,&pfFreqDataReal[uiSssStartPos+uiSssProtectReLen],&pfFreqDataImag[uiSssStartPos+uiSssProtectReLen]);
    }
    //SSS
    if(1 == uiSssSymbolValidFlg)
    {
        ///对PBCH位置进行清0
        memset(&pfFreqDataReal[uiSssStartPos], 0x0, sizeof(FLOAT)* uiSssReLen);
        memset(&pfFreqDataImag[uiSssStartPos], 0x0, sizeof(FLOAT)* uiSssReLen);

        GenLteSssSeq(ptCellInfoModuDatGen,&pfFreqDataReal[uiSssStartPos+uiSssProtectReLen],&pfFreqDataImag[uiSssStartPos+uiSssProtectReLen]);
    }
}
/**************************************************************************
 * 函数名称: BspGenLteSymbolFreqData
 * 功能描述: Lte频域符号生成
 * 输入参数:   uiSlotIndex-slot号，0---19
             uiSymIndex-symbol号，0--7
             ptCellInfoModuDatGen-参数结构体
 * 输出参数:    pfFreqDataReal -频域信号实部
             pfFreqDataImag -频域信号虚部
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenLteSymbolFreqData(T_CellInfoModuDatGen *ptCellInfoModuDatGen,INT32 *puiOrgRandomData,FLOAT*pfFreqDataReal,FLOAT*pfFreqDataImag)
{
    UINT32    uiSlotIndexAdj         ;
    UINT32    uiPdschModuleTypeSel   ;
    UINT32    uiPdschStartPos        ;
    UINT32    uiPdschReLen           ;
    UINT32    uiPdschSymbolValidFlg  ;
    UINT32    uiCrsSymbolValidFlg    ;
    UINT32    uiPbchModuleTypeSel    ;
    UINT32    uiPbchStartPos         ;
    UINT32    uiPbchReLen            ;
    UINT32    uiPbchSymbolValidFlg   ;
    UINT32    uiPbchAbstractFlg      ;
    UINT32    uiValidScNum           ;
    UINT32    uiSssModuleTypeSel     ;
    UINT32    uiSssSymbolValidFlg    ;
    UINT32    uiPssSymbolValidFlg    ;
    FLOAT *pfFreqPbchRealData = NULL ;
    FLOAT *pfFreqPbchImagData = NULL ;
    UINT32    uiSymbolLen            ;
    UINT32    uiSlotIndex            ;
    UINT32    uiSymbolIndex          ;

    ///参数获取
    uiSlotIndex             = ptCellInfoModuDatGen->tNrOrLteDataIndex.uiSlotIndex;
    uiSymbolIndex           = ptCellInfoModuDatGen->tNrOrLteDataIndex.uiSymbolIndex;

    if(LTE_SYMBOL_NUM <= uiSymbolIndex)
    {
        return BSP_ERROR;
    }

    //对slotindex进行处理
    uiSlotIndexAdj          = uiSlotIndex%SLOT_NUM_PER_SUBFRAME;
    //有效子载波
    uiValidScNum            = ptCellInfoModuDatGen->tLteCellInfoCommon.uiValidScNum;
    //直流子载波位置
    uiSymbolLen             = ptCellInfoModuDatGen->tLteCellInfoCommon.uiSymbolLen ;
    ///Pdsch获取参数
    uiPdschModuleTypeSel    = ptCellInfoModuDatGen->tLteCellInfoPdsch.uiPdschModuleTypeSel ; //调制方式
    uiPdschStartPos         = ptCellInfoModuDatGen->tLteCellInfoPdsch.uiPdschStartPos ;    ///pdsch的起始长度
    uiPdschReLen            = ptCellInfoModuDatGen->tLteCellInfoPdsch.uiPdschReLen ;    ///pdsch的长度
    uiPdschSymbolValidFlg   = ptCellInfoModuDatGen->tLteCellInfoPdsch.uiPdschSymbolValidFlg[uiSlotIndexAdj][uiSymbolIndex] ;
    ///Crs获取参数
    uiCrsSymbolValidFlg     = ptCellInfoModuDatGen->tLteCrsPara.uiCrsSymbolValidFlg[uiSlotIndexAdj][uiSymbolIndex] ;
    //Pbch参数获取
    uiPbchModuleTypeSel     = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchModuleTypeSel ; //调制方式
    uiPbchStartPos          = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchStartPos ;    ///pbch的起始长度
    uiPbchReLen             = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchReLen ;    ///pbch的长度
    uiPbchSymbolValidFlg    = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchSymbolValidFlg[uiSlotIndexAdj][uiSymbolIndex] ;
    uiPbchAbstractFlg       = ptCellInfoModuDatGen->tLteCellInfoPbch.uiPbchAbstractFlg[uiSlotIndexAdj][uiSymbolIndex] ;
    //Sss参数获取
    uiSssModuleTypeSel      = ptCellInfoModuDatGen->tLteCellInfoSss.uiSssModuleTypeSel ;
    uiSssSymbolValidFlg     = ptCellInfoModuDatGen->tLteCellInfoSss.uiSssSymbolValidFlg[uiSlotIndexAdj][uiSymbolIndex] ;
    uiPssSymbolValidFlg     = ptCellInfoModuDatGen->tLteCellInfoSss.uiPssSymbolValidFlg[uiSlotIndexAdj][uiSymbolIndex] ;


    dbgInfoEx("%s uiSlotIndexAdj is %d,uiValidScNum is %d,uiSymbolLen is %d,uiPdschModuleTypeSel is %d,uiPdschStartPos is %d,uiPdschReLen is %d,uiPdschSymbolValidFlg is %d\n", __FUNCTION__,
            uiSlotIndexAdj,uiValidScNum,uiSymbolLen,uiPdschModuleTypeSel,uiPdschStartPos,uiPdschReLen,uiPdschSymbolValidFlg);
    dbgInfoEx("%s uiCrsSymbolValidFlg is %d,uiPbchModuleTypeSel is %d,uiPbchStartPos is %d,uiPbchReLen is %d,uiPbchSymbolValidFlg is %d,uiPbchAbstractFlg is %d\n", __FUNCTION__,
            uiCrsSymbolValidFlg,uiPbchModuleTypeSel,uiPbchStartPos,uiPbchReLen,uiPbchSymbolValidFlg,uiPbchAbstractFlg);
    dbgInfoEx("%s uiSssModuleTypeSel is %d,uiSssSymbolValidFlg is %d,uiPssSymbolValidFlg is %d\n", __FUNCTION__,
            uiSssModuleTypeSel,uiSssSymbolValidFlg,uiPssSymbolValidFlg);

    if((EVM_MODULE_NUM <= uiPbchModuleTypeSel)||(EVM_MODULE_NUM <= uiPdschModuleTypeSel)||(uiSymbolLen <= uiPbchStartPos)||(uiSymbolLen <= uiPdschStartPos))
    {
        return BSP_ERROR;
    }

    //空间分配
    pfFreqPbchRealData      = (FLOAT *)malloc(sizeof(FLOAT)*uiPbchReLen);
    if(NULL == pfFreqPbchRealData)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfFreqPbchImagData      = (FLOAT *)malloc(sizeof(FLOAT)*uiPbchReLen);
    if(NULL == pfFreqPbchImagData)
    {
        free(pfFreqPbchRealData);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    //Pdsch
    if(1 == uiPdschSymbolValidFlg)
    {
        BspQamGen[uiPdschModuleTypeSel](&puiOrgRandomData[uiSlotIndexAdj*LTE_SYMBOL_NUM*uiValidScNum+uiSymbolIndex*uiValidScNum],uiPdschReLen,&pfFreqDataReal[uiPdschStartPos],&pfFreqDataImag[uiPdschStartPos]);
    }
    //Pbch QPSK
    if(1 == uiPbchSymbolValidFlg)
    {
        //48RE
        if(1 == uiPbchAbstractFlg)
        {
            ///对PBCH位置进行清0
            memset(&pfFreqDataReal[uiPbchStartPos], 0x0, sizeof(FLOAT)* uiPbchReLen);
            memset(&pfFreqDataImag[uiPbchStartPos], 0x0, sizeof(FLOAT)* uiPbchReLen);
            ///生成数据源
            BspQamGen[uiPbchModuleTypeSel](&puiOrgRandomData[uiSlotIndexAdj*LTE_SYMBOL_NUM*uiValidScNum+uiSymbolIndex*uiValidScNum],uiPbchReLen,pfFreqPbchRealData,pfFreqPbchImagData);
            ///设置位置
            InsertLtePbchSeq(pfFreqPbchRealData, pfFreqPbchImagData,ptCellInfoModuDatGen,&pfFreqDataReal[uiPbchStartPos],&pfFreqDataImag[uiPbchStartPos]);
        }
        else
        {
            BspQamGen[uiPbchModuleTypeSel](&puiOrgRandomData[uiSlotIndexAdj*LTE_SYMBOL_NUM*uiValidScNum+uiSymbolIndex*uiValidScNum],uiPbchReLen,&pfFreqDataReal[uiPbchStartPos],&pfFreqDataImag[uiPbchStartPos]);
        }
    }

    ///Pss sss
    InsertLteSssOrPss(uiPssSymbolValidFlg,uiSssSymbolValidFlg,uiSymbolLen,ptCellInfoModuDatGen,pfFreqDataReal,pfFreqDataImag);

    //CRS
    if(1 == uiCrsSymbolValidFlg)
    {
        CrsRefDataGen(uiSlotIndex,uiSymbolIndex,ptCellInfoModuDatGen,pfFreqDataReal,pfFreqDataImag);
    }

    //直流子载波
    InsertLteDc(pfFreqDataReal,pfFreqDataImag,uiSymbolLen);

    free(pfFreqPbchRealData);
    free(pfFreqPbchImagData);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGenLteSubframeData
 * 功能描述: 生成子帧级时域数据
 * 输入参数: ptCellInfoModuDatGen - 入参
 * 输出参数: puiTimeData - 时域数据
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenLteSubframeData(T_CellInfoModuDatGen *ptCellInfoModuDatGen,UINT32 *puiTimeData)
{
    UINT32      uiSymbolNum     = 0 ;
    UINT32      uiSymbolNumLoop = 0 ;
    UINT32      uiSymbolLen     = 0 ;
    UINT32      uiSymbolCp0Len  = 0 ;
    UINT32      uiSymbolCp1Len  = 0 ;
    UINT32      uiDatLen        = 0 ;
    UINT32      uiDataSlotLen   = 0 ;
    UINT32      uiValidScNum    = 0 ;
    UINT32      uiSubFrameNumb  = 0 ;
    UINT32      uiSlotNumPerSubFrame = 0;
    UINT32      uiSlotIndex     = 0 ;
    UINT32      uiSlotLoop      = 0 ;
    UINT32      uiSymbolCpIndex = 0 ;
    FLOAT      *pfFreqDataReal  = NULL ;
    FLOAT      *pfFreqDataImag  = NULL ;
    FLOAT      *pfTimeDataReal  = NULL ;
    FLOAT      *pfTimeDataImag  = NULL ;
    FLOAT      *pfOrgTimeDataReal  = NULL ;
    FLOAT      *pfOrgTimeDataImag  = NULL ;
    INT32      *puiOrgRandomData = NULL ;
    CHAR pcFileName1[30] = "/opt_timedata.txt";

    //参数获取
    uiSymbolNum              = ptCellInfoModuDatGen->tLteCellInfoCommon.uiSymbolNum; //7个
    uiSymbolCp0Len           = ptCellInfoModuDatGen->tLteCellInfoCommon.uiSymbolCp0Len;
    uiSymbolCp1Len           = ptCellInfoModuDatGen->tLteCellInfoCommon.uiSymbolCp1Len;
    uiSymbolLen              = ptCellInfoModuDatGen->tLteCellInfoCommon.uiSymbolLen;
    uiValidScNum             = ptCellInfoModuDatGen->tLteCellInfoCommon.uiValidScNum;
    uiSubFrameNumb           = ptCellInfoModuDatGen->tLteCellInfoCommon.uiSubFrameNumb ;
    uiSlotNumPerSubFrame     = ptCellInfoModuDatGen->tLteCellInfoCommon.uiSlotNumPerSubFrame; //2个
    uiSlotIndex              = uiSubFrameNumb * uiSlotNumPerSubFrame ;

    dbgInfoEx("%s uiSymbolNum is %d,uiSymbolCp0Len is %d,uiSymbolCp1Len is %d,uiSymbolLen is %d,uiValidScNum is %d,uiSubFrameNumb is %d,uiSlotNumPerSubFrame is %d,uiSlotIndex is %d,\n", __FUNCTION__,
            uiSymbolNum,uiSymbolCp0Len,uiSymbolCp1Len,uiSymbolLen,uiValidScNum,uiSubFrameNumb,uiSlotNumPerSubFrame,uiSlotIndex);

    //申请空间
    pfFreqDataReal      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen));
    if(NULL == pfFreqDataReal)
    {
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfFreqDataImag      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen));
    if(NULL == pfFreqDataImag)
    {
        free(pfFreqDataReal);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfTimeDataReal      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
    if(NULL == pfTimeDataReal)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfTimeDataImag      = (FLOAT *)malloc(sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
    if(NULL == pfTimeDataImag)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    puiOrgRandomData    = (INT32 *)malloc(sizeof(UINT32)*(uiValidScNum*uiSymbolNum*uiSlotNumPerSubFrame));
    if(NULL == puiOrgRandomData)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        free(pfTimeDataImag);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfOrgTimeDataReal   = (FLOAT *)malloc(sizeof(FLOAT)*SLOT_TIMEDATA_LEN);
    if(NULL == pfOrgTimeDataReal)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        free(pfTimeDataImag);
        free(puiOrgRandomData);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pfOrgTimeDataImag   = (FLOAT *)malloc(sizeof(FLOAT)*SLOT_TIMEDATA_LEN);
    if(NULL == pfOrgTimeDataImag)
    {
        free(pfFreqDataReal);
        free(pfFreqDataImag);
        free(pfTimeDataReal);
        free(pfTimeDataImag);
        free(puiOrgRandomData);
        free(pfOrgTimeDataReal);
        dbgInfo("%s malloc failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    //生成随机数
    BspGenRandomData(uiValidScNum*uiSymbolNum*uiSlotNumPerSubFrame,puiOrgRandomData);

    //生成子帧数据
    for(uiSlotLoop = uiSlotIndex; uiSlotLoop < uiSlotIndex + 2; uiSlotLoop++)
    {
        //按照符号生成频域数据
        for(uiSymbolNumLoop = 0;uiSymbolNumLoop < uiSymbolNum ;uiSymbolNumLoop++)
        {
            ptCellInfoModuDatGen->tNrOrLteDataIndex.uiSymbolIndex = uiSymbolNumLoop ;
            ptCellInfoModuDatGen->tNrOrLteDataIndex.uiSlotIndex   = uiSlotLoop ;
            uiSymbolCpIndex = ptCellInfoModuDatGen->tLteCellInfoCommon.auiSymbolCpIndex[uiSymbolNumLoop];
            ///空间清0
            memset(pfFreqDataReal,0,sizeof(FLOAT)*(uiSymbolLen));
            memset(pfFreqDataImag,0,sizeof(FLOAT)*(uiSymbolLen));
            memset(pfTimeDataReal,0,sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
            memset(pfTimeDataImag,0,sizeof(FLOAT)*(uiSymbolLen+uiSymbolCp0Len));
            //生成频域数据
            BspGenLteSymbolFreqData(ptCellInfoModuDatGen,puiOrgRandomData,pfFreqDataReal,pfFreqDataImag);
            //FftShift
            BspFftShift(pfFreqDataReal,pfFreqDataImag,pfFreqDataReal,pfFreqDataImag,uiSymbolLen);
            //IFFT
            BspFreqDataToTimeData(ptCellInfoModuDatGen,pfFreqDataReal,pfFreqDataImag,pfTimeDataReal,pfTimeDataImag);
            //时域信号增加CP
            BspTimeDataAddCp(ptCellInfoModuDatGen,uiSymbolCpIndex,pfTimeDataReal,pfTimeDataImag,&uiDatLen);
            //峰均比计算 cov
            if(uiDataSlotLen < SLOT_TIMEDATA_LEN)
            {
                BspTimeDataAvgMaxRatioCal(ptCellInfoModuDatGen,uiDatLen,pfTimeDataReal,pfTimeDataImag);
            }
            //符号拼接
            BspTimeDataCombine(pfTimeDataReal,pfTimeDataImag,uiDatLen,&pfOrgTimeDataReal[uiDataSlotLen],&pfOrgTimeDataImag[uiDataSlotLen]);
            //位置计算
            uiDataSlotLen = uiDataSlotLen + uiDatLen ;
        }
    }
    //功率定标
    BspDataPwrAdj(ptCellInfoModuDatGen,pfOrgTimeDataReal,pfOrgTimeDataImag,uiDataSlotLen);
    //将IQ信号拼接在一起，高I，低Q
    BspCombineSymbolData(pfOrgTimeDataReal,pfOrgTimeDataImag,uiDataSlotLen,puiTimeData);
    //记录
    WriteUintDataFile((UINT32 *)&puiTimeData[0], uiDataSlotLen, pcFileName1);

    free(pfFreqDataReal);
    free(pfFreqDataImag);
    free(pfTimeDataReal);
    free(pfTimeDataImag);
    free(puiOrgRandomData);
    free(pfOrgTimeDataReal);
    free(pfOrgTimeDataImag);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGenLteEvmData
 * 功能描述: Lte在线源生成模块
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGenLteEvmData()
{
    //变量初始化
    memset(g_uiEvmTimeData,0,sizeof(UINT32)*SLOT_TIMEDATA_LEN);
    //时域数据生成
    BspGenLteSubframeData(&g_atCellInfoModuDatGen,g_uiEvmTimeData);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetEvmData
 * 功能描述: 获取源数据
 * 输入参数:
 * 输出参数:
 * 返 回 值:
 * 其它说明: 无
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2023年01月29日     创建
 **************************************************************************/
UINT32 BspGetEvmData(UINT32 *puiEvmDat,UINT32 uiDatLen)
{
    if((NULL == puiEvmDat)||(SLOT_TIMEDATA_LEN < uiDatLen))
    {
        return BSP_ERROR ;
    }

    memcpy_s(&puiEvmDat[0],uiDatLen*sizeof(UINT32),&g_uiEvmTimeData[0],uiDatLen*sizeof(UINT32));

    return BSP_OK;
}

///保存数据
UINT32 WriteUintDataFile(UINT32 *buf, UINT32 len, const char* filename)
{
    FILE *fd = NULL;
    UINT32 uindex    = 0;
    INT32 lFprtfRet  = 0;
    INT32 fret       = 0;
    UINT32 tempBuf   = 0;
    rsize_t dirlist_size = 1;
    CHAR  *const dirlist[1] = {"/"};
    INT32 iFopenRet = 0;

    iFopenRet = zte_fopen_s(&fd, filename, "w+r", dirlist, dirlist_size);
    if (0 != iFopenRet)
    {
        dbgInfo("fopen Error!!\n");
        return BSP_ERROR;
    }

    for(uindex = 0;uindex<len;uindex ++)
    {
        tempBuf = buf[uindex];
        lFprtfRet = fprintf_s(fd, "0x%08x,\n", tempBuf);
        if(-1 == lFprtfRet)
        {
            fret = fclose(fd);
             if(-1 == fret)
             {
                 dbgInfo("fclose Error,fret is %d\n",fret);
             }
            return ERROR;
        }
    }
    fret = fclose(fd);
    if(-1 == fret)
    {
        return ERROR;
    }

    return OK;
}




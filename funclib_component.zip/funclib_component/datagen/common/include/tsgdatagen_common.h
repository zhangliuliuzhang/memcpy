/*
 * tsgdatagen_common.h
 *
 *  Created on: 2023年4月17日
 *      Author: 10144629
 */

#ifndef PLATFORM_BSP_FUNCLIB_COMPONENT_DATAGEN_COMMON_INCLUDE_TSGDATAGEN_COMMON_H_
#define PLATFORM_BSP_FUNCLIB_COMPONENT_DATAGEN_COMMON_INCLUDE_TSGDATAGEN_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bspbasetype.h"


#define SLOT_LOCATION          14         //时隙位置
#define MAX_DMRS_NUM           4

#define TYPE1_PORT_NUM         8          //type1端口数8
#define TYPE1WF_K_NUM          2          //type1k'取值0，1
#define TYPE1WT_L_NUM          2          //type1l'取值0，1

#define TYPE2_PORT_NUM         12         //type2端口数12
#define TYPE2WF_K_NUM          2          //type2k'取值0，1
#define TYPE2WT_L_NUM          2          //type2l'取值0，1

#define TYPEA_SINGLE_NUM            4   //typeAsingle加法位置
#define TYPEA_SINGLE_ADD_NUM        4   //typeAsingle加法位置
#define TYPEA_SINGLE_SYMBOLS_NUM    14  //typeAsingle标志位

#define TYPEB_SINGLE_NUM            4   //typeBsingle加法位置
#define TYPEB_SINGLE_ADD_NUM        4   //typeBsingle加法位置
#define TYPEB_SINGLE_SYMBOLS_NUM    14  //typeBsingle标志位

#define TYPEA_DOUBLE_NUM            2   //typeAdouble加法位置
#define TYPEA_DOUBLE_ADD_NUM        2   //typeAdouble加法位置
#define TYPEA_DOUBLE_SYMBOLS_NUM    14  //typeAdouble标志位

#define TYPEB_DOUBLE_NUM            2   //typeBdouble加法位置
#define TYPEB_DOUBLE_ADD_NUM        2   //typeBdouble加法位置
#define TYPEB_DOUBLE_SYMBOLS_NUM    14  //typeBdouble标志位
#define DMRSSYMBFREQ_NUM            4096  //Dmrs频域数据长度

#define PI                          3.14159265358979323846   ///PI的宏定义
#define SLOT_TIMEDATA_LEN           61440               //0.5ms的slot时域长度
#define BAND_NUM                    12    //带宽数目
#define SCS_NUM                     2     //子载波间隔数目
#define DATA_MODE_NUM               5     //数据源类型
#define TM2MODE_POS_NUM             3     //数据位置数目
#define SLOT_NUM                    10    //slot数目
#define PDCCH_SYMBOLE_NUM           3    //pdcch占用符号数目
#define SCS_15KHZ                   15    //15K子载波间隔
#define RADIO_MODE_NUM              2     //支持NR和LTE
#define EVM_MODULE_NUM              3

///////LTE
#define PORT0                       0
#define PORT1                       1
#define CRS_GAP                     6
#define RB_NUM_LTE_MAX              110
#define CRS_NUM_PER_RB              2
#define PBCH_RB_NUM                 6
#define SLOT_NUM_PER_SUBFRAME       2
#define CRS_SYMBOL_PER_SLOT         2
#define LTE_SYMBOL_NUM              7
#define LTE_PBCH_GAP                3
#define LTE_PBCH_SHIFTA             0
#define LTE_PBCH_SHIFTB             2
#define LTE_SSS_LEN                 72
#define LTE_SSS_PR_LEN              5
#define FDD_DATA_MODE               0x1
#define AAU_DATA_MODE               0x1
#define NR_DATA_MODE                0x1
#define TDD_DATA_MODE               0x0
#define RRU_DATA_MODE               0x0
#define LTE_DATA_MODE               0x0
#define DATA_BANDWIDTH_100M_MHz    100
#define DATA_BANDWIDTH_90M_MHz     90
#define DATA_BANDWIDTH_80M_MHz     80
#define DATA_BANDWIDTH_70M_MHz     70
#define DATA_BANDWIDTH_60M_MHz     60
#define DATA_BANDWIDTH_50M_MHz     50
#define DATA_BANDWIDTH_40M_MHz     40
#define DATA_BANDWIDTH_30M_MHz     30
#define DATA_BANDWIDTH_20M_MHz     20
#define DATA_BANDWIDTH_15M_MHz     15
#define DATA_BANDWIDTH_10M_MHz     10
#define DATA_BANDWIDTH_5M_MHz      5

#define DATA_RATE_122P88          122880
#define DATA_RATE_92P16           92160
#define DATA_RATE_61P44           61440
#define DATA_RATE_46P08           46080
#define DATA_RATE_30P72           30720
#define DATA_RATE_23P04           23040
#define DATA_RATE_15P36           15360
#define DATA_RATE_7P68            7680

#define DATA_FFT_LEN_MAX          16384
#define PSS_INDEX_NUM                 3


typedef struct T_CellInfoPdcch
{
    UINT32 uiPdcchStartPos                                       ; //pdcch的起始位置
    UINT32 uiPdcchReLen                                          ; //pdcch RE为单位的频域长度
    UINT32 uiPdcchSchReLen                                       ; //pdcch 填充时 的pdsch长度
    UINT32 uiPdcchFdmOnOrOff                                     ; //pdcch fdmon or fdmoff
    UINT32 uiaPdcchTimeSymbolValFlg[TYPEA_SINGLE_SYMBOLS_NUM]    ; //pdcch 符号有效标志 1表示有效，0表示无效
}T_CellInfoPdcch;

typedef struct T_CellInfoPdsch
{
    UINT32 uiModuleTypeSel                                     ; //QMSK,64QAM或256AQM
    UINT32 uiPdschReLen                                         ; //Pdsch Len
    UINT32 uiPdschStartPos                                      ; //Pdsch StartPos
}T_CellInfoPdsch;

typedef struct T_CellInfoDmrs
{
    UINT32 uiDmrsMapType         ; //DMRS的TypeA、B
    UINT32 uiLimits              ; //DMRS的单双符号
    UINT32 uiDmrsAddPos          ; //DMRS符号增加的位置
    UINT32 uiDmrsFirstPos        ; //DMRS 第一个符号位置
    UINT32 uiPdschLength         ; //PdschLen
    UINT32 uiDmrsLdLength        ; //DMRS TypeB的长度
    UINT32 uiDmrsNum             ; //DMRS 个数
    UINT32 uiCellId              ; //DMRS的cellid
    UINT32 uiDmrsType            ;
    UINT32 uiSymbolLen           ;
    UINT32 uiPortId              ;
    UINT32 uiSlot                ;
    UINT32 uiScId                ;
    UINT32 uiValidScNum          ;
    INT32  iScaleTmp             ;
    UINT32 uiDmrsReEndPos        ;
    UINT32 uiDmrsReStartPos      ;
    UINT32 uiDmrsPos             ; //DMRS 位置
    UINT32 uiDmrsAddPdschFlg     ; //DMRS 插花标记 1表示插花 0表示不插花
    UINT32 uiDmrsPosSymbolValFlg[TYPEA_SINGLE_SYMBOLS_NUM]    ; //dmrs 符号有效标志 1表示有效，0表示无效
}T_CellInfoDmrs;

typedef struct T_CellInfoCommon
{
    UINT32 uiSymbolNum                                      ; //符号个数
    UINT32 uiSymbolCp0Len                                   ; //CP0长度
    UINT32 uiSymbolCp1Len                                   ; //CP1长度
    UINT32 auiSymbolCpIndex[TYPEA_SINGLE_SYMBOLS_NUM]        ; //CP长度指示
    UINT32 uiScs                                            ; //子载波间隔
}T_CellInfoCommon;

typedef struct T_NrorLteCellInfoCommon
{
    INT32  iSetFixValue                                     ; //定标值 单位是0.1dbfs，如果需要-1dbfs，则需要配置-10
    INT32  iSignalWidthLen                                  ; //信号位宽
    UINT32 uiSymbolCp0Len                                   ; //CP0长度
    UINT32 uiSymbolCp1Len                                   ; //CP1长度
    UINT32 uiSymbolLen                                      ; //符号长度
}T_NrorLteCellInfoCommon;

typedef struct T_CellInfoCalcSta
{
    FLOAT  fMaxMeanRatio[TYPEA_SINGLE_SYMBOLS_NUM]         ; //峰均比
}T_CellInfoCalcSta;

typedef struct{
    INT32 ifftsize; /**<FFT长度*/
    INT32 idftsize; /**<dft基底长度PFFT*/
    INT32 ibtfnum;  /**<fft蝶形级数PFFT*/
    INT32 iMode;    /**<纯fft模式 or dft+fft,PFFT*/
    INT32 iRadix;   /**<FFT基，4的整数次幂必须用基4，2的整数次幂非4的整数次幂必须用基2*/
    INT32 ifftflag; /*用以标识IFFT/FFT的旋转因子，1：IFFT,0：FFT*/
    FLOAT *pftrW;   /**<Pointer to complex twiddle factor,实虚交织排列*/
    FLOAT *pfdftW;  /**<旋转因子实虚交织排列,PFFT*/
    UINT8 *pucRev;  /**<Pointer to bit reverse table containing 64 entries，实数*/
    INT32 *pidftidx;/**<时域抽取映射索引,PFFT*/
}T_FftPara;
/////////LTE
typedef struct T_LteCellInfoPbch
{
    UINT32 uiPbchModuleTypeSel                                   ; //QMSK,64QAM或256AQM
    UINT32 uiPbchReLen                                         ; //Pbch Len
    UINT32 uiPbchStartPos                                      ; //Pbch StartPos
    UINT32 uiPbchSymbolValidFlg[SLOT_NUM_PER_SUBFRAME][LTE_SYMBOL_NUM];//Pbch VailidFlg
    UINT32 uiPbchAbstractFlg[SLOT_NUM_PER_SUBFRAME][LTE_SYMBOL_NUM];//Pbch 48Re有效标志
    UINT32 uiPbchGap                                           ;
    UINT32 uiPbchPosShiftA                                     ;  ///Pbch偏移位置A
    UINT32 uiPbchPosShiftB                                     ; ///Pbch偏移位置B
}T_LteCellInfoPbch;

typedef struct T_LteCellInfoSss
{
    UINT32 uiSssModuleTypeSel                                 ; //QMSK,64QAM或256AQM
    UINT32 uiSssReLen                                         ; //Sss Len
    UINT32 uiSssStartPos                                      ; //Sss StartPos
    UINT32 uiSssProtectReLen                                  ; //Sss 保护长度
    UINT32 uiSssSymbolValidFlg[SLOT_NUM_PER_SUBFRAME][LTE_SYMBOL_NUM];//Sss VailidFlg
    UINT32 uiPssSymbolValidFlg[SLOT_NUM_PER_SUBFRAME][LTE_SYMBOL_NUM];//Pss VailidFlg
}T_LteCellInfoSss;

typedef struct T_LteCellInfoPdsch
{
    UINT32 uiPdschModuleTypeSel                                 ; //QMSK,64QAM或256AQM
    UINT32 uiPdschReLen                                         ; //Pdsch Len
    UINT32 uiPdschStartPos                                      ; //Pdsch StartPos
    UINT32 uiPdschSymbolValidFlg[SLOT_NUM_PER_SUBFRAME][LTE_SYMBOL_NUM];//Pdsch VailidFlg
}T_LteCellInfoPdsch;

typedef struct T_LteCrsPara
{
    UINT32 Crs_v[LTE_SYMBOL_NUM];
    UINT32 Crs_v_shift;
    UINT32 uiCrsSymbolValidFlg[SLOT_NUM_PER_SUBFRAME][LTE_SYMBOL_NUM]; //Crs ValidFlg
}T_LteCrsPara;

typedef struct
{
    UINT32  uiCellId       ;
    UINT32  uiStartScNum   ;
    UINT32  uiValidRbNum   ;
    UINT32  uiSymbolLen    ;
    UINT32  uiSymbolNum    ;
    UINT32  uiValidScNum   ;
    UINT32  uiSymbolCp0Len ;
    UINT32  uiSymbolCp1Len ;
    UINT32  auiSymbolCpIndex[LTE_SYMBOL_NUM];
    UINT32  uiSubFrameNumb ;
    UINT32  uiSlotNumPerSubFrame;
}T_LteCellInfoCommon;

typedef struct tag_T_NR_LTE_DATA_INDEX
{
    UINT32 uiSlotIndex;
    UINT32 uiSymbolIndex;
}T_NrOrLteDataIndex;

typedef struct T_CellInfoModuDatGen
{
    T_NrorLteCellInfoCommon tNrorLteCellInfoCommon ;
    T_NrOrLteDataIndex     tNrOrLteDataIndex ;
    ///NR
    T_CellInfoDmrs     tCellInfoDmrs       ;
    T_CellInfoPdcch    tCellInfoPdcch      ;
    T_CellInfoPdsch    tCellInfoPdsch      ;
    T_CellInfoCommon   tCellInfoCommon     ;
    T_FftPara          tFftPara            ;
    T_CellInfoCalcSta  tCellInfoCalcSta    ;
    ///LTE
    T_LteCellInfoPbch     tLteCellInfoPbch       ;
    T_LteCellInfoSss      tLteCellInfoSss        ;
    T_LteCellInfoPdsch    tLteCellInfoPdsch      ;
    T_LteCrsPara          tLteCrsPara            ;
    T_LteCellInfoCommon   tLteCellInfoCommon     ;

}T_CellInfoModuDatGen;

typedef struct tag_T_EVM_DATA_PARA
{

    UINT32 uiNrOrLteMode;
    UINT32 uiAauorRruMode;
    UINT32 uiBandWidth;
    UINT32 uiSampleRate;

}T_EvmDataParaInfo;


typedef struct tag_T_ADV_PFFT_PARA
{
    INT32 Nfft;
    INT32 mbtf;
    INT32 ndft;
    INT32 iIfftFlg;
    FLOAT *ptr_x;
    FLOAT *ptr_w;
    FLOAT *ptr_w_dft;
    INT32 *pIdx;
    FLOAT *ptr_y;

}T_AdvPfftTranPara;

typedef struct tag_T_NR_LTE_DATA_PARA
{
    UINT32 uislot;
    UINT32 uiBandWidth;
    UINT32 uiDataType;
    UINT32 uiTddOrFddFlg;
    UINT32 uiAauOrRruFlg;
    UINT32 uiDataRate;
    UINT32 uiDatPwrN13DbfsFlg ;
}T_NrOrLteDataPara;



///函数声明
UINT32 BspQAM64Gen(INT32 *piOrgData,UINT32 uiOrgDataLen,FLOAT *pfModulRealData,FLOAT *pfModulImagData);
UINT32 BspQAM256Gen(INT32 *piOrgData,UINT32 uiOrgDataLen,FLOAT *pfModulRealData,FLOAT *pfModulImagData);
UINT32 BspQPSKGen(INT32 *piOrgData,UINT32 uiOrgDataLen,FLOAT *pfModulRealData,FLOAT *pfModulImagData);
typedef UINT32 (*BspQAMGenCalFunction)(INT32 *piOrgData,UINT32 uiOrgDataLen,FLOAT *pfModulRealData,FLOAT *pfModulImagData);
UINT32 WriteUintDataFile(UINT32 *buf, UINT32 len, const char* filename);
UINT32 BspGenLteEvmData();
UINT32 BspGenNrEvmData();
UINT32 BspGetEvmData(UINT32 *puiEvmDat,UINT32 uiDatLen);
UINT32 BspSetLteEvmPara(T_NrOrLteDataPara *ptNrOrLteDataPara);
UINT32 BspSetNrEvmPara(T_NrOrLteDataPara *ptNrOrLteDataPara);

#ifdef __cplusplus
}
#endif


#endif /* PLATFORM_BSP_FUNCLIB_COMPONENT_DATAGEN_COMMON_INCLUDE_TSGDATAGEN_COMMON_H_ */


#ifndef _BOARDMODLECOMMON_H_
#define _BOARDMODLECOMMON_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"
#include "boardmodleapi.h"
/**************************************************************************
 *                               宏定义
 **************************************************************************/

//todo 单板下board.h中的公共枚举及宏定义后续迁移到此处(例如SIZE类的宏定义)


/* 组件 */
#define BOARD_SOFT_SERVICE_ACT_BASE (0)
#define BOARD_HARD_FEATURE_ACT_BASE (1000)
#define BOARD_CHIP_POWERON_ACT_BASE (2000)
#define BOARD_DIG_TRX_LINK_ACT_BASE (3000)
#define BOARD_FUNCTION_ACT_BASE     (4000)
#define BOARD_TEMPRARY_ACT_BASE     (5000)
#define BOARD_COMPO_ACT_SPACE       (1000)

#define DEEP_LEVEL1  (1)                /* 直接存储数据参数的地址和维度 */
#define DEEP_LEVEL2  (2)                /* 存储配置方案数据的地址和维度 */
#define DEEP_LEVEL2_BYCHIP  (3)         /* 存储配置方案数据的地址和维度,方案选择依赖于chipid */

#define BOARD_MATCH_ID_MAX  (6)         /*目前存在最大6片IC的机型*/
#define BOARD_INVALID_MATCH_ID (0xFFFF)
#define BOARD_ACT_DATA_MAX  (4)         /* 每个初始化动作支持的最大数据组数 */
#define BOARD_CFG_DATA_PART_MAX  (4)    /* 每个配置支持的数据组数 */
#define BOARD_ACT_NAME_LEN  (32)
#define BOARD_COMPO_ACT_MAX  (100)      /* 每个单板功能组件包含的最大初始化动作数 */

#define DATA_PART_MAX (5)
#define PWR_UPDATE_FLAG            (1)
#define PWR_NO_UPDATE_FLAG         (0)

/* 获取功能项目对应的数据和维度,以下情况会直接返回BSP_ERROR 
    (1)查找数据过程中出错；
    (2)LEVEL2的数据在boardconfig中未指定配置方案；
    (3)查找到的数据地址为NULL；
*/
#define BOARD_MODLE_GET_DATA(actType,pos,part,pPara,num)             \
    retVal = BspBoardModleGetData(actType, pos, part, (VOID**)(&pPara), &(num));  \
    if(BSP_OK != retVal)                                        \
    {                                                           \
        return BSP_ERROR;                                       \
    }                                                           \
    if(!pPara)                                                  \
    {                                                           \
        return BSP_ERROR;                                       \
    }

/* 非数组形式的LEVEL1 数据 */
#define BOARD_MODLE_SET_LEVEL1_DATA(atctype,pos,data) \
        BspBoardModleSetData(atctype,pos,DEEP_LEVEL1,(VOID*)(&data), 1, sizeof(data));

/* 数组形式的LEVEL1 数据 */
#define BOARD_MODLE_SET_LEVEL1_ARRAY(atctype,pos,data) \
        BspBoardModleSetData(atctype,pos,DEEP_LEVEL1,(VOID*)data, NELEMENTS(data), sizeof(data[0]));

/* 数组形式的LEVEL2 数据 */
#define BOARD_MODLE_SET_LEVEL2_ARRAY(atctype,pos,data) \
        BspBoardModleSetData(atctype,pos,DEEP_LEVEL2,(VOID*)data, NELEMENTS(data), 0);

/* 数组形式的LEVEL2_BYCHIP 数据 */
#define BOARD_MODLE_SET_LEVEL2_BYCHIP_ARRAY(atctype,pos,data) \
        BspBoardModleSetData(atctype,pos,DEEP_LEVEL2_BYCHIP,(VOID*)data, NELEMENTS(data), 0);

/* 文件解析用的数据及布局信息存储空间初始化 */
#define BOARD_MODLE_GROUP_INIT(actType,idx,name)                                           \
    static T_DataCfgGroup s_dataGrp##name;                                                 \
    static T_DataLayoutGrp s_layoutGrp##name;                                              \
    if(BSP_OK != BspBoardModleGroupInit(actType,idx,&s_dataGrp##name,&s_layoutGrp##name))  \
    {                                                                                      \
        dbgErr("%s %s err!\n", __func__, #name);                                           \
        return;                                                                 \
    }

#define BSP_INIT_NOT_RECORD                BSP_ERROR

#ifndef CHECK_RETVAL
#define CHECK_RETVAL(str, retVal)               \
    if (BSP_OK != retVal)                       \
    {                                           \
        dbgErr("%s %s err!\n", __func__, #str); \
        return retVal;                          \
    }
#endif

#define CHECK_CRITICAL_ERR(str, retVal)                                         \
    if (BSP_OK != retVal)                                                       \
    {                                                                           \
        dbgErr("[!!!] ---  %s %s critical error! --- [!!!]\n", __func__, #str); \
        return retVal;                                                          \
    }

#define boardInitLog(level,fmt...)    BspLogPrint(BspLogAdd("boardInit",DEFAULT_LOG_LEVEL),level,##fmt)

/**************************************************************************
 *                         数据类型
 **************************************************************************/

typedef UINT32 (*FUNC_GET_MATCH_ID)(VOID);
typedef UINT32 (*FUNC_BOARD_INIT_ACT)(VOID);
typedef UINT32 (*FUNC_CHANGE_INIT_FLOW)(VOID);
typedef UINT32 (*FUNC_CONFIG_INIT_FLOW)(UINT32 boardType);
typedef VOID (*FUNC_SET_BOARD_DATA)(VOID);
typedef UINT32 (*FUNC_GET_BD_SUB_ID)(VOID);

/* 单板模型功能组件种类 */
enum E_BOARD_COMPONENT_TYPE
{
    E_BOARD_SOFT_SERVICE_COMPO = 0,     /* 单板系统软件服务初始化组件 */
    E_BOARD_HARD_FEATURE_COMPO,         /* 单板硬件特性、硬件互联关系初始化功能组件 */
    E_BOARD_CHIP_POWERON_COMPO,         /* 周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件 */
    E_BOARD_DIG_TRX_LINK_COMPO,         /* 数字TX/RX/FB三大链路初始化功能组件 */
    E_BOARD_FUNCTION_COMPO,             /* 单板业务功能初始化组件 */
    E_BOARD_TEMPRARY_COMPO,             /* 单板临时功能初始化组件 */
    E_BOARD_COMPO_TYPE_MAX
};

enum E_BOARD_POWERON_TYPE
{
    E_POWERON_BOARD_PREINIT = 0,
    E_POWERON_BOARD_INIT,
    E_POWERON_RFTR_INIT,
    E_POWERON_PA_INIT,
    E_POWERON_NUM
};

#if 0
/* 传递到单板模型中的单板数据(可能为1层数据，也可能为2层数据) */
typedef struct tagT_BoardDataGroup
{
    UINT32   deep;   /* 数据深度 */
    VOID*    addr;   /* 数据地址 */
    UINT32   size;   /* 数据组数 */
}T_BoardDataGroup;
#endif

/* 配置方案表(用于定义数据和配置方案的对应关系) */
typedef struct tagT_DataCfgGroup
{
    //UINT8    cfgIdx; /* 配置方案索引号 */
    VOID*    addr;     /* Part0 第0部分数据地址 */
    UINT32   num;      /* Part0 第0部分数据元素数 */
    UINT32   size;     /* Part0 第0部分数据元素大小 */
    VOID*    addr1;    /* Part1 第1部分数据地址 */
    UINT32   num1;     /* Part1 第1部分数据元素数 */
    UINT32   size1;    /* Part1 第1部分数据元素大小 */
    VOID*    addr2;    /* Part2 第2部分数据地址 */
    UINT32   num2;     /* Part2 第2部分数据元素数 */
    UINT32   size2;    /* Part2 第2部分数据元素大小 */
    VOID*    addr3;    /* Part3 第3部分数据地址 */
    UINT32   num3;     /* Part3 第3部分数据元素数 */
    UINT32   size3;    /* Part3 第3部分数据元素大小 */
    VOID*    addr4;    /* Part3 第4部分数据地址 */
    UINT32   num4;     /* Part3 第4部分数据元素数 */
    UINT32   size4;    /* Part3 第4部分数据元素大小 */

}T_DataCfgGroup;

/* 数据布局信息，用于按照数据布局解析数据文件 */
typedef struct tagT_DataLayoutGrp
{
    VOID*    layout;       /* Part0 数据布局信息 */
    UINT32   version;      /* Part0 数据布局的版本 */
    VOID*    layout1;      /* Part1 数据布局信息 */
    UINT32   version1;     /* Part1 数据布局的版本 */
    VOID*    layout2;      /* Part2 数据布局信息 */
    UINT32   version2;     /* Part2 数据布局的版本 */
    VOID*    layout3;      /* Part3 数据布局信息 */
    UINT32   version3;     /* Part3 数据布局的版本 */
    VOID*    layout4;      /* Part4 数据布局信息 */
    UINT32   version4;     /* Part4 数据布局的版本 */
}T_DataLayoutGrp;

/* 功能组件配置方案表 */
typedef struct tagT_CoreMatchInfo
{
    //UINT32  matchId;  /* 根据FUNC_GET_MATCH_ID的返回值进行配置方案选择 */
    UINT8   cfgIdxArray[BOARD_COMPO_ACT_MAX]; /* 组件内各动作对应的配置方案 */
}T_CompoActCfgIdxInfo;

/* 组件配置方案表和单板的映射关系 */
typedef struct tagT_CoreActBoardMap
{
    T_CompoActCfgIdxInfo matchInfo[BOARD_MATCH_ID_MAX];
}T_CompoCfgIdxBoardMap;

/* 增加二级单板ID和配置方案的映射关系 */
typedef struct tagT_BoardSubIdCfgMap
{
    UINT32 boardId;
    UINT32 boardSubId;
    UINT32 chipId;
    UINT32 actType;
    UINT32 actCfg;
}T_BoardSubIdCfgMap;

/* 单板侧和单板模型之间的交互信息 */
typedef struct tagT_BoardInterFace
{
    UINT32 boardType;                       /* 单板类型 */
    UINT32 boardIdMax;                      /* 单板规格最大数量 */  
    UINT32 boardSubIdMax;                   /* 二级单板ID最大值 */  
    FUNC_GET_MATCH_ID pFuncGetMatchId;      /* 获取匹配Id的回调接口 */
    FUNC_GET_BD_SUB_ID pFuncGetBdSubId;     /* 获取二级单板Id的回调接口 */
    FUNC_CHANGE_INIT_FLOW pFuncPreLgcType;  /* 调整单板获取boardid之前的初始化流程的回调接口 */
    FUNC_CHANGE_INIT_FLOW pFuncPostLgcType; /* 调整单板初始化流程的回调接口，单板差异部分 */
    UINT32 VirtualboardId;                  /* 虚拟单板宏，用于在线加载初始化数据 */
    UINT32 VirtualSecboardId;               /* 虚拟单板二级宏，用于在线加载初始化数据 */
}T_BoardInterFace;

/* 在例化单板(例如boardmodle_ic4_2)和单板模型之间的交互信息 */
typedef struct tagT_InstanceInterFace
{
    UINT32 poweronNum;                   /* 既单板代码中的E_POWERON_NUM，对于主从CPU版本，该值可能不一样，需要传递进来 */
    UINT32 lgcTypeActType;               /* 第一次获取单板ID后对应的actType */
    FUNC_CONFIG_INIT_FLOW pFuncInitflow; /* 预置单板初始化流程的回调接口 */
}T_InstanceInterFace;

/* 初始化接口挂接表定义 */
typedef struct tagT_BoardActFuncTbl
{
    UINT32 actType;                         /* 动作类型 */
    FUNC_BOARD_INIT_ACT actFunc;            /* 初始化接口 */  
    CHAR *pActName;                         /* 初始化动作简要描述 */
    UINT32 initFlag;                        /* 初始化标志位 例如BSP_INIT_NOT_RECORD*/
}T_BoardActFuncTbl;

typedef struct tagT_BoardActFuncTblItem
{
    T_BoardActFuncTbl *pBoardActFuncTbl;
    UINT32 boardActFuncTblLen;
}T_BoardActFuncTblItem;


/**************************************************************************
*                         函数声明
**************************************************************************/

/* 单板模型相关接口 */
UINT32 BspBoardModleSetBoardId(UINT32 boardId);
UINT32 BspBoardModleSetLogFileName(const CHAR *logFileName);
UINT32 BspBoardModleBrdIfInit(T_BoardInterFace *pInterface);
UINT32 BspBoardModleInstanceIfInit(T_InstanceInterFace *pInterface);
UINT32 BspBoardModleGetData(UINT32 actType, UINT32 idx, UINT32 part, VOID **pData, UINT32 *pNum);
UINT32 BspBoardModleGetActType(UINT32 compoType, const CHAR *actNameStr, UINT32 *pActType);
UINT32 BspBoardModleSetActFunc(UINT32 actType, FUNC_BOARD_INIT_ACT pFunc, CHAR * actNameStr, UINT32 initFlag);
UINT32 BspBoardModleSetActByTbl(T_BoardActFuncTbl *pTbl, UINT32 num);
UINT32 BspBoardModleSetData(UINT32 actType, UINT32 idx, UINT32 deep, VOID *pData, UINT32 num, UINT32 size);
UINT32 BspBoardModleSetDataFunc(UINT32 compoType, FUNC_SET_BOARD_DATA pFunc);
UINT32 BspBoardModleSetBoardMap(UINT32 compoType, T_CompoCfgIdxBoardMap *pMap, UINT32 num);
UINT32 BspBoardModleSetBoardSubMap(T_BoardSubIdCfgMap *pSubMap, UINT32 itemNum);
UINT32 BspBoardModleSetBoardMapFunc(FUNC_SET_BOARD_DATA pFunc);
UINT32 BspBoardModleAddPreAction(UINT32 actType);
UINT32 BspBoardModleAddInitAction(UINT32 actType);
UINT32 BspBoardModleInsertNextAction(UINT32 refActType, UINT32 newActType);
UINT32 BspBoardModleInsertPrevAction(UINT32 refActType, UINT32 newActType);
UINT32 BspBoardModleDeleteAction(UINT32 targetActType);
UINT32 SetPowerOnFinished(UINT32 type);
UINT32 BspBoardModleSetActCfg(UINT32 actType, UINT8 cfgIdx);
UINT32 GetVirtualId(UINT32 *pVirtualId);
UINT32 BspGetBoardInitStat(VOID);

/* 提供给单板侧调用的预初始化接口 */
UINT32 BspBoardModlePreInit(VOID);
UINT32 BspBoardModleChangeActCfgBySubId(VOID);

/* 提供给单板侧调用的初始化接口 */
UINT32 BspBoardModleInit(VOID);
UINT32 BspGetBoardType(VOID);

/* 数据布局初始化接口 */
UINT32 BspBoardModleGroupInit(UINT32 actType, UINT32 idx, T_DataCfgGroup *pDataGrp, T_DataLayoutGrp *pLayOutGrp);
UINT32 BspBoardModleSetFileData(UINT32 actType, UINT32 idx, UINT32 part, VOID *pData, UINT32 num, UINT32 size);
UINT32 BspBoardModleSetDataLayout(UINT32 actType, UINT32 idx, UINT32 part, VOID *pLayout, UINT32 version);
UINT32 BspBoardModleGetDataLayout(UINT32 actType, UINT32 idx, UINT32 part, VOID **pLayout, UINT32 *version);
void BspSetPowerUpdateFlag(UINT32 flag);
void BspSetPwrSelfRescueFlag(UINT32 flag);

#ifdef __cplusplus
}
#endif

#endif /* _BOARDINIT_H_ */



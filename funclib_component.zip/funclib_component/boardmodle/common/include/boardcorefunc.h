
#ifndef _BOARDCOREFUNC_H_
#define _BOARDCOREFUNC_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"
#include "board_ic4_2.h"
#include "ichaladapt_ic4_2.h"

/**************************************************************************
 *                        宏
 **************************************************************************/

/**************************************************************************
 *                         数据类型
 **************************************************************************/
/* BSPLOG配置信息 */
typedef struct tagT_BspLogInitInfo
{
    UINT32 maxSize;         /* BSP LOG大小限制 */
    const CHAR  *logFileName;    /* BSPLOG文件名称 */
    UINT32 ulOptLogType;   /* 光口log所在进程类型 */
    UINT32 ulOptLogSize;    /* 光口log大小 */
}T_BspLogInitInfo;

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspCoreInitExPrn(VOID);
UINT32 BspCoreSignalInit(VOID);
UINT32 BspCoreInitStatCallBackInit(VOID);
UINT32 BspCoreBspLogInit(VOID);
UINT32 BspCoreInitLogBackup(VOID);

UINT32 BspCoreInitVerGroupPara(VOID);
UINT32 BspCoreInitDeviceIdList(VOID);
UINT32 BspCoreInitThresholdIdList(VOID);
UINT32 BspCoreInitFuncIdList(VOID);
UINT32 BspCoreInitGainIdList(VOID);

UINT32 BspInitAdpBdHwIdInfoPara(VOID);
UINT32 BspSerialLogToFlashInit(VOID);
UINT32 BspSaveBakLogSlave(VOID);
UINT32 BspGetCurLogForMasterTaskSlave(VOID);
UINT32 BspSaveKmsgLogSlave(VOID);
VOID BspChangeSlaveSerialLogDir(VOID);
VOID BspSlavePutSerialLogToMaster(VOID);
UINT32 BspOpenKenelSwitch(VOID);


#ifdef __cplusplus
}
#endif

#endif /* _BOARDCOREFUNC_H_ */



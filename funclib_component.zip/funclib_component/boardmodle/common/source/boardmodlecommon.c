/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardmodlecommon.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板模型的公共实现
* 注意事项 : 无
* 作    者 :   王涛10248577
* 创建日期 : 2022-03-23
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2022-03-23
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "boardmodlecommon.h"
#include "bspcomm.h"
#include "boardid.h"
#include "vxadp.h"
#include "funccommon_log.h"

/**************************************************************************
                                   宏定义
**************************************************************************/

#define BOARDMODLE_HELP_LEN (50)
#define BOARD_COMPO_NAME_LEN (32)
#define BOARD_FUNC_SET_DATA_MAX (10)

#define BSP_INIT_ERR_CODE_HARD_RST         2
#define BSP_INIT_ERR_CODE_SOFT_RST         1
#define BSP_INIT_ERR_CODE_NO_RST           0

#define CHECK_STATUS_PRE(funcName)                                                      \
{                                                                                       \
    BspLog(LOG_LEVEL_0, "%s enter.\n", funcName);                                    \
}

#define CHECK_STATUS_POST(ret, funcName, _funcRet, id)                                  \
{                                                                                       \
    ret = (_funcRet !=BSP_OK) ? BspGetErrInfo(id) : 0;                                  \
    BspLog(LOG_LEVEL_0, "%s exit.return %d %d\n",funcName,_funcRet,ret);             \
    dbgInfo("%s... %s(return %d)\n",funcName,(BSP_OK==_funcRet)?"OK":"ERROR",_funcRet); \
    if (ret == BSP_INIT_ERR_CODE_SOFT_RST || ret == BSP_INIT_ERR_CODE_HARD_RST)         \
    {                                                                                   \
        return ret;                                                                     \
    }                                                                                   \
}


/**************************************************************************
                                数据类型定义
**************************************************************************/
typedef struct tagT_ErrCodeInfo
{
    UINT32 devId;
    UINT32 errCode;
}T_ErrCodeInfo;

typedef struct tagT_BoardAction T_BoardAction;

/* 单板初始化动作的版本内置 */
typedef struct tagT_InitActData
{
    UINT32 deep;            /* 数据深度 */
    VOID*  addr;            /* 数据首地址 */    
    UINT32 num;             /* 数据维数 */    
    UINT32 size;            /* 数据size */
}T_BoardActData;

/* 存放文件解析出的初始化数据 */
typedef struct tagT_InitFileData
{
    VOID*  addr;            /* 数据首地址 */
    VOID*  layout;          /* 数据布局 */
}T_BoardFileData;

/* 单板初始化动作定义 */
typedef struct tagT_BoardAction
{
    UINT32 initFlag;
    UINT32 actType;
    CHAR actName[BOARD_ACT_NAME_LEN]; 
    T_BoardActData actDataArray[BOARD_ACT_DATA_MAX];   /* 存放版本内置数据 */
    T_BoardFileData fileDataArray[BOARD_ACT_DATA_MAX]; /* 存放文件解析出的数据 */
    FUNC_BOARD_INIT_ACT actFunc;
    T_BoardAction *prev;
    T_BoardAction *next;
}T_BoardAction;

/* 单板初始化 - 功能组件定义 */
typedef struct tagT_BoardComponent
{
    T_BoardAction action[BOARD_COMPO_ACT_MAX];
    FUNC_SET_BOARD_DATA funcSetData[BOARD_FUNC_SET_DATA_MAX];
    UINT32 funcNum;
    T_CompoCfgIdxBoardMap *pMap;
    UINT32 mapNum;
}T_BoardComponent;

/* 单板初始化模型 */
typedef struct tagT_BoardInitFlow
{
    T_BoardComponent compo[E_BOARD_COMPO_TYPE_MAX];
    FUNC_SET_BOARD_DATA funcSetBoardMap;
    /* 二级单板ID start */
    T_BoardSubIdCfgMap *pSubMap;
    UINT32 subMapItemNum;
    /* 二级单板ID end  */
}T_BoardInitFlow;

/* 单板对高层APP提供的接口模型 */
typedef struct tagT_BoardAppInterface
{
    FUNC_BOARD_RX_SERDES_REINIT FuncRxSerdesReInit;
    //...
}T_BoardAppInterface;

/* 单板模型定义 */
typedef struct tagT_BoardModle
{
    UINT32 boardId;                 /* 单板Id */
    const CHAR *logFileName;              /* BSP LOG文件名称 */
    T_BoardInterFace *pBoardIF;
    T_InstanceInterFace *pInstanceIF;
    T_BoardInitFlow initFlow;
    T_BoardAppInterface appInterface;
}T_BoardModle;


/**************************************************************************
                            公共全局变量
**************************************************************************/
static T_BoardModle s_tBoardModle = {0}; 

static T_BoardAction s_tPreInitActListHead = { 0 };
static T_BoardAction *s_ptPreInitActListEnd = &(s_tPreInitActListHead);

static T_BoardAction s_tInitActListHead = { 0 };
static T_BoardAction *s_ptInitActListEnd = &(s_tInitActListHead);

static CHAR s_BoardCompoNameStr[E_BOARD_COMPO_TYPE_MAX][BOARD_COMPO_NAME_LEN] =
{
    "BOARD_SOFT_SERVICE_COMPO",
    "BOARD_HARD_FEATURE_COMPO",
    "BOARD_CHIP_POWERON_COMPO",
    "BOARD_TRX_LINK_COMPO",
    "BOARD_FUNCTION_COMPO",
    "BOARD_TEMPRARY_COMPO"
};

#if 0 /* 暂时保留一段时间 */
static UINT32 s_CompoActTypeRange[E_BOARD_COMPO_TYPE_MAX][2] = 
{
    {BOARD_SOFT_SERVICE_ACT_BASE,    BOARD_SOFT_SERVICE_ACT_BASE+BOARD_COMPO_ACT_MAX},
    {BOARD_HARD_FEATURE_ACT_BASE,    BOARD_HARD_FEATURE_ACT_BASE+BOARD_COMPO_ACT_MAX},
    {BOARD_CHIP_POWERON_ACT_BASE,    BOARD_CHIP_POWERON_ACT_BASE+BOARD_COMPO_ACT_MAX},
    {BOARD_DIG_TRX_LINK_ACT_BASE,    BOARD_DIG_TRX_LINK_ACT_BASE+BOARD_COMPO_ACT_MAX},
    {BOARD_FUNCTION_ACT_BASE,        BOARD_FUNCTION_ACT_BASE+BOARD_COMPO_ACT_MAX},
    {BOARD_TEMPRARY_ACT_BASE,        BOARD_TEMPRARY_ACT_BASE+BOARD_COMPO_ACT_MAX}   
};
#endif

static T_ErrCodeInfo s_errCodeInfo[] =
{
    {BSP_DEVICE_ID_FLASH0,      BSP_INIT_ERR_CODE_HARD_RST},
    {BSP_DEVICE_ID_BOOT0,       BSP_INIT_ERR_CODE_HARD_RST},
    {BSP_DEVICE_ID_KDA,         BSP_INIT_ERR_CODE_NO_RST},//BSP_INIT_ERR_CODE_HARD_RST},
    {BSP_DEVICE_ID_PLL_DIST,    BSP_INIT_ERR_CODE_NO_RST},//BSP_INIT_ERR_CODE_HARD_RST},
    {BSP_DEVICE_ID_FPGA0,       BSP_INIT_ERR_CODE_NO_RST},
};

static UINT32 bspPowerOnStatus = 0;


/* 维测用 */
static UINT8 s_boardModleHelpPrint[][BOARDMODLE_HELP_LEN] =
{
    "showboardaction compotype(0-5)",
    "showboardflow",
    "showboarddata actype"
};
/**************************************************************************
                           函数声明
**************************************************************************/
static VOID showboarddata(UINT32 actType);
UINT32 BspBoardModleChangeActCfgBySubId(VOID);

/*****************************************************************************
                                    内部接口
*****************************************************************************/

/*****************************************************************************
*  函数名称   : GetDeep1DataInfo
*  功能描述   : 获取深度为1的数据地址等信息
*  输入参数   : T_BoardActData *pActData: 初始化动作对应的数据地址
*  输出参数   : VOID **pData: 数据地址
*            UINT32 *pNum: 元素个数
*            UINT32 *pSize: 数据元素大小
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetDeep1DataInfo(T_BoardActData *pActData, VOID **pData, UINT32 *pNum, UINT32 *pSize)
{
    *pNum = pActData->num;
    *pData = pActData->addr;
    *pSize = pActData->size;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : GetComponentType
*  功能描述   : 根据初始化动作类型查找功能组件类型
*  输入参数   : UINT32 actType: 初始化动作类型
*  输出参数   : 无
*  返 回 值   : 功能组件类型
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetComponentType(UINT32 actType)
{
    UINT32 compoType = (actType / BOARD_COMPO_ACT_SPACE);

    if(compoType < E_BOARD_COMPO_TYPE_MAX)
    {
        return compoType;
    }

    return E_BOARD_COMPO_TYPE_MAX;
}

/*****************************************************************************
*  函数名称   : GetActOffset
*  功能描述   : 根据初始化动作类型查找在对应功能组件中的偏移量
*  输入参数   : UINT32 actType: 初始化动作类型
*  输出参数   : 无
*  返 回 值   : 偏移量
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetActOffset(UINT32 actType)
{
    UINT32 offset = (actType % BOARD_COMPO_ACT_SPACE);
    
    if(offset < BOARD_COMPO_ACT_MAX)
    {
        return offset;
    }
    
    return BOARD_COMPO_ACT_MAX;
}

/*****************************************************************************
*  函数名称   : GetMatchId
*  功能描述   : 获取MatchID，用于匹配同一单板ID下的多片芯片
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : MatchId
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetMatchId(VOID)
{
    static UINT32 matchId = BOARD_INVALID_MATCH_ID;

    if(BOARD_INVALID_MATCH_ID == matchId)
    {
        /* 如果未注册pFuncGetMatchId的回调，则默认取第0项配置 */
        if(NULL == s_tBoardModle.pBoardIF->pFuncGetMatchId)
        {
            matchId = 0;
            return matchId;           
        }
        else
        {
            matchId = s_tBoardModle.pBoardIF->pFuncGetMatchId();
            return matchId;
        }         
    }
    else 
    {
        return matchId;
    }
}

/*****************************************************************************
*  函数名称   : GetBoardSubId
*  功能描述   : 获取二级单板ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : bdSubID
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetBoardSubId(VOID)
{
    static UINT32 subId = BOARD_INVALID_MATCH_ID;

    if(BOARD_INVALID_MATCH_ID == subId)
    {
        /* 如果未注册pFuncGetMatchId的回调，则默认取第0项配置 */
        if(NULL == s_tBoardModle.pBoardIF->pFuncGetBdSubId)
        {
            subId = 0;
            return subId;           
        }
        else
        {
            subId = s_tBoardModle.pBoardIF->pFuncGetBdSubId();
            return subId;
        }         
    }
    else 
    {
        return subId;
    }
}

/*****************************************************************************
*  函数名称   : BspGetBoardType
*  功能描述   : 获取单前是主从架构类型
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BoardType
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetBoardType(VOID)
{
    UINT32 uiBoardType = 0;
    uiBoardType = s_tBoardModle.pBoardIF->boardType;
    return uiBoardType;
}

/*****************************************************************************
*  函数名称   : GetActCfgIndex
*  功能描述   : 获取当前单板指定初始化动作对应的配置方案号
*  输入参数   : UINT32 actType: 初始化动作类型
*  输出参数   : UINT32 *pIndex: 配置方案号
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetActCfgIndex(UINT32 actType, UINT32 *pIndex)
{
    UINT32 matchId = GetMatchId();
    UINT32 boardId = s_tBoardModle.boardId;
    UINT32 offset = GetActOffset(actType);
    UINT32 compoType = GetComponentType(actType);

    if(s_tBoardModle.pBoardIF == NULL)
    {
        return BSP_ERROR;        
    }

    if(boardId >= s_tBoardModle.pBoardIF->boardIdMax)
    {
        return BSP_ERROR;        
    }

    if(matchId >= BOARD_MATCH_ID_MAX)
    {
        return BSP_ERROR;
    }

    if(offset >= BOARD_COMPO_ACT_MAX || compoType >= E_BOARD_COMPO_TYPE_MAX)
    {
        return BSP_ERROR;
    }

    *pIndex = s_tBoardModle.initFlow.compo[compoType].pMap[boardId].matchInfo[matchId].cfgIdxArray[offset];
	dbgInfoEx("%s>> matchId:%d boardId:%d, compoType:%d, offset:%d, pIndex:%d\n", __FUNCTION__, matchId, boardId, compoType, offset, *pIndex);

    return BSP_OK;  
}

/*****************************************************************************
*  函数名称   : GetDataOfDataCfgGroup
*  功能描述   : 获取配置方案对应的数据(可指定part序号)
*  输入参数   : 略
*  输出参数   : 略
*  返 回 值   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static VOID GetDataOfDataCfgGroup(T_DataCfgGroup *pDataCfgGroup, UINT32 cfgIdx, UINT32 part, VOID **pData, UINT32 *pNum, UINT32 *pSize)
{
    if(0 == part)
    {
        *pNum = pDataCfgGroup[cfgIdx-1].num;
        *pData = pDataCfgGroup[cfgIdx-1].addr;   
        *pSize = pDataCfgGroup[cfgIdx-1].size;        
    }
    else if(1 == part)
    {
        *pNum = pDataCfgGroup[cfgIdx-1].num1;
        *pData = pDataCfgGroup[cfgIdx-1].addr1;   
        *pSize = pDataCfgGroup[cfgIdx-1].size1;           
    }
    else if(2 == part)
    {
        *pNum = pDataCfgGroup[cfgIdx-1].num2;
        *pData = pDataCfgGroup[cfgIdx-1].addr2;   
        *pSize = pDataCfgGroup[cfgIdx-1].size2;           
    }
    else if(3 == part)
    {
        *pNum = pDataCfgGroup[cfgIdx-1].num3;
        *pData = pDataCfgGroup[cfgIdx-1].addr3;   
        *pSize = pDataCfgGroup[cfgIdx-1].size3;           
    }
    else if(4 == part)
    {
        *pNum = pDataCfgGroup[cfgIdx-1].num4;
        *pData = pDataCfgGroup[cfgIdx-1].addr4;
        *pSize = pDataCfgGroup[cfgIdx-1].size4;
    }
    else 
    {
        *pNum = 0;
        *pData = NULL;
        *pSize = 0;        
    }
    return;
       
}

/*****************************************************************************
*  函数名称   : GetDeep2DataInfo
*  功能描述   : 获取深度为2的数据地址等信息
*  输入参数   : T_BoardActData *pActData: 初始化动作对应的数据地址
*            UINT32 actType: 初始化动作类型
*            UINT32 part: T_DataCfgGroup中的addr还是addr1
*  输出参数   : VOID **pData: 数据地址
*            UINT32 *pNum: 元素个数
*            UINT32 *pSize: 数据元素大小
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetDeep2DataInfo(T_BoardActData *pActData, UINT32 actType, UINT32 part, VOID **pData, UINT32 *pNum, UINT32 *pSize)
{
    T_DataCfgGroup *pDataCfgGroup= NULL;
    UINT32 cfgIdx = 0;

    if(BSP_OK != GetActCfgIndex(actType, &cfgIdx))
    {
        return BSP_ERROR;
    }
    
    pDataCfgGroup = (T_DataCfgGroup *)(pActData->addr);
    if(NULL == pDataCfgGroup)
    {
        return BSP_ERROR;
    }

    if(cfgIdx > pActData->num)
    {
        return BSP_ERROR;
    }

    /* 有效的cfgIdx从1开始，0认为无效，故返回空指针 */
    if(cfgIdx < 1)
    {
        return BSP_ERROR;
    }
    else 
    {
        GetDataOfDataCfgGroup(pDataCfgGroup,cfgIdx,part,pData,pNum,pSize);
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : GetDeep2ByChipDataInfo
*  功能描述   : 获取深度为2的数据地址等信息
*            该数据的配置方案仅依赖于chipId，和boardId无关
*  输入参数   : T_BoardActData *pActData: 初始化动作对应的数据地址
*            UINT32 actType: 初始化动作类型
*            UINT32 part: T_DataCfgGroup中的addr还是addr1
*  输出参数   : VOID **pData: 数据地址
*            UINT32 *pNum: 元素个数
*            UINT32 *pSize: 数据元素大小
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetDeep2ByChipDataInfo(T_BoardActData *pActData, UINT32 actType, UINT32 part, VOID **pData, UINT32 *pNum, UINT32 *pSize)
{
    T_DataCfgGroup *pDataCfgGroup= NULL;
    UINT32 matchId = GetMatchId();
    UINT32 cfgIdx = matchId+1;   /* 仅通过ChipId来区分配置方案 */
 
    if(matchId >= BOARD_MATCH_ID_MAX)
    {
        dbgErr("%s matchid error\n", __func__);
        return BSP_ERROR;
    }

    if(cfgIdx > pActData->num)
    {
        return BSP_ERROR;
    }
    
    pDataCfgGroup = (T_DataCfgGroup *)(pActData->addr);
    if(NULL == pDataCfgGroup)
    {
        dbgErr("%s pDataCfgGroup is null\n", __func__);
        return BSP_ERROR;
    }
    
    GetDataOfDataCfgGroup(pDataCfgGroup,cfgIdx,part,pData,pNum,pSize);
    dbgInfoEx("%s pDataCfgGroup=%p, cfgIdx=%d part=%d pData=%p pNum=%d\n", __func__, 
            pDataCfgGroup, cfgIdx, part, *pData, *pNum);

    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : GetBoardAction
*  功能描述   : 获取配置方案对应的数据(可指定part序号)
*  输入参数   : UINT32 actType: 初始化动作类型
*  输出参数   : 无
*  返 回 值   : 初始化动作结构地址
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static T_BoardAction *GetBoardAction(UINT32 actType)
{
    UINT32 offset = GetActOffset(actType);
    UINT32 compoType = GetComponentType(actType);
    
    if(offset == BOARD_COMPO_ACT_MAX || compoType == E_BOARD_COMPO_TYPE_MAX)
    {
        return NULL;    
    }
    else
    {
        return &(s_tBoardModle.initFlow.compo[compoType].action[offset]);
    }
}

/*****************************************************************************
*  函数名称   : BoardModleActionInit
*  功能描述   : 单板模型的内部初始化(单板动作、预初始化和初始化链表)
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BoardModleActionInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 funcNum = 0;
    UINT32 index = 0;

    /* 将data中各功能项目的数据挂接到单板模型中 */
    for(loop = 0; loop < E_BOARD_COMPO_TYPE_MAX; loop++)
    {
        funcNum = min(s_tBoardModle.initFlow.compo[loop].funcNum, BOARD_FUNC_SET_DATA_MAX);

        for(index = 0; index < funcNum; index++)
        {
            if(s_tBoardModle.initFlow.compo[loop].funcSetData[index])
            {
                s_tBoardModle.initFlow.compo[loop].funcSetData[index]();
            }
        }
    }

    /* 将data中单板和配置方案的对应关系挂接到单板模型中 */
    if(s_tBoardModle.initFlow.funcSetBoardMap)
    {
        s_tBoardModle.initFlow.funcSetBoardMap();
    }

    /* 设置单板上电状态的初始化，该值用于向高层上报 */
    if(s_tBoardModle.pInstanceIF->poweronNum > E_POWERON_NUM)
    {
        bspPowerOnStatus = BIT_SET(E_POWERON_NUM)-1;
    }
    else
    {
        bspPowerOnStatus = BIT_SET(s_tBoardModle.pInstanceIF->poweronNum)-1;
    }

    /* 执行在例化单板(例如boardmodle_ic4_2)中挂接的回调接口，实现初始化流程的预置 */
    if(s_tBoardModle.pInstanceIF->pFuncInitflow)
    {
       retVal = s_tBoardModle.pInstanceIF->pFuncInitflow(s_tBoardModle.pBoardIF->boardType); 
    }

    /* 执行单板下挂接的修改预初始化流程的接口(不区分单板id) */
    if(s_tBoardModle.pBoardIF->pFuncPreLgcType)    
    {
        retVal |= s_tBoardModle.pBoardIF->pFuncPreLgcType();
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspInitLogBackup
*  功能描述   : bsplog.txt备份为bsplog.init
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspInitLogBackup(VOID)
{
    static UINT32 backupFlag = 0;
    char   cmdsrt[128] = {0};
    int snpRet = 0;

    if(s_tBoardModle.logFileName)
    {   
        snpRet = snprintf_s(cmdsrt,sizeof(cmdsrt),"cp /%s.txt /%s.init",
            s_tBoardModle.logFileName, s_tBoardModle.logFileName);
        SNPRINTF_S_CHECK(snpRet, sizeof(cmdsrt)); 
        if (backupFlag == 0)
        {
            backupFlag = 1;
            BspSystem(cmdsrt);
        }        
    }
    
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetErrInfo
*  功能描述   : 获取ErrCode
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : ERROR CODE
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspGetErrInfo(UINT32 devId)
{
    UINT32 idx    = 0;

    for (idx = 0; idx < NELEMENTS(s_errCodeInfo); idx++)
    {
        if (devId == s_errCodeInfo[idx].devId)
        {
            return s_errCodeInfo[idx].errCode;
        }
    }

    return BSP_INIT_ERR_CODE_NO_RST;
}

/*****************************************************************************
*  函数名称   : SetPartOfFileData
*  功能描述   : 保存从文件解析出的数据地址(指定part序号)
*  输入参数   : 略
*  输出参数   : 略
*  返 回 值   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-13 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 SetPartOfFileData(T_DataCfgGroup *pDataCfgGroup, UINT32 part, UINT32 *pData, UINT32 num, UINT32 size)
{
    if(0 == part)
    {
        pDataCfgGroup->addr = pData;
        pDataCfgGroup->num = num;
        pDataCfgGroup->size = size;
    }
    else if(1 == part)
    {
        pDataCfgGroup->addr1 = pData;
        pDataCfgGroup->num1 = num;
        pDataCfgGroup->size1 = size;
    }
    else if(2 == part)
    {
        pDataCfgGroup->addr2 = pData;
        pDataCfgGroup->num2 = num;
        pDataCfgGroup->size2 = size;
    }
    else if(3 == part)
    {
        pDataCfgGroup->addr3 = pData;
        pDataCfgGroup->num3 = num;
        pDataCfgGroup->size3 = size;
    }
    else if(4 == part)
    {
        pDataCfgGroup->addr4 = pData;
        pDataCfgGroup->num4 = num;
        pDataCfgGroup->size4 = size;
    }
    else
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : SetPartOfDataLayout
*  功能描述   : 保存数据对应的布局(指定part序号)
*  输入参数   : 略
*  输出参数   : 略
*  返 回 值   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-13 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 SetPartOfDataLayout(T_DataLayoutGrp *pLayoutGrp, UINT32 part, UINT32 *pLayout, UINT32 version)
{
    if(0 == part)
    {
        pLayoutGrp->layout = pLayout;
        pLayoutGrp->version = version;
    }
    else if(1 == part)
    {
        pLayoutGrp->layout1 = pLayout;
        pLayoutGrp->version1 = version;
    }
    else if(2 == part)
    {
        pLayoutGrp->layout2 = pLayout;
        pLayoutGrp->version2 = version;
    }
    else if(3 == part)
    {
        pLayoutGrp->layout3 = pLayout;
        pLayoutGrp->version3 = version;
    }
    else if(4 == part)
    {
        pLayoutGrp->layout4 = pLayout;
        pLayoutGrp->version4 = version;
    }
    else
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : GetPartOfDataLayout
*  功能描述   : 获取数据对应的布局(指定part序号)
*  输入参数   : 略
*  输出参数   : 略
*  返 回 值   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-13 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetPartOfDataLayout(T_DataLayoutGrp *pLayoutGrp, UINT32 part, VOID** pLayout, UINT32* version)
{
    if(0 == part)
    {
        *pLayout = pLayoutGrp->layout;
        *version = pLayoutGrp->version;
    }
    else if(1 == part)
    {
        *pLayout = pLayoutGrp->layout1;
        *version = pLayoutGrp->version1;
    }
    else if(2 == part)
    {
        *pLayout = pLayoutGrp->layout2;
        *version = pLayoutGrp->version2;
    }
    else if(3 == part)
    {
        *pLayout = pLayoutGrp->layout3;
        *version = pLayoutGrp->version3;
    }
    else if(4 == part)
    {
        *pLayout = pLayoutGrp->layout4;
        *version = pLayoutGrp->version4;
    }
    else
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : GetPartOfFileData
*  功能描述   : 获取从文件解析出的数据地址(指定part序号)
*  输入参数   : 略
*  输出参数   : 略
*  返 回 值   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-13 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 GetPartOfFileData(T_DataCfgGroup *pDataCfgGroup, UINT32 part, VOID **pData, UINT32 *pNum)
{
    if(NULL == pDataCfgGroup)
    {
        return BSP_ERROR;
    }

    if(0 == part)
    {
        *pNum = pDataCfgGroup->num;
        *pData = pDataCfgGroup->addr;
    }
    else if(1 == part)
    {
        *pNum = pDataCfgGroup->num1;
        *pData = pDataCfgGroup->addr1;
    }
    else if(2 == part)
    {
        *pNum = pDataCfgGroup->num2;
        *pData = pDataCfgGroup->addr2;
    }
    else if(3 == part)
    {
        *pNum = pDataCfgGroup->num3;
        *pData = pDataCfgGroup->addr3;
    }
    else if(4 == part)
    {
        *pNum = pDataCfgGroup->num4;
        *pData = pDataCfgGroup->addr4;
    }
    else
    {
        *pNum = 0;
        *pData = NULL;
        return BSP_ERROR;
    }

    if(NULL == *pData)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/*****************************************************************************
*                                  对外接口                                      *
*****************************************************************************/

/*****************************************************************************
*  函数名称   : BspGetBoardInitStatus
*  功能描述   : 高层获取单板初始化状态的接口
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 初始化状态;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetBoardInitStat(VOID)
{
    BspLog(LOG_LEVEL_0,"board init status: %#x\n", bspPowerOnStatus);
    if (bspPowerOnStatus == 0)
    {
        BspInitLogBackup();
    }
    return bspPowerOnStatus;
}

/*****************************************************************************
*  函数名称   : SetPowerOnFinished
*  功能描述   : 设置初始化完成状态
*  输入参数   : type: 初始化类型
*  输出参数   : 无
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 SetPowerOnFinished(UINT32 type)
{
    bspPowerOnStatus &= BIT_REV(type);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : SetPowerOnIniting
*  功能描述   : 设置初始化中状态
*  输入参数   : type: 初始化类型
*  输出参数   : 无
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 SetPowerOnIniting(UINT32 type)
{
    bspPowerOnStatus |= BIT_SET(type);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetBoardId
*  功能描述   : 将BoardId设置到单板模型中，用于后续配置方案的匹配
*  输入参数   : UINT32 boardId:单板ID 
*  输出参数   : 无
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetBoardId(UINT32 boardId)
{
    s_tBoardModle.boardId = boardId;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetLogFileName
*  功能描述   : 配置单板的log文件名称
*  输入参数   : CHAR *logFileName):log文件名称
*  输出参数   : 无
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetLogFileName(const CHAR *logFileName)
{
    s_tBoardModle.logFileName = logFileName;
    return BspSetLogFileName(logFileName);
}

/*****************************************************************************
*  函数名称   : BspBoardModleBrdIfInit
*  功能描述   : 用于将单板下的信息传递到单板模型中
*  输入参数   : T_BoardInterFace *pInterface: 单板接口信息
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleBrdIfInit(T_BoardInterFace *pInterface)
{
    if(NULL == pInterface)
    {
        return BSP_ERROR;
    }
    s_tBoardModle.pBoardIF = pInterface;
    
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspBoardModleInstanceIfInit
*  功能描述   : 用于将例化单板中的信息传递到单板模型中
*  输入参数   : T_InstanceInterFace *pInterface:例化单板接口信息
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleInstanceIfInit(T_InstanceInterFace *pInterface)
{
    if(NULL == pInterface)
    {
        return BSP_ERROR;
    }
    s_tBoardModle.pInstanceIF = pInterface;
    
    return BSP_OK;
}



/*****************************************************************************
*  函数名称   : BspBoardModleGetData
*  功能描述   : 根据actType获取对应的数据参数
*  输入参数   : UINT32 actType: 初始化动作
*            UINT32 idx    : 初始化动作中对应的第几组数据
*            UINT32 part   : 配置方案中对应的第几组数据
*  输出参数   : VOID **pData   : 获取的参数地址
*            UINT32 *pNum  : 获取的参数数组的元素个数
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleGetData(UINT32 actType, UINT32 idx, UINT32 part, VOID **pData, UINT32 *pNum)
{
    UINT32 size = 0;
    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL == pAct || idx >= BOARD_ACT_DATA_MAX || NULL == pData|| NULL == pNum)
    {
        return BSP_ERROR;
    }

    /* 查询是否已从文件解析出数据 */
    if(BSP_OK == GetPartOfFileData(pAct->fileDataArray[idx].addr, part, pData, pNum))
    {
        dbgInfo("%s>> get acttype[%d] idx[%d] from json file\n",__FUNCTION__, actType, idx);  
        BspLog(LOG_LEVEL_0, "%s>> get acttype[%d] idx[%d] from json file\n", __FUNCTION__, actType, idx);
        return BSP_OK;
    }

    /* 如果未查询到文件解析出的数据，则使用版本内置的数据 */
    if(DEEP_LEVEL1 == pAct->actDataArray[idx].deep)
    {
        return GetDeep1DataInfo(&(pAct->actDataArray[idx]), pData, pNum, &size);
    }
    else if(DEEP_LEVEL2 == pAct->actDataArray[idx].deep)
    {
        return GetDeep2DataInfo(&(pAct->actDataArray[idx]), actType, part, pData, pNum, &size);
    }
    else if(DEEP_LEVEL2_BYCHIP == pAct->actDataArray[idx].deep)
    {
        return GetDeep2ByChipDataInfo(&(pAct->actDataArray[idx]), actType, part, pData, pNum, &size);
    }    
    else 
    {
        return BSP_ERROR;
    }
}

/*****************************************************************************
*  函数名称   : BspBoardModleGetActType
*  功能描述   : 根据初始化接口名称获取ActType
*  输入参数   : UINT32 compoType: 动作组件类型
*            const CHAR *actNameStr:接口名称
*  输出参数   : UINT32 *pActType:初始化动作类型
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleGetActType(UINT32 compoType, const CHAR *actNameStr, UINT32 *pActType)
{
    UINT32 loop = 0;

    if(compoType >= E_BOARD_COMPO_TYPE_MAX)
    {
        return BSP_ERROR;
    }
    
    for(loop = 0; loop < BOARD_COMPO_ACT_MAX; loop++)
    {
        if(!strcmp(s_tBoardModle.initFlow.compo[compoType].action[loop].actName, actNameStr))
        {
            *pActType = s_tBoardModle.initFlow.compo[compoType].action[loop].actType;
            return BSP_OK;
        }
    }
        
   return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetActFunc
*  功能描述   : 配置单板动作对应的回调函数及接口名称等信息
*  输入参数   : UINT32 actType: 初始化动作类型
*            FUNC_BOARD_INIT_ACT pFunc: 初始化接口函数地址
*            CHAR *actNameStr: 初始化动作名称
*            UINT32 initFlag: 初始化标志
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetActFunc(UINT32 actType, FUNC_BOARD_INIT_ACT pFunc, CHAR *actNameStr, UINT32 initFlag)
{
    int ret = 0;
    T_BoardAction *pAct = GetBoardAction(actType);
    
    if(NULL != pAct)
    {
        pAct->actFunc = pFunc;
        if(NULL != actNameStr)
        {
            ret = strncpy_s(pAct->actName, sizeof(pAct->actName), actNameStr, BOARD_ACT_NAME_LEN-1);
            if (ret != 0)
            {
                dbgErr("%s>>strncpy_s failed[ret %x]\n", __FUNCTION__, ret);
            }            
            pAct->initFlag = initFlag;
            pAct->actType = actType;
        }
        return BSP_OK;
    }
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetActByTbl
*  功能描述   : 根据表格初始化单板动作对应的回调函数及接口名称
*  输入参数   : T_BoardActFuncTbl *pTbl: 初始化动作数组首地址
*            UINT32 num:  初始化动作数量
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetActByTbl(T_BoardActFuncTbl *pTbl, UINT32 num)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    for(loop=0; loop<num; loop++)
    {
        retVal |= BspBoardModleSetActFunc(pTbl->actType, pTbl->actFunc, pTbl->pActName, pTbl->initFlag);
        pTbl++;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetData
*  功能描述   : 将各功能项目的数据参数设定到单板模型中
*  输入参数   : UINT32 actType: 初始化动作类型
*            UINT32 idx: 初始化动作对应数据的序号
*            UINT32 deep: 数据深度
*            VOID *pData: 数据首地址
*            UINT32 num: 数据元素个数
*            UINT32 size: 数据元素大小
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetData(UINT32 actType, UINT32 idx, UINT32 deep, VOID *pData, UINT32 num, UINT32 size)
{
    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL != pAct)
    {
        if(idx < BOARD_ACT_DATA_MAX)
        {
            pAct->actDataArray[idx].deep = deep;
            pAct->actDataArray[idx].addr = pData;
            pAct->actDataArray[idx].num = num;
            pAct->actDataArray[idx].size = size;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetDataFunc
*  功能描述   : 注册用于设定各功能项目数据参数的回调接口到单板模型中
*  输入参数   : UINT32 compoType: 功能组件类型
*            FUNC_SET_BOARD_DATA pFunc: 设置数据参数的函数地址
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetDataFunc(UINT32 compoType, FUNC_SET_BOARD_DATA pFunc)
{
    UINT32 funcNum = 0;

    if(compoType < E_BOARD_COMPO_TYPE_MAX)
    {
        funcNum = s_tBoardModle.initFlow.compo[compoType].funcNum;

        if(funcNum >= BOARD_FUNC_SET_DATA_MAX)
        {
            return ERROR;
        }
        else
        {
            s_tBoardModle.initFlow.compo[compoType].funcSetData[funcNum] = pFunc;
            funcNum++;
            s_tBoardModle.initFlow.compo[compoType].funcNum = funcNum;

            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetBoardMap
*  功能描述   : 将单板和配置方案的对应关系设定到单板模型中
*  输入参数   : UINT32 compoType: 功能组件类型
*            T_CompoCfgIdxBoardMap *pMap: 单板和配置方案的对应关系数组地址
*            UINT32 num: 单板和配置方案的对应关系的数组元素个数
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetBoardMap(UINT32 compoType, T_CompoCfgIdxBoardMap *pMap, UINT32 num)
{
    if(NULL != pMap && 0 != num && compoType < E_BOARD_COMPO_TYPE_MAX)
    {
        s_tBoardModle.initFlow.compo[compoType].pMap = pMap;
        s_tBoardModle.initFlow.compo[compoType].mapNum = num;
        return BSP_OK;
    }
    return BSP_ERROR;    
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetBoardSubMap
*  功能描述   : 将二级单板ID和配置方案的对应关系设定到单板模型中
*  输入参数   : T_BoardSubIdCfgMap *pSubMap: 二级单板ID和配置方案的对应关系数组地址
*            UINT32 num: 二级单板ID和配置方案的对应关系的数组元素个数
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetBoardSubMap(T_BoardSubIdCfgMap *pSubMap, UINT32 itemNum)
{
    if(NULL == pSubMap)
    {
        return BSP_ERROR;   
    }

    s_tBoardModle.initFlow.pSubMap = pSubMap;
    s_tBoardModle.initFlow.subMapItemNum = itemNum;

    return BSP_OK; 
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetBoardMapFunc
*  功能描述   : 注册用于设定单板和配置方案的对应关系的回调函数到单板模型中
*  输入参数   : FUNC_SET_BOARD_DATA pFunc: 设定单板和配置方案的对应关系的接口函数地址
*  输出参数   : 无
*  返 回 值   : BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetBoardMapFunc(FUNC_SET_BOARD_DATA pFunc)
{

    s_tBoardModle.initFlow.funcSetBoardMap = pFunc;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspBoardModleAddPreAction
*  功能描述   : 向单板预初始化流程末尾追加初始化动作
*  输入参数   : UINT32 actType: 初始化动作类型
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleAddPreAction(UINT32 actType)
{
    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL != pAct)
    {        
        if(s_ptPreInitActListEnd != NULL)
        {
            pAct->prev = s_ptPreInitActListEnd;
            s_ptPreInitActListEnd->next = pAct;
            s_ptPreInitActListEnd = pAct;
            return BSP_OK;
        }
    }    
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspBoardModleAddInitAction
*  功能描述   : 向单板初始化流程末尾追加初始化动作
*  输入参数   : UINT32 actType: 初始化动作类型
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleAddInitAction(UINT32 actType)
{
    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL != pAct)
    {        
        if(s_ptInitActListEnd != NULL)
        {
            pAct->prev = s_ptInitActListEnd;
            s_ptInitActListEnd->next = pAct;
            s_ptInitActListEnd = pAct;
            return BSP_OK;
        }
    }    
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspBoardModleInsertNextAction
*  功能描述   : 在指定动作后面插入初始化动作
*  输入参数   : UINT32 refActType: 作为参照的初始化动作
*            UINT32 newActType: 待插入的初始化动作
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleInsertNextAction(UINT32 refActType, UINT32 newActType)
{
    T_BoardAction *pRefAct = GetBoardAction(refActType);
    T_BoardAction *pNewAct = GetBoardAction(newActType);
    if(NULL == pRefAct || NULL == pNewAct)
    {        
        return BSP_ERROR;
    }    
    
    if(pNewAct->prev || pNewAct->next)
    {
        return BSP_ERROR;
    }

    if(pRefAct == s_ptPreInitActListEnd)
    {
        return BspBoardModleAddPreAction(newActType);
    }

    if(pRefAct == s_ptInitActListEnd)
    {
        return BspBoardModleAddInitAction(newActType);
    }

    if(NULL == pRefAct->next)
    {
        return BSP_ERROR;
    }

    pNewAct->prev = pRefAct;
    pNewAct->next = pRefAct->next;
    pRefAct->next->prev = pNewAct;
    pRefAct->next = pNewAct;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspBoardModleInsertPrevAction
*  功能描述   : 在指定动作前面插入初始化动作
*  输入参数   : UINT32 refActType: 作为参照的初始化动作
*            UINT32 newActType: 待插入的初始化动作
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleInsertPrevAction(UINT32 refActType, UINT32 newActType)
{
    T_BoardAction *pRefAct = GetBoardAction(refActType);
    T_BoardAction *pNewAct = GetBoardAction(newActType);
    if(NULL == pRefAct || NULL == pNewAct)
    {        
        return BSP_ERROR;
    }    

    if(pNewAct->prev || pNewAct->next)
    {
        return BSP_ERROR;
    }

    if(NULL == pRefAct->prev)
    {
        return BSP_ERROR;
    }

    pNewAct->next = pRefAct;
    pNewAct->prev = pRefAct->prev;
    pRefAct->prev->next = pNewAct;
    pRefAct->prev = pNewAct;

    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BspBoardModleDeleteAction
*  功能描述   : 删除指定的初始化动作
*  输入参数   : UINT32 targetActType: 待删除的初始化动作
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleDeleteAction(UINT32 targetActType)
{
    T_BoardAction *pPrevAct = NULL;
    T_BoardAction *pNextAct = NULL;
    T_BoardAction *pDelAct = GetBoardAction(targetActType);
    if(NULL == pDelAct)
    {        
        return BSP_ERROR;
    }

    if(s_ptPreInitActListEnd == pDelAct || s_ptInitActListEnd == pDelAct)
    {
        pPrevAct = pDelAct->prev;
        if(NULL == pPrevAct)
        {
            return BSP_ERROR;
        }
        else 
        {
            pPrevAct->next = NULL;
            pDelAct->next = NULL;
            pDelAct->prev = NULL;
            if(s_ptPreInitActListEnd == pDelAct)
            {
                s_ptPreInitActListEnd = pPrevAct;
            }
            else 
            {
                s_ptInitActListEnd = pPrevAct;
            }
        }
    }
    else 
    {
        if(NULL == pDelAct->next || NULL == pDelAct->prev)
        {
            return BSP_ERROR;
        }
        else 
        {
            pPrevAct = pDelAct->prev;
            pNextAct = pDelAct->next;
            pPrevAct->next = pNextAct;
            pNextAct->prev = pPrevAct;
            pDelAct->next = NULL;
            pDelAct->prev = NULL;
        }
    }

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetActDataCfg
*  功能描述   : 修改指定初始化动作对应的配置方案号(需要在获取到boardid之后调用)
*  输入参数   : UINT32 actType: 初始化动作类型
*  输出参数   : UINT32 cfgIdx: 配置方案号
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetActCfg(UINT32 actType, UINT8 cfgIdx)
{
    UINT32 matchId = GetMatchId();
    UINT32 boardId = s_tBoardModle.boardId;
    UINT32 offset = GetActOffset(actType);
    UINT32 compoType = GetComponentType(actType);

    if(s_tBoardModle.pBoardIF == NULL)
    {
        return BSP_ERROR;        
    }

    if(boardId >= s_tBoardModle.pBoardIF->boardIdMax)
    {
        return BSP_ERROR;        
    }

    if(matchId >= BOARD_MATCH_ID_MAX)
    {
        return BSP_ERROR;
    }

    if(offset >= BOARD_COMPO_ACT_MAX || compoType >= E_BOARD_COMPO_TYPE_MAX)
    {
        return BSP_ERROR;
    }

    s_tBoardModle.initFlow.compo[compoType].pMap[boardId].matchInfo[matchId].cfgIdxArray[offset] = cfgIdx+1;

    return BSP_OK;  
}

/*****************************************************************************
*  函数名称   : BspBoardModleChangeActCfg
*  功能描述   : 按照二级单板ID修改指定初始化动作对应的配置方案号
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleChangeActCfgBySubId(VOID)
{
    UINT32 targetBoardId = 0;
    UINT32 targetBoardSubId = 0;
    UINT32 targetActType = 0;
    UINT32 targetActCfg = 0;
    UINT32 targetChipId = 0;
    UINT32 index = 0;
    UINT32 matchId = GetMatchId();
    UINT32 boardId = s_tBoardModle.boardId;
    UINT32 boardSubId = GetBoardSubId();
    UINT32 offset = 0;
    UINT32 compoType = 0;
    T_BoardSubIdCfgMap *pSubMap = NULL;
    BspLog(0,"%s \n", __func__);

    if(s_tBoardModle.pBoardIF == NULL)
    {
        return BSP_ERROR;        
    }

    if(NULL == s_tBoardModle.initFlow.pSubMap || 0 == s_tBoardModle.initFlow.subMapItemNum)
    {
        return BSP_ERROR;
    }

    if(boardId >= s_tBoardModle.pBoardIF->boardIdMax)
    {
        return BSP_ERROR;        
    }

    if(boardSubId >= s_tBoardModle.pBoardIF->boardSubIdMax)
    {
        return BSP_ERROR;
    }

    if(matchId >= BOARD_MATCH_ID_MAX)
    {
        return BSP_ERROR;
    }

    pSubMap = s_tBoardModle.initFlow.pSubMap;
    for(index=0; index<s_tBoardModle.initFlow.subMapItemNum; index++)
    {
        targetBoardId = pSubMap->boardId;
        targetBoardSubId = pSubMap->boardSubId;
        targetChipId = pSubMap->chipId;
        targetActType = pSubMap->actType;
        targetActCfg = pSubMap->actCfg;

        BspLog(0,"%s %d  %d %d %d %d \n", __func__,targetBoardId,targetBoardSubId,targetChipId,targetActType,targetActCfg);

        /* 对于单板ID、二级单板ID、片号均能匹配上的项目，按照内容调整初始化动作对应的配置方案 */
        if((boardId == targetBoardId) && (boardSubId == targetBoardSubId) && (matchId == targetChipId))
        {
            offset = GetActOffset(targetActType);
            compoType = GetComponentType(targetActType);

            if(offset >= BOARD_COMPO_ACT_MAX || compoType >= E_BOARD_COMPO_TYPE_MAX)
            {
                return BSP_ERROR;
            }
            BspLog(0,"%s ok \n", __func__);
            s_tBoardModle.initFlow.compo[compoType].pMap[boardId].matchInfo[matchId].cfgIdxArray[offset] = targetActCfg;
        }
        pSubMap++;
    }
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspBoardModleGroupInit
*  功能描述   : 将各功能项目的数据参数设定到单板模型中
*  输入参数   : UINT32 actType: 初始化动作类型
*            UINT32 idx: 初始化动作对应数据的序号
*            T_DataCfgGroup *pDataGrp:数据组首地址
*            T_DataLayoutGrp *pLayOutGrp: 数据布局组首地址
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-1 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleGroupInit(UINT32 actType, UINT32 idx, T_DataCfgGroup *pDataGrp, T_DataLayoutGrp *pLayOutGrp)
{
    if(NULL == pDataGrp || NULL == pLayOutGrp || idx >= BOARD_ACT_DATA_MAX)
    {
        return BSP_ERROR;
    }

    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL != pAct)
    {
        if(idx < BOARD_ACT_DATA_MAX)
        {
            pAct->fileDataArray[idx].addr = pDataGrp;
            pAct->fileDataArray[idx].layout = pLayOutGrp;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetFileData
*  功能描述   : 将数据对应的配置文件名称写入单板模型
*  输入参数   : UINT32 actType: 初始化动作类型
*            UINT32 idx: 初始化动作对应数据的序号
*            UINT32 part: 初始化动作对应数据的part号
*            VOID *pData: 数据地址
*            UINT32 num: 数据维度
*            UINT32 size:数据size
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-1 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetFileData(UINT32 actType, UINT32 idx, UINT32 part, VOID *pData, UINT32 num, UINT32 size)
{
    T_DataCfgGroup *pDataCfgGrp = NULL;
    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL == pAct || idx >= BOARD_ACT_DATA_MAX || part >= DATA_PART_MAX || NULL == pData)
    {
        return BSP_ERROR;
    }

    pDataCfgGrp = (T_DataCfgGroup *)(pAct->fileDataArray[idx].addr);
    if(NULL == pDataCfgGrp)
    {
        return BSP_ERROR;
    }

    return SetPartOfFileData(pDataCfgGrp, part, pData, num, size);
}

/*****************************************************************************
*  函数名称   : BspBoardModleSetDataLayout
*  功能描述   : 将数据对应的配置文件名称写入单板模型
*  输入参数   : UINT32 actType: 初始化动作类型
*            UINT32 idx: 初始化动作对应数据的序号
*            UINT32 part: 初始化动作对应数据的part号
*            VOID *pLayout: 数据布局
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-1 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleSetDataLayout(UINT32 actType, UINT32 idx, UINT32 part, VOID *pLayout, UINT32 version)
{
    T_DataLayoutGrp *pLayoutGrp = NULL;
    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL == pAct || idx >= BOARD_ACT_DATA_MAX || part >= DATA_PART_MAX || NULL == pLayout)
    {
        return BSP_ERROR;
    }

    pLayoutGrp = (T_DataLayoutGrp *)(pAct->fileDataArray[idx].layout);
    if(NULL == pLayoutGrp)
    {
        return BSP_ERROR;
    }

    return SetPartOfDataLayout(pLayoutGrp, part, pLayout, version);
}

/*****************************************************************************
*  函数名称   : BspBoardModleGetDataLayout
*  功能描述   : 获取数据布局
*  输入参数   : UINT32 actType: 初始化动作类型
*            UINT32 idx: 初始化动作对应数据的序号
*            UINT32 part: 初始化动作对应数据的part号
*  输出参数   : 无
*  返 回 值   : 数据布局/NULL
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王涛@2023-11-1 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleGetDataLayout(UINT32 actType, UINT32 idx, UINT32 part, VOID **pLayout, UINT32 *version)
{
    T_DataLayoutGrp *pLayoutGrp = NULL;
    T_BoardAction *pAct = GetBoardAction(actType);
    if(NULL == pAct || idx >= BOARD_ACT_DATA_MAX || part >= DATA_PART_MAX)
    {
        return NULL;
    }

    pLayoutGrp = (T_DataLayoutGrp *)(pAct->fileDataArray[idx].layout);
    if(NULL == pLayoutGrp)
    {
        return NULL;
    }

    return GetPartOfDataLayout(pLayoutGrp, part, pLayout, version);
}


/*****************************************************************************
*  函数名称   : BspBoardModlePreInit
*  功能描述   : 单板模型提供的单板预初始化动作
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModlePreInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 ret = BSP_OK;
    T_BoardAction *pAct = NULL;
    struct timeval  startTime;
    struct timeval  endTime;
    UINT32 calTime = 0;
    
    /* 初始化单板模型中的数据、动作和链表 */
    gettimeofday(&startTime,NULL);
    retVal = BoardModleActionInit();
    CHECK_CRITICAL_ERR(BoardModleActionInit,retVal);
    gettimeofday(&endTime,NULL); 
    
    calTime = (((endTime.tv_sec - startTime.tv_sec)*1000000L + endTime.tv_usec) - startTime.tv_usec);
    calTime = calTime / 1000;
    dbgInfo("%s BoardModleActionInit calTime=%d(ms)\n", __FUNCTION__, calTime);

    /* 执行预初始化流程 */
    BspLog(LOG_LEVEL_0, "%s start\n", __FUNCTION__);
    pAct = s_tPreInitActListHead.next;
    while(pAct)
    {
        CHECK_STATUS_PRE(pAct->actName);
        if(pAct->actFunc)
        {
            ret = pAct->actFunc();
        }
        else
        {
            dbgErr("!!! critical error %s actFunc of current action is NULL !!!\n", __func__);
            strcpy_s(pAct->actName, BOARD_ACT_NAME_LEN-1, "unknown actFunc");
            ret = BSP_ERROR;
        }
        CHECK_STATUS_POST(retVal,pAct->actName,ret,pAct->initFlag);
        /* 
            执行E_HARD_FEATURE_GET_LGC_TYPE动作之后，可正常识别单板ID，
            此时执行单板挂接的修改初始化流程的接口 
        */
        if(s_tBoardModle.pInstanceIF->lgcTypeActType == pAct->actType)
        {
        	/*根据二级单板ID修改功能配置参数方案*/
            BspBoardModleChangeActCfgBySubId();
            if(s_tBoardModle.pBoardIF->pFuncPostLgcType)    
            {
                ret = s_tBoardModle.pBoardIF->pFuncPostLgcType();
                CHECK_CRITICAL_ERR(BspChangeFlowPostLgcType,ret);
            }
        }
        pAct = pAct->next;
    }    
    SetPowerOnFinished(E_POWERON_BOARD_PREINIT);
    BspLog(LOG_LEVEL_0, "%s end,return %d\n", __FUNCTION__,retVal);
    
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspBoardModleInit
*  功能描述   : 单板模型提供的单板初始化动作
*  输入参数   :  无
*  输出参数   : 无
*  返 回 值   : BSP_OK/BSP_ERROR
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardModleInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 ret = BSP_OK;
    T_BoardAction *pAct = NULL;
    
    /* 执行初始化流程 */
    BspLog(LOG_LEVEL_0, "%s start\n", __FUNCTION__);
    pAct = s_tInitActListHead.next;
    while(pAct)
    {
        CHECK_STATUS_PRE(pAct->actName);
        if(pAct->actFunc)
        {
            ret = pAct->actFunc();
        }
        else
        {
            dbgErr("!!! critical error %s actFunc of current action is NULL !!!\n", __func__);
            strcpy_s(pAct->actName, BOARD_ACT_NAME_LEN-1, "unknown actFunc");
            ret = BSP_ERROR;
        }
        CHECK_STATUS_POST(retVal,pAct->actName,ret,pAct->initFlag);
        pAct = pAct->next;
    }
    
    dbgInfo("%s end,return %d,ticks %d\n", __FUNCTION__, retVal, tickGet());
    SetPowerOnFinished(E_POWERON_PA_INIT);
    SetPowerOnFinished(E_POWERON_BOARD_INIT);
    BspLog(LOG_LEVEL_0, "%s end,return %d\n", __FUNCTION__,retVal);
    
    return retVal;    
}

/**************************************************************************
                            维测接口
**************************************************************************/
#define FUNC_TO_STR(x)    #x
static VOID showboardaction(UINT32 compotype)
{
    UINT32 loop = 0;
    CHAR *pName = NULL;
    T_BoardAction *pAct = NULL;
    T_BoardActData *pActData = NULL;
       
    if(compotype < E_BOARD_COMPO_TYPE_MAX)
    {   
        dbgInfo("%s:\n", s_BoardCompoNameStr[compotype]);
        dbgInfo("ActIdx ActName                               data0|deep|num      data1|deep|num  func      \n");
        for(loop=0; loop<BOARD_COMPO_ACT_MAX; loop++)
        {
            pAct = &(s_tBoardModle.initFlow.compo[compotype].action[loop]);
            pActData = pAct->actDataArray;
            pName = pAct->actName;

            if(NULL == pAct->actFunc && NULL == pActData[0].addr)
            {
                continue;
            }
            
            dbgInfo("%-6d %-32s %p|%04d|%03d %p|%04d|%03d  %-32s\n",
            BOARD_COMPO_ACT_SPACE*compotype+loop,
            pAct->actFunc==NULL?"*Data Only":pName,
            pActData[0].addr,pActData[0].deep,pActData[0].num,
            pActData[1].addr,pActData[1].deep,pActData[1].num,
            FUNC_TO_STR(pAct->actFunc));
        }
    
    }
    return;
}

UINT32 GetVirtualId(UINT32 *pVirtualId)
{

    INPUT_POINTER_CHECK(pVirtualId);

    if(s_tBoardModle.pBoardIF == NULL)
    {
        return BSP_ERROR;
    }

    *pVirtualId = s_tBoardModle.pBoardIF->VirtualboardId;

    return BSP_OK;
}

static VOID showpreinitflow(VOID)
{
    T_BoardAction *pAct = NULL;

    dbgInfo("Board Pre Init Flow:\n");
    dbgInfo("ActType ActName                              func      \n");    
    pAct = s_tPreInitActListHead.next;
    while(pAct)
    {        
        dbgInfo("%-7d %-32s %-32s\n", pAct->actType, pAct->actName, FUNC_TO_STR(pAct->actFunc));
        pAct = pAct->next;
    }
    return;
}

static VOID showinitflow(VOID)
{
    T_BoardAction *pAct = NULL;

    dbgInfo("Board Init Flow:\n");
    dbgInfo("ActType ActName                              func      \n");    
    pAct = s_tInitActListHead.next;
    while(pAct)
    {        
        dbgInfo("%-7d %-32s %-32s\n", pAct->actType, pAct->actName, FUNC_TO_STR(pAct->actFunc));
        pAct = pAct->next;
    }
    return;    
}

VOID showboardflow(VOID)
{
    showpreinitflow();
    dbgInfo("=========================\n");
    showinitflow();
    return;
}

static VOID ShowOneLineData(CHAR *pData, UINT32 size)
{
    UINT32 loop = 0;
    UINT32 *p = (UINT32*)pData;
    UINT32 num = size/sizeof(UINT32);
    for(loop=0; loop<num; loop++)
    {
        dbgInfo("  0x%08x", p[loop]);
    }
    dbgInfo("\n");
    return;
}

static VOID ShowDataInfo(UINT32 loop, UINT32 retVal, VOID *pData, UINT32 num, UINT32 size)
{
    CHAR *pChar = NULL;
    UINT32 idx = 0;
    
    if(BSP_OK != retVal)
    {
        dbgInfo("Data[idx=%02d,num=%02d] error\n", loop, num);
    }
    else
    {   
        if(NULL == pData || 0 == num || 0 == size)
        {
            dbgInfo("Data[idx=%02d,num=%02d] is null\n", loop, num);
        }
        else 
        {
            dbgInfo("Data[idx=%02d,num=%02d] = \n", loop, num);
            pChar = (CHAR*)pData;
            for(idx=0; idx<num; idx++)
            {
                ShowOneLineData(pChar+idx*size,size);
            }
        }
    }    
}

/* 不依赖底层的简单UT测试--  确认初始化流程+参数的通用打印核对 */
static VOID showboarddata(UINT32 actType)
{
    UINT32 retVal = BSP_OK;
    T_BoardAction *pAct = NULL;
    UINT32 loop = 0;
    UINT32 size = 0;
    UINT32 part=  0;
    VOID *pData = NULL;
    UINT32 num = 0;
        
    pAct = GetBoardAction(actType);
    if(NULL != pAct && NULL != pAct->actDataArray[0].addr)
    {   
        dbgInfo("[ActType: %04d][ActName: %s]\n", actType,
            NULL == pAct->actFunc?"Data only":pAct->actName); 
        for(loop=0; loop<BOARD_ACT_DATA_MAX; loop++)
        {
            if(pAct->actDataArray[loop].addr)
            {   
                pData = NULL;
                size = 0;
                num = 0;
                if(pAct->actDataArray[loop].deep == DEEP_LEVEL1)
                {
                    retVal = GetDeep1DataInfo(&(pAct->actDataArray[loop]), &pData, &num, &size);
                    ShowDataInfo(loop, retVal, pData, num, size);
                }
                else 
                {
                    for(part=0; part<BOARD_CFG_DATA_PART_MAX; part++)
                    {
                        retVal = GetDeep2DataInfo(&(pAct->actDataArray[loop]), actType, part, &pData, &num, &size);
                        ShowDataInfo(loop, retVal, pData, num, size);
                    }
                }
            }
        }
    }
    return;
}

static UINT32 boardmodlehelp(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    dbgInfo("BOARDMODLE Help:\n");

    udPrintCnt = sizeof(s_boardModleHelpPrint) / BOARDMODLE_HELP_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        dbgInfo(" %s \n", s_boardModleHelpPrint[udCnt]);
    }

    return (UINT32)BSP_OK;
}




/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardmodlecommon.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了全机型通用的初始化接口实现
* 注意事项 : 无
* 作    者 :   王涛10248577
* 创建日期 : 2022-03-23
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2022-03-23
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "boardcorefunc.h"
#include "boardmodlecommon.h"
#include "funccommon.h"
#include "funccommon_a.h"
#include "exprn.h"
#include "funccommon_log.h"
#include "boardid.h"
#include "rruinfo.h"
#include "bspcommonstdlog.h"
#ifndef MULT_PROGRESS_S
#include "zx211413gpio.h"
#endif

/**************************************************************************
                               宏定义
**************************************************************************/
#define BOARD_MODLE_CORE_GET_ACTTYPE(compoType,actType)                  \
    if(BSP_OK != BspBoardModleGetActType(compoType, __func__, &actType)) \
    {                                                                    \
        return BSP_ERROR;                                                \
    }

/**************************************************************************
                               结构体类型定义
**************************************************************************/



/**************************************************************************
                            公共全局变量
**************************************************************************/


/**************************************************************************
                            内部接口
**************************************************************************/

static UINT32 InitExPrn(VOID)
{
    UINT32 retVal = BSP_OK;

    BspMkdir("/ata/tmplog/");
    retVal = BspLoadAreaLogLevels();
    if(BSP_ERROR == retVal)
    {
        dbgErr("area log level load fail!");
    }
    retVal = ExPrnPad(getpid());
    exprnadd("BspBoardModlePreInit");
    exprnadd("BspBoardModleInit");

    return retVal;
}


/* 信号处理函数 */
static void SignalHandle(int signo, siginfo_t *info, void *context)
{
    dbgInfo("[SignalHandle]Recv signal: %d!!!\n", signo);
}

/* 初始化时调用 */
static UINT32 BspInitSignalHandle(VOID)
{
    BspSignalHandleRegister(SignalHandle);
    #if BSP_MAKE_VER
    struct sigaction act;
    sigemptyset(&act.sa_mask);
    act.sa_flags=SA_SIGINFO;
    act.sa_sigaction=SignalHandle;
    sigaction(SIGTERM,&act,NULL);
    #endif
    return BSP_OK;
}

static UINT32 BspIdListInit(T_BoardIdItem *ptIdList, UINT32 ulNum)
{
    UINT32 idx;

    ptIdList[0].ulIdAddr = 0;
    for (idx = 1; idx < ulNum; idx++)
    {
        ptIdList[idx].ulIdAddr = ptIdList[idx-1].ulIdAddr + ptIdList[idx-1].ulIdNum;
    }
    return BSP_OK;
}

static UINT32 PrnBomid(TVerGroup *pVerGroup, UINT32 num)
{
    UINT32 ulGroupIdx      = 0;

    printf("SoftId  NickName      ModuleGroupId  BrdGroupId  BrdTypeId  HdChangeId  HdCustomIdA  HdCustomIdB  MagicNum\n");
    for (ulGroupIdx = 0; ulGroupIdx < num; ulGroupIdx++)
    {
        dbgInfo("%#6X  " , ulGroupIdx);
        dbgInfo("%-12s  ", pVerGroup[ulGroupIdx].cNickname); // 负数向左对齐
        dbgInfo("%#13X  ", pVerGroup[ulGroupIdx].HardId[MOD_GROUP_ID]);
        dbgInfo("%#10X  ", pVerGroup[ulGroupIdx].HardId[BRD_GROUP_ID]);
        dbgInfo("%#9X  " , pVerGroup[ulGroupIdx].HardId[BRD_TYPE_ID]);
        dbgInfo("%#10X  ", pVerGroup[ulGroupIdx].HardId[HW_CHANGE_ID]);
        dbgInfo("%#11X  ", pVerGroup[ulGroupIdx].HardId[HW_CUSTOM_ID_A]);
        dbgInfo("%#11X  ", pVerGroup[ulGroupIdx].HardId[HW_CUSTOM_ID_B]);
        dbgInfo("%#8X  " , pVerGroup[ulGroupIdx].HardId[BOMID_MAGIC_NUM]);
        dbgInfo("\n");
    }
    return 0;
}

/**************************************************************************
                            外部接口
**************************************************************************/

/*****************************************************************************
*  函数名称   : BspInitVerGroupPara()
*  功能描述   : 设置电源类型ver数组
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2010-05-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspCoreInitVerGroupPara(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 actType = 0;

    BOARD_MODLE_CORE_GET_ACTTYPE(E_BOARD_HARD_FEATURE_COMPO,actType);

    /* 配置VerGroup的信息 */  
    retVal |= BspBoardModleGetData(actType, 0, 0, (VOID**)(&pPara), &(num));
    if(pPara != NULL)
    {
        retVal |= BspSetHwGroup((TVerGroup*)pPara,num);
        /* 打印 */
        PrnBomid(pPara,num);  
    }
    else
    {
        dbgInfo("HwGroup is NULL");
    } 

    /* 配置VerGroupEX的信息 */
    pPara = NULL;
    retVal |= BspBoardModleGetData(actType, 1, 0, (VOID**)(&pPara), &(num));
    if(pPara != NULL)
    {
        retVal |= BspSetHwGroup_Ex((TVerGroup*)pPara,num);
    }
    else
    {
        dbgInfo("HwGroupEX is NULL"); 
    }

    /* 配置VerGroupNew的信息 */
    pPara = NULL;
    retVal |= BspBoardModleGetData(actType, 2, 0, (VOID**)(&pPara), &(num));
    if(pPara != NULL)
    {
        retVal |= BspSetHwGroup_New((TVerGroupNew*)pPara,num);
    }
    else
    {
        dbgInfo("[%s] s_HwGroup_New is NULL \n", __FUNCTION__);
    }

    /* 配置二级BomId的信息 */
    pPara = NULL;
    retVal |= BspBoardModleGetData(actType, 3, 0, (VOID**)(&pPara), &(num));
    if(pPara != NULL)
    {
        retVal |= BspSetHwGroup_SecId((TVerGroupNew*)pPara,num);
    }
    else
    {
        dbgInfo("[%s] s_HwGroup_New is NULL \n", __FUNCTION__);
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspInitDeviceIdList()
*  功能描述   : 初始化DeviceId LIST
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2010-05-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspCoreInitDeviceIdList(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 actType = 0;

    BOARD_MODLE_CORE_GET_ACTTYPE(E_BOARD_HARD_FEATURE_COMPO,actType);
    BOARD_MODLE_GET_DATA(actType,0,0,pPara,num);
    
    BspIdListInit((T_BoardIdItem*)pPara, num);
    retVal = BspSetDeviceIdList((T_BoardIdItem*)pPara, num);
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspInitThresholdIdList()
*  功能描述   : 初始化Threshold LIST
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2010-05-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspCoreInitThresholdIdList(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 actType = 0;

    BOARD_MODLE_CORE_GET_ACTTYPE(E_BOARD_HARD_FEATURE_COMPO,actType);
    BOARD_MODLE_GET_DATA(actType,0,0,pPara,num);
    BspIdListInit((T_BoardIdItem*)pPara, num);
    retVal = BspSetThresholdIdList((T_BoardIdItem*)pPara, num);
    return retVal;
}
/*****************************************************************************
*  函数名称   : BspInitFuncIdList()
*  功能描述   : 初始化FUNC LIST
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2010-05-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspCoreInitFuncIdList(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 actType = 0;

    BOARD_MODLE_CORE_GET_ACTTYPE(E_BOARD_HARD_FEATURE_COMPO,actType);
    BOARD_MODLE_GET_DATA(actType,0,0,pPara,num);
    BspIdListInit((T_BoardIdItem*)pPara, num);
    retVal = BspSetFuncIdList((T_BoardIdItem*)pPara, num);
    return retVal;
}
/*****************************************************************************
*  函数名称   : BspInitGainIdList()
*  功能描述   : 初始化GAIN LIST
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2010-05-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspCoreInitGainIdList(VOID)
{
    UINT32 retVal = BSP_OK;
     VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 actType = 0;

    BOARD_MODLE_CORE_GET_ACTTYPE(E_BOARD_HARD_FEATURE_COMPO,actType);
    BOARD_MODLE_GET_DATA(actType,0,0,pPara,num);
    BspIdListInit((T_BoardIdItem*)pPara, num);
    retVal = BspSetGainIdList((T_BoardIdItem*)pPara, num);
    return retVal;
}

UINT32 BspCoreInitExPrn(VOID)
{
    return InitExPrn();
}

UINT32 BspCoreSignalInit(VOID)
{
    return BspInitSignalHandle();
}

UINT32 BspCoreInitStatCallBackInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSet_GetBoardInitStatusCallBack(BspGetBoardInitStat);

    return retVal;
}

/*光口断链自救打桩*/
UINT32 BspBoardResetFlagInit(VOID)
{
    const char *filename = "/ata/noboardreset";
    if (BspIsFileExist(filename) == BSP_OK)
    {
        BspBoardResetDisable();
    }
    return BSP_OK;
}

UINT32 BspCoreBspLogInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspLogInitInfo *pPara = NULL;
    UINT32 num = 0;
    UINT32 actType = 0;
    BOARD_MODLE_CORE_GET_ACTTYPE(E_BOARD_SOFT_SERVICE_COMPO,actType);
    BOARD_MODLE_GET_DATA(actType,0,0,pPara,num);
    retVal = BspLogPrintExtInit(pPara->maxSize, pPara->logFileName);
    retVal |= BspBoardModleSetLogFileName(pPara->logFileName);
    BspHalAdaptOptLogPrintInit(pPara->ulOptLogType, pPara->ulOptLogSize);

#ifndef MULT_PROGRESS_S
    retVal |= BspBoardResetFlagInit();
#endif
    return retVal; 
}

/*将中断号和串口日志内存地址传递给内核，主进程调用*/
UINT32 BspSerialLogToFlashInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 interruptNum = 0;

#ifdef MULT_PROGRESS_S
    if (0 == BspGetRpuId())  /*主片上主进程已经执行，从进程不需要重复执行*/
    {
        return BSP_OK;
    }
    interruptNum = COM_INTERRUPT_NUM_D42_UART0;
#else
    UINT32 gpioVal7 = 0;
    UINT32 gpioVal12 = 0;

    gpioVal7 = _BspZteGpioGet(7);
    gpioVal12 = _BspZteGpioGet(12);

    if((1 == gpioVal7) && (1 == gpioVal12))
    {
        interruptNum = COM_INTERRUPT_NUM_D42_UART0;
    }
    else
    {
        interruptNum = COM_INTERRUPT_NUM_D42_UART5;
    }
#endif
    retVal = BspPhyAddrToKernel(APP_LOG_PHY_ADDR_D42, interruptNum );

    return retVal;
}

/*记录串口日志bspmasterapplog、bspmastermgrkmsg，主片从进程不需要重复记录，主进程已经记录*/
UINT32 BspSaveBakLogSlave(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;

    chipId = BspGetRpuId();
    if (0 == chipId)
    {
        return BSP_OK;
    }
    BspSetSlavePutSerialLogToMasterFun(BspSlavePutSerialLogToMaster);
    retVal = BspSaveBakLog();
    return retVal;
}

/*记录串口日志bspmastermgrkmsg，主片从进程不需要重复记录，主进程已经记录*/
UINT32 BspGetCurLogForMasterTaskSlave(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;

    chipId = BspGetRpuId();
    if (0 == chipId)
    {
        return BSP_OK;
    }
    retVal = BspGetCurLogForMasterTask();
    return retVal;
}

/*记录串口日志bspmastermgrcurkmsg，主片从进程不需要重复记录，主进程已经记录*/
UINT32 BspSaveKmsgLogSlave(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;

    chipId = BspGetRpuId();
    if (0 == chipId)
    {
        return BSP_OK;
    }
    retVal = BspSaveKmsgLog();
    return retVal;
}

/*将从片传过来的串口log转存到主片ata/.log/bsp目录下*/
/* Started by AICoder, pid:a5f25b63566a4038bf9b8e76c91ef6af */
VOID BspChangeSlaveSerialLogDir(VOID)
{
    INT32 snpRet = 0;
    UINT32 retVal = BSP_ERROR;
    UINT32 loop = 0;
    UINT32 ulSocMaxSum = 0;
    UINT32 chipId = 0;
    CHAR appLogFileNameBuf[255] = "";
    CHAR moveLogFileCmd[255] = "";
    CHAR sourceLogPath[255] = "";
    CHAR targetLogPath[255] = "";
    const CHAR *slaveLogFilePrefix[4] = {"app", "appcur", "kmsg", "kmsgcur"};
    const CHAR *masterLogFilePrefix[4] = {APP_LOG_BAK_FILE_PREFIX, APP_LOG_CUR_FILE_PREFIX, LAST_KMSG_FILE_PREFIX, CUR_KMSG_FILE_PREFIX};

    ulSocMaxSum = BspGetRpuNum();
    for(chipId = 1; chipId < ulSocMaxSum; chipId++)
    {
        for (loop = 0; loop < 4; loop++)
        {
            snpRet = snprintf_s(sourceLogPath, sizeof(sourceLogPath), "/ata/%s_%u_01.gz", slaveLogFilePrefix[loop], chipId);
            SNPRINTF_S_CHECK(snpRet, sizeof(sourceLogPath));
            retVal = BspIsFileExist(sourceLogPath);
            if(BSP_OK == retVal)
            {
                snpRet = snprintf_s(appLogFileNameBuf, sizeof(appLogFileNameBuf), "%s_%u", masterLogFilePrefix[loop], chipId);
                SNPRINTF_S_CHECK(snpRet, sizeof(appLogFileNameBuf));
                BspRenameLogFile(APP_LOG_PATH,appLogFileNameBuf,4);
                snpRet = snprintf_s(targetLogPath, sizeof(targetLogPath), "%s/%s_01.gz", APP_LOG_PATH, appLogFileNameBuf);
                SNPRINTF_S_CHECK(snpRet, sizeof(appLogFileNameBuf));
                snpRet = snprintf_s(moveLogFileCmd, sizeof(moveLogFileCmd), "mv %s %s", sourceLogPath, targetLogPath);
                SNPRINTF_S_CHECK(snpRet, sizeof(moveLogFileCmd));
                BspSystem(moveLogFileCmd);
            }
        }
    }
}
/* Ended by AICoder, pid:a5f25b63566a4038bf9b8e76c91ef6af */

/*将从片记录的串口log转存到主片ata/下*/
/* Started by AICoder, pid:9594af57a7d74177b740fc1418f5f742 */
VOID BspSlavePutSerialLogToMaster(VOID)
{
    INT32 snpRet = 0;
    UINT32 loop = 0;
    UINT32 chipId = 0;
    CHAR TftpCmd[255] = "";
    CHAR ip[]="198.33.33.100";
    CHAR sourceLogPath[255] = "";
    CHAR targetLogPath[255] = "";
    const CHAR *slaveLogFilePrefix[4] = {"app", "appcur", "kmsg", "kmsgcur"};
    const CHAR *masterLogFilePrefix[4] = {APP_LOG_BAK_FILE_PREFIX, APP_LOG_CUR_FILE_PREFIX, LAST_KMSG_FILE_PREFIX, CUR_KMSG_FILE_PREFIX};

    chipId = BspGetRpuId();
    for (loop = 0; loop < 4; loop++)
    {
        snpRet = snprintf_s(sourceLogPath, sizeof(sourceLogPath), "%s_01.gz", masterLogFilePrefix[loop]);
        SNPRINTF_S_CHECK(snpRet, sizeof(sourceLogPath));
        snpRet = snprintf_s(targetLogPath, sizeof(targetLogPath), "%s_%u_01.gz", slaveLogFilePrefix[loop], chipId);
        SNPRINTF_S_CHECK(snpRet, sizeof(targetLogPath));
        snpRet = snprintf_s(TftpCmd, sizeof(TftpCmd), "tftp -p %s -r /../ata/%s -l /../ata/.log/bsp/%s", ip,targetLogPath,sourceLogPath);
        SNPRINTF_S_CHECK(snpRet, sizeof(TftpCmd));
        BspSystem(TftpCmd);
    }
}
/* Ended by AICoder, pid:9594af57a7d74177b740fc1418f5f742 */

/*始化流程中打开内核维测开关*/
UINT32 BspOpenKenelSwitch(VOID)
{
    UINT32 retVal = BSP_OK;
/*    const CHAR echoCmd[255] = "echo 1 > /proc/sys/kernel/rwsem_owner_debug";
    const CHAR rwsemFile[255] = "/proc/sys/kernel/rwsem_owner_debug";

    retVal = BspIsFileExist(rwsemFile);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    BspSystem(echoCmd);*/
    return retVal;
}

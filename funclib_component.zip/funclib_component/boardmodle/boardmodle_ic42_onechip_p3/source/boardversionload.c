#include "fpgaload.h"
#include "boardversionload.h"
#include "systemcallapi.h"
#include "devdrv_fpgaload.h"
#include "funccommon.h"
#include "newunpress.h"
#include "fpgaload.h"
#include "fpga_common.h"
#include "plugandplay.h"
#include "boardmodle_ic4_2.h"
#include "funccommon_log.h"
#include "fpgaloadprocess.h"
#include "bsperrcode.h"
#include "zprintf.h"

#define loadLog(level, fmt...) BspLogPrint(BspLogAdd("loadlog", DEFAULT_LOG_LEVEL), level, ##fmt)
static void DownloadComponentsVer(const char *verName, const char *serverIp)
{
    INT32 retVal = 0;
    UINT32 loop = 0;
    CHAR ftpCmd[100] = {0};

    // IP无效不下载
    if (serverIp == NULL)
    {
        return;
    }

    /* 下载版本 */
    retVal = snprintf_s(ftpCmd, sizeof(ftpCmd), "tftp -g -r %s -l %s %s -b 16384",
                        verName, verName, serverIp);
    SNPRINTF_S_CHECK(retVal, sizeof(ftpCmd));
    for (loop = 0; loop < 5; loop++)
    {
        retVal = BspSystem(ftpCmd);
        if (retVal != 0)
        {
            // loadLog(LOG_INFO,"%s: loop %d run cmd %s failed\n", __FUNCTION__, loop, ftpCmd);
            continue;
        }
        else
        {
            break;
        }
    }
}


void verload(void)
{
    UINT32 ulVerErrReason  = 0;
    UINT32 ulVerNameStrLen = 0;
    UINT32 softType = 0;
    UINT32 ulTmpRet = BSP_OK;
    T_CtrlVerErrReason tVerErrReason = {0};
    UINT8 aucSoftVer[VERNO_LEN + 1] = {0};
    char aucLoadVerName[VERNO_LEN + 1] = {0};
    UINT8 *pucSoftVerBuf = NULL;
    UINT32 ulCnt = 0;
    T_NameSoftTypeList *softTypeList = NULL;
    UINT32 listLen = 0;

    BspGetSoftTypeList(&softTypeList, &listLen);
    for (ulCnt = 0; ulCnt < listLen; ulCnt ++)
    {
        CONTINUE_IF_EXP(softTypeList[ulCnt].versionStatus != VERSION_REQUIRED &&
                    softTypeList[ulCnt].versionStatus != VERSION_OPTIONAL_ENABLE);
        memset_s(aucSoftVer, sizeof(aucSoftVer), 0, sizeof(aucSoftVer));
        memset_s(&tVerErrReason, sizeof(tVerErrReason), 0, sizeof(tVerErrReason));
        softType = softTypeList[ulCnt].ulSoftType;
        BspGetModuleSoftVersion(softType, aucSoftVer, VERNO_LEN);
        ulVerNameStrLen = VerGetInvalidStrLen(aucSoftVer, VERNO_LEN);
        if (ulVerNameStrLen <= VERNO_LEN)
        {
            pucSoftVerBuf = aucSoftVer;
        }
        else
        {
            pucSoftVerBuf = "Ver NULL";
        }

        ulTmpRet = BspGetModuleVerErrReason(softType, &tVerErrReason);
        PRN_VER_LOAD_ERR_REASON(softTypeList[ulCnt].name, ulTmpRet, &tVerErrReason, aucLoadVerName, &ulVerErrReason);
        RedirPrintf("%s%-11d: %-25s ErrReason(%u)\n", aucLoadVerName, softType, pucSoftVerBuf, ulVerErrReason);
    }
}

void verswv(void)
{
    CHAR   temp[VERNO_LEN + 1] = {0};
    T_VerFileHeader verHead = {0};
    UINT32 ulCnt = 0;
    UINT32 softType = 0;
    CHAR fileName[NAME_MAX] = {0};
    T_NameSoftTypeList *softTypeList = NULL;
    UINT32 listLen = 0;

    if (BspGetBootVersion(temp, VERNO_LEN) == 0)
    {
        RedirPrintf("%-20s: %-20s\n", "Boot Ver(M)", temp);
    }
    BspGetSoftTypeList(&softTypeList, &listLen);
    for(ulCnt = 0;ulCnt < listLen; ulCnt ++)
    {
        CONTINUE_IF_EXP(softTypeList[ulCnt].versionStatus != VERSION_REQUIRED &&
                    softTypeList[ulCnt].versionStatus != VERSION_OPTIONAL_ENABLE);
        softType = softTypeList[ulCnt].ulSoftType;
        if (softType > SOFT_TYPE_CUR)
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/cur%u.swv", softType);
        }
        else
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/cur.swv");
        }
        (void)BspGetSwVerHead(fileName, &verHead);
        BspSecondToDate(temp, 32, verHead.ulCreateTime, 8);
        verHead.ucVerNo[VERNO_LEN-1] = '\0';
        RedirPrintf("%s%-15d: %-25s, %s\n", "Ver cur", softType,verHead.ucVerNo, temp);

        if (softType > SOFT_TYPE_CUR)
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/tmp%u.swv", softType);
        }
        else
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/tmp.swv");
        }
        (void)BspGetSwVerHead(fileName, &verHead);
        BspSecondToDate(temp, 32, verHead.ulCreateTime, 8);
        verHead.ucVerNo[VERNO_LEN-1] = '\0';
        RedirPrintf("%s%-15d: %-25s, %s\n", "Ver tmp", softType,verHead.ucVerNo, temp);

        if (BSP_OK == BspGetProtectModuleFileInfo(softType, 0, &verHead))
        {
            verHead.ucVerNo[VERNO_LEN - 1]= '\0';
            BspSecondToDate(temp, 32, verHead.ulCreateTime, 8);
            RedirPrintf("%s%-3d: %-25s, %s\n", "Ver ProtectZone cur", softType,verHead.ucVerNo, temp);
        }
        else
        {
            RedirPrintf("%s>>ProtectZone Module Ver Get Error!\n", __FUNCTION__);
        }
        showloaderr(softTypeList[ulCnt].name);
        RedirPrintf("\n");
    }
}

UINT32 BspRecordHashVer(void)
{
    int ret = 0;
    UINT32 location = 0;
    INT32 fpgaFlag = 0;
    CHAR filePath[NAME_MAX] = {0};
    T_VerFileHeader verHead = {0};
    T_XMLLIST_PARA loadVerPara = {0};

    BspSetModuleSoftVersion(SOFT_TYPE_FPGA0, NULL, 0);
    BspClrVerLoadRes();
    BspClrModuleVerErrReason(0);

    // QCELL有些环境会放XML,为了保证准确性,再加上 BspGetWriteXmlToProtectEnable 条件
    if ((BspGetWriteXmlToProtectEnable() == WRITE_XML_FILE_TO_PROTECT_ZONE) &&
        (BspGetXmlListPara(SOFT_TYPE_VERIFY, &loadVerPara) == BSP_OK))
    {
        // 此次修改前使用FPGA_VER_FLAG来确定hash文件名,在非安全环境可能存在dsp版本升级,hash版本不升级的场景
        // 宏站(非QCELL)机型,版本加载是组件化形式,hash的文件名从xml中获取,xml中的文件名是准确的.
        if (loadVerPara.ulHashSelect == 1)
        {
            location = BSP_ACK_VERSION;
        }
        else
        {
            location = BSP_RUN_VERSION;
        }
        (void)snprintf_s(filePath, sizeof(filePath), "/ata/rru/%s", loadVerPara.acFileName);
        // loadLog(LOG_INFO, "%s>>not qcell, filepath:%s\n", __FUNCTION__, filePath);
    }
    else
    {
        // QCELL机型,版本加载是非组件化形式,不使用xml,且ini文件中的FPGA_VER_FLAG只用来控制hash文件的升级状态,状态是准确的
        fpgaFlag = BspGetRruIniFlag();
        if (fpgaFlag == ACTIVE_BOOT)
        {
            location = BSP_ACK_VERSION;
            (void)snprintf_s(filePath, sizeof(filePath), "/ata/rru/tmp27.swv");
        }
        else
        {
            location = BSP_RUN_VERSION;
            (void)snprintf_s(filePath, sizeof(filePath), "/ata/rru/cur27.swv");
        }
        // loadLog(LOG_INFO, "%s>>qcell, fpgaFlag:0x%x, filepath:%s !\n", __FUNCTION__, fpgaFlag, filePath);
    }

    if (BspGetSwVerHead(filePath, &verHead) != BSP_OK)
    {
        // loadLog(LOG_INFO, "%s>>BspGetSwVerHead failed, filepath:%s !\n",__FUNCTION__,filePath);
        if (BspGetProtectVerInfo(SOFT_TYPE_VERIFY, &verHead) != BSP_OK)
        {
            return BSP_ERROR;
        }
        location = BSP_PROVERSION;
    }
    BspRecordVerLoadRes(SOFT_TYPE_VERIFY, 0, location);

    /* 设置HASH版本信息到全局变量,供版本比对使用 */
    BspSetModuleSoftVersion(SOFT_TYPE_VERIFY, verHead.ucVerNo, VERNO_LEN);
    BspSaveModuleSoftInfo(SOFT_TYPE_VERIFY, verHead.ulCRC32, verHead.ulCompressedSize + sizeof(T_VerFileHeader), verHead.ucVerNo);

    return BSP_OK;
}

static UINT32 LoadBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    CHAR cmdExe[32] = {0};
    UINT32 pidNum = 0;
    ULONG ret = 0;
    CHAR cmd[64] = {0};
    int retVal = 0;

    if (BSP_OK == BspIsPidExisted(processName, &pidNum))
    {
        if (snprintf_s(cmdExe, sizeof(cmdExe), "kill -9 %d", pidNum) < 0)
        {
            // loadLog(LOG_INFO, "%s: snprintf_s() is error\n", __FUNCTION__);
        }
        BspSystem(cmdExe);
    }

    ret = BspChmod(binFileName, "750");
    if (ret != BSP_OK)
    {
        return BSP_ERROR;
    }
    if (snprintf_s(cmd, sizeof(cmd), "%s &", binFileName) < 0)
    {
        // loadLog(LOG_INFO, "%s:snprintf_s() is error\n", __FUNCTION__);
    }
    retVal = BspSystem(cmd);
    if (retVal != BSP_OK)
    {
        // loadLog(LOG_INFO,"%s: Run %s failed, ret:%d\n", __FUNCTION__, cmd, retVal);
        return BSP_ERROR;
    }
    else
    {
        // loadLog(LOG_INFO,"%s: Run %s process success\n", __FUNCTION__, binFileName);
    }

    return BSP_OK;
}

static void BspLoadFpgaVersionFromSwv(UINT32 index, char *swvFile, T_PkgVerInfo *pkgVerInfo, UINT32 *verType, T_VerLoadInfo *verLoadInfo)
{
    CHAR preverPathName[NAME_MAX] = {0};
    UINT32 swid = 0;
    UINT32 alarmFlag = 0;
    UINT32 retval = 0;

    INPUT_POINTER_CHECK(swvFile);
    INPUT_POINTER_CHECK(pkgVerInfo);
    INPUT_POINTER_CHECK(verType);
    INPUT_POINTER_CHECK(verLoadInfo);

    swid = pkgVerInfo->tVerHeadInfo.ulSoftType;
    retval = BspGetPreverFpgaPath(swid, preverPathName, sizeof(preverPathName), &alarmFlag);
    if (retval == BSP_OK)
    {
        BspSetFpgaVerComparFlag(alarmFlag);
        if (alarmFlag == 0)
        {
            fpgaloadLog(LOAD_INFO, "%s: swid=%u 0x%x,prever file name:%s\n", __FUNCTION__, swid, swid, preverPathName);
            if (*verType == BSP_RUN_VERSION)
            {
                (void)BspBackUpFpgaSwv(swvFile);
            }
            // 加载tmp10.swv的时候,是升级场景,能保证swid和ini文件相同
            (void)remove(swvFile);
            (void)BspCopyFile(preverPathName, swvFile);
            memset_s(pkgVerInfo, sizeof(T_PkgVerInfo), 0, sizeof(T_PkgVerInfo));
            (void)BspGetFileSysPackVerInfo(swvFile, verLoadInfo->commonLoadInfo[index].verIndex, pkgVerInfo);
        }
        // 如果预装版本找不到对应的swid,继续版本加载
    }
    else
    {
        BspSetFpgaVerComparFlag(0);
    }
}

/*****************************************************************************
 *  函数名称   : BspLoadVersionFromSwv
 *  功能描述   : 加载swv压缩形式的版本
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : loadErrMask 记录错误原因
 *  输出参数   :
 *  返 回 值   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  10290326@2022-05-19 19:40:00, 创建
 *----------------------------------------------------------------------------*/
static UINT32 BspLoadVersionFromSwv(T_VerLoadInfo *verLoadInfo, UINT32 i, char *swvFile, const char *processName, const char *processPath,
                                    UINT32 softType, UINT32 hashSelect, UINT32 postRes, UINT32 *verType, UINT32 *loadErrMask)
{
    UINT32 cnt = 0;
    UINT32 retval = 0;
    BYTE *imageBuf = NULL;
    T_PkgVerInfo pkgVerInfo = {0};
    LoadBinVersionFunc loadVerFunc = NULL;
    
    
    

    INPUT_POINTER_CHECK(verType);

    pkgVerInfo.ulSoftType = softType;
    pkgVerInfo.ulPostRes = hashSelect;
    for (cnt = 0; cnt < 3; cnt++)
    {
        // loadLog(LOG_INFO, "%s: Reading %s file from %s...try, ulPostRes=%u\n", __FUNCTION__, verLoadInfo->commonLoadInfo[i].ExeName, swvFile, pkgVerInfo.ulPostRes);
        retval = BspGetFileSysPackVerInfo(swvFile, verLoadInfo->commonLoadInfo[i].verIndex, &pkgVerInfo);
        if (retval == UNPRESS_EC_DIV_NUM_ERROR)
        {
            // loadLog(LOG_INFO, "%s: %s not exist %u index package\n", __FUNCTION__, swvFile, verLoadInfo->commonLoadInfo[i].verIndex);
            return BSP_OK;
        }
        if (retval != BSP_OK)
        {
            BITS_SET(*loadErrMask, 2, (i * 4), 4);
            // loadLog(LOG_INFO, "%s: BspGetFileSysPackVerInfo failed, try use Protect File cnt:%u, ulPostRes=%u retval=0x%x\n", __FUNCTION__, cnt, pkgVerInfo.ulPostRes, retval);
            if (postRes == 1) /*版本升级过程中，直接返回错误*/
            {
                BITS_SET(*loadErrMask, 3, (i * 4), 4);
                continue;
            }
            memset_s(&pkgVerInfo, sizeof(T_PkgVerInfo), 0, sizeof(T_PkgVerInfo));
            *verType = BSP_PROVERSION;
            retval = BspGetProtectFileInfo(softType, verLoadInfo->commonLoadInfo[i].verIndex, &pkgVerInfo);
            // 如果verIndex找不到,返回成功,错误原因恢复成0
            RETURN_VAL_DO_IF_EXP(retval == UNPRESS_EC_DIV_NUM_ERROR, BSP_OK, BITS_SET(*loadErrMask, 0, (i * 4), 4);

            BspLog(LOG_LEVEL_0, "%s: %s not exist %u index protect package\n", __FUNCTION__, swvFile, verLoadInfo->commonLoadInfo[i].verIndex));
            if (retval != BSP_OK)
            {
                // loadLog(LOG_INFO, "%s:Get ProctFileInfo failed ![Ret %#x]\n",__FUNCTION__, retval);
                BITS_SET(*loadErrMask, 4, (i * 4), 4);
                continue;
            }
        }
        // FPGA0版本
        if (softType == 10)
        {
            BspLoadFpgaVersionFromSwv(i, swvFile, &pkgVerInfo, verType, verLoadInfo);
        }
        if (pkgVerInfo.tVerHeadInfo.ulOriginalSize == 0)
        {
            BITS_SET(*loadErrMask, 5, (i * 4), 4);
            // loadLog(LOG_INFO, "%s: tPkgVerInfo.tVerHeadInfo.ulOriginalSize is equal 0, cnt:%u \n", __FUNCTION__, cnt);
            continue;
        }
        // loadLog(LOG_INFO, "%s: version<%s>\n", __FUNCTION__, pkgVerInfo.tVerHeadInfo.ucVerNo);
        dbgInfo("%s: version<%s>\n", __FUNCTION__, pkgVerInfo.tVerHeadInfo.ucVerNo);
        imageBuf = (BYTE *)malloc(pkgVerInfo.tVerHeadInfo.ulOriginalSize);
        if (imageBuf == NULL)
        {
            BITS_SET(*loadErrMask, 6, (i * 4), 4);
            // loadLog(LOG_INFO, "%s: malloc %u mem failed, cnt:%u \n", __FUNCTION__, pkgVerInfo.tVerHeadInfo.ulOriginalSize, cnt);
            continue;
        }

        retval = BspGetVerPackData(&pkgVerInfo, processPath, imageBuf);
        if (retval != BSP_OK)
        {
            free(imageBuf);
            BITS_SET(*loadErrMask, 7, (i * 4), 4);
            // loadLog(LOG_INFO, "%s: BspGetVerPackData failed, cnt:%u\n", __FUNCTION__, cnt);
            continue;
        }
        free(imageBuf);
        loadVerFunc = verLoadInfo->commonLoadInfo[i].loadBinFunc;
        if (loadVerFunc == NULL)
        {
            loadVerFunc = LoadBinVersion;
        }
        retval = loadVerFunc(verLoadInfo->commonLoadInfo[i].comIndex, processPath, processName, ((T_FpgaCfgModePriv *)verLoadInfo->PrvInfo) + i, verLoadInfo->PrvLen);
        if (retval == BSP_OK)
        {
            BITS_SET(*loadErrMask, 0, (i * 4), 4);
            // loadLog(LOG_INFO, "%s: %s version load OK\n", __FUNCTION__, processName);
            break;
        }
        else
        {
            BITS_SET(*loadErrMask, 8, (i * 4), 4);
            // loadLog(LOG_INFO, "%s: %s version load failed, cnt=%u\n", __FUNCTION__, processName, cnt);
            retval = BSP_VER_LOAD_ERROR;
        }
    }

    return retval;
}

static void GetVersionSwvPath(T_VerLoadInfo *verLoadInfo, char *filePath, rsize_t pathBufLen, UINT32 *psoftType, UINT32 *verType, UINT32 *postRes, UINT32 *hashSelect)
{
    UINT32 ret = 0;
    INT32 retVal = 0;
    UINT32 softType = 0;
    const char *fileName = NULL;
    T_XMLLIST_PARA loadVerPara = {0};

    softType = BspSwitchNameToSoftType(verLoadInfo->SoftName);
    if (softType == BSP_ERROR)
    {
        // loadLog(LOG_INFO,"%s: can't get %s 's SoftType\n", __FUNCTION__, verLoadInfo->SoftName);
        return;
    }
    *psoftType = softType;
    if (verLoadInfo->loadType == VERSION_LOAD_TYPE_CUR_SWV)
    {
        fileName = verLoadInfo->swvName;
    }
    else if (verLoadInfo->loadType == VERSION_LOAD_TYPE_COMPONENTIZED)
    {
        if (verLoadInfo->swvName == NULL)
        {
            BspClrSingleVerLoadRes(softType);
            ret = BspGetXmlListPara(softType, &loadVerPara);
            if (ret != BSP_OK)
            {
                // loadLog(LOG_INFO, "%s: can't get softtype %d 's loadVerPara\n", __FUNCTION__, softType);
                return;
            }
            if (loadVerPara.ulPostRes == 1)
            {
                *verType = BSP_ACK_VERSION;
            }
            *postRes = loadVerPara.ulPostRes;
            *hashSelect = loadVerPara.ulHashSelect;
            // 如果IP有效，则下载版本文件
            DownloadComponentsVer(loadVerPara.acFileName, verLoadInfo->ftpServerIp);
            fileName = loadVerPara.acFileName;
        }
        else
        {
            fileName = verLoadInfo->swvName;
        }
    }
    retVal = snprintf_s(filePath, pathBufLen, "%s/%s", verLoadInfo->releaseVerPathPrx, fileName);
    SNPRINTF_S_CHECK(retVal, pathBufLen);
}

UINT32 BspLoadSwvVersion(T_VerLoadInfo *loadInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 ret = 0;
    char swvFile[128] = {0};
    UINT32 softType = BSP_ERROR;
    UINT32 verType = BSP_RUN_VERSION;
    UINT32 postRes = 0;
    int ret_s = 0;
    UINT32 i = 0;
    char processName[30] = {0};
    char binFileName[60] = {0};
    UINT32 loadErrMask = 0; // 每个组件4个bit的错误码，一共支持记录8个组件的错误原因
    UINT32 hashSelect = 0;
    UINT32 fpgafactoryId = 0;
    T_FpgaCfgModePriv tFpgaCfgInfo = {0};
    LoadBinVersionFunc loadVerFunc = NULL;
    GetFpgaFactory getfpgafactory = NULL;

    for (i = 0; i < loadInfo->infoLen; i++)
    {
        memset_s(processName, sizeof(processName), 0, sizeof(processName));
        memset_s(binFileName, sizeof(binFileName), 0, sizeof(binFileName));
        ret_s = snprintf_s(processName, sizeof(processName), "%s", loadInfo->commonLoadInfo[i].ExeName);
        SNPRINTF_S_CHECK(ret_s, sizeof(processName));
        ret_s = snprintf_s(binFileName, sizeof(binFileName), "/%s", processName);
        SNPRINTF_S_CHECK(ret_s, sizeof(binFileName));
        loadVerFunc = loadInfo->commonLoadInfo[i].loadBinFunc;
        getfpgafactory = loadInfo->commonLoadInfo[i].getFpgaFactory;
        if (loadVerFunc == NULL)
        {
            loadVerFunc = LoadBinVersion;
        }

        ret = loadVerFunc(loadInfo->commonLoadInfo[i].comIndex, binFileName, processName, ((T_FpgaCfgModePriv *)loadInfo->PrvInfo) + i, loadInfo->PrvLen);
        if (ret == BSP_OK)
        {
            continue;
        }

        if (i == 0)
        {
            GetVersionSwvPath(loadInfo, swvFile, sizeof(swvFile), &softType, &verType, &postRes, &hashSelect);
        }

        /*加载逻辑通过识别芯片ID选择不同的verIndex*/
        if (getfpgafactory != NULL)
        {
            fpgafactoryId = getfpgafactory(0);
            dbgInfo("fpgafactoryId = %d\n", fpgafactoryId);

            memcpy_s(&tFpgaCfgInfo, sizeof(T_FpgaCfgModePriv), ((T_FpgaCfgModePriv *)loadInfo->PrvInfo) + i, sizeof(T_FpgaCfgModePriv));
            if (fpgafactoryId != tFpgaCfgInfo.tFpgaCfgPrivEx.devType)
            {
                continue;
            }
        }

        dbgInfo("fpga version loop = %d num = %d\n", i, loadInfo->infoLen);

        retVal |= BspLoadVersionFromSwv(loadInfo, i, swvFile, processName, binFileName, softType, hashSelect, postRes, &verType, &loadErrMask);
    }
#ifndef PLAT_X86_TEST
    if (loadInfo->swvName == NULL || loadInfo->loadType != VERSION_LOAD_TYPE_COMPONENTIZED)
    {
        BspRecordVerLoadRes(softType, loadErrMask, verType);
    }
#endif
    return retVal;
}

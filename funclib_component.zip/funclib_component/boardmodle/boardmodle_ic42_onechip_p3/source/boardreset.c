/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeature-hardid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "funccommon.h"
#include "boardid.h"
#include "boardreset.h"
#include "funccommon_a.h"
#include "regdrv.h"
#include "ichaladapt_ic4_2.h"
#include "board_ic4_2.h"
#include "pa_ic4_2_ctrl.h"
// #include "gainctrlcommon.h"
#include "systemcallapi.h"
#include "cpam_inter_api.h"
// #include "dpdicxmodem.h"
// #include "optctrlcommon.h"
#include "fpgaloadprocess.h"
#include "ichaladapt_crm_ic4_2.h"
#include "zprintf.h"

/**************************************************************************
 *                            全局变量定义                                       *
 **************************************************************************/
#define DPDIC_RST_TYPE_INFO(chipIdx)                               \
    {                                                              \
        REG_RPU##chipIdx##_EXT_RESET, REG_RPU##chipIdx##_POR_RESET \
    }
#define IF(x) if (x)
#define FOR(x) for (x)
static T_FpgaReLoadFlagFun s_fpgaReLoadFlagFun =
    {

        .FpgaReLoadFlagSet = BspFpgaReLoadFlagSet,
        .FpgaReLoadFlagGet = BspFpgaReLoadFlagGet,
        .InitFlag = 1,
};

static UINT32 g_ulFpgaReLoadFlag = 0xffffffff;
static UINT32 rstEnableFlag = 0x5a5a;
static UINT32 s_DisableFlowCtrl = DISABLE;
static E_BOARD_MS_FLAG s_MsFlag = E_OTHER_BOARD_TYPE;
static FUNC_BSP_BOARD_SOC_RESET s_pFuncBoardSocReset = NULL;
/*配置是否初始化时钟或光口的标志，0为不初始化，1位初始化*/
VOID BspFpgaReLoadFlagSet(UINT32 ulReFlag)
{
    UINT32 ulRegVal = 0;
    UINT32 bitVal = 0;
    UINT32 regAddr = 0xd4c001d0;
    DpdIcHalAddrRegRd(0, regAddr, 0, &ulRegVal);
    dbgInfo("[%s] source reg value is %d\n", __FUNCTION__, ulRegVal);
    bitVal = (ulReFlag == 0) ? (1) : (0); // 上电默认值是0
    if (bitVal == 0)
    {
        ulRegVal = BIT_REV(0) & ulRegVal;
    }
    else
    {
        ulRegVal = BIT_SET(0) | ulRegVal;
    }
    dbgInfo("[%s] bitVal'%d ulRegVal'%d\n", __FUNCTION__, bitVal, ulRegVal);
    DpdIcHalAddrRegWr(0, regAddr, 0, ulRegVal); /*bit0为 是否重配光口的标志*/
}

/*获取是否初始化时钟或光口的标志，0为不初始化，1位初始化*/
UINT32 BspFpgaReLoadFlagGet(VOID)
{
    UINT32 ulRegVal = 1;
    UINT32 regAddr = 0xd4c001d0;
    if (g_ulFpgaReLoadFlag != 0xffffffff)
    {
        return g_ulFpgaReLoadFlag;
    }
    DpdIcHalAddrRegRd(0, regAddr, 0, &ulRegVal);
    g_ulFpgaReLoadFlag = ((ulRegVal & 0x1) == 0) ? (1) : (0);
    dbgInfo("%sFpga reload RegVal 0x%x\n", __FUNCTION__, ulRegVal);
    BspFpgaReLoadFlagSet(0); /*获取后将标志改为默认不初始化时钟和光口状态*/
    return g_ulFpgaReLoadFlag;
}

VOID BspResetFpga(UINT32 chipId)
{
    switch (chipId)
    {
    case 0:
        /*             BspRegPinWr(DRV_REG_FPGA0_RESET,0);
                    BspSysUsDelay(10);
                    BspRegPinWr(DRV_REG_FPGA0_RESET,1);
                    BspSysUsDelay(10);
                    BspRegPinWr(DRV_REG_FPGA0_RESET,0); */
        break;
    default:
        break;
    }
}

/*适用于单片*/
UINT32 BspResetDeviceInit(VOID)
{
    // BspSetMasterSlaveFlag(E_MASTER_BOARD_TYPE);
    // BspResetDeviceCallBackInit(BspDevReset);
    BspInitFpgaReLoadFun(&s_fpgaReLoadFlagFun);
    return BSP_OK;
}

UINT32 RruLinkPwrOffEnable()
{
    BspRruLinkPwrOffEnable(0x5A5A);
    return BspRruLinkPwrOffRruCfgChk();
}

UINT32 RruLinkPwrOffInit()
{
    UINT32 retVal = 0;
    unsigned long virAddr = 0;
    UINT32 ramOffset = 290*SIZE_1K; /* 34K+256K */
    UINT32 ramSize = 16;
    virAddr = BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP);
    if ((UINT32)BSP_ERROR == virAddr)
    {
    	BspLog(LOG_LEVEL_0,"%s get reserve mem addr error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    retVal = BspRruLinkPwrOffInit();
    if (BSP_OK == retVal)
    {
        retVal = BspRruLinkBreakTimeInit(virAddr+ramOffset,ramSize);
        BspLog(LOG_LEVEL_0,"%s pwr init ok,break time init %d\n",__FUNCTION__,retVal);
    }
    return retVal;
}
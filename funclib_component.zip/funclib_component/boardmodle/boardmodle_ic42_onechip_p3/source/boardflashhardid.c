/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardhardid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板从Flash读取Bomid的函数接口实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "rruinfo.h"
#include "exprn.h"
#include "bspcomm.h"
#include "crc.h"
#include "boardhardid.h"
#include "flash.h"
#include "zprintf.h"

/**************************************************************************
 *                            全局变量定义                                       *
 **************************************************************************/
static UINT32 s_ulFlashBomidCfgResult = 0xFFFFFFFF;
static UINT32 s_ulTpsDefCfgStatus = 0;
static UINT32 s_ulFlashBomidOffset = 0;

/**************************************************************************
 *                                宏定义                                      *
 **************************************************************************/
#define FLASH_MODULE_GROUP_ID_L (s_ulFlashBomidOffset + (UINT32)0)      // BOMID绝对地址 + 0 个字节
#define FLASH_BOARD_GROUP_ID_L (s_ulFlashBomidOffset + (UINT32)1)       // BOMID绝对地址 + 1 个字节
#define FLASH_BOARD_TYPE_ID_L (s_ulFlashBomidOffset + (UINT32)2)        // BOMID绝对地址 + 2 个字节
#define FLASH_BOARD_HARD_CHANGE_ID_L (s_ulFlashBomidOffset + (UINT32)3) // BOMID绝对地址 + 3 个字节
#define FLASH_HARDWARE_CUSTOM_A_L (s_ulFlashBomidOffset + (UINT32)4)    // BOMID绝对地址 + 4 个字节
#define FLASH_HARDWARE_CUSTOM_B_L (s_ulFlashBomidOffset + (UINT32)5)    // BOMID绝对地址 + 5 个字节
#define FLASH_MODULE_GROUP_ID_H (s_ulFlashBomidOffset + (UINT32)6)      // BOMID绝对地址 + 6 个字节
#define FLASH_BOARD_GROUP_ID_H (s_ulFlashBomidOffset + (UINT32)7)       // BOMID绝对地址 + 7 个字节
#define FLASH_BOARD_TYPE_ID_H (s_ulFlashBomidOffset + (UINT32)8)        // BOMID绝对地址 + 8 个字节
#define FLASH_BOARD_HARD_CHANGE_ID_H (s_ulFlashBomidOffset + (UINT32)9) // BOMID绝对地址 + 9 个字节
#define FLASH_HARDWARE_CUSTOM_A_H (s_ulFlashBomidOffset + (UINT32)10)   // BOMID绝对地址 + 10个字节
#define FLASH_HARDWARE_CUSTOM_B_H (s_ulFlashBomidOffset + (UINT32)11)   // BOMID绝对地址 + 11个字节
#define FLASH_BOMID_CRC_OFFSET_H (s_ulFlashBomidOffset + (UINT32)12)    // BOMID绝对地址 + 12个字节
#define FLASH_BOMID_CRC_OFFSET_L (s_ulFlashBomidOffset + (UINT32)13)    // BOMID绝对地址 + 13个字节
#define FLASH_BOMID_MAGIC_NUM_A_L (s_ulFlashBomidOffset + (UINT32)14)   // BOMID绝对地址 + 14个字节
#define FLASH_BOMID_MAGIC_NUM_B_H (s_ulFlashBomidOffset + (UINT32)15)   // BOMID绝对地址 + 15个字节

#define BOARD_BOMID_MAGIC_NUM 0xA5C3

// 正常返回 BSP_OK
UINT32 BspGetBomidFromFlash(TVerGroup *ptBomidInfo)
{
    UCHAR aucGetBomId[16] = {0};
    UINT32 ulBomIdCrcCalc = 0xF0F0FFFF;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;

    //  INPUT_POINTER_CHECK(ptBomidInfo);
    if ((TVerGroup *)NULL == ptBomidInfo)
    {
        ulRetVal |= BIT_SET(0);
        dbgErr("%s>>Error! pBomidInfo cannot NULL\n", __FUNCTION__);
        return ulRetVal;
    }

    /* 注意: aucGetBomId[12]= Addr[0x0D](FLASH_BOMID_CRC_OFFSET_L): CRC16 Low  8Bit,
             aucGetBomId[13]= Addr[0x0C](FLASH_BOMID_CRC_OFFSET_H): CRC16 High 8Bit */
    ulTmpRet |= BspFlashRead(FLASH_MODULE_GROUP_ID_L, &aucGetBomId[0], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOARD_GROUP_ID_L, &aucGetBomId[1], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOARD_TYPE_ID_L, &aucGetBomId[2], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOARD_HARD_CHANGE_ID_L, &aucGetBomId[3], 1);
    ulTmpRet |= BspFlashRead(FLASH_HARDWARE_CUSTOM_A_L, &aucGetBomId[4], 1);
    ulTmpRet |= BspFlashRead(FLASH_HARDWARE_CUSTOM_B_L, &aucGetBomId[5], 1);
    ulTmpRet |= BspFlashRead(FLASH_MODULE_GROUP_ID_H, &aucGetBomId[6], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOARD_GROUP_ID_H, &aucGetBomId[7], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOARD_TYPE_ID_H, &aucGetBomId[8], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOARD_HARD_CHANGE_ID_H, &aucGetBomId[9], 1);
    ulTmpRet |= BspFlashRead(FLASH_HARDWARE_CUSTOM_A_H, &aucGetBomId[10], 1);
    ulTmpRet |= BspFlashRead(FLASH_HARDWARE_CUSTOM_B_H, &aucGetBomId[11], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOMID_CRC_OFFSET_L, &aucGetBomId[12], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOMID_CRC_OFFSET_H, &aucGetBomId[13], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOMID_MAGIC_NUM_A_L, &aucGetBomId[14], 1);
    ulTmpRet |= BspFlashRead(FLASH_BOMID_MAGIC_NUM_B_H, &aucGetBomId[15], 1);
    if (BSP_OK != ulTmpRet)
    {
        ulRetVal |= BIT_SET(1);
        dbgErr("%s>>BomId FlashRead Error!\n", __FUNCTION__);
    }

    ptBomidInfo->HardId[MOD_GROUP_ID] = (aucGetBomId[6] << 8) | aucGetBomId[0];
    ptBomidInfo->HardId[BRD_GROUP_ID] = (aucGetBomId[7] << 8) | aucGetBomId[1];
    ptBomidInfo->HardId[BRD_TYPE_ID] = (aucGetBomId[8] << 8) | aucGetBomId[2];
    ptBomidInfo->HardId[HW_CHANGE_ID] = (aucGetBomId[9] << 8) | aucGetBomId[3];
    ptBomidInfo->HardId[HW_CUSTOM_ID_A] = (aucGetBomId[10] << 8) | aucGetBomId[4];
    ptBomidInfo->HardId[HW_CUSTOM_ID_B] = (aucGetBomId[11] << 8) | aucGetBomId[5];
    ptBomidInfo->HardId[BOMID_CRC_DATA] = (aucGetBomId[13] << 8) | aucGetBomId[12];
    ptBomidInfo->HardId[BOMID_MAGIC_NUM] = (aucGetBomId[15] << 8) | aucGetBomId[14];

    ulBomIdCrcCalc = (UINT32)BspCountCrc16(0xFFFF, aucGetBomId, 12); // BspCountCRC8
    if (ptBomidInfo->HardId[BOMID_CRC_DATA] != ulBomIdCrcCalc)
    {
        ulRetVal |= BIT_SET(2);
        dbgErr("%s>>BomId CrcCheck Error! Crc= Flash'0x%04X Calc'0x%04X\n", __FUNCTION__,
               ptBomidInfo->HardId[BOMID_CRC_DATA], ulBomIdCrcCalc);
    }

    if (BOARD_BOMID_MAGIC_NUM != ptBomidInfo->HardId[BOMID_MAGIC_NUM])
    {
        ulRetVal |= BIT_SET(3);
        dbgErr("%s>>MagicNum Get Error! MagicNum= 0x%04X\n", __FUNCTION__,
               ptBomidInfo->HardId[BOMID_MAGIC_NUM]);
    }

    dbgInfoEx("%s>>BomId: 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X\n", __FUNCTION__,
              ptBomidInfo->HardId[MOD_GROUP_ID], ptBomidInfo->HardId[BRD_GROUP_ID],
              ptBomidInfo->HardId[BRD_TYPE_ID], ptBomidInfo->HardId[HW_CHANGE_ID],
              ptBomidInfo->HardId[HW_CUSTOM_ID_A], ptBomidInfo->HardId[HW_CUSTOM_ID_B],
              ptBomidInfo->HardId[BOMID_MAGIC_NUM], ptBomidInfo->HardId[BOMID_CRC_DATA]);

    return ulRetVal;
}

UINT32 BspSetFlashBomidCfgResult(UINT32 ulCfgIdx, UINT32 ulCfgFlag)
{
    if (ulCfgIdx >= 8)
    {
        dbgErr("%s>>Error! CfgIdx Over; CfgIdx= %d\n", __FUNCTION__, ulCfgIdx);
        return BSP_ERROR;
    }
    s_ulFlashBomidCfgResult &= ~(0x0F << (ulCfgIdx * 4));
    s_ulFlashBomidCfgResult |= (ulCfgFlag & 0x0F) << (ulCfgIdx * 4);

    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspGetBoardBomidCrcDataPara
 *  功能描述   : 获取硬件BomidCrcData
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 硬件信息
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
 *  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
 *----------------------------------------------------------------------------
 */
UINT32 BspGetBoardBomidCrcDataPara(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulHwCustomIdRet = 0xFFFF;

    if (0xFFFF != ulHwCustomIdRet)
    {
        return ulHwCustomIdRet;
    }

    ulBomInfoIdx = BOMID_CRC_DATA;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        // 从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulHwCustomIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>BomidCrc= (0x%08X) %d\n", __FUNCTION__,
              ulHwCustomIdRet, ulHwCustomIdRet);

    return ulHwCustomIdRet;
}
/*****************************************************************************
 *  函数名称   : BspGetHardwareMagicNumPara
 *  功能描述   : 获取硬件MagicNum
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 硬件信息
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
 *  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
 *----------------------------------------------------------------------------
 */
UINT32 BspGetHardwareMagicNumPara(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulHwCustomIdRet = 0xFFFF;

    if (0xFFFF != ulHwCustomIdRet)
    {
        return ulHwCustomIdRet;
    }

    ulBomInfoIdx = BOMID_MAGIC_NUM;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        //  从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        //  tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulHwCustomIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>MagicNum= (0x%08X) %d\n", __FUNCTION__,
              ulHwCustomIdRet, ulHwCustomIdRet);

    return ulHwCustomIdRet;
}
UINT32 BspGetHardwareCustomIdPara_B(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulHwCustomIdRet = 0xFFFF;

    if (0xFFFF != ulHwCustomIdRet)
    {
        return ulHwCustomIdRet;
    }

    ulBomInfoIdx = HW_CUSTOM_ID_B;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        //  从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        //  tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulHwCustomIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>HwCustomIdA= (0x%08X) %d\n", __FUNCTION__,
              ulHwCustomIdRet, ulHwCustomIdRet);

    return ulHwCustomIdRet;
}

/*****************************************************************************
 *  函数名称   : BspGetHardwareChangeIdPara
 *  功能描述   : 获取硬件变更ID
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 硬件信息
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
 *  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
 *----------------------------------------------------------------------------
 */
UINT32 BspGetHardwareChangeIdPara(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulHwChangeIdRet = 0xFFFF;

    if (0xFFFF != ulHwChangeIdRet)
    {
        return ulHwChangeIdRet;
    }

    ulBomInfoIdx = HW_CHANGE_ID;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        //  从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        //  tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulHwChangeIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>HwChangeId= (0x%04X) %d\n", __FUNCTION__,
              ulHwChangeIdRet, ulHwChangeIdRet);

    return ulHwChangeIdRet;
}

/*****************************************************************************
 *  函数名称   : BspGetBoardTypeIdPara
 *  功能描述   : 获取单板类型
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 硬件信息
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
 *  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
 *----------------------------------------------------------------------------
 */
UINT32 BspGetBoardTypeIdPara(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulBrdTypeIdRet = 0xFFFF;

    if (0xFFFF != ulBrdTypeIdRet)
    {
        return ulBrdTypeIdRet;
    }

    ulBomInfoIdx = BRD_TYPE_ID;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        //  从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        //  tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulBrdTypeIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>BoardTypeId= (0x%04X) %d\n", __FUNCTION__,
              ulBrdTypeIdRet, ulBrdTypeIdRet);

    return ulBrdTypeIdRet;
}

/*****************************************************************************
 *  函数名称   : BspGetBoardGroupIdPara
 *  功能描述   : 获取单板组ID
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 硬件信息
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
 *  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
 *----------------------------------------------------------------------------
 */
UINT32 BspGetBoardGroupIdPara(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulBrdGroupIdRet = 0xFFFF;

    if (0xFFFF != ulBrdGroupIdRet)
    {
        return ulBrdGroupIdRet;
    }

    ulBomInfoIdx = BRD_GROUP_ID;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        //  从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        //  tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulBrdGroupIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>BoardGroupId= (0x%04X) %d\n", __FUNCTION__,
              ulBrdGroupIdRet, ulBrdGroupIdRet);

    return ulBrdGroupIdRet;
}

/*****************************************************************************
 *  函数名称   : BspGetModuleGroupIdPara
 *  功能描述   : 获取模组ID
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 硬件信息
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
 *  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
 *----------------------------------------------------------------------------
 */
UINT32 BspGetModuleGroupIdPara(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulModuleGroupIdRet = 0xFFFF;

    if (0xFFFF != ulModuleGroupIdRet)
    {
        return ulModuleGroupIdRet;
    }

    ulBomInfoIdx = MOD_GROUP_ID;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        //  从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        //  tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulModuleGroupIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>ModuleGroupId= (0x%04X) %d\n", __FUNCTION__,
              ulModuleGroupIdRet, ulModuleGroupIdRet);

    return ulModuleGroupIdRet;
}

/*****************************************************************************
 *  函数名称   : BspGetHardwareCustomIdPara_A
 *  功能描述   : 获取硬件CustomId
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 硬件信息
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
 *  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
 *----------------------------------------------------------------------------
 */
UINT32 BspGetHardwareCustomIdPara_A(VOID)
{
    UINT32 ulBomInfoIdx = 0;
    UINT32 ulRetVal = BSP_OK;
    TVerGroup tVerBomidInfo = {
        0,
    };
    static UINT32 ulHwCustomIdRet = 0xFFFF;

    if (0xFFFF != ulHwCustomIdRet)
    {
        return ulHwCustomIdRet;
    }

    ulBomInfoIdx = HW_CUSTOM_ID_A;
    ulRetVal = BspGetBomidFromFlash(&tVerBomidInfo);
    if (BSP_OK != ulRetVal)
    {
        //  从Flash中获取异常, CRC上报0xFFFF, 其它BomID上报获取值;
        //  tVerBomidInfo.HardId[ulBomInfoIdx] = 0xFFFF;
        dbgErr("%s>>BomidFromFlash Get Error!\n", __FUNCTION__);
    }

    BspSetFlashBomidCfgResult(ulBomInfoIdx, ulRetVal);
    ulHwCustomIdRet = tVerBomidInfo.HardId[ulBomInfoIdx];

    dbgInfoEx("%s>>HwCustomIdA= (0x%08X) %d\n", __FUNCTION__,
              ulHwCustomIdRet, ulHwCustomIdRet);

    return ulHwCustomIdRet;
}

UINT32 BspHwCustomIdAnalyseInit(VOID)
{
    UINT32 ulSfpModFlag = 0;
    UINT32 hwCustomId_A = 0;
    //  UINT32 hwCustomId_B  = 0;
    //  UINT32 ulPwrVoltType = 0;
    UINT32 ulFunRet = BSP_OK;
    T_HwCustomIdAnalyseInfo tHwCustomIdInfo = {
        0,
    };

    //  ulPwrVoltType = BspGetPwrHwDefineType();

    /* 预留或不支持的元素默认为 BSP_ERROR */
    memset((VOID *)&tHwCustomIdInfo, 0xFF, sizeof(T_HwCustomIdAnalyseInfo));

    hwCustomId_A = BspGetHardwareCustomIdPara_A(); // RruInfo接口: BspGetHardwareCustomId_A();
                                                   //  hwCustomId_B = BspGetHardwareCustomIdPara_B(); // RruInfo接口: BspGetHardwareCustomId_B();
    if (hwCustomId_A >= 0xFFFF)
    {
        dbgErr("%s>>HardwareCustomIdPara_A Get Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    tHwCustomIdInfo.ulAnalyseFlag = RRUINFO_HW_CUSTOM_ID_ANALYSE_FLAG;
    tHwCustomIdInfo.ulPaVoltType = (hwCustomId_A >> 0) & 0x01;
    tHwCustomIdInfo.ulPaBankAType = (hwCustomId_A >> 1) & 0x01;
    tHwCustomIdInfo.ulPaBankBType = (hwCustomId_A >> 2) & 0x01;
    tHwCustomIdInfo.ulPaBypassFlag = (hwCustomId_A >> 3) & 0x01;
    tHwCustomIdInfo.ulTecSupportFlag = (hwCustomId_A >> 4) & 0x01;
    tHwCustomIdInfo.ulPlcSupportFlag = (hwCustomId_A >> 5) & 0x01;
    tHwCustomIdInfo.ulPlcBrandType = (hwCustomId_A >> 6) & 0x03;
    tHwCustomIdInfo.ulMcsChipType = (hwCustomId_A >> 8) & 0x01;
    tHwCustomIdInfo.ulMcsDdrSizeType = (hwCustomId_A >> 9) & 0x01;
    tHwCustomIdInfo.ulMcsDdrChipType = (hwCustomId_A >> 10) & 0x01;
    tHwCustomIdInfo.ulOokSupportFlag = (hwCustomId_A >> 11) & 0x01;
    tHwCustomIdInfo.ulFanSupportFlag = (hwCustomId_A >> 12) & 0x01;
    tHwCustomIdInfo.ulEpldChipType = (hwCustomId_A >> 13) & 0x03;

    ulSfpModFlag = (hwCustomId_A >> (UINT32)15) & (UINT32)0x01;
    if (0 == ulSfpModFlag)
    {
        tHwCustomIdInfo.ulSfpModuleType = (UINT32)E_SFP;
    }
    else
    {
        tHwCustomIdInfo.ulSfpModuleType = (UINT32)E_DSFP;
    }

    /* 硬件自定义BOMID与硬件上报信息不一致, 设置异常值;
       其它元素的对比根据需要补充 ??? */

    ulFunRet = BspSetHwCustomIdAnalyseInfo(&tHwCustomIdInfo);

    return ulFunRet;
}

#ifndef USE_SOCMSG_BOMID
UINT32 BspInitAdpBdHwIdInfoPara(VOID)
{
    UINT32 retVal = BSP_OK;
    TVerGroup tHwIdInfo = {
        0,
    };

    tHwIdInfo.HardId[MOD_GROUP_ID] = BspGetModuleGroupIdPara();
    tHwIdInfo.HardId[BRD_GROUP_ID] = BspGetBoardGroupIdPara();
    tHwIdInfo.HardId[BRD_TYPE_ID] = BspGetBoardTypeIdPara();
    tHwIdInfo.HardId[HW_CHANGE_ID] = BspGetHardwareChangeIdPara();
    tHwIdInfo.HardId[HW_CUSTOM_ID_A] = BspGetHardwareCustomIdPara_A();
    tHwIdInfo.HardId[HW_CUSTOM_ID_B] = BspGetHardwareCustomIdPara_B();
    tHwIdInfo.HardId[BOMID_MAGIC_NUM] = BspGetHardwareMagicNumPara();
    tHwIdInfo.HardId[BOMID_CRC_DATA] = BspGetBoardBomidCrcDataPara();

    retVal = BspSetHwId_16(&tHwIdInfo);
    retVal |= BspHwCustomIdAnalyseInit();
    return retVal;
}
#endif

VOID BspSetFlashBomidOffset(UINT32 offset)
{
    s_ulFlashBomidOffset = offset;
}

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : adsboardid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了调整进程CPU亲和力的接口实现
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "zprintf.h"
#include "exprn.h"

/**************************************************************************
                                 宏定义
**************************************************************************/

#define CPU_CORE_ID_MAX_SUM (4)
#define CPU_CORE_ID_MASK_SUM (0xF)
#define PID_NAME_MAX_NUM (10)
#define STR_ARR_CPY(a, b) strncpyex(a, b, sizeof(a))

/**************************************************************************
                                 内部接口
**************************************************************************/

static char *strncpyex(char *dest, const char *src, int len)
{
    char *p;
    memset(dest, 0, len);
    p = strncpy(dest, src, len - 1);
    return p;
}

static INT8 *BspGetNumFromStr(INT8 *pachStr, INT32 wIndex)
{
    CHAR seps[] = " ";
    CHAR *token = NULL;
    CHAR *holder = NULL; /* points to initString fragment beyond tok */
    int wLoop = 0;
    static CHAR aucBufVar[128] = {0};

    INPUT_POINTER_CHECK_RETURN_NULL(pachStr);
    STR_ARR_CPY(aucBufVar, pachStr);

    while (1)
    {
        /* While there are tokens in "string" */
        /* Get next token: */
        if (0 == wLoop)
        {
            token = strtok_r(aucBufVar, seps, &holder);
        }
        else
        {
            token = strtok_r(NULL, seps, &holder);
        }
        if (NULL == token)
        {
            /* 不满足要求 需要立即退出 */
            return token;
        }
        if (wLoop == wIndex)
        {
            /* dbgInfo( " %s\n", token ); */
            return token;
        }
        wLoop++;
    }
}

static UINT32 GetProcPidsByName(UINT8 *pucPathProcName, UINT32 *pulProcPidNo, UINT32 ulPidNum)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulCnt = 0;
    CHAR acGetBuf[64] = " ";
    CHAR acCmdBuf[64] = " ";
    UINT8 *pucRetHandle = NULL;
    CHAR *pcPidNum = NULL;
    FILE *pFileHandle = NULL;
    INT32 lSnpRet = 0;

    if ((NULL == pucPathProcName) || (NULL == pulProcPidNo))
    {
        ulRetVal |= BIT_SET(0);
        dbgErr("%s>>Error! PathProcName or ProcPidNo is NULL !\n", __FUNCTION__);
        return ulRetVal;
    }

    lSnpRet = snprintf_s(acCmdBuf, sizeof(acCmdBuf), "pidof %s", pucPathProcName);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(acCmdBuf));

    pFileHandle = popen(acCmdBuf, "r");
    if (NULL == pFileHandle)
    {
        ulRetVal |= BIT_SET(1);
        dbgErr("%s>>%s Open Error!\n", __FUNCTION__, acCmdBuf);
        return ulRetVal;
    }
    sleep(2);
    pucRetHandle = fgets(acGetBuf, sizeof(acGetBuf) - 2, pFileHandle);
    if (NULL == pucRetHandle)
    {
        dbgErr("%s>> Fgets Char Error!\n", __FUNCTION__);
        pclose(pFileHandle);
        return BSP_ERROR;
    }
    pclose(pFileHandle);
    for (ulCnt = 0; ulCnt < min(ulPidNum, PID_NAME_MAX_NUM); ulCnt++)
    {
        pcPidNum = BspGetNumFromStr(pucRetHandle, ulCnt);
        if (pcPidNum != NULL)
        {
            *(pulProcPidNo + ulCnt) = (int)strtol(pcPidNum, (char **)NULL, 10);
        }
    }
    return ulRetVal;
}

static UINT32 GetProcPidByName(UINT8 *pucPathProcName, UINT32 *pulProcPidNo)
{
    return GetProcPidsByName(pucPathProcName, pulProcPidNo, 1);
}

static UINT32 ProcAffinitySet(UINT32 ulProcPidNo, UINT32 ulCpuCoreMask)
{
    pid_t iTmpPidNum = 0;
    UINT32 ulTmpVal = BSP_OK;
    UINT32 coreId = 0;
    cpu_set_t tSetCpuMask = {0};

    iTmpPidNum = (pid_t)ulProcPidNo; // MGR_MCS进程号
    CPU_ZERO(&tSetCpuMask);          // 置空CPU核的集合
    for (coreId = 0; coreId < CPU_CORE_ID_MAX_SUM; coreId++)
    {
        if ((BIT_SET(coreId) & ulCpuCoreMask) != 0)
        {
            CPU_SET(coreId, &tSetCpuMask); // 设置亲和力值, 将一个给定CPU号加到一个集合
        }
    }

    /* 设置进程为Pid的进程运行在Mask所设定的CPU核上; 如果Pid为0, 则表示指
       定当前的进程; 如果当前pid所指定的CPU没有运行在 Mask所指定的任意一个
       CPU上, 则改指定的进程会从其它CPU上迁移到Mask指定的一个CPU上运行 */
    ulTmpVal = (UINT32)sched_setaffinity(iTmpPidNum, sizeof(cpu_set_t), &tSetCpuMask);
    if (BSP_ERROR == ulTmpVal)
    {
        dbgErr("%s>>ProcNo'%d Core'%d ProcAffinity Set Error!\n",
               __FUNCTION__, ulProcPidNo, ulCpuCoreMask);
        return BSP_ERROR;
    }

    dbgInfo("%s>>CoreIdx'%d ProcNo'%d Run ProcessorMask: 0x%02X\n", __FUNCTION__,
            ulCpuCoreMask, iTmpPidNum, tSetCpuMask.__bits[0]);

    return BSP_OK;
}

// 获取进程CPU亲和力
static UINT32 ProcAffinityGet(UINT32 ulProcPidNo, UINT32 *pulCoreIdMask)
{
    pid_t iTmpPidNum = 0;
    UINT32 ulProcCoreMask = 0;
    UINT32 ulCpuIssetFlag = 0;
    UINT32 ulCpuCoreIdIdx = 0;
    UINT32 ulCoreProcsSum = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;
    cpu_set_t tGetCpuMask = {0};

    iTmpPidNum = (pid_t)ulProcPidNo; // MGR_MCS进程号
    CPU_ZERO(&tGetCpuMask);          // 置空CPU核的集合

    ulCoreProcsSum = sysconf(_SC_NPROCESSORS_CONF); /* 获取核总数 */
    if (ulCoreProcsSum > CPU_CORE_ID_MAX_SUM)
    {
        ulRetVal |= BIT_SET(0);
        dbgErr("%s>>Error! CpuCoreSum Over; CoreSum(0~%d)= %d\n",
               __FUNCTION__, CPU_CORE_ID_MAX_SUM, ulCoreProcsSum);
        return ulRetVal;
    }

    /* 获取在集合的CPU核, 即获得pid所指定的进程的CPU位掩码, 并将改掩码
       返回到mask所指向的结构中, 即获得指定pid当前可以运行在哪些CPU */
    ulTmpRet = (UINT32)sched_getaffinity(iTmpPidNum, sizeof(cpu_set_t), &tGetCpuMask);
    if (BSP_ERROR == ulTmpRet)
    {
        ulRetVal |= BIT_SET(1);
        dbgErr("%s>>ProcNo'%d Affinity Get Error!\n", __FUNCTION__, iTmpPidNum);
        return ulRetVal;
    }

    ulCpuIssetFlag = 0;
    ulProcCoreMask = 0;
    for (ulCpuCoreIdIdx = 0; ulCpuCoreIdIdx < ulCoreProcsSum; ulCpuCoreIdIdx++)
    {
        /* 检查CPU是否在这个集合中, 在返回非零值, 否则返回零值 */
        ulTmpRet = (UINT32)CPU_ISSET(ulCpuCoreIdIdx, &tGetCpuMask);
        if (0 != ulTmpRet)
        {
            ulCpuIssetFlag++;
            ulProcCoreMask |= BIT_SET(ulCpuCoreIdIdx);
            dbgInfoEx("%s>>Ret= %d; ProcNo'%d Run ProcessorCore: Mask'0x%02X Id'%d\n", __FUNCTION__,
                      ulTmpRet, iTmpPidNum, tGetCpuMask.__bits[0], ulCpuCoreIdIdx);
        }
    }

    if (NULL != pulCoreIdMask)
    {
        *pulCoreIdMask = ulProcCoreMask;
    }

    if (0 == ulCpuIssetFlag)
    {
        dbgErr("%s>>Error! Check CpuCoreId Over; CoreProcSum= %d\n",
               __FUNCTION__, ulCoreProcsSum);
    }
    else
    {
        dbgInfo("%s>>CoreSum'%d ProcNo'%d Run ProcessorMask: 0x%02X 0x%02X\n", __FUNCTION__,
                ulCoreProcsSum, iTmpPidNum, tGetCpuMask.__bits[0], ulProcCoreMask);
    }

    return BSP_OK;
}

static UINT32 BspSetProcAffinity(UINT8 *pucPathProcName, UINT32 ulCpuCoreMask)
{
    UINT32 ulProcPidNo = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;
    CHAR acProcNoName[64] = {0};
    INT32 lSnpRet = 0;

    ulProcPidNo = BSP_ERROR;
    lSnpRet = snprintf_s(acProcNoName, sizeof(acProcNoName), "%s", pucPathProcName);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(acProcNoName));

    ulTmpRet = GetProcPidByName((UINT8 *)&acProcNoName[0], &ulProcPidNo);
    if (BSP_OK == ulTmpRet)
    {
        ulTmpRet = BSP_OK;
        ulTmpRet |= ProcAffinitySet(ulProcPidNo, ulCpuCoreMask);
        ulTmpRet |= ProcAffinityGet(ulProcPidNo, NULL);

        ulRetVal |= (BSP_OK == ulTmpRet) ? 0 : BIT_SET(3);
    }
    else
    {
        ulRetVal |= BIT_SET(2);
        dbgErr("%s>>[%s] ProcPidByName Get Error!\n", __FUNCTION__, acProcNoName);
    }

    return ulRetVal;
}

/**************************************************************************
                                 对外接口
**************************************************************************/
UINT32 BspCoreProcAffinitySet(CHAR *procName, UINT32 coreMask)
{
    UINT32 ulFunRet = BSP_OK;

    INPUT_POINTER_CHECK(procName);

    if (coreMask > CPU_CORE_ID_MASK_SUM)
    {
        return BSP_ERROR;
    }

    ulFunRet = BspSetProcAffinity(procName, coreMask);

    return ulFunRet;
}

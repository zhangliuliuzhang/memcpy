/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : chippoweronwrapper.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件
 * 注意事项 : 无
 *---------------------------------------------------------------------------*/
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "chippoweronwrapper.h"
#include "devdrv_clk.h"
#include "clk_common.h"
#include "boardversionload.h"
#include "fpgaloadprocess.h"
#include "plugandplay.h"

#define CHIPPOWERON_DATA_FILE_NAME "ChipPoweronData.json"

/*时钟芯片的初始化*/
UINT32 InitClkDev(VOID)
{
    UINT32 retVal = BSP_OK;

    return retVal;
}

UINT32 LoadFpgaVersion(void)
{
    UINT32 retVal = BSP_OK;
    T_VerLoadInfo *fpgaLoadInfo = NULL;
    UINT32 num = 0;
    UINT32 softType = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_FPGA_LOAD, 0, 0, fpgaLoadInfo, num);
    softType = BspSwitchNameToSoftType(fpgaLoadInfo->SoftName);
    if (softType != BSP_ERROR && softType != ERROR_NULL_POINTER)
    {
        BspSetFpgaVerSoftType(softType);
    }
    return BspLoadSwvVersion(fpgaLoadInfo);
}
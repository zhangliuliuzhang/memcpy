/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeaturewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "bspcommon.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "hardfeaturewrapper.h"
#include "flash.h"
#include "board_ic4_2.h"
#include "freqcfgcommon.h"
#include "boardverprotect.h"
#include "regdrv_access.h"
#include "boardcpuid.h"
#include "boardhardid.h"

#define BOARD_CFG_PATH "/BoardCfgFile"
#define HARD_FEATURE_DATA_FILE_NAME "HardFeatureData.json"
/*****************************************************************************
                                  函数声明
*****************************************************************************/
static UINT32 FpgaAccessCheck(UINT32 chip);
static T_Reg_Head s_regHeadGroup[REG_FUNCDOMAIN_MAX] =
    {
        [REG_FUNCDOMAIN_CPU_DDR3] =
            {
                .regFuncDomainType = REG_FUNCDOMAIN_CPU_DDR3,
                .accessType = DEV_REG_ACCESS_LOCAL_BUS,
                .chanInter = 0,
                .chipNum = 1,
                .rawPhyBaseAddr[0] = SYS_MEM_TOP,
                .mapPhyBaseAddr[0] = SYS_MEM_TOP,
                .maxSize = USER_RESERVED_SIZE,
                .virtualBaseAddr[0] = 0,
                .initFlag = 1,
                .subSectFlag = 0,
                .mmapType               = MMAP_TYPE_MEMNC,
            },
        [REG_FUNCDOMAIN_SLAVE_CPU_DDR3] =
            {
                .regFuncDomainType = REG_FUNCDOMAIN_SLAVE_CPU_DDR3,
                .accessType = DEV_REG_ACCESS_LOCAL_BUS,
                .chanInter = 0,
                .chipNum = 1,
                .rawPhyBaseAddr[0] = SLAVE_SYS_MEM_TOP,
                .mapPhyBaseAddr[0] = SLAVE_SYS_MEM_TOP,
                .maxSize = SLAVE_USER_RESERVED_SIZE,
                .virtualBaseAddr[0] = 0,
                .initFlag = 1,
                .subSectFlag = 0,
                .mmapType               = MMAP_TYPE_MEMNC,
            },
        [REG_FUNCDOMAIN_FPGA0] =
            {
                .regFuncDomainType = REG_FUNCDOMAIN_FPGA0,
                .accessType = DEV_REG_ACCESS_SPI_BUS,
                .chanInter = 0,
                .chipNum = 1,
                .rawPhyBaseAddr[0] = 0,
                .mapPhyBaseAddr[0] = 0,
                .maxSize = SIZE_64K,
                .initFlag = 1,
                .subSectFlag = 0,
                .pcbCheck = FpgaAccessCheck,
                .mmapType               = MMAP_TYPE_MEM,
            },
};

static UINT32 FpgaAccessCheck(UINT32 chip)
{
    return BSP_OK;
    // return BspCheckFpgaLoadStatus(chip);
}
// UINT32 g_flashDivision = 0;   /*flash区分 单NOR、NOR+NAND*/
UINT32 BspSplicingBoardCfgFilePath(char *pFilePath, UINT32 len)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 moduleGroupId = 0;
    UINT32 boardGroupId = 0;
    UINT32 boardTypeId = 0;
    UINT32 hardwareChangeId = 0;
    INT32 snprtRet = 0;

    INPUT_POINTER_CHECK(pFilePath);
    moduleGroupId = BspGetModuleGroupIdPara();
    boardGroupId = BspGetBoardGroupIdPara();
    boardTypeId = BspGetBoardTypeIdPara();
    hardwareChangeId = BspGetHardwareChangeIdPara();

    snprtRet = snprintf_s(pFilePath, len, "%s/%x_%x_%x_%x",
                          BOARD_CFG_PATH, moduleGroupId, boardGroupId, boardTypeId, hardwareChangeId);
    SNPRINTF_S_CHECK(snprtRet, len);

    dbgInfoEx("%s>> pFilePath:%s\n", __FUNCTION__, pFilePath);
    return BSP_OK;
}

/*****************************************************************************
                                  全局变量
*****************************************************************************/
UINT32 BspFlashInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_FlashInfo *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_FLASH_INIT, 0, 0, pPara, num);
    retVal = BspFlashModuleInit(pPara);
#if BSP_MAKE_VER
    BspFlashShowCfg();
#endif
    BspSetBbuUniqueIdFlashId(FLASH_ANTI_STEAL_ID_OFFSET);
    return retVal;
}

UINT32 BspInitVerProtect(VOID)
{
    UINT32 retVal = BSP_OK;
    T_VerProtectInfo *verInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_INIT_VER_PROTECT, 0, 0, verInfo, num);
    retVal = BspInitVersionProtect(verInfo);

    return retVal;
}

UINT32 BspInitProtectFileList(VOID)
{
    UINT32 retVal = BSP_OK;
    T_AllRunVerList *verList = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_INIT_PROTECT_FILELIST, 0, 0, verList, num);
    retVal = BspSetProtectFileList(verList);

    return retVal;
}

UINT32 BspRegTblInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    T_Reg_Tbl *p_tRegTbl = NULL;

    /* regtbl 初始化 */
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_REG_TBL, 0, 0, p_tRegTbl, num);
    retVal |= BspSetRegTblData(p_tRegTbl, num);
    retVal |= BspSetRegTblHeadData(s_regHeadGroup, NELEMENTS(s_regHeadGroup));
    retVal |= BspRegAccessInit();
    retVal |= BspInitRegVirAddr();
    retVal |= BspRegTblValInit();

    return retVal;
}

/* 初始化 cpuId 和 coreId */
UINT32 BspInitCpuAndCoreId(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_CpuIdInfo *pCpuIdInfo = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_CPUID_INIT, 0, 0, pCpuIdInfo, paraNum);
    retVal = BspInitCpuIdInfoTbl(pCpuIdInfo, paraNum);

    retVal |= BspInitCpuId();
    retVal |= BspInitCoreId();

    return retVal;
}

UINT32 BspRruPropertyInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_RruPropertyInfo *pPara = NULL;
    UINT32 num = 0;
    if (BspGetBoardLoadCfgType() == 1)
    {
        retVal = BspInitGlobalRruHwInfo();
        retVal |= BspInitBoardProperty();
    }
    else
    {
        BOARD_MODLE_GET_DATA(E_HARD_FEATURE_RRU_PROPERTY, 0, 0, pPara, num);
        retVal = BspSetBoardPropInfo(pPara->ascbuf, pPara->bufSize);
        retVal |= BspInitAdpHwInfoNew();
    }

    return BSP_OK;
}

UINT32 BspGetFlashBomid(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BomidFlashInfo *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_GET_BOMID, 0, 0, pPara, num);
    BspSetFlashBomidOffset(pPara->flashBomidOffset);
    retVal = BspInitAdpBdHwIdInfoPara();
    CHECK_RETVAL(BspInitAdpBdHwIdInfoPara, retVal);

    return retVal;
}

UINT32 BspGetBoardIdFirst(VOID)
{
    UINT32 ulBoardId = 0;
    char boardCfgFilePath[256] = {0};
    char boardPropertyFilePath[256] = {0};
    INT32 snprtRet = 0;
    UINT32 ret = 0;
    ulBoardId = BspGetBoardLgcType();
    /* 第一次获取Boardid后，配置到单板模型中，用于后续的数据匹配 */

    ret = BspSplicingBoardCfgFilePath(boardCfgFilePath, sizeof(boardCfgFilePath));
    CHECK_RETVAL(BspSplicingBoardCfgFilePath, ret);
    snprtRet = snprintf_s(boardPropertyFilePath, sizeof(boardPropertyFilePath), "%s/%s", boardCfgFilePath, "BoardProperty.txt");
    SNPRINTF_S_CHECK(snprtRet, sizeof(boardPropertyFilePath));
    dbgInfoEx("%s:boardPropertyFilePath: %s \n", __FUNCTION__, boardPropertyFilePath);
    if (BspIsFileExist(boardPropertyFilePath) == BSP_OK)
    {
        BspSetBoardLoadCfgType(1);
        BspSetBoardCfgPath(boardCfgFilePath, sizeof(boardCfgFilePath));
        // ulBoardId = 26;
        ret = GetVirtualId(&ulBoardId);
        CHECK_RETVAL(GetVirtualId, ret);
        BspSetBoardVirtualId(ulBoardId);
        dbgInfoEx("%s>>boardCfgFilePath: %s\n", __FUNCTION__, boardCfgFilePath);
    }
    else
    {
        BspSetBoardLoadCfgType(0);
    }

    BspBoardModleSetBoardId(ulBoardId);
    return BSP_OK;
}

UINT32 BspGetReservedMemSize(UINT8 moduleId)
{
    UINT32 size = 0;

    switch (moduleId)
    {
        case BSP_HIGH_RESERVED_MEM_BSP:
            size = BSP_MEM_SIZE;
            break;

        case BSP_HIGH_RESERVED_MEM_MGR:
            size = OSS_MEM_SIZE;
            break;

        case BSP_HIGH_RESERVED_MEM_USER_DEFINE:
            size = BSP_VER_PROTECT_SIZE;
            break;

        case BSP_HIGH_RESERVED_MEM_APP1: /* 产品高层，使用保留区 */
            size = APP_RESERVED_SIZE;
            break;

        default:
            dbgInfo("%s: Error input %d\n", __FUNCTION__, moduleId);
            size = 0;
    }

    return size;
}

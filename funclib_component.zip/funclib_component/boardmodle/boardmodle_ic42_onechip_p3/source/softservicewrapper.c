/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : softservicewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "softservicewrapper.h"
#include "udpmsg_ic.h"
#include "trustsvc.h"
#include "fpgaload.h"
#include "fpgaloadprocess.h"
#include "certkeyprocess.h"
#include "sign_verify.h"
#include "dbootctrl_new.h"
#include "boardDboot.h"
#include "dualbootapi.h"
#include "coreprocaffinity.h"
#include "board.h"
#include "board_ic4_2.h"
#include "i2cbuszx211413.h"
#include "regaccess.h"
#include "zprintf.h"

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
static TDbootPara s_tDbootInitPara =
    {
        {
            {
                M0BOOT_MASTER_ADDR,
                M0BOOT_SLAVE_ADDR,
            },
            {
                BOOT_BL2_MASTER_ADDR,
                BOOT_BL2_SLAVE_ADDR,
            },
            {
                KEBOOT_MASTER_ADDR,
                KEBOOT_SLAVE_ADDR,
            },
        },
        {
            M0BOOT_SIZE,
            BOOT_BL2_SIZE + BOOT_FIP_SIZE,
            KEBOOT_MAX_SIZE,
        },
        3,
        BspGetMsBootSel,
        BspSetMsBootSel,
        BspGetCpuType,
};
UINT32 g_flashDivision = 0; /*flash区分 单NOR、NOR+NAND*/
UINT32 BspCfgSecVerifyPara(VOID)
{
    UINT32 ulFlashAddr[9] = {(SIZE_128M - SIZE_1M), SIZE_4K, (SIZE_128M - SIZE_1M + SIZE_8K), SIZE_4K * 7, SIZE_4K * 7, SIZE_32K, (SIZE_128M - SIZE_1M + SIZE_128K), SIZE_4K * 5, SIZE_4K * 5};
    UINT32 FlashAddr[9] = {SIZE_45M, SIZE_4K, (SIZE_45M + SIZE_8K), SIZE_4K * 7, SIZE_4K * 7, SIZE_32K, (SIZE_45M + SIZE_128K), SIZE_4K * 5, SIZE_4K * 5};
    UINT32 ulRet = BSP_OK;

    /*设置秘钥区flash偏移*/
    if (g_flashDivision == 0) // NOR+NAND
    {
        ulRet |= BspCfgFlashAddrLen(ulFlashAddr);
    }
    else // 单NOR
    {
        ulRet |= BspCfgFlashAddrLen(FlashAddr);
    }

    /*设置回调函数*/
    ulRet |= BspSetSecVerifyFunc(BspGetVersionSign, BspDecodeB64, BspModuleVersion_Verify);

    return ulRet;
}

UINT32 UdpMsgModuleInit(VOID)
{
    UINT32 ulLoop = 0;
    T_UdpPathDesc udppathdesc = {0};
    T_UdpPathSocketInfo tmpUdpSocketInfo = {0};
    T_UdpPathSocketCfgInfo *pPara = NULL;
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;

    BOARD_MODLE_GET_DATA(E_SOFT_SERVICE_UDPMSGMODULE_INIT, 0, 0, pPara, num);
    dbgInfo("pPara->usedTypeNum %d %p\n", pPara->usedTypeNum, pPara);
    if (pPara->usedTypeNum == 0)
    {
        return BSP_ERROR;
    }

    for (ulLoop = 0; ulLoop < pPara->usedTypeNum; ulLoop++)
    {
        tmpUdpSocketInfo = pPara->udpSocketInfo[ulLoop];
        udppathdesc.typeId = tmpUdpSocketInfo.typeId;
        // tx info
        udppathdesc.tx_info.port = tmpUdpSocketInfo.tx_info.port;
        udppathdesc.tx_info.pathid = tmpUdpSocketInfo.tx_info.pathid;
        udppathdesc.tx_info.binden = tmpUdpSocketInfo.tx_info.binden;
        memcpy_s(udppathdesc.tx_info.ip, sizeof(tmpUdpSocketInfo.tx_info.ip),
                 tmpUdpSocketInfo.tx_info.ip, sizeof(tmpUdpSocketInfo.tx_info.ip));
        // rx info
        udppathdesc.rx_info.port = tmpUdpSocketInfo.rx_info.port;
        udppathdesc.rx_info.pathid = tmpUdpSocketInfo.rx_info.pathid;
        memcpy_s(udppathdesc.rx_info.ip, sizeof(tmpUdpSocketInfo.rx_info.ip),
                 tmpUdpSocketInfo.rx_info.ip, sizeof(tmpUdpSocketInfo.rx_info.ip));
        // init
        UdpPathInit(udppathdesc);
    }
    BspInitUdpPathSocketCfgInfo(pPara);

    dbgInfo("%s %d Succ!\n", __FUNCTION__, __LINE__);
    return BSP_OK;
}

UINT32 BspCfgSecVerifyCallBack(VOID)
{
    BspFpgaLoadPrnCallBack((pFpgaLoadPrintFunc)FpgaLoadPrint);                 /*fpgaloadlog回调函数挂接*/
    BspChkFlashVerCallBack((pChkFlashVerFunc)BspChkFlashVer);                  /*BspChkFlashVer回调函数挂接*/
    BspCheckSystemVerSignCallBack((pCheckSystemVerSign)BspCheckSystemVerSign); /*BspCheckSystemVerSign回调函数挂接*/

    return BSP_OK;
}

UINT32 BspInitDbootPara(VOID)
{
    BspGetBootFlagCallback((FUNC_GET_BOOT_FLAG)BspGetMsBootSel);
    BspSetBootFlagCallback((FUNC_SET_BOOT_FLAG)BspSetMsBootSel);
    BspSetBootVerSrc(BOOT_VER_FROM_FLASH);

    return BspDbootParaInit(&s_tDbootInitPara);
}

UINT32 BspCoreProcAffinityInit(void)
{
    T_CoreProcAffinityInfo *pPara = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;

    BOARD_MODLE_GET_DATA(E_SOFT_SERVICE_CORE_AFFINITY_CFG, 0, 0, pPara, num);

    for (loop = 0; loop < num; loop++)
    {
        retVal |= BspCoreProcAffinitySet(pPara->procName, pPara->coreMask);
        pPara++;
    }

    return retVal;
}

UINT32 BspGetCpuType(UINT8 *cpuType)
{
    *cpuType = BSP_ZX211413;

    return BSP_OK;
}

UINT32 BspCfgSecVerifyFun(VOID) /* 是否启用验签功能 */
{
    UINT32 ulBySwitch = 0;
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulFunRet = BSP_ERROR;

    /* 检查调试标记 */
    if (BSP_OK == BspGetSafeBootDbgFlag())
    {
        dbgInfo("%s>>BspMGR File[/ata/SafeBoot_dbg] Exist!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    // 获取安全Boot开关状态: 0-安全关闭, 1-安全打开
    ulTmpRet = BspGetSafeBootCheckSwitch(&ulBySwitch);
    if (BSP_OK == ulTmpRet)
    {
        if (1 == ulBySwitch) /* 启用验签 */
        {
            ulFunRet = BspCfgSecVerifyPara();
            dbgInfo("%s>>BspMGR SafeBoot Open; SecVerifyPara Cfg %s!\n", __FUNCTION__,
                    (ulFunRet == BSP_OK) ? ("Succ") : ("Error"));
        }
        else
        {
            dbgInfo("%s>>BspMGR SafeBootCheckSwitch'%d Get Succ! SafeBoot Close;\n",
                    __FUNCTION__, ulBySwitch);
        }
    }
    else
    {
        dbgErr("%s>>BspMGR SafeBootCheckSwitch'%d Get Error! SafeBoot Close;\n",
               __FUNCTION__, ulBySwitch);
    }

    return ulFunRet;
}


UINT32 BspInitEfuseWriteFunc(void)
{
    return BspEfuseWriteCallBack(crmEfuseRegWrite);
}

UINT32 BspInitEfuseReadFunc(void)
{
    return BspEfuseReadCallBack(crmEfuseRegRead);
}

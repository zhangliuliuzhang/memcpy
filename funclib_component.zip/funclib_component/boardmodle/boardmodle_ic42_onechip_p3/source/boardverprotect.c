/*****************************************************************************
 * 版权所有(C) 2022, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : boardverprotect.c
 * 文件标识 : 无
 * 内容摘要 : 版本保护区相关实现
 * 注意事项 : 无
 *---------------------------------------------------------------------------*/

#include "boardverprotect.h"
#include "fpgaloadprocess.h"
#include "boardmodle_ic4_2.h"
#include "zprintf.h"

#define ELSE_IF(x) else if (x)

/**************************************************************************
 *                         外部接口定义
 **************************************************************************/

/**************************************************************************
 * 函数名称: BspInitVersionProtect(*)
 * 功能描述: 保护区版本Flash地址信息初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspInitVersionProtect(T_VerProtectInfo *verInfo)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(verInfo);

    BspSetVerProtectAddr(verInfo->startAddr);
    BspSetVerProtectLen(verInfo->size);
    BspSetVerProtectType(verInfo->verType); /* 保护区中刷入完整版本 */

    return retVal;
}

UINT32 BspSetProtectFileList(T_AllRunVerList *verList)
{
    UINT32 ulCnt = 0;
    UINT32 ulVerNum = 0;
    UINT32 ulMasterVerNum = 0;
    UINT32 ulSlaveVerNum = 0;
    UINT32 ulBrdLgcId = 0;
    UINT32 protectVerList[32] = {0};

    INPUT_POINTER_CHECK(verList);

    ulMasterVerNum = verList->ulMasterVerNum;
    ulSlaveVerNum = verList->ulSlaveVerNum;
    ulVerNum = ulMasterVerNum + ulSlaveVerNum;
    if ((ulVerNum < ulMasterVerNum) || (ulVerNum < ulSlaveVerNum))
    {
        dbgErr("%s>>The ulVerNum Overflow!!! \n", __FUNCTION__);
        return BSP_ERROR;
    }
    for (ulCnt = 0; ulCnt < min(MASTER_VER_NUM_MAX, ulMasterVerNum); ulCnt++)
    {
        protectVerList[ulCnt] = verList->tMasterRunVerList[ulCnt].ulSoftType;
    }
    for (ulCnt = 0; ulCnt < min(SLAVE_VER_NUM_MAX, ulSlaveVerNum); ulCnt++)
    {
        protectVerList[ulCnt + ulMasterVerNum] = verList->tSlaveRunVerList[ulCnt].ulSoftType;
    }

    for (ulCnt = 0; ulCnt < min(32, ulVerNum); ulCnt++)
    {
        dbgInfo("%s>>protectVerList[%d] equal %d!\n", __FUNCTION__, ulCnt, protectVerList[ulCnt]);
    }
    BspSetWriteXmlToProtectFlag(verList->writeXmlFile);
    // coverity[cert_exp37_c_violation:SUPPRESS]
    // coverity[cert_dcl60_cpp_violation:SUPPRESS]
    // coverity[cert_int31_c_violation:SUPPRESS]
    return BspSetProtectVerIndex((UINT32 *)protectVerList, ulVerNum, verList);
}

/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardcpuid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了例化单板的cpuid、rpuid管理的接口实现
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/
#include "bspcomm.h"
#include "funccommon.h"
#include "boardmodlecommon.h"
#include "funccommonapi.h"

#include "ichaladapt_ic4_2.h"
#include "boardcpuid.h"
#include "udpmsg_ic.h"
#include "zprintf.h"
/**************************************************************************
 *                                 宏
 **************************************************************************/


/**************************************************************************
 *                               枚举定义
 **************************************************************************/
 
/**************************************************************************
 *                               数据类型
 **************************************************************************/



/**************************************************************************
 *                                全局变量
 **************************************************************************/
 T_CpuIdInfo *s_pCpuIdInfo = NULL;
 UINT32 s_pCpuIdInfoNum = 0;

/**************************************************************************
*                                 接口实现
**************************************************************************/

UINT32 BspGetIcChipId(UINT32 *pChipIdx, UINT32 *pDieIdx)
{
    UINT32 retVal = BSP_OK;
    UINT32 regData = 0;
    UINT32 regAddr = 0;

    INPUT_POINTER_CHECK(pChipIdx);
    INPUT_POINTER_CHECK(pDieIdx);

    *pDieIdx = 0;
    retVal = IcHalBitRdReg(0,CRM_M0_RECORD_TEMP_REG,0,pChipIdx,8,10);
    return BSP_OK;
}

UINT32 BspGetRpuId(VOID)
{
    UINT32 ChipIdx = 0;
    UINT32 DieIdx = 0;

#ifndef PLAT_X86_TEST
    BspGetIcChipId(&ChipIdx, &DieIdx);
#else
    ChipIdx = BspAdsTestGetChipId();
#endif
    return ChipIdx;
}

UINT32 BspInitCpuIdInfoTbl(T_CpuIdInfo *pCpuIdInfo ,UINT32 num)
{
    INPUT_POINTER_CHECK(pCpuIdInfo);
    s_pCpuIdInfo = pCpuIdInfo;
    s_pCpuIdInfoNum = num;

    return BSP_OK;
}

T_CpuIdInfo * GetCpuIdInfoByPuId(UINT32 isPeerPu,UINT32 puId)
{
    UINT32 loop    = 0;
   
    if (NULL == s_pCpuIdInfo)
    {
        dbgInfo("[%s] s_pCpuIdInfo if not init! \n", __FUNCTION__);
        return NULL;
    }
    
    for (loop = 0; loop < s_pCpuIdInfoNum; loop++)
    {
        if (isPeerPu == s_pCpuIdInfo[loop].isPeerPu && puId == s_pCpuIdInfo[loop].puId)
        {
            return &s_pCpuIdInfo[loop];
        }
    }

    return NULL;
}

/* 根据获取的puId初始化主片的cpuId */
UINT32 BspInitCpuId(VOID)
{
    UINT32 puId = 0;

    puId = BspGetRpuId();
    //BspSetBoardIcChipIndex((UINT8)puId);
    T_CpuIdInfo *cpuInfo = GetCpuIdInfoByPuId(0,puId);
    INPUT_POINTER_CHECK(cpuInfo);
    
    return BspSetCpuId(cpuInfo->cpuId);
}

/* 根据获取的puId初始化主片的coreId */
UINT32 BspInitCoreId(VOID)
{
    UINT32 puId = 0;

    puId = BspGetRpuId();
    T_CpuIdInfo *cpuInfo = GetCpuIdInfoByPuId(0, puId);
    INPUT_POINTER_CHECK(cpuInfo);

    return BspSetCoreId(cpuInfo->coreId);
}

/* 高层调用 */
UINT32 BspGetPeerPuCpuId(UINT32 puId)
{
    T_CpuIdInfo *cpuInfo = GetCpuIdInfoByPuId(1,puId);

    if(NULL == cpuInfo)
    {
        return BSP_OK;
    }

    return cpuInfo->cpuId;
}

/* 高层调用 */
UINT32 BspGetPeerPuCoreId(UINT32 puId)
{
    T_CpuIdInfo *cpuInfo = GetCpuIdInfoByPuId(1,puId);

    if(NULL == cpuInfo)
    {
        return BSP_OK;
    }

    return cpuInfo->coreId;
}

T_CpuIdInfo * GetCpuIdInfoByCpuId(UINT32 cpuId)
{
    UINT32 loop = 0;

    if (NULL == s_pCpuIdInfo)
    {
        dbgInfo("[%s] s_pCpuIdInfo if not init! \n", __FUNCTION__);
        return NULL;
    }

    for (loop = 0; loop < s_pCpuIdInfoNum; loop++)
    {
        if (cpuId == s_pCpuIdInfo[loop].cpuId)
        {
            return &s_pCpuIdInfo[loop];
        }
    }

    return NULL;
}
/* 根据cpuId查找对应的puId；高层调用 */
UINT32 BspGetCpuIdToPuId(UINT32 cpuId)
{
    T_CpuIdInfo *cpuInfo = GetCpuIdInfoByCpuId(cpuId);
    INPUT_POINTER_CHECK(cpuInfo);

    return cpuInfo->puId;
}

#ifndef _HARDFEATURE_WRAPPER_H_
#define _HARDFEATURE_WRAPPER_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
/**************************************************************************
 *                        宏
 **************************************************************************/

/**************************************************************************
 *                                枚举定义
 **************************************************************************/
typedef enum _REG_FUNCDOMAIN_TYPE
{
    REG_FUNCDOMAIN_CPU_DDR3 = 0 ,   /* high mem           0 */
	REG_FUNCDOMAIN_FPGA0,           /* fpga               1 */
	REG_FUNCDOMAIN_SLAVE_CPU_DDR3 , /* 从MGR high mem     2 */
    REG_FUNCDOMAIN_MAX
} E_REG_FUNCDOMAIN_TYPE;

typedef struct tagT_BomidFlashInfo
{
    UINT32   flashBomidOffset;  /* Flash上保存Bomid的偏移地址 */
    UINT32   flashBomidSize;    /* Flash上Bomid信息的长度 */
}T_BomidFlashInfo;

typedef struct tagT_RruPropertyInfo
{
    const unsigned char * ascbuf;     /* 开始地址 */
    UINT32   bufSize;           /* size */
}T_RruPropertyInfo;
/**************************************************************************
 *                         数据类型
 **************************************************************************/


/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspInitCpuAndCoreId(VOID);
UINT32 BspInitProtectFileList(VOID);
UINT32 BspRegTblInit(VOID);
UINT32 BspInitCpuAndCoreId(VOID);
UINT32 BspRruPropertyInit(VOID);
UINT32 BspGetFlashBomid(VOID);
UINT32 BspInitVerProtect(VOID);
UINT32 BspFlashInit(VOID);
UINT32 BspGetBoardIdFirst(VOID);
#ifdef __cplusplus
}
#endif

#endif /* _HARDFEATURE_WRAPPER_H_ */




#ifndef _BOARD_CPU_ID_H_
#define _BOARD_CPU_ID_H_

#ifdef __cplusplus 
extern "C" { 
#endif


/**************************************************************************
 *                         数据类型
 **************************************************************************/

typedef struct tagT_CpuIdInfo
{
    UINT32 isPeerPu;  /* 标识主从，主片用0表示，从片用1表示 */
    UINT32 puId;      /* 对主片和从片分别从0开始编号 */
    UINT32 cpuId;     /* 从1开始编号，若为MCS芯片，该编号需与MCS同事核对；cpuId=puId+2 */
    UINT32 coreId;    /* coreId */
}T_CpuIdInfo;


/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspGetRpuId(VOID);
UINT32 BspInitCoreId(VOID);
UINT32 BspInitCpuId(VOID);
UINT32 BspInitCpuIdInfoTbl(T_CpuIdInfo *pCpuIdInfo, UINT32 num);
UINT32 BspGetPeerPuCpuId(UINT32 puId);
UINT32 BspGetPeerPuCoreId(UINT32 puId);
UINT32 BspGetCpuIdToPuId(UINT32 cpuId);
UINT32 BspGetIcChipId(UINT32 *pChipIdx, UINT32 *pDieIdx);


#ifdef __cplusplus
}
#endif

#endif /* _BOARD_CPU_ID_ */




#ifndef _BOARD_HARD_ID_H_
#define _BOARD_HARD_ID_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"

/*
    ******************************************************************
    目前平台包含了两种方式读取Bomid，Flash方式读取/SocMsg方式读取
    可以通过在单板CMakelist中通过USE_SOCMSG_BOMID宏进行切换
    ------------------------------------------------------------------
    增加 USE_SOCMSG_BOMID宏: SocMsg方式读取，适用于无Flash的从片版本
    删除 USE_SOCMSG_BOMID宏: Flash方式读取，适用带Flash的版本
    ******************************************************************
*/

/**************************************************************************
 *                        宏
 **************************************************************************/


/**************************************************************************
 *                                枚举定义
 **************************************************************************/
 


/**************************************************************************
 *                         数据类型
 **************************************************************************/



/**************************************************************************
*                         函数声明
**************************************************************************/

/* Flash方式/Soc Msg方式 共用的接口 */
UINT32 BspGetModuleGroupIdPara(VOID);
UINT32 BspGetBoardGroupIdPara(VOID);
UINT32 BspGetBoardTypeIdPara(VOID);
UINT32 BspGetHardwareChangeIdPara(VOID);
UINT32 BspGetHardwareCustomIdPara_A(VOID);
UINT32 BspGetHardwareCustomIdPara_B(VOID);
UINT32 BspGetHardwareMagicNumPara(VOID);
UINT32 BspGetBoardBomidCrcDataPara(VOID);

UINT32 BspInitAdpBdHwIdInfoPara(VOID);

/* Flash方式读取Bomid使用的接口 */
VOID BspSetFlashBomidOffset(UINT32 offset);
UINT32 SetHwInfo16(UINT32 ulModuleGroupId, UINT32 ulBoardGroupId, UINT32 ulBoardTypeId,
                           UINT32 ulHwChangeId, UINT32 ulCustomHwIdA, UINT32 ulCustomHwIdB);

/* Soc Msg方式读取Bomid使用的接口 */
VOID BspGetBomIdBySocMsg(VOID);



#ifdef __cplusplus
}
#endif

#endif /* _BOARD_HARD_ID_ */



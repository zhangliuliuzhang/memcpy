
#ifndef _SOFTSERVICE_WRAPPER_H_
#define _SOFTSERVICE_WRAPPER_H_

#ifdef __cplusplus 
extern "C" { 
#endif


/**************************************************************************
 *                        宏
 **************************************************************************/

/**************************************************************************
 *                                枚举定义
 **************************************************************************/
 


/**************************************************************************
 *                         数据类型
 **************************************************************************/

typedef struct
{
    CHAR *procName;
    UINT32 coreMask;
} T_CoreProcAffinityInfo;
/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 UdpMsgModuleInit(VOID);
UINT32 BspGetCpuType(UINT8 *cpuType);
UINT32 BspCfgSecVerifyCallBack(VOID);
UINT32 BspInitDbootPara(VOID);
UINT32 BspCoreProcAffinityInit(void);
UINT32 BspCfgSecVerifyFun(VOID);
UINT32 BspInitEfuseWriteFunc(void);
UINT32 BspInitEfuseReadFunc(void);
#ifdef __cplusplus
}
#endif

#endif /* _SOFTSERVICE_WRAPPER_H_ */



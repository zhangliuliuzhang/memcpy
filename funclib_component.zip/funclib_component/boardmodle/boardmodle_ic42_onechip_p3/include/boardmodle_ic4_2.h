
#ifndef _BOARDMODLE_IC4_2_H_
#define _BOARDMODLE_IC4_2_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
//#include "functionwrapper.h"
/**************************************************************************
 *                                   宏
 **************************************************************************/

//todo 单板下board.h中的公共枚举及宏定义后续迁移到此处(和系列单板共性的定义，例如flash分配)


#define BOARD_ACTION_DEF(acttype,func,initflag)  \
    { acttype,            func,              #func,        initflag},


/**************************************************************************
 *                                枚举定义
 **************************************************************************/
/* 单板系统软件服务初始化组件包含动作种类定义 */
enum E_BOARD_SOFT_SERVICE_ACT_TYPE
{
    E_SOFT_SERVICE_SIGNAL = BOARD_SOFT_SERVICE_ACT_BASE,   /* 信号初始化*/
    E_SOFT_SERVICE_EXT_PRN,                                /* EXT打印模块初始化 */
    E_SOFT_SERVICE_BSP_LOG,                                /* BSPLOG记录模块初始化 */
    E_SOFT_SERVICE_PM_INIT,                                /* 打印模块初始化 */
    E_SOFT_SERVICE_DBOOT_INIT,                             /* 双BOOT参数初始化 */
    E_SOFT_SERVICE_UDPMSGMODULE_INIT,                      /* 核间UDP通信参数及任务初始化*/
    E_SOFT_SERVICE_CORE_AFFINITY_CFG,                      /* CPU亲和力初始化 */
    E_SOFT_SERVICE_RECORD_HASH_VER,                        /* 设置HASH版本信息到全局变量,供版本比对使用 */
    E_SOFT_SERVICE_INIT_EFUSE_WRITE,                       /* 初始化整机EFUSE写功能 */
    E_SOFT_SERVICE_INIT_EFUSE_READ,                        /* 初始化整机EFUSE读功能 */
    E_SOFT_SERVICE_INIT_GPIO_READ,                         /* 初始化整机GPIO读功能 */
    E_SOFT_SERVICE_INIT_SEC_CALLBACK,                      /* 版本启动安全验签回调 */
    E_SOFT_SERVICE_INIT_SEC_VERIFY,                        /* 版本启动安全验签功能 */

    E_SOFT_SERVICE_ACT_MAX
};

/* 单板硬件特性、硬件互联关系初始化功能组件包含动作种类定义 */
enum E_BOARD_HARD_FEATURE_ACT_TYPE
{
    E_HARD_FEATURE_BOARD_ID = BOARD_HARD_FEATURE_ACT_BASE,/* 单板Boardid表始化 */
    E_HARD_FEATURE_DEV_ID,                                /* 设备ID表始化 */
    E_HARD_FEATURE_FUNC_ID,                               /* 功能ID表始化 */
    E_HARD_FEATURE_THRESHOLD_ID,                          /* 阈值ID表始化 */
    E_HARD_FEATURE_GAIN_ID,                               /* 增益ID表始化 */
    E_HARD_FEATURE_GET_BOMID,                             /* 从Flash读取Bomid信息      */
    E_HARD_FEATURE_GET_LGC_TYPE,                          /* 第一次调用BspGetBoardLgcType,获取后保存在全局变量中 */
    E_HARD_FEATURE_RRU_PROPERTY,                          /* 特性表加载 */
    E_HARD_FEATURE_RRUFILE_INIT,                          /* RRUINFO表加载 */
    E_HARD_FEATURE_REG_TBL,                               /* 寄存器表初始化 */
    E_HARD_FEATURE_DPDIC_REG_TBL,                         /* DPDIC寄存器表初始化 */
    E_HARD_FEATURE_FLASH_INIT,                            /* FLASH参数初始化 */
    E_HARD_FEATURE_INIT_VER_PROTECT,                      /* 初始化保护区版本Flash地址信息 */
    E_HARD_FEATURE_CPUID_INIT,                            /* cpuId 初始化 */
    E_HARD_FEATURE_INIT_PROTECT_FILELIST,                 /* 初始化保护区版本清单 */
    E_HARD_FEATURE_INIT_SOC_VER,                          /* 初始化SOC版本信息 */

    E_HARD_FEATURE_ACT_MAX
};

/* 周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件包含动作种类定义 */
enum E_BOARD_CHIP_POWERON_ACT_TYPE
{
    E_CHIP_POWERON_CLK_DEV = BOARD_CHIP_POWERON_ACT_BASE,  /* 时钟芯片初始化 */
    E_CHIP_POWERON_FPGA_LOAD,                              /* FPGA加载 */
    E_CHIP_POWERON_BOARDRESET_CALLBACK,                    /* 单板复位接口的挂接 */
    E_CHIP_POWERON_ACT_MAX
};

/* TX/RX/FB三大链路初始化功能组件包含动作种类定义 */
enum E_BOARD_TRX_LINK_ACT_TYPE
{
    E_TRX_LINK_DPDIC_OPT_TX_SERDES= BOARD_DIG_TRX_LINK_ACT_BASE, /*TX 光口Serdes始化+pcs初始化 */
    E_TRX_LINK_ACT_MAX
};

/* 单板业务功能初始化组件包含动作定义 */
enum E_BOARD_FUNCTION_ACT_TYPE
{
    E_FUNCTION_PRE_ALLOC = BOARD_FUNCTION_ACT_BASE,        /* 场景预置初始化 */
    E_FUNCTION_LINKPWROFF_ENABLE,                          /* 光纤断链自救功能使能 */
    E_FUNCTION_LINKPWROFF_INIT,                            /* 光纤断链自救功能初始化 */
    E_FUNCTION_ACT_MAX
};


/**************************************************************************
 *                         数据类型
 **************************************************************************/



/**************************************************************************
*                         函数声明
**************************************************************************/

/* 单板属性 */
typedef struct tagT_BoardAttribute
{
    
}T_BoardAttribute;


#ifdef __cplusplus
}
#endif

#endif /* _BOARDMODLE_IC4_2_H_ */



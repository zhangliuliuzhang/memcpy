/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardvga.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 :   10307448
* 创建日期 : 2022-06-11 10:26:05
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10307448
* 修改日戳: 2022-06-11 10:26:05
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "ichaladapt_ic4_2.h"
#include "rruinfo.h"
#include "gainctrlapi.h"
#include "gainctrl_ic4_2.h"
#include "boardvga.h"
#include "powerctrl_comps_ic4_2.h"
#include "freqcfgcommon.h"
#include "rxscan_ic4_2.h"
#include "chnmap_a.h"
#include "bsppub.h"
#include "devdrv_transceiver.h"

/**************************************************************************
*                               全局变量定义                                *
**************************************************************************/
T_BspHalAdaptVgaCtrlComPara *s_pVgaCtrlPara = NULL;

static vga_MTS_SwitchAgc  s_pMTS_SwitchAgc = NULL;
static vga_ADI_SwitchAgc  s_pADI_SwitchAgc = NULL;
static vga_TI_SwitchAgc   s_pTI_SwitchAgc = NULL;
static UINT32 g_sEmptyVgaSliceLut[SLICER_MAP_LEN] = {0}; /* 空表 */
static UINT32 g_sTrxAgcCtrlFlag = 0; /* 查看Agc控制标志。0-Stop, 1-Start */
static UINT32 g_MtsDevNum = 0;  /* MTS芯片数量 */
static INT32 anaPreAtt[32] = {0};
static INT32 digPreAtt[32] = {0};
static UINT32 g_sAgcCfgAnaPreAttSw = 1; /* AGC 模式下,是否需要配置模拟预衰。0：关闭配置，1：打开配置 */
UINT32  g_agcAnaPreAttFlag = 1; /* 是否关闭AGC配置模拟预衰的标志。0：关闭配置，1：打开配置 */
static vga_ADI_SwitchAgc  s_pADI_StopAgc = NULL;

/**************************************************************************
*                         函数声明
**************************************************************************/
static vga_MTS_SwitchAgc Vga_MTSSwitchAgc(VOID);


/**************************************************************************
 *                         函数实现
 **************************************************************************/



static VOID BspSetAgcCfgAnaPreAttSw(UINT32 sw)
{
    g_sAgcCfgAnaPreAttSw = sw;
}

UINT32 BspGetRxAnaAtt(UINT32 chanNo, INT32 digAtt, INT32* rxAttGain)
{
    UINT32 freq  = 0;
    INT32 rxGain = 0;

    INPUT_POINTER_CHECK(rxAttGain);
    if (BspGetRfChCenterFreq(chanNo, (UINT32)RX, &freq) != BSP_OK)
    {
        dbgErr(">>BspGetRxAnaAtt get chan [%u] centor freq pointer error\r\n", chanNo);
        return BSP_ERROR;
    }
    if (BspGetRxPreAtt(chanNo, freq, &rxGain) != BSP_OK)
    {
        dbgErr(">>BspGetRxAnaAtt get rx gain error, chan[%u], freq [%u]\r\n", chanNo, freq);
        return BSP_ERROR;
    }
    *rxAttGain = rxGain > digAtt ?  0 : ((rxGain - digAtt - 50) / 100) * 100;

    return BSP_OK;
}

UINT32 BspSetRxDigitPreAtt(UINT32 chanNo, UINT32 carr, UINT32 radioMode, INT32 preAtt, UINT32 isTempComp)
{
    UINT32 retVal = BSP_OK;

    /*配置VGA补偿*/
    retVal = BspSetRxVgaAtt(chanNo,carr,radioMode,preAtt);
    dbgInfoEx("%s>>chanNo %d,carrNo %d,totalAdjGain %d\n",__FUNCTION__,chanNo,carr,preAtt);

    return retVal;
}

UINT32 BspSetRxPreAtt_AGC(UINT32 chanNo, UINT32 isTempComp)
{
    UINT32 retVal = BSP_OK;
    UINT32 carrFreq = 0;
    UINT32 carrMode = 0;
    INT32 rxDigPreAtt = 0;
    INT32 rxAnaPreAtt = 0;
    UINT32 loop = 0;
    UINT32 carrNo = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 bspChan = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    if(MODE_ONLY_FDD == BspGetFddTddCoExistSta())    /*fdd机型AGC时上行增益补偿在BspTempParaUpdate-BspUpdateUlGainFactor*/
    {
        dbgInfoEx("fdd agc not need cfg\n");
        return BSP_OK;
    }
    retVal = BspGetBspChnByRfChn(chanNo, RX, &bspChan);
    if (retVal != BSP_OK)
    {
        dbgErr(">>BspGetBspChnByRfChn Rf Chan Map Bsp Chan error\r\n");
        return BSP_ERROR;
    }
    retVal = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if (retVal != BSP_OK)
    {
        dbgErr(">>BspGetDifInfoByBspChn Bsp Chan Map Dif Chan error\r\n");
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChan,RX);
    
    if (NULL == pRfCfg)
    {
        dbgErr("[%s]difChan'%d pRfCfg Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }

    for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
    {
        carrNo = pRfCfg->para.carrInfo[loop].carrNo;
        carrMode = pRfCfg->para.carrInfo[loop].radioMode;
        carrFreq = pRfCfg->para.carrInfo[loop].freq;

        retVal |= BspGetRxPreAttByFreq(chanNo, carrFreq, &rxDigPreAtt,carrMode);
        dbgInfoEx(">>BspSetRxPreAtt_AGC chan [%u], carrNo [%u], radioMode [%#x], carrFreq [%u], rxPreAtt [%d]\r\n", chanNo,
                carrNo, carrMode, carrFreq, rxDigPreAtt);
        /* 设置vga校准因子*/

        retVal |= BspSetRxDigitPreAtt(chanNo, carrNo, carrMode, rxDigPreAtt, isTempComp);
    }

    /* agc 模式下需要再配置模拟预衰,温补模式下，无需再配置模拟预衰 */
    if (g_sAgcCfgAnaPreAttSw && (isTempComp == 0))
    {
        rxDigPreAtt = _BspGetUlAttDigPara(chanNo, 0);
        retVal |= BspGetRxAnaAtt(chanNo, rxDigPreAtt, &rxAnaPreAtt);
        retVal |= BspSetRxAgcGain(chanNo, rxAnaPreAtt);
        digPreAtt[chanNo] = rxDigPreAtt;
        anaPreAtt[chanNo] = rxAnaPreAtt;
    }
    return retVal;
}

UINT32 BspSetAllChnAgcPreAtt(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chIndex = 0;
    UINT32 rfChNum = 0;
    
    rfChNum = BspGetRxChannel();
    for (chIndex = 0; chIndex < rfChNum; chIndex++)
    {
        retVal |= BspSetRxPreAtt_AGC(chIndex, 0);
    }

    return retVal;
}

UINT32 BspGetAgcAnaPreAttFlag(UINT32 *agcAnaPreAttFlag)
{
    INPUT_POINTER_CHECK(agcAnaPreAttFlag);
    *agcAnaPreAttFlag = g_agcAnaPreAttFlag;

    return BSP_OK;
}

UINT32 BspSetAgcAnaPreAttFlag(UINT32 agcAnaPreAttFlag)
{
    g_agcAnaPreAttFlag = agcAnaPreAttFlag;

    return BSP_OK;
}

UINT32 BspSetRxAllTdmDigPreAtt(INT32 digAtt)
{
    UINT32 retVal = BSP_OK;

    /* digAtt 为0.01db单位,需要转换为0.1db单位 */
    retVal = BspHalAdaptSetAllRxVgaGain(digAtt / 10);

    return retVal;
}

UINT32 BspSetRxPreAtt_MGC(UINT32 chanNo)
{
    UINT32 retVal = BSP_OK;
    INT32 digAtt  = 0;
    INT32 anaAtt  = 0;

    digAtt = _BspGetUlAttDigPara(chanNo, 0);
    retVal |= BspGetRxAnaAtt(chanNo, digAtt, &anaAtt);
    dbgInfoEx("BspSetRxPreAtt_MGC> digPreAtt [%d], AnalogPreAtt [%d]\r\n", digAtt, anaAtt);

    /* 数字衰减预埋-3db, 预埋到校准因子处 */
    retVal |= BspSetRxAllTdmDigPreAtt(digAtt);
    /* TRANCEIVER 模拟衰减预埋 30 - 校准因子(-3db)-G1 (离线参数表) */
    retVal |= BspSetRxGain(chanNo, anaAtt);
    
    digPreAtt[chanNo] = digAtt;
    anaPreAtt[chanNo] = anaAtt;
    
    return retVal;
}

UINT32 BspCfgMgcModePreAtt(VOID)
{
    UINT32 retVal  = BSP_OK;
    UINT32 chIndex = 0;
    UINT32 rfChNum = 0;
    
    rfChNum = BspGetRxChannel();
    for (chIndex = 0; chIndex < rfChNum; chIndex++)
    {
        retVal = BspSetRxPreAtt_MGC(chIndex);
        if (retVal != BSP_OK)
        {
            dbgErr("BspCfgMgcModePreAtt > BspSetRxPreAtt_MGC error, rfch [%u]\r\n", chIndex);
            return retVal;
        }
    }

    return retVal;
}

UINT32 BspGetAgcCtrlFlag(VOID)
{
    dbgInfoEx("Agc Status = %d [0-Stop, 1-Start]\n", g_sTrxAgcCtrlFlag);
    return g_sTrxAgcCtrlFlag;
}

static UINT32 GetTransceiverChipNum()
{
    TRruDeviceDescription *pDev = NULL;
    UINT32 loop;
    static UINT32 num = 0;

    if (num != 0)
    {
    	return num;
    }
    for (loop = 0; loop < BspGetTxBspChanNum(); loop++)
    {
        if (0 == BspChipInfoPtrGetByRfPathDef(loop,TX,DEVICE_TYPE_TRANSCEIVER,&pDev))
        {
            if (pDev->ulDeviceCfg != INVALID_VALUE)
            {
                num++;
            }
        }
    }
    return num;
}

UINT32 BspGetTrxDevNum(VOID)
{
    if(0 == g_MtsDevNum)//未初始化
    {
        g_MtsDevNum = GetTransceiverChipNum();
    }
    if (g_MtsDevNum > MTS_MAX_CHIP_NUM)
    {
        return MTS_MAX_CHIP_NUM;
    }
    return g_MtsDevNum;
}


static vga_ADI_SwitchAgc Vga_ADISwitchAgc(VOID)
{
    return s_pADI_SwitchAgc;
}

static vga_MTS_SwitchAgc Vga_MTSSwitchAgc(VOID)
{
    return s_pMTS_SwitchAgc;
}

static vga_TI_SwitchAgc Vga_TISwitchAgc(VOID)
{
    return s_pTI_SwitchAgc;
}

static vga_ADI_SwitchAgc Vga_ADIStopAgc(VOID)
{
    return s_pADI_StopAgc;
}


UINT32 BspStopAgcCtrl_Trx(VOID)
{
    vga_MTS_SwitchAgc pMTS_SwitchAgc = NULL;
    UINT32 chipNum = BspGetTrxDevNum();
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 trsvNameId = 0;
    vga_TI_SwitchAgc pTI_SwitchAgc = NULL;
    vga_ADI_SwitchAgc pADI_StopAgc = NULL;
    for (loop = 0; loop < chipNum; ++loop)
    {
        pMTS_SwitchAgc = Vga_MTSSwitchAgc();
        if(pMTS_SwitchAgc != NULL)
        {
            retVal |= pMTS_SwitchAgc(loop, 3);
            dbgInfoEx("The function pointer[pMTS_SwitchAgc]  is ok.\n");
        }
    }
    if (BspGetTransceiverInfoByBspChnl(0, &trsvNameId, NULL, NULL) != BSP_OK)
    {
        dbgInfoEx("%s >> get transceiver info failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if(DEVICE_AFE7989 == trsvNameId)
    {
        pTI_SwitchAgc = Vga_TISwitchAgc();
        if(pTI_SwitchAgc != NULL)
        {
            retVal |= pTI_SwitchAgc(DISABLE);
            dbgInfoEx("The function pointer[pADI_SwitchAgc]  is ok.\n");
        }
    }
    if(DEVICE_AD903X == trsvNameId)
    {
        pADI_StopAgc = Vga_ADIStopAgc();
        if(pADI_StopAgc != NULL)
        {
            retVal |= pADI_StopAgc();
            dbgInfoEx("The function pointer[pADI_StopAgc]  is ok.\n");
        }
    }   
    return retVal;
}

UINT32 BspGetADISwitchAgc(vga_ADI_SwitchAgc pCallBackFunc)
{
    s_pADI_SwitchAgc = pCallBackFunc;

    return BSP_OK;   
}

UINT32 BspGetMTSSwitchAgc(vga_MTS_SwitchAgc pCallBackFunc)
{
    s_pMTS_SwitchAgc = pCallBackFunc;

    return BSP_OK;
}

UINT32 BspGetADIStopAgc(vga_ADI_SwitchAgc pCallBackFunc)
{
    s_pADI_StopAgc = pCallBackFunc;

    return BSP_OK;   
}

UINT32 BspGetTiSwitchAgc(vga_TI_SwitchAgc pCallBackFunc)
{
    s_pTI_SwitchAgc = pCallBackFunc;
    return BSP_OK;
}

UINT32 BspStartAgcCtrl_Trx(VOID)
{
    vga_MTS_SwitchAgc pMTS_SwitchAgc = NULL;
    vga_ADI_SwitchAgc pADI_SwitchAgc = NULL;
    vga_TI_SwitchAgc pTI_SwitchAgc = NULL;
    UINT32 chipNum = BspGetTrxDevNum();
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 trsvNameId = 0;

    if (BspGetTransceiverInfoByBspChnl(0, &trsvNameId, NULL, NULL) != BSP_OK)
    {
        dbgInfoEx("%s >> get transceiver info failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if (DEVICE_MTS == trsvNameId || DEVICE_MTS2PRE == trsvNameId || DEVICE_MTS21PRE == trsvNameId)
    {
        for (loop=0; loop < chipNum; ++loop)
        {
            pMTS_SwitchAgc = Vga_MTSSwitchAgc();
            if(pMTS_SwitchAgc != NULL)
            {
                retVal |= pMTS_SwitchAgc(loop, 0);
                dbgInfoEx("The function pointer[pMTS_SwitchAgc]  is ok.\n");
            }
        }
    }
    else if(DEVICE_AD903X == trsvNameId)
    {
        pADI_SwitchAgc = Vga_ADISwitchAgc();
        if(pADI_SwitchAgc != NULL)
        {
            retVal |= pADI_SwitchAgc();
            dbgInfoEx("The function pointer[pADI_SwitchAgc]  is ok.\n");
        }        
    }
    else if(DEVICE_AFE7989 == trsvNameId)
    {
        pTI_SwitchAgc = Vga_TISwitchAgc();
        if(pTI_SwitchAgc != NULL)
        {
            retVal |= pTI_SwitchAgc(ENABLE);
            dbgInfoEx("The function pointer[pADI_SwitchAgc]  is ok.\n");
        }
    }

    return retVal;
}


/*****************************************************************************
*  函数名称   : BspSetTempComp
*  功能描述   : 设置温度补偿
*  输入参数   : chanNo : 通道号
               dir : 上下行方向
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波 @2022-06-13 17:13:05
*----------------------------------------------------------------------------
*/
UINT32 BspSetTempComp(UINT32 chanNo, UINT32 dir)
{
    UINT32 retVal = 0;
    UINT32 maxRfChNum = 0;

    maxRfChNum = BspGetRxChannel();

    if (dir != RX)
    {
        return BSP_OK;
    }
    if (chanNo >= maxRfChNum)
    {
        dbgErr(">>BspSetTempComp, chanNo [%u] over max num [%u]\r\n", chanNo, maxRfChNum);
        return BSP_ERROR;
    }
    dbgInfoEx("%s>>chanNo %d\n",__FUNCTION__,chanNo);

    retVal = BspSetRxPreAtt_AGC(chanNo, 1);

    return retVal;
}


/*****************************************************************************
*  函数名称   : BspVgaAgcCfgInit
*  功能描述   : Agc控制参数初始化
*  输入参数   : pVgaCtrlPara : VGA控制参数
               pVgaCompPara : VGA补偿压缩参数
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波 @2022-06-13 11:12:26
*----------------------------------------------------------------------------
*/
UINT32 BspVgaAgcCfgInit(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCompPara *pVgaCompPara)
{
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pVgaCtrlPara);
    INPUT_POINTER_CHECK(pVgaCompPara);

    s_pVgaCtrlPara = pVgaCtrlPara;
    retVal = BspHalAdaptInitVgaAgc(pVgaCtrlPara, pVgaCompPara);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspVgaMgcCfgInit
*  功能描述   : Mgc控制参数初始化
*  输入参数   : pVgaCtrlPara : VGA控制参数
               pVgaCtrlMgcPara : MGC参数
               pVgaCompPara : VGA补偿压缩参数
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波 @2022-06-13 10:42:46
*----------------------------------------------------------------------------
*/
UINT32 BspVgaMgcCfgInit(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCtrlMgcPara *pVgaCtrlMgcPara, T_BspHalAdaptVgaCompPara *pVgaCompPara)
{
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pVgaCtrlPara);
    INPUT_POINTER_CHECK(pVgaCtrlMgcPara);
    INPUT_POINTER_CHECK(pVgaCompPara);

    s_pVgaCtrlPara = pVgaCtrlPara;
    retVal = BspHalAdaptInitVgaMgc(pVgaCtrlPara, pVgaCtrlMgcPara, pVgaCompPara);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspStopAgcCtrl
*  功能描述   : 切换到MGC模式
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 采用AGC方案的机型在初始化中调用；若该机型为MGC方案，调用时返回 BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波 @2022-06-13 15:05:00
*----------------------------------------------------------------------------
*/
UINT32 BspStopAgcCtrl(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockIdx = 0;

    if(NULL == s_pVgaCtrlPara)
	{
        dbgInfo("[%s] s_pVgaCtrlPara is not initialized！\n", __FUNCTION__);
		return BSP_ERROR;
	}

    if(VGA_MODE_AGC == s_pVgaCtrlPara->uiVgaMode)
	{
        /* 刷新slicer 因子 */
        retVal |= BspHalAdaptSetVgaTransDbLut(blockIdx, &g_sEmptyVgaSliceLut[0]); 
        retVal |= BspStopAgcCtrl_Trx();    
        g_sTrxAgcCtrlFlag = FALSE;
        BspSetVgaCtrlMode(VGA_MODE_AGC);
        /* 设置MGC模式下的衰减预埋 */
        retVal |= BspCfgMgcModePreAtt();

        /*切回MGC模式后获取rxAtt，RSSI检测需要配置rxAtt获取的标记*/
        retVal |= BspSetGainCtrlPreAttMode(GAIN_CTRL_NOT_EMBODY_PREATT);
	}


    return retVal;
}


/*****************************************************************************
*  函数名称   : BspStartAgcCtrl
*  功能描述   : 启动VGA功能
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 单板初始化启动后，由APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10307448徐利波 @2022-06-13 21:00:24
*----------------------------------------------------------------------------
*/
UINT32 BspStartAgcCtrl(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockIdx = 0;

    if(NULL == s_pVgaCtrlPara)
	{
		dbgInfo("[%s] s_pVgaCtrlPara is not initialized！\n", __FUNCTION__);
		return BSP_ERROR;
	}

    if(VGA_MODE_AGC == s_pVgaCtrlPara->uiVgaMode)
    {
    	BspSetAgcCfgAnaPreAttSw(g_agcAnaPreAttFlag);
		retVal |= BspStartAgcCtrl_Trx();
		BspSetVgaCtrlMode(VGA_MODE_AGC);
		g_sTrxAgcCtrlFlag = TRUE;

		/* 设置AGC模式下,Rx衰减预埋 */
		retVal |= BspSetAllChnAgcPreAtt();

		/* 配置slice 映射表 */
		retVal |= BspHalAdaptSetVgaTransDbLut(blockIdx, s_pVgaCtrlPara->uiVgaLutTab);
		retVal |= BspHalAdaptSetVgaTransDbLut(blockIdx, &g_sEmptyVgaSliceLut[0]);
		retVal |= BspHalAdaptSetVgaTransDbLut(blockIdx, s_pVgaCtrlPara->uiVgaLutTab);

		 /*AGC模式下，RSSI检测不需要获取rxAtt*/
		BspSetGainCtrlPreAttMode(GAIN_CTRL_EMBODY_PREATT);
    }

    return retVal;
}

/**************************************************************************
 *                         维测接口实现
 **************************************************************************/
UINT32 showpreatt(VOID)
{
    UINT32 retVal     = 0;
    UINT32 loopI      = 0;
    UINT32 loopJ      = 0;
    UINT32 chipId     = 0;
    UINT32 difChan    = 0;
    UINT32 bspChan    = 0;
    UINT32 rfChNum    = 0;
    INT32 caliPreAtt  = 0;
    INT32 halRxPreAtt = 0;
    INT32  fixGain    = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    rfChNum = BspGetRxChannel();

    for (loopI = 0; loopI < rfChNum; loopI++)
    {
        if (g_sTrxAgcCtrlFlag == FALSE)
        {
            dbgInfo("MgcMode RfChan: [%u], AnaPreAtt: [%d], DigitPreAtt: [%d]\r\n", loopI, anaPreAtt[loopI], digPreAtt[loopI]);
        }
        else
        {
            retVal |= BspGetBspChnByRfChn(loopI, RX, &bspChan);
            retVal |= BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);

            pRfCfg = GetRfCfgPara(bspChan,TX);
            if (NULL == pRfCfg)
            {
                dbgErr("[%s]difChan'%d pRfCfg Get Error!\n",__FUNCTION__, difChan);
                return BSP_ERROR;
            }

            for (loopJ = 0; loopJ < pRfCfg->para.carrNum; loopJ++)
            {
                // retVal |= BspGetRxPreAttByFreq(loopI, pRfCfg->para.carrInfo[loopJ].freq, &caliPreAtt);
                retVal |= BspHalAdaptGetRxVgaGain(difChan, pRfCfg->para.carrInfo[loopJ].radioMode, pRfCfg->para.carrInfo[loopJ].carrNo, &halRxPreAtt);
                retVal |= _BspGetRxChanTargetGain_Base(bspChan, (UINT32)0, &fixGain);
                dbgInfo("AgcMode RfChan [%u], carrNo [%u], radioMode [%#x], carrFreq [%u], fixGain [%d], caliRxPreAtt [%d], halRegPreAtt [%d]\r\n", loopI,
                        pRfCfg->para.carrInfo[loopJ].carrNo, pRfCfg->para.carrInfo[loopJ].radioMode,
                        pRfCfg->para.carrInfo[loopJ].freq, fixGain, caliPreAtt, halRxPreAtt);
            }
        }
    }

    return retVal;
}



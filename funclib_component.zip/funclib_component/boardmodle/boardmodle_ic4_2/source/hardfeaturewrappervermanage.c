/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeaturewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了保护区初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "hardfeaturewrappervermanage.h"
#include "board_ic4_2.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "boardverprotect.h"
#include "bspcommon.h"


/**************************************************************************
 * 函数名称: BspInitVerProtect(*)
 * 功能描述: 保护区版本信息初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspInitVerProtect(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    UINT32 flashParaSel = BspGetFlashParaSel();
    T_VerProtectInfo* verInfo = NULL;
    T_VerProtectInfo protectVerInfo[FLASH_PARA_MAX] =
    {
        {
            PROTECT_ZONE_ADDRESS,
            PROTECT_ZONE_SIZE,
            PROTECT_ZONE_FULL_VER,
        },
        {
            PROTECT_ZONE_ADDRESS_NOR,
            PROTECT_ZONE_SIZE_NOR,
            PROTECT_ZONE_FULL_VER,
        },
    };

    retVal = BspBoardModleGetData(E_HARD_FEATURE_INIT_VER_PROTECT, 0, 0, (VOID **)&verInfo, &num);
    if (retVal != BSP_OK)
    {
        if (flashParaSel >= FLASH_PARA_MAX)
        {
            flashParaSel = FLASH_PARA_NOR_NAND;
        }
        verInfo = &protectVerInfo[flashParaSel];
    }
    retVal = BspInitVersionProtect(verInfo);
    
    return retVal;
}

/**************************************************************************
 * 函数名称: BspInitProtectFileList(*)
 * 功能描述: 保护区版本清单初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspInitProtectFileList(VOID)
{
    UINT32 retVal = BSP_OK;
    T_AllRunVerList *verList = NULL;
    UINT32 num = 0;    

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_INIT_PROTECT_FILELIST, 0, 0, verList, num);
    retVal = BspSetProtectFileList(verList);
    
    return retVal;
}

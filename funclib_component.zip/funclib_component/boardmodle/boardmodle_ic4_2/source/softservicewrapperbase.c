/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : softservicewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了主控和版本管理进程共同所需的初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2023-11-23
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2023-11-23
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/


#include "bsppub.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "udpmsg_ic.h"
#include "boardsocmsg.h"
#include "exprn.h"
#include "softservicewrapperbase.h"
#include "coreprocaffinity.h"

UINT32 UdpMsgModuleInit(VOID)
{
    UINT32 ulLoop = 0;
    T_UdpPathDesc udppathdesc = {0};
    T_UdpPathSocketInfo tmpUdpSocketInfo = {0};
    T_UdpPathSocketCfgInfo *pPara = NULL;
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;

    retVal = BspUdpMsgQueryParaInit();

    BOARD_MODLE_GET_DATA(E_SOFT_SERVICE_UDPMSGMODULE_INIT, 0, 0, pPara, num);
    dbgInfo("pPara->usedTypeNum %d %p\n", pPara->usedTypeNum, pPara);
    if (pPara->usedTypeNum == 0)
    {
        return BSP_ERROR;
    }

    for (ulLoop = 0; ulLoop < pPara->usedTypeNum; ulLoop++)
    {
        tmpUdpSocketInfo = pPara->udpSocketInfo[ulLoop];
        udppathdesc.typeId = tmpUdpSocketInfo.typeId;
        //tx info
        udppathdesc.tx_info.port = tmpUdpSocketInfo.tx_info.port;
        udppathdesc.tx_info.pathid = tmpUdpSocketInfo.tx_info.pathid;
        udppathdesc.tx_info.binden = tmpUdpSocketInfo.tx_info.binden;
        memcpy_s(udppathdesc.tx_info.ip, sizeof(tmpUdpSocketInfo.tx_info.ip),\
                tmpUdpSocketInfo.tx_info.ip, sizeof(tmpUdpSocketInfo.tx_info.ip));
        //rx info
        udppathdesc.rx_info.port = tmpUdpSocketInfo.rx_info.port;
        udppathdesc.rx_info.pathid = tmpUdpSocketInfo.rx_info.pathid;
        memcpy_s(udppathdesc.rx_info.ip, sizeof(tmpUdpSocketInfo.rx_info.ip),\
                tmpUdpSocketInfo.rx_info.ip, sizeof(tmpUdpSocketInfo.rx_info.ip));
        //init
        UdpPathInit(udppathdesc);
    }
    BspInitUdpPathSocketCfgInfo(pPara);

    dbgInfoEx("%s %d Succ!\n", __FUNCTION__, __LINE__);
    return retVal;
}

UINT32 BspCoreProcAffinityInit(void)
{
    T_CoreProcAffinityInfo  *pPara = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;

    BOARD_MODLE_GET_DATA(E_SOFT_SERVICE_CORE_AFFINITY_CFG, 0, 0, pPara, num);

    for (loop = 0; loop<num; loop++)
    {
        retVal |= BspCoreProcAffinitySet(pPara->procName, pPara->coreMask);
        pPara++;
    }

    return retVal;
}
/*************************************************************
 *
 *	filename	: ma_ctrl.h
 *	author	: luca
 *  comments: manage master's serials
 *
 *************************************************************/
#include <stdio.h>
#include <math.h>
#include "bsppub.h"
#include "bspcomm.h"

#include "dpdicxmodem.h"
#include "vxadp.h"
#include "exprn.h"
#include "crc.h"
#include "bspcommon.h"
#include "uart_ic4_2.h"
#include "boardreset.h"
#include "chippoweronwrapper.h"
/*
    DPDIC4.2 add start
*/
#define SocRstLog(level, fmt...)             //SocResetPrint(level, ##fmt)
/*
    DPDIC4.2 add end
*/

#define DPDIC_LOAD_DUART3_ID   0   //4C单板中的DUART3   --ttyS3
#define DPDIC_LOAD_DUART4_ID   1   //4C单板中的DUART4   --ttyS4

#define DPDIC_VERSION_PATH_PREXLOAD      "/tmp/bootloader1.bin"
#define DPDIC_VERSION_PATH_XLOAD         "/tmp/bootloader2.bin"
#define DPDIC_VERSION_PATH_RAMBOOT       "/tmp/ramboot.bin"

#define TIMEOUTBYSEC(buflen,baud) (buflen*20/baud+2)
#define TIMEOUTBYUSEC(buflen,baud) (buflen*20*1000000/baud )

#define XMODEM_LOAD_INIT_STATUS_CHECK(initFlag)                                 \
    if (NXP_SERIAL_MODULE_INIT_OK != initFlag)                                  \
    {                                                                           \
        dbgErr("%s:module Init status is err!\n",__FUNCTION__);                 \
        return BSP_ERROR;                                                       \
    }
#define XMODEM_SND_LENTH_CHECK(lenth1,lenth2)                                   \
    if (lenth1 <= lenth2)                                                       \
    {                                                                           \
        dbgErr("%s:Length[%d] is <= limit[%d] !\n",__FUNCTION__,lenth1,lenth2); \
        return BSP_ERROR;                                                       \
    }
#define PRN_LOADING_PROGRESS(lenth1,lenth2)                                     \
    if ((0 != lenth1) && (0 == (lenth1 & lenth2)))                              \
    {                                                                           \
        printf(".");                                                            \
    }    
    
/**************************************************************/
SEM_ID DpdIcLoadSem = NULL;

/* 全局串口管理块*/
T_NXP_SERIAL_APP gtNxpSerialApp;
UINT32 gtNxpSerialModuleInitFlag = NXP_SERIAL_MODULE_INIT_WAIT;

INT32 NxpComPortFd[NXP_COM_PORT_MAX] = {-1,-1,-1,-1,-1,-1,-1,-1};
static const CHAR *s_NxpComPortName[NXP_COM_PORT_MAX] = {0};
static UINT32 s_dpdicSocComPortIdx[DPDIC_SOC_MAX_NUM] = {0}; 
static UINT32 s_dpdicSocUartIdx[DPDIC_SOC_MAX_NUM] = {0};

T_DPDIC_XMODEM_INFO *s_pDpdicXmodemInfo = NULL;

static struct termios termios_last, termios_now;

static INT32 baudrateArray[][2] = 
{
    {9600,B9600},
    {19200,B19200},
    {38400,B38400},
    {57600,B57600},
    {115200,B115200},
    {460800,B460800},
    {921600,B921600},
    {1562500,B1500000}, 
    {3125000,B3000000},
    {3686400,B3500000},
    {4000000,B4000000},     
};
static UINT32 baudArrayRow = sizeof(baudrateArray)/sizeof(baudrateArray[0]);

T_LOADVER_INFO xloadVersionMap[] =
{
    /*     版本                           路径 */
    {DPDIC_VERSION_PREXLOAD,        DPDIC_VERSION_PATH_PREXLOAD},
    {DPDIC_VERSION_XLOAD,           DPDIC_VERSION_PATH_XLOAD},
    {DPDIC_VERSION_RAMBOOT,         DPDIC_VERSION_PATH_RAMBOOT},
};

UINT32 g_XmdoemMode = 0; 
UINT32 g_DpdIcLoadChip = 0;
UINT32 g_dpdIcLoadStat[DPDIC_SOC_MAX_NUM] = {0xF0000000,0xF0000000};
UINT32 g_XmdoemSndErr[DPDIC_SOC_MAX_NUM] = {0};

/*********************************************************************/

static UINT32 BspSetBaudrate(INT32 baudrate)
{
    INT32 flag = B115200;
    UINT32 ulCnt = 0;
    
    for(ulCnt=0;ulCnt<baudArrayRow;ulCnt++)
    {
        if(baudrateArray[ulCnt][0]==baudrate)
        {
             flag = baudrateArray[ulCnt][1];
             break;
        }
    }
    if(ulCnt==baudArrayRow)
    {
        dbgErr("%s>> Can't Find %d baudrate ,use default 115200 !\n",__FUNCTION__,baudrate);        
    }

    termios_now.c_cflag =flag;  /* set baudrate */
    return BSP_OK;
}
static INT32 BspGetBaudrate(VOID)
{
    INT32 baudrate = 0;
    INT32 flag = 0;
    UINT32 ulCnt = 0;
    
    flag = cfgetospeed (&termios_now);

    for(ulCnt=0;ulCnt<baudArrayRow;ulCnt++)
    {
        if(baudrateArray[ulCnt][1]==flag)
        {
             baudrate = baudrateArray[ulCnt][0];
             break;
        }
    }
    if(ulCnt==baudArrayRow)
    {
        dbgErr("%s>> Can't Find %d Flag  !\n",__FUNCTION__,flag);        
    }
    return baudrate;
}
static UINT32 BspSetDataBit(INT32 databit)
{
    termios_now.c_cflag &= ~CSIZE;
    switch (databit) 
    {
        case 8:
            termios_now.c_cflag |= CS8;
            break;
        case 7:
            termios_now.c_cflag |= CS7;
            break;
        case 6:
            termios_now.c_cflag |= CS6;
            break;
        case 5:
            termios_now.c_cflag |= CS5;
            break;
        default:
            termios_now.c_cflag |= CS8;
            break;
    }
    return BSP_OK;
}
static UINT32 BspSetParityCheck(INT8 parity)
{
    switch (parity)
    {
        case 'N':                /* no parity check */
            termios_now.c_cflag &= ~PARENB;
            break;
        case 'E':                 /* even */
            termios_now.c_cflag |= PARENB;
            termios_now.c_cflag &= ~PARODD;
            break;
        case 'O':                 /* odd */
            termios_now.c_cflag |= PARENB;
            termios_now.c_cflag |= ~PARODD;
            break;
        default:                 /* no parity check */
            termios_now.c_cflag &= ~PARENB;
            break;
    }
    return BSP_OK;
}
static UINT32 BspSetStopBit(const char *stopbit)
{
    if (0 == strcmp (stopbit, "1"))
    {
        termios_now.c_cflag &= ~CSTOPB; /* 1 stop bit */
    }
    else if (0 == strcmp (stopbit, "1.5"))
    {
        termios_now.c_cflag &= ~CSTOPB; /* 1.5 stop bits */
    }
    else if (0 == strcmp (stopbit, "2"))
    {
        termios_now.c_cflag |= CSTOPB;  /* 2 stop bits */
    }
    else
    {
        termios_now.c_cflag &= ~CSTOPB; /* 1 stop bit */
    }
    return BSP_OK;
}
static INT32 BspSetPortAttr(UINT32 comPort,INT32 baudrate,INT32 databit, const char *stopbit, INT8 parity)
{
    memset(&termios_now,0, sizeof (termios_now));
    cfmakeraw(&termios_now);
    BspSetBaudrate(baudrate);
    termios_now.c_cflag |= CLOCAL | CREAD;      /* | CRTSCTS */
    BspSetDataBit(databit);
    BspSetParityCheck(parity);
    BspSetStopBit(stopbit);
    termios_now.c_oflag = 0;
    termios_now.c_lflag |= 0;
    termios_now.c_oflag &= ~OPOST;
    termios_now.c_cc[VTIME] = 1;        /* unit: 1/10 second. */
    termios_now.c_cc[VMIN] = 1; /* minimal characters for reading */
    tcflush(NxpComPortFd[comPort], TCIFLUSH);
    return (tcsetattr(NxpComPortFd[comPort], TCSANOW, &termios_now));
}

/*case: OpenComPort(6, 3686400, 8, "1",'N')*/
UINT32 BspOpenNxpComPort(UINT32 ComPort, INT32 baudrate, INT32 databit,const CHAR *stopbit, CHAR parity)
{
    char  comPort[50] = {0};
    INT32 retval = BSP_OK;
    INT32 snpRet = 0;

    if(ComPort < NXP_COM_PORT_MAX)
    {
        snpRet = snprintf_s(comPort,sizeof(comPort),"%s",s_NxpComPortName[ComPort]);//4C单板DUART3对应dev/ttyS3
        SNPRINTF_S_CHECK(snpRet, sizeof(comPort));        
    }
    else 
    {
        dbgErr("%s failed\n",__FUNCTION__);
        return BSP_ERROR;        
    }

    if(-1 == NxpComPortFd[ComPort])
    {
        NxpComPortFd[ComPort] = open(comPort, O_RDWR | O_NOCTTY | O_NONBLOCK);
        if (-1 == NxpComPortFd[ComPort])
        {
            SocRstLog(RST_INFO, "M0 open>>ComPort:%d, ComPortFdSta:%d\n",ComPort,NxpComPortFd[ComPort]);
            dbgErr("%s cannot open port %s\n",__FUNCTION__,comPort);
            return BSP_ERROR;
        }
    }
    retval = tcgetattr(NxpComPortFd[ComPort], &termios_last);
    if (-1 == retval)
    {
        SocRstLog(RST_INFO, "M0 tcgetattr>>ComPortFdSta:%d,retval:%d\n",NxpComPortFd[ComPort],retval);
        dbgErr("%s>>tcgetattr failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /* 0 on success, -1 on failure */
    retval = BspSetPortAttr(ComPort, baudrate, databit, stopbit, parity);
    if (-1 == retval)
    {
        SocRstLog(RST_INFO, "M0 BspSetPortAttr>>ComPort:%d,retval:%d\n",ComPort,retval);
        dbgErr("%s port %s cannot set baudrate at %d\n",__FUNCTION__,comPort,baudrate);
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspInitNxpSerial(UINT32 chip, UINT32 baudrate)
{
    UINT32 retVal = BSP_OK;

    if(chip<DPDIC_SOC_MAX_NUM && s_dpdicSocComPortIdx[chip]<NXP_COM_PORT_MAX)
    {
        retVal = BspOpenNxpComPort(s_dpdicSocComPortIdx[chip] ,baudrate,8, "1",'N');//DPDIC_LOAD_UART_ID，Dra62x用UART ID	
    }
    else
    {
	    dbgErr("not belong the range!");	
    }
    return retVal;
}

INT32 BspReadNxpComPortInTime(UINT32 ulChip, VOID *data, INT32 datalength,UINT32 maxT)
{
    INT32  ret = 0;
    INT32  retval = 0;
    UINT32 ulBackLen = 0;
    UINT32 ulBaudrate = 0;
    UINT32 ulPortBaud = 0;
    UINT32 ulUsenc = 0;
    struct timeval tv_timeout;
    fd_set  fs_read;
    UINT32 comPort = 0;

    if(ulChip<DPDIC_SOC_MAX_NUM && s_dpdicSocComPortIdx[ulChip]<NXP_COM_PORT_MAX)
    {
        comPort = s_dpdicSocComPortIdx[ulChip];
    }
    else 
    {
        return BSP_ERROR;
    }
    
    FD_ZERO(&fs_read);
    FD_SET(NxpComPortFd[comPort], &fs_read);

    ulBackLen  = (UINT32)(datalength & 0x7FFFFFFF);
    ulBaudrate = (UINT32)(BspGetBaudrate() & 0x7FFFFFFF);
    if (0 != ulBaudrate)
    {
        // TIMEOUTBYUSEC(buflen,baud) (buflen * 20 *1000000 / baud)
        // usenc = TIMEOUTBYUSEC(datalength, ulBaudrate) + maxT;
        // ulUsenc = (datalength * 20 * 1000000 / ulBaudrate) + maxT;
        if (ulBackLen < (UINT32)(0xFFFFFFFF / (20 * 1000000)))
        {
            ulPortBaud = ulBackLen * 20 * 1000000 / ulBaudrate;
            if (ulPortBaud < (UINT32)(0xFFFFFFFF - maxT))
            {
                ulUsenc = ulPortBaud + maxT;
            }
        }
        tv_timeout.tv_sec  = ulUsenc / 1000000;
        tv_timeout.tv_usec = ulUsenc % 1000000;
    }
    //dbgInfo("%s>>timeout %d s\n",__FUNCTION__,tv_timeout.tv_sec);
    retval = select(NxpComPortFd[comPort] + 1, &fs_read, NULL, NULL, &tv_timeout);
    if (retval)
    {
        ret =zte_read_s(NxpComPortFd[comPort], data, datalength, datalength);
        dbgInfoEx("%s>>retval:%d,data %p\n",__FUNCTION__,retval,data);
        return (ret);
    }
    else
    {
        return BSP_ERROR;
    }
}
INT32 BspReadNxpComPort(UINT32 ulChip, VOID *data, INT32 datalength)
{
    return BspReadNxpComPortInTime(ulChip,data, datalength,2000000);
}

INT32 BspNxpSerialRcvChar(UINT32 ulChip, INT8 *pChar)
{
    INT32 lRetval = 0;

    INPUT_POINTER_CHECK(pChar);

    lRetval = BspReadNxpComPort(ulChip, pChar, 1);
    dbgInfoEx("[%s]%d,char:%d\n", __FUNCTION__, __LINE__, *pChar);

    return lRetval;
}

/*接收串口数据buf和长度*/
UINT32 BspNxpSerialRcv(UINT32 ulChip, UINT8 *pcRcvBuf, UINT32 dwBufLen)
{
    //need to add timeout function
    INT8 c;
    UINT8 *p = NULL;
    UINT32 n = 0;

    p = pcRcvBuf;
    for (;;)
    {
        if (-1==BspNxpSerialRcvChar(ulChip,&c))
        {
            printf("serial recv error!\n");
            return BSP_ERROR;
        }

        if(++n >= dwBufLen)
        {
            *p = '\0';
            break; /* sanity check */
        }

        *p++ = c;
        if ('\n' == c) /* eof */
        {
            *p = '\0';
            break;
        }
    }
    //printf("serial recv:%s\n", pcRcvBuf);
    return BSP_OK;
}
UINT32 BspNxpSerialRecvByte(UINT32 ulChip,UINT8 *data)
{
    INPUT_POINTER_CHECK(data);
    return BspNxpSerialRcv(ulChip,data,1);
}
UINT32 BspNxpSerialRcvInTime(UINT32 ulChip, INT8 *pcRcvBuf, UINT32 dwBufLen,UINT32 maxT)
{
    // need to add timeout function
    INT8 c;
    INT8 *p = NULL;
    UINT32 n = 0;

    p = pcRcvBuf;
    for (;;)
    {
        if (-1==BspReadNxpComPortInTime(ulChip,&c,1,maxT))
        {
            dbgInfo("%s>>serial recv error!\n",__FUNCTION__);
            return BSP_ERROR;
        }

        if(++n >= dwBufLen)
        {
            *p = '\0';
            break; /* sanity check */
        }

        *p++ = c;
        if ('\n' == c) /* eof */
        {
            *p = '\0';
            break;
        }
    }

    return BSP_OK;
}

/*发送给DPDIC串口数据buf和长度*/
UINT32 BspNxpSerialSnd(UINT32 ulChip, UINT8 *pcSndBuf, UINT32 dwBufLen)
{
    INT32 len = 0;
    UINT32 comPort = 0;

    if(ulChip<DPDIC_SOC_MAX_NUM && s_dpdicSocComPortIdx[ulChip]<NXP_COM_PORT_MAX)
    {
        comPort = s_dpdicSocComPortIdx[ulChip];
    }
    else 
    {
        return BSP_ERROR;
    }

    INPUT_POINTER_CHECK(pcSndBuf);
    len = write(NxpComPortFd[comPort],pcSndBuf,dwBufLen);
    if(len != dwBufLen)
    {
        dbgErr("%s>>write ComPort err:%d!\n",__FUNCTION__,len);
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspNxpSerialSendByte(UINT32 ulChip,UINT8 data)
{     
    UINT8 tmpdata = data;
    return BspNxpSerialSnd(ulChip,&tmpdata,1);
}

/*映射ic的串口到nxp的LPUART5*/
UINT32 BspSwitchDpdIcUartPort(UINT32 ulchip)
{        
    if(ulchip >= DPDIC_SOC_MAX_NUM)
    {
        dbgErr("%s icId err,should be less %d !\n",__FUNCTION__,4);
        return BSP_ERROR;
    }

    BspSetUartMap(s_dpdicSocUartIdx[ulchip]);
    return BSP_OK;
}

UINT32 NxpSerialBaudrateSet(UINT32 ulChip,UINT32 dwBaudrate)
{
    /* 设置主串口波特率 */
    gtNxpSerialApp.tNxpSerialDrv.pfNxpSerialInit(ulChip,dwBaudrate);
    //gtNxpSerialApp.tNxpSerialDrv.pfMSTimeDelay(500);

    dbgInfo("Change SM Serials BaudRate to B%d ... OK\n", dwBaudrate);
    return BSP_OK;
}

UINT32 NxpSerialRcvFifoClear(UINT32 ulchip)
{
    UINT32 comPort = 0;

    if(ulchip<DPDIC_SOC_MAX_NUM && s_dpdicSocComPortIdx[ulchip]<NXP_COM_PORT_MAX)
    {
        comPort = s_dpdicSocComPortIdx[ulchip];
    }
    else 
    {
        return BSP_ERROR;
    }

    tcflush(NxpComPortFd[comPort], TCIFLUSH);
    return BSP_OK;
}

void NxpSerialTxFifoClear(UINT32 ulchip)
{
    UINT32 comPort = 0;

    if(ulchip<DPDIC_SOC_MAX_NUM && s_dpdicSocComPortIdx[ulchip]<NXP_COM_PORT_MAX)
    {
        comPort = s_dpdicSocComPortIdx[ulchip];
    }
    else 
    {
        return;
    }

    tcflush(NxpComPortFd[comPort], TCOFLUSH);
    return;
}

/* 流式发送帧 */
INT32 BspNxpSerialSndFrame(UINT32 ulChip, INT8 *pcSndBuf, UINT32 dwBufLen)
{
    UINT16 usInitMask = 0;
    UINT32 ulRet = BSP_OK;
#if 1
    union //Crc16Bytes
    {
        UINT16 usCalCrc16;
        UINT8  ucCrcByte[2];
    }Crc16Data;

    INPUT_POINTER_CHECK(pcSndBuf);
    Crc16Data.usCalCrc16 = CalculateCRC16(usInitMask,(const unsigned char *)pcSndBuf,dwBufLen);
    Crc16Data.usCalCrc16 = ntohs(Crc16Data.usCalCrc16);
    BspNxpSerialSnd(ulChip,(UINT8 *)pcSndBuf,dwBufLen);
    BspNxpSerialSnd(ulChip,&Crc16Data.ucCrcByte[0],1);
    BspNxpSerialSnd(ulChip,&Crc16Data.ucCrcByte[1],1);    
#else
    UINT16 usCalCrc16 = 0;
    usCalCrc16 = CalculateCRC16(usInitMask,pcSndBuf,dwBufLen);

    ulRet = BspNxpSerialSnd(ulChip,pcSndBuf,dwBufLen);
    dbgInfo("%s>>send data \n",__FUNCTION__);
    ulRet |=BspNxpSerialSnd(ulChip,htons(usCalCrc16),2);
    dbgInfo("%s>>send CRC16 \n",__FUNCTION__);
#endif
    return ulRet;
}

UINT32 BspRecSndErr(UINT32 chipNo,UINT32 x)
{
    if(chipNo>=2)
    {
        memset(&g_XmdoemSndErr[0],0,sizeof(g_XmdoemSndErr));
        return BSP_OK;
    }
    g_XmdoemSndErr[chipNo] = BIT_SET(x);
    return BSP_OK;
}

UINT32 BspSetXmdoemMode(UINT32 ulMode)
{
    g_XmdoemMode = (ulMode==0)?(0):(1);
    return BSP_OK;
}

UINT32 g_ucAckIdVolt = 750;
VOID testSetucAckIdVolt(UINT32 value)
{
    g_ucAckIdVolt = value;
}
UINT32 BspGetDpdicVoltByUart(UINT32 ulchip, UINT32 checkCnt)
{
    UINT32 ucAckId = 0;
   
    checkCnt = (checkCnt<2)?(2):(checkCnt);
    dbgInfo("%s>>start waiting ack char C...,tick %llu\n",__FUNCTION__,tick64Get());
    //while (--checkCnt)
    {
        //lRet = BspNxpSerialRcvChar(ulchip, &ucAckId);  //执行时间太长，暂时注释处理，正式调试时放开
        ucAckId = g_ucAckIdVolt;
        dbgInfo("%s>>waiting ack char C...AckId[0x%x]\n",__FUNCTION__,ucAckId);
#if 0 //功能未实现，临时注释0727
        if (lRet == BSP_ERROR)
        {
            return BSP_ERROR;
        }
        else if (XMODEM_CRC_CHR == ucAckId)
        {
            dbgInfo("no achieve valid volt!\n");
            return BSP_ERROR;
        }	
        else if (XMODEM_CRC_CHR1 == ucAckId)
        {
            continue;
        } 
#endif		
        if((XMODEM_CRC_CHR != ucAckId)&&(XMODEM_CRC_CHR1 != ucAckId))
        {
            dbgInfo("%s>>achieve valid volt!\n",__FUNCTION__);
            return ucAckId;
        }		
    }
    dbgInfo("%s>>waiting ack char C...ok,tick %llu\n",__FUNCTION__,tick64Get());
    return BSP_OK;
}

UINT32 BspCheckLoadStart(UINT32 ulchip, UINT32 checkCnt)
{
    INT32 lRet = BSP_OK;
    INT8 ucAckId = -1;
    
    checkCnt = (checkCnt<2)?(2):(checkCnt);
    dbgInfo("%s>>start waiting ack char C...,tick %llu\n",__FUNCTION__,tick64Get());
    while (--checkCnt)
    {
        lRet = BspNxpSerialRcvChar(ulchip,&ucAckId);
        if ((lRet!=-1)&&(XMODEM_CRC_CHR == ucAckId))
        {
            break;
        }     
        dbgInfo("waiting ack char C...AckId[0x%x]\n",ucAckId);
    }
    if(0 == checkCnt)
    {
        dbgErr("%s>>waiting ack char C...timeout,return !\n",__FUNCTION__);  
        BspRecSndErr(g_DpdIcLoadChip,0);
        return BSP_ERROR;
    }	
    dbgInfo("%s>>waiting ack char C...ok,tick %llu\n",__FUNCTION__,tick64Get());
    return BSP_OK;
}
UINT32 BspRepyAckEnd(UINT32 ulchip, INT32 timeoutCnt)
{
    INT8 ucAckId = XMODEM_EOT;
    			
    while ((ucAckId != XMODEM_ACK)&&(timeoutCnt>0))
    {
        dbgInfo("Waiting for Completed ACK ...");
        BspNxpSerialSendByte(ulchip,XMODEM_EOT);
        BspNxpSerialRcvChar(ulchip,&ucAckId);
        timeoutCnt--;
        gtNxpSerialApp.tNxpSerialDrv.pfMSTimeDelay(100);
    }
    if(timeoutCnt<=0)
    {
        printf(".Failed !\n");
        BspRecSndErr(g_DpdIcLoadChip,4);
        return BSP_ERROR;
    }
    printf(". OK !\n");
    return BSP_OK;
}
UINT32 BspReplyAckId(UINT32 ulchip,INT8 xhead,UINT32 xDataSize,INT8 frameCnt,INT8 *pcSendData,UINT32 ulLenth,INT8 *ackId)
{
    INT8 acFrameData[XMODEM_DATA_SIZE_STX + XMODEM_CRC_SIZE + XMODEM_FRAME_ID_SIZE + 1];
    INT8 ucAckId = 0;
    UINT32 tmpVal = BSP_OK;
    INT32 timeout = 8;
    UINT32 dataCnt = 0;

    INPUT_POINTER_CHECK(pcSendData);
    INPUT_POINTER_CHECK(ackId);    
    
    acFrameData[0] = xhead;
    acFrameData[1] = frameCnt;
    acFrameData[2] = (INT8)(255 - acFrameData[1]);

    do
    {
        if(BSP_OK != (tmpVal=BspNxpSerialSnd(ulchip,(UINT8 *)acFrameData, 3)))
        {
            timeout --;
            dbgErr("%s>>send head:failed!\n",__FUNCTION__);
            gtNxpSerialApp.tNxpSerialDrv.pfMSTimeDelay(500);
        }
    }while((tmpVal != BSP_OK)&&(timeout>0));
    if(timeout<=0)
    {
        dbgErr("%s>>Send Head Err ,return !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset(acFrameData,0x1A,xDataSize);
    for(dataCnt=0; dataCnt<min(ulLenth,xDataSize); dataCnt++ )
    {
        acFrameData[dataCnt]= *pcSendData++;
    }
    BspNxpSerialSndFrame(ulchip,acFrameData, xDataSize);
    dbgInfoEx("%s>>SendOver, DataSize %d\n",__FUNCTION__,xDataSize);

    if(-1==BspNxpSerialRcvChar(ulchip,&ucAckId))
    {
        dbgErr("%s>>BspNxpSerialRcvChar Err ,return !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    else
    {
        *ackId = ucAckId;
    }
    
    return BSP_OK;
}
UINT32 XmdoemSndData(UINT32 ulChip,INT8 xhead,UINT32 xDataSize,INT8 frameCnt,INT8 *pcSendData,UINT32 ulLenth)
{
    INT8 ucAckId = 0;
    UINT32 tryCnt = 0;

    INPUT_POINTER_CHECK(pcSendData);
    do
    {
        if(BSP_OK!=BspReplyAckId(ulChip,xhead,xDataSize,frameCnt, pcSendData, ulLenth,&ucAckId))
        {
            dbgErr("%s>>ReplyAckId Failed ,ackId[0x%x] !\n",__FUNCTION__,ucAckId);
            BspRecSndErr(g_DpdIcLoadChip,1);
            return BSP_ERROR;
        }
        if(ucAckId==XMODEM_ACK)
        {           
            return BSP_OK;
        }
        else if(ucAckId!=XMODEM_NAK)
        {
            dbgErr("%s>>Can't Identify ackId[0x%x] !\n",__FUNCTION__,ucAckId);
            BspRecSndErr(g_DpdIcLoadChip,2);
            return BSP_ERROR;
        }
        tryCnt++;
    }while(tryCnt<5);
    if(tryCnt==5)
    {
        dbgErr("%s>>NAK Retry 5 times ,quit !\n",__FUNCTION__);
        BspRecSndErr(g_DpdIcLoadChip,3);
        return BSP_ERROR;
    }
    return BSP_OK;
}

INT32 NxpSerialXmdoemSnd(UINT32 ulchip, INT8 *pcSrcData, UINT32 dwLen)
{
    UINT32 xModemHead = XMODEM_SOH;
    UINT32 xModemDataSize = XMODEM_DATA_SIZE_SOH;
    INT8 *pcSendData = NULL;
    UINT32 frameCnt = 1;
    UINT32 ulLenth = 0;
    UINT32 sndLenth = 0;

    INPUT_POINTER_CHECK(pcSrcData);
    XMODEM_SND_LENTH_CHECK(dwLen,0);
    if(g_XmdoemMode==1)
    {
         xModemHead = XMODEM_STX;
         xModemDataSize = XMODEM_DATA_SIZE_STX;
    }
    if(BSP_ERROR==BspCheckLoadStart(ulchip, 10))
    {
        return BSP_ERROR;
    }
    while((dwLen - sndLenth)>=0)
    {
        pcSendData = pcSrcData+sndLenth;
        if((dwLen - sndLenth) >= xModemDataSize)
        {
            ulLenth = xModemDataSize;
        }
        else
        {
            ulLenth = dwLen -sndLenth;
        }
        if(ulLenth==0)
        {
            return BspRepyAckEnd(ulchip,120);
        }
        if(BSP_OK!=XmdoemSndData(ulchip,(INT8)xModemHead,xModemDataSize,frameCnt,pcSendData,ulLenth))
        {
            dbgInfo("%s>>Send Data Err sndLenth=%d !\n ",__FUNCTION__,sndLenth);
            return BSP_ERROR;
        }
        PRN_LOADING_PROGRESS(frameCnt,0x3);//每3帧打个点
        frameCnt++;
        sndLenth = sndLenth + ulLenth;
    }
   dbgInfo("%s>>Send Data OK !\n ",__FUNCTION__);//永远不会执行到
   return BSP_OK;
}
UINT32 NxpSendXload(UINT32 ulchip, char *pcFileName)
{
    FILE *pFile = NULL;
    UINT32 len;
    UINT32 ulReadSize;
    INT8   *pcBuf = NULL;
    INT8 *image_buf = NULL;
    INT32 fclsRet = 0;

    if( NULL == pcFileName)
    {
        dbgErr("%s>>Input is Null !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pFile = fopen(pcFileName, "rb");
    if (NULL == pFile)
    {
        dbgErr("%s>>Can't Open file: %s\n",__FUNCTION__,pcFileName);
        return BSP_ERROR;
    }

    dbgInfo("%s>>Open %s successful!\n", __FUNCTION__,pcFileName);
    len = BspGetFileLen(pcFileName);
    if(len == BSP_ERROR)
    {
        fclsRet = fclose(pFile);
        FCLOSE_CHECK(fclsRet);
        dbgErr("%s>>GetFileLen Failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    image_buf = (INT8 *)malloc(len + 3);
    if (NULL == image_buf)
    {
        dbgErr("%s>>Can't malloc memory for slave DPDIC !\n",__FUNCTION__);
        fclsRet = fclose(pFile);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    /* 保证分配的内存4字节对齐 */
    pcBuf = (INT8 *)((uintptr_t)(((uintptr_t)image_buf + 0x3) & ~0x3));
    ulReadSize = fread(pcBuf, 1, (size_t)len, pFile);
    if (ulReadSize != len)
    {
        dbgErr("%s>>Read %s Error!\n",__FUNCTION__,pcFileName);
        free(image_buf);
        fclsRet = fclose(pFile);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    fclsRet = fclose(pFile);
    FCLOSE_CHECK(fclsRet);
    dbgInfo("%s>>send data start ! tick %llu, ulReadSize:%d\n",__FUNCTION__,tick64Get(),ulReadSize);
    if (-1==NxpSerialXmdoemSnd(ulchip,(INT8 *)pcBuf, ulReadSize))
    {
        dbgErr("%s>>NxpSerialXmdoemSnd failed !\n",__FUNCTION__);
        free(image_buf);
        return BSP_ERROR;
    }
    dbgInfo("%s>>send data end ! tick %llu \n",__FUNCTION__,tick64Get());
    free(image_buf);
    return BSP_OK;
}
/*********************************************************************/


static UINT32 SemDpdIcLoadInit(VOID)
{
    static UINT8 s_ucSemDpdIcLoadInit = 0;
    
    if (1 == s_ucSemDpdIcLoadInit)
    {
        return BSP_OK;
    }

    DpdIcLoadSem = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (NULL == DpdIcLoadSem)
    {
        dbgErr("%s:semBCreate failed.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    s_ucSemDpdIcLoadInit = 1;
    return BSP_OK;
}
static UINT32 BspGetDpdIcLoadSem(VOID)
{

    if (BSP_OK != SemDpdIcLoadInit())
    {
        return BSP_ERROR;
    }
    semTake(DpdIcLoadSem, WAIT_FOREVER);
    return BSP_OK;
}

static UINT32 BspRlsDpdIcLoadSem(VOID)
{
    semGive(DpdIcLoadSem);
    return BSP_OK;
}

UINT32 g_defHighSpeedBaudrate = NXP_SRIAL_B1562500;
VOID testBspSetBaudrateVal(UINT32 baudRate)
{
	g_defHighSpeedBaudrate = baudRate;
}
/* 判断模块是否初始化 */
UINT32 NxpIsSerialModuleInit(VOID)
{
	return ((gtNxpSerialModuleInitFlag == NXP_SERIAL_MODULE_INIT_OK)?BSP_OK:BSP_ERROR);
}

UINT32 DpdIcLoadModuleInit(T_NXP_SERIAL_APP * ptNxpSerialApp)
{
    UINT32 udRet = BSP_OK;

    INPUT_POINTER_CHECK(ptNxpSerialApp);
    memset(&gtNxpSerialApp, 0, sizeof(T_NXP_SERIAL_APP));

    /* 注册串口驱动接口 */
    gtNxpSerialApp.udSlaveChipNum                          =   ptNxpSerialApp->udSlaveChipNum;                                                         
    gtNxpSerialApp.tNxpSerialDrv.udPortId                  =   ptNxpSerialApp->tNxpSerialDrv.udPortId;
    gtNxpSerialApp.tNxpSerialDrv.udBaudrate                =   ptNxpSerialApp->tNxpSerialDrv.udBaudrate;
    gtNxpSerialApp.tNxpSerialDrv.udMaxBaudrate             =   ptNxpSerialApp->tNxpSerialDrv.udMaxBaudrate;
    gtNxpSerialApp.tNxpSerialDrv.pfNxpSerialInit           =   ptNxpSerialApp->tNxpSerialDrv.pfNxpSerialInit;
    gtNxpSerialApp.tNxpSerialDrv.pfMSTimeDelay             =   ptNxpSerialApp->tNxpSerialDrv.pfMSTimeDelay;
    gtNxpSerialApp.tNxpSerialDrv.pfByteRecv                =   ptNxpSerialApp->tNxpSerialDrv.pfByteRecv;
    gtNxpSerialApp.tNxpSerialDrv.pfByteSend                =   ptNxpSerialApp->tNxpSerialDrv.pfByteSend;
    gtNxpSerialApp.tNxpSerialDrv.pfIsBusy                  =   ptNxpSerialApp->tNxpSerialDrv.pfIsBusy;
    gtNxpSerialApp.tNxpSerialDrv.pfIsRxFifoEmpty           =   ptNxpSerialApp->tNxpSerialDrv.pfIsRxFifoEmpty;
    gtNxpSerialApp.tNxpSerialDrv.pfIsTxFifoFull            =   ptNxpSerialApp->tNxpSerialDrv.pfIsTxFifoFull;
    gtNxpSerialApp.tNxpSerialDrv.pfBaudrateSet             =   NxpSerialBaudrateSet;
    gtNxpSerialApp.tNxpSerialDrv.pfNxpSerialRecvFifoClear  =   NxpSerialRcvFifoClear;

    gtNxpSerialApp.tNxpSlaveDrv.udPortId                   =   ptNxpSerialApp->tNxpSlaveDrv.udPortId;
    gtNxpSerialApp.tNxpSlaveDrv.pfDstPortSwitch            =   ptNxpSerialApp->tNxpSlaveDrv.pfDstPortSwitch;
    gtNxpSerialApp.tNxpSlaveDrv.pfSlaveChipReset           =   ptNxpSerialApp->tNxpSlaveDrv.pfSlaveChipReset;
    gtNxpSerialApp.tNxpSlaveDrv.pfCmdExec                  =   NULL;//NxpSlaveChipCmdExec;
    gtNxpSerialApp.tNxpSlaveDrv.pfSlaveChipRegRead         =   NULL;//MaSlaveChipRegRead;
    gtNxpSerialApp.tNxpSlaveDrv.pfSlaveChipRegWrite        =   NULL;//MaSlaveChipRegWrite;
    gtNxpSerialApp.tNxpSlaveDrv.pfIsSerialCommOk           =   NULL;//MaSlaveChipIsCommOk;
    gtNxpSerialApp.tNxpSlaveDrv.pfXmodemStart              =   NULL;//DpdIcXmodemStart;
    gtNxpSerialApp.tNxpSlaveDrv.pfSlaveDpdIcJump           =   NULL;//MaSlaveChipJump;
    gtNxpSerialApp.tNxpSlaveDrv.pfSerialAttrSet            =   NULL;//NxpSlaveSerialAttrSet;
    	
    gtNxpSerialApp.pfRecv                                  =   BspNxpSerialRcv;//MaSerialRcv;
    gtNxpSerialApp.pfRecvInTime                            =   BspNxpSerialRcvInTime;//MaSerialRcv;

    gtNxpSerialApp.pfSend                                  =   BspNxpSerialSnd;//MaSerialSnd;
    gtNxpSerialApp.pfLoadByXmodem                          =   NxpSendXload;
    gtNxpSerialApp.pfLoadBuffByXmodem                      =   NULL;//MaSendXloadBuff;
    gtNxpSerialApp.pfSetXloadConfig                        =   NULL;//MaDdrInitParamSet;
    gtNxpSerialApp.pfLoadXloadConfig                       =   NULL;//MaDdrInitParamSend;

    gtNxpSerialApp.pfInitTftpParam                         =   ptNxpSerialApp->pfInitTftpParam;
    gtNxpSerialApp.pfLoadTftpParam                         =   NULL;//MaTftpParamSend;
    gtNxpSerialApp.pfStartTftpServer                       =   ptNxpSerialApp->pfStartTftpServer;

    gtNxpSerialModuleInitFlag = NXP_SERIAL_MODULE_INIT_OK;
    return udRet;
}

UINT32 DpdIcXmodemDrvInit(VOID)
{
    T_NXP_SERIAL_APP tNxpSerialApp = {0};

    /* 注册串口驱动 */
    memset(&tNxpSerialApp, 0, sizeof(T_NXP_SERIAL_APP));

    //tNxpSerialApp.udSlaveChipNum                   = BspGetMcsChipNum();
    //tNxpSerialApp.tNxpSerialDrv.udPortId           = 0;
    tNxpSerialApp.tNxpSerialDrv.udBaudrate           = NXP_SRIAL_B115200;
    tNxpSerialApp.tNxpSerialDrv.udMaxBaudrate        = NXP_SRIAL_B1562500;//BspGetMaUartMaxBaurd();//NXP最大支持3686400，此函数可以在规格下调用然后更改最大波特率;
    tNxpSerialApp.tNxpSerialDrv.pfNxpSerialInit      = BspInitNxpSerial;
    tNxpSerialApp.tNxpSerialDrv.pfMSTimeDelay        = BspSysMsDelay_Sys;
    tNxpSerialApp.tNxpSerialDrv.pfByteRecv           = NULL;//BspDpdIcSerialRecvByte;
    tNxpSerialApp.tNxpSerialDrv.pfByteSend           = BspNxpSerialSendByte;
    tNxpSerialApp.tNxpSerialDrv.pfIsBusy             = NULL;//BspMsSerialIsBusy;
    tNxpSerialApp.tNxpSerialDrv.pfIsRxFifoEmpty      = NULL;//BspMsSerialRcvFifoEmpty;
    tNxpSerialApp.tNxpSerialDrv.pfIsTxFifoFull       = NULL;//BspMsSerialTxFifoFull;	
    //tNxpSerialApp.tNxpSlaveDrv.udPortId            = 0;
    tNxpSerialApp.tNxpSlaveDrv.pfDstPortSwitch       = BspSwitchDpdIcUartPort;
    tNxpSerialApp.tNxpSlaveDrv.pfSlaveChipReset      = BspDpdicResetRelease;
    tNxpSerialApp.pfStartTftpServer                  = NULL;//BspMaTftpServerStart;
    tNxpSerialApp.pfInitTftpParam                    = NULL;//BspMaTftpParamInit;

    /* 初始化代理串口模块，注册接口 */
    DpdIcLoadModuleInit(&tNxpSerialApp);
    dbgInfo("%s succ init\n",__FUNCTION__);
    return BSP_OK;
}

/* Dpdic4 加载调用接口 */
UINT32 BspParaLoadDpdIcRamBootVer(UINT32 ulRstType, UINT32 ulLoadChip, UINT32 ulChipNum, UINT32 ulDelay)
{
    UINT32 udRet = BSP_OK;
    UINT32 ulLoadRes = 0;
    UINT32 ulChipCnt = 0;
   
    XMODEM_LOAD_INIT_STATUS_CHECK(gtNxpSerialModuleInitFlag);

    /* 用于加载版本前的预处理操作 */
    if(s_pDpdicXmodemInfo->pFuncPreLoadSoc)
    {
        s_pDpdicXmodemInfo->pFuncPreLoadSoc(ulLoadChip);
    }
    
    dbgInfo("%s>>start,tick = %lld\n",__FUNCTION__,tick64Get());
    /* 初始化串口，设置为默认波特率:115200(nxp侧) */
    dbgInfo("Step 1:set Nxp Uart baudrate to %d...\n", g_defHighSpeedBaudrate);
    udRet = gtNxpSerialApp.tNxpSerialDrv.pfNxpSerialInit(ulLoadChip, g_defHighSpeedBaudrate);
    if (BSP_OK != udRet)
    {
        dbgInfo("%s>NxpSerialDrv Init Error! Ret= 0x%04X\n",__FUNCTION__, udRet);
    }

    BspSetXmdoemMode(0);
    for (ulChipCnt = 0; ulChipCnt < ulChipNum; ulChipCnt++)
    {
        g_DpdIcLoadChip = ulLoadChip;
        /* 切换串口 */
        gtNxpSerialApp.tNxpSlaveDrv.pfDstPortSwitch(ulLoadChip);
        NxpSerialRcvFifoClear(ulLoadChip);
        /* 复位从片*/
        udRet = gtNxpSerialApp.tNxpSlaveDrv.pfSlaveChipReset(ulRstType, ulLoadChip); // BspDpdicChipReset
        if (BSP_OK != udRet)
        {
            SocRstLog(RST_INFO, "%s>>M0 Reset Dpdic%d Fail:%d\n",__FUNCTION__,ulLoadChip,udRet);
            dbgInfo("%s>SlaveChipReset Error! Ret= 0x%04X\n",__FUNCTION__, udRet);
        }

        /* 加载bootstrap,  并跳转执行 */
        dbgInfo("start loading chip %d bootstrap...,tick %llu\n", ulLoadChip, tick64Get());
        udRet = gtNxpSerialApp.pfLoadByXmodem(ulLoadChip, xloadVersionMap[DPDIC_VERSION_RAMBOOT].ucVersionPath);
        if (BSP_OK != udRet)
        {     
            ulLoadRes |= (UINT32)BSP_BIT_SET(ulLoadChip % 31);
            dbgErr("chip %d finish loading bootstrap:failed!!!,tick %llu\n", ulLoadChip, tick64Get());
        }
        else
        {
#if 0       /* 4.2暂时不需要 */       
            SgmiiSetSerdesChnlChkFlag(1, ulLoadChip + 1, 1);
#endif
            dbgInfo("chip %d finish loading bootstrap:ok !!!,tick %llu\n", ulLoadChip, tick64Get());
            BspLog(LOG_LEVEL_0,"chip %d finish loading bootstrap:ok !!!,tick %llu\n", ulLoadChip, tick64Get());
        }
    }
    dbgInfo("%s>>end,LoadRes 0x%x,tick = %llu\n",__FUNCTION__,ulLoadRes,tick64Get());

    /* 重置串口波特率，设置为默认波特率:115200(nxp侧) */
    dbgInfo("Last Step:set Nxp Uart baudrate to %d...\n", NXP_SRIAL_B115200);
    udRet = gtNxpSerialApp.tNxpSerialDrv.pfNxpSerialInit(ulLoadChip, NXP_SRIAL_B115200);
    if (BSP_OK != udRet)
    {
        dbgInfo("%s>NxpSerialDrv Init Error! Ret= 0x%04X\n",__FUNCTION__, udRet);
    }

    /* 用于加载版本后的后处理操作 */
    if(s_pDpdicXmodemInfo->pFuncPostLoadSoc)
    {
        s_pDpdicXmodemInfo->pFuncPostLoadSoc(ulLoadChip);
    }

    return ulLoadRes;
}

/* Dpdic4 加载调用接口 */
UINT32 BspDpdIcM0XmodemLoad(UINT32 ulRstType, UINT32 ulLoadChip, UINT32 ulChipMax, UINT32 ulDelay)
{
    static UINT32 firtRun = 0;
    UINT32 ulRetVal = BSP_ERROR;

    /* 注册串口驱动 */
    if (firtRun == 0)
    {
        DpdIcXmodemDrvInit();
#if 0       /* 4.2暂时不需要 */              
        BspSystem("arp -s 198.33.32.2 40:a0:c8:fe:40:2 dev eth2");
        BspSystem("arp -s 198.33.33.2 40:00:c6:21:21:2 dev eth2");
        BspSystem("arp -s 198.33.32.3 40:a0:c8:fe:40:3 dev eth3");
        BspSystem("arp -s 198.33.33.3 40:00:c6:21:21:3 dev eth3");
#endif
        firtRun = 1;
    }
    BspRecSndErr(255, 0);

    dbgInfo("%s>>XmodemLoad Start! StaTick= %llu\n", __FUNCTION__, tick64Get());
    BspGetDpdIcLoadSem();

    // NR40 M0加载采用串口加载ramboot, 再网口加载bootloader1和bootloader2
    ulRetVal = BspParaLoadDpdIcRamBootVer(ulRstType, ulLoadChip, ulChipMax, ulDelay);
    g_dpdIcLoadStat[ulLoadChip] = ulRetVal;

    BspRlsDpdIcLoadSem();
    dbgInfo("%s>>XmodemLoad End! EndTick= %llu\n", __FUNCTION__, tick64Get());
    return ulRetVal;
}

UINT32 BspLoadDpdIc(UINT32 ulRstType)
{
    UINT32 ulChipIdx = 0;
    UINT32 chipRet = 0;
    UINT32 ulSocMaxNum = 2;
    UINT32 ulRetVal = BSP_OK;
    UINT32 socChipId = 0;

    ulSocMaxNum = BspGetRpuNum(); /* Dpdic Rpu总数 */
    for (ulChipIdx = 0; ulChipIdx < ulSocMaxNum; ulChipIdx++)
    {
        chipRet = BspGetDpdicLoadChipNo(ulChipIdx, &socChipId);
        if (chipRet != BSP_OK)
        {
            socChipId = ulChipIdx;
        }
        ulRetVal |= BspLoadDpdIcByChip(ulRstType, socChipId);
    }

    return ulRetVal;
}

UINT32 BspLoadDpdIcByChip(UINT32 ulRstType, UINT32 ulChip)
{
    UINT32 ulSocMaxNum = 2;
    UINT32 ulRetVal = BSP_OK;
    UINT32 retry = 0;

    ulSocMaxNum = BspGetRpuNum(); /* Dpdic Rpu总数 */
    if (ulChip >= ulSocMaxNum)
    {
        dbgErr("%s>>Error! ChipIdx Over; Idx(0~%d)= %d\n",
               __FUNCTION__, ulSocMaxNum - 1, ulChip);
        return BSP_ERROR;
    }

    /* 从片2退出深度休眠时，概率性UART版本发送失败问题规避 */
    while(retry<5)
    {
        ulRetVal = BspDpdIcM0XmodemLoad(ulRstType, ulChip, 1, 1);
        if(BSP_OK == ulRetVal)
        {
            dbgInfo("%s>>BspDpdIcM0XmodemLoad OK, ulRstType=%d ulChip=%d\n", 
                    __FUNCTION__,ulRstType,ulChip);
            break;
        }
        dbgInfo("%s>>BspDpdIcM0XmodemLoad fail, ulRstType=%d ulChip=%d retry=%d\n", 
                __FUNCTION__,ulRstType,ulChip,retry);
        BspSysMsDelay(100);
        retry++;
    }
    return ulRetVal;
}

UINT32 DpdicGetUpdateFlagFromFlash(UINT32 ulRstType, UINT32 ulSocIdx)
{
    UINT32 ulRetUpdateFlag = BSP_ERROR;
    return ulRetUpdateFlag;
}

// ulSocIdx < 2 -- 单片DpdicVer加载,
// ulSocIdx=255 -- 所有DpdicVer加载
UINT32 BspSocDpdicVerUpdate(UINT32 ulRstType, UINT32 ulSocIdx)
{
    UINT32 ulSocMaxSum  = 0;
    UINT32 ulUpdateFlag = 0;
    UINT32 ulFunRet = BSP_OK;

    //新改版DPDIC从flash启动，其他规格从主片获取
    ulUpdateFlag = DpdicGetUpdateFlagFromFlash(ulRstType, ulSocIdx);
    if (BSP_OK == ulUpdateFlag)
    {
        dbgInfo("%s>>Dpdic boots from flash......\n", __FUNCTION__);
        return BSP_OK;
    }

    if (BSP_OK == BspIsFileExist("/ata/a9631a_test.txt"))
    {
        /* ata目录下上传此TXT文件, 即此文件存在, 不加载DPDIC版本, 用于特殊调试或不带DPDIC芯片的测试环境 */
        dbgInfo("%s>>a9631a_test.txt Exist; Forbid Load DpdicVer!\n", __FUNCTION__);
        return BSP_OK;
    }

    ulSocMaxSum = BspGetRpuNum(); /* Dpdic Rpu总数 BspGetRpuNum()*/ 
    if (ulSocIdx >= DPDIC_SOC_MAX_NUM) // if ((0 == ulSocMaxSum) || (ulSocMaxSum > 2))
    {
        dbgErr("%s>>Error! SocMaxSum Over; SocSum(1~%d)= %d\n",
               __FUNCTION__, DPDIC_SOC_MAX_NUM, ulSocMaxSum);
        return BSP_ERROR;
    }

    dbgInfo("%s>>Soc(Sum'%d Idx'%d) DpdicVer Load......\n", __FUNCTION__, ulSocMaxSum, ulSocIdx);
    if (ulSocIdx < ulSocMaxSum)
    {
        ulFunRet = BspLoadDpdIcByChip(ulRstType, ulSocIdx);
    }
    else
    {
        ulFunRet = BspLoadDpdIc(ulRstType);
    }
    dbgInfo("%s>>Soc(Sum'%d Idx'%d) DpdicVer Load Finish\n", __FUNCTION__, ulSocMaxSum, ulSocIdx);

    return ulFunRet;
}

UINT32 BspSetDpdicRegByM0Uart(UINT32 ulChipIdx, UINT32 ulAddr, UINT32 ulData)
{
    INT32  lSnpRet  = 0;
    UINT32 ulRetVal = BSP_OK;
    UINT8  aucCmdData[32] = {0, };

    lSnpRet = snprintf_s((CHAR *)aucCmdData, sizeof(aucCmdData), "mm %08x %04x", ulAddr, ulData);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(aucCmdData));

    ulRetVal = BspNxpSerialSnd(ulChipIdx, aucCmdData, sizeof(aucCmdData));
    if (BSP_OK == ulRetVal)
    {
        dbgInfoEx("%s>>Chip'%d: [%s] SerialSend Succ!\n", __FUNCTION__, ulChipIdx, aucCmdData);
    }
    else
    {
        dbgErr("%s>>Chip'%d: [%s] SerialSend Error!\n", __FUNCTION__, ulChipIdx, aucCmdData);
    }

    return ulRetVal;
}

UINT32 BspGetDpdicRegByM0Uart(UINT32 ulChipIdx, UINT32 ulAddr, UINT32 *pulData)
{
    INT32  lSnpRet   = 0;
    UINT32 ulRetVal  = BSP_OK;
    UINT8  aucCmdData[32] = {0,};
    INT8   acRecvData[32] = {0,}; 

    lSnpRet = snprintf_s((CHAR *)aucCmdData, sizeof(aucCmdData), "md %08x", ulAddr);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(aucCmdData));

    ulRetVal = BspNxpSerialSnd(ulChipIdx, aucCmdData, sizeof(aucCmdData));
    if (BSP_OK != ulRetVal)
    {
        dbgErr("%s>>Chip'%d: [%s] SerialSend Error!\n", __FUNCTION__, ulChipIdx, aucCmdData);
    }

    /* ####### 经过验证, 无法获取到正常的寄存器值 ########*/
    BspNxpSerialRcvChar(ulChipIdx, &(acRecvData[0]));
    BspNxpSerialRcvChar(ulChipIdx, &(acRecvData[1]));

    if (NULL != pulData)
    {
        *pulData  = (UINT32)(acRecvData[1] & 0x7FFFFFFF) << 8;
        *pulData |= (UINT32)(acRecvData[0] & 0x7FFFFFFF) << 0;
    //  *pulData = (UINT32)((acRecvData[1] << 8) | acRecvData[0]);
        dbgInfo("%s>>Chip'%d: [%s] SerialRecv'0x%04X Succ!\n", __FUNCTION__,
               ulChipIdx, aucCmdData, *pulData);
    }

    return ulRetVal;
}

VOID showErrReasonTbl(VOID)
{
    //XmdoemSndErr状态值 | 英文解释 | 对应接口
    dbgInfo("XmdoemSndErr:1>>>No Achieve Char C         >>>BspCheckLoadStart\n");
    dbgInfo("XmdoemSndErr:2>>>Reply AckId Return Error  >>>XmdoemSndData\n");
    dbgInfo("XmdoemSndErr:4>>>XMODEM_NAK No Response    >>>XmdoemSndData\n");
    dbgInfo("XmdoemSndErr:8>>>NAK Retry Overtime        >>>XmdoemSndData\n");
    dbgInfo("XmdoemSndErr:16>>>Reply AckId End Overtime >>>BspRepyAckEnd\n");
    dbgInfo("DpdIc0LoadStat:1>>>Ic0 RamBoot0 Load Fail  >>>BspParaLoadDpdIcRamBootVer\n");
    dbgInfo("DpdIc0LoadStat:2>>>Ic1 RamBoot0 Load Fail  >>>BspParaLoadDpdIcRamBootVer\n");
    dbgInfo("查询log日志>>>日志文件ata/socrstlog>>>搜索关键词M0\n");
}

UINT32 prnloadsta(VOID)
{
    UINT32 ulChipNo = 0;
    UINT32 ulSocMaxSum = BspGetRpuNum(); /* Dpdic Rpu总数 BspGetRpuNum() */
    dbgInfo("DpdIc0 Load status 0x%x, DpdIc1 Load status 0x%x\n",g_dpdIcLoadStat[0],g_dpdIcLoadStat[1]);
    for(ulChipNo=0;ulChipNo<ulSocMaxSum;ulChipNo++)
    {
        dbgInfo("DpdIc %d,Data Send Err 0x%x\n",ulChipNo,g_XmdoemSndErr[ulChipNo]);
    }
    dbgInfo("*********************show Err Reason Query*********************\n");
    showErrReasonTbl();
    return BSP_OK;
}

UINT32 BspDpdIcXmodemInfoInit(T_DPDIC_XMODEM_INFO *pXmodemInfo)
{
    s_pDpdicXmodemInfo = pXmodemInfo;
    memcpy_s(s_NxpComPortName, sizeof(s_NxpComPortName), pXmodemInfo->pNxpComPortName, sizeof(pXmodemInfo->pNxpComPortName));
    memcpy_s(s_dpdicSocComPortIdx, sizeof(s_dpdicSocComPortIdx), pXmodemInfo->dpdicSocComPortIdx, sizeof(pXmodemInfo->dpdicSocComPortIdx));
    memcpy_s(s_dpdicSocUartIdx, sizeof(s_dpdicSocUartIdx), pXmodemInfo->dpdicSocUartIdx, sizeof(pXmodemInfo->dpdicSocUartIdx));

    return BSP_OK;
}




#include "bsppub.h"

UINT32 BspGetCpuType(UINT8 *cpuType)
{
    *cpuType = BSP_ZX211413; 

    return BSP_OK;
}

#include <string.h>
#include <time.h>
#include <math.h>
#include "vxadp.h"
#include "list.h"
#include "exprn.h"
#include "systemcallapi.h"
#include "funccommon_a.h"
#include "boardsocmsg.h"
#include "elf_symbol.h"
#include "msgproc.h"
#include "boardhardid.h"
/***********************************************************************************/
#define FILE_SAVE_STDIO   "/UdpCmd"
INT32 CMD_flag_print = 1;

#define IPC_SOCKET_LENTH 256


#define UDP_SHELL_COMMD_RESULT              0x1000
#define UDP_SHELL_COMMD_SUCCESS             (UDP_SHELL_COMMD_RESULT + 0x01)
#define UDP_SHELL_COMMD_MSG_ERROR           (UDP_SHELL_COMMD_RESULT + 0x02)
#define UDP_SHELL_COMMD_FUN_UNKNOW          (UDP_SHELL_COMMD_RESULT + 0x03)
#define UDP_SHELL_COMMD_OPEN_FILE_ERROR     (UDP_SHELL_COMMD_RESULT + 0x04)
#define UDP_SHELL_COMMD_RD_FILE_ERROR       (UDP_SHELL_COMMD_RESULT + 0x05)
#define UDP_SHELL_COMMD_REDIRECT_ERROR      (UDP_SHELL_COMMD_RESULT + 0x06)

/*************************************************************************************/
FUNC_GET_CLK_STA    pFuncGetClkSta = NULL;
T_UdpMsgQueryIdAck  S_tUdpMsgBrdBomidInfo = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0xffff};

UINT32 SocMsgSetBoardBomidInfo(T_UdpMsgQueryIdAck *ptBomidInfo)
{
    if (NULL == ptBomidInfo)
    {
        dbgErr("%s>>Error! pBomidInfo cannot NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    S_tUdpMsgBrdBomidInfo.state            = ptBomidInfo->state;
    S_tUdpMsgBrdBomidInfo.ModuleGroupId    = ptBomidInfo->ModuleGroupId;
    S_tUdpMsgBrdBomidInfo.BoardGroupId     = ptBomidInfo->BoardGroupId;
    S_tUdpMsgBrdBomidInfo.BoardTypeId      = ptBomidInfo->BoardTypeId;
    S_tUdpMsgBrdBomidInfo.HardwareChangeId = ptBomidInfo->HardwareChangeId;
    S_tUdpMsgBrdBomidInfo.HwCustomIdA      = ptBomidInfo->HwCustomIdA;
    S_tUdpMsgBrdBomidInfo.HwCustomIdB      = ptBomidInfo->HwCustomIdB;
    S_tUdpMsgBrdBomidInfo.HwMagicNum       = ptBomidInfo->HwMagicNum;
    S_tUdpMsgBrdBomidInfo.BrdBomidCrc      = ptBomidInfo->BrdBomidCrc;
    S_tUdpMsgBrdBomidInfo.ProtocolType     = ptBomidInfo->ProtocolType;

    return BSP_OK;
}

UINT32 SocMsgGetBoardBomidInfo(T_UdpMsgQueryIdAck *ptBomidInfo)
{
    UINT32 ulRetVal = BSP_OK;

    if (NULL == ptBomidInfo)
    {
        ulRetVal = BSP_ERROR;
        dbgErr("%s>>Error! pBomidInfo cannot NULL!\n", __FUNCTION__);
        return ulRetVal;
    }

    ptBomidInfo->state            = S_tUdpMsgBrdBomidInfo.state;
    ptBomidInfo->ModuleGroupId    = S_tUdpMsgBrdBomidInfo.ModuleGroupId;
    ptBomidInfo->BoardGroupId     = S_tUdpMsgBrdBomidInfo.BoardGroupId;
    ptBomidInfo->BoardTypeId      = S_tUdpMsgBrdBomidInfo.BoardTypeId;
    ptBomidInfo->HardwareChangeId = S_tUdpMsgBrdBomidInfo.HardwareChangeId;
    ptBomidInfo->HwCustomIdA      = S_tUdpMsgBrdBomidInfo.HwCustomIdA;
    ptBomidInfo->HwCustomIdB      = S_tUdpMsgBrdBomidInfo.HwCustomIdB;
    ptBomidInfo->HwMagicNum       = S_tUdpMsgBrdBomidInfo.HwMagicNum;
    ptBomidInfo->BrdBomidCrc      = S_tUdpMsgBrdBomidInfo.BrdBomidCrc;
    ptBomidInfo->ProtocolType     = S_tUdpMsgBrdBomidInfo.ProtocolType;

    return ulRetVal;
}


/*****************************************************************************
*  函数名称   : BspSetSocMsgBomidInfo
*  功能描述   : 主片将Bomid信息写入SocMsg模块，供从片通过UPD消息获取
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增
*----------------------------------------------------------------------------
*/
UINT32 BspSetSocMsgBomidInfo(VOID)
{
    UINT32 retVal = BSP_OK;
    T_UdpMsgQueryIdAck tSocMsgBomidInfo = {0};

    tSocMsgBomidInfo.state            = UDP_SOCMSG_BOMID_NEW_CFG_FLAG;
    tSocMsgBomidInfo.ModuleGroupId    = BspGetModuleGroupId();
    tSocMsgBomidInfo.BoardGroupId     = BspGetBoardGroupId();
    tSocMsgBomidInfo.BoardTypeId      = BspGetBoardTypeId();
    tSocMsgBomidInfo.HardwareChangeId = BspGetHardwareChangeId();
    tSocMsgBomidInfo.HwCustomIdA      = BspGetHardwareCustomId_A();
    tSocMsgBomidInfo.HwCustomIdB      = BspGetHardwareCustomId_B();
    tSocMsgBomidInfo.HwMagicNum       = BspGetHardwareMagicNum();
    tSocMsgBomidInfo.BrdBomidCrc      = BspGetBoardBomidCrcVal();
    tSocMsgBomidInfo.ProtocolType     = BspGetPbOrBbuMode();
    
    retVal |= SocMsgSetBoardBomidInfo(&tSocMsgBomidInfo);
	
    return retVal;
}

UINT32 DbgSocMsgGetBoardBomidInfo(VOID)
{
    UINT32 ulRetVal = BSP_OK;
    T_UdpMsgQueryIdAck tBrdBomidInfo = {0xFFFF, };

    ulRetVal = SocMsgGetBoardBomidInfo(&tBrdBomidInfo);

    dbgInfo("%s>>State'(0x%04X 0x%04X): BomId: 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X 0x%04X ProtocolType:0x%04X\n",
            __FUNCTION__, UDP_SOCMSG_BOMID_NEW_CFG_FLAG, tBrdBomidInfo.state,
            tBrdBomidInfo.ModuleGroupId, tBrdBomidInfo.BoardGroupId,
            tBrdBomidInfo.BoardTypeId,   tBrdBomidInfo.HardwareChangeId,
            tBrdBomidInfo.HwCustomIdA,   tBrdBomidInfo.HwCustomIdB,
            tBrdBomidInfo.HwMagicNum,    tBrdBomidInfo.BrdBomidCrc,
            tBrdBomidInfo.ProtocolType);

    return ulRetVal;
}

UINT32 SocMsgQueryId(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8 ulChnlNo,UINT8 ulFreqBandNo,UINT8* pbuff,UINT32 len)
{
    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;

    UINT32 retVal = BSP_OK;

    UINT8  *pucApiBuff = NULL;
    TSocApiPDU *send = NULL;
    TSocApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(TSocApiPDU) + sizeof(TSocApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TSocApiPDU) + sizeof(TSocApiPDU));

    send = (TSocApiPDU *)&pucApiBuff[0];
    recv = (TSocApiPDU *)&pucApiBuff[sizeof(TSocApiPDU)];

    msgType = MSG_TYPE_QUERY_ID;
    ulMsgLen  = sizeof(T_UdpMsgQueryId);

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = htons(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = htons(ulMsgLen);
    send->head.chan    = (UINT8)ulChnlNo;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = srcId;
    send->head.dstId    = dstId;
    send->head.typeId    = typeId;
    send->head.recvEn    = MSG_REQ;
#ifndef _4C_VDE_TEST_
    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }
#endif
    dbgInfo("%s:state=%x\n",__FUNCTION__,recv->msg.tQueryIdAck.state);

    if(recv->msg.tQueryIdAck.state!=0)
    {
        retVal = BSP_ERROR;
    }
    memcpy_s(pbuff, len, recv->msg.buf, len);
    free(pucApiBuff);
    //MsgResultProc(retVal);
    return retVal;
}

UINT32 SocMsgQueryRadioMode(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8 ulChnlNo,UINT8 ulFreqBandNo,T_UdpMsgQueryRadioAck* pbuff,UINT32 len)
{
    UINT16 ulMsgLen  = 0;
    UINT16 msgType = 0;
    UINT32 retVal = BSP_OK;

    TSocApiPDU *send = NULL;
    TSocApiPDU *recv = NULL;
    T_UdpMsgQueryRadioAck tQueryRadioModeAck;

    send = (TSocApiPDU *)malloc(sizeof(TSocApiPDU));
    if (NULL == send)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    
    recv = (TSocApiPDU *)malloc(sizeof(TSocApiPDU));    
    if (NULL == recv)
    {
        free(send);
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)send, 0, sizeof(TSocApiPDU));
    memset((VOID *)recv, 0, sizeof(TSocApiPDU));

    msgType = MSG_TYPE_QUERY_RADIOMODE;
    ulMsgLen  = sizeof(T_UdpMsgQueryRadio)&0xffff;

    send->lenAPDU      = ((sizeof(send->head)&0xffff) + ulMsgLen);
    send->head.msgType = htons(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = htons(ulMsgLen);
    send->head.chan    = ulChnlNo;
    send->head.band    = ulFreqBandNo;

    send->head.srcId    = srcId;
    send->head.dstId    = dstId;
    send->head.typeId    = (typeId&0xff);
    send->head.recvEn    = MSG_REQ;
#ifndef _4C_VDE_TEST_
    if (BSP_OK != BspUdpMsgProc(typeId, (VOID*)send, (VOID*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }
#endif
    tQueryRadioModeAck = recv->msg.tQueryRadioAck;

    dbgInfo("%s:state=%x\n",__FUNCTION__,tQueryRadioModeAck.state);

    if(tQueryRadioModeAck.state!=0)
    {
        retVal = BSP_ERROR;
    }
    
    tQueryRadioModeAck.RadioMode = ntohl(tQueryRadioModeAck.RadioMode);
    *pbuff = tQueryRadioModeAck;
    
    free(send);
    free(recv);
    return retVal;
}

UINT32 SocMsgQueryTime(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8 ulChnlNo,UINT8 ulFreqBandNo,UINT8* pbuff,UINT32 len)
{
    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;

    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pbuff);

    UINT8  *pucApiBuff = NULL;
    TSocApiPDU *send = NULL;
    TSocApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(TSocApiPDU) + sizeof(TSocApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TSocApiPDU) + sizeof(TSocApiPDU));

    send = (TSocApiPDU *)&pucApiBuff[0];
    recv = (TSocApiPDU *)&pucApiBuff[sizeof(TSocApiPDU)];

    msgType = MSG_TYPE_QUERY_TIME;
    ulMsgLen  = sizeof(T_UdpMsgQueryTimeAck);

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = htons(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = htons(ulMsgLen);
    send->head.chan    = (UINT8)ulChnlNo;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId    = srcId;
    send->head.dstId    = dstId;
    send->head.typeId    = typeId;
    send->head.recvEn    = MSG_REQ;
#ifndef _4C_VDE_TEST_
    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }
#endif
    dbgInfo("%s:state=%x\n",__FUNCTION__,recv->msg.tQueryTimeAck.state);

    if(recv->msg.tQueryTimeAck.state!=0)
    {
        retVal = BSP_ERROR;
        dbgErr("%s tQueryTimeAck state error\n", __FUNCTION__);
    }
    if((len < 16360) && (len > 0) )
    {
        memcpy(pbuff,recv->msg.buf,len);
    }
    else
    {
        dbgErr("%s len error\n", __FUNCTION__);
    }
        
    free(pucApiBuff);
    //MsgResultProc(retVal);
    return retVal;
}


UINT32 SocMsgRecvAck(UINT32 typeId,UINT32 msgType,UINT8 srcId,UINT8  dstId,
		UINT8 ulChnlNo,UINT8 ulFreqBandNo,UINT8* pbuff,UINT32 len)
{
    UINT32 ulMsgLen  = 0;
    UINT32 retVal = BSP_OK;

    UINT8  *pucApiBuff = NULL;
    TSocApiPDU *send = NULL;
    TSocApiPDU *recv = NULL;

    pucApiBuff = (UINT8 *)malloc(sizeof(TSocApiPDU) + sizeof(TSocApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TSocApiPDU) + sizeof(TSocApiPDU));

    send = (TSocApiPDU *)&pucApiBuff[0];
    recv = (TSocApiPDU *)&pucApiBuff[sizeof(TSocApiPDU)];

    ulMsgLen  = len;
    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = htons(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = htons(ulMsgLen);
    send->head.chan    = (UINT8)ulChnlNo;
    send->head.band    = (UINT8)ulFreqBandNo;

    send->head.srcId   = srcId;
    send->head.dstId   = dstId;
    send->head.typeId  = typeId;
    send->head.recvEn  = MSG_ACK;
    memcpy_s(send->msg.buf,len,pbuff,len);
#ifndef _4C_VDE_TEST_	
    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }
#endif
    free(pucApiBuff);
    //MsgResultProc(retVal);
    return retVal;
}

UINT32 BspQueryIdProc(UINT32 typeId, UINT8 *Buf, UINT32 buflen)
{
    UINT8  srcId;
    UINT8  dstId;
    UINT8  ulChnlNo = 0;
    UINT8  ulFreqBandNo = 0;
    UINT32 ModuleGroupId;
    UINT32 BoardGroupId;
    UINT32 BoardTypeId;
    UINT32 HwChangeId;
    UINT32 msgType = MSG_TYPE_QUERY_ID;
    TUdpApiHeader *ptUdpMsgHead = (TUdpApiHeader *)Buf;
    T_UdpMsgQueryIdAck tBrdBomidInfo = {0xFFFF, };
    T_UdpMsgQueryIdAck tUdpMsgQueryIdAck ={0};

    /* tBrdBomidInfo.state用于新旧Bomid方案传送的判断 */
    SocMsgGetBoardBomidInfo(&tBrdBomidInfo);

    if (UDP_SOCMSG_BOMID_NEW_CFG_FLAG == tBrdBomidInfo.state)
    {
        srcId         = ptUdpMsgHead->dstId;
        dstId         = ptUdpMsgHead->srcId;

        tUdpMsgQueryIdAck.state            = 0;
        tUdpMsgQueryIdAck.ModuleGroupId    = htonl(tBrdBomidInfo.ModuleGroupId);
        tUdpMsgQueryIdAck.BoardGroupId     = htonl(tBrdBomidInfo.BoardGroupId);
        tUdpMsgQueryIdAck.BoardTypeId      = htonl(tBrdBomidInfo.BoardTypeId);
        tUdpMsgQueryIdAck.HardwareChangeId = htonl(tBrdBomidInfo.HardwareChangeId);
        tUdpMsgQueryIdAck.HwCustomIdA      = htonl(tBrdBomidInfo.HwCustomIdA);
        tUdpMsgQueryIdAck.HwCustomIdB      = htonl(tBrdBomidInfo.HwCustomIdB);
        tUdpMsgQueryIdAck.HwMagicNum       = htonl(tBrdBomidInfo.HwMagicNum);
        tUdpMsgQueryIdAck.BrdBomidCrc      = htonl(tBrdBomidInfo.BrdBomidCrc);
        tUdpMsgQueryIdAck.ProtocolType     = htonl(tBrdBomidInfo.ProtocolType);
    }
    else
    {
        srcId         = ptUdpMsgHead->dstId;
        dstId         = ptUdpMsgHead->srcId;

        ModuleGroupId = BspGetModuleGroupIdPara();
        BoardGroupId  = BspGetBoardGroupIdPara();
        BoardTypeId   = BspGetBoardTypeIdPara();
        HwChangeId    = BspGetHardwareChangeIdPara();

        tUdpMsgQueryIdAck.state            = 0;
        tUdpMsgQueryIdAck.ModuleGroupId    = htonl(ModuleGroupId);
        tUdpMsgQueryIdAck.BoardGroupId     = htonl(BoardGroupId);
        tUdpMsgQueryIdAck.BoardTypeId      = htonl(BoardTypeId);
        tUdpMsgQueryIdAck.HardwareChangeId = htonl(HwChangeId);
        tUdpMsgQueryIdAck.ProtocolType     = htonl(tBrdBomidInfo.ProtocolType);
    }
	return SocMsgRecvAck(typeId, msgType, srcId, dstId, ulChnlNo, ulFreqBandNo,
			             (UINT8 *)&tUdpMsgQueryIdAck, sizeof(T_UdpMsgQueryIdAck));
}

UINT32 BspQueryTimeProc(UINT32 typeId,UINT8 *Buf, UINT32 buflen)
{
    UINT32	msgType = MSG_TYPE_QUERY_TIME;
    UINT8	srcId;
    UINT8	dstId;
    TUdpApiHeader *ptUdpMsgHead = (TUdpApiHeader *)Buf;
    T_UdpMsgQueryTimeAck  tUdpMsgQueryTimeAck={0};

    srcId = ptUdpMsgHead->dstId;
    dstId = ptUdpMsgHead->srcId;

    //tUdpMsgQueryTimeAck.seconds = (time_t)htonl((UINT32)time((time_t *)NULL));   /*此消息目前没有实际使用*/
    tUdpMsgQueryTimeAck.seconds = 0;
    tUdpMsgQueryTimeAck.state   = 0;
    return SocMsgRecvAck(typeId,msgType,srcId, dstId,0,
    	0,(UINT8 *)&tUdpMsgQueryTimeAck,sizeof(T_UdpMsgQueryTimeAck));
}

UINT32 BspQueryRadioModeProc(UINT32 typeId,UINT8 *Buf, UINT32 buflen)
{
    UINT32	msgType = MSG_TYPE_QUERY_RADIOMODE;
    UINT8	srcId;
    UINT8	dstId;
    UINT8	ulChnlNo = 0;
    UINT8	ulFreqBandNo = 0;
    UINT32  radioMode;
    UINT32  len = (UINT32)sizeof(T_UdpMsgQueryRadioAck);
    
    TUdpApiHeader *ptUdpMsgHead = (TUdpApiHeader *)((VOID*)Buf);
    T_UdpMsgQueryRadioAck tUdpMsgQueryRadioAck={0};
    
    srcId = ptUdpMsgHead->dstId;
    dstId = ptUdpMsgHead->srcId;
    
    radioMode = BspGetRadioStandard();
    
    tUdpMsgQueryRadioAck.RadioMode = ((radioMode&0xff)<<24)|((radioMode&0xff00)<<8)|((radioMode&0xff0000)>>8)|((radioMode&0xff000000)>>24);    
    tUdpMsgQueryRadioAck.state = 0;

    return SocMsgRecvAck(typeId,msgType,srcId, dstId,ulChnlNo,
    		ulFreqBandNo,(VOID*)&tUdpMsgQueryRadioAck,len);
}
	
T_MsgSocCommandAck g_msgAck = {0};

UINT32 BspSoccmdProc(UINT32 typeId,UINT8 *Buf, UINT32 buflen)
{
    UINT32	msgType = MSG_TYPE_SOC_CMD;
    UINT8	srcId;
    UINT8	dstId;
    /* int i; */


    TUdpApiHeader *ptUdpMsgHead = (TUdpApiHeader *)Buf;
    UINT32 loop = 0;

    srcId = ptUdpMsgHead->dstId;
    dstId = ptUdpMsgHead->srcId;

    memset(&g_msgAck,0,sizeof(T_MsgSocCommandAck));
    g_msgAck.cmdRet = -1;
    BspParaseUdpShellCmd(Buf + sizeof(TUdpApiHeader),buflen - sizeof(TUdpApiHeader),&g_msgAck);
    
    g_msgAck.ulmask = htonl(g_msgAck.ulmask);
    g_msgAck.cmdRet = htonl(g_msgAck.cmdRet);
    g_msgAck.cmdErrReason = htonl(g_msgAck.cmdErrReason);

    for(loop=0;loop<CMD_PARA_NUM;loop++)
    {
        g_msgAck.ulFuncParams[loop] = htonl(g_msgAck.ulFuncParams[loop]);
    }

    return SocMsgRecvAck(typeId,msgType,srcId, dstId,0,
        0,(UINT8 *)&g_msgAck,sizeof(T_MsgSocCommandAck));

}

UINT32 BspQueryClkStatusCallbackInit(FUNC_GET_CLK_STA pFunc)
{
    pFuncGetClkSta = pFunc;
    return BSP_OK;
}

UINT32 BspQueryClkStatusProc(UINT32 typeId,UINT8 *Buf,UINT32 buflen)
{
    UINT32 msgType = MSG_TYPE_QUERY_CLK;
    UINT8 srcId = 0;
    UINT8 dstId = 0;
    T_UdpMsgQueryClk *pReq = NULL;
    T_UdpMsgQueryClkAck clkAck = {0};

    INPUT_POINTER_CHECK(Buf);
    TUdpApiHeader *ptUdpMsgHead = (TUdpApiHeader *)Buf;
    srcId = ptUdpMsgHead->dstId;
    dstId = ptUdpMsgHead->srcId;

    if (buflen < sizeof(TUdpApiHeader)+sizeof(T_UdpMsgQueryClk))
    {
        clkAck.clkEnable = 0;
    }
    else
    {
        pReq = (T_UdpMsgQueryClk *)(Buf + sizeof(TUdpApiHeader));
        if (pFuncGetClkSta)
        {
            pFuncGetClkSta(dstId,pReq,&clkAck);
        }
        else
        {
            clkAck.clkEnable = 0;
        }
    }
 
    return SocMsgRecvAck(typeId,msgType,srcId,dstId,0,0,(UINT8 *)&clkAck,sizeof(T_UdpMsgQueryClkAck));
}
//dpdic从板调用
UINT32 BspQueryClkStatus(UINT32 typeId,UINT8 srcId,UINT8 dstId,T_UdpMsgQueryClk *sBuf,UINT32 slen,T_UdpMsgQueryClkAck* rBuf,UINT32 rlen)
{
    UINT16 ulMsgLen  = 0;
    UINT16 msgType = 0;
    UINT32 retVal = BSP_OK;

    TSocApiPDU *send = NULL;
    TSocApiPDU *recv = NULL;

    /* T_UdpMsgQueryClk    tQueryClk    = {0}; */
    /* T_UdpMsgQueryClkAck tQueryClkAck = {0}; */

    INPUT_POINTER_CHECK(sBuf);
    INPUT_POINTER_CHECK(rBuf);

    send = (TSocApiPDU *)malloc(sizeof(TSocApiPDU));
    if (NULL == send)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    
    recv = (TSocApiPDU *)malloc(sizeof(TSocApiPDU));    
    if (NULL == recv)
    {
        free(send);
        retVal |= BIT_SET(1);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)send, 0, sizeof(TSocApiPDU));
    memset((VOID *)recv, 0, sizeof(TSocApiPDU));

    msgType = MSG_TYPE_QUERY_CLK;
    ulMsgLen  = sizeof(T_UdpMsgQueryClk);

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = htons(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = htons(ulMsgLen);
    send->head.chan    = 0;
    send->head.band    = 0;

    send->head.srcId    = srcId;
    send->head.dstId    = dstId;
    send->head.typeId    = (typeId&0xff);
    send->head.recvEn    = MSG_REQ;
    dbgInfo("%s:[0]lenAPDU=%d,ulMsgLen=%d\n",__FUNCTION__,send->lenAPDU,ulMsgLen);
    memcpy((void*)(&send->msg.buf),(void*)sBuf,sizeof(T_UdpMsgQueryClk));
    dbgInfo("%s:[1]lenAPDU=%d,ulMsgLen=%d\n",__FUNCTION__,send->lenAPDU,ulMsgLen);
#ifndef _4C_VDE_TEST_
    if (BSP_OK != BspUdpMsgProc(typeId, (VOID*)send, (VOID*)recv))
    {
        retVal |= BIT_SET(2);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }
#endif
    memcpy((void*)(rBuf),(void*)&recv->msg.buf,sizeof(T_UdpMsgQueryClkAck));
    
    free(send);
    free(recv);
    return retVal;
}

/*从片从主片获取时钟锁定和主光口识别状态*/
UINT32 BspGetSysPllStatusFromMain(UINT8 *pLdSta, UINT8 *pMainOpt,UINT8 *pCpriSwRec)
{
    UINT8 slaverId = 2;  /*从片198.33.33.2*/
    UINT8 masterId = 100; /*主片198.33.33.100*/
    UINT32 retVal = 0;
    UINT32 chipId = 0;
    UINT32 typeId = HEAD_TYPE_ID_NXP_SOC;
    T_UdpMsgQueryClkAck tUdpMsgQueryClkAck = {0};
    T_UdpMsgQueryClk tUdpMsgQueryClk = {0};
    UINT32 loopIndex = 0;
    UINT32 maxTry = 3;   /*最多尝试三次*/

    INPUT_POINTER_CHECK(pLdSta);
    INPUT_POINTER_CHECK(pMainOpt);
    INPUT_POINTER_CHECK(pCpriSwRec);
    chipId = BspGetRpuId();
    slaverId += (chipId&0xff);
    for(loopIndex = 0; loopIndex < maxTry; loopIndex++)
    {
        retVal = BspQueryClkStatus(typeId,slaverId,masterId,&tUdpMsgQueryClk,sizeof(T_UdpMsgQueryClk),&tUdpMsgQueryClkAck,sizeof(T_UdpMsgQueryClkAck));
        if(BSP_OK == retVal)
        {
            dbgInfoEx("clk %d mainopt %d CpriSwRec %d\n",tUdpMsgQueryClkAck.clklock,tUdpMsgQueryClkAck.reserve,tUdpMsgQueryClkAck.clksource);
            *pLdSta = tUdpMsgQueryClkAck.clklock;
            *pMainOpt = tUdpMsgQueryClkAck.reserve;
            *pCpriSwRec = tUdpMsgQueryClkAck.clksource;
            break;
        }
    }
    if(loopIndex == maxTry)  /*主从消息不通*/
    {
        dbgErr("get Clk Status failed\n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

void getpllsta(void)
{
    UINT8 pllSta = 0;
    UINT8 mainOpt = 0xFF;
    UINT8 cpriSwRec = 0;
    UINT32 retVal = BSP_OK;
    retVal = BspGetSysPllStatusFromMain(&pllSta,&mainOpt,&cpriSwRec);
    dbgInfo("retVal %d pllSta %d mainOpt %d cpriSwRec %d\n",retVal,pllSta,mainOpt, cpriSwRec);
}

extern UINT32 BspQueryIdProc(UINT32 typeId,UINT8 *Buf, UINT32 buflen);

static T_UdpMsgQueryUnit tUdpMsgQueryUnit[]=
{
    {MSG_TYPE_QUERY_ID,                  BspQueryIdProc},
    {MSG_TYPE_SOC_CMD,                   BspSoccmdProc},
    {MSG_TYPE_QUERY_TIME,                BspQueryTimeProc},
    {MSG_TYPE_QUERY_RADIOMODE,           BspQueryRadioModeProc},
    {MSG_TYPE_QUERY_CLK,                 BspQueryClkStatusProc},
};

UINT32 BspUdpMsgQueryParaInit(VOID)
{
    return BspSetUdpMsgQueryUnitPara(tUdpMsgQueryUnit, NELEMENTS(tUdpMsgQueryUnit));
}

UINT8 gnxpid=100;
UINT8 gicid=5;
static void setnxpid(UINT8 nxpid)
{
	gnxpid= nxpid;
}
static void seticid(UINT8 icid)
{
	gicid= icid;
}
static void getid()
{
	T_UdpMsgQueryIdAck tUdpMsgQueryIdAck;
	SocMsgQueryId(HEAD_TYPE_ID_NXP_SOC, gicid, gnxpid,0,0,(UINT8 *)&tUdpMsgQueryIdAck,sizeof(T_UdpMsgQueryIdAck));
	dbgInfo("state %d:%d,%d,%d,%d  ProtocolType:0x%04X\n",tUdpMsgQueryIdAck.state,
			tUdpMsgQueryIdAck.ModuleGroupId,
			tUdpMsgQueryIdAck.BoardGroupId,
			tUdpMsgQueryIdAck.BoardTypeId,
			tUdpMsgQueryIdAck.HardwareChangeId,
            ntohl(tUdpMsgQueryIdAck.ProtocolType));
}




UINT32 SocMsgCmd(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8* pbuff,UINT32 len,UINT8* cmd,UINT32 cmdLen)
{
    UINT32 ulMsgLen  = 0;
    UINT32 msgType = 0;

    UINT32 retVal = BSP_OK;

    UINT8  *pucApiBuff = NULL;
    TSocApiPDU *send = NULL;
    TSocApiPDU *recv = NULL;
    /* int i; */

    pucApiBuff = (UINT8 *)malloc(sizeof(TSocApiPDU) + sizeof(TSocApiPDU));
    if (NULL == pucApiBuff)
    {
        retVal |= BIT_SET(0);
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return retVal;
    }
    memset((VOID *)pucApiBuff, 0, sizeof(TSocApiPDU) + sizeof(TSocApiPDU));

    send = (TSocApiPDU *)&pucApiBuff[0];
    recv = (TSocApiPDU *)&pucApiBuff[sizeof(TSocApiPDU)];

    msgType = MSG_TYPE_SOC_CMD;
    ulMsgLen  = sizeof(T_CmdParam);

    send->lenAPDU      = sizeof(send->head) + ulMsgLen;
    send->head.msgType = htons(msgType);
    send->head.numAPDU = 0;
    send->head.msgLen  = htons(ulMsgLen);
    send->head.chan    = (UINT8)0;
    send->head.band    = (UINT8)0;

    send->head.srcId    = srcId;
    send->head.dstId    = dstId;
    send->head.typeId    = typeId;
    send->head.recvEn    = MSG_REQ;
    memcpy((UINT8 *)(&(send->msg.tCmdParam)), cmd, cmdLen);
#ifndef _4C_VDE_TEST_
    if (BSP_OK != BspUdpMsgProc(typeId, (UINT8*)send, (UINT8*)recv))
    {
        retVal |= BIT_SET(1);
        dbgErr("%s>>SocketId'%d MsgType'0x%04X MsgProc Error! Ret= 0x%02X\n",
               __FUNCTION__, typeId, msgType, retVal);
    }
#endif
    memcpy(pbuff,recv->msg.buf,len);
    free(pucApiBuff);
    //MsgResultProc(retVal);
    return retVal;
}


/* elf function */
long (*testFUNC)(long, long, long, long, long, long, long, long, long, long);
UINT32 BspLoadRedirectLoge(const CHAR *ucFileName, CHAR *pucBuf, UINT32 *ptDataLen);

VOID BspParaseUdpShellCmd(VOID *pBuf,UINT32 len,T_MsgSocCommandAck *result)
{
    INT32 i=0, j=0, k=0;
    char  command_buf[32]={0}, argstr[10][30]={0}, argstr1[32] = {0};
    char  argtemp[30]={0}/* ,strTemp[10]={0} */;
    char  fileName[20]={0};
    INT32 argint[10]={0}, argflag[10]={0}, arginttmp[10] = {0}, outPutflag[10] = {0};
    WORD32 symtype=0;
    WORD32 symsize=0;
    INT32 value=0;
    /* INT32 iRet=BSP_OK; */
    T_CmdParam *ptCmdFrame = NULL;
    INT32 oldStdout=0;
    INT32 fd  = 0;
    /* FILE *fd1 = NULL; */
    UINT32 fileLen = 0;
    /* INT32 lenstr=0; */
    UINT32 ulMaskTmp=0;
    UINT32 ulTmp = 0;
    UINT32* buff[10]  = {NULL};
    INT32 snRet = 0;

    INPUT_POINTER_CHECK_RETURN(pBuf);
    INPUT_POINTER_CHECK_RETURN(result);

    memset(command_buf, 0, sizeof(command_buf));
    memset(argstr, 0, sizeof(argstr));  /*确认下大小*/
    memset(argflag,0, sizeof(argflag));
    memset(fileName,0,sizeof(fileName));

    ptCmdFrame = (T_CmdParam*)pBuf;
    result->ulmask   = CMD_FUNC;

    ulMaskTmp = ntohl(ptCmdFrame->ulmask);
    dbgInfoEx("%s: ulMaskTmp:%d\n",__FUNCTION__, ulMaskTmp);
    dbgInfo("ptCmdFrame->ulmask is %x\n",ptCmdFrame->ulmask);
    if(CMD_FUNC == ntohl(ptCmdFrame->ulmask))
    {
        /* get the command */
        if (CMD_flag_print == 1)
        {
            printf("%s\n", ptCmdFrame->ucCmd);
        }

        /* 将字符串调试命令分解为函数和参数 */
        i = 0;
        j = 0;
        k = 0;

        for (i = 0; (i < IPC_SOCKET_LENTH); i++)
        {
            ulTmp = i%sizeof(ptCmdFrame->ucCmd);
            /* 函数名分离 */
            if (j == 0)
            {
                if ((ptCmdFrame->ucCmd[ulTmp] != ' ') && (ptCmdFrame->ucCmd[ulTmp] != '\0'))
                {
                    command_buf[k%32] = ptCmdFrame->ucCmd[ulTmp];
                    k++;
                }
                else
                {
                    command_buf[k%32] = '\0';
                    j++;
                    k = 0;
                }
            }
            else
            {
                /* 参数分离，字符串形式 */
                if ((ptCmdFrame->ucCmd[ulTmp] != ',') && (ptCmdFrame->ucCmd[ulTmp] != '\0'))
                {
                    //argstr[j-1][29]用来存放\0,参数最多不能超过29个字符
                    if (k < 29)
                    {
                        argstr[(j-1)%10][k%30] = ptCmdFrame->ucCmd[ulTmp];
                        k++;
                    }
                    else
                    {
                        printf(" para %d is too long \n", j);
                        result->cmdRet = -1;
                        result->cmdErrReason = 0x1111;
                        return;
                    }
                }
                else
                {
                    argstr[(j-1)%10][k%30] = '\0';
                    j++;
                    k = 0;

                    if (ptCmdFrame->ucCmd[ulTmp] == '\0')
                    {
                        break;
                    }
                }
            }
        }

        /* 参数字符串形式转化为整型数 */
        for (i = 0; i < 10; i++)
        {
            //参数为16进制数
            if (((argstr[i][0] == '0') && (argstr[i][1] == 'x'))
                || ((argstr[i][0] == '0') && (argstr[i][1] == 'X')))
            {
                snRet = sscanf_s(argstr[i], "0x%x", (unsigned int *)&argint[i]);
                SSCANF_S_CHECK(snRet);

                if (CMD_flag_print == 1)
                {
                    argstr[i][29] = '\0';
                    printf("line :%d argstr[%d] :%s argint[%d]:0x%x \n", __LINE__, i, argstr[i], i, argint[i]);
                }
            }
            //参数为字符串
            else if (argstr[i][0] == '\"')
            {
                argflag[i] = 1;
                //跳过"
                memcpy(argtemp, &argstr[i][1], strlen(&argstr[i][1]));
                argtemp[strlen(&argstr[i][1])] = '\0';
                /*strcpy(argstr[i], argtemp);*/
                //coverity[cert_exp37_c_violation:SUPPRESS]
                strncpy_s(argstr[i], sizeof(argstr[i]), argtemp, sizeof(argstr[i]));

                if (CMD_flag_print == 1)
                {
                    argstr[i][29] = '\0';
                    printf("line :%d argstr[%d] :%s  \n", __LINE__, i, argstr[i]);
                }
            }
			else if ((argstr[i][0] == '<') && (argstr[i][(strlen(&argstr[i][0])-1)] == '>'))
		    {
                outPutflag[i] = 1;
				memcpy_s(argtemp,30*sizeof(INT8), &argstr[i][1], strlen(&argstr[i][1]) - 1);
                argtemp[strlen(&argstr[i][1]) - 1] = '\0';

                arginttmp[i] = atoi(argtemp);
                buff[i] = (UINT32*) malloc(arginttmp[i]);
                memset(buff[i],0,arginttmp[i]);
                snRet = snprintf_s(argstr1,sizeof(argstr1), "0x%p", buff[i]);
                SNPRINTF_S_CHECK(snRet,sizeof(argstr1));
                snRet = sscanf_s(argstr1, "0x%x", (unsigned int *)&argint[i]);
                SSCANF_S_CHECK(snRet);
                /*strcpy(argstr[i], argtemp);*/
                strncpy(argstr[i], argtemp, sizeof(argstr[i]));
				if (CMD_flag_print == 1)
                {
                    argstr[i][29] = '\0';
                    printf("line :%d argstr[%d] :%s argint[%d]:0x%x \n", __LINE__, i, argstr[i], i, argint[i]);
                }
			}
            //参数为十进制
            else
            {
                argint[i] = atoi(argstr[i]);

                if (CMD_flag_print == 1)
                {
                    argstr[i][29] = '\0';
                    printf("line :%d argstr[%d] :%s argint[%d]:0x%x \n", __LINE__, i, argstr[i], i, argint[i]);
                }
            }
        }
        if (CMD_flag_print == 1)
        {
            printf("recv cmd:%s\n",command_buf);
        }

        if (symFindByName(command_buf, (WORDPTR *)(&testFUNC), &symsize, &symtype) == 0)
        {
            //执行函数
            if (STT_FUNC == symtype)
            {
                snRet = snprintf_s(fileName,sizeof(fileName),"%s",FILE_SAVE_STDIO);
                SNPRINTF_S_CHECK(snRet,sizeof(fileName));
                oldStdout = dup(STDOUT_FILENO);
                if( -1 == oldStdout)
                {
                    result->cmdRet = -1;
                    result->cmdErrReason = UDP_SHELL_COMMD_REDIRECT_ERROR;
                    printf("%s dup rediret error\n",__FUNCTION__);
                    /*close(oldStdout);coverity 检查 ,oldstdout =-1 不能close*/
					for(i = 0 ; i < 10; i++)
				    {
                       if(outPutflag[i] == 1)
                       {
                          free(buff[i]);
                       }
					}
                    return ;
                }
                fd = open(fileName, O_RDWR | O_CREAT | O_TRUNC,S_IRUSR|S_IWUSR);
                if (-1 == fd)
                {
                    result->cmdRet = -1;
                    result->cmdErrReason = UDP_SHELL_COMMD_OPEN_FILE_ERROR;
                    printf("%s open file %s error\n",__FUNCTION__,fileName);
                    close(oldStdout);
					for(i = 0 ; i < 10; i++)
				    {
                       if(outPutflag[i] == 1)
                       {
                          free(buff[i]);
                       }
					}
                    return ;
                }
                /* 重定向 */
                if (-1 == dup2(fd,STDOUT_FILENO) )
                {
                    printf("%s rediret error\n",__FUNCTION__);
                    result->cmdRet = -1;
                    result->cmdErrReason = UDP_SHELL_COMMD_REDIRECT_ERROR;
                    close(fd);
                    close(oldStdout);
					for(i = 0 ; i < 10; i++)
				    {
                       if(outPutflag[i] == 1)
                       {
                          free(buff[i]);
                       }
					}
                    return ;
                }

                if(testFUNC != NULL)
                {
                    value = testFUNC(((argflag[0] == 0) ? argint[0] :(intptr_t)argstr[0]),
                                     ((argflag[1] == 0) ? argint[1] :(intptr_t)argstr[1]),
                                     ((argflag[2] == 0) ? argint[2] :(intptr_t)argstr[2]),
                                     ((argflag[3] == 0) ? argint[3] :(intptr_t)argstr[3]),
                                     ((argflag[4] == 0) ? argint[4] :(intptr_t)argstr[4]),
                                     ((argflag[5] == 0) ? argint[5] :(intptr_t)argstr[5]),
                                     ((argflag[6] == 0) ? argint[6] :(intptr_t)argstr[6]),
                                     ((argflag[7] == 0) ? argint[7] :(intptr_t)argstr[7]),
                                     ((argflag[8] == 0) ? argint[8] :(intptr_t)argstr[8]),
                                     ((argflag[9] == 0) ? argint[9] :(intptr_t)argstr[9])
                                    );
                }
                /* 恢复stdout */
                if (-1 == dup2(oldStdout,STDOUT_FILENO) )
                {
                    dbgErr("%s rediret recover error\n",__FUNCTION__);
                    result->cmdRet = -1;
                    result->cmdErrReason = UDP_SHELL_COMMD_REDIRECT_ERROR;
                    close(fd);
                    close(oldStdout);
					for(i = 0 ; i < 10; i++)
				    {
                       if(outPutflag[i] == 1)
                       {
                          free(buff[i]);
                       }
					}
                    return ;
                }
                close(fd);
                close(oldStdout);

                memcpy(result->ucCmd,command_buf,min(strlen(command_buf)%sizeof(command_buf),CMD_LENTH));
                result->cmdRet = (unsigned long)value;
            	for (i = 0; i < 10; i++)
            	{
            	    if(outPutflag[i] == 1)
            	    {
                        result->ulFuncParams[i] = *(buff[i]);
						printf("output is %d,and buff is %p.\n", *(buff[i]), buff[i]);
            	    }
				    else
            	    {
                        result->ulFuncParams[i] = argint[i];
					}
            	}
                if (BSP_ERROR == BspLoadRedirectLoge(fileName,result->cmdOutInfo,&fileLen))
                {
                    result->cmdErrReason = UDP_SHELL_COMMD_SUCCESS;
                    memset(&(result->cmdOutInfo[0]),0,sizeof(result->cmdOutInfo));
                }
                else
                {
                    result->cmdErrReason = UDP_SHELL_COMMD_SUCCESS;
                }


            }
            //显示变量值,暂不支持返回
            else
            {
                printf("symtype:%d unkonow \n", symtype);
                result->cmdRet = -1;
                result->cmdErrReason = UDP_SHELL_COMMD_MSG_ERROR;
				for(i = 0 ; i < 10; i++)
				{
                   if(outPutflag[i] == 1)
                   {
                       free(buff[i]);
                   }
		        }
                return ;
            }
        }
        else
        {
            printf("sym:%s not found!\n", command_buf);
            result->cmdRet = -1;
            result->cmdErrReason = UDP_SHELL_COMMD_FUN_UNKNOW;
			for(i = 0 ; i < 10; i++)
		    {
                if(outPutflag[i] == 1)
                {
                   free(buff[i]);
                }
			}
            return ;
        }
    }

	for(i = 0 ; i < 10; i++)
	{
		if(outPutflag[i] == 1)
		{
			free(buff[i]);
	    }
    }

	return;
}


UINT32 BspLoadRedirectLoge(const CHAR *ucFileName, CHAR *pucBuf, UINT32 *ptDataLen)
{
    INT32 readLen = 0;
    INT32 fd;
    struct stat tStatInfo;

    if ((ucFileName == NULL) || (pucBuf == NULL)
        || (ptDataLen == NULL))
    {
        return BSP_ERROR;
    }

    *ptDataLen = 0;



    fd = open(ucFileName, O_RDWR);
    if (fd < 0 )
    {
        dbgErr("Open file %s Failed!\n ", ucFileName);
        return BSP_ERROR;
    }
    if (-1 == stat(ucFileName, &tStatInfo))
    {
        dbgErr("stat file %s Failed!\n ", ucFileName);
        close(fd);
        return BSP_ERROR;
    }
   // fseek(fd, 0L, SEEK_SET);	/*定位到文件的开头*/

    BspSysMsDelay(50);
    readLen = read(fd,pucBuf,min((ULONG)tStatInfo.st_size,CMD_STDIO_INFO_LENTH));
    BspSysMsDelay(50);
    close(fd);

    if ((readLen < 0))
    {
        return BSP_ERROR;
    }

    *ptDataLen = (ULONG)tStatInfo.st_size;
    return BSP_OK;
}




UINT32 BspParseCmdResult(UINT32 cmdResult)
{
    switch(cmdResult)
    {
        case UDP_SHELL_COMMD_SUCCESS:
            RedirPrintf("Func run success\n");
            break;
        case UDP_SHELL_COMMD_MSG_ERROR:
            RedirPrintf("Func run failed,Msg Error\n");
            break;
        case UDP_SHELL_COMMD_FUN_UNKNOW:
            RedirPrintf("Func run failed,Unkown Fun name\n");
            break;
        case UDP_SHELL_COMMD_OPEN_FILE_ERROR:
            RedirPrintf("Func run failed,file open failed\n");
            break;
        case UDP_SHELL_COMMD_RD_FILE_ERROR:
            RedirPrintf("Func run failed,file read failed\n");
            break;
        case UDP_SHELL_COMMD_REDIRECT_ERROR:
            RedirPrintf("Func run failed,redirect failed\n");
            break;
        default:
            RedirPrintf("Error,Unknow result\n");
            break;
    }

    return BSP_OK;
}


UINT32 GetRadioCfg(VOID)
{
    UINT8  ucSlaverId = 2;
    UINT8  ucMasterId = 100;
    UINT32 ulRet = 0;
    UINT32 chipId = 0;
    UINT32 ulCnt = 0;
    UINT32 typeId = (UINT32)(HEAD_TYPE_ID_NXP_SOC&0xffffffff);
    UINT32 len = (UINT32)sizeof(T_UdpMsgQueryRadioAck);

    T_UdpMsgQueryRadioAck tUdpMsgQueryRadioAck  = {0};

    chipId = BspGetRpuId(); 
    ucSlaverId += (chipId&0xff);
    
    for(ulCnt=0;ulCnt<10;ulCnt++)
    {
        ulRet = SocMsgQueryRadioMode(typeId, ucSlaverId, ucMasterId,0,0,(T_UdpMsgQueryRadioAck*)&tUdpMsgQueryRadioAck,len);
        if((BSP_OK == ulRet)&&(BSP_OK == tUdpMsgQueryRadioAck.state))
        {
            dbgInfoEx("[%s]:RadioMode is 0x%x.\n",__FUNCTION__,tUdpMsgQueryRadioAck.RadioMode);
            break;
        }
    }
    if(ulCnt==10)
    {
        tUdpMsgQueryRadioAck.RadioMode = RADIO_STANDARD_UMTS | RADIO_STANDARD_GSM | RADIO_STANDARD_LTE_FDD | RADIO_STANDARD_NB_IOT | RADIO_STANDARD_FDD_5G;
        dbgErr("%s>>Udp Msg Get Failed !use default mode[5G] !\n",__FUNCTION__);
    }
    return tUdpMsgQueryRadioAck.RadioMode;
}

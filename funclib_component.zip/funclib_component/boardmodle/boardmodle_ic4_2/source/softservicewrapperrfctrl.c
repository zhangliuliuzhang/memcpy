/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : softservicewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "bspcommon.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "softservicewrapperrfctrl.h"
#include "softservicewrappervermanage.h"
#include "exprn.h"
#include "uart.h"
#include "uart_ic4_2.h"
#include "rftable.h"
#include "systemcallapi.h"
#include "ntl_l2ss_api.h"
#include "rruabilitycommon.h"
#include "funccommonapi.h"
#include "i2cbuszx211413.h"
#include "ichaladapt_ic4_2.h"
#include "ichaladapt_pad_ic4_2.h"
#include "optctrlcommon.h"
#include "uart_ic4_2_aisg.h"
#include "boardsocmsg.h"
#include "regdrv_pincfg.h"
#include "zx211413gpio.h"
#include "devswvload.h"
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/


UINT32 BspUartInit(VOID)
{
    T_UartDevPara *pPara = NULL;
    T_UartDevPara *uart = NULL;
    UINT32 num = 0;
    UINT32 *uartNum = 0;
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;

    BspIfSocNsbtFineCallBack(BspIfSocNsbtFine);

    BOARD_MODLE_GET_DATA(E_SOFT_SERVICE_UART_INIT,0,0,pPara,num);

    for (loop = 0; loop < num; loop++)
    {
        uart = &(pPara[loop]);
        retVal |= BspInitUartDev(uart);
        retVal |= UartInit(uart->type, uart->deviceId);
    }
    BOARD_MODLE_GET_DATA(E_SOFT_SERVICE_UART_INIT,0,1,uartNum,num);
    BspSetAisgNsbtControlNum(*uartNum);

    retVal |= BspInitAntInterFaceHardAblity();
    return retVal;
}

UINT32 BspRruTblLoadCfgInit(VOID)
{
    UINT32 flashParaSel = BspGetFlashParaSel();
    T_RruTblInfoSet tInfoSet[FLASH_PARA_MAX] =
    {
        {
            .pToMediumDir = RFTBL_DIR_IN_FLASH,
            .pToFsDir     = RFTBL_DIR_IN_DDR,
            .ulPhyAddr    = FLASH_RFTBL_OFFSET,
            .ulPhySize    = FLASH_RFTBL_SIZE,
        },
        {
            .pToMediumDir = RFTBL_DIR_IN_FLASH,
            .pToFsDir     = RFTBL_DIR_IN_DDR,
            .ulPhyAddr    = FLASH_RFTBL_OFFSET_NOR,
            .ulPhySize    = FLASH_RFTBL_SIZE_NOR,
        },
    };

    if (flashParaSel >= FLASH_PARA_MAX)
    {
        flashParaSel = FLASH_PARA_NOR_NAND;
    }
    return BspRruTblLoadCfg(&tInfoSet[flashParaSel]);
}

UINT32 BspLoadFlashInfoToMem(VOID)
{
    UINT32 retVal = BSP_OK;
    char  temp[64] = {0};
    INT32  snprtRet = 0;
    /* FLASH裸区校准文件地址设置 */
    snprtRet = snprintf_s(temp, sizeof(temp), "mkdir -p %s", RFTBL_DIR_IN_DDR);
    SNPRINTF_S_CHECK(snprtRet, sizeof(temp));
    BspSystem(temp);
    BspRruTblLoadCfgInit();
    BspCreatInfoFileCopyAll();
    BspUpdateChgIdMask();   /*根据离线表更新chgIdMask 用于器件替换场景查到基准单板 无对应新增的RruDevInfo.txt文件直接返回不影响功能*/
    return retVal;
}

static UINT32 BspCfgEthIpInfo(T_InnerIpInfo *ipInfo)
{
    UINT32 ret = 0;

    ret |= BspNetDeviceOpen(ipInfo->ethName);
    ret |= BspSetIp(ipInfo->ethName, ipInfo->ipAddr);
    ret |= BspSetIpMask(ipInfo->ethName, ipInfo->netMask);
    ret |= BspSetMac(ipInfo->ethName, ipInfo->macAddr);

    return ret;
}

UINT32 BspInnerNetL2ssInit(void)
{
    T_OptInitPara pOptInitPara = {0};
    T_OptInitPara *pPara = NULL;
    T_BspHalAdaptOptCpriInfo *pParaCpri = NULL;
    UINT32 num = 0;
    UINT32 num2 = 0;
    UINT32 retVal = BSP_OK;
    

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_HAL_INIT,0,0,pPara,num);
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,0,0,pParaCpri,num2);
    if(NULL != pParaCpri)
    {
        retVal = BspHalAdaptSetCpriRruType(pParaCpri->uCpuCfgEn);
    }
    pOptInitPara.optWorkMode = pPara->optWorkMode;
    if(pOptInitPara.optWorkMode == E_OPT_MODE_IR)  /*不能修改原始参数*/
    {
        pOptInitPara.optWorkMode = E_OPT_MODE_CPRI;  /*对l2ss只区分cpri和ecpri，不取反cpri和IR*/
    }
    if(pOptInitPara.optWorkMode == E_OPT_MODE_QCELL)   /*4.2 目前QECELL走ECPRI,其他都是CPRI*/
    {
        (VOID)BspSetOptProType(E_OPT_PRO_TYPE_ECPRI,0);
        (VOID)BspSetOptProType(E_OPT_PRO_TYPE_ECPRI,1);
    }
    else
    {
        (VOID)BspSetOptProType(E_OPT_PRO_TYPE_CPRI,0);
        (VOID)BspSetOptProType(E_OPT_PRO_TYPE_CPRI,1);
    }
    dbgInfo("BspInnerNetL2ssInit:%d\n",pOptInitPara.optWorkMode);
    retVal |= IcHalApiNtlL2ssInit(&pOptInitPara);
    // retVal |= IcHalApiNtlL2ssInitVlanCfg(pOptInitPara.optWorkMode); 和韩彦涛沟通注释掉， 打开部分的xmac和trxp

    return retVal;
}

UINT32 BspInnerNetCfg(void)
{
    T_InnerNetInfo  *pPara = NULL;
    UINT32          num = 0;
    UINT32          loop = 0;
    UINT32          retVal = BSP_OK;
    INT32           ret = 0;

    BOARD_MODLE_GET_DATA(E_SOFT_SERVICE_INNER_NET_CFG, 0, 0, pPara, num);

    for (loop = 0; loop < pPara->ipInfoNum; loop++)
    {
        retVal = BspCfgEthIpInfo(&(pPara->ipInfoPara[loop]));
        if (retVal != BSP_OK)
        {
            dbgErr("%s: ipinfo %u cfg failed\n", __FUNCTION__, loop);
        }
    }

    for (loop = 0; loop < pPara->routeNum; loop++)
    {
        ret = BspSystem(pPara->routePara[loop]);
        if (ret != 0)
        {
            dbgErr("%s: route %u cfg failed\n", __FUNCTION__, loop);
        }
    }

    for (loop = 0; loop < pPara->arpNum; loop++)
    {
        ret = BspSystem(pPara->arpPara[loop]);
        if (ret != 0)
        {
            dbgErr("%s: arp %u cfg failed\n", __FUNCTION__, loop);
        }
    }

    return BSP_OK;
}

UINT32 BspInitRruFormPara(void)
{
    UINT32          num = 0;
    UINT32          retVal = BSP_OK;
    T_RruFormInfo   *pPara = NULL;

    retVal = BspBoardModleGetData(E_SOFT_SERVICE_INIT_RRU_FORM, 0, 0, (void **)(&pPara), &num);
    if(retVal != BSP_OK || pPara == NULL)
    {
        return BSP_OK;
    }
    BspInitRruForm(pPara, num);
    return BSP_OK;
}

UINT32 BspReadGpio0Status(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 flashDivision = 0;

    retVal = DpdIcHalRegTblInit();
    retVal |= BspCpuGpioInit();
    retVal |= BspSetPadFuncSel(IO_GPIO_0,0);
    flashDivision = BspDpdicGpioGet(0);
    BspSetFlashDivision(flashDivision);
    dbgInfo("%s: flashDivision %d\n", __FUNCTION__, flashDivision);

    return retVal;
}

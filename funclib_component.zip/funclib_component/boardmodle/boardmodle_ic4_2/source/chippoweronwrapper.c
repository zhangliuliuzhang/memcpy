/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : chippoweronwrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件
* 注意事项 : 无
*---------------------------------------------------------------------------*/
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "chippoweronwrapper.h"
#include "padctrl.h"
#include "cbswcfg.h"
#include "boardversionload.h"
#include "boardpad_ic4_2.h"
#include "funccommon_a.h"
#include "boardreset.h"
#include "devdrv_dac.h"
#include "plugandplay.h"
#include "devdrv_clk.h"
#include "clk_common.h"
#include "fpgaloadprocess.h"
#include "att_common.h"
#include "ichaladapt_crm_ic4_2.h"
#include "boardreset.h"
#include "dpdicxmodem.h"
#include "devdrv_lo.h"
#include "gainctrlcommon.h"
#include "devdrv_att.h"
#include "devdrv_transceiver.h"
#include "eeprom_common.h"
#include "transceiver_common.h"
#include "optctrlapi.h"
#include "dpd_app.h"
#include "i2cbuszx211413.h"
#include "pwr_a.h"
#include "eepromapi.h"

#include "ichaladapt_j204_ic4_2.h"
#include "regaccess.h"
#include "optctrl_ntl_ic4_2.h"
#include "j204_ic4_2.h"
#include "rftable_padacset.h"
#include "rruinfo.h"
#include "rftable_pabasicinfo.h"
#include "pa_ic4_2_gridvolt.h"
#include "powerctrl_ic4_2.h"
#include "crc.h"
#include "coreprocaffinity.h"

#define CHIPPOWERON_DATA_FILE_NAME       "ChipPoweronData.json"

static ChipPowOn_ClkInitPostHandle pChipPowonClkInitPostHandle = NULL;
static ChipPowOn_ChangePaDacDeviceCfg pChangePaDacDeviceCfg = NULL;
static ChipPowOn_Negative8VAlarm pNegative8VAlarm = NULL;
static UINT32 N8vAlarmFlag = 0x5a5a;/*-8V是否检测标志，0x5a5a检测-8V告警，0xa5a5不检测-8v告警，默认检测*/
CHAR g_ramBootFileName[255] = "/tmp/ramboot.bin";
/*****************************************************************************
 *  函数名称   : BspInitGpioPad(VOID)
 *  功能描述   : pad模块初始化
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功，其他     失败
 *  其它说明   :
 *****************************************************************************/
UINT32 BspInitGpioPad(void)
{
    UINT32 retVal = BSP_OK;
    T_GpioPadInfoModify *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_PAD,0,0,pPara,num);
    retVal = BspBoardPadInit(pPara, num);

    return retVal;
}
/*反馈射频控制模块通用参数初始化*/
UINT32 BspCbSwCommonParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspCbSwPara* ptCbSwPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA,0,0,ptCbSwPara,num);
    retVal = BspCbSwParaInit(ptCbSwPara, num);
    return retVal;
}

UINT32 BspInitRfPllInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_RfPllInit_Para* pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_RFPLL_INIT,0,0,pPara,num);

    if(TX == pPara->dlDirect)
    {
        retVal = BspInitRfPll(TX);
    }

    if(RX == pPara->ulDirect)
    {
    	retVal = BspInitRfPll(RX);
    }

    if(PRX == pPara->prlDirect)
    {
    	retVal = BspInitRfPll(PRX);
    }

    return retVal;
}

UINT32 BspPreInitRfTransceiver(VOID)
{
    UINT32 retVal = BSP_OK;
    //后续针对tranciver加载前需要相关动作在进行添加

    return retVal;
}

UINT32 BspPostInitRfTransceiver(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulChan = 0;

    for(ulChan = 0; ulChan < BspGetRxChannel(); ulChan++)
    {
    	retVal = BspSetRxGain(ulChan, 0);
    }
    //后续将TrxBoardSwitchInit进行添加

    SetPowerOnFinished(E_POWERON_RFTR_INIT);

    return retVal;
}

/*Transceiver serdes预均衡参数初始化*/
UINT32 BspTrxJ204SerdesTxEqInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_TrxJ204SerdesTxEqPara *pPara = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT,0,0,pPara,num);
    if(NULL == pPara || 0 == num)
    {
        /* 未指定预加重参数，则不进行配置 */
        return BSP_OK;
    }

    for(loop=0; loop<num; loop++)
    {
        retVal |= BspTrxSerdesTxPreEmphasis(pPara[loop].chipId, pPara[loop].laneId, pPara[loop].eqMain, pPara[loop].eqPre, pPara[loop].eqPost);
        CHECK_RETVAL(BspTrxSerdesTxPreEmphasis, retVal);
    }

    return retVal;
}

UINT32 BspInitDattVgaPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    T_ATTVGA_CFGPARA* pAttPara;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_ATT_INIT, 0, 0, pAttPara, num);

    retVal = BspSetAttVgaCfgPara(pAttPara, num);
    retVal |= BspInitDattVga();

    return retVal;
}
UINT32 BspInitAcAttSwitchPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    T_TRXACATT_CFGPARA* pAttPara = NULL;;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_ACATT_INIT, 0, 0, pAttPara, num);
    retVal = BspSetTransceiverAcAttSwitch(pAttPara, num);

    return retVal;
}

/*反馈射频控制时间片参数初始化*/
UINT32 BspCbSwStaTblParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspCbSwStaTbl* ptCbSwStaTbl = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,0,0,ptCbSwStaTbl,num);
    retVal =  BspCbSwStaTblInit(ptCbSwStaTbl, num);
    retVal |= BspHalAdaptSetSwOe(ENABLE);
    retVal |= BspDspSetFbCtrlInfo(ptCbSwStaTbl, num);
    return retVal;
}

UINT32 BspCbSwStaTblPara1Init(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspCbSwStaTbl* ptCbSwStaTbl = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,0,1,ptCbSwStaTbl,num);
    retVal =  BspCbSwStaTblInit(ptCbSwStaTbl, num);
    retVal |= BspHalAdaptSetSwOe(ENABLE);
    retVal |= BspDspSetFbCtrlInfo(ptCbSwStaTbl, num);
    return retVal;
}

/*反馈射频控制电子开关真值表初始化*/
UINT32 BspCbSwRfTblParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspCbSwRfTbl* ptCbSwRfTbl = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA,0,0,ptCbSwRfTbl,num);
    retVal = BspCbSwRfTblInit(ptCbSwRfTbl, num);
    return retVal;
}

/*反馈射频控制电子开关真值表初始化*/
UINT32 BspCbSwRfTblParaInit_Fpga(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspCbSwRfTbl* ptCbSwRfTbl = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA,0,0,ptCbSwRfTbl,num);
    retVal = BspCbSwRfTblInit_Fpga(ptCbSwRfTbl, num);
    return retVal;
}

UINT32 BspSetUshellThrdAffinity(UINT32 coreMask)
{
    UINT32 retVal = BSP_OK;
    static UINT32 originCoreMask = 0;
    UINT32 tidNo = 0;
    CHAR ushellMgr[] = "{ushellAgent} /MGR.EXE";
    CHAR ushellMgr_s[] = "{ushellAgent} /MGR_S.EXE";
    CHAR *pThrdName = ushellMgr;

#ifdef MULT_PROGRESS_S
    /*主从架构机型针对从进程 ushell 线程修改cpu亲和力*/
    if (0 == BspGetRpuId())
    {
        pThrdName = ushellMgr_s;
    }
#endif

    dbgInfoEx("[%s] *pThrdName:%s, ushellMgr_s:%s\n", __FUNCTION__, pThrdName, ushellMgr_s);
    retVal |= BspGetTidByName(pThrdName, &tidNo);
    if (retVal != BSP_OK)
    {
        dbgErr("[%s]: get tidNo fail, tidNo:%d, retVal:%d \n", __FUNCTION__, tidNo, retVal);
        return BSP_ERROR;
    }

    if (originCoreMask == 0)
    {
        retVal |= ProcAffinityGet(tidNo, &originCoreMask);
    }

    dbgInfo("[%s] Tid:%d, inputCoreMask:0x%x, originCoreMask:0x%x \n",
            __FUNCTION__, tidNo, coreMask, originCoreMask);

    if (coreMask == 0)
    {
        /* 恢复原有绑核关系 */
        retVal |= ProcAffinitySet(tidNo, originCoreMask);
        return retVal;
    }

    retVal |= ProcAffinitySet(tidNo, coreMask);

    return retVal;
}

/* Started by AICoder, pid:4ef93s2e584b5d914d8d0843e08e85323905293b */
/*IC动态调整核压的温度与电压映射关系参数初始化*/
UINT32 BspDpdicDynVoltParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 index = 0;
    T_icCoreVoltDynCfg *pIcDynPara = BspGetSlaveIcDynVoltPara();

    /*主片承担调压异常时拉起从片的任务,需采用较小的调压范围,保持相对稳定*/
    if (0 == BspGetRpuId())
    {
        pIcDynPara = BspGetMainIcDynVoltPara();
    }

    INPUT_POINTER_CHECK(pIcDynPara);
    retVal = BspSetIcDynVoltPara(pIcDynPara);
    retVal |= BspSetPmbVoltGate(index, pIcDynPara->icVoltLowThrMv, pIcDynPara->icVoltHighThrMv);
    dbgInfo("[%s] lowVoltMv:%d, highVoltMv:%d \n",__FUNCTION__,
            pIcDynPara->icVoltLowThrMv, pIcDynPara->icVoltHighThrMv);

    return retVal;
}
/* Ended by AICoder, pid:4ef93s2e584b5d914d8d0843e08e85323905293b */

/*电源管理芯片系数初始化*/
UINT32 BspPmbScaleInfoInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_PmbScaleInfo *pPmbScale = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_PMB_SCALE_INFO, 0, 0, pPmbScale, num);

    if (pPmbScale->pmbNum > D42_PMB_MAX_NUM)
    {
        dbgErr("[%s] pmbNum:%d out of range! maxNum:%d \n",
                __FUNCTION__, pPmbScale->pmbNum, D42_PMB_MAX_NUM);
        return BSP_ERROR;
    }

    for(loop = 0; loop < pPmbScale->pmbNum; loop++)
    {
        retVal |= BspSetPmbCoef(pPmbScale->pmbcoef[loop].pmbNo, pPmbScale->pmbcoef[loop].pmbKrCoef);
    }

    return retVal;
}

/*主进程加载M0初始化*/
UINT32 BspMainM0LoadVersion(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    UINT32 coreLoop = 0;
    T_M0VerLoadInfo *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_MAIN_M0_LOAD,0,0,pPara,num);

    for(coreLoop = 0; coreLoop < pPara->coreNum; coreLoop++)
    {
    	if(pPara->coreLoadInfo[coreLoop].ceneType < E_M0_VERSION_M_MAX)
    	{
    	    retVal |= BspHalAdaptLoadM0CoreVersion(pPara->coreLoadInfo[coreLoop].coreId, pPara->coreLoadInfo[coreLoop].ceneType);
    	    BspLog(LOG_LEVEL_0, "%s: coreId=%d ceneType:%d load OK ! \n", __FUNCTION__, pPara->coreLoadInfo[coreLoop].coreId,pPara->coreLoadInfo[coreLoop].ceneType);
    	}
    	else
    	{
            BspLog(LOG_LEVEL_0, "%s: coreId=%d ceneType:%d not support  ! \n", __FUNCTION__, pPara->coreLoadInfo[coreLoop].coreId,pPara->coreLoadInfo[coreLoop].ceneType);
    	}
    }

    retVal |= BspSetMainM0VerLoadInfo(pPara);

    return retVal;
}

/*从进程加载M0初始化*/
UINT32 BspSlaveM0LoadVersion(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    UINT32 coreLoop = 0;

    T_M0VerLoadInfo *pPara = NULL;
    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_SLAVE_M0_LOAD,0,0,pPara,num);

    for(coreLoop = 0; coreLoop < pPara->coreNum; coreLoop++)
    {
    	if((pPara->coreLoadInfo[coreLoop].ceneType < E_M0_VERSION_S_MAX) && (pPara->coreLoadInfo[coreLoop].ceneType > E_M0_VERSION_M_MAX))
    	{
    	    retVal |= BspHalAdaptLoadM0CoreVersion(pPara->coreLoadInfo[coreLoop].coreId, pPara->coreLoadInfo[coreLoop].ceneType);
    	    BspLog(LOG_LEVEL_0, "%s: coreId=%d ceneType:%d load OK ! \n", __FUNCTION__, pPara->coreLoadInfo[coreLoop].coreId,pPara->coreLoadInfo[coreLoop].ceneType);
    	}
    	else
    	{
            BspLog(LOG_LEVEL_0, "%s: coreId=%d ceneType:%d not support  ! \n", __FUNCTION__, pPara->coreLoadInfo[coreLoop].coreId,pPara->coreLoadInfo[coreLoop].ceneType);
    	}
    }

    retVal |= BspSetSlaveM0VerLoadInfo(pPara);

    return retVal;
}

/* FPGA 版本加载 */
UINT32 LoadFpgaVersion(void)
{
    UINT32 retVal = BSP_OK;
    T_VerLoadInfo *fpgaLoadInfo = NULL;
    UINT32 num = 0;
    UINT32 softType = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_FPGA_LOAD, 0, 0, fpgaLoadInfo, num);
    softType = BspSwitchNameToSoftType(fpgaLoadInfo->SoftName);
    if (softType != BSP_ERROR && softType != ERROR_NULL_POINTER)
    {
        BspSetFpgaVerSoftType(softType);
    }
    return BspLoadSwvVersion(fpgaLoadInfo);
}
/* DPD DSP 版本加载 */
UINT32 LoadDspVersion(void)
{
    UINT32 retVal = BSP_OK;
    T_VerLoadInfo *dspLoadInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DSP_LOAD, 0, 0, dspLoadInfo, num);
    return BspLoadSwvVersion(dspLoadInfo);
}

/* AC DSP 版本加载 */
UINT32 LoadAcDspVersion(void)
{
    UINT32 retVal = BSP_OK;
    T_VerLoadInfo *dspLoadInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_AC_DSP_LOAD, 0, 0, dspLoadInfo, num);
    return BspLoadSwvVersion(dspLoadInfo);
}

/* 多片IC机型，主片从MGR版本加载*/
UINT32 LoadSlaveMgrVersion(void)
{
    UINT32 retVal = BSP_OK;
    T_VerLoadInfo *slaveMgrLoadInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_SLAVE_MGR_LOAD, 0, 0, slaveMgrLoadInfo, num);
    return BspLoadSwvVersion(slaveMgrLoadInfo);
}

UINT32 LoadSlaveBinVersion(void)
{
    UINT32 retVal = BSP_OK;
    T_VerLoadInfo *slaveMgrLoadInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_SLAVE_BIN_LOAD, 0, 0, slaveMgrLoadInfo, num);
    return BspLoadSwvVersion(slaveMgrLoadInfo);
}
/* UINT32 BspCbSwPinTblParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspCbPinSw* ptCbPinSwTbl = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CBSW_PINSW_PARA,0,ptCbPinSwTbl,num);
    retVal = BspCbPinSwTblInit(ptCbPinSwTbl, num);
    return retVal;
} */

/*时钟芯片的初始化*/
UINT32 InitClkDev(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chip = 0;
    UINT32 reLoadFlag = OPT_AND_CLK_NOT_NEED_INIT;

    reLoadFlag = BspGetClkAndOptReLoadFlag();
    dbgInfoEx("resetTpye = %d\n",reLoadFlag);
    if(OPT_AND_CLK_NOT_NEED_INIT == reLoadFlag)
    {
        ClkSetFpgaReLoadFlag(0);   //不是掉电复位时，不重新配置系统时钟
    }else
    {
        /*需要初始化时钟，pll2关闭CRM_DISABLE*/
        BspHalAdaptCrmSocPll2PwrDivEnDis(chip,0);
        /*需要初始化时钟，pll3关闭CRM_DISABLE*/
        BspHalAdaptCrmSocPll3PwrDivEnDis(0);
    }
    if(RRU_BBU == BspGetPbOrBbuMode())
    {
        BspSetClkPllSysDevCfg();
    }
    retVal |= BspInitClkPllSys();

    if(pChipPowonClkInitPostHandle != NULL)
    {
        retVal |= pChipPowonClkInitPostHandle();
    }
    return retVal;
}

/* DAC相关接口挂接以及参数初始化 */
UINT32 BspDacInterfaceParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_DACVOLT_CFGPARA* ptDacInterfacePara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DAC_CALLBACK,0,0,ptDacInterfacePara,num);
    retVal = BspSetDacGridVoltCfgPara(ptDacInterfacePara, num);
    return retVal;
}
/*是否判断-8V告警调试接口*/
static VOID dbgChangeN8vAlmFlag(UINT32 flag)
{
    N8vAlarmFlag = flag;
}
/*DAC时钟初始化*/
UINT32 BspDacDevInit(VOID)
{
    UINT32 retVal = BSP_OK;

    if(N8vAlarmFlag == 0x5a5a)/*todo: -8v告警检测待完善，看下-8v检测接口是否可以通用*/
    {
        if(pNegative8VAlarm != NULL)
        {
            retVal = pNegative8VAlarm();
            if(retVal != BSP_OK)
            {
                dbgErr("[%s] have -8v alarm!\n",__FUNCTION__);
                return BSP_ERROR;
            }
        }
    }
    if(pChangePaDacDeviceCfg != NULL)
    {
        retVal = pChangePaDacDeviceCfg();
    }
    retVal |= BspInitRfDac();

    retVal |= BspSetPaVibas(0);
    return retVal;
}

/*IC4.2 时钟芯片配置前的CRM模块初始化*/
UINT32 BspDpdicCrmInit_BeforeClk(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptCrmPara_BeforeClk *pPara = NULL;
    UINT32 num = 0;

#ifndef MULT_PROGRESS_S
    (void)SfpSetOptStateFunc(BspGetOptSpeed, BspGetOptStatus);
#endif

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,0,0,pPara,num);

    /*CRM SOC时钟初始化*/
    retVal |= BspHalAdaptCrmSocClkParaInit(pPara->tSocClkPara);

    return retVal;
}

/*IC4.2 时钟芯片配置后的CRM模块初始化，适用于单片和主从中的主片场景*/
UINT32 BspDpdicCrmInit_After_M(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptCrmPara_AfterClk *pPara = NULL;
    UINT32 num = 0;
    UINT32 reLoadFlag = 0;

    reLoadFlag = BspGetClkAndOptReLoadFlag();
    dbgInfoEx("resetTpye = %d\n",reLoadFlag);

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,0,0,pPara,num);

    if(RRU_BBU_EP214 == BspGetPbOrBbuMode())
    {
        /*DPD模块关闭前4通道 仅ep214需要*/
        BspHalAdaptSetDldpdSetGateCfg(0x30,0);
    }

    /*关闭中频总控*/
    BspHalAdaptSetJ204DifGate(0);
    /*关闭FFT和rach时钟*/
    BspHalAdaptCrmCfgPrachFftMode(0,0xff00);

    if (OPT_AND_CLK_NOT_NEED_INIT != reLoadFlag)
    {
        /*CRM PLL初始化*/
        retVal |= BspHalAdaptCrmPllParaInit(pPara->tPllClkPara);
        /*CRM OPT时钟初始化*/
        retVal |= BspHalAdaptCrmOptClkParaInit(pPara->tOptClkPara);
    }

    /*打开中频总控*/
    BspHalAdaptSetJ204DifGate(1);
    if(RRU_BBU_EP214 == BspGetPbOrBbuMode())
    {
        /*cfr前四个通道关闭 仅ep214需要*/
        BspHalAdaptSetCfrStageGateCtrl(0);
    }

    /*CRM Dif时钟初始化*/
    retVal |= BspHalAdaptCrmDifClkParaInit(pPara->tDifClkPara);
    //非ep214机型需打开
    if(RRU_BBU_EP214 != BspGetPbOrBbuMode())
    {
        /*打开FFT和rach时钟*/
        BspHalAdaptCrmCfgPrachFftMode(0,0xffff);
    }

    /*CRM 复位释放*/
    retVal |= BspHalAdaptCrmCommonRstParaInit(pPara->tCommRst);
    /* 复位Bif Gf Dif (解决Bif Gf挂死问题) */
    retVal |= BspHalAdaptCrmGfBifDifSetReset(0, 0);
    /* 释放复位Bif Gf Dif */
    retVal |= BspHalAdaptCrmGfBifDifSetReset(0, 1);
    /*CRM Dif时钟选择初始化*/
    retVal |= BspHalAdaptCrmDifClkSelectParaInit(pPara->tDifClkSelectPara);
    /* CRM j204 global apb复位释放 */
    retVal |= BspHalAdaptCrmJ204SetResetGlobalApb(1);
    retVal |= BspHalAdaptJitOutWinCfg(0);
    BspSysMsDelay(11);
    retVal |= BspHalAdaptJitOutWinCfg(2);
    retVal |= BspHalAdaptJ204InfGlbWinCfg(0);
    BspSysMsDelay(11);
    retVal |= BspHalAdaptJ204InfGlbWinCfg(2);
    
    #if !defined(BSP_MAKE_VER) && !defined(_BSP_WITH_WFS)/*小版本网口5min ping不通规避*/
    /*复位光口pcs解决挂死, NCR机型不需要处理 */
    if (OPT_AND_CLK_NOT_NEED_INIT != reLoadFlag && IS_NCR != BspIsNcr())
    {
        retVal |= BspHalAdaptCrmPcsSetReset(0xf,0); /*复位*/
        BspSysUsDelay(100);
        retVal |= BspHalAdaptCrmPcsSetReset(0xf,1); /*复位释放*/
        BspSysUsDelay(100);
    }
    #endif

    return retVal;
}

static UINT32 s_DpdicOptClkCfgCondition = SWITCH_ON;
UINT32 BspGetOptClkInitCondition(VOID)
{
    return s_DpdicOptClkCfgCondition;
}

VOID BspSetOptClkInitCondition(UINT32 cfgFlag)
{
    s_DpdicOptClkCfgCondition = cfgFlag;
}

/*IC4.2 时钟芯片配置后的CRM模块初始化， CRM模块初始化，适用主从中的从片场景*/
UINT32 BspDpdicCrmInit_After_S(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptCrmPara_AfterClk *pPara = NULL;
    UINT32 num = 0;
    UINT32 recordReg = 0;
    UINT32 reLoadFlag = 0;
    UINT32 chip = 0;

    BspGetClkAndOptReLoadFlag();
    reLoadFlag = BspGetOptClkInitCondition();
    dbgInfoEx("resetTpye = %d\n",reLoadFlag);
    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,0,0,pPara,num);
    dbgInfo("*****************************************************[%d]\r\n",reLoadFlag);

    BspHalAdaptCrmRecRegSet(0, 0, 31, 1);
    BspHalAdaptCrmRecRegGet(0, 0, 31, &recordReg);
    BspLog(LOG_LEVEL_0, "%s: recordReg=%u reLoadFlag:%d \n", __FUNCTION__, recordReg,reLoadFlag);
    
    /*关闭中频总控*/
    BspHalAdaptSetJ204DifGate(0);
    /*关闭FFT和rach时钟*/
    BspHalAdaptCrmCfgPrachFftMode(0,0xff00);

    if(OPT_AND_CLK_NOT_NEED_INIT != reLoadFlag)
    {
        /*需要初始化时钟，pll2关闭CRM_DISABLE*/
        BspHalAdaptCrmSocPll2PwrDivEnDis(chip,0);
        /*需要初始化时钟，pll3关闭CRM_DISABLE*/
        BspHalAdaptCrmSocPll3PwrDivEnDis(0);
        /*CRM PLL初始化*/
        retVal |= BspHalAdaptCrmPllParaInit(pPara->tPllClkPara);
        /*CRM OPT时钟初始化*/
        retVal |= BspHalAdaptCrmOptClkParaInit(pPara->tOptClkPara);
    }

    /*打开中频总控*/
    BspHalAdaptSetJ204DifGate(1);
    /*CRM Dif时钟初始化*/
    retVal |= BspHalAdaptCrmDifClkParaInit(pPara->tDifClkPara);
    /*打开FFT和rach时钟*/
    BspHalAdaptCrmCfgPrachFftMode(0,0xffff);
    /*CRM 复位释放*/
    retVal |= BspHalAdaptCrmCommonRstParaInit(pPara->tCommRst);
    /* 复位Bif Gf Dif (解决Bif Gf挂死问题) */
    retVal |= BspHalAdaptCrmGfBifDifSetReset(0, 0);
    /* 释放复位Bif Gf Dif */
    retVal |= BspHalAdaptCrmGfBifDifSetReset(0, 1);
    /*CRM Dif时钟选择初始化*/
    retVal |= BspHalAdaptCrmDifClkSelectParaInit(pPara->tDifClkSelectPara);
    /* CRM j204 global apb复位释放 */
    retVal |= BspHalAdaptCrmJ204SetResetGlobalApb(1);
    retVal |= BspHalAdaptJitOutWinCfg(0);
    BspSysUsDelay(1);
    retVal |= BspHalAdaptJitOutWinCfg(2);
    retVal |= BspHalAdaptJ204InfGlbWinCfg(0);
    BspSysUsDelay(1);
    retVal |= BspHalAdaptJ204InfGlbWinCfg(2);

    return retVal;
}

UINT32 BspGetDpdicLoadChipNo(UINT32 chipIdx, UINT32 *socChipNo)
{
    T_DpdicSocLoadOrder *pPara = NULL;
    UINT32 num = 0;
    UINT32 chipNo = 0;
    UINT32 chipNum = 0;
    UINT32 retVal = 0;
    UINT32 routePath = 0;

    INPUT_POINTER_CHECK(socChipNo);

    chipNum = BspGetRpuNum();
    if ((chipIdx >= chipNum) || (chipIdx >= DPDIC_SOC_MAX_NUM))
    {
        dbgInfo("%s>> chipIdx overrange!!!\r\n",__func__);
        *socChipNo = chipIdx;
        return BSP_OK;
    }

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_LOAD_ORDER_CHIPNO,0,0,pPara,num);
    BspGetCpriModeLaneRoutePath(&routePath);
    if(routePath < num)
    {
		if (BIT_VAL(pPara[routePath].chipMask, chipIdx))
		{
			 chipNo = pPara[routePath].socLoadChipNo[chipIdx];
			 *socChipNo = chipNo;
			 return BSP_OK;
		}
    }
    return BSP_OK;
}

/* DPDIC从片的复位和复位释放控制, 适用于主片 */
static UINT32 DpdicSlaveSocReset(UINT32 rstCtrl)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipRet = 0;
    T_DpdicSocReset *pPara = NULL;
    UINT32 num = 0;
    UINT32 chip = 0;
    UINT32 socChipId = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_SOC_RESET,0,0,pPara,num);
    for(chip=0; chip<BspGetRpuNum(); chip++)
    {
        chipRet = BspGetDpdicLoadChipNo(chip, &socChipId);
        if (chipRet != BSP_OK)
        {
            socChipId = chip;
        }

        if(BIT_VAL(pPara->chipMask, socChipId))
        {
            dbgInfo("%s>> soc chipid:%d\r\n",__func__,socChipId);
            retVal |= BspDpdicResetCtrl(socChipId, pPara->rstType, rstCtrl);
            dbgInfo("%s>> retval:%d\r\n",__func__,retVal);
        }
    }

    return retVal;
}

/* DPDIC从片的复位和复位释放控制, 适用于主片 */
UINT32 BspDpdicSlaveSocResetByChip(UINT32 chipId, UINT32 rstCtrl)
{   
    UINT32 retVal = BSP_OK;
    T_DpdicSocReset *pPara = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_SOC_RESET,0,0,pPara,num);
    if(chipId >=BspGetRpuNum())
    {
        dbgErr("%s chipId[%d] error!\n",__func__,chipId);
        return BSP_ERROR;        
    }
    if(BIT_VAL((pPara->chipMask), chipId))
    {
        retVal = BspDpdicResetCtrl(chipId, pPara->rstType, rstCtrl);
    }
    else  
    {
        dbgErr("%s chipId[%d] not support!\n",__func__,chipId);
        retVal = BSP_ERROR;           
    }
    return retVal;
}

/* DPDIC从片的复位控制, 适用于主片 */
UINT32 BspDpdicSlaveSocReset(VOID)
{   
    return DpdicSlaveSocReset(0);
}

/* DPDIC从片的复位释放控制, 适用于主片 */
UINT32 BspDpdicSlaveSocRelease(VOID)
{
    return DpdicSlaveSocReset(1);
}

/* DPDIC从片M0版本加载, 适用于主片 */
UINT32 BspDpdicSlaveSocLoad(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipRet = 0;
    T_DpdicSocLoad *pPara = NULL;
    UINT32 num = 0;
    UINT32 ulChipLoop  = 0;
    UINT32 ulSocMaxSum = 2;
    UINT32 socChipId = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_SOC_LOAD,0,0,pPara,num);
    ulSocMaxSum = BspGetRpuNum(); /* Dpdic(RPU) 总数 */
    dbgInfo("%s>>RpuNum Get OK! SocSum= %d\n", __FUNCTION__, ulSocMaxSum);
    retVal = BspDpdIcXmodemInfoInit(&(pPara->xmodemInfo));
    for (ulChipLoop = 0; ulChipLoop < ulSocMaxSum; ulChipLoop++)
    {
        chipRet = BspGetDpdicLoadChipNo(ulChipLoop, &socChipId);
        if (chipRet != BSP_OK)
        {
            socChipId = ulChipLoop;
        }

        if(BIT_VAL(pPara->chipMask, socChipId))
        {
            dbgInfo("%s>> soc chipid:%d\r\n",__func__,socChipId);
            retVal |= BspSocDpdicVerUpdate(pPara->rstType, socChipId);
        }
    }
    return retVal;
}

/* DPDIC从片M0版本加载, 适用于主片 */
UINT32 BspDpdicSlaveSocLoadByChip(UINT32 chipId)
{
    UINT32 retVal = BSP_OK;
    T_DpdicSocLoad *pPara = NULL;
    UINT32 num = 0;
    UINT32 ulSocMaxSum = 2;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_SOC_LOAD,0,0,pPara,num);
    ulSocMaxSum = BspGetRpuNum(); /* Dpdic(RPU) 总数 */
    dbgInfo("%s>>RpuNum Get OK! SocSum= %d\n", __FUNCTION__, ulSocMaxSum);

    if(chipId >= ulSocMaxSum)
    {
        dbgErr("%s chipId[%d] error!\n",__func__,chipId);
        return BSP_ERROR;
    }

    if(BIT_VAL(pPara->chipMask, chipId))
    {
        retVal = BspSocDpdicVerUpdate(pPara->rstType, chipId);
    }
    else
    {
        dbgErr("%s chipId[%d] not support!\n",__func__,chipId);
        retVal = BSP_ERROR;
    }

    return retVal;
}

/*transceiver初始化*/
UINT32 BspRfTransceiverInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_IC_TRX_PIN_MAP *pPara = NULL;
    UINT32 num = 0;

    retVal = BspBoardModleGetData(E_CHIP_POWERON_TRANSCEIVER_INIT, 0, 0, (VOID**)(&pPara), &(num));
    if(pPara != NULL)
    {
        BspHalAdaptSetTrxPinMap(pPara);/*复位管脚对应关系初始化*/
    }

    retVal = BspInitRfTransceiver();
    BspSetInitAlarmStatus(ALARM_ACTION_TRANCEIVER_INIT, retVal);

    return retVal;
}

UINT32 BspFileCopy(const CHAR* pcSrcFileName, const CHAR* pcDesFileName)
{
    int ret = 0;
    char cmd[128] = {0};
    INPUT_POINTER_CHECK(pcSrcFileName); 
    INPUT_POINTER_CHECK(pcDesFileName); 
    ret = snprintf_s(cmd, sizeof(cmd), "cp -r %s %s", pcSrcFileName, pcDesFileName);
    SNPRINTF_S_CHECK(ret, sizeof(cmd));
    BspSystem(cmd);
    return BSP_OK;
}

UINT32 BspFileMove(CHAR* pcSrcFileName,CHAR* pcDesFileName)
{
    int ret = 0;
    CHAR cmd[128] = {0};
    INPUT_POINTER_CHECK(pcSrcFileName); 
    INPUT_POINTER_CHECK(pcDesFileName); 

    ret = snprintf_s(cmd, sizeof(cmd), "mv %s %s", pcSrcFileName, pcDesFileName);
    SNPRINTF_S_CHECK(ret, sizeof(cmd));
    BspSystem(cmd);
    return BSP_OK;
}

UINT32 BspFileMoveInit(void)
{
    UINT32 retVal = BSP_OK;
    T_FileMoveList *pPara = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;
    
    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_FILE_MOVE,0,0,pPara,num); 

    for(loop = 0; loop < num; loop++)
    {   
        if(pPara[loop].moveWay == MOVE_WAY_COPY)
        {
            BspFileCopy(pPara[loop].pSourcePath,pPara[loop].pDestPath);
        }
        else if(pPara[loop].moveWay == MOVE_WAY_MOVE)
        {
            BspFileMove(pPara[loop].pSourcePath,pPara[loop].pDestPath);
        }
        else
        {
            BspFileCopy(pPara[loop].pSourcePath,pPara[loop].pDestPath);
        }
        
    }
    BspSystem("rm -rf /oemfile_m");
    BspSystem("rm -rf /oemfile_s");

    return retVal;
}

static UINT32 BspSetPowerI2cByPass(UINT32 isBypass)
{
    UINT32 i2cEnableStatus = 0;

    i2cEnableStatus = ((isBypass == 1) ? DISABLE:ENABLE);
    BspSetZx211413EnableStatus(IC4_2_I2C_BUS_ID_4, i2cEnableStatus);

    return BSP_OK;
}

UINT32 BspCfgInfoAfterPowerInit(VOID)
{
    UINT32 retval = BSP_OK;

    BspSetEepromDlyCallBackInit(BspSetEepromPageDly); /*eeprom page页切换需要延时*/
    BspSetPowerI2cByPassCallBack(BspSetPowerI2cByPass);

    return retval;
}

UINT32 BspDpdicPwrSavePreInit(void)
{
    UINT32 retVal = BSP_OK;
    T_DpdicPwrSaveSel *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_PWRSAVE_PRE,0,0,pPara,num);
    (VOID)BspHalAdaptSetPwrSaveCfg(E_IC_PWRSAVE_NORMAL_SEL,pPara);

    pPara = NULL;
    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_PWRSAVE_PRE,0,1,pPara,num);
    (VOID)BspHalAdaptSetPwrSaveCfg(E_IC_PWRSAVE_DEEPSLEEP_SEL,pPara);

    return retVal;
}

UINT32 BspDpdicPwrSaveInit(void)
{
    UINT32 retVal = BSP_OK;
    T_DpdicPwrSaveSel *pPara = NULL;
    UINT32 num = 0;
    
    (VOID)BspBoardModleGetData(E_CHIP_POWERON_DPDIC_PWRSAVE, 0, 0, (VOID**)(&pPara), &(num));
    (VOID)BspHalAdaptSetPwrSaveCfg(E_IC_PWRSAVE_NORMAL_SEL,pPara);
    retVal = BspHalAdaptPwrSavePreInit();

    pPara = NULL;
    (VOID)BspBoardModleGetData(E_CHIP_POWERON_DPDIC_PWRSAVE, 0, 1, (VOID**)(&pPara), &(num));
    (VOID)BspHalAdaptSetPwrSaveCfg(E_IC_PWRSAVE_DEEPSLEEP_SEL,pPara);

    pPara = NULL;
    (VOID)BspBoardModleGetData(E_CHIP_POWERON_DPDIC_PWRSAVE, 0, 2, (VOID**)(&pPara), &(num));
    (VOID)BspHalAdaptSetPwrSaveCfg(E_IC_PWRSAVE_ALLCARROFF_SEL,pPara);   

    pPara = NULL;
    (VOID)BspBoardModleGetData(E_CHIP_POWERON_DPDIC_PWRSAVE, 0, 3, (VOID**)(&pPara), &(num));
    (VOID)BspHalAdaptSetPwrSaveCfg(E_IC_PWRSAVE_QCELL_PB_SEL,pPara);

    pPara = NULL;
    (VOID)BspBoardModleGetData(E_CHIP_POWERON_DPDIC_PWRSAVE, 0, 4, (VOID**)(&pPara), &(num));
    (VOID)BspHalAdaptSetPwrSaveCfg(E_IC_PWRSAVE_QCELL_BBU_SEL,pPara);

    return retVal;
}

UINT32 BspDpdicPwrSavePostInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptPwrSavePostInit();

    return retVal;
}

static BOOL IsRruPaBdNameCmpSucc(const char *pCompPaBdName)
{
    char paBoardName[BAR_MAX_LENGTH] = {0};
    UINT32 paChan = 0;

    if (pCompPaBdName == NULL)
    {
        dbgErr("%s:Input Pointer is NULL!", __FUNCTION__);
        return FALSE;
    }

    BspGetPaBoardName(paChan, paBoardName, BAR_MAX_LENGTH);
    if (strncmp(paBoardName, pCompPaBdName, BAR_MAX_LENGTH) == 0)
    {
        return TRUE;
    }
    dbgInfo("%s:This PA does not require move table file!", __FUNCTION__);

    return FALSE;
}

UINT32 BspRfTblFileMoveInit(void)
{
    UINT32 retVal = BSP_OK;
    T_RfTblFileMoveList *pPara = NULL;
    UINT32 num = 0;
    UINT32 fileNum = 0;
    UINT32 loop = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_RFTBL_FILE_MOVE, 0, 0, pPara, num);
    INPUT_POINTER_CHECK(pPara);

    if (pPara->isSupportChkPaBdName == SUPPORT)
    {
        if ((!IsRruPaBdNameCmpSucc(pPara->pMoveTblPaBoardName1)) &&
            (!IsRruPaBdNameCmpSucc(pPara->pMoveTblPaBoardName2)))
        {
            return BSP_OK;
        }
    }

    retVal = BspRruProductTimeCompare(pPara->compareTime);
    if(BSP_OK == retVal)
    {
        fileNum = pPara->fileNum;
        for(loop = 0; loop < fileNum; loop++)
        {
            BspFileCopy(pPara->pRfTblSourcePath[loop], pPara->pRfTblAtaCaliDestPath[loop]);
            BspFileCopy(pPara->pRfTblSourcePath[loop], pPara->pRfTblTmpCaliDestPath[loop]);
        }
    }

    return retVal;
}

UINT32 BspCpriModeSwitchFuncInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_CPRI_MODE_SWITCH_FUNC_INIT, 0, 0, pPara, num);
    retVal = BspSetCpriModeSwitchCfgFunc((T_CpriModeSwitchCfgFunc*)pPara);
    return retVal;
}

UINT32 BspCpriModeSwitchParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_CPRI_MODE_SWITCH_PARA_INIT, 0, 0, pPara, num);
    retVal = BspSetLaneRoutePara((T_CpriModeLaneRoutePara*)pPara,num);
    return retVal;
}

VOID socinitcpripara(VOID)
{
    BspCpriModeSwitchFuncInit();
}
#ifdef MULT_PROGRESS_S
static T_FileMoveList s_tBoardCfgFileMoveList[] =
{
    {FILE_MOVE_SLAVE_BOARD_CFG_FILE_SOURCE_PATH,FILE_MOVE_MASTER_BOARD_CFG_FILE_DEST_PATH},
    {FILE_MOVE_SLAVE_APP_BOARD_CFG_FILE_SOURCE_PATH,FILE_MOVE_MASTER_APP_BOARD_CFG_FILE_DEST_PATH},
};
#else
static T_FileMoveList s_tBoardCfgFileMoveList[] =
{
    {FILE_MOVE_MASTER_BOARD_CFG_FILE_SOURCE_PATH,FILE_MOVE_MASTER_BOARD_CFG_FILE_DEST_PATH},
    {FILE_MOVE_MASTER_APP_BOARD_CFG_FILE_SOURCE_PATH,FILE_MOVE_MASTER_APP_BOARD_CFG_FILE_DEST_PATH},
};
#endif
UINT32 BspBoardCfgFileMoveInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_FileMoveList *pPara = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;
    CHAR cmd[256] = {0};
    int ret = 0;
    UINT32 fileRet = 0;

    pPara = s_tBoardCfgFileMoveList;
    num = NELEMENTS(s_tBoardCfgFileMoveList);
    dbgInfo("%s >> %d >> %s!\n", __FUNCTION__, __LINE__, "start!!!");
    for(loop = 0; loop < num; loop++)
    {
        fileRet = BSP_OK;
        /* 如果源目录不存在，则调过 */
        if(BSP_OK != BspIsFileExist(pPara[loop].pSourcePath))
        {
            fileRet |= BSP_ERROR;
            continue;
        }
        (VOID)memset_s((VOID*)cmd, sizeof(cmd), 0, sizeof(cmd));
        /* 如果目的目录不存在，则创建目录并移动文件 */
        if(BSP_OK != BspIsFileExist(pPara[loop].pDestPath))
        {
            ret = snprintf_s(cmd, sizeof(cmd), "mkdir -p %s && mv %s/* %s",
                             pPara[loop].pDestPath, pPara[loop].pSourcePath, pPara[loop].pDestPath);
            if(ret < (INT32)0 || ret > sizeof(cmd))
            {
                dbgErr("%s snprintf_s error \n", __FUNCTION__);
                fileRet |= BSP_ERROR;
                continue;
            }
            BspSystem(cmd);
        }
        /* 如果目的目录已存在，则直接移动文件 */
        else
        {
            ret = snprintf_s(cmd, sizeof(cmd), "mv %s/* %s",
                             pPara[loop].pSourcePath, pPara[loop].pDestPath);
            if(ret < (INT32)0 || ret > sizeof(cmd))
            {
                dbgErr("%s snprintf_s error \n", __FUNCTION__);
                fileRet |= BSP_ERROR;
                continue;
            }
            BspSystem(cmd);
        }
        dbgInfo("%s >> %d >> pSourcePath: %s, pDestPath: %s, ret=%d\n",
                     __FUNCTION__, __LINE__, pPara[loop].pSourcePath, pPara[loop].pDestPath, fileRet);
    }
    retVal |= fileRet;
    dbgInfo("%s >> %d >> %s!\n", __FUNCTION__, __LINE__, "end!!!");
    return retVal;
}

UINT32 BspUpdatePaDacSetParaInit(VOID)
{
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;
    T_PaDasSetVal *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_UPDATE_PADACSET_PARA, 0, 0, pPara, num);
    INPUT_POINTER_CHECK(pPara);

    retVal = BspUpdatePaDacSetPara(pPara, num);

    return retVal;
}

/* Started by AICoder, pid:i0ca3qa52a5961914230098a6058c5130295f387 */
UINT32 BspUpdateQcellPaDacSetParaInit(VOID)
{
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;
    T_PaDasSetQVal *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_UPDATE_QCELL_PADACSET_PARA, 0, 0, pPara, num);
    INPUT_POINTER_CHECK(pPara);

    retVal = BspUpdateQcellPaDacSetPara((T_PaDasSetQVal *)pPara, num);

    return retVal;
}
/* Ended by AICoder, pid:i0ca3qa52a5961914230098a6058c5130295f387 */
UINT32 BspModifyDefaultPaVolt(void)
{
    UINT32 retVal = BSP_OK;
    T_ModifyPaVolt *pPara = NULL;
    UINT32 num = 0;
    UINT32 chanNum = 0;
    UINT32 loop = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_MODIFY_PA_VOLT, 0, 0, pPara, num);
    INPUT_POINTER_CHECK(pPara);

    retVal = BspRruProductTimeRangeCompare(pPara->compareTimeMin, pPara->compareTimeMax);
    if(BSP_OK == retVal)
    {
        chanNum = BspGetTxChannel();
        BspSetReducePaVoltFlag(SUPP_REDUCE_PA_VOLT);
        BspSetPaVoltDelt(pPara->fixVolt);
        for(loop = 0; loop < chanNum; loop++)
        {
            BspSetFwdDbmDelta(loop, pPara->reducePow);
        }
    }

    return retVal;
}

/*拼接MO版本  在从片复位和加载之前要完成*/
UINT32 BspSwitchSpareLaneInit(VOID)
{
    UINT32 retVal = BSP_ERROR;
    FILE *pFile = NULL;
    UINT32 offset = 0;
    T_CpriModeLaneRoutePara *laneRoute = NULL;
    UINT32 routePath = 0;
    UINT32 inDependentFlag = 0xf;

    BspGetCpriModeIndependentFlag(&inDependentFlag);
    BspLog(LOG_LEVEL_0, "%s inDependentFlag %d\n", __func__, inDependentFlag);
    if(0 != inDependentFlag)
    {
        return BSP_OK;
    }
    laneRoute = malloc(sizeof(T_CpriModeLaneRoutePara));
    if(NULL == laneRoute)
    {
        return BSP_ERROR;
    }
    memset_s(laneRoute, sizeof(T_CpriModeLaneRoutePara), 0, sizeof(T_CpriModeLaneRoutePara));
    retVal = BspGetCpriModeLaneRoutePath(&routePath);
    if(BSP_ERROR == retVal)
    {
        free(laneRoute);
        return BSP_ERROR;
    }

    retVal = BspGetOptCpriModePathLaneRoutePara(routePath, laneRoute);
    if(BSP_ERROR == retVal)
    {
        free(laneRoute);
        return BSP_ERROR;
    }
    laneRoute->crc = CalculateCRC16(CRC_MASK, (UINT8 *)laneRoute + sizeof(laneRoute->crc), sizeof(T_CpriModeLaneRoutePara) - sizeof(laneRoute->crc));
    pFile = fopen(g_ramBootFileName, "rb+");
    if (NULL == pFile)
    {
        dbgErr("%s>>Can't Open file: %s\n",__FUNCTION__,g_ramBootFileName);
        free(laneRoute);
        return BSP_ERROR;
    }

    (VOID)fseek(pFile, offset, SEEK_END);
    (VOID)fwrite(laneRoute, sizeof(T_CpriModeLaneRoutePara), 1, pFile);
    free(laneRoute);
    (VOID)fclose(pFile);

    return retVal;
}

/* Started by AICoder, pid:9978bn5680p9e64149dc0bb8208aae526dd9f859 */
UINT32 BspGetEfuseInfo(T_EfuseInfo *pEfuseInfo)
{
    UINT32 crcAteCp1 = 0;
    UINT32 chipVer = 0;
    UINT32 dieAddr_x = 0;
    UINT32 dieAddr_y = 0;
    UINT32 lotLow  = 0;
    UINT32 lotMid  = 0;
    UINT32 lotHigh = 0;
    UINT64 lotId = 0;
    UINT32 waferNo = 0;
    UINT32 timeLow = 0;
    UINT32 timeHigh = 0;
    UINT64 testTime = 0;
    time_t time = {0};
    struct tm* pTimeinfo = NULL;

    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x900, &crcAteCp1, 0, 7);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x900, &chipVer, 8, 11);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x900, &dieAddr_x, 12, 19);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x900, &dieAddr_y, 20, 27);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x900, &lotLow, 28, 31);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x904, &lotMid, 0, 31);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x908, &lotHigh, 0, 11);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x908, &waferNo, 12, 16);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x910, &timeLow, 25, 31);
    IcHalBitRdReg(0, BSP_EFUSE_REGINFO, 0x914, &timeHigh, 0, 24);
    lotId = ((UINT64)lotHigh << 36) | ((UINT64)lotMid << 4) | (UINT64)lotLow;
    testTime = (timeHigh << 7) | timeLow;
    time = (time_t)testTime;
    dbgInfoEx("lotHigh:0x%03x, lotMid:0x%08x, lotLow:0x%01x, lotId:0x%012llx, timeHigh:0x%07x, timeLow:0x%02x, testTime:0x%08llx \n",
            lotHigh, lotMid, lotLow, lotId, timeHigh, timeLow, testTime);

    pTimeinfo = localtime((const time_t*)&time);
    INPUT_POINTER_CHECK(pTimeinfo);
    pTimeinfo->tm_year += 1900;
    pTimeinfo->tm_mon += 1;

    if (NULL == pEfuseInfo)
    {
        dbgInfo("crcAteCp1:0x%02x, chipVer:0x%01x, dieAddr_x:0x%02x, dieAddr_y:0x%02x, lotId:0x%012llx, waferNo:0x%02x, testTime(%u-%02u-%02u %02u:%02u:%02u)\n",
                crcAteCp1, chipVer, dieAddr_x, dieAddr_y, lotId, waferNo, pTimeinfo->tm_year,
                pTimeinfo->tm_mon, pTimeinfo->tm_mday, pTimeinfo->tm_hour, pTimeinfo->tm_min, pTimeinfo->tm_sec);
        return BSP_ERROR;
    }

    pEfuseInfo->crcAteCp1 = crcAteCp1;
    pEfuseInfo->chipVer = chipVer;
    pEfuseInfo->dieAddr_x = dieAddr_x;
    pEfuseInfo->dieAddr_y = dieAddr_y;
    pEfuseInfo->lotId = lotId;
    pEfuseInfo->waferNo = waferNo;
    pEfuseInfo->testTime.tm_year = pTimeinfo->tm_year;
    pEfuseInfo->testTime.tm_mon = pTimeinfo->tm_mon;
    pEfuseInfo->testTime.tm_mday = pTimeinfo->tm_mday;
    pEfuseInfo->testTime.tm_hour = pTimeinfo->tm_hour;
    pEfuseInfo->testTime.tm_min = pTimeinfo->tm_min;
    pEfuseInfo->testTime.tm_sec = pTimeinfo->tm_sec;

    return BSP_OK;
}
/* Ended by AICoder, pid:9978bn5680p9e64149dc0bb8208aae526dd9f859 */

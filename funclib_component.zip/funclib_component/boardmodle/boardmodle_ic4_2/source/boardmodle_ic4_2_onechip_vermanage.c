/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : bsp
 * 文件名称 : boardmodle_ic4_2.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件提供了IC4_2系列单板的例化实现
 * 注意事项 : 无
 * 作    者 :   王涛10248577
 * 创建日期 : 2022-03-23
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 王涛10248577
 * 修改日戳: 2022-03-23
 * 变更说明: 创建文件
 *----------------------------------------------------------------------------
 */

#include "boardmodle_ic4_2.h"
#include "boardmodleactinjector.h"
#include "boardcorefunc.h"
#include "digtrxlinkwrapper.h"
#include "functionwrapper.h"
#include "hardfeaturewrapperbase.h"
#include "hardfeaturewrappervermanage.h"
#include "softservicewrapperbase.h"
#include "softservicewrappervermanage.h"
#include "chippoweronwrapper.h"
#include "regaccess.h"
#include "vxadp.h"
#include "rruinfo.h"
#include "boardversionload.h"
#include "funccommon_pm.h"
/**************************************************************************
                               宏定义
**************************************************************************/

/**************************************************************************
                               结构体类型定义
**************************************************************************/
/**************************************************************************
                               函数声明
**************************************************************************/
/**************************************************************************
                               全局变量定义
**************************************************************************/

/* --------------------------------------------------------------------- */
/* ----------------------- IC4.2单板基础动作定义  ---------------------- */
/* --------------------------------------------------------------------- */
static T_BoardActFuncTbl s_BoardActFuncTbl_ic4_2_onechip_vermanage_base[] =
{
    /*  动作类型                                        动作接口                        初始化标志      */
    // 系统软件服务
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SIGNAL, BspCoreSignalInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_EXT_PRN, BspCoreInitExPrn, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_BSP_LOG, BspCoreBspLogInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_PM_INIT, PmInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_DBOOT_INIT, BspInitDbootPara, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_UDPMSGMODULE_INIT, UdpMsgModuleInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_CORE_AFFINITY_CFG, BspCoreProcAffinityInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_RECORD_HASH_VER, BspRecordHashVer, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_EFUSE_WRITE, BspInitEfuseWriteFunc, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_EFUSE_READ, BspInitEfuseReadFunc, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_SEC_CALLBACK, BspCfgSecVerifyCallBack, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_SEC_VERIFY, BspCfgSecVerifyFun, BSP_INIT_NOT_RECORD)
    // 单板硬件特性，连接关系
    BOARD_ACTION_DEF(E_HARD_FEATURE_BOARD_ID, BspCoreInitVerGroupPara, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_DEV_ID, BspCoreInitDeviceIdList, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_THRESHOLD_ID, BspCoreInitThresholdIdList, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_FUNC_ID, BspCoreInitFuncIdList, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_GAIN_ID, BspCoreInitGainIdList, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_GET_BOMID, BspGetFlashBomid, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_GET_LGC_TYPE, BspGetBoardIdFirst, BSP_INIT_NOT_RECORD)
    /* BOARD_ACTION_DEF(E_HARD_FEATURE_INIT_RRU_TYPE,     BspInitRruType,                 BSP_INIT_NOT_RECORD) */
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRU_PROPERTY, BspRruPropertyInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_FLASH_INIT, BspFlashInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_DPDIC_REG_TBL, DpdIcHalRegTblInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_REG_TBL, BspRegTblInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRUFILE_INIT, BspInitRruFileInfo, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_INIT_VER_PROTECT, BspInitVerProtect, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_INIT_PROTECT_FILELIST, BspInitProtectFileList, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CPUID_INIT, BspInitCpuAndCoreId, BSP_INIT_NOT_RECORD)

    // 周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件包含动作
    /* BOARD_ACTION_DEF(E_CHIP_POWERON_FPGA_LOAD, LoadFpgaVersion, BSP_INIT_NOT_RECORD) */
    /* BOARD_ACTION_DEF(E_CHIP_POWERON_BOARDRESET_CALLBACK, BspResetDeviceInit, BSP_INIT_NOT_RECORD) */
    /* BOARD_ACTION_DEF(E_FUNCTION_LINKPWROFF_ENABLE,     RruLinkPwrOffEnable,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_LINKPWROFF_INIT,       RruLinkPwrOffInit,              BSP_INIT_NOT_RECORD) */
};

/* ========================================================================================================= */
/* ============================= 单片版本 ================================================================== */
/* ========================================================================================================= */

/* --------------------------------------------------------------------- */
/* ----------------------- one-chip动作差异定义  ----------------------- */
/* --------------------------------------------------------------------- */
static T_BoardActFuncTbl s_BoardActFuncTbl_ic4_2__onechip_vermanage[] =
{
    /*  动作类型                                        动作接口                        初始化标志      */
};

/* --------------------------------------------------------------------- */
/* -------------------------- 预初始化流程定义  ------------------------ */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardPreInitFlow_ic4_2__onechip_vermanage[] =
{
    {E_SOFT_SERVICE_EXT_PRN, "BspCoreInitExPrn"},
    {E_SOFT_SERVICE_SIGNAL, "BspCoreSignalInit"},
    {E_SOFT_SERVICE_BSP_LOG, "BspCoreBspLogInit"},
    {E_HARD_FEATURE_FLASH_INIT, "BspFlashInit"},
    /* { E_FUNCTION_LINKPWROFF_ENABLE,     "RruLinkPwrOffEnable"}, */
#ifndef PLAT_X86_TEST
    {E_SOFT_SERVICE_DBOOT_INIT, "BspInitDbootPara"},
#endif
    {E_HARD_FEATURE_INIT_VER_PROTECT, "BspInitVerProtect"},
    {E_SOFT_SERVICE_PM_INIT, "BspCorePmInit"},
    {E_HARD_FEATURE_DPDIC_REG_TBL, "DpdIcHalRegTblInit"},
    /* {E_CHIP_POWERON_BOARDRESET_CALLBACK, "BspResetDeviceInit"}, */
    {E_HARD_FEATURE_DEV_ID, "BspCoreInitDeviceIdList"},
    {E_HARD_FEATURE_THRESHOLD_ID, "BspCoreInitThresholdIdList"},
    {E_HARD_FEATURE_FUNC_ID, "BspCoreInitFuncIdList"},
    {E_HARD_FEATURE_GAIN_ID, "BspCoreInitGainIdList"},
    {E_HARD_FEATURE_GET_BOMID, "BspGetFlashBomid"},
    /*BspCoreInitVerGroupPara需要放在BspInitRruFileInfo之前，后者要使用s_VerGroup*/
    {E_HARD_FEATURE_BOARD_ID, "BspCoreInitVerGroupPara"},
    /*需要区分boardid的动作，必须放在本动作后 */
    {E_HARD_FEATURE_GET_LGC_TYPE, "BspGetBoardIdFirst"},
    /*BspRruPropertyInit需要放在BspInitRruFileInfo之前，rruinfo解析要使用rruproperty中的通道数,BspGetTxChannel*/
    {E_HARD_FEATURE_RRU_PROPERTY, "BspRruPropertyInit"},
    {E_HARD_FEATURE_RRUFILE_INIT, "BspInitRruFileInfo"},
    {E_HARD_FEATURE_INIT_PROTECT_FILELIST, "BspInitProtectFileList"},
#ifndef PLAT_X86_TEST
    {E_HARD_FEATURE_REG_TBL, "BspRegTblInit"},
    /* 需要保证所有启线程的动作都在此动作之后，否则无法继承绑定0核 */
    {E_SOFT_SERVICE_CORE_AFFINITY_CFG, "BspCoreProcAffinityInit"},
    {E_SOFT_SERVICE_UDPMSGMODULE_INIT, "UdpMsgModuleInit"},
#endif

    {E_SOFT_SERVICE_INIT_EFUSE_WRITE, "BspInitEfuseWriteFunc"},
    {E_SOFT_SERVICE_INIT_EFUSE_READ, "BspInitEfuseReadFunc"},
    {E_SOFT_SERVICE_INIT_SEC_CALLBACK, "BspCfgSecVerifyCallBack"},
    {E_SOFT_SERVICE_INIT_SEC_VERIFY, "BspCfgSecVerifyFun"},
};

/* --------------------------------------------------------------------- */
/* --------------------------- 初始化流程定义 -------------------------- */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardInitFlow_ic4_2__onechip_vermanage[] =
{
#ifndef PLAT_X86_TEST
    {E_SOFT_SERVICE_RECORD_HASH_VER, "BspRecordHashVer"},
    /* {E_CHIP_POWERON_FPGA_LOAD, "LoadFpgaVersion"}, */
#endif
    //{ E_CHIP_POWERON_DPDIC_CBSW_PINSW_PARA,       "BspCbSwPinTblParaInit" },
    {E_HARD_FEATURE_CPUID_INIT, "BspInitCpuAndCoreId"},
    /* { E_FUNCTION_LINKPWROFF_INIT,        "RruLinkPwrOffInit"}, */
};

static T_ModleInitItem modleItem_ic4_2_onechip_vermanage =
{
    s_BoardActFuncTbl_ic4_2_onechip_vermanage_base, NELEMENTS(s_BoardActFuncTbl_ic4_2_onechip_vermanage_base),
    s_BoardActFuncTbl_ic4_2__onechip_vermanage, NELEMENTS(s_BoardActFuncTbl_ic4_2__onechip_vermanage),
    s_BoardPreInitFlow_ic4_2__onechip_vermanage, NELEMENTS(s_BoardPreInitFlow_ic4_2__onechip_vermanage),
    s_BoardInitFlow_ic4_2__onechip_vermanage, NELEMENTS(s_BoardInitFlow_ic4_2__onechip_vermanage)
};

/**************************************************************************
                            自举接口
**************************************************************************/
static __attribute((constructor)) void BoardModleIc4_2_OneChipVerManageInit()
{
    BspSetModelItem(E_BOARD_ONE_CHIP_VER_MANAGE_TYPE, &modleItem_ic4_2_onechip_vermanage);
}


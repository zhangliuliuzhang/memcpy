/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeaturewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "rftable.h"
#include "rftable_common.h"
#include "boardmodlecommon.h"

#include "rruinfo.h"
#include "rftableinit.h"
#include "funccommon_a.h"
#include "exprn.h"

static T_RfTblFileMenu *s_pRfTblFile = NULL;
static UINT32           s_uFileNum   = 0;
static T_RfTblConvert  *s_RfTblConvert = NULL;
static UINT32           s_uConvertNum   = 0;
static T_RfTblChipMap *s_RfTblChipMap = NULL;
static UINT32           s_uChipMapNum   = 0;

UINT32 g_ulRfTblLoadRec = 0;

UINT32 GetRfTblConvertValByChanPro(UINT32 ulLoop, UINT32 ulChanPro,UINT32 *pSubFileNo,UINT32 *pIniChan, UINT32 *pChanNum, UINT32 *pDstChan)
{
    UINT32 ulRecLoop = 0;
    if( (NULL == pIniChan) || (NULL == pChanNum) ||(NULL == pSubFileNo) || (NULL == pDstChan))
    {
        return BSP_ERROR;
    }

    for(ulRecLoop=0; ulRecLoop<CHAN_PRO_MAX; ulRecLoop++)
    {
        if(ulChanPro == s_RfTblConvert[ulLoop].tChanPro[ulRecLoop].ulChanPro)
        {
            *pIniChan = s_RfTblConvert[ulLoop].tChanPro[ulRecLoop].ulIniChan;
            *pChanNum = s_RfTblConvert[ulLoop].tChanPro[ulRecLoop].ulChanNum;
            *pSubFileNo = s_RfTblConvert[ulLoop].tChanPro[ulRecLoop].ulSubFileNo;
            *pDstChan = s_RfTblConvert[ulLoop].tChanPro[ulRecLoop].dstChan;
            break;
        }
    }
    return BSP_OK;
}

UINT32 BspRfTblConvert(UINT32 ulFileInex, UINT32 ulRpuId, UINT32 ulChanPro)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulLoop = 0;
    UINT32 ulSubFileNo = 0;
    UINT32 ulIniChan = 0;
    UINT32 ulChanNum = 0;
    UINT32 ulDestChan = 0;

    for( ulLoop=0; ulLoop<s_uConvertNum; ulLoop++ )
    {
        if(ulRpuId != s_RfTblConvert[ulLoop].ulRpuId)
        {
            continue;
        }
        ulRetVal |= GetRfTblConvertValByChanPro(ulLoop,ulChanPro,&ulSubFileNo,&ulIniChan,&ulChanNum,&ulDestChan);
        if (BspGetSubFileExistStatus(TBL_KIND_OF_PADACSET,ulSubFileNo) != BSP_OK)
        {
            dbgInfo("%s>> ------------ subfileno:%d not exist!------------- \r\n",__func__,ulSubFileNo);
            continue;
        }

        s_pRfTblFile[ulFileInex].pTblConvert(ulSubFileNo,ulIniChan,ulDestChan,ulChanNum);
        dbgInfo("%s ulSubFileNo %d ulFileInex %d ulIniChan %d ulDestChan %d ulChanNum %d\n", __FUNCTION__,ulSubFileNo,ulFileInex,ulIniChan,ulDestChan,ulChanNum);
    }

    return ulRetVal;
}



UINT32 BspPaDacChipMap(VOID)
{
    UINT32 ulLoop = 0;
    UINT32 ulRpuId = 0;
    UINT32 subFileNo = 0;

    ulRpuId = BspGetRpuId();
    for( ulLoop=0; ulLoop<s_uChipMapNum; ulLoop++ )
    {
        if( s_RfTblChipMap[ulLoop].ulAbsoluteChip == s_RfTblChipMap[ulLoop].ulRelativeChip )
        {
            continue;
        }

        subFileNo = s_RfTblChipMap[ulLoop].ulSubFileNo;
        if (BspGetSubFileExistStatus(TBL_KIND_OF_PADACSET,subFileNo) != BSP_OK)
        {
            dbgInfo("%s>> ------------PaDacSet subfileno:%d not exist!------------- \r\n",__func__,subFileNo);
            continue;
        }

        if( ulRpuId == s_RfTblChipMap[ulLoop].ulRpuId )
        {
            _BspPaDacSetChipMap(s_RfTblChipMap[ulLoop].ulSubFileNo,
                    s_RfTblChipMap[ulLoop].ulAbsoluteChip,
                    s_RfTblChipMap[ulLoop].ulRelativeChip );
        }
    }

    return BSP_OK;
}


UINT32 BspGetRfTblInitParam(UINT32 ulFileType, UINT32 uProp, T_CaliTblInitParam *ptParam)
{
    UINT32 ulLoop = 0;
    INT32  lMin = -10000000, lMax = 10000000;
    UINT32 ulPaNum = 0;

    BspAdpGetRruPaNum(&ulPaNum);
    ptParam->ulTxChanNum = BspGetTxChannel();
    ptParam->ulRxChanNum = BspGetRxChannel();
    ptParam->ulPaPhyNum  = ulPaNum;
    if(E_PROP_PA != uProp)
    {
        ptParam->ulSubNum    = 1;
    }
    else
    {
        ptParam->ulSubNum    = ulPaNum;
    }

    for (ulLoop = 0; ulLoop < NELEMENTS(ptParam->lValMin); ulLoop++)
    {
        ptParam->lValMin[ulLoop] = lMin;
        ptParam->lValMax[ulLoop] = lMax;
    }

    ptParam->ulCaliLoadPath = BspGetCaliTblLoadLocation();
    return BSP_OK;
}

UINT32 BspGetRfTblInitFile(T_CaliTblInitFile *ptFileInfo)
{
    T_CaliTblInitParam tInitParam = {0};
    UINT32 ulIdx;
    T_TextTrans tText = {0};
    UINT32 ulFileNum = s_uFileNum;

    ulFileNum = min(ulFileNum, NUM_TBL_KIND_NUM);
    ptFileInfo->ulFileNum = ulFileNum;
    for (ulIdx = 0; ulIdx < ulFileNum; ulIdx++)
    {
        BspGetRfTblInitParam(s_pRfTblFile[ulIdx].ulFileType,s_pRfTblFile[ulIdx].ulFileProp, &tInitParam);

        ptFileInfo->FileMenu[ulIdx]     = s_pRfTblFile[ulIdx].ulFileType;
        ptFileInfo->SubFileNum[ulIdx]   = s_pRfTblFile[ulIdx].ulSubFileNum;
        ptFileInfo->FilePaths[ulIdx][0] = (BspGetCaliTblLoadLocation()==TBL_FILE_SYS)?TBL_FILE_SYS:TBL_PROPECT_SYS;
        ptFileInfo->FilePaths[ulIdx][1] = (BspGetCaliTblLoadLocation()==TBL_FILE_SYS)?TBL_PROPECT_SYS:TBL_FILE_SYS;
        ptFileInfo->IsErrAlm[ulIdx]     = s_pRfTblFile[ulIdx].ulIsErrAlm;
        if(E_PROP_BOARD == s_pRfTblFile[ulIdx].ulFileProp)
        {
            tInitParam.ulSubNum    = s_pRfTblFile[ulIdx].ulSubFileNum;   /*单板下指定此类校准表的个数  用来判断是否支持多校准表*/
        }
        memcpy(&ptFileInfo->InitParam[ulIdx], &tInitParam, sizeof(tInitParam));
        memset(&tText,0,sizeof(tText));
        snprintf(tText.acFileName,sizeof(tText.acFileName),"%s",s_pRfTblFile[ulIdx].pAtaFile);
        snprintf(tText.acFileNameInProcFile,sizeof(tText.acFileNameInProcFile),"%s",s_pRfTblFile[ulIdx].pFsFile);
        snprintf(tText.acFileNameInSysFile,sizeof(tText.acFileNameInSysFile),"%s",s_pRfTblFile[ulIdx].pAtaFile);
        _BspSetRfTblTextTrans(s_pRfTblFile[ulIdx].ulFileType, &tText);
    }

    return BSP_OK;
}

UINT32 BspSetRfConvertTbl(T_RfTblConvert *pPara, UINT32 num)
{
    s_RfTblConvert = pPara;
    s_uConvertNum = num;
    return BSP_OK;
}

UINT32 BspSetRfChipMapTbl(T_RfTblChipMap *pPara, UINT32 num)
{
    s_RfTblChipMap = pPara;
    s_uChipMapNum = num;
    return BSP_OK;
}


UINT32 BspRfTblLoad(T_RfTblFileMenu *pPara, UINT32 num)

{
    UINT32 retVal = BSP_OK;
    UINT64 almMaskVal = BSP_OK;
    UINT32 ulIdx = 0;
    T_CaliTblInitFile* pTInitFile = NULL;

    s_pRfTblFile = pPara;
    s_uFileNum = num;

    pTInitFile = (T_CaliTblInitFile*)malloc(sizeof(T_CaliTblInitFile));
    if(NULL != pTInitFile)
    {
        BspGetRfTblInitFile(pTInitFile); //参数初始化
        almMaskVal = _BspCalibTblInit(pTInitFile);//获取值

        for (ulIdx = 0; ulIdx < s_uFileNum; ulIdx++)
        {
            if (almMaskVal & BIT64_SET(s_pRfTblFile[ulIdx].ulFileType))
            {
                s_pRfTblFile[ulIdx].ulLoadState = TBL_LOAD_FAIL;
            }
            else
            {
                s_pRfTblFile[ulIdx].ulLoadState = TBL_LOAD_SUCC;
                if( NULL != s_pRfTblFile[ulIdx].pTblConvert )
                {

                    retVal |= BspRfTblConvert(ulIdx, BspGetRpuId(), s_pRfTblFile[ulIdx].ulChanPro);
                    if( TBL_KIND_OF_PADACSET == s_pRfTblFile[ulIdx].ulFileType )
                    {
                     /*栅压校准表的特殊处理*/
                        BspPaDacChipMap();
                    }
                }
            }
        }
        free(pTInitFile);
    }
    else
    {
        retVal = BSP_ERROR;
    }


    return retVal;
}

/*一拖三机型子端不建链时将对应校准表状态置为ok*/
/* Started by AICoder, pid:f1e57ga78b0a7e5148320823800b932063b58ffa */
VOID BspClrRfTblLoadStaBySlavePortCfg(UINT32 portId )
{
    UINT32 portSta = 0;
    UINT32 ulIdx = 0;    /*单板初始化参数里表的类型个数遍历*/

    if(0 != g_ulRfTblLoadRec)
    {
         BspSysMsDelay(100);    /*防止不同子端同时访问这个字符串*/
    }
    g_ulRfTblLoadRec = 1;
    for (ulIdx = 0; ulIdx < s_uFileNum; ulIdx++)
    {
        portSta = BspGetSlavePortStatus(portId);
        dbgInfoEx("%s>>portSta=%d\n",__FUNCTION__, portSta);
        if(0 != portSta)
        {
            BspSetRfTblLoadSta(s_pRfTblFile[ulIdx].ulFileType, portId+2, 0);
            BspClearSlaveCaliFileAlarmLoadString(portId+2);
       }
    }
    g_ulRfTblLoadRec = 0;
}
/* Ended by AICoder, pid:f1e57ga78b0a7e5148320823800b932063b58ffa */
/*一拖三机型保留母端的校准表加载状态*/
/* Started by AICoder, pid:iab6ev8db7o8c43149270a5f50b4240b3c753d0b */
VOID BspInitSlaveRfTblLoadSta(VOID)
{
    UINT32 ulIdx = 0;    /*单板初始化参数里表的类型个数遍历*/
    UINT32 subFileIndex = 0;  /*每一类表中具体表的个数遍历*/
    UINT64 fileLoadSta = 0;  /*按类型上报校准表是否异常，多个相同表有一个异常即异常*/

    if(0 != g_ulRfTblLoadRec)
    {
         BspSysMsDelay(100);    /*防止不同子端同时访问这个字符串*/
    }
    g_ulRfTblLoadRec = 1;
    BspClearCaliFileAlarmLoadString();   /*将整机初始化的记录去掉最开始的记录不保存编号信息 只能调用一次*/
    for (ulIdx = 0; ulIdx < s_uFileNum; ulIdx++)
    {
        if((s_pRfTblFile[ulIdx].ulSubFileNum < 2)||(TBL_KIND_OF_PADACSET == s_pRfTblFile[ulIdx].ulFileType))    /*只有母端有1个表的 或者多个表但是母端无编号*/
        {
            fileLoadSta = BspGetRfTblLoadSta(s_pRfTblFile[ulIdx].ulFileType, 0);
            if(s_pRfTblFile[ulIdx].ulIsErrAlm && (BSP_OK != fileLoadSta))   /*ulIsErrAlm表示的是是否上报告警*/
            {
                BspSetCaliFileAlarmString(s_pRfTblFile[ulIdx].ulFileType, 1);
                BspSetCaliFileLoadString(s_pRfTblFile[ulIdx].ulFileType, 1);
            }
        }
        else    /*多张表的  保留母端表解析的结果（编号小于2） 子端的表在线更新*/
        {
            for(subFileIndex = 0; subFileIndex < 2; subFileIndex ++)
            {
                fileLoadSta = BspGetRfTblLoadSta(s_pRfTblFile[ulIdx].ulFileType, subFileIndex);
                if(s_pRfTblFile[ulIdx].ulIsErrAlm && (BSP_OK != fileLoadSta))   /*ulIsErrAlm表示的是是否上报告警*/
                {
                    dbgInfoEx("ulFileType %d subFileIndex %d \n",s_pRfTblFile[ulIdx].ulFileType,subFileIndex);
                    BspSetCaliFileAlarmStringByIndex(s_pRfTblFile[ulIdx].ulFileType, 1, subFileIndex, s_pRfTblFile[ulIdx].ulSubFileNum);
                    BspSetCaliFileLoadString(s_pRfTblFile[ulIdx].ulFileType, 1);
                }
            }
        }
    }
    g_ulRfTblLoadRec = 0;
}
/* Ended by AICoder, pid:iab6ev8db7o8c43149270a5f50b4240b3c753d0b */

/*一拖三机型更新校准表加载状态，1子端不在线断链时不上报对应子端的告警 2支持按类型按编号上报告警*/
/* Started by AICoder, pid:6bc43ab26343cc914ebe081020b9ed0f3cf64be7 */
UINT32 BspSetRfTblLoadStaBySlavePortCfg(UINT32 portId)
{
    UINT32 retVal = 0;
    UINT32 ulIdx = 0;    /*单板初始化参数里表的类型个数遍历*/
    UINT32 subFileIndex = 0;  /*每一类表中具体表的个数遍历*/
    UINT64 fileLoadSta = 0;  /*按类型上报校准表是否异常，多个相同表有一个异常即异常*/
    UINT64 subFileLoadSta = 0;  /*每一张表是否正常，相同类型不同编号时分别上报*/

    if(0 != g_ulRfTblLoadRec)
    {
         BspSysMsDelay(100);
    }
    g_ulRfTblLoadRec = 1;
    for (ulIdx = 0; ulIdx < s_uFileNum; ulIdx++)
    {
        subFileLoadSta = 0;

        for(subFileIndex = 0; subFileIndex < s_pRfTblFile[ulIdx].ulSubFileNum; subFileIndex ++)
        {
            fileLoadSta |= BspGetRfTblLoadSta(s_pRfTblFile[ulIdx].ulFileType, subFileIndex);
        }

        if(fileLoadSta & BIT64_SET(s_pRfTblFile[ulIdx].ulFileType))
        {
            s_pRfTblFile[ulIdx].ulLoadState = TBL_LOAD_FAIL;
        }
        else
        {
            s_pRfTblFile[ulIdx].ulLoadState = TBL_LOAD_SUCC;
        }

        if(s_pRfTblFile[ulIdx].ulIsErrAlm && (fileLoadSta & BIT64_SET(s_pRfTblFile[ulIdx].ulFileType)))
        {
            for(subFileIndex = 2; subFileIndex < s_pRfTblFile[ulIdx].ulSubFileNum; subFileIndex ++)
            {
                subFileLoadSta = BspGetRfTblLoadSta(s_pRfTblFile[ulIdx].ulFileType, subFileIndex);
                if((BSP_OK != subFileLoadSta)&&(subFileIndex == (portId+2)))
                {
                    dbgInfoEx("ulFileType %d subFileIndex %d \n",s_pRfTblFile[ulIdx].ulFileType,subFileIndex);
                    BspSetCaliFileAlarmStringByIndex(s_pRfTblFile[ulIdx].ulFileType, 1, subFileIndex, s_pRfTblFile[ulIdx].ulSubFileNum);
                    BspSetCaliFileLoadString(s_pRfTblFile[ulIdx].ulFileType, 1);
                }
            }
        }
    }
    g_ulRfTblLoadRec = 0;

    return retVal;
}
/* Ended by AICoder, pid:6bc43ab26343cc914ebe081020b9ed0f3cf64be7 */

UINT32 BspRenamePaTbl(UINT32 index)
{
    UINT32 idx = 0;
    UINT32 fileNum = s_uFileNum;
    char   cmd[256] = {0};
    char   aucTmpName[128] = {0};
    const CHAR *pBuf = NULL;
    INT32  snpRet = 0;

    for (idx = 0; idx < fileNum; idx++)
    {
        if((E_PROP_PA == s_pRfTblFile[idx].ulFileProp) && (2 ==  s_pRfTblFile[idx].ulSubFileNum))
        {
            if(0 == access(s_pRfTblFile[idx].pAtaFile, F_OK))
            {
                pBuf = strstr(s_pRfTblFile[idx].pAtaFile, ".txt");
                if(pBuf == NULL)
                {
                    return BSP_ERROR;
                }
                //coverity[cert_str30_c_violation:SUPPRESS]
                memcpy_s(aucTmpName, (uintptr_t)pBuf - (uintptr_t)s_pRfTblFile[idx].pAtaFile, s_pRfTblFile[idx].pAtaFile, (uintptr_t)pBuf - (uintptr_t)s_pRfTblFile[idx].pAtaFile);
                snpRet = snprintf_s(cmd, sizeof(cmd), "mv %s %s%d%s ", s_pRfTblFile[idx].pAtaFile,aucTmpName, index, ".txt");
                SNPRINTF_S_CHECK(snpRet,sizeof(cmd));
                BspSystem(cmd);
                memset(aucTmpName,0,128);
            }
            if (0 == access(s_pRfTblFile[idx].pFsFile, F_OK))
            {
                pBuf = strstr(s_pRfTblFile[idx].pFsFile, ".txt");
                if(pBuf == NULL)
                {
                    return BSP_ERROR;
                }
                //coverity[cert_str30_c_violation:SUPPRESS]
                memcpy_s(aucTmpName, (uintptr_t)pBuf - (uintptr_t)s_pRfTblFile[idx].pFsFile, s_pRfTblFile[idx].pFsFile, (uintptr_t)pBuf - (uintptr_t)s_pRfTblFile[idx].pFsFile);
                snpRet = snprintf_s(cmd, sizeof(cmd), "mv %s %s%d%s\0", s_pRfTblFile[idx].pFsFile, aucTmpName, index, ".txt");
                SNPRINTF_S_CHECK(snpRet,sizeof(cmd));
                BspSystem(cmd);
                memset(aucTmpName,0,128);
            }
        }
    }

    return BSP_OK;
}

UINT32 BspGetCaliFileAlarmedString(UINT32 *pulAlarmed, INT8 *pucCaliFileString)
{
    UINT32 ret = 0;
    UINT32 pAlarmTemp0 = 0;
    UINT32 pAlarmTemp1 = 0;

    ret |= _BspGetCaliFileAlarmedString(&pAlarmTemp0, (char *)pucCaliFileString);
    ret |= BspGetRruInfoAlarmedString(&pAlarmTemp1,(CHAR *)pucCaliFileString);
    *pulAlarmed = pAlarmTemp0 | pAlarmTemp1;
    return ret;
}

UINT32 BspSaveRfTblFileInfo(T_RfTblFileMenu *pPara, UINT32 num)
{
    INPUT_POINTER_CHECK(pPara);
    s_pRfTblFile = pPara;
    s_uFileNum = num;
    return BSP_OK;
}

void rftblprn(void)
{
    UINT32 ulIdx = 0;
    dbgInfo("total file num: %d\n", s_uFileNum);
    dbgInfo("%-37s    %-5s  %s\n", "fileinfo", "alarm", "loadstate(1=ERROR,2=OK)");
    for (ulIdx = 0; ulIdx < s_uFileNum; ulIdx++)
    {
        dbgInfo("[%-2d] %-32s    %-5s  %d\n",
                s_pRfTblFile[ulIdx].ulFileType,
            strrchr(s_pRfTblFile[ulIdx].pAtaFile,'/'),
            s_pRfTblFile[ulIdx].ulIsErrAlm ? "ALARM" : "---",
                    s_pRfTblFile[ulIdx].ulLoadState);
    }
}


/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeature-hardid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了IC4.2光口serdes+pcs参数初始化、及模块功能初始化的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/
#include "boardntl_ic4_2.h"
#include "boardreset.h"
#include "boardmodlecommon.h"
#ifndef MULT_PROGRESS_S
#include "sfp.h"
#endif
#include "opt_pcs_api.h"
#include "optctrl_cpri_ic4_2.h"
#include "cpam_inter_api.h"
#include "pub_ntl.h"

#include "ntl_nacc_xmac.h"
#include "ichal_opt_api.h"
#include "opt_cpri_api.h"
#include "ichaladapt_ic4_2.h"
#include "funccommon.h"
#include "boardsocmsg.h"
#include "optctrlcommon.h"
#include "ntl_l2ss_api.h"
#include "boardmodle_ic4_2.h"
#include "optctrlapi.h"
#include "optctrl_ntl_ic4_2.h"
#include "digtrxlinkwrapper.h"
#include "lyca_dev.h"
/**************************************************************************
*                            全局变量定义                                       *
**************************************************************************/
static T_SERDES_PARAM *s_pSerdesCfg = NULL;
static UINT32 s_serdesLaneNum = 0;
static UINT32 s_innerSerdesLanMask = 0;
static T_BspHalAdaptSerdesRxCfg *s_pSerdesRxCfg = NULL;
static UINT32 s_serdesRxInitedFlag = 0;
static T_BspHalAdaptPcsCfg *s_sboardCpriPcsCfg = NULL;
static UINT32 s_boardPcsUsedLanedNum = 0;
T_optSerdesPcsMap g_optSerdesPcsMap = {0};
static UINT32 s_innerSerdesMonitoExSw = 0;
UINT32 innerSerdesSta = 0;   /*上联口是都否正常，不为0时不处理下联口*/
UINT32 txSwitchRec[OPT_PCS_LANE_MAX_NUM]  = {0};
UINT32 uplinkCnt[OPT_PCS_LANE_MAX_NUM]  = {0};
UINT32 downlinkTxCnt[OPT_PCS_LANE_MAX_NUM] = {0};
UINT32 downlinkRxCnt[OPT_PCS_LANE_MAX_NUM] = {0};
BspJudgeCpriSwitchType cpriSwitchTypeFun = NULL;
UINT32 g_ulInnerChipCmRec = 0;
static UINT32 s_BoardNtlWorkMode = 0xff;
UINT32 g_sgmiiLaneErrCnt = 0;
/**************************************************************************
*                                宏定义                                      *
**************************************************************************/

#define OPT_SERDES_RETRY_MAX (10) /* 因为高层已启线程监控，故单板初始化过程仅重试1次 */
#define OPT_MAC_SPEED_1000M (1000)
#define OPT_MAC_SPEED_100M (100)
#define CLK_STA_OK         (1)
#define OPT_STA_OK         (1)
#define BOARDNTL_PHY_OPT_0         (0)
#define BOARDNTL_PHY_OPT_1         (1)
#ifndef INPUT_INNER_LANE_MASK_CHECK
/* 物理光口号入参检查*/
#define INPUT_INNER_LANE_MASK_CHECK(laneId)                      \
		if((BIT_SET(laneId) & s_innerSerdesLanMask) == 0)     \
		{                                                     \
		    continue;                                         \
		}
#endif

#ifndef INPUT_INNER_LANEID_CHECK
/* 物理光口号入参检查*/
#define INPUT_INNER_LANE_SW_CHECK(laneId)                      \
        if((BIT_SET(laneId) & s_innerSerdesMonitorSw) == 0)    \
        {                                                      \
            continue;                                          \
        }
#endif

/* serdes lane号入参检查*/
#define INPUT_LANEID_CHECK_RETURN(laneId)                      \
        if(laneId >= OPT_SERDES_LANE_MAX_NUM)           \
        {                                               \
            return ;                           \
        }

#define OPT_INNER_LANE_CHECK_MONITOR_SW(VOID)       \
if(s_innerSerdesMonitoExSw)                 \
{                                           \
    break;                                  \
}


VOID BspSetOptSerdesPcsMap(T_optSerdesPcsMap *pMap)
{
	memcpy_s(&g_optSerdesPcsMap,sizeof(T_optSerdesPcsMap),pMap,sizeof(T_optSerdesPcsMap));
}
UINT32 BspGetOptNoBySerdesPcsLane(UINT32 laneId)
{
	UINT32 loop = 0;
	for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
	{
		if(g_optSerdesPcsMap.laneId[loop] == laneId)
		{
			return g_optSerdesPcsMap.optNo[loop];
		}
	}
	return BSP_ERROR;
}
#ifndef MULT_PROGRESS_S
/*从单板下发的全量配置中抽取出有效数据*/
static UINT32 BspGetVaildSerdesParam(T_OPT_SERDES_PCS_PARAM *pSerdesPcsParam,UINT32 *planeMask)
{
	UINT32 loop = 0;
	UINT32 laneMask = 0;
	UINT32 cnt = 0;
	UINT32 sfptype = 0;
	UINT32 optNo = 0;
	UINT32 realLaneNum = 0;

	laneMask = pSerdesPcsParam->laneMask;    /*硬件实际使用的lane，包括接电模块和光模块*/
	for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
	{
		if(laneMask&BIT_SET(loop))
		{
			BspSetSerdesParaByPhyNo(pSerdesPcsParam->serdesParam[loop].laneId,&pSerdesPcsParam->optRatePara);
			realLaneNum++;
		}
	}
	for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
	{
        optNo = BspGetOptNoBySerdesPcsLane(loop);   /*seders 的lane转到外部光笼的编号，这里需要转换接口*/
        (VOID)BspSetPhyNoBySfpNo(optNo,loop);
        if(optNo >= OPT_SERDES_LANE_MAX_NUM)
        {
            continue;
        }
		sfptype = BspIsSpecialQsfp(optNo);
		dbgInfo("%s serdes lane %d, sfp opt %d, sfptype %d\n",__FUNCTION__,loop,optNo,sfptype);
		if(sfptype ==1)  /*这条lane对应电模块，接网口，等于0或者直接报错，表示接光模块或者没接*/
		{
			laneMask = laneMask & BIT_REV(loop);     /*不能初始化接电模块的lane*/
		}
	}
	for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
	{
		if(laneMask&BIT_SET(loop))
		{
			cnt++;
		}
	}

	*planeMask = laneMask;   /*光链路使用的lane*/
	s_pSerdesCfg = (T_SERDES_PARAM *)malloc(sizeof(T_SERDES_PARAM)*cnt); /*单板下传入全集，这里过滤出有效数据*/
    if (NULL == s_pSerdesCfg)
    {
        dbgInfo("%s s_pSerdesCfg malloc error !\n",__FUNCTION__);
        return BSP_ERROR;
    }
	s_pSerdesRxCfg = (T_BspHalAdaptSerdesRxCfg *)malloc(sizeof(T_BspHalAdaptSerdesRxCfg)*cnt);
    if (NULL == s_pSerdesRxCfg)
    {
        dbgInfo("%s s_pSerdesRxCfg malloc error !\n",__FUNCTION__);
        return BSP_ERROR;
    }
	s_serdesLaneNum = cnt;
    s_innerSerdesLanMask = pSerdesPcsParam->innerLanMask;
	dbgInfo("%s LANEMASK %d INNERLANEMASK %d\n",__FUNCTION__,laneMask,s_innerSerdesLanMask);
	cnt = 0;
	for(loop = 0; loop < realLaneNum; loop++)
	{
		if(laneMask&BIT_SET(pSerdesPcsParam->serdesParam[loop].laneId))
		{
		    memcpy_s(&s_pSerdesCfg[cnt],sizeof(T_SERDES_PARAM),&pSerdesPcsParam->serdesParam[loop],sizeof(T_SERDES_PARAM));
		    memcpy_s(&s_pSerdesRxCfg[cnt],sizeof(T_BspHalAdaptSerdesRxCfg),&pSerdesPcsParam->serdesRxCfg[loop],sizeof(T_BspHalAdaptSerdesRxCfg));
	    	cnt++;
		}
   }
	return BSP_OK;
}

/*从单板下发的全量配置中抽取出有效数据 926x_s不需要访问sfp*/
static UINT32 BspGetVaildPcsParam(T_OPT_SERDES_PCS_PARAM *pSerdesPcsParam)
{
	UINT32 loop = 0;
	UINT32 cnt = 0;
	UINT32 sfptype = 0;
	UINT32 optNo = 0;
	UINT32 mask = 0;

	for(loop = 0; loop <  OPT_PCS_LANE_MAX_NUM; loop++)
	{
	    optNo = BspGetOptNoBySerdesPcsLane(loop);   /*pcs 的lane转到外部光笼的编号，这里需要转换接口*/
		sfptype = BspIsSpecialQsfp(optNo);
		dbgInfo("%s pcs lane %d, sfp opt %d, sfptype %d\n",__FUNCTION__,loop,optNo,sfptype);
		if(sfptype ==1)  /*这条lane对应电模块，接网口，等于0或者直接报错，表示接光模块或者没接*/
		{
			continue;
		}
	    if(pSerdesPcsParam->pcsCfg[loop].uBindMode1x4x != OPTPCS_BIND_MODE_NG)
	    {
	    	mask = mask | BIT_SET(loop);
		    cnt++;
	    }
	}
	dbgInfo("%s MASK %d\n",__FUNCTION__,mask);
	s_sboardCpriPcsCfg = (T_BspHalAdaptPcsCfg *)malloc(sizeof(T_BspHalAdaptPcsCfg)*cnt); /*单板下传入全集，这里过滤出有效数据*/
	if (NULL == s_sboardCpriPcsCfg)
	{
	    dbgInfo("%s s_sboardCpriPcsCfg malloc error !\n",__FUNCTION__);
	    return BSP_ERROR;
	}
	s_boardPcsUsedLanedNum = cnt;
	cnt = 0;
	for(loop = 0; loop <  OPT_PCS_LANE_MAX_NUM; loop++)
	{
		if((pSerdesPcsParam->pcsCfg[loop].uBindMode1x4x != OPTPCS_BIND_MODE_NG)&&(mask&BIT_SET(loop)))
		{
			memcpy_s(&s_sboardCpriPcsCfg[cnt],sizeof(T_BspHalAdaptPcsCfg),&pSerdesPcsParam->pcsCfg[loop],sizeof(T_BspHalAdaptPcsCfg));
			cnt++;
		}
	}
	return BSP_OK;
}
#else
static UINT32 BspGetVaildSerdesParam(T_OPT_SERDES_PCS_PARAM *pSerdesPcsParam,UINT32 *planeMask)
{
	UINT32 loop = 0;
	UINT32 laneMask = 0;
	UINT32 cnt = 0;

	laneMask = pSerdesPcsParam->laneMask;
	*planeMask = laneMask;

	for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
	{
		if(laneMask&BIT_SET(loop))
		{
			cnt++;
		}
	}
	s_pSerdesCfg = (T_SERDES_PARAM *)malloc(sizeof(T_SERDES_PARAM)*cnt); /*单板下传入全集，这里过滤出有效数据*/
    if (s_pSerdesCfg == NULL)
    {
        dbgErr("%s: malloc s_pSerdesCfg failed \n",__FUNCTION__);
        return BSP_ERROR;
    }
	s_pSerdesRxCfg = (T_BspHalAdaptSerdesRxCfg *)malloc(sizeof(T_BspHalAdaptSerdesRxCfg)*cnt);
    if (s_pSerdesRxCfg == NULL)
    {
        free(s_pSerdesCfg);
        dbgErr("%s: malloc s_pSerdesRxCfg failed \n",__FUNCTION__);
        return BSP_ERROR;
    }
	s_serdesLaneNum = cnt;
    s_innerSerdesLanMask = pSerdesPcsParam->innerLanMask;
	for(loop = 0; loop < cnt; loop++)
	{
		memcpy_s(&s_pSerdesCfg[loop],sizeof(T_SERDES_PARAM),&pSerdesPcsParam->serdesParam[loop],sizeof(T_SERDES_PARAM));
		memcpy_s(&s_pSerdesRxCfg[loop],sizeof(T_BspHalAdaptSerdesRxCfg),&pSerdesPcsParam->serdesRxCfg[loop],sizeof(T_BspHalAdaptSerdesRxCfg));
   }
	return BSP_OK;
}
/*从单板下发的全量配置中抽取出有效数据*/
static UINT32 BspGetVaildPcsParam(T_OPT_SERDES_PCS_PARAM *pSerdesPcsParam)
{
	UINT32 loop = 0;
	UINT32 cnt = 0;

	for(loop = 0; loop <  OPT_PCS_LANE_MAX_NUM; loop++)
	{
		if(pSerdesPcsParam->pcsCfg[loop].uBindMode1x4x != OPTPCS_BIND_MODE_NG)
		{
			cnt++;
		}
	}
	s_sboardCpriPcsCfg = (T_BspHalAdaptPcsCfg *)malloc(sizeof(T_BspHalAdaptPcsCfg)*cnt); /*单板下传入全集，这里过滤出有效数据*/
    if (s_sboardCpriPcsCfg == NULL)
    {
        dbgErr("%s: malloc s_sboardCpriPcsCfg failed \n",__FUNCTION__);
        return BSP_ERROR;
    }

	s_boardPcsUsedLanedNum = cnt;
	cnt = 0;
	for(loop = 0; loop <  OPT_PCS_LANE_MAX_NUM; loop++)
	{
		if(pSerdesPcsParam->pcsCfg[loop].uBindMode1x4x != OPTPCS_BIND_MODE_NG)
		{
			memcpy_s(&s_sboardCpriPcsCfg[cnt],sizeof(T_BspHalAdaptPcsCfg),&pSerdesPcsParam->pcsCfg[loop],sizeof(T_BspHalAdaptPcsCfg));
			cnt++;
		}
	}
	return BSP_OK;
}
#endif
void showserdespara(void)
{
	UINT32 loop = 0;
	dbgInfo("TX serdes:\n");
	dbgInfo("serdesId  laneId  rate  chlen  txEqEn  eoh0  eoh1  eoh2  eoh3\n");
	for(loop = 0; loop < s_serdesLaneNum; loop++)
	{
       dbgInfo("%d  %d  %d  %f  %d  %d  %d  %d  %d\n",s_pSerdesCfg[loop].serdesId,s_pSerdesCfg[loop].laneId,s_pSerdesCfg[loop].rate,s_pSerdesCfg[loop].chlen,
    		   s_pSerdesCfg[loop].txEqEn,s_pSerdesCfg[loop].eoh0,s_pSerdesCfg[loop].eoh1,s_pSerdesCfg[loop].eoh2,s_pSerdesCfg[loop].eoh3);
	}
	dbgInfo("RX serdes:\n");
	dbgInfo("phaseMin  phaseMax  uVga  uCmtermCtrl\n");
	for(loop = 0; loop < s_boardPcsUsedLanedNum; loop++)
	{
       dbgInfo("%d  %d  %d  %d\n", s_pSerdesRxCfg[loop].phaseMin,s_pSerdesRxCfg[loop].phaseMax,s_pSerdesRxCfg[loop].uVga,s_pSerdesRxCfg[loop].uCmtermCtrl);
	}
}

void showpcspara(void)
{
	UINT32 loop = 0;

	dbgInfo("pcs:\n");
	dbgInfo("uPcsPortIdx  uEthOrCpri  uBindMode1x4x  uPortMode  uProtocolType  uFecMode  uGearBoxBW  uEvenOutEn  uEvenOutSpeed1x uSelfdefEthEn \n");
	for(loop = 0; loop < s_boardPcsUsedLanedNum; loop++)
	{
	    dbgInfo("%d  %d  %d  %d  %d  %d  %d  %d  %d %d\n",s_sboardCpriPcsCfg[loop].uPcsPortIdx,s_sboardCpriPcsCfg[loop].uEthOrCpri,s_sboardCpriPcsCfg[loop].uBindMode1x4x,s_sboardCpriPcsCfg[loop].uPortMode,
	    		s_sboardCpriPcsCfg[loop].uProtocolType,s_sboardCpriPcsCfg[loop].uFecMode,s_sboardCpriPcsCfg[loop].uGearBoxBW,s_sboardCpriPcsCfg[loop].uEvenOutEn,s_sboardCpriPcsCfg[loop].uEvenOutSpeed1x,s_sboardCpriPcsCfg[loop].uSelfdefEthEn);
	}
}

static UINT32 BspOptNtlCrmInit(UINT32 laneMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    retVal = BspHalAdaptCrmNtlXmacSetReset(TX, laneMask, rstFlag);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptCrmNtlXmacSetReset, retVal);
    retVal = BspHalAdaptCrmNtlXmacSetReset(RX, laneMask, rstFlag);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptCrmNtlXmacSetReset, retVal);

    return retTotal;
}
static UINT32 BspOptPcsPreInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptPcsPreInit(s_sboardCpriPcsCfg, s_boardPcsUsedLanedNum);
    CHECK_RETVAL(BspHalAdaptPcsPreInit, retVal);

    return retVal;
}
static UINT32 BspOptPcsInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptPcsInit(s_sboardCpriPcsCfg, s_boardPcsUsedLanedNum);
    CHECK_RETVAL(BspHalAdaptPcsInit, retVal);

    return BSP_OK;
}

/* 关闭 flotoken_en 和 path_en */
static UINT32 BspSetFlowTokenEnPathEnDisable(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSetFlowTokenEnPathEnDisable(s_sboardCpriPcsCfg, s_boardPcsUsedLanedNum);
    CHECK_RETVAL(BspHalAdaptSetFlowTokenEnPathEnDisable, retVal);

    return BSP_OK;
}

UINT32 BspGetOptInitParaInfo(T_OptInitPara *pOptInitPara)
{
    T_OptInitPara *pPara = NULL;
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_HAL_INIT,0,0,pPara,num);
 
    pOptInitPara->optWorkMode = pPara->optWorkMode;

    if(pOptInitPara->optWorkMode == E_OPT_MODE_IR)  /*不能修改原始参数*/
    {
        pOptInitPara->optWorkMode = E_OPT_MODE_CPRI;  /*对l2ss只区分cpri和ecpri，不取反cpri和IR*/
    }
    
    return retVal;
}

/* 光口Serdes 固件加载 */
static UINT32 BspOptSerdesLoadFirmware(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesLoadFw(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesLoadFw, retVal);

    return BSP_OK;
}

/* 光口Serdes TX 初始化 */
static UINT32 BspOptSerdesTxInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesTxInit(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesTxInit, retVal);

    return BSP_OK;
}

/* 光口Serdes TX 预加重参数配置 */
static UINT32 BspOptSerdesSetTxEq(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSetSerdesTxEq(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSetSerdesTxEq, retVal);

    return BSP_OK;
}

/* 光口Serdes RX 初始化 */
static UINT32 BspOptSerdesRxInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesRxInit(s_pSerdesCfg,s_pSerdesRxCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesRxInit, retVal);

    return BSP_OK;
}

/* 光口Serdes切换到正常模式 */
static UINT32 BspOptSerdesChgNormal(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSerdesChgNormal(s_pSerdesCfg, s_serdesLaneNum);
    CHECK_RETVAL(BspHalAdaptSerdesChgNormal, retVal);

    return BSP_OK;
}
UINT32 BspOptSerdesInit(VOID)
{
   UINT32 retTotal = BSP_OK;
   UINT32 retVal = BSP_OK;

   /* 光口Serdes固件加载 */
   retVal = BspOptSerdesLoadFirmware();
   retTotal |= retVal;
   CHECK_RETVAL_PRN(BspOptSerdesLoadFirmware, retVal);

   /* 光口Tx Serdes初始化 */
   retVal = BspOptSerdesTxInit();
   retTotal |= retVal;
   CHECK_RETVAL_PRN(BspOptSerdesTxInit, retVal);

   /* 光口Tx Serdes  预加重参数配置 */
   retVal = BspOptSerdesSetTxEq();
   retTotal |= retVal;
   CHECK_RETVAL_PRN(BspOptSerdesSetTxEq, retVal);

   /* Rx的初始化移动到单板初始化的最后进行 */
   return retTotal;
}


/*MCS如果没有数据过来会导致光口serdes初始化失败，需要高层起线程一直判断PCS状态 接口先保留，后续看情况*/
UINT32 BspReInitOptRxSerdes(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 loop = 0;
    UINT32 serdesId = 0;
    UINT32 laneId = 0;
    UINT32 ulPcsSta = 0;
    UINT32 ulPcsLaneId = 0;
    T_BspHalAdaptSerdesRxCfg *serdesRxCfg = NULL;
    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
        serdesId = s_pSerdesCfg[loop].serdesId;
        laneId = s_pSerdesCfg[loop].laneId;
        serdesRxCfg = &s_pSerdesRxCfg[loop];
        /*pcs的laneId与serdesId、laneId有如下对应关系*/
        ulPcsLaneId = serdesId * 4 + laneId;
        /*判断PCS状态*/
        retVal = BspHalAdaptPcsGetLinkPcsSta(ulPcsLaneId, &ulPcsSta);
        CHECK_RETVAL_PRN(BspHalAdaptPcsGetLinkPcsSta, retVal);
        retTotal |= retVal;
        dbgInfoEx("[%s] : [ser %d][lane %d] [PCS STA 0x%08x]\n",__func__,serdesId,laneId,ulPcsSta);

        /*pcs Status：回读回来的结果，看第0和1bit，如果不是0x3就执行*/
        if (ulPcsSta != 0x3)
        {
            retVal = BspHalAdaptLycaInitRx(serdesId, laneId,serdesRxCfg);
            CHECK_RETVAL_PRN(BspHalAdaptLycaInitRx, retVal);
            retTotal |= retVal;

            retVal = BspHalAdaptLycaTccSwitch(serdesId, laneId);
            CHECK_RETVAL_PRN(BspHalAdaptLycaTccSwitch, retVal);
            retTotal |= retVal;
        }

        /*初始化完成之后再次回读pcs状态*/
        retVal = BspHalAdaptPcsGetLinkPcsSta(ulPcsLaneId, &ulPcsSta);
        CHECK_RETVAL_PRN(BspHalAdaptPcsGetLinkPcsSta, retVal);
        retTotal |= retVal;
        dbgInfoEx("[%s] : [ser %d][lane %d] [PCS STA 0x%08x]\n",__func__,serdesId,laneId,ulPcsSta);
        if(ulPcsSta != 0x3)
        {
            retVal = BSP_ERROR;
        }
        retTotal |= retVal;
    }

    return retTotal;
}

/*片间serdes Rx初始化*/
UINT32 BspReCfgOptInnerRxSerdes(UINT32 serdesId, UINT32 laneId)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 loop = 0;
    T_BspHalAdaptSerdesRxCfg *serdesRxCfg = NULL;
    UINT32 retryTime = 3;

    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
        if(( s_pSerdesCfg[loop].laneId == laneId)&&(BIT_SET(laneId) & s_innerSerdesLanMask))
        {
            serdesRxCfg = &s_pSerdesRxCfg[loop];
            break;
        }
    }
    if(loop == s_serdesLaneNum)
    {
        dbgErr("laneId %d is invalid \n",laneId);
        return BSP_ERROR;
    }
    dbgInfoEx("serdesId %d laneId %d \n",serdesId,laneId);
    for(loop = 0; loop < retryTime; loop++)
    {
        retVal = BspHalAdaptLycaInitRx(serdesId,laneId,serdesRxCfg);
        if(BSP_OK != retVal)
        {
            dbgErr("%s BspHalAdaptLycaInitRx lane[%d][%d] err\n", __func__, serdesId, laneId);
            continue;
        }
        BspSysMsDelay(200);
        break;
    }
    retTotal |= retVal;

    retVal = BspHalAdaptLycaTccSwitch(serdesId, laneId);
    CHECK_RETVAL_PRN(BspHalAdaptLycaTccSwitch, retVal);
    retTotal |= retVal;
    return retTotal;
}

UINT32 BspNtlInit(T_OPT_SERDES_PCS_PARAM *pPara)
{
    T_OptInitPara pOptInitPara = {0};
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 laneMask = 0;

    retVal = BspGetVaildSerdesParam(pPara,&laneMask);
    retTotal |= retVal;
    CHECK_RETVAL(BspGetVaildSerdesParam, retVal);

    retVal = BspGetVaildPcsParam(pPara);
    retTotal |= retVal;
    CHECK_RETVAL(BspGetVaildPcsParam, retVal);	

    //BspCevaArpInit();
    //BspR8ArpInit();
    /* Serdes初始化状态清空(维测用) */
    BspHalAdaptOptSerdesInitStatusClr();

    /* 关闭 trxp 和 xmac */
    BspNtlInitSetTrxpXmacEn(0); // 对应 1.1 1.2 步骤

    /* 复位住l2ss xmac lane  暂时保留，cpri应该不需要 hal确认先保留*/
    retVal = BspOptNtlCrmInit(laneMask, 0);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptNtlCrmInit, retVal);

    /* pcs复位释放 */
    retVal = BspHalAdaptCrmPcsSetReset(laneMask,1); 
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptCrmPcsSetReset, retVal);

    /* pcs预初始化 */
    retVal = BspOptPcsPreInit(); // 对应步骤 2.0
    retTotal |= retVal;
    CHECK_RETVAL(BspOptPcsPreInit, retVal);

    /* 关闭 flow_token_en 和 tx/rx_path_en */
    BspSetFlowTokenEnPathEnDisable(); // 对应 步骤 2.1

    /* 光口serdes TX 初始化 */
    retVal = BspOptSerdesInit(); // 对应5
    retTotal |= retVal;
    CHECK_RETVAL(BspOptSerdesInit, retVal);

    /* 光口serdes Rx初始化(和建开讨论，为保证和流程一致，先加上。只初始化一次就行) */
    BspOptSerdesRxInit();

    /* pcs初始化 */
    retVal = BspOptPcsInit(); // 这个接口打开了 flow_token_en 和 patch_en,对应步骤 6 和 8
    retTotal |= retVal;
    CHECK_RETVAL(BspOptPcsInit, retVal); 

    /* 复位释放l2ss xmac lane */
    retVal = BspOptNtlCrmInit(laneMask, 1);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptNtlCrmInit, retVal);

    if( !((RRU_PB_BBU ==  BspGetPbOrBbuMode()) || (RRU_BBU ==  BspGetPbOrBbuMode())) )/* QCELL此处不走L2SS配置流程 */
    {
        BspGetOptInitParaInfo(&pOptInitPara);
        (void)IcHalApiNtlL2ssInitVlanCfg(pOptInitPara.optWorkMode); // 会自动打开 xmac 和 trxp 对应 8.1 9 10 11
    }

#if !defined (MULT_PROGRESS_S) && !defined (QCELL_MULT_PROGRESS_M) /* QCELL主进程不走下面流程 */
    UINT32 rpuNum = BspGetRpuNum();
    if(rpuNum > 1)
    {
        retVal = BspNtlInitForSgmii(); /*仅UBR的主片需要配置*/
        retTotal |= retVal;
    }
#endif
    return retTotal;
}

T_BspHalAdaptPcsCfg g_pcsParaForSfp =
{ 0, OPTPCS_CPRI,  OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_CPRI_66B, OPTPCS_FEC_TYPE_RSFEC528, OPTPCS_PCS_GEAR_WIDTH_32B, 1, OPTPCS_PCS_CPRI_24G, 0};
T_SERDES_PARAM g_txSerdesParaForSfp =
     {SERDES_ID_0, SERDES_LANE_0, SERDES_RATE_9G83, 5.569, 1, 0, 0, 72, -12};
T_BspHalAdaptPcsCfg g_pcsParaForQsfp =
    { 0, OPTPCS_ETH,  OPTPCS_BIND_MODE_4T1X, OPTPCS_PORT_MODE_1X, OPTPCS_ETH_1G_2P5G_10B, OPTPCS_FEC_TYPE_BYPASS, OPTPCS_PCS_GEAR_WIDTH_32B ,0, 0, 0};
T_SERDES_PARAM g_txSerdesParaForQsfp =
     {SERDES_ID_0, SERDES_LANE_0, SERDES_RATE_1G25, 5.04, 0, 0, 0, 0,0};
T_BspHalAdaptSerdesRxCfg g_rxSerdesParaForQsfp =  { -24, 24, 0, 4 };
UINT32 BspSfpNtlInit(UINT32 laneId)
{
    T_BspHalAdaptPcsCfg pcsParaForQsfp = {0};
    T_SERDES_PARAM serdesTxParaForQsfp = {0};
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    dbgInfoEx("%s laneId %d\n",__FUNCTION__,laneId);
    memcpy_s(&pcsParaForQsfp,sizeof(T_BspHalAdaptPcsCfg),&g_pcsParaForSfp,sizeof(T_BspHalAdaptPcsCfg));
    pcsParaForQsfp.uPcsPortIdx = laneId;
    memcpy_s(&serdesTxParaForQsfp,sizeof(T_SERDES_PARAM),&g_txSerdesParaForSfp,sizeof(T_SERDES_PARAM));
    serdesTxParaForQsfp.laneId = laneId;
    /* pcs预初始化 */
    retVal = BspHalAdaptPcsPreInit(&pcsParaForQsfp,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptPcsPreInit, retVal);
    /* 1 固件加载*/
    retVal = BspHalAdaptSerdesLoadFw(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    /* pcs初始化 */
    retVal =  BspHalAdaptPcsInit(&pcsParaForQsfp,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptPcsInit, retVal);
    return retVal;
}

UINT32 BspQsfpNtlInit(UINT32 laneId)
{
    static UINT32 cfgFlag = 0xff;
    UINT32 laneMask = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
#ifndef  MULT_PROGRESS_S
    UINT32 sfpNo = BspGetSfpNoByPhyNo(laneId);
#endif
    UINT32 tmpLaneId = 0;
    T_BspHalAdaptPcsCfg pcsParaForQsfp = {0};
    T_SERDES_PARAM serdesTxParaForQsfp = {0};
    T_BspHalAdaptSerdesRxCfg serdesRxParaForQsfp = {0};

    dbgInfoEx("%s laneId %d\n",__FUNCTION__,laneId);
    tmpLaneId = laneId;
    /*做网口时lane参数初始化*/
    memcpy_s(&pcsParaForQsfp,sizeof(T_BspHalAdaptPcsCfg),&g_pcsParaForQsfp,sizeof(T_BspHalAdaptPcsCfg));
    pcsParaForQsfp.uPcsPortIdx = laneId;
    memcpy_s(&serdesTxParaForQsfp,sizeof(T_SERDES_PARAM),&g_txSerdesParaForQsfp,sizeof(T_SERDES_PARAM));
    serdesTxParaForQsfp.laneId = laneId;
    memcpy_s(&serdesRxParaForQsfp,sizeof(T_BspHalAdaptSerdesRxCfg),&g_rxSerdesParaForQsfp,sizeof(T_BspHalAdaptSerdesRxCfg));
    laneMask = 1<<laneId;
    if(laneId >= OPT_PCS_LANE_MAX_NUM)
    {
       laneId = tmpLaneId%OPT_PCS_LANE_MAX_NUM;
       return BspSfpNtlInit(laneId);
    }
    /* 复位住l2ss xmac lane  暂时保留，cpri应该不需要 hal确认先保留*/
    retVal = BspOptNtlCrmInit(laneMask, 0);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptNtlCrmInit, retVal);
    /* pcs复位释放 */
    retVal = BspHalAdaptCrmPcsSetReset(laneMask,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptCrmPcsSetReset, retVal);
    /* pcs预初始化 */
    retVal = BspHalAdaptPcsPreInit(&pcsParaForQsfp,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptPcsPreInit, retVal);
    /* 光口serdes初始化 */
    /* 1 固件加载*/
    retVal = BspHalAdaptSerdesLoadFw(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    /* 2 光口Tx Serdes初始化 */
    retVal = BspHalAdaptSerdesTxInit(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    /* 3 光口Tx Serdes 预加重参数初始化 */
    retVal =  BspHalAdaptSetSerdesTxEq(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptSerdesInit, retVal);
    /*PHY芯片配置*/
#ifndef  MULT_PROGRESS_S
    retVal =  BspInitSfpPhy(sfpNo);
    retTotal |= retVal;
#endif
    /*光口Rx Serdes初始化*/
    retVal =  BspHalAdaptSerdesRxInit(&serdesTxParaForQsfp,&serdesRxParaForQsfp, 1);
    retTotal |= retVal;
    retVal = BspHalAdaptSerdesChgNormal(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptSerdesChgNormal, retVal);
    /* pcs初始化 */
    retVal =  BspHalAdaptPcsInit(&pcsParaForQsfp,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptPcsInit, retVal);
    /* 复位释放l2ss xmac lane */
    retVal = BspOptNtlCrmInit(laneMask, 1);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptNtlCrmInit, retVal);
    /* xmac l2ss端口配置 有顺序要求 */
    BspNaccXmacInit(laneId);
    if(0xff == cfgFlag)
    {
        BspHalAdaptNtlL2ssPortVlanDebugCfg();  /*按L2SS 要求，用户态也只配置一次*/
        cfgFlag = 0;
    }
    BspHalAdaptTrxpEnOrDisable(laneId,1);
    BspHalAdaptXmacEnOrDisable(laneId,1);
    // BspHalNtlXmacCfgPortSpeed(laneId,1);  /*1是1.25G 在BspNaccXmacInit已配置速率不用单独配置*/

    return retTotal;

}

UINT32 BspQsfpNtlInitNcr(UINT32 laneId)
{
    static UINT32 cfgFlag = 0xff;
    UINT32 laneMask = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 tmpLaneId = 0;
    T_BspHalAdaptPcsCfg pcsParaForQsfp = {0};
    T_SERDES_PARAM serdesTxParaForQsfp = {0};
    T_BspHalAdaptSerdesRxCfg serdesRxParaForQsfp = {0};

    dbgInfoEx("%s laneId %d\n",__FUNCTION__,laneId);
    tmpLaneId = laneId;
    /*做网口时lane参数初始化*/
    memcpy_s(&pcsParaForQsfp,sizeof(T_BspHalAdaptPcsCfg),&g_pcsParaForQsfp,sizeof(T_BspHalAdaptPcsCfg));
    pcsParaForQsfp.uPcsPortIdx = laneId;
    memcpy_s(&serdesTxParaForQsfp,sizeof(T_SERDES_PARAM),&g_txSerdesParaForQsfp,sizeof(T_SERDES_PARAM));
    serdesTxParaForQsfp.laneId = laneId;
    memcpy_s(&serdesRxParaForQsfp,sizeof(T_BspHalAdaptSerdesRxCfg),&g_rxSerdesParaForQsfp,sizeof(T_BspHalAdaptSerdesRxCfg));
    laneMask = 1<<laneId;
    if(laneId >= OPT_PCS_LANE_MAX_NUM)
    {
       laneId = tmpLaneId%OPT_PCS_LANE_MAX_NUM;
       return BspSfpNtlInit(laneId);
    }
    /* 复位住l2ss xmac lane  暂时保留，cpri应该不需要 hal确认先保留*/
    retVal = BspOptNtlCrmInit(laneMask, 0);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptNtlCrmInit, retVal);
    /* pcs复位释放 */
    retVal = BspHalAdaptCrmPcsSetReset(laneMask,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptCrmPcsSetReset, retVal);
    /* pcs预初始化 */
    retVal = BspHalAdaptPcsPreInit(&pcsParaForQsfp,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptPcsPreInit, retVal);
    /* 光口serdes初始化 */
    /* 1 固件加载*/
    retVal = BspHalAdaptSerdesLoadFw(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    /* 2 光口Tx Serdes初始化 */
    retVal = BspHalAdaptSerdesTxInit(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    /* 3 光口Tx Serdes 预加重参数初始化 */
    retVal =  BspHalAdaptSetSerdesTxEq(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptSerdesInit, retVal);
    /*光口Rx Serdes初始化*/
    retVal =  BspHalAdaptSerdesRxInit(&serdesTxParaForQsfp,&serdesRxParaForQsfp, 1);
    retTotal |= retVal;
    retVal = BspHalAdaptSerdesChgNormal(&serdesTxParaForQsfp, 1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptSerdesChgNormal, retVal);
    /* pcs初始化 */
    retVal =  BspHalAdaptPcsInit(&pcsParaForQsfp,1);
    retTotal |= retVal;
    CHECK_RETVAL(BspHalAdaptPcsInit, retVal);
    /* 复位释放l2ss xmac lane */
    retVal = BspOptNtlCrmInit(laneMask, 1);
    retTotal |= retVal;
    CHECK_RETVAL(BspOptNtlCrmInit, retVal);
    /* xmac l2ss端口配置 有顺序要求 */
    BspNaccXmacInitNcr(laneId);
    if(0xff == cfgFlag)
    {
        BspHalAdaptNtlL2ssPortVlanDebugCfg();  /*按L2SS 要求，用户态也只配置一次*/
        cfgFlag = 0;
    }
    BspHalAdaptTrxpEnOrDisable(laneId,1);
    BspHalAdaptXmacEnOrDisable(laneId,1);

    return retTotal;

}

/*此次修改去掉了主片的调用  从片在rxserdes配置之后调用 和之前一致 只有9269使用*/
UINT32 BspInnerSdrRxCheckOff(VOID)
{
    UINT32 resetflag = 0;
    UINT32 loop = 0;
    UINT32 laneId = 0;
    UINT32 fecMode = 0;

    resetflag = BspGetBoardResetType();
    BspLog(LOG_LEVEL_0,"%s start, ticks %d\n", __FUNCTION__, tickGet());
    /*从片切成25G之后 软复位从片有帧头抖动 需要此流程保证重启过程中25G的网口不断，sgmii+cpri时不需要此流程*/
    /*从片预初始化调用BspOptFrRobustInitBySoftResetFlag中 BspHalAdaptCpriSetSwDstFrFlag(SWITCH_OFF) */
    BspHalAdaptCpriSetSwDstFrFlag(SWITCH_ON);

    if (0 == BspGetRpuId())
    {
        BspSetInnerSerdesMonitorSw(0xff);
        return BSP_OK;
    }
    /* Started by AICoder, pid:7dcfb22b13e86a0140180bf5b05dff2aea41ce6e */
    INPUT_POINTER_CHECK(s_pSerdesCfg);

    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
        laneId = s_pSerdesCfg[loop].laneId;
        BspHalAdaptPcsGetLinkFecMode(laneId,&fecMode);
        dbgInfo("%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
        BspLog(LOG_LEVEL_0,"%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
        if(OPTPCS_FEC_TYPE_BYPASS == fecMode)   /*合一模式下 fec模式不是25G 说明从片软复位的时候还是1.25G*/
        {
            IcHalSetLycaLoadFwState(0,laneId,1);
        }
        IcHalApiSetLycaLoadFwFlag(0,laneId);    /*保持原有调用 只是使用的lane是动态变化的了 这里是因为从片软复位的时候不加载serdes 但是底层有需要有个加载的状态用于流程*/
    }
    /* Ended by AICoder, pid:7dcfb22b13e86a0140180bf5b05dff2aea41ce6e */
    if((resetflag != 10) && (resetflag != 1))
    {
#ifdef MULT_PROGRESS_S       /*这里是L2SS要求的从片软复位启动的配置动作  因为从片单独软复位 高层不会重新触发1.25到25G的切换 */
        T_OptInitPara optInitPara = {0};
        UINT32 savingFlag = 0xf;
        savingFlag = BspHalAdaptGetLaneSavingFlag();
        if(1 == savingFlag)   /*区分开原有流程*/
        {
             optInitPara.optWorkMode = E_OPT_MODE_CPRI;    /*只有qcell有差异 其他机型对L2SS全是cpri 而不是ecpri*/
             BspHalAdaptNtlL2ssSetSlaveFlag(1);
             BspHalAdaptNtlL2ssInit(&optInitPara);   /*软复位不调用BspHalAdaptNtlL2ssInitVlanCfg*/
        }
#endif
        BspSetInnerSerdesMonitorSw(0xff);
    }
    else
    {
        BspSetInnerSerdesMonitorSw(0xff);
    }

    BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_OFF);  /*这接口执行在rx serdes之后 所以需要打开*/

    return BSP_OK;
}

UINT32 BspCpriModeNtlSoftInit(VOID)
{
    UINT32 num = 0;
    UINT32 laneMaskAll = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    T_OPT_SERDES_PCS_PARAM *pParaExt = NULL;

    if (BspGetRpuId() == 0)
    {
        return BSP_OK;
    }

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_TX_SERDES,0,0,pParaExt,num);
    retVal = BspGetVaildSerdesParam(pParaExt,&laneMaskAll);
    retTotal |= retVal;

    retVal = BspGetVaildPcsParam(pParaExt);
    retTotal |= retVal;

    return retTotal;
}
/*合一lane工作时从片启动时不需要加载serdes  boot配置好sgmii 用户态只需要替换获取对应lane参数为后续的自救任务做准备 这里还是1.25G的参数 */
UINT32 BspCpriModeNtlSoftInitNew(T_OPT_SERDES_PCS_PARAM *pParaExt)
{
    UINT32 laneMaskAll = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 loop = 0;
    UINT32 laneId = 0;
    UINT32 fecMode = 0xff;

    if (BspGetRpuId() == 0)
    {
        return BSP_OK;
    }
    INPUT_POINTER_CHECK(pParaExt);
    retVal = BspGetVaildSerdesParam(pParaExt,&laneMaskAll);
    retTotal |= retVal;

    retVal = BspGetVaildPcsParam(pParaExt);
    retTotal |= retVal;

    INPUT_POINTER_CHECK(s_pSerdesRxCfg);
    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
        /* Started by AICoder, pid:maa1fdf80fp1758140c20950a09fa803afc9187c */
        laneId = s_pSerdesCfg[loop].laneId;
        BspHalAdaptPcsGetLinkFecMode(laneId,&fecMode);
        dbgInfo("%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
        BspLog(LOG_LEVEL_0,"%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
        if(OPTPCS_FEC_TYPE_BYPASS == fecMode)   /* fec模式不是25G 说明此时还是1.25G 是M0完整配置启动*/
        {
            IcHalSetLycaLoadFwState(0,laneId,1);
        }
        /* Ended by AICoder, pid:maa1fdf80fp1758140c20950a09fa803afc9187c */
        IcHalApiSetLycaLoadFwFlag(0,laneId);    /*保持原有调用 只是使用的lane是动态变化的了 这里是因为从片启动的时候不加载serdes 但是底层有需要有个加载的状态用于流程*/
    }
    return retTotal;
}

static UINT32 s_ntlCpriInitRetMask = 0;

UINT32 BspSetRetMask(UINT32 retVal, UINT32 mask)
{
    if (retVal != BSP_OK)
    {
        s_ntlCpriInitRetMask |= mask;
    }

    return BSP_OK;
}

static VOID showcpriretmask(VOID)
{
    dbgInfo("retVal:%#x\r\n",s_ntlCpriInitRetMask);
}
UINT32 BspUpdateSlaveSerdesPcsPara(VOID)
{
    T_OPT_INNER_SERDES_PCS_PARAM *pPara = NULL;
    UINT32 loop = 0;
    UINT32 num = 0;
    UINT32 rpuId = 0;
    UINT32 resetType = 0xff;
    UINT32 laneId = 0;
    UINT32 retVal = BSP_OK;
    UINT32 workMode = 0;
    UINT32 savingFlag = 0xff;
    UINT32 fecMode = 0;

    BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_OFF);    /*从片合一模式的时候先关掉了 用户态不配serdes 在自救任务前要打开开关*/
    resetType = BspGetBoardResetType();
    workMode = BspGetOptWorkMode(0);
    savingFlag = BspHalAdaptGetLaneSavingFlag();
    resetType = BspGetBoardResetType();
    dbgInfo(" resetType %d workMode %d savingFlag %d\n", resetType, workMode, savingFlag);
    BspLog(LOG_LEVEL_0,"%s>> resetType:%d  workMode %d savingFlag %d \r\n",__func__,resetType, workMode, savingFlag);
    rpuId = BspGetRpuId();
    if(0 == rpuId)
    {
        dbgInfo("ic0 not need\n");
        return BSP_OK;
    }

    if((BSP_OPT_WORK_MODE_SHARE != workMode)&&(1 != savingFlag))
    {
        return BSP_OK;
    }

    if((BSP_OMC_HARD_RESET == resetType)||(BSP_RPDC_PWROFF_RESET == resetType))
    {
        return BSP_OK;
    }
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_INNER_OPT_SERDES,0,0,pPara,num);
    INPUT_POINTER_CHECK(s_pSerdesCfg);
    INPUT_POINTER_CHECK(s_sboardCpriPcsCfg);
    INPUT_POINTER_CHECK(s_pSerdesRxCfg);
    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
        laneId = s_pSerdesCfg[loop].laneId;
        BspHalAdaptPcsGetLinkFecMode(laneId,&fecMode);
        dbgInfo("%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
        BspLog(LOG_LEVEL_0,"%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
        if(OPTPCS_FEC_TYPE_RSFEC528 == fecMode)   /*合一模式下 fec模式不是25G 说明从片软复位的时候还是1.25G*/
        {
            memcpy_s(&s_sboardCpriPcsCfg[loop],sizeof(T_BspHalAdaptPcsCfg),&pPara->pcsCfg[laneId],sizeof(T_BspHalAdaptPcsCfg));
            memcpy_s(&s_pSerdesCfg[loop],sizeof(T_SERDES_PARAM),&pPara->serdesParam[laneId],sizeof(T_SERDES_PARAM));
            memcpy_s(&s_pSerdesRxCfg[loop],sizeof(T_BspHalAdaptSerdesRxCfg),&pPara->serdesRxCfg[laneId],sizeof(T_BspHalAdaptSerdesRxCfg));
        }
    }
    showpcspara();
    showserdespara();

    return BSP_OK;
}

UINT32 BspCommonCpriRateSwitchType(VOID)
{
    UINT32 loop = 0;
    UINT32 laneId = 0;
    UINT32 fecMode = 0;
    UINT32 optProperty = 0;
    UINT32 optInterConn = 0;

    INPUT_POINTER_CHECK(s_pSerdesRxCfg);
    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
         laneId      = s_pSerdesCfg[loop].laneId;
         if((BIT_SET(laneId) & s_innerSerdesLanMask) == 0)
         {
             continue;
         }
         BspHalAdaptPcsGetLinkFecMode(laneId,&fecMode);
         dbgInfoEx("%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
         (VOID)BspHalAdaptGetOptProperty(laneId, &optProperty, &optInterConn);
         dbgInfoEx("laneId %d ulOptProperty %d ulOptInterConn %d\n",laneId,optProperty,optInterConn);

         if((1 == optInterConn)&&(OPTPCS_FEC_TYPE_RSFEC528 == fecMode))    /*独立lane模式下 只需要监控下联口的状态optProperty=1 表示下联*/
         {
             BspSetSlaveIcLoadStatus(1);
             BspLog(LOG_LEVEL_0,"%s>> laneId %d fecMode %d\n", __func__, laneId, fecMode);
             return BSP_OK;
         }
    }

    return BSP_ERROR;
}

UINT32 BspCommonCpriRateSwitchTypeInit(VOID)
{
    UINT32 flag = 0xff;
    flag = BspHalAdaptGetLaneSavingFlag();    /*是否处于独立lane的状态*/
    if(1 == flag)
    {
        BspSetCpriSwitchTypeFun(BspCommonCpriRateSwitchType);
    }
    return BSP_OK;
}

UINT32 BspNtlInitByLane(UINT32 laneId)
{
    UINT32 laneMask = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 loop = 0;
    UINT32 num = 0;
    T_BspHalAdaptPcsCfg pcsParaForSfp = {0};
    T_SERDES_PARAM serdesTxParaForSfp = {0};
    T_BspHalAdaptSerdesRxCfg serdesRxParaForSfp = {0};
    T_OPT_INNER_SERDES_PCS_PARAM *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_INNER_OPT_SERDES,0,0,pPara,num);

    memcpy_s(&pcsParaForSfp,sizeof(T_BspHalAdaptPcsCfg),&pPara->pcsCfg[laneId],sizeof(T_BspHalAdaptPcsCfg));
    pcsParaForSfp.uPcsPortIdx = laneId;
    memcpy_s(&serdesTxParaForSfp,sizeof(T_SERDES_PARAM),&pPara->serdesParam[laneId],sizeof(T_SERDES_PARAM));
    serdesTxParaForSfp.laneId = laneId;
    memcpy_s(&serdesRxParaForSfp,sizeof(T_BspHalAdaptSerdesRxCfg),&pPara->serdesRxCfg[laneId],sizeof(T_BspHalAdaptSerdesRxCfg));
    laneMask = 1<<laneId;

    for(loop = 0; loop < OPT_PCS_LANE_MAX_NUM; loop++)
    {
        if(s_pSerdesCfg[loop].laneId == laneId)
        {
            memcpy_s(&s_sboardCpriPcsCfg[loop],sizeof(T_BspHalAdaptPcsCfg),&pPara->pcsCfg[laneId],sizeof(T_BspHalAdaptPcsCfg));
            memcpy_s(&s_pSerdesCfg[loop],sizeof(T_SERDES_PARAM),&pPara->serdesParam[laneId],sizeof(T_SERDES_PARAM));
            memcpy_s(&s_pSerdesRxCfg[loop],sizeof(T_BspHalAdaptSerdesRxCfg),&pPara->serdesRxCfg[laneId],sizeof(T_BspHalAdaptSerdesRxCfg));
            break;
        }
    }
    if(loop == OPT_PCS_LANE_MAX_NUM)
    {
        return BSP_ERROR;
    }

    retVal = BspOptNtlCrmInit(laneMask, 0);
    BspSetRetMask(retVal,0x1);

    retVal = BspHalAdaptCrmPcsSetReset(laneMask,1);
    BspSetRetMask(retVal,0x2);

    retVal = BspHalAdaptPcsPreInit(&pcsParaForSfp,1);
    BspSetRetMask(retVal,0x4);

    retVal = BspHalAdaptSerdesLoadFw(&serdesTxParaForSfp, 1);
    BspSetRetMask(retVal,0x8);

    retVal = BspHalAdaptSerdesTxInit(&serdesTxParaForSfp, 1);
    BspSetRetMask(retVal,0x10);

    retVal =  BspHalAdaptSetSerdesTxEq(&serdesTxParaForSfp, 1);
    BspSetRetMask(retVal,0x20);

    retVal =  BspHalAdaptSerdesRxInit(&serdesTxParaForSfp,&serdesRxParaForSfp, 1);
    BspSetRetMask(retVal,0x40);

    retVal = BspHalAdaptSerdesChgNormal(&serdesTxParaForSfp, 1);
    BspSetRetMask(retVal,0x80);

    retVal =  BspHalAdaptPcsInit(&pcsParaForSfp,1);
    BspSetRetMask(retVal,0x100);

    retVal = BspOptNtlCrmInit(laneMask, 1);
    BspSetRetMask(retVal,0x200);

    retTotal = s_ntlCpriInitRetMask;

    BspGetBoardResetType();
    BspHalAdaptCpriCfgLineRate(laneId,0x19);    /*线速率都是25 9269在单板初始化流程里识别到片间lane已经配置了*/
#ifdef MULT_PROGRESS_S
    T_OptInitPara optInitPara = {0};
    UINT32 flag = 0;
    flag = BspHalAdaptGetLaneSavingFlag();    /*是否处于独立lane的状态*/
    if(0 == flag)
    {
      if((laneId == 1)&&(0 == g_ulInnerChipCmRec))  /*本ic 接收完主片的消息之后（上联的lane已经切换完）才能执行，执行之后信令就断了*/
      {
        BspLog(LOG_LEVEL_0,"%s\n", __func__);
        optInitPara.optWorkMode = E_OPT_MODE_CPRI;
        BspHalAdaptNtlL2ssSetSlaveFlag(1);
        BspHalAdaptNtlL2ssInit(&optInitPara);
        BspHalAdaptNtlL2ssInitVlanCfg(E_OPT_MODE_CPRI);  /*boot传输版本完成后，配置传输信令，入参暂定模式5（此接口删boot下vlan，重新建，影响较大）*/
        BspSetInnerSerdesMonitorSw(0xff);
        //BspHalAdaptCpriMapConfig(1,0,1);   /*从片指定光口cpri的上联口为主光口 9269有单独流程设置了*/
      }
    }
    else
    {
        static UINT32 l2ssCfgRec = 0;
        if(0 == l2ssCfgRec)   /*只需要执行一次 一片IC可能需要切多条lane*/
        {
            optInitPara.optWorkMode = E_OPT_MODE_CPRI;   /*只有qcell有差异 其他机型对L2SS全是cpri 而不是ecpri*/
            BspHalAdaptNtlL2ssSetSlaveFlag(1);
            BspHalAdaptNtlL2ssInit(&optInitPara);
            BspHalAdaptNtlL2ssInitVlanCfg(E_OPT_MODE_CPRI);  /*boot传输版本完成后，配置传输信令，入参暂定模式5（此接口删boot下vlan，重新建，影响较大）*/
            BspHalAdaptCpriCfgCmUxSel(LOG_OPT_0,LOG_OPT_0);
            BspHalAdaptCpriCfgCmUxSel(LOG_OPT_1,LOG_OPT_3);
            BspHalAdaptCpriCfgCmUxSel(LOG_OPT_2,LOG_OPT_2);
            BspHalAdaptCpriCfgCmUxSel(LOG_OPT_3,LOG_OPT_1);
            BspLog(LOG_LEVEL_0,"%s>> l2sscfg\n", __func__);
            l2ssCfgRec = 0xff;
        }
    }
#endif

#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    if (1 == BspHalAdaptGetLaneSavingFlag())
    {
       BspSetNtlL2ssTrxpEnOrDisBitmap(OPTPCS_CPRI);
    }
#endif
    return retTotal;
}

UINT32 chipCmTest(VOID)
{
    UINT32 ret = BSP_OK;

    BspSetOptCpriRelation(1,1,1);
    BspHalAdaptCpriCfgOptProperty(1,0,1,1);
    BspHalAdaptCpriCfgLineRate(1,25);
    BspNtlInitByLane(1);

    T_OptInitPara optInitPara = {0};
    optInitPara.optWorkMode = E_OPT_MODE_CPRI;
    BspHalAdaptNtlL2ssSetSlaveFlag(1);
    BspHalAdaptNtlL2ssInit(&optInitPara);
    BspHalAdaptNtlL2ssInitVlanCfg(E_OPT_MODE_CPRI);  /*boot传输版本完成后，配置传输信令，入参暂定模式5（此接口删boot下vlan，重新建，影响较大）*/
    BspSetInnerSerdesMonitorSw(0xff);

    return ret;
}

/* Started by AICoder, pid:ec5f643e731345d14c410839e08dfd22cc353d17 */
UINT32 BspChangeInnerChipCmCfg(UINT32 type)
{
     UINT32 retVal = BSP_OK;
     BspLog(LOG_LEVEL_0,"%s type %d\n", __func__, type);
#ifndef MULT_PROGRESS_S
     BspSysMsDelay(3000);
     retVal |= BspHalAdaptXmacEnOrDisable(2,SWITCH_OFF);  /*boot传版本打开2端口（已默认打开），用户态关2开9*/
     retVal |= BspHalAdaptTrxpEnOrDisable(2,SWITCH_OFF);
     retVal |= BspHalAdaptTrxpEnOrDisable(9,SWITCH_ON);
#else
     UINT32 rpuId = 0;
     rpuId = BspGetRpuId();
     if(rpuId > 0)
     {
         T_OptInitPara optInitPara = {0};
         g_ulInnerChipCmRec = 1;
         optInitPara.optWorkMode = E_OPT_MODE_CPRI;
         BspHalAdaptNtlL2ssSetSlaveFlag(1);
         retVal |= BspHalAdaptNtlL2ssInit(&optInitPara);
         retVal |= BspHalAdaptNtlL2ssInitVlanCfg(E_OPT_MODE_CPRI);  /*boot传输版本完成后，配置传输信令，入参暂定模式5（此接口删boot下vlan，重新建，影响较大）*/
     }
#endif
     return retVal;
}
/* Ended by AICoder, pid:ec5f643e731345d14c410839e08dfd22cc353d17 */

static UINT32 s_onlineCpriSwitchFlagBak = SWITCH_OFF;
UINT32 g_ulOptPathSwitchEn = SWITCH_ON;
void setoptpathswen(UINT32 en)
{
    g_ulOptPathSwitchEn = en;
}
UINT32 BspSwitchCpriLaneRouteMode(T_CpriModeLaneRoutePara * tpara)
{
    UINT32 retVal = BSP_OK;
    UINT32 rpuId = 0;
    UINT32 loopx = 0;
    UINT32 loopy = 0;
    UINT32 socNum = 0;
    UINT32 serdesPhyNo = 0;
    UINT32 lastSocNo = 0;
    UINT32 upLinkOptNoMask = 0;
    UINT32 downLinkOptNoMask = 0;
    UINT32 isNeedCfgXmac = 0;

    T_CpriModeChipSerdesPara chipSerdesPara = {0};
    T_OnlineCpriModeSwitchCfgInfo cfgInfo = {0};
    INPUT_POINTER_CHECK(tpara);
    if(SWITCH_OFF == g_ulOptPathSwitchEn)
    {
        dbgInfo("opt pathroute not allowed change\n");
        return BSP_ERROR;
    }
    BspSetLaneRoutePara(tpara,1);

    rpuId = BspGetRpuId();
    socNum = tpara->chipNum;

    dbgInfoEx("%s>> rpuId:%d socNum:%d\r\n",__func__,rpuId,socNum);
    BspLog(LOG_LEVEL_0,"%s>> rpuId:%d socNum:%d\r\n",__func__,rpuId,socNum);
    for (loopx = 0; loopx < socNum; loopx++)
    {
        dbgInfoEx("####### chipIndex:%d chipId:%d serdesNum:%d #######\r\n",loopx,tpara->chipSerdesPara[loopx].chipId,tpara->chipSerdesPara[loopx].serdesNum);
        if (rpuId == tpara->chipSerdesPara[loopx].chipId)
        {
            chipSerdesPara.chipId = tpara->chipSerdesPara[loopx].chipId;
            chipSerdesPara.serdesNum = tpara->chipSerdesPara[loopx].serdesNum;
            for(loopy = 0; loopy < chipSerdesPara.serdesNum; loopy++)
            {
                chipSerdesPara.serdesPara[loopy].serdesPortId = tpara->chipSerdesPara[loopx].serdesPara[loopy].serdesPortId;
                chipSerdesPara.serdesPara[loopy].serdesModeType = tpara->chipSerdesPara[loopx].serdesPara[loopy].serdesModeType;
                chipSerdesPara.serdesPara[loopy].serdesProp = tpara->chipSerdesPara[loopx].serdesPara[loopy].serdesProp;
                dbgInfoEx("%s>> serdes-port:%d serdes-type:%#x serdes-prop:%d\r\n",__func__,chipSerdesPara.serdesPara[loopy].serdesPortId,chipSerdesPara.serdesPara[loopy].serdesModeType,chipSerdesPara.serdesPara[loopy].serdesProp);
            }
            break;
        }
    }

    lastSocNo = tpara->chipSerdesPara[socNum-1].chipId;
    dbgInfoEx("%s>> lastSocNo:%d\r\n",__func__,lastSocNo);

    for (loopy = 0; loopy < chipSerdesPara.serdesNum; loopy++)
    {
        if (chipSerdesPara.serdesPara[loopy].serdesProp == E_SERDES_LINK_PROP_DOWNLINK)
        {
            serdesPhyNo = chipSerdesPara.serdesPara[loopy].serdesPortId;
            dbgInfoEx("%s>> downlink serdesPhyNo:%d\r\n",__func__,serdesPhyNo);
            downLinkOptNoMask |= BIT_SET(serdesPhyNo);  /*存在1上多下的场景*/
        }
    }

    for (loopy = 0; loopy < chipSerdesPara.serdesNum; loopy++)
    {
        if (chipSerdesPara.serdesPara[loopy].serdesProp == E_SERDES_LINK_PROP_UPLINK)
        {
            serdesPhyNo = chipSerdesPara.serdesPara[loopy].serdesPortId;
            dbgInfoEx("%s>> uplink serdesPhyNo:%d\r\n",__func__,serdesPhyNo);
            upLinkOptNoMask |= BIT_SET(serdesPhyNo);
        }
    }

    isNeedCfgXmac = SWITCH_ON;
    if (rpuId == 0)     /*如下接口是主MGR里的流程 这里不改的话必须要s_tCpriModeLaneRoutePara 最后一片是IC0才行**/
    {
        BspSetCpuResetMonitorStartFlag(SWITCH_ON);           /*主片放开软复位自救任务,当前最后一片是soc0*/
    }

    cfgInfo.isNeedCpriSwitch = SWITCH_ON;
    s_onlineCpriSwitchFlagBak = SWITCH_ON;
    cfgInfo.upLinkOptNoMask      = upLinkOptNoMask;
    cfgInfo.downLinkOptNoMask    = downLinkOptNoMask;
    cfgInfo.isNeedCfgXmac    = isNeedCfgXmac;
    cfgInfo.routePath = tpara->routePath;
    BspSetOnlineCpriModeSwitchCfgInfo(&cfgInfo);

    return retVal;
}

static T_OnlineCpriModeSwitchCfgInfo s_OnlineCpriModeSwitchCfgInfo = {0,0,0,0,0};

UINT32 BspSetOnlineCpriModeSwitchCfgInfo(T_OnlineCpriModeSwitchCfgInfo *cfgInfo)
{
    INPUT_POINTER_CHECK(cfgInfo);

    s_OnlineCpriModeSwitchCfgInfo.isNeedCpriSwitch = cfgInfo->isNeedCpriSwitch;
    s_OnlineCpriModeSwitchCfgInfo.upLinkOptNoMask      = cfgInfo->upLinkOptNoMask;
    s_OnlineCpriModeSwitchCfgInfo.downLinkOptNoMask    = cfgInfo->downLinkOptNoMask;
    s_OnlineCpriModeSwitchCfgInfo.isNeedCfgXmac    = cfgInfo->isNeedCfgXmac;
    s_OnlineCpriModeSwitchCfgInfo.routePath    = cfgInfo->routePath;
    
    return BSP_OK;
}

UINT32 BspGetOnlineCpriModeSwitchCfgInfo(T_OnlineCpriModeSwitchCfgInfo *cfgInfo)
{
    INPUT_POINTER_CHECK(cfgInfo);

    cfgInfo->isNeedCpriSwitch = s_OnlineCpriModeSwitchCfgInfo.isNeedCpriSwitch;
    cfgInfo->upLinkOptNoMask      = s_OnlineCpriModeSwitchCfgInfo.upLinkOptNoMask;
    cfgInfo->downLinkOptNoMask    = s_OnlineCpriModeSwitchCfgInfo.downLinkOptNoMask;
    cfgInfo->isNeedCfgXmac    = s_OnlineCpriModeSwitchCfgInfo.isNeedCfgXmac;
    cfgInfo->routePath    = s_OnlineCpriModeSwitchCfgInfo.routePath;

    return BSP_OK;
}

UINT32 BspSetOnLneCpriModeSwitchInThread(UINT32 sw)
{
    T_OnlineCpriModeSwitchCfgInfo cfgInfo = {0};

    BspGetOnlineCpriModeSwitchCfgInfo(&cfgInfo);
    cfgInfo.isNeedCpriSwitch = sw;
    BspSetOnlineCpriModeSwitchCfgInfo(&cfgInfo);

    return BSP_OK;
}

static VOID showcprioptpara(void)
{
    T_OnlineCpriModeSwitchCfgInfo cfgInfo = {0};

    BspGetOnlineCpriModeSwitchCfgInfo(&cfgInfo);
    dbgInfo("isNeedCpriSwitch:%d historystatus:%d\r\n",cfgInfo.isNeedCpriSwitch,s_onlineCpriSwitchFlagBak);
    dbgInfo("upLinkOptNoMask:%d\r\n",cfgInfo.upLinkOptNoMask);
    dbgInfo("downLinkOptNoMask:%d\r\n",cfgInfo.downLinkOptNoMask);
    dbgInfo("isNeedCfgXmac:%d\r\n",cfgInfo.isNeedCfgXmac);
    dbgInfo("routePath:%d\r\n",cfgInfo.routePath);
}

UINT32 BspGetOnlineCpriModeSwitch(UINT32 *sw)
{
    UINT32 isNeedCpriSwitch = 0;
    T_OnlineCpriModeSwitchCfgInfo cfgInfo = {0};

    INPUT_POINTER_CHECK(sw);

    BspGetOnlineCpriModeSwitchCfgInfo(&cfgInfo);
    isNeedCpriSwitch = cfgInfo.isNeedCpriSwitch;
    *sw = isNeedCpriSwitch;

    return BSP_OK;
}

static UINT8 s_cpriSwitchRec = 0;   /*是否已经执行过25G切换*/
UINT8 BspGetCpriSwitchRec(VOID)
{
    return s_cpriSwitchRec;
}
UINT32 BspSocInnerSerdesLaneRateSwitch(VOID)
{
    UINT32 retVal = 0;
    UINT32 downLinkOptNoMask = 0;
    UINT32 upLinkOptNoMask = 0;
    UINT32 isNeedCfgXmac = 0;
    T_OnlineCpriModeSwitchCfgInfo cfgInfo = {0};
    UINT32 workMode = 0xff;
    UINT32 loop = 0;
    UINT32  savingFlag = BspHalAdaptGetLaneSavingFlag();
    UINT32 routePath = 0;

    BspGetOnlineCpriModeSwitchCfgInfo(&cfgInfo);
    isNeedCfgXmac = cfgInfo.isNeedCfgXmac;
    downLinkOptNoMask = cfgInfo.downLinkOptNoMask;
    upLinkOptNoMask= cfgInfo.upLinkOptNoMask;
    routePath =  cfgInfo.routePath;
    for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
    {
        if(0 != (BIT_SET(loop)&downLinkOptNoMask))
        {
            retVal |= BspNtlInitByLane(loop);
            BspSysMsDelay(5000);
        }
    }

    for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
    {
        if(0 != (BIT_SET(loop)&upLinkOptNoMask))
        {
            retVal |= BspNtlInitByLane(loop);
            BspSysMsDelay(1000);
        }
    }

    dbgInfo("%s>> routePath %d downLinkOptNoMask:0x%x, upLinkOptNoMask:0x%x\r\n",__func__,routePath, downLinkOptNoMask,upLinkOptNoMask);
    BspLog(LOG_LEVEL_0,"%s>> downLinkOptNoMask:0x%x, upLinkOptNoMask:0x%x\r\n",__func__,downLinkOptNoMask,upLinkOptNoMask);
    s_cpriSwitchRec = 1;
    if (isNeedCfgXmac == SWITCH_ON)
    {
        if(1 == savingFlag)   /*合一lane模式下*/
        {
            BspSetNtlL2ssTrxpEnOrDisBitmap(OPTPCS_CPRI);
            return BSP_OK;
        }
        if(0 == BspGetRpuId())    /*主片需要 从片不需要*/
        {
            retVal |= BspHalAdaptXmacEnOrDisable(2,SWITCH_OFF);  /*boot传版本打开2端口（已默认打开），用户态关2开9*/
            retVal |= BspHalAdaptTrxpEnOrDisable(2,SWITCH_OFF);
            retVal |= BspHalAdaptXmacEnOrDisable(9,SWITCH_ON);  /*对外IC不需要设置此端口开关*/
            retVal |= BspHalAdaptTrxpEnOrDisable(9,SWITCH_ON);
        }
        else
        {
            workMode = BspGetOptWorkMode(0);
            if(BSP_OPT_WORK_MODE_SHARE == workMode)   /*高层保证负荷分担组网下发之后调用切换片间lane为双上联*/
            {
                  BspHalAdaptCpriSetTxRxPPoint(0,1,0x14);    /*从片负荷分担 主片必然是TDDIR 从片需要配置P值*/
                  BspHalAdaptCpriCfgCmUxSel(LOG_OPT_0,LOG_OPT_0);
                  BspHalAdaptCpriCfgCmUxSel(LOG_OPT_1,LOG_OPT_1);
                  BspHalAdaptCpriCfgCmUxSel(LOG_OPT_2,LOG_OPT_2);
                  BspHalAdaptCpriCfgCmUxSel(LOG_OPT_3,LOG_OPT_3);
            }
        }
    }

    return retVal;
}

UINT32 BspOptSerdesRxInitWithRetry(UINT32 maxRetryTime)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    INT32 retryTimes = -1;

    /* 光口Rx Serdes初始化 */
    while(1)
    {
        retryTimes++;
        retVal = BspOptSerdesRxInit();
        if(BSP_OK == retVal)
        {
            dbgInfo("%s Opt Serdes init success, retry time = %d\n", __FUNCTION__, retryTimes);
            break;
        }
        if(retryTimes >= maxRetryTime)
        {
            dbgInfo("%s cancel for retry time = %d failed!\n", __FUNCTION__, retryTimes);
            break;
        }
        BspSysMsDelay(200);
    }
    retTotal |= retVal;

    /* 光口Serdes切到正常模式 */
    retVal = BspOptSerdesChgNormal();
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspOptSerdesChgNormal, retVal);
    s_serdesRxInitedFlag = BspHalAdaptGetLycaSoftResetFlag();
    BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_OFF);   /*初始化之后是可以配置serdes的*/
    BspFpgaReLoadFlagSet(0);/*将标志改为默认不初始化时钟和光口状态*/

    return retTotal;
}

UINT32 BspGetInnerLaneMask(VOID)
{
    return s_innerSerdesLanMask;
}

static UINT32 s_innerSerdesMonitorSw = 0xff;
UINT32 BspSetInnerSerdesMonitorSw(UINT32 lanemask)
{
    s_innerSerdesMonitorSw = lanemask;
    return BSP_OK;
}

static UINT32 s_ulLimitTransferChipOptMonitorSw = 0xFF;
UINT32 LimitTrsrSetChipOptMonitorSw(UINT32 ulOptMask)
{
    s_ulLimitTransferChipOptMonitorSw = ulOptMask;
    return BSP_OK;
}

static UINT32 s_aulLimitTrsrChipOptStatus[OPT_SERDES_LANE_MAX_NUM][10] = {{0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                                          {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                                          {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                                                                          {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
static UINT32 s_aulLimitTrsrChipOptCfgInfo[OPT_SERDES_LANE_MAX_NUM][2][2] = {{{0, 0}, {0, 0}},
                                                                             {{0, 0}, {0, 0}},
                                                                             {{0, 0}, {0, 0}},
                                                                             {{0, 0}, {0, 0}}};
UINT32 DbgLimitTrsrChipOptMonitor(VOID)
{
    UINT32 ulPhyOpt = 0;

    for (ulPhyOpt = 0; ulPhyOpt < OPT_SERDES_LANE_MAX_NUM; ulPhyOpt++)
    {
        dbgInfo("%s>>InitFlag'%3d: LimitTrsrMode= %3d; HalExtMode= %3d; GetPropRet= 0x%04X; InterConn= %d;\n", __FUNCTION__,
                s_aulLimitTrsrChipOptStatus[ulPhyOpt][0], s_aulLimitTrsrChipOptStatus[ulPhyOpt][1],
                s_aulLimitTrsrChipOptStatus[ulPhyOpt][2], s_aulLimitTrsrChipOptStatus[ulPhyOpt][3],
                s_aulLimitTrsrChipOptStatus[ulPhyOpt][4]);
        dbgInfo("%s>>WaitCnt'%4d: LimitTrsrMode= %3d; HalExtMode= %3d; GetPropRet= 0x%04X; InterConn= %d;\n", __FUNCTION__,
                s_aulLimitTrsrChipOptStatus[ulPhyOpt][5], s_aulLimitTrsrChipOptStatus[ulPhyOpt][6],
                s_aulLimitTrsrChipOptStatus[ulPhyOpt][7], s_aulLimitTrsrChipOptStatus[ulPhyOpt][8],
                s_aulLimitTrsrChipOptStatus[ulPhyOpt][9]);
        dbgInfo("%s>>PhyOpt'%d AxcArrangeCfg: NormalCfg= Ret'0x%04X  Flag'%d; ExtendCfg= Ret'0x%04X  Flag'%d;\n\n", __FUNCTION__,
                ulPhyOpt, s_aulLimitTrsrChipOptCfgInfo[ulPhyOpt][0][0], s_aulLimitTrsrChipOptCfgInfo[ulPhyOpt][0][1],
                s_aulLimitTrsrChipOptCfgInfo[ulPhyOpt][1][0], s_aulLimitTrsrChipOptCfgInfo[ulPhyOpt][1][1]);
    }
    return BSP_OK;
}
/*增加任务停止接口*/
UINT32 BspSetInnerSerdesMonitorExSw(UINT32 mask)
{
    s_innerSerdesMonitoExSw = mask;
    return BSP_OK;
}

/*针对片间serdes 上联口和sgmii 优先进行监控处理 下联口往后*/
UINT32 BspGetInnerSerdesMonitorPriority(UINT32 laneId, UINT32 serdesSpeed)
{
    UINT32 priority = 0;
    UINT32 optProperty = 0;
    UINT32 optInterConn = 0;
    UINT32 retVal = BSP_OK;

    /* ulOptProperty : 0-表示上联, 1-表示下联, 2-表示未知态, 3-表示无光态
       ulOptInterConn: 1-表示CHIP间互联光口，与ulPropertyCfgEn 无关 */
    retVal = BspHalAdaptGetOptProperty(laneId, &optProperty, &optInterConn);
    CHECK_RETVAL_PRN(BspHalAdaptGetOptProperty, retVal);
    if((optProperty == 0)||( serdesSpeed == SERDES_RATE_1G25))
    {
        priority = 1;   /*要优先监控*/
    }
    else
    {
        priority = 0;   /*下联口*/
    }
    dbgInfoEx("[%s] LaneId= %d, serdesSpeed %d, optProperty= %d priority %d \n",
              __FUNCTION__, laneId, serdesSpeed, optProperty ,priority);

    return priority;
}
/*片间的网口 只需要监控低6bit */
UINT32 BspGetPcsRealAlmBySpeed(UINT32 laneId, UINT32 serdesSpeed)
{
    UINT32 pcsSta =0;
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptPcsGetLinkPcsSta(laneId,&pcsSta);
    CHECK_RETVAL_PRN(BspHalAdaptLycaInitRx, retVal);
    dbgInfoEx("[%s] uplink Loop(Sum'%d PhyOpt'%d: PcsSta= 0x%x\n", __FUNCTION__,
          s_serdesLaneNum, laneId, pcsSta);
    if(serdesSpeed == SERDES_RATE_1G25)
    {
         pcsSta = pcsSta&0x3f;/*1.25G速率只关注低6bit*/
    }

    return pcsSta;
}

/*1.25g lane且pcs异常才会调用此接口  规避负荷分担时主片lane2发起了25G切换，但是从片消息丢失未收到切换命令 还是保持1.25G故障*/
/* Started by AICoder, pid:jcad87b48ax9a84146f70a7660840f440738a87c */
UINT32 BspSgmiiLaneSelfSaveCfg(UINT32 laneId)
{
    UINT32 workMode = BSP_OPT_WORK_MODE_CASCADE_NORMAL;
    UINT32 isNeedCpriSwitch = SWITCH_OFF;
    T_CpriModeLaneRoutePara routePara = {0};
    UINT8 cpriSwRec = 0;
    UINT8 clkSta = 0;
    UINT8 optSta = 0;

    if(0 == BspGetRpuId())   /*修改只针对从片*/
    {
        return BSP_OK;
    }
    if(1 != g_ulInnerChipCmRec)   /*已经执行过信令切换到lane3--lane0  单独复位从片不会进来, 因为BspChangeInnerChipCmCfg 只在支持负荷分担的机型 整机上电BBU建链前执行一次*/
    {
        return BSP_OK;
    }
    workMode = BspGetOptWorkMode(0);
    if(BSP_OPT_WORK_MODE_SHARE == workMode)   /*应对场景为负荷分担组网下 从片没有收到25G切换消息 而主片已经切了 此时速率还是1.25 切成25之后不会再进来*/
    {
        BspGetOnlineCpriModeSwitch(&isNeedCpriSwitch);
        if(SWITCH_OFF== isNeedCpriSwitch)   /*从片此刻还没收到下发切换的命令  如果已经下发而且已经执行，速率不会还是1.25G  切换的动作也在自救任务里是顺序执行的*/
        {
            dbgInfoEx("%s laneId %d  errcnt %d\n",__func__,laneId, g_sgmiiLaneErrCnt );
            if(g_sgmiiLaneErrCnt <  MAX_SGMII_LANE_ERR_CNT+1) /*读取主片lane2的速率是否是25G 如果多次异常则主动发起一次切换  注意不要反复执行 加个最大次数限制*/
            {
                (void)BspGetRruSysPllStatus(&clkSta,&optSta,&cpriSwRec);
                if(SWITCH_ON == cpriSwRec)   /*主片已切 如果消息不通计数不增加*/
                {
                     BspLog(LOG_LEVEL_0,"%s laneId %d errcnt %d\n",__func__,laneId,g_sgmiiLaneErrCnt);
                     dbgInfo("%s laneId %d errcnt++ %d\n",__func__,laneId,g_sgmiiLaneErrCnt);
                     g_sgmiiLaneErrCnt++;
                }
            }
            if(MAX_SGMII_LANE_ERR_CNT == g_sgmiiLaneErrCnt)    /*次数不能太多 要在主片发起整机掉电自救（大于8min）之前完成  同时也不能太短，要考虑从片刚收到了切换指令，但是本接口还未读到的时间  5s一轮*/
            {
                BspGetOptCpriModePathLaneRoutePara(0, &routePara);
                BspSwitchCpriLaneRouteMode(&routePara);
                g_sgmiiLaneErrCnt = MAX_SGMII_LANE_ERR_CNT+1;
                BspLog(LOG_LEVEL_0,"%s laneId %d cpriswtich\n",__func__,laneId);
            }
        }
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:jcad87b48ax9a84146f70a7660840f440738a87c */
/*片间cpri 上联的lane和sgmii状态监控*/
VOID BspInnerSerdesUplinkMonitor(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 laneId = 0;
    UINT32 pcsSta = 0;
    UINT32 serdesId = 0;
    UINT32 pcsStaOk = 0x3;/*0x3低2bit为1为正常*/
    UINT32 serdesSpeed = 0;
    UINT32 txSwitch = 0;
    UINT32 uplinkCntMax = 5;
    T_BspHalAdaptSerdesRxCfg *serdesRxCfg = NULL;
    UINT32 cdrSta = BSP_OK;

    for(loop = 0; loop < s_serdesLaneNum; loop++)
     {
         serdesId    = s_pSerdesCfg[loop].serdesId;
         laneId      = s_pSerdesCfg[loop].laneId;
         serdesSpeed = s_pSerdesCfg[loop].rate;
         INPUT_INNER_LANE_MASK_CHECK(laneId);
         INPUT_INNER_LANE_SW_CHECK(laneId);
         INPUT_LANEID_CHECK_RETURN(laneId);

         if(BspGetInnerSerdesMonitorPriority(laneId,serdesSpeed)) /*先上联 或者sgmii sgmii优先级其实是最高的*/
         {
             pcsSta = BspGetPcsRealAlmBySpeed(laneId,serdesSpeed);
             BspGetOptCdrStatus(laneId, &cdrSta);
             dbgInfoEx("txSwitchRec[laneId %d] %d uplinkCnt %d pcsSta 0x%x cdrSta %d\n",laneId,txSwitchRec[laneId],uplinkCnt[laneId] ,pcsSta, cdrSta);
             if((pcsSta == pcsStaOk)&&(BSP_OK == cdrSta))
             {
                 innerSerdesSta &= BIT_REV(laneId);   /*上联口正常时置0*/
                 dbgInfoEx("innerSerdesSta %d\n",innerSerdesSta);
                 if(serdesSpeed != SERDES_RATE_1G25)  /*片间cpri，sgmii先不考虑从对端自救*/
                 {
                     txSwitchRec[laneId] = 0;
                     uplinkCnt[laneId] = 0;
                     (VOID)BspApiLycaGetTxDataNrzEn(serdesId,laneId,&txSwitch);
                     if(txSwitch != SWITCH_ON)
                     {
/*                         检查TX是否关闭，如果此时是关闭态  需要恢复TX，初始化TX会影响自己的RX
                         (VOID)BspApiLycaTxDataNrzEn(serdesId,laneId,SWITCH_ON);*/
                         /*初始化TX */
                         BspHalAdaptSerdesTxInit(&s_pSerdesCfg[loop],1);
                         BspHalAdaptSetSerdesTxEq(&s_pSerdesCfg[loop],1);
                         BspNtlPcsReCfg(laneId);
                         txSwitchRec[laneId]  = 1;   /*恢复时初始化TX 引起的RX异常，此时不关自己的TX*/
                         uplinkCnt[laneId]  = 0;
                     }
                 }
                 continue;
             }
#if defined(_BSP_WITH_WFS)
#else
             BspLog(LOG_LEVEL_0,"txSwitchRec[laneId %d] %d uplinkCnt %d pcsSta 0x%x cdrSta %d txSwitch %d\n",laneId,txSwitchRec[laneId],uplinkCnt[laneId] ,pcsSta,cdrSta, txSwitch);
#endif
             innerSerdesSta |= BIT_SET(laneId);   /*上联口异常时置1*/
             dbgInfoEx("innerSerdesSta %d\n",innerSerdesSta);
             serdesRxCfg = &s_pSerdesRxCfg[loop];
             retVal = BspHalAdaptLycaInitRx(serdesId, laneId,serdesRxCfg);
             CHECK_RETVAL_PRN(BspHalAdaptLycaInitRx, retVal);

             retVal = BspHalAdaptLycaTccSwitch(serdesId, laneId);
             CHECK_RETVAL_PRN(BspHalAdaptLycaTccSwitch, retVal);
             BspNtlPcsRxReset(laneId); 
             if(serdesSpeed != SERDES_RATE_1G25)  /*片间cpri*/
             {
                 /*关闭TX方向，让对端检测到告警*/
                 dbgInfoEx("uplink laneId %d \n",laneId);
                 if((txSwitchRec[laneId]  != 1)||(uplinkCnt[laneId] > uplinkCntMax))   /*自己TX初始化引起的RX异常，只初始化RX，最多5次，还不恢复则让整个流程转起来，从对端流程恢复本地*/
                 {
                     dbgInfoEx("uplink laneId %d  off; txSwitchRec[laneId] %d uplinkCnt[laneId]%d\n",laneId,txSwitchRec[laneId],uplinkCnt[laneId]);
                     (VOID)BspApiLycaTxDataNrzEn(serdesId,laneId,SWITCH_OFF);
                     uplinkCnt[laneId] = 0;
                 }
             }
             else   /*1.25G异常可能是对端切了25G 需要额外自救流程*/
             {
                  BspSgmiiLaneSelfSaveCfg(laneId);
             }
             uplinkCnt[laneId] ++;
         }
         else
         {
             innerSerdesSta &= BIT_REV(laneId);    /*原来是sgmii  现在切成cpri 需要清掉  否则影响下联口自救*/
         }
     }
     return;
}

/*获取对外光口的建链状态*/
UINT32 BspGetRruSysPllStatus(UINT8 *pClkSta, UINT8 *pOptSta, UINT8 *pCpriSwRec)
{
    UINT32 retVal = BSP_OK;
    UINT32 rpuId = 0;
    UINT32 mainOpt = 0;
    UINT32 clkSta = 0xf;

    INPUT_POINTER_CHECK(pClkSta);
    INPUT_POINTER_CHECK(pOptSta);
    INPUT_POINTER_CHECK(pCpriSwRec);
    rpuId = BspGetRpuId();
    if(rpuId > 0)
    {
        retVal = BspGetSysPllStatusFromMain(pClkSta, pOptSta,pCpriSwRec);
    }
    else  /*主片主MGR*/
    {
        BspHalAdaptGetMainPhyOpt(&mainOpt);
        BspHalAdaptGetSysLd(0,&clkSta);
        if((BSP_ERROR != mainOpt)&&(BSP_OK == clkSta))
        {
            *pClkSta = CLK_STA_OK;
            *pOptSta = OPT_STA_OK;
        }
    }
    dbgInfoEx("BspGetRruSysPllStatus clkSta %d, optSta %d(0:err 1:ok) cpriSwRec %d\n", *pClkSta, *pOptSta, *pCpriSwRec);

    return retVal;
}
/*片间cpri 下联的lane 状态监控*/
VOID BspInnerSerdesDownlinkMonitor(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 laneId = 0;
    UINT32 pcsSta = 0;
    UINT32 serdesId = 0;
    UINT32 pcsStaOk = 0x3;/*0x3低2bit为1为正常*/
    UINT32 serdesSpeed = 0;
    T_BspHalAdaptSerdesRxCfg *serdesRxCfg = NULL;
    UINT32 downlinkRxLimit = 15;
    UINT32 downlinkTxLimit = 5;
    UINT8 clkSta = 0;
    UINT8 optSta = 0;
    UINT8 cpriSw = 0;
    UINT32 cdrSta = 0;

     for(loop = 0; loop < s_serdesLaneNum; loop++)
     {
         serdesId    = s_pSerdesCfg[loop].serdesId;
         laneId      = s_pSerdesCfg[loop].laneId;
         serdesSpeed = s_pSerdesCfg[loop].rate;
         INPUT_INNER_LANE_MASK_CHECK(laneId);
         INPUT_INNER_LANE_SW_CHECK(laneId);
         INPUT_LANEID_CHECK_RETURN(laneId);

         if(0 == BspGetInnerSerdesMonitorPriority(laneId,serdesSpeed)) /*后下联*/
         {
             pcsSta = BspGetPcsRealAlmBySpeed(laneId,serdesSpeed);
             BspGetOptCdrStatus(laneId, &cdrSta);
             if((pcsSta == pcsStaOk)&&(BSP_OK == cdrSta))
             {
                 downlinkTxCnt[laneId] = 0;
                 downlinkRxCnt[laneId] = 0;
                 continue;
             }
             downlinkRxCnt[laneId]++;
             serdesRxCfg = &s_pSerdesRxCfg[loop];
             retVal = BspHalAdaptLycaInitRx(serdesId, laneId,serdesRxCfg);
             CHECK_RETVAL_PRN(BspHalAdaptLycaInitRx, retVal);

             retVal = BspHalAdaptLycaTccSwitch(serdesId, laneId);
             CHECK_RETVAL_PRN(BspHalAdaptLycaTccSwitch, retVal);
             BspNtlPcsRxReset(laneId);
             dbgInfoEx("downlink laneId %d downlinkRxCnt[laneId] %d pcsSta 0x%x cdrSta %d\n",laneId,downlinkRxCnt[laneId], pcsSta, cdrSta);
             if(downlinkRxCnt[laneId] > downlinkRxLimit)   /*因为对端上联口TX关闭而连续检测到异常*/
             {
                 /*初始化TX */
                 (VOID)BspHalAdaptSerdesTxInit(&s_pSerdesCfg[loop],1);
                 (VOID)BspHalAdaptSetSerdesTxEq(&s_pSerdesCfg[loop],1);
                 BspNtlPcsReCfg(laneId);
                 downlinkRxCnt[laneId] = 0; /*接收异常计数n清0*/
                 BspGetRruSysPllStatus(&clkSta,&optSta,&cpriSw);
                 if((CLK_STA_OK == clkSta)&&(OPT_STA_OK == optSta))  /*对外光口建链才能计数 否则开始长时间不建链 后续建链高层会误报告警及复位*/
                 {
                     downlinkTxCnt[laneId]++;   /*TX初始化计数计数m+1*/
                 }
                 else
                 {
                     downlinkTxCnt[laneId] = 0;
                 }
             }
             dbgInfoEx("downlink laneId %d downlinkTxCnt[laneId] %d\n",laneId,downlinkTxCnt[laneId]);
#if defined(_BSP_WITH_WFS)
#else
             BspLog(LOG_LEVEL_0,"downlink laneId %d downlinkRxCnt[laneId] %d downlinkTxCnt[laneId] %d pcsSta 0x%x cdrSta %d\n",laneId,downlinkRxCnt[laneId], downlinkTxCnt[laneId], pcsSta, cdrSta);
#endif
             if(downlinkTxCnt[laneId] > downlinkTxLimit)
             {
                 BspSetInnerSerdesStatus(1);/*给高层上报自救失败，需要整机自救复位,所以这里downlinkTxCnt 不再清0*/
             }
         }
     }

     return;
}

/*片间lane的rx状态监控*/
void BspInnerSerdesRxMonitorThread(VOID)
{
    UINT32 tmpRet = BSP_OK;
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 ulWaitCnts  = 0;
    UINT32 ulOptProperty = 0;
    UINT32 ulOptInterConn = 0;
    UINT32 ulHalExternMode = 254;
    UINT32 ulLimitTrsrMode = 254;
    UINT32 logOptNo = 0;
    UINT32 paritySeparate = 0;
    UINT32 axcChanNum = 0;
    UINT32 isNeedCpriSwitch = SWITCH_OFF;
    UINT32 cpriModeSwitchSuccessflag = BSP_ERROR;
    BspUpdateSlaveSerdesPcsPara();
    BspCommonCpriRateSwitchTypeInit();
    while(1)
    {
        OPT_INNER_LANE_CHECK_MONITOR_SW();

        IF_CHK((NULL != cpriSwitchTypeFun) && (BSP_ERROR == cpriModeSwitchSuccessflag))
        {
            cpriModeSwitchSuccessflag = cpriSwitchTypeFun();
        }
        if (BspGetRpuId() != 0)
        {
            BspConfigFrDir();/*根据当前P值，实时更新psync帧头偏移方向*/
        }

        BspGetOnlineCpriModeSwitch(&isNeedCpriSwitch);
        if(isNeedCpriSwitch != SWITCH_OFF)
        {
            BspSysMsDelay(5000);
            BspSocInnerSerdesLaneRateSwitch();
            BspSysMsDelay(5000);
            BspSetOnLneCpriModeSwitchInThread(SWITCH_OFF);
            continue;
        }

        BspInnerSerdesUplinkMonitor();

        dbgInfoEx("[%s] innerSerdesSta 0x%x\n", __FUNCTION__,innerSerdesSta);
        if(innerSerdesSta)  /*上联口没正常之前 先不处理下联口，直接跳转回去处理上联口*/
        {
            BspSysMsDelay(5000);
            continue;
        }
        BspInnerSerdesDownlinkMonitor();

        if (LIMIT_TRANSFER_SUPPORT_YES == BspGetLimitTransferSupportFlag())
        {
            for (loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++) // OPT_SERDES_LANE_MAX_NUM = 4
            {
                if (0 == (BIT_SET(loop) & s_ulLimitTransferChipOptMonitorSw))
                {
                    dbgInfoEx("%s>>PhyOpt'%d Continue: ChipOptMonitorSw= 0x%04X\n",
                              __FUNCTION__, loop, s_ulLimitTransferChipOptMonitorSw);
                    continue;
                }

                ulLimitTrsrMode = BspGetLimitTransferMode();
                /* ulOptProperty : 0-表示上联, 1-表示下联, 2-表示未知态, 3-表示无光态
                   ulOptInterConn: 1-表示CHIP间互联光口，与ulPropertyCfgEn 无关 */
                tmpRet = BspHalAdaptGetOptProperty(loop, &ulOptProperty, &ulOptInterConn);
                if ((BSP_OK == tmpRet) && (1 == ulOptInterConn))
                {
                    // 0-控制字位置不传IQ; 1-常规扩展; 3-极限扩展; BSP_ERROR-无效值
                    ulHalExternMode = IcHalApiCpriGetExternMode(loop); // loop= 主控'PHY_OPT3, 从核'PHY_OPT0

                    if (LIMIT_TRANSFER_MODE_NORMAL == ulLimitTrsrMode)
                    {
                        if (MODE_NORMAL != ulHalExternMode)
                        {
                            retVal = BspHalAdaptAxcArrangeTypeByBspRate(loop, BSP_OPT_SPEED_24P33024G, MODE_NORMAL);
                            CHECK_RETVAL_PRN(BspHalAdaptAxcArrangeTypeByBspRate, retVal);
                            s_aulLimitTrsrChipOptCfgInfo[loop][0][0] = retVal;
                            s_aulLimitTrsrChipOptCfgInfo[loop][0][1] = 1; // 1 为配置有效
                        }
                    }
                    else if (LIMIT_TRANSFER_MODE_EXTEND == ulLimitTrsrMode)
                    {
                        logOptNo = BspHalAdaptGetLogOpt(loop);
                        BspHalAdaptCpriGetAxcArrangeType(logOptNo, &paritySeparate, &axcChanNum);
                        if ((MODE_EXTREME_EXTEND != ulHalExternMode) || (1 != paritySeparate) || (1 != axcChanNum)) // 1为极限模式下axc摆放方式配置
                        {
                            retVal = BspHalAdaptAxcArrangeTypeByBspRate(loop, BSP_OPT_SPEED_24P33024G, MODE_EXTREME_EXTEND);
                            CHECK_RETVAL_PRN(BspHalAdaptAxcArrangeTypeByBspRate, retVal);
                            s_aulLimitTrsrChipOptCfgInfo[loop][1][0] = retVal;
                            s_aulLimitTrsrChipOptCfgInfo[loop][1][1] = 1; // 1 为配置有效
                        }
                    }
                }

                // Status[loop][0~4]先记录上电初始数据, Status[loop][6~9]再记录当前数据
                // 对比前后数据, 用于调试分析定位;
                if (0 == s_aulLimitTrsrChipOptStatus[loop][0])
                {
                    s_aulLimitTrsrChipOptStatus[loop][0] = 1; // 1 为记录有效
                    s_aulLimitTrsrChipOptStatus[loop][1] = ulLimitTrsrMode;
                    s_aulLimitTrsrChipOptStatus[loop][2] = ulHalExternMode;
                    s_aulLimitTrsrChipOptStatus[loop][3] = tmpRet;
                    s_aulLimitTrsrChipOptStatus[loop][4] = ulOptInterConn;
                }
                s_aulLimitTrsrChipOptStatus[loop][5] = (ulWaitCnts++) % 10000; // 只显示4 位数
                s_aulLimitTrsrChipOptStatus[loop][6] = ulLimitTrsrMode;
                s_aulLimitTrsrChipOptStatus[loop][7] = ulHalExternMode;
                s_aulLimitTrsrChipOptStatus[loop][8] = tmpRet;
                s_aulLimitTrsrChipOptStatus[loop][9] = ulOptInterConn;
                dbgInfoEx("%s>>PhyOpt'%d: LimitTrsrMode= %d; HalExtMode= %d; GetPropRet= 0x%04X; InterConn= %d;\n",
                          __FUNCTION__, loop, ulLimitTrsrMode, ulHalExternMode, tmpRet, ulOptInterConn);
            }
        }
        BspCfgMaxDelay2Point();
        BspSysMsDelay(5000);
    }
}

/* Started by AICoder, pid:x46c2m08bc7871d14951088500dabb4bdf304070 */
UINT32 BspCfgMaxDelay2Point(VOID)
{
    UINT32 maxDly2Point = 0;
    UINT32 retVal = BSP_OK;
    UINT32 phyOpt0Sta = 0;
    UINT32 phyOpt1Sta = 0;
    UINT32 halNetMode = 0;
    UINT32 rpuId = BspGetRpuId();

    retVal = BspHalAdaptGetCpriNetMode(&halNetMode);
    /* 只有从片和负荷分担才需要走这个流程，组网变化整机复位，从片时掉电复位可恢复 */
    if((rpuId >= 1) && ((halNetMode == NET_MODE_LOAD_SHARE) || (s_BoardNtlWorkMode != halNetMode)))
    {
        s_BoardNtlWorkMode = halNetMode;
        phyOpt0Sta = BspHalAdaptGetSerdesFsmStatus(BOARDNTL_PHY_OPT_0);
        phyOpt1Sta = BspHalAdaptGetSerdesFsmStatus(BOARDNTL_PHY_OPT_1);

        /* 负荷分担片间上联口0，1都正常从光口获取2点鉴相值 */
        if((phyOpt0Sta == BSP_OK) && (phyOpt1Sta == BSP_OK))
        {
            maxDly2Point = BspHalAdaptGetMaxDelay2Point();
            BspHalAdaptSetSlaveBaseDelayLogOpt(maxDly2Point);
            retVal |= BspHalAdaptCpri2PointFrSel();
        }
        else if((phyOpt0Sta == BSP_OK))
        {
            maxDly2Point = BspHalAdaptGetLogOpt(BOARDNTL_PHY_OPT_0);
            BspHalAdaptSetSlaveBaseDelayLogOpt(maxDly2Point);
            retVal |= BspHalAdaptCpri2PointFrSel();
        }
        else if((phyOpt1Sta == BSP_OK))
        {
            maxDly2Point = BspHalAdaptGetLogOpt(BOARDNTL_PHY_OPT_1);
            BspHalAdaptSetSlaveBaseDelayLogOpt(maxDly2Point);
            retVal |= BspHalAdaptCpri2PointFrSel();
        }
    }

    return retVal;
}
/* Ended by AICoder, pid:x46c2m08bc7871d14951088500dabb4bdf304070 */

T_XmacDrvParam g_XmacDrvParam =
{
    NTL_XMAC_MRU,/*.udMruVlaue = NTL_XMAC_MRU,*/
    NTL_XMAC_TX_MAX_LEN,/* .udMtuVlaue = NTL_XMAC_TX_MAX_LEN,*/
    1,/*.bEnable = 1,*/
    0,/*.bReplaceSrcMac = 0,*/
    1,/*.bTxAddPadEn = 1,*/
    0,/*.resv = 0,*/
    {0},/*.aucMacAddr[6] = {0},*/
    {0},/*.resv2[2] = {0},*/
    0,/*.b1588RcvCtl = 0,*/
    0,/*.b1588TxCtl = 0,*/
    0,/*.ePortSpeedType = 0,*/
    0,/*.eMacId = 0,*/
    e_NTL_XMAC_FEC_BYPASS,/*.fecMode = e_NTL_XMAC_FEC_BYPASS,*/
    NTL_PATH_DELAY_100M_RX,/*.udPcsRcvPathDelay = NTL_PATH_DELAY_100M_RX,*/
    NTL_PATH_DELAY_100M_TX,/*.udPcsTxPathDelay = NTL_PATH_DELAY_100M_TX,*/
    e_XMAC_SPEED_100M,/*.ePortSpeed = e_XMAC_SPEED_100M,*/
};
T_XmacDrvParam g_XmacDrvParamForSgmii =
{
    NTL_XMAC_MRU,/*.udMruVlaue = NTL_XMAC_MRU,*/
    NTL_XMAC_TX_MAX_LEN,/* .udMtuVlaue = NTL_XMAC_TX_MAX_LEN,*/
    1,/*.bEnable = 1,*/
    0,/*.bReplaceSrcMac = 0,*/
    1,/*.bTxAddPadEn = 1,*/
    0,/*.resv = 0,*/
    {0},/*.aucMacAddr[6] = {0},*/
    {0},/*.resv2[2] = {0},*/
    0,/*.b1588RcvCtl = 0,*/
    0,/*.b1588TxCtl = 0,*/
    0,/*.ePortSpeedType = 0,*/
    0,/*.eMacId = 0,*/
    e_NTL_XMAC_FEC_BYPASS,/*.fecMode = e_NTL_XMAC_FEC_BYPASS,*/
    NTL_PATH_DELAY_1000M_RX,/*.udPcsRcvPathDelay = NTL_PATH_DELAY_100M_RX,*/
    NTL_PATH_DELAY_1000M_TX,/*.udPcsTxPathDelay = NTL_PATH_DELAY_100M_TX,*/
    e_XMAC_SPEED_1G,/*.ePortSpeed = e_XMAC_SPEED_100M,*/
};
UINT32 BspNaccXmacInit(UINT32 xmacId)
{
    UINT32 retVal = BSP_OK;
#ifndef MULT_PROGRESS_S
    UINT32 optId = 0;
    UINT32 phySpeed = OPT_MAC_SPEED_100M;
    T_XmacDrvParam tmpXmacDrvParam = {0};

    optId = BspGetSfpNoByPhyNo(xmacId);

    if(optId == BSP_ERROR){
        return BSP_ERROR;
    }
    
    phySpeed = BspGetCfgMacSpeed(optId);
    if(phySpeed == OPT_MAC_SPEED_1000M)
    {
        memcpy_s(&tmpXmacDrvParam, sizeof(T_XmacDrvParam), &g_XmacDrvParamForSgmii, sizeof(T_XmacDrvParam));
    }
    else
    {
        memcpy_s(&tmpXmacDrvParam, sizeof(T_XmacDrvParam), &g_XmacDrvParam, sizeof(T_XmacDrvParam));
    }
    tmpXmacDrvParam.eMacId = xmacId;
    retVal = BspHalAdaptNaccXmacInit(&tmpXmacDrvParam);
#endif
    return retVal;
}
UINT32 BspNaccXmacInitNcr(UINT32 xmacId)
{
    UINT32 retVal = BSP_OK;
    UINT32 optId = 0;
    T_XmacDrvParam tmpXmacDrvParam = {0};

    optId = BspGetSfpNoByPhyNo(xmacId);

    if(optId == BSP_ERROR){
        return BSP_ERROR;
    }

    memcpy_s(&tmpXmacDrvParam, sizeof(T_XmacDrvParam), &g_XmacDrvParamForSgmii, sizeof(T_XmacDrvParam));

    tmpXmacDrvParam.eMacId = xmacId;
    retVal = BspHalAdaptNaccXmacInit(&tmpXmacDrvParam);
    return retVal;
}

UINT32 BspNtlInitForSgmii(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 xmacId = 0;
    T_XmacDrvParam tmpXmacDrvParam = {0};
    UINT32 loop = 0;

    for(loop = 0; loop < s_boardPcsUsedLanedNum; loop++)
    {
        if(s_sboardCpriPcsCfg[loop].uEthOrCpri == OPTPCS_ETH)
        {
            xmacId = s_sboardCpriPcsCfg[loop].uPcsPortIdx;
            memcpy_s(&tmpXmacDrvParam,sizeof(T_XmacDrvParam),&g_XmacDrvParamForSgmii,sizeof(T_XmacDrvParam));
            tmpXmacDrvParam.eMacId = xmacId;
            retVal = BspHalAdaptNaccXmacInit(&tmpXmacDrvParam);
            (VOID)BspHalAdaptTrxpEnOrDisable(xmacId,1);
            (VOID)BspHalAdaptXmacEnOrDisable(xmacId,1);
            //BspHalAdaptTrxpEnOrDisable(13);  /*已经配置不用重新配*/
        }
    }
    return retVal;
}

UINT32 BspQcellSetAllL2ssTrxpEn(UINT32 enSw)
{
    UINT32 retVal = BSP_OK;

    for(UINT32 udPortNum=0; udPortNum<=15; udPortNum++ )
    {
        if( 1 == udPortNum || 15 == udPortNum) /* qcell 1 和 15 口是debug口，不需要操作 */
        {
            continue;
        }
        retVal |= BspHalAdaptTrxpEnOrDisable(udPortNum,enSw); /* 初始化的时候全关 */
    }

    return retVal;
}

UINT32 BspUbrSetAllL2ssTrxpEn(UINT32 enSw)
{
    UINT32 retVal = BSP_OK;

    for(UINT32 udPortNum=0; udPortNum<=15; udPortNum++ )
    {
         /* UBR 0  1 和 15 口是debug口，不需要操作;级联和非级联场景关掉14口就行，7和8不用动 */
        if(0 == udPortNum || 1 == udPortNum || 15 == udPortNum || 7 == udPortNum || 8 == udPortNum)
        {
            continue;
        }
        retVal |= BspHalAdaptTrxpEnOrDisable(udPortNum,enSw); 
    }

    return retVal;
}

/* Ntl 初始化时候对Trxp和Xmac的使能 */
UINT32 BspNtlInitSetTrxpXmacEn(UINT32 enSw)
{
    UINT32 retVal = BSP_OK;
#ifndef  MULT_PROGRESS_S
    UINT32 xmacId = 0;
    UINT32 loop = 0;
    UINT32 rpuNum = BspGetRpuNum();
#endif

    /*  1、QCELL */
    if( (RRU_PB_BBU == BspGetPbOrBbuMode()) || (RRU_BBU ==  BspGetPbOrBbuMode()) ) 
    {
        (VOID)BspHalAdaptXmacEnOrDisable(0,enSw);

        /* trxp 上电流程只关注关闭即可，开流程由后续谁用谁打开 */
        if(DISABLE == enSw) 
        {
            BspQcellSetAllL2ssTrxpEn(enSw);
        }
        
    }
    
    /* 2、UBR */
#ifndef  MULT_PROGRESS_S
    if(rpuNum > 1 && DISABLE == enSw)
    {
        for(loop = 0; loop < s_boardPcsUsedLanedNum; loop++)
        {
            if(s_sboardCpriPcsCfg[loop].uEthOrCpri == OPTPCS_ETH)
            {
                xmacId = s_sboardCpriPcsCfg[loop].uPcsPortIdx;
                (VOID)BspHalAdaptXmacEnOrDisable(xmacId,enSw);
            }
        }

        BspUbrSetAllL2ssTrxpEn(enSw);
    }
#endif

    /* 3、TDD FDD T+F
        xmac在boot阶段配置，此处无需关注开关
     */

    return retVal;    
}


/*reset pcs rx*/
UINT32 BspNtlPcsRxReset(UINT32 laneId)
{
    UINT32 retVal = BSP_OK;
    UINT32 pcsCfgEn = 0;

    pcsCfgEn = BspGetOptPcsCfgEn();
    if(1 == pcsCfgEn) /*1表示光口占用*/
    {
         BspSysMsDelay(150);
    }
    pcsCfgEn = BspGetOptPcsCfgEn();
    if(0 == pcsCfgEn) /*0表示光口未占用*/
    {
        BspHalAdaptPcsSetGloableCfgEn(laneId, 1);
        BspHalAdaptPcsSet1XLinkCfgEn(laneId, RX, DISABLE);
        BspSysMsDelay(10);
        BspHalAdaptPcsSet1XLinkCfgEn(laneId, RX, ENABLE);
        BspHalAdaptPcsSetGloableCfgEn(laneId, 0);
        dbgInfoEx("BspNtlPcsRxReset LANE %d\n",laneId);
    }

    return retVal;
}

/*pcs reinit*/
UINT32 BspNtlPcsReCfg(UINT32 laneId)
{
    UINT32 retVal = BSP_OK;
    UINT32 pcsCfgEn = 0;
    UINT32 loopIndex = 0;
    T_BspHalAdaptPcsCfg pcsCfg = {0};

    for(loopIndex = 0; loopIndex < s_boardPcsUsedLanedNum; loopIndex++)
    {
        if(s_sboardCpriPcsCfg[loopIndex].uPcsPortIdx == laneId)
        {
            memcpy_s(&pcsCfg,sizeof(T_BspHalAdaptPcsCfg),&s_sboardCpriPcsCfg[loopIndex],sizeof(T_BspHalAdaptPcsCfg));
            break;
        }
    }
    if(loopIndex == s_boardPcsUsedLanedNum)
    {
        return BSP_ERROR;
    }
    dbgInfoEx("loopIndex %d uPcsPortIdx %d, udEthOrCpri %d uProtocolType %d udFecMode %d",      \
               loopIndex,pcsCfg.uPcsPortIdx,pcsCfg.uEthOrCpri,pcsCfg.uProtocolType,pcsCfg.uFecMode);
    pcsCfgEn = BspGetOptPcsCfgEn();
    if(1 == pcsCfgEn) /*1表示光口占用*/
    {
        BspSysMsDelay(150);
    }
    pcsCfgEn = BspGetOptPcsCfgEn();
    if(0 == pcsCfgEn)  /*0表示光口未占用*/
    {
        retVal = BspHalAdaptPcsInit(&pcsCfg,1);
    }

    return retVal;
}
UINT32 g_ulTestSerdesSta = BSP_OK;
VOID testSerdesStatus(UINT32 sta)
{
     g_ulTestSerdesSta = sta;
}

VOID testSerdesErr(VOID)
{
    UINT32 laneId = 0;
    UINT32 loop = 0;
    UINT32 flag = 0xff;
    UINT32 optProperty = 0;
    UINT32 optInterConn = 0;

    flag = BspHalAdaptGetLaneSavingFlag();    /*是否处于独立lane的状态*/
    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
         laneId      = s_pSerdesCfg[loop].laneId;
         if((BIT_SET(laneId) & s_innerSerdesLanMask) == 0)
         {
             continue;
         }
        (VOID)BspHalAdaptGetOptProperty(laneId, &optProperty, &optInterConn);
        dbgInfo("laneId %d ulOptProperty %d ulOptInterConn %d\n",laneId,optProperty,optInterConn);
        if(1 == optInterConn)   /*切换的时候会修改初始化变量 这里以速率来区分是可以的*/
        {
            if((1 == flag)&&(1 == optProperty))    /*独立lane模式下 只需要监控下联口的状态optProperty=1 表示下联*/
            {
                BspHalAdaptOptSdsSendPrbs(0,laneId,4,1);
                return ;
            }
        }
    }
}
/*高层读取片间serdes cprilane的状态*/
UINT32 BspCheckInnerSerdesStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 laneId = 0;
    UINT32 pcsSta = 0;
    UINT32 pcsStaOk = 0x3;
    UINT32 optProperty = 0;
    UINT32 optInterConn = 0;
    UINT32 serdesSpeed = 0;	
    UINT32 loop = 0;	
    UINT32 flag = 0xff;
    UINT32 serdesSta = 0;

    flag = BspHalAdaptGetLaneSavingFlag();    /*是否处于独立lane的状态*/

    for(loop = 0; loop < s_serdesLaneNum; loop++)
    {
         laneId      = s_pSerdesCfg[loop].laneId;
         serdesSpeed = s_pSerdesCfg[loop].rate;
         if((BIT_SET(laneId) & s_innerSerdesLanMask) == 0)
         {
             continue;
         }
        (VOID)BspHalAdaptPcsGetLinkPcsSta(laneId,&pcsSta);
        (VOID)BspHalAdaptGetOptProperty(laneId, &optProperty, &optInterConn);
        dbgInfoEx("laneId %d ulOptProperty %d ulOptInterConn %d pcsSta 0x%x\n",laneId,optProperty,optInterConn,pcsSta);
        if((1 == optInterConn)&&(SERDES_RATE_24G33 == serdesSpeed))
        {
            if((1 == flag)&&(1 != optProperty))    /*独立lane模式下 只需要监控下联口的状态optProperty=1 表示下联*/
            {
                  continue;
            }
            if(pcsSta != pcsStaOk)
            {
                serdesSta |= BIT_SET(laneId);
            }
        }
    }
    if(BSP_OK != g_ulTestSerdesSta)
    {
        serdesSta = g_ulTestSerdesSta;
    }
    if(BSP_OK == serdesSta)
    {
        retVal = INNER_SERDES_OK;
    }
    else
    {
        retVal = INNER_SERDES_ERR;
    }

    return retVal;
}


UINT32 BspSetCpriSwitchTypeFun(BspJudgeCpriSwitchType ucFunc)
{
    INPUT_POINTER_CHECK(ucFunc);
    cpriSwitchTypeFun = ucFunc;
    return BSP_OK;
}

void optpathsw(UINT32 laneRoutePath)
{
    T_CpriModeLaneRoutePara routePara = {0};
    BspGetOptCpriModePathLaneRoutePara(laneRoutePath, &routePara);
    BspSwitchCpriLaneRouteMode(&routePara);
}

#if BSP_MAKE_VER
VOID BspNtlInit25ByLane(VOID)
{
    UINT32 socId = BspGetRpuId();

    if(socId == 4)
    {
        BspNtlInitByLane(1);
        BspSysMsDelay(10000);
        BspSetMultSerdesRxInit(1);
    }
    else
    {
        BspNtlInitByLane(2);
        BspSysMsDelay(5000);
        BspNtlInitByLane(1);
        BspSysMsDelay(15000);
        BspSetMultSerdesRxInit(1);
        BspSysMsDelay(40000);
        BspSetMultSerdesRxInit(2);
    }
}
#endif /* BSP_MAKE_VER */

/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardsochwcfg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了例化单板的处理片间硬件差异的接口实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/
#include "bspcomm.h"
#include "funccommon.h"


#include "boardsochwdiffcfg.h"


/**************************************************************************
 *                                 宏
 **************************************************************************/
#define  BOARD_SOC_MAX (32)

/**************************************************************************
 *                               枚举定义
 **************************************************************************/
 
/**************************************************************************
 *                               数据类型
 **************************************************************************/
typedef struct T_SocBdCfgInfo
{
    UINT32 socHardVerCfgOff;
    UINT32 socDrvTblCfgMode;
}T_Soc_BdCfgInfo;

typedef struct T_SocBoardHwCfg
{
    UINT32 socNum;
    T_Soc_BdCfgInfo socBdHwCfgInfo[BOARD_SOC_MAX];
}T_Soc_BoardHwCfg;


/**************************************************************************
 *                                全局变量
 **************************************************************************/
/* 预置3种类型，后续根据需要增加 */
static T_Soc_BoardHwCfg s_Soc_BdHwCfg[E_SOC_HW_DIFF_TYPE_MAX] = 
{ 
    [E_SOC_HW_DIFF_NUM_3] = /* 3片IC机型 */
        {
            .socNum = 3,
            .socBdHwCfgInfo[0]= {0,0},/*HwVersion 数值偏移,DrvTbl Mode*/
            .socBdHwCfgInfo[1]= {SOC_HWVERSION_OFFSET,1},
            .socBdHwCfgInfo[2]= {SOC_HWVERSION_OFFSET*2,1}
        },
    
    [E_SOC_HW_DIFF_NUM_2] = /* 2片IC机型 */
        {
            .socNum = 2,
            .socBdHwCfgInfo[0]= {0,0},/*HwVersion 数值偏移,DrvTbl Mode*/
            .socBdHwCfgInfo[1]= {SOC_HWVERSION_OFFSET,1},
        },
        
    [E_SOC_HW_DIFF_NUM_1] = /* 1片IC机型 */
        {
            .socNum = 1,
            .socBdHwCfgInfo[0]={0, 0},
        },
    [E_SOC_HW_DIFF_NUM_4] = /* 4片IC机型 */
        {
            .socNum = 4,
            .socBdHwCfgInfo[0]= {0,0},/*HwVersion 数值偏移,DrvTbl Mode*/
            .socBdHwCfgInfo[1]= {SOC_HWVERSION_OFFSET,1},
            .socBdHwCfgInfo[2]= {SOC_HWVERSION_OFFSET*2,1},
            .socBdHwCfgInfo[3]= {SOC_HWVERSION_OFFSET*3,1}
        },
    [E_SOC_HW_DIFF_NUM_5] = /* 5片IC机型 */
        {
            .socNum = 5,
            .socBdHwCfgInfo[0]= {0,0},/*HwVersion 数值偏移,DrvTbl Mode*/
            .socBdHwCfgInfo[1]= {SOC_HWVERSION_OFFSET,1},
            .socBdHwCfgInfo[2]= {SOC_HWVERSION_OFFSET*2,1},
            .socBdHwCfgInfo[3]= {SOC_HWVERSION_OFFSET*3,1},
            .socBdHwCfgInfo[4]= {SOC_HWVERSION_OFFSET*4,1},
        },
    [E_SOC_HW_DIFF_NUM_6] =
        {
            .socNum = 6,
            .socBdHwCfgInfo[0]= {0,0},
            .socBdHwCfgInfo[1]= {SOC_HWVERSION_OFFSET,1},
            .socBdHwCfgInfo[2]= {SOC_HWVERSION_OFFSET*2,1},
            .socBdHwCfgInfo[3]= {SOC_HWVERSION_OFFSET*3,1},
            .socBdHwCfgInfo[4]= {SOC_HWVERSION_OFFSET*4,1},
            .socBdHwCfgInfo[5]= {SOC_HWVERSION_OFFSET*5,1},
        },
};


static UINT32 s_boardSocType = 0;
static UINT32 s_maxOffset = 0;

/**************************************************************************
*                                 接口实现
**************************************************************************/

UINT32 BspSetDiffSocCfg(UINT32 ulChipIdx,  UINT32 *pHwCfg)
{
    //UINT32 mGpId   = 0x0190;
    UINT32 aauType = s_boardSocType;
    /*UINT32 hwId    = 0;*/
    UINT32 socId = 0;
    UINT32 maxOffset = s_maxOffset;
    
    if(pHwCfg==NULL)
    {
        dbgErr("%s>>Chip %d,Input is Null !\n",__FUNCTION__,ulChipIdx);
        //boardInitLog(LOG_INFO, "%s>>Chip %d,Input is Null !\n",__FUNCTION__,ulChipIdx);
        return BSP_ERROR;
    }
    dbgInfo("%s>>Chip %d,HwCfg %d !\n",__FUNCTION__,ulChipIdx,*pHwCfg);
    //boardInitLog(LOG_INFO, "%s>>Chip %d,HwCfg %d !\n",__FUNCTION__,ulChipIdx,*pHwCfg);

    if(*pHwCfg>=maxOffset)
    {
         dbgErr("%s>>Chip %d,HwCfgId[%d] is out of range[rrutype %d,maxOffset %d] !\n",__FUNCTION__,ulChipIdx,*pHwCfg,aauType,maxOffset);
        //boardInitLog(LOG_INFO, "%s>>Chip %d,HwCfgId[%d] is out of range[rrutype %d,maxOffset %d] !\n",__FUNCTION__,ulChipIdx,*pHwCfg,aauType,maxOffset);
        return BSP_ERROR;
    }
    /*获取Soc编号*/
    socId = BspGetRpuId();

    if(socId>=s_Soc_BdHwCfg[aauType].socNum)
    {
        dbgErr("%s>>Chip %d,Soc Id[%d] is out of range[rrutype %d,max %d] !\n",__FUNCTION__,ulChipIdx,socId,aauType,\
            s_Soc_BdHwCfg[aauType].socNum);
        return BSP_ERROR;
    }

    /*计算Fix后的Hw Version 编号*/
    /*公式:  NewHwVersion = OldHwVersion + socX_BdHwCfgOff*/
    *pHwCfg += s_Soc_BdHwCfg[aauType].socBdHwCfgInfo[socId].socHardVerCfgOff;
#if 0  /* 暂时用不到，故屏蔽掉 */   
    /*Drv Tbl 变量值修正*/
    BspFixDiffSocDrvTbl(s_Soc_BdHwCfg[aauType].socBdHwCfgInfo[socId].socDrvTblCfgMode);
#endif
    dbgInfo("%s>>Chip %d,aautype %d,socid %d,newhwcfg %d,drvtblfix %d\n",__FUNCTION__,ulChipIdx,aauType,socId,*pHwCfg,\
        s_Soc_BdHwCfg[aauType].socBdHwCfgInfo[socId].socDrvTblCfgMode);
    //boardInitLog(LOG_INFO,"%s>>Chip %d,aautype %d,socid %d,newhwcfg %d\n",__FUNCTION__,ulChipIdx,aauType,socId,*pHwCfg);
    return BSP_OK;
}

UINT32 BspSetBoardSocHwDiffType(UINT32 boardSocType, UINT32 maxOffset)
{
    s_boardSocType = boardSocType;
    s_maxOffset = maxOffset;

    return BSP_OK;
}



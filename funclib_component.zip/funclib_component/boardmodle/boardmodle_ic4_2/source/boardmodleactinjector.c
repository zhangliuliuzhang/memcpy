/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardmodle_ic4_2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了IC4_2系列单板的例化框架实现
* 注意事项 : 无
* 作    者 :  赵玄10293411
* 创建日期 : 2022-03-23
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 赵玄10293411
* 修改日戳: 2022-11-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "boardmodleactinjector.h"
#include "boardmodle_ic4_2.h"
#include "zprintf.h"

#define BOARD_MODLE_TYPE_MAX_NUM (20)

/**************************************************************************
                               函数声明
**************************************************************************/
UINT32 BspBoardModleInitFlowCfg(UINT32 boardType);

/* --------------------------------------------------------------------- */
/* -------------------------- 例化单板接口信息  ------------------------ */
/* --------------------------------------------------------------------- */
static T_InstanceInterFace s_InstanceInterface =
{
    E_POWERON_PA_INIT+1,                      /* todo 可能需要例化多个单板，否则此处需要特殊处理 */
    E_HARD_FEATURE_GET_LGC_TYPE,
    BspBoardModleInitFlowCfg
};

static T_ModleInitItem modelInitItem[BOARD_MODLE_TYPE_MAX_NUM] = {};


/**************************************************************************
                               接口定义
**************************************************************************/
UINT32 BspSetModelItem(UINT32 boardType, T_ModleInitItem *pModelItem)
{
    if(boardType >= BOARD_MODLE_TYPE_MAX_NUM)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pModelItem);

    modelInitItem[boardType].actFuncTblBase = pModelItem->actFuncTblBase;
    modelInitItem[boardType].actFuncTblBaseLen = pModelItem->actFuncTblBaseLen;
    modelInitItem[boardType].actFuncTblDiff = pModelItem->actFuncTblDiff;
    modelInitItem[boardType].actFuncTblDiffLen = pModelItem->actFuncTblDiffLen;
    modelInitItem[boardType].preInitFlow = pModelItem->preInitFlow;
    modelInitItem[boardType].preInitFlowLen = pModelItem->preInitFlowLen;
    modelInitItem[boardType].initFlow = pModelItem->initFlow;
    modelInitItem[boardType].initFlowLen = pModelItem->initFlowLen;

    return BSP_OK;
}

static UINT32 AddActToPreInitFlowByTbl(T_BoardInitFlowTbl *pTbl, UINT32 num)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    for(loop=0; loop<num; loop++)
    {
        retVal |= BspBoardModleAddPreAction(pTbl->actType);
        pTbl++;
    }

    return BSP_OK;
}

static UINT32 AddActToInitFlowByTbl(T_BoardInitFlowTbl *pTbl, UINT32 num)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    for(loop=0; loop<num; loop++)
    {
        retVal |= BspBoardModleAddInitAction(pTbl->actType);
        pTbl++;
    }

    return BSP_OK;
}

UINT32 BspBoardModleInitFlowCfg(UINT32 boardType)
{
    UINT32 retVal = BSP_OK;
    if(boardType >= BOARD_MODLE_TYPE_MAX_NUM)
    {
        return BSP_ERROR;
    }

    retVal = BspBoardModleSetActByTbl(modelInitItem[boardType].actFuncTblBase, modelInitItem[boardType].actFuncTblBaseLen);
    retVal |= BspBoardModleSetActByTbl(modelInitItem[boardType].actFuncTblDiff, modelInitItem[boardType].actFuncTblDiffLen);
    retVal |= AddActToPreInitFlowByTbl(modelInitItem[boardType].preInitFlow, modelInitItem[boardType].preInitFlowLen);
    retVal |= AddActToInitFlowByTbl(modelInitItem[boardType].initFlow, modelInitItem[boardType].initFlowLen);

    return retVal;
}

/**************************************************************************
                            自举接口
**************************************************************************/
static __attribute((constructor)) void BoardModleActInjector()
{
    (VOID)BspBoardModleInstanceIfInit(&s_InstanceInterface);
}

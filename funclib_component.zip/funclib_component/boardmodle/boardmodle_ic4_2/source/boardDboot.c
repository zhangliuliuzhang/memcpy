/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardDboot.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了双boot初始化函数的实现
* 注意事项 : 无
* 作    者 : 
* 创建日期 : 2022-10-22 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 
* 修改日戳: 2022-10-22 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "funccommon.h"
#include "boardDboot.h"
#include "dualbootapi.h"
#include "regaccess.h"
#include "regtbl.h"

/**************************************************************************
*                            全局变量定义                                       *
**************************************************************************/


/**************************************************************************
*                                宏定义                                      *
**************************************************************************/



/**************************************************************************
*                                接口定义                                     *
**************************************************************************/
UINT32 BspGetMsBootSel(VOID)
{
    UINT32 kebootFlag = 0;

    (void)IcHalBitRdReg(0, CRM_M0_USR_RSV_RESET_REC, 4, &kebootFlag, 0, 7);

    if (kebootFlag == MASTER_KUBOOT_OK)
    {
        return LOW_ADDR_BOOT;
    }
    else if (kebootFlag == SLAVE_KUBOOT_OK)
    {
        return HIGH_ADDR_BOOT;
    }
    else
    {
        // 其他非法值返回低区boot
        return LOW_ADDR_BOOT;
    }
}

UINT32 BspSetMsBootSel(UINT32 ulFlag)
{
    if (0 == ulFlag)  //低区启动标志
    {
        (void)IcHalBitWrReg(0, CRM_M0_USR_RSV_RESET_REC, 4, MASTER_KUBOOT_OK, 0, 7);
    }
    else if (1 == ulFlag)  //高区启动标志
    {
        (void)IcHalBitWrReg(0, CRM_M0_USR_RSV_RESET_REC, 4, SLAVE_KUBOOT_OK, 0, 7);
    }
    else
    {
        ;
    }

    return BSP_OK;
}

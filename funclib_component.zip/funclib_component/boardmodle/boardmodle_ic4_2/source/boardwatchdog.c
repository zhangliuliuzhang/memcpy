#include "bsppub.h"
#include "regtbl.h"
#include "bspcomm.h"
#include "boardwatchdog.h"
#ifndef DYNAMIC_COMPILE
#include "ichaladapt_crm_ic4_2.h"
#include "regaccess.h"
#include "exprn.h"
#else
#include "boardwatchdoginfra.h"
#endif
#include "boardmodlecommon.h"
#include "pwr_a.h"
#include "funccommon.h"
#include "regdrv_accesstbl.h"
#include "regdrv_access.h"

#define EXTERNAL_WDT_ENABLE    0xface
#define EXTERNAL_WDT_DISABLE   0xdead

#define UNLOCK              (0x1ACCE551)
#define LOCK                (0x00000001)
#define INT_ENABLE          (1 << 0)
#define RESET_ENABLE        (1 << 1)
#define APP_FEEDDOG_TIME    21      /* 参考IC3.0,设置成21s */
#define KERNEL_FEEDDOG_TIME 240     /* 240s */
#define WDT_MAX_TIME        1374    /* 0xffffffff / 50000000 * 16 */

static UINT32 s_ossFeedDogTimes = 0;       /* OSS喂狗次数 */
static UINT32 s_pwrUpdateFlag = PWR_NO_UPDATE_FLAG;             /* 电源升级标志 */
static UINT32 s_pwrSelfRescueFlag = PWR_NO_SUPPORT_SELF_RESCUE; /* 电源自救标志 */
static BOOL s_isSupportFpgaWatchDog = FALSE;

void BspSetPowerUpdateFlag(UINT32 flag)
{
    s_pwrUpdateFlag = flag;
}

static UINT32 BspGetPowerUpdateFlag(void)
{
    return s_pwrUpdateFlag;
}

void BspSetPwrSelfRescueFlag(UINT32 flag)
{
    s_pwrSelfRescueFlag = flag;
}

UINT32 BspGetPwrSelfRescueFlag(void)
{
    return s_pwrSelfRescueFlag;
}

static UINT32 SetWtdLoad(UINT32 chip, UINT32 load)
{
    return IcHalWrReg(chip, WD_REG_LOAD, 0, load);
}

static UINT32 SetWtdLock(UINT32 chip,UINT32 lock)
{
    return IcHalWrReg(chip, WD_REG_LOCK, 0, lock);
}

static UINT32 SetWtdCtrl(UINT32 chip,UINT32 ctrl)
{
    return IcHalWrReg(chip, WD_REG_COUNTROL, 0, ctrl);
}

static UINT32 GetWtdCurrCounter(UINT32 chip)
{
    UINT32 regVal = 0;
    IcHalRdReg(chip, WD_REG_VALUE, 0, &regVal);
    return regVal;
}

/* ulTimerValue 单位s */
static UINT32 SetWatchDogTime(UINT32 ulTimerValue)
{
    UINT32      ulLoadVal = 0;

    if (ulTimerValue < 1)
    {
        dbgErr("%s: set wtd timeout error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    ulTimerValue = min(ulTimerValue, WDT_MAX_TIME);

    // 1: IC4.2 看门狗时钟是50MHZ.  2: 计数器位宽是 36bit,可配置的是高32bit,所以要除以16
    ulLoadVal = (UINT32)((ulTimerValue * (5 * pow(10, 7))) / 16);
    SetWtdLock(0, UNLOCK);
    SetWtdLoad(0, ulLoadVal);
    SetWtdLock(0, LOCK);

    return BSP_OK;
}

static UINT32 SetExterWtdCtrl(UINT32 ctrl)
{
    return BspHalAdaptCfgSetCrmFifteenthRecordReg(ctrl, 0, 15);  //操作0-15bit,使能和去使能外部看门狗
}

static UINT32 GetExterWtdCtrlStatus(UINT32 *status)
{
    UINT32 ret = BSP_OK;
    UINT32 sta = 0;

    if(NULL == status)
    {
        BspHalAdaptCfgGetCrmFifteenthRecordReg(0, 15, &sta);   //操作0-15bit,查看外部看门狗使能状态
        dbgInfoEx("[%s]Extern Watch dog status = 0x%x\n", __FUNCTION__, sta);

        return BSP_ERROR;
    }
    else
    {
        ret |= BspHalAdaptCfgGetCrmFifteenthRecordReg(0, 15, status);   //操作0-15bit,查看外部看门狗使能状态
    }

    return ret;
}

static UINT32 SetExterWtdHeartCounter(UINT32 num)
{
    return BspHalAdaptCfgSetCrmFifteenthRecordReg(num, 16, 31);  //操作16-31bit,喂外狗
}

static UINT32 GetExterWtdHeartCounter(UINT32 *num)
{
    UINT32 ret = BSP_OK;
    UINT32 value = 0;

    if(NULL == num)
    {
        BspHalAdaptCfgGetCrmFifteenthRecordReg(16, 31, &value);  //操作16-31bit,获取外狗的自增数
        dbgInfoEx("[%s]Extern Watch dog A53 AddNum = 0x%x\n", __FUNCTION__, value);

        return BSP_ERROR;
    }
    else
    {
        ret |= BspHalAdaptCfgGetCrmFifteenthRecordReg(16, 31, num);  //操作16-31bit,获取外狗的自增数
    }

    return ret;
}

static UINT32 WatchDogDisable(VOID)
{
    SetWtdLock(0, UNLOCK);
    SetWtdCtrl(0, 0);   /* IC看门狗复位去使能 ,关闭中断和计数*/
    SetExterWtdCtrl(EXTERNAL_WDT_DISABLE);
    SetWtdLock(0, LOCK);

    return BSP_OK;
}

static UINT32 WatchDogEnable(VOID)
{
    SetWtdLock(0, UNLOCK);
    SetWtdCtrl(0, INT_ENABLE | RESET_ENABLE);   // 使能计数和中断
    SetExterWtdCtrl(EXTERNAL_WDT_ENABLE);
    SetWtdLock(0, LOCK);

    return BSP_OK;
}

static UINT32 WtdSetCpuLaunchFlag(VOID)
{
    UINT32 ret = BSP_OK;

    ret |= BspHalAdaptCrmRecRegSet(0, 0, 31, 1);

    return ret;
}

UINT32 BspWatchDogInit(void)
{
#ifdef BSP_MAKE_VER
    WatchDogDisable();
#else
    SetWatchDogTime(KERNEL_FEEDDOG_TIME);
    WatchDogEnable();
#endif
    WtdSetCpuLaunchFlag();

    return BSP_OK;
}

UINT32 BspWatchDogEnable(VOID)
{
    return WatchDogEnable();
}

UINT32 BspSetWatchDogTime(UINT32 ulTimerValue)
{
    return SetWatchDogTime(ulTimerValue);
}

UINT32 BspWatchDogDisable(VOID)
{
    return WatchDogDisable();
}

/*OSS喂狗周期100ms,内核验证外狗心跳自增周期为60s(周期内自增数增加为600) */
static UINT32 SetExternWtdNumAdd(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 status = 0;
    UINT32 heartNum = 0;

    retVal = GetExterWtdHeartCounter(&heartNum);
    if(UINT16_MAX == heartNum)
    {
        heartNum = 0;
    }
    else
    {
        heartNum += 1;
    }

    retVal |= GetExterWtdCtrlStatus(&status);
    if(EXTERNAL_WDT_ENABLE == status)
    {
        retVal |= SetExterWtdHeartCounter(heartNum);
    }

    return retVal;
}

UINT32 BspMcuWatchDogFeed(void)
{
    UINT32 retVal = BSP_OK;

    if(PWR_SUPPORT_SELF_RESCUE == s_pwrSelfRescueFlag)
    {
        if(PWR_NO_UPDATE_FLAG == s_pwrUpdateFlag)
        {
            s_ossFeedDogTimes ++;
            if(600 == s_ossFeedDogTimes) /* 1分钟给电源MCU喂狗一次，电源升级阶段不进行喂狗 */
            {
                retVal = BspSetPwrMcuFeedDog();
                s_ossFeedDogTimes = 0;
                dbgInfoEx("Pwr Mcu Watch Dog Feed, retVal = %d\n", retVal);
            }
        }
        else
        {
            s_ossFeedDogTimes = 0;
        }
    }
    return retVal;
}

/* Started by AICoder, pid:28ca0f6331u3e95142720b84219bc15d01510dd1 */
// V5平台OSS测喂狗周期100ms,理论上此处看门狗超时时间大于100ms即可
UINT32 BspWatchDogFeed(VOID)
{
    UINT32 retVal = BSP_OK;
    static UINT32 fpgaWtdTimes = 100;

    retVal = SetWatchDogTime(APP_FEEDDOG_TIME);
    retVal |= SetExternWtdNumAdd();
    retVal |= BspMcuWatchDogFeed();

    if (BspIsSupportFpgaWatchDog())
    {
        if (0 == fpgaWtdTimes)
        {
            /*为降低cpu利用率,fpga看门狗每2秒喂一次*/
            retVal |= BspFpgaWatchDogFeed();
            fpgaWtdTimes = 101;/*CI环境偶现cpu利用率高/看门狗复位问题，讨论优化将逻辑喂狗周期由2s改为10s*/
        }
        fpgaWtdTimes--;
    }

    return retVal;
}

UINT32 BspFpgaWatchDogFeed(VOID)
{
    /*喂狗寄存器默认值为0, FPGA通过识别其他值变化到 0x5a 来触发一次喂狗*/
    BspRegWr(0, REG_FPGA_WD_FEED, 0, 0x5a);
    BspRegWr(0, REG_FPGA_WD_FEED, 0, 0);
    return BSP_OK;
}

UINT32 BspFpgaWatchDogEnable(VOID)
{
#if !defined(BSP_MAKE_VER) && !defined(_BSP_WITH_WFS)
    BspRegWr(0, REG_FPGA_WD_EN0, 0, 0);
#endif
    return BSP_OK;
}

UINT32 BspFpgaWatchDogDisable(VOID)
{
    BspRegWr(0, REG_FPGA_WD_EN0, 0, 1);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetFpgaWatchDogTime(*)
 * 功能描述: 设置看门狗喂狗时间
 * 输入参数: ulTimerValue - 写入喂狗的时间，单位s
 * 输出参数: 无
 * 返 回 值: BSP_OK表示成功; BSP_ERROR表示失败;
 * 其它说明: 看门狗超时配置寄存器0xb, bit[7:0]有效，单位5.369s, FPGA默认为10min
 *           FPGA使用固定默认值, 无需调用配置FPGA看门狗喂狗时间;
 *           BspSetFpgaWatchDogTime 600 -- 寄存器配置值(10*60)/5.369 = 111;
 *----------------------------------------------------------------------------
 */
UINT32 BspSetFpgaWatchDogTime(UINT32 ulTimerValue)
{
    UINT32 ulLoadTime = 0;

    ulLoadTime = (UINT32)((ulTimerValue * 1000) / FPGA_WDG_OUTTIME_UNIT_MS);
    BspRegWr(0, REG_FPGA_WD_TIMEOUT, 0, ulLoadTime);
    dbgInfoEx("[%s] FpgaWatchDog: Time= %ds, RegVal= %d\n",
                  __FUNCTION__, ulTimerValue, ulLoadTime);

    return BSP_OK;
}

UINT32 BspSetSupportFpgaWatchDogFlag(BOOL isSupportFlag)
{
    s_isSupportFpgaWatchDog = isSupportFlag;
    return BSP_OK;
}

BOOL BspIsSupportFpgaWatchDog(VOID)
{
    return s_isSupportFpgaWatchDog;
}

UINT32 prnfpgawatchdoginfo(VOID)
{
    UINT32 feedVal = 0;
    UINT32 enVal = 0;
    UINT32 timeOutVal = 0;

    BspRegRd(0, REG_FPGA_WD_FEED, 0, &feedVal);
    BspRegRd(0, REG_FPGA_WD_EN0, 0, &enVal);
    BspRegRd(0, REG_FPGA_WD_TIMEOUT, 0, &timeOutVal);

    dbgInfo("fpgaWatchDog feed reg val: 0x%x \n", feedVal);
    dbgInfo("fpgaWatchDog enable sta(0-on; 1-off): 0x%x \n", enVal);
    dbgInfo("fpgaWatchDog time reg val: %d, %ds \n", timeOutVal, timeOutVal*FPGA_WDG_OUTTIME_UNIT_MS/1000);

    return BSP_OK;
}
/* Ended by AICoder, pid:28ca0f6331u3e95142720b84219bc15d01510dd1 */

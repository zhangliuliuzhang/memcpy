#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <limits.h>
#include "cJSON.h"
#include "crc.h"
#include "zprintf.h"
#include "core_monitor_check.h"

#define A53_IRAM_BASEADDR   (0x84023000)
#define JSON_DEBUG_OFFSET   (0x400)
#define A53_DEBUG_FLAG      (0x5aa55aa5)
#define MAX_8               (8)
#define MAX_DEBUG_ENTRIES   (5)

typedef struct {
    UINT32 EnableReg;
    UINT32 EnableValue;
    UINT32 DisableValue;
    UINT32 Delay;
} DebugEnableDetail;

typedef struct {
    UINT32 DebugReg[MAX_8];
    UINT32 Value[MAX_8];
} DebugEntryDetail;

typedef struct {
    UINT32 EntryID;
    UINT32 DebugEnable;
    DebugEnableDetail DebugEnableDetail;
    UINT32 DebugEntryNum;
    DebugEntryDetail DebugEntryDetail;
} DebugEntry;

typedef struct {
    UINT32 RouteID;
    UINT32 StructVersion;
    UINT32 CRC;
    UINT32 TotalEntryNum;
    DebugEntry DebugEntry[MAX_DEBUG_ENTRIES];
} DebugMap;

static CHAR file[] = "/WDmonitor.json";

/* Started by AICoder, pid:e18d3r43e61f1fc14dba0ae1809502272083276a */
void PrintDebugMap(const DebugMap *debugMap) 
{
    if (debugMap == NULL) 
    {
        dbgInfo("DebugMap is NULL\n");
        return;
    }

    dbgInfo("RouteID: 0x%X\n", debugMap->RouteID);
    dbgInfo("StructVersion: %d\n", debugMap->StructVersion);
    dbgInfo("CRC: 0x%X\n", debugMap->CRC);
    dbgInfo("TotalEntryNum: %d\n", debugMap->TotalEntryNum);

    size_t totalEntries = (debugMap->TotalEntryNum < MAX_DEBUG_ENTRIES) ? debugMap->TotalEntryNum : MAX_DEBUG_ENTRIES;

    for (size_t i = 0; i < totalEntries; ++i) 
    {
        const DebugEntry *entry = &debugMap->DebugEntry[i];
        dbgInfo("DebugEntry[%lu]:\n", i);
        dbgInfo("  EntryID: %d\n", entry->EntryID);
        dbgInfo("  DebugEnable: %d\n", entry->DebugEnable);
        dbgInfo("  DebugEnableDetail:\n");
        dbgInfo("    EnableReg: 0x%X\n", entry->DebugEnableDetail.EnableReg);
        dbgInfo("    EnableValue: 0x%X\n", entry->DebugEnableDetail.EnableValue);
        dbgInfo("    DisableValue: 0x%X\n", entry->DebugEnableDetail.DisableValue);
        dbgInfo("    Delay: %d\n", entry->DebugEnableDetail.Delay);
        dbgInfo("  DebugEntryNum: %d\n", entry->DebugEntryNum);
        dbgInfo("  DebugEntryDetail:\n");
        
        size_t entryDetails = (entry->DebugEntryNum < MAX_8) ? entry->DebugEntryNum : MAX_8;
        for (size_t j = 0; j < entryDetails; ++j) 
        {
            dbgInfo("    DebugReg[%lu]: 0x%X, Value[%lu]: 0x%X\n", j, entry->DebugEntryDetail.DebugReg[j], j, entry->DebugEntryDetail.Value[j]);
        }
    }
}
/* Ended by AICoder, pid:e18d3r43e61f1fc14dba0ae1809502272083276a */

/**********************************************************************
* 函数名称: DpdIcDoMemUnmap
* 功能描述: 释放通过 mmap 映射的内存
* 输入参数: 
* 输出参数:
* 返 回 值: 
* 其它说明:
* 修改日期        版本号 修改人           修改内容
* -----------------------------------------------
* 20241122          v1.0    liusen            create
***********************************************************************/
static void DpdIcDoMemUnmap(DebugMap *pVirAddr)
{
    if (pVirAddr != NULL) 
    {
        // 使用 munmap 来释放映射的内存
        if (munmap(pVirAddr, 0x1000) == -1) 
        {
            // 打印错误信息
            dbgErr("munmap failed\n");
        }
    }
}

/**********************************************************************
* 函数名称: DpdIcDoMemMap
* 功能描述: mmap映射
* 输入参数: 
* 输出参数:
* 返 回 值: 成功映射后的虚拟地址
* 其它说明:
* 修改日期        版本号 修改人           修改内容
* -----------------------------------------------
* 20241122          v1.0    liusen            create
***********************************************************************/
static DebugMap * DpdIcDoMemMap(void)
{
    DebugMap *pVirAddr = NULL;
    void *vmAddr = NULL;
    int iFd = 0;
    int iSpaceProt = PROT_READ | PROT_WRITE;

    if((iFd = open("/dev/mem", O_RDWR | O_SYNC)) == -1)
    {
        dbgErr("mmap open failed\n");
        return NULL;
    }

    vmAddr = (DebugMap*)mmap(NULL, 0x1000, iSpaceProt, MAP_SHARED, iFd, (UINT32)A53_IRAM_BASEADDR);
    if (vmAddr == (DebugMap*)-1)
    {
        close(iFd);
        dbgErr("mmap viraddr failed\n");
        return NULL;
    }
    pVirAddr = (DebugMap *)vmAddr;
    close(iFd);

    return pVirAddr;
}

/**********************************************************************
* 函数名称: ParseConfigToDebugMap
* 功能描述: 解析json文件里的字段，放入结构体对应位置
* 输入参数: config：需要解析的json文件config字段里的内容
* 输出参数: 无
* 返 回 值: BSP_OK 成功
           其他   失败
* 其它说明:
* 修改日期        版本号 修改人           修改内容
* -----------------------------------------------
* 20241122          v1.0    liusen            create
***********************************************************************/
/* Started by AICoder, pid:14224rbbdc943df14298091031a6cc0389a0430b */
void ParseConfigToDebugMap(cJSON *config) 
{
    DebugMap *targetAddress = NULL;
    DebugMap *pAddr = NULL;
    DebugMap *DebugMapStruct = NULL;

    DebugMapStruct = (DebugMap *)malloc(sizeof(DebugMap));
    if (DebugMapStruct == NULL) 
    {
        dbgErr("Memory allocation failed\n");
        return;
    }
    memset_s(DebugMapStruct, sizeof(DebugMap), 0, sizeof(DebugMap));

    if (cJSON_IsArray(config)) 
    {
        UINT32 count = cJSON_GetArraySize(config);

        for (UINT32 i = 0; i < count && i < MAX_DEBUG_ENTRIES; ++i) 
        {
            cJSON *entry = cJSON_GetArrayItem(config, i);
            if (cJSON_IsObject(entry)) 
            {
                DebugEntry *DebugEntryStruct = &DebugMapStruct->DebugEntry[i];
                cJSON *entryIDItem = cJSON_GetObjectItem(entry, "EntryID");
                cJSON *debugEnableItem = cJSON_GetObjectItem(entry, "DebugEnable");
                cJSON *debugEntryNumItem = cJSON_GetObjectItem(entry, "DebugEntryNum");

                INPUT_POINTER_CHECK_JSON(entryIDItem, DebugMapStruct);
                INPUT_VALUE_CHECK_STRTOL(entryIDItem, EntryID, DebugEntryStruct->EntryID);
                INPUT_POINTER_CHECK_JSON(debugEnableItem, DebugMapStruct);
                INPUT_VALUE_CHECK_STRTOL(debugEnableItem, DebugEnable, DebugEntryStruct->DebugEnable);

                cJSON *enableDetail = cJSON_GetObjectItem(entry, "DebugEnableDetail");
                if (cJSON_IsObject(enableDetail)) 
                {
                    cJSON *enableRegItem = cJSON_GetObjectItem(enableDetail, "EnableReg");
                    cJSON *enableValueItem = cJSON_GetObjectItem(enableDetail, "EnableValue");
                    cJSON *disableValueItem = cJSON_GetObjectItem(enableDetail, "DisableValue");
                    cJSON *delayItem = cJSON_GetObjectItem(enableDetail, "Delay");

                    INPUT_POINTER_CHECK_JSON(enableRegItem, DebugMapStruct);
                    INPUT_POINTER_CHECK_JSON(enableValueItem, DebugMapStruct);
                    INPUT_POINTER_CHECK_JSON(disableValueItem, DebugMapStruct);
                    INPUT_POINTER_CHECK_JSON(delayItem, DebugMapStruct);
                    INPUT_VALUE_CHECK_STRTOL(enableRegItem, EnableReg, DebugEntryStruct->DebugEnableDetail.EnableReg);
                    INPUT_VALUE_CHECK_STRTOL(enableValueItem, EnableValue, DebugEntryStruct->DebugEnableDetail.EnableValue);
                    INPUT_VALUE_CHECK_STRTOL(disableValueItem, DisableValue, DebugEntryStruct->DebugEnableDetail.DisableValue);
                    INPUT_VALUE_CHECK_STRTOL(delayItem, Delay, DebugEntryStruct->DebugEnableDetail.Delay);
                }

                INPUT_POINTER_CHECK_JSON(debugEntryNumItem, DebugMapStruct);
                INPUT_VALUE_CHECK_STRTOL(debugEntryNumItem, DebugEntryNum, DebugEntryStruct->DebugEntryNum);

                cJSON *entryDetail = cJSON_GetObjectItem(entry, "DebugEntryDetail");
                if (cJSON_IsObject(entryDetail)) 
                {
                    cJSON *debugReg = cJSON_GetObjectItem(entryDetail, "DebugReg");
                    cJSON *value = cJSON_GetObjectItem(entryDetail, "Value");
                    if (cJSON_IsArray(debugReg) && cJSON_IsArray(value)) 
                    {
                        UINT32 regCount = cJSON_GetArraySize(debugReg);
                        UINT32 valCount = cJSON_GetArraySize(value);
                        for (UINT32 j = 0; j < MAX_8 && j < regCount; ++j) 
                        {
                            cJSON *regItem = cJSON_GetArrayItem(debugReg, j);
                            INPUT_POINTER_CHECK_JSON(regItem, DebugMapStruct);
                            INPUT_VALUE_CHECK_STRTOL(regItem, DebugReg, DebugEntryStruct->DebugEntryDetail.DebugReg[j]);
                        }
                        for (UINT32 j = 0; j < MAX_8 && j < valCount; ++j) 
                        {
                            cJSON *valItem = cJSON_GetArrayItem(value, j);
                            INPUT_POINTER_CHECK_JSON(valItem, DebugMapStruct);
                            INPUT_VALUE_CHECK_STRTOL(valItem, Value, DebugEntryStruct->DebugEntryDetail.Value[j]);
                        }
                    }
                }
            }
        }
        DebugMapStruct->TotalEntryNum = (UINT32)count;
    }
    else
    {
        dbgErr("Config is not an array\n");
        free(DebugMapStruct);
        return;
    }

    unsigned char *dataStart = (unsigned char *)&DebugMapStruct->DebugEntry[0];
    UINT32 dataSize = sizeof(DebugMap) - 16;
    DebugMapStruct->CRC = (UINT32)CalculateCRC16(0xffff, dataStart, dataSize);
    DebugMapStruct->StructVersion = (UINT32)0;
    DebugMapStruct->RouteID = (UINT32)A53_DEBUG_FLAG;

    pAddr = DpdIcDoMemMap();
    targetAddress = (DebugMap *)((char *)pAddr + JSON_DEBUG_OFFSET);
    memcpy_s(targetAddress, sizeof(DebugMap), DebugMapStruct, sizeof(DebugMap));
    DpdIcDoMemUnmap(pAddr);

    free(DebugMapStruct);
}
/* Ended by AICoder, pid:14224rbbdc943df14298091031a6cc0389a0430b */

static UINT32 ParseJsonString(const CHAR *json_text)
{
    cJSON *root = cJSON_Parse(json_text);

    if (root == NULL)
    {
        dbgErr("Error: Cannot parse json text.\n");
        return BSP_ERROR;
    }

    cJSON *config = cJSON_GetObjectItem(root, "config");
    if (config == NULL)
    {
        dbgErr("Error: Cannot find key 'config' in json text.\n");
        cJSON_Delete(root);
        return BSP_ERROR;
    }

    if(root == NULL)
    {
        dbgErr("error content:%s\n", cJSON_GetErrorPtr());
    }
    
    ParseConfigToDebugMap(config);
    cJSON_Delete(root);

    return BSP_OK;
}

/**********************************************************************
* 函数名称: GetFileLen
* 功能描述: 获取到文件长度
* 输入参数: 文件名
* 输出参数: 
* 返 回 值: BSP_OK 成功
           其他   失败
* 其它说明:
* 修改日期          版本号       修改人           修改内容
* -----------------------------------------------
* 20241123      v1.0    liusen            create
***********************************************************************/
static UINT32 GetFileLen(const CHAR *ucFileName, UINT32 *fileSize)
{
   struct stat tStatInfo = {0};

   if (-1 == stat(ucFileName, &tStatInfo))
   {
       return BSP_ERROR;
   }
   else
   {
       *fileSize = (UINT32)tStatInfo.st_size;
       return BSP_OK;
   }
}

/**********************************************************************
* 函数名称: read_json_file
* 功能描述: 读取对应路径下的json文件内容
* 输入参数: const CHAR *filename json文件名
* 输出参数: NULL
* 返 回 值: json 文件内容
           其他   失败
* 其它说明:
* 修改日期          版本号       修改人           修改内容
* -----------------------------------------------
* 20241123      v1.0    liusen            create
***********************************************************************/
static CHAR *read_json_file(const CHAR *filename)
{
    FILE *fp = NULL;
    UINT32 fileSize = 0;

    if ((fopen_s(&fp, filename, "r")) != 0 || NULL == fp)
    {
        dbgErr("Error: Cannot open file[ %s]! \n", filename);
        return NULL;
    }

    // 获取文件大小
    if (BSP_OK != GetFileLen(filename, &fileSize))
    {
        dbgErr("Error: fail to get file[%s] size! \n", filename);
        if (fclose(fp) != 0) 
        {
            dbgErr("Error: fclose failed for file[%s]! \n", filename);
        }
        return NULL;
    }

    // 分配内存空间
    CHAR *buffer = (CHAR *)malloc(fileSize + 1);
    if (buffer == NULL)
    {
        dbgErr("Error: Cannot allocate memory for reading file[%s]! \n", filename);
        if (fclose(fp) != 0) 
        {
            dbgErr("Error: fclose failed for file[%s]! \n", filename);
        }
        return NULL;
    }

    // 读取文件内容
    size_t bytesRead = fread(buffer, 1, fileSize, fp);
    if (bytesRead != fileSize)
    {
        dbgErr("Error: read file[%s] error! \n", filename);
        if (fclose(fp) != 0) 
        {
            dbgErr("Error: fclose failed for file[%s]! \n", filename);
        }
        free(buffer);
        return NULL;
    }
    buffer[fileSize] = '\0';

    if (fclose(fp) != 0) 
    {
        dbgErr("Error: fclose failed for file[%s]! \n", filename);
    }
    return buffer;
}

/**********************************************************************
* 函数名称: ParseJsonFile
* 功能描述: 处理json文件
* 输入参数: 
* 输出参数: 
* 返 回 值: 
           
* 其它说明:
* 修改日期          版本号       修改人           修改内容
* -----------------------------------------------
* 20241123      v1.0    liusen            create
***********************************************************************/
static UINT32 ParseJsonFile(const CHAR *fileName)
{
    UINT32 ret = BSP_OK;
    char *json_text = NULL;

    if (NULL == fileName)
    {
        return BSP_OK;
    }

    json_text = read_json_file(fileName);
    if (json_text == NULL)
    {
        return BSP_ERROR;
    }

    ret = ParseJsonString(json_text);
    if (BSP_OK != ret)
    {
        dbgErr("Error: Failed to parse %s.\n", fileName);
        free(json_text);
        return BSP_ERROR;
    }
    free(json_text);
    return BSP_OK;
}

/**********************************************************************
* 函数名称: BspShowM0DebugMap
* 功能描述: 对外接口，提供给BSP在a53复位后，读取a53 iram空间的内容到串口日志里
* 输入参数: 
* 输出参数: 
* 返 回 值: 
           
* 其它说明:
* 修改日期          版本号       修改人           修改内容
* -----------------------------------------------
* 20241123      v1.0    liusen            create
***********************************************************************/
void BspShowM0DebugMap(void) 
{
    DebugMap *pAddr = NULL;
    DebugMap *targetAddress = NULL;

    pAddr = DpdIcDoMemMap();
    if (pAddr == NULL) 
    {
        // 处理错误情况
        dbgInfo("Memory mapping failed\n");
        return;
    }

    targetAddress = (DebugMap *)((char *)pAddr + JSON_DEBUG_OFFSET);
    PrintDebugMap(targetAddress);
    memset_s(targetAddress, sizeof(DebugMap), 0, sizeof(DebugMap));
    DpdIcDoMemUnmap(pAddr);
}

/**********************************************************************
* 函数名称: BspSetM0DebugMap
* 功能描述: 对外接口，解析根目录下的json文件，实现a53核挂死维测功能
* 输入参数: 
* 输出参数: 
* 返 回 值: 
           
* 其它说明:
* 修改日期          版本号       修改人           修改内容
* -----------------------------------------------
* 20241123      v1.0    liusen            create
***********************************************************************/
void BspSetM0DebugMap(void)
{
    ParseJsonFile(file);
}


/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardpwrsave.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了board层用于节能相关功能的接口
* 注意事项 : 无
* 作    者 : 陈希多10300629
* 创建日期 : 2022-10-31
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 陈希多10300629
* 修改日戳: 2022-10-31
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "ichaladaptbspapi.h"
#include "bspcomm.h"
#include "chnmapcommon.h"
#include "ru_univdef.h"
#include "funccommon_carrmap.h"
#include "freqcfgcommon.h"
//#include "ichaladapt_ic4_2.h"
#include "ichaladapt_dtx_ic4_2.h"
#include "functionwrapper.h"
#include "boarddtxpwrsave.h"
#include "dtx.h"
#include "funccommon_a.h"
#include "pwrsave_common.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "pa_ic4_2_ctrl.h"
#include "freqcfg_ic4_2_analyse.h"
#include "chnmap_a.h"
#include "rruinfo.h"
#include "regdrv_access.h"

#define DTX_INVALID_CHN (0xFF)

static T_RruDtxAbilitySupport *DtxAbilitySupportInfo = NULL;
static UINT32 AbilitySupportNum = 0;

static UINT32 s_dtxEnStauts[BSP_MAX_CHAN_NUM] = {0};
static UINT32 s_DtxSymbCntChnSel = DTX_INVALID_CHN;
static UINT32 s_DtxSymbSubcarClk = 0;
static UINT32 s_tmpDtxCloseMode = 0;

/* DTX节能相关参数，所有规格共用以下参数 */
T_BspHalAdaptDifDtxCheckPara s_DifDtxTxCheckPara =
{
    0,      /** 符号头来源选择 0：定时模块产生 1：FFTA 2：光口3bit信息符号头  3:定时产生模块 */
    100,    /** 符号头到开始检测的等待时间，以样点为单位 */
    1,      /** 符号功率检测门限，I^2 + Q^2，峰值模式和均值模式共用 */
    0,      /** 符号功率检测方式 0：平均功率 1：峰值功率 */
    3,      /** dtx来源选择，0：定时产生 1：FFTA 2：光口3bit 3：内部自检 4：光口16bit */
    0,      /** 峰值模式下超过门限的次数阈值 */
    0       /** 自检测gp长度配置，tdd下降沿开始计数 */
};

static void opendtx(void)
{
    s_tmpDtxCloseMode = 0;
}

static void closedtx(void)
{
    s_tmpDtxCloseMode = 1;
}

static VOID SetDtxSymbCntChnSel(UINT32 chn)
{
    s_DtxSymbCntChnSel = chn;
}

static UINT32 GetDtxSymbCntChnSel(VOID)
{
    return s_DtxSymbCntChnSel;
}

UINT32 BspSetDtxEnStatus(UINT32 bspChan, UINT32 on)
{
    s_dtxEnStauts[bspChan] = on;

    return BSP_OK;
}

UINT32 BspGetDtxSwitch(UINT32 bspChan, UINT32 *sw)
{
    INPUT_POINTER_CHECK(sw);

    if(bspChan >= BspGetTxBspChanNum())
    {
        dbgErr("%s>>bspChan is Error! bspChan=%d \n", __FUNCTION__,bspChan);
        return BSP_ERROR;
    }

    *sw = s_dtxEnStauts[bspChan];
    dbgInfoEx("[%s]: DtxEnStatus = %d\n", __FUNCTION__, s_dtxEnStauts[bspChan]);

    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspResetAllDtxRoute
* 功能描述: 清除全部DTX载波路由信息
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
**************************************************************************/
VOID BspResetAllDtxRoute(VOID)
{
    UINT32 retVal = BSP_OK;

    /* DTX是否处于关闭模式，维测用 */
    if(s_tmpDtxCloseMode)
    {
        return;
    }

    BspDlyDlDtxOutSelDataSaveAndOff();

    BspLog(LOG_LEVEL_0,"%s, enter \n",__FUNCTION__);

    DbgClrDtxRouteStatus();
    retVal = BspHalAdaptDtxClrAllRoute();

    BspLog(LOG_LEVEL_0,"%s, exit ret=%d\n",__FUNCTION__, retVal);

    dbgInfoEx("%s finished!\n", __FUNCTION__);

    return ;
}

/**************************************************************************
* 函数名称: BspSetDtxRoute
* 功能描述: 配置DTX载波路由信息
*           因为小区闭塞/小区删除等场景，底层不知道载波是否真实存在，
*           所以由高层控制，对存在的载波配置DTX路由
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
**************************************************************************/
UINT32 BspSetDtxRoute(UINT32 bspChan,UINT32 radioMod,UINT32 carrNo,UINT32 on)
{
    UINT32 difChan = 0;
    UINT32 chipId = 0;
    UINT32 retVal = BSP_OK;

    /* DTX是否处于关闭模式，维测用 */
    if(s_tmpDtxCloseMode)
    {
        return BSP_ERROR;
    }
    BspLog(LOG_LEVEL_0,"%s: bspChan[%d] radioMod[%#x] carrNo[%d] on[%d] enter. \n",
        __FUNCTION__, bspChan, radioMod, carrNo, on);

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s TX bspChan[%d] Get DifChan err\n", __func__, bspChan);
        return retVal;
    }

    DbgSaveDtxRouteStatus(bspChan,carrNo,on);
    retVal = BspHalAdaptSetDtxRoute(difChan, carrNo, radioMod, on);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspHalAdaptSetDtxRoute err. difChan[%d] radioMod[%#x] carrNo[%d] on[%d]\n",
            __FUNCTION__, difChan, radioMod, carrNo, on);
        return retVal;
    }

    BspLog(LOG_LEVEL_0,"%s: bspChan[%d] radioMod[%#x] carrNo[%d] on[%d] exit. \n",
        __FUNCTION__, bspChan, radioMod, carrNo, on);

    return retVal;
}

UINT32 BspSetDtxSwitchEN(UINT32 bspChan, UINT32 difCarrNo, UINT32 radio, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s bspChn=%d BspGetDifInfoByBspChn fail! \n", __FUNCTION__, bspChan);
        return retVal;
    }

    retVal = BspHalAdaptSetDtxCheckEn(difChan,difCarrNo,radio,sw);
    if(BSP_OK != retVal)
    {
        dbgErr("%s difChn=%d radio=%d carrNo=%d BspHalAdaptSetDtxCheckEn fail! \n", __func__, difChan, radio, difCarrNo);
        return retVal;
    }

    retVal = BspHalAdaptSetDtxEnToIo(difChan,difCarrNo,radio,sw);
    if(BSP_OK != retVal)
    {
        dbgErr("%s difChn=%d radio=%d carrNo=%d BspHalAdaptSetDtxEnToIo fail! \n", __func__, difChan, radio, difCarrNo);
        return retVal;
    }

    if(IS_NCR == BspIsNcr())
    {
        retVal = BspHalAdaptSetDtxEnToDlbank(difChan,difCarrNo,radio,SWITCH_OFF);  //NCR机型上行静默不使能
    }
    else
    {
        retVal = BspHalAdaptSetDtxEnToDlbank(difChan,difCarrNo,radio,sw);
    }
    if(BSP_OK != retVal)
    {
        dbgErr("%s difChn=%d radio=%d carrNo=%d BspHalAdaptSetDtxEnToDlbank fail! \n", __func__, difChan, radio, difCarrNo);
        return retVal;
    }

    return retVal;
}

/*逻辑侧打开DTX*/
/* Started by AICoder, pid:876ba19559g07bc145360aca00c9f33477c2b63a */
UINT32 BspSetFpgaDtxSwitch(UINT32 bspChan, UINT32 on)
{
    UINT32 ret    = BSP_OK;
    UINT32 rfChan = 0;
    UINT32 fpgaId   = 0;
    UINT32 difChan   = 0;

    ret = BspGetRfChnByBspChn(bspChan, TX, &rfChan);
    if (BSP_OK != ret)
    {
        rfChan = bspChan;
        dbgErr("%s: rfChan get error!\n", __FUNCTION__);

    }

    ret = BspGetDifInfoByRfChn(rfChan, TX, &fpgaId, &difChan);
    if (BSP_OK != ret)
    {
        dbgErr("%s: fpgaIdx get error!\n", __FUNCTION__);
        fpgaId = 0;
    }


    dbgInfo("[%s]:fpgaIdx is %d,rfChan is %d \n",__FUNCTION__,fpgaId,rfChan);

    //打开射频节能开关
    BspRegBitValWr(fpgaId,     REG_DTX_PA_EN, 0, on, difChan, difChan);
    BspRegBitValWr(fpgaId,  REG_DTX_RF_TX_EN, 0, on, difChan, difChan);
    BspRegBitValWr(fpgaId, REG_DTX_TRX_TX_EN, 0, on, difChan, difChan);

    return ret;
}
/* Ended by AICoder, pid:876ba19559g07bc145360aca00c9f33477c2b63a */

/**************************************************************************
* 函数名称: BspSetDtxEnFlag
* 功能描述: 对通道使能DTX功能
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
**************************************************************************/
UINT32 BspSetDtxEnFlag(UINT32 bspChan, UINT32 on)
{
    UINT32 retVal  = BSP_OK;
    UINT32 carrIdx = 0;
    UINT32 radio   = 0;
    UINT32 loop    = 0;
    T_RfCfgPara *pRfCfg = NULL;

    BspLog(LOG_LEVEL_0,"%s, enter bspChan=%d on=%d\n",__FUNCTION__, bspChan, on);
    if(bspChan >= BspGetTxBspChanNum())
    {
        dbgErr("%s>>bspChan is Error! bspChan=%d \n", __FUNCTION__,bspChan);
        return BSP_ERROR;
    }

    pRfCfg = BspGetRfCfgPara(bspChan, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("%s bspChan=%d GetRfCfgPara fail! \n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    if(LINK_REMOTE == BspIsRemoteSlaveChan(bspChan, 0))   /*子端建链才配置*/
    {
        on = SWITCH_OFF;   /*一拖三机型 子端通道固定不使能dtx*/
        BspLog(LOG_LEVEL_0,"%s, slave change bspChan=%d on=%d\n",__FUNCTION__, bspChan, on);
    }
    DbgSaveDtxEnableStatus(bspChan, on);
    for(loop = 0; loop < pRfCfg->carrNum; loop++)
    {
        carrIdx = pRfCfg->carrInfo[loop].carrNo;
        radio = pRfCfg->carrInfo[loop].radioMode;

        if(SWITCH_ON == on)
        {
            retVal = BspSetDtxSwitchEN(bspChan, carrIdx, radio, SWITCH_ON);
            retVal |= BspSetTddIoDtxEn(bspChan, SWITCH_ON);
        }
        else
        {
            retVal = BspSetTddIoDtxEn(bspChan, SWITCH_OFF);
            retVal |= BspSetDtxSwitchEN(bspChan, carrIdx, radio, SWITCH_OFF);
        }
    }

    if(SWITCH_OFF != on)
    {
        BspDlyDlDtxOutSelRecover();
        BspLog(LOG_LEVEL_0,"%s, exit bspChan=%d on=%d (Recover)\n",__FUNCTION__, bspChan, on);
    }
    else
    {
        BspLog(LOG_LEVEL_0,"%s, exit bspChan=%d on=%d\n",__FUNCTION__, bspChan, on);
    }
    retVal |= BspSetDtxEnStatus(bspChan, on);

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        BspSetFpgaDtxSwitch(bspChan, on);
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspSetDtxSymbCntCh(UINT32 chan)
 * 功能描述: 设置DTX符号关闭统计通道
 * 输入参数: chan  要统计的通道
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:  区分上下行
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------

 **************************************************************************/
UINT32 BspSetDtxSymbCntCh(UINT32 chan)
{
    UINT32 retVal = BSP_OK;
    /*UINT32 difChn = 0;
    UINT32 chipidx  = 0;*/

    if(chan >= BspGetTxBspChanNum())
    {
        dbgErr("%s>>bspChan is Error! bspChan=%d \n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    SetDtxSymbCntChnSel(chan);

    dbgInfoEx("%s chansel: %d \n",__FUNCTION__, GetDtxSymbCntChnSel());

    return retVal;
}

/**************************************************************************
 * 函数名称: BspSetDtxSymbSubcarClk(UINT32 count)
 * 功能描述: 设置DTX符号关闭统计不同子载波clk数
 * 输入参数: pCnt  clk数
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:  区分上下行
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------

 **************************************************************************/
UINT32 BspSetDtxSymbSubcarClk(UINT32 clkCount)
{
    UINT32 ret = BSP_OK;

    s_DtxSymbSubcarClk = clkCount;
    dbgInfoEx("%s clkCount: %d \n",__FUNCTION__, clkCount);

    return ret;
}

/**************************************************************************
 * 函数名称: BspGetDtxSymbSubcarClk(UINT32 count)
 * 功能描述: 获取DTX符号关闭统计不同子载波clk数
 * 输入参数: pCnt  clk数
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:  区分上下行
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------

 **************************************************************************/
UINT32 BspGetDtxSymbSubcarClk(UINT32 *pClkCount)
{
    UINT32 ret = BSP_OK;
    UINT32 clkCount = s_DtxSymbSubcarClk;

    if(0 != clkCount)
    {
        *pClkCount = clkCount;
    }
    else
    {
        ret = BSP_ERROR;
        dbgErr("%s Error!!!\n",__FUNCTION__);
    }
    dbgInfoEx("%s clkCount: %d \n",__FUNCTION__,clkCount);

    return ret;
}

/**************************************************************************
 * 函数名称: GetDtxSymbCnt(UINT32 *pSymCnt)
 * 功能描述: get DTX符号关闭统计
 * 输入参数: 无
 * 输出参数: 符号数
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:  区分上下行
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------

 **************************************************************************/
static UINT32 GetDtxSymbCnt(UINT32 *pSymCnt)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipidx  = 0;
    UINT32 symCnt = 0;

    UINT32 dtxSymbCntChnSel = GetDtxSymbCntChnSel();

    if(DTX_INVALID_CHN == dtxSymbCntChnSel)
    {
        dbgErr("%s dtx chan sel err! chnsel=%d\n", __FUNCTION__, dtxSymbCntChnSel);
        return BSP_ERROR;
    }

    retVal = BspGetDifInfoByBspChn(dtxSymbCntChnSel, TX, &chipidx, &difChn);
    if(BSP_OK != retVal)
    {
        dbgErr("%s bspChn=%d BspGetDifInfoByBspChn fail! \n", __FUNCTION__, dtxSymbCntChnSel);
        return retVal;
    }

    retVal = BspHalAdaptGetDtxChSymCnt(difChn, &symCnt);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspHalAdaptSetDtxChSymCntClr fail! diChn[%d] \n", __FUNCTION__, difChn);
        return retVal;
    }
    *pSymCnt = symCnt;
    dbgInfoEx("%s symcnt: %d chansel: %d \n",__FUNCTION__, symCnt, dtxSymbCntChnSel);

    return retVal;
}

/**************************************************************************
 * 函数名称: BspGetDtxSymbCnt(UINT32 *pCnt)
 * 功能描述: get DTX符号关闭统计
 * 输入参数: 无
 * 输出参数: pCnt 计数值(100us为单位)
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:  区分上下行
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------

 **************************************************************************/
UINT32 BspGetDtxSymbCnt(UINT32 *pCnt)
{
    UINT32 ret = BSP_OK;
    UINT32 count = 0;
    UINT32 clkCnt = 0;
    UINT32 cntTime = 0;
    UINT32 unit = 0;   //0.0001ms/0.1us/100ns
    UINT32 retTotal = BSP_OK;

    ret = BspGetDtxSymbSubcarClk(&clkCnt);
    retTotal |= ret;
    ret = GetDtxSymbCnt(&count);
    retTotal |= ret;
    if(retTotal == BSP_OK)
    {
        unit = (clkCnt * (UINT32)1000) / (UINT32)6144;   //以30K子载波间隔为例 unit = (2194/61.44)(us)*10,0.0001ms的整数倍
        cntTime = (UINT32)(count * unit);
        dbgInfoEx("%s cntTime: 0x%x, cntTime: %d\n",__FUNCTION__,cntTime,cntTime);
        *pCnt = cntTime;
    }
    else
    {
        dbgErr("%s Error!!!\n",__FUNCTION__);
    }
    dbgInfoEx("%s pCnt: %u, cntTime: %u, clkCnt: %d, count: %u, count: 0x%x ,unit: %d\n",__FUNCTION__,*pCnt,cntTime,clkCnt,count,count,unit);

    return retTotal;
}

/**************************************************************************
 * 函数名称: BspSetDtxSymbCntClr(UINT32 clearFlag)
 * 功能描述: DTX符号关闭统计清零
 * 输入参数: clearFlag     0:正常计数   1：清零
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:  区分上下行
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------

 **************************************************************************/
UINT32 BspSetDtxSymbCntClr(UINT32 clearFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipidx  = 0;

    UINT32 dtxSymbCntChnSel = GetDtxSymbCntChnSel();
    if(DTX_INVALID_CHN == dtxSymbCntChnSel)
    {
        dbgErr("%s dtx chan sel err! chnsel=%d\n", __FUNCTION__, dtxSymbCntChnSel);
        return BSP_ERROR;
    }

    retVal = BspGetDifInfoByBspChn(dtxSymbCntChnSel, TX, &chipidx, &difChn);
    if(BSP_OK != retVal)
    {
        dbgErr("%s bspChn=%d BspGetDifInfoByBspChn fail! \n", __FUNCTION__, dtxSymbCntChnSel);
        return retVal;
    }

    retVal = BspHalAdaptSetDtxChSymCntClr(difChn, clearFlag);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspHalAdaptSetDtxChSymCntClr fail! difChn[%d] clearFlag[%d] \n", __FUNCTION__, difChn, clearFlag);
        return retVal;
    }
    dbgInfoEx("%s clearFlag: %d chansel: %d \n",__FUNCTION__,clearFlag, dtxSymbCntChnSel);

    return retVal;
}

UINT32 BspSetDtxChkAbility(T_RruDtxAbilitySupport *DtxAblitySuppor, UINT32 num)
{
	DtxAbilitySupportInfo = DtxAblitySuppor;
	AbilitySupportNum = num;
	return BSP_OK;
}

UINT32 BspGetDtxChkAbility(UINT32 radioMode)
{
   UINT32 ulDtxAbility = 0;
    UINT32 num = 0;

    for(num = 0; num < AbilitySupportNum; num++)
    {
        if(DtxAbilitySupportInfo[num].radioMode == radioMode)
        {
            ulDtxAbility = DtxAbilitySupportInfo[num].dtxAbility;
        }
    }

    return ulDtxAbility;
}

/*******************************************************************************
 * 函数名称: BspSetDtxSwitch(*)
 * 功能描述: DTX使能控制
 * 输入参数: bspChan    - BSP通道号
 *           on - 使能标志, 0:去使能, 1:使能
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 其它- 失败
 * 其它说明: 无
 *------------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), wangfangli @2019-07-29 19:21:00 创建
 *------------------------------------------------------------------------------
 */
UINT32 BspSetDtxSwitch(UINT32 bspChan, UINT32 on)
{
    UINT32 retVal = 0;
    UINT32 radio  = 0;
    UINT32 carrIdx = 0;
    UINT32 loop   = 0;
    UINT32 maxCarrNum = 0;
    T_RfCfgPara *pRfCfg = NULL;

    BspLog(LOG_LEVEL_0,"%s, enter bspChan=%d on=%d\n",__FUNCTION__, bspChan, on);
    if(bspChan >= BspGetTxBspChanNum())
    {
        dbgErr("%s>>bspChan is Error! bspChan=%d \n", __FUNCTION__,bspChan);
        return BSP_ERROR;
    }

    pRfCfg = BspGetRfCfgPara(bspChan, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("%s bspChan=%d GetRfCfgPara fail! \n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    maxCarrNum = pRfCfg->carrNum;
    if ((UINT32)0 == maxCarrNum)
    {
        dbgErr("[%s] error maxCarrNum = %d \n" ,__FUNCTION__,maxCarrNum);
        return BSP_ERROR;
    }

    DbgSaveDtxEnableStatus(bspChan, on);
    for(loop = 0; loop < maxCarrNum; loop++)
    {
        carrIdx = pRfCfg->carrInfo[loop].carrNo;
        radio = pRfCfg->carrInfo[loop].radioMode;

        if((BSP_RADIO_STANDARD_GSM == radio) || (BSP_RADIO_STANDARD_UMTS == radio))
        {
            retVal = BspSetTddIoDtxEn(bspChan, SWITCH_OFF);
            dbgInfoEx("[%s]bspChan = %d is not support DTX_GU, radioMod is %d, carrNo is %d\n",__FUNCTION__, bspChan, radio, carrIdx);
            continue;
        }

        if(SWITCH_ON == on)
        {
            retVal = BspSetDtxSwitchEN(bspChan, carrIdx, radio, SWITCH_ON);
            retVal |= BspSetTddIoDtxEn(bspChan, SWITCH_ON);
        }
        else
        {
            retVal = BspSetTddIoDtxEn(bspChan, SWITCH_OFF);
            retVal |= BspSetDtxSwitchEN(bspChan, carrIdx, radio, SWITCH_OFF);
        }
    }

    retVal |= BspSetDtxEnStatus(bspChan, on);

    if(SWITCH_OFF != on)
    {
        BspDlyDlDtxOutSelRecover();
        BspLog(LOG_LEVEL_0,"%s, exit bspChan=%d on=%d (Recover)\n",__FUNCTION__, bspChan, on);
    }
    BspLog(LOG_LEVEL_0,"%s, exit bspChan=%d on=%d\n",__FUNCTION__, bspChan, on);

    return retVal;
}

/* DVGA异常规避，关闭下行DTX开关接口，FDD机型对外接口，名称有异议，重新封装 */
UINT32 BspSetTxDtxEn(UINT32 bspChan, UINT32 isEn)
{
    BspLog(LOG_LEVEL_0, "[%s]bspChan = %d, isEnable = %d\n", __FUNCTION__, bspChan, isEn);
    return BspSetTddIoDtxEn(bspChan, isEn);
}

UINT32 BspClrDtxCounter(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    retVal = BspHalAdaptSetDtxChSymCntClr(difChan, 1);
    retVal |= BspHalAdaptSetDtxChSymCntClr(difChan, 0);
    BspLog(LOG_LEVEL_1, "[%s]bspChan = %d\n", __FUNCTION__, bspChan);

    return retVal;
}

UINT32 BspGetDtxCounter(UINT32 bspChan, UINT32 *pDtxCounter)
{
    UINT32 retVal = BSP_OK;
    UINT32 symCnt = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(pDtxCounter);

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetDtxChSymCnt(difChan, &symCnt);
    *pDtxCounter = symCnt;

    dbgInfoEx("[%s] bspChan = %d, difChan = %d, pDtxCounter = %d\n",__FUNCTION__, bspChan, difChan, *pDtxCounter);

    return retVal;
}

/* 获取通道级符号节电时长接口   pSymOffTime 出参单位：0.1us*/
UINT32 BspGetDtxChSymOffTime(UINT32 bspChan, UINT32 *pSymOffTime)
{
    UINT32 retVal = BSP_OK;
    UINT32 puiSymCntUs = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(pSymOffTime);

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetDtxChSymOffTime(difChan, &puiSymCntUs);
    *pSymOffTime = puiSymCntUs * 10;

    dbgInfoEx("[%s] bspChan = %d, difChan = %d, pDtxCounter = %d\n",__FUNCTION__, bspChan, difChan, *pSymOffTime);

    return retVal;
}

/* TDD节电门控开关控制接口 */
UINT32 BspSetPwrsaveTddEn(UINT32 rxsw, UINT32 txsw)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 rxChnNum = BspGetRxChannel();
    UINT32 loop = 0;

    /* 目前的机型，各通道均采用相同的配置 */
    for(loop = 0; loop < txChnNum; loop++)
    {
        /* 下行tdd动态节电使能 */
        retVal = BspHalAdaptSetTxTddEn(loop, txsw);
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BspHalAdaptSetTxTddEn, retVal);
    }

    for(loop = 0; loop < rxChnNum; loop++)
    {
        /* 上行行tdd动态节电使能 */
        retVal = BspHalAdaptSetRxTddEn(loop, rxsw);
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BspHalAdaptSetRxTddEn, retVal);
    }

    return retTotal;
}

/*****************************************************************************
 *  函数名称   : BspDpdicDifDtxParaInit(*)
 *  功能描述   : DTX参数初始化
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK-成功，其他失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdicDifDtxParaInit(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK;

    /* DTX参数初始化 */
    retVal = BspHalAdaptDtxCheckParaInit(difChan, &s_DifDtxTxCheckPara);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptDtxCheckParaInit, retVal);

    /* TDD节点门控使能配置 */
    retVal = BspSetPwrsaveTddEn(1, 1);
    CHECK_RETVAL_PRN(BspSetPwrsaveTddEn, retVal);

    return retTotal;
}

UINT32 BspDtxParaInit(VOID)
{
    UINT32 ret = 0;
    UINT32 chan = 0;
    UINT32 txChanNum = BspGetTxChanNum();
    UINT32 flagVal = 0;

    BspSetDtxRouteCallBack(BspSetDtxRoute);

    flagVal = BspGetFddTddCoExistSta();
    BspHalAdaptSetFddAntFrCompFlag(flagVal);  //dtx节能标志下发，FDD/TDD/t+f等机型HAL层区分判别

    for(chan = 0; chan<txChanNum; chan++)
    {
        ret |= BspDpdicDifDtxParaInit(chan);
    }

    return ret;
}


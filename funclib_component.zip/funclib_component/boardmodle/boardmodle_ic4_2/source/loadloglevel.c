#include "bsppub.h"
#include "dif_hal_log.h"
#include "ichal_opt_logrecord.h"
#include "loadloglevel.h"
#include "funccommon_log.h"
#include "funccommon.h"
#include "bspcommon.h"

#define AREA_NUM (6)
static UINT32 s_logLevel[AREA_NUM] = {0};
static UINT32 s_logPrintDirFlag[AREA_NUM] = {0};
static CHAR areaLogLevelConfFile[] = "/ata/loglevel.conf";

UINT32 readAreaLogLevel(CHAR *area, UINT32 *pulAreaLogLevel, UINT32 type)
{
    CHAR  cOptKey[32]="";
    UINT32 ulRet = BSP_ERROR;
    T_Bsp_RruIniCfgItem tLoadCfgPara = {0};
    INT32 snprtRet = 0;
    INPUT_POINTER_CHECK(pulAreaLogLevel);
    if(BSP_OK == type)
    {
        snprtRet = snprintf_s(cOptKey, sizeof(cOptKey), AREA_LOG_KEY, area);
    }
    else
    {
        snprtRet = snprintf_s(cOptKey, sizeof(cOptKey), AREA_LOG_PRINT_DIR, area);
    }
    SNPRINTF_S_CHECK(snprtRet, sizeof(cOptKey));
    ulRet = BspReadRuCfgIniFieldValue(areaLogLevelConfFile, cOptKey, &tLoadCfgPara);

    if (BSP_OK != ulRet)
    {
        *pulAreaLogLevel = 0;
    }
    else
    {
        *pulAreaLogLevel = (UINT32)(tLoadCfgPara.cFieldValue) - 48;
    }

    return ulRet;
}

UINT32 BspLoadAreaLogLevels(VOID)
{
    UINT32 ulRet = BSP_ERROR;
    CHAR *area[6] = {"APP", "OSS", "BSP", "HAL", "OPT", "DSP"};
    UINT32 halLogLevel = 0;
    UINT32 optLogLevel = 0;
    UINT32 temp = 0;
    T_Bsp_RruIniCfgItem tLoadCfgPara = {0};

    ulRet = BspIsFileExist(areaLogLevelConfFile);
    if(BSP_OK == ulRet)
    {
        ulRet = BspReadRuCfgIniFieldValue(areaLogLevelConfFile, "BSP_LOG_PRINT_DIRECTORY_FLAG", &tLoadCfgPara);
        if(BSP_ERROR == ulRet)
        {
            BspDeleteFile(areaLogLevelConfFile);
            ulRet = BspCreateFile(areaLogLevelConfFile);
            if(BSP_ERROR == ulRet)
            {
                dbgErr("create log level file failed!\n");
                return BSP_ERROR;
            }
            ulRet = BspAddLogLevels();
            if(BSP_ERROR == ulRet)
            {
                dbgErr("add log levels failed!\n");
                return BSP_ERROR;
            }
        }
    }
    else
    {
        ulRet = BspCreateFile(areaLogLevelConfFile);
        if(BSP_ERROR == ulRet)
        {
            dbgErr("create log level file failed!\n");
            return BSP_ERROR;
        }
        ulRet = BspAddLogLevels();
        if(BSP_ERROR == ulRet)
        {
            dbgErr("add log levels failed!\n");
            return BSP_ERROR;
        }
    }

    for (int i = 0;i < 6;i++)
    {
        ulRet = readAreaLogLevel(area[i], &s_logLevel[i], 0);
        if(ulRet == BSP_ERROR)
        {
            dbgErr("load %s log level failed!\n",area[i]);
        }
        ulRet = readAreaLogLevel(area[i], &s_logPrintDirFlag[i], 1);
        if(ulRet == BSP_ERROR)
        {
            dbgErr("load  %s log print directory flag failed!\n",area[i]);
        }
    }
    halLogLevel = BspGetAreaLogLevel(LOG_HAL);
    temp = s_logPrintDirFlag[LOG_HAL];
    temp <<= 8;
    temp |= (UINT8)halLogLevel;
    IcHalApiSetHalLogLevel(temp);

    optLogLevel = BspGetAreaLogLevel(LOG_OPT);
    temp = 0;
    temp = s_logPrintDirFlag[LOG_OPT];
    temp <<= 8;
    temp |= (UINT8)optLogLevel;
    IcHalApiSetOptLogLevel(temp);

    BspSetLogPrintDirFlag(s_logPrintDirFlag[LOG_BSP]);
    if(BSP_OK == s_logPrintDirFlag[LOG_BSP])
    {
        BspSystem("rm -rf /ata/tmplog/");
        BspMkdir("/ata/tmplog/");
    }
    return ulRet;
}

UINT32 BspAddLogLevels(VOID)
{
    UINT32 ulRet = BSP_ERROR;
    CHAR levelStr = (CHAR)(48);
    CHAR *areaLogLevel[6] = {"LOG_APP_LEVEL","LOG_OSS_LEVEL","LOG_BSP_LEVEL","LOG_HAL_LEVEL","LOG_OPT_LEVEL","LOG_DSP_LEVEL"};
    CHAR *logPrintDirFlag[6] = {"APP_LOG_PRINT_DIRECTORY_FLAG",
                                "OSS_LOG_PRINT_DIRECTORY_FLAG",
                                "BSP_LOG_PRINT_DIRECTORY_FLAG",
                                "HAL_LOG_PRINT_DIRECTORY_FLAG",
                                "OPT_LOG_PRINT_DIRECTORY_FLAG",
                                "DSP_LOG_PRINT_DIRECTORY_FLAG",};
    for(int i = 0;i < 6;i++)
    {
        ulRet = BspAddRuCfgIniFieldValue(areaLogLevelConfFile,areaLogLevel[i],levelStr);
        if(BSP_ERROR == ulRet)
        {
            dbgErr("add log level failed!\n");
            return BSP_ERROR;
        }
        ulRet = BspAddRuCfgIniFieldValue(areaLogLevelConfFile,logPrintDirFlag[i],levelStr);
        if(BSP_ERROR == ulRet)
        {
            dbgErr("add log print directory flag failed!\n");
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

UINT32 BspGetAreaLogLevel(UINT32 area)
{
    if(area >= AREA_NUM)
    {
        return BSP_ERROR;
    }
    return s_logLevel[area];
}

UINT32 BspSetAreaLogLevel(UINT32 area,UINT32 logLevel)
{
    UINT32 retVal = BSP_OK;
    if(area >= AREA_NUM)
    {
        return BSP_ERROR;
    }
    s_logLevel[area] = logLevel;
    CHAR levelStr = (CHAR)(logLevel + 48);
    CHAR *areaName[6] = {"LOG_APP_LEVEL", "LOG_OSS_LEVEL", "LOG_BSP_LEVEL", "LOG_HAL_LEVEL", "LOG_OPT_LEVEL", "LOG_DSP_LEVEL"};
    retVal = BspSetRuCfgIniFieldValue(areaLogLevelConfFile,areaName[area],levelStr);
    return retVal;
}

/*设置log记录路径，flag取0:/tmplog/，1:/ata/tmplog/，重启生效 */
UINT32 SetLogDir(UINT32 area,UINT32 flag)
{
    UINT32 retVal = BSP_OK;
    CHAR logStr = (CHAR)(flag + 48);
    CHAR *areaName[6] = {"APP", "OSS", "BSP", "HAL", "OPT", "DSP"};
    CHAR  strKey[32]="";
    INT32 snprtRet = 0;

    if(area >= AREA_NUM)
    {
        dbgErr("input area is error!");
        return BSP_ERROR;
    }
    snprtRet = snprintf_s(strKey, sizeof(strKey), AREA_LOG_PRINT_DIR, areaName[area]);
    SNPRINTF_S_CHECK(snprtRet, sizeof(strKey));
    if((0 != flag) && (1 != flag))
    {
        return BSP_ERROR;
    }
    retVal = BspSetRuCfgIniFieldValue(areaLogLevelConfFile,strKey,logStr);
    return retVal;
}

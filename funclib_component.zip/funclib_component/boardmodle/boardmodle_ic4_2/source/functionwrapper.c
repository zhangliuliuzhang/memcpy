/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : functionwrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化流程函数
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/


#include "bsppub.h"
#include "bspcomm.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "functionwrapper.h"
#include "funccommon.h"
#include "freqcfgcommon.h"
#include "chnmapcommon.h"
#include "ichaladapt_ic4_2.h"
#include "optctrl_pre_alloc.h"
#include "timedelay_ic4_2.h"
#include "powerctrl_comps_ic4_2.h"
#include "cfrcommon.h"
#if defined(CFR_REFACTOR)
#include "cfr_dpdic.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"
#include "ichaladaptcfrapi.h"
#include "cfr_cfgpara.h"
#else
#include "cfr_ic4_2.h"
#include "cfr_ic4_2_coefdata.h"
#endif
#include "rruinfo.h"
#include "powerctrl_ic4_2.h"
#include "optadpt.h"
#include "boardsocmsg.h"
#include "dpd_app.h"
#include "dpdcommon.h"
#include "gainctrl_ic4_2.h"
#include "freqcfg_ic4_2.h"
#include "freqcfg_ic4_2_analyse.h"
#include "boardvga.h"
#include "rruabilitycommon.h"
#include "funccommon_a.h"
#include "tddcfg_ic4_2.h"
#include "rxscan_ic4_2.h"
#include "powerctrl_comps_ic4_2.h"
#include "vectorvswr_ic4_2.h"
#include "rftable.h"
#include "papt_common.h"
#include "boarddtxpwrsave.h"
#include "pwr_common.h"
#include "pwr_a.h"
#include "linkcfg_ic4_2.h"
#include "optctrl_cpri_ic4_2.h"
#include "boardid.h"
#include "optctrl_ntl_ic4_2.h"
#ifndef MULT_PROGRESS_S
#include "cpri_reg.h"
#include "sfp.h"
#include "optadpt.h"
#endif
#include "ntfcommon.h"
/**************************************************************************
                            全局变量
**************************************************************************/
static UINT32 g_Soc_Radiocfg = RADIO_STANDARD_UMTS | RADIO_STANDARD_GSM | RADIO_STANDARD_LTE_FDD | RADIO_STANDARD_NB_IOT | RADIO_STANDARD_FDD_5G;
static UINT32 g_Soc_Radiocfg_init_flag = 0x8000;

extern DOUBLE s_WinCoef[4096];
extern UINT32 s_WinCoefLen;

#define FUNCTION_DATA_FILE_NAME       "FunctionData.json"

/**************************************************************************
                            内部接口
**************************************************************************/
/***********T+Fe功率共享机型,回调函数**************************/
FUNC_SET_SOC_RADIOCFG_FLAG s_SetSocRadioCfgFlag = NULL;
UINT32 s_cfgRadio = 0xFFFFFFFF;
VOID BspRegisterRadioCfgCallBack(FUNC_SET_SOC_RADIOCFG_FLAG pFunc, UINT32 data)
{
    s_SetSocRadioCfgFlag = pFunc;
    s_cfgRadio = data;
}

FUNC_CHANGE_SOC_RADIOCFG s_ChangeSocRadioCfg = NULL;
UINT32 s_ChangeSocRadioVal = 0xFFFFFFFF;
VOID BspChangeRadioCfgCallBack(FUNC_SET_SOC_RADIOCFG_FLAG pFunc, UINT32 data)
{
    s_ChangeSocRadioCfg = pFunc;
    s_ChangeSocRadioVal = data;
}
/**************************************************************************
                            对外接口
**************************************************************************/
/*配频模块初始化*/
UINT32 BspTxFreqCfgInit(VOID)
{
    UINT32 bspChan     = 0;
    UINT32 loop        = 0;
    UINT32 chanSelect  = 0;
    UINT32 retVal = BSP_OK;
    T_FreqCfgData *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_TX_FREQ_CFG,0,0,pPara,num);
    for(loop = 0; loop < num; loop++)
    {
        chanSelect = pPara[loop].chanSelect;
        for (bspChan = 0; bspChan < BspGetTxBspChanNum(); bspChan++)  //TX
        {
            if(BIT_VAL(chanSelect,bspChan))
            {
                BspRfPllCfgInit(bspChan, TX, &pPara[loop].freqPara);
            }
        }
    }

    /* 功率检测开关挂接 */
    BspSetCallBackChanPowCalcSw(powsw);

    /* NB in-band/guard-band 频偏设置接口挂接 */
    if (NULL == BspGetNbTxFreqOffsetCallBack())
    {
        retVal |= BspSetNbTxFreqOffsetCallBack((pSetNbTxFreqOffset)BspSetTxNbGuardOffset);
    }

    return retVal;
}

UINT32 BspRxFreqCfgInit(VOID)
{
    UINT32 bspChan   = 0;
    UINT32 loop      = 0;
    UINT32 chanSelect  = 0;
    UINT32 retVal = BSP_OK;
    T_FreqCfgData *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_RX_FREQ_CFG,0,0,pPara,num);
    for(loop = 0; loop < num; loop++)
    {
        chanSelect = pPara[loop].chanSelect;
        for (bspChan = 0; bspChan < BspGetRxBspChanNum(); bspChan++)  //RX
        {
            if(BIT_VAL(chanSelect,bspChan))
            {
                BspRfPllCfgInit(bspChan, RX, &pPara[loop].freqPara);
            }
        }
    }

    /* NB in-band/guard-band 频偏设置接口挂接 */
    if (NULL == BspGetNbRxFreqOffsetCallBack())
    {
        retVal |= BspSetNbRxFreqOffsetCallBack((pSetNbRxFreqOffset)BspSetRxNbGuardOffset);
    }

    return retVal;
}
/*****************************************************************************
 *  函数名称   : BspPreAllocInit()
 *  功能描述   : 单板下根据规格预先设置一个场景
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *****************************************************************************/
UINT32 BspOptPreAllocInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 rruType = TDD_TYPE;
    T_BspHalAdaptPreAllocCarrInfo *pPara = NULL;
    T_BspHalAdaptPreAllocBoardPara *pParaEx = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_PRE_ALLOC,0,0,pPara,num);
    BOARD_MODLE_GET_DATA(E_FUNCTION_PRE_ALLOC,0,1,pParaEx,num);
    /* todo 待和钟用共通完善 */
    rruType = BspGetFddTddCoExistSta();
    retVal = BspInitBoardPreAllocInfo(pPara,rruType);
    retVal |= BspInitBoardPreAllocParaToHal(pParaEx->ulType,pParaEx->ulAntMask);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspVgaLikeSpiParaInit()
 *  功能描述   : 单板下根据规格预先设置一个场景
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *****************************************************************************/
UINT32 BspVgaLikeSpiParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_MtsIcBusRoutePara *pPara = NULL;
    T_MtsBusCfgSpiPara *pParaEx = NULL;
    UINT32 num = 0;
    UINT32 numEx = 0;
    UINT32 uiLoop = 0;
    BOARD_MODLE_GET_DATA(E_FUNCTION_VGA_LIKE_SPI_PARA_INIT,0,0,pPara,num);
    BOARD_MODLE_GET_DATA(E_FUNCTION_VGA_LIKE_SPI_PARA_INIT,0,1,pParaEx,numEx);


    for(uiLoop = 0;uiLoop < num;uiLoop++)
    {

    	retVal = BspHalAdaptSetMtsBusRoute(pPara[uiLoop].uiDifChan,pPara[uiLoop].uiMtsBusIdx,pPara[uiLoop].uiMtsRx);
    }

    for(uiLoop = 0;uiLoop < numEx;uiLoop++)
    {

    	retVal = BspHalAdaptInitMtsBusCfg(pParaEx[uiLoop].uiMtsBusIdx,&pParaEx[uiLoop].mtsBusCfgPara);
    }

    return retVal;
}

/*功率检测-HAL层功率检测参数初始化*/
UINT32 BspInitPowCalcPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_BspHalAdaptPowChk *pPowChkPara  = NULL;
    T_BspHalAdaptGsmPowChk *pGsmPowChkPara  = NULL;
    
    BOARD_MODLE_GET_DATA(E_FUNCTION_POWCALC_INIT, 0, 0, pPowChkPara, paraNum);
    retVal = BspSetPowCalcPara(pPowChkPara);

    BOARD_MODLE_GET_DATA(E_FUNCTION_GSM_POWCALC_INIT, 0, 0, pGsmPowChkPara, paraNum);
    retVal |= BspSetGsmPowCalcPara(pGsmPowChkPara);
    
    BspClearCarrGainCallBackInit(BspClearCarrGain);

    return retVal;
}
/*功率门限相关初始化*/
UINT32 BspInitPowCalcThresholdPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    UINT32 chanNum = BspGetBspChanNum(TX);
    UINT32 thresholdIndex = 0;
    UINT32 ulChanLoop = 0;
    UINT32 loop = 0;
    UINT32 chanMask = 0;
    T_PowThreInitPara *pPowThrePara = NULL;

    retVal = BspInitPowCalc();
    BOARD_MODLE_GET_DATA(E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT, 0, 0, pPowThrePara, num);
    dbgInfo("%s  ,line:%d\n", __FUNCTION__,__LINE__);
    for(loop = 0; loop < num; loop++)
    {
        chanMask = pPowThrePara[loop].chanmask;
        dbgInfo("%s  ,line:%d, chanmask%d\n", __FUNCTION__,__LINE__,chanMask);
        for(ulChanLoop = 0; ulChanLoop < chanNum; ulChanLoop++)
        {
            if(BIT_VAL(chanMask,ulChanLoop))
            {
                retVal |= BspSetPowAvgCnt(ulChanLoop,pPowThrePara[loop].powAvgCnt);
                dbgInfo("%s  ,line:%d, powAvgCnt%d\n", __FUNCTION__,__LINE__,pPowThrePara[loop].powAvgCnt);
                for(thresholdIndex = 0; thresholdIndex < THRESHOLD_NUM; thresholdIndex++)
                {
                	dbgInfo("%s  ,line:%d, powDbmThreshold :%d\n", __FUNCTION__,__LINE__,pPowThrePara[loop].powDbmThreshold[thresholdIndex]);
                    retVal |= BspSetVswrThreshhold(ulChanLoop,thresholdIndex,pPowThrePara[loop].vswrThreshold[thresholdIndex]);
                    retVal |= BspSetPowThreshhold(ulChanLoop,thresholdIndex,pPowThrePara[loop].powDbmThreshold[thresholdIndex]);
                    retVal |= BspSetVwsrThreshold(ulChanLoop,thresholdIndex,pPowThrePara[loop].vswrPowThresHold[thresholdIndex]);
                }
            }
            
        }
    }
    return retVal;
}

/*温度门限相关初始化*/
UINT32 BspInitTempThresholdPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    UINT32 loop = 0;
    T_ThresholdPara *pTempThrePara = NULL;
    T_ModifyPaVolt *pPara = NULL;
    UINT32 len = 0;
    UINT32 tmpRet = BSP_OK;

    BOARD_MODLE_GET_DATA(E_FUNCTION_TEMP_THRESHOLD_PARA_INIT, 0, 0, pTempThrePara, num);

    dbgInfo("%s  ,line:%d\n", __FUNCTION__,__LINE__);

    for(loop = 0; loop < num; loop++)
    {
        if(SUPP_REDUCE_PA_VOLT == BspGetReducePaVoltFlag())
        {
            tmpRet = BspBoardModleGetData(E_CHIP_POWERON_MODIFY_PA_VOLT, 0, 0, (VOID**)(&pPara), &(len));
            if((BSP_OK == tmpRet) && (NULL != pPara))
            {
                if(BSP_THRESHOLD_ID_SLIGHTOVER_PA_TEMPER == pTempThrePara[loop].devIdVal)
                {
                    pTempThrePara[loop].alarmThreshold += pPara->paPreOverTempThre;
                    pTempThrePara[loop].recoverThreshold += pPara->paPreOverTempThre;
                }
            }
        }
        retVal |= BspSetTempThresholdFromBoard(pTempThrePara[loop].devIdVal, pTempThrePara[loop].alarmThreshold, pTempThrePara[loop].recoverThreshold);

    }
    return retVal;
}

/*功率检测任务初始化*/
UINT32 BspInitPowCalcThread(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    T_PowUpdateTime *pPowCalcTime = NULL;
    BOARD_MODLE_GET_DATA(E_FUNCTION_POWCALC_THREAD_INIT, 0, 0, pPowCalcTime, num);
    BspSetPcGainOffsetFlag(PCGAIN_OFFSET);
    retVal = BspSetSpePowTimeCfg(pPowCalcTime->powCalcTime);
    retVal |= BspPowCalcThreadInit();
    retVal |= BspTssiUpdateThreadInit();
    retVal |= BspSetNbicAccClrThreadInit(); /* ANF抵消功能异常问题任务 */

    return retVal;
}
/*DSP功率检测任务初始化*/
UINT32 BspInitDpdPowCalcThread(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_DspPowCalcPara *pDspPowCalcPara = NULL;
    BOARD_MODLE_GET_DATA(E_FUNCTION_DSP_CALC_POW_PARA, 0, 0, pDspPowCalcPara, paraNum);
    retVal  = BspInitDspPowCalcPara(pDspPowCalcPara);
    retVal |= BspDpdPowCalcThreadInit();

    return retVal;
}

/* 功率计算-定标参数初始化 */
UINT32 BspInitDlPowCalcPara(VOID)
{    
    UINT32 retVal = BSP_OK;
    UINT32 dlParaNum = 0;
    T_DlPowCalcPara *pDlPara  = NULL;
    
    BOARD_MODLE_GET_DATA(E_FUNCTION_DL_POWCALC_PARA_INIT, 0, 0, pDlPara, dlParaNum);
    retVal = _BspSetDlPowDefPara(pDlPara, dlParaNum);

    return retVal;
}

UINT32 BspInitUlPowCalcPara(VOID)
{    
    UINT32 retVal = BSP_OK;
    UINT32 dlParaNum = 0;
    T_UlPowCalcPara *pUlPara  = NULL;
    
    BOARD_MODLE_GET_DATA(E_FUNCTION_UL_POWCALC_PARA_INIT, 0, 0, pUlPara, dlParaNum);

    retVal = _BspSetUlPowDefPara(pUlPara, dlParaNum);

    return retVal;
}

/* 降额参数初始化 */
UINT32 BspPowerAdjParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_UL_POWERCADJ_PARA_INIT, 0, 0, pPara, num);
    return BspSetPowerAdjPara((INT32*)pPara, num);
}

/*射频链路延时初始化*/
UINT32 BspTxRfDlyInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    BOARD_MODLE_GET_DATA(E_FUNCTION_TX_RF_DELAY,0,0,pPara,num);

    retVal = BspInitJ204AndRfDly(TX,(UINT32*)pPara,num);
    CHECK_RETVAL(BspInitJ204AndRfDly, retVal);
  
    return retVal;
}

UINT32 BspRxRfDlyInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    BOARD_MODLE_GET_DATA(E_FUNCTION_RX_RF_DELAY,0,0,pPara,num);

    retVal = BspInitJ204AndRfDly(RX,(UINT32*)pPara,num);
    CHECK_RETVAL(BspInitJ204AndRfDly, retVal);
  
    return retVal;
}

/*理论延时和实际延时差值初始化*/
UINT32 BspInitTxDeltDly(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    BOARD_MODLE_GET_DATA(E_FUNCTION_TX_DELT_DELAY,0,0,pPara,num);

    retVal = BspDeltDlyInit(TX,(T_BspHalAdaptLinkDeltDly*)pPara,num);
    CHECK_RETVAL(BspDeltDlyInit, retVal);
 
    return retVal;
}

UINT32 BspInitRxDeltDly(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    BOARD_MODLE_GET_DATA(E_FUNCTION_RX_DELT_DELAY,0,0,pPara,num);

    retVal = BspDeltDlyInit(RX,(T_BspHalAdaptLinkDeltDly*)pPara,num);
    CHECK_RETVAL(BspDeltDlyInit, retVal);
 
    return retVal;
}


/*FDD机型时，给BBU 上报的T2A和TA3的时延参数初始化*/
UINT32 BspInitFddDlyPara(VOID)
{
    UINT32 retVal = BSP_OK;
    T_FddCarrDlyReportPara *pDlyInfo = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;
    BOARD_MODLE_GET_DATA(E_FUNCTION_FDD_DELAY,0,0,pDlyInfo,num);
    for(loop = 0; loop < num; loop++ )
    {
        retVal |= BspInitFddDlyInfo(pDlyInfo[loop].radio,&pDlyInfo[loop].carrDlyInfo);

    }

    return retVal;
}

/* Started by AICoder, pid:59ec781a6cw1f29146aa081a304d8c0981c9cc83 */
/*FDD机型时，给BBU上报的Toffset时延参数初始化*/
UINT32 BspInitFddToffset(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_FDD_TOFFSET,0,0,pPara,num);

    retVal = BspInitFddToffsetVal(*((UINT32*)pPara));

    return retVal;
}

/*FDD机型时，给BBU上报的固定链路延时参数初始化*/
UINT32 BspInitFddFixLink(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_FDD_FIXLINK,0,0,pPara,num);

    retVal = BspInitFddFixLinkDly(*((UINT32*)pPara));

    return retVal;
}
/* Ended by AICoder, pid:59ec781a6cw1f29146aa081a304d8c0981c9cc83 */

/*多片机型时，片间传输延时初始化，只有多片机型需要*/
UINT32 BspInitChipTranDlyPara(VOID)
{
    UINT32 retVal = BSP_OK;
    T_RruChipTranDly *pChipTranDly = NULL;
    T_RruChipTranDlyAllChip *pChipTranDlyAllChip = NULL;
    UINT32 num = 0;
    UINT32 pathNum = 0;
    UINT32 chipId = BspGetRpuId();
    T_CpriModeLaneRoutePara laneRoutePath = {0};
    UINT32 pathIndex = 0;

    retVal = BspBoardModleGetData(E_FUNCTION_CHIP_TRANDLY_ALL_PATH, 0, 0, (VOID**)(&pChipTranDlyAllChip), &(pathNum));
    if(BSP_OK != retVal)
    {
        dbgInfo("bsp get chip transfer delay err!\n");
    }
    BOARD_MODLE_GET_DATA(E_FUNCTION_CHIP_TRANDLY,0,0,pChipTranDly,num);
    if(NULL == pChipTranDlyAllChip)
    {
        retVal |= BspInitChipTransmitDlyAll(pChipTranDly,num);
        retVal |= BspInitChipTransmitDlyOneChip(chipId);
        return retVal;
    }

    retVal = BspGetOptCpriModePathParaFromRam(&laneRoutePath);
    if(BSP_OK == retVal)
    {
        pathIndex = laneRoutePath.routePath;
    }
    if(0 == chipId)
    {
        retVal = BspGetLaneRoutePathFromFlash(&pathIndex);
    }
    if(pathIndex >= pathNum)
    {
        pathIndex = 0;
    }
    retVal |= BspInitChipTransmitDlyAll(pChipTranDlyAllChip[pathIndex].allChipTranDly,num);
    retVal |= BspInitChipTransmitDlyOneChip(chipId);
    return retVal;
}

/* 适用于单片或主进程场景*/
UINT32 BspInitRruDefAbility_M(VOID)
{
    UINT32 retVal = BSP_OK;
    T_RruDefAbility *pPara = NULL;
    T_RadioPara para = {NULL};/*当前应该可以各机型通用，暂时不抽取成参数*/
    UINT32 *paraEx = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_DEFABILITY,0,0,pPara,num);
    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_DEFABILITY,0,1,paraEx,num);

    retVal = BspSetCarrierNum(pPara->carrNum);
    retVal |= BspSetDefaultRadio(pPara->defRadio);
    retVal |= BspSetRadioStandard(pPara->defRadio);
    retVal |= BspLoadRadioFile();
    BspGetRadioCfg();

    if(RADIO_STANDARD_NB_IOT == (RADIO_STANDARD_NB_IOT & BspGetDefaultRadio()))  //IC4.2平台，针对支持NB机型给BBU上报rruclass字段值为6
    {
        retVal |= BspSetRruClass(RRU_CLASS_NB_SUPPORT);
    }

    para.pGetRadionMode = BspGetRadioCfg;
    para.pSetRadionMode = BspSetRadioCfg;
    retVal |= BspSetChanModeType(paraEx,num);
    retVal |= BspInitRadioPara(&para);
    retVal |= BspInitRruAbilityFunc();
    BspSetVersionLoadType(VERSON_LOAD_TYPE_COMPONENTIZATION);

    return retVal;
}
/*适用于从片获取整机制式*/
UINT32 BspGetSocRadioCfg(VOID)
{
    UINT32 ulTypeRet = 0;

    if (0 != g_Soc_Radiocfg_init_flag)
    {
        dbgErr("%s>>Error! RadioCfgInitFlag'0x%08X Not Init; RadioMode(0x%08X:5G 0x%08X:4G)= 0x%08X\n",
               __FUNCTION__, g_Soc_Radiocfg_init_flag, RADIO_STANDARD_5G, RADIO_STANDARD_LTE_TDD, g_Soc_Radiocfg);

        g_Soc_Radiocfg_init_flag |= BIT_SET(13);
    }
    ulTypeRet = g_Soc_Radiocfg ;

    return ulTypeRet;
}



/* Started by AICoder, pid:35c55x10df6c1e7148cc0a9240c1511c7807ae99 */
/* 适用于从进程的场景*/
UINT32 BspInitRruDefAbility_S(VOID)
{
    UINT32 retVal = BSP_OK;
    T_RruDefAbility *pPara = NULL;
    T_RadioPara para = {NULL};/*当前应该可以各机型通用，暂时不抽取成参数*/
    UINT32 num = 0;
    UINT32 ulRdRadioStd = 0;
    UINT32 *paraEx = NULL;

    ulRdRadioStd = GetRadioCfg();/*从板向主板索要射频制式*/
    g_Soc_Radiocfg = ulRdRadioStd;

    if(s_SetSocRadioCfgFlag != NULL)
    {
        g_Soc_Radiocfg = ulRdRadioStd & s_cfgRadio;
    }

    if(s_ChangeSocRadioCfg != NULL)
    {
        g_Soc_Radiocfg = s_ChangeSocRadioVal;
    }

    if (0x8000 == g_Soc_Radiocfg_init_flag)
    {       
        g_Soc_Radiocfg_init_flag = 0;
    }
    else
    {
        g_Soc_Radiocfg_init_flag |= BIT_SET(14);
    }
    para.pGetRadionMode = BspGetSocRadioCfg;
    para.pSetRadionMode = NULL;
    retVal = BspInitRadioPara(&para);

    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_DEFABILITY,0,0,pPara,num);
    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_DEFABILITY,0,1,paraEx,num);

    retVal |= BspSetChanModeType(paraEx,num);
    retVal |= BspSetCarrierNum(pPara->carrNum);
    retVal |= BspSetRadioStandard(pPara->defRadio);
    retVal |= BspInitRruAbilityFunc();
    BspSetVersionLoadType(VERSON_LOAD_TYPE_COMPONENTIZATION);
    return retVal;
}
/* Ended by AICoder, pid:35c55x10df6c1e7148cc0a9240c1511c7807ae99 */

/*****************************************************************************
*  函数名称   : BspInitRruUlDelayCmpAbility()
*  功能描述   : 初始化RRU 上行时延补偿能力
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
*/
UINT32 BspInitRruUlDelayCmpAbility(VOID)
{
    UINT32 retVal         = BSP_OK;
    UINT32 num            = 0;
    UINT32 *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_ULDELAY_CMPABILITY,0,0,pPara,num);

    retVal |= BspSetTddCarr40KMAbility(1);
    retVal |= BspSetUlDelayCmpAbility(pPara[0], DELAY_CMP_FUNC_NOT_SUPPORT);

    return retVal;
}


/*****************************************************************************
*  函数名称   : BspInitRruCarrAbility()
*  功能描述   : 初始化RRU 载波上报能力
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),10191426@2019-05-21 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspInitRruCarrAbility(VOID)
{
    UINT32 num = 0;
    UINT32 radioMode = 0;
    UINT32 ulRadioType = 0;
    UINT32 ulCarrierNrSum = 0;
    UINT32 ulCarrierLteSum = 0;
    UINT32 retVal = BSP_OK;
    T_RruCarrAbility *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_CARR_ABILITY,0,0,pPara,num);
    ulRadioType = BspGetRadioStandard();
    radioMode = ulRadioType & BSP_RADIO_STANDARD_LTE_NR_MIX;

    if ((radioMode&BSP_RADIO_STANDARD_5G) || (radioMode&BSP_RADIO_STANDARD_LTE_TDD))
    {
        if (BSP_RADIO_STANDARD_LTE_TDD == radioMode) 
        {
            ulCarrierLteSum = pPara->singleLteCarrNum;
        }
        else if (BSP_RADIO_STANDARD_5G == radioMode) 
        {
            ulCarrierNrSum = pPara->singleNrCarrNum;
        }
        else
        {
            ulCarrierNrSum = pPara->mixNrCarrNum;
            ulCarrierLteSum = pPara->mixLteCarrNum;
        }
        retVal = BspSetCarrNumCfg(RADIOMODE_NR_INDEX, ulCarrierNrSum);
        retVal |= BspSetCarrNumCfg(RADIOMODE_LTE_TDD_INDEX, ulCarrierLteSum);
        BspSetSlaveCarrierNum(ulCarrierNrSum + ulCarrierLteSum);      /*母端高层上报的时候用的是这两个变量 单模的时候其中一个变量为0*/
    }
    
    else
    {
        if (BSP_RADIO_STANDARD_LTE_FDD == radioMode)
        {
            ulCarrierLteSum = pPara->singleLteCarrNum;
        }
        else if (BSP_RADIO_STANDARD_FDD_5G == radioMode)
        {
            ulCarrierNrSum = pPara->singleNrCarrNum;
        }
        else
        {
            ulCarrierNrSum = pPara->mixNrCarrNum;
            ulCarrierLteSum = pPara->mixLteCarrNum;
        }
        retVal = BspSetCarrNumCfg(RADIOMODE_NR_INDEX, ulCarrierNrSum);
        retVal |= BspSetCarrNumCfg(RADIOMODE_LTE_FDD_INDEX, ulCarrierLteSum);
    }
    //retVal |= BspInitRruUlDelayCmpAbility();
    
    dbgInfo("%s>>RadioMode'%d: CfgCarrNrSum= %d CfgCarrLteSum= %d\n", __FUNCTION__, ulRadioType, ulCarrierNrSum, ulCarrierLteSum);
    return retVal;
}

/* 削峰动态参数（削峰门限、窗长、检测门限、窗长等级）初始化 */
UINT32 BspInitCfrDymPara(VOID)
{
    UINT32 retVal  = BSP_OK;
    UINT32 paraNum = 0;
    T_CfrGateCfgGroup *pCfrGateCfgGroup = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_CFR_DYN_PARA_INIT, 0, 0, pCfrGateCfgGroup, paraNum);
    retVal = BspCfrDymParaInit(paraNum, pCfrGateCfgGroup);

    return retVal;
}

/* 削峰模块初始化 */
UINT32 BspInitCfrFunc(VOID)
{
    UINT32 retVal  = BSP_OK;
    UINT32 paraNum = 0;
    UINT32 chnLoop = 0;
    UINT32 cpgFlag = CFR_CPG_CPU_CAL;
    T_BspHalAdaptDifCommCfrPara *pCfrCommPara = NULL;

    //挂接根据CPG长度配置中频时延的回调接口,在配频之后调用
    retVal = BspSetCallBackAfterFreqcfg(TX, 0, BspSetDlyPara);
    retVal |= BspInitCfrModuleFunc();
    retVal |= BspSetCfrLutLen(CFR_CPG_RAM_768);
    retVal |= BspCfrHbfParaInitAll();
    retVal |= BspInitCfrDymPara();
    retVal |= BspHalAdaptCfrSetTddswInit();
    retVal |= BspHalAdaptCfrSetEnergyInit();
    retVal |= BspInitPowShareModule();
    retVal |= BspSetTssiPowInfoCallBackInit(BspGetTssiPowInfo);  /*分载波功率获取接口*/
    retVal |= BspSetTxIfTssiCallBackInit(BspGetTxIfTssi);  /*合载波数字功率获取接口*/

    BOARD_MODLE_GET_DATA(E_FUNCTION_CFR_COMM_PARA_INIT, 0, 0, pCfrCommPara, paraNum);

    for (chnLoop = 0; chnLoop < BspGetTxChanNum(); chnLoop++)
    {
        if (pCfrCommPara->uiCpgMode[chnLoop] == CFR_CPG_HW_CAL)
        {
            cpgFlag = CFR_CPG_HW_CAL;
            break;
        }
    }

    if (cpgFlag == CFR_CPG_HW_CAL)
    {
        retVal |= BspCfrSetFreqWordFsInit();
        retVal |= BspCfrSetDlpreKiPowSelInit();
    }

    return retVal;
}

/* 削峰软、硬件计算的静态参数初始化 */
UINT32 BspInitCfrPara(VOID)
{
    UINT32 retVal        = BSP_OK;
    UINT32 paraNum       = 0;
    UINT32 chnLoop       = 0;
    UINT32 cpgFlag       = CFR_CPG_CPU_CAL;
    T_BspHalAdaptDifCommCfrPara *pCfrCommPara   = NULL;
    T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara  = NULL;
    T_BspHalAdaptCfrKnWordPara  *pCfrKnWordPara = NULL;
    T_BspHalAdaptCfrParCommPara *pCfrParPara    = NULL;
    T_BspHalAdaptDpdParCommPara *pDpdParPara    = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_CFR_COMM_PARA_INIT, 0, 0, pCfrCommPara, paraNum);
    retVal = BspInitCfrCommPara(pCfrCommPara);

    BOARD_MODLE_GET_DATA(E_FUNCTION_CFR_PAR_PARA_INIT, 0, 0, pCfrParPara, paraNum);
    retVal |= BspInitCfrParPara(pCfrParPara);

    BOARD_MODLE_GET_DATA(E_FUNCTION_DPD_PAR_PARA_INIT, 0, 0, pDpdParPara, paraNum);
    retVal |= BspInitDpdParPara(pDpdParPara);

    for (chnLoop = 0; chnLoop < BspGetTxChanNum(); chnLoop++)
    {
        if (pCfrCommPara->uiCpgMode[chnLoop] == CFR_CPG_HW_CAL)
        {
            cpgFlag = CFR_CPG_HW_CAL;
            break;
        }
    }

    if (cpgFlag == CFR_CPG_HW_CAL)
    {
        retVal |= BspInitCfrSetCpgGateBypass();
        retVal |= BspInitRangeBandPara();
        retVal |= BspSetCpgParaRangeCarrInit();

        BOARD_MODLE_GET_DATA(E_FUNCTION_CFR_KICOMM_PARA_INIT, 0, 0, pCfrHWCpgPara, paraNum);
        retVal |= BspInitKiCommPara(pCfrHWCpgPara);

        BOARD_MODLE_GET_DATA(E_FUNCTION_CFR_KNCOMM_PARA_INIT, 0, 0, pCfrKnWordPara, paraNum);
        retVal |= BspInitKnCommPara(pCfrKnWordPara);
    }

    return retVal;
}

/*****************************************************************************
 *  函数名称   : TrxDigGainInit
 *  功能描述   : 上下行数字增益初始化
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 成功; 其它值为失败
 *  其它说明   : 1、K0 cfr前增益；Kf cfr后；Kd dpd后，配合att做闭环功控0.5db以内调节。
 *              2、FDD：基带功率-13dbfs,Tx的K0=-6dB,Kf=2dB,Kd=0dB；Rx的Pc=0dB。
 *              3、TDD：基带功率-14dbfs,Tx的K0=-5dB,Kf=4dB,Kd=0dB；Rx的Pc=0dB。
 *              4、开环时,Tx方向调节Kd值和TxAtt。
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-05-27, 创建
 *----------------------------------------------------------------------------
 */
UINT32 TrxDigGainInit(VOID)
{
    UINT32 retVal    = BSP_OK;
    UINT32 chan      = 0;
    UINT32 paraNum   = 0;
    T_GainCommPara *pGainCommPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_TRX_DIG_GAIN_INIT, 0, 0, pGainCommPara, paraNum);

    retVal = BspSetGainCommPara(pGainCommPara);

    for (chan = 0; chan < BspGetTxChannel(); chan++)
    {
        retVal |= BspSetMixGain(chan, 0, pGainCommPara->preCfrGain[chan]);  /* CFR入口，K0增益调节点 */
        retVal |= BspSetKfGain(chan, pGainCommPara->preDpdGain[chan]);      /* 进DPD增益 */
        retVal |= BspSetKdGain(chan, pGainCommPara->outDpdGain[chan]);      /* out dpd  */
        retVal |= BspHalAdaptSetDlpreTdmGain(chan, pGainCommPara->dlPreGain[chan]);
        retVal |= BspSetLinkCfgDlpreGain(chan, pGainCommPara->dlPreGain[chan]);
    }

    return retVal;
}

/*DPD均值保护后希望降低进入dpd的功率*/
UINT32 BspFixPaptKfGain(UINT32 chan, INT32 gain)
{
    UINT32 paraNum   = 0;
    T_GainCommPara *pGainCommPara = NULL;
    UINT32 retVal = BSP_OK;

    BOARD_MODLE_GET_DATA(E_FUNCTION_TRX_DIG_GAIN_INIT, 0, 0, pGainCommPara, paraNum);
    if(0 == gain)
    {
        retVal = BspSetKfGain(chan, pGainCommPara->preDpdGain[chan]);      /* 进DPD增益 设置为默认值*/
    }
    else
    {
        retVal = BspSetKfGain(chan, gain);      /* 进DPD增益 设置调整值-1900+tar*/
    }

    return retVal;
}

/*****************************************************************************
 *  函数名称   : DPD功能初始化
 *  功能描述   : 给dsp下发静态路由和整机硬件信息
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 成功; 其它值为失败
 *  其它说明
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspInitDpdFunc(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspDpdSetRruInfo(0,0);
    retVal |= BspInitDpdModulePimFunc();

    return retVal;
}

/* VGA相关总线初始化 */
UINT32 BspVgaBusInit(VOID)
{
    UINT32 retVal   = BSP_OK;
    UINT32 ifBusNum = 0;
    UINT32 rfBusNum = 0;
    UINT32 paraNum  = 0;
    UINT32 routeNum = 0;
    UINT32 spiFlg   = 0;
    UINT32 spiNo    = 0;
    UINT32 loop     = 0;
    UINT32 oE       = 1;

    T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara = NULL;
    T_BspHalAdaptTimeCfgPara *pTimeSlice = NULL;
    T_IfBusParaTbl *pIfBusPara = NULL;
    T_RfBusParaTbl *pRfBusPara = NULL;
    T_VgaChnRoute *pRoute = NULL;

    retVal |= BspBoardModleGetData(E_FUNCTION_VGA_CTRL_PARA_INIT, 0, 0, (VOID**)(&pVgaCtrlPara), &(paraNum));
    if(NULL != pVgaCtrlPara)
    {
        if (VGA_MODE_AGC == pVgaCtrlPara->uiVgaMode)
        {
            return retVal;
        }
    }

    retVal |= BspHalAdaptInitVgaOeInput(oE);
    retVal |= BspHalAdaptInitVgaBusPara();
    
    retVal |= BspBoardModleGetData(E_FUNCTION_MGC_TIME_SLICE_PARA_INIT, 0, 0, (VOID**)(&pTimeSlice), &(paraNum));
    if(NULL != pTimeSlice)
    {
        retVal |= BspHalAdaptSetIfRfSendTimeFlagCfg(pTimeSlice);
    }

    retVal |= BspBoardModleGetData(E_FUNCTION_IF_BUS_PARA_INIT, 0, 0, (VOID**)(&pIfBusPara), &(ifBusNum));
    if(NULL != pIfBusPara)
    {
        for (spiNo = 0; spiNo < ifBusNum; spiNo++)
        {
            retVal |= BspHalAdaptInitIfBusPara(pIfBusPara[spiNo].ifSpiNo, pIfBusPara[spiNo].ifBusParaTbl);
        }
    }

    retVal |= BspBoardModleGetData(E_FUNCTION_RF_BUS_PARA_INIT, 0, 0, (VOID**)(&pRfBusPara), &(rfBusNum));
    if(NULL != pRfBusPara)
    {
        for (spiNo = 0; spiNo < rfBusNum; spiNo++)
        {
            retVal |= BspHalAdaptInitRfBusPara(pRfBusPara[spiNo].rfSpiNo, pRfBusPara[spiNo].rfBusRate);
        }
    }

    retVal |= BspBoardModleGetData(E_FUNCTION_VGA_CHN_ROUTE_INIT, 0, 0, (VOID**)(&pRoute), &(routeNum));
    if(NULL != pRoute)
    {
        for (spiFlg = 0; spiFlg < routeNum; spiFlg++)
        {
            if (RF_SPI_BUS == pRoute[spiFlg].spiFlag)
            {
                for (spiNo = 0; spiNo < pRoute[spiFlg].Num; spiNo++)
                {
                    dbgInfoEx("%s: RF_SPI spiFlg: %d spiNo: %d Len: %d \n", __FUNCTION__, spiFlg, spiNo, pRoute[spiFlg].route[spiNo].Len);
                    for (loop = 0; loop < pRoute[spiFlg].route[spiNo].Len; loop++)
                    {
                        retVal |= BspHalAdaptSetRfBusRoute(pRoute[spiFlg].route[spiNo].spiNo, pRoute[spiFlg].route[spiNo].Tbl[loop].difChn, pRoute[spiFlg].route[spiNo].Tbl[loop].vgaCh);
                    }
                }
            }

            if (IF_SPI_BUS == pRoute[spiFlg].spiFlag)
            {
                for (spiNo = 0; spiNo < pRoute[spiFlg].Num; spiNo++)
                {
                    dbgInfoEx("%s: IF_SPI spiFlg: %d spiNo: %d Len: %d \n", __FUNCTION__, spiFlg, spiNo, pRoute[spiFlg].route[spiNo].Len);
                    for (loop = 0; loop < pRoute[spiFlg].route[spiNo].Len; loop++)
                    {
                        retVal |= BspHalAdaptSetIfBusRoute(pRoute[spiFlg].route[spiNo].spiNo, pRoute[spiFlg].route[spiNo].Tbl[loop].difChn, pRoute[spiFlg].route[spiNo].Tbl[loop].vgaCh);
                    }
                }
            }
        }
    }

    return retVal;
}

/* 射频rfbus总线外挂VGA器件的初始化 */
UINT32 BspRfVgaInit(VOID)
{
    UINT32 retVal       = BSP_OK;
    UINT32 paraNum      = 0;
    UINT32 rfAttParaNum = 0;
    UINT32 realValNum   = 0;
    UINT32 spiFlg       = 0;
    UINT32 spiNo        = 0;
    UINT32 regLoop      = 0;
    T_RfAttInitTbl *pRfAttPara = NULL;
    T_VgaRealValTbl *pRealVal = NULL;
    T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara = NULL;

    retVal |= BspBoardModleGetData(E_FUNCTION_VGA_CTRL_PARA_INIT, 0, 0, (VOID**)(&pVgaCtrlPara), &(paraNum));
    if(NULL != pVgaCtrlPara)
    {
        if (VGA_MODE_AGC == pVgaCtrlPara->uiVgaMode)
        {
            return retVal;
        } 
    }

    retVal |= BspHalAdaptSetVgaMode(VGA_MODE_MANUAL);

    retVal |= BspBoardModleGetData(E_FUNCTION_RF_ATT_REAL_VAL_INIT, 0, 0, (VOID**)(&pRealVal), &(realValNum));
    if(NULL != pRealVal)
    {
        for (spiFlg = 0; spiFlg < realValNum; spiFlg++)
        {
            if (RF_SPI_BUS == pRealVal[spiFlg].spiFlag)
            {
                for (spiNo = 0; spiNo < pRealVal[spiFlg].tblNum; spiNo++)
                {
                    retVal |= BspHalAdaptSetRfBusRealValTab(pRealVal[spiFlg].valTbl[spiNo].spiNo, pRealVal[spiFlg].valTbl[spiNo].realVal, pRealVal[spiFlg].valTbl[spiNo].tblLen);
                    BspSysUsDelay(1000);
                }
            }  
        }
    }

    retVal |= BspBoardModleGetData(E_FUNCTION_RF_ATT_PARA_INIT, 0, 0, (VOID**)(&pRfAttPara), &(rfAttParaNum));
    if(NULL != pRfAttPara)
    {
        for (spiNo = 0; spiNo < rfAttParaNum; spiNo++)
        {
            for (regLoop = 0; regLoop < pRfAttPara[spiNo].rftblLen; regLoop++)
            {
                retVal |= BspHalAdaptSetRfBusAddr(pRfAttPara[spiNo].rfSpiNo, pRfAttPara[spiNo].rfAttTbl[regLoop].difChn, pRfAttPara[spiNo].rfAttTbl[regLoop].addr);
                retVal |= BspHalAdaptSetManualAtt(pRfAttPara[spiNo].rfAttTbl[regLoop].difChn, regLoop);

                dbgInfo("[%s] rfSpiNo'%d,difchan'%d, rfaddr'%d, attValIndex'%d\n",__FUNCTION__,pRfAttPara[spiNo].rfSpiNo,
                pRfAttPara[spiNo].rfAttTbl[regLoop].difChn,pRfAttPara[spiNo].rfAttTbl[regLoop].addr,regLoop);

                BspSysMsDelay(10);
            }
        }
    }
    
    return retVal;
}

/* MgcCmdInfo Init */
UINT32 BspMgcCmdInfoInit(VOID)
{
    UINT32 retVal       = BSP_OK;
    UINT32 paraNum      = 0;
    T_BspHalAdaptVgaJ204CmdPara *tVgaJ204CmdPara = NULL;

    retVal |= BspBoardModleGetData(E_FUNCTION_VGA_CTRL_MGC_CMD_INIT, 0, 0, (VOID**)(&tVgaJ204CmdPara), &(paraNum));
    retVal |= BspHalAdaptInitVgaJ204CmdPara(tVgaJ204CmdPara);

    return retVal;
}

/* VGA控制参数初始化 */
UINT32 BspVgaCfgInit(VOID)
{
    UINT32 retVal     = BSP_OK;
    UINT32 paraNum    = 0;
    UINT32 sheetNum   = 0;
    UINT32 realValNum = 0;
    UINT32 routeNum   = 0;
    UINT32 spiFlg     = 0;
    UINT32 spiNo      = 0;
    UINT32 loop       = 0;
    T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara = NULL;
    T_BspHalAdaptVgaCtrlMgcPara *pVgaCtrlMgcPara = NULL;
    T_BspHalAdaptVgaCompPara *pVgaCompPara = NULL;
    T_MgcSheet *pMgcSheet = NULL;
    T_VgaRealValTbl *pRealVal = NULL;
    T_VgaAddrRoute *pRoute = NULL;
    
    BOARD_MODLE_GET_DATA(E_FUNCTION_VGA_CTRL_PARA_INIT, 0, 0, pVgaCtrlPara, paraNum);
    BOARD_MODLE_GET_DATA(E_FUNCTION_VGA_CTRL_COMP_PARA_INIT, 0, 0, pVgaCompPara, paraNum);

    if (VGA_MODE_AGC == pVgaCtrlPara->uiVgaMode)
    {
        retVal = BspVgaAgcCfgInit(pVgaCtrlPara, pVgaCompPara);
    }

    if (VGA_MODE_MGC == pVgaCtrlPara->uiVgaMode)
    {
        retVal |= BspBoardModleGetData(E_FUNCTION_VGA_REAL_VAL_INIT, 0, 0, (VOID**)(&pRealVal), &(realValNum));
        if(NULL != pRealVal)
        {
            for (spiFlg = 0; spiFlg < realValNum; spiFlg++)
            {
                if (RF_SPI_BUS == pRealVal[spiFlg].spiFlag)
                {
                    for (spiNo = 0; spiNo < pRealVal[spiFlg].tblNum; spiNo++)
                    {
                        retVal |= BspHalAdaptSetRfBusRealValTab(pRealVal[spiFlg].valTbl[spiNo].spiNo, pRealVal[spiFlg].valTbl[spiNo].realVal, pRealVal[spiFlg].valTbl[spiNo].tblLen);
                    }
                } 

                if (IF_SPI_BUS == pRealVal[spiFlg].spiFlag)
                {
                    for (spiNo = 0; spiNo < pRealVal[spiFlg].tblNum; spiNo++)
                    {
                        retVal |= BspHalAdaptSetIfBusRealValTab(pRealVal[spiFlg].valTbl[spiNo].spiNo, pRealVal[spiFlg].valTbl[spiNo].realVal, pRealVal[spiFlg].valTbl[spiNo].tblLen);
                    }
                } 
            }
        }

        retVal |= BspBoardModleGetData(E_FUNCTION_MGC_SHEET_PARA_INIT, 0, 0, (VOID**)(&pMgcSheet), &(sheetNum));
        if(NULL != pMgcSheet)
        {
            for (loop = 0; loop < sheetNum; loop++)
            {
                retVal |= BspHalAdaptSetVgaMgcSheets(pMgcSheet[loop].difChn, pMgcSheet[loop].sheetTab, pMgcSheet[loop].sheetLen);
            }
        }

        retVal |= BspBoardModleGetData(E_FUNCTION_VGA_ADDR_ROUTE_INIT, 0, 0, (VOID**)(&pRoute), &(routeNum));
        if(NULL != pRoute)
        {
            for (spiFlg = 0; spiFlg < routeNum; spiFlg++)
            {
                if (RF_SPI_BUS == pRoute[spiFlg].spiFlag)
                {
                    for (spiNo = 0; spiNo < pRoute[spiFlg].Num; spiNo++)
                    {
                        for (loop = 0; loop < pRoute[spiFlg].route[spiNo].Len; loop++)
                        {
                            retVal |= BspHalAdaptSetRfBusAddr(pRoute[spiFlg].route[spiNo].spiNo, pRoute[spiFlg].route[spiNo].Tbl[loop].difChn, pRoute[spiFlg].route[spiNo].Tbl[loop].addr);
                        }
                    }
                }

                if (IF_SPI_BUS == pRoute[spiFlg].spiFlag)
                {
                    for (spiNo = 0; spiNo < pRoute[spiFlg].Num; spiNo++)
                    {
                        for (loop = 0; loop < pRoute[spiFlg].route[spiNo].Len; loop++)
                        {
                            retVal |= BspHalAdaptSetIfBusAddr(pRoute[spiFlg].route[spiNo].spiNo, pRoute[spiFlg].route[spiNo].Tbl[loop].difChn, pRoute[spiFlg].route[spiNo].Tbl[loop].addr); 
                        }
                    }
                }
            }
        }

        retVal |= BspBoardModleGetData(E_FUNCTION_VGA_CTRL_MGC_PARA_INIT, 0, 0, (VOID**)(&pVgaCtrlMgcPara), &(paraNum));
        if(NULL != pVgaCtrlMgcPara)
        {
            retVal |= BspVgaMgcCfgInit(pVgaCtrlPara, pVgaCtrlMgcPara, pVgaCompPara);
        }
    }
    
    return retVal;
}

UINT32 BspVgaInfoInit(void)
{
    UINT32 retVal     = BSP_OK;
    UINT32 busy    = 0;
    UINT32 busy_count    = 0;
    UINT32 regindex  = 0;
    UINT32 sendData = 0;
    UINT32 paraNum    = 0;
    T_VgaFpgaCtrlInfo *pVgaCtrlPara = NULL;


    BOARD_MODLE_GET_DATA(E_FUNCTION_VGA_FPGACTRL_INIT, 0, 0, pVgaCtrlPara, paraNum);

    BspRegWr(0,REG_FPGASPI_SPI0_CFG_SEL,0,1);
    for(regindex=0; regindex<pVgaCtrlPara->Num; regindex++)
    {
        sendData = 0;
        sendData |= (((pVgaCtrlPara->spireg[regindex].ulAddr>>8)&0x007f)|0x00)<<16;
        sendData |= (pVgaCtrlPara->spireg[regindex].ulAddr&0x00ff)<<8;
        sendData |= (pVgaCtrlPara->spireg[regindex].ulVal);

        dbgInfoEx("send L = 0x%x H = 0x%x \n",(sendData & 0xFFFF),((sendData >> 16) & 0xFFFF));

        BspRegWr(0,REG_FPGASPI_SPI0_START,0,0);
        BspRegWr(0,REG_FPGASPI_SPI0_BITBYTE,0,pVgaCtrlPara->bitnum);/*发送的bit数*/
        BspRegWr(0,REG_FPGASPI_SPI0_DATA_L_WR,0,(sendData & 0xFFFF) );
        BspRegWr(0,REG_FPGASPI_SPI0_DATA_H_WR,0,((sendData >> 16) & 0xFFFF));

        /* wait till busy change to low */
        BspRegRd(0,REG_FPGASPI_SPI0_BUSY,0,&busy);
        while (busy && (busy_count < 100))
        {
            busy_count++;
            dbgInfoEx("fpgaspi %d busy count = %d\n",0,busy_count);
            BspRegRd(0,REG_FPGASPI_SPI0_BUSY,0,&busy);
        }

        BspRegWr(0,REG_FPGASPI_SPI0_START,0,1);

        BspRegRd(0,REG_FPGASPI_SPI0_BUSY,0,&busy);
        while (busy && (busy_count < 1000))
        {
            busy_count++;
            dbgInfoEx("fpgaspi %d busy count = %d\n",0,busy_count);
            BspRegRd(0,REG_FPGASPI_SPI0_BUSY,0,&busy);
        }
        BspRegWr(0,REG_FPGASPI_SPI0_START,0,0);

        BspSysMsDelay(10);
    }
    BspRegWr(0,REG_FPGASPI_SPI0_CFG_SEL,0,0);
    return retVal;
}


UINT32 BspInitOpenLoopPara(VOID)  /*上下行及反馈开环相关参数及接口挂接初始化*/
{
    T_RxOpenLoopPara *para = NULL;
    UINT32 retVal = BSP_OK;
    UINT32 dlParaNum = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_OPENLOOP_PARA_INIT, 0, 0, para, dlParaNum);
    retVal = BspInitTxOpenLoopPara();
    retVal |= BspSetRxOpenLoopPara(para);

    return retVal;
}

/*DTX载波能力上报*/
UINT32 BspDtxAbilitySupport(VOID)
{
    UINT32 retVal = BSP_OK;
    T_RruDtxAbilitySupport *pDtxAbilityInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_DTX_ABILITY_SUPPORT, 0, 0, pDtxAbilityInfo, num);

    retVal = BspSetDtxChkAbility(pDtxAbilityInfo, num);
    return retVal;
}

UINT32 BspChanCenterFreqFlagInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pSupFlag = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_USE_CHAN_DEFAULT_CENTERFREQ_FLAG, 0, 0, pSupFlag, num);

    INPUT_POINTER_CHECK(pSupFlag);

    BspSetChanCenterFreqFlag(*pSupFlag);

    return retVal;
}

UINT32 BspDflOutRangAlmFlagInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pSupAlmFlag = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_DFL_OUT_RANG_ALM_FLAG, 0, 0, pSupAlmFlag, num);

    INPUT_POINTER_CHECK(pSupAlmFlag);

    BspSetDflOutRangFlag(*pSupAlmFlag);

    return retVal;
}

UINT32 BspSfpSelfHealFlagInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pSupFlag = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_SFP_SELF_HEAL_FLAG, 0, 0, pSupFlag, num);

    INPUT_POINTER_CHECK(pSupFlag);

    BspSetSfpSelfHealFlag(*pSupFlag);

    return retVal;
}

/* 通道组初始化 */
UINT32 BspChanGroupInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_ChanGroupInfo *pChanGrpInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_CHAN_GROUP_INIT,0,0,pChanGrpInfo,num);

    retVal = BspSetChanGroupInfo(pChanGrpInfo);
    return retVal;
}

/* 通道组和TDD索引之间的对应关系 */
UINT32 BspChnGrpToTddIdxInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 *pTddCfgIdx = NULL;
    UINT32 num = 0;

    BspSetTddCfgCallBack(BspGetCpeAdvChangeFlag, BspClrCpeAdvChangeFlag);
    BOARD_MODLE_GET_DATA(E_FUNCTION_CHANGRP_TO_TDDIDX_INIT,0,0,pTddCfgIdx,num);

    if(num > MAX_TDD_GROUP_NUM)
    {
        return BSP_ERROR;
    }
    
    retVal = BspChnGrpToTddIdxCfg(pTddCfgIdx, num);
    return retVal;
}

T_ChBndSupInfo s_ChBndSupInfo[128] = {0};

UINT32 BspGetChnBandVal(UINT32 bspchan, UINT32 dir,UINT32 bandno)
{
    UINT32 j = 0;
    UINT32 mapnum = 0;

    mapnum = sizeof(s_ChBndSupInfo)/sizeof(s_ChBndSupInfo[0]);

    for(j=0;j<mapnum;j++)
    {
        if(s_ChBndSupInfo[j].dir != dir)
        {
            continue;
        }

        if(bspchan == s_ChBndSupInfo[j].chan)
        {
            return s_ChBndSupInfo[j].band[bandno];
        }
    }
    return BSP_ERROR;
}

/* Started by AICoder, pid:a40711b17f9b4f4eaad4580c293ecc0d */
VOID BspSetChnBandVal(UINT32 bspchan, UINT32 dir, UINT32 bandno, UINT32 bandVal)
{
    UINT32 loop = 0;
    UINT32 mapnum = 0;

    mapnum = sizeof(s_ChBndSupInfo)/sizeof(s_ChBndSupInfo[0]);

    for(loop = 0; loop < mapnum; loop++)
    {
        if(s_ChBndSupInfo[loop].dir != dir)
        {
            continue;
        }

        if(bspchan == s_ChBndSupInfo[loop].chan)
        {
            s_ChBndSupInfo[loop].band[bandno] = bandVal;
            break;
        }
    }
}
/* Ended by AICoder, pid:a40711b17f9b4f4eaad4580c293ecc0d */

/* 解决特性表中TX和RX频段部队称问题，在初始化流程中更新频段信息 */
UINT32 BspChnFreqBandInfoInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_ChBndSupInfo *pChanFreqBandCfgInfo = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_CHANFREQ_BAND_INIT,0,0,pChanFreqBandCfgInfo,num);
    memcpy_s(s_ChBndSupInfo, sizeof(T_ChBndSupInfo)*num, pChanFreqBandCfgInfo, sizeof(T_ChBndSupInfo)*num);

    retVal = BspSetChnBndSptInfoInit(BspGetChnBandVal);
    return retVal;
}


UINT32 BspInitRxScanPara(T_DPDIC_RXSCAN *pRxScanPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 rxScanChnNum = BspGetRxChannel();

    static UINT32 rxScanInitFlag = 0;
    T_RxScanModule *pRxScanModule = NULL;


    if(rxScanInitFlag == (UINT32)0)
    {
        retVal |= BspInitDpdicRxScanModuleFunc();
        if(retVal != BSP_OK)
        {
            dbgInfo("[%s]Init IcRxScan ModuleFunc Error \n",__FUNCTION__);
            return BSP_ERROR;
        }
        pRxScanModule = (T_RxScanModule *)BspGetRxScanModuleInfo();
        pRxScanModule->rxScanGetTma = BspGetTmaGainByBspChn;
        rxScanInitFlag =1;
    }
    retVal |= BspSetDpdicRxScanParaInfo(rxScanChnNum,pRxScanPara);
    retVal |= BspSetFftWinPara(s_WinCoef, s_WinCoefLen);

    return retVal;
}

/* 接收频谱扫描初始化 */
UINT32 BspInitRxScanInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_DPDIC_RXSCAN *pRxScanPara = NULL;
    UINT32 num = 0;
    double *pdRxHbfCoef = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_RXSCAN_INIT,0,0,pRxScanPara,num);
    retVal |= BspInitRxScanPara(pRxScanPara);
    BOARD_MODLE_GET_DATA(E_FUNCTION_RXSCAN_INIT,0,1,pdRxHbfCoef,num);
    dbgInfo("[%s],: %d\n", __FUNCTION__, num);
    retVal |= BspSetRxHbfCoefCfg(pdRxHbfCoef, num);

   // retVal |= BspRxScanParaReInitCallBack(BspInitRxScanPara); /* 挂接回调，高层可以重复初始化 */
    return retVal;
}

/*功率检测任务初始化*/
UINT32 BspDpdVswrParaInit(VOID)
{
    UINT32 chan = 0;

    for (chan = 0; chan < BspGetTxChannel(); chan++)
    {
        BspDpdVswrEnable(chan, DPD_VSWR_FUNC_SUPPORT);
    }
    BspDpdVswrTblStateCallBackInit(_BspGetDpdVswrLoadState);
    BspSetVectorVswrCallBackInit(BspGetPaVectorVswr);  /*矢量驻波获取接口*/
    BspSetVectorVswrFreqCallBackInit(BspGetVectorVswrFreq);  /*矢量驻波频点获取接口*/
    BspSetVswrModeCallBackInit(BspSetDpdVswrMode);/*离线驻波模式设置接口*/

    return BSP_OK;
}

/*功放保护告警上报和自救处理初始化*/
UINT32 BspPaptReportRecoverInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_J204PairEndsInfo *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_PAPT_REPORT_RECOVER,0,0,pPara,num);
    retVal = BspPaptCheckRecoverInit(pPara);
    return retVal;
}

/*TDD静态调压参数初始化*/
UINT32 BspInitPaPwrVoltCtrl(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    T_PaPwrVoltCtrlPara *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_PA_PWRVOLT_INIT,0,0,pPara,num);
    retVal = BspSetPaPwrVoltCtrl(pPara);
    return retVal;
}

/*REV功率回退保护门限初始化*/
UINT32 BspRevPowProtectInit(void)
{
    UINT32 retVal   = BSP_OK;
    UINT32 num      = 0;
    INT32 *pPara = NULL;
    T_RevProGatePara *pRevGate = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_REV_PROTECT_INIT,0,0,pPara,num);
    retVal |= BspRevPowProtect(pPara,num);

    BOARD_MODLE_GET_DATA(E_FUNCTION_REV_GATE_PARA_INIT,0,0,pRevGate,num);
    retVal |= BspSetRevGatePara(&pRevGate[0]);

    return retVal;
}

#ifndef MULT_PROGRESS_S
/****************************************************************************
*  函数名称   : BspCheckSelfLoop(*)
*  功能描述   : 检查光口是否处于自环状态
*  输入参数   : optSpeed   9.8时进行自适应
*  返 回 值   : BSP_OK
*  其它说明   : 硬件自检使用
*-----------------------------------------------------------------------------*/
UINT32 BspCheckSelfLoop(T_PwrInputAlmThre *almThre)
{
    UINT32 retVal = BSP_OK;
    UINT32 phyPort = 0;

    INPUT_POINTER_CHECK(almThre);
    phyPort = BspGetPhyNoBySfpNo(0);
    retVal |= BspOpenSfpCdr(0,0); /*关闭光模块CDR*/
    BspHalAdaptCpriCfgLineRate(phyPort, BSP_OPT_SPEED_9P8304G);

    dbgInfo("%s: PhyPort = %d uRet =  %d\n",__FUNCTION__, phyPort,retVal);
    if(BspGetOptLoopSta(phyPort) == BSP_OK)
    {
        BspSetOptSelfTestStatus(1);
        optadptoff();
        retVal |= IcHalCpriCfgOptProperty(0,0,1,0);
        retVal |= IcHalCpriInternalLoopback(0,1);
        retVal |= IcHalCpriMidFreqBfnSel(5);
        retVal |= IcHalCpriSetFrTestMode(0,1);
        retVal |= BspNtfLedRunTask();
        BspSetDcTreansAlmThre(almThre[0]);
        BspSetAcAlmThre_100V(almThre[1]);
        BspSetAcAlmThre_110V(almThre[2]);
        BspSetAcAlmThre_220V(almThre[3]);
        BspSetDcAlmThre(almThre[4]);
    }
    else
    {
        BspSetOptSelfTestStatus(0);
    }
    /* 避免9.8G光口速率配置不全，导致自适应异常,清除9.8G所有配置 */
    BspHalAdaptLycaLoadFw(0,phyPort);

    dbgInfo("%s: OptSelfTest = %d \n",__FUNCTION__, BspGetOptSelfTestStatus(0));
    return retVal;
}
#endif

UINT32 BspNtfCfgInit(VOID)
{
    UINT32 retVal       = BSP_OK;
    UINT32 num          = 0;
    T_NtfCfgData *pPara = NULL;

    #ifdef _BSP_WITH_WFS
    return BSP_OK;
    #endif
    
    BOARD_MODLE_GET_DATA(E_FUNCTION_NTF_PARA_INIT,0,0,pPara,num);
	retVal |= BspGetMTSSwitchNtf(pPara->pTest204c);
	retVal |= BspSetAdcStatusMask(pPara->adcStatusMask);
    retVal |= BspSetNtfPowFlag(pPara->ntfPowFlag);
    retVal |= BspSetTssiFwdDiffThreshold(pPara->ntfTssiFwdDiffThreshold);
    retVal |= BspSetNtfVswrStep(pPara->vswrStep);
    retVal |= BspSetNtfScalarVswrThre(pPara->scalarVswrThre);
    
#ifndef MULT_PROGRESS_S
    if(1 == pPara->ntfSupportFlag)
    {
        retVal |= IcHalCpriInternalLoopback(0,0);

        if((0 == BspIsSpecialQsfp(0))&&(BSP_ERROR == BspCheckRruIdVaild(0))&&(BSP_ERROR == BspCheckRruIdVaild(1)))
        {
            retVal |= BspCheckSelfLoop(pPara->almThre);
        }
        dbgInfoEx("%s: AdcMask: %d NtfPowFlag: %d. \n", __FUNCTION__, pPara->adcStatusMask, pPara->ntfPowFlag);
    }
#endif
    return retVal;
}

/* 低噪放关闭后链路增益变化参数初始化 */
UINT32 BspInitLnaOffPara(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_DefLnaOffGain *pLnaPara  = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_LNAOFF_PARA_INIT, 0, 0, pLnaPara, paraNum);
    retVal = BspSetLnaGainPara(pLnaPara, paraNum);

    return retVal;
}

#if 0
UINT32 BspParseTxFreqCfgPara(T_FreqCfgData *pPara, UINT32 *pNum)
{
    UINT32 arraySize     = 0;
    UINT32 ret = 0;
    UINT32 loop = 0;
    cJSON *paraJson = NULL;
    cJSON *root = NULL;
    char *pCfgData = NULL;
    cJSON *cfgItem = NULL;
    cJSON *item = NULL;

    INPUT_POINTER_CHECK(pPara);
    INPUT_POINTER_CHECK(pNum);
    //coverity[cert_str30_c_violation:SUPPRESS]
    ret = BspGetBoardCfgData("FunctionData.json", &pCfgData);
    CHECK_RETVAL_PRN(BspGetBoardCfgData, ret);
    dbgInfoEx("%s>> pCfgData: %s \n", __FUNCTION__, pCfgData);
    root = cJSON_Parse(pCfgData);
    CHECK_CJSON_OBJECT_FREE_MEM("root", root, pCfgData);

    paraJson = cJSON_GetObjectItem(root,"TxFreqCfgPara");
    CHECK_CJSON_OBJECT_FREE_MEM("paraJson", paraJson, pCfgData);

    arraySize = cJSON_GetArraySize(paraJson);
    for(loop = 0; loop < arraySize; loop++)
    {
        cfgItem = cJSON_GetArrayItem(paraJson, loop);

        item = cJSON_GetObjectItem(cfgItem, "chanSelect");
        CHECK_CJSON_OBJECT("chanSelect", item);
        pPara->chanSelect              = item ->valueint;
        
        item = cJSON_GetObjectItem(cfgItem, "ifFreq");
        CHECK_CJSON_OBJECT("ifFreq", item);
        pPara->freqPara.ifFreq              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "loStep");
        CHECK_CJSON_OBJECT("loStep", item);
        pPara->freqPara.loStep              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "ncoStep");
        CHECK_CJSON_OBJECT("ncoStep", item);
        pPara->freqPara.ncoStep              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "cfgSolution");
        CHECK_CJSON_OBJECT("cfgSolution", item);
        pPara->freqPara.cfgSolution              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "ncoSolution");
        CHECK_CJSON_OBJECT("ncoSolution", item);
        pPara->freqPara.ncoSolution              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "defLoFreqKHz");
        CHECK_CJSON_OBJECT("defLoFreqKHz", item);
        pPara->freqPara.defLoFreqKHz              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "defLoFreqKHz0");
        CHECK_CJSON_OBJECT("defLoFreqKHz0", item);
        pPara->freqPara.defLoFreqKHz0              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "IfBw");
        CHECK_CJSON_OBJECT("IfBw", item);
        pPara->freqPara.IfBw              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "dpdRangeLow");
        CHECK_CJSON_OBJECT("dpdRangeLow", item);
        pPara->freqPara.dpdRangeLow              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "dpdRangeHigh");
        CHECK_CJSON_OBJECT("dpdRangeHigh", item);
        pPara->freqPara.dpdRangeHigh              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "loToCarrThre");
        CHECK_CJSON_OBJECT("loToCarrThre", item);
        pPara->freqPara.loToCarrThre              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "loToFilterThre");
        CHECK_CJSON_OBJECT("loToFilterThre", item);
        pPara->freqPara.loToFilterThre              = item ->valueint;
        
        item = cJSON_GetObjectItem(cfgItem, "bandNcoFlag");
        CHECK_CJSON_OBJECT("bandNcoFlag", item);
        pPara->freqPara.bandNcoFlag              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "bandNcoStep");
        CHECK_CJSON_OBJECT("bandNcoStep", item);
        pPara->freqPara.bandNcoStep              = item ->valueint;

        item = cJSON_GetObjectItem(cfgItem, "bandNcoBase");
        CHECK_CJSON_OBJECT("bandNcoBase", item);
        pPara->freqPara.bandNcoBase              = item ->valueint;
    }

    free(root);
    root = NULL;
    free(pCfgData);
    pCfgData = NULL;

    *pNum = arraySize;
    dbgInfoEx("[%s]arraySize %d \n", __FUNCTION__, arraySize);
    return BSP_OK;
}
#endif

UINT32 BspPsyncInterruptInit(VOID)
{
    UINT32 retVal = 0;
    UINT32 psyncInitNo = 255;  /* 中断号 */
    UINT32 timeOffset  = 4200000;  /* 延时 */

    retVal = BspHalPsyncTimGernInit(psyncInitNo, OPT_10MS_TO_NS, timeOffset, OPT_10MS_TO_NS, SWITCH_ON);
    retVal |= BspHalPsyncTimGernInit(psyncInitNo, OPT_10MS_TO_NS, timeOffset, OPT_10MS_TO_NS, SWITCH_OFF);
    retVal |= BspHalAdaptPimPsyncIrqCfg();

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspDpdSetEqCaliParam(*)
 *  功能描述   : EQ功能，向dsp下发TxFwd和FilterGain校准数据
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   : R接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspDpdSetEqCaliParam(VOID)
{
    UINT32 chan = 0;
    UINT32 bandId = 0;
    UINT32 chanNum = 0;
    UINT32 bandNum = 0;
    UINT32 paraNum = 0;
    UINT32 retVal = BSP_OK;
    T_DpdEqData *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_DPD_SET_EQ_INIT, 0, 0, pPara, paraNum);

    if(1 == pPara->supportFlag)
    {
        chanNum = BspGetTxChannel();
        bandNum = BspGetFreqBandCnts(0,TX);
        dbgInfoEx("[%s]:chanNum %d, bandNum %d\n",__FUNCTION__,chanNum,bandNum);

        for(chan = 0; chan < chanNum; chan++)
        {
            for(bandId = 0; bandId < bandNum; bandId++)
            {
                dbgInfoEx("%s:chan %d, bandId %d\n",__FUNCTION__,chan,bandId);
                retVal = BspDpdSetFilterParam(chan,bandId);
                if(BSP_OK != retVal)
                {
                    dbgErr("%s:chan %d, bandId %d FilterGain.txt Send Error !\n",__FUNCTION__,chan,bandId);
                }
                retVal |= BspDpdSetFwdParam(chan,bandId);
                if(BSP_OK != retVal)
                {
                    dbgErr("%s:chan %d, bandId %d TxFwd.txt Send Error !\n",__FUNCTION__,chan,bandId);
                }
            }
        }
    }

    return retVal;
}

UINT32 BspSetRruSpecialFlagInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 num = 0;
    UINT32 flagNum = 0;
    UINT32 rruSpecialFlagInfo[] = {BSP_FU_RU_MTSTEMP_PTX, BSP_FU_RU_PWRLETTEMP_CHECK};
    T_RruSpecialAbilitySetFlag *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_ABILITY_FLAG, 0, 0, pPara, num);

    for(flagNum = 0; flagNum < NELEMENTS(rruSpecialFlagInfo); flagNum++)
    {
        for(loop = 0; loop < num; loop++)
        {
            if(pPara[loop].funcIndex == rruSpecialFlagInfo[flagNum])
            {
                retVal |= pPara[loop].pSpFuncSetFlag(SUPPORT);
            }
        }
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetRruCarrRangeCapInit()
*  功能描述   : RRU支持的载波号范围信息上报初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
*/
UINT32 BspSetRruCarrRangeCapInit(VOID)
{
    UINT32 retVal         = BSP_OK;
    UINT32 num            = 0;
    T_RruFreqIdCaCap *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_RRU_CARR_CAP,0,0,pPara,num);

    retVal |= BspSetRruCarrRangeCapture(&pPara[0]);

    return retVal;
}

/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardadjdrain.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了例化单板的TDD静态调压的接口实现
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2022-011-28 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2022-11-28 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "boardadjdrain.h"
#include "powerctrl_ic4_2.h"
#include "powerctrl_comps_ic4_2.h"
#include "chnmap_a.h"
#include "freqcfgcommon.h"
#include "pa_ic4_2_gridvolt.h"
#include "cfrcommon.h"
#include "rftable.h"
#include "pwr_a.h"
#include "ichaladapt_ic4_2.h"
#include "devdrv_att.h"
#include "dpd_app.h"
#include "chnmap_a.h"
#include "ichaladapt_cfr_ic4_2.h"
#include "cfr_ic4_2.h"

#define DEFAULT_FILTER_GAIN                      ((UINT32) 80)          /* 默认插损值0.8db */
#define DEFAULT_CFR_GATE_PARA                    ((DOUBLE) 1.259)        /* 根据通道功率调整肖峰门限的参数，算法提供*/
#define FILTE_GAIN_DEFAULT             -80
#define PA_DRAIN_SET_FAILED            1<<0                                                 //告警，写入失败

static UINT32 BspSetDrainVoltPerChip(UINT32 index, INT32 volt);

#define PA_SET_BEST_VOLT(bestvolt,getindex,setindex,ppointer)   \
{                                                               \
    INT32 delta = 0;                                                \
    if(BSP_ERROR != BspGetPaBestVolt(getindex,&bestvolt))           \
    {                                                               \
        if(SUPP_REDUCE_PA_VOLT == BspGetReducePaVoltFlag())         \
        {                                                           \
            delta = BspGetPaVoltDelt();                             \
        }                                                           \
        BspSetDrainVoltPerChip(setindex,bestvolt + delta);                           \
        *ppointer = bestvolt + delta;                                       \
    }                                                               \
    else                                                            \
    {                                                               \
        *ppointer = 45000;                                          \
    }                                                               \
}                                                                   \

#define PAVOLTLEVEL_INPUTSW_CHECK(s) \
{                                    \
    if(s > 15)               \
    {                                \
        dbgErr("s: Input Init Para Error.\n");  \
        return BSP_ERROR;            \
    }                                \
}

INT32 g_ulAntPwrPre[TBL_MAX_TX_CHAN_NUM] ={0,};
INT32 g_ulPaVoltPre[TBL_MAX_TX_CHAN_NUM] ={0,}; /* 记录上次配置的漏压  */
UINT32 g_vbiasTypeErr = 0;
static UINT32 glPaVoltStatusWarn = 0;                       //漏压设置与读取失败
pPaGridAdjFunc pGetGridAdjCall = NULL;
static UINT32 s_setPwrIndexFlag_TF = 0;
static T_AdjChanGroupInfo s_adjChanGroupInfo = {0};
static ChanPower s_adjChanPwr[TBL_MAX_TX_CHAN_NUM] = {0}; 
static INT32 s_adjSlavePwr[TBL_MAX_TX_CHAN_NUM] = {0};
ChanPowerGroup tChanPowerGroup = {0};

UINT32 BspSetPwrIndexFlag_TF(VOID)
{
    return s_setPwrIndexFlag_TF = 1;
}
UINT32 BspSetDoublePwrIndexFlag(T_AdjChanGroupInfo *pAdjChanGroupInfo)
{
    INPUT_POINTER_CHECK(pAdjChanGroupInfo);

    memcpy_s(&s_adjChanGroupInfo, sizeof(T_AdjChanGroupInfo), pAdjChanGroupInfo, sizeof(T_AdjChanGroupInfo));

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspPaDrainAdjVoltCfg
 * 功能描述: 静态调压相关
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/

static UINT32 BspSetDrainVoltPerChip(UINT32 index, INT32 volt)
{
    UINT32 retVal = BSP_OK;

    /* t+f单板隔离 */
    if(1 == s_setPwrIndexFlag_TF)
    {
        retVal |= BspSetPwrModulePaVolt(1,volt);
    }
    else
    {
        retVal |= BspSetPwrModulePaVolt(index,volt);
    }
    return retVal;
}

//告警状态清除函数
UINT32 BspSetPaDrainAdjPaVoltWarnClear(VOID)
{
    glPaVoltStatusWarn = 0;//清除所有告警信息
    return BSP_OK;
}

//获取告警状态信息，记录最近一次调压的告警信息，读后会自动清除
UINT32 BspPaDrainAdjSetPaVoltWarnStatus(UINT32 *ulPaVoltSetStatus)
{
    INPUT_POINTER_CHECK(ulPaVoltSetStatus);
    *ulPaVoltSetStatus = glPaVoltStatusWarn ;
    return BSP_OK;
}

static UINT32 BspGetAdjPaPwrMax(UINT32 chanNum,ChanPower pChanPwr[],UINT32 *PaPwrMax,UINT32 *ulchan)
{
    INT32  ulFilterGain[ANT_CHANNEL_NUM_MAX]       = {0};     //滤波器增益
    INT32  ulFilterGainGet[ANT_CHANNEL_NUM_MAX]    = {0};
    UINT32 ulchanIndex = 0;
    UINT32 ulLoop = 0;
    UINT32 chanNo = 0;
    UINT32 ulMaxAntMinusFilter  = 0;
    INPUT_POINTER_CHECK(PaPwrMax);
    INPUT_POINTER_CHECK(ulchan);

    dbgInfoEx("[%s]:Adj Chanel Number = %d\n",__FUNCTION__,chanNum);

    for (ulLoop = 0;ulLoop < chanNum;ulLoop++)
    {
        chanNo = pChanPwr[ulLoop].chanNo;
        if(chanNo >= ANT_CHANNEL_NUM_MAX)
        {
            dbgErr("%s: chanNo'%d >= %d\n", __FUNCTION__,chanNo,ANT_CHANNEL_NUM_MAX);
            return BSP_ERROR;
        }
        if(0x7fffffff == pChanPwr[ulLoop].chanPwr) /*功率无效标志*/
        {
            dbgErr("%s: chanNo'%d power is invalid！\n", __FUNCTION__,pChanPwr[ulLoop].chanNo);
            /*这一行的作用是多个电源下 一个电源的所有通道功率都0x7fffffff 预期 设置默认电压，此时要正确传递此电源对应的一个通道号，没有这行默认传0不一定对*/
            ulchanIndex = pChanPwr[ulLoop].chanNo;   /*这个参数传出去是找电源编号使用 只要是这个通道组的任意通道号都是可以的*/
            continue;
        }
        if (BSP_OK == BspGetFilterGain(chanNo,&ulFilterGain[chanNo]))
        {
            ulFilterGainGet[chanNo] = ulFilterGain[chanNo];
        }
        else
        {
            ulFilterGainGet[chanNo] = FILTE_GAIN_DEFAULT;
        }
        pChanPwr[ulLoop].chanPwr += abs(ulFilterGainGet[chanNo]);
        if (ulMaxAntMinusFilter < pChanPwr[ulLoop].chanPwr)
        {
            ulMaxAntMinusFilter = pChanPwr[ulLoop].chanPwr ;
            ulchanIndex = chanNo;
        }
        dbgInfoEx("[%s]:Filter Gain[%d] Value  = %d\n",__FUNCTION__,chanNo,ulFilterGainGet[chanNo]);
    }
    *PaPwrMax = ulMaxAntMinusFilter;
    *ulchan = ulchanIndex;
    return BSP_OK;
}

static UINT32 BspSetPaAdjVolt(UINT32 index, INT32 ulPaVolt, UINT32 *ulPaDrainVoltGet)
{
    UINT32 iLoop                = 0;
    INT32  ulCurrVolt           = 0;
    UINT32 delay                = 0;
    UINT32 tmpRet               = 0;
    INT32  ulPaVoltGet          = 0;
    UINT32 ulTimesRecord        = 0;     //记录读或者写是否连续三次失败
    INT32 ulPaBestVolt          = 0;
    UINT32 ulDevIndex           = 0;

    if(1 == s_setPwrIndexFlag_TF)
    {
        ulDevIndex = 1;
    }
    else
    {
        ulDevIndex = index;
    }

    BspGetPwrModulePaVol(ulDevIndex,&ulCurrVolt);      //根据当前电压和配置电压来计算延时量，每2V步进需要延时200ms
    delay = min(abs(ulPaVolt-ulCurrVolt)/2000, 6);
    for(iLoop = 0;iLoop < 3 ;iLoop ++)      //最多设置三次
    {
        tmpRet = BspSetDrainVoltPerChip(index, ulPaVolt);
        BspSysMsDelay(delay*200);

        tmpRet |= BspGetPwrModulePaVol(ulDevIndex,&ulPaVoltGet);
        if((BSP_OK != tmpRet)||(abs(ulPaVoltGet - ulPaVolt) > 1200))
        {
            ulTimesRecord ++;
        }
        else
        {
            break;
        }
    }
    if (3 == ulTimesRecord)
    {
        dbgErr("[%s]:Pa Volt Set Value Wrong !\n",__FUNCTION__);
        glPaVoltStatusWarn |= PA_DRAIN_SET_FAILED;
        PA_SET_BEST_VOLT(ulPaBestVolt,0,index,ulPaDrainVoltGet);
    }
    else
    {
        *ulPaDrainVoltGet = ulPaVolt;
         dbgInfoEx("[%s]:Hope To Set Value is %d (mv)\n",__FUNCTION__,*ulPaDrainVoltGet);
    }
    return BSP_OK;
}

//离线表中获取漏压值
static UINT32 BspGetPaEnSaveAdjVds(UINT32 parLevel, UINT32 powerLevel, INT32 *paVolt,UINT32 chanNo)
{
    UINT32 loop  = 0;
    UINT32 level = PA_ENERGY_SAVING_ADJ_MAX_LEVEL;
    UINT32 combiLevel = parLevel;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    UINT32 tblIndex = 0;
    UINT32 tblChn = chanNo;

    BspUpdateRfTblIndexAndChn(chanNo, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(paVolt);


    if (combiLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL)
    {
        return BSP_ERROR;
    }
    for(loop = 0; loop < PA_ENERGY_SAVING_ADJ_MAX_COMBI; loop++)
    {
        if ((parLevel == ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[combiLevel].combiList[loop][0]) &&
            (powerLevel == ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[combiLevel].combiList[loop][1]))
        {
            level =  ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[combiLevel].combiList[loop][2];
        }
    }
    if ((level >= ptEnSavAdjData->tEnSavAdjHeader.vdsNum) || (level >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        return BSP_ERROR;
    }
    else
    {
        *paVolt = ptEnSavAdjData->atEnSavAdjPath[tblChn].vdsLevel[level];
        return BSP_OK;
    }
}

/* Started by AICoder, pid:k9e74pd130e161f14a820b057042cb15dce7924c */
static UINT32 BspGetPaMaxDrainVolt(UINT32 chan,INT32 *paVolt)
{
    INT32 delta    = 0;
    INT32 bestvolt = 0;

    INPUT_POINTER_CHECK(paVolt);
    if(BSP_ERROR != BspGetPaBestVolt(chan,&bestvolt))
    {
        if(SUPP_REDUCE_PA_VOLT == BspGetReducePaVoltFlag())
        {
            delta = BspGetPaVoltDelt();
        }

        *paVolt = bestvolt + delta;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:k9e74pd130e161f14a820b057042cb15dce7924c */

//由最大通道的功率索引powerLevel，获取parLevelfreqLevel，dataIndex并保存
static UINT32 BspGetPaDrainChanLevel(UINT32 chanNum,ChanPower pChanPwr[],INT32 *paVolt)
{
	UINT32 ulLoop        = 0;
    UINT32 chanNo        = 0;
	UINT32 freq          = 0;
    UINT32 parLevel      = 0;
    UINT32 powerLevel    = 0;
    UINT32 freqLevel     = 0;
    UINT32 dataIndex     = 0;
    UINT32 pwrAvgRat     = 0;
    INT32 paMaxDrainVolt = 0;  //最大漏压值
    UINT32 powerMaxLevel = 0;  //对应功率索引
    UINT32 tmpRet        = BSP_OK;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    UINT32 tblIndex = 0;
    UINT32 tblChn = 0;
    INT32 bestvolt = 0;
    INT32 delt = 0;
    UINT32 retVal = BSP_OK;
    UINT32 flag          = 0;

    INPUT_POINTER_CHECK(pChanPwr);

    BspUpdateRfTblIndexAndChn(pChanPwr[0].chanNo, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);

    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    //只有初始化，没有从文件读取值
    if((0 == ptEnSavAdjData->tEnSavAdjHeader.parNum) ||(0 == ptEnSavAdjData->tEnSavAdjHeader.freqNum )
      ||
      (0 == ptEnSavAdjData->tEnSavAdjHeader.powerNum)||(0 == ptEnSavAdjData->tEnSavAdjHeader.vdsNum))
    {
        return BSP_ERROR;
    }



	(void)BspGetPwrAverageRatio(&pwrAvgRat);
	for (ulLoop = 0;ulLoop < chanNum;ulLoop++)
	{
        chanNo = pChanPwr[ulLoop].chanNo;
        if(chanNo >= ANT_CHANNEL_NUM_MAX)
        {
            dbgErr("%s: chanNo'%d >= %d\n", __FUNCTION__,chanNo,ANT_CHANNEL_NUM_MAX);
            return BSP_ERROR;
        }
        if(0x7fffffff == pChanPwr[ulLoop].chanPwr) /*功率无效标志*/
        {
            dbgErr("%s: chanNo'%d power is invalid！\n", __FUNCTION__,chanNo);
            continue;
        }
        flag        = 1;  /*功率有效标志*/
	    parLevel    = BspGetParLevelByFile(pwrAvgRat,chanNo);
	    powerLevel  = BspGetPowerLevelByFile(pChanPwr[ulLoop].chanPwr,chanNo);
	    tmpRet      = BspGetPaEnSaveAdjVds(parLevel,powerLevel,paVolt,chanNo);

        if(SUPP_REDUCE_PA_VOLT == BspGetReducePaVoltFlag())
        {
            retVal = BspGetPaBestVolt(ulLoop, &bestvolt);
            if(BSP_OK == retVal)
            {
                delt = BspGetPaVoltDelt();
                bestvolt += delt;
                if(*paVolt > bestvolt)
                {
                    *paVolt = bestvolt;
                }
            }
        }
	    if(paMaxDrainVolt < *paVolt)
	    {
	        paMaxDrainVolt = *paVolt;
	        powerMaxLevel  = powerLevel;
	    }
	}
	/* Started by AICoder, pid:acad9p6d20a48fe140c10a113029ad06e877b7fb */
    if((0 == flag)&&(0 != chanNum))/*所有通道功率无效*/
    {
        BspGetPaMaxDrainVolt(pChanPwr[0].chanNo, &paMaxDrainVolt);
        *paVolt = paMaxDrainVolt;
        dbgInfo("[%s]:Power of all chan is invalid,bestvolt is %d (mv)\n",__FUNCTION__,*paVolt);
        return BSP_OK;
    }
    /* Ended by AICoder, pid:acad9p6d20a48fe140c10a113029ad06e877b7fb */
	/*功率有效且漏压获取失败，无PaEnergySavingAdj.txt离线参数文件*/
	if(paMaxDrainVolt == 0)
	{
	    return BSP_ERROR;
	}

	for (ulLoop = 0;ulLoop < chanNum;ulLoop++)
	{
        chanNo = pChanPwr[ulLoop].chanNo;
	    freq        = BspGetMultiCarrCenterFreq(TX, chanNo);
	    parLevel    = BspGetParLevelByFile(pwrAvgRat,chanNo);
//	    powerLevel  = BspGetPowerLevelByFile(pChanPwr[ulLoop].chanPwr,ulLoop);
	    freqLevel   = BspGetFreqLevelByFile(freq,chanNo);
	    dataIndex   = BspGetCombiIndex(parLevel, powerMaxLevel, freqLevel,chanNo);  //powerLevel
	    BspSetPaVibasNewIndex(chanNo, parLevel, dataIndex);
	}
	*paVolt = paMaxDrainVolt;

	return tmpRet;
}

static UINT32 BspGetPaDrainChanPwrByChanMask(UINT32 chanMask,UINT32 chanNum,ChanPower pChanPwr[],UINT32 *maskChanNum)
{
    UINT32 ulLoop               = 0;
    UINT32 chanNo               = 0;
    UINT32 i                    = 0;
    UINT32 chNum                = 0;
    UINT32 maxTxChn   = BspGetTxChannel();
    UINT32 maskLimit  = BIT_SET(maxTxChn);

    INPUT_POINTER_CHECK(pChanPwr);
    INPUT_POINTER_CHECK(maskChanNum);
    if((chanNum < 1) || (chanNum > maxTxChn))
    {
        dbgErr("%s: chanNum >= 1 && chanNum <= %d\n", __FUNCTION__, maxTxChn);
        return BSP_ERROR;
    }
       
    if (chanMask >= maskLimit)
    {
        dbgErr("%s input mask'%#x overload!\n", __FUNCTION__, chanMask);
        return BSP_ERROR;
    }

    for (ulLoop=0; ulLoop < chanNum; ulLoop++)
        {       
            chanNo = pChanPwr[ulLoop].chanNo; 
            if (((0x1 << chanNo) & chanMask) && (i < TBL_MAX_TX_CHAN_NUM)) 
            {
                s_adjChanPwr[i].chanNo = pChanPwr[ulLoop].chanNo; 
                s_adjChanPwr[i].chanPwr = pChanPwr[ulLoop].chanPwr;
                dbgInfoEx("ChanMask =%d ChanNo =%d ChanPow = %d \n",chanMask,s_adjChanPwr[i].chanNo,s_adjChanPwr[i].chanPwr);
                i++;
                chNum++;
            }
        }
    *maskChanNum = chNum;

    return BSP_OK;
}

UINT32 BspCfgPaDrainVoltByChanPower(UINT32 chanNum, ChanPower pChanPwr[])
{
    UINT32 ulPaPwrMax           = 0;
    INT32  ulPaVolt             = 0;
    UINT32 ulPaDrainVoltGet     = 0;
    UINT32 ulchan               = 0;
    UINT32 chanNo               = 0;   
    UINT32 ulLoop               = 0;
    UINT32 chanmask             = 0;
    UINT32 chNum                = 1;
    UINT32 maxTxChn   = BspGetTxChannel();
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pChanPwr);

    dbgInfoEx("[%s] ChanNum =%d\n",__func__,chanNum);

    for (ulLoop = 0;ulLoop < chanNum;ulLoop++)
    {
        chanNo = pChanPwr[ulLoop].chanNo;        //调试用
        TBL_CHAN_VALID_CHECK(ulLoop);
        s_adjSlavePwr[ulLoop] = pChanPwr[ulLoop].chanPwr;
        dbgInfoEx("[%s] ChanNo =%d ChanPow = %d \n",__func__,chanNo,pChanPwr[ulLoop].chanPwr);
    }

    if((chanNum < 1) || (chanNum > maxTxChn))
    {
        dbgErr("%s: chanNum >= 1 && chanNum <= %d\n", __FUNCTION__, maxTxChn);
        return BSP_ERROR;
    }

    BspSetPaDrainAdjPaVoltWarnClear();   //清除告警状态
    if(s_adjChanGroupInfo.s_dualPwrFlag == 1)
    {
        for(ulLoop = 0;ulLoop < s_adjChanGroupInfo.pwrNum; ulLoop++ )
        {
            chanmask = s_adjChanGroupInfo.adjChanGroupMask[ulLoop];
            BspGetPaDrainChanPwrByChanMask(chanmask,chanNum,pChanPwr,&chNum);
            dbgInfoEx("[%s]ChanMask=0x%x ChanNum%d\n",__func__,chanmask,chNum);
            //获取小区功率，并计算单天线通道最大输出功率
            //单天线最大输出功率减滤波器增益作为PA最大输出功率
            BspGetAdjPaPwrMax(chNum,s_adjChanPwr,&ulPaPwrMax,&ulchan);
            dbgInfoEx("[%s]GetPaPwrMax=%d is chan%d\n",__func__,ulPaPwrMax,ulchan);

            if(BSP_OK == BspGetPaDrainChanLevel(chNum,s_adjChanPwr,&ulPaVolt))
            {
                BspSetPaAdjVolt(ulchan, ulPaVolt, &ulPaDrainVoltGet);
                dbgInfoEx("[%s] ChanMask:0x%x Get The Final Value = %d (mv)\n",__func__,chanmask,ulPaDrainVoltGet);
                dbgInfoEx("[%s]*********PaEnergySavingAdj.txt load successful !!!!**********\n",__FUNCTION__);
            }

            memset_s(s_adjChanPwr, sizeof(s_adjChanPwr), 0, sizeof(s_adjChanPwr));
        }
        return BSP_OK;
    }
    else if(s_adjChanGroupInfo.s_dualPwrFlag == 2)   /*子母端机型*/
    {
        for(ulLoop = 0;ulLoop < s_adjChanGroupInfo.pwrNum; ulLoop++ )
        {
            chanmask = s_adjChanGroupInfo.adjChanGroupMask[ulLoop];
            BspGetPaDrainChanPwrByChanMask(chanmask,chanNum,pChanPwr,&chNum);
            dbgInfoEx("[%s]ChanMask=0x%x ChanNum%d\n",__func__,chanmask,chNum);
            //获取小区功率，并计算单天线通道最大输出功率
            //单天线最大输出功率减滤波器增益作为PA最大输出功率
            BspGetAdjPaPwrMax(chNum,s_adjChanPwr,&ulPaPwrMax,&ulchan);
            dbgInfoEx("[%s]GetPaPwrMax=%d is chan%d\n",__func__,ulPaPwrMax,ulchan);

            IF_CHK(BSP_OK == BspGetPaDrainChanLevel(chNum,s_adjChanPwr,&ulPaVolt))
            {
                IF_CHK(0 == s_adjChanGroupInfo.pwrType[ulLoop])
                {
                    BspSetPaAdjVolt(ulchan, ulPaVolt, &ulPaDrainVoltGet);
                }
                ELSE   /*设置子端漏压 同时传递电压值给dsp*/
                {
                   for(loop = 0; loop < chNum; loop++)
                   {
                        BspDpdSetSscVoltGrdCfg(s_adjChanPwr[loop].chanNo,ulPaVolt);
                   }
                   if(LINK_REMOTE == BspIsRemoteSlaveChan(s_adjChanPwr[0].chanNo, 1))   /*子端建链才配置*/
                   {
                        BspSlavePortPaVolt(s_adjChanPwr[0].chanNo, ulPaVolt);  /*不给高层上报失败 否则cfr txatt 漏压更新流程高层不会执行 漏压失败通过子端重新上电流程纠正*/
                   }
                }
                dbgInfoEx("[%s] ChanMask:0x%x Get The Final Value = %d (mv)\n",__func__,chanmask,ulPaVolt);
                dbgInfoEx("[%s]*********PaEnergySavingAdj.txt load successful !!!!**********\n",__FUNCTION__);
            }

            memset_s(s_adjChanPwr, sizeof(s_adjChanPwr), 0, sizeof(s_adjChanPwr));
        }
        return retVal;
    }
    else
    {
        //获取小区功率，并计算单天线通道最大输出功率
        //单天线最大输出功率减滤波器增益作为PA最大输出功率
        BspGetAdjPaPwrMax(chanNum,pChanPwr,&ulPaPwrMax,&ulchan);
        dbgInfoEx("[%s]GetPaPwrMax=%d is chan%d\n",__func__,ulPaPwrMax,ulchan);

        if(BSP_OK == BspGetPaDrainChanLevel(chanNum,pChanPwr,&ulPaVolt))
        {
            BspSetPaAdjVolt(0,ulPaVolt, &ulPaDrainVoltGet);
            dbgInfoEx("[%s]Get The Final Value = %d (mv)\n",__func__,ulPaDrainVoltGet);
            dbgInfoEx("[%s]*********PaEnergySavingAdj.txt load successful !!!!**********\n",__FUNCTION__);
            return BSP_OK;
        }
    }
    
    dbgInfoEx("[%s]*********PaEnergySavingAdj.txt load failed !!!!**********\n",__FUNCTION__);
    return BSP_ERROR;
}

/*9124 子端重启之后 漏压恢复成默认值 需要按复位前预期的调压值设置  否则调压增益和实际电压对不上 影响TX插损 不能存电压 换子端包不住*/
/* Started by AICoder, pid:ea6b0c47d68d44c2aa4c57d1db361822 */
UINT32 BspCheckAndReCfgSlavePaVolt(UINT32 chan)
{
    INT32 paVolt = 0;
    UINT32 retVal = BSP_OK;
    UINT32 chanmask = 0x0;   /*一个子端固定是2个通道*/
    UINT32 anotherChan = 0;
    UINT32 chNum = 2;
    UINT32 paPwrMax = 0;
    UINT32 maxPwrChan = 0;
    ChanPower tmpadjChanPwr[2]= {0};   /*不能用全局变量 各个子端之间没法保证互斥*/

    retVal = BspGetAnotherSlaveChnByBspChn(chan, TX, &anotherChan);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    TBL_CHAN_VALID_CHECK(chan);
    TBL_CHAN_VALID_CHECK(anotherChan);
    if((0 == s_adjSlavePwr[chan])||(0 == s_adjSlavePwr[anotherChan]))
    {
        return BSP_OK;  /*还没调压过 不需要后续流程*/
    }
    chanmask = (BIT_SET(chan)|BIT_SET(anotherChan));
    tmpadjChanPwr[0].chanNo = chan;
    tmpadjChanPwr[0].chanPwr = s_adjSlavePwr[chan];
    tmpadjChanPwr[1].chanNo = anotherChan;
    tmpadjChanPwr[1].chanPwr = s_adjSlavePwr[anotherChan];
    dbgInfoEx("[%s]ChanMask=0x%x ChanNum%d\n",__func__,chanmask,chNum);
    //获取小区功率，并计算单天线通道最大输出功率
    //单天线最大输出功率减滤波器增益作为PA最大输出功率
    BspGetAdjPaPwrMax(chNum,tmpadjChanPwr,&paPwrMax,&maxPwrChan);
    dbgInfoEx("[%s]GetPaPwrMax=%d is chan%d\n",__func__,paPwrMax,maxPwrChan);

    if(BSP_OK == BspGetPaDrainChanLevel(chNum,tmpadjChanPwr,&paVolt))
    {
         if(LINK_REMOTE == BspIsRemoteSlaveChan(tmpadjChanPwr[0].chanNo, 1))   /*子端建链才配置*/
         {
             retVal |= BspSlavePortPaVolt(tmpadjChanPwr[0].chanNo, paVolt);
         }
    }

    return retVal;
}
/* Ended by AICoder, pid:ea6b0c47d68d44c2aa4c57d1db361822 */


//测试函数
UINT32 bspadjvolttest(UINT32 ulCtrlVal,UINT32 ulCtrlVal1,UINT32 ulCtrlVal2,UINT32 ulCtrlVal3)
{
    ChanPower ChanPwr[4] = {0};
    UINT32 ulLoop           = 0; 

    for(ulLoop = 0; ulLoop < 4; ulLoop++)
    {
        ChanPwr[ulLoop].chanNo = ulLoop;
    }

    ChanPwr[0].chanPwr = ulCtrlVal;
    ChanPwr[1].chanPwr = ulCtrlVal1;
    ChanPwr[2].chanPwr = ulCtrlVal2;
    ChanPwr[3].chanPwr = ulCtrlVal3;
    BspCfgPaDrainVoltByChanPower(4, ChanPwr);
    return BSP_OK;
}

static UINT32 bspadjvolttest_2T(UINT32 ulCtrlVal,UINT32 ulCtrlVal1)
{
    ChanPower ChanPwr[2] = {0,};
    UINT32 ulLoop           = 0; 

    for(ulLoop = 0; ulLoop < 2; ulLoop++)
    {
        ChanPwr[ulLoop].chanNo = ulLoop;
    }

    ChanPwr[0].chanPwr = ulCtrlVal;
    ChanPwr[1].chanPwr = ulCtrlVal1;
    BspCfgPaDrainVoltByChanPower(2, ChanPwr);
    return BSP_OK;
}


UINT32 printGetCfrGatePara(UINT32 chan)
{
    UINT32 ret        = BSP_OK;
    UINT32 loop       = 0;
    UINT32 dir        = 1;
    UINT32 difChipId  = 0;
    UINT32 difChn     = 0;
    UINT32 Freqband   = 0;
    UINT32 cfrGate[E_CFR_THR_NUM]  = {0};

    ret |= BspGetDifInfoByBspChn(chan,dir, &difChipId, &difChn);
    ret |= IcHalApiGetCfrGate(difChn,Freqband, cfrGate,E_CFR_THR_NUM);
    if(BSP_OK != ret)
    {
        dbgInfo("[%s]:Set Cfr Gate Failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("---------chan %d--------\n",chan);
    for(loop = 0;loop< 3; loop++)
    {
        dbgInfo("Get cfrGate[%d] = %d\n",loop,cfrGate[loop]);
    }
    return ret;
}

/*****************************************************************************
*  函数名称: BspSetDefaultCfrGate
*  功能描述: 设置默认cfg削峰门限
*  输入参数:
*  输出参数: 无
*  返 回 值: BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
******************************************************************************/
UINT32 BspSetDefaultCfrGate(UINT32 chan)
{
    UINT32 dir        = 1;
    UINT32 difChn     = 0;
    UINT32 difChipId  = 0;
    UINT32 retVal     = BSP_OK;
    UINT32 freqband   = 0;
    UINT32 cfrGate[E_CFR_THR_NUM]  = {0, 0, 0};

    retVal |= BspGetDifInfoByBspChn(chan,dir, &difChipId, &difChn);
    retVal |= BspGetCfrGatePara(difChn, cfrGate);
    dbgInfoEx("difChn = %d cfrGate[0] = %d cfrGate[1] = %d cfrGate[2] = %d \n" ,difChn,cfrGate[E_CFR_THR_1ST],cfrGate[E_CFR_THR_2ND],cfrGate[E_CFR_THR_3RD]);
    retVal |= IcHalApiSetCfrGate(difChn,freqband,cfrGate,E_CFR_THR_NUM);
    if(BSP_OK != retVal)
    {
        dbgInfo("[%s]:Set Cfr Gate Failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return retVal;
}

UINT32 BspGetCurrCfrGate(UINT32 chanNo, UINT32 currChanPwrDbm, UINT32 *pDefCfrGate, UINT32 *pCurrCfrGate)
{
    DOUBLE cfrGateTmp  = 0.0;
    INT32  chanPaPwrMw = 0;
    INT32  pwrLevelMw  = 0;
    UINT32 loop        = 0;
    DOUBLE tmpValue    = 0.0;
    UINT32 ret         = BSP_OK;

    INPUT_POINTER_CHECK(pDefCfrGate);
    INPUT_POINTER_CHECK(pCurrCfrGate);

    ret = BspGetChanPaPowerByFile(chanNo, &chanPaPwrMw);
    CHECK_RETVAL(BspGetChanPaPowerByFile, ret);
    dbgInfoEx("%s: chanNo = %d, currChanPwrDbm = %d, chanPaPwrMw = %d \n", __FUNCTION__, chanNo, currChanPwrDbm, chanPaPwrMw);

    ret |= BspGetPowerUpByFile(currChanPwrDbm, chanNo, &pwrLevelMw);
    if (chanPaPwrMw != 0 && pwrLevelMw != 0)
    {
        /***此处为CERT FLP32-C误告警，如下抑制告警***/
        //coverity[cert_flp32_c_violation:SUPPRESS]
        tmpValue = sqrt(DEFAULT_CFR_GATE_PARA*(DOUBLE)pwrLevelMw/(DOUBLE)chanPaPwrMw);
        dbgInfoEx("%s: DEFAULT_CFR_GATE_PARA = %f, pwrLevelMw = %d, chanPaPwrMw = %d, tempValue = %f\n",
            __FUNCTION__, DEFAULT_CFR_GATE_PARA, pwrLevelMw, chanPaPwrMw, tmpValue);
    }

    for(loop = 0; loop < (UINT32)E_CFR_THR_NUM; loop++)
    {
        cfrGateTmp = pDefCfrGate[loop] * tmpValue;
        dbgInfoEx("%s: cfrGateTmp = %f, pDefCfrGate[%d] = %d, tmpValue = %f\n",
                __FUNCTION__, cfrGateTmp, loop, pDefCfrGate[loop], tmpValue);

        /***此处为CERT FLP34-C误告警，如下抑制告警***/
        //coverity[cert_flp34_c_violation:SUPPRESS]
        if((UINT32)cfrGateTmp > pDefCfrGate[loop])
        {
            pCurrCfrGate[loop] = pDefCfrGate[loop];
        }
        else if((UINT32)cfrGateTmp < (pDefCfrGate[loop]/2))
        {
            pCurrCfrGate[loop] = pDefCfrGate[loop]/2;
        }
        else
        {
            pCurrCfrGate[loop] = (UINT32)cfrGateTmp;
        }
        dbgInfoEx("%s: pCurrCfrGate[%d] = %d, cfrtemp = %f\n", __FUNCTION__, loop, pCurrCfrGate[loop], cfrGateTmp);
    }

    return ret;
}

UINT32 BspGetCurrCfrGateByLevel(UINT32 chanNo, UINT32 level, UINT32 currChanPwrDbm, UINT32 *pDefCfrGate, UINT32 *pCurrCfrGate)
{
    DOUBLE cfrGateTmp  = 0.0;
    INT32  chanPaPwrMw = 0;
    INT32  pwrLevelMw  = 0;
    UINT32 loop        = 0;
    DOUBLE tmpValue    = 0.0;
    UINT32 ret         = BSP_OK;

    INPUT_POINTER_CHECK(pDefCfrGate);
    INPUT_POINTER_CHECK(pCurrCfrGate);

    ret = BspGetChanPaPowerByFile(chanNo, &chanPaPwrMw);
    CHECK_RETVAL(BspGetChanPaPowerByFile, ret);
    dbgInfoEx("%s: chanNo = %d, currChanPwrDbm = %d, chanPaPwrMw = %d \n", __FUNCTION__, chanNo, currChanPwrDbm, chanPaPwrMw);

    ret |= BspGetPowerUpByFileByLevel(currChanPwrDbm, chanNo, level, &pwrLevelMw);
    if (chanPaPwrMw != 0 && pwrLevelMw != 0)
    {
        /***此处为CERT FLP32-C误告警，如下抑制告警***/
        //coverity[cert_flp32_c_violation:SUPPRESS]
        tmpValue = sqrt(DEFAULT_CFR_GATE_PARA*(DOUBLE)pwrLevelMw/(DOUBLE)chanPaPwrMw);
        dbgInfoEx("%s: DEFAULT_CFR_GATE_PARA = %f, pwrLevelMw = %d, chanPaPwrMw = %d, tempValue = %f\n",
            __FUNCTION__, DEFAULT_CFR_GATE_PARA, pwrLevelMw, chanPaPwrMw, tmpValue);
    }

    for(loop = 0; loop < (UINT32)E_CFR_THR_NUM; loop++)
    {
        cfrGateTmp = pDefCfrGate[loop] * tmpValue;
        dbgInfoEx("%s: cfrGateTmp = %f, pDefCfrGate[%d] = %d, tmpValue = %f\n",
                __FUNCTION__, cfrGateTmp, loop, pDefCfrGate[loop], tmpValue);

        /***此处为CERT FLP34-C误告警，如下抑制告警***/
        //coverity[cert_flp34_c_violation:SUPPRESS]
        if((UINT32)cfrGateTmp > pDefCfrGate[loop])
        {
            pCurrCfrGate[loop] = pDefCfrGate[loop];
        }
        else if((UINT32)cfrGateTmp < (pDefCfrGate[loop]/2))
        {
            pCurrCfrGate[loop] = pDefCfrGate[loop]/2;
        }
        else
        {
            pCurrCfrGate[loop] = (UINT32)cfrGateTmp;
        }
        dbgInfoEx("%s: pCurrCfrGate[%d] = %d, cfrtemp = %f\n", __FUNCTION__, loop, pCurrCfrGate[loop], cfrGateTmp);
    }

    return ret;
}

/*****************************************************************************
*  函数名称: BspGetPaChanPwrDbm
*  功能描述: 高层下发天线口功率，减去滤波插损值获取功放功率
*  输入参数: chanNo：通道索引，currChanPwrMw：高层下发功率
*  输出参数: currChanPwrDbm：功放功率
*  返 回 值: BSP_OK
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
******************************************************************************/
UINT32 BspGetPaChanPwrDbm(UINT32 chanNo, UINT32 currChanPwrMw, UINT32 *currChanPwrDbm)
{
    INT32  filterGainDbm   = 0;

    /***此处为CERT FLP34-C和CERT INT31-C误告警，如下抑制告警***/
    //coverity[cert_flp34_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]
    *currChanPwrDbm = (UINT32)mwTodbm(currChanPwrMw);
    dbgInfoEx("%s: currlChanPwrDbm_1 = %d, currChanPwrMw_1 = %d\n", __FUNCTION__, *currChanPwrDbm, currChanPwrMw);

    /*从FilterGain.txt获取滤波插损值*/
    if (BSP_OK == BspGetFilterGain(chanNo, &filterGainDbm))
    {
        dbgInfoEx("%s:chanNo = %d, filterGainDbm = %d\n", __FUNCTION__, chanNo, filterGainDbm);
    }
    else
    {
        filterGainDbm = DEFAULT_FILTER_GAIN; /*无FileterGain.txt文件默认0.8db*/
        dbgInfoEx("%s: no FilterGain.txt, chanNo = %d, filterGainDbm = %d\n", __FUNCTION__, chanNo,filterGainDbm);
    }

    /***此处为CERT INT30-C误告警，如下抑制告警***/
    //coverity[cert_int30_c_violation:SUPPRESS]
    *currChanPwrDbm += abs(filterGainDbm);
    dbgInfoEx("%s: currlChanPwrDbm_2 = %d, filterGainDbm = %d\n", __FUNCTION__, *currChanPwrDbm, filterGainDbm);

    return BSP_OK;
}

UINT32 BspCfgCfrGateByChanPower(UINT32 chanNum, ChanPower pChanPwr[])
{
    UINT32 dir        = TX;
    UINT32 difChn     = 0;
    UINT32 difChipId  = 0;
    UINT32 ret        = BSP_OK;
    UINT32 index      = 0;
    UINT32 chanNo     = 0;
    UINT32 freqBand   = 0;
    UINT32 currChanPwrMw  = 0;
    UINT32 currChanPwrDbm = 0;
    UINT32 defCfrGate[E_CFR_THR_NUM] = {0, 0, 0};
    UINT32 curCfrGate[E_CFR_THR_NUM] = {0, 0, 0};

    INPUT_POINTER_CHECK(pChanPwr);

    for(index = 0;index < chanNum;index++)
    {
        chanNo = pChanPwr[index].chanNo;
        currChanPwrMw = pChanPwr[index].chanPwr;

        ret = BspGetDifInfoByBspChn(chanNo, dir, &difChipId, &difChn);
        CHECK_RETVAL(BspGetDifInfoByBspChn, ret);
        ret = BspGetCfrGatePara(difChn, defCfrGate);
        CHECK_RETVAL(BspGetCfrGatePara, ret);
        dbgInfoEx("index = %d, chan = %d, difChn = %d, cfrGate1 = %d, cfrGate2 = %d, cfrGate3 = %d\n",
                index, chanNo, difChn, defCfrGate[E_CFR_THR_1ST], defCfrGate[E_CFR_THR_2ND], defCfrGate[E_CFR_THR_3RD]);
        ret = BspGetPaChanPwrDbm(chanNo, currChanPwrMw, &currChanPwrDbm);
        CHECK_RETVAL(BspGetPaChanPwrDbm, ret);
        ret = BspGetCurrCfrGate(chanNo, currChanPwrDbm, defCfrGate, curCfrGate);
        CHECK_RETVAL(BspGetCurrCfrGate, ret);
        ret = BspHalAdaptSetCfrGate(difChn,freqBand, curCfrGate, E_CFR_THR_NUM);
        CHECK_RETVAL(BspHalAdaptSetCfrGate, ret);
        ret = BspSetCfrGateCfg(difChn, E_CFR_THR_NUM, curCfrGate);
        CHECK_RETVAL(BspSetCfrGateCfg, ret);
        ret = printGetCfrGatePara(chanNo);
        CHECK_RETVAL(printGetCfrGatePara, ret);
    }
    return ret;
}

static UINT32 bspsetcfrgatetest_2T(INT32 ulPwrVal)
{
    ChanPower pChanPwrTest[2] = {0};
    UINT32 chanLoop           = 0;
    UINT32 ret                = BSP_OK;

    for (chanLoop = 0;chanLoop < 2;chanLoop++)
    {
        pChanPwrTest[chanLoop].chanNo  = chanLoop;
        pChanPwrTest[chanLoop].chanPwr = ulPwrVal;
    }
    ret = BspCfgCfrGateByChanPower(2,pChanPwrTest);

    if(ret != BSP_OK)
    {
        dbgInfo("[%s]:Cfg Cfr Gate By Chan Power Failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

static UINT32 bspsetcfrgatetest_4T(UINT32 ulCtrlVal,UINT32 ulCtrlVal1,UINT32 ulCtrlVal2,UINT32 ulCtrlVal3)
{
    ChanPower pChanPwrTest[4] = {0};
    UINT32 chanLoop           = 0;
    UINT32 ret                = BSP_OK;

    for (chanLoop = 0;chanLoop < 4;chanLoop++)
    {
        pChanPwrTest[chanLoop].chanNo  = chanLoop;
    }

    pChanPwrTest[0].chanPwr = ulCtrlVal;
    pChanPwrTest[1].chanPwr = ulCtrlVal1;
    pChanPwrTest[2].chanPwr = ulCtrlVal2;
    pChanPwrTest[3].chanPwr = ulCtrlVal3;

    ret = BspCfgCfrGateByChanPower(4,pChanPwrTest);

    if(ret != BSP_OK)
    {
        dbgInfo("[%s]:Cfg Cfr Gate By Chan Power Failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

static UINT32 bspsetcfrgatetest_8T(INT32 ulPwrVal)
{
    ChanPower pChanPwrTest[8] = {0};
    UINT32 chanLoop           = 0;
    UINT32 ret                = BSP_OK;

    for (chanLoop = 0;chanLoop < 8;chanLoop++)
    {
        pChanPwrTest[chanLoop].chanNo  = chanLoop;
        pChanPwrTest[chanLoop].chanPwr = ulPwrVal;
    }
    ret = BspCfgCfrGateByChanPower(8,pChanPwrTest);

    if(ret != BSP_OK)
    {
        dbgInfo("[%s]:Cfg Cfr Gate By Chan Power Failed !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspSetPaVoltByGpio(UINT32 ulLevel)
{
    PAVOLTLEVEL_INPUTSW_CHECK(ulLevel);	
    (void)BspHalAdaptSetPaVoltByReg(ulLevel);
	
    return BSP_OK;
}


UINT32 BspInitAntPwrPre(VOID)
{
    UINT32 loop = 0;
    for(loop=0; loop<TBL_MAX_TX_CHAN_NUM; loop++)
    {
        g_ulAntPwrPre[loop]  = 0x7fffffff;
        g_ulPaVoltPre[loop]  = 0x7fffffff;
    }
    dbgInfoEx("%s: g_ulAntPwrPre set OK! \n",__FUNCTION__);
    return BSP_OK;
}

static VOID showgridvoltinfo()
{
   UINT32 loop = 0;
   dbgInfo("g_vbiasTypeErr : %d\n", g_vbiasTypeErr);
   dbgInfo("g_ulAntPwrPre : \n"); /*A点配置功率表*/
   for(loop = 0; loop<TBL_MAX_TX_CHAN_NUM; loop++)
   {
       dbgInfo("[%d]:%5d  ", loop, g_ulAntPwrPre[loop]);
       if(0 == ((loop + 1) % 8))
       {
           dbgInfo("\n");
       }
   }
}

//获取节能文件中栅压类型对应的栅压值
static INT32 BspGetDeltaVoltFromFile(T_PaEnSavAdjCaliData *ptEnSavAdjData,UINT32 paChan,UINT32 parLevel,UINT32 dataIndex,UINT32 vbiasTypeNum,UINT32 vbiasType)
{
    INT32  deltaVolt  = 0;
    UINT32 typeVal    = 0;

    INPUT_POINTER_CHECK(ptEnSavAdjData);
    typeVal = vbiasTypeNum+vbiasType;
    if ((dataIndex < EN_SAV_ADJ_MAX_ROW) && (parLevel < PA_ENERGY_SAVING_ADJ_MAX_LEVEL) &&
        (paChan <  TBL_MAX_TX_CHAN_NUM) && (typeVal  < EN_SAV_ADJ_MAX_ITEM))
    {
        deltaVolt = ptEnSavAdjData->atEnSavAdjPath[paChan].pCombiData[parLevel].combiItem[dataIndex][typeVal];
    }
    return deltaVolt;
}

UINT32 BspPaGridVoltAdjByFile(UINT32 chanNo, INT32 powerDbm)
{
    UINT32 parLevel      = 0;
    UINT32 powerLevel    = 0;
    UINT32 freqLevel     = 0;
    UINT32 dataIndex     = 0;
    //INT32  rdTemp        = 0;
    /* INT32  tempInf       = 0; */
    /* INT32  dacVolt       = 0; */
    UINT32 num           = 0;
    UINT32 paChan        = 0;
    /* UINT32 loop          = 0; */
    //UINT32 dacChan       = 0;
    /* UINT32 coefNum       = 0; */
    /* UINT32 pointNum      = 0; */
    /* UINT32 stdInfIndex   = 0; */
    /* UINT32 currInfIndex  = 0; */
    /* INT32  tempOfDacData = 0; */
    /* INT32  odacData      = 0; */
    UINT32 vbiasType     = 0;
    UINT32 freq          = 0;
    UINT32 vbiasTypeNum  = 4;
    //UINT32 VgsDeltaNum   = 4;
    /* UINT32 paGainNum     = 1; */
    /* UINT32 tempPointIndex= 0; */
   /*  UINT32 tempCoefItem  = 0; */
    /* INT32  tempPoint[TEMP_POINT_MAX_NUM] = {0}; */
    /* INT32  tempCoef[TEMP_POINT_MAX_NUM]  = {0}; */
    UINT32 pwrAvgRat     = 0;
    UINT32 paVibasFlag   = 0;
    UINT32 powerLevelPre = 0;  
    INT32  powDbmPre     = 0;
    INT32 deltaBVolt = 0;
    INT32 deltaRatePowerVolt = 0;
    static UINT32 s_ratePowerLevel = 0;
    static UINT32 s_dataIndexRatePower = 0;
    INT32 deltaDacVolt = 0;
    UINT32 PaRatedPower = 0;
    UINT32 tblIndex = 0;
    /* UINT32 digGainQorvo = 0; */
    /* UINT32 dacVoltGain = 0; */

    T_PaDacSetCaliData  *ptData          = NULL;
    T_PaDacSetGridVoltRecord *ptRecord   = NULL;
    /* T_PaEnSavAdjPath *ptEnSavRecord      = NULL; */
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    TPaBasicInfoCaliData * pCali = NULL;
    UINT32 tblChn = 0;

    BspUpdateRfTblIndexAndChn(chanNo, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    IF_CHK(tblIndex > 0)
    {
        return BSP_OK;    /*按照方案子母端机型 子端不在静态调压流程调整栅压直接返回OK 子端表的编号是234*/
    }
    pCali = _BspGetPaBasicInfoCalibData(0);
    TBL_CHAN_VALID_CHECK(chanNo);
    if(pCali != NULL)
    {
         PaRatedPower = pCali->atBasicInfoPath[chanNo].ulPaRatedPower;
    }
    
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    (void)BspGetPwrAverageRatio(&pwrAvgRat); 
    freq        = BspGetMultiCarrCenterFreq(TX, chanNo);
    parLevel    = BspGetParLevelByFile(pwrAvgRat,chanNo);
    powerLevel = BspGetPowerLevelByFile(powerDbm,chanNo);
    freqLevel   = BspGetFreqLevelByFile(freq,chanNo);
    dataIndex   = BspGetCombiIndex(parLevel, powerLevel, freqLevel,chanNo);

    dbgInfoEx("%s: PaRatedPower[%d], freq[%d]\n", __FUNCTION__,PaRatedPower, freq);
    BspGetVibasEnableFlag(chanNo, &paVibasFlag);
    if(0 == paVibasFlag) 
    {
        return BSP_OK;
    }
	dbgInfoEx("%s: chanNo[%d]: parLevel[%d], powerLevel[%d] freqLevel[%d] dataIndex[%d]\n", __FUNCTION__, chanNo, parLevel, powerLevel, freqLevel, dataIndex);

    /* 获取写表数据 */
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    INPUT_POINTER_CHECK(ptData);
    INPUT_POINTER_CHECK(ptData->pCaliPath[0]);
    if ((dataIndex >= EN_SAV_ADJ_MAX_ROW) || (parLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) ||
        (freqLevel > PA_ENERGY_SAVING_ADJ_MAX_LEVEL) || (powerLevel > PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        return BSP_ERROR;
    }

    /*@20200429:根据胡晓鹏的节能方案，在设置栅压前，需要根据配置功率查询PaGain，并补偿到Txatt */
    if(0x7fffffff  != g_ulAntPwrPre[chanNo])
    {
    	powDbmPre = g_ulAntPwrPre[chanNo];
    	powerLevelPre = BspGetPowerLevelByFile(powDbmPre,chanNo);
        dbgInfoEx("%s: powDbmPre = %d, powerLevelPre = %d\n",  __FUNCTION__, powDbmPre, powerLevelPre);
    }
    else  /* 第一次网管下发配置时，参考的前一次配置功率是额定功率。 */
    {
        if(PaRatedPower == 0)
        {
               powerLevelPre = 0;
        }
        else
        {
               powerLevelPre = BspGetPowerLevelByFile(PaRatedPower,chanNo);
        }
        s_ratePowerLevel = powerLevelPre;  /* 保存第一次的额定功率等级  */
        dbgInfoEx("%s: First issued PaRatedPower = %d, powerLevelPre = %d\n", __FUNCTION__, PaRatedPower, powerLevelPre);
    }
    dbgInfoEx("%s: chanNo[%d]: parLevel[%d], powerLevelPre[%d] freqLevel[%d]\n", __FUNCTION__, chanNo, parLevel, powerLevelPre, freqLevel);

    s_dataIndexRatePower = BspGetCombiIndex(parLevel, s_ratePowerLevel, freqLevel,chanNo); /* 额定功率对应的行索引 */
    dbgInfoEx("%s:s_ratePowerLevel[%d], s_dataIndexRatePower[%d]\n", __FUNCTION__, s_ratePowerLevel, s_dataIndexRatePower);

    if((s_dataIndexRatePower >= EN_SAV_ADJ_MAX_ROW) || (dataIndex >= EN_SAV_ADJ_MAX_ROW))
    {
        return BSP_ERROR;
    }

    BspSetPaVibasNewIndex(chanNo, parLevel, dataIndex);

    paChan = chanNo;
    /* 解析后的paChan通道数据 */
    ptRecord = ptData->pCaliPath[0][paChan].ptRecord;
    INPUT_POINTER_CHECK(ptRecord);
    //防止spi总线过度访问，BspGetExPaTemp和BspGetPaTemp均需要用射频通道号，内部会转换成pa通道
    /*
    if (BSP_OK != BspGetExPaTemp(chanNo, &rdTemp))
    {
        dbgErr("%s paChan%d get temp failed\n",__FUNCTION__,paChan);
        rdTemp = 400;
    }
    */

    /* 配置DAC:一个 PA 需要 ulRecordNum 条配置 */
    for (num = 0; num < ptData->pCaliPath[0][paChan].ulRecordNum; num++)
    {
        //dacChan       = ptRecord->ulDacChanIndex;     /* DAC通道索引 */
        vbiasType     = ptRecord->ulGridVoltType;
        vbiasTypeNum  = ptEnSavAdjData->atEnSavAdjPath[paChan].vbiasTypeNum;
        //VgsDeltaNum   = ptEnSavAdjData->atEnSavAdjPath[paChan].vgsDeltaNum;
        if(vbiasType >= (EN_SAV_ADJ_MAX_ITEM - vbiasTypeNum))
        {
            g_vbiasTypeErr++;
            dbgErr("%s: vbiasType is out of range.\n", __FUNCTION__);
            continue;
        }
        
        deltaBVolt = BspGetDeltaVoltFromFile(ptEnSavAdjData,paChan,parLevel,dataIndex,vbiasTypeNum,vbiasType);
        deltaRatePowerVolt = BspGetDeltaVoltFromFile(ptEnSavAdjData,paChan,parLevel,s_dataIndexRatePower,vbiasTypeNum,vbiasType);
        deltaDacVolt  = deltaBVolt - deltaRatePowerVolt;   /* 计算此次配置功率 和 额定功率 对应的 栅压差 */
        dbgInfoEx("%s: vibasType = %d, deltaRatePowerVolt = %d,deltaBVolt = %d,deltaDacVolt = %d\n", __FUNCTION__,vbiasType, deltaRatePowerVolt, deltaBVolt, deltaDacVolt);
        BspSetPaVibasDeltaDacVolt(vbiasType, deltaDacVolt);
        ptRecord++;
    }
    /* 设置栅压  */
    if(pGetGridAdjCall != NULL)                              /* 8T不执行 */
    {
        BspSetPaVibas(0);
    }
    else
    {
        BspSetPaVibasByChanNew(0, chanNo);
    }

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspCfgPaGridVoltByChanPower(*)
 *  功能描述   : 自动调整栅压
 *  输入参数   : chanNum-通道数，pChanPwr-每个通道的功率
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 节能调压接口
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspCfgPaGridVoltByChanPower(UINT32 chanNum, ChanPower pChanPwr[])
{
    UINT32 retVal = 0;
    UINT32 ulLoop = 0;
    UINT32 chanNo = 0;
    UINT32 errCnt = 0;
    UINT32 txChnl = 0;
    INT32   gain      = 0;
    INT32  ulFilterGain = 0;
    UINT32 ulRfChn = 0;
    UINT32 flag = 0;

    dbgInfoEx("[%s] ChanNum =%d\n",__func__,chanNum);

    for (ulLoop = 0;ulLoop < chanNum;ulLoop++)
    {
        chanNo = pChanPwr[ulLoop].chanNo;        //调试用
        dbgInfoEx("[%s] ChanNo =%d ChanPow = %d \n",__func__,chanNo,pChanPwr[ulLoop].chanPwr);
    }

    txChnl = BspGetTxChannel();
    if(chanNum < 1 || chanNum > txChnl)
    {
        dbgErr("%s: chanNum >= 1 && chanNum <= %d\n", __FUNCTION__, txChnl);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pChanPwr);

    BspRecordPaGridVoltByChanPower(chanNum, pChanPwr);

    for(ulLoop = 0; ulLoop < chanNum; ulLoop++)
    {
        ulRfChn = pChanPwr[ulLoop].chanNo;
        flag = BspIsRemoteSlaveChan(ulRfChn,0);
        if(LINK_REMOTE == flag)
        {
            dbgInfoEx("slave chan %d not need cfg grid volt\n",ulRfChn);
            continue;
        }
        /*从FilterGain.txt获取滤波插损值*/
        if (BSP_OK == BspGetFilterGain(ulRfChn,&ulFilterGain))
        {
            gain = ulFilterGain;
            dbgInfoEx("%s: ulLoop = %d, ulRfChn = %d, gain = %d\n", __FUNCTION__, ulLoop, ulRfChn,gain);
        }
        else
        {
            gain = FILTE_GAIN_DEFAULT;/*无FileterGain.txt文件默认0.8db*/
            dbgInfoEx("%s: no FilterGain.txt, ulLoop = %d, ulRfChn = %d, gain = %d\n", __FUNCTION__, ulLoop, ulRfChn,gain);
        }
        pChanPwr[ulLoop].chanPwr -= gain;  //@20200430 add
        dbgInfoEx("%s: ulLoop = %d, ulRfChn = %d, chanPwr = %d\n", __FUNCTION__, ulLoop, ulRfChn,pChanPwr[ulLoop].chanPwr);
        retVal = BspPaGridVoltAdjByFile(ulRfChn, pChanPwr[ulLoop].chanPwr);
        if(BSP_OK != retVal)
        {
            errCnt++;
        }
    }
    
    return errCnt;
}

UINT32 BspPaGridVoltAdjByFileTxAtt(UINT32 chanNo, INT32 powerDbm)
{
    UINT32 parLevel      = 0;
    UINT32 powerLevel    = 0;
    UINT32 freqLevel     = 0;
    UINT32 dataIndex     = 0;
    UINT32 freq          = 0;
    UINT32 pwrAvgRat     = 0;
    UINT32 paVibasFlag   = 0;
    UINT32 powerLevelPre = 0;  
    INT32  powDbmPre     = 0;
    UINT32 dataIndexPre  = 0;
    INT32 paGain = 0;
    INT32 paGainPre = 0;
    UINT32 paGainPos     = 0;
    INT32 paTxAtt = 0;
    INT32 txAtt   = 0;
    static UINT32 s_ratePowerLevel = 0;
    static UINT32 s_dataIndexRatePower = 0;
    UINT32 PaRatedPower = 0;
    UINT32 tblIndex = 0;
    UINT32 tblChn = chanNo;
    T_PaDacSetCaliData  *ptData          = NULL;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    TPaBasicInfoCaliData * pCali = NULL;

    pCali = _BspGetPaBasicInfoCalibData(0);
    TBL_CHAN_VALID_CHECK(chanNo);
    IF_CHK(pCali != NULL)
    {
         PaRatedPower = pCali->atBasicInfoPath[chanNo].ulPaRatedPower;
    }
    
    BspUpdateRfTblIndexAndChn(chanNo, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    (void)BspGetPwrAverageRatio(&pwrAvgRat); 
    freq        = BspGetMultiCarrCenterFreq(TX, chanNo);
    parLevel    = BspGetParLevelByFile(pwrAvgRat,chanNo);
    powerLevel  = BspGetPowerLevelByFile(powerDbm,chanNo);
    freqLevel   = BspGetFreqLevelByFile(freq,chanNo);
    dataIndex   = BspGetCombiIndex(parLevel, powerLevel, freqLevel,chanNo);

    dbgInfoEx("%s: PaRatedPower[%d], freq[%d]\n", __FUNCTION__,PaRatedPower, freq);
    BspGetVibasEnableFlag(chanNo, &paVibasFlag);
    if((0 == paVibasFlag)&&(BSP_OK == BspIsSupportRfsRemote()))
    {
        return BSP_OK;
    }
    dbgInfoEx("%s: chanNo[%d]: parLevel[%d], powerLevel[%d] freqLevel[%d] dataIndex[%d]\n", __FUNCTION__, chanNo, parLevel, powerLevel, freqLevel, dataIndex);

    /* 获取写表数据 */
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    INPUT_POINTER_CHECK(ptData);
    INPUT_POINTER_CHECK(ptData->pCaliPath[0]);
    IF_CHK((dataIndex >= EN_SAV_ADJ_MAX_ROW) || (parLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) ||
        (freqLevel > PA_ENERGY_SAVING_ADJ_MAX_LEVEL) || (powerLevel > PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        return BSP_ERROR;
    }

    IF_CHK(0x7fffffff  != g_ulAntPwrPre[chanNo])
    {
        powDbmPre = g_ulAntPwrPre[chanNo];
        powerLevelPre = BspGetPowerLevelByFile(powDbmPre,chanNo);
        dbgInfoEx("%s: powDbmPre = %d, powerLevelPre = %d\n",  __FUNCTION__, powDbmPre, powerLevelPre);
    }
    ELSE  /* 第一次网管下发配置时，参考的前一次配置功率是额定功率。 */
    {
        IF_CHK(PaRatedPower == 0)
        {
               powerLevelPre = 0;
        }
        ELSE
        {
               powerLevelPre = BspGetPowerLevelByFile(PaRatedPower,chanNo);
        }
        s_ratePowerLevel = powerLevelPre;  /* 保存第一次的额定功率等级  */
        dbgInfoEx("%s: First issued PaRatedPower = %d, powerLevelPre = %d\n", __FUNCTION__, PaRatedPower, powerLevelPre);
    }
    dataIndexPre =  BspGetCombiIndex(parLevel, powerLevelPre, freqLevel,chanNo); 
    dbgInfoEx("%s: chanNo[%d]: parLevel[%d], powerLevelPre[%d] freqLevel[%d] dataIndexPre[%d]\n", __FUNCTION__, chanNo, parLevel, powerLevelPre, freqLevel, dataIndexPre);

    s_dataIndexRatePower = BspGetCombiIndex(parLevel, s_ratePowerLevel, freqLevel,chanNo); /* 额定功率对应的行索引 */
    dbgInfoEx("%s:s_ratePowerLevel[%d], s_dataIndexRatePower[%d]\n", __FUNCTION__, s_ratePowerLevel, s_dataIndexRatePower);

    IF_CHK((dataIndexPre >= EN_SAV_ADJ_MAX_ROW) || (parLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) ||
        (freqLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) || (powerLevelPre >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        return BSP_ERROR;
    }    
    IF_CHK((s_dataIndexRatePower >= EN_SAV_ADJ_MAX_ROW) || (dataIndex >= EN_SAV_ADJ_MAX_ROW))
    {
        return BSP_ERROR;
    }

    /*根据前后2次配置功率索引，查询对应2次pagain*/
    paGainPos = ptEnSavAdjData->atEnSavAdjPath[tblChn].vbiasTypeNum + ptEnSavAdjData->atEnSavAdjPath[tblChn].vgsDeltaNum;
    
    IF_CHK(paGainPos >= EN_SAV_ADJ_MAX_ROW)
    {
        return BSP_ERROR;
    }

    paGain = ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[parLevel].combiItem[dataIndex][paGainPos];
    paGainPre = ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[parLevel].combiItem[dataIndexPre][paGainPos];
    BspSetPaGain(chanNo,paGain);/*B点*/
    g_ulAntPwrPre[chanNo] = powerDbm;  /* 记录当前最新配置的功率  */
    dbgInfoEx("%s: chan = %d, powerDbm = %d\n", __FUNCTION__, chanNo, powerDbm);
    dbgInfoEx("%s: chan[%d]: paGainPos[%d], paGain[%d], paGainPre[%d]\n", __FUNCTION__, chanNo,paGainPos,paGain,paGainPre);

    paTxAtt = paGain - paGainPre;
    IF_CHK(0 != paTxAtt)   /* 如果ATT调整量为0，就不设置ATT。 */
    {
        BspGetTxAtt(chanNo, &txAtt);
        dbgInfoEx("%s: chanNo[%d]: paGain[%d], paGainPre[%d] deltaAtt[%d] curTxatt[%d]\n", __FUNCTION__, chanNo, paGain, paGainPre, paTxAtt, txAtt);
        txAtt -= paTxAtt;    /* 根据会议纪要实现 */
        BspSetTxAtt(chanNo, txAtt);
        dbgInfoEx("%s: chanNo[%d]: destTxatt[%d]\n", __FUNCTION__, chanNo, txAtt);
    }
    /*read back test*/
    BspGetTxAtt(chanNo, &txAtt); 
    dbgInfoEx("%s: read back test chanNo = %d, txatt = %d\n", __FUNCTION__, chanNo, txAtt);

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspCfgPaGridVoltByChanPowerTxAtt(*)
 *  功能描述   : 设置ATT补偿
 *  输入参数   : chanNum-通道数，pChanPwr-每个通道的功率
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspCfgPaGridVoltByChanPowerTxAtt(UINT32 chanNum, ChanPower pChanPwr[])
{
    UINT32 retVal = 0;
    UINT32 ulLoop = 0;
    UINT32 chanNo = 0;
    UINT32 errCnt = 0;
    UINT32 txChnl = 0;
    INT32   gain      = 0;
    INT32  ulFilterGain = 0;
    UINT32 ulRfChn = 0;

    dbgInfoEx("[%s] ChanNum =%d\n",__func__,chanNum);
    INPUT_POINTER_CHECK(pChanPwr);

    for (ulLoop = 0;ulLoop < chanNum;ulLoop++)
    {
        chanNo = pChanPwr[ulLoop].chanNo;        //调试用
        dbgInfoEx("[%s] ChanNo =%d ChanPow = %d \n",__func__,chanNo,pChanPwr[ulLoop].chanPwr);
    }

    txChnl = BspGetTxChannel();
    if(chanNum < 1 || chanNum > txChnl)
    {
        dbgErr("%s: chanNum >= 1 && chanNum <= %d\n", __FUNCTION__, txChnl);
        return BSP_ERROR;
    }

    for(ulLoop = 0; ulLoop < chanNum; ulLoop++)
    {
        ulRfChn = pChanPwr[ulLoop].chanNo;
        /*从FilterGain.txt获取滤波插损值*/
        if (BSP_OK == BspGetFilterGain(ulRfChn,&ulFilterGain))
        {
            gain = ulFilterGain;
            dbgInfoEx("%s: ulLoop = %d, ulRfChn = %d, gain = %d\n", __FUNCTION__, ulLoop, ulRfChn,gain);
        }
        else
        {
            gain = FILTE_GAIN_DEFAULT;/*无FileterGain.txt文件默认0.8db*/
            dbgInfoEx("%s: no FilterGain.txt, ulLoop = %d, ulRfChn = %d, gain = %d\n", __FUNCTION__, ulLoop, ulRfChn,gain);
        }
        pChanPwr[ulLoop].chanPwr -= gain;  //@20200430 add
        dbgInfoEx("%s: ulLoop = %d, ulRfChn = %d, chanPwr = %d\n", __FUNCTION__, ulLoop, ulRfChn,pChanPwr[ulLoop].chanPwr);
        retVal = BspPaGridVoltAdjByFileTxAtt(ulRfChn, pChanPwr[ulLoop].chanPwr);
        if(BSP_OK != retVal)
        {
            errCnt++;
        }
    }
    
    return errCnt;
}

UINT32 BspRegisterPaGridAdj(pPaGridAdjFunc pGridAdjCall)
{
    pGetGridAdjCall = pGridAdjCall;
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspCfgCfrGateByVolt(*)
 *  功能描述   : 通过漏压调整削峰门限，高层调用
 *  输入参数   : volt-漏压，chanNum-通道数，pChanPwr-每个通道的功率
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspCfgCfrGateByVolt(UINT32 volt, UINT32 chanNum, ChanPower pChanPwr[])
{
    UINT32 dir        = TX;
    UINT32 difChn     = 0;
    UINT32 difChipId  = 0;
    UINT32 ret        = BSP_OK;
    UINT32 index      = 0;
    UINT32 chanNo     = 0;
    UINT32 freqBand   = 0;
    UINT32 defCfrGate[E_CFR_THR_NUM] = {0, 0, 0};
    UINT32 curCfrGate[E_CFR_THR_NUM] = {0, 0, 0};
    UINT32 level      = 0;

    dbgInfoEx("[%s] ChanNum =%d volt =%d \n",__func__,chanNum,volt);
    INPUT_POINTER_CHECK(pChanPwr);

    for(index = 0;index < chanNum;index++)
    {
        chanNo = pChanPwr[index].chanNo;
        dbgInfoEx("[%s] ChanNo =%d ChanPow = %d \n",__func__,chanNo,pChanPwr[index].chanPwr);

        ret = BspGetDifInfoByBspChn(chanNo, dir, &difChipId, &difChn);
        CHECK_RETVAL(BspGetDifInfoByBspChn, ret);
        ret = BspGetCfrGatePara(difChn, defCfrGate);
        CHECK_RETVAL(BspGetCfrGatePara, ret);
        dbgInfo("index = %d, chan = %d, difChn = %d, cfrGate1 = %d, cfrGate2 = %d, cfrGate3 = %d\n",
                index, chanNo, difChn, defCfrGate[E_CFR_THR_1ST], defCfrGate[E_CFR_THR_2ND], defCfrGate[E_CFR_THR_3RD]);
        level = BspGetVdsLevelByFile(volt, chanNo);
        ret = BspGetCurrCfrGateByLevel(chanNo, level, 0, defCfrGate, curCfrGate);
        CHECK_RETVAL(BspGetCurrCfrGateByLevel, ret);
        ret = BspHalAdaptSetCfrGate(difChn,freqBand, curCfrGate, E_CFR_THR_NUM);
        CHECK_RETVAL(BspHalAdaptSetCfrGate, ret);
        ret = BspSetCfrGateCfg(difChn, E_CFR_THR_NUM, curCfrGate);
        CHECK_RETVAL(BspSetCfrGateCfg, ret);
        ret = printGetCfrGatePara(chanNo);
        CHECK_RETVAL(printGetCfrGatePara, ret);
    }
    return ret;
}

static UINT32 BspCfgPaTxAttByVoltPerChan(UINT32 chanNo, INT32 volt)
{
    UINT32 parLevel      = 0;
    UINT32 powerLevel    = 0;
    UINT32 freqLevel     = 0;
    UINT32 dataIndex     = 0;
    UINT32 freq          = 0;
    UINT32 pwrAvgRat     = 0;
    UINT32 powerLevelPre = 0;  
    INT32  voltPre       = 0;
    UINT32 dataIndexPre  = 0;
    INT32 paGain = 0;
    INT32 paGainPre = 0;
    UINT32 paGainPos     = 0;
    INT32 paTxAtt = 0;
    INT32 txAtt   = 0;
    static UINT32 s_ratePowerLevel = 0;
    static UINT32 s_dataIndexRatePower = 0;
    UINT32 tblIndex = 0;
    UINT32 tblChn = chanNo;
    T_PaDacSetCaliData  *ptData          = NULL;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;

    TBL_CHAN_VALID_CHECK(chanNo);
    
    BspUpdateRfTblIndexAndChn(chanNo, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    (void)BspGetPwrAverageRatio(&pwrAvgRat); 
    freq        = BspGetMultiCarrCenterFreq(TX, chanNo);
    parLevel    = BspGetParLevelByFile(pwrAvgRat,chanNo);
    powerLevel  = BspGetVdsLevelByFile(volt, chanNo);
    freqLevel   = BspGetFreqLevelByFile(freq,chanNo);
    dataIndex   = BspGetCombiIndex(parLevel, powerLevel, freqLevel,chanNo);

    dbgInfoEx("%s: chanNo[%d]: parLevel[%d], powerLevel[%d] freqLevel[%d] dataIndex[%d]\n", __FUNCTION__, chanNo, parLevel, powerLevel, freqLevel, dataIndex);

    /* 获取写表数据 */
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    INPUT_POINTER_CHECK(ptData);
    INPUT_POINTER_CHECK(ptData->pCaliPath[0]);
    if((dataIndex >= EN_SAV_ADJ_MAX_ROW) || (parLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) ||
        (freqLevel > PA_ENERGY_SAVING_ADJ_MAX_LEVEL) || (powerLevel > PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        return BSP_ERROR;
    }

    if(0x7fffffff  != g_ulPaVoltPre[chanNo])
    {
        voltPre = g_ulPaVoltPre[chanNo];
        powerLevelPre = BspGetVdsLevelByFile(voltPre,chanNo);
        dbgInfoEx("%s: voltPre = %d, powerLevelPre = %d\n",  __FUNCTION__, voltPre, powerLevelPre);
    }
    else
    {
        s_ratePowerLevel = powerLevelPre = 0;  /* 保存第一次的额定功率等级  */
        dbgInfoEx("%s: First issued powerLevelPre = %d\n", __FUNCTION__, powerLevelPre);
    }
    dataIndexPre =  BspGetCombiIndex(parLevel, powerLevelPre, freqLevel,chanNo); 
    dbgInfoEx("%s: chanNo[%d]: parLevel[%d], powerLevelPre[%d] freqLevel[%d] dataIndexPre[%d]\n", __FUNCTION__, chanNo, parLevel, powerLevelPre, freqLevel, dataIndexPre);

    s_dataIndexRatePower = BspGetCombiIndex(parLevel, s_ratePowerLevel, freqLevel,chanNo); /* 额定功率对应的行索引 */
    dbgInfoEx("%s:s_ratePowerLevel[%d], s_dataIndexRatePower[%d]\n", __FUNCTION__, s_ratePowerLevel, s_dataIndexRatePower);

    if((dataIndexPre >= EN_SAV_ADJ_MAX_ROW) || (parLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) ||
        (freqLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) || (powerLevelPre >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        return BSP_ERROR;
    }    
    if((s_dataIndexRatePower >= EN_SAV_ADJ_MAX_ROW) || (dataIndex >= EN_SAV_ADJ_MAX_ROW))
    {
        return BSP_ERROR;
    }

    /*根据前后2次配置功率索引，查询对应2次pagain*/
    paGainPos = ptEnSavAdjData->atEnSavAdjPath[tblChn].vbiasTypeNum + ptEnSavAdjData->atEnSavAdjPath[tblChn].vgsDeltaNum;
    
    if(paGainPos >= EN_SAV_ADJ_MAX_ROW)
    {
        return BSP_ERROR;
    }

    paGain = ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[parLevel].combiItem[dataIndex][paGainPos];
    paGainPre = ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[parLevel].combiItem[dataIndexPre][paGainPos];
    BspSetPaGain(chanNo,paGain);/*B点*/
    g_ulPaVoltPre[chanNo] = volt;  /* 记录当前最新配置的漏压  */
    dbgInfoEx("%s: chan = %d, volt = %d\n", __FUNCTION__, chanNo, volt);
    dbgInfoEx("%s: chan[%d]: paGainPos[%d], paGain[%d], paGainPre[%d]\n", __FUNCTION__, chanNo,paGainPos,paGain,paGainPre);

    paTxAtt = paGain - paGainPre;
    if(0 != paTxAtt)   /* 如果ATT调整量为0，就不设置ATT */
    {
        BspGetTxAtt(chanNo, &txAtt);
        dbgInfoEx("%s: chanNo[%d]: paGain[%d], paGainPre[%d] deltaAtt[%d] curTxatt[%d]\n", __FUNCTION__, chanNo, paGain, paGainPre, paTxAtt, txAtt);
        txAtt -= paTxAtt;
        BspSetTxAtt(chanNo, txAtt);
        dbgInfoEx("%s: chanNo[%d]: destTxatt[%d]\n", __FUNCTION__, chanNo, txAtt);
    }
    /*read back txatt*/
    BspGetTxAtt(chanNo, &txAtt); 
    dbgInfoEx("%s: read back chanNo = %d, txatt = %d\n", __FUNCTION__, chanNo, txAtt);

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspCfgPaTxAttByVolt(*)
 *  功能描述   : 通过漏压调整Txatt，高层调用
 *  输入参数   : volt-漏压，chanNum-通道数，pChanPwr-每个通道的功率
 *  输出参数   : 无
 *  返 回 值   : BSP_OK 成功
 *              其他     失败
 *  其它说明   : 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspCfgPaTxAttByVolt(UINT32 volt, UINT32 chanNum, ChanPower pChanPwr[])
{
    UINT32 retVal = 0;
    UINT32 ulLoop = 0;
    UINT32 chanNo = 0;
    UINT32 errCnt = 0;
    UINT32 txChnl = 0;

    dbgInfoEx("[%s] ChanNum =%d volt =%d \n",__func__,chanNum,volt);
    INPUT_POINTER_CHECK(pChanPwr);

    txChnl = BspGetTxChannel();
    if(chanNum < 1 || chanNum > txChnl)
    {
        dbgErr("%s: chanNum >= 1 && chanNum <= %d\n", __FUNCTION__, txChnl);
        return BSP_ERROR;
    }

    for(ulLoop = 0; ulLoop < chanNum; ulLoop++)
    {
        chanNo = pChanPwr[ulLoop].chanNo;
        dbgInfoEx("[%s] ChanNo =%d ChanPow = %d \n",__func__,chanNo,pChanPwr[ulLoop].chanPwr);
        retVal = BspCfgPaTxAttByVoltPerChan(chanNo, volt);
        if(BSP_OK != retVal)
        {
            errCnt++;
        }
    }
    
    return errCnt;
}

UINT32 testsetchanpwr(UINT32 chanNo, INT32 chanPwr)
{
    UINT32 loop = 0;

    for(loop = 0; loop < tChanPowerGroup.chanNum; loop++)
    {
        if(chanNo == tChanPowerGroup.tChanPower[loop].chanNo)
        {
            break;
        }
    }

    if(loop < tChanPowerGroup.chanNum)
    {
        tChanPowerGroup.tChanPower[loop].chanNo = chanNo;
        tChanPowerGroup.tChanPower[loop].chanPwr = chanPwr;
    }
    else
    {
        tChanPowerGroup.tChanPower[tChanPowerGroup.chanNum].chanNo = chanNo;
        tChanPowerGroup.tChanPower[tChanPowerGroup.chanNum].chanPwr = chanPwr;
        tChanPowerGroup.chanNum++;
    }

    return BSP_OK;
}

VOID testshowchanpwr(VOID)
{
    UINT32 loop = 0;

    dbgInfo("tChanPowerGroup.chanNum = %d!\n", tChanPowerGroup.chanNum);
    for(loop = 0; loop < tChanPowerGroup.chanNum; loop++)
    {
        dbgInfo("chanNo(%d) chanPwr(%d)!\n", tChanPowerGroup.tChanPower[loop].chanNo, tChanPowerGroup.tChanPower[loop].chanPwr);
    }
}

VOID testclrchanpwr(VOID)
{
    UINT32 loop = 0;

    dbgInfo("tChanPowerGroup.chanNum = %d!\n", tChanPowerGroup.chanNum);
    for(loop = 0; loop < tChanPowerGroup.chanNum; loop++)
    {
        tChanPowerGroup.tChanPower[loop].chanNo = 0;
        tChanPowerGroup.tChanPower[loop].chanPwr = 0;
    }
    tChanPowerGroup.chanNum = 0;
}

UINT32 testcfgpagridvoltbychanpower(VOID)
{
    testshowchanpwr();
    return BspCfgPaGridVoltByChanPower(tChanPowerGroup.chanNum, tChanPowerGroup.tChanPower);
}

UINT32 testcfgpagridvoltbychanpowertxatt(VOID)
{
    testshowchanpwr();
    return BspCfgPaGridVoltByChanPowerTxAtt(tChanPowerGroup.chanNum, tChanPowerGroup.tChanPower);
}

UINT32 testcfgpadrainvoltbychanpower(VOID)
{
    testshowchanpwr();
    return BspCfgPaDrainVoltByChanPower(tChanPowerGroup.chanNum, tChanPowerGroup.tChanPower);
}

UINT32 testcfgcfrgatebychanpower(VOID)
{
    testshowchanpwr();
    return BspCfgCfrGateByChanPower(tChanPowerGroup.chanNum, tChanPowerGroup.tChanPower);
}

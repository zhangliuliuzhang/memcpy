/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeaturewrapperbase.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的基础封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "hardfeaturewrapperbase.h"
#include "board_ic4_2.h"
#include "boardhardid.h"
#include "flash.h"
#include "bspcommon.h"
#include "boardmodle_ic4_2.h"
#include "funccommon_log.h"
#include "funccommon_a.h"
#include "boardcpuid.h"
#include "hardfeaturewrapperrfctrl.h"
#include "uartcommon.h"


#define BOARD_CFG_PATH                    "/BoardCfgFile"

/*****************************************************************************
                                  函数声明
*****************************************************************************/
static UINT32 FpgaAccessCheck(UINT32 chip);

/*****************************************************************************
                                  全局变量
*****************************************************************************/
static T_Reg_Head s_regHeadGroup[REG_FUNCDOMAIN_MAX] =
{
    [REG_FUNCDOMAIN_CPU_DDR3] = 
    {
        .regFuncDomainType      = REG_FUNCDOMAIN_CPU_DDR3,
        .accessType             = DEV_REG_ACCESS_LOCAL_BUS,
        .chanInter              = 0,
        .chipNum                = 1,
        .rawPhyBaseAddr[0]      = SYS_MEM_TOP,
        .mapPhyBaseAddr[0]      = SYS_MEM_TOP,
        .maxSize                = USER_RESERVED_SIZE,
        .virtualBaseAddr[0]     = 0,
        .initFlag               = 1,
        .subSectFlag            = 0,
        .mmapType               = MMAP_TYPE_MEMNC,
    },
    [REG_FUNCDOMAIN_SLAVE_CPU_DDR3] = 
    {
        .regFuncDomainType      = REG_FUNCDOMAIN_SLAVE_CPU_DDR3,
        .accessType             = DEV_REG_ACCESS_LOCAL_BUS,
        .chanInter              = 0,
        .chipNum                = 1,
        .rawPhyBaseAddr[0]      = SLAVE_SYS_MEM_TOP,
        .mapPhyBaseAddr[0]      = SLAVE_SYS_MEM_TOP,
        .maxSize                = SLAVE_USER_RESERVED_SIZE,
        .virtualBaseAddr[0]     = 0,
        .initFlag               = 1,
        .subSectFlag            = 0,
        .mmapType               = MMAP_TYPE_MEMNC,
    },    
    [REG_FUNCDOMAIN_FPGA0] =
    {
        .regFuncDomainType      = REG_FUNCDOMAIN_FPGA0,
        .accessType             = DEV_REG_ACCESS_SPI_BUS,
        .chanInter              = 0,
        .chipNum                = 1,
        .rawPhyBaseAddr[0]      = 0,
        .mapPhyBaseAddr[0]      = 0,
        .maxSize                = SIZE_64K,
        .initFlag               = 1,
        .subSectFlag            = 0,
        .pcbCheck               = FpgaAccessCheck,
        .mmapType               = MMAP_TYPE_MEM,
    },
};

/*****************************************************************************
                                    内部接口
*****************************************************************************/
static UINT32 FpgaAccessCheck(UINT32 chip)
{
    return BSP_OK;
    //return BspCheckFpgaLoadStatus(chip);
}

UINT32 BspSplicingBoardCfgFilePath(char* pFilePath, UINT32 len)
{
    UINT32 moduleGroupId = 0;
    UINT32 boardGroupId = 0;
    UINT32 boardTypeId = 0;
    UINT32 hardwareChangeId = 0;
    INT32  snprtRet = 0;


    INPUT_POINTER_CHECK(pFilePath);
    moduleGroupId = BspGetModuleGroupIdPara();
    boardGroupId = BspGetBoardGroupIdPara();
    boardTypeId = BspGetBoardTypeIdPara();
    hardwareChangeId = BspGetHardwareChangeIdPara();

    snprtRet = snprintf_s(pFilePath, len, "%s/%x_%x_%x_%x",
            BOARD_CFG_PATH, moduleGroupId, boardGroupId, boardTypeId, hardwareChangeId);
    SNPRINTF_S_CHECK(snprtRet, len);

    dbgInfoEx("%s>> pFilePath:%s\n", __FUNCTION__, pFilePath);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspFlashInit
*  功能描述   : Flash参数初始化
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspFlashInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_FlashInfo *pPara = NULL;
    UINT32 num = 0;
    UINT32 flashParaSel = FLASH_PARA_NOR_NAND;
    T_Bsp_RruIniCfgItem iniCfg = {0};
    T_FlashInfo boardFlashInfo[FLASH_PARA_MAX] =
    {
        {
            NOR_FLASH_SIZE + NAND_FLASH_SIZE,
            FLASH_SECTOR_SIZE,
            FLASH_PARTITION_NUM,
            {
                {"/dev/mtd0", FLASH_BOOT_PART_OFFSET,       FLASH_BOOT_PART_SIZE},
                {"/dev/mtd1", FLASH_BSP_PART_OFFSET,        FLASH_BSP_PART_SIZE},
                {"/dev/mtd2", FLASH_SECRET_KEY_OFFSET,      FLASH_SECRET_KEY_SIZE},
            }
        },
        {
            NOR_FLASH_SIZE,
            FLASH_SECTOR_SIZE,
            FLASH_PARTITION_NUM,
            {
                {"/dev/mtd0", FLASH_BOOT_PART_OFFSET,       FLASH_BOOT_PART_SIZE_NOR},
                {"/dev/mtd1", FLASH_BSP_PART_OFFSET_NOR,    FLASH_BSP_PART_SIZE_NOR},
                {"/dev/mtd2", FLASH_SECRET_KEY_OFFSET_NOR,  FLASH_SECRET_KEY_SIZE},
            }
        }
    };
    UINT32 stralIdOffset[FLASH_PARA_MAX] = {FLASH_ANTI_STEAL_ID_OFFSET, FLASH_ANTI_STEAL_ID_OFFSET_NOR};

    (void)BspReadRuCfgIniFieldValue(FLASH_PARA_FILE, FLASH_SEL_KEY, &iniCfg);
    if (iniCfg.cFieldValue == FLASH_SEL_NOR)
    {
        flashParaSel = FLASH_PARA_NOR;
    }
    BspSetFlashParaSel(flashParaSel);
    /* 如果单板下传入了FLASH配置参数使用单板下传入的,未传入根据GPIO0来选择FLASH规划(GPIO0低-Nor+Nand规划, GPIO0高-单Nor规划) */
    retVal = BspBoardModleGetData(E_HARD_FEATURE_FLASH_INIT, 0, 0, (VOID **)&pPara, &num);
    if (retVal != BSP_OK)
    {
        pPara = &boardFlashInfo[flashParaSel];
    }
    BspLog(LOG_LEVEL_0, "%s: flashParaSel=%u, retVal=%u\n", __FUNCTION__, flashParaSel, retVal);
    retVal = BspFlashModuleInit(pPara);
#if BSP_MAKE_VER
    BspFlashShowCfg();
#endif
    BspSetBbuUniqueIdFlashId(stralIdOffset[flashParaSel]);
    BspSetAntiThefFlashId(ANTI_THEF_MODE0, stralIdOffset[flashParaSel] + 1);/*anti-counterfeiting(bit0)*/
    BspSetAntiThefFlashId(ANTI_THEF_MODE1, stralIdOffset[flashParaSel] + 2);/*proactive theft prevention(bit1)*/
    return retVal;
}

/**************************************************************************
 * 函数名称: BspRegTblInit(*)
 * 功能描述: 通用寄存器表初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10090699    创建
 **************************************************************************/
UINT32 BspRegTblInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    T_Reg_Tbl *p_tRegTbl = NULL;
    
    /* regtbl 初始化 */
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_REG_TBL, 0, 0, p_tRegTbl, num);
    retVal |= BspSetRegTblData(p_tRegTbl, num);
    retVal |= BspSetRegTblHeadData(s_regHeadGroup, NELEMENTS(s_regHeadGroup));
    retVal |= BspRegAccessInit();
    retVal |= BspInitRegVirAddr();
    retVal |= BspRegTblValInit();

    return retVal;
}

/* 初始化 cpuId 和 coreId */
UINT32 BspInitCpuAndCoreId(VOID)
{
    UINT32 retVal  = BSP_OK;
    UINT32 paraNum = 0;
    T_CpuIdInfo *pCpuIdInfo = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_CPUID_INIT, 0, 0, pCpuIdInfo, paraNum);
    retVal = BspInitCpuIdInfoTbl(pCpuIdInfo, paraNum);

    retVal |= BspInitCpuId();
    retVal |= BspInitCoreId();

    return retVal;
}

/* Started by AICoder, pid:b19ffdb2bfi48ce14b940805c0425c1cf2e6cc9a */
UINT32 BspSetAisgDigPhaseShiftInfoInit(VOID)
{
    UINT32 retVal = BSP_OK;
    TAisgDigPhaseShiftDevInfo *pAisgDigPhaseShiftDevInfo = NULL;
    UINT32 paraNum = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_DPS_UART_PARA_INIT, 0, 0, pAisgDigPhaseShiftDevInfo, paraNum);
    retVal |= BspSetAisgDigPhaseShiftInfo(pAisgDigPhaseShiftDevInfo);

    return retVal;
}
/* Ended by AICoder, pid:b19ffdb2bfi48ce14b940805c0425c1cf2e6cc9a */

/*****************************************************************************
*  函数名称   : BspRruPropertyInit
*  功能描述   : rruproperty.txt的导入和按BoardID进行解析
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspRruPropertyInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_RruPropertyInfo *pPara = NULL;
    UINT32 num = 0; 

    if (BspGetBoardLoadCfgType() == 1)
    {
        retVal = BspInitGlobalRruHwInfo();
        retVal |= BspInitBoardProperty();
    }
    else
    {
        BOARD_MODLE_GET_DATA(E_HARD_FEATURE_RRU_PROPERTY, 0, 0, pPara, num);
        retVal = BspSetBoardPropInfo(pPara->ascbuf, pPara->bufSize);
        retVal |= BspInitAdpHwInfoNew();
    }

    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspUpdateRruPropertyInfo
*  功能描述   : 单板侧配置特性表更新差分信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 10229672@2025-01-10 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspUpdateRruPropertyInfo(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulLoop = 0;
    T_BoardProPertyUpdateInfo *pBoardProPertyPara = NULL;
    TRruDeviceUpdateInfo *pRruDevicePara = NULL;
    UINT32 ulBoardSecId = BspGetBoardSecLgcType();
    UINT32 num = 0;

    BspLog(LOG_LEVEL_0, "%s: ulBoardSecId=%u \n", __FUNCTION__, ulBoardSecId);

    if(INVALID_VALUE == ulBoardSecId)
    {
    	return BSP_OK;
    }
    /*获取单板配置更新参数*/
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_RRU_PROPERTY_PARA, 0, 0, pBoardProPertyPara, num);

    pRruDevicePara = malloc(sizeof(TRruDeviceUpdateInfo) * MAX_ITEM_NUM);
    memset_s(pRruDevicePara, MAX_ITEM_NUM*sizeof(TRruDeviceUpdateInfo), 0, MAX_ITEM_NUM*sizeof(TRruDeviceUpdateInfo));
    /*通过二级单板宏，查找更新特性表参数*/
    for(ulLoop = 0; ulLoop < MAX_SUBID_NUM; ulLoop++)
    {
    	if(ulBoardSecId == pBoardProPertyPara->tBoardSecIdPropertyInfo[ulLoop].ulSecLgcId)
    	{
            memcpy_s(pRruDevicePara, MAX_ITEM_NUM*sizeof(TRruDeviceUpdateInfo), &(pBoardProPertyPara->tBoardSecIdPropertyInfo[ulLoop].tRruDeviceUpdateInfo[0]), MAX_ITEM_NUM*sizeof(TRruDeviceUpdateInfo));
            break;
    	}
    }

    /*更新单板参数到特性表*/
    retVal = BspSetBoardPropertyUpdateInfo(pRruDevicePara, MAX_ITEM_NUM);
    free(pRruDevicePara);
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetFlashBomid
*  功能描述   : 从单板下获取Bomid在Flash中地址并且进行初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetFlashBomid(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BomidFlashInfo *pPara = NULL;
    UINT32 num = 0;
    UINT32 flashParaSel = BspGetFlashParaSel();
    T_BomidFlashInfo bomidFlashInfo[FLASH_PARA_MAX] =
    {
        {
            FLASH_BOMID_OFFSET,
            FLASH_BOMID_SIZE
        },
        {
            FLASH_BOMID_OFFSET_NOR,
            FLASH_BOMID_SIZE
        },
    };

    retVal = BspBoardModleGetData(E_HARD_FEATURE_GET_BOMID, 0, 0, (VOID **)&pPara, &num);
    if (retVal != BSP_OK)
    {
        if (flashParaSel >= FLASH_PARA_MAX)
        {
            flashParaSel = FLASH_PARA_NOR_NAND;
        }
        pPara = &bomidFlashInfo[flashParaSel];
    }
    BspSetFlashBomidOffset(pPara->flashBomidOffset);
    retVal = BspInitAdpBdHwIdInfoPara();
    CHECK_RETVAL(BspInitAdpBdHwIdInfoPara, retVal);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetSocMsgBomid
*  功能描述   : 通过SOC MSG从主片
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetSocMsgBomid(VOID)
{
    UINT32 retVal = BSP_OK;

    BspGetBomIdBySocMsg();
    retVal = BspInitAdpBdHwIdInfoPara();
    CHECK_RETVAL(BspInitAdpBdHwIdInfoPara, retVal);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetBoardIdFirst
*  功能描述   : 第一次对比获取BoardId的值(会保存在静态变量中供后续使用)
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetBoardIdFirst(VOID)
{
    UINT32 ulBoardId = 0;
    char boardCfgFilePath[256] = {0};
    char boardPropertyFilePath[256] = {0};
    INT32  snprtRet = 0;
    UINT32 ret = 0;

    /* Started by AICoder, pid:j8f42785a5ge31414e970b3f30c2700b8ff67c66 */
    if(BSP_OK == BspIsFileExist("/ata/devsotest"))
    {  /*需要在第一次获取单板宏之前执行*/
        BspTestModifyBomidPara(0);
        BspTestModifyBomidPara(1);
        BspTestModifyBomidPara(2);
        BspTestModifyBomidPara(3);
    }
    /* Ended by AICoder, pid:j8f42785a5ge31414e970b3f30c2700b8ff67c66 */
    ulBoardId = BspGetBoardLgcType();
    /* 第一次获取Boardid后，配置到单板模型中，用于后续的数据匹配 */
#ifndef PLAT_X86_TEST
    ret = BspSplicingBoardCfgFilePath(boardCfgFilePath, sizeof(boardCfgFilePath));
    CHECK_RETVAL(BspSplicingBoardCfgFilePath, ret);
    snprtRet = snprintf_s(boardPropertyFilePath, sizeof(boardPropertyFilePath), "%s/%s", boardCfgFilePath, "BoardProperty.txt");
    SNPRINTF_S_CHECK(snprtRet, sizeof(boardPropertyFilePath));
    dbgInfoEx("%s:boardPropertyFilePath: %s \n", __FUNCTION__, boardPropertyFilePath);
    if (BspIsFileExist(boardPropertyFilePath) == BSP_OK)
    {
        BspSetBoardLoadCfgType(1);
        BspSetBoardCfgPath(boardCfgFilePath, sizeof(boardCfgFilePath));
        //ulBoardId = 26;
        ret = GetVirtualId(&ulBoardId);
        CHECK_RETVAL(GetVirtualId, ret);
        BspSetBoardVirtualId(ulBoardId);
        dbgInfoEx("%s>>boardCfgFilePath: %s\n", __FUNCTION__, boardCfgFilePath);
    }
    else
    {
        BspSetBoardLoadCfgType(0);
    }
#endif
    BspBoardModleSetBoardId(ulBoardId);
    return BSP_OK;
}

UINT32 BspGetReservedMemSize(UINT8 moduleId)
{
    UINT32 size = 0;

    switch (moduleId)
    {
        case BSP_HIGH_RESERVED_MEM_BSP:
            size = BSP_MEM_SIZE;
            break;

        case BSP_HIGH_RESERVED_MEM_MGR:
            size = OSS_MEM_SIZE;
            break;

        case BSP_HIGH_RESERVED_MEM_USER_DEFINE:
            size = BSP_VER_PROTECT_SIZE;
            break;

        case BSP_HIGH_RESERVED_MEM_APP1: /* 产品高层，使用保留区 */
            size = APP_RESERVED_SIZE;
            break;

        default:
            dbgInfo("%s: Error input %d\n", __FUNCTION__, moduleId);
            size = 0;
    }

    return size;
}

/*打桩测试接口  删除某个单板的bomid 设置为异常值  人为制造匹配不上场景*/
/* Started by AICoder, pid:567bf9c8d4r2b5b14d2e095df088271f30a138df */
UINT32 BspTestModifyBomidPara(UINT32 type)
{
    UINT32 retVal = BSP_OK;
    TVerGroup *pVerGroup   = NULL;
    UINT32 num = 0;
    UINT32 loop = 0;
    TVerGroup* pFlashVerGrp = NULL;
    UINT32 idx = 0;

    pFlashVerGrp = BspGetBoardIdInfo();
    INPUT_POINTER_CHECK(pFlashVerGrp);
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_BOARD_ID,type,0,pVerGroup,num);   /*不同整机使用的数组不一样 需要遍历一遍 但是这里没参数会提前返回 所以不能在这里循环*/
    for(loop = 0; loop < num; loop++)
    {
        for(idx = 0; idx < HW_CUSTOM_ID_A; idx++)
        {
            if(pVerGroup[loop].HardId[idx] != pFlashVerGrp->HardId[idx])
            {
                break;
            }
        }
        if(idx == HW_CUSTOM_ID_A)
        {
            break;
        }
    }
    if(loop != num)
    {
         dbgInfo("ModifyBomidPara type %d 0x%x 0x%x 0x%x 0x%x\n",type, pVerGroup[loop].HardId[0],pVerGroup[loop].HardId[1],pVerGroup[loop].HardId[2],pVerGroup[loop].HardId[3]);
         pVerGroup[loop].HardId[HW_CHANGE_ID] = 0xffff;   /*修改参数  让整机匹配不到bomid*/
         pVerGroup[loop].HardId[BRD_TYPE_ID] = 0xffff;
         pVerGroup[loop].HardId[BRD_GROUP_ID] = 0xffff;
         pVerGroup[loop].HardId[MOD_GROUP_ID] = 0xffff;
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:567bf9c8d4r2b5b14d2e095df088271f30a138df */

/* Started by AICoder, pid:qe0c1u631320c5414b760aaee04e79373b06dea9 */
/* 修改寄存器头信息的接口函数 */
UINT32 BspModifyRegHeadInfo(T_Reg_Head *newInfo, UINT32 headLen)
{
    INPUT_POINTER_CHECK(newInfo);

    if (headLen > REG_FUNCDOMAIN_MAX) 
    {
        dbgInfo("[%s] %d >> Invalid headLen: %d (max allowed: %d)!!!\n", __FUNCTION__, __LINE__, headLen, REG_FUNCDOMAIN_MAX);
        return BSP_ERROR;
    }

    /* 更新寄存器头信息 */
    memcpy_s(s_regHeadGroup, sizeof(s_regHeadGroup), newInfo, headLen * sizeof(T_Reg_Head));

    return BSP_OK;
}
/* Ended by AICoder, pid:qe0c1u631320c5414b760aaee04e79373b06dea9 */

/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : digtrxlink_wrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层接口适配单板模型的接口封装实现
* 注意事项 : 无
* 作    者 :   王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2023-03-25
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "digtrxlinkwrapper.h"
#include "boardmodle_ic4_2.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"
#include "chnmapcommon.h"
#include "funccommon_carrmap.h"
#include "j204_ic4_2.h"
#include "boardntl_ic4_2.h"
#include "optctrl_cpri_ic4_2.h"
#include "vxadp.h"
#include "j204_trx.h"
#include "funccommon_a.h"
#include "optadpt.h"
#include "boardreset.h"
#ifndef MULT_PROGRESS_S
#include "sfp.h"
#endif
#include "opt_pcs_api.h"
#include "optctrl_ntl_ic4_2.h"
/**************************************************************************
                            宏定义
**************************************************************************/

#define DIG_TRX_LINK_DATA_FILE_NAME       "DigTrxLinkData.json"
#define SUPPORT_RECOVERY_FLAG                 (1)
#define NO_SUPPORT_RECOVERY_FLAG          (0)
/**************************************************************************
                            公共全局变量
**************************************************************************/
HGOptInitCheckCall g_HGOptBootFlag = NULL;
static T_OPT_SERDES_PCS_PARAM *s_pSerdesPcsInfoCfg = NULL;
static T_BspHalAdaptOptCpriInfo *s_pCpriInfoCfg = NULL;
static T_OPT_L2SSPARA *s_spL2ssInfoBeforeCfg = NULL;
static T_OPT_L2SSPARA *s_spL2ssInfoAfterCfg = NULL;
static CHAR s_interChipLaneFile[32] = "/ata/interchip.txt";
static UINT32 s_recoveryFlag = NO_SUPPORT_RECOVERY_FLAG;
/**************************************************************************
                            内部接口
**************************************************************************/


/**************************************************************************
                            对外接口
**************************************************************************/
UINT32 BspDpdIcDifClkParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_CLK,0,0,pPara,num);
    retVal = BspHalAdaptDifClkParaInit((T_BspHalAdaptDifClkPara *)pPara, CFG_TYPE_HAL_INIT);
    CHECK_RETVAL(BspHalAdaptDifClkParaInit, retVal);
    
    return retVal;    
}

UINT32 BspDpdIcDifSamRateParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_SAMRATE,0,0,pPara,num);
    retVal = BspHalAdaptDifSamRateParaInit((T_BspHalAdaptDifSamRatePara*)pPara);
    CHECK_RETVAL(BspHalAdaptDifSamRateParaInit, retVal);
    
    return retVal;    
}

UINT32 BspDpdIcDifInitParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_CFG,0,0,pPara,num);
    retVal = BspHalAdaptDifParaInit((T_BspHalAdaptDifCfgPara*)pPara);
    CHECK_RETVAL(BspHalAdaptDifParaInit, retVal);                          
    
    return retVal;    
}

/*工装版本资源分配终止频点拓宽15M*/
UINT32 BspWfsResAllocFreqPlus(T_BspHalAdaptDifResAllocPara *pDifPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 dir = TX;
    UINT32 chip = 0;
    UINT32 chnLoop = 0;
    UINT32 bandLoop = 0;
    UINT32 difChan = 0;
    UINT32 txnum = BspGetTxBspChanNum();

    INPUT_POINTER_CHECK(pDifPara);

    for (chnLoop = 0; chnLoop < txnum; chnLoop++)
    {
        retVal |= BspGetDifInfoByBspChn(chnLoop, dir, &chip, &difChan);
        if (BSP_OK != retVal)
        {
            dbgErr("[%s] bspChan[%d] get difchan fail!\n", __FUNCTION__, chnLoop);
            return BSP_ERROR;
        }

        for (bandLoop = 0; bandLoop < pDifPara->tResourceCommPara[difChan].uiTxFreqNum; bandLoop++)
        {
            pDifPara->tResourceCommPara[difChan].tTxFreqPara[bandLoop].uiFreqEnd += 15000;
            dbgInfoEx("[%s] chn'%u, band'%u, txFreqStart'%u, txFreqEnd'%u. \n", __FUNCTION__, difChan, bandLoop,
                    pDifPara->tResourceCommPara[difChan].tTxFreqPara[bandLoop].uiFreqStart,
                    pDifPara->tResourceCommPara[difChan].tTxFreqPara[bandLoop].uiFreqEnd);
        }
    }

    return retVal;
}

UINT32 BspDpdIcDifResAllocParaInit(VOID)
{
    T_DifResourceAllocCommPara s_tDifResAllocPara = {0};
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 chip = 0;
    UINT32 difChan = 0;
    VOID *pPara = NULL;
    UINT32 txnum = BspGetTxBspChanNum();
    UINT32 rxnum = BspGetRxBspChanNum();
    UINT32 maxchannum = 0;
    UINT32 dir = 0;
    UINT32 num = 0;

    if(txnum >= rxnum)
    {
        maxchannum = txnum;
        dir = TX;
    }
    else
    {
        maxchannum = rxnum;
        dir = RX;
    }

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_RESALLOC,0,0,pPara,num);
    for (loop = 0; loop < maxchannum; loop++)
    {
        retVal |= BspGetDifInfoByBspChn(loop, dir, &chip, &difChan);
        if ((BSP_OK != retVal) || (difChan >= BSP_HALADAPT_IC_CHAN_MAX_NUM))
        {
            dbgErr("[%s] bspChan[%d] get difchan fail!\n",
                   __FUNCTION__, loop);
            return retVal;
        }
        if(num == 1)
        {
            memcpy_s(&s_tDifResAllocPara.tResourceCommPara[difChan], sizeof(T_BspHalAdaptDifResAllocChanPara),
                    (T_BspHalAdaptDifResAllocChanPara*)pPara, sizeof(T_BspHalAdaptDifResAllocChanPara));
        }
        else
        {
            if(loop < num)
            {
                memcpy_s(&s_tDifResAllocPara.tResourceCommPara[difChan], sizeof(T_BspHalAdaptDifResAllocChanPara),
                        (T_BspHalAdaptDifResAllocChanPara*)pPara+loop, sizeof(T_BspHalAdaptDifResAllocChanPara));
            }
            else
            {
                continue;
            }
        }
    }

    #ifdef _BSP_WITH_WFS
    if( NOT_QCELL_MODE == BspGetPbOrBbuMode() )
    {
        /* 工装qcell不需要 */
        retVal |= BspWfsResAllocFreqPlus(&s_tDifResAllocPara); /*工装版本资源分配终止频点拓宽15M*/
    }
    #endif

    retVal |= BspHalAdaptDifResourceAllocParaInit(&s_tDifResAllocPara);
    CHECK_RETVAL(BspHalAdaptDifResourceAllocParaInit, retVal);

    return retVal;
}

/* 下行静态路由初始化 */
UINT32 BspDpdicTxRouteMapInit(VOID)
{   
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 chanNum = BspGetTxBspChanNum();
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_TX_ROUTE,0,0,pPara,num);
    retVal = BspHalAdaptDifTxRouteMapInit((T_BspHalAdaptDifTxRouteMap*)pPara, num, chanNum);
    CHECK_RETVAL(BspHalAdaptDifTxRouteMapInit, retVal);

    return retVal;
}

/* 下行静态路由参数初始化 */
UINT32 BspDpdicTxRouteParaInit(VOID)
{   
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 chanNum = BspGetTxBspChanNum();
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_TX_PARA,0,0,pPara,num);
    retVal = BspHalAdaptDifTxRouteParaInit((T_BspHalAdaptDifTxRoutePara*)pPara, num, chanNum);
    CHECK_RETVAL(BspHalAdaptDifTxRouteParaInit, retVal);

    return retVal;    
}

/* 下行J204路由参数初始化 */
UINT32 BspDpdicTxJ204RouteMapInit(VOID)
{   
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 chanNum = BspGetTxBspChanNum();
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_TX_204,0,0,pPara,num);
    retVal = BspHalAdaptDifTx204RouteMapInit((T_BspHalAdaptDifTx204RouteMap*)pPara, num, chanNum);
    CHECK_RETVAL(BspHalAdaptDifTx204RouteMapInit, retVal);

    return retVal;
}

/* 上行静态路由参数初始化 */
UINT32 BspDpdicRxRouteMapInit(VOID)
{   
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 chanNum = BspGetRxBspChanNum();
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_RX_ROUTE,0,0,pPara,num);
    retVal = BspHalAdaptDifRxRouteMapInit((T_BspHalAdaptDifRxRouteMap*)pPara, num, chanNum);
    CHECK_RETVAL(BspHalAdaptDifRxRouteMapInit, retVal);

    return retVal;
}

/* 反馈静态路由参数初始化 */
UINT32 BspDpdicFbRouteMapInit(VOID)
{   
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptDifFbRouteMap *pPara = NULL;
    UINT32 num = 0;
    UINT32 chanNum = BspGetTxBspChanNum();

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_FB_ROUTE,0,0,pPara,num);
    retVal = BspHalAdaptDifFbRouteMapInit(pPara, num, chanNum);
    CHECK_RETVAL(BspHalAdaptDifFbRouteMapInit, retVal);
    return retVal;
}


/* 中频Hal初始化 */
UINT32 BspDpdicDifHalInit(VOID)
{
    UINT32 retVal = BSP_OK;
    
    retVal = BspHalAdaptDifInit();
    CHECK_RETVAL(BspHalAdaptDifInit, retVal);

    return retVal;
}
/* FDD机型需要在单板初始化流程中初始化TDD配置，TDD机型在小区配置过程中动态配置 */
UINT32 BspDpdicDifTddCfg(void)
{
    T_BspHalAdaptCarrTddIndCfg *pPara = NULL;
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;

    retVal = BspBoardModleGetData(E_TRX_LINK_DPDIC_DIF_CFG_TDD, 0, 0, (VOID**)(&pPara), &num);
    if (retVal != BSP_OK)
    {
        return BSP_OK;
    }
    return BspHalAdaptDifCfgTdd_FDD(pPara);
}

/* 下行帧头信息初始化*/
UINT32 BspDpdicDifFrameHeaderInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_FR,0,0,pPara,num);
    retVal = BspHalAdaptSetDifFrInit((T_BspHalAdaptFrInitCfg*)pPara);
    CHECK_RETVAL(BspHalAdaptSetDifFrInit, retVal);

    return retVal;
}

/* 光口CPRI参数初始化 */
UINT32 BspDpdicOptCpriParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptOptCpriInfo *pPara = NULL;
    UINT32 num = 0;
    UINT32 cpuId = 0;

    if(NULL == s_pCpriInfoCfg)
    {
        BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,0,0,pPara,num);
    }
    else
    {
        pPara = s_pCpriInfoCfg;
    }
    retVal = BspHalAdaptOptCpriParamInit(pPara);
    CHECK_RETVAL(BspHalAdaptOptCpriParamInit, retVal);
    if(pPara->uCpuCfgEn == CPU_CFG_DISEN)
    {
        BspSetBlindMapMode(1);
    }
    cpuId = BspGetRpuId();
    if(cpuId != 0)
    {
        BspSetDefMainPhyOpt(pPara->uMainOpt);   /*从片的BspDpdicOptCpriInit要设置默认主光口 从这获取入参*/
    	BspHalAdaptOptCpriCfgCuMasterEn(1);  /*UBR从片配1*/
    }
    return retVal;
}

static UINT32 s_defMainUpPhyOptNo = 0;

UINT32 BspSetDefMainPhyOpt(UINT32 optNo)
{
    s_defMainUpPhyOptNo = optNo;
    return BSP_OK;
}

/* 光口CPRI功能初始化 既有建链又有业务处理，没法适配主从架构，需要hal拆分接口*/
UINT32 BspDpdicOptCpriInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptOptCpriInit();
    CHECK_RETVAL(BspHalAdaptOptCpriInit, retVal);
#ifdef  MULT_PROGRESS_S
    UINT32 rpuId = 0;
    rpuId = BspGetRpuId();
    if(rpuId > 0) /*0表示IC芯片编号为0 不再单独定义宏*/
    {
        BspHalAdaptCpriMapConfig(1,0,s_defMainUpPhyOptNo);   /*从片指定光口cpri的上联口为主光口*/
    }
#else
    UINT32 inDependentFlag = 0xff;
    BspGetCpriModeIndependentFlag(&inDependentFlag);
    if(SERDES_LANE_INDEPENDENT == inDependentFlag)     /*合一lane模式下*/
    {
        BspSetNtlL2ssTrxpEnOrDisBitmap(OPTPCS_ETH);          /*在切25G之前主片需要执行此接口 从片不需要此接口*/
    }
#endif
    return retVal;
}

/* Started by AICoder, pid:he119sc2f6w1dfb14ddd088660e432101f0960fc */
/* 空口帧头选择初始化 */
UINT32 BspDpdicOptMeasParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 mode = 0;
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_MEAS,0,0,pPara,num);
    retVal = BspHalAdaptMeasureInit(*((UINT32*)pPara));
    CHECK_RETVAL(BspHalAdaptMeasureInit, retVal);

    /*关于GF问题给光口下发：PRU连接的是PB还是BBU*/
    mode = BspGetPbOrBbuMode();
    dbgInfoEx("%s >> mode = %d\n",__FUNCTION__,mode);
    retVal = BspHalAdaptSetPbOrBbuMode(mode);

    return retVal;
}
/* Ended by AICoder, pid:he119sc2f6w1dfb14ddd088660e432101f0960fc */

/*从9626 单板下移到公共模块 TDD公共流程使用 指示TDD机型要处理RRU接未配置光口的场景*/
void BspSetCheckRruIdRangeCB(void)
{
    return;
}

/* 规避混合环网拔插光纤偶现误码，导致RRU复位的故障 */
static UINT32 BspSetRstPreInit(VOID)
{
    UINT32 retVal = BSP_OK;
    const UINT32 resetThres = 10;

    retVal |= BspSetCpriCfgResetPdThres(ENABLE, resetThres);
    retVal |= BspSetCpriCfgResetThres(ENABLE, resetThres);
    retVal |= BspSetOptCwNetAlarmMask(LOG_OPT0, 0xFCF);  /* 告警屏蔽的功能，使能如下bit位，增加告警屏蔽控制字的强度 */
    retVal |= BspSetOptCwNetAlarmMask(LOG_OPT1, 0xFCF);  /* 告警屏蔽的功能，使能如下bit位，增加告警屏蔽控制字的强度 */
    retVal |= BspHalAdaptCpriClearCpriRstReq();

    return retVal;
}

UINT32 BspSetCpriCfgIqOpen(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 dualBbuFlag = 0;
    UINT32 logOptLoop = 0;

    dualBbuFlag = BspGetSupportDualBbuFlag();
    if(OPT_NOT_SUPPORT_DUAL_BBU == dualBbuFlag)
    {
        for (logOptLoop = 0; logOptLoop < OPT_MAX; logOptLoop++)
        {
            /* 打开下联逻辑口的上下行数据 */
            IcHalApiCpriCfgIqCloseEn(logOptLoop, DISABLE, RX);
            IcHalApiCpriCfgIqCloseEn(logOptLoop, DISABLE, TX);
        }
    }

    return retVal;
}

/*roe初始化*/
UINT32 BspDpdicOptRoeInit(T_OPT_ROE_INIT_PARA *pRoePara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pRoePara);
    retVal = BspHalAdaptOptRoeInitCfg(pRoePara);  /*ROE初始化从BspHalAdaptOptInit中间抽出来 注意底层将qcell屏掉了 由BspDpdicOptCellInit配置qcell*/

    return retVal;
}

UINT32 BspSetRecoveryFlag(UINT32 flag)
{
    s_recoveryFlag = flag;
    return s_recoveryFlag;
}

UINT32 BspGetRecoveryFlag(void)
{
    return s_recoveryFlag;
}

/*光口内部各模块业务功能初始化*/
UINT32 BspDpdicOptCfgParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 protocol = PROCOTOL_CPRI;
    T_BspHalAdaptOptInitCfgInfo *pPara = NULL;
    UINT32 num = 0;
    T_OPT_ROE_INIT_PARA roePara = {0};
    UINT32 reLoadFlag = 0;
    UINT32 roeProtocol = 0;
    UINT32 workMode = 0;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_HAL_INIT,0,0,pPara,num);
    roeProtocol = BspHalAdaptGetRoeCurProtocol(3);    /*需要放到BspFirstSetProtocol 之前 这里边改了这个值 要先读上一次配置的值判断这次是否需要完全重配*/
    if(BspGetIrCaseCadeCpriFlag() == IR_CASECADE_CPRI_FLAG)
    {
        pPara->optWorkMode = BspFirstSetProtocol();
    }

    retVal = BspHalAdaptOptInit(pPara);
    CHECK_RETVAL_PRN(BspHalAdaptOptInit, retVal);  /*这里只打印 不return 否则光口协议没配置  无法建链*/

    if(pPara->optWorkMode == E_OPT_MODE_IR)
    {
    	BspRegisterCheckRruIdRangeCallBack(BspSetCheckRruIdRangeCB); 
    	protocol = PROCOTOL_IR;
        retVal = BspHalAdaptCpriCfgTransLsarRstReqEn(0,0);  /*原来配置1,0 表示默认转发，现在临时回退成默认值，规避拔掉光纤之后级联整机发生硬复位*/
        CHECK_RETVAL_PRN(BspHalAdaptCpriCfgTransLsarRstReqEn, retVal);
        BspHalAdaptCfgTddLcvEnable(0xf);  /*插拔光纤自适应过程中，存在9.8G和10.1G识别主光口导致恢复钟输出问题,增加LCV告警检测*/
    }
    if(pPara->optWorkMode == E_OPT_MODE_QCELL)
    {
    	protocol = PROCOTOL_QCELL;
    }
    if(pPara->optWorkMode == E_OPT_MODE_NCR)
    {
        protocol = PROCOTOL_NCR;
    }
    if(pPara->optWorkMode == E_OPT_MODE_ROE)
    {
        protocol = PROCOTOL_ROE;
    }
#ifndef MULT_PROGRESS_S  /*FDD需要配置 crc掩码*/
    if(pPara->optWorkMode == E_OPT_MODE_CPRI)
    {
        (VOID)BspSetOptCpriSetCrcMask();
        BspRegisterCheckRruIdRangeCallBack(BspSetCheckRruIdRangeCB);
    }
#endif
#if (defined(BSP_MAKE_VER) || defined(_BSP_WITH_WFS))
    dbgInfoEx("[%s]word = %d\n",__FUNCTION__, workMode);
#else
    if((0 != pPara->reserved[0]) || (BspGetRecoveryFlag() == SUPPORT_RECOVERY_FLAG))
    {
       BspSetOptRingFlag(pPara->reserved[0]);
       if(pPara->optWorkMode == E_OPT_MODE_IR)
       {  /*这里异速率级联复位前一级的时候  不能改 需要区分机型*/
           BspLog(LOG_LEVEL_0,"%s, flag %d\n", __FUNCTION__, BspGetRecoveryFlag());
           BspSetCpriCfgNetTrasMode(0, 0);
           BspSetCpriCfgNetTrasMode(1, 0);
           BspSetCpriCfgNetTrasMode(2, 0);
           BspSetCpriCfgNetTrasMode(3, 0); /*符合分担会配置成交叉转发，切换到其他组网模式需要切成组网模式*/
           BspHalAdaptCpriOptBindSel(2, 0);   /*符合分担时逻辑2，3口数据来源都选择基准光口,其他应该配置为0  切换组网单板初始化软复位光口不执行 funclib执行*/
           BspHalAdaptCpriOptBindSel(3, 0);
           BspSetCpriUlFrameAlignFrSelByMode(2, 2);
           BspSetCpriUlFrameAlignFrSelByMode(3, 2);
           BspSetOptCpriCwOptBindCfg(2, 0);
           BspSetOptCpriCwOptBindCfg(3, 0);
           BspHalAdaptCpriCfgIqCloseEn(2, DISABLE, TX);/* 打开逻辑2，3的下行数据 */
           BspHalAdaptCpriCfgIqCloseEn(3, DISABLE, TX);
           BspHalAdaptCpriCfgOptProperty(2,2,0,0);     /*lane2设置为下联 IR切组网会复位 初始化重新配置成默认*/
           BspSetUpDownLinkOptNum(0, 0, 0);
           /* Started by AICoder, pid:hba98vdcaar053614a99084b70b7b20ff0b5e853 */
               workMode = BspGetDefaultOptWorkMode(0);
               if(BSP_OPT_WORK_MODE_SHARE == workMode)
               {
                   /* 软复位组网模式也恢复到默认级联 */
                   BspSetOptWorkMode(BSP_OPT_WORK_MODE_CASCADE_NORMAL);
               }
           /* Ended by AICoder, pid:hba98vdcaar053614a99084b70b7b20ff0b5e853 */
       }
    }
    if(OPT_SUPPORT_SHARE == BspGetOptShareFlag())
    {
         BspSetBbuPortSpecialFlag(1);
    }
    BspSetOptFrTestModeEn(pPara->reserved[1]);
    BspSetSupportDualBbuFlag(pPara->reserved[2]);
#endif	
    retVal = BspSetOptCpriProtocol(protocol);
    retVal |= BspSetRstPreInit();
    retVal |= BspSetCpriCfgIqOpen();  /*BspSetUpOptDataEn设置的关数据在此处保底恢复*/
    roePara.optWorkMode = pPara->optWorkMode;
    reLoadFlag = BspGetClkAndOptReLoadFlag();
    BspLog(LOG_LEVEL_0,"%s, reLoadFlag %d roeProtocol %d optWorkMode %d\n", __FUNCTION__, reLoadFlag, roeProtocol, roePara.optWorkMode);
#ifndef MULT_PROGRESS_S      /*单片和多片主MGR*/
    /*复位类型判断不需要初始化光口 同时roe生效的协议和当前cpri配置的一样才不需要重配*/
    if((OPT_AND_CLK_NOT_NEED_INIT == reLoadFlag)&&(roePara.optWorkMode == roeProtocol))
    {
        dbgInfo("roe not need initcfg \n");
        BspSetpriorityLinkByPhy0Flag(NOT_TRY_LINK_WITH_PHY0);
    }
    else
    {
        BspSetpriorityLinkByPhy0Flag(TRY_LINK_WITH_PHY0);
        retVal |= BspDpdicOptRoeInit(&roePara);  /*roe初始化*/
    }
    BspHalAdaptCpriInternalLoopback(0,0);
    BspHalAdaptCpriInternalLoopback(1,0);
#else
    if(0 == BspGetRpuId())
    {
        return retVal;   /*主片从MGR不需要 其他从片都固定需要配置*/
    }
    retVal |= BspDpdicOptRoeInit(&roePara);  /*roe初始化*/
#endif
    BspInitChipInterOptAlmEn();   /*此接口要在本接口中BspHalAdaptCpriCfgOptProperty调用之后再执行*/
    return retVal;
}

/* J204c 建链参数初始化 */
UINT32 BspJ204LinkInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_J204LinkPara *pPara = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_204_LINK,0,0,pPara,num);
    retVal = BspJ204LinkParaInit((T_J204LinkPara*)pPara);
    CHECK_RETVAL(BspJ204LinkParaInit, retVal);

    return retVal;
}

/* 光模块配置参数初始化 */
#ifndef MULT_PROGRESS_S
UINT32 BspSfpCfpParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_SfpCfgPara *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_SFP_CFG_PARA,0,0,pPara,num);

    retVal = BspSetSfpCfpPara((T_SfpCfgPara*)pPara, num);
    CHECK_RETVAL(BspSetSfpCfpPara, retVal);

    return retVal;
}
#endif

/* J204c SYSREF参数初始化 */
UINT32 BspJ204SysrefInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptSysrefCfg *pPara = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_204_SYSREF,0,0,pPara,num);
    retVal = BspJ204SysrefParaInit((T_BspHalAdaptSysrefCfg*)pPara);
    CHECK_RETVAL(BspJ204SysrefParaInit, retVal);

    return retVal;
}

/* J204c SYSREF参数初始化 */
UINT32 BspJ204SerdesTxEqInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_J204SerdesTxEqPara *pPara = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_204_TXEQ,0,0,pPara,num);
    retVal = BspJ204SerdesTxEqParaInit((T_J204SerdesTxEqPara*)pPara, num);
    CHECK_RETVAL(BspJ204SerdesTxEqParaInit, retVal);

    return retVal;
}

/* J204c lane映射参数初始化 */
UINT32 BspJ204LinkMapInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_J204TransLinkMapPara *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_204_IC_TRX_LINK_MAP,0,0,pPara,num);
    retVal = BspJ204LinkLaneMapInit((T_J204TransLinkMapPara*)pPara,num);
    CHECK_RETVAL(BspJ204LaneMapInit, retVal);

    return retVal;
}
/**************************************************************************
        光口serdes+pcs参数初始化、及模块功能初始化（主接口+子接口）
**************************************************************************/
/*
    IC做从的场景，ntl主复位应该在用户态前就已释放，故用户态不需要操作
    NTL主复位接口: BspHalAdaptCrmNtlTopSetReset
    NTL PTP目前暂不使用，后期使用时可以通过以下接口进行释放，
    NTL PTP复位接口:BspHalAdaptCrmNtlPtpSetReset
*/
UINT32 g_ulTxRxNtlShareInit = SWITCH_OFF;
//**根据主片flash中文件或者从片ram中的数据 决定是否更在线更新光口初始化相关参数及具体需要更新的参数
UINT32 BspUpdateOptInitParaByFlashOrRam(VOID)
{
    UINT32 *pPara = NULL;
    UINT32 num = 0;
    T_OPT_PATH_PARAM *pParaEx = NULL;
    UINT32 numEx = 0;
    UINT32 routePath = 0xff;
    UINT32 cfgIndex = 0;
    UINT32 retVal = BSP_OK;

    BspHalAdaptSetLaneSavingFlag(0);
#ifndef MULT_PROGRESS_S
    UINT32 inDependentFlag = 0xff;
    retVal = BspGetCpriModeLaneRoutePath(&routePath);    /*主片直接从ata下文件读取  从片要从MO版本恢复出的信息A53ram中获取*/
    retVal |= BspGetCpriModeIndependentFlag(&inDependentFlag);
    dbgInfo("%s routePath %d inDependentFlag %d\n", __func__, routePath, inDependentFlag);
    BspLog(LOG_LEVEL_0,"%s routePath %d inDependentFlag %d\n",__func__, routePath, inDependentFlag);
    if(BSP_OK != retVal)
    {
       return BSP_ERROR;
    }
    if(0 != inDependentFlag)
    {
        return BSP_OK;    /*非合一lane方案  不需要后续流程 1是多条lane 0是合1  为1表示没有这个文件或者文件读出来是1*/
    }
#else
    if(0 == BspGetRpuId())
    {
       return BSP_OK;   /*主片从MGR 不需要此流程*/
    }
    T_CpriModeLaneRoutePara tmpPara = {0};
    retVal = BspGetOptCpriModePathParaFromRam(&tmpPara);   /*这个地方回读的时候要校验magic字段*/
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    routePath = tmpPara.routePath;
    dbgInfo("%s routePath %d\n", __func__, routePath);
    BspLog(LOG_LEVEL_0,"%s routePath %d\n",__func__, routePath);
#endif
    if(routePath > E_PARA_PARA_NUM)
    {
        return BSP_OK;    /*读不到文件里的路径id编号  不需要后续流程*/
    }
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_PATH_PARA,0,0,pPara,num);
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_PATH_PARA,0,1,pParaEx,numEx);
    cfgIndex = pPara[routePath];     /*此路径下的参数编号*/
    dbgInfo("%s cfgIndex %d numEx %d\n", __func__, cfgIndex, numEx);
    BspLog(LOG_LEVEL_0,"%s cfgIndex %d numEx %d\n", __func__, cfgIndex, numEx);
    if(cfgIndex >= numEx)
    {
        return BSP_ERROR;
    }
    s_pSerdesPcsInfoCfg = (T_OPT_SERDES_PCS_PARAM *)malloc(sizeof(T_OPT_SERDES_PCS_PARAM));
    INPUT_POINTER_CHECK(s_pSerdesPcsInfoCfg);
    s_pCpriInfoCfg = (T_BspHalAdaptOptCpriInfo*)malloc(sizeof(T_BspHalAdaptOptCpriInfo));
    INPUT_POINTER_CHECK(s_pCpriInfoCfg);
    s_spL2ssInfoBeforeCfg = (T_OPT_L2SSPARA*)malloc(sizeof(T_OPT_L2SSPARA));
    INPUT_POINTER_CHECK(s_spL2ssInfoBeforeCfg);
    s_spL2ssInfoAfterCfg = (T_OPT_L2SSPARA*)malloc(sizeof(T_OPT_L2SSPARA));
    INPUT_POINTER_CHECK(s_spL2ssInfoAfterCfg);
    BspRecordCpriModeCurRoutePath(routePath);
    memcpy_s(s_pSerdesPcsInfoCfg, sizeof(T_OPT_SERDES_PCS_PARAM), (T_OPT_SERDES_PCS_PARAM *)pParaEx[cfgIndex].pSerdesPcsPara, sizeof(T_OPT_SERDES_PCS_PARAM));
    memcpy_s(s_pCpriInfoCfg, sizeof(T_BspHalAdaptOptCpriInfo), (T_BspHalAdaptOptCpriInfo *)pParaEx[cfgIndex].pCpriInfo, sizeof(T_BspHalAdaptOptCpriInfo));
    memcpy_s(s_spL2ssInfoBeforeCfg, sizeof(T_OPT_L2SSPARA), (T_BspHalAdaptOptCpriInfo *)pParaEx[cfgIndex].pL2ssBeforePara, sizeof(T_OPT_L2SSPARA));
    memcpy_s(s_spL2ssInfoAfterCfg, sizeof(T_OPT_L2SSPARA), (T_BspHalAdaptOptCpriInfo *)pParaEx[cfgIndex].pL2ssAfterPara, sizeof(T_OPT_L2SSPARA));
    dbgInfo("%s cfgIndex %d \n", __func__, cfgIndex);
    if(BspGetRpuId() > 0)
    {
        BspHalAdaptNtlL2ssSetSlaveFlag(1);
    }
    BspHalAdaptSetLaneSavingFlag(1);    //**独立lane时给L2ss下发标志
    return BSP_OK;
}

void showserdespathinfo(void)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK_RETURN(s_pSerdesPcsInfoCfg);
    dbgInfo("laneMask %d\n",s_pSerdesPcsInfoCfg->laneMask);
    for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
    {
#ifndef MULT_PROGRESS_S
       if(BIT_SET(loop)&s_pSerdesPcsInfoCfg->laneMask)
#endif
       {
       dbgInfo("loop %d laneId %d rate %d  chlen %f txEqEn %d eoh0 %d eoh1 %d eoh2 %d eoh3 %d\n",loop, s_pSerdesPcsInfoCfg->serdesParam[loop].laneId,
           s_pSerdesPcsInfoCfg->serdesParam[loop].rate, s_pSerdesPcsInfoCfg->serdesParam[loop].chlen,s_pSerdesPcsInfoCfg->serdesParam[loop].txEqEn,
           s_pSerdesPcsInfoCfg->serdesParam[loop].eoh0, s_pSerdesPcsInfoCfg->serdesParam[loop].eoh1,s_pSerdesPcsInfoCfg->serdesParam[loop].eoh2,s_pSerdesPcsInfoCfg->serdesParam[loop].eoh3);
       }
    }

    for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
    {
#ifndef MULT_PROGRESS_S
        if(BIT_SET(loop)&s_pSerdesPcsInfoCfg->laneMask)
#endif
        {
       dbgInfo("phaseMin %d phaseMax %d uVga %d uCmtermCtrl %d\n", s_pSerdesPcsInfoCfg->serdesRxCfg[loop].phaseMin, s_pSerdesPcsInfoCfg->serdesRxCfg[loop].phaseMax,
           s_pSerdesPcsInfoCfg->serdesRxCfg[loop].uVga, s_pSerdesPcsInfoCfg->serdesRxCfg[loop].uCmtermCtrl);
        }
    }

    for(loop = 0; loop < OPT_SERDES_LANE_MAX_NUM; loop++)
    {
#ifndef MULT_PROGRESS_S
        if(BIT_SET(loop)&s_pSerdesPcsInfoCfg->laneMask)
#endif
        {
        dbgInfo(" uPcsPortIdx %d uEthOrCpri %d(1:cpri 0:eth)\n", s_pSerdesPcsInfoCfg->pcsCfg[loop].uPcsPortIdx, s_pSerdesPcsInfoCfg->pcsCfg[loop].uEthOrCpri);
        }
    }
    dbgInfo("innerLanMask %d\n",s_pSerdesPcsInfoCfg->innerLanMask);
}

void showcpripathinfo(void)
{
    UINT32 loop = 0;
    INPUT_POINTER_CHECK_RETURN(s_pCpriInfoCfg);
    dbgInfo("uQcellEn %d\n",s_pCpriInfoCfg->uQcellEn);
    dbgInfo("uNetMode %d\n",s_pCpriInfoCfg->uNetMode);
    dbgInfo("uCpuCfgEn %d\n",s_pCpriInfoCfg->uCpuCfgEn);
    dbgInfo("uMainOpt %d\n",s_pCpriInfoCfg->uMainOpt);
    dbgInfo("uPhyOptCfgMask 0x%x\n",s_pCpriInfoCfg->uPhyOptCfgMask);
    for(loop = 0; loop < OPT_MAX; loop++)
    {
        if(BIT_SET(loop)&s_pCpriInfoCfg->uPhyOptCfgMask)
        {
            dbgInfo("phy %d uProperty %d uPropertyCfgEn %d uChipInterConn %d\n",loop, s_pCpriInfoCfg->phyOptProp[loop].uProperty,
            s_pCpriInfoCfg->phyOptProp[loop].uPropertyCfgEn,s_pCpriInfoCfg->phyOptProp[loop].uChipInterConn );
        }
    }
    dbgInfo("uLogOptCfgMask 0x%x\n",s_pCpriInfoCfg->uLogOptCfgMask);
    for(loop = 0; loop < OPT_MAX; loop++)
    {
        if(BIT_SET(loop)&s_pCpriInfoCfg->uLogOptCfgMask)
        {
        dbgInfo("log %d uRelationPhyopt %d uBindOptSel %d uFrameAlignPeriod %d\n",loop, s_pCpriInfoCfg->logOptProp[loop].uRelationPhyopt,s_pCpriInfoCfg->logOptProp[loop].uBindOptSel,
            s_pCpriInfoCfg->logOptProp[loop].uFrameAlignPeriod );
        }
    }
    return ;
}

void showl2sspathinfo(void)
{
    INPUT_POINTER_CHECK_RETURN(s_spL2ssInfoBeforeCfg);
    INPUT_POINTER_CHECK_RETURN(s_spL2ssInfoAfterCfg);
    dbgInfo("routepath %d\n", BspGetCpriModeCurrRoutePath());
    dbgInfo("1.25G SGMII: key 0x%llx mask 0x%llx\n", s_spL2ssInfoBeforeCfg->key, s_spL2ssInfoBeforeCfg->mask);
    dbgInfo("25G    CPRI: key 0x%llx mask 0x%llx\n", s_spL2ssInfoAfterCfg->key, s_spL2ssInfoAfterCfg->mask);
}

static char s_sBasicCfgInfo[][40] = {
"cfgindex0 E_PARA_LANE0UP",
"cfgindex1 E_PARA_LANE1UP",
"cfgindex2 E_PARA_LANE2UP",
"cfgindex3 E_PARA_LANE1UP_LANE2DOWN",
"cfgindex4 E_PARA_LANE2UP_LANE1DOWN",
"cfgindex5 E_PARA_LANE1UP_LANE3DOWN",
"cfgindex6 E_PARA_LANE0UP_LANE1DOWN",
"cfgindex7 E_PARA_LANE1UP_LANE23DOWN",
"cfgindex8 E_PARA_LANE2DOWN",
"cfgindex9 E_PARA_LANE3DOWN",
};
/*打印当前IC 使用那条路径 及配置编号*/
UINT32 showpathindex(void)
{
    UINT32 *pPara = NULL;
    UINT32 num = 0;
    UINT32 path = 0xff;
    UINT32 retVal = BSP_OK;
    UINT32 cfgIndex = 0;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_PATH_PARA,0,0,pPara,num);
    path = BspGetCpriModeCurrRoutePath();
    if(0xff == path)
    {
        dbgErr("can not get current patch\n");
        return BSP_ERROR;
    }
    cfgIndex = pPara[path];
    dbgInfo("ic%d currpath %d cfgindex %d %s\n ", BspGetRpuId(),path,cfgIndex,s_sBasicCfgInfo[cfgIndex]);

    return BSP_OK;
}

static char  s_soptpathinfo[][40]= {
   "showserdespathinfo",
   "showcpripathinfo",
   "showl2sspathinfo",
   "showpathindex",
   "BspGetCpriModeCurrRoutePath",
   "showcprioptpara",
   "showpcspara",
   "showserdespara",
   "optpathsw pathNo",
   "showlaneroutebypath pathNo",
   "BspSetLaneRoutePathFromFlash pathNo",
   "setoptpathswen en",
   "testSerdesStatus 0/1(配合soccmd)",
   "testSerdesErr (配合soccmd)",
   "getrambootinfo",
};
void optpathhelp(void)
{
   UINT32 loop = 0;
   for(loop =0 ; loop < NELEMENTS(s_soptpathinfo); loop++ )
   {
        dbgInfo("%s\n",s_soptpathinfo[loop]);
   }
}

UINT32 BspSetNtlL2ssTrxpEnOrDisBitmap(UINT32 mode)
{
    UINT32 retVal = BSP_OK;

    if(OPTPCS_ETH == mode)
    {
         if(NULL != s_spL2ssInfoBeforeCfg)
         {
              BspLog(LOG_LEVEL_0,"%s eth KEY 0x%llx MASK 0x%llx\n",__func__, s_spL2ssInfoBeforeCfg->key,s_spL2ssInfoBeforeCfg->mask);
              retVal = BspHalAdaptNtlL2ssTrxpEnOrDisBitmap(s_spL2ssInfoBeforeCfg->key, s_spL2ssInfoBeforeCfg->mask);
         }
    }
    if(OPTPCS_CPRI == mode)
    {
         if(NULL != s_spL2ssInfoAfterCfg)
         {
              BspLog(LOG_LEVEL_0,"%s cpri KEY 0x%llx MASK 0x%llx\n",__func__,s_spL2ssInfoAfterCfg->key,s_spL2ssInfoAfterCfg->mask);
              retVal = BspHalAdaptNtlL2ssTrxpEnOrDisBitmap(s_spL2ssInfoAfterCfg->key, s_spL2ssInfoAfterCfg->mask);
         }
    }
    return retVal;
}
UINT32 BspNtlTxInit(VOID)
{
    VOID *pPara = NULL;
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;

    BspUpdateOptInitParaByFlashOrRam();
    if(NULL == s_pSerdesPcsInfoCfg)
    {
        BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_TX_SERDES,0,0,pPara,num);
    }
    else
    {
        pPara = s_pSerdesPcsInfoCfg;
    }
#ifndef MULT_PROGRESS_S
    T_optSerdesPcsMap *pParaEx = NULL;
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_TX_SERDES,0,1,pParaEx,num);
    BspSetOptSerdesPcsMap(pParaEx);
#else
    UINT32 savingFlag = 0xf;
    savingFlag = BspHalAdaptGetLaneSavingFlag();
    if(1 == savingFlag)
    {
        if(NULL != s_pSerdesPcsInfoCfg)
        {
            retVal = BspCpriModeNtlSoftInitNew(s_pSerdesPcsInfoCfg);    /*独立lane切换机型 去掉单板插入动作统一在此配置*/
            BspLog(LOG_LEVEL_0,"%s slaveic\n", __func__);
            return retVal;
        }
    }
    UINT32 optWorkMode = 0;
    UINT32 resetflag = 0xf;
    T_OptInitPara optInitPara = {0};

    optWorkMode = BspGetOptWorkMode(0);
    resetflag = BspGetBoardResetType();
    if(BSP_OPT_WORK_MODE_SHARE == optWorkMode)
    {
         if((BSP_RPDC_PWROFF_RESET != resetflag)&&(BSP_OMC_HARD_RESET != resetflag))   /*信令切换之后才会是软复位*/
         {
             BspCpriModeNtlSoftInit();
             IcHalApiSetLycaLoadFwFlag(0,0);    /*保持原有调用 只是使用的lane是动态变化的了 这里是因为从片软复位的时候不加载serdes 但是底层有需要有个加载的状态用于流程*/
             IcHalApiSetLycaLoadFwFlag(0,1);
             optInitPara.optWorkMode = E_OPT_MODE_CPRI;    /*只有qcell有差异 其他机型对L2SS全是cpri 而不是ecpri*/
             BspHalAdaptNtlL2ssSetSlaveFlag(1);
             BspHalAdaptNtlL2ssInit(&optInitPara);   /*软复位不调用BspHalAdaptNtlL2ssInitVlanCfg*/
             BspSetInnerSerdesMonitorSw(0xff);
             g_ulTxRxNtlShareInit = SWITCH_ON;
             BspLog(LOG_LEVEL_0,"%s, resetflag %d\n", __func__, resetflag);
             return BSP_OK;
        }
    }
#endif
    BspQsfpNtlInitCallback(BspQsfpNtlInit);
    retVal = BspNtlInit((T_OPT_SERDES_PCS_PARAM *)pPara);
    return retVal;
}

UINT32 BspNtlRxInit(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspOptSerdesRxInitWithRetry(10);
    return retVal;
}
UINT32 BspOptBootpInit(VOID)   /*临时添加方便高层调试，光口自适应后去掉*/
{
    /* UINT32 phyOptNo = 0; */  /*物理光口和serdes的lane一一对应，但是和光笼子编号可能有交叉*/
    UINT32 retVal = BSP_OK;
    #ifndef MULT_PROGRESS_S
    UINT32 optNo = 0;
    if(NULL != g_HGOptBootFlag)
    {
        for(optNo = 0; optNo < 2; optNo++)
        {
            BspHGSfpCdrWdCheck(optNo, 0);
        }
    }
    #endif
    //BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,0,0,pPara,num);
    //phyOptNo = pPara->uMainOpt;
    //retVal |= BspSetOptSpeed(phyOptNo,BSP_OPT_SPEED_24P33024G);
    //retVal |= BspHalAdaptSetDivClk(0,BSP_OPT_SPEED_24P33024G,40,phyOptNo);//wric(0xd4c00b08+phyOptNo*4,395);   /*BspHalAdaptSetDivClk(BSP_OPT_SPEED_24P33024G,40);*/
    //retVal |= BspHalAdaptSetCrmOptCpriRefClkSoft(phyOptNo);  /*//wric(0xd4c00b28,0x101800);入参是物理主光口的laneid*/
    //retVal |= BspHalAdaptPsyncCfg(2);  /*光口初始化时设置，IcHalPsyncApi, 调试为1 bbu为2*/
    //BspSysMsDelay(3000);
    //retVal |= BspHalAdaptOptCpriCmInit();  /*需要光口锁定之后执行*/
    return retVal;
}
UINT32 BspNtlRxInit_S(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = BspGetRpuId();
    UINT32 resetflag = 0xf;
    if(chipId == 0)
    {
        return BSP_OK;
    }
    /*按内核和L2SS要求ubr的从片关闭端口4 解决多次AC之后从片挂死问题（MO收到AC的消息被冲死）从片复位之后boot会重新打开，IC0本身就关闭在*/
    BspHalAdaptTrxpEnOrDisable(4,0);
    resetflag = BspGetBoardResetType();
    if(SWITCH_ON == g_ulTxRxNtlShareInit)    /*CPRI初始化在前边组网模式改成默认值了 这里和TX保持一致就行*/
    {
         if((BSP_RPDC_PWROFF_RESET != resetflag)&&(BSP_OMC_HARD_RESET != resetflag))
         {
             BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_OFF);
             BspLog(LOG_LEVEL_0,"%s, resetflag %d\n", __func__, resetflag);
             return BSP_OK;     /*负荷分担后单独软复位从片*/
        }
    }
    retVal = BspOptSerdesRxInitWithRetry(1);
    return retVal;
}


UINT32 BspInnerSerdesRxMonitor(VOID)
{
    UINT32 retVal = BSP_OK;
    static INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;
    UINT32 innerLaneMask = BspGetInnerLaneMask();
    if(innerLaneMask == 0)
    {
        return retVal;
    }

    if (lTaskID != ((INT32)BSP_ERROR))
    {
        return BSP_ERROR;
    }

    lTaskID = taskSpawn("BspInnerSerdesRxMonitorThread", 100, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspInnerSerdesRxMonitorThread, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgInfo("!!! Creat BspInnerSerdesRxMonitorThread Error !!!\n");
        dbgInfo("TaskRetVal = %x\n", lTaskID);
        dbgInfo("[1first]ulTaskStack = %d\n", ulTaskStack);
        retVal = BSP_ERROR;
    }
    return retVal;
}
/*多片板内级联的serdes速率配置*/
UINT32 BspBoardInnerCpriSpeedCfg(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptOptCpriInfo *pCpriPara = NULL;
    UINT32 cpriParanum = 0;
    UINT32 laneIndex = 0;
    UINT32 speed = 0x19;

    if(NULL == s_pCpriInfoCfg)
    {
        BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,0,0,pCpriPara,cpriParanum);
    }
    else
    {
        pCpriPara= s_pCpriInfoCfg;
    }
    for(laneIndex = 0; laneIndex < OPT_SERDES_LANE_MAX_NUM; laneIndex++)
    {
        if(BIT_SET(laneIndex)&pCpriPara->uPhyOptCfgMask)
        {
            /*1为芯片间级联*/
            if(pCpriPara->phyOptProp[laneIndex].uChipInterConn == 1 )
            {
                retVal |= BspHalAdaptCpriCfgLineRate(laneIndex,speed);
            }
        }
    }
    return retVal;
}

/* J204c Transceiver回调挂接 */
UINT32 BspJ204TrxCallBackInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_J204TrxCallBackCfg *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,0,0,pPara,num);
    retVal = BspJ204TrxCallBackCfg(pPara,num);

    return retVal;
}

UINT32 BspSetHGOptInitCallBack(HGOptInitCheckCall HGOptInitFlag)
{
    g_HGOptBootFlag = HGOptInitFlag;
    return BSP_OK;
}

/*光口针对单片单板进行的修改*/
UINT32 BspDpdicOptCellInit(VOID)
{
    UINT32 retVal = BSP_OK;
    T_OPT_ROE_INIT_PARA *pPara = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_OPT_CELL_INIT,0,0,pPara,num);
    retVal = BspHalAdaptOptQcellInit(pPara);
    return retVal;  
}

UINT32 BspSetLaneSelfSaveFileFromFlash(UINT32 fieldType, UINT32 value)

{
    CHAR buf[32];
    FILE *file = NULL;
    CHAR *fieldName[5] = {"LaneRoutePath", "LaneRouteTryTimes", "PreFaultPos", "IndependentFlag", "LaneRouteTryDyingWords"};
    CHAR copyFieldName[5][64];
    UINT32 count = 0;
    UINT32 loop = 0;
    INT32 ret = 0;

    file = fopen(s_interChipLaneFile, "r+");
    if (file == NULL) {
        dbgErr("%s open file failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    while (fgets(buf, sizeof(buf), file))
    {
        if(fieldType == count)
        {
            ret = sprintf_s(copyFieldName[count], sizeof(copyFieldName[count]), "%s = %d\n",fieldName[count],value);
            SNPRINTF_S_CHECK(ret, sizeof(copyFieldName[count]));
        }
        else
        {
            (void)zte_strncpy_s(copyFieldName[count],sizeof(copyFieldName[count]), buf, sizeof(buf));
        }
        count ++;
    }
    (VOID)fclose(file);
    ret = remove(s_interChipLaneFile);
    if(BSP_OK != ret)
    {
        dbgInfo("remove interchip.txt file failed!\n");
        return BSP_ERROR;
    }
    file = fopen(s_interChipLaneFile, "w");
    if (NULL == file) {
        dbgErr("%s open file failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    for(loop = 0; loop < count; loop++)
    {
        (VOID)fprintf(file, "%s", copyFieldName[loop]);
    }
    (VOID)fclose(file);
    return BSP_OK;
}

UINT32 BspGetLaneSelfSaveFileFromFlash(UINT32 fieldType, UINT32 *fieldValue)
{
    FILE *pFile = NULL;
    CHAR key[256] =  "";
    CHAR value[256] = "";
    CHAR *fieldName[5] = {"LaneRoutePath", "LaneRouteTryTimes", "PreFaultPos", "IndependentFlag", "LaneRouteTryDyingWords"};

    INPUT_POINTER_CHECK(fieldValue);
    pFile = fopen(s_interChipLaneFile, "r");
    if (pFile == NULL)
    {
        dbgErr("%s open file fail\n",__FUNCTION__);
        return BSP_ERROR;
    }

    while (fscanf(pFile, "%255s = %255s\n", key, value) == 2)
    {
        if(0 == strcmp(key, fieldName[fieldType]))
        {
            *fieldValue = (UINT32)value[0] - 48;
            (VOID)fclose(pFile);
            return BSP_OK;
        }
    }
    (VOID)fclose(pFile);
    return BSP_ERROR;
}

/*2条lane切1条lane需要由高层触发 创建文件底层上电初始化还不知道是那种场景  至于是否增加入参还是默认从path0 开始再讨论*/
UINT32 BspIndependentLaneSelfSaveFileInit(UINT32 path)
{
    UINT32 retVal = BSP_OK;
    FILE *pFile = NULL;

    retVal = BspIsFileExist(s_interChipLaneFile);
    if(BSP_OK == retVal)
    {
        return BSP_OK;
    }
    pFile = fopen(s_interChipLaneFile, "w");
    if (NULL == pFile) {
        dbgErr("%s open %s fiald\n",__FUNCTION__,s_interChipLaneFile);
        return BSP_ERROR;
    }


    (VOID)fprintf(pFile, "LaneRoutePath = %d\n", path);
    (VOID)fprintf(pFile, "LaneRouteTryTimes = 0\n");
    (VOID)fprintf(pFile, "PreFaultPos = 0\n");
    (VOID)fprintf(pFile, "IndependentFlag = 0\n");
    (VOID)fprintf(pFile, "LaneRouteTryDyingWords = 0\n");
    (VOID)fclose(pFile);

    return BSP_OK;
}

/* Started by AICoder, pid:fd4b5yb198h0de3147d1086420e7e326c9453870 */
/*路由改配自救接口*/
VOID BspReCfgTx204Route(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 puiFlag = 1;

    BspHalAdaptCheckTx204Route(&puiFlag);
    if(0 == puiFlag)
    {
        retVal = BspDpdicTxJ204RouteMapInit();
        dbgInfo("[%s] ret:%u\n",__FUNCTION__,retVal);
        BspLog(LOG_LEVEL_0,"[%s] ret:%u\n",__FUNCTION__,retVal);
    }
    return;
}
/* Ended by AICoder, pid:fd4b5yb198h0de3147d1086420e7e326c9453870 */

UINT32 getrambootinfo(VOID)
{
    FILE *file = NULL;
    char buffer[512] = {0};
    UINT32 bytesRead = 0;
    UINT32 offset = 0x2dc00; // 指定的起始位置
    UINT32 loop = 0;

    // 打开文件
    file = fopen("/tmp/ramboot.bin", "r");
    if (file == NULL) {
        dbgInfo("Failed to open file\n");
        return BSP_ERROR;
    }
    // 移动文件指针到指定位置
    if (fseek(file, offset, SEEK_SET) != 0) {
    	dbgInfo("Failed to seek in file\n");
        (VOID)fclose(file);
        return BSP_ERROR;
    }
    // 读取文件内容
    bytesRead = fread(buffer, 1, sizeof(buffer), file);
    if (bytesRead > 0) {
        for(loop = 0 ; loop < bytesRead; loop++)
        {
        	dbgInfo("0x%x ", buffer[loop]);
            if(0 == (loop%16))
            {
            	dbgInfo("\n");
            }
        }
    } else {
    	dbgInfo("Failed to read file\n");
    }
    // 关闭文件
    (VOID)fclose(file);
    return 0;
}

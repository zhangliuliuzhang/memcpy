/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : padCtrl.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了管脚复用配置接口
* 注意事项 : 无
* 作    者 : 10279092
* 创建日期 : 2022-02-22
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------*/
#include "boardpad_ic4_2.h"
#include "exprn.h"
#include "padctrl_ic4_2.h"
#include "ichaladapt_ic4_2.h"

/**************************************************************************
 *                        宏
 **************************************************************************/


/**************************************************************************
 *                        全局变量
 **************************************************************************/

/*---------------------1.8V通用管脚寄存器概述-----------------------------
 1.8V通用管脚寄存器概述
31:11     10:9      8           7   6   5   4   3   2   1   0
R         R/W       R/W         R/W R/W R/W R/W R/W R/W R/W R/W
Reserved  func_sel  config_done DS3 DS2 DS1 DS0 PS  PE  SL  ST
-----------------------3.3V通用管脚寄存器概述-----------------------------
31:11     10:9      8           7         6   5   4   3   2   1   0
R         R/W       R/W         R         R/W R/W R/W R/W R/W R/W R/W
Reserved  func_sel  config_done Reserved  DS3 DS2 DS1 DS0 PU  PD  ST
---------------------------------------------------------------------*/
T_GpioPadInfo gpioPadInfo[E_HalPadName_Max] =
{
        /*REG0*/
        BSP_SET_PAD_REG_TBL(O_SOC_25M_CLK,       "O_SOC_25M_CLK,       ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_EVM_10M_CLK,       "O_EVM_10M_CLK,       ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_REC_RST_N,         "I_REC_RST_N,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_EXT_RST_N,         "I_EXT_RST_N,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RMT_HD_RST_N,      "O_RMT_HD_RST_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_PWR_RESTART_3V3,   "O_PWR_RESTART_3V3,   ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x0,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(O_CPU_RST_N,         "O_CPU_RST_N,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_PWR_UV_12V,        "I_PWR_UV_12V,        ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_PWR_UV_48V,        "I_PWR_UV_48V,        ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_PWR_PD_48V_3V3,    "I_PWR_PD_48V_3V3,    ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(I_N8V_ALM_N_3V3,     "I_N8V_ALM_N_3V3,     ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x1,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(I_28V_48V_CHECK,     "I_28V_48V_CHECK,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_48V_EN_3V3,        "O_48V_EN_3V3,        ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x0,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(I_DAT_OFF,           "I_DAT_OFF,           ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_PA_OFF,            "I_PA_OFF,            ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_AC_SYNC_FR,       "IO_AC_SYNC_FR,       ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_PWR_OVER_LOAD,     "I_PWR_OVER_LOAD,     ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_1PPS_OUT,          "O_1PPS_OUT,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_1PPS_IN_GPS,       "I_1PPS_IN_GPS,       ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_1PPS_IN_RCV,       "I_1PPS_IN_RCV,       ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_FSYNC_OUT,         "O_FSYNC_OUT,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_FSYNC_IN,          "I_FSYNC_IN,          ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_PTP_TRIG,         "IO_PTP_TRIG,         ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_FR_INDEX,          "O_FR_INDEX,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_CHIP_SYNC_OUT,     "O_CHIP_SYNC_OUT,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_A53_UART_TXD,      "O_A53_UART_TXD,      ",PAD_GPIO_1_8V,  0,   0,    0x2,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_A53_UART_RXD,      "I_A53_UART_RXD,      ",PAD_GPIO_1_8V,  0,   0,    0x2,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_UART1_TXD_3V3,     "O_UART1_TXD_3V3,     ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(I_UART1_RXD_3V3,     "I_UART1_RXD_3V3,     ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(O_UART2_TXD,         "O_UART2_TXD,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_UART2_RXD,         "I_UART2_RXD,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_UART3_TXD,         "O_UART3_TXD,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_UART3_RXD,         "I_UART3_RXD,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_UART4_TXD,         "O_UART4_TXD,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_UART4_RXD,         "I_UART4_RXD,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_M0_UART_TXD,       "O_M0_UART_TXD,       ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_M0_UART_RXD,       "I_M0_UART_RXD,       ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_CLK_SPI_CS_N,      "O_CLK_SPI_CS_N,      ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_CLK_SPI_CLK,       "O_CLK_SPI_CLK,       ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_CLK_SPI_TX,        "O_CLK_SPI_TX,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_CLK_SPI_RX,        "I_CLK_SPI_RX,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_CLK_LD0,           "I_CLK_LD0,           ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_CLK_LD1,           "I_CLK_LD1,           ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI6_CS_N,         "O_SPI6_CS_N,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI6_CLK,          "O_SPI6_CLK,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_SPI6_SDIO,        "IO_SPI6_SDIO,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_SPI6_SDO,          "I_SPI6_SDO,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI0_IO0,        "IO_QSPI0_IO0,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI0_IO1,        "IO_QSPI0_IO1,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI0_IO2,        "IO_QSPI0_IO2,        ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI0_IO3,        "IO_QSPI0_IO3,        ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(O_QSPI0_SCLK_OUT,    "O_QSPI0_SCLK_OUT,    ",PAD_GPIO_1_8V,  1,   1,    0x1,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(O_QSPI0_CS0_N,       "O_QSPI0_CS0_N,       ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(O_QSPI0_CS1_N,       "O_QSPI0_CS1_N,       ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x8,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI1_IO0,        "IO_QSPI1_IO0,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI1_IO1,        "IO_QSPI1_IO1,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI1_IO2,        "IO_QSPI1_IO2,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_QSPI1_IO3,        "IO_QSPI1_IO3,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    1,    1),
        BSP_SET_PAD_REG_TBL(O_QSPI1_SCLK_OUT,    "O_QSPI1_SCLK_OUT,    ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x8,    2,    1),
        BSP_SET_PAD_REG_TBL(O_QSPI1_CS0_N,       "O_QSPI1_CS0_N,       ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    2,    1),
        BSP_SET_PAD_REG_TBL(O_QSPI1_CS1_N,       "O_QSPI1_CS1_N,       ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x8,    2,    1),
        BSP_SET_PAD_REG_TBL(IO_CRM_IIC_SDA_3V3,  "IO_CRM_IIC_SDA_3V3,  ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_CRM_IIC_SCL_3V3,  "IO_CRM_IIC_SCL_3V3,  ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC0_SDA,         "IO_IIC0_SDA,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC0_SCL,         "IO_IIC0_SCL,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_JTAG_TCK,          "I_JTAG_TCK,          ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_JTAG_TMS,          "I_JTAG_TMS,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_JTAG_TDI,          "I_JTAG_TDI,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_JTAG_TDO,          "O_JTAG_TDO,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_JTAG_SEL0,         "I_JTAG_SEL0,         ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_JTAG_SEL1,         "I_JTAG_SEL1,         ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_MDIO_DAT,         "IO_MDIO_DAT,         ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_MDIO_CK,           "O_MDIO_CK,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_0,           "IO_GPIO_0,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_1,           "IO_GPIO_1,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_2,           "IO_GPIO_2,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_3,           "IO_GPIO_3,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_4,           "IO_GPIO_4,           ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_5,           "IO_GPIO_5,           ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_6,           "IO_GPIO_6,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_7,           "IO_GPIO_7,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_8,           "IO_GPIO_8,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_9,           "IO_GPIO_9,           ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_10,          "IO_GPIO_10,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_11,          "IO_GPIO_11,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_12,          "IO_GPIO_12,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_13,          "IO_GPIO_13,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_14,          "IO_GPIO_14,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_15,          "IO_GPIO_15,          ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_22_3V3,      "IO_GPIO_22_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_23_3V3,      "IO_GPIO_23_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_24_3V3,      "IO_GPIO_24_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_25_3V3,      "IO_GPIO_25_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN4_N,      "O_RX_LNA_EN4_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN5_N,      "O_RX_LNA_EN5_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN6_N,      "O_RX_LNA_EN6_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN7_N,      "O_RX_LNA_EN7_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_PRX_SW0_V1,        "O_PRX_SW0_V1,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_PRX_SW0_V2,        "O_PRX_SW0_V2,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_PRX_SW0_V3,        "O_PRX_SW0_V3,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_PRX_SW1_V1,        "O_PRX_SW1_V1,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_PRX_SW1_V2,        "O_PRX_SW1_V2,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_PRX_SW1_V3,        "O_PRX_SW1_V3,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC1_CTRL_TX_AC_SW, "O_AC1_CTRL_TX_AC_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC1_CTRL_RX_AC_SW, "O_AC1_CTRL_RX_AC_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC1_CTRL_TX_RX_SW, "O_AC1_CTRL_TX_RX_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC2_CTRL_TX_AC_SW, "O_AC2_CTRL_TX_AC_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC2_CTRL_RX_AC_SW, "O_AC2_CTRL_RX_AC_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC2_CTRL_TX_RX_SW, "O_AC2_CTRL_TX_RX_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN4,     "O_TX_PA_AMP_EN4,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN5,     "O_TX_PA_AMP_EN5,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN6,     "O_TX_PA_AMP_EN6,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN7,     "O_TX_PA_AMP_EN7,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_SPI2_SDO,          "I_SPI2_SDO,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_SPI2_SDIO,        "IO_SPI2_SDIO,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI2_CLK,          "O_SPI2_CLK,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI2_CS0_N,        "O_SPI2_CS0_N,        ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI2_CS1_N,        "O_SPI2_CS1_N,        ",PAD_GPIO_1_8V,  0,   0,    0x3,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_RST_N,        "O_TRX1_RST_N,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_SPI4_SDIO,        "IO_SPI4_SDIO,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI4_SCLK,         "O_SPI4_SCLK,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI4_CS_N,         "O_SPI4_CS_N,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_ORX_MODE0,    "O_TRX1_ORX_MODE0,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_ORX_MODE1,    "O_TRX1_ORX_MODE1,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_ORX_MODE2,    "O_TRX1_ORX_MODE2,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(I_TRX1_GAIN_FRAME,   "I_TRX1_GAIN_FRAME,   ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX1_GAIN_CLK,     "I_TRX1_GAIN_CLK,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX1_GAIN_DATA,    "I_TRX1_GAIN_DATA,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_VGA_FRAME,    "O_TRX1_VGA_FRAME,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_VGA_CLK,      "O_TRX1_VGA_CLK,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_VGA_DATA,     "O_TRX1_VGA_DATA,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX1_ALARM0,       "I_TRX1_ALARM0,       ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX1_ALARM1,       "I_TRX1_ALARM1,       ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_TX_AC_RXATT,  "O_TRX1_TX_AC_RXATT,  ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX1_RX_AC_TXATT,  "O_TRX1_RX_AC_TXATT,  ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX1_BBFRAME,       "O_RX1_BBFRAME,       ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(O_TX1_BBFRAME,       "O_TX1_BBFRAME,       ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RSV2,          "O_TRX_RSV2,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RSV3,          "O_TRX_RSV3,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RX_EN2,        "O_TRX_RX_EN2,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RX_EN3,        "O_TRX_RX_EN3,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        /*REG1*/
        BSP_SET_PAD_REG_TBL(I_SERDES0_LOP_3V3,   "I_SERDES0_LOP_3V3,   ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x1,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SERDES0_TX_DIS_3V3,"O_SERDES0_TX_DIS_3V3,",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x0,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(I_SERDES1_LOP_3V3,   "I_SERDES1_LOP_3V3,   ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x1,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SERDES1_TX_DIS_3V3,"O_SERDES1_TX_DIS_3V3,",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x0,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(I_IIC_UART_ID_3V3,   "I_IIC_UART_ID_3V3,   ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x0,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC1_SDA_3V3,     "IO_IIC1_SDA_3V3,     ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC1_SCL_3V3,     "IO_IIC1_SCL_3V3,     ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC2_SDA_3V3,     "IO_IIC2_SDA_3V3,     ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC2_SCL_3V3,     "IO_IIC2_SCL_3V3,     ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_16,          "IO_GPIO_16,          ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_17_3V3,      "IO_GPIO_17_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_18_3V3,      "IO_GPIO_18_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_19_3V3,      "IO_GPIO_19_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_20_3V3,      "IO_GPIO_20_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_21_3V3,      "IO_GPIO_21_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_26,          "IO_GPIO_26,          ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_27,          "IO_GPIO_27,          ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_28_3V3,      "IO_GPIO_28_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_29_3V3,      "IO_GPIO_29_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_30_3V3,      "IO_GPIO_30_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_31_3V3,      "IO_GPIO_31_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_32_3V3,      "IO_GPIO_32_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_33_3V3,      "IO_GPIO_33_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_GPIO_34_3V3,      "IO_GPIO_34_3V3,      ",PAD_GPIO_3_3V,  0,BSP_INVALID_VALUE,    0x2,    0x2,    0,    1),
        /*REG2*/
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN0_N,      "O_RX_LNA_EN0_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN1_N,      "O_RX_LNA_EN1_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN2_N,      "O_RX_LNA_EN2_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(O_RX_LNA_EN3_N,      "O_RX_LNA_EN3_N,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC3_SDA,         "IO_IIC3_SDA,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC3_SCL,         "IO_IIC3_SCL,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC4_SDA,         "IO_IIC4_SDA,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC4_SCL,         "IO_IIC4_SCL,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC5_SDA,         "IO_IIC5_SDA,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(IO_IIC5_SCL,         "IO_IIC5_SCL,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    1,    1),
        BSP_SET_PAD_REG_TBL(O_AC0_CTRL_TX_AC_SW, "O_AC0_CTRL_TX_AC_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC0_CTRL_RX_AC_SW, "O_AC0_CTRL_RX_AC_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_AC0_CTRL_TX_RX_SW, "O_AC0_CTRL_TX_RX_SW, ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN0,        "O_TRX_TX_EN0,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN1,        "O_TRX_TX_EN1,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN2,        "O_TRX_TX_EN2,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN3,        "O_TRX_TX_EN3,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN4,        "O_TRX_TX_EN4,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN5,        "O_TRX_TX_EN5,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN6,        "O_TRX_TX_EN6,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_TX_EN7,        "O_TRX_TX_EN7,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN0,     "O_TX_PA_AMP_EN0,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN1,     "O_TX_PA_AMP_EN1,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN2,     "O_TX_PA_AMP_EN2,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX_PA_AMP_EN3,     "O_TX_PA_AMP_EN3,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_RST_N,        "O_TRX0_RST_N,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(IO_SPI3_SDIO,        "IO_SPI3_SDIO,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI3_SCLK,         "O_SPI3_SCLK,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_SPI3_CS_N,         "O_SPI3_CS_N,         ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_ORX_MODE0,    "O_TRX0_ORX_MODE0,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_ORX_MODE1,    "O_TRX0_ORX_MODE1,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_ORX_MODE2,    "O_TRX0_ORX_MODE2,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_ORX_MODE3,    "O_TRX0_ORX_MODE3,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX0_GAIN_FRAME,   "I_TRX0_GAIN_FRAME,   ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX0_GAIN_CLK,     "I_TRX0_GAIN_CLK,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX0_GAIN_DATA,    "I_TRX0_GAIN_DATA,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_VGA_FRAME,    "O_TRX0_VGA_FRAME,    ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_VGA_CLK,      "O_TRX0_VGA_CLK,      ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_VGA_DATA,     "O_TRX0_VGA_DATA,     ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX0_ALARM0,       "I_TRX0_ALARM0,       ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(I_TRX0_ALARM1,       "I_TRX0_ALARM1,       ",PAD_GPIO_1_8V,  0,   0,    0x1,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_TX_AC_RXATT,  "O_TRX0_TX_AC_RXATT,  ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX0_RX_AC_TXATT,  "O_TRX0_RX_AC_TXATT,  ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TX0_BBDV,          "O_TX0_BBDV,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_RX0_BBDV,          "O_RX0_BBDV,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RSV0,          "O_TRX_RSV0,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RSV1,          "O_TRX_RSV1,          ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RX_EN0,        "O_TRX_RX_EN0,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
        BSP_SET_PAD_REG_TBL(O_TRX_RX_EN1,        "O_TRX_RX_EN1,        ",PAD_GPIO_1_8V,  0,   0,    0x0,    0x5,    0,    1),
};

UINT32 padGpioName[] =
{
        O_SOC_25M_CLK,
        O_EVM_10M_CLK,
        I_REC_RST_N,
        I_EXT_RST_N,
        O_RMT_HD_RST_N,
        O_PWR_RESTART_3V3,
        O_CPU_RST_N,
        I_PWR_UV_12V,
        I_PWR_UV_48V,
        I_PWR_PD_48V_3V3,
        I_N8V_ALM_N_3V3,
        I_28V_48V_CHECK,
        O_48V_EN_3V3,
        I_DAT_OFF,
        I_PA_OFF,
        IO_AC_SYNC_FR,
        I_PWR_OVER_LOAD,
        O_1PPS_OUT,
        I_1PPS_IN_GPS,
        I_1PPS_IN_RCV,
        O_FSYNC_OUT,
        I_FSYNC_IN,
        IO_PTP_TRIG,
        O_FR_INDEX,
        O_CHIP_SYNC_OUT,
        O_A53_UART_TXD,
        I_A53_UART_RXD,
        O_UART1_TXD_3V3,
        I_UART1_RXD_3V3,
        O_UART2_TXD,
        I_UART2_RXD,
        O_UART3_TXD,
        I_UART3_RXD,
        O_UART4_TXD,
        I_UART4_RXD,
        O_M0_UART_TXD,
        I_M0_UART_RXD,
        O_CLK_SPI_CS_N,
        O_CLK_SPI_CLK,
        O_CLK_SPI_TX,
        I_CLK_SPI_RX,
        I_CLK_LD0,
        I_CLK_LD1,
        O_SPI6_CS_N,
        O_SPI6_CLK,
        IO_SPI6_SDIO,
        I_SPI6_SDO,
        IO_QSPI0_IO0,
        IO_QSPI0_IO1,
        IO_QSPI0_IO2,
        IO_QSPI0_IO3,
        O_QSPI0_SCLK_OUT,
        O_QSPI0_CS0_N,
        O_QSPI0_CS1_N,
        IO_QSPI1_IO0,
        IO_QSPI1_IO1,
        IO_QSPI1_IO2,
        IO_QSPI1_IO3,
        O_QSPI1_SCLK_OUT,
        O_QSPI1_CS0_N,
        O_QSPI1_CS1_N,
        IO_CRM_IIC_SDA_3V3,
        IO_CRM_IIC_SCL_3V3,
        IO_IIC0_SDA,
        IO_IIC0_SCL,
        I_JTAG_TCK,
        I_JTAG_TMS,
        I_JTAG_TDI,
        O_JTAG_TDO,
        I_JTAG_SEL0,
        I_JTAG_SEL1,
        IO_MDIO_DAT,
        O_MDIO_CK,
        IO_GPIO_0,
        IO_GPIO_1,
        IO_GPIO_2,
        IO_GPIO_3,
        IO_GPIO_4,
        IO_GPIO_5,
        IO_GPIO_6,
        IO_GPIO_7,
        IO_GPIO_8,
        IO_GPIO_9,
        IO_GPIO_10,
        IO_GPIO_11,
        IO_GPIO_12,
        IO_GPIO_13,
        IO_GPIO_14,
        IO_GPIO_15,
        IO_GPIO_22_3V3,
        IO_GPIO_23_3V3,
        IO_GPIO_24_3V3,
        IO_GPIO_25_3V3,
        O_RX_LNA_EN4_N,
        O_RX_LNA_EN5_N,
        O_RX_LNA_EN6_N,
        O_RX_LNA_EN7_N,
        O_PRX_SW0_V1,
        O_PRX_SW0_V2,
        O_PRX_SW0_V3,
        O_PRX_SW1_V1,
        O_PRX_SW1_V2,
        O_PRX_SW1_V3,
        O_AC1_CTRL_TX_AC_SW,
        O_AC1_CTRL_RX_AC_SW,
        O_AC1_CTRL_TX_RX_SW,
        O_AC2_CTRL_TX_AC_SW,
        O_AC2_CTRL_RX_AC_SW,
        O_AC2_CTRL_TX_RX_SW,
        O_TX_PA_AMP_EN4,
        O_TX_PA_AMP_EN5,
        O_TX_PA_AMP_EN6,
        O_TX_PA_AMP_EN7,
        I_SPI2_SDO,
        IO_SPI2_SDIO,
        O_SPI2_CLK,
        O_SPI2_CS0_N,
        O_SPI2_CS1_N,
        O_TRX1_RST_N,
        IO_SPI4_SDIO,
        O_SPI4_SCLK,
        O_SPI4_CS_N,
        O_TRX1_ORX_MODE0,
        O_TRX1_ORX_MODE1,
        O_TRX1_ORX_MODE2,
        I_TRX1_GAIN_FRAME,
        I_TRX1_GAIN_CLK,
        I_TRX1_GAIN_DATA,
        O_TRX1_VGA_FRAME,
        O_TRX1_VGA_CLK,
        O_TRX1_VGA_DATA,
        I_TRX1_ALARM0,
        I_TRX1_ALARM1,
        O_TRX1_TX_AC_RXATT,
        O_TRX1_RX_AC_TXATT,
        O_RX1_BBFRAME,
        O_TX1_BBFRAME,
        O_TRX_RSV2,
        O_TRX_RSV3,
        O_TRX_RX_EN2,
        O_TRX_RX_EN3,
        //reg1
        I_SERDES0_LOP_3V3,
        O_SERDES0_TX_DIS_3V3,
        I_SERDES1_LOP_3V3,
        O_SERDES1_TX_DIS_3V3,
        I_IIC_UART_ID_3V3,
        IO_IIC1_SDA_3V3,
        IO_IIC1_SCL_3V3,
        IO_IIC2_SDA_3V3,
        IO_IIC2_SCL_3V3,
        IO_GPIO_16,
        IO_GPIO_17_3V3,
        IO_GPIO_18_3V3,
        IO_GPIO_19_3V3,
        IO_GPIO_20_3V3,
        IO_GPIO_21_3V3,
        IO_GPIO_26,
        IO_GPIO_27,
        IO_GPIO_28_3V3,
        IO_GPIO_29_3V3,
        IO_GPIO_30_3V3,
        IO_GPIO_31_3V3,
        IO_GPIO_32_3V3,
        IO_GPIO_33_3V3,
        IO_GPIO_34_3V3,
        //reg2
        O_RX_LNA_EN0_N,
        O_RX_LNA_EN1_N,
        O_RX_LNA_EN2_N,
        O_RX_LNA_EN3_N,
        IO_IIC3_SDA,
        IO_IIC3_SCL,
        IO_IIC4_SDA,
        IO_IIC4_SCL,
        IO_IIC5_SDA,
        IO_IIC5_SCL,
        O_AC0_CTRL_TX_AC_SW,
        O_AC0_CTRL_RX_AC_SW,
        O_AC0_CTRL_TX_RX_SW,
        O_TRX_TX_EN0,
        O_TRX_TX_EN1,
        O_TRX_TX_EN2,
        O_TRX_TX_EN3,
        O_TRX_TX_EN4,
        O_TRX_TX_EN5,
        O_TRX_TX_EN6,
        O_TRX_TX_EN7,
        O_TX_PA_AMP_EN0,
        O_TX_PA_AMP_EN1,
        O_TX_PA_AMP_EN2,
        O_TX_PA_AMP_EN3,
        O_TRX0_RST_N,
        IO_SPI3_SDIO,
        O_SPI3_SCLK,
        O_SPI3_CS_N,
        O_TRX0_ORX_MODE0,
        O_TRX0_ORX_MODE1,
        O_TRX0_ORX_MODE2,
        O_TRX0_ORX_MODE3,
        I_TRX0_GAIN_FRAME,
        I_TRX0_GAIN_CLK,
        I_TRX0_GAIN_DATA,
        O_TRX0_VGA_FRAME,
        O_TRX0_VGA_CLK,
        O_TRX0_VGA_DATA,
        I_TRX0_ALARM0,
        I_TRX0_ALARM1,
        O_TRX0_TX_AC_RXATT,
        O_TRX0_RX_AC_TXATT,
        O_TX0_BBDV,
        O_RX0_BBDV,
        O_TRX_RSV0,
        O_TRX_RSV1,
        O_TRX_RX_EN0,
        O_TRX_RX_EN1,
};

T_LvdsGpioPadInfo padLvdsGpioInfo[] =
{
        {O_SYSREF1_P_N, "O_SYSREF1_P_N", PAD_GPIO_LVDS, 0, 0 },
        {O_SYSREF0_P_N, "O_SYSREF0_P_N", PAD_GPIO_LVDS, 0, 0 }
};

T_LvdsCfgInfo padLvdsCfgInfo[] =
{
        {O_CPRI_REV_P_N,      "O_CPRI_REV_P_N    ", PAD_GPIO_LVDS, 0x72281},
        {O_SYSREF1_P_N,       "O_SYSREF1_P_N     ", PAD_GPIO_LVDS, 0x72281},
        {I_CHIP_SYNC_INP_N,   "I_CHIP_SYNC_INP_N ", PAD_GPIO_LVDS, 0x40ac1},
        {O_SYSREF0_P_N,       "O_SYSREF0_P_N     ", PAD_GPIO_LVDS, 0x72281}
};

/**************************************************************************
*                         函数声明
**************************************************************************/
static UINT32 BspPadFuncInit(VOID);
static UINT32 BspCfgLvdsPin(void);
static UINT32 BspModifyPadFunc(T_GpioPadInfoModify *gpioModifyPadInfo, UINT32 modifyNum);
/**************************************************************************
*                         函数实现
**************************************************************************/

/**********************************************************************
* 函数名称: BspPadFuncInit
* 功能描述: 系列单板pad功能初始化
* 输入参数: 无
* 输出参数: 无
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 BspPadFuncInit(void)
{
    UINT32 retVal                  = BSP_OK;
    UINT32 padNum                  = 0;
    UINT32 padInfoNum              = 0;

    padNum     = NELEMENTS(padGpioName);
    padInfoNum = NELEMENTS(gpioPadInfo);
    dbgInfoEx("%s: PadGpioName is [%d],gpioPadInfo is [%d]\n",__FUNCTION__,padNum,padInfoNum);

    retVal |= BspMountPadPointer();
    retVal |= BspInitAllPadGpio(gpioPadInfo, padInfoNum, padGpioName, padNum);
    retVal |= BspCfgLvdsPin();

    CHECK_RETVAL(BspPadFuncInit, retVal);

    return retVal;
}

static UINT32 BspCfgLvdsPin(void)
{
    UINT32 LVdsCfgNum = 0;
    UINT32 loop       = 0;
    UINT32 retVal     = BSP_OK;
    UINT32 lvdsNum    = 0;

    LVdsCfgNum = NELEMENTS(padLvdsCfgInfo);
    for(loop = 0; loop < LVdsCfgNum; loop ++)
    {
        retVal |= BspHalSetLvdsCfg(padLvdsCfgInfo[loop].padName, padLvdsCfgInfo[loop].lvdsCfgVal);
    }

    lvdsNum = NELEMENTS(padLvdsGpioInfo);
    /*差分管脚复用功能配置*/
    for(loop = 0; loop < lvdsNum; loop ++)
    {
        retVal  |= BspLvdsPinInit(padLvdsGpioInfo[loop].padName,
                padLvdsGpioInfo[loop].lvdsFrameHead,padLvdsGpioInfo[loop].lvdsFuncSel);
    }

    return retVal;
}

/**********************************************************************
* 函数名称: BspModifyPadFunc
* 功能描述: 系列单板修改pad功能选择接口
* 输入参数: 无
* 输出参数: 无
* 说       明: 无
* 返  回  值: BSP_OK / BSP_ERROR
************************************************************************/
static UINT32 BspModifyPadFunc(T_GpioPadInfoModify *gpioModifyPadInfo, UINT32 modifyNum)
{
    UINT32 loop        = 0;
    UINT32 padRegName  = 0;

    if(gpioModifyPadInfo == NULL)
    {
        dbgInfoEx("[%s]: The PAD base table is used and does not need to be modified.\n", __FUNCTION__);
        return BSP_OK;
    }

    for(loop = 0; loop < modifyNum; loop ++)
    {
        padRegName = gpioModifyPadInfo[loop].padName;
        gpioPadInfo[padRegName].padStCfg    = gpioModifyPadInfo[loop].padStCfg;
        gpioPadInfo[padRegName].padSlCfg    = gpioModifyPadInfo[loop].padSlCfg;
        gpioPadInfo[padRegName].padPullCfg  = gpioModifyPadInfo[loop].padPullCfg;
        gpioPadInfo[padRegName].padDsCfg    = gpioModifyPadInfo[loop].padDsCfg;
        gpioPadInfo[padRegName].padCfgDone  = gpioModifyPadInfo[loop].padCfgDone;
        gpioPadInfo[padRegName].padFuncSel  = gpioModifyPadInfo[loop].padFuncSel;
    }

    return BSP_OK;
}

UINT32 BspBoardPadInit(T_GpioPadInfoModify *gpioModifyPadInfo, UINT32 modifyNum)
{
    UINT32 retVal = BSP_OK;

    if(gpioModifyPadInfo == NULL)
    {
        dbgInfoEx("[%s]: Use pad base table.\n", __FUNCTION__);
    }

    retVal |= BspModifyPadFunc(gpioModifyPadInfo, modifyNum);
    retVal |= BspPadFuncInit();

    return retVal;
}

/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pwrsave_common.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了通道关断和载波关断的接口
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "pwrsave_common.h"
#include "pa_ic4_2_ctrl.h"
#include "ichaladaptbspapi.h"
#include "rruinfo.h"
#include "chnmapcommon.h"
#include "exprn.h"
#include "dpd_app.h"
#include "j204_common.h"
#include "rftable_pabasicinfo.h"
#include "dpd_app.h"
#include "hardfeaturewrapperrfctrl.h"
#include "pwr_a.h"
#include "devdrv_pwr.h"
#include "regdrv_accesstbl.h"
#include "regdrv_access.h"
/**************************************************************************
*                                宏定义                                      *
**************************************************************************/

#define TRX_MAX_NUM (8)
#define DGB_CHAN_MAX_NUM (32)

/**************************************************************************
*                            全局变量定义                                       *
**************************************************************************/
static UINT32 s_PwrSaveMode = 1; /* 1是开启，0是关闭 默认关闭 */
static UINT32 s_PwrSaveDeepSleepStat = 0; /* 是否进入深度休眠 */
static UINT32 s_dbgDtxEnableChanMask = 0;
static UINT8 s_dbgDtxRouteStatus[DGB_CHAN_MAX_NUM] = {0};
static UINT8 s_dbgTxCarrIcPwrSaveSwMask[DGB_CHAN_MAX_NUM] = {0};
static UINT8 s_dbgRxCarrIcPwrSaveSwMask[DGB_CHAN_MAX_NUM] = {0};
static UINT32 s_mtsResetByFpgaFlag = 0;
static UINT32 s_dbgDpdChnPwrSaveStatus = 0xFFFF;
static UINT32 s_dbgDpdChanSwitchCnt = 0;
static UINT32 s_tmpPwrSaveDpdCloseMode = 0;

#define LOWPOWER_OFF            0x88  //进入电源轻载状态
#define LOWPOWER_ON             0x80  //退出电源轻载状态
/**************************************************************************
*                              函数定义                                       *
**************************************************************************/

/* 快速查找Transceiver片数的接口，避免反复查找特性表 */
static UINT32 GetTransceiverChipNum(VOID)
{
    TRruDeviceDescription *pDev = NULL;
    UINT32 loop;
    static UINT32 num = 0;

    if (num != 0)
    {
        return num;
    }
    for (loop = 0; loop < BspGetTxBspChanNum(); loop++)
    {
        if (BSP_OK == BspChipInfoPtrGetByRfPathDef(loop, TX, DEVICE_TYPE_TRANSCEIVER, &pDev))
        {
            if (pDev->ulDeviceCfg != INVALID_VALUE)
            {
                num++;
            }
        }
    }
    return num;
}

/* ------------------------------------------------------------------------- */
/* ------------------------------------------------------------------------- */
/* --------------------------------BSP内部接口 ----------------------------- */
/* ------------------------------------------------------------------------- */
/* ------------------------------------------------------------------------- */

UINT32 BspGetPwrSaveMode(VOID)
{
    return s_PwrSaveMode;
}

UINT32 BspSetPwrSaveMode(UINT32 mode)
{
    s_PwrSaveMode = mode;
    return s_PwrSaveMode;
}

VOID DbgClrDtxRouteStatus(VOID)
{
    memset_s(s_dbgDtxRouteStatus, sizeof(s_dbgDtxRouteStatus), 0, sizeof(s_dbgDtxRouteStatus));

    return ;
}

VOID DbgSaveDtxRouteStatus(UINT32 bspChan, UINT32 carrId, UINT32 on)
{
    if(bspChan < DGB_CHAN_MAX_NUM)
    {
        if(on)
        {
            s_dbgDtxRouteStatus[bspChan] |= BIT_SET(carrId);
        }
        else
        {
            s_dbgDtxRouteStatus[bspChan] &= BIT_REV(carrId);
        }
    }

    return ;
}

VOID DbgSaveDtxEnableStatus(UINT32 bspChan, UINT32 sw)
{
    if(bspChan < DGB_CHAN_MAX_NUM)
    {
        if(sw)
        {
            s_dbgDtxEnableChanMask |= BIT_SET(bspChan);
        }
        else
        {
            s_dbgDtxEnableChanMask &= BIT_REV(bspChan);
        }
    }

    return ;
}

VOID DbgSaveDeepSleepStatus(UINT32 sw)
{
    s_PwrSaveDeepSleepStat = sw;    
}

UINT32 BspGetDeepSleepStatus(VOID)
{
    return s_PwrSaveDeepSleepStat;
}

VOID opendpdpwrsave(VOID)
{
    s_tmpPwrSaveDpdCloseMode = 0;
}

VOID closedpdpwrsave(VOID)
{
    s_tmpPwrSaveDpdCloseMode = 1;
}

/**************************************************************************
* 函数名称: BspResetTransceiver
* 功能描述: 复位住所有的Transceiver
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 
**************************************************************************/
UINT32 BspResetTransceiver(VOID)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = BSP_OK; 
    UINT32 isHigh = 0; /* 已确认AD903x,AFE80xx,MTS2.0都是拉低是复位态 */
    
    BspLog(LOG_LEVEL_0,"%s: Shutdown All Transceiver enter. \n", __FUNCTION__);
    
    for(loop=0; loop<GetTransceiverChipNum();loop++)
    {
        retVal = BspHalAdaptResetTransceiverChip(loop,isHigh);
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BspHalAdaptResetTransceiverChip, retVal);
    }
    
    dbgInfoEx("%s: Shutdown All Transceiver exit. retTotal=%#x\n", __FUNCTION__,retTotal);
    BspLog(LOG_LEVEL_0,"%s: Shutdown All Transceiver exit. retTotal=%#x\n", __FUNCTION__,retTotal);

    return retTotal;
}

UINT32 BspGetPwrVoltLimitDown(UINT32 Index, INT32* pPaVolt)
{
    UINT32 Ret=BSP_ERROR, PaVolt=0;
    TPaBasicInfoCaliData* pCali = NULL;

    pCali = _BspGetPaBasicInfoCalibData(0);

    if(Index<TBL_MAX_TX_CHAN_NUM && pCali!=NULL)
    {
        if (pCali->atBasicInfoPath[Index].ulPathLoadFlag != TBL_LOAD_SUCC)
        {
            dbgInfoEx("%s[%d] path[%d] load %d\n", __FUNCTION__, __LINE__, Index, pCali->atBasicInfoPath[Index].ulPathLoadFlag);
            return Ret;
        }
        PaVolt = pCali->atBasicInfoPath[Index].ulPwrVoltDown;
        Ret = BSP_OK;
    }
    if(pPaVolt!=NULL)
    {
        *pPaVolt = PaVolt;
    }
    dbgInfo("%s: ch%d downvolt = %d\n",__FUNCTION__,Index,PaVolt);
    return Ret;
}

UINT32 BspSetRruAllChanPaVolt(INT32 volt)
{
    UINT32 loop = 0;
    UINT32 txChnNum = 0;

    txChnNum = BspGetTxChannel();
    for(loop = 0; loop < txChnNum; loop++)
    {
        if(BSP_OK != BspSetPaVolt(loop, volt))
        {
            BspLog(LOG_LEVEL_0, "%s BspSetPaVolt fail! chan=[%d]\n", __FUNCTION__, loop);
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspPwrSavePaVoltCtrl(*)
 *  功能描述   : PA 48V电源调到最低档位和恢复
 *  输入参数   : ctrl  0-掉电, 1-不掉电
 *  输出参数   : 无
 *  返 回 值   : BSP_OK-成功，其他失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 */
UINT32 BspPwrSavePaVoltCtrl(UINT32 ctrl)
{
    UINT32 retVal = BSP_OK;
    UINT32 txChnNum = 0;
    UINT32 loop = 0;
    INT32 volt = 0;

    txChnNum = BspGetTxChannel();

    /* 调压到最低档位 */
    if(SWITCH_OFF == ctrl)
    {
        for(loop=0; loop<txChnNum; loop++)
        {
            //按PaBasicInfo.txt最低档位设置实现
            //retVal = BspGetPwrVoltLimitDown(loop, &volt);
            if(BSP_OK == retVal)
            {
                //retVal = BspSetPaVolt(loop, volt);
                retVal = BspSetPaVolt(loop, 35000);  //目前4.2平台深度休眠：功放漏压统一调整为35V进行节能
                if(BSP_OK == retVal)
                {
                    dbgInfoEx("%s BspSetPaVolt succ! chan=[%d] volt=[%d]\n", __func__, loop, volt);
                }
                else
                {
                    BspLog(LOG_LEVEL_0,"%s BspSetPaVolt fail! chan=[%d] volt=[%d]\n", __func__, loop, volt);
                }
            }
            else
            {
                BspLog(LOG_LEVEL_0,"%s BspGetPwrVoltLimitDown err chan=[%d]\n", __func__, loop);
            }
        }
    }
    /* 恢复到正常档位 */
    else
    {
        retVal = BspPaDefaultVoltInit();
        if(BSP_OK == retVal)
        {
            dbgInfoEx("%s BspPaDefaultVoltInit succ!\n", __func__);
        }
        else
        {
            BspLog(LOG_LEVEL_0,"%s BspPaDefaultVoltInit fail!\n", __func__);
        }
    }

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspPwrsveSerdesAllPowerDown()
 *  功能描述   : 关闭204serdes
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK-成功，其他失败
 *  其它说明   : 深度休眠使用
 *----------------------------------------------------------------------------
 */
UINT32 BspPwrsveSerdesAllPowerDown(VOID)
{
    UINT32 txLaneIdMask = 0xFF;
    UINT32 rxLaneIdMask = 0xFF;
    UINT32 retVal = 0;
    UINT32 retTotal = BSP_OK;

    retVal = BspHalAdaptJ204cSerdesPowerDown(TX, txLaneIdMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptJ204cSerdesPowerDown,retVal);

    retVal = BspHalAdaptJ204cSerdesPowerDown(RX, rxLaneIdMask);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptJ204cSerdesPowerDown,retVal);

    j204ExLog(J204_SERDES,"%s All Lane Powdown Finish [txLaneMask=%#x] [rxLaneMask=%#x] ret=0x%#x\n",
            __func__, txLaneIdMask,rxLaneIdMask,retTotal);

    return retTotal;

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspSetIcDeepSleepCtrl(*)
 *  功能描述   : 关闭DPDIC除关口以外的功能模块
 *  输入参数   : sw 0-关闭，1-恢复
 *  输出参数   : 无
 *  返 回 值   : BSP_OK-成功，其他失败
 *  其它说明   : 深度休眠使用(针对单片IC机型)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetIcDeepSleepCtrl(UINT32 ctrl)
{
    UINT32 retVal = BSP_OK;
    UINT32 chanNum = 0;
    UINT32 chanMask = 0;

    chanNum = BspGetTxChannel();
    chanMask = ((0x1<<chanNum)-1);
    //进入深度关断
    if(SWITCH_OFF == ctrl)
    {
        //DPD通道关断
        retVal |= BspPwrSaveDpdChanSwitch(chanMask,ctrl);
        CHECK_RETVAL(BspPwrSaveDpdChanSwitch,retVal);

        //光口天线去使能
        retVal = BspHalAdaptOptAllCellEn(ctrl);
        BspLog(LOG_LEVEL_0,"%s: opt Cell en[%d], ret[%d]\n", __FUNCTION__, ctrl, retVal);
        CHECK_RETVAL(BspHalAdaptOptAllCellEn,retVal);

        //关闭204Serdes
        retVal = BspPwrsveSerdesAllPowerDown();
        CHECK_RETVAL(BspPwrsveSerdesAllPowerDown,retVal);

        //IC内部门控关闭(光口、中频)
        retVal = BspHalAdaptDpdicGateCtrl(E_IC_PWRSAVE_DEEPSLEEP_SEL);
        BspLog(LOG_LEVEL_0,"%s: dpdic gate ctrl pwrsavempde[%d], ret[%d]\n", __FUNCTION__, E_IC_PWRSAVE_DEEPSLEEP_SEL, retVal);
        CHECK_RETVAL(BspHalAdaptDpdicGateCtrl,retVal);

        BspLog(LOG_LEVEL_0,"%s: ctrl[%d] success!\n", __FUNCTION__,ctrl);
    }
    // 退出深度关断
    else
    {
        /*//IC内部门控打开(光口、中频)
        retVal = BspHalAdaptDpdicGateCtrl(E_IC_PWRSAVE_NORMAL_SEL);
        BspLog(LOG_LEVEL_0,"%s: dpdic gate ctrl pwrsavempde[%d], ret[%d]\n", __FUNCTION__, E_IC_PWRSAVE_NORMAL_SEL, retVal);
        CHECK_RETVAL(BspHalAdaptDpdicGateCtrl,retVal);

        //光口天线使能
        retVal = BspHalAdaptOptAllCellEn(ctrl);
        BspLog(LOG_LEVEL_0,"%s: opt Cell en[%d], ret[%d]\n", __FUNCTION__, ctrl, retVal);
        CHECK_RETVAL(BspHalAdaptOptAllCellEn,retVal);

        //DPD通道打开
        retVal |= BspPwrSaveDpdChanSwitch(chanMask,ctrl);
        CHECK_RETVAL(BspPwrSaveDpdChanSwitch,retVal);*/

        BspLog(LOG_LEVEL_0,"%s: ctrl[%d] success!\n", __FUNCTION__,ctrl);
    }

    return retVal;
}

/* 通知DPD关闭/打开部分通道 */
static UINT32 SetDpdChanSwitch(UINT32 chanmask, UINT32 sw)
{
    UINT32 retVal = 0;
    UINT32 cycleMs = 200; //200ms
    UINT32 retryMaxTimes = 300; //300*200ms=60s
    UINT32 retryTimes = 0;
    UINT32 swMask = 0; /* 1开;0关 */
    UINT32 result = 0;

    if(sw == 0)
    {
        swMask = chanmask;
    }
    else
    {
        swMask = 0;
    }

    /* 通知DPD关闭通道 */
    retVal = BspSetDpdChanOff(swMask);
    CHECK_RETVAL(BspSetDpdChanOff, retVal);

    /* 查询DPD处理结果 */
    do
    {
        if(retryTimes > retryMaxTimes)
        {
            BspLog(LOG_LEVEL_0,"%s fail to recv dpd ok result for retry=%d\n", __func__, retryTimes);
            return BSP_ERROR;
        }
        BspSysMsDelay(cycleMs);
        (VOID)BspDpdChanOffStaQuery(&result);
        retryTimes++;
        dbgInfo("%s check dpd chan switch result = %d, retry times = %d\n", __func__, result, retryTimes);
    }
    while(1 != result);

    return retVal;
}

/**************************************************************************
* 函数名称: BspPwrSaveDpdChanSwitch
* 功能描述: DPD通断关断
* 输入参数: chanMask - BSP通道掩码
* 输入参数: sw - 门控开关 0:关/1:开
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 通断关断用接口
**************************************************************************/
UINT32 BspPwrSaveDpdChanSwitch(UINT32 chanMask, UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    /* 维测开关 */
    if(s_tmpPwrSaveDpdCloseMode)
    {
        return BSP_OK;
    }

    BspLog(LOG_LEVEL_0,"%s: Dpd chan sw[%d] chanMask(%#x) enter. \n", __FUNCTION__, sw, chanMask);

    if(SWITCH_OFF == sw)
    {
        s_dbgDpdChnPwrSaveStatus |= chanMask;
    }
    else
    {
        s_dbgDpdChnPwrSaveStatus &= (~chanMask);
    }

    s_dbgDpdChanSwitchCnt++;
    retVal |= SetDpdChanSwitch(chanMask, sw);

    BspLog(LOG_LEVEL_0,"%s: Dpd chan sw[%d] chanMask(%#x) exit. retVal=%#x\n", __FUNCTION__,sw, chanMask,retVal);

    return retVal;
}

UINT32 BspSetPaVoltCtrl()
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 index = 0;
    INT32  rruPower = 0;
    UINT32 pwrOutLetNum = 0;
    INT32  pwrConsumeRecord = 0;

    pwrOutLetNum = BspGetPwrOutLetDevNum();   //RRU整机插头个数
    for(index = 0; index < pwrOutLetNum; index++)
    {
        pwrConsumeRecord = 0;
        if(BSP_OK != BspGetRruConsumedPower(index, &pwrConsumeRecord))
        {
            BspLog(LOG_LEVEL_0, "[%s]index = %d, GetRruPower is Failed!\n", __FUNCTION__, index);
            return BSP_ERROR;
        }
        rruPower = rruPower + pwrConsumeRecord;
    }

    if(rruPower < 150000)  //整机功耗小于150W在进行调压
    {
        for(loop = 0; loop < 3; loop++)  //调压3次
        {
            if(retVal == BspSetRruAllChanPaVolt(35000))  //目前4.2平台深度休眠：功放漏压统一调整为35V进行节能
            {
                break;
            }
            BspSysMsDelay(1000);
        }

        if(3 == loop)  //调压3次都不成功则返回失败
        {
            BspLog(LOG_LEVEL_0, "[%s]paVoltAdjustNum = %d, PaVoltAdjust is Failed!\n", __FUNCTION__, loop);
            return BSP_ERROR;
        }

        return BSP_OK;
    }

    BspLog(LOG_LEVEL_0, "[%s]rruPower = %d,Power consumption No meet the requirements\n", __FUNCTION__, rruPower);
    return BSP_ERROR;
}

/*****************************************************************************
 *  函数名称   : BspSetPwrLowStaSwitch()
 *  功能描述   : 深休下进入电源轻载模式策略
 *  输入参数   : sw 1-退出电源轻载，0-进入电源轻载
 *  输出参数   : 无
 *  返 回 值   : BSP_OK-成功，其他失败
 *  其它说明   : 调用pwrsave_common.c中接口组合生成深度休眠动作
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPwrLowStaSwitch(UINT32 sw)
{
    UINT32 ret = BSP_OK;
    UINT32 index = 0;
    UINT32 loop = 0;
    UINT32 status = 0;
    UINT32 pwrNum = 0;
    static UINT32 warning[RRU_PWR_NUM] = {0};

    pwrNum = BspGetPwrModuleNum();
    if(pwrNum > RRU_PWR_NUM)
    {
        BspLog(LOG_LEVEL_0, "[%s]pwrNum = %d, Exceed the RRU MAX PwrNum\n", __FUNCTION__, pwrNum);

        return BSP_ERROR;
    }

    if(SWITCH_OFF == sw)  //进入电源轻载
    {
        for(index = 0; index < pwrNum; index++)
        {
            for(loop = 0; loop < 3; loop++)
            {
                ret |= BspSetPowerLowStatus(index, SWITCH_OFF);
                ret |= BspGetPowerLowStatus(index, &status);

                if((BSP_OK == ret) && (LOWPOWER_OFF == status))
                {
                    break;
                }
                BspSysMsDelay(1000);
            }
            if(3 == loop)
            {
                BspLog(LOG_LEVEL_0, "[%s]index = %d, SetPowerLowStatus is Failed!\n", __FUNCTION__, index);
                warning[index] = 1;
            }
        }
    }
    else  //退出电源轻载
    {
        for(index = 0; index < pwrNum; index++)
        {
            if(1 == warning[index])  //没有成功进入电源轻载的不需要触发退出轻载模式
            {
                continue;
            }

            for(loop = 0; loop < 3; loop++)
            {
                ret |= BspSetPowerLowStatus(index, SWITCH_ON);
                ret |= BspGetPowerLowStatus(index, &status);

                if((BSP_OK == ret) && (LOWPOWER_ON == status))
                {
                    break;
                }
                BspSysMsDelay(1000);
            }

            if(3 == loop)  //3次没有退出成功返回失败
            {
                dbgInfo("[%s]index = %d, ExitPowerLowStatus is Failed!\n", __FUNCTION__, index);
                return BSP_ERROR;
            }
        }
    }

    return ret;
}
/* ------------------------------------------------------------------------- */
/* ------------------------------------------------------------------------- */
/* -------------------------------对高层接口 ------------------------------- */
/* ------------------------------------------------------------------------- */
/* ------------------------------------------------------------------------- */


/**************************************************************************
* 函数名称: BspSetTxRfPwrSaveSwitch
* 功能描述: 关闭/打开除PA以外的下行射频器件
* 输入参数: rfChan 射频通道号
* 输入参数: sw 1开/0关
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 和BspSetPaSwitch搭配，完成全部下行射频器件的节能
**************************************************************************/
UINT32 BspSetTxRfPwrSaveSwitch(UINT32 rfChan, UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal |= BspSetTxSwitch(rfChan, sw);
    //retVal |= BspSetPaPowTxSwitch(rfChan, sw);
    BspSetPaPowTxSwitch(rfChan, sw);  /* 有些通道不需要，会返回错误，暂时不关注返回值 */

    return retVal;     
}

/**************************************************************************
* 函数名称: BspSetRxRfPwrSaveSwitch
* 功能描述: 关闭/打开除LNA以外的上行射频器件
* 输入参数: rfChan 射频通道号
* 输入参数: sw 1开/0关
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 和BspSetLnaSwitch搭配，完成全部上行射频器件的节能
**************************************************************************/
UINT32 BspSetRxRfPwrSaveSwitch(UINT32 rfChan, UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSetRxSwitch(rfChan, sw);

    return retVal;     
}

/**************************************************************************
* 函数名称: BspPwrSaveTxChanSwitch
* 功能描述: 下行中频通道关断
* 输入参数: sw 1开/0关
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 
**************************************************************************/
UINT32 BspPwrSaveTxChanSwitch(UINT32 chanNo, UINT32 sw)
{
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspPwrSaveRxChanSwitch
* 功能描述: 上行中频通道关断
* 输入参数: sw 1开/0关
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 
**************************************************************************/
UINT32 BspPwrSaveRxChanSwitch(UINT32 chanNo, UINT32 sw)
{
    return BSP_OK;
}


/**************************************************************************
* 函数名称: BspPwrSaveTxCarrSwitch
* 功能描述: 下行中频载波关断
* 输入参数: sw 1开/0关
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 
**************************************************************************/
UINT32 BspPwrSaveTxCarrSwitch(UINT32 chanNo, UINT32 carrNo, UINT32 radioMode, UINT32 sw)
{
    return BSP_OK;
}

/**************************************************************************
* 函数名称: BspPwrSaveRxCarrSwitch
* 功能描述: 上行中频载波关断
* 输入参数: sw 1开/0关
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 
**************************************************************************/
UINT32 BspPwrSaveRxCarrSwitch(UINT32 chanNo, UINT32 carrNo, UINT32 radioMode, UINT32 sw)
{
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspSetIcDifPwrSaveSwitch(*)
 *  功能描述   : IC节电，数字中频Dif模块开关
 *  输入参数   : sw 0-关闭，1-恢复
 *  输出参数   : 无
 *  返 回 值   : BSP_OK-成功，其他失败
 *  其它说明   : 全载波关断使用
 *----------------------------------------------------------------------------
 */
UINT32 BspSetIcDifPwrSaveSwitch(UINT32 sw)
{
    return BSP_OK;
}

UINT32 BspSetMtsResetByFpgaFlag(UINT32 flag)
{
    s_mtsResetByFpgaFlag = flag;
    return s_mtsResetByFpgaFlag;
}

UINT32 BspGetMtsResetByFpgaFlag(VOID)
{
    return s_mtsResetByFpgaFlag;
}

/**************************************************************************
* 函数名称: BspShutdownTransceiver
* 功能描述: 深度睡眠使用：复位住所有的Trx(全载波关断及深度休眠使用)
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: 
**************************************************************************/
UINT32 BspShutdownTransceiver(VOID)
{
    UINT32 retVal = BSP_OK;

    if(!BspGetPwrSaveMode())
    {
        dbgInfoEx("%s exit for mode = %d\n", __func__, BspGetPwrSaveMode());
        return BSP_OK;
    }

    if(BspGetMtsResetByFpgaFlag() == MTS_RESET_BY_FPGA_FlAG)
    {
        BspRegBitValWr(0, FPGA_MTS_RESET, 0, 0, 0, 0);
    }
    else
    {
        retVal = BspResetTransceiver();
    }
    return retVal;
}

/* ------------------------------------------------------------------------- */
/* ------------------------------------------------------------------------- */
/* --------------------------------维测接口 -------------------------------- */
/* ------------------------------------------------------------------------- */
/* ------------------------------------------------------------------------- */
static VOID showpwrsavestatus(VOID)
{
    dbgInfo("POWER SAVE STATUS: \n");
    dbgInfo("---------------------------------------------------\n");
    dbgInfo("Deep Sleep Status:      %d (0-normal,1-deepsleep)\n", s_PwrSaveDeepSleepStat);
    dbgInfo("---------------------------------------------------\n");
    dbgInfo("Dtx Enable Mask:        0x%08x (bit:1-en,0-dis)\n", s_dbgDtxEnableChanMask);
    dbgInfo("---------------------------------------------------\n");
    dbgInfo("Pwr Save Mode:          %d(0-close,1-open)\n", s_PwrSaveMode);
    dbgInfo("---------------------------------------------------\n");
    dbgInfo("Dpd chan Status:        0x%08x\n", s_dbgDpdChnPwrSaveStatus);
    dbgInfo("---------------------------------------------------\n");
    dbgInfo("Dpd chan Sw Cnt:     %d\n", s_dbgDpdChanSwitchCnt);
    
    return;
}

static VOID showpwrsavecarrstatus(UINT32 bspChan)
{
    if(bspChan >= DGB_CHAN_MAX_NUM)
    {
        return;
    }
    dbgInfo("POWER SAVE CARR STATUS: CHAN[%d]\n", bspChan);
    dbgInfo("Dtx Carr Route status:   %#x\n", s_dbgDtxRouteStatus[bspChan]);
    dbgInfo("Ic Tx Carr Pwr Save:     %#x\n", s_dbgTxCarrIcPwrSaveSwMask[bspChan]);
    dbgInfo("Ic Rx Carr Pwr Save:     %#x\n", s_dbgRxCarrIcPwrSaveSwMask[bspChan]);
    return; 
}

static UINT32 pwrsavetxrfsw(UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 txChnNum = 0;
    UINT32 loop = 0;

    txChnNum = BspGetTxChannel();
    for(loop=0; loop<txChnNum; loop++)
    {
        retVal |= BspSetTxRfPwrSaveSwitch(loop, sw);
    }

    return retVal;    
}

static UINT32 pwrsaverxrfsw(UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 rxChnNum = 0;
    UINT32 loop = 0;

    rxChnNum = BspGetRxChannel();
    for(loop=0; loop<rxChnNum; loop++)
    {
        retVal |= BspSetRxRfPwrSaveSwitch(loop, sw);
    }

    return retVal;    
}

/*****************************************************************************
 *  函数名称   : BspSetIcDeepSleepCtrlSwitch(*)
 *  功能描述   : 关闭DPDIC除关口以外的功能模块
 *  输入参数   : sw 0-关闭，1-恢复
 *  输出参数   : 无
 *  返 回 值   : BSP_OK-成功，其他失败
 *  其它说明   : 深度休眠使用(针对多片IC,UBR机型使用)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetIcDeepSleepCtrlSwitch(UINT32 ctrl)
{
    UINT32 retVal = BSP_OK;

    //进入深度关断
    if(SWITCH_OFF == ctrl)
    {
        //光口天线去使能
        retVal = BspOptDisableCtrl();

        //关闭204Serdes
        retVal = BspPwrsveSerdesAllPowerDown();
        CHECK_RETVAL(BspPwrsveSerdesAllPowerDown,retVal);

        //IC内部门控关闭(光口、中频)
        retVal = BspHalAdaptDpdicGateCtrl(E_IC_PWRSAVE_DEEPSLEEP_SEL);
        BspLog(LOG_LEVEL_0,"%s: dpdic gate ctrl pwrsavempde[%d], ret[%d]\n", __FUNCTION__, E_IC_PWRSAVE_DEEPSLEEP_SEL, retVal);
        CHECK_RETVAL(BspHalAdaptDpdicGateCtrl,retVal);

        BspLog(LOG_LEVEL_0,"%s: ctrl[%d] success!\n", __FUNCTION__,ctrl);
    }
    // 退出深度关断
    else
    {
        //IC内部门控打开(光口、中频)
        retVal = BspHalAdaptDpdicGateCtrl(E_IC_PWRSAVE_NORMAL_SEL);
        BspLog(LOG_LEVEL_0,"%s: dpdic gate ctrl pwrsavempde[%d], ret[%d]\n", __FUNCTION__, E_IC_PWRSAVE_NORMAL_SEL, retVal);
        CHECK_RETVAL(BspHalAdaptDpdicGateCtrl,retVal);

        BspLog(LOG_LEVEL_0,"%s: ctrl[%d] success!\n", __FUNCTION__,ctrl);
    }

    return retVal;
}


static void exprnaddpwrsavefunc(VOID)
{
    exprnadd("BspResetTransceiver");
    exprnadd("BspSetPaGridVoltSwitch");
    exprnadd("BspSetIcDeepPwrSaveSwitch");
    exprnadd("BspResetTransceiver");
    exprnadd("BspShutdownTransceiver");
    return;
}


static VOID pwrsavecommonhelp(VOID)
{
    dbgInfo("--Debug command-----------\n");
    dbgInfo("exprnaddpwrsavefunc\n");
    dbgInfo("BspPaGridVoltPwrSaveSw sw\n");
    dbgInfo("pwrsavetxrfsw sw\n");
    dbgInfo("pwrsaverxrfsw sw\n");
    dbgInfo("BspResetTransceiver\n");
    dbgInfo("BspSetTxRfPwrSaveSwitch chan,sw\n");
    dbgInfo("BspSetRxRfPwrSaveSwitch chan,sw\n"); 
    dbgInfo("BspPwrSaveTxChanSwitch chan,sw\n");
    dbgInfo("BspPwrSaveRxChanSwitch chan,sw\n"); 
    dbgInfo("BspPwrSaveTxCarrSwitch chanNo,carrNo,radioMode,sw\n");
    dbgInfo("BspPwrSaveRxCarrSwitch chanNo,carrNo,radioMode,sw\n"); 
    dbgInfo("BspSetIcDifPwrSaveSwitch sw\n");
    dbgInfo("BspSetIcDeepPwrSaveSwitch sw\n");

    dbgInfo("\nBspGetPwrSaveMode\n"); 
    dbgInfo("BspSetPwrSaveMode mode\n"); 
    dbgInfo("showpwrsavestatus\n");
    dbgInfo("showpwrsavecarrstatus\n");
    
    return;
}


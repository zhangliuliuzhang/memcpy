/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardpapt.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了例化单板的功放保护通用接口
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "boardpapt.h"
#include "funccommon.h"
#include "boardmodlecommon.h"
#include "freqcfg_ic4_2.h"
#include "ichaladapt_ic4_2.h"
#include "cpri_alm.h"
#include "hardfeaturewrapperrfctrl.h"
#include "chnmap_a.h"
#include "crmalm.h"
#include "papt_maintain.h"
#include "optadpt.h"

#include "boardmodle_ic4_2.h"
#include "functionwrapper.h"
/**************************************************************************
*                                宏定义                                      *
**************************************************************************/

#define OPT_NUM_GET_CHECK                                                 \
    sfpNum = BspGetSfpNum();                                              \
    if(IC4_2_OPT_NUM_MAX < sfpNum)                                        \
    {                                                                     \
        dbgErr("%s: Opt num[%d] is over range. \n",__FUNCTION__, sfpNum); \
    }

/**************************************************************************
*                            全局变量定义                                       *
**************************************************************************/
static T_RfPaptCfgUpdata s_paptParaUpdata[IC_CHAN_MAX_NUM]  = {0};
static T_PaptCrmCfg      s_paptCrmCfg                       = {0};

static T_BspHalAdaptPaptParaCfg s_paptPara[IC_CHAN_MAX_NUM] = {0};
static T_BspHalAdaptPaptParaCfg s_PaptParaTemplate =
{
    .paptHpf    =
    {
        .pHpfCoef   = {6,-37,133,-347,712,-1208,1735,-2145,2300},   /* 高通滤波器系数 */
        .hpfPowThr  = -2000,        /* 带外单点门限 */
        .hpfWinLen  = 8,            /* 带外单点窗长 */
        .hpfOverNum = 2             /* 带外超门限点数 */
    },
    .paptRamp   =
    {
        .spThr      = 0,            /* 带内单点门限 */
        .rampMod    = 1,            /* RAMP模式 */
        .daOff      = 0,            /* 关数据配置 */
        .daDly      = 128,          /* 数据延时 */
        .rampOnStp  = 1,            /* 打开步进 */
        .rampOffStp = 2047          /* 关断步进 */
    },
    .paptUnus   =
    {
        .paOffDly0  = 20000,        /* 关PA异常(非数据类)恢复延时 */
        .paOffDly1  = 20000,        /* 关PA异常(数据类)恢复延时 */
        .paOffMask  = 0x800000,     /* 关PA异常屏蔽掩码 */
        .daOffDly0  = 20000,        /* 关DATA异常(非数据类)恢复延时 */
        .daOffDly1  = 20000,        /* 关DATA异常(数据类)恢复延时 */
        .daOffMask  = 0x802e80,       /* 关DATA异常屏蔽掩码 */
        .dpdDly     = 20000,        /* 送给dpd的异常恢复延时 */
        .dpdMask    = 0x802e80,       /* 送给dpd的异常屏蔽掩码 */
    },
    .paptDpd    =
    {
        .avgPowNum  = 16383,        /* 平均率点数 */
        .avgPowThr  = -1350,        /* 平均功率门限,单位:dbfs值X100 */
        .avgPowMod  = 0,            /* 平均功模式 */
        .AvgIIRCoef = 0,            /* IIR系数 */
    },
    .paptCfr    =
     {
         .avgPowNumL = 8191,         /* 长时平均功率点数 */
         .avgPowThrL = -1650,        /* 长时平均功率门限,单位:dbfs值X100 */
         .avgPowNumS = 2047,         /* 短时平均功率点数 */
         .avgPowThrS = -1250,        /* 短时平均功率门限,单位:dbfs值X100 */
         .avgPowMod  = 0,            /* 平均功率模式 */
         .AvgIIRCoef = 0,            /* IIR系数 */
         .cfrTddBypss= 1,            /* CFR TDD 旁路 */
     },
    .paptEtTdd  =
     {
         .tddDly     = 0,            /* TDD延时 */
     },
    .paptTrans  =
    {
        .inverse    = {0,0,0,0},    /* 取反标志:0或1 */
        .lock       = {0,0,0,0},    /* 锁存标志:0或1 */
    },
    .paptRcf    =
    {
        .byPass     = 1,            /* 旁路标志,0或1 */
        .overNum    = 4000,         /* 概率溢出点数 */
        .overThr    = -1800,        /* 概率溢出门限,单位:dbfs值X100 */
        .overWin    = 16,           /* 概率溢出窗长 */
        .overSleepNum = 1,          /* 概率溢出关断点数 */
    },
    .paptPaRouter    = 0xff,  /*关PA路由 ,0xff默认不配置 */
    .paptLnaRouter   = 0xff,  /*关LNA路由，0xff默认不配置*/
};

INT32 g_ulDpdAvgThrDelta[IC_CHAN_MAX_NUM] = {0};   /*门限相对变化量*/
INT32 g_ulCfrAvgThrDelta[IC_CHAN_MAX_NUM] = {0};

UINT32 ulPaptNcrFlag = 0;
/**************************************************************************
*                                接口定义                                     *
**************************************************************************/
/* papt CRM start */


static UINT32 BSPClearPaptCrmAlrmAll()
{
    UINT32 retVal = BSP_OK;

    retVal |= CrmPaAlmClear0(DPDIC_CRM_PAPT_ALM_MASK);
    retVal |= CrmDaAlmClear0(DPDIC_CRM_PAPT_ALM_MASK);
    retVal |= CrmAlmLatchStaClear(DPDIC_CRM_PAPT_ALM_MASK);

    /*固定流程写1再写0 表示清一次告警*/
    retVal |= CrmPaAlmClear0(0);
    retVal |= CrmDaAlmClear0(0);
    retVal |= CrmAlmLatchStaClear(0);

    return retVal;
}

static UINT32 BspGetCrmAlmEnSta()
{
    UINT32 retVal    = BSP_OK;
    UINT32 crmEnMask = 0;

    retVal |= CrmAlmRealSta(&crmEnMask);
    dbgInfo("%s: crm Papt Alarm Enble[%#x]. \n", __FUNCTION__, crmEnMask);

    return retVal;
}

static UINT32 BspGetCrmAlmLatchSta()
{
    UINT32 retVal   = BSP_OK;
    UINT32 crmAlarm = 0;

    retVal |= CrmAlmLatchSta(&crmAlarm);
    dbgInfo("%s: crm Papt Alarm Report[%#x]. \n", __FUNCTION__, crmAlarm);

    return retVal;
}

/* Started by AICoder, pid:k5d8doa468j8148142ab0a39b05f4a2f5bd35594 */
/**
 * 函数名称: BspSetPaptNcrFlag
 * 功能描述: 设置ulPaptNcrFlag的值
 * 输入参数: ulflag - 设置的值
 * 输出参数: 无
 * 返 回 值: 无
*/
VOID BspSetPaptNcrFlag(UINT32 ulflag)
{
    ulPaptNcrFlag = ulflag;
}

/**
 * 函数名称: BspGetPaptNcrFlag
 * 功能描述: 获取ulPaptNcrFlag的值
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: ulPaptNcrFlag的值
*/
UINT32 BspGetPaptNcrFlag(VOID)
{
    return ulPaptNcrFlag;
}
/* Ended by AICoder, pid:k5d8doa468j8148142ab0a39b05f4a2f5bd35594 */

UINT32 BspSetPaptCrmMask(T_PaptCrmCfg *paptCrmCfg)
{
    UINT32 retVal = BSP_OK;

    memcpy_s(&s_paptCrmCfg, sizeof(T_PaptCrmCfg), paptCrmCfg, sizeof(T_PaptCrmCfg));

    retVal |= CrmPaMask0(paptCrmCfg->crmPaMask);
    retVal |= CrmDaMask0(paptCrmCfg->crmDaMask);
    retVal |= CrmAlmRealStaMask(paptCrmCfg->crmEnMask);
    retVal |= CrmAlmLatchStaMask(paptCrmCfg->crmReportMask);

    retVal |= BSPClearPaptCrmAlrmAll();

    return retVal;
}

/* papt CRM end */

UINT32 BspPaptCfgUpdate(UINT32 bspChan, T_RfPaptCfgUpdata *para)
{
    memcpy_s(&s_paptParaUpdata[bspChan], sizeof(T_RfPaptCfgUpdata), para, sizeof(T_RfPaptCfgUpdata));

    return BSP_OK;
}

static UINT32 UpdatePaptCfg(UINT32 difChan, T_BspHalAdaptPaptParaCfg *pCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 mtsPaMask = 0;
    UINT32 crmPaMask = 0;
    UINT32 optPaMask = 0;
    UINT32 mtsNo  = 0;

    mtsNo = s_paptParaUpdata[difChan].mtsAlarmNo;
    crmPaMask = s_paptCrmCfg.openCrmPaDaFlag;
    optPaMask = s_paptCrmCfg.openOptPaDaFlag;

    if((mtsNo >= 1) &&(mtsNo <= 2))
    {
        mtsPaMask = 1 << ((s_paptParaUpdata[difChan].mtsAlarmNo - 1) * 2);
        pCfg->paptUnus.paOffMask |= (mtsPaMask << 14);
        pCfg->paptUnus.daOffMask |= (mtsPaMask << 14);
        pCfg->paptUnus.dpdMask   |= (mtsPaMask << 14);
    }
    if(mtsNo >= 3)
    {
        mtsPaMask = 1 << (s_paptParaUpdata[difChan].mtsAlarmNo-2);
        pCfg->paptUnus.paOffMask |= (mtsPaMask << 14);
        pCfg->paptUnus.daOffMask |= (mtsPaMask << 14);
        pCfg->paptUnus.dpdMask   |= (mtsPaMask << 14);
    }
    if(crmPaMask == 1)
    {
        pCfg->paptUnus.paOffMask |= (3 << 19); /*CRM 关PA需要同时打开bit19，20*/
        pCfg->paptUnus.daOffMask |= (1 << 20);
        pCfg->paptUnus.dpdMask   |= (1 << 20);
    }
#if (defined(BSP_MAKE_VER) || defined(_BSP_WITH_WFS))
    /*时钟失锁只关数据，不连BBU时钟失锁，即工装和小版本不使能时钟失锁*/
    pCfg->paptUnus.daOffMask &= (~(1 << 23));
    pCfg->paptUnus.dpdMask   &= (~(1 << 23));
#else

    /* Started by AICoder, pid:z2df3g0b22w8f2114fe90a9e80f0651665a642cd */
    if(1 == BspGetPaptNcrFlag())
    {
        pCfg->paptUnus.paOffMask &= (~(1 << 19));
        pCfg->paptUnus.daOffMask &= (~(1 << 19));
        pCfg->paptUnus.dpdMask   &= (~(1 << 19));

        pCfg->paptUnus.paOffMask &= (~(1 << 20));
        
        pCfg->paptUnus.paOffMask &= (~(1 << 23));
        pCfg->paptUnus.daOffMask &= (~(1 << 23));
        pCfg->paptUnus.dpdMask   &= (~(1 << 23));
    /* Started by AICoder, pid:k67efacd55776d5145fe0b3cb08a6d179ea9c811 */
        pCfg->paptDpd.avgPowThr   = -850;
        pCfg->paptCfr.avgPowThrL  = -1150;
        if (difChan < 6) /* 0,1,2,3,4,5 */
        {
            pCfg->paptUnus.paOffMask = 0x40000;
        }
        else
        {
            pCfg->paptUnus.paOffMask = 0xC0000;
        }

        if (difChan < 4) /* 0,1,2,3 */
        {
            pCfg->paptUnus.daOffMask = 0x146E80;
            pCfg->paptUnus.dpdMask   = 0x146E80;
        }
        else
        {
            pCfg->paptUnus.daOffMask = 0x1C6E80;
            pCfg->paptUnus.dpdMask   = 0x1C6E80; 
        }
    /* Ended by AICoder, pid:k67efacd55776d5145fe0b3cb08a6d179ea9c811 */
    }
    /* Ended by AICoder, pid:z2df3g0b22w8f2114fe90a9e80f0651665a642cd */

    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
        pCfg->paptUnus.paOffMask |= (1 << 22);
        pCfg->paptUnus.daOffMask |= (1 << 22);
        pCfg->paptUnus.dpdMask   |= (1 << 22);
    }

    if(1 == optPaMask)
    {
        pCfg->paptUnus.paOffMask |= (1 << 21);
        pCfg->paptUnus.daOffMask |= (1 << 21);
        pCfg->paptUnus.dpdMask   |= (1 << 21);
    }
#endif

    dbgInfoEx("%s difChan=%d, mtsNo=%d, paOffMask = %#x. optPaMask=0x%x\n", __func__, difChan, mtsNo, pCfg->paptUnus.paOffMask, optPaMask);
    return retVal;
}

static UINT32 BspHalAdaptUpdatePaptRoute(UINT32 difChan, T_BspHalAdaptPaptParaCfg* pCfg, UINT32 paId)
{
    dbgInfoEx("%s difChan=%d, paId=%d\n", __func__, difChan, paId);
    pCfg->paptPaRouter = paId;
    return BSP_OK;
}

static UINT32 BspHalAdaptUpdateLnaptRoute(UINT32 difChan, T_BspHalAdaptPaptParaCfg* pCfg, UINT32 LnaId)
{
    if(s_paptParaUpdata->lnaFalg == 0)
    {
        LnaId = 0xff;
    }

    dbgInfoEx("%s difChan=%d, LnaId=%d\n", __func__, difChan, LnaId);
    pCfg->paptLnaRouter = LnaId;
    return BSP_OK;
}

static UINT32 UpdatePaptRoute(UINT32 difChan, T_BspHalAdaptPaptParaCfg *pCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChipId = 0;
    UINT32 rfChan = 0;
    UINT32 paIoId = 0xff;
    UINT32 lnaIoId = 0xff;

    retVal = BspGetRfChnInfoByDifInfo(difChipId, difChan, TX, &rfChan);
    CHECK_RETVAL(BspGetRfChnInfoByDifInfo,retVal);

    retVal = BspGetPaIoInfoByRfChn(rfChan, TX, &paIoId);
    CHECK_RETVAL(BspGetPaIoInfoByRfChn,retVal);

    /* TDD机型需要关LNA， FDD机型R<T hal不会配置LNA路由，增加限制避免流程异常中断 */
    if(difChan < BspGetRxChannel())
    {
        retVal = BspGetLnaIoInfoByRfChn(rfChan, RX, &lnaIoId);
        CHECK_RETVAL(BspGetLnaIoInfoByRfChn,retVal);
    }

    retVal = BspHalAdaptUpdatePaptRoute(difChan, pCfg, (paIoId&0xf)); /*低4bit是编号，4-7bit是类型*/
    CHECK_RETVAL(BspHalAdaptUpdatePaptRoute,retVal);

    retVal = BspHalAdaptUpdateLnaptRoute(difChan, pCfg, (lnaIoId&0xf)); /*低4bit是编号，4-7bit是类型*/
    CHECK_RETVAL(BspHalAdaptUpdateLnaptRoute,retVal);

    return retVal;
}

UINT32 BspUpdatePaptInitInfo(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = 0;
    T_BspHalAdaptPaptParaCfg paptPara = {0};
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 difChan = 0;

    for (difChan = 0; difChan < min(txChnNum, IC_CHAN_MAX_NUM); difChan++)
    {
        memset_s(&paptPara, sizeof(T_BspHalAdaptPaptParaCfg), 0, sizeof(T_BspHalAdaptPaptParaCfg));
        memcpy_s(&paptPara, sizeof(T_BspHalAdaptPaptParaCfg), &s_PaptParaTemplate, sizeof(T_BspHalAdaptPaptParaCfg));
        retVal = BspUpdatePaptPara(difChan, &paptPara);
        CHECK_RETVAL_PRN(BspUpdatePaptPara, retVal);

        retVal = UpdatePaptRoute(difChan, &paptPara);
        retTotal |= retVal;
        CHECK_RETVAL_PRN(UpdatePaptRoute, retVal);

        retVal = UpdatePaptCfg(difChan, &paptPara);
        retTotal |= retVal;
        CHECK_RETVAL_PRN(UpdatePaptCfg, retVal);

        retVal = BspHalAdaptPaptInit(difChan, &paptPara);
        retTotal |= retVal;
        CHECK_RETVAL_PRN(BspHalAdaptPaptInit, retVal);
        memcpy_s(&s_paptPara[difChan], sizeof(T_BspHalAdaptPaptParaCfg), &paptPara, sizeof(T_BspHalAdaptPaptParaCfg));
    }

    retVal |= BspClrAllDpdicAlmStatus();

    return retTotal;
}

UINT32 BspSecondaryUpdatePaptInit(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 num = 0;
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 difChan = 0;
    T_BspHalAdaptPaptParaCfg *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_PAPT_SECONDARY_INIT, 0, 0, pPara, num);

    for (difChan = 0; difChan < min(txChnNum, IC_CHAN_MAX_NUM); difChan++)
    {
        retVal = UpdatePaptRoute(difChan, pPara);
        retVal |= BspHalAdaptPaptInit(difChan, pPara);
        memcpy_s(&s_paptPara[difChan], sizeof(T_BspHalAdaptPaptParaCfg), pPara, sizeof(T_BspHalAdaptPaptParaCfg));
    }

    retVal |= BspClrAllDpdicAlmStatus();

    return retVal;
}

/*获取cfr长时平均门限相对变化量*/
INT32 BspGetCfrAvgThrDelta(UINT32 bspChn)
{
    if(bspChn >= IC_CHAN_MAX_NUM)
    {
        return 0;
    }
    dbgInfoEx("bspChn %d cfrdelta %d\n", bspChn, g_ulCfrAvgThrDelta[bspChn]);
    BspLog(LOG_LEVEL_0,"bspChn %d cfrdelta %d\n", bspChn, g_ulCfrAvgThrDelta[bspChn]);
    return g_ulCfrAvgThrDelta[bspChn];
}

/*获取dpd均值门限相对变化量*/
INT32 BspGetDpdAvgThrDelta(UINT32 bspChn)
{
    if(bspChn >= IC_CHAN_MAX_NUM)
    {
        return 0;
    }
    dbgInfoEx("bspChn %d dpddelta %d\n", bspChn, g_ulDpdAvgThrDelta[bspChn]);
    BspLog(LOG_LEVEL_0,"bspChn %d dpddelta %d\n", bspChn, g_ulDpdAvgThrDelta[bspChn]);
    return g_ulDpdAvgThrDelta[bspChn];
}

UINT32 BspUpdatePaptAvgPowInfo(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 retTotal = 0;
    UINT32 chipidx = 0;
    UINT32 difChan = 0;
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 radio = 0;
    UINT32 carrId = 0;
    UINT32 maxCarrNum = 0;
    UINT32 avgPowUpdateflag = 0;
    T_RfCfgPara *pRfCfg = NULL;
    T_BspHalAdaptPaptCfrCfg paptCfrPara = {0};
    T_BspHalAdaptPaptDpdCfg paptDpdPara = {0};
    T_PaptHpfInfoCfg paptHpfPara = {0};
    T_BspFuRuSupportAvgPaptInfo tmp = {0};
    INT32 tmpHpfCoef[HPF_COEF_NUM] = {1,-27,-45,38,193,135,-398, -1173,2545};

    pRfCfg = BspGetRfCfgPara(bspChan, TX);
    if(NULL == pRfCfg)
    {
        dbgErr("%s difChn=%d GetRfCfgPara fail! \n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    maxCarrNum = pRfCfg->carrNum;
    if(0 == maxCarrNum)
    {
        dbgErr("[%s] error maxCarrNum = %d \n" ,__FUNCTION__, maxCarrNum);
        return BSP_ERROR;
    }

    for(carrId = 0; carrId < maxCarrNum; carrId++)
    {
        radio = pRfCfg->carrInfo[carrId].radioMode;
        if(RADIO_STANDARD_NB_IOT == radio)
        {
            avgPowUpdateflag = 1;
        }
    }

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipidx, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s bspChn=%d BspGetDifInfoByBspChn fail! \n", __FUNCTION__, bspChan);
        return retVal;
    }
    if(difChan >= min(txChnNum, IC_CHAN_MAX_NUM))
    {
        dbgErr("%s difChan=%d Exceed the ChanNum:%d\n", __FUNCTION__, bspChan, min(txChnNum, IC_CHAN_MAX_NUM));
        return BSP_ERROR;
    }
    memcpy_s(&paptCfrPara, sizeof(T_BspHalAdaptPaptCfrCfg), &(s_PaptParaTemplate.paptCfr), sizeof(T_BspHalAdaptPaptCfrCfg));
    memcpy_s(&paptDpdPara, sizeof(T_BspHalAdaptPaptDpdCfg), &(s_PaptParaTemplate.paptDpd), sizeof(T_BspHalAdaptPaptDpdCfg));
    memcpy_s(&paptHpfPara, sizeof(T_PaptHpfInfoCfg), &(s_PaptParaTemplate.paptHpf), sizeof(T_PaptHpfInfoCfg));

    retVal = BspGetRruSpecialAbility(BSP_FU_RU_SPE_AVG_PAPT, &tmp, sizeof(T_BspFuRuSupportAvgPaptInfo));
    if((1 == tmp.usSupportAvgPaptFlag)&&(0 != (tmp.ulChanMask&(1<<bspChan))))
    {
          if((1 == maxCarrNum)&&(pRfCfg->carrInfo[0].bandWidth <= 20000))  /*单载波且带宽小于20M下更新配置收窄滤波器 其他用默认值*/
          {
             memcpy_s(paptHpfPara.pHpfCoef, HPF_COEF_NUM*sizeof(INT32), tmpHpfCoef, HPF_COEF_NUM*sizeof(INT32));
             paptHpfPara.hpfPowThr = -3000;
             BspLog(LOG_LEVEL_0,"%s: bspChan %d pHpfCoef update \n", __FUNCTION__, bspChan);
             dbgInfoEx("%s: bspChan %d pHpfCoef update \n", __FUNCTION__, bspChan);
          }
          BspHalAdaptCfgHpfInfo(difChan, &paptHpfPara);
    }
    /* Started by AICoder, pid:a57adh5245nc8e014d360981f0b7c827f1f11777 */
    if(1 == BspGetPaptNcrFlag())
    {
        paptHpfPara.hpfPowThr = -1500;
        BspLog(LOG_LEVEL_0,"%s: bspChan %d pHpfCoef update hpfPowThr \n", __FUNCTION__, bspChan);
        dbgInfoEx("%s: bspChan %d pHpfCoef update hpfPowThr \n", __FUNCTION__, bspChan);
        BspHalAdaptCfgHpfInfo(difChan, &paptHpfPara);
    }
    /* Ended by AICoder, pid:a57adh5245nc8e014d360981f0b7c827f1f11777 */
    retVal = BspUpdateAvgPowInfo(difChan, avgPowUpdateflag, &paptCfrPara, &paptDpdPara);
    CHECK_RETVAL_PRN(BspUpdateAvgPowInfo, retVal);

    retVal = BspHalAdaptPaptAvgPow(difChan, &paptCfrPara, &paptDpdPara);
    retTotal |= retVal;
    CHECK_RETVAL_PRN(BspHalAdaptPaptAvgPow, retVal);

    memcpy_s(&s_paptPara[difChan].paptCfr, sizeof(T_BspHalAdaptPaptCfrCfg), &paptCfrPara, sizeof(T_BspHalAdaptPaptCfrCfg));
    memcpy_s(&s_paptPara[difChan].paptDpd, sizeof(T_BspHalAdaptPaptDpdCfg), &paptDpdPara, sizeof(T_BspHalAdaptPaptDpdCfg));
    memcpy_s(&s_paptPara[difChan].paptHpf, sizeof(T_PaptHpfInfoCfg), &paptHpfPara, sizeof(T_PaptHpfInfoCfg));
    retVal = BspHalAdaptClrPaptMonitorRpt(difChan, 0x3400);  //清除重新配置的三个门限的历史告警（按BIT位清除）
    retVal = BspHalAdaptClrPowInvalidFlag(difChan);
    retTotal |= retVal;

    return retTotal;
}

/*更新DPD均值保护门限*/
UINT32 BspUpdatePaptDpdAvgPowThr(UINT32 bspChan, INT32 delta)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0,"%s: bspChan %d delta %d \n", __FUNCTION__, bspChan, delta);
    dbgInfoEx("%s: bspChan %d delta %d \n", __FUNCTION__, bspChan, delta);
    if(bspChan >= IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }
    g_ulDpdAvgThrDelta[bspChan] = delta;
    retVal = BspUpdatePaptAvgPowInfo(bspChan);

    return retVal;
}

/*更新CFR均值保护门限*/
UINT32 BspUpdatePaptCfrAvgPowThr(UINT32 bspChan, INT32 delta)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0,"%s: bspChan %d delta %d \n", __FUNCTION__, bspChan, delta);
    dbgInfoEx("%s: bspChan %d delta %d \n", __FUNCTION__, bspChan, delta);
    if(bspChan >= IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }
    g_ulCfrAvgThrDelta[bspChan] = delta;
    retVal = BspUpdatePaptAvgPowInfo(bspChan);

    return retVal;
}

/*按照类型更新保护门限*/
UINT32 BspUpdatePaptPowThr(UINT32 bspChan, UINT32 type, INT32 delta)
{
    UINT32 retVal = BSP_OK;

    switch(type)
    {
        case E_PA_PRO_TYPE_LOCAL_FREQ_DPD_AVG_PWR:   /*dpd均值*/
            retVal |= BspUpdatePaptDpdAvgPowThr(bspChan, delta);
            break;
        case E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR:  /*cfr均值*/
            retVal |= BspUpdatePaptCfrAvgPowThr(bspChan, delta);
            break;
        default:
            break;
    }

    return retVal;
}

/*打开或者关闭cfr的功放保护使能*/
UINT32 BspUpdatePaptCfgAvgMask(UINT32 bspChan, INT32 enMask)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0;
    T_PaptUnusInfoCfg tmp = {0};

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",
               __FUNCTION__, bspChan, difChan);
        return retVal;
    }
    dbgInfoEx("%s bspChan %d enMask %d\n", __FUNCTION__, bspChan, enMask);
    memcpy_s(&tmp, sizeof(T_PaptUnusInfoCfg), &s_paptPara[difChan].paptUnus,sizeof(T_PaptUnusInfoCfg));
    dbgInfoEx("1-%s bspChan %d enMask %d daoffMask 0x%x\n", __FUNCTION__, bspChan, enMask, tmp.daOffMask);
    if(0 == enMask)
    {
        tmp.daOffMask &= BIT_REV(13);
        tmp.dpdMask &= BIT_REV(13);
    }
    else
    {
        tmp.daOffMask |= BIT_SET(13);
        tmp.dpdMask |= BIT_SET(13);
    }
    dbgInfoEx("2-%s bspChan %d enMask %d daoffMask 0x%x\n", __FUNCTION__, bspChan, enMask, tmp.daOffMask);
    retVal = BspHalAdaptCfgPaptUnus(difChan, &tmp);

    return retVal;
}

/*按照类型设置掩码*/
UINT32 BspUpdatePaptPowMask(UINT32 bspChan, UINT32 type, INT32 enMask)
{
    UINT32 retVal = BSP_OK;

    switch(type)
    {
        case E_PA_PRO_TYPE_LOCAL_FREQ_LONG_AVG_PWR:  /*cfr均值*/
            retVal |= BspUpdatePaptCfgAvgMask(bspChan, enMask);
            break;
        default:
            break;
    }

    return retVal;
}

/*分配置类型和功放保护类型更新参数*/
UINT32 BspUpdatePaptPowInfo(UINT32 bspChan, UINT32 cfgType, UINT32 paproType, INT32 para)
{
    UINT32 retVal = BSP_OK;

    switch(cfgType)
    {
        case 0:
            retVal = BspUpdatePaptPowThr(bspChan,paproType, para);
            break;
        case 1:
            retVal = BspUpdatePaptPowMask(bspChan, paproType, para);
            break;
        case 2:
            retVal = BspFixPaptKfGain(bspChan, para);
            break;
        default:
            break;
    }
    return retVal;
}
/* 清除DPDIC   PAPT告警 */
UINT32 BspClrAllDpdicAlmStatus(void)
{
    UINT32 bspChan  = 0;
    UINT32 chipId   = 0;
    UINT32 chanNum  = BspGetTxChanNum();
    UINT32 difChan  = 0;
    UINT32 retVal   = 0;
    UINT32 retTotal = 0;

    for(bspChan = 0; bspChan < chanNum; bspChan++)
    {
        retVal |= BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
        if (BSP_OK != retVal)
        {
            dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",__FUNCTION__, bspChan, difChan);
            return retVal;
        }

        retVal = BspHalAdaptClrPaptMonitorRpt(difChan, DPDIC_PAPT_ALM_MASK);
        retVal = BspHalAdaptClrPowInvalidFlag(difChan);
        retTotal |= retVal;
        if (BSP_OK != retVal)
        {
            dbgErr("[%s] BspHalAdaptClrPaptMonitorRpt Error, difChan[%d]\n",
                   __FUNCTION__, difChan);
        }
    }

    return retTotal;
}

static UINT32 BspSetSerdesAlmMaskPaptCfg(UINT32 *ulRegVal)
{
    UINT32 ret          = BSP_OK;
    UINT32 sfpNum       = 0;
    UINT32 loop         = 0;

    OPT_NUM_GET_CHECK

    for(loop = 0; loop < sfpNum; loop ++)
    {
        ret |= OptCpriSetPaptOptSerdesIpAlmMask(loop, ulRegVal[loop]);
        dbgInfoEx("%s: optNo = %d, serdesMask = %#x. \n",__FUNCTION__, loop, ulRegVal[loop]);
    }

    return ret;
}

static UINT32 BspSetSbcResDaOffAlmMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetSbcResDaOffAlmMask(ulRegVal);
    dbgInfoEx("%s: SbcResDaOff = %#x. \n",__FUNCTION__, ulRegVal);

    return ret;
}

static UINT32 BspSetDaOffDlyPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDaOffDly(ulRegVal);
    dbgInfoEx("%s: DifPaOff = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetDaOnDlyPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDaOnDly(ulRegVal);
    dbgInfoEx("%s: CpriSetDaOnDly = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetDifDaOffOptAlmMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDifDaOffOptAlmMask(ulRegVal);
    dbgInfoEx("%s: CpriSetDifDaOffOptAlmMask = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetDifDaOffSecMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDifDaOffSecMask(ulRegVal);
    dbgInfoEx("%s: CpriSetDifDaOffOptAlmMask = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

UINT32 BspSetDifPaOffOptAlmMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDifPaOffOptAlmMask(ulRegVal);
    dbgInfoEx("%s: CpriSetDifPaOffOptAlmMask = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetDifPaOffSecMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDifPaOffSecMask(ulRegVal);
    dbgInfoEx("%s: CpriSetDifPaOffSecMask = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetLocalDaOffAlmMaskPaptCfg(UINT32 *ulRegVal)
{
    UINT32 ret          = BSP_OK;
    UINT32 sfpNum       = 0;
    UINT32 loop         = 0;

    OPT_NUM_GET_CHECK

    for(loop = 0; loop < sfpNum; loop ++)
    {
        ret |= OptCpriSetLocalDaOffAlmMask(loop, ulRegVal[loop]);
        dbgInfoEx("%s: optNo = %d, CpriSetLocalDaOffAlmMask = %#x. \n",__FUNCTION__, loop, ulRegVal[loop]);
    }

    return ret;
}

static UINT32 BspSetCascDaOffAlmMaskPaptCfg(UINT32 *ulRegVal)
{
    UINT32 ret          = BSP_OK;
    UINT32 sfpNum       = 0;
    UINT32 loop         = 0;

    OPT_NUM_GET_CHECK

    for(loop = 0; loop < sfpNum; loop ++)
    {
        ret |= OptCpriSetCascDaOffAlmMask(loop, ulRegVal[loop]);
        dbgInfoEx("%s: optNo = %d, CpriSetCascDaOffAlmMask = %#x. \n",__FUNCTION__, loop, ulRegVal[loop]);
    }

    return ret;
}

static UINT32 BspSetDifDaOffAlmMaskPaptCfg(UINT32 *ulRegVal)
{
    UINT32 ret          = BSP_OK;
    UINT32 sfpNum       = 0;
    UINT32 loop         = 0;

    OPT_NUM_GET_CHECK

    for(loop = 0; loop < sfpNum; loop ++)
    {
        ret |= OptCpriSetDifDaOffAlmMask(loop, ulRegVal[loop]);
        dbgInfoEx("%s: optNo = %d, CpriSetDifDaOffAlmMask = %#x. \n",__FUNCTION__, loop, ulRegVal[loop]);
    }

    return ret;
}

static UINT32 BspSetDifPaOffAlmMaskPaptCfg(UINT32 *ulRegVal)
{
    UINT32 ret          = BSP_OK;
    UINT32 sfpNum       = 0;
    UINT32 loop         = 0;

    OPT_NUM_GET_CHECK

    for(loop = 0; loop < sfpNum; loop ++)
    {
        ret |= OptCpriSetDifPaOffAlmMask(loop, ulRegVal[loop]);
        dbgInfoEx("%s: optNo = %d, CpriSetDifPaOffAlmMask = %#x. \n",__FUNCTION__, loop, ulRegVal[loop]);
    }

    return ret;
}
static UINT32 BspSetDifDifPhyAlmDaMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriAlmDifPhyAlmDaMask(ulRegVal);
    dbgInfoEx("%s: CpriAlmDifPhyAlmDaMask = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetDifPhyAlmDaMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDifPaOffSecMask(ulRegVal);
    dbgInfoEx("%s: CpriAlmDifPhyAlmDaMask = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetDifPhyAlmDaMaskInfoPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriSetDifPaOffSecMask(ulRegVal);
    dbgInfoEx("%s: DifPhyAlmDaMaskInfo = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

static UINT32 BspSetDifPaOffPhyAlmDaMaskInfoPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret          = BSP_OK;

    ret = OptCpriAlmDifPhyAlmPaMask(ulRegVal);
    dbgInfoEx("%s: DifPaOffPhyAlmDaMaskInfo = %#x. \n",__FUNCTION__,ulRegVal);

    return ret;
}

UINT32 BspPaptCfgInit(Papt_Opt_Cfg_Info *optCfgInfo)
{
    UINT32 ret = BSP_OK;

    ret |= BspSetPcsAlarmMask();
    ret |= BspSetSerdesAlmMaskPaptCfg(optCfgInfo->serdesAlmMaskInfo);   //serdes告警掩码 0xFFF2
    ret |= BspSetSbcResDaOffAlmMaskPaptCfg(optCfgInfo->sbcDaOffMaskInfo);  //辅光口响应主光口告警IQ关断 0X1
    ret |= BspSetDaOffDlyPaptCfg(optCfgInfo->daOffDlyInfo);//主辅光口告警IQ关断延迟关断配置0x10
    ret |= BspSetDaOnDlyPaptCfg(optCfgInfo->daOnDlyInfo);//主辅光口告警IQ关断延迟打开配置0x1
    ret |= BspSetDifDaOffOptAlmMaskPaptCfg(optCfgInfo->difDaOffAlmMaskInfo);//光口中频数据屏蔽告警掩码0x1
    ret |= BspSetDifDaOffSecMaskPaptCfg(optCfgInfo->difDaOffSecMaskInfo);//中频数据屏蔽告警掩码0x7
    ret |= BspSetDifPaOffOptAlmMaskPaptCfg(optCfgInfo->difPaOffAlmMaskInfo);//光口中频关功放告警掩码0x1
    ret |= BspSetDifPaOffSecMaskPaptCfg(optCfgInfo->difPaOffSecMaskInfo);//中频关功放告警掩码0x1
    ret |= BspSetLocalDaOffAlmMaskPaptCfg(optCfgInfo->localLogicAlmMaskInfo);//链路告警关断本级数据掩码配置0x09FCF
    ret |= BspSetCascDaOffAlmMaskPaptCfg(optCfgInfo->cascLogicAlmMaskInfo);//链路告警关断转发数据掩码配置0x09FCF
    ret |= BspSetDifDaOffAlmMaskPaptCfg(optCfgInfo->logicDaOffAlmMaskInfo);//U0口中频数据屏蔽告警掩码寄存器0x1FCF
    ret |= BspSetDifPaOffAlmMaskPaptCfg(optCfgInfo->logicPaOffAlmMaskInfo);//U0口中频关功放告警掩码0x800
    ret |= BspSetDifDifPhyAlmDaMaskPaptCfg(optCfgInfo->DifPhyAlmDaMaskInfo);//关数据保护物理光口告警掩码
    ret |= BspSetDifPhyAlmDaMaskPaptCfg(optCfgInfo->DifPaOffSecMaskInfo);//关功放保护物理光口告警掩码
    ret |= BspSetDifPaOffPhyAlmDaMaskInfoPaptCfg(optCfgInfo->DifPaOffPhyAlmDaMaskInfo);//关功放保护物理光口告警掩码
    return ret;
}

static UINT32 papt(UINT32 difChan)
{
    CHAR tmp[10] = {0};
    CHAR tmpBuf[100] = {0};
    UINT32 i = 0;
    int ret = 0;
    T_BspHalAdaptPaptParaCfg *paptPara = NULL;

    if (difChan >= NELEMENTS(s_paptPara))
    {
        return BSP_ERROR;
    }
    paptPara = &s_paptPara[difChan];
    dbgInfo("%s: difChan=%u\n", __FUNCTION__, difChan);
    dbgInfo("paptHpf:\n");
    for (i = 0; i < HPF_COEF_NUM; i++)
    {
        ret = snprintf_s(tmp, sizeof(tmp), "%d, ", paptPara->paptHpf.pHpfCoef[i]);
        SNPRINTF_S_CHECK(ret, sizeof(tmp));
        strncat_s(tmpBuf, sizeof(tmpBuf), tmp, strnlen_s(tmp, 10));
    }
    dbgInfo("    pHpfCoef: %s\n", tmpBuf);
    dbgInfo("    hpfPowThr: %d\n", paptPara->paptHpf.hpfPowThr);
    dbgInfo("    hpfWinLen: %u\n", paptPara->paptHpf.hpfWinLen);
    dbgInfo("    hpfOverNum: %u\n", paptPara->paptHpf.hpfOverNum);

    dbgInfo("paptRamp:\n");
    dbgInfo("    spThr: %d\n", paptPara->paptRamp.spThr);
    dbgInfo("    rampMod: %u\n", paptPara->paptRamp.rampMod);
    dbgInfo("    daOff: %u\n", paptPara->paptRamp.daOff);
    dbgInfo("    daDly: %u\n", paptPara->paptRamp.daDly);
    dbgInfo("    rampOnStp: %u\n", paptPara->paptRamp.rampOnStp);
    dbgInfo("    rampOffStp: %u\n", paptPara->paptRamp.rampOffStp);

    dbgInfo("paptUnus:\n");
    dbgInfo("    paOffDly0: %u\n", paptPara->paptUnus.paOffDly0);
    dbgInfo("    paOffDly1: %u\n", paptPara->paptUnus.paOffDly1);
    dbgInfo("    paOffMask: %u\n", paptPara->paptUnus.paOffMask);
    dbgInfo("    daOffDly0: %u\n", paptPara->paptUnus.daOffDly0);
    dbgInfo("    daOffDly1: %u\n", paptPara->paptUnus.daOffDly1);
    dbgInfo("    daOffMask: %u\n", paptPara->paptUnus.daOffMask);
    dbgInfo("    dpdDly: %u\n", paptPara->paptUnus.dpdDly);
    dbgInfo("    dpdMask: %u\n", paptPara->paptUnus.dpdMask);

    dbgInfo("paptDpd:\n");
    dbgInfo("    avgPowNum: %u\n", paptPara->paptDpd.avgPowNum);
    dbgInfo("    avgPowThr: %d\n", paptPara->paptDpd.avgPowThr);
    dbgInfo("    avgPowMod: %u\n", paptPara->paptDpd.avgPowMod);
    dbgInfo("    AvgIIRCoef: %u\n", paptPara->paptDpd.AvgIIRCoef);

    dbgInfo("paptCfr:\n");
    dbgInfo("    avgPowNumL: %u\n", paptPara->paptCfr.avgPowNumL);
    dbgInfo("    avgPowThrL: %d\n", paptPara->paptCfr.avgPowThrL);
    dbgInfo("    avgPowNumS: %u\n", paptPara->paptCfr.avgPowNumS);
    dbgInfo("    avgPowThrS: %d\n", paptPara->paptCfr.avgPowThrS);
    dbgInfo("    avgPowMod: %u\n", paptPara->paptCfr.avgPowMod);
    dbgInfo("    AvgIIRCoef: %u\n", paptPara->paptCfr.AvgIIRCoef);
    dbgInfo("    cfrTddBypss: %u\n", paptPara->paptCfr.cfrTddBypss);

    dbgInfo("paptEtTdd:\n");
    dbgInfo("    tddDly: %u\n", paptPara->paptEtTdd.tddDly);

    dbgInfo("paptTrans:\n");
    memset_s(tmpBuf, sizeof(tmpBuf), 0, sizeof(tmpBuf));
    for (i = 0; i < PAPT_TRANS_UNUS_GRP_NUM; i++)
    {
        ret = snprintf_s(tmp, sizeof(tmp), "%u, ", paptPara->paptTrans.inverse[i]);
        SNPRINTF_S_CHECK(ret, sizeof(tmp));
        strncat_s(tmpBuf, sizeof(tmpBuf), tmp, strnlen_s(tmp, 10));
    }
    dbgInfo("    inverse: %s\n", tmpBuf);
    memset_s(tmpBuf, sizeof(tmpBuf), 0, sizeof(tmpBuf));
    for (i = 0; i < PAPT_TRANS_UNUS_GRP_NUM; i++)
    {
        ret = snprintf_s(tmp, sizeof(tmp), "%u, ", paptPara->paptTrans.lock[i]);
        SNPRINTF_S_CHECK(ret, sizeof(tmp));
        strncat_s(tmpBuf, sizeof(tmpBuf), tmp, strnlen_s(tmp, 10));
    }
    dbgInfo("    lock: %s\n", tmpBuf);

    dbgInfo("paptRcf:\n");
    dbgInfo("    byPass: %u\n", paptPara->paptRcf.byPass);
    dbgInfo("    overNum: %u\n", paptPara->paptRcf.overNum);
    dbgInfo("    overThr: %d\n", paptPara->paptRcf.overThr);
    dbgInfo("    overWin: %u\n", paptPara->paptRcf.overWin);
    dbgInfo("    overSleepNum: %u\n", paptPara->paptRcf.overSleepNum);

    dbgInfo("paptRouter:\n");
    dbgInfo("    paptPaRouter: %u\n", paptPara->paptPaRouter);
    dbgInfo("    paptLnaRouter: %u\n", paptPara->paptLnaRouter);

    return BSP_OK;
}

static void paprtprn(UINT32 bspChan, UINT32 isClr)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s] bspChan[%d] Get difChan[%d] Error!\n",
               __FUNCTION__, bspChan, difChan);
        return;
    }

    HalPaptShow(difChan, 0);
    if(isClr)
    {
        BspHalAdaptClrPaptMonitorRpt(difChan, DPDIC_PAPT_ALM_MASK);
    }
    return;
}

static VOID papts(UINT32 chanMask, UINT32 isClr)
{
	UINT32 bspChan = 0;
	UINT32 mask = chanMask?chanMask:0xFFFFFFFF;
    for(bspChan = 0; bspChan < BspGetTxChannel(); bspChan++)
    {
        if(!(mask & BIT_SET(bspChan)))
        {
            continue;
        }
		
	    paprtprn(bspChan, isClr);
    }
}

static VOID paprtclr(VOID)
{
    (VOID)BspClrAllDpdicAlmStatus();
}



/*****************************************************************************
* 版权所有(C) 2022, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardversionload.c
* 文件标识 : 无
* 内容摘要 : 统一版本加载实现
* 注意事项 : 无
*---------------------------------------------------------------------------*/

#include "fpgaload.h"
#include "boardversionload.h"
#include "systemcallapi.h"
#include "devdrv_fpgaload.h"
#include "funccommon.h"
#include "newunpress.h"
#include "fpgaload.h"
#include "fpga_common.h"
#include "plugandplay.h"
#include "boardmodle_ic4_2.h"
#include "funccommon_log.h"
#include "fpgaloadprocess.h"
#include "bspcommon.h"
#include "dualbootapi.h"
#include "bsp_svm_app.h"

#define FILE_NAME_LEN 128

static void DownloadComponentsVer(const char *verName, const char *serverIp)
{
    INT32           retVal = 0;
    UINT32          loop = 0;
    CHAR            ftpCmd[100] = {0};

    // IP无效不下载
    if (serverIp == NULL)
    {
        return;
    }

    /* 下载版本 */
    retVal = snprintf_s(ftpCmd, sizeof(ftpCmd), "tftp -g -r %s -l %s %s -b 16384",
        verName, verName, serverIp);
    SNPRINTF_S_CHECK(retVal, sizeof(ftpCmd));
    for(loop=0; loop<5; loop++)
    {
        retVal = BspSystem(ftpCmd);
        if (retVal != 0)
        {
            BspLog(LOG_LEVEL_0,"%s: loop %d run cmd %s failed\n", __FUNCTION__, loop, ftpCmd);
            continue;
        }
        else
        {
            break;
        }
    }
}

UINT32 g_FlushCpeVerFlag = 0;

/* Started by AICoder, pid:p7ce155520f1659142280a17e0f3c10cd1a76b0b */
VOID BspSetFlushCpeVerFlag(UINT32 flag)
{
#ifndef _BSP_WITH_WFS
    g_FlushCpeVerFlag = flag;
#endif
}
/* Ended by AICoder, pid:p7ce155520f1659142280a17e0f3c10cd1a76b0b */

UINT32 BspGetFlushCpeVerFlag(VOID)
{
    return g_FlushCpeVerFlag;
}

/* Started by AICoder, pid:e4c3cr1083q11f414d0608ee60b0a80c4bc5531d */
FUNC_BSP_GET_MT_RUNVER g_pFuncBspGetMtRunVer = NULL;

UINT32 BspGetMtRunVerCallBack(FUNC_BSP_GET_MT_RUNVER pFunc)
{
    g_pFuncBspGetMtRunVer = pFunc;
    return BSP_OK;
}

BOOL BspCompareMtVerno(CHAR* filePath, UINT32 filePathLen)
{
    UINT32 retVal = 0;
    CHAR swvVerNo[VERNO_LEN] = {0};
    CHAR runVerNo[VERNO_LEN] = {0};

    INPUT_POINTER_CHECK(filePath);
    if(filePathLen > FILE_NAME_LEN)
    {
        dbgErr("[%s]filePathLen = %d Err\n", __FUNCTION__, filePathLen);
        return FALSE;
    }

    retVal = BspGetFileSysPackVerNo(filePath, swvVerNo);
    CHECK_RETVAL_PRN(BspGetFileSysPackVerNo, retVal);

    if(NULL != g_pFuncBspGetMtRunVer)
    {
        retVal = g_pFuncBspGetMtRunVer(runVerNo, sizeof(runVerNo));
        if(GET_MT_RUN_VER_ERROR == retVal)
        {
            //薛勇方案，读取子卡版本号5次，读不到就需要烧录
            fpgaloadLog(LOAD_INFO,"%s, get mt run verno failed, need flush mt ver\n", __FUNCTION__);
            return FALSE;
        }
    }

    if(0 == strncmp((const CHAR*)swvVerNo, (const CHAR*)runVerNo, VERNO_LEN))
    {
        dbgInfo("[%s]target version %s is the same with run version !\n", __FUNCTION__, filePath);
        return TRUE;
    }
    else
    {
        dbgInfo("[%s]target version %s is not the same with run version !\n", __FUNCTION__, filePath);
        return FALSE;
    }
}

static void GetVersionSwvPath(T_VerLoadInfo *verLoadInfo, char *filePath, rsize_t pathBufLen, UINT32 *psoftType, UINT32 *verType, UINT32 *postRes, UINT32 *hashSelect)
{
    UINT32          ret = 0;
    INT32           retVal = 0;
    UINT32          softType = 0;
    const char      *fileName = NULL;
    T_XMLLIST_PARA  loadVerPara = {0};
    CHAR            mtFilePath[FILE_NAME_LEN] = {0};
    int rruExistRet = 0;
    int flagExistRet = 0;

    softType = BspSwitchNameToSoftType(verLoadInfo->SoftName);
    if(softType == BSP_ERROR)
    {
        BspLog(LOG_LEVEL_0,"%s: can't get %s 's SoftType\n", __FUNCTION__, verLoadInfo->SoftName);
        return;
    }
    *psoftType = softType;
    if (verLoadInfo->loadType == VERSION_LOAD_TYPE_CUR_SWV)
    {
        fileName = verLoadInfo->swvName;
    }
    else if (verLoadInfo->loadType == VERSION_LOAD_TYPE_COMPONENTIZED)
    {
        if (verLoadInfo->swvName == NULL)
        {
            BspClrSingleVerLoadRes(softType);
            ret = BspGetXmlListPara(softType, &loadVerPara);
            BspGetFileExistRet(&rruExistRet, &flagExistRet);
            BspLog(LOG_LEVEL_0, "%s: rruExistRet=%d flagExistRet=%d\n", __FUNCTION__, rruExistRet, flagExistRet);
            if (ret != BSP_OK)
            {
                BspLog(LOG_LEVEL_0, "%s: can't get softtype %d 's loadVerPara, ret=0x%x\n", __FUNCTION__, softType, ret);
                return;
            }
            if(loadVerPara.ulPostRes == 1)
            {
                *verType = BSP_ACK_VERSION;
                if(BSP_SOFT_TYPE_CPE == softType)
                {
                    retVal = snprintf_s(mtFilePath, pathBufLen, "%s/%s", verLoadInfo->releaseVerPathPrx, loadVerPara.acFileName);
                    SNPRINTF_S_CHECK(retVal, pathBufLen);
                    if(!BspCompareMtVerno(mtFilePath, sizeof(mtFilePath)))
                    {
                        BspSetFlushCpeVerFlag(NEED_FLUSH_CPE_VER);
                        fpgaloadLog(LOAD_INFO,"[%s][%d]Bsp set flush cpever flag: need!\n", __FUNCTION__, __LINE__);
                    }
                }
            }
            if((NEED_FLUSH_CPE_VER_PROC == BspGetFlushCpeVerProcFlag()) && (BSP_SOFT_TYPE_CPE == softType))
            {
                retVal = snprintf_s(mtFilePath, pathBufLen, "%s/%s", verLoadInfo->releaseVerPathPrx, loadVerPara.acFileName);
                SNPRINTF_S_CHECK(retVal, pathBufLen);
                if(!BspCompareMtVerno(mtFilePath, sizeof(mtFilePath)))
                {
                    BspSetFlushCpeVerFlag(NEED_FLUSH_CPE_VER);
                    fpgaloadLog(LOAD_INFO,"[%s][%d]Bsp set flush cpever flag: need!\n", __FUNCTION__, __LINE__);
                }
            }
            *postRes    = loadVerPara.ulPostRes;
            *hashSelect = loadVerPara.ulHashSelect;
            // 如果IP有效，则下载版本文件
            DownloadComponentsVer(loadVerPara.acFileName, verLoadInfo->ftpServerIp);
            fileName = loadVerPara.acFileName;
        }
        else
        {
            fileName = verLoadInfo->swvName;
        }
    }
    retVal = snprintf_s(filePath, pathBufLen, "%s/%s", verLoadInfo->releaseVerPathPrx, fileName);
    SNPRINTF_S_CHECK(retVal, pathBufLen);
}
/* Ended by AICoder, pid:e4c3cr1083q11f414d0608ee60b0a80c4bc5531d */

static UINT32 LoadBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    CHAR cmdExe[32] = {0};
    UINT32 pidNum = 0;
    ULONG ret = 0;
    CHAR cmd[64] = {0};
    int retVal = 0;

    if(BSP_OK == BspIsPidExisted(processName, &pidNum))
    {
        if (snprintf_s(cmdExe,sizeof(cmdExe),"kill -9 %d",pidNum) < 0)
        {
            BspLog(LOG_LEVEL_0, "%s: snprintf_s() is error\n", __FUNCTION__);
        }
        BspSystem(cmdExe);
    }

    ret = BspChmod(binFileName, "750");
    if (ret != BSP_OK)
    {
        return BSP_ERROR;
    }
    if (snprintf_s(cmd, sizeof(cmd), "%s &", binFileName) < 0)
    {
        BspLog(LOG_LEVEL_0, "%s:snprintf_s() is error\n", __FUNCTION__);
    }
    retVal = BspSystem(cmd);
    if (retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0,"%s: Run %s failed, ret:%d\n", __FUNCTION__, cmd, retVal);
        return BSP_ERROR;
    }
    else
    {
        BspLog(LOG_LEVEL_0,"%s: Run %s process success\n", __FUNCTION__, binFileName);
    }

    return BSP_OK;
}

UINT32 LoadFpgaBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    UINT32 ret = BSP_OK;
    ret |= BspFpgaLoadParaInit((T_FpgaCfgModePriv*)(para), paranum);
    ret |= BspFpgaLoadInit();
    ret |= BspLoadFpgaImg(chipid, binFileName);
    return ret;
}

/*二次解压mcu版本 只有9124使用*/
UINT32 LoadMcuBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    char  oriFileName[] = "/ata/rru/cur14.swv";
    char  oriFileNameEx[] = "/ata/rru/cur14ex.swv";
    char cmd[100] = {0};

    dbgInfo("LoadMcuBinVersion chipid %d binFileName %s  processName %s\n", chipid, binFileName,processName);
    if(BSP_OK == BspIsFileExist(binFileName))  /*第一次解压正常 才有这个mcu.swv文件 才能移到ata/rru 改成cur14.swv*/
    {
        /*读取版本内容 传给子端*/
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",oriFileNameEx,oriFileName);
        BspSystem(cmd);
        BspSetModuleSoftFlag(SWITCH_ON);
        return BSP_OK;   /*避免重复解压*/
    }
    BspSetModuleSoftFlag(SWITCH_OFF);

    return BSP_ERROR;
}

/*一次解压子端mcu*/
UINT32 LoadMcuSwvVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    int  snpRet = 0;
    char  tmpFileName[32] = {0};
    char  backFileName[] =  "/tmpmcu.swv";
    char  oriFileName[] =   "/ata/rru/cur14.swv";
    char  oriFileNameEx[] = "/ata/rru/cur14ex.swv";
    char cmd[100] = {0};
    char backbinFileName[] = {"/mcu.bit.bin"};

    dbgInfo("LoadMcuSwvVersion chipid %d binFileName %s  processName %s\n", chipid, binFileName,processName);
    snpRet = snprintf_s(tmpFileName,sizeof(tmpFileName),"/ata/rru/%s",processName);
    SNPRINTF_S_CHECK(snpRet, sizeof(tmpFileName));

    if(BSP_OK == BspIsFileExist(backbinFileName))  /*如果已经存在.bin 会导致此次流程提前返回 无法重新解压.swv*/
    {
         (VOID)remove(backbinFileName);/*重新加载的时候需要把mcu.bit.bin先删掉*/
    }
    if(BSP_OK == BspIsFileExist(binFileName))  /*mcu.swv*/
    {
        if(BSP_OK == BspIsFileExist(tmpFileName))
        {
            (VOID)remove(tmpFileName); /*删除原来保留的历史备份文件*/
        }
        (void)snprintf_s(cmd, sizeof(cmd), "cp %s %s",binFileName,backFileName);  /*备份调试使用*/
        BspSystem(cmd);
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",binFileName,tmpFileName);
        BspSystem(cmd);
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",oriFileName,oriFileNameEx);
        BspSystem(cmd);
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",tmpFileName,oriFileName);
        BspSystem(cmd);
        return BSP_OK;
    }

    return BSP_ERROR;
}

/*二次解压epld版本*/
UINT32 LoadEpldBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    char  oriFileName[] = "/ata/rru/cur12.swv";
    char  oriFileNameEx[] = "/ata/rru/cur12ex.swv";
    char cmd[100] = {0};

    dbgInfo("LoadEpldBinVersion chipid %d binFileName %s  processName %s\n", chipid, binFileName,processName);
    if(BSP_OK == BspIsFileExist(binFileName))  /*第一次解压正常 才有这个epld.swv文件 才能移到ata/rru 改成cur12.swv*/
    {
        /*读取版本内容 传给子端*/
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",oriFileNameEx,oriFileName);
        BspSystem(cmd);
        BspSetModuleSoftFlag(SWITCH_ON);
        return BSP_OK;   /*避免重复解压*/
    }
    BspSetModuleSoftFlag(SWITCH_OFF);

    return BSP_ERROR;
}

/*一次解压子端epld*/
UINT32 LoadEpldSwvVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    int  snpRet = 0;
    char  tmpFileName[32] = {0};
    char  backFileName[] =  "/tmpepld.swv";
    char  oriFileName[] =   "/ata/rru/cur12.swv";
    char  oriFileNameEx[] = "/ata/rru/cur12ex.swv";
    char cmd[100] = {0};
    char backbinFileName[] = {"/epld.bit.bin"};

    dbgInfo("LoadEpldSwvVersion chipid %d binFileName %s  processName %s\n", chipid, binFileName,processName);
    snpRet = snprintf_s(tmpFileName,sizeof(tmpFileName),"/ata/rru/%s",processName);
    SNPRINTF_S_CHECK(snpRet, sizeof(tmpFileName));
    if(BSP_OK == BspIsFileExist(backbinFileName))
    {
         (VOID)remove(backbinFileName);/*重启加载的时候需要把mcu.bit.bin删掉先*/
    }
    if(BSP_OK == BspIsFileExist(binFileName))
    {
        if(BSP_OK == BspIsFileExist(tmpFileName))
        {
            (VOID)remove(tmpFileName); /*删除原来保留的历史备份文件*/
        }
        (void)snprintf_s(cmd, sizeof(cmd), "cp %s %s",binFileName,backFileName);  /*epld.swv->tmpepld.swv*/
        BspSystem(cmd);
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",binFileName,tmpFileName);/*/epld.swv->ata/rru/epld.swv*/
        BspSystem(cmd);
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",oriFileName,oriFileNameEx); /*cur12.swv->cur12ex.swv*/
        BspSystem(cmd);
        (void)snprintf_s(cmd, sizeof(cmd), "mv %s %s",tmpFileName,oriFileName);  /*ata/rru/epld.swv->ata/rru/cur12.swv*/
        BspSystem(cmd);
        return BSP_OK;
    }

    return BSP_ERROR;
}

UINT32 BspCheckFileSystermVersionLength(char *pcFileName, UINT32 softType)
{
    UINT32 ulDataLen = 0;
    UINT32 iReadLen = 0;
    INT32  lSnpRet = 0;
    FILE *pf;
    BYTE* pByZipDataBuf = NULL;
    TSwPackage *ptUnionAddr;
    BYTE* pbyHeaderBuf = NULL;
    UINT32 ulVerOffset = 0;
    INT32 fopsRet = 0;
    INPUT_POINTER_CHECK(pcFileName);

    if (softType != 10)
    {
        return BSP_OK;
    }

    fopsRet = fopen_s(&pf, pcFileName, "rb");
    FOPEN_S_CHECK(fopsRet);
    if (pf == NULL)
    {
        dbgErr("%s>>File[%s] Open Error!\n",__FUNCTION__, pcFileName);
        return BSP_ERROR;
    }

    /**************************************/
    pbyHeaderBuf = (BYTE *)malloc(sizeof(T_VerFileHeader) + sizeof(TSwPackage));
    if(NULL == pbyHeaderBuf)
    {
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("%s>>CodeLine'%d: HeaderBuf Malloc Error!\n",__FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    iReadLen = fread(pbyHeaderBuf, 1, sizeof(T_VerFileHeader) + sizeof(TSwPackage), pf);
    if (iReadLen != sizeof(T_VerFileHeader) + sizeof(TSwPackage))
    {
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("%s>>CodeLine'%d: FreadData To Buffer Error!\n",__FUNCTION__, __LINE__);
        return BSP_VER_READ_ERROR;
    }
    ptUnionAddr = (TSwPackage*) (pbyHeaderBuf+ sizeof(T_VerFileHeader));
    ulVerOffset = sizeof(T_VerFileHeader) + sizeof(unsigned char) + ptUnionAddr->ucSwNum * sizeof(TSwIdInfo);

    /**************************************/

    if(fseek(pf, ulVerOffset, SEEK_SET) != 0)
    {
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        dbgErr("%s>>File[%s] Fseek Error!\n",__FUNCTION__, pcFileName);
        return BSP_ERROR;
    }

    ulDataLen = BspGetPkgVersionLength();
    pByZipDataBuf = (BYTE*)malloc(ulDataLen);
    if(NULL == pByZipDataBuf)
    {
        dbgErr("%s>>malloc failed [line:%d]!\n",__FUNCTION__,__LINE__);
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        return BSP_ERROR;
    }

    iReadLen = fread((VOID *)pByZipDataBuf, 1, ulDataLen, pf);
    if (iReadLen != (int)ulDataLen)
    {
        dbgErr("%s>>File Read Error! VerLen = 0x%x, ReadLen = 0x%x.\n",
                __FUNCTION__, ulDataLen, iReadLen);
        lSnpRet = fclose(pf);
        FCLOSE_CHECK(lSnpRet);
        free(pbyHeaderBuf);
        pbyHeaderBuf = NULL;
        free(pByZipDataBuf);
        pByZipDataBuf = NULL;
        return BSP_ERROR;
    }

    free(pByZipDataBuf);
    pByZipDataBuf = NULL;
    free(pbyHeaderBuf);
    pbyHeaderBuf = NULL;
    lSnpRet = fclose(pf);
    FCLOSE_CHECK(lSnpRet);

    return BSP_OK;
}

VOID BspJudgeFlushCpeVer(UINT32 softType)
{
    if(BSP_SOFT_TYPE_CPE == softType)
    {
        BspSetFlushCpeVerFlag(NEED_FLUSH_CPE_VER);
        fpgaloadLog(LOAD_INFO,"[%s]Bsp set flush cpever flag: need!\n", __FUNCTION__);
    }
}

VOID BspChangeSysVerLoadRet(UINT32 softType, UINT32* pRet)
{
    UINT32 ret = BSP_OK;
    UINT32 loop =0;
    UINT32 connectVerNum = 0;
    UINT32 connectVerList[MAX_SOFTTYPE_NUM] = {0};

    if(NULL == pRet)
    {
        return;
    }

    ret = BspGetConnectVerList(connectVerList, &connectVerNum);
    if((BSP_OK == ret) && (0 != connectVerNum))
    {
        for(loop = 0; loop < connectVerNum; loop++)
        {
            if((TRUE == BspCheckProIniFileExist()) && (softType == connectVerList[loop]))
            {
                BspLog(LOG_LEVEL_0, "%s:Load Version cur%d.swv From Protect !\n", __FUNCTION__, softType);
                *pRet = BSP_ERROR;
                break;
            }
        }
    }

    return;
}

/*****************************************************************************
 *  函数名称   : BspLoadVersionFromSwv
 *  功能描述   : 加载swv压缩形式的版本
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : loadErrMask 记录错误原因
 *  输出参数   :
 *  返 回 值   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  10290326@2022-05-19 19:40:00, 创建
 *----------------------------------------------------------------------------*/
static UINT32 BspLoadVersionFromSwv(T_VerLoadInfo *verLoadInfo, UINT32 i, char *swvFile, const char *processName, const char *processPath,
        UINT32 softType, UINT32 hashSelect, UINT32 postRes, UINT32 *verType, UINT32 *loadErrMask)
{
    UINT32          cnt = 0;
    UINT32          retval = 0;
    BYTE            *imageBuf = NULL;
    T_PkgVerInfo    pkgVerInfo = {0};
    LoadBinVersionFunc loadVerFunc = NULL;
    UINT32 swid = 0;
    CHAR preverPathName[NAME_MAX] = {0};
    UINT32 alarmFlag = 0;

    INPUT_POINTER_CHECK(verType);

    pkgVerInfo.ulSoftType = softType;
    pkgVerInfo.ulPostRes = hashSelect;
    for(cnt = 0; cnt < 3; cnt++)
    {
    	IF_CHK(i < verLoadInfo->infoLen)
        {
            BspLog(LOG_LEVEL_0, "%s: Reading %s file from %s...try, ulPostRes=%u\n", __FUNCTION__, verLoadInfo->commonLoadInfo[i].ExeName, swvFile, pkgVerInfo.ulPostRes);
        }
        retval = BspGetFileSysPackVerInfo(swvFile, verLoadInfo->commonLoadInfo[i].verIndex, &pkgVerInfo);
        IF_CHK(retval == UNPRESS_EC_DIV_NUM_ERROR)
        {
        	IF_CHK(i < verLoadInfo->infoLen)
        	{
                BspLog(LOG_LEVEL_0, "%s: %s not exist %u index package\n", __FUNCTION__, swvFile, verLoadInfo->commonLoadInfo[i].verIndex);
        	}
            return BSP_OK;
        }

        BspChangeSysVerLoadRet(softType, &retval);
        retval |= BspCheckFileSystermVersionLength(swvFile, softType);
        if (retval != BSP_OK)
        {
            BITS_SET(*loadErrMask, 2, (i * 4), 4);
            BspLog(LOG_LEVEL_0, "%s: BspGetFileSysPackVerInfo failed, try use Protect File cnt:%u, ulPostRes=%u retval=0x%x\n", __FUNCTION__, cnt, pkgVerInfo.ulPostRes, retval);
            if(postRes == 1)/*版本升级过程中，直接返回错误*/
            {
                BITS_SET(*loadErrMask, 3, (i * 4), 4);
                continue;
            }
            memset_s(&pkgVerInfo, sizeof(T_PkgVerInfo), 0, sizeof(T_PkgVerInfo));
            *verType = BSP_PROVERSION;
            retval = BspGetProtectFileInfo(softType, verLoadInfo->commonLoadInfo[i].verIndex, &pkgVerInfo);
            // 如果verIndex找不到,返回成功,错误原因恢复成0
            RETURN_VAL_DO_IF_EXP(retval == UNPRESS_EC_DIV_NUM_ERROR, BSP_OK, BITS_SET(*loadErrMask, 0, (i * 4), 4);
                BspLog(LOG_LEVEL_0, "%s: %s not exist %u index protect package\n", __FUNCTION__, swvFile, verLoadInfo->commonLoadInfo[i].verIndex));
            if(retval != BSP_OK)
            {
                BspLog(LOG_LEVEL_0, "%s:Get ProctFileInfo failed ![Ret %#x]\n",__FUNCTION__, retval);
                BITS_SET(*loadErrMask, 4, (i * 4), 4);
                continue;
            }
            BspJudgeFlushCpeVer(softType);
        }
        // FPGA0版本
        if (softType == 10)
        {
            swid = pkgVerInfo.tVerHeadInfo.ulSoftType;
            retval = BspGetPreverFpgaPath(swid, preverPathName, sizeof(preverPathName), &alarmFlag);
            if (retval == BSP_OK)
            {
                if (alarmFlag == 0)
                {
                    fpgaloadLog(LOAD_INFO, "%s: swid=%u 0x%x,prever file name:%s\n",__FUNCTION__, swid, swid, preverPathName);
                    if (*verType == BSP_RUN_VERSION)
                    {
                        (void)BspBackUpFpgaSwv(swvFile);
                    }
                    // 加载tmp10.swv的时候,是升级场景,能保证swid和ini文件相同
                    (void)remove(swvFile);
                    (void)BspCopyFile(preverPathName, swvFile);
                    memset_s(&pkgVerInfo, sizeof(T_PkgVerInfo), 0, sizeof(T_PkgVerInfo));
                    (void)BspGetFileSysPackVerInfo(swvFile, verLoadInfo->commonLoadInfo[i].verIndex, &pkgVerInfo);
                }
                // 如果预装版本找不到对应的swid,继续版本加载
            }
            else
            {
                BspSetFpgaVerComparFlag(0);
            }
        }
        if (pkgVerInfo.tVerHeadInfo.ulOriginalSize == 0)
        {
            BITS_SET(*loadErrMask, 5, (i * 4), 4);
            BspLog(LOG_LEVEL_0, "%s: tPkgVerInfo.tVerHeadInfo.ulOriginalSize is equal 0, cnt:%u \n", __FUNCTION__, cnt);
            continue;
        }
        BspLog(LOG_LEVEL_0, "%s: version<%s>\n", __FUNCTION__, pkgVerInfo.tVerHeadInfo.ucVerNo);
        dbgInfo("%s: version<%s>\n", __FUNCTION__, pkgVerInfo.tVerHeadInfo.ucVerNo);
        CONTINUE_IF_EXP(pkgVerInfo.tVerHeadInfo.ulOriginalSize > SVM_BIN_MAX_SIZE_ORIGINAL);
        CONTINUE_IF_EXP(pkgVerInfo.tVerHeadInfo.ulCompressedSize > SVM_BIN_MAX_SIZE_COMPRESSED);
        imageBuf = (BYTE *)malloc(pkgVerInfo.tVerHeadInfo.ulOriginalSize);
        if(imageBuf == NULL)
        {
            BITS_SET(*loadErrMask, 6, (i * 4), 4);
            BspLog(LOG_LEVEL_0, "%s: malloc %u mem failed, cnt:%u \n", __FUNCTION__, pkgVerInfo.tVerHeadInfo.ulOriginalSize, cnt);
            continue;
        }

        retval = BspGetVerPackData(&pkgVerInfo, processPath, imageBuf);
        if(retval != BSP_OK)
        {
            free(imageBuf);
            BITS_SET(*loadErrMask, 7, (i * 4), 4);
            BspLog(LOG_LEVEL_0, "%s: BspGetVerPackData failed, cnt:%u\n", __FUNCTION__, cnt);
            continue;
        }
        free(imageBuf);
        loadVerFunc = verLoadInfo->commonLoadInfo[i].loadBinFunc;
        if (loadVerFunc == NULL)
        {
            loadVerFunc = LoadBinVersion;
        }
        retval = loadVerFunc(verLoadInfo->commonLoadInfo[i].comIndex, processPath, processName,  ((T_FpgaCfgModePriv *)verLoadInfo->PrvInfo)+i, verLoadInfo->PrvLen);
        if(retval == BSP_OK)
        {
            BITS_SET(*loadErrMask, 0, (i * 4), 4);
            BspLog(LOG_LEVEL_0, "%s: %s version load OK\n", __FUNCTION__, processName);
            break;
        }
        else
        {
            BITS_SET(*loadErrMask, 8, (i * 4), 4);
            BspLog(LOG_LEVEL_0, "%s: %s version load failed, cnt=%u\n", __FUNCTION__, processName, cnt);
            retval = BSP_VER_LOAD_ERROR;
        }
    }

    return retval;
}

/*获取FPGA ID */
UINT32 BspGetFpgaTypeByFpgaId(UINT32 ulFpgaIndex)
{
    /* UINT32 ulRetVal = BSP_OK; */
    UINT32 ulFpgaType = FPGA_DEVICE_PANGO;
    if(BSP_OK == BspCheckPangoId(ulFpgaIndex))
    {
        ulFpgaType = FPGA_DEVICE_PANGO;
    }
    else if(BSP_OK == BspCheckLatticeId(ulFpgaIndex))
    {
        ulFpgaType = FPGA_DEVICE_LATTICE;
    }
    else
    {
        ulFpgaType = FPGA_DEVICE_PANGO;
    }
    return ulFpgaType;
}

UINT32 BspLoadSwvVersion(T_VerLoadInfo *loadInfo)
{
    UINT32      retVal          = BSP_OK;
    UINT32      ret             = 0;
    char        swvFile[128]    = {0};
    UINT32      softType        = BSP_ERROR;
    UINT32      verType         = BSP_RUN_VERSION;
    UINT32      postRes         = 0;
    int         ret_s           = 0;
    UINT32      i               = 0;
    char        processName[30] = {0};
    char        binFileName[60] = {0};
    UINT32      loadErrMask     = 0;    // 每个组件4个bit的错误码，一共支持记录8个组件的错误原因
    UINT32      hashSelect      = 0;
    UINT32      fpgafactoryId    = 0;
    T_FpgaCfgModePriv tFpgaCfgInfo = {0};
    LoadBinVersionFunc loadVerFunc = NULL;
    GetFpgaFactory getfpgafactory = NULL;

    for (i = 0; i < loadInfo->infoLen; i++)
    {
        memset_s(processName, sizeof(processName), 0, sizeof(processName));
        memset_s(binFileName, sizeof(binFileName), 0, sizeof(binFileName));
        ret_s = snprintf_s(processName, sizeof(processName), "%s", loadInfo->commonLoadInfo[i].ExeName);
        SNPRINTF_S_CHECK(ret_s, sizeof(processName));
        ret_s = snprintf_s(binFileName, sizeof(binFileName), "/%s", processName);
        SNPRINTF_S_CHECK(ret_s, sizeof(binFileName));
        loadVerFunc = loadInfo->commonLoadInfo[i].loadBinFunc;
        getfpgafactory = loadInfo->commonLoadInfo[i].getFpgaFactory;
        if(loadVerFunc == NULL)
        {
            loadVerFunc = LoadBinVersion;
        }

        ret = loadVerFunc(loadInfo->commonLoadInfo[i].comIndex, binFileName, processName, ((T_FpgaCfgModePriv *)loadInfo->PrvInfo)+i, loadInfo->PrvLen);
        if (ret == BSP_OK)
        {
            continue;
        }

        if (i == 0)
        {
            GetVersionSwvPath(loadInfo, swvFile, sizeof(swvFile), &softType, &verType, &postRes, &hashSelect);
        }

        /*加载逻辑通过识别芯片ID选择不同的verIndex*/
        if(getfpgafactory != NULL)
        {
            fpgafactoryId = getfpgafactory(0);
            dbgInfo("fpgafactoryId = %d\n",fpgafactoryId);

            memcpy_s(&tFpgaCfgInfo, sizeof(T_FpgaCfgModePriv),((T_FpgaCfgModePriv *)loadInfo->PrvInfo)+i,sizeof(T_FpgaCfgModePriv));
            if(fpgafactoryId != tFpgaCfgInfo.tFpgaCfgPrivEx.devType)
            {
                continue;
            }
        }

        dbgInfo("fpga version loop = %d num = %d\n",i,loadInfo->infoLen);

        retVal |= BspLoadVersionFromSwv(loadInfo, i, swvFile, processName, binFileName, softType, hashSelect, postRes, &verType, &loadErrMask);
        BspSetModuleSoftFlag(SWITCH_ON);
    }
#ifndef PLAT_X86_TEST
    if (loadInfo->swvName == NULL || loadInfo->loadType != VERSION_LOAD_TYPE_COMPONENTIZED)
    {
        BspRecordVerLoadRes(softType, loadErrMask, verType);
    }
#endif

    return retVal;
}

UINT32 UnzipTheTarPackage(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum)
{
    int ret = 0;
    char binFileNameBuf[60] = {0};
    char * const argv[4] = {"tar", "-jxvf", binFileNameBuf, NULL};
    rsize_t argc = 4;
    char * const pathlist[1] = {"/bin/tar"};
    rsize_t pathlist_size = 1;
    rsize_t len = 0;

    len = strnlen_s(binFileName, 60);
    if (len <= 0)
    {
        (VOID)remove(binFileName);
        dbgErr("%s>>strnlen_s failed[len %lx]\n", __FUNCTION__, len);
        return BSP_ERROR;
    }

    ret = strncpy_s(binFileNameBuf, sizeof(binFileNameBuf), binFileName, len);
    if (ret != 0)
    {
        (VOID)remove(binFileName);
        dbgErr("%s>>strncpy_s failed[ret %x]\n", __FUNCTION__, ret);
        return BSP_ERROR;
    }

    ret = zte_system_s("/bin/tar", argv, argc, pathlist, pathlist_size);
    if (ret != 0)
    {
        (VOID)remove(binFileName);
        dbgErr("%s>>tar -jxvf %s failed[ret %x]\n",__FUNCTION__, binFileName, ret);
        return BSP_ERROR;
    }

    // 删除临时文件
    (VOID)remove(binFileName);

    return BSP_OK;
}

UINT32 BspRecordBootVerFileInfoInit(void)
{
    UINT32 ret = BSP_OK;
    UINT32 masterBootCrc = 0;
    UINT32 masterBootLength = 0;
    CHAR bootVerName[VERNO_LEN] = {0};
    T_VerFileHeader tVerFileHeader = {0};

    ret |= BspGetBootVersion(bootVerName, VERNO_LEN);
    bootVerName[VERNO_LEN-1] = '\0';
    dbgInfo("[%s]BootVer: MasterBoot= [%s]\n", __FUNCTION__, bootVerName);

    ret |= BspGetMasterBootHeadInfo(&tVerFileHeader);
    masterBootCrc = ntohl(tVerFileHeader.ulCRC32);
    masterBootLength = ntohl(tVerFileHeader.ulCompressedSize);
    dbgInfo("[%s]CRC = %d, SIZE = %d\n", __FUNCTION__, masterBootCrc,masterBootLength);

    ret |= BspSaveModuleSoftInfo(SOFT_TYPE_UPDATEBOOT, masterBootCrc, masterBootLength + sizeof(T_VerFileHeader), bootVerName);

    return ret;
}

UINT32 BspRecordHashVer(void)
{
    UINT32      location        = 0;
    INT32       fpgaFlag        = 0;
    CHAR     filePath[NAME_MAX] = {0};
    T_VerFileHeader verHead     = {0};
    T_XMLLIST_PARA  loadVerPara = {0};

    BspSetModuleSoftVersion(SOFT_TYPE_FPGA0, NULL, 0);
    BspClrVerLoadRes();
    BspClrModuleVerErrReason(0);

    // QCELL有些环境会放XML,为了保证准确性,再加上 BspGetWriteXmlToProtectEnable 条件
    if ((BspGetWriteXmlToProtectEnable() == WRITE_XML_FILE_TO_PROTECT_ZONE) &&
        (BspGetXmlListPara(SOFT_TYPE_VERIFY, &loadVerPara) == BSP_OK))
    {
        // 此次修改前使用FPGA_VER_FLAG来确定hash文件名,在非安全环境可能存在dsp版本升级,hash版本不升级的场景
        // 宏站(非QCELL)机型,版本加载是组件化形式,hash的文件名从xml中获取,xml中的文件名是准确的.
        if (loadVerPara.ulHashSelect == 1)
        {
            location = BSP_ACK_VERSION;
        }
        else
        {
            location = BSP_RUN_VERSION;
        }
        (void)snprintf_s(filePath, sizeof(filePath), "/ata/rru/%s", loadVerPara.acFileName);
        BspLog(LOG_LEVEL_0, "%s>>not qcell, filepath:%s\n", __FUNCTION__, filePath);
    }
    else
    {
        // QCELL机型,版本加载是非组件化形式,不使用xml,且ini文件中的FPGA_VER_FLAG只用来控制hash文件的升级状态,状态是准确的
        fpgaFlag = BspGetRruIniFlag();
        if (fpgaFlag == ACTIVE_BOOT)
        {
            location = BSP_ACK_VERSION;
            (void)snprintf_s(filePath, sizeof(filePath), "/ata/rru/tmp27.swv");
        }
        else
        {
            location = BSP_RUN_VERSION;
            (void)snprintf_s(filePath, sizeof(filePath), "/ata/rru/cur27.swv");
        }
        BspLog(LOG_LEVEL_0, "%s>>qcell, fpgaFlag:0x%x, filepath:%s !\n", __FUNCTION__, fpgaFlag, filePath);
    }

    if (BspGetSwVerHead(filePath, &verHead) != BSP_OK)
    {
        BspLog(LOG_LEVEL_0, "%s>>BspGetSwVerHead failed, filepath:%s !\n",__FUNCTION__,filePath);
        if (BspGetProtectVerInfo(SOFT_TYPE_VERIFY, &verHead) != BSP_OK)
        {
            return BSP_ERROR;
        }
        location = BSP_PROVERSION;
    }
    BspRecordVerLoadRes(SOFT_TYPE_VERIFY, 0, location);

    /* 设置HASH版本信息到全局变量,供版本比对使用 */
    BspSetModuleSoftVersion(SOFT_TYPE_VERIFY, verHead.ucVerNo, VERNO_LEN);
    BspSaveModuleSoftInfo(SOFT_TYPE_VERIFY, verHead.ulCRC32, verHead.ulCompressedSize + sizeof(T_VerFileHeader), verHead.ucVerNo);

    return BSP_OK;
}

UINT32 BspInitBoardType(void)
{
    UINT32 rpuId = BspGetRpuId();

    if (rpuId == 0)
    {
        BspSetMGRType(MASTER_BOARD_MGR_S);
    }
    else
    {
        BspSetMGRType(SLAVE_BOARD_MGR);
    }
    return BSP_OK;
}

static UINT32 VerGetInvalidStrLen(char *pucSoftVer, UINT32 ulVerLen)
{
    UINT32 ulLoop = 0;
    UINT32 ulInvalidLen0xFF = 0;
    UINT32 ulInvalidLen0x00 = 0;
    UINT32 ulRetValidStrLen = 0;

    if (pucSoftVer == NULL)
    {
        ulRetValidStrLen = VERNO_LEN + 3;
        return ulRetValidStrLen;
    }

    for (ulLoop = 0; ulLoop < ulVerLen; ulLoop++)
    {
        if (0x00 == pucSoftVer[ulLoop])
        {
            ulInvalidLen0x00++;
        }
        else if (0xFF == pucSoftVer[ulLoop])
        {
            ulInvalidLen0xFF++;
        }
    }

    /* 检测SoftVer信息是否全0x00, 是返回值VERNO_LEN + 2 */
    if (ulInvalidLen0x00 >= ulVerLen)
    {
        ulRetValidStrLen = VERNO_LEN + 2;
        return ulRetValidStrLen;
    }

    /* 检测SoftVer信息是否全0xFF, 是返回值VERNO_LEN + 1 */
    if (ulInvalidLen0xFF >= ulVerLen)
    {
        ulRetValidStrLen = VERNO_LEN + 1;
        return ulRetValidStrLen;
    }

    return ulRetValidStrLen;
}

static void PRN_VER_LOAD_ERR_REASON(const CHAR *softName, UINT32 GetStatus, T_CtrlVerErrReason *tLdErrReason, char *pPrnName, UINT32 *pLdReason)
{
    int ret = 0;
    const char *pcMacroVerName = softName;

    INPUT_POINTER_CHECK_RET_NONE_VALUE(softName);
    INPUT_POINTER_CHECK_RET_NONE_VALUE(tLdErrReason);
    INPUT_POINTER_CHECK_RET_NONE_VALUE(pPrnName);
    INPUT_POINTER_CHECK_RET_NONE_VALUE(pLdReason);

    if (GetStatus == BSP_OK)
    {
        switch(tLdErrReason->ucRunVer)
        {
            case BSP_RUN_VERSION:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Run Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = tLdErrReason->ucMasterVerErr;
                break;
            }
            case BSP_BAK_VERSION:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Back Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = tLdErrReason->ucSlaveVerErr;
                break;
            }
            case BSP_BIN_DEF_VERSION:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Bin Def Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = tLdErrReason->ucBinDefaultVerErr;
                break;
            }
            case BSP_BAK_DEF_VERSION:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Back Def Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = tLdErrReason->ucBakDefaultVerErr;
                break;
            }
            case BSP_ACK_VERSION:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Ack Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = tLdErrReason->ucAckVerErr;
                break;
            }
            case BSP_PROVERSION:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Protect Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = tLdErrReason->ucProtectVerErr;
                break;
            }
            case BSP_BOOT_PROVERSION:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Spec Protect Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = 0;
                break;
            }
            default:
            {
                ret=snprintf_s((pPrnName), VERNO_LEN, "%s Unknow Ver", pcMacroVerName);
                SNPRINTF_S_CHECK(ret, VERNO_LEN);
                (*pLdReason) = 0xFEFC;
                break;
            }
        }
    }
    else
    {
        ret=snprintf_s((pPrnName), VERNO_LEN, "%s VerReasonGetErr", pcMacroVerName);
        SNPRINTF_S_CHECK(ret, VERNO_LEN);
        (*pLdReason) = 0xFFFFFFFF;
    }
}

void verload(void)
{
    UINT32 ulVerErrReason  = 0;
    UINT32 ulVerNameStrLen = 0;
    UINT32 softType = 0;
    UINT32 ulTmpRet = BSP_OK;
    T_CtrlVerErrReason tVerErrReason = {0};
    char aucSoftVer[VERNO_LEN + 1] = {0};
    char aucLoadVerName[VERNO_LEN + 1] = {0};
    const char *pucSoftVerBuf = NULL;
    UINT32 ulCnt = 0;
    T_NameSoftTypeList *softTypeList = NULL;
    UINT32 listLen = 0;

    BspGetSoftTypeList(&softTypeList, &listLen);
    for (ulCnt = 0; ulCnt < listLen; ulCnt ++)
    {
        CONTINUE_IF_EXP(softTypeList[ulCnt].versionStatus != VERSION_REQUIRED &&
                    softTypeList[ulCnt].versionStatus != VERSION_OPTIONAL_ENABLE);
        memset_s(aucSoftVer, sizeof(aucSoftVer), 0, sizeof(aucSoftVer));
        memset_s(&tVerErrReason, sizeof(tVerErrReason), 0, sizeof(tVerErrReason));
        softType = softTypeList[ulCnt].ulSoftType;
        BspGetModuleSoftVersion(softType, aucSoftVer, VERNO_LEN);
        ulVerNameStrLen = VerGetInvalidStrLen(aucSoftVer, VERNO_LEN);
        if (ulVerNameStrLen <= VERNO_LEN)
        {
            pucSoftVerBuf = aucSoftVer;
        }
        else
        {
            pucSoftVerBuf = "Ver NULL";
        }

        ulTmpRet = BspGetModuleVerErrReason(softType, &tVerErrReason);
        PRN_VER_LOAD_ERR_REASON(softTypeList[ulCnt].name, ulTmpRet, &tVerErrReason, aucLoadVerName, &ulVerErrReason);
        RedirPrintf("%s%-11d: %-25s ErrReason(%u)\n", aucLoadVerName, softType, pucSoftVerBuf, ulVerErrReason);
    }
}

void verswv(void)
{
    CHAR   temp[VERNO_LEN + 1] = {0};
    T_VerFileHeader verHead = {0};
    UINT32 ulCnt = 0;
    UINT32 softType = 0;
    CHAR fileName[NAME_MAX] = {0};
    T_NameSoftTypeList *softTypeList = NULL;
    UINT32 listLen = 0;

    if (BspGetBootVersion(temp, VERNO_LEN) == 0)
    {
        RedirPrintf("%-20s: %-20s\n", "Boot Ver(M)", temp);
    }
    BspGetSoftTypeList(&softTypeList, &listLen);
    for(ulCnt = 0;ulCnt < listLen; ulCnt ++)
    {
        CONTINUE_IF_EXP(softTypeList[ulCnt].versionStatus != VERSION_REQUIRED &&
                    softTypeList[ulCnt].versionStatus != VERSION_OPTIONAL_ENABLE);
        softType = softTypeList[ulCnt].ulSoftType;
        if (softType > SOFT_TYPE_CUR)
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/cur%u.swv", softType);
        }
        else
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/cur.swv");
        }
        (void)BspGetSwVerHead(fileName, &verHead);
        BspSecondToDate(temp, 32, verHead.ulCreateTime, 8);
        verHead.ucVerNo[VERNO_LEN-1] = '\0';
        RedirPrintf("%s%-15d: %-25s, %s\n", "Ver cur", softType,verHead.ucVerNo, temp);

        if (softType > SOFT_TYPE_CUR)
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/tmp%u.swv", softType);
        }
        else
        {
            (void)snprintf_s(fileName, sizeof(fileName), "/ata/rru/tmp.swv");
        }
        (void)BspGetSwVerHead(fileName, &verHead);
        BspSecondToDate(temp, 32, verHead.ulCreateTime, 8);
        verHead.ucVerNo[VERNO_LEN-1] = '\0';
        RedirPrintf("%s%-15d: %-25s, %s\n", "Ver tmp", softType,verHead.ucVerNo, temp);

        if (BSP_OK == BspGetProtectModuleFileInfo(softType, 0, &verHead))
        {
            verHead.ucVerNo[VERNO_LEN - 1]= '\0';
            BspSecondToDate(temp, 32, verHead.ulCreateTime, 8);
            RedirPrintf("%s%-3d: %-25s, %s\n", "Ver ProtectZone cur", softType,verHead.ucVerNo, temp);
        }
        else
        {
            RedirPrintf("%s>>ProtectZone Module Ver Get Error!\n", __FUNCTION__);
        }
        showloaderr(softTypeList[ulCnt].name);
        RedirPrintf("\n");
    }
}

void verbaseex(void)
{
    const char *bitStr = NULL;

    if (sizeof(void *) == 8)
    {
        bitStr = "64-bit";
    }
    else
    {
        bitStr = "32-bit";
    }
    dbgInfo("BIN CLASS     : %s\n", bitStr);
}

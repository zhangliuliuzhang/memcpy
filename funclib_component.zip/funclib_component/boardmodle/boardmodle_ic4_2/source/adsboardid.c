/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : adsboardid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ADS测试中打桩获取单板id的实现
* 注意事项 : 无
* 作    者 : 10102065
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "rruinfo.h"
#include "boardmodle_ic4_2.h"
/*#include "adsboardid.h"*/

#if defined PLAT_X86_TEST || defined FUNCLIB_ADS  /* 本代码仅供在X86平台软仿测试及ADS板验证时使用 */

/**************************************************************************
                                 宏定义
**************************************************************************/
#define ADS_BOARD_ID_FILE_NAME "/adstestboardid.txt"



/**************************************************************************
                         获取单板ID的打桩
**************************************************************************/
UINT32 g_adsTestChipId = 0;

UINT32 BspAdsTestGetChipId(VOID)
{
    return g_adsTestChipId;
}

static VOID readAdsTestBoardId(UINT32 *boardId, UINT32 *chipId)
{
    FILE *fp = NULL;
    UCHAR str[10] = {0};
    UCHAR *pBoardId = NULL;
    UCHAR *pChipId = NULL;
    INT32 fRet = 0;

    fp = fopen(ADS_BOARD_ID_FILE_NAME,"r");
    if(fp != NULL)
    {
	    if(fgets(str,9,fp) != NULL)
        {   
            pBoardId = str;
            pChipId = strstr(str,",");
            if(NULL != pChipId)
            {
                *pChipId = 0;
                pChipId = pChipId + 1;
                *boardId = atoi(pBoardId);
                *chipId = atoi(pChipId); 
            }
        }
	    fRet = fclose(fp);
        FCLOSE_CHECK(fRet);
    }
}

static UINT32 BspAdsTestSetHwId(UINT32 boardId)
{
    UINT32 retVal = BSP_OK;
    UINT32 id[4] = {0};
    TVerGroup *pPara = NULL;
    UINT32 num = 0;
    UINT32 actType = 0;
    
    /* 获取VerGroup的信息 */
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_BOARD_ID,0,0,pPara,num);

    id[0] = pPara[boardId].HardId[MOD_GROUP_ID];
    id[1] = pPara[boardId].HardId[BRD_GROUP_ID];
    id[2] = pPara[boardId].HardId[BRD_TYPE_ID];
    id[3] = pPara[boardId].HardId[HW_CHANGE_ID];

    BspSetHwId(id[0],id[1],id[2],id[3]);

    boardid16();

    return retVal;
}

UINT32 BspAdsTestGetHwId(VOID)
{
    UINT32 boardId = 0;
    UINT32 chipId = 0;

    readAdsTestBoardId(&boardId, &chipId); 
    
    BspAdsTestSetHwId(boardId);
    g_adsTestChipId = chipId;

    return BSP_OK;
}

#endif


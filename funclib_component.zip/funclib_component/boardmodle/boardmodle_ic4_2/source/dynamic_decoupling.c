/*****************************************************************************
* 版权所有(C) 2023, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : dynamic_decoupling.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件按照动态库需要，存放funclib_component下各模块解耦所被调整位置的接
*           口，暂时存放，后续或根据高层多进程化有新的调整，待所有接口被妥善调整后请
*           删除此源文件与对应头文件。
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2023-08-02 11：46：00
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "ru_basedef.h"
#include "dynamic_decoupling.h"
#include "ichaladapt_crm_ic4_2.h"
#include "ichaladapt_ic4_2.h"
#include "funccommonapi.h"
#include "chnmap_a.h"
#include "zprintf.h"
#include "exprn.h"



BSP_QCELL_GET_ANT_LINK_STATUS qcellGetLInkStatus_ep214 = NULL;

UINT32 BspQcellSetAntLinkStatusFun(BSP_QCELL_GET_ANT_LINK_STATUS pFunc)
{
    qcellGetLInkStatus_ep214 = pFunc;
    return BSP_OK;
}

/* QCELL EP214专用，获取天线在位状态 */
UINT32 BspGetQcellAntLInkStatus(UINT32 *status)
{
    if (NULL != qcellGetLInkStatus_ep214)
    {
        return qcellGetLInkStatus_ep214(status);
    }
    
    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称:BspGetAntLinkStatus
 * 功能描述:对外接口，提供所有天线在位状态，供高层告警使用
 * 输入参数: 无
 * 输出参数: uStatus：天线在位状态位图
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月06日    wangfei    创建
 **************************************************************************/
UINT32 BspGetAntLinkStatus(UINT32 *uStatus)
{
    UINT32    ret = BSP_OK;
    UINT32    bspChn = 0;
    UINT32    antDetPinId  = 0;
    UINT32    antMap = 0;
    UINT32    antDetMap = 0;
    UINT32    historyMap = 0;/* 历史的天线在位状态，如果天线在位检测失败，则上报历史状态 */

    if (RRU_BBU_EP214 == BspGetPbOrBbuMode())/* 如果是qcell EP214机型才走这个 */
    {
        return BspGetQcellAntLInkStatus(uStatus);
    }
    
    ret |= BspHalAdaptGetAwRpt(&antDetMap);

    for(bspChn = 0; bspChn < BspGetTxChannel(); bspChn++)
    {
        ret |= BspGetAntDetPinIdByBspChn(bspChn, &antDetPinId);
        antMap |= ((antDetMap >> antDetPinId) & 0x1) << bspChn;
    }

    if(ret == BSP_OK)
    {
        *uStatus = antMap;
        historyMap = antMap;
    }
    else/* 如果检测失败的话，则上报历史天线在位状态 */
    {
        *uStatus = historyMap;
    }

    dbgInfoEx("uStatus: %d historyMap: %d\n", *uStatus, historyMap);

    return BSP_OK;
}

VOID prnantdetmap(VOID)
{
    UINT32    bspChn  = 0;
    UINT32    antDetPinId  = 0;
    UINT32    antDetMap = 0;
    UINT32    antLinkStatus = 0;

    for(bspChn = 0; bspChn < BspGetTxChannel(); bspChn++)
    {
        BspGetAntDetPinIdByBspChn(bspChn, &antDetPinId);
        dbgInfo("\n %2d-%2d: ", bspChn, antDetPinId);
    }
    BspHalAdaptGetAwRpt(&antDetMap);
    dbgInfo("\naw map info: 0x%x\n", antDetMap);
    BspGetAntLinkStatus(&antLinkStatus);
    dbgInfo("\nantLinkStatus: 0x%x\n", antLinkStatus);
    dbgInfo("\n");
    return;
}

UINT32 getantdetmap(VOID)
{
    UINT32    bspChn  = 0;
    UINT32    antDetPinId  = 0;
    UINT32    antDetMap = 0;
    UINT32    antLinkStatus = 0;

    for(bspChn = 0; bspChn < BspGetTxChannel(); bspChn++)
    {
        BspGetAntDetPinIdByBspChn(bspChn, &antDetPinId);
        dbgInfo("\n %2d-%2d: ", bspChn, antDetPinId);
    }
    BspHalAdaptGetAwRpt(&antDetMap);
    dbgInfo("\naw map info: 0x%x\n", antDetMap);
    BspGetAntLinkStatus(&antLinkStatus);
    dbgInfo("\nantLinkStatus: 0x%x\n", antLinkStatus);
    dbgInfo("\n");

    return antLinkStatus;
}

static UINT32 GetRfFpgaMaxTempTest(VOID)
{
    INT32 lpTemp = 0;

    if (BSP_OK != BspGetRfFpgaMaxTempResult(&lpTemp))
    {
        dbgErr("[%s]:Get Max Rf Fpga Temperature Failed!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("[%s]The Max Temperature Is %5.2f (Centigrade) of RFFPGA\n", __FUNCTION__, lpTemp / 10.0);

    return BSP_OK;
}

UINT32 BspGetRfFpgaMaxTempResult(INT32 *lMaxTemp)
{
    UINT32 ret = BSP_OK;
    INT32 temp0 = 0;
    INT32 temp1 = 0;

    ret = BspHalAdaptGetIcCalibrationTemp(&temp0, &temp1);
    *lMaxTemp = temp0 / 10;
    dbgInfoEx("Temp0 %.2lf degree, Temp1 %.2lf degree\n", temp0 / 100.0, temp1 / 100.0);
    return ret;
}


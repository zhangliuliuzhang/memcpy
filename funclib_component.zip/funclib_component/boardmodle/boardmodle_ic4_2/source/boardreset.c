/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeature-hardid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bspcomm.h"
#include "funccommon.h"
#include "boardid.h"
#include "boardreset.h"
#include "funccommon_a.h"
#include "pwr_a.h"
#include "regdrv.h"
#include "ichaladapt_ic4_2.h"
#include "ichaladapt_pwr_ic4_2.h"
#include "board_ic4_2.h"
#include "pa_ic4_2_ctrl.h"
#include "gainctrlcommon.h"
#include "systemcallapi.h"
#include "cpam_inter_api.h"
#include "dpdicxmodem.h"
#include "optctrlcommon.h"
#include "fpgaloadprocess.h"
#include "ichaladapt_crm_ic4_2.h"
#include "boardmodle_ic4_2.h"
#include "optctrl_cpri_ic4_2.h"
#include "optadpt.h"
#include "chippoweronwrapper.h"
#include "boardcorefunc.h"
#ifndef MULT_PROGRESS_S
#include "ledctrl_a.h"
#endif
/**************************************************************************
*                            全局变量定义                                       *
**************************************************************************/

static T_FpgaReLoadFlagFun s_fpgaReLoadFlagFun =
{

    .FpgaReLoadFlagSet = BspFpgaReLoadFlagSet,
    .FpgaReLoadFlagGet = BspFpgaReLoadFlagGet,
    .InitFlag = 1,
};
static UINT32 g_ulFpgaReLoadFlag = 0xffffffff;
static UINT32 rstEnableFlag = 0x5a5a;
static UINT32 s_DisableFlowCtrl = DISABLE;
static E_BOARD_MS_FLAG s_MsFlag = E_OTHER_BOARD_TYPE;
static FUNC_BSP_BOARD_SOC_RESET s_pFuncBoardSocReset = NULL;
static FUNC_BOARD_SOFT_RST pBoardSoftRst = NULL;
static FUNC_BSP_BOARD_M_RESET s_pFuncBoardMasterPreReset = NULL;
UINT32 g_ulBoardSetResetFlag = 0;
/**************************************************************************
*                                宏定义                                      *
**************************************************************************/
#define DPDIC_RST_TYPE_INFO(chipIdx)  {REG_RPU##chipIdx##_EXT_RESET,REG_RPU##chipIdx##_POR_RESET}
#define IF(x) if(x)
#define FOR(x) for(x) 

/**************************************************************************
*                                接口定义                                     *
**************************************************************************/
UINT32 BspBoardSoftResetCallBack(FUNC_BOARD_SOFT_RST pFunc)
{
    pBoardSoftRst = pFunc;
    return BSP_OK;
}

UINT32 BspBoardMasterPreResetCallBack(FUNC_BSP_BOARD_M_RESET pFunc)
{
    s_pFuncBoardMasterPreReset = pFunc;
    return BSP_OK;
}
UINT32 BspSetBoardResetFlag(VOID)
{
    g_ulBoardSetResetFlag = 1;
    return BSP_OK;
}

UINT32 BspGetBoardResetFlag(VOID)
{
    return g_ulBoardSetResetFlag;
}

/*配置是否初始化时钟或光口的标志，0为不初始化，1位初始化*/
VOID BspFpgaReLoadFlagSet(UINT32 ulReFlag)
{
    UINT32 ulRegVal = 0;
    UINT32 bitVal = 0;
    UINT32 regAddr = 0xd4c001d0;
    BspHalAdaptDpdicRegRd(0,regAddr,0,&ulRegVal);
    dbgInfo("[%s] source reg value is %d\n",__FUNCTION__,ulRegVal);
    bitVal = (ulReFlag==0)?(1):(0);  //上电默认值是0
    if(bitVal == 0)
    {
        ulRegVal = BIT_REV(0) & ulRegVal;
    }
    else
    {
        ulRegVal = BIT_SET(0) | ulRegVal;
    }
    dbgInfo("[%s] bitVal'%d ulRegVal'%d\n",__FUNCTION__,bitVal,ulRegVal);
    BspHalAdaptDpdicRegWr(0,regAddr,0,ulRegVal);/*bit0为 是否重配光口的标志*/
}
/*获取是否初始化时钟或光口的标志，0为不初始化，1位初始化*/
UINT32 BspFpgaReLoadFlagGet(VOID)
{
    UINT32 ulRegVal = 1;
    UINT32 regAddr = 0xd4c001d0;
    if(g_ulFpgaReLoadFlag != 0xffffffff)
    {
        return g_ulFpgaReLoadFlag;
    }
    BspHalAdaptDpdicRegRd(0,regAddr,0,&ulRegVal);
    g_ulFpgaReLoadFlag = ((ulRegVal&0x1) == 0)?(1):(0);
    dbgInfo("%sFpga reload RegVal 0x%x\n",__FUNCTION__,ulRegVal);
    
    return g_ulFpgaReLoadFlag;
}

static void BspSetMasterSlaveFlag(E_BOARD_MS_FLAG msFlag)
{
    s_MsFlag = msFlag;
}

static E_BOARD_MS_FLAG BspGetMasterSlaveFlag(void)
{
    return s_MsFlag;
}

/*适用于单片*/
UINT32 BspResetDeviceInit(VOID)
{
    BspSetMasterSlaveFlag(E_MASTER_BOARD_TYPE);
    BspResetDeviceCallBackInit(BspDevReset);
    BspInitFpgaReLoadFun(&s_fpgaReLoadFlagFun);
    return BSP_OK;
}

UINT32 BspDevReset(OSS_ULONG devId, UINT32 resetType, UINT32 cause)
{
    UINT32  idBase = 0;
    UINT32  idInnerIndex = 0;

    BspDevIdToBase(devId, &idBase, &idInnerIndex);

    dbgInfoEx("devId=%#lx idBase=%d idInnerIndex=%d\n",devId,idBase,idInnerIndex);
    fpgaloadLog(LOAD_INFO,"[%s] devId=%lu idBase=%d idInnerIndex=%d\n", __FUNCTION__, devId,idBase,idInnerIndex);
    switch (idBase)
    {
        case BSP_DEVICE_ID_BOARD0:  /* 单板复位     */
        {
            dbgInfo("[Bsp Reset] Cause: %x\n", cause);
            BspSysMsDelay_Sys(1000);
            BspBoardSetReset(resetType, cause);
            break;
        }
        case BSP_DEVICE_ID_FPGA0:
            dbgInfo("reset fpga%d!!!!!!!!!\n", idInnerIndex);
            BspResetFpga(idInnerIndex);
            break;
        default:
            break;
    }
    return BSP_OK;
}

UINT32 BspBoardPwrOff(UINT32 resetType, UINT32 cause)
{
    fpgaloadLog(LOAD_INFO,"[%s] resetType %d cause %d\n", __FUNCTION__, resetType, cause);
    if (resetType != BSP_RESET_TYPE_PWROFF)
    {
        return BSP_OK;
    }
    dbgInfo("******recv pwr off command:cause %d******\n",cause);
    BspHalAdaptMaskPwrOffAlarmReport();
    BspRruLinkPwrOffPreProc();
    BspCtrlPm(0, 0);
    BspSysMsDelay_Sys(5000);
    return BSP_OK;
}

void BspSetDisableFlowCtrl(UINT32 enable)
{
    s_DisableFlowCtrl = enable;
}

static UINT32 BspGetDisableFlowCtrl(void)
{
    return s_DisableFlowCtrl;
}

/*
 * is ubifs readonly filesystem
   0:  rw
   1:  ro
   2:  filesystem mount error
  -1:  error
*/
 #define FS_FILESYSTEM_NOTMOUNT         2
 #define FS_FILESYSTEM_READONLY         1
 #define FS_FILESYSTEM_RW               0
static INT32 fs_isro(void)
{
    FILE *fd            = NULL;
    char pReadBuf[100]  = {0};
    char acStr1[30]     = {0};
    char acStr2[30]     = {0};
    char acStr3[30]     = {0};
    char acStr4[30]     = {0};
    int ret             = -1;
    int cmdRet          = 0;

    #define MOUNT_INFO_FILE "/proc/mounts"

    fd = fopen(MOUNT_INFO_FILE, "r");
    if(fd == NULL)
    {
        dbgErr("%s: Can not open /proc/mounts\n", __FUNCTION__);
        return -1;
    }

    /* 循环读取每行 */
    while (NULL != fgets(pReadBuf, sizeof(pReadBuf), fd))
    {
        /* ubi0_0 /mnt/filesystem ubifs rw,sync,relatime 0 0 */
        cmdRet = sscanf_s(pReadBuf ,"%6s %15s %5s %2s,", acStr1, acStr2, acStr3, acStr4);
        if (cmdRet != 4)
        {
            dbgInfoEx("%s: sscanf_s failed, ret = %d\n", __FUNCTION__, cmdRet);
        }
        if(strncmp("/mnt/filesystem", acStr2, 20) == 0)
        {
            if(strncmp("rw", acStr4, 10) == 0)
            {
                ret = FS_FILESYSTEM_RW;
            }
            else if(strncmp("ro", acStr4, 10) == 0)
            {
                ret = FS_FILESYSTEM_READONLY;
            }
            break;
        }
        memset_s(pReadBuf, sizeof(pReadBuf), 0, sizeof(pReadBuf));
        memset_s(acStr1, sizeof(acStr1), 0, sizeof(acStr1));
        memset_s(acStr2, sizeof(acStr2), 0, sizeof(acStr2));
        memset_s(acStr3, sizeof(acStr3), 0, sizeof(acStr3));
        memset_s(acStr4, sizeof(acStr4), 0, sizeof(acStr4));
    }
    /*没有找到*/
    if(ret == -1)
    {
        dbgErr("%s: filesystem not mount\n", __FUNCTION__);
        ret = FS_FILESYSTEM_NOTMOUNT;
    }

    cmdRet = fclose(fd);
    FCLOSE_CHECK(cmdRet);
    return ret;
}

FUNC_BSP_RESET_CPE pResetCpeFunc = NULL;

UINT32 BspSetResetCpeFunc(FUNC_BSP_RESET_CPE pFunc)
{
    pResetCpeFunc = pFunc;

    return BSP_OK;
}

UINT32 BspSetTxSwOff(VOID)
{
    UINT32 ret  = 0;
    UINT32 chan = 0;

    if(NULL != pResetCpeFunc)
    {
        ret |= pResetCpeFunc();
    }

    for(chan = 0; chan < BspGetTxChannel(); chan++)
    {
        BspSetPaSwitch(chan, 0);      /* 关功放 */
        BspSetPaPowTxSwitch(chan,0);  /* 关下行小信号 */
        BspSetTxGain(chan, -3150);    /* TX增益设置为最小(需要补充) */
    }

    return ret;
}

UINT32 BspBoardSetReset(UINT32 resetType, UINT32 cause)
{
    UINT32 index = 0;
    UINT32 retVal = BSP_OK;
    INT32 ret = 0;
    UINT32 flag = 0;
    UINT32 regAddr = 0xd4c001d0;
    UINT32 regVal = 0;
    UINT32 rpuId = BspGetRpuId();

    fpgaloadLog(LOAD_INFO, "[%s] rstEnableFlag = %d, RpuId = %d, BoardResetFlag = %d!\n", 
        __FUNCTION__, rstEnableFlag, rpuId, BspGetBoardResetFlag());
    if (rstEnableFlag == 0x2d2d)
    {
        dbgInfo("%s reset is disable\n", __FUNCTION__);
        return BSP_OK;
    }
    dbgInfo("[%s] RpuId = %d, BoardResetFlag = %d!\n", __FUNCTION__, rpuId, BspGetBoardResetFlag());

    optadptoff();
    qcelloptadptoff();
    dbgInfo("[%s] qcelloptadptoff and optadptoff!\n", __FUNCTION__);
    BspSetOptControlAlarmAuto();
    dbgInfo("[%s] BspSetOptControlAlarmAuto!\n", __FUNCTION__);

    exprnadd("BspOptAlmCollect");
    for (index = 0; index < 3; index++)
    {
        BspOptAlmCollect();
        BspSysMsDelay(50);
    }

/* Started by AICoder, pid:y02ff0587dfd7ff148db0a956060ca02ace52cbf */
    if(NOT_QCELL_MODE != BspGetPbOrBbuMode())
    {
        dbgInfo("[%s] off opt Sw2 !\n", __FUNCTION__);
        BspHalAdaptSetSw2TxDstPort(0);
    }
/* Ended by AICoder, pid:y02ff0587dfd7ff148db0a956060ca02ace52cbf */

    //coverity[cert_int36_c_violation:SUPPRESS] 
    IF(1 == BspGetBoardResetFlag())
    {
        FOR(index = 0; index < BspGetTxChannel(); index++)
        {
            BspSetPaSwitch(index, 0);      /* 关功放 */
            BspSetPaPowTxSwitch(index,0);  /* 关下行小信号 */
            BspSetTxGain(index, -3150);    /* TX增益设置为最小(需要补充) */
        }

        FOR(index = 0; index < BspGetRxChannel(); index ++)
        {
            BspSetLnaTddSwitch(index,0); /* 关上行低噪放 */
        }
        BspSysUsDelay(50);
        exit(0);
        return BSP_OK;
    }

    BspBoardPwrOff(resetType, cause);

    BspHalAdaptDpdicRegRd(0,regAddr,0,&regVal);
    flag = ((regVal&0x1) == 0)?(1):(0);
    dbgInfo("flag %d\n",flag);
    fpgaloadLog(LOAD_INFO, "[%s] flag %d\n", __FUNCTION__, flag);
    if((cause == BSP_APP_SOFT_RESET)&&(flag == 1))  /*版本升级*/
    {
        BspHalAdaptCpriCfgFecEn(0,0);
        BspHalAdaptCpriCfgFecEn(1,0);
    }

    retVal |= BspSetTxSwOff();

    for (index = 0; index < BspGetRxChannel(); index ++)
    {
        BspSetLnaTddSwitch(index,0); /* 关上行低噪放 */
    }

    BspSysUsDelay(50);

    /* 对于已经打开流控的单板,复位之前需要关闭流控 */
    if (BspGetDisableFlowCtrl() == ENABLE)
    {
        if (BspNetFlowctrlStop("eth1") != BSP_OK)
        {
            dbgErr("%s: BspNetFlowctrlStop failed\n", __FUNCTION__);
        }
    }
    /* 关闭各串网口、中断，避免二次内核跳转期间异常 */
    retVal |= BspNetDeviceClose("eth0");
    if (retVal != BSP_OK)
    {
        dbgErr("!!! BspNetDeviceClose  eth0 Error  !!!\n");
    }
    retVal |= BspNetDeviceClose("eth1");
    if (retVal != BSP_OK)
    {
        dbgErr("!!! BspNetDeviceClose  eth1 Error  !!!\n");
    }

    if (BspGetMasterSlaveFlag() == E_MASTER_BOARD_TYPE)
    {
        ret = fs_isro(); /* 判断文件系统是否出过问题，需要在boot中格式化 */
        if ((ret == FS_FILESYSTEM_READONLY) || (ret == FS_FILESYSTEM_NOTMOUNT))
        {
            *(UINT32 *)(uintptr_t)FS_FORMAT_FLAG = 0xdeadbeaf;
            dbgErr("%s>>Filesystem Error! RstType'%d Cause'0x%02X GracefulReboot!\n",
                   __FUNCTION__, resetType, cause);
            BspSetBootStartStep(0);     // 不要直启，希望加载二级boot
        }
    }
    /* kexecreboot failed or special(dboot), or manual reboot,
     * do gracefulreboot for reset.
     */
    BspGracefulReboot(cause);

    return BSP_OK;
}
/*适用于主片主进程*/
UINT32 BspResetDeviceInit_M(VOID)
{
    BspResetDeviceCallBackInit(BspDevReset_M);
    BspInitFpgaReLoadFun(&s_fpgaReLoadFlagFun);
    return BSP_OK;
}

UINT32 BspSetBoardSocResetFunc(FUNC_BSP_BOARD_SOC_RESET pFunc)
{
    s_pFuncBoardSocReset = pFunc;
    return BSP_OK;
}

UINT32 BspDevReset_M(OSS_ULONG devId, UINT32 resetType, UINT32 cause)
{
    UINT32  idBase = 0;
    UINT32  idInnerIndex = 0;

    BspDevIdToBase(devId, &idBase, &idInnerIndex);

    dbgInfoEx("devId=%#lx idBase=%d idInnerIndex=%d\n",devId,idBase,idInnerIndex);
    switch (idBase)
    {
        case BSP_DEVICE_ID_BOARD0:  /* 单板复位     */
        {
            dbgInfo("[Bsp Reset] Cause: %x\n", cause);
            BspSysMsDelay_Sys(1000);
            BspBoardSetReset_M(resetType, cause);
            break;
        }
        case BSP_DEVICE_ID_FPGA0:
            dbgInfo("reset fpga%d!!!!!!!!!\n", idInnerIndex);
            BspResetFpga(idInnerIndex);
            break;
        case BSP_DEVICE_ID_BOARDSOC0:
            if(NULL != s_pFuncBoardSocReset)
            {
                BspChangeSlaveSerialLogDir();
                (*s_pFuncBoardSocReset)(devId,resetType,cause);
            }
            else 
            {
                dbgErr("%s board soc reset callback func is not registered!\n", __func__);
            }
            break;
        default:
            break;
    }
    return BSP_OK;
}
UINT32 BspBoardSetReset_M(UINT32 resetType, UINT32 cause)
{
    UINT32 retVal = BSP_OK;
    INT32 ret = 0;
    UINT32 flag = 0;
    UINT32 regAddr = 0xd4c001d0;
    UINT32 regVal = 0;

    if (rstEnableFlag == 0x2d2d)
    {
        dbgInfo("%s reset is disable\n", __FUNCTION__);
        return BSP_OK;
    }

    optadptoff();
    qcelloptadptoff();
    BspHalAdaptCpriInternalLoopback(LOG_OPT0,DISABLE);   /*主片复位会调用此接口 用于版本回退时恢复寄存器默认值*/
    BspHalAdaptCpriInternalLoopback(LOG_OPT1,DISABLE);
    dbgInfo("[%s] qcelloptadptoff and optadptoff!\n", __FUNCTION__);
    BspSetOptControlAlarmAuto();
    dbgInfo("[%s] BspSetOptControlAlarmAuto!\n", __FUNCTION__);
    if(NOT_QCELL_MODE != BspGetPbOrBbuMode())
    {
        dbgInfo("[%s] off opt Sw2 !\n", __FUNCTION__);
        BspHalAdaptSetSw2TxDstPort(0);
    }
    if(NULL != s_pFuncBoardMasterPreReset)
    {
         s_pFuncBoardMasterPreReset();
    }
    BspBoardPwrOff(resetType, cause);
    BspSysUsDelay(50);
    BspHalAdaptDpdicRegRd(0,regAddr,0,&regVal);
    flag = ((regVal&0x1) == 0)?(1):(0);
    dbgInfo("flag %d\n",flag);
    if((cause == BSP_APP_SOFT_RESET)&&(flag == 1))  /*版本升级*/
    {
        BspHalAdaptCpriCfgFecEn(0,0);
        BspHalAdaptCpriCfgFecEn(1,0);
    }

    /* 对于已经打开流控的单板,复位之前需要关闭流控 */
    if (BspGetDisableFlowCtrl() == ENABLE)
    {
        if (BspNetFlowctrlStop("eth1") != BSP_OK)
        {
            dbgErr("%s: BspNetFlowctrlStop failed\n", __FUNCTION__);
        }
    }
    /* 关闭各串网口、中断，避免二次内核跳转期间异常 */
    retVal |= BspNetDeviceClose("eth0");
    if (retVal != BSP_OK)
    {
        dbgErr("!!! BspNetDeviceClose  eth0 Error  !!!\n");
    }
    retVal |= BspNetDeviceClose("eth1");
    if (retVal != BSP_OK)
    {
        dbgErr("!!! BspNetDeviceClose  eth1 Error  !!!\n");
    }

    ret = fs_isro(); /* 判断文件系统是否出过问题，需要在boot中格式化 */
    if ((ret == FS_FILESYSTEM_READONLY) || (ret == FS_FILESYSTEM_NOTMOUNT))
    {
        *(UINT32 *)(uintptr_t)FS_FORMAT_FLAG = 0xdeadbeaf;
        dbgErr("%s>>Filesystem Error! RstType'%d Cause'0x%02X GracefulReboot!\n",
               __FUNCTION__, resetType, cause);
        BspSetBootStartStep(0);     // 不要直启，希望加载二级boot
    }
    /* kexecreboot failed or special(dboot), or manual reboot,
     * do gracefulreboot for reset.
     */
    BspGracefulReboot(cause);

    return BSP_OK;
}
/*适用于从片*/
UINT32 BspResetDeviceInit_S(VOID)
{
    BspSetMasterSlaveFlag(E_SLAVE_BOARD_TYPE);
    BspResetDeviceCallBackInit(BspDevReset);
    return BSP_OK;
}

VOID BspGracefulReboot(UINT32 cause)
{
    CHAR   buffer[20] = {0,};
    INT32  snpRet = 0;

    memset(buffer,0,sizeof(buffer));
    
    #ifndef MULT_PROGRESS_S
    BspSwitchLedToDefState(SWITCH_ON);
    #endif

    switch (cause)
    {
        case BSP_OMC_SOFT_RESET:
        case BSP_APP_SOFT_RESET:
        case BSP_APP_HARD_RESET:
        case BSP_LOCAL_REBOOTALL:
        case BSP_LOCAL_REBOOT:
        case BSP_LOCAL_SOFTEXCP_RESET:
        {
            snpRet = snprintf_s(buffer, sizeof(buffer), "reboot %d", cause);
            SNPRINTF_S_CHECK(snpRet,sizeof(buffer));
            //96xx soc支持自复位,去掉消息请求复位
            BspSystem(buffer);
            break;
        }
        default:
        {
            dbgErr("%s>>cause error\n", __FUNCTION__);
            break;
        }
    }
}

VOID BspResetFpga(UINT32 chipId)
{
    switch (chipId)
    {
        case 0:
/*             BspRegPinWr(DRV_REG_FPGA0_RESET,0);
            BspSysUsDelay(10);
            BspRegPinWr(DRV_REG_FPGA0_RESET,1); 
            BspSysUsDelay(10);
            BspRegPinWr(DRV_REG_FPGA0_RESET,0); */
            break;
        default:
            break;
    }
}
static UINT32 s_dbgResetReason = 0;
static UINT32 s_m0ResetReason = 0;
static UINT32 s_dbgResetRecord = 0;
static UINT32 s_dbgResetReason1 = 0;
static UINT32 s_dbgResetReason2 = 0;
static VOID showresetreason(VOID)
{
    dbgInfo("Reset Reason: %#x\n", s_dbgResetReason);
    dbgInfo("Reset Reason1: %#x\n", s_dbgResetReason1);
    dbgInfo("Reset Record: %#x\n", s_dbgResetRecord);
    dbgInfo("Reset M0Reason: %#x\n", s_m0ResetReason);
    dbgInfo("Reset Reason2: %#x\n", s_dbgResetReason2);
}

UINT32 BspCrmGetResetReason(UINT32 *rstReason, UINT32 *rstReason_1, UINT32 *rstReason_2)
{
    UINT32 rstReason1 = 0;
    UINT32 rstReason2 = 0;
    UINT32 rstReason1_1=0;
    UINT32 rstReason2_1=0;
    UINT32 count = 0;

    INPUT_POINTER_CHECK(rstReason);
    INPUT_POINTER_CHECK(rstReason_1);
    INPUT_POINTER_CHECK(rstReason_2);

    while(1)
    {
        BspHalAdaptCrmGetResetReason(0, &rstReason1);  //0xd4c00d70
        BspHalAdaptCrmGetResetReason(0, &rstReason2);

        BspHalAdaptCrmGetResetReason(1, &rstReason1_1);  //0xd4c00d74
        BspHalAdaptCrmGetResetReason(1, &rstReason2_1);

        if((rstReason1 == rstReason2) && (rstReason1_1 == rstReason2_1))
        {
            *rstReason = rstReason1;
            *rstReason_1 = rstReason1_1;
            break;
        }
        if(count == 5)
        {
            *rstReason = rstReason2;
            *rstReason_1 = rstReason2_1;
            break;
        }
        count = count + 1;
    }
    BspHalAdaptCfgGetCrmRecordReg(0, 31, rstReason_2);
    BspHalAdaptCfgSetCrmRecordReg(0, 15, 18);
    s_dbgResetReason = *rstReason;
    s_m0ResetReason = *rstReason;
    s_dbgResetReason1 = *rstReason_1;
    s_dbgResetReason2 = *rstReason_2;
    dbgInfo("%s reset reason = %#x, reason1 = %#x, s_dbgResetReason2 = %#x\n", __FUNCTION__, *rstReason, *rstReason_1, *rstReason_2);
    return BSP_OK;
}

UINT32 BspGetSoftResetRes(UINT32 rstRecord)
{
    UINT32 rstReason = 0;
    s_dbgResetRecord = rstRecord;
    rstRecord = rstRecord - 1;
    rstRecord &= 0xff;  /* 低8bit记录复位原因 */

    switch (rstRecord)
    {
        case BSP_LOCAL_REBOOT:
        case BSP_LOCAL_REBOOTALL:
        case BSP_LOCAL_SOFTEXCP_RESET:
        case BSP_APP_HARD_RESET:
        case BSP_EXTERNAL_WATCHDOG_RESET:
        {
            rstReason = rstRecord;
            break;
        }
        case BSP_APP_SOFT_RESET:
        {
            rstReason = rstRecord;
            if(1 == BspGetFpgaReLoadFlag())
            {
                rstReason = BSP_APP_HARD_RESET;
            }
            break;
        }
        default:
        {
            rstReason = BSP_LOCAL_WATCHDOG_RESET;  /* 片内看门狗复位 */
            break;
        }
    }

    return rstReason;
}
/****************************************************************************
* 函数名称: BspGetBoardResetType
* 功能描述: 单板复位原因查询
* 输入参数：无
* 输出参数: 无
* 返 回 值: 复位原因
* 其它说明: TDD/FDD 差别:
            OMC 软复位、硬复位: FDD使用控制字, TDD接收IR消息，高层主动复位
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王勇@2014-5-29,  78e
*----------------------------------------------------------------------------
*/
UINT32 BspGetBoardResetType(VOID)
{
    static UINT32 ulRet = 0xffff;
    UINT32 rstReason = 0;
    UINT32 rstReason_1 = 0;
    UINT32 rstReason_2 = 0;
    UINT32 ulFuncRet = 0;
    UINT32 regAddr = 0xd4c00178;/*内核记录复位原因寄存器*/
    UINT32 rpuId = BspGetRpuId();

    dbgInfoEx("[%s] RpuId = %d, BoardResetFlag = %d!\n", __FUNCTION__, rpuId, BspGetBoardResetFlag());
    if((0 == rpuId) && (1 == BspGetBoardResetFlag()))
    {
        return 0xff;
    }
    
    if(0xffff != ulRet)
    {
        return ulRet;
    }

    BspCrmGetResetReason(&rstReason, &rstReason_1, &rstReason_2);
    if(rstReason_2 & BIT_SET(20))
    {
        BspHalAdaptCfgSetCrmRecordReg(0, 19, 20);
    }

    /* 查询软件复位明细,内核记录 0xd4c00178 */
    BspHalAdaptDpdicRegRd(0,regAddr,0,&ulFuncRet);
    if(rstReason & BSP_BIT(1)) /* por引脚复位(掉电复位) */
    {
        ulRet = BSP_RPDC_PWROFF_RESET; 
    }
    else if (rstReason_1 & BSP_BIT(9))/* 控制字复位 */
    {
        ulRet = BSP_OMC_HARD_RESET;
    }
    else if(rstReason_1 & BSP_BIT(0))
    {
        /*IC外部EXT复位记录*/
        ulRet = BSP_APP_SOFT_RESET;
    }
    else if(rstReason & BIT_SET(2))
    {
        if(rstReason_2 & BIT_SET(15))
        {
            ulRet = BSP_APP_HARD_RESET;  //RRU整板复位
        }
        else
        {
            ulRet = BSP_IC_HARD_RESET;
        }
    }
    else if(rstReason & BSP_BIT(3))/* a53看门狗超时复位 */
    {
        ulRet = BspGetSoftResetRes(ulFuncRet);
    }
    else
    {
        s_dbgResetRecord = ulFuncRet;
        if(0 == ulFuncRet)
        {
            ulFuncRet = 0xff;
        }
        else
        {
            ulFuncRet = ulFuncRet -1;
            ulFuncRet &=0xff;
        }
        ulRet = ulFuncRet;
    }
    /* 清除软件复位明细 */
    BspHalAdaptClrCrmResetReason(0,1,1);/*清除掉电复位记录 0xd4c00d40*/
    BspHalAdaptClrCrmResetReason(0,2,2);/*清除MO 看门狗复位记录 0xd4c00d40*/
    BspHalAdaptClrCrmResetReason(1,9,9);/*清除控制字复位记录 0xd4c00d44*/
    BspHalAdaptClrCrmResetReason(0,3,3);/*清除A53看门狗复位记录 0xd4c00d40*/
    BspHalAdaptClrCrmResetReason(1,0,0);/*清除IC外部EXT复位记录 0xd4c00d44*/
    BspHalAdaptDpdicRegWr(0,regAddr,0,0xff); /*清除内核复位记录*/

    return ulRet;
}

UINT32 BspGetClkAndOptReLoadFlag(VOID)
{
    UINT32 reLoadFlag = 0;
    UINT32 resetType = 0;

    resetType = BspGetBoardResetType();
    reLoadFlag = BspGetFpgaReLoadFlag();
    BspLog(LOG_LEVEL_0,"%s: resetType=%u reLoadFlag=%u s_m0ResetReason=0x%x BspGetFddTddCoExistSta=%u\n",
        __FUNCTION__,resetType, reLoadFlag, s_m0ResetReason, BspGetFddTddCoExistSta());

    if(BSP_OK == BspChkAaxSerdesFile())
    {
        BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_OFF);  /*光口底层1 表示不配 0表示配置*/
        BspLog(LOG_LEVEL_0,"%s:ClkAndOptReload[%d] \n", __FUNCTION__, OPT_AND_CLK_NEED_INIT);
        return OPT_AND_CLK_NEED_INIT;
    }
    if(RRU_PB_BBU == BspGetPbOrBbuMode() || RRU_BBU == BspGetPbOrBbuMode())
    {
    	 return OPT_AND_CLK_NEED_INIT;/*QCELL R8159 机型 连PB模式只要硬复位场景，*/
    }

    if(s_m0ResetReason & BSP_BIT(2)) /*bit2 M0 发起了全芯片复位,需要重配，验证双boot功能发现，此时时钟不重配配crm会挂死，正常不会触发*/
    {
        BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_OFF);  /*光口底层1 表示不配 0表示配置*/
        return OPT_AND_CLK_NEED_INIT;
    }
    if(resetType == BSP_APP_SOFT_RESET)
    {
        BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_ON);  /*光口底层1 表示不配 0表示配置*/
        return OPT_AND_CLK_NOT_NEED_INIT;
    }
    if((resetType == BSP_LOCAL_REBOOT)&&(reLoadFlag == OPT_AND_CLK_NOT_NEED_INIT))
    {
        BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_ON);  /*光口底层1 表示不配 0表示配置*/
        return OPT_AND_CLK_NOT_NEED_INIT;
    }
    if((resetType == BSP_OMC_HARD_RESET)&&(MODE_ONLY_FDD == BspGetFddTddCoExistSta())&&(reLoadFlag == OPT_AND_CLK_NOT_NEED_INIT))
    {   /*FDD机型硬复位不重配光口（复位控制字2bit） TDD重配（控制字1bit）*/
        BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_ON);  /*光口底层1 表示不配 0表示配置*/
        return OPT_AND_CLK_NOT_NEED_INIT;
    }
    BspHalAdaptSetLycaSoftResetFlag(LYCA_SOFT_RESET_OFF);  /*光口底层1 表示不配 0表示配置*/
    return OPT_AND_CLK_NEED_INIT;
}

/**************************************************************************
 * 函数名称: BspSlaveBoardHwReset()
 * 功能描述: 高层app复位从片接口
 * 输入参数: index 0x0 ~ 0xf   为从片ID
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2018年03月5日 10229672    创建
 **************************************************************************/

VOID BspSlaveBoardHwReset(UINT32 index)
{
    UINT32 ulSocMaxSum = 0;

    ulSocMaxSum = BspGetRpuNum(); /* Dpdic Rpu总数 */
    if(ulSocMaxSum == 0)
    {
        ulSocMaxSum = SOC_HW_SUPPORT_MAX_CHIP_SUM;
    }

    if (1 == BspGetBoardReset()) // ==1代表屏蔽掉复位
    {
        dbgInfo("BspBoardReset: Rest is NOT Allowed!\n");
        return;
    }
    BspLog(LOG_LEVEL_0,"%s reset id=%d\n",__FUNCTION__,index);

    if (pBoardSoftRst != NULL)
    {
        pBoardSoftRst(index);
        return;
    }

    if (index < ulSocMaxSum)
    {
        /* 按照方案要求: BSP提供给APP用于复位DPDIC的接口按照软复位实现,只复位A53核,M0版本、逻辑光口以及已有的VLAN不动*/
        MainCpuResetDpdic("BspSlaveBoardHwReset", SOC_SOFT_RESET_TYPE_EXT, index, SOC_RESET_NUM_ALL);
    }
    else
    {
        dbgInfo("%s>>Error! SocIdx Over; Index= %d\n", __FUNCTION__, index);
    }

    return;
}

static UINT32 BspGetIcRstTypeInfo(UINT32 ulPinSel, UINT32 ulChipIdx, UINT32 *ulIcGpioIdx)
{
    UINT32 ulIcRstTypeLoop = 0;
    INPUT_POINTER_CHECK(ulIcGpioIdx);

    struct tagTIcRstTypeList
    {
        UINT32 pExtRstPinIdx;
        UINT32 pPorRstPinIdx;
    }perIcRstTpyeList[] =
    {
        DPDIC_RST_TYPE_INFO(0),
        DPDIC_RST_TYPE_INFO(1),
        DPDIC_RST_TYPE_INFO(2),
        DPDIC_RST_TYPE_INFO(3),
        DPDIC_RST_TYPE_INFO(4),
    };

    ulIcRstTypeLoop = ulChipIdx - 1;
    if (ulIcRstTypeLoop >= NELEMENTS(perIcRstTpyeList))
    {
        dbgErr("%s>>Error! ChipIdx Over; Idx(0~%d)= %d\n",__FUNCTION__, BspGetRpuNum() - 1, ulChipIdx);
        return BSP_ERROR;
    }

    if (0 == ulPinSel)
    {
        *ulIcGpioIdx = perIcRstTpyeList[ulIcRstTypeLoop].pPorRstPinIdx;
    }
    else
    {
        *ulIcGpioIdx = perIcRstTpyeList[ulIcRstTypeLoop].pExtRstPinIdx;
    }

    dbgInfoEx("%s>> rstPinIdx:%d\r\n",__FUNCTION__,*ulIcGpioIdx);

    return BSP_OK;
}

// ulPinSel 复位类型: 0- POR_RSTn, 1- EXT_RSTn
static UINT32 CpuRstDpdicByGpio(UINT32 ulPinSel, UINT32 ulChipIdx, UINT32 ulCtrlFlag)
{
    UINT32 ulRpuMaxSum = 0;
    UINT32 ulIcGpioIdx = 0;
    UINT32 rpuNum = 0;
    CHAR pcRstTypeStr[16] = "NULL";
    UINT32 retVal = BSP_OK;
    INT32 snpRet = 0;

    /* Dpdic Rpu总数 */
    rpuNum = BspGetRpuNum();
    if(rpuNum == 0)
    {
        ulRpuMaxSum = SOC_HW_SUPPORT_MAX_CHIP_SUM;
    }
    else
    {
        ulRpuMaxSum = min(rpuNum, SOC_HW_SUPPORT_MAX_CHIP_SUM);
    }
    
    if (ulChipIdx >= ulRpuMaxSum)
    {
        dbgErr("%s>>Error! ChipIdx Over; Idx(0~%d)= %d\n",
               __FUNCTION__, ulRpuMaxSum - 1, ulChipIdx);
        return BSP_ERROR;
    }

    if (0 == ulPinSel)
    {
        snpRet = snprintf_s(pcRstTypeStr,sizeof(pcRstTypeStr),"POR_RST");
        SNPRINTF_S_CHECK(snpRet, sizeof(pcRstTypeStr));
    }
    else
    {
        snpRet = snprintf_s(pcRstTypeStr,sizeof(pcRstTypeStr),"EXT_RST");
        SNPRINTF_S_CHECK(snpRet, sizeof(pcRstTypeStr));
    }

    retVal = BspGetIcRstTypeInfo(ulPinSel,ulChipIdx,&ulIcGpioIdx);
    if (retVal != BSP_OK)
    {
        dbgErr("%s>> Get Ic Rst Type Pin Err!\r\n",__FUNCTION__);
        return BSP_ERROR;
    }

    BspRegPinWr(ulIcGpioIdx, !!(ulCtrlFlag));
    dbgInfoEx("%s>>Dpdic'%d PinSel'%d Ctrl'%d RstType: %s!\n", __FUNCTION__,
              ulChipIdx, ulPinSel, ulCtrlFlag, pcRstTypeStr);

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称 : MainCpuResetDpdic(*)
 * 功能描述 : 主控CPU 复位 Dpdic
 * 输入参数 : pcRstStr  - 复位调用函数名
 *            ulRstType - 复位类型,
 *                        0  - Hard(EXT_RSTn/POR_RSTn),
 *                        1  - Soft(EXT_RSTn),
 *                        2  - Por(POR_RSTn),
 *
 *            ulChipIdx - DPDIC 芯片编号
 *            ulCtrlFlag- RstCtrl标志,
 *                        0  - 复位住,    1  - 复位释放;
 *                        255- 复位住等待一会儿后再释放
 * 输出参数 : 无
 * 返 回 值 : BSP_OK- 成功, 其它- 失败
 * 其它说明 : 主控复位Dpdic, BSP上电初始化使用Hard复位, 其它使用Soft;
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 CpuRstDpdicRstType0(UINT32 ulChipIdx, UINT32 ulCtrlFlag)
{
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulFunRet = BSP_OK;

    if (ulChipIdx >= 255)
    {
        return BSP_ERROR;
    }
    
    if (ulCtrlFlag < (UINT32)255)
    {
        ulFunRet |= CpuRstDpdicByGpio(1, ulChipIdx, !(!ulCtrlFlag)); // EXT_RSTn
        if (ulCtrlFlag > (UINT32)0)
        {
            BspSysUsDelay(90);
        }
        ulFunRet |= CpuRstDpdicByGpio(0, ulChipIdx, !(!ulCtrlFlag)); // POR_RSTn
        /*SGMII是否需要恢复待后续确认后完善*/
/*         if ((UINT32)0 == ulCtrlFlag)
        {
            ulTmpRet = SgmiiSetSerdesChnlChkFlag(1, ulChipIdx + 1, 0);
        } */
    }
    else
    {
        ulFunRet |= CpuRstDpdicByGpio(1, ulChipIdx, 0); // EXT_RSTn
        ulFunRet |= CpuRstDpdicByGpio(0, ulChipIdx, 0); // POR_RSTn

        /*SGMII是否需要恢复待后续确认后完善*/
        /* ulTmpRet = SgmiiSetSerdesChnlChkFlag(1, ulChipIdx + 1, 0);*/
        BspSysUsDelay(110000);                      // 延迟110ms,
    
        ulFunRet |= CpuRstDpdicByGpio(1, ulChipIdx, 1); // EXT_RSTn
        BspSysUsDelay(90);                         // 延迟 90us,
        ulFunRet |= CpuRstDpdicByGpio(0, ulChipIdx, 1); // POR_RSTn 和PHY_RST_N 绑定
    }

    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>Sgmii'%d LinkPartner Reset Error!\n", __FUNCTION__, ulChipIdx + 2);
    }
    return ulFunRet;
}

UINT32 CpuRstDpdicRstType1(UINT32 ulChipIdx, UINT32 ulCtrlFlag)
{
    UINT32 ulFunRet = BSP_OK;

    if (ulCtrlFlag < (UINT32)255)
    {
        ulFunRet |= CpuRstDpdicByGpio(1, ulChipIdx, !(!ulCtrlFlag));
    }
    else
    {
        ulFunRet |= CpuRstDpdicByGpio(1, ulChipIdx, 0);
        BspSysUsDelay(110000); /* 延迟110ms, 可根据需要修改 */
    
        ulFunRet |= CpuRstDpdicByGpio(1, ulChipIdx, 1);
    }

    return ulFunRet;
}

UINT32 CpuRstDpdicRstType2(UINT32 ulChipIdx, UINT32 ulCtrlFlag)
{
    UINT32 ulTmpRet = BSP_OK;
    UINT32 ulFunRet = BSP_OK;

    if (ulChipIdx >= 255)
    {
        return BSP_ERROR;
    }

    if (ulCtrlFlag < (UINT32)255)
    {
        ulFunRet |= CpuRstDpdicByGpio(0, ulChipIdx, !(!ulCtrlFlag));

        /*SGMII是否需要恢复待后续确认后完善*/
        /* if ((UINT32)0 == ulCtrlFlag)
        {
            ulTmpRet = SgmiiSetSerdesChnlChkFlag(1, ulChipIdx + 1, 0);
        } */
    }
    else
    {
        ulFunRet |= CpuRstDpdicByGpio(0, ulChipIdx, 0);

        /*SGMII是否需要恢复待后续确认后完善*/
        /* ulTmpRet = SgmiiSetSerdesChnlChkFlag(1, ulChipIdx + 1, 0); */
        BspSysUsDelay(110000); /* 延迟110ms, 可根据需要修改 */
    
        ulFunRet |= CpuRstDpdicByGpio(0, ulChipIdx, 1);
    }

    if (BSP_OK != ulTmpRet)
    {
        dbgErr("%s>>Sgmii'%d LinkPartner Reset Error!\n", __FUNCTION__, ulChipIdx + 2);
    }
    return ulFunRet;
}

UINT32 MainCpuResetDpdic(const CHAR *pcRstStr, UINT32 ulRstType, UINT32 ulChipIdx, UINT32 ulCtrlFlag)
{
    UINT32 ulFunRet = BSP_OK;

    if ((UINT32)0 == ulRstType)
    {// 0- POR_RSTn/EXT_RSTn
        ulFunRet = CpuRstDpdicRstType0(ulChipIdx, ulCtrlFlag);
    }
    else if ((UINT32)1 == ulRstType)
    {// 1- EXT_RSTn
        ulFunRet = CpuRstDpdicRstType1(ulChipIdx, ulCtrlFlag);
    }
    else if ((UINT32)2 == ulRstType)
    {// 0- POR_RSTn
        ulFunRet = CpuRstDpdicRstType2(ulChipIdx, ulCtrlFlag);
    }
    else
    {
        ulFunRet = CpuRstDpdicRstType0(ulChipIdx, ulCtrlFlag);
    }

    if ((CHAR *)NULL != pcRstStr)
    {
        BspLog(LOG_LEVEL_0, "[%s-> %s]>>Chip'%d: Rst= Type'%d Flag'%d\n",
                  pcRstStr, __FUNCTION__, ulChipIdx, ulRstType, ulCtrlFlag);

        dbgInfoEx("%s>>Chip'%d RstType'%d Ctrl'%d: %s Reset!\n", __FUNCTION__,
                  ulChipIdx, ulRstType, ulCtrlFlag, pcRstStr);
    }
    else
    {
        dbgInfoEx("%s>>Chip'%d RstType'%d Ctrl'%d: Dpdic Reset!\n", __FUNCTION__,
                  ulChipIdx, ulRstType, ulCtrlFlag);
    }

    return ulFunRet;
}

/**************************************************************************
 * 函数名称: BspDpdicResetCtrl
 * 功能描述: 复位DPDIC
 * 输入参数: ulChipNo - 芯片编号, 芯片编号大于总数, 选择所有的芯片
             ulRstType- 复位类型
 *           ulRstCtrl- 0:复位住, 1:复位释放
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2021年02月03日 00283311    创建
 **************************************************************************/
UINT32 BspDpdicResetCtrl(UINT32 ulChipNo, UINT32 ulRstType, UINT32 ulRstCtrl)
{
    UINT32 ulSocRstFlag = 0;
    UINT32 ulSocChipIdx = 0;
    UINT32 ulSocChipMin = 0;
    UINT32 ulSocChipMax = 0;
    UINT32 ulSocChipSum = 0;
    UINT32 ulFunRet = BSP_OK;

    ulSocRstFlag = (0 == ulRstCtrl) ? 0 : 1;
    ulSocChipSum = BspGetRpuNum(); /* Dpdic Rpu总数 */

    if (ulChipNo < ulSocChipSum)
    {
        ulSocChipMin = ulChipNo;
        ulSocChipMax = ulChipNo + 1;
    }
    else
    {
        ulSocChipMin = 0;
        ulSocChipMax = ulSocChipSum;
    }

    for (ulSocChipIdx = ulSocChipMin; ulSocChipIdx < ulSocChipMax; ulSocChipIdx++)
    {
        ulFunRet |= MainCpuResetDpdic("BspInitDpdicRstCtrl", ulRstType, ulSocChipIdx, ulSocRstFlag);
    }

    dbgInfo("%s>>DpdicSum'%d: RstCtrl(0:Stop 1:Rls)= %d\n",
            __FUNCTION__, ulSocChipSum, ulRstCtrl);

    return ulFunRet;
}

/**************************************************************************
 * 函数名称: BspDpdicResetRelease
 * 功能描述: 复位住等待一会儿后再释放
 * 输入参数: ulRstType- 复位类型
 *           ulChipIdx - 芯片编号, 芯片编号大于总数, 选择所有的芯片
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2021年02月03日 00283311    创建
 **************************************************************************/
UINT32 BspDpdicResetRelease(UINT32 ulRstType, UINT32 ulChipIdx)
{
    UINT32 ulSocMaxSum  = 0;
    UINT32 ulSocChipCnt = 0;
    UINT32 ulSocChipMin = 0;
    UINT32 ulSocChipMax = 0;
    UINT32 ulFunRet = BSP_OK;

    ulSocMaxSum = BspGetRpuNum(); /* Dpdic Rpu总数 */
    if (ulChipIdx < ulSocMaxSum)
    {
        ulSocChipMin = ulChipIdx;
        ulSocChipMax = ulChipIdx + 1;
    }
    else
    {
        ulSocChipMin = 0;
        ulSocChipMax = ulSocMaxSum;
    }

    for (ulSocChipCnt = ulSocChipMin; ulSocChipCnt < ulSocChipMax; ulSocChipCnt++)
    {
        ulFunRet |= MainCpuResetDpdic("BspDpdicResetRelease", ulRstType, ulSocChipCnt, 255);
    }

    dbgInfoEx("%s>>ChipIdx'(%d~%d) Reset!\n", __FUNCTION__,
              ulSocChipMin, ulSocChipMax - 1);
    return ulFunRet;
}

UINT32 RruLinkPwrOffEnable()
{
    BspRruLinkPwrOffEnable(0x5A5A);
    return BspRruLinkPwrOffRruCfgChk();
}

/*****************************************************************************
*  函数名称   : BspProtectPwrDown_OneChip
*  功能描述   :单片场景 kill dsp进程和MGR进程
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :
*  其它说明   : 无
*  工装使用申明: 无
*----------------------------------------------------------------------------
*/
UINT32 BspProtectPwrDown_OneChip(VOID)
{
    char  buffer[20] = {0,};

    /*BspWatchDogDisable();*/ /*去使能看门狗*/

    (void)snprintf_s(buffer, sizeof(buffer), "pkill DSP.EXE");
    BspSystem(buffer);/*杀DSP进程*/

    (void)snprintf_s(buffer, sizeof(buffer), "pkill MGR.EXE");
    BspSystem(buffer);/*杀MGR进程*/

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspProtectPwrDown_M
*  功能描述   :主从架构主片 kill dsp进程和MGR进程
*  读全局变量 : 暂未实现
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   :
*  其它说明   : 无
*  工装使用申明: 无
*----------------------------------------------------------------------------
*/
UINT32 BspProtectPwrDown_M(VOID)
{
    char  buffer[20] = {0,};
    /*BspWatchDogDisable()*/;/*去使能看门狗*/

    (void)snprintf_s(buffer, sizeof(buffer), "pkill DSP.EXE");
    BspSystem(buffer);/*杀DSP进程*/

    (void)snprintf_s(buffer, sizeof(buffer), "pkill MGR.EXE");
    BspSystem(buffer);/*杀MGR进程*/

    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BspProtectPwrDownMainChip
*  功能描述   :主片IC处理
*  读全局变量 :
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :
*  其它说明   : 。
*  工装使用申明: 无
*----------------------------------------------------------------------------
*/
UINT32 BspProtectPwrDownMainChip(VOID)
{
    UINT32 uiBoardType = 0;
    uiBoardType = BspGetBoardType();
    dbgInfo("%s,%d: uiBoardType:%d \n",__FUNCTION__, __LINE__,uiBoardType);
	switch(uiBoardType)
    {
        case E_BOARD_ONE_CHIP_TYPE:
        {
            BspProtectPwrDown_OneChip();
            break;
        }
        case E_BOARD_MS_M_TYPE:
        {
            BspProtectPwrDown_M();
            break;
        }
        default:
        {
            dbgInfoEx("%s  error! \n",__FUNCTION__);
            break;
        }
    }

    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspProtectPwrDownFromChip
*  功能描述   :从片IC处理
*  读全局变量 :
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :
*  其它说明   :
*  工装使用申明: 无
*----------------------------------------------------------------------------
*/
UINT32 BspProtectPwrDownFromChip(UINT32 chipId)
{
	/*从片拉死功能，各个机型可能连的GPIO管脚不同，需要从单板侧回调*/ 
    UINT32 retVal = BSP_OK;
    UINT32 chipRet = 0;
    UINT32 socChipId = 0;

    if((chipId >= BspGetRpuNum()) || (0 == chipId))  
    {
        dbgErr("%s chipId[%d] error!\n", __FUNCTION__, chipId);
        return BSP_ERROR;        
    }

    chipRet = BspGetDpdicLoadChipNo(chipId, &socChipId);
    if (chipRet != BSP_OK)
    {
        socChipId = chipId;
    }

    /*拉从片的GPIO管脚*/
    dbgInfo("%s>> soc chipid:%d\r\n", __FUNCTION__, socChipId);
    retVal = BspDpdicResetCtrl(socChipId, SOC_POWERON_RESET_TYPE_POR, RESET_CTRL_RESET_STOP);
    dbgInfo("%s>> retval:%d\r\n", __FUNCTION__, retVal);

    return retVal;
}
/*****************************************************************************
*  函数名称   : BspProtectPwrDown
*  功能描述   :单片场景 kill dsp进程和MGR进程
*  读全局变量 : 无从片直接拉复位，不用kill进程。
*  写全局变量 : 无
*  输入参数   : 0 主片IC或单主IC，1其它从片IC，2其它IC
*  输出参数   : 无
*  返 回 值   :
*  其它说明   : 此接口APP只能在主片主控进程调用，其它从片不能使用。
*  工装使用申明: 无
*----------------------------------------------------------------------------
*/
UINT32 BspProtectPwrDown(UINT32 chipId)
{

    if(RRU_PB_BBU == BspGetPbOrBbuMode())
    {
        switch(chipId)
        {
            case 0:
            {
            	BspProtectPwrDownMainChip();
                break;
            }
            default:
            {
            	BspProtectPwrDownFromChip(chipId);
                dbgInfo("%s plat radio no support! \n",__FUNCTION__);
                break;
            }
        }
        
    }else{

        dbgInfo("%s,%d: BBU_CONNECTION_RRU \n",__FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
	
    return BSP_OK;
}

UINT32 RruLinkPwrOffInit()
{
    UINT32 retVal = 0;
    unsigned long virAddr = 0;
    UINT32 ramOffset = 290*SIZE_1K; /* 34K+256K */
    UINT32 ramSize = 16;
    virAddr = BspGetReservedMemAddr(BSP_HIGH_RESERVED_MEM_BSP);
    if ((UINT32)BSP_ERROR == virAddr)
    {
    	BspLog(LOG_LEVEL_0,"%s get reserve mem addr error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    retVal = BspRruLinkPwrOffInit();
    if (BSP_OK == retVal)
    {
        retVal = BspRruLinkBreakTimeInit(virAddr+ramOffset,ramSize);
        BspLog(LOG_LEVEL_0,"%s pwr init ok,break time init %d\n",__FUNCTION__,retVal);
    }
    return retVal;
}

VOID testboardsocreset(UINT32 chipId)
{
    CHAR boardSocId[24] = {0};
    (VOID)snprintf_s(boardSocId,sizeof(boardSocId),"BoardSoc%d", chipId);
    BspResetDevice((OSS_ULONG)boardSocId, 0, 9);
}

UINT32 BspDpdicSlaveSocSoftReset(UINT32 rstCtrl)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipRet = 0;
    T_DpdicSocReset *pPara = NULL;
    UINT32 num = 0;
    UINT32 chip = 0;
    UINT32 socChipId = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_SOC_LOAD,0,0,pPara,num);
    for(chip=0; chip<BspGetRpuNum(); chip++)
    {
        chipRet = BspGetDpdicLoadChipNo(chip, &socChipId);
        if (chipRet != BSP_OK)
        {
            socChipId = chip;
        }

        if(BIT_VAL(pPara->chipMask, socChipId))
        {
            dbgInfo("%s>> soc chipid:%d\r\n",__func__,socChipId);
            retVal |= BspDpdicResetCtrl(socChipId, SOC_SOFT_RESET_TYPE_EXT, rstCtrl);
            dbgInfo("%s>> retval:%d\r\n",__func__,retVal);
        }
    }

    return retVal;
}

UINT32 BspDpdicSlaveSocSoftReLoad(UINT32 chipId)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipRet = 0;
    T_DpdicSocLoad *pPara = NULL;
    UINT32 num = 0;
    UINT32 ulChipLoop  = 0;
    UINT32 ulSocMaxSum = 2;
    UINT32 socChipId = 0;

    BOARD_MODLE_GET_DATA(E_CHIP_POWERON_DPDIC_SOC_LOAD,0,0,pPara,num);
    ulSocMaxSum = BspGetRpuNum(); /* Dpdic(RPU) 总数 */
    dbgInfo("%s>>RpuNum Get OK! SocSum= %d\n", __FUNCTION__, ulSocMaxSum);

    retVal = BspDpdIcXmodemInfoInit(&(pPara->xmodemInfo));

    if (chipId != SOC_RESET_NUM_ALL)
    {
        retVal |= BspDpdicResetRelease(SOC_SOFT_RESET_TYPE_EXT, chipId);
        BspLog(LOG_LEVEL_0,"%s: soft reset soc [chipId=%d]\r\n",__func__,chipId);
        return retVal;
    }
    for (ulChipLoop = 0; ulChipLoop < ulSocMaxSum; ulChipLoop++)
    {
        chipRet = BspGetDpdicLoadChipNo(ulChipLoop, &socChipId);
        if (chipRet != BSP_OK)
        {
            socChipId = ulChipLoop;
        }
        
        BspSysMsDelay_Sys(15000);

        if(BIT_VAL(pPara->chipMask, socChipId))
        {
            dbgInfo("%s>> soc chipid:%d\r\n",__func__,socChipId);
            retVal |= BspDpdicResetRelease(SOC_SOFT_RESET_TYPE_EXT, socChipId);
        }
    }
    return retVal;
}

/*等待所有从片都起来之后，启动复位任务*/
static UINT32 s_socResetMonitorStartFlag = 0;
VOID BspSetCpuResetMonitorStartFlag(UINT32 flag)
{
    s_socResetMonitorStartFlag = flag;
}
UINT32 BspGetCpuResetMonitorStartFlag(VOID)
{
    return s_socResetMonitorStartFlag;
}

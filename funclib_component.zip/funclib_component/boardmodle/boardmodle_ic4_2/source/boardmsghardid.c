/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardudphardid.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "rruinfo.h"
#include "exprn.h"
#include "bspcomm.h"
#include "boardhardid.h"
#include "boardsocmsg.h"


/**************************************************************************
*                            全局变量定义                                       *
**************************************************************************/
UINT32 ulModuleGroupId = 0xffff;
UINT32 ulBoardGroupId  = 0xffff;
UINT32 ulBoardTypeId   = 0xffff;
UINT32 ulHardChangeId  = 0xffff;
UINT32 ulCustomId_A    = 0xffff;/*用户自定义id A*/
UINT32 ulCustomId_B    = 0xffff;/*用户自定义id B*/
UINT32 ulMagicNum      = 0xffff;
UINT32 ulHardWareCrc   = 0xffff;

/**************************************************************************
*                                宏定义                                      *
**************************************************************************/
#define BspGetBomIdParaFromMaster_MAXNUM 3 //3或5

/**************************************************************************
*                                接口定义                                     *
**************************************************************************/
/*****************************************************************************
*  函数名称   : BspSetModuleGroupIdPara
*  功能描述   : 设置模组ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   : A96XX_M
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000001(N/A), 张林刚@2019-05-06 08:33:43, 新建
*----------------------------------------------------------------------------
*/
UINT32 BspSetModuleGroupIdPara(UINT32 ulId)
{
    ulModuleGroupId = ulId;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetBoardGroupIdPara
*  功能描述   : 设置单板组ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspSetBoardGroupIdPara(UINT32 ulId)
{
    ulBoardGroupId = ulId;
    return BSP_OK;
}


/*****************************************************************************
*  函数名称   : BspSetBoardTypeIdPara
*  功能描述   : 设置单板类型
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspSetBoardTypeIdPara(UINT32 ulId)
{
    ulBoardTypeId = ulId;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetHardwareChangeIdPara
*  功能描述   : 设置硬件变更ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspSetHardwareChangeIdPara(UINT32 ulId)
{
    ulHardChangeId = ulId;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetHardwareCustomIdPara_A
*  功能描述   : 设置用户自定义ID_A
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增用户自定义id
*----------------------------------------------------------------------------
*/
UINT32 BspSetHardwareCustomIdPara_A(UINT32 ulId)
{
    ulCustomId_A = ulId;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetHardwareCustomIdPara_B
*  功能描述   : 设置用户自定义ID_B
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增用户自定义id
*----------------------------------------------------------------------------
*/
UINT32 BspSetHardwareCustomIdPara_B(UINT32 ulId)
{
    ulCustomId_B = ulId;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetHardwareMagicNumPara
*  功能描述   : 设置硬件MagicNum,用于标注是否做crc校验
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增
*----------------------------------------------------------------------------
*/
UINT32 BspSetHardwareMagicNumPara(UINT32 ulId)
{
    ulMagicNum = ulId;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetBoardBomidCrcDataPara
*  功能描述   : 设置硬件bomid crc信息
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增
*----------------------------------------------------------------------------
*/
UINT32 BspSetBoardBomidCrcDataPara(UINT32 ulId)
{
    ulHardWareCrc = ulId;
    return BSP_OK;
}

/* Started by AICoder, pid:m0694g323cr4e581463a08f0f04100202610318a */
/*****************************************************************************
*  函数名称   : BspSetProtocolTypeDataPara
*  功能描述   : 设置硬件ProtocolType信息
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增
*----------------------------------------------------------------------------
*/
UINT32 BspSetProtocolTypeDataPara(UINT32 mode)
{
    BspSetPbOrBbuMode(mode);
    dbgInfo("[%s]%d,ProtocolType:0x%04X\n",__FUNCTION__,__LINE__,mode);
    BspLog(LOG_LEVEL_0, "[%s]: ProtocolType:0x%04X\n",__FUNCTION__,mode);

    return BSP_OK;
}
/* Ended by AICoder, pid:m0694g323cr4e581463a08f0f04100202610318a */

#ifdef USE_SOCMSG_BOMID
/*****************************************************************************
*  函数名称   : BspGetModuleGroupIdPara
*  功能描述   : 获取模组ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   : A96XX_M
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspGetModuleGroupIdPara( VOID )
{
    UINT32 moduleGroupId = 0xFFFF;
    moduleGroupId = ulModuleGroupId;
    return moduleGroupId;
}

/*****************************************************************************
*  函数名称   : BspGetBoardGroupIdPara
*  功能描述   : 获取单板组ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspGetBoardGroupIdPara( VOID )
{
    UINT32 boardGroupId = 0xFFFF;
    boardGroupId = ulBoardGroupId;
    return boardGroupId;
}

/*****************************************************************************
*  函数名称   : BspGetBoardTypeIdPara
*  功能描述   : 获取单板类型
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspGetBoardTypeIdPara( VOID )
{
    UINT32 boardTypeId = 0xFFFF;
    boardTypeId = ulBoardTypeId;
    return boardTypeId;
}

/*****************************************************************************
*  函数名称   : BspGetHardwareChangeIdPara
*  功能描述   : 获取硬件变更ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspGetHardwareChangeIdPara(VOID)
{
    UINT32 hwChangeId = 0xFFFF;
    hwChangeId = ulHardChangeId;
    return hwChangeId;
}
/*****************************************************************************
*  函数名称   : BspGetHardwareCustomIdPara_A
*  功能描述   : 获取用户自定义ID_A
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增用户自定义id
*----------------------------------------------------------------------------
*/
UINT32 BspGetHardwareCustomIdPara_A(VOID)
{
    UINT32 CustomId = 0xFFFF;
    CustomId = ulCustomId_A;
    return CustomId;
}
/*****************************************************************************
*  函数名称   : BspGetHardwareCustomIdPara_B
*  功能描述   : 获取用户自定义ID_B
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增用户自定义id
*----------------------------------------------------------------------------
*/
UINT32 BspGetHardwareCustomIdPara_B(VOID)
{
    UINT32 CustomId = 0xFFFF;
    CustomId = ulCustomId_B;
    return CustomId;
}
/*****************************************************************************
*  函数名称   : BspGetHardwareMagicNumPara
*  功能描述   : 获取硬件MagicNum,用于标注是否做crc校验
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增
*----------------------------------------------------------------------------
*/
UINT32 BspGetHardwareMagicNumPara(VOID)
{
    UINT32 magicNum = 0xFFFF;
    magicNum = ulMagicNum;
    return magicNum;
}
/*****************************************************************************
*  函数名称   : BspGetBoardBomidCrcDataPara
*  功能描述   : 获取硬件bomid crc信息
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增
*----------------------------------------------------------------------------
*/
UINT32 BspGetBoardBomidCrcDataPara(VOID)
{
    UINT32 HwCrc = 0xFFFF;
    HwCrc = ulHardWareCrc;
    return HwCrc;
}
#endif
/*****************************************************************************
*  函数名称   : BspGetBomIdParaFromMaster
*  功能描述   : 获取硬件ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
UINT32 BspGetBomIdParaFromMaster(VOID)
{
    UINT8  ucSlaverId = 2;
    UINT8  ucMasterId = 100;
    UINT32 ulRet = 0;
    UINT32 chipId = 0;

    T_UdpMsgQueryIdAck tUdpMsgQueryIdAck = {0};

#if 0  /* 王涛修改，待和钟用确认 todo */
    BspGetIcChipId(&chipId, &dieId); /* BspGetRpuId() + 2 */
#else
    chipId = BspGetRpuId();
#endif
    ucSlaverId = chipId + 2;

    ulRet = SocMsgQueryId(HEAD_TYPE_ID_NXP_SOC, ucSlaverId, ucMasterId,0,0,(UINT8 *)&tUdpMsgQueryIdAck,sizeof(T_UdpMsgQueryIdAck));
    if((BSP_OK == ulRet)&&(BSP_OK == tUdpMsgQueryIdAck.state))
    {

        BspSetModuleGroupIdPara(ntohl(tUdpMsgQueryIdAck.ModuleGroupId));
        BspSetBoardGroupIdPara(ntohl(tUdpMsgQueryIdAck.BoardGroupId));
        BspSetBoardTypeIdPara(ntohl(tUdpMsgQueryIdAck.BoardTypeId));
        BspSetHardwareChangeIdPara(ntohl(tUdpMsgQueryIdAck.HardwareChangeId));
        BspSetHardwareCustomIdPara_A(ntohl(tUdpMsgQueryIdAck.HwCustomIdA));
        BspSetHardwareCustomIdPara_B(ntohl(tUdpMsgQueryIdAck.HwCustomIdB));
        BspSetHardwareMagicNumPara(ntohl(tUdpMsgQueryIdAck.HwMagicNum));
        BspSetBoardBomidCrcDataPara(ntohl(tUdpMsgQueryIdAck.BrdBomidCrc));
        BspSetProtocolTypeDataPara(ntohl(tUdpMsgQueryIdAck.ProtocolType));

        dbgInfoEx("[%s]%d,ModuleGroupId:0x%04X,BoardGroupId:0x%04X\n",__FUNCTION__,__LINE__,ntohl(tUdpMsgQueryIdAck.ModuleGroupId),ntohl(tUdpMsgQueryIdAck.BoardGroupId));
        dbgInfoEx("[%s]%d,BoardTypeId:0x%04X,HardwareChangeId:0x%04X\n",__FUNCTION__,__LINE__,ntohl(tUdpMsgQueryIdAck.BoardTypeId),ntohl(tUdpMsgQueryIdAck.HardwareChangeId));
        dbgInfoEx("[%s]%d,HwCustomIdA:0x%04X,HwCustomIdB:0x%04X\n",__FUNCTION__,__LINE__,ntohl(tUdpMsgQueryIdAck.HwCustomIdA),ntohl(tUdpMsgQueryIdAck.HwCustomIdB));
        dbgInfoEx("[%s]%d,HwMagicNum:0x%04X,BrdBomidCrc:0x%04X\n",__FUNCTION__,__LINE__,ntohl(tUdpMsgQueryIdAck.HwMagicNum),ntohl(tUdpMsgQueryIdAck.BrdBomidCrc));
        dbgInfoEx("[%s]%d,ProtocolType:0x%04X\n",__FUNCTION__,__LINE__,ntohl(tUdpMsgQueryIdAck.ProtocolType));

    }
    else
    {
        dbgErr("%s ulRet=%d state=%d\n",__FUNCTION__,ulRet,tUdpMsgQueryIdAck.state);
        BspSetModuleGroupIdPara(0x190); //a9651a BomId获取失败问题修改
        BspSetBoardGroupIdPara(0);
        BspSetBoardTypeIdPara(0);
        BspSetHardwareChangeIdPara(0);
        BspSetHardwareMagicNumPara(0);
        BspSetBoardBomidCrcDataPara(0xffff);
    }
    return ulRet;
}

/*****************************************************************************
*  函数名称   : BspGetBomIdParaFromMaster
*  功能描述   : 获取硬件ID
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 崔文会@2011-01-19 08:33:43, 拷贝并平台规范化
*  $0000001(N/A), 姜建奎@2012-08-20 08:33:43, 移植到r15trx
*----------------------------------------------------------------------------
*/
VOID BspGetBomIdBySocMsg(VOID)
{
    UINT32 cnt = 0;

    for (cnt = 0; cnt < BspGetBomIdParaFromMaster_MAXNUM; cnt++)
    {
        if ((BSP_OK == BspGetBomIdParaFromMaster()) && (0xffff != BspGetBoardBomidCrcDataPara()))
        {
          dbgInfo("%s>> BspGetBomIdParaFromMaster is OK!\n",__FUNCTION__);
          BspLog(LOG_LEVEL_0, "[%s]: BspGetBomIdParaFromMaster is OK!\n",__FUNCTION__);
          break;
        }
        BspSysMsDelay(3000);
    }
    if (cnt >= BspGetBomIdParaFromMaster_MAXNUM)
    {
        dbgErr("%s>> BspGetBomIdParaFromMaster fails. Proceed to reboot!\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0, "[%s]: BspGetBomIdParaFromMaster fails. Proceed to reboot!\n",__FUNCTION__);
        //BspSystem("reboot"); /* todo 暂时屏蔽掉，后期稳定后打开 */
    }
	
	return; 
}

#ifdef USE_SOCMSG_BOMID
/*****************************************************************************
*  函数名称   : BspInitAdpBdHwIdInfoPara
*  功能描述   : 从片获取硬件bomid信息
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 硬件信息
*  其它说明   : 适用于没有Flash，需要通过UPD消息从主片获取Bomid的从片
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张林刚@2021-02-23 08:33:43, nr4.0新增
*----------------------------------------------------------------------------
*/
UINT32 BspInitAdpBdHwIdInfoPara(VOID)
{
    UINT32 retVal = BSP_OK;
    TVerGroup tHwIdInfo = {0, };
	
    tHwIdInfo.HardId[MOD_GROUP_ID]    = BspGetModuleGroupIdPara();
    tHwIdInfo.HardId[BRD_GROUP_ID]    = BspGetBoardGroupIdPara();
    tHwIdInfo.HardId[BRD_TYPE_ID]     = BspGetBoardTypeIdPara();
    tHwIdInfo.HardId[HW_CHANGE_ID]    = BspGetHardwareChangeIdPara();
    tHwIdInfo.HardId[HW_CUSTOM_ID_A]  = BspGetHardwareCustomIdPara_A();
    tHwIdInfo.HardId[HW_CUSTOM_ID_B]  = BspGetHardwareCustomIdPara_B();
    tHwIdInfo.HardId[BOMID_MAGIC_NUM] = BspGetHardwareMagicNumPara();
    tHwIdInfo.HardId[BOMID_CRC_DATA]  = BspGetBoardBomidCrcDataPara();
	
    retVal = BspSetHwId_16(&tHwIdInfo);
    return retVal;
}
#endif



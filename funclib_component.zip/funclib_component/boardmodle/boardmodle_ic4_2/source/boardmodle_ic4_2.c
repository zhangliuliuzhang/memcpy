/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardmodle_ic4_2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了IC4_2系列单板的例化数据实现
* 注意事项 : 无
* 作    者 :   王涛10248577
* 创建日期 : 2022-03-23
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2022-03-23
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "boardmodle_ic4_2.h"
#include "boardmodleactinjector.h"
#include "boardmodlecommon.h"
#include "boardcorefunc.h"
#include "digtrxlinkwrapper.h"
#include "functionwrapper.h"
#include "hardfeaturewrapper.h"
#include "softservicewrapper.h"
#include "chippoweronwrapper.h"
#include "regaccess.h"
#include "vxadp.h"
#include "funccommon_pm.h"
#include "rruinfo.h"
#include "j204_ic4_2.h"
#if defined(CFR_REFACTOR)
#include "cfr_dpdic.h"
#else
#include "cfr_ic4_2.h"
#endif
#include "devdrv_eeprom.h"
#include "boardreset.h"
#include "regdrv_pincfg.h"
#include "boardwatchdog.h"
#include "devdrv_tempsensor.h"
#include "devdrv_pwr.h"
#include "devdrv_adc.h"
#include "devdrv_uartplc.h"
#include "boardsocmsg.h"
#include "devbus_spibus.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "boardvga.h"
#include "optadpt.h"
#include "boardverprotect.h"
#include "boardversionload.h"
#include "boarddtxpwrsave.h"
#include "pwr_a.h"
#include "j204_dbg.h"
#include "pwr_a.h"
#include "functionwrapper.h"
#include "bspcommonstdlog.h"
#include "powerctrl_ic4_2.h"

/**************************************************************************
                               宏定义
**************************************************************************/



/**************************************************************************
                               结构体类型定义
**************************************************************************/

/**************************************************************************
                               全局变量定义
**************************************************************************/

/* --------------------------------------------------------------------- */
/* ----------------------- IC4.2单板基础动作定义  ---------------------- */
/* --------------------------------------------------------------------- */
static T_BoardActFuncTbl s_BoardActFuncTbl_ic4_2_base[] =
{
    /*  动作类型                                        动作接口                        初始化标志      */
//系统软件服务
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SIGNAL,            BspCoreSignalInit,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_EXT_PRN,           BspCoreInitExPrn,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_BSP_LOG,           BspCoreBspLogInit,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_KDA_LIB,           kdaLibInit,                     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_PM_INIT,           PmInit,                         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_DBOOT_INIT,        BspInitDbootPara,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_UDPMSGMODULE_INIT, UdpMsgModuleInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_WATCHDOG_INIT,     BspWatchDogInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_UART_INIT,         BspUartInit,                    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_FLASHFILE_INIT,    BspLoadFlashInfoToMem,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INNER_NET_CFG,     BspInnerNetCfg,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_CORE_AFFINITY_CFG, BspCoreProcAffinityInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_RECORD_HASH_VER,   BspRecordHashVer,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INNER_NET_L2SS,    BspInnerNetL2ssInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_RRU_FORM,     BspInitRruFormPara,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_EFUSE_WRITE,  BspInitEfuseWriteFunc,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_EFUSE_READ,   BspInitEfuseReadFunc,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_GPIO_READ,    BspInitGpioRdFunc,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_SEC_CALLBACK, BspCfgSecVerifyCallBack,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_SEC_VERIFY,   BspCfgSecVerifyFun,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_INIT_STAT_CALLBACK,BspCoreInitStatCallBackInit,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_BOOT_HEADFILE_RECORD,BspRecordBootVerFileInfoInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_OPEN_KENEL_SWITCH, BspOpenKenelSwitch,             BSP_INIT_NOT_RECORD)
//单板硬件特性，连接关系
    BOARD_ACTION_DEF(E_HARD_FEATURE_BOARD_ID,          BspCoreInitVerGroupPara,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_DEV_ID,            BspCoreInitDeviceIdList,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_THRESHOLD_ID,      BspCoreInitThresholdIdList,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_FUNC_ID,           BspCoreInitFuncIdList,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_GAIN_ID,           BspCoreInitGainIdList,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_GET_BOMID,         BspGetFlashBomid,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_GET_LGC_TYPE,      BspGetBoardIdFirst,             BSP_INIT_NOT_RECORD)
    /* BOARD_ACTION_DEF(E_HARD_FEATURE_INIT_RRU_TYPE,     BspInitRruType,                 BSP_INIT_NOT_RECORD) */
    BOARD_ACTION_DEF(E_HARD_FEATURE_LINK_INFO_INIT,    BspBoardLinkInfoInit,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_FWD_LINK_INFO_INIT,BspBoardFwdLinkInfoInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRU_PROPERTY,      BspRruPropertyInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRU_PROPERTY_PARA, BspUpdateRruPropertyInfo,       BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_FLASH_INIT,        BspFlashInit,                   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CALI_FILE_GET,     BspTftpRfTblGetInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CALI_FILE,         BspRfTblInit,                   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CALI_GAIN_MODIFY,  BspRfTblGainModify,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_REGISTER_CALLBACK, BspSetHardFeatureCallback,      BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_DPDIC_REG_TBL,     DpdIcHalRegTblInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_IIC_BUS,           BspInitI2c,                     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_SPI_BUS,           BspInitSpi,                     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_REG_TBL,           BspRegTblInit,                  BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_DRV_TBL,           BspDrvTblInit,                  BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_DRV_PIN_INIT,      BspRegDrvPinInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_SOC_DIFF_INIT,     BspPreInitSocHwCfg,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRUFILE_INIT,      BspInitRruFileInfo,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRUFILE_BOMIDCHECK,BspInitRruFileInfoBomidCheck,   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRUFILE_CALC,      intfBspRruInfoCalc,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_UART_SEL_INIT,     BspUartCfgDataInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_NSBT_MAP_INIT,     BspNsbtMapInit,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_SET_SOC_BOMID,     BspSetSocMsgBomidInfo,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_FPGA_DEV_LINK,     BspFpgaDevLinkInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,BspBoardTddIoLinkInfoInit,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_TDDIO_CTRL_INIT,   BspTddIoCtrlInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_INIT_VER_PROTECT,  BspInitVerProtect,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_INIT_PROTECT_FILELIST,  BspInitProtectFileList,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_INIT_SOC_VER,      BspExtractSocVer,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_TDDIO_OEEN_BEFORE, BspSetExceptPaLnaOeEnable,      BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_TDDIO_OEEN_AFTER,  BspSetPaLnaOeEnable,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CPUID_INIT,        BspInitCpuAndCoreId,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_COMMON_THREAD_INIT,BspCommonThreadInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_ANTPOWER_INIT,     BspAntPowerInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_OPT_PAPT_INIT,     BspPaptCfgInfoInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CRM_PAPT_INIT,     BspPaptCrmInfoInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_POWER_ADJUST_DELTA,BspPOwerAdjustDeltaInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PAPT_UPDATA,       BspInitPaptUpdata,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PAPT_INIT,         BspInitPaPtPara,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CHECKPLLLD_CALLBACK,BspCheckPllLdCallBackInit,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_REMOTE_RESET_INIT, BspPowOnOffInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PA_VOLT_INIT,      BspPaDefaultVoltInit,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PWR_MAP_CHAN_INIT, BspSetPwrCfgParaInit,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PWRTEMP_THRESHOLD_INIT,  BspSetPwrTempAlarmThresholdValue,   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_USE_STATIC_DEVID,  BspUseStaticDevIdInit,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_TDDIO_DTX,          BspInitDtxCfg,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_CHAN_RFTBL_PARA,    BspBoardChanRfTblParaInit,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_ANTI_TAMPER_INIT,   BspInitAntiTamper,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PWR_CONFIG_INIT,    BspSetPwrSupplyAbilityParaInit,BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRUTEMP_OFFSET_INIT,BspRruTempOffsetInit,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PWROVERTEMP_DERATING_CFG,BspPwrOverTempDeratingInit,BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_PWRCURRENT_CFG,  BspSetPwrInputCrrentParaInit,      BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_RRUPOWERCONSTRAINT_CFG,BspRruPowerConstraintCfgInit,BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_NSBT_CTRL_DELAY_OPTIMIZA,BspNsbtCtrlDelayOptmimiza,BSP_INIT_NOT_RECORD)

//周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件包含动作
    BOARD_ACTION_DEF(E_CHIP_POWERON_FPGA_LOAD,         LoadFpgaVersion,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_AC_DSP_LOAD,       LoadAcDspVersion,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DSP_LOAD,          LoadDspVersion,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_SLAVE_MGR_LOAD,    LoadSlaveMgrVersion,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_MAIN_M0_LOAD,      BspMainM0LoadVersion,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_SLAVE_M0_LOAD,     BspSlaveM0LoadVersion,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_SLAVE_BIN_LOAD,    LoadSlaveBinVersion,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_PAD,         BspInitGpioPad,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_EEPROM,            BspInitEepromDev,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_PWR_EEPROM_PAGE_SET, BspCfgInfoAfterPowerInit,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_RFPLL_INIT,        BspInitRfPllInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_TRANSCEIVER_PRE_INIT,         BspPreInitRfTransceiver,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_TRANSCEIVER_INIT,             BspRfTransceiverInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_TRANSCEIVER_POST_INIT,        BspPostInitRfTransceiver,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT,        BspTrxJ204SerdesTxEqInit,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_ATT_INIT,                     BspInitDattVgaPara,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_ACATT_INIT,                   BspInitAcAttSwitchPara,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA,       BspCbSwCommonParaInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,       BspCbSwStaTblParaInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA,        BspCbSwRfTblParaInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA,   BspCbSwRfTblParaInit_Fpga,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_BOARDRESET_CALLBACK,          BspResetDeviceInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_CLK_DEV,           InitClkDev,                     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DAC_CALLBACK,      BspDacInterfaceParaInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_PA_DAC,            BspDacDevInit,                  BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_RF_ADC,            BspInitRfRxAdc,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_PWR_DEV,           BspInitPwrRpdc,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_UARTPLC_DEV,       BspInitUartPlc,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_EN_PWR_OT,         BspSetPwrOtEnable,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_TEMPSENSOR_DEV,    BspInitTempSensor,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,         BspDpdicCrmInit_BeforeClk,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,          BspDpdicCrmInit_After_M,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_SOC_RESET,    BspDpdicSlaveSocReset,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_SOC_RELEASE,  BspDpdicSlaveSocRelease,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_SOC_LOAD,     BspDpdicSlaveSocLoad,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_FILE_MOVE,          BspFileMoveInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_PWRSAVE_PRE,  BspDpdicPwrSavePreInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_PWRSAVE,      BspDpdicPwrSaveInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_PWRSAVE_POST, BspDpdicPwrSavePostInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_RFTBL_FILE_MOVE,    BspRfTblFileMoveInit,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_CPRI_MODE_SWITCH_FUNC_INIT,BspCpriModeSwitchFuncInit,BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_CPRI_MODE_SWITCH_PARA_INIT,BspCpriModeSwitchParaInit,BSP_INIT_NOT_RECORD)
    /*漏水检测后处理需求暂时屏蔽，后续方案评估在放开*/
    /*BOARD_ACTION_DEF(E_CHIP_POWERON_RRU_WATERLEAK_PROCESS_POST, BspRruWaterLeakPostProcess,         BSP_INIT_NOT_RECORD)*/
    BOARD_ACTION_DEF(E_CHIP_POWERON_BOARD_CFG_FILE_MOVE,   BspBoardCfgFileMoveInit,      BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_UPDATE_PADACSET_PARA,  BspUpdatePaDacSetParaInit,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_MODIFY_PA_VOLT,        BspModifyDefaultPaVolt,       BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_UPDATE_QCELL_PADACSET_PARA,  BspUpdateQcellPaDacSetParaInit,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_INIT_BOARDTYPE,        BspInitBoardType,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_SWITCH_SPARE_LANE, BspSwitchSpareLaneInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_DPDIC_DYN_VOLT_CFG,  BspDpdicDynVoltParaInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_PMB_SCALE_INFO,     BspPmbScaleInfoInit,             BSP_INIT_NOT_RECORD)

//数字TX/RX/FB 3大链路
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_TX_SERDES,   BspNtlTxInit,                   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_RX_SERDES,   BspNtlRxInit,                   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,   BspDpdicOptCpriParaInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_CPRI_INIT,   BspDpdicOptCpriInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_MEAS,        BspDpdicOptMeasParaInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_HAL_INIT,    BspDpdicOptCfgParaInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_CELL_INIT,   BspDpdicOptCellInit,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_CLK,         BspDpdIcDifClkParaInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_SAMRATE,     BspDpdIcDifSamRateParaInit,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_CFG,         BspDpdIcDifInitParaInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_RESALLOC,    BspDpdIcDifResAllocParaInit,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_TX_ROUTE,    BspDpdicTxRouteMapInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_TX_PARA,     BspDpdicTxRouteParaInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_TX_204,      BspDpdicTxJ204RouteMapInit,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_RX_ROUTE,    BspDpdicRxRouteMapInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_FB_ROUTE,    BspDpdicFbRouteMapInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_HAL_INIT,    BspDpdicDifHalInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_FR,          BspDpdicDifFrameHeaderInit,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_LINK,        BspJ204LinkInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_SYSREF,      BspJ204SysrefInit,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_TXEQ,        BspJ204SerdesTxEqInit,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_INIT_STEP,   BspJ204LinkInitStep,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_PRE_STEP,    BspJ204LinkPreStep,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_POST_STEP,   BspJ204LinkPostStep,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_DIF_CFG_TDD,     BspDpdicDifTddCfg,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_BOOTP_INIT,  BspOptBootpInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_INNER_SERDES_CFG, BspBoardInnerCpriSpeedCfg,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_INNER_SERDES_MONITOR,BspInnerSerdesRxMonitor,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,BspJ204TrxCallBackInit,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_ADAPT_INFO_INIT,_BspOptAdptInfoInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_ADAPT_THREAD_INIT,_BspOptAdptThreadInit,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_SWITCHOVER_THREAD_INIT,BspChkOptSwitchOverThreadInit,BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_TXPRIORITY_THREAD_INIT,BspCfgTxPriorityThreadInit,BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_IC_TRX_LINK_MAP, BspJ204LinkMapInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_204_RECORD_STATE, BspRecord204LinkStatus,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_J204_CHECK_RETRY,       BspJ204LinkCheckAndRetry,       BSP_INIT_NOT_RECORD)
#ifndef MULT_PROGRESS_S
    BOARD_ACTION_DEF(E_TRX_LINK_SFP_CFG_PARA,           BspSfpCfpParaInit,       BSP_INIT_NOT_RECORD)
#endif

//业务功能
    BOARD_ACTION_DEF(E_FUNCTION_PRE_ALLOC,             BspOptPreAllocInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_TX_FREQ_CFG,           BspTxFreqCfgInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RX_FREQ_CFG,           BspRxFreqCfgInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_TX_RF_DELAY,           BspTxRfDlyInit,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RX_RF_DELAY,           BspRxRfDlyInit,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_TX_DELT_DELAY,         BspInitTxDeltDly,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RX_DELT_DELAY,         BspInitRxDeltDly,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_FDD_DELAY,             BspInitFddDlyPara,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_FDD_TOFFSET,           BspInitFddToffset,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_FDD_FIXLINK,           BspInitFddFixLink,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_CHIP_TRANDLY,          BspInitChipTranDlyPara,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RRU_DEFABILITY,        BspInitRruDefAbility_M,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_DL_POWCALC_PARA_INIT,  BspInitDlPowCalcPara,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_UL_POWCALC_PARA_INIT,  BspInitUlPowCalcPara,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_UL_POWERCADJ_PARA_INIT,BspPowerAdjParaInit,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_POWCALC_INIT,          BspInitPowCalcPara,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,BspInitPowCalcThresholdPara,BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_TEMP_THRESHOLD_PARA_INIT,BspInitTempThresholdPara,     BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_POWCALC_THREAD_INIT,   BspInitPowCalcThread,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_VECTORVSWR_INIT,       BspDpdVswrParaInit,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_CFR_PARA_INIT,         BspInitCfrPara,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_CFR_FUNC_INIT,         BspInitCfrFunc,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_DPD_FUNC_INIT,         BspInitDpdFunc,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_TRX_DIG_GAIN_INIT,     TrxDigGainInit,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_VGA_BUS_INIT,          BspVgaBusInit,                  BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RF_VGA_INIT,           BspRfVgaInit,                   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_VGA_CFG_INIT,          BspVgaCfgInit,                  BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_VGA_CTRL_MGC_CMD_INIT, BspMgcCmdInfoInit,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_VGA_FPGACTRL_INIT,     BspVgaInfoInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_STOP_AGC_CTRL_INIT,    BspStopAgcCtrl,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_VGA_LIKE_SPI_PARA_INIT,BspVgaLikeSpiParaInit,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_OPENLOOP_PARA_INIT,    BspInitOpenLoopPara,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_CHAN_GROUP_INIT,       BspChanGroupInit,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_CHANGRP_TO_TDDIDX_INIT,BspChnGrpToTddIdxInit,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_HARD_FEATURE_REMOTE_RESET_INIT, BspPowOnOffInit,                BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_CHANFREQ_BAND_INIT,    BspChnFreqBandInfoInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RXSCAN_INIT,           BspInitRxScanInit,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_LINKPWROFF_ENABLE,     RruLinkPwrOffEnable,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_LINKPWROFF_INIT,       RruLinkPwrOffInit,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RRU_CARR_ABILITY,      BspInitRruCarrAbility,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_PAPT_REPORT_RECOVER,   BspPaptReportRecoverInit,       BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_DTX_ABILITY_SUPPORT,   BspDtxAbilitySupport,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_DTX_PARA_INIT,         BspDtxParaInit,                 BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RRU_ULDELAY_CMPABILITY,BspInitRruUlDelayCmpAbility,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_PA_PWRVOLT_INIT,       BspInitPaPwrVoltCtrl,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_REV_PROTECT_INIT,      BspRevPowProtectInit,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_VINDOWN_EFFECTIVE_INIT,BspDetectVindownIsEffective,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_LNAOFF_PARA_INIT,      BspInitLnaOffPara,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_DSP_CALC_POW_PARA,     BspInitDpdPowCalcThread,        BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_NTF_PARA_INIT,         BspNtfCfgInit,                  BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_ICPSYNC_INTERRUPT_INIT,BspPsyncInterruptInit,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_USE_CHAN_DEFAULT_CENTERFREQ_FLAG, BspChanCenterFreqFlagInit, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_DPD_SET_EQ_INIT,       BspDpdSetEqCaliParam,           BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RRU_ABILITY_FLAG,      BspSetRruSpecialFlagInit,       BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_RRU_CARR_CAP,          BspSetRruCarrRangeCapInit,      BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_DFL_OUT_RANG_ALM_FLAG, BspDflOutRangAlmFlagInit,       BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_SFP_SELF_HEAL_FLAG,    BspSfpSelfHealFlagInit,         BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SERIAL_LOG_PRINT_INIT, BspSerialLogToFlashInit,    BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SAVE_BAK_LOG_TO_FLASH, BspSaveBakLog,              BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH, BspGetCurLogForMasterTask,  BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH, BspSaveKmsgLog,            BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SAVE_BAK_LOG_TO_FLASH_SLAVE, BspSaveBakLogSlave,   BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH_SLAVE, BspGetCurLogForMasterTaskSlave, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH_SLAVE, BspSaveKmsgLogSlave, BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_POW_THROD_CFG,         BspInitPowThrodCfg,             BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_FUNCTION_CHIP_DPS_UART_INIT,         BspSetAisgDigPhaseShiftInfoInit,             BSP_INIT_NOT_RECORD)
};

/* ========================================================================================================= */
/* ============================= 单片版本 ================================================================== */
/* ========================================================================================================= */

/* --------------------------------------------------------------------- */
/* ----------------------- one-chip动作差异定义  ----------------------- */
/* --------------------------------------------------------------------- */
static T_BoardActFuncTbl s_BoardActFuncTbl_ic4_2_onechip[] =
{
    /*  动作类型                                        动作接口                        初始化标志      */
};



/* --------------------------------------------------------------------- */
/* -------------------------- 预初始化流程定义  ------------------------ */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardPreInitFlow_ic4_2_onechip[] =
{
    { E_SOFT_SERVICE_EXT_PRN,           "BspCoreInitExPrn"},
    { E_CHIP_POWERON_BOARD_CFG_FILE_MOVE, "BspBoardCfgFileMoveInit"},
    { E_SOFT_SERVICE_INIT_STAT_CALLBACK,"BspBoardInitStatCallBackInit"},
    { E_SOFT_SERVICE_SIGNAL,            "BspCoreSignalInit"},
    { E_SOFT_SERVICE_BSP_LOG,           "BspCoreBspLogInit"},
    { E_HARD_FEATURE_FLASH_INIT,        "BspFlashInit"},
    { E_FUNCTION_LINKPWROFF_ENABLE,     "RruLinkPwrOffEnable"},
#ifndef PLAT_X86_TEST
    { E_SOFT_SERVICE_DBOOT_INIT,        "BspInitDbootPara"},
    { E_SOFT_SERVICE_KDA_LIB,           "kdaLibInit"},
    { E_SOFT_SERVICE_FLASHFILE_INIT,    "BspLoadFlashInfoToMem"},
#endif
    { E_HARD_FEATURE_INIT_VER_PROTECT, "BspInitVerProtect"},
    { E_SOFT_SERVICE_PM_INIT,           "BspCorePmInit"},
    { E_HARD_FEATURE_DPDIC_REG_TBL,     "DpdIcHalRegTblInit"},
    { E_CHIP_POWERON_BOARDRESET_CALLBACK ,"BspResetDeviceInit"},
    { E_SOFT_SERVICE_WATCHDOG_INIT,     "BspWatchDogInit"},
    { E_HARD_FEATURE_DEV_ID,            "BspCoreInitDeviceIdList"},
    { E_HARD_FEATURE_THRESHOLD_ID,      "BspCoreInitThresholdIdList"},
    { E_HARD_FEATURE_FUNC_ID,           "BspCoreInitFuncIdList"},
    { E_HARD_FEATURE_GAIN_ID,           "BspCoreInitGainIdList"},
    { E_HARD_FEATURE_REGISTER_CALLBACK, "BspSetHardFeatureCallback"},
    { E_HARD_FEATURE_GET_BOMID,         "BspGetFlashBomid" },
    { E_HARD_FEATURE_BOARD_ID,          "BspCoreInitVerGroupPara"},    /*BspCoreInitVerGroupPara需要放在BspInitRruFileInfo之前，后者要使用s_VerGroup*/
    { E_HARD_FEATURE_GET_LGC_TYPE,      "BspGetBoardIdFirst"},         /*需要区分boardid的动作，必须放在本动作后 */
    { E_SOFT_SERVICE_UART_INIT,         "BspUartInit"},
    { E_HARD_FEATURE_RRU_PROPERTY,      "BspRruPropertyInit"},         /*BspRruPropertyInit需要放在BspInitRruFileInfo之前，rruinfo解析要使用rruproperty中的通道数,BspGetTxChannel*/
    { E_HARD_FEATURE_RRU_PROPERTY_PARA, "BspUpdateRruPropertyInfo"},
    { E_HARD_FEATURE_RRUFILE_INIT,      "BspInitRruFileInfo"},
    { E_HARD_FEATURE_RRUFILE_BOMIDCHECK,"BspInitRruFileInfoBomidCheck"},
    { E_HARD_FEATURE_INIT_PROTECT_FILELIST, "BspInitProtectFileList"},
    { E_HARD_FEATURE_LINK_INFO_INIT,    "BspBoardLinkInfoInit"},
    { E_HARD_FEATURE_FWD_LINK_INFO_INIT,"BspBoardFwdLinkInfoInit"},
    { E_FUNCTION_RRU_DEFABILITY,        "BspInitRruDefAbility_M"},
#ifndef PLAT_X86_TEST
    { E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,  "BspDpdicCrmInit_BeforeClk"},
    { E_CHIP_POWERON_DPDIC_PAD,         "BspInitGpioPad"},
    { E_HARD_FEATURE_REG_TBL,           "BspRegTblInit"},
    { E_HARD_FEATURE_DRV_TBL,           "BspDrvTblInit"},
    { E_HARD_FEATURE_FPGA_DEV_LINK,     "BspFpgaDevLinkInit"},
    { E_HARD_FEATURE_DRV_PIN_INIT,      "BspRegDrvPinInit"},
    { E_HARD_FEATURE_IIC_BUS,           "BspInitI2c"},
    { E_HARD_FEATURE_SPI_BUS,           "BspInitSpi"},
    { E_SOFT_SERVICE_SERIAL_LOG_PRINT_INIT, "BspSerialLogToFlashInit"},
    { E_SOFT_SERVICE_SAVE_BAK_LOG_TO_FLASH, "BspSaveBakLog"},
    { E_SOFT_SERVICE_INNER_NET_L2SS,    "BspInnerNetL2ssInit"},
    { E_SOFT_SERVICE_INNER_NET_CFG,     "BspInnerNetCfg"},
    { E_SOFT_SERVICE_CORE_AFFINITY_CFG, "BspCoreProcAffinityInit"}, /* 需要保证所有启线程的动作都在此动作之后，否则无法继承绑定0核 */
    { E_SOFT_SERVICE_UDPMSGMODULE_INIT, "UdpMsgModuleInit"},
#endif
    {E_CHIP_POWERON_RFTBL_FILE_MOVE,    "BspRfTblFileMoveInit"},  //要放在宏：E_CHIP_POWERON_FILE_MOVE之前
    {E_CHIP_POWERON_FILE_MOVE,          "BspFileMoveInit"},       //要放在宏：E_CHIP_POWERON_RFTBL_FILE_MOVE之后
    { E_HARD_FEATURE_CALI_FILE,         "BspRfTblInit"},
    {E_CHIP_POWERON_UPDATE_PADACSET_PARA, "BspUpdatePaDacSetParaInit"},
    {E_CHIP_POWERON_UPDATE_QCELL_PADACSET_PARA, "BspUpdateQcellPaDacSetParaInit"},
    {E_CHIP_POWERON_MODIFY_PA_VOLT,     "BspModifyDefaultPaVolt"},
    {E_HARD_FEATURE_CHAN_RFTBL_PARA,    "BspBoardChanRfTblParaInit"},
    { E_HARD_FEATURE_RRUFILE_CALC,      "intfBspRruInfoCalc"},
    { E_FUNCTION_CHANFREQ_BAND_INIT,    "BspChnFreqBandInfoInit"},
    { E_FUNCTION_CHAN_GROUP_INIT,       "BspChanGroupInit" },
    { E_FUNCTION_CHANGRP_TO_TDDIDX_INIT,"BspChnGrpToTddIdxInit" },
    { E_SOFT_SERVICE_INIT_RRU_FORM,     "BspInitRruFormPara" },
    { E_FUNCTION_RXSCAN_INIT,       "BspInitRxScanInit" },
    { E_SOFT_SERVICE_INIT_EFUSE_WRITE,  "BspInitEfuseWriteFunc" },
    { E_SOFT_SERVICE_INIT_EFUSE_READ,   "BspInitEfuseReadFunc" },
    { E_SOFT_SERVICE_INIT_GPIO_READ,    "BspInitGpioRdFunc" },
    { E_SOFT_SERVICE_INIT_SEC_CALLBACK, "BspCfgSecVerifyCallBack" },
    { E_SOFT_SERVICE_INIT_SEC_VERIFY,   "BspCfgSecVerifyFun" },
    { E_HARD_FEATURE_ANTI_TAMPER_INIT,  "BspInitAntiTamper"},
    { E_HARD_FEATURE_NSBT_CTRL_DELAY_OPTIMIZA, "BspNsbtCtrlDelayOptmimiza"},
};

/* --------------------------------------------------------------------- */
/* --------------------------- 初始化流程定义 -------------------------- */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardInitFlow_ic4_2_onechip[] =
{
#ifndef PLAT_X86_TEST
    { E_CHIP_POWERON_CLK_DEV,            "InitClkDev"},
#endif
    { E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,  "BspDpdicCrmInit_After_M"},
    { E_CHIP_POWERON_DPDIC_PWRSAVE,        "BspDpdicPwrSaveInit"},  /* 关闭DPDIC内部不使用的资源，节电 */
#ifndef PLAT_X86_TEST
    { E_SOFT_SERVICE_RECORD_HASH_VER,     "BspRecordHashVer"},
    {E_CHIP_POWERON_FPGA_LOAD,            "LoadFpgaVersion"},
    { E_CHIP_POWERON_EEPROM,              "BspInitEepromDev"},
    {E_CHIP_POWERON_MAIN_M0_LOAD,         "BspMainM0LoadVersion"},
    { E_CHIP_POWERON_SLAVE_M0_LOAD,       "BsSlaveM0LoadVersion"},
    { E_CHIP_POWERON_PWR_EEPROM_PAGE_SET, "BspCfgInfoAfterPowerInit"},
    { E_HARD_FEATURE_PWR_MAP_CHAN_INIT,   "BspSetPwrCfgParaInit"},
    { E_CHIP_POWERON_PWR_DEV,            "BspInitPwrRpdc"},
    /*{ E_CHIP_POWERON_RRU_WATERLEAK_PROCESS_POST, "BspRruWaterLeakPostProcess"},   在E_CHIP_POWERON_PWR_DEV之后 */
    { E_CHIP_POWERON_TEMPSENSOR_DEV,     "BspInitTempSensor"},
#endif
    { E_CHIP_POWERON_AC_DSP_LOAD,        "LoadAcDspVersion"},   /* AC DSP版本加载 */
    { E_CHIP_POWERON_DSP_LOAD,           "LoadDspVersion"},     /* DPD DSP版本加载 */
    { E_CHIP_POWERON_RFPLL_INIT,         "BspInitRfPllInit"},
    { E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,"BspBoardTddIoLinkInfoInit"},
    { E_HARD_FEATURE_TDDIO_CTRL_INIT,    "BspTddIoCtrlInit"},
    { E_HARD_FEATURE_TDDIO_OEEN_BEFORE,  "BspSetExceptPaLnaOeEnable"},
    { E_CHIP_POWERON_TRANSCEIVER_PRE_INIT,    "BspPreInitRfTransceiver"},

    { E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,"BspJ204TrxCallBackInit"},
    { E_TRX_LINK_DPDIC_204_LINK,         "BspJ204LinkInit"},
    { E_TRX_LINK_DPDIC_204_IC_TRX_LINK_MAP,"BspJ204LinkMapInit"},
    { E_TRX_LINK_DPDIC_204_SYSREF,       "BspJ204SysrefInit"},
    { E_TRX_LINK_DPDIC_204_TXEQ,         "BspJ204SerdesTxEqInit"},
    { E_TRX_LINK_DPDIC_204_INIT_STEP,    "BspJ204LinkInitStep"},

    { E_TRX_LINK_DPDIC_204_PRE_STEP,     "BspJ204LinkPreStep"},

#ifndef PLAT_X86_TEST
    { E_CHIP_POWERON_TRANSCEIVER_INIT,    "BspRfTransceiverInit"},
#endif
    { E_CHIP_POWERON_TRANSCEIVER_POST_INIT,   "BspPostInitRfTransceiver"},
    { E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT,   "BspTrxJ204SerdesTxEqInit"},
    { E_TRX_LINK_DPDIC_204_POST_STEP,    "BspJ204LinkPostStep"},  /* 需要放置在Transceiver初始化之后 */
    { E_TRX_LINK_J204_CHECK_RETRY,       "BspJ204LinkCheckAndRetry"},
    { E_CHIP_POWERON_ATT_INIT,           "BspInitDattVgaPara"},
    { E_CHIP_POWERON_ACATT_INIT,          "BspInitAcAttSwitchPara"},
    { E_FUNCTION_PRE_ALLOC,              "BspOptPreAllocInit"},
#ifndef PLAT_X86_TEST
    { E_TRX_LINK_DPDIC_OPT_TX_SERDES,    "BspNtlTxInit"},
#endif
    { E_TRX_LINK_DPDIC_OPT_CPRI_PARA,    "BspDpdicOptCpriParaInit"},
    { E_TRX_LINK_DPDIC_OPT_CPRI_INIT,    "BspDpdicOptCpriInit"},
    { E_TRX_LINK_DPDIC_OPT_MEAS,         "BspDpdicOptMeasParaInit"},
    { E_TRX_LINK_DPDIC_OPT_HAL_INIT,     "BspDpdicOptCfgParaInit"},
    { E_TRX_LINK_DPDIC_OPT_CELL_INIT,    "BspDpdicOptCellInit"},
    { E_TRX_LINK_DPDIC_DIF_CLK,          "BspDpdIcDifClkParaInit"},
    { E_TRX_LINK_DPDIC_DIF_SAMRATE,      "BspDpdIcDifSamRateParaInit"},
    { E_TRX_LINK_DPDIC_DIF_RESALLOC,     "BspDpdIcDifResAllocParaInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_ROUTE,     "BspDpdicTxRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_PARA,      "BspDpdicTxRouteParaInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_204,       "BspDpdicTxJ204RouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_RX_ROUTE,     "BspDpdicRxRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_FB_ROUTE,     "BspDpdicFbRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_HAL_INIT,     "BspDpdicDifHalInit"},
    { E_TRX_LINK_DPDIC_DIF_CFG,          "BspDpdIcDifInitParaInit"},
    { E_TRX_LINK_DPDIC_DIF_CFG_TDD,      "BspDpdicDifTddCfg"},
    { E_TRX_LINK_DPDIC_DIF_FR,           "BspDpdicDifFrameHeaderInit"},
    { E_CHIP_POWERON_DAC_CALLBACK,       "BspDacInterfaceParaInit"},
    { E_CHIP_POWERON_PA_DAC,             "BspDacDevInit"},
    { E_CHIP_POWERON_RF_ADC,             "BspInitRfRxAdc"},
    { E_FUNCTION_TX_FREQ_CFG,            "BspTxFreqCfgInit"},
    { E_FUNCTION_RX_FREQ_CFG,            "BspRxFreqCfgInit"},
    { E_FUNCTION_TX_RF_DELAY,            "BspTxRfDlyInit"},
    { E_FUNCTION_RX_RF_DELAY,            "BspRxRfDlyInit"},
    { E_FUNCTION_TX_DELT_DELAY,          "BspInitTxDeltDly"},
    { E_FUNCTION_RX_DELT_DELAY,          "BspInitRxDeltDly"},
    { E_FUNCTION_FDD_DELAY,              "BspInitFddDlyPara"},/*只有FDD机型走此流程，TDD机型参数不需要配置*/
    /* { E_FUNCTION_CHIP_TRANDLY,           "BspInitChipTranDlyPara"}, *//*单片不需要*/
    { E_FUNCTION_DL_POWCALC_PARA_INIT,   "BspInitDlPowCalcPara"},
    { E_FUNCTION_UL_POWCALC_PARA_INIT,   "BspInitUlPowCalcPara"},
    { E_FUNCTION_OPENLOOP_PARA_INIT,     "BspInitOpenLoopPara"},
    { E_FUNCTION_POWCALC_INIT,           "BspInitPowCalcPara"},
    { E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,"BspInitPowCalcThresholdPara"},
    { E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA,      "BspCbSwCommonParaInit" },
    { E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,      "BspCbSwStaTblParaInit" },
    { E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA,       "BspCbSwRfTblParaInit" },
    //{ E_CHIP_POWERON_DPDIC_CBSW_PINSW_PARA,       "BspCbSwPinTblParaInit" },
#ifndef PLAT_X86_TEST
    { E_FUNCTION_POWCALC_THREAD_INIT,    "BspInitPowCalcThread"},
    {E_FUNCTION_VECTORVSWR_INIT,         "BspDpdVswrParaInit"},
    { E_TRX_LINK_DPDIC_OPT_RX_SERDES,    "BspNtlRxInit"}, /*此项可能需要调整到初始化最后，实际环境验证决定*/
#endif
    { E_FUNCTION_CFR_PARA_INIT,          "BspInitCfrPara"},
    { E_FUNCTION_CFR_FUNC_INIT,          "BspInitCfrFunc"},
    { E_FUNCTION_DPD_FUNC_INIT,          "BspInitDpdFunc"},
    { E_FUNCTION_TRX_DIG_GAIN_INIT,      "TrxDigGainInit"},
    { E_HARD_FEATURE_CPUID_INIT,         "BspInitCpuAndCoreId"},
    { E_TRX_LINK_DPDIC_OPT_BOOTP_INIT,   "BspOptBootpInit"},
    { E_HARD_FEATURE_REMOTE_RESET_INIT,   "BspPowOnOffInit"},
    { E_FUNCTION_NTF_PARA_INIT,          "BspNtfCfgInit"},
    { E_TRX_LINK_DPDIC_OPT_ADAPT_INFO_INIT,"_BspOptAdptInfoInit"},
    { E_TRX_LINK_DPDIC_OPT_ADAPT_THREAD_INIT,"_BspOptAdptThreadInit"},
    { E_FUNCTION_VGA_LIKE_SPI_PARA_INIT, "BspVgaLikeSpiParaInit"},
    { E_FUNCTION_VGA_BUS_INIT,           "BspVgaBusInit"},
    { E_FUNCTION_RF_VGA_INIT,            "BspRfVgaInit"},
    { E_FUNCTION_VGA_CFG_INIT,           "BspVgaCfgInit"},
    { E_FUNCTION_VGA_CTRL_MGC_CMD_INIT, "BspMgcCmdInfoInit"},
    { E_FUNCTION_STOP_AGC_CTRL_INIT,     "BspStopAgcCtrl"},
#ifndef PLAT_X86_TEST
    { E_HARD_FEATURE_COMMON_THREAD_INIT, "BspCommonThreadInit"},
    { E_FUNCTION_PAPT_REPORT_RECOVER,    "BspPaptReportRecoverInit"},
    { E_HARD_FEATURE_OPT_PAPT_INIT,        "BspPaptCfgInfoInit"},
    { E_HARD_FEATURE_CRM_PAPT_INIT,        "BspPaptCrmInfoInit"},
    { E_HARD_FEATURE_PAPT_UPDATA,        "BspInitPaptUpdata"},
    { E_HARD_FEATURE_PAPT_INIT,          "BspInitPaPtPara"},
    { E_HARD_FEATURE_ANTPOWER_INIT,      "BspAntPowerInit"},
    { E_FUNCTION_PA_PWRVOLT_INIT,        "BspInitPaPwrVoltCtrl"},
    { E_HARD_FEATURE_PA_VOLT_INIT,   "BspPaDefaultVoltInit"},
#endif
#ifdef _BSP_WITH_WFS
        { E_CHIP_POWERON_EN_PWR_OT,   "BspSetPwrOtEnable"},
#endif
    { E_HARD_FEATURE_CHECKPLLLD_CALLBACK, "BspCheckPllLdCallBackInit"},
    { E_FUNCTION_LINKPWROFF_INIT,        "RruLinkPwrOffInit"},
    { E_HARD_FEATURE_PWRTEMP_THRESHOLD_INIT,  "BspSetPwrTempAlarmThresholdValue"},
    { E_FUNCTION_RRU_CARR_ABILITY,      "BspInitRruCarrAbility"},
    { E_FUNCTION_DTX_ABILITY_SUPPORT,   "BspDtxAbilitySupport"},
    {E_FUNCTION_DTX_PARA_INIT,          "BspDtxParaInit"},
    {E_HARD_FEATURE_TDDIO_DTX,          "BspInitDtxCfg"},
    {E_FUNCTION_RRU_ULDELAY_CMPABILITY, "BspInitRruUlDelayCmpAbility"},
#ifndef _BSP_WITH_WFS
    {E_FUNCTION_REV_PROTECT_INIT,      "BspRevPowProtectInit"},
#endif
    { E_TRX_LINK_DPDIC_204_RECORD_STATE, "BspRecord204LinkStatus"},
    { E_FUNCTION_VINDOWN_EFFECTIVE_INIT, "BspDetectVindownIsEffective"},
    { E_CHIP_POWERON_DPDIC_PWRSAVE_POST, "BspDpdicPwrSavePostInit"},  /* 节电后处理 */
    //{ E_HARD_FEATURE_USE_STATIC_DEVID, "BspUseStaticDevIdInit"},
    { E_HARD_FEATURE_TDDIO_OEEN_AFTER,   "BspSetPaLnaOeEnable"},
    { E_TRX_LINK_DPDIC_OPT_SWITCHOVER_THREAD_INIT,"BspChkOptSwitchOverThreadInit"},
    { E_TRX_LINK_DPDIC_OPT_TXPRIORITY_THREAD_INIT,"BspCfgTxPriorityThreadInit"},
    { E_FUNCTION_LNAOFF_PARA_INIT,       "BspInitLnaOffPara"},
    { E_FUNCTION_ICPSYNC_INTERRUPT_INIT, "BspPsyncInterruptInit"},
    { E_FUNCTION_DSP_CALC_POW_PARA,     "BspInitDpdPowCalcThread"},/* DSP功率检测初始化*/
    { E_FUNCTION_USE_CHAN_DEFAULT_CENTERFREQ_FLAG,"BsphnetrFreqFlagInit"},
    { E_HARD_FEATURE_POWER_ADJUST_DELTA, "BspPOwerAdjustDeltaInit"},
    { E_FUNCTION_DPD_SET_EQ_INIT,        "BspDpdSetEqCaliParam"},
    {E_SOFT_SERVICE_BOOT_HEADFILE_RECORD, "BspRecordBootVerFileInfoInit"},
    { E_FUNCTION_DFL_OUT_RANG_ALM_FLAG,  "BspDflOutRangAlmFlagInit"},
    { E_FUNCTION_SFP_SELF_HEAL_FLAG,     "BspSfpSelfHealFlagInit"},
    { E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH, "BspGetCurLogForMasterTask"},
    { E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH, "BspSaveKmsgLog"},
    { E_SOFT_SERVICE_OPEN_KENEL_SWITCH,    "BspOpenKenelSwitch"},    /* 打开内核维测开关 */
    { E_HARD_FEATURE_RRUTEMP_OFFSET_INIT,  "BspRruTempOffsetInit"},
    { E_FUNCTION_POW_THROD_CFG,            "BspInitPowThrodCfg"},
    { E_HARD_FEATURE_RRUPOWERCONSTRAINT_CFG, "BspRruPowerConstraintCfgInit"},
};

/* ========================================================================================================= */
/* ============================ ADS测试版本 ================================================================ */
/* ========================================================================================================= */

/* --------------------------------------------------------------------- */
/* -------------------------- 预初始化流程定义  ------------------------ */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardPreInitFlow_ic4_2_ads[] =
{
    { E_SOFT_SERVICE_EXT_PRN,           "BspCoreInitExPrn"},
    { E_SOFT_SERVICE_INIT_STAT_CALLBACK,"BspBoardInitStatCallBackInit"},
    { E_SOFT_SERVICE_SIGNAL,            "BspCoreSignalInit"},
    { E_SOFT_SERVICE_BSP_LOG,           "BspCoreBspLogInit"},

#ifndef DEBUG_REGACCESS
  //{ E_SOFT_SERVICE_DBOOT_INIT,        "BspInitDbootPara"},
    { E_SOFT_SERVICE_KDA_LIB,           "kdaLibInit"},
#endif
    { E_SOFT_SERVICE_PM_INIT,           "BspCorePmInit"},
    { E_HARD_FEATURE_DPDIC_REG_TBL,     "DpdIcHalRegTblInit"},
    { E_HARD_FEATURE_DEV_ID,            "BspCoreInitDeviceIdList"},
    { E_HARD_FEATURE_THRESHOLD_ID,      "BspCoreInitThresholdIdList"},
    { E_HARD_FEATURE_FUNC_ID,           "BspCoreInitFuncIdList"},
    { E_HARD_FEATURE_GAIN_ID,           "BspCoreInitGainIdList"},
    { E_HARD_FEATURE_REGISTER_CALLBACK, "BspSetHardFeatureCallback"},
    { E_HARD_FEATURE_GET_BOMID,         "BspGetFlashBomid" },
    { E_HARD_FEATURE_BOARD_ID,          "BspCoreInitVerGroupPara"},
    { E_HARD_FEATURE_GET_LGC_TYPE,      "BspGetBoardIdFirst"},         /* 需要区分boardid的动作，必须放在本动作后 */
    /* { E_HARD_FEATURE_INIT_RRU_TYPE,     "BspInitRruType"}, */
    { E_HARD_FEATURE_LINK_INFO_INIT,    "BspBoardLinkInfoInit"},
    { E_HARD_FEATURE_RRU_PROPERTY,      "BspRruPropertyInit"},
    { E_HARD_FEATURE_RRU_PROPERTY_PARA, "BspUpdateRruPropertyInfo"},
    { E_FUNCTION_RRU_DEFABILITY,        "BspInitRruDefAbility_M"},
    { E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,  "BspDpdicCrmInit_BeforeClk"},
    { E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,  "BspDpdicCrmInit_After_M"},

};

/* --------------------------------------------------------------------- */
/* --------------------------- 初始化流程定义 -------------------------- */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardInitFlow_ic4_2_ads[] =
{
    { E_CHIP_POWERON_EEPROM,             "BspInitEepromDev"},
    { E_FUNCTION_PRE_ALLOC,              "BspOptPreAllocInit"},
    /*{ E_TRX_LINK_DPDIC_OPT_TX_SERDES,    "BspNtlTxInit"},*/
    { E_TRX_LINK_DPDIC_OPT_CPRI_PARA,    "BspDpdicOptCpriParaInit"},
    { E_TRX_LINK_DPDIC_OPT_CPRI_INIT,    "BspDpdicOptCpriInit"},
    { E_TRX_LINK_DPDIC_OPT_MEAS,         "BspDpdicOptMeasParaInit"},
    { E_TRX_LINK_DPDIC_OPT_HAL_INIT,     "BspDpdicOptCfgParaInit"},
    { E_TRX_LINK_DPDIC_DIF_CLK,          "BspDpdIcDifClkParaInit"},
    { E_TRX_LINK_DPDIC_DIF_SAMRATE,      "BspDpdIcDifSamRateParaInit"},
    { E_TRX_LINK_DPDIC_DIF_RESALLOC,     "BspDpdIcDifResAllocParaInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_ROUTE,     "BspDpdicTxRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_PARA,      "BspDpdicTxRouteParaInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_204,       "BspDpdicTxJ204RouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_RX_ROUTE,     "BspDpdicRxRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_HAL_INIT,     "BspDpdicDifHalInit"},
    { E_TRX_LINK_DPDIC_DIF_CFG,          "BspDpdIcDifInitParaInit"},
    { E_TRX_LINK_DPDIC_DIF_FR,           "BspDpdicDifFrameHeaderInit"},
    { E_TRX_LINK_DPDIC_204_LINK,         "BspJ204LinkInit"},
    { E_TRX_LINK_DPDIC_204_SYSREF,       "BspJ204SysrefInit"},
    { E_TRX_LINK_DPDIC_204_TXEQ,         "BspJ204SerdesTxEqInit"},
#if 0 /* 筛片版本需要放开 */
    { E_TRX_LINK_DPDIC_204_INIT_STEP,    "BspJ204LinkInitStep"},
    { E_TRX_LINK_DPDIC_204_PRE_STEP,     "BspJ204LinkPreStep"},
    { E_TRX_LINK_DPDIC_204_POST_STEP,    "BspJ204LinkPostStep"},  /* 需要放置在Transceiver初始化之后 */
#endif
    { E_FUNCTION_TX_FREQ_CFG,            "BspTxFreqCfgInit"},
    { E_FUNCTION_RX_FREQ_CFG,            "BspRxFreqCfgInit"},
    { E_FUNCTION_TX_RF_DELAY,            "BspTxRfDlyInit"},
    { E_FUNCTION_RX_RF_DELAY,            "BspRxRfDlyInit"},
    { E_FUNCTION_TX_DELT_DELAY,          "BspInitTxDeltDly"},
    { E_FUNCTION_RX_DELT_DELAY,          "BspInitRxDeltDly"},
    { E_FUNCTION_FDD_DELAY,              "BspInitFddDlyPara"},/*只有FDD机型走此流程，TDD机型参数不需要配置*/
    { E_FUNCTION_DL_POWCALC_PARA_INIT,   "BspInitDlPowCalcPara"},
    { E_FUNCTION_UL_POWCALC_PARA_INIT,   "BspInitUlPowCalcPara"},
    { E_FUNCTION_POWCALC_INIT,           "BspInitPowCalcPara"},
    { E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,"BspInitPowCalcThresholdPara"},
   /* { E_FUNCTION_DPD_FUNC_INIT,          "BspInitDpdFunc"},*/
    //{ E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,"BspBoardTddIoLinkInfoInit"},
    //{ E_HARD_FEATURE_TDDIO_CTRL_INIT,    "BspTddIoCtrlInit"},
    { E_FUNCTION_CFR_PARA_INIT,          "BspInitCfrPara"},
    { E_FUNCTION_CFR_FUNC_INIT,          "BspInitCfrFunc"},
};



/* ========================================================================================================= */
/* =========================  主从结构主版本 =============================================================== */
/* ========================================================================================================= */

/* --------------------------------------------------------------------- */
/* ------------------- 主从结构主版本动作差异部分定义 ------------------ */
/* --------------------------------------------------------------------- */
static T_BoardActFuncTbl s_BoardActFuncTbl_ic4_2_MS_M[] =
{
    /*  动作类型                                        动作接口                        初始化标志      */
        BOARD_ACTION_DEF(E_CHIP_POWERON_BOARDRESET_CALLBACK,         BspResetDeviceInit_M,                     BSP_INIT_NOT_RECORD)
};

/* --------------------------------------------------------------------- */
/* -------------------------- 预初始化流程定义  ------------------------ */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardPreInitFlow_ic4_2_MS_M[] =
{
    { E_SOFT_SERVICE_EXT_PRN,           "BspCoreInitExPrn"},
    { E_SOFT_SERVICE_INIT_STAT_CALLBACK,"BspBoardInitStatCallBackInit"},
    { E_CHIP_POWERON_BOARD_CFG_FILE_MOVE, "BspBoardCfgFileMoveInit"},
    { E_SOFT_SERVICE_SIGNAL,            "BspCoreSignalInit"},
    { E_SOFT_SERVICE_BSP_LOG,           "BspCoreBspLogInit"},
    { E_HARD_FEATURE_FLASH_INIT,        "BspFlashInit"},
    { E_FUNCTION_LINKPWROFF_ENABLE,     "RruLinkPwrOffEnable"},
#ifndef PLAT_X86_TEST
    { E_SOFT_SERVICE_DBOOT_INIT,        "BspInitDbootPara"},
    { E_SOFT_SERVICE_KDA_LIB,           "kdaLibInit"},
    { E_SOFT_SERVICE_FLASHFILE_INIT,    "BspLoadFlashInfoToMem"},
#endif
    { E_HARD_FEATURE_INIT_VER_PROTECT,  "BspInitVerProtect"},
    { E_SOFT_SERVICE_PM_INIT,           "BspCorePmInit"},
    { E_HARD_FEATURE_DPDIC_REG_TBL,     "DpdIcHalRegTblInit"},
    { E_CHIP_POWERON_BOARDRESET_CALLBACK ,"BspResetDeviceInit"},
    { E_HARD_FEATURE_DEV_ID,            "BspCoreInitDeviceIdList"},
    { E_HARD_FEATURE_THRESHOLD_ID,      "BspCoreInitThresholdIdList"},
    { E_HARD_FEATURE_FUNC_ID,           "BspCoreInitFuncIdList"},
    { E_HARD_FEATURE_GAIN_ID,           "BspCoreInitGainIdList"},
    { E_HARD_FEATURE_REGISTER_CALLBACK, "BspSetHardFeatureCallback"},
    { E_HARD_FEATURE_GET_BOMID,         "BspGetFlashBomid" },
    { E_HARD_FEATURE_SET_SOC_BOMID,     "BspSetSocMsgBomidInfo"},
    { E_HARD_FEATURE_BOARD_ID,          "BspCoreInitVerGroupPara"},
    { E_HARD_FEATURE_GET_LGC_TYPE,      "BspGetBoardIdFirst"},         /* 需要区分boardid的动作，必须放在本动作后 */
    { E_HARD_FEATURE_RRU_PROPERTY,      "BspRruPropertyInit"},
    { E_HARD_FEATURE_RRU_PROPERTY_PARA, "BspUpdateRruPropertyInfo"},
    { E_HARD_FEATURE_RRUFILE_INIT,      "BspInitRruFileInfo"},
    { E_HARD_FEATURE_RRUFILE_BOMIDCHECK,"BspInitRruFileInfoBomidCheck"},
    { E_HARD_FEATURE_INIT_PROTECT_FILELIST, "BspInitProtectFileList"},
    {E_CHIP_POWERON_RFTBL_FILE_MOVE,    "BspRfTblFileMoveInit"},  //要放在宏：E_CHIP_POWERON_FILE_MOVE之前
    { E_HARD_FEATURE_CALI_FILE,         "BspRfTblInit"},
    {E_CHIP_POWERON_MODIFY_PA_VOLT,     "BspModifyDefaultPaVolt"},
    { E_HARD_FEATURE_LINK_INFO_INIT,    "BspBoardLinkInfoInit"},
    { E_HARD_FEATURE_FWD_LINK_INFO_INIT,"BspBoardFwdLinkInfoInit"},
    { E_FUNCTION_RRU_DEFABILITY,        "BspInitRruDefAbility_M"},
    { E_HARD_FEATURE_UART_SEL_INIT,      "BspUartCfgDataInit"},  // uart初始化之前拿不到bomId
#ifndef PLAT_X86_TEST
    { E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,  "BspDpdicCrmInit_BeforeClk"},
    { E_CHIP_POWERON_DPDIC_PAD,         "BspInitGpioPad"},/*主片从进程不需要*/
    { E_HARD_FEATURE_REG_TBL,           "BspRegTblInit"},
    { E_HARD_FEATURE_DRV_TBL,           "BspDrvTblInit"},
    { E_HARD_FEATURE_FPGA_DEV_LINK,     "BspFpgaDevLinkInit"},
    { E_HARD_FEATURE_DRV_PIN_INIT,      "BspRegDrvPinInit"},
    { E_HARD_FEATURE_IIC_BUS,           "BspInitI2c"},
    { E_HARD_FEATURE_SPI_BUS,           "BspInitSpi"},
    { E_SOFT_SERVICE_SERIAL_LOG_PRINT_INIT, "BspSerialLogToFlashInit"},
    { E_SOFT_SERVICE_SAVE_BAK_LOG_TO_FLASH, "BspSaveBakLog"},
#endif

    { E_SOFT_SERVICE_WATCHDOG_INIT,     "BspWatchDogInit"},
#ifndef PLAT_X86_TEST
    { E_SOFT_SERVICE_UART_INIT,         "BspUartInit"},
    { E_SOFT_SERVICE_INNER_NET_L2SS,    "BspInnerNetL2ssInit"},
    { E_SOFT_SERVICE_INNER_NET_CFG,     "BspInnerNetCfg" },
    { E_SOFT_SERVICE_CORE_AFFINITY_CFG, "BspCoreProcAffinityInit"}, /* 需要保证所有启线程的动作都在此动作之后，否则无法继承绑定0核 */
    { E_SOFT_SERVICE_UDPMSGMODULE_INIT, "UdpMsgModuleInit"},
#endif
    {E_CHIP_POWERON_FILE_MOVE,          "BspFileMoveInit"},  //要放在宏：E_CHIP_POWERON_RFTBL_FILE_MOVE之后
    { E_HARD_FEATURE_RRUFILE_CALC,      "intfBspRruInfoCalc"},
    { E_FUNCTION_CHANFREQ_BAND_INIT,    "BspChnFreqBandInfoInit"},
    { E_SOFT_SERVICE_INIT_RRU_FORM,     "BspInitRruFormPara" },
    { E_FUNCTION_UL_POWERCADJ_PARA_INIT,"BspPowerAdjParaInit"},
    { E_HARD_FEATURE_NSBT_MAP_INIT,      "BspNsbtMapInit"},
    { E_SOFT_SERVICE_INIT_EFUSE_WRITE,  "BspInitEfuseWriteFunc" },
    { E_SOFT_SERVICE_INIT_EFUSE_READ,   "BspInitEfuseReadFunc" },
    { E_SOFT_SERVICE_INIT_GPIO_READ,    "BspInitGpioRdFunc" },
    { E_SOFT_SERVICE_INIT_SEC_CALLBACK, "BspCfgSecVerifyCallBack" },
    { E_SOFT_SERVICE_INIT_SEC_VERIFY,   "BspCfgSecVerifyFun" },
    { E_HARD_FEATURE_ANTI_TAMPER_INIT,  "BspInitAntiTamper"},
    { E_CHIP_POWERON_CPRI_MODE_SWITCH_FUNC_INIT,   "BspCpriModeSwitchFuncInit" },
    { E_CHIP_POWERON_CPRI_MODE_SWITCH_PARA_INIT,   "BspCpriModeSwitchParaInit" },
    { E_CHIP_POWERON_UPDATE_QCELL_PADACSET_PARA, "BspUpdateQcellPaDacSetParaInit"},
};

/* --------------------------------------------------------------------- */
/* -------------------------- 初始化流程定义  ------------------------ */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardInitFlow_ic4_2_MS_M[] =
{
    {E_CHIP_POWERON_CLK_DEV,                   "InitClkDev"},
    {E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,       "BspDpdicCrmInit_After_M"},
    {E_CHIP_POWERON_DPDIC_PWRSAVE_PRE,         "BspDpdicPwrSavePreInit"},
    {E_SOFT_SERVICE_RECORD_HASH_VER,           "BspRecordHashVer"},
    {E_HARD_FEATURE_INIT_SOC_VER,              "BspExtractSocVer"},
    {E_CHIP_POWERON_FPGA_LOAD,                 "LoadFpgaVersion"},
#ifndef PLAT_X86_TEST
    {E_CHIP_POWERON_EEPROM,                    "BspInitEepromDev"},
    {E_CHIP_POWERON_PWR_EEPROM_PAGE_SET,       "BspCfgInfoAfterPowerInit"},
    {E_CHIP_POWERON_UARTPLC_DEV,               "BspInitUartPlc"},
    {E_CHIP_POWERON_PWR_DEV,                   "BspInitPwrRpdc"},
    {E_HARD_FEATURE_PWR_MAP_CHAN_INIT,         "BspSetPwrCfgParaInit"},
  /*  {E_CHIP_POWERON_RRU_WATERLEAK_PROCESS_POST, "BspRruWaterLeakPostProcess"},   在E_HARD_FEATURE_PWR_MAP_CHAN_INIT之后 */
    {E_CHIP_POWERON_TEMPSENSOR_DEV,            "BspInitTempSensor"},
#endif
    {E_CHIP_POWERON_AC_DSP_LOAD,               "LoadAcDspVersion"}, /*主进程需要加ACDSP*/
    {E_CHIP_POWERON_SLAVE_MGR_LOAD,            "LoadSlaveMgrVersion"},
    {E_CHIP_POWERON_MAIN_M0_LOAD,              "BspMainM0LoadVersion"},
#ifndef PLAT_X86_TEST
    {E_TRX_LINK_DPDIC_OPT_TX_SERDES,           "BspNtlTxInit"},/*主片从进程不需要*/
#endif
    {E_TRX_LINK_SFP_CFG_PARA,                  "BspSfpCfpParaInit"},
    {E_TRX_LINK_DPDIC_OPT_CPRI_PARA,           "BspDpdicOptCpriParaInit"},
    {E_TRX_LINK_DPDIC_OPT_CPRI_INIT,           "BspDpdicOptCpriInit"},/*需要拆解，对接BBU的光口主进程需要，从不需要，和业务相关的从需要主不需要*/
    {E_TRX_LINK_DPDIC_OPT_MEAS,                "BspDpdicOptMeasParaInit"},

    {E_TRX_LINK_DPDIC_OPT_HAL_INIT,            "BspDpdicOptCfgParaInit"},
    {E_TRX_LINK_DPDIC_OPT_INNER_SERDES_CFG,    "BspBoardInnerCpriSpeedCfg"},
    {E_CHIP_POWERON_SWITCH_SPARE_LANE,         "BspSwitchSpareLaneInit"},
#ifndef PLAT_X86_TEST
    {E_TRX_LINK_DPDIC_OPT_RX_SERDES,           "BspNtlRxInit"}, /*此项可能需要调整到初始化最后，实际环境验证决定*//*主片从进程不需要*/
#endif
    {E_TRX_LINK_DPDIC_OPT_INNER_SERDES_MONITOR,"BspInnerSerdesRxMonitor"},
    {E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA,"BspCbSwRfTblParaInit_Fpga"},
    {E_CHIP_POWERON_DPDIC_SOC_RESET,           "BspDpdicSlaveSocReset"},
    {E_CHIP_POWERON_DPDIC_SOC_LOAD,            "BspDpdicSlaveSocLoad"},
    {E_HARD_FEATURE_CPUID_INIT,                "BspInitCpuAndCoreId"},
    {E_TRX_LINK_DPDIC_OPT_BOOTP_INIT,          "BspOptBootpInit"},
    {E_HARD_FEATURE_ANTPOWER_INIT,             "BspAntPowerInit"},
    {E_HARD_FEATURE_PA_VOLT_INIT,              "BspPaDefaultVoltInit"},
#ifdef _BSP_WITH_WFS
    {E_CHIP_POWERON_EN_PWR_OT,                 "BspSetPwrOtEnable"},
#endif
    {E_HARD_FEATURE_CHECKPLLLD_CALLBACK,       "BspCheckPllLdCallBackInit"},
#ifndef PLAT_X86_TEST
    {E_HARD_FEATURE_COMMON_THREAD_INIT,        "BspCommonThreadInit"},
#endif
    {E_HARD_FEATURE_REMOTE_RESET_INIT,         "BspPowOnOffInit"},
    {E_FUNCTION_NTF_PARA_INIT,                 "BspNtfCfgInit"},
    {E_TRX_LINK_DPDIC_OPT_ADAPT_INFO_INIT,     "_BspOptAdptInfoInit"},
    {E_TRX_LINK_DPDIC_OPT_ADAPT_THREAD_INIT,   "_BspOptAdptThreadInit"},
    {E_FUNCTION_LINKPWROFF_INIT,               "RruLinkPwrOffInit"},
    {E_HARD_FEATURE_OPT_PAPT_INIT,             "BspPaptCfgInfoInit"},
    {E_FUNCTION_DTX_ABILITY_SUPPORT,           "BspDtxAbilitySupport"},
    {E_FUNCTION_VINDOWN_EFFECTIVE_INIT,        "BspDetectVindownIsEffective"},
    {E_TRX_LINK_DPDIC_OPT_SWITCHOVER_THREAD_INIT,"BspChkOptSwitchOverThreadInit"},
    {E_TRX_LINK_DPDIC_OPT_TXPRIORITY_THREAD_INIT,"BspCfgTxPriorityThreadInit"},
    {E_HARD_FEATURE_PWR_CONFIG_INIT,            "BspSetPwrSupplyAbilityParaInit"},
    {E_SOFT_SERVICE_BOOT_HEADFILE_RECORD,       "BspRecordBootVerFileInfoInit"},
    {E_FUNCTION_RRU_CARR_CAP,                   "BspSetRruCarrRangeCapInit"},
    {E_FUNCTION_RRU_ABILITY_FLAG,               "BspSetRruSpecialFlagInit"},
    {E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH, "BspGetCurLogForMasterTask"},
    {E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH, "BspSaveKmsgLog"},
    {E_HARD_FEATURE_RRUTEMP_OFFSET_INIT,      "BspRruTempOffsetInit"},
    {E_HARD_FEATURE_PWROVERTEMP_DERATING_CFG, "BspPwrOverTempDeratingInit"},
    {E_SOFT_SERVICE_OPEN_KENEL_SWITCH,    "BspOpenKenelSwitch"},    /* 打开内核维测开关 */
    {E_HARD_FEATURE_PWRCURRENT_CFG,    "BspSetPwrInputCrrentParaInit"},
    {E_HARD_FEATURE_RRUPOWERCONSTRAINT_CFG, "BspRruPowerConstraintCfgInit"},
    {E_FUNCTION_POW_THROD_CFG,            "BspInitPowThrodCfg"},
    {E_HARD_FEATURE_NSBT_CTRL_DELAY_OPTIMIZA,   "BspNsbtCtrlDelayOptmimiza"},
    {E_FUNCTION_FDD_DELAY,              "BspInitFddDlyPara"},/*只有FDD机型走此流程，TDD机型参数不需要配置*/
};

static T_BoardInitFlowTbl s_BoardInitFlow_ic4_2_MS_M_PLUS[] =
{
    {E_CHIP_POWERON_CLK_DEV,                   "InitClkDev"},
    {E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,       "BspDpdicCrmInit_After_M"},
    {E_CHIP_POWERON_DPDIC_PWRSAVE_PRE,         "BspDpdicPwrSavePreInit"},
    {E_SOFT_SERVICE_RECORD_HASH_VER,           "BspRecordHashVer"},
    {E_HARD_FEATURE_INIT_SOC_VER,              "BspExtractSocVer"},
    {E_CHIP_POWERON_FPGA_LOAD,                 "LoadFpgaVersion"},
#ifndef PLAT_X86_TEST
    {E_CHIP_POWERON_EEPROM,                    "BspInitEepromDev"},
    {E_CHIP_POWERON_PWR_EEPROM_PAGE_SET,       "BspCfgInfoAfterPowerInit"},
    {E_CHIP_POWERON_PWR_DEV,                   "BspInitPwrRpdc"},
    { E_HARD_FEATURE_PWR_MAP_CHAN_INIT,        "BspSetPwrCfgParaInit"},
    {E_CHIP_POWERON_TEMPSENSOR_DEV,            "BspInitTempSensor"},
#endif
    {E_CHIP_POWERON_AC_DSP_LOAD,               "LoadAcDspVersion"}, /*主进程需要加ACDSP*/
#ifndef PLAT_X86_TEST
    {E_TRX_LINK_DPDIC_OPT_TX_SERDES,           "BspNtlTxInit"},/*主片从进程不需要*/
#endif
    {E_TRX_LINK_DPDIC_OPT_CPRI_PARA,           "BspDpdicOptCpriParaInit"},
    {E_TRX_LINK_DPDIC_OPT_CPRI_INIT,           "BspDpdicOptCpriInit"},/*需要拆解，对接BBU的光口主进程需要，从不需要，和业务相关的从需要主不需要*/
    {E_TRX_LINK_DPDIC_OPT_MEAS,                "BspDpdicOptMeasParaInit"},
    {E_TRX_LINK_DPDIC_OPT_HAL_INIT,            "BspDpdicOptCfgParaInit"},
    {E_TRX_LINK_DPDIC_OPT_INNER_SERDES_CFG,    "BspBoardInnerCpriSpeedCfg"},
    {E_CHIP_POWERON_DPDIC_SOC_RESET,           "BspDpdicSlaveSocReset"},
    {E_CHIP_POWERON_DPDIC_SOC_LOAD,            "BspDpdicSlaveSocLoad"},

    {E_CHIP_POWERON_SLAVE_MGR_LOAD,            "LoadSlaveMgrVersion"},
    {E_CHIP_POWERON_MAIN_M0_LOAD,              "BspMainM0LoadVersion"},
#ifndef PLAT_X86_TEST
    {E_TRX_LINK_DPDIC_OPT_RX_SERDES,           "BspNtlRxInit"}, /*此项可能需要调整到初始化最后，实际环境验证决定*//*主片从进程不需要*/
#endif
    {E_TRX_LINK_DPDIC_OPT_INNER_SERDES_MONITOR,"BspInnerSerdesRxMonitor"},

    {E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA,"BspCbSwRfTblParaInit_Fpga"},
    {E_HARD_FEATURE_CPUID_INIT,                "BspInitCpuAndCoreId"},
    {E_TRX_LINK_DPDIC_OPT_BOOTP_INIT,          "BspOptBootpInit"},
    {E_HARD_FEATURE_ANTPOWER_INIT,             "BspAntPowerInit"},
    {E_FUNCTION_PA_PWRVOLT_INIT,               "BspInitPaPwrVoltCtrl"},
    {E_HARD_FEATURE_PA_VOLT_INIT,              "BspPaDefaultVoltInit"},
#ifdef _BSP_WITH_WFS
    {E_CHIP_POWERON_EN_PWR_OT,                 "BspSetPwrOtEnable"},
#endif
    {E_HARD_FEATURE_CHECKPLLLD_CALLBACK,       "BspCheckPllLdCallInit"},
#ifndef PLAT_X86_TEST
    {E_HARD_FEATURE_COMMON_THREAD_INIT,        "BspCommonThreadInit"},
#endif
    {E_HARD_FEATURE_REMOTE_RESET_INIT,         "BspPowOnOffInit"},
    {E_FUNCTION_NTF_PARA_INIT,                 "BspNtfCfgInit"},
    {E_TRX_LINK_DPDIC_OPT_ADAPT_INFO_INIT,     "_BspOptAdptInfoInit"},
    {E_TRX_LINK_DPDIC_OPT_ADAPT_THREAD_INIT,   "_BspOptAdptThreadInit"},
    {E_FUNCTION_LINKPWROFF_INIT,               "RruLinkPwrOffInit"},
    {E_HARD_FEATURE_OPT_PAPT_INIT,             "BspPaptCfgInfoInit"},
    {E_FUNCTION_DTX_ABILITY_SUPPORT,           "BspDtxAbilitySupport"},
    {E_FUNCTION_VINDOWN_EFFECTIVE_INIT,        "BspDetectVindownIsEffective"},
    {E_TRX_LINK_DPDIC_OPT_SWITCHOVER_THREAD_INIT,"BspChkOptSwitchOverThreadInit"},
    { E_TRX_LINK_DPDIC_OPT_TXPRIORITY_THREAD_INIT,"BspCfgTxPriorityThreadInit"},
    {E_SOFT_SERVICE_BOOT_HEADFILE_RECORD,       "BspRecordBootVerFileInfoInit"},
    {E_FUNCTION_RRU_ABILITY_FLAG,               "BspSetRruSpecialFlagInit"},
    {E_FUNCTION_TEMP_THRESHOLD_PARA_INIT,       "BspInitTempThresholdPara"},
    {E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH,      "BspGetCurLogForMasterTask"},
    {E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH,     "BspSaveKmsgLog"},
    {E_SOFT_SERVICE_OPEN_KENEL_SWITCH,         "BspOpenKenelSwitch"},    /* 打开内核维测开关 */
    {E_FUNCTION_POW_THROD_CFG,                 "BspInitPowThrodCfg"},
    {E_HARD_FEATURE_NSBT_CTRL_DELAY_OPTIMIZA,   "BspNsbtCtrlDelayOptmimiza"},
    {E_FUNCTION_CHIP_DPS_UART_INIT,   "BspSetAisgDigPhaseShiftInfoInit"},
};

/* ========================================================================================================= */
/* =========================  主从结构从版本 =============================================================== */
/* ========================================================================================================= */

/* --------------------------------------------------------------------- */
/* ------------------- 主从结构从版本动作差异部分定义 ------------------ */
/* --------------------------------------------------------------------- */
static T_BoardActFuncTbl s_BoardActFuncTbl_ic4_2_MS_S[] =
{
//周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件包含动作
    BOARD_ACTION_DEF(E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,          BspDpdicCrmInit_After_S,          BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_CHIP_POWERON_BOARDRESET_CALLBACK,          BspResetDeviceInit_S,             BSP_INIT_NOT_RECORD)
//业务功能
    BOARD_ACTION_DEF(E_FUNCTION_RRU_DEFABILITY,        BspInitRruDefAbility_S,          BSP_INIT_NOT_RECORD)

//单板硬件特性，连接关系
    BOARD_ACTION_DEF(E_HARD_FEATURE_GET_BOMID,         BspGetSocMsgBomid,               BSP_INIT_NOT_RECORD)
    BOARD_ACTION_DEF(E_TRX_LINK_DPDIC_OPT_RX_SERDES,   BspNtlRxInit_S,                  BSP_INIT_NOT_RECORD)
};

/* --------------------------------------------------------------------- */
/* -------------------------- 预初始化流程定义  ------------------------ */
/* --------------------------------------------------------------------- */
static T_BoardInitFlowTbl s_BoardPreInitFlow_ic4_2_MS_S[] =
{
    { E_SOFT_SERVICE_EXT_PRN,           "BspCoreInitExPrn"},
    { E_SOFT_SERVICE_INIT_STAT_CALLBACK,"BspBoardInitStatCallBackInit"},
    { E_CHIP_POWERON_BOARD_CFG_FILE_MOVE, "BspBoardCfgFileMoveInit"},
    { E_SOFT_SERVICE_SIGNAL,            "BspCoreSignalInit"},
    { E_SOFT_SERVICE_BSP_LOG,           "BspCoreBspLogInit"}, /*需要确认主从接口参数是否一致*/
#ifndef PLAT_X86_TEST
    //{ E_SOFT_SERVICE_UART_INIT,         "BspUartInit"},
    { E_SOFT_SERVICE_KDA_LIB,           "kdaLibInit"}, /*需要确认从片是否需要*//*先注释掉，目前用不到*/
#endif
    { E_SOFT_SERVICE_PM_INIT,           "BspCorePmInit"},
    { E_HARD_FEATURE_DPDIC_REG_TBL,     "DpdIcHalRegTblInit"},
    { E_SOFT_SERVICE_SERIAL_LOG_PRINT_INIT, "BspSerialLogToFlashInit"},
    { E_CHIP_POWERON_INIT_BOARDTYPE,    "BspInitBoardType"},
    { E_CHIP_POWERON_BOARDRESET_CALLBACK, "BspResetDeviceInit"},
    { E_HARD_FEATURE_DEV_ID,            "BspCoreInitDeviceIdList"},
    { E_HARD_FEATURE_THRESHOLD_ID,      "BspCoreInitThresholdIdList"},
    { E_HARD_FEATURE_FUNC_ID,           "BspCoreInitFuncIdList"},
    { E_HARD_FEATURE_GAIN_ID,           "BspCoreInitGainIdList"},
    { E_HARD_FEATURE_REGISTER_CALLBACK, "BspSetHardFeatureCallback"},
    { E_SOFT_SERVICE_CORE_AFFINITY_CFG, "BspCoreProcAffinityInit"}, /* 需要保证所有启线程的动作都在此动作之后，否则无法继承绑定0核 */
#ifndef PLAT_X86_TEST
    { E_SOFT_SERVICE_UDPMSGMODULE_INIT, "UdpMsgModuleInit"},
#endif
    { E_HARD_FEATURE_GET_BOMID,         "BspGetSocMsgBomid" },
    { E_HARD_FEATURE_BOARD_ID,          "BspCoreInitVerGroupPara"},
    { E_HARD_FEATURE_GET_LGC_TYPE,      "BspGetBoardIdFirst"},         /* 需要区分boardid的动作，必须放在本动作后 */
    { E_HARD_FEATURE_SOC_DIFF_INIT,     "BspPreInitSocHwCfg"},
    { E_HARD_FEATURE_RRU_PROPERTY,      "BspRruPropertyInit"},
    { E_HARD_FEATURE_RRU_PROPERTY_PARA, "BspUpdateRruPropertyInfo"},
    { E_HARD_FEATURE_CALI_FILE_GET,     "BspTftpRfTblGetInit"},
    { E_HARD_FEATURE_RRUFILE_INIT,      "BspInitRruFileInfo"},
    {E_CHIP_POWERON_MODIFY_PA_VOLT,     "BspModifyDefaultPaVolt"},
    /* { E_HARD_FEATURE_INIT_RRU_TYPE,     "BspInitRruType"}, */
    { E_HARD_FEATURE_LINK_INFO_INIT,    "BspBoardLinkInfoInit"},
    { E_HARD_FEATURE_FWD_LINK_INFO_INIT,"BspBoardFwdLinkInfoInit"},
#ifndef PLAT_X86_TEST
    { E_FUNCTION_RRU_DEFABILITY,        "BspInitRruDefAbility_S"},
#endif
    { E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,  "BspDpdicCrmInit_BeforeClk"},
    { E_CHIP_POWERON_DPDIC_PAD,         "BspInitGpioPad"},/*主片从进程不需要*/
    { E_HARD_FEATURE_DRV_TBL,           "BspDrvTblInit"},
    { E_HARD_FEATURE_FPGA_DEV_LINK,     "BspFpgaDevLinkInit"},
#ifndef PLAT_X86_TEST
    { E_HARD_FEATURE_DRV_PIN_INIT,      "BspRegDrvPinInit"},
#endif
    { E_HARD_FEATURE_IIC_BUS,           "BspInitI2c"},
    { E_HARD_FEATURE_SPI_BUS,           "BspInitSpi"},
    { E_SOFT_SERVICE_SAVE_BAK_LOG_TO_FLASH_SLAVE, "BspSaveBakLogSlave"},
    { E_HARD_FEATURE_REG_TBL,           "BspRegTblInit"},
    { E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,  "BspDpdicCrmInit_After_M"},/*主片的从进程不需要再进行CRM初始化，不能传参数*/
    { E_CHIP_POWERON_DPDIC_PWRSAVE,        "BspDpdicPwrSaveInit"},  /* 关闭DPDIC内部不使用的资源，节电 */
    {E_CHIP_POWERON_FILE_MOVE,          "BspFileMoveInit"},
    //{ E_HARD_FEATURE_CALI_FILE_GET,     "BspTftpRfTblGetInit"},
    { E_HARD_FEATURE_CALI_FILE,         "BspRfTblInit"},
    { E_CHIP_POWERON_UPDATE_PADACSET_PARA, "BspUpdatePaDacSetParaInit"},
    { E_HARD_FEATURE_CALI_GAIN_MODIFY,  "BspRfTblGainModify"},
    { E_HARD_FEATURE_RRUFILE_CALC,      "intfBspRruInfoCalc"},
    { E_FUNCTION_CHANFREQ_BAND_INIT,      "BspChnFreqBandInfoInit"},
    { E_FUNCTION_CHAN_GROUP_INIT,       "BspChanGroupInit" },
    { E_FUNCTION_RXSCAN_INIT,       "BspInitRxScanInit" },
};

/* --------------------------------------------------------------------- */
/* -------------------------- 初始化流程定义  ------------------------ */
/* --------------------------------------------------------------------- */

static T_BoardInitFlowTbl s_BoardInitFlow_ic4_2_MS_S[] =
{
    { E_CHIP_POWERON_TEMPSENSOR_DEV,     "BspInitTempSensor"},
    { E_CHIP_POWERON_DSP_LOAD,           "LoadDspVersion"},
    { E_CHIP_POWERON_SLAVE_M0_LOAD,       "BsSlaveM0LoadVersion"},
    { E_FUNCTION_PRE_ALLOC,              "BspOptPreAllocInit"},
    { E_TRX_LINK_DPDIC_OPT_TX_SERDES,    "BspNtlTxInit"},/*主片从进程不需要*/
    { E_TRX_LINK_DPDIC_OPT_CPRI_PARA,    "BspDpdicOptCpriParaInit"},/*从进程不需要*/
    { E_TRX_LINK_DPDIC_OPT_CPRI_INIT,    "BspDpdicOptCpriInit"},/*需要拆解，对接BBU的光口主进程需要，从不需要，和业务相关的从需要主不需要*/
    { E_TRX_LINK_DPDIC_OPT_MEAS,         "BspDpdicOptMeasParaInit"},
    { E_TRX_LINK_DPDIC_OPT_HAL_INIT,     "BspDpdicOptCfgParaInit"},
    { E_TRX_LINK_DPDIC_OPT_CELL_INIT,    "BspDpdicOptCellInit"},
    { E_TRX_LINK_DPDIC_OPT_INNER_SERDES_CFG, "BspBoardInnerCpriSpeedCfg"},
#ifndef PLAT_X86_TEST
    { E_TRX_LINK_DPDIC_OPT_RX_SERDES,    "BspNtlRxInit"}, /*此项可能需要调整到初始化最后，实际环境验证决定*//*主片从进程不需要*/
#endif
    { E_TRX_LINK_DPDIC_OPT_INNER_SERDES_MONITOR,"BspInnerSerdesRxMonitor"},
    { E_TRX_LINK_DPDIC_DIF_CLK,          "BspDpdIcDifClkParaInit"},
    { E_TRX_LINK_DPDIC_DIF_SAMRATE,      "BspDpdIcDifSamRateParaInit"},
    { E_TRX_LINK_DPDIC_DIF_RESALLOC,     "BspDpdIcDifResAllocParaInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_ROUTE,     "BspBspVgaBusInitDpdicTxRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_PARA,      "BspDpdicTxRouteParaInit"},
    { E_TRX_LINK_DPDIC_DIF_TX_204,       "BspDpdicTxJ204RouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_RX_ROUTE,     "BspDpdicRxRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_FB_ROUTE,     "BspDpdicFbRouteMapInit"},
    { E_TRX_LINK_DPDIC_DIF_HAL_INIT,     "BspDpdicDifHalInit"},
    { E_TRX_LINK_DPDIC_DIF_CFG,          "BspDpdIcDifInitParaInit"},
    { E_TRX_LINK_DPDIC_DIF_CFG_TDD,      "BspDpdicDifTddCfg"},
    { E_TRX_LINK_DPDIC_DIF_FR,           "BspDpdicDifFrameHeaderInit"},
    { E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,"BspBoardTddIoLinkInfoInit"},
    { E_HARD_FEATURE_TDDIO_CTRL_INIT,    "BspTddIoCtrlInit"},
    { E_HARD_FEATURE_TDDIO_OEEN_BEFORE,  "BspSetExceptPaLnaOeEnable"},
    { E_CHIP_POWERON_TRANSCEIVER_PRE_INIT,    "BspPreInitRfTransceiver"},
    { E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,"BspJ204TrxCallBackInit"},
    { E_TRX_LINK_DPDIC_204_LINK,         "BspJ204LinkInit"},
    { E_TRX_LINK_DPDIC_204_SYSREF,       "BspJ204SysrefInit"},
    { E_TRX_LINK_DPDIC_204_TXEQ,         "BspJ204SerdesTxEqInit"},
    { E_TRX_LINK_DPDIC_204_IC_TRX_LINK_MAP,"BspJ204LinkMapInit"},
    { E_TRX_LINK_DPDIC_204_INIT_STEP,    "BspJ204LinkInitStep"},
    { E_TRX_LINK_DPDIC_204_PRE_STEP,     "BspJ204LinkPreStep"},
#ifndef PLAT_X86_TEST
    { E_CHIP_POWERON_TRANSCEIVER_INIT,    "BspRfTransceiverInit"},
#endif
    { E_CHIP_POWERON_TRANSCEIVER_POST_INIT,    "BspPostInitRfTransceiver"},
    { E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT,   "BspTrxJ204SerdesTxEqInit"},
    { E_TRX_LINK_DPDIC_204_POST_STEP,    "BspJ204LinkPostStep"},  /* 需要放置在Transceiver初始化之后 */
    { E_CHIP_POWERON_RFPLL_INIT,         "BspInitRfPllInit"},
    { E_CHIP_POWERON_ATT_INIT,            "BspInitDattVgaPara"},
    { E_CHIP_POWERON_ACATT_INIT,          "BspInitAcAttSwitchPara"},
    { E_CHIP_POWERON_DAC_CALLBACK,       "BspDacInterfaceParaInit"},
    { E_CHIP_POWERON_PA_DAC,             "BspDacDevInit"},
    { E_CHIP_POWERON_RF_ADC,             "BspInitRfRxAdc"},
    { E_FUNCTION_TRX_DIG_GAIN_INIT,      "TrxDigGainInit"},
    { E_FUNCTION_TX_FREQ_CFG,            "BspTxFreqCfgInit"},
    { E_FUNCTION_RX_FREQ_CFG,            "BspRxFreqCfgInit"},
    { E_FUNCTION_TX_RF_DELAY,            "BspTxRfDlyInit"},
    { E_FUNCTION_RX_RF_DELAY,            "BspRxRfDlyInit"},
    { E_FUNCTION_TX_DELT_DELAY,          "BspInitTxDeltDly"},
    { E_FUNCTION_RX_DELT_DELAY,          "BspInitRxDeltDly"},
    { E_FUNCTION_FDD_DELAY,              "BspInitFddDlyPara"},/*只有FDD机型走此流程，TDD机型参数不需要配置*/
    { E_FUNCTION_FDD_TOFFSET,            "BspInitFddToffset"},
    { E_FUNCTION_FDD_FIXLINK,            "BspInitFddFixLink"},
    { E_FUNCTION_CHIP_TRANDLY,           "BspInitChipTranDlyPara"},
    { E_FUNCTION_DL_POWCALC_PARA_INIT,   "BspInitDlPowCalcPara"},
    { E_FUNCTION_UL_POWCALC_PARA_INIT,   "BspInitUlPowCalcPara"},
    { E_FUNCTION_POWCALC_INIT,           "BspInitPowCalcPara"},
    { E_FUNCTION_OPENLOOP_PARA_INIT,     "BspInitOpenLoopPara"},
    { E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,"BspInitPowCalcThresholdPara"},
    { E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA,      "BspCbSwCommonParaInit" },
    { E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,      "BspCbSwStaTblParaInit" },
    { E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA,       "BspCbSwRfTblParaInit" },
    { E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA,   "BspCbSwRfTblParaInit_Fpga" },
    { E_FUNCTION_POWCALC_THREAD_INIT,    "BspInitPowCalcThread"},
    {E_FUNCTION_VECTORVSWR_INIT,         "BspDpdVswrParaInit"},
    { E_FUNCTION_CFR_PARA_INIT,          "BspInitCfrPara"},
    { E_FUNCTION_CFR_FUNC_INIT,          "BspInitCfrFunc"},
    { E_FUNCTION_DPD_FUNC_INIT,          "BspInitDpdFunc"},
    { E_HARD_FEATURE_CPUID_INIT,         "BspInitCpuAndCoreId"},
    { E_FUNCTION_VGA_LIKE_SPI_PARA_INIT, "BspVgaLikeSpiParaInit"},
    { E_FUNCTION_VGA_BUS_INIT,           "BspVgaBusInit"},
    { E_FUNCTION_RF_VGA_INIT,            "BspRfVgaInit"},
    { E_FUNCTION_VGA_CFG_INIT,           "BspVgaCfgInit"},
    { E_FUNCTION_VGA_FPGACTRL_INIT,     "BspVgaInfoInit"},
    { E_FUNCTION_VGA_CTRL_MGC_CMD_INIT, "BspMgcCmdInfoInit"},
    { E_HARD_FEATURE_PA_VOLT_INIT,   "BspPaDefaultVoltInit"},
    /*{ E_FUNCTION_STOP_AGC_CTRL_INIT,     "BspStopAgcCtrl"},*/    /* 暂时屏蔽，待完成开发后放开 */
#ifndef PLAT_X86_TEST
    { E_HARD_FEATURE_COMMON_THREAD_INIT, "BspCommonThreadInit"},
    { E_FUNCTION_PAPT_REPORT_RECOVER,    "BspPaptReportRecoverInit"},
    { E_HARD_FEATURE_OPT_PAPT_INIT,        "BspPaptCfgInfoInit"},
    { E_HARD_FEATURE_CRM_PAPT_INIT,        "BspPaptCrmInfoInit"},
    { E_HARD_FEATURE_PAPT_UPDATA,        "BspInitPaptUpdata"},
    { E_HARD_FEATURE_PAPT_INIT,          "BspInitPaPtPara"},
    { E_FUNCTION_RRU_CARR_ABILITY,      "BspInitRruCarrAbility"},
#endif
    {E_FUNCTION_DTX_PARA_INIT,          "BspDtxParaInit"},
    {E_HARD_FEATURE_TDDIO_DTX,          "BspInitDtxCfg"},
    {E_FUNCTION_RRU_ULDELAY_CMPABILITY, "BspInitRruUlDelayCmpAbility"},
#ifndef _BSP_WITH_WFS
    {E_FUNCTION_REV_PROTECT_INIT,      "BspRevPowProtectInit"},
#endif
    { E_TRX_LINK_DPDIC_204_RECORD_STATE, "BspRecord204LinkStatus"},
    { E_HARD_FEATURE_TDDIO_OEEN_AFTER,   "BspSetPaLnaOeEnable"},
    { E_CHIP_POWERON_DPDIC_PWRSAVE_POST, "BspDpdicPwrSavePostInit"},  /* 节电后处理 */
    //{ E_HARD_FEATURE_USE_STATIC_DEVID,   "BspUseStaticDevIdInit"}
    { E_FUNCTION_LNAOFF_PARA_INIT,       "BspInitLnaOffPara"},
    { E_FUNCTION_ICPSYNC_INTERRUPT_INIT, "BspPsyncInterruptInit"},
    { E_FUNCTION_DPD_SET_EQ_INIT,        "BspDpdSetEqCaliParam"},
    { E_FUNCTION_RRU_ABILITY_FLAG,       "BspSetRruSpecialFlagInit"},
    { E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH_SLAVE, "BspGetCurLogForMasterTaskSlave"},
    { E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH_SLAVE, "BspSaveKmsgLogSlave"},
    { E_HARD_FEATURE_RRUTEMP_OFFSET_INIT,    "BspRruTempOffsetInit"},
    {E_FUNCTION_POW_THROD_CFG,                 "BspInitPowThrodCfg"},
    {E_CHIP_POWERON_PWR_DEV,             "BspInitPwrRpdc"},
    {E_CHIP_POWERON_PMB_SCALE_INFO,      "BspPmbScaleInfoInit"},
    {E_HARD_FEATURE_DPDIC_DYN_VOLT_CFG,  "BspDpdicDynVoltParaInit"},
    {E_FUNCTION_NTF_PARA_INIT,           "BspNtfCfgInit"},
};

static T_ModleInitItem modleItem_ic4_2_onechip =
{
    s_BoardActFuncTbl_ic4_2_base, NELEMENTS(s_BoardActFuncTbl_ic4_2_base),
    s_BoardActFuncTbl_ic4_2_onechip, NELEMENTS(s_BoardActFuncTbl_ic4_2_onechip),
    s_BoardPreInitFlow_ic4_2_onechip, NELEMENTS(s_BoardPreInitFlow_ic4_2_onechip),
    s_BoardInitFlow_ic4_2_onechip, NELEMENTS(s_BoardInitFlow_ic4_2_onechip)
};

static T_ModleInitItem modleItem_ic4_2_MS_M =
{
    s_BoardActFuncTbl_ic4_2_base, NELEMENTS(s_BoardActFuncTbl_ic4_2_base),
    s_BoardActFuncTbl_ic4_2_MS_M, NELEMENTS(s_BoardActFuncTbl_ic4_2_MS_M),
    s_BoardPreInitFlow_ic4_2_MS_M, NELEMENTS(s_BoardPreInitFlow_ic4_2_MS_M),
    s_BoardInitFlow_ic4_2_MS_M, NELEMENTS(s_BoardInitFlow_ic4_2_MS_M)
};

static T_ModleInitItem modleItem_ic4_2_MS_M_PLUS =
{
    s_BoardActFuncTbl_ic4_2_base, NELEMENTS(s_BoardActFuncTbl_ic4_2_base),
    s_BoardActFuncTbl_ic4_2_MS_M, NELEMENTS(s_BoardActFuncTbl_ic4_2_MS_M),
    s_BoardPreInitFlow_ic4_2_MS_M, NELEMENTS(s_BoardPreInitFlow_ic4_2_MS_M),
    s_BoardInitFlow_ic4_2_MS_M_PLUS, NELEMENTS(s_BoardInitFlow_ic4_2_MS_M_PLUS)
};

static T_ModleInitItem modleItem_ic4_2_MS_S =
{
    s_BoardActFuncTbl_ic4_2_base, NELEMENTS(s_BoardActFuncTbl_ic4_2_base),
    s_BoardActFuncTbl_ic4_2_MS_S, NELEMENTS(s_BoardActFuncTbl_ic4_2_MS_S),
    s_BoardPreInitFlow_ic4_2_MS_S, NELEMENTS(s_BoardPreInitFlow_ic4_2_MS_S),
    s_BoardInitFlow_ic4_2_MS_S, NELEMENTS(s_BoardInitFlow_ic4_2_MS_S)
};

static T_ModleInitItem modleItem_ic4_2_ads =
{
    s_BoardActFuncTbl_ic4_2_base, NELEMENTS(s_BoardActFuncTbl_ic4_2_base),
    s_BoardActFuncTbl_ic4_2_onechip, NELEMENTS(s_BoardActFuncTbl_ic4_2_onechip),
    s_BoardPreInitFlow_ic4_2_ads, NELEMENTS(s_BoardPreInitFlow_ic4_2_ads),
    s_BoardInitFlow_ic4_2_ads, NELEMENTS(s_BoardInitFlow_ic4_2_ads)
};

/**************************************************************************
                               接口定义
**************************************************************************/

static __attribute((constructor)) void BspModelItemInit_Ic4_2()
{
    BspSetModelItem(E_BOARD_ONE_CHIP_TYPE, &modleItem_ic4_2_onechip);
    BspSetModelItem(E_BOARD_MS_M_TYPE, &modleItem_ic4_2_MS_M);
    BspSetModelItem(E_BOARD_MS_M_PLUS_TYPE, &modleItem_ic4_2_MS_M_PLUS);
    BspSetModelItem(E_BOARD_MS_S_TYPE, &modleItem_ic4_2_MS_S);
    BspSetModelItem(E_BOARD_ADS_TEST_TYPE, &modleItem_ic4_2_ads);
}

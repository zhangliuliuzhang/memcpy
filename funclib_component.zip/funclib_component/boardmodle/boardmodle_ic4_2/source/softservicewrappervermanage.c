/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : softservicewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了p3进程所需初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "bspcommon.h"
#include "boardmodlecommon.h"
#include "softservicewrappervermanage.h"
#include "board_ic4_2.h"
#include "dbootctrl_new.h"
#include "boardDboot.h"
#include "i2cbuszx211413.h"
#include "trustsvc.h"
#include "sign_verify.h"
#include "fpgaloadprocess.h"
#include "certkeyprocess.h"
#include "ichaladapt_ic4_2.h"
#include "dualbootapi.h"
// #include "zx211413gpio.h"
// #include "regdrv_pincfg.h"
#include "regaccess.h"

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
UINT32 g_flashDivision = 0;   /*flash区分 单NOR、NOR+NAND*/


/* ==============================================================
    DBOOT参数(下标0-NOR+NAND配置, 下标1-单NOR配置)
 ============================================================== */
static TDbootPara s_tDbootInitPara[FLASH_PARA_MAX] =
{
    {
        {
            {
                M0BOOT_MASTER_ADDR,
                M0BOOT_SLAVE_ADDR,
            },
            {
                BOOT_BL2_MASTER_ADDR,
                BOOT_BL2_SLAVE_ADDR,
            },
            {
                KEBOOT_MASTER_ADDR,
                KEBOOT_SLAVE_ADDR,
            },
        },
        {
            M0BOOT_SIZE,
            BOOT_BL2_SIZE + BOOT_FIP_SIZE,
            KEBOOT_MAX_SIZE,
        },
        3,
        BspGetMsBootSel,
        BspSetMsBootSel,
        BspGetCpuType,
    },
    {
        {
            {
                M0BOOT_MASTER_ADDR,
                M0BOOT_SLAVE_ADDR,
            },
            {
                BOOT_BL2_MASTER_ADDR_NOR,
                BOOT_BL2_SLAVE_ADDR_NOR,
            },
            {
                KEBOOT_MASTER_ADDR_NOR,
                KEBOOT_SLAVE_ADDR_NOR,
            },
        },
        {
            M0BOOT_SIZE,
            BOOT_BL2_SIZE_NOR + BOOT_FIP_SIZE_NOR,
            KEBOOT_MAX_SIZE_NOR,
        },
        3,
        BspGetMsBootSel,
        BspSetMsBootSel,
        BspGetCpuType,
    }
};

UINT32 BspInitDbootPara(VOID)
{
    UINT32 flashParaSel = BspGetFlashParaSel();

    BspGetBootFlagCallback((FUNC_GET_BOOT_FLAG)BspGetMsBootSel);
    BspSetBootFlagCallback((FUNC_SET_BOOT_FLAG)BspSetMsBootSel);
    BspSetBootVerSrc(BOOT_VER_FROM_FLASH);

    if (flashParaSel >= FLASH_PARA_MAX)
    {
        flashParaSel = FLASH_PARA_NOR_NAND;
    }
    return BspDbootParaInit(&s_tDbootInitPara[flashParaSel]);
}

UINT32 BspGetSecNvEnByGpio(UINT32 enType, UINT32 *enVal)
{
    UINT32 retVal = 0;
    UINT32 uRet = 0;

    INPUT_POINTER_CHECK(enVal);

    if (enType == 0) /*安全使能：配置为功能模式1(GPIO引脚输入)，读取0xd4c00168 bit 4*/
    {
        IcHalRdReg(0, PAD_TRX_RXEN3_IO_CFG, 0, &retVal);
        IcHalWrReg(0, PAD_TRX_RXEN3_IO_CFG, 0, 0x250);
        BspSysMsDelay_Sys(100);
        uRet = IcHalBitRdReg(0, CRM_M0_RECORD_TEMP_REG, 0, enVal, 4, 5);
        IcHalWrReg(0, PAD_TRX_RXEN3_IO_CFG, 0, retVal);
    }
    else if (enType == 1) /*安全使能：配置为功能模式1(GPIO引脚输入)，读取0xd4c00168 bit 5*/
    {
        IcHalRdReg(0, PAD_TRX_RXEN2_IO_CFG, 0, &retVal);
        IcHalWrReg(0, PAD_TRX_RXEN2_IO_CFG, 0, 0x250);
        BspSysMsDelay_Sys(100);
        uRet = IcHalBitRdReg(0, CRM_M0_RECORD_TEMP_REG, 0, enVal, 5, 6);
        IcHalWrReg(0, PAD_TRX_RXEN2_IO_CFG, 0, retVal);
    }
    dbgInfo("%s>>read %s -- val'%d !\n", __FUNCTION__, (enType == 0) ? "sec en" : "roll-back en", *enVal);

    return uRet;
}

UINT32 BspInitGpioRdFunc(void)
{
    return BspGpioReadCallBack(BspGetSecNvEnByGpio);
}

UINT32 BspInitEfuseWriteFunc(void)
{
    return BspEfuseWriteCallBack(crmEfuseRegWrite);
}

UINT32 BspInitEfuseReadFunc(void)
{
    return BspEfuseReadCallBack(crmEfuseRegRead);
}

UINT32 BspCfgSecVerifyCallBack(VOID)
{
    BspFpgaLoadPrnCallBack((pFpgaLoadPrintFunc)FpgaLoadPrint);/*fpgaloadlog回调函数挂接*/
    BspChkFlashVerCallBack((pChkFlashVerFunc)BspChkFlashVer);/*BspChkFlashVer回调函数挂接*/
    BspCheckSystemVerSignCallBack((pCheckSystemVerSign)BspCheckSystemVerSign);/*BspCheckSystemVerSign回调函数挂接*/

    return BSP_OK;
}

/********供单板调用、获取flash类型并更新全局变量**************/
VOID BspSetFlashDivision(UINT32 flashDivision)
{
    g_flashDivision = flashDivision;
}
/********供 APP调用 、获取flash类型全局变量 1为单NOR，0为NOR+NAND**************/
UINT32 BspGetFlashDivision(VOID)
{
    UINT32 flashDivision = 0;

    flashDivision = g_flashDivision;

    return flashDivision;

}
UINT32 BspCfgSecVerifyPara(VOID)
{
    UINT32 ulFlashAddr[9] ={(SIZE_128M - SIZE_1M),SIZE_4K,(SIZE_128M - SIZE_1M+SIZE_8K),SIZE_4K*7,SIZE_4K*7,SIZE_32K,(SIZE_128M - SIZE_1M+SIZE_128K),SIZE_4K*5,SIZE_4K*5};
    UINT32 FlashAddr[9]   ={SIZE_45M,SIZE_4K,(SIZE_45M+SIZE_8K),SIZE_4K*7,SIZE_4K*7,SIZE_32K,(SIZE_45M+SIZE_128K),SIZE_4K*5,SIZE_4K*5};
    UINT32 ulRet = BSP_OK;

    /*设置秘钥区flash偏移*/
    if(g_flashDivision == 0)  //NOR+NAND
    {
        ulRet |= BspCfgFlashAddrLen(ulFlashAddr);
    }
    else  //单NOR
    {
        ulRet |= BspCfgFlashAddrLen(FlashAddr);
    }

    /*设置回调函数*/
    ulRet |=  BspSetSecVerifyFunc(BspGetVersionSign,BspDecodeB64,BspModuleVersion_Verify);

    return ulRet;
}

// minMGR对应接口: BspInitSecVerifyFun
UINT32 BspCfgSecVerifyFun(VOID) /* 是否启用验签功能 */
{
    UINT32  ulBySwitch = 0;
    UINT32  ulTmpRet = BSP_OK;
    UINT32  ulFunRet = BSP_ERROR;

    /* 检查调试标记 */
    if (BSP_OK == BspGetSafeBootDbgFlag())
    {
        dbgInfo("%s>>BspMGR File[/ata/SafeBoot_dbg] Exist!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    // 获取安全Boot开关状态: 0-安全关闭, 1-安全打开
    ulTmpRet = BspGetSafeBootCheckSwitch(&ulBySwitch);
    if (BSP_OK == ulTmpRet)
    {
        if (1 == ulBySwitch) /* 启用验签 */
        {
            ulFunRet = BspCfgSecVerifyPara();
            dbgInfo("%s>>BspMGR SafeBoot Open; SecVerifyPara Cfg %s!\n", __FUNCTION__,
                    (ulFunRet == BSP_OK) ? ("Succ") : ("Error"));
        }
        else
        {
            dbgInfo("%s>>BspMGR SafeBootCheckSwitch'%d Get Succ! SafeBoot Close;\n",
                    __FUNCTION__, ulBySwitch);
        }
    }
    else
    {
        dbgErr("%s>>BspMGR SafeBootCheckSwitch'%d Get Error! SafeBoot Close;\n",
               __FUNCTION__, ulBySwitch);
    }

    return ulFunRet;
}


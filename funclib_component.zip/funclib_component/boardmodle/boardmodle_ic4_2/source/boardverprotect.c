/*****************************************************************************
* 版权所有(C) 2022, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardverprotect.c
* 文件标识 : 无
* 内容摘要 : 版本保护区相关实现
* 注意事项 : 无
*---------------------------------------------------------------------------*/

#include "boardverprotect.h"
#include "fpgaloadprocess.h"
#include "boardmodle_ic4_2.h"
#include "board_ic4_2.h"
#include "funccommon.h"

#define ELSE_IF(x) else if(x)
/**************************************************************************
*                         全局变量声明
**************************************************************************/

/**************************************************************************
*                             内部接口定义
**************************************************************************/
/* 清高端内存中的版本号记录 */
static VOID ClearHighMemVersionInfo(VOID)
{
    BspSetModuleSoftVersion(SOFT_TYPE_SOCFPGA, NULL, 0);
    BspSetModuleSoftVersion(SOFT_TYPE_SOCCUR, NULL, 0);
    BspSetModuleSoftVersion(SOFT_TYPE_SOCMGR, NULL, 0);
    BspSetModuleSoftVersion(SOFT_TYPE_ACR8, NULL, 0);
    BspSetModuleSoftVersion(SOFT_TYPE_DPDDSP, NULL, 0);
    return;
}

/**************************************************************************
*                         外部接口定义
**************************************************************************/

/**************************************************************************
 * 函数名称: BspInitVersionProtect(*)
 * 功能描述: 保护区版本Flash地址信息初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspInitVersionProtect(T_VerProtectInfo *verInfo)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(verInfo);

    BspSetVerProtectAddr(verInfo->startAddr);
    BspSetVerProtectLen(verInfo->size);
    BspSetVerProtectType(verInfo->verType); /* 保护区中刷入完整版本 */
    BspSetBoardSectorInfo(SIZE_1M, SIZE_1M);

    return retVal;
}

/**************************************************************************
 * 函数名称: BspSetProtectFileNum(*)
 * 功能描述: 设置版本清单
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明: 涉及保护区刷新接口BspFlushSysPackVerToProtect和创建xml文件接口BspCreateXmlFile
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspSetProtectFileList(T_AllRunVerList *verList)
{    
    UINT32 ulCnt = 0;
    UINT32 ulVerNum = 0;
    UINT32 ulMasterVerNum = 0;
    UINT32 ulSlaveVerNum = 0;
    UINT32 protectVerList[32] ={0};

    INPUT_POINTER_CHECK(verList);

    ulMasterVerNum = verList->ulMasterVerNum;
    ulSlaveVerNum = verList->ulSlaveVerNum;
    ulVerNum = ulMasterVerNum + ulSlaveVerNum;
    if((ulVerNum < ulMasterVerNum) || (ulVerNum < ulSlaveVerNum))
    {
        dbgErr("%s>>The ulVerNum Overflow!!! \n", __FUNCTION__);
        return BSP_ERROR;
    }
    for(ulCnt = 0;ulCnt < min(MASTER_VER_NUM_MAX,ulMasterVerNum);ulCnt++)
    {
        protectVerList[ulCnt] = verList->tMasterRunVerList[ulCnt].ulSoftType;
    }            
    for(ulCnt = 0;ulCnt < min(SLAVE_VER_NUM_MAX,ulSlaveVerNum);ulCnt++)
    {
        protectVerList[ulCnt + ulMasterVerNum] = verList->tSlaveRunVerList[ulCnt].ulSoftType;
    }

    for(ulCnt = 0;ulCnt < min(32,ulVerNum);ulCnt++)
    {
        dbgInfo("%s>>protectVerList[%d] equal %d!\n",__FUNCTION__,ulCnt,protectVerList[ulCnt]);
    }
    BspSetWriteXmlToProtectFlag(verList->writeXmlFile);
    //coverity[cert_exp37_c_violation:SUPPRESS] 
    //coverity[cert_dcl60_cpp_violation:SUPPRESS] 
    //coverity[cert_int31_c_violation:SUPPRESS]     
    return BspSetProtectVerIndex((UINT32 *)protectVerList,ulVerNum,verList);
}


/**************************************************************************
 * 函数名称: BspExtractSocVer
 * 功能描述: 提取从片版本(仅适用于多片IC的主片主MGR)
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明: 
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspExtractSocVer(VOID)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulSoftType = 0xFFFF;
    UINT32 ulVerType = BSP_RUN_VERSION;
    INT32  iRet = 0;
    T_XMLLIST_PARA tLoadVerPara = {0};
    UINT32 socVerIdx = 0;
    CHAR acSrcFileName[32] = {0};
    CHAR acDesFileName[32] ={0};
    CHAR acFilePath[] = "/tmp";
    UINT32 retVal = 0;
    T_AllRunVerList *verList = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_INIT_SOC_VER, 0, 0, verList, num);
    ClearHighMemVersionInfo();
    for(socVerIdx=0;socVerIdx<verList->ulSlaveVerNum;socVerIdx++)
    {
        ulSoftType = BspSwitchNameToSoftType(verList->tSlaveRunVerList[socVerIdx].acVerName);
        if(ulSoftType == BSP_ERROR)
        {
            dbgErr("%s>>can't get %s 's  SoftType !\n",__FUNCTION__,verList->tSlaveRunVerList[socVerIdx].acVerName);
            continue;
        }
        memset_s(&tLoadVerPara,sizeof(tLoadVerPara),0,sizeof(tLoadVerPara));
        BspClrSingleVerLoadRes(ulSoftType);            //coverity[cert_exp37_c_violation:SUPPRESS] 
        ulRet = BspGetXmlListPara(ulSoftType, &tLoadVerPara);
        if(ulRet == BSP_ERROR)
        {
            dbgErr("%s>>can't get softtype %d 's  loadVerPara !\n",__FUNCTION__,ulSoftType);
            continue;
        }
        
        if(tLoadVerPara.ulPostRes == 1)
        {
            ulVerType = BSP_ACK_VERSION;
        }
        else
        {
            ulVerType = BSP_RUN_VERSION;
        }
        /*生成版本名*/
#ifdef _BSP_WITH_WFS
        if(snprintf_s(acSrcFileName,32,"/ata/BSP/%s",tLoadVerPara.acFileName) < 0)
#else
        if(snprintf_s(acSrcFileName,32,"/ata/rru/%s",tLoadVerPara.acFileName) < 0)
#endif
        {
            dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);
            if(tLoadVerPara.ulPostRes == 1)
            {
                //ulVerType = BSP_ACK_VERSION;
                BspRecordVerLoadRes(ulSoftType,BIT_SET(0),ulVerType); 
                return BSP_ERROR;
            }
            else
            {
                BspRecordVerLoadRes(ulSoftType,BIT_SET(1),ulVerType); 
                continue;
            }
        } 

        if(ulSoftType == 13)/*保持soc cur 名字不变*/
        {
            iRet = snprintf_s(acDesFileName,32,"/tmp/cpu.swv");
        }
        ELSE_IF(ulSoftType == 7)/*部分机型的从片MGR为cur7，但是minimgr识别从片MGR时统一成cur14*/
        {
            iRet = snprintf_s(acDesFileName,32,"/tmp/cur14.swv");
        }
        else
        {
            iRet = snprintf_s(acDesFileName,32,"/tmp/cur%d.swv",ulSoftType);
        }
        if(iRet < 0)
        {            
            dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);
            if(tLoadVerPara.ulPostRes == 1)
            {
                //ulVerType = BSP_ACK_VERSION;
                BspRecordVerLoadRes(ulSoftType,BIT_SET(2),ulVerType); 
                return BSP_ERROR;
            }
            else
            {
                BspRecordVerLoadRes(ulSoftType,BIT_SET(3),ulVerType); 
                continue;
            }
        }
        
        /*获取文件系统版本*/
        //if(BSP_OK!=(ulRet = BspGetVerSwvData(acSrcFileName, 0xFFFF,"/tmp",acDesFileName,(UINT32*)&tLoadVerPara.ulPostRes))) //coverity[cert_exp37_c_violation:SUPPRESS] 
        //coverity[cert_exp37_c_violation:SUPPRESS] 
        //coverity[cert_int31_c_violation:SUPPRESS] 
        //coverity[cert_dcl60_cpp_violation:SUPPRESS] 
        //coverity[cert_dcl40_cpp_violation:SUPPRESS] 
        if(BSP_OK!=(ulRet = BspGetVerSwvData(acSrcFileName, 0xFFFF,acFilePath,acDesFileName,&tLoadVerPara.ulHashSelect)))
        {
            dbgErr("%s>>Get %s FileSysVerSwvData failed ![Ret %#x]\n",__FUNCTION__,acSrcFileName,ulRet);  
            if(tLoadVerPara.ulPostRes == 1)
            {
                //ulVerType = BSP_ACK_VERSION;
                /*版本升级过程中，直接返回错误*/       
                BspRecordVerLoadRes(ulSoftType,BIT_SET(4),ulVerType); 
                return BSP_ERROR; 
                //continue;
            }
            else
            {
                BspRecordVerLoadRes(ulSoftType,BIT_SET(5),ulVerType);
            }
            
            /*获取保护区版本*/
            ulVerType = BSP_PROVERSION;
            //coverity[cert_str30_c_violation:SUPPRESS] 
            if(BSP_OK!=(ulRet = BspGetVerSwvData(NULL,ulSoftType,(CHAR*)"/tmp",acDesFileName,NULL)))
            {
                dbgErr("%s>>Get SoftType%d ProctVerSwvData failed ![Ret %#x]\n",__FUNCTION__,ulSoftType,ulRet);
                BspRecordVerLoadRes(ulSoftType,BIT_SET(6),ulVerType);
                continue;
            } 
        }
        dbgInfo("%s>>Get SoftType%d VerSwvData OK ![Ret %#x]\n",__FUNCTION__,ulSoftType,ulRet);
        BspRecordVerLoadRes(ulSoftType,0,ulVerType);
    }
    return ulRet;  
}

/* Started by AICoder, pid:fb5636a1aaf663514978082c1015cf84461802ae */
/**************************************************************************
 * 函数名称: BspExtractSocVer
 * 功能描述: 提取从片版本(仅适用于多片IC的主片主MGR),仅仅拷贝从片版本到tmp路径下
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspExtractSocVerToTmp(VOID)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulSoftType = 0xFFFF;
    INT32  iRet = 0;
    T_XMLLIST_PARA tLoadVerPara = {0};
    UINT32 socVerIdx = 0;
    CHAR acSrcFileName[32] = {0};
    CHAR acDesFileName[32] ={0};
    CHAR acFilePath[] = "/tmp";
    UINT32 retVal = 0;
    T_AllRunVerList *verList = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_INIT_SOC_VER, 0, 0, verList, num);

    for(socVerIdx=0;socVerIdx<verList->ulSlaveVerNum;socVerIdx++)
    {
        ulSoftType = BspSwitchNameToSoftType(verList->tSlaveRunVerList[socVerIdx].acVerName);
        if(ulSoftType == BSP_ERROR)
        {
            dbgErr("%s>>can't get %s 's  SoftType !\n",__FUNCTION__,verList->tSlaveRunVerList[socVerIdx].acVerName);
            BspLog(LOG_LEVEL_0,"[%s] >>can't get %s 's  SoftType !\n", __FUNCTION__,verList->tSlaveRunVerList[socVerIdx].acVerName);

            continue;
        }
        memset_s(&tLoadVerPara,sizeof(tLoadVerPara),0,sizeof(tLoadVerPara));

        ulRet = BspGetXmlListPara(ulSoftType, &tLoadVerPara);
        if(ulRet == BSP_ERROR)
        {
            dbgErr("%s>>can't get softtype %d 's  loadVerPara !\n",__FUNCTION__,ulSoftType);
            BspLog(LOG_LEVEL_0,"[%s] >>can't get softtype %d 's  loadVerPara !\n", __FUNCTION__,ulSoftType);

            continue;
        }

        /*生成版本名*/
#ifdef _BSP_WITH_WFS
        if(snprintf_s(acSrcFileName,32,"/ata/BSP/%s",tLoadVerPara.acFileName) < 0)
#else
        if(snprintf_s(acSrcFileName,32,"/ata/rru/%s",tLoadVerPara.acFileName) < 0)
#endif
        {
            dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);

        }

        if(ulSoftType == 13)/*保持soc cur 名字不变*/
        {
            iRet = snprintf_s(acDesFileName,32,"/tmp/cpu.swv");
        }
        ELSE_IF(ulSoftType == 7)/*部分机型的从片MGR为cur7，但是minimgr识别从片MGR时统一成cur14*/
        {
            iRet = snprintf_s(acDesFileName,32,"/tmp/cur14.swv");
        }
        else
        {
            iRet = snprintf_s(acDesFileName,32,"/tmp/cur%d.swv",ulSoftType);
        }
        if(iRet < 0)
        {
            dbgErr("%s>>snprintf error [line:%d]\n",__FUNCTION__,__LINE__);

        }

        if(BSP_OK!=(ulRet = BspGetVerSwvData(acSrcFileName, 0xFFFF,acFilePath,acDesFileName,&tLoadVerPara.ulHashSelect)))
        {
            dbgErr("%s>>Get %s FileSysVerSwvData failed ![Ret %#x]\n",__FUNCTION__,acSrcFileName,ulRet);
            BspLog(LOG_LEVEL_0,"[%s] >>Get %s FileSysVerSwvData failed ![Ret %#x]\n",__FUNCTION__,acSrcFileName,ulRet);

        }
    }
    return ulRet;
}
/* Ended by AICoder, pid:fb5636a1aaf663514978082c1015cf84461802ae */
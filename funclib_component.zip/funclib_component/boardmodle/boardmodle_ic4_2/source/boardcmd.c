/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : boardcmd.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了例化单板的通用调试接口
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/
#include "bspcomm.h"
#include "funccommon.h"
#include "boardmodlecommon.h"
#include "boardmodle_ic4_2.h"
#include "boardhardid.h"
#include "udpmsg_ic.h"
#include "boardsocmsg.h"
#include "rruinfo.h"
#include "chnmap_a.h"
#include "ichaladapt_crm_ic4_2.h"
#include "exprn.h"
#include "flash.h"
/**************************************************************************
*                                宏定义                                      *
**************************************************************************/
#define BOARD_HELP_CMD_LEN   (128)


/**************************************************************************
*                            全局变量定义                                       *
**************************************************************************/
UINT8 g_BoardHelpPrint[][BOARD_HELP_CMD_LEN] =
{
    "prnbomid",
    "setbomid idx",
    "printflash addr,len",
    "writeflash addr,data"
    "showchanmap"
};

/**************************************************************************
*                                函数声明                                     *
**************************************************************************/
UINT32 IcTemp(void);

/**************************************************************************
*                                接口定义                                     *
**************************************************************************/
UINT32 prnbomid(VOID)
{
    UINT32 ulGroupIdx      = 0;
    UINT32 retVal = BSP_OK;
    TVerGroup *pVerGroup = NULL;
    UINT32 num = 0;
    
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_BOARD_ID,0,0,pVerGroup,num);
    dbgInfo("SoftId  NickName      ModuleGroupId  BrdGroupId  BrdTypeId  HdChangeId  HdCustomIdA  HdCustomIdB  MagicNum\n");
    for (ulGroupIdx = 0; ulGroupIdx < num; ulGroupIdx++)
    {
        dbgInfo("%#6X  " , ulGroupIdx);
        dbgInfo("%-12s  ", pVerGroup[ulGroupIdx].cNickname); // 负数向左对齐
        dbgInfo("%#13X  ", pVerGroup[ulGroupIdx].HardId[MOD_GROUP_ID]);
        dbgInfo("%#10X  ", pVerGroup[ulGroupIdx].HardId[BRD_GROUP_ID]);
        dbgInfo("%#9X  " , pVerGroup[ulGroupIdx].HardId[BRD_TYPE_ID]);
        dbgInfo("%#10X  ", pVerGroup[ulGroupIdx].HardId[HW_CHANGE_ID]);
        dbgInfo("%#11X  ", pVerGroup[ulGroupIdx].HardId[HW_CUSTOM_ID_A]);
        dbgInfo("%#11X  ", pVerGroup[ulGroupIdx].HardId[HW_CUSTOM_ID_B]);
        dbgInfo("%#8X  " , pVerGroup[ulGroupIdx].HardId[BOMID_MAGIC_NUM]);
        dbgInfo("\n");
    }
    return retVal;
}

UINT32 setbomid(UINT32 idx, UINT32 type)
{
    UINT32 ulModuleGroupId = 0xFFFF;
    UINT32 ulBoardGroupId  = 0xFFFF;
    UINT32 ulBoardTypeId   = 0xFFFF;
    UINT32 ulHwChangeId    = 0xFFFF;
    UINT32 ulCustomHwIdA   = 0xFFFF;
    UINT32 ulCustomHwIdB   = 0xFFFF;
//  UINT32 ulBomMagicNum   = 0xFFFF;
//  UINT32 ulBrdBomidCrc   = 0xFFFF;
    UINT32 retVal          = BSP_OK;
    TVerGroup *pVerGroup   = NULL;
    UINT32 num = 0;
    
    if(1 == type)
    {
        BOARD_MODLE_GET_DATA(E_HARD_FEATURE_BOARD_ID,1,0,pVerGroup,num);
        if(idx < num)
        {
            ulModuleGroupId = (pVerGroup[idx].HardId[MOD_GROUP_ID])    & 0xFFFF;
            ulBoardGroupId  = (pVerGroup[idx].HardId[BRD_GROUP_ID])    & 0xFFFF;
            ulBoardTypeId   = (pVerGroup[idx].HardId[BRD_TYPE_ID])     & 0xFFFF;
            ulHwChangeId    = (pVerGroup[idx].HardId[HW_CHANGE_ID])    & 0xFFFF;
            ulCustomHwIdA   = (pVerGroup[idx].HardId[HW_CUSTOM_ID_A])  & 0xFFFF;
            ulCustomHwIdB   = (pVerGroup[idx].HardId[HW_CUSTOM_ID_B])  & 0xFFFF;
        //  ulBomMagicNum   = (pVerGroup[idx].HardId[BOMID_MAGIC_NUM]) & 0xFFFF;
        //  ulBrdBomidCrc   = (pVerGroup[idx].HardId[BOMID_CRC_DATA])  & 0xFFFF;
        }
    }
    else
    {
        BOARD_MODLE_GET_DATA(E_HARD_FEATURE_BOARD_ID,0,0,pVerGroup,num);
        if (idx < num)
        {
            ulModuleGroupId = (pVerGroup[idx].HardId[MOD_GROUP_ID])    & 0xFFFF;
            ulBoardGroupId  = (pVerGroup[idx].HardId[BRD_GROUP_ID])    & 0xFFFF;
            ulBoardTypeId   = (pVerGroup[idx].HardId[BRD_TYPE_ID])     & 0xFFFF;
            ulHwChangeId    = (pVerGroup[idx].HardId[HW_CHANGE_ID])    & 0xFFFF;
            ulCustomHwIdA   = (pVerGroup[idx].HardId[HW_CUSTOM_ID_A])  & 0xFFFF;
            ulCustomHwIdB   = (pVerGroup[idx].HardId[HW_CUSTOM_ID_B])  & 0xFFFF;
        //  ulBomMagicNum   = (pVerGroup[idx].HardId[BOMID_MAGIC_NUM]) & 0xFFFF;
        //  ulBrdBomidCrc   = (pVerGroup[idx].HardId[BOMID_CRC_DATA])  & 0xFFFF;
        }
    }
    /* BomMagicNum 和 BrdBomidCrc 在函数SetHwInfo16内部实现配置 */
    retVal = SetHwInfo16(ulModuleGroupId, ulBoardGroupId, ulBoardTypeId, ulHwChangeId, ulCustomHwIdA, ulCustomHwIdB);

    return retVal;
}

UINT32 printflash(UINT32 addr, UINT32 num)
{
    UCHAR *pReadbuf = NULL;
    UINT32 ulRetVal = BSP_OK;
    UINT32 cnt = 0;

    if(num > 1024)
    {
        dbgErr("%s max size is limited to 1024\n", __func__);
        num = 1024;
    }

    pReadbuf = (UCHAR*)malloc(num);
    if (NULL == pReadbuf)
    {
        dbgErr("%s malloc error !\n", __func__);
        return BSP_ERROR;
    }

    ulRetVal = BspFlashRead(addr, pReadbuf, num);
    if(BSP_OK != ulRetVal)
    {
        dbgErr("%s BspFlashRead error\n", __func__);
        free(pReadbuf);
        return ulRetVal;
    }

    for (cnt = 0; cnt < num; cnt++)
    {
        if (cnt % 4 == 0)
        {
            dbgInfo("\n0x%08x:", addr);
            addr += 4;
        }
        dbgInfo(" [%02x]", pReadbuf[cnt]);
    }

    dbgInfo("\n");
    free(pReadbuf);
        
    return ulRetVal;
}

UINT32 writeflash(UINT32 addr, UCHAR data)
{
    UINT32 ulRetVal = BSP_OK;
    ulRetVal = BspFlashWrite(addr, &data, 1);
    if(BSP_OK != ulRetVal)
    {
        dbgErr("%s addr=0x%08x, data=0x%02x BspFlashWrite error\n", 
            __func__, addr, data);
    }
    return ulRetVal;
}

#ifdef USE_SOCCMD_MASTER
/*****************************************************************************
 *  函数名称   : BspSocCmd(*)
 *  功能描述   : 执行主上进行从命令的发送
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   : RRU公共接口函数
 *  工装使用申明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 190699@2017-2-27, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSocCmd(UINT8 chan,CHAR *cmd, UINT32* outPut)
{
    UINT8  ucSlaverId = 100;
    UINT8  ucMasterId = 2;
    UINT32 ulRet = 0;
    UINT32 loop = 0;

    T_CmdParam msgbody = {0};
    T_MsgSocCommandAck msgAck = {0};

    ucMasterId = chan + 2;
    INPUT_POINTER_CHECK(cmd);
    if(0 == strlen(cmd))
    {
        dbgErr("%s command is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }

    memcpy(msgbody.ucCmd,cmd,min(strlen(cmd),CMD_LENTH));
    msgbody.ulmask = htonl(CMD_FUNC);
    //dbgInfo("[%s]cmdMask=0x%x,cmd=%s\n",__FUNCTION__,msgbody.ulmask,msgbody.ucCmd);
    ulRet = SocMsgCmd(HEAD_TYPE_ID_NXP_SOC, ucSlaverId, ucMasterId,
        (unsigned char *)&msgAck,sizeof(T_MsgSocCommandAck),
        (unsigned char *)&msgbody,sizeof(T_CmdParam));

    RedirPrintf("[%s])(%d) Ret = 0x%x\n", __FUNCTION__, __LINE__,ulRet);  //todo ex
    BspParseCmdResult(ntohl(msgAck.cmdErrReason));
    if ( UDP_SHELL_COMMD_SUCCESS == ntohl(msgAck.cmdErrReason))
    {
        msgAck.cmdOutInfo[CMD_STDIO_INFO_LENTH] = 0;
        msgAck.cmdOutInfo[CMD_STDIO_INFO_LENTH] = 0;

        RedirPrintf("soc[%d] %s\n",chan,msgAck.ucCmd);
        RedirPrintf("soc[%d] out info:\n",chan);
        RedirPrintf("%s\n",msgAck.cmdOutInfo);
        RedirPrintf("soc[%d] return value = %d\n",chan,ntohl(msgAck.cmdRet));
    	for(loop = 0; loop < 10; loop++)
    	{
           *(outPut+loop) = ntohl(msgAck.ulFuncParams[loop]);
    	}
    	ulRet = BSP_OK;
    }
    else
    {
        ulRet = BSP_ERROR;
        RedirPrintf("[%s])(%d) Ret = 0x%x\n", __FUNCTION__, __LINE__,ulRet);
    }

    return ulRet; //return BSP_OK;
}

UINT32 soccmd(UINT8 *cmd,UINT32 startPuId,UINT32 endPuId)
{
    UINT32 puId = startPuId;
    UINT32 puNum = BspGetRpuNum();
    UINT32 output[10] = {0};

    do
    {
        BspSocCmd((UINT8)puId,(CHAR *)cmd, output);
        puId++;
    } while (puId <= endPuId && puId < puNum);
    return BSP_OK;
}

#endif

UINT32 BspIfSocNsbtFine(UINT8 socId, const CHAR *cmd)
{
    UINT8  ucSlaverId = 100;
    UINT8  ucMasterId = 2;
    UINT32 ulRet = 0;
    // CHAR *cmd   = "BspGetNsbtFine";

    T_CmdParam msgbody = {0};
    T_MsgSocCommandAck msgAck = {0};

    ucMasterId = socId + 2;
    INPUT_POINTER_CHECK(cmd);
    if(0 == strlen(cmd))
    {
        dbgErr("%s command is NULL\n",__FUNCTION__);
        return BSP_ERROR;
    }

    memcpy(msgbody.ucCmd,cmd,min(strlen(cmd),CMD_LENTH));
    msgbody.ulmask = htonl(CMD_FUNC);
    //dbgInfo("[%s]cmdMask=0x%x,cmd=%s\n",__FUNCTION__,msgbody.ulmask,msgbody.ucCmd);
    ulRet = SocMsgCmd(HEAD_TYPE_ID_NXP_SOC, ucSlaverId, ucMasterId,
        (UINT8 *)&msgAck,sizeof(T_MsgSocCommandAck),
        (UINT8*)&msgbody,sizeof(T_CmdParam));

    dbgInfoEx("[%s])(%d) Ret = 0x%x\n", __FUNCTION__, __LINE__,ulRet);  //todo ex
    BspParseCmdResult(ntohl(msgAck.cmdErrReason));
    if ( UDP_SHELL_COMMD_SUCCESS == ntohl(msgAck.cmdErrReason))
    {
        msgAck.cmdOutInfo[CMD_STDIO_INFO_LENTH] = 0;
        msgAck.cmdOutInfo[CMD_STDIO_INFO_LENTH] = 0;

        dbgInfoEx("soc[%d] %s\n",socId,msgAck.ucCmd);
        dbgInfoEx("soc[%d] out info:\n",socId);
        dbgInfoEx("%s\n",msgAck.cmdOutInfo);
        dbgInfoEx("soc[%d] return value = %d\n",socId,ntohl(msgAck.cmdRet));
    	ulRet = msgAck.cmdRet;
    }
    else
    {
        ulRet = BSP_ERROR;
        dbgErr("[%s])(%d) Ret = 0x%x\n", __FUNCTION__, __LINE__,ulRet);
    }

    return ulRet; //return BSP_OK;
}

static UINT32 BspGetTrxChipIdAndChanNo(UINT32 dir, UINT32 rfChan, UINT32 *chipId, UINT32 *chanNo)
{
    TRruDeviceDescription *pDev = NULL;
    eDeviceType deviceType = DEVICE_TYPE_TRANSCEIVER;
    INPUT_POINTER_CHECK(chipId);
    INPUT_POINTER_CHECK(chanNo);

    if (BSP_OK == BspChipInfoPtrGetByRfPathDef(rfChan, dir, deviceType, &pDev))
    {
        *chipId = pDev->ulDeviceIndex;
        *chanNo = pDev->ulDeviceInterIndex;
        return BSP_OK;
    }
    return BSP_ERROR;
}

UINT32 showchanmap(VOID)
{
	UINT32 retVal = BSP_OK;
	T_RU_LINK_MAP *pLinkMap = NULL;
	UINT32 LinkMapNum = 0;
    UINT32 loop          = 0;
    UINT32 trxId         = 0;
    UINT32 trxChan       = 0;
    UINT32 dir = TX;
    
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_LINK_INFO_INIT,0,0,pLinkMap,LinkMapNum);

    for (loop = 0; loop < LinkMapNum; loop++)
    {
        if(pLinkMap[loop].linkInfo[LINK_INFO_LINKTYPE] != dir)
        {
            continue;
        }
        BspGetTrxChipIdAndChanNo(dir,pLinkMap[loop].linkInfo[LINK_INFO_BSPCHN],&trxId, &trxChan);
        dbgInfo("LinkId=%2d dir:%s Bsp=%2d Chip=%2d Dif=%2d Ant=%2d TrxChipID=%2d TrxChan=%2d\n", loop, ((dir==TX)?"TX":"RX"),
                pLinkMap[loop].linkInfo[LINK_INFO_BSPCHN],
                pLinkMap[loop].linkInfo[LINK_INFO_DIFCHIPID],
                pLinkMap[loop].linkInfo[LINK_INFO_DIFCHN],
                pLinkMap[loop].linkInfo[LINK_INFO_ANTID],
                trxId,trxChan);
    }
    return BSP_OK;    
}

UINT32 boardhelp(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    dbgInfo("Board Help:\n");

    udPrintCnt = sizeof(g_BoardHelpPrint) / BOARD_HELP_CMD_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        dbgInfo(" %s \n", g_BoardHelpPrint[udCnt]);
    }

    return (UINT32)BSP_OK;
}

UINT32 IcTemp(void)
{
    INT32 temp0 = 0;
    INT32 temp1 = 0;
    UINT32 ret = 0;

    ret = BspHalAdaptGetIcCalibrationTemp(&temp0, &temp1);
    dbgInfo("Temp0 %.2lf degree, Temp1 %.2lf degree\n", temp0 / 100.0, temp1 / 100.0);

    return ret;
}

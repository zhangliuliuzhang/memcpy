/*****************************************************************************
* 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : hardfeaturewrapper.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板初始化函数适配单板模型的封装实现
* 注意事项 : 无
* 作    者 : 王涛
* 创建日期 : 2022-03-26 10:26:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛
* 修改日戳: 2022-03-26 10:26:34
* 变更说明: 创建
*

*-------------------------------------------
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcommon.h"
#include "boardmodle_ic4_2.h"
#include "hardfeaturewrapperrfctrl.h"
#include "rruinfo.h"
#include "i2cbusapi.h"
#include "board_ic4_2.h"
#include "regdrv_pincfg.h"
#include "spiapi.h"
#include "zx211413spi.h"
#include "rftableinit.h"
#include "rftable.h"
#include "devbus_spibus.h"
#include "devbus_i2cbus.h"
#include "boardsochwdiffcfg.h"
#include "devdrv_spiadpter.h"
#include "gainctrl_ic4_2.h"
#include "uart_ic4_2.h"
#include "pa_ic4_2_ctrl.h"
#include "pa_ic4_2_calcpara.h"
#include "powerctrl_ic4_2.h"
#include "powerctrl_comps_ic4_2.h"
#include "antcalcommon.h"
#include "pwr_a.h"
#include "boardpapt.h"
#include "devdrv_att.h"
#include "devdrv_tempsensor.h"
#include "boardsocmsg.h"
#include "freqcfg_ic4_2.h"
#include "optadpt.h"
#include "dpd_app.h"
#include "funccommonapi.h"
#include "papt_common.h"
#include "ipccommon.h"
#include "uart_ic4_2_aisg.h"
#include "boardntl_ic4_2.h"
#ifndef  MULT_PROGRESS_S
#include "rruabilitycommon.h"
#endif
#define HARD_FEATURE_DATA_FILE_NAME       "HardFeatureData.json"
#define FLASH_ANTI_TAMPER_OFFSET_NOR_NAND   (FLASH_BOMID_OFFSET + (UINT32)0x90)
#define FLASH_ANTI_TAMPER_OFFSET_NOR        (FLASH_BSP_PART_OFFSET_NOR + (UINT32)0x90)


FUNC_POST_INIT_RFTBL pPostRfTblInit = NULL;
/*****************************************************************************
                                  函数声明
*****************************************************************************/
extern UINT32 Zx211413SetFpgaRwExProtectBitNum(UINT32 BitNum);


/*****************************************************************************
                                  全局变量
*****************************************************************************/


pDPDPowerChange pGetDPDChangeCall = NULL;
pPaVoltUpdateFunc pPaVoltUpdateCall = NULL;
UINT32 ulHardFeatureWapperRfCtrlNcrFlag = 0;
/*****************************************************************************
                                    内部接口
*****************************************************************************/
static UINT32 BspSetModifyDrvTbl(_T_Reg_Drv_Tbl *p_tDrvTbl, UINT32 uDrvTblNum, _T_Dev_Reg_Tbl_Modify *pModRegTbl, UINT32 ulSz)
{
    UINT32 ulIdx = 0;
    UINT32 ulPos = 0;

    for(ulIdx = 0; ulIdx < ulSz; ulIdx ++)
    {
        ulPos = pModRegTbl[ulIdx].modiIdx;
        if (ulPos < uDrvTblNum)
        {
            p_tDrvTbl[ulPos].chipIdx = pModRegTbl[ulIdx].chipIdx;
            p_tDrvTbl[ulPos].regType = pModRegTbl[ulIdx].regType;
            p_tDrvTbl[ulPos].regAddr = pModRegTbl[ulIdx].regAddr;
            p_tDrvTbl[ulPos].bitNum  = pModRegTbl[ulIdx].bitNum;
            p_tDrvTbl[ulPos].defVal  = pModRegTbl[ulIdx].defVal;
        }
    }
    return BSP_OK;
}

/*****************************************************************************
                                  外部接口
*****************************************************************************/
/*****************************************************************************
*  函数名称   : BspBoardLinkInfoInit
*  功能描述   : 单板丝印初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardLinkInfoInit(VOID)
{
	UINT32 retVal = BSP_OK;
	T_RU_LINK_MAP *pLinkMap = NULL;
	UINT32 LinkMapNum = 0;
   
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_LINK_INFO_INIT,0,0,pLinkMap,LinkMapNum);
    retVal = BspChanLinkInfoInit(pLinkMap, LinkMapNum);
    CHECK_RETVAL(BspChanLinkInfoInit, retVal);
 
	return retVal;
}
/* Started by AICoder, pid:bc51fn460153823140f30ad5a0d001207fd1b320 */
/**************************************************************************
 * 函数名称: BspBoardFwdLinkInfoInit
 * 功能描述: 初始化射频通道号全链路方向
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2024年06月20日    陈显宝    创建
 **************************************************************************/
UINT32 BspBoardFwdLinkInfoInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 LinkMapNum = 0;
    T_RU_LINK_MAP_APP_CFG *pLinkMap = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_FWD_LINK_INFO_INIT,0,0,pLinkMap,LinkMapNum);

    retVal = BspFwdLinkInfoInit(pLinkMap, LinkMapNum);
    CHECK_RETVAL(BspFwdLinkInfoInit, retVal);

    return retVal;
}
/* Ended by AICoder, pid:bc51fn460153823140f30ad5a0d001207fd1b320 */

/*****************************************************************************
*  函数名称   : BspSetHardFeatureCallback
*  功能描述   : 注册和丝印关系相关的回调接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetHardFeatureCallback(VOID)
{
    BspGetDflInfoFuncResister((VOID *)BspGetDflInfoByRfChn);
    BspGetAntInfoFuncResister((VOID *)BspGetAntInfoByRfChn);

    return BSP_OK;
}

/* Started by AICoder, pid:xfa31o4810cba0f143360901e0ab8d201693ae03 */
/**
 * 函数名称: BspSetHardFeatureWapperRfCtrlNcrFlag
 * 功能描述: ulHardFeatureWapperRfCtrlNcrFlag
 * 输入参数: ulflag - 设置的值
 * 输出参数: 无
 * 返 回 值: 无
*/
VOID BspSetHardFeatureWapperRfCtrlNcrFlag(UINT32 ulflag)
{
    ulHardFeatureWapperRfCtrlNcrFlag = ulflag;
}

/**
 * 函数名称: BspGetHardFeatureWapperRfCtrlNcrFlag
 * 功能描述: 获取ulPaptNcrFlag的值
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: ulHardFeatureWapperRfCtrlNcrFlag
*/
UINT32 BspGetHardFeatureWapperRfCtrlNcrFlag(VOID)
{
    return ulHardFeatureWapperRfCtrlNcrFlag;
}
/* Ended by AICoder, pid:xfa31o4810cba0f143360901e0ab8d201693ae03 */

UINT32 BspCrmProcLockInit(VOID)
{
    IPC_SHM_INFO info = {0};
    info.shmKey = CRM_SHM_KEY;

    return BspShmInit(&info);
}

/*****************************************************************************
*  函数名称   : BspInitI2c
*  功能描述   : I2C总线参数初始化
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitI2c(void)
{
    UINT32 retVal            = BSP_OK;
    T_I2C_BUS_DRV *pParaInfo = NULL;
    UINT32        *pParaList = NULL;
    UINT32 infoNum           = 0;
    UINT32 listNum           = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_IIC_BUS, 0, 0, pParaInfo, infoNum);
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_IIC_BUS, 0, 1, pParaList, listNum);

    retVal |= BspCrmProcLockInit();
    retVal |= BspSetIICBusInfo(pParaInfo, pParaList, listNum);
    retVal |= BspIICBusInit();

    return retVal;
}

/**************************************************************************
 * 函数名称: BspDrvTblInit(*)
 * 功能描述: 通用寄存器表初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10090699    创建
 **************************************************************************/
UINT32 BspDrvTblInit(VOID)
{
    UINT32 retVal = BSP_OK;
    _T_Reg_Drv_Tbl *pDrvTbl = NULL;
    UINT32 drvTblNum = 0;
    _T_Dev_Reg_Tbl_Modify *pModDrvTbl = NULL;
    UINT32 modDrvTblNum = 0;
    
    /* drvtbl 初始化 */
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_DRV_TBL,0,0,pDrvTbl,drvTblNum);
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_DRV_TBL,0,1,pModDrvTbl,modDrvTblNum);
    retVal = BspSetModifyDrvTbl(pDrvTbl, drvTblNum, pModDrvTbl, modDrvTblNum);
    retVal |= BspSetRegDrvData(pDrvTbl, drvTblNum);

    return retVal;
}

UINT32 BspInitSpi(void)
{
    UINT32 retVal            = BSP_OK;
    T_SPI_DRV     *pParaInfo = NULL;
    UINT32        *pParaList = NULL;
    UINT32 infoNum           = 0;
    UINT32 listNum           = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_SPI_BUS, 0, 0, pParaInfo, infoNum);
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_SPI_BUS, 0, 1, pParaList, listNum);

    retVal |= Zx211413SetFpgaRwExProtectBitNum(8); /*跟逻辑平台约定4.2所有的逻辑寄存器访问都有8bit间隔保护*/
    retVal |= BspSetSpiBusInfo(pParaInfo, pParaList, listNum);
    retVal |= BspSetZteSpiCs(BspZx211413SpiSetCs);
    retVal |= BspSpiBusInit();
    return retVal;
}

UINT32 BspUpdateRfTblInfo(T_CaliTblInfoUpdate *pPara, UINT32 num)
{
    UINT32 loop = 0;

    if (pPara == NULL)
    {
        return BSP_OK;
    }

    for(loop = 0; loop < num; loop ++)
    {
        BspUpdateCaliTblInfo(pPara[loop].fileType, pPara[loop].pFuncRfTableInit0, pPara[loop].pFuncRfTableInit1,
                     pPara[loop].pFuncRfTableDataBuf0, pPara[loop].pFuncRfTableDataBuf1);
    }

    return BSP_OK;
}
/*高层检查回读接口报错 也报0给BBU  */
/* Started by AICoder, pid:23aa3j0690bdab614f3709d270ed742095377236 */
void BspSetRuPaBaseInfoByRfTbl(void)
{
#ifdef  MULT_PROGRESS_S    /*单片和主片主MGR需要*/
    return;
#else
    UINT32 loop = 0;
    UINT32 effVal = 0;
    UINT32 chanNum = 0;
    UINT8 isSn20  = 0;
    T_BspFuRuPaBaseInfo tmpInfo = {0};
    chanNum = BspGetTxChannel();

    for(loop = 0; loop < chanNum; loop++)
    {
        effVal = 0xf;
        BspGetPaEfficientVal(loop, &effVal);   /*遍历通道所以不加通道号转换了 校准表异常报0  如果部分通道正常 部分通道通道异常 按正常通道报*/
        if(2 == effVal)/*只要有一个是2 就报1 其他都是0*/
        {
            isSn20 = 1;
        }
    }
    tmpInfo.isSn20 = isSn20;    /*后续预留字段使用时在此扩展*/
    dbgInfoEx("isSn20 %d\n",isSn20);
    BspSetRuPaBaseInfo(&tmpInfo);
    return ;
#endif
}
/* Ended by AICoder, pid:23aa3j0690bdab614f3709d270ed742095377236 */
/**************************************************************************
 * 函数名称: BspRfTblInit(*)
 * 功能描述: 离线参数表加载
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspRfTblInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    retVal = BspBoardModleGetData(E_HARD_FEATURE_CALI_FILE, 0, 3, (VOID**)(&pPara), &(num));
    retVal |= BspUpdateRfTblInfo((T_CaliTblInfoUpdate*)pPara, num);
    retVal |= BspBoardModleGetData(E_HARD_FEATURE_CALI_FILE,0,1,(VOID**)(&pPara), &(num));
    retVal |= BspSetRfConvertTbl((T_RfTblConvert*)pPara, num);
    retVal |= BspBoardModleGetData(E_HARD_FEATURE_CALI_FILE,0,2,(VOID**)(&pPara), &(num));
    retVal |= BspSetRfChipMapTbl((T_RfTblChipMap*)pPara, num);
    retVal |= BspBoardModleGetData(E_HARD_FEATURE_CALI_FILE,0,0,(VOID**)(&pPara), &(num));
    retVal |= BspRfTblLoad((T_RfTblFileMenu*)pPara, num);
    BspSetRuPaBaseInfoByRfTbl();
    return retVal;
}

/**************************************************************************
 * 函数名称: BspRfTblInit(*)
 * 功能描述: 离线参数表加载
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspRfTblGainModify(VOID)
{
    UINT32 retVal = BSP_OK;
    INT32 *pParaRfGain= NULL;
    INT32 *pParaRadioGain= NULL;
    UINT32 chanloop = 0;
    UINT32 caliChn = 0;
    UINT32 typeloop = 0;
    UINT32 caliType[5] = {TX, RX, RX, TX, TX};
    UINT32 num[2] = {0};

    /*如果是工装环境，不需要校准*/
#ifdef _BSP_WITH_WFS
    return BSP_OK;
#endif

    retVal |= BspBoardModleGetData(E_HARD_FEATURE_CALI_GAIN_MODIFY, 0, 0, (VOID**)(&pParaRfGain), &num[0]);
    retVal |= BspBoardModleGetData(E_HARD_FEATURE_CALI_GAIN_MODIFY, 0, 1, (VOID**)(&pParaRadioGain), &num[1]);
    dbgInfo("%s num0 %d,num1 %d\n", __FUNCTION__, num[0], num[1]);

    for(chanloop = 0; chanloop < num[0]; chanloop++)
    {
        for(typeloop=0; typeloop < TBL_TYPE_NUM; typeloop++)
        {
            retVal = BspGetCaliChnByBspChn(chanloop, caliType[typeloop], &caliChn);
            if(retVal == BSP_ERROR)
            {
                continue;
            }
            retVal = BspSetCaliModefyGain(caliChn, typeloop, *(pParaRfGain + chanloop*TBL_TYPE_NUM + typeloop));
        }
    }
    retVal |= BspSetRadioGain(pParaRadioGain);

    return retVal;
}

UINT32 BspRfTblPostInitCallBack(FUNC_POST_INIT_RFTBL func)
{
    pPostRfTblInit = func;
    return BSP_OK;
}

UINT32 BspRfTblPostInit(VOID)
{
    UINT32 retVal = BSP_OK;
    if (NULL != pPostRfTblInit)
    {
        retVal = pPostRfTblInit();
    }
    return retVal;
}

/**************************************************************************
 * 函数名称: BspPreInitSocHwCfg(*)
 * 功能描述: 多片SOC硬件配置差异初始化
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10090699    创建
**************************************************************************/
UINT32 BspPreInitSocHwCfg(VOID)
{
    UINT32 retVal = BSP_OK;
    T_BoardSocHwDiffCfg *pSocDiffCfg = NULL;
    UINT32 num = 0;    
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_SOC_DIFF_INIT,0,0,pSocDiffCfg,num);
    BspSetBoardSocHwDiffType(pSocDiffCfg->boardSocType, pSocDiffCfg->maxOffset);       
    retVal = BspSetSocHwCfg(BspSetDiffSocCfg);

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspTftpRfTblGet(*)
 *  功能描述   : 用于“主→从”下载eeprom，并触发加载
 *  输入参数   : index--功放序号
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *  其它说明   : RRU内部接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wzy@2017-5-27, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspTftpRfTblGetInit(VOID)
{
    UINT32 size,retry;
    UINT32 retVal = 0;
    UINT32 RfTblNum = 0;
    VOID *pPara = NULL;
    UINT32 num = 0;
    struct stat fileStat = {0};
    CHAR TftpCmd[100]={0};
    CHAR Path[]= RFTBL_DIR_IN_DDR;
    const CHAR *Local  = NULL;
    const CHAR *Remote = NULL;
    CHAR LocalFilePath[100]={0};
    CHAR RemoteFilePath[100]={0};
    CHAR ip[]="198.33.33.100";
    INT32 snpRet = 0;
    UINT32 subFileNum = 0;
    UINT32 fileIdx = 0;
    const CHAR *pBuf = NULL;
    UINT8 aucTmpName[128] = {0};
    T_RfTblFileMenu sRfTblFileMenu[NUM_TBL_KIND_NUM] = {0};

    snpRet = snprintf_s(TftpCmd,sizeof(TftpCmd),"mkdir -p %s",Path);
    SNPRINTF_S_CHECK(snpRet, sizeof(TftpCmd));
    BspSystem(TftpCmd);

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_CALI_FILE,0,0,pPara,num);

    memcpy_s(&sRfTblFileMenu, sizeof(T_RfTblFileMenu)*num, (T_RfTblFileMenu*)pPara, sizeof(T_RfTblFileMenu)*num);


    for(RfTblNum=0;RfTblNum < (num+1);RfTblNum++)
    {
        if(RfTblNum == num)
        {
            Local = "/tmp/cali/RruInfo.txt";
            Remote = "/ata/cali/RruInfo.txt";
            subFileNum = 1;
        }
        else
        {
            Local = sRfTblFileMenu[RfTblNum].pFsFile;
            Remote = sRfTblFileMenu[RfTblNum].pAtaFile;
            subFileNum = sRfTblFileMenu[RfTblNum].ulSubFileNum;
        }

        dbgInfoEx("%s>> ... subFileNum:%d LocalFilePath:%s RemoteFilePath:%s\r\n",__func__,subFileNum,Local,Remote);
        for (fileIdx = 0; fileIdx < subFileNum; fileIdx++)
        {
            if (subFileNum > 1)
            {
                pBuf = strstr(Local, ".txt");
                INPUT_POINTER_CHECK(pBuf);
                //coverity[cert_str30_c_violation:SUPPRESS]
                memcpy_s(aucTmpName, sizeof(aucTmpName), Local, (uintptr_t)pBuf-(uintptr_t)Local);
                snpRet = snprintf_s(LocalFilePath,sizeof(LocalFilePath),"%s%d%s",aucTmpName,fileIdx,".txt");
                SNPRINTF_S_CHECK(snpRet, sizeof(LocalFilePath));
                memset_s(aucTmpName, sizeof(aucTmpName), 0, sizeof(aucTmpName));

                pBuf = strstr(Remote, ".txt");
                INPUT_POINTER_CHECK(pBuf);
                //coverity[cert_str30_c_violation:SUPPRESS]
                memcpy_s(aucTmpName, sizeof(aucTmpName), Remote, (uintptr_t)pBuf-(uintptr_t)Remote);
                snpRet = snprintf_s(RemoteFilePath,sizeof(RemoteFilePath),"%s%s%d%s","..",aucTmpName,fileIdx,".txt");
                SNPRINTF_S_CHECK(snpRet, sizeof(RemoteFilePath));
                memset_s(aucTmpName, sizeof(aucTmpName), 0, sizeof(aucTmpName));
                dbgInfoEx("%s>> Mutil Files rename... subFileNum:%d LocalFilePath:%s RemoteFilePath:%s\r\n",__func__,subFileNum,LocalFilePath,RemoteFilePath);
            }
            else
            {
                /*temp/cali下面有从内存取，如果没有从ata/cali flash取,如果都没有则跳过*/
                snpRet = snprintf_s(LocalFilePath,sizeof(LocalFilePath),"%s",Local);
                SNPRINTF_S_CHECK(snpRet, sizeof(LocalFilePath));
                snpRet = snprintf_s(RemoteFilePath,sizeof(RemoteFilePath),"%s%s","..",Remote);
                SNPRINTF_S_CHECK(snpRet, sizeof(RemoteFilePath));
            }

            for (retry = 0; retry < 3; retry++)
            {
                snpRet = snprintf_s(TftpCmd,sizeof(TftpCmd),"tftp -gr %s -l %s %s",&LocalFilePath[5],LocalFilePath,ip);
                SNPRINTF_S_CHECK(snpRet, sizeof(TftpCmd));
                dbgInfo("%s: %s from %s \n",__FUNCTION__,&LocalFilePath[5],LocalFilePath);
                BspSystem(TftpCmd);
                BspSysMsDelay(100);
                dbgInfo("%s[GET]: %s ( try %d times )\n",__FUNCTION__,LocalFilePath,retry);
                if (stat(LocalFilePath,&fileStat)==0 && (size=fileStat.st_size) > 0)
                {
                    dbgInfo("%s: Get %s(%d bytes) from %s succ.\n",__FUNCTION__,LocalFilePath,size,ip);
                    break;
                }
            }
            if(3 == retry)
            {
                snpRet = snprintf_s(TftpCmd,sizeof(TftpCmd),"tftp -gr %s -l %s %s",RemoteFilePath,LocalFilePath,ip);
                SNPRINTF_S_CHECK(snpRet, sizeof(TftpCmd));
                dbgInfo("%s: %s from %s \n",__FUNCTION__,LocalFilePath,RemoteFilePath);
                for (retry = 0; retry < 3; retry++)
                {
                    BspSystem(TftpCmd);
                    BspSysMsDelay(100);
                    dbgInfo("%s[GET]: %s ( try %d times )\n",__FUNCTION__,LocalFilePath,retry);
                    if (stat(LocalFilePath,&fileStat)==0 && (size=fileStat.st_size) > 0)
                    {
                        dbgInfo("%s: Get %s(%d bytes) from %s succ.\n",__FUNCTION__,LocalFilePath,size,ip);
                        break;
                    }
                }
            }
        }
    }
    return retVal;
}

/**************************************************************************
 * 函数名称: BspUartCfgDataInit(*)
 * 功能描述: UART映射初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspUartCfgDataInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_UART_SEL_INIT,0,0,pPara,num);

    retVal = BspUartMapCfg((T_UartMapInfo*)pPara, num);
    return retVal;
}

/**************************************************************************
 * 函数名称: BspNsbtMapInit(*)
 * 功能描述: Nsbt映射初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspNsbtMapInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_NSBT_MAP_INIT,0,0,pPara,num);
    retVal = BspNsbtMapCfg((T_AntInterfacePwrMap*)pPara, num);

    //retVal |= BspInitAntInterFaceHardAblity();

    return retVal;
}
/*****************************************************************************
*  函数名称   : BspBoardTddIoLinkInfoInit
*  功能描述   : 单板tddio丝印初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspBoardTddIoLinkInfoInit(VOID)
{
	UINT32 retVal = BSP_OK;
	VOID *pTddIoLinkMap = NULL;
	VOID *pTddIoToRfLinkMap = NULL;
	UINT32 LinkMapNum = 0;
	UINT32 TddIoToRfLinkMapNum = 0;
    UINT32 paraNum = 0;
    T_TDDIO_FDDAC_BASE_PARA *pTddIoPara = NULL;
    UINT32 paraNumEx = 0;
    T_TDDIO_AC_SWITCH_PARA *pTddIoParaEx = NULL;

	BOARD_MODLE_GET_DATA(E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,0,0,pTddIoLinkMap,LinkMapNum);
	BOARD_MODLE_GET_DATA(E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,0,1,pTddIoToRfLinkMap,TddIoToRfLinkMapNum);
    
	retVal = BspChanLinkInfoInitTddIo((T_RU_LINK_MAP_TDDIO *)pTddIoLinkMap, LinkMapNum);
	retVal |= BspChanLinkInfoInitTddIoToRf((T_RU_LINK_MAP_TDDIO_TO_RF *)pTddIoToRfLinkMap, TddIoToRfLinkMapNum);
	CHECK_RETVAL(BspBoardTddIoLinkInfoInit, retVal);

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_AC_TDDIO_PARA_INIT,0,0,pTddIoPara,paraNum);
    BspInitFddAcCtrlPara(pTddIoPara,paraNum);
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_AC_TDDIO_PARA_INIT,0,1,pTddIoParaEx,paraNumEx);
    BspInitAcCtrlSwitchPara(pTddIoParaEx,paraNumEx);

	return retVal;
}

/**************************************************************************
 * 函数名称: BspTddIoParaInit(*)
 * 功能描述: 上电初始化调用，射频开关参数初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月27日 10229672    创建
 **************************************************************************/
UINT32 BspTddIoCtrlInit(VOID)
{
    UINT32 retVal = BSP_OK;
    VOID *pTddIoConctrlPara = NULL;
    VOID *pTddIoBaseDlyPara = NULL;
    VOID *pTddIoExcept = NULL;
    UINT32 num = 0;
    T_AntCalInterface acInterFace;
    
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_TDDIO_CTRL_INIT, 0, 0, pTddIoConctrlPara, num);
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_TDDIO_CTRL_INIT, 0, 1, pTddIoBaseDlyPara, num);
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_TDDIO_CTRL_INIT, 0, 2, pTddIoExcept, num);

    acInterFace.pFuncGetModeVal = BspGetRadioModeValue;
    acInterFace.pFuncGetdGp2Ac = GetdGp2Ac;
    acInterFace.pFuncGetdGp2AcEnd = GetdGp2AcEnd;

    (VOID)BspPaCtrlAcCallBackFuncInit(&acInterFace);
    (VOID)BspInitTddIoConctrlPara((T_TDDIO_CONCTRL_PARA *)pTddIoConctrlPara);
    retVal = BspBoardTddIoInfoInit((T_TDD_IO_BASE_PARA_INFO*)pTddIoBaseDlyPara);
    retVal |= BspTddIoExceptCtrl((T_TDDIO_EXCEPT_CTRL*)pTddIoExcept);  /*预留单板与平台设计不一致的异常电平，比如高低电平*/
    retVal |= BspTddIoParaInit();
    retVal |= BspSetTddIoAcCtrlSwitch(E_AC_TYPE_FDD);
    CHECK_RETVAL_PRN(BspTddIoCtrlInit, retVal);

    return BSP_OK;
}

UINT32 BspInitTempUpdateThread(void)
{
#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    BspLog(LOG_LEVEL_0, "%s: Don't start update temp thread\n", __FUNCTION__);
    return BSP_OK;
#else
    BspGetCalibTblCompsTemp();
    BspInitTempSourcePara(TEMP_SOURCE_BSP_CACHE, TEMP_SOURCE_BSP_CACHE);
    BspCalibTblCompsThreadInit();
    BspLog(LOG_LEVEL_0, "%s: Start update temp thread\n", __FUNCTION__);
    return BSP_OK;
#endif
}

UINT32 BspInitPowerStatusThread(void)
{
#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    BspLog(LOG_LEVEL_0, "%s: Don't start update power status thread\n", __FUNCTION__);
    return BSP_OK;
#else
    BspEnableRdPwrInfoByCache();
    BspPowerStatusThreadInit();
    BspLog(LOG_LEVEL_0, "%s: Start update power status thread\n", __FUNCTION__);
    return BSP_OK;
#endif
}

UINT32 BspInitOptStatusThread(VOID)
{
    UINT32 retVal = BSP_OK;

#if (defined (BSP_MAKE_VER) || defined (_BSP_WITH_WFS))
    BspLog(LOG_LEVEL_0, "%s: Don't start update opt status thread\n", __FUNCTION__);
    return BSP_OK;
#else
    retVal = BspInitOptInfoStatusThread();
    BspLog(LOG_LEVEL_0, "%s: Start update opt status thread\n", __FUNCTION__);
#endif
    return retVal;

}

UINT32 BspCommonThreadInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspInitTempUpdateThread();
    retVal |= BspInitPowerStatusThread();
    retVal |= BspInitOptStatusThread();

    return BSP_OK;
}

UINT32 BspAntPowerInit(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulAnt = 0;
    UINT32 *ulAntPower = NULL;
    UINT32 num = 0;
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_ANTPOWER_INIT, 0, 0, ulAntPower, num);

    for(ulAnt=0; ulAnt<num; ulAnt++)
    {
        BspSetRruAntRatedPowerFlag(ulAnt,1);
        BspSetRruAntRatedPower(ulAnt, ulAntPower[ulAnt]);
    }
    return BSP_OK;
}


static void DpdSample2AvgPow(UINT32 dpdSample, UINT32 *avgPowNum)
{
    UINT32 i = 0;
    UINT32 sampleArr[] = {983040, 737280, 491520, 368640, 245760};
    UINT32 avgPowArr[] = {32767, 16383, 16383, 8191, 8191};

    for (i = 0; i < NELEMENTS(sampleArr); i++)
    {
        if (sampleArr[i] == dpdSample)
        {
            break;
        }
    }

    if (i == NELEMENTS(sampleArr))
    {
        return;
    }

    if (avgPowNum)
    {
        *avgPowNum = avgPowArr[i];
    }
}

static void CfrSample2PowNum(UINT32 type, UINT32 cfrSample, UINT32 *avgPowNum)
{
    UINT32 i = 0;
    UINT32 sampleArr[] = {491520, 368640, 245760, 122880};
    UINT32 avgPowLArr[] = {16383, 8191, 8191, 4095};
    UINT32 avgPowSArr[] = {4095, 8191, 2047, 1023};

    for (i = 0; i < NELEMENTS(sampleArr); i++)
    {
        if (sampleArr[i] == cfrSample)
        {
            break;
        }
    }

    if (i == NELEMENTS(sampleArr))
    {
        return;
    }

    if (avgPowNum)
    {
        if (type == 0)
        {
            *avgPowNum = avgPowLArr[i];
        }
        else
        {
            *avgPowNum = avgPowSArr[i];
        }
    }
}

UINT32 BspUpdatePaptPara(UINT32 difChan, T_BspHalAdaptPaptParaCfg *paptPara)
{
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;
    INT32 dpdPowCalc = 0;
    INT32 PowThrChange = 0;
    T_BspHalAdaptDifSamRatePara *pSamRatePara = NULL;
    T_GainCommPara *pGainCommPara = NULL;
    T_DlPowCalcPara *pPowCalcPara = NULL;

    BOARD_MODLE_GET_DATA(E_FUNCTION_TRX_DIG_GAIN_INIT, 0, 0, pGainCommPara, num);
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_SAMRATE, 0, 0, pSamRatePara, num);
    BOARD_MODLE_GET_DATA(E_FUNCTION_DL_POWCALC_PARA_INIT, 0, 0, pPowCalcPara, num);

    if (difChan < NELEMENTS(pSamRatePara->uiDpdSamRate))
    {
        DpdSample2AvgPow(pSamRatePara->uiDpdSamRate[difChan], &paptPara->paptDpd.avgPowNum);
    }

    if (difChan < NELEMENTS(pSamRatePara->uiCfrSamRate))
    {
        CfrSample2PowNum(0, pSamRatePara->uiCfrSamRate[difChan], &paptPara->paptCfr.avgPowNumL);
        CfrSample2PowNum(1, pSamRatePara->uiCfrSamRate[difChan], &paptPara->paptCfr.avgPowNumS);
    }

    if (difChan < NELEMENTS(pGainCommPara->preDpdGain))
    {
        paptPara->paptHpf.hpfPowThr = -1900 + pGainCommPara->preDpdGain[difChan] - 300;
        if(NULL != pGetDPDChangeCall)
        {
            pGetDPDChangeCall(&PowThrChange);
            paptPara->paptHpf.hpfPowThr = -1900 + pGainCommPara->preDpdGain[difChan] - PowThrChange;
        }

        paptPara->paptDpd.avgPowThr = -1900 + pGainCommPara->preDpdGain[difChan] + 250 + 100;
        /* Started by AICoder, pid:jff35c6a65t446a143680ac200a1321edd05aa28 */
        if(1 == BspGetHardFeatureWapperRfCtrlNcrFlag())
        {
            paptPara->paptHpf.hpfPowThr += 500;
            paptPara->paptHpf.hpfPowThr += 500;
            paptPara->paptDpd.avgPowThr += 500;
        }
        /* Ended by AICoder, pid:jff35c6a65t446a143680ac200a1321edd05aa28 */
        dpdPowCalc = pPowCalcPara[difChan].lvVal[1] + pGainCommPara->preCfrGain[difChan] +
                pGainCommPara->preDpdGain[difChan] + pGainCommPara->outDpdGain[difChan];
        if(dpdPowCalc > -1700)
        {
            paptPara->paptRamp.spThr = 0;
        }
        else
        {
            paptPara->paptRamp.spThr = -100;
        }
    }
    return BSP_OK;
}

UINT32 BspUpdateAvgPowInfo(UINT32 difChan, UINT32 updateflag, T_BspHalAdaptPaptCfrCfg *paptCfrPara, T_BspHalAdaptPaptDpdCfg *paptDpdPara)
{
    UINT32 num = 0;
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptDifSamRatePara *pSamRatePara = NULL;
    T_GainCommPara *pGainCommPara = NULL;
    INT32 dpdThr = 0;
    INT32 cfrThr = 0;

    BOARD_MODLE_GET_DATA(E_FUNCTION_TRX_DIG_GAIN_INIT, 0, 0, pGainCommPara, num);
    BOARD_MODLE_GET_DATA(E_TRX_LINK_DPDIC_DIF_SAMRATE, 0, 0, pSamRatePara, num);

    if(difChan < NELEMENTS(pSamRatePara->uiCfrSamRate))
    {
        CfrSample2PowNum(0, pSamRatePara->uiCfrSamRate[difChan], &(paptCfrPara->avgPowNumL));
        CfrSample2PowNum(1, pSamRatePara->uiCfrSamRate[difChan], &(paptCfrPara->avgPowNumS));
    }

    if(difChan < NELEMENTS(pSamRatePara->uiDpdSamRate))
    {
        DpdSample2AvgPow(pSamRatePara->uiDpdSamRate[difChan], &(paptDpdPara->avgPowNum));
    }

    INPUT_PARAM_RANGE_CHECK(difChan, NELEMENTS(pGainCommPara->preDpdGain));
    dpdThr = BspGetDpdAvgThrDelta(difChan);
    cfrThr = BspGetCfrAvgThrDelta(difChan);
    if(1 == updateflag)   //通道配置NB制式的均值门限由+2.5改为+6.5
    {
        paptCfrPara->avgPowThrL = -1650 + 400 + cfrThr;
        paptCfrPara->avgPowThrS = -1250 + 400;
        paptDpdPara->avgPowThr = -1900 + pGainCommPara->preDpdGain[difChan] + 650 + 100 + dpdThr;
    }
    else
    {
        paptCfrPara->avgPowThrL = -1650 + cfrThr;
        paptCfrPara->avgPowThrS = -1250;
        paptDpdPara->avgPowThr = -1900 + pGainCommPara->preDpdGain[difChan] + 250 + 100 + dpdThr;
    }
    /* Started by AICoder, pid:f4b85r9aae4546b140a00a16a00288197307f0e3 */
    if(1 == BspGetHardFeatureWapperRfCtrlNcrFlag())
    {
        paptCfrPara->avgPowThrL += 500;
        paptCfrPara->avgPowThrS += 500;
        paptDpdPara->avgPowThr  += 500;
    }
    /* Ended by AICoder, pid:f4b85r9aae4546b140a00a16a00288197307f0e3 */
    return BSP_OK;
}

UINT32 BspInitPaPtPara(void)
{
    UINT32 retVal = BSP_OK;

    /* 挂接功放保护均值门限更新接口，在配频之后调用 */
    retVal = BspSetUpdatePaptAvgPowInfoCallBack(BspUpdatePaptAvgPowInfo);
    retVal |= BspSetUpdatePaptInfoCallBack(BspUpdatePaptPowInfo);
    retVal |= BspUpdatePaptInitInfo();
    BspSecondaryUpdatePaptInit();

    return retVal;
}

static UINT32 _BspGetSysPllStatus(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 clkStatus[2] = {0xf,0xf};

    retVal = BspHalAdaptGetSysLd(0,&clkStatus[0]);//获取一级锁相环锁定状态
    retVal |= BspHalAdaptGetSysLd(1,&clkStatus[1]);//获取二级锁相环锁定状态
    if(retVal != BSP_OK)
    {
       return BSP_ERROR;
    }
    dbgInfoEx("Ld0 %d Ld1 %d\n",clkStatus[0],clkStatus[1]);
    if(clkStatus[0] != 0)/*跟数字确认我们只用LD0判断，LD1是假象*/
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*主从片间时钟状态的同步 目前只有从片需要获取主片时钟状态的需求 这里只处理BspQueryClkStatusProc 发送接口  从片发送BspQueryClkStatus*/
void BspClkStaSyncProc(UINT8 srcId, T_UdpMsgQueryClk *pReq, T_UdpMsgQueryClkAck *pAck)
{
    UINT32 mainOpt = 0;
    UINT32 clkSta = 0;

    INPUT_POINTER_CHECK_RETURN(pReq);
    INPUT_POINTER_CHECK_RETURN(pAck);
    BspHalAdaptGetMainPhyOpt(&mainOpt);
    clkSta = _BspGetSysPllStatus();
    pAck->clklock = 0;
    pAck->reserve = 0;
    pAck->clksource = BspGetCpriSwitchRec();
    if(BSP_ERROR != mainOpt)
    {
        pAck->reserve = 1;  /*主光口正常*/
    }
    if(BSP_OK == clkSta)
    {
        pAck->clklock = 1;   /*系统时钟锁定*/
    }
    dbgInfoEx("mainopt %d(%d), clkSta %d(%d)\n",mainOpt, pAck->reserve, clkSta,pAck->clklock);

    return ;
}
UINT32 BspCheckPllLdCallBackInit(void)
{
    UINT32 retVal = BSP_OK;
    retVal = BspSysPllStatusGetCallback(_BspGetSysPllStatus);
    BspQueryClkStatusCallbackInit(BspClkStaSyncProc);
    return retVal;
}

UINT32 BspPowOnOffInit(void)
{
    UINT32 retVal    = BSP_OK;
    UINT32 cpriType = 0;

    retVal |= BspHalAdaptGetCpriProtocol(&cpriType);
    switch(cpriType)
    {
        case PROCOTOL_CPRI:
            retVal |= BSpHalAdaptSetFddPwrOff();
            break;
        case PROCOTOL_IR:
            retVal |= BSpHalAdaptSetTddPwrOff();
            break;
        case PROCOTOL_QCELL:
            break;
        default:
            break;
    }

    return retVal;
}

UINT32 BspRegisterPaVoltUpdateCall(pPaVoltUpdateFunc updateCall)
{
    pPaVoltUpdateCall = updateCall;
    return BSP_OK;
}

/* Started by AICoder, pid:e47e5ra1d2t6b37142a3093e002d4a4f09e0a520 */
static UINT32 *updatePaVolt = NULL;
UINT32 BspSetSecondUpdatePaVolt(UINT32 chan, UINT32 volt)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("[%s]chan=%d, Execeed the Max_Num", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if(NULL == updatePaVolt)
    {
        updatePaVolt = (UINT32 *)malloc(sizeof(UINT32)*BSP_MAX_TX_CHAN);
        if(NULL == updatePaVolt)
        {
            dbgErr("%s>>updatePaVolt Malloc Error!\n", __FUNCTION__);
            return BSP_ERROR;
        }

        memset_s(updatePaVolt, sizeof(UINT32)*BSP_MAX_TX_CHAN, 0, sizeof(UINT32)*BSP_MAX_TX_CHAN);
    }
    updatePaVolt[chan] = volt;

    return BSP_OK;
}
/* Ended by AICoder, pid:e47e5ra1d2t6b37142a3093e002d4a4f09e0a520 */

/* Started by AICoder, pid:z2999ub0ed36c00140070a3fe026bd1658994f9a */
VOID BspGetSecondUpdatePaVolt(T_DefPaPara *paVoltInfo)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK_RETURN(paVoltInfo);
    if(NULL == updatePaVolt)
    {
        return ;
    }

    for(loop = 0; loop < BSP_MAX_TX_CHAN; loop++)
    {
        paVoltInfo->ulPaVolt[loop] = updatePaVolt[loop];
        BspLog(LOG_LEVEL_0, "%s,loop:%d,pavolt:%d\n", __FUNCTION__, loop, updatePaVolt[loop]);
    }

    return ;
}
/* Ended by AICoder, pid:z2999ub0ed36c00140070a3fe026bd1658994f9a */

/*BSP初始化功放漏压*/
UINT32 BspPaDefaultVoltInit()
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    INT32 volt = 0;
    INT32 bestvolt = 0;
    UINT32 paraNum = 0;
    T_DefPaPara *pPaVoltInfo = NULL;
    INT32 delta = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PA_VOLT_INIT, 0, 0, pPaVoltInfo, paraNum);
    BspGetSecondUpdatePaVolt(pPaVoltInfo);

    if(SUPP_REDUCE_PA_VOLT == BspGetReducePaVoltFlag())
    {
        delta = BspGetPaVoltDelt();
        dbgInfoEx("[%s] delta volt  %d\n",__FUNCTION__,delta);
    }

    for(loop=0;loop<BspGetTxChannel();loop++)
    {
        retVal=BspGetPaBestVolt(loop,&bestvolt);

        if(retVal == BSP_OK)
        {
            volt = bestvolt + delta;
            BspSetPaVolt(loop, volt);
            dbgInfoEx("chan %d best volt  %d\n",loop,volt);
        }
        else
        {
            volt = pPaVoltInfo->ulPaVolt[loop] + delta;
            BspSetPaVolt(loop, volt);
            dbgInfoEx("[%s]chan %d default volt  %d\n",__FUNCTION__,loop,volt);
        }

        BspSetDflTxInsertLoss(loop,pPaVoltInfo->uDflTxInsertLoss[loop]);
        BspSetPaTempDelta(pPaVoltInfo->ulTempdelta);
        BspSetPaDefaultVolt(loop,volt);

        if(BSP_OK != BspIsSupportRfsRemote())   /*一拖三机型给dsp下发电压档位*/
        {
            BspDpdSetSscVoltGrdCfg(loop,volt);
        }

        if(NULL != pPaVoltUpdateCall)
        {
            pPaVoltUpdateCall(loop, volt);
        }
    }
    BspSetPaVoltAdjustType(BSP_PA_VOLT_ADJUST_SEPARATE);
    return retVal;
}

/*BSP初始化功放漏压*/
UINT32 BspPaDefaultVoltInitByChan(UINT32 chan)
{
    UINT32 retVal = BSP_OK;
    INT32 volt = 0;
    INT32 bestvolt = 0;
    UINT32 paraNum = 0;
    T_DefPaPara *pPaVoltInfo = NULL;

    if(chan >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PA_VOLT_INIT, 0, 0, pPaVoltInfo, paraNum);
    retVal=BspGetPaBestVolt(chan,&bestvolt);

    if(retVal == BSP_OK)
    {
        volt = bestvolt;
        BspSetPaVolt(chan, bestvolt);
        dbgInfoEx("chan %d best volt  %d\n",chan,bestvolt);
    }
    else
    {
        volt = pPaVoltInfo->ulPaVolt[chan];
        BspSetPaVolt(chan, volt);
        dbgInfoEx("[%s]chan %d default volt  %d\n",__FUNCTION__,chan,pPaVoltInfo->ulPaVolt[chan]);
    }

    BspSetDflTxInsertLoss(chan, pPaVoltInfo->uDflTxInsertLoss[chan]);
    BspSetPaTempDelta(pPaVoltInfo->ulTempdelta);
    BspSetPaDefaultVolt(chan,volt);

    if(BSP_OK != BspIsSupportRfsRemote())   /*一拖三机型给dsp下发电压档位*/
    {
        BspDpdSetSscVoltGrdCfg(chan,volt);
    }

    if(NULL != pPaVoltUpdateCall)
    {
        pPaVoltUpdateCall(chan, volt);
    }
    BspSetPaVoltAdjustType(BSP_PA_VOLT_ADJUST_SEPARATE);
    return retVal;
}

UINT32 BspSetPwrCfgParaInit(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_PWR_MAP_CHAN *pPaVoltNum = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PWR_MAP_CHAN_INIT, 0, 0, pPaVoltNum, paraNum);
    retVal |= BspChanMapPwrIdxInit(pPaVoltNum);
    retVal |= BspSetpwrPaVoltNum(pPaVoltNum->pwrNum);

    return retVal;
}

/* Started by AICoder, pid:9c8f2w20e5jcd42145410b19b02ad61e0f147913 */
UINT32 BspSetPwrSupplyAbilityParaInit(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_PwrSupplyCfg *pwrSupplyCfg = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PWR_CONFIG_INIT, 0, 0, pwrSupplyCfg, paraNum);

    retVal |= BspPwrSupplyMapInit(pwrSupplyCfg);

    return retVal;
}
/* Ended by AICoder, pid:9c8f2w20e5jcd42145410b19b02ad61e0f147913 */

/* Started by AICoder, pid:41db1789bbh199f14f780aa9f04d151678b21a7c */
UINT32 BspSetPwrInputCrrentParaInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_PwrInputCurrAlarmCfg *pwrInputCurrentCfg = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PWRCURRENT_CFG, 0, 0, pwrInputCurrentCfg, paraNum);

    retVal |= BspPwrInputCurrCfgInit(pwrInputCurrentCfg);

    return retVal;
}
/* Ended by AICoder, pid:41db1789bbh199f14f780aa9f04d151678b21a7c */

UINT32 BspSetPwrTempAlarmThresholdValue(VOID)
{
    UINT32 retVal = 0;
    UINT32 pwrindexnum = 0;
    T_PwrTempAlarmDefPaPara *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PWRTEMP_THRESHOLD_INIT, 0, 0, pPara, pwrindexnum);

    retVal = BspSetPwrTempAlmThreshold(pPara);

    return retVal;
}

UINT32 BspPaptCfgInfoInit(void)
{
    UINT32 retVal  = BSP_OK;
    UINT32 paraNum = 0;
    Papt_Opt_Cfg_Info *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_OPT_PAPT_INIT, 0, 0, pPara, paraNum);

    retVal = BspPaptCfgInit(pPara);

    return retVal;
}

/*初始化流程需要放在BspInitPaPtPara之前*/
UINT32 BspInitPaptUpdata(void)
{
    UINT32 retVal  = BSP_OK;
    UINT32 paraNum = 0;
    UINT32 loop    = 0;
    UINT32 chanSelect = 0;
    UINT32 bspChan = 0;
    T_PaptUpdata *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PAPT_UPDATA, 0, 0, pPara, paraNum);
    for(loop = 0; loop < paraNum; loop ++)
    {
        chanSelect = pPara[loop].chanSelect;
        for (bspChan = 0; bspChan < BspGetTxBspChanNum(); bspChan ++)
        {
            if(BIT_VAL(chanSelect,bspChan))
            {
                retVal |= BspPaptCfgUpdate(bspChan, &pPara[loop].updataCfgPara);
            }
        }
    }

    return retVal;
}

/*初始化流程需要放在BspInitPaPtPara之前*/
UINT32 BspPaptCrmInfoInit(void)
{
    UINT32 retVal  = BSP_OK;
    UINT32 paraNum = 0;
    T_PaptCrmCfg *pPara = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_CRM_PAPT_INIT, 0, 0, pPara, paraNum);

    retVal = BspSetPaptCrmMask(pPara);

    return retVal;
}

UINT32 BspPOwerAdjustDeltaInit(void)
{
    UINT32 retVal  = BSP_OK;
    UINT32 paraNum = 0;
    T_PowerAdjustDelta *pPara = NULL;
    UINT32 chanNum = BspGetTxChanNum();

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_POWER_ADJUST_DELTA, 0, 0, pPara, paraNum);

    retVal = BspPwrDeltaInit(pPara, chanNum);

    return retVal;
}

UINT32 BspPaPwrVoltInit(VOID)
{
	return BspPaDefaultVoltInit();
}

/* 使用静态的DEVID，以规避CPU使用率过高问题 */
UINT32 BspUseStaticDevIdInit(VOID)
{
    BspSetAttDevIdToNoNewFlag(0x5a5a);
    BspAttDevIdToDevNoNewInit();
    BspSetTempDevIdToNoNewFlag(0x5a5a);
    BspTempDevIdToDevNoNewInit();
    return BSP_OK;
}

UINT32 BspRegisterGetDPDGainAdjustFunc(pDPDPowerChange pGetDPDChange)
{
    if(pGetDPDChange != NULL)
    {
        pGetDPDChangeCall = pGetDPDChange;
    }
    return BSP_OK;
}

/*4T+4T 通道和各个校准表的映射关系*/
UINT32 BspBoardChanRfTblParaInit(void)
{
    UINT32 retVal = BSP_OK;
    T_RfTblChanPara *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_CHAN_RFTBL_PARA,0,0,pPara,num);
    retVal = BspChanRfTblParaInit(pPara,num);

    return retVal;
}

/*2T+6T 通道和各个校准表的映射关系*/
UINT32 BspBoardChanRfTblPara1Init(void)
{
    UINT32 retVal = BSP_OK;
    T_RfTblChanPara *pPara = NULL;
    UINT32 num = 0;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_CHAN_RFTBL_PARA,0,1,pPara,num);
    retVal = BspChanRfTblParaInit(pPara,num);

    return retVal;
}

UINT32 BspGetExpansionBoxPos(UINT32 antIndex, T_SwitchBoxInfo *switchInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 paraNum = 0;
    T_ExpansionBoxCfg *boxCfgInfo = NULL;

    INPUT_POINTER_CHECK(switchInfo);

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_EXPANSION_BOX_PARA, 0, 0, boxCfgInfo, paraNum);

    for (loop = 0; loop < paraNum; loop++)
    {
        if (boxCfgInfo[loop].antIndex == antIndex)
        {
            memcpy_s(switchInfo, sizeof(T_SwitchBoxInfo), &(boxCfgInfo[loop].switchCfgInfo), sizeof(T_SwitchBoxInfo));
            return retVal;
        }
    }

    return BSP_ERROR;
}

UINT32 BspGetExpansionBoxAnt(UINT32 boxId, UINT32 gearId)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 paraNum = 0;
    T_ExpansionBoxCfg *boxCfgInfo = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_EXPANSION_BOX_PARA, 0, 0, boxCfgInfo, paraNum);
    for (loop = 0; loop < paraNum; loop++)
    {
        if((boxCfgInfo[loop].switchCfgInfo.boxId == boxId) && (boxCfgInfo[loop].switchCfgInfo.gearId == gearId))
        {
            return boxCfgInfo[loop].antIndex;
        }
    }

    return BSP_ERROR;
}

UINT32 BspInitAntiTamper(VOID)
{
    UINT32 ret = 0;
    UINT32 flashType = 0;
    BspLog(LOG_LEVEL_0, "%s start\n", __FUNCTION__);
    
    flashType = BspGetFlashParaSel();
    if(flashType == 0)     //0:NOR+NAND类型flash 非0：NOR类型flash
    {
        BspSetAntiTamperBaseAddr(FLASH_ANTI_TAMPER_OFFSET_NOR_NAND);
        dbgInfoEx("NOR_NAND\n");
    }
    else
    {
        BspSetAntiTamperBaseAddr(FLASH_ANTI_TAMPER_OFFSET_NOR);
        dbgInfoEx("NOR\n");
    }

    BspSetAntiTamperOffsetAddr(0x0d);
    BspSetClearAntiTamperFlagOffsetAddr(CRC_CLR_FLGA_OFFSET_ADDR);
    ret = InitAntiTamper();
    dbgInfoEx("%s>>BspInitAntiTamper \n", __func__);

    return ret;
}

/* 单板，功放，电源美化温度delt值单板下配置 */
UINT32 BspRruTempOffsetInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_DefRruTempOffsetPara *rruTempOffsetInfo = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_RRUTEMP_OFFSET_INIT, 0, 0, rruTempOffsetInfo, paraNum);

    BspSetTempOffset(rruTempOffsetInfo);

    return retVal;
}

UINT32 BspPwrOverTempDeratingInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_PwrOverTempDerating *pwrOverTempDeratingCfg = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_PWROVERTEMP_DERATING_CFG, 0, 0, pwrOverTempDeratingCfg, paraNum);

    BspSetPwrTempDeratingInfo(pwrOverTempDeratingCfg);

    return retVal;
}

/* Started by AICoder, pid:9b540j3d12dee1514c880b387086a8154d52a674 */
UINT32 BspRruPowerConstraintCfgInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 paraNum = 0;
    T_RruPowerCfgInfo *rruPowerCfg = NULL;

    BOARD_MODLE_GET_DATA(E_HARD_FEATURE_RRUPOWERCONSTRAINT_CFG, 0, 0, rruPowerCfg, paraNum);

    retVal |= BspSetRruPowerConstraintPara(rruPowerCfg);

    return retVal;
}
/* Ended by AICoder, pid:9b540j3d12dee1514c880b387086a8154d52a674 */

/* Started by AICoder, pid:k22c5n6db3za9e8144360971b042f81590d984cc */
UINT32 BspNsbtCtrlDelayOptmimiza(VOID)
{
    #if defined(_BSP_WITH_WFS)
    return BSP_OK;
    #endif
    UINT32 ret = 0;
    UINT32 Ta = 100;       /* 短告警去抖时间（单位：us）*/
    UINT32 Tb = 10000000;  /* 短告警延长阈值（单位：us) */
    UINT32 Td = 12000;     /* 短告警断开时间（单位：us）*/

    ret = BspNsbtCtrlDelayInit(Ta, Tb, Td);

    return ret;
}
/* Ended by AICoder, pid:k22c5n6db3za9e8144360971b042f81590d984cc */

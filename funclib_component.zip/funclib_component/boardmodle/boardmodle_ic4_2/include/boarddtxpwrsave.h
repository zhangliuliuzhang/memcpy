
#ifndef _BOARDPWRSAVE_H_
#define _BOARDPWRSAVE_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "functionwrapper.h"

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspSetDtxChkAbility(T_RruDtxAbilitySupport *DtxAblitySuppor, UINT32 num);
UINT32 BspGetDtxCounter(UINT32 bspChan, UINT32 *pDtxCounter);
UINT32 BspDpdicDifDtxParaInit(UINT32 difChan);
UINT32 BspDtxParaInit(VOID);
UINT32 BspGetDtxChSymOffTime(UINT32 bspChan, UINT32 *pSymOffTime);/* 获取通道级符号节电时长接口 */
UINT32 BspSetPwrsaveTddEn(UINT32 rxsw, UINT32 txsw);
UINT32 BspSetFpgaDtxSwitch(UINT32 bspChan, UINT32 on);
#ifdef __cplusplus
}
#endif

#endif

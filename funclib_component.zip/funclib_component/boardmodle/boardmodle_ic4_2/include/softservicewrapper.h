
#ifndef _SOFTSERVICE_WRAPPER_H_
#define _SOFTSERVICE_WRAPPER_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "softservicewrapperbase.h"
#include "softservicewrapperrfctrl.h"
#include "softservicewrappervermanage.h"

#ifdef __cplusplus
}
#endif

#endif /* _SOFTSERVICE_WRAPPER_H_ */



#ifndef _HARDFEATURE_WRAPPER_BASE_H_
#define _HARDFEATURE_WRAPPER_BASE_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"
#include "regdrv_access.h"

/**************************************************************************
 *                                枚举定义
 **************************************************************************/
typedef enum _REG_FUNCDOMAIN_TYPE
{
    REG_FUNCDOMAIN_CPU_DDR3 = 0 ,   /* high mem           0 */
    REG_FUNCDOMAIN_FPGA0,           /* fpga               1 */
    REG_FUNCDOMAIN_SLAVE_CPU_DDR3 , /* 从MGR high mem     2 */
    REG_FUNCDOMAIN_MAX
}E_REG_FUNCDOMAIN_TYPE;

typedef struct tagT_RruPropertyInfo
{
    const unsigned char * ascbuf;     /* 开始地址 */
    UINT32   bufSize;           /* size */
}T_RruPropertyInfo;

/* 单板Flash Bomid信息 */
typedef struct tagT_BomidFlashInfo
{
    UINT32   flashBomidOffset;  /* Flash上保存Bomid的偏移地址 */
    UINT32   flashBomidSize;    /* Flash上Bomid信息的长度 */
}T_BomidFlashInfo;


UINT32 BspSetAisgDigPhaseShiftInfoInit(VOID);
UINT32 BspSplicingBoardCfgFilePath(char* pFilePath, UINT32 len);
UINT32 BspFlashInit(VOID);
UINT32 BspRegTblInit(VOID);
UINT32 BspInitCpuAndCoreId(VOID);
UINT32 BspRruPropertyInit(VOID);
UINT32 BspUpdateRruPropertyInfo(VOID);
UINT32 BspGetFlashBomid(VOID);
UINT32 BspGetSocMsgBomid(VOID);
UINT32 BspGetBoardIdFirst(VOID);
UINT32 BspTestModifyBomidPara(UINT32 type);
UINT32 BspModifyRegHeadInfo(T_Reg_Head *newInfo, UINT32 headLen);

#ifdef __cplusplus
}
#endif

#endif /* _HARDFEATURE_WRAPPER_BASE_H_ */

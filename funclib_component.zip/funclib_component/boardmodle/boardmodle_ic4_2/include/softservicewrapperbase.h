#ifndef _SOFTSERVICE_WRAPPER_BASE_H_
#define _SOFTSERVICE_WRAPPER_BASE_H_

#ifdef __cplusplus 
extern "C" { 
#endif
#include "ichal_opt_logrecord.h"
typedef struct
{
    CHAR *procName;
    UINT32 coreMask;
} T_CoreProcAffinityInfo;

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 UdpMsgModuleInit(VOID);
UINT32 BspCoreProcAffinityInit(void);

#ifdef __cplusplus
}
#endif

#endif /* _SOFTSERVICE_WRAPPER_BASE_H_ */

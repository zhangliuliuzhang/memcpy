#ifndef _BOARD_VERSION_LOAD_H_
#define _BOARD_VERSION_LOAD_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"

typedef UINT32 (*LoadBinVersionFunc)(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum);
typedef UINT32 (*GetFpgaFactory)(UINT32 ulIndex);
typedef struct
{
    UINT32              comIndex;       // 器件片号
    UINT32              verIndex;       // 在swv中的版本索引
    UINT32              updateFlag;     // 更新加载结果，只有swv中的所有版本都加载成功后才更新
    LoadBinVersionFunc  loadBinFunc;    // 加载版本的函数，如果为NULL，调用LoadBinVersion加载版本
    const char          *ExeName;       // 进程名称
    GetFpgaFactory  getFpgaFactory;    // 判断逻辑芯片厂家
} T_VerLoadInfoComm;
typedef struct
{
    UINT32                      loadType;
    T_VerLoadInfoComm           *commonLoadInfo;
    UINT32                      infoLen;
    VOID                        *PrvInfo;
    UINT32                      PrvLen;
    const char                  *releaseVerPathPrx;     //  正式的swv版本的路径名(不包含文件名)
    const char                  *SoftName;              //  组件化后组件的名称(DPDDSP/ACDSP等)
    const char                  *swvName;               //  非组件化加载的文件名
    const char                  *ftpServerIp;           //  从片需要配置，下载版本的IP，其他配置成NULL
} T_VerLoadInfo;



typedef struct
{
    UINT32 ulSoftType;
    const char *curFile;
    const char *tmpFile;
}T_FileSoftTypeList;

#define VERSION_LOAD_TYPE_CUR_SWV           0   // 加载类似于/ata/rru/dsp/cur.swv版本
#define VERSION_LOAD_TYPE_COMPONENTIZED     1   // 通过组件化的XML获取加载的文件

#define NEED_UPDATEINI                      0x01
#define DONOT_UPDATEINI                     0x00
#define BSP_SOFT_TYPE_CPE                   26
#define NEED_FLUSH_CPE_VER                  1
#define NO_NEED_FLUSH_CPE_VER               0
#define GET_MT_RUN_VER_ERROR                1

void verbaseex(void);
void verload(void);
void verswv(void);
UINT32 BspLoadSwvVersion(T_VerLoadInfo *loadInfo);
UINT32 LoadFpgaBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum);
UINT32 UnzipTheTarPackage(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum);
UINT32 BspRecordBootVerFileInfoInit(void);
UINT32 BspRecordHashVer(void);
UINT32 BspInitBoardType(void);
UINT32 BspGetFpgaTypeByFpgaId(UINT32 ulFpgaIndex);
UINT32 LoadMcuBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum);
UINT32 LoadMcuSwvVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum);
UINT32 LoadEpldSwvVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum);
UINT32 LoadEpldBinVersion(UINT32 chipid, const char *binFileName, const char *processName, void *para, UINT32 paranum);
UINT32 BspGetFlushCpeVerFlag(VOID);
VOID BspSetFlushCpeVerFlag(UINT32 flag);
typedef UINT32 (*FUNC_BSP_GET_MT_RUNVER)(CHAR* verNo, UINT32 verNoLen);
UINT32 BspGetMtRunVerCallBack(FUNC_BSP_GET_MT_RUNVER pFunc);

#ifdef __cplusplus
}
#endif
#endif // _BOARD_VERSION_LOAD_H_

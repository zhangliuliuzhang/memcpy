#ifndef _DYNAMIC_DECOUPLING_H_
#define _DYNAMIC_DECOUPLING_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef UINT32 (*BSP_QCELL_GET_ANT_LINK_STATUS)(UINT32 *uStatus);

VOID prnantdetmap(VOID);
UINT32 getantdetmap(VOID);
UINT32 BspQcellSetAntLinkStatusFun(BSP_QCELL_GET_ANT_LINK_STATUS pFunc);





#ifdef __cplusplus
}
#endif

#endif /* _DYNAMIC_DECOUPLING_H_ */

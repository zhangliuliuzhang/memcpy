#ifndef _CHIPPOWERONWRAPPER_H_
#define _CHIPPOWERONWRAPPER_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "dpdicxmodem.h"
#include "rruinfo.h"
#include "ichaladapt_ic4_2.h"
#include "optctrlapi.h"

/**************************************************************************
 *                        宏
 **************************************************************************/
/*主片主和单片下MTS 源目录*/
#define FILE_MOVE_MASTER_MTS_SOURCE_PATH          "/oemfile_m/mts"
/*从片下MTS 源目录*/
#define FILE_MOVE_SLAVE_MTS_SOURCE_PATH           "/oemfile_s/mts"
/*MTS 目的目录*/
#define FILE_MOVE_MASTER_MTS_DEST_PATH            "/mts"

/* Started by AICoder, pid:u4df1z7bdd126ca149b80a129030fb05c4548124 */
/*主片PLC源目录*/
#define FILE_MOVE_MASTER_PLC_SOURCE_PATH          "/oemfile_m/plc/"
/*PLC 目的目录*/
#define FILE_MOVE_MASTER_PLC_DEST_PATH            "/plc/"
/* Ended by AICoder, pid:u4df1z7bdd126ca149b80a129030fb05c4548124 */

/*NCR MCU版本 源目录*/
#define FILE_MOVE_MASTER_NCRMCU_SOURCE_PATH                 "/oemfile_m/ncrmcu/"
/*NCR MCU版本 目的目录*/
#define FILE_MOVE_MASTER_NCRMCU_DEST_PATH                   "/mcu/"

/* Started by AICoder, pid:i168bgbdcar46161435309aa200c9e1cf7c26c99 */
/*vmp_tool工具 源目录*/
#define FILE_MOVE_MASTER_VMPTOOL_SOURCE_PATH                "/oemfile_m/vmp_tool/"
/*vmp_tool工具 目的目录*/
#define FILE_MOVE_MASTER_VMPTOOL_DEST_PATH                  "/vmp_tool/"
/* Ended by AICoder, pid:i168bgbdcar46161435309aa200c9e1cf7c26c99 */

/*bootloader 源目录*/
#define FILE_MOVE_MASTER_BOOT_LOADER0_SOURCE_PATH           "/oemfile_m/bootloader0.bin"
#define FILE_MOVE_MASTER_BOOT_LOADER1_SOURCE_PATH           "/oemfile_m/bootloader1.bin"
#define FILE_MOVE_MASTER_RAMBOOT_SOURCE_PATH                "/oemfile_m/ramboot.bin"
#define FILE_MOVE_MASTER_BOOT_LOADER0_D4_SOURCE_PATH        "/oemfile_m/bootloader0_d4.bin"
#define FILE_MOVE_MASTER_BOOT_LOADER1_D4_SOURCE_PATH        "/oemfile_m/bootloader1_d4.bin"
#define FILE_MOVE_MASTER_RAMBOOT_D4_SOURCE_PATH             "/oemfile_m/ramboot_d4.bin"
/*MCU版本 源目录*/
#define FILE_MOVE_MASTER_PWRUPDATE_SOURCE_PATH           "/oemfile_m/pwrupdate"

#define FILE_MOVE_PASAVEADJ_DEST_CALI_PATH       "/ata/cali/PaEnergySavingAdj.txt"
#define FILE_MOVE_PASAVEADJ_DEST_TMP_PATH        "/tmp/cali/PaEnergySavingAdj.txt"
#define FILE_MOVE_PATEMPGAIN_DEST_CALI_PATH      "/ata/cali/PaTempGain.txt"
#define FILE_MOVE_PATEMPGAIN_DEST_TMP_PATH       "/tmp/cali/PaTempGain.txt"

/*ADI 源目录*/
#define FILE_MOVE_ADI_SOURCE_PATH           "/oemfile_m/adi_r8159182326"
/*ADI 目的目录*/
#define FILE_MOVE_ADI_DEST_PATH            "/adi"

/*ADI 源目录*/
#define FILE_MOVE_ADI_R81591835E_SOURCE_PATH           "/oemfile_m/adi/adi_r8159m1835e"
/*ADI 目的目录*/
#define FILE_MOVE_ADI_R81591835E_DEST_PATH            "/adi/adi_r8159m1835e"

#define FILE_MOVE_MASTER_BOARD_CFG_FILE_SOURCE_PATH         "/oemfile_m/BoardCfgFile"
#define FILE_MOVE_SLAVE_BOARD_CFG_FILE_SOURCE_PATH          "/oemfile_s/BoardCfgFile"
#define FILE_MOVE_MASTER_BOARD_CFG_FILE_DEST_PATH           "/BoardCfgFile"
#define FILE_MOVE_MASTER_APP_BOARD_CFG_FILE_SOURCE_PATH     "/oemfile_m/.info"
#define FILE_MOVE_SLAVE_APP_BOARD_CFG_FILE_SOURCE_PATH      "/oemfile_s/.info"
#define FILE_MOVE_MASTER_APP_BOARD_CFG_FILE_DEST_PATH       "/.info"

/*bootloader 目的目录*/
#define FILE_MOVE_MASTER_BOOT_LOADER0_DEST_PATH             "/tmp/bootloader0.bin"
#define FILE_MOVE_MASTER_BOOT_LOADER1_DEST_PATH             "/tmp/bootloader1.bin"
#define FILE_MOVE_MASTER_RAMBOOT_DEST_PATH                  "/tmp/ramboot.bin"
/*MCU版本 目的目录*/
#define FILE_MOVE_MASTER_PWRUPDATE_DEST_PATH           "/pwrupdate"
#define FILE_MOVE_MASTER_PWRUPDATE_SOURCE_PATH         "/oemfile_m/pwrupdate"

/* ko */
#define FILE_MOVE_MASTER_KO_SOURCE_PATH                     "/oemfile_m/*.ko"
#define FILE_MOVE_SLAVE_KO_SOURCE_PATH                      "/oemfile_s/*.ko"
#define FILE_MOVE_KO_DEST_PATH                              "/"


/*18232649*/
#define FILE_MOVE_ADI_R8159_18232649_SOURCE_PATH_M "/oemfile_m/adi_r815918232649_m"
#define FILE_MOVE_ADI_R8159_18232649_DEST_PATH_M   "/adi"

#define FILE_MOVE_ADI_R8159_18232649_SOURCE_PATH_S "/oemfile_m/adi_r815918232649_s"
#define FILE_MOVE_ADI_R8159_18232649_DEST_PATH_S   "/adi"

#define FILE_MOVE_MASTER_DEV_SOURCE_PATH          "/oemfile_m/devsocfg"
#define FILE_MOVE_MASTER_DEV_DEST_PATH            "/devsocfg"
#define MOVE_WAY_COPY (0)
#define MOVE_WAY_MOVE (1)

#define D42_PMB_MAX_NUM      ((UINT32)10)   /*D42电源管理芯片最大数量*/

/**************************************************************************
 *                                枚举定义
 **************************************************************************/

/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef UINT32 (*ChipPowOn_ClkInitPostHandle)(VOID);/*时钟文件初始化后处理接口，待后续需要的时候增加参数*/
typedef UINT32 (*ChipPowOn_ChangePaDacDeviceCfg)(VOID);/*栅压DAC配置方案修改接口*/
typedef UINT32 (*ChipPowOn_Negative8VAlarm)(VOID);/*-8V告警检测接口*/
typedef UINT32 (*ChipPowOn_GetSocLoadStatus)(UINT32 *status);
typedef UINT32 (*ChipPowOn_GetCpriModeLaneRoutePathNo)(UINT32 *path);
typedef UINT32 (*ChipPowOn_SetCpriModeLaneRoutePathNo)(UINT32 path);
typedef UINT32 (*ChipPowOn_GetCpriModeLaneRouteTryingTimes)(UINT32 *times);
typedef UINT32 (*ChipPowOn_SetCpriModeLaneRouteTryingTimes)(UINT32 times);
typedef UINT32 (*ChipPowOn_GetCpriModeSupportAblity)(UINT32 *ablity);

typedef struct t_dac_init_para
{
    UINT32 N8vAlarmFlag;        /*-8V是否检测标志，0x5a5a检测-8V告警，0xa5a5不检测-8v告警*/
    ChipPowOn_ChangePaDacDeviceCfg pChangePaDacDeviceCfg;
    ChipPowOn_Negative8VAlarm pNegative8VAlarm;
}T_DACINIT_PARA;


typedef struct tagT_RfPllInit_Para
{
    UINT32 dlDirect;
    UINT32 ulDirect;
    UINT32 prlDirect;
}T_RfPllInit_Para;

typedef struct tagT_DpdicSocReset
{
    UINT32 rstType;
    UINT32 chipMask;
}T_DpdicSocReset;

typedef struct tagT_DpdicSocLoad
{
    UINT32 rstType;
    UINT32 chipMask;
    T_DPDIC_XMODEM_INFO xmodemInfo;
}T_DpdicSocLoad;

typedef struct tagT_FileMoveList
{
    CHAR  *pSourcePath;
    CHAR  *pDestPath;
    UINT32 moveWay;             /* 移动方式，0：copy 1：move*/
}T_FileMoveList;

typedef struct tagT_DpdicSocLoadOrder
{
    UINT32 chipMask;
    UINT32 socLoadChipNo[DPDIC_SOC_MAX_NUM];
}T_DpdicSocLoadOrder;

typedef struct tagT_RfTblFileMoveList
{
    const CHAR  **pRfTblSourcePath;
    const CHAR  **pRfTblAtaCaliDestPath;
    const CHAR  **pRfTblTmpCaliDestPath;
    UINT32 fileNum;
    const CHAR  *compareTime;
    UINT32 isSupportChkPaBdName;
    const char  *pMoveTblPaBoardName1;
    const char  *pMoveTblPaBoardName2;
}T_RfTblFileMoveList;

typedef struct tag_pmb_coef
{
    UINT32 pmbNo;      /*芯片索引*/
    UINT32 pmbKrCoef;    /*电阻分压比例,由电源提供*/
} T_PmbCoef;

typedef struct tag_pmb_scale_info
{
    UINT32 pmbNum;                        /*电源管理芯片数量*/
    T_PmbCoef pmbcoef[D42_PMB_MAX_NUM];   /*芯片系数*/
} T_PmbScaleInfo;

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspInitGpioPad(VOID);
UINT32 BspCbSwCommonParaInit(VOID);
UINT32 BspCbSwStaTblParaInit(VOID);
UINT32 BspCbSwStaTblPara1Init(VOID);
UINT32 BspCbSwRfTblParaInit(VOID);
UINT32 BspCbSwRfTblParaInit_Fpga(VOID);
UINT32 LoadFpgaVersion(VOID);
UINT32 LoadDspVersion(VOID);
UINT32 LoadSlaveMgrVersion(void);
UINT32 LoadSlaveBinVersion(void);
UINT32 BspMainM0LoadVersion(VOID);
UINT32 BspSlaveM0LoadVersion(VOID);
UINT32 BspInitRfPllInit(VOID);
UINT32 BspPreInitRfTransceiver(VOID);
UINT32 BspPostInitRfTransceiver(VOID);
UINT32 BspInitDattVgaPara(VOID);
UINT32 BspCbSwPinTblParaInit(VOID);
UINT32 InitClkDev(VOID);
UINT32 BspDacInterfaceParaInit(VOID);
UINT32 BspDacDevInit(VOID);
UINT32 BspDpdicCrmInit_BeforeClk(VOID);
UINT32 BspDpdicCrmInit_After_M(VOID);
UINT32 BspDpdicCrmInit_After_S(VOID);
UINT32 BspDpdicSlaveSocReset(VOID);
UINT32 BspDpdicSlaveSocRelease(VOID);
UINT32 BspDpdicSlaveSocLoad(VOID);
UINT32 BspDpdicSlaveSocLoadByChip(UINT32 chipId);
UINT32 BspDpdicSlaveSocResetByChip(UINT32 chipId, UINT32 rstCtrl);
UINT32 BspRfTransceiverInit(VOID);
UINT32 LoadAcDspVersion(void);
UINT32 BspFileMoveInit(void);
UINT32 BspInitAcAttSwitchPara(VOID);
UINT32 BspCfgInfoAfterPowerInit(VOID);
UINT32 BspDpdicPwrSavePreInit(void);
UINT32 BspDpdicPwrSaveInit(void);
UINT32 BspDpdicPwrSavePostInit(void);
UINT32 BspGetDpdicLoadChipNo(UINT32 chipIdx, UINT32 *socChipNo);
UINT32 BspRfTblFileMoveInit(void);
UINT32 BspFileCopy(const CHAR* pcSrcFileName, const CHAR* pcDesFileName);
UINT32 BspFileMove(CHAR* pcSrcFileName,CHAR* pcDesFileName);
UINT32 BspCpriModeSwitchFuncInit(VOID);
UINT32 BspCpriModeSwitchParaInit(VOID);
/* Trx J204c 预均衡参数初始化 */
UINT32 BspTrxJ204SerdesTxEqInit(VOID);
/* 单板配置文件(包括APP和BSP的配置文件)搬移 */
UINT32 BspBoardCfgFileMoveInit(VOID);
VOID BspSetOptClkInitCondition(UINT32 cfgFlag);
UINT32 BspUpdatePaDacSetParaInit(VOID);
UINT32 BspUpdateQcellPaDacSetParaInit(VOID);
UINT32 BspModifyDefaultPaVolt(void);
UINT32 BspSwitchSpareLaneInit(VOID);
UINT32 BspDpdicDynVoltParaInit(VOID);
UINT32 BspPmbScaleInfoInit(VOID);
UINT32 BspGetEfuseInfo(T_EfuseInfo *pEfuseInfo);
#ifdef __cplusplus
}
#endif

#endif

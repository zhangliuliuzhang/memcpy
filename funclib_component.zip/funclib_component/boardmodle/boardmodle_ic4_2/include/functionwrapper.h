
#ifndef _FUNCTION_2WRAPPER_H_
#define _FUNCTION_2WRAPPER_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
#include "freqcfgcommon.h"
/**************************************************************************
 *                        宏
 **************************************************************************/
#define BSP_RADIO_STANDARD_LTE_NR_MIX  (0x6030)     /*兼容FDD、TDD的LTE和NR制式*/

/**************************************************************************
 *                                枚举定义
 **************************************************************************/
 


/**************************************************************************
 *                         数据类型
 **************************************************************************/

/* 配频模块用参数信息 */
typedef struct tagT_FreqCfgData
{
    UINT32 chanSelect;          /*选取相应通道*/
    T_RfPllCfgInit freqPara;  /*配频数据*/
}T_FreqCfgData;

/* 载波能力 */
typedef struct tagT_RruDefAbility
{
    UINT32 carrNum;
    UINT32 defRadio;
}T_RruDefAbility;

/* 载波DTX能力上报 */
typedef struct tagT_RruDtxAbilitySupport
{
    UINT32 radioMode;
    UINT32 dtxAbility;
}T_RruDtxAbilitySupport;

typedef struct tagT_ChBndSupInfo
{
    UINT32  dir;
    UINT32  chan;
    UINT32  band[3];
}T_ChBndSupInfo;

/* 不同制式载波上报能力 */
typedef struct tagT_RruCarrAbility
{
    UINT32 singleNrCarrNum;
    UINT32 singleLteCarrNum;
    UINT32 mixNrCarrNum;
    UINT32 mixLteCarrNum;
}T_RruCarrAbility;

/* 硬件自检参数 */
typedef struct tagT_NtfCfgData
{
    UINT32 ntfSupportFlag;
    UINT32 ntfPowFlag;
    UINT32 ntfTssiFwdDiffThreshold;
    UINT32 adcStatusMask; 
    INT32 (*pTest204c)(VOID);
    UINT32 vswrStep;
    UINT32 scalarVswrThre;
    T_PwrInputAlmThre almThre[5];
}T_NtfCfgData;

/* EQ功能参数 */
typedef struct tagT_DpdEqData
{
    UINT32 supportFlag;     /* 是否支持EQ功能标志 */
}T_DpdEqData;

/* 支持提升闭环功控门限的机型 */
typedef struct tagT_RruRaiseTptlGateList
{
    CHAR *pcTypeNumber;
    CHAR *pcPid;
}T_RruRaiseTptlGateList;

typedef struct tagT_UpdateBandInfo
{
    UINT32 boardName;   /*单板枚举值*/
    UINT32 oldBandVal;  /*需要替换的频段值*/
    UINT32 newBandVal;  /*新的频段值*/
}T_UpdateBandInfo;

/* DLVGA驱动电流配置表结构体 - 定义单个寄存器的驱动电流配置信息 */
typedef struct
{
    UINT32 chipId;          /* 芯片ID，用于标识不同的芯片 */
    UINT32 regAddr;         /* 寄存器地址，指定要操作的寄存器位置 */
    UINT32 driveCurrent;    /* 驱动电流值，要写入的目标值 */
    UINT32 waitTimeMs;      /* 等待时间(ms)，写入后的稳定等待时间 */
    UINT32 retryTimes;      /* 重试次数，写入失败时的重试次数 */
} T_DlVgaDrivePara;

typedef VOID (*FUNC_SET_SOC_RADIOCFG_FLAG)(VOID);
VOID BspRegisterRadioCfgCallBack(FUNC_SET_SOC_RADIOCFG_FLAG pFunc,UINT32);

typedef VOID (*FUNC_CHANGE_SOC_RADIOCFG)(VOID);
VOID BspChangeRadioCfgCallBack(FUNC_CHANGE_SOC_RADIOCFG pFunc,UINT32 data);

/**************************************************************************
*                         函数声明
**************************************************************************/

UINT32 BspTxFreqCfgInit(VOID);
UINT32 BspRxFreqCfgInit(VOID);
UINT32 BspOptPreAllocInit(VOID);
UINT32 BspTxRfDlyInit(VOID);
UINT32 BspRxRfDlyInit(VOID);
UINT32 BspInitTxDeltDly(VOID);
UINT32 BspInitRxDeltDly(VOID);
UINT32 BspInitFddDlyPara(VOID);

UINT32 BspInitRruDefAbility_M(VOID);
UINT32 BspInitRruDefAbility_S(VOID);
UINT32 BspInitRruCarrAbility(VOID);
UINT32 BspInitPowCalcPara(VOID);
UINT32 BspInitDlPowCalcPara(VOID);
UINT32 BspInitUlPowCalcPara(VOID);
UINT32 BspPowerAdjParaInit(VOID);
UINT32 BspInitPowCalcThread(VOID);
UINT32 BspInitPowCalcThresholdPara(VOID);
UINT32 BspInitTempThresholdPara(VOID);
UINT32 BspInitCfrPara(VOID);
UINT32 BspInitCfrFunc(VOID);
UINT32 BspInitChipTranDlyPara(VOID);
UINT32 BspInitDpdFunc(VOID);
UINT32 TrxDigGainInit(VOID);
UINT32 BspVgaCfgInit(VOID);
UINT32 BspMgcCmdInfoInit(VOID);
UINT32 BspVgaInfoInit(void);
UINT32 BspRfVgaInit(VOID);
UINT32 BspVgaBusInit(VOID);

UINT32 BspInitOpenLoopPara(VOID);

/* 通道组初始化 */
UINT32 BspChanGroupInit(VOID);
UINT32 BspDtxAbilitySupport(VOID);
/* 通道组和TDD索引之间的对应关系 */
UINT32 BspChnGrpToTddIdxInit(VOID);
/* 通道频段信息初始化 */
UINT32 BspChnFreqBandInfoInit(VOID);
/* 接收频谱扫描初始化 */
UINT32 BspInitRxScanInit(VOID);
UINT32 BspVgaLikeSpiParaInit(VOID);
UINT32 BspDpdVswrParaInit(VOID);

/*功放保护告警上报和自救处理初始化*/
UINT32 BspPaptReportRecoverInit(VOID);
/*40KM拉远时延上报参数初始化*/
UINT32 BspInitRruUlDelayCmpAbility(VOID);
UINT32 BspInitPaPwrVoltCtrl(VOID);
UINT32 BspRevPowProtectInit(void);

//#ifndef MULT_PROGRESS_S
UINT32 BspNtfCfgInit(VOID);
//#endif
/* FDD 关闭LNA NI扫描需求 */
UINT32 BspInitLnaOffPara(VOID);
UINT32 BspParseTxFreqCfgPara(T_FreqCfgData *pPara, UINT32 *pNum);
UINT32 BspPsyncInterruptInit(VOID);
UINT32 BspInitDpdPowCalcThread(VOID);
UINT32 BspChanCenterFreqFlagInit(VOID);
UINT32 BspFixPaptKfGain(UINT32 chan, INT32 gain);
UINT32 BspDpdSetEqCaliParam(VOID);
UINT32 BspSetRruSpecialFlagInit(VOID);
UINT32 BspSetRruCarrRangeCapInit(VOID);
UINT32 BspDflOutRangAlmFlagInit(VOID);
UINT32 BspGetChnBandVal(UINT32 bspchan, UINT32 dir,UINT32 bandno);
VOID BspSetChnBandVal(UINT32 bspchan, UINT32 dir, UINT32 bandno, UINT32 bandVal);
UINT32 BspSfpSelfHealFlagInit(VOID);
UINT32 BspSetNtfCarrRadio(UINT32 radio);
UINT32 BspGetNtfCarrRadio(void);
UINT32 BspInitFddToffset(VOID);
UINT32 BspInitFddFixLink(VOID);
#ifdef __cplusplus
}
#endif

#endif /* _FUNCTION_2WRAPPER_H_ */



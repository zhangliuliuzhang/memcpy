/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : brsadpt.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了单板的结构体、变量、参数配置
* 注意事项 : 无
* 作    者 : NR2.0
* 创建日期 : 2017-08-27
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#ifndef _UDPMSG_H_
#define _UDPMSG_H_

#ifdef __cplusplus
extern "C"{
#endif

#include <time.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "udpmsg_ic.h"


#define UDP_SOCMSG_BOMID_NEW_CFG_FLAG   0xA5C3


#define MSG_TYPE_QUERY_ID        		0x0001     //从向主查询bomid

#define MSG_TYPE_SOC_CMD        		0x0002     //主向从发送soccmd
#define MSG_TYPE_QUERY_RADIOMODE   		0x0004     //从向主查询radioMode
#define MSG_TYPE_QUERY_CLK              0x0005     //从向主查询时钟状态

#define MSG_TYPE_QUERY_TIME             0x0012	   //从向主查询time


/*MSG_TYPE_SOC_CMD相关宏定义*/
#define UDP_SHELL_COMMD_RESULT              0x1000
#define UDP_SHELL_COMMD_SUCCESS             (UDP_SHELL_COMMD_RESULT + 0x01)
#define UDP_SHELL_COMMD_MSG_ERROR           (UDP_SHELL_COMMD_RESULT + 0x02)
#define UDP_SHELL_COMMD_FUN_UNKNOW          (UDP_SHELL_COMMD_RESULT + 0x03)
#define UDP_SHELL_COMMD_OPEN_FILE_ERROR     (UDP_SHELL_COMMD_RESULT + 0x04)
#define UDP_SHELL_COMMD_RD_FILE_ERROR       (UDP_SHELL_COMMD_RESULT + 0x05)
#define UDP_SHELL_COMMD_REDIRECT_ERROR      (UDP_SHELL_COMMD_RESULT + 0x06)

#define CMD_LENTH        127
#define CMD_PARA_NUM   10
#define CMD_STDIO_INFO_LENTH   (1024*4)

#define MAKE_FOURCC(a,b,c,d) \
( ((ULONG)d) | ( ((ULONG)c) << 8 ) | ( ((ULONG)b) << 16 ) | ( ((ULONG)a) << 24 ) )
#define CMD_SYNC       MAKE_FOURCC('@','S','Y','N')
#define CMD_GET_DATA   MAKE_FOURCC('@','D','A','T')
#define CMD_FUNC       MAKE_FOURCC('@','C','M','D')

typedef enum
{
    CLK_LOCK   = 0,//时钟锁定
    CLK_UNLOCK = 1,//时钟失锁
}e_clkstatus;
typedef enum
{
    TRX_START = 1,//TRX状态，初始化开始
    TRX_END   = 2,//TRX状态，初始化结束
}e_trxstatus;
typedef enum
{
    CLK_LOCAL = 0,//时钟源类型：本地时钟
    CLK_1588  = 1,//时钟源类型：1588时钟
}e_clksource;

/*************************** API Layer Information ****************************/

#pragma pack(1)

/* 0x01消息--获取ID */
typedef struct tagT_UdpMsgQueryId
{
}T_UdpMsgQueryId;

typedef struct tagT_UdpMsgQueryIdAck
{
    UINT16 state;
    UINT32 ModuleGroupId;
    UINT32 BoardGroupId;
    UINT32 BoardTypeId;
    UINT32 HardwareChangeId;
    UINT32 HwCustomIdA;
    UINT32 HwCustomIdB;
    UINT32 HwMagicNum;
    UINT32 BrdBomidCrc;
    UINT32 ProtocolType; /*  QCELLL   0:PB ,1:BBU ,   0xffff 宏站场景。*/
}T_UdpMsgQueryIdAck;

/* 0x02消息--soccmd */
typedef struct tagT_SocCmdParam
{
	UINT32 ulmask;				        /* mask always FUNC_CMD_MASK*/
	INT8   ucCmd[CMD_LENTH+1];             /* 命令 */
	UINT32 ucRsv1[4];                     /* 备用 */
}T_CmdParam;

/* 0x03消息--soctime */
typedef struct tagT_UdpMsgQueryTimeAck
{
    UINT16 state;
    time_t seconds;
}T_UdpMsgQueryTimeAck;

/* 0x04消息--获取制式 */
typedef struct tagT_UdpMsgQueryRadio
{
}T_UdpMsgQueryRadio;

typedef struct tagT_UdpMsgQueryRadioAck
{
    UINT32 state;
    UINT32 RadioMode;
}T_UdpMsgQueryRadioAck;

/* 0x05消息--查询时钟状态 */
typedef struct tagT_UdpMsgQueryClk
{
    UINT8 trxstatus;//从片上报trx状态给主片：值为TRX_START或TRX_END
    UINT8 rev[3];
}T_UdpMsgQueryClk;
typedef struct tagT_UdpMsgQueryClkAck
{
    UINT8  clkEnable;   //是否使能该功能；
    UINT8  clklock;     //时钟锁定状态，按bit位定义，bit n代表第n个锁相环，值为CLK_LOCK或CLK_UNLOCK
    UINT8  clksource;   //时钟源：本地或1588，CLK_LOCAL或CLK_1588
    UINT8  reserve;     //预留
    UINT32 unlockCnt[8];//时钟失锁次数，每个锁相环对应一个值
    UINT32 rev[2];      //预留
}T_UdpMsgQueryClkAck;

/* 被测单板返回测试结果数据结构定义 */
typedef struct tagT_MsgSocCommandAck
{
	UINT32 ulmask;			            /* mask always FUNC_CMD_MASK*/
	char   ucCmd[CMD_LENTH + 1];                    /* 命令 */
	INT32  cmdRet;                     /* 函数返回值 */
    char   cmdOutInfo[CMD_STDIO_INFO_LENTH+1];              /* 输出的函数执行打印512的深度*/
	UINT32 ulFuncParams[CMD_PARA_NUM];             /* 参数,最多支持10个参数 */
    UINT32 cmdErrReason;
}T_MsgSocCommandAck;

typedef struct tagT_SocMsgPDU
{
	UINT16 lenAPDU; /* length of head+msg */
	union
	{
		UINT8 headbuff[MAX_UPD_MSG_HEAD];
		TUdpApiHeader head;
	};
	union
	{
		UINT8 buf[MAX_UPD_MSG_BODY];
        /* 0x01消息 */
        T_UdpMsgQueryId tQueryId;
        T_UdpMsgQueryIdAck tQueryIdAck;
        /* 0x02消息 */
        T_CmdParam tCmdParam;
        T_MsgSocCommandAck tMsgSocCommandAck;
		/* 0x03消息 */
        T_UdpMsgQueryTimeAck tQueryTimeAck;
        /* 0x04消息 */
        T_UdpMsgQueryRadio tQueryRadio;
        T_UdpMsgQueryRadioAck tQueryRadioAck;
        /* 0x05消息 */
        T_UdpMsgQueryClk tQueryClk;
        T_UdpMsgQueryClkAck tQueryClkAck;
    }msg;
}TSocApiPDU;


#pragma pack()

typedef void (*FUNC_GET_CLK_STA)(UINT8 srcId,T_UdpMsgQueryClk *pReq,T_UdpMsgQueryClkAck *pAck);

#define DPD_HTONL(a)           htonl(a)
#define DPD_HTONS(a)           htons(a)
#define DPD_NTOHL(a)           ntohl(a)
#define DPD_NTOHS(a)           ntohs(a)

/*函数声明*/
UINT32 SocMsgQueryRadioMode(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8 ulChnlNo,UINT8 ulFreqBandNo,T_UdpMsgQueryRadioAck* pbuff,UINT32 len);
UINT32 BspQueryClkStatusCallbackInit(FUNC_GET_CLK_STA pFunc);
VOID BspParaseUdpShellCmd(VOID *pBuf,UINT32 len,T_MsgSocCommandAck *result);
void prnapihead(UINT8 *Buf);

UINT32 SocMsgQueryId(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8 ulChnlNo,UINT8 ulFreqBandNo,UINT8* pbuff,UINT32 len);
UINT32 DbgSocMsgGetBoardBomidInfo(VOID);
UINT32 SocMsgSetBoardBomidInfo(T_UdpMsgQueryIdAck *ptBomidInfo);
UINT32 SocMsgGetBoardBomidInfo(T_UdpMsgQueryIdAck *ptBomidInfo);
UINT32 BspSetSocMsgBomidInfo(VOID);
UINT32 BspParseCmdResult(UINT32 cmdResult);

UINT32 SocMsgQueryTime(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8 ulChnlNo,UINT8 ulFreqBandNo,UINT8* pbuff,UINT32 len);
UINT32 BspQueryClkStatus(UINT32 typeId,UINT8 srcId,UINT8 dstId,T_UdpMsgQueryClk *sBuf,UINT32 slen,T_UdpMsgQueryClkAck* rBuf,UINT32 rlen);
UINT32 SocMsgCmd(UINT32 typeId,UINT8 srcId,UINT8 dstId,UINT8* pbuff,UINT32 len,UINT8* cmd,UINT32 cmdLen);
VOID BspParaseUdpShellCmd(VOID *pBuf,UINT32 len,T_MsgSocCommandAck *result);
UINT32 GetRadioCfg(VOID);
UINT32 BspIfSocNsbtFine(UINT8 socId, const CHAR *cmd);
UINT32 BspGetSysPllStatusFromMain(UINT8 *pLdSta, UINT8 *pMainOpt,UINT8 *pCpriSwRec);
UINT32 BspUdpMsgQueryParaInit(VOID);
#ifdef __cplusplus
}
#endif

#endif  /* _UDPMSG_H_ */

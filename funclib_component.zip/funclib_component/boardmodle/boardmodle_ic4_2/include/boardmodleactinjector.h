#ifndef _BOARDMODLE_ACT_INJECTOR_H_
#define _BOARDMODLE_ACT_INJECTOR_H_

#include "bsppub.h"
#include "boardmodlecommon.h"

/* 初始化流程挂接表定义 */
typedef struct tagT_BoardInitFlowTbl
{
    UINT32 actType;                         /* 动作类型 */
    CHAR *pActName;                         /* 初始化动作简要描述,可以填接口名称，仅为显示用 */
}T_BoardInitFlowTbl;

/* 初始化接口挂接表定义 */
typedef struct tagT_ModleInitItem
{
    T_BoardActFuncTbl *actFuncTblBase;
    UINT32 actFuncTblBaseLen;
    T_BoardActFuncTbl *actFuncTblDiff;
    UINT32 actFuncTblDiffLen;
    T_BoardInitFlowTbl *preInitFlow;
    UINT32 preInitFlowLen;
    T_BoardInitFlowTbl *initFlow;
    UINT32 initFlowLen;
}T_ModleInitItem;

UINT32 BspSetModelItem(UINT32 boardType, T_ModleInitItem *pModelItem);


#endif

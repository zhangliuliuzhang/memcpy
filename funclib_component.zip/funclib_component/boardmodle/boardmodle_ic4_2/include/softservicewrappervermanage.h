
#ifndef _SOFTSERVICE_WRAPPER_VER_MANAGE_H_
#define _SOFTSERVICE_WRAPPER_VER_MANAGE_H_

#ifdef __cplusplus 
extern "C" { 
#endif

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspInitDbootPara(VOID);
UINT32 BspGetSecNvEnByGpio(UINT32 enType, UINT32 *enVal);
UINT32 BspInitGpioRdFunc(void);
UINT32 BspInitEfuseWriteFunc(void);
UINT32 BspInitEfuseReadFunc(void);
UINT32 BspCfgSecVerifyCallBack(VOID);
UINT32 BspCfgSecVerifyPara(VOID);
UINT32 BspCfgSecVerifyFun(VOID);
VOID BspSetFlashDivision(UINT32 flashDivision);
UINT32 BspGetFlashDivision(VOID);
#ifdef __cplusplus
}
#endif

#endif /* _SOFTSERVICE_WRAPPER_VER_MANAGE_H_ */



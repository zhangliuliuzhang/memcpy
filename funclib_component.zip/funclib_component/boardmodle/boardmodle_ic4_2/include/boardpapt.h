
#ifndef _BOARD_PAPT_H_
#define _BOARD_PAPT_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
#include "bsppub.h"

#define IC4_2_OPT_NUM_MAX   (4)

typedef struct tag_Papt_Opt_Cfg_Info
{
    UINT32 openPaDaFlag;
    UINT32 sbcDaOffMaskInfo;     // addr:0xC2408034   value: 0x00000001
    UINT32 daOffDlyInfo;         // addr:0xC2408038   value: 0x00000010
    UINT32 daOnDlyInfo;          // addr:0xC240803C   value: 0x80000001
    UINT32 difDaOffAlmMaskInfo;  // addr:0xC2410820   value: 0x00000001
    UINT32 difPaOffAlmMaskInfo;  // addr:0xC2410824   value: 0x00000001
    UINT32 difDaOffSecMaskInfo;  // addr:0xC2400064   value: 0x00000101
    UINT32 difPaOffSecMaskInfo;  // addr:0xC2400060   value: 0x00000007
    UINT32 serdesAlmMaskInfo[IC4_2_OPT_NUM_MAX];     // addr:0xC2402350   value: 0x000007e0
    UINT32 localLogicAlmMaskInfo[IC4_2_OPT_NUM_MAX]; // addr:0xC2408014   value: 0x00009FCF
    UINT32 cascLogicAlmMaskInfo[IC4_2_OPT_NUM_MAX];  // addr:0xC2408024   value: 0x00009FCF
    UINT32 logicDaOffAlmMaskInfo[IC4_2_OPT_NUM_MAX]; // addr:0xC2410800   value: 0x00001FCF
    UINT32 logicPaOffAlmMaskInfo[IC4_2_OPT_NUM_MAX]; // addr:0xC2410804   value: 0x00000800
    UINT32 DifPhyAlmDaMaskInfo;   // addr:0xC2410840   value: 0x00000000
    UINT32 DifPaOffSecMaskInfo;   // addr:0xC2400060   value: 0x00000007
    UINT32 DifPaOffPhyAlmDaMaskInfo;  // addr:0xC2410844   value: 0x00000011
} Papt_Opt_Cfg_Info;

typedef struct T_PaptCfgUpdataStruct
{
    UINT32  lnaFalg;       /*是否支持LNA关断标志*/
    UINT32  mtsAlarmNo;    /*MTS连接的alarm管脚 ，一片IC最多两片[0,1]*/
    UINT32  paMask;        /*开PA的告警掩码*/
    UINT32  daMask;
}T_RfPaptCfgUpdata; /**功放保护参数配置*/

typedef struct T_PaptUpdataStruct
{
    UINT32            chanSelect;          /*选取相应通道*/
    T_RfPaptCfgUpdata updataCfgPara;            /*中频功放保护数据更新*/
}T_PaptUpdata; /**功放保护参数配置*/

typedef struct T_PaptCrmCfgStruct
{
    UINT32  openCrmPaDaFlag; /*是否支持CRM PaDa关断*/
    UINT32  openOptPaDaFlag; /*是否支持Opt PaDa关断*/
    UINT32  crmPaMask;    /*关PA掩码*/
    UINT32  crmDaMask;    /*关数据掩码*/
    UINT32  crmEnMask;    /*告警生效掩码*/
    UINT32  crmReportMask;    /*告警上报掩码*/
}T_PaptCrmCfg; /**功放保护CRM参数配置*/

UINT32 BspClrAllDpdicAlmStatus(void);
UINT32 BspPaptCfgInit(Papt_Opt_Cfg_Info *optCfgInfo);
UINT32 BspUpdatePaptInitInfo(void);
UINT32 BspSecondaryUpdatePaptInit(void);
UINT32 BspPaptCfgUpdate(UINT32 bspChan, T_RfPaptCfgUpdata *para);
UINT32 BspSetPaptCrmMask(T_PaptCrmCfg *paptCrmCfg);
UINT32 BspSetDifPaOffOptAlmMaskPaptCfg(UINT32 ulRegVal);
INT32 BspGetCfrAvgThrDelta(UINT32 bspChn);
INT32 BspGetDpdAvgThrDelta(UINT32 bspChn);
UINT32 BspUpdatePaptPowInfo(UINT32 bspChan, UINT32 cfgType, UINT32 paproType, INT32 para);
VOID BspSetPaptNcrFlag(UINT32 ulflag);
#ifdef __cplusplus
}
#endif

#endif /* _BOARD_HARD_ID_ */



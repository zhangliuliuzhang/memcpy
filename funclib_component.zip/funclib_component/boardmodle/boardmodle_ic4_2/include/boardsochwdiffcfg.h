
#ifndef _BOARD_SOC_HW_DIFF_CFG_H_
#define _BOARD_SOC_HW_DIFF_CFG_H_

#ifdef __cplusplus 
extern "C" { 
#endif


#define  SOC_HWVERSION_OFFSET (200)

/* SOC硬件差异类型选择 */
enum E_SOC_HW_DIFF_TYPE
{
    E_SOC_HW_DIFF_NUM_3   = 0,   /* 共3片SOC，每片都是不同配置 */
    E_SOC_HW_DIFF_NUM_2,         /* 共2片SOC，每片都是不同配置 */
    E_SOC_HW_DIFF_NUM_1,         /* 共1片SOC */
    E_SOC_HW_DIFF_NUM_4,         /* 共4片SOC */
    E_SOC_HW_DIFF_NUM_5,
    E_SOC_HW_DIFF_NUM_6,
    E_SOC_HW_DIFF_TYPE_MAX
};

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspSetDiffSocCfg(UINT32 ulChipIdx,  UINT32 *pHwCfg);
UINT32 BspSetBoardSocHwDiffType(UINT32 boardSocType, UINT32 maxOffset);


#ifdef __cplusplus
}
#endif

#endif /* _BOARD_SOC_HW_DIFF_CFG_ */




#ifndef _DIGTRXLINK_WRAPPER_H_
#define _DIGTRXLINK_WRAPPER_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
/**************************************************************************
 *                        宏
 **************************************************************************/


/**************************************************************************
 *                                枚举定义
 **************************************************************************/
 


/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef UINT32 (*HGOptInitCheckCall)(void);


/**************************************************************************
*                         函数声明
**************************************************************************/

UINT32 BspDpdIcDifClkParaInit(VOID);
UINT32 BspDpdIcDifSamRateParaInit(VOID);
UINT32 BspDpdIcDifInitParaInit(VOID);
UINT32 BspDpdIcDifResAllocParaInit(VOID);

/* 下行静态路由初始化 */
UINT32 BspDpdicTxRouteMapInit(VOID);

/* 下行静态路由参数初始化 */
UINT32 BspDpdicTxRouteParaInit(VOID);

/* 下行J204路由参数初始化 */
UINT32 BspDpdicTxJ204RouteMapInit(VOID);
/* 上行静态路由参数初始化 */
UINT32 BspDpdicRxRouteMapInit(VOID);


/* 反馈静态路由参数初始化 */
UINT32 BspDpdicFbRouteMapInit(VOID);
/* 中频Hal初始化 */
UINT32 BspDpdicDifHalInit(VOID);

/* 下行帧头信息初始化*/
UINT32 BspDpdicDifFrameHeaderInit(VOID);
UINT32 BspDpdicDifTddCfg(void);
UINT32 BspDpdicOptCpriParaInit(VOID);
UINT32 BspDpdicOptCpriInit(VOID);
UINT32 BspDpdicOptMeasParaInit(VOID);
UINT32 BspDpdicOptCfgParaInit(VOID);
UINT32 BspSetRecoveryFlag(UINT32 flag);
UINT32 BspGetRecoveryFlag(void);
/* J204c 建链参数初始化 */
UINT32 BspJ204LinkInit(VOID);

/* J204c SYSREF参数初始化 */
UINT32 BspJ204SysrefInit(VOID);
/* 光模块配置参数初始化 */
#ifndef MULT_PROGRESS_S
UINT32 BspSfpCfpParaInit(VOID);
#endif

/* J204c SYSREF参数初始化 */
UINT32 BspJ204SerdesTxEqInit(VOID);

/* J204c Transceiver回调挂接 */
UINT32 BspJ204TrxCallBackInit(VOID);

/* 光口serdes初始化 */
UINT32 BspNtlTxInit(VOID);
UINT32 BspNtlRxInit(VOID);
/*光口建链相关配置*/
UINT32 BspOptBootpInit(VOID);
UINT32 BspNtlRxInit_S(VOID);
UINT32 BspBoardInnerCpriSpeedCfg(VOID);
UINT32 BspInnerSerdesRxMonitor(VOID);
UINT32 BspJ204LinkMapInit(VOID);
UINT32 BspSetHGOptInitCallBack(HGOptInitCheckCall HGOptInitFlag);
UINT32 BspSetNtlL2ssTrxpEnOrDisBitmap(UINT32 mode);
UINT32 BspSetDefMainPhyOpt(UINT32 optNo);
UINT32 BspDpdicOptCellInit(VOID);
#ifdef __cplusplus
}
#endif

#endif /* _DIGTRXLINK_WRAPPER_H_ */



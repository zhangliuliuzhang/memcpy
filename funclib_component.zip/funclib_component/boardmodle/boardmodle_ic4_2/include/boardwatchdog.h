#include "pub_basetypedef.h"


/**************************************************************************
 *                        宏定义                                              
 **************************************************************************/
#define FPGA_WDG_OUTTIME_UNIT_MS       (UINT32)(5369) // 外部看门狗喂狗超时配置寄存器单位时间5.369s


/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数接口
 **************************************************************************/
UINT32 BspFpgaWatchDogFeed(VOID);
UINT32 BspFpgaWatchDogEnable(VOID);
UINT32 BspFpgaWatchDogDisable(VOID);
UINT32 BspSetFpgaWatchDogTime(UINT32 ulTimerValue);
UINT32 BspSetSupportFpgaWatchDogFlag(BOOL isSupportFlag);
BOOL BspIsSupportFpgaWatchDog(VOID);
UINT32 BspWatchDogInit(void);
UINT32 BspMcuWatchDogFeed(void);

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

void BspShowM0DebugMap(void);
void BspSetM0DebugMap(void);

/* Started by AICoder, pid:961eev3470m119014d3c0afb107842026456564d */
#define INPUT_POINTER_CHECK_JSON(ppointer, DebugMapStruct)                 \
    if ((NULL == ppointer) || (0 == cJSON_IsString(ppointer)))             \
    {                                                                      \
        free(DebugMapStruct);                                              \
        return;                                                            \
    }
/* Ended by AICoder, pid:961eev3470m119014d3c0afb107842026456564d */

/* Started by AICoder, pid:h42244bbdcp43df14298091030a6cc1389a2430b */
// 新增宏定义，用于检查strtol的返回值
#define INPUT_VALUE_CHECK_STRTOL(item, field, struct_field) \
    do { \
        char *endptr; \
        errno = 0; \
        long val = strtoul(item->valuestring, &endptr, 0); \
        if ((ULONG_MAX == (val)) && (errno == ERANGE)) { \
            dbgErr("Invalid value for %s: %s\n", #field, item->valuestring); \
        } \
        struct_field = (UINT32)val; \
    } while (0)
/* Ended by AICoder, pid:h42244bbdcp43df14298091030a6cc1389a2430b */
#ifdef __cplusplus
}
#endif
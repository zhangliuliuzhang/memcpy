
#ifndef _RFTABLEINIT_H_
#define _RFTABLEINIT_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
#include "rftable_common.h"

/**************************************************************************
 *                        宏
 **************************************************************************/
#define _FILE_INF(name)       "/ata/cali/"#name, "/tmp/cali/"#name
#define CHAN_PRO_MAX       8
/**************************************************************************
 *                                枚举定义
 **************************************************************************/
enum
{
    E_PROP_FLASH = 0,
    E_PROP_PA,
    E_PROP_BOARD,
    E_PROP_NUM
};


/**************************************************************************
 *                         数据类型
 **************************************************************************/
#pragma pack(4)
typedef struct tagTRfTblFileMenu
{
    UINT32 ulFileType;
    UINT32 ulFileProp;
    UINT32 ulLoadState;
    UINT32 ulIsErrAlm;
    UINT32 ulSubFileNum;
    CHAR  *pAtaFile;
    CHAR  *pFsFile;
    UINT32 ulChanPro;
    UINT32 (*pTblConvert)(UINT32 ulSubFileNo,UINT32 ulIniChan,UINT32 dstChan, UINT32 ulChanNum);
}T_RfTblFileMenu;
#pragma pack()

typedef struct tagRfTblChanPro
{
    UINT32 ulSubFileNo;
    UINT32 ulChanPro;
    UINT32 ulIniChan;
    UINT32 ulChanNum;
    UINT32 dstChan;
}T_RfTblChanPro;

typedef struct tagRfTblConvert
{
    UINT32 ulRpuId;
    T_RfTblChanPro tChanPro[CHAN_PRO_MAX];
}T_RfTblConvert;

typedef struct tagRfTblChipMap
{
    UINT32 ulRpuId;
    UINT32 ulSubFileNo;
    UINT32 ulRelativeChip;
    UINT32 ulAbsoluteChip;
}T_RfTblChipMap;



/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspRfTblInit(VOID);
UINT32 BspSetRfConvertTbl(T_RfTblConvert *pPara, UINT32 num);
UINT32 BspSetRfChipMapTbl(T_RfTblChipMap *pPara, UINT32 num);
UINT32 BspRfTblLoad(T_RfTblFileMenu *pPara, UINT32 num);
UINT32 BspRfTblConvert(UINT32 ulFileInex, UINT32 ulRpuId, UINT32 ulChanPro);
UINT32 GetRfTblConvertValByChanPro(UINT32 ulLoop, UINT32 ulChanPro,UINT32 *pSubFileNo,UINT32 *pIniChan, UINT32 *pChanNum, UINT32 *pDstChan);
UINT32 BspRenamePaTbl(UINT32 index);
UINT32 BspSaveRfTblFileInfo(T_RfTblFileMenu *pPara, UINT32 num);
UINT32 BspGetRfTblInitFile(T_CaliTblInitFile *ptFileInfo);
UINT32 BspSetRfTblLoadStaBySlavePortCfg(UINT32 portId);
VOID BspInitSlaveRfTblLoadSta(VOID);
VOID BspClrRfTblLoadStaBySlavePortCfg(UINT32 portId );
#ifdef __cplusplus
}
#endif

#endif /* _RFTABLEINIT_H_ */



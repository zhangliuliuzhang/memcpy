#ifndef _HARDFEATURE_WRAPPER_VER_MANAGE_H_
#define _HARDFEATURE_WRAPPER_VER_MANAGE_H_

#ifdef __cplusplus 
extern "C" { 
#endif

UINT32 BspInitVerProtect(VOID);
UINT32 BspInitProtectFileList(VOID);

#ifdef __cplusplus
}
#endif

#endif /* _HARDFEATURE_WRAPPER_VER_MANAGE_H_ */



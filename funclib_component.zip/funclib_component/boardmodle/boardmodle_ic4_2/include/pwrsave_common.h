/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pwrsave_common.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了通道关断，载波关断的节能接口声明
* 注意事项 : 无
* 作    者 :   10248577
* 创建日期 : 2022-11-10
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 2022-11-10
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _PWRSAVE_COMMON_H_
#define _PWRSAVE_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"
#include "funccommon_log.h"

#define FastAdjVoltAblInfo      T_FastAdjVoltAblInfo
 /*时隙调压：硬件最大挡位以及功率最大支持挡位*/
#define MTS_RESET_BY_FPGA_FlAG (1)
#define FAST_ADJUST_VOLT_GPIOREGLEVEL_MAX_NUM (16)
#define FAST_ADJUST_VOLT_LEVEL_MAX_NUM (8)
#define FAST_ADJUST_VOLT_HARD_GPIONUM (4)
#define ONE_PWR_GROUP (1)
#define PWR_GROUP_CHAN_MASK (0xff)
#define GROUP_ID_ZERO (0)
#define PWRMODULE_FASTADJUSTVOLT_ABLITY (6000)      /*调压步进能力为6V/500us*/
#define PWRMODULE_FASTADJUST_DELAY_20MS (20)
#define PWRMODULE_FASTADJUST_DELAY_10MS (10)
#define PWRMODULE_FASTADJUST_CHANMASK_MAXARRAY_SIZE (4) /* 电源组下对应的通道掩码数组大小 */
#define BOARD_SUPPORT_FASTADJVOLT (1)
#define BOARD_DONOT_SUPPORT_FASTADJVOLT (0)
#define GPIO_BASE_ADRS (0xD6400000)
//#define MSG_DSP_CH_MAX (32)
#define MSG_GAIN_TUNE_TEMP_NUM_MAX (20)  /*按-40~150每10度一个温度，总共是是20个*/
#define MSG_GAIN_TUNE_INFO_NUM (3)  /*增益补偿值、相位补偿值、有效标志*/

#define INDEX_RANGE_CHECK(ParamVal, MaxVal)              \
{                                                        \
    if ((ParamVal) > (MaxVal))                           \
    {                                                    \
        dbgInfo("%s>>Error!Param Over; Idx(0~%d)= %d\n", \
                __FUNCTION__, (MaxVal), (ParamVal));     \
        return BSP_ERROR;                                \
    }                                                    \
}


#define UPARA_CHECK(a,start,end)         \
{                                        \
    if ((a) > (end))                     \
    {                                    \
        dbgErr("para check error,"#a"=%d\n",(a));\
        return BSP_ERROR;                \
    }                                    \
}
typedef struct tag_FastAdjVoltFileInfo
{
    INT32 maxVoltVal;           /*最大电压档位，单位mV*/
    INT32 minVoltVal;           /*最大电压档位，单位mV*/
    BYTE MaxDelay;               /*[0,255],单位ms */
    BYTE FastAdjVoltGroup;       /*[0,2]*/
    BYTE Group0LevelNum;         /* 调压组0的档位数,[0,8] */
    BYTE Group0PwrLevel[8];      /* 调压组0功率档位,[0,100]，单位% */
    BYTE Group1LevelNum;         /* 调压组1的档位数,[0,8] */
    BYTE Group1PwrLevel[8];      /* 调压组1功率档位,[0,100]，单位% */
    BYTE resv[4];
} T_FastAdjVoltFileInfo;

typedef struct tag_FastAdjVoltAblInfo
{
    BYTE MaxDelay;               /*[0,255],单位ms */
    BYTE FastAdjVoltGroup;       /*[0,2]*/
    BYTE Group0LevelNum;         /* 调压组0的档位数,[0,8] */
    BYTE Group0PwrLevel[8];      /* 调压组0功率档位,[0,100]，单位% */
    BYTE Group1LevelNum;         /* 调压组1的档位数,[0,8] */
    BYTE Group1PwrLevel[8];      /* 调压组1功率档位,[0,100]，单位% */
    BYTE resv[4];
} FastAdjVoltAblInfo;

/**************************************************************************
 *                         数据类型
 **************************************************************************/




/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspSetIcDeepSleepCtrl(UINT32 sw);
UINT32 BspPwrSavePaGridVoltSwitch(UINT32 sw);
UINT32 BspResetTransceiver(VOID);
UINT32 BspPwrSaveDpdChanSwitch(UINT32 chanMask, UINT32 sw);
UINT32 BspPwrsveSerdesAllPowerDown(VOID);
UINT32 BspPwrSavePaVoltCtrl(UINT32 ctrl);
UINT32 BspSetTxRfPwrSaveSwitch(UINT32 rfChan, UINT32 sw);
UINT32 BspSetRxRfPwrSaveSwitch(UINT32 rfChan, UINT32 sw);
UINT32 BspGetPwrSaveMode(VOID);
UINT32 BspSetPwrSaveMode(UINT32 mode);
VOID DbgSaveDeepSleepStatus(UINT32 sw);
VOID DbgSaveDtxEnableStatus(UINT32 bspChan, UINT32 sw);
VOID DbgSaveDtxRouteStatus(UINT32 bspChan, UINT32 carrId, UINT32 on);
VOID DbgClrDtxRouteStatus(VOID);
UINT32 BspGetPaEnergySaveStdInfo(VOID);
UINT32 BspSendSlotVoltGrpInfoToDpd(VOID);
UINT32 BspSetTrappingTblPreInit(VOID);
UINT32 BspSetGainTuneTblInit(VOID);
VOID BspTransIQValue(FLOAT* pValue);
UINT32 ShowGainTuneTableByChan(UINT32 chan);
UINT32 ShowFastPwrAdjTrainingTable(UINT32 chan);
UINT32 BspGetDeepSleepStatus(VOID);
UINT32 BspSetRruAllChanPaVolt(INT32 volt);
UINT32 BspSetIcDeepSleepCtrlSwitch(UINT32 ctrl);
UINT32 BspSetPaVoltCtrl();
UINT32 BspSetPwrLowStaSwitch(UINT32 sw);
UINT32 BspShutdownTransceiver(VOID);
UINT32 BspSetMtsResetByFpgaFlag(UINT32 flag);
UINT32 BspGetMtsResetByFpgaFlag(VOID);

#ifdef __cplusplus
}
#endif
#endif 


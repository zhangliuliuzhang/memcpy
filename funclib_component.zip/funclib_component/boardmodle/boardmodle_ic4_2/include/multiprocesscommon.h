
#ifndef _MULTI_PROCESS_COMMON_H_
#define _MULTI_PROCESS_COMMON_H_

#ifdef __cplusplus 
extern "C" { 
#endif


#ifdef __cplusplus
}
#endif

#endif /* _MULTI_PROCESS_COMMON_H_ */

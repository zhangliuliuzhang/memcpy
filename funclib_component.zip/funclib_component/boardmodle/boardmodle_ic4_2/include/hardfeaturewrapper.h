#ifndef _HARDFEATURE_WRAPPER_H_
#define _HARDFEATURE_WRAPPER_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "hardfeaturewrapperbase.h"
#include "hardfeaturewrapperrfctrl.h"
#include "hardfeaturewrappervermanage.h"

#ifdef __cplusplus
}
#endif

#endif /* _HARDFEATURE_WRAPPER_H_ */



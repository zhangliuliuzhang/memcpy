
#ifndef _HARDFEATURE_WRAPPER_RF_CTRL_H_
#define _HARDFEATURE_WRAPPER_RF_CTRL_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
#include "papt_api.h"
#include "ichaladapt_ic4_2.h"
#include "chnmap_a.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "rftable.h"
#include "rruinfo.h"
/**************************************************************************
 *                        宏
 **************************************************************************/

#define RFTBL_DIR_IN_DDR      "/tmp/cali"
#define CRM_SHM_KEY "/ata"
/**************************************************************************
 *                                枚举定义
 **************************************************************************/


/**************************************************************************
 *                         数据类型
 **************************************************************************/

/* 多片SOC硬件配置差异初始化 */
typedef struct tagT_BoardSocHwDiffCfg
{
    UINT32 boardSocType;
    UINT32 maxOffset;
}T_BoardSocHwDiffCfg;

typedef struct tagT_BoardSecIdPropertyInfo
{
    UINT32 ulSecLgcId;/*二级单板ID*/
    TRruDeviceUpdateInfo tRruDeviceUpdateInfo[MAX_ITEM_NUM];
}T_BoardSecIdPropertyInfo;

typedef struct tagT_BoardProPertyUpdateInfo
{
    UINT32 ulBrdLgcId;/*一级单板ID*/
    T_BoardSecIdPropertyInfo tBoardSecIdPropertyInfo[MAX_SUBID_NUM];
}T_BoardProPertyUpdateInfo;

typedef struct
{
    UINT32 paVoltNum;
}T_PaVoltNum;

typedef UINT32 (*pDPDPowerChange)(INT32* DPDGainChange);
typedef UINT32 (*FUNC_POST_INIT_RFTBL)(VOID);
typedef UINT32 (*pPaVoltUpdateFunc)(UINT32 chan, UINT32 volt);
/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspInitTempUpdateThread(void);
UINT32 BspCommonThreadInit(void);
UINT32 BspInitPaPtPara(void);
UINT32 BspBoardLinkInfoInit(VOID);
UINT32 BspSetHardFeatureCallback(VOID);
UINT32 BspInitI2c(void);
UINT32 BspInitSpi(void);
UINT32 BspDrvTblInit(VOID);
UINT32 BspRfTblInit(VOID);
UINT32 BspRfTblGainModify(VOID);
UINT32 BspRfTblPostInit(VOID);
UINT32 BspRfTblPostInitCallBack(FUNC_POST_INIT_RFTBL func);
UINT32 BspPreInitSocHwCfg(VOID);
UINT32 BspTftpRfTblGetInit(VOID);
UINT32 BspUartCfgDataInit(VOID);
UINT32 BspNsbtMapInit(VOID);
UINT32 BspTddIoCtrlInit(VOID);
UINT32 BspBoardTddIoLinkInfoInit(VOID);
UINT32 BspAntPowerInit(VOID);
UINT32 BspCheckPllLdCallBackInit(void);
UINT32 BspPowOnOffInit(void);
UINT32 BspPaDefaultVoltInit(VOID);
UINT32 BspPaDefaultVoltInitByChan(UINT32 chan);
UINT32 BspSetPwrCfgParaInit(void);
UINT32 BspSetPwrSupplyAbilityParaInit(VOID);
UINT32 BspSetPwrInputCrrentParaInit(VOID);
UINT32 BspSetPwrTempAlarmThresholdValue(VOID);
UINT32 BspPaptCfgInfoInit(void);
UINT32 BspUpdatePaptPara(UINT32 difChan, T_BspHalAdaptPaptParaCfg *paptPara);
UINT32 BspInitPaptUpdata(void);
UINT32 BspPaptCrmInfoInit(void);
UINT32 BspPOwerAdjustDeltaInit(void);
UINT32 BspUseStaticDevIdInit(VOID);
UINT32 BspInitOptStatusThread(VOID);
UINT32 BspBoardChanRfTblParaInit(void);
UINT32 BspBoardChanRfTblPara1Init(void);
UINT32 BspInitAntiTamper(VOID);
UINT32 BspRegisterGetDPDGainAdjustFunc(pDPDPowerChange pGetDPDChange);
UINT32 BspUpdateAvgPowInfo(UINT32 difChan, UINT32 updateflag, T_BspHalAdaptPaptCfrCfg *paptCfrPara, T_BspHalAdaptPaptDpdCfg *paptDpdPara);
UINT32 BspUpdateRfTblInfo(T_CaliTblInfoUpdate *pPara, UINT32 num);
UINT32 BspRegisterPaVoltUpdateCall(pPaVoltUpdateFunc updateCall);
UINT32 BspGetAppCfgMap(T_RU_LINK_MAP_APP_CFG **ppMap, UINT32 *pMapNum);
UINT32 BspBoardFwdLinkInfoInit(VOID);
UINT32 BspRruTempOffsetInit(VOID);
UINT32 BspPwrOverTempDeratingInit(VOID);
UINT32 BspSetSecondUpdatePaVolt(UINT32 chan, UINT32 volt);
VOID BspSetHardFeatureWapperRfCtrlNcrFlag(UINT32 ulflag);
UINT32 BspNsbtCtrlDelayOptmimiza(VOID);
UINT32 BspRruPowerConstraintCfgInit(VOID);
void BspSetRuPaBaseInfoByRfTbl(void);
#ifdef __cplusplus
}
#endif

#endif /* _HARDFEATURE_WRAPPER_RF_CTRL_H_ */



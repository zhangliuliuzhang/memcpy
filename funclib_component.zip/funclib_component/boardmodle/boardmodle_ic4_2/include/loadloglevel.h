#ifndef LOADLOGLEVEL_H
#define LOADLOGLEVEL_H


#define AREA_LOG_KEY             "LOG_%s_LEVEL"
#define AREA_LOG_PRINT_DIR       "%s_LOG_PRINT_DIRECTORY_FLAG"


typedef enum AREA_LOG
{
    LOG_APP = 0,
    LOG_OSS = 1,
    LOG_BSP = 2,
    LOG_HAL = 3,
    LOG_OPT = 4,
    LOG_DSP = 5,
}areaLog;


UINT32 readAreaLogLevel(CHAR *area, UINT32 *pulAreaLogLevel, UINT32 type);
UINT32 BspAddLogLevels(VOID);
UINT32 BspSetAreaLogLevel(UINT32 area,UINT32 logLevel);
UINT32 SetLogDir(UINT32 area,UINT32 flag);


#endif

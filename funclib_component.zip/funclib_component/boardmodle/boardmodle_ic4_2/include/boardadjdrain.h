/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardadjdrain.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了例化单板的TDD静态调压的接口实现
* 注意事项 : 无
* 作    者 :   10102065
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10102065
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _BOARD_ADJDRAIN_H_
#define _BOARD_ADJDRAIN_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "rftable_padrainadj.h"
/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef UINT32 (*pPaGridAdjFunc)(void);
# define MAX_ADJ_GROUP_NUM              (4)
typedef struct _T_AdjChanGroupInfo {
    UINT32 s_dualPwrFlag;                          /* 多电源模块标志 */
    UINT32 adjChanGroupMask[MAX_ADJ_GROUP_NUM];      /* 多电源模块对应调压通道掩码 */
    UINT32 pwrNum;                                 /*电源模块的个数 一拖三机型每个子端相当于一个电源*/
    UINT32 pwrType[MAX_ADJ_GROUP_NUM];             /* 多电源模块供电类型，只有9124特殊子母端端供电有差异设置漏压要区分接口 0默认用原始接口设置漏压*/
} T_AdjChanGroupInfo;


/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspSetPaDrainAdjPaVoltWarnClear(VOID);
UINT32 BspPaDrainAdjSetPaVoltWarnStatus(UINT32 *ulPaVoltSetStatus);
UINT32 BspGetParAdjChan(UINT32 ulRecordNum, TPaDrainAdjPathRecord *ptRecord, UINT32 ulPwrAvgRatGet, UINT32 *ulParChan, UINT32 *ulPaDrainVoltGet, UINT32 ulchan);
UINT32 BspGetPaAdjVolt(UINT32 ulPaPwrMax, UINT32 ulParChan, INT32* ulPaVolt, TPaDrainAdjPathRecord *ptRecord);
UINT32 printGetCfrGatePara(UINT32 chan);
UINT32 BspGetCurrCfrGate(UINT32 chanNo, UINT32 currChanPwrDbm, UINT32 *pDefCfrGate, UINT32 *pCurrCfrGate);
UINT32 BspGetCurrCfrGateByLevel(UINT32 chanNo, UINT32 level, UINT32 currChanPwrDbm, UINT32 *pDefCfrGate, UINT32 *pCurrCfrGate);
UINT32 BspGetPaChanPwrDbm(UINT32 chanNo, UINT32 currChanPwrMw, UINT32 *currChanPwrDbm);
UINT32 BspSetPaVoltByGpio(UINT32 ulLevel);
UINT32 BspInitAntPwrPre(VOID);
UINT32 BspPaGridVoltAdjByFile(UINT32 chanNo, INT32 powerDbm);
UINT32 BspPaGridVoltAdjByFileTxAtt(UINT32 chanNo, INT32 powerDbm);
UINT32 BspRegisterPaGridAdj(pPaGridAdjFunc pGridAdjCall);
UINT32 BspSetPwrIndexFlag_TF(VOID);
UINT32 BspSetDoublePwrIndexFlag(T_AdjChanGroupInfo *pAdjChanGroupInfo);
#ifdef __cplusplus
}
#endif
#endif 



#ifndef _SOFTSERVICE_WRAPPER_RF_CTRL_H_
#define _SOFTSERVICE_WRAPPER_RF_CTRL_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"
#include "board_ic4_2.h"
/**************************************************************************
 *                        宏
 **************************************************************************/
#define RFTBL_DIR_IN_FLASH    "/ata/cali"
#define RFTBL_DIR_IN_DDR      "/tmp/cali"
/**************************************************************************
 *                                枚举定义
 **************************************************************************/
 


/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef struct
{
    const char *ethName;
    unsigned char *ipAddr;
    unsigned char *netMask;
    unsigned char *macAddr;
} T_InnerIpInfo;

typedef struct
{
    T_InnerIpInfo *ipInfoPara;
    UINT32 ipInfoNum;
    const char **routePara;
    UINT32 routeNum;
    const char **arpPara;
    UINT32 arpNum;
} T_InnerNetInfo;

/**************************************************************************
*                         函数声明
**************************************************************************/
VOID BspCevaArpInit(VOID);
UINT32 BspUartInit(VOID);
UINT32 BspLoadFlashInfoToMem(VOID);
UINT32 BspInnerNetL2ssInit(void);
UINT32 BspInnerNetCfg(void);
UINT32 BspInitRruFormPara(void);
UINT32 BspReadGpio0Status(VOID);

#ifdef __cplusplus
}
#endif

#endif /* _SOFTSERVICE_WRAPPER_RF_CTRL_H_ */



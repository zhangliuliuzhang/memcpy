
#ifndef _HARDFEATURE_WRAPPER_H_
#define _HARDFEATURE_WRAPPER_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "ichaladapt_ic4_2.h"
/**************************************************************************
 *                        宏
 **************************************************************************/
#define MAX_SGMII_LANE_ERR_CNT  (6)

/**************************************************************************
 *                                枚举定义
 **************************************************************************/
 


/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef struct  T_optSerdesPcsMap {
	UINT32 optNo[OPT_PCS_LANE_MAX_NUM];
	UINT32 laneId[OPT_PCS_LANE_MAX_NUM];  /*和ic确认pcs和serdes的lane肯定是一一对应的*/
} T_optSerdesPcsMap;

typedef struct tagT_OnlineCpriModeSwitchCfgInfo
{
    UINT32 isNeedCpriSwitch; //是否需要cpri切换
    UINT32 upLinkOptNoMask;      //上联口
    UINT32 downLinkOptNoMask;    //下联口
    UINT32 isNeedCfgXmac;    //是否需要配置xmac以及trx内端口
    UINT32 routePath;        //通路编号
}T_OnlineCpriModeSwitchCfgInfo;

/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspNtlInit(T_OPT_SERDES_PCS_PARAM *pPara);
UINT32 BspOptSerdesRxInitWithRetry(UINT32 maxRetryTime);
VOID BspSetOptSerdesPcsMap(T_optSerdesPcsMap *pMap);
UINT32 BspGetInnerLaneMask(VOID);
void BspInnerSerdesRxMonitorThread(VOID);
UINT32 BspQsfpNtlInit(UINT32 laneId);
UINT32 BspNaccXmacInit(UINT32 xmacId);
UINT32 BspNtlInitForSgmii(VOID);
UINT32 BspNtlInitSetTrxpXmacEn(UINT32 enSw);
UINT32 BspSetInnerSerdesMonitorSw(UINT32 lanemask);
UINT32 BspReCfgOptInnerRxSerdes(UINT32 serdesId, UINT32 laneId);
UINT32 BspNtlPcsRxReset(UINT32 laneId);
UINT32 BspNtlPcsReCfg(UINT32 laneId);
UINT32 BspNtlInitByLane(UINT32 laneId);
UINT32 BspInnerSdrRxCheckOff(VOID);
UINT32 BspCpriModeNtlSoftInit(VOID);
UINT32 BspCpriModeNtlSoftInitNew(T_OPT_SERDES_PCS_PARAM *pParaExt);
UINT32 BspSetOnlineCpriModeSwitchCfgInfo(T_OnlineCpriModeSwitchCfgInfo *cfgInfo);
UINT32 BspGetOnlineCpriModeSwitchCfgInfo(T_OnlineCpriModeSwitchCfgInfo *cfgInfo);
UINT32 BspSetOnLneCpriModeSwitchInThread(UINT32 sw);
UINT32 BspGetOnlineCpriModeSwitch(UINT32 *sw);
UINT32 BspSocInnerSerdesLaneRateSwitch(VOID);
UINT8 BspGetCpriSwitchRec(VOID);
UINT32 BspGetRruSysPllStatus(UINT8 *pClkSta, UINT8 *pOptSta, UINT8 *pCpriSwRec);
UINT32 BspNaccXmacInitNcr(UINT32 xmacId);
UINT32 BspQsfpNtlInitNcr(UINT32 laneId);
UINT32 BspCfgMaxDelay2Point(VOID);
UINT32 BspSetMultSerdesRxInit(UINT32 ulPhyOpt);
#ifdef __cplusplus
}
#endif

#endif /* _HARDFEATURE_2WRAPPER_H_ */



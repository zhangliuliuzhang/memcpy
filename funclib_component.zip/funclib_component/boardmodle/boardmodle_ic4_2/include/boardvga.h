/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : boardvga.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了VGA控制模块，IC4.2单板的结构体、变量、参数配置
* 注意事项 : 无
* 作    者 : 
* 创建日期 : 2022-06-11
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 
* 修改日戳: 2022-06-11
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _BOARDVGA_H_
#define _BOARDVGA_H_
#include "bsppub.h"
#include "bspcommon.h"
#include "ichaladapt_ic4_2.h"

#ifdef __cplusplus
extern "C" {
#endif

/*---------------------------------------------------------*/
/*                        宏定义                           */
/*---------------------------------------------------------*/
#define SLICER_MAP_LEN (64)
#define MTS_MAX_CHIP_NUM  4        /* 最大mts芯片数 */

#define IF_VGA_SPI0         0        /* 中频rfbus总线0 */
#define IF_VGA_SPI1         1        /* 中频rfbus总线1 */
#define RF_VGA_SPI0         0        /* 射频rfbus总线所对应的外挂器件0 */
#define RF_VGA_SPI1         1        /* 射频rfbus总线所对应的外挂器件1 */
#define IF_SPI_BUS          0        /* 中频SPI总线 */
#define RF_SPI_BUS          1        /* 射频SPI总线 */
#define RF_SPI_BUS_RATE_3   3        /* 射频总线速率。3:7.68Mhz */

/*---------------------------------------------------------*/
/*                        数据类型                         */
/*---------------------------------------------------------*/

/****** VGA Slice 传输方式 ******/
typedef enum TagE_SlicerTransType
{
    SLICE_TRANS_GPIO = 0,
    SLICE_TRANS_J204_Port,
    SLICE_TRANS_J204_Data
} E_SlicerTransType;

typedef enum TagE_SliceTransMode
{
    SLICE_TRANS_TWO_BIT = 0, /* 0-14bit数据+2bit silcer因子 */
    SLICE_TRANS_ONE_BIT      /* 1-15bit数据+1bit silcer因子 */
} E_SliceTransMode;

/****** 策略表参数 ******/
typedef struct tagMgcSheet
{
    UINT32 difChn;                   //中频通道号
    UINT32 *sheetTab;                //策略表数组
    UINT32 sheetLen;                 //表长度
}T_MgcSheet; 

/****** 中频总线参数表 ******/
typedef struct tagIfBusParaTbl
{
    UINT32 ifSpiNo;                        //中频ifbus总线索引，取值0~1
    T_BspHalAdaptIfBusPara *ifBusParaTbl;  //参数表
}T_IfBusParaTbl; 

/****** 射频总线参数表 ******/
typedef struct tagRfBusParaTbl
{
    UINT32 rfSpiNo;                  //射频rfbus总线索引，取值0~1
    UINT32 rfBusRate;                //射频总线速率（0:61.44Mhz, 1:30.72Mhz, 2:15.36Mhz, 3:7.68Mhz）
}T_RfBusParaTbl; 

/****** VGA器件真值表 ******/
typedef struct tagRealValTbl
{
    UINT32 spiNo;                    //射频rfbus总线索引，取值0~1
    UINT32 *realVal;                 //真值表数组
    UINT32 tblLen;                   //真值表长度
}T_RealValTbl; 

typedef struct tagVgaRealValTbl
{
    UINT32 spiFlag;                  //总线类型（中频或射频）
    T_RealValTbl *valTbl;            //Att寄存器初始化参数表
    UINT32 tblNum;                   //真值表数量
}T_VgaRealValTbl; 

/****** 射频总线上外挂衰减器初始化配置参数 ******/
typedef struct tagRfAttInitPara
{
    UINT32 difChn;                   //中频通道号
    UINT32 addr;                     //寄存器地址
}T_RfAttInitPara; 

typedef struct tagRfAttInitTbl
{
    UINT32 rfSpiNo;                 // 射频rfbus总线索引，取值0~1
    UINT32 rftblLen;                // 寄存器表长度
    T_RfAttInitPara *rfAttTbl;      // Att寄存器初始化参数表
}T_RfAttInitTbl; 

/****** 中频通道至中频、射频VGA寄存器地址的路由关系 ******/
typedef struct tagBusAddrRoute
{
    UINT32 difChn;                   //中频通道
    UINT32 addr;                     //器件地址
}T_BusAddrRoute; 

typedef struct tagAddrRoute
{
    UINT32 spiNo;                     //总线索引，取值0~1
    T_BusAddrRoute *Tbl;               //路由表数组
    UINT32 Len;                       //路由表长度
}T_AddrRoute; 

typedef struct tagVgaBusAddrRoute
{
    UINT32 spiFlag;                  //总线类型（中频或射频）
    T_AddrRoute *route;               //总线路由表，类spi模式需关注通道配置，spi2模式需要关注地址配置
    UINT32 Num;                      //路由表数量
}T_VgaAddrRoute; 

/****** 中频通道至中频、射频VGA器件通道的路由关系 ******/
typedef struct tagBusChnRoute
{
    UINT32 difChn;                   //中频通道
    UINT32 vgaCh;                    //VGA器件通道
}T_BusChnRoute; 

typedef struct tagChnRoute
{
    UINT32 spiNo;                     //总线索引，取值0~1
    T_BusChnRoute *Tbl;               //路由表数组
    UINT32 Len;                       //路由表长度
}T_ChnRoute; 

typedef struct tagVgaBusChnRoute
{
    UINT32 spiFlag;                  //总线类型（中频或射频）
    T_ChnRoute *route;               //总线路由表，类spi模式需关注通道配置，spi2模式需要关注地址配置
    UINT32 Num;                      //路由表数量
}T_VgaChnRoute; 

typedef struct tagInitInfo
{
    UINT32 Num;                   //初始化寄存器总个数
    UINT32 bitnum;                //时序位宽
    T_UniSpiReg *spireg;          //初始化配置
}T_VgaFpgaCtrlInfo;

typedef UINT32 (*vga_MTS_SwitchAgc)(INT32 chip,UINT32 vgaMode);
typedef UINT32 (*vga_ADI_SwitchAgc)();
typedef UINT32 (*vga_TI_SwitchAgc)(UINT32 mode);

/*---------------------------------------------------------*/
/*                        函数声明                         */
/*---------------------------------------------------------*/
UINT32 BspVgaAgcCfgInit(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCompPara *pVgaCompPara);
UINT32 BspVgaMgcCfgInit(T_BspHalAdaptVgaCtrlComPara *pVgaCtrlPara, T_BspHalAdaptVgaCtrlMgcPara *pVgaCtrlMgcPara, T_BspHalAdaptVgaCompPara *pVgaCompPara);
UINT32 BspStopAgcCtrl(VOID);
UINT32 BspGetMTSSwitchAgc(vga_MTS_SwitchAgc pCallBackFunc);
UINT32 BspGetTrxDevNum(VOID);
// UINT32 BspStartAgcCtrl(VOID);
UINT32 BspSetAllChnAgcPreAtt(VOID);
UINT32 BspGetADISwitchAgc(vga_ADI_SwitchAgc pCallBackFunc);
UINT32 BspSetAgcAnaPreAttFlag(UINT32 agcAnaPreAttFlag);
UINT32 BspGetTiSwitchAgc(vga_TI_SwitchAgc pCallBackFunc);
UINT32 BspGetADIStopAgc(vga_ADI_SwitchAgc pCallBackFunc);
UINT32 BspGetRxAnaAtt(UINT32 chanNo, INT32 digAtt, INT32* rxAttGain);
#ifdef __cplusplus
}
#endif

#endif /* _BOARDVGA_H_ */


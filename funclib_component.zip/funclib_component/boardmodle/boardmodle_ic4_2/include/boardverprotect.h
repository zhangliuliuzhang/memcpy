#ifndef _BOARD_VER_PROTECT_H_
#define _BOARD_VER_PROTECT_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "fpgaloadprocess.h"

/* 保护区版本Flash地址信息 */
typedef struct tagT_VerProtectInfo
{
    UINT32 startAddr; 
    UINT32 size;
    UINT32 verType;  
}T_VerProtectInfo;


UINT32 BspInitVersionProtect(T_VerProtectInfo *verInfo);
UINT32 BspSetProtectFileList(T_AllRunVerList *verList);
UINT32 BspExtractSocVer(VOID);
UINT32 BspExtractSocVerToTmp(VOID);

#ifdef __cplusplus
}
#endif
#endif


#ifndef _BOARDMODLE_IC4_2_H_
#define _BOARDMODLE_IC4_2_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
/**************************************************************************
 *                                   宏
 **************************************************************************/

//todo 单板下board.h中的公共枚举及宏定义后续迁移到此处(和系列单板共性的定义，例如flash分配)


#define BOARD_ACTION_DEF(acttype,func,initflag)  \
    { acttype,            func,              #func,        initflag},


/**************************************************************************
 *                                枚举定义
 **************************************************************************/
/* 单板模型种类定义 */
enum E_BOARD_TYPE
{
    E_BOARD_ONE_CHIP_TYPE = 0,  /* 单片结构 */
    E_BOARD_MS_M_TYPE,          /* 主从结构的主片 */
    E_BOARD_MS_S_TYPE,          /* 主从结构的从片 */
    E_BOARD_ADS_TEST_TYPE,      /* ADS验证板 */
    E_BOARD_MS_M_PLUS_TYPE,     /* 主从结构的主片最新改进型 */
    E_BOARD_ONE_CHIP_RF_CTRL_TYPE,     /* 动态库拆分：射频控制进程的单片结构 */
    E_BOARD_ONE_CHIP_VER_MANAGE_TYPE,  /* 动态库拆分：版本管理进程的单片结构 */
    E_BOARD_MODLE_TYPE_MAX
};
/* 单板系统软件服务初始化组件包含动作种类定义 */
enum E_BOARD_SOFT_SERVICE_ACT_TYPE
{
    E_SOFT_SERVICE_SIGNAL = BOARD_SOFT_SERVICE_ACT_BASE,   /* 信号初始化*/
    E_SOFT_SERVICE_EXT_PRN,                                /* EXT打印模块初始化 */
    E_SOFT_SERVICE_BSP_LOG,                                /* BSPLOG记录模块初始化 */
    E_SOFT_SERVICE_KDA_LIB,                                /* KDA服务初始化 */
    E_SOFT_SERVICE_PM_INIT,                                /* 打印模块初始化 */
    E_SOFT_SERVICE_DBOOT_INIT,                             /* 双BOOT参数初始化 */
    E_SOFT_SERVICE_UDPMSGMODULE_INIT,                      /* 核间UDP通信参数及任务初始化*/
    E_SOFT_SERVICE_WATCHDOG_INIT,                          /* 看门狗初始化 */
    E_SOFT_SERVICE_UART_INIT,                              /* UART服务初始化 */
    E_SOFT_SERVICE_FLASHFILE_INIT,                         /* 裸区离线文件恢复 */
    E_SOFT_SERVICE_INNER_NET_L2SS,                         /* 内部网口用L2SS VLAN初始化 */
    E_SOFT_SERVICE_INNER_NET_CFG,                          /* 内部网口初始化 */
    E_SOFT_SERVICE_CORE_AFFINITY_CFG,                      /* CPU亲和力初始化 */
    E_SOFT_SERVICE_RECORD_HASH_VER,                        /* 设置HASH版本信息到全局变量,供版本比对使用 */
    E_SOFT_SERVICE_INIT_RRU_FORM,                          /* 初始化RRU整机形态参数 */
    E_SOFT_SERVICE_INIT_EFUSE_WRITE,                       /* 初始化整机EFUSE写功能 */
    E_SOFT_SERVICE_INIT_EFUSE_READ,                        /* 初始化整机EFUSE读功能 */
    E_SOFT_SERVICE_INIT_GPIO_READ,                         /* 初始化整机GPIO读功能 */
    E_SOFT_SERVICE_INIT_SEC_CALLBACK,                      /* 版本启动安全验签回调 */
    E_SOFT_SERVICE_INIT_SEC_VERIFY,                        /* 版本启动安全验签功能 */
    E_SOFT_SERVICE_INIT_STAT_CALLBACK,                     /* 获取初始化状态函数注册接口 */
    E_SOFT_SERVICE_BOOT_HEADFILE_RECORD,                   /* 记录主区boot版本的头信息 */
    E_SOFT_SERVICE_SERIAL_LOG_PRINT_INIT,                  /* 增加串口日志转存到flash初始化*/
    E_SOFT_SERVICE_SAVE_BAK_LOG_TO_FLASH,                  /* 保存串口日志bak到flash*/
    E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH,                  /* 保存串口日志cur到flash*/
    E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH,                 /* 保存串口日志kmsg到flash*/
    E_SOFT_SERVICE_SAVE_BAK_LOG_TO_FLASH_SLAVE,            /* 保存从片串口日志bak到flash*/
    E_SOFT_SERVICE_SAVE_CUR_LOG_TO_FLASH_SLAVE,            /* 保存从片串口日志cur到flash*/
    E_SOFT_SERVICE_SAVE_KMSG_LOG_TO_FLASH_SLAVE,           /* 保存从片串口日志kmsg到flash*/
    E_SOFT_SERVICE_OPEN_KENEL_SWITCH,                      /* 初始化流程打开内核维测开关*/
    E_SOFT_SERVICE_ACT_MAX
};

/* 单板硬件特性、硬件互联关系初始化功能组件包含动作种类定义 */
enum E_BOARD_HARD_FEATURE_ACT_TYPE
{
    E_HARD_FEATURE_BOARD_ID = BOARD_HARD_FEATURE_ACT_BASE,/* 单板Boardid表始化 */
    E_HARD_FEATURE_DEV_ID,                                /* 设备ID表始化 */
    E_HARD_FEATURE_FUNC_ID,                               /* 功能ID表始化 */
    E_HARD_FEATURE_THRESHOLD_ID,                          /* 阈值ID表始化 */
    E_HARD_FEATURE_GAIN_ID,                               /* 增益ID表始化 */
    E_HARD_FEATURE_GET_BOMID,                             /* 从Flash读取Bomid信息      */
    E_HARD_FEATURE_GET_LGC_TYPE,                          /* 第一次调用BspGetBoardLgcType,获取后保存在全局变量中 */
    /* E_HARD_FEATURE_INIT_RRU_TYPE, */                   /* 初始化RRUTYPE *//*去除，和E_HARD_SERVICE_RRUFILE_INIT动作重复*/
    E_HARD_FEATURE_LINK_INFO_INIT,                        /* 单板丝印初始化 */
    E_HARD_FEATURE_RRU_PROPERTY,                          /* 特性表加载 */
    E_HARD_FEATURE_RRU_PROPERTY_PARA,                     /* 特性表参数更新 */
    E_HARD_FEATURE_RRUFILE_INIT,                          /* RRUINFO表加载 */
    E_HARD_FEATURE_DRV_TBL,                               /* 驱动PIN管脚表始化 */
    E_HARD_FEATURE_REG_TBL,                               /* 寄存器表初始化 */
    E_HARD_FEATURE_DRV_PIN_INIT,                          /* pin管脚寄存器初始化 */
    E_HARD_FEATURE_SPI_BUS,                               /* SPI总线初始化 */
    E_HARD_FEATURE_IIC_BUS,                               /* IIC总线初始化 */
    E_HARD_FEATURE_CALI_FILE_GET,                         /* 离线参数表获取 */
    E_HARD_FEATURE_CALI_FILE,                             /* 离线参数表加载 */
    E_HARD_FEATURE_CALI_GAIN_MODIFY,                      /* 离线参数表单板侧修正 */
    E_HARD_FEATURE_DPDIC_REG_TBL,                         /* DPDIC寄存器表初始化 */
    E_HARD_FEATURE_FLASH_INIT,                            /* FLASH参数初始化 */
    E_HARD_FEATURE_SOC_DIFF_INIT,                         /* 多片SOC硬件配置差异初始化 */
    E_HARD_FEATURE_UART_SEL_INIT,                         /* UART选通参数初始化 */
    E_HARD_FEATURE_NSBT_MAP_INIT,                         /* Nsbt映射初始化 */
    E_HARD_FEATURE_SET_SOC_BOMID,                         /* 主片保存Bomid，待从片通过SocMsg读取 */
    E_HARD_FEATURE_FPGA_DEV_LINK,                         /* FPGA和SPI总线关系初始化 */
    E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,                  /* 单板TDDIO丝印初始化 */
    E_HARD_FEATURE_TDDIO_CTRL_INIT,                       /* TDDIO 射频开关控制参数初始化 */
    E_HARD_FEATURE_TDDIO_OEEN_BEFORE,                     /* TDDIO 射频开关OE使能控制 除了palna */
    E_HARD_FEATURE_TDDIO_OEEN_AFTER,                      /* TDDIO 射频开关OE使能控制 仅palna */
    E_HARD_FEATURE_INIT_VER_PROTECT,                      /* 初始化保护区版本Flash地址信息 */
    E_HARD_FEATURE_REGISTER_CALLBACK,                     /* 注册回调 */
    E_HARD_FEATURE_CPUID_INIT,                            /* cpuId 初始化 */
    E_HARD_FEATURE_INIT_PROTECT_FILELIST,                 /* 初始化保护区版本清单 */
    E_HARD_FEATURE_INIT_SOC_VER,                          /* 初始化SOC版本信息 */
    E_HARD_FEATURE_RRUFILE_CALC,                          /* RRUINFO功率和频点计算，提供给高层用 */
    E_HARD_FEATURE_COMMON_THREAD_INIT,                    /* BSP线程初始化公共接口(从底层读取后保存到全局变量中，提供给高层使用) */
    E_HARD_FEATURE_ANTPOWER_INIT,                         /* 天线功率初始化 */
    E_HARD_FEATURE_CRM_PAPT_INIT,                         /* 光口功放保护初始化 */
    E_HARD_FEATURE_OPT_PAPT_INIT,                         /* 光口功放保护初始化 */
    E_HARD_FEATURE_PAPT_INIT,                             /* 中频功放保护初始化 */
    E_HARD_FEATURE_PAPT_UPDATA,                           /* 光口功放保护初始化数据更新 */
    E_HARD_FEATURE_REMOTE_RESET_INIT,                     /* 远程硬复位，掉电复位，掉电告警上报初始化 */
    E_HARD_FEATURE_CHECKPLLLD_CALLBACK,                   /*时钟及本振锁定获取接口挂接 */
    E_HARD_FEATURE_PA_VOLT_INIT,                          /*功放默认电压 */
    E_HARD_FEATURE_PWR_MAP_CHAN_INIT,                     /*电源48V与PA的映射参数*/
    E_HARD_FEATURE_PWRTEMP_THRESHOLD_INIT,                /*电源过温保护提供峰值和默认恢复值*/
    E_HARD_FEATURE_TDDIO_DTX,                        	  /* TDDIO 射频开关dtx相关 */
    E_HARD_FEATURE_USE_STATIC_DEVID,                      /* 使用静态的DEVID，以规避CPU使用率过高问题 */
    E_HARD_FEATURE_AC_TDDIO_PARA_INIT,                    /* AC控制管脚参数初始化 */
    E_HARD_FEATURE_POWER_ADJUST_DELTA,                    /* 微调整天线口功率 */
    E_HARD_FEATURE_CHAN_RFTBL_PARA,                       /* 支持多校准表解析及使用 */
    E_HARD_FEATURE_ANTI_TAMPER_INIT,                      /* 防篡改地址选择 */
    E_HARD_FEATURE_PWR_CONFIG_INIT,                       /* RRU整机电源供电能力不足配置参数 */
    E_HARD_FEATURE_EXPANSION_BOX_PARA,                    /* RRU农网盒子硬件配置关系映射 */
    E_HARD_FEATURE_FWD_LINK_INFO_INIT,                    /* NCR机型射频通道全链路方向初始化*/
    E_HARD_FEATURE_RRUTEMP_OFFSET_INIT,                   /* RRU电源,单板,功放告警温度提高偏移量配置参数 */
    E_HARD_FEATURE_PWROVERTEMP_DERATING_CFG,              /* RRU电源节点轻微过温功放降额配置信息 */
    E_HARD_FEATURE_PWRCURRENT_CFG,                        /* RRU整机电源过流告警配置参数 */
    E_HARD_FEATURE_RRUPOWERCONSTRAINT_CFG,                /* RRU功率天线和频段功率约束配置信息 */
    E_HARD_FEATURE_RRUFILE_BOMIDCHECK,                    /* RRUINFO表加载后处理,判断整机是否支持BOMID严格匹配方案 */
    E_HARD_FEATURE_NSBT_CTRL_DELAY_OPTIMIZA,              /* RRU NSBT开关时延优化 */
    E_HARD_FEATURE_DPS_UART_PARA_INIT,                         /*移相器控制器与UART对应关系*/
    E_HARD_FEATURE_ACT_MAX
};

/* 周边外设器件及主要芯片(DPDIC、FPGA等)的上电初始化功能组件包含动作种类定义 */
enum E_BOARD_CHIP_POWERON_ACT_TYPE
{
    E_CHIP_POWERON_CLK_DEV = BOARD_CHIP_POWERON_ACT_BASE,  /* 时钟芯片初始化 */
    E_CHIP_POWERON_PWR_DEV,                                /* 电源设备初始化 */
    E_CHIP_POWERON_EN_PWR_OT,                              /* 使能电源过温保护功能 */
    E_CHIP_POWERON_PA_DAC,                                 /* 栅压DAC芯片初始化 */
    E_CHIP_POWERON_RF_ADC,                                 /*目前没有单独的DAC器件，但是 栅压芯片读电流需要adc的接口*/
    E_CHIP_POWERON_FPGA_LOAD,                              /* FPGA加载 */
    E_CHIP_POWERON_DSP_LOAD,                               /* DPD DSP加载 */
    E_CHIP_POWERON_TRANSCEIVER,                            /* TRANSCEIVER芯片初始化 */
    E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,                   /* 时钟芯片初始化前的DPDIC CRM初始化 */
    E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,                    /* 时钟芯片初始化后的DPDIC CRM初始化 */
    E_CHIP_POWERON_DPDIC_PAD,                              /* DPDIC芯片PAD初始化 */
    E_CHIP_POWERON_EEPROM,                                 /* Eeprom相关器件初始化 */
    E_CHIP_POWERON_PWR_EEPROM_PAGE_SET,                    /* PWR Eeprom页写增加延时 */
    E_CHIP_POWERON_RFPLL_INIT,                             /* 下，上行和反馈本振器件初始化 */
    E_CHIP_POWERON_TRANSCEIVER_PRE_INIT,                   /*Transceiver器件初始化前处理*/
    E_CHIP_POWERON_TRANSCEIVER_INIT,                       /*Transceiver器件初始化*/
    E_CHIP_POWERON_TRANSCEIVER_POST_INIT,                  /*Transceiver器件初始化后处理*/
    E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT,                  /*Transceiver serdes预均衡参数初始化*/
    E_CHIP_POWERON_ATT_INIT,                               /*下行和反馈Att器件初始化*/
    E_CHIP_POWERON_ACATT_INIT,                             /*AC 模式下固定ATT功能初始化*/
    E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA,                 /* DPDIC芯片射频控制模块通用参数初始化 */
    E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,                 /* DPDIC芯片射频控制模块时间片参数初始化 */
    E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA,                  /* DPDIC芯片射频控制模块真值表参数初始化 */
    E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA,             /* DPDIC芯片射频控制模块真值表参数初始化 */
    //E_CHIP_POWERON_DPDIC_CBSW_PINSW_PARA,                /* DPDIC芯片射频控制模块PIN管脚选择参数初始化 */
    E_CHIP_POWERON_BOARDRESET_CALLBACK,                    /* 单板复位接口的挂接 */
    E_CHIP_POWERON_DAC_CALLBACK,                           /* 栅压DAC接口挂接 */
    E_CHIP_POWERON_TEMPSENSOR_DEV,                         /* 温度传感器设备初始化 */
    E_CHIP_POWERON_SLAVE_MGR_LOAD,                         /* 从MGR加载(1片IC上跑多个MGR时的从MGR加载) */
    E_CHIP_POWERON_SLAVE_BIN_LOAD,                         /*二次解压子端版本*/
    E_CHIP_POWERON_DPDIC_SOC_RESET,                        /* 复位住DPDIC从片 */
    E_CHIP_POWERON_DPDIC_SOC_RELEASE,                      /* 复位释放DPDIC从片 */
    E_CHIP_POWERON_DPDIC_SOC_LOAD,                         /* 加载DPDIC从片(MO Ramboot版本) */
    E_CHIP_POWERON_AC_DSP_LOAD,                            /* ACDSP版本加载 */
    E_CHIP_POWERON_MAIN_M0_LOAD,                           /* 主进程M0版本加载 */
    E_CHIP_POWERON_SLAVE_M0_LOAD,                         /* 从进程/从片M0版本加载 */
    E_CHIP_POWERON_FILE_MOVE,                              /* 初始化中固件等文件搬移 */
    E_CHIP_POWERON_DPDIC_PWRSAVE_PRE,                      /* DPDIC芯片节电，ubr机型主片参数初始化 */
    E_CHIP_POWERON_DPDIC_PWRSAVE,                          /* DPDIC芯片节电，关闭不使用的光口、中频、A53核资源 */
    E_CHIP_POWERON_DPDIC_PWRSAVE_POST,                     /* DPDIC芯片节电后处理 */
    E_CHIP_POWERON_DPDIC_LOAD_ORDER_CHIPNO,                /* DPDIC芯片加载顺序 */
    E_CHIP_POWERON_RFTBL_FILE_MOVE,
    E_CHIP_POWERON_CPRI_MODE_SWITCH_FUNC_INIT,
    E_CHIP_POWERON_CPRI_MODE_SWITCH_PARA_INIT,
    E_CHIP_POWERON_RRU_WATERLEAK_PROCESS_POST,             /* RRU漏水检测单板初始化后处理 */
    E_CHIP_POWERON_BOARD_CFG_FILE_MOVE,                    /* 单板配置文件位置搬移 */
    E_CHIP_POWERON_UPDATE_PADACSET_PARA,                   /* 更新栅压文件参数 */
    E_CHIP_POWERON_UPDATE_QCELL_PADACSET_PARA,             /*Qcell更新栅压文件参数*/
    E_CHIP_POWERON_MODIFY_PA_VOLT,                         /* 修改默认漏压 */
    E_CHIP_POWERON_INIT_BOARDTYPE,                         /* 初始化单板类型, 从片流程调用 */
    E_HARD_FEATURE_DPDIC_DYN_VOLT_CFG,                     /* DPDIC芯片核压动态调整参数配置 */
    E_CHIP_POWERON_SWITCH_SPARE_LANE,
    E_CHIP_POWERON_PMB_SCALE_INFO,                         /* 电源管理芯片系数 */
    E_CHIP_POWERON_UARTPLC_DEV,                            /* UartPlc设备初始化 */
    E_CHIP_POWERON_ACT_MAX
};

/* TX/RX/FB三大链路初始化功能组件包含动作种类定义 */
enum E_BOARD_TRX_LINK_ACT_TYPE
{
    E_TRX_LINK_DPDIC_OPT_TX_SERDES= BOARD_DIG_TRX_LINK_ACT_BASE, /*TX 光口Serdes始化+pcs初始化 */
    E_TRX_LINK_DPDIC_OPT_RX_SERDES,                        /* RX 光口Serdes始化+pcs初始化 */
    E_TRX_LINK_DPDIC_OPT_CPRI_PARA,                        /* 光口CPRI参数初始化 */
    E_TRX_LINK_DPDIC_OPT_CPRI_INIT,                        /* 光口CPRI参数初始化 */
    E_TRX_LINK_DPDIC_OPT_MEAS,                             /* 光口空口帧头初始化 */
    E_TRX_LINK_DPDIC_OPT_HAL_INIT,                         /* 光口功能初始化-实际动作 */
    E_TRX_LINK_DPDIC_OPT_CELL_INIT,                         /* 光口针对主从架构波及单片的修改*/
    E_TRX_LINK_DPDIC_OPT_BOOTP_INIT,                       /* 光口建链相关动作 */
    E_TRX_LINK_DPDIC_OPT_ADAPT_INFO_INIT,                  /* 光口自适应接口挂接 */
    E_TRX_LINK_DPDIC_OPT_ADAPT_THREAD_INIT,                /* 光口自适应任务启动 */
    E_TRX_LINK_DPDIC_DIF_CLK,                              /* 中频时钟初始化 */
    E_TRX_LINK_DPDIC_DIF_SAMRATE,                          /* 中频采样率初始化 */
    E_TRX_LINK_DPDIC_DIF_CFG,                              /* 中频配置初始化 */
    E_TRX_LINK_DPDIC_DIF_RESALLOC,                         /* 中频资源分配初始化 */
    E_TRX_LINK_DPDIC_DIF_TX_ROUTE,                         /* 中频下行路由初始化 */
    E_TRX_LINK_DPDIC_DIF_TX_PARA,                          /* 中频下行路由参数初始化 */
    E_TRX_LINK_DPDIC_DIF_TX_204,                           /* 中频下行204路由初始化 */
    E_TRX_LINK_DPDIC_DIF_RX_ROUTE,                         /* 中频上行路由初始化 */
    E_TRX_LINK_DPDIC_DIF_FB_ROUTE,                         /* 中频反馈理由初始化 */
    E_TRX_LINK_DPDIC_DIF_HAL_INIT,                         /* 中频功能初始化-实际动作 */
    E_TRX_LINK_DPDIC_DIF_FR,                               /* 中频帧头初始化 */
    E_TRX_LINK_DPDIC_DIF_CFG_TDD,                          /* FDD机型初始化TDD配置动作 */
    E_TRX_LINK_DPDIC_204_LINK,                             /* J204c 建链参数初始化 */
    E_TRX_LINK_DPDIC_204_SYSREF,                           /* J204c SYSREF参数初始化 */
    E_TRX_LINK_DPDIC_204_TXEQ,                             /* J204c SERDES预加重参数初始化 */
    E_TRX_LINK_DPDIC_204_INIT_STEP,                        /* J204c 建链INIT STEP */
    E_TRX_LINK_DPDIC_204_PRE_STEP,                         /* J204c 建链PRE STEP */
    E_TRX_LINK_DPDIC_204_POST_STEP,                        /* J204c 建链POST STEP */
    E_TRX_LINK_DPDIC_OPT_INNER_SERDES_CFG,                 /* 片间serdes cpri速率配置 */
    E_TRX_LINK_DPDIC_OPT_INNER_SERDES_MONITOR,             /* 片间serdes rx监控 */
    E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,                    /* J204c Transceiver回调挂接 */
    E_TRX_LINK_DPDIC_204_IC_TRX_LINK_MAP,                  /* J204c ic和mts link映射 */
    E_TRX_LINK_DPDIC_204_RECORD_STATE,                     /* 记录单板初始化结束时的J204建链状态 */
    E_TRX_LINK_DPDIC_OPT_SWITCHOVER_THREAD_INIT,           /* 环网光口倒换任务启动 */
    E_TRX_LINK_DPDIC_OPT_TXPRIORITY_THREAD_INIT,           /* 环网光口强制转发任务启动 */
    E_TRX_LINK_J204_CHECK_RETRY,                           /* J204c建链状态的检查和重试 */
    E_TRX_LINK_DPDIC_INNER_OPT_SERDES,                     /*片间cpri参数*/
    E_TRX_LINK_DPDIC_INNER_BACKUP_BRANCH_SERDES,           /*片间支路serdes参数*/
    E_TRX_LINK_SFP_CFG_PARA,                               /*光模块CDR参数*/
    E_TRX_LINK_DPDIC_OPT_PATH_PARA,
    E_TRX_LINK_ACT_MAX
};

/* 单板业务功能初始化组件包含动作定义 */
enum E_BOARD_FUNCTION_ACT_TYPE
{
    E_FUNCTION_PRE_ALLOC = BOARD_FUNCTION_ACT_BASE,        /* 场景预置初始化 */
    E_FUNCTION_TX_FREQ_CFG ,                               /* 下行配频初始化 */
    E_FUNCTION_RX_FREQ_CFG ,                               /* 上行配频初始化 */
    E_FUNCTION_TX_RF_DELAY ,                               /* 下行射频时延初始化 */
    E_FUNCTION_RX_RF_DELAY ,                               /* 上行射频时延初始化 */
    E_FUNCTION_TX_DELT_DELAY ,                             /* 下行DELT时延初始化 */
    E_FUNCTION_RX_DELT_DELAY ,                             /* 上行DELT时延初始化 */
    E_FUNCTION_FDD_DELAY ,                                 /* FDD时延初始化，纯TDD机型不需要 */
    E_FUNCTION_FDD_TOFFSET,                                /* FDD Toffset初始化，纯TDD机型不需要 */
    E_FUNCTION_FDD_FIXLINK,                                /* FDD 固定链路时延初始化，纯TDD机型不需要 */
    E_FUNCTION_CHIP_TRANDLY,                               /* 对于多片的时候片间传输延时,只适用于多片场景 */
    E_FUNCTION_RRU_DEFABILITY,                             /* RRU默认能力初始化，单通道最大载波数、默认制式 */

    E_FUNCTION_POWCALC_INIT,                               /* 功率检测相关参数初始化 */
    E_FUNCTION_GSM_POWCALC_INIT,                           /* GSM功率检测相关参数初始化*/
    E_FUNCTION_DL_POWCALC_PARA_INIT,                       /* 下行功率计算定标默认参数初始化 */
    E_FUNCTION_UL_POWCALC_PARA_INIT,                       /* 上行功率计算定标默认参数初始化 */
    E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,                /* 功控相关门限初始化 */
    E_FUNCTION_TEMP_THRESHOLD_PARA_INIT,                   /* 温度相关门限初始化 */
    E_FUNCTION_POWCALC_THREAD_INIT,                        /* 功率检测任务初始化 */
    E_FUNCTION_PAPT_PARA_INIT,                             /* 功放保护告警掩码及告警阈值参数初始化 */
    
    E_FUNCTION_CFR_PARA_INIT,                              /* 削峰软、硬件计算的静态参数初始化 */
    E_FUNCTION_CFR_FUNC_INIT,                              /* 削峰功能初始化 */
    E_FUNCTION_CFR_COMM_PARA_INIT,                         /* 削峰静态主体参数初始化 */
    E_FUNCTION_CFR_DYN_PARA_INIT,                          /* 削峰动态参数初始化 */
    E_FUNCTION_CFR_KICOMM_PARA_INIT,                       /* 削峰硬件计算Ki等静态参数初始化 */
    E_FUNCTION_CFR_KNCOMM_PARA_INIT,                       /* 削峰硬件计算Kn等静态参数初始化 */
    E_FUNCTION_CFR_PAR_PARA_INIT,                          /* 削峰峰均比参数初始化 */
    E_FUNCTION_DPD_PAR_PARA_INIT,                          /* DPD峰均比参数初始化 */
    E_FUNCTION_DPD_FUNC_INIT,                              /* DPD功能初始化 */
    E_FUNCTION_TRX_DIG_GAIN_INIT,                          /* 上下行数字增益初始化 */

    E_FUNCTION_VGA_BUS_INIT,                               /* VGA总线初始化 */
    E_FUNCTION_RF_VGA_INIT,                                /* 射频外挂VGA器件初始化 */
    E_FUNCTION_RF_ATT_PARA_INIT,                           /* 射频rfbus总线外挂衰减器初始化 */
    E_FUNCTION_RF_ATT_REAL_VAL_INIT,                       /* 射频总线外挂衰减器件真值表初始化，用于射频VGA器件初始化 */

    E_FUNCTION_VGA_CFG_INIT,                               /* VGA模块初始化 */
    E_FUNCTION_VGA_CTRL_PARA_INIT,                         /* VGA控制参数初始化 */
    E_FUNCTION_VGA_CTRL_MGC_PARA_INIT,                     /* MGC控制参数初始化 */
    E_FUNCTION_VGA_CTRL_MGC_CMD_INIT,                      /* MGC cmd参数初始化 */
    E_FUNCTION_VGA_CTRL_COMP_PARA_INIT,                    /* VGA补偿压缩参数初始化 */
    E_FUNCTION_STOP_AGC_CTRL_INIT,                         /* 切换到MGC模式初始化 */
    E_FUNCTION_MGC_SHEET_PARA_INIT,                        /* MGC策略表参数初始化 */
    E_FUNCTION_IF_BUS_PARA_INIT,                           /* 中频总线参数初始化 */
    E_FUNCTION_RF_BUS_PARA_INIT,                           /* 射频总线参数初始化 */
    E_FUNCTION_VGA_REAL_VAL_INIT,                          /* 真值表初始化，用于策略表查询的衰减值与真实衰减值的转换 */
    E_FUNCTION_VGA_CHN_ROUTE_INIT,                         /* VGA总线通道路由初始化 */
    E_FUNCTION_VGA_ADDR_ROUTE_INIT,                        /* VGA总线地址路由初始化 */
    E_FUNCTION_VGA_FPGACTRL_INIT,                          /* 逻辑初始化VGA芯片参数 */
    E_FUNCTION_MGC_TIME_SLICE_PARA_INIT,                   /* MGC时间片参数初始化 */
    E_FUNCTION_VGA_LIKE_SPI_PARA_INIT,                     /* MTS通过 类SPI给IC发送slicer或ad快检信息参数初始化 */

    E_FUNCTION_OPENLOOP_PARA_INIT,                         /* 开环定标相关接口挂接 */
    E_FUNCTION_CHAN_GROUP_INIT,                            /* 通道组初始化 */
    E_FUNCTION_DTX_ABILITY_SUPPORT,                        /*载波制式DTX能力上报*/
    E_FUNCTION_CHANGRP_TO_TDDIDX_INIT,                     /* 通道组与TDD索引对应关系初始化 */
    E_FUNCTION_CHANFREQ_BAND_INIT,                         /* 通道中频段对应关系初始化 */
    E_FUNCTION_RXSCAN_INIT,                                /* 接收频谱扫描初始化 */
    E_FUNCTION_LINKPWROFF_ENABLE,                          /* 光纤断链自救功能使能 */
    E_FUNCTION_LINKPWROFF_INIT,                            /* 光纤断链自救功能初始化 */
    E_FUNCTION_VECTORVSWR_INIT,                            /* 矢量驻波功能初始化 */
    E_FUNCTION_RRU_CARR_ABILITY,                           /* RRU载波能力上报初始化，配置这个制式能配置的最大载波数 */
    E_FUNCTION_UL_POWERCADJ_PARA_INIT,                     /* 过温过功率降额参数初始化 */
    E_FUNCTION_PAPT_REPORT_RECOVER,                        /* 功放保护告警上报和自救处理初始化 */
    E_FUNCTION_DTX_PARA_INIT,                              /* DTX参数初始化 */
    E_FUNCTION_RRU_ULDELAY_CMPABILITY,                     /* 40KM时延能力上报 */
    E_FUNCTION_PA_PWRVOLT_INIT,                            /* TDD静态调压参数初始化 */
    E_FUNCTION_REV_PROTECT_INIT,                           /* REV功率保护回退*/
    E_FUNCTION_REV_GATE_PARA_INIT,                         /* REV功率保护门限参数初始化*/
    E_FUNCTION_VINDOWN_EFFECTIVE_INIT,                     /* 判定供电能不足功能中硬件光耦状态*/
    E_FUNCTION_NTF_PARA_INIT,                              /* 硬件自检参数初始化 */
    E_FUNCTION_LNAOFF_PARA_INIT,                           /* LNA关闭参数初始化 */
    E_FUNCTION_PAPT_SECONDARY_INIT,                        /* 功放保护参数二次更新配置 */
    E_FUNCTION_ICPSYNC_INTERRUPT_INIT,                     /* psync中断初始化配置 */
    E_FUNCTION_DSP_CALC_POW_PARA,                          /* DSP功率检测初始化*/
    E_FUNCTION_USE_CHAN_DEFAULT_CENTERFREQ_FLAG,           /* 使用通道默认中心频点标志 */
    E_FUNCTION_DPD_SET_EQ_INIT,                            /* EQ功能，向dsp下发TxFwd和FilterGain校准数据 */
    E_FUNCTION_RRU_ABILITY_FLAG,                           /* RRU规格整机能力上报 */
    E_FUNCTION_RRU_CARR_CAP,                               /* RRU支持的载波号范围信息上报 */
    E_FUNCTION_DFL_OUT_RANG_ALM_FLAG,                      /* 支持下行频点超范围告警 */
    E_FUNCTION_SFP_SELF_HEAL_FLAG,                         /* 支持光模块掉电自愈 */
    E_FUNCTION_POW_THROD_CFG,                              /* 基带过功率，BBU与RRU联合检测功能初始化 */
    E_FUNCTION_CHIP_TRANDLY_ALL_PATH,                      /* 支持lane自救机型不同path下片间时延配置*/
    E_FUNCTION_CHIP_DPS_UART_INIT,                      /* 移相器控制器与UART对应关系*/
    E_FUNCTION_ACT_MAX,
};

/* 单板对应进程种类定义 */
enum E_BOARD_PROCESS_TYPE
{
    E_BOARD_PROCESS_RF_CTRL_TYPE,     /* 动态库拆分：射频控制进程相关 */
    E_BOARD_PROCESS_VER_MANAGE_TYPE,  /* 动态库拆分：版本管理进程相关 */
    E_BOARD_PROCESS_BASE_TYPE,        /* 动态库拆分：所有进程共用部分 */
    E_BOARD_PROCESS_TYPE_MAX
};

/**************************************************************************
 *                         数据类型
 **************************************************************************/

/**************************************************************************
*                         函数声明
**************************************************************************/

typedef UINT32 (*FUNC_CHANGE_FLOW_POST_LGC_TYPE)(VOID);

typedef struct tagT_FuncChangeFlowPostLgcType
{
    FUNC_CHANGE_FLOW_POST_LGC_TYPE funcChangeFlowPostLgcType;
}T_FuncChangeFlowPostLgcType;

/* 单板属性 */
typedef struct tagT_BoardAttribute
{
    
}T_BoardAttribute;


#ifdef __cplusplus
}
#endif

#endif /* _BOARDMODLE_IC4_2_H_ */



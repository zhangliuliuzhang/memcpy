
#ifndef _BOARD_RESET_H_
#define _BOARD_RESET_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "boardmodlecommon.h"
#include "bsppub.h"
/**************************************************************************
 *                        宏
 **************************************************************************/

/**************************************************************************
 *                                枚举定义
 **************************************************************************/
typedef enum
{
    E_OTHER_BOARD_TYPE,
    E_MASTER_BOARD_TYPE,
    E_SLAVE_BOARD_TYPE
} E_BOARD_MS_FLAG;

#define SOC_POWERON_RESET_TYPE_POR (0)
#define SOC_SOFT_RESET_TYPE_EXT    (1)
#define SOC_RESET_NUM_ALL          (255)
#define SOC_HW_SUPPORT_MAX_CHIP_SUM         8
#define OPT_AND_CLK_NOT_NEED_INIT          (0)    /*RRU内部软复位,即不需要初始化时钟和光口*/
#define OPT_AND_CLK_NEED_INIT              (1)    /*RRU内部硬复位，即需要初始化时钟和光口*/

#define RESET_CTRL_RESET_STOP              (0)    /*复位住*/
#define RESET_CTRL_RESET_RELEASE           (1)    /*复位释放*/
#define RESET_CTRL_RESET_WAIT_RELEASE      (255)  /*复位住等待一会儿后再释放*/
/**************************************************************************
 *                         数据类型
 **************************************************************************/
typedef UINT32 (*FUNC_BSP_BOARD_SOC_RESET)(OSS_ULONG devId, UINT32 resetType, UINT32 cause);
typedef VOID (*FUNC_BOARD_SOFT_RST)(UINT32 chipId);
typedef UINT32 (*FUNC_BSP_RESET_CPE)(VOID);
typedef UINT32 (*FUNC_BSP_BOARD_M_RESET)(VOID);
/**************************************************************************
*                         函数声明
**************************************************************************/

UINT32 BspResetDeviceInit(VOID);
UINT32 BspDevReset(OSS_ULONG devId, UINT32 resetType, UINT32 cause);
UINT32 BspBoardSetReset(UINT32 resetType, UINT32 cause);
UINT32 BspBoardPwrOff(UINT32 resetType, UINT32 cause);
VOID BspGracefulReboot(UINT32 cause);
VOID BspResetFpga(UINT32 chipId);
UINT32 BspGetBoardResetType(VOID);
VOID BspFpgaReLoadFlagSet(UINT32 ulReFlag);
UINT32 BspFpgaReLoadFlagGet(VOID);
UINT32 CpuRstDpdicRstType0(UINT32 ulChipIdx, UINT32 ulCtrlFlag);
UINT32 CpuRstDpdicRstType1(UINT32 ulChipIdx, UINT32 ulCtrlFlag);
UINT32 CpuRstDpdicRstType2(UINT32 ulChipIdx, UINT32 ulCtrlFlag);
UINT32 MainCpuResetDpdic(const CHAR *pcRstStr, UINT32 ulRstType, UINT32 ulChipIdx, UINT32 ulCtrlFlag);
UINT32 BspBoardSetReset_M(UINT32 resetType, UINT32 cause);
UINT32 BspResetDeviceInit_M(VOID);
UINT32 BspDevReset_M(OSS_ULONG devId, UINT32 resetType, UINT32 cause);
UINT32 BspResetDeviceInit_S(VOID);
void BspSetDisableFlowCtrl(UINT32 enable);
UINT32 BspDpdicResetCtrl(UINT32 ulChipNo, UINT32 ulRstType, UINT32 ulRstCtrl);
UINT32 BspDpdicResetRelease(UINT32 ulRstType, UINT32 ulChipIdx);
UINT32 BspGetClkAndOptReLoadFlag(VOID);
UINT32 RruLinkPwrOffEnable();
UINT32 RruLinkPwrOffInit();
UINT32 BspSetBoardSocResetFunc(FUNC_BSP_BOARD_SOC_RESET pFunc);
UINT32 BspSetBoardResetFlag(VOID);
UINT32 BspGetBoardResetFlag(VOID);
UINT32 BspProtectPwrDown(UINT32 chipId);
UINT32 BspDpdicSlaveSocSoftReset(UINT32 rstCtrl);
UINT32 BspDpdicSlaveSocSoftReLoad(UINT32 chipId);
UINT32 BspBoardSoftResetCallBack(FUNC_BOARD_SOFT_RST pFunc);
VOID BspSetCpuResetMonitorStartFlag(UINT32 flag);
UINT32 BspGetCpuResetMonitorStartFlag(VOID);
UINT32 BspSetResetCpeFunc(FUNC_BSP_RESET_CPE pFunc);
UINT32 BspBoardMasterPreResetCallBack(FUNC_BSP_BOARD_M_RESET pFunc);
#ifdef __cplusplus
}
#endif

#endif /* _BOARD_HARD_ID_ */



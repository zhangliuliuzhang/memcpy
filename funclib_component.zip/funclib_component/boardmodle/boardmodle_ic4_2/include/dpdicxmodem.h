/*************************************************************
 *
 *	filename	: ma_serial.h
 *	author	: luca
 *  comments: manage master's serials
 *											
 *************************************************************/
#ifndef DPDIC_XMODEM_LOAD_H
#define DPDIC_XMODEM_LOAD_H
#define NXP_SERIAL_REQ_ERROR                'f'
#define NXP_SERIAL_REQ_SUCCESS              'p'

#define in_range(c, lo, up)  ((unsigned char)c >= lo && (unsigned char)c <= up)
#define isprint(c)           in_range(c, 0x20, 0x7f)
#define isdigit(c)           in_range(c, '0', '9')
#define isxdigit(c)          (isdigit(c) || in_range(c, 'a', 'f') || in_range(c, 'A', 'F'))
#define islower(c)           in_range(c, 'a', 'z')
//#define isspace(c)           (c == ' ' || c == '\f' || c == '\n' || c == '\r' || c == '\t' || c == '\v')

/**************************************************************
| SOH | 信息包序号 | 信息包序号的反码 | 数据区段 | 算术校验和?|
|*****|************|******************|**********|************|*/

// serial x-modem send implementation ....
#define XMODEM_SOH                        (0x01)          /* 128字节帧的开头字节 */
#define XMODEM_STX                        (0x02)          /* 1K帧的开头字节 */
#define XMODEM_EOT                        (0x04)          /* 所有数据传输完毕的结束响应 */
#define XMODEM_ACK                        (0x06)          /* 接收方响应正常接收 */
#define XMODEM_NAK                        (0x15)          /* 接收方请求重传(也用来做启动传输) */
#define XMODEM_CAN                        (0x18)          /* 接收方取消传输标志 */
#define XMODEM_CTRLZ                      (0x1A)          /* 数据不满128字节时填充的数据 */
#define XMODEM_OUTC                       (0x43)          /* 要求以CRC校验传输的启动传输标志 */

/*当接收方一开始启动传输时发送的是NAK，表示它希望以累加和方式校验。
当接收方一开始启动传输时发送的是字符“C”，表示它希望以CRC方式校验。*/

#define XMODEM_CRC_CHR      'C'
#define XMODEM_CRC_CHR1     'V'
#define XMODEM_CRC_SIZE      2      /* Crc_High Byte + Crc_Low Byte */
#define XMODEM_FRAME_ID_SIZE 2      /* Frame_Id + 255-Frame_Id */
#define XMODEM_DATA_SIZE_SOH 128    /* for Xmodem protocol */
#define XMODEM_DATA_SIZE_STX 1024   /* for 1K xmodem protocol */
#define USE_1K_XMODEM        1      /* 1 for use 1k_xmodem 0 for xmodem */

#if (USE_1K_XMODEM)
#define XMODEM_DATA_SIZE  XMODEM_DATA_SIZE_STX
#define XMODEM_HEAD  XMODEM_STX
#else
#define XMODEM_DATA_SIZE  XMODEM_DATA_SIZE_SOH
#define XMODEM_HEAD   XMODEM_SOH
#endif

typedef struct tag_serial_port_cmd 
{
    INT8 acCmdStr[32];
    UINT32 dwCmd;
    UINT32 *pdwRetVal;
}T_SERIAL_PORT_CMD;

typedef struct ddr_init_res
{
    UINT32 ulMagic;
    UINT32 ulDdrInitResult;
    UINT32 ulUDdrInitSelect; 
    UINT32 ulDdrFreq;
    UINT32 ulBoardType;
    UINT32 ulUddrInitConfig;
}T_DDR_INIT_RES;

typedef struct 
{
    UINT32          dst_addr_low32;     /*版本文件地址低32bit*/
    UINT32          dst_addr_high32;    /*版本文件地址高32bit*/
    INT8            tftp_filename[64];  /*版本文件名*/
} TFTP_FILES_INFO;

typedef struct 
{
    UINT32          magic_flag;          /*0x12345678*/
    UINT8           server_mac[6];	     /* 服务器MAC CC MAC*/
    UINT8           client_mac[6];	     /* 客户端MAC  MCS MAC*/
    UINT16          vlan;                /*VLAN 没有VLAN填写0xffff*/
    UINT16          TftpBlkSizeOption;   /*块大小*/
    UINT32          server_ip;           /*服务器IP CC的IP*/
    UINT32          client_ip;           /*客户端IP，MCS的IP*/
    UINT32          TftpTimeoutCountMax;/*尝试多少次*/
    UINT32          download_file_num;   /*下载文件数目*/
    TFTP_FILES_INFO tftp_download_file_info[6];
    UINT32          tftp_done_flag;      /*完成标记大端*/
    INT8            tftp_done_filename[64]; /*版本文件名*/
    UINT32          boot_type;              /*xload自动网口加载还是等通知加载模式*/
} TFTP_PARAS_CFG;
typedef struct tag_nxp_serial_drv
{
    /* 串口属性 */
    UINT32 udPortId;               //串口ID标识
    UINT32 udBaudrate;             //串口波特率
    UINT32 udMaxBaudrate;          //最大支持的串口波特率

    /* 基本操作 */
    UINT32 (* pfNxpSerialInit)(UINT32 ulChip, UINT32 udBaudrate); //串口初始化
    UINT32 (* pfByteRecv)(UINT8 *puCh);                           //串口收数据，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfByteSend)(UINT32 ulChip, UINT8 ucCh);             //串口发数据，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfIsRxFifoEmpty)(VOID);                             //返回接受队列空状态,返回值BSP_OK为空/BSP_ERROR不空
    UINT32 (* pfIsTxFifoFull)(VOID);                              //返回发送队列满状态,返回值BSP_OK为满/BSP_ERROR不满
    UINT32 (* pfIsBusy)(VOID);                                    //返回串口忙状态,返回值BSP_OK为忙/BSP_ERROR不忙
    UINT32 (* pfNxpSerialRecvFifoClear)(UINT32 ulChip);           //清空接收队列
    VOID   (* pfMSTimeDelay)(UINT32 udMS);                        //毫秒时延
    UINT32 (* pfBaudrateSet)(UINT32 ulChip, UINT32 udBaudrate);	  //串口波特率设置，返回值BSP_OK成功/BSP_ERROR失败	
}T_NXP_SERIAL_DRV;


typedef struct tag_nxp_serial_manage
{
    /* 串口属性 */							
    UINT32 udPortId;                                        //对端ID标识

    /* 从片操作 */
    UINT32 (* pfSlaveChipRegRead)(UINT64 ullDstAddr, UINT32 *pdwRetVal, UINT8 ucWidth);    //通过操作epld复位从片，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfSlaveChipRegWrite)(UINT64 ullDstAddr, UINT32 dwVal, UINT8 ucWidth);        //通过操作epld复位从片，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfCmdExec)(T_SERIAL_PORT_CMD *ptCmd);                //串口发数据，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfDstPortSwitch)(UINT32 udDstId);                    //通过操作epld切换对端串口，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfSlaveChipReset)(UINT32 ulRstType, UINT32 udDstId); //通过操作epld复位从片，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfIsSerialCommOk)(VOID);                             //检查串口是否通信正常，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfXmodemStart)( UINT64 ullDstAddr, UINT8 ucWidth);
    UINT32 (* pfSlaveDpdIcJump)(UINT64 ullDstAddr, UINT8 ucWidth);     //程序跳转命令
    UINT32 (* pfSerialAttrSet)(UINT32 dwBaudRate, UINT32 dwDataBits, UINT8 cVerify, UINT32 dwStopBits, UINT8 cFlowCtrl);
}T_NXP_SERIAL_SLV;

typedef struct tag_nxp_serial_app
{
    T_NXP_SERIAL_DRV  tNxpSerialDrv;
    T_NXP_SERIAL_SLV  tNxpSlaveDrv;
    UINT32 udSlaveChipNum;

    /* 应用接口 */
    UINT32 (* pfRecv)(UINT32 ulchip, UINT8 *pcBuf, UINT32 udLen); //串口收数据，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfSend)(UINT32 ulchip, UINT8 *pcBuf, UINT32 udLen);                //串口发数据，返回值BSP_OK成功/BSP_ERROR失败
    UINT32 (* pfRecvInTime)(UINT32 ulchip, INT8 *pcRcvBuf, UINT32 dwBufLen,UINT32 maxT);
    UINT32 (* pfLoadByXmodem)(UINT32 ulchip, char * pcFileName); //串口加载文件
    UINT32 (* pfLoadBuffByXmodem)(UINT8 * pcBuf, UINT32 udlen, UINT64 ullDstAddr);
    UINT32 (* pfSetXloadConfig)(UINT32 udDstId, UINT32 udUddrSelect, UINT32 udDdrFreq, UINT32 udBoardType, T_DDR_INIT_RES * ptDdrParam);    
    UINT32 (* pfLoadXloadConfig)(T_DDR_INIT_RES * ptDdrParam);  
    UINT32 (* pfInitTftpParam)(UINT32 udChipId, TFTP_PARAS_CFG * ptTftpParam);
    UINT32 (* pfLoadTftpParam)(UINT32 udChipId);
    UINT32 (* pfStartTftpServer)(VOID);  
}T_NXP_SERIAL_APP;


enum NXP_SERIAL_MODULE_INIT_FLAG{
    NXP_SERIAL_MODULE_INIT_OK,
    NXP_SERIAL_MODULE_INIT_WAIT
};
enum NXP_SRIAL_BAUDRATE{
    NXP_SRIAL_B9600          = 9600,
    NXP_SRIAL_B14400         = 14400,
    NXP_SRIAL_B19200         = 19200,
    NXP_SRIAL_B38400         = 38400,
    NXP_SRIAL_B115200        = 115200,
    NXP_SRIAL_B230400        = 230400,
    NXP_SRIAL_B380400        = 380400,
    NXP_SRIAL_B460800        = 460800,
    NXP_SRIAL_B921600        = 921600,
    NXP_SRIAL_B1562500       = 1562500, 	
    NXP_SRIAL_B1843200       = 1843200,
    NXP_SRIAL_B3125000       = 3125000, 	
    NXP_SRIAL_B3686400       = 3686400,
    NXP_SRIAL_B4000000       = 4000000,
    NXP_SRIAL_B7372800       = 7372800,
    NXP_SRIAL_B14745600      = 14745600,
    NXP_SRIAL_DEFAULT        = 115200,
};

enum NXP_SERIAL_CMD{
    NXP_SERIAL_CMD_READ             = 0x0,
    NXP_SERIAL_CMD_WRITE            = 0x1,
    /* 访问Slave MCS 数据宽度:1/2/4字节 */	
    NXP_SERIAL_CMD_SET_ACCESS_WIDTH = 0x2,    
    /* set slave MS serial attribution */
    NXP_SERIAL_CMD_SET_ATTR         = 0x3,      
    NXP_SERIAL_CMD_JUMP             = 0x4,
    NXP_SERIAL_CMD_XMODEM_SEND      = 0x5
};

enum DPDIC_VERSION_TYPE{
	DPDIC_VERSION_PREXLOAD = 0,
	DPDIC_VERSION_XLOAD,
	DPDIC_VERSION_RAMBOOT,
};

static const UINT32 s_NxpBaudRateTbl[] = 
{
    NXP_SRIAL_B9600,
    NXP_SRIAL_B14400,
    NXP_SRIAL_B19200,
    NXP_SRIAL_B38400,
    NXP_SRIAL_B115200,
    NXP_SRIAL_B230400,
    NXP_SRIAL_B380400,
    NXP_SRIAL_B460800,
    NXP_SRIAL_B921600,
    NXP_SRIAL_B1562500,	
    NXP_SRIAL_B1843200,
    NXP_SRIAL_B3125000,
    NXP_SRIAL_B3686400,
    NXP_SRIAL_B4000000,
    NXP_SRIAL_B7372800,
    NXP_SRIAL_B14745600
};

typedef struct tag_loadver_info
 {
    UINT32 udVersionType;
    char ucVersionPath[128];
    //UINT64 udDstAddr;
 }T_LOADVER_INFO;

#define NXP_COM_PORT_MAX           (8)
#define DPDIC_SOC_MAX_NUM          (NXP_COM_PORT_MAX)

typedef UINT32 (*FUNC_CALLED_SOC_LOAD)(UINT32 socId);

typedef struct tag_DPDIC_XMODEM_INFO
{
    const CHAR *pNxpComPortName[NXP_COM_PORT_MAX];
    UINT32 dpdicSocComPortIdx[DPDIC_SOC_MAX_NUM];
    UINT32 dpdicSocUartIdx[DPDIC_SOC_MAX_NUM];  
    FUNC_CALLED_SOC_LOAD pFuncPreLoadSoc;
    FUNC_CALLED_SOC_LOAD pFuncPostLoadSoc;
}T_DPDIC_XMODEM_INFO;

UINT32 BspDpdIcXmodemInfoInit(T_DPDIC_XMODEM_INFO *pXmodemInfo);

UINT32 BspLoadDpdIc(UINT32 ulRstType);
UINT32 BspLoadDpdIcByChip(UINT32 ulRstType, UINT32 ulChip);
UINT32 BspSocDpdicVerUpdate(UINT32 ulRstType, UINT32 ulSocIdx);

UINT32 BspSetDpdicRegByM0Uart(UINT32 ulChipIdx, UINT32 ulAddr, UINT32 ulData);
UINT32 BspGetDpdicRegByM0Uart(UINT32 ulChipIdx, UINT32 ulAddr, UINT32 *pulData);
UINT32 BspGetDpdicVoltByUart(UINT32 ulchip, UINT32 checkCnt);


#endif //DPDIC_XMODEM_LOAD_H

/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : cbswcfg_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了adapter的ICHAL反馈射频开关控制接口 声明
* 注意事项 : 仅内部使用，不给外部单板或平台调用
* 作    者 :   10268066
* 创建日期 : 2020-11-010
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10268066
* 修改日戳: 2020-11-10
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_CBSWCFG_H_
#define _FUNCLIB_CBSWCFG_H_



#ifdef __cplusplus
extern "C" {
#endif
//此处include HAL层头文件
#include "bsppub.h"
#include "bspcomm.h"

#include "exprn.h"
#include "ichaladapt_ic4_2.h"

typedef struct
{
    UINT32 swIndex;
    T_BspHalAdaptCbSwStaTbl* pCbSwStaTbl;
    UINT32 tblLen;
}T_BspCbSwStaTbl;

typedef struct
{
    UINT32 swIndex;           /*射频开关表索引，IC内部存在2套独立映射表*/
    UINT32 transBitSel;     /*当前映射表的bit使能，同外部管脚对应的bit相关联*/
    UINT32 ConnectMode;     /*IC和器件的连接关系，0直连transceiver，1连EPLD*/
    UINT32 frameNo;         /*射频开关启动的无线帧号，正常均为0*/
    UINT32 swMode;          /*射频开关的启动模式，0不响应无线帧号，1响应无线帧号*/
    UINT32 frBitEn;         /*无线帧号计数掩码*/
    UINT32 fwdRevLen;       /*  FWD与REV时间片实际长度,单位ms RRU 10ms QCELL 20ms */
}T_BspCbSwPara;

typedef struct
{
    UINT32 swIndex;
    UINT32 rfType;
    T_BspHalAdaptCbSwRfTbl pCbSwRfTbl;
}T_BspCbSwRfTbl;

typedef struct
{
    UINT32 pinName;     /*射频管脚名枚举*/
    UINT32 sw;          /*选择射频管脚控制来源IC内部哪套射频控制，0第一套，1第二套*/
}T_BspCbPinSw;

UINT32 BspCbSwParaInit(T_BspCbSwPara* ptCbSwPara, UINT32 len);
UINT32 BspCbSwStaTblInit(T_BspCbSwStaTbl* ptCbSwStaTbl,UINT32 len);
UINT32 BspCbSwRfTblInit(T_BspCbSwRfTbl* ptCbSwRfTbl,UINT32 len);
UINT32 BspCbPinSwTblInit(T_BspCbPinSw* ptCbPinSwTbl,UINT32 len);
UINT32 BspCbSwRfTblInit_Fpga(T_BspCbSwRfTbl* ptCbSwRfTbl,UINT32 len);
#ifdef __cplusplus
}
#endif
#endif 

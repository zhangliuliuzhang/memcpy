/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : cbswcfgapi.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了adapter的ICHAL反馈射频开关控制接口 声明
* 注意事项 : 给外部单板或平台或调用
* 作    者 :   10268066
* 创建日期 : 2020-11-10
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10268066
* 修改日戳: 2020-11-10
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_CBSWCFG_DBG_H_
#define _FUNCLIB_CBSWCFG_DBG_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "cbswcfg.h"


UINT32 dbgSaveCbSwRfTbl(T_BspCbSwRfTbl* ptCbSwRfTbl,UINT32 len);
UINT32 dbgSaveCbSwPara(UINT32 swIndex, T_BspHalAdaptCbSwPara *ptSwInitCfg);
UINT32 dbgSaveCbSwStaTbl(UINT32 swIndex, T_BspHalAdaptCbSwStaTbl* tSwStaTbl, UINT32 len);
UINT32 setcbforcesta(UINT32 swInex, UINT32 chan, UINT32 sta, UINT32 period,UINT32 sw);
UINT32 dbgSaveCbPinSwTbl(T_BspCbPinSw* ptCbPinSwTbl,UINT32 len);




#ifdef __cplusplus
}
#endif
#endif 
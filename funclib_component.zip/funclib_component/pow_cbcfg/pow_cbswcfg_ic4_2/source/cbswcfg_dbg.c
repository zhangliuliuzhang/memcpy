/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : cbswcfg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了adapter的ICHAL反馈射频开关控制接口 声明
* 注意事项 : cbswcfg相关的所有接口定义，包含维测和对外接口
* 作    者 :   10268066
* 创建日期 : 2020-11-10
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10268066
* 修改日戳: 2020-11-10
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "cbswcfg_dbg.h"

#define CB_SW_HELP_LEN (50)
UINT8 g_cbSwHelpPrint[][CB_SW_HELP_LEN] =
{
    "dbgShowCbPinSwTbl",
    "dbgShowCbSwRfTbl",
    "dbgShowCbSwPara swIndex",
    "dbgShowCbSwStaTbl swIndex",
    "setcbforcesta swInex,chan,sta,period,sw",
};

UINT32 cbswhelp(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    dbgInfo("cb sw Help:\n");

    udPrintCnt = sizeof(g_cbSwHelpPrint) / CB_SW_HELP_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        dbgInfo(" %s \n", g_cbSwHelpPrint[udCnt]);
    }

    return (UINT32)BSP_OK;
}

static T_BspHalAdaptCbSwPara g_dbgHalSwPara[MAX_CB_SW_NUM] = {0};
static T_BspCbSwStaTbl s_tdbgCbSwStaTbl[MAX_CB_SW_NUM] = 
{
    {0,NULL,0},
    {1,NULL,0},
};
static T_BspCbSwRfTbl* s_ptdbgCbSwRfTbl = NULL;
static UINT32 s_dbgCbSwRfTblLen = 0;

static T_BspCbPinSw* s_ptdbgCbPinSwTbl = NULL;
static UINT32 s_dbgCbPinSwTblLen = 0;

UINT32 dbgSaveCbPinSwTbl(T_BspCbPinSw* ptCbPinSwTbl,UINT32 len)
{
    if(ptCbPinSwTbl == NULL)
    {
        return BSP_ERROR;
    }
    s_dbgCbPinSwTblLen = len;
    s_ptdbgCbPinSwTbl = ptCbPinSwTbl;
    return BSP_OK;
}

static UINT32 dbgShowCbPinSwTbl(void)
{
    UINT32 loop = 0;
    if(s_ptdbgCbSwRfTbl == NULL)
    {
        dbgErr("Cb Pin SW TBL is NULL\n");
        return BSP_ERROR;
    }
    for(loop = 0;loop < s_dbgCbPinSwTblLen; loop++)
    {
        dbgInfo("PinIndex[%d] SW[%d]\n",s_ptdbgCbPinSwTbl[loop].pinName,s_ptdbgCbPinSwTbl[loop].sw);
    }
    return BSP_OK;
}
UINT32 dbgSaveCbSwRfTbl(T_BspCbSwRfTbl* ptCbSwRfTbl,UINT32 len)
{
    if(ptCbSwRfTbl == NULL)
    {
        return BSP_ERROR;
    }
    s_dbgCbSwRfTblLen = len;
    s_ptdbgCbSwRfTbl = ptCbSwRfTbl;
    return BSP_OK;
}

static UINT32 dbgShowCbSwRfTbl(void)
{
    UINT32 swIndex = 0;
    UINT32 typeIndex = 0;
    UINT32 tblIndex = 0;
    UINT32 chanIndex = 0;
    if(s_ptdbgCbSwRfTbl == NULL)
    {
        dbgErr("Cb SW TBL is NULL\n");
        return BSP_ERROR;
    }
    for(swIndex = 0; swIndex < MAX_CB_SW_NUM; swIndex++)
    {
        for(typeIndex = E_HAL_RF_RAM_TYPE_FWD; typeIndex <= E_HAL_RF_RAM_TYPE_CAL; typeIndex++)
        {
            if(typeIndex == E_HAL_RF_RAM_TYPE_FWD)
            {
                dbgInfo("**************SwIndex[%d] FWD CbSwRfTbl*********************\n",swIndex);
            }
            if(typeIndex == E_HAL_RF_RAM_TYPE_REV)
            {
                dbgInfo("**************SwIndex[%d] REV CbSwRfTbl*********************\n",swIndex);
            }
            if(typeIndex == E_HAL_RF_RAM_TYPE_CAL)
            {
                dbgInfo("**************SwIndex[%d] Cali CbSwRfTbl*********************\n",swIndex);
            }
            for(tblIndex = 0; tblIndex < s_dbgCbSwRfTblLen; tblIndex++)
            {
                if((s_ptdbgCbSwRfTbl[tblIndex].swIndex == swIndex) && (s_ptdbgCbSwRfTbl[tblIndex].rfType == typeIndex))
                {
                    for(chanIndex = 0; chanIndex < s_ptdbgCbSwRfTbl[tblIndex].pCbSwRfTbl.uiChanNum; chanIndex++)
                    {
                        dbgInfo("chan[%d] valu:%#x",chanIndex,s_ptdbgCbSwRfTbl[tblIndex].pCbSwRfTbl.uiOneLine[chanIndex]);
                    }
                }
            }
        }
    }
    return BSP_OK;
}

UINT32 dbgSaveCbSwPara(UINT32 swIndex, T_BspHalAdaptCbSwPara *ptSwInitCfg)
{
    if(swIndex >= MAX_CB_SW_NUM)
    {
        dbgErr("[%s] swIndex'%d over !\n",__FUNCTION__,swIndex);
        return BSP_ERROR;
    }
    g_dbgHalSwPara[swIndex].uiTransBitSel = ptSwInitCfg->uiTransBitSel;
    g_dbgHalSwPara[swIndex].uiConnectMode = ptSwInitCfg->uiConnectMode;
    g_dbgHalSwPara[swIndex].uiFrId = ptSwInitCfg->uiFrId;
    g_dbgHalSwPara[swIndex].uiFrMode = ptSwInitCfg->uiFrMode;
    return BSP_OK;
}

static VOID dbgShowCbSwPara(UINT32 swIndex)
{
    dbgInfo("TransBitSel%d ConnectMode%d swMode %d FrameNo%d \n",g_dbgHalSwPara[swIndex].uiTransBitSel,
    g_dbgHalSwPara[swIndex].uiConnectMode,g_dbgHalSwPara[swIndex].uiFrMode,g_dbgHalSwPara[swIndex].uiFrId);
}

UINT32 dbgSaveCbSwStaTbl(UINT32 swIndex, T_BspHalAdaptCbSwStaTbl* tSwStaTbl, UINT32 len)
{
    UINT32 loop = 0;
    
    for(loop = 0; loop < MAX_CB_SW_NUM; loop++)
    {
        if(s_tdbgCbSwStaTbl[loop].swIndex == swIndex)
        {
            s_tdbgCbSwStaTbl[loop].pCbSwStaTbl = tSwStaTbl;
            s_tdbgCbSwStaTbl[loop].tblLen = len;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

static UINT32 dbgShowCbSwStaTbl(UINT32 swIndex)
{
    UINT32 loop = 0;
    UINT32 index = 0;
    for(loop = 0; loop < MAX_CB_SW_NUM; loop++)
    {
        if(s_tdbgCbSwStaTbl[loop].swIndex == swIndex)
        {
            index = loop;
            break;
        }
    }
    if(loop == MAX_CB_SW_NUM)
    {
        dbgErr("swIndex error!\n");
        return BSP_ERROR;
    }
    if(s_tdbgCbSwStaTbl[index].pCbSwStaTbl == NULL)
    {
        dbgErr("pCbSwStaTbl is NULL!\n");
        return BSP_ERROR;
    }
    if(s_tdbgCbSwStaTbl[index].tblLen == 0)
    {
        dbgErr("pCbSwStaTbl Len is zero!\n");
        return BSP_ERROR;
    }
    for(loop = 0; loop < s_tdbgCbSwStaTbl[index].tblLen; loop++)
    {
        dbgInfo("[%d]: %d \n",loop,s_tdbgCbSwStaTbl[index].pCbSwStaTbl[loop].uiStatus);
    }
    return BSP_OK;
}
/*设置射频开关强制处于某状态*/
/*sta:1:DPD 3:FWD 4:REV 5:CHK_S 6:CHK_L  period:单位ms*/
UINT32 setcbforcesta(UINT32 swInex, UINT32 chan, UINT32 sta, UINT32 period,UINT32 sw)
{
    UINT32 ret = BSP_OK;
    if(sw == SWITCH_ON)
    {
        ret = BspHalAdaptCbSwForceModeOn(swInex,chan,sta,period);
    }
    else
    {
        ret = BspHalAdaptCbSwForceModeOff(swInex,chan);
    }
    return ret;
}

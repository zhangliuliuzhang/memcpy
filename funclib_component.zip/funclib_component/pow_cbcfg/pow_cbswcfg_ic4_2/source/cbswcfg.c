/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : cbswcfg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了adapter的ICHAL反馈射频开关控制接口 声明
* 注意事项 : cbswcfg相关的所有接口定义，包含维测和对外接口
* 作    者 :   10268066
* 创建日期 : 2020-11-10
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10268066
* 修改日戳: 2020-11-10
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "cbswcfg.h"
#include "cbswcfg_dbg.h"
#include "regdrv.h"


/**********************************************************************
* 函数名称：BspCbSwParaInit(*)
* 功能描述：反馈电子开关射频配置表相关参数初始化
* 输入参数：ptCbSwPara: 参数结构体
*           len: 参数结构体长度
* 输出参数：无
* 返 回 值：BSP_OK
* 其它说明：无
* -----------------------------------------------
 * 修改日期        版本号     修改人       修改内容
 * 2021-11-25     V1.0      10258234       create
***********************************************************************/
UINT32 BspCbSwParaInit(T_BspCbSwPara* ptCbSwPara, UINT32 len)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    UINT32 swIndex = 0;
    T_BspHalAdaptCbSwPara tSwInitCfg = {0};
    for(loop = 0; loop < len; loop++)
    {
        swIndex = ptCbSwPara[loop].swIndex;
        tSwInitCfg.uiTransBitSel = ptCbSwPara[loop].transBitSel;
        tSwInitCfg.uiConnectMode = ptCbSwPara[loop].ConnectMode;
        tSwInitCfg.uiFrId = ptCbSwPara[loop].frameNo;
        tSwInitCfg.uiFrMode = ptCbSwPara[loop].swMode;
        tSwInitCfg.uiFrBitEn = ptCbSwPara[loop].frBitEn;
        tSwInitCfg.uiFwdRevLen = ptCbSwPara[loop].fwdRevLen;
        dbgSaveCbSwPara(swIndex,&tSwInitCfg);
        ret |= BspHalAdaptCbSwParaInit(swIndex,&tSwInitCfg);
        memset(&tSwInitCfg, 0, sizeof(T_SwInitCfg));
    }
    return ret;
}

/**********************************************************************
* 函数名称：BspCbSwStaTblInit(*)
* 功能描述：反馈电子开关射频时间片状态表初始化
* 输入参数：ptCbSwStaTbl: 参数结构体
*         len: 参数结构体长度
* 输出参数：无
* 返 回 值：BSP_OK
* 其它说明：无
* -----------------------------------------------
 * 修改日期        版本号     修改人       修改内容
 * 2021-11-25     V1.0      10258234       create
***********************************************************************/
UINT32 BspCbSwStaTblInit(T_BspCbSwStaTbl* ptCbSwStaTbl,UINT32 len)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    UINT32 swIndex =0;
    UINT32 oneStaTblLen = 0;
    T_BspHalAdaptCbSwStaTbl* ptOneSwStaTbl = NULL;
    for(loop = 0; loop < len; loop++)
    {
        swIndex = ptCbSwStaTbl[loop].swIndex;
        ptOneSwStaTbl = ptCbSwStaTbl[loop].pCbSwStaTbl;
        oneStaTblLen = ptCbSwStaTbl[loop].tblLen;
        ret |= BspHalAdaptCbSwStaTblInit(swIndex,ptOneSwStaTbl,oneStaTblLen);
        dbgSaveCbSwStaTbl(swIndex,ptOneSwStaTbl,oneStaTblLen);
    }
    return ret;
}
/**********************************************************************
* 函数名称：BspCbSwRfTblInit(*)
* 功能描述：电子开关真值表配置
* 输入参数：ptCbSwRfTbl: 参数结构体
*         len: 参数结构体长度
* 输出参数：无
* 返 回 值：BSP_OK
* 其它说明：无
* -----------------------------------------------
 * 修改日期        版本号     修改人       修改内容
 * 2021-11-25     V1.0      10258234       create
***********************************************************************/
UINT32 BspCbSwRfTblInit(T_BspCbSwRfTbl* ptCbSwRfTbl,UINT32 len)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    UINT32 swIndex =0;
    UINT32 rfType = 0;

    for(loop = 0; loop < len; loop++)
    {
        swIndex = ptCbSwRfTbl[loop].swIndex;
        rfType = ptCbSwRfTbl[loop].rfType;
        ret |= BspHalAdaptCbSwRfTblInit(swIndex,rfType,&ptCbSwRfTbl[loop].pCbSwRfTbl);
        dbgSaveCbSwRfTbl(ptCbSwRfTbl,len);
    }
    return ret;
}

/**********************************************************************
* 函数名称：BspCbSwRfTblInit_Fpga(*)
* 功能描述：电子开关真值表配置
* 输入参数：ptCbSwRfTbl: 参数结构体
*         len: 参数结构体长度
* 输出参数：无
* 返 回 值：BSP_OK
* 其它说明：无
* -----------------------------------------------
 * 修改日期        版本号     修改人       修改内容
 * 2021-11-25     V1.0      10258234       create
***********************************************************************/
UINT32 BspCbSwRfTblInit_Fpga(T_BspCbSwRfTbl* ptCbSwRfTbl,UINT32 len)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;
    UINT32 chan = 0;

    BspRegWr(ptCbSwRfTbl[0].swIndex,REG_SW_RAM_WR_EN,0,1);

    for(loop=0; loop<len; loop++)
    {

        if((ptCbSwRfTbl[loop].rfType==E_HAL_RF_RAM_TYPE_FWD) || (ptCbSwRfTbl[loop].rfType==E_HAL_RF_RAM_TYPE_REV))
        {
            for(chan = 0; chan < ptCbSwRfTbl[loop].pCbSwRfTbl.uiChanNum; chan++)
            {
                BspRegWr(ptCbSwRfTbl[0].swIndex,REG_SW_RAM_WR_ADDR,0,(ptCbSwRfTbl[loop].pCbSwRfTbl.uiOneLine[chan]>>16)&0xff);
                BspRegWr(ptCbSwRfTbl[0].swIndex,REG_SW_RAM_WR_DATA,0,ptCbSwRfTbl[loop].pCbSwRfTbl.uiOneLine[chan]&0xffff);
                dbgInfoEx("rfType = %d ADDR = %4d, Val = 0x%04x\n",ptCbSwRfTbl[loop].rfType, (ptCbSwRfTbl[loop].pCbSwRfTbl.uiOneLine[chan]>>16)&0xff,ptCbSwRfTbl[loop].pCbSwRfTbl.uiOneLine[chan]&0xffff);
            }
        }

    }

    BspRegWr(ptCbSwRfTbl[0].swIndex,REG_SW_RAM_WR_EN,0,0);

    return ret;
}

/**********************************************************************
* 函数名称：BspCbPinSwTblInit(*)
* 功能描述：电子开关外部管脚来源IC内部哪套射频控制选择
* 输入参数：T_BspCbPinSw: 参数结构体
*         len: 参数结构体长度
* 输出参数：无
* 返 回 值：BSP_OK
* 其它说明：无
* -----------------------------------------------
 * 修改日期        版本号     修改人       修改内容
 * 2021-11-25     V1.0      10258234       create
***********************************************************************/
UINT32 BspCbPinSwTblInit(T_BspCbPinSw* ptCbPinSwTbl,UINT32 len)
{
    UINT32 ret = BSP_OK;
    UINT32 loop = 0;

    for(loop = 0; loop < len; loop++)
    {
        ret |= BspHalAdaptCbPinSw(ptCbPinSwTbl[loop].pinName,ptCbPinSwTbl[loop].sw);
        dbgSaveCbPinSwTbl(ptCbPinSwTbl,len);
    }
    return ret;
}


/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : tddcfg_ic3_dbg.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了tdd信号生成配置接口声明
* 注意事项 : 无
* 作    者 :   10121018
* 创建日期 : 2019-03-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_TDDCFG_IC4_2_DBG_H_
#define _FUNCLIB_TDDCFG_IC4_2_DBG_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    E_TEST_TDD_CFG_NR_5MS_7DS2U644 = 0,     //NR帧格式 5ms单周期 7D1S2U 6:4:4
    E_TEST_TDD_CFG_LTE_5MS_27,              //LTE帧格式 27配比 
    E_TEST_TDD_CFG_NR_2P5MS_3D1U1022,       //NR帧格式 2.5ms单周期 3D1S1U 10:2:2
    E_TEST_TDD_CFG_NR_3PLUS2_644,           //NR帧格式 3+2 6:4:4
    E_TEST_TDD_CFG_NR_2P5MS_SP_1D3U1022,    //NR帧格式 2.5ms单周期 1D3U 10:2:2
    E_TEST_TDD_CFG_NR_2P5MS_DP_1D3U1022,    //NR帧格式 2.5ms双周期 1D3U 10:2:2    
    E_TEST_TDD_CFG_LTE_5MS_38,              //LTE帧格式 38配比 
    E_TEST_TDD_CFG_MAX
} E_TestTddFrFormatType;

UINT32 TestGetTddIndicateNewCfg(E_TestTddFrFormatType frFormatType, T_CarrTddIndicateNewCfg *pCfg);
VOID DbgPrnTddCfg(T_TddCfg *tddIndCfg);
VOID DbgPrnTxTddCfg(T_TxTddCfg *txTddIndCfg);
VOID DbgPrnRxTddCfg(T_RxTddCfg *txTddIndCfg);
UINT32 test_TddCfg(UINT32 groupId, UINT32 radioMode, UINT32 chanMask);
UINT32 test_TddCfgInfo(UINT32 groupNum, UINT32 validFlag);
UINT32 test_TddCfgGroupGroupTddInfo(UINT32 groupIndex, UINT32 groupId, UINT32 chanMask, UINT32 carrNum);
UINT32 test_TddCfgCarrTddInfo(UINT32 groupId, UINT32 carrIndex, UINT32 carrNo, UINT32 formatType);
UINT32 clearTestTddCfg(void);
UINT32 tddCfgTest();
#if 0
VOID DbgSaveOptTddCfg(T_CarrTddIndCfg *pTddCfg, UINT32 cfgNum);
#endif
UINT32 ShowTddCfg(T_CarrTddIndCfg *pTddCfg);
UINT32 Test_SetNrTddFrFormatNoStatic(UINT32 formatType);
#ifdef __cplusplus
}
#endif
#endif

/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : tddcfg_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了tdd信号生成配置接口声明
* 注意事项 : 无
* 作    者 :   10121018
* 创建日期 : 2019-03-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_TDDCFG_IC4_2_H_
#define _FUNCLIB_TDDCFG_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif

/* 保存通道组信息，该信息从chanmap中自动解析 */
typedef struct _T_ChanGroupInfo {
    UINT32 txChanGroupNum;                          /* 下行通道组个数 */
    UINT32 txChanGroupMask[MAX_TDD_GROUP_NUM];      /* 下行通道组掩码 */
    UINT32 rxChanGroupNum;                          /* 上行通道组个数 */
    UINT32 rxChanGroupMask[MAX_TDD_GROUP_NUM];      /* 上行通道组掩码 */
} T_ChanGroupInfo;

#define MAX_PERIOD_INDEX_NUM (15)
#define MAX_DL_UL_SW_CNT     (2)
typedef struct _T_TddCfgInfoToFpga {  /*9124 fpga也需要感知部分开关的控制，TDD也需要配置给FPGA*/
    UINT32 swPoint;   /*切换点配置寄存器[7:4]:DwPTS-GP-UpPTS配置 ；[3:0]:上下行配置比*/
    UINT32 period;    /*周期：0.5ms:0 0.625ms:1 1.25ms:2 1ms:3 2ms:4 2.5ms:5  5ms:6 10ms:7 bit0-7 8-15代表两个切换*/
    UINT32 dlUlSwNum; /*0:单周期    1：双周期*/
    UINT32 dlSymbolCnt[MAX_DL_UL_SW_CNT];
    UINT32 ulSymbolCnt[MAX_DL_UL_SW_CNT];
    UINT32 dlSlotCnt[MAX_DL_UL_SW_CNT];
    UINT32 ulSlotCnt[MAX_DL_UL_SW_CNT];
} T_TddCfgInfoToFpga;

typedef struct T_FillAgainTddCfgInfoPartThree {
    UINT32 carrNum;
    UINT32 *loop;
    UINT32 *cnt;
    UINT32 *radio;
    UINT32 *lteFlag;
    UINT32 *carrNumFill;
    UINT32 *nrFlag;
} T_FillAgainTddCfgInfoPartThree;

typedef UINT32 (*FUNC_IS_NEED_REUPDATE_TDD_CFG)(UINT32 tddIndex);
typedef UINT32 (*FUNC_CALLED_AFTER_UPDATE_TDD)(UINT32 tddIndex);
#define MAX_GROUPID_NUM_ONE_TDD         (4)     /*每套TDD对应的groupid的梳理，目前已知的一套TDD对应小区劈裂，是2个groupid*/
#define TDD_NEED_CFG_SWTBL          (0x5a5a)
#define TDD_NEED_ONLY_CFG_DLY       (0xa5a5)
#define TDD_NOT_NEED_CFG            (0)

#define ARR_BOUND_TDDCFG(loop,border)                                         \
    if (loop >= border)                                                       \
    {                                                                         \
        dbgErr("%s : arr bound! loop:%d border:%d",__FUNCTION__,loop,border); \
        return BSP_ERROR;                                                     \
    }                                                                         \


VOID BspSetTddCfgCallBack(FUNC_IS_NEED_REUPDATE_TDD_CFG pFunc1, FUNC_CALLED_AFTER_UPDATE_TDD pFnuc2);

UINT32 BspSetTddCfgInfo(T_TddCfg *tddIndCfg);//配全局
UINT32 BspSetTxTddCfgInfo(T_TxTddCfg *tddTxIndCfg);// 配置TX
UINT32 BspSetRxTddCfgInfo(T_RxTddCfg *tddRxIndCfg);// 配置RX
UINT32 BspGetTddSwitchResult(UINT32 groupId,UINT32 *result);//高层判断是佛切换TDD
UINT32 BspGetTxTddSwitchResult(UINT32 groupId,UINT32 *result);
UINT32 BspGetRxTddSwitchResult(UINT32 groupId,UINT32 *result);
UINT32 BspUpdateTddCfg(UINT32 groupId);//调用
UINT32 BspUpdateTxTddCfg(UINT32 groupId);
UINT32 BspUpdateRxTddCfg(UINT32 groupId);
UINT32 BspGetTddCfgByChan(UINT32 bspchan, T_CarrTddIndCfg *pTddCfg);
UINT32 BspGetTxTddCfgByChan(UINT32 bspchan, T_CarrTddIndCfg *pTddCfg);
UINT32 BspGetTddCfgIdByChanMask(UINT32 antMask);
UINT32 BspGetTxOrRxTddCfgIdByChanMask(UINT32 antMask, UINT32 dir);
UINT32 BspGetTxOrRxChanMaskByTddCfgId(UINT32 tddid, UINT32 dir);
UINT32 BspGetChanGroupInfo(T_ChanGroupInfo *pChnGrpInfo);
UINT32 BspSetChanGroupInfo(T_ChanGroupInfo *pChnGrpInfo);
UINT32 BspSetTddTimingMode(UINT32 tddMode);
UINT32 BspGetTddTimingMode(VOID);
UINT32 BspChnGrpToTddIdxCfg(UINT32 *tddcfgIdx, UINT32 len);
UINT32 BspGetTddChanMaskByChanMask(UINT32 antMask);
VOID DbgPrnAppTddCfg(VOID);
VOID DbgPrnFillTddCfg(VOID);
UINT32 BspGetFirstGpByTddCfg(UINT32 tddId, UINT32 *pRadio, UINT32 *pTime);
UINT32 BspGetTddIndCfgFpga(UINT32 tddId, T_TddCfgInfoToFpga *pCfg);
UINT32 BspSetTddCfgToFpga(UINT32 tddId);
UINT32 BspGetTddPeriodByIndex(UINT32 index);
UINT32 BspCfgNrTddToFpga(UINT32 index);
UINT32 BspUpdateTddCfg_NCR(UINT32 groupId);
UINT32 BspGetTddCfgIdByGrouId(UINT32 groupId,UINT32 *ulIndex,UINT32 *groupIndex);
T_TddCfg *BspGetTddIndCfgBakMem(void);
#ifdef __cplusplus
}
#endif
#endif

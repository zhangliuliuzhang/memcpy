/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : tddcfg_ic3.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了tdd信号生成配置接口实现
* 注意事项 : 无
* 作    者 :   10121018
* 创建日期 : 2019-03-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"
#include "tddcfg_ic4_2.h"
#include "ichaladaptbspapi.h"
#include "chnmap_a.h"
#include "ichaladapt_ic4_2.h"
#include "tddcfg_ic4_2_dbg.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "regdrv.h"
#include "regdrv_access.h"
#include "funccommonapi.h"
#include "freqcfgcommon.h"
#include "freqcfg_ic4_2.h"
#include "funccommon_a.h"
#include "tddcfg_ic4_2_dbg.h"

/*高层下发的TDD配置*/
static T_TddCfg *g_tddIndCfgbak = NULL;
static T_TxTddCfg *g_txTddIndCfgbak = NULL;
static T_RxTddCfg *g_rxTddIndCfgbak = NULL;
/*对应每套TDD所选用的tdd配置的制式*/
static UINT32 ulTddCfgFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 g_txTddCfgFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 g_rxTddCfgFlag[MAX_TDD_GROUP_NUM] = {0};
/*对应每套TDD是否需要重配标志，0：不重配 0x5a5a：重配TDD表象 0xa5a5:重配时延*/
static UINT32 ulTddReCfgFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 g_txTddReCfgFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 g_rxTddReCfgFlag[MAX_TDD_GROUP_NUM] = {0};
/*对于每套TDD的配置标志,1：已配置 0：未重配*/
static UINT32 ulTddReCfgDoneFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 g_txTddReCfgDoneFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 g_rxTddReCfgDoneFlag[MAX_TDD_GROUP_NUM] = {0};
/*存储最终生效给HAL的TDD配置*/
static T_CarrTddIndCfg  g_tddIndCfgDif[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg  g_txTddIndCfgDif[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg  g_rxTddIndCfgDif[MAX_TDD_GROUP_NUM] = {0};
/*存储每组TDD的NR配置*/
static T_CarrTddIndCfg  g_tddIndCfgBak_Nr[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg  g_txTddIndCfgBak_Nr[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg  g_rxTddIndCfgBak_Nr[MAX_TDD_GROUP_NUM] = {0};
/*存储每组TDD的LTE配置*/
static T_CarrTddIndCfg  g_tddIndCfgBak_Lte[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg  g_txTddIndCfgBak_Lte[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg  g_rxTddIndCfgBak_Lte[MAX_TDD_GROUP_NUM] = {0};
/*存储重排后的TDD配置，应对小区劈裂，相同TDD index的配置放在一起*/
static T_TddCfg *g_tddIndCfgFillAgain = NULL;
static T_TxTddCfg *g_txTddIndCfgFillAgain = NULL;
static T_RxTddCfg *g_rxTddIndCfgFillAgain = NULL;
/*给光口的TDD配置*/
T_CarrTddIndCfg  g_tddIndCfgOpt_Nr[MAX_TDD_GROUP_NUM] = {0};
T_CarrTddIndCfg  g_txTddIndCfgOpt_Nr[MAX_TDD_GROUP_NUM] = {0};
T_CarrTddIndCfg  g_rxTddIndCfgOpt_Nr[MAX_TDD_GROUP_NUM] = {0};
T_CarrTddIndCfg  g_tddIndCfgOpt_Lte[MAX_TDD_GROUP_NUM] = {0};
T_CarrTddIndCfg  g_txTddIndCfgOpt_Lte[MAX_TDD_GROUP_NUM] = {0};
T_CarrTddIndCfg  g_rxTddIndCfgOpt_Lte[MAX_TDD_GROUP_NUM] = {0};
T_TddCfgInfoToFpga g_tddIndCfgFpga[MAX_TDD_GROUP_NUM] = {0};
/*给中频的TDD配置*/
static T_CarrTddIndCfg s_dbgdifTddCfg[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg s_dbgdifTxTddCfg[MAX_TDD_GROUP_NUM] = {0};
static T_CarrTddIndCfg s_dbgdifRxTddCfg[MAX_TDD_GROUP_NUM] = {0};
static UINT32 s_dbgGroupId[MAX_TDD_GROUP_NUM] = {0};
static UINT32 s_dbgTxGroupId[MAX_TDD_GROUP_NUM] = {0};
static UINT32 s_dbgRxGroupId[MAX_TDD_GROUP_NUM] = {0};
static UINT32 s_dbgDifTddCfgFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 s_dbgDifTxTddCfgFlag[MAX_TDD_GROUP_NUM] = {0};
static UINT32 s_dbgDifRxTddCfgFlag[MAX_TDD_GROUP_NUM] = {0};

UINT32 tddIndCfgDifGroupNum = 0;
UINT32 txTddIndCfgDifGroupNum = 0;
UINT32 rxTddIndCfgDifGroupNum = 0;
UINT32 tddIndCfgGroupNum_Nr = 0;
UINT32 txTddIndCfgGroupNum_Nr = 0;
UINT32 rxTddIndCfgGroupNum_Nr = 0;
UINT32 tddIndCfgGroupNum_Lte = 0;
UINT32 txTddIndCfgGroupNum_Lte = 0;
UINT32 rxTddIndCfgGroupNum_Lte = 0;
UINT32 g_lastTddSwitch[MAX_TDD_GROUP_NUM][5] = {0};
UINT32 g_lastTxTddSwitch[MAX_TDD_GROUP_NUM][5] = {0};
UINT32 g_lastRxTddSwitch[MAX_TDD_GROUP_NUM][5] = {0};

/*TDD ID和Group ID映射关系*/
static UINT32 g_tddIdGroupIdMap[MAX_TDD_GROUP_NUM][MAX_GROUPID_NUM_ONE_TDD] = {0};/*和APP确认，groupid网管可配0~255，低16bit为chanmask，高16bit为groupid*/
static UINT32 g_txTddIdGroupIdMap[MAX_TDD_GROUP_NUM][MAX_GROUPID_NUM_ONE_TDD] = {0};
static UINT32 g_rxTddIdGroupIdMap[MAX_TDD_GROUP_NUM][MAX_GROUPID_NUM_ONE_TDD] = {0};

/*按照fpga寄存器的含义定义tdd配置参数*/
T_TddCfgInfoToFpga g_ulTddCfgInfoToFpga[] =
{
  {0},   /*清除使用*/
  {0,0x6,0,{0x3f,0},{0x3c00,0},{0x7f,0},{0x300,0}}, /*NR_5MS_7DS2U644*/
  {0,0x5,0,{0x3ff,0},{0x3000,0},{0x7,0},{0x10,0}},  /*NR_2P5MS_3D1U1022*/
  {0,0x6,0,{0x3f,0},{0x3c00,0},{0x3C7,0},{0x30,0}},  /*NR_3PLUS2_644 DDDSUUDDDD*/
  {0,0x5,0,{0x3ff,0},{0x3000,0},{0x1,0},{0x1c,0}},  /*NR_2P5MS_SP_1D3U1022*/
  {0,0x0505,1,{0x3ff,0x3ff},{0x3000,0x3000},{0x7,0x3},{0x10,0x18}},  /*NR_2P5MS_DP_1D3U1022 DDDSUDDSUU*/
};
/* 保存通道组信息，该信息从chanmap中自动解析 */
static T_ChanGroupInfo s_ChanGroupInfo = { 0 };
#if 0/*暂时无用*/
static UINT32 s_ulTddTimingModeSelect = TDD_TIMING_MODE_SELECT_1; //lte和nr默认选择第一套tdd配置,该模式指通道级tdd模式
/*规格下传入TDD控制模式选择，默认选择第1套*/
UINT32 BspSetTddTimingMode(UINT32 tddMode)
{
    s_ulTddTimingModeSelect = tddMode;
    return BSP_OK;
}

UINT32 BspGetTddTimingMode(VOID)
{
    return s_ulTddTimingModeSelect;
}
#endif
/* 可以通过挂接以下回调来增加更新TDD的判断条件 */
FUNC_IS_NEED_REUPDATE_TDD_CFG p_FuncIsNeedUpdateTdd = NULL;
FUNC_CALLED_AFTER_UPDATE_TDD p_FuncCalledAfterUpdateTdd = NULL;

static UINT32 DbgSaveDifTddCfg(T_CarrTddIndCfg *pTddCfg, UINT32 groupId, UINT32 tddCfgId);

/*单板下需要挂接*/
VOID BspSetTddCfgCallBack(FUNC_IS_NEED_REUPDATE_TDD_CFG pFunc1, FUNC_CALLED_AFTER_UPDATE_TDD pFnuc2)
{
    p_FuncIsNeedUpdateTdd = pFunc1;
    p_FuncCalledAfterUpdateTdd = pFnuc2;
    return;
}

/*记录TDD配置*/
UINT32 recordTddIndCfg(T_TddCfg *destCfg,T_TddCfg *srcCfg)
{
    INPUT_POINTER_CHECK(destCfg);
    INPUT_POINTER_CHECK(srcCfg);
    memset_s(destCfg,sizeof(T_TddCfg),0,sizeof(T_TddCfg));
    memcpy_s(destCfg,sizeof(T_TddCfg),srcCfg,sizeof(T_TddCfg));
    return BSP_OK;
}
/* 记录TDD配置:下行 */
UINT32 recordTxTddIndCfg(T_TxTddCfg *destCfg,T_TxTddCfg *srcCfg)
{
    INPUT_POINTER_CHECK(destCfg);
    INPUT_POINTER_CHECK(srcCfg);
    memset_s(destCfg,sizeof(T_TxTddCfg),0,sizeof(T_TxTddCfg));
    memcpy_s(destCfg,sizeof(T_TxTddCfg),srcCfg,sizeof(T_TxTddCfg));
    return BSP_OK;
}

/* 记录TDD配置:上行 */
UINT32 recordRxTddIndCfg(T_RxTddCfg *destCfg,T_RxTddCfg *srcCfg)
{
    INPUT_POINTER_CHECK(destCfg);
    INPUT_POINTER_CHECK(srcCfg);
    memset_s(destCfg,sizeof(T_RxTddCfg),0,sizeof(T_RxTddCfg));
    memcpy_s(destCfg,sizeof(T_RxTddCfg),srcCfg,sizeof(T_RxTddCfg));
    return BSP_OK;
}

/**清除对应TDD配置*/
UINT32 clrCarrTddIndCfg(T_CarrTddIndCfg *carrTddIndCfg)
{
    INPUT_POINTER_CHECK(carrTddIndCfg);
    memset_s(carrTddIndCfg,sizeof(T_CarrTddIndCfg),0,sizeof(T_CarrTddIndCfg));
    return BSP_OK;
}

/**TX:清除对应TDD配置*/
UINT32 clrCarrTxTddIndCfg(T_CarrTddIndCfg *carrTddIndCfg)
{
    INPUT_POINTER_CHECK(carrTddIndCfg);
    memset_s(carrTddIndCfg,sizeof(T_CarrTddIndCfg),0,sizeof(T_CarrTddIndCfg));
    return BSP_OK;
}

static UINT32 clrGroupIdToTddIdMap(void)
{
    UINT32 tddIndex = 0;
    UINT32 groupIdLoop = 0;
    for(tddIndex = 0; tddIndex < MAX_TDD_GROUP_NUM; tddIndex++)
    {
        for(groupIdLoop = 0; groupIdLoop < MAX_GROUPID_NUM_ONE_TDD; groupIdLoop++)
        {
            g_tddIdGroupIdMap[tddIndex][groupIdLoop] = BSP_INVALID_VALUE;
        }
    }
    return BSP_OK;
}

static UINT32 clrGroupIdToTxOrRxTddIdMap(UINT32 dir)
{
    UINT32 tddIndex = 0;
    UINT32 groupIdLoop = 0;
    for(tddIndex = 0; tddIndex < MAX_TDD_GROUP_NUM; tddIndex++)
    {
        ARR_BOUND_TDDCFG(tddIndex,MAX_TDD_GROUP_NUM);
        for(groupIdLoop = 0; groupIdLoop < MAX_GROUPID_NUM_ONE_TDD; groupIdLoop++)
        {
            ARR_BOUND_TDDCFG(groupIdLoop,MAX_GROUPID_NUM_ONE_TDD);
            if(TX == dir)
            {
                g_txTddIdGroupIdMap[tddIndex][groupIdLoop] = BSP_INVALID_VALUE;
            }
            else
            {
                g_rxTddIdGroupIdMap[tddIndex][groupIdLoop] = BSP_INVALID_VALUE;
            }
        }
    }
    return BSP_OK;
}

static UINT32 setGroupIdToTddIdMap(UINT32 tddId, UINT32 groupId, UINT32 chanMask)
{
    UINT32 groupIdLoop = 0;

    dbgInfoEx("[%s]tddId:%d, groupId:%d, chanMask:%d\n",__FUNCTION__,tddId, groupId, chanMask);
    if(tddId >= MAX_TDD_GROUP_NUM)
    {
        dbgInfoEx("%s groupId=%d, ulIndex=%d, tddid is over\n", __FUNCTION__, groupId, tddId);
        return BSP_ERROR;
    }

    for(groupIdLoop = 0; groupIdLoop < MAX_GROUPID_NUM_ONE_TDD; groupIdLoop++)
    {
        if(g_tddIdGroupIdMap[tddId][groupIdLoop] == BSP_INVALID_VALUE)
        {
            g_tddIdGroupIdMap[tddId][groupIdLoop] = ((groupId & 0xffff)<<16) | (chanMask & 0xffff);
            dbgInfoEx("%s ulIndex=%d groupid=%d chanmask=%d groupIdLoop=%d %d\n", __FUNCTION__,tddId,groupId,chanMask,groupIdLoop,g_tddIdGroupIdMap[tddId][groupIdLoop]);
            break;
        }
    }

    if(groupIdLoop == MAX_GROUPID_NUM_ONE_TDD)
    {
        dbgErr("%s groupId=%d, ulIndex=%d, groupnum is over\n", __FUNCTION__, groupId, tddId);
        return BSP_ERROR;
    }
    return BSP_OK;
}

static UINT32 setGroupIdToTxOrRxTddIdMap(UINT32 tddId, UINT32 groupId, UINT32 chanMask, UINT32 dir)
{
    UINT32 groupIdLoop = 0;

    dbgInfoEx("[%s]tddId:%d, groupId:%d, chanMask:%d dir:%d \n",__FUNCTION__,tddId, groupId, chanMask,dir);
   

    for(groupIdLoop = 0; groupIdLoop < MAX_GROUPID_NUM_ONE_TDD; groupIdLoop++)
    {
        ARR_BOUND_TDDCFG(tddId,MAX_TDD_GROUP_NUM);
        ARR_BOUND_TDDCFG(groupIdLoop,MAX_GROUPID_NUM_ONE_TDD);
        if((TX ==dir) && (g_txTddIdGroupIdMap[tddId][groupIdLoop] == BSP_INVALID_VALUE))
        {
            g_txTddIdGroupIdMap[tddId][groupIdLoop] = ((groupId & 0xffff)<<16) | (chanMask & 0xffff);
            dbgInfoEx("%s ulIndex=%d groupid=%d chanmask=%d groupIdLoop=%d g_txTddIdGroupIdMap:%d\n", __FUNCTION__,tddId,groupId,chanMask,groupIdLoop,g_txTddIdGroupIdMap[tddId][groupIdLoop]);
            break;
        }
        else if((RX ==dir) && (g_rxTddIdGroupIdMap[tddId][groupIdLoop] == BSP_INVALID_VALUE))
        {
            g_rxTddIdGroupIdMap[tddId][groupIdLoop] = ((groupId & 0xffff)<<16) | (chanMask & 0xffff);
            dbgInfoEx("%s ulIndex=%d groupid=%d chanmask=%d groupIdLoop=%d g_rxTddIdGroupIdMap:%d\n", __FUNCTION__,tddId,groupId,chanMask,groupIdLoop,g_rxTddIdGroupIdMap[tddId][groupIdLoop]);
            break;
        }
    }

    if(groupIdLoop == MAX_GROUPID_NUM_ONE_TDD)
    {
        dbgErr("%s groupId=%d, ulIndex=%d, groupnum is over\n", __FUNCTION__, groupId, tddId);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*记录某载波的TDD配置*/
UINT32 recordCarrTddIndCfg(T_CarrTddIndCfg *destCfg,T_CarrTddIndCfg *srcCfg)
{
    INPUT_POINTER_CHECK(destCfg);
    INPUT_POINTER_CHECK(srcCfg);
    memset_s(destCfg,sizeof(T_CarrTddIndCfg),0,sizeof(T_CarrTddIndCfg));
    memcpy_s(destCfg, sizeof(T_CarrTddIndCfg), srcCfg,sizeof(T_CarrTddIndCfg));
    return BSP_OK;
}

/* 根据Chanmap解析出通道组信息，默认天线通道组号(chanmap中第8列)为TDD索引 */
UINT32 BspGetChanGroupInfo(T_ChanGroupInfo *pChnGrpInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 chan = 0;
    UINT32 group = 0;
    UINT32 txChanMask[MAX_TDD_GROUP_NUM] = {0};
    UINT32 rxChanMask[MAX_TDD_GROUP_NUM] = {0};
    UINT32 antId = 0;
    UINT32 antChn = 0;

    INPUT_POINTER_CHECK(pChnGrpInfo);

    /* 如果通道信息已经获取过，则直接返回 */
    if(s_ChanGroupInfo.txChanGroupNum && s_ChanGroupInfo.rxChanGroupNum)
    {
        memcpy_s(pChnGrpInfo, sizeof(T_ChanGroupInfo), &s_ChanGroupInfo, sizeof(T_ChanGroupInfo));
        return BSP_OK;
    }

    /* 如果通道信息还没有获取过，则调用接口从chanmap中解析出来 */
    /* 解析TX */
    for(chan=0; chan<BspGetTxChanNum(); chan++)
    {
        retVal = BspGetAntInfoByBspChn(chan, TX, &antId, &antChn);
        CHECK_RETVAL(BspGetAntInfoByBspChn,retVal);
        if(antChn < MAX_TDD_GROUP_NUM)
        {
            //coverity[cert_int31_c_violation:SUPPRESS]
            VAR_BIT_SET(txChanMask[antChn],chan);
        }
    }
    /* 解析RX */
    for(chan=0; chan<BspGetRxChanNum(); chan++)
    {
        retVal = BspGetAntInfoByBspChn(chan, RX, &antId, &antChn);
        CHECK_RETVAL(BspGetAntInfoByBspChn,retVal);
        if(antChn < MAX_TDD_GROUP_NUM)
        {
            //coverity[cert_int31_c_violation:SUPPRESS]
            VAR_BIT_SET(rxChanMask[antChn],chan);
        }            
    }
    /* 计算通道组数并更新到全局变量中保存 */
    for(group=0; group<MAX_TDD_GROUP_NUM; group++)
    {
        s_ChanGroupInfo.txChanGroupMask[group] = txChanMask[group];
        if(s_ChanGroupInfo.txChanGroupMask[group])
        {
            s_ChanGroupInfo.txChanGroupNum++;
        }
        s_ChanGroupInfo.rxChanGroupMask[group] = rxChanMask[group];
        if(s_ChanGroupInfo.rxChanGroupMask[group])
        {
             s_ChanGroupInfo.rxChanGroupNum++;
        }       
    }
    memcpy_s(pChnGrpInfo, sizeof(T_ChanGroupInfo), &s_ChanGroupInfo, sizeof(T_ChanGroupInfo));
    return retVal;   
}

/* 当不希望使用通过chanmap解析出的通道组时，可以通过本接口进行配置tdd索引于通道之间的关系 */
UINT32 BspSetChanGroupInfo(T_ChanGroupInfo *pChnGrpInfo)
{
    INPUT_POINTER_CHECK(pChnGrpInfo);

    memcpy_s(&s_ChanGroupInfo, sizeof(T_ChanGroupInfo), pChnGrpInfo, sizeof(T_ChanGroupInfo));
    return BSP_OK;

}

/* 
    tdd索引和通道组对应关系，该关系可以从单板下制定
*/
static UINT32 s_ChanGroup2TddCfgId[MAX_TDD_GROUP_NUM] = {0, 1, 2, 3};

UINT32 BspChnGrpToTddIdxCfg(UINT32 *tddcfgIdx, UINT32 len)
{
    if(len > MAX_TDD_GROUP_NUM)
    {
        return BSP_ERROR; 
    }
    memcpy_s(s_ChanGroup2TddCfgId, sizeof(UINT32)*4, tddcfgIdx, sizeof(UINT32)*4);
    return BSP_OK;
}

/*
 * 通过天线掩码获取TDD索引
*/
UINT32 BspGetTddCfgIdByChanMask(UINT32 antMask)
{
    UINT32 chanGrp = 0;
    UINT32 chanMask = 0;
    UINT32 destGrp = 0;
    UINT32 loop = 0;
    UINT32 retVal = 0;
    T_ChanGroupInfo chanGroupInfo = {0};

    if(BSP_OK != BspGetChanGroupInfo(&chanGroupInfo) || chanGroupInfo.txChanGroupNum == 0)
    {
        dbgErr("%s Get Chan Group Info err\n",__func__);
        return 0;
    }
    
    if(chanGroupInfo.txChanGroupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s error of chan group num > 4\n", __func__);
        return 0;
    }

    if(IS_NCR == BspIsNcr())
    {
        for(loop = 0; loop < BSP_HALADAPT_IC_CHAN_MAX_NUM; loop++)
        {
            if((0x1<<loop) & antMask)
            {
                retVal = BspGetTddIdByTxChInOneLink(loop, TX, &destGrp);
                CHECK_RETVAL(BspGetTddIdByTxChInOneLink, retVal);
                break;
            }
        }
    }
    else
    {
        for(chanGrp=0; chanGrp<chanGroupInfo.txChanGroupNum;chanGrp++)
        {
            chanMask = chanGroupInfo.txChanGroupMask[chanGrp];
            dbgInfoEx("%s antMask=%#x chanMask=%#x\n", __func__, antMask, chanMask);
            if(antMask & chanMask)
            {
                destGrp = chanGrp;
                break;
            }
        }    
        if(chanGrp == chanGroupInfo.txChanGroupNum)
        {
            dbgErr("%s fail to find antmask(%#x) in chan group info \n", __func__, antMask);
        }
    }
    dbgInfoEx("%s destGrp=%#x\n", __func__, destGrp);

    return s_ChanGroup2TddCfgId[destGrp];
}

/*
 * 通过天线掩码获取TDD索引
*/
UINT32 BspGetTxOrRxTddCfgIdByChanMask(UINT32 antMask, UINT32 dir)
{
    UINT32 chanGrp = 0;
    UINT32 chanMask = 0;
    UINT32 destGrp = 0;
    T_ChanGroupInfo chanGroupInfo = {0};
    UINT32 chanGroupNum = 0 ;
    
    if(BSP_OK != BspGetChanGroupInfo(&chanGroupInfo) || chanGroupInfo.txChanGroupNum == 0)
    {
        dbgErr("%s Get Chan Group Info err\n",__func__);
        return 0;
    }

    chanGroupNum = (TX == dir) ? chanGroupInfo.txChanGroupNum:chanGroupInfo.rxChanGroupNum;
    
    if(chanGroupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s error of chan group num > 4\n", __func__);
        return 0;
    }
    
    for(chanGrp=0; chanGrp<chanGroupNum; chanGrp++)
    {
        ARR_BOUND_TDDCFG(chanGrp,chanGroupNum);
        chanMask = (TX == dir) ? chanGroupInfo.txChanGroupMask[chanGrp]:chanGroupInfo.rxChanGroupMask[chanGrp];
        dbgInfoEx("%s antMask=%#x chanMask=%#x dir:%d \n", __func__, antMask, chanMask,dir);
        if(antMask & chanMask)
        {
           destGrp = chanGrp;
           break;
        }
    }    
    if(chanGrp == chanGroupNum)
    {
        dbgErr("%s fail to find antmask(%#x) in chan group info \n", __func__, antMask);
    }

    ARR_BOUND_TDDCFG(destGrp,MAX_TDD_GROUP_NUM);
    return s_ChanGroup2TddCfgId[destGrp];
}

/* Started by AICoder, pid:c2123mcffe79f7b14ded084ce0a7ba3ca0f28ce0 */
/*
 * 通过TDD索引获取天线掩码
*/
UINT32 BspGetTxOrRxChanMaskByTddCfgId(UINT32 tddid, UINT32 dir)
{
    UINT32 chanGrp = 0;
    UINT32 chanMask = 0;
    T_ChanGroupInfo chanGroupInfo = {0};
    UINT32 chanGroupNum = 0 ;
    
    if(BSP_OK != BspGetChanGroupInfo(&chanGroupInfo) || chanGroupInfo.txChanGroupNum == 0)
    {
        dbgErr("%s Get Chan Group Info err\n",__func__);
        return chanMask;
    }

    chanGroupNum = (TX == dir) ? chanGroupInfo.txChanGroupNum:chanGroupInfo.rxChanGroupNum;
    
    if(chanGroupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s error of chan group num > 4\n", __func__);
        return chanMask;
    }
    
    for(chanGrp = 0; chanGrp < chanGroupNum; chanGrp++)
    {
        ARR_BOUND_TDDCFG(chanGrp, chanGroupNum);
        if (s_ChanGroup2TddCfgId[chanGrp] == tddid)
        {
            chanMask = (TX == dir) ? chanGroupInfo.txChanGroupMask[chanGrp]:chanGroupInfo.rxChanGroupMask[chanGrp];
            break;
        }
    }

    return chanMask;
}
/* Ended by AICoder, pid:c2123mcffe79f7b14ded084ce0a7ba3ca0f28ce0 */


/*
 * 通过通道掩码获取对应TDD的所有通道的掩码
*/
UINT32 BspGetTddChanMaskByChanMask(UINT32 antMask)
{
    UINT32 chanGrp = 0;
    UINT32 chanMask = 0xff;
    T_ChanGroupInfo chanGroupInfo = {0};

    if((BSP_OK != BspGetChanGroupInfo(&chanGroupInfo)) || (chanGroupInfo.txChanGroupNum == 0))
    {
        dbgErr("%s Get Chan Group Info err\n",__func__);
        return chanMask;
    }

    if(chanGroupInfo.txChanGroupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s error of chan group num > 4\n", __func__);
        return chanMask;
    }

    for(chanGrp=0; chanGrp<chanGroupInfo.txChanGroupNum; chanGrp++)
    {
        chanMask = chanGroupInfo.txChanGroupMask[chanGrp];
        dbgInfoEx("%s antMask=%#x chanMask=%#x\n", __func__, antMask, chanMask);
        if(antMask & chanMask)
        {
            if(IS_NCR == BspIsNcr())
            {
                return antMask;
            }
            else
            {
                return chanMask;
            }
        }
    }
    if(chanGrp == chanGroupInfo.txChanGroupNum)
    {
        chanMask = 0xff;/*如果找不到，默认是全天线*/
        dbgErr("%s fail to find antmask(%#x) in chan group info \n", __func__, antMask);
    }

    return chanMask;
}

/*
 * TX:通过通道掩码获取对应TDD的所有通道的掩码
*/
UINT32 BspGetTxOrRxTddChanMaskByChanMask(UINT32 antMask, UINT32 dir)
{
    UINT32 retVal = BSP_OK;
    UINT32 chanGrp = 0;
    UINT32 chanMask = 0xff;
    UINT32 groupNum = 0;    
    T_ChanGroupInfo chanGroupInfo = {0};

    retVal = BspGetChanGroupInfo(&chanGroupInfo);
    groupNum  = (TX == dir) ? chanGroupInfo.txChanGroupNum:chanGroupInfo.rxChanGroupNum;

    if((BSP_OK != retVal) || (groupNum == 0))
    {
        dbgErr("%s dir:%d Get Chan Group Info err\n",__func__,dir);
        return chanMask;
    }

    if(groupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s dir:%d  error of chan group num > 4\n", __func__,dir);
        return chanMask;
    }

    for(chanGrp=0; chanGrp<groupNum; chanGrp++)
    {
        ARR_BOUND_TDDCFG(chanGrp,groupNum);
        chanMask = (TX == dir) ? chanGroupInfo.txChanGroupMask[chanGrp]:chanGroupInfo.rxChanGroupMask[chanGrp];
        dbgInfoEx("%s dir:%d antMask=%#x chanMask=%#x\n", __func__, antMask, chanMask,dir);
        if(antMask & chanMask)
        {
           return chanMask;
        }
    }
    if(chanGrp == groupNum)
    {
        chanMask = 0xff;/*如果找不到，默认是全天线*/
        dbgErr("%s dir:%d fail to find antmask(%#x) in chan group info \n", __func__, antMask,dir);
    }

    return chanMask;
}

/*相同TDD索引下，根据制式在高层下发的各个载波中，选取一个对应制式的载波的TDD配置*/
UINT32 getTddIndCfgByMode(UINT32 radioMode, T_TddIndicateNewCfg *tddIndCfg, T_CarrTddIndCfg *carrTddIndCfg)
{
    UINT32 ulRet = BSP_ERROR;
    UINT32 ulCarrNum = 0;
    UINT32 ulcarr = 0;
    UINT32 ulCarrRadio = 0;

    ulCarrNum = tddIndCfg->carrNum;
    for(ulcarr = 0; ulcarr < ulCarrNum; ulcarr++)
    {
        ulCarrRadio = tddIndCfg->carrTddIndicateCfg[ulcarr].radioMode;
        if(radioMode == ulCarrRadio)
        {
            carrTddIndCfg->uiGroupId   = tddIndCfg->groupId;
            carrTddIndCfg->uiTddCfgId  = BspGetTddCfgIdByChanMask(tddIndCfg->chanMask);
            carrTddIndCfg->uiCarrNo    = tddIndCfg->carrTddIndicateCfg[ulcarr].carrNo;
            carrTddIndCfg->uiRadioMode = ulCarrRadio;
            carrTddIndCfg->uiChanMask  = tddIndCfg->chanMask;
            carrTddIndCfg->uiDlUlSwNum = tddIndCfg->carrTddIndicateCfg[ulcarr].dlUlSwNum;
            memcpy_s(carrTddIndCfg->uiDlUlSwPeriod,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                    tddIndCfg->carrTddIndicateCfg[ulcarr].dlUlSwPeriod, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            memcpy_s(carrTddIndCfg->uiDlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                                    tddIndCfg->carrTddIndicateCfg[ulcarr].dlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            memcpy_s(carrTddIndCfg->uiUlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                                    tddIndCfg->carrTddIndicateCfg[ulcarr].ulSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            ulRet = BSP_OK;
            break;
        }
    }
    if(ulcarr == ulCarrNum)
    {
        dbgErr("%s don't find radio=%d tdd cfg!\n", __FUNCTION__, radioMode);
        return BSP_ERROR;
    }
    return ulRet;
}

/*TX:相同TDD索引下，根据制式在高层下发的各个载波中，选取一个对应制式的载波的TDD配置*/
UINT32 getTxTddIndCfgByMode(UINT32 radioMode, T_TxTddIndicateNewCfg *tddIndCfg, T_CarrTddIndCfg *carrTddIndCfg)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 carrNum = 0;
    UINT32 carrIndex = 0;
    UINT32 carrRadio = 0;

    carrNum = tddIndCfg->carrNum;
    for(carrIndex = 0; carrIndex < carrNum; carrIndex++)
    {
        ARR_BOUND_TDDCFG(carrIndex,carrNum);
        carrRadio = tddIndCfg->carrTddIndicateCfg[carrIndex].radioMode;
        if(radioMode == carrRadio)
        {
            carrTddIndCfg->uiGroupId   = tddIndCfg->groupId;
            carrTddIndCfg->uiTddCfgId  = BspGetTxOrRxTddCfgIdByChanMask(tddIndCfg->chanMask,TX);
            carrTddIndCfg->uiCarrNo    = tddIndCfg->carrTddIndicateCfg[carrIndex].carrNo;
            carrTddIndCfg->uiRadioMode = carrRadio;
            carrTddIndCfg->uiChanMask  = tddIndCfg->chanMask;
            carrTddIndCfg->uiDlUlSwNum = tddIndCfg->carrTddIndicateCfg[carrIndex].dlUlSwNum;
            memcpy_s(carrTddIndCfg->uiDlUlSwPeriod,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                    tddIndCfg->carrTddIndicateCfg[carrIndex].dlUlSwPeriod, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            memcpy_s(carrTddIndCfg->uiDlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                                    tddIndCfg->carrTddIndicateCfg[carrIndex].dlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            memcpy_s(carrTddIndCfg->uiUlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                                    tddIndCfg->carrTddIndicateCfg[carrIndex].ulSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            retVal = BSP_OK;
            break;
        }
    }
    if(carrIndex == carrNum)
    {
        dbgErr("%s don't find radio=%d tdd cfg!\n", __FUNCTION__, radioMode);
        return BSP_ERROR;
    }
    return retVal;
}

/*RX:相同TDD索引下，根据制式在高层下发的各个载波中，选取一个对应制式的载波的TDD配置*/
UINT32 getRxTddIndCfgByMode(UINT32 radioMode, T_RxTddIndicateNewCfg *tddIndCfg, T_CarrTddIndCfg *carrTddIndCfg)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 carrNum = 0;
    UINT32 carrIndex = 0;
    UINT32 carrRadio = 0;

    carrNum = tddIndCfg->carrNum;
    for(carrIndex = 0; carrIndex < carrNum; carrIndex++)
    {
        ARR_BOUND_TDDCFG(carrIndex,carrNum);
        carrRadio = tddIndCfg->carrTddIndicateCfg[carrIndex].radioMode;
        if(radioMode == carrRadio)
        {
            carrTddIndCfg->uiGroupId   = tddIndCfg->groupId;
            carrTddIndCfg->uiTddCfgId  = BspGetTxOrRxTddCfgIdByChanMask(tddIndCfg->chanMask,RX);
            carrTddIndCfg->uiCarrNo    = tddIndCfg->carrTddIndicateCfg[carrIndex].carrNo;
            carrTddIndCfg->uiRadioMode = carrRadio;
            carrTddIndCfg->uiChanMask  = tddIndCfg->chanMask;
            carrTddIndCfg->uiDlUlSwNum = tddIndCfg->carrTddIndicateCfg[carrIndex].dlUlSwNum;
            memcpy_s(carrTddIndCfg->uiDlUlSwPeriod,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                    tddIndCfg->carrTddIndicateCfg[carrIndex].dlUlSwPeriod, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            memcpy_s(carrTddIndCfg->uiDlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                                    tddIndCfg->carrTddIndicateCfg[carrIndex].dlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            memcpy_s(carrTddIndCfg->uiUlSymbolNum,MAX_UL_DL_SW_NUM*sizeof(UINT32),\
                                    tddIndCfg->carrTddIndicateCfg[carrIndex].ulSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32));
            retVal = BSP_OK;
            break;
        }
    }
    if(carrIndex == carrNum)
    {
        dbgErr("%s don't find radio=%d tdd cfg!\n", __FUNCTION__, radioMode);
        return BSP_ERROR;
    }
    return retVal;
}

/*通过天线掩码和高层groupId获取对应的TDD索引*/
VOID getTddCfgIndex(UINT32 ulGroupId, UINT32 antMask, UINT32 *index)
{
    UINT32 ulCnt = 0;
    UINT32 groupId = 0;
    UINT32 chanMask = 0;

    for(ulCnt = 0; ulCnt < MAX_TDD_GROUP_NUM; ulCnt++)
    {
        chanMask = g_tddIndCfgDif[ulCnt].uiChanMask;
        groupId  = g_tddIndCfgDif[ulCnt].uiGroupId;
        if((ulGroupId == groupId)&& (antMask == chanMask))
        {
            *index = ulCnt;
            break;
        }
    }
    if(MAX_TDD_GROUP_NUM == ulCnt)
    {
        *index = BspGetTddCfgIdByChanMask(antMask); /*如果找不到就将天线掩码的组号代表第几套tdd*/
    }
    return;
}

/*TX RX:通过天线掩码和高层groupId获取对应的TDD索引*/
UINT32 getTxOrRxTddCfgIndex(UINT32 ulGroupId, UINT32 antMask, UINT32 *index, UINT32 dir)
{
    UINT32 cnt = 0;
    UINT32 groupId = 0;
    UINT32 chanMask = 0;

    for(cnt = 0; cnt < MAX_TDD_GROUP_NUM; cnt++)
    {
        ARR_BOUND_TDDCFG(cnt,MAX_TDD_GROUP_NUM);
        if (TX == dir)
        {
            chanMask = g_txTddIndCfgDif[cnt].uiChanMask;
            groupId  = g_txTddIndCfgDif[cnt].uiGroupId;
            if((ulGroupId == groupId)&& (antMask == chanMask))
            {
                *index = cnt;
                break;
            }
        }
        else
        {
            chanMask = g_rxTddIndCfgDif[cnt].uiChanMask;
            groupId  = g_rxTddIndCfgDif[cnt].uiGroupId;
            if((ulGroupId == groupId)&& (antMask == chanMask))
            {
                *index = cnt;
                break;
            }
        }
        
        
    }
    if(MAX_TDD_GROUP_NUM == cnt)
    {
        *index = BspGetTxOrRxTddCfgIdByChanMask(antMask,dir); /*如果找不到就将天线掩码的组号代表第几套tdd*/
    }
    return BSP_OK;
}

/*清除无效的TDD配置*/
VOID BspClrTddIndCfgDif(T_TddCfg *tddIndCfg)
{
    /*UINT32 ulRet = BSP_ERROR;*/
    UINT32 ulCnt0 = 0;
    UINT32 ulCnt1 = 0;
    UINT32 antMask = 0;
    UINT32 groupNum = 0;

    groupNum =  tddIndCfg->groupNum;
    for(ulCnt0 = 0; ulCnt0 < MAX_TDD_GROUP_NUM; ulCnt0++)
    {
        /*先将上一次保存的光口配置全部清除*/
        clrCarrTddIndCfg(&g_tddIndCfgOpt_Nr[ulCnt0]);
        clrCarrTddIndCfg(&g_tddIndCfgOpt_Lte[ulCnt0]);
        tddIndCfgGroupNum_Nr = 0;
        tddIndCfgGroupNum_Lte= 0;
        /*根据天线掩码，依次轮循上一次TDD的配置，如果能够在当前APP下发的TDD配置中找到对应的天线掩码，则认为tdd配置存在或者改变，暂不处理；
         * 如果找不到，则认为该TDD配置已经删除，需要将上一次tdd配置中清除*/
        antMask = g_tddIndCfgDif[ulCnt0].uiChanMask;
        for(ulCnt1 = 0; ulCnt1 < groupNum; ulCnt1++)
        {
            if(antMask & tddIndCfg->tddIndicateCfg[ulCnt1].chanMask)
            {
                /*天线掩码一致，暂不作处理*/
                break;
            }
        }
        if(ulCnt1 == groupNum)
        {
            clrCarrTddIndCfg(&g_tddIndCfgDif[ulCnt0]); /*如果找不到则认为该配置已经删除，清除对应的tdd配置*/
            ulTddCfgFlag[ulCnt0] = 0;
            ulTddReCfgFlag[ulCnt0] = 0;
            ulTddReCfgDoneFlag[ulCnt0] = 0;
            clrCarrTddIndCfg(&g_tddIndCfgBak_Lte[ulCnt0]);
            clrCarrTddIndCfg(&g_tddIndCfgBak_Nr[ulCnt0]);
        }
    }
    return;
}

/*TX:清除无效的TDD配置*/
UINT32 BspClrTxTddIndCfgDif(T_TxTddCfg *tddIndCfg)
{
    /*UINT32 ulRet = BSP_ERROR;*/
    UINT32 cnt0 = 0;
    UINT32 cnt1 = 0;
    UINT32 antMask = 0;
    UINT32 groupNum = 0;

    groupNum =  tddIndCfg->groupNum;
    for(cnt0 = 0; cnt0 < MAX_TDD_GROUP_NUM; cnt0++)
    {
        ARR_BOUND_TDDCFG(cnt0,MAX_TDD_GROUP_NUM);
        /*先将上一次保存的光口配置全部清除*/
        clrCarrTddIndCfg(&g_txTddIndCfgOpt_Nr[cnt0]);
        clrCarrTddIndCfg(&g_txTddIndCfgOpt_Lte[cnt0]);
        txTddIndCfgGroupNum_Nr = 0;
        txTddIndCfgGroupNum_Lte= 0;
        /*根据天线掩码，依次轮循上一次TDD的配置，如果能够在当前APP下发的TDD配置中找到对应的天线掩码，则认为tdd配置存在或者改变，暂不处理；
         * 如果找不到，则认为该TDD配置已经删除，需要将上一次tdd配置中清除*/
        antMask = g_txTddIndCfgDif[cnt0].uiChanMask;
        for(cnt1 = 0; cnt1 < groupNum; cnt1++)
        {
            ARR_BOUND_TDDCFG(cnt1,groupNum);
            if(antMask & tddIndCfg->tddIndicateCfg[cnt1].chanMask)
            {
                /*天线掩码一致，暂不作处理*/
                break;
            }
        }
        if(cnt1 == groupNum)
        {
            clrCarrTddIndCfg(&g_txTddIndCfgDif[cnt0]); /*如果找不到则认为该配置已经删除，清除对应的tdd配置*/
            g_txTddCfgFlag[cnt0] = 0;
            g_txTddReCfgFlag[cnt0] = 0;
            g_txTddReCfgDoneFlag[cnt0] = 0;
            clrCarrTddIndCfg(&g_txTddIndCfgBak_Lte[cnt0]);
            clrCarrTddIndCfg(&g_txTddIndCfgBak_Nr[cnt0]);
        }
    }
    return BSP_OK;
}

/*RX:清除无效的TDD配置*/
UINT32 BspClrRxTddIndCfgDif(T_RxTddCfg *tddIndCfg)
{
    /*UINT32 ulRet = BSP_ERROR;*/
    UINT32 cnt0 = 0;
    UINT32 cnt1 = 0;
    UINT32 antMask = 0;
    UINT32 groupNum = 0;

    groupNum =  tddIndCfg->groupNum;
    for(cnt0 = 0; cnt0 < MAX_TDD_GROUP_NUM; cnt0++)
    {
        ARR_BOUND_TDDCFG(cnt0,MAX_TDD_GROUP_NUM);
        /*先将上一次保存的光口配置全部清除*/
        clrCarrTddIndCfg(&g_rxTddIndCfgOpt_Nr[cnt0]);
        clrCarrTddIndCfg(&g_rxTddIndCfgOpt_Lte[cnt0]);
        rxTddIndCfgGroupNum_Nr = 0;
        rxTddIndCfgGroupNum_Lte= 0;
        /*根据天线掩码，依次轮循上一次TDD的配置，如果能够在当前APP下发的TDD配置中找到对应的天线掩码，则认为tdd配置存在或者改变，暂不处理；
         * 如果找不到，则认为该TDD配置已经删除，需要将上一次tdd配置中清除*/
        antMask = g_rxTddIndCfgDif[cnt0].uiChanMask;
        for(cnt1 = 0; cnt1 < groupNum; cnt1++)
        {
            ARR_BOUND_TDDCFG(cnt1,MAX_TDD_GROUP_NUM);
            if(antMask & tddIndCfg->tddIndicateCfg[cnt1].chanMask)
            {
                /*天线掩码一致，暂不作处理*/
                break;
            }
        }
        if(cnt1 == groupNum)
        {
            clrCarrTddIndCfg(&g_rxTddIndCfgDif[cnt0]); /*如果找不到则认为该配置已经删除，清除对应的tdd配置*/
            g_rxTddCfgFlag[cnt0] = 0;
            g_rxTddReCfgFlag[cnt0] = 0;
            g_rxTddReCfgDoneFlag[cnt0] = 0;
            clrCarrTddIndCfg(&g_rxTddIndCfgBak_Lte[cnt0]);
            clrCarrTddIndCfg(&g_rxTddIndCfgBak_Nr[cnt0]);
        }
    }
    return BSP_OK;
}

/*比较他的的配置会否一致*/
UINT32 compareCarrTddCfg(UINT32 tddCfgId, UINT32 radioMode, T_CarrTddIndCfg *carrTddIndCfg)
{
    /*INT32 lRet = BSP_ERROR;*/
    T_CarrTddIndCfg tddIndCfgTmp = {0};
    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode)
    {
        memcpy_s(&tddIndCfgTmp, sizeof(T_CarrTddIndCfg), &g_tddIndCfgBak_Lte[tddCfgId],sizeof(T_CarrTddIndCfg));
    }
    else
    {
        memcpy_s(&tddIndCfgTmp, sizeof(T_CarrTddIndCfg), &g_tddIndCfgBak_Nr[tddCfgId],sizeof(T_CarrTddIndCfg));
    }
    if(tddIndCfgTmp.uiTddCfgId != carrTddIndCfg->uiTddCfgId)
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiTddCfgIdTmp=%d uiTddCfgId=%d!\n",\
                __FUNCTION__,radioMode,tddCfgId,tddIndCfgTmp.uiTddCfgId,carrTddIndCfg->uiTddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(tddIndCfgTmp.uiDlUlSwNum != carrTddIndCfg->uiDlUlSwNum)
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiDlUlSwNumTmp=%d uiDlUlSwNum=%d!\n",\
                    __FUNCTION__,radioMode,tddCfgId,tddIndCfgTmp.uiDlUlSwNum,carrTddIndCfg->uiDlUlSwNum);
        return TDD_NEED_CFG_SWTBL;
    }
    if(0 != memcmp(tddIndCfgTmp.uiDlSymbolNum,carrTddIndCfg->uiDlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32)))
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiDlSymbolNum not match!\n",__FUNCTION__,radioMode,tddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(0 != memcmp(tddIndCfgTmp.uiUlSymbolNum,carrTddIndCfg->uiUlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32)))
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiUlSymbolNum not match!\n",__FUNCTION__,radioMode,tddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(0 != memcmp(tddIndCfgTmp.uiDlUlSwPeriod,carrTddIndCfg->uiDlUlSwPeriod, MAX_UL_DL_SW_NUM*sizeof(UINT32)))
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiDlUlSwPeriod not match!\n",__FUNCTION__,radioMode,tddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(tddIndCfgTmp.uiChanMask != carrTddIndCfg->uiChanMask)
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiChanMaskTmp=%d uiChanMask=%d!\n",\
                    __FUNCTION__,radioMode,tddCfgId,tddIndCfgTmp.uiChanMask,carrTddIndCfg->uiChanMask);
        return TDD_NEED_ONLY_CFG_DLY;
    }
    return TDD_NOT_NEED_CFG;
}

/*TX RX 比较他的的配置会否一致*/
UINT32 compareCarrTxOrRxTddCfg(UINT32 tddCfgId, UINT32 radioMode, T_CarrTddIndCfg *carrTddIndCfg, UINT32 dir)
{
    /*INT32 lRet = BSP_ERROR;*/
    T_CarrTddIndCfg tddIndCfgTmp = {0};
    if (MAX_TDD_GROUP_NUM <= tddCfgId)
    {
        return BSP_ERROR;
    }
    T_CarrTddIndCfg *tddBak_Lte = (TX == dir) ? &g_txTddIndCfgBak_Lte[tddCfgId]:&g_rxTddIndCfgBak_Lte[tddCfgId];
    T_CarrTddIndCfg *tddBak_Nr  = (TX == dir) ? &g_txTddIndCfgBak_Nr[tddCfgId]: &g_rxTddIndCfgBak_Nr[tddCfgId];


    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode)
    {
        memcpy_s(&tddIndCfgTmp, sizeof(T_CarrTddIndCfg), tddBak_Lte,sizeof(T_CarrTddIndCfg));
    }
    else
    {
        memcpy_s(&tddIndCfgTmp, sizeof(T_CarrTddIndCfg), tddBak_Nr,sizeof(T_CarrTddIndCfg));
    }
    if(tddIndCfgTmp.uiTddCfgId != carrTddIndCfg->uiTddCfgId)
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiTddCfgIdTmp=%d uiTddCfgId=%d!\n",\
                __FUNCTION__,radioMode,tddCfgId,tddIndCfgTmp.uiTddCfgId,carrTddIndCfg->uiTddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(tddIndCfgTmp.uiDlUlSwNum != carrTddIndCfg->uiDlUlSwNum)
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiDlUlSwNumTmp=%d uiDlUlSwNum=%d!\n",\
                    __FUNCTION__,radioMode,tddCfgId,tddIndCfgTmp.uiDlUlSwNum,carrTddIndCfg->uiDlUlSwNum);
        return TDD_NEED_CFG_SWTBL;
    }
    if(0 != memcmp(tddIndCfgTmp.uiDlSymbolNum,carrTddIndCfg->uiDlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32)))
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiDlSymbolNum not match!\n",__FUNCTION__,radioMode,tddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(0 != memcmp(tddIndCfgTmp.uiUlSymbolNum,carrTddIndCfg->uiUlSymbolNum, MAX_UL_DL_SW_NUM*sizeof(UINT32)))
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiUlSymbolNum not match!\n",__FUNCTION__,radioMode,tddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(0 != memcmp(tddIndCfgTmp.uiDlUlSwPeriod,carrTddIndCfg->uiDlUlSwPeriod, MAX_UL_DL_SW_NUM*sizeof(UINT32)))
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiDlUlSwPeriod not match!\n",__FUNCTION__,radioMode,tddCfgId);
        return TDD_NEED_CFG_SWTBL;
    }
    if(tddIndCfgTmp.uiChanMask != carrTddIndCfg->uiChanMask)
    {
        dbgInfoEx("%s radioMode=%d tddCfgId=%d uiChanMaskTmp=%d uiChanMask=%d!\n",\
                    __FUNCTION__,radioMode,tddCfgId,tddIndCfgTmp.uiChanMask,carrTddIndCfg->uiChanMask);
        return TDD_NEED_ONLY_CFG_DLY;
    }
    return TDD_NOT_NEED_CFG;
}


/*通过制式和TDD索引 清除 对应的TDD配置 */
UINT32 clrCarrTddCfgBakByMode(UINT32 tddCfgId, UINT32 radioMode)
{
    UINT32 ulRet = BSP_ERROR;
    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode)
    {
        ulRet = clrCarrTddIndCfg(&g_tddIndCfgBak_Lte[tddCfgId]);
    }
    else
    {
        ulRet = clrCarrTddIndCfg(&g_tddIndCfgBak_Nr[tddCfgId]);
    }
    return ulRet;
}

/*TX RX 通过制式和TDD索引 清除 对应的TDD配置 */
UINT32 clrCarrTxOrRxTddCfgBakByMode(UINT32 tddCfgId, UINT32 radioMode,UINT32 dir)
{
    UINT32 retVal = BSP_ERROR;
    ARR_BOUND_TDDCFG(tddCfgId,MAX_TDD_GROUP_NUM);

    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode)
    {
        retVal = (TX == dir) ?  clrCarrTddIndCfg(&g_txTddIndCfgBak_Lte[tddCfgId]):clrCarrTddIndCfg(&g_rxTddIndCfgBak_Lte[tddCfgId]);
    }
    else
    {
        retVal = (TX == dir) ?  clrCarrTddIndCfg(&g_txTddIndCfgBak_Nr[tddCfgId] ):clrCarrTddIndCfg(&g_rxTddIndCfgBak_Nr[tddCfgId] );
    }
    return retVal;
}

/*通过制式和TDD索引 保存 对应的TDD配置 */
UINT32 saveCarrTddCfgBakByMode(UINT32 tddCfgId, UINT32 radioMode,T_CarrTddIndCfg *carrTddIndCfg)
{
    UINT32 ulRet = BSP_ERROR;
    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode)
    {
        ulRet = recordCarrTddIndCfg(&g_tddIndCfgBak_Lte[tddCfgId], carrTddIndCfg);
    }
    else
    {
        ulRet = recordCarrTddIndCfg(&g_tddIndCfgBak_Nr[tddCfgId], carrTddIndCfg);
    }
    return ulRet;
}

/*TX RX通过制式和TDD索引 保存 对应的TDD配置 */
UINT32 saveCarrTxOrRxTddCfgBakByMode(UINT32 tddCfgId, UINT32 radioMode,T_CarrTddIndCfg *carrTddIndCfg,UINT32 dir)
{
    UINT32 retVal = BSP_ERROR;
    ARR_BOUND_TDDCFG(tddCfgId,MAX_TDD_GROUP_NUM);

    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode)
    {
        retVal = (TX == dir) ? recordCarrTddIndCfg(&g_txTddIndCfgBak_Lte[tddCfgId], carrTddIndCfg):recordCarrTddIndCfg(&g_rxTddIndCfgBak_Lte[tddCfgId], carrTddIndCfg);
    }
    else
    {
        retVal = (TX == dir) ? recordCarrTddIndCfg(&g_txTddIndCfgBak_Nr[tddCfgId],  carrTddIndCfg):recordCarrTddIndCfg(&g_rxTddIndCfgBak_Nr[tddCfgId],  carrTddIndCfg);
    }
    return retVal;
}


/*分析是否重配TDD*/
UINT32 BspSingleModeReAnalysTddCfgInfo(UINT32 tddCfgId, UINT32 radioMode1, UINT32 radioMode2, T_TddIndicateNewCfg *tddIndNewCfg)
{
    /*UINT32 tddCfgFlagTmp = 0;*/
    UINT32 ulRet  = BSP_ERROR;
    UINT32 ulRet1 = BSP_ERROR;
    UINT32 ulRet2 = BSP_ERROR;
    T_CarrTddIndCfg carrTddIndCfg1 = {0};
    T_CarrTddIndCfg carrTddIndCfg2 = {0};

    if(tddCfgId >= MAX_TDD_GROUP_NUM || NULL == tddIndNewCfg)
    {
        return ulRet;
    }

    ulRet1 = getTddIndCfgByMode(radioMode1, tddIndNewCfg, &carrTddIndCfg1);
    ulRet2 = getTddIndCfgByMode(radioMode2, tddIndNewCfg, &carrTddIndCfg2);
    /* 前一次帧格式为LTE，本次帧格式包含NR时，为解决DTX切数据问题，强制切换为NR的帧格式 */
    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode1 && BSP_OK == ulRet2)
    {
        ulTddCfgFlag[tddCfgId] = radioMode2;
        ulTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
        ulTddReCfgDoneFlag[tddCfgId] = 0;
        ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2);
        if(BSP_OK == ulRet1)
        {
            ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1);
        }
        else 
        {
            clrCarrTddCfgBakByMode(tddCfgId,radioMode1);
        }
    }
    else if(BSP_OK == ulRet1)
    {
        ulTddCfgFlag[tddCfgId] = radioMode1;
        ulRet = compareCarrTddCfg(tddCfgId, radioMode1, &carrTddIndCfg1);
        if(TDD_NOT_NEED_CFG == ulRet)
        {
            ulTddReCfgFlag[tddCfgId] = TDD_NOT_NEED_CFG;
            ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1);/*解决只有载波号变化光口配置信息不刷新问题*//* ZHY：可以同步到D4 */
            //ulTddReCfgDoneFlag[tddCfgId] = 1;
        }
        else if(TDD_NEED_ONLY_CFG_DLY == ulRet)/*如果底层表象一样，只是通道掩码不一样，只更新时延，不更新表象，避免劈裂影响另一个通道*/
        {
            ulTddReCfgFlag[tddCfgId] = TDD_NEED_ONLY_CFG_DLY;
            //ulTddReCfgDoneFlag[tddCfgId] = 1;
            ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1);
        }
        else
        {
            ulTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
            ulTddReCfgDoneFlag[tddCfgId] = 0;
            ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1);
        }
        
        if(BSP_OK == ulRet2)
        {
            saveCarrTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2);
        }
        else
        {
            clrCarrTddCfgBakByMode(tddCfgId,radioMode2);
        }
    }
    else
    {
        clrCarrTddCfgBakByMode(tddCfgId,radioMode1);
        ulTddCfgFlag[tddCfgId] = 0;/*找不到mode1的tdd配置，临时先将flag置为0*/
        if(BSP_OK == ulRet2)
        {
            ulTddCfgFlag[tddCfgId] = radioMode2;/*存在mode2的tdd配置，将flag置为mode2*/
            ulRet = compareCarrTddCfg(tddCfgId, radioMode2, &carrTddIndCfg2);
            if(TDD_NOT_NEED_CFG == ulRet)
            {
                ulTddReCfgFlag[tddCfgId] = TDD_NOT_NEED_CFG;
                ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2);/*解决只有载波号变化光口配置信息不刷新问题*/
                //ulTddReCfgDoneFlag[tddCfgId] = 1;
            }
            else if(TDD_NEED_ONLY_CFG_DLY == ulRet)
            {
                ulTddReCfgFlag[tddCfgId] = TDD_NEED_ONLY_CFG_DLY;
                //ulTddReCfgDoneFlag[tddCfgId] = 1;
                ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2);
            }
            else
            {
                ulTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
                ulTddReCfgDoneFlag[tddCfgId] = 0;
                ulRet = saveCarrTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2);
            }
        }
    }
    return ulRet;
}

/*TX:分析是否重配TDD*/
UINT32 BspSingleModeReAnalysTxTddCfgInfo(UINT32 tddCfgId, UINT32 radioMode1, UINT32 radioMode2, T_TxTddIndicateNewCfg *tddIndNewCfg)
{
    /*UINT32 tddCfgFlagTmp = 0;*/
    UINT32 retVal  = BSP_ERROR;
    UINT32 retVal1 = BSP_ERROR;
    UINT32 retVal2 = BSP_ERROR;
    T_CarrTddIndCfg carrTddIndCfg1 = {0};
    T_CarrTddIndCfg carrTddIndCfg2 = {0};

    ARR_BOUND_TDDCFG(tddCfgId,MAX_TDD_GROUP_NUM);
    INPUT_POINTER_CHECK(tddIndNewCfg);

    retVal1 = getTxTddIndCfgByMode(radioMode1, tddIndNewCfg, &carrTddIndCfg1);
    retVal2 = getTxTddIndCfgByMode(radioMode2, tddIndNewCfg, &carrTddIndCfg2);
    /* 前一次帧格式为LTE，本次帧格式包含NR时，为解决DTX切数据问题，强制切换为NR的帧格式 */
    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode1 && BSP_OK == retVal2)
    {
        g_txTddCfgFlag[tddCfgId] = radioMode2;
        g_txTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
        g_txTddReCfgDoneFlag[tddCfgId] = 0;
        retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,TX);
        retVal = (BSP_OK == retVal1) ? saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,TX) :clrCarrTxOrRxTddCfgBakByMode(tddCfgId,radioMode1,TX);
    }
    else if(BSP_OK == retVal1)
    {
        g_txTddCfgFlag[tddCfgId] = radioMode1;
        retVal = compareCarrTxOrRxTddCfg(tddCfgId, radioMode1, &carrTddIndCfg1,TX);
        if(TDD_NOT_NEED_CFG == retVal)
        {
            g_txTddReCfgFlag[tddCfgId] = TDD_NOT_NEED_CFG;
            retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,TX);/*解决只有载波号变化光口配置信息不刷新问题*/
            //ulTddReCfgDoneFlag[tddCfgId] = 1;
        }
        else if(TDD_NEED_ONLY_CFG_DLY == retVal)/*如果底层表象一样，只是通道掩码不一样，只更新时延，不更新表象，避免劈裂影响另一个通道*/
        {
            g_txTddReCfgFlag[tddCfgId] = TDD_NEED_ONLY_CFG_DLY;
            //ulTddReCfgDoneFlag[tddCfgId] = 1;
            retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,TX);
        }
        else
        {
            g_txTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
            g_txTddReCfgDoneFlag[tddCfgId] = 0;
            retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,TX);
        }
        
        if(BSP_OK == retVal2)
        {
            saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,TX);
        }
        else
        {
            clrCarrTxOrRxTddCfgBakByMode(tddCfgId,radioMode2,TX);
        }
    }
    else
    {
        clrCarrTxOrRxTddCfgBakByMode(tddCfgId,radioMode1,TX);
        g_txTddCfgFlag[tddCfgId] = 0;/*找不到mode1的tdd配置，临时先将flag置为0*/
        if(BSP_OK == retVal2)
        {
            g_txTddCfgFlag[tddCfgId] = radioMode2;/*存在mode2的tdd配置，将flag置为mode2*/
            retVal = compareCarrTxOrRxTddCfg(tddCfgId, radioMode2, &carrTddIndCfg2,TX);
            if(TDD_NOT_NEED_CFG == retVal)
            {
                g_txTddReCfgFlag[tddCfgId] = TDD_NOT_NEED_CFG;
                retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,TX);/*解决只有载波号变化光口配置信息不刷新问题*/
                //ulTddReCfgDoneFlag[tddCfgId] = 1;
            }
            else if(TDD_NEED_ONLY_CFG_DLY == retVal)
            {
                g_txTddReCfgFlag[tddCfgId] = TDD_NEED_ONLY_CFG_DLY;
                //ulTddReCfgDoneFlag[tddCfgId] = 1;
                retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,TX);
            }
            else
            {
                g_txTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
                g_txTddReCfgDoneFlag[tddCfgId] = 0;
                retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,TX);
            }
        }
    }
    return retVal;
}

/*RX:分析是否重配TDD*/
UINT32 BspSingleModeReAnalysRxTddCfgInfo(UINT32 tddCfgId, UINT32 radioMode1, UINT32 radioMode2, T_RxTddIndicateNewCfg *tddIndNewCfg)
{
    /*UINT32 tddCfgFlagTmp = 0;*/
    UINT32 retVal  = BSP_ERROR;
    UINT32 retVal1 = BSP_ERROR;
    UINT32 retVal2 = BSP_ERROR;
    T_CarrTddIndCfg carrTddIndCfg1 = {0};
    T_CarrTddIndCfg carrTddIndCfg2 = {0};

    ARR_BOUND_TDDCFG(tddCfgId,MAX_TDD_GROUP_NUM);
    INPUT_POINTER_CHECK(tddIndNewCfg);

    retVal1 = getRxTddIndCfgByMode(radioMode1, tddIndNewCfg, &carrTddIndCfg1);
    retVal2 = getRxTddIndCfgByMode(radioMode2, tddIndNewCfg, &carrTddIndCfg2);
    /* 前一次帧格式为LTE，本次帧格式包含NR时，为解决DTX切数据问题，强制切换为NR的帧格式 */
    if(BSP_RADIO_STANDARD_LTE_TDD == radioMode1 && BSP_OK == retVal2)
    {
        g_rxTddCfgFlag[tddCfgId] = radioMode2;
        g_rxTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
        g_rxTddReCfgDoneFlag[tddCfgId] = 0;
        retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,RX);
        retVal = (BSP_OK == retVal1) ? saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,RX) : clrCarrTxOrRxTddCfgBakByMode(tddCfgId,radioMode1,RX);
    }
    else if(BSP_OK == retVal1)
    {
        g_rxTddCfgFlag[tddCfgId] = radioMode1;
        retVal = compareCarrTxOrRxTddCfg(tddCfgId, radioMode1, &carrTddIndCfg1,RX);
        if(TDD_NOT_NEED_CFG == retVal)
        {
            g_rxTddReCfgFlag[tddCfgId] = TDD_NOT_NEED_CFG;
            retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,RX);/*解决只有载波号变化光口配置信息不刷新问题*/
            //ulTddReCfgDoneFlag[tddCfgId] = 1;
        }
        else if(TDD_NEED_ONLY_CFG_DLY == retVal)/*如果底层表象一样，只是通道掩码不一样，只更新时延，不更新表象，避免劈裂影响另一个通道*/
        {
            g_rxTddReCfgFlag[tddCfgId] = TDD_NEED_ONLY_CFG_DLY;
            //ulTddReCfgDoneFlag[tddCfgId] = 1;
            retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,RX);
        }
        else
        {
            g_rxTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
            g_rxTddReCfgDoneFlag[tddCfgId] = 0;
            retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode1, &carrTddIndCfg1,RX);
        }
        
        if(BSP_OK == retVal2)
        {
            saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,RX);
        }
        else
        {
            clrCarrTxOrRxTddCfgBakByMode(tddCfgId,radioMode2,RX);
        }
    }
    else
    {
        clrCarrTxOrRxTddCfgBakByMode(tddCfgId,radioMode1,RX);
        g_rxTddCfgFlag[tddCfgId] = 0;/*找不到mode1的tdd配置，临时先将flag置为0*/
        if(BSP_OK == retVal2)
        {
            g_rxTddCfgFlag[tddCfgId] = radioMode2;/*存在mode2的tdd配置，将flag置为mode2*/
            retVal = compareCarrTxOrRxTddCfg(tddCfgId, radioMode2, &carrTddIndCfg2,RX);
            if(TDD_NOT_NEED_CFG == retVal)
            {
                g_rxTddReCfgFlag[tddCfgId] = TDD_NOT_NEED_CFG;
                retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,RX);/*解决只有载波号变化光口配置信息不刷新问题*/
                //ulTddReCfgDoneFlag[tddCfgId] = 1;
            }
            else if(TDD_NEED_ONLY_CFG_DLY == retVal)
            {
                g_rxTddReCfgFlag[tddCfgId] = TDD_NEED_ONLY_CFG_DLY;
                //ulTddReCfgDoneFlag[tddCfgId] = 1;
                retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,RX);
            }
            else
            {
                g_rxTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
                g_rxTddReCfgDoneFlag[tddCfgId] = 0;
                retVal = saveCarrTxOrRxTddCfgBakByMode(tddCfgId, radioMode2, &carrTddIndCfg2,RX);
            }
        }
    }
    return retVal;
}


/*****************************************************************************
 *  函数名称   : BspAnalysTddCfgInfo(*)
 *  功能描述   : tdd配置的第一次预分析
 *  输入参数   : tddCfgId--tdd配置的序号
 *              tddIndNewCfg --app下发的某一套tdd配置
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : RRU公共接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspAnalysTddCfgInfo(UINT32 tddCfgId, T_TddIndicateNewCfg *tddIndNewCfg)
{
    UINT32 ulRet =BSP_OK;
    T_CarrTddIndCfg carrTddIndCfg = {0};

    /*1. 先将第tddCfgId套tdd配置对应的nr、lte配置和标志全部清除*/
    ulTddCfgFlag[tddCfgId] = 0;
    ulTddReCfgFlag[tddCfgId] = 0;
    ulTddReCfgDoneFlag[tddCfgId] = 0;
    clrCarrTddIndCfg(&g_tddIndCfgBak_Lte[tddCfgId]);
    clrCarrTddIndCfg(&g_tddIndCfgBak_Nr[tddCfgId]);
    /*2. 优先查找NR载波是否存在tdd配置*/
    ulRet = getTddIndCfgByMode(BSP_RADIO_STANDARD_5G, tddIndNewCfg, &carrTddIndCfg);
    if(BSP_OK == ulRet)
    {
        /*3.将tdd配置制式置为NR，tdd配置需要重配(0x5a5a),将tdd配置保存到Nr的全局备份*/
        ulTddCfgFlag[tddCfgId] = BSP_RADIO_STANDARD_5G;
        ulTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
        ulTddReCfgDoneFlag[tddCfgId] = 0;
        recordCarrTddIndCfg(&g_tddIndCfgBak_Nr[tddCfgId], &carrTddIndCfg);
        /*4.查找是否存在lte载波的tdd配置，如果有则保存到Lte的全局备份*/
        if(BSP_OK == getTddIndCfgByMode(BSP_RADIO_STANDARD_LTE_TDD, tddIndNewCfg, &carrTddIndCfg))
        {
            recordCarrTddIndCfg(&g_tddIndCfgBak_Lte[tddCfgId], &carrTddIndCfg);
        }
    }
    else
    {
        /*3.不存在NR载波，则查找LTE载波的TDD配置*/
        ulRet = getTddIndCfgByMode(BSP_RADIO_STANDARD_LTE_TDD, tddIndNewCfg, &carrTddIndCfg);
        if(BSP_OK == ulRet)
        {
            /*4.将tdd配置制式置为NR，tdd配置需要重配(0x5a5a),将tdd配置保存到Nr的全局备份*/
            ulTddCfgFlag[tddCfgId] = BSP_RADIO_STANDARD_LTE_TDD;
            ulTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
            ulTddReCfgDoneFlag[tddCfgId] = 0;
            ulRet = recordCarrTddIndCfg(&g_tddIndCfgBak_Lte[tddCfgId], &carrTddIndCfg);
        }
    }
    return ulRet;
}


UINT32 BspAnalysTxTddCfgInfo(UINT32 tddCfgId, T_TxTddIndicateNewCfg *tddIndNewCfg)
{
    UINT32 retVal =BSP_OK;
    T_CarrTddIndCfg carrTddIndCfg = {0};

    if (MAX_TDD_GROUP_NUM <= tddCfgId)
    {
        return BSP_ERROR;
    }
    /*1. 先将第tddCfgId套tdd配置对应的nr、lte配置和标志全部清除*/
    g_txTddCfgFlag[tddCfgId] = 0;
    g_txTddReCfgFlag[tddCfgId] = 0;
    g_txTddReCfgDoneFlag[tddCfgId] = 0;
    clrCarrTddIndCfg(&g_txTddIndCfgBak_Lte[tddCfgId]);
    clrCarrTddIndCfg(&g_txTddIndCfgBak_Nr[tddCfgId]);
    /*2. 优先查找NR载波是否存在tdd配置*/
    retVal = getTxTddIndCfgByMode(BSP_RADIO_STANDARD_5G, tddIndNewCfg, &carrTddIndCfg);
    if(BSP_OK == retVal)
    {
        /*3.将tdd配置制式置为NR，tdd配置需要重配(0x5a5a),将tdd配置保存到Nr的全局备份*/
        g_txTddCfgFlag[tddCfgId] = BSP_RADIO_STANDARD_5G;
        g_txTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
        g_txTddReCfgDoneFlag[tddCfgId] = 0;
        recordCarrTddIndCfg(&g_txTddIndCfgBak_Nr[tddCfgId], &carrTddIndCfg);
        /*4.查找是否存在lte载波的tdd配置，如果有则保存到Lte的全局备份*/
        if(BSP_OK == getTxTddIndCfgByMode(BSP_RADIO_STANDARD_LTE_TDD, tddIndNewCfg, &carrTddIndCfg))
        {
            recordCarrTddIndCfg(&g_txTddIndCfgBak_Lte[tddCfgId], &carrTddIndCfg);
        }
    }
    else
    {
        /*3.不存在NR载波，则查找LTE载波的TDD配置*/
        retVal = getTxTddIndCfgByMode(BSP_RADIO_STANDARD_LTE_TDD, tddIndNewCfg, &carrTddIndCfg);
        if(BSP_OK == retVal)
        {
            /*4.将tdd配置制式置为NR，tdd配置需要重配(0x5a5a),将tdd配置保存到Nr的全局备份*/
            g_txTddCfgFlag[tddCfgId] = BSP_RADIO_STANDARD_LTE_TDD;
            g_txTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
            g_txTddReCfgDoneFlag[tddCfgId] = 0;
            retVal = recordCarrTddIndCfg(&g_txTddIndCfgBak_Lte[tddCfgId], &carrTddIndCfg);
        }
    }
    return retVal;
}

UINT32 BspAnalysRxTddCfgInfo(UINT32 tddCfgId, T_RxTddIndicateNewCfg *tddIndNewCfg)
{
    UINT32 retVal =BSP_OK;
    T_CarrTddIndCfg carrTddIndCfg = {0};

    if (MAX_TDD_GROUP_NUM <= tddCfgId)
    {
        return BSP_ERROR;
    }
    /*1. 先将第tddCfgId套tdd配置对应的nr、lte配置和标志全部清除*/
    g_rxTddCfgFlag[tddCfgId] = 0;
    g_rxTddReCfgFlag[tddCfgId] = 0;
    g_rxTddReCfgDoneFlag[tddCfgId] = 0;
    clrCarrTddIndCfg(&g_rxTddIndCfgBak_Lte[tddCfgId]);
    clrCarrTddIndCfg(&g_rxTddIndCfgBak_Nr[tddCfgId]);
    /*2. 优先查找NR载波是否存在tdd配置*/
    retVal = getRxTddIndCfgByMode(BSP_RADIO_STANDARD_5G, tddIndNewCfg, &carrTddIndCfg);
    if(BSP_OK == retVal)
    {
        /*3.将tdd配置制式置为NR，tdd配置需要重配(0x5a5a),将tdd配置保存到Nr的全局备份*/
        g_rxTddCfgFlag[tddCfgId] = BSP_RADIO_STANDARD_5G;
        g_rxTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
        g_rxTddReCfgDoneFlag[tddCfgId] = 0;
        recordCarrTddIndCfg(&g_rxTddIndCfgBak_Nr[tddCfgId], &carrTddIndCfg);
        /*4.查找是否存在lte载波的tdd配置，如果有则保存到Lte的全局备份*/
        if(BSP_OK == getRxTddIndCfgByMode(BSP_RADIO_STANDARD_LTE_TDD, tddIndNewCfg, &carrTddIndCfg))
        {
            recordCarrTddIndCfg(&g_rxTddIndCfgBak_Lte[tddCfgId], &carrTddIndCfg);
        }
    }
    else
    {
        /*3.不存在NR载波，则查找LTE载波的TDD配置*/
        retVal = getRxTddIndCfgByMode(BSP_RADIO_STANDARD_LTE_TDD, tddIndNewCfg, &carrTddIndCfg);
        if(BSP_OK == retVal)
        {
            /*4.将tdd配置制式置为NR，tdd配置需要重配(0x5a5a),将tdd配置保存到Nr的全局备份*/
            g_rxTddCfgFlag[tddCfgId] = BSP_RADIO_STANDARD_LTE_TDD;
            g_rxTddReCfgFlag[tddCfgId] = TDD_NEED_CFG_SWTBL;
            g_rxTddReCfgDoneFlag[tddCfgId] = 0;
            retVal = recordCarrTddIndCfg(&g_rxTddIndCfgBak_Lte[tddCfgId], &carrTddIndCfg);
        }
    }
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspSaveTddCfgAnalysResult(*)
 *  功能描述   : 保存tdd配置预分析结果
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : RRU公共接口函数
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
VOID BspSaveTddCfgAnalysResult(VOID)
{
    UINT32 ulCnt  = 0;
    UINT32 ulLteNum = 0;
    UINT32 ulNrNum = 0;
    /*UINT32 ulRadioMode = 0;*/
    UINT32 ulFlagTmp = 0;

    tddIndCfgDifGroupNum = 0;
    tddIndCfgGroupNum_Nr = 0;
    tddIndCfgGroupNum_Lte= 0;
    for(ulCnt = 0; ulCnt < MAX_TDD_GROUP_NUM; ulCnt++)
    {
        ulFlagTmp = 0;
        if(BSP_RADIO_STANDARD_5G == ulTddCfgFlag[ulCnt])
        {
            ulFlagTmp = ulTddCfgFlag[ulCnt];
            recordCarrTddIndCfg(&g_tddIndCfgDif[ulCnt], &g_tddIndCfgBak_Nr[ulCnt]);
        }
        else if(BSP_RADIO_STANDARD_LTE_TDD == ulTddCfgFlag[ulCnt])
        {
            ulFlagTmp = ulTddCfgFlag[ulCnt];
            recordCarrTddIndCfg(&g_tddIndCfgDif[ulCnt], &g_tddIndCfgBak_Lte[ulCnt]);
        }
        if(0 != ulFlagTmp)
        {
            tddIndCfgDifGroupNum++;
            if(0 != g_tddIndCfgBak_Nr[ulCnt].uiRadioMode)
            {
                recordCarrTddIndCfg(&g_tddIndCfgOpt_Nr[ulNrNum], &g_tddIndCfgBak_Nr[ulCnt]);
                ulNrNum++;
            }
            if(0 != g_tddIndCfgBak_Lte[ulCnt].uiRadioMode)
            {
                recordCarrTddIndCfg(&g_tddIndCfgOpt_Lte[ulLteNum], &g_tddIndCfgBak_Lte[ulCnt]);
                ulLteNum++;
            }
        }
    }
    tddIndCfgGroupNum_Nr  = ulNrNum;
    tddIndCfgGroupNum_Lte = ulLteNum;
    BspHalAdaptOptCfgTdd(g_tddIndCfgOpt_Nr, tddIndCfgGroupNum_Nr);
    BspHalAdaptOptCfgTdd(g_tddIndCfgOpt_Lte, tddIndCfgGroupNum_Lte);

    return;
}

UINT32 BspSaveTxTddCfgAnalysResult(VOID)
{
    UINT32 cnt  = 0;
    UINT32 lteNum = 0;
    UINT32 nrNum = 0;
    /*UINT32 ulRadioMode = 0;*/
    UINT32 ulFlagTmp = 0;
    UINT32 ioCtrlType = 0;

    txTddIndCfgDifGroupNum = 0;
    txTddIndCfgGroupNum_Nr = 0;
    txTddIndCfgGroupNum_Lte= 0;
    for(cnt = 0; cnt < MAX_TDD_GROUP_NUM; cnt++)
    {
        if ((MAX_TDD_GROUP_NUM <= cnt) || (MAX_TDD_GROUP_NUM <= nrNum) || (MAX_TDD_GROUP_NUM <= lteNum))
        {
            dbgInfo("pointer is bigger than arr num !!");
            return BSP_ERROR;
        }
        
        ulFlagTmp = 0;
        if(BSP_RADIO_STANDARD_5G == g_txTddCfgFlag[cnt])
        {
            ulFlagTmp = g_txTddCfgFlag[cnt];
            recordCarrTddIndCfg(&g_txTddIndCfgDif[cnt], &g_txTddIndCfgBak_Nr[cnt]);
        }
        else if(BSP_RADIO_STANDARD_LTE_TDD == g_txTddCfgFlag[cnt])
        {
            ulFlagTmp = g_txTddCfgFlag[cnt];
            recordCarrTddIndCfg(&g_txTddIndCfgDif[cnt], &g_txTddIndCfgBak_Lte[cnt]);
        }
        if(0 != ulFlagTmp)
        {
            txTddIndCfgDifGroupNum++;
            if(0 != g_txTddIndCfgBak_Nr[cnt].uiRadioMode)
            {
                recordCarrTddIndCfg(&g_txTddIndCfgOpt_Nr[nrNum], &g_txTddIndCfgBak_Nr[cnt]);
                nrNum++;
            }
            if(0 != g_txTddIndCfgBak_Lte[cnt].uiRadioMode)
            {
                recordCarrTddIndCfg(&g_txTddIndCfgOpt_Lte[lteNum], &g_txTddIndCfgBak_Lte[cnt]);
                lteNum++;
            }
        }
    }
    txTddIndCfgGroupNum_Nr  = nrNum;
    txTddIndCfgGroupNum_Lte = lteNum;
    if (BspGetTxChanNum() > BspGetRxChanNum())
    {
        BspHalAdaptOptCfgTdd(g_txTddIndCfgOpt_Nr, txTddIndCfgGroupNum_Nr);/* 吉森全：上下行那个通道多就配哪一个，配一次就行 */
        BspHalAdaptOptCfgTdd(g_txTddIndCfgOpt_Lte, txTddIndCfgGroupNum_Lte);
    }
    ioCtrlType = BspGetInitTddNum();/* 暂时先不用拆分上下行吧 */
    if(E_INIT_TYPE_MS == ioCtrlType)/* 一拖三暂时先不拆分，不会拆 */
    {
        (VOID)BspSetTddCfgToFpga(0);  /*一拖三机型特殊处理*/
        (VOID)BspSetSlavePortTddCfg(0);   /*不论此时子端是否上电都需要配置，防止中途修改tdd帧结构的情况*/
        (VOID)BspSetSlavePortTddCfg(1);   /*子端单独上电需要其他流程保证*/
        (VOID)BspSetSlavePortTddCfg(2);
    }

    return BSP_OK;
}

UINT32 BspSaveRxTddCfgAnalysResult(VOID)
{
    UINT32 cnt  = 0;
    UINT32 lteNum = 0;
    UINT32 nrNum = 0;
    /*UINT32 ulRadioMode = 0;*/
    UINT32 ulFlagTmp = 0;
    UINT32 ioCtrlType = 0;

    rxTddIndCfgDifGroupNum = 0;
    rxTddIndCfgGroupNum_Nr = 0;
    rxTddIndCfgGroupNum_Lte= 0;
    for(cnt = 0; cnt < MAX_TDD_GROUP_NUM; cnt++)
    {
        if ((MAX_TDD_GROUP_NUM <= cnt) || (MAX_TDD_GROUP_NUM <= nrNum) || (MAX_TDD_GROUP_NUM <= lteNum))
        {
            dbgInfo("pointer is bigger than arr num !!");
            return BSP_ERROR;
        }
        ulFlagTmp = 0;
        if(BSP_RADIO_STANDARD_5G == g_rxTddCfgFlag[cnt])
        {
            ulFlagTmp = g_rxTddCfgFlag[cnt];
            recordCarrTddIndCfg(&g_rxTddIndCfgDif[cnt], &g_rxTddIndCfgBak_Nr[cnt]);
        }
        else if(BSP_RADIO_STANDARD_LTE_TDD == g_rxTddCfgFlag[cnt])
        {
            ulFlagTmp = g_rxTddCfgFlag[cnt];
            recordCarrTddIndCfg(&g_rxTddIndCfgDif[cnt], &g_rxTddIndCfgBak_Lte[cnt]);
        }
        if(0 != ulFlagTmp)
        {
            rxTddIndCfgDifGroupNum++;
            if(0 != g_rxTddIndCfgBak_Nr[cnt].uiRadioMode)
            {
                recordCarrTddIndCfg(&g_rxTddIndCfgOpt_Nr[nrNum], &g_rxTddIndCfgBak_Nr[cnt]);
                nrNum++;
            }
            if(0 != g_rxTddIndCfgBak_Lte[cnt].uiRadioMode)
            {
                recordCarrTddIndCfg(&g_rxTddIndCfgOpt_Lte[lteNum], &g_rxTddIndCfgBak_Lte[cnt]);
                lteNum++;
            }
        }
    }
    rxTddIndCfgGroupNum_Nr  = nrNum;
    rxTddIndCfgGroupNum_Lte = lteNum;
    
    if (BspGetRxChanNum() >= BspGetTxChanNum())/* 等于号是为了上下行数目相等的时候，必配一把 */
    {
        BspHalAdaptOptCfgTdd(g_rxTddIndCfgOpt_Nr, rxTddIndCfgGroupNum_Nr);
        BspHalAdaptOptCfgTdd(g_rxTddIndCfgOpt_Lte, rxTddIndCfgGroupNum_Lte);
    }
    
    ioCtrlType = BspGetInitTddNum();/* 暂时先不用拆分上下行吧 */
    if(E_INIT_TYPE_MS == ioCtrlType)/* 一拖三暂时先不拆分，不会拆 */
    {
        (VOID)BspSetTddCfgToFpga(0);  /*一拖三机型特殊处理*/
        (VOID)BspSetSlavePortTddCfg(0);   /*不论此时子端是否上电都需要配置，防止中途修改tdd帧结构的情况*/
        (VOID)BspSetSlavePortTddCfg(1);   /*子端单独上电需要其他流程保证*/
        (VOID)BspSetSlavePortTddCfg(2);
    }

    return BSP_OK;;
}

/*周期：0.5ms:0 0.625ms:1 1.25ms:2 1ms:3 2ms:4 2.5ms:5  5ms:6 10ms:7      0.625ms、1.25ms暂不支持*/
UINT32 g_ulIndexOfPeriod[MAX_PERIOD_INDEX_NUM] =
{
    500,625,1250,1000,2000,2500,5000,10000
};
UINT32 getPeriodIndex(UINT32 period)
{
    UINT32 loop = 0;
    UINT32 index = MAX_PERIOD_INDEX_NUM;

    for(loop = 0; loop < MAX_PERIOD_INDEX_NUM; loop++)
    {
        if(g_ulIndexOfPeriod[loop] == period)
        {
            index = loop;
            break;
        }
    }
    if(loop == MAX_PERIOD_INDEX_NUM)
    {
        dbgErr("getPeriodIndex period %d failed\n", period);
    }

    return index;
}

UINT32 BspGetTddPeriodByIndex(UINT32 index)
{
    if(index >= MAX_PERIOD_INDEX_NUM)
    {
        return BSP_ERROR;
    }
    return g_ulIndexOfPeriod[index];
}

/*9124 需要给fpga配置tdd 配置规则特殊，此接口相当于是ic的配置到fpga配置的映射转换*/
UINT32 BspGetTddIndexByTddCfg(UINT32 dlUlSw, UINT32 period, UINT32 dlSymbol)
{
    UINT32 index = 0;

    if(5000 == period)
    {
        index = 1;
    }
    if((2500 == period)&&(52 == dlSymbol))
    {
        if(1 == dlUlSw)
        {
            index = 2;
        }
        else
        {
            index = 5;
        }
    }
    if(3000 == period)
    {
        index = 3;
    }
    if((2500 == period)&&(24 == dlSymbol))
    {
        index = 4;
    }

    return index;
}

/*将TDD NR帧结构下发给FPGA*/
UINT32 BspSetNrTddCfgToFpga(UINT32 tddId)
{
    UINT32 periodIndex = 0;
    UINT32 loop = 0;
    UINT32 tmpIndex = 0;
    UINT32 tmp = 0;
    UINT32 retVal = BSP_OK;

    if(tddId >= MAX_TDD_GROUP_NUM)
    {
        return BSP_ERROR;
    }
    if(BSP_RADIO_STANDARD_5G == g_tddIndCfgDif[tddId].uiRadioMode)
    {
        BspRegWr(0, REG_FPGA_RADIOMODE_CFG, 0, 0x0);
        BspRegWr(0, REG_FPGA_CPE_ADV_TIME, 0, 0);
        g_tddIndCfgFpga[tddId].dlUlSwNum = g_tddIndCfgDif[tddId].uiDlUlSwNum;
        if(g_tddIndCfgFpga[tddId].dlUlSwNum > MAX_DL_UL_SW_CNT)
        {
            return BSP_ERROR;
        }
        for(loop = 0; loop < g_tddIndCfgFpga[tddId].dlUlSwNum; loop++)
        {
            tmpIndex = getPeriodIndex(g_tddIndCfgDif[tddId].uiDlUlSwPeriod[loop]);
            if(MAX_PERIOD_INDEX_NUM != tmpIndex)
            {
                periodIndex |= (tmpIndex<< (loop*8));
            }
            dbgInfoEx("loop %d tmpIndex %d, periodIndex 0x%x\n",loop, tmpIndex, periodIndex);
        }
        g_tddIndCfgFpga[tddId].period = periodIndex&0xffff;
        for(loop = 0; loop < g_tddIndCfgFpga[tddId].dlUlSwNum; loop++)
        {
            g_tddIndCfgFpga[tddId].dlSymbolCnt[loop] = g_tddIndCfgDif[tddId].uiDlSymbolNum[loop]%14;
            g_tddIndCfgFpga[tddId].ulSymbolCnt[loop] = g_tddIndCfgDif[tddId].uiUlSymbolNum[loop]%14;
            g_tddIndCfgFpga[tddId].dlSlotCnt[loop] = g_tddIndCfgDif[tddId].uiDlSymbolNum[loop]/14;
            g_tddIndCfgFpga[tddId].ulSlotCnt[loop] = g_tddIndCfgDif[tddId].uiUlSymbolNum[loop]/14;
            dbgInfoEx("loop %d dlSymbolCnt %d, ulSymbolCnt %d dlSlotCnt %d ulSlotCnt %d\n",loop,  g_tddIndCfgFpga[tddId].dlSymbolCnt[loop], g_tddIndCfgFpga[tddId].ulSymbolCnt[loop], g_tddIndCfgFpga[tddId].dlSlotCnt[loop] ,g_tddIndCfgFpga[tddId].ulSlotCnt[loop]);
        }
        tmp = BspGetTddIndexByTddCfg(g_tddIndCfgDif[tddId].uiDlUlSwNum,g_tddIndCfgDif[tddId].uiDlUlSwPeriod[0],g_tddIndCfgDif[tddId].uiDlSymbolNum[0]);
        retVal = BspCfgNrTddToFpga(tmp);
    }

    return retVal;
}

/*获取存储的帧结构信息  后续发给子端*/
UINT32 BspGetTddIndCfgFpga(UINT32 tddId, T_TddCfgInfoToFpga *pCfg)
{
    INPUT_POINTER_CHECK(pCfg);
    memset_s(pCfg, sizeof(T_TddCfgInfoToFpga), 0, sizeof(T_TddCfgInfoToFpga));
    memcpy_s(pCfg, sizeof(T_TddCfgInfoToFpga), &g_tddIndCfgFpga[tddId], sizeof(T_TddCfgInfoToFpga));   /*先清再配*/

    return BSP_OK;
}


/* 时隙配比     FPGA定义 0-S,1-D,2-U
0    5ms        D    S    U    U    U    D    S    U    U    U
1    5ms        D    S    U    U    D    D    S    U    U    D
2    5ms        D    S    U    D    D    D    S    U    D    D
3    10ms    D    S    U    U    U    D    D    D    D    D
4    10ms    D    S    U    U    D    D    D    D    D    D
5    10ms    D    S    U    D    D    D    D    D    D    D
6    10ms    D    S    U    U    U    D    S    U    U    D
*/

/*
特殊子帧    normal CP
    D    GP    U
0|    3    10    1
1|    9    4    1
2|    10    3    1
3|    11    2    1
4|    12    1    1
5|    3    9    2
6|    9    3    2
7|    10    2    2
8|    11    1    2
9|    6    6    2
 * */

UINT32 BspSetLteTddCfgToFpga(UINT32 tddId)
{
    UINT32 regVal = 0;
    UINT32 subFrameRatio = 0;
    UINT32 speSubFrameRatio = 0;

    if(tddId >= MAX_TDD_GROUP_NUM)
    {
        return BSP_ERROR;
    }
    subFrameRatio = BspGetLteIrSubFrame();
    speSubFrameRatio = BspGetLteIrSpeSubFrame();
    regVal = subFrameRatio|(speSubFrameRatio<<4);
    if(BSP_RADIO_STANDARD_LTE_TDD == g_tddIndCfgDif[tddId].uiRadioMode)   /*目前需要配到FPGA的只支持一套TDD*/
    {
        BspRegWr(0, REG_RF_FPGA_BITMAP_SLOT0, 0, regVal);
        BspRegWr(0, REG_FPGA_RADIOMODE_CFG, 0, 0x1);
        BspRegWr(0, REG_FPGA_CPE_ADV_TIME, 0, 1);
    }
    return BSP_OK;
}

/*清除fpga配置的tdd帧结构信息*/
UINT32 BspClrTddCfgToFpga(VOID)
{
    UINT32 retVal = BSP_OK;
	
    retVal = BspRegWr(0, REG_FPGA_RADIOMODE_CFG,    0, 0x0);
    retVal |= BspRegWr(0, REG_FPGA_CPE_ADV_TIME,    0, 0x0);
    retVal |= BspRegWr(0, REG_RF_FPGA_BITMAP_SLOT0, 0, 0x0); /*切换点配置寄存器[7:4]:DwPTS-GP-UpPTS配置 ；[3:0]:上下行配置比*/
    retVal |= BspCfgNrTddToFpga(0);

    return retVal;
}

UINT32 BspCfgNrTddToFpga(UINT32 index)
{
    T_TddCfgInfoToFpga data = {0};
    UINT32 retVal = BSP_OK;

    if(index >= NELEMENTS(g_ulTddCfgInfoToFpga))
    {
        return BSP_ERROR;
    }
    (VOID)memcpy_s(&data, sizeof(T_TddCfgInfoToFpga), &g_ulTddCfgInfoToFpga[index], sizeof(T_TddCfgInfoToFpga));
    retVal = BspRegWr(0, REG_NR_PERIOD ,           0, data.period); /*周期：0.5ms:0 0.625ms:1 1.25ms:2 1ms:3 2ms:4 2.5ms:5  5ms:6 10ms:7*/
    retVal |= BspRegWr(0, REG_NR_PERIOD_FLAG ,      0, data.dlUlSwNum); /*0:单周期 1：双周期*/
    retVal |= BspRegWr(0, REG_NR_DL_FLAG1 ,         0, data.dlSymbolCnt[0]); /*1st S时隙symbol是否为下行指示信号，1:下行 0:不是下行*/
    retVal |= BspRegWr(0, REG_NR_UL_FLAG1 ,         0, data.ulSymbolCnt[0]); /*1st S时隙symbol是否为上行指示信号，1:上行 0:不是上行 */
    retVal |= BspRegWr(0, REG_NR_DL_FLAG2 ,         0, data.dlSymbolCnt[1]); /*2nd S时隙symbol是否为下行指示信号，1:下行 0:不是下行*/
    retVal |= BspRegWr(0, REG_NR_UL_FLAG2 ,         0, data.ulSymbolCnt[1]); /*2nd S时隙symbol是否为上行指示信号，1:上行 0:不是上行 */
    retVal |= BspRegWr(0, REG_NR_DL_SLOT_FLAG1 ,    0, data.dlSlotCnt[0]); /*双周期第一个周期slot上下行标识*/
    retVal |= BspRegWr(0, REG_NR_UL_SLOT_FLAG1 ,    0, data.ulSlotCnt[0]); /*双周期第一个周期slot上下行标识*/
    retVal |= BspRegWr(0, REG_NR_DL_SLOT_FLAG2 ,    0, data.dlSlotCnt[1]); /*双周期第二个周期slot上下行标识*/
    retVal |= BspRegWr(0, REG_NR_UL_SLOT_FLAG2 ,    0, data.ulSlotCnt[1]); /*双周期第二个周期slot上下行标识*/

    return retVal;
}
/*将TDD帧结构信息下发给fpga*/
UINT32 BspSetTddCfgToFpga(UINT32 tddId)
{
    UINT32 retVal = BSP_OK;

    BspClrTddCfgToFpga();
    memset_s(&g_tddIndCfgFpga,sizeof(T_TddCfgInfoToFpga),0,sizeof(T_TddCfgInfoToFpga));   /*先清再配*/
    retVal |= BspSetNrTddCfgToFpga(tddId);
    retVal |= BspSetLteTddCfgToFpga(tddId);

    return retVal;
}

static T_TddCfg *BspGetTddIndCfgFillAgainMem(void)
{
    if (g_tddIndCfgFillAgain == NULL)
    {
        g_tddIndCfgFillAgain = (T_TddCfg *)malloc(sizeof(T_TddCfg));
        if (g_tddIndCfgFillAgain == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_tddIndCfgFillAgain, sizeof(T_TddCfg), 0, sizeof(T_TddCfg));
    }
    return g_tddIndCfgFillAgain;
}

static T_TxTddCfg *BspGetTxTddIndCfgFillAgainMem(void)
{
    if (g_txTddIndCfgFillAgain == NULL)
    {
        g_txTddIndCfgFillAgain = (T_TxTddCfg *)malloc(sizeof(T_TxTddCfg));
        if (g_txTddIndCfgFillAgain == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_txTddIndCfgFillAgain, sizeof(T_TxTddCfg), 0, sizeof(T_TxTddCfg));
    }
    return g_txTddIndCfgFillAgain;
}

static T_RxTddCfg *BspGetRxTddIndCfgFillAgainMem(void)
{
    if (g_rxTddIndCfgFillAgain == NULL)
    {
        g_rxTddIndCfgFillAgain = (T_RxTddCfg *)malloc(sizeof(T_RxTddCfg));
        if (g_rxTddIndCfgFillAgain == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_rxTddIndCfgFillAgain, sizeof(T_RxTddCfg), 0, sizeof(T_RxTddCfg));
    }
    return g_rxTddIndCfgFillAgain;
}

/*对高层下发的group天线组进行重新填充，相同的TDD放到同一个group组中，根据制式每种制式保留一组时隙配比*/
UINT32 BspFillAgainTddCfgInfo(T_TddCfg *tddIndCfg)
{
    UINT32 ulCnt = 0;
    UINT32 groupNum = 0;
    UINT32 groupId = 0;
    UINT32 antMask = 0;
    UINT32 ulIndex = 0;
    UINT32 groupNumFill = 0;/*重新填充后的group的数量*/
    UINT32 groupFillTdd[MAX_TDD_GROUP_NUM] = {BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE};/*重新统计后对应的TDD index*/
    UINT32 groupFillGroupMask[MAX_TDD_GROUP_NUM] = {0};/*重新统计后相同TDD对应的group位置掩码*/
    UINT32 groupFillRadioMask[MAX_TDD_GROUP_NUM][2] = {0};/*重新统计后相同TDD对应包含的制式掩码*/
    UINT32 groupFillChanMask[MAX_TDD_GROUP_NUM] = {0};/*重新统计后相同TDD对应的通道掩码全集*/
    UINT32 loop = 0;
    UINT32 carrLoop = 0;
    UINT32 carrNum = 0;
    UINT32 radio = 0;
    UINT32 carrNumFill = 0;
    UINT32 lteFlag = 0;
    UINT32 nrFlag = 0;
    T_TddCfg *tddIndCfgFillAgain = BspGetTddIndCfgFillAgainMem();
    INPUT_POINTER_CHECK(tddIndCfgFillAgain);
    INPUT_POINTER_CHECK(tddIndCfg);

    memset_s(tddIndCfgFillAgain,sizeof(T_TddCfg),0,sizeof(T_TddCfg));
    /*无论是否有效都清除TDD和GROUPID的对应关系*/
    clrGroupIdToTddIdMap();
    if(0 == tddIndCfg->validFlag)
    {
        memcpy_s(tddIndCfgFillAgain,sizeof(T_TddCfg),tddIndCfg,sizeof(T_TddCfg));
        return BSP_OK;
    }
    groupNum = tddIndCfg->groupNum;
    if(groupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s groupnum=%d is over!\n",__func__,groupNum);
        return BSP_ERROR;
    }
    
    /*将相同TDD index的group进行掩码统计，记录对应的TDD*/
    for(ulCnt = 0; ulCnt < groupNum; ulCnt++)
    {
        ulIndex = 0xff;
        groupId = tddIndCfg->tddIndicateCfg[ulCnt].groupId;
        antMask = tddIndCfg->tddIndicateCfg[ulCnt].chanMask;
        carrNum = tddIndCfg->tddIndicateCfg[ulCnt].carrNum;
        /*如果当前groupId内的载波有效数是0,不计入TDD分析中,避免因无效的配置导致下次配置分析结果未不需要重配，导致时延不更新问题*/
        if(carrNum == 0)
        {
            continue;
        }
        getTddCfgIndex(groupId, antMask, &ulIndex);
        /*4.1 将对应的groupid和对应的TDD id配置对应的map关系*/
        setGroupIdToTddIdMap(ulIndex,groupId,antMask);
        for(loop = 0; loop < MAX_TDD_GROUP_NUM; loop++)
        {
            if(groupFillTdd[loop] == ulIndex)
            {
                break;
            }
        }
        if(loop >= MAX_TDD_GROUP_NUM)
        {
            groupFillTdd[groupNumFill] = ulIndex;
            groupFillGroupMask[groupNumFill] |= BIT_SET(ulCnt);
            groupFillChanMask[groupNumFill] |= antMask;
            groupNumFill++;
        }
        else
        {
            groupFillGroupMask[loop] |= BIT_SET(ulCnt);
            groupFillChanMask[loop] |= antMask;
        }
    }
    /*如果重新统计的group数量和高层下发的数量一致，证明没有劈裂，不需要合并group配置*/
    if(groupNumFill == groupNum)
    {
        memcpy_s(tddIndCfgFillAgain,sizeof(T_TddCfg),tddIndCfg,sizeof(T_TddCfg));
        dbgInfo("[%s] groupNumFill'%d groupNum'%d\n",__FUNCTION__,groupNumFill,groupNum);
        return BSP_OK;
    }
    /*将相同TDD index的group包含的制式进行统计*/
    for(ulCnt = 0; ulCnt < groupNumFill; ulCnt++)
    {
        for(loop = 0; loop < groupNum; loop++)
        {
            if(groupFillGroupMask[ulCnt] & BIT_SET(loop))
            {
                carrNum = 0;
                carrNum = tddIndCfg->tddIndicateCfg[loop].carrNum;
                for(carrLoop = 0; carrLoop < carrNum; carrLoop++)
                {
                    radio = 0;
                    radio = tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrLoop].radioMode;
                    if((radio & groupFillRadioMask[ulCnt][0]) == 0)
                    {
                        groupFillRadioMask[ulCnt][0] |= radio;
                        groupFillRadioMask[ulCnt][1]++;
                    }
                }
            }
        }
    }
    /*填充重排后的载波*/
    tddIndCfgFillAgain->validFlag = tddIndCfg->validFlag;
    tddIndCfgFillAgain->groupNum = groupNumFill;
    for(ulCnt = 0; ulCnt < groupNumFill; ulCnt++)
    {
        lteFlag = 0;
        nrFlag = 0;
        carrNumFill = 0;
        tddIndCfgFillAgain->tddIndicateCfg[ulCnt].groupId = groupFillGroupMask[ulCnt];
        tddIndCfgFillAgain->tddIndicateCfg[ulCnt].carrNum = groupFillRadioMask[ulCnt][1];
        tddIndCfgFillAgain->tddIndicateCfg[ulCnt].chanMask = groupFillChanMask[ulCnt];
        for(loop = 0; loop < groupNum; loop++)
        {
            if(groupFillGroupMask[ulCnt] & BIT_SET(loop))
            {
                carrNum = 0;
                carrNum = tddIndCfg->tddIndicateCfg[loop].carrNum;
                for(carrLoop = 0; carrLoop < carrNum; carrLoop++)
                {
                    radio = 0;
                    radio = tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrLoop].radioMode;
                    if((groupFillRadioMask[ulCnt][1] == 1) && (radio != 0))
                    {
                        memcpy_s(&tddIndCfgFillAgain->tddIndicateCfg[ulCnt].carrTddIndicateCfg[carrNumFill],sizeof(T_CarrTddIndicateNewCfg),&tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrLoop],sizeof(T_CarrTddIndicateNewCfg));
                        carrNumFill++;
                        break;
                    }
                    else if(groupFillRadioMask[ulCnt][1] == 2)
                    {
                        if((radio == BSP_RADIO_STANDARD_LTE_TDD) && (lteFlag == 0))
                        {
                            lteFlag = 1;
                            memcpy_s(&tddIndCfgFillAgain->tddIndicateCfg[ulCnt].carrTddIndicateCfg[carrNumFill],sizeof(T_CarrTddIndicateNewCfg),&tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrLoop],sizeof(T_CarrTddIndicateNewCfg));
                            carrNumFill++;
                        }
                        if((radio == BSP_RADIO_STANDARD_5G) && (nrFlag == 0))
                        {
                            nrFlag = 1;
                            memcpy_s(&tddIndCfgFillAgain->tddIndicateCfg[ulCnt].carrTddIndicateCfg[carrNumFill],sizeof(T_CarrTddIndicateNewCfg),&tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrLoop],sizeof(T_CarrTddIndicateNewCfg));
                            carrNumFill++;
                        }
                    }
                }
                if(carrNumFill == groupFillRadioMask[ulCnt][1])
                {
                    break;
                }
            }
        }
    }

    return BSP_OK;
}

/* 优化代码复杂度 */
UINT32 BspFillAgainTxTddCfgInfoPartOne(T_TxTddCfg *txTddIndCfg, UINT32 *groupFillGroupMask, UINT32 *groupFillChanMask, UINT32 *groupNumFill)
{
    UINT32 retVal = BSP_OK;
    UINT32 cnt = 0;
    UINT32 loop = 0;
    UINT32 index = 0;
    UINT32 groupNum = txTddIndCfg->groupNum;
    UINT32 groupId = 0;
    UINT32 antMask = 0;
    UINT32 carrNum = 0;
    UINT32 groupFillTdd[MAX_TDD_GROUP_NUM] = {BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE};/*重新统计后对应的TDD index*/
    
    for(cnt = 0; cnt < groupNum; cnt++)
    {
        ARR_BOUND_TDDCFG(cnt,MAX_TDD_GROUP_NUM);
        index = 0xff;
        INPUT_POINTER_CHECK(txTddIndCfg);
        groupId = txTddIndCfg->tddIndicateCfg[cnt].groupId ;
        antMask = txTddIndCfg->tddIndicateCfg[cnt].chanMask;
        carrNum = txTddIndCfg->tddIndicateCfg[cnt].carrNum;
        
        /*如果当前groupId内的载波有效数是0,不计入TDD分析中,避免因无效的配置导致下次配置分析结果未不需要重配，导致时延不更新问题*/
        if(carrNum == 0)
        {
            continue;
        }
        getTxOrRxTddCfgIndex(groupId, antMask, &index, TX);
        /*4.1 将对应的groupid和对应的TDD id配置对应的map关系*/
        setGroupIdToTxOrRxTddIdMap(index,groupId,antMask,TX);
        for(loop = 0; loop < MAX_TDD_GROUP_NUM; loop++)
        {
            ARR_BOUND_TDDCFG(loop,MAX_TDD_GROUP_NUM);
            if(groupFillTdd[loop] == index)
            {
                break;
            }
        }
        if(loop >= MAX_TDD_GROUP_NUM)
        {
            ARR_BOUND_TDDCFG(*groupNumFill,MAX_TDD_GROUP_NUM);
            groupFillTdd[*groupNumFill] = index;
            groupFillGroupMask[*groupNumFill] |= BIT_SET(cnt);
            groupFillChanMask[*groupNumFill] |= antMask;
            (*groupNumFill)++;
        }
        else
        {
            groupFillGroupMask[loop] |= BIT_SET(cnt);
            groupFillChanMask[loop] |= antMask;
        }
    }

    return retVal;
}

UINT32 BspFillAgainRxTddCfgInfoPartOne(T_RxTddCfg *rxTddIndCfg, UINT32 *groupFillGroupMask, UINT32 *groupFillChanMask, UINT32 *groupNumFill)
{
    UINT32 retVal = BSP_OK;
    UINT32 cnt = 0;
    UINT32 loop = 0;
    UINT32 index = 0;
    UINT32 groupNum = rxTddIndCfg->groupNum;
    UINT32 groupId = 0;
    UINT32 antMask = 0;
    UINT32 carrNum = 0;
    UINT32 groupFillTdd[MAX_TDD_GROUP_NUM] = {BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE};/*重新统计后对应的TDD index*/
    
    for(cnt = 0; cnt < groupNum; cnt++)
    {
        ARR_BOUND_TDDCFG(cnt,MAX_TDD_GROUP_NUM);
        index = 0xff;
        INPUT_POINTER_CHECK(rxTddIndCfg);
        groupId = rxTddIndCfg->tddIndicateCfg[cnt].groupId ;
        antMask = rxTddIndCfg->tddIndicateCfg[cnt].chanMask;
        carrNum = rxTddIndCfg->tddIndicateCfg[cnt].carrNum;
        
        /*如果当前groupId内的载波有效数是0,不计入TDD分析中,避免因无效的配置导致下次配置分析结果未不需要重配，导致时延不更新问题*/
        if(carrNum == 0)
        {
            continue;
        }
        getTxOrRxTddCfgIndex(groupId, antMask, &index, RX);
        /*4.1 将对应的groupid和对应的TDD id配置对应的map关系*/
        setGroupIdToTxOrRxTddIdMap(index,groupId,antMask,RX);
        for(loop = 0; loop < MAX_TDD_GROUP_NUM; loop++)
        {
            ARR_BOUND_TDDCFG(loop,MAX_TDD_GROUP_NUM);
            if(groupFillTdd[loop] == index)
            {
                break;
            }
        }
        if(loop >= MAX_TDD_GROUP_NUM)
        {
            ARR_BOUND_TDDCFG(*groupNumFill,MAX_TDD_GROUP_NUM);
            groupFillTdd[*groupNumFill] = index;
            groupFillGroupMask[*groupNumFill] |= BIT_SET(cnt);
            groupFillChanMask[*groupNumFill] |= antMask;
            (*groupNumFill)++;
        }
        else
        {
            groupFillGroupMask[loop] |= BIT_SET(cnt);
            groupFillChanMask[loop] |= antMask;
        }
    }

    return retVal;
}

UINT32 BspFillAgainTxTddCfgInfoPartTwo(UINT32 groupNumFill, UINT32 *groupFillGroupMask, UINT32 (*groupFillRadioMask)[2], T_TxTddCfg *txTddIndCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 cnt = 0;
    UINT32 loop = 0;
    UINT32 carrLoop = 0;
    UINT32 temp = 0;

    UINT32 groupNum = 0;
    UINT32 carrNum = 0;
    UINT32 radio = 0;

    /* 检查空指针 */
    if (NULL == txTddIndCfg)
    {
        dbgInfo("[%s]Input Pointer is NULL !!",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"[%s]TX:Input Pointer is NULL ! \n", __FUNCTION__);
        return BSP_ERROR;
    }

    groupNum = txTddIndCfg->groupNum;

    for(cnt = 0; cnt < groupNumFill; cnt++)
    {
        for(loop = 0; loop < groupNum; loop++)
        {
            ARR_BOUND_TDDCFG(cnt,MAX_TDD_GROUP_NUM);
            if(groupFillGroupMask[cnt] & BIT_SET(loop))
            {
                ARR_BOUND_TDDCFG(loop,MAX_TDD_GROUP_NUM);              
                carrNum = 0;    
                carrNum = txTddIndCfg->tddIndicateCfg[loop].carrNum;
                for(carrLoop = 0; carrLoop < carrNum; carrLoop++)
                {
                    ARR_BOUND_TDDCFG(carrLoop,carrNum);
                    ARR_BOUND_TDDCFG(cnt,groupNumFill);
                    radio = 0;
                    radio = txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrLoop].radioMode;
                    
                    temp = 0;
                    temp = (radio & groupFillRadioMask[cnt][0]);
                    groupFillRadioMask[cnt][0] = (temp == 0) ? ((groupFillRadioMask[cnt][0]) | (radio)) : groupFillRadioMask[cnt][0];
                    groupFillRadioMask[cnt][1] = (temp == 0) ? ((groupFillRadioMask[cnt][1])+1) : groupFillRadioMask[cnt][1];
                    
                }
            }
        }
    }

    return retVal;
}

UINT32 BspFillAgainRxTddCfgInfoPartTwo(UINT32 groupNumFill, UINT32 *groupFillGroupMask, UINT32 (*groupFillRadioMask)[2], T_RxTddCfg *rxTddIndCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 cnt = 0;
    UINT32 loop = 0;
    UINT32 carrLoop = 0;
    UINT32 temp = 0;
    UINT32 groupNum = 0;
    UINT32 carrNum = 0;
    UINT32 radio = 0;

    /* 检查空指针 */
    if (NULL == rxTddIndCfg)
    {
        dbgInfo("[%s]Input Pointer is NULL !!",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"[%s]RX:Input Pointer is NULL ! \n", __FUNCTION__);
        return BSP_ERROR;
    }

    groupNum = rxTddIndCfg->groupNum;

    for(cnt = 0; cnt < groupNumFill; cnt++)
    {
        for(loop = 0; loop < groupNum; loop++)
        {
            ARR_BOUND_TDDCFG(cnt,MAX_TDD_GROUP_NUM);
            if(groupFillGroupMask[cnt] & BIT_SET(loop))
            {
                ARR_BOUND_TDDCFG(loop,MAX_TDD_GROUP_NUM);              
                carrNum = 0;    
                carrNum = rxTddIndCfg->tddIndicateCfg[loop].carrNum;
                for(carrLoop = 0; carrLoop < carrNum; carrLoop++)
                {
                    ARR_BOUND_TDDCFG(carrLoop,carrNum);
                    ARR_BOUND_TDDCFG(cnt,groupNumFill);
                    radio = 0;
                    radio = rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrLoop].radioMode;
                    
                    temp = 0;
                    temp = (radio & groupFillRadioMask[cnt][0]);
                    groupFillRadioMask[cnt][0] = (temp == 0) ? ((groupFillRadioMask[cnt][0]) | (radio)) : groupFillRadioMask[cnt][0];
                    groupFillRadioMask[cnt][1] = (temp == 0) ? ((groupFillRadioMask[cnt][1])+1) : groupFillRadioMask[cnt][1];
                    
                }
            }
        }
    }

    return retVal;
}

UINT32 BspFillAgainTxTddCfgInfoPartThree(UINT32 (*groupFillRadioMask)[2], T_TxTddCfg *txTddIndCfg, T_TxTddCfg *txTddIndCfgFillAgain, T_FillAgainTddCfgInfoPartThree txTddCfgInfoPartThree)
{
    UINT32 retVal = BSP_OK;
    UINT32 carrLoop = 0;
    UINT32 carrNum = txTddCfgInfoPartThree.carrNum;
    UINT32 *loop = txTddCfgInfoPartThree.loop;
    UINT32 *cnt = txTddCfgInfoPartThree.cnt;
    UINT32 *radio = txTddCfgInfoPartThree.radio;
    UINT32 *lteFlag = txTddCfgInfoPartThree.lteFlag;
    UINT32 *carrNumFill = txTddCfgInfoPartThree.carrNumFill;
    UINT32 *nrFlag = txTddCfgInfoPartThree.nrFlag;

    INPUT_POINTER_CHECK(loop);
    INPUT_POINTER_CHECK(cnt);
    INPUT_POINTER_CHECK(radio);
    INPUT_POINTER_CHECK(lteFlag);
    INPUT_POINTER_CHECK(carrNumFill);
    INPUT_POINTER_CHECK(nrFlag);

    for(carrLoop = 0; carrLoop < carrNum; carrLoop++)
    {
        ARR_BOUND_TDDCFG(carrLoop,carrNum);
        *radio = 0;
        *radio =txTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop].radioMode;
        if((groupFillRadioMask[*cnt][1] == 1) && (*radio != 0))
        {
            ARR_BOUND_TDDCFG(*carrNumFill,MAX_TDD_GROUP_NUM);
            memcpy_s(&(txTddIndCfgFillAgain->tddIndicateCfg[*cnt].carrTddIndicateCfg[*carrNumFill]),sizeof(T_TxCarrTddIndicateNewCfg),&(txTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop]),sizeof(T_TxCarrTddIndicateNewCfg));
            (*carrNumFill)++;
            break;
        }
        else if(groupFillRadioMask[*cnt][1] == 2)
        {
            if((*radio == BSP_RADIO_STANDARD_LTE_TDD) && (*lteFlag == 0))
            {
                ARR_BOUND_TDDCFG(*carrNumFill,MAX_TDD_GROUP_NUM);
                *lteFlag = 1;
                memcpy_s(&(txTddIndCfgFillAgain->tddIndicateCfg[*cnt].carrTddIndicateCfg[*carrNumFill]),sizeof(T_TxCarrTddIndicateNewCfg),&(txTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop]),sizeof(T_TxCarrTddIndicateNewCfg));
                (*carrNumFill)++;
            }
            if((*radio == BSP_RADIO_STANDARD_5G) && (*nrFlag == 0))
            {
                ARR_BOUND_TDDCFG(*carrNumFill,MAX_TDD_GROUP_NUM);
                *nrFlag = 1;
                memcpy_s(&(txTddIndCfgFillAgain->tddIndicateCfg[*cnt].carrTddIndicateCfg[*carrNumFill]),sizeof(T_TxCarrTddIndicateNewCfg),&(txTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop]),sizeof(T_TxCarrTddIndicateNewCfg));
                (*carrNumFill)++;
            }
        }
    }

    return retVal;
}

UINT32 BspFillAgainRxTddCfgInfoPartThree(UINT32 (*groupFillRadioMask)[2], T_RxTddCfg *rxTddIndCfg, T_RxTddCfg *rxTddIndCfgFillAgain, T_FillAgainTddCfgInfoPartThree rxTddCfgInfoPartThree)
{
    UINT32 retVal = BSP_OK;
    UINT32 carrLoop = 0;
    UINT32 carrNum = rxTddCfgInfoPartThree.carrNum;
    UINT32 *loop = rxTddCfgInfoPartThree.loop;
    UINT32 *cnt = rxTddCfgInfoPartThree.cnt;
    UINT32 *radio = rxTddCfgInfoPartThree.radio;
    UINT32 *lteFlag = rxTddCfgInfoPartThree.lteFlag;
    UINT32 *carrNumFill = rxTddCfgInfoPartThree.carrNumFill;
    UINT32 *nrFlag = rxTddCfgInfoPartThree.nrFlag;

    INPUT_POINTER_CHECK(loop);
    INPUT_POINTER_CHECK(cnt);
    INPUT_POINTER_CHECK(radio);
    INPUT_POINTER_CHECK(lteFlag);
    INPUT_POINTER_CHECK(carrNumFill);
    INPUT_POINTER_CHECK(nrFlag);

    for(carrLoop = 0; carrLoop < carrNum; carrLoop++)
    {
        ARR_BOUND_TDDCFG(carrLoop,carrNum);
        *radio = 0;
        *radio =rxTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop].radioMode;
        if((groupFillRadioMask[*cnt][1] == 1) && (*radio != 0))
        {
            ARR_BOUND_TDDCFG(*carrNumFill,MAX_TDD_GROUP_NUM);
            memcpy_s(&(rxTddIndCfgFillAgain->tddIndicateCfg[*cnt].carrTddIndicateCfg[*carrNumFill]),sizeof(T_RxCarrTddIndicateNewCfg),&(rxTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop]),sizeof(T_RxCarrTddIndicateNewCfg));
            (*carrNumFill)++;
            break;
        }
        else if(groupFillRadioMask[*cnt][1] == 2)
        {
            if((*radio == BSP_RADIO_STANDARD_LTE_TDD) && (*lteFlag == 0))
            {
                ARR_BOUND_TDDCFG(*carrNumFill,MAX_TDD_GROUP_NUM);
                *lteFlag = 1;
                memcpy_s(&(rxTddIndCfgFillAgain->tddIndicateCfg[*cnt].carrTddIndicateCfg[*carrNumFill]),sizeof(T_RxCarrTddIndicateNewCfg),&(rxTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop]),sizeof(T_RxCarrTddIndicateNewCfg));
                (*carrNumFill)++;
            }
            if((*radio == BSP_RADIO_STANDARD_5G) && (*nrFlag == 0))
            {
                ARR_BOUND_TDDCFG(*carrNumFill,MAX_TDD_GROUP_NUM);
                *nrFlag = 1;
                memcpy_s(&(rxTddIndCfgFillAgain->tddIndicateCfg[*cnt].carrTddIndicateCfg[*carrNumFill]),sizeof(T_RxCarrTddIndicateNewCfg),&(rxTddIndCfg->tddIndicateCfg[*loop].carrTddIndicateCfg[carrLoop]),sizeof(T_RxCarrTddIndicateNewCfg));
                (*carrNumFill)++;
            }
        }
    }

    return retVal;
}

/*TX:对高层下发的group天线组进行重新填充，相同的TDD放到同一个group组中，根据制式每种制式保留一组时隙配比*/
UINT32 BspFillAgainTxTddCfgInfo(T_TxTddCfg *tddIndCfg)
{
    UINT32 cnt = 0;
    UINT32 groupNum = 0;
    // UINT32 groupId = 0;
    // UINT32 antMask = 0;
    // UINT32 index = 0;
    UINT32 groupNumFill = 0;/*重新填充后的group的数量*/
    // UINT32 carrIndex = 0;
    // UINT32 groupFillTdd[MAX_TDD_GROUP_NUM] = {BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE};/*重新统计后对应的TDD index*/
    UINT32 groupFillGroupMask[MAX_TDD_GROUP_NUM] = {0};/*重新统计后相同TDD对应的group位置掩码*/
    UINT32 groupFillRadioMask[MAX_TDD_GROUP_NUM][2] = {0};/*重新统计后相同TDD对应包含的制式掩码*/
    UINT32 groupFillChanMask[MAX_TDD_GROUP_NUM] = {0};/*重新统计后相同TDD对应的通道掩码全集*/
    UINT32 loop = 0;
    // UINT32 carrLoop = 0;
    UINT32 carrNum = 0;
    UINT32 radio = 0;
    UINT32 carrNumFill = 0;
    UINT32 lteFlag = 0;
    UINT32 nrFlag = 0;
    T_TxTddCfg *tddIndCfgFillAgain = BspGetTxTddIndCfgFillAgainMem();
    T_FillAgainTddCfgInfoPartThree txTddCfgInfoPartThree = {0};

    INPUT_POINTER_CHECK(tddIndCfgFillAgain);
    INPUT_POINTER_CHECK(tddIndCfg);

    memset_s(tddIndCfgFillAgain,sizeof(T_TxTddCfg),0,sizeof(T_TxTddCfg));
    /*无论是否有效都清除TDD和GROUPID的对应关系*/
    clrGroupIdToTxOrRxTddIdMap(TX);
    if(0 == tddIndCfg->validFlag)
    {
        memcpy_s(tddIndCfgFillAgain,sizeof(T_TxTddCfg),tddIndCfg,sizeof(T_TxTddCfg));
        return BSP_OK;
    }
    groupNum = tddIndCfg->groupNum;
    if(groupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s groupnum=%d is over!\n",__func__,groupNum);
        return BSP_ERROR;
    }
    
    /*将相同TDD index的group进行掩码统计，记录对应的TDD*/
    BspFillAgainTxTddCfgInfoPartOne(tddIndCfg, &groupFillGroupMask[0], &groupFillChanMask[0], &groupNumFill);
    /*如果重新统计的group数量和高层下发的数量一致，证明没有劈裂，不需要合并group配置*/
    if(groupNumFill == groupNum)
    {
        memcpy_s(tddIndCfgFillAgain,sizeof(T_TxTddCfg),tddIndCfg,sizeof(T_TxTddCfg));
        dbgInfo("[%s] groupNumFill'%d groupNum'%d\n",__FUNCTION__,groupNumFill,groupNum);
        return BSP_OK;
    }

    /*将相同TDD index的group包含的制式进行统计*/
    BspFillAgainTxTddCfgInfoPartTwo(groupNumFill, &groupFillGroupMask[0], groupFillRadioMask, tddIndCfg);
    
    /*填充重排后的载波*/
    tddIndCfgFillAgain->validFlag = tddIndCfg->validFlag;
    tddIndCfgFillAgain->groupNum = groupNumFill;
    for(cnt = 0; cnt < groupNumFill; cnt++)
    {
        ARR_BOUND_TDDCFG(cnt,groupNumFill);
        lteFlag = 0;
        nrFlag = 0;
        carrNumFill = 0;
        tddIndCfgFillAgain->tddIndicateCfg[cnt].groupId = groupFillGroupMask[cnt];
        tddIndCfgFillAgain->tddIndicateCfg[cnt].carrNum = groupFillRadioMask[cnt][1];
        tddIndCfgFillAgain->tddIndicateCfg[cnt].chanMask = groupFillChanMask[cnt];
        for(loop = 0; loop < groupNum; loop++)
        {
            if(groupFillGroupMask[cnt] & BIT_SET(loop))
            {
                ARR_BOUND_TDDCFG(loop,groupNum);
                carrNum = 0;
                carrNum = tddIndCfg->tddIndicateCfg[loop].carrNum;
                txTddCfgInfoPartThree.carrNum = carrNum;
                txTddCfgInfoPartThree.loop = &loop;
                txTddCfgInfoPartThree.cnt = &cnt;
                txTddCfgInfoPartThree.radio = &radio;
                txTddCfgInfoPartThree.lteFlag = &lteFlag;
                txTddCfgInfoPartThree.carrNumFill = &carrNumFill;
                txTddCfgInfoPartThree.nrFlag = &nrFlag;

                BspFillAgainTxTddCfgInfoPartThree(groupFillRadioMask, tddIndCfg, tddIndCfgFillAgain, txTddCfgInfoPartThree);
                if(carrNumFill == groupFillRadioMask[cnt][1])
                {
                    break;
                }
            }
        }
    }

    return BSP_OK;
}

/*rx:对高层下发的group天线组进行重新填充，相同的TDD放到同一个group组中，根据制式每种制式保留一组时隙配比*/
UINT32 BspFillAgainRxTddCfgInfo(T_RxTddCfg *tddIndCfg)
{
    UINT32 cnt = 0;
    UINT32 groupNum = 0;
    // UINT32 groupId = 0;
    // UINT32 antMask = 0;
    // UINT32 index = 0;
    UINT32 groupNumFill = 0;/*重新填充后的group的数量*/
    // UINT32 carrIndex = 0;
    // UINT32 groupFillTdd[MAX_TDD_GROUP_NUM] = {BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE,BSP_INVALID_VALUE};/*重新统计后对应的TDD index*/
    UINT32 groupFillGroupMask[MAX_TDD_GROUP_NUM] = {0};/*重新统计后相同TDD对应的group位置掩码*/
    UINT32 groupFillRadioMask[MAX_TDD_GROUP_NUM][2] = {0};/*重新统计后相同TDD对应包含的制式掩码*/
    UINT32 groupFillChanMask[MAX_TDD_GROUP_NUM] = {0};/*重新统计后相同TDD对应的通道掩码全集*/
    UINT32 loop = 0;
    // UINT32 carrLoop = 0;
    UINT32 carrNum = 0;
    UINT32 radio = 0;
    UINT32 carrNumFill = 0;
    UINT32 lteFlag = 0;
    UINT32 nrFlag = 0;
    T_RxTddCfg *tddIndCfgFillAgain = BspGetRxTddIndCfgFillAgainMem();
    T_FillAgainTddCfgInfoPartThree rxTddCfgInfoPartThree = {0};
    
    INPUT_POINTER_CHECK(tddIndCfgFillAgain);
    INPUT_POINTER_CHECK(tddIndCfg);

    memset_s(tddIndCfgFillAgain,sizeof(T_RxTddCfg),0,sizeof(T_RxTddCfg));
    /*无论是否有效都清除TDD和GROUPID的对应关系*/
    clrGroupIdToTxOrRxTddIdMap(RX);
    if(0 == tddIndCfg->validFlag)
    {
        memcpy_s(tddIndCfgFillAgain,sizeof(T_RxTddCfg),tddIndCfg,sizeof(T_RxTddCfg));
        return BSP_OK;
    }
    groupNum = tddIndCfg->groupNum;
    if(groupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s groupnum=%d is over!\n",__func__,groupNum);
        return BSP_ERROR;
    }

    /*将相同TDD index的group进行掩码统计，记录对应的TDD*/
    BspFillAgainRxTddCfgInfoPartOne(tddIndCfg, &groupFillGroupMask[0], &groupFillChanMask[0], &groupNumFill);

    /*如果重新统计的group数量和高层下发的数量一致，证明没有劈裂，不需要合并group配置*/
    if(groupNumFill == groupNum)
    {
        memcpy_s(tddIndCfgFillAgain,sizeof(T_RxTddCfg),tddIndCfg,sizeof(T_RxTddCfg));
        dbgInfo("[%s] RX:--> groupNumFill'%d groupNum'%d\n",__FUNCTION__,groupNumFill,groupNum);
        return BSP_OK;
    }

    /*将相同TDD index的group包含的制式进行统计*/
    BspFillAgainRxTddCfgInfoPartTwo(groupNumFill, &groupFillGroupMask[0], groupFillRadioMask, tddIndCfg);
    
    /*填充重排后的载波*/
    tddIndCfgFillAgain->validFlag = tddIndCfg->validFlag;
    tddIndCfgFillAgain->groupNum = groupNumFill;

    for(cnt = 0; cnt < groupNumFill; cnt++)
    {
        ARR_BOUND_TDDCFG(cnt,groupNumFill);
        lteFlag = 0;
        nrFlag = 0;
        carrNumFill = 0;
        tddIndCfgFillAgain->tddIndicateCfg[cnt].groupId = groupFillGroupMask[cnt];
        tddIndCfgFillAgain->tddIndicateCfg[cnt].carrNum = groupFillRadioMask[cnt][1];
        tddIndCfgFillAgain->tddIndicateCfg[cnt].chanMask = groupFillChanMask[cnt];
        for(loop = 0; loop < groupNum; loop++)
        {
            ARR_BOUND_TDDCFG(loop,groupNum);
            if(groupFillGroupMask[cnt] & BIT_SET(loop))
            {
                carrNum = 0;
                carrNum = tddIndCfg->tddIndicateCfg[loop].carrNum;
                rxTddCfgInfoPartThree.carrNum = carrNum;
                rxTddCfgInfoPartThree.loop = &loop;
                rxTddCfgInfoPartThree.cnt = &cnt;
                rxTddCfgInfoPartThree.radio = &radio;
                rxTddCfgInfoPartThree.lteFlag = &lteFlag;
                rxTddCfgInfoPartThree.carrNumFill = &carrNumFill;
                rxTddCfgInfoPartThree.nrFlag = &nrFlag;

                BspFillAgainRxTddCfgInfoPartThree(groupFillRadioMask, tddIndCfg, tddIndCfgFillAgain, rxTddCfgInfoPartThree);
                if(carrNumFill == groupFillRadioMask[cnt][1])
                {
                    break;
                }
            }
        }
    }

    return BSP_OK;
}

T_TddCfg *BspGetTddIndCfgBakMem(void)
{
    if (g_tddIndCfgbak == NULL)
    {
        g_tddIndCfgbak = (T_TddCfg *)malloc(sizeof(T_TddCfg));
        if (g_tddIndCfgbak == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_tddIndCfgbak, sizeof(T_TddCfg), 0, sizeof(T_TddCfg));
    }
    return g_tddIndCfgbak;
}

static T_TxTddCfg *BspGetTxTddIndCfgBakMem(void)
{
    if (g_txTddIndCfgbak == NULL)
    {
        g_txTddIndCfgbak = (T_TxTddCfg *)malloc(sizeof(T_TxTddCfg));
        if (g_txTddIndCfgbak == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_txTddIndCfgbak, sizeof(T_TxTddCfg), 0, sizeof(T_TxTddCfg));
    }
    return g_txTddIndCfgbak;
}

static T_RxTddCfg *BspGetRxTddIndCfgBakMem(void)
{
    if (g_rxTddIndCfgbak == NULL)
    {
        g_rxTddIndCfgbak = (T_RxTddCfg *)malloc(sizeof(T_RxTddCfg));
        if (g_rxTddIndCfgbak == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_rxTddIndCfgbak, sizeof(T_RxTddCfg), 0, sizeof(T_RxTddCfg));
    }
    return g_rxTddIndCfgbak;
}

static UINT32 DbgSaveDifTxOrRxTddCfg(T_CarrTddIndCfg *pTddCfg, UINT32 groupId, UINT32 tddCfgId,UINT32 dir)
{
    if(tddCfgId >= MAX_TDD_GROUP_NUM || NULL == pTddCfg)
    {
        return BSP_ERROR;
    }

    if(TX == dir)
    {
        s_dbgTxGroupId[tddCfgId] = groupId;
        s_dbgDifTxTddCfgFlag[tddCfgId] = 1;
        memcpy_s(&(s_dbgdifTxTddCfg[tddCfgId]), sizeof(T_CarrTddIndCfg), pTddCfg, sizeof(T_CarrTddIndCfg));
    }
    else
    {
        s_dbgRxGroupId[tddCfgId] = groupId;
        s_dbgDifRxTddCfgFlag[tddCfgId] = 1;
        memcpy_s(&(s_dbgdifRxTddCfg[tddCfgId]), sizeof(T_CarrTddIndCfg), pTddCfg, sizeof(T_CarrTddIndCfg));
    }
    
    return BSP_OK;
}

VOID DbgPrnFillTddCfg()
{
    T_TddCfg *tddIndCfg = BspGetTddIndCfgFillAgainMem();
    INPUT_POINTER_CHECK_RETURN(tddIndCfg);
    DbgPrnTddCfg(tddIndCfg);
}

VOID DbgPrnFillTxOrRxTddCfg(UINT32 dir)
{
    if(TX == dir)
    {
        T_TxTddCfg *tddIndCfg = BspGetTxTddIndCfgFillAgainMem();
        INPUT_POINTER_CHECK_RETURN(tddIndCfg);
        DbgPrnTxTddCfg(tddIndCfg);
    }
    else
    {
        T_RxTddCfg *tddIndCfg = BspGetRxTddIndCfgFillAgainMem();
        INPUT_POINTER_CHECK_RETURN(tddIndCfg);
        DbgPrnRxTddCfg(tddIndCfg);
    }
    
}

VOID DbgPrnAppTxOrRxTddCfg(UINT32 dir)
{
    if(TX == dir)
    {
        T_TxTddCfg *txTddIndCfg = BspGetTxTddIndCfgBakMem();
        INPUT_POINTER_CHECK_RETURN(txTddIndCfg);
        DbgPrnTxTddCfg(txTddIndCfg);
    }
    else
    {
        T_RxTddCfg *rxTddIndCfg = BspGetRxTddIndCfgBakMem();
        INPUT_POINTER_CHECK_RETURN(rxTddIndCfg);
        DbgPrnRxTddCfg(rxTddIndCfg);
    }
}

/*****************************************************************************
 *  函数名称   : BspSetTddCfgInfo(*)
 *  功能描述   : APP配置TDD接口
 *  输入参数   : tddIndCfg:TDD表象
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : APP接口，主要进行分析，不实际配置表象
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTddCfgInfo(T_TddCfg *tddIndCfg)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulCnt = 0;
    UINT32 groupNum = 0;
    UINT32 groupId = 0;
    UINT32 antMask = 0;
    UINT32 ulIndex = 0;
    T_TddCfg *tddIndCfgFillAgain = BspGetTddIndCfgFillAgainMem();
    INPUT_POINTER_CHECK(tddIndCfgFillAgain);
    T_TddCfg *tddIndCfgbak = BspGetTddIndCfgBakMem();
    INPUT_POINTER_CHECK(tddIndCfgbak);

    /*1.将app下发的tdd配置保存备份*/
    recordTddIndCfg(tddIndCfgbak, tddIndCfg);
    /* 调试期间临时增加，版本稳定后删除 */
    DbgPrnAppTddCfg();
    /*2.将TDD INDEX相同的不同天线组进行重新组合*/
    ulRet = BspFillAgainTddCfgInfo(tddIndCfg);
    DbgPrnFillTddCfg();
    if(ulRet != BSP_OK)
    {
        dbgErr("[%s] FILL TDD CFG FAIL!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /*3.判断下发的tdd配置是否有效*/
    if(0 == tddIndCfgFillAgain->validFlag)
    {
        /*3.tdd配置无效，则将上一次保存的所有tdd配置信息清除*/
        for(ulCnt=0; ulCnt < MAX_TDD_GROUP_NUM; ulCnt++)
        {
            ulTddCfgFlag[ulCnt] = 0;
            clrCarrTddIndCfg(&g_tddIndCfgDif[ulCnt]);
            clrCarrTddIndCfg(&g_tddIndCfgBak_Nr[ulCnt]);
            clrCarrTddIndCfg(&g_tddIndCfgBak_Lte[ulCnt]);
            clrCarrTddIndCfg(&g_tddIndCfgOpt_Nr[ulCnt]);
            clrCarrTddIndCfg(&g_tddIndCfgOpt_Lte[ulCnt]);
        }
    }
    else
    {
        /*4.下发的tdd配置有效的情况下，先将已经删除的tdd配置信息清除*/
        if(IS_NCR != BspIsNcr())
        {
            BspClrTddIndCfgDif(tddIndCfgFillAgain);
        }

        groupNum = tddIndCfgFillAgain->groupNum;
        for(ulCnt = 0; ulCnt < groupNum; ulCnt++)
        {
            /*5.根据下发的tdd配置中的天线掩码和groupId查找对应的TDD配置的序号*/
            groupId = tddIndCfgFillAgain->tddIndicateCfg[ulCnt].groupId;
            antMask = tddIndCfgFillAgain->tddIndicateCfg[ulCnt].chanMask;
            getTddCfgIndex(groupId, antMask, &ulIndex);
            /*6.根据上一次第ulIndex套tdd标志的制式，分别做对应的重配流程预分析*/
            if(BSP_RADIO_STANDARD_LTE_TDD == ulTddCfgFlag[ulIndex])
            {
                ulRet = BspSingleModeReAnalysTddCfgInfo(ulIndex, BSP_RADIO_STANDARD_LTE_TDD, BSP_RADIO_STANDARD_5G, &tddIndCfgFillAgain->tddIndicateCfg[ulCnt]);
            }
            else if(BSP_RADIO_STANDARD_5G == ulTddCfgFlag[ulIndex])
            {
                ulRet = BspSingleModeReAnalysTddCfgInfo(ulIndex, BSP_RADIO_STANDARD_5G, BSP_RADIO_STANDARD_LTE_TDD, &tddIndCfgFillAgain->tddIndicateCfg[ulCnt]);
            }
            else
            {
                ulRet = BspAnalysTddCfgInfo(ulIndex, &tddIndCfgFillAgain->tddIndicateCfg[ulCnt]);
            }
        }
    }
    BspLog(LOG_LEVEL_0,"[%s] groupNum[%d], groupId[%d] antMask[%d].\n",__FUNCTION__, groupNum, groupId, antMask);
    BspSaveTddCfgAnalysResult();

    return ulRet;
}

/*****************************************************************************
 *  函数名称   : BspSetTxTddCfgInfo(*)
 *  功能描述   : APP配置TDD接口
 *  输入参数   : tddTxIndCfg:TDD表象
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : APP接口，主要进行分析，不实际配置表象
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetTxTddCfgInfo(T_TxTddCfg *tddTxIndCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 cnt = 0;
    UINT32 groupNum = 0;
    UINT32 groupId = 0;
    UINT32 antMask = 0;
    UINT32 index = 0;
    BspLog(LOG_LEVEL_0,"[%s] TX --> enter !\n",__FUNCTION__);
    T_TxTddCfg *tddIndCfgFillAgain = BspGetTxTddIndCfgFillAgainMem();
    INPUT_POINTER_CHECK(tddIndCfgFillAgain);
    T_TxTddCfg *tddIndCfgbak = BspGetTxTddIndCfgBakMem();
    INPUT_POINTER_CHECK(tddIndCfgbak);

    /*1.将app下发的tdd配置保存备份*/
    recordTxTddIndCfg(tddIndCfgbak, tddTxIndCfg);
    /* 调试期间临时增加，版本稳定后删除 */
    DbgPrnAppTxOrRxTddCfg(TX);
    /*2.将TDD INDEX相同的不同天线组进行重新组合*/
    retVal = BspFillAgainTxTddCfgInfo(tddTxIndCfg);
    DbgPrnFillTxOrRxTddCfg(TX);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] FILL TDD CFG FAIL!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /*3.判断下发的tdd配置是否有效*/
    if(0 == tddIndCfgFillAgain->validFlag)
    {
        /*3.tdd配置无效，则将上一次保存的所有tdd配置信息清除*/
        for(cnt=0; cnt < MAX_TDD_GROUP_NUM; cnt++)
        {
            ARR_BOUND_TDDCFG(cnt,MAX_TDD_GROUP_NUM);
            g_txTddCfgFlag[cnt] = 0;
            clrCarrTddIndCfg(&g_txTddIndCfgDif[cnt]);
            clrCarrTddIndCfg(&g_txTddIndCfgBak_Nr[cnt]);
            clrCarrTddIndCfg(&g_txTddIndCfgBak_Lte[cnt]);
            clrCarrTddIndCfg(&g_txTddIndCfgOpt_Nr[cnt]);
            clrCarrTddIndCfg(&g_txTddIndCfgOpt_Lte[cnt]);
        }
    }
    else
    {
        /*4.下发的tdd配置有效的情况下，先将已经删除的tdd配置信息清除*/
        BspClrTxTddIndCfgDif(tddIndCfgFillAgain);
        groupNum = tddIndCfgFillAgain->groupNum;
        for(cnt = 0; cnt < groupNum; cnt++)
        {
            if ((MAX_TDD_GROUP_NUM <= cnt) || (MAX_TDD_GROUP_NUM <= index))
            {
                return BSP_ERROR;
            }
            /*5.根据下发的tdd配置中的天线掩码和groupId查找对应的TDD配置的序号*/
            groupId = tddIndCfgFillAgain->tddIndicateCfg[cnt].groupId;
            antMask = tddIndCfgFillAgain->tddIndicateCfg[cnt].chanMask;
            getTxOrRxTddCfgIndex(groupId, antMask, &index, TX);
            /*6.根据上一次第ulIndex套tdd标志的制式，分别做对应的重配流程预分析*/
            ARR_BOUND_TDDCFG(index,MAX_TDD_GROUP_NUM);
            if(BSP_RADIO_STANDARD_LTE_TDD == g_txTddCfgFlag[index])
            {
                retVal = BspSingleModeReAnalysTxTddCfgInfo(index, BSP_RADIO_STANDARD_LTE_TDD, BSP_RADIO_STANDARD_5G, &tddIndCfgFillAgain->tddIndicateCfg[cnt]);
            }
            else if(BSP_RADIO_STANDARD_5G == g_txTddCfgFlag[index])
            {
                retVal = BspSingleModeReAnalysTxTddCfgInfo(index, BSP_RADIO_STANDARD_5G, BSP_RADIO_STANDARD_LTE_TDD, &tddIndCfgFillAgain->tddIndicateCfg[cnt]);
            }
            else
            {
                retVal = BspAnalysTxTddCfgInfo(index, &tddIndCfgFillAgain->tddIndicateCfg[cnt]);
            }
        }
    }
    BspLog(LOG_LEVEL_0,"[%s] TX --> groupNum[%d], groupId[%d] antMask[%d].\n",__FUNCTION__, groupNum, groupId, antMask);
    BspSaveTxTddCfgAnalysResult();

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspSetRxTddCfgInfo(*)
 *  功能描述   : APP配置TDD接口
 *  输入参数   : tddRxIndCfg:TDD表象
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : APP接口，主要进行分析，不实际配置表象
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetRxTddCfgInfo(T_RxTddCfg *tddRxIndCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 cnt = 0;
    UINT32 groupNum = 0;
    UINT32 groupId = 0;
    UINT32 antMask = 0;
    UINT32 index = 0;
    BspLog(LOG_LEVEL_0,"[%s] RX --> enter !\n",__FUNCTION__);
    T_RxTddCfg *tddIndCfgFillAgain = BspGetRxTddIndCfgFillAgainMem();
    INPUT_POINTER_CHECK(tddIndCfgFillAgain);
    T_RxTddCfg *tddIndCfgbak = BspGetRxTddIndCfgBakMem();
    INPUT_POINTER_CHECK(tddIndCfgbak);

    /*1.将app下发的tdd配置保存备份*/
    recordRxTddIndCfg(tddIndCfgbak, tddRxIndCfg);
    /* 调试期间临时增加，版本稳定后删除 */
    DbgPrnAppTxOrRxTddCfg(RX);
    /*2.将TDD INDEX相同的不同天线组进行重新组合*/
    retVal = BspFillAgainRxTddCfgInfo(tddRxIndCfg);
    DbgPrnFillTxOrRxTddCfg(RX);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] FILL TDD CFG FAIL!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    /*3.判断下发的tdd配置是否有效*/
    if(0 == tddIndCfgFillAgain->validFlag)
    {
        /*3.tdd配置无效，则将上一次保存的所有tdd配置信息清除*/
        for(cnt=0; cnt < MAX_TDD_GROUP_NUM; cnt++)
        {
            ARR_BOUND_TDDCFG(cnt,MAX_TDD_GROUP_NUM);
            g_rxTddCfgFlag[cnt] = 0;
            clrCarrTddIndCfg(&g_rxTddIndCfgDif[cnt]);
            clrCarrTddIndCfg(&g_rxTddIndCfgBak_Nr[cnt]);
            clrCarrTddIndCfg(&g_rxTddIndCfgBak_Lte[cnt]);
            clrCarrTddIndCfg(&g_rxTddIndCfgOpt_Nr[cnt]);
            clrCarrTddIndCfg(&g_rxTddIndCfgOpt_Lte[cnt]);
        }
    }
    else
    {
        /*4.下发的tdd配置有效的情况下，先将已经删除的tdd配置信息清除*/
        BspClrRxTddIndCfgDif(tddIndCfgFillAgain);
        groupNum = tddIndCfgFillAgain->groupNum;
        for(cnt = 0; cnt < groupNum; cnt++)
        {
            if (MAX_TDD_GROUP_NUM <= cnt)
            {
                return BSP_ERROR;
            }
            /*5.根据下发的tdd配置中的天线掩码和groupId查找对应的TDD配置的序号*/
            groupId = tddIndCfgFillAgain->tddIndicateCfg[cnt].groupId;
            antMask = tddIndCfgFillAgain->tddIndicateCfg[cnt].chanMask;
            getTxOrRxTddCfgIndex(groupId, antMask, &index, RX);
            /*6.根据上一次第ulIndex套tdd标志的制式，分别做对应的重配流程预分析*/
            ARR_BOUND_TDDCFG(index,MAX_TDD_GROUP_NUM);
            if(BSP_RADIO_STANDARD_LTE_TDD == g_rxTddCfgFlag[index])
            {
                retVal = BspSingleModeReAnalysRxTddCfgInfo(index, BSP_RADIO_STANDARD_LTE_TDD, BSP_RADIO_STANDARD_5G, &tddIndCfgFillAgain->tddIndicateCfg[cnt]);
            }
            else if(BSP_RADIO_STANDARD_5G == g_txTddCfgFlag[index])
            {
                retVal = BspSingleModeReAnalysRxTddCfgInfo(index, BSP_RADIO_STANDARD_5G, BSP_RADIO_STANDARD_LTE_TDD, &tddIndCfgFillAgain->tddIndicateCfg[cnt]);
            }
            else
            {
                retVal = BspAnalysRxTddCfgInfo(index, &tddIndCfgFillAgain->tddIndicateCfg[cnt]);
            }
        }
    }
    BspLog(LOG_LEVEL_0,"[%s] RX --> groupNum[%d], groupId[%d] antMask[%d].\n",__FUNCTION__, groupNum, groupId, antMask);
    BspSaveRxTddCfgAnalysResult();

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetTddCfgIdByGrouId(*)
 *  功能描述   : 通过APP的groupId寻找TDD索引
 *  输入参数   : groupId:APP下发的groupId
 *  输出参数   : ulIndex:Tdd索引
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetTddCfgIdByGrouId(UINT32 groupId,UINT32 *ulIndex,UINT32 *groupIndex)
{
    UINT32 ulRet = BSP_ERROR;
    UINT32 tddIndex = 0;
    UINT32 groupIdLoop = 0;
    for(tddIndex = 0; tddIndex < MAX_TDD_GROUP_NUM; tddIndex++)
    {
        for(groupIdLoop = 0; groupIdLoop < MAX_GROUPID_NUM_ONE_TDD; groupIdLoop++)
        {
            if(groupId == ((g_tddIdGroupIdMap[tddIndex][groupIdLoop]>>16) & 0xffff))
            {
                *ulIndex = tddIndex;
                *groupIndex = groupIdLoop;
                return BSP_OK;
            }
        }
    }
    return ulRet;
}

UINT32 BspGetTxOrRxTddCfgIdByGrouId(UINT32 groupId,UINT32 *ulIndex,UINT32 *groupIndex, UINT32 dir)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 tddIndex = 0;
    UINT32 groupIdLoop = 0;
    UINT32 tddIdGroupIdMap_Temp = 0;


    for(tddIndex = 0; tddIndex < MAX_TDD_GROUP_NUM; tddIndex++)
    {
        ARR_BOUND_TDDCFG(tddIndex,MAX_TDD_GROUP_NUM);
        for(groupIdLoop = 0; groupIdLoop < MAX_GROUPID_NUM_ONE_TDD; groupIdLoop++)
        {
            ARR_BOUND_TDDCFG(groupIdLoop,MAX_GROUPID_NUM_ONE_TDD);
            tddIdGroupIdMap_Temp = (TX == dir) ? (g_txTddIdGroupIdMap[tddIndex][groupIdLoop]>>16):(g_rxTddIdGroupIdMap[tddIndex][groupIdLoop]>>16);
            if(groupId == (tddIdGroupIdMap_Temp & 0xffff))
            {
                *ulIndex = tddIndex;
                *groupIndex = groupIdLoop;
                return BSP_OK;
            }
        }
    }
    return retVal;
}


/*****************************************************************************
 *  函数名称   : BspGetTddSwitchResult(*)
 *  功能描述   : 通过APP的groupId寻找对应TDD是否需要重配标志
 *  输入参数   : groupId:APP下发的groupId
 *  输出参数   : result:是否重配结果
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : APP接口
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetTddSwitchResult(UINT32 groupId,UINT32 *result)
{
    /*UINT32 ulCnt = 0;*/
    UINT32 ulRet = BSP_ERROR;
    UINT32 ulIndex = 0;
    UINT32 ulGroupIndex = 0;
    BspLog(LOG_LEVEL_0,"%s,groupId=%d enter \n", __FUNCTION__, groupId);
    *result = 0;
    ulRet = BspGetTddCfgIdByGrouId(groupId, &ulIndex,&ulGroupIndex);
    dbgInfo("[%s] groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,groupId,ulIndex,ulGroupIndex);
	if(ulIndex >= MAX_TDD_GROUP_NUM)
	{
        return BSP_ERROR;		
	}
	
    if(BSP_OK == ulRet)
    {
        if(TDD_NEED_CFG_SWTBL == ulTddReCfgFlag[ulIndex])
        {
            *result = 1;
            g_lastTddSwitch[ulIndex][2] = *result;
        }
        else if(TDD_NEED_ONLY_CFG_DLY == ulTddReCfgFlag[ulIndex])
        {
            *result = 1;
            g_lastTddSwitch[ulIndex][2] = 2;
        }
        else if((TDD_NOT_NEED_CFG == ulTddReCfgFlag[ulIndex]) && (ulTddReCfgDoneFlag[ulIndex] == 0))
        {
            *result = 1;
            g_lastTddSwitch[ulIndex][2] = 2;
        }
    }
    g_lastTddSwitch[ulIndex][0] = groupId;
    g_lastTddSwitch[ulIndex][1] = ulIndex;
    BspLog(LOG_LEVEL_0,"[%s] ret'%d groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,ulRet,groupId,ulIndex,ulGroupIndex);
    BspLog(LOG_LEVEL_0,"[%s] cfgflag'%d cfgdoneflag'%d result'%d \n",__FUNCTION__,ulTddReCfgFlag[ulIndex],ulTddReCfgDoneFlag[ulIndex],*result);
    /* 当TDD帧格式无变化时，通过其他需要重配TDD的判断接口再进行判断 */
    if(*result == 0 && NULL != p_FuncIsNeedUpdateTdd)
    {
       *result = p_FuncIsNeedUpdateTdd(g_tddIndCfgDif[ulIndex].uiTddCfgId);
       g_lastTddSwitch[ulIndex][3] = *result;
       if(*result == 1)
       {
           //coverity[cert_ctr50_cpp_violation:SUPPRESS]
           ulTddReCfgFlag[ulIndex] = TDD_NEED_ONLY_CFG_DLY;/*劈裂场景将标志改为更新时延标志*/
       }
       
    }
    g_lastTddSwitch[ulIndex][4] = *result;
    
    dbgInfo("%s groupId=%d, ulIndex=%d, result=%d\n", __FUNCTION__, groupId, ulIndex, *result);
    
    BspLog(LOG_LEVEL_0,"%s groupId=%d, ulIndex=%d, result=%d\n", __FUNCTION__, groupId, ulIndex, *result);
    
    return ulRet;
}

UINT32 BspGetTxTddSwitchResult(UINT32 groupId,UINT32 *result)
{
    /*UINT32 ulCnt = 0;*/
    UINT32 retVal = BSP_ERROR;
    UINT32 index = 0;
    UINT32 groupIndex = 0;
    BspLog(LOG_LEVEL_0,"%s,groupId=%d enter \n", __FUNCTION__, groupId);
    *result = 0;
    retVal = BspGetTxOrRxTddCfgIdByGrouId(groupId, &index,&groupIndex,TX);
    dbgInfo("[%s] groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,groupId,index,groupIndex);
	ARR_BOUND_TDDCFG(index,MAX_TDD_GROUP_NUM);
	
    if(BSP_OK == retVal)
    {
        if(TDD_NEED_CFG_SWTBL == g_txTddReCfgFlag[index])
        {
            *result = 1;
            g_lastTxTddSwitch[index][2] = *result;
        }
        else if(TDD_NEED_ONLY_CFG_DLY == g_txTddReCfgFlag[index])
        {
            *result = 1;
            g_lastTxTddSwitch[index][2] = 2;
        }
        else if((TDD_NOT_NEED_CFG == g_txTddReCfgFlag[index]) && (g_txTddReCfgDoneFlag[index] == 0))
        {
            *result = 1;
            g_lastTxTddSwitch[index][2] = 2;
        }
    }
    g_lastTxTddSwitch[index][0] = groupId;
    g_lastTxTddSwitch[index][1] = index;
    BspLog(LOG_LEVEL_0,"[%s] ret'%d groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,retVal,groupId,index,groupIndex);
    BspLog(LOG_LEVEL_0,"[%s] cfgflag'%d cfgdoneflag'%d result'%d \n",__FUNCTION__,g_txTddReCfgFlag[index],g_txTddReCfgDoneFlag[index],*result);
    /* 当TDD帧格式无变化时，通过其他需要重配TDD的判断接口再进行判断 */
    if(*result == 0 && NULL != p_FuncIsNeedUpdateTdd)
    {
       *result = p_FuncIsNeedUpdateTdd(g_txTddIndCfgDif[index].uiTddCfgId);
       g_lastTxTddSwitch[index][3] = *result;
       if(*result == 1)
       {
           //coverity[cert_ctr50_cpp_violation:SUPPRESS]
           g_txTddReCfgFlag[index] = TDD_NEED_ONLY_CFG_DLY;/*劈裂场景将标志改为更新时延标志*/
       }
       
    }
    g_lastTxTddSwitch[index][4] = *result;
    
    dbgInfo("%s groupId=%d, index=%d, result=%d\n", __FUNCTION__, groupId, index, *result);
    
    BspLog(LOG_LEVEL_0,"%s groupId=%d, index=%d, result=%d\n", __FUNCTION__, groupId, index, *result);
    
    return retVal;
}

UINT32 BspGetRxTddSwitchResult(UINT32 groupId,UINT32 *result)
{
    /*UINT32 ulCnt = 0;*/
    UINT32 retVal = BSP_ERROR;
    UINT32 index = 0;
    UINT32 groupIndex = 0;
    BspLog(LOG_LEVEL_0,"%s,groupId=%d enter \n", __FUNCTION__, groupId);
    *result = 0;
    retVal = BspGetTxOrRxTddCfgIdByGrouId(groupId, &index,&groupIndex,RX);
    dbgInfo("[%s] groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,groupId,index,groupIndex);
	ARR_BOUND_TDDCFG(index,MAX_TDD_GROUP_NUM);
	
    if(BSP_OK == retVal)
    {
        if(TDD_NEED_CFG_SWTBL == g_rxTddReCfgFlag[index])
        {
            *result = 1;
            g_lastRxTddSwitch[index][2] = *result;
        }
        else if(TDD_NEED_ONLY_CFG_DLY == g_rxTddReCfgFlag[index])
        {
            *result = 1;
            g_lastRxTddSwitch[index][2] = 2;
        }
        else if((TDD_NOT_NEED_CFG == g_rxTddReCfgFlag[index]) && (g_rxTddReCfgDoneFlag[index] == 0))
        {
            *result = 1;
            g_lastRxTddSwitch[index][2] = 2;
        }
    }
    g_lastRxTddSwitch[index][0] = groupId;
    g_lastRxTddSwitch[index][1] = index;
    BspLog(LOG_LEVEL_0,"[%s] ret'%d groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,retVal,groupId,index,groupIndex);
    BspLog(LOG_LEVEL_0,"[%s] cfgflag'%d cfgdoneflag'%d result'%d \n",__FUNCTION__,g_rxTddReCfgFlag[index],g_rxTddReCfgDoneFlag[index],*result);
    /* 当TDD帧格式无变化时，通过其他需要重配TDD的判断接口再进行判断 */
    if(*result == 0 && NULL != p_FuncIsNeedUpdateTdd)
    {
       *result = p_FuncIsNeedUpdateTdd(g_rxTddIndCfgDif[index].uiTddCfgId);
       g_lastRxTddSwitch[index][3] = *result;
       if(*result == 1)
       {
           //coverity[cert_ctr50_cpp_violation:SUPPRESS]
           g_rxTddReCfgFlag[index] = TDD_NEED_ONLY_CFG_DLY;/*劈裂场景将标志改为更新时延标志*/
       }
       
    }
    g_lastRxTddSwitch[index][4] = *result;
    
    dbgInfo("%s groupId=%d, index=%d, result=%d\n", __FUNCTION__, groupId, index, *result);
    
    BspLog(LOG_LEVEL_0,"%s groupId=%d, index=%d, result=%d\n", __FUNCTION__, groupId, index, *result);
    
    return retVal;
}

UINT32 BspUpdateTddCfg_RRU(UINT32 groupId)
{
    UINT32 difChan = 0;
    UINT32 retVal = BSP_ERROR;
    /*T_CarrTddIndCfg tddCfg = {0};*/
    /*UINT32 *pSrc = NULL;  */
   /* UINT32 *pDest = NULL;*/
    UINT32 tddCfgId = 0;
    /*UINT32 optCfgNum = 1;*/
    UINT32 loop = 0;
    UINT32 chanMask = 0;
    UINT32 chipId = 0;
    UINT32 tddSel = 0;
    UINT32 ulGroupIndex = 0;
    UINT32 tddCfgChanMask = 0;
    T_BspHalAdaptFrTypeCfg t_FrCfg = {BSP_AIR_INTERFACE_FR_HD,BSP_AIR_INTERFACE_FR_HD,BSP_AIR_INTERFACE_FR_HD,0,0};
    UINT32 ioCtrlType = 0;

    BspLog(LOG_LEVEL_0,"%s,groupId=%d enter \n", __FUNCTION__, groupId);
    
    retVal = BspGetTddCfgIdByGrouId(groupId, &tddCfgId,&ulGroupIndex);
    dbgInfo("[%s] groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,groupId,tddCfgId,ulGroupIndex);
    if(BSP_OK != retVal)
    {
        dbgErr("%s tdd group=%d can't fine tddcfg id!\n",__FUNCTION__,groupId);
        return BSP_ERROR;
    }

    //获取通道掩码
    chanMask = g_tddIdGroupIdMap[tddCfgId][ulGroupIndex]&0xffff;
    dbgInfo("[%s] chanmask'%d\n",__FUNCTION__,chanMask);
    BspLog(LOG_LEVEL_0,"%s,tddCfgId=%d chanMask=%d ret = %d ! \n", __FUNCTION__, tddCfgId,chanMask,retVal);
    //商用版本选空口帧头
    #ifndef FUNCLIB_ADS
    /*todo：暂时屏蔽，后续放开*/
    for(loop=0;loop<BSP_HALADAPT_IC_CHAN_MAX_NUM;loop++)
    {
        if((0x1<<loop) & chanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, TX, &chipId, &difChan);
            if(BSP_OK != retVal)
            {
                dbgErr("%s BspGetDifInfoByBspChn bspChan=%d err!\n",__FUNCTION__, loop);
                return BSP_ERROR;
            }
            retVal = BspHalAdaptSetFrSelect(difChan, &t_FrCfg);
            if(BSP_OK != retVal)
            {
                dbgErr("%s BspHalAdaptSetFrSelect [difChan=%d] err!\n",__FUNCTION__, difChan);
                return BSP_ERROR;
            }
        }
    }    
    #endif

    //配置中频TDD
    if(ulTddReCfgDoneFlag[tddCfgId] == 0)
    {
        tddCfgChanMask = BspGetTddChanMaskByChanMask(chanMask);
        retVal = BspHalAdaptDifCfgTdd_TDD(&g_tddIndCfgDif[tddCfgId],tddCfgChanMask);
        if(BSP_OK != retVal)
        {
            ulTddReCfgDoneFlag[tddCfgId] = 0;
            dbgErr("%s BspHalAdaptDifCfgTdd_TDD [tddCfgId=%d] err!\n",__FUNCTION__, tddCfgId);
            BspLog(LOG_LEVEL_0,"%s,groupId=%d ret = %d dif tddcfg err! \n", __FUNCTION__, groupId,retVal);
            return BSP_ERROR;
        }
        /*维测,保存中频TDD配置*/
        DbgSaveDifTddCfg(&g_tddIndCfgDif[tddCfgId], groupId, tddCfgId);
        BspLog(LOG_LEVEL_0,"%s,groupId=%d ret = %d dif tddcfg ok! \n", __FUNCTION__, groupId,retVal);
        ulTddReCfgDoneFlag[tddCfgId] = 1;
        ioCtrlType = BspGetInitTddNum();
        if(E_INIT_TYPE_MS == ioCtrlType)
        {
            (VOID)BspSetTddCfgToFpga(0);  /*一拖三机型特殊处理*/
            (VOID)BspSetSlavePortTddCfg(0);   /*不论此时子端是否上电都需要配置，防止中途修改tdd帧结构的情况*/
            (VOID)BspSetSlavePortTddCfg(1);   /*子端单独上电需要其他流程保证*/
            (VOID)BspSetSlavePortTddCfg(2);
        }
    }


    
    //通道延时配置
    for(loop=0;loop<BSP_HALADAPT_IC_CHAN_MAX_NUM;loop++)
    {
        if((0x1<<loop) & chanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, TX, &chipId, &difChan);
            if(BSP_OK != retVal)
            {
                dbgErr("%s BspGetDifInfoByBspChn bspChan=%d err!\n",__FUNCTION__, loop);
                return BSP_ERROR;
            }
            retVal = BspHalAdaptUpdateDifChanDelay(difChan);
            if(BSP_OK != retVal)
            {
                dbgErr("%s BspHalAdaptUpdateDifChanDelay [difChan=%d] err!\n",__FUNCTION__, difChan);
                return BSP_ERROR;
            }
        }
    }
#ifndef FUNCLIB_ADS
    //todo: 待IQ控制实现后放开接口
    tddSel = g_tddIndCfgDif[tddCfgId].uiTddCfgId;

    //只配置TDDIO的时延和SPC参数
    retVal = BspUpdateTddIoVariablePara(tddSel, E_AC_TYPE_STOP);  
    //打开acctrl/ac固定att/tivalid等开关
   /* BspSetTddIoSwitchOn(tddSel);*/ /*临时屏蔽*/

    /* 如果挂接了TDD配置后处理，则进行调用 */
    if(NULL != p_FuncCalledAfterUpdateTdd)
    {
        if(p_FuncCalledAfterUpdateTdd(tddSel) != BSP_OK)
        {
            dbgErr("%s>>p_FuncCalledAfterUpdateTdd Error!\n", __FUNCTION__);
            return BSP_ERROR;
        }        
    }
#endif

    BspLog(LOG_LEVEL_0,"%s,groupId=%d finished! \n", __FUNCTION__, groupId);

    return retVal;
}

/* Started by AICoder, pid:sa812se6220908c14c73082bc0100b1ba5d37f9e */
VOID BspTranChanMask(UINT32 chanMaskTx, UINT32* chanMaskRx)
{
    if(chanMaskTx & 0xf0)
    {
        *chanMaskRx = (~chanMaskTx) & 0xf0;
    }
    else
    {
        *chanMaskRx = (~chanMaskTx) & 0x0f;
    }
}

VOID BspPrintChanMaskInfo(UINT32* tddCfgChanMaskFill, UINT32* tddCfgChanMaskRxFill, UINT32* carrNoBak)
{
    UINT32 loop = 0;

    for(loop = 0; loop < MAX_TDD_GROUP_NUM; loop++)
    {
        BspLog(LOG_LEVEL_0,"line[%d]:tddCfgChanMaskFill[%d] = %x, tddCfgChanMaskRxFill[%d] = %x, carrNoBak[%d] = %d\n",
        __LINE__, loop, tddCfgChanMaskFill[loop], loop, tddCfgChanMaskRxFill[loop], loop, carrNoBak[loop]);
    }
}
/* Ended by AICoder, pid:sa812se6220908c14c73082bc0100b1ba5d37f9e */

/* Started by AICoder, pid:73cabweb54255971489d0b4b71e1fa55220338c8 */
UINT32 BspUpdateTddCfg_NCR(UINT32 groupId)
{
    UINT32 difChan = 0;
    UINT32 difRxChan = 0;
    UINT32 retVal = BSP_ERROR;
    /*T_CarrTddIndCfg tddCfg = {0};*/
    /*UINT32 *pSrc = NULL;  */
   /* UINT32 *pDest = NULL;*/
    UINT32 tddCfgId = 0;
    /*UINT32 optCfgNum = 1;*/
    UINT32 loop = 0;
    UINT32 chanMask = 0;
    UINT32 chipId = 0;
    UINT32 tddSel = 0;
    UINT32 ulGroupIndex = 0;
    static UINT32 maskFillFlag = 0;
    UINT32 tddCfgChanMask = 0;
    UINT32 tddCfgChanMaskRx = 0;
    UINT32 uiTddCfgIdBack = 0;
    static UINT32 carrNoBak[MAX_TDD_GROUP_NUM] = {0xf,0xf,0xf,0xf};
    static UINT32 tddCfgChanMaskFill[MAX_TDD_GROUP_NUM] = {0};
    static UINT32 tddCfgChanMaskRxFill[MAX_TDD_GROUP_NUM] = {0};

    T_BspHalAdaptFrTypeCfg t_FrCfg = {BSP_CHAN_ASSOCIATED_FR_HD,BSP_AIR_INTERFACE_FR_HD,BSP_CHAN_ASSOCIATED_FR_HD,0,0};

    BspLog(LOG_LEVEL_0,"%s,groupId=%d enter \n", __FUNCTION__, groupId);
    
    retVal = BspGetTddCfgIdByGrouId(groupId, &tddCfgId,&ulGroupIndex);
    dbgInfo("[%s] groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,groupId,tddCfgId,ulGroupIndex);
    if(BSP_OK != retVal)
    {
        dbgErr("%s tdd group=%d can't fine tddcfg id!\n",__FUNCTION__,groupId);
        return BSP_ERROR;
    }

    //获取通道掩码
    chanMask = g_tddIdGroupIdMap[tddCfgId][ulGroupIndex]&0xffff;
    dbgInfo("[%s] chanmask'%d\n",__FUNCTION__,chanMask);
    BspLog(LOG_LEVEL_0,"%s,tddCfgId=%d chanMask=%d ret = %d ! \n", __FUNCTION__, tddCfgId,chanMask,retVal);
    //商用版本选空口帧头
    #ifndef FUNCLIB_ADS
    /*todo：暂时屏蔽，后续放开*/
    for(loop=0; loop < BSP_HALADAPT_IC_CHAN_MAX_NUM; loop++)
    {
        if((0x1<<loop) & chanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, TX, &chipId, &difChan);
            CHECK_RETVAL(BspGetDifInfoByBspChn, retVal);
            retVal = BspHalAdaptSetFrSelect(difChan, &t_FrCfg);
            CHECK_RETVAL(BspHalAdaptSetFrSelect, retVal);
        }
    }    
    #endif

    //配置中频TDD
    if(ulTddReCfgDoneFlag[tddCfgId] == 0)
    {
        tddCfgChanMask = BspGetTddChanMaskByChanMask(chanMask);
        BspLog(LOG_LEVEL_0,"line[%d]:g_tddIndCfgDif[%d].uiTddCfgId = %d, tddCfgChanMask = %x\n", __LINE__, tddCfgId, g_tddIndCfgDif[tddCfgId].uiTddCfgId, tddCfgChanMask);

        BspTranChanMask(tddCfgChanMask, &tddCfgChanMaskRx);

        BspPrintChanMaskInfo(tddCfgChanMaskFill, tddCfgChanMaskRxFill, carrNoBak);
        carrNoBak[g_tddIndCfgDif[tddCfgId].uiTddCfgId] = g_tddIndCfgDif[tddCfgId].uiCarrNo;
        uiTddCfgIdBack = g_tddIndCfgDif[tddCfgId].uiTddCfgId;
        retVal = BspHalAdaptDifCfgTxOrRxTdd_TDD(&g_tddIndCfgDif[tddCfgId],tddCfgChanMask,tddCfgChanMaskRxFill[g_tddIndCfgDif[tddCfgId].uiTddCfgId]);
        tddCfgChanMaskFill[g_tddIndCfgDif[tddCfgId].uiTddCfgId] = tddCfgChanMask;

        for(loop = 0; loop < BSP_HALADAPT_IC_CHAN_MAX_NUM; loop++)
        {
            if((0x1<<loop) & tddCfgChanMaskRx)
            {
                retVal = BspGetTddIdByTxChInOneLink(loop, RX, &g_tddIndCfgDif[tddCfgId].uiTddCfgId);
                CHECK_RETVAL(BspGetTddIdByTxChInOneLink, retVal);
                break;
            }
        }
        g_tddIndCfgDif[tddCfgId].uiCarrNo = carrNoBak[g_tddIndCfgDif[tddCfgId].uiTddCfgId];
        BspLog(LOG_LEVEL_0,"line[%d]:g_tddIndCfgDif[%d].uiTddCfgId = %d, tddCfgChanMaskRx = %x\n", __LINE__, tddCfgId, g_tddIndCfgDif[tddCfgId].uiTddCfgId, tddCfgChanMaskRx);
        retVal = BspHalAdaptDifCfgTxOrRxTdd_TDD(&g_tddIndCfgDif[tddCfgId],tddCfgChanMaskFill[g_tddIndCfgDif[tddCfgId].uiTddCfgId],tddCfgChanMaskRx);
        if(BSP_OK != retVal)
        {
            ulTddReCfgDoneFlag[tddCfgId] = 0;
            dbgErr("%s BspHalAdaptDifCfgTxOrRxTdd_TDD [tddCfgId=%d] err!\n",__FUNCTION__, tddCfgId);
            BspLog(LOG_LEVEL_0,"%s,groupId=%d ret = %d dif tddcfg err! \n", __FUNCTION__, groupId,retVal);
        }
        tddCfgChanMaskRxFill[g_tddIndCfgDif[tddCfgId].uiTddCfgId] = tddCfgChanMaskRx;
        BspPrintChanMaskInfo(tddCfgChanMaskFill, tddCfgChanMaskRxFill, carrNoBak);
        /*维测,保存中频TDD配置*/
        DbgSaveDifTddCfg(&g_tddIndCfgDif[tddCfgId], groupId, tddCfgId);
        BspLog(LOG_LEVEL_0,"%s,groupId=%d ret = %d dif tddcfg ok! \n", __FUNCTION__, groupId,retVal);
        ulTddReCfgDoneFlag[tddCfgId] = 1;
    }

    //通道延时配置
    for(loop=0; loop<BSP_HALADAPT_IC_CHAN_MAX_NUM; loop++)
    {
        if((0x1<<loop) & chanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, TX, &chipId, &difChan);
            CHECK_RETVAL(BspGetDifInfoByBspChn, retVal);

            retVal = BspHalAdaptUpdateTxDifChanDelay(difChan);
            CHECK_RETVAL(BspHalAdaptUpdateTxDifChanDelay, retVal);

            retVal = BspGetRxChByTxChInOneLink(difChan, TX, &difRxChan);
            CHECK_RETVAL(BspGetRxChByTxChInOneLink, retVal);

            retVal = BspHalAdaptUpdateRxDifChanDelay(difRxChan);
            CHECK_RETVAL(BspHalAdaptUpdateRxDifChanDelay, retVal);
        }
    }
#ifndef FUNCLIB_ADS

    //只配置TDDIO的时延和SPC参数
    if(maskFillFlag != 0)
    {
        g_tddIndCfgDif[tddCfgId].uiTddCfgId = 1;
        tddSel = g_tddIndCfgDif[tddCfgId].uiTddCfgId;
        retVal = BspUpdateTddIoVariablePara(tddSel, E_AC_TYPE_STOP);  
        CHECK_RETVAL(BspUpdateTddIoVariablePara, retVal);
        g_tddIndCfgDif[tddCfgId].uiTddCfgId = 2;
        tddSel = g_tddIndCfgDif[tddCfgId].uiTddCfgId;
        retVal = BspUpdateTddIoVariablePara(tddSel, E_AC_TYPE_STOP); 
        CHECK_RETVAL(BspUpdateTddIoVariablePara, retVal); 
    }
    g_tddIndCfgDif[tddCfgId].uiTddCfgId = uiTddCfgIdBack;

    //打开acctrl/ac固定att/tivalid等开关
   /* BspSetTddIoSwitchOn(tddSel);*/ /*临时屏蔽*/

    /* 如果挂接了TDD配置后处理，则进行调用 */
    if(NULL != p_FuncCalledAfterUpdateTdd)
    {
        retVal = p_FuncCalledAfterUpdateTdd(tddSel);
        CHECK_RETVAL(p_FuncCalledAfterUpdateTdd, retVal);      
    }
#endif
    maskFillFlag++;

    BspLog(LOG_LEVEL_0,"%s,groupId=%d finished! \n", __FUNCTION__, groupId);

    return retVal;
}
/* Ended by AICoder, pid:73cabweb54255971489d0b4b71e1fa55220338c8 */

/*****************************************************************************
 *  函数名称   : BspUpdateTddCfg(*)
 *  功能描述   : 通过APP的groupId更新TDD配置
 *  输入参数   : groupId:APP下发的groupId
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : APP接口
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspUpdateTddCfg(UINT32 groupId)
{
    if(IS_NCR == BspIsNcr())
    {
        return BspUpdateTddCfg_NCR(groupId);
    }
    else
    {
        return BspUpdateTddCfg_RRU(groupId);
    }
}

UINT32 BspUpdateTxTddCfg(UINT32 groupId)
{
    UINT32 difChan = 0;
    UINT32 retVal = BSP_ERROR;
    /*T_CarrTddIndCfg tddCfg = {0};*/
    /*UINT32 *pSrc = NULL;  */
   /* UINT32 *pDest = NULL;*/
    UINT32 txTddCfgId = 0;
    UINT32 rxTddCfgId = 0;
    /*UINT32 optCfgNum = 1;*/
    UINT32 loop = 0;
    UINT32 txChanMask = 0;
    UINT32 rxChanMask = 0;
    UINT32 chipId = 0;
    UINT32 tddSel = 0;
    UINT32 txGroupIndex = 0;
    UINT32 rxGroupIndex = 0;
    UINT32 txTddCfgChanMask = 0;
    UINT32 rxTddCfgChanMask = 0;
    /* 不用改 */

    BspLog(LOG_LEVEL_0,"%s,TX --> groupId=%d enter \n", __FUNCTION__, groupId);
    
    retVal = BspGetTxOrRxTddCfgIdByGrouId(groupId, &txTddCfgId, &txGroupIndex,TX);
    retVal = BspGetTxOrRxTddCfgIdByGrouId(groupId, &rxTddCfgId, &rxGroupIndex,RX);
    dbgInfo("[%s] TX -->groupId'%d txTddCfgId'%d txGroupIndex'%d\n",__FUNCTION__,groupId, txTddCfgId, txGroupIndex);
    dbgInfo("[%s] RX -->groupId'%d rxTddCfgId'%d rxGroupIndex'%d\n",__FUNCTION__,groupId, txTddCfgId, txGroupIndex);
    if(BSP_OK != retVal)
    {
        dbgErr("%s TX -->tdd group=%d can't fine tddcfg id!\n",__FUNCTION__,groupId);
        return BSP_ERROR;
    }

    //获取通道掩码
    if ((MAX_TDD_GROUP_NUM <= txTddCfgId) || ((MAX_TDD_GROUP_NUM <= rxTddCfgId))  || (MAX_GROUPID_NUM_ONE_TDD <= rxGroupIndex) || (MAX_GROUPID_NUM_ONE_TDD <= txGroupIndex) )
    {
        dbgInfo("rxTddCfgId or rxGroupIndex biger than MAX_TDD_GROUP_NUM !!!");
        return BSP_ERROR;
    }
    txChanMask = g_txTddIdGroupIdMap[txTddCfgId][txGroupIndex]&0xffff;
    rxChanMask = g_rxTddIdGroupIdMap[rxTddCfgId][rxGroupIndex]&0xffff;/* 此处获取上行掩码只是为了 BspHalAdaptDifCfgTxOrRxTdd_TDD 使用*/
    dbgInfo("[%s] TX --> txChanMask'%d rxChanMask'%d\n",__FUNCTION__,txChanMask,rxChanMask);
    BspLog(LOG_LEVEL_0,"%s,TX --> txTddCfgId=%d txChanMask=%d rxChanMask'%d ret = %d ! \n", __FUNCTION__, txTddCfgId,txChanMask,rxChanMask,retVal);
    //商用版本选空口帧头
    #ifndef FUNCLIB_ADS
    /*todo：暂时屏蔽，后续放开*/
    for(loop=0;loop<BSP_HALADAPT_IC_CHAN_MAX_NUM;loop++)
    {
        if((0x1<<loop) & txChanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, TX, &chipId, &difChan);
            BspLog(LOG_LEVEL_0,"%s,TX --> chipId=%d difChan=%d ret = %d ! \n", __FUNCTION__, chipId,difChan,retVal);
            CHECK_RETVAL(BspGetDifInfoByBspChn, retVal);
            
            retVal = BspHalAdaptSetFrSelectByDir(difChan, TX);
            BspLog(LOG_LEVEL_0,"%s,TX --> BspHalAdaptSetFrSelectByDir ret = %d ! \n", __FUNCTION__, retVal);
            CHECK_RETVAL(BspHalAdaptSetFrSelectByDir, retVal);
        }
    }    
    #endif

    //配置中频TDD
    if(g_txTddReCfgDoneFlag[txTddCfgId] == 0)
    {
        txTddCfgChanMask = BspGetTxOrRxTddChanMaskByChanMask(txChanMask,TX);
        rxTddCfgChanMask = BspGetTxOrRxTddChanMaskByChanMask(rxChanMask,RX);
        BspLog(LOG_LEVEL_0,"%s,TX --> txChanMask:%d rxChanMask:%d ! \n", __FUNCTION__, txTddCfgChanMask,rxTddCfgChanMask);
        retVal = BspHalAdaptDifCfgTxOrRxTdd_TDD(&g_txTddIndCfgDif[txTddCfgId],txTddCfgChanMask,rxTddCfgChanMask);/* 不拆，只调用一次即可 */
        if(BSP_OK != retVal)
        {
            g_txTddReCfgDoneFlag[txTddCfgId] = 0;
            dbgErr("%s TX --> BspHalAdaptDifCfgTxOrRxTdd_TDD [txTddCfgId=%d] err!\n",__FUNCTION__, txTddCfgId);
            BspLog(LOG_LEVEL_0,"%s,TX --> groupId=%d ret = %d dif tddcfg err! \n", __FUNCTION__, groupId,retVal);
            return BSP_ERROR;
        }
        /*维测,保存中频TDD配置*/
        DbgSaveDifTxOrRxTddCfg(&g_txTddIndCfgDif[txTddCfgId], groupId, txTddCfgId,TX);
        BspLog(LOG_LEVEL_0,"%s,TX --> groupId=%d ret = %d dif tddcfg ok! \n", __FUNCTION__, groupId,retVal);
        g_txTddReCfgDoneFlag[txTddCfgId] = 1;
    }


    
    //通道延时配置
    for(loop=0;loop<BSP_HALADAPT_IC_CHAN_MAX_NUM;loop++)
    {
        if((0x1<<loop) & txChanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, TX, &chipId, &difChan);
            if(BSP_OK != retVal)
            {
                dbgErr("%s TX --> BspGetDifInfoByBspChn bspChan=%d err!\n",__FUNCTION__, loop);
                return BSP_ERROR;
            }
            retVal = BspHalAdaptUpdateTxDifChanDelay(difChan);
            if(BSP_OK != retVal)
            {
                dbgErr("%s TX --> BspHalAdaptUpdateTxDifChanDelay [difChan=%d] err!\n",__FUNCTION__, difChan);
                return BSP_ERROR;
            }
        }
    }
#ifndef FUNCLIB_ADS
    //todo: 待IQ控制实现后放开接口
    tddSel = g_txTddIndCfgDif[txTddCfgId].uiTddCfgId;

    //只配置TDDIO的时延和SPC参数
    retVal = BspUpdateTddIoVariablePara(tddSel, E_AC_TYPE_STOP);  /* 刘志敬：不需要拆分 */
    //打开acctrl/ac固定att/tivalid等开关
   /* BspSetTddIoSwitchOn(tddSel);*/ /*临时屏蔽*/

    /* 如果挂接了TDD配置后处理，则进行调用 */
     //此接口是清楚是否重配时延的标志，只在上行掉一次就行了。遇到故障：复位基带板偶现上行时延没配置，原因是因为先掉的下行时延配置接口且配置成功了，
     //然后把标志置零了，所以APP就不会再配置上行时延了
    /* if(NULL != p_FuncCalledAfterUpdateTdd)  
    {
        if(p_FuncCalledAfterUpdateTdd(tddSel) != BSP_OK)// 刘志敬：不需要拆分 
        {
            dbgErr("%s>>TX --> p_FuncCalledAfterUpdateTdd Error!\n", __FUNCTION__);
            return BSP_ERROR;
        }        
    } */
#endif

    BspLog(LOG_LEVEL_0,"%s,TX --> groupId=%d finished! \n", __FUNCTION__, groupId);

    return retVal;
}

UINT32 BspUpdateRxTddCfg(UINT32 groupId)
{
    UINT32 difChan = 0;
    UINT32 retVal = BSP_ERROR;
    /*T_CarrTddIndCfg tddCfg = {0};*/
    /*UINT32 *pSrc = NULL;  */
   /* UINT32 *pDest = NULL;*/
    UINT32 rxTddCfgId = 0;
    /*UINT32 optCfgNum = 1;*/
    UINT32 loop = 0;
    UINT32 rxChanMask = 0;
    UINT32 chipId = 0;
    UINT32 tddSel = 0;
    // UINT32 txGroupIndex = 0;
    UINT32 rxGroupIndex = 0;
    // UINT32 txTddCfgChanMask = 0;
    UINT32 rxTddCfgChanMask = 0;
    /* 不用改 */

    BspLog(LOG_LEVEL_0,"%s,RX --> groupId=%d enter \n", __FUNCTION__, groupId);
    
    retVal = BspGetTxOrRxTddCfgIdByGrouId(groupId, &rxTddCfgId,&rxGroupIndex,RX);
    dbgInfo("[%s] RX -->groupId'%d tddIndex'%d GroupIndex'%d\n",__FUNCTION__,groupId,rxTddCfgId,rxGroupIndex);
    if(BSP_OK != retVal)
    {
        dbgErr("%s RX -->tdd group=%d can't fine tddcfg id!\n",__FUNCTION__,groupId);
        return BSP_ERROR;
    }

    //获取通道掩码
    if ((MAX_TDD_GROUP_NUM <= rxTddCfgId)  || (MAX_GROUPID_NUM_ONE_TDD <= rxGroupIndex))
    {
        dbgInfo("rxTddCfgId or rxGroupIndex biger than MAX_TDD_GROUP_NUM !!!");
        return BSP_ERROR;
    }
    rxChanMask = g_rxTddIdGroupIdMap[rxTddCfgId][rxGroupIndex]&0xffff;
    dbgInfo("[%s] RX --> rxChanMask'%d \n",__FUNCTION__,rxChanMask);
    BspLog(LOG_LEVEL_0,"%s,RX --> rxTddCfgId=%d rxChanMask=%d  ret = %d ! \n", __FUNCTION__, rxTddCfgId,rxChanMask,retVal);
    //商用版本选空口帧头
    #ifndef FUNCLIB_ADS
    /*todo：暂时屏蔽，后续放开*/
    for(loop=0;loop<BSP_HALADAPT_IC_CHAN_MAX_NUM;loop++)
    {
        if((0x1<<loop) & rxChanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, RX, &chipId, &difChan);
            BspLog(LOG_LEVEL_0,"%s,RX --> chipId=%d difChan=%d ret = %d ! \n", __FUNCTION__, chipId,difChan,retVal);
            CHECK_RETVAL(BspGetDifInfoByBspChn, retVal);
            
            retVal = BspHalAdaptSetFrSelectByDir(difChan, RX);
            BspLog(LOG_LEVEL_0,"%s,RX --> BspHalAdaptSetFrSelectByDir ret = %d ! \n", __FUNCTION__, retVal);
            CHECK_RETVAL(BspHalAdaptSetFrSelectByDir, retVal);
        }
    }    
    #endif

    //配置中频TDD
    if(g_rxTddReCfgDoneFlag[rxTddCfgId] == 0)
    {
        rxTddCfgChanMask = BspGetTxOrRxTddChanMaskByChanMask(rxChanMask,RX);
        BspLog(LOG_LEVEL_0,"%s,RX --> rxChanMask:%d  \n", __FUNCTION__,rxTddCfgChanMask);
        /* retVal = BspHalAdaptDifCfgTxOrRxTdd_TDD(&g_txTddIndCfgDif[txTddCfgId],txTddCfgChanMask,rxTddCfgChanMask);// 下行调用过了，上行不用再调用 
        if(BSP_OK != retVal)
        {
            g_rxTddReCfgDoneFlag[rxTddCfgId] = 0;
            dbgErr("%s RX --> BspHalAdaptDifCfgTxOrRxTdd_TDD [rxTddCfgId=%d] err!\n",__FUNCTION__, rxTddCfgId);
            BspLog(LOG_LEVEL_0,"%s,RX --> groupId=%d ret = %d dif tddcfg err! \n", __FUNCTION__, groupId,retVal);
            return BSP_ERROR;
        }*/
        /*维测,保存中频TDD配置*/
        DbgSaveDifTxOrRxTddCfg(&g_rxTddIndCfgDif[rxTddCfgId], groupId, rxTddCfgId,RX);
        BspLog(LOG_LEVEL_0,"%s,RX --> groupId=%d ret = %d dif tddcfg ok! \n", __FUNCTION__, groupId,retVal);
        g_rxTddReCfgDoneFlag[rxTddCfgId] = 1;
    }


    
    //通道延时配置
    for(loop=0;loop<BSP_HALADAPT_IC_CHAN_MAX_NUM;loop++)
    {
        if((0x1<<loop) & rxChanMask)
        {
            /* todo 上下行BSP通道和DifChan不对称时，可能会有问题，需要确认 */
            retVal = BspGetDifInfoByBspChn(loop, RX, &chipId, &difChan);
            if(BSP_OK != retVal)
            {
                dbgErr("%s RX --> BspGetDifInfoByBspChn bspChan=%d err!\n",__FUNCTION__, loop);
                return BSP_ERROR;
            }
            retVal = BspHalAdaptUpdateRxDifChanDelay(difChan);
            if(BSP_OK != retVal)
            {
                dbgErr("%s RX --> BspHalAdaptUpdateRxDifChanDelay [difChan=%d] err!\n",__FUNCTION__, difChan);
                return BSP_ERROR;
            }
        }
    }
#ifndef FUNCLIB_ADS
    //todo: 待IQ控制实现后放开接口
    tddSel = g_rxTddIndCfgDif[rxTddCfgId].uiTddCfgId;

    //只配置TDDIO的时延和SPC参数
    retVal = BspUpdateTddIoVariablePara(tddSel, E_AC_TYPE_STOP);  /* 刘志敬：不需要拆分 */
    //打开acctrl/ac固定att/tivalid等开关
   /* BspSetTddIoSwitchOn(tddSel);*/ /*临时屏蔽*/

    /* 如果挂接了TDD配置后处理，则进行调用 */
    if(NULL != p_FuncCalledAfterUpdateTdd)
    {
        if(p_FuncCalledAfterUpdateTdd(tddSel) != BSP_OK)/* 刘志敬：不需要拆分 */
        {
            dbgErr("%s>>RX --> p_FuncCalledAfterUpdateTdd Error!\n", __FUNCTION__);
            return BSP_ERROR;
        }        
    }
#endif

    BspLog(LOG_LEVEL_0,"%s,RX --> groupId=%d finished! \n", __FUNCTION__, groupId);

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetTddCfgByChan(*)
 *  功能描述   : 通过BSP通道号获取TDD配置
 *  输入参数   : bspchan:BSP通道号
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : APP接口
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 张林刚10074237@2020-12-25, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetTddCfgByChan(UINT32 bspchan, T_CarrTddIndCfg *pTddCfg)
{
    UINT32 chanmask = 0;
    UINT32 tddCfgId = 0;

    chanmask = BIT_SET(bspchan);
    tddCfgId = BspGetTddCfgIdByChanMask(chanmask);
    memcpy_s(pTddCfg, sizeof(T_CarrTddIndCfg), &s_dbgdifTddCfg[tddCfgId], sizeof(T_CarrTddIndCfg));
    return BSP_OK;
}

UINT32 BspGetTxTddCfgByChan(UINT32 bspchan, T_CarrTddIndCfg *pTddCfg)
{
    UINT32 chanmask = 0;
    UINT32 tddCfgId = 0;

    chanmask = BIT_SET(bspchan);
    tddCfgId = BspGetTxOrRxTddCfgIdByChanMask(chanmask,TX);
    ARR_BOUND_TDDCFG(tddCfgId,MAX_TDD_GROUP_NUM);
    memcpy_s(pTddCfg, sizeof(T_CarrTddIndCfg), &s_dbgdifTxTddCfg[tddCfgId], sizeof(T_CarrTddIndCfg));
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspGetChanMinStartFreqAndMaxEndFreq(*)
 *  功能描述   : 通过BSP通道号通道起始结束频点边界
 *  输入参数   : bspchan:BSP通道号
 *  输出参数   : 无
 *  返 回 值:  : BSP_OK 成功
 *            其他     失败
 *  其它说明   : APP接口
 *  工装使用申明:
 *----------------------------------------------------------------------------
 *----------------------------------------------------------------------------
 */
UINT32 BspGetChanMinStartFreqAndMaxEndFreq(UINT32 ulChan,UINT32 *ulMinTxStartFreq, UINT32 *ulMaxTxEndFreq)
{
    UINT32 ulBandId = 0;
    T_RruRfModuleInfoNew tRfModuleInfo = {0};
    UINT32 retVal = 0;
    retVal = BspGetRruRfModuleInfoNew(ulChan, &tRfModuleInfo);

    *ulMinTxStartFreq = tRfModuleInfo.ulRuTxStartFreq[0];
    *ulMaxTxEndFreq = tRfModuleInfo.ulRuTxEndFreq[0];

    for(ulBandId = 0; ulBandId < tRfModuleInfo.ulRuFreqBand; ulBandId++ )
    {
        if(*ulMinTxStartFreq > tRfModuleInfo.ulRuTxStartFreq[ulBandId])
        {
        	*ulMinTxStartFreq = tRfModuleInfo.ulRuTxStartFreq[ulBandId];
        }

        if(*ulMaxTxEndFreq < tRfModuleInfo.ulRuTxEndFreq[ulBandId])
        {
        	*ulMaxTxEndFreq = tRfModuleInfo.ulRuTxEndFreq[ulBandId];
        }
	}

    return retVal;
}

UINT32 BspGetChanTxOrRxMinStartFreqAndMaxEndFreq(UINT32 ulChan,UINT32 *ulMinStartFreq, UINT32 *ulMaxEndFreq,UINT32 dir)
{
    UINT32 bandId = 0;
    T_RruRfModuleInfoNew tRfModuleInfo = {0};
    UINT32 retVal = 0;
    UINT32 startFreqTemp;
    UINT32 endFreqTemp;
    retVal = BspGetRruRfModuleInfoNew(ulChan, &tRfModuleInfo);

    *ulMinStartFreq = (TX == dir) ? tRfModuleInfo.ulRuTxStartFreq[0]:tRfModuleInfo.ulRuRxStartFreq[0];
    *ulMaxEndFreq = (TX == dir) ? tRfModuleInfo.ulRuTxEndFreq[0]:tRfModuleInfo.ulRuRxEndFreq[0];

    for(bandId = 0; bandId < tRfModuleInfo.ulRuFreqBand; bandId++ )
    {
        ARR_BOUND_TDDCFG(bandId,BSP_MAX_BAND_NUM_PER_CH);
        startFreqTemp =  (TX == dir) ? tRfModuleInfo.ulRuTxStartFreq[bandId]:tRfModuleInfo.ulRuRxStartFreq[bandId];
        endFreqTemp =  (TX == dir) ? tRfModuleInfo.ulRuTxEndFreq[bandId]:tRfModuleInfo.ulRuRxEndFreq[bandId];

        if(*ulMinStartFreq > startFreqTemp)
        {
        	*ulMinStartFreq = startFreqTemp;
        }

        if(*ulMaxEndFreq < endFreqTemp)
        {
        	*ulMaxEndFreq = endFreqTemp;
        }
	}

    return retVal;
}

UINT32 BspGetBandInfo(T_HwFreqInfo *pHwFreqInfo)
{
    UINT32 retVal = BSP_OK;
    T_ChanGroupInfo chanGrpInfo;
    //T_RruRfModuleInfo rfModuleInfo;
   // T_RruRfModuleInfoNew rfModuleInfoNew;
    UINT32 chanGrp = 0;
    UINT32 ulTddCfgId = 0;
    UINT32 chanMask = 0;
    UINT32 chan = 0;
    UINT32 rfChan = 0;
    UINT32 ulMinTxStartFreq = 0;
    UINT32 ulMaxTxEndFreq = 0;
    INPUT_POINTER_CHECK(pHwFreqInfo);

    retVal = BspGetChanGroupInfo(&chanGrpInfo);
    CHECK_RETVAL(BspGetChanGroupInfo, retVal);

    if(chanGrpInfo.txChanGroupNum > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s error of chan group num > 4\n", __func__);
        return BSP_ERROR;
    }

    memset(pHwFreqInfo, 0, sizeof(T_HwFreqInfo));
    for(chanGrp=0; chanGrp<chanGrpInfo.txChanGroupNum;chanGrp++)
    {
        chanMask = chanGrpInfo.txChanGroupMask[chanGrp];
        for(chan=0;chan<BSP_HALADAPT_IC_CHAN_MAX_NUM;chan++)
        {
            if(chanMask & (0x1 << chan))
            {
                retVal = BspGetRfChnByBspChn(chan, TX, &rfChan);
                CHECK_RETVAL(BspGetRfChnByBspChn, retVal);

             //   BspGetRruRfModuleInfoNew(rfChan, &rfModuleInfoNew);
                ulTddCfgId = BspGetTddCfgIdByChanMask(chanMask);

                BspGetChanMinStartFreqAndMaxEndFreq(chan,&ulMinTxStartFreq,&ulMaxTxEndFreq);

                pHwFreqInfo->tOneBandInfo[pHwFreqInfo->uiBandNum].uiBandId = ulTddCfgId;
                pHwFreqInfo->tOneBandInfo[pHwFreqInfo->uiBandNum].uiStartFreq = ulMinTxStartFreq; /* KHz */
                pHwFreqInfo->tOneBandInfo[pHwFreqInfo->uiBandNum].uiEndFreq = ulMaxTxEndFreq; /* KHz */
                dbgInfoEx("%s>>, chanGrp%d,ulMinTxStartFreq%d,ulMaxTxEndFreq%d\n", __FUNCTION__,chanGrp,ulMinTxStartFreq,ulMaxTxEndFreq);
                break;
            }
        }
        if(BSP_HALADAPT_IC_CHAN_MAX_NUM == chan)
        {
            dbgErr("%s fail to find chan at chanmask\n",__func__);
            return BSP_ERROR;
        }
        pHwFreqInfo->uiBandNum++;
    }
    return BSP_OK;
}

UINT32 BspGetTxOrRxBandInfo(T_HwFreqInfo *pHwFreqInfo,UINT32 dir)
{
    UINT32 retVal = BSP_OK;
    T_ChanGroupInfo chanGrpInfo;
    //T_RruRfModuleInfo rfModuleInfo;
   // T_RruRfModuleInfoNew rfModuleInfoNew;
    UINT32 chanGrp = 0;
    UINT32 tddCfgId = 0;
    UINT32 chanMask = 0;
    UINT32 chan = 0;
    UINT32 rfChan = 0;
    UINT32 minStartFreq = 0;
    UINT32 maxEndFreq = 0;
    UINT32 groupNumTemp = 0;

    BspLog(LOG_LEVEL_0,"%s, --> dir=%d enter \n", __FUNCTION__, dir);
    INPUT_POINTER_CHECK(pHwFreqInfo);

    retVal = BspGetChanGroupInfo(&chanGrpInfo);
    CHECK_RETVAL(BspGetChanGroupInfo, retVal);

    groupNumTemp = (TX == dir) ? chanGrpInfo.txChanGroupNum : chanGrpInfo.rxChanGroupNum;

    if(groupNumTemp > MAX_TDD_GROUP_NUM)
    {
        dbgErr("%s error of chan group num > 4\n", __func__);
        return BSP_ERROR;
    }

    memset(pHwFreqInfo, 0, sizeof(T_HwFreqInfo));
    for(chanGrp=0; chanGrp<groupNumTemp;chanGrp++)
    {
        ARR_BOUND_TDDCFG(chanGrp,MAX_TDD_GROUP_NUM);
        chanMask = (TX == dir) ? chanGrpInfo.txChanGroupMask[chanGrp]:chanGrpInfo.rxChanGroupMask[chanGrp];
        for(chan=0;chan<BSP_HALADAPT_IC_CHAN_MAX_NUM;chan++)
        {
            ARR_BOUND_TDDCFG(chan,BSP_HALADAPT_IC_CHAN_MAX_NUM);
            if(chanMask & (0x1 << chan))
            {
                retVal = (TX == dir) ? BspGetRfChnByBspChn(chan, TX, &rfChan) : BspGetRfChnByBspChn(chan, RX, &rfChan);
                CHECK_RETVAL(BspGetRfChnByBspChn, retVal);

             //   BspGetRruRfModuleInfoNew(rfChan, &rfModuleInfoNew);
                tddCfgId = BspGetTxOrRxTddCfgIdByChanMask(chanMask,dir);

                BspGetChanTxOrRxMinStartFreqAndMaxEndFreq(chan,&minStartFreq,&maxEndFreq,dir);
                ARR_BOUND_TDDCFG(pHwFreqInfo->uiBandNum,MAX_TDD_GROUP_NUM);
                pHwFreqInfo->tOneBandInfo[pHwFreqInfo->uiBandNum].uiBandId = tddCfgId;
                pHwFreqInfo->tOneBandInfo[pHwFreqInfo->uiBandNum].uiStartFreq = minStartFreq; /* KHz */
                pHwFreqInfo->tOneBandInfo[pHwFreqInfo->uiBandNum].uiEndFreq = maxEndFreq; /* KHz */
                dbgInfoEx("%s>>, dir:%d chanGrp%d,minStartFreq%d,maxEndFreq%d\n", __FUNCTION__,dir,chanGrp,minStartFreq,maxEndFreq);
                BspLog(LOG_LEVEL_0,"%s, --> dir:%d chanGrp%d,minStartFreq%d,maxEndFreq%d\n", __FUNCTION__, dir,chanGrp,minStartFreq,maxEndFreq);
                break;
            }
        }
        if(BSP_HALADAPT_IC_CHAN_MAX_NUM == chan)
        {
            dbgErr("%s fail to find chan at chanmask\n",__func__);
            return BSP_ERROR;
        }
        pHwFreqInfo->uiBandNum++;
    }

    BspLog(LOG_LEVEL_0,"%s, --> dir=%d exit \n", __FUNCTION__, dir);
    return BSP_OK;
}

/*设置下行tdd  目前场景是PIM清除资源后重新配置TDD生效    清除资源是会把tdd的一部分配置复位掉，因为增量配置的原因*/
UINT32 BspSetDlTddSel(UINT32 bspChan)
{
    UINT32 retVal = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspGetDifInfoByBspChn bspChan=%d err!\n",__FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    retVal = BspHalApiSetDlTddSel(difChan);

    return retVal;
}

UINT32 BspSetUlTddSel(UINT32 bspChan)
{
    UINT32 retVal = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, RX, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("%s BspGetDifInfoByBspChn bspChan=%d err!\n",__FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    retVal = BspHalApiSetUlTddSel(difChan);

    return retVal;
}

VOID DbgPrnAppTddCfg()
{
    T_TddCfg *tddIndCfg = BspGetTddIndCfgBakMem();
    INPUT_POINTER_CHECK_RETURN(tddIndCfg);
    DbgPrnTddCfg(tddIndCfg);
}

/*获取第一个GP在的位置*/
UINT32 BspGetFirstGpByTddCfg(UINT32 tddId, UINT32 *pRadio, UINT32 *pTime)
{
    T_CarrTddIndCfg tddCfg = {0};
    UINT32 radioMode = 0;

    if(tddId >= MAX_TDD_GROUP_NUM)
    {
        return BSP_ERROR;
    }
    (VOID)BspGetTddCfgByChan(tddId, &tddCfg);
    radioMode = tddCfg.uiRadioMode;
    if((radioMode != BSP_RADIO_STANDARD_5G)&&(radioMode != BSP_RADIO_STANDARD_LTE_TDD))
    {
        return BSP_ERROR;  /*还未配置tdd 或tdd异常*/
    }
    if(BSP_RADIO_STANDARD_5G == radioMode)
    {
        *pTime = tddCfg.uiDlSymbolNum[0]*5000000/10/14;   /*nr帧结构 第一个gp在的位置*/
    }
    else
    {
        *pTime = tddCfg.uiDlSymbolNum[0]*10000000/10/14; /*lte帧结构 第一个gp在的位置*/
    }
    *pRadio = radioMode;

    return BSP_OK;
}

static UINT32 DbgSaveDifTddCfg(T_CarrTddIndCfg *pTddCfg, UINT32 groupId, UINT32 tddCfgId)
{
    if(tddCfgId >= MAX_TDD_GROUP_NUM || NULL == pTddCfg)
    {
        return BSP_ERROR;
    }

    s_dbgGroupId[tddCfgId] = groupId;
    s_dbgDifTddCfgFlag[tddCfgId] = 1;
    memcpy_s(&(s_dbgdifTddCfg[tddCfgId]), sizeof(T_CarrTddIndCfg), pTddCfg, sizeof(T_CarrTddIndCfg));

    return BSP_OK;
}

VOID DbgShowDifTddCfg(VOID)
{
    UINT32 loop = 0;
    
    dbgInfo("DIF TDD CFG is :\n");
    for(loop=0; loop<MAX_TDD_GROUP_NUM; loop++)
    {
        if(s_dbgDifTddCfgFlag[loop])
        {
            dbgInfo("Update GroupId is %d\n", s_dbgGroupId[loop]);
            ShowTddCfg(&s_dbgdifTddCfg[loop]);
            dbgInfo("\n");
        }
    }
    return;
}

UINT32 DbgShowDifTxOrRxTddCfg(UINT32 dir)
{
    UINT32 loop = 0;
    
    dbgInfo("dir:%d DIF TDD CFG is :\n",dir);
    for(loop=0; loop<MAX_TDD_GROUP_NUM; loop++)
    {
        ARR_BOUND_TDDCFG(loop,MAX_TDD_GROUP_NUM);
        if((TX == dir) && (s_dbgDifTxTddCfgFlag[loop]))
        {
            dbgInfo("Update GroupId is %d\n", s_dbgTxGroupId[loop]);
            ShowTddCfg(&s_dbgdifTxTddCfg[loop]);
            dbgInfo("\n");
        }
        else if((RX == dir) && (s_dbgDifRxTddCfgFlag[loop]))
        {
            dbgInfo("Update GroupId is %d\n", s_dbgRxGroupId[loop]);
            ShowTddCfg(&s_dbgdifRxTddCfg[loop]);
            dbgInfo("\n");
        }
    }
    return BSP_OK;
}

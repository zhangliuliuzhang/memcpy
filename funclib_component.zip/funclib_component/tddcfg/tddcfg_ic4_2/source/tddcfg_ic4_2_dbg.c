/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : tddcfg_ic3_dbg.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了tdd信号生成配置接口实现
* 注意事项 : 无
* 作    者 :   10121018
* 创建日期 : 2019-03-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"

#include "tddcfg_ic4_2.h"
#include "tddcfg_ic4_2_dbg.h"
#include "rruinfo.h"



#if 0
static T_CarrTddIndCfg s_dbgOptTddCfg[MAX_TDD_GROUP_NUM] = {0};
static UINT32 s_DbgOptTddcfgNum = 0;
#endif
extern T_CarrTddIndCfg  g_tddIndCfgOpt_Nr[MAX_TDD_GROUP_NUM];
extern T_CarrTddIndCfg  g_tddIndCfgOpt_Lte[MAX_TDD_GROUP_NUM];
extern UINT32 tddIndCfgGroupNum_Nr;
extern UINT32 tddIndCfgGroupNum_Lte;
extern UINT32 g_lastTddSwitch[MAX_TDD_GROUP_NUM][5];

#define TDDCFG_HELP_LEN (200)


UINT8 g_tddCfgHelpPrint[][TDDCFG_HELP_LEN] =
{
    "DbgPrnAppTddCfg",
    "DbgPrnFillTddCfg",
    "DbgShowDifTddCfg",
    "DbgShowOptTddCfg",
    "DbgPrnTestTddCfg",
    "showtddswitch",
    "showchangroup",
    "test_TddCfg(UINT32 groupId, UINT32 radioMode, UINT32 chanMask)",
    "[1] clearTestTddCfg",
    "[2] test_TddCfgInfo(UINT32 groupNum, UINT32 validFlag)",
    "[3] test_TddCfgGroupGroupTddInfo(UINT32 groupIndex, UINT32 groupId, UINT32 chanMask, UINT32 carrNum)",
    "[4] test_TddCfgCarrTddInfo(UINT32 groupId, UINT32 carrIndex, UINT32 carrNo, UINT32 formatType)",
    "[5] tddCfgTest",
    "[6] test_UpdateTdd groupId",
    "Test_SetNrTddFrFormat(UINT32 formatType)",
    "Test_SetLteTddFrFormat(UINT32 formatType)",
    "val - tdd frame format type",
    "0   - NR_5MS_7DS2U644",
    "1   - LTE_5MS_27",
    "2   - NR_2P5MS_3D1U1022",
    "3   - NR_3PLUS2_644",
    "4   - NR_2P5MS_SP_1D3U1022",
    "5   - NR_2P5MS_DP_1D3U1022",
    "6   - LTE_5MS_38",
};


#if 0
VOID DbgSaveOptTddCfg(T_CarrTddIndCfg *pTddCfg, UINT32 cfgNum)
{
    memcpy_s(&s_dbgOptTddCfg, sizeof(T_CarrTddIndCfg)*MAX_TDD_GROUP_NUM, pTddCfg, sizeof(T_CarrTddIndCfg)*cfgNum);
    s_DbgOptTddcfgNum = cfgNum;
}
#endif
UINT32 ShowTddCfg(T_CarrTddIndCfg *pTddCfg)
{
    UINT32 loop = 0;

    dbgInfo("----------------------------------\n");
    dbgInfo("groupId is %d\n", pTddCfg->uiGroupId);
    dbgInfo("tddCfgId is %d\n", pTddCfg->uiTddCfgId);
    dbgInfo("carrNo is %d\n", pTddCfg->uiCarrNo);
    dbgInfo("radioMode is %d\n", pTddCfg->uiRadioMode);
    dbgInfo("chanMask is %#x\n", pTddCfg->uiChanMask);
    dbgInfo("dlulSwNum is %d\n", pTddCfg->uiDlUlSwNum);

    dbgInfo("loop dlulswperiod ulsymbolNum ulsymbolNum\n");
    for(loop=0;loop<pTddCfg->uiDlUlSwNum;loop++)
    {    
    	dbgInfo("%4d %12d %11d %11d\n",loop,
        pTddCfg->uiDlUlSwPeriod[loop],
        pTddCfg->uiDlSymbolNum[loop],
        pTddCfg->uiUlSymbolNum[loop]);
    }
    dbgInfo("----------------------------------\n");
    return BSP_OK;
}


VOID DbgShowOptTddCfg(VOID)
{   
    UINT32 loop = 0;
    dbgInfo("OPT NR TDD CFG is : [GroupNum=%d]\n",tddIndCfgGroupNum_Nr);
    for(loop=0; loop<tddIndCfgGroupNum_Nr;loop++)
    {
        dbgInfo("NR TDD[%d] :\n", loop);
        ShowTddCfg(&(g_tddIndCfgOpt_Nr[loop]));
    }
    dbgInfo("OPT LTE TDD CFG is : [GroupNum=%d]\n",tddIndCfgGroupNum_Lte);
    for(loop=0; loop<tddIndCfgGroupNum_Lte;loop++)
    {
        dbgInfo("LTE TDD[%d] :\n", loop);
        ShowTddCfg(&(g_tddIndCfgOpt_Lte[loop]));
    }
}   

VOID showtddswitch(VOID)
{
    UINT32 loop = 0;
    for(loop=0; loop<MAX_TDD_GROUP_NUM; loop++)
    {
        dbgInfo("groupId =%d\n", g_lastTddSwitch[loop][0]);
        dbgInfo("ulIndex =%d\n", g_lastTddSwitch[loop][1]);    
        dbgInfo("tdd result   =%d\n", g_lastTddSwitch[loop][2]);
        dbgInfo("other result =%d\n", g_lastTddSwitch[loop][3]);
        dbgInfo("final result =%d\n", g_lastTddSwitch[loop][4]);
        dbgInfo("----------------------------------\n");
    }
    return;
}

UINT32 tddcfghelp(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    dbgInfo("Tddcfg Help:\n");

    udPrintCnt = sizeof(g_tddCfgHelpPrint) / TDDCFG_HELP_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        dbgInfo(" %s \n", g_tddCfgHelpPrint[udCnt]);
    }

    return (UINT32)BSP_OK;
}

static UINT32 s_NrTestTddFrFormat = E_TEST_TDD_CFG_NR_5MS_7DS2U644;
static UINT32 s_LteTestTddFrFormat = E_TEST_TDD_CFG_LTE_5MS_27;
static T_TddCfg *g_testTddIndCfg = NULL;

static UINT32 Test_SetNrTddFrFormat(UINT32 formatType)
{
    s_NrTestTddFrFormat = formatType;
    return s_NrTestTddFrFormat;
}
/* Started by AICoder, pid:z340ee605fq7df01471a0ab13011a119f7731139 */
UINT32 Test_SetNrTddFrFormatNoStatic(UINT32 formatType)
{
    return Test_SetNrTddFrFormat(formatType);
}
/* Ended by AICoder, pid:z340ee605fq7df01471a0ab13011a119f7731139 */
static UINT32 Test_SetLteTddFrFormat(UINT32 formatType)
{
    s_LteTestTddFrFormat = formatType;
    return s_LteTestTddFrFormat;
}

static T_CarrTddIndicateNewCfg s_testTddCfg[E_TEST_TDD_CFG_MAX] = 
{
    //NR_5MS_7DS2U644
    {
        //carrNo    //radioMode                 //dlUlSwNum
         0,         BSP_RADIO_STANDARD_5G,      1,
        //dlUlSwPeriod
        {5000,},
        //dlSymbolNum
        {104,},
        //ulSymbolNum
        {32,}
    },
    //LTE_27配比    
    {
        //carrNo    //radioMode                  //dlUlSwNum
         0,         BSP_RADIO_STANDARD_LTE_TDD,  2,
        //dlUlSwPeriod
        {3000,2000},
        //dlSymbolNum
        {24,28},
        //ulSymbolNum
        {16,0}
    },
    //NR_2P5MS_3D1U1022
    {
        //carrNo    //radioMode                 //dlUlSwNum
         0,         BSP_RADIO_STANDARD_5G,      1,
        //dlUlSwPeriod
        {2500,},
        //dlSymbolNum
        {52,},
        //ulSymbolNum
        {16,}
    },
    //NR_3PLUS2_644
    {
        //carrNo    //radioMode                 //dlUlSwNum
         0,         BSP_RADIO_STANDARD_5G,      2,
        //dlUlSwPeriod
        {3000,2000},
        //dlSymbolNum
        {48,56},
        //ulSymbolNum
        {32,0}
    },
    //NR_2P5MS_SP_1D3U1022
    {
        //carrNo    //radioMode                 //dlUlSwNum
         0,         BSP_RADIO_STANDARD_5G,      1,
        //dlUlSwPeriod
        {2500,},
        //dlSymbolNum
        {24,},
        //ulSymbolNum
        {44,}
    },    
    //NR_2P5MS_DP_1D3U1022
    {
        //carrNo    //radioMode                 //dlUlSwNum
         0,         BSP_RADIO_STANDARD_5G,      2,
        //dlUlSwPeriod
        {2500,2500},
        //dlSymbolNum
        {52,38},
        //ulSymbolNum
        {16,30}
    },
    //LTE_38配比    
    {
        //carrNo    //radioMode                  //dlUlSwNum
         0,         BSP_RADIO_STANDARD_LTE_TDD,  2,
        //dlUlSwPeriod
        {5000,5000},
        //dlSymbolNum
        {25,70},
        //ulSymbolNum
        {44,0}
    }
};

static T_TddCfg *BspGetTddCfgMem(void)
{
    if (g_testTddIndCfg == NULL)
    {
        g_testTddIndCfg = (T_TddCfg *)malloc(sizeof(T_TddCfg));
        if (g_testTddIndCfg == NULL)
        {
            return NULL;
        }
        zte_memset_s(g_testTddIndCfg, sizeof(T_TddCfg), 0, sizeof(T_TddCfg));
    }
    return g_testTddIndCfg;
}

UINT32 test_TddCfgInfo(UINT32 groupNum, UINT32 validFlag)
{
    T_TddCfg *testTddIndCfg = BspGetTddCfgMem();
    INPUT_POINTER_CHECK(testTddIndCfg);
    if(groupNum > BSP_MAX_CARR_NUM)
    {
        dbgErr("input groupNum over!");
        return BSP_ERROR;
    }
    testTddIndCfg->validFlag = validFlag;
    testTddIndCfg->groupNum  = groupNum;
    return BSP_OK;
}

UINT32 test_TddCfgGroupGroupTddInfo(UINT32 groupIndex, UINT32 groupId, UINT32 chanMask, UINT32 carrNum)
{
    T_TddCfg *testTddIndCfg = BspGetTddCfgMem();
    INPUT_POINTER_CHECK(testTddIndCfg);
    if(groupIndex >= MAX_TDD_GROUP_NUM)
    {
        dbgErr("input groupIndex over!");
        return BSP_ERROR;
    }

    if(carrNum > BSP_MAX_CARR_NUM)
    {
        dbgErr("input carrNum over!");
        return BSP_ERROR;
    }

    testTddIndCfg->tddIndicateCfg[groupIndex].groupId = groupId;
    testTddIndCfg->tddIndicateCfg[groupIndex].chanMask = chanMask;
    testTddIndCfg->tddIndicateCfg[groupIndex].carrNum = carrNum;
    return BSP_OK;
}

UINT32 test_TddCfgCarrTddInfo(UINT32 groupId, UINT32 carrIndex, UINT32 carrNo, UINT32 formatType)
{
    UINT32 loop = 0;
    T_CarrTddIndicateNewCfg *pCfg = NULL;
    T_TddCfg *testTddIndCfg = BspGetTddCfgMem();
    INPUT_POINTER_CHECK(testTddIndCfg);

    if(carrIndex >= BSP_MAX_CARR_NUM)
    {
        dbgErr("input carrIndex over!");
        return BSP_ERROR;
    }
    for(loop = 0; loop < testTddIndCfg->groupNum; loop++)
    {
        if(testTddIndCfg->tddIndicateCfg[loop].groupId == groupId)
        {
            pCfg = &(testTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrIndex]);
            memcpy_s(pCfg, sizeof(T_CarrTddIndicateNewCfg), &(s_testTddCfg[formatType]), sizeof(T_CarrTddIndicateNewCfg));
            testTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carrIndex].carrNo = carrNo;
            break;
        }
    }
    return BSP_OK;
}

UINT32 clearTestTddCfg(void)
{
    T_TddCfg *testTddIndCfg = BspGetTddCfgMem();
    INPUT_POINTER_CHECK(testTddIndCfg);
    memset_s(testTddIndCfg,sizeof(T_TddCfg),0,sizeof(T_TddCfg));
    return BSP_OK;
}
UINT32 tddCfgTest(void)
{
    T_TddCfg *testTddIndCfg = BspGetTddCfgMem();
    INPUT_POINTER_CHECK(testTddIndCfg);
    return BspSetTddCfgInfo(testTddIndCfg);
}

static VOID DbgPrnTestTddCfg(void)
{
    T_TddCfg *testTddIndCfg = BspGetTddCfgMem();
    INPUT_POINTER_CHECK_RETURN(testTddIndCfg);
    DbgPrnTddCfg(testTddIndCfg);
}
UINT32 BspGetRadioModeNum(INT32 radioMode)
{
    UINT32 ii = 0; 
    UINT32 rlen = 32;
    UINT32 rtotal = 0;
    for (ii = 0; ii < rlen; ii++)
    {
        if ((1<<ii) & radioMode)
        {
            rtotal++;
        }
    }
    return rtotal;
}

UINT32 test_TddCfg(UINT32 groupId, UINT32 radioMode, UINT32 chanMask)
{
    UINT32 retVal = BSP_OK;
    T_TddCfg *tddCfg = NULL;
    UINT32 loopGrp = 0;
    UINT32 loopCarr = 0;
    UINT32 tddSel = 0;
    T_CarrTddIndicateNewCfg *pCfg = NULL;
    UINT32 radioNum = 0;

    tddCfg = (T_TddCfg *)malloc(sizeof(T_TddCfg));
    if (tddCfg == NULL)
    {
        return BSP_ERROR;
    }
    memset(tddCfg, 0, sizeof(T_TddCfg));
    tddCfg->validFlag = 1;
    tddCfg->groupNum = 1;

    radioNum = BspGetRadioModeNum(radioMode);
    if (radioNum == 0)
    {
        free(tddCfg);
        dbgInfo("No carr radio mode config\r\n");
        return BSP_OK;
    }
    for(loopGrp=0; loopGrp<tddCfg->groupNum;loopGrp++)
    {
        tddCfg->tddIndicateCfg[loopGrp].groupId = groupId;
        tddCfg->tddIndicateCfg[loopGrp].chanMask = chanMask;
        tddCfg->tddIndicateCfg[loopGrp].carrNum = radioNum;
       
        for(loopCarr=0; loopCarr<tddCfg->tddIndicateCfg[loopGrp].carrNum; loopCarr++)
        {
            pCfg = &(tddCfg->tddIndicateCfg[loopGrp].carrTddIndicateCfg[loopCarr]);

            /* 单模NR */
            if(radioMode == 0x2000)
            {
                tddSel = s_NrTestTddFrFormat;    
            }
            /* 单模LTE */
            else if(radioMode == 0x20)
            {
                tddSel = s_LteTestTddFrFormat;
            }
            /* 混模 */
            else
            {
                /* NR */
                if(loopCarr == 0)
                {
                    tddSel = s_NrTestTddFrFormat;
                }
                /* LTE */
                else
                {
                    tddSel = s_LteTestTddFrFormat;
                }
            }

            if((IS_NCR == BspIsNcr()) && (chanMask == 0xc0))
            {
                s_testTddCfg[tddSel].carrNo = 1;
            }
            memcpy_s(pCfg, sizeof(T_CarrTddIndicateNewCfg), &(s_testTddCfg[tddSel]), sizeof(T_CarrTddIndicateNewCfg));
        }        
    }
    retVal = BspSetTddCfgInfo(tddCfg);
    if(BSP_OK != retVal)
    {
        free(tddCfg);
        return retVal;
    }
    free(tddCfg);
    return retVal;
}

UINT32 test_UpdateTdd(UINT32 groupId)
{
    UINT32 result = 0;
    UINT32 retVal = BSP_OK;
    BspGetTddSwitchResult(groupId, &result);
    dbgInfo("BspGetTddSwitchResult is %d\n", result);
    if(result == 1) 
    {
        retVal = BspUpdateTddCfg(groupId);
    }

    return retVal;
}

VOID DbgPrnTddCfg(T_TddCfg *tddIndCfg)
{
    UINT32 loop = 0;
    UINT32 carr = 0;
    UINT32 udsw = 0;
    
    dbgInfo("validFlag=%d\n",tddIndCfg->validFlag);
    dbgInfo("groupNum=%d\n", tddIndCfg->groupNum);
    dbgInfo("----------------------------------\n");
    for(loop=0; loop<tddIndCfg->groupNum; loop++)
    {
        dbgInfo("    groupId=%d\n",tddIndCfg->tddIndicateCfg[loop].groupId);
        dbgInfo("    carrNum=%d\n",tddIndCfg->tddIndicateCfg[loop].carrNum);
        dbgInfo("    chanMask=%#x\n",tddIndCfg->tddIndicateCfg[loop].chanMask);
        for(carr=0; carr<tddIndCfg->tddIndicateCfg[loop].carrNum;carr++)
        {
            dbgInfo("        carr%d\n", carr);
            dbgInfo("        carrNo=%d\n",tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].carrNo);
            dbgInfo("        radioMode=%d\n",tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].radioMode);
            dbgInfo("        dlUlSwNum=%d\n",tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwNum);
            for(udsw=0;udsw<tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwNum;udsw++)
            {
                dbgInfo("            sw%d\n",udsw);
                dbgInfo("            dlUlSwPeriod=%d\n",tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwPeriod[udsw]);
                dbgInfo("            dlSymbolNum=%d\n",tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlSymbolNum[udsw]);
                dbgInfo("            ulSymbolNum=%d\n",tddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].ulSymbolNum[udsw]);
            }
        }
        dbgInfo("----------------------------------\n");
    }
    
    return;
}

VOID DbgPrnTxTddCfg(T_TxTddCfg *txTddIndCfg)
{
    UINT32 loop = 0;
    UINT32 carr = 0;
    UINT32 udsw = 0;
    
    dbgInfo("-------------------------->> Tx Tdd Cfg Info ! <<--------------------------\n");
    dbgInfo("validFlag=%d\n",txTddIndCfg->validFlag);
    dbgInfo("groupNum=%d\n", txTddIndCfg->groupNum);
    dbgInfo("----------------------------------\n");
    for(loop=0; loop<txTddIndCfg->groupNum; loop++)
    {
        dbgInfo("    groupId=%d\n",txTddIndCfg->tddIndicateCfg[loop].groupId);
        dbgInfo("    carrNum=%d\n",txTddIndCfg->tddIndicateCfg[loop].carrNum);
        dbgInfo("    chanMask=%#x\n",txTddIndCfg->tddIndicateCfg[loop].chanMask);
        for(carr=0; carr<txTddIndCfg->tddIndicateCfg[loop].carrNum;carr++)
        {
            dbgInfo("        carr%d\n", carr);
            dbgInfo("        carrNo=%d\n",txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].carrNo);
            dbgInfo("        radioMode=%d\n",txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].radioMode);
            dbgInfo("        dlUlSwNum=%d\n",txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwNum);
            for(udsw=0;udsw<txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwNum;udsw++)
            {
                dbgInfo("            sw%d\n",udsw);
                dbgInfo("            dlUlSwPeriod=%d\n",txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwPeriod[udsw]);
                dbgInfo("            dlSymbolNum=%d\n",txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlSymbolNum[udsw]);
                dbgInfo("            ulSymbolNum=%d\n",txTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].ulSymbolNum[udsw]);
            }
        }
        dbgInfo("----------------------------------\n");
    }
    
    return;
}

VOID DbgPrnRxTddCfg(T_RxTddCfg *rxTddIndCfg)
{
    UINT32 loop = 0;
    UINT32 carr = 0;
    UINT32 udsw = 0;
    
    dbgInfo("-------------------------->> Rx Tdd Cfg Info ! <<--------------------------\n");
    dbgInfo("validFlag=%d\n",rxTddIndCfg->validFlag);
    dbgInfo("groupNum=%d\n", rxTddIndCfg->groupNum);
    dbgInfo("----------------------------------\n");
    for(loop=0; loop<rxTddIndCfg->groupNum; loop++)
    {
        dbgInfo("    groupId=%d\n",rxTddIndCfg->tddIndicateCfg[loop].groupId);
        dbgInfo("    carrNum=%d\n",rxTddIndCfg->tddIndicateCfg[loop].carrNum);
        dbgInfo("    chanMask=%#x\n",rxTddIndCfg->tddIndicateCfg[loop].chanMask);
        for(carr=0; carr<rxTddIndCfg->tddIndicateCfg[loop].carrNum;carr++)
        {
            dbgInfo("        carr%d\n", carr);
            dbgInfo("        carrNo=%d\n",rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].carrNo);
            dbgInfo("        radioMode=%d\n",rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].radioMode);
            dbgInfo("        dlUlSwNum=%d\n",rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwNum);
            for(udsw=0;udsw<rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwNum;udsw++)
            {
                dbgInfo("            sw%d\n",udsw);
                dbgInfo("            dlUlSwPeriod=%d\n",rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlUlSwPeriod[udsw]);
                dbgInfo("            dlSymbolNum=%d\n",rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].dlSymbolNum[udsw]);
                dbgInfo("            ulSymbolNum=%d\n",rxTddIndCfg->tddIndicateCfg[loop].carrTddIndicateCfg[carr].ulSymbolNum[udsw]);
            }
        }
        dbgInfo("----------------------------------\n");
    }
    
    return;
}


UINT32 TestGetTddIndicateNewCfg(E_TestTddFrFormatType frFormatType, T_CarrTddIndicateNewCfg *pCfg)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCfg);
    if(frFormatType < E_TEST_TDD_CFG_MAX)
    {
        memcpy_s(pCfg, sizeof(T_CarrTddIndicateNewCfg), &(s_testTddCfg[frFormatType]), sizeof(T_CarrTddIndicateNewCfg));
    }
    else
    {
        retVal = BSP_ERROR;
    }

    return retVal;
}

VOID showchangroup(VOID)
{
    UINT32 retVal = BSP_OK;
    T_ChanGroupInfo chanGrpInfo;
    UINT32 group = 0;

    retVal = BspGetChanGroupInfo(&chanGrpInfo);
    if(BSP_OK != retVal)
    {
        dbgErr("BspGetChanGroupInfo err\n");
        return;
    }

    dbgInfo("Tx chan group num = %d\n",chanGrpInfo.txChanGroupNum);
    for(group=0; group<MAX_TDD_GROUP_NUM; group++)
    {
        dbgInfo("[Group%d] chanmask = %#x\n", group, chanGrpInfo.txChanGroupMask[group]);       
    }    
    dbgInfo("Rx chan group num = %d\n",chanGrpInfo.rxChanGroupNum);
    for(group=0; group<MAX_TDD_GROUP_NUM; group++)
    {
        dbgInfo("[Group%d] chanmask = %#x\n", group, chanGrpInfo.rxChanGroupMask[group]);       
    }

    return;
}






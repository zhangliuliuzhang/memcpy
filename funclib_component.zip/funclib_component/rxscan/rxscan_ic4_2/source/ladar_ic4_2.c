/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : ladar_ic4_2.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供雷达扫描控制接口
 * 注意事项 : 无
 * 作    者 :
 * 创建日期 : 2023-8-6 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "rxscanapi.h"
#include "ladar_ic4_2.h"
#include <math.h>
#include "ichaladapt_ic4_2.h"
#include "ru_univdef.h"
#include "rxscan_ic4_2.h"
#include "freqcfgcommon.h"
#include "pa_ic4_2_ctrl.h"
#include "fft.h"
#include "fftwin.h"
#include "devdrv_att.h"
#include "powerctrl_comps_ic4_2.h"
#include "secure_func.h"
#include "chnmapapi.h"
#include "funccommon_log.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define SAMPLE_NUM_MAX             ((UINT32)(16384))
#define SAMPLE_TIME_MAX            ((UINT32)(5))
#define FO_DDC_KHZ                 ((INT32)(-117856))
#define FS_ADC_KHZ                 ((UINT32)(386640))
#define FFT_NUM                    ((UINT32)(4096))
#define START_INDEX                ((UINT32)(1372))
#define START_FREQ                 ((UINT32)(930000))
#define INDEX_MAX                  ((UINT32)(2716))
#define EXTRACT_MULTIPLE           ((UINT32)(4))
#define POW_INTEGRAL_NUM           ((UINT32)(168))
#define POW_STEP_KHZ               ((UINT32)(180))
#define POW_MERGE_STEP             ((UINT32)(8))
#define TXPOW_DEF                  ((UINT16)(20))

#define  AC_STOP   ((UINT32)(0))
#define  AC_DL     ((UINT32)(1))

#define  SPT_OK    ((UINT8)(0))
#define  SPT_ALM   ((UINT8)(1))

#define  FILE_NAME_MAX    ((UINT32)(40))
#define  BUFF_SIZE_MAX    ((UINT32)(32))
#define  FULL_SCAL_16BIT  ((DOUBLE)(16255.6)) /* 16255.6 = 2000.0*log(4096) + 1000.0* log10(pow(2.0,2*(15))) */

#define END_FREQ ((UINT32)(960000))
#define MIN_LEN ((UINT32)(2))
#define SPT_MEAN_LEN ((UINT32)(10))
#define STEP_KHZ ((DOUBLE)(180.0))
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef struct T_RxCarrInfo
{
    UINT32    carrNo;
    UINT32    carrMode;
    UINT32    rxCoef;
}T_RxCarrInfo;

typedef struct T_RxCarrInfoBackup
{
    UINT32    carrNum;
    T_RxCarrInfo carrInfo[BSP_MAX_CARR_NUM];
}T_RxCarrBackup;

typedef struct T_LadarAlmInfo
{
    UINT16    subBandIdx;
    UINT16    externTxPow;
    UINT8     avgAlmFlag;
    UINT8     maxAlmFlag;
    UINT16    avgThrod;
    UINT16    maxThrod;
}T_LadarAlmInfo;

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static DOUBLE s_Fft_RealTmp[SAMPLE_TIME_MAX][FFT_NUM] ={0};
static DOUBLE s_Fft_ImagTmp[SAMPLE_TIME_MAX][FFT_NUM] ={0};

static DOUBLE s_fft_In_I[FFT_NUM] = {0.0};  /* FFT输入单组数据实部 */
static DOUBLE s_fft_In_Q[FFT_NUM] = {0.0};  /* FFT输入单组数据虚部 */

static FLOAT  s_fftWeight1[FFT_NUM]={0.0};
static FLOAT  s_fftWeight2[FFT_NUM]={0.0};
static INT16  s_fftCoef2[FFT_NUM]={0};

static DOUBLE s_fft_Out_I[FFT_NUM] = {0.0}; /* FFT输出单组数据实部 */
static DOUBLE s_fft_Out_Q[FFT_NUM] = {0.0}; /* FFT输出单组数据虚部 */

static DOUBLE s_fft_Pow[SAMPLE_TIME_MAX][FFT_NUM]  = {0};

static DOUBLE s_PowMax[FFT_NUM]  = {0.0};
static DOUBLE s_PowAvg[FFT_NUM]  = {0.0};

static INT32 s_PowMaxMergeDbm[POW_INTEGRAL_NUM]  = {0};
static INT32 s_PowAvgMergeDbm[POW_INTEGRAL_NUM]  = {0};

static UINT16 s_sptMax[POW_INTEGRAL_NUM] = {0};
static UINT16 s_sptAvg[POW_INTEGRAL_NUM] = {0};

static INT16 s_sptAvgSort[POW_INTEGRAL_NUM] = {0};

static T_LadarAlmInfo  s_ladarAlmInfo[POW_INTEGRAL_NUM] = {0};

static T_RxCarrBackup  s_rxCarrBackup[MAX_RX_CHAN] = {0};
static INT32  s_rxatt[MAX_RX_CHAN] = {0};

static T_BspLadarPara  s_ladarPara = {0};
static BOOL s_ladarSupport = FALSE;
static BOOL s_sampleSave = FALSE;

double ladarFilterCoef[]=
{
  0.0000147921 ,
  0.000128302  ,
  0.000185671  ,
  0.000218486  ,
  0.000136136  ,
  -0.0000958391,
  -0.000450051 ,
  -0.000808833 ,
  -0.000981087 ,
  -0.000768328 ,
  -0.0000674167,
  0.00102932   ,
  0.00219014   ,
  0.00290159   ,
  0.00263961   ,
  0.00111295   ,
  -0.00151081  ,
  -0.00450959  ,
  -0.0067294   ,
  -0.00694216  ,
  -0.00435302  ,
  0.000916552  ,
  0.00758583   ,
  0.0133814    ,
  0.0156588    ,
  0.0123516    ,
  0.0029578    ,
  -0.0108009   ,
  -0.0249651   ,
  -0.0341088   ,
  -0.0327727   ,
  -0.0171843   ,
  0.0132669    ,
  0.0553139    ,
  0.102177     ,
  0.145002     ,
  0.175017     ,
  0.185806     ,
  0.175017     ,
  0.145002     ,
  0.102177     ,
  0.0553139    ,
  0.0132669    ,
  -0.0171843   ,
  -0.0327727   ,
  -0.0341088   ,
  -0.0249651   ,
  -0.0108009   ,
  0.0029578    ,
  0.0123516    ,
  0.0156588    ,
  0.0133814    ,
  0.00758583   ,
  0.000916552  ,
  -0.00435302  ,
  -0.00694216  ,
  -0.0067294   ,
  -0.00450959  ,
  -0.00151081  ,
  0.00111295   ,
  0.00263961   ,
  0.00290159   ,
  0.00219014   ,
  0.00102932   ,
  -0.0000674167,
  -0.000768328 ,
  -0.000981087 ,
  -0.000808833 ,
  -0.000450051 ,
  -0.0000958391,
  0.000136136  ,
  0.000218486  ,
  0.000185671  ,
  0.000128302  ,
  0.0000147921 ,
};
static UINT32 s_filterLen = NELEMENTS(ladarFilterCoef);
/**************************************************************************
 *                         函数实现
 **************************************************************************/
UINT32 BspGetLadarFreqScanChanType(VOID)
{
    return AC_CHAN_TYPE;
}

VOID BspLadarSetSupport(BOOL isSupport)
{
    s_ladarSupport = isSupport;
}

BOOL BspIsSupportLadar(VOID)
{
    return s_ladarSupport;
}

VOID BspLadarSetSampleSave(BOOL isEnable)
{
    s_sampleSave = isEnable;
}

UINT32 BspLadarGetRxBspChan(VOID)
{
    return 0;
}

UINT32 BspLadarSetRxCoefZero(UINT32 bspChan)
{
    UINT32 difChipId = 0;
    UINT32 difChan = 0;
    UINT32 carrIdx = 0;
    UINT32 carrNo = 0;
    UINT32 carrMode = 0;
    UINT32 rxCoef = 0;
    T_RfCfgPara *pRfCfgPara = NULL;

    if (bspChan >= MAX_RX_CHAN)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != BspGetDifInfoByRfChn(bspChan, RX, &difChipId, &difChan))
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d,%d,%d) return error\n", __FUNCTION__, bspChan, difChipId, difChan);
        return BSP_ERROR;
    }

    pRfCfgPara = (T_RfCfgPara *)BspGetRfCfgPara(bspChan, RX);
    if (NULL == pRfCfgPara)
    {
        dbgErr("[%s]Chan %d Rx No CarrPara\n", __func__ , bspChan);
        return BSP_OK;
    }

    memset_s(&s_rxCarrBackup[bspChan], sizeof(T_RxCarrBackup), 0, sizeof(T_RxCarrBackup));

    for (carrIdx = 0 ; ((carrIdx < pRfCfgPara->carrNum) && (carrIdx < BSP_MAX_CARR_NUM)) ; carrIdx++)
    {
        carrNo = pRfCfgPara->carrInfo[carrIdx].carrNo;
        carrMode = pRfCfgPara->carrInfo[carrIdx].radioMode;
        BspHalAdaptGetUlbankAptuneCoef(difChan, carrNo, carrMode, &rxCoef);
        s_rxCarrBackup[bspChan].carrInfo[carrIdx].carrNo = carrNo;
        s_rxCarrBackup[bspChan].carrInfo[carrIdx].carrMode = carrMode;
        s_rxCarrBackup[bspChan].carrInfo[carrIdx].rxCoef = rxCoef;
        BspHalAdaptSetUlbankAptuneCoef(difChan, carrNo, carrMode, 0);
    }
    s_rxCarrBackup[bspChan].carrNum = carrIdx;
    return BSP_OK;
}

VOID showrxcarrinfo(UINT32 bspRxChan)
{
    UINT32 carrNum = 0;
    UINT32 carrIdx = 0;
    UINT32 carrNo = 0;
    UINT32 carrMode = 0;
    UINT32 rxCoef = 0;

    if (bspRxChan >= MAX_RX_CHAN)
    {
        return;
    }

    carrNum = s_rxCarrBackup[bspRxChan].carrNum;
    dbgPrn("Rx%u, CarrNum=%u\n", bspRxChan, carrNum);

    for (carrIdx = 0 ; ((carrIdx < carrNum) && (carrIdx < BSP_MAX_CARR_NUM)) ; carrIdx++)
    {
        carrNo = s_rxCarrBackup[bspRxChan].carrInfo[carrIdx].carrNo;
        carrMode = s_rxCarrBackup[bspRxChan].carrInfo[carrIdx].carrMode;
        rxCoef = s_rxCarrBackup[bspRxChan].carrInfo[carrIdx].rxCoef;
        dbgPrn("carrIdx%u,carrNo=%u,carrMode=%u,rxCoef=%u\n", carrIdx, carrNo, carrMode, rxCoef);
    }
}

UINT32 BspLadarRecoverRxCoef(UINT32 bspChan)
{
    UINT32 difChipId = 0;
    UINT32 difChan = 0;
    UINT32 carrIdx = 0;
    UINT32 carrNo = 0;
    UINT32 carrMode = 0;
    UINT32 rxCoef = 0;

    if (bspChan >= MAX_RX_CHAN)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != BspGetDifInfoByRfChn(bspChan, RX, &difChipId, &difChan))
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d,%d,%d) return error\n", __FUNCTION__, bspChan, difChipId, difChan);
        return BSP_ERROR;
    }

    for (carrIdx = 0 ; ((carrIdx < s_rxCarrBackup[bspChan].carrNum) && (carrIdx < BSP_MAX_CARR_NUM)) ; carrIdx++)
    {
        carrNo = s_rxCarrBackup[bspChan].carrInfo[carrIdx].carrNo;
        carrMode = s_rxCarrBackup[bspChan].carrInfo[carrIdx].carrMode;
        rxCoef = s_rxCarrBackup[bspChan].carrInfo[carrIdx].rxCoef;
        BspHalAdaptSetUlbankAptuneCoef(difChan, carrNo, carrMode, rxCoef);
    }

    return BSP_OK;
}

#define RXATT_SCAN     ((INT32)(-2400))
UINT32 BspLadarSetRxAtt(UINT32 bspChan, UINT32 mode)
{
    INT32 attVal = 0;
    UINT32 difChipId = 0;
    UINT32 difChan = 0;

    if (bspChan >= MAX_RX_CHAN)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != BspGetDifInfoByRfChn(bspChan, RX, &difChipId, &difChan))
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d,%d,%d) return error\n", __FUNCTION__, bspChan, difChipId, difChan);
        return BSP_ERROR;
    }

    if (mode == MGC_MODE_MANUAL)  /* 切手动模式*/
    {
        attVal = RXATT_SCAN;
        dbgInfo("%s>>RxAtt = %d, rxChan = %d\n", __FUNCTION__,attVal, bspChan);
        s_rxatt[bspChan] = attVal;

        BspHalAdaptSetVgaModeByChan(difChan, MGC_MODE_MANUAL);
        BspHalAdaptSetManualVga(difChan, abs(attVal)/50);
    }
    else if (mode == MGC_MODE_MGC) /*切回MGC模式*/
    {
        BspHalAdaptSetVgaModeByChan(difChan, MGC_MODE_MGC);
    }

    return BSP_OK;
}

UINT32 BspLadarSetAcSwitch(UINT32 type)
{
    UINT32 retVal = 0;
    retVal |= BspSetAcCtrlModeCtrl(0 , SWITCH_FDD_CTRL_MODE);

    if (type == AC_STOP)
    {
        retVal |= BspSetAcCtrlSwitchCtrl(AC1_CTRL_RX_SW, AC_CTRL_SWITCH_OFF);
        retVal |= BspSetAcCtrlSwitchCtrl(AC1_CTRL_CAL_SW, AC_CTRL_SWITCH_OFF);
    }
    else if (type == AC_DL)
    {
        retVal |= BspSetAcCtrlSwitchCtrl(AC1_CTRL_RX_SW, AC_CTRL_SWITCH_ON);
        retVal |= BspSetAcCtrlSwitchCtrl(AC1_CTRL_CAL_SW, AC_CTRL_SWITCH_ON);
    }
    else
    {
        dbgErr("[%s] input para error,type=%d!\n",__func__,type);
        return BSP_ERROR;
    }

    return retVal;
}

UINT32 BspLadarGetAlmInfo(UINT32 freqKHz, T_LadarAlmInfo *pAlmInfo)
{
    UINT32  subBandNum  = 0;
    UINT16  subBandIdx = 0;
    UINT32  startFreq = 0;
    UINT32  endFreq = 0;

    INPUT_POINTER_CHECK(pAlmInfo);

    subBandNum = s_ladarPara.subBandNum;
    for (subBandIdx = 0; ((subBandIdx < subBandNum) && (subBandIdx < LADAR_SUB_BAND_MAX)); subBandIdx++)
    {
        startFreq = s_ladarPara.subBandStartFreq[subBandIdx];
        endFreq = s_ladarPara.subBandEndFreq[subBandIdx];
        if ((freqKHz >= startFreq) && (freqKHz < endFreq))
        {
            pAlmInfo->subBandIdx = subBandIdx;
            pAlmInfo->avgThrod = s_ladarPara.subBandAvgThrod[subBandIdx];
            pAlmInfo->maxThrod = s_ladarPara.subBandMaxThrod[subBandIdx];
            pAlmInfo->externTxPow = s_ladarPara.subBandExternTxPwr[subBandIdx];
            pAlmInfo->avgAlmFlag = SPT_OK;
            pAlmInfo->maxAlmFlag = SPT_OK;
            return BSP_OK;
        }
    }

    pAlmInfo->subBandIdx = 0;
    pAlmInfo->avgThrod = 0;
    pAlmInfo->maxThrod = 0;
    pAlmInfo->externTxPow = TXPOW_DEF;
    pAlmInfo->avgAlmFlag = SPT_OK;
    pAlmInfo->maxAlmFlag = SPT_OK;
    return BSP_OK;
}

UINT32 BspLadarSetPara(T_BspLadarPara *pLadarPara)
{
    UINT32 index = 0;
    UINT32 freqKHz = 0;

    INPUT_POINTER_CHECK(pLadarPara);

    memcpy_s((void *)&s_ladarPara, sizeof(T_BspLadarPara), (void *)pLadarPara, sizeof(T_BspLadarPara));

    for(index = 0; index < POW_INTEGRAL_NUM; index++)
    {
        freqKHz = START_FREQ + index * POW_STEP_KHZ;
        BspLadarGetAlmInfo(freqKHz, &s_ladarAlmInfo[index]);
    }

    return BSP_OK;
}

UINT32 BspLadarGetPara(T_BspLadarPara *pLadarPara)
{
    INPUT_POINTER_CHECK(pLadarPara);

    memcpy_s((void *)pLadarPara, sizeof(T_BspLadarPara), (void *)&s_ladarPara, sizeof(T_BspLadarPara));

    return BSP_OK;
}

VOID BspLadarPrnPara(VOID)
{
    UINT16  subBandNum  = 0;
    UINT16  subBandIdx = 0;

    subBandNum = s_ladarPara.subBandNum;
    dbgPrn("Ladar Scan Para subBandNum=%u\n", subBandNum);

    for (subBandIdx = 0; ((subBandIdx < subBandNum) && (subBandIdx < LADAR_SUB_BAND_MAX)); subBandIdx++)
    {
        dbgPrn("subBand%u\n", subBandIdx);
        dbgPrn("StartFreq=%u(KHz),", s_ladarPara.subBandStartFreq[subBandIdx]);
        dbgPrn("EndFreq=%u(KHz),", s_ladarPara.subBandEndFreq[subBandIdx]);
        dbgPrn("AvgThrod=%u(0.01dB),", s_ladarPara.subBandAvgThrod[subBandIdx]);
        dbgPrn("MaxThrod=%u(0.01dB),", s_ladarPara.subBandMaxThrod[subBandIdx]);
        dbgPrn("ExternTxPwr=%u(W)\n", s_ladarPara.subBandExternTxPwr[subBandIdx]);
    }
}

VOID BspLadarPrnAlm(VOID)
{
    UINT32 index = 0;
    UINT32 freqKHz = 0;

    dbgPrn("index,freqKHz,subBandIdx,TxPow(W),sptAvg(0.01dB),sptMax(0.01dB),sptAvgSort(0.01dB),powAvgMerge(0.01dBm),powMaxMerge(0.01dBm),avgThrod(0.01dB),maxThrod(0.01dB),avgAlm,maxAlm\n");
    for (index = 0; index < POW_INTEGRAL_NUM; index++)
    {
        freqKHz = START_FREQ + index * POW_STEP_KHZ;
        dbgPrn("%-3u,%-6u,%u,%u,%u,%u,%u,%d,%d,%u,%u,%u,%u\n", index, freqKHz, s_ladarAlmInfo[index].subBandIdx, s_ladarAlmInfo[index].externTxPow, s_sptAvg[index], s_sptMax[index], s_sptAvgSort[index],
               s_PowAvgMergeDbm[index], s_PowMaxMergeDbm[index], s_ladarAlmInfo[index].avgThrod, s_ladarAlmInfo[index].maxThrod, s_ladarAlmInfo[index].avgAlmFlag, s_ladarAlmInfo[index].maxAlmFlag);
    }
}

VOID prnladar(VOID)
{
    BspLadarPrnPara();
    BspLadarPrnAlm();
}

UINT32 BspSampleDateFileUINT(UINT32 *pData, CHAR *pFileNameI, CHAR *pFileNameQ, UINT32 point)
{
    FILE *finFileI = NULL;
    FILE *finFileQ = NULL;
    UINT32 pointLoop = 0;
    INT32  fprtRet = 0;
    INT32  fclsRet = 0;
    UINT16  real = 0;
    UINT16  imag = 0;
    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pFileNameI);
    INPUT_POINTER_CHECK(pFileNameQ);

    finFileI = fopen(pFileNameI, "w+");
    if (NULL == finFileI)
    {
        return BSP_ERROR;
    }

    finFileQ = fopen(pFileNameQ, "w+");
    if (NULL == finFileQ)
    {
        (VOID)fclose(finFileI);
        return BSP_ERROR;
    }

    for (pointLoop = 0; pointLoop < point; pointLoop++)
    {
        real = (UINT16)((pData[pointLoop] >> (UINT16)16) & (UINT16)0xFFFF);
        imag = (UINT16)(pData[pointLoop] & (UINT16)0xFFFF);
        fprtRet = fprintf(finFileI, "0x%04x\n", real);
        FPRINTF_CHECK(fprtRet);
        fprtRet = fprintf(finFileQ, "0x%04x\n", imag);
        FPRINTF_CHECK(fprtRet);
    }
    fclsRet = fclose(finFileI);
    FCLOSE_CHECK(fclsRet);

    fclsRet = fclose(finFileQ);
    FCLOSE_CHECK(fclsRet);
    return BSP_OK;
}

UINT32 BspSampleDateFileDouble(DOUBLE *pData, CHAR *pFileName ,UINT32 point)
{
    FILE *finFile = NULL;
    UINT32 pointLoop = 0;
    INT32 fprtRet = 0;
    INT32 fclsRet = 0;
    INT16 integer = 0;

    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pFileName);

    finFile = fopen(pFileName, "w+");
    if (NULL == finFile)
    {
        return BSP_ERROR;
    }

    for (pointLoop = 0; pointLoop < point; pointLoop++)
    {
        integer = (INT16)(pData[pointLoop]);
        fprtRet = fprintf(finFile, "0x%04hx\n", integer);
        FPRINTF_CHECK(fprtRet);
    }
    fclsRet = fclose(finFile);
    FCLOSE_CHECK(fclsRet);
    return BSP_OK;
}

UINT32 BspSampleSave(CHAR *pFileName, UINT32 sampleTime, UINT32 *pData, UINT32 point)
{
    UINT32 ret = BSP_OK;
    CHAR fileNameI[FILE_NAME_MAX] = {0};
    CHAR fileNameQ[FILE_NAME_MAX] = {0};
    INT32  snpRet = 0;

    INPUT_POINTER_CHECK(pData);

    if (!s_sampleSave)
    {
        return BSP_OK;
    }

    snpRet = snprintf_s(fileNameI, sizeof(fileNameI), "%s_%d_I.txt", pFileName, sampleTime);
    SNPRINTF_S_CHECK(snpRet, FILE_NAME_MAX);

    snpRet = snprintf_s(fileNameQ, sizeof(fileNameQ), "%s_%d_Q.txt", pFileName, sampleTime);
    SNPRINTF_S_CHECK(snpRet, FILE_NAME_MAX);

    ret = BspSampleDateFileUINT(pData, fileNameI, fileNameQ, point);
    return ret;
}

UINT32 BspDoubleSampleSave(CHAR *pFileName, UINT32 sampleTime, DOUBLE *pDataI, DOUBLE *pDataQ, UINT32 point)
{
    UINT32 ret = BSP_OK;
    CHAR fileName[FILE_NAME_MAX] = {0};
    INT32  snpRet = 0;

    INPUT_POINTER_CHECK(pDataI);
    INPUT_POINTER_CHECK(pDataQ);

    if (!s_sampleSave)
    {
        return BSP_OK;
    }

    snpRet = snprintf_s(fileName, sizeof(fileName), "%s_%d_I.txt", pFileName, sampleTime);
    SNPRINTF_S_CHECK(snpRet, FILE_NAME_MAX);

    ret = BspSampleDateFileDouble(pDataI, fileName, point);

    snpRet = snprintf_s(fileName, sizeof(fileName), "%s_%d_Q.txt", pFileName, sampleTime);
    SNPRINTF_S_CHECK(snpRet, FILE_NAME_MAX);

    ret |= BspSampleDateFileDouble(pDataQ, fileName, point);
    return ret;
}

/*****************************************************************************
*  函数名称   : BspLadarMoveNco
*  功能描述   : 移频
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : samplePoint -- 采数点数
*            : pSampleData -- 输入数据,限制在一组16384采数内部
*  输出参数   : pRealOutData -- 输出数据实部
               pImagOutData -- 输出数据虚部
*  返 回 值   : BSP_OK或错误码
*  其它说明   :NCO计算公式为   y(n) = x(n) .* exp(j*2*pi*fo/fs*n)
               经过转化后为    y(n) = x(n)*(cos(Qn)+jSin(Qn))
            Qn  = 2*pi*fo/fs*n
           X(n) = (I+jQ)
           Y(n) = (I+jQ)*(cos(Qn)+jSin(Qn)) = (I*cos(Qn)-Q*Sin(Qn))+j(I*sin(Qn)+Q*cos(Qn))
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BspLadarMoveNco(UINT32 samplePoint, UINT32 *pSampleData, DOUBLE *pRealOutData, DOUBLE *pImagOutData)
{
    DOUBLE realTemp = 0.0;
    DOUBLE imagTemp = 0.0;
    INT16  real = 0;
    INT16  imag = 0;
    UINT32 pointLoop = 0;
    DOUBLE dQn          = 0.0;
    DOUBLE dQnRadian    = 0.0;
    DOUBLE *pReal       = NULL;
    DOUBLE *pImag          = NULL;
    INT32  dpdicFo      = FO_DDC_KHZ;
    INT32  dpdicFs      = FS_ADC_KHZ;
    double tempsin = 0.0;
    double tempcos = 0.0;

    INPUT_POINTER_CHECK(pSampleData);
    INPUT_POINTER_CHECK(pRealOutData);
    INPUT_POINTER_CHECK(pImagOutData);

    dbgInfo("%s, Fo=%dKHz, samplePoint=%u\n", __FUNCTION__, dpdicFo, samplePoint);

    pReal  = (DOUBLE*)malloc(sizeof(DOUBLE)*samplePoint);
    if(pReal == NULL)
    {
        free(pReal);
        dbgInfo("[%s] malloc failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    pImag  = (DOUBLE*)malloc(sizeof(DOUBLE)*samplePoint);
    if(pImag == NULL)
    {
        free(pReal);
        free(pImag);
        dbgInfo("[%s] malloc failed\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s(pReal, sizeof(DOUBLE)*samplePoint, 0, sizeof(DOUBLE)*samplePoint);
    memset_s(pImag, sizeof(DOUBLE)*samplePoint, 0, sizeof(DOUBLE)*samplePoint);

    dQn = (DOUBLE)(2.0* PI * dpdicFo / dpdicFs);

    for(pointLoop = 0;pointLoop < samplePoint; pointLoop++)
    {
        dQnRadian   =  dQn * (DOUBLE)(pointLoop + (UINT32)1);
        real        = (INT16)((pSampleData[pointLoop]>>(UINT32)16)&(UINT32)0xFFFF);   /*实部*/
        imag        = (INT16)(pSampleData[pointLoop]& (UINT32)0xFFFF);      /*虚部*/
        realTemp    = (DOUBLE)real;
        imagTemp    = (DOUBLE)imag;
        tempsin     = sin(dQnRadian);
        tempcos     = cos(dQnRadian);
        /*Y(n) = (I+jQ)*(cos(Qn)+jSin(Qn)) = (I*cos(Qn)-Q*Sin(Qn))+j(I*sin(Qn)+Q*cos(Qn))*/
        pReal[pointLoop]  = realTemp * tempcos - imagTemp * tempsin;/*(I*cos(Qn)-Q*Sin(Qn))*/
        pImag[pointLoop]  = realTemp * tempsin + imagTemp * tempcos;/*(I*sin(Qn)+Q*cos(Qn))*/

        dbgInfoEx("----loop:%d,dQnRadian:%f,realTemp:%f,imagTemp:%f,tempsin:%.4f,tempcos:%.4f,pReal:%.4f,pImag:%.4f.\n",\
                    pointLoop,dQnRadian,realTemp,imagTemp,tempsin,tempcos,pReal[pointLoop],pImag[pointLoop]);
    }
    memcpy_s(pRealOutData, sizeof(DOUBLE)*samplePoint, pReal, sizeof(DOUBLE)*samplePoint);
    memcpy_s(pImagOutData, sizeof(DOUBLE)*samplePoint, pImag, sizeof(DOUBLE)*samplePoint);
    free(pReal);
    free(pImag);

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspLadarHbfCal()
*  功能描述   : HBF 半带滤, 4 倍抽取
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :  sampleNum -- 采数点数
*             : pdInRealData  -- 输入实部数据指针
*             : pdInImagData  -- 输入虚部数据指针
*  输出参数   : pdOutRealData -- 输出实部数据指针
             : pdOutImagData -- 输出实部数据指针
               pulOutDataLen -- 输出数据长度
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BspLadarHbfCal(DOUBLE *pdInRealData, DOUBLE *pdInImagData, DOUBLE *pdOutRealData, DOUBLE *pdOutImagData, UINT32* pOutDataLen)
{
    UINT32 outDataLen = 0;
    UINT32 hbfCoefLen = s_filterLen;
    UINT32 halfCoefLen = s_filterLen/2;
    UINT32 dataLen = 0;
    UINT32 loop = 0;
    UINT32 sampleNum = SAMPLE_NUM_MAX;
    DOUBLE *pdHbfCoef = NULL;
    DOUBLE *pdOutRealDataTemp   = NULL;
    DOUBLE *pdOutImagDataTemp   = NULL;

    INPUT_POINTER_CHECK(pdInRealData);
    INPUT_POINTER_CHECK(pdInImagData);
    INPUT_POINTER_CHECK(pdOutRealData);
    INPUT_POINTER_CHECK(pdOutImagData);
    INPUT_POINTER_CHECK(pOutDataLen);

    pdHbfCoef  = (DOUBLE*)malloc(sizeof(DOUBLE)*hbfCoefLen);
    if(NULL == pdHbfCoef)
    {
        dbgInfo("%s malloc pdHbfCoef failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pdOutRealDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*(sampleNum+hbfCoefLen));
    if(NULL == pdOutRealDataTemp)
    {
        free(pdHbfCoef);
        dbgInfo("%s malloc pdOutRealDataTemp failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pdOutImagDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*(sampleNum+hbfCoefLen));
    if(NULL == pdOutImagDataTemp)
    {
        free(pdHbfCoef);
        free(pdOutRealDataTemp);
        dbgInfo("%s malloc pdOutImagDataTemp failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(pdHbfCoef, sizeof(DOUBLE)*hbfCoefLen, 0, sizeof(DOUBLE)*hbfCoefLen);
    memset_s(pdOutRealDataTemp, sizeof(DOUBLE)*(sampleNum+hbfCoefLen), 0, sizeof(DOUBLE)*(sampleNum+hbfCoefLen));
    memset_s(pdOutImagDataTemp, sizeof(DOUBLE)*(sampleNum+hbfCoefLen), 0, sizeof(DOUBLE)*(sampleNum+hbfCoefLen));

    memcpy_s(pdHbfCoef, hbfCoefLen*sizeof(DOUBLE), ladarFilterCoef, hbfCoefLen*sizeof(DOUBLE));
    ConvolutionAlgorithm(pdInRealData, pdHbfCoef, sampleNum, hbfCoefLen, pdOutRealDataTemp);
    ConvolutionAlgorithm(pdInImagData, pdHbfCoef, sampleNum, hbfCoefLen, pdOutImagDataTemp);
    dbgInfo("%s,sampleLen = %u,hbfCoefLen=%u\n", __FUNCTION__ , sampleNum , hbfCoefLen);
    dataLen = sampleNum + halfCoefLen;
    for(loop = halfCoefLen; loop < dataLen; loop ++)/*抽样到92.16采样率*/
    {
        if(loop % EXTRACT_MULTIPLE == (UINT32)0)
        {
            pdOutRealData[loop/EXTRACT_MULTIPLE] = pdOutRealDataTemp[loop];
            pdOutImagData[loop/EXTRACT_MULTIPLE] = pdOutImagDataTemp[loop];
            outDataLen++;
            dbgInfoEx("[%s] Loop'%d real %.4f image %.4f\n", __FUNCTION__, loop, pdOutRealData[loop/EXTRACT_MULTIPLE], pdOutImagData[loop/EXTRACT_MULTIPLE]);
        }
    }
    dbgInfo("outDataLen = %d \n",outDataLen);
    free(pdHbfCoef);
    free(pdOutRealDataTemp);
    free(pdOutImagDataTemp);

    *pOutDataLen = outDataLen;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspLadarAlignDataToFftNum()
*  功能描述   : 单组数据对齐到FFT长度
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :  sampleNum -- 采数点数
*             : pInRealData  -- 输入实部数据指针
*             : pInImagData  -- 输入虚部数据指针
*  输出参数   : pOutRealData -- 输出实部数据指针
             : pOutImagData -- 输出实部数据指针
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BspLadarAlignDataToFftNum(UINT32 samplePoint, DOUBLE *pInRealData, DOUBLE *pInImagData, DOUBLE *pOutRealData, DOUBLE *pOutImagData)
{
    UINT32 pointLoop  = 0;
    UINT32 sampleNum  = 0;

    INPUT_POINTER_CHECK(pInRealData);
    INPUT_POINTER_CHECK(pInImagData);
    INPUT_POINTER_CHECK(pOutRealData);
    INPUT_POINTER_CHECK(pOutImagData);

    dbgInfoEx("%s,samplePoint=%u \n", __FUNCTION__, samplePoint);

    if(samplePoint < FFT_NUM)
    {
        sampleNum = samplePoint;
    }
    else
    {
        sampleNum = FFT_NUM;
    }
    for(pointLoop = 0;pointLoop < sampleNum; pointLoop++)
    {
        pOutRealData[pointLoop] = pInRealData[pointLoop];
        pOutImagData[pointLoop] = pInImagData[pointLoop];
    }
    return BSP_OK;
}

UINT32 BspLadarFftSample(UINT32 bspChan, UINT32 sampleLoop, DOUBLE *pSampleRealData,DOUBLE *pSampleImageData)
{
    UINT32 retVal  = BSP_OK;
    UINT32 difChipId = 0;
    UINT32 difChan = 0;
    UINT32 sampleNum = SAMPLE_NUM_MAX;
    UINT32 datanum = 0;
    UINT32 hbfSampleLen = 0;
    CHAR filename[BUFF_SIZE_MAX] = {0};
    FILE *fin = NULL;
    int fclsRet = 0;
    UINT32 *pOutDataTemp = NULL;  /* 单组采数数据， I放在高16bit,Q在低16bit */
    DOUBLE *pOutRealTemp = NULL;  /* 单组移频后数据 I */
    DOUBLE *pOutImagTemp = NULL;  /* 单组移频后数据 Q */
    DOUBLE *pdInRealTemp = NULL;  /* 单组滤波 4倍抽取后数据 I */
    DOUBLE *pdInImagTemp = NULL;  /* 单组滤波 4倍抽取后数据 Q */
    UCHAR *pucBuffer = NULL;      /* 读文件Buffer */

    INPUT_POINTER_CHECK(pSampleRealData);
    INPUT_POINTER_CHECK(pSampleImageData);

    if(BSP_OK != BspGetDifInfoByRfChn(bspChan, RX, &difChipId, &difChan))
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d,%d,%d) return error\n", __FUNCTION__, bspChan, difChipId, difChan);
        return BSP_ERROR;
    }

    pOutDataTemp = (UINT32 *)malloc(sizeof(UINT32)*sampleNum);
    if(pOutDataTemp == NULL)
    {
        dbgInfo("%s malloc failed!", __FUNCTION__);
        return BSP_ERROR;
    }

    pOutRealTemp = (DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pOutRealTemp == NULL)
    {
        dbgInfo("%s malloc failed!", __FUNCTION__);
        free(pOutDataTemp);
        return BSP_ERROR;
    }

    pOutImagTemp = (DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pOutImagTemp == NULL)
    {
        dbgInfo("%s malloc failed!", __FUNCTION__);
        free(pOutDataTemp);
        free(pOutRealTemp);
        return BSP_ERROR;
    }

    pdInRealTemp = (DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pdInRealTemp == NULL)
    {
        dbgInfo("%s malloc failed!", __FUNCTION__);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        return BSP_ERROR;
    }

    pdInImagTemp  =(DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pdInImagTemp == NULL)
    {
        dbgInfo("%s malloc failed!", __FUNCTION__);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        return BSP_ERROR;
    }

    memset_s(pOutDataTemp, (sizeof(UINT32)*sampleNum), 0, (sizeof(UINT32)*sampleNum));
    memset_s(pOutRealTemp, (sizeof(DOUBLE)*sampleNum), 0, (sizeof(DOUBLE)*sampleNum));
    memset_s(pOutImagTemp, (sizeof(DOUBLE)*sampleNum), 0, (sizeof(DOUBLE)*sampleNum));
    memset_s(pdInRealTemp, (sizeof(DOUBLE)*sampleNum), 0, (sizeof(DOUBLE)*sampleNum));
    memset_s(pdInImagTemp, (sizeof(DOUBLE)*sampleNum), 0, (sizeof(DOUBLE)*sampleNum));

    retVal = BspHalAdaptSetSampleUlChTimes(1);

    fclsRet = snprintf_s(filename, BUFF_SIZE_MAX, "sampleUlCh.bin");
    SNPRINTF_S_CHECK(fclsRet, BUFF_SIZE_MAX);

    if((fopen_s(&fin,filename, "r+") != 0) || (fin == NULL))
    {
        dbgErr("%s: open %s failed!\n", __FUNCTION__, filename);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        free(pdInImagTemp);
        return BSP_ERROR;
    }

    pucBuffer = (UCHAR *)malloc(sizeof(UINT32)*(sampleNum+32));
    if (NULL == pucBuffer)
    {
        dbgErr("Fail to get memory! error code: %s\n", zte_strerror_s(errno));
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        free(pdInImagTemp);

        fclsRet = fclose(fin);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    /* 2.从文件读取数据 */
    datanum = fread(pucBuffer, 1, sizeof(UINT32)*(sampleNum+32), fin);
    memcpy_s(pOutDataTemp, sizeof(UINT32)*sampleNum, pucBuffer+32*sizeof(UINT32), sizeof(UINT32)*sampleNum);
    if((datanum != sizeof(UINT32)*(sampleNum+32)))
    {
        dbgErr("[%s]read file '%d  Error \n", __FUNCTION__, datanum);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        free(pdInImagTemp);
        free(pucBuffer);

        fclsRet = fclose(fin);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    BspSampleSave("sample@368P64", sampleLoop, pOutDataTemp, sampleNum);

    /* 3.移频 */
    retVal |= BspLadarMoveNco(sampleNum, pOutDataTemp, pOutRealTemp, pOutImagTemp);
    BspDoubleSampleSave("moveNco@368P64", sampleLoop, pOutRealTemp, pOutImagTemp, sampleNum);

    /* 4. 半带/1/4抽取滤波器*/
    BspLadarHbfCal(pOutRealTemp, pOutImagTemp, pdInRealTemp, pdInImagTemp, &hbfSampleLen);
    BspDoubleSampleSave("hbf@92P16", sampleLoop, pdInRealTemp, pdInImagTemp, hbfSampleLen);

    memset_s(pOutRealTemp, (sizeof(DOUBLE)*sampleNum), 0, (sizeof(DOUBLE)*sampleNum));
    memset_s(pOutImagTemp, (sizeof(DOUBLE)*sampleNum), 0, (sizeof(DOUBLE)*sampleNum));
    /* 5. 输出数据对齐到4096点*/
    BspLadarAlignDataToFftNum(hbfSampleLen, pdInRealTemp, pdInImagTemp, pSampleRealData, pSampleImageData);

    free(pOutDataTemp);
    free(pOutRealTemp);
    free(pOutImagTemp);
    free(pdInRealTemp);
    free(pdInImagTemp);
    free(pucBuffer);

    fclsRet = fclose(fin);
    FCLOSE_CHECK(fclsRet);

    return retVal;
}

UINT32 BspLadarSample(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 sampleLoop = 0;

    if (!s_ladarSupport)
    {
        dbgErr("[%s]Trx Board Not Support Ladar Scan\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgPrn("%s begin, ticks %u\n", __FUNCTION__, tickGet());
    BspLadarSetSampleSta(bspChan, LADAR_SCAN_RUNNING);

    /*1.RX0 通道所有通道上行载波增益记录下来，并清0 */
    BspLadarSetRxCoefZero(bspChan);
    /*2.RRU射频链路切换成下行AC校准状态 */
    BspLadarSetAcSwitch(AC_DL);
    /*3.记录RX0通道当前RXATT值，然后把RXATT设置为0dB衰减 */
    BspLadarSetRxAtt(bspChan, MGC_MODE_MANUAL);

    memset_s(s_Fft_RealTmp, sizeof(s_Fft_RealTmp), 0, sizeof(s_Fft_RealTmp));
    memset_s(s_Fft_ImagTmp, sizeof(s_Fft_ImagTmp), 0, sizeof(s_Fft_ImagTmp));

    /*4.启动采数 */
    for(sampleLoop = 0; sampleLoop < SAMPLE_TIME_MAX; sampleLoop++)
    {
        retVal |= BspLadarFftSample(bspChan, sampleLoop, s_Fft_RealTmp[sampleLoop], s_Fft_ImagTmp[sampleLoop]);
    }

    /*5.RX0通道 RXATT恢复成自动模式 */
    BspLadarSetRxAtt(bspChan, MGC_MODE_MGC);
    /*6.AC开关恢复到接收通道状态 */
    BspLadarSetAcSwitch(AC_STOP);
    /*7.RX0通道所有载波上行增益恢复 */
    BspLadarRecoverRxCoef(bspChan);

    BspLadarSetSampleSta(bspChan, LADAR_SCAN_OK);
    dbgPrn("%s end, ret=%u, ticks %u\n", __FUNCTION__, retVal, tickGet());
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspLadarFft()
*  功能描述   : 进行FFT 计算
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :算法由V1平台移植
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BspLadarFft(UINT32 fftCalNum)
{
    static UINT32 initFlag   = 0;
    UINT32 pointLoop         = 0;
    DOUBLE fftShift          = 0.0;

    if (fftCalNum > FFT_NUM)
    {
        dbgErr("[%s] fftCalNum=%u Error\n", __FUNCTION__,fftCalNum);
        return BSP_ERROR;
    }
    /*FFT calc*/
    if(0 == initFlag)
    {
        fft24_initW(s_fftWeight1, s_fftWeight2, fftCalNum);
        fft24_change(s_fftCoef2, fftCalNum);
        initFlag = 1;
    }
    fft24_DX(s_fft_Out_I, s_fft_Out_Q, s_fft_In_I, s_fft_In_Q, s_fftWeight1, s_fftWeight2, fftCalNum, s_fftCoef2);

    /*FFT shift*/
    for(pointLoop = 0 ; pointLoop < fftCalNum/2; pointLoop++)
    {
        fftShift = s_fft_Out_I[pointLoop];
        s_fft_Out_I[pointLoop] = s_fft_Out_I[pointLoop + fftCalNum/2];
        s_fft_Out_I[pointLoop + fftCalNum/2] = fftShift;

        fftShift = s_fft_Out_Q[pointLoop];
        s_fft_Out_Q[pointLoop] = s_fft_Out_Q[pointLoop + fftCalNum/2];
        s_fft_Out_Q[pointLoop + fftCalNum/2] = fftShift;
    }
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspLadarAccumulateFftData()
*  功能描述   : 单组数据I^2+Q^2
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :算法由V1平台移植
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*----------------------------------------------------------------------------
*/
UINT32 BspLadarAccumulateFftData(UINT32 fftCalNum, DOUBLE *pFftData)
{
    UINT32 pointLoop = 0;
    INPUT_POINTER_CHECK(pFftData);

    if(fftCalNum > FFT_NUM)
    {
        dbgErr("[%s]fftCalNum  = %d Error\n", __FUNCTION__, fftCalNum);
        return BSP_ERROR;
    }

    for(pointLoop = 0; pointLoop < fftCalNum; pointLoop++)
    {
        pFftData[pointLoop] = pow(s_fft_Out_I[pointLoop], 2) + pow(s_fft_Out_Q[pointLoop], 2);
    }
    return BSP_OK;
}

VOID prnfftpow(UINT32 index)
{
    UINT32  fftIdx = 0;
    UINT32  sampleLoop = 0;
    if (index >= POW_INTEGRAL_NUM)
    {
        index = POW_INTEGRAL_NUM -1;
    }

    fftIdx = START_INDEX + index * POW_MERGE_STEP;
    dbgPrn("fftIdx start%u, end%u\n", fftIdx, fftIdx+7);
    if ((fftIdx >= FFT_NUM) || ((fftIdx+7) >= FFT_NUM))
    {
        return;
    }

    for(sampleLoop = 0; sampleLoop < SAMPLE_TIME_MAX; sampleLoop++)
    {
        dbgPrn("sample%u %.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n", sampleLoop, s_fft_Pow[sampleLoop][fftIdx],s_fft_Pow[sampleLoop][fftIdx+1],s_fft_Pow[sampleLoop][fftIdx+2],
            s_fft_Pow[sampleLoop][fftIdx+3],s_fft_Pow[sampleLoop][fftIdx+4],s_fft_Pow[sampleLoop][fftIdx+5],s_fft_Pow[sampleLoop][fftIdx+6],s_fft_Pow[sampleLoop][fftIdx+7]);
    }

    dbgPrn("fftPowAvg:%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n", s_PowAvg[fftIdx], s_PowAvg[fftIdx+1],s_PowAvg[fftIdx+2],s_PowAvg[fftIdx+3],
        s_PowAvg[fftIdx+4], s_PowAvg[fftIdx+5],s_PowAvg[fftIdx+6], s_PowAvg[fftIdx+7]);

    dbgPrn("fftPowMax:%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f,%.4f\n", s_PowMax[fftIdx], s_PowMax[fftIdx+1],s_PowMax[fftIdx+2],s_PowMax[fftIdx+3],
        s_PowMax[fftIdx+4], s_PowMax[fftIdx+5],s_PowMax[fftIdx+6], s_PowMax[fftIdx+7]);
}

UINT32 BspGetIdRssiAvgComp(UINT32 freqKHz, UINT32 bw, INT32 *pAvgComp)
{
    UINT32 bspRxChan = 0;
    UINT32 chnNum = BspGetRxChannel();
    UINT32 retVal = BSP_OK;
    INT32 rxCompVal = 0;
    DOUBLE rxCompSum = 0;

    INPUT_POINTER_CHECK(pAvgComp);

    for (bspRxChan = 0; bspRxChan < chnNum; bspRxChan++)
    {
        rxCompVal = 0;
        retVal |= BspGetIdRssiDbmCompGain(bspRxChan, freqKHz, bw, &rxCompVal);
        dbgInfoEx("%s Rx%u, freq%u, rxCompVal=%d\n", __FUNCTION__, bspRxChan, freqKHz, rxCompVal);
        rxCompSum += rxCompVal;
    }

    if (chnNum > 0)
    {
        *pAvgComp = (INT32)(rxCompSum/chnNum);
        dbgInfoEx("%s Total Chan%u, rxCompSum=%f, avgComp=%d\n", __FUNCTION__, chnNum, rxCompSum, *pAvgComp);
    }

    return retVal;
}

/* 数字功率映射模拟功率完成后，再加24dB(补偿rxatt=24dB与写表时RXATT=0dB的偏移量)，然后再减6.02dB(扣除AC耦合器的损耗) */
#define POW_OFFSET     ((INT32)(1790))
UINT32 BspLadarCalFftPow(UINT32 bspChan)
{
    UINT32 sampleLoop = 0;
    UINT32 tmaGain = 0;
    UINT32 fftNum = 0;
    UINT32 index = 0;
    UINT32 start = 0;
    UINT32 externTxPowMw = 0;
    UINT32 freqKHz = 0;
    INT32 rxCompVal = 0;
    INT32 avgThrod = 0;
    INT32 maxThrod = 0;
    DOUBLE powMaxDbfs = 0.0;
    DOUBLE powAvgDbfs = 0.0;
    DOUBLE powMaxMerge = 0.0;
    DOUBLE powAvgMerge = 0.0;

    memset_s(s_PowAvg, sizeof(s_PowAvg), 0, sizeof(s_PowAvg));
    memset_s(s_PowMax, sizeof(s_PowMax), 0, sizeof(s_PowMax));

    for(fftNum = START_INDEX; fftNum < INDEX_MAX ; fftNum++)
    {
        for(sampleLoop = 0; sampleLoop < SAMPLE_TIME_MAX; sampleLoop++)
        {
            s_PowAvg[fftNum] += s_fft_Pow[sampleLoop][fftNum];

            if (s_fft_Pow[sampleLoop][fftNum] > s_PowMax[fftNum])
            {
                s_PowMax[fftNum] = s_fft_Pow[sampleLoop][fftNum];
            }
        }

        s_PowAvg[fftNum] /= (DOUBLE)(SAMPLE_TIME_MAX);
    }

    BspGetTmaGainByBspChn(bspChan, &tmaGain);

    memset_s(s_PowMaxMergeDbm, sizeof(s_PowMaxMergeDbm), 0, sizeof(s_PowMaxMergeDbm));
    memset_s(s_PowAvgMergeDbm, sizeof(s_PowAvgMergeDbm), 0, sizeof(s_PowAvgMergeDbm));

    memset_s(s_sptMax, sizeof(s_sptMax), 0, sizeof(s_sptMax));
    memset_s(s_sptAvg, sizeof(s_sptAvg), 0, sizeof(s_sptAvg));

    memset_s(s_sptAvgSort, sizeof(s_sptAvgSort), 0, sizeof(s_sptAvgSort));

    for (index = 0; index < POW_INTEGRAL_NUM; index++)
    {
        start = START_INDEX + index * POW_MERGE_STEP;
        freqKHz = START_FREQ + index * POW_STEP_KHZ;
        BspGetIdRssiAvgComp(freqKHz, 0, &rxCompVal);
        externTxPowMw = (s_ladarAlmInfo[index].externTxPow) * 1000;
        avgThrod = s_ladarAlmInfo[index].avgThrod;
        maxThrod = s_ladarAlmInfo[index].maxThrod;

        powMaxMerge = s_PowMax[start] + s_PowMax[start+1] + s_PowMax[start+2] + s_PowMax[start+3] + s_PowMax[start+4] + s_PowMax[start+5] + s_PowMax[start+6] + s_PowMax[start+7];
        powMaxDbfs = 1000.0*log10_s(powMaxMerge, 0.0) - FULL_SCAL_16BIT;
        s_PowMaxMergeDbm[index] = (INT32)(powMaxDbfs - rxCompVal - tmaGain + POW_OFFSET);
        s_sptMax[index] = (UINT16)(1000*log10_s(externTxPowMw, 0.0) - s_PowMaxMergeDbm[index]);
        dbgInfoEx("index%-3u,freqKHz=%u,powMaxMerge=%.2f,powMaxDbfs=%.2f,s_PowMaxMergeDbm=%d,s_sptMax=%d\n", index, freqKHz, powMaxMerge, powMaxDbfs, s_PowMaxMergeDbm[index], s_sptMax[index]);
        BspLog(LOG_LEVEL_0, "%s{index%-3u,freq=%u,maxMerge=%.2f,dbfs=%.2f,rxComp=%d,dbm=%d,sptMax=%d}\n", __FUNCTION__, index, freqKHz, powMaxMerge, powMaxDbfs, rxCompVal, s_PowMaxMergeDbm[index], s_sptMax[index]);

        if ((maxThrod > 0) && (s_sptMax[index] < maxThrod))
        {
            s_ladarAlmInfo[index].maxAlmFlag = SPT_ALM;
        }

        powAvgMerge = s_PowAvg[start] + s_PowAvg[start+1] + s_PowAvg[start+2] + s_PowAvg[start+3] + s_PowAvg[start+4] + s_PowAvg[start+5] + s_PowAvg[start+6] + s_PowAvg[start+7];
        powAvgDbfs = 1000*log10_s(powAvgMerge, 0.0) - FULL_SCAL_16BIT;
        s_PowAvgMergeDbm[index] = (INT32)(powAvgDbfs - rxCompVal - tmaGain + POW_OFFSET);
        s_sptAvg[index] = (UINT16)(1000 * log10_s(externTxPowMw, 0.0) - s_PowAvgMergeDbm[index]);
        s_sptAvgSort[index] = (INT16)s_sptAvg[index];
        dbgInfoEx("index%-3u,freqKHz=%u,powAvgMerge=%.2f,powAvgDbfs=%.2f,s_PowAvgMergeDbm=%d,s_sptAvg=%d\n", index, freqKHz, powAvgMerge, powAvgDbfs, s_PowAvgMergeDbm[index], s_sptAvg[index]);
        BspLog(LOG_LEVEL_0, "%s{index%-3u,freq=%u,avgMerge=%.2f,dbfs=%.2f,rxComp=%d,dbm=%d,sptAvg=%d}\n", __FUNCTION__, index, freqKHz, powAvgMerge, powAvgDbfs, rxCompVal, s_PowAvgMergeDbm[index], s_sptAvg[index]);

        if ((avgThrod > 0) && (s_sptAvg[index] < avgThrod))
        {
            s_ladarAlmInfo[index].avgAlmFlag = SPT_ALM;
        }
    }

    return BSP_OK;
}

UINT32 BspLadarFftCal(UINT32 bspChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 sampleLoop = 0;
    UINT32 fftNum = 0;

    if (!s_ladarSupport)
    {
        dbgErr("[%s]Trx Board Not Support Ladar Scan\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgPrn("%s begin, ticks %u\n", __FUNCTION__, tickGet());

    for(sampleLoop = 0; sampleLoop < SAMPLE_TIME_MAX; sampleLoop++)
    {
        memset_s(s_fft_In_I, sizeof(s_fft_In_I), 0, sizeof(s_fft_In_I));
        memset_s(s_fft_In_Q, sizeof(s_fft_In_Q), 0, sizeof(s_fft_In_Q));
        memset_s(s_fft_Out_I, sizeof(s_fft_Out_I), 0, sizeof(s_fft_Out_I));
        memset_s(s_fft_Out_Q, sizeof(s_fft_Out_Q), 0, sizeof(s_fft_Out_Q));

        for(fftNum = 0; fftNum < FFT_NUM ; fftNum++)
        {
            s_fft_In_I[fftNum] = s_Fft_RealTmp[sampleLoop][fftNum];
            s_fft_In_Q[fftNum] = s_Fft_ImagTmp[sampleLoop][fftNum];
        }
        BspDoubleSampleSave("fftIn@92P16", sampleLoop, s_fft_In_I, s_fft_In_Q, FFT_NUM);
        /*加窗化归一化处理*/
        retVal |= BspFftWin(s_fft_In_I, s_fft_In_Q, FFT_NUM, s_fft_In_I, s_fft_In_Q);

        /* FFT计算 */
        retVal |= BspLadarFft(FFT_NUM);
        BspDoubleSampleSave("fftOut@92P16", sampleLoop, s_fft_Out_I, s_fft_Out_Q, FFT_NUM);
        /* I^2+Q^2 */
        retVal |= BspLadarAccumulateFftData(FFT_NUM, s_fft_Pow[sampleLoop]);
    }

    BspLadarCalFftPow(bspChan);

    dbgPrn("%s end, ret=%u, ticks %u\n", __FUNCTION__, retVal, tickGet());

    return retVal;
}

UINT32 BspLadarGetScanData(T_BspLadarSacnData *pLadarScanData)
{
    INPUT_POINTER_CHECK(pLadarScanData);

    pLadarScanData->startFreqKHz = START_FREQ;
    pLadarScanData->stepKHz = POW_STEP_KHZ;
    pLadarScanData->freqNum = POW_INTEGRAL_NUM;

    memcpy_s((void *)pLadarScanData->sptAvg, sizeof(s_sptAvg), (void *)&s_sptAvg, sizeof(s_sptAvg));
    memcpy_s((void *)pLadarScanData->sptMax, sizeof(s_sptMax), (void *)&s_sptMax, sizeof(s_sptMax));

    return BSP_OK;
}

/* Started by AICoder, pid:bebf414d8cb93e81423a0ae4602e8d59dc30e18c */
UINT32 BspLadarGetAlm(T_BspLadarFreqInfo *pLadarFreqInfo)
{
    UINT32 index = 0;
    UINT16 avgSptMinMean = 0;
    UINT16 subBandIdx = 0;
    UINT32 avgThrod = 0;
    UINT32 maxThrod = 0;
    UINT32 avgAlmNum[LADAR_SUB_BAND_MAX] = {0};
    UINT32 maxAlmNum[LADAR_SUB_BAND_MAX] = {0};

    INPUT_POINTER_CHECK(pLadarFreqInfo);

    pLadarFreqInfo->almFlg.subBandNum = s_ladarPara.subBandNum;
    BspLog(LOG_LEVEL_0, "%s{bandNum=%u}\n", __FUNCTION__, pLadarFreqInfo->almFlg.subBandNum);

    for (index = 0; index < POW_INTEGRAL_NUM; index++)
    {
        subBandIdx = s_ladarAlmInfo[index].subBandIdx;
        avgThrod = s_ladarAlmInfo[index].avgThrod;
        maxThrod = s_ladarAlmInfo[index].maxThrod;
        if ((0 == avgThrod) || (0 == maxThrod) || (subBandIdx >= LADAR_SUB_BAND_MAX))
        {
            continue;
        }
        if (SPT_ALM == s_ladarAlmInfo[index].avgAlmFlag)
        {
            avgAlmNum[subBandIdx]++;
        }
        if (SPT_ALM == s_ladarAlmInfo[index].maxAlmFlag)
        {
            maxAlmNum[subBandIdx]++;
        }
    }

    for (index = 0; ((index < s_ladarPara.subBandNum) && (index < LADAR_SUB_BAND_MAX)); index++)
    {
        pLadarFreqInfo->almFlg.subBandStartFreq[index] = s_ladarPara.subBandStartFreq[index];
        pLadarFreqInfo->almFlg.subBandEndFreq[index] = s_ladarPara.subBandEndFreq[index];
        avgThrod = s_ladarPara.subBandAvgThrod[index];
        avgSptMinMean = pLadarFreqInfo->analyseRpt.subBandAvgDelta[index];
        BspLog(LOG_LEVEL_0, "%s{subBand%u,start%u,end%u}\n", __FUNCTION__, index, pLadarFreqInfo->almFlg.subBandStartFreq[index], pLadarFreqInfo->almFlg.subBandEndFreq[index]);
        if ((avgSptMinMean < avgThrod) && (maxAlmNum[index] > 0))
        {
            pLadarFreqInfo->almFlg.subBandAlmFlag[index] = SPT_ALM;
            dbgPrn("%s subBand%u, avgSptMinMean=%u, avgThrod=%u, maxAlmNum=%u\n", __FUNCTION__, index, avgSptMinMean, avgThrod, maxAlmNum[index]);
            BspLog(LOG_LEVEL_0, "%s{subBand%u, avgSptMinMean=%u, avgThrod=%u, maxAlmNum=%u}\n", __FUNCTION__, index, avgAlmNum[index], avgThrod, maxAlmNum[index]);
        }
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:bebf414d8cb93e81423a0ae4602e8d59dc30e18c */

/* Started by AICoder, pid:iccd2n9c0fl99411490d0a99604f613be735dd9b */
UINT32 BubbleSort(INT16 *pBuf, UINT32 bufLen, INT16 *avgMinMean)
{
    INT16 temp = 0;
    UINT32 i = 0;
    UINT32 j = 0;
    UINT32 sortLen = 0;
    DOUBLE sum = 0.0;

    INPUT_POINTER_CHECK(pBuf);
    INPUT_POINTER_CHECK(avgMinMean);

    if (bufLen < MIN_LEN)
    {
        dbgErr("[%s]bufLen must be greater than 1\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for (i = 0; i < SPT_MEAN_LEN; i++)
    {
        for (j = (bufLen - 1); j > i; j--)
        {
            if (pBuf[j] < pBuf[j - 1])
            {
                temp = pBuf[j];
                pBuf[j] = pBuf[j - 1];
                pBuf[j - 1] = temp;
            }
        }
    }

    sortLen = (bufLen <= SPT_MEAN_LEN) ? (bufLen) : (SPT_MEAN_LEN);
    for (i = 0; i < sortLen; i++)
    {
        sum += (DOUBLE)(pBuf[i]);
    }
    if (sortLen > 0)
    {
        *avgMinMean = (INT16)(sum / sortLen);
    }

    return BSP_OK;
}

UINT32 BspLadarGetAvgSptMinMean(T_BspLadarAnalyseRpt *pLadarAnalyseRpt)
{
    UINT32 ret = BSP_OK;
    UINT32 band = 0;
    UINT32 startFreq = 0;
    UINT32 endFreq = 0;
    UINT32 startIndex = 0;
    UINT32 endIndex = 0;
    UINT32 len = 0;
    INT16 avgSptMinMean = 0;
    INT16 *pBuf = NULL;

    INPUT_POINTER_CHECK(pLadarAnalyseRpt);

    for (band = 0; ((band < s_ladarPara.subBandNum) && (band < LADAR_SUB_BAND_MAX)); band++)
    {
        startFreq = s_ladarPara.subBandStartFreq[band];
        CONTINUE_IF_EXP((startFreq < START_FREQ) || (startFreq > END_FREQ));

        endFreq = s_ladarPara.subBandEndFreq[band];
        CONTINUE_IF_EXP((endFreq < START_FREQ) || (endFreq > END_FREQ));

        CONTINUE_IF_EXP(startFreq >= endFreq);
        startIndex = ceil((startFreq - START_FREQ) / STEP_KHZ);
        endIndex = floor((endFreq - START_FREQ) / STEP_KHZ);
        len = endIndex - startIndex + 1;
        CONTINUE_IF_EXP((startIndex >= POW_INTEGRAL_NUM) || (len > POW_INTEGRAL_NUM));

        pBuf = &(s_sptAvgSort[startIndex]);
        ret |= BubbleSort(pBuf, len, &avgSptMinMean);
        pLadarAnalyseRpt->subBandAvgDelta[band] = avgSptMinMean;
        BspLog(LOG_LEVEL_0, "%s{band%u,startFreq=%u,endFreq=%u,startIndex=%u,endIndex=%u,len=%u,avgSptMinMean=%d}\n", __FUNCTION__, band, startFreq, endFreq, startIndex, endIndex, len, avgSptMinMean);
    }

    return ret;
}
/* Ended by AICoder, pid:iccd2n9c0fl99411490d0a99604f613be735dd9b */

UINT32 BspLadarGetAnalyseRpt(T_BspLadarAnalyseRpt *pLadarAnalyseRpt)
{
    UINT16 subBandIdx = 0;
    UINT32 index = 0;
    UINT32 avgThrod = 0;
    UINT32 maxThrod = 0;
    UINT32 subBandSumNum[LADAR_SUB_BAND_MAX] = {0};
    UINT32 avgAlmNum[LADAR_SUB_BAND_MAX] = {0};
    UINT32 maxAlmNum[LADAR_SUB_BAND_MAX] = {0};
    UINT16 avgSptMin[LADAR_SUB_BAND_MAX] = {0xffff, 0xffff, 0xffff, 0xffff};
    UINT16 maxSptMin[LADAR_SUB_BAND_MAX] = {0xffff, 0xffff, 0xffff, 0xffff};
    DOUBLE avgSptSum[LADAR_SUB_BAND_MAX] = {0.0};
    DOUBLE maxSptSum[LADAR_SUB_BAND_MAX] = {0.0};

    INPUT_POINTER_CHECK(pLadarAnalyseRpt);

    pLadarAnalyseRpt->subBandNum = s_ladarPara.subBandNum;
    BspLog(LOG_LEVEL_0, "%s{bandNum=%u}\n", __FUNCTION__, pLadarAnalyseRpt->subBandNum);

    for (index = 0; index < POW_INTEGRAL_NUM; index++)
    {
        subBandIdx = s_ladarAlmInfo[index].subBandIdx;
        avgThrod = s_ladarAlmInfo[index].avgThrod;
        maxThrod = s_ladarAlmInfo[index].maxThrod;
        if ((0 == avgThrod) || (0 == maxThrod) || (subBandIdx >= LADAR_SUB_BAND_MAX))
        {
            continue;
        }
        subBandSumNum[subBandIdx]++;
        avgSptSum[subBandIdx] += s_sptAvg[index];
        if (avgSptMin[subBandIdx] > s_sptAvg[index])
        {
            avgSptMin[subBandIdx] = s_sptAvg[index];
        }

        maxSptSum[subBandIdx] += s_sptMax[index];
        if (maxSptMin[subBandIdx] > s_sptMax[index])
        {
            maxSptMin[subBandIdx] = s_sptMax[index];
        }

        if (SPT_ALM == s_ladarAlmInfo[index].avgAlmFlag)
        {
            avgAlmNum[subBandIdx]++;
        }
        if (SPT_ALM == s_ladarAlmInfo[index].maxAlmFlag)
        {
            maxAlmNum[subBandIdx]++;
        }
    }

    for (index = 0; ((index < s_ladarPara.subBandNum) && (index < LADAR_SUB_BAND_MAX)); index++)
    {
        pLadarAnalyseRpt->subBandStartFreq[index]= s_ladarPara.subBandStartFreq[index];
        pLadarAnalyseRpt->subBandEndFreq[index] = s_ladarPara.subBandEndFreq[index];
        pLadarAnalyseRpt->subBandAvgBandWidth[index] = avgAlmNum[index] * POW_STEP_KHZ;
        pLadarAnalyseRpt->subBandMaxBnadWidth[index] = maxAlmNum[index] * POW_STEP_KHZ;
        BspLog(LOG_LEVEL_0, "%s{subBand%u,start%u,end%u,avgBand%u,maxBand%u}\n", __FUNCTION__, index, pLadarAnalyseRpt->subBandStartFreq[index], pLadarAnalyseRpt->subBandEndFreq[index], pLadarAnalyseRpt->subBandAvgBandWidth[index], pLadarAnalyseRpt->subBandMaxBnadWidth[index]);

        if (subBandSumNum[index] > 0)
        {
            pLadarAnalyseRpt->subBandAvgThordAlmAvg[index] = (UINT16)(avgSptSum[index]/subBandSumNum[index]);
            BspLog(LOG_LEVEL_0, "%s{Num=%u,avgSptSum=%.2f,avgSptAvg=%u}\n", __FUNCTION__, subBandSumNum[index], avgSptSum[index], pLadarAnalyseRpt->subBandAvgThordAlmAvg[index]);

            pLadarAnalyseRpt->subBandMaxThordAlmAvg[index] = (UINT16)(maxSptSum[index]/subBandSumNum[index]);
            BspLog(LOG_LEVEL_0, "%s{Num=%u,maxSptSum=%.2f,maxSptAvg=%u}\n", __FUNCTION__, subBandSumNum[index], maxSptSum[index], pLadarAnalyseRpt->subBandMaxThordAlmAvg[index]);
        }

        pLadarAnalyseRpt->subBandAvgDelta[index] = avgSptMin[index];
        pLadarAnalyseRpt->subBandMaxDelta[index] = maxSptMin[index];
        BspLog(LOG_LEVEL_0, "%s{avgSptMin=%u,maxSptMin=%u}\n", __FUNCTION__, avgSptMin[index], maxSptMin[index]);
    }
    return BSP_OK;
}

UINT32 BspLadarScan(UINT32 bspChan, T_BspLadarPara *pLadarPara, T_BspLadarFreqInfo *pLadarFreqInfo)
{
    UINT32 retVal = BSP_OK;
    UINT32 sampleRet = BSP_OK;

    if (bspChan >= MAX_RX_CHAN)
    {
        return BSP_ERROR;
    }

    INPUT_POINTER_CHECK(pLadarPara);
    INPUT_POINTER_CHECK(pLadarFreqInfo);

    retVal = BspLadarSetPara(pLadarPara);
    sampleRet = BspLadarSample(bspChan);
    if (BSP_OK == sampleRet)
    {
        retVal |= BspLadarFftCal(bspChan);

        retVal |= BspLadarGetScanData(&(pLadarFreqInfo->freqData));
        retVal |= BspLadarGetAnalyseRpt(&(pLadarFreqInfo->analyseRpt));
        retVal |= BspLadarGetAvgSptMinMean(&(pLadarFreqInfo->analyseRpt));
        retVal |= BspLadarGetAlm(pLadarFreqInfo);
    }

    return retVal;
}

VOID testladar(UINT32 startFreqKHz, UINT32 endFreqKHz, UINT32 avgThrod, UINT32 maxThrod, UINT32 txPwrW)
{
    UINT32 retVal = BSP_OK;
    T_BspLadarPara  *pLadarPara = NULL;
    T_BspLadarFreqInfo *pLadarFreqInfo = NULL;

    pLadarPara = (T_BspLadarPara *)malloc(sizeof(T_BspLadarPara));
    if (NULL == pLadarPara)
    {
        return;
    }

    memset_s(pLadarPara, sizeof(T_BspLadarPara), 0, sizeof(T_BspLadarPara));
    pLadarPara->subBandNum = 1;
    pLadarPara->subBandStartFreq[0] = ((0 == startFreqKHz)?(930000):(startFreqKHz));
    pLadarPara->subBandEndFreq[0] = ((0 == endFreqKHz)?(960000):(endFreqKHz));
    pLadarPara->subBandAvgThrod[0] = ((0 == avgThrod)?(7000):(avgThrod));
    pLadarPara->subBandMaxThrod[0] = ((0 == maxThrod)?(5500):(maxThrod));
    pLadarPara->subBandExternTxPwr[0] = ((0 == txPwrW)?(80):(txPwrW));

    pLadarFreqInfo = (T_BspLadarFreqInfo *)malloc(sizeof(T_BspLadarFreqInfo));
    if (NULL == pLadarFreqInfo)
    {
        free(pLadarPara);
        return;
    }

    memset_s(pLadarFreqInfo, sizeof(T_BspLadarFreqInfo), 0, sizeof(T_BspLadarFreqInfo));

    retVal = BspLadarScan(0, pLadarPara, pLadarFreqInfo);
    dbgPrn("%s retVal=%u\n", __FUNCTION__, retVal);

    BspLadarPrnPara();

    free(pLadarPara);
    free(pLadarFreqInfo);
}

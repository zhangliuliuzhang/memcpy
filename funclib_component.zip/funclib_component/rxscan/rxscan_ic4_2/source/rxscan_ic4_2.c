/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : rxscan_ic3.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 频谱扫描控制 方案由FPGA实现参数配置 BSP流程控制
 * 注意事项 : FPGA 频谱扫描采样数为92.16M ，4096点，这个与BBU已经对其，如果FPGA采样速率不是92.16M，
 *         则需要进行FPGA NCO 搬移，需要对齐到92.16M上，并且上报点数为4096点。
 * 作    者 : 10102065
 * 创建日期 : 2017-2-22 09:54:30
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 *
 *------------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "regdrv.h"
#include "rxscan_ic4_2.h"
#include "chnmap_a.h"
#include "rruinfo.h"
#include <math.h>
#include "resource_alloc_api.h"
#include "regtbl.h"
#include "devdrv_transceiver.h"
#include "devdrv_att.h"
#include "ichaladapt_ic4_2.h"
#include "ul_ch.h"
#include "sample_ch.h"

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

extern UINT32 HalSampleChModeCfg(UINT32 uiSampleMode0, UINT32 uiSampleMode1);
extern UINT32 HalSampleChAbnCfg(UINT32 uiSampleAbn0, UINT32 uiSampleAbn1);
extern UINT32 HalSampleUlCh1(UINT32 uiDifChan, UINT32 uiPosSel);
extern UINT32 HalSampleUlChDataTypeCfg(UINT32 uiDataType0, UINT32 uiDataType1);
static T_DPDIC_RXSCAN *s_pIcRxScanChnInfo = NULL;
double  s_dpdicFft_RealTmp[FFT_MAX_SAMPLE_TIMES][FFT_MAX_NUM] ={0};
double  s_dpdicFft_ImagTmp[FFT_MAX_SAMPLE_TIMES][FFT_MAX_NUM] ={0};
static T_RX_SAMPLE_COEF_CFG      g_ptRxHbfInfo = {0};
static T_RX_SAMPLE_COEF_CFG      g_ptRx3P4EfInfo = {0};
static UINT32 			s_icRxScanMaxChnNum = 0;
static UINT32        	s_ChBndMapNum  = 0;
static T_ChBndMapInfo *s_ChBndMap = NULL; 
static UINT32           rxScanMtsAgcMode = 0;  /*接收扫频 控制MTS AGC模式*/
static UINT32           s_VgaCtrlMode = 0;  /*VGA模式*/

RxScan_ParaInit g_Func_RxScanParaReInit = NULL;
static vga_MTS_SwitchAgcByChan  s_pMTS_SwitchAgcByChan = NULL;
ULONG BspSetRx3P4EfCoefCfg(DOUBLE* dRx3P4EfCoef,ULONG ulLength);
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define DPDIC_RXSCAN_FUNC_INIT    0x1
#define DPDIC_RXSCAN_FUNC_UNINIT  0x0

#define DPDIC_RXSCAN_SAMPLE_CHANCE    10
#define DPDIC_RXSCAN_SAMPLE_COMPLETE  0x1

#define INPUT_DPDIC_RXSCANCHN_CHECK(bspChn)                  \
{                                                           \
    UINT32 rxChn     = BspGetIcRxScanMaxChnNum();    		\
    if (bspChn >= rxChn)                                    \
    {                                                       \
        dbgErr("[%s]ICchn'%d is Error ,Over rxScanChn'%d MaxRxChn'%d \n",__FUNCTION__,bspChn,rxChn);\
        return BSP_ERROR;                                   \
    }                                                       \
}

#define RxScanPrint(level,fmt...)    PmPrint(PmAutoAdd(DEFAULT_PM_LEVEL,"DpdApp"),(level)|PM_PREFIX,##fmt)
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
/*3/4抽样系数*/
static DOUBLE g_dRxHbfCoef_3p4Ef[]={
        0.0000333,
        0.0000846,
        0.0001355,
        0.0001281,
        0.0000737,
        -0.000261,
        -0.000577,
        -0.000765,
        -0.000624,
        -0.000066,
        0.0007504,
        0.0014151,
        0.0014296,
        0.0005191,
        -0.001085,
        -0.002598,
        -0.003004,
        -0.001649,
        0.0011934,
        0.0041857,
        0.0054630,
        0.0036893,
        -0.000909,
        -0.006231,
        -0.009117,
        -0.007091,
        -0.000131,
        0.0086708,
        0.0142748,
        0.0123995,
        0.0024120,
        -0.011397,
        -0.021350,
        -0.020396,
        -0.006656,
        0.0142468,
        0.0310036,
        0.0323573,
        0.0140527,
        -0.017013,
        -0.044570,
        -0.050833,
        -0.026982,
        0.0194756,
        0.0654457,
        0.0823553,
        0.0517310,
        -0.021417,
        -0.105190,
        -0.151004,
        -0.114375,
        0.0226619,
        0.2383870,
        0.4748996,
        0.6582662,
        0.7272740,
        0.6582662,
        0.4748996,
        0.2383870,
        0.0226619,
        -0.114375,
        -0.151004,
        -0.105190,
        -0.021417,
        0.0517310,
        0.0823553,
        0.0654457,
        0.0194756,
        -0.026982,
        -0.050833,
        -0.044570,
        -0.017013,
        0.0140527,
        0.0323573,
        0.0310036,
        0.0142468,
        -0.006656,
        -0.020396,
        -0.021350,
        -0.011397,
        0.0024120,
        0.0123995,
        0.0142748,
        0.0086708,
        -0.000131,
        -0.007091,
        -0.009117,
        -0.006231,
        -0.000909,
        0.0036893,
        0.0054630,
        0.0041857,
        0.0011934,
        -0.001649,
        -0.003004,
        -0.002598,
        -0.001085,
        0.0005191,
        0.0014296,
        0.0014151,
        0.0007504,
        -0.000066,
        -0.000624,
        -0.000765,
        -0.000577,
        -0.000261,
        0.0000737,
        0.0001281,
        0.0001355,
        0.0000846,
        0.0000333,
 };

/**************************************************************************
 *                         函数实现
 **************************************************************************/
UINT32 BspInitRxScanChBndMapTbl(UINT32 mapnum ,T_ChBndMapInfo *maptbl)
{
    INPUT_POINTER_CHECK(maptbl);    

    s_ChBndMapNum = mapnum;
    s_ChBndMap = maptbl;

    return BSP_OK;
}

UINT32 BspGetRxScanChBndPos(UINT32 bspchn,UINT32 band)
{
    UINT32 j = 0;
    UINT32 mapval = ERROR_NULL_POINTER;    
  
    INPUT_POINTER_CHECK(s_ChBndMap);
    
    for(j=0;j<s_ChBndMapNum;j++)        
    {         
        if((s_ChBndMap[j].chan == bspchn) &&\
            (s_ChBndMap[j].band == band))
        {
            return (s_ChBndMap[j].index);
        }
    }

    return mapval;    
}

UINT32 BspDpdicSampleDateFileUINT(UINT32 *pDataTemp,char *pFileName ,UINT32 point)
{
    FILE *finFile  = NULL;
    UINT32 pointLoop = 0;
    INT32  fprtRet = 0;
    INT32  fclsRet = 0;
    INPUT_POINTER_CHECK(pDataTemp);
    INPUT_POINTER_CHECK(pFileName);


    finFile = fopen(pFileName,"w+");

    if((NULL == finFile))
    {
        return BSP_ERROR;
    }


   for(pointLoop = 0;pointLoop<point;pointLoop ++)
   {
	   fprtRet = fprintf(finFile,"0x%0x\n",pDataTemp[point]);
	   FPRINTF_CHECK(fprtRet);
   }
   fclsRet = fclose(finFile);
   FCLOSE_CHECK(fclsRet);
   return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetRxScanMaxChnNum
*  功能描述   : 设置场强扫描基本参数信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspSetDpdicRxScanMaxChnNum(UINT32 maxChnNum)
{
	s_icRxScanMaxChnNum = maxChnNum;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanMaxChnNum
*  功能描述   : 获取频谱扫描最大通道数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetDpdicRxScanMaxChnNum(VOID)
{
	 return s_icRxScanMaxChnNum;
}
/*****************************************************************************
*  函数名称   : BspSetFpgaRxScanParaInfo
*  功能描述   : 设置fpga场强扫描基本参数信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetDpdicRxScanParaInfo(UINT32 rxScanChnNum,T_DPDIC_RXSCAN *pIcRxScanInfo)
{
	UINT32 chnLoop  = 0;
	INPUT_POINTER_CHECK(pIcRxScanInfo);
	if(rxScanChnNum > (BspGetDpdicRxScanMaxChnNum()))
	{
		dbgErr("[%s] IcRxScanChnNum'%d is Over Max Chn'%d \n",__FUNCTION__,rxScanChnNum,BspGetDpdicRxScanMaxChnNum());
		return BSP_ERROR;
	}
	memcpy_s(s_pIcRxScanChnInfo,sizeof(T_DPDIC_RXSCAN),pIcRxScanInfo,sizeof(T_DPDIC_RXSCAN));
    for(chnLoop = 0;chnLoop < rxScanChnNum;chnLoop ++)
    {
        BspSetRxScanCommInfo(chnLoop,&s_pIcRxScanChnInfo->rxScanCommon[chnLoop]);
    }
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetFpgaRxScanParaInfo
*  功能描述   : 获取fpga场强扫描功基础参数信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspGetDpdicRxScanParaInfo(T_DPDIC_RXSCAN *pIcRxScanInfo)
{
	INPUT_POINTER_CHECK(pIcRxScanInfo);
	memcpy_s(pIcRxScanInfo,sizeof(T_DPDIC_RXSCAN),s_pIcRxScanChnInfo,sizeof(T_DPDIC_RXSCAN));
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspFpgaRxScanChnInfoInit
*  功能描述   : fpgaRxScan 通道配置初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspDpdicRxScanChnInfoInit()
{

    if ((s_pIcRxScanChnInfo != NULL))
    {
        return BSP_OK;
    }
    s_pIcRxScanChnInfo = (T_DPDIC_RXSCAN *)malloc(sizeof(T_DPDIC_RXSCAN));
    if (s_pIcRxScanChnInfo == NULL)
    {
        dbgInfo("[%s]IC RxScan Chn malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(s_pIcRxScanChnInfo, 0, sizeof(T_DPDIC_RXSCAN));

    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspFpgaRxScanMemInfoInit
*  功能描述   : CFR 所需要空间初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/

UINT32 BspDpdicRxScanMemInfoInit(UINT32 icRxScanChnNum)
{
    BspInitRxScanCommInfo(icRxScanChnNum);
    BspDpdicRxScanChnInfoInit();
    return BSP_OK;
}

/*****************************************************************************
*  函数名称    : BspFpgaNcoMoveCal()
*  功能描述    : FPGA NCO 搬移
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数    : adcType  -- ADC 采样类型 0 :实采样 1:复采样
*         : samplePoint -- 采数点数
*         : pSampleData --  输入数据
*  输出参数   : 无
*  返 回 值    : BSP_OK或错误码
*  其它说明   :NCO计算公式为   y(n) = x(n) .* exp(j*2*pi*fo/fs*n)
                         经过转化后为       y(n) = x(n)*(cos(Qn)+jSin(Qn))
           Qn 	= 2*pi*fo/fs*n
           X(n) = (I+jQ)
           Y(n) = (I+jQ)*(cos(Qn)+jSin(Qn)) = (I*cos(Qn)-Q*Sin(Qn))+j(I*sin(Qn)+Q*cos(Qn))
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)

*----------------------------------------------------------------------------
*/
UINT32 BspDpdicNcoMoveCal(UINT32 bspRxChn,UINT32 band,UINT32 samplePoint,UINT32 *pSampleData,DOUBLE *pRealOutData,DOUBLE *pImagOutData)
{
	UINT32 retVal       = BSP_OK;
	DOUBLE realTemp 	= 0.0;
	DOUBLE imagTemp 	= 0.0;
	INT16  real     	= 0;
	INT16  imag     	= 0;
	UINT32 pointLoop 	= 0;
	DOUBLE dQn      	= 0.0;
	DOUBLE dQnRadian	= 0.0;
	DOUBLE *pReal   	= NULL;
	DOUBLE *pImag  		= NULL;
	INT32  dpdicFo       = 0;
	INT32  dpdicFs       = 0;
	INPUT_POINTER_CHECK(pSampleData);
	INPUT_POINTER_CHECK(pRealOutData);
	INPUT_POINTER_CHECK(pImagOutData);
	pReal  = (DOUBLE*)malloc(sizeof(DOUBLE)*samplePoint);
	if(pReal == NULL)
	{
		free(pReal);
		dbgInfo("[%s] malloc failed\n",__FUNCTION__);
		return BSP_ERROR;
	}
	pImag  = (DOUBLE*)malloc(sizeof(DOUBLE)*samplePoint);
	if(pImag == NULL)
	{
		free(pReal);
		free(pImag);
		dbgInfo("[%s] malloc failed\n",__FUNCTION__);
		return BSP_ERROR;
	}
	memset(pReal,0,sizeof(DOUBLE)*samplePoint);
	memset(pImag,0,sizeof(DOUBLE)*samplePoint);
	double tempsin = 0.0;
	double tempcos = 0.0;
	retVal |= BspGetRxScanFs(bspRxChn,(UINT32 *)&dpdicFs);
    if((retVal != BSP_OK)||(dpdicFs == (INT32)0))
	{
		dbgErr("[%s]Get RxScanChn'%d Fs'%d Error \n",__FUNCTION__,bspRxChn,dpdicFs);
		free(pReal);
	    free(pImag);
		return BSP_ERROR;
	}
    retVal |= BspGetRxScanFo(bspRxChn,band,&dpdicFo);
    dbgInfoEx("%s dpdicFo %d \n",__FUNCTION__,dpdicFo);

    if((retVal != BSP_OK)||(dpdicFo == (INT32)0))
	{
		dbgErr("[%s]Get RxScanChn'%d Fo'%d Error \n",__FUNCTION__,bspRxChn,dpdicFo);
	}
	dQn = (DOUBLE)(2.0* PI * dpdicFo / dpdicFs);

	for(pointLoop = 0;pointLoop < samplePoint; pointLoop++)
	{
		dQnRadian   =  dQn * (DOUBLE)(pointLoop + (UINT32)1);
		real        = (INT16)((pSampleData[pointLoop]>>(UINT32)16)&(UINT32)0xFFFF);   /*实部*/
		imag        = (INT16)(pSampleData[pointLoop]& (UINT32)0xFFFF);      /*虚部*/
		realTemp    = (DOUBLE)real;
		imagTemp    = (DOUBLE)imag;
		tempsin     = sin(dQnRadian);
		tempcos     = cos(dQnRadian);
		/*Y(n) = (I+jQ)*(cos(Qn)+jSin(Qn)) = (I*cos(Qn)-Q*Sin(Qn))+j(I*sin(Qn)+Q*cos(Qn))*/
		pReal[pointLoop]  = realTemp * tempcos - imagTemp * tempsin;/*(I*cos(Qn)-Q*Sin(Qn))*/
		pImag[pointLoop]  = realTemp * tempsin + imagTemp * tempcos;/*(I*sin(Qn)+Q*cos(Qn))*/
	}
	memcpy_s(pRealOutData,sizeof(DOUBLE)*samplePoint,pReal,sizeof(DOUBLE)*samplePoint);
	memcpy_s(pImagOutData,sizeof(DOUBLE)*samplePoint,pImag,sizeof(DOUBLE)*samplePoint);
	free(pReal);
	free(pImag);

	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspFpgaSampleDataCombin()
*  功能描述   : FPGA 数据采集合并数据实部虚部合并为32bit
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*         : samplePoint -- 需要取数据的点数
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :a:数据转化为实部在低16BIT,虚部在高16BIT 并统一到4096点‘
               修改:算法同事建议使用浮点计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspDpdicSampleDataCombin(UINT32 samplePoint,DOUBLE *pInRealData,DOUBLE *pInImagData,DOUBLE *pOutRealData,DOUBLE *pOutImagData)
{
	UINT32 pointLoop     = 0;
	UINT32 sampleNum   	= 0;
	INPUT_POINTER_CHECK(pInRealData);
	INPUT_POINTER_CHECK(pInImagData);
	INPUT_POINTER_CHECK(pOutRealData);
	INPUT_POINTER_CHECK(pOutImagData);

	if(samplePoint < (UINT32)FFT_MAX_NUM)
	{
		sampleNum = samplePoint;
	}
	else
	{
		sampleNum = FFT_MAX_NUM;
	}
	for(pointLoop = 0;pointLoop < sampleNum;pointLoop ++)
	{
		pOutRealData[pointLoop] = pInRealData[pointLoop/* + SCREEN_SAMPLE*/];
		pOutImagData[pointLoop] = pInImagData[pointLoop/* + SCREEN_SAMPLE*/];
	}
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspFpgaSampleDataCombin()
*  功能描述   : FPGA 数据采集合并数据实部虚部合并为32bit
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*         : samplePoint -- 需要取数据的点数
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :a:数据转化为实部在低16BIT,虚部在高16BIT 并统一到4096点‘
               修改:算法同事建议使用浮点计算。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspDpdicSampleDataCovertIQ(UINT32 samplePoint,UINT32 band,UINT32 *pSampleData,DOUBLE *pOutRealData,DOUBLE *pOutImagData)
{
	UINT32 pointLoop    = 0;
	UINT32 sampleNum   	= 0;
	INT16  real     	= 0;
	INT16  imag     	= 0;
	FILE *finI   = NULL;
    FILE *finQ   = NULL;
    CHAR filename[2][40] = {0};
    INT32  fprtRet = 0;
    INT32 fclsRet = 0;
    INT32  snpRet = 0;
	INPUT_POINTER_CHECK(pSampleData);
	INPUT_POINTER_CHECK(pOutRealData);
	INPUT_POINTER_CHECK(pOutImagData);
    
	snpRet = snprintf_s(filename[0], 40,"./DPDIC_I_covert_B%d.txt",band);
	SNPRINTF_S_CHECK(snpRet,40);
	finI = fopen(filename[0],"w+");

	if((NULL == finI))
	{
		return BSP_ERROR;
	}
    
	snpRet = snprintf_s(filename[1],40, "./DPDIC_Q_covert_B%d.txt",band);
	SNPRINTF_S_CHECK(snpRet,40);
	finQ = fopen(filename[1],"w+");

	if((NULL == finQ))
	{
		fclsRet = fclose(finI);
		FCLOSE_CHECK(fclsRet);
		return BSP_ERROR;
	}
	if(samplePoint <= (UINT32)FFT_MAX_NUM)
	{
		sampleNum = samplePoint;
	}
	else
	{
		sampleNum = FFT_MAX_NUM;
	}
	for(pointLoop = 0;pointLoop < sampleNum;pointLoop ++)
	{
		real      			= (INT16)((pSampleData[pointLoop]>> (UINT32)16) & (UINT32)0xFFFF);  /*实部 I*/
		imag      			= (INT16)(pSampleData[pointLoop] & (UINT32)0xFFFF);       /*虚部 Q*/
		pOutRealData[pointLoop] = (DOUBLE)real;
		pOutImagData[pointLoop] = (DOUBLE)imag;
		fprtRet = fprintf(finI,"0x%0x\n",real);
		FPRINTF_CHECK(fprtRet);
		fprtRet = fprintf(finQ,"0x%0x\n",imag);
		FPRINTF_CHECK(fprtRet);

	}
	fclsRet = fclose(finI);
	FCLOSE_CHECK(fclsRet);
	fclsRet = fclose(finQ);
	FCLOSE_CHECK(fclsRet);
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspFpgaFftSample()
*  功能描述   : FPGA FFT SAMPLE 采数模块
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : pulSampleData  -- 4096个复数 低16bit 实部，高16bit虚部
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspDpdicFftSample(UINT32 bspRxChn,UINT32 band,T_DPDIC_SAMPLE_INFO *pFftPara,DOUBLE *pSampleRealData,DOUBLE *pSampleImageData)
{
    UINT32 retVal       = BSP_OK;
    UINT32 sampleNum    = 16384;  /* 采集的数据需要的采数点数(长度)*/
    UINT32 dpdicFs      = 0;
    UINT32 ulSampleFlag = 0;
    UINT32 *pOutDataTemp = NULL;
    DOUBLE *pOutRealTemp = NULL;
    DOUBLE *pOutImagTemp = NULL;
    DOUBLE *pdInRealTemp = NULL;
    DOUBLE *pdInImagTemp = NULL;
    ULONG  ulHbfSampleLen = 0;
    ULONG  ulEfSampleLen  = 0;
    FILE *fin = NULL;
    CHAR filename[40] = {0};
    UINT32 loopIdx = 0;
    UINT32 datanum = 0;
    UINT32 difChipId = 0;
    UINT32 difChan = 0;
    UCHAR *pucBuffer = NULL;
    int fclsRet = 0;
    UINT32 sampleFs[] = {122880,184320,245760,368640,491520,737280};
    UINT32 samleFsNum = NELEMENTS(sampleFs);
    T_DPDIC_SAMPLE_INFO *pDpdicSampleInfo = NULL;

    INPUT_POINTER_CHECK(pSampleRealData);
    INPUT_POINTER_CHECK(pSampleImageData);
    INPUT_POINTER_CHECK(pFftPara);

    pDpdicSampleInfo = (T_DPDIC_SAMPLE_INFO*)pFftPara;
    sampleNum = pDpdicSampleInfo->sampleNum;

    if(BSP_OK != BspGetDifInfoByRfChn(bspRxChn, RX, &difChipId, &difChan))
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d,%d,%d) return error\n", __FUNCTION__, bspRxChn, difChipId, difChan);
        return BSP_ERROR;
    }

    retVal |= BspGetRxScanFs(bspRxChn,&dpdicFs);

    for(loopIdx=0; loopIdx<samleFsNum; loopIdx++)
    {
        if(dpdicFs == sampleFs[loopIdx])
        {
            ulSampleFlag = loopIdx;
            break;
        }
    }

    dbgInfoEx("%s dpdicFs %d sampleflg %d \n",__FUNCTION__,dpdicFs,ulSampleFlag);

    pOutDataTemp    =(UINT32 *)malloc(sizeof(DOUBLE)*sampleNum);

    INPUT_POINTER_CHECK(pOutDataTemp);
    
    pOutRealTemp    =(DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pOutRealTemp == NULL)
    {
        dbgInfo("%s malloc failed!",__FUNCTION__);
        free(pOutDataTemp);
        return BSP_ERROR;
    }

    pOutImagTemp    =(DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pOutImagTemp == NULL)
    {
        dbgInfo("%s malloc failed!",__FUNCTION__);
        free(pOutDataTemp);
        free(pOutRealTemp);
        return BSP_ERROR;
    }

    pdInRealTemp  =(DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pdInRealTemp == NULL)
    {
        dbgInfo("%s malloc failed!",__FUNCTION__);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        return BSP_ERROR;
    }

    pdInImagTemp  =(DOUBLE *)malloc(sizeof(DOUBLE)*sampleNum);
    if(pdInImagTemp == NULL)
    {
        dbgInfo("%s malloc failed!",__FUNCTION__);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        return BSP_ERROR;
    }

    memset(pOutDataTemp, 0,(sizeof(DOUBLE)*sampleNum));
    memset(pOutRealTemp, 0,(sizeof(DOUBLE)*sampleNum));
    memset(pOutImagTemp, 0,(sizeof(DOUBLE)*sampleNum));
    memset(pdInRealTemp, 0,(sizeof(DOUBLE)*sampleNum));
    memset(pdInImagTemp, 0,(sizeof(DOUBLE)*sampleNum));

	/*  1  采数  */
    UlChSetCdcSmp(difChan,ulSampleFlag);
    IcHalApiSampleUlCh(difChan,1);

    fclsRet = snprintf_s(filename,40, "sampleUlCh.bin");
    SNPRINTF_S_CHECK(fclsRet, 40);

    if((fopen_s(&fin,filename, "r+") != 0) || (fin == NULL))
    {
        dbgErr("%s: open %s failed!\n",__FUNCTION__,filename);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        free(pdInImagTemp);

        return BSP_ERROR;
    }

    if (NULL == (pucBuffer = (UCHAR *)malloc(sizeof(UINT32)*(sampleNum+32))))
    {
        dbgErr("Fail to get memory! error code: %s\n", zte_strerror_s(errno));
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        free(pdInImagTemp);

        fclsRet = fclose(fin);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }

    /* 2.从文件读取数据 */
    datanum = fread(pucBuffer, 1, sizeof(UINT32)*(sampleNum+32), fin);
    memcpy_s(pOutDataTemp, sizeof(UINT32)*sampleNum, pucBuffer+32*sizeof(UINT32), sizeof(UINT32)*sampleNum);
    if((datanum != sizeof(UINT32)*(sampleNum+32)))
    {
        dbgErr("[%s]read file '%d  Error \n",__FUNCTION__,datanum);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        free(pdInImagTemp);
        free(pucBuffer);

        fclsRet = fclose(fin);
        FCLOSE_CHECK(fclsRet);
        return RX_SCAN_FREQ_FFT_SAMPLE_FAILE;
    }
    /*3.NCO搬移   FS 92.16M 为基准对齐，如果不是92.16M需要进行NCO搬移 */
    dbgInfoEx("%s dpdicFs %d sampleNum %d \n",__FUNCTION__,dpdicFs,sampleNum);

    if(dpdicFs == 0)
    {
        dbgErr("[%s]Get RxScanChn'%d Fs'%d Error \n",__FUNCTION__,bspRxChn,dpdicFs);
        free(pOutDataTemp);
        free(pOutRealTemp);
        free(pOutImagTemp);
        free(pdInRealTemp);
        free(pdInImagTemp);
        free(pucBuffer);

        fclsRet = fclose(fin);
        FCLOSE_CHECK(fclsRet);
        return RX_SCAN_FREQ_FFT_SAMPLE_FAILE;
    }

    retVal |= BspDpdicNcoMoveCal(bspRxChn,band, sampleNum,pOutDataTemp, pOutRealTemp,pOutImagTemp);

    /*4.如果不是92.16M需要进行数据抽取 */
    if((dpdicFs != (UINT32)RXSCAN_SAMPLERATE))
    {
        /*sample data to 1/2 1/4 1/8*/
        retVal |= BspDpdIcHbfCal(sampleNum,dpdicFs,pOutRealTemp,pOutImagTemp,pdInRealTemp,pdInImagTemp,&ulHbfSampleLen);

        /*if ulsample is 245.76/491.52 ,should 3/4 sample*/
        IF_CHK((245760 == dpdicFs) ||(491520 == dpdicFs))
        {
            memcpy_s(pOutRealTemp, (sizeof(DOUBLE)*sampleNum), pdInImagTemp, (sizeof(DOUBLE)*sampleNum));
            memcpy_s(pOutImagTemp, (sizeof(DOUBLE)*sampleNum), pdInRealTemp, (sizeof(DOUBLE)*sampleNum));
            memset(pdInRealTemp, 0,(sizeof(DOUBLE)*sampleNum));
            memset(pdInImagTemp, 0,(sizeof(DOUBLE)*sampleNum));

            ulEfSampleLen = ulHbfSampleLen;

            BspSetRx3P4EfCoefCfg(g_dRxHbfCoef_3p4Ef, NELEMENTS(g_dRxHbfCoef_3p4Ef));
            retVal |= BspDpdIc3P4EfCal(ulEfSampleLen, pOutImagTemp, pOutRealTemp,pdInRealTemp, pdInImagTemp, &ulHbfSampleLen);
        }

        memset(pOutRealTemp, 0,(sizeof(DOUBLE)*sampleNum));
        memset(pOutImagTemp, 0,(sizeof(DOUBLE)*sampleNum));

        retVal |= BspDpdicSampleDataCombin(ulHbfSampleLen, pdInRealTemp, pdInImagTemp,pSampleRealData,pSampleImageData);
    }
    else
    {
        retVal |= BspDpdicSampleDataCovertIQ(sampleNum,band,pOutDataTemp,pSampleRealData,pSampleImageData);
    }

    free(pOutDataTemp);
    free(pOutRealTemp);
    free(pOutImagTemp);
    free(pdInRealTemp);
    free(pdInImagTemp);
    free(pucBuffer);

    fclsRet = fclose(fin);
    FCLOSE_CHECK(fclsRet);

    return retVal;
}


vga_MTS_SwitchAgcByChan Vga_MTSSwitchAgcByChan(VOID)
{
    return s_pMTS_SwitchAgcByChan;
}

UINT32 BspGetMTSSwitchAgcByChan(vga_MTS_SwitchAgcByChan pCallBackFunc)
{
    s_pMTS_SwitchAgcByChan = pCallBackFunc;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetRxScanMtsAgcSw()
*  功能描述   : 控制MTS RX AGC开关
*  输入参数   : rxChan
*           sw      0： 关        1：开
*  输出参数   :
*  返 回 值     : BSP_OK或错误码
*  其它说明   : R9224系列机型 采数时控制MTS侧  AGC 切换到手动模式，并设置VGA的衰减值(R9234 切换IC侧)
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 张龙@2021-10-30 19:26:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxScanMtsAgcSw(UINT32 rxChan, UINT32 mode)
{
    INT32 attVal = 0;
    INT32 vgaVal = 0;
    UINT32 chip = 0;
    UINT32 difChipId = 0;
    UINT32 difChan = 0;
    UINT32 mtsChanNo = 0;
    vga_MTS_SwitchAgcByChan pMTS_SwitchAgcByChan = Vga_MTSSwitchAgcByChan();

    if(BSP_OK != BspGetTrxChipIdAndChanNoByRfChan(rxChan, RX,&chip, &mtsChanNo))
    {
        return BSP_ERROR;
    }
    if (BSP_OK != BspGetDifInfoByRfChn(rxChan, RX, &difChipId, &difChan))
    {
        dbgErr("%s BspGetDifInfoByRfChn(%d,%d,%d) return error\n", __FUNCTION__, rxChan, difChipId, difChan);
        return BSP_ERROR;
    }

    if ((VGA_MODE_AGC == BspGetVgaCtrlMode()&&(pMTS_SwitchAgcByChan != NULL)))
    {
        if(mode == MGC_MODE_MANUAL)
        {
            BspGetRxAtt(rxChan, &attVal);
            pMTS_SwitchAgcByChan(chip,mtsChanNo,MTS_AGC_MODE_MANUAL);
            BspSetRxAtt(rxChan,attVal);
            BspSetRxScanVgcGain(rxChan,attVal);
        }
        else if(mode == MGC_MODE_MGC)
        {
            pMTS_SwitchAgcByChan(chip,mtsChanNo,MTS_AGC_MODE_AGC);
        }

        return BSP_OK;
    }

    if (mode == MGC_MODE_MANUAL)  /* AGC 切手动模式*/
    {
        BspGetRxAtt(rxChan, &attVal);
        BspGetRxVga(rxChan, &vgaVal);
        dbgInfoEx("%s>>chip = %d, ttVal = %d, rxChan = %d !  \n", __FUNCTION__, chip, attVal+vgaVal, rxChan);

        BspHalAdaptSetVgaModeByChan(difChan, MGC_MODE_MANUAL);   /*0:agc 1:mgc1 2:mgc2 3:manual*/
        BspHalAdaptSetManualAtt(rxChan, abs(attVal)/50);
        BspHalAdaptSetManualVga(rxChan, abs(vgaVal)/50);

        BspSetRxScanVgcGain(rxChan,attVal+vgaVal);
    }
    else if (mode == MGC_MODE_MGC) /* AGC 切MGC模式*/
    {
        BspHalAdaptSetVgaModeByChan(difChan, MGC_MODE_MGC);   /*0:agc 1:mgc1 2:mgc2 3:manual*/
    }

    return BSP_OK;
}

UINT32 BspSetMtsAgcMode(UINT32 mode)
{
    rxScanMtsAgcMode = mode;

    return BSP_OK;
}

UINT32 BspGetMtsAgcMode()
{
    return rxScanMtsAgcMode;
}

UINT32 BspSetVgaCtrlMode(UINT32 mode)
{
	s_VgaCtrlMode = mode;

    return BSP_OK;
}

UINT32 BspGetVgaCtrlMode(VOID)
{
    return s_VgaCtrlMode;
}
/*****************************************************************************
*  函数名称   : BspFpgaRxScanFftSample()
*  功能描述   : 获取上行频谱扫描采数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspDpdicRxScanFftSample(UINT32 bspRxChn,UINT32 band)
{
    UINT32 retVal = BSP_OK;
    T_DPDIC_RXSCAN *pDpdicRxScanInfo = NULL;
    UINT32 dpdicRxAgcGain   = 0;
    UINT32 sampleTimes      = 0;/*采数次数*/
    UINT32 sampleLoop       = 0;
    UINT32 samplePiontNum   = 0;/*采数点数*/
    double *pDpdicFftReal   = NULL;
    double *pDpdicFftImag   = NULL;

    pDpdicRxScanInfo    = (T_DPDIC_RXSCAN*)malloc(sizeof(T_DPDIC_RXSCAN));

    if(pDpdicRxScanInfo == NULL)
    {
        dbgErr("[%s]Malloc Space is Error\n",__FUNCTION__);
        return RX_SCAN_FREQ_FFT_SAMPLE_FAILE;
    }

    /*1.先将上行VGA置为手动模式 */
    BspSetRxScanMtsAgcSw(bspRxChn, MGC_MODE_MANUAL);
    BspSetMtsAgcMode(MGC_MODE_MANUAL);

    if(retVal!= BSP_OK)
    {
        dbgInfoEx("[%s]RxScanChn'%d Agc Gain'%d Set Error \n",__FUNCTION__,bspRxChn,dpdicRxAgcGain);
    }

    memset(pDpdicRxScanInfo,    0, sizeof(T_DPDIC_RXSCAN));
    memset(s_dpdicFft_RealTmp,0,sizeof(s_dpdicFft_RealTmp));
    memset(s_dpdicFft_ImagTmp,0,sizeof(s_dpdicFft_ImagTmp));

    /*2.从单板获取采数参数 */
    BspGetDpdicRxScanParaInfo(pDpdicRxScanInfo);

    sampleTimes = pDpdicRxScanInfo->rxScanCommon[bspRxChn].rxScanSampLoop;
    samplePiontNum = pDpdicRxScanInfo->dpdicSample.sampleNum;

    dbgInfoEx("%s sampleTimes %d  fsamplePiont %d \n",__FUNCTION__,sampleTimes,samplePiontNum);

    pDpdicFftReal    = (DOUBLE*)malloc((sizeof(DOUBLE))* sampleTimes * samplePiontNum);

    if(pDpdicFftReal == NULL)
    {
        free(pDpdicRxScanInfo);
        dbgErr("[%s]FpgaFftSample Malloc Space is Error\n",__FUNCTION__);
        return RX_SCAN_FREQ_FFT_SAMPLE_FAILE;
    }
    pDpdicFftImag    = (DOUBLE*)malloc((sizeof(DOUBLE))* sampleTimes * samplePiontNum);
    if(pDpdicFftImag == NULL)
    {
        free(pDpdicFftReal);
        free(pDpdicRxScanInfo);
        dbgErr("[%s]FpgaFftSample Malloc Space is Error\n",__FUNCTION__);
        return RX_SCAN_FREQ_FFT_SAMPLE_FAILE;
    }
    /*3.从DUl盲采数*/
    for(sampleLoop = 0;sampleLoop < sampleTimes;sampleLoop ++)
    {
        retVal|=BspDpdicFftSample(bspRxChn,band,&pDpdicRxScanInfo->dpdicSample,&pDpdicFftReal[sampleLoop* samplePiontNum],&pDpdicFftImag[sampleLoop* samplePiontNum]);
    }
    /*4上行VGA恢复自动模式 */
    BspSetRxScanMtsAgcSw(bspRxChn, MGC_MODE_MGC);
    BspSetMtsAgcMode(MGC_MODE_MGC);
    /*5数据保存 */
    samplePiontNum = pDpdicRxScanInfo->rxScanCommon[bspRxChn].fftCalcNum;
    retVal |= BspSetRxScanSampleData(sampleTimes,samplePiontNum,pDpdicFftReal,pDpdicFftImag);
    free(pDpdicFftReal);
    free(pDpdicFftImag);
    free(pDpdicRxScanInfo);

    return retVal;
}
/*****************************************************************************
*  函数名称   : BspInitFpgaRxScanModuleFunc
*  功能描述   : FPGA 频谱扫描功能初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitDpdicRxScanModuleFunc(VOID)
{
	UINT32 retVal           		= BSP_OK;
	T_RxScanModule *pRxScanModule 	= NULL;
	UINT32 rxRxScanInitFlag         = DPDIC_RXSCAN_FUNC_UNINIT;
	UINT32 icRxScanChnNum           = 0;

	rxRxScanInitFlag      = BspGetRxScanFuncInitFlag();
	pRxScanModule         = (T_RxScanModule *)BspGetRxScanModuleInfo();
	icRxScanChnNum      = BspGetRxChannel();
	BspSetDpdicRxScanMaxChnNum(icRxScanChnNum);
	if (rxRxScanInitFlag == (UINT32)DPDIC_RXSCAN_FUNC_INIT)
	{
		return retVal;
	}

	BspDpdicRxScanMemInfoInit(icRxScanChnNum);

	pRxScanModule->rxScanSample 	= BspDpdicRxScanFftSample;
	pRxScanModule->rxScanCalc   	= BspRxScanFftCalc;
	pRxScanModule->rxScanGetDate	= BspGetRxScanCountData;
	pRxScanModule->rxScanGetFreq	= BspGetRxScanFreqInfo;
	pRxScanModule->rxScanRstDate	= BspRestRxScanAllData;
	return retVal;
}

/*****************************************************************************
*  函数名称   : IntPub_UnitFunc_RxHbfCoefCfg
*  功能描述   : 半带滤波器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : dHbfCoef      - 表格系数
*             : ulLength      - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxHbfCoefCfg(DOUBLE* dHbfCoef,ULONG ulLength)
{
	UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(dHbfCoef);  
    g_ptRxHbfInfo.pdCoefArray = dHbfCoef;    
    g_ptRxHbfInfo.ulCoefLen = ulLength;
	return retVal;
}

/*****************************************************************************
*  函数名称   : IntPub_UnitFunc_GetRxHbfCoefCfg
*  功能描述   : 半带滤波器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : dHbfCoef      - 表格系数
*             : ulLength      - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
ULONG BspGetRxHbfCoefCfg(T_RX_SAMPLE_COEF_CFG* ptRxfCoefCfg)
{
   INPUT_POINTER_CHECK(ptRxfCoefCfg);

    memcpy_s(ptRxfCoefCfg,sizeof(T_RX_SAMPLE_COEF_CFG),&g_ptRxHbfInfo,sizeof(T_RX_SAMPLE_COEF_CFG));
    
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : IntPub_UnitFunc_GetRx3P4EfCoefCfg
*  功能描述   : 3/4抽取滤波器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : dRx3P4EfCoef   - 表格系数
*             : ulLength       - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
ULONG BspGetRx3P4EfCoefCfg(T_RX_SAMPLE_COEF_CFG* ptRxfCoefCfg)
{
    INPUT_POINTER_CHECK(ptRxfCoefCfg);

    memcpy_s(ptRxfCoefCfg,sizeof(T_RX_SAMPLE_COEF_CFG),&g_ptRx3P4EfInfo,sizeof(T_RX_SAMPLE_COEF_CFG));
    
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetRx3P4EfCoefCfg
*  功能描述   : 3/4抽取滤波器
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : dRx3P4EfCoef   - 表格系数
*             : ulLength       - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
ULONG BspSetRx3P4EfCoefCfg(DOUBLE* dRx3P4EfCoef,ULONG ulLength)
{
    INPUT_POINTER_CHECK(dRx3P4EfCoef);
    g_ptRx3P4EfInfo.pdCoefArray = dRx3P4EfCoef;
    g_ptRx3P4EfInfo.ulCoefLen = ulLength;
   	return BSP_OK;
}


ULONG BspRxScanParaReInitCallBack(RxScan_ParaInit ucFunc)
{
	INPUT_POINTER_CHECK(ucFunc);
	
	g_Func_RxScanParaReInit = ucFunc;

	return BSP_OK;
}

ULONG BspRxScanParaReInitFunc(void)
{
	ULONG ulRet = BSP_OK;
	if(g_Func_RxScanParaReInit != (RxScan_ParaInit)NULL)
    {
		ulRet = g_Func_RxScanParaReInit();
	}
	return ulRet;
}

/*****************************************************************************
*  函数名称   : BspDpdIcHbfCal()
*  功能描述   : HBF 半带滤波器计算
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulRxChan   -- rx 通道号
*             : ulAdcType  -- ADC 采样类型 0 :实采样 1:复采样
*             : ulSubFreqBand -- 中频上行频段 DPDIC
*             : ulSamplePoint -- 采数点数
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
ULONG BspDpdIcHbfCal(ULONG ulSamplePoint,ULONG ulSampleFs,DOUBLE *pdInRealData,DOUBLE *pdInImagData,DOUBLE *pdOutRealData,DOUBLE *pdOutImagData,ULONG* pulOutDataLen)
{
    ULONG   ulOutDateLen        = 0;
    ULONG   ulHbfCoefLen        = 0;
    ULONG   ulLoop              = 0;
    ULONG   smapleNum           = (ulSampleFs/RXSCAN_SAMPLERATE)/2*2;
    DOUBLE *pdHbfCoef           = NULL;
    DOUBLE *pdOutRealDataTemp   = NULL;    
    DOUBLE *pdOutImagDataTemp   = NULL;
    T_RX_SAMPLE_COEF_CFG pRxCoefCfg ={0};

    INPUT_POINTER_CHECK(pdInRealData);
    INPUT_POINTER_CHECK(pdInImagData);
    INPUT_POINTER_CHECK(pdOutRealData);
    INPUT_POINTER_CHECK(pdOutImagData);  

    BspGetRxHbfCoefCfg(&pRxCoefCfg);
	ulHbfCoefLen = pRxCoefCfg.ulCoefLen;

    pdHbfCoef  = (DOUBLE*)malloc(sizeof(DOUBLE)*ulHbfCoefLen);
    if(NULL ==pdHbfCoef)
    {
        dbgInfo("%s malloc pdHbfCoef failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pdOutRealDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*(ulSamplePoint+ulHbfCoefLen));
    if(NULL ==pdOutRealDataTemp)
    {
        free(pdHbfCoef);
        dbgInfo("%s malloc pdOutRealDataTemp failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    pdOutImagDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*(ulSamplePoint+ulHbfCoefLen));
    if(NULL ==pdOutImagDataTemp)
    {
        free(pdHbfCoef);
        free(pdOutRealDataTemp);
        dbgInfo("%s malloc pdOutImagDataTemp failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset(pdHbfCoef,0,sizeof(DOUBLE)*ulHbfCoefLen);
    memset(pdOutRealDataTemp,0,sizeof(DOUBLE)*(ulSamplePoint+ulHbfCoefLen));
    memset(pdOutImagDataTemp,0,sizeof(DOUBLE)*(ulSamplePoint+ulHbfCoefLen));

    memcpy_s(pdHbfCoef,ulHbfCoefLen*sizeof(DOUBLE),pRxCoefCfg.pdCoefArray,ulHbfCoefLen*sizeof(DOUBLE));
    ConvolutionAlgorithm(pdInRealData,pdHbfCoef,ulSamplePoint,ulHbfCoefLen, pdOutRealDataTemp);
    ConvolutionAlgorithm(pdInImagData,pdHbfCoef,ulSamplePoint,ulHbfCoefLen, pdOutImagDataTemp);

    for(ulLoop = 0;ulLoop < (ulSamplePoint + ulHbfCoefLen);ulLoop ++)/*抽样到92.16采样率*/
    {
        if(ulLoop % smapleNum == (ULONG)0)
        {
            pdOutRealData[ulLoop/smapleNum] = pdOutRealDataTemp[ulLoop];
            pdOutImagData[ulLoop/smapleNum] = pdOutImagDataTemp[ulLoop];
            ulOutDateLen    ++;
            //BspSysMsDelay_Sys(50);
            //dbgInfoEx("[%s] Loop'%d real %.4f image %.4f\n",__FUNCTION__,ulLoop,pdOutRealData[ulLoop/smapleNum],pdOutImagData[ulLoop/smapleNum]);
        }
    }

    dbgInfoEx("ulOutDateLen = %d \n",ulOutDateLen);
    free(pdHbfCoef);
    free(pdOutRealDataTemp);
    free(pdOutImagDataTemp);

    *pulOutDataLen = ulOutDateLen;	

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : IntPub_UnitFunc_ConvolutionAlgorithm()
*  功能描述   : 卷积算法
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 
*             : 
*             : 
*             : 
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
ULONG ConvolutionAlgorithm(DOUBLE* dInData1,DOUBLE* dInData2,ULONG ulData1Len,ULONG ulData2Len,DOUBLE *dOutData)
{
    ULONG ulLoopN       = 0;
    ULONG ulLoopM       = 0;
    ULONG ulLoopNtemp   = 0;
    LONG  lLoopMtemp    = 0;
    DOUBLE *pdInData    = NULL;
    INPUT_POINTER_CHECK(dInData1);
    INPUT_POINTER_CHECK(dInData2);
    INPUT_POINTER_CHECK(dOutData);    
   
    pdInData = (DOUBLE*)malloc(sizeof(DOUBLE)*(ulData1Len+ulData2Len));
	if(pdInData == NULL)
	{
		return BSP_ERROR;
	}
    memcpy_s(pdInData,ulData1Len*sizeof(DOUBLE),dInData1,ulData1Len*sizeof(DOUBLE));
    
    memset(&pdInData[ulData1Len],0,ulData2Len*sizeof(DOUBLE));

    dbgInfoEx("%s ulData1Len %d ulData2Len %d\n",__FUNCTION__,ulData1Len,ulData2Len);
   
    for(ulLoopN = 0,ulLoopM =0; (ulLoopN <ulData1Len + ulData2Len)||(ulLoopM<ulData2Len); ulLoopN ++,ulLoopM ++)
	{
		if(ulLoopM >= ulData2Len )
		{
            ulLoopM = ulData2Len - (ULONG)1;
        }
		for(lLoopMtemp =ulLoopM,ulLoopNtemp = 0;(lLoopMtemp >= (LONG)0)&&(ulLoopNtemp <=ulLoopM);lLoopMtemp --,ulLoopNtemp ++)
		{
			
			dOutData[ulLoopN] +=pdInData[ulLoopN - ulLoopNtemp]*dInData2[ulLoopM - lLoopMtemp];

		}
	}
    free(pdInData);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspDpdIc3P4EfCal()
*  功能描述   : 3/4抽取滤波器计算
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ulRxChan   -- rx 通道号
*             : ulAdcType  -- ADC 采样类型 0 :实采样 1:复采样
*             : ulSubFreqBand -- 中频上行频段 DPDIC
*             : ulSamplePoint -- 采数点数
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
ULONG BspDpdIc3P4EfCal(ULONG ulSamplePoint,DOUBLE *pdInRealData,DOUBLE *pdInImagData,DOUBLE *pdOutRealData,DOUBLE *pdOutImagData,ULONG* pulOutDataLen)
{
    ULONG   ulOutDateLen        = 0;
    ULONG   ulEfCoefLen         = 0;
    ULONG   ulLoop              = 0;
    DOUBLE *pdEffCoef           = NULL;
    DOUBLE *pdOutRealDataTemp   = NULL;    
    DOUBLE *pdOutImagDataTemp   = NULL;  
    DOUBLE *pdInRealDataTemp   = NULL;    
    DOUBLE *pdInImagDataTemp   = NULL;  
    
    T_RX_SAMPLE_COEF_CFG pRxCoefCfg ={0};    

    INPUT_POINTER_CHECK(pdInRealData);
    INPUT_POINTER_CHECK(pdInImagData);
    INPUT_POINTER_CHECK(pdOutRealData);
    INPUT_POINTER_CHECK(pdOutImagData);
    
    BspGetRx3P4EfCoefCfg(&pRxCoefCfg);

    ulEfCoefLen = pRxCoefCfg.ulCoefLen;
    
    pdEffCoef         = (DOUBLE*)malloc(sizeof(DOUBLE)*ulEfCoefLen);
	if(NULL == pdEffCoef)
    {
        dbgInfo("%s malloc pdEffCoef failed\n",__FUNCTION__);
        return BSP_ERROR;
    }
	
    pdOutRealDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*(ulSamplePoint+ulEfCoefLen)*3);
    if(NULL == pdOutRealDataTemp)
    {
        free(pdEffCoef);
        dbgInfo("%s malloc pdOutRealDataTemp failed\n",__FUNCTION__);
        return BSP_ERROR;    
    }
	
    pdOutImagDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*(ulSamplePoint+ulEfCoefLen)*3);
	if(NULL == pdOutImagDataTemp)
    {
        free(pdEffCoef);
        free(pdOutRealDataTemp);
        dbgInfo("%s malloc pdOutImagDataTemp failed\n",__FUNCTION__);
        return BSP_ERROR;    
    }

    pdInRealDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*ulSamplePoint*3);
	if(NULL == pdInRealDataTemp)
    {
        free(pdEffCoef);
        free(pdOutRealDataTemp);
		free(pdOutImagDataTemp);
        dbgInfo("%s malloc pdInRealDataTemp failed\n",__FUNCTION__);
        return BSP_ERROR;    
    }

    pdInImagDataTemp = (DOUBLE*)malloc(sizeof(DOUBLE)*ulSamplePoint*3);
	if(NULL == pdInImagDataTemp)
    {
        free(pdEffCoef);
        free(pdOutRealDataTemp);
		free(pdOutImagDataTemp);
		free(pdInRealDataTemp);
        dbgInfo("%s malloc pdInImagDataTemp failed\n",__FUNCTION__);
        return BSP_ERROR;    
    }

    memset(pdEffCoef,0,sizeof(DOUBLE)*ulEfCoefLen);
    memset(pdOutRealDataTemp,0,sizeof(DOUBLE)*(ulSamplePoint+ulEfCoefLen)*3);
    memset(pdOutImagDataTemp,0,sizeof(DOUBLE)*(ulSamplePoint+ulEfCoefLen)*3);
    memset(pdInRealDataTemp,0,sizeof(DOUBLE)*ulSamplePoint*3);
    memset(pdInImagDataTemp,0,sizeof(DOUBLE)*ulSamplePoint*3);
    memcpy_s(pdEffCoef,ulEfCoefLen*sizeof(DOUBLE),pRxCoefCfg.pdCoefArray,ulEfCoefLen*sizeof(DOUBLE));   
    for(ulLoop = 0;ulLoop < ulSamplePoint * (ULONG)3;ulLoop ++)/*3倍插值*/
    {
        if(ulLoop % (ULONG)3 == 0)
        {
            pdInRealDataTemp[ulLoop] = pdInRealData[ulLoop/(ULONG)3];
            pdInImagDataTemp[ulLoop] = pdInImagData[ulLoop/(ULONG)3];            
        }
        else
        {
            pdInRealDataTemp[ulLoop]  = 0.0;
            pdInImagDataTemp[ulLoop]  = 0.0;
        }
        
    }   
    ConvolutionAlgorithm(pdInRealDataTemp,pdEffCoef,ulSamplePoint*(ULONG)3,ulEfCoefLen, pdOutRealDataTemp);
    ConvolutionAlgorithm(pdInImagDataTemp,pdEffCoef,ulSamplePoint*(ULONG)3,ulEfCoefLen, pdOutImagDataTemp);


    for(ulLoop = 0;ulLoop < ulSamplePoint * (ULONG)3;ulLoop ++)/*4倍抽取*/
    {
        if(ulLoop % (ULONG)4 == 0)
        {
            pdOutRealData[ulLoop/(ULONG)4] = pdOutRealDataTemp[ulLoop];
            pdOutImagData[ulLoop/(ULONG)4] = pdOutImagDataTemp[ulLoop];
            ulOutDateLen++;
            //BspSysMsDelay_Sys(50);
            //dbgInfoEx("[%s] Loop'%d real %.4f image %.4f\n",__FUNCTION__,ulLoop,pdOutRealData[ulLoop/4],pdOutImagData[ulLoop/4]);
        }       
    }
    *pulOutDataLen = ulOutDateLen;
    free(pdEffCoef);
    free(pdOutRealDataTemp);
    free(pdOutImagDataTemp);
    free(pdInRealDataTemp);
    free(pdInImagDataTemp);

    return BSP_OK;
 }


/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : rxscan_ic.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供IC 频谱扫描控制接口
 * 注意事项 : 无
 * 作    者 :
 * 创建日期 : 2021-1-8 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#ifndef _FUNCLIB_RXSCAN_IC4_2_H_
#define _FUNCLIB_RXSCAN_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "rxscancommon.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define SCREEN_SAMPLE                35           /* DPDIC 筛数起始点*/

#define HAL_ADC_SAMPLERATE_491M52 0
#define HAL_ADC_SAMPLERATE_368M64 1
#define HAL_ADC_SAMPLERATE_245M76 2
#define HAL_ADC_SAMPLERATE_184M32 3
#define HAL_ADC_SAMPLERATE_122M88 4
#define HAL_ADC_SAMPLERATE_92M16  5

#define MGC_MODE_MANUAL       0
#define MGC_MODE_MGC          2

#define MTS_AGC_MODE_MANUAL       3
#define MTS_AGC_MODE_MGC2         2
#define MTS_AGC_MODE_MGC1         1
#define MTS_AGC_MODE_AGC          0

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef struct tag_dpdic_sample_info
{
    UINT32 sampleChn;        /*频谱分析的通道*/
    UINT32 sampleBand;       /*频谱分析频段band*/
    UINT32 sampleNum;        /*频谱分析采集的数据需要的采数点数(长度)*/
    UINT32 adcType;			 /*频谱分析ADC采数模式(实采样/复采样) ADC 采样类型 0 :实采样 1:复采样*/
}T_DPDIC_SAMPLE_INFO;

typedef struct tag_fpga_rxscan
{
	T_DPDIC_SAMPLE_INFO 	dpdicSample;
	T_RXSCAN_COMMON_INFO    rxScanCommon[BSP_MAX_RX_CHAN];
}T_DPDIC_RXSCAN;

typedef struct tagT_ChBndMapInfo
{
    UINT32  index;
    UINT32  chan;
    UINT32  band;
}T_ChBndMapInfo;

typedef struct tag_rx_sample_filter_coef_cfg
{    
    DOUBLE *pdCoefArray;
    ULONG  ulCoefLen;
}T_RX_SAMPLE_COEF_CFG;

typedef ULONG (*Fft_SampleInit)(ULONG ulChan,VOID *pvFftPara,DOUBLE *pdSampleRealData,DOUBLE *pdSampleImagData);
typedef ULONG (*RxScan_ParaInit)(void);
typedef UINT32 (*vga_MTS_SwitchAgcByChan)(INT32 chip,UINT32 mtsChan,UINT32 vgaMode);
/**************************************************************************
 *                         函数接口
 **************************************************************************/




UINT32 BspInitIcRxScanModuleFunc(VOID);
UINT32 BspSetIcRxScanParaInfo(UINT32 rxScanChnNum,T_DPDIC_RXSCAN *pFpgaRxScanInfo);
UINT32 BspInitRxScanChBndMapTbl(UINT32 mapnum ,T_ChBndMapInfo *maptbl);
ULONG ConvolutionAlgorithm(DOUBLE* dInData1,DOUBLE* dInData2,ULONG ulData1Len,ULONG ulData2Len,DOUBLE *dOutData);
ULONG BspDpdIc3P4EfCal(ULONG ulSamplePoint,DOUBLE *pdInRealData,DOUBLE *pdInImagData,DOUBLE *pdOutRealData,DOUBLE *pdOutImagData,ULONG* pulOutDataLen);
ULONG BspDpdIcHbfCal(ULONG ulSamplePoint,ULONG ulSampleFs,DOUBLE *pdInRealData,DOUBLE *pdInImagData,DOUBLE *pdOutRealData,DOUBLE *pdOutImagData,ULONG* pulOutDataLen);
UINT32 BspDpdIcRxScanSetVgaAuto(UINT32 chip, UINT32 rxChan);
UINT32 BspDpdIcRxScanSetVgaManual(UINT32 chip,UINT32 rxChan);
UINT32 BspSetDpdicRxScanParaInfo(UINT32 rxScanChnNum,T_DPDIC_RXSCAN *pIcRxScanInfo);
UINT32 BspInitDpdicRxScanModuleFunc(VOID);
UINT32 BspSetRxHbfCoefCfg(DOUBLE* dHbfCoef,ULONG ulLength);
ULONG BspRxScanParaReInitCallBack(RxScan_ParaInit ucFunc);
UINT32 BspGetMTSSwitchAgcByChan(vga_MTS_SwitchAgcByChan pCallBackFunc);
UINT32 BspSetMtsAgcMode(UINT32 mode);
UINT32 BspSetVgaCtrlMode(UINT32 mode);
UINT32 BspGetVgaCtrlMode(VOID);
UINT32 BspSetRxHbfCoefCfg(DOUBLE* dHbfCoef,ULONG ulLength);
ULONG BspGetRxHbfCoefCfg(T_RX_SAMPLE_COEF_CFG* ptRxfCoefCfg);
UINT32 BspSetRxScanMtsAgcSw(UINT32 rxChan, UINT32 mode);
#ifdef __cplusplus
}
#endif

#endif


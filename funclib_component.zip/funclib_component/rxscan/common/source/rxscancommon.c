/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : rxscancommon.c
* 文件标识 : {[N/A]}
* 内容摘要 : 频谱扫描 模块公共功能具体实现接口
* 注意事项 : 进行频谱扫描的采数点数和计算点数有可能不一样，所以需要分开对待。实部在低16BIT,虚部在高16BIT
* 作    者 : wangfei
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <linux/sysctl.h>
#include <sys/mman.h>
#include <pthread.h>
#include <errno.h>
#include "bspcomm.h"
#include <math.h>
#include "rxscancommon.h"
#include "rxscanapi.h"
#include "ru_univdef.h"
#include "rruinfo.h"
#include "fft.h"
#include "exprn.h"
#include "rftable.h"
#include "chnmap_a.h"
#include "freqcfgcommon.h"
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
static DOUBLE s_fftWinCoef[FFT_MAX_NUM] = {0.0};
static DOUBLE s_fft_Out_Real[FFT_MAX_NUM] = {0.0}; /*FFT 计算输出数据实部*/
static DOUBLE s_fft_Out_Imag[FFT_MAX_NUM] = {0.0}; /*FFT 计算输出数据虚部*/
static DOUBLE s_fft_Out_Pow[FFT_MAX_NUM]  = {0.0};  /*FFT 计算多组数据累加*/
static DOUBLE s_fft_In_Real[FFT_MAX_NUM]  = {0.0};  /*FFT 计算输入数据实部*/
static DOUBLE s_fft_In_Imag[FFT_MAX_NUM]  = {0.0};  /*FFT 计算输入数据虚部*/
static DOUBLE *s_pFft_sample_Real  = NULL; /* 采数的数据实部*/
static DOUBLE *s_pFft_sample_Imag  = NULL; /* 采数的数据虚部*/
static UINT32 s_fft_sampletimes    = 0;    /* 采数的次数*/
static UINT32 s_fft_samplePointNum = 0;    /* 采数的点数*/
static FLOAT  s_fftW1[FFT_MAX_NUM]={0.0};
static FLOAT  s_fftW2[FFT_MAX_NUM]={0.0};
static INT16  s_fftC2[FFT_MAX_NUM]={0};

static UINT32  s_startFreq  = 0;
static UINT32  s_stopFreq   = 0;
static UINT32  s_rxScanStep = 0;
static UINT32 g_rfCenterFreq = 0;
static UINT32 g_rfCenterFreqList[BSP_MAX_RX_CHAN] = {0};
static UINT32  s_IcComp = 0;
static INT32  *s_pRxScanAgcGain = NULL  ;
static UINT32  s_rxScanSupportFlag = RXSCAN_FUNC_SUPPORT;/*默认支持*/

static T_RXSCAN_COMMON_INFO        *s_pRxScanCommInfo = NULL;
static T_RxScan                    s_rxScanData[FFT_MAX_NUM]={0};
static T_RxScanModule              s_rxScanFunc = {0};
static UINT32 s_rxScanMaxChnNum	= 0;

static char s_fftFileName[2][20]={"/connect.txt","/disconnect.txt"};
static pGetBandNcoVal s_pGetBadnNcoFunc = NULL;
static INT32 s_compsThreshold = -12000; //默认为-120dbm
static UINT32 s_rxScanOutOfBandId = 0;
RxScan_FreqLimit g_Func_RxScanFreqLimit = NULL;

pRxScanOutOfBandCompCali g_Func_RxScanOutOfBandCompCali = NULL;

static UINT32 s_rxscanIsSupportOutBand = RX_SCAN_NOT_SUPPORT_OUT_BAND;

extern ULONG tickGet();
extern unsigned long long tick64Get();
/**************************************************************************
 *                        宏定义
 **************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
    
/**************************************************************************
*                         函数实现
**************************************************************************/
UINT32 BspRxScanFreqLimit(RxScan_FreqLimit ucFunc)
{
	INPUT_POINTER_CHECK(ucFunc);

    g_Func_RxScanFreqLimit = ucFunc;

	return BSP_OK;
}

UINT32 BspSetRxScanIcComp(UINT32 comp)
{
	s_IcComp = comp;
	return BSP_OK;
}

UINT32 BspGetRxScanIcComp(UINT32 *comp)
{
	*comp = s_IcComp;
	return BSP_OK;
}



/*****************************************************************************
*  函数名称   : BspGetGxScanSampleData
*  功能描述   : 获取采数次数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspGetRxScanSampleTimes(VOID)
{
	return s_fft_sampletimes;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanSamplePointNum
*  功能描述   : 获取采数点数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspGetRxScanSamplePointNum(VOID)
{
	return s_fft_samplePointNum;
}
/*****************************************************************************
*  函数名称   : BspSetRxScanSampleData
*  功能描述   : 设置多次采数数据
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxScanSampleData(UINT32 sampleTimes,UINT32 samplePiontNum,DOUBLE*pSampleReal,DOUBLE*pSampleImag)
{
	INPUT_POINTER_CHECK(pSampleReal);
	INPUT_POINTER_CHECK(pSampleImag);
	UINT32 sampleLen = 0;
	sampleLen = (sizeof(DOUBLE))*sampleTimes * samplePiontNum;
	if(s_pFft_sample_Real == NULL)
	{
		s_pFft_sample_Real = (DOUBLE*)malloc(sampleLen);
		if(s_pFft_sample_Real == NULL)
		{
			dbgInfo("[%s] FftSampleDate Real malloc failed\n",__FUNCTION__);
			s_pFft_sample_Real = NULL;
			s_pFft_sample_Imag = NULL;
			return BSP_ERROR;
		}
	}
	if(s_pFft_sample_Imag == NULL)
	{
		s_pFft_sample_Imag = (DOUBLE*)malloc(sampleLen);
		if(s_pFft_sample_Imag == NULL)
		{
			dbgInfo("[%s] FftSampleDate Real malloc failed\n",__FUNCTION__);
			free(s_pFft_sample_Real);
			s_pFft_sample_Real = NULL;
			s_pFft_sample_Imag = NULL;
			return BSP_ERROR;
		}
	}
	memset(s_pFft_sample_Real,0,sampleLen);
	memset(s_pFft_sample_Imag,0,sampleLen);

	memcpy(s_pFft_sample_Real,pSampleReal,sampleLen);
	memcpy(s_pFft_sample_Imag,pSampleImag,sampleLen);
	s_fft_sampletimes 		= sampleTimes;
    s_fft_samplePointNum	= samplePiontNum;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanSampleData
*  功能描述   : 获取多次采数数据
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspGetRxScanSampleData(UINT32 sampleTimes,UINT32 samplePiontNum,DOUBLE*pSampleReal,DOUBLE*pSampleImag,UINT32 *pOutTimes,UINT32 *pOutPoint)
{
	INPUT_POINTER_CHECK(pSampleReal);
	INPUT_POINTER_CHECK(pSampleImag);
	INPUT_POINTER_CHECK(pOutTimes);
	INPUT_POINTER_CHECK(pOutPoint);

	UINT32 sampleLen = 0;
	UINT32 rxScanSampleTimes = 0;
	UINT32 rxScanSamplePoint = 0;

	rxScanSampleTimes = min(BspGetRxScanSampleTimes(),sampleTimes);
	rxScanSamplePoint = min(BspGetRxScanSamplePointNum(),samplePiontNum);
	sampleLen = (sizeof(DOUBLE))*rxScanSampleTimes * rxScanSamplePoint;

	memcpy(pSampleReal,s_pFft_sample_Real,sampleLen);
	memcpy(pSampleImag,s_pFft_sample_Imag,sampleLen);
	*pOutTimes = rxScanSampleTimes;
	*pOutPoint = rxScanSamplePoint;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetRxScanMaxChnNum
*  功能描述   : 设置场强扫描基本参数信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
static UINT32 BspSetRxScanMaxChnNum(UINT32 maxChnNum)
{
	s_rxScanMaxChnNum = maxChnNum;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanMaxChnNum
*  功能描述   : 获取频谱扫描最大通道数
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanMaxChnNum(VOID)
{
	 return s_rxScanMaxChnNum;
}
/*****************************************************************************
*  函数名称   : BspSetRxScanCommInfo
*  功能描述   : 设置场强扫描基本参数信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitRxScanCommInfo(UINT32 rxChnNum)
{
	if(s_pRxScanCommInfo == NULL)
	{
		s_pRxScanCommInfo = (T_RXSCAN_COMMON_INFO*)malloc(sizeof(T_RXSCAN_COMMON_INFO)*rxChnNum);

		if(s_pRxScanCommInfo == NULL)
		{
			dbgInfo("[%s] rxChnNum'%d malloc failed\n",__FUNCTION__,rxChnNum);
			return BSP_ERROR;
		}
	}
	if(s_pRxScanAgcGain == NULL)
	{
		s_pRxScanAgcGain = (INT32*)malloc(sizeof(INT32)*rxChnNum);

		if(s_pRxScanAgcGain == NULL)
		{
			dbgInfo("[%s] rxAgcGainNum'%d malloc failed\n",__FUNCTION__,rxChnNum);
			free(s_pRxScanCommInfo);
			s_pRxScanCommInfo = NULL;
			s_pRxScanAgcGain  = NULL;
			return BSP_ERROR;
		}
	}

	memset(s_pRxScanCommInfo,0,sizeof(T_RXSCAN_COMMON_INFO)*rxChnNum);
	memset(s_pRxScanAgcGain,0,sizeof(INT32)*rxChnNum);
	BspSetRxScanMaxChnNum(rxChnNum);
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetRxScanCommInfo
*  功能描述   : 设置场强扫描基本参数信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxScanCommInfo(UINT32 bspRxChn,T_RXSCAN_COMMON_INFO *pRxScanCommInfo)
{
	UINT32 size = sizeof(T_RXSCAN_COMMON_INFO);
	INPUT_POINTER_CHECK(pRxScanCommInfo);
	INPUT_RXSCANCHN_CHECK(bspRxChn);
	memcpy(&s_pRxScanCommInfo[bspRxChn],pRxScanCommInfo,size);
	return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetRxScanCommInfo
*  功能描述   : 获取场强扫描功基础参数信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanCommInfo(UINT32 bspRxChn,T_RXSCAN_COMMON_INFO *pRxScanCommInfo)
{
	UINT32 size = sizeof(T_RXSCAN_COMMON_INFO);
	INPUT_POINTER_CHECK(pRxScanCommInfo);
	INPUT_RXSCANCHN_CHECK(bspRxChn);
	memcpy(pRxScanCommInfo,&s_pRxScanCommInfo[bspRxChn],size);
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanFs
*  功能描述   : 获取频谱扫描采样速率
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanFs(UINT32 bspRxChn,UINT32 *pFs)
{
	UINT32 retVal = BSP_OK;
	INPUT_POINTER_CHECK(pFs);
	T_RXSCAN_COMMON_INFO rxScanRxInfo = {0};
	retVal = BspGetRxScanCommInfo(bspRxChn,&rxScanRxInfo);
	*pFs = rxScanRxInfo.fs;
	return retVal;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanFo
*  功能描述   : 获取频谱扫描频偏
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanFo(UINT32 bspRxChn,UINT32 band,INT32 *pFo)
{
	UINT32 retVal = BSP_OK;
	INPUT_POINTER_CHECK(pFo);
	T_RXSCAN_COMMON_INFO rxScanRxInfo = {0};
	retVal = BspGetRxScanCommInfo(bspRxChn,&rxScanRxInfo);
	*pFo = rxScanRxInfo.fo[band];
	return retVal;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanDpdStatus
*  功能描述   : 获取频谱扫描是否停DPD标记
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanDpdStatus(UINT32 bspRxChn,UINT32 *pDpdFlag)
{
	UINT32 retVal = BSP_OK;
	INPUT_POINTER_CHECK(pDpdFlag);
	T_RXSCAN_COMMON_INFO rxScanRxInfo = {0};
	retVal = BspGetRxScanCommInfo(bspRxChn,&rxScanRxInfo);
	*pDpdFlag = rxScanRxInfo.stopDpdFlag;
	return retVal;
}
/*****************************************************************************
*  函数名称   : BspSetRxVgcGain
*  功能描述   : 设置场强扫描VgcGain
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxScanVgcGain(UINT32 bspRxChn,INT32 rxAgcGain)
{
	INPUT_POINTER_CHECK(s_pRxScanAgcGain);
	s_pRxScanAgcGain[bspRxChn] = rxAgcGain;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxVgcGain
*  功能描述   : 获取场强扫描VgcGain
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanVgcGain(UINT32 bspRxChn,INT32 *pRxAgcGain)
{
	INPUT_POINTER_CHECK(s_pRxScanAgcGain);
	*pRxAgcGain = s_pRxScanAgcGain[bspRxChn];;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetRxScanSupportFlag
*  功能描述   : 设置场强扫描功能支持标记
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : flag   - 不支持 BSP_ERROR_FUNC_NOT_SUPPORT ，支持 0
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxScanSupportFlag(UINT32 flag)
{
	s_rxScanSupportFlag = flag;
	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanSupportFlag
*  功能描述   : 获取场强扫描功能支持标记
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanSupportFlag(VOID)
{
	return s_rxScanSupportFlag ;
}
/*****************************************************************************
*  函数名称   : BspSetFftWinPara
*  功能描述   : FftWin Coef
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : dFftWinCoef   - 表格系数
*         : ulLength      - 长度
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspSetFftWinPara(DOUBLE* pFftWinCoef,UINT32 length)
{
    INPUT_POINTER_CHECK(pFftWinCoef);

    if(length > FFT_MAX_NUM)
    {
        dbgErr("[%s]FftWin Coef Length = %d Error\n",__FUNCTION__,length);
        return BSP_ERROR;
    }
    memcpy(s_fftWinCoef,pFftWinCoef,length*sizeof(double));

	return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanStep
*  功能描述   :获取频谱扫描步进
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :BSP_OK/BSP_ERROR;
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞 2016-11-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanStep(UINT32 bspRxChn,UINT32 * pRxScanStep )
{
    INPUT_POINTER_CHECK(pRxScanStep);
    *pRxScanStep  = s_rxScanStep;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspSetRxScanStep
*  功能描述   : 设置频谱扫描步进
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :BSP_OK/BSP_ERROR;
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞 2016-11-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxScanStep(UINT32 bspRxChn,UINT32 rxScanStep )
{
    s_rxScanStep = rxScanStep;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspFftCalc()
*  功能描述   : FFT 计算
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :算法由V1平台移植
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
static UINT32 BspFftCalc(UINT32 fftCalNum)
{
    /* UINT32 retVal            = BSP_OK; */
    /* UINT32 size              = 0; */
    static UINT32 initFlag   = 0;
    UINT32 pointLoop         = 0;
    DOUBLE fftShift          = 0.0;

    if(fftCalNum > FFT_MAX_NUM)
    {
        dbgErr("[%s]fftCalNum  = %d Error\n",__FUNCTION__,fftCalNum);
        return BSP_ERROR;
    }
    /*FFT calc*/
    if(0 == initFlag)
	{
		fft24_initW(s_fftW1,s_fftW2,fftCalNum);
		fft24_change(s_fftC2,fftCalNum);
		initFlag = 1;
	}
    fft24_DX(s_fft_Out_Real,s_fft_Out_Imag,s_fft_In_Real,s_fft_In_Imag,s_fftW1,s_fftW2,fftCalNum,s_fftC2);

    /*FFT shift*/
    for(pointLoop = 0;pointLoop < fftCalNum/2;pointLoop++)
	{
    	fftShift 									= s_fft_Out_Real[pointLoop];
		s_fft_Out_Real[pointLoop] 					= s_fft_Out_Real[pointLoop + fftCalNum/2];
		s_fft_Out_Real[pointLoop + fftCalNum/2] 	= fftShift;

		fftShift 									= s_fft_Out_Imag[pointLoop];
		s_fft_Out_Imag[pointLoop] 					= s_fft_Out_Imag[pointLoop + fftCalNum/2];
		s_fft_Out_Imag[pointLoop + fftCalNum/2] 	= fftShift;
	}
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspFftWinCalc()
*  功能描述   : FFT 加窗化归一化处理
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
static UINT32 BspFftWinCalc(DOUBLE* pReal,DOUBLE* pImag,UINT32 fftCalNum)
{
    /* UINT32 retVal       = BSP_OK; */
    UINT32 pointLoop    = 0;
    INPUT_POINTER_CHECK(pReal);
    INPUT_POINTER_CHECK(pImag);
    if(fftCalNum > FFT_MAX_NUM)
    {
        dbgErr("[%s]fftCalNum  = %d Error\n",__FUNCTION__,fftCalNum);
        return BSP_ERROR;
    }
    for(pointLoop = 0; pointLoop < fftCalNum; pointLoop++)
    {
        s_fft_In_Real[pointLoop] = pReal[pointLoop]*s_fftWinCoef[pointLoop];
        s_fft_In_Imag[pointLoop] = pImag[pointLoop]*s_fftWinCoef[pointLoop];
    }
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspFftAccumulationData()
*  功能描述   : FFT 多组数据累加
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :算法由V1平台移植
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
static UINT32 BspFftAccumulationData(UINT32 fftCalNum,DOUBLE *pFftData)
{
    UINT32 pointLoop = 0;
    INPUT_POINTER_CHECK(pFftData);

    if(fftCalNum > FFT_MAX_NUM)
    {
        dbgErr("[%s]fftCalNum  = %d Error\n",__FUNCTION__,fftCalNum);
        return BSP_ERROR;
    }
    /*多组数据累加*/
    for(pointLoop = 0; pointLoop < fftCalNum; pointLoop ++)
    {
        pFftData[pointLoop]+= pow(s_fft_Out_Real[pointLoop],2)+pow(s_fft_Out_Imag[pointLoop],2);
    }
    return BSP_OK;

}
/*****************************************************************************
 *  函数名称   : BspGetPsdRange()
 *  功能描述   : get psd cal range
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   : 算法从V1平台移植
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 王飞@2016-11-20
 *----------------------------------------------------------------------------
 */
static UINT32 BspGetPsdRange(UINT32 bspRxChn,UINT32 freqBand,UINT32 fftCalNum,UINT32 rxScanStep,UINT32 rxScanPos,UINT32 *pStart,UINT32 *pEnd)
{
	UINT32 retVal           = BSP_OK;
	UINT32 spanStart        = 0;
	UINT32 spanEnd          = 0;
	UINT32 rfCenterFreq     = 0;
	UINT32 rxStartFreq     = 0;
	UINT32 rxEndFreq     = 0;
    TFreqStartEnd freqStartEnd = {0};    

    if(fftCalNum > FFT_MAX_NUM)
    {
        dbgErr("[%s]fftCalNum  = %d Error\n",__FUNCTION__,fftCalNum);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pStart);
    INPUT_POINTER_CHECK(pEnd);
    INPUT_RXSCANCHN_CHECK(bspRxChn);

    retVal |= BspGetFreqRange(bspRxChn,freqBand,RX,&freqStartEnd);
    retVal |= BspAdpGetBoardFreqValue(bspRxChn,freqBand,RX,START_FREQ_FLAG,&rxStartFreq);
    retVal |= BspAdpGetBoardFreqValue(bspRxChn,freqBand,RX,END_FREQ_FLAG,&rxEndFreq);

    if (BSP_OK != retVal)
    {
    	dbgInfoEx("[%s] BspGetFreqRange Error\n",__FUNCTION__);
    }

	spanStart = freqStartEnd.aulFreqStart[freqBand]/10;
	spanEnd   = freqStartEnd.aulFreqEnd[freqBand]/10;

	rfCenterFreq    = (rxStartFreq + rxEndFreq)/20;/*中心频点为特性表打表中心*/

    if((g_Func_RxScanFreqLimit != (RxScan_FreqLimit)NULL) && (s_rxScanOutOfBandId == freqBand))
    {
        g_Func_RxScanFreqLimit(&spanStart,&spanEnd);
        spanStart = spanStart/10;
        spanEnd = spanEnd/10;
        rfCenterFreq    = (spanStart + spanEnd)/2;/*中心频点单位10khz rruproperty 来区分高低LO*/
    }

	dbgInfoEx("[%s]bspRxChn'%d, freqBand'%d, spanStart'%d, spanEnd'%d\n",__FUNCTION__, bspRxChn, freqBand, spanStart, spanEnd);

	if(spanStart <= (rfCenterFreq - rxScanPos))
	{
		*pStart = 0;
	}
	else
	{
		*pStart = ceil((spanStart - rfCenterFreq + rxScanPos)/(rxScanStep/100.0));/*步进为22.5k*/
	}

	/*计算功率谱的终止位置*/
	if(spanEnd >=(rfCenterFreq + rxScanPos))
	{
		*pEnd = fftCalNum;
	}
	else
	{
		*pEnd  = fftCalNum-(rfCenterFreq + rxScanPos - spanEnd)/(rxScanStep/100.0);
	}

	dbgInfoEx("[%s]*pStart'%d, *pEnd'%d, fftCalNum'%d\n",__FUNCTION__, *pStart, *pEnd, fftCalNum);

	if((*pStart>fftCalNum)||(*pEnd>fftCalNum)||(*pStart>*pEnd))
	{
		retVal |= BSP_ERROR;
	}

	return retVal;
}

UINT32 BspSetBandNcoPtr(pGetBandNcoVal pfunc)
{
    s_pGetBadnNcoFunc = pfunc;
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspRxScandDataProcess()
 *  功能描述   : 数据及对应的频点信息统计
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   :
 *  返 回 值   :
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), LT@2015-08
 *----------------------------------------------------------------------------
 */
UINT32 BspRxScandDataProcess(UINT32 bspRxChn,UINT32 band,UINT32 rxScanStep,UINT32 rxScanPos,UINT32 psdFreqStart,UINT32 psdFreqEnd,UINT32 fftCalNum,UINT32 sampleTimes,UINT32 antStat)
{
    UINT32 retVal       = BSP_OK;
    UINT32 centerFreq   = 0;
    UINT32 startFreq    = 0;
    INT32  agcGain      = 0;
    UINT32 rxCompChn    = 0;
    UINT32 freqPosloop  = 0;
    UINT32 caliTblStart = 0;
    UINT32 caliTblEnd   = 0;
    UINT32 caliStep     = 0;
    UINT32 caliRfLoadFlg = 0;
    UINT32 currentFreq  = 0;
    UINT32 currRecIndex = 0;
    INT32  rxCompVal    = 0;
    DOUBLE tempData     = 0;
    INT32 dbfsValue     = 0;
    INT32 tmaGain       = 0;
    INT16 rxScanData    = 0;
    TRxRssiCaliData* pRxRssiData = NULL;
    T_FreqRecord* pFreqRecord = NULL;
    INT32 BdTemp = 0;
    UINT32 tCurrentFreq = 0;
    INT32  tRxCompVal	= 0;
    T_RXSCAN_FREQUENT_INFO freqInfo = {0};
    UINT32 centerIndex = 0;
    UINT32 centerComp = 0;
    INT16 RxScanDataTmp = 0;
    UINT32 tcenterFreq =0;
    UINT32 spanStart        = 0;
    UINT32 spanEnd          = 0;
    UINT32 IsSupportOutBand = RX_SCAN_NOT_SUPPORT_OUT_BAND;
    UINT32 currentFreqOutBand = 0;
    UINT32 rxStartFreq = 0;
    UINT32 rxEndFreq = 0;

    if(fftCalNum > FFT_MAX_NUM)
    {
        dbgErr("[%s]fftCalNum  = %d Error\n",__FUNCTION__,fftCalNum);
        return BSP_ERROR;
    }

    if((0 == fftCalNum)||(0 == sampleTimes))
    {
        dbgErr("[%s]fftCalNum:%d or sampleTimes:%d is Error\n", __FUNCTION__, fftCalNum, sampleTimes);
        return BSP_ERROR;
    }

    if(bspRxChn >= BSP_MAX_RX_CHAN)
    {
        dbgErr("[%s]bspRxChn  = %d Error\n",__FUNCTION__,bspRxChn);
        return BSP_ERROR;
    }


    retVal |= BspAdpGetBoardFreqValue(bspRxChn,band,RX,START_FREQ_FLAG,&rxStartFreq);
    retVal |= BspAdpGetBoardFreqValue(bspRxChn,band,RX,END_FREQ_FLAG,&rxEndFreq);

    if(BSP_OK != retVal)
    {
        dbgInfoEx("[%s] BspGetFreqRange Error\n",__FUNCTION__);
    }

    centerFreq = (rxStartFreq + rxEndFreq)/2/10;

    IF_CHK((g_Func_RxScanFreqLimit != (RxScan_FreqLimit)NULL) && (s_rxScanOutOfBandId == band))
    {
        g_Func_RxScanFreqLimit(&spanStart,&spanEnd);
        centerFreq = (spanStart+spanEnd)/20;
    }

    s_startFreq = (UINT32)(centerFreq - (rxScanPos - psdFreqStart *(rxScanStep/100.0)))*100;  /*0.1KHz*/
    s_stopFreq  = s_startFreq + (psdFreqEnd - psdFreqStart)*rxScanStep;  /*0.1KHz*/
    startFreq   = s_startFreq;

    dbgInfoEx("[%s]s_startFreq'%d, s_stopFreq'%d, centerFreq'%d, rxScanPos'%d, psdFreqStart'%d, psdFreqEnd'%d, rxScanStep'%d\n",
            __FUNCTION__, s_startFreq, s_stopFreq, centerFreq, rxScanPos, psdFreqStart, psdFreqEnd, rxScanStep);

    retVal |= BspGetRxScanVgcGain(bspRxChn,&agcGain);
    pRxRssiData = (TRxRssiCaliData *)_BspGetCalibData(TBL_KIND_OF_RXRSSI,0);

    if(NULL == pRxRssiData)
    {
        return BSP_ERROR;
    }

    retVal |= BspGetCaliChnByBspChn(bspRxChn,RX,&rxCompChn);

    caliTblStart  = pRxRssiData->atRxRssiCaliPath[rxCompChn].tHeader.aulStartFreq[band]*10;
    caliTblEnd    = pRxRssiData->atRxRssiCaliPath[rxCompChn].tHeader.aulStopFreq[band]*10;
    caliStep      = pRxRssiData->atRxRssiCaliPath[rxCompChn].tHeader.aulRfStep[band]*10;
    pFreqRecord   = pRxRssiData->atRxRssiCaliPath[rxCompChn].patRfRecord[band];
    caliRfLoadFlg = pRxRssiData->atRxRssiCaliPath[rxCompChn].ulRfLoadFalg;

    if((caliStep == 0)||(caliRfLoadFlg != TBL_LOAD_SUCC))
    {
        caliStep = 1;
        dbgInfoEx("[%s]caliStep  Val'%d ,caliRfLoadFlag'%d \n",__FUNCTION__,caliStep,caliRfLoadFlg);
    }
    if(pFreqRecord == NULL)
    {
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]caliTblStart:%d,caliTblEnd:%d,caliStep:%d,caliRfLoadFlg:%d.\n",__FUNCTION__,caliTblStart,caliTblEnd,caliStep,caliRfLoadFlg);

    freqInfo.startFreq = s_startFreq;
    freqInfo.stopFreq = s_stopFreq;
    freqInfo.caliTblStart = caliTblStart;
    freqInfo.caliTblEnd = caliTblEnd;
    freqInfo.caliStep = caliStep;

    IsSupportOutBand = BspGetRxScanIsSupportOutBand();

    retVal |= BspGetBoardTemp(0,&BdTemp);

    tcenterFreq = centerFreq*100;
    tcenterFreq = (tcenterFreq > caliTblStart)?(tcenterFreq):caliTblStart; /* 确保扫频频点落入校准表范围 */
    tcenterFreq = (tcenterFreq > caliTblEnd)?(caliTblEnd):tcenterFreq;
    centerIndex = (UINT32)((FLOAT)(tcenterFreq - caliTblStart)/(FLOAT)caliStep + 0.5) ;   /* lb, 小标查询校准补偿值，扫频只考虑rfcomps */
    centerComp = pFreqRecord[centerIndex].lCompVal;

    for(freqPosloop = psdFreqStart;freqPosloop <= psdFreqEnd;freqPosloop++)
    {
        if(caliRfLoadFlg == TBL_LOAD_SUCC)
        {
            currentFreq = startFreq + (freqPosloop - psdFreqStart) * rxScanStep;
            currentFreqOutBand = currentFreq;
            currentFreq = (currentFreq > caliTblStart)?(currentFreq):caliTblStart; /* 确保扫频频点落入校准表范围 */
            currentFreq = (currentFreq > caliTblEnd)?(caliTblEnd):currentFreq;
            currRecIndex = (UINT32)((FLOAT)(currentFreq - caliTblStart)/(FLOAT)caliStep + 0.5) ;   /* lb, 小标查询校准补偿值，扫频只考虑rfcomps */
            rxCompVal = pFreqRecord[currRecIndex].lCompVal;

            if ((currentFreqOutBand < caliTblStart || currentFreqOutBand > caliTblEnd) && (IsSupportOutBand == RX_SCAN_SUPPORT_OUT_BAND) && (s_rxScanOutOfBandId == band))
            {
                UINT32 tRet = BSP_ERROR;
                if ((pRxScanOutOfBandCompCali)NULL != g_Func_RxScanOutOfBandCompCali)
                {
                    tRet = g_Func_RxScanOutOfBandCompCali(bspRxChn,currentFreqOutBand,freqInfo,BdTemp,&tRxCompVal,&tCurrentFreq);
                }
                if (tRet == BSP_OK)
                {
                    currentFreq = tCurrentFreq;
                    rxCompVal = tRxCompVal;
                    //dbgInfoEx("%s,currentFreq = %d, rxCompVal = %d \n",__FUNCTION__,currentFreq,rxCompVal);
                }
            }
        }
        tempData = (s_fft_Out_Pow[freqPosloop]/(double)sampleTimes);
        tempData = sqrt(tempData)/fftCalNum;

        if(0 == tempData)
        {
            tempData = 0.76500;  /* 出现0值，归一化处理，统一处理为低噪值 */
        }
        /*D42+3dB 补偿1/4抽取数据增益的损失*/
        dbfsValue = 2000*log10(tempData) - 1000.0* log10(pow(2.0,2*(15))) + 600;
        retVal |= BspRxScanGetTma(bspRxChn,(UINT32 *)&tmaGain);  /* 增加塔放增益 */
        rxScanData = (INT16)(dbfsValue - rxCompVal - agcGain - tmaGain);

        if(IsSupportOutBand == RX_SCAN_SUPPORT_OUT_BAND && (currentFreq < caliTblStart || currentFreq > caliTblEnd))
        {
            RxScanDataTmp = (INT16)(dbfsValue - centerComp - agcGain - tmaGain);
            if (RxScanDataTmp < (s_compsThreshold - agcGain))
            {
                rxScanData = RxScanDataTmp;
            }
        }
        /* 把起始点放在数组0的位置 */
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        s_rxScanData[freqPosloop - psdFreqStart].data[antStat] = rxScanData; /*换算成dbm*/
        s_rxScanData[freqPosloop - psdFreqStart].freq = currentFreq;   /* 单位为 0.1kHz */

        dbgInfoEx("%d  %d  %d  %d  %d  %d  %d %f %f  %d \n",freqPosloop - psdFreqStart,s_rxScanData[freqPosloop - psdFreqStart].freq,
                s_rxScanData[freqPosloop - psdFreqStart].data[0],s_rxScanData[freqPosloop - psdFreqStart].data[1],
                rxScanData,agcGain,dbfsValue,tempData,s_fft_Out_Pow[freqPosloop],rxCompVal);
    }

    return retVal;
}
/*****************************************************************************
*  函数名称   : IntPub_UnitFunc_BspRxScanStart()
*  功能描述   : 获取上行频谱扫描
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK或错误码
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞@2016-11-28 00:03:16, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspRxScanFftCalc(UINT32 bspRxChn,UINT32 band,UINT32 antStat, UINT32 cellStat)
{
    UINT32 retVal 			= BSP_OK;
    UINT32 sampleTimes		= 0;
    UINT32 fftSamplePos 	= 0;
    UINT32 fftCalNum    	= 0;
    UINT32 rxScanStep   	= 0;
    UINT32 rxScanPos		= 0;
    UINT32 sampleLoop   	= 0;
    UINT32 pointLoop    	= 0;
    UINT32 psdFreqStart    	= 0;
    UINT32 psdFreqEnd      	= 0;
    DOUBLE *pSampleReal     = NULL;
    DOUBLE *pSampleImag		= NULL;
    UINT32 fftCalNumTmp     = 0;
    UINT32 sampleTimesTmp   = 0;
    FILE *fp   = NULL;
    INT32 fclsRet = 0;
    INT32 fprtRet = 0;
    T_RXSCAN_COMMON_INFO *pRxScanInfo = NULL;
    
    if(bspRxChn >=BspGetRxScanMaxChnNum()||band > 2||antStat > 1||cellStat > 1)
    {
        dbgErr("[%s]RxScanChn'%d band'%d antStat'%d cellStat'%d: input para ERROR!!\n",__FUNCTION__,bspRxChn,band,antStat,cellStat);
        return RX_SCAN_FREQ_PARA_ERROR;
    }

    fp = fopen(s_fftFileName[antStat], "w+");
    if(fp == NULL)
    {
        dbgErr("[%s]:Open file %s for writing failed!\n",__FUNCTION__, s_fftFileName[antStat]);
        return RX_SCAN_FREQ_FILE_FAILE;
    }

    pRxScanInfo    = (T_RXSCAN_COMMON_INFO*)malloc(sizeof(T_RXSCAN_COMMON_INFO));
    if(pRxScanInfo == NULL)
    {
        dbgInfo("[%s] malloc failed\n",__FUNCTION__);
        free(pRxScanInfo);
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    retVal |= BspGetRxScanCommInfo(bspRxChn, pRxScanInfo);

    fftCalNumTmp    = pRxScanInfo->fftCalcNum;
    sampleTimesTmp  = pRxScanInfo->rxScanSampLoop;
    pSampleReal    = (DOUBLE*)malloc((sizeof(DOUBLE))*fftCalNumTmp *sampleTimesTmp);

    if(pSampleReal == NULL)
    {
        dbgInfo("[%s] malloc failed\n",__FUNCTION__);
        free(pRxScanInfo);
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    pSampleImag    = (DOUBLE*)malloc((sizeof(DOUBLE))*fftCalNumTmp *sampleTimesTmp);
    if(pSampleImag == NULL)
    {
        dbgInfo("[%s] malloc failed\n",__FUNCTION__);
        free(pRxScanInfo);
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pSampleReal);
        return BSP_ERROR;
    }
    retVal |=BspGetRxScanSampleData(sampleTimesTmp,fftCalNumTmp,pSampleReal,pSampleImag,&sampleTimes,&fftCalNum);

    dbgInfoEx("[%s]sampleTimes'%d fftCalNum'%d \n",__FUNCTION__,sampleTimes,fftCalNum);
    if(0 == fftCalNum)
    {
        free(pRxScanInfo);
        fclsRet = fclose(fp);
        FCLOSE_CHECK(fclsRet);
        free(pSampleImag);
        free(pSampleReal);
        dbgErr("[%s]Para Error,fftCalcNum'%d \n",__FUNCTION__,fftCalNum);
        return BSP_ERROR;
    }
    memset(s_fft_Out_Pow,0,sizeof(s_fft_Out_Pow));
    memset(s_fft_In_Real,0,sizeof(s_fft_In_Real));
    memset(s_fft_In_Imag,0,sizeof(s_fft_In_Imag));

    fftSamplePos 	= pRxScanInfo->fftSamplePos;
    rxScanStep   	= fftSamplePos*10/fftCalNum;/* 单位为 0.1kHz */
    rxScanPos    	= fftSamplePos*50/1000;/*起始位置50us，4608=50*92.16  6144 = 50*122.88 */
    retVal |= BspSetRxScanStep(bspRxChn, rxScanStep);

    for(pointLoop = 0;pointLoop < fftCalNum ;pointLoop ++)
    {
        for(sampleLoop = 0;sampleLoop < sampleTimes;sampleLoop ++)
        {
            s_fft_In_Real[pointLoop] += pSampleReal[sampleLoop*fftCalNum + pointLoop];/*实部在低16BIT,虚部在高16BIT*/
            s_fft_In_Imag[pointLoop] += pSampleImag[sampleLoop*fftCalNum + pointLoop];/*实部在低16BIT,虚部在高16BIT*/
        }

        fprtRet = fprintf(fp,"%f\n",s_fft_In_Real[pointLoop]);
        FPRINTF_CHECK(fprtRet);
        fprtRet = fprintf(fp,"%f\n",s_fft_In_Imag[pointLoop]);
        FPRINTF_CHECK(fprtRet);
    }
    /*2.加窗化归一化处理*/
    retVal |= BspFftWinCalc(s_fft_In_Real,s_fft_In_Imag, fftCalNum);
    /*3. FFT计算 */
    retVal |= BspFftCalc(fftCalNum);
    /*多组数据累加*/
    retVal |= BspFftAccumulationData(fftCalNum,s_fft_Out_Pow);
    fclsRet = fclose(fp);
    FCLOSE_CHECK(fclsRet);
    /*4. 数据后处理，计算功率谱，只计算滤波器带宽内的点*/
    retVal |= BspGetPsdRange(bspRxChn, band,fftCalNum, rxScanStep,rxScanPos, &psdFreqStart, &psdFreqEnd);
    dbgInfoEx("[%s] psdFreqStart %d  psdFreqEnd %d\n",__FUNCTION__,psdFreqStart,psdFreqEnd);
    /*5.数据统计*/
    retVal |= BspRxScandDataProcess(bspRxChn, band,rxScanStep,rxScanPos, psdFreqStart,psdFreqEnd,fftCalNum,sampleTimes,antStat);

    free(pRxScanInfo);
    free(pSampleImag);
    free(pSampleReal);

    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspGetRxScanCountData()
 *  功能描述   : 获取频谱分析功率谱数据及对应的频点信息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : count	-获取第几组数据，从0开始排列
 *  输出参数   : pRxScanData-功率谱信息，data0为断开天线的数据，data1为连接天线的数据
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 10102065@2015-08
 *----------------------------------------------------------------------------
 */
UINT32 BspGetRxScanCountData(UINT32 count, T_RxScan *pRxScanData)
{
    if(count >=FFT_MAX_NUM || NULL == pRxScanData)
    {
        dbgErr("%d %s input para %d error.\n",__LINE__,__FUNCTION__,count);
        return BSP_ERROR;
    }
    memcpy(pRxScanData, &s_rxScanData[count], sizeof(T_RxScan));

    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspRestRxScanAllData()
 *  功能描述   : 清除频谱分析的相关数据
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), LT@2015-08
 *----------------------------------------------------------------------------
 */
UINT32 BspRestRxScanAllData(VOID)
{
    memset(&s_rxScanData[0],0,FFT_MAX_NUM * sizeof(T_RxScan));
    s_startFreq  = 0;
    s_stopFreq   = 0;
    s_rxScanStep = 0;
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : BspGetRxScanFreq()
 *  功能描述   : 获取频谱分析频点信息:起始频点，终止频点，步进
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 起始频点，终止频点，步进
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), LT@2015-08
 *----------------------------------------------------------------------------
 */
UINT32 BspGetRxScanFreqInfo(UINT32 bspRxChn,UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep)
{
    UINT32 rxScanStep          =   0;
    if(NULL == pStartFreq || NULL == pStopFreq || NULL == pStep)
    {
        dbgPrn(" [%s][%d] input para error.\n",__FUNCTION__,__LINE__);
        return BSP_ERROR;
    }
    BspGetRxScanStep(bspRxChn, &rxScanStep);
    *pStartFreq = s_startFreq;
    *pStopFreq  = s_stopFreq;
    *pStep      = rxScanStep;
    return BSP_OK;
}
/*****************************************************************************
*  函数名称   : BspGetRxScanModuleInfo
*  功能描述   : 频谱扫描 模块功能信息
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
T_RxScanModule* BspGetRxScanModuleInfo(VOID)
{
    return &(s_rxScanFunc);
}
/*****************************************************************************
*  函数名称   : BspGetRxScanFuncInitFlag
*  功能描述   : 获取RxScan模块初始化标记
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxScanFuncInitFlag(VOID)
{
    return s_rxScanFunc.initFlag;
}
/*****************************************************************************
*  函数名称   : BspRxScanGetTma
*  功能描述   : 上行频谱采数TMA增益
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :BSP_OK/BSP_ERROR;
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞 2016-11-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspRxScanGetTma(UINT32 bspRxChn,UINT32 *pTmaGain)
{
    /* UINT32 retVal    = BSP_OK; */
	dbgInfoEx("[%s]rxChn'%d . \n\n",__FUNCTION__,bspRxChn);
	if(s_rxScanFunc.rxScanGetTma == NULL)
	{
		dbgInfo("[%s]rxScan func Tma is NULL \n",__FUNCTION__);
		return BSP_ERROR;
	}
    return s_rxScanFunc.rxScanGetTma(bspRxChn,pTmaGain);
}
/************************** rxscanapi.h 接口********************************/
/*****************************************************************************
*  函数名称   : BspRxScanDpdStatus
*  功能描述   : 上行扫描时需要关闭下行dpd通道标志
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :BSP_OK/BSP_ERROR;
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞 2016-11-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspRxScanDpdStatus(UINT32 bspRxChn,UINT32 bspTxChn,UINT32 * pDpdFlag )
{
    UINT32 retVal        = BSP_OK;
    INPUT_POINTER_CHECK(pDpdFlag);
    retVal |= BspGetRxScanDpdStatus(bspRxChn, pDpdFlag);
    return retVal;
}
/*****************************************************************************
*  函数名称   : BspRxScanSample
*  功能描述   : 上行频谱采数
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :BSP_OK/BSP_ERROR;
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞 2016-11-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspRxScanSample(UINT32 bspRxChn,UINT32 band)
{
    /* UINT32 retVal    = BSP_OK; */
	dbgInfoEx("[%s]rxChn'%d band'%d. \n\n",__FUNCTION__,bspRxChn,band);
	if(s_rxScanFunc.rxScanSample == NULL)
	{
		dbgInfo("[%s]rxScan func Sample is NULL \n",__FUNCTION__);
		return BSP_ERROR;
	}
    return s_rxScanFunc.rxScanSample(bspRxChn,band);
}

/*****************************************************************************
*  函数名称   : BspRxScanCal
*  功能描述   : 上行频谱FFT计算
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :BSP_OK/BSP_ERROR;
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞 2016-11-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspRxScanCal(UINT32 bspRxChn,UINT32 band,UINT32 antStat, UINT32 cellStat)
{
	if(s_rxScanFunc.rxScanCalc == NULL)
	{
		dbgInfo("[%s]rxScan func Calc is NULL \n",__FUNCTION__);
		return BSP_ERROR;
	}
	return s_rxScanFunc.rxScanCalc(bspRxChn,band,antStat,cellStat);
}
/*****************************************************************************
 *  函数名称   : BspGetRxScanData()
 *  功能描述   : 获取频谱分析功率谱数据及对应的频点信息
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : count-获取第几组数据，从0开始排列
 *  输出参数   : ptRxScanData-功率谱信息，data0为断开天线的数据，data1为连接天线的数据
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), WF@2016-08
 *----------------------------------------------------------------------------
 */
UINT32 BspGetRxScanData(UINT32 count, T_RxScan *pRxScanData)
{
	INPUT_POINTER_CHECK(pRxScanData);
	if(s_rxScanFunc.rxScanGetDate == NULL)
	{
		dbgInfo("[%s]rxScan func Get Date is NULL \n",__FUNCTION__);
		return BSP_ERROR;
	}
	return s_rxScanFunc.rxScanGetDate(count,pRxScanData);
}
/*****************************************************************************
 *  函数名称   : BspGetRxScanFreq()
 *  功能描述   : 获取频谱分析频点信息:起始频点，终止频点，步进
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 起始频点，终止频点，步进
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wf@2016-08
 *----------------------------------------------------------------------------
 */
UINT32 BspGetRxScanFreq(UINT32 bspRxChn,UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep)
{
    INPUT_POINTER_CHECK(pStartFreq);
    INPUT_POINTER_CHECK(pStopFreq);
    INPUT_POINTER_CHECK(pStep);
    if(s_rxScanFunc.rxScanGetFreq == NULL)
	{
		dbgInfo("[%s]rxScan func Get Freq is NULL \n",__FUNCTION__);
		return BSP_ERROR;
	}
	return s_rxScanFunc.rxScanGetFreq(bspRxChn,pStartFreq, pStopFreq,pStep);
}
/*****************************************************************************
 *  函数名称   : BspRestRxScanData()
 *  功能描述   : 清除频谱分析的相关数据
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : 0 - success, 其它值为失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), LT@2015-08
 *----------------------------------------------------------------------------
 */
UINT32 BspRestRxScanData(VOID)
{
	if(s_rxScanFunc.rxScanRstDate == NULL)
	{
		dbgInfo("[%s]rxScan func Rst Date is NULL \n",__FUNCTION__);
		return BSP_ERROR;
	}
    return s_rxScanFunc.rxScanRstDate();
}
/*****************************************************************************
*  函数名称   : BspRxScanReInit
*  功能描述   : 上行扫描初始化
*  读全局变量 :
*  写全局变量 :
*  输入参数   :
*  输出参数   :
*  返 回 值   :BSP_OK/BSP_ERROR;
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 王飞 2016-11-28 创建
*----------------------------------------------------------------------------
*/
UINT32 BspRxScanParaReInit(VOID)
{
	return BSP_OK;
}

UINT32 BspSetRfCenterFreq(UINT32 centerFreq)
{
	g_rfCenterFreq = centerFreq;
	return BSP_OK;
}

UINT32 BspSetRfCenterFreqList(UINT32 *freqList)
{
    INPUT_POINTER_CHECK(freqList);

    memcpy_s(g_rfCenterFreqList, BSP_MAX_RX_CHAN*sizeof(UINT32), freqList, BSP_MAX_RX_CHAN*sizeof(UINT32));
    return BSP_OK;
}

UINT32 BspSetRxScanIsSupportOutBand(UINT32 IsSupport)
{
	if (IsSupport == RX_SCAN_NOT_SUPPORT_OUT_BAND)
	{
		s_rxscanIsSupportOutBand = RX_SCAN_NOT_SUPPORT_OUT_BAND;
	}
	else
	{
		s_rxscanIsSupportOutBand = RX_SCAN_SUPPORT_OUT_BAND;
	}
	return BSP_OK;
}

UINT32 BspGetRxScanIsSupportOutBand(void)
{
	return s_rxscanIsSupportOutBand;
}
UINT32 BspSetRxScanOutBandCali(pRxScanOutOfBandCompCali uFunc)
{
	INPUT_POINTER_CHECK(uFunc);
	g_Func_RxScanOutOfBandCompCali = uFunc;
	return BSP_OK;
}

VOID BspSetRxScanCompsThread(INT32 thread) //默认单位dbm
{
	dbgInfo("Modify the compensation threshold to %d \n", thread);
	s_compsThreshold = thread * 100;
}

VOID BspSetScanOutOfBandId(UINT32 bandId)
{
    s_rxScanOutOfBandId = bandId;
}

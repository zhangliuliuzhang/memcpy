/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : pimccomon.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供CFR模块配置的功能实现。
 * 注意事项 : 无
 * 作    者 : wangfei
 * 创建日期 : 2015-10-20 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: 
 * 责 任 人:
 * 修改日戳: 
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef _FUNCLIB_RXSCAN_COMMON_H_INCLUDED_
#define _FUNCLIB_RXSCAN_COMMON_H_INCLUDED_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"

/**************************************************************************
 *                        宏定义                                              
 **************************************************************************/
#define FFT_MAX_NUM             		4096  /* 进行FFT计算的最大点数 */
#define FFT_MAX_SAMPLE_TIMES    		10    /* 进行FFT计算的次数 */

#define RXSCAN_NOT_DEED_STOP_DPD  0
#define RXSCAN_NEED_STOP_DPD      1
#define RXSCAN_MTS_AGC_MODE       1           /* 采用控制MTS 侧AGC模式  */

#define RXSCAN_FUNC_SUPPORT             0
#define RXSCAN_FUNC_NOT_SUPPORT    		BSP_ERROR_FUNC_NOT_SUPPORT

#define DFL_BANDWIDTH_30M  (30000)
#define DFL_BANDWIDTH_45M  (45000)

#define RX_SCAN_FREQ_PARA_ERROR       	(0xFFFFFFFF)
#define RX_SCAN_FREQ_FFT_SAMPLE_FAILE 	(0xFFFFFFFE)
#define RX_SCAN_FREQ_FILE_FAILE       	(0xFFFFFFFC)
#define RX_SCAN_FREQ_FFT_CALC_FAILE   	(0xFFFFFFFB)

#define RX_SCAN_SUPPORT_OUT_BAND    1
#define RX_SCAN_NOT_SUPPORT_OUT_BAND 0 

#define PI          (3.1415926)

#define INPUT_RXSCANCHN_CHECK(bspChn)                       \
{                                                           \
    UINT32 rxChn     = BspGetRxScanMaxChnNum();             \
    if (bspChn >= rxChn)                                    \
    {                                                       \
        dbgErr("[%s]chn'%d is Error ,Over rxScanChn MaxRxChn'%d \n",__FUNCTION__,bspChn,rxChn);\
        return BSP_ERROR;                                   \
    }                                                       \
}

#define RXSCAN_SAMPLERATE   92160   /*采样速率92.16M ,需要对齐到92.16M上*/
#define SAMPLERATE_245P76M  245760   /*采样速率245760M ,需要对齐到245760M上*/
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


typedef struct tag_rx_scan_common_info
{
   UINT32 rxScanSampLoop;    /* 采数计算循环次 */
   UINT32 stopDpdFlag;       /*0:不需要停DPD 1:需要停DPD(IC 需要停全芯片DPD)（4.2平台不关注）*/
   UINT32 fftMode;           /*FFT 计算模式  0:DPDIC 计算模式  1:FPGA计算模式 （4.2平台不关注）*/
   UINT32 fftCalcNum;        /*FFT 计算模式的点数*/
   UINT32 fftSamplePos;      /*采样点位置 e.g 122.88M/92.16M KH （4.2平台不关注）Z*/
   UINT32 fs;                /*MTS ADC采样速率FS KHZ*/
   INT32 fo[3];              /*采数位置频偏FO KHZ(射频本振频点-上行实际扫频频段中心频点)--单通道最大支持3个频段*/
}T_RXSCAN_COMMON_INFO;

typedef struct tag_rx_scan_frequent_info
{
    UINT32 startFreq;
    UINT32 stopFreq;
    UINT32 caliTblStart;
    UINT32 caliTblEnd;
    UINT32 caliStep;
}T_RXSCAN_FREQUENT_INFO;


typedef struct RxScanOutOfBandComp
{
    UINT32 frequent;
    INT32 compValLow;
    INT32 tempLow;
    INT32 compValMedium;
    INT32 tempMedium;
    INT32 compValHigh;
    INT32 tempHigh;
}T_RxScanOutOfBandComp;

typedef struct RxScanOutBandData
{
    T_RxScanOutOfBandComp *headArray;
    UINT32 hLength;
    T_RxScanOutOfBandComp *tailArray;
    UINT32 tLength;
}T_RxScanOutBandData;

typedef struct RxScanOutBandDataAllChan
{
    UINT32 ulFreqBand;
    UINT32 ulDflBw;
    T_RxScanOutBandData *rxScanOutBandData;
    UINT32 ulChanNum;
}T_RxScanOutBandDataAllChan;

typedef UINT32 (*RxScan_Sample)(UINT32 bspRxChn,UINT32 band);
typedef UINT32 (*RxScan_Calc)(UINT32 bspRxChn,UINT32 band,UINT32 antStat, UINT32 cellStat);
typedef UINT32 (*RxScan_GetDate)(UINT32 count, T_RxScan *pRxScanData);
typedef UINT32 (*RxScan_GetFreq)(UINT32 bspRxChn,UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep);
typedef UINT32 (*RxScan_GetTma)(UINT32 bspChn,UINT32 *pTmaGain);
typedef UINT32 (*RxScan_RstDate)(VOID);
typedef INT32 (*pGetBandNcoVal)(UINT32 bspch,UINT32 bandid);

typedef UINT32 (*RxScan_FreqLimit)(UINT32 *pSpanStart,UINT32 *pSpanEnd);

typedef UINT32 (*pRxScanOutOfBandCompCali)(UINT32 bspRxChn, UINT32 Freq,T_RXSCAN_FREQUENT_INFO freqInfo,INT32 temp,INT32 *compVal,UINT32 *currentFreq);

typedef struct tag_rx_scan_module
{
	RxScan_Sample 	rxScanSample;
	RxScan_Calc   	rxScanCalc;
	RxScan_GetDate	rxScanGetDate;
	RxScan_GetFreq  rxScanGetFreq;
	RxScan_RstDate  rxScanRstDate;
	RxScan_GetTma	rxScanGetTma;
	UINT32          initFlag;
}T_RxScanModule;


/**************************************************************************
 *                         函数接口
 **************************************************************************/

UINT32 BspSetRxScanCommInfo(UINT32 bspRxChn,T_RXSCAN_COMMON_INFO *pRxScanCommInfo);
UINT32 BspGetRxScanCommInfo(UINT32 bspRxChn,T_RXSCAN_COMMON_INFO *pRxScanCommInfo);
UINT32 BspGetRxScanFs(UINT32 bspRxChn,UINT32 *pFs);
UINT32 BspGetRxScanFo(UINT32 bspRxChn,UINT32 band,INT32 *pFo);
UINT32 BspGetRxScanDpdStatus(UINT32 bspRxChn,UINT32 *pDpdFlag);
UINT32 BspSetRxScanVgcGain(UINT32 bspRxChn,INT32 rxAgcGain);
UINT32 BspGetRxScanVgcGain(UINT32 bspRxChn,INT32 *pRxAgcGain);
UINT32 BspGetRxScanMaxChnNum(VOID);
T_RxScanModule* BspGetRxScanModuleInfo(VOID);
UINT32 BspGetRxScanFuncInitFlag(VOID);
UINT32 BspGetRxScanCountData(UINT32 count, T_RxScan *pRxScanData);
UINT32 BspGetRxScanFreqInfo(UINT32 bspRxChn,UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep);
UINT32 BspRestRxScanAllData(VOID);
UINT32 BspRxScanFftCalc(UINT32 bspRxChn,UINT32 band,UINT32 antStat, UINT32 cellStat);
UINT32 BspSetRxScanSampleData(UINT32 sampleTimes,UINT32 samplePiontNum,DOUBLE*pSampleReal,DOUBLE*pSampleImag);
UINT32 BspRxScanGetTma(UINT32 bspRxChn,UINT32 *pTmaGain);
UINT32 BspInitRxScanCommInfo(UINT32 rxChnNum);
UINT32 BspGetRxScanSupportFlag(VOID);
UINT32 BspSetFftWinPara(DOUBLE* pFftWinCoef,UINT32 length);
UINT32 BspSetBandNcoPtr(pGetBandNcoVal pfunc);
UINT32 BspGetLoPllFreq(UINT32 devId,UINT32 *freq);
UINT32 BspSetRfCenterFreq(UINT32 centerFreq);
UINT32 BspSetRxScanIcComp(UINT32 comp);
UINT32 BspSetRxScanIsSupportOutBand(UINT32 IsSupport);
UINT32 BspGetRxScanIsSupportOutBand(VOID);
UINT32 BspSetRxScanOutBandCali(pRxScanOutOfBandCompCali uFunc);
UINT32 BspRxScanFreqLimit(RxScan_FreqLimit ucFunc);
UINT32 BspSetRfCenterFreqList(UINT32 *freqList);
UINT32 BspRxScandDataProcess(UINT32 bspRxChn,UINT32 band,UINT32 rxScanStep,UINT32 rxScanPos,UINT32 psdFreqStart,UINT32 psdFreqEnd,UINT32 fftCalNum,UINT32 sampleTimes,UINT32 antStat);
UINT32 BspSetRxScanSupportFlag(UINT32 flag);
VOID BspSetScanOutOfBandId(UINT32 bandId);
#ifdef __cplusplus
}
#endif
#endif //_FUNCLIB_RXSCAN_COMMON_H_INCLUDED_



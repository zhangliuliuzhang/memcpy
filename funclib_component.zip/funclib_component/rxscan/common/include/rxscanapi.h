/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : rxscanapi.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供频谱扫描对外接口
 * 注意事项 : 无
 * 作    者 : 10102065
 * 创建日期 : 2017-2-22 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#ifndef _FUNCLIB_RXSCAN_API_H_
#define _FUNCLIB_RXSCAN_API_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/
#define   LADAR_SUB_BAND_MAX       ((UINT16)(4))
#define   AC_CHAN_TYPE             ((UINT32)(1))
/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
typedef struct T_BspLadarPara
{
    UINT16 subBandNum;                              /* 频谱扫描频谱分段数量 分频段数=0，全部检测频段作为唯一一个分段*/
    UINT32 subBandStartFreq[LADAR_SUB_BAND_MAX];    /* 频谱扫描频谱各个分段的起始频点 单位KHz*/
    UINT32 subBandEndFreq[LADAR_SUB_BAND_MAX];      /* 频谱扫描频谱各个分段的终止频点 单位KHz*/
    UINT16 subBandAvgThrod[LADAR_SUB_BAND_MAX];      /* 频谱扫描频谱各个分段的平均功率门限 单位0.01dbm，用于产生过门限通知*/
    UINT16 subBandMaxThrod[LADAR_SUB_BAND_MAX];      /* 频谱扫描频谱各个分段的最大功率门限 单位0.01dbm*/
    UINT16 subBandExternTxPwr[LADAR_SUB_BAND_MAX];  /* 频谱扫描频谱各个分段的异系统发射功率 单位W 例如20w、40w，用于计算隔离度*/
    UINT32 reservd[LADAR_SUB_BAND_MAX];
}T_BspLadarPara;

typedef struct T_BspLadarScanData
{
    UINT32 startFreqKHz;
    UINT32 stepKHz;
    UINT32 freqNum;
    UINT16 sptMax[200];  /* 频谱隔离度最大值，单位0.01dB*/
    UINT16 sptAvg[200];  /* 频谱隔离度平均值，单位0.01dB*/
}T_BspLadarSacnData;

typedef struct T_BspLadarAlm
{
    UINT16  subBandNum;                              /* 频谱扫描频谱分段数量*/
    UINT32 subBandStartFreq[LADAR_SUB_BAND_MAX];    /* 频谱扫描频谱各个分段的起始频点 单位KHz*/
    UINT32 subBandEndFreq[LADAR_SUB_BAND_MAX];      /* 频谱扫描频谱各个分段的终止频点 单位KHz*/
    UINT8  subBandAlmFlag[LADAR_SUB_BAND_MAX];      /* 频谱扫描频谱各个分段的告警标志,0==隔离通过（隔离度大于门限）；1==隔离不足 */
}T_BspLadarAlm;

typedef struct T_BspLadarAnalyseRpt
{
    UINT16 subBandNum;                                /* 频谱扫描频谱分段数量*/
    UINT32 subBandStartFreq[LADAR_SUB_BAND_MAX];      /* 频谱扫描频谱各个分段的起始频点 单位KHz*/
    UINT32 subBandEndFreq[LADAR_SUB_BAND_MAX];        /* 频谱扫描频谱各个分段的终止频点 单位KHz*/
    UINT16 subBandAvgThordAlmAvg[LADAR_SUB_BAND_MAX]; /* 频谱扫描频谱各个分段的平均功率隔离度越门限的全部点，隔离度平均值 单位0.01db*/
    UINT16 subBandMaxThordAlmAvg[LADAR_SUB_BAND_MAX]; /* 频谱扫描频谱各个分段的最大功率隔离度越门限的全部点，隔离度平均值 单位0.01db*/
    UINT16 subBandAvgDelta[LADAR_SUB_BAND_MAX];       /* 频谱扫描频谱各个分段的平均功率隔离度越门限的全部点，隔离度最小值与门限的delta 单位0.01db*/
    UINT16 subBandMaxDelta[LADAR_SUB_BAND_MAX];       /* 频谱扫描频谱各个分段的最大功率隔离度越门限的全部点，隔离度最小值与门限的delta 单位0.01db*/
    UINT16 subBandAvgBandWidth[LADAR_SUB_BAND_MAX];   /* 频谱扫描频谱各个分段的平均功率隔离度越门限的全部点，总计带宽 单位KHz*/
    UINT16 subBandMaxBnadWidth[LADAR_SUB_BAND_MAX];   /* 频谱扫描频谱各个分段的最大功率隔离度越门限的全部点，总计带宽 单位KHz*/
}T_BspLadarAnalyseRpt;

typedef struct T_BspLadarFreqInfo
{
    T_BspLadarSacnData     freqData;
    T_BspLadarAlm          almFlg;
    T_BspLadarAnalyseRpt   analyseRpt;
}T_BspLadarFreqInfo;

/**************************************************************************
 *                         函数接口
 **************************************************************************/

UINT32 BspRxScanParaReInit(VOID);
UINT32 BspRxScanDpdStatus(UINT32 bspRxChn,UINT32 bspTxChn,UINT32 * pDpdFlag );
UINT32 BspRxScanSample(UINT32 bspRxChn,UINT32 band);
UINT32 BspRxScanCal(UINT32 bspRxChn,UINT32 band,UINT32 antStat, UINT32 cellStat);
UINT32 BspGetRxScanData(UINT32 count, T_RxScan *pRxScanData);
UINT32 BspGetRxScanFreq(UINT32 bspRxChn,UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep);
UINT32 BspRestRxScanData(VOID);

BOOL BspIsSupportLadar(VOID);
UINT32 BspLadarGetRxBspChan(VOID);
UINT32 BspLadarScan(UINT32 bspChan, T_BspLadarPara *pLadarPara, T_BspLadarFreqInfo *pLadarFreqInfo);
UINT32 BspGetLadarFreqScanChanType(VOID);

#ifdef __cplusplus
}
#endif

#endif


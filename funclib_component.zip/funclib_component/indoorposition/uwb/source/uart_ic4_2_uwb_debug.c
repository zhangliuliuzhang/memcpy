/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : uart_gps.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "uart_ic4_2_uwb_debug.h"

#define UWB_EXPRNADD_LEN 50

/* Started by AICoder, pid:s4eb8156a8wcf82141210a1e801e1c3b21e502a4 */
CHAR uwbPrintInfo[][UWB_EXPRNADD_LEN]=
{
    "BspUwbUartInit(VOID)",
    "BspStartUwb(VOID)",                             /*启动UWB测距功能*/
    "BspStopUwb(VOID)",                              /*停止UWB测距功能*/
    "BspGetUwbVerAnalysis(VOID)",                    /*UWB模块版本升级结束后版本号获取*/
    "BspGetUwbInfo(VOID)",                           /*获取UWB发送的任意200个数据*/
    "BspSetBbuMsgToUwbDelay(UINT32 delayTime)",      /*控制下行BBU到uwb数据转发线延时时间*/
    "BspSetUwbMsgToBbuDelay(UINT32 delayTime)",      /*控制上行uwb到BBU数据转发线延时时间*/
    "BspGetUwbSocketId(VOID)",
    "BspSetBbuMsgToUwbSw(UINT8 flag)",               /*控制下行BBU到uwb数据转发线程开关*/
    "BspSetUwbMsgToBbuSw(UINT8 flag)",               /*控制上行行uwb到BBU数据转发线程开关*/
    "printserverip(VOID)",                           /*打印服务端IP地址*/
    "BspDhcpServerIpInit(VOID)",                     /*获取Dhcp服务端IP地址*/
    "BspUwbSocketInit(VOID)",                        /*uwb的Socket配置初始化*/
    "BspToUwbTest(UINT32 sw)",                       /*测试下行获取版本号指令*/
    "_BspRecvBbuMsgToUwbProcess(VOID *para)",        /*下行线程*/
    "_BspRecvUwbMsgToBbuProcess(VOID *para)",        /*上行线程*/
    "dhcp(VOID)",                                    /*测试接口创建虚拟网卡eth0_dhcp*/
    "BspStartUwbMac(VOID)",                          /*向uwb发送mac地址查询的指令*/
    "printuwbmac(VOID)",                             /*打印UWB MAC地址*/
    "CfgOptNetEth3AddrTest(VOID)",                   /*配置eth3网卡信息测试接口*/
    "BspSetUwbSw(UINT8 sw)",                         /*uwb功能的开关接口,供app使用*/

};

VOID uwbhelp(VOID)
{
    UINT32 loop = 0;
    for(loop = 0; loop < NELEMENTS(uwbPrintInfo);loop++)
    {
        dbgInfo("%d. %s\n",loop, uwbPrintInfo[loop]);
    }
    return;
}
/* Ended by AICoder, pid:s4eb8156a8wcf82141210a1e801e1c3b21e502a4 */
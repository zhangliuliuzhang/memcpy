/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : uart_gps.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include <time.h>  
#include <stdio.h>
#include "bsppub.h"
#include "uart_ic4_2.h"
#include "uart_ic4_2_uwb.h"

/* UWB初始化 */
UINT32 Bsp_WfsUwbUartInit(VOID)
{
    return BspUwbUartInit();
}

/* 启动UWB测距功能 */
UINT32 Bsp_WfsStartUwb(VOID)
{
    return BspStartUwb();
}

/* SubsDist UWB测距功能：规避UWB的一个bug，初始化完成后，第二次测距需要敲 */
UINT32 Bsp_WfsSubsDistUwb(VOID)
{
    return BspSubsDistUwb();
}

UINT32 Bsp_WfsGetUwblengthInfo(UINT32 antNum , UINT8* distarr)
{
    return BspGetUwblengthInfo(antNum, distarr);
}

/* 停止UWB测距功能 */
UINT32 Bsp_WfsStopUwb(VOID)
{
    return BspStopUwb();
}

/* 解析UWB测距数据 */
UINT32 Bsp_WfsUwbDistPushDataAnalysis(VOID)
{
    return BspUwbDistPushDataAnalysis();
}

/* 获取工卡号和距离值 */
UINT32 Bsp_WfsUwbDistGetDistAndCardNum(UINT8 *cardNumberArr,  UINT8 *distArrTemp)
{
    return BspUwbDistGetDistAndCardNum(cardNumberArr, distArrTemp);
}

/* 功率等级查询 */
UINT32 Bsp_WfsStartUwbPwr(VOID)
{
    return BspStartUwbPwr();
}

/* 功率等级设置 */
UINT32 Bsp_WfsSetUwbPwr(UINT32 value1 ,UINT32 value2)
{
    return BspSetUwbPwr(value1,value2);
}
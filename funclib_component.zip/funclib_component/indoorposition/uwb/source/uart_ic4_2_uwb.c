/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : uart_gps.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : UART访问
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include <time.h>  
#include <stdio.h>
#include "uart_ic4_2_uwb.h"
#include "uartuwb.h"
#include "uart.h"
#include "uart_ic4_2.h"
#include <netinet/in.h>
#include "uartdev.h"
#include "secure_func.h"
#include "udpsocket.h"
#include <errno.h>
#include "systemcallapi.h"
#include "ichaladapt_ic4_2.h"
#include "ntl_l2ss_api.h"

#define UWB_SCC_LOOP_ENABLE     1
/*#define GPS_SCC_LOOP_DISABLE    2*/
#define UWB_SCC_DEBUG_ENABLE    3
#define UWB_SCC_DEBUG_DISABLE   4
#define UWB_SCC_FIOBAUDRATE     5
#define UWB_SCC_EX_LOOP_BACK    6
#define UWB_SCC_ERR_INF_PRN     7
#define UWB_SCC_TX_STATUS       0x10
#define UWB_SCC_RX_STATUS       0x11
/*SCC_LOOP_DISABLE宏值2在内核cgel4.x的arm体系和系统宏值定义冲突,因此修改*/
#define UWB_SCC_IOCTL_BASE      'G'
#define UWB_SCC_LOOP_DISABLE    _IOW (UWB_SCC_IOCTL_BASE, 2, unsigned long)

#define FILE_PATH_MAX_LEN    64
#define FILE_NAME_MAX_LEN    64
#define DEFAULT_FILE_PATH     "./ata/rru"
#define DEFAULT_FILE_NAME     "CUM30"

#define TEMP_INPUTCHECK(s)                        \
{                                                 \
        if(s <= 0 ||s > 200)          \
        {                                         \
            dbgInfo("Input para is invalid\n");   \
            return BSP_ERROR;                     \
        }                                         \
}

UINT32 ulUwbStartOn = 1;

char filepath[FILE_PATH_MAX_LEN+1] = {0};
//char filename[FILE_NAME_MAX_LEN+1] = {0};
char filefullname[FILE_PATH_MAX_LEN+FILE_NAME_MAX_LEN+1] = {0};
char fileversion[FILE_PATH_MAX_LEN+1] = {0};


/**************************************************************************
 * 函数名称: BspGpsUartInit(*)
 * 功能描述: UWB初始化
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspUwbUartInit(VOID)
{
    const T_UartDev *dev = BspGetUartDev(UART_DEV_TYPE_UWB, 0);
    UINT32 baudRate = dev ? dev->para.baudRate : UART_BAUD_RATE_DEFAULT;
    
    BspUwbUartIoctl(UWB_SCC_FIOBAUDRATE, baudRate);
    BspUwbUartIoctl(UWB_SCC_DEBUG_DISABLE, 0);
    BspUwbUartIoctl(UWB_SCC_EX_LOOP_BACK, 0);

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: (*)
 * 功能描述: UWB收发
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspUwbSend(UINT8 *buf, UINT32 len)
{
    return BspUwbUartSend(buf, len);
}

UINT32 BspUwbRecv(UINT8 *buf, UINT32 len)
{
    return BspUwbUartRecv(buf, len);
}

/**************************************************************************
 * 函数名称: BspStartUwb
 * 功能描述: 启动UWB测距功能
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
/* Started by AICoder, pid:pc8d7o8f8cac74d14e5f0931406f7a1043d6d45b */
UINT32 BspStartUwb(VOID)
{
    UINT8  temp[14] = "AT+UWBSTART\r\n";
    UINT8  temp_New[16] = "AT+UWBSTART=5\r\n";
    UINT32 loop;
    UINT8  ucStartDate[13] = {0};
    UINT8  ucStartDate_New[15] = {0};
    UINT32 cnt = 13;

    for(loop = 0;loop < cnt;loop++)
    {
    	ucStartDate[loop] = temp[loop];
    }
    BspUwbSend(ucStartDate,cnt);

    cnt = 15;

    for(loop = 0;loop < cnt;loop++)
    {
    	ucStartDate_New[loop] = temp_New[loop];
    }
    BspUwbSend(ucStartDate_New,cnt);
    return BSP_OK;
}
/* Ended by AICoder, pid:pc8d7o8f8cac74d14e5f0931406f7a1043d6d45b */

/**************************************************************************
 * 函数名称: BspSUBSDISTUwb
 * 功能描述: SubsDist UWB测距功能
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
/* Started by AICoder, pid:yde5fee273ab62814c1a089cf0a4e8119042baa4 */
UINT32 BspSubsDistUwb(VOID)
{
    UINT8  temp[21] = "AT+SUBSDIST=1000\r\n";
    UINT32 loop;
    UINT8  ucStartDate[18] = {0};
    UINT32 cnt = 18;

    BspStartUwb();
    BspSysMsDelay(30);
    for(loop = 0;loop < cnt;loop++)
    {
        ucStartDate[loop] = temp[loop];
    }
    BspUwbSend(ucStartDate,cnt);
    
    return BSP_OK;
}
/* Ended by AICoder, pid:yde5fee273ab62814c1a089cf0a4e8119042baa4 */
/**************************************************************************
 * 函数名称: BspStopUwb
 * 功能描述: 停止UWB测距功能
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspStopUwb(VOID)
{
    UINT8  temp[13] = "AT+UWBSTOP\r\n";
    UINT32 loop;
    UINT8  ucStopDate[13] = {0};
    UINT32 cnt = 12;

    for(loop = 0;loop < cnt;loop++)
    {
    	ucStopDate[loop] = temp[loop];
    }

    BspUwbSend(ucStopDate,cnt);
    return BSP_OK;
}
UINT32 uiDataCheckFlag = 1;
UINT32 setdatacheck(UINT32 DataCheckFlag)
{
    uiDataCheckFlag = DataCheckFlag;
    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspUpgStarUwb
 * 功能描述: 暂时不考虑文件名获取与计算文件大小。
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspUpgStarUwb(UINT32 FileSize ,UINT32 totalPkgNum)
{
 /*   UINT8  temp[48] = "AT+UPGSTART=CUM30V100R001B002,91340,457,200,1\r\n";*/
    UINT32 cnt = 52;
    UINT8   temp[52] = {0};
    (void)zte_snprintf_s((char*)temp, sizeof(temp), "AT+UPGSTART=CUM30V100,%u,%u,%u,%u\r\n", FileSize, totalPkgNum,200,1);
  /*  sprintf_s(temp,sizeof(temp) ,"AT+UPGSTART=CUM30V100,%u,%u,%u,%u\r\n", FileSize, totalPkgNum,200,1);*/
    cnt = zte_strnlen_s((const char*)temp,sizeof(temp));
    return BspUwbSend(temp,cnt);

}
/**************************************************************************
 * 函数名称: BspCharConversionUint
 * 功能描述: 字符转数字。
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32	BspCharConversionUint(UINT32 DataStart,UINT32 DataEnd,UINT8 * Data)
{
	UINT32 loop = 0;
	UINT32 Index = 0;

	for(loop = DataStart;loop< DataEnd+1;loop++)
	{
		Index = (pow(10,(DataEnd - loop))) * (Data[loop]-'0') + Index;
	}
	return Index;
}
/**************************************************************************
 * 函数名称: BspUpgGetUwbAnalysis
 * 功能描述: UWB模块版本拆包请求解析。
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/

/* Started by AICoder, pid:w5f0749ccdc8e9514a690a00b0b52e8f24f762dd */
UINT32 BspUpgGetUwbAnalysis(UINT32 * PkgIndex,UINT32 * PkgLen)
{
    UINT8  temp[200] = {0};
    UINT32 loop = 0;
    UINT32 loopDate = 0;
    //UINT8  ucUpgDate[48] = {0};
   // UINT32 cnt = 47;
    UINT8  ucStartDate[10] = "AT+UPGGET=";
    UINT32 uiDataHeaderLength = 0;/*去除串包的冗余数据及数据头长*/
    INT32  recvLen = 0;
    UINT32 PkgIndexStart = 0;
    UINT32 PkgIndexEnd = 0;
    UINT32  PkgLenStart = 0;
    UINT32  PkgLenEnd = 0;

    recvLen = BspUwbRecv(temp,sizeof(temp));

    if (recvLen <= 0 ||recvLen > 200)
    {
        dbgErr("recv NONE or recv return Error!\n");
        return BSP_ERROR;
    }

    /* 计算 去除串包的冗余数据及数据头长后开始的数组下标*/
    if(uiDataCheckFlag)
    {
	    for(loop = 0;loop < recvLen;loop++)
        {
	    	dbgInfoEx("loop:%d,temp:%c\n",loop,temp[loop]);
            if(temp[loop] == ucStartDate[loopDate])
		    {
            	dbgInfoEx("loopDate:%d,ucStartDate:%c\n",loopDate,ucStartDate[loopDate]);
            	loopDate ++;

			    if(temp[loop] == '=' )
            	{
            		 uiDataHeaderLength = loop +1;
            		 break;
            	}
            	if(loopDate >=  10)
            	{
    		        return BSP_ERROR;
            	}

		    }
	    }
	}
   /* 计算包序号的起始下标和结束下标*/
    PkgIndexStart = uiDataHeaderLength;
    for (loop = uiDataHeaderLength; loop < recvLen; loop++)
    {
    	dbgInfoEx("%c\n",temp[loop]);
	    if(temp[loop] == ',')
		{
            TEMP_INPUTCHECK(loop-1);
	    	PkgIndexEnd = loop-1;
	    	PkgLenStart = loop+1;
	    	dbgInfoEx("PkgIndexEnd:%d\n",PkgIndexEnd);
	    	dbgInfoEx("PkgLenStart:%d\n",PkgLenStart);
	    	break;
		}
    }
    /* 计算包长的起始下标和结束下标*/
	PkgLenEnd = PkgLenStart;
    for(loop = PkgLenStart ; loop < recvLen; loop++)
	{
	    if(temp[loop]>= '0' && temp[loop]<= '9')
		{
		   PkgLenEnd ++;
		}
		else
		{
		   break;
		}
	}

    if(PkgIndexEnd >=200 || (PkgLenEnd-1) >= 200)
    {
    	return BSP_ERROR;
    }


   *PkgIndex = BspCharConversionUint(PkgIndexStart,PkgIndexEnd,temp);
   TEMP_INPUTCHECK(PkgLenEnd-1);
   *PkgLen = BspCharConversionUint(PkgLenStart,PkgLenEnd-1,temp);/*PkgLenEnd 要不要-1看最后带不带/0*/
   dbgInfoEx("PkgIndex:%d,PkgLen:%d\n",*PkgIndex,*PkgLen);
    return BSP_OK;
}
/* Ended by AICoder, pid:w5f0749ccdc8e9514a690a00b0b52e8f24f762dd */

/**************************************************************************
 * 函数名称: BspGetUwbVerAnalysis
 * 功能描述: UWB模块版本升级结束后版本号获取。
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspGetUwbVerAnalysis(VOID)
{
    UINT8  temp[200] = {0};
    UINT32 loop = 0;
    UINT32 loopDate = 0;
    UINT8  ucStartDate[11] = "AT+PUSHVER=";
    UINT32 uiDataHeaderLength = 0;/*去除串包的冗余数据及数据头长*/
    INT32  recvLen = 0;
    UINT32 PkgIndexStart = 0;


    recvLen = BspUwbRecv(temp,sizeof(temp));

    if (recvLen <= 0 ||recvLen > 200)
    {
        dbgErr("recv NONE or recv return Error!\n");
        return BSP_ERROR;
    }

    /* 计算 去除串包的冗余数据及数据头长后开始的数组下标*/
    if(uiDataCheckFlag)
    {
	    for(loop = 0;loop < recvLen;loop++)
        {
	    	dbgInfoEx("loop:%d,temp:%c\n",loop,temp[loop]);
            if(temp[loop] == ucStartDate[loopDate])
		    {
            	dbgInfoEx("loopDate:%d,ucStartDate:%c\n",loopDate,ucStartDate[loopDate]);
            	loopDate ++;
			    if(temp[loop] == '=' )
            	{
            		 uiDataHeaderLength = loop +1;
            		 break;
            	}
            	if(loopDate >=  11)
            	{
    		        return BSP_ERROR;
            	}
		    }
	    }
	}
   /* 打印版本号，并校验版本升级是否成功*/
    PkgIndexStart = uiDataHeaderLength;
	dbgInfo("\n");
    for (loop = PkgIndexStart; loop < recvLen; loop++)
    {
    	dbgInfo("%c",temp[loop]);
    }

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspSUBSDISTUwb
 * 功能描述: SubsDist UWB测距功能
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSendCgmrToUwb(VOID)
{
    UINT8  temp[11] = "AT+CGMR?";
    /*  UINT32 loop;
    UINT8  ucCgmrDate[10] = {0};*/
    UINT32 cnt = 11;
/*
    for(loop = 0;loop < cnt;loop++)
    {
    	ucCgmrDate[loop] = temp[loop];
    }
*/
    cnt = zte_strnlen_s((const char *)temp,sizeof(temp));

    return BspUwbSend(temp,cnt);
}

/**************************************************************************
 * 函数名称: BspGetUwbVerAnalysis
 * 功能描述: UWB模块正常时版本号获取。
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspGetCgmrVerAnalysis(VOID)
{
	/*  UINT8  temp[50] = {0};
    UINT32 loop = 0;
    INT32  recvLen = 0;*/

    BspSendCgmrToUwb();
/*
    for(loop = 0;loop< 5;loop++)
    {
        BspSysMsDelay(20);
        recvLen = BspUwbRecv(temp,sizeof(temp));
        if (recvLen <= 0 ||recvLen > 200)
        {
            dbgErr("recv NONE or recv return Error!\n");
            continue;
        }
    	dbgInfo("loop:%s,temp:%s\n",loop,temp);
    }
    */
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetUwbInfo
 * 功能描述:获取UWB发送的任意200个数据
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspGetUwbInfo(VOID)
{
    UINT8  temp[200] = {0};

    INT32  recvLen = 0;

    recvLen = BspUwbRecv(temp,sizeof(temp));
    if (recvLen <= 0 ||recvLen > 200)
    {
        dbgErr("recv NONE or recv return Error!\n");
        return BSP_ERROR;
    }
    dbgInfo("UwbInfo:%s\n",temp);
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspUpgRruPutPkgToUwb
 * 功能描述: RRU 向UWB模组发送拆过的版本子包
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspUpgRruPutPkgToUwb()
{
  //  UINT8  ucStartDate[10] = "AT+UPGPUT=";

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspUwbDistPushDataAnalysis
 * 功能描述: UWB模块请求升级包解析
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspUwbDistPushDataAnalysis(VOID)
{
    UINT8  temp[1200] = {0};
    INT32  recvLen;
    UINT32 loop = 0;
    UINT32 loopDate = 0;
    UINT8  ucStartDate[12] = "AT+DISTPUSH=";
    UINT32 uiDataHeaderLength = 0;/*数据头长*/
    /*UINT8  temp[1200]="AT+DISTPUSH=65800001,10000,1,1696992280,2,000002AE&168&63&3320&-57&2024-01-022,000002AE&168&63&3320&-57&2024-01-022";*/
    UINT32 date = 0 ;
    UINT32 num = 0;
    recvLen = BspUwbRecv(temp,sizeof(temp));
    if (recvLen <= 0 ||recvLen > 1200)
    {
        dbgErr("recv NONE or recv return Error!\n");
        return BSP_ERROR;
    }

    /* 计算 去除串包的冗余数据及数据头长后开始的数组下标*/
    if(uiDataCheckFlag)
    {
	    for(loop = 0;loop < recvLen;loop++)
        {
	    	dbgInfoEx("loop:%d,temp:%c\n",loop,temp[loop]);
            if(temp[loop] == ucStartDate[loopDate])
		    {
            	dbgInfoEx("loopDate:%d,ucStartDate:%c\n",loopDate,ucStartDate[loopDate]);
            	loopDate ++;
			    if(temp[loop] == '=' )
            	{
            		 uiDataHeaderLength = loop +1;
            		 break;
            	}
            	if(loopDate >=  12)
            	{
    		        return BSP_ERROR;
            	}
		    }
	    }
	}


    dbgInfo("----English Meaning Description----\n");
    dbgInfo("M_DEVEUI\n");
    dbgInfo("INDEX\n");
    dbgInfo("ANT\n");
    dbgInfo("TIME\n");
    dbgInfo("NUM\n");
    dbgInfo("DEVEUI&EVENT&DIST(cm)&VBvat(0.01v)&RSSI&TICKPOS(ms)\n");
    dbgInfo("..........\n");

    dbgInfo("----中文含义描述----\n");
    dbgInfo("CUM30 模组地址\n");
    dbgInfo("推送数据编号\n");
    dbgInfo("天线编号\n");
    dbgInfo("UTC 时间(采用GPS、底板等方式对时取到的时间) \n");
    dbgInfo("有距离终端信息个数\n");
    dbgInfo("工卡设备地址&事件编号&工卡距离值(cm)&工卡电压值(0.01v)&工卡接收信号&T工卡测距发生的时间戳(偏移ms) \n");
    dbgInfo("..........\n");

    for (loop = uiDataHeaderLength; loop < recvLen; loop++)
    {
	    if(temp[loop] == ',')
		{
	    	 dbgInfo(" \n");
	    	 date ++;
	    	 if(date > (num+4) )
	    	 {
	    		 return BSP_OK;
	    	 }
			 continue;
		}
	    if(4 == date)
	    {
	    	num = temp[loop] -'0';
	    }
	    dbgInfo("%c",temp[loop]);
    }
    dbgInfo("\n");

    return BSP_OK;
}

/* Started by AICoder, pid:74188c2a12z0030146c10bad5000ab3c7e36df10 */
UINT32 BspGetTwoDataHead(UINT32 recvLen, UINT32 *headFlag, UINT8 *temp, UINT32 *headFlagOneIndex)
{
    UINT32 loop = 0;
    UINT32 equalFlag = 0; /* 0：相等 非0：不相等 */
    UINT32 uiDataHeaderLength = 12;/*数据头长*/
    UINT8  ucStartDate[12] = "AT+PUSHDIST";/* 这个是字符串，字符串和字符数组的区别就是看里面有没有 '\0',这里数组长度是12，字符个数是11个，所以最后一个位置留给了 '\0'  */

    /*截取两个数据头之间的完整的数据，如果没有则返回错误*/
    for(loop = 0;loop < recvLen;loop++)
    {
        if (2 == *headFlag)
        {
            break;
        }
        
        if (1200 <= loop)
        {
            return BSP_ERROR;
        }
        
        if(temp[loop] == 'A')
        {
            equalFlag = 0;
            for (UINT32 i = 0; i < (uiDataHeaderLength-3); i++)// (uiDataHeaderLength-1)是因为字符数组最后一位存的是 '\0'
            {
                PARAM_RANGE_CHECK(loop+i,1200);
                equalFlag |= (temp[loop+i] != ucStartDate[i]) ? 1 : 0;
                dbgInfo("%d,%d ",temp[loop+i],ucStartDate[i]);
            }
            dbgInfo("%d \n",*headFlag);
            headFlagOneIndex[*headFlag] = (0 == equalFlag) ? loop : headFlagOneIndex[*headFlag];
            *headFlag = (0 == equalFlag) ? (*headFlag+1) : *headFlag;
        }

    }
    return BSP_OK;
}
/* Ended by AICoder, pid:74188c2a12z0030146c10bad5000ab3c7e36df10 */
 
/* UWB获取工卡号和距离值 cardNumberArr：工卡号字符数组 ，dist距离值 */
UINT32 BspUwbDistGetDistAndCardNum(UINT8 *cardNumberArr, UINT8 *distArrTemp)
{
    UINT8  temp[1200] = {0};
    INT32  recvLen = 0;
    UINT32 loop = 0;
    UINT32 tmpFlag = 0;
    // UINT8 distArrTemp[20] = {0};
    UINT32 tempIndexDist = 19;
    UINT32 tempIndexCardNum = 19;
    /*UINT8  temp[1200]="AT+DISTPUSH=65800001,10000,1,1696992280,2,000002AE&168&63&3320&-57&2024-01-022,000002AE&168&63&3320&-57&2024-01-022";*/
    recvLen = BspUwbRecv(temp,sizeof(temp));
    UINT32 headFlag = 0; /* 记录有几个数据头 */
    UINT32 headFlagOneIndex[2] = {0};/* 两个数据头中 'A'字符在temp中的Index */
    
    INPUT_POINTER_CHECK(cardNumberArr);
    INPUT_POINTER_CHECK(distArrTemp);

    /* if (recvLen <= 0 ||recvLen >= 1200) */
    PARAM_RANGE_CHECK(recvLen, 1200);
    PARAM_RANGE_CHECK(0, recvLen);

    /*截取两个数据头之间的完整的数据，如果没有则返回错误*/
    BspGetTwoDataHead(recvLen, &headFlag, &(temp[0]), &(headFlagOneIndex[0]));

    if (2 > headFlag)/* 没有找到两个完整的数据头 */
    {
        dbgErr("can not find two head !");
        return BSP_ERROR;
    }
    
    dbgInfo("the data of between two head: headOneIndex:%d ~ %d \n ",headFlagOneIndex[1],headFlagOneIndex[0]);
    for (loop = headFlagOneIndex[0]; loop < headFlagOneIndex[1]; loop++)
    {
        dbgInfo("%c ",temp[loop]);
    }
    dbgInfo("\n");
    /* 000002AE&168&63&3320&-57&2024-01-022 
       000002AE:工卡号
       63:距离值 */
    for (loop = headFlagOneIndex[1]; loop > headFlagOneIndex[0]; loop--)
    {
        if ((1200 <= loop))
        {
            return BSP_ERROR;
        }
        
        tmpFlag = ('&' == temp[loop]) ? (tmpFlag+1) : tmpFlag;

        if ((3 == tmpFlag) && ('&' != temp[loop]))/* 记录距离值 */
        {
            distArrTemp[tempIndexDist] = temp[loop];
            tempIndexDist--;
        }
        
        if ((5 == tmpFlag) && (',' == temp[loop]))/* 记录完毕 */
        {
            break;
        }

        if ((5 == tmpFlag) && ('&' != temp[loop]))/* 记录工卡号 */
        {
            cardNumberArr[tempIndexCardNum] = temp[loop];
            tempIndexCardNum--;
        }

        if ((0 == tempIndexCardNum) || (0 == tempIndexDist))/* 防止越界 */
        {
            break;
        }
        
    }

    // *dist = atoi(distArrTemp);

    return BSP_OK;
}

UINT32 BspTestGetDistAndCardNum(VOID)
{
    UINT8 cardNumberArr[20] =  {'0'};
    UINT8 distArrTemp[20] =  {'0'};
    UINT32 tmpFlag = 0;

    BspUwbDistGetDistAndCardNum(&(cardNumberArr[0]), &(distArrTemp[0]));

    dbgInfo("cardNumberArr: ");

    for (tmpFlag = 0; tmpFlag < 20; tmpFlag++)
    {
        dbgInfo("%c ",cardNumberArr[tmpFlag]);
    }
    dbgInfo("\n");

    dbgInfo("distArrTemp: ");
    for (tmpFlag = 0; tmpFlag < 20; tmpFlag++)
    {
        dbgInfo("%c ",distArrTemp[tmpFlag]);
    }
    dbgInfo("\n");

    return BSP_OK;
}

VOID uwbrecv(VOID)
{
    UINT8  temp[100] = {0};
    INT32  recvLen;
    UINT32 loop;
    
    recvLen = BspUwbRecv(temp,sizeof(temp));
    if (recvLen <= 0 ||recvLen > 100)
    {
        dbgErr("recv NONE or recv return Error!\n");
        return ;
    }

    for (loop = 0; loop < recvLen; loop++)
    {
        if ((loop & 0xf) == 0)
        {
            dbgInfo("\n");
        }
        dbgInfo("%02x ", temp[loop]);
    }
    dbgInfo("\n");
}

VOID UwbRecvTaskSwitch(UINT32 ulOnOff)
{
    ulUwbStartOn = ulOnOff;
    dbgInfo("Gps Recv Task Switch is %s\n",(ulOnOff==1)?"On":"Off");
}

/*VOID UwbRecvTask(VOID)
{
    dbgInfo("%s Start!\n",__FUNCTION__);
    while(ulUwbStartOn==1)
    {
    	BspUwbDistPushDataAnalysis();
        BspSysMsDelay(1000);
    }
}
UINT32 UwbTestTaskStart(VOID)
{
    pthread_t threadId = 0;
    INT32     errCode = 0;

    errCode = pthread_create(&threadId, NULL, (VOID *)UwbRecvTask, NULL);
    if (0 != errCode)
    {
        dbgInfo("create thread<%s> failed!\n",__FUNCTION__);
    }
    else
    {
        dbgInfo("create thread<%s> success!\n",__FUNCTION__);
    }
    return errCode;
}
*/
UINT32 uwbsendtstdata(UINT32 dataFlag,UINT32 tstcnt)
{
    UINT8  temp[100] = {0};
    UINT32 loop;
    /* UINT32 buflen; */
    UINT32 cnt = tstcnt;
    UINT32 urandomGet[100] = {0};

    if (tstcnt > 100)/*参数检查，防止访问越界*/
    {
        dbgErr("%s test data can not more than 100!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /* CID 14326 */
    if (BspGetRandomData(cnt, urandomGet)!=BSP_OK)
    {
        dbgErr("BspGetRandomData faild!\n");
        return BSP_ERROR;
    } 

    for (loop = 0; loop < cnt; loop++)
    {
        if (0 == dataFlag)
        {
            temp[loop] = loop;
        }
        else
        {
            temp[loop]= ntohl(urandomGet[loop])%cnt;
        }
    }

	
    for (loop = 0; loop < cnt; loop++)
    {
		
        if ((loop & 0xf) == 0)
        {
            dbgInfo("\n");
        }
        dbgInfo("%02x ", temp[loop]);
    }
    dbgInfo("\n");
    
    return BspUwbSend(temp,cnt);
}


VOID BspUwbUartRecvTest(VOID)
{
    uwbrecv();
}

UINT32 BspUwbUartSendDataTest(UINT32 dataFlag, UINT32 tstcnt)
{
    return uwbsendtstdata(dataFlag, tstcnt);
}

/* 给工装用的485接口 */
UINT32 BspWfsUartSendDataTest(UINT32 type, UINT32 devIndex,UINT32 dataFlag,UINT32 tstcnt,UINT8 *sendData)
{
    UINT8  temp[100] = {0};
    UINT32 loop = 0;
    UINT32 cnt = 0;
    UINT32 urandomGet[100] = {0};

    cnt = tstcnt;

    if (tstcnt > 100)/*参数检查，防止访问越界*/
    {
        dbgInfo("%s test data can not more than 100!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /* CID 20363 */
    if (BspGetRandomData(cnt, urandomGet) != BSP_OK)
    {
        dbgInfo("BspGetRandomData faild!\n");
        return BSP_ERROR;
    }
    
    for (loop = 0; loop < cnt; loop++)
    {
        if (0 == dataFlag)
        {
            temp[loop] = loop;
        }
        else
        {
            temp[loop]= ntohl(urandomGet[loop])%cnt;
        }
    }

    for (loop = 0; loop < cnt; loop++)
    {
        if ((loop & 0xf) == 0)
        {
            dbgInfo("\n");
        }
        dbgInfo("%02x ", temp[loop]);
    }
    dbgInfo("\n");

    if (NULL != sendData)
    {
        memcpy_s(sendData, 100*sizeof(UINT8), &(temp[0]), 100*sizeof(UINT8));
    }
    
    return BspUartDevSend(type,devIndex,temp,cnt);
}

/* uart接收测试 */
VOID BspWfsUartRecvTest(UINT32 type, UINT32 devIndex, UINT8 *recvData)
{
    UINT8  temp[100] = {0};
    UINT32 recvLen = 0;
    UINT32 loop = 0;
    
    recvLen = BspUartDevRecv(type,devIndex,temp,sizeof(temp));
    if ((recvLen == 0) || (recvLen > 100))
    {
        dbgInfo("recv NONE or recv return Error!\n");
        return ;
    }
    if (NULL != recvData)
    {
        memcpy_s(recvData, 100*sizeof(UINT8), &(temp[0]), 100*sizeof(UINT8));
    }
    
    for (loop = 0; loop < recvLen; loop++)
    {
        if ((loop & 0xf) == 0)
        {
            dbgInfo("\n");
        }
        dbgInfo("%02x ", temp[loop]);
    }
    dbgInfo("\n");
}

/**************************************************************************
 * 函数名称: BspU16SumCheck
 * 功能描述: 版本校验
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT16 BspU16SumCheck(UINT8 *dst, UINT16 size)  //版本包应答，最后一位的CRC参数。
{
    uint16_t sum = 0;
    while( size-- )
    {
        sum += *dst++;
    }
    return sum;
}

/**************************************************************************
 * 函数名称: BspSerializeUpgradePut
 * 功能描述: UWB 版本串行升级
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT16 BspSerializeUpgradePut(UINT32 pkgIndex, UINT8 *pkg, UINT16 pkgLen, UINT8 dst[600])
{
	UINT16 len        = 0;
    char   buf[600+1] = {0};
    (void)zte_snprintf_s(buf+zte_strnlen_s(buf,sizeof(buf)), sizeof(buf), "AT+UPGPUT=%u,%u", pkgIndex, pkgLen);
	if(pkgLen > 0)
	{
		len = zte_strnlen_s(buf,sizeof(buf));
		buf[len++] = ',';
	    for(int i = 0; i< pkgLen; i++)
	    {
            (void)zte_snprintf_s((char *)&buf[len+i*2], sizeof(buf), "%02X", pkg[i]);

	    }
	}
    (void)zte_snprintf_s(buf+zte_strnlen_s(buf,sizeof(buf)), sizeof(buf), ",%04X\r\n", BspU16SumCheck(pkg, pkgLen));
	len = zte_strnlen_s(buf,sizeof(buf));
    memcpy_s(dst,len, buf, len);
    return len;
}

/*
int BspFindUpgradeFile(void)
{
	DIR *dir;
	struct dirent *entry;
	char keyword[] = DEFAULT_FILE_NAME; // 设置需要匹配的关键字
	char fname[FILE_NAME_MAX_LEN+1];
	char ver[FILE_NAME_MAX_LEN+1];

	if(strlen(filefullname)) {
		return 0;
	}
	memset(fname, 0, sizeof(fname));

    if ((dir = opendir(DEFAULT_FILE_PATH)) != NULL) { // 打开当前工作目录(".")
        while ((entry = readdir(dir)) != NULL) { // 遍历目录中的每个条目
            //判断文件名是否包含关键字
            if (MemNCaseFind(entry->d_name, strlen(entry->d_name), keyword, strlen(keyword)) != NULL &&
				MemNCaseFind(entry->d_name, strlen(entry->d_name), ".bin", strlen(".bin")) != NULL) {
                // 输出符合条件的文件名
               // LOG(IWG_LOG_ERROR,g_moduleLogLevel,MODULE_NAME, "find local upgrade file '%s'\n", entry->d_name);
				memcpy(fname, entry->d_name, StrLen(entry->d_name));
                break;
            }
        }

        closedir(dir); // 关闭目录
    } else {
        perror("Dir faild");
        return -1;
    }
    memset(ver, 0, sizeof(ver));

	if(strlen(fname) > 0) {
		char *dotPos = strchr(fname, '.');
		if(dotPos) {
			memset(fileversion, 0, sizeof(fileversion));
			memcpy(fileversion, fname, dotPos - fname);
		}
		memset(filepath, 0, sizeof(filepath));
		memset(filename, 0, sizeof(filename));
		memset(filefullname, 0, sizeof(filefullname));

		memcpy(filepath, DEFAULT_FILE_PATH, strlen(DEFAULT_FILE_PATH));
		memcpy(filename, fname, strlen(fname) > FILE_NAME_MAX_LEN ? FILE_NAME_MAX_LEN : strlen(fname));

		memcpy(filefullname, filepath, strlen(filepath));
		*(filefullname+strlen(filefullname)) = '/';
		memcpy(filefullname+strlen(filefullname), filename, strlen(filename));
	}
    return 0;
}
*/

#define filefullname                     "/ata/rru/CUM30V100.bin"
/* Started by AICoder, pid:e5c24f1a15ab4799ab965e2bb78f5a95 */
INT32 BspReadUpgradeFile(long position, char *buf, int len)
{
	FILE *fp = NULL;
	size_t bytesRead = 0;
    INT32  snpRet = 0;
    CHAR *const dirlist[1] = {"/ata/rru"};
    rsize_t dirlist_size = 1;
    
	if(zte_strnlen_s(filefullname,sizeof(filefullname)))
	{
        INT32 ulRet = zte_fopen_s(&fp, filefullname, "rb", dirlist, dirlist_size);
        if(0 != ulRet)
        {
            dbgInfo ("[%s]:file open %s fail %s\n", __FUNCTION__, filefullname, zte_strerror_s (errno));
            return BSP_ERROR;
        }
	}
	if(fp)
	{
		// 将文件指针移动到指定位置
		if (fseek(fp, position, SEEK_SET) != 0)
		{
			//LOG(IWG_LOG_ERROR,g_moduleLogLevel,MODULE_NAME,"open upgrade file position '%u'failed\n", position);
			//dbgInfo(IWG_LOG_ERROR,g_moduleLogLevel,MODULE_NAME,"open upgrade file position '%u'failed\n", position);
            snpRet = fclose(fp);
            FCLOSE_CHECK(snpRet);
            return -2;
		}
		//每次最多读取fp大小的字符到缓冲区
		bytesRead = fread(buf, sizeof(char), len, fp);
		if(0 == bytesRead)
		{
			dbgInfo("fread return Error!\n");
		}
	 }
	 else
	 {
       if(zte_strnlen_s(filefullname,sizeof(filefullname)))
	   {
			// LOG(IWG_LOG_ERROR,g_moduleLogLevel,MODULE_NAME,"open upgrade file '%s'failed\n", filefullname);
	   }
	   else
	   {
			//LOG(IWG_LOG_ERROR,g_moduleLogLevel,MODULE_NAME,"open upgrade file 'NULL'failed\n");
	   }

	   dbgInfo("open upgrade file failed\n");
	  /* if(fp)
	   {
	       fclose(fp); // 确保文件在所有路径上都被关闭
	   }
		return -1;*/
	}

    if(fp)
    {
		if(fclose(fp))// 确保文件在所有路径上都被关闭
		{
			dbgInfo("fclose return Error!\n");
		}
    }
	return bytesRead;
}
/* Ended by AICoder, pid:e5c24f1a15ab4799ab965e2bb78f5a95 */

/* Started by AICoder, pid:b470019b0a14465b8e9b5aeba3537c8a */
/**************************************************************************
 * 函数名称: BspUwbUpdate
 * 功能描述: UWB 版本串行升级
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspUwbUpdate(UINT32 FileSize ,UINT32 totalPkgNum)
{
	INT32 readFileBytes =0;
	UINT32 SinglePkgLen = 0;/*单包内容长度*/
	UINT16 TotalSinglePkgLen = 0;/*单包总长，包含子包头及包内容*/
	UINT32 pkgIndex = 0;
	UINT32 loop =0 ;
    UINT8 buf[600] = {0};
	UINT32 buffer_size = 200; // 假设我们需要200个char的缓冲区
	UINT32 loopNum = 0; // 循环次数统计
	UINT32 ErrorPkgNum = 0; // 错包计算
	UINT8 *buffer = malloc(buffer_size); // 使用malloc申请内存
    if (buffer == NULL) {
        // 处理内存分配失败的情况
        return BSP_ERROR;
    }

    BspUpgStarUwb(FileSize,totalPkgNum);
    for(loop = 0;loop < totalPkgNum;loop++)
    {
        BspSysMsDelay(30);
        memset(buffer, 0, buffer_size);
	    BspUpgGetUwbAnalysis(&pkgIndex,&SinglePkgLen);

	    readFileBytes = BspReadUpgradeFile(pkgIndex*SinglePkgLen, (char*)buffer, SinglePkgLen);
	    dbgInfo("BspUwbUpdate loop:%d ,pkgIndex:%d, SinglePkgLen:%d\n",loop,pkgIndex,SinglePkgLen);

	    loopNum++;
    	if(loopNum > totalPkgNum)
    	{
    		ErrorPkgNum = loopNum - totalPkgNum;
    		if( ErrorPkgNum > 50)
    		{

    			 dbgInfo("The number of error packets exceeds the range！！ ErrorPkgNum:%d \n",ErrorPkgNum);
    			 free(buffer);
    			 return BSP_OK;
    		}
    	}
	    if(SinglePkgLen <=0 || SinglePkgLen>200)
	    {
	    	loop = pkgIndex;
	    	continue;
	    }

	    if(readFileBytes > 0)
	    {
	    	TotalSinglePkgLen = BspSerializeUpgradePut(pkgIndex, buffer, readFileBytes, buf);
	        BspUwbSend(buf,TotalSinglePkgLen);
	        loop = pkgIndex ;
		    dbgInfo("BspUwbUpdate pkg loop:%d\n",loop);

	    }
    }
     BspSysMsDelay(5);
     BspGetUwbVerAnalysis();
     BspSysMsDelay(15);
     BspGetUwbVerAnalysis();
	 free(buffer);
	 return BSP_OK;
}

/* Ended by AICoder, pid:b470019b0a14465b8e9b5aeba3537c8a */



/**************************************************************************
 以下函数代码为UWB正式商用方案代码
 * ------------------------------------------------------------------------
 **************************************************************************/
#define DHCP_UDHCPC_LOG             "/ata/rru/udhcpc.log"
#define RECV_BUF_LEN                (1024*3)
#define SEND_BUF_LEN                (512)
#define MAC_ADDR_LEN                (6) /*mac地址的长度*/
#define UWB_SW_OPEN                 (1) /*UWB功能使能*/
#define UWB_SW_CLOSE                (0) /*UWB功能不使能*/

char g_serverIp[50] = {0};
UINT8 g_uwbMac[MAC_ADDR_LEN] = {0};
UINT8 bbuMsgToUwbSw = 0;
UINT8 uwbMsgToBbuSw = 0;
UINT32 g_uwbSocketId = 0xff;//默认
UINT32 socketCnt = 0;//socket默认初始化次数，目前只能初始化一次
UINT32 dhcpFlag  = 0;  //dhcp请求默认初始化，0请求未成功
UINT32 bbuMsgToUwbDelay = 50;//下行延时发包时间（ms）
UINT32 uwbMsgToBbuDelay = 6;//上行延时发包时间（ms）

pOpenUwbMacInMacSwitchFunc openUwbMacInMacSwitchFunc = NULL;

UINT32 BspOpenUwbMacInMacSwitchFunc(pOpenUwbMacInMacSwitchFunc uwbFunc)
{
    openUwbMacInMacSwitchFunc = uwbFunc;
    return BSP_OK;
}

/* Started by AICoder, pid:72ab8da64e0805e14a8e0bcf90503f8a9b55b002 */
/**************************************************************************
 * 函数名称: BspSetSocketCnt
 * 功能描述: 控制SocketInit初始化次数，目前只能初始化一次
 * 输入参数: UINT32 num  0：修改成未初始化状态；非0：不能使用非0值。会导致socket初始化失败。
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSetSocketCnt(UINT32 num)
{
    socketCnt = num;
    dbgInfo("[%s]socket init cnt is %d.\n", __FUNCTION__,socketCnt);
    return BSP_OK;
}

UINT32 BspGetSocketCnt(VOID)
{
    return socketCnt;
}

/**************************************************************************
 * 函数名称: BspSetDhcpFlag
 * 功能描述: 控制DhcpInit初始化次数，目前只能初始化一次
 * 输入参数: UINT32 num  0：修改成未初始化状态；非0：重新初始化dhcp。
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSetDhcpFlag(UINT32 num)
{
    dhcpFlag = num;
    dbgInfo("[%s]dhcp init flag is %d.\n", __FUNCTION__,dhcpFlag);
    return BSP_OK;
}

UINT32 BspGetDhcpFlag(VOID)
{
    return dhcpFlag;
}

/**************************************************************************
 * 函数名称: BspSetBbuMsgToUwbDelay
 * 功能描述: 控制下行BBU到uwb数据转发线延时时间
 * 输入参数: UINT32 delayTime （ms）
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSetBbuMsgToUwbDelay(UINT32 delayTime)
{
    bbuMsgToUwbDelay = delayTime;
    return BSP_OK;
}

UINT32 BspGetBbuMsgToUwbDelay(VOID)
{
    return bbuMsgToUwbDelay;
}

/**************************************************************************
 * 函数名称: BspSetBbuMsgToUwbDelay
 * 功能描述: 控制上行uwb到BBU数据转发线延时时间
 * 输入参数: UINT32 delayTime （ms）
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSetUwbMsgToBbuDelay(UINT32 delayTime)
{
    uwbMsgToBbuDelay = delayTime;
    return BSP_OK;
}

UINT32 BspGetUwbMsgToBbuDelay(VOID)
{
    return uwbMsgToBbuDelay;
}
/* Ended by AICoder, pid:72ab8da64e0805e14a8e0bcf90503f8a9b55b002 */

UINT32 BspGetUwbSocketId(VOID)
{
    return g_uwbSocketId;
}

/* Started by AICoder, pid:kae37o21873787b1492d09e4b0ed150f62351d01 */
/**************************************************************************
 * 函数名称: BspSetBbuMsgToUwbSw
 * 功能描述: 控制下行BBU到uwb数据转发线程开关
 * 输入参数: UINT8 flag  0：关闭；1：打开
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSetBbuMsgToUwbSw(UINT8 flag)
{
    bbuMsgToUwbSw = flag;
    return BSP_OK;
}
/* Ended by AICoder, pid:kae37o21873787b1492d09e4b0ed150f62351d01 */

/* Started by AICoder, pid:8ae37n2187z787b1492d09e4b0ed150f62341d01 */
UINT32 BspGetBbuMsgToUwbSw(VOID)
{
    return bbuMsgToUwbSw;
}
/* Ended by AICoder, pid:8ae37n2187z787b1492d09e4b0ed150f62341d01 */

/* Started by AICoder, pid:qae37w2187w787b1492d09e4b0ed150f62351d01 */
/**************************************************************************
 * 函数名称: BspSetUwbMsgToBbuSw
 * 功能描述: 控制上行行uwb到BBU数据转发线程开关
 * 输入参数: UINT8 flag  0：关闭；1：打开
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSetUwbMsgToBbuSw(UINT8 flag)
{
    uwbMsgToBbuSw = flag;
    return BSP_OK;
}
/* Ended by AICoder, pid:qae37w2187w787b1492d09e4b0ed150f62351d01 */

/* Started by AICoder, pid:uae37y21876787b1492d09e4b0ed150f62341d01 */
UINT32 BspGetUwbMsgToBbuSw(VOID)
{
    return uwbMsgToBbuSw;
}
/* Ended by AICoder, pid:uae37y21876787b1492d09e4b0ed150f62341d01 */

/* Started by AICoder, pid:dcf6fv0f574a32c141d00809b0d1bb28d501a855 */
/**************************************************************************
 * 函数名称: BspGetIpStartLoop
 * 功能描述: 获取IP起始位置
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspGetIpStartLoop( char * buf,char * buf1,UINT32 *loopStar)
{
    UINT32 loop =0;

    if (NULL == buf || NULL == buf1 || NULL == loopStar)
    {
        dbgInfo ("[%s]:Invalid argument\n", __FUNCTION__);
        return BSP_ERROR;
    }

	for(loop =0;loop<22;loop++)
    {
        if( (*(buf1+loop)) >= '0' && (*(buf1+loop)) <= '9')
        {
            *loopStar = loop;
            return BSP_OK;
        }
    }
    dbgInfo ("[%s]:No digit found in the string\n", __FUNCTION__);
    return BSP_ERROR;
}
/* Ended by AICoder, pid:dcf6fv0f574a32c141d00809b0d1bb28d501a855 */

/* Started by AICoder, pid:2ea99x2eab33b26140aa0a8d304dd23c4ce54174 */
/**************************************************************************
 * 函数名称: BspGetIpEndLoop
 * 功能描述: 获取IP结束位置
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspGetIpEndLoop( char * buf,char * buf1,UINT32 *loopEnd)
{
    UINT32 loop =0;
    UINT32 count =0;

    if (NULL == buf || NULL == buf1 || NULL == loopEnd)
    {
        dbgInfo ("[%s]:Invalid argument\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for(loop =0;loop<22;loop++)
    {
       if(count == 3)
       {
           if(!(*(buf1+loop) >= '0' && *(buf1+loop) <= '9'))
	       {
	           if(loop > 0)
		       {
	               *loopEnd = loop -1;
		       }
		    //    else
		    //    {
		    //         *loopEnd = 0;
		    //    }
	           break;
	       }
	    }

        if( *(buf1+loop)  == '.')
        {
	        count ++;
        }
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:2ea99x2eab33b26140aa0a8d304dd23c4ce54174 */

/* Started by AICoder, pid:2f34629067kf2a91459408871054c13c19177ae1 */
/**************************************************************************
 * 函数名称:BspReadFile
 * 功能描述: 从文件读取内容到log
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年11月10日                  王睿   创建
 **************************************************************************/
UINT32 BspReadFile(const CHAR *ucFileName,char * buf,size_t bufSize)
{
    FILE *file = NULL;
    INT32 readLen = 0;
    INT32 lSnpRet = 0;
    CHAR *const dirlist[1] = {"/ata"};
    rsize_t dirlist_size = 1;

    if (NULL == ucFileName || NULL == buf)
    {
        dbgInfo ("[%s]:Invalid argument\n", __FUNCTION__);
        return BSP_ERROR;
    }

    INT32 ulRet = zte_fopen_s(&file, ucFileName, "r", dirlist, dirlist_size);
    if (0 != ulRet)
    {
        dbgInfo ("[%s]:file open %s fail %s\n", __FUNCTION__, ucFileName, zte_strerror_s (errno));
        return BSP_ERROR;
    }

    readLen = fread(buf, 1, bufSize - 1, file);
    dbgInfoEx("readLen %d bufSize-1 %lu buf %s\n", readLen,bufSize - 1,buf);
    
    if (readLen <= 0)
    {
        lSnpRet = fclose(file);
        FCLOSE_CHECK(lSnpRet);
        /*fread如果不成功或读到文件末尾返回 0*/
        dbgInfo ("[%s]:file read fail %s\n", __FUNCTION__, zte_strerror_s (errno));
        return BSP_ERROR;
    }
    lSnpRet = fclose (file);
    FCLOSE_CHECK(lSnpRet);
    buf[readLen-1] = '\0';

    return BSP_OK;
}
/* Ended by AICoder, pid:2f34629067kf2a91459408871054c13c19177ae1 */

/* Started by AICoder, pid:8b38fmd447fa5d51485e0ac9309d85491e31842b */
/**************************************************************************
 * 函数名称:BspReadServerIpFromFile
 * 功能描述: 从文件中读服务端IP地址
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspReadServerIpFromFile (const CHAR *ucFileName)
{
    char buf[1400] = {0};
    char buf1[7] = {"server"};
	char * retbuf1;
	UINT32 ret;
	UINT32 loopStar =0;
	UINT32 loopEnd =0;

    /*从udhcpc.log离线文件读文件内容*/
    if (BSP_ERROR == BspReadFile(ucFileName, buf, sizeof(buf))) 
    {
        dbgInfoEx("Failed to read file %s \n", ucFileName);
        return BSP_ERROR;
    }

    buf[1399] = '\0';
    retbuf1 = strstr((const char *)buf,(const char *)buf1);//找到buf中第一次出现buf1的位置
    
    if (retbuf1 == NULL) {
        dbgInfoEx("String %s not found in file %s \n", buf1,ucFileName);
        return BSP_ERROR;
    }

    dbgInfoEx("buf=%s \nretbuf1=%s \n", buf,retbuf1);
    
    /*获取IP起始位置*/
    ret = BspGetIpStartLoop(buf,retbuf1,&loopStar);
 	/*获取IP结束位置*/
    ret |=  BspGetIpEndLoop(buf,retbuf1,&loopEnd);

    dbgInfoEx("loopStar %d loopEnd %d \n", loopStar, loopEnd);

    if (loopStar > loopEnd || loopEnd >= sizeof(g_serverIp)) 
    {
        dbgInfoEx("Invalid loop indices: %u to %u \n", loopStar, loopEnd);
        return BSP_ERROR;
    }

    strncpy_s(g_serverIp, sizeof(g_serverIp), &retbuf1[loopStar], (loopEnd - loopStar + 1));
    dbgInfo("serverIp = %s loopStar = %d loopEnd = %d len = %d\n",g_serverIp,loopStar,loopEnd,(loopEnd - loopStar + 1));

    return ret;
}
/* Ended by AICoder, pid:8b38fmd447fa5d51485e0ac9309d85491e31842b */

/**************************************************************************
 * 函数名称:BspGetDhcpServerIp
 * 功能描述: 获取服务端IP地址，udp模块初始化需要
 * 输入参数:
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
char *BspGetDhcpServerIp(VOID)
{
    return &g_serverIp[0];
}

/* 打印服务端IP维测 */
UINT32 printserverip(VOID)
{
    UINT32 ret = BSP_OK;
	dbgInfo("serverIp = %s \n",g_serverIp);
    return ret;
}

/* Started by AICoder, pid:y29d77271e51fde14a81099200ad3706b495631c */
/**************************************************************************
 * 函数名称: BspGetDhcpServerIp
 * 功能描述: 获取Dhcp服务端IP代码
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspDhcpServerIpInit(VOID)
{
    char           cmd[100];
    BspSystem("rm /ata/rru/udhcpc.log");
    BspSystem("pkill -f 'udhcpc -i eth3'");
    // BspSystem("udhcpc -i eth3");
    //0（标准输入），1（标准输出），2（标准错误）。当使用2>&1时，意味着将标准错误（文件描述符2）重定向到标准输出（文件描述符1）。无论是正常的输出信息还是错误信息，
    (void)snprintf_s (cmd, sizeof (cmd), "timeout 10 udhcpc -i eth3 >>%s 2>&1",DHCP_UDHCPC_LOG);
    dbgInfoEx("cmd is: %s\n", &cmd[0]);
    dbgInfoEx("cmd shuzu size is: %lu,cmd zifu size is: %d\n", sizeof (cmd), zte_strnlen_s((const char*)cmd,sizeof(cmd)));

    if (BspSystem((const CHAR*)cmd) == -1)
    {
        dbgInfo("Failed to execute command: %s\n", cmd);
        return BSP_ERROR;
    }

    if (BSP_ERROR == BspReadServerIpFromFile(DHCP_UDHCPC_LOG))
    {
        dbgInfo("Failed to read file %s \n", DHCP_UDHCPC_LOG);
        return BSP_ERROR;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:y29d77271e51fde14a81099200ad3706b495631c */ 

/* Started by AICoder, pid:63719la600v076e14e0e08cfd073584a6f026196 */
/**************************************************************************
 * 函数名称： BspUwbSocketInit
 * 功能描述： uwb的Socket配置初始化
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspUwbSocketInit(VOID)//参考UdpMsgModuleInit
{
	UINT32 retVal = BSP_OK;
    T_UdpSocket udpSocket = {0,};
    UINT32 uwbIdserver = 20;//uwbid先写死
    UINT32 uwbIdcli = 20;//uwbid先写死
    char * serverIp = NULL;

    serverIp = BspGetDhcpServerIp();

    if (NULL == serverIp)
    {
        dbgInfo("%s: Failed to get DHCP server IP\n", __FUNCTION__);
        return BSP_ERROR;
    }

    /* 初始化uwbudpSocket信息*/
    udpSocket.id       = uwbIdcli;
    udpSocket.listenId = uwbIdserver;//待确认
    udpSocket.port     = 33338; //端口号固定，待确认
    // (void)snprintf_s((char *)udpSocket.ip,sizeof(udpSocket.ip),"%s","197.33.33.100");//uwb服务器IP通过DHCP服务器自动分配，BspGetDhcpServerIp 197,33,33,4
    (void)snprintf_s((char *)udpSocket.ip,sizeof(udpSocket.ip),"%s",BspGetDhcpServerIp());//uwb服务器IP通过DHCP服务器自动分配，BspGetDhcpServerIp

    dbgInfo("udpSocket.id = %d udpSocket.listenId = %d udpSocket.port = %d udpSocket.ip = %s \n",udpSocket.id,udpSocket.listenId,udpSocket.port,(char *)udpSocket.ip);
    BspLog(LOG_LEVEL_0,"%s@%d >> udpSocket.id = %d udpSocket.listenId = %d udpSocket.port = %d udpSocket.ip = %s \n", __FUNCTION__,__LINE__,udpSocket.id,udpSocket.listenId,udpSocket.port,(char *)udpSocket.ip);

    retVal = BspUdpSocketInit(&udpSocket);//初始化udpSocket信息

    g_uwbSocketId = udpSocket.id;

    return retVal;
}
/* Ended by AICoder, pid:63719la600v076e14e0e08cfd073584a6f026196 */

/**************************************************************************
 * 函数名称: BspCalculateNumChunks
 * 功能描述: 计算传输数据包的数量
 * 输入参数: dataLen：数据包总大小
 *          chunkSize：单个数据包大小
 * 输出参数: 数据包的数量
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
/* Started by AICoder, pid:m73be40c4dad1be142ae08bcc0a66e133880a40a */
UINT32 BspCalculateNumChunks(UINT32 dataLen, UINT32 chunkSize) 
{
    if(0 == chunkSize)
    {
        // 如果chunkSize为0，返回一个错误代码或抛出异常，因为除以零是未定义的
        return BSP_ERROR;
    }
    return (dataLen + chunkSize - 1) / chunkSize;
}
/* Ended by AICoder, pid:m73be40c4dad1be142ae08bcc0a66e133880a40a */

/**************************************************************************
 * 函数名称: BspSendPkgInChunks
 * 功能描述: 将数据包拆分发送给uwb
 * 输入参数: dataLen：数据包总大小
 *          chunkSize：单个数据包大小
 * 输出参数: 数据包的数量
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
/* Started by AICoder, pid:y6b6apeab35c1041462b0905d045476204042807 */
UINT32 BspSendPkgInChunks(UINT8 *bufCovTemp, UINT32 dataLen) 
{
    UINT32 sentTotal = 0; // 已发送的总字节数
    UINT32 retryCount = 0;
    UINT32 retryCountMax = 3;// 最大重试次数
    UINT32 numChunks = BspCalculateNumChunks(dataLen, SEND_BUF_LEN);
    UINT32 retVal = BSP_ERROR;

    if (numChunks == BSP_ERROR) {
        dbgInfoEx("[%s] Error: Invalid chunk size.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for (UINT32 chunkIndex = 0; chunkIndex < numChunks; ++chunkIndex) 
    {
        UINT32 offset = chunkIndex * SEND_BUF_LEN;
        UINT32 chunkSize = (dataLen - offset > SEND_BUF_LEN) ? SEND_BUF_LEN : (dataLen - offset);
        char buffer[chunkSize + 1]; // 确保有空字符终止,保存每包数据的内容
        zte_memset_s(buffer,sizeof(buffer),0,sizeof(buffer));

        //接收到bbu的数据，拆包之后一个包最多发送3次，否则丢弃
        for (retryCount = 0; retryCount < retryCountMax; retryCount++)
        {
            BspSysMsDelay(bbuMsgToUwbDelay);//发送uwb数据包，延迟50ms，继续发送下一个包

            dbgInfoEx("[%s] retrying... attempt send %dth packet %d times, chunkSize is %d, offset is %d !!!\n packet is [%s]\n", __FUNCTION__, chunkIndex, retryCount + 1, chunkSize, offset, (bufCovTemp + offset));
            retVal = BspUwbSend(bufCovTemp + offset, chunkSize);

            memcpy_s(buffer, chunkSize, bufCovTemp + offset, chunkSize);
            buffer[chunkSize] = '\0'; // 确保字符串终止

            if ( BSP_ERROR !=  retVal)
            {
                retVal = BSP_OK;
                break;  // 如果有一次发送成功，退出循环，重新获取下一包数据
            }
            dbgInfoEx("[%s] send bbu Message to uwb failed!! errno = %d - %s\n", __FUNCTION__, errno, zte_strerror_s(errno));

        }
        if(BSP_OK == retVal)
        {
            sentTotal += chunkSize;
            dbgInfoEx("[%s] send bbu Message is:\n[%s] to uwb success!!\n", __FUNCTION__, buffer);
        } else
        {
            dbgInfoEx("[%s] send bbu Message is:\n[%s] to uwb failed!! \n", __FUNCTION__, buffer);
        }
    }

    if (sentTotal == dataLen) 
    {
        dbgInfoEx("[%s] All data sent successfully.\n", __FUNCTION__);
        return BSP_OK;
    } else if(0 == sentTotal)
    {
        dbgInfoEx("[%s] Warning: Only %d out of %d bytes were sent.\n", __FUNCTION__, sentTotal, dataLen);
        return BSP_ERROR;
    } else
    {
        dbgInfoEx("[%s] Warning: Only %d out of %d bytes were sent.\n", __FUNCTION__, sentTotal, dataLen);
        return BSP_OK;
    }
}
/* Ended by AICoder, pid:y6b6apeab35c1041462b0905d045476204042807 */

/* Started by AICoder, pid:6fc36f7361s68ab14a9f0b49a023d50353083e56 */
UINT32 toUwbTest = 0;

UINT32 BspToUwbTest(UINT32 sw)
{
    toUwbTest = sw;
    dbgInfo("[%s] toUwbTest is %d\n",__FUNCTION__,toUwbTest);
    return BSP_OK;
}
/* Ended by AICoder, pid:6fc36f7361s68ab14a9f0b49a023d50353083e56 */

/* Started by AICoder, pid:l8b20u4151a0fdf1421e09a110edb305043523a8 */
/**************************************************************************
 * 函数名称： _BspRecvBbuMsgToUwbProcess
 * 功能描述： 循环接收BBU发送到eth3口的数据，发送给uwb
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
static void * _BspRecvBbuMsgToUwbProcess(VOID *para)
{
    
    UINT8  *buf;
    UINT8  *bufCovTemp;
    INT32  recvLen = 0;
    UINT32 retVal = BSP_OK;
    UINT32 uwbSocketId = 0xff;

    UINT8  uwbSendTemp[11] = "AT+CGMR?";//测试发送uwb版本获取

    buf = malloc(RECV_BUF_LEN);  /*max receive buf*/
    if (buf == NULL)
    {
        return NULL;
    }

    while(1)
    {
        /* Started by AICoder, pid:u982b0059ax852a146940a9a80b3c00cd6f6c4f3 */
        if(0 == bbuMsgToUwbSw)
        {
            BspSysMsDelay(bbuMsgToUwbDelay);
            dbgInfoEx("[%s] recv bbu Message swith off!!!!\n",__FUNCTION__);
            continue;
        }
        /* Ended by AICoder, pid:u982b0059ax852a146940a9a80b3c00cd6f6c4f3 */
        /* Started by AICoder, pid:8e88bwbb9e2e864144f708eb4071dd3a4e6586e9 */
        /*启动dhcp 放到线程里*/
        if(0 == dhcpFlag)
        {
            retVal = BspDhcpServerIpInit();
            if (retVal != BSP_OK)
            {
                dhcpFlag = 0;
                dbgInfoEx("[%s]Failed to dhcp serverIp init!!!\n",__FUNCTION__);
                BspSysMsDelay(10000);//10s请求一次dhcp服务器
                continue;
            }
            dhcpFlag++;
            dbgInfo("[%s]Success to dhcp serverIp init!!!\n",__FUNCTION__);
        }

        /*只初始化socket一次*/
        if(0 == socketCnt)
        {
            BspSysMsDelay(30);
            retVal = BspUwbSocketInit();
            if(BSP_OK == retVal)
            {
                socketCnt++;
                dbgInfoEx("[%s]@[%d] Success to UwbSocket init!!! retVal=%d socketCnt=%d\n", __FUNCTION__,__LINE__,retVal,socketCnt);
                BspLog(LOG_LEVEL_0,"[%s]@[%d] Success to UwbSocket init!!! retVal=%d socketCnt=%d\n", __FUNCTION__,__LINE__,retVal,socketCnt);
            }else
            {
                socketCnt = 0;
                dbgInfoEx("[%s]@[%d] Failed to UwbSocket init!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
                BspLog(LOG_LEVEL_0,"[%s]@[%d] Failed to UwbSocket init!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
                BspSysMsDelay(10000);
                continue;
            }
        }
        /* Ended by AICoder, pid:8e88bwbb9e2e864144f708eb4071dd3a4e6586e9 */

        uwbSocketId = BspGetUwbSocketId();
        dbgInfoEx("[%s] listenMgrId %d \n", __FUNCTION__,uwbSocketId);
        /* Started by AICoder, pid:7496fue9f2dd27014cf80a1f20ee0e0377769b3f */
        if(uwbSocketId == 0xff)
        {
            BspSysMsDelay(bbuMsgToUwbDelay);
            dbgInfoEx("[%s] Socket init failed!!!!\n",__FUNCTION__);
            continue;
        }
        /* Ended by AICoder, pid:7496fue9f2dd27014cf80a1f20ee0e0377769b3f */

        bufCovTemp = buf;
        memset_s(bufCovTemp, RECV_BUF_LEN, 0, RECV_BUF_LEN);/*接收数据之前，将缓存内容清0，防止有没用的数据*/

        dbgInfoEx("[%s] start rev bbu Message!\n",__FUNCTION__);
        BspSysMsDelay(bbuMsgToUwbDelay);

        // /* 接收bbu消息接口 */
        recvLen = (INT32)BspUdpSocketRecv(uwbSocketId,bufCovTemp,RECV_BUF_LEN);
        /* 获取到消息数据之后 */
        if (recvLen <= 0)
        {
            dbgInfoEx("[%s] recv bbu Message erro ror recv return Error!\n",__FUNCTION__);
            dbgInfoEx("[%s] failed!! errno = %d -%s\n",__FUNCTION__,errno, zte_strerror_s(errno));
            continue;
        }
        if (recvLen >RECV_BUF_LEN)
        {
            recvLen = RECV_BUF_LEN;
            dbgInfoEx("[%s]@[%d] recv bbu byte > %d recvLen=%d\n", __FUNCTION__,__LINE__,RECV_BUF_LEN,recvLen);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] recv bbu byte > %d recvLen=%d\n", __FUNCTION__,__LINE__,RECV_BUF_LEN,recvLen);
        }
        dbgInfoEx("[%s] recv bbu Message success!\nbufCovTemp = %s;RecvLen= %d\n",__FUNCTION__,bufCovTemp,recvLen);

        /* Started by AICoder, pid:f5431c260cn2329142510b8b108b46297d80407e */
        if(1 == toUwbTest)//测试发送uwb版本获取开关
        {
            retVal = BspSendPkgInChunks(uwbSendTemp,sizeof(uwbSendTemp));
            if(BSP_ERROR == retVal)
            {
               dbgInfoEx("[%s] UwbSend Message [%s] failed!!\n",__FUNCTION__,uwbSendTemp);
               continue;
            }
            dbgInfoEx("[%s] UwbSend Message [%s] success!!\n",__FUNCTION__,uwbSendTemp);

        }else
        {
            /* 将接收bbu的数据拆包发送给uwb */
            retVal = BspSendPkgInChunks(bufCovTemp, recvLen);
            if (BSP_ERROR == retVal)
            {
                dbgInfoEx("[%s] send bbu Message to uwb failed!! \n", __FUNCTION__);
                continue;
            }
        }
        /* Ended by AICoder, pid:f5431c260cn2329142510b8b108b46297d80407e */

    }

    return NULL;
}
/* Ended by AICoder, pid:l8b20u4151a0fdf1421e09a110edb305043523a8 */

/**************************************************************************
 * 函数名称： _BspRecvBbuMsgToUwbThreadInit
 * 功能描述： 接收BBU消息发送uwb模块线程
 * 输入参数： ulOpt:光口号
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 _BspRecvBbuMsgToUwbThreadInit(VOID)
{    
	pthread_t th_id = 0;
	UINT32     ulRet = BSP_OK;

	ulRet = pthread_create(&th_id, NULL, _BspRecvBbuMsgToUwbProcess, NULL);

	if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
    }
    else
    {
        dbgErr("create thread<%s> success!\n",__FUNCTION__);
    }
	return ulRet;
    
}

/* Started by AICoder, pid:0d084t819d5c7dc14f320bc830cacb01fa315d1b */
/**************************************************************************
 * 函数名称： _BspRecvUwbMsgToBbuProcess
 * 功能描述： 循环接收uwb串口的数据，通过eth3口发送给BBU
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
static void * _BspRecvUwbMsgToBbuProcess(VOID *para)
{
    
    // UINT8  uwbRecvtemp[SEND_BUF_LEN] = "uwb send success!!";
    UINT8  uwbRecvtemp[SEND_BUF_LEN] = {0};
    UINT8  *buf;
    UINT32 retVal;
    INT32  recvLen = 0;
    UINT32 uwbSocketId = 0xff;
    UINT32 retryCount = 0;
    UINT32 retryCountMax = 3;// 最大重试次数

    //删除udp OUTPUT丢弃数据包的防火墙规则
    BspSystem("iptables -D OUTPUT 1");
    //添加udp OUTPUT接收数据包的防火墙规则
    BspSystem("iptables -A OUTPUT -o eth0 -p udp -m udp -j ACCEPT");

    buf = malloc(SEND_BUF_LEN);  /*max receive buf*/
    if (buf == NULL)
    {
        return NULL;
    }

    while(1)
    {
        uwbSocketId = BspGetUwbSocketId();
        dbgInfoEx("[%s] listenMgrId %d \n", __FUNCTION__,uwbSocketId);

        //cw告警先注释掉
        if(0 == uwbMsgToBbuSw || uwbSocketId == 0xff)
        {
            BspSysMsDelay(uwbMsgToBbuDelay);
            dbgInfoEx("[%s] recv uwb Message swith off or Socket init failed!!!!\n",__FUNCTION__);
            continue; 
        }

        BspSysMsDelay(uwbMsgToBbuDelay);

        zte_memset_s(uwbRecvtemp,SEND_BUF_LEN,0,SEND_BUF_LEN);

        recvLen = BspUwbRecv(uwbRecvtemp,sizeof(uwbRecvtemp));//接收uwb模块的数据，200个字节

        if (recvLen <= 0)
        {
            dbgInfoEx("[%s] recv NONE or recv return Error!\n",__FUNCTION__);
            continue;
        }

        if (recvLen > SEND_BUF_LEN)
        {
            recvLen = SEND_BUF_LEN;
            dbgInfoEx("[%s]@[%d] recv uwb byte > %d recvLen=%d\n", __FUNCTION__,__LINE__,SEND_BUF_LEN,recvLen);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] recv uwb byte > %d recvLen=%d\n", __FUNCTION__,__LINE__,SEND_BUF_LEN,recvLen);
        }

        memcpy_s(buf,SEND_BUF_LEN,uwbRecvtemp,SEND_BUF_LEN);

        dbgInfoEx("[%s] recv uwb Message is:\n%s\n",__FUNCTION__,uwbRecvtemp);

        /* Started by AICoder, pid:k6ffb6163effc2d14537081a30231418fd398635 */
        //接收到uwb的数据，通过原始套接字最多发送3次，否则丢弃
        for (retryCount = 0; retryCount < retryCountMax; retryCount++)
        {
            dbgInfoEx("[%s] retrying... attempt %d....send char num: %d\n", __FUNCTION__, retryCount + 1, recvLen);
            retVal = BspUdpSocketSend(uwbSocketId, buf, recvLen);
            if (BSP_OK== retVal ) 
            {
                dbgInfoEx("[%s] send uwb Message is:\n[%s] to bbu success!!\n", __FUNCTION__, buf);
                break;  // 如果有一次发送成功，退出循环，重新获取下一包数据
            }
            dbgInfoEx("[%s] send uwb Message is:\n[%s] to bbu failed!! errno = %d - %s\n", __FUNCTION__, buf, errno, zte_strerror_s(errno));
        }
        
        if (BSP_ERROR == retVal)
        {
            //发送3次都失败，丢弃该包数据，重新获取下一包数据
            dbgInfoEx("[%s] send uwb Message to bbu %d times failed!! \n", __FUNCTION__,retryCount);
            continue;
        }
        /* Ended by AICoder, pid:k6ffb6163effc2d14537081a30231418fd398635 */

    }

    return NULL;
}
/* Ended by AICoder, pid:0d084t819d5c7dc14f320bc830cacb01fa315d1b */

/**************************************************************************
 * 函数名称： _BspRecvUwbMsgToBbuThreadInit
 * 功能描述： 接收uwb模块消息发送BBU线程
 * 输入参数： ulOpt:光口号
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 _BspRecvUwbMsgToBbuThreadInit(VOID)
{    
	pthread_t th_id = 0;
	UINT32     ulRet = BSP_OK;

	ulRet = pthread_create(&th_id, NULL, _BspRecvUwbMsgToBbuProcess, NULL);
	// ulRet = pthread_create(&th_id, NULL, (VOID *)testsendProcess, (VOID *)listenMgrId);


	if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
    }
    else
    {
        dbgErr("create thread<%s> success!\n",__FUNCTION__);
    }
	return ulRet;
    
}

//测试接口创建虚拟网卡eth0_dhcp
UINT32 dhcp(VOID)
{
    UINT32 ret = BSP_OK;
    BspSystem("./ip link add link eth0 name eth0_dhcp type macvlan");
    BspSystem("ifconfig eth0_dhcp hw ether 40:00:C7:21:21:64");
    BspSystem("ifconfig eth0_dhcp 199.33.33.38 netmask 255.255.255.0");
    BspSystem("ifconfig eth0_dhcp mtu 1492");
    BspSystem("ifconfig eth0_dhcp up");
    BspSystem("ifconfig");

    return ret;
}

/* Started by AICoder, pid:dc1f1c83de9fe6e148e80ae3200d2328ca95865e */
/**************************************************************************
 * 函数名称： BspStartUwbMac
 * 功能描述： 向uwb发送mac地址查询的指令
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 BspStartUwbMac(VOID)
{
    UINT8  temp[8] = "AT+MAC?";
    UINT32 loop;
    UINT8  uwbSendTemp[7] = {0};
    UINT32 cnt = sizeof(uwbSendTemp);
    UINT32 retVal = BSP_OK;

    for(loop = 0;loop < cnt;loop++)
    {
    	uwbSendTemp[loop] = temp[loop];
    }
    dbgInfoEx("[%s] temp is:%s uwbSendTemp is:%s cnt:%lu\n",__FUNCTION__,temp,uwbSendTemp,sizeof(uwbSendTemp));

    retVal = BspUwbSend(uwbSendTemp,cnt);
    if(BSP_ERROR == retVal)
    {
       dbgInfo("[%s] UwbSend Message [%s] failed!!\n",__FUNCTION__,uwbSendTemp);
       return retVal;
    }
    return retVal;
}
/* Ended by AICoder, pid:dc1f1c83de9fe6e148e80ae3200d2328ca95865e */

/* Started by AICoder, pid:ic9bd892c0jba551468808886046a93055254043 */
/**************************************************************************
 * 函数名称： BspCheckMacHeadAnalyze
 * 功能描述： 分析接收到的macBuf数据包里是否包含macHeader "+MAC:
 * 输入参数： macBuf:mac字符指针
 *          ucStartDate:
 *          macHeader:mac头
 *          macHeaderLength:mac头起始索引
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 BspCheckMacHeadAnalysis(UINT8 *macBuf,UINT8 *ucStartDate,const UINT8 *macHeader, UINT32 *macHeaderLength) 
{

    UINT32 macHeaderLen = 0;
    UINT32 macBufLen = 0;
    UINT8 *macHeaderStart = NULL;
    UINT32 copySize = 0;

    INPUT_POINTER_CHECK(macBuf);
    INPUT_POINTER_CHECK(ucStartDate);
    INPUT_POINTER_CHECK(macHeader);
    INPUT_POINTER_CHECK(macHeaderLength);

    macHeaderLen = zte_strnlen_s((const char *)macHeader,1200);
    macBufLen = zte_strnlen_s((char *)macBuf,1200);

    dbgInfoEx("[%s] macHeader = %s\n macHeaderLen = %d macBufLen = %d\n",__FUNCTION__,macHeader,macHeaderLen,macBufLen);

    if (macBufLen < macHeaderLen) {
        dbgInfoEx("[%s] macBuf length is less than \"%s\"\n", __FUNCTION__ , macHeader);
        return BSP_ERROR;
    }

    // 查找macHeader在macBuf中的位置
    macHeaderStart = (UINT8 *)strstr((const char *)macBuf, (const char *)macHeader);

    if (macHeaderStart == NULL) {
        dbgInfoEx("[%s] %s not found in macBuf \n", __FUNCTION__, macHeader);
        return BSP_ERROR;
    }

    // 计算从macHeader开始到macBuf结束的字符数
    copySize = macBufLen - (macHeaderStart - macBuf) + 1; // +1是用于预留空字符终止符
    dbgInfoEx("[%s]  macHeaderStart = %s\n copySize = %d\n",__FUNCTION__,macHeaderStart,copySize);

    // 检查mac包内容不完整情况
    if(copySize < (macHeaderLen + (MAC_ADDR_LEN * 2)))
    {
        dbgInfoEx("[%s] mac address char num < %d!!!\n", __FUNCTION__ ,(MAC_ADDR_LEN * 2));
        return BSP_ERROR;
    }

    // 检查复制的大小是否超过了缓冲区大小
    if (copySize > 1200) {
        dbgInfoEx("[%s] exceeds the buffer size!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    // 将找到的MAC地址复制到ucStartDate
    memcpy_s(ucStartDate, copySize, macHeaderStart, copySize);
    dbgInfoEx("[%s] ucStartDate=%s \n",__FUNCTION__, ucStartDate);

    *macHeaderLength = (macHeaderStart - macBuf);
    dbgInfoEx("[%s] macHeaderLength=%u macHeaderStart=%ld\n",__FUNCTION__, *macHeaderLength,(macHeaderStart - macBuf));

    return BSP_OK;
}
/* Ended by AICoder, pid:ic9bd892c0jba551468808886046a93055254043 */

/* Started by AICoder, pid:sfcff2333cy1c2d142d20ae13038535dc7784985 */
/**************************************************************************
 * 函数名称： BspGetUwbMacInit
 * 功能描述： 获取uwb的mac地址
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 * 2015/01/19    V1.1     yaoxiaoan        创建
 **************************************************************************/
UINT32 BspGetUwbMacInit(UINT8 *macAddr)
{
	UINT8 macBuf[1200] = {'0'};
    INT32 recvLen = 0;
    UINT8 macBufTemp[13];/*截取uwb返回数据包mac字符数组*/
    UINT8  macHeader[6] = "+MAC:";/*mac地址数据包头*/
    UINT8  ucStartDate[1200] = {0};/*mac地址数据包头*/
    UINT32 uiDataHeaderLength = 0;/*去除串包的冗余数据及数据头长*/
    UINT32 PkgIndexStart = 0;/*包序号的起始下标*/
    UINT32 PkgIndexEnd = 0;/*包序号的结束下标*/
    UINT32 scanned = 0;
    UINT32 revIndex = 0;
    UINT32 revCntMax = 3;/*接收uwb数据包最大次数，接收一次的包可能不包含mac头信息*/
	UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(macAddr);

    //发起uwbmac查询的命令
    retVal = BspStartUwbMac();

    if(BSP_ERROR == retVal)
    {
        dbgInfo("[%s] send Uwb Mac failed!!\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"[%s]@[%d] send Uwb Mac failed!!\n", __FUNCTION__,__LINE__);
        return retVal;
    }

    for(revIndex =0;revIndex < revCntMax;revIndex++)
    {
        memset_s(&macBuf, sizeof(macBuf), 0, sizeof(macBuf));/*接收数据之前，将缓存内容清0，防止有没用的数据*/

        recvLen = BspUwbRecv(macBuf,sizeof(macBuf));
        macBuf[sizeof(macBuf) - 1] = '\0';/*字符数组最后一个用于存放空字符终止符*/
        if (recvLen <= 0 ||recvLen > 1200)
        {
            dbgInfo("[%s] recv NONE or recv return Error!\n",__FUNCTION__);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] recv NONE or recv return Error!\n", __FUNCTION__,__LINE__);
            return BSP_ERROR;
        }
    
        dbgInfoEx("[%s] <%d> BspUwbRecv macBuf = %s\n",__FUNCTION__,revIndex,macBuf);
    
        //检查接收uwb包是否包含"+MAC:"信息
        retVal = BspCheckMacHeadAnalysis(macBuf,&ucStartDate[0],&macHeader[0],&uiDataHeaderLength);
        if(BSP_OK == retVal)
        {
            // ucStartDate[1999] = '\0';//字符数组最后一个用于存放空字符终止符
            break;
           
        }
        if(BSP_ERROR == retVal && revIndex >= (revCntMax - 1))
        {
            dbgInfo("[%s] recv data no MacHead %s!!\n",__FUNCTION__,macHeader);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] recv data no MacHead %s!!\n", __FUNCTION__,__LINE__,macHeader);
            return retVal;
        }

    }

    dbgInfoEx("[%s] get uwb ucStartDate mac is:%s\n",__FUNCTION__,ucStartDate);

    //+MAC:64C8D6700002
    dbgInfoEx("[%s] get uwb macBuf is:%s\n",__FUNCTION__,macBuf);

    /* 计算包序号的起始下标和结束下标*/
    PkgIndexStart = uiDataHeaderLength + zte_strnlen_s((char *)&macHeader[0],sizeof(macHeader));
    PkgIndexEnd = PkgIndexStart + (MAC_ADDR_LEN * 2) - 1;

    if (PkgIndexEnd > sizeof(macBuf))
    {
        dbgInfo("PkgIndexEnd out of macBuf range\n");
        BspLog(LOG_LEVEL_0,"[%s]@[%d] PkgIndexEnd out of macBuf range!!\n", __FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    dbgInfoEx("PkgIndexStart=%d PkgIndexEnd=%d macHeaderlen:%d\n", PkgIndexStart,PkgIndexEnd,zte_strnlen_s((char *)&macHeader[0],sizeof(macHeader)));

    memcpy_s(&macBufTemp,sizeof(macBufTemp),&macBuf[PkgIndexStart],(MAC_ADDR_LEN * 2));
    macBufTemp[12] = '\0';
    dbgInfoEx("macBufTemp=%s \n", macBufTemp);

    /*将字符串转换成mac数组 str2mac*/
    scanned = zte_sscanf_s((const char *)macBufTemp,"%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx",NULL,&macAddr[0],&macAddr[1],&macAddr[2],&macAddr[3],&macAddr[4],&macAddr[5]);

    if (scanned != 6)
    {
        dbgErr("Failed to parse MAC address.\n");
        BspLog(LOG_LEVEL_0,"[%s]@[%d] Failed to parse MAC address.\n", __FUNCTION__,__LINE__);
        return BSP_ERROR;
    }

    BspLog(LOG_LEVEL_0,"uwbmac is: %02x:%02x:%02x:%02x:%02x:%02x\n", macAddr[0],macAddr[1],macAddr[2],macAddr[3],macAddr[4],macAddr[5]);

    return BSP_OK;
}
/* Ended by AICoder, pid:sfcff2333cy1c2d142d20ae13038535dc7784985 */

/* Started by AICoder, pid:qb2dayfdbdw199c148f20a9db055912ac6e28a0d */
/**************************************************************************
 * 函数名称： BspCheckUwbMac
 * 功能描述： 检查g_uwbMac全局变量地址是否全为0
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspCheckUwbMac(VOID)
{

    for (UINT32 index = 0; index < MAC_ADDR_LEN; index++)
    {
        if (g_uwbMac[index] != 0)
        {
            return BSP_OK; // 只要有一个元素不为0，就返回BSP_OK
        }
    }
    return BSP_ERROR; // 所有元素都为0，返回BSP_ERROR
}
/* Ended by AICoder, pid:qb2dayfdbdw199c148f20a9db055912ac6e28a0d */

/* Started by AICoder, pid:6f8cf90979m556b145fc0a5b40c5c32ce9069e60 */
/**************************************************************************
 * 函数名称： BspGetUwbMac
 * 功能描述： 获取uwb的mac地址上报给app
 * 输入参数： pUwbMac:mac字符指针
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspGetUwbMac(UINT8 *pUwbMac)
{
	UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pUwbMac);
    /* Started by AICoder, pid:ab4d7h6f1fb73ec1456e094570b3590af2f5bf59 */
    if(BSP_ERROR == BspCheckUwbMac())
    {
        dbgInfoEx("g_uwbMac %02x:%02x:%02x:%02x:%02x:%02x\n", g_uwbMac[0],g_uwbMac[1],g_uwbMac[2],g_uwbMac[3],g_uwbMac[4],g_uwbMac[5]);
        return BSP_ERROR;
    }
    /* Ended by AICoder, pid:ab4d7h6f1fb73ec1456e094570b3590af2f5bf59 */

    dbgInfoEx("g_uwbMac %02x:%02x:%02x:%02x:%02x:%02x\n", g_uwbMac[0],g_uwbMac[1],g_uwbMac[2],g_uwbMac[3],g_uwbMac[4],g_uwbMac[5]);
    memcpy_s(&pUwbMac[0],MAC_ADDR_LEN,&g_uwbMac[0],MAC_ADDR_LEN);
    dbgInfoEx("app :uwbmac %02x:%02x:%02x:%02x:%02x:%02x\n", pUwbMac[0],pUwbMac[1],pUwbMac[2],pUwbMac[3],pUwbMac[4],pUwbMac[5]);

    return retVal;
}
/* Ended by AICoder, pid:6f8cf90979m556b145fc0a5b40c5c32ce9069e60 */

/* Started by AICoder, pid:s985bx5357gb19b14c1c0ae960df470fcc755389 */
/*测试GetUwbMac接口*/
UINT32 printuwbmac(VOID)
{
	UINT32 retVal = BSP_OK;

    dbgInfo("uwbmac %02x:%02x:%02x:%02x:%02x:%02x\n", g_uwbMac[0],g_uwbMac[1],g_uwbMac[2],g_uwbMac[3],g_uwbMac[4],g_uwbMac[5]);

    return retVal;
}
/* Ended by AICoder, pid:s985bx5357gb19b14c1c0ae960df470fcc755389 */

/* Started by AICoder, pid:ma762g2ca2m734d149980813d0f20b5a4485bcc8 */
UINT32 BspGetUwblengthInfo(UINT32 antNum,UINT8 *distarr)
{
    UINT8  temp[200] = {0};
    UINT32 recvLen = 0;
    UINT32 loop = 0;
    UINT32 DataHeader = 0; /*数据头长*/
    UINT32 data1 = 0; /*逗号计数标志*/
    UINT32 data2 = 0; /*&计数标志*/
    UINT32 num = 0;
    UINT32 found = 0;
    recvLen = BspUwbRecv(temp,sizeof(temp));
    TEMP_INPUTCHECK(recvLen);
    for (num = 0; num < recvLen; num++)
    {
        if ((temp[num] == '=') && (found == 0))
        {
            DataHeader = num + 1;
            for (loop = DataHeader; loop < recvLen; loop++)
            {
                if(temp[loop] == ',')
                {
                    data1 ++;
                    continue;
                }
                
                if((2 == data1) && (temp[loop] == (antNum + '0'))) // 比较字符串形式的数字
                {
                    found = 1;
                }

                if(temp[loop] == '&')
                {
                    data2 ++;
                    continue;
                }

                if((1 == found) && (2 == data2)) /*1：标记  2：找到第二个逗号*/
                {
                    for(int i = 0; i < 3 && (loop + i <recvLen); i++)
                    {
                            if(temp[loop + i] != '&')
                            {
                                distarr[i]=temp[loop+i];
                            }
                            else
                            {
                                distarr[i]= '\0';
                                break;
                            }       
                    }

                    break;
                }
            }    
            data1 = 0; /* 重置计数器以便下一次迭代 */
            data2 = 0;
        }
    }
    dbgInfo("\n");
    return BSP_OK;
}
/* Ended by AICoder, pid:ma762g2ca2m734d149980813d0f20b5a4485bcc8 */

/*****************************************************************************
 *  函数名称   : BspSetUWBL2ssVlanInit()
 *  功能描述   : uwb配置光口L2ss Vlan模块 
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: BSP_OK 成功
 *            其他     失败
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUWBL2ssVlanInit(VOID)
{
    UINT32 retVal = BSP_OK;
    /* uwb配置光口L2ss Vlane模块 需在cHalApiSetUWBL2ssVlane该接口之后 */
    // IcHalApiSetUWBL2ssVlan();
    BspHalAdaptSetUWBL2ssVlan();

    return retVal;
}

/* Started by AICoder, pid:i584be5855ba62514a2b0a65f0e16e2bc492d2b4 */
/**************************************************************************
 * 函数名称： BspCfgOptNetEth3Addr
 * 功能描述： 配置eth3网卡信息
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspCfgOptNetEth3Addr(VOID)
{
    UINT32 retVal = BSP_OK;
    //40:00:C6:21:21:63 配置eth3网口的ip、mac、掩码。先配默认，后续eth3的ip通过dncp服务器分配，mac，掩码需要方案定，需与BBU约定好
    UINT8 eth3Mac[6]={0};

    //打开uwb eth3口的ioctrl开关
    INPUT_POINTER_CHECK(openUwbMacInMacSwitchFunc);
    openUwbMacInMacSwitchFunc();

    retVal |=BspGetUwbMac(&eth3Mac[0]);
    retVal |= BspNetDeviceClose((char*)"eth3");
    // system("./ip link add link eth0 name eth3 type macvlan");//在eth0网卡虚拟一个网卡3，调试用该命令
    retVal |= BspSetMac((char*)"eth3",eth3Mac);
    retVal |= BspNetDeviceOpen((char*)"eth3");

    BspSystem("ifconfig eth3 mtu 1492");  /*以太网报文最大长度为1492，默认1500会导致基带板上无法访问rru*/
    return retVal;
}
/* Ended by AICoder, pid:i584be5855ba62514a2b0a65f0e16e2bc492d2b4 */

/* Started by AICoder, pid:of25e80755h907b14e560ad74062703980d3cd3a */
/**************************************************************************
 * 函数名称： CfgOptNetEth3AddrTest
 * 功能描述： 配置eth3网卡信息测试接口
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 CfgOptNetEth3AddrTest(VOID)
{
    UINT32 retVal = BSP_OK;
    //40:00:C6:21:21:63 配置eth3网口的ip、mac、掩码。先配默认，后续eth3的ip通过dncp服务器分配，mac，掩码需要方案定，需与BBU约定好
    UINT8 eth3Mac[6]={0};
    UINT8 eth3Ip[4]={197,33,33,4};
    UINT8 eth3ulMask[4]={0xff,0xff,0xff,0x00};

    //打开uwb eth3口的ioctrl开关
    INPUT_POINTER_CHECK(openUwbMacInMacSwitchFunc);
    openUwbMacInMacSwitchFunc();

    retVal |=BspGetUwbMac(&eth3Mac[0]);
    retVal |= BspNetDeviceClose((char*)"eth3");
    // system("./ip link add link eth0 name eth3 type macvlan");//在eth0网卡虚拟一个网卡3，调试用该命令
    retVal |= BspSetMac((char*)"eth3",eth3Mac);
    retVal |= BspSetIp((char*)"eth3",eth3Ip);
    retVal |= BspSetIpMask((char*)"eth3",eth3ulMask);
    retVal |= BspNetDeviceOpen((char*)"eth3");

    BspSystem("ifconfig eth3 mtu 1492");  /*以太网报文最大长度为1492，默认1500会导致基带板上无法访问rru*/
    return retVal;
}
/* Ended by AICoder, pid:of25e80755h907b14e560ad74062703980d3cd3a */

/* Started by AICoder, pid:v1bacj3415f4bba140c408e8f098a65f05b1225b */
/**************************************************************************
 * 函数名称： BspGetUwbMacAdd
 * 功能描述： 获取UWBMAC地址getMacCntMax次，直到连续三次获取相同的MAC地址，返回BSP_OK
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 BspGetUwbMacAdd(VOID)
{
    UINT8 uwbMacOld[MAC_ADDR_LEN] = {0};
    UINT8 uwbMacNew[MAC_ADDR_LEN] = {0};
    UINT32 getMacIndex = 0;
    UINT32 getMacCntMax = 30;/*获取MAC数据包最大次数*/
    UINT32 macMatchCntMax = 3;/*MAC相同累计最大次数*/
    UINT32 count = 0;

    for (getMacIndex = 0; getMacIndex < getMacCntMax; getMacIndex++)
    {
        if (BspGetUwbMacInit(uwbMacNew) != BSP_OK)
        {
            continue; // 获取MAC失败，继续下一次尝试
        }

        // 检查当前MAC地址是否与前一次相同
        if (memcmp(uwbMacNew, uwbMacOld, MAC_ADDR_LEN) == 0)
        {
            count++;//相同计数累加
            dbgInfoEx("macMatchCount:%d >> uwbMacNew %02x:%02x:%02x:%02x:%02x:%02x\n", count,uwbMacNew[0],uwbMacNew[1],uwbMacNew[2],uwbMacNew[3],uwbMacNew[4],uwbMacNew[5]);
            BspLog(LOG_LEVEL_0,"macMatchCount:%d >> uwbMacNew %02x:%02x:%02x:%02x:%02x:%02x\n", count,uwbMacNew[0],uwbMacNew[1],uwbMacNew[2],uwbMacNew[3],uwbMacNew[4],uwbMacNew[5]);
            if (count >= macMatchCntMax)
            {
                // 连续三次获取相同的MAC地址，赋值给全局变量并返回成功
                zte_memcpy_s(g_uwbMac, MAC_ADDR_LEN, uwbMacNew, MAC_ADDR_LEN);
                return BSP_OK;
            }
        }
        else
        {
            count = 0;
        }

        // 更新uwbMacOld为当前的uwbMacNew
        zte_memcpy_s(uwbMacOld, MAC_ADDR_LEN, uwbMacNew, MAC_ADDR_LEN);
    }

    // 循环结束仍未找到稳定的MAC地址，返回错误
    return BSP_ERROR;
}
/* Ended by AICoder, pid:v1bacj3415f4bba140c408e8f098a65f05b1225b */

/* Started by AICoder, pid:wae37m2187c787b1492d09e4b0ed150f62361d01 */
/**************************************************************************
 * 函数名称: BspSetUwbSw
 * 功能描述: 提供整个uwb功能的开关接口,供app使用
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值:
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspSetUwbSw(UINT8 sw)
{
    UINT32 retVal = BSP_OK;

    dbgInfoEx("[%s]@[%d] APP setuwbsw is %d.\n", __FUNCTION__,__LINE__,sw);
    BspLog(LOG_LEVEL_0,"[%s]@[%d] APP setuwbsw is %d.\n", __FUNCTION__,__LINE__,sw);

    /* 打开UWB功能 */
    if(UWB_SW_OPEN == sw)
    {
        /* Started by AICoder, pid:a120e57765b448514a3e0a8c60e7cf0e62494d8b */
        /*初始化uwbmac*/
        retVal = BspGetUwbMacAdd();/*初始化uwbmac信息，保存到g_uwbMac全局变量*/
        
        if (retVal != BSP_OK)
        {
            dbgInfo("[%s]@[%d] Failed to uwb mac init!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] Failed to uwb mac init!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
            return retVal;
        }
        /* Ended by AICoder, pid:a120e57765b448514a3e0a8c60e7cf0e62494d8b */

        /*开启光口L2ss通道*/
        retVal = BspSetUWBL2ssVlanInit();
        if (retVal != BSP_OK)
        {
            dbgInfo("[%s]@[%d] Failed to BspSetUWBL2ssVlanInit!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] Failed to BspSetUWBL2ssVlanInit!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);

            return retVal;
        }
        /*配置eth3网卡*/
        retVal = BspCfgOptNetEth3Addr();
        if (retVal != BSP_OK)
        {
            dbgInfo("[%s]@[%d] Failed to cfg eth3!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] Failed to cfg eth3!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);

            return retVal;
        }

        if(BSP_OK == retVal)
        {
            /*启动uwb收发线程开关*/
            BspSetBbuMsgToUwbSw(sw);
            BspSetUwbMsgToBbuSw(sw);
        }

    }

    /* 关闭UWB功能 */
    if(UWB_SW_CLOSE == sw)
    {
        /*关闭uwb收发线程开关*/
        BspSetBbuMsgToUwbSw(sw);
        BspSetUwbMsgToBbuSw(sw);

        /* Started by AICoder, pid:m9cb4c7d43740601451f095a20a7511eb4e80995 */
        /*关闭eth3网卡*/
        retVal = BspNetDeviceClose((char*)"eth3");
        if (retVal != BSP_OK)
        {
            dbgInfo("[%s]@[%d] Failed to BspNetDeviceClose eth3!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] Failed to BspNetDeviceClose eth3!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);

            return retVal;
        }
        /*关闭光口L2ss通道*/
        retVal = NtlL2ssTrxpDisable(12);
        if (retVal != BSP_OK)
        {
            dbgInfo("[%s]@[%d] Failed to NtlL2ssTrxpDisable!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);
            BspLog(LOG_LEVEL_0,"[%s]@[%d] Failed to NtlL2ssTrxpDisable!!! retVal=%d\n", __FUNCTION__,__LINE__,retVal);

            return retVal;
        }
        /* Ended by AICoder, pid:m9cb4c7d43740601451f095a20a7511eb4e80995 */
    }
    return retVal;
}
/* Ended by AICoder, pid:wae37m2187c787b1492d09e4b0ed150f62361d01 */

/**************************************************************************
 * 函数名称： BspStartUwbPwr
 * 功能描述： 向uwb发送功率等级查询的指令
 * 输入参数： 无
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
/* Started by AICoder, pid:i1846j25cc68f1c1412209c3b054642455f34a6a */
UINT32 BspStartUwbPwr(VOID)
{
    UINT8  temp[11] = "AT+UWBPWR?";
    UINT32 loop;
    UINT8  uwbSendTemp[11] = {0};
    UINT32 cnt = sizeof(uwbSendTemp);
    UINT32 retVal = BSP_OK;

    for(loop = 0;loop < cnt;loop++)
    {
    	uwbSendTemp[loop] = temp[loop];
    }
    dbgInfoEx("[%s] temp is:%s uwbSendTemp is:%s cnt:%lu\n",__FUNCTION__,temp,uwbSendTemp,sizeof(uwbSendTemp));

    retVal = BspUwbSend(uwbSendTemp,cnt);
    if(BSP_ERROR == retVal)
    {
       dbgInfo("[%s] UwbSend Message [%s] failed!!\n",__FUNCTION__,uwbSendTemp);
       return retVal;
    }
    return retVal;
}
/* Ended by AICoder, pid:i1846j25cc68f1c1412209c3b054642455f34a6a */

/**************************************************************************
 * 函数名称： BspSetUwbPwr
 * 功能描述： 向uwb发送功率等级设置的指令
 * 输入参数： value1：粗调值；value2：精调值
 * 输出参数： 无
 * 返 回 值： 无
 * 其它说明： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
/* Started by AICoder, pid:o46e4g3839oc8ed141c70848106f2813e2d72452 */
UINT32 BspSetUwbPwr(UINT32 value1 ,UINT32 value2)
{
    UINT32 cnt = 52;
    UINT8  temp[52] = {0};
    (void)sprintf_s((char*)temp, sizeof(temp), "AT+UWBPWR=%u,%u\r\n", value1, value2);
    
    cnt = zte_strnlen_s((const char*)temp,sizeof(temp));
    dbgInfo("[%s] temp=[%s] cnt=[%d]\n",__FUNCTION__,temp,cnt);
    return BspUwbSend(temp,cnt);
}
/* Ended by AICoder, pid:o46e4g3839oc8ed141c70848106f2813e2d72452 */

#ifndef _FUNCLIB_UART_IC4_2_UWB_H_INCLUDED
#define _FUNCLIB_UART_IC4_2_UWB_H_INCLUDED

#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"

/**************************************************************************
*                         函数声明
**************************************************************************/
typedef UINT32 (*pOpenUwbMacInMacSwitchFunc)(VOID);/* UwbMacInMac io控制回调 */

UINT32 _BspRecvBbuMsgToUwbThreadInit(VOID);
UINT32 _BspRecvUwbMsgToBbuThreadInit(VOID);
UINT32 BspDhcpServerIpInit(VOID);
char *BspGetDhcpServerIp(VOID);
UINT32 BspSetBbuMsgToUwbSw(UINT8 flag);
UINT32 BspGetBbuMsgToUwbSw(VOID);
UINT32 BspSetUwbMsgToBbuSw(UINT8 flag);
UINT32 BspGetUwbMsgToBbuSw(VOID);
UINT32 BspSetUwbSw(UINT8 sw);
UINT32 BspGetUwbMac(UINT8 *pUwbMac);
UINT32 BspOpenUwbMacInMacSwitchFunc(pOpenUwbMacInMacSwitchFunc uwbFunc);
UINT32 BspStartUwbPwr(VOID);
UINT32 BspSetUwbPwr(UINT32 value1 ,UINT32 value2);

#ifdef __cplusplus
}
#endif

#endif
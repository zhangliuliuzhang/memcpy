
#ifndef _FUNCLIB_UART_IC4_2_UWB_DEBUG_H_INCLUDED
#define _FUNCLIB_UART_IC4_2_UWB_DEBUG_H_INCLUDED

#ifdef __cplusplus
extern "C"{
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"

/**************************************************************************
*                         函数声明
**************************************************************************/


#ifdef __cplusplus
}
#endif

#endif
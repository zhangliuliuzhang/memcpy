/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_common.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块公共定义
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_CONVERGEGREEN_CONFIG_BLOCK_H_INCLUDED
#define FUNCLIB_CONVERGEGREEN_CONFIG_BLOCK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "funccommon_log.h"
#include "exprn.h"
#include "utdoa_ctrl_api.h"
#include "icopthalcomm.h"

/**************************************************************************
 *                               宏定义
 **************************************************************************/
	typedef struct
	{
	    UINT32 uiCellNo;    /*保存当前下发的小区号*/
	    UINT32 uiCarrNo;    /*保存当前下发的载波号*/
		UINT32 uiChanMask;    /*使能通道掩码*/
	    UINT32 uiRadio;    /*小区制式*/
	    UINT8 ucSwitch;    /*Qcell调度汇聚节能功能操作指示, 0:关闭, 1:使能*/
	    UINT8 ucBitPosition;    /*NR 节能位图*/
	    UINT8 ucReserved[6];
	}T_ConvergeGreenCfg;



#define BSP_CG_NUMBER_OF_THRESHOLD_CHECK(uiNumber, uiThreshold)      \
    {                                                                   \
        if ((uiNumber) >= (uiThreshold))                                \
        {                                                               \
            dbgErr("%s: %s=%u err,should be less than %u!\n",           \
                   __FUNCTION__, #uiNumber, (uiNumber), (uiThreshold)); \
            return BSP_ERROR;                                           \
        }                                                               \
    }

#define CONVERGE_GREEN_MAX_CARR_NUM (UINT32)3
#define CONVERGE_GREEN_MAX_CHAN_NUM  SRS_MAX_CARR_NUM_ONECELL
#define PSYNCIRQ_SWITCHOFF          (0)
#define QCELL_MAX_CHAN_NUM          (UINT32)16

	/**************************************************************************
	 *                               函数声明
	 **************************************************************************/

	UINT32 BspSetConDispathcPsyncIrqCfg(UINT32 uSwitch);
	UINT32 BspCleanConvergeGreenCfg(UINT32 uiRadioMode);
	UINT32 BspSetConvergeGreenConfig(T_ConvergeGreenCfg * pConvergeGreenCfg);
	UINT32 BspSetConvergeGreenOptEn(UINT32 uValidCellNum,UINT32 uiRadioMode);
    UINT32 BspOneClickCollectConvergeGreen(VOID);
	UINT32 BspSetConvergeGreenFrAdjustVal(T_ConvergeGreenCfg * pConvergeGreenCfg);
#ifdef __cplusplus
}
#endif
#endif



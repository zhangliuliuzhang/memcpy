/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_block.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块相关实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "converge_green_config.h"

#include "ichaladapt_ic4_2.h"
/*#include "indoorpositioncommon.h"*/

/**************************************************************************
 *                                 函数声明
 **************************************************************************/



/**************************************************************************
 *                                  宏定义
 **************************************************************************/


/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/
/* link参数更新处理 */

/****************************************************************************
*                         全局变量定义                                            *
****************************************************************************/
T_ConvergeGreenCfg  s_pConvergeGreenCfg[CONVERGE_GREEN_MAX_CARR_NUM] = {0};
T_BspHalAdaptConvergDispatchInfoTnr s_pConvergeGreenCfgForOpt = {0};



/****************************************************************************
*                              全局变量                                         *
****************************************************************************/


/* CRC错误计数记录 */

/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/

/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo_TNR
 * 功能描述: SRS 保存寄存器功能函数 TNR
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSavaConvergeGreenRegRegInfo_TNR(T_RF_SWTICH_MSG * pSrsShareMemRfSwitchData,UINT32 uiCarrLoop,UINT32 uiClearOrRecoverVal)
{
	UINT32 uiLoop = 0;

	BSP_CG_NUMBER_OF_THRESHOLD_CHECK(uiCarrLoop,CONVERGE_GREEN_MAX_CARR_NUM);

	s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].uBitPosition   = s_pConvergeGreenCfg[uiCarrLoop].ucBitPosition;
	s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].uCellCarrId   = s_pConvergeGreenCfg[uiCarrLoop].uiCarrNo;
	s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].uSwitch = (UINT32)s_pConvergeGreenCfg[uiCarrLoop].ucSwitch;
	s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].uValidCarrNum = pSrsShareMemRfSwitchData->uiLen;

	for(uiLoop = 0; uiLoop < pSrsShareMemRfSwitchData->uiLen; uiLoop++)
	{
		BSP_CG_NUMBER_OF_THRESHOLD_CHECK(uiLoop,CONVERGE_GREEN_MAX_CHAN_NUM);

		if(1 == uiClearOrRecoverVal)
		{

			s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].tAddrInfo[uiLoop].uClearVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}

		if(0 == uiClearOrRecoverVal)
		{
			s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pConvergeGreenCfgForOpt.tCellInfo[uiCarrLoop].tAddrInfo[uiLoop].uRecoverVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}
	}
	return BSP_OK;

}




/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo
 * 功能描述: SRS 保存寄存器功能函数
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSavaConvergeGreenRegInfo(T_RF_SWTICH_MSG * pSrsShareMemRfSwitchData,UINT32 uiRadioMode,UINT32 uiCarrNo,UINT32 uiCarrLoop,UINT32 uiClearOrRecoverVal)
{

    switch(uiRadioMode)
    {
        case BSP_RADIO_STANDARD_NR:
        {
        	BspSavaConvergeGreenRegRegInfo_TNR(pSrsShareMemRfSwitchData,uiCarrLoop,uiClearOrRecoverVal);
            break;
        }
        case BSP_RADIO_STANDARD_LTE_TDD:
        {
            break;
        }
        case BSP_RADIO_STANDARD_FDD_NR:
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            break;
        }
        default:
        {
            break;
        }
    }
	return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo
 * 功能描述: SRS 获取寄存器功能函数
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleConvergeGreenRegInfo(T_ConvergeGreenCfg * pConvergeGreenCfg,UINT32 uiGrp,UINT32 uiCarrLoop,UINT32 uiClearOrRecoverVal)
{
	UINT32 uiLoop = 0;
    T_RF_SWTICH_MSG ShareMemRfSwitchData = {0};
    E_RegType uiType   = UT_REG_TYPE_PSWT;


    BspHalAdaptClrSaveRegInfo(uiType,uiGrp);
    BspHalAdaptSetSaveGrp(uiType,uiGrp);
    BspHalAdaptSetSaveRegEn(1);

    for(uiLoop = 0 ; uiLoop<BspGetTxChanNum(); uiLoop++)
    {
    	 if((pConvergeGreenCfg->uiChanMask & ((UINT32)0x1 << uiLoop)) !=0)
    	 {
    		 BspHalAdaptRcdDlpreGainClr(uiLoop,pConvergeGreenCfg->uiCarrNo, pConvergeGreenCfg->uiRadio, uiClearOrRecoverVal);
    		 BspHalAdaptConDispatchSetCcToGainDelay(uiLoop,pConvergeGreenCfg->uiCarrNo,pConvergeGreenCfg->uiRadio);
    	 }
    }

    BspHalAdaptSetSaveRegEn(0);
    BspHalAdaptGetSaveRegInfo(uiType,uiGrp, &ShareMemRfSwitchData);

    BspSavaConvergeGreenRegInfo(&ShareMemRfSwitchData,pConvergeGreenCfg->uiRadio,pConvergeGreenCfg->uiCarrNo,uiCarrLoop,uiClearOrRecoverVal);
	return BSP_OK;

}
/*****************************************************************************
 * 函数名称: BspSaveAppConvergeGreenConfig
 * 功能描述: 保存汇聚调度节能APP配置
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: 存储的下标
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSaveAppConvergeGreenConfig(T_ConvergeGreenCfg  *pConvergeGreenCfg)
{
	UINT32 uiLoop = 0;

	for(uiLoop =0 ;uiLoop<CONVERGE_GREEN_MAX_CARR_NUM;uiLoop++)
	{
	    dbgInfoEx("%s>> second  s_pConvergeGreenCfg[%d].ulCellNo: %d \n", __FUNCTION__, uiLoop, s_pConvergeGreenCfg[uiLoop].uiCellNo);
	    if( (pConvergeGreenCfg->uiCellNo == s_pConvergeGreenCfg[uiLoop].uiCellNo) && (pConvergeGreenCfg->uiRadio == s_pConvergeGreenCfg[uiLoop].uiRadio) )
	    {
	    	memcpy_s(s_pConvergeGreenCfg+uiLoop,sizeof(T_ConvergeGreenCfg),pConvergeGreenCfg,sizeof(T_ConvergeGreenCfg));
	    	return uiLoop;
	    }
	}

	for(uiLoop = 0 ;uiLoop<CONVERGE_GREEN_MAX_CARR_NUM;uiLoop++)
	{
	    dbgInfoEx("%s>> first s_pConvergeGreenCfg[%d].ulCellNo: %d,s_pConvergeGreenCfg[%d].uiRadio: %d \n", __FUNCTION__, uiLoop, s_pConvergeGreenCfg[uiLoop].uiCellNo, uiLoop, s_pConvergeGreenCfg[uiLoop].uiRadio);
		if( (s_pConvergeGreenCfg[uiLoop].uiCellNo == 0) && (s_pConvergeGreenCfg[uiLoop].uiRadio == 0) )
		{
	    	memcpy_s(s_pConvergeGreenCfg+uiLoop,sizeof(T_ConvergeGreenCfg),pConvergeGreenCfg,sizeof(T_ConvergeGreenCfg));
	    	return uiLoop;
		}
	}

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetConvergeGreenFrAdjustVal
 * 功能描述: 光口帧头调整量解耦 - 汇聚调度
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetConvergeGreenFrAdjustVal(T_ConvergeGreenCfg * pConvergeGreenCfg)
{
    UINT32 chanMask = 0;
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;
    chanMask = pConvergeGreenCfg->uiChanMask;
    for(chan = 0; chan < QCELL_MAX_CHAN_NUM; chan++)
    {
        if((chanMask & ((UINT32)0x1 << chan)) !=0)
        {
            retVal = BspHalAdaptSetFeatureFrAdjustVal(chan, pConvergeGreenCfg->uiCarrNo, pConvergeGreenCfg->uiRadio, E_QCELL_DISPATCH_FUNCION);
        }
    }   
    return retVal;
}

/*****************************************************************************
 * 函数名称: BspSetConvergeGreenConfig
 * 功能描述: 汇聚调度节能对APP配置
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetConvergeGreenConfig(T_ConvergeGreenCfg * pConvergeGreenCfg)
{
	UINT32 uiGrp = 0;
	UINT32 uiCarrLoop = 0;
	UINT32 uiClear = 1;
	UINT32 uiRecoverVal =0;

	uiCarrLoop = BspSaveAppConvergeGreenConfig(pConvergeGreenCfg);

	/*光口帧头调整量解耦*/
	BspSetConvergeGreenFrAdjustVal(pConvergeGreenCfg);

    uiGrp = uiCarrLoop*2;

    BspHandleConvergeGreenRegInfo(pConvergeGreenCfg,uiGrp,uiCarrLoop,uiClear);

    uiGrp = uiCarrLoop*2 + 1;

    BspHandleConvergeGreenRegInfo(pConvergeGreenCfg,uiGrp,uiCarrLoop,uiRecoverVal);

	return BSP_OK;
}



/*****************************************************************************
 * 函数名称: BspCleanConvergeGreenCfg
 * 功能描述: 汇聚调度节能对APP配置
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspCleanConvergeGreenCfg(UINT32 uiRadioMode)
{
    switch(uiRadioMode)
    {
        case BSP_RADIO_STANDARD_NR:
        {
        	memset_s(&s_pConvergeGreenCfg,sizeof(T_ConvergeGreenCfg) *CONVERGE_GREEN_MAX_CARR_NUM,0,sizeof(T_ConvergeGreenCfg) * CONVERGE_GREEN_MAX_CARR_NUM);
        	memset_s(&s_pConvergeGreenCfgForOpt,sizeof(T_BspHalAdaptConvergDispatchInfoTnr),0,sizeof(T_BspHalAdaptConvergDispatchInfoTnr) );
        	BspHalAdaptM0ClearConDispatchMesg();
        	break;
        }
        case BSP_RADIO_STANDARD_LTE_TDD:
        {
            break;
        }
        case BSP_RADIO_STANDARD_FDD_NR:
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            break;
        }
        default:
        {
            break;
        }
    }
	return BSP_OK;
}

UINT32 BspSetConDispathcPsyncIrqCfg(UINT32 uSwitch)
{
    UINT32 ret = BSP_OK;

    dbgInfoEx("[%s]  uSwitch=%u\n",__FUNCTION__,uSwitch);
    ret |= BspHalAdaptConDispathcPsyncIrqCfg(uSwitch);
    if(PSYNCIRQ_SWITCHOFF == uSwitch)
    {
        BspSysMsDelay(20);
        ret |= BspHalAdaptM0RcvConDispatchMesg();
        dbgInfoEx("[%s]  uSwitch is off,  Recover ConDispath MSG\n",__FUNCTION__);
    }
    return ret;
}

/*****************************************************************************
 * 函数名称: BspSetConvergeGreenOptEn
 * 功能描述: 使能制式下的所有小区的SRS配置。
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetConvergeGreenOptEn(UINT32 uValidCellNum,UINT32 uiRadioMode)
{
	   switch(uiRadioMode)
	    {
	        case BSP_RADIO_STANDARD_NR:
	        {
	        	s_pConvergeGreenCfgForOpt.uValidCellNum = uValidCellNum;
	        	s_pConvergeGreenCfgForOpt.uInfoValidFlag = 1;
	        	BspHalAdaptM0SetConDispatchMesg(&s_pConvergeGreenCfgForOpt);

	        	 /*光口BspSetConDispathcPsyncIrqCfg开中断 接口*/
	            break;
	        }
	        case BSP_RADIO_STANDARD_LTE_TDD:
	        {
	        	 /*光口开中断 接口*/
	            break;
	        }
	        case BSP_RADIO_STANDARD_FDD_NR:
	        case BSP_RADIO_STANDARD_LTE_FDD:
	        {
	        	 /*光口开中断 接口*/
	            break;
	        }
	        default:
	        {
	            break;
	        }
	    }
	return BSP_OK;
}

UINT32 printconvergegreeninfo(VOID)
{
	UINT32 uiloop =0;
	UINT32 uiloopcell =0;
	RedirPrintf("-------fdd converge green app info-------\n");
    for(uiloop =0;uiloop<CONVERGE_GREEN_MAX_CARR_NUM;uiloop++)
    {

		RedirPrintf("\n");
		RedirPrintf("uiCellN: %d ",s_pConvergeGreenCfg[uiloop].uiCellNo);
		RedirPrintf("uiCarrNo: 0x%x ",s_pConvergeGreenCfg[uiloop].uiCarrNo);
		RedirPrintf("uiChanMask:0x%x ",s_pConvergeGreenCfg[uiloop].uiChanMask);
		RedirPrintf("uiRadio:0x%x ",s_pConvergeGreenCfg[uiloop].uiRadio);
		RedirPrintf("ucSwitch:0x%x ",s_pConvergeGreenCfg[uiloop].ucSwitch);
		RedirPrintf("ucBitPosition:0x%x ",s_pConvergeGreenCfg[uiloop].ucBitPosition);

    }
	RedirPrintf("\n");

	RedirPrintf("-------fdd converge green opt info-------\n");
	RedirPrintf("uInfoValidFlag:%d\n ",s_pConvergeGreenCfgForOpt.uInfoValidFlag);
	RedirPrintf("uValidCellNum:%d \n",s_pConvergeGreenCfgForOpt.uValidCellNum);


    for(uiloopcell =0;uiloopcell<CONVERGE_GREEN_MAX_CARR_NUM;uiloopcell++)
    {
    	RedirPrintf("uCellCarrId:%d ",s_pConvergeGreenCfgForOpt.tCellInfo[uiloopcell].uCellCarrId);
    	RedirPrintf("uValidCarrNum:%d ",s_pConvergeGreenCfgForOpt.tCellInfo[uiloopcell].uValidCarrNum);
    	RedirPrintf("uBitPosition:%d ",s_pConvergeGreenCfgForOpt.tCellInfo[uiloopcell].uBitPosition);
    	RedirPrintf("uSwitch:%d ",s_pConvergeGreenCfgForOpt.tCellInfo[uiloopcell].uSwitch);
    	RedirPrintf("\n");

    	for(uiloop =0;uiloop<8;uiloop++)
    	{
    	     RedirPrintf("uAddr:0x%x ",s_pConvergeGreenCfgForOpt.tCellInfo[uiloopcell].tAddrInfo[uiloop].uAddr);
    	     RedirPrintf("uClearVal:%d ",s_pConvergeGreenCfgForOpt.tCellInfo[uiloopcell].tAddrInfo[uiloop].uClearVal);
    	     RedirPrintf("uRecoverVal:%d ",s_pConvergeGreenCfgForOpt.tCellInfo[uiloopcell].tAddrInfo[uiloop].uRecoverVal);
    	     RedirPrintf("\n");
    	}
    	RedirPrintf("\n");
    }

	return BSP_OK;
}

UINT32 BspOneClickCollectConvergeGreen(VOID)
{
    RedirPrintf("-------- SRS printconvergegreeninfo ------------ \n");
	printconvergegreeninfo();

	return BSP_OK;
}

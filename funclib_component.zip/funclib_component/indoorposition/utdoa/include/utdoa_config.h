/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : utdoa_ic4_2.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供utdoa_ic4_2模块相关定义
 * 注意事项 : 无
 * 作    者 : 
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_UTDOA_CONFIG_BLOCK_H_INCLUDED
#define FUNCLIB_UTDOA_CONFIG_BLOCK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "chnmap_a.h"
#include "dmimo_config.h"


/* APP下发的模式类型 */
#define        BSP_UTDOA_MODE_OFF (UINT32)0                    /* 关闭模式 */
#define        BSP_UTDOA_MODE_LARGE_ERGODIC (UINT32)1          /* 大遍历 */
#define        BSP_UTDOA_MODE_SMALL_ERGODIC_AND_SRS (UINT32)6  /* 小遍历+SRS 对应中频的 小遍历 */
#define        BSP_UTDOA_MODE_SRS (UINT32)4                    /* 纯SRS定位 */

/* 操作模式 */
#define SEND_MODE       (UINT32)1   // 发送模式
#define CAPTURE_MODE    (UINT32)2   // 拍照模式
#define INSERT_MODE     (UINT32)3   // 回传模式


#define UTDOA_MAX_CARR_NUM (UINT32)3      /*UTDOA 支持的最大载波个数*/

#define QCELL_UTDOA_MAX_CHAN_NUM       (UINT32)16


#define UTDOA_AAC_GROUP_NUM (UINT32)8      /*UTDOA 有效起始结束组个数*/
#define UTDOA_AAC_FRAME_NUM (UINT32)128      /*UTDOA 有效起始结束组个数*/

#define	UTDOA_AAC_RETURN_SYM_POS (UINT32)8  /*AAC序列回传符号个数*/

#define UTDOA_SEND_TIME_SLOT_NUM (UINT32)160   /*AAC序列发送时隙个数*/
#define UTDOA_CAPTURE_TIME_SLOT_NUM (UINT32)20   /*AAC序列拍照时隙个数*/
#define UTDOA_RETURN_TIME_SLOT_NUM (UINT32)160   /*AAC序列回传时隙个数*/

#define    UTDOA_BITMAP_WORD_LENGTH (UINT32)32

#define UTDOA_SENDRAM_LEN  (UINT32)1024


#define	RTT_SRS_TIME_SLOT_NUM (UINT32)20    	/*RTT序列发送时隙个数*/

#define UT_INVALID_CARR_NUMBER_FLAG (UINT32) 0xffff

#define UT_DMM_RESOURCE_EN (UINT32)1 


/***********************************************************************************/
/*                             UTDOA 结构体定义                                      */
/***********************************************************************************/

typedef struct tagT_RruUTDOACellCfg
{
    UINT32 ulCellNo;    /*保存当前下发的小区号*/
    UINT32 ulCarrNo;    /*保存当前下发的载波号*/
    UINT32 uiChanMask;    /*使能通道掩码*/
    UINT32 uiRadio;    /*制式*/
    UINT32 uiCarrBandWidth;    /*载波带宽*/
} T_RruUTDOACellCfg;

/*一 大遍历小遍历接口*/
typedef struct tagT_RruUTDOALargeSmallErgodic
{
    UCHAR   Enable;                /*空口校准使能控制, 0：停止，1：启动大遍历，6：启动小遍历 4:SRS*/
    USHORT  AACFrameStart;         /*AAC启动帧号*/
    USHORT  AACFrameEnd;           /*AAC结束帧号*/
    UCHAR   AACGroup;              /*本RRU所属AAC组ID，最多8个*/
    USHORT  AACGroupStartFrame[UTDOA_AAC_GROUP_NUM]; /*AAC启动帧号，有效元素0～（AAC分组号-1)*/
    USHORT  AACGroupEndFrame[UTDOA_AAC_GROUP_NUM];   /*AAC结束帧号，有效元素0～（AAC分组号-1)*/
    UCHAR   AACSendFrame[UTDOA_AAC_FRAME_NUM];     /*AAC序列发送帧号，位图表示*/
    UCHAR   AACCaputeFrame[UTDOA_AAC_FRAME_NUM];   /*AAC序列拍照帧号，位图表示*/
    UCHAR   AACReturnFrame[UTDOA_AAC_FRAME_NUM];   /*AAC序列回传帧号，位图表示*/
    USHORT  RttStartFrame;         /*RTT启动帧号*/
    USHORT  RttEndFrame;           /*RTT结束帧号*/
    UCHAR   Reserved[18];          /*Reserved*/
} T_RruUTDOALargeSmallErgodic;

/*二UTDOA SRS定位接口*/
typedef struct tagT_RruUTDOASRSCfg
{
    UINT32  CellFlag;              /*本地小区标识*/
    UCHAR   AACSendTimeSlot[UTDOA_SEND_TIME_SLOT_NUM];  /*AAC序列发送时隙*/
    USHORT  AACSendSym;            /*AAC序列发送符号*/
    UCHAR   AACCaptureTimeSlot[UTDOA_CAPTURE_TIME_SLOT_NUM];/*AAC序列拍照时隙*/ 
    UCHAR   AACReturnTimeSlot[UTDOA_RETURN_TIME_SLOT_NUM];/*AAC序列回传时隙*/
    USHORT  AACReturnSymPos[UTDOA_AAC_RETURN_SYM_POS];    /*AAC序列回传符号*/
    UCHAR   RttSendTimeSlot[RTT_SRS_TIME_SLOT_NUM];   /*RTT序列发送时隙*/
    USHORT  RttSendSym;            /*RTT序列发送符号*/
    UCHAR   RttReturnTimeSlot[RTT_SRS_TIME_SLOT_NUM]; /*RTT序列回传时隙*/
    USHORT  RttReturnSym;          /*RTT回传符号位置*/
    UCHAR   SRSCaptureTimeSlot[RTT_SRS_TIME_SLOT_NUM];/*SRS拍照时隙*/
    USHORT  SRSCaptureSym;         /*SRS拍照符号*/
    USHORT  SRSCaptureCycle;       /*SRS拍照周期*/
    UINT32  SRSReturnFrame;        /*SRS回传帧号*/
    UCHAR   SRSReturnTimeSlot[RTT_SRS_TIME_SLOT_NUM]; /*SRS回传时隙*/
    USHORT  SRSReturnSym;          /*SRS回传符号*/
    UCHAR   Reserved[36];          /*Reserved*/
} T_RruUTDOASRSCfg;

/*四  UTDOA校准周期配置接口*/
typedef struct
{
    UINT16 usCalibPeriod;       /*utdoa小遍历校准周期，单位：超帧,(小遍历超帧周期)*/
    UINT16 usOffset;            /*UTDOA起始超帧校准周期内偏移(小遍历超帧号)*/
    UINT8 uReserved[8];
}T_UtdoaCalibPeriodCfg;

typedef struct tagT_RruUTDOAAllCfg
{
    T_RruUTDOACellCfg   UtdoaCellCfg;
    T_RruUTDOALargeSmallErgodic UtdoaLargeSmallErgodicCfg;
    T_RruUTDOASRSCfg UtdoaSrsCfg;
    T_UtdoaCalibPeriodCfg UtdoaCalibPeriodCfg;
} T_RruUTDOAAllCfg;

/**************************************************************************
 *                        函数声明
 **************************************************************************/
#if 0 //用不到的结构体
	typedef struct tagT_RruUTDOALargeSmallErgodicAllCfg
	{
			T_RruUTDOACellCfg  UtdoaLargeSmallErgodicCellCfg;

		    T_RruUTDOALargeSmallErgodic UtdoaLargeSmallErgodicCfg;

	} T_RruUTDOALargeSmallErgodicAllCfg;

	typedef struct tagT_RruUTDOASRSAllCfg
	{
			T_RruUTDOACellCfg UtdoaSrsCellCfg;
		    T_RruUTDOASRSCfg  UtdoaSrsCfg;

	} T_RruUTDOASRSAllCfg;
#endif


#define BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK_UTDOA(uiNumber, uiThreshold)      \
    {                                                                   	  \
        if ((uiNumber) >= (uiThreshold))                                	  \
        {                                                               	  \
            dbgErr("%s: %s=%u err,should be less than %u!\n",           	  \
                   __FUNCTION__, #uiNumber, (uiNumber), (uiThreshold)); 	  \
            return BSP_ERROR;                                           	  \
        }                                                               	  \
    }


/* 指针非空检查宏，返回 BSP_ERROR_NULL_POINTER */
#define INPUT_POINTER_CHECK_UTDOA(ppointer,bspState)                      	  \
	if (NULL == ppointer)                                                 	  \
    {                                                                         \
		if(BSP_ERROR == bspState)                                             \
		{                                                                     \
			dbgInfo("%s:Input Pointer is NULL!\n",__FUNCTION__);              \
		}                                                                     \
        return bspState;                                                      \
    }                                                                         \
	 
#define ARR_BOUND_UTDOA(loop,border)                    	                  \
	if (loop >= border)	  	  												  \
	{																  	      \
		dbgErr("%s : arr bound! loop:%d border:%d",__FUNCTION__,loop,border); \
		return BSP_ERROR;													  \
	}																  	      \


/* Started by AICoder, pid:7af66t5a04k70501427f0a286062eb060c190ced */
// 专门为中频的规避：中频底层结构体中的数组长度只有3，用于保存3中模式的信息，但实际上UTDOA有四种模式，
// 所以在使用到中频底层结构体时，需要单独使用该宏进行校验。idx不能大于等于3，
// 在其他对中频模式的校验中，idx不能大于等于4
#define ARR_BOUND_UTDOA_FOR_HAL(loop,border)                    	          \
	if (loop >= border)	  	  												  \
	{																  	      \
		dbgErr("%s : arr bound for hal mode! loop:%d border:%d",__FUNCTION__,loop,border); \
		return BSP_OK;													  \
	}																  	      \
/* Ended by AICoder, pid:7af66t5a04k70501427f0a286062eb060c190ced */

UINT32 BspGetSuperFrameNoAddr(VOID);
UINT32 BspGetSuperFrameNo(VOID);
UINT32 BspTestSetUtdoaMode(UCHAR mode);
UINT32 BspInterruptDealUtdoaThreadInit(void);
VOID BspSetInterrupFlagUtdoa(UINT32 sw);
UINT32 BspGetNextSuperMode(VOID);

T_UTDOA_AC_INDEX_MAP * BspGetUtAcIndexMap(VOID);
UINT32 BspUtByPassSubLna(UINT32 chanMask, UINT32 radio);
UINT32 BspUtByPassSubLnaForApp(VOID);


/* ------------------------ 打印类 ----------------------- */
VOID utdoahelp(VOID);
UINT32 BspSetUtdoaPrintFlag(UINT32 en);

UINT32 BspPrintSaveDataUtForHal(UINT32 carrLoop);
UINT32 BspPrintDataAppForBsp(UINT32 uiCarrLoop, UINT32 mode);

UINT32 printutsuperframe(VOID);
UINT32 printutdosrscfg(VOID);
UINT32 printutdoalsecfg(VOID);
UINT32 BspUtAcCtrlParaPrint(UINT32 tddSel, UINT32 acType);

/* ------------------- 暴露给app的接口 ------------------- */
UINT32 BspSetUtIoEn(UINT32 bspChan, UINT32 dir, UINT32 en);
UINT32 BspSetDlGpEn(UINT32 bspChan, UINT32 radioMode, UINT32 carrId, UINT32 en);
UINT32 BspSetUtdoaPsyncIrqCfg(UINT32 switchEnable);
UINT32 BspSetUtdoaAllConfigInfoAnalysis(T_RruUTDOAAllCfg * pUtdoaAllCfg);
UINT32 BspCleanAllUtdoaCfg(VOID);
UINT32 BspUtdoaMasterEnable(UINT32 chanMask, UINT32 carrId, UINT32 radioMode,UINT32 en);
UINT32 BspSetUtdoaDlDtxPaAndAmpGpSel(UINT32 ulChanMask,UINT32 uiSwitch);
UINT32 BspSetUtdoaDlTimingDlTddDlyClean(UINT32 uiChanMask);
UINT32 BspUtdoaIsOpenGp(VOID);


UINT32 BspOneClickCollectUtdoa(VOID);/* utdoa一键采集接口 */
UINT32 BspGetUtDmmCoexistDmmSt();
VOID BspUpdateDmimoExistStatus();

#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_J204_BLOCK_H_INCLUDED



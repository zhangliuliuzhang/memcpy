/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : utdoa_ic4_2.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供UTDOA定位模块相关实现
 * 注意事项 : 无
 * 作    者 : 刘林涛 1
 * 创建日期 : 2022-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "utdoa_config.h"
#include "utdoa_aac.h"
#include "bsppub.h"
#include "ichaladapt_ic4_2.h"
#include "psync.h"
#include "secure_func.h"
#include "chnmap_a.h"
#include "optadpt.h"
#include "tddcfg_ic4_2.h"
#include "io_api.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "pacommon.h"
#include "pa_ic4_2_calcpara.h"
#include "dpd_app.h"




/**************************************************************************
 *                                 函数声明
 **************************************************************************/



/**************************************************************************
 *                                  宏定义
 **************************************************************************/


/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/

/****************************************************************************
*                         全局变量定义                                            *
****************************************************************************/
/*保存APPUTDOA配置信息*/
//T_RruUTDOALargeSmallErgodicAllCfg s_pUtdoaLargeSmallErgodicCfg[UTDOA_MAX_CARR_NUM] = {0};
//T_RruUTDOASRSAllCfg s_pUtdoaSrsAllCfg[UTDOA_MAX_CARR_NUM] = {0};
T_RruUTDOAAllCfg s_pUtdoaAllCfg[UTDOA_MAX_CARR_NUM] = {0}; // ZHY：临时注释，用于测试
T_RruUTDOAAllCfg s_pUtdoaAllCfgBak[UTDOA_MAX_CARR_NUM][UT_VALIDMODE_NUM] = {0}; //保存APP下发的每一个载波及模式的参数

/* 保存转给中频的数据，便于维测 */
T_BspHalAdaptUtSendParaCfg   bspSaveDateUtSendParaCfg[UTDOA_MAX_CARR_NUM]   = {0};
T_BspHalAdaptUtSampleParaCfg bspSaveDateUtSampleParaCfg[UTDOA_MAX_CARR_NUM] = {0};
T_BspHalAdaptUtInsertParaCfg bspSaveDateUtInsertParaCfg[UTDOA_MAX_CARR_NUM] = {0};

/* 用于存放AAC序列 */
T_CPG_AacParam     s_PCpg_Aac_Param[MAX_RADIO_NUM] = {0};

UINT32 utCarrNumArr[UTDOA_MAX_CARR_NUM] = {UT_INVALID_CARR_NUMBER_FLAG, UT_INVALID_CARR_NUMBER_FLAG, UT_INVALID_CARR_NUMBER_FLAG}; 
UINT32 utCarrNum = 0; // 统计UTDOA载波数量

// 保存传递给光口的 rtt增益、r2r增益、校准周期、周期内偏移信息
T_UtdoaSmallErgodicParaOpt toOptParaBak = {0};

/* 保存转给中频的PA时序数据，便于维测 */
/*T_BspHalAdaptUtDlIoPara bspSaveDataPaDlCfg[MAX_AAC_ANT_NUM][UTDOA_MAX_CARR_NUM] = {0};
T_BspHalAdaptUlIoPara bspSaveDataPaUlCfg[MAX_AAC_ANT_NUM][UTDOA_MAX_CARR_NUM] = {0};*/

UINT32 printFlag = 1; /* 维测打印标志，默认放开 */

UINT32 calibPeriod_Ut[UTDOA_MAX_CARR_NUM] = {0}; // 校准周期全局变量
UINT32 offset_Ut[UTDOA_MAX_CARR_NUM] = {0};      // 周期内偏移全局变量
UINT32 calibPeriod_Ut_Bak[UTDOA_MAX_CARR_NUM] = {0}; // 校准周期全局变量
UINT32 offset_Ut_Bak[UTDOA_MAX_CARR_NUM] = {0};      // 周期内偏移全局变量

UINT32 optInterruptFlag = 1; /* 光口切换RTT和R2R增益的中断的开关 */

/* Started by AICoder, pid:cb4b0wc0f7d61781495709f510a8ac050a98a94d */
T_AC_CTRL_CFG g_utAcCtrlPara[DPDIC_MAX_TDD_NUM][AC_CTRL_TYPE_NUM] = {0};
T_AC_CTRL_SW_OUT_CFG g_utAcCtrlMux[AC_CTRL_TYPE_NUM] = {0};
T_UTDOA_AC_INDEX_MAP utAcIndexMap[QCELL_UTDOA_MAX_CHAN_NUM] = {0};
T_UTDOA_AC_INDEX_MAP* BspGetUtAcIndexMap(VOID)
{
    return &(utAcIndexMap[0]);
}

UINT32 utDmmCoexistDmmSt = 0; /*UTDOA和DMIMO共存场景下，中频DMIMO开关状态，默认0关闭*/

/* Ended by AICoder, pid:cb4b0wc0f7d61781495709f510a8ac050a98a94d */
/* 测试专用代码 */
#if 0
T_RruUTDOAAllCfg s_pUtdoaAllCfg[UTDOA_MAX_CARR_NUM] = 
{
	// 第 0 组的 T_RruUTDOAAllCfg
	{
		// T_RruUTDOACellCfg
		{
			0,		// UINT32 ulCellNo;    	 	/*保存当前下发的小区号*/
		    1,		// UINT32 ulCarrNo;   	 	/*保存当前下发的载波号*/
		    3,		// UINT32 uiChanMask;    	/*使能通道掩码*/
		    0x2000,	// UINT32 uiRadio;    		/*制式*/
		    100,	// UINT32 uiCarrBandWidth;  /*载波带宽*/

		},
		// T_RruUTDOALargeSmallErgodic
		{
			6,								 // UCHAR   Enable;               					 /*空口校准使能控制, 0：停止，1：启动大遍历，2：启动小遍历*/
		    10,								 // USHORT  AACFrameStart;         					 /*AAC启动帧号*/
		    300,							 // USHORT  AACFrameEnd;           					 /*AAC结束帧号*/
		    191,							 // UCHAR   AACGroup;              					 /*本RRU所属AAC组ID，最多8个*/
		    {0,100,200,300,400,500,600,700}, // USHORT  AACGroupStartFrame[UTDOA_AAC_GROUP_NUM]; /*AAC启动帧号，有效元素0～（AAC分组号-1)*/
		    {50,150,250,350,450,550,650,799},// USHORT  AACGroupEndFrame[UTDOA_AAC_GROUP_NUM];   /*AAC结束帧号，有效元素0～（AAC分组号-1)*/
		    {1,0,1,1,0},					 // UCHAR   AACSendFrame[UTDOA_AAC_FRAME_NUM];     	 /*AAC序列发送帧号，位图表示*/
		    {0,1,1,1,1},					 // UCHAR   AACCaputeFrame[UTDOA_AAC_FRAME_NUM];   	 /*AAC序列拍照帧号，位图表示*/
		    {1,1,1,1,1},					 // UCHAR   AACReturnFrame[UTDOA_AAC_FRAME_NUM];     /*AAC序列回传帧号，位图表示*/
		    {101},							 // USHORT  RttStartFrame;         					 /*RTT启动帧号*/
		    {312},							 // USHORT  RttEndFrame;           					 /*RTT结束帧号*/
		    								 // UCHAR   Reserved[18];          					 /*Reserved*/
		},
		// T_RruUTDOASRSCfg
		{
			1,					// UINT32  CellFlag;              								 /*本地小区标识*/
			{1,2,3,8,9,1,0,5},	// UCHAR   AACSendTimeSlot[UTDOA_SEND_TIME_SLOT_NUM];  			 /*AAC序列发送时隙*/
			9,					// USHORT  AACSendSym;            								 /*AAC序列发送符号*/
			{6,8,9,2,4,2,1,4},	// UCHAR   AACCaptureTimeSlot[UTDOA_CAPTURE_TIME_SLOT_NUM];		 /*AAC序列拍照时隙*/ 
			{7,5,6,3,6,4,2,2},	// UCHAR   AACReturnTimeSlot[UTDOA_RETURN_TIME_SLOT_NUM];		 /*AAC序列回传时隙*/
			{6,6,6,6,6,5,4,6},	// USHORT  AACReturnSymPos[UTDOA_AAC_RETURN_SYM_POS];    		 /*AAC序列回传符号*/
			{3,6,4,4,5,6,2,1},	// UCHAR   RttSendTimeSlot[RTT_SRS_TIME_SLOT_NUM];  			 /*RTT序列发送时隙*/
			8,					// USHORT  RttSendSym;            								 /*RTT序列发送符号*/
			{1,5,5,2,6,6,1,1},	// UCHAR   RttReturnTimeSlot[RTT_SRS_TIME_SLOT_NUM]; 			 /*RTT序列回传时隙*/
			16,					// USHORT  RttReturnSym;         								 /*RTT回传符号位置*/
			{1,6,5,1,2,3,7,9},	// UCHAR   SRSCaptureTimeSlot[RTT_SRS_TIME_SLOT_NUM];			 /*SRS拍照时隙*/
			15,					// USHORT  SRSCaptureSym;         						         /*SRS拍照符号*/
			20,					// USHORT  SRSCaptureCycle;       							     /*SRS拍照周期*/
			111,				// UINT32  SRSReturnFrame;        								 /*SRS回传帧号*/
			{2,6,2,1,4,5,6,3},	// UCHAR   SRSReturnTimeSlot[RTT_SRS_TIME_SLOT_NUM]; 			 /*SRS回传时隙*/
			33,					// USHORT  SRSReturnSym;                                         /*SRS回传符号*/
								// UCHAR   Reserved[36];                                         /*Reserved*/
		},
		// T_UtdoaCalibPeriodCfg
		{
		    6,                  // UINT16 usCalibPeriod;       /*utdoa小遍历校准周期，单位：超帧,(小遍历超帧周期)*/
	        30,                 // UINT16 usOffset;            /*UTDOA起始超帧校准周期内偏移(小遍历超帧号)*/
		}

	},


};
#endif

UINT32 BspTestSetUtdoaMode(UCHAR mode)
{
    s_pUtdoaAllCfg->UtdoaLargeSmallErgodicCfg.Enable = mode;
	return BSP_OK;
}

UINT32 testStopFlag = 1;
VOID testSetTestStopFlag(UINT32 flag)// 停止参数下发过程，进而禁止模式切换
{
    testStopFlag = flag;
}

UINT32 interrupFlag = 1;
VOID BspSetInterrupFlagUtdoa(UINT32 sw) // 停止/启动 ，线程中对小遍历和SRS模式的切换
{
    interrupFlag = sw;
}

// 0：禁止模式切换，包括参数下发过程 、小遍历SRS模式切换线程  1：不禁止模式切换
VOID BspTestSetStopChangeMode(UINT32 en)
{
    testSetTestStopFlag(en);
    BspSetInterrupFlagUtdoa(en);
}



T_BspHalAdaptUtSendParaCfg s_pUtdoaSendParaCfgForHal[UTDOA_MAX_CARR_NUM] = {0};

T_UtdoaCalibPeriodCfg UtdoaCalibPeriodCfg = {0};



/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/
/* Started by AICoder, pid:027559dbc17874a1441c09753015862661f53fc4 */
/* 注意，不在用bit区分载波了，因为下发的信息中有载波号以及对应的使能en */ 
UINT32 BspGetUtEnModel(UINT32 uiUtEnMode) 
{ 
    UINT32 uiUtForHalMode = UT_MODE_OFF; 

    switch(uiUtEnMode) 
    { 
        case BSP_UTDOA_MODE_OFF: 
            uiUtForHalMode =       UT_MODE_OFF; 
            break; 
        case BSP_UTDOA_MODE_LARGE_ERGODIC: 
            uiUtForHalMode =       UT_MODE_GROUP; 
            break; 
        case BSP_UTDOA_MODE_SMALL_ERGODIC_AND_SRS: 
            uiUtForHalMode =       UT_MODE_CALI; 
            break; 
        case BSP_UTDOA_MODE_SRS:
            uiUtForHalMode =       UT_MODE_SRS; 
            break;
        default: 
            uiUtForHalMode =    UT_MODE_OFF; 
            break;
        break; 
    }

    return uiUtForHalMode; 
}
/* Ended by AICoder, pid:027559dbc17874a1441c09753015862661f53fc4 */

/*****************************************************************************
 * 函数名称: BspIsUtdoaExit
 * 功能描述: 判断UTDOA是否存在
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspIsUtdoaExit(VOID)
{
    UINT32 exitFlagTmp = 0;
    UINT32 exitFlag = 0;

    /* Enable 是包含了三个载波的使能情况的掩码 */
    for (UINT32 carrLoop = 0; carrLoop < UTDOA_MAX_CARR_NUM; carrLoop++)
    {
        exitFlagTmp  |= (UINT32)s_pUtdoaAllCfg[carrLoop].UtdoaLargeSmallErgodicCfg.Enable;/* APP下来的是掩码。和孙晨确定。 uiEnable是透传过来的*/
    }

    if (0 != exitFlagTmp)
    {
        exitFlag = 1;
    }

    return exitFlag;
}

// 统计有效的UTDOA载波数量
// 删除等操作使得载波有变动后，APP会重新下发小区，则需要将 utCarrNumArr、utCarrNum 重新初始化
// 去使能一个载波后，则对应的有效载波数量要减1 
/* Started by AICoder, pid:p75adq5473be14b144f70999f0bd075c73c02539 */
UINT32 BspSetUtCarrNum(UINT32 carrNumber, UINT32 enable)
{
    UINT32 loop = 0;
    UINT32 tempIndex = UTDOA_MAX_CARR_NUM;
    UINT32 firstInvalidIndex = UTDOA_MAX_CARR_NUM;

    for (loop = 0; loop < UTDOA_MAX_CARR_NUM; loop++)
    {
        if ((UT_INVALID_CARR_NUMBER_FLAG == utCarrNumArr[loop]) && (firstInvalidIndex == UTDOA_MAX_CARR_NUM))
        {
            firstInvalidIndex = loop;
        }
        
        if (carrNumber == utCarrNumArr[loop])
        {
            tempIndex = loop;
            break;
        }
    }
    
    BspLog(LOG_LEVEL_0,"%s >>>tempIndex:%d firstInvalidIndex:%d utCarrNum:%d\n",\
           __FUNCTION__,tempIndex, firstInvalidIndex, utCarrNum); // 记录下发参数的次数

    if (tempIndex != UTDOA_MAX_CARR_NUM) 
    {
        if (BSP_UTDOA_MODE_OFF == enable)
        {
            utCarrNumArr[tempIndex] = UT_INVALID_CARR_NUMBER_FLAG;
            if (0 == utCarrNum)
            {
                return BSP_ERROR;
            }
            
            utCarrNum--;
            return BSP_OK;
        }
    }
    else
    {
        if ((UTDOA_MAX_CARR_NUM != firstInvalidIndex) && (BSP_UTDOA_MODE_OFF != enable))
        {
            utCarrNumArr[firstInvalidIndex] = carrNumber;
            utCarrNum++;
            return BSP_OK;
        }
        return BSP_ERROR;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:p75adq5473be14b144f70999f0bd075c73c02539 */

/* Started by AICoder, pid:z68ad7ef24p04d5149520b9f709b382cf686c5b6 */
/* 给app封装的接口:IO使能 20240802会议：放到BSP做吧*/
/* ZHY:互斥代码，先注释掉 */
UINT32 BspSetUtIoEn(UINT32 bspChan, UINT32 dir, UINT32 en)
{
    UINT32 retVal = BSP_OK;

    // 开的时候不做互斥判断
    if (0 != en)
    {
        retVal = (TX == dir) ? BspHalAdaptUtDlIoEn(bspChan,en):BspHalAdaptUtUlIoEn(bspChan,en);
        dbgInfoEx("%s>> open IO en retVal:%d\n", __FUNCTION__,retVal);
        return retVal;
    }
    else
    {
        // 不能采用信号量的方式，假设DMM关闭了，信号量变成1（剩下UT还在使能），
        // 那么DMM如果再次调用关闭接口，判断信号量为1就会关闭IO，但实际上UT还在使能
        // 可能会出现这种情况，可能。因此不采用信号量的方式。
        if (DMM_UT_PUBLIC_EN_OFF == BspGetDmmIoEnVar()) //发现Dmm不再使能，这时才能关闭IO使能
        {
            retVal = (TX == dir) ? BspHalAdaptUtDlIoEn(bspChan,en):BspHalAdaptUtUlIoEn(bspChan,en);
            dbgInfoEx("%s>> close IO en and DMM not enable !retVal:%d\n", __FUNCTION__,retVal);
            return retVal;
        }
    }

    return BSP_ERROR;
} 
/* Ended by AICoder, pid:z68ad7ef24p04d5149520b9f709b382cf686c5b6 */

/* Started by AICoder, pid:8968ara54b3ecff14f1f0a85e049532add03be0c */
/* 中频使能接口 */
UINT32 BspSetUtdoaEnForHal(UINT32 en, UINT32 chan, UINT32 carrNo, UINT32 radio, UINT32 halMode)
{
    UINT32 retVal = BSP_OK; 
    UINT32 enFlag = (UT_MODE_SRS == halMode) ? !en : en; // SRS模式下，中频AacEn使能与非SRS模式使能相反
    
    retVal |= BspHalAdaptUtSendAacEn(chan,carrNo,radio,enFlag);
    retVal |= BspHalAdaptUtSampleEn(chan,carrNo,radio,en);
    retVal |= BspHalAdaptUtInsertAacEn(chan,carrNo,radio,en);
    // retVal |= BspSetUtIoEn(chan, TX, en);
    // retVal |= BspSetUtIoEn(chan, RX, en); ZHY:互斥代码，先注释掉
    retVal |= BspHalAdaptUtDlIoEn(chan, UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
    retVal |= BspHalAdaptUtUlIoEn(chan, UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。

    // if (!((DMM_UT_PUBLIC_EN_ON == BspGetDmmIoEnVar()) && (0 == en))) // DMM存在，且下发的是去使能，进不去这个分支
    // { ZHY:互斥代码先注释掉，后续放开
        // retVal |= BspHalAdaptSetDlGpEn(chan, radio,carrNo, en); // GP使能接口
    // }
  
    dbgInfoEx("%s : en:%d chan:%d carrNo:%d radio:%d retVal:%d \n",__FUNCTION__,en, chan,carrNo,radio,retVal);
    return retVal;
}
/* Ended by AICoder, pid:8968ara54b3ecff14f1f0a85e049532add03be0c */

UINT32 BspSetUtdoaEnForHalByChanMask(UINT32 en, UINT32 carrNo, UINT32 radio, UINT32 chanMask, UINT32 halMode)
{
    UINT32 retVal = BSP_OK;
    UINT32 chanLoop = 0;

    for (chanLoop = 0; chanLoop < QCELL_UTDOA_MAX_CHAN_NUM; chanLoop++) // ulChanMask 一共32bit，最大循环到31
    {
        if(chanMask & (0x1 << chanLoop))
        {
            retVal |= BspSetUtdoaEnForHal(en, chanLoop, carrNo, radio, halMode);
            dbgInfoEx("%s :chan-> %d \n",__FUNCTION__,chanLoop);
        }
    }   
    
    return retVal;
}

/* Started by AICoder, pid:8f296kf33364700149bb0abe606efe143df62b11 */
/*****************************************************************************
 * 函数名称: BspSetUtdoaDlDtxPaAndAmpGpSel
 * 功能描述: 做dmimo时要打开对应的GP不能做DTX节能
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUtdoaDlDtxPaAndAmpGpSel(UINT32 ulChanMask,UINT32 uiSwitch)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 uiChanLoop = 0;
    UINT32 uiTddCfgId = 0;  

    if(1 == uiSwitch)
    {
         uiTddCfgId = BspGetTddCfgIdByChanMask(ulChanMask);
         uiTddCfgId = uiTddCfgId+1;/*和红平确认tdd套数从1开始*/
    }
    else
    {
    	uiTddCfgId = 9;
    }

    dbgInfoEx("%s>>  ulChanMask:%d, uiTddCfgId:%d\n", __FUNCTION__,  ulChanMask, uiTddCfgId);
    for (uiChanLoop = 0; uiChanLoop < QCELL_UTDOA_MAX_CHAN_NUM; uiChanLoop++) // ulChanMask 一共32bit，最大循环到31
    {
    	if(ulChanMask & (0x1 << uiChanLoop))
    	{
    	    dbgInfoEx("%s>> uiChanLoop:%d, uiTddCfgId:%d\n", __FUNCTION__, uiChanLoop, uiTddCfgId);
    		ulRetVal = BspHalAdaptSetDlDtxPaGpSel(uiChanLoop,uiTddCfgId);
    		ulRetVal = BspHalAdaptSetDlDtxAmpGpSel(uiChanLoop,uiTddCfgId);
    	}
    }   
    return ulRetVal;
}
/* Ended by AICoder, pid:8f296kf33364700149bb0abe606efe143df62b11 */

/* Started by AICoder, pid:c7d18i34a8z22941465f0baf6012a60ae4999c6b */
/*****************************************************************************
 * 函数名称: BspSetDlTimingDlTddDlyDisable
 * 功能描述:清除 2us 使能
 * 输入参数:
 * 输出参数: 载波存储序号
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUtdoaDlTimingDlTddDlyClean(UINT32 uiChanMask)
{
    UINT32 uiLoop =0;
    for(uiLoop =0 ;uiLoop<QCELL_UTDOA_MAX_CHAN_NUM;uiLoop++)
    {
        if(uiChanMask & ((UINT32)0x1 << uiLoop))
        {
            BspHalAdaptSetDlTimingDlTddDly(uiLoop,0);
        }
    }
    return BSP_OK ;
}
/* Ended by AICoder, pid:c7d18i34a8z22941465f0baf6012a60ae4999c6b */

/*****************************************************************************
 * 函数名称: BspSaveUtdoaAacDate
 * 功能描述: 保存AAC 序列数据
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSaveUtdoaAacDate_TNR(VOID)
{

	UINT32 ulRadioStand =0;
	UINT32 ulAntNum =0;
    for(ulRadioStand = 0;ulRadioStand < MAX_RADIO_NUM;ulRadioStand++)
    {
    	switch(ulRadioStand)
    	{
            case TNR_BAND_TYPE_100M:
	        s_PCpg_Aac_Param[TNR_BAND_TYPE_100M].ulBandWidth = BANDWIDTH_100M;
	        s_PCpg_Aac_Param[TNR_BAND_TYPE_100M].ulRadioStd= RADIO_STANDARD_5G;
            for(ulAntNum=0;ulAntNum<MAX_AAC_ANT_NUM;ulAntNum++)
            {
                memcpy_s(&s_PCpg_Aac_Param[TNR_BAND_TYPE_100M].CptAacDate[ulAntNum].AacCpgAntDate[0],sizeof(T_CPG_AacType),AacCpgAntDate_100M + ulAntNum,sizeof(T_CPG_AacType));
    	    }
            break;
            case TNR_BAND_TYPE_80M:
    	    s_PCpg_Aac_Param[TNR_BAND_TYPE_80M].ulBandWidth = BANDWIDTH_80M;
    	    s_PCpg_Aac_Param[TNR_BAND_TYPE_80M].ulRadioStd= RADIO_STANDARD_5G;
            for(ulAntNum=0;ulAntNum<MAX_AAC_ANT_NUM;ulAntNum++)
            {
                    memcpy_s(&s_PCpg_Aac_Param[TNR_BAND_TYPE_80M].CptAacDate[ulAntNum].AacCpgAntDate[0],sizeof(T_CPG_AacType),AacCpgAntDate_80M + ulAntNum,sizeof(T_CPG_AacType));
            }
            break;
            case TNR_BAND_TYPE_60M:
    	    s_PCpg_Aac_Param[TNR_BAND_TYPE_60M].ulBandWidth = BANDWIDTH_60M;
    	    s_PCpg_Aac_Param[TNR_BAND_TYPE_60M].ulRadioStd= RADIO_STANDARD_5G;
            for(ulAntNum=0;ulAntNum<MAX_AAC_ANT_NUM;ulAntNum++)
            {
                    memcpy_s(&s_PCpg_Aac_Param[TNR_BAND_TYPE_60M].CptAacDate[ulAntNum].AacCpgAntDate[0],sizeof(T_CPG_AacType),AacCpgAntDate_60M + ulAntNum,sizeof(T_CPG_AacType));
            }
            break;
            default:
            break;
    	}
    }
    return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspGetUtdoaChanLoop
 * 功能描述: 获取AAC 序列通道序号。如 chanmask为 0011 1100（0x3c），而 s_PCpg_Aac_Param 中的UTDOA保存了4个通道的AAC数据（通道从0~4），
 *          而改函数的作用就是将 chanmask和0~4 一一对应起来的。
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetUtdoaChanLoop(UINT32  uiDifChan, UINT32  uiChanMask)
{
	UINT32 uiloop = 0;
	UINT32 uiMinimumChan = 0;
	UINT32 txChnNum = BspGetTxChannel();

    for(uiloop = 0; uiloop < txChnNum; uiloop++)
    {
        if((uiChanMask & ((UINT32)0x1 << uiloop)) !=0)
        {
        	if(uiDifChan  == uiloop)
        	{
        		return uiMinimumChan;
        	}
        	uiMinimumChan ++;

        }
    }

    return BSP_ERROR;
}
/*****************************************************************************
 * 函数名称: BspGetUtdoaAacDate
 * 功能描述: 获取AAC 序列数据
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetUtdoaAacDate(UINT32 uiDifChan, UINT32  uiChanMask,UINT32  uiCarrBandWidth,UINT32 ulRadioStand, UINT32 puiAcBaseSeque[1024])
{
	UINT32 uiRadioloop = 0;
	UINT32 uiDifChanloop = 0 ;

	uiDifChanloop = BspGetUtdoaChanLoop(uiDifChan,uiChanMask);

	if(BSP_ERROR == uiDifChanloop)
	{
	    return BSP_OK;
	}

	for(uiRadioloop =0 ;uiRadioloop < MAX_RADIO_NUM ;uiRadioloop++)
	{
		if( (ulRadioStand == s_PCpg_Aac_Param[uiRadioloop].ulRadioStd)  && (uiCarrBandWidth == s_PCpg_Aac_Param[uiRadioloop].ulBandWidth) )
		{
			  memcpy_s(&puiAcBaseSeque[0],sizeof(T_CPG_AacType),&s_PCpg_Aac_Param[uiRadioloop].CptAacDate[uiDifChanloop].AacCpgAntDate[0],sizeof(T_CPG_AacType));
		}
	}

    return BSP_OK;
}

/* Started by AICoder, pid:m8efam2dc3h06351486f096a2057fd22f528852c */
UINT32 BspSetUtAacGain(UINT32 difChan, UINT32 chanMask, UINT32 radioMode, UINT32 utCarrValidNum, UINT32 halMode)
{
    UINT32 difChanloop = 0 ;
    UINT32 tmpCarrloop = 0 ;
    UINT32 ret = BSP_OK;
    T_BspHalAdaptUtAacGainArray tempGain = {0};
    difChanloop = BspGetUtdoaChanLoop(difChan,chanMask);

    BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK_UTDOA(difChanloop, MAX_AAC_ANT_NUM);

    /*DMM和UT共存情况下，UT直接使用DMM大遍历结果。与中频确认，UT小遍历场景下也需要配置AAC增益*/
    if ((UT_MODE_GROUP != halMode) && (UT_MODE_CALI != halMode))
    {
        return BSP_OK;
    }
    
    
    if (1 >= utCarrValidNum)
    {
        memcpy_s(&tempGain,sizeof(T_BspHalAdaptUtAacGainArray),&r2rSingleUtCarr[difChanloop],sizeof(T_BspHalAdaptUtAacGainArray));
    }
    else
    {
        memcpy_s(&tempGain,sizeof(T_BspHalAdaptUtAacGainArray),&r2rMultiUtCarr[difChanloop],sizeof(T_BspHalAdaptUtAacGainArray));
    }

    for (tmpCarrloop = 0; tmpCarrloop < UTDOA_MAX_CARR_NUM; tmpCarrloop++)
    {
        if (UT_INVALID_CARR_NUMBER_FLAG == utCarrNumArr[tmpCarrloop])
        {
            continue;
        }
        
        ret |= BspHalAdaptSetUtSendAacGain(difChan, utCarrNumArr[tmpCarrloop], radioMode, &tempGain);
        dbgInfoEx("%s>> tmpCarrloop[%d]: ret:%d \n", __FUNCTION__, tmpCarrloop, ret);
    }
    
    return ret;
}
/* Ended by AICoder, pid:m8efam2dc3h06351486f096a2057fd22f528852c */

/* Started by AICoder, pid:t8e4apb03e077ea14bc208b8e0a77c2b7bf012a8 */
UINT32 printaacDate(UINT32 ulRadioStand)
{
	UINT32 iloop = 0;
	UINT32 iLoop = 0;

	dbgInfo("ulRadioStand:%x",ulRadioStand);
	for(iloop =0;iloop < MAX_AAC_ANT_NUM;iloop++)
	{
        dbgInfo("ANT:%d ----------------------------------------------------------------- \n",iloop);  
		for(iLoop =0;iLoop < MAX_AAC_LUT_LEN_TMP;iLoop++)
		{
	        if (((0 == iLoop % 32)) && (0 != iLoop) )  
            {  
            	dbgInfo("\n");  
            } 
			ARR_BOUND_UTDOA(iLoop,MAX_AAC_LUT_LEN_TMP); 
			ARR_BOUND_UTDOA(ulRadioStand,MAX_RADIO_NUM); 
     		dbgInfo("%x ",s_PCpg_Aac_Param[ulRadioStand].CptAacDate[iloop].AacCpgAntDate[iLoop]);  
		}
		dbgInfo("\n");
	}
	return BSP_OK;
}
/* Ended by AICoder, pid:t8e4apb03e077ea14bc208b8e0a77c2b7bf012a8 */

/* Started by AICoder, pid:f8f30r7ce6c331914f8e092b9007a62ec6a14a56 */
/*****************************************************************************
 * 函数名称: BspSetUtdoaSrsFrameBitmapHandle
 * 功能描述: 保存处理过的SRS拍照帧bitmap参数配置信息
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUtdoaSrsSampleFrameBitmapHandle(UINT32 uiCarrLoop , UINT32 * ulFrameBitmap, UINT32 utForHalMode)
{
    UINT32 ulLoop = 0;
    UINT32 ulLoopStart = 0;
    UINT16 usSRSCaptureCycle = 0;
    UINT16 usAACFrameEnd = 0;
    BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);
    usSRSCaptureCycle = s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSCaptureCycle;
    usAACFrameEnd = s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACFrameEnd;

    if (UT_MODE_CALI == utForHalMode)
    {
        ulLoopStart = usAACFrameEnd + 1;//ZHY:注意这里看环境上的信息，usAACFrameEnd不是799，是小遍历结束的帧号
    }
    else if (UT_MODE_SRS == utForHalMode)
    {
        ulLoopStart = 0;
    }

    for(ulLoop = ulLoopStart; ulLoop< UTDOA_SENDRAM_LEN; ulLoop++)
    {
        if (0 == usSRSCaptureCycle)
        {
            return BSP_OK;
        }
        // if(ulLoop > usAACFrameEnd)// 假设是纯的SRS模式，这个边界条件是不是不对呢
        if( 0 == (ulLoop % usSRSCaptureCycle) )
        {
            ulFrameBitmap[ulLoop/UTDOA_BITMAP_WORD_LENGTH] = BIT_FIELD_MASK_CFG(ulFrameBitmap[ulLoop/UTDOA_BITMAP_WORD_LENGTH],1,(ulLoop % (UTDOA_SENDRAM_LEN/UTDOA_BITMAP_WORD_LENGTH)),1);/*清零 记录当前的小区*/
        }
        else
        {
            ulFrameBitmap[ulLoop/UTDOA_BITMAP_WORD_LENGTH] = BIT_FIELD_MASK_CFG(ulFrameBitmap[ulLoop/UTDOA_BITMAP_WORD_LENGTH],0,(ulLoop % (UTDOA_SENDRAM_LEN/UTDOA_BITMAP_WORD_LENGTH)),1);/*清零 记录当前的小区*/
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:f8f30r7ce6c331914f8e092b9007a62ec6a14a56 */

/*****************************************************************************
 * 函数名称: BspSetUtdoaSrsFrameBitmapHandle
 * 功能描述: 保存处理过的SRS回传帧bitmap参数配置信息
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUtdoaSrsReturnFrameBitmapHandle(UINT32 uiCarrLoop , UINT32 * ulFrameBitmap, UINT32 utForHalMode)
{
    UINT32 ulLoop = 0;
    UINT32 ulLoopStart = 0;
    UINT16 usSRSCaptureCycle = 0;
    UINT16 usAACFrameEnd = 0;
    UINT32 uiSRSReturnFrame = 0;
    UINT8  ucbit = 0;
    BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);
    usSRSCaptureCycle = s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSCaptureCycle;
    usAACFrameEnd = s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACFrameEnd;

    uiSRSReturnFrame = s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSReturnFrame;

    if (UT_MODE_CALI == utForHalMode)
    {
        ulLoopStart = usAACFrameEnd + 1;
    }
    else if (UT_MODE_SRS == utForHalMode)
    {
        ulLoopStart = 0;
    }

    if (0 == usSRSCaptureCycle)
    {
        return BSP_OK;
    }

    for(ulLoop = ulLoopStart; ulLoop< 1024; ulLoop++)
    {
        // if(ulLoop > usAACFrameEnd) 小遍历AAC超帧周期内，AAC已结束立刻进入SRS 状态 --此处当纯SRS模式时会存在边界条件不对的现象
        ucbit = BIT_FIELD_MASK_RIGHT_ALIGN(uiSRSReturnFrame, ulLoop % usSRSCaptureCycle, 1) ;
        ulFrameBitmap[ulLoop/32] = BIT_FIELD_MASK_CFG(ulFrameBitmap[ulLoop/32],ucbit,(ulLoop % 32),1);
    }

    return BSP_OK;
}


/* Started by AICoder, pid:h758fbae8055b561448609a2c0a7f53a9c121884 */
/*****************************************************************************
 * 函数名称: BspSetUtdoaFrameBitmapHandle
 * 功能描述: 保存处理过的帧bitmap参数配置信息
 * 输入参数:dealMode指的是发送（1）、拍照（2）、回传（3）
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUtdoaFrameBitmapHandle(UINT8  *ucFrameBitmap,UINT32 * ulFrameBitmap, UINT32 uiUtForHalMode, UINT32 dealMode, UINT32 carrLoop)
{
	UINT32 ulLoop = 0;
	UINT32 ucLoop = 0;

	for(ucLoop = 0; ucLoop< UTDOA_AAC_FRAME_NUM; ucLoop++)
	{
	    if(ucLoop != 0 && (ucLoop%4) == 0)
        {
            ulLoop = ulLoop+1;
        }
	    if(ulLoop >= UTDOA_BITMAP_WORD_LENGTH)
	    {
			dbgInfo("%s ulFrameBitmap Array Bound ",__FUNCTION__);
            break;
	    	// return BSP_OK;
	    }
	    dbgInfoEx("%s>> ucFrameBitmap[%d]: 0x%x \n", __FUNCTION__, ucLoop, ucFrameBitmap[ucLoop]);
	    ulFrameBitmap[ulLoop] = ulFrameBitmap[ulLoop] | (ucFrameBitmap[ucLoop] << ((ucLoop%4)*8));
	    dbgInfoEx("%s>> ulFrameBitmap[%d]: 0x%x \n", __FUNCTION__, ulLoop, ulFrameBitmap[ulLoop]);
	}

    // 小遍历模式下的SRS帧处理
    if (UT_MODE_CALI == uiUtForHalMode)
    {
                                            // SRS没有发送帧处理
        if (CAPTURE_MODE == dealMode)       // SRS拍照帧处理
        {
            BspSetUtdoaSrsSampleFrameBitmapHandle( carrLoop, ulFrameBitmap, uiUtForHalMode );
        }
        else if (INSERT_MODE == dealMode)   // SRS回插帧处理
        {
            BspSetUtdoaSrsReturnFrameBitmapHandle( carrLoop, ulFrameBitmap, uiUtForHalMode );
        }
    }
    
	return BSP_OK;
}
/* Ended by AICoder, pid:h758fbae8055b561448609a2c0a7f53a9c121884 */

/*****************************************************************************
 * 函数名称: BspGetUtdoaSlotMaxEndFrNum
 * 功能描述: 获取时隙分组信息中，最大的结束帧号
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetUtdoaSlotMaxEndFrNum(UINT32 uiCarrLoop)
{
	UINT32 ulLoop = 0;
	UINT32 srsSlotMaxEndFrNum = 0;
	ARR_BOUND_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);

	/* 为什么-1呢：因为八组起止帧，只用了7组给中频，最后一组没用，所以-1 */
	for(ulLoop = 0; ulLoop< (UTDOA_AAC_GROUP_NUM-1); ulLoop++)
	{
		ARR_BOUND_UTDOA(ulLoop,UTDOA_AAC_GROUP_NUM);
        if( srsSlotMaxEndFrNum < s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[ulLoop])/* ZHY：AAC超帧周期内，AAC已结束立刻进入SRS 状态 ？ 此函数是改变状态的？ */
        {
			ARR_BOUND_UTDOA(ulLoop,UTDOA_AAC_GROUP_NUM);
        	srsSlotMaxEndFrNum = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[ulLoop];
        }
	}

	return srsSlotMaxEndFrNum;
}


/*****************************************************************************
 * 函数名称: BspHandleUtdoaSlotInfoCfgForHalCfg
 * 功能描述: 拍照时隙bitmap处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 拍照时隙bitmap处理，app的时隙数组，复用八次给中频即可
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleUtdoaCaptureSlotInfoCfgForHalCfg(UINT32 uiCarrLoop, T_UtParaUint *UtParaUint, UCHAR *aacTimeSlot, UCHAR *rttTimeSlot, UCHAR *srsTimeSlot, UINT32 uiUtForHalMode)
{
	UINT32 ulSlotIndex = 1;
	UCHAR *rttTimeSlot_Temp = rttTimeSlot;
	UCHAR *aacTimeSlot_Temp = aacTimeSlot;
	UCHAR *srsTimeSlot_Temp = srsTimeSlot;

	INPUT_POINTER_CHECK_UTDOA(UtParaUint,      BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(rttTimeSlot_Temp,BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(aacTimeSlot_Temp,BSP_ERROR);
	ARR_BOUND_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);

	/* 大遍历模式：将起止帧、时隙、符号 放到 1+7+1 中的数组0 */
	if (UT_MODE_GROUP == uiUtForHalMode)
	{
		// for (UINT32 i = 0; i < UTDOA_AAC_GROUP_NUM; i++)/* 大遍历放到0位置就行了，为啥要循环呢？ */
		// {
		// 	ARR_BOUND_UTDOA(i,        UTDOA_AAC_GROUP_NUM);
		// 	if (/* (0 != s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[i]) || */ (0 != s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[i]) )
		// 	{
				UtParaUint->uiSlotInfo[0].uiStartFrNo  = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[0];
				UtParaUint->uiSlotInfo[0].uiEndFrNo    = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[0];
				UtParaUint->uiSlotInfo[0].uiSlotBitmap = (UINT32)( aacTimeSlot_Temp[0] | (aacTimeSlot_Temp[1] << 8) | ((aacTimeSlot_Temp[2] & 0x0F) << 16) );
				dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiStartFrNo );
    			dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiEndFrNo   );
    			dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiSlotBitmap);
		// 		return BSP_OK;
		// 	}	
		// }
		return BSP_OK;
	}

    /* uiSlotInfo共有9组，和中频规定：第一组存放Rtt信息，后8组存放时隙信息。且时隙bitmap只取时隙信息中的前三个UCHAR即可 */
	UtParaUint->uiSlotInfo[0].uiStartFrNo  = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.RttStartFrame;
	UtParaUint->uiSlotInfo[0].uiEndFrNo    = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.RttEndFrame;
	UtParaUint->uiSlotInfo[0].uiSlotBitmap = (UINT32)( rttTimeSlot_Temp[0] | (rttTimeSlot_Temp[1] << 8) | ((rttTimeSlot_Temp[2] & 0x0F) << 16) );
	dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiStartFrNo );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiEndFrNo   );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiSlotBitmap);
 	
	for(UINT32 ucLoop = 0; ucLoop < (UTDOA_AAC_GROUP_NUM-1); ucLoop++)
	{
		if(ulSlotIndex > (UTDOA_AAC_GROUP_NUM-1))
		{
	        dbgErr("%s>> ulSlotIndex=%u is biger than UTDOA_AAC_GROUP_NUM !!! \n", __FUNCTION__, ulSlotIndex);
			return BSP_OK;
		}
        
		ARR_BOUND_UTDOA(ulSlotIndex,UT_MAX_FRAME_SECTION_NUM);
		UtParaUint->uiSlotInfo[ulSlotIndex].uiStartFrNo  = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[ulSlotIndex-1];
		UtParaUint->uiSlotInfo[ulSlotIndex].uiEndFrNo    = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[ulSlotIndex-1];
        if (0 != UtParaUint->uiSlotInfo[ulSlotIndex].uiEndFrNo)
        {
            UtParaUint->uiSlotInfo[ulSlotIndex].uiSlotBitmap = (UINT32)( aacTimeSlot_Temp[0] | (aacTimeSlot_Temp[1] << 8) | ((aacTimeSlot_Temp[2] & 0x0F) << 16) );
        }

        dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[ulSlotIndex].uiStartFrNo );
        dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[ulSlotIndex].uiEndFrNo   );
        dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[ulSlotIndex].uiSlotBitmap);
        ulSlotIndex = ulSlotIndex+1;
	}

	/* srs定位信息没有发送时隙，如果传过来为NULL，则可以认为是发送 */
	INPUT_POINTER_CHECK_UTDOA(srsTimeSlot_Temp,BSP_OK);

	/* 最后一组存放SRS时隙信息：SRS的起始帧号是时隙结束的帧号，SRS的结束帧号是1023 */
	ARR_BOUND_UTDOA(UT_MAX_FRAME_SECTION_NUM-1,UT_MAX_FRAME_SECTION_NUM);
	UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiStartFrNo  = BspGetUtdoaSlotMaxEndFrNum(uiCarrLoop) + 1;
	UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiEndFrNo    = 1023;
	UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiSlotBitmap = (UINT32)( srsTimeSlot_Temp[0] | (srsTimeSlot_Temp[1] << 8) | ((srsTimeSlot_Temp[2] & 0x0F) << 16) );
	dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiStartFrNo );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiEndFrNo   );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiSlotBitmap);

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspHandleUtdoaSlotInfoCfgForHalCfg
 * 功能描述: 回插时隙bitmap处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 回插和发送是将APP的回插AAC时隙（共160个CHAR），分成八组给中频
 *          ZHY：存在一些疑问：BBU的发送时隙是将160个char分成八组（每20个char一组），而系统方案表明将160个char复用八次
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleUtdoaSendAndReturnSlotInfoCfgForHalCfg(UINT32 uiCarrLoop, T_UtParaUint *UtParaUint, UCHAR *aacTimeSlot, UCHAR *rttTimeSlot, UCHAR *srsTimeSlot, UINT32 uiUtForHalMode)
{
	UINT32 ulSlotIndex = 1;
	UCHAR *rttTimeSlot_Temp = rttTimeSlot;
	UCHAR *aacTimeSlot_Temp = aacTimeSlot;
	UCHAR *srsTimeSlot_Temp = srsTimeSlot;

	INPUT_POINTER_CHECK_UTDOA(UtParaUint,      BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(rttTimeSlot_Temp,BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(aacTimeSlot_Temp,BSP_ERROR);
	ARR_BOUND_UTDOA(uiCarrLoop,       UTDOA_MAX_CARR_NUM);

	/* 大遍历模式：将起止帧、时隙、符号 放到 1+7+1 中的数组0 */
	if (UT_MODE_GROUP == uiUtForHalMode)
	{
		// for (UINT32 i = 0; i < UTDOA_AAC_GROUP_NUM; i++)
		// {
		// 	ARR_BOUND_UTDOA(i,UTDOA_AAC_GROUP_NUM);
		// 	if ((0 != s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[i]) || (0 != s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[i]) )
		// 	{
				UtParaUint->uiSlotInfo[0].uiStartFrNo  = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[0];
				UtParaUint->uiSlotInfo[0].uiEndFrNo    = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[0];
				UtParaUint->uiSlotInfo[0].uiSlotBitmap = (UINT32)( aacTimeSlot_Temp[0] | (aacTimeSlot_Temp[1] << 8) | ((aacTimeSlot_Temp[2] & 0x0F) << 16) );
				dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiStartFrNo );
    			dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiEndFrNo   );
    			dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiSlotBitmap);
		// 		return BSP_OK;
		// 	}	
		// }
		return BSP_OK;
	}
	
    /* 1+7+1 ：第一组存放Rtt信息，且时隙bitmap只取时隙信息中的前三个UCHAR即可 */
	UtParaUint->uiSlotInfo[0].uiStartFrNo  = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.RttStartFrame;
	UtParaUint->uiSlotInfo[0].uiEndFrNo    = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.RttEndFrame;
	UtParaUint->uiSlotInfo[0].uiSlotBitmap = (UINT32)( rttTimeSlot_Temp[0] | (rttTimeSlot_Temp[1] << 8) | ((rttTimeSlot_Temp[2] & 0x0F) << 16) );
	dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiStartFrNo );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiEndFrNo   );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiSlotBitmap);
 	
	/* 后7组存放时隙信息 */
	for(UINT32 ucLoop = 0; ucLoop < (UTDOA_SEND_TIME_SLOT_NUM-20); ucLoop = ucLoop+20)
	{
		if(ulSlotIndex > (UTDOA_AAC_GROUP_NUM-1))
		{
	        dbgErr("%s>> ulSlotIndex is biger than UTDOA_AAC_GROUP_NUM !!! ulSlotIndex:%d \n", __FUNCTION__, ulSlotIndex);
			return BSP_OK;
		}
        
		UtParaUint->uiSlotInfo[ulSlotIndex].uiStartFrNo  = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[ulSlotIndex-1];
		UtParaUint->uiSlotInfo[ulSlotIndex].uiEndFrNo    = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[ulSlotIndex-1];
        UtParaUint->uiSlotInfo[ulSlotIndex].uiSlotBitmap = (UINT32)( aacTimeSlot_Temp[ucLoop] | (aacTimeSlot_Temp[ucLoop+1] << 8) | ((aacTimeSlot_Temp[ucLoop+2] & 0x0F) << 16) );

        dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[ulSlotIndex].uiStartFrNo );
        dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[ulSlotIndex].uiEndFrNo   );
        dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[ulSlotIndex].uiSlotBitmap);
        ulSlotIndex = ulSlotIndex+1;
	}

	/* srs定位信息没有发送时隙，如果传过来为NULL，则可以认为是发送 */
	INPUT_POINTER_CHECK_UTDOA(srsTimeSlot_Temp,BSP_OK);

	/* 最后一组存放SRS时隙信息：SRS的起始帧号是时隙结束的帧号，SRS的结束帧号是1023 */
	ARR_BOUND_UTDOA(UT_MAX_FRAME_SECTION_NUM-1,UT_MAX_FRAME_SECTION_NUM);
	UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiStartFrNo  = BspGetUtdoaSlotMaxEndFrNum(uiCarrLoop) + 1;
	UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiEndFrNo    = 1023;
	UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiSlotBitmap = (UINT32)( srsTimeSlot_Temp[0] | (srsTimeSlot_Temp[1] << 8) | ((srsTimeSlot_Temp[2] & 0x0F) << 16) );
	dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiStartFrNo );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiEndFrNo   );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, ulSlotIndex, UtParaUint->uiSlotInfo[UT_MAX_FRAME_SECTION_NUM-1].uiSlotBitmap);

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspHandleUtdoaSrsSlotInfoCfgForHalCfg
 * 功能描述: SRS定位模式下，拍照和回传时隙bitmap处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 和中频约定，纯SRS模式下，将SRS的时隙bitmap放在 1+7+1 时隙数组中的0位置，即取代RTT的位置。
 * 			后八个（7+1）位置清零即可，中频在纯SRS模式下，只取0位置的时隙数据。
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleUtdoaSrsSlotInfoCfgForHalCfg(T_UtParaUint *UtParaUint, UCHAR *srsTimeSlot)
{
	UCHAR *srsTimeSlot_Temp = srsTimeSlot; 

	INPUT_POINTER_CHECK_UTDOA(UtParaUint,      BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(srsTimeSlot_Temp,BSP_ERROR);

	memset_s( &UtParaUint->uiSlotInfo[0], UT_MAX_FRAME_SECTION_NUM*sizeof(T_UtSlotInfo), 0, UT_MAX_FRAME_SECTION_NUM*sizeof(T_UtSlotInfo) );

	UtParaUint->uiSlotInfo[0].uiStartFrNo  = 0;
	UtParaUint->uiSlotInfo[0].uiEndFrNo    = 1023;
	UtParaUint->uiSlotInfo[0].uiSlotBitmap = (UINT32)( srsTimeSlot_Temp[0] | (srsTimeSlot_Temp[1] << 8) | ((srsTimeSlot_Temp[2] & 0x0F) << 16) );
	dbgInfoEx("%s>> uiSlotInfo[%d].uiStartFrNo: %d \n",    __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiStartFrNo );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiEndFrNo: %d \n",      __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiEndFrNo   );
    dbgInfoEx("%s>> uiSlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, 0, UtParaUint->uiSlotInfo[0].uiSlotBitmap);

	return BSP_OK;	
}

/*****************************************************************************
 * 函数名称: BspHandleUtdoaSendAndCaptureSymInfoCfgForHalCfg
 * 功能描述: 符号处理，针对发送和拍照
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 大遍历 放到数组 0 的位置。小遍历采用 1+7+1
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleUtdoaSendAndCaptureSymInfoCfgForHalCfg(UINT32 carrLoop, T_UtParaUint *UtParaUint, USHORT *aacSym, USHORT *rttSym , USHORT *srsSym ,UINT32 uiUtForHalMode)
{
	UINT32 index = 1;

	INPUT_POINTER_CHECK_UTDOA(UtParaUint,BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(aacSym,    BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(rttSym,    BSP_ERROR);
	
	/* 大遍历：将符号放到数组 0 的位置 */
	if (UT_MODE_GROUP == uiUtForHalMode)
	{
		UtParaUint->uiSymBitmap[0] = (UINT32)(*aacSym);
		dbgInfoEx("%s>> uiUtForHalMode: %d  uiSymBitmap: %d \n",   __FUNCTION__, uiUtForHalMode, UtParaUint->uiSymBitmap[0]);
		return BSP_OK;
	}

	/* 小遍历：采用 1+7+1           */
	UtParaUint->uiSymBitmap[0] = (UINT32)(*rttSym);
	for (UINT32 i = 0; i < (UTDOA_AAC_GROUP_NUM-1); i++)
	{
        if (0 != (UINT32)s_pUtdoaAllCfg[carrLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[i])
        {
            ARR_BOUND_UTDOA(index,UT_MAX_FRAME_SECTION_NUM);
            UtParaUint->uiSymBitmap[index] = (UINT32)(*aacSym); 
        }
        dbgInfoEx("%s>> uiUtForHalMode: %d  uiSymBitmap: %d \n",   __FUNCTION__, uiUtForHalMode, UtParaUint->uiSymBitmap[index]);
        index++;
	}
	
	/* srs定位信息没有发送符号，如果传过来为NULL，则可以认为是发送 */
	INPUT_POINTER_CHECK_UTDOA(srsSym,BSP_OK);
	ARR_BOUND_UTDOA(UT_MAX_FRAME_SECTION_NUM-1,UT_MAX_FRAME_SECTION_NUM);
	UtParaUint->uiSymBitmap[UT_MAX_FRAME_SECTION_NUM-1] = (UINT32)(*srsSym);
	dbgInfoEx("%s>> uiUtForHalMode: %d  uiSymBitmap: %d \n",   __FUNCTION__, uiUtForHalMode, UtParaUint->uiSymBitmap[UT_MAX_FRAME_SECTION_NUM-1]);

	return BSP_OK;	
}

/*****************************************************************************
 * 函数名称: BspHandleUtdoaReturnSymInfoCfgForHalCfg
 * 功能描述: 大遍历和小遍历：符号处理，针对回传
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 大遍历 放到数组 0 的位置。小遍历采用 1+7+1
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleUtdoaReturnSymInfoCfgForHalCfg(T_UtParaUint *UtParaUint, USHORT *aacSym, USHORT *rttSym , USHORT *srsSym ,UINT32 uiUtForHalMode)
{
	UINT32 index = 1;

	INPUT_POINTER_CHECK_UTDOA(UtParaUint,BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(aacSym,    BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(rttSym,    BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(srsSym,    BSP_ERROR);
	
	/* 大遍历：将符号放到数组 0 的位置 */
	if (UT_MODE_GROUP == uiUtForHalMode)
	{
		UtParaUint->uiSymBitmap[0] = (UINT32)(aacSym[0]);
		dbgInfoEx("%s>> uiUtForHalMode: %d  uiSymBitmap: %d \n",   __FUNCTION__, uiUtForHalMode, UtParaUint->uiSymBitmap[0]);
		return BSP_OK;
	}

	/* 小遍历：采用 1+7+1           */
	UtParaUint->uiSymBitmap[0] = (UINT32)(*rttSym);
	for (UINT32 i = 0; i < (UTDOA_AAC_GROUP_NUM-1); i++)
	{
		ARR_BOUND_UTDOA(index,UT_MAX_FRAME_SECTION_NUM);
		UtParaUint->uiSymBitmap[index] = (UINT32)(aacSym[i]); 
		dbgInfoEx("%s>> uiUtForHalMode: %d  uiSymBitmap: %d \n",   __FUNCTION__, uiUtForHalMode, UtParaUint->uiSymBitmap[index]);
		index++;
	}
	
	/* srs定位信息没有发送符号，如果传过来为NULL，则可以认为是发送 */
	ARR_BOUND_UTDOA(UT_MAX_FRAME_SECTION_NUM-1,UT_MAX_FRAME_SECTION_NUM);
	UtParaUint->uiSymBitmap[UT_MAX_FRAME_SECTION_NUM-1] = (UINT32)(*srsSym);
	dbgInfoEx("%s>> uiUtForHalMode: %d  uiSymBitmap: %d \n",   __FUNCTION__, uiUtForHalMode, UtParaUint->uiSymBitmap[UT_MAX_FRAME_SECTION_NUM-1]);

	return BSP_OK;	
}

/*****************************************************************************
 * 函数名称: BspHandleUtdoaCaptureAndReturnSrsSymInfoCfgForHalCfg
 * 功能描述: SRS：符号处理，针对拍照和回传
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 大遍历 放到数组 0 的位置。小遍历采用 1+7+1
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleUtdoaCaptureAndReturnSrsSymInfoCfgForHalCfg(T_UtParaUint *UtParaUint, USHORT *srsSym)
{

	INPUT_POINTER_CHECK_UTDOA(UtParaUint,BSP_ERROR);
	INPUT_POINTER_CHECK_UTDOA(srsSym,    BSP_ERROR);

	UtParaUint->uiSymBitmap[0] = (UINT32)(*srsSym);
	
	return BSP_OK;	
}

/*****************************************************************************
 * 函数名称: BspSaveDataUtForHal
 * 功能描述: 保存处理完成后的给中频的 发送、拍照和回传数据 数据。以便维测
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSaveDataUtForHal(T_BspHalAdaptUtSendParaCfg *sendData, T_BspHalAdaptUtSampleParaCfg *captureData, T_BspHalAdaptUtInsertParaCfg *returnData, UINT32 uiCarrLoop, UINT32 uiUtForHalMode)
{
	ARR_BOUND_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);
    ARR_BOUND_UTDOA_FOR_HAL(uiUtForHalMode,UT_VALIDMODE_NUM);
	memcpy_s(&(bspSaveDateUtSendParaCfg[uiCarrLoop].paraUnit[uiUtForHalMode]),  sizeof(T_BspHalAdaptUtParaUint),&(sendData->paraUnit[uiUtForHalMode]),sizeof(T_BspHalAdaptUtParaUint));
	memcpy_s(&(bspSaveDateUtSampleParaCfg[uiCarrLoop].paraUnit[uiUtForHalMode]),sizeof(T_BspHalAdaptUtParaUint),&(captureData->paraUnit[uiUtForHalMode]),sizeof(T_BspHalAdaptUtParaUint));
	memcpy_s(&(bspSaveDateUtInsertParaCfg[uiCarrLoop].paraUnit[uiUtForHalMode]),sizeof(T_BspHalAdaptUtParaUint),&(returnData->paraUnit[uiUtForHalMode]),sizeof(T_BspHalAdaptUtParaUint));

	return BSP_OK;
}


/*****************************************************************************
 * 函数名称: BspGetUtDlIoCfgUtdoa
 * 功能描述: 获取amp和pa的tddio管脚
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetUtDlIoCfgUtdoa(UINT32 uiDifChan,T_BspHalAdaptUtDlIoPara * pUtIo)
{
	UINT32 ulRetVal = BSP_OK;
	UINT32 uiTxen = 0;
	UINT32 uiTxPa = 0;
	ulRetVal |= BspGetTxEnIoInfoByRfChn(uiDifChan,LINK_TYPE_TX,&uiTxen);/*qcell将AMP当TXEN使用*/
	pUtIo->uiAmpIdx = uiTxen;

	ulRetVal |= BspGetPaIoInfoByRfChn(uiDifChan,LINK_TYPE_TX,&uiTxPa);
	pUtIo->uiPaIdx = uiTxPa;
    return ulRetVal;
}
/*****************************************************************************
 * 函数名称: BspGetUtUlIoCfgUtdoa
 * 功能描述: 获取rxen和lna的tddio管脚
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetUtUlIoCfgUtdoa(UINT32 uiDifChan,T_BspHalAdaptUtUlIoPara * pUtIo)
{
	UINT32 ulRetVal = BSP_OK;
	ulRetVal |=BspGetRxEnIoInfoByRfChn(uiDifChan,LINK_TYPE_RX,&pUtIo->uiRxenIdx);
	ulRetVal |=BspGetLnaIoInfoByRfChn(uiDifChan,LINK_TYPE_RX,&pUtIo->uiLnaIdx);
    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspSetPaPathCfgForHalUtdoa
 * 功能描述: Pa时序部分的处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 获取下行的 PA 和 AMP 对应的TDDIO管脚，获取上行的LNA 和 RXEN 对应的TDDIO管脚给中频
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPathCfgForHalUtdoa(UINT32 bspChan, UINT32 carrId, UINT32 radioMode, UINT32 Mode)
{
	UINT32 retVal = BSP_OK;

	T_BspHalAdaptUtDlIoPara  pUtDlIo = {0};
    T_BspHalAdaptUtUlIoPara  pUtUlIo = {0};
	
	retVal |= BspGetUtDlIoCfgUtdoa(bspChan,&pUtDlIo);
	retVal |= BspGetUtUlIoCfgUtdoa(bspChan,&pUtUlIo);
	
	pUtDlIo.uiAmpIdx = pUtDlIo.uiAmpIdx & 0xf;
	pUtDlIo.uiPaIdx = pUtDlIo.uiPaIdx & 0xf;
	pUtUlIo.uiLnaIdx = pUtUlIo.uiLnaIdx & 0xf;
	pUtUlIo.uiRxenIdx = pUtUlIo.uiRxenIdx &0xf;
    pUtUlIo.uiAcSwIdx = utAcIndexMap[bspChan].offset; // 中频处会根据偏移量，自动将寄存器偏移 offset*4 的量

	dbgInfoEx("%s>> bspChan:%d uiAmpIdx%d! uiPaIdx:%d  \n", __FUNCTION__,bspChan,pUtDlIo.uiAmpIdx,pUtDlIo.uiPaIdx  );
	dbgInfoEx("%s>> bspChan:%d uiLnaIdx%d! uiRxenIdx:%d uiRuiAcSwIdxxenIdx:%d\n", __FUNCTION__,bspChan,pUtUlIo.uiLnaIdx,pUtUlIo.uiRxenIdx,pUtUlIo.uiAcSwIdx);

	retVal |= BspHalAdaptUtDlIoCfg(bspChan, carrId, radioMode, Mode, &pUtDlIo);
	retVal |= BspHalAdaptUtUlIoCfg(bspChan, carrId, radioMode, Mode, &pUtUlIo);

	return retVal;
}
/*****************************************************************************
 * 函数名称: BspPrintDataDealForHalCode
 * 功能描述: 打印处理后的中频数据
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: uiUtForHalMode (0:largeGroup 1:clai 2:srs)  sendOrCapOrReturn (1:send 2:capture 3:return)
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspPrintDataDealForHalCode(T_UtParaUint *utInfo,UINT32 uiUtForHalMode, UINT32 sendOrCapOrReturn)
{

	dbgInfo("ZHY --------------> Hal Mode: %d  (0:largeGroup 1:clai 2:srs)  sendOrCapOrReturn: %d (1:send 2:capture 3:return)  <-------------- \n",uiUtForHalMode, sendOrCapOrReturn);

	dbgInfo("ZHY --------------------->  Fr bitmap info  <--------------------- \n");
	dbgInfo("uiFrNoBitmap: \n");
	for (UINT32 i = 0; i < UT_BITMAP_WORD_LENGTH; i++)
	{
		ARR_BOUND_UTDOA(i,UT_BITMAP_WORD_LENGTH);
		dbgInfo("0x%-8x ",utInfo->uiFrNoBitmap[i]);
	}
	dbgInfo("\n");

	dbgInfo("ZHY -----------------> slot and sym bitmap info <----------------- \n");
	for (UINT32 i = 0; i < UT_MAX_FRAME_SECTION_NUM; i++)
	{
		ARR_BOUND_UTDOA(i,UT_MAX_FRAME_SECTION_NUM);
		dbgInfo("Section %d : uiSlotBitmap:0x%-8x  uiSymBitmap:0x%-8x  uiStartFrNo:%d  uiEndFrNo:%d \n", i, utInfo->uiSlotInfo[i].uiSlotBitmap, utInfo->uiSymBitmap[i], utInfo->uiSlotInfo[i].uiStartFrNo, utInfo->uiSlotInfo[i].uiEndFrNo);
	}
	dbgInfo("\n");

	return BSP_OK;
}

/* Started by AICoder, pid:we9aak862dre1e7148d40856c0313449c45059f4 */
/*****************************************************************************
 * 函数名称: BspPrintSaveDataUtForHal
 * 功能描述: 打印保存下来的，已经处理好后给中频的数据
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspPrintSaveDataUtForHal(UINT32 carrLoop)
{

	dbgInfo("-----------------------------------> print save data for hal <----------------------------------- \n");

    dbgInfo("------------------------------------------------> carrLoop: %d <------------------------------------------------ \n",carrLoop);
    dbgInfo("------------------------------------------------> carrLoop: %d <------------------------------------------------ \n",carrLoop);
    dbgInfo("------------------------------------------------> carrLoop: %d <------------------------------------------------ \n",carrLoop);
    ARR_BOUND_UTDOA(carrLoop,UTDOA_MAX_CARR_NUM);
    BspPrintDataDealForHalCode(&bspSaveDateUtSendParaCfg[carrLoop].paraUnit[0],0,1  ); /* 发送的大遍历 */
    BspPrintDataDealForHalCode(&bspSaveDateUtSampleParaCfg[carrLoop].paraUnit[0],0,2); /* 拍照的大遍历 */
    BspPrintDataDealForHalCode(&bspSaveDateUtInsertParaCfg[carrLoop].paraUnit[0],0,3); /* 回传的大遍历 */

    BspPrintDataDealForHalCode(&bspSaveDateUtSendParaCfg[carrLoop].paraUnit[1],1,1  ); /* 发送的校准   */
    BspPrintDataDealForHalCode(&bspSaveDateUtSampleParaCfg[carrLoop].paraUnit[1],1,2); /* 拍照的校准   */
    BspPrintDataDealForHalCode(&bspSaveDateUtInsertParaCfg[carrLoop].paraUnit[1],1,3); /* 回传的校准   */

    BspPrintDataDealForHalCode(&bspSaveDateUtSendParaCfg[carrLoop].paraUnit[2],2,1  ); /* 发送的srs   */
    BspPrintDataDealForHalCode(&bspSaveDateUtSampleParaCfg[carrLoop].paraUnit[2],2,2); /* 拍照的srs   */
    BspPrintDataDealForHalCode(&bspSaveDateUtInsertParaCfg[carrLoop].paraUnit[2],2,3); /* 回传的srs   */	
	
	return BSP_OK;
}
/* Ended by AICoder, pid:we9aak862dre1e7148d40856c0313449c45059f4 */

UINT32 FOR_CIRCULATE_UTDOA_UCHAR(UCHAR *ppointer,UINT32 arrLen,UINT32 lineBreak) 
{                   	  
	for (UINT32 i = 0; i < arrLen; i++)					  				  	  
	{																	  	  
		if ((0 != lineBreak) && ( (0 != i) && (0 == (i % lineBreak)) ))	  	  
		{																  	  
			dbgInfo("\n");												  	  
		}	                 												  
		if (arrLen <= i)                                                      
        {                                                                     
			dbgErr("%s: arr bound !! i:%d  arrLen:%d",__FUNCTION__,i,arrLen); 
			return BSP_ERROR;                                             
        }    															  	  
		dbgInfo("0x%-2x ",(UINT32)(ppointer[i]));							  	  
	}	

	return BSP_OK;
}

UINT32 FOR_CIRCULATE_UTDOA_USHORT(USHORT *ppointer,UINT32 arrLen,UINT32 lineBreak) 
{                   	  
	for (UINT32 i = 0; i < arrLen; i++)					  				  	  
	{																	  	  
		if ((0 != lineBreak) && ( (0 != i) && (0 == (i % lineBreak)) ))	  	  
		{																  	  
			dbgInfo("\n");												  	  
		}	                 												  
		if (arrLen <= i)                                                      
        {                                                                     
                dbgErr("%s: arr bound !! i:%d  arrLen:%d",__FUNCTION__,i,arrLen); 
                return BSP_ERROR;                                             
        }    															  	  
		dbgInfo("0x%-4x ",(UINT32)(ppointer[i]));							  	  
	}	

	return BSP_OK;
}                                                                      

/* Started by AICoder, pid:t8e80s1ed6t7291141420804101b0e13ffa23a92 */
/* mode: 0(大遍历) 1(小遍历) 2(SRS) */
UINT32 BspPrintDataAppForBsp(UINT32 uiCarrLoop, UINT32 mode)
{

	ARR_BOUND_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);
    ARR_BOUND_UTDOA_FOR_HAL(mode,UT_VALIDMODE_NUM);
	dbgInfo("-----------------------------------> print data app for bsp <----------------------------------- \n");
	dbgInfo("--------------------> print UtdoaCellCfg Info <---------------------\n");

	dbgInfo("ulCellNo:%d  ulCarrNo:%d  uiChanMask:%d  uiRadio:%d  uiCarrBandWidth:%d \n",s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaCellCfg.ulCellNo, \
			s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaCellCfg.ulCarrNo, s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaCellCfg.uiChanMask, s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaCellCfg.uiRadio, \
			s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaCellCfg.uiCarrBandWidth \
			);


	dbgInfo("--------------> print UtdoaLargeSmallErgodicCfg Info <--------------\n");

	dbgInfo(" Enable: %d \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.Enable             );
	dbgInfo("AACFrameStart: 0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACFrameStart);
	dbgInfo("AACFrameEnd: 0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACFrameEnd    );
	dbgInfo("AACGroup: %d \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACGroup          );
	
	dbgInfo("AACGroupStartFrame: ");
	FOR_CIRCULATE_UTDOA_USHORT(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[0],UTDOA_AAC_GROUP_NUM,0 );
	dbgInfo("\n");

	dbgInfo("AACGroupEndFrame: ");
	FOR_CIRCULATE_UTDOA_USHORT(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[0],UTDOA_AAC_GROUP_NUM,0   );
	dbgInfo("\n");

	dbgInfo("AACSendFrame:   \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACSendFrame[0],UTDOA_AAC_FRAME_NUM,64       );
	dbgInfo("\n");

	dbgInfo("AACCaputeFrame: \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACCaputeFrame[0],UTDOA_AAC_FRAME_NUM,0      );
	dbgInfo("\n");

	dbgInfo("AACReturnFrame: \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.AACReturnFrame[0],UTDOA_AAC_FRAME_NUM,0      );
	dbgInfo("\n");

	dbgInfo(" RttStartFrame: 0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.RttStartFrame                   );
	dbgInfo(" RttEndFrame: 0x%x   \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaLargeSmallErgodicCfg.RttEndFrame                     );


	dbgInfo("---------------------> print UtdoaSrsCfg Info <---------------------\n");
	
	dbgInfo("CellFlag: %d \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.CellFlag                                            );

	dbgInfo("AACSendTimeSlot:    \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.AACSendTimeSlot[0],UTDOA_SEND_TIME_SLOT_NUM,40             );
	dbgInfo("\n");

	dbgInfo("AACCaptureTimeSlot: \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.AACCaptureTimeSlot[0],UTDOA_CAPTURE_TIME_SLOT_NUM,0        );
	dbgInfo("\n");

	dbgInfo("AACReturnTimeSlot: \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.AACReturnTimeSlot[0],UTDOA_RETURN_TIME_SLOT_NUM,40         );
	dbgInfo("\n");

	dbgInfo("RttSendTimeSlot:   \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.RttSendTimeSlot[0],RTT_SRS_TIME_SLOT_NUM,0                 );
	dbgInfo("\n");

	dbgInfo("RttReturnTimeSlot: \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.RttReturnTimeSlot[0],RTT_SRS_TIME_SLOT_NUM,0               );
	dbgInfo("\n");

	dbgInfo("SRSCaptureTimeSlot:\n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.SRSCaptureTimeSlot[0],RTT_SRS_TIME_SLOT_NUM,0              );
	dbgInfo("\n");

	dbgInfo("SRSReturnTimeSlot: \n");
	FOR_CIRCULATE_UTDOA_UCHAR(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.SRSReturnTimeSlot[0],RTT_SRS_TIME_SLOT_NUM,0               );
	dbgInfo("\n");

	dbgInfo(" AACSendSym: 0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.AACSendSym                                       );

	dbgInfo("AACReturnSymPos:  \n");
	FOR_CIRCULATE_UTDOA_USHORT(&s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.AACReturnSymPos[0],UTDOA_AAC_RETURN_SYM_POS,0             );
	dbgInfo("\n");

	dbgInfo(" RttSendSym:      0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.RttSendSym     );
	dbgInfo(" RttReturnSym:    0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.RttReturnSym   );
	dbgInfo(" SRSCaptureSym:   0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.SRSCaptureSym  );
	dbgInfo(" SRSCaptureCycle: %d   \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.SRSCaptureCycle);
	dbgInfo(" SRSReturnFrame:  0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.SRSReturnFrame );
	dbgInfo(" SRSReturnSym:    0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaSrsCfg.SRSReturnSym   );

    dbgInfo("---------------------> print UtdoaCalibPeriodCfg Info <---------------------\n");
    dbgInfo(" usCalibPeriod:    %d   \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaCalibPeriodCfg.usCalibPeriod   );
    dbgInfo(" usOffset:         0x%x \n",(UINT32)s_pUtdoaAllCfgBak[uiCarrLoop][mode].UtdoaCalibPeriodCfg.usOffset        );

	return BSP_OK;
}
/* Ended by AICoder, pid:t8e80s1ed6t7291141420804101b0e13ffa23a92 */

UINT32 BspSetUtdoaPrintFlag(UINT32 en)
{
	printFlag = en;
	return BSP_OK;
}

/* Started by AICoder, pid:4ff54w7b3dlc60a1491c0a41d0ce093605146531 */
VOID BspUtdoaPrintSmallErgodicParaForOpt(VOID)
{
    dbgInfo("toOptParaBak.rttStart:%d    \n",toOptParaBak.rttStart   );
    dbgInfo("toOptParaBak.rttEnd:%d      \n",toOptParaBak.rttEnd     );
    dbgInfo("toOptParaBak.offset:%d      \n",toOptParaBak.offset     );
    dbgInfo("toOptParaBak.calibPeriod:%d \n",toOptParaBak.calibPeriod);
    dbgInfo("---------------------> paraRtt <---------------------\n");
    dbgInfo("toOptParaBak.paraRtt.uiLen:%d     \n",toOptParaBak.paraRtt.uiLen);
    dbgInfo("toOptParaBak.paraRtt.uiEn :%d     \n",toOptParaBak.paraRtt.uiLen);
    for (UINT32 i = 0; i < MAX_REG_INFO_NUM; i++)
    {
        if (0 == (i % 10 ))
        {
            dbgInfo("\n");
        }
        dbgInfo("{0x%x,0x%x} ",toOptParaBak.paraRtt.UtRegInfo[i].uiPhyAddr,toOptParaBak.paraRtt.UtRegInfo[i].uiRegVal);
    }
    dbgInfo("\n");
    dbgInfo("---------------------> paraR2r <---------------------\n");
    dbgInfo("toOptParaBak.paraR2r.uiLen:%d     \n",toOptParaBak.paraR2r.uiLen);
    dbgInfo("toOptParaBak.paraR2r.uiEn :%d     \n",toOptParaBak.paraR2r.uiLen);
    for (UINT32 i = 0; i < MAX_REG_INFO_NUM; i++)
    {
        if (0 == (i % 10 ))
        {
            dbgInfo("\n");
        }
        dbgInfo("{0x%x,0x%x} ",toOptParaBak.paraR2r.UtRegInfo[i].uiPhyAddr,toOptParaBak.paraR2r.UtRegInfo[i].uiRegVal);
    }
}
/* Ended by AICoder, pid:4ff54w7b3dlc60a1491c0a41d0ce093605146531 */

VOID utdoahelp(VOID)
{
	dbgInfo("    =====================    print    ==================== \n");
	dbgInfo("    BspSetUtdoaPrintFlag(UINT32 en)                        \n");
	dbgInfo("    BspPrintSaveDataUtForHal(UINT32 carrLoop)              \n");
	dbgInfo("    BspPrintDataAppForBsp(UINT32 uiCarrLoop, UINT32 mode)  \n");
	dbgInfo("    printaacDate(UINT32 ulRadioStand)                      \n");
    dbgInfo("    BspUtdoaPrintSmallErgodicParaForOpt(VOID)              \n");
    dbgInfo("    BspUtAcCtrlParaPrint(UINT32 tddSel, UINT32 acType)     \n");
    dbgInfo("    BspUtAcCtrlMuxParaPrint(VOID)                          \n");
	dbgInfo("                                                           \n");
	dbgInfo("    =====================  interrupt  ==================== \n");
    dbgInfo("    BspTestSetStopChangeMode(UINT32 en)                    \n");
    dbgInfo("    testSetTestStopFlag(UINT32 flag)                       \n");
	dbgInfo("    BspSetInterrupFlagUtdoa(UINT32 sw)                     \n");
	dbgInfo("    BspGetNextSuperMode(VOID)                              \n");
    dbgInfo("                                                           \n");
    dbgInfo("    =====================   hal log   ==================== \n");
    dbgInfo("    BspSetHalLogCollectFlag(UINT32 value)                  \n");
}

UINT32 BspSetUtdoaTddGpClr(UINT32 chanMask, UINT32 carrNo, UINT32 radioMode,UINT32 en)
{
    UINT32 chan = 0;
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 txSw = en;
    UINT32 rxSw = 1-en;

    for(chan = 0; chan <txChnNum; chan++)
    {
        if((chanMask & (0x1 << chan)) !=0)
        {
            BspHalAdaptUtTddClrCfg(chan,carrNo,radioMode);
            BspHalAdaptSetUlTddClrEn(chan,carrNo,radioMode,txSw);
            BspHalAdaptSetUlBankTddSw(chan,carrNo,radioMode,rxSw);
        }
    }

    return BSP_OK;
}

/* Started by AICoder, pid:u5ab7v58f0a9c3c14c640b86705439242b277853 */
VOID BspUtdoaRttSlotArrDeal(UINT32 rttValidLength, UINT32 rttSlotTmp, UINT32 *rttSlotArr)
{
    UINT32 tmpLoop = 0;
    UINT32 slotIndex = 0;

    // 双2.5ms周期 可能会有问题？因为时隙不是7和17了，而是两个7？
    for ( tmpLoop = 0; tmpLoop < rttValidLength; tmpLoop++)
    {
        if ( rttSlotTmp & BIT_SET(tmpLoop))
        {
           if (0 == slotIndex)
           {
                rttSlotArr[0] = BIT_SET(tmpLoop);
                slotIndex++;
           }
           else if(1 == slotIndex)
           {
                rttSlotArr[1] = BIT_SET(tmpLoop);
                slotIndex++;
           }
           else
           {
                break;
           }
        }
    }
}
/* Ended by AICoder, pid:u5ab7v58f0a9c3c14c640b86705439242b277853 */

/* Started by AICoder, pid:017d081147k1b1f149c10aca11103d056b0169e7 */
UINT32 BspUtdoaDealRttDataForEachChan(UINT32 chanMask, UINT32 carrNo, UINT32 radio, UINT32 halUtMode, UINT32 uiCarrBandWidth, T_BspHalAdaptUtSendParaCfg* sendPara )
{
    ARR_BOUND_UTDOA_FOR_HAL(halUtMode,UT_VALIDMODE_NUM);
    UINT32 difChan = 0;
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 rttEndFr = sendPara->paraUnit[halUtMode].uiSlotInfo[0].uiEndFrNo;
    UINT32 rttStarFr = sendPara->paraUnit[halUtMode].uiSlotInfo[0].uiStartFrNo;
    UINT32 frame[800] = {0}; // 其实用不了这么大
    UINT32 slot[2] = {0};
    UINT32 frIndex = 0;
    UINT32 tmpLoop = 0;
    UINT32 rttValidLength = 20;
    UINT32 *rttFrTmp = &(sendPara->paraUnit[halUtMode].uiFrNoBitmap[0]);
    UINT32 rttSlotTmp = sendPara->paraUnit[halUtMode].uiSlotInfo[0].uiSlotBitmap;
    UINT32 tmpCpyIndex = 0;
    UINT32 chanLoop = 0;
    UINT32 tmpRttFr = 0;
    UINT32 tmpRttFrTwo = 0;
    T_BspHalAdaptUtSendParaCfg sendParaTmp = {0};

    BspLog(LOG_LEVEL_0,"%s >>>chanMask:%d carrNo:%d radio:0x%x halUtMode:%d\n", __FUNCTION__,chanMask, carrNo, radio, halUtMode );
    BspLog(LOG_LEVEL_0,"%s >>>rttFrTmp[0]:0x%x rttFrTmp[1]:0x%x rttSlotTmp:0x%x rttEndFr:0x%x \n", __FUNCTION__,rttFrTmp[0], rttFrTmp[1], rttSlotTmp, rttEndFr);

    if (UT_MODE_CALI != halUtMode)
    {
        for(difChan = 0; difChan <txChnNum; difChan++)
        {
            if((chanMask & (0x1 << difChan)) !=0)
            {
                BspGetUtdoaAacDate(difChan,chanMask,uiCarrBandWidth,radio,&(sendPara->uiAcBaseSeque[0])); /*获取AAC序列*/
                BspHalAdaptUtSendAacCfg(difChan,carrNo,radio,sendPara);      // 发送配置给中频：AAC序列、帧号bitmap、时隙bitmap、符号bitmap
            }
        }
        return BSP_OK;
    }

    BspUtdoaRttSlotArrDeal(rttValidLength,rttSlotTmp,&(slot[0]));

    BspLog(LOG_LEVEL_0,"%s >>>slot[0]:0x%x slot[1]:0x%x \n", __FUNCTION__,slot[0], slot[1]);

    for(tmpLoop = rttStarFr; tmpLoop <= rttEndFr; tmpLoop++)
    {
        if (rttFrTmp[tmpLoop/32] & BIT_SET(tmpLoop%32))
        {
            ARR_BOUND_UTDOA((frIndex+1),800);
            frame[frIndex] = BIT_SET(tmpLoop);
            frame[frIndex+1] = BIT_SET(tmpLoop);
            frIndex = frIndex + 2;
        }
    }

    BspLog(LOG_LEVEL_0,"%s >>>frame[0]:0x%x [1]:0x%x [2]:0x%x [3]:0x%x [4]:0x%x [5]:0x%x [6]:0x%x \n", __FUNCTION__,frame[0],frame[1],frame[2],frame[3],frame[4],frame[5]);

    memcpy_s(&sendParaTmp,sizeof(T_BspHalAdaptUtSendParaCfg),sendPara,sizeof(T_BspHalAdaptUtSendParaCfg));

    for(difChan = 0; difChan <txChnNum; difChan++)
    {
        if((chanMask & (0x1 << difChan)) !=0)
        {
            ARR_BOUND_UTDOA(tmpCpyIndex,frIndex);
            chanLoop = BspGetUtdoaChanLoop(difChan, chanMask);
            
            // 不跨帧
            if((rttStarFr/32) == (rttEndFr/32))
            {
                tmpRttFr = sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[rttStarFr/32];
                tmpRttFrTwo = frame[tmpCpyIndex];
                sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[rttStarFr/32] = BIT_FIELD_MASK_CFG(tmpRttFr,tmpRttFrTwo,(rttStarFr%32),(rttEndFr%32));  
            }
            else // 跨帧
            {
                // 在前一个帧
                if (frame[tmpCpyIndex] >= frame[0])
                {
                    tmpRttFr = sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[(rttStarFr/32)];
                    tmpRttFrTwo = frame[tmpCpyIndex];
                    sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[rttStarFr/32] = BIT_FIELD_MASK_CFG(tmpRttFr,tmpRttFrTwo,(rttStarFr%32),(32-(rttStarFr%32)));
                    tmpRttFr = sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[(rttEndFr/32)];
                    sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[rttEndFr/32]  = BIT_FIELD_MASK_CFG(tmpRttFr,0,0,(rttEndFr%32));
                }
                // 在后一个帧
                else
                {
                    tmpRttFr = sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[(rttEndFr/32)];
                    tmpRttFrTwo = frame[tmpCpyIndex];
                    sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[rttEndFr/32] = BIT_FIELD_MASK_CFG(tmpRttFr,tmpRttFrTwo,0,(rttEndFr%32));
                    tmpRttFr = sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[(rttStarFr/32)];
                    sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[rttStarFr/32]  = BIT_FIELD_MASK_CFG(tmpRttFr,0,(rttStarFr%32),(32-(rttStarFr%32)));
                }
            }
            
            tmpCpyIndex++;
            
            sendParaTmp.paraUnit[halUtMode].uiSlotInfo[0].uiSlotBitmap = slot[chanLoop%2];

            BspLog(LOG_LEVEL_0,"%s >>>toHal chan:%d chanLoop:%d tmpCpyIndex:%d uiFrNoBitmap[0]:0x%x uiSlotBitmap:0x%x  \n", __FUNCTION__,difChan,chanLoop,tmpCpyIndex,sendParaTmp.paraUnit[halUtMode].uiFrNoBitmap[0], slot[chanLoop%2]);
            BspGetUtdoaAacDate(difChan,chanMask,uiCarrBandWidth,radio,&sendParaTmp.uiAcBaseSeque[0]); /*获取AAC序列*/
            BspHalAdaptUtSendAacCfg(difChan,carrNo,radio,&sendParaTmp);      // 发送配置给中频：AAC序列、帧号bitmap、时隙bitmap、符号bitmap
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:017d081147k1b1f149c10aca11103d056b0169e7 */

/* 非小遍历情况下关闭光口对Rtt和R2R增益的切换中断线程 */
/* Started by AICoder, pid:i2eba60eda522331439a082401e3db046856ad6f */
VOID BspSetGainChangeInterruptEn(UINT32 uiUtForHalMode)
{
    if (UT_MODE_CALI != uiUtForHalMode)
    {
        BspHalAdaptUtdoaAacIrqCfg(0);
        optInterruptFlag = 0;
    }
}

UINT32 BspUtSetRttR2rGainParaToHal(UINT32 uidifChanNo, UINT32 uiCarrNo, UINT32 uiCarrRadio, UINT32 chanLoop)
{
    T_BspHalAdaptUtAacGainArray gainTmp = {0};
    
    // RTT 
    BspHalAdaptSetSaveGrp(UT_REG_TYPE_UTDOA,0);
    BspHalAdaptSetSaveRegEn(1);
    if(1 >= utCarrNum)
    {
        memcpy_s(&(gainTmp),sizeof(T_BspHalAdaptUtAacGainArray),(&(rttSingleUtCarr[chanLoop])),sizeof(T_BspHalAdaptUtAacGainArray));
    }
    else
    {
        memcpy_s(&(gainTmp),sizeof(T_BspHalAdaptUtAacGainArray),(&(rttMultiUtCarr[chanLoop])),sizeof(T_BspHalAdaptUtAacGainArray));
    }
    BspHalAdaptSaveUtSendAAcGain(uidifChanNo, uiCarrNo, uiCarrRadio, &gainTmp);
    BspHalAdaptSetSaveRegEn(0);//uiEn配置为0，代表下发的增益不会进行寄存器地址和值的映射操作。
    memset_s(&(gainTmp),sizeof(T_BspHalAdaptUtAacGainArray),0,sizeof(T_BspHalAdaptUtAacGainArray));
    
    // R2R
    BspHalAdaptSetSaveGrp(UT_REG_TYPE_UTDOA,1);
    BspHalAdaptSetSaveRegEn(1);
    if(1 >= utCarrNum)
    {
        memcpy_s(&(gainTmp),sizeof(T_BspHalAdaptUtAacGainArray),(&(r2rSingleUtCarr[chanLoop])),sizeof(T_BspHalAdaptUtAacGainArray));
    }
    else
    {
        memcpy_s(&(gainTmp),sizeof(T_BspHalAdaptUtAacGainArray),(&(r2rMultiUtCarr[chanLoop])),sizeof(T_BspHalAdaptUtAacGainArray));
    }
    BspHalAdaptSaveUtSendAAcGain(uidifChanNo, uiCarrNo, uiCarrRadio, &gainTmp);
    BspHalAdaptSetSaveRegEn(0);//uiEn配置为0，代表下发的增益不会进行寄存器地址和值的映射操作。
    memset_s(&(gainTmp),sizeof(T_BspHalAdaptUtAacGainArray),0,sizeof(T_BspHalAdaptUtAacGainArray));
    
    return BSP_OK;
}

UINT32 BspUtDealSmallErgodicParaToOpt(UINT32 uiUtForHalMode)
{
    UINT32 uiChanMask = 0;
    UINT32 carrLoop = 0;
    UINT32 uidifChanNo = 0;
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 uiCarrNo = 0;
    UINT32 uiCarrRadio = 0;
    UINT32 chanLoop = BspGetTxChannel();
    T_RegSaveUnit rttHalUintPara = {0};
    T_RegSaveUnit r2rHalUintPara = {0};
    T_UtdoaSmallErgodicParaOpt toOptPara = {0};

    // 小遍历情况下才进行处理。
    if (UT_MODE_CALI != uiUtForHalMode)
    {
        return BSP_OK;
    }

    BspHalAdaptClrSaveRegInfo(UT_REG_TYPE_UTDOA,0);// 0代表RTT组号 清除中频保存的载波增益，载波来一次清除一次
    BspHalAdaptClrSaveRegInfo(UT_REG_TYPE_UTDOA,1);// 1代表R2R组号 清除中频保存的载波增益，载波来一次清除一次

    // 不同载波的RTT起止帧号、校准周期、周期内偏移相同，因此使用载波0的就可以的。
    toOptPara.rttStart    = s_pUtdoaAllCfgBak[0][1].UtdoaLargeSmallErgodicCfg.RttStartFrame;
    toOptPara.rttEnd      = s_pUtdoaAllCfgBak[0][1].UtdoaLargeSmallErgodicCfg.RttEndFrame;
    toOptPara.offset      = s_pUtdoaAllCfgBak[0][1].UtdoaCalibPeriodCfg.usOffset;
    toOptPara.calibPeriod = s_pUtdoaAllCfgBak[0][1].UtdoaCalibPeriodCfg.usCalibPeriod;

    for(carrLoop = 0; carrLoop<utCarrNum; carrLoop++)
    {
        uiChanMask  = s_pUtdoaAllCfgBak[carrLoop][1].UtdoaCellCfg.uiChanMask; // 1 在这里表示小遍历模式
        uiCarrNo    = s_pUtdoaAllCfgBak[carrLoop][1].UtdoaCellCfg.ulCarrNo;
        uiCarrRadio = s_pUtdoaAllCfgBak[carrLoop][1].UtdoaCellCfg.uiRadio;

        if ((0 == uiChanMask) || (0 == uiCarrRadio)) // 说明还未保存到此载波的小遍历模式参数
        {
            continue;
        }

        for(uidifChanNo = 0; uidifChanNo <txChnNum; uidifChanNo++)
        {
            chanLoop = BspGetUtdoaChanLoop(uidifChanNo, uiChanMask);
            if((MAX_AAC_ANT_NUM > chanLoop) && ((uiChanMask & (0x1 << uidifChanNo)) !=0))
            {
                BspUtSetRttR2rGainParaToHal(uidifChanNo, uiCarrNo, uiCarrRadio, chanLoop);
            }
        }
    }

    BspHalAdaptGetSaveRegInfo(UT_REG_TYPE_UTDOA, 0, &rttHalUintPara); // 明天问王伟这个接口 可不可以在最后，一下子取出增益
    BspHalAdaptGetSaveRegInfo(UT_REG_TYPE_UTDOA, 1, &r2rHalUintPara);
    
    memcpy_s(&(toOptPara.paraRtt),sizeof(T_RegSaveUnit),&(rttHalUintPara),sizeof(T_RegSaveUnit));
    memcpy_s(&(toOptPara.paraR2r),sizeof(T_RegSaveUnit),&(r2rHalUintPara),sizeof(T_RegSaveUnit));
    memcpy_s(&(toOptParaBak),sizeof(T_UtdoaSmallErgodicParaOpt),&(toOptPara),sizeof(T_UtdoaSmallErgodicParaOpt));

    BspHalAdaptSetUtdoaSmallErgodicPara(&toOptPara); // 发送给光口

    return BSP_OK;
}

/* Ended by AICoder, pid:i2eba60eda522331439a082401e3db046856ad6f */

/* Started by AICoder, pid:2cbe7261ec98dac14595082730225610b000c1f4 */
VOID BspUtSendUtInfoToDsp(VOID)
{

    UINT32 utIsExit = BspIsUtdoaExit();
    
    if (0 != calibPeriod_Ut_Bak[0])
    {
        // 使用Bak的原因是，calibPeriod_Ut 可能会因为手动打桩导致参数发生变化。
        BspDpdSetUtdoaCfgMsg(0,0,calibPeriod_Ut_Bak[0],offset_Ut_Bak[0],utIsExit);
    }

}
/* Ended by AICoder, pid:2cbe7261ec98dac14595082730225610b000c1f4 */
/* Started by AICoder, pid:398c3te2aczbddb14950098851406820ba31eccf */
/*****************************************************************************
 * 函数名称: BspHandleUtdoaAllCfg
 * 功能描述: 一 将APP 下发的UTDOA数据 处理后发给HAL
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
T_BspHalAdaptUtSendParaCfg   pHalAdaptUtSendParaCfg ={0};
T_BspHalAdaptUtSampleParaCfg pHalAdaptUtSampleParaCfg = {0};
T_BspHalAdaptUtInsertParaCfg pHalAdaptUtInsertParaCfg = {0};
UINT32 g_utdoaTestFlag = 0xff; //维测开关，用来模拟APP切换大遍历和小遍历模式
UINT32 BspHandleUtdoaAllCfg(UINT32  uiCarrLoop)
{
	UINT32 uiChanMask = 0;
	UINT32 uidifChanNo = 0;
	UINT32 uiCarrNo = 0;
	UINT32 uiCarrRadio = 0;
	UINT32 txChnNum = BspGetTxChannel();
	UINT32 uiCarrBandWidth = 0;
	UINT32 uiEnable = 0;
    UINT32 enFlag = 0; //UTDOA中频的一些使能标志
	UINT32 uiUtForHalMode = UT_MODE_OFF;
    UINT32 dlyValue = 2000;
    
    /* Started by AICoder, pid:j0ef203b65ge0cc140d30ab5909faf0e1c99d426 */
    if(g_utdoaTestFlag == 0)//切换到大遍历
    {
        memcpy_s(&s_pUtdoaAllCfg[uiCarrLoop], sizeof(T_RruUTDOAAllCfg), &s_pUtdoaAllCfgBak[uiCarrLoop][0], sizeof(T_RruUTDOAAllCfg));
    }
    else if(g_utdoaTestFlag == 1)//切换到小遍历
    {
        memcpy_s(&s_pUtdoaAllCfg[uiCarrLoop], sizeof(T_RruUTDOAAllCfg), &s_pUtdoaAllCfgBak[uiCarrLoop][1], sizeof(T_RruUTDOAAllCfg));
    }
    /* Ended by AICoder, pid:j0ef203b65ge0cc140d30ab5909faf0e1c99d426 */
	BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);
	ARR_BOUND_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);

	uiChanMask = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.uiChanMask;
	uiCarrNo = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.ulCarrNo;
	uiCarrRadio = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.uiRadio;
	uiCarrBandWidth = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.uiCarrBandWidth;

	uiEnable = s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.Enable;
	uiUtForHalMode = BspGetUtEnModel(uiEnable);

    dbgInfo("New Utdoa config, uiUtForHalMode[%u]\n", uiUtForHalMode);
    HAL_LOG(HAL_LOG_L0, "New Utdoa config, uiUtForHalMode[%u]\n", uiUtForHalMode);
/* Started by AICoder, pid:kd6eaecca9096ca140a008cd908eb206c0d321fa */    
    ARR_BOUND_UTDOA(uiUtForHalMode,4);
/* Ended by AICoder, pid:kd6eaecca9096ca140a008cd908eb206c0d321fa */

    if (0 == testStopFlag)
    {
        return BSP_OK;
    }

    BspSetGainChangeInterruptEn(uiUtForHalMode);
    if(uiUtForHalMode == UT_MODE_OFF)
    {
        enFlag = 0;
        // dlyValue = 0;
        BspSetUtdoaTddGpClr(uiChanMask, uiCarrNo, uiCarrRadio, enFlag);
        // BspSetUtIoEnVar(DMM_UT_PUBLIC_EN_OFF); // 设置UT互斥变量为假    不能这么写，因为这个是整体存在与否，而该接口下发的是载波级别的 
    }
/* Started by AICoder, pid:1d679le104w8f141405a08399020a73de2a0daef */
    else
    {
        enFlag = 1;
        // dlyValue = 2000;
        BspSetUtdoaTddGpClr(uiChanMask, uiCarrNo, uiCarrRadio, enFlag);
        // BspSetUtIoEnVar(DMM_UT_PUBLIC_EN_ON);   // 设置UT互斥变量为真，只要有就置为真，ZHY：互斥代码，先注释掉
        BspSetUtdoaDlDtxPaAndAmpGpSel(uiChanMask,1); // 仿照DMM放到这里，同样的，不能在下发配置接口中关闭，下发接口是载波级的，而此接口是通道级的，只能在总使能接口中关

        // 每次下发对应模式的参数前，先清除其老参数。发现APP下发给BSP的大遍历帧号，和发送给中频的帧号，对不上，核对转换规则也没啥问题。怀疑是重复下发大遍历参数导致，因此进行清除。
        ARR_BOUND_UTDOA_FOR_HAL(uiUtForHalMode,UT_VALIDMODE_NUM);
        memset_s(&pHalAdaptUtSendParaCfg.paraUnit[uiUtForHalMode],  sizeof(T_BspHalAdaptUtParaUint),0,sizeof(T_BspHalAdaptUtParaUint));
        memset_s(&pHalAdaptUtSendParaCfg.uiAcBaseSeque[0], sizeof(UINT32)*UT_AAC_SENDRAM_LEN_BSP, 0,sizeof(UINT32)*UT_AAC_SENDRAM_LEN_BSP);
        memset_s(&pHalAdaptUtSampleParaCfg.paraUnit[uiUtForHalMode],sizeof(T_BspHalAdaptUtParaUint),0,sizeof(T_BspHalAdaptUtParaUint));
        memset_s(&pHalAdaptUtInsertParaCfg.paraUnit[uiUtForHalMode],sizeof(T_BspHalAdaptUtParaUint),0,sizeof(T_BspHalAdaptUtParaUint));
    }
/* Ended by AICoder, pid:1d679le104w8f141405a08399020a73de2a0daef */

	

	if( (UT_MODE_GROUP == uiUtForHalMode) || (UT_MODE_CALI == uiUtForHalMode) )
	{	
		/*大遍历小遍历发送帧号bitmap处理*/
		BspSetUtdoaFrameBitmapHandle(s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACSendFrame,pHalAdaptUtSendParaCfg.paraUnit[uiUtForHalMode].uiFrNoBitmap, uiUtForHalMode, SEND_MODE, uiCarrLoop);
		/*大遍历小遍历拍照帧号bitmap处理*/
		BspSetUtdoaFrameBitmapHandle(s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACCaputeFrame,pHalAdaptUtSampleParaCfg.paraUnit[uiUtForHalMode].uiFrNoBitmap, uiUtForHalMode, CAPTURE_MODE, uiCarrLoop);
		/*大遍历小遍历回传帧号bitmap处理*/
		BspSetUtdoaFrameBitmapHandle(s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.AACReturnFrame,pHalAdaptUtInsertParaCfg.paraUnit[uiUtForHalMode].uiFrNoBitmap, uiUtForHalMode, INSERT_MODE, uiCarrLoop);

		/* 发送时隙序列处理                */
		BspHandleUtdoaSendAndReturnSlotInfoCfgForHalCfg(uiCarrLoop,&pHalAdaptUtSendParaCfg.paraUnit[uiUtForHalMode],  &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.AACSendTimeSlot[0],   &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.RttSendTimeSlot[0],  NULL, uiUtForHalMode);        
		/* 拍照时隙序列处理: RTT拍照借用发送 */
		BspHandleUtdoaCaptureSlotInfoCfgForHalCfg(      uiCarrLoop,&pHalAdaptUtSampleParaCfg.paraUnit[uiUtForHalMode],&s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.AACCaptureTimeSlot[0],&s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.RttSendTimeSlot[0],  &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSCaptureTimeSlot[0], uiUtForHalMode);   
		/* 回传时隙序列处理                */
		BspHandleUtdoaSendAndReturnSlotInfoCfgForHalCfg(uiCarrLoop,&pHalAdaptUtInsertParaCfg.paraUnit[uiUtForHalMode],&s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.AACReturnTimeSlot[0], &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.RttReturnTimeSlot[0],&s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSReturnTimeSlot[0],  uiUtForHalMode);

		/* 发送符号处理 */
		BspHandleUtdoaSendAndCaptureSymInfoCfgForHalCfg(uiCarrLoop, &pHalAdaptUtSendParaCfg.paraUnit[uiUtForHalMode],   &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.AACSendSym, &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.RttSendSym, NULL, uiUtForHalMode);
		/* 拍照符号处理 */
		BspHandleUtdoaSendAndCaptureSymInfoCfgForHalCfg(uiCarrLoop, &pHalAdaptUtSampleParaCfg.paraUnit[uiUtForHalMode], &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.AACSendSym, &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.RttSendSym, &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSCaptureSym, uiUtForHalMode);
		/* 回传符号处理 */
		BspHandleUtdoaReturnSymInfoCfgForHalCfg(&pHalAdaptUtInsertParaCfg.paraUnit[uiUtForHalMode], &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.AACReturnSymPos[0], &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.RttReturnSym, &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSReturnSym,uiUtForHalMode);

        /* 将传给中频的数据保存一份，以便维测 */
	    BspSaveDataUtForHal(&pHalAdaptUtSendParaCfg, &pHalAdaptUtSampleParaCfg, &pHalAdaptUtInsertParaCfg, uiCarrLoop, uiUtForHalMode);

	}
    
    /* 这里加上小遍历的原因是：如果有一个整机复位则跳过SRS参数直接从大遍历参数下发，丢失SRS信息，所以直接使用小遍历中携带的SRS信息。 */
    if ((UT_MODE_SRS == uiUtForHalMode) || (UT_MODE_CALI == uiUtForHalMode))
	{
		/* SRS 发送帧号bitmap处理,发送和小遍历的相同不用处理 */
		/* SRS 拍照帧号bitmap处理 */
		BspSetUtdoaSrsSampleFrameBitmapHandle(uiCarrLoop,pHalAdaptUtSampleParaCfg.paraUnit[UT_MODE_SRS].uiFrNoBitmap, UT_MODE_SRS);
		/* SRS 回传帧号bitmap处理 */
		BspSetUtdoaSrsReturnFrameBitmapHandle(uiCarrLoop,pHalAdaptUtInsertParaCfg.paraUnit[UT_MODE_SRS].uiFrNoBitmap, UT_MODE_SRS);

		/* SRS 没有发送序列 */
		/* SRS 拍照时隙处理 */
		BspHandleUtdoaSrsSlotInfoCfgForHalCfg(&pHalAdaptUtSampleParaCfg.paraUnit[UT_MODE_SRS],&s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSCaptureTimeSlot[0]);
		/* SRS 回传序列处理 */
		BspHandleUtdoaSrsSlotInfoCfgForHalCfg(&pHalAdaptUtInsertParaCfg.paraUnit[UT_MODE_SRS],&s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSReturnTimeSlot[0] );

		/* SRS 没有发送符号 */
		/* SRS 拍照符号处理 */
		BspHandleUtdoaCaptureAndReturnSrsSymInfoCfgForHalCfg(&pHalAdaptUtSampleParaCfg.paraUnit[UT_MODE_SRS], &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSCaptureSym);
		/* SRS 回传符号处理 */
		BspHandleUtdoaCaptureAndReturnSrsSymInfoCfgForHalCfg(&pHalAdaptUtInsertParaCfg.paraUnit[UT_MODE_SRS], &s_pUtdoaAllCfg[uiCarrLoop].UtdoaSrsCfg.SRSReturnSym );
        
        /* 将传给中频的数据保存一份，以便维测 */
	    BspSaveDataUtForHal(&pHalAdaptUtSendParaCfg, &pHalAdaptUtSampleParaCfg, &pHalAdaptUtInsertParaCfg, uiCarrLoop, UT_MODE_SRS);
	
	}
    // else//ZHY:大遍历的关闭模式怎么处理呢
    // {

    // }

    // 将校准周期和偏移保存至全局变量
    if (0 != s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg.usCalibPeriod )
    {
        /* Started by AICoder, pid:o16e48f963g38e7146940a19e0a9370654a4be4a */
        offset_Ut[uiCarrLoop]          = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg.usOffset     ;
        offset_Ut_Bak[uiCarrLoop]      = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg.usOffset     ;
        calibPeriod_Ut[uiCarrLoop]     = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg.usCalibPeriod;
        calibPeriod_Ut_Bak[uiCarrLoop] = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg.usCalibPeriod;
        /* Ended by AICoder, pid:o16e48f963g38e7146940a19e0a9370654a4be4a */
    }

    BspUtSendUtInfoToDsp();

    // BspHalAdaptUtSendAacCfg(uidifChanNo,uiCarrNo,uiCarrRadio,&pHalAdaptUtSendParaCfg);      // 发送配置给中频：AAC序列、帧号bitmap、时隙bitmap、符号bitmap
    BspUtdoaDealRttDataForEachChan(uiChanMask,uiCarrNo,uiCarrRadio,uiUtForHalMode,uiCarrBandWidth,&pHalAdaptUtSendParaCfg);

	for(uidifChanNo = 0; uidifChanNo <txChnNum; uidifChanNo++)
    {
        if((uiChanMask & (0x1 << uidifChanNo)) !=0)
        {
            BspSetUtAacGain(uidifChanNo, uiChanMask, uiCarrRadio, utCarrNum, uiUtForHalMode);
            
            
            BspHalAdaptUtSampleCfg(uidifChanNo,uiCarrNo,uiCarrRadio,&pHalAdaptUtSampleParaCfg);    // 拍照配置给中频：帧号bitmap、时隙bitmap、符号bitmap
            BspHalAdaptUtInsertAacCfg(uidifChanNo,uiCarrNo,uiCarrRadio,&pHalAdaptUtInsertParaCfg); // 回插配置给中频：帧号bitmap、时隙bitmap、符号bitmap
            
            BspHalAdaptUtSetMode(uiUtForHalMode);
            if ((UT_MODE_GROUP == uiUtForHalMode) || (UT_MODE_CALI == uiUtForHalMode))
            {
                BspSetPaPathCfgForHalUtdoa(uidifChanNo,uiCarrNo,uiCarrRadio,uiUtForHalMode);/* 只有大小遍历需要配置PA、lna管脚 */
            }
            BspSetUtdoaEnForHal(enFlag, uidifChanNo, uiCarrNo, uiCarrRadio, uiUtForHalMode);// 发送、拍照、回插、IO的使能
            BspHalAdaptSetTsGpEn(uidifChanNo,UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
            BspHalAdaptSetDlTimingDlTddDly(uidifChanNo,dlyValue); // 配置 timing 时延

            // 下面这个接口用于给光口传递增益信息，以使光口可以切换RTT和R2R增益
        }
    }
    BspUtDealSmallErgodicParaToOpt(uiUtForHalMode);



	/* 维测接口 */
	if (printFlag == 1)
	{
        ARR_BOUND_UTDOA_FOR_HAL(uiUtForHalMode,UT_VALIDMODE_NUM);
		/* AAC序列数据 */
		printaacDate(s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.uiRadio);

		/* APP传给BSP的数据 */
		BspPrintDataAppForBsp(uiCarrLoop, uiUtForHalMode);

		/* 转换给中频的数据 */
		BspPrintDataDealForHalCode(&pHalAdaptUtSendParaCfg.paraUnit[uiUtForHalMode],  uiUtForHalMode, 1);
		BspPrintDataDealForHalCode(&pHalAdaptUtSampleParaCfg.paraUnit[uiUtForHalMode],uiUtForHalMode, 2);
		BspPrintDataDealForHalCode(&pHalAdaptUtInsertParaCfg.paraUnit[uiUtForHalMode],uiUtForHalMode, 3);
	}
	
	// BspSetInterrupFlagUtdoa(1);/* ZHY：暂时添加 */

	return BSP_OK;
}
/* Ended by AICoder, pid:398c3te2aczbddb14950098851406820ba31eccf */


/*****************************************************************************
 * 函数名称: BspSavaAppUtdoaAllCfg
 * 功能描述: 中断处理接口
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 nextSuperMode = 0xFFFF;

UINT32 BspGetNextSuperMode(VOID)
{
	dbgInfo("nextSuperMode:%d \n",nextSuperMode);
	return BSP_OK;
}

/* 光口中断开关：打开就开始检测799帧 */
UINT32 BspSetUtdoaPsyncIrqCfg(UINT32 switchEnable)
{
	return BspHalAdaptUtdoaPsyncIrqCfg(switchEnable);
}

/* Started by AICoder, pid:0fc7eg0ee4z214d14c8f090d109faf263b2041b5 */
/* 纯粹是为了通过圈复杂度，而抽出的函数：控制光口中断开关 */
UINT32 BspUtdoaSetOptPsyncIrqCfg(UINT32 *tempFlag)
{
    UINT32 retVal = BSP_OK;

    if (0 == BspIsUtdoaExit())/* 关闭光口中断的799帧检测 */
    {
        if (0 != *tempFlag)
        {
            *tempFlag = 0;
            BspHalAdaptUtdoaSetCovertFlag(0);/* 设置共享标志为0 */
            retVal |= BspSetUtdoaPsyncIrqCfg(0);/* 中断开关设置为0 */
        }
    }
    else/*  if (1 == BspIsUtdoaExit()) */
    {
        if (1 != *tempFlag)
        {
            *tempFlag = 1;
            retVal |= BspSetUtdoaPsyncIrqCfg(1);
        }
    }

    return retVal;
}
/* Ended by AICoder, pid:0fc7eg0ee4z214d14c8f090d109faf263b2041b5 */

UINT32 halLogCollectFlag = 3;  // 中频的log采集，手动开关标志
//1:下行采数   2:上行拍照   3：上行回插

/* Started by AICoder, pid:uc5d2s505017dc6146d30bdea00def2bee72e90a */
VOID BspSetHalLogCollectFlag(UINT32 value)
{
    halLogCollectFlag = value;
}

VOID BspPrintfHalLogCollectFlag(VOID)
{
    dbgInfo("halLogCollectFlag is %d\n",halLogCollectFlag);
}

// 传1进去表明开始记录，0表示结束记录
VOID BspHalCollectRecordFrameNo(UINT32 flag)
{
    UINT32 superFramNo    = BspGetSynPsyncSuperFrameNo();
    UINT32 psyncFramNo    = BspGetSynPsyncFrameNo();  // 光口帧号
    UINT32 halFrameNo = 0;
    BspHalAdaptGetWirelessFrId(&halFrameNo);
    
    if (1 == flag)
    {
        BspLog(LOG_LEVEL_0,"%s >>> start log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo,psyncFramNo, halFrameNo);
    }
    else
    {
        BspLog(LOG_LEVEL_0,"%s >>> end log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo,psyncFramNo, halFrameNo);
    }
}
/* Ended by AICoder, pid:uc5d2s505017dc6146d30bdea00def2bee72e90a */

UINT32 tmpLoopTimes = 5; // 临时的  后续可能删除 ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
VOID BspSetTmpLoopTimes(UINT32 value)
{
    tmpLoopTimes = value;
}

UINT32 loopFiveFlag = 0;
UINT32 collectGroupCarrLoop = UT_INVALID_CARR_NUMBER_FLAG;  // 将要采集的大遍历的载波在 s_pUtdoaAllCfg 存储的 序号 ！
UINT32 startGroupCollect = 0;
UINT32 groupCollectOk = 0; // 大遍历采数是否 完成 1：完成  0：未完成
/* Started by AICoder, pid:3ef212e9b1k371e14bbb0ab151c23707b4d8233c */
// 大遍历采数
UINT32 BspUtCollectHalLog(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 tmpLoop = 0;
    UINT32 selectflag = 0;

    if (0 == halLogCollectFlag)
    {
        return retVal;
    }

    selectflag = (halLogCollectFlag / 2) + 1;//halLogCollectFlag的正确入参为1-3，所以selectflag这里对应的是1-2

    // 如果当前存在SRS模式，说明大遍历完全做完。则将 groupCollectOk 标志恢复，以避免重新发起UTDOA后，影响采数
    if (UT_MODE_SRS == BspHalAdaptUtGetMode())
    {
        collectGroupCarrLoop = UT_INVALID_CARR_NUMBER_FLAG;
        startGroupCollect = 0;
        groupCollectOk = 0;
    }
    
    // 如果大遍历采数已经完成，则直接返回
    if (1 == groupCollectOk)
    {
        return BSP_OK;
    }

    // 标志的恢复应该考虑：
    //  （1）当前载波的模式还是大遍历：那如果中频标志和BSP标志恢复的话，下次循环还是大遍历的话怎么办？
    //  （2）当前载波的模式不是大遍历，但其余载波模式还处于大遍历，应该只关闭BSP标志，但如果关闭的话，不保证下次循环其他载波还继续进行采数？
    //  （3）全部载波都不是大遍历
    // 鉴于以上考虑，BSP侧新增一个采数完成标志 groupCollectOk ，以避免在大遍历完成一次采数后，在下一轮循环中又继续采数。
    //  注意：当读取到存在SRS模式时，理论上所有载波的大遍历已经全部做完并变成了其他模式。此时应该将 groupCollectOk 重新恢复到 0
    if (1 == startGroupCollect)  // 如果有开始采数的标志则才进行关闭哦
    {
        // 当前采数完成
        if ((UTDOA_MAX_CARR_NUM > collectGroupCarrLoop) && (BSP_OK == BspHalAdaptGetSampleCarrFinish(selectflag)))
        {
            // 采数已经完成，并且当前处于大遍历模式，此时关闭采数，并将大遍历采数标志恢复
            if ((UT_MODE_GROUP == BspGetUtEnModel((UINT32)s_pUtdoaAllCfg[collectGroupCarrLoop].UtdoaLargeSmallErgodicCfg.Enable)))
            {
                UINT32 superFramNo    = BspGetSynPsyncSuperFrameNo();
                UINT32 psyncFramNo    = BspGetSynPsyncFrameNo();  // 光口帧号
                UINT32 halFrameNo = 0;
                BspHalAdaptGetWirelessFrId(&halFrameNo);
                dbgInfoEx("%s >>> end log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo, psyncFramNo, halFrameNo);
                collectGroupCarrLoop = UT_INVALID_CARR_NUMBER_FLAG;
                startGroupCollect = 0;
                groupCollectOk = 1;
                BspHalAdaptEndSampleCarr(selectflag); // 大遍历结束采数配置

                BspHalAdaptRecoverSampleCfg(); // 采数恢复配置
                BspHalAdaptRenameUtdoaSampleFile(halLogCollectFlag); // 采集的数据文件重命名
                return BSP_OK;
            }

            // 采数已完成，但此时大遍历已经做完，此时不关闭采数，但将BSP侧大遍历采数标志恢复
            collectGroupCarrLoop = UT_INVALID_CARR_NUMBER_FLAG;
            startGroupCollect = 0;
            groupCollectOk = 1;
            return BSP_OK;
        }
    }

    // 判断当前是否存在大遍历
    for ( tmpLoop = 0; tmpLoop < UTDOA_MAX_CARR_NUM; tmpLoop++)
    {
        if ((UT_INVALID_CARR_NUMBER_FLAG == collectGroupCarrLoop) && (UT_MODE_GROUP == BspGetUtEnModel((UINT32)s_pUtdoaAllCfg[tmpLoop].UtdoaLargeSmallErgodicCfg.Enable)))
        {
            collectGroupCarrLoop = tmpLoop;
            break;
        }
    }
    // 找不到大遍历的载波， 直接返回
    // ARR_BOUND_UTDOA(collectGroupCarrLoop,UTDOA_MAX_CARR_NUM);
    if (collectGroupCarrLoop >= UTDOA_MAX_CARR_NUM)
    {
        return BSP_OK;
    }

    if((0 == startGroupCollect) && (0 == groupCollectOk))
    {
        // 循环 不够5次，那么循环记数器++
        if (tmpLoopTimes > loopFiveFlag)
        {
            loopFiveFlag = loopFiveFlag + 1;
            return BSP_OK;
        }
        else
        {
            loopFiveFlag = 0; // 防止哪里出错导致loopFiveFlag溢出
        }
        
        UINT32 superFramNo    = BspGetSynPsyncSuperFrameNo();
        UINT32 psyncFramNo    = BspGetSynPsyncFrameNo();  // 光口帧号
        UINT32 halFrameNo = 0;
        BspHalAdaptGetWirelessFrId(&halFrameNo);
        dbgInfoEx("%s >>> start log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo, psyncFramNo, halFrameNo);

        UINT32 chanMask  = s_pUtdoaAllCfg[collectGroupCarrLoop].UtdoaCellCfg.uiChanMask;
        UINT32 carrId    = s_pUtdoaAllCfg[collectGroupCarrLoop].UtdoaCellCfg.ulCarrNo;
        UINT32 radioMode = s_pUtdoaAllCfg[collectGroupCarrLoop].UtdoaCellCfg.uiRadio;
        UINT32 mode      = BspGetUtEnModel((UINT32)s_pUtdoaAllCfg[collectGroupCarrLoop].UtdoaLargeSmallErgodicCfg.Enable);
        

        BspHalAdaptSampleBank(chanMask, carrId, radioMode, mode, halLogCollectFlag);
        startGroupCollect = 1; // 大遍历采数开始标志，置1
    }

    return retVal;
}
/* Ended by AICoder, pid:3ef212e9b1k371e14bbb0ab151c23707b4d8233c */

UINT32 samllErgodicCollectStartFlag = 0;
/* Started by AICoder, pid:o53cfm3b69d4f1614b030a3750972450e5d1db7d */
// 小遍历采数
UINT32 BspUtCollectHalLogTwo(UINT32 halMode, UINT32 carrLoop)
{
    UINT32 chanMask  = s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiChanMask;
    UINT32 radioMode = s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiRadio;
    UINT32 carrId = s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.ulCarrNo;

    if (0 == halLogCollectFlag)
    {
        return BSP_OK;
    }
    
    // 只采第一个通道的第一个载波
    if(0 != carrLoop)
    {
        return BSP_OK;
    }

    // 当前使能小遍历（就是当前SRS模式的799帧后就被使能成小遍历了），并且下个超帧是小遍历，并且采数标志为0时，才开始采数
    if ((halMode == UT_MODE_CALI))
    {
        if (0 == samllErgodicCollectStartFlag)
        {
            UINT32 superFramNo    = BspGetSynPsyncSuperFrameNo();
            UINT32 psyncFramNo    = BspGetSynPsyncFrameNo();  // 光口帧号
            UINT32 halFrameNo = 0;
            BspHalAdaptGetWirelessFrId(&halFrameNo);
            dbgInfoEx("%s >>> start log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo, psyncFramNo, halFrameNo);
            HAL_LOG(HAL_LOG_L0, "%s >>> start log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo, psyncFramNo, halFrameNo);

            samllErgodicCollectStartFlag = 1;
            //BspHalAdaptUtInsertSampleUlBank(chanMask, carrId, radioMode, halMode); 
            BspHalAdaptSampleBank(chanMask, carrId, radioMode, halMode, halLogCollectFlag);
        }
    }
    else // 当判断下个超帧不是AAC超帧时，停止采数
    {
        if (1 == samllErgodicCollectStartFlag) // 开始采数了才需要停止，如果没有这个判断，会不断的调用停止采数函数
        {
            UINT32 superFramNo    = BspGetSynPsyncSuperFrameNo();
            UINT32 psyncFramNo    = BspGetSynPsyncFrameNo();  // 光口帧号
            UINT32 halFrameNo = 0;
            UINT32 selectflag = 0;
            BspHalAdaptGetWirelessFrId(&halFrameNo);
            dbgInfoEx("%s >>> end log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo, psyncFramNo, halFrameNo);
            HAL_LOG(HAL_LOG_L0, "%s >>> start log: superFramNo:%d psyncFramNo:%d halFrameNo:%d \n", __FUNCTION__, superFramNo, psyncFramNo, halFrameNo);

            samllErgodicCollectStartFlag = 0;

            selectflag = (halLogCollectFlag / 2) + 1;//halLogCollectFlag在前方已有参数校验和拦截，这里只能为1-3
            BspHalAdaptEndSampleCarr(selectflag); // 小遍历结束采数配置

            BspHalAdaptRecoverSampleCfg(); // 采数恢复配置
            // BspHalAdaptRenameSampleFile(); // 采集的数据文件重命名，按照中频要求  去掉
        }
    }
   
    return BSP_OK;
}
/* Ended by AICoder, pid:o53cfm3b69d4f1614b030a3750972450e5d1db7d */

/* Started by AICoder, pid:b1ff924313a076d149a10a7410c89862a6101eb9 */
/* ZHY:光口的中断 打开开关 BspHalAdaptUtdoaPsyncIrqCfg 由高层调用	*/
static void * BspInterruptDealUtdoa(void *para)
{
	// UINT32 uiUtForHalMode = UT_MODE_OFF;
	// UINT32 uiCarrNo = 0;
	UINT32 uiChanMask = 0;
	UINT32 uiRadio = 0;
	UINT32 uiEnable = 0;
    UINT32 carrNo   = 0xFFFF;
	UINT32 superFramNo = 0;
	UINT32 retVal = BSP_ERROR;
    UINT32 dmmEn = 0; /*默认不使能*/

	UINT32 tempFlag = 0;/* tempFlag的作用只是保证，光口中断开的时候只开一次，关的时候只关一次，避免多次连续下配置，中断接口多次调用 */
	
	while (1)
	{
		BspSysMsDelay(200);

        if (0 == interrupFlag)
        {
            continue;
        }

        // UTDOA采数--大遍历
        BspUtCollectHalLog();

		/* 控制光口中断开关（只是控制是否检测799帧） */
		BspUtdoaSetOptPsyncIrqCfg(&tempFlag);
		
		/* 1、从光口获取中断共享标志 */
		if (1 != BspHalAdaptUtdoaGetCovertFlag()) 
		{
			continue;
		}

		/* 遍历所有载波，注意uiCarrLoop只是一个标量，ulCarrNo才是实际的载波号 */
		for (UINT32 uiCarrLoop = 0; uiCarrLoop < UTDOA_MAX_CARR_NUM; uiCarrLoop++)
		{
            uiEnable = (UINT32)s_pUtdoaAllCfg[uiCarrLoop].UtdoaLargeSmallErgodicCfg.Enable;
            carrNo   = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.ulCarrNo;

            if((BSP_UTDOA_MODE_SMALL_ERGODIC_AND_SRS == uiEnable) && (0 != calibPeriod_Ut[uiCarrLoop])) // 只有小遍历模式时才能进行 小遍历和SRS模式的切换。因为小遍历同时使能小遍历和SRS
			{
                // 小遍历情况下开启RTT和R2R增益切换的中断线程。
                if (0 == optInterruptFlag)
                {
                    BspHalAdaptUtdoaAacIrqCfg(1);
                    optInterruptFlag = 1;
                }
                
                /* 2、调用中频接口设置下个超帧模式 */
                /* （1）计算下个超帧的模式 */
                retVal = BSP_OK;
                // ZHY:要不要加个延时？？？？？
                superFramNo    = BspGetSynPsyncSuperFrameNo();	
                uiChanMask     = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.uiChanMask;
                uiRadio        = s_pUtdoaAllCfg[uiCarrLoop].UtdoaCellCfg.uiRadio;
                
				if( ((superFramNo+1)%calibPeriod_Ut[uiCarrLoop]) == offset_Ut[uiCarrLoop])/* （超帧号+1）%校准周期 == 校准偏移 */
				{
					nextSuperMode = UT_MODE_CALI;
                    BspUtCollectHalLogTwo(UT_MODE_CALI,uiCarrLoop);// UTDOA采数--小遍历
					retVal |= BspHalAdaptUtSetMode(UT_MODE_CALI);
                    retVal |= BspSetUtdoaEnForHalByChanMask(1, carrNo, uiRadio, uiChanMask, UT_MODE_CALI);// 发送、拍照、回插、IO使能
					dbgInfoEx("%s: utdoa interrup --> next superFram mode is: %d \n", __FUNCTION__, nextSuperMode);

                    /* Started by AICoder, pid:9dda58309713ea9141220a9620f4d12b98268b2b */
                    /*UT小遍历场景下给中频下发去使能DMM*/
                    utDmmCoexistDmmSt = 1;
                    dbgInfoEx("%s >>> utdoa small ergodic, disables dmimo\n", __FUNCTION__); 
				}
				else
				{
                    BspUpdateDmimoExistStatus();
					nextSuperMode = UT_MODE_SRS;
                    BspUtCollectHalLogTwo(UT_MODE_SRS,uiCarrLoop);
					retVal |= BspHalAdaptUtSetMode(UT_MODE_SRS); 
                    retVal |= BspSetUtdoaEnForHalByChanMask(1, carrNo, uiRadio, uiChanMask, UT_MODE_SRS);// 发送、拍照、回插、IO使能 
					dbgInfoEx("%s: utdoa interrup --> next superFram mode is: %d \n", __FUNCTION__, nextSuperMode);
				}

                /* 3、将共享标志置为0,并给中频下发dmimo使能状态 */
                if (BSP_OK == retVal)
                {
                    BspHalAdaptUtdoaSetCovertFlag(0);
                    dmmEn = BspGetUtDmmCoexistDmmSt();
                    BspSetUtDmmCoexistDmmSt(dmmEn);
                    dbgInfoEx("%s>>config dmimo status, dmmEn = %d\n", __FUNCTION__,dmmEn);
                    /* Ended by AICoder, pid:9dda58309713ea9141220a9620f4d12b98268b2b */
                }
			}	
		}
		
		
	}

	return NULL;
}
/* Ended by AICoder, pid:b1ff924313a076d149a10a7410c89862a6101eb9 */

/* Started by AICoder, pid:19923g6d67eb2591493c08d5c0412213c4229d65 */
UINT32 BspGetUtDmmCoexistDmmSt()
{
    return utDmmCoexistDmmSt;
}

VOID BspUpdateDmimoExistStatus()
{
    UINT32 dmimoExistSt = 0;
    dmimoExistSt = BspGetDmmIsExist();
    utDmmCoexistDmmSt = (1 == dmimoExistSt) ? 1 : 0;
}
/* Ended by AICoder, pid:19923g6d67eb2591493c08d5c0412213c4229d65 */

/* Started by AICoder, pid:x37eff78e4ud3f514eee0b220067192059930d10 */
/* 注意周期内偏移要小于校准周期！ */
VOID BspChangeCaliPeriod(UINT32 calibPeriodValue, UINT32 offsetValue)
{
    UINT32 loop = 0;
    
    // 如果校准周期为0 ，则恢复为正常值，拔桩
    if (0 == calibPeriodValue)
    {
        for ( loop = 0; loop < UTDOA_MAX_CARR_NUM; loop++)
        {
            offset_Ut[loop]      = offset_Ut_Bak[loop];
            calibPeriod_Ut[loop] = calibPeriod_Ut_Bak[loop];
        }
    }
    // 同一个整机，不同的载波，的校准周期 和 周期内偏移的值是一样的 
    else
    {
        for( loop = 0; loop < UTDOA_MAX_CARR_NUM; loop++)
        {
            offset_Ut[loop]      = offsetValue;
            calibPeriod_Ut[loop] = calibPeriodValue;
        }
    }
}
/* Ended by AICoder, pid:x37eff78e4ud3f514eee0b220067192059930d10 */

UINT32 BspInterruptDealUtdoaThreadInit(void)
{    
	pthread_t th_id = 0;
	UINT32     ulRet = BSP_OK;

	ulRet = pthread_create(&th_id, NULL, BspInterruptDealUtdoa, NULL);

	if (0 != ulRet)
    {
        dbgErr("utdoa inteerrup create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
        BspLog(LOG_LEVEL_0,"utdoa inteerrup create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, ulRet);
    }
    else
    {
        dbgErr("utdoa inteerrup create thread<%s> success!\n",__FUNCTION__);
        BspLog(LOG_LEVEL_0,"utdoa inteerrup create thread<%s> success! \n", __FUNCTION__);
    }
	return ulRet;
    
}

/*****************************************************************************
 * 函数名称: BspSavaAppUtdoaAllCfg
 * 功能描述: 一 大遍历小遍历SRSb 信息保存接口
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */

UINT32 BspSavaAppUtdoaAllCfg(T_RruUTDOAAllCfg * pUtdoaAllCfg)
{

	UINT32 uiLoop = 0;
    UINT32 halMode = 3;
    UINT32 sCellNo = 0xffff;
    UINT32 sCarrNo = 0xffff;

    halMode = BspGetUtEnModel(pUtdoaAllCfg->UtdoaLargeSmallErgodicCfg.Enable);

	for(uiLoop = 0 ;uiLoop<UTDOA_MAX_CARR_NUM;uiLoop++)
	{
        sCellNo = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCellNo;
        sCarrNo = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCarrNo;
	    if((pUtdoaAllCfg->UtdoaCellCfg.ulCellNo == sCellNo) && (pUtdoaAllCfg->UtdoaCellCfg.ulCarrNo == sCarrNo))
	    {
		    dbgInfoEx("%s>> second  pUtdoaAllCfg[%d],ulCellNo: %d \n", __FUNCTION__, uiLoop, pUtdoaAllCfg->UtdoaCellCfg.ulCellNo);
	    	memcpy_s(s_pUtdoaAllCfg+uiLoop,sizeof(T_RruUTDOAAllCfg),pUtdoaAllCfg,sizeof(T_RruUTDOAAllCfg));
            if (UT_MODE_OFF != halMode)
            {
                memcpy_s(&(s_pUtdoaAllCfgBak[uiLoop][halMode]),sizeof(T_RruUTDOAAllCfg),pUtdoaAllCfg,sizeof(T_RruUTDOAAllCfg));
            }
	    	return uiLoop;
	    }
	}

	for(uiLoop = 0 ;uiLoop<UTDOA_MAX_CARR_NUM;uiLoop++)
	{
		if( ( s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiRadio == 0) && ( s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCellNo == 0) )
		{
			dbgInfoEx("%s>> first  pUtdoaAllCfg[%d],ulCellNo: %d \n", __FUNCTION__, uiLoop, pUtdoaAllCfg->UtdoaCellCfg.ulCellNo);
	    	memcpy_s(s_pUtdoaAllCfg+uiLoop,sizeof(T_RruUTDOAAllCfg),pUtdoaAllCfg,sizeof(T_RruUTDOAAllCfg));
            if (UT_MODE_OFF != halMode)
            {
	    	    memcpy_s(&(s_pUtdoaAllCfgBak[uiLoop][halMode]),sizeof(T_RruUTDOAAllCfg),pUtdoaAllCfg,sizeof(T_RruUTDOAAllCfg));
            }
	    	return uiLoop;
		}
	}

	dbgInfoEx("%s>> UTDOA error \n", __FUNCTION__);
	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspCaliPeriod
 * 功能描述: 四 周期校准，将校准周期存放到全局变量中，APP在小遍历的时候将校准周期IE随大结构体一起下发
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspCaliPeriod(T_UtdoaCalibPeriodCfg *pUtCalibPeriodCfg,UINT32 uiCarrLoop) 
{
    UINT32 retVal = BSP_OK; 
    
    /*保存维测*/
    ARR_BOUND_UTDOA(uiCarrLoop,UTDOA_MAX_CARR_NUM);
    memcpy_s(&s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg,sizeof(T_UtdoaCalibPeriodCfg),pUtCalibPeriodCfg,sizeof(T_UtdoaCalibPeriodCfg));
    
    return retVal;
}
/* Started by AICoder, pid:db55emb9303ac4b1446309fd1036fb602952c0cb */
UINT32 BspUtAcCtrlParaPrint(UINT32 tddSel, UINT32 acType)  /*每个管脚参数一样,AC控制不需要基础时序参数，只需要参数13 14 15给TRX_AC_EN模块使用以产生*x_acen_timing信号,且9个tdd_ac_control_timing模块参数一致*/
{
    UINT32 modeMap = BSP_OK;
    UINT32 loop = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range (maxValue is 10).\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }
    modeMap = FromAcTypeToModeMapSel(acType);
    if(modeMap == BSP_ERROR)
    {
        return BSP_ERROR;
    }
    dbgInfo(">>>>>>>%s: AcCtrlPara Output: tddSel: %d, tddMode: %d\n", __FUNCTION__, tddSel, BspGetTddSwModeSel(tddSel));
    dbgInfo(">>>>>>>TRX_AC_EN BasePara and ModeMap\n");
    for(loop = 0; loop < AC_CTRL_TYPE_NUM; loop++)
    {
      dbgInfo("acCtrlType %d\n",loop);
      dbgInfo("Tx:\n uiAcEnDly: %d[CLK@737.28], %f[us]\n uiAcDisEnDly1: %d[CLK@737.28], %f[us]\n uiAcDisEnDly2: %d[CLK@737.28], %f[us]\n uiAcEnTiming2Sel1: %d\n",
        g_utAcCtrlPara[tddSel][loop].tTxACEnPara.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_utAcCtrlPara[tddSel][loop].tTxACEnPara.uiAcEnDly),
        g_utAcCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_utAcCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly1),
        g_utAcCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_utAcCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly2),
        g_utAcCtrlPara[tddSel][loop].tTxACEnPara.uiAcEnTiming2Sel1);

      dbgInfo("Rx:\n uiAcEnDly: %d[CLK@737.28], %f[us]\n uiAcDisEnDly1: %d[CLK@737.28], %f[us]\n uiAcDisEnDly2: %d[CLK@737.28], %f[us]\n uiAcEnTiming2Sel1: %d\n",
        g_utAcCtrlPara[tddSel][loop].tRxACEnPara.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_utAcCtrlPara[tddSel][loop].tRxACEnPara.uiAcEnDly),
        g_utAcCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_utAcCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly1),
        g_utAcCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_utAcCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly2),
        g_utAcCtrlPara[tddSel][loop].tRxACEnPara.uiAcEnTiming2Sel1);

      dbgInfo("ac_sw_tdd0 ModeMapSel: %d ModeNum: %d\n",
        g_utAcCtrlPara[tddSel][loop].tAcSwMap0.uiModeMapSel[modeMap], g_utAcCtrlPara[tddSel][loop].tAcSwMap0.uiModeNum);
      dbgInfo("ac_sw_tdd1 ModeMapSel: %d ModeNum: %d\n",
        g_utAcCtrlPara[tddSel][loop].tAcSwMap1.uiModeMapSel[modeMap], g_utAcCtrlPara[tddSel][loop].tAcSwMap1.uiModeNum);
      dbgInfo("ac_sw_tdd2 ModeMapSel: %d ModeNum: %d\n",
        g_utAcCtrlPara[tddSel][loop].tAcSwMap2.uiModeMapSel[modeMap], g_utAcCtrlPara[tddSel][loop].tAcSwMap2.uiModeNum);
      dbgInfo("\n");
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:db55emb9303ac4b1446309fd1036fb602952c0cb */

/* Started by AICoder, pid:99fa9e8155u2c5e14a8709ead01e31184515980d */
VOID BspUtAcCtrlMuxParaPrint(VOID)
{
    dbgInfo(">>> %s <<< \n", __FUNCTION__);
    for (UINT32 acIdx = 0; acIdx < AC_CTRL_TYPE_NUM; acIdx++)
    {
        dbgInfo(" ------------acIndex:%d------------------ \n",acIdx);
        dbgInfo("uiAcCtrl4Sel1:    %d\n", g_utAcCtrlMux[acIdx].uiAcCtrl4Sel1);
        dbgInfo("uiAcCtrlFdd4Sel1: %d\n", g_utAcCtrlMux[acIdx].uiAcCtrlFdd4Sel1);
        dbgInfo("uiAcCtrl2Sel1:    %d\n", g_utAcCtrlMux[acIdx].uiAcCtrl2Sel1);
        dbgInfo("uiAcOut3Sel1:     %d\n", g_utAcCtrlMux[acIdx].uiAcOut3Sel1);
        dbgInfo("uiAcCtrlOutSel:   %d\n", g_utAcCtrlMux[acIdx].uiAcCtrlOutSel);
        dbgInfo(" ---------------------------------------- \n");
    }
}
/* Ended by AICoder, pid:99fa9e8155u2c5e14a8709ead01e31184515980d */

/* Started by AICoder, pid:5207chb8d3s0e821419e09f7f093ba443cd0d88a */
UINT32 BspUtSetAcCtrlPara(UINT32 chan, UINT32 radioMode)
{
    UINT32 tddId = BSP_ERROR;
    UINT32 chanMask = BIT_SET(chan);
    T_AC_CTRL_CFG *acCtrlPara = NULL;
    UINT32 acIdx = BSP_ERROR;
    UINT32 gpNum = 0;
    UINT32 ret = BSP_OK;
    UINT32 utD1GpTime45G = 0;
    UINT32 utDUeAdv45G = 0;

    utD1GpTime45G = BspGetD1GpTime45G();
    utDUeAdv45G = BspGetDUeAdv45G();
    tddId = BspGetTxOrRxTddCfgIdByChanMask(chanMask, TX);
    ARR_BOUND_UTDOA(tddId,DPDIC_MAX_TDD_NUM);

    acIdx = utAcIndexMap[chan].offset;
    ARR_BOUND_UTDOA(acIdx,AC_CTRL_TYPE_NUM);
    acCtrlPara = &(g_utAcCtrlPara[tddId][acIdx]);
    INPUT_POINTER_CHECK_UTDOA(acCtrlPara, BSP_ERROR);
    
    acCtrlPara->tRxACEnPara.uiAcEnTiming2Sel1 = 1;
    acCtrlPara->tRxACEnPara.uiAcEnDly = 3358;
    // GP符号数*GP符号长度 - UE提前量 -- (1)符号长度和UE提前量都使用混模的（已经和中频确认过）(2)公式计算出来的结果直接强转UINT就行，无论向下/向上
    ret |= BspGetTddIoGpNum(radioMode, &gpNum);
    acCtrlPara->tRxACEnPara.uiAcDisEnDly1 = DOUBLE_US_2_UINT32_737(gpNum*utD1GpTime45G - utDUeAdv45G);
    // num文档是1，数组第一个赋值就行
    acCtrlPara->tAcSwMap0.uiModeMapSel[0]  = 1;
    acCtrlPara->tAcSwMap1.uiModeMapSel[0]  = 2;
    acCtrlPara->tAcSwMap0.uiModeNum = 1;
    acCtrlPara->tAcSwMap1.uiModeNum = 1;

    ret |= BspHalAdaptSetAcCtrlPara(acCtrlPara, tddId, acIdx);

    return ret;
}
/* Ended by AICoder, pid:5207chb8d3s0e821419e09f7f093ba443cd0d88a */

/* Started by AICoder, pid:d126co3c16a49be14d240b5330dde21c1307bd95 */
// 要按照UTDOA通道都遍历一遍
UINT32 BspUtSetAcCtrlMuxPara(UINT32 chan)
{
    UINT32 acIdx = BSP_ERROR;
    UINT32 tddId = BSP_ERROR;
    UINT32 chanMask = BIT_SET(chan);

    acIdx = utAcIndexMap[chan].offset;
    ARR_BOUND_UTDOA(acIdx,AC_CTRL_TYPE_NUM);
    tddId = BspGetTxOrRxTddCfgIdByChanMask(chanMask, TX);
    ARR_BOUND_UTDOA(tddId,DPDIC_MAX_TDD_NUM);

    g_utAcCtrlMux[acIdx].uiAcCtrl4Sel1 = tddId;
    g_utAcCtrlMux[acIdx].uiAcCtrl2Sel1 = 1;
    g_utAcCtrlMux[acIdx].uiAcCtrlOutSel = 2;

    return BspHalAdaptSetAcCtrlMuxPara(&(g_utAcCtrlMux[acIdx]), acIdx);
}
/* Ended by AICoder, pid:d126co3c16a49be14d240b5330dde21c1307bd95 */

/* Started by AICoder, pid:180deq27f1odc4c1406508edb0f8b419f11587f9 */
UINT32 BspUtSetPadCfg(UINT32 chan)
{
    UINT32 padIdx = BSP_ERROR;
    UINT32 retVal = BSP_OK;

    padIdx = utAcIndexMap[chan].uiHalPadName;
    if ((BSP_ERROR != padIdx) && (0 != padIdx))
    {
        retVal |= BspHalAdaptSetPadDs(padIdx,0x5);
        retVal|= BspHalAdaptSetPadCfgDone(padIdx,0x1);
    }
    
    return retVal;
}
/* Ended by AICoder, pid:180deq27f1odc4c1406508edb0f8b419f11587f9 */

/* Started by AICoder, pid:4b035i98e1r9a321400d08cc10f04a2078814389 */
UINT32 BspUtByPassSubLnaFun(UINT32 chanMask, UINT32 radio)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    for ( loop = 0; loop < QCELL_UTDOA_MAX_CHAN_NUM; loop++)
    {
        if ( (chanMask & (0X1 << loop)) != 0 )
        {
            retVal |= BspUtSetAcCtrlPara(loop,radio);
            retVal |= BspUtSetAcCtrlMuxPara(loop);
            retVal |= BspUtSetPadCfg(loop);
        }
    }
    
    return retVal;
}
/* Ended by AICoder, pid:4b035i98e1r9a321400d08cc10f04a2078814389 */

/* Started by AICoder, pid:h2b468391av0ec6149990acfe0a0151ee940f86e */
UINT32 BspUtByPassSubLna(UINT32 chanMask, UINT32 radio)
{
    UINT32 tddId = BspGetTxOrRxTddCfgIdByChanMask(chanMask, TX);

    BspGetAcCtrlParaUt(g_utAcCtrlPara);     // ByPass 二级低噪放：调用一次即可
    BspGetAcCtrlMux(g_utAcCtrlMux);         // ByPass 二级低噪放：调用一次即可
    BspHalAdaptSetAcCtrlModeMapSel(tddId,0);    // ByPass 二级低噪放：都传 0 即可,第二次修改，参数1修改为传 tddId
    BspUtByPassSubLnaFun(chanMask, radio);  // ByPass 二级低噪放：调用一次即可

    return BSP_OK;
}
/* Ended by AICoder, pid:h2b468391av0ec6149990acfe0a0151ee940f86e */

/* Started by AICoder, pid:3e00f62d5b064014ab407c15a7251564 */
/* Started by AI-VerifyCI-KwCov, pid:3e00f62d5b064014ab407c15a7251564 */ 
UINT32 BspUtByPassSubLnaForApp(VOID)
{
    // UINT32 carrLoop = 0;

    // 二级低噪放开关， 不能使用 utCarrNum 做边界，这个统计的只是目前有效的载波数量，而 s_pUtdoaAllCfg 保存的则是所有的不重复的载波信息，
    // 不关心是否有效。 假设两个载波，一个有效一个无效，有效载波在 s_pUtdoaAllCfg[1] 位置，则使用 utCarrNum 的话，遍历不到位置 1 的。
    // for(carrLoop = 0; carrLoop<UTDOA_MAX_CARR_NUM; carrLoop++)
    // {
    //     if ((s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiChanMask != 0) && (((UINT32)s_pUtdoaAllCfg[carrLoop].UtdoaLargeSmallErgodicCfg.Enable) != 0))
    //     {
    //         BspUtByPassSubLnaFun(s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiChanMask,s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiRadio);
    //     }
    // }

    return BSP_OK;
}
/* Ended by AI-VerifyCI-KwCov, pid:3e00f62d5b064014ab407c15a7251564 */
/* Ended by AICoder, pid:3e00f62d5b064014ab407c15a7251564 */ 

/*****************************************************************************
 * 函数名称: BspSetUtdoaFrAdjustVal
 * 功能描述: 光口帧头调整量解耦 - UTDOA
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUtdoaFrAdjustVal(T_RruUTDOAAllCfg  *pUtdoaAllCfg)
{
    UINT32 chanMask = 0;
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;
    chanMask   = pUtdoaAllCfg->UtdoaCellCfg.uiChanMask;
    for(chan = 0; chan < QCELL_UTDOA_MAX_CHAN_NUM; chan++)
    {
        if((chanMask & ((UINT32)0x1 << chan)) !=0)
        {
            retVal = BspHalAdaptSetFeatureFrAdjustVal(chan, pUtdoaAllCfg->UtdoaCellCfg.ulCarrNo, pUtdoaAllCfg->UtdoaCellCfg.uiRadio, E_QCELL_UTDOA_FUNCION);
        }
    }   
    return retVal;
}


/*****************************************************************************
 * 函数名称: BspReconfigConflictCell
 * 功能描述: 重新配置冲突的小区参数
 * 输入参数: pNewCfg - 新下发的UTDOA配置
 *           conflictIdx - 冲突配置的索引
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 用新参数覆盖旧参数并重新配置底层
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspReconfigConflictCell(T_RruUTDOAAllCfg *pNewCfg, UINT32 conflictIdx)
{
    UINT32 halMode = 0;
    T_RruUTDOAAllCfg tempCfg = {0};

    /* 保存旧配置的小区号和载波号等不变参数 */
    UINT32 oldCellNo = s_pUtdoaAllCfg[conflictIdx].UtdoaCellCfg.ulCellNo;
    UINT32 oldCarrNo = s_pUtdoaAllCfg[conflictIdx].UtdoaCellCfg.ulCarrNo;
    UINT32 oldChanMask = s_pUtdoaAllCfg[conflictIdx].UtdoaCellCfg.uiChanMask;
    UINT32 oldRadio = s_pUtdoaAllCfg[conflictIdx].UtdoaCellCfg.uiRadio;
    UINT32 oldBandWidth = s_pUtdoaAllCfg[conflictIdx].UtdoaCellCfg.uiCarrBandWidth;

    /* 复制新配置的内容 */
    memcpy_s(&tempCfg, sizeof(T_RruUTDOAAllCfg), pNewCfg, sizeof(T_RruUTDOAAllCfg));

    /* 恢复不变的参数 */
    tempCfg.UtdoaCellCfg.ulCellNo = oldCellNo;
    tempCfg.UtdoaCellCfg.ulCarrNo = oldCarrNo;
    tempCfg.UtdoaCellCfg.uiChanMask = oldChanMask;
    tempCfg.UtdoaCellCfg.uiRadio = oldRadio;
    tempCfg.UtdoaCellCfg.uiCarrBandWidth = oldBandWidth;

    /* 获取HAL模式 */
    halMode = BspGetUtEnModel(tempCfg.UtdoaLargeSmallErgodicCfg.Enable);

    /* 更新s_pUtdoaAllCfg中的旧配置 */
    memcpy_s(&s_pUtdoaAllCfg[conflictIdx], sizeof(T_RruUTDOAAllCfg), &tempCfg, sizeof(T_RruUTDOAAllCfg));

    /* 更新s_pUtdoaAllCfgBak中相应的配置 */
    if(UT_MODE_OFF != halMode)
    {
        memcpy_s(&(s_pUtdoaAllCfgBak[conflictIdx][halMode]), sizeof(T_RruUTDOAAllCfg), &tempCfg, sizeof(T_RruUTDOAAllCfg));
    }

    /* 重新配置底层 */
    BspHandleUtdoaAllCfg(conflictIdx);

    BspLog(LOG_LEVEL_0, "%s >>> Reconfigured conflict cell: oldCell=%d, oldCarr=%d\n",
            __FUNCTION__, oldCellNo, oldCarrNo);

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspCheckSameChanMaskDiffCell
 * 功能描述: 检查同一组通道是否存在不同小区号的UTDOA配置
 * 输入参数: pNewCfg - 新下发的UTDOA配置
 *           pConflictIdx - 用于保存冲突的配置索引
 * 输出参数: pConflictIdx - 冲突配置的索引
 * 返 回 值: BSP_OK - 存在冲突需要处理, BSP_ERROR - 无冲突
 * 其它说明: 当同一通道组存在不同小区号时返回BSP_OK
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspCheckSameChanMaskDiffCell(T_RruUTDOAAllCfg *pNewCfg)
{
    UINT32 uiLoop = 0;
    UINT32 newChanMask = pNewCfg->UtdoaCellCfg.uiChanMask;
    UINT32 newCellNo = pNewCfg->UtdoaCellCfg.ulCellNo;
    UINT32 newCarrNo = pNewCfg->UtdoaCellCfg.ulCarrNo;


    /* 遍历已保存的配置，查找同一通道组但不同小区号的情况 */
    for(uiLoop = 0; uiLoop < UTDOA_MAX_CARR_NUM; uiLoop++)
    {
        BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK_UTDOA(uiLoop,UTDOA_MAX_CARR_NUM);
        /* 跳过空配置和自身配置 ,这个可以，uiRadio必不为0，如果存在配置的情况*/
        if((s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiRadio == 0) &&
            (s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCellNo == 0))
        {
            continue;
        }

        /* 跳过相同小区号和载波号的配置，UTDOA不可能出现载波号相同的情况（UT只针对TDDNR，同一制式不可能载波号相同） */
        if((s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCellNo == newCellNo) &&
            (s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCarrNo == newCarrNo))
        {
            continue;
        }

        /* 检查通道掩码是否有重叠 */ // ZHY:这个逻辑也马马虎虎可以吧，应该用等于，不过这个业务上也对
        if((s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiChanMask & newChanMask) != 0)
        {
            /* 发现同一组通道存在不同小区号的配置 */            
            BspLog(LOG_LEVEL_0, "%s >>> Handled conflict: reconfigured existing cell with new parameters\n", __FUNCTION__);
            BspLog(LOG_LEVEL_0, "%s >>> Found conflict: chanMask=0x%x, oldCarrNo=%d, newCarrNo=%d\n",
                    __FUNCTION__, newChanMask, s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCarrNo, newCarrNo);
            /* 存在冲突，先用新参数覆盖旧参数并重新配置 */
            BspReconfigConflictCell(pNewCfg, uiLoop);
        }
    }

    return BSP_OK;

}

/*****************************************************************************
 * 函数名称: BspSetUtdoaAllConfigInfoAnalysis
 * 功能描述: 一 大遍历小遍历SRS app接口
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 oneTimeFlag = 0;/* 字面含义：只有一次 */
UINT32 BspSetUtdoaAllConfigInfoAnalysis(T_RruUTDOAAllCfg * pUtdoaAllCfg)
{
    UINT32 uiCarrLoop = 0 ;
    UINT32 carrNumber = pUtdoaAllCfg->UtdoaCellCfg.ulCarrNo;
    UINT32 cellNumber = pUtdoaAllCfg->UtdoaCellCfg.ulCellNo;
    UINT32 enMode     = pUtdoaAllCfg->UtdoaLargeSmallErgodicCfg.Enable;
    // UINT32 chanMask   = pUtdoaAllCfg->UtdoaCellCfg.uiChanMask;
    // UINT32 radio      = pUtdoaAllCfg->UtdoaCellCfg.uiRadio;

    /* Started by AICoder, pid:we50eoc4a8qe40e14c2f0827c07a360dbc444630 */
    /*UT大遍历场景下给中频下发去使能DMM*/
    if(BSP_UTDOA_MODE_LARGE_ERGODIC == enMode)
    {
        utDmmCoexistDmmSt = 1;
        BspLog(LOG_LEVEL_0,"%s >>> utdoa large ergodic, disables dmimo\n", __FUNCTION__);
    }
    /* Ended by AICoder, pid:we50eoc4a8qe40e14c2f0827c07a360dbc444630 */

    if (0 == oneTimeFlag)
	{
	    BspSaveUtdoaAacDate_TNR();    /* 保存AAC数据 */
        // BspUtByPassSubLna(chanMask, radio);  // ByPass 二级低噪放：调用一次即可

        oneTimeFlag = oneTimeFlag + 1;
	}

    /* 检查是否存在同一通道组不同小区号的情况 */
    BspCheckSameChanMaskDiffCell(pUtdoaAllCfg);


    // 保存小遍历校准周期信息
    // BspCaliPeriod(&(pUtdoaAllCfg->UtdoaCalibPeriodCfg), pUtdoaAllCfg->UtdoaCellCfg.ulCarrNo); 应该不需要了

    uiCarrLoop = BspSavaAppUtdoaAllCfg(pUtdoaAllCfg); /* 保存APP下发的配置信息 */

    BspSetUtCarrNum(carrNumber, enMode);
    //BspSetUtdoaFrAdjustVal(pUtdoaAllCfg); //光口帧头调整量，//中频提供的临时规避方案（无线帧号时延配置方案）
	BspHandleUtdoaAllCfg(uiCarrLoop);/* 将APP下发的数据转换成中频需要的数据并配置给中频 */

    BspLog(LOG_LEVEL_0,"%s >>>ulCellNo:%d ulCarrNo:%d enMode:%d \n", __FUNCTION__, cellNumber,carrNumber, pUtdoaAllCfg->UtdoaLargeSmallErgodicCfg.Enable); // 记录下发参数的次数

	return BSP_OK;
}

#if 0
/*****************************************************************************
 * 函数名称: BspSavaAppUtdoaSrsCfg
 * 功能描述: 二UTDOA SRS定位接口
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
/*UINT32 BspSavaAppUtdoaSrsCfg(T_RruUTDOASRSAllCfg * pUtdoaSrsCfg)
{
	UINT32 uiLoop = 0;
	for(uiLoop =0 ;uiLoop<UTDOA_MAX_CARR_NUM;uiLoop++)
	{
		 if(pUtdoaSrsCfg->UtdoaSrsCellCfg.ulCellNo == s_pUtdoaSrsAllCfg[uiLoop].UtdoaSrsCellCfg.ulCellNo)
		 {
			 dbgInfoEx("%s>> second  s_pUtdoaSrsAllCfg[%d],ulCellNo: %d \n", __FUNCTION__, uiLoop,pUtdoaSrsCfg->UtdoaSrsCellCfg.ulCellNo);
			 memcpy_s(s_pUtdoaSrsAllCfg+uiLoop,sizeof(T_RruUTDOASRSAllCfg),pUtdoaSrsCfg,sizeof(T_RruUTDOASRSAllCfg));
			 return uiLoop;
		 }
	}
	for(uiLoop =0 ;uiLoop<UTDOA_MAX_CARR_NUM;uiLoop++)
	{
		 if( (s_pUtdoaSrsAllCfg[uiLoop].UtdoaSrsCellCfg.ulCellNo == 0) && (s_pUtdoaSrsAllCfg[uiLoop].UtdoaSrsCellCfg.uiRadio == 0) )
		 {
			 dbgInfoEx("%s>> first  s_pUtdoaSrsAllCfg[%d],ulCellNo: %d \n", __FUNCTION__, uiLoop,pUtdoaSrsCfg->UtdoaSrsCellCfg.ulCellNo);
			 memcpy_s(s_pUtdoaSrsAllCfg+uiLoop,sizeof(T_RruUTDOASRSAllCfg),pUtdoaSrsCfg,sizeof(T_RruUTDOASRSAllCfg));
			 return uiLoop;
		 }
	}
	return BSP_OK;
}
*/
#endif

/*****************************************************************************
 * 函数名称: BspUtdoaIsOpenGp()
 * 功能描述:高层做完TS后会调用此接口，底层根据UT使能状况去判断是否打开GP开关
 * 输入参数:
 * 输出参数: BSP_OK
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 
 *      问题现象：UTDOA的GP开关被关，手动打开也会被关。
 *      问题原因：周期TS中关掉了
 *      解决方案：高层在做周期TS关掉GP开关后，调用一个接口通知BSP，BSP在接口内部判断UT是否使能，使能的情况下去打开GP开关，UT不使能的情况下不做处理（因为此时可能做DMM）。
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspUtdoaIsOpenGp(VOID)
{
    UINT32 chan     = 0;
    UINT32 carrLoop = 0;
    UINT32 chanMask = 0;
    UINT32 ret = BSP_OK;
    UINT32 dly = 2000;
    
    for( carrLoop = 0; carrLoop < UTDOA_MAX_CARR_NUM; carrLoop++ )
    {
        chanMask = s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiChanMask;

        if ( 0 != s_pUtdoaAllCfg[carrLoop].UtdoaLargeSmallErgodicCfg.Enable )
        {
            BspSetUtdoaDlDtxPaAndAmpGpSel(chanMask,1); // 增加IO的gp使能
            for ( chan = 0; chan < QCELL_UTDOA_MAX_CHAN_NUM; chan++ )
            {
                if( (chanMask & (0X1 << chan)) != 0 )
                {
                    BspHalAdaptSetTsGpEn(chan,UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
                    BspHalAdaptSetDlTimingDlTddDly(chan,dly);

                }
            }
        }
    }

    return ret;
}


/*****************************************************************************
 * 函数名称: BspCleanALLUtdoaCfg
 * 功能描述:清除所有UTDOA配置。 //ZHY:s_pUtdoaAllCfgBak  这个没清？？？
 * 输入参数:
 * 输出参数: 载波存储序号
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspCleanAllUtdoaCfg(VOID) 
{
    UINT32 carrLoop = 0 ;
    UINT32 chan = 0;
    UINT32 chanMask = 0;
    UINT32 utMode = 0;
    UINT32 carrNo = 0;
    UINT32 radio = 0;
    UINT32 en = 0;
    dbgInfo("%s>> \n", __FUNCTION__);
    BspLog(LOG_LEVEL_0,"%s>>>\n", __FUNCTION__);
    utCarrNum = 0;
    for(carrLoop = 0; carrLoop < UTDOA_MAX_CARR_NUM; carrLoop++)
    {
        utCarrNumArr[carrLoop] = UT_INVALID_CARR_NUMBER_FLAG;
        chanMask = s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiChanMask;
        radio = s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.uiRadio;
        carrNo   = s_pUtdoaAllCfg[carrLoop].UtdoaCellCfg.ulCarrNo  ;
        for (chan = 0; chan < QCELL_UTDOA_MAX_CHAN_NUM; chan++)
        {
            if((chanMask & (0X1 << chan)) != 0)
            {
                BspHalAdaptUtSendAacEn(chan,carrNo,radio,en);
                BspHalAdaptUtSampleEn(chan,carrNo,radio,en);
                BspHalAdaptUtInsertAacEn(chan,carrNo,radio,en);
                BspHalAdaptUtDlIoEn(chan, UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
                BspHalAdaptUtUlIoEn(chan, UT_DMM_RESOURCE_EN);
                BspHalAdaptSetTsGpEn(chan,UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
            }
        }

        for (utMode = 0; utMode < UT_VALIDMODE_NUM; utMode++)
        {
            memset_s(&s_pUtdoaAllCfgBak[carrLoop][utMode],sizeof(T_RruUTDOAAllCfg),0,sizeof(T_RruUTDOAAllCfg));
        }

        memset_s(&s_pUtdoaAllCfg[carrLoop],sizeof(T_RruUTDOAAllCfg),0,sizeof(T_RruUTDOAAllCfg));
        memset_s(&bspSaveDateUtSendParaCfg[carrLoop],sizeof(T_BspHalAdaptUtSendParaCfg),0,sizeof(T_BspHalAdaptUtSendParaCfg));
        memset_s(&bspSaveDateUtSampleParaCfg[carrLoop],sizeof(T_BspHalAdaptUtSampleParaCfg),0,sizeof(T_BspHalAdaptUtSampleParaCfg));
        memset_s(&bspSaveDateUtInsertParaCfg[carrLoop],sizeof(T_BspHalAdaptUtInsertParaCfg),0,sizeof(T_BspHalAdaptUtInsertParaCfg));

        memset_s(&pHalAdaptUtSendParaCfg,sizeof(T_BspHalAdaptUtSendParaCfg),0,sizeof(T_BspHalAdaptUtSendParaCfg));
        memset_s(&pHalAdaptUtSampleParaCfg,sizeof(T_BspHalAdaptUtSampleParaCfg),0,sizeof(T_BspHalAdaptUtSampleParaCfg));
        memset_s(&pHalAdaptUtInsertParaCfg,sizeof(T_BspHalAdaptUtInsertParaCfg),0,sizeof(T_BspHalAdaptUtInsertParaCfg));
    }
    // ZHY:给DSP发送0018消息去停止DMM？UTDOA不需要停止吗
    // BspDpdSetDmimoCtrl(0,0,0x2D2D); 

    // 清除中频UTDOA底层的变量
    BspHalAdaptUtdoaClear();

    // 设置UT模式为关闭
    BspHalAdaptUtSetMode(UT_MODE_OFF);

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspDmimoMasterDiable
 * 功能描述: UTDOA 、DMM 和 TS 流程互斥，TS去使能,此时不会触发校准使能。开的话有校准使能开
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspUtdoaMasterEnable(UINT32 chanMask, UINT32 carrId, UINT32 radioMode,UINT32 en)
{
    UINT32 chanLoop = 0;
    UINT32 dlyNs =2000;

    BspSetUtdoaDlDtxPaAndAmpGpSel(chanMask,UT_DMM_RESOURCE_EN);  // 中频：无论何时，都使能GP，不要关闭
    
    for(chanLoop =0 ;chanLoop<QCELL_UTDOA_MAX_CHAN_NUM;chanLoop++)
    {
        if(chanMask & ((UINT32)0x1 << chanLoop))
        {
            BspHalAdaptUtSendAacEn(chanLoop,carrId,radioMode,en);
			BspHalAdaptUtSampleEn(chanLoop,carrId,radioMode,en);
			BspHalAdaptUtInsertAacEn(chanLoop,carrId,radioMode,en);
            // BspSetUtIoEn(chanLoop,TX,en); // 已在接口内做和DMM的互斥
            // BspSetUtIoEn(chanLoop,RX,en); // 已在接口内做和DMM的互斥 ZHY:互斥代码，先注释掉
            BspHalAdaptUtDlIoEn(chanLoop, UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
            BspHalAdaptUtUlIoEn(chanLoop, UT_DMM_RESOURCE_EN);
            // if ( !((DMM_UT_PUBLIC_EN_ON == BspGetDmmIoEnVar()) && (0 == en)) ) // 当DMM还存在并且下发的是去使能，则不能操作关闭GP和Timing延时
            // { ZHY:互斥代码先注释掉，后续放开
                BspHalAdaptSetDlTimingDlTddDly(chanLoop,dlyNs);
                BspHalAdaptSetTsGpEn(chanLoop,UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
            // }
        }
    }
    return  BSP_OK;
}


#if 0
/*****************************************************************************
 * 函数名称: BspGetSuperFrameNo
 * 功能描述: 光口超帧号同步获取
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetSuperFrameNo(VOID)
{
	UINT32 retVal = BSP_OK;
	UINT32 ulSuperFrameNo = 0;
	ulSuperFrameNo = IcHalApiGetSynPsyncSuperFrameNo();
	dbgInfo("got SuperFrameNo is %d\n",ulSuperFrameNo);

	return ulSuperFrameNo;
}
 
/*****************************************************************************
 * 函数名称: BspGetSuperFrameNoAddr
 * 功能描述: 获取超帧号地址
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetSuperFrameNoAddr(VOID)
{
	UINT32 retVal = BSP_OK;
	UINT32 ulAddrofSuperFraNo = 0;
	ulAddrofSuperFraNo = IcHalApiGetSynPsyncSuperFrameNoAddr();
	dbgInfo("got SuperFrameNo address is %d\n",ulAddrofSuperFraNo);

	return retVal;
}



/*****************************************************************************
 * 函数名称: BspSetUtdoaConfigInfoAnalysis
 * 功能描述: utdoa参数配置处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetUtdoaConfigInfoAnalysis( UINT32 uiCarrLoop)
{
	// T_BspHalAdaptUtSendParaCfg  pDmm = {0};

	// UINT32 uiDifChan = 0;

	// BspGetUtdoaAacDate(uiDifChan,uiCarrId,uiRadioMode,&pDmm.uiAcBaseSeque[0]);

	// BspHalAdaptUtSendAacCfg(uiDifChan,uiCarrId,uiRadioMode,pDmm);


	return BSP_OK;
}

/*一 大遍历小遍历接口维测*/
UINT32 printutdoalsecfg(VOID)
{

	UINT32 uiLoop = 0;
	UINT32 ulCellNo = 0;
	UINT32 ulCarrNo = 0;
	UINT32 uiChanMask = 0;
	UINT32 uiRadio = 0;
	UINT32 uiCarrBandWidth = 0;
	UCHAR ucEnable = 0;
	UINT32 i =0;

	for(uiLoop =0 ;uiLoop<UTDOA_MAX_CARR_NUM;uiLoop++)
	{

		ulCellNo = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCellNo;
		ulCarrNo = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCarrNo;
		uiChanMask = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiChanMask;
		uiRadio = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiRadio;
		uiCarrBandWidth = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiCarrBandWidth;

	    dbgInfo("ulCellNo:%d,ulCarrNo:%d, uiChanMask:%d,uiRadio:%d,uiCarrBandWidth:%d\n",ulCellNo,ulCarrNo,uiChanMask,uiRadio,uiCarrBandWidth);

	    dbgInfo("uiEnable:%d\n,",ucEnable);
	    dbgInfo("AACFrameStart:%d\n,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACFrameStart);
	    dbgInfo("AACFrameEnd:%d\n,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACFrameEnd);
	    dbgInfo("AACGroup:%d\n,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACGroup);
	    dbgInfo("AACGroupStartFrame\n");
		for(i =0 ;i<UTDOA_AAC_GROUP_NUM;i++)
		{
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACGroupStartFrame[i]);
		}
		 dbgInfo("\n");

		 dbgInfo("AACGroupEndFrame\n");
		for(i =0 ;i<UTDOA_AAC_GROUP_NUM;i++)
		{
			dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACGroupEndFrame[i]);
		}
		dbgInfo("\n");

		dbgInfo("AACSendFrame\n");
		for(i =0 ;i<UTDOA_AAC_FRAME_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			dbgInfo("0x%x,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACSendFrame[i]);


		}
		dbgInfo("\n");

		dbgInfo("AACCaputeFrame\n");
		for(i =0 ;i<UTDOA_AAC_FRAME_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			dbgInfo("0x%x,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACCaputeFrame[i]);


		}
		dbgInfo("\n");

		dbgInfo("AACReturnFrame\n");
		for(i =0 ;i<UTDOA_AAC_FRAME_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			dbgInfo("0x%x,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.AACReturnFrame[i]);

		}
		dbgInfo("\n");
		dbgInfo("RttStartFrame:%d\n,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.RttStartFrame);
		dbgInfo("RttEndFrame:%d\n,",s_pUtdoaAllCfg[uiLoop].UtdoaLargeSmallErgodicCfg.RttEndFrame);
	}


	return BSP_OK;
}

/*二UTDOA SRS定位维测接口*/
UINT32 printutdosrscfg(VOID)
{
	UINT32 uiLoop = 0;
	UINT32 ulCellNo = 0;
	UINT32 ulCarrNo = 0;
	UINT32 uiChanMask = 0;
	UINT32 uiRadio = 0;
	UINT32 uiCarrBandWidth = 0;
	UINT32 i =0;

	for(uiLoop =0 ;uiLoop<UTDOA_MAX_CARR_NUM;uiLoop++)
	{
		ulCellNo = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCellNo;
		ulCarrNo = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.ulCarrNo;
		uiChanMask = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiChanMask;
		uiRadio = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiRadio;
		uiCarrBandWidth = s_pUtdoaAllCfg[uiLoop].UtdoaCellCfg.uiCarrBandWidth;
	    dbgInfo("ulCellNo:%d,ulCarrNo:%d, uiChanMask:%d,uiRadio:%d,uiCarrBandWidth:%d\n",ulCellNo,ulCarrNo,uiChanMask,uiRadio,uiCarrBandWidth);

	    dbgInfo("AACSendTimeSlot\n");
		for(i =0 ;i<UTDOA_SEND_TIME_SLOT_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.AACSendTimeSlot[i]);
		}
		dbgInfo("\n");

	    dbgInfo("AACSendSym:%d \n",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.AACSendSym);

		dbgInfo("AACCaptureTimeSlot\n");
	    for(i =0 ;i<UTDOA_CAPTURE_TIME_SLOT_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.AACCaptureTimeSlot[i]);
		}
		dbgInfo("\n");

		dbgInfo("AACReturnTimeSlot\n");
	    for(i =0 ;i<UTDOA_RETURN_TIME_SLOT_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.AACReturnTimeSlot[i]);
		}
		dbgInfo("\n");

		dbgInfo("AACReturnSymPos\n");
	    for(i =0 ;i<UTDOA_AAC_RETURN_SYM_POS;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.AACReturnSymPos[i]);
		}
		dbgInfo("\n");

		dbgInfo("RttSendTimeSlot\n");
	    for(i =0 ;i<RTT_SRS_TIME_SLOT_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.RttSendTimeSlot[i]);
		}
		dbgInfo("\n");

	    dbgInfo("RttSendSym:%d \n",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.RttSendSym);

		dbgInfo("RttReturnTimeSlot\n");
	    for(i =0 ;i<RTT_SRS_TIME_SLOT_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.RttReturnTimeSlot[i]);
		}
		dbgInfo("\n");

	    dbgInfo("RttReturnSym:%d \n",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.RttReturnSym);

		dbgInfo("SRSCaptureTimeSlot\n");
	    for(i =0 ;i<RTT_SRS_TIME_SLOT_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.SRSCaptureTimeSlot[i]);
		}
		dbgInfo("\n");

	    dbgInfo("SRSCaptureSym:%d \n",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.SRSCaptureSym);
	    dbgInfo("SRSCaptureCycle:%d \n",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.SRSCaptureCycle);
	    dbgInfo("SRSReturnFrame:%d \n",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.SRSReturnFrame);

		dbgInfo("SRSReturnTimeSlot\n");
	    for(i =0 ;i<RTT_SRS_TIME_SLOT_NUM;i++)
		{
			if((i!=0) && (!(i%8)) )
			{
				dbgInfo("\n");
			}
			 dbgInfo("%d,",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.SRSReturnTimeSlot[i]);
		}
		dbgInfo("\n");

	    dbgInfo("SRSReturnSym:%d \n",s_pUtdoaAllCfg[uiLoop].UtdoaSrsCfg.SRSReturnSym);

	}
	return BSP_OK;

}
/*
UINT32 printutsuperframe(VOID)
{

	for (UINT32 uiCarrLoop = 0; uiCarrLoop < UTDOA_MAX_CARR_NUM; uiCarrLoop++)
	{
		dbgInfo("uiCarrLoop:%d usCalibPeriod%d  usOffset:%d \n",uiCarrLoop,s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg.usCalibPeriod,s_pUtdoaAllCfg[uiCarrLoop].UtdoaCalibPeriodCfg.usOffset);
	}
	
	dbgInfo("usCalibPeriod%d\n",s_pUtCalibPeriodCfg.usCalibPeriod);
	dbgInfo("usOffset%d\n",s_pUtCalibPeriodCfg.usOffset);
	return BSP_OK;
}
*/
#endif

/* 暂时没人调用*/
UINT32 BspSetDlGpEn(UINT32 bspChan, UINT32 radioMode, UINT32 carrId, UINT32 en)
{
    return BspHalAdaptSetTsGpEn(bspChan,UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
}

UINT32 BspOneClickCollectUtdoa(VOID)
{
	return BSP_OK;
}

/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dmimo_para.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供demimo_ic4_2模块相关定义
 * 注意事项 : 无
 * 作    者 : 
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_DMIMO_CONFIG_BLOCK_H_INCLUDED
#define FUNCLIB_DMIMO_CONFIG_BLOCK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "utdoa_ctrl_api.h"
#include "funccommon_log.h"


#define DMIMO_MAX_FRAME_SECTION_NUM (UINT32)8 //IC可支持的无线帧号最大的分段数：9段
#define DMIMO_BITMAP_WORD_LENGTH (UINT32)32 //bitmap占用的字长:32bit*32 = 1024bit
#define DMIMO_BITMAP_FRAME_NUM (UINT32)32 //bitmap占用的字长:32bit*32 = 1024bit
#define DMIMO_MAX_CARR_NUM (UINT32)3
#define DMIMO_SENDRAM_LEN  (UINT32)1024
#define DMIMO_NR_SLOTBITMAP_LEN  (UINT32)20
#define QCELL_MAX_CHAN_NUM       (UINT32)16

#ifndef SET_BIT
#define SET_BIT(n)     (1UL << (n))    /* 对bit[n]掩码 */
#endif
#ifndef REV_BIT
#define REV_BIT(n)      (~(1UL << (n)))
#endif

#define UT_DMM_RESOURCE_EN (UINT32)1 
/**************************************************************************
 *                       结构体定义
 **************************************************************************/

	typedef struct{
	    UINT32 dmimoflag;//指定标志
	    UINT32 uiChan;//指定通道
	    UINT32 uiCarrNo;//指定载波
	    UINT32 uiRadio;//指定制式
	    UINT32 uiDir;//指定上行或下行
	    UINT32 uiFrameNo;//指定上行或下行
	}T_DmimoPrintInfoSet;//时隙信息



typedef struct{
    UINT32 uiSlotBitmap;//时隙bitmap
    UINT32 uiStartFrNo;//起始帧号
    UINT32 uiEndFrNo;//结束帧号
}T_DmimoSlotInfo;//时隙信息



typedef struct{
    UINT32 uiFrNoBitmap[DMIMO_BITMAP_FRAME_NUM];  //帧号bitmap
    T_DmimoSlotInfo uiSlotInfo[DMIMO_MAX_FRAME_SECTION_NUM];  //时隙信息，每组包括：时隙bitmap，起始帧号，结束帧号。对应底层的9段帧号配置。
    UINT32 uiSymBitmap;  //符号bitmap
}T_DmimoParaUint;//单个UTDOA控制信息

typedef struct tagT_ProductDmimoCarrCfgForHal
{
        UINT32 ulCellNo;    /*保存当前下发的小区号*/
        UINT32 ulCarrNo;    /*保存当前下发的载波号*/
        UINT32 uiChanMask;    /*空口校准使能控制，0: 停止, 1:使能*/
        UINT32 uiRadio;    /*制式*/
        UINT8 ucEnable;    /*空口校准使能控制，0: 停止, 1:使能*/
        UINT16 usCalibTime;    /*DMIMO小遍历校准周期 （单位：帧）*/
        UINT16 usCalibStartFrame;    /*空口校准启动帧号(周期内）*/
        UINT16 usCalibEndFrame;    /*空口校准结束帧号(周期内）*/
        UINT8 ucAACGroupNum;    /*AAC分组数*/
        T_DmimoParaUint uiParaSendInfo;
        T_DmimoParaUint uiParaBackInfo;

}T_ProductDmimoCarrCfgForHal;

typedef struct tagT_AacGroup
{
    UINT32 uiStart;
    UINT32 uiStop;
    UINT32 uiAddr;// 每组数据时隙 bitmap 地址
}T_AacGroup;

typedef struct tagT_SlotBitmapGroup
{
    UCHAR slotBitmap[DMIMO_NR_SLOTBITMAP_LEN];
}T_SlotBitmapGroup;

#define BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK(uiNumber, uiThreshold)      \
    {                                                                   \
        if ((uiNumber) >= (uiThreshold))                                \
        {                                                               \
            dbgErr("%s: %s=%u err,should be less than %u!\n",           \
                   __FUNCTION__, #uiNumber, (uiNumber), (uiThreshold)); \
            return BSP_ERROR;                                           \
        }                                                               \
    }



UINT32 BspHandleFrameBitmap(T_DmimoParaUint *pDmimoPara);
UINT32 BspSetDmimoConfigInfoAnalysis(T_ProductDmimoCarrCfg  *pDmimoCfg);
UINT32 BspSetDmimoMasterSwitchEn(T_DmimoMasterSwitchEn  *pDmimoMasterEn);
UINT8 BspGetDmimoMasterSwitchEn( UINT32 uiCarrNo, UINT32 uiRadio);
UINT32 _BspSuperframeNumberThreadInit(void);
UINT32 BspSetDmimoUtTddCfg(T_CarrTddIndCfg *tddIndCfg);
UINT32 _BspSuperframeNumberThreadInit(void);
UINT32 BspCleanALLDmimoCfg(VOID);
UINT32 BspCleanDmimoCfgByCellNo(UINT32 ulCellNo);
UINT32 BspSetDmimoPsyncSynSwitch(UINT32 uSwitch);
UINT32 BspPsyncFrameCheck(VOID);
UINT32 BspSetQcellPsyncSyn(VOID);
UINT32 BspSetDmimoPrint(VOID);
UINT32 BspSetDmimoBankSample(UINT32 uiChan,UINT32 ulCarrNo,UINT32 uiRadio,UINT32 uiDir);
UINT32 BspSetOpt2DlPreFrCfgLog(VOID);
UINT32 BspOneClickCollectDmm(VOID);
UINT32 BspDmmSetFrAdjustVal(T_ProductDmimoCarrCfg  *pDmimoCfg);
UINT32 BspGetDmmIsExist();
UINT32 BspSetUtDmmCoexistDmmSt(UINT32 dmmEn);
#ifdef __cplusplus
}
#endif
#endif 



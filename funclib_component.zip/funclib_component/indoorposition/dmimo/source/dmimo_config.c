/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dmimo_para.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供UTDOA定位模块相关实现
 * 注意事项 : 无
 * 作    者 : 刘林涛 1
 * 创建日期 : 2022-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#include "dmimo_config.h"
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmap_a.h"
#include "rruinfo.h"
#include "ichaladapt_ic4_2.h"
#include "exprn.h"
#include "mesginter_drv.h"
#include "dpd_app.h"
#include "timedelay.h"
#include "tddcfg_ic4_2.h"

/**************************************************************************
 *                                 函数声明
 **************************************************************************/



/**************************************************************************
 *                                  宏定义
 **************************************************************************/
#define FRAME_BIT_MAP_ARRAY_LEN      ((UINT32)32)
#define UINT32_BIT_LEN               ((UINT32)32)
#define DMIMO_AAC_GROUP_LEN          ((UINT32)8)

/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/

/****************************************************************************
*                         全局变量定义                                            *
****************************************************************************/
UINT32 uiSuperframenumberFlag = 0;
UINT32 uiDirdataFlag = 0;
UINT32 uiDmimoIsExist = 0; /*DMIMO是否存在，默认不存在，置为0*/
/****************************************************************************
*                              全局变量                                         *
****************************************************************************/

T_ProductDmimoCarrCfg  s_pDmimoCfg[DMIMO_MAX_CARR_NUM] = {0};

T_DmimoMasterSwitchEn  s_pDmimoMasterSwitchEn[DMIMO_MAX_CARR_NUM] = {0};

T_ProductDmimoCarrCfgForHal s_pDmimoCfgForHal[DMIMO_MAX_CARR_NUM] = {0};

T_DmimoPrintInfoSet PrintInfoSet = {0};

UINT32 PrintDmimoCfg(VOID)
{
    UINT32 i = 0;
    UINT32 j = 0;
    UINT32 m = 0;
    UINT32 n = 0;


    for(i = 0; i < DMIMO_MAX_CARR_NUM; i++)
    {
        RedirPrintf("%s>> i:%d, ulCellNo:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].ulCellNo);
        RedirPrintf("%s>> i:%d, ulCarrNo:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].ulCarrNo);
        RedirPrintf("%s>> i:%d, uiCanMask:%x \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].uiChanMask);
        RedirPrintf("%s>> i:%d, uiRadio:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].uiRadio);
        RedirPrintf("%s>> i:%d, ucEnable:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].ucEnable);
        RedirPrintf("%s>> i:%d, usCalibTime:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].usCalibTime);
        RedirPrintf("%s>> i:%d, usCalibStartFrame:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].usCalibStartFrame);
        RedirPrintf("%s>> i:%d, usCalibEndFrame:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].usCalibEndFrame);
        RedirPrintf("%s>> i:%d, ucAACGroupNum:%d \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].ucAACGroupNum);

        for(j = 0; j < DMIMO_BITMAP_WORD_LENGTH; j++)
        {
            RedirPrintf("%s>> i:%d, SendFrNoBitmap[%d]:0x%x \n", __FUNCTION__, i, j, s_pDmimoCfgForHal[i].uiParaSendInfo.uiFrNoBitmap[j]);
            RedirPrintf("%s>> i:%d, BackFrNoBitmap[%d]:0x%x \n", __FUNCTION__, i, j, s_pDmimoCfgForHal[i].uiParaBackInfo.uiFrNoBitmap[j]);
        }
        for(m = 0; m < DMIMO_MAX_FRAME_SECTION_NUM; m++)
        {

            RedirPrintf("%s>> i:%d, SendSlotInfo[%d].uiSlotBitmap[%d]:0x%x \n",
                        __FUNCTION__, i, m, n, s_pDmimoCfgForHal[i].uiParaSendInfo.uiSlotInfo[m].uiSlotBitmap);
            RedirPrintf("%s>> i:%d, BackSlotInfo[%d].uiSlotBitmap[%d]:0x%x \n",
                        __FUNCTION__, i, m, n, s_pDmimoCfgForHal[i].uiParaBackInfo.uiSlotInfo[m].uiSlotBitmap);
            RedirPrintf("%s>> i:%d, SendSlotInfo[%d].uiStartFrNo:0x%x \n",
                        __FUNCTION__, i, m, s_pDmimoCfgForHal[i].uiParaSendInfo.uiSlotInfo[m].uiStartFrNo);
            RedirPrintf("%s>> i:%d, SendSlotInfo[%d].uiEndFrNo:0x%x \n",
                        __FUNCTION__, i, m, s_pDmimoCfgForHal[i].uiParaSendInfo.uiSlotInfo[m].uiEndFrNo);
            RedirPrintf("%s>> i:%d, BackSlotInfo[%d].uiStartFrNo:0x%x \n",
                        __FUNCTION__, i, m, s_pDmimoCfgForHal[i].uiParaBackInfo.uiSlotInfo[m].uiStartFrNo);
            dbgInfo("%s>> i:%d, BackSlotInfo[%d].uiEndFrNo:0x%x \n",
                        __FUNCTION__, i, m, s_pDmimoCfgForHal[i].uiParaBackInfo.uiSlotInfo[m].uiEndFrNo);
        }
        RedirPrintf("%s>> i:%d, SendSymBitmap:0x%x \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].uiParaSendInfo.uiSymBitmap);
        RedirPrintf("%s>> i:%d, BackSymBitmap:0x%x \n", __FUNCTION__, i, s_pDmimoCfgForHal[i].uiParaBackInfo.uiSymBitmap);
    }
    return BSP_OK;
}

UINT32 PrintFrameNo(VOID)
{
	UINT32	uiPuiFrId = 0;
	UINT32  uiPsyncFrameNo = 0;
	UINT32  uiBfn = 0;
	UINT32 ulRetVal = BSP_OK;

	BspHalAdaptGetWirelessFrId(&uiPuiFrId);
	uiPsyncFrameNo = BspFtmGetFrameNo();
	uiBfn = BspHalAdaptGetQcellBfn(0);
	RedirPrintf("%s>> hal_IF_FrId %d,uiPsyncFrameNo:%d cpirFrameNo:%d\n", __FUNCTION__, uiPuiFrId, uiPsyncFrameNo,uiBfn);
    return ulRetVal;
}

UINT32 PrintMasterSwitchEn(VOID)
{
	UINT32 ulRetVal = BSP_OK;
	UINT32 uiLoop =0;
    for(uiLoop = 0; uiLoop < DMIMO_MAX_CARR_NUM; uiLoop++)
    {
    	RedirPrintf("PrintMasterSwitchEn>> uiLoop:%d,uiCellNo:%d\n",uiLoop,s_pDmimoMasterSwitchEn[uiLoop].uiCellNo);
    	RedirPrintf("PrintMasterSwitchEn>> uiLoop:%d,uiCarrNo:%d\n",uiLoop,s_pDmimoMasterSwitchEn[uiLoop].uiCarrNo);
    	RedirPrintf("PrintMasterSwitchEn>> uiLoop:%d,uiChanMask:%x\n",uiLoop,s_pDmimoMasterSwitchEn[uiLoop].uiChanMask);
    	RedirPrintf("PrintMasterSwitchEn>> uiLoop:%d,uiRadio:%x\n",uiLoop,s_pDmimoMasterSwitchEn[uiLoop].uiRadio);
    	RedirPrintf("PrintMasterSwitchEn>> uiLoop:%d,ucMasterSwitchEn:%d\n",uiLoop,s_pDmimoMasterSwitchEn[uiLoop].ucMasterSwitchEn);
    	RedirPrintf("PrintMasterSwitchEn>> uiLoop:%d,ucCpNum:%d\n",uiLoop,s_pDmimoMasterSwitchEn[uiLoop].ucCpNum);
    }

    return ulRetVal;
}

/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
 * 函数名称: BspSaveAppDmimoConfig
 * 功能描述: 保存APP dmimo参数配置信息
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSaveAppDmimoConfig(T_ProductDmimoCarrCfg  *pDmimoCfg)
{
	UINT32 uiLoop = 0;


    for(uiLoop =0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
	    dbgInfoEx("%s>> whether DMIMO exists. s_pDmimoCfg[%d].ulCellNo: %d \n", __FUNCTION__, uiLoop, s_pDmimoCfg[uiLoop].ulCellNo);
        if((0 != pDmimoCfg->uiChanMask) && (BSP_RADIO_STANDARD_5G == pDmimoCfg->uiRadio) )
        {
            uiDmimoIsExist |= (UINT32)pDmimoCfg->ucEnable;
        }
	}

	for(uiLoop =0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
	    dbgInfoEx("%s>> second  s_pDmimoCfg[%d].ulCellNo: %d \n", __FUNCTION__, uiLoop, s_pDmimoCfg[uiLoop].ulCellNo);
	    if(pDmimoCfg->ulCellNo == s_pDmimoCfg[uiLoop].ulCellNo)
	    {
	    	memcpy_s(s_pDmimoCfg+uiLoop,sizeof(T_ProductDmimoCarrCfg),pDmimoCfg,sizeof(T_ProductDmimoCarrCfg));
	    	return BSP_OK;
	    }
	}


	for(uiLoop = 0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
	    dbgInfoEx("%s>> first s_pDmimoCfg[%d].ulCellNo: %d,s_pDmimoCfg[%d].uiRadio: %d \n", __FUNCTION__, uiLoop, s_pDmimoCfg[uiLoop].ulCellNo, uiLoop, s_pDmimoCfg[uiLoop].uiRadio);
		if( (s_pDmimoCfg[uiLoop].ulCellNo == 0) && (s_pDmimoCfg[uiLoop].uiRadio == 0) )
		{
	    	memcpy_s(s_pDmimoCfg+uiLoop,sizeof(T_ProductDmimoCarrCfg),pDmimoCfg,sizeof(T_ProductDmimoCarrCfg));
	    	return BSP_OK;
		}
	}

	return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspGetUtDlIoCfg
 * 功能描述: 将处理好的 数据发给HAL层
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetUtDlIoCfg(UINT32 uiDifChan,T_BspHalAdaptUtDlIoPara * pUtIo)
{
	UINT32 ulRetVal = BSP_OK;
	UINT32 uiTxen = 0;
	UINT32 uiTxPa = 0;
	ulRetVal |= BspGetTxEnIoInfoByRfChn(uiDifChan,LINK_TYPE_TX,&uiTxen);/*qcell将AMP当TXEN使用*/
	pUtIo->uiAmpIdx = uiTxen;

	ulRetVal |= BspGetPaIoInfoByRfChn(uiDifChan,LINK_TYPE_TX,&uiTxPa);
	pUtIo->uiPaIdx = uiTxPa;
    return ulRetVal;
}
/*****************************************************************************
 * 函数名称: BspGetUtDlIoCfg
 * 功能描述: 将处理好的 数据发给HAL层
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspGetUtUlIoCfg(UINT32 uiDifChan,T_BspHalAdaptUtUlIoPara * pUtIo)
{
	UINT32 ulRetVal = BSP_OK;
	ulRetVal |=BspGetRxEnIoInfoByRfChn(uiDifChan,LINK_TYPE_RX,&pUtIo->uiRxenIdx);
	ulRetVal |=BspGetLnaIoInfoByRfChn(uiDifChan,LINK_TYPE_RX,&pUtIo->uiLnaIdx);
    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspSetDlDtxPaAndAmpGpSel
 * 功能描述: 做dmimo时要打开对应的GP不能做DTX节能
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDlDtxPaAndAmpGpSel(UINT32 ulChanMask,UINT32 uiSwitch)
{
	UINT32 ulRetVal = BSP_OK;
	UINT32 uiChanLoop = 0;
	UINT32 uiTddCfgId = 0;

	if(1 == uiSwitch)
	{
	     uiTddCfgId = BspGetTddCfgIdByChanMask(ulChanMask);
	     uiTddCfgId = uiTddCfgId+1;/*和红平确认tdd套数从1开始*/
	}
	else
	{
		uiTddCfgId = 9;
	}
    dbgInfoEx("%s>>  ulChanMask:%d, uiTddCfgId:%d\n", __FUNCTION__,  ulChanMask, uiTddCfgId);
    for (uiChanLoop = 0; uiChanLoop < QCELL_MAX_CHAN_NUM; uiChanLoop++) // ulChanMask 一共32bit，最大循环到31
    {
    	if(ulChanMask & (0x1 << uiChanLoop))
    	{
    	    dbgInfoEx("%s>> uiChanLoop:%d, uiTddCfgId:%d\n", __FUNCTION__, uiChanLoop, uiTddCfgId);
    		ulRetVal = BspHalAdaptSetDlDtxPaGpSel(uiChanLoop,uiTddCfgId);
    		ulRetVal = BspHalAdaptSetDlDtxAmpGpSel(uiChanLoop,uiTddCfgId);
    	}
    }
    return ulRetVal;
}

/*****************************************************************************
 * 函数名称: BspSetDmimoHalConfig
 * 功能描述: 将处理好的 数据发给HAL层
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoHalConfig(UINT32  uiCarrLoop)
{
    UINT32  ulChanMask = 0;
    UINT32 uiLoop = 0;
    UINT32 i = 0;
    UINT32 j = 0;
    UINT32 uiDifChan = 0;
    UINT32 uiCarrId = 0;
    UINT32 uiRadioMode = 0;
    UINT8 ucEn = 0;
    UINT8 ucMasterEn = 0;
    T_BspHalAdaptUtDmimoParaCfg dmimoSendParaHalCfg = {0};
    T_BspHalAdaptUtDmimoParaCfg dmimoBackParaHalCfg = {0};
    T_BspHalAdaptUtDlIoPara  pUtDlIo = {0};
    T_BspHalAdaptUtUlIoPara  pUtUlIo = {0};

    if(uiCarrLoop >= DMIMO_MAX_CARR_NUM)
    {
    	dbgInfo("%s>> uiCarrLoop is Array Bound ! \n", __FUNCTION__);
    	return BSP_OK;
    }

    dbgInfoEx("%s>> start! \n", __FUNCTION__);
    ulChanMask = s_pDmimoCfgForHal[uiCarrLoop].uiChanMask;
    BspSetDlDtxPaAndAmpGpSel(ulChanMask,1);
    for (uiLoop = 0; uiLoop < QCELL_MAX_CHAN_NUM; uiLoop++)
    {
        dbgInfoEx("%s>> uiLoop:%d, ulChanMask:0x%x\n", __FUNCTION__, uiLoop, ulChanMask);
    	if(ulChanMask & (0x1 << uiLoop))
    	{
            uiDifChan = uiLoop;
            uiCarrId = s_pDmimoCfgForHal[uiCarrLoop].ulCarrNo;
            uiRadioMode = s_pDmimoCfgForHal[uiCarrLoop].uiRadio;
            dbgInfoEx("%s>> uiLoop:%d, uiDifChan:%d, uiCarrId:%d, uiRadioMode:%d\n", __FUNCTION__, uiLoop, uiDifChan, uiCarrId, uiRadioMode);
            for(i = 0; i < DMIMO_BITMAP_WORD_LENGTH; i++)
            {
                dmimoSendParaHalCfg.paraUnit.uiFrNoBitmap[i] = s_pDmimoCfgForHal[uiCarrLoop].uiParaSendInfo.uiFrNoBitmap[i];
                dmimoBackParaHalCfg.paraUnit.uiFrNoBitmap[i] = s_pDmimoCfgForHal[uiCarrLoop].uiParaBackInfo.uiFrNoBitmap[i];
                dbgInfoEx("%s>> uiLoop:%d, sendFrNoBitmap[%d]:0x%x\n", __FUNCTION__, uiLoop, i, dmimoSendParaHalCfg.paraUnit.uiFrNoBitmap[i]);
            }

            for(j = 0; j < DMIMO_MAX_FRAME_SECTION_NUM; j++)
            {
                dmimoSendParaHalCfg.paraUnit.uiSlotInfo[j].uiSlotBitmap = s_pDmimoCfgForHal[uiCarrLoop].uiParaSendInfo.uiSlotInfo[j].uiSlotBitmap;
                dmimoBackParaHalCfg.paraUnit.uiSlotInfo[j].uiSlotBitmap = s_pDmimoCfgForHal[uiCarrLoop].uiParaBackInfo.uiSlotInfo[j].uiSlotBitmap;

                dmimoSendParaHalCfg.paraUnit.uiSlotInfo[j].uiStartFrNo = s_pDmimoCfgForHal[uiCarrLoop].uiParaSendInfo.uiSlotInfo[j].uiStartFrNo;
                dmimoSendParaHalCfg.paraUnit.uiSlotInfo[j].uiEndFrNo = s_pDmimoCfgForHal[uiCarrLoop].uiParaSendInfo.uiSlotInfo[j].uiEndFrNo;
                dmimoBackParaHalCfg.paraUnit.uiSlotInfo[j].uiStartFrNo = s_pDmimoCfgForHal[uiCarrLoop].uiParaBackInfo.uiSlotInfo[j].uiStartFrNo;
                dmimoBackParaHalCfg.paraUnit.uiSlotInfo[j].uiEndFrNo = s_pDmimoCfgForHal[uiCarrLoop].uiParaBackInfo.uiSlotInfo[j].uiEndFrNo;
                dbgInfoEx("%s>> uiLoop:%d, sendSlotInfo[%d].SlotBitmap:0x%x\n", __FUNCTION__, uiLoop, j, dmimoSendParaHalCfg.paraUnit.uiSlotInfo[j].uiSlotBitmap);
            }
            dmimoSendParaHalCfg.paraUnit.uiSymBitmap[0] = s_pDmimoCfgForHal[uiCarrLoop].uiParaSendInfo.uiSymBitmap;
            dmimoBackParaHalCfg.paraUnit.uiSymBitmap[0] = s_pDmimoCfgForHal[uiCarrLoop].uiParaBackInfo.uiSymBitmap;
            ucEn = s_pDmimoCfgForHal[uiCarrLoop].ucEnable;

            dbgInfoEx("%s>> uiLoop:%d, uiSymBitmap:%d\n", __FUNCTION__, uiLoop, dmimoSendParaHalCfg.paraUnit.uiSymBitmap[0]);
            /*代码顺序先dmimo 配置，后做IO顺序不能变*/
            ucMasterEn = BspGetDmimoMasterSwitchEn(s_pDmimoCfgForHal[uiCarrLoop].ulCarrNo,s_pDmimoCfgForHal[uiCarrLoop].uiRadio);

            ucEn = ucEn && ucMasterEn;

            BspHalAdaptDmmSendCfg(uiDifChan,uiCarrId,uiRadioMode,&dmimoSendParaHalCfg);
            BspHalAdaptDmmSendEn(uiDifChan,uiCarrId, uiRadioMode,ucEn);/*要去使能和使能 */
            BspHalAdaptDmmReceiveCfg(uiDifChan,uiCarrId,uiRadioMode,&dmimoBackParaHalCfg);
            BspHalAdaptDmmReceiveEn(uiDifChan,uiCarrId, uiRadioMode,ucEn);/*要去使能和使能 */
           /*
            if(ucEn)
            {
                BspDpdSetDmimoCtrl(0,0,0x5A5A);
            }
            else
            {
                BspDpdSetDmimoCtrl(0,0,0x2D2D);
            }
            */
 
            if(ucEn)
            {
                 BspDpdSetDmmCfgMsg(uiDifChan,0,uiCarrId,uiRadioMode,0x5A5A);
            }
            else
            {
                 BspDpdSetDmmCfgMsg(uiDifChan,0,uiCarrId,uiRadioMode,0x2D2D);
            }

            /* 射频开关dmimo 和UT共用有一个使能就要使能，在去使能时要小心,在做UTDOA时要耦合在一起*/
            BspGetUtDlIoCfg(uiDifChan,&pUtDlIo);
            BspGetUtUlIoCfg(uiDifChan,&pUtUlIo);
            pUtDlIo.uiAmpIdx = pUtDlIo.uiAmpIdx & 0xf;
            pUtDlIo.uiPaIdx = pUtDlIo.uiPaIdx & 0xf;
            pUtUlIo.uiLnaIdx = pUtUlIo.uiLnaIdx & 0xf;
            pUtUlIo.uiRxenIdx = pUtUlIo.uiRxenIdx &0xf;
            dbgInfoEx("%s>> uiDifChan:%d uiAmpIdx%d! uiPaIdx:%d\n", __FUNCTION__,uiDifChan,pUtDlIo.uiAmpIdx,pUtDlIo.uiPaIdx);
            dbgInfoEx("%s>> uiDifChan:%d uiLnaIdx%d! uiRxenIdx:%d\n", __FUNCTION__,uiDifChan,pUtUlIo.uiLnaIdx,pUtUlIo.uiRxenIdx);
            BspHalAdaptUtDlIoCfg(uiDifChan, uiCarrId, uiRadioMode, UT_MODE_OFF, &pUtDlIo);
            BspHalAdaptUtUlIoCfg(uiDifChan, uiCarrId, uiRadioMode, UT_MODE_OFF, &pUtUlIo);

            BspHalAdaptUtDlIoEn(uiDifChan, UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
            BspHalAdaptUtUlIoEn(uiDifChan, UT_DMM_RESOURCE_EN);
            BspHalAdaptUtTddClrCfg(uiDifChan,uiCarrId,uiRadioMode);
            BspHalAdaptSetTsGpEn(uiDifChan,UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
    	}
    }
    BspHalAdaptUtTddUpdate(uiDifChan);
    dbgInfoEx("%s>> end! \n", __FUNCTION__);

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetDmimoFrameBitmapHandle
 * 功能描述: 保存处理过的帧bitmap参数配置信息
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoFrameBitmapHandle(UINT8  *ucFrameBitmap,UINT32 * ulFrameBitmap)
{
	UINT32 ulLoop = 0;
	UINT32 ucLoop = 0;

	for(ucLoop = 0; ucLoop< 128; ucLoop++)
	{
	    if(ucLoop != 0 && (ucLoop%4) == 0)
        {
            ulLoop = ulLoop+1;
        }
	    if(ulLoop >= DMIMO_BITMAP_WORD_LENGTH)
	    {
			dbgInfo("%s ulFrameBitmap Array Bound ",__FUNCTION__);
	    	return BSP_OK;
	    }
	    dbgInfoEx("%s>> ucFrameBitmap[%d]: 0x%x \n", __FUNCTION__, ucLoop, ucFrameBitmap[ucLoop]);
	    ulFrameBitmap[ulLoop] = ulFrameBitmap[ulLoop] | (ucFrameBitmap[ucLoop] << ((ucLoop%4)*8));
	    dbgInfoEx("%s>> ulFrameBitmap[%d]: 0x%x \n", __FUNCTION__, ulLoop, ulFrameBitmap[ulLoop]);
	}

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BsplookupStartEndFrame
 * 功能描述: 查询起始结束帧
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */

UINT32 BspLookupStartEndFrame(UINT32 ulFrameNum,UINT16 *usGroupStartFrame,UINT16 *usGroupEndFrame)
{
	UINT32 ulLoop = 0;

    for(ulLoop = 0; ulLoop < DMIMO_ACS_SERT_END_MODLE_NUM ; ulLoop++)
    {
       if( (ulFrameNum >usGroupStartFrame[ulLoop]) && (ulFrameNum < usGroupEndFrame[ulLoop]))
       {
            return ulLoop;
       }
    }
    return BSP_ERROR;
}

/*****************************************************************************
 * 函数名称: BspSetDmimoSlotInfoBitmapHandle
 * 功能描述: 保存处理过的帧bitmap参数配置信息
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoSlotInfoBitmapHandle(UINT8 *ucSlotBitmap, UINT16 *usGroupStartFrame, UINT16 *usGroupEndFrame, T_DmimoSlotInfo *s_SlotInfo)
{
	UINT32 ucLoop = 0;
	UINT32 ulSlotIndex = 0;


	INPUT_POINTER_CHECK(ucSlotBitmap);
	INPUT_POINTER_CHECK(usGroupStartFrame);
	INPUT_POINTER_CHECK(usGroupEndFrame);
	INPUT_POINTER_CHECK(s_SlotInfo);
	
	for(ucLoop = 0; ucLoop < DMIMO_MAX_SLOT_LEN; ucLoop = ucLoop+20)
	{
		if(ulSlotIndex >=DMIMO_MAX_FRAME_SECTION_NUM)
		{
	        dbgInfo("%s>> s_SlotInfo[%d] \n", __FUNCTION__, ulSlotIndex);
			return BSP_OK;
		}
        s_SlotInfo[ulSlotIndex].uiStartFrNo = usGroupStartFrame[ulSlotIndex];
        s_SlotInfo[ulSlotIndex].uiEndFrNo = usGroupEndFrame[ulSlotIndex];
        s_SlotInfo[ulSlotIndex].uiSlotBitmap = ucSlotBitmap[ucLoop] | (ucSlotBitmap[ucLoop+1] << 8) | ( ((ucSlotBitmap[ucLoop+2] & 0x0F)<<16) );
        dbgInfoEx("%s>> s_SlotInfo[%d].uiStartFrNo: %d \n", __FUNCTION__, ulSlotIndex, s_SlotInfo[ulSlotIndex].uiStartFrNo);
        dbgInfoEx("%s>> s_SlotInfo[%d].uiEndFrNo: %d \n", __FUNCTION__, ulSlotIndex, s_SlotInfo[ulSlotIndex].uiEndFrNo);
        dbgInfoEx("%s>> s_SlotInfo[%d].uiSlotBitmap: 0x%x \n", __FUNCTION__, ulSlotIndex, s_SlotInfo[ulSlotIndex].uiSlotBitmap);
        ulSlotIndex = ulSlotIndex+1;
	}

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetDmimoConfigDataHandle
 * 功能描述:
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimCarrDataHandle(UINT32 uiCarrLoop ,T_ProductDmimoCarrCfg  *pDmimoCfg)
{

	  s_pDmimoCfgForHal[uiCarrLoop].ulCellNo = pDmimoCfg->ulCellNo;
	  s_pDmimoCfgForHal[uiCarrLoop].ulCarrNo = pDmimoCfg->ulCarrNo;
	  s_pDmimoCfgForHal[uiCarrLoop].uiChanMask = pDmimoCfg->uiChanMask;
	  s_pDmimoCfgForHal[uiCarrLoop].uiRadio = pDmimoCfg->uiRadio;
	  s_pDmimoCfgForHal[uiCarrLoop].ucEnable = pDmimoCfg->ucEnable;
	  s_pDmimoCfgForHal[uiCarrLoop].usCalibTime = pDmimoCfg->usCalibTime;
	  s_pDmimoCfgForHal[uiCarrLoop].usCalibStartFrame = pDmimoCfg->usCalibStartFrame;
	  s_pDmimoCfgForHal[uiCarrLoop].usCalibEndFrame = pDmimoCfg->usCalibEndFrame;
	  s_pDmimoCfgForHal[uiCarrLoop].ucAACGroupNum = pDmimoCfg->ucAACGroupNum;

	  return BSP_OK;

}


/*****************************************************************************
 * 函数名称: BspCleanHalDmimoCfg
 * 功能描述:清除发给hal的dmimo配置。
 * 输入参数:
 * 输出参数:
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspCleanHalDmimoCfg(UINT32 ulCellNo)
{
	UINT32 uiLoop = 0 ;
    for(uiLoop = 0; uiLoop < DMIMO_MAX_CARR_NUM; uiLoop++)
    {
    	if(s_pDmimoCfgForHal[uiLoop].ulCellNo == ulCellNo)
    	{
    		   memset_s(&s_pDmimoCfgForHal[uiLoop],sizeof(T_ProductDmimoCarrCfgForHal),0,sizeof(T_ProductDmimoCarrCfgForHal));
    	}
    }
    uiDmimoIsExist = 0;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspCleanAppDmimoCfg
 * 功能描述:清除APP下发的dmimo配置。
 * 输入参数:
 * 输出参数: 载波存储序号
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspCleanAppDmimoCfg(UINT32 ulCellNo)
{
	UINT32 uiLoop = 0 ;
    for(uiLoop = 0; uiLoop < DMIMO_MAX_CARR_NUM; uiLoop++)
    {
    	if(s_pDmimoCfg[uiLoop].ulCellNo == ulCellNo)
    	{
    		   memset_s(&s_pDmimoCfg[uiLoop],sizeof(T_ProductDmimoCarrCfg),0,sizeof(T_ProductDmimoCarrCfg));
    	}
    	if(s_pDmimoMasterSwitchEn[uiLoop].uiCellNo == ulCellNo)
    	{
    		   memset_s(&s_pDmimoMasterSwitchEn[uiLoop],sizeof(T_DmimoMasterSwitchEn),0,sizeof(T_DmimoMasterSwitchEn));
    	}
    }
    uiDmimoIsExist = 0;
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspCleanDmimoCfgByCellNo
 * 功能描述:按照小区标识清除dmimo配置。
 * 输入参数:
 * 输出参数: 载波存储序号
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspCleanDmimoCfgByCellNo(UINT32 ulCellNo)
{

	BspCleanAppDmimoCfg(ulCellNo);
	BspCleanHalDmimoCfg(ulCellNo);
    BspDpdSetDmimoCtrl(0,0,0x2D2D);
    uiDmimoIsExist = 0;
	return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspSetDlTimingDlTddDlyDisable
 * 功能描述:清除 2us 使能
 * 输入参数:
 * 输出参数: 载波存储序号
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDlTimingDlTddDlyClean(UINT32 uiChanMask)
{
    UINT32 uiLoop =0;
    for(uiLoop =0 ;uiLoop<QCELL_MAX_CHAN_NUM;uiLoop++)
	{
    	if(uiChanMask & ((UINT32)0x1 << uiLoop))
		{
            BspHalAdaptSetDlTimingDlTddDly(uiLoop,0);
        }
    }
    return BSP_OK ;
}

/*****************************************************************************
 * 函数名称: BspCleanALLDmimoCfg
 * 功能描述:清除所有dmimo配置。
 * 输入参数:
 * 输出参数: 载波存储序号
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspCleanALLDmimoCfg(VOID)
{
	UINT32 uiLoop = 0 ;
    dbgInfo("%s>> \n", __FUNCTION__);
    for(uiLoop = 0; uiLoop < DMIMO_MAX_CARR_NUM; uiLoop++)
    {

    	memset_s(&s_pDmimoCfg[uiLoop],sizeof(T_ProductDmimoCarrCfg),0,sizeof(T_ProductDmimoCarrCfg));
        memset_s(&s_pDmimoMasterSwitchEn[uiLoop],sizeof(T_DmimoMasterSwitchEn),0,sizeof(T_DmimoMasterSwitchEn));
		memset_s(&s_pDmimoCfgForHal[uiLoop],sizeof(T_ProductDmimoCarrCfgForHal),0,sizeof(T_ProductDmimoCarrCfgForHal));
    }
    BspDpdSetDmmCfgClrFlg(1);
    BspDpdSetDmimoCtrl(0,0,0x2D2D);
    BspHalAdaptDmClear();

    uiDmimoIsExist = 0;/*DMIMO不存在*/
	return BSP_OK;
}


/*****************************************************************************
 * 函数名称: BspSetDmimoConfigDataHandle
 * 功能描述:
 * 输入参数:
 * 输出参数: 载波存储序号
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoConfigDataHandle(T_ProductDmimoCarrCfg  *pDmimoCfg)
{

	UINT32 uiLoop = 0;

	dbgInfoEx("%s>> start! \n", __FUNCTION__);
	dbgInfoEx("%s>> pDmimoCfg->ulCellNo: %d \n", __FUNCTION__, pDmimoCfg->ulCellNo);
	for(uiLoop =0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
	        dbgInfoEx("%s>> second s_pDmimoCfg[%d].ulCellNo: %d \n", __FUNCTION__, uiLoop, s_pDmimoCfg[uiLoop].ulCellNo);
		if(pDmimoCfg->ulCellNo == s_pDmimoCfg[uiLoop].ulCellNo)
		{
            /*清除上次下发存储计算过的haldmimo信息*/
			 BspCleanHalDmimoCfg(pDmimoCfg->ulCellNo);

            /*小区配置相关信息*/
			  BspSetDmimCarrDataHandle(uiLoop,pDmimoCfg);

			/*处理发送帧bitmap*/
			  BspSetDmimoFrameBitmapHandle(pDmimoCfg->ucAACSendFrame,s_pDmimoCfgForHal[uiLoop].uiParaSendInfo.uiFrNoBitmap);

			  /*处理接收帧bitmap*/
			  BspSetDmimoFrameBitmapHandle(pDmimoCfg->ucAACBackFrame,s_pDmimoCfgForHal[uiLoop].uiParaBackInfo.uiFrNoBitmap);

			  /*处理发送符号bitmap*/
			  s_pDmimoCfgForHal[uiLoop].uiParaSendInfo.uiSymBitmap = pDmimoCfg->usAACSendSymbol;

			  /*处理接收符号bitmap*/
			  s_pDmimoCfgForHal[uiLoop].uiParaBackInfo.uiSymBitmap = pDmimoCfg->usAACBackSymbol;

			  /*处理发送时隙bitmap*/
			  BspSetDmimoSlotInfoBitmapHandle(pDmimoCfg->ucAACSendTimeSlot,pDmimoCfg->usAACGroupStartFrame,pDmimoCfg->usAACGroupEndFrame,s_pDmimoCfgForHal[uiLoop].uiParaSendInfo.uiSlotInfo);

			  /*处理接收时隙bitmap*/
			  BspSetDmimoSlotInfoBitmapHandle(pDmimoCfg->ucAACBackTimeSlot,pDmimoCfg->usAACGroupStartFrame,pDmimoCfg->usAACGroupEndFrame,s_pDmimoCfgForHal[uiLoop].uiParaBackInfo.uiSlotInfo);
			  return uiLoop;
		}
	}


	for(uiLoop =0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
	    dbgInfoEx("%s>> first s_pDmimoCfg[%d].ulCellNo: %d \n", __FUNCTION__, uiLoop, s_pDmimoCfg[uiLoop].ulCellNo);
		if( (s_pDmimoCfg[uiLoop].ulCellNo == 0) && (s_pDmimoCfg[uiLoop].uiRadio == 0) )
		{
            /*小区配置相关信息*/
			  BspSetDmimCarrDataHandle(uiLoop,pDmimoCfg);

			/*处理发送帧bitmap*/
			  BspSetDmimoFrameBitmapHandle(pDmimoCfg->ucAACSendFrame,s_pDmimoCfgForHal[uiLoop].uiParaSendInfo.uiFrNoBitmap);

			  /*处理接收帧bitmap*/
			  BspSetDmimoFrameBitmapHandle(pDmimoCfg->ucAACBackFrame,s_pDmimoCfgForHal[uiLoop].uiParaBackInfo.uiFrNoBitmap);

			  /*处理发送符号bitmap*/
			  s_pDmimoCfgForHal[uiLoop].uiParaSendInfo.uiSymBitmap = pDmimoCfg->usAACSendSymbol;

			  /*处理接收符号bitmap*/
			  s_pDmimoCfgForHal[uiLoop].uiParaBackInfo.uiSymBitmap = pDmimoCfg->usAACBackSymbol;

			  /*处理发送时隙bitmap*/
			  BspSetDmimoSlotInfoBitmapHandle(pDmimoCfg->ucAACSendTimeSlot,pDmimoCfg->usAACGroupStartFrame,pDmimoCfg->usAACGroupEndFrame,s_pDmimoCfgForHal[uiLoop].uiParaSendInfo.uiSlotInfo);

			  /*处理接收时隙bitmap*/
			  BspSetDmimoSlotInfoBitmapHandle(pDmimoCfg->ucAACBackTimeSlot,pDmimoCfg->usAACGroupStartFrame,pDmimoCfg->usAACGroupEndFrame,s_pDmimoCfgForHal[uiLoop].uiParaBackInfo.uiSlotInfo);
			  return uiLoop;
		}
	}

	return BSP_ERROR;
}


/*****************************************************************************
 * 函数名称: BspGetDmimoMasterSwitchEn
 * 功能描述: dmimo总开关使能获取
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT8 BspGetDmimoMasterSwitchEn( UINT32 uiCarrNo, UINT32 uiRadio)
{
	UINT32 uiLoop = 0;
	for(uiLoop =0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
		if( (uiCarrNo == s_pDmimoMasterSwitchEn[uiLoop].uiCarrNo)  &&  (uiRadio == s_pDmimoMasterSwitchEn[uiLoop].uiRadio))
		{
           return  s_pDmimoMasterSwitchEn[uiLoop].ucMasterSwitchEn;
		}
	}

	return  BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspDmimoMasterDiable
 * 功能描述: dmimo 和TS流程互斥，TS去使能,此时不会触发校准使能。开的话有校准使能开
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspDmimoMasterEnable(UINT32 uiChanMask, UINT32 uiCarrId, UINT32 uiRadioMode,UINT32 uiEn)
{
	UINT32 uiLoop = 0;
    UINT32 uiDlyNs =2000;

	BspSetDlDtxPaAndAmpGpSel(uiChanMask,UT_DMM_RESOURCE_EN);

	for(uiLoop =0 ;uiLoop<QCELL_MAX_CHAN_NUM;uiLoop++)
	{
    	if(uiChanMask & ((UINT32)0x1 << uiLoop))
		{
            BspHalAdaptDmmSendEn(uiLoop,uiCarrId, uiRadioMode,uiEn);/*要去使能和使能 */
            BspHalAdaptDmmReceiveEn(uiLoop,uiCarrId, uiRadioMode,uiEn);/*要去使能和使能 */
            BspHalAdaptUtDlIoEn( uiLoop, UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
            BspHalAdaptUtUlIoEn( uiLoop, UT_DMM_RESOURCE_EN);//UT和DMM共存，对于DMIMO配置下发时，只使能通道级GP和通道级IO资源，不做耦合判断。
            BspHalAdaptSetDlTimingDlTddDly(uiLoop,uiDlyNs); // 中频：不需关闭，直接就是2000
            BspHalAdaptSetTsGpEn(uiLoop,UT_DMM_RESOURCE_EN);
		}
	}
	return  BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspSetDmimoMasterSwitchEn
 * 功能描述: dmimo总开关使能
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoMasterSwitchEn(T_DmimoMasterSwitchEn  *pDmimoMasterEn)
{
	UINT32 ret = BSP_ERROR;
	UINT32 uiLoop = 0;
	
	
	INPUT_POINTER_CHECK(pDmimoMasterEn);
	
	for(uiLoop =0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
        if(pDmimoMasterEn->uiCellNo == s_pDmimoMasterSwitchEn[uiLoop].uiCellNo)
	    {
	    	s_pDmimoMasterSwitchEn[uiLoop].ucCpNum = pDmimoMasterEn->ucCpNum;
	    	s_pDmimoMasterSwitchEn[uiLoop].ucMasterSwitchEn = pDmimoMasterEn->ucMasterSwitchEn;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiChanMask = pDmimoMasterEn->uiChanMask;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiRadio = pDmimoMasterEn->uiRadio;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiCarrNo = pDmimoMasterEn->uiCarrNo;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiCellNo = pDmimoMasterEn->uiCellNo;

	    	BspDmimoMasterEnable(pDmimoMasterEn->uiChanMask, pDmimoMasterEn->uiCarrNo,pDmimoMasterEn->uiRadio,pDmimoMasterEn->ucMasterSwitchEn);

	    	ret = IcHalApiUtSetDmimoMasterSwitchInfo(s_pDmimoMasterSwitchEn);
	    	return ret;
	    }
	}

	for(uiLoop =0 ;uiLoop<DMIMO_MAX_CARR_NUM;uiLoop++)
	{
        /*dbgInfoEx("%s>> first s_pDmimoCfg[%d].ulCellNo: %d \n", __FUNCTION__, uiLoop, pDmimoMasterEn[uiLoop].uiCellNo);*/

        if( (s_pDmimoMasterSwitchEn[uiLoop].uiCellNo == 0) && (s_pDmimoMasterSwitchEn[uiLoop].uiRadio == 0) )
	    {
	    	s_pDmimoMasterSwitchEn[uiLoop].ucCpNum = pDmimoMasterEn->ucCpNum;
	    	s_pDmimoMasterSwitchEn[uiLoop].ucMasterSwitchEn = pDmimoMasterEn->ucMasterSwitchEn;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiChanMask = pDmimoMasterEn->uiChanMask;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiRadio = pDmimoMasterEn->uiRadio;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiCarrNo = pDmimoMasterEn->uiCarrNo;
	    	s_pDmimoMasterSwitchEn[uiLoop].uiCellNo = pDmimoMasterEn->uiCellNo;

	    	BspDmimoMasterEnable(pDmimoMasterEn->uiChanMask, pDmimoMasterEn->uiCarrNo,pDmimoMasterEn->uiRadio,pDmimoMasterEn->ucMasterSwitchEn);

	    	ret = IcHalApiUtSetDmimoMasterSwitchInfo(s_pDmimoMasterSwitchEn);
	    	return ret;
	    }
	}

	return BSP_OK;
}


UINT32 BspSetAllKoRfSwtichCfg(VOID)
{
    T_RF_SWTICH_MSG ShareMemRfSwitchData = {0};
    T_RF_SWTICH_MSG ShareMemRfSwitchAllSetData = {0};
    T_RF_SWTICH_MSG ShareMemRfSwitchAllClrData = {0};
    E_RegType uiType   = UT_REG_TYPE_DMIMO;
    UINT32 uiGpLoop= 0 ;
    UINT32 uiGpLenSet= 0 ;
    UINT32 uiGpLenClr= 0 ;

    for(uiGpLoop =0 ;uiGpLoop<DMIMO_MAX_CARR_NUM*2;uiGpLoop++)
    {
        BspHalAdaptGetSaveRegInfo(uiType, uiGpLoop, &ShareMemRfSwitchData);
        if( (uiGpLoop%2 ==0) && (ShareMemRfSwitchData.uiLen > 0) )
        {
        	memcpy_s(ShareMemRfSwitchAllSetData.UtRegInfo + uiGpLenSet,sizeof(T_RegInfo) * ShareMemRfSwitchData.uiLen ,ShareMemRfSwitchData.UtRegInfo,sizeof(T_RegInfo) * ShareMemRfSwitchData.uiLen );
        	uiGpLenSet = uiGpLenSet + ShareMemRfSwitchData.uiLen;
        }
        if((uiGpLoop%2 !=0)&&  (ShareMemRfSwitchData.uiLen > 0) )
        {
        	memcpy_s(ShareMemRfSwitchAllClrData.UtRegInfo + uiGpLenClr,sizeof(T_RegInfo) * ShareMemRfSwitchData.uiLen ,ShareMemRfSwitchData.UtRegInfo,sizeof(T_RegInfo) * ShareMemRfSwitchData.uiLen );
        	uiGpLenClr = uiGpLenClr + ShareMemRfSwitchData.uiLen;
        }
    }

    ShareMemRfSwitchAllSetData.uiLen = uiGpLenSet;

    ShareMemRfSwitchAllClrData.uiLen = uiGpLenClr;

    BspKoRfSwtichCfg(&ShareMemRfSwitchAllSetData, E_A53_RF_SWITCH_SET);


    dbgInfoEx("%s>> set uiLen:%d,! \n", __FUNCTION__,ShareMemRfSwitchAllSetData.uiLen);
    dbgInfoEx("%s>> clr uiLen:%d,! \n", __FUNCTION__,ShareMemRfSwitchAllClrData.uiLen);

	for(uiGpLoop =0 ;uiGpLoop<MAX_REG_INFO_NUM;uiGpLoop++)
    {
		dbgInfoEx("uiPhyAddr:%x uiRegVal: %d\n",ShareMemRfSwitchAllSetData.UtRegInfo[uiGpLoop].uiPhyAddr,ShareMemRfSwitchAllSetData.UtRegInfo[uiGpLoop].uiRegVal);
	}
	for(uiGpLoop =0 ;uiGpLoop<MAX_REG_INFO_NUM;uiGpLoop++)
    {
		dbgInfoEx("uiPhyAddr:%x uiRegVal: %d\n",ShareMemRfSwitchAllClrData.UtRegInfo[uiGpLoop].uiPhyAddr,ShareMemRfSwitchAllClrData.UtRegInfo[uiGpLoop].uiRegVal);
	}
    BspKoRfSwtichCfg(&ShareMemRfSwitchAllClrData, E_A53_RF_SWITCH_CLR);

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetDmmFrAdjustVal
 * 功能描述: 光口帧头调整量解耦 - Dmimo
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmmFrAdjustVal(T_ProductDmimoCarrCfg  *pDmimoCfg)
{
    UINT32 chanMask = 0;
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;
    chanMask = pDmimoCfg->uiChanMask;
    for(chan = 0; chan < QCELL_MAX_CHAN_NUM; chan++)
    {
        if((chanMask & ((UINT32)0x1 << chan)) !=0)
        {
            retVal = BspHalAdaptSetFeatureFrAdjustVal(chan, pDmimoCfg->ulCarrNo, pDmimoCfg->uiRadio, E_QCELL_DMIMO_FUNCION);
        }
    }   
    return retVal;
}

/*****************************************************************************
 * 函数名称: BspSetDmimoConfigInfoAnalysis
 * 功能描述: dmimo参数配置处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoConfigInfoAnalysis(T_ProductDmimoCarrCfg  *pDmimoCfg)
{
    UINT32 uiCarrLoop = 0 ;
    UINT32 chanMask = 0;
    UINT32 i        = 0;
    E_RegType uiType   = UT_REG_TYPE_DMIMO;
    T_RF_SWTICH_MSG ShareMemRfSwitchData = {0};

    BspLog(LOG_LEVEL_0,"%s>> dmimo start! \n", __FUNCTION__);
    dbgInfoEx("%s>> start! \n", __FUNCTION__);

   /* BspHalAdaptDmClear();移到中频测清除*/

    BspSaveAppDmimoConfig(pDmimoCfg);

    /*光口帧头调整量解耦*/
    //BspSetDmmFrAdjustVal(pDmimoCfg); //中频提供的临时规避方案（无线帧号时延配置方案）

    uiCarrLoop = BspSetDmimoConfigDataHandle(pDmimoCfg);

    if(uiCarrLoop >= DMIMO_MAX_CARR_NUM)
    {
    	dbgInfoEx("%s>> carr num error \n", __FUNCTION__);
        return BSP_ERROR;
    }

    BspSetDmimoHalConfig(uiCarrLoop);

    BspHandleFrameBitmap(&(s_pDmimoCfgForHal[uiCarrLoop].uiParaBackInfo));/*以最后一个下发的载波为准*/

    dbgInfoEx("%s uiCarrLoop:%d,pDmimoCfg->ulCarrNo:%d\n", __FUNCTION__,uiCarrLoop,pDmimoCfg->ulCarrNo);

    BspHalAdaptClrSaveRegInfo(uiType, uiCarrLoop*2);
    BspHalAdaptSetSaveGrp(uiType, uiCarrLoop*2);
    BspHalAdaptSetSaveRegEn(1);

    chanMask = pDmimoCfg->uiChanMask;
    dbgInfoEx("%s>>ulChanMask:0x%x\n", __FUNCTION__,  chanMask);
    for(i = 0; i < QCELL_MAX_CHAN_NUM; i++)
    {
        if((chanMask & ((UINT32)0x1 << i)) !=0)
        {
            BspHalAdaptUtTddClrEn(i, pDmimoCfg->ulCarrNo, pDmimoCfg->uiRadio, 1);
        }
    }

    BspHalAdaptSetSaveRegEn(0);

    BspHalAdaptGetSaveRegInfo(uiType, uiCarrLoop*2, &ShareMemRfSwitchData);

    dbgInfoEx("%s>> uiEn:%d, uiLen:%d, uiPhyAddr:%d, Stop:%d \n", __FUNCTION__,
            ShareMemRfSwitchData.uiLen, ShareMemRfSwitchData.uiEn, ShareMemRfSwitchData.UtRegInfo[0].uiPhyAddr, ShareMemRfSwitchData.UtRegInfo[0].uiRegVal);

    /*BspKoRfSwtichCfg(&ShareMemRfSwitchData, E_A53_RF_SWITCH_SET);*/


    BspHalAdaptClrSaveRegInfo(uiType, uiCarrLoop*2+1);
    BspHalAdaptSetSaveGrp(uiType, uiCarrLoop*2+1);
    BspHalAdaptSetSaveRegEn(1);
    for(i = 0; i < QCELL_MAX_CHAN_NUM; i++)
    {
        if((chanMask & ((UINT32)0x1 << i)) != 0)
        {
            BspHalAdaptUtTddClrEn(i, pDmimoCfg->ulCarrNo, pDmimoCfg->uiRadio, 0);
        }
    }
    BspHalAdaptSetSaveRegEn(0);


    BspHalAdaptGetSaveRegInfo(uiType, uiCarrLoop*2+1, &ShareMemRfSwitchData);

    dbgInfoEx("%s>> uiEn:%d, uiLen:%d, uiPhyAddr:%d, Stop:%d \n", __FUNCTION__,
                ShareMemRfSwitchData.uiLen, ShareMemRfSwitchData.uiEn, ShareMemRfSwitchData.UtRegInfo[0].uiPhyAddr, ShareMemRfSwitchData.UtRegInfo[0].uiRegVal);
   /*BspKoRfSwtichCfg(&ShareMemRfSwitchData, E_A53_RF_SWITCH_CLR);*/

    BspSetAllKoRfSwtichCfg();

    dbgInfoEx("%s>> end! \n", __FUNCTION__);
    BspLog(LOG_LEVEL_0,"%s>> dmimo end! \n", __FUNCTION__);
    return BSP_OK;
}

VOID RfSwitchTest()
{
    T_RegSaveUnit ShareMemRfSwitchData = {0};
    T_RegSaveUnit ShareMemRfSwitchDataClr = {0};
    T_SUBFRAME_BITMAP_MSG subframe = {0};


    subframe.bitmap[0] = 0xf0f0f0f0;
    subframe.bitmap[1] = 0x5a5a5a5a;
    subframe.bitmap[3] = 0x5a5a5a5a00000000;
    subframe.bitmap[6] = 0x5a5a5a5a0b0b0b0b;
    subframe.bitmap[9] = 0xf0f0f0f002020202;
    subframe.bitmap[11] = 0x5a5a5a5af0f0f0f0;
    subframe.bitmap[14] = 0x0a0a0a0a02020202;
    subframe.bitmap[16] = 0x5a5a5a5a0a0a0a0a;
    subframe.bitmap[18] = 0x5a5a5a5aa5a5a5a5;
    subframe.bitmap[20] = 0x5a5a5a5a5a5a5a5a;
    subframe.bitmap[23] = 0x4b4b4b4b02020202;
    subframe.bitmap[25] = 0x5a5a5a5a4b4b4b4b;
    subframe.bitmap[28] = 0x0a0a0a0a;
    subframe.bitmap[31] = 0x4b4b4b4b;
    BspKoSubFrameCfg(&subframe);


    ShareMemRfSwitchData.uiEn = 1;
    ShareMemRfSwitchData.uiLen = 1;
    ShareMemRfSwitchData.UtRegInfo[0].uiPhyAddr = 0xcb205644;
    ShareMemRfSwitchData.UtRegInfo[0].uiRegVal = 0x0f0f0f0f;
    dbgInfo("%s>> uiEn:%d, uiLen:%d, uiPhyAddr:0x%x, uiRegVal:0x%x \n", __FUNCTION__,
                ShareMemRfSwitchData.uiLen, ShareMemRfSwitchData.uiEn, ShareMemRfSwitchData.UtRegInfo[0].uiPhyAddr, ShareMemRfSwitchData.UtRegInfo[0].uiRegVal);

    BspKoRfSwtichCfg(&ShareMemRfSwitchData, E_A53_RF_SWITCH_SET);


    ShareMemRfSwitchDataClr.uiEn = 0;
    ShareMemRfSwitchDataClr.uiLen = 2;
    ShareMemRfSwitchDataClr.UtRegInfo[0].uiPhyAddr = 0xcb205648;
    ShareMemRfSwitchDataClr.UtRegInfo[0].uiRegVal  = 0x5a5a5a5a;
    ShareMemRfSwitchDataClr.UtRegInfo[1].uiPhyAddr = 0xcb20564c;
    ShareMemRfSwitchDataClr.UtRegInfo[1].uiRegVal  = 0x01010101;
    dbgInfo("%s>> uiEn:%d, uiLen:%d, uiPhyAddr:0x%x, uiRegVal:0x%x \n", __FUNCTION__,
            ShareMemRfSwitchDataClr.uiLen, ShareMemRfSwitchDataClr.uiEn, ShareMemRfSwitchDataClr.UtRegInfo[0].uiPhyAddr, ShareMemRfSwitchDataClr.UtRegInfo[0].uiRegVal);
    BspKoRfSwtichCfg(&ShareMemRfSwitchDataClr, E_A53_RF_SWITCH_CLR);
}

VOID FrameNumTest()
{
    T_FRAME_NUM_MSG msgSend = {0};
    T_FRAME_NUM_MSG msgRecv = {0};

    msgSend.frameNum = 0xff;

    BspKoFrameNumCfg(&msgSend, &msgRecv);

    dbgInfo("%s msgSend = %d, msgRecv = %d\n,",__FUNCTION__,msgSend.frameNum, msgRecv.frameNum);
}

VOID DmimoTest()
{
    T_ProductDmimoCarrCfg  DmimoCfg = {0};
    DmimoCfg.ulCellNo = 0;
    DmimoCfg.ulCarrNo = 0;
    DmimoCfg.uiChanMask = 0xf;
    DmimoCfg.uiRadio = 0x2000;
    DmimoCfg.ucEnable = 1;
    DmimoCfg.usCalibTime = 1024;
    DmimoCfg.usCalibStartFrame = 32;
    DmimoCfg.usCalibEndFrame = 255;
    DmimoCfg.ucAACGroupNum = 8;
    DmimoCfg.usAACGroupStartFrame[0] = 0;
    DmimoCfg.usAACGroupStartFrame[1] = 10;
    DmimoCfg.usAACGroupStartFrame[2] = 20;
    DmimoCfg.usAACGroupStartFrame[3] = 30;
    DmimoCfg.usAACGroupStartFrame[4] = 40;
    DmimoCfg.usAACGroupStartFrame[5] = 50;
    DmimoCfg.usAACGroupStartFrame[6] = 60;
    DmimoCfg.usAACGroupStartFrame[7] = 70;
    DmimoCfg.usAACGroupEndFrame[0] = 7;
    DmimoCfg.usAACGroupEndFrame[1] = 17;
    DmimoCfg.usAACGroupEndFrame[2] = 27;
    DmimoCfg.usAACGroupEndFrame[3] = 37;
    DmimoCfg.usAACGroupEndFrame[4] = 47;
    DmimoCfg.usAACGroupEndFrame[5] = 57;
    DmimoCfg.usAACGroupEndFrame[6] = 67;
    DmimoCfg.usAACGroupEndFrame[7] = 77;
    DmimoCfg.ucAACSendFrame[0] = 0xf;
    DmimoCfg.ucAACSendFrame[1] = 0x7f;
    DmimoCfg.ucAACSendFrame[2] = 0xd;
    DmimoCfg.ucAACSendFrame[3] = 0xc;
    DmimoCfg.ucAACSendFrame[4] = 0xb;
    DmimoCfg.ucAACSendFrame[5] = 0xa;
    DmimoCfg.ucAACSendFrame[6] = 0x9;
    DmimoCfg.ucAACSendFrame[7] = 0x8;
    DmimoCfg.ucAACSendFrame[8] = 0x7;
    DmimoCfg.ucAACSendFrame[9] = 0x6;
    DmimoCfg.ucAACSendFrame[10] = 0x5;
    DmimoCfg.ucAACSendFrame[11] = 0x4;
    DmimoCfg.ucAACSendFrame[12] = 0x3;
    DmimoCfg.ucAACSendFrame[13] = 0x2;
    DmimoCfg.ucAACSendFrame[14] = 0x1;
    DmimoCfg.ucAACSendFrame[15] = 0x0;
    DmimoCfg.ucAACSendFrame[120] = 0x8;
    DmimoCfg.ucAACSendFrame[121] = 0x9;
    DmimoCfg.ucAACSendFrame[122] = 0xa;
    DmimoCfg.ucAACSendFrame[123] = 0xb;
    DmimoCfg.ucAACSendFrame[124] = 0xc;
    DmimoCfg.ucAACSendFrame[125] = 0xd;
    DmimoCfg.ucAACSendFrame[126] = 0xe;
    DmimoCfg.ucAACSendFrame[127] = 0xf;
    DmimoCfg.ucAACSendTimeSlot[0]=0x0;
    DmimoCfg.ucAACSendTimeSlot[1]=0x1;
    DmimoCfg.ucAACSendTimeSlot[2]=0x0;
    DmimoCfg.ucAACSendTimeSlot[3]=0x1;
    DmimoCfg.ucAACSendTimeSlot[4]=0x0;
    DmimoCfg.ucAACSendTimeSlot[5]=0x1;
    DmimoCfg.ucAACSendTimeSlot[6]=0x0;
    DmimoCfg.ucAACSendTimeSlot[7]=0x1;
    DmimoCfg.ucAACSendTimeSlot[8]=0x0;
    DmimoCfg.ucAACSendTimeSlot[9]=0x1;
    DmimoCfg.ucAACSendTimeSlot[10]=0x0;
    DmimoCfg.ucAACSendTimeSlot[11]=0x1;
    DmimoCfg.ucAACSendTimeSlot[12]=0x0;
    DmimoCfg.ucAACSendTimeSlot[13]=0x1;
    DmimoCfg.ucAACSendTimeSlot[14]=0x0;
    DmimoCfg.ucAACSendTimeSlot[15]=0x1;
    DmimoCfg.ucAACSendTimeSlot[16]=0x0;
    DmimoCfg.ucAACSendTimeSlot[17]=0x1;
    DmimoCfg.ucAACSendTimeSlot[18]=0x0;
    DmimoCfg.ucAACSendTimeSlot[19]=0x1;
    DmimoCfg.ucAACSendTimeSlot[20]=0x1;
    DmimoCfg.ucAACSendTimeSlot[21]=0x1;
    DmimoCfg.ucAACSendTimeSlot[22]=0x1;
    DmimoCfg.ucAACSendTimeSlot[23]=0x0;
    DmimoCfg.ucAACSendTimeSlot[24]=0x1;
    DmimoCfg.ucAACSendTimeSlot[25]=0x1;
    DmimoCfg.ucAACSendTimeSlot[26]=0x1;
    DmimoCfg.ucAACSendTimeSlot[27]=0x1;
    DmimoCfg.ucAACSendTimeSlot[153]=0x0;
    DmimoCfg.ucAACSendTimeSlot[154]=0x1;
    DmimoCfg.ucAACSendTimeSlot[156]=0x0;
    DmimoCfg.ucAACSendTimeSlot[157]=0x1;
    DmimoCfg.ucAACSendTimeSlot[158]=0x0;
    DmimoCfg.ucAACSendTimeSlot[159]=0x1;
    DmimoCfg.usAACSendSymbol = 0x0f;

    DmimoCfg.ucAACBackFrame[0] = 0xf;
    DmimoCfg.ucAACBackFrame[1] = 0xe;
    DmimoCfg.ucAACBackFrame[2] = 0xd;
    DmimoCfg.ucAACBackFrame[3] = 0xc;
    DmimoCfg.ucAACBackFrame[4] = 0xb;
    DmimoCfg.ucAACBackFrame[5] = 0xa;
    DmimoCfg.ucAACBackFrame[6] = 0x9;
    DmimoCfg.ucAACBackFrame[7] = 0x8;
    DmimoCfg.ucAACBackFrame[8] = 0x7;
    DmimoCfg.ucAACBackFrame[9] = 0x6;
    DmimoCfg.ucAACBackFrame[10] = 0x5;
    DmimoCfg.ucAACBackFrame[11] = 0x4;
    DmimoCfg.ucAACBackFrame[12] = 0x3;
    DmimoCfg.ucAACBackFrame[13] = 0x2;
    DmimoCfg.ucAACBackFrame[14] = 0x1;
    DmimoCfg.ucAACBackFrame[15] = 0x0;
    DmimoCfg.ucAACBackFrame[120] = 0x8;
    DmimoCfg.ucAACBackFrame[121] = 0x9;
    DmimoCfg.ucAACBackFrame[122] = 0xa;
    DmimoCfg.ucAACBackFrame[123] = 0xb;
    DmimoCfg.ucAACBackFrame[124] = 0xc;
    DmimoCfg.ucAACBackFrame[125] = 0xd;
    DmimoCfg.ucAACBackFrame[126] = 0xe;
    DmimoCfg.ucAACBackFrame[127] = 0xf;
    DmimoCfg.ucAACBackTimeSlot[0]=0x0;
    DmimoCfg.ucAACBackTimeSlot[1]=0x1;
    DmimoCfg.ucAACBackTimeSlot[2]=0x0;
    DmimoCfg.ucAACBackTimeSlot[3]=0x1;
    DmimoCfg.ucAACBackTimeSlot[4]=0x0;
    DmimoCfg.ucAACBackTimeSlot[5]=0x1;
    DmimoCfg.ucAACBackTimeSlot[6]=0x0;
    DmimoCfg.ucAACBackTimeSlot[7]=0x1;
    DmimoCfg.ucAACBackTimeSlot[8]=0x0;
    DmimoCfg.ucAACBackTimeSlot[9]=0x1;
    DmimoCfg.ucAACBackTimeSlot[10]=0x0;
    DmimoCfg.ucAACBackTimeSlot[11]=0x1;
    DmimoCfg.ucAACBackTimeSlot[12]=0x0;
    DmimoCfg.ucAACBackTimeSlot[13]=0x1;
    DmimoCfg.ucAACBackTimeSlot[14]=0x0;
    DmimoCfg.ucAACBackTimeSlot[15]=0x1;
    DmimoCfg.ucAACBackTimeSlot[16]=0x0;
    DmimoCfg.ucAACBackTimeSlot[17]=0x1;
    DmimoCfg.ucAACBackTimeSlot[18]=0x0;
    DmimoCfg.ucAACBackTimeSlot[19]=0x1;
    DmimoCfg.ucAACBackTimeSlot[20]=0x1;
    DmimoCfg.ucAACBackTimeSlot[21]=0x1;
    DmimoCfg.ucAACBackTimeSlot[22]=0x1;
    DmimoCfg.ucAACBackTimeSlot[23]=0x0;
    DmimoCfg.ucAACBackTimeSlot[24]=0x1;
    DmimoCfg.ucAACBackTimeSlot[25]=0x1;
    DmimoCfg.ucAACBackTimeSlot[26]=0x1;
    DmimoCfg.ucAACBackTimeSlot[27]=0x1;
    DmimoCfg.ucAACBackTimeSlot[153]=0x0;
    DmimoCfg.ucAACBackTimeSlot[154]=0x1;
    DmimoCfg.ucAACBackTimeSlot[156]=0x0;
    DmimoCfg.ucAACBackTimeSlot[157]=0x1;
    DmimoCfg.ucAACBackTimeSlot[158]=0x0;
    DmimoCfg.ucAACBackTimeSlot[159]=0x1;
    DmimoCfg.usAACBackSymbol = 0xf0;

    BspSetDmimoConfigInfoAnalysis(&DmimoCfg);

}

static UINT32 FindGroupNumByFrameNum(UINT32 frameNum, T_DmimoSlotInfo *pSlotInfo, UINT32 *pResult, UINT32 *pGroupNum)
{
    UINT32 i = 0;
    UINT32 groupNum = 0;
    UINT32 result = 0;


    INPUT_POINTER_CHECK(pResult);
    INPUT_POINTER_CHECK(pSlotInfo);
    INPUT_POINTER_CHECK(pGroupNum);

    for(i = 0; i < DMIMO_AAC_GROUP_LEN; i++)
    {
        dbgInfoEx("%s>> i:%d, frameNum:%d, Start:%d, Stop:%d \n", __FUNCTION__, i, frameNum, pSlotInfo[i].uiStartFrNo, pSlotInfo[i].uiEndFrNo);
        if(frameNum >= pSlotInfo[i].uiStartFrNo && frameNum <= pSlotInfo[i].uiEndFrNo)
        {
            groupNum = i;
            result = 1;
            dbgInfoEx("%s>> i:%d, frameNum:%d, groupNum:%d, result:%d \n", __FUNCTION__, i, frameNum, groupNum, result);
            break;
        }
    }

    *pResult = result;
    *pGroupNum = groupNum;
    return BSP_OK;
}

static UINT32 GetSubFrameBitMap(T_DmimoSlotInfo *pSlotInfo, UINT32 frameNum, UINT64 *pSubFrameBitmap)
{
    UINT32 slotLoop = 0;
    UINT64 subFrameBitmap = 0;
    UINT32 SlotBitmap = 0;
    UINT32 flag = 0;


    INPUT_POINTER_CHECK(pSlotInfo);
    INPUT_POINTER_CHECK(pSubFrameBitmap);

    subFrameBitmap= *pSubFrameBitmap;
    dbgInfoEx("%s>> frameNum:%d, SlotBitMap:0x%x\n", __FUNCTION__, frameNum, pSlotInfo->uiSlotBitmap);
    for(slotLoop = 0; slotLoop < (DMIMO_NR_SLOTBITMAP_LEN/2); slotLoop++ )
    {
        SlotBitmap=pSlotInfo->uiSlotBitmap & SET_BIT(slotLoop);
        dbgInfoEx("%s>> slotLoop:%d, SlotBitMap:0x%x \n", __FUNCTION__, slotLoop, SlotBitmap);
        if(SlotBitmap != 0)
        {
            subFrameBitmap = subFrameBitmap | SET_BIT(frameNum*2);
            flag = 1;
            break;
        }
    }

    if(flag != 1)
    {
        subFrameBitmap = subFrameBitmap & REV_BIT(frameNum*2);
    }

    dbgInfoEx("%s>> subFrameBitmap_0:0x%llx\n", __FUNCTION__, subFrameBitmap);
    for(slotLoop = DMIMO_NR_SLOTBITMAP_LEN/2; slotLoop < DMIMO_NR_SLOTBITMAP_LEN; slotLoop++ )
    {
        SlotBitmap=pSlotInfo->uiSlotBitmap & SET_BIT(slotLoop);
        dbgInfoEx("%s>> slotLoop:%d, SlotBitMap:0x%x \n", __FUNCTION__, slotLoop, SlotBitmap);
        if(SlotBitmap != 0)
        {
            subFrameBitmap = subFrameBitmap |  SET_BIT(frameNum*2+1);
            break;
        }
    }

    if(flag != 1)
    {
        subFrameBitmap = subFrameBitmap & REV_BIT(frameNum*2+1);
    }

    dbgInfoEx("%s>> subFrameBitmap_1:0x%llx \n", __FUNCTION__, subFrameBitmap);
    *pSubFrameBitmap = subFrameBitmap;
    return BSP_OK;
}

static UINT32 SetSubFrameBitMapZero(UINT32 frameNum, UINT64 *pSubFrameBitmap)
{
    INPUT_POINTER_CHECK(pSubFrameBitmap);


    *pSubFrameBitmap = *pSubFrameBitmap & REV_BIT(frameNum*2) & REV_BIT(frameNum*2+1);
    dbgInfoEx("%s>> frameNum:%d, SubFrameBitmap:0x%llx\n", __FUNCTION__, frameNum, *pSubFrameBitmap);

    return BSP_OK;
}

UINT32 BspConverFrameBitmapToSubFrameBitmap(UINT32 *pFrameBitmap, T_DmimoSlotInfo *pSlotInfo, UINT64 *pSubframeBitmap)
{
    UINT32 arrayIndex = 0;
    UINT32 bitIndex = 0;
    UINT32 frameBitmap = 0;
    UINT64 subFrameBitmap = 0;
    UINT32 bitVal = 0;
    UINT32 frameNum = 0;
    UINT32 groupNum = 0;
    UINT32 result = 0;
    T_DmimoSlotInfo *pSlot = NULL;
    UINT32 ret = BSP_OK;


    INPUT_POINTER_CHECK(pFrameBitmap);
    INPUT_POINTER_CHECK(pSlotInfo);
    INPUT_POINTER_CHECK(pSubframeBitmap);

    for(arrayIndex = 0; arrayIndex < FRAME_BIT_MAP_ARRAY_LEN; arrayIndex++ )
    {
        frameBitmap = pFrameBitmap[arrayIndex];
        dbgInfoEx("%s>> arrayIndex:%d, frameBitmap:0x%x\n", __FUNCTION__, arrayIndex, frameBitmap);
        for(bitIndex = 0; bitIndex < UINT32_BIT_LEN; bitIndex++ )
        {
            bitVal = frameBitmap & SET_BIT(bitIndex);
            dbgInfoEx("%s>> bitIndex:%d, bitVal:0x%x\n", __FUNCTION__, bitIndex, bitVal);
            if(bitVal != 0)
            {
                frameNum = (arrayIndex*UINT32_BIT_LEN) + bitIndex;
                ret = FindGroupNumByFrameNum(frameNum, pSlotInfo, &result, &groupNum);
                dbgInfoEx("%s>> frameNum:%d, groupNum:%d, result:%d\n", __FUNCTION__, frameNum, groupNum, result);
                if(ret == BSP_OK)
                {
                    if(result == 1)
                    {
                        pSlot = pSlotInfo + groupNum;
                        ret = GetSubFrameBitMap(pSlot, bitIndex, &subFrameBitmap);
                        dbgInfoEx("%s>> bitIndex:%d, StartFrNo:%d, subFrameBitmap:0x%llx\n",
                                __FUNCTION__, bitIndex, pSlot->uiStartFrNo, subFrameBitmap);
                        if(ret == BSP_ERROR)
                        {
                            dbgErr("%s>> GetSubFrameBitMap failed, StartFrNo:%d, bitIndex:%d ret:%d!\n", __FUNCTION__, pSlot->uiStartFrNo, bitIndex, ret);
                            return BSP_ERROR;
                        }
                    }
                    else
                    {
                        ret = SetSubFrameBitMapZero(bitIndex, &subFrameBitmap);
                        if(ret == BSP_ERROR)
                        {
                            dbgErr("%s>> SetSubFrameBitMapZero failed, subFrameBitmap:0x%llx, bitIndex:%d, ret:%d !\n",
                                    __FUNCTION__, subFrameBitmap, bitIndex, ret);
                            return BSP_ERROR;
                        }
                    }
                }
                else
                {
                    dbgErr("%s>> FindGroupNumByFrameNum failed, frameNum:%d, uiStartFrNo:%d, uiEndFrNo:%d, uiSlotBitmap:0x%x ret:%d !\n", __FUNCTION__,
                            frameNum, pSlotInfo->uiStartFrNo, pSlotInfo->uiEndFrNo, pSlotInfo->uiSlotBitmap, ret);
                    return BSP_ERROR;
                }
            }
            else
            {
                ret = SetSubFrameBitMapZero(bitIndex, &subFrameBitmap);
                if(ret == BSP_ERROR)
                {
                    dbgErr("%s>> SetSubFrameBitMapZero failed, subFrameBitmap:0x%llx, bitIndex:%d ret:%d!\n",
                            __FUNCTION__, subFrameBitmap, bitIndex, ret);
                    return BSP_ERROR;
                }
            }
            dbgInfoEx("%s>> bitIndex:%d, subFrameBitmap:0x%llx\n", __FUNCTION__, bitIndex,  subFrameBitmap);
        }
        *pSubframeBitmap = subFrameBitmap;
        dbgInfoEx("%s>> arrayIndex:%d, subFrameBitmap:0x%llx\n", __FUNCTION__, arrayIndex,  subFrameBitmap);
    }

    return BSP_OK;
}
UINT32 BspConverFrameBitmapToSubFrameBitmap1(UINT32 *pFrameBitmap, T_DmimoSlotInfo *pSlotInfo, UINT32 *pSubframeBitmap)
{

    UINT32 uiRet = 0;
    UINT32 uiDlFrNo = 0;
    UINT32 uiDlSlotBitMap = 0;
    UINT32 uiFrSecNo = 0;
    UINT32 uiNewFrBitMapWord = 0;
    UINT32 uiNewBit = 0;
    UINT32 uiLoop = 0;
    UINT32 uiLoopBit = 0;

    for(uiLoop=0; uiLoop<DMIMO_BITMAP_FRAME_NUM; uiLoop++)
    {
        if(pFrameBitmap[uiLoop] != 0)
        {
            for(uiLoopBit = 0; uiLoopBit<DMIMO_BITMAP_WORD_LENGTH; uiLoopBit ++)
            {
                if(((pFrameBitmap[uiLoop] >> uiLoopBit)&0x01) != 0)
                {
                    uiDlFrNo = uiLoop*DMIMO_BITMAP_WORD_LENGTH + uiLoopBit;//当前遍历到的帧号
                    uiNewFrBitMapWord = uiLoop*2 + (UINT32)(uiLoopBit/16);//新bitmap对应的帧号字（1024bit -> 2048bit）
                    uiNewBit = 2*uiLoopBit - DMIMO_BITMAP_WORD_LENGTH*(UINT32)(uiLoopBit/16);//新bitmap所对应的bit位
                    BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK(uiFrSecNo, DMIMO_MAX_FRAME_SECTION_NUM);
                    BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK(uiNewFrBitMapWord, DMIMO_BITMAP_WORD_LENGTH*2);

                    if(uiDlFrNo > pSlotInfo[uiFrSecNo].uiEndFrNo)
                    {
                        uiFrSecNo ++;//当前帧号>=当前帧段结尾帧号时，帧段号加1
                        BSP_INPUT_NUMBER_OF_THRESHOLD_CHECK(uiFrSecNo, DMIMO_MAX_FRAME_SECTION_NUM);
                    }
                    uiDlSlotBitMap =  pSlotInfo[uiFrSecNo].uiSlotBitmap;

                    if((uiDlSlotBitMap & 0x3FF) > 0)//低10bit存在有效值
                    {
                    	pSubframeBitmap[uiNewFrBitMapWord] |= ((UINT32)1 << uiNewBit);
                    }
                    if(((uiDlSlotBitMap >> 10) & 0x3FF) > 0)//高10bit存在有效值
                    {
                    	pSubframeBitmap[uiNewFrBitMapWord] |= ((UINT32)1 << (uiNewBit+1));
                    }
                }
            }
        }
    }

    return uiRet;

}
T_SUBFRAME_BITMAP_MSG subframe = {0};
UINT32 Printsubframe(VOID)
{
	UINT32 iloop=0;
    for(iloop= 0;iloop<32;iloop++)
    {
    	RedirPrintf("bitmap[%d]:%llx\n",iloop,subframe.bitmap[iloop]);
    }
    return BSP_OK;
}
UINT32 BspHandleFrameBitmap(T_DmimoParaUint *pDmimoPara)
{
   // T_SUBFRAME_BITMAP_MSG subframe = {0};

    UINT32 subframe1[64] ={0};
    UINT32 ret = BSP_OK;

/*
    ret = BspConverFrameBitmapToSubFrameBitmap(pDmimoPara->uiFrNoBitmap, pDmimoPara->uiSlotInfo, subframe.bitmap);
    if(ret != BSP_OK)
    {
        dbgErr("%s>> BspConverFrameBitmapToSubFrameBitmap failed!, ret:%d \n", __FUNCTION__, ret);
        return BSP_ERROR;
    }

*/
    BspConverFrameBitmapToSubFrameBitmap1(pDmimoPara->uiFrNoBitmap, pDmimoPara->uiSlotInfo, subframe1);

/*
    subframe.bitmap[0] = 0x01010101;
    subframe.bitmap[1] = 0x02020202;
    subframe.bitmap[62] = 0x5a5a5a5a;
    subframe.bitmap[63] = 0x4b4b4b4b;
    */

    /* Started by AICoder, pid:26b7e8cd5efe4bd1469a088a9095e31613456d7d */
        memcpy_s(subframe.bitmap,sizeof(subframe.bitmap),subframe1,sizeof(subframe1));
    /* Ended by AICoder, pid:26b7e8cd5efe4bd1469a088a9095e31613456d7d */
    ret = BspKoSubFrameCfg(&subframe);

    return ret;
}


/*****************************************************************************
 * 函数名称: BspSetDmimoUtTddCfg
 * 功能描述: dmimo ut第4套TDD配置设置
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoUtTddCfg(T_CarrTddIndCfg *tddIndCfg)
{
    UINT32 ret = BSP_OK;
    UINT32 tddCfgChanMask = 0;

    tddIndCfg->uiTddCfgId = 3;
    tddCfgChanMask = tddIndCfg->uiChanMask;
    ret  =  BspHalAdaptDifCfgTdd_TDD(tddIndCfg,tddCfgChanMask);
    //ret |=  BspHalAdaptUtTddUpdate();
    return ret;
}


/*****************************************************************************
 * 函数名称: BspHalAdaptSetDmimoPsyncSynCfg
 * 功能描述: 光UTDOA Dmimo 超帧号处理
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoPsyncSynSwitch(UINT32 uSwitch)
{
	return BspHalAdaptSetDmimoPsyncIrqCfg(uSwitch);
}

/*****************************************************************************
 * 函数名称: BspPsyncFrameCheck
 * 功能描述: 帧号是否同步检查
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)

 *----------------------------------------------------------------------------
 */
UINT32 BspPsyncFrameCheck(VOID)
{
	return BspHalAdaptPsyncFrameCheck();
}

/*****************************************************************************
 * 函数名称: BspSetQcellPsyncSyn
 * 功能描述: 帧号同步设置
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)

 *----------------------------------------------------------------------------
 */
UINT32 BspSetQcellPsyncSyn(VOID)
{
	return BspHalAdaptQcellPsyncSyn();
}





/*****************************************************************************
 * 函数名称: setdmimoprint
 * 功能描述: 指定通道 载波，上行或下行采数
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)

 *----------------------------------------------------------------------------
 */
UINT32 setdmimoprint(UINT32 uiChan,UINT32 uiCarrNo,UINT32 uiRadio,UINT32 uiDir,UINT32 uiFrameNo)
{
	PrintInfoSet.dmimoflag = 1;
	PrintInfoSet.uiChan = uiChan;
	PrintInfoSet.uiCarrNo = uiCarrNo;
	PrintInfoSet.uiRadio = uiRadio;
	PrintInfoSet.uiDir = uiDir;
	PrintInfoSet.uiFrameNo = uiFrameNo;
	return BSP_OK;
}


/*****************************************************************************
 * 函数名称: BspSetDmimoBankSample
 * 功能描述: 采数功能
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)

 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoBankSample(UINT32 uiChan,UINT32 ulCarrNo,UINT32 uiRadio,UINT32 uiDir)
{
    UINT32 ret = BSP_OK;
	if(uiDir == TX)
	{
		BspHalAdaptUtDlBankSample(uiChan, ulCarrNo, uiRadio, 0);
		BspHalAdaptUtDlBankSample(uiChan, ulCarrNo, uiRadio, 1);
	}
	else
	{
		BspHalAdaptUtUlBankSample(uiChan, ulCarrNo, uiRadio, 0);
		BspHalAdaptUtUlBankSample(uiChan, ulCarrNo, uiRadio, 1);
	}
	return ret;
}

/*****************************************************************************
 * 函数名称: BspSetOpt2DlPreFrCfgLog
 * 功能描述:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)

 *----------------------------------------------------------------------------
 */
UINT32 BspSetOpt2DlPreFrCfgLog(VOID)
{
	BspHalAdaptGetOpt2DlPreFrCfg(13);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetOpt2DlPreFrCfgLog
 * 功能描述: 光口抓数log
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)

 *----------------------------------------------------------------------------
 */
UINT32 BspSetSampleIf0Log(UINT32 uDir, UINT32 ulCarrNo)
{
	UINT32 iloop=0;
	UINT32 uiHalCarrNo=0;
	T_BspHalAdaptUtDmimoParaCfg g_SendDmimoParaCfg ={0};
	T_BspHalAdaptUtDmimoParaCfg g_BankDmimoParaCfg ={0};

	for(iloop =0 ; iloop < DMIMO_MAX_CARR_NUM;iloop++)
	{
		uiHalCarrNo = s_pDmimoCfgForHal[iloop].ulCarrNo;
	     if(uiHalCarrNo  == ulCarrNo)
	     {
	         if(TX == uDir)
	         {
	 	    	  memcpy_s(&g_SendDmimoParaCfg,sizeof(T_BspHalAdaptUtDmimoParaCfg),&s_pDmimoCfgForHal[iloop].uiParaSendInfo.uiFrNoBitmap[0],sizeof(T_BspHalAdaptUtDmimoParaCfg));
	              BspHalAdaptSampleIf0(uDir,&g_SendDmimoParaCfg);
	         }
	         else if(RX ==  uDir)
	         {
	        	 memcpy_s(&g_BankDmimoParaCfg,sizeof(T_BspHalAdaptUtDmimoParaCfg),&s_pDmimoCfgForHal[iloop].uiParaBackInfo.uiFrNoBitmap[0],sizeof(T_BspHalAdaptUtDmimoParaCfg));
		         BspHalAdaptSampleIf0(uDir,&g_BankDmimoParaCfg);
	         }
	     }
	}
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetUtDlBankSample
 * 功能描述: 帧号同步设置
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)

 *----------------------------------------------------------------------------
 */
UINT32 BspSetDmimoPrint(VOID)
{
	UINT32 iloop=0;
	UINT32 uiChan = 0;
	UINT32 uiChanMask = 0;
	UINT32 uiRadio = 0 ;
	UINT32 ulCarrNo = 0;
	UINT32 uiDir = 0;
	UINT32 uiFrameNo = 9;


	BspPrintDelay(32);
	BspPrintDelay(8192);

	if(1 == PrintInfoSet.dmimoflag)
	{
		uiChan = PrintInfoSet.uiChan;
		ulCarrNo = PrintInfoSet.uiCarrNo;
		uiRadio = PrintInfoSet.uiRadio;
		uiDir = PrintInfoSet.uiDir;
		uiFrameNo = PrintInfoSet.uiFrameNo;
		BspHalAdaptPsyncFramenoInfoPrint(uiFrameNo);
		BspSetDmimoBankSample(uiChan,ulCarrNo,uiRadio, uiDir);
        return BSP_OK;
	}

	BspHalAdaptPsyncFramenoInfoPrint(uiFrameNo);
	for(iloop =0 ; iloop < DMIMO_MAX_CARR_NUM;iloop++)
	{
		uiChanMask = s_pDmimoCfg[iloop].uiChanMask;
		uiRadio = s_pDmimoCfg[iloop].uiRadio;
		ulCarrNo = s_pDmimoCfg[iloop].ulCarrNo;

        if(uiRadio != 0)
        {
            for(uiChan = 0; uiChan < QCELL_MAX_CHAN_NUM; uiChan++)
            {
                if((uiChanMask & ((UINT32)0x1 << uiChan)) !=0)
                {
                	if(uiDirdataFlag == 0)
                	{
                		BspSetDmimoBankSample(uiChan, ulCarrNo, uiRadio,TX);
                		BspSetSampleIf0Log(TX,ulCarrNo);
                	    uiDirdataFlag = 1 ;
                	}
                	else
                	{
                		BspSetDmimoBankSample(uiChan, ulCarrNo, uiRadio,RX);
                		BspSetSampleIf0Log(RX,ulCarrNo);
            			uiDirdataFlag = 0 ;
                	}
                	return BSP_OK;
                }
            }
        }
	}
	return BSP_OK;
}

UINT32 dmimohelp(VOID)
{
    dbgInfo("PrintDmimoCfg \n");
	dbgInfo("PrintFrameNo \n");
    dbgInfo("PrintMasterSwitchEn \n");
    dbgInfo("Printsubframe \n");
	dbgInfo("setdmimoprint(UINT32 uiChan,UINT32 uiCarrNo,UINT32 uiRadio,UINT32 uiDir,UINT32 uiFrameNo)\n");
    return BSP_OK;
}
/*****************************************************************************
 * 函数名称: _BspSuperframenumberProcess
 * 功能描述: 光UTDOA Dmimo 超帧号处理
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */

static void * _BspSuperframenumberProcess(void *para)
{
	// T_FRAME_NUM_MSG MsgSend ;
	// T_FRAME_NUM_MSG MsgRecv ;
	// UINT32 uiStateFlag =0;
	// UINT32 uiLoop =0;
/*    while(1)
    {
    	 BspSysMsDelay(50);
	     BspKoFrameNumCfg(& MsgSend, &MsgRecv);
	     if(MsgRecv.frameNum > 798 && MsgRecv.frameNum <1023 && 0 == uiSuperframenumberFlag)
	     {
	    	    uiSuperframenumberFlag = 1;
	            dbgInfoEx("%s>> bitIndex:%d, uiSuperframenumberFlag:0x%d\n", __FUNCTION__, uiSuperframenumberFlag);
	    	  * if（UTDOA存在的情况下BspGetUtdoaState）
                if( 大遍历使能)
                {
                                       走大遍历
                }
                else{
                    if（（5%256 =5） +1 == 6）
                    {
                             匹配上了，证明下一个超帧要进行UTDOA 小遍历;
                    }
                   else if(dmimo存在)
                   {
                            未匹配上，下一个超帧还是要进行dmimo  + SRS （定位）;
                   }
                   else if(dmimo不存在)
                   {
                             SRS （定位）
                   }
                 else **/
	    	 /*
                 if(dmimo存在)
                 {
                	 for(uiLoop =0; uiLoop< DMIMO_MAX_CARR_NUM; uiLoop++)
                	 {
                		if((1==s_pDmimoMasterSwitchEn[uiLoop].ucMasterSwitchEn)&&  (0x2000 == s_pDmimoMasterSwitchEn[uiLoop].uiRadio))
                		{
                               hal层模式切换接口
                		}
                	 }

                 }
                 */
	 /*    }
	     else
	     {
	    	 dbgInfoEx("%s>> bitIndex:%d, uiSuperframenumberFlag:0x%d\n", __FUNCTION__, uiSuperframenumberFlag);
	    	 uiSuperframenumberFlag = 0;
	     }
    }*/

	return NULL;
}


/**************************************************************************
 * 函数名称： _BspSuperframeNumberThreadInit
 * 功能描述： 光UTDOA Dmimo 超帧号计算线程
 * 输入参数： ulOpt:光口号
 * 输出参数： 无
 * 修改日期    版本号     修改人      修改内容
 * -----------------------------------------------
 **************************************************************************/
UINT32 _BspSuperframeNumberThreadInit(void)
{
	pthread_t  th_id = 0;
	UINT32     ulRet = BSP_OK;

	ulRet = pthread_create(&th_id, NULL, _BspSuperframenumberProcess, NULL);

	if (0 != ulRet)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n",__FUNCTION__,ulRet);
    }
    else
    {
        dbgErr("create thread<%s> success!\n",__FUNCTION__);
    }

	return ulRet;

}

/* DMM一键采集接口 */
UINT32 BspOneClickCollectDmm(VOID)
{
    UINT32 retVal = BSP_OK;

    RedirPrintf(">>> PrintDmimoCfg <<< \n");
    retVal |= PrintDmimoCfg();
    RedirPrintf(">>> Printsubframe <<< \n");
    retVal |= Printsubframe();
    RedirPrintf(">>> PrintMasterSwitchEn <<< \n");
    retVal |= PrintMasterSwitchEn();
    RedirPrintf(">>> PrintFrameNo <<< \n");
    retVal |= PrintFrameNo();

    return retVal;
}

/* Started by AICoder, pid:s93d5v1ebeqe2b3147c60ae9c06e83398d99ce5e */
UINT32 BspGetDmmIsExist()
{
    return uiDmimoIsExist;
}

UINT32 BspSetUtDmmCoexistDmmSt(UINT32 dmmEn)
{
    UINT32 chanMask = 0;
    UINT32 dmmLoop = 0;
    UINT32 chanLoop = 0;
    UINT32 carrId = 0;
    UINT32 radioMode = 0;
    
    dbgInfoEx("%s>> start! \n", __FUNCTION__);
    for(dmmLoop = 0; dmmLoop < DMIMO_MAX_CARR_NUM; dmmLoop++)
    {
        carrId = s_pDmimoCfg[dmmLoop].ulCarrNo;
        radioMode = s_pDmimoCfg[dmmLoop].uiRadio;
        chanMask = s_pDmimoCfg[dmmLoop].uiChanMask;
        for(chanLoop =0 ; chanLoop < QCELL_MAX_CHAN_NUM; chanLoop++)
        {
            if(chanMask & ((UINT32)0x1 << chanLoop))
            {
                BspHalAdaptDmmSendEn(chanLoop,carrId,radioMode,dmmEn);
                BspHalAdaptDmmReceiveEn(chanLoop,carrId,radioMode,dmmEn);
                dbgInfoEx("%s :dmmLoop->%d, carrId-> %d, chan-> %d ,dmmEn = %d\n",__FUNCTION__,dmmLoop,carrId,chanLoop,dmmEn);
            }
        }        
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:s93d5v1ebeqe2b3147c60ae9c06e83398d99ce5e */
/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_block.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块相关实现
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10 
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "srs_config.h"
#include "ichaladapt_ic4_2.h"
/*#include "indoorpositioncommon.h"*/

/**************************************************************************
 *                                 函数声明
 **************************************************************************/



/**************************************************************************
 *                                  宏定义
 **************************************************************************/


/****************************************************************************
 *                               数据类型定义
 ****************************************************************************/
/* link参数更新处理 */

/****************************************************************************
*                         全局变量定义                                            *
****************************************************************************/
T_BspHalAdaptPsotionRadioInfoTnr s_pSrsCfgForOpt_TNR = {0};
T_BspHalAdaptPsotionRadioInfoTdd s_pSrsCfgForOpt_TDD = {0};
T_BspHalAdaptPsotionRadioInfoFddFnr s_pSrsCfgForOpt_FDD = {0};
/****************************************************************************
*                              全局变量                                         *
****************************************************************************/


/* CRC错误计数记录 */

/*****************************************************************************
*                                                                            *
*                              内部函数实现                                        *
*                                                                            *
*****************************************************************************/


/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo_TNR
 * 功能描述: SRS 保存寄存器功能函数 TNR
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSavaSrsRegInfo_TNR(T_RF_SWTICH_MSG * pSrsShareMemRfSwitchData,UINT32 uiOptSrsCarrNo,UINT32 uiClearOrRecoverVal)
{
	UINT32 uiLoop = 0;

	BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiOptSrsCarrNo,SRS_MAX_CELL_NUM_TNR);

	s_pSrsCfgForOpt_TNR.tAddr[uiOptSrsCarrNo].uValidCarrNum = pSrsShareMemRfSwitchData->uiLen;
	s_pSrsCfgForOpt_TNR.tAddr[uiOptSrsCarrNo].uCellId = uiOptSrsCarrNo;

	for(uiLoop = 0;uiLoop<pSrsShareMemRfSwitchData->uiLen;uiLoop++)
	{
		BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiLoop,SRS_MAX_CARR_NUM_ONECELL);

		if(1 ==uiClearOrRecoverVal)
		{
			s_pSrsCfgForOpt_TNR.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pSrsCfgForOpt_TNR.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uClearVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}

		if(0 ==uiClearOrRecoverVal)
		{
			s_pSrsCfgForOpt_TNR.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pSrsCfgForOpt_TNR.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uRecoverVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}
	}
	return BSP_OK;

}

/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo_TDD
 * 功能描述: SRS 保存寄存器功能函数 TNR
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSavaSrsRegInfo_TDD(T_RF_SWTICH_MSG * pSrsShareMemRfSwitchData,UINT32 uiOptSrsCarrNo,UINT32 uiClearOrRecoverVal)
{
	UINT32 uiLoop = 0;

	BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiOptSrsCarrNo,SRS_MAX_CELL_NUM_TLTE);
	s_pSrsCfgForOpt_TDD.tAddr[uiOptSrsCarrNo].uValidCarrNum = pSrsShareMemRfSwitchData->uiLen;
	s_pSrsCfgForOpt_TDD.tAddr[uiOptSrsCarrNo].uCellId = uiOptSrsCarrNo;

	for(uiLoop = 0;uiLoop<pSrsShareMemRfSwitchData->uiLen;uiLoop++)
	{
		BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiLoop,SRS_MAX_CARR_NUM_ONECELL);
		if(1 ==uiClearOrRecoverVal)
		{
			s_pSrsCfgForOpt_TDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pSrsCfgForOpt_TDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uClearVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}

		if(0 ==uiClearOrRecoverVal)
		{
			s_pSrsCfgForOpt_TDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pSrsCfgForOpt_TDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uRecoverVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}
	}
	return BSP_OK;

}

/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo_TDD
 * 功能描述: SRS 保存寄存器功能函数 TNR
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSavaSrsRegInfo_FDD(T_RF_SWTICH_MSG * pSrsShareMemRfSwitchData,UINT32 uiOptSrsCarrNo,UINT32 uiClearOrRecoverVal)
{
	UINT32 uiLoop = 0;

	BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiOptSrsCarrNo,SRS_MAX_CELL_NUM_FDD);

	s_pSrsCfgForOpt_FDD.tAddr[uiOptSrsCarrNo].uValidCarrNum = pSrsShareMemRfSwitchData->uiLen;
	s_pSrsCfgForOpt_FDD.tAddr[uiOptSrsCarrNo].uCellId = uiOptSrsCarrNo;

	for(uiLoop = 0;uiLoop<pSrsShareMemRfSwitchData->uiLen;uiLoop++)
	{
		BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiLoop,SRS_MAX_CARR_NUM_ONECELL);
		if(1 ==uiClearOrRecoverVal)
		{
			s_pSrsCfgForOpt_FDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pSrsCfgForOpt_FDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uClearVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}

		if(0 ==uiClearOrRecoverVal)
		{
			s_pSrsCfgForOpt_FDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uAddr = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiPhyAddr;
			s_pSrsCfgForOpt_FDD.tAddr[uiOptSrsCarrNo].tAddrInfo[uiLoop].uRecoverVal = pSrsShareMemRfSwitchData->UtRegInfo[uiLoop].uiRegVal;
		}
	}
	return BSP_OK;

}

/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo
 * 功能描述: SRS 保存寄存器功能函数
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSavaSrsRegInfo(T_RF_SWTICH_MSG * pSrsShareMemRfSwitchData,UINT32 uiRadioMode,UINT32 uiOptSrsCarrNo,UINT32 uiClearOrRecoverVal)
{

    switch(uiRadioMode)
    {
        case BSP_RADIO_STANDARD_NR:
        {
        	BspSavaSrsRegInfo_TNR(pSrsShareMemRfSwitchData,uiOptSrsCarrNo,uiClearOrRecoverVal);
            break;
        }
        case BSP_RADIO_STANDARD_LTE_TDD:
        {
        	BspSavaSrsRegInfo_TDD(pSrsShareMemRfSwitchData,uiOptSrsCarrNo,uiClearOrRecoverVal);
            break;
        }
        case BSP_RADIO_STANDARD_FDD_NR:
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
        	BspSavaSrsRegInfo_FDD(pSrsShareMemRfSwitchData,uiOptSrsCarrNo,uiClearOrRecoverVal);
            break;
        }
        default:
        {
            break;
        }
    }
	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSavaSrsRegInfo
 * 功能描述: SRS 获取寄存器功能函数
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsRegInfo(TRruChnCarrPositionSrsItem * pSrsCfg,UINT32 uiGrp,UINT32 uiClearOrRecoverVal)
{
	UINT32 uiLoop = 0;
    T_RF_SWTICH_MSG ShareMemRfSwitchData = {0};
    E_RegType uiType   = UT_REG_TYPE_SRS;



    BspHalAdaptClrSaveRegInfo(uiType,uiGrp);
    BspHalAdaptSetSaveGrp(uiType,uiGrp);
    BspHalAdaptSetSaveRegEn(1);

    for(uiLoop = 0 ; uiLoop<BspGetTxChanNum(); uiLoop++)
    {
    	 if((pSrsCfg->uiChnMask & ((UINT32)0x1 << uiLoop)) !=0)
    	 {
    		 BspHalAdaptRcdTdmAigaClr(uiLoop,pSrsCfg->uiCarrNo, pSrsCfg->uiRadioMode, uiClearOrRecoverVal);/*1是清零值*/
    		 BspHalAdaptSetCcToGainDelay(uiLoop,pSrsCfg->uiCarrNo,pSrsCfg->uiRadioMode);
    	 }
    }

    BspHalAdaptSetSaveRegEn(0);
    BspHalAdaptGetSaveRegInfo(uiType,uiGrp, &ShareMemRfSwitchData);
    BspSavaSrsRegInfo(&ShareMemRfSwitchData,pSrsCfg->uiRadioMode,pSrsCfg->uiOptSrsCarrNo,uiClearOrRecoverVal);
	return BSP_OK;

}

/*****************************************************************************
 * 函数名称: BspGetSrsCellChanNum
 * 功能描述: 获取 SRS 小区  的 通道个数。也是该小区有效载波数uValidCarrNum。
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetSrsCellChanNum(UINT32 uiChnMask)
{
	UINT32 uiLoop = 0;
	UINT32 uiChanNum = 0;
	for(uiLoop =0 ; uiLoop<BspGetTxChanNum();uiLoop++)
	{
   	    if((uiChnMask & ((UINT32)0x1 << uiLoop)) !=0)
   	    {
   		     uiChanNum ++;
   	    }
	}
	return uiChanNum;
}
/*****************************************************************************
 * 函数名称: BspHandleSrsSlotCfgInfo_TNR
 * 功能描述: SRS Slot号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsSlotCfgInfo_TNR(UINT32 uiSrsSFBitMap,UINT32 uiOptSrsCarrNo)
{
	UINT32 uiLoop = 0;

	BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiOptSrsCarrNo,SRS_MAX_CELL_NUM_TNR);

	BspHalAdaptM0SetSfBitmapTnr(uiOptSrsCarrNo,BSP_RADIO_STANDARD_NR,uiSrsSFBitMap);

	for(uiLoop = 0; uiLoop<SRS_MAX_SLOT_NUM_TNR ; uiLoop++)
	{
		if( (uiSrsSFBitMap >>uiLoop) & 0x1 )
		{
			s_pSrsCfgForOpt_TNR.uSlotCellidMap[uiOptSrsCarrNo][uiLoop][0] = 0xf;
		}

	}
	return BSP_OK;

}

/*****************************************************************************
 * 函数名称: BspHandleSrsSlotCfgInfo_TDD
 * 功能描述: SRS Slot号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsSlotCfgInfo_TDD(UINT32 uiSrsSFBitMap,UINT32 uiOptSrsCarrNo)
{
	UINT32 uiLoop = 0;

	BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiOptSrsCarrNo,SRS_MAX_CELL_NUM_TLTE);

	for(uiLoop = 0; uiLoop<SRS_MAX_SLOT_NUM_TLTE ; uiLoop++)
	{
		if( (uiSrsSFBitMap >>uiLoop) & 0x1 )
		{
			s_pSrsCfgForOpt_TDD.uSlotCellidMap[uiOptSrsCarrNo][uiLoop][0] = 0xf;
		}

	}
	return BSP_OK;

}
/*****************************************************************************
 * 函数名称: BspHandleSrsSlotCfgInfo_TDD
 * 功能描述: SRS Slot号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsSlotCfgInfo_FDD(UINT32 usSrsSFBitMap,UINT32 uiOptSrsCarrNo)
{
	UINT32 uiLoop = 0;

	BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiOptSrsCarrNo,SRS_MAX_CELL_NUM_FDD);

	for(uiLoop = 0; uiLoop<SRS_MAX_SLOT_NUM_FDD ; uiLoop++)
	{
		if( (usSrsSFBitMap >>uiLoop) & 0x1 )
		{
			s_pSrsCfgForOpt_FDD.uSlotCellidMap[uiOptSrsCarrNo][uiLoop][0] = 0xf;
		}

	}
	return BSP_OK;

}
/*****************************************************************************
 * 函数名称: BspHandleSrsRegInfo
 * 功能描述: SRS Slot号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsSlotCfgInfo(UINT32 uiRadioMode , UINT32 uiSrsSFBitMap,UINT32 uiOptSrsCarrNo)
{

    switch(uiRadioMode)
    {
        case BSP_RADIO_STANDARD_NR:
        {
        	BspHandleSrsSlotCfgInfo_TNR(uiSrsSFBitMap,uiOptSrsCarrNo);
            break;
        }
        case BSP_RADIO_STANDARD_LTE_TDD:
        {
        	BspHandleSrsSlotCfgInfo_TDD(uiSrsSFBitMap,uiOptSrsCarrNo);
            break;
        }
        case BSP_RADIO_STANDARD_FDD_NR:
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
        	BspHandleSrsSlotCfgInfo_FDD(uiSrsSFBitMap,uiOptSrsCarrNo);
            break;
        }
        default:
        {
            break;
        }
    }
	return BSP_OK;


}
/*****************************************************************************
 * 函数名称: BspHandleSrsFrameCfgInfo_TNR
 * 功能描述: SRS Frame号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsFrameCfgInfo_TNR(TRruChnCarrPositionSrsItem * pSrsCfg)
{
	UINT32 uiLoop = 0;

	UINT32 uiSrsData0 = 0;
	UINT32 uiSrsData1 = 0;
	UINT32 uiOptSrsCarrNo = 0;
	UINT32 uiPrruPollTime = 0;
	UINT32 uiPrruPollNum = 0;
	UINT32 uiPrruPollPeriodFactor = 0;
	UINT32 uiFrameCellidMap = 0;


	uiPrruPollTime = (UINT32 )pSrsCfg->ucPrruPollTime;
	uiPrruPollNum = (UINT32 )pSrsCfg->ucPrruPollNum;
	uiPrruPollPeriodFactor = (UINT32 )pSrsCfg->usPrruPollPeriodFactor;
	uiOptSrsCarrNo = pSrsCfg->uiOptSrsCarrNo;

	if( (0 == uiPrruPollTime) || (0 == uiPrruPollNum) || (0==uiPrruPollPeriodFactor) )
	{
		return BSP_OK;
	}

	for(uiLoop=0; uiLoop< SRS_MAX_FRAME_NUM ; uiLoop++)
	{
		uiSrsData0 = uiLoop % ((uiPrruPollTime * uiPrruPollNum) * uiPrruPollPeriodFactor);
		uiSrsData1 =  uiSrsData0 / uiPrruPollTime;
		uiFrameCellidMap = s_pSrsCfgForOpt_TNR.uFrameCellidMap[uiLoop]; /*回传 不清零*/


        if(uiSrsData0 < (uiPrruPollTime * uiPrruPollNum))
        {
        	if(uiSrsData1 == ((UINT32)pSrsCfg->ucPRRUPositionID) )
        	{
        		s_pSrsCfgForOpt_TNR.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,0,(4*(uiOptSrsCarrNo-1)),4);/*回传 不清零，对应的bit写0*/
        	}
        	else
        	{
        		s_pSrsCfgForOpt_TNR.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,uiOptSrsCarrNo,(4*(uiOptSrsCarrNo-1)),4);/*清零 记录当前的小区*/
        	}
        }
        else
        {
    		s_pSrsCfgForOpt_TNR.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,0,(4*(uiOptSrsCarrNo-1)),4);/*回传 不清零，对应的bit写0*/
        }

	}




	return BSP_OK;
}


/*****************************************************************************
 * 函数名称: BspHandleSrsFrameCfgInfo_TDD
 * 功能描述: SRS Frame号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsFrameCfgInfo_TDD(TRruChnCarrPositionSrsItem * pSrsCfg)
{
	UINT32 uiLoop = 0;

	UINT32 uiSrsData0 = 0;
	UINT32 uiSrsData1 = 0;
	UINT32 uiOptSrsCarrNo = 0;
	UINT32 uiPrruPollTime = 0;
	UINT32 uiPrruPollNum = 0;
	UINT32 uiPrruPollPeriodFactor = 0;
	UINT32 uiFrameCellidMap = 0;


	uiPrruPollTime = (UINT32 )pSrsCfg->ucPrruPollTime;
	uiPrruPollNum = (UINT32 )pSrsCfg->ucPrruPollNum;
	uiPrruPollPeriodFactor = (UINT32 )pSrsCfg->usPrruPollPeriodFactor;
	uiOptSrsCarrNo = pSrsCfg->uiOptSrsCarrNo;

	if( (0 == uiPrruPollTime) || (0 == uiPrruPollNum) || (0==uiPrruPollPeriodFactor))
	{
		return BSP_OK;
	}

	for(uiLoop=0; uiLoop< SRS_MAX_FRAME_NUM ; uiLoop++)
	{
		uiSrsData0 = uiLoop % ((uiPrruPollTime * uiPrruPollNum) * uiPrruPollPeriodFactor);
		uiSrsData1 =  uiSrsData0 / uiPrruPollTime;
		uiFrameCellidMap = s_pSrsCfgForOpt_TDD.uFrameCellidMap[uiLoop]; /*回传 不清零*/


        if(uiSrsData0 < (uiPrruPollTime * uiPrruPollNum))
        {
        	if(uiSrsData1 == ((UINT32)pSrsCfg->ucPRRUPositionID) )
        	{
        		s_pSrsCfgForOpt_TDD.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,0,(4*(uiOptSrsCarrNo-1)),4);/*回传 不清零，对应的bit写0*/
        	}
        	else
        	{
        		s_pSrsCfgForOpt_TDD.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,uiOptSrsCarrNo,(4*(uiOptSrsCarrNo-1)),4);/*清零 记录当前的小区*/
        	}
        }
        else
        {
    		s_pSrsCfgForOpt_TDD.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,0,(4*(uiOptSrsCarrNo-1)),4);/*回传 不清零，对应的bit写0*/
        }

	}

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspHandleSrsFrameCfgInfo_TDD
 * 功能描述: SRS Frame号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsFrameCfgInfo_FDD(TRruChnCarrPositionSrsItem * pSrsCfg)
{
	UINT32 uiLoop = 0;

	UINT32 uiSrsData0 = 0;
	UINT32 uiSrsData1 = 0;
	UINT32 uiOptSrsCarrNo = 0;
	UINT32 uiPrruPollTime = 0;
	UINT32 uiPrruPollNum = 0;
	UINT32 uiPrruPollPeriodFactor = 0;
	UINT32 uiFrameCellidMap = 0;


	uiPrruPollTime = (UINT32 )pSrsCfg->ucPrruPollTime;
	uiPrruPollNum = (UINT32 )pSrsCfg->ucPrruPollNum;
	uiPrruPollPeriodFactor = (UINT32 )pSrsCfg->usPrruPollPeriodFactor;
	uiOptSrsCarrNo = pSrsCfg->uiOptSrsCarrNo;


	if( (0 == uiPrruPollTime) || (0 == uiPrruPollNum) || (0==uiPrruPollPeriodFactor))
	{
		return BSP_OK;
	}

	for(uiLoop=0; uiLoop< SRS_MAX_FRAME_NUM ; uiLoop++)
	{
		uiSrsData0 = uiLoop % ((uiPrruPollTime * uiPrruPollNum) * uiPrruPollPeriodFactor);
		uiSrsData1 =  uiSrsData0 / uiPrruPollTime;
		uiFrameCellidMap = s_pSrsCfgForOpt_FDD.uFrameCellidMap[uiLoop]; /*回传 不清零*/


        if(uiSrsData0 < (uiPrruPollTime * uiPrruPollNum))
        {
        	if(uiSrsData1 == ((UINT32)pSrsCfg->ucPRRUPositionID) )
        	{
        		s_pSrsCfgForOpt_FDD.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,0,(4*(uiOptSrsCarrNo-1)),4);/*回传 不清零，对应的bit写0*/
        	}
        	else
        	{
        		s_pSrsCfgForOpt_FDD.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,uiOptSrsCarrNo,(4*(uiOptSrsCarrNo-1)),4);/*清零 记录当前的小区*/
        	}
        }
        else
        {
        	s_pSrsCfgForOpt_FDD.uFrameCellidMap[uiLoop] = BIT_FIELD_MASK_CFG(uiFrameCellidMap,0,(4*(uiOptSrsCarrNo-1)),4);/*回传 不清零，对应的bit写0*/
        }

	}

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspHandleSrsFrameCfgInfo
 * 功能描述: SRS Frame号bitmap配置信息处理
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspHandleSrsFrameCfgInfo(TRruChnCarrPositionSrsItem * pSrsCfg)
{
	    UINT32  uiRadioMode = 0;

	    uiRadioMode = pSrsCfg->uiRadioMode;

	    switch(uiRadioMode)
	    {
	        case BSP_RADIO_STANDARD_NR:
	        {
	        	BspHandleSrsFrameCfgInfo_TNR(pSrsCfg);
	            break;
	        }
	        case BSP_RADIO_STANDARD_LTE_TDD:
	        {
	        	BspHandleSrsFrameCfgInfo_TDD(pSrsCfg);
	            break;
	        }
	        case BSP_RADIO_STANDARD_FDD_NR:
	        case BSP_RADIO_STANDARD_LTE_FDD:
	        {
	        	BspHandleSrsFrameCfgInfo_FDD(pSrsCfg);
	            break;
	        }
	        default:
	        {
	            break;
	        }
	    }
		return BSP_OK;
}

UINT32 BspPrintSrsCfg(TRruChnCarrPositionSrsItem * pSrsCfg)
{
    dbgInfo("%s>> uiChnMask:%d \n", __FUNCTION__, pSrsCfg->uiChnMask);
    dbgInfo("%s>> uiCarrNo:%d \n", __FUNCTION__, pSrsCfg->uiCarrNo);
    dbgInfo("%s>> uiCellId:%d \n", __FUNCTION__, pSrsCfg->uiCellId);
    dbgInfo("%s>> uiOptSrsCarrNo:%d \n", __FUNCTION__, pSrsCfg->uiOptSrsCarrNo);
    dbgInfo("%s>> uiRadioMode:%d \n", __FUNCTION__, pSrsCfg->uiRadioMode);
    dbgInfo("%s>> ucCpId:%d \n", __FUNCTION__, pSrsCfg->ucCpId);
    dbgInfo("%s>> ucCPType:%d \n", __FUNCTION__, pSrsCfg->ucCPType);
    dbgInfo("%s>> ucQcellPositionEnable:%d \n", __FUNCTION__, pSrsCfg->ucQcellPositionEnable);
    dbgInfo("%s>> ucPRRUPositionID:%d \n", __FUNCTION__, pSrsCfg->ucPRRUPositionID);
    dbgInfo("%s>> ucPrruPollNum:%d \n", __FUNCTION__, pSrsCfg->ucPrruPollNum);
    dbgInfo("%s>> ucPrruPollTime:%d \n", __FUNCTION__, pSrsCfg->ucPrruPollTime);
    dbgInfo("%s>> uiSrsSFBitMap:%d \n", __FUNCTION__, pSrsCfg->uiSrsSFBitMap);
    dbgInfo("%s>> usPrruPollPeriodFactor:%d \n", __FUNCTION__, pSrsCfg->usPrruPollPeriodFactor);

	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetSrsFrAdjustVal
 * 功能描述: 光口帧头调整量解耦 - SRS
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSrsFrAdjustVal(TRruChnCarrPositionSrsItem * pSrsCfg)
{
    UINT32 chanMask = 0;
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;
    chanMask = pSrsCfg->uiChnMask;
    for(chan = 0; chan < QCELL_MAX_CHAN_NUM; chan++)
    {
        if((chanMask & ((UINT32)0x1 << chan)) !=0)
        {
            retVal = BspHalAdaptSetFeatureFrAdjustVal(chan, pSrsCfg->uiCarrNo, pSrsCfg->uiRadioMode, E_QCELL_SRS_FUNCION);
        }
    }   
    return retVal;
}


/*****************************************************************************
 * 函数名称: BspSetSrsConfig
 * 功能描述: SRS 对APP接口
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSrsConfig(TRruChnCarrPositionSrsItem * pSrsCfg)
{
	UINT32 uiGrp = 0;

	UINT32 uiClear = 1;
	UINT32 uiRecoverVal =0;



	BspPrintSrsCfg(pSrsCfg);

	/*光口帧头调整量解耦*/
	BspSetSrsFrAdjustVal(pSrsCfg);

    uiGrp = pSrsCfg->uiOptSrsCarrNo*2 -2;
    BspHandleSrsRegInfo(pSrsCfg,uiGrp,uiClear);

    uiGrp = pSrsCfg->uiOptSrsCarrNo*2 -1;
    BspHandleSrsRegInfo(pSrsCfg,uiGrp,uiRecoverVal);



    BspHandleSrsFrameCfgInfo(pSrsCfg);

    BspHandleSrsSlotCfgInfo(pSrsCfg->uiRadioMode, pSrsCfg->uiSrsSFBitMap, pSrsCfg->uiOptSrsCarrNo);


	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspSetSrsOptEn
 * 功能描述: 使能制式下的所有小区的SRS配置。
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSrsOptEn(UINT32 uValidCellNum,UINT32 uiRadioMode)
{
	   switch(uiRadioMode)
	    {
	        case BSP_RADIO_STANDARD_NR:
	        {

	        	s_pSrsCfgForOpt_TNR.uValidCellNum = uValidCellNum;
	        	s_pSrsCfgForOpt_TNR.uInfoValidFlag = 1;
        s_pSrsCfgForOpt_TNR.frameNoAdjustFlag = BspHalAdaptGetSrsFrameNoDelayAdjustFlagTnr();
	        	BspHalAdaptM0SetMesgTnr(&s_pSrsCfgForOpt_TNR);

	        	 /*光口开中断 接口*/
	            break;
	        }
	        case BSP_RADIO_STANDARD_LTE_TDD:
	        {
	        	s_pSrsCfgForOpt_TDD.uValidCellNum = uValidCellNum;
	        	s_pSrsCfgForOpt_TDD.uInfoValidFlag = 1;
        s_pSrsCfgForOpt_TDD.frameNoAdjustFlag = 0;
	        	BspHalAdaptM0SetMesgTlte(&s_pSrsCfgForOpt_TDD);
	        	 /*光口开中断 接口*/
	            break;
	        }
	        case BSP_RADIO_STANDARD_FDD_NR:
	        case BSP_RADIO_STANDARD_LTE_FDD:
	        {
	        	s_pSrsCfgForOpt_FDD.uValidCellNum = uValidCellNum;
	        	s_pSrsCfgForOpt_FDD.uInfoValidFlag = 1;
        s_pSrsCfgForOpt_FDD.frameNoAdjustFlag = BspHalAdaptGetSrsFrameNoDelayAdjustFlagFdd();
	        	BspHalAdaptM0SetMesgFdd(&s_pSrsCfgForOpt_FDD);
	        	 /*光口开中断 接口*/
	            break;
	        }
	        default:
	        {
	            break;
	        }
	    }
	return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspCleanSrsCfg
 * 功能描述: 清除同一制式的所有SRS小区配置
 * 输入参数: grpId - Group ID(也就是IC的J204 Block Id)
 * 输出参数: 无
 * 返 回 值: BSP_OK/BSP_ERROR
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10248577@2021-08-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspCleanSrsCfg(UINT32 uiRadioMode)
{
	   switch(uiRadioMode)
	    {
	        case BSP_RADIO_STANDARD_NR:
	        {
	        	 memset_s(&s_pSrsCfgForOpt_TNR,sizeof(T_BspHalAdaptPsotionRadioInfoTnr),0,sizeof(T_BspHalAdaptPsotionRadioInfoTnr));
	        	 BspHalAdaptM0ClearMesgTnr();
	            break;
	        }
	        case BSP_RADIO_STANDARD_LTE_TDD:
	        {
	        	BspHalAdaptM0ClearMesgTlte();
	        	 memset_s(&s_pSrsCfgForOpt_TDD,sizeof(T_BspHalAdaptPsotionRadioInfoTdd),0,sizeof(T_BspHalAdaptPsotionRadioInfoTdd));
	            break;
	        }
	        case BSP_RADIO_STANDARD_FDD_NR:
	        case BSP_RADIO_STANDARD_LTE_FDD:
	        {
	        	BspHalAdaptM0ClearMesgFdd();
	        	memset_s(&s_pSrsCfgForOpt_FDD,sizeof(T_BspHalAdaptPsotionRadioInfoFddFnr),0,sizeof(T_BspHalAdaptPsotionRadioInfoFddFnr));
	            break;
	        }
	        default:
	        {
	            break;
	        }
	    }
	return BSP_OK;
}


UINT32 BspSetSrsPsyncIrqCfgTnr(UINT32 uSwitch)
{
	UINT32 retVal = BSP_OK;
	retVal = BspHalAdaptSrsPsyncIrqCfgTnr(uSwitch);

	if(0 == uSwitch)
	{
		retVal = BspHalAdaptSrsSetRevMesgTnr();
		dbgInfo("[%s]  uSwitch is off,  Recover TNR MSG\n",__FUNCTION__);
	}
	return retVal;
}

UINT32 BspSetSrsPsyncIrqCfgTlte(UINT32 uSwitch)
{
	UINT32 retVal = BSP_OK;
	retVal = BspHalAdaptSrsPsyncIrqCfgTlte(uSwitch);

	if(0 == uSwitch)
	{
		retVal = BspHalAdaptSrsSetRevMesgTlte();
		dbgInfo("[%s]  uSwitch is off,  Recover TLTE MSG\n",__FUNCTION__);
	}
	return retVal;
}
UINT32 BspSetSrsPsyncIrqCfgFdd(UINT32 uSwitch)
{
	UINT32 retVal = BSP_OK;
	retVal = BspHalAdaptSrsPsyncIrqCfgFdd(uSwitch);

	if(0 == uSwitch)
	{
		retVal = BspHalAdaptSrsSetRevMesgFdd();
		dbgInfo("[%s]  uSwitch is off,  Recover Fdd MSG\n",__FUNCTION__);
	}
	return retVal;
}


TRruChnCarrPositionSrsItem srsdate ={0};
UINT32 srstest(UINT32 uiRadioMode)
{
	srsdate.uiChnMask =0x3c;
	srsdate.uiCarrNo = 0;
	srsdate.uiCellId = 123456;

	srsdate.uiOptSrsCarrNo =2;
	srsdate.uiRadioMode = uiRadioMode;
	srsdate.ucCpId = 3;

	srsdate.ucCPType = 4;
	srsdate.ucQcellPositionEnable = 6;
	srsdate.ucPRRUPositionID = 1;

	srsdate.ucPrruPollNum = 4;
	srsdate.ucPrruPollTime = 2;
	srsdate.uiSrsSFBitMap = 0x88;
	srsdate.usPrruPollPeriodFactor = 4;
	BspCleanSrsCfg(uiRadioMode);
	BspSetSrsConfig(&srsdate);
	BspSetSrsOptEn(1,uiRadioMode);

	return BSP_OK;
}
UINT32 printsrsinfonr(VOID)
{
	UINT32 uiloop =0;
	UINT32 uiloopcell =0;
	RedirPrintf("-------nr srs-------\n");
	RedirPrintf("uInfoValidFlag:%d\n",s_pSrsCfgForOpt_TNR.uInfoValidFlag);
	RedirPrintf("uInfoValidFlag:%d\n",s_pSrsCfgForOpt_TNR.uValidCellNum);


	RedirPrintf("uFrameCellidMap\n");
    for(uiloop =0;uiloop<SRS_MAX_FRAME_NUM;uiloop++)
    {
		if((uiloop!=0) && (!(uiloop%8)))
	   {
			RedirPrintf("\n");
	   }
		RedirPrintf("0x%x ",s_pSrsCfgForOpt_TNR.uFrameCellidMap[uiloop]);

    }
	RedirPrintf("\n");
	RedirPrintf("uSlotCellidMap\n");
    for(uiloopcell =0;uiloopcell<SRS_MAX_CELL_NUM_TNR;uiloopcell++)
    {
    	RedirPrintf("uiloopcell:%d \n",uiloopcell);
        for(uiloop =0;uiloop<SRS_MAX_SLOT_NUM_TNR;uiloop++)
        {
    	      RedirPrintf("%d ",s_pSrsCfgForOpt_TNR.uSlotCellidMap[uiloopcell][uiloop][0]);
        }
    	RedirPrintf("\n");
    }

	RedirPrintf("tAddrInfo\n");
    for(uiloopcell =0;uiloopcell<SRS_MAX_CELL_NUM_TNR;uiloopcell++)
    {
    	RedirPrintf("uCellId:%d \n",s_pSrsCfgForOpt_TNR.tAddr[uiloopcell].uCellId);
    	RedirPrintf("uValidCarrNum:%d \n",s_pSrsCfgForOpt_TNR.tAddr[uiloopcell].uValidCarrNum);
        for(uiloop =0;uiloop<SRS_MAX_CARR_NUM_ONECELL;uiloop++)
        {
    	      RedirPrintf("uAddr:%x ",s_pSrsCfgForOpt_TNR.tAddr[uiloopcell].tAddrInfo[uiloop].uAddr);
    	      RedirPrintf("uClearVal:%d ",s_pSrsCfgForOpt_TNR.tAddr[uiloopcell].tAddrInfo[uiloop].uClearVal);
    	      RedirPrintf("uRecoverVal:%d ",s_pSrsCfgForOpt_TNR.tAddr[uiloopcell].tAddrInfo[uiloop].uRecoverVal);
    	      RedirPrintf("\n");
        }
    	RedirPrintf("\n");
    }

	return BSP_OK;
}


UINT32 printsrsinfotdd(VOID)
{
	UINT32 uiloop =0;
	UINT32 uiloopcell =0;
	RedirPrintf("-------tdd srs-------\n");
	RedirPrintf("uInfoValidFlag:%d\n",s_pSrsCfgForOpt_TDD.uInfoValidFlag);
	RedirPrintf("uInfoValidFlag:%d\n",s_pSrsCfgForOpt_TDD.uValidCellNum);


	RedirPrintf("uFrameCellidMap\n");
    for(uiloop =0;uiloop<SRS_MAX_FRAME_NUM;uiloop++)
    {
		if((uiloop!=0) && (!(uiloop%8)))
	   {
			RedirPrintf("\n");
	   }
		RedirPrintf("0x%x ",s_pSrsCfgForOpt_TDD.uFrameCellidMap[uiloop]);

    }
	RedirPrintf("\n");
	RedirPrintf("uSlotCellidMap\n");
    for(uiloopcell =0;uiloopcell<SRS_MAX_CELL_NUM_TLTE;uiloopcell++)
    {
    	RedirPrintf("uiloopcell:%d \n",uiloopcell);
        for(uiloop =0;uiloop<SRS_MAX_SLOT_NUM_TLTE;uiloop++)
        {
    	      RedirPrintf("%d ",s_pSrsCfgForOpt_TDD.uSlotCellidMap[uiloopcell][uiloop][0]);
        }
    	RedirPrintf("\n");
    }

	RedirPrintf("tAddrInfo\n");
    for(uiloopcell =0;uiloopcell<SRS_MAX_CELL_NUM_TLTE;uiloopcell++)
    {
    	RedirPrintf("uCellId:%d \n",s_pSrsCfgForOpt_TDD.tAddr[uiloopcell].uCellId);
    	RedirPrintf("uValidCarrNum:%d \n",s_pSrsCfgForOpt_TDD.tAddr[uiloopcell].uValidCarrNum);
        for(uiloop =0;uiloop<SRS_MAX_CARR_NUM_ONECELL;uiloop++)
        {
    	      RedirPrintf("uAddr:%x ",s_pSrsCfgForOpt_TDD.tAddr[uiloopcell].tAddrInfo[uiloop].uAddr);
    	      RedirPrintf("uClearVal:%d ",s_pSrsCfgForOpt_TDD.tAddr[uiloopcell].tAddrInfo[uiloop].uClearVal);
    	      RedirPrintf("uRecoverVal:%d ",s_pSrsCfgForOpt_TDD.tAddr[uiloopcell].tAddrInfo[uiloop].uRecoverVal);
    	      RedirPrintf("\n");
        }
    	RedirPrintf("\n");
    }

	return BSP_OK;
}


UINT32 printsrsinfofdd(VOID)
{
	UINT32 uiloop =0;
	UINT32 uiloopcell =0;
	RedirPrintf("-------fdd srs-------\n");
	RedirPrintf("uInfoValidFlag:%d\n",s_pSrsCfgForOpt_FDD.uInfoValidFlag);
	RedirPrintf("uInfoValidFlag:%d\n",s_pSrsCfgForOpt_FDD.uValidCellNum);


	RedirPrintf("uFrameCellidMap\n");
    for(uiloop =0;uiloop<SRS_MAX_FRAME_NUM;uiloop++)
    {
		if((uiloop!=0) && (!(uiloop%8)))
	   {
			RedirPrintf("\n");
	   }
		RedirPrintf("0x%x ",s_pSrsCfgForOpt_FDD.uFrameCellidMap[uiloop]);

    }
	RedirPrintf("\n");
	RedirPrintf("uSlotCellidMap\n");
    for(uiloopcell =0;uiloopcell<SRS_MAX_CELL_NUM_FDD;uiloopcell++)
    {
    	RedirPrintf("uiloopcell:%d \n",uiloopcell);
        for(uiloop =0;uiloop<SRS_MAX_SLOT_NUM_FDD;uiloop++)
        {
    	      RedirPrintf("%d ",s_pSrsCfgForOpt_FDD.uSlotCellidMap[uiloopcell][uiloop][0]);
        }
    	RedirPrintf("\n");
    }

	RedirPrintf("tAddrInfo\n");
    for(uiloopcell =0;uiloopcell<SRS_MAX_CELL_NUM_FDD;uiloopcell++)
    {
    	RedirPrintf("uCellId:%d \n",s_pSrsCfgForOpt_FDD.tAddr[uiloopcell].uCellId);
    	RedirPrintf("uValidCarrNum:%d \n",s_pSrsCfgForOpt_FDD.tAddr[uiloopcell].uValidCarrNum);
        for(uiloop =0;uiloop<SRS_MAX_CARR_NUM_ONECELL;uiloop++)
        {
    	      RedirPrintf("uAddr:%x ",s_pSrsCfgForOpt_FDD.tAddr[uiloopcell].tAddrInfo[uiloop].uAddr);
    	      RedirPrintf("uClearVal:%d ",s_pSrsCfgForOpt_FDD.tAddr[uiloopcell].tAddrInfo[uiloop].uClearVal);
    	      RedirPrintf("uRecoverVal:%d ",s_pSrsCfgForOpt_FDD.tAddr[uiloopcell].tAddrInfo[uiloop].uRecoverVal);
    	      RedirPrintf("\n");
        }
    	RedirPrintf("\n");
    }

	return BSP_OK;
}

UINT32 printsrsinfo(UINT32 uiRadioMode)
{
	   switch(uiRadioMode)
	    {
	        case BSP_RADIO_STANDARD_NR:
	        {
	        	printsrsinfonr();
	            break;
	        }
	        case BSP_RADIO_STANDARD_LTE_TDD:
	        {
	        	printsrsinfotdd();
	            break;
	        }
	        case BSP_RADIO_STANDARD_FDD_NR:
	        case BSP_RADIO_STANDARD_LTE_FDD:
	        {
	        	printsrsinfofdd();
	            break;
	        }
	        default:
	        {
	            break;
	        }
	    }
	return BSP_OK;
}

UINT32 BspOneClickCollectSrs(VOID)
{
    RedirPrintf("-------- SRS printsrsinfonr ------------ \n");
    printsrsinfonr();
    RedirPrintf("-------- SRS printsrsinfotdd ------------ \n");
    printsrsinfotdd();
    RedirPrintf("-------- SRS printsrsinfofdd ------------ \n");
    printsrsinfofdd();

    return BSP_OK;
}

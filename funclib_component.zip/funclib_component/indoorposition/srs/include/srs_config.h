/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : j204_common.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供J204模块公共定义
 * 注意事项 : 无
 * 作    者 : wangtao 10248577
 * 创建日期 : 2020-12-10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_SRS_CONFIG_BLOCK_H_INCLUDED
#define FUNCLIB_SRS_CONFIG_BLOCK_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "funccommon_log.h"
#include "exprn.h"
#include "utdoa_ctrl_api.h"

#define QCELL_MAX_CHAN_NUM       (UINT32)16
/**************************************************************************
 *                               宏定义
 **************************************************************************/
	typedef struct tagRruCarrPositionItem
	{
		UINT32   uiChnMask;                                /* 通道掩码 */
		UINT32   uiCarrNo;                               /* 载波号 */
		UINT32   uiCellId;                                /* 小区id,主要用于定位问题 */
		UINT32   uiOptSrsCarrNo;                                /* 光口SRS载波号 ，从1开始 */
	    UINT32   uiRadioMode;                             /* 无线制式,表示本次数据包的制式  */

	    UINT8     ucCpId;                                 /* cpId,主要用于定位问题 */
	    UINT8     ucCPType;                               /* CP类型 */
	    UINT8     ucQcellPositionEnable;                  /* Qcell定位开关 */
	    UINT8     ucPRRUPositionID;                       /* 每个pRRU载波的pRRU编号 */
	    UINT8     ucPrruPollNum;                          /* pRRU轮询个数,BBU侧保证都是2的整数幂 */
	    UINT8     ucPrruPollTime;                         /* pRRU轮询间隔时间,后台通过配置保证都是2的正数幂 */

	    UINT32    uiSrsSFBitMap;                           /* Srs子帧位图 */
	    UINT16    usPrruPollPeriodFactor;       /* pRRU轮询周期因子,低8bit,ucPrruPollPeriodFactor和ucPrruPollPeriodFactorH表达的16bit数为2的整数次幂 */
	    UINT8     ucRes[4];

	}TRruChnCarrPositionSrsItem;


#define BSP_SRS_NUMBER_OF_THRESHOLD_CHECK(uiNumber, uiThreshold)      \
    {                                                                   \
        if ((uiNumber) >= (uiThreshold))                                \
        {                                                               \
            dbgErr("%s: %s=%u err,should be less than %u!\n",           \
                   __FUNCTION__, #uiNumber, (uiNumber), (uiThreshold)); \
            return BSP_ERROR;                                           \
        }                                                               \
    }



	/**************************************************************************
	 *                               函数声明
	 **************************************************************************/
UINT32 BspSetSrsConfig(TRruChnCarrPositionSrsItem * pSrsCfg);
UINT32 BspSetSrsOptEn(UINT32 uValidCellNum,UINT32 uiRadioMode);
UINT32 BspCleanSrsCfg(UINT32 uiRadioMode);
UINT32 BspSetSrsPsyncIrqCfgTnr(UINT32 uSwitch);
UINT32 BspSetSrsPsyncIrqCfgTlte(UINT32 uSwitch);
UINT32 BspSetSrsPsyncIrqCfgFdd(UINT32 uSwitch);
UINT32 BspOneClickCollectSrs(VOID);
UINT32 BspSetSrsFrAdjustVal(TRruChnCarrPositionSrsItem * pSrsCfg);
#ifdef __cplusplus
}
#endif
#endif



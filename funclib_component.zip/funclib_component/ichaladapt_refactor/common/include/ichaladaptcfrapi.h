/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladaptbspapi.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPTCFRAPI_H_
#define _FUNCLIB_ICHALADAPTCFRAPI_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ichaladapt_ic4_2.h"

/*CFR对外的平台性接口，具备通用性，适用于下一代IC芯片，funclib层cfr模块只能调用本文件内的接口*/
UINT32 BspHalAdaptSetCfrGate(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrGate, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrWin(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWin, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrDelt(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrDelt, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrWinlevel(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWinLevel, UINT32 gateNum);
UINT32 BspHalAdaptSetCfrSwitch(UINT32 difChn, UINT32 freqBand, UINT32 cfrOnOff);
UINT32 BspHalAdaptSetBbTssiCfg(UINT32 difChan);
UINT32 BspHalAdaptCfrSetSymstrGsmSel(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptCfrSetCpgMode(UINT32 difChan, UINT32 freqBand, UINT32 cpgMode);
UINT32 BspHalAdaptDifCfrParaInit(T_BspHalAdaptDifCommCfrPara *pDifCfrPara);
UINT32 BspHalAdaptCfrCommParaCpgInit(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara);
UINT32 BspHalAdaptKnWordLutParaInit(T_BspHalAdaptCfrKnWordPara *pCfrKnWordPara);
UINT32 BspHalAdaptCpgeParaRangeFreqInit(void);
UINT32 BspHalAdaptCfrSetCpgGateBypassInit(void);
UINT32 BspHalAdaptDpdParCfgCommParaInit(T_BspHalAdaptDpdParCommPara *pDpdParPara);
UINT32 BspHalAdaptGetDpdParPara(T_BspHalAdaptDpdParCommPara *pDpdParPara);
UINT32 BspHalAdaptSetCpgParaRangeCarrInit(void);
UINT32 BspHalAdaptCfrSetFreqWordFsInit(void);
UINT32 BspHalAdaptCfrSetDlpreKiPowSelInit(void);
UINT32 BspHalAdaptCfrSetDelay(UINT32 difChn, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara);
UINT32 BspHalAdaptCfrSetTddsw(UINT32 difChan, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara);
UINT32 BspHalAdaptCfrSetCpgLen(UINT32 difChan, UINT32 freqBand, UINT32 cpgMaxlen);
UINT32 BspHalAdaptSetCfrHb1Coef(UINT32 difChn, INT32 *pcfrHb1Coef, UINT32 coefLen);
UINT32 BspHalAdaptSetCfrHb0Coef(UINT32 difChn, INT32 *pcfrHb0Coef, UINT32 coefLen);
UINT32 BspHalAdaptSetCfrOutMode(UINT32 difChn, UINT32 freqBand, UINT32 mode);
UINT32 BspHalAdaptSetDlyPara(UINT32 difChn, T_BspHalAdaptDlyCfgCfrPara *pDlyPara);
UINT32 BspHalAdaptSetDlpreKiIndexType(UINT32 difChan);
UINT32 BspHalAdaptCfrParCfgCommParaInit(T_BspHalAdaptCfrParCommPara *pCfrParPara);
UINT32 BspHalAdaptGetCfrParPara(T_BspHalAdaptCfrParCommPara *pCfrParPara);
UINT32 BspHalAdaptCfrSetCpgSuspend(UINT32 difChn, UINT32 freqBand, UINT32 suspend);
UINT32 BspCfrHbfParaInitAll(VOID);
UINT32 BspHalAdaptGetCfrKiCommPara(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara);
VOID SaveDifCfg(UINT32 type, VOID *pAddr, UINT32 linkunm, UINT32 difChNum);
T_DifCfgSave* GetDifCfgSave(UINT32 type);
UINT32 BspHalAdaptCfrSetTddswInit(void);
UINT32 BspHalAdaptCfrSetEnergyInit(void);
UINT32 BspSetCpgParaRangeCarrInit(void);
UINT32 BspCfrSetFreqWordFsInit(void);
UINT32 BspCfrSetDlpreKiPowSelInit(void);
UINT32 BspHalAdaptCfrClrOriginCoefCarrInfo(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptDssCfrSetOriginCoef(UINT32 difChan, UINT32 carrIndex, UINT32 carrRadio, UINT32 carrBw, UINT32 coefLen, const INT32 *pCoefPara);
UINT32 BspHalAdaptCfrCleanDlpreKiPowSel(UINT32 difChan, UINT32 freqBand);
UINT32 BspHalAdaptCfrSetBlock0Ram1Len(void);
UINT32 BspHalAdaptSetCpgParaRangeCarrNum(void);


#ifdef __cplusplus

}
#endif
#endif





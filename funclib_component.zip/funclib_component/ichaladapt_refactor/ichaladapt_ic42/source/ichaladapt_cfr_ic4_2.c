/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_cfr_ic4.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了j204相关ICHAL适配层接口函数实现
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "ichaladaptcfrapi.h"
#include "ichaladaptcommon.h"
#include "ichaladapt_ic4_2.h"

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/
T_BspHalAdaptCfrParCommPara *s_pCfrParPara = NULL;
T_BspHalAdaptDpdParCommPara *s_pDpdParPara = NULL;
T_BspHalAdaptCfrParaHardCpg *s_pCfrHWCpgPara = NULL;

/**************************************************************************
                            CFR相关接口
**************************************************************************/
#define ICHAL_ADAPT_FUNC_DEF(func, ...)       \
    {                                         \
        UINT32 retVal = BSP_OK;               \
        retVal = IcHalApi##func(__VA_ARGS__); \
        \
        return retVal;                        \
    }

UINT32 BspHalAdaptSetCfrGate(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrGate, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrGate);
    retVal =  IcHalApiSetCfrGate(difChn, freqBand, pcfrGate, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrGate(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrGate, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrGate);
    retVal =  IcHalApiGetCfrGate(difChn, freqBand, pcfrGate, gateNum);

    return retVal;
}

UINT32 BspHalAdaptSetCfrWin(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWin, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWin);
    retVal =  IcHalApiSetCfrWin(difChn, freqBand, pcfrWin, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrWin(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWin, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWin);
    retVal =  IcHalApiGetCfrWin(difChn, freqBand, pcfrWin, gateNum);

    return retVal;
}

UINT32 BspHalAdaptSetCfrDelt(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrDelt, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrDelt);
    retVal =  IcHalApiSetCfrDelt(difChn, freqBand, pcfrDelt, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrDelt(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrDelt, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrDelt);
    retVal =  IcHalApiGetCfrDelt(difChn, freqBand, pcfrDelt, gateNum);

    return retVal;
}

UINT32 BspHalAdaptSetCfrWinlevel(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWinLevel, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWinLevel);
    retVal =  IcHalApiSetCfrWinLevel(difChn, freqBand, pcfrWinLevel, gateNum);

    return retVal;
}

UINT32 BspHalAdaptGetCfrWinlevel(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWinLevel, UINT32 gateNum)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pcfrWinLevel);
    retVal =  IcHalApiGetCfrWinLevel(difChn, freqBand, pcfrWinLevel, gateNum);

    return retVal;
}

UINT32 BspHalAdaptSetCfrSwitch(UINT32 difChn, UINT32 freqBand, UINT32 cfrOnOff)
ICHAL_ADAPT_FUNC_DEF(SetCfrSwitch,difChn, freqBand, cfrOnOff)

/** 设置在线计算BBTSSI相关配置 */
UINT32 BspHalAdaptSetBbTssiCfg(UINT32 difChan)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetBbTssiCfg(difChan);

    return retVal;
}

UINT32 BspHalAdaptCfrSetSymstrGsmSel(UINT32 difChan, UINT32 freqBand)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetSymstrGsmSel(difChan, freqBand);

    return retVal;
}
/** 设置削峰软硬件计算模式 **/
UINT32 BspHalAdaptCfrSetCpgMode(UINT32 difChan, UINT32 freqBand, UINT32 cpgMode)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetCfrCpgMode(difChan, freqBand, cpgMode);

    return retVal;
}

UINT32 BspHalAdaptCfrCommParaCpgInit(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCfrHWCpgPara);

    s_pCfrHWCpgPara = pCfrHWCpgPara;

    retVal = IcHalApiCfrCommParaCpgInit(pCfrHWCpgPara);

    return retVal;
}

UINT32 BspHalAdaptGetCfrKiCommPara(T_BspHalAdaptCfrParaHardCpg *pCfrHWCpgPara)
{
    if(s_pCfrHWCpgPara == NULL)
    {
        dbgInfo("[%s] s_pCfrHWCpgPara is not initialized！\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy_s(pCfrHWCpgPara, sizeof(T_BspHalAdaptCfrParaHardCpg), s_pCfrHWCpgPara, sizeof(T_BspHalAdaptCfrParaHardCpg));

    return BSP_OK;
}

UINT32 BspHalAdaptKnWordLutParaInit(T_BspHalAdaptCfrKnWordPara *pCfrKnWordPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCfrKnWordPara);
    retVal = IcHalApiKnWordLutParaInit(pCfrKnWordPara);

    return retVal;
}

/**  削峰硬件计算频段靠前摆放参数初始化  **/
UINT32 BspHalAdaptCpgeParaRangeFreqInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCpgeParaRangeFreqInit();

    return retVal;
}

UINT32 BspHalAdaptCfrSetCpgGateBypassInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetCpgGateBypassInit();

    return retVal;
}

UINT32 BspHalAdaptDpdParCfgCommParaInit(T_BspHalAdaptDpdParCommPara *pDpdParPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDpdParPara);

    s_pDpdParPara = pDpdParPara;

    retVal = IcHalApiDpdParCfgCommParaInit(pDpdParPara);

    return retVal;
}

UINT32 BspHalAdaptGetDpdParPara(T_BspHalAdaptDpdParCommPara *pDpdParPara)
{
    if(s_pDpdParPara == NULL)
    {
        dbgInfo("[%s] s_pDpdParPara is not initialized！\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy_s(pDpdParPara, sizeof(T_BspHalAdaptDpdParCommPara), s_pDpdParPara, sizeof(T_BspHalAdaptDpdParCommPara));

    return BSP_OK;
}

/** 削峰在线计算某通道载波靠前摆放初始化 **/
UINT32 BspHalAdaptSetCpgParaRangeCarrInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiSetCpgParaRangeCarrInit();

    return retVal;
}

/** 设置CPG在线计算频段频率控制字速率初始化 **/
UINT32 BspHalAdaptCfrSetFreqWordFsInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetFreqWordFsInit();

    return retVal;
}

/** 设置dlpre内部Ki索引计算功率选择参数（DSS场景）*/
UINT32 BspHalAdaptCfrSetDlpreKiPowSelInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetDlpreKiPowSelInit();

    return retVal;
}

UINT32 BspHalAdaptCfrSetDelay(UINT32 difChn, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pDlyPara);
    retVal =  IcHalApiSetCfrDlyNum(difChn, freqBand, pDlyPara);

    return retVal;
}

/** 计算每级削峰模块的tddsw扩展*/
UINT32 BspHalAdaptCfrSetTddsw(UINT32 difChan, UINT32 freqBand, T_BspHalAdaptCfrDlyCalcPara *pDlyPara)
{
   UINT32 retVal = BSP_OK;

   retVal = IcHalApiCfrSetTddsw(difChan, freqBand, pDlyPara);

   return retVal;
}

/** cpg系数长度配置的对外接口 */
UINT32 BspHalAdaptCfrSetCpgLen(UINT32 difChan, UINT32 freqBand, UINT32 cpgMaxlen)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetCpgLen(difChan, freqBand, cpgMaxlen);

    return retVal;
}

UINT32 BspHalAdaptSetCfrHb1Coef(UINT32 difChn, INT32 *pcfrHb1Coef, UINT32 coefLen)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqBand = 0;
    INPUT_POINTER_CHECK(pcfrHb1Coef);
    retVal =  IcHalApiSetCfrHbf1Coef(difChn, freqBand, pcfrHb1Coef, coefLen);
    return retVal;
}

UINT32 BspHalAdaptSetCfrHb0Coef(UINT32 difChn, INT32 *pcfrHb0Coef, UINT32 coefLen)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqBand = 0;
    INPUT_POINTER_CHECK(pcfrHb0Coef);
    retVal =  IcHalApiSetCfrHbf0Coef(difChn, freqBand, pcfrHb0Coef, coefLen);
    return retVal;
}

UINT32 BspHalAdaptSetCfrOutMode(UINT32 difChn, UINT32 freqBand, UINT32 mode)    \
ICHAL_ADAPT_FUNC_DEF(SetCfrOutMode, difChn, freqBand, mode)

UINT32 BspHalAdaptSetDlyPara(UINT32 difChn, T_BspHalAdaptDlyCfgCfrPara *pDlyPara)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqBand = 0;

    INPUT_POINTER_CHECK(pDlyPara);
    retVal =  IcHalApiSetDlyPara(difChn, freqBand, pDlyPara);

    return retVal;
}

/** 设置dlpre内部Ki索引载波类型选择信号(dsp单g不迭代功能需要)*/
UINT32 BspHalAdaptSetDlpreKiIndexType(UINT32 difChan)
{
   UINT32 retVal = BSP_OK;

   retVal = IcHalApiSetDlpreKiIndexCaType(difChan);

   return retVal;
}

UINT32 BspHalAdaptCfrParCfgCommParaInit(T_BspHalAdaptCfrParCommPara *pCfrParPara)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pCfrParPara);

    s_pCfrParPara = pCfrParPara;

    retVal = IcHalApiCfrParCfgCommParaInit(pCfrParPara);

    return retVal;
}

UINT32 BspHalAdaptGetCfrParPara(T_BspHalAdaptCfrParCommPara *pCfrParPara)
{
    if(s_pCfrParPara == NULL)
    {
        dbgInfo("[%s] s_pCfrParPara is not initialized！\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memcpy_s(pCfrParPara, sizeof(T_BspHalAdaptCfrParCommPara), s_pCfrParPara, sizeof(T_BspHalAdaptCfrParCommPara));

    return BSP_OK;
}

/** CPG在线计算暂停与开启，suspend：0x0：开启；0x1：暂停。*/
UINT32 BspHalAdaptCfrSetCpgSuspend(UINT32 difChn, UINT32 freqBand, UINT32 suspend)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetCpgSuspend(difChn, freqBand, suspend);

    return retVal;
}

/** 每级削峰模块的tddsw扩展初始化清零 */
UINT32 BspHalAdaptCfrSetTddswInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiCfrSetTddswInit();

    return retVal;
}

static T_DifCfgSave s_tDifCfgSave[E_DIF_CFG_TYPE_MAX] = {0};

VOID SaveDifCfg(UINT32 type, VOID *pAddr, UINT32 linkunm, UINT32 difChNum)
{
    if (type < E_DIF_CFG_TYPE_MAX)
    {
        s_tDifCfgSave[type].pAddr = pAddr;
        s_tDifCfgSave[type].linkunm = linkunm;
        s_tDifCfgSave[type].difChNum = difChNum;
    }
    return;
}

T_DifCfgSave *GetDifCfgSave(UINT32 type)
{
    if (type < E_DIF_CFG_TYPE_MAX)
    {
        return &(s_tDifCfgSave[type]);
    }
    return NULL;
}

/** 设置CPG在线计算频段频率控制字速率初始化 **/
UINT32 BspCfrSetFreqWordFsInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptCfrSetFreqWordFsInit();

    return retVal;
}

/** 设置dlpre内部Ki索引计算功率选择参数（DSS场景）*/
UINT32 BspCfrSetDlpreKiPowSelInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptCfrSetDlpreKiPowSelInit();

    return retVal;
}

/** 削峰在线计算某通道载波靠前摆放初始化 **/
UINT32 BspSetCpgParaRangeCarrInit(void)
{
    UINT32 retVal = BSP_OK;

    retVal |= BspHalAdaptSetCpgParaRangeCarrInit();

    return retVal;
}


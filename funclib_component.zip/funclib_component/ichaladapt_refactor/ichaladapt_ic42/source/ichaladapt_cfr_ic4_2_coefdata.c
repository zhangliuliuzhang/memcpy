/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2_coefdata.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2削峰模块下cpg以及滤波器系数的参数信息
* 注意事项 : 无
* 作    者 : 喻波10220056
* 创建日期 : 2023-07-03
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 喻波10220056
* 修改日戳: 2023-07-03
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "bspcomm.h"
#include "bsppub.h"
#include "ichaladaptcfrapi.h"
#include "ichaladapt_cfr_ic4_2_coefdata.h"

/**************************************************************************
 *                        宏定义
 **************************************************************************/

/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/*CPG 总表，新增FS速率表需在此处添加申明*/
T_CfrCpgParaTbl s_cfrCpgParaTbl[] =
{
    {CFR_FS_245P76M  ,NULL,0},
    {CFR_FS_491P52M  ,NULL,0},
    {CFR_FS_983P04M  ,NULL,0},
    {CFR_FS_1966P08M ,NULL,0},
};

/* wei 因子总表，新增FS速率表需在此处添加申明*/
T_CfrWeiFactorTbl s_cfrWeiFactor[] =
{
    {CFR_FS_245P76M  ,NULL,0},
    {CFR_FS_491P52M  ,NULL,0},
    {CFR_FS_983P04M  ,NULL,0},
    {CFR_FS_1966P08M ,NULL,0},
};

INT32 s_cfrHbf0Coef[]=
{
    0x3fba,
    0xad,
    0x3e8b,
    0x2e7,
    0x39f9,
    0x141b,
};

INT32 s_cfrHbf1Coef[]=
{
    0x3d5f,
    0x1285,
};


/**************************************************************************
 *                         函数实现
 **************************************************************************/
/*****************************************************************************
*  函数名称   : CfrCpgCoefTblInit_IC4_2
*  功能描述   : 对应CPG的初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : fsRate:cpg的fs速率
*              *pCpgPara:对应速率的CPG表
*              cpgTblLen:表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*             :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 CfrCpgCoefTblInit_IC4_2(UINT32 fsRate,T_CfrCpgPara *pCpgPara, UINT32 cpgTblLen)
{
    UINT32 ulLoop         = 0;
    UINT32 ulCpgTblLen = NELEMENTS(s_cfrCpgParaTbl);
    INPUT_POINTER_CHECK(pCpgPara);
    for(ulLoop = 0; ulLoop < ulCpgTblLen; ulLoop++)
    {
        if(fsRate == s_cfrCpgParaTbl[ulLoop].cfrFsRate)
        {
            s_cfrCpgParaTbl[ulLoop].cpgParaTbl = pCpgPara;
            s_cfrCpgParaTbl[ulLoop].cpgParaTblLen = cpgTblLen;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : CfrFactorTblInit_IC4_2
*  功能描述   : 初始化CFR的 wei 因子
*  输入参数   : fsRate:因子的fs速率
*              *pCfrWeiFactor:对应速率的因子表
*              cfrFactorTblLen:表格大小
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*             :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 CfrFactorTblInit_IC4_2(UINT32 fsRate, T_CfrWeiFactor *pCfrWeiFactor, UINT32 cfrFactorTblLen)
{
    UINT32 ulLoop         = 0;
    UINT32 ulCfrFactorLen = NELEMENTS(s_cfrWeiFactor);
    INPUT_POINTER_CHECK(pCfrWeiFactor);
    for(ulLoop = 0; ulLoop < ulCfrFactorLen; ulLoop++)
    {
        if(fsRate == s_cfrWeiFactor[ulLoop].cfrFsRate)
        {
            s_cfrWeiFactor[ulLoop].cfrfactortbl = pCfrWeiFactor;
            s_cfrWeiFactor[ulLoop].cfrFactorTblLen = cfrFactorTblLen;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/*****************************************************************************
*  函数名称   : BspGetWeiCfrFactor_IC4_2
*  功能描述   : 获取CFR的 wei 因子
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspGetWeiCfrFactorCommon(UINT32 factorRate, T_CfrWeiFactor *pWeiCfrFactor)
{
    UINT32 ulLoop = 0;
    UINT32 ulCfrFactorLen = NELEMENTS(s_cfrWeiFactor);
    UINT32 ulCfrFactorFsTblLen = 0;
    T_CfrWeiFactor *cfrWeiFactor = NULL;

    for(ulLoop = 0; ulLoop < ulCfrFactorLen; ulLoop++)
    {
        if((factorRate == s_cfrWeiFactor[ulLoop].cfrFsRate)&&(s_cfrWeiFactor[ulLoop].cfrfactortbl != NULL))
        {
           cfrWeiFactor = s_cfrWeiFactor[ulLoop].cfrfactortbl;
           ulCfrFactorFsTblLen = s_cfrWeiFactor[ulLoop].cfrFactorTblLen;
           break;
        }
    }

    INPUT_POINTER_CHECK(pWeiCfrFactor);
    if (ulLoop >= ulCfrFactorLen)
    {
        dbgErr("%s cfrFs'%d cpg para not found!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pWeiCfrFactor->wei_gsm = cfrWeiFactor->wei_gsm;
    pWeiCfrFactor->wei_umts = cfrWeiFactor->wei_umts;
    pWeiCfrFactor->wei_nb_lot = cfrWeiFactor->wei_nb_lot;
    pWeiCfrFactor->wei_lte_fdd = cfrWeiFactor->wei_lte_fdd;
    pWeiCfrFactor->wei_lte_tdd = cfrWeiFactor->wei_lte_tdd;
    pWeiCfrFactor->wei_nr = cfrWeiFactor->wei_nr;
    pWeiCfrFactor->cpgRate = cfrWeiFactor->cpgRate;

    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspInitCfrFilterPara
*  功能描述   : CFR 结构参数配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrHbf1FilterPara(UINT32 difChn,INT32* pCoef,UINT32 coefLen)
{
    return BspHalAdaptSetCfrHb1Coef(difChn, pCoef,coefLen);
}

/*****************************************************************************
*  函数名称   : BspInitCfrHbf0FilterPara
*  功能描述   : CFR 结构参数配置
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   :
*  输出参数   : 无
*  返 回 值   :BSP_OK;
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 王飞@2015-11-28 14:55:24
*----------------------------------------------------------------------------
*/
UINT32 BspInitCfrHbf0FilterPara(UINT32 difChn,INT32* pCoef,UINT32 coefLen)
{
    return BspHalAdaptSetCfrHb0Coef(difChn, pCoef,coefLen);
}

UINT32 BspCfrHbfParaInit(UINT32 difChn)
{
    UINT32 ret = BSP_OK;
    UINT32 ulHbf0Len = 0;
    UINT32 ulHbf1Len = 0;
    ulHbf0Len = NELEMENTS(s_cfrHbf0Coef);
    ulHbf1Len = NELEMENTS(s_cfrHbf1Coef);
    ret = BspInitCfrHbf0FilterPara(difChn,s_cfrHbf0Coef,ulHbf0Len);
    ret |= BspInitCfrHbf1FilterPara(difChn,s_cfrHbf1Coef,ulHbf1Len);
    dbgInfoEx("[%S] difchan:%d HBF0len:%d HBF1len:%d ret:%d",__FUNCTION__,difChn,ulHbf0Len,ulHbf1Len,ret);
    return ret;
}

UINT32 BspGetCfrCpgCoefCommon(UINT32 difChn,UINT32 cfrBw,UINT32 rate,T_CfrCpgPara *pCpgPara)
{
    UINT32 ulLoop         = 0;
    UINT32 ulCpgTblLen = NELEMENTS(s_cfrCpgParaTbl);
    UINT32 ulCpgFsTblLen = 0;
    T_CfrCpgPara *cfrCpgPara = NULL;

    for(ulLoop = 0; ulLoop < ulCpgTblLen; ulLoop++)
    {
        if((rate == s_cfrCpgParaTbl[ulLoop].cfrFsRate)&&(s_cfrCpgParaTbl[ulLoop].cpgParaTbl != NULL))
        {
            cfrCpgPara = s_cfrCpgParaTbl[ulLoop].cpgParaTbl;
            ulCpgFsTblLen = s_cfrCpgParaTbl[ulLoop].cpgParaTblLen;
            break;
        }

    }
    INPUT_POINTER_CHECK(pCpgPara);
    if (ulLoop >= ulCpgTblLen)
    {
        dbgErr("[%s] cfrFs'%d cpg para not found!\n", __FUNCTION__, rate);
        return BSP_ERROR;
    }

    //按区分cpg速率修改
    for(ulLoop = 0; ulLoop < ulCpgFsTblLen; ulLoop++)
    {
        if (cfrCpgPara[ulLoop].cfrBw == cfrBw)
        {
            pCpgPara->pCoefPara = cfrCpgPara[ulLoop].pCoefPara;
            pCpgPara->cfrBw     = cfrCpgPara[ulLoop].cfrBw;
            pCpgPara->coefLen   = cfrCpgPara[ulLoop].coefLen;
            pCpgPara->cpgRate   = cfrCpgPara[ulLoop].cpgRate;
            pCpgPara->vaildLen  = cfrCpgPara[ulLoop].vaildLen;
            return BSP_OK;
        }
    }
    dbgInfo("[%s] Get CfrBw[%d] Cpg Para Error!\n", __FUNCTION__, cfrBw);
    return BSP_ERROR;
}

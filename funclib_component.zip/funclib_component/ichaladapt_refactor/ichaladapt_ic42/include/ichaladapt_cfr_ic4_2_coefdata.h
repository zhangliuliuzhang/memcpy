/*****************************************************************************
* 版权所有(C) 2021,  ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : CFR
* 文件名称 : cfr_ic4_2_coefdata.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件主要提供DPDIC4.2削峰模块下cpg以及滤波器系数的参数信息
* 注意事项 : 无
* 作    者 : 喻波10220056
* 创建日期 : 2023-07-03
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 喻波10220056
* 修改日戳: 2023-07-03
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef PLATFORM_BSP_FUNCLIB_COMPONENT_ICHALADAPT_REFACTOR_ICHALADAPT_IC42_INCLUDE_ICHALADAPT_CFR_IC4_2_COEFDATA1_H_
#define PLATFORM_BSP_FUNCLIB_COMPONENT_ICHALADAPT_REFACTOR_ICHALADAPT_IC42_INCLUDE_ICHALADAPT_CFR_IC4_2_COEFDATA1_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"

/*CFR FS KHZ*/
#define CFR_FS_30P72M        30720
#define CFR_FS_61P44M        61440
#define CFR_FS_92P16M        92160
#define CFR_FS_122P88M       122880
#define CFR_FS_184P32M       184320
#define CFR_FS_245P76M       245760
#define CFR_FS_368P64M       368640
#define CFR_FS_491P52M       491520
#define CFR_FS_737P28M       737280
#define CFR_FS_983P04M       983040
#define CFR_FS_1966P08M      1966080
#define CFR_FS_1474P56M      1474560

typedef enum
{
    E_CFR_BW_MIN,          /* 0          */
    E_CFR_BW_5M,           /* 1  NR 5M   */
    E_CFR_BW_10M,          /* 2  NR 10M  */
    E_CFR_BW_15M,          /* 3  NR 15M  */
    E_CFR_BW_20M,          /* 4  NR 20M  */
    E_CFR_BW_25M,          /* 5  NR 25M  */
    E_CFR_BW_30M,          /* 6  NR 30M  */
    E_CFR_BW_40M,          /* 7  NR 40M  */
    E_CFR_BW_50M,          /* 8  NR 50M  */
    E_CFR_BW_59M,          /* 9  NR 59M  */
    E_CFR_BW_60M,          /* 10 NR 60M  */
    E_CFR_BW_70M,          /* 11 NR 70M  */
    E_CFR_BW_80M,          /* 12 NR 80M  */
    E_CFR_BW_90M,          /* 13 NR 90M  */
    E_CFR_BW_100M,         /* 14 NR 100M */
    E_CFR_BW_160M,         /* 15 NR 160M */
    E_CFR_BW_200M,         /* 16 NR 200M */
    E_CFR_BW_400M,         /* 17 NR 400M */

    E_CFR_BW_FDD_5G_15M,   /* 18 FDD NR 15M */
    E_CFR_BW_FDD_5G_20M,   /* 19 FDD NR 20M */
    E_CFR_BW_FDD_5G_30M,   /* 20 FDD NR 30M */
    E_CFR_BW_FDD_5G_40M,   /* 21 FDD NR 20M */
    E_CFR_BW_FDD_5G_50M,   /* 22 FDD NR 50M */

    E_CFR_BW_4P4M,         /* 23 LTE 4.4M */
    E_CFR_BW_4P6M,         /* 24 LTE 4.6M */
    E_CFR_BW_4P8M,         /* 25 LTE 4.8M */
    E_CFR_BW_7P4M,         /* 26 LTE 7.4M */
    E_CFR_BW_7P5M,         /* 27 LTE 7.5M */
    E_CFR_BW_8M,           /* 28 LTE 8M   */
    E_CFR_BW_8P8M,         /* 29 LTE 8.8M */
    E_CFR_BW_9P2M,         /* 30 LTE 9.2M */
    E_CFR_BW_9P6M,         /* 31 LTE 9.6M */

    E_CFR_BW_LTE_1P4M,     /* 32 LTE 1.4M */
    E_CFR_BW_LTE_3M,       /* 33 LTE 3M   */
    E_CFR_BW_LTE_5M,       /* 34 LTE 5M   */
    E_CFR_BW_LTE_10M,      /* 35 LTE 10M  */
    E_CFR_BW_LTE_15M,      /* 36 LTE 15M  */
    E_CFR_BW_LTE_20M,      /* 37 LTE 20M  */

    E_CFR_BW_UTMS_2P6M,    /* 38 UMTS 2.6M */
    E_CFR_BW_UTMS_2P8M,    /* 39 UMTS 2.8M */
    E_CFR_BW_UTMS_3P0M,    /* 40 UMTS 3.0M */
    E_CFR_BW_UTMS_3P2M,    /* 41 UMTS 3.2M */
    E_CFR_BW_UTMS_3P4M,    /* 42 UMTS 3.4M */
    E_CFR_BW_UTMS_3P6M,    /* 43 UMTS 3.6M */
    E_CFR_BW_UTMS_3P8M,    /* 44 UMTS 3.8M */
    E_CFR_BW_UTMS_4P0M,    /* 45 UMTS 4.0M */
    E_CFR_BW_UTMS_4P2M,    /* 46 UMTS 4.2M */
    E_CFR_BW_UTMS_4P4M,    /* 47 UMTS 4.4M */
    E_CFR_BW_UTMS_4P6M,    /* 48 UMTS 4.6M */
    E_CFR_BW_UTMS_4P8M,    /* 49 UMTS 4.8M */
    E_CFR_BW_UTMS_5P0M,    /* 50 UMTS 5.0M */

    E_CFR_BW_NBIOT,        /* 51 NB  */
    E_CFR_BW_GSM,          /* 52 GSM */

    E_CFR_RADIO_BW_MAX,
}E_CFR_RADIO_BW_INFO;
typedef struct tag_cfr_cpg_para         /*cpg参数*/
{
    UINT32          cfrBw;
    const INT32     *pCoefPara;
    UINT32          coefLen;
    UINT32          cpgRate;
    UINT32          vaildLen;
}T_CfrCpgPara;

typedef struct tag_cfr_cpg_wei_factor
{
    DOUBLE  wei_gsm;              /* gsm载波wei因子 */
    DOUBLE  wei_umts;             /* umts载波wei因子*/
    DOUBLE  wei_nb_lot;           /* nb载波wei因子 */
    DOUBLE  wei_lte_fdd;          /* FDD的LTE载波wei因子*/
    DOUBLE  wei_lte_tdd;          /* TDD的LTE载波wei因子 */
    DOUBLE  wei_nr;               /* nr载波wei因子 */
    UINT32 cpgRate;               /* CPG速率 */
}T_CfrWeiFactor;

typedef struct tag_cfr_cpg_wei_factor_tbl
{
    UINT32          cfrFsRate;
    T_CfrWeiFactor  *cfrfactortbl;
    UINT32          cfrFactorTblLen;
}T_CfrWeiFactorTbl;

typedef struct tag_cfr_cpg_para_tbl         /*cpg参数*/
{
    UINT32          cfrFsRate;
    T_CfrCpgPara    *cpgParaTbl;
    UINT32          cpgParaTblLen;
}T_CfrCpgParaTbl;

/**************************************************************************
 *                        宏定义
 **************************************************************************/


/**************************************************************************
*                         数据类型                                       *
**************************************************************************/


/**************************************************************************
 *                         函数接口
 **************************************************************************/

UINT32 CfrCpgCoefTblInit_IC4_2(UINT32 fsRate,T_CfrCpgPara *pCpgPara, UINT32 cpgTblLen);
UINT32 CfrFactorTblInit_IC4_2(UINT32 fsRate, T_CfrWeiFactor *pCfrWeiFactor, UINT32 cfrFactorTblLen);
UINT32 BspCfrHbfParaInit(UINT32 difChn);
UINT32 BspGetWeiCfrFactorCommon(UINT32 factorRate, T_CfrWeiFactor *pWeiCfrFactor);
UINT32 BspGetCfrCpgCoefCommon(UINT32 difChn,UINT32 cfrBw,UINT32 rate,T_CfrCpgPara *pCpgPara);

#ifdef __cplusplus
}
#endif
#endif //FUNCLIB_CFR_FPGA_H_INCLUDED


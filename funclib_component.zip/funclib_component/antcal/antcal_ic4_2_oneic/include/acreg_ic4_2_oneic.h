
#ifdef __cplusplus
extern "C" {
#endif

#define AC_DRV_SEQ_LEN  (1024)
#define acTxDrvAcSeqCnt  (AC_DRV_SEQ_LEN*64)

enum
{
    AC_SEQ_GEAR_45 = 0, //-45dbfs
    AC_SEQ_GEAR_40,
    AC_SEQ_GEAR_35,
    AC_SEQ_GEAR_30,
    AC_SEQ_GEAR_25,
    AC_SEQ_GEAR_NUM
};

UINT32 acTxDrvAcSeqDataNr[acTxDrvAcSeqCnt] = {0,};

UINT32 acRxDrvAcSeqDataNr[AC_DRV_SEQ_LEN] =
{
    #include "acseqtest_UL.h"
};
//ADS TEST
UINT32 acTxDrvAcSeqDataNrTemp[1024] =
{
    #include "acseqtest_DL.h"
};

UINT32 acTxDrvAcSeqDataLteTemp[1024] =
{
    #include "acseqtest_lte_DL.h"
};

#ifdef __cplusplus
}
#endif


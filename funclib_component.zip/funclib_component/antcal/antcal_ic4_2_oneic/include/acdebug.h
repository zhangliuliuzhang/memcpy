#ifndef FUNCLIB_ACDEBUG_H_INCLUDED
#define FUNCLIB_ACDEBUG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"
#include "secure_func.h"

#include "dsp_dbg.h"

/**************************************************************************
 *                             宏定义                                             *
 **************************************************************************/
#define WAITR8TIMEMeasCNT           3
#define WAITR8TIMESPILLCNT          6
#define MAX_AcSyncTime_NUM          10

#define AC_FUNC_LOG_MAX_SIZE ((UINT32)5242280)  // 5M = 1024 * 1024 * 5
#define AC_FUNC_LOG_MAX_FILE_NUM ((UINT32)10) //压缩文件最大分卷数
#define AC_FUNC_LOG_MAX_STRING ((UINT32)100) //绝对路径最大字符数

#define AC_FUNC_LOG_RST_SUCCES 0
#define AC_FUNC_LOG_FILE_MAX 11

enum
{
    AC_DDR_HANDLE_READ = 0,
    AC_DDR_HANDLE_WRITE
};
enum
{
    AC_FUNC_LOG_HIGH = 0,
    AC_FUNC_LOG_MID,
    AC_FUNC_LOG_LOW
};

#define ZTE_SECURITY_FUNC_CHECK(iRet)                                                             \
    {                                                                                             \
        if (BSP_FAIL == (INT32)(iRet))                                                            \
        {                                                                                         \
            dbgErr("[%s], line: %u, zte_s func iRet'%d Error \n", __FUNCTION__, __LINE__, (iRet));\
            return (iRet);                                                                        \
        }                                                                                         \
    }

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
typedef struct t_RecordAcSyncTime
{	
	UINT32 SyncTimeIndex[MAX_AcSyncTime_NUM];
	UINT32 SyncTime[MAX_AcSyncTime_NUM];
}T_RecordAcSyncTime;

typedef struct t_RecordAcDoInfo
{
	UINT32 AcDataInitCnt;
	UINT32 WriteAcMsgCnt;
	UINT32 SetAcSeqIcCnt;         
	UINT32 GetAcSyncTimeCnt;      
	UINT32 SetAcParaIcCnt;              
	UINT32 GetAcCatchDataStaCnt;  
	UINT32 SendHaulBackAcSeqIcCnt;
	UINT32 DlWaitR8TimeCnt;
	UINT32 DlWaitR8TimeSpillCnt;
	UINT32 UlWaitR8TimeCnt;
	UINT32 UlWaitR8TimeSpillCnt;
	UINT32 SetAcWgtIcCnt;
	UINT32 ChkAcSeqIcCnt;
	UINT32 SetAcSyncTimeCnt;
	UINT32 CalAcSeqIcCnt;
	UINT32 GetAcSeqIcCnt;
	UINT32 CalAcWgtIcCnt;
	UINT32 GetAcWgtIcCnt;
	UINT32 ChkAcWgtIcCnt;
	T_RecordAcSyncTime SetAcSyncTimeSta;
}T_RecordAcDoInfo; 




/**************************************************************************
 *                            函数声明                                   *
 **************************************************************************/
UINT32 getGenInt4CallBackCnt(VOID);
UINT32 getRetryDmaCnt(UINT32 acType);
UINT32 getR8Dog(VOID);

VOID RecordR8AcSeqStartFrameNo(UINT32 acType,UINT32 bitMap,UINT32 frameNo,UINT32 realNo);
UINT32 checkWaitR8SmpOverTime(UINT32 acType, UINT32 waitR8TimeCnt);
VOID recordErsUpdateTime(UINT32 acType, UINT32 acFlag);
VOID recordWaitR8TimeCnt(UINT32 acType, UINT32 waitR8TimeCnt);
VOID recordToDspPackets(UINT32 acType, UINT32 retVal);
VOID RecordSetAcSeqIcInfo(UINT32 carr,UINT32 pasteCarrFlag,UINT32 deviate,UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode,UINT32 acType);
VOID RecordSetAcParaIcInfo(UINT32 acType,UINT32 refChn,UINT32 acChnChgFlag);
VOID getAcInfo(UINT32 acType, UINT32 carrNo, UINT32 radioMode);


VOID recordAcDataInitCnt(VOID);
UINT32 JudgeWaitR8TimeCnt(UINT32 acType,UINT32 waitR8TimeCnt);
VOID recordSendHaulBackAcCnt(VOID);
VOID recordSetAcWgtIcCnt(VOID);
VOID recordWriteAcMsgCnt(VOID);
VOID recordGetAcSyncTimeCnt(VOID);
VOID RecordSetAcSyncTimeCnt(UINT32 syncTime);
VOID recordGetAcCatchDataStaCnt(VOID);
VOID recordSetAcParaIcCnt(UINT32 acType);
UINT32 SetRecordAcDoInfoInit(VOID);
VOID recordCalAcSeqIcCnt(VOID);
VOID recordAcTickInfo(UINT32 type,UINT32 funIdx,UINT32 exceptionExit);
VOID RecordShareAcSeqStartFrameNo(UINT32 acType,UINT32 bitMap,UINT32 frameNo,UINT32 realNo);
VOID recordGetAcWgtIcCnt(VOID);
VOID recordChkAcWgtIcCnt(VOID);
VOID recordCalAcWgtIcCnt(VOID);
VOID recordGetAcSeqIcCnt(VOID);
VOID recordChkAcSeqIcCnt(VOID);

UINT32 BspHandleAcFuncLog(VOID);

INT32 AcFuncLogM(UINT32 logLevel, const CHAR *format, ...);

INT32 AcFuncLogS(UINT32 logLevel, const CHAR *format, ...);

UINT32 AcFuncDspAddrInfo(UINT32 uiMode);

VOID BspRecordLastAcRst(UINT32 uiAcRst);
UINT32 BspGetLastAcRst(VOID);

UINT32 AcFuncPasta(VOID);
VOID AcFuncDbfs(VOID);
VOID AcFuncAttshow(VOID);
UINT32 AcFuncDlpostPaptAlm(VOID);
VOID AcFuncRssi(UINT32 uiRadioMode, UINT32 uiCarrNo);
UINT32 AcFuncCarrSta(VOID);

#ifdef __cplusplus
}
#endif
#endif /*endif FUNCLIB_ACDEBUG_H_INCLUDED*/

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : antcal.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了天线校正接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2019-03-21
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _FUNCLIB_ANTCAL_H_
#define _FUNCLIB_ANTCAL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "antcalapi.h"
#include "dpd_app.h"

#define KXCPSW_AC_DEV                    "/dev/cpsw_ac"
#define CPSW_SET_ADDR_INFO              (0x11)
#define CPSW_AC_DEBUG                   (0x33)
#define CPSW_GET_INFO                   (0x44)
#define CPSW_AC_DATA_GET                (0x55)
#define CPSW_AC_START_SET               (0x66)  
#define AC_SIZE_1K                      (1024)
#define AC_SIZE_512K                    (AC_SIZE_1K*512)
#define AC_SIZE_1M                      (AC_SIZE_1K*1024)
#define AC_SIZE_1G                      (AC_SIZE_1M*1024)
#define AC_SIZE_H_OFFSET                (0x70000)
#define AC_SIZE_JAC_CONJ_FREQ_SEQ_OFFSET (0x75000)

//AC序列的大小
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024     1024*4  //CPU读取DSP计算出来的AC发送序列 大小
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_768      768*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_512      512*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_384      384*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_256      256*4

#define AC_IF0_TYPE                        0
#define AC_IF1_TYPE                        1

//9626E电桥新增
#define LTE_SLOT_SYM_NUM                   7
#define COUPNET_APP_LIST                   3

#define AC_WEIGHT_DATA_NUM_FOR_APP         100
#define AC_WEIGHT_FOR_APP_ARR              99
#define AC_WEIGHT_DATA_LAST_ELE            98
#define AC_NETMODE_DUP                     1

#define AC_UDP_SEND_PACK                   3
#define AC_UDP_MAX_PACK                    4

#define AC_ANT_NUM_INVALID                 64

#define IC42_MAX_POLA_CHAN             (2)
#define IC42_AC_MAX_RB_NUM             (273)
#ifndef BITMAP_MAX_NUM
    #define BITMAP_MAX_NUM                   (128)
#endif

#define AC_LTE_COUPLE_NUM             (20)
#define AC_LTE_COUPLE_BAND_NUM_MAX    (4)

/****************************************************************/

/**********************IC A53与R8共享内存起始和大小*****************************
****************************************************************/
#define IC_AC_SHARE_MEM_ADDR_PHY_BASE           0x01200000
#define IC_AC_SHARE_MEM_ADDR_SIZE               0x00400000   //4M

/**********************上行校正采数*****************************
 16轮重复迭代*每轮1次发完64T(每次1发64收)*采数是1024个点*4字节
 由于每个IC各收各的，所以实际每个IC是1发32收，对应大小是1024*4*32*16 = 2MB
 绝对地址:0x0200_0000
 大小:    2MB
 范围:    0x0200_0000 ~ 0x021F_FFFF
****************************************************************/
#define IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET 0x00000000//偏移地址0x0000_0000
#define IC_AC_SHARE_MEM_UL_CATCH_DATA_SIZE         0x00200000//大小为0x0020_0000，2MB

/**********************下行校正采数*****************************
 16轮重复迭代*每轮9次发完64T(每次8发1收)*采数是1024个点*4字节
 绝对地址:0x0220_0000
 大小:    16*9*1024*4Bytes = 0x0009_0000 = 576K
 范围:    0x0220_0000 ~ 0x0228_FFFF
****************************************************************/
#define IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET 0x00200000//偏移地址为0x0020_0000
#define IC_AC_SHARE_MEM_DL_CATCH_DATA_SIZE         0x00090000//大小为0x0009_0000, 576KB

/**************下行的9轮天线规则对应的Block Bank信息****************
 绝对地址:0x0229_0000
 大小:   ICRRBBdlBlockBankBandInfo这个结构体就是9KB大小
 范围:    0x0229_0000 ~ 0x0229_23FF
**********************************************/
#define IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_ADDR_OFFSET 0x00290000//偏移地址是0x0029_0000
#define IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_SIZE        0x00002400//大小为0x0000_2400，9K

/**************上行1轮天线规则对应Block Bank信息****************
 绝对地址:0x0229_2400
 大小:   ICRRBBulBlockBankBandInfo这个结构体就是2KB大小
 范围:    0x0229_2400 ~ 0x0229_2BFF
**********************************************/
#define IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_ADDR_OFFSET  0x00292400//偏移地址是0x0029_2400
#define IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_SIZE         0x00000800//大小为0x0000_0800，2K

/**************下行和上行AC权值数据信息:DMA搬移的源地址、目的地址、长度等信息****************
 绝对地址:0x0229_2C00
 大小:   1K
 范围:    0x0229_2C00 ~ 0x0229_2FFF
**********************************************/
#define IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_ADDR_OFFSET 0x00292C00//偏移地址是0x0029_2C00
#define IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_SIZE        0x00000400//大小为1K，即0x0000_0400

/**************调试和维测信息****************
 绝对地址:0x0229_3000
 大小:  1K
 范围:    0x0229_3000~0x0229_33FF
**********************************************/
#define IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET 0x00293000 //偏移地址是0x0029_3000
#define IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_SIZE        0x00000400//大小为1K，即0x0000_0400

/**************调试和维测信息****************
上行VGA上报数据，32根天线，每根UINT32大小数据，分16次采，共16*4*32 = 2KB
 绝对地址:0x0229_3000
 大小:  2KB
 范围:    0x0229_3000~0x0229_33FF
**********************************************/
#define IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET 0x00293400//偏移地址是0x0029_3400
#define IC_AC_SHARE_MEM_UL_AC_VGA_DATA_SIZE        0x00000800//大小为2K，即0x0000_0800

/*************************************************************/

/**************失步干扰_FRAMENO*******************
 绝对地址: 0x0029_3C00
 大小:  4B
 范围: 0x0029_3C00 ~ 0x0029_3C03
**********************************************/
#define IC_AC_SHARE_MEM_OUT_SYNC_FRAMENO_ADDR0_OFFSET         0x00293C00//偏移地址是0x0029_3C00
#define IC_AC_SHARE_MEM_OUT_SYNC_FRAMENO_ADDR0_DATA_SIZE      0x00000004//大小为4B，即0x00000004

/**************失步干扰_IODLCFG*******************
 绝对地址: 0x0029_3C04
 大小:  100B
 范围: 0x0029_3C04 ~ 0x0029_3D03
**********************************************/
#define IC_AC_SHARE_MEM_OUT_SYNC_IODLCFG_ADDR0_OFFSET         0x00293C04//偏移地址是0x00293C04
#define IC_AC_SHARE_MEM_OUT_SYNC_IODLCFG_ADDR0_DATA_SIZE      0x00000200//大小为256B，即0x00000100

/**************失步干扰_IOULCFG*******************
 绝对地址: 0x0029_3D04
 大小:  100B
 范围: 0x0029_3D04 ~ 0x0029_3E03
**********************************************/
#define IC_AC_SHARE_MEM_OUT_SYNC_IOULCFG_ADDR0_OFFSET         0x00293E04//偏移地址是0x00293D04
#define IC_AC_SHARE_MEM_OUT_SYNC_IOULCFG_ADDR0_DATA_SIZE      0x00000200//大小为256B，即0x00000100

/***************驻波检测_FWD***********************
 VSWR驻波检测FWD上报数据，8根天线，每根天线上的FWD占用2*4B，共8*2*4B = 64B
 绝对地址: 0x0029_4004
 大小:  64B
 范围: 0x0029_4004 ~ 0x0029_4043
**********************************************/
#define IC_AC_SHARE_MEM_OUT_VSWR_FWD_ADDR0_OFFSET         0x00294004//偏移地址是0x00294004
#define IC_AC_SHARE_MEM_OUT_VSWR_FWD_ADDR0_DATA_SIZE      0x40      //大小为64B

/***************驻波检测_REV***********************
 VSWR驻波检测REV上报数据，8根天线，每根天线上的REV占用2*4B，共8*2*4B = 64B
 绝对地址: 0x0029_4044
 大小:  64B
 范围: 0x0029_4044 ~ 0x0029_4083
**********************************************/
#define IC_AC_SHARE_MEM_OUT_VSWR_REV_ADDR0_OFFSET         0x00294044//偏移地址是0x00294044
#define IC_AC_SHARE_MEM_OUT_VSWR_REV_ADDR0_DATA_SIZE      0x40      //大小为64B


/**********************IC A53与AC DSP共享内存起始和大小*****************************
****************************************************************/

#define IC_AC_SHARE_MEM_ADDR_PHY_BASE_A53_ACDSP 0x01600000
#define IC_AC_SHARE_MEM_ADDR_SIZE_A53_ACDSP     0x00FF0000    //A53和DSP的有效存放地址

//DSP使用的偏移地址，用于存放上下行的AC数据
#define NXP_AC_MEM_DSP_RECV_AC_SEQ_ADDR        0              //CPU读取DSP存储的上行AC数据 地址 0x0000_0000
#define NXP_AC_MEM_DSP_RECV_AC_SEQ_SIZE        16*8*1026*4    //CPU读取DSP存储的上行AC数据大小
#define NXP_AC_MEM_DSP_TRAN_AC_SEQ_ADDR        10*AC_SIZE_1M   //CPU读取DSP存储的下行AC数据 地址 0x00A0_0000
#define NXP_AC_MEM_DSP_TRAN_AC_SEQ_SIZE        16*1026*4      //CPU读取DSP存储的下行AC数据大小

//DSP自己使用的偏移地址，用于存放上下行的JAC数据
#define NXP_AC_MEM_DSP_UL_ORG_DATA_ADDR        0              //CPU读取DSP存储的上行AC数据 地址 0x0000_0000
#define NXP_AC_MEM_DSP_UL_ORG_DATA_SIZE        16*8*1026*4    //CPU读取DSP存储的上行AC数据大小
#define NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR        10*AC_SIZE_1M  //CPU读取DSP存储的下行AC数据 地址 0x00A0_0000
#define NXP_AC_MEM_DSP_DL_ORG_DATA_SIZE        16*1026*4      //CPU读取DSP存储的下行AC数据大小

//上行频域权值的偏移地址
#define NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_ADDR    12*AC_SIZE_1M  //CPU读取DSP存储的上行频域权 地址 0x00C0_0000
#define NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_SIZE  64*273*4      //CPU读取DSP存储的上行频域权 大小

//下行频域权值的偏移地址
#define NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_ADDR    13*AC_SIZE_1M  //CPU读取DSP存储的下行频域权 地址 0x00D0_0000
#define NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_SIZE  64*273*4      //CPU读取DSP存储的下行频域权 大小

//参考通道信道估计
#define NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR        13*AC_SIZE_1M + AC_SIZE_H_OFFSET //CPU读取DSP存储的参考通道H 地址 0x00D7_0000
#define NXP_AC_MEM_CPU_RD_REF_AC_H_SIZE        4*1024*4                         //CPU读取DSP存储的参考通道H 大小

//参考通道信道估计
#define NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR       13*AC_SIZE_1M + AC_SIZE_H_OFFSET + 4*1024*4 //CPU读取DSP存储的H定标因子 地址 0x00D7_4000
#define NXP_AC_MEM_CPU_RD_REF_SCALE_SIZE       4                                           //CPU读取DSP存储的H定标因子 大小

//AC频域定点基序列的偏移地址
#define NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR  13*AC_SIZE_1M + AC_SIZE_JAC_CONJ_FREQ_SEQ_OFFSET//CPU读取DSP计算出来的AC频域定点基序列 地址 0x00D7_5000
#define NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_SIZE  1024*4    

//AC序列的偏移地址
#define NXP_AC_MEM_CPU_RD_AC_SEQ_ADDR          13*AC_SIZE_1M + AC_SIZE_512K //CPU读取DSP计算出来的AC发送序列 地址 0x00D8_0000
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE          1024*4                      //CPU读取DSP计算出来的AC发送序列 大小

//下面定义对应结构体 T_Cmac2PulmAntAdjustScheInfo 这是APP发给BSP并写共享内存的DSP需要的信息的偏移地址
#define NXP_AC_MEM_CPU_WR_AC_INFO_ADDR         14*AC_SIZE_1M  //CPU写DSP需要的各种AC计算参数 地址0x00E0_0000
#define NXP_AC_MEM_CPU_WR_AC_INFO_SIZE         0x12D43       //CPU写DSP需要的各种AC计算参数 大小

//下面定义对应结构体T_Pulm2CmacAntAdjustRsp 这是DSP写入共享内存BSP需要的信息，包含prach权的偏移地址
#define NXP_AC_MEM_CPU_RD_AC_INFO_ADDR         15*AC_SIZE_1M  //CPU读DSP存储的恢复信息，包括prach权 地址0x00F0_0000
#define NXP_AC_MEM_CPU_RD_AC_INFO_SIZE         0x866         //CPU读DSP存储的恢复信息，包括prach权 大小

//内插前延时
#define FRONT_ZERO_TYPE 0
#define END_ZERO_TYPE   1

#define IC_AC_RETRY_TIME 16
#define IC_AC_ROUND_TIME 9
#define IC_AC_POINT_NUM  1024

/****************************************************************/
/* GP位置计算公式类型 中移混模NR&LTE 及 单模NR */
//AC序列长度= AC原始长度+CP长度
#define GP_AC_SQUENCE_LEN_NR_122880 (1024+64) //1088
#define GP_AC_SQUENCE_LEN_NR_92160  (768+48)  //816
#define GP_AC_SQUENCE_LEN_NR_61440  (512+32)  //544
#define GP_AC_SQUENCE_LEN_NR_46080  (384+24)  //408
#define GP_AC_SQUENCE_LEN_NR_30720  (256+16)  //272
#define GP_AC_SQUENCE_LEN_LTE_30720 (512+32)  //544
#define GP_AC_SQUENCE_LEN_LTE_23040 (384+32)  //416
#define GP_AC_SQUENCE_LEN_LTE_15360 (256+16)  //272
#define GP_AC_SQUENCE_LEN_LTE_7680  (128+8)  //272

#define GP_TIME_BASE_UPLINK  (1096)
#define GP_TIME_BASE_DOWNLIK (600)
#define AC_SEQ_NR_BASIC_LEN  (1088)
#define AC_SEQ_LTE_BASIC_LEN (544)
#define AC_LTE_SEQ_WITH_RF_DELAY (1584)

#define GP_DW_PTS_TS_NR (4384)

#define VSWR_FWD_MODE              (1)       /*VSWR FWD模式*/
#define RCUA_MAX_CAL_PORT_NUM      (3)       /* RCUA机型支持3个CAL口 */
#define RCUA_MAX_FREQ_NUM          (5)       /* RCUA机型支持5个频段 */
#define DBFS_VALUE_16BIT   (9031)      /* 20log(2^15)=90.308998699,16bit-1 */
#define VSWR_VAILD_FLAG            (1)  /* 驻波计算有效标志 */
#define VSWR_INVAILD_FLAG          (0)  /* 驻波计算无效标志 */

#define RTIOC_TYPE_PSYNC        RTIO_CLASS_PSYNC
#define RTTST_RTIOC_MSG_OPT_NOTIFY    _IOW(RTIOC_TYPE_PSYNC, 0x00, T_NOTIFY_MSG_DATA)

/*************************************************************/

enum JAC_HANDLE_TYPE
{
    JAC_SEND_DATA = 0,
    JAC_CATCH_DATA,
    JAC_SEND_CATCH_DATA
};

enum JAC_EN_FLAG
{
    JAC_DISABLE = 0,
    JAC_ENABLE
};

enum AC_WGT_TYPE
{
    AC_WGT_FREQ = 0,
    AC_WGT_TIME,
    AC_WGT_TA
};

enum JAC_REF_RST
{
    JAC_REF_SUC = 0,
    JAC_REF_FAILED
};

enum
{
    ERGODIC_FREE = 0,
    CJT_BIG_ERGODIC,            // CJT大遍历
    CJT_SMALL_ERGODIC,          // CJT小遍历
    UTDOA_BIG_ERGODIC,          // UTDOA大遍历
    UTDOA_SMALL_ERGODIC,        // UTDOA小遍历
};

#define AC_DATA_LEN 1024
#define AC_DDR_DATA_OFFSET    273
#define JAC_DDR_DATA_OFFSET   274
#define JAC_DATA_ORG_DATA_LEN 1024
#define JAC_DATA_ORG_DATA_OFFSET 1026
#define JAC_ITERATIONS 4
#define JAC_REF_H_SCALE 4

//Jac新增
#define JAC_FR_DEBUG_CNT_MAX  10
enum JAC_SUPER_FR_RESULT
{
    JAC_SUPER_FR_SUC = 0,
    JAC_SUPER_FR_ERR
};

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef RESULT_CHECK_NO_HANDLE
#define RESULT_CHECK_NO_HANDLE(uiRet)                                                               \
    {                                                                                              \
        if (BSP_OK != (uiRet))                                                                     \
        {                                                                                          \
            dbgInfo("[%s], line: %u, no handle  \n", __FUNCTION__, __LINE__, (uiRet));             \
        }                                                                                          \
    }
#endif

// 函数返回值检查宏，返回 return
#ifndef RESULT_CHECK_RETURN_AC
#define RESULT_CHECK_RETURN_AC(uiRet)                                                 \
    {                                                                                 \
        if (BSP_ERROR == (uiRet))                                                        \
        {                                                                             \
            dbgErr("[%s][LINE %d] uiRet Error!\n", __FUNCTION__, __LINE__);           \
            return BSP_ERROR;                                                         \
        }                                                                             \
    }
#endif

#ifndef INPUT_FALSE_CONTINUE_AC
#define INPUT_FALSE_CONTINUE_AC(input)                                                \
    if (0 == (input))                                                                 \
    {                                                                                 \
        printf("[%s][LINE %d] Input is False!\n", __FUNCTION__, __LINE__);            \
        continue;                                                                     \
    }
#endif
/* Started by AICoder, pid:ucc70me755fa49a14ef90a28701ec41e4ea90724 */
#ifndef RETURN_RESULT_CHECK_AC
#define RETURN_RESULT_CHECK_AC(uiRet)                                                            \
    {                                                                                            \
        if (BSP_OK != (uiRet))                                                                   \
        {                                                                                        \
            dbgInfo("[%s], line: %u, AC Result Check 0x%X \n", __FUNCTION__, __LINE__, (uiRet)); \
            return uiRet;                                                                        \
        }                                                                                        \
    }
#endif

#ifndef INPUT_COMPARE_CONTINUE_AC
#define INPUT_COMPARE_CONTINUE_AC(inputA, inputB)                                                \
    if ((inputA) != (inputB))                                                                     \
    {                                                                                             \
        dbgInfo("[%s][LINE %d] compare not equal inputA:%d, inputB:%d \n", __FUNCTION__, __LINE__, inputA, inputB); \
        continue;                                                                                 \
    }
#endif

#define BSP_RF_FREQ1_NUM (4)

/* Ended by AICoder, pid:ucc70me755fa49a14ef90a28701ec41e4ea90724 */
typedef struct tag_T_AC_WGT_ADDR_INFO
{
    UINT32 uiSocId;
    UINT32 uiDir;
    UINT32 uiDdrOffset;
    UINT32 uiAcWidth;
    UINT8 *pucWgtAddr;
}T_AC_WGT_ADDR_INFO;

typedef struct tag_T_AC_WGT_INFO
{
    UINT32 radioMode;
    UINT32 bandWidth;
    UINT32 rbNum;
}T_AcWgtInfo;

struct ac_info
{
    INT32 sendPackets_ok;
    INT32 sendPackets_err;
};

typedef struct tag_T_AC_LEN_TS
{
    UINT32 radio;
    UINT32 bandWidth;
    UINT32 sample;
    UINT32 acLen;  //acLen = acSeqLen + 前后CP
}T_AcLenInfo;

//所有制式下参数
typedef struct tag_T_AC_ALL_PARA
{
    UINT32 radio;
    UINT32 bandWidth;
    UINT32 sample;  
    UINT32 acSeqLen;
    UINT32 acDataOffset;
    UINT32 acCpLen;
}T_AcAllParaInfo;

//目前制式下参数
typedef struct tag_T_AC_PARA
{
    UINT32 sample;  
    UINT32 acSeqLen;
    UINT32 acDataOffset;
    UINT32 acCpLen;
}T_AcParaInfo;

typedef struct tag_T_AC_CARR_INFO
{
    UINT32 acType;  
    UINT32 radioMode;
    UINT32 carrNo;
    UINT32 bandWidth;
}T_AcCarrInfo;

typedef struct tag_T_AC_WGT_DATA
{
    UINT32 *pWgt;
    UINT32  uiWgtLength;
    UINT32 *pPrachWgt;
    UINT32  uiPrachLength;
    UINT32  uiPasteCarrFlag;
}T_AcWgtData;
#pragma pack(1) /*按照单字节对齐*/
typedef struct notify_to_kernel
{
    UINT32 private[1];
}T_NOTIFY_MSG_DATA;
#pragma pack() /*取消指定对齐，恢复缺省对齐*/
typedef struct tag_T_JAC_SUERP_FR_DEBUG
{
    UINT32 uiCfgFr;
    UINT32 uiRealFr;
    LONG timeRet;
}T_JacSuperFrInfo;

/* Started by AICoder, pid:wf2b1g4ce11cb0d1411c0a2310e49919a6d6ed0c */
typedef struct tag_T_AC_RETRY_INFO
{
    UINT32 retry;
    UINT32 retryTime;
    UINT32 round;
    UINT32 roundTime;
}T_AcRetryInfo;

typedef struct tag_T_AC_DATA_PARA
{
    UINT32 uiAcType;
    UINT32 uiCarrNo;
    UINT32 uiPasteCarrFlag;
    UINT32 uiBandWidth;
    UINT32 uiRadioMode;
}T_AcDataPara;

typedef struct tag_T_VSWR_FREQ_INFO
{
    UINT32 uiFwdValue;
    UINT32 uiFwdBasicInfo;
    UINT32 uiRevValue;
    UINT32 uiRevBasicInfo;
}T_VswrFreqInfo;

typedef struct tag_T_VSWR_DETECT_INFO
{
    T_VswrFreqInfo atVswrFreqInfo[RCUA_MAX_FREQ_NUM];
}T_VswrDetectInfo;

typedef struct tagT_aacWgtData
{
    UINT32 logicCarrNo;
    UINT32 radioMode;
    UINT32 aacErrWgtbak[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM];
    UINT32 aacWgtLength;            /* AAC权值的长度，单位为byte */
    UINT32 aacInitiateNum;
    UINT32 aacRbNum;                //维测使用
}T_aacWgtData;

typedef struct tagT_AacBitmapCfg
{
    UINT8 txBitmap[BITMAP_MAX_NUM];       /**tx位图*/
    UINT8 rxBitmap[BITMAP_MAX_NUM];       /**rx位图*/
}T_AacBitmapCfg;

/* Ended by AICoder, pid:wf2b1g4ce11cb0d1411c0a2310e49919a6d6ed0c */
UINT32 showUlAcAllProgressCnt(VOID);
UINT32 BspGetAcFrontOrEndZeroDelay(UINT32 acType, UINT32 radio, UINT32 carrNo,UINT32 gpNum,UINT32 bw,UINT32 pasteCarrFlag, UINT32 frontOrEnd);
UINT32 BspGetAcFrToDlEnd(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 bw, UINT32 pasteCarrFlag);
UINT32 showUlAcVgaData(UINT32 carrNo, UINT32 radioMode);
UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag);
VOID testDlAcSeqIc(VOID);
VOID testUlAcSeqIc(VOID);
UINT32 bspAcPsyncInit(UINT32 radioMode);
UINT32 BspSetRxAcSwitch(UINT32 chan,UINT32 sw);
UINT32 BspSetTxAcSwitch(UINT32 chan, UINT32 sw);
UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag);
UINT8* BspGetAcMemBaseAddr(VOID);
T_AcCarrCfgNxp* GetAcCarrCfg(VOID);
UINT32 BspInitAllSaveWgt(void);
UINT32 BspGetAntAmpPhase(UINT32 ulPath, UINT32 ulCarrFreq, T_PauRelativeRec *ptData);
UINT32 BspOutOfPsyncDetectPsyncInit(VOID);
UINT32 BspGetAcNetMode(VOID);
UINT32 BspGetPauRelativePhaseDup(UINT32 ulChan, UINT32 ulBand, INT32 lFreq, INT32 *plPhase);
UINT32 BspGetDupTxChannel(VOID);
UINT32 BspGetCoupNetPostPro(UINT32 *pUlNetFactorApp,UINT32 *pUlNetFactorSource,UINT32 uiChan,UINT16 *pvalidFreNum,UINT32 carryno);
UINT32 BspGetULCoupleNetFactor(UINT32 cellId, UINT16 channelId, UINT16* pvalidFreNum, UINT32 *pBridegPara);
UINT32 BspSetWgtPostPro(UINT32 *pDupCarryWgt,UINT32 *pOriWgt,UINT32 *pOrgCarryWgt,UINT32 uiDateLen,UINT32 AntBitmap);
UINT32 SetAcWgtIcPro(T_AcCarrInfo* ptAcCarrInfo, T_AcWgtData* ptAcWgtData);
UINT32 BspGetAcCatchChan(UINT32 *pCatchDataChan, UINT32 *pAcRpuId, UINT32 *pBandNo);
UINT32 BspGetOamAcType(UINT32 uwACType);
UINT32 BspSetCouplingMode(UINT32 uiAdapteEn, UINT32 uiAdapteType);
//Jac新增
UINT32 BspGetAcWgtRbNum(UINT32 radioMode,UINT32 bandWidth,UINT32 pasteCarrFlag,UINT32 If0TypeOrIf1Type);
UINT32 GetJacMode(VOID);
UINT32 GetJacType(VOID);
UINT8 GetJacBitMap(VOID);
UINT32 GetCalRoute();
UINT8* BspGetAcDspMemBaseAddr(VOID);

//vswr检测新增
UINT32 SetVswrPara(UINT32 acType);/* 配置驻波参数 */
UINT32 SetVswrFwdPara(UINT32 acType);/* 配置fwd检测参数 */
UINT32 GetVswrCalFinishSta(UINT32 *puiCalSta);/* 回读驻波计算状态 */
UINT32 GetVswrData(UINT32 acType);/* 获取驻波值 */
UINT32 showvswrval(UINT32 uiCalPort, UINT32 uiFreq);/* 回读fwd和rev */
UINT32 BspConvertRegToDbfs(UINT32 uiCalPort, UINT32 uiFreq, INT32 *piFwdVal, INT32 *piRevVal);/* 将寄存器值转化成dbfs */
UINT32 BspGetPauRelativePhaseData(UINT32 ulChan, UINT32 ulBand, UINT32 pauIdx, INT32 lFreq, INT32 *plPhase);
UINT32 BspGetAcRelativePhaseData(UINT32 chan, UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep, UINT32 **pData);
UINT32 BspInitAac(VOID);
UINT32 SwAppAacTypeToIcType(UINT32 type, UINT32 *aacType, UINT32 *aacStage);
UINT32 testSetAacBitmapToIcHal(UINT8 txBitmapData, UINT8 rxBitmapData, UINT32 dir, UINT32 startIndex, UINT32 endIndex);
UINT32 dbgPrintAacFrameMode(VOID);
UINT32 dbgPrintAacSampPointDly(VOID);
VOID dbgShowUtdoaSuperFrameInfo(UINT32 carrNo);
void prnaacsupframebitmap(UINT32 carrNo);
UINT32 InitStoredCarrWgt(UINT32 logicCarrNo, UINT32 radioMode);
UINT32 CalcUpdateAcWgtNew(UINT32 saveWgtIndex, UINT32 *pUpdataWgt, UINT32 updataWgtLength);
UINT32 UpdateAcWgtNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pUpdataWgt, UINT32 updataWgtLength, UINT32 *pAcWgtLength);
UINT32 BspCheckAacWgtRangeNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 pAacWgt[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM]);
UINT32 SaveLatestAacWgtNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 pAacWgtData[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM], UINT32 aacWgtLength);
#ifdef __cplusplus
}
#endif
#endif 


#ifndef _DPDICHAL_ACDRV_H_
#define _DPDICHAL_ACDRV_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "exprn.h"
#include "secure_func.h"
#include "vxadp.h"
#include "antcal_ic4_2_oneic.h"
#include "antcalcommon.h"

#define AC_TYPE_DL                0   //代表下行
#define AC_TYPE_UL                1   //代表上行
#define AC_TYPE_STOP              2   //代表结束AC
#define VSWR_TYPE_FWD             3   //代表FWD
#define VSWR_TYPE_REV             4   //代表REV
#define VSWR_TYPE_STOP            5   //代表结束VSWR

#define AC_TYPE_FDD_DL            8   //代表fdd下行
#define AC_TYPE_FDD_UL            9   //代表fdd上行

#define IC_AC_RETRY_TIME 16
#define IC_AC_ROUND_TIME 9
#define IC_AC_POINT_NUM  1024
#define DL_BANK_BANK_NUM  16
#define IC_AC_ULBANK_RAM_NUM 32

#define acDrvAcSeqPntCnt          1024
#define acDrvAcSeqPntCntLte       512
#define acDrvAcSeqPntCntLtePaste  1024
#define acPulseDataLen           ((acDrvAcSeqPntCnt)*64)
#define AC_CELL_SEPARATE_MODE     1

#define AC_INSERT_0_POS     0
#define AC_INSERT_1_POS     1
#define AC_INSERT_2_POS     2
#define AC_INSERT_3_POS     3

#define AC_PHASE_DIFF_MODE        1

#define AC_NOT_CHANGE_CALC_CHN    0
#define AC_CHANGE_CALC_CHN        1

#define CATCH_RAM_EN_ON   1
#define CATCH_RAM_EN_OFF  0
#define BAND_IS_SELECT    1

#define AC_DATA_LEN_1024          1024
#define AC_DATA_LEN_768           768
#define AC_DATA_LEN_512           512
#define AC_DATA_LEN_384           384
#define AC_DATA_LEN_256           256
#define AC_DATA_LEN_128           128

#define AC_DATA_OFFSET_128        128
#define AC_DATA_OFFSET_96         96
#define AC_DATA_OFFSET_64         64
#define AC_DATA_OFFSET_48         48
#define AC_DATA_OFFSET_32         32
#define AC_DATA_OFFSET_16         16

#define AC_CP_64                  64
#define AC_CP_48                  48
#define AC_CP_32                  32
#define AC_CP_24                  24
#define AC_CP_16                  16
#define AC_CP_8                    8

#define AC_GP_LEN_NR                 4388   //(4448+4384*13)/14=4388
#define AC_DL_DATA_POS_TO_3GP_LEN_NR 600
#define AC_UL_DATA_POS_TO_3GP_LEN_NR 1096

#define AC_EPLD_GP_NUM_1      1
#define AC_EPLD_GP_NUM_2      2

#define AC_FREQ_BAND_S35     0
#define AC_FREQ_BAND_S26     1

#define ANT_NUM_PER_IC      (8)

#define FRAME_TYPE_2P5MS             2500
#define FRAME_TYPE_5MS               5000
#define FRAME_TYPE_10MS              10000
#define FRAME_TYPE_20MS              20000

#define PER_SLOT_NUM_NR              (61440)
#define PER_SUB_FRAME_NUM_LTE        (30720)
#define AC_DATA_TO_DSP_LEN            1024
#define ANT_IS_SELECT                 (1)

// 特殊类型AC RB数
#define IF0_RB_NUM_LTE                160
#define PASTE_CARR_RB_NUM             100

#define DFRAME_US_NR                  500
//NR 共4096+288(CP)=4384Ts Ts=1/(30000 * 4096)=8.138ns  4384*8.138/1000=35.677us
#define DL_OTHER_SYM_US_NR            35.677
#define DFRAME_US_LTE                 1000
//LTE 共2048+144(CP)=2192Ts Ts=1/(15000 * 2048)=32.552ns  2192*32.552/1000=71.354us
#define DL_OTHER_SYM_US_LTE           71.354
//LTE下长CP与普通CP时间差
#define DL_LONGCP_DIFF_LTE            0.52
//NR LTE添加8Ts保护
#define PRORT_TS                      0.26

#define AC_MULTI_CHIP                 (1)
//参数范围检查
#define INPUT_AC_PARAMETER_CHECK(para, maxVal)                                 \
    do                                                                         \
    {                                                                          \
        if ((para) >= (maxVal))                                                \
        {                                                                      \
            dbgErr("[%s] Input para'%d (>= maxVal'%d) Error!! \n", __FUNCTION__, (para), (maxVal)); \
            return BSP_ERROR;                                                  \
        }                                                                      \
    } while(0)

#define INPUT_AC_ZERO_CHECK(para)                                     \
    do                                                                \
    {                                                                 \
        if ((para) == 0 )                                             \
        {                                                             \
            dbgErr("[%s] Input para is zero!! \n", __FUNCTION__);     \
            return BSP_ERROR;                                         \
        }                                                             \
    } while(0)

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef RESULT_CHECK_CONTINUE_AC
#define RESULT_CHECK_CONTINUE_AC(uiRet)                                                              \
    {                                                                                                \
        if (BSP_OK != (uiRet))                                                                       \
        {                                                                                            \
            dbgInfoEx("[%s], line: %u, AC Result Check Continue uiRet'0x%X\n", __FUNCTION__, __LINE__, (uiRet)); \
            continue;                                                                                \
        }                                                                                            \
    }
#endif

#ifndef RESULT_CHECK_FALSE_CONTINUE_AC
#define RESULT_CHECK_FALSE_CONTINUE_AC(uiRet)                                                              \
    {                                                                                                \
        if (BSP_OK == (uiRet))                                                                       \
        {                                                                                            \
            dbgInfoEx("[%s], line: %u, AC Result Check Continue uiRet'0x%X\n", __FUNCTION__, __LINE__, (uiRet)); \
            continue;                                                                                \
        }                                                                                            \
    }
#endif

 
#ifndef INPUT_FALSE_NO_WARNING_AC
#define INPUT_FALSE_NO_WARNING_AC(input)                                     \
    if (64 == (input))                                                                 \
    {                                                                                 \
        return BSP_OK;                                                                     \
    }
#endif
/* Started by AICoder, pid:l543bp39379604b14689098880e9c52fef025527 */
#ifndef RESULT_CHECK_AC_WITHOUT_HANDLE
#define RESULT_CHECK_AC_WITHOUT_HANDLE(uiRet)                                                                          \
    {                                                                                                                  \
        if (BSP_OK != (uiRet))                                                                                         \
        {                                                                                                              \
            dbgInfoEx("[%s], line: %u, AC Result Check without handle uiRet'0x%X\n", __FUNCTION__, __LINE__, (uiRet)); \
        }                                                                                                              \
    }
#endif

#ifndef CHECK_AC_ANT_VALID
#define CHECK_AC_ANT_VALID(uiAnt)                                                                  \
    {                                                                                              \
        if (64 == (uiAnt))                                                                         \
        {                                                                                          \
            dbgInfoEx("[%s], line: %u, AC Ant INVALID Check Continue \n", __FUNCTION__, __LINE__); \
            continue;                                                                              \
        }                                                                                          \
    }
#endif

#ifndef RESULT_CHECK_BREAK_AC
#define RESULT_CHECK_BREAK_AC(uiRet)                                                                          \
    {                                                                                                         \
        if (BSP_OK == (uiRet))                                                                                \
        {                                                                                                     \
            dbgInfoEx("[%s], line: %u, AC Result Check Break uiRet'0x%X\n", __FUNCTION__, __LINE__, (uiRet)); \
            break;                                                                                            \
        }                                                                                                     \
    }
#endif
/* Ended by AICoder, pid:l543bp39379604b14689098880e9c52fef025527 */
//载波拼接拆分标志
enum
{
    CARR_NOT_PASTE = 0,
    CARR_IS_PASTE  = 1,
    CARR_IS_SPLIT  = 2
};

typedef enum
{
    AC_ROUND_0 = 0,
    AC_ROUND_1,
    AC_ROUND_2,
    AC_ROUND_3,
    AC_ROUND_4,
    AC_ROUND_5,
    AC_ROUND_6,
    AC_ROUND_7,
    AC_ROUND_8,
    AC_ROUND_9,
    AC_ROUND_NUM = 9
}E_AC_ROUND_LIST;

typedef enum
{
    AC_DL_ANTS_NUM_0 = 0,
    AC_DL_ANTS_NUM_1,
    AC_DL_ANTS_NUM_2,
    AC_DL_ANTS_NUM_3,
    AC_DL_ANTS_NUM_4,
    AC_DL_ANTS_NUM_5,
    AC_DL_ANTS_NUM_6,
    AC_DL_ANTS_NUM_7,
    AC_DL_ANTS_NUM_8,
    AC_DL_ANTS_NUM_9,
    AC_DL_ANTS_NUM_10,
    AC_DL_ANTS_NUM_11,
    AC_DL_ANTS_NUM = 12,
    AC_UL_ANTS_NUM = 12,
    MAX_ANT_NUM    = 64
}E_AC_DL_ANTS_NUM_LIST;//同时发送的天线个数

typedef enum
{
    AC_IC_0 = 0,
    AC_IC_1,
    AC_IC_2,
    AC_IC_3,
    AC_IC_4,
    AC_IC_5,
    AC_IC_6 = 6,
    AC_IC_7,
    AC_IC_NUM = 8
}E_AC_IC_LIST;//同时发送的天线个数

typedef struct CMPL16
{
    INT16 real;
    INT16 imag;
}CMPL16;

typedef struct t_acDataToDspType
{
    UINT32 ComplexData[AC_DATA_TO_DSP_LEN];
    INT32  iScale;
    INT32  iCrc;
}acDataToDsp;

typedef struct tag_ichal_acpara_delay_structure_para
{
    UINT32 acUlBankCompensateWaitDelay;       /* UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayPasteCarr;      /* 拼接载波UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelay50MNr;  /* NR 50M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelay40MNr;  /* NR 40M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr80M;  /* NR 80M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr60M;  /* NR 60M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr20M;  /* NR 20M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr30M;  /* NR 30M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr15M;  /* NR 15M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr10M;  /* NR 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayLte10M; /* LTE 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayLte15M; /* LTE 15M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 resv;                              /* 保留字段*/

}T_ICHAL_ACPARA_DELAY;

#pragma pack()
typedef struct tag_ichal_ac_drv_structure_para
{
    //A53
    T_ICHAL_ACPARA_DELAY acNrCfgPara;
    T_ICHAL_ACPARA_DELAY acLteCfgPara;

    UINT32 acOffset; //序列偏移
    UINT32 icNum; //IC数
    UINT32 dlAntNum; //下行每轮天线数
    UINT32 boardType;

    UINT32 acDlRoundNo;                 /* 下行校正分组数 */
    UINT32 acUlRoundNo;                 /* 上行校正天线数 */
    UINT32 acCatchDataChan;             /* 下行AC时，上行采数通道 */
    UINT32 acBackUpCatchDataChan;       /* 下行AC时，上行备用采数通道 */
    UINT32 acSendDataChan;              /* 上行AC时，下行发数通道 */
    UINT32 acBackUpSendDataChan;        /* 上行AC时，下行备用发数通道 */
    UINT32 acIcMaxAntNo;                /* 每片IC最大天线数 */
    UINT32 sendAcRpuId;                 /* 上行AC时，下行发数通道所在IC */
    UINT32 catchAcRpuId;                /* 下行AC时，上行采数通道所在IC */
    UINT32 AntNumSum;                   /* 最大天线数数目 */
    UINT32 insertTimes;                 /* FDD inslot 内插次数 */
    UINT32 acStartChan;                 /* 起始通道 */
    UINT32 acMultiChip;                 /* 多片整机标志*/
    UINT32 acCatchChnBand0;             /* Band0耦合通道 */
    UINT32 acCatchChnBand1;             /* Band1耦合通道 */
    UINT32 acCatchChnBand2;             /* Band2耦合通道 */
    UINT32 acSendChnBand0;              /* Band0校准通道 */
    UINT32 acSendChnBand1;              /* Band1校准通道 */
    UINT32 acSendChnBand2;              /* Band2校准通道 */
    UINT32 RcuaBoardFlag;               /* Rcua单板标志，Rcua机型用1，其余用0 */
    UINT32 acFixTxAttFlag;              /* 上行AC固定txatt标志*/
    UINT32 acTxAttValue;                /* 上行AC固定txatt值*/
    UINT32 acFixRxAttFlag;              /* 上行AC固定Rxatt标志*/
    UINT32 acRxAttValue;                /* 上行AC固定Rxatt值*/
    UINT32 (*pSetAcSyncEn)(UINT32 actype);
    UINT32 (*pMtsNcoCfg)(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 uiBandWidth, A53R8AcDebugShareInfo* shareInfo); /*MTS 配频接口*/
    INT32  (*pGetAcDspNco)(VOID);       /* 获取AC DSP NCO */
    UINT32 (*pSetAcTddRfSwitch)(UINT32 acType); /* 切换AC开关TDD时序*/
    UINT32 (*pBspSetAcTddSwitchPwrShare)(UINT32 acType, A53R8AcDebugShareInfo* shareInfo );
    UINT32 (*pBspSetCouplingAdapte)(UINT32 uiAdapteEn, UINT32 uiAdapteType);
    UINT32 (*pBspGetRfIoIndex)(UINT32 acType);
    INT32 (*pBspSetTxAttValue)(UINT32 chan,UINT32 attValue,UINT32 mask);
    INT32 (*pBspSetRxAttValue)(UINT32 chan,UINT32 attValue,UINT32 mask);
}T_ICHAL_ACPARA;

typedef struct IcHalAcBoardInfo
{
    UINT32 shareMemPhyAddrBase;      //物理首地址
    VOID* shareMemVirAddrBase;      //虚拟首地址
    UINT32 shareMemAllSize;          //共享空间总大小
    
    UINT32 dlAcUlBankCatchAddrOffset;//存放用于下行校正的ulBank采数，需要区分不同的RAM
    UINT32 dlAcUlBankCatchSize;      //存放用于下行校正的ulBank采数，需要区分不同的RAM
    UINT32 ulAcUlBankCatchAddrOffset;//存放用于上行校正的ulBank采数，需要区分不同的RAM
    UINT32 ulAcUlBankCatchSize;      //存放用于上行校正的ulBank采数，需要区分不同的RAM
    
    UINT32 dlBank0AxisDmaAddrOffset; //存放4个dlBank Axis写序列的地址，用于维测回读用

    UINT32 dlAcBlockBankInfoAddrOffset;  //存放下行AC的block和bank信息的地址，要传给R8
    UINT32 dlAcBlockBankInfoSize;        //存放下行AC的block和bank信息的地址，要传给R8
    UINT32 ulAcBlockBankInfoAddrOffset;  //存放上行AC的block和bank信息的地址，要传给R8
    UINT32 ulAcBlockBankInfoSize;        //存放上行AC的block和bank信息的地址，要传给R8

    UINT32 AcWgtDmaInfoAddrOffset;  //存放下行和上行AC权值的DMA信息，要传给R8
    UINT32 AcWgtDmaInfoSize;        //存放下行和上行AC权值的DMA信息，要传给R8

    UINT32 a53R8DebugInfoAddrOffset;  //存放上行AC权值的DMA信息，要传给R8
    UINT32 a53R8DebugInfoSize;        //存放上行AC权值的DMA信息，要传给R8

    UINT32 vgaDataAddrOffset;  //存放上行AC读取的vga数据的地址
    UINT32 vgaDataSize;        //存放上行AC读取的vga数据的数据长度

    UINT32 phaDiffSeqAddrOffset;  //残余相差模式下16通道序列数据
    UINT32 phaDiffSeqSize;

    UINT32 phaDiffAxisDmaAddrOffset;  //残余相差模式下,存放4个dlBank Axis写序列的地址，用于维测回读用

    UINT32 VswrBlockBankOffset;     //用于存放驻波计算时的block和bank信息
    UINT32 VswrBlockBankSize;      //用于存放驻波计算时的block和bank信息的大小

    UINT32 VswrTddSwitchOffset;     //用于存放驻波计算时的Tdd参数信息
    UINT32 VswrTddSwitchSize;      //用于存放驻波计算时的Tdd参数大小

    UINT32 VswrRevSwitchOffset;     //用于存放驻波计算时的Tdd参数信息
    UINT32 VswrRevSwitchSize;      //用于存放驻波计算时的Tdd参数大小

}IcHalAcBoardInfo;

typedef struct ICRDlRBlockBankInfo
{
    UINT32 dlIsSet[AC_DL_ANTS_NUM];   //用于动态配置
    UINT32 dlBank[AC_DL_ANTS_NUM];    //bank

    UINT32 ulIsSet[AC_DL_ANTS_NUM];   //用于动态配置
    UINT32 ulBank[AC_DL_ANTS_NUM];    //bank
    UINT32 ulVgaChn[AC_DL_ANTS_NUM];  //vga chan
    UINT32 ulVgaDelay[AC_DL_ANTS_NUM];//vga delay

    UINT32 dlDifChn[AC_DL_ANTS_NUM];
    UINT32 ulDifChn[AC_DL_ANTS_NUM];
    UINT32 reserve[160];
}ICRDlRBlockBankInfo;//必须是1024字节

typedef struct ICRRBlockBankDL
{
    ICRDlRBlockBankInfo bBInfo[AC_ROUND_NUM];//9轮,9*1024 = 9K
}ICRRBlockBankDL;//IC内部的处理，总共9轮，每一轮的信息

typedef struct ICRUlRBlockBankInfo
{
    UINT32 dlIsSet[AC_UL_ANTS_NUM];    //用于动态配置
    UINT32 dlBank[AC_UL_ANTS_NUM];     //bank

    UINT32 ulIsSet[AC_UL_ANTS_NUM];    //用于动态配置
    UINT32 ulBank[AC_UL_ANTS_NUM];     //bank
    UINT32 ulVgaChn[AC_UL_ANTS_NUM];   //vga chan
    UINT32 ulVgaDelay[AC_UL_ANTS_NUM]; //vga delay

    UINT32 dlDifChn[AC_UL_ANTS_NUM];
    UINT32 ulDifChn[AC_UL_ANTS_NUM];
    UINT32 reserve[160];
}ICRUlRBlockBankInfo;//必须是1024字节

typedef struct ICRRBlockBankUL
{
    ICRUlRBlockBankInfo bBInfo[1];
}ICRRBlockBankUL;//IC内部的处理，总共9轮，每一轮的信息

typedef struct L2dAcWgtR8DmaInfo
{
    UINT32 srcPhyAddr;
    UINT32 dstPhyAddr;
    UINT32 dataSize;
    UINT32 frameNo;
	UINT32 uDir;
	UINT32 pasteCarrFlag;
    UINT32 reserve[250];
}L2dAcWgtR8DmaInfo;//凑成1K

typedef struct tagIcAcShareMemInfo_dlAcCatchData
{
    UINT32 dlAcCatchData[IC_AC_ROUND_TIME][IC_AC_POINT_NUM];//4*16*9*1024 = 576KB
}dlAcCatchData;

typedef struct tagIcAcShareMemInfo_ulAcCatchData
{
    UINT32 ulAcCatchData[IC_AC_ULBANK_RAM_NUM][IC_AC_POINT_NUM]; //4*64*1024   = 64KB
}ulAcCatchData;

typedef struct tagIcAcShareMemInfo_dlSeqDmaStore
{
    UINT32 dlBankDmaSeq[IC_AC_POINT_NUM];                  //4*1024*4    = 16KB
}dlSeqDmaStore;

typedef struct UlAcVgaData
{
    UINT32 vga[IC_AC_RETRY_TIME][AC_UL_ANTS_NUM];//2KB，正好是2KB
}UlAcVgaData;//凑成2K

typedef struct tagIcAcShareMemInfo
{
    ulAcCatchData ulAcCatch[IC_AC_RETRY_TIME];//4*32*1024*16 = 2MB
    dlAcCatchData dlAcCatch[IC_AC_RETRY_TIME];//4*16*9*1024  = 576KB

    ICRRBlockBankDL dlbBInfo;                   //9*1024       = 9KB 下行AC的分组关系
    ICRRBlockBankUL ulbBInfo;                   //2*1024       = 2KB 上行AC的分组关系

    L2dAcWgtR8DmaInfo AcWgtR8DmaInfo;          //权值的DMA信息，下行AC和上行AC公用1段地址，1KB，实际没有那么大，预留了很多，凑成1K

    A53R8AcDebugShareInfo  a53R8ShareInfo; //调试信息，1KB，实际没有那么大，预留了很多，凑成1K
    UlAcVgaData ulAcVgaData;//2KB的16轮迭代的的上行VGA采数结果
}IcAcShareMemInfo;

typedef struct ULROUNDANTSELInfo
{
    UINT32 ant[AC_UL_ANTS_NUM];
}ULROUNDANTSELInfo;

typedef struct DLROUNDANTSEL
{
    UINT32 ant[AC_ROUND_NUM][AC_DL_ANTS_NUM];
}DLROUNDANTSEL;

typedef struct ACBLOCKBANKNEEDINFO
{
    DLROUNDANTSEL dlAcRoundAntSel[AC_IC_NUM];//下行天线选择信息
    ULROUNDANTSELInfo ulAcRoundAntSel[AC_IC_NUM];//上行天线选择信息
}ACBLOCKBANKNEEDINFO;

typedef struct _T_AC_CHN_MAP_
{
    UINT32 linkInfo[4];
} T_AC_CHN_MAP;

enum _AC_MAP_DEF_
{
    AC_RFCHN = 0,     /* 射频通道 */
    AC_DIFCHIPID,     /* 中频芯片id */
    AC_ANTID,         /* 天线号 */
    AC_ANTCHN,        /* 频段*/
    MAP_INFO_NUM
};

enum
{
    AC_BAND_0 = 0,
    AC_BAND_1,
    AC_BAND_2
};
typedef enum
{
    E_CORE_INT_DL_AC_CATCH_DATA_INDEX       = 0x0100,//下行AC时的采数结果
    E_CORE_INT_UL_AC_CATCH_DATA_INDEX       = 0x0101,//上行AC时的采数结果
    E_CORE_INT_DL_BANKS_AXIS_DMA_DATA_INDEX = 0x0102,//从dlbank写序列的地方，用DMA方式把序列搬到DDR
    E_CORE_INT_DL_AC_BLOCK_BANK_INFO_INDEX  = 0x0103,//存放下行AC每轮的block和bank信息（也即天线分组信息）
    E_CORE_INT_UL_AC_BLOCK_BANK_INFO_INDEX  = 0x0104,//存放上行AC每轮的block和bank信息（也即天线分组信息）
    E_CORE_INT_AC_WGT_DMA_INFO_INDEX        = 0x0105,//存放上行或者下行AC的权值进行DMA的源地址、目的地址、长度等信息
    /*************************************
    存放调试和维测信息
    1，AC序列生效的psync无线帧时刻，即无线帧号
    2，AC权值生效的psync无线帧时刻，即无线帧号
    3，。。。预留
    *************************************/
    E_CORE_INT_AC_DEBUG_SHARE_INFO_INDEX    = 0x0106,
    E_CORE_INT_UL_AC_VGA_DATA_INDEX         = 0x0107,
    E_CORE_INT_PHASE_DIFF_SEQ_DATA_INDEX    = 0x0108,
    E_CORE_INT_UPDAT_ACCA_PHASE_COMPVAL     = 0x0109,
    E_CORE_INT_DL_AC_CATCH_DATA_MAX         = 0x010a,
    E_CORE_INT_CATCH_RAM_BLOCK_INDEX        = 0x010b,
    E_CORE_INT_VSWR_RAM_BLOCK_INDEX         = 0x010c
}E_A53_R8_CORE_INT_INDEX;

VOID   BspSetBandNo(UINT32 inPut);
UINT32 BspGetBandNo(VOID);
UINT32 IcHalSetBoardInfoInit(IcHalAcBoardInfo* data);
UINT32 IcHalInitUlBank(VOID);//静态上电写死
UINT32 IcHalInitDlBank(VOID);//静态上电写死
UINT32 BspGetAntNoByRoundInfo(UINT32 rpuId, UINT32 round);
UINT32 BspAcChanMapInfoInit(const T_AC_CHN_MAP *pLinkMap, UINT32 linkNum);
UINT32 BspSetAcFreqBandId(UINT32 FreqId);
UINT32 BspGetAcFreqBandId(VOID);
UINT32 IcHalAcInsrtDataWrRam(UINT32 acType, UINT32 *seq, UINT32 dataLen,UINT32 length,UINT32 radioMode,UINT32 carrNo);
UINT32 IcHalDlSetUlBankCatchRamRoundCfg(UINT32 ic, A53R8AcDebugShareInfo* a53R8ShareInfo);
UINT32 IcHalInitAntSelInfo(ACBLOCKBANKNEEDINFO* acBlockBankNeedInfo);
UINT32 BspInitAcCfgPara(T_ICHAL_ACPARA* acCfgPara);
UINT32 IcHalUlSetUlBankCatchRamRoundCfg(UINT32 ic, A53R8AcDebugShareInfo* a53R8ShareInfo);
UINT32 GetdGp2Ac(UINT32 acType, UINT32 radio,DOUBLE* Gp2Ac);
UINT32 GetdGp2AcEnd(UINT32 acType, UINT32 radio, DOUBLE* Gp2AcEnd);
UINT32 SetGp2Ac(UINT32 val);
UINT32 BspGp2Ac(UINT32 acType, UINT32 radio, UINT32 carrNo,DOUBLE* Gp2Ac);
UINT32 BspGp2AcEnd(UINT32 acType, UINT32 radio,UINT32 carrNo, DOUBLE* Gp2AcEnd);
UINT32 BspGetAcEndInsert0Num(UINT32 acType,UINT32 radioMode,UINT32 carrNo,UINT32 bw,UINT32 pasteCarrFlag);
UINT32 BspGetAcInsertDelay(UINT32 acType, UINT32 radio, UINT32 carrNo,UINT32 gpNum,UINT32 bw,UINT32 pasteCarrFlag);
UINT32 acReduceRankAntSel(A53R8AcDebugShareInfo* shareInfo, UINT32 refChn, UINT32 radioMode);
UINT32 getCoupleChanRpuId(UINT32* calcChnIcNo, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetBlockBankInfo(UINT32 radioMode, UINT32 carrNo,UINT32 dataOffset, UINT32 acType, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetAcInsertData(UINT32 acSeqLen, UINT32 acCpLen);
UINT32 IcHalSetDlInsertFrontDelayPoint(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 pasteCarrFlag,UINT32 bandWidth,UINT32 acGpNum);
UINT32 IcHalSetUlBankAllBlockCatchRamEnOff(VOID);
UINT32 IcHalCompensateUlBankCatchRamWaitDelayPoint(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 pasteCarrFlag,UINT32 bandWidth,UINT32 acGpNum);
VOID   IcHalUlAcRoundCfg(UINT32 ic, UINT32 round);
UINT32 IcHalSetDlBankAcSequenceInsertRoundCfg(UINT32 ic, UINT32 round);
UINT32 IcHalSetUlBankCatchRamClearAllInts(VOID);
UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag);
UINT32 IcHalCopyBlockBankInfoToShareMem();
UINT32 IcHalSetDlbankAcInsertPos(UINT32 acInsertPos);
UINT32 IcHalSetTddFlgDly(UINT32 radioMode, UINT32 carrNo,UINT32 acInsertPos);
T_ICHAL_ACPARA* getAcParaAddr(VOID);
FLOAT IcHalGetDLFrameDly(UINT32 uiCalAntNum, UINT32 uiCarrNo, UINT32 uiRadioMode);
UINT32 IcHalDmaMoveDataFromUlBankCatchRamToDdrShareMem(UINT32 round,UINT32 actype);
UINT32 BspSetAcInslotIoCtrl(UINT32 acType,UINT32 radioMode,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo);
UINT32 IcHalSetFddAcRamPara(UINT32 seqLen,UINT32 cpLen,T_ICHAL_ACPARA* acPara,UINT32 acType,UINT32 radioMode);
UINT32 IcHalSetFddUlCatchCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn, T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara);
UINT32 IcHalSetFddUlInsertCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn,
                                  T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetFddDlCatchCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo,
                                 UINT32 refChn, T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetFddDlInsertCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn,
                                  T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara);
UINT32 IcHalFddSetFrPara(T_ICHAL_ACPARA* acPara, UINT32 frameNo);
UINT32 IcHalAcSetDlGpEn(UINT32 acType, UINT32 carrNo, UINT32 radioMode);
UINT32 IcHalSetAcRamPara(UINT32 seqLen,UINT32 cpLen);
UINT32 IcHalSetFrPara(UINT32 acType,T_ICHAL_ACPARA* acPara);
UINT32 ICHalSetUlbankAcDataRouterCfg(UINT32 acCatchDataPos);
UINT32 IcHalSetAcOrAAcMode(UINT32 Mode);
UINT32 IcHalGetFrameTypeForAc(UINT32 uCarrNo,UINT32 radioMode);
UINT32 GetAcInsertPos(VOID);
UINT32 GetAcCatchDataPos(VOID);
UINT32 acCatchDataChnInfo(A53R8AcDebugShareInfo* shareInfo, UINT32 radioMode);
UINT32 BspAcKoInit(VOID);
UINT32 BspSetAcSwitchAntMask(UINT32 acType, T_ICHAL_ACPARA* acPara);
UINT32 BspRestAcInt(VOID);
void BspSetBbuSuperFrameNo(UINT32 frameNo);
UINT32 BspCopyOutOfPsyncParaToKo(UINT32 radioMode);
UINT32 BspGetAcNetMode(VOID);
UINT32 BspGetIfType(A53R8AcDebugShareInfo* shareInfo, UINT32 radioMode,UINT32 CarrId,UINT32 *uiIfType);
UINT32 BspGetAntNoByDlAcRoundAntSel(UINT32 round, UINT32 rpuId, UINT32 array);
UINT32 BspGetBandCatchChn(VOID);
UINT32 BspGetRfChnbyAntNum(UINT32 uiAntNo, UINT32 uiBandNo, UINT32 dir);
UINT32 BspGetBandSendChn(UINT32 uiBandNo);
UINT32 IcHalSetDlbankFddFrameNo(UINT32 uiFrameIdEn, UINT32 uiFrameNo, UINT32 uiAntId);
UINT32 IcHalSetUlbankFddFrameNo(UINT32 uiFrameIdEn, UINT32 uiFrameNo, UINT32 uiAntId);
UINT32 IcHalSetDlBankAcInsertSequenceGain(UINT32 block,UINT32 seqGain);
UINT32 acGetRpuIdByBandNo(UINT32 uiBandNo, UINT32 uiRpuId);
UINT32 SetUlBankWaitDelay(UINT32 bandWidth, UINT32 delay);

#ifdef _AC_PRINTF_EN_
#define acprintf(fmt,...)     printf(fmt,##__VA_ARGS__)
#define acprintfEx(fmt,...)   dbgInfoEx(fmt,##__VA_ARGS__)
#else
#define acprintf(fmt,...)
#define acprintfEx(fmt,...)
#endif

#ifdef __cplusplus
}
#endif
#endif

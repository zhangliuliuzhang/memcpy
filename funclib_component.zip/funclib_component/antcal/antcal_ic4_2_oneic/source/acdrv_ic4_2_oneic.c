#include "bsppub.h"
#include "bspcomm.h"
#include "acdrv_ic4_2_oneic.h"
#include "acreg_ic4_2_oneic.h"
#include "icopthalcomm.h"
#include "ichaladaptbspapi.h"
#include "chnmap_a.h"
#include "cellcfgapi.h"
#include "ac_api.h"
#include "antcalapi.h"
#include "antcal_ic4_2_oneic.h"
#include "vgactrl_api.h"
#include "tdd_cfg.h"
#include "tdd_api.h"
#include "ac_ext_api.h"
#include "resource_alloc_info.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "io_api.h"
#include "antcalcommon.h"
#include "psyncdrv.h"
#include "dlyapi.h"

typedef enum
{
    AC_TDD_CATCH   = 0,
    AC_FDD_CATCH   = 1
}AC_TDD_FDD;
typedef enum
{
    AC_GP_ID_CATCH = 0,
    AC_FRAME_CATCH = 1
}AC_GPID_FRAME;

/*
Ulbank RAM BaseAddr = 0xcb210000;
any RAM addr        = BaseAddr + block*0x00020000 + ram*0x00004000;
16 UlBank Block, 2 RAM/block, Block offset=0x0002_0000, RAM offset=0x0000_4000 */
#define AC_UL_BANK_CATCH_RAM_BLOCK0_RAM0_PHY_ADDR 0xcb210000
#define ULBANK_AC_BLOCK_OFFSET                    0x00020000
#define ULBANK_AC_RAM_OFFSET                      0x00004000

/*
Dlbank RAM BaseAddr = 0xcca14000;
any RAM addr        = BaseAddr + block*0x00020000 + ram*0x00001000;
16 DlBank Block, 2 RAM/block, Block offset=0x0002_0000, RAM offset=0x0000_1000 */
#define AC_DL_BANK_INSERT_RAM_BLOCK0_RAM0_PHY_ADDR 0xcca14000
#define DLBANK_AC_BLOCK_OFFSET                     0x00020000
#define DLBANK_AC_RAM_OFFSET                       0x00001000
#define MAX_OUTOFSYNC_ANT_NUM          (8)

//初始化:起始地址/GP/TDD等信息[A53上做]
UINT32 frontDelay = 1;//非0即可
UINT32 front0Num  = 10;//任意值
UINT32 IcHalCatchUlBankRamCnt[8] = {0};
UINT32 IcHalCatchUlBankRamTickCnt = 0;
DLROUNDANTSEL dlAcRoundAntSel[AC_IC_NUM] ={0};
DLROUNDANTSEL dlAcRoundAntSelTmp[AC_IC_NUM] ={0};
ULROUNDANTSELInfo ulAcRoundAntSel[AC_IC_NUM] ={0};

DLROUNDANTSEL dlAcRoundAntSel_another[AC_IC_NUM] ={0};
ULROUNDANTSELInfo ulAcRoundAntSel_another[AC_IC_NUM] ={0};
DLROUNDANTSEL dlAcRoundAntSelTmp_another[AC_IC_NUM] ={0};

ICRRBlockBankDL dlAcBlockBankBandInfo[AC_IC_NUM] = {0};//2片IC
ICRRBlockBankUL ulAcBlockBankBandInfo[AC_IC_NUM] = {0};//2片IC

UINT32 pulseModeData[acPulseDataLen] = {0};
UINT32 IcHalShowAcSeqDmaInfoData[1024] = {0};
UINT32 s_recordCurrentRoundIndex = 0;
UINT32 s_selectAcSequence        = 0;//默认发序列
UINT32 s_acPulseDataVal   = 0x10000;
UINT32 s_acSeqTestFlag = 0;
UINT32 s_acDrvVerId = 0;
UINT32 s_acEpldGpNum = 0;
UINT32 s_acFreqBandId = 0;
INT8 avgTaDl   = 0;
INT8 avgTaUl   = 0;
IcHalAcBoardInfo s_acDrvBoard = {0};
T_ICHAL_ACPARA IcHalAcCfgPara = {0};
const T_AC_CHN_MAP* s_acChnMapInfo  = NULL;
UINT32 s_acChnMapNum   = 0;
UINT32 g_acCatchDataPos = 0; //0：rcf后
UINT32 g_acInsertPos = 0; //0表示drcf前
static UINT32 s_bbuSuperFrameNo = 0;
/* 转给中频的IO时序数据 */
T_BspHalAdaptUtDlIoPara s_bspIoDlCfg[MAX_OUTOFSYNC_ANT_NUM] = {0};
T_BspHalAdaptUtUlIoPara s_bspIoUlCfg[MAX_OUTOFSYNC_ANT_NUM] = {0};
extern T_AcCarrCfgNxp g_acCarrCfgNxp;

T_ICHAL_ACPARA* getAcParaAddr(VOID)
{   
    return &(IcHalAcCfgPara);
}

void SetAcInsertPos(UINT32 inPut)
{
	g_acInsertPos = inPut;
}

UINT32 GetAcInsertPos()
{
	return g_acInsertPos;
}

void BspSetBandNo(UINT32 inPut)
{
    g_acCarrCfgNxp.bandNo = inPut;
}

UINT32 BspGetBandNo(VOID)
{
    return g_acCarrCfgNxp.bandNo;
}

void SetAcCatchDataPos(UINT32 inPut)
{
	g_acCatchDataPos = inPut;
}

UINT32 GetAcCatchDataPos()
{
	return g_acCatchDataPos;
}

//获取所做载波频段的校准通道
UINT32 BspGetBandSendChn(UINT32 uiBandNo)
{
    UINT32 uiSendChn        = 0;
    T_ICHAL_ACPARA* acPara  = NULL;

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    dbgInfoEx("[%s] uiBandNo:%d\n", __FUNCTION__, uiBandNo);
    switch(uiBandNo)
    {
        case AC_BAND_0:
        {
            uiSendChn = acPara->acSendChnBand0;
            break;
        }
        case AC_BAND_1:
        {
            uiSendChn = acPara->acSendChnBand1;
            break;
        }
        case AC_BAND_2:
        {
            uiSendChn = acPara->acSendChnBand2;
            break;
        }
        default:
        {
            dbgInfo("[%s] unknown Band No:%d", __FUNCTION__, uiBandNo);
            break;
        }
    }

    return uiSendChn;
}


//获取所做载波频段的耦合通道
UINT32 BspGetBandCatchChn(VOID)
{
    UINT32 uiBandNo          = 0;
    UINT32 uiCatchChn        = 0;
    T_ICHAL_ACPARA* acPara   = NULL;

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    dbgInfoEx("[%s] uiBandNo:%d\n", __FUNCTION__, uiBandNo);
    switch(uiBandNo)
    {
        case AC_BAND_0:
        {
            uiCatchChn = acPara->acCatchChnBand0;
            break;
        }
        case AC_BAND_1:
        {
            uiCatchChn = acPara->acCatchChnBand1;
            break;
        }
        case AC_BAND_2:
        {
            uiCatchChn = acPara->acCatchChnBand2;
            break;
        }
        default:
        {
            dbgInfo("[%s] unknown Band No:%d", __FUNCTION__, uiBandNo);
            break;
        }
    }

    return uiCatchChn;
}

UINT32 IcHalShowBoardInfo(VOID)
{
    acprintf("s_acDrvBoard.shareMemPhyAddrBase         = 0x%08X\n", s_acDrvBoard.shareMemPhyAddrBase);//物理首地址
    acprintf("s_acDrvBoard.shareMemVirAddrBase         = 0x%08X\n", s_acDrvBoard.shareMemVirAddrBase);//虚拟首地址
    acprintf("s_acDrvBoard.shareMemAllSize             = 0x%08X\n\n", s_acDrvBoard.shareMemAllSize);  //共享空间总大小

    //存放用于下行校正的ulBank采数，需要区分不同的RAM
    acprintf("s_acDrvBoard.dlAcUlBankCatchAddrOffset   = 0x%08X\n", s_acDrvBoard.dlAcUlBankCatchAddrOffset);
    //存放用于上行校正的ulBank采数，需要区分不同的RAM
    acprintf("s_acDrvBoard.ulAcUlBankCatchAddrOffset   = 0x%08X\n\n", s_acDrvBoard.ulAcUlBankCatchAddrOffset);

    //存放4个dlBank Axis写序列的地址，用于维测回读用
    acprintf("s_acDrvBoard.dlBank0AxisDmaAddrOffset    = 0x%08X\n\n", s_acDrvBoard.dlBank0AxisDmaAddrOffset);

    //存放下行AC的block和bank信息的地址，要传给R8
    acprintf("s_acDrvBoard.dlAcBlockBankInfoAddrOffset = 0x%08X\n", s_acDrvBoard.dlAcBlockBankInfoAddrOffset);  
    //存放上行AC的block和bank信息的地址，要传给R8
    acprintf("s_acDrvBoard.ulAcBlockBankInfoAddrOffset = 0x%08X\n\n", s_acDrvBoard.ulAcBlockBankInfoAddrOffset);  

    //存放下行和上行AC的权值信息的地址，要传给R8
    acprintf("s_acDrvBoard.AcWgtDmaInfoAddrOffset      = 0x%08X\n", s_acDrvBoard.AcWgtDmaInfoAddrOffset);  

    //存放A53-R8调试信息的地址，要传给R8
    acprintf("s_acDrvBoard.a53R8DebugInfoAddrOffset      = 0x%08X\n", s_acDrvBoard.a53R8DebugInfoAddrOffset);  

    //存放从ulbank获取的vga的系数的地址
    acprintf("s_acDrvBoard.vgaDataAddrOffset      = 0x%08X\n", s_acDrvBoard.vgaDataAddrOffset);  

    //存放残余相差模式下16通道序列数据的地址
    acprintf("s_acDrvBoard.phaDiffSeqAddrOffset        = 0x%08X\n", s_acDrvBoard.phaDiffSeqAddrOffset); 
    //存放残余相差模式下,存放4个dlBank Axis写序列的地址，用于维测回读用
    acprintf("s_acDrvBoard.phaDiffSeqAddrOffset        = 0x%08X\n", s_acDrvBoard.phaDiffAxisDmaAddrOffset); 

    //存放驻波计算参数
    acprintf("s_acDrvBoard.VswrBlockBankOffset        = 0x%08X\n", s_acDrvBoard.VswrBlockBankOffset);


    return BSP_OK;
}

UINT32 BspSetAcFreqBandId(UINT32 FreqId)
{
    s_acFreqBandId = FreqId;
    return BSP_OK;
}

UINT32 BspGetAcFreqBandId(VOID)
{
    return s_acFreqBandId;
}

UINT32 BspInitAcCfgPara(T_ICHAL_ACPARA* acCfgPara)
{
    INPUT_POINTER_CHECK(acCfgPara)
    memcpy_s((VOID*)&IcHalAcCfgPara, sizeof(T_ICHAL_ACPARA), (VOID*)acCfgPara, sizeof(T_ICHAL_ACPARA));

    return BSP_OK;
}

UINT32 IcHalClearShareMem(VOID)
{
    VOID * baseAddr  = s_acDrvBoard.shareMemVirAddrBase;
    UINT32 dataSize  = s_acDrvBoard.shareMemAllSize;//4MB字节

    memset(baseAddr, 0, dataSize);
    acprintf("Share Mem Size 0x%08X(Addr 0x%08X ~ Addr 0x%08X) was Cleared\n",
            dataSize, (UINT32)baseAddr, (UINT32)(baseAddr + dataSize));

    return BSP_OK;
}

VOID IcHalSetAcRoundCfgIndex(UINT32 ic, UINT32 round)
{
    s_recordCurrentRoundIndex = round;
}

UINT32 IcHalGetAcRoundCfgIndex(UINT32 ic)
{
    acprintf("\nCurrent Round Cfg Index = %d\n\n", s_recordCurrentRoundIndex);
    return s_recordCurrentRoundIndex;
}

VOID IcHalSetAcSequenceType(UINT32 type)
{
    s_selectAcSequence = type;
}

UINT32 IcHalGetAcSequenceType(VOID)
{
    const char * strings = (0 == s_selectAcSequence) ? "AcTestData":"AcPulse";
    dbgInfo("\nAc Sequence is %s\n\n", strings);
    return BSP_OK;
}

VOID IcHalSetAcPulseDataVal(UINT32 data)
{
    s_acPulseDataVal = data;
}

VOID IcHalSetAcSeqTestFlag(UINT32 flag)
{
    s_acSeqTestFlag = flag;
}

UINT32 IcHalGetAcSeqTestFlag(VOID)
{
    return s_acSeqTestFlag;
}

UINT32 IcHalSetPulseData(UINT32 acType, UINT32 dataOffset)
{
    UINT32 ic          = 0;
    UINT32 icMaxNum    = 0;
    UINT32 roundLoop   = 0;
    UINT32 roundNum    = 0;
    UINT32 antLoop     = 0;
    UINT32 antNum      = 0;
    UINT32 pulseOffset = 0;
    UINT32 antNoTmp    = 0;

    icMaxNum = IcHalAcCfgPara.icNum;
    roundNum = IcHalAcCfgPara.acDlRoundNo;
    antNum   = IcHalAcCfgPara.dlAntNum;

    memset_s(&pulseModeData[0], 64*1024*4, 0, 64*1024*4);
    if((dataOffset==0)||(dataOffset>128))
    {
        dataOffset = 128 ;
    }

    for(ic = 0; ic < icMaxNum; ic++)
    {
        for(roundLoop = 0;roundLoop < roundNum;roundLoop++)
        {
            for(antLoop = 0;antLoop < antNum;antLoop++)
            {
                antNoTmp = dlAcRoundAntSel[ic].ant[roundLoop][antLoop];
                if(antNoTmp!= 64)
                {
                    if(AC_TYPE_DL==acType)
                    {
                        pulseOffset = dataOffset * antLoop + antNoTmp * acDrvAcSeqPntCnt;
                    }
                    else
                    {
                        pulseOffset = antNoTmp * acDrvAcSeqPntCnt;
                    }
                    dbgInfoEx("antNoTmp=%d, pulseOffset=%d\n",antNoTmp,pulseOffset);
                    pulseModeData[pulseOffset] = s_acPulseDataVal;//0x2388000
                }
            }
        }
    }

    return BSP_OK;
}

//ads test  21/4/9
void memsetDlAcSeq()
{
    memset(acTxDrvAcSeqDataNr,0,acTxDrvAcSeqCnt*sizeof(UINT32));
}

void memsetUlAcSeq()
{
    memset(acRxDrvAcSeqDataNr,0,AC_DRV_SEQ_LEN*sizeof(UINT32));
}

//ac序列颠倒
void ArrayElemReverse(UINT32 *acSeq,UINT32 leftIndex,UINT32 rightIndex)
{
    UINT32 i = 0;
    UINT32 temp = 0;
    for(i = 0;i < (rightIndex - leftIndex + 1) / 2;i++)
    {
        temp = acSeq[leftIndex + i];
        acSeq[leftIndex + i] = acSeq[rightIndex - i];
        acSeq[rightIndex - i] = temp;
    }
}

UINT32 acSeqTemp[1024]  = {0,};
//ac打桩序列移位
void acSeqOffset(UINT32 radioMode)
{
    UINT32 antNum      = 0;
    UINT32 antNoTmp    = 0;
    UINT32 ic          = 0;
    UINT32 roundLoop   = 0;
    UINT32 roundNum    = 0;
    UINT32 antLoop     = 0;
    UINT32 dataLen     = 0;
    UINT32 dataoffset  = 0;
    UINT32 dataRightOffset = 0;
    UINT32 dataLeftOffset  = 0;
    roundNum = IcHalAcCfgPara.acDlRoundNo;
    antNum   = IcHalAcCfgPara.dlAntNum;
    ic = BspGetRpuId();

    if((RADIO_STANDARD_5G == radioMode) || (RADIO_STANDARD_FDD_5G == radioMode))
    {
        dataLen    = 1024;
        dataoffset = 128;
    }
    else
    {
        dataLen    = 512;
        dataoffset = 64;
    }

    for(roundLoop = 0; roundLoop < roundNum; roundLoop++)
    {
    	for(antLoop = 0; antLoop < antNum; antLoop++)
        {
            antNoTmp = dlAcRoundAntSel[ic].ant[roundLoop][antLoop];
            dbgInfoEx("[%s] roundLoop:%d, antLoop:%d, antNoTmp:%d \n", __FUNCTION__, roundLoop, antLoop, antNoTmp);
            if((RADIO_STANDARD_5G == radioMode) || (RADIO_STANDARD_FDD_5G == radioMode))
            {
                memcpy_s(acSeqTemp, dataLen * sizeof(UINT32), acTxDrvAcSeqDataNrTemp, dataLen * sizeof(UINT32));
            }
            else
            {
                memcpy_s(acSeqTemp, dataLen*sizeof(UINT32), acTxDrvAcSeqDataLteTemp, dataLen * sizeof(UINT32));
            }
            if(antNoTmp!= 64)
            {
                dataLeftOffset = dataoffset * antNoTmp;
                dataRightOffset = dataLen-dataLeftOffset;
                dbgInfoEx("[%s] dataRightOffset:%d, dataLeftOffset:%d\n", __FUNCTION__, dataRightOffset, dataLeftOffset);
                if(dataRightOffset != 0)
                {
                    ArrayElemReverse(acSeqTemp, 0,dataLeftOffset-1);
                    ArrayElemReverse(acSeqTemp, dataLeftOffset, dataLen-1);
                    ArrayElemReverse(acSeqTemp, 0, dataLen-1);
                }
                if(antNoTmp < 8)
                {
                    memcpy_s(acTxDrvAcSeqDataNr+(antNoTmp-ic*8) *1024, dataLen * sizeof(UINT32), acSeqTemp, dataLen * sizeof(UINT32));
                }
                else
                {
                    memcpy_s(acTxDrvAcSeqDataNr+(antNoTmp-(ic+1)*8) *1024, dataLen * sizeof(UINT32), acSeqTemp, dataLen * sizeof(UINT32));
                }
            }
        }
    }
}

UINT32 IcHalChangeAcSeqAddr(UINT32 acType, UINT32** seqcp,UINT32 radioMode)
{
    //AC DSP下发序列
    if(0 == IcHalGetAcSeqTestFlag()) 
    {
        return BSP_OK;
    }

    //AC打桩序列
    if(AC_TYPE_DL == acType)
    {
        acSeqOffset(radioMode);
        *seqcp = acTxDrvAcSeqDataNr;
    }
    else if(AC_TYPE_UL == acType)
    {
        *seqcp = acRxDrvAcSeqDataNr;
    }

    //恢复AC DSP下发序列
    IcHalSetAcSeqTestFlag(0);

    return BSP_OK;
}

UINT32 g_uiaAcDatasingle[acDrvAcSeqPntCnt] = {0};
UINT32 IcHalAcInsrtDataWrRam(UINT32 acType, UINT32 *seq, UINT32 dataLen, UINT32 length,UINT32 radioMode,UINT32 carrNo)
{
    UINT32 uiDifChn          = 0;
    UINT32 uiAntId           = 0;
    UINT32 uiAntNoTmp        = 0;
    UINT32 uiBlockId         = 0;
    UINT32 uiIcId            = 0;
    UINT32 uiSendChn         = 0;
    UINT32 uiBackUpSendChn   = 0;
    UINT32 *seqCopy          = seq;
    UINT32 uiBankId[16]      = {0};
    UINT32 uiBankNum         = 0;
    UINT32 uiRet             = 0;
    UINT32 uiBackUpRet       = 0;
    UINT32 uiNum             = 0;
    UINT32 uiBandNo          = 0;
    UINT32 uiDifChipId       = 0;
    UINT32 uiBackUpDifChipId  = 0;
    UINT32 uiSendDataDifChn  = 0;
    UINT32 uiBackUpSendDataDifChn = 0;
    UINT32 uiTempLength      = 0;
    UINT32 icMaxAntNo        = IcHalAcCfgPara.acIcMaxAntNo;
    UINT32 udTransSize       = 1024*4;//1024 data points, 4K, 0x00001000
    UINT32 uiStartAntId      =0; 
    
    INPUT_AC_ZERO_CHECK(icMaxAntNo);
    dbgInfo("[%s] acType:%d, radioMode:%d \n", __FUNCTION__, acType, radioMode);

    uiIcId = BspGetRpuId();
    udTransSize = sizeof(UINT32)*acDrvAcSeqPntCnt;
    uiSendChn = IcHalAcCfgPara.acSendDataChan + 1;
    uiBackUpSendChn = IcHalAcCfgPara.acBackUpSendDataChan + 1;
    uiStartAntId = IcHalAcCfgPara.acStartChan;

    uiRet = BspGetDifInfoByAntInfo(uiSendChn, uiBandNo, TX, &uiDifChipId, &uiSendDataDifChn);
    uiBackUpRet = BspGetDifInfoByAntInfo(uiBackUpSendChn, uiBandNo, TX, &uiBackUpDifChipId, &uiBackUpSendDataDifChn);
    RESULT_CHECK_AC_WITHOUT_HANDLE(uiRet);
    RESULT_CHECK_AC_WITHOUT_HANDLE(uiBackUpRet);

    IcHalChangeAcSeqAddr(acType, &seqCopy,radioMode);
    memset_s((VOID *)&g_uiaAcDatasingle[0], acDrvAcSeqPntCnt * sizeof(UINT32), 0, acDrvAcSeqPntCnt * sizeof(UINT32));

    for(uiAntId = uiStartAntId ;uiAntId < icMaxAntNo; uiAntId++)
    {
        uiAntNoTmp = BspGetAntNoByDlAcRoundAntSel(0, uiIcId, uiAntId);
        CHECK_AC_ANT_VALID(uiAntNoTmp);
        uiAntNoTmp = uiAntId + 1; //对应map表中的天线号列，需要加1
        uiRet = BspGetDifInfoByAntInfo(uiAntNoTmp, uiBandNo, TX, &uiDifChipId, &uiDifChn);
        RESULT_CHECK_CONTINUE(uiRet);
        if(AC_TYPE_UL == acType) 
        {           
            uiRet =(((BSP_OK == uiRet)&&(uiSendDataDifChn == uiDifChn)) || ((BSP_OK == uiBackUpRet)&&(uiBackUpSendDataDifChn == uiDifChn)));
            RESULT_CHECK_FALSE_CONTINUE_AC(uiRet);
        }

        uiRet = IcHalGetTxDuc1CarrBankIdByDifCarr(uiDifChn, carrNo, radioMode, &uiBankId[0], &uiBankNum);
        RESULT_CHECK_CONTINUE(uiRet);
        for(uiNum = 0;uiNum < uiBankNum;uiNum++)
        {
            dbgInfo("difChn=%d, uiBankId=%d, radioMode=%d,carrNo=%d\n", uiDifChn, uiBankId[uiNum], radioMode, carrNo);
        }
        if(0 == s_selectAcSequence)  //sequence
        {
            INPUT_POINTER_CHECK(seqCopy);
            if(AC_TYPE_DL == acType)
            {
                INPUT_AC_PARAMETER_CHECK(uiDifChn*udTransSize, length);
                memcpy_s((VOID*)&g_uiaAcDatasingle[0], udTransSize, (VOID*)(seqCopy + uiDifChn*acDrvAcSeqPntCnt), udTransSize);
            }
            else if(AC_TYPE_UL == acType)
            {
                memcpy_s((VOID*)&g_uiaAcDatasingle[0], udTransSize, (VOID*)(seqCopy), udTransSize);
            }
        }
        else  //pulse
        {
            uiTempLength = uiDifChn * acDrvAcSeqPntCnt + uiIcId * icMaxAntNo * acDrvAcSeqPntCnt;
            if (uiTempLength < acPulseDataLen)
            {
                memcpy_s((VOID*)&g_uiaAcDatasingle[0], udTransSize,(UINT8*)(pulseModeData + uiTempLength), udTransSize);
            }
        }

        IcHalApiSetRamSel(uiBlockId, uiDifChn, SWITCH_ON);
        if(BSP_OK != IcHalApiAcInsrtDataWrRam(uiBlockId, uiDifChn, &g_uiaAcDatasingle[0], dataLen))
        {
            dbgInfo("[%s] AcInsrtData ERROR \n",__FUNCTION__);
            IcHalApiSetRamSel(uiBlockId, uiDifChn, SWITCH_OFF);
            return BSP_ERROR;
        }
        IcHalApiSetRamSel(uiBlockId, uiDifChn, SWITCH_OFF);
    }

    return BSP_OK;
}

UINT32 IcHalSetBoardInfoInit(IcHalAcBoardInfo* data)
{
    UINT32 uiAntNum = 0;
    INPUT_POINTER_CHECK(data)
    memcpy_s((VOID*)&s_acDrvBoard, sizeof(IcHalAcBoardInfo), (VOID*)data, sizeof(IcHalAcBoardInfo));

    IcHalClearShareMem();

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        IcHalInitDlBank();
    }
    IcHalInitUlBank();

    return BSP_OK;
}

UINT32 IcHalInitDlAcAllBlockBankInfo(UINT32 carrNo, UINT32 radioMode)
{
    UINT32 ic           = BspGetRpuId();
    UINT32 round        = 0;
    UINT32 roundMax     = IcHalAcCfgPara.acDlRoundNo;
    UINT32 dlAnt        = 0;
    UINT32 dlAntMax     = IcHalAcCfgPara.dlAntNum;
    UINT32 difChipId    = 0;
    UINT32 difChan      = 0;
    UINT32 antNoTmp     = 0;
    UINT32 bandNo       = 0; //逻辑频段号,默认0
    UINT32 dlBankId[16] = {0};
    UINT32 ulBankId[16] = {0};
    UINT32 bankNum      = 0;
    UINT32 num          = 0;
    UINT32 uiRet        = 0;
    UINT32 uiAntStart   = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();

    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        uiAntStart = 4;
    }
    for(round = 0; round < roundMax; round++)
    {
        dbgInfoEx("\n**************** round %d, ic %d ****************\n",round,ic);
        for(dlAnt = uiAntStart; dlAnt < dlAntMax; dlAnt++)
        {
            INPUT_AC_PARAMETER_CHECK(ic, AC_IC_NUM);
            INPUT_AC_PARAMETER_CHECK(round, AC_ROUND_NUM);
            INPUT_AC_PARAMETER_CHECK(dlAnt, AC_DL_ANTS_NUM);
            antNoTmp = dlAcRoundAntSel[ic].ant[round][dlAnt];
            dbgInfoEx("[%s] antNoTmp:%d \n", __FUNCTION__, antNoTmp);
            if(64 != antNoTmp)
            {
                antNoTmp = antNoTmp + 1; //对应map表中的天线号列，需要加1
                uiRet = BspGetDifInfoByAntInfo(antNoTmp, bandNo, TX, &difChipId, &difChan);
                RESULT_CHECK_CONTINUE(uiRet);
                uiRet = IcHalGetTxDuc1CarrBankIdByDifCarr(difChan, carrNo, radioMode, &dlBankId[0], &bankNum);
                RESULT_CHECK_CONTINUE(uiRet);

                for(num = 0; num<bankNum; num++)
                {
                    dbgInfoEx("[%s] num=%d, dlBankId=%d \n", __FUNCTION__, num, dlBankId[num]);
                }
                dlAcBlockBankBandInfo[ic].bBInfo[round].dlBank[dlAnt]   = dlBankId[0];
                dlAcBlockBankBandInfo[ic].bBInfo[round].dlDifChn[dlAnt] = difChan;
                dlAcBlockBankBandInfo[ic].bBInfo[round].dlIsSet[dlAnt]  = 1;

                /*下面的前提是带射频环回*/
                uiRet = IcHalGetRxDdc1CarrBankIdByDifCarr(difChan, carrNo, radioMode, &ulBankId[0], &bankNum);
                RESULT_CHECK_CONTINUE(uiRet);

                for(num = 0; num<bankNum; num++)
                {
                    dbgInfoEx("[%s] num=%d, ulBankId=%d \n", __FUNCTION__, num, ulBankId[num]);
                }
                dlAcBlockBankBandInfo[ic].bBInfo[round].ulBank[dlAnt]     = ulBankId[0];
                dlAcBlockBankBandInfo[ic].bBInfo[round].ulDifChn[dlAnt]   = difChan;
                dlAcBlockBankBandInfo[ic].bBInfo[round].ulIsSet[dlAnt]    = 1;
            }
        }
    }

    return BSP_OK;
}

UINT32 IcHalInitUlAcAllBlockBankInfo(UINT32 carrNo, UINT32 radioMode, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 ic           = BspGetRpuId();
    UINT32 round        = 0;
    UINT32 dlAnt        = 0;
    UINT32 icMaxAntNo   = IcHalAcCfgPara.acIcMaxAntNo;
    UINT32 difChipId    = 0;
    UINT32 calcAnt      = 0;
    UINT32 difChan      = 0;
    UINT32 calcDifChan  = 0;
    UINT32 clk737Delay  = 0;
    UINT32 antNoTmp     = 0;
    UINT32 dlBankId[16] = {0};
    UINT32 ulBankId[16] = {0};
    UINT32 bankNum      = 0;
    UINT32 num          = 0;
    UINT32 uiACPosId    = 0;
    UINT32 uiRet        = 0;
    UINT32 uiAntStart   = 0;
    UINT32 uibandNo     = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();
    
    if(AC_CELL_SEPARATE_MODE == acCellSeparateMode)
    {
        if(separateBit == 0xf0)
        {
            uiAntStart = 4;
        }
        else if(separateBit == 0x0f)
        {
            icMaxAntNo = 4;
        }
    }

    calcAnt = shareInfo->acCatchDataChan + 1;//对应map表中的天线号列，需要加1
    uiACPosId = GetAcCatchDataPos();

    for(dlAnt = uiAntStart; dlAnt < icMaxAntNo; dlAnt++)
    {
        INPUT_AC_PARAMETER_CHECK(ic, AC_IC_NUM);
        INPUT_AC_PARAMETER_CHECK(round, 1);
        INPUT_AC_PARAMETER_CHECK(dlAnt, AC_UL_ANTS_NUM);
        antNoTmp = ulAcRoundAntSel[ic].ant[dlAnt];
        dbgInfoEx("[%s] antNoTmp:%d \n", __FUNCTION__, antNoTmp);
        if(64 != antNoTmp)
        {
            antNoTmp = antNoTmp + 1; //对应map表中的天线号列，需要加1
            uiRet = BspGetDifInfoByAntInfo(antNoTmp, uibandNo, RX, &difChipId, &difChan);
            RESULT_CHECK_CONTINUE(uiRet);

            if(ic == shareInfo->sendAcRpuId)
            {
                uiRet = BspGetDifInfoByAntInfo(calcAnt, uibandNo, TX, &difChipId, &calcDifChan);
                RESULT_CHECK_CONTINUE(uiRet);
                uiRet = IcHalGetTxDuc1CarrBankIdByDifCarr(calcDifChan, carrNo, radioMode, &dlBankId[0], &bankNum);
                RESULT_CHECK_CONTINUE(uiRet);
                for(num = 0; num<bankNum; num++)
                {
                    dbgInfoEx("[%s] ulAcBlockBankBandInfo calcDifChan:%d num=%d, dlBankId=%d \n", __FUNCTION__, calcDifChan, num, dlBankId[num]);
                }
                ulAcBlockBankBandInfo[ic].bBInfo[round].dlBank[dlAnt]   = dlBankId[0];
                ulAcBlockBankBandInfo[ic].bBInfo[round].dlDifChn[dlAnt] = calcDifChan;
                ulAcBlockBankBandInfo[ic].bBInfo[round].dlIsSet[dlAnt]  = 1;
                dbgInfoEx("[%s] ulAcBlockBankBandInfo dlAnt:%d, calcAnt:%d, calcDifChan:%d, dlBankId:%d \n", __FUNCTION__, dlAnt, calcAnt, calcDifChan, dlBankId[0]);
            }

            /*下面的前提是带射频环回*/
            uiRet = IcHalGetRxDdc1CarrBankIdByDifCarr(difChan, carrNo, radioMode, &ulBankId[0], &bankNum);
            RESULT_CHECK_CONTINUE(uiRet);
            for(num = 0; num<bankNum; num++)
            {
                dbgInfoEx("[%s] ulAcBlockBankBandInfo num=%d, ulBankId=%d \n", __FUNCTION__, num, ulBankId[num]);
            }
            ulAcBlockBankBandInfo[ic].bBInfo[round].ulBank[dlAnt]           = ulBankId[0];
            ulAcBlockBankBandInfo[ic].bBInfo[round].ulVgaChn[dlAnt]         = difChan;
            IcHalApiGetVgaCompDlyToAC(difChan, carrNo, radioMode, uiACPosId, &clk737Delay);
            ulAcBlockBankBandInfo[ic].bBInfo[round].ulVgaDelay[dlAnt]       = clk737Delay;
            ulAcBlockBankBandInfo[ic].bBInfo[round].ulDifChn[dlAnt]         = difChan;
            ulAcBlockBankBandInfo[ic].bBInfo[round].ulIsSet[dlAnt]          = 1;
            dbgInfoEx("[%s] ulAcBlockBankBandInfo dlAnt:%d, antNoTmp:%d, difChan:%d, ulBankId:%d, ulVgaDelay:%d \n",
                    __FUNCTION__, dlAnt, antNoTmp, difChan, ulBankId[0], clk737Delay);
        }
    }

    return BSP_OK;
}

UINT32 BspGetIcNoByRefChn(UINT32 refChn, UINT32 radioMode)
{
    UINT32 loop  = 0;
    UINT32 icMax = IcHalAcCfgPara.icNum;
    UINT32 round = 0;
    UINT32 roundMax = IcHalAcCfgPara.acDlRoundNo;
    UINT32 dlAnt = 0;
    UINT32 dlAntMax = IcHalAcCfgPara.dlAntNum;
    UINT32 antNoTmp = 0;

    if(refChn >= 64)
    {
        dbgErr("refChnNo Error !!!\n");
        return AC_IC_NUM;
    }
    for (loop = 0; loop < icMax; loop++)
    {
        for (round = 0; round <roundMax; round++)
        {
            for (dlAnt = 0; dlAnt<dlAntMax; dlAnt++)
            {
                antNoTmp = dlAcRoundAntSel[loop].ant[round][dlAnt];

                if (refChn == antNoTmp)
                {
                    return loop;
                }
            }
        }
    }

    return AC_IC_NUM;
}

UINT32 acReduceRankAntSelIc0(UINT32 refChn)
{
    UINT32 maxRoundNo = IcHalAcCfgPara.acDlRoundNo;
    UINT32 maxAntNo   = IcHalAcCfgPara.dlAntNum;
    UINT32 maxIcNo    = IcHalAcCfgPara.icNum;
    UINT32 icNo       = 0;
    UINT32 roundNo    = 0;
    UINT32 antNo      = 0;
    UINT32 originalRefChn = 0;

    //恢复默认分组关系
    memcpy_s((VOID*)&dlAcRoundAntSel[0],AC_IC_NUM*sizeof(DLROUNDANTSEL),(VOID*)&dlAcRoundAntSelTmp[0],AC_IC_NUM*sizeof(DLROUNDANTSEL));
    
    for(icNo = 0; icNo < maxIcNo ; icNo++)
    {
        for(roundNo = 0; roundNo < maxRoundNo ; roundNo++)
        {
            for(antNo = 0; antNo < maxAntNo ; antNo++)
            {                          
                //1、用0通道替换参考通道，然后0通道降秩
                if(refChn == dlAcRoundAntSel[icNo].ant[roundNo][antNo])
                {
                    dlAcRoundAntSel[icNo].ant[roundNo][antNo] = originalRefChn;
                }
            }
            //2、用参考通道替代0通道  
            dlAcRoundAntSel[0].ant[roundNo][0] = refChn;
        }
    }
    
    return BSP_OK;
}

UINT32 acReduceRankAntSelIc1(UINT32 refChn)
{
    UINT32 maxRoundNo = IcHalAcCfgPara.acDlRoundNo;
    UINT32 maxAntNo   = IcHalAcCfgPara.dlAntNum;
    UINT32 maxIcNo    = IcHalAcCfgPara.icNum;
    UINT32 icNo    = 0;
    UINT32 roundNo = 0;
    UINT32 antNo   = 0;
    UINT32 refChnIcNo = 0;
    UINT32 refChnroundNo = 0;
    UINT32 refChnantNo = 0;
    UINT32 originalRefChn = 0;

    //清告警
    if(refChn > 63)
    {
        dbgErr("refChnNo Error !!!\n");
        return BSP_ERROR;
    }

    //恢复默认分组关系
    memcpy_s((VOID*)&dlAcRoundAntSel[0],AC_IC_NUM*sizeof(DLROUNDANTSEL),(VOID*)&dlAcRoundAntSelTmp[0],AC_IC_NUM*sizeof(DLROUNDANTSEL));
    
    for(icNo = 0; icNo < maxIcNo ; icNo++)
    {
        for(roundNo = 0; roundNo < maxRoundNo ; roundNo++)
        {
            for(antNo = 0; antNo < maxAntNo ; antNo++)
            {                          
                if(refChn == dlAcRoundAntSel[icNo].ant[roundNo][antNo])
                {
                    refChnIcNo    = icNo;
                    refChnroundNo = roundNo;
                    refChnantNo   = antNo;
                    dbgInfoEx("refChnIcNo:%d refChnroundNo: %d refChnantNo: %d\n",refChnIcNo,refChnroundNo,refChnantNo);
                }
            }
        }
    }

    for(roundNo = 0; roundNo < maxRoundNo ; roundNo++)
    {
        //1、把之前的0通道置为64
        dlAcRoundAntSel[0].ant[roundNo][0] = 64;
        //2、用refChn通道作为参考通道
        dlAcRoundAntSel[refChnIcNo].ant[roundNo][0] = refChn;
    }
    
    //3、refChn置为64;ref所在round 选中TX0
    dlAcRoundAntSel[refChnIcNo].ant[refChnroundNo][refChnantNo] = 64;
    //4、原来参考通道挪到新参考通道refChn的位置refChnantNo
    dlAcRoundAntSel[0].ant[refChnroundNo][refChnantNo]          = originalRefChn;

    return BSP_OK;
}

UINT32 acReduceRankAdjDataOffset(UINT32 refChn,UINT32 radioMode)
{
    UINT32 icNo  = 0;
    UINT32 icMax = IcHalAcCfgPara.icNum;
    UINT32 round = 0;
    UINT32 roundMax = IcHalAcCfgPara.acDlRoundNo;
    UINT32 dlAnt = 0;
    UINT32 dlAntMax = IcHalAcCfgPara.dlAntNum;
    UINT32 firstAntIcNo = 0;
    UINT32 firstAntNo = 0;
    UINT32 firstAntCnt = 0;
    UINT32 refIcNo = 0;
    UINT32 antNoTmp = 0;

    refIcNo = BspGetIcNoByRefChn(refChn,radioMode);

    if((refIcNo == 0) || (refIcNo == AC_IC_NUM))
    {
        return BSP_OK;
    }
    
    for(round = 0; round < roundMax; round++)
    {
        for(icNo = 0; icNo < icMax; icNo++)
        {
            for(dlAnt = 0; dlAnt < dlAntMax; dlAnt++)
            {
                antNoTmp = dlAcRoundAntSel[icNo].ant[round][dlAnt];

                //索引每个round第一个有效的通道信息
                if((64 != antNoTmp)&&(0 == firstAntCnt))
                {  
                    firstAntIcNo  = icNo;
                    firstAntNo = dlAnt;
                    firstAntCnt++;
                    dbgInfoEx("round : %d firstAntIcNo: %d firstAntNo :%d \n",round,firstAntIcNo,firstAntNo);
                }
            }
        }
        
        firstAntCnt = 0;
        acprintfEx("ICNo: %d roundNo :%d AntNo %d \n",refIcNo,round,dlAntMax-1);
    }

    return BSP_OK;
}


/* Started by AICoder, pid:b3786wdc1e98a241495f091c2076c61cce37dbb5 */
UINT32 acGetRpuIdByBandNo(UINT32 uiBandNo, UINT32 uiRpuId)
{
    UINT32 uiValidRpuId = 0;

    if (0 == uiBandNo)
    {
        // 如果uiBandNo为0，取uiRpuId的低8位
        uiValidRpuId = uiRpuId & 0x00ff;
    }
    else
    {
        // 否则，取uiRpuId的高8位并右移8位
        uiValidRpuId = (uiRpuId & 0xff00) >> 8;
    }

    return uiValidRpuId;
}
/* Ended by AICoder, pid:b3786wdc1e98a241495f091c2076c61cce37dbb5 */

UINT32 acCatchDataChnInfo(A53R8AcDebugShareInfo* shareInfo, UINT32 radioMode)
{
    UINT32 uiDlCatchChn  = 0;
    UINT32 uiUlSendChn   = 0;
    UINT32 uiCatchDifChn = 0;
    UINT32 uiSendDifChn  = 0;
    UINT32 uiRet         = 0;
    UINT32 uiDifChip     = 0;
    UINT32 uiRpuId       = BspGetRpuId();
    UINT32 uiBandNo      = 0;

    if(uiRpuId == shareInfo->catchAcRpuId)
    {
        uiDlCatchChn = shareInfo->acCatchDataChan + 1;//对应map表中的天线号列，需要加1
        uiRet = BspGetDifInfoByAntInfo(uiDlCatchChn, uiBandNo, RX, &uiDifChip, &uiCatchDifChn);
        RETURN_RESULT_CHECK(uiRet);
        shareInfo->dlCatchDifChn = uiCatchDifChn;
    }
    else
    {
        dbgInfo("[%s] This is not the catch IC\n", __FUNCTION__);
    }

    if(uiRpuId == shareInfo->sendAcRpuId)
    {
        uiUlSendChn = shareInfo->acSendDataChan + 1;//对应map表中的天线号列，需要加1
        uiRet = BspGetDifInfoByAntInfo(uiUlSendChn, uiBandNo, TX, &uiDifChip, &uiSendDifChn);
        RETURN_RESULT_CHECK(uiRet);
        shareInfo->ulSendDifChn = uiSendDifChn;
    }
    else
    {
        dbgInfo("[%s] This is not the send IC\n", __FUNCTION__);
    }

    return uiRet;
}

UINT32 showAntSel(VOID)
{
    UINT32 icNo    = 0;
    UINT32 roundNo = 0;
    UINT32 antNo   = 0;
    UINT32 icMax   = IcHalAcCfgPara.icNum;

    for(icNo = 0; icNo < icMax; icNo++)
    {
        acprintf("------->IC %d -------\n",icNo);
        for(roundNo = 0; roundNo < AC_ROUND_NUM; roundNo++)
        {
            for(antNo = 0; antNo < AC_DL_ANTS_NUM; antNo++)
            { 
                acprintf(" %2d",dlAcRoundAntSel[icNo].ant[roundNo][antNo]);                
            }
            acprintf("\n");
        }  
    }    

    return BSP_OK;
}

UINT32 showAntSelElse(VOID)
{
    UINT32 icNo    = 0;
    UINT32 roundNo = 0;
    UINT32 antNo   = 0;
    UINT32 icMax   = IcHalAcCfgPara.icNum;

    for(icNo = 0; icNo < icMax; icNo++)
    {
        acprintf("------->IC %d -------\n",icNo);
        for(roundNo = 0; roundNo < AC_ROUND_NUM; roundNo++)
        {
            for(antNo = 0; antNo < AC_DL_ANTS_NUM; antNo++)
            { 
                acprintf(" %2d",dlAcRoundAntSel_another[icNo].ant[roundNo][antNo]);
            }
            acprintf("\n");
        }  
    }    

    return BSP_OK;
}

UINT32 IcHalGetIcNumAndAnt(UINT32 *pIcNum, UINT32 *pDlAntNum)
{
    *pIcNum = IcHalAcCfgPara.icNum;
    *pDlAntNum = IcHalAcCfgPara.dlAntNum;
    return BSP_OK;
}

UINT32 IcHalInitAntSelInfo(ACBLOCKBANKNEEDINFO* acBlockBankNeedInfo)
{
    memcpy_s((VOID*)&dlAcRoundAntSel[0], AC_IC_NUM*sizeof(DLROUNDANTSEL), (VOID*)&(acBlockBankNeedInfo->dlAcRoundAntSel), AC_IC_NUM*sizeof(DLROUNDANTSEL));
    memcpy_s((VOID*)&ulAcRoundAntSel[0], AC_IC_NUM*sizeof(ULROUNDANTSELInfo),(VOID*)&(acBlockBankNeedInfo->ulAcRoundAntSel), AC_IC_NUM*sizeof(ULROUNDANTSELInfo));
    //留给降秩后恢复默认天线分组
    memcpy_s((VOID*)&dlAcRoundAntSelTmp[0], AC_IC_NUM*sizeof(DLROUNDANTSEL),(VOID*)&(acBlockBankNeedInfo->dlAcRoundAntSel), AC_IC_NUM*sizeof(DLROUNDANTSEL));

    return BSP_OK;
}

UINT32 BspGetAntNoByRoundInfo(UINT32 rpuId, UINT32 round)
{
    if ((rpuId >=AC_IC_NUM) || (round >=AC_UL_ANTS_NUM))
    {
        return BSP_ERROR;
    }

    return ulAcRoundAntSel[rpuId].ant[round];
}

UINT32 BspGetAntNoByDlAcRoundAntSel(UINT32 round, UINT32 rpuId, UINT32 array)
{
    if ((rpuId >=AC_IC_NUM) || (round >=AC_ROUND_NUM) || (array >= IcHalAcCfgPara.dlAntNum))
    {
        return BSP_ERROR;
    }

    return dlAcRoundAntSel[rpuId].ant[round][array];
}


UINT32 IcHalInitBlockBankInfo(UINT32 carrNo, UINT32 radioMode, A53R8AcDebugShareInfo* shareInfo)
{
    memset((VOID*)&dlAcBlockBankBandInfo[0], 0, AC_IC_NUM*sizeof(ICRRBlockBankDL));
    memset((VOID*)&ulAcBlockBankBandInfo[0], 0, AC_IC_NUM*sizeof(ICRRBlockBankUL));

    IcHalInitUlAcAllBlockBankInfo(carrNo, radioMode,shareInfo);
    IcHalInitDlAcAllBlockBankInfo(carrNo, radioMode);

    return BSP_OK;
}

UINT32 IcHalSetBlockBankInfo(UINT32 radioMode, UINT32 carrNo,UINT32 dataOffset, UINT32 acType, A53R8AcDebugShareInfo* shareInfo)
{
    memset((VOID*)&dlAcBlockBankBandInfo[0], 0, AC_IC_NUM*sizeof(ICRRBlockBankDL));
    memset((VOID*)&ulAcBlockBankBandInfo[0], 0, AC_IC_NUM*sizeof(ICRRBlockBankUL));
    
    IcHalAcCfgPara.acOffset = dataOffset;
    
    IcHalInitUlAcAllBlockBankInfo(carrNo, radioMode,shareInfo);
    IcHalInitDlAcAllBlockBankInfo(carrNo, radioMode);

    return BSP_OK;
}

UINT32 IcHalShowDlAcBlockBankInfo(UINT32 ic)
{
    UINT32 round = 0;
    UINT32 roundMax = IcHalAcCfgPara.acDlRoundNo;
    UINT32 dlAnt = 0;
    UINT32 dlAntMax = IcHalAcCfgPara.dlAntNum;
    
    dbgInfo("\n******************** IC %d ********************\n", ic);
    for(round = 0; round < roundMax; round++)
    {
        for(dlAnt = 0; dlAnt < dlAntMax; dlAnt++)
        {
            dbgInfo("DLAC round %d, Ant %2d, DL: dlIsSet %d, bank %2d ->>>-  UL: ulIsSet %d, bank %2d, vgaChan %2d,vgaDelay %2d\n",\
                round,
                dlAcRoundAntSel[ic].ant[round][dlAnt],
                dlAcBlockBankBandInfo[ic].bBInfo[round].dlIsSet[dlAnt],
                dlAcBlockBankBandInfo[ic].bBInfo[round].dlBank[dlAnt],
                dlAcBlockBankBandInfo[ic].bBInfo[round].ulIsSet[dlAnt],
                dlAcBlockBankBandInfo[ic].bBInfo[round].ulBank[dlAnt],
                dlAcBlockBankBandInfo[ic].bBInfo[round].ulVgaChn[dlAnt],
                dlAcBlockBankBandInfo[ic].bBInfo[round].ulVgaDelay[dlAnt]
            );
        }
    }
    
    return BSP_OK;
}

UINT32 IcHalShowUlAcBlockBankInfo(UINT32 ic)
{
    UINT32 round = 0;
    UINT32 roundMax = 1;
    UINT32 dlAnt = 0;
    UINT32 icMaxAntNo = 16;
    
    icMaxAntNo = IcHalAcCfgPara.acIcMaxAntNo;
    dbgInfo("\n******************** IC %d ********************\n", ic);
    for(round = 0; round < roundMax; round++)//只有1次
    {
        for(dlAnt = 0; dlAnt < icMaxAntNo; dlAnt++)
        {
            dbgInfo("ULAC round %d, Ant %2d, DL: dlIsSet %d, bank %2d, ->>>-  UL: ulIsSet %d, bank %2d, vgaChan %2d,vgaDelay %2d\n",\
                round,
                ulAcRoundAntSel[ic].ant[dlAnt],
                ulAcBlockBankBandInfo[ic].bBInfo[round].dlIsSet[dlAnt],
                ulAcBlockBankBandInfo[ic].bBInfo[round].dlBank[dlAnt],
                ulAcBlockBankBandInfo[ic].bBInfo[round].ulIsSet[dlAnt],
                ulAcBlockBankBandInfo[ic].bBInfo[round].ulBank[dlAnt],
                ulAcBlockBankBandInfo[ic].bBInfo[round].ulVgaChn[dlAnt],
                ulAcBlockBankBandInfo[ic].bBInfo[round].ulVgaDelay[dlAnt]
            );
        }
    }
    
    return BSP_OK;
}

UINT32 IcHalShowBlockBankInfo(UINT32 ic)
{
    acprintf("\n****************** DL AC Block Bank Info ******************\n");
    IcHalShowDlAcBlockBankInfo(ic);
    
    acprintf("\n****************** UL AC Block Bank Info ******************\n");
    IcHalShowUlAcBlockBankInfo(ic);
    
    return BSP_OK;
}

UINT32 IcHalCopyBlockBankInfoToShareMem()
{
    VOID * srcAddr       = 0;
    VOID * dstBaseAddr   = 0;
    UINT32 dstAddrOffset = 0;
    VOID * dstAddr       = 0;
    UINT32 dldataSize    = 0;
    UINT32 uldataSize    = 0;
    UINT32 chip          = 0;

    chip          =  BspGetRpuId();
    dstBaseAddr   = s_acDrvBoard.shareMemVirAddrBase;
    dldataSize    = sizeof(ICRRBlockBankDL);//下行和上行的分组信息，是同一个结构体
    uldataSize    = sizeof(ICRRBlockBankUL);//下行和上行的分组信息，是同一个结构体

    INPUT_AC_PARAMETER_CHECK(chip, AC_IC_NUM);

    //下行分组信息拷贝到R8的共享内存
    srcAddr       = (VOID*)(&dlAcBlockBankBandInfo[chip]);
    dstAddrOffset = s_acDrvBoard.dlAcBlockBankInfoAddrOffset;
    dstAddr       = dstBaseAddr + dstAddrOffset;
    memcpy_s(dstAddr, dldataSize, srcAddr, dldataSize);
    acprintf("chip %d, copy Dl BlockBank Info, srcAddr 0x%08X, dstBase 0x%08X, Offset 0x%08X, DstAddr 0x%08X, size 0x%08X\n",
              chip, srcAddr, dstBaseAddr, dstAddrOffset, dstAddr, dldataSize);

    //上行分组信息拷贝到R8的共享内存
    srcAddr       = (VOID*)(&ulAcBlockBankBandInfo[chip]);
    dstAddrOffset = s_acDrvBoard.ulAcBlockBankInfoAddrOffset;
    dstAddr       = dstBaseAddr + dstAddrOffset;
    memcpy_s(dstAddr, uldataSize, srcAddr, uldataSize);
    acprintf("chip %d, copy Ul BlockBank Info, srcAddr 0x%08X, dstBase 0x%08X, Offset 0x%08X, DstAddr 0x%08X, size 0x%08X\n",
              chip, srcAddr, dstBaseAddr, dstAddrOffset, dstAddr, uldataSize);

    return BSP_OK;
}

//内插使能:根据bitmap进行使能
UINT32 IcHalSetDlBankAcInsertOnOff(UINT32 onOff)
{
    //NR4.0 2020.11.23
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;
    UINT32 uiInsrtEn = (SWITCH_ON == onOff) ? 1:0;
    UINT32 dlBitMap    = 0;
    A53R8AcDebugShareInfo* a53R8ShareInfo = NULL;
    UINT8 *pucBaseAddr = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    
    a53R8ShareInfo = (A53R8AcDebugShareInfo*)((VOID *)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr));
    dlBitMap    = a53R8ShareInfo->dlBitMap;

    for(uiAntNum=0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        if(ANT_IS_SELECT == BIT_VAL(dlBitMap, uiAntNum))
        {
            //内插使能
            IcHalApiSetAcCaliEnCa(uiBlockId, uiAntNum, uiInsrtEn);
        }
    }

    return BSP_OK;
}

UINT32 IcHalSetDlBankAcInsertAddrAndLength(UINT32 block,UINT32 startAddr,UINT32 endAddr,UINT32 length) 
{
    UINT32 uiAntNum = 0;
    UINT32 uiSection = 0;
    UINT32 uiSectionMax = 6;

    for(uiAntNum = 0;uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //起始地址
        IcHalApiSetAcInsrtStartAddrCa(block, uiAntNum, startAddr);
        //结束地址
        IcHalApiSetAcInsrtEndAddr(block, uiAntNum, endAddr);
        //内插长度，AC只使用第0段
        IcHalApiSetAcSeqLength(block, uiAntNum, 0, length);
        //6组配置分别对应6段序列，其余配为0
        for(uiSection = 1;uiSection < uiSectionMax;uiSection++)
        {
            IcHalApiSetAcSeqLength(block, uiAntNum, uiSection, 0);
        }
    }

    return BSP_OK;
}

//内插前延时样点数
UINT32 IcHalSetDlInsertFrontDelayPoint(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 pasteCarrFlag,UINT32 bandWidth,UINT32 acGpNum)
{
    UINT32 uiBlockId           = 0;
    UINT32 uiAntNum            = 0;
    UINT32 uiAcInsertDelay     = 0;
    UINT32 uiFrontZeroDelay    = 0;
    UINT32 uiEndZeroDelay      = 0;
    UINT32 uiSectionSel        = 0;
    UINT32 uiSectionMax        = 8;

    uiAcInsertDelay  = BspGetAcFrToDlEnd(actype, carrNo, radioMode, bandWidth, pasteCarrFlag);
    uiFrontZeroDelay = BspGetAcFrontOrEndZeroDelay(actype, radioMode, carrNo, acGpNum, bandWidth, pasteCarrFlag, FRONT_ZERO_TYPE);
    uiEndZeroDelay   = BspGetAcFrontOrEndZeroDelay(actype, radioMode, carrNo, acGpNum, bandWidth, pasteCarrFlag, END_ZERO_TYPE);
    dbgInfo("[%s] uiAcInsertDelay:%d, uiFrontZeroDelay:%d, uiEndZeroDelay:%d\n", __FUNCTION__, uiAcInsertDelay, uiFrontZeroDelay, uiEndZeroDelay);
    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        for(uiSectionSel = 0;uiSectionSel < uiSectionMax;uiSectionSel++)
        {
            //配置内插前延时
            IcHalApiSetPreAcInsrtDlyCa(uiBlockId, uiAntNum, uiSectionSel, uiAcInsertDelay);
            //内插前插0值
            IcHalApiSetAcInsrtZeroNumCa(uiBlockId, uiAntNum, uiFrontZeroDelay);
            //内插后插0值
            IcHalApiSetPostAcInsrtDlyCa(uiBlockId, uiAntNum, uiEndZeroDelay);
        }
    }

    return BSP_OK;
}

//内插前插0样点数
UINT32 IcHalSetDlBankAcInsertFrontZeroPoint(UINT32 block) 
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //内插前插0值
        IcHalApiSetAcInsrtZeroNumCa(uiBlockId, uiAntNum, front0Num);
    }

    return BSP_OK;
}
//内插后等待值样点数
UINT32 IcHalSetDlBankAcInsertRearDelayPoint(UINT32 block) 
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //内插后等待值
        IcHalApiSetPostAcInsrtDlyCa(uiBlockId, uiAntNum, frontDelay);
    }

    return BSP_OK;
}

//内插次数选择，TDD只插1次
UINT32 IcHalSetDlBankAcInsertTimes(UINT32 block,UINT32 insrtNum) 
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //内插次数
        IcHalApiSetAcInsrtTimeCa(uiBlockId, uiAntNum, insrtNum);
    }
    return BSP_OK;
}

UINT32 IcHalSetDlBankAcInsertSequenceGain(UINT32 block,UINT32 seqGain) 
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //序列增益
        IcHalApiSetAcGainICa(uiBlockId, uiAntNum, 0, seqGain);
        IcHalApiSetAcGainQCa(uiBlockId, uiAntNum, 0, seqGain);
    }
    return BSP_OK;
}

UINT32 IcHalSetUlBankCatchRamEnOff(UINT32 uiAntNum)
{
    UINT32 uiBlockId = 0;
    UINT32 uiOff     = 0;

    //采数使能
    IcHalApiSetAccbSnapEn(uiBlockId, uiAntNum, uiOff);

    return BSP_OK;
}

UINT32 IcHalSetUlAllBankCatchRamEnOff(VOID)
{
    UINT32 uiAntNum  = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        IcHalSetUlBankCatchRamEnOff(uiAntNum);
    }

    return BSP_OK;
}

UINT32 IcHalSetUlBankAllBlockCatchRamEnOff(VOID)
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;
    UINT32 uiOff     = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //采数去使能
        IcHalApiSetAccbSnapEn(uiBlockId, uiAntNum, uiOff);
    }

    return BSP_OK;
}
/************************************************************************
   4片RAM ramSel 0~3

   1，有中断指示(高)，才可以读RAM
   2，读完，要清中断，不然影响下次读中断
   3，中断使能关闭时，即不用中断时，每次只要清就行，不用判断是否有中断
************************************************************************/
UINT32 IcHalGetAllUlBankCatchRamInt(VOID)
{
    UINT32 uiBlock    = 0;
    UINT32 uiIntInfo  = 0;
    UINT32 uiAntNum   = 0;
    
    for(uiAntNum=0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        acprintf("******************** uiAntNum %d ********************\n", uiAntNum);
        IcHalApiGetAccbDoneInt(uiBlock, uiAntNum, &uiIntInfo);
        acprintf("uiAntNum:%d Accb Done Int: %d ", uiAntNum, uiIntInfo);
        acprintf("\n\n");
    }

    return BSP_OK;
}

UINT32 IcHalSetUlBankCatchRamClearAllInts(VOID)
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        ////清接收中断
        IcHalApiSetAccbDoneIntClr(uiBlockId, uiAntNum, 0);
        IcHalApiSetAccbDoneIntClr(uiBlockId, uiAntNum, 1);
        IcHalApiSetAccbDoneIntClr(uiBlockId, uiAntNum, 0);
    }

    return BSP_OK;
}

UINT32 IcHalSetUlBankCatchRamRouterUlBank(UINT32 block, UINT32 ramSel, UINT32 bank)
{
    IcHalApiSetAccbBankRouterCfg(block, ramSel, bank);

    return BSP_OK;
}

UINT32 IcHalGetAcUlCompensateWaitDly(UINT32 radioMode,UINT32 pasteCarrFlag, UINT32 bandWidth)
{
    UINT32 CompensateWaitDlyPoint = 0;
    T_ICHAL_ACPARA* acPara           = NULL;
    
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    
    if(RADIO_STANDARD_5G == radioMode)
    {
        switch(bandWidth)
        {
            case BANDWIDTH_100M_MHz://NR 100M
            case BANDWIDTH_90M_MHz://NR 90M
            {
                CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelay;
                break;
            }
            case BANDWIDTH_80M_MHz://NR 80M
            case BANDWIDTH_70M_MHz://NR 70M
            {
                CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr80M;
                break;
            }
            case BANDWIDTH_60M_MHz://NR 60M
            {
                CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr60M;
                break;
            }
            case BANDWIDTH_50M_MHz://NR 50M
            {
                CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelay50MNr;
                break;
            }
            case BANDWIDTH_40M_MHz://NR 40M
            {
                CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelay40MNr;
                break;
            }
            case BANDWIDTH_30M_MHz://NR 30M
            {
                CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr30M;
                break;
            }
            case BANDWIDTH_25M_MHz://NR 25M
            case BANDWIDTH_20M_MHz://NR 20M
            {
                CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr20M;
                break;
            }
            default:
                break;
        }
    } 

    else if(RADIO_STANDARD_LTE_TDD == radioMode)
    {
        if(CARR_IS_PASTE == pasteCarrFlag) //LTE载波拼接
        {
            CompensateWaitDlyPoint = acPara->acLteCfgPara.acUlBankCompensateWaitDelayPasteCarr;
        }
        else 
        {
            switch(bandWidth)
            {
                case BANDWIDTH_20M_MHz:
                {
                    CompensateWaitDlyPoint = acPara->acLteCfgPara.acUlBankCompensateWaitDelay;
                    break;
                }
                case BANDWIDTH_10M_MHz:
                {
                    CompensateWaitDlyPoint = acPara->acLteCfgPara.acUlBankCompensateWaitDelay;
                    break;
                }           
                default:
                break;
            } 
        }
    }

    return CompensateWaitDlyPoint;
}

UINT32 IcHalSetDlavgTA(INT8 inPut)
{
    avgTaDl = inPut;
    return BSP_OK;
}
UINT32 IcHalSetUlavgTA(INT8 inPut)
{
    avgTaUl = inPut;
    return BSP_OK;
}

UINT32 BspGetCatchDifChn(UINT32 *puiDifChn)
{
    UINT32 acCellSeparateMode      = BspGetAcCellSeparateMode();
    UINT32 separateBit             = BspGetSepareBitmap();
    T_ICHAL_ACPARA* ptAcPara       = NULL;
    UINT32 uiAntId                 = 0;
    UINT32 uiAntTmp                = 0;
    UINT32 uiCatchDataChan         = 0;
    UINT32 uiAcRpuId               = 0;
    UINT32 uibandNo                = 0;
    UINT32 difChipId               = 0;
    UINT32 uiRet                   = 0;

    ptAcPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    if(AC_MULTI_CHIP != ptAcPara->acMultiChip)
    {
        if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
        {
            *puiDifChn = 4;
        }
        else
        {
            BspGetAcCatchChan(&uiCatchDataChan,&uiAcRpuId,&uibandNo);
            uiCatchDataChan = uiCatchDataChan +1;
            uiRet = BspGetDifInfoByAntInfo(uiCatchDataChan, uibandNo, RX, &difChipId, puiDifChn);
            RETURN_RESULT_CHECK(uiRet);
        }
    }
    else
    {
        for(uiAntId = 0;uiAntId < ptAcPara->acIcMaxAntNo; uiAntId++)
        {
            uiAntTmp = BspGetAntNoByDlAcRoundAntSel(0, BspGetRpuId(), uiAntId);
            CHECK_AC_ANT_VALID(uiAntTmp);
            uiAntTmp = uiAntId + 1; //对应map表中的天线号列，需要加1
            uiRet = BspGetDifInfoByAntInfo(uiAntTmp, uibandNo, TX, &difChipId, puiDifChn);
            RESULT_CHECK_BREAK_AC(uiRet);
        }
    }

    return BSP_OK;
}

UINT32 BspGetAvgTa(UINT32 uiAcType, INT8 *pcAvgTa)
{
    if(AC_TYPE_DL == uiAcType)
    {
        *pcAvgTa = avgTaDl;
    }
    else if(AC_TYPE_UL == uiAcType)
    {
        *pcAvgTa = avgTaUl;
    }
    else
    {
        dbgInfoEx("%s:err acType:%d \n",  __FUNCTION__, uiAcType);
    }

    return BSP_OK;
}

UINT32 IcHalSetUlBankCatchRamWaitDelayPoint(UINT32 acType,UINT32 block, UINT32 antId, UINT32 delay, UINT32 radioMode,UINT32 carrNo,UINT32 sample,UINT32 pasteCarrFlag,UINT32 bandWidth)
{
	FLOAT delayAfterCompensatedFloat = 0;
    UINT32 delayAfterCompensated   = 0;
    UINT32 ueAdvVal                = 0;
    UINT32 ueAdvValns              = 0;
    FLOAT factor                   = 0;
    FLOAT factorTA_c               = 0;
    INT8 avgTA                     = 0;
    UINT32 acInsertPosRate         = 0;
    UINT32 acCatchDataPosRate      = 0;
    UINT32 acInsertPos             = 0;     //0表示drcf前
    UINT32 acCatchDataPos          = 0;      //0：rcf后
    UINT32 difChan                 = 0;
    UINT32 uiValidNum              = 0;
    UINT32 ui4GUeGapValNs          = 0;
    UINT32 ui5GUeGapValNs          = 0;
    UINT32 UeGapValAdjNs           = 0;
    UINT32 UeGapValAdjClk          = 0;
    UINT32 uiRet                   = 0;
    UINT32 UeGapValAdjNsLTETdd     = 0;
    UINT32 waitAcDly               = IcHalGetAcUlCompensateWaitDly(radioMode,pasteCarrFlag,bandWidth);

    uiRet = BspGetCatchDifChn(&difChan);
    RETURN_RESULT_CHECK(uiRet);

    acInsertPos    = GetAcInsertPos();
    acCatchDataPos = GetAcCatchDataPos();
    
    //三点发数 修改
    //根据AC采数位置获取该位置采样率
    IcHalApiGetAcRxNodeSampleRate(difChan, radioMode, carrNo, acCatchDataPos, &acCatchDataPosRate);
    //根据AC发数位置获取该位置采样率
    IcHalApiGetAcTxNodeSampleRate(difChan, radioMode, carrNo, acInsertPos, &acInsertPosRate, &uiValidNum);

    //获取4GUE保护量
    IcHalApiGetUeGapVal(RADIO_STANDARD_LTE_TDD, &ui4GUeGapValNs);
    //获取5GUE保护量
    IcHalApiGetUeGapVal(RADIO_STANDARD_5G, &ui5GUeGapValNs);

    UeGapValAdjNsLTETdd = ui4GUeGapValNs - ui5GUeGapValNs;
    UeGapValAdjNs = (RADIO_STANDARD_LTE_TDD == radioMode)? UeGapValAdjNsLTETdd : 0;

    UeGapValAdjClk = NsToClk(UeGapValAdjNs,CLK_RATE_30P72);
    INPUT_AC_ZERO_CHECK(acInsertPosRate);
    INPUT_AC_ZERO_CHECK(acCatchDataPosRate);
    if((acCatchDataPosRate < 983040) &&(acInsertPosRate < 983040))
    {
        factor = (FLOAT)acCatchDataPosRate / (FLOAT)acInsertPosRate;
        factorTA_c = (FLOAT)acCatchDataPosRate /(FLOAT)CLK_RATE_245P76;
    }
    uiRet = BspGetAvgTa(acType, &avgTA);
    RETURN_RESULT_CHECK(uiRet);

    /* Started by AICoder, pid:z988fj4a771182214f3e0b5cc0fa8d0bb51926a1 */
    if (delay >= 0x7fffff || UeGapValAdjClk >= 0x7fffff || waitAcDly >= 0x7fffff)
    {
        dbgErr("[%s], LINE:%d data out of range \n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    if(radioMode == RADIO_STANDARD_5G)
    {
        delayAfterCompensatedFloat = factor * (FLOAT)delay + factor * (FLOAT)UeGapValAdjClk + (FLOAT)waitAcDly + factorTA_c * (FLOAT)avgTA;
    }
    else
    {
        delayAfterCompensatedFloat = factor * (FLOAT)delay + factor * (FLOAT)UeGapValAdjClk + (FLOAT)waitAcDly;
    }
    /* Ended by AICoder, pid:z988fj4a771182214f3e0b5cc0fa8d0bb51926a1 */
    dbgInfoEx("[%s] factor:%f,delay:%d,UeGapValAdjClk:%d, waitAcDly:%d, factorTA_c:%f,avgTA:%d\n",
                __FUNCTION__,factor,delay,UeGapValAdjClk,waitAcDly,factorTA_c,avgTA);
    if((delayAfterCompensatedFloat > 0) && (delayAfterCompensatedFloat <1000000.0)) //修改告警
    {
        delayAfterCompensated = delayAfterCompensatedFloat;
    }
    dbgInfoEx("acCatchDataPosRate is %d,acInsertPosRate is %d,UeGapValAdjNs is %d,UeGapValAdjClk is %d\n",acCatchDataPosRate,acInsertPosRate,UeGapValAdjNs,UeGapValAdjClk);

    //配置UE提前量
    IcHalApiGetUeAdvVal(radioMode, &ueAdvValns);
    ueAdvVal = NsToClk(ueAdvValns,CLK_RATE_737P28);
    IcHalApiSetAccbFrTaDelay(block, antId, ueAdvVal);
    //AC模块采数延时配置
    IcHalApiSetAccbDelayNum(block, antId, delayAfterCompensated);

    return BSP_OK;
}

UINT32 IcHalGetUlCatchDataDelayPoint(UINT32 actype,UINT32 radioMode,UINT32 carrNo,UINT32 pasteCarrFlag, UINT32 bandWidth, UINT32* delay,UINT32 acGpNum)
{
    UINT32 uiFrToGp     = 0;
    UINT32 uiFrontDelay = 0;

    uiFrToGp = BspGetAcFrToDlEnd(actype, carrNo, radioMode, bandWidth, pasteCarrFlag);
    uiFrontDelay = BspGetAcFrontOrEndZeroDelay(actype, radioMode, carrNo, acGpNum, bandWidth, pasteCarrFlag, FRONT_ZERO_TYPE);
    *delay = uiFrToGp + uiFrontDelay;

    return BSP_OK;
}

UINT32 IcHalCompensateUlBankCatchRamWaitDelayPoint(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 pasteCarrFlag,UINT32 bandWidth,UINT32 acGpNum)
{
    UINT32 uiBlockId      = 0;
    UINT32 uiAntNum       = 0;
    UINT32 uiSample       = 0;
    UINT32 uiAcCatchDelay = 0;
    UINT32 uiAntStart = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();
    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        uiAntStart = 4;
    }

    IcHalGetUlCatchDataDelayPoint(actype,radioMode,carrNo,pasteCarrFlag,bandWidth,&uiAcCatchDelay,acGpNum);
    uiSample = bspGetSampleFromBw(radioMode,bandWidth,pasteCarrFlag);
    if(0 == uiSample)
    {
        dbgInfo("[%s] sample:%d error\n",__FUNCTION__,uiSample);
        return BSP_ERROR;
    }
    for(uiAntNum = uiAntStart; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //采数延时等待配置，与下行对齐
        IcHalSetUlBankCatchRamWaitDelayPoint(actype, uiBlockId, uiAntNum, uiAcCatchDelay, radioMode, carrNo, uiSample, pasteCarrFlag, bandWidth);
    }

    return BSP_OK;
}

UINT32 IcHalDmaMoveDataFromUlBankCatchRamToDdrShareMem(UINT32 round,UINT32 actype)
{
    /* Done in R8 */
    return BSP_OK;
}
//打印dlbank的动态配置 
UINT32 IcHalShowAllDlBankAcRegs(VOID)
{
    UINT32 uiAntNum  = 0;
    UINT32 uiBlockId = 0;
    UINT32 uiSetBank = 0;
    UINT32 uiAcEn    = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        dbgInfo("\n****************** uiAntNum %d *********************\n", uiAntNum);
        IcHalApiGetAcDataSelCa(uiBlockId, uiAntNum, &uiSetBank);//内插载波选择
        IcHalApiGetAcCaliEnCa(uiBlockId, uiAntNum, &uiAcEn);//内插使能
        dbgInfo("uiAntNum %d, setBank %2d, acen:%d\n", uiAntNum, uiSetBank, uiAcEn);
    }
    
    return BSP_OK;
}

//打印ulbank的动态配置 
UINT32 IcHalShowAllUlBankAcRegs(VOID)
{
    UINT32 uiAntNum  = 0;
    UINT32 uiBlockId = 0;
    UINT32 uiIntClrSta = 0 ;
    UINT32 uiIntEnSta = 0 ;
    UINT32 uiCatchEnSta   = 0;
    UINT32 uiRouterBank = 0;
    UINT32 uiVgaInChn = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        dbgInfo("\n****************** uiAntNum %d *******************\n", uiAntNum);
        IcHalApiGetAccbDoneIntClr(uiBlockId, uiAntNum, &uiIntClrSta);//清接收中断状态回读
        IcHalApiGetAccbDoneIntEn(uiBlockId, uiAntNum, &uiIntEnSta);//使能接收中断状态回读
        dbgInfo("IntClrSta %d, IntEnSta %d(1:En)\n", uiIntClrSta, uiIntEnSta);

        IcHalApiGetAccbSnapEn(uiBlockId, uiAntNum, &uiCatchEnSta);//采数使能状态回读
        IcHalApiGetAccbBankRouterCfg(uiBlockId, uiAntNum, &uiRouterBank); //采数bank router配置
        IcHalApiGetAccbChRouterCfg(uiBlockId, uiAntNum, &uiVgaInChn);//VGA通道补偿系数router配置

        dbgInfo("uiAntNum %d, CatchEn %d(1:En), RouterBank %2d, VgaInChn %2d\n",\
                uiAntNum, uiCatchEnSta, uiRouterBank, uiVgaInChn);
    }

    return BSP_OK;
}

UINT32 IcHalSetAcInsertData(UINT32 acSeqLen, UINT32 acCpLen)
{
    UINT32 uiBlockId   = 0;
    UINT32 uiStartAddr = 0;
    UINT32 uiEndAddr   = 0;
    UINT32 uiLength    = 0;

    uiStartAddr= acSeqLen - acCpLen/2;
    uiEndAddr  = acSeqLen - 1;
    uiLength   = acSeqLen + acCpLen;

    IcHalSetDlBankAcInsertAddrAndLength(uiBlockId, uiStartAddr, uiEndAddr, uiLength);

    return BSP_OK;
}
//上行RAM采集数据长度配置
UINT32 IcHalSetUlAcDataLen(UINT32 acSeqLen)
{
    UINT32 uiBlockId    = 0;
    UINT32 uiAntNum     = 0;
    UINT32 uiGetNum     = 0;
    UINT32 uiHoldNum    = 0;
    UINT32 uiCbLen      = 0;

    uiGetNum   = acSeqLen - 1;
    uiHoldNum  = acSeqLen ;
    uiCbLen    = acSeqLen - 1;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        ///Get Num
        IcHalApiSetAccbGetNum(uiBlockId, uiAntNum, uiGetNum);
        ///Hold Num
        IcHalApiSetAccbHoldNum(uiBlockId, uiAntNum, uiHoldNum);
        ///Ac Ram Len
        IcHalApiSetAccbCbLength(uiBlockId,uiAntNum, uiCbLen);
    }

    return BSP_OK;
}

UINT32 IcHalInitDlBank(VOID)
{
    UINT32 uiBlockId       = 0;
    UINT32 uiAntId         = 0;
    UINT32 uiAcInsertPos   = 0;      //0表示drcf前
    UINT32 uiAcFrMode      = 0;      //0表示fr模式
    UINT32 uiAcInsertTimes = 1;      //1次
    UINT32 uiSeqNum        = 0;      //支持6段序列配置,AC默认用第0段
    UINT32 uiAcDataGainICa = 0x400;  //实部默认值为0x400    
    UINT32 uiAcDataGainQCa = 0;      //虚部默认值为0
    UINT32 uiAcCaliOff     = 0;      //先关闭发数使能
    UINT32 uiAcFrameIdOff  = 0;      //0表示不受无线帧号的限制
    UINT32 uiAcFrameIdMk   = 2;      //2表示低10bit可用
    UINT32 uiAcFrSel       = 1;      //1表示无线帧号匹配
    UINT32 uiMode          = 1;      //AC数据选择直接替换
    UINT32 uiOptAcEn       = 1;      //1不看光口的ac_en信号，将光口的ac_en掩码掉

    uiAcInsertPos = GetAcInsertPos();
    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        //AC插入位置
        IcHalApiSetAcPos(uiBlockId, uiAntId, uiAcInsertPos);
        //fr模式
        IcHalApiSetGpFrSelCaMod(uiBlockId, uiAntId, uiAcFrMode);
        //内插次数
        IcHalApiSetAcInsrtTimeCa(uiBlockId, uiAntId, uiAcInsertTimes);
        //增益实部I
        IcHalApiSetAcGainICa(uiBlockId, uiAntId, uiSeqNum, uiAcDataGainICa);
        //增益实部Q
        IcHalApiSetAcGainQCa(uiBlockId, uiAntId, uiSeqNum, uiAcDataGainQCa);
        //关闭内插使能
        IcHalApiSetAcCaliEnCa(uiBlockId, uiAntId, uiAcCaliOff);
        //不受无线帧号的限制
        IcHalApiSetFrameIdEn(uiBlockId, uiAntId, uiAcFrameIdOff);
        //无线帧号掩码
        IcHalApiSetOptFrameIdMk(uiBlockId, uiAntId, uiAcFrameIdMk);
        //无线帧号匹配方式
        IcHalApiSetFrameIdSel(uiBlockId, uiAntId, uiAcFrSel);
        //AC数据替换方式
        IcHalApiSetDataSwitchMode(uiBlockId, uiAntId, uiMode);
        //不看光口的ac_en信号，将光口的ac_en掩码掉
        IcHalApiSetAcEnMk(uiBlockId, uiAntId, uiOptAcEn);
    }

    return BSP_OK;
}

UINT32 IcHalSetTddFlgDly(UINT32 radioMode, UINT32 carrNo,UINT32 acInsertPos)
{
    UINT32 maxChnNum = BspGetTxChannel();
    UINT32 loopSel = 0;
    UINT32 uiLoopStart = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();

    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        uiLoopStart = 4;
    }

    for(loopSel = uiLoopStart; loopSel < maxChnNum; loopSel++)
    {
        //coverity[cert_exp37_c_violation:SUPPRESS]
        IcHalApiSetAcTddDly(loopSel, radioMode, carrNo, acInsertPos); //DlBank中AC使用的TddFlg延时
    }

    return BSP_OK;
}

//配置下行AC插数位置
UINT32 IcHalSetDlbankAcInsertPos(UINT32 acInsertPos)
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntId = 0;

    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {	
        IcHalApiSetAcPos(uiBlockId, uiAntId, acInsertPos); //AC插入位置:0-drcf前、1-drcf后、2-drouter0后、3-drouter1后
    }

    return BSP_OK;
}

//配置上行AC插数位置
UINT32 ICHalSetUlbankAcDataRouterCfg(UINT32 acCatchDataPos)
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntId = 0;
	
    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        IcHalApiSetAccbDataRouterCfg(uiBlockId, uiAntId, acCatchDataPos); //设置采数位置:0-rcf后 1-rcf前 其他-NCO0前
    }

    return BSP_OK;
}

UINT32 IcHalInitUlBank(VOID)
{
    UINT32 uiBlockId            = 0;
    UINT32 uiAntNum             = 0;
    UINT32 uiAcCatchDataPos     = 0;   //0：rcf后
    UINT32 uiAcCatchDataMode    = 0;   //0：fr模式
    UINT32 uiAcFrNumPerSync     = 1;   //AC不可见，直接配1，rssi相关
    UINT32 ui10msFrEn           = 0;   //0：5ms帧头去使能
    UINT32 uiAcFreeCatchDataOff = 0;   //0：关闭自由采数
    UINT32 uiAcRssiOff          = 0;   //配置为0时：AC工作状态;配置为1时rssi工作状态;保证AC和rssi互斥
    UINT32 uiAcInsertDataNum    = 0;   //0：提取1次
    UINT32 uiAcFrameIdOff       = 0;   //0：帧号匹配去使能
    UINT32 uiAcCatchDataOff     = 0;   //0：采数去使能
    UINT32 uiAcInslotOff        = 0;   //0：关闭
    UINT32 uiAcFrameIdMask      = 2;   //2：I有效ID位宽10bit
    UINT32 uiCbLength           = 1023;//AC上行采数RAM深度
    UINT32 uiOptMaskEn          = 1;

    uiAcCatchDataPos = GetAcCatchDataPos();
    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        //设置采数位置为RCF后
        IcHalApiSetAccbDataRouterCfg(uiBlockId, uiAntNum, uiAcCatchDataPos);
        //采数模式fr
        IcHalApiSetAccbCbMode(uiBlockId, uiAntNum, uiAcCatchDataMode);
        //一个ACsync里，有效AC采数的帧头数量，可配范围1~255，AC不可见，直接配1
        IcHalApiSetAccbFrNum(uiBlockId, uiAntNum, uiAcFrNumPerSync);
        //AC 5m帧头去使能
        IcHalApiSetAccbFr5msEn(uiBlockId, uiAntNum, ui10msFrEn);
        //关闭自由采数
        IcHalApiSetAccbFreeCbEn(uiBlockId, uiAntNum, uiAcFreeCatchDataOff);
        //配置AC使能，rssi去使能
        IcHalApiSetAccbRssiEn(uiBlockId, uiAntNum, uiAcRssiOff);
        //插数次数，目前只有一次
        IcHalApiSetAccbCycleNum(uiBlockId, uiAntNum, uiAcInsertDataNum);
        //帧号匹配去使能
        IcHalApiSetAccbFrameIdEn(uiBlockId, uiAntNum, uiAcFrameIdOff);
        //关闭上行采数使能
        IcHalApiSetAccbSnapEn(uiBlockId, uiAntNum, uiAcCatchDataOff);
        //关闭inslot
        IcHalApiSetAccbAcInslotEn(uiBlockId, uiAntNum, uiAcInslotOff);
        //无线帧号掩码
        IcHalApiSetAccbFrameIdMask(uiBlockId, uiAntNum, uiAcFrameIdMask);
        //AC上行采数RAM深度配置
        IcHalApiSetAccbCbLength(uiBlockId, uiAntNum, uiCbLength);
        //1-掩码，即光口的ACsnap信号不使能
        IcHalApiSetOptSnapMaskEn(uiBlockId, uiAntNum, uiOptMaskEn);
        //1-掩码，即光口的AC回插信号不使能
        IcHalApiSetOptInsrtMaskEn(uiBlockId, uiAntNum, uiOptMaskEn);
    }

    return BSP_OK;
}

UINT32 IcHalSetUlBankCatchRamEnOn(void)
{
    UINT32 uiDifChn    = 0;
    UINT32 uiBlock     = 0;
    UINT32 uiEn        = 1;
    UINT8 *pucBaseAddr = NULL;
    A53R8AcDebugShareInfo *a53R8ShareInfo = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    a53R8ShareInfo = (A53R8AcDebugShareInfo*)((VOID *)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr));
    uiDifChn = a53R8ShareInfo->dlCatchDifChn;

    IcHalApiSetAccbSnapEn(uiBlock, uiDifChn, uiEn);
    dbgInfo("[%s] uiDifChn:%d \n", __FUNCTION__, uiDifChn);

    return BSP_OK;
}

UINT32 IcHalSetUlBankCatchRamPreCfg(A53R8AcDebugShareInfo* a53R8ShareInfo)
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntNum  = 0;

    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        ////清接收中断
        IcHalApiSetAccbDoneIntClr(uiBlockId, uiAntNum, 0);
        IcHalApiSetAccbDoneIntClr(uiBlockId, uiAntNum, 1);
        IcHalApiSetAccbDoneIntClr(uiBlockId, uiAntNum, 0);
    }

    return BSP_OK;
}

UINT32 IcHalUlBankCatchRamWithReadInt(UINT32 antIdx)
{
    UINT32 uiBlockId = 0;
    UINT32 uiIntInfo = 0;
    UINT32 uiRamInt  = 0x1;
    UINT32 uiDelayMs = 100;//100ms

    while(1)
    {
        IcHalApiGetAccbDoneInt(uiBlockId, antIdx, &uiIntInfo);
        if(1 == (uiRamInt & uiIntInfo))
        {
            IcHalCatchUlBankRamCnt[0]++;
            IcHalCatchUlBankRamCnt[1] = uiRamInt;
            acprintf("Find Catch Interrupt with count = %2d!\n", IcHalCatchUlBankRamTickCnt);
            return BSP_OK;
        }
        
        if(uiDelayMs == IcHalCatchUlBankRamTickCnt)//最多100次，即100ms
        {
            IcHalCatchUlBankRamCnt[3]++;
            break;
        }
        
#ifdef _AC_A53_DEBUG_
            BspSysUsDelay_Sys(1000);//1ms
#else
//            ???//不会报错，不要删掉
//            OSS_TSK_Sleep(1);//1个tick即1ms，在验证板上是12.5ms
#endif

        //没有的话，等一会再判断
        IcHalCatchUlBankRamTickCnt++;
    }

    acprintf("Faied Catch Interrupt with count = %2d!\n", IcHalCatchUlBankRamTickCnt);

    return BSP_ERROR;    
}

///根据blockNo和AcIdx 来生成鉴相值
UINT32 IcHalGetGpVid(UINT32 blockNo,UINT32 UiAcIdx,UINT32 *pGpVid)
{
    if( 0 == (blockNo%2))
    {
        *pGpVid = blockNo + UiAcIdx ;
    }
    else
    {
        *pGpVid = 0 ;
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]blockNo:%d,UiAcIdx:%d,pGpVid:%d\n",__FUNCTION__,blockNo,UiAcIdx,*pGpVid); //对应寄存器配置
    return BSP_OK;
}

//根据接收通道配置上行接收路由
UINT32 IcHalDlSetUlBankCatchRamRoundCfg(UINT32 ic, A53R8AcDebugShareInfo* a53R8ShareInfo)
{
    UINT32 uiBlockId   = 0;
    UINT32 uiRamSel    = 0;
    UINT32 uiBankSel   = 0;
    UINT32 uiCatchAnt  = 0;
    UINT32 uiCatchIc   = 0;
    UINT32 uiRound     = 0;
    UINT32 uiRpuId     = BspGetRpuId();

    INPUT_AC_PARAMETER_CHECK(ic, AC_IC_NUM);
    uiCatchAnt = a53R8ShareInfo->acCatchDataChan;
    uiCatchIc  = a53R8ShareInfo->catchAcRpuId;

    if(uiCatchIc != uiRpuId)
    {
        dbgInfo("[%s] catchAnt is not no this IC\n", __FUNCTION__);
        return BSP_OK;
    }
    //初始化
    IcHalSetUlBankCatchRamPreCfg(a53R8ShareInfo);
    INPUT_AC_PARAMETER_CHECK(uiRound, AC_ROUND_NUM);
    INPUT_AC_PARAMETER_CHECK(uiCatchAnt, AC_DL_ANTS_NUM);
    if(1 == dlAcBlockBankBandInfo[ic].bBInfo[uiRound].ulIsSet[uiCatchAnt])
    {
        uiBankSel = dlAcBlockBankBandInfo[ic].bBInfo[uiRound].ulBank[uiCatchAnt];
        uiRamSel  = dlAcBlockBankBandInfo[ic].bBInfo[uiRound].ulDifChn[uiCatchAnt];

        dbgInfo("[%s] uiRamSel:%d, uiBankSel:%d \n", __FUNCTION__, uiRamSel, uiBankSel);
        IcHalApiSetAccbChBnkRouterCfg(uiBlockId, uiRamSel, 0); //AC通道采数选择bank
        IcHalSetUlBankCatchRamRouterUlBank(uiBlockId, uiRamSel, uiBankSel);
    }

    return BSP_OK;
}

//dlbank每次(下行AC总共9次)迭代的动态配置
UINT32 IcHalSetDlBankAcSequenceInsertRoundCfg(UINT32 ic, UINT32 round)
{
    UINT32 uiBlockId     = 0;
    UINT32 acInsertPos   = 0;
    UINT32 uiAntId       = 0;
    UINT32 uiSetBank     = 0;
    UINT8 *pucBaseAddr = NULL;
    A53R8AcDebugShareInfo *a53R8ShareInfo = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    a53R8ShareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr);
    acInsertPos    = a53R8ShareInfo->acInsertPos;

    for(uiAntId = 0; uiAntId < AC_DL_ANTS_NUM; uiAntId++)
    {
        if(1 == dlAcBlockBankBandInfo[ic].bBInfo[round].dlIsSet[uiAntId])
        {
            switch(acInsertPos)
            {
                case AC_INSERT_0_POS:
                case AC_INSERT_1_POS:
                case AC_INSERT_2_POS:
                case AC_INSERT_3_POS:
                {
                    uiSetBank = dlAcBlockBankBandInfo[ic].bBInfo[round].dlBank[uiAntId];
                    break;
                }
                default:
                    uiSetBank = dlAcBlockBankBandInfo[ic].bBInfo[round].dlBank[uiAntId];
                    break;
            }
            IcHalApiSetAcDataSelCa(uiBlockId, uiAntId, uiSetBank);
            IcHalApiSetAc10msSelCa(uiBlockId, uiAntId, uiSetBank);
        }
    }

    return BSP_OK;
}

//ulbank每次(下行AC总共9次)迭代的动态配置
UINT32 IcHalUlSetDlBankAcSequenceInsertRoundCfg(UINT32 ic, UINT32 round)
{
    UINT32 uiBlockId      = 0;
    UINT32 uiSetBank      = 0;
    UINT32 array          = 0;
    UINT32 uiSendDataChn  = 0;
    UINT32 uiSendDifChn   = 0;
    UINT32 uiIcMaxAntNo   = 0;
    UINT32 uiAcInsertPos  = 0;
    UINT8 *pucBaseAddr    = NULL;
    A53R8AcDebugShareInfo *shareInfo = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    shareInfo = (A53R8AcDebugShareInfo*)((VOID *)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr));

    uiSendDataChn   = shareInfo->acCatchDataChan;
    uiSendDifChn    = shareInfo->ulSendDifChn;
    uiIcMaxAntNo    = shareInfo->icMaxAntNo;
    uiAcInsertPos   = shareInfo->acInsertPos;
    array           = uiSendDataChn % uiIcMaxAntNo;

    switch(uiAcInsertPos)
    {
        case AC_INSERT_0_POS:
        case AC_INSERT_1_POS:
        case AC_INSERT_2_POS:
        case AC_INSERT_3_POS:
        {
            uiSetBank = ulAcBlockBankBandInfo[ic].bBInfo[0].dlBank[array];
            break;
        }
        default:
        {
            uiSetBank = ulAcBlockBankBandInfo[ic].bBInfo[0].dlBank[array];
            break;
        }
    }
    IcHalApiSetAcDataSelCa(uiBlockId, uiSendDifChn, uiSetBank);
    IcHalApiSetAc10msSelCa(uiBlockId, uiSendDifChn, uiSetBank);

    return BSP_OK;
}

VOID IcHalDlAcRoundCfg(UINT32 ic, UINT32 round)
{
    IcHalSetDlBankAcSequenceInsertRoundCfg(ic, round);
}

VOID IcHalUlAcRoundCfg(UINT32 ic, UINT32 round)
{
	UINT32 realRound = 0;
    IcHalUlSetDlBankAcSequenceInsertRoundCfg(ic, realRound);
}

/*****************************************************************
    中断使能常开
    1，先清中断上报（0x8960_05A8寄存器）
    2，发数
    3，循环判断中断是否上报【----这个循环判断是否有最大循环次数、或者最大循环判断时间？----】
    4，中断上报后，先读数，再清中断
    5，重复1
    
    clrInts(0);    //清接收中断
    enInts(0);     //使能接收中断
    recoVer(block);//回选载波 0x88C0B00写4
    roundCfgAntCellCarr(round,icId,cellCarr);
    catchUlBankFunc(CATCH_ROUND_CTRL_CNT);
    CATCH_ROUND_CTRL_CNT++;
    psyncint10msoff();//做完16轮，发送完2天线就关掉回调
    gudTaskCnt_Task05_1Block_8Bank[4]++;

    1,roundcfg
    2,clrInt
    3,等到下一个10ms
    4,采数
*****************************************************************/
UINT32 smpAcUlbankRam(UINT32 block,CHAR* fileName)
{
#if 0
    UINT32 uiAcIdx    = 0;
    FILE *fp          = NULL;
    CHAR buff[128]    = {0};
    CHAR outFile[64]  = {0};
    INT32 iTmpRet     = 0;
    UINT32 data[4096] = {0};
    UINT32 acDataLen  = 0;
    UINT32 point      = 0;

    INPUT_AC_PARAMETER_CHECK(block, ANT_NUM_PER_IC);

    iTmpRet = snprintf_s(outFile,sizeof(outFile) - 1,"ulbankRam%d.txt",block);
    SNPRINTF_S_CHECK(iTmpRet, sizeof(outFile) - 1);
    fp = fopen(outFile,"w+");
    if(NULL == fp)
    {
        dbgErr("%s open error!",outFile);
        return BSP_ERROR;
    }

    dbgInfo("block:%d\n",block);
    for(uiAcIdx = 0; uiAcIdx < ONE_BLOCK_ANT_NUM;uiAcIdx++)
    {
        //if(BSP_OK != IcHalApiAcSampleDataRdRam(block, uiAcIdx, &data[0], &acDataLen))
        if(BSP_OK != BspHalAdaptAcSampleDataRdRam(block, uiAcIdx, &data[0], &acDataLen))
        {
            iTmpRet = fclose(fp);
            FCLOSE_CHECK(iTmpRet);
            dbgErr("Get sample data failed!\n");
            return BSP_ERROR;
        }

        dbgInfo("uiAcIdx:%d, acDataLen:%d\n",uiAcIdx,acDataLen);
        for(point = 0; point < 4096; point++)
        {
            if(point % 4 == 0)
            {
                iTmpRet = fprintf(fp,"\n0x%08x:",point);
                FPRINTF_CHECK(iTmpRet);
            }
            iTmpRet = fprintf(fp," 0x%08x",data[point]);
            FPRINTF_CHECK(iTmpRet);
        }
    }

    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    iTmpRet = snprintf_s(buff,sizeof(buff)-1,"ftpput -u data -p data 198.33.33.2 %s %s",(fileName? fileName : outFile),outFile);
    SNPRINTF_S_CHECK(iTmpRet, sizeof(buff)-1);
    dbgInfo("%s\n",buff);
    BspSystem(buff);
    dbgInfo("*** check file %s ***\n", outFile);
#endif
    return BSP_OK;
}

VOID IcHalShowAllRegsInfo(UINT32 ic, UINT32 round, UINT32 times)
{
    /*
    UINT32 uiBlockId = 0;
    UINT32 uiAcIdx   = 0;
    UINT32 loop      = 0;
    UINT32 uiCarrId  = 0;
    UINT32 data[8]   = {0};
    UINT8  fileName[256] = {0};
    UINT8  tftpCmd[256] = {0};
    INT32 fret = 0;
    INT32 sret = 0;
    FILE* fp = NULL;

    sret = snprintf_s(fileName,sizeof(fileName),"ic%d_round%d_times%d.txt", ic, round, times);
    SNPRINTF_S_CHECK(sret,sizeof(fileName));
    if(NULL == (fp = fopen(fileName, "w+")))
    {
        acprintf("openfile error\n");
        return ;
    }

    fret = fprintf(fp,"********** DL BANKs  base:0xCCA01A00 block:0x20000********** \n");
    FPRINTF_CHECK(fret);
    for(uiBlockId = 0; uiBlockId < 16; uiBlockId++)
    {
        //0x0000C
        BspHalAdaptGetRamSel(uiBlockId, &data[0]);
        BspHalAdaptGetAcPos(uiBlockId, &data[1]);
        fret = fprintf(fp,"0x0000C: block %2d, sel %2d, RamSel 0x%08X, AcPos 0x%08X\n", uiBlockId, 0, data[0], data[1]);
        FPRINTF_CHECK(fret);

        for(uiAcIdx = 0; uiAcIdx < 2; uiAcIdx++)
        {
            //0x00010+i*0x4
            BspHalAdaptGetAcSyncClear(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetPostLongDlyTimesCa(uiBlockId, uiAcIdx, &data[1]);
            BspHalAdaptGetAcGainCa(uiBlockId, uiAcIdx, &data[2]);
            fret = fprintf(fp,"0x00010+i*0x4: block %d, sel %2d, SyncClear 0x%08X, PostLongDlyTimesCa 0x%08X, GainCa 0x%08X\n", \
                          uiBlockId, uiAcIdx, data[0],data[1],data[2]);
            FPRINTF_CHECK(fret);

            //0x00018+i*0x4
            BspHalAdaptGetFrameId(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetOdevityFlag(uiBlockId, uiAcIdx, &data[1]);
            BspHalAdaptGetOdevityEn(uiBlockId, uiAcIdx, &data[2]);
            BspHalAdaptGetFrameIdEn(uiBlockId, uiAcIdx, &data[3]);
            BspHalAdaptGetAc5msEn(uiBlockId, uiAcIdx, &data[4]);
            BspHalAdaptGetOptFrameIdMk(uiBlockId, uiAcIdx, &data[5]);
            fret = fprintf(fp,"0x00018+i*0x4: block %d, sel %2d, FrameId 0x%08X, OdevityFlag 0x%08X, OdevityEn 0x%08X \n", \
                          uiBlockId, uiAcIdx, data[0],data[1],data[2]);
            FPRINTF_CHECK(fret);
            fret = fprintf(fp,"\t\t FrameIdEn 0x%08X, 5msEn 0x%08X, OptFrameIdMk 0x%08X \n", data[3],data[4],data[5]);
            FPRINTF_CHECK(fret);

            //0x00020+i*0x4
            BspHalAdaptGetAcDataSelCa(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetGpFrSelCaMod(uiBlockId, uiAcIdx, &data[1]);
            BspHalAdaptGetAcTddConfig(uiBlockId, uiAcIdx, &data[2]);
            BspHalAdaptGetAc10msSelCa(uiBlockId, uiAcIdx, &data[3]);
            fret = fprintf(fp,"0x00020+i*0x4: block %d, sel %2d, DataSelCa 0x%08X, GpFrSelCaMod 0x%08X, TddConfig 0x%08X, 10msSelCa 0x%08X\n", \
                          uiBlockId, uiAcIdx, data[0],data[1],data[2],data[3]);
            FPRINTF_CHECK(fret);

            //0x00028+i*0x4
            BspHalAdaptGetAcInsrtTimeCa(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAcCaliEnCa(uiBlockId, uiAcIdx, &data[1]);
            BspHalAdaptGetAcInsrtStartAddrCa(uiBlockId, uiAcIdx, &data[2]);
            BspHalAdaptGetGpIdCa(uiBlockId, uiAcIdx, &data[3]);
            fret = fprintf(fp,"0x00028+i*0x4: block %d, sel %2d, InsrtTimeCa 0x%08X, CaliEnCa 0x%08X, InsrtStartAddrCa 0x%08X, GpIdCa 0x%08X\n", \
                          uiBlockId, uiAcIdx, data[0],data[1],data[2],data[3]);
            FPRINTF_CHECK(fret);

            //0x00030+i*0x4
            BspHalAdaptGetAcInsrtEndAddr(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAcSeqLength(uiBlockId, uiAcIdx, &data[1]);
            fret = fprintf(fp,"0x00030+i*0x4: block %d, sel %2d, InsrtEndAddr 0x%08X, SeqLength 0x%08X", uiBlockId, uiAcIdx, data[0],data[1]);
            FPRINTF_CHECK(fret);

            //0x00038+i*0x4
            BspHalAdaptGetPreAcInsrtDlyCa(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x00038+i*0x4: block %d, sel %2d, InsrtDlyCa 0x%08X", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            //0x00040+i*0x4
            BspHalAdaptGetAcInsrtZeroNumCa(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x00040+i*0x4: block %d, sel %2d, InsrtZeroNumCa 0x%08X", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            //0x00048+i*0x4
            BspHalAdaptGetPostAcInsrtDlyCa(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x00048+i*0x4: block %d, sel %2d, PostAcInsrtDlyCa 0x%08X", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            //0x00050+i*0x4
            BspHalAdaptGetPostAcInsrtLongDlyCa(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x00050+i*0x4: block %d, sel %2d, PostAcInsrtLongDlyCa 0x%08X", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            for(loop=0; loop < 10; loop++)
            {
                //0x00058+i*0x4
                uiCarrId = uiAcIdx*10 + loop;
                BspHalAdaptGetTopDataSelCfg(uiBlockId, uiCarrId, &data[0]);
                fret = fprintf(fp,"0x00058+i*0x4: block %d, uiCarrId %2d, TopDataSelCfg 0x%08X", uiBlockId, uiCarrId, data[0]);
                FPRINTF_CHECK(fret);
            }

            //0x000A8+i*0x4
            BspHalAdaptGetAcSync(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x000A8+i*0x4: block %d, sel %2d, AcSync 0x%08X", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            //0x000B0+i*0x4
            BspHalAdaptGetAcInsertTimes(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x000B0+i*0x4: block %d, sel %2d, AcInsertTimes 0x%08X", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            //0x000B8+i*0x4
            BspHalAdaptGetFrGpPha(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x000B8+i*0x4: block %d, sel %2d, FrGpPha 0x%08X", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);
        }
    }


    fret = fprintf(fp,"********** UL BANKs  base:0xCB202000 block:0x20000********** \n");   
    FPRINTF_CHECK(fret);
    for(uiBlockId = 0; uiBlockId < 16; uiBlockId++)
    {
        for(uiAcIdx = 0; uiAcIdx < 2; uiAcIdx++)
        {
            //0x0000+i*0x4
            BspHalAdaptGetUlchDataDelayCfg(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetUlchFrDelayCfg(uiBlockId, uiAcIdx, &data[1]);
            fret = fprintf(fp,"0x0000+i*0x4: block %2d, sel %2d, DataDelayCfg 0x%08X, FrDelayCfg 0x%08X\n", uiBlockId, uiAcIdx, data[0], data[1]);
            FPRINTF_CHECK(fret);

            //0x0040+i*0x4
            BspHalAdaptGetAccbBankRouterCfg(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAccbDataRouterCfg(uiBlockId, uiAcIdx, &data[1]);
            BspHalAdaptGetAccbGpvldRouterCfg(uiBlockId, uiAcIdx, &data[2]);
            BspHalAdaptGetAccbChFr0RouterCfg(uiBlockId, uiAcIdx, &data[3]);
            BspHalAdaptGetAccbChFr1RouterCfg(uiBlockId, uiAcIdx, &data[4]);
            BspHalAdaptGetAccbChRouterCfg(uiBlockId, uiAcIdx, &data[5]);
            BspHalAdaptGetAccbChBnkRouterCfg(uiBlockId, uiAcIdx, &data[6]);
            fret = fprintf(fp,"0x0040+i*0x4: block %2d, sel %2d, BankRouterCfg 0x%08X, DataRouterCfg 0x%08X, GpvldRouterCfg 0x%08X\n", \
                           uiBlockId, uiAcIdx, data[0], data[1], data[2]);
            FPRINTF_CHECK(fret);
            fret = fprintf(fp,"\t\t ChFr0RouterCfg 0x%08X, ChFr1RouterCfg 0x%08X, ChRouterCfg 0x%08X  ChBnkRouterCfg 0x%08X\n", data[3],data[4],data[5],data[6]);
            FPRINTF_CHECK(fret);

            //0x0050+i*0x4
            BspHalAdaptGetAccbFr5msEn(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAccbFrNum(uiBlockId, uiAcIdx, &data[1]);
            BspHalAdaptGetAccbFrameIdMask(uiBlockId, uiAcIdx, &data[2]);
            BspHalAdaptGetAccbFrameId(uiBlockId, uiAcIdx, &data[3]);
            BspHalAdaptGetAccbFr5msId(uiBlockId, uiAcIdx, &data[4]);
            fret = fprintf(fp,"0x0050+i*0x4: block %2d, sel %2d, Fr5msEn 0x%08X, FrNum 0x%08X, FrameIdMask 0x%08X\n", \
                           uiBlockId, uiAcIdx, data[0], data[1], data[2]);
            FPRINTF_CHECK(fret);
            fret = fprintf(fp,"\t\t FrameId 0x%08X, Fr5msId 0x%08X\n", data[3],data[4]);
            FPRINTF_CHECK(fret);

            //0x0060+i*0x4
            BspHalAdaptGetAccbSnapEn(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAccbCbMode(uiBlockId, uiAcIdx, &data[1]);
            BspHalAdaptGetAccbFrameIdEn(uiBlockId, uiAcIdx, &data[2]);
            BspHalAdaptGetAccbCycleNum(uiBlockId, uiAcIdx, &data[3]);
            BspHalAdaptGetAccbRssiEn(uiBlockId, uiAcIdx, &data[4]);
            BspHalAdaptGetAccbFreeCbEn(uiBlockId, uiAcIdx, &data[5]);
            BspHalAdaptGetAccbRamRdEn(uiBlockId, uiAcIdx, &data[6]);
            fret = fprintf(fp,"0x0060+i*0x4: block %2d, sel %2d, SnapEn 0x%08X, CbMode 0x%08X, FrameIdEn 0x%08X\n", \
                           uiBlockId, uiAcIdx, data[0], data[1], data[2]);
            FPRINTF_CHECK(fret);
            fret = fprintf(fp,"\t\t CycleNum 0x%08X, RssiEn 0x%08X, FreeCbEn 0x%08X  RamRdEn 0x%08X\n", data[3],data[4],data[5],data[6]);
            FPRINTF_CHECK(fret);

            //0x0070+i*0x4
            BspHalAdaptGetAccbHoldNum(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAccbGetNum(uiBlockId, uiAcIdx, &data[1]);
            fret = fprintf(fp,"0x0070+i*0x4: block %2d, sel %2d, HoldNum 0x%08X, GetNum 0x%08X\n", uiBlockId, uiAcIdx, data[0], data[1]);
            FPRINTF_CHECK(fret);

            //0x0080+i*0x4
            BspHalAdaptGetAccbDelayNum(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x0080+i*0x4: block %2d, sel %2d, DelayNum 0x%08X\n", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            //0x0090+i*0x4
            BspHalAdaptGetAccbCbLength(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAccbVgaDelay(uiBlockId, uiAcIdx, &data[1]);
            fret = fprintf(fp,"0x0090+i*0x4: block %2d, sel %2d, CbLength 0x%08X, VgaDelay 0x%08X\n", uiBlockId, uiAcIdx, data[0], data[1]);
            FPRINTF_CHECK(fret);

            //0x00a0+i*0x4
            BspHalAdaptGetAccbFrTaDelay(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x00a0+i*0x4: block %2d, sel %2d, FrTaDelay 0x%08X\n", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);

            //0x00b0+i*0x4
            BspHalAdaptGetAccbInslotWaitAbnml(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAccbIntCnt(uiBlockId, uiAcIdx, &data[1]);
            fret = fprintf(fp,"0x00b0+i*0x4: block %2d, sel %2d, InslotWaitAbnml 0x%08X, AccbIntCnt 0x%08X\n", uiBlockId, uiAcIdx, data[0], data[1]);
            FPRINTF_CHECK(fret);

            //0x00c0+i*0x4
            BspHalAdaptGetAccbAcInslotDelay(uiBlockId, uiAcIdx, &data[0]);
            BspHalAdaptGetAccbAcInslotEn(uiBlockId, uiAcIdx, &data[1]);
            fret = fprintf(fp,"0x00c0+i*0x4: block %2d, sel %2d, InslotDelay 0x%08X, InslotEn 0x%08X\n", uiBlockId, uiAcIdx, data[0], data[1]);
            FPRINTF_CHECK(fret);

            //0x00d0+i*0x4
            BspHalAdaptGetAccbFrMeas(uiBlockId, uiAcIdx, &data[0]);
            fret = fprintf(fp,"0x00d0+i*0x4: block %2d, sel %2d, AccbFrMeas 0x%08X\n", uiBlockId, uiAcIdx, data[0]);
            FPRINTF_CHECK(fret);
        }

        //0x00e0
        BspHalAdaptGetAccbDoneInt(uiBlockId, &data[0]);
        fret = fprintf(fp,"0x00e0: block %2d, sel %2d, AccbDoneInt 0x%08X\n", uiBlockId, uiAcIdx, data[0]);
        FPRINTF_CHECK(fret);

        //0x00e4
        BspHalAdaptGetAccbWarningClr(uiBlockId, &data[0]);
        BspHalAdaptGetAccbDoneIntClr(uiBlockId, &data[1]);
        fret = fprintf(fp,"0x00e4: block %2d, sel %2d, WarningClr 0x%08X, DoneIntClr 0x%08X\n", uiBlockId, uiAcIdx, data[0], data[1]);
        FPRINTF_CHECK(fret);

        //0x00e8
        BspHalAdaptGetAccbDoneIntEn(uiBlockId, &data[0]);
        fret = fprintf(fp,"0x00e8: block %2d, sel %2d, DoneIntEn 0x%08X\n", uiBlockId, uiAcIdx, data[0]);
        FPRINTF_CHECK(fret);
    }

    fret = fclose(fp);
    FCLOSE_CHECK(fret);

    sret = snprintf_s(tftpCmd, sizeof(tftpCmd), "ftpput -u IcHalShowAllRegsInfo -p IcHalShowAllRegsInfo 199.33.33.2 %s %s",fileName,fileName);
    SNPRINTF_S_CHECK(sret,sizeof(tftpCmd));
    BspSystem(tftpCmd);
    acprintf("\nCheck File at %s\n\n", fileName);
    */
}

VOID IcHalRoundCfgDebug(UINT32 ic)
{
	UINT32 round = 0;
	UINT32 times = 0;
	
	round = 0;
	times = 0;
    acprintf("***************** round %d times %d *****************\n\n", round, times);
	IcHalDlAcRoundCfg(ic, round);
	IcHalShowAllRegsInfo(ic, round, times);

	round = 1;
	times = 1;
    acprintf("\n***************** round %d times %d *****************\n\n", round, times);
	IcHalDlAcRoundCfg(ic, round);
	IcHalShowAllRegsInfo(ic, round, times);

	round = 0;
	times = 2;
    acprintf("\n***************** round %d times %d *****************\n\n", round, times);
	IcHalDlAcRoundCfg(ic, round);
	IcHalShowAllRegsInfo(ic, round, times);

}
	
UINT32 goac(UINT32 sendMsg)
{
    return 0;
}

UINT32 IcHalSetAcPileSeqPwrGear(UINT32 acPwrGear)
{
    return BSP_OK;
}

UINT32 BspAcChanMapInfoInit(const T_AC_CHN_MAP *pLinkMap, UINT32 linkNum)
{
    s_acChnMapInfo  = (T_AC_CHN_MAP *) pLinkMap;
    s_acChnMapNum   = linkNum;
    return BSP_OK;
}

UINT32 BspGetAcMapInfo(const T_AC_CHN_MAP **pptMap, UINT32 *ulpSize)
{
    INPUT_POINTER_CHECK(pptMap);
    INPUT_POINTER_CHECK(ulpSize);
    *pptMap     = (T_AC_CHN_MAP *)s_acChnMapInfo;
    *ulpSize    = s_acChnMapNum;

    if (NULL == (*pptMap))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 IcHalGetRfChnByAntInfo(UINT32 antId,UINT32 antChn,UINT32 *pRfChan)
{
    UINT32 idx  = 0;
    //UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    T_AC_CHN_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pRfChan);

    BspGetAcMapInfo((const T_AC_CHN_MAP **)&pMap, &size);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->linkInfo[AC_ANTID] == antId &&
            pMap->linkInfo[AC_ANTCHN] == antChn)
        {
            *pRfChan = pMap->linkInfo[AC_RFCHN];
             dbgInfoEx("%s>> antId'%d, antChn'%d, RfChn = %d\n",__FUNCTION__,antId,antChn,*pRfChan);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

UINT32 SetUlBankWaitDelay(UINT32 bandWidth, UINT32 delay)
{
    dbgInfoEx("%s:Set BandWidth:%d, Delay:%d \n", __FUNCTION__, bandWidth, delay);
    switch(bandWidth)
    {
        case BANDWIDTH_100M_MHz://NR 100M
        case BANDWIDTH_90M_MHz: //NR 90M
        {
            IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelay = delay;
            break;
        }
        case BANDWIDTH_80M_MHz://NR 80M
        {
            IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr80M = delay;
            break;
        }
        case BANDWIDTH_60M_MHz://NR 60M
        {
            IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr60M = delay;
            break;
        }
        case BANDWIDTH_50M_MHz://NR 50M
        {
            IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelay50MNr = delay;
            break;
        }
        case BANDWIDTH_40M_MHz://NR 40M
        {
            IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelay40MNr = delay;
            break;
        }
        case BANDWIDTH_30M_MHz://NR 30M
        {
            IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr30M = delay;
            break;
        }
        case BANDWIDTH_20M_MHz://NR 20M
        {
            IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr20M = delay;
            break;
        }
        default:
            dbgInfoEx("%s:Can't find this BandWidth:%d \n", __FUNCTION__, bandWidth);
            break;
    }

    return BSP_OK;
}

UINT32 SetLteUlBankWaitDelay(INT32 bandWidth, INT32 delay)
{
    dbgInfoEx("%s:Set BandWidth:%d, Delay:%d \n", __FUNCTION__, bandWidth, delay);
    switch(bandWidth)
    {
        case BANDWIDTH_60M_MHz://LTE??? 60M
        {
            IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelayPasteCarr = delay;
            break;
        }
        case BANDWIDTH_20M_MHz://LTE 20M
        {
            IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelay = delay;
            break;
        }
        case BANDWIDTH_15M_MHz://LTE 15M
        {
            IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelayLte15M = delay;
            break;
        }
        case BANDWIDTH_10M_MHz://LTE 10M
        {
            IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelayLte10M = delay;
            break;
        }
        default:
            dbgInfoEx("%s:Can't find this BandWidth:%d \n", __FUNCTION__, bandWidth);
            break;
    }

    return BSP_OK;
}

UINT32 GetUlBankWaitDelay(VOID)
{
    dbgInfo("%s:Get NR  BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_100M_MHz, IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelay);
    dbgInfo("%s:Get NR  BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_80M_MHz, IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr80M);
    dbgInfo("%s:Get NR  BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_60M_MHz, IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr60M);
    dbgInfo("%s:Get NR  BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_50M_MHz, IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelay50MNr);
    dbgInfo("%s:Get NR  BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_40M_MHz, IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelay40MNr);
    dbgInfo("%s:Get NR  BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_30M_MHz, IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr30M);
    dbgInfo("%s:Get NR  BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_20M_MHz, IcHalAcCfgPara.acNrCfgPara.acUlBankCompensateWaitDelayNr20M);
    dbgInfo("%s:Get LTE BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_60M_MHz, IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelayPasteCarr);
    dbgInfo("%s:Get LTE BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_20M_MHz, IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelay);
    dbgInfo("%s:Get LTE BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_15M_MHz, IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelayLte15M);
    dbgInfo("%s:Get LTE BandWidth:%d, Delay:%d \n", __FUNCTION__, BANDWIDTH_10M_MHz, IcHalAcCfgPara.acLteCfgPara.acUlBankCompensateWaitDelayLte10M);
    dbgInfo("%s:Get AC TA_C_Dl:%d, TA_C_Ul:%d \n", __FUNCTION__,avgTaDl,avgTaUl);

    return BSP_OK;
}

//根据接收通道配置上行接收路由
UINT32 IcHalUlSetUlBankCatchRamRoundCfg(UINT32 ic, A53R8AcDebugShareInfo* a53R8ShareInfo)
{
    UINT32 uiAntId     = 0;
    UINT32 uiBlockId   = 0;
    UINT32 uiBankSel   = 0;
    UINT32 uiVgaChnSel = 0;
    UINT32 uiVgaDelay  = 0;
    UINT32 icMaxAntNo  = 0;
    UINT32 uiDifChn    = 0;

    //参数获取
    icMaxAntNo = a53R8ShareInfo->icMaxAntNo;
    //静态配置
    IcHalSetUlBankCatchRamPreCfg(a53R8ShareInfo);
    //Parameter check
    INPUT_AC_PARAMETER_CHECK(ic, AC_IC_NUM);
    for(uiAntId = 0; uiAntId < icMaxAntNo; uiAntId++)
    {
        if(1 == ulAcBlockBankBandInfo[ic].bBInfo[0].ulIsSet[uiAntId])
        {
            uiBankSel   = ulAcBlockBankBandInfo[ic].bBInfo[0].ulBank[uiAntId];
            uiVgaChnSel = ulAcBlockBankBandInfo[ic].bBInfo[0].ulVgaChn[uiAntId];
            uiVgaDelay  = ulAcBlockBankBandInfo[ic].bBInfo[0].ulVgaDelay[uiAntId];
            uiDifChn    = ulAcBlockBankBandInfo[ic].bBInfo[0].ulDifChn[uiAntId];
            //上行AC数据路由配置
            IcHalApiSetAccbBankRouterCfg(uiBlockId, uiDifChn, uiBankSel);
            //VGA路由配置
            IcHalApiSetAccbChRouterCfg(uiBlockId, uiDifChn, uiVgaChnSel);
            IcHalApiSetAcVgaRouterCfg(uiBlockId, uiDifChn, uiVgaChnSel);
            //VGA延时配置
            IcHalApiSetAccbVgaDelay(uiBlockId, uiAntId, uiVgaDelay);
            dbgInfoEx("[%s]:ic %d, uiBankSel %d, uiDifChn:%d, uiVgaChnSel %d, uiVgaDelay %d\n", __FUNCTION__, ic, uiBankSel, uiDifChn, uiVgaChnSel, uiVgaDelay);
        }
    }

    return BSP_OK;
}

/////////////////////////////////////////////////////////////////FrameId 配置////////////////////////////////////////////////////////////////
UINT32 IcHalSetAcSyncPara(UINT32 acSyncEn,UINT32 uiFrameNo)
{
     //帧号配置
    IcHalApiSetACSyncFramenum(uiFrameNo);
    //acsync 使能
    IcHalApiSetACEn(acSyncEn);

    return BSP_OK;
}

/////////////////////////////////////////////////////////////////帧号配置////////////////////////////////////////////////////////////////
UINT32 IcHalSetDlbankSendSameFrameNo(UINT32 uiFrameIdEn,UINT32 uiFrameNo)
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntId   = 0;

    ///寄存器配置
    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        //配置的帧号
        IcHalApiSetFrameId(uiBlockId, uiAntId, uiFrameNo);
        ///帧号使能
        IcHalApiSetFrameIdEn(uiBlockId, uiAntId, uiFrameIdEn);
    }

    return BSP_OK;
}

/////////////////////////////////////////////////////////////////FrameId 配置////////////////////////////////////////////////////////////////
UINT32 IcHalSetUlbankSmpSameFrameNo(UINT32 uiFrameIdEn,UINT32 uiFrameNo)
{
    UINT32 uiBlockId = 0;
    UINT32 uiAntId   = 0;

    ///寄存器配置
    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        //配置的帧号
        IcHalApiSetAccbFrameId(uiBlockId, uiAntId, uiFrameNo);
        ///帧号使能
        IcHalApiSetAccbFrameIdEn(uiBlockId, uiAntId, uiFrameIdEn);
    }

    return BSP_OK;
}

UINT32 IcHalSetFrPara(UINT32 acType,T_ICHAL_ACPARA* acPara)
{
    UINT32 uiBlockId     = 0;
    UINT32 uiAntId       = 0;
    UINT32 ui10msFrEn    = 0;
    UINT32 uiRssiOff     = 0;
    UINT32 uiMaxFrNum    = 1;
    UINT32 uiFrameOff    = 0;
    UINT32 uiAcSyncOff   = 0;
    UINT32 uiFrameNo     = 0;
    UINT32 uiDlPreFrSel  = 1;      //0选择10ms帧头
    UINT32 ui10msFrPeriod = 7372800; //对应10ms帧频
    UINT32 uiSecMax      = 9;
    UINT32 uiSecSel      = 0;
    UINT32 uiAcOdevityEn = 1;       //高位为偶帧，1表示使能，低位为奇帧，1表示使能
    UINT32 uiInsertPos   = 1023;    //AC不需要切换，都配置为1023
    UINT32 uiFrSelType   = 1;
    UINT32 uiCbLength    = 1023;
    UINT32 uiAntStart = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();

    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        uiAntStart = 4;
    }

    ///寄存器配置
    for(uiAntId = uiAntStart; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        //配置帧频分频周期
        IcHalApiSetAcFrPeriod(uiBlockId, uiAntId, ui10msFrPeriod);
        //帧频帧头延时配置
        IcHalApiSetAcFrDly(uiBlockId, uiAntId, 0); // AC使用时配置为0，UE定位根据需要延迟，延迟后锁存无线帧号
        //ULABNK 5ms帧频去使能
        IcHalApiSetAccbFr5msEn(uiBlockId, uiAntId, ui10msFrEn);
        //有效帧头数量
        IcHalApiSetAccbFrNum(uiBlockId, uiAntId, uiMaxFrNum); //AC配置为1
        ///RSSI去使能
        IcHalApiSetAccbRssiEn(uiBlockId, uiAntId, uiRssiOff);

        for(uiSecSel = 0;uiSecSel < uiSecMax;uiSecSel++)
        {
            //AC插数不受奇偶帧限制
            IcHalApiSetOdevityFlag(uiBlockId, uiAntId, uiSecSel, uiAcOdevityEn);
            //AC启动后的起始延时值切换位置配置
            IcHalApiSetFrIdPos(uiBlockId, uiAntId, uiSecSel, uiInsertPos);
        }
        //无线帧号匹配方式
        IcHalApiSetFrameIdSel(uiBlockId, uiAntId, uiFrSelType);
        //AC上行采数RAM深度配置1024
        IcHalApiSetAccbCbLength(uiBlockId, uiAntId, uiCbLength);
        //10ms分频配置
        IcHalApiSetAcSnap10msFrDiv(uiBlockId, uiAntId, ui10msFrPeriod);
    }
    //DLPRE 输出5ms AC同步帧头周期选择
    IcHalApiSetACSyncFrPeriodMode(uiDlPreFrSel);
    //acsync
    IcHalSetAcSyncPara(uiAcSyncOff,uiFrameNo);
    //FrameEN is off
    IcHalSetDlbankSendSameFrameNo(uiFrameOff,uiFrameNo);
    //FrameEN is off
    IcHalSetUlbankSmpSameFrameNo(uiFrameOff,uiFrameNo);

    return BSP_OK;
}
/////////////////////////////////////////////////////////////////IcHalAcSetDlGpEn////////////////////////////////////////////////////////////////
UINT32 IcHalAcSetDlGpEn(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{
    UINT32 uiGpEn       = 0;
    UINT32 uiIcMaxAntNo = 0;
    UINT32 uiAntNum     = 0;
    UINT32 uiAntStart   = 0;
    UINT32 uiAntTmp     = 0;
    UINT32 uiBandNo     = 0;
    UINT32 uiDifChipId  = 0;
    UINT32 uiDifChn     = 0;
    UINT32 uiRet        = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();

    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        uiAntStart = 4;
    }
    else
    {
        uiAntStart = IcHalAcCfgPara.acStartChan;
    }

    ///GP 打开或关闭
    if(AC_TYPE_STOP == acType)
    {
        uiGpEn = 0;
    }
    else
    {
        uiGpEn = 1;
    }
    //获取IC内部天线数目
    uiIcMaxAntNo = IcHalAcCfgPara.acIcMaxAntNo;
    ///GP 设置
    for(uiAntNum = uiAntStart; uiAntNum < uiIcMaxAntNo; uiAntNum++)
    {
        uiAntTmp = BspGetAntNoByDlAcRoundAntSel(0, BspGetRpuId(), uiAntNum);
        CHECK_AC_ANT_VALID(uiAntTmp);
        dbgInfoEx("[%s], valid ant:%d \n", __FUNCTION__, uiAntTmp);
        uiAntTmp = MIN(uiAntTmp, AC_DL_ANTS_NUM);
        uiAntTmp = uiAntTmp + 1; //对应map表中的天线号列，需要加1
        uiRet = BspGetDifInfoByAntInfo(uiAntTmp, uiBandNo, TX, &uiDifChipId, &uiDifChn);
        RESULT_CHECK_CONTINUE(uiRet);
        dbgInfoEx("[%s], uiDifChn:%d \n", __FUNCTION__, uiDifChn);
        IcHalSetDlGpEn(uiDifChn, radioMode, carrNo, uiGpEn);
    }
    IcHalApiSetAcCfgEn(uiGpEn);//加塞接口

    return BSP_OK;
}
/////////////////////////////////////////////////////////////////IcHalSetAcInsertSmpDataLen////////////////////////////////////////////////////////////////
UINT32 IcHalSetAcRamPara(UINT32 seqLen,UINT32 cpLen)
{
    //内插AC数据长度
    IcHalSetAcInsertData(seqLen, cpLen);

    //上行RAM采集数据长度配置
    IcHalSetUlAcDataLen(seqLen);

    //上行ACRAM 去使能
    IcHalSetUlBankAllBlockCatchRamEnOff();

    return BSP_OK;
}

UINT32 IcHalSetAcOrAAcMode(UINT32 Mode)
{
    UINT32 uiAntId   = 0;
    UINT32 uiBlockId = 0;
    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        IcHalApiSetAcAacMode(uiBlockId, uiAntId, Mode);
    }

    return BSP_OK;
}
/////////////////////////////////////////////////////////////////根据帧结构进行适配////////////////////////////////////////////////////////////////
UINT32 IcHalGetFrameTypeForAc(UINT32 uCarrNo,UINT32 radioMode)
{
    UINT32 uFrame     = 0;
    UINT32 uFrameType = 0;

    IcHalApiAcGetTddInfo(uCarrNo,0,radioMode,&uFrame);

    if((FRAME_TYPE_2P5MS == uFrame)||(FRAME_TYPE_5MS == uFrame))
    {
        uFrameType = 1;
    }
    else if(FRAME_TYPE_10MS == uFrame)
    {
        uFrameType = 2;
    }
    else if(FRAME_TYPE_20MS == uFrame)
    {
        uFrameType = 4;
    }
    else
    {
        uFrameType = 1;
    }

    return uFrameType;
}

FLOAT IcHalGetDLFrameDly(UINT32 uiCalAntNum, UINT32 uiCarrNo, UINT32 uiRadioMode)
{
    UINT32 uiFrameType      = 0;
    UINT32 uiDFrameNum      = 0;
    UINT32 uiDSymNum        = 0;
    UINT32 uiDFrameUsNr     = DFRAME_US_NR;
    FLOAT  fDlFrameUsNr     = DL_OTHER_SYM_US_NR;
    UINT32 uiDFrameUsLte    = DFRAME_US_LTE;
    FLOAT  fDlFrameUsLte    = DL_OTHER_SYM_US_LTE;
    FLOAT  fLongCpDiff      = DL_LONGCP_DIFF_LTE;//LTE 20M为例，16clk=0.52us
    FLOAT  fProtTs          = PRORT_TS;//8Ts保护间隔
    FLOAT  fTimeDlyUs       = 0;
    FLOAT  fLongCpUsSum     = 0;
    UINT32 uiLongCpSymNum   = 0;
    T_CarrTddIndCfg pCfg    = {0};

    IcHalApiAcGetTddInfo(uiCarrNo,0,uiRadioMode,&uiFrameType);
    dbgInfo("[%s]: uiFrameType:%d \n", __FUNCTION__, uiFrameType);

    IcHalApiGetTddByCarrNo(uiCarrNo, uiCalAntNum, uiRadioMode, &pCfg);

    //pCfg.uiDlSymbolNum中存的是D时隙的符号个数，包括D和S中的DL
    uiDFrameNum = pCfg.uiDlSymbolNum[0] / 14;
    uiDSymNum   = pCfg.uiDlSymbolNum[0] % 14;

    dbgInfo("[%s]: uiDFrameNum:%d, uiDSymNum:%d \n", __FUNCTION__, uiDFrameNum, uiDSymNum);

    if(RADIO_STANDARD_5G == uiRadioMode)
    {
        fTimeDlyUs = (uiDFrameNum * uiDFrameUsNr) + (uiDSymNum * fDlFrameUsNr);
    }
    else if(RADIO_STANDARD_LTE_TDD == uiRadioMode)
    {
        uiLongCpSymNum = (LTE_SLOT_SYM_NUM > uiDSymNum)? 1 : 2;//LTE 7个符号1个长CP
        fLongCpUsSum = fLongCpDiff * uiLongCpSymNum + fProtTs;   
        fTimeDlyUs = (uiDFrameNum * uiDFrameUsLte) + (uiDSymNum * fDlFrameUsLte) + fLongCpUsSum;
    }
    else
    {
        //do nothing
    }
    dbgInfoEx("[%s]: fTimeDlyUs:%f, uiLongCpDiff:%f,fLongCpSum:%f\n", __FUNCTION__, fTimeDlyUs, fLongCpDiff, fLongCpUsSum);

    return fTimeDlyUs;
}


/**********************************************ko int*******************************************************/
//4.0 下行AC, 耦合通道采数单独使能
UINT32 IcHalDLSetAccbDoneIntEn(VOID)
{
    UINT32 uiBlockId       = 0;
    UINT32 uiEN            = 1;
    UINT32 uiDifChn        = 0;
    UINT8 *pucBaseAddr = NULL;
    A53R8AcDebugShareInfo* shareInfo = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    shareInfo = (A53R8AcDebugShareInfo*)((VOID *)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr));
    uiDifChn  = shareInfo->dlCatchDifChn;

    IcHalApiSetAccbDoneIntEn(uiBlockId, uiDifChn, uiEN);

    return BSP_OK;
}

UINT32 BspTestKoInsertAndCatchDataDL(VOID)
{
    UINT32 uiRpuId = 0;

    IcHalSetUlBankCatchRamClearAllInts();///Int Clr
    IcHalDLSetAccbDoneIntEn();
    IcHalSetDlBankAcInsertOnOff(SWITCH_OFF);
    IcHalSetDlBankAcSequenceInsertRoundCfg(uiRpuId, 0);
    IcHalSetDlBankAcInsertOnOff(SWITCH_ON);
    IcHalSetUlBankCatchRamEnOn();//ACRAM EN

    return BSP_OK;
}

UINT32 IcHalSetAccbDoneIntEn(VOID)
{
    UINT32 uiAntId   = 0;
    UINT32 uiBlockId = 0;
    UINT32 uiEN      = 1;

    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        IcHalApiSetAccbDoneIntEn(uiBlockId, uiAntId, uiEN);   //使能接收中断
    }

    return BSP_OK;
}

UINT32 IcHalSetUlAllBankCatchRamEnOn(VOID)
{
    UINT32 uiAntId     = 0;
    UINT32 uiBlockId   = 0;
    UINT32 uiEN        = 1;
    UINT32 icMaxAntNo  = 0;
    UINT8 *pucBaseAddr = NULL;
    UINT32 ulBitMap    = 0;
    A53R8AcDebugShareInfo* shareInfo = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr);
    icMaxAntNo  = shareInfo->icMaxAntNo;
    ulBitMap    = shareInfo->ulBitMap;

    for(uiAntId = 0; uiAntId < icMaxAntNo; uiAntId++)
    {
        if(ANT_IS_SELECT == BIT_VAL(ulBitMap, uiAntId))
        {
            IcHalApiSetAccbSnapEn(uiBlockId, uiAntId, uiEN);   //使能接收中断
        }
    }

    return BSP_OK;
}

UINT32 BspTestKoInsertAndCatchDataUL(VOID)
{
    UINT32 uiRpuId = 0;

    IcHalSetUlBankCatchRamClearAllInts(); //Int Clr
    IcHalSetAccbDoneIntEn();
    IcHalSetDlBankAcInsertOnOff(SWITCH_OFF);
    IcHalUlSetDlBankAcSequenceInsertRoundCfg(uiRpuId, 0);
    IcHalSetDlBankAcInsertOnOff(SWITCH_ON);
    IcHalSetUlAllBankCatchRamEnOn(); //ACRAM EN

    return BSP_OK;
}

UINT32 BspSetAcSwitchAntMask(UINT32 acType, T_ICHAL_ACPARA* acPara)
{
    UINT32 uiTddSel     = 0;
    UINT32 uiTxChanMask = 0;
    UINT32 uiRxChanMask = 0;
    UINT32 uiDlAntNum   = 0;
    UINT32 uiUlAntNum   = 0;
    UINT32 uiAntLoop    = 0;
    UINT32 uiRet        = 0;
    UINT32 uiAntId      = 0;
    UINT32 uiChannum    = 0;
    UINT32 uiBspChn     = 0;
    UINT32 uiCatchChn   = 0;
    UINT32 uiSendChn    = 0;
    UINT8* baseAddr     = NULL;
    A53R8AcDebugShareInfo* shareInfo = NULL;
    UINT32 uiAntStart   = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();

    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        uiAntStart = 4;
    }
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error!\n",__FUNCTION__);
        return BSP_ERROR;    
    }
    //coverity[cert_exp36_c_violation:SUPPRESS] 
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + baseAddr);
    if(AC_TYPE_DL == acType)
    {
        uiDlAntNum = acPara->dlAntNum;
        for(uiAntLoop = uiAntStart;uiAntLoop < uiDlAntNum;uiAntLoop++)
        {
            uiAntId = BspGetAntNoByDlAcRoundAntSel(0, BspGetRpuId(), uiAntLoop);
            CHECK_AC_ANT_VALID(uiAntId);
            uiAntId = MIN(uiAntId, AC_DL_ANTS_NUM);
            uiAntId = uiAntId + 1; //对应map表中的天线号列，需要加1
            uiRet = BspGetBspChnByAntId(uiAntId, TX, &uiChannum, &uiBspChn);
            RETURN_RESULT_CHECK(uiRet);
            VAR_BIT_SET(uiTxChanMask, uiBspChn);
            dbgInfoEx("[%s] acType:%d, uiAntLoop:%d, uiBspChn:%d\n", __FUNCTION__, acType, uiAntLoop, uiBspChn);
        }
        if(BspGetRpuId() == shareInfo->catchAcRpuId)
        {
            //coverity[cert_exp39_c_violation:SUPPRESS]
            uiCatchChn = shareInfo->acCatchDataChan + 1;
            uiRet = BspGetBspChnByAntId(uiCatchChn, RX, &uiChannum, &uiBspChn);
            RETURN_RESULT_CHECK(uiRet);
            VAR_BIT_SET(uiRxChanMask, uiBspChn);
        }
        uiRet = BspSetAcMuxSpcChanMask(uiTddSel, acType, uiTxChanMask, uiRxChanMask);
        RETURN_RESULT_CHECK(uiRet);
        dbgInfo("[%s] acType:%d, uiCatchChn:%d, uiBspChn:%d\n", __FUNCTION__, acType, uiCatchChn, uiBspChn);
    }
    else if(AC_TYPE_UL == acType)
    {
        uiUlAntNum = acPara->acUlRoundNo;
        for(uiAntLoop = 0;uiAntLoop < uiUlAntNum;uiAntLoop++)
        {
            uiAntId = BspGetAntNoByDlAcRoundAntSel(0, BspGetRpuId(), uiAntLoop);
            CHECK_AC_ANT_VALID(uiAntId);
            uiAntId = MIN(uiAntId, AC_UL_ANTS_NUM);
            uiAntId = uiAntId + 1; //对应map表中的天线号列，需要加1
            uiRet = BspGetBspChnByAntId(uiAntId, RX, &uiChannum, &uiBspChn);
            RETURN_RESULT_CHECK(uiRet);
            VAR_BIT_SET(uiRxChanMask, uiBspChn);
            dbgInfoEx("[%s] acType:%d, uiAntLoop:%d, uiBspChn:%d\n", __FUNCTION__, acType, uiAntLoop, uiBspChn);
        }
        if(BspGetRpuId() == shareInfo->sendAcRpuId)
        {
            //coverity[cert_exp39_c_violation:SUPPRESS]
            uiSendChn = shareInfo->acSendDataChan + 1;
            uiRet = BspGetBspChnByAntId(uiSendChn, TX, &uiChannum, &uiBspChn);
            RETURN_RESULT_CHECK(uiRet);
            VAR_BIT_SET(uiTxChanMask, uiBspChn);
        }
        uiRet = BspSetAcMuxSpcChanMask(uiTddSel, acType, uiTxChanMask, uiRxChanMask);
        RETURN_RESULT_CHECK(uiRet);
        dbgInfo("[%s] acType:%d, uiSendChn:%d, uiBspChn:%d\n", __FUNCTION__, acType, uiSendChn, uiBspChn);
    }
    else if(AC_TYPE_STOP == acType)
    {
        uiRet = BspSetAcMuxSpcChanMask(uiTddSel, acType, uiTxChanMask, uiRxChanMask);
        RETURN_RESULT_CHECK(uiRet);
    }
    else
    {
        dbgErr("[%s] unknown ac type:%d \n", __FUNCTION__, acType);
    }
    dbgInfo("[%s] acType:%d, uiTxChanMask:0x%x, uiRxChanMask:0x%x\n", __FUNCTION__, acType, uiTxChanMask, uiRxChanMask);

    return BSP_OK;
}

/**********************************************************************FDD API*********************************************************************/
/////////////////////////////////////////////////////////////////帧号配置////////////////////////////////////////////////////////////////
UINT32 IcHalSetDlbankFddFrameNo(UINT32 uiFrameIdEn, UINT32 uiFrameNo, UINT32 uiAntId)
{
    UINT32 uiBlockId = 0;

    //配置的帧号
    IcHalApiSetFrameId(uiBlockId, uiAntId, uiFrameNo);
    ///帧号使能
    IcHalApiSetFrameIdEn(uiBlockId, uiAntId, uiFrameIdEn);

    return BSP_OK;
}

/////////////////////////////////////////////////////////////////FrameId 配置////////////////////////////////////////////////////////////////
UINT32 IcHalSetUlbankFddFrameNo(UINT32 uiFrameIdEn, UINT32 uiFrameNo, UINT32 uiAntId)
{
    UINT32 uiBlockId = 0;

    //配置的帧号
    IcHalApiSetAccbFrameId(uiBlockId, uiAntId, uiFrameNo);
    ///帧号使能
    IcHalApiSetAccbFrameIdEn(uiBlockId, uiAntId, uiFrameIdEn);

    return BSP_OK;
}

UINT32 g_ProtectTime = 250000;

VOID setProtectTime(UINT32 time)
{
    g_ProtectTime = time;
}

//开关保护间隔
UINT32 BspFddGetSwitchProtectTime(UINT32 radio)
{
    return g_ProtectTime;  //单位ns,250us
}

//长插0间隔
UINT32 BspGetUlLongZeroAcTime(UINT32 radio)
{
    return 400000;  //单位ns，400us
}

//获取延时补偿值
UINT32 BspFddGetPreciseCompDly(UINT32 actype,UINT32 uiacSample)
{
    FLOAT   factorTA_c = 0.0f;
    UINT32  avgTA      = 0;
    UINT32  avgdly     = 0;

    factorTA_c = (FLOAT)uiacSample /(FLOAT)CLK_RATE_245P76;

    //获取精时延均值
    if(AC_TYPE_FDD_DL == actype)
    {
        avgTA = avgTaDl;
    }
    else if(AC_TYPE_FDD_UL == actype)
    {
        avgTA = avgTaUl;
    }
    else
    {
        avgTA = avgTaDl;
    }
    avgdly = avgTA * factorTA_c;

    return avgdly;
}

//获取内插前延时
UINT32 BspGetFddAcInsertDelay(UINT32 acType, UINT32 radio, UINT32 bw,UINT32 slotNo, UINT32 subframeNo)
{
    UINT32 uiDelay        = 0;
    UINT32 uiSample       = 0;
    FLOAT  factor         = 0.0f;
    UINT32 pasteCarrFlag  = 0;

    uiSample = bspGetSampleFromBw(radio, bw, pasteCarrFlag);

    if(BSP_RADIO_STANDARD_FDD_5G == radio)
    {
        uiDelay = slotNo * PER_SLOT_NUM_NR;
        factor = (FLOAT)uiSample / PER_SLOT_NUM_NR;
        uiDelay  = factor * uiDelay;
    }
    else if(RADIO_STANDARD_LTE_FDD == radio)
    {
        uiDelay = subframeNo * PER_SUB_FRAME_NUM_LTE;
        factor = (FLOAT)uiSample / PER_SUB_FRAME_NUM_LTE;
        uiDelay = factor * uiDelay;
    }
    else
    {
        dbgInfo("[%s] unkonwn ac type\n", __FUNCTION__);
    }

    dbgInfoEx("[%s]:radio 0x%x,factor=%f, uiDelay=%d \n", __FUNCTION__, radio, factor, uiDelay);

    return uiDelay;
}

UINT32 setNrAcSampleDly(UINT32 bandWidth)
{
    UINT32 CompensateWaitDlyPoint = 0;
    T_ICHAL_ACPARA* acPara           = NULL;
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();

    switch(bandWidth)
    {
        case BANDWIDTH_100M_MHz://NR 100M
        case BANDWIDTH_90M_MHz://NR 90M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelay;
            break;
        }
        case BANDWIDTH_80M_MHz://NR 80M
        case BANDWIDTH_70M_MHz://NR 70M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr80M;
            break;
        }
        case BANDWIDTH_60M_MHz://NR 60M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr60M;
            break;
        }
        case BANDWIDTH_50M_MHz://NR 50M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelay50MNr;
            break;
        }
        case BANDWIDTH_40M_MHz://NR 40M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelay40MNr;
            break;
        }
        case BANDWIDTH_30M_MHz://NR 30M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr30M;
            break;
        }
        case BANDWIDTH_25M_MHz://NR 25M
        case BANDWIDTH_20M_MHz://NR 20M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr20M;
            break;
        }
        case BANDWIDTH_10M_MHz://NR 10M
        {
            CompensateWaitDlyPoint = acPara->acNrCfgPara.acUlBankCompensateWaitDelayNr10M;
            break;
        }
        default:
            break;
    }
    return CompensateWaitDlyPoint;
}

UINT32 setLteAcSampleDly(UINT32 bandWidth)
{
    UINT32 CompensateWaitDlyPoint = 0;
    T_ICHAL_ACPARA* acPara           = NULL;
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    switch(bandWidth)
    {
        case BANDWIDTH_20M_MHz:
        {
            CompensateWaitDlyPoint = acPara->acLteCfgPara.acUlBankCompensateWaitDelay;
            break;
        }
        case BANDWIDTH_10M_MHz:
        {
            CompensateWaitDlyPoint = acPara->acLteCfgPara.acUlBankCompensateWaitDelayLte10M;
            break;
        }
        default:
        break;
    }
    
    return CompensateWaitDlyPoint;
}

UINT32 BspGetAcFddUlCompensateWaitDly(UINT32 radioMode,UINT32 bandWidth)
{
    UINT32 CompensateWaitDlyPoint = 0;

    if(RADIO_STANDARD_FDD_5G == radioMode)
    {
        CompensateWaitDlyPoint = setNrAcSampleDly(bandWidth);
       
    }
    else if((RADIO_STANDARD_LTE_TDD == radioMode) || (RADIO_STANDARD_LTE_FDD  == radioMode))
    {
        CompensateWaitDlyPoint = setLteAcSampleDly(bandWidth);

    }
    return CompensateWaitDlyPoint;
}

UINT32 IcHalFddSetFrPara(T_ICHAL_ACPARA* acPara, UINT32 frameNo)
{
    UINT32 uiBlockId     = 0;
    UINT32 uiAntId       = 0;
    UINT32 ui10msFrEn    = 0;
    UINT32 uiRssiOff     = 0;
    UINT32 uiMaxFrNum    = 1;
    UINT32 uiFrameOff    = 0;
    UINT32 uiAcSyncOff   = 0;
    UINT32 uiDlPreFrSel  = 1;       //1选择10ms帧头
    UINT32 ui10msFrPeriod = 7372800; //对应10ms帧频
    UINT32 uiSecMax      = 9;
    UINT32 uiSecSel      = 0;
    UINT32 uiAcOdevityEn = 3;       //高位为偶帧，1表示使能，低位为奇帧，1表示使能
    UINT32 uiInsertPos   = 1023;    //AC不需要切换，都配置为1023
    UINT32 uiFrSelType   = 1;
    UINT32 uiCbLength    = 4095;

    ///寄存器配置
    for(uiAntId = 0; uiAntId < ANT_NUM_PER_IC; uiAntId++)
    {
        //配置帧频分频周期
        IcHalApiSetAcFrPeriod(uiBlockId, uiAntId, ui10msFrPeriod);
        //帧频帧头延时配置
        IcHalApiSetAcFrDly(uiBlockId, uiAntId, 0); // AC使用时配置为0，UE定位根据需要延迟，延迟后锁存无线帧号
        //ULABNK 配置10ms帧频使能
        IcHalApiSetAccbFr5msEn(uiBlockId, uiAntId, ui10msFrEn);
        //有效帧头数量
        IcHalApiSetAccbFrNum(uiBlockId, uiAntId, uiMaxFrNum); //AC配置为1
        ///RSSI去使能
        IcHalApiSetAccbRssiEn(uiBlockId, uiAntId, uiRssiOff);

        for(uiSecSel = 0;uiSecSel < uiSecMax;uiSecSel++)
        {
            //AC插数不受奇偶帧限制
            IcHalApiSetOdevityFlag(uiBlockId, uiAntId, uiSecSel, uiAcOdevityEn);
            //AC启动后的起始延时值切换位置配置
            IcHalApiSetFrIdPos(uiBlockId, uiAntId, uiSecSel, uiInsertPos);
        }
        //无线帧号匹配方式
        IcHalApiSetFrameIdSel(uiBlockId, uiAntId, uiFrSelType);
        //AC上行采数RAM深度配置 inslot4096
        IcHalApiSetAccbCbLength(uiBlockId, uiAntId, uiCbLength);
        //10ms分频配置
        IcHalApiSetAcSnap10msFrDiv(uiBlockId, uiAntId, ui10msFrPeriod);
    }
    //DLPRE 输出10ms AC同步帧头周期选择
    IcHalApiSetACSyncFrPeriodMode(uiDlPreFrSel);
    //acsync
    IcHalSetAcSyncPara(uiAcSyncOff, frameNo);
    //FrameEN is off
    IcHalSetDlbankSendSameFrameNo(uiFrameOff, frameNo);
    //FrameEN is off
    IcHalSetUlbankSmpSameFrameNo(uiFrameOff, frameNo);

    return BSP_OK;
}

//FDD 上行AC 下行配置
UINT32 IcHalSetFddUlInsertCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn,
                                  T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 uiSwitchProtectTime     = 0;
    UINT32 uiSwitchProtectClk      = 0;
    UINT32 uiAcSample              = 0;
    UINT32 uiInsertNum             = 0;
    UINT32 uiInsertFrontZero       = 0;
    UINT32 uiDlshortZero           = 0;
    UINT32 uiDlLongZero            = 0;
    UINT32 uiIcNo                  = 0;
    UINT32 uiacinSertDly           = 0;
    UINT32 uiacinSertDlyTmp        = 0;
    UINT32 uiDlZeroPos             = 0;
    UINT32 uiBlockId               = 0;
    UINT32 uiFrameIdEn             = 1;
    UINT32 uiFrameNoTran           = 0;
    UINT32 uiCalcAnt               = 0;
    T_AcCarrCfgNxp* AcCarrCfg      = NULL;
    UINT32 uiRet                   = 0;
    UINT32 uiRpuId                 = 0;
    UINT32 uiCalcDifChan           = 0;
    UINT32 uiDifChipId             = 0;
    UINT32 uiSectionSel            = 0;
    UINT32 uiSectionMax            = 8;

    //参数获取
    uiAcSample           = ptAcParaInfo->sample;
    uiInsertNum          = ptAcPara->insertTimes;
    uiRpuId              = shareInfo->sendAcRpuId;
    uiFrameNoTran        = frameNo;
    uiIcNo               = BspGetRpuId();

    if(uiIcNo != uiRpuId)
    {
        dbgInfo("[%s] CalcChn is not on this chip \n", __FUNCTION__);
        return BSP_OK;
    }
    uiCalcAnt = shareInfo->acSendDataChan + 1;//对应map表中的天线号列，需要加1
    AcCarrCfg = (T_AcCarrCfgNxp*)GetAcCarrCfg();

    uiRet = BspGetDifInfoByAntInfo(uiCalcAnt, AcCarrCfg->bandNo, RX, &uiDifChipId, &uiCalcDifChan);
    RETURN_RESULT_CHECK(uiRet);

    dbgInfoEx("[%s] uiacSample :%d, uiInsertNum :%d,uiIcNo :%d,uiFrameNoTran:%d\n", __FUNCTION__, uiAcSample, uiInsertNum, uiIcNo, uiFrameNoTran);

    //开关保护间隔获取
    uiSwitchProtectTime = BspFddGetSwitchProtectTime(radioMode);
    uiSwitchProtectClk  = NsToClk(uiSwitchProtectTime, uiAcSample);

    //获取内插前延时配置
    uiacinSertDlyTmp  = BspGetFddAcInsertDelay(actype, radioMode, bandWidth, slotNo, subframeNo);
    uiacinSertDly     = uiacinSertDlyTmp + 1;

    //前插0计算
    uiInsertFrontZero = uiSwitchProtectClk;

    //短后插0计算
    uiDlshortZero     = 0;

    //后长插0计算
    uiDlLongZero      = 0;

    //长插0的位次
    uiDlZeroPos       = 31;

    IcHalApiSetAcInsrtTimeCa(uiBlockId, uiCalcDifChan, uiInsertNum);                    //通道内插次数
    IcHalApiSetPostLongDlyTimesCa(uiBlockId, uiCalcDifChan, uiDlZeroPos);               //通道长插0的位次
    for(uiSectionSel = 0;uiSectionSel < uiSectionMax;uiSectionSel++)
    {
        IcHalApiSetPreAcInsrtDlyCa(uiBlockId, uiCalcDifChan, uiSectionSel, uiacinSertDly); //通道的内插前延时
    }
    IcHalApiSetAcInsrtZeroNumCa(uiBlockId, uiCalcDifChan, uiInsertFrontZero);           //通道前插0值
    IcHalApiSetPostAcInsrtDlyCa(uiBlockId, uiCalcDifChan, uiDlshortZero);               //通道短插0值
    IcHalApiSetPostAcInsrtLongDlyCa(uiBlockId, uiCalcDifChan, uiDlLongZero);            //通道长插0值

    dbgInfo("[%s] dlBlockSel :%d,uiInsertNum :%d,uiDlZeroPos :%d,uiacinSertDly :%d,uiInsertFrontZero :%d,uiDlshortZero :%d,uiDlLongZero :%d, uiFrameNoTran:%d \n", __FUNCTION__,
              uiBlockId, uiInsertNum, uiDlZeroPos, uiacinSertDly, uiInsertFrontZero, uiDlshortZero, uiDlLongZero, uiFrameNoTran);

    //无线帧号配置
    IcHalSetDlbankFddFrameNo(uiFrameIdEn, uiFrameNoTran, uiCalcDifChan);

    return BSP_OK;
}

//FDD 上行AC 上行配置
UINT32 IcHalSetFddUlCatchCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn, T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara)
{
    UINT32 uiSwitchProtectTime             = 0;
    UINT32 uiSwitchProtectClk              = 0;
    UINT32 uiacCpLen                       = 0;
    UINT32 uiacSeqLen                      = 0;
    UINT32 uiacSample                      = 0;
    UINT32 uiPreciseCompDly                = 0;
    UINT32 uiWaitAcDly                     = 0;
    UINT32 uiAcSmpDly                      = 0;
    UINT32 uiFddDlHoldNum                  = 0;
    UINT32 uiFddDlGetNum                   = 0;
    UINT32 uiacInsertDataNum               = 0;
    UINT32 uiacinSertDly                   = 0;
    UINT32 uiUlInsertZeroNum               = 0;
    UINT32 uiBlockId                       = 0;
    UINT32 uiAntId                         = 0;
    UINT32 uiAntIdMax                      = 0;
    UINT32 uiRound                         = 0;
    UINT32 acInslotEn                      = 0;
    UINT32 uiInsertNum                     = 0;
    UINT32 uiFrameIdEn                     = 1;
    UINT32 uiIcNo                          = 0;
    UINT32 uiAntNoTmp                      = 0;
    UINT32 uiBand                          = 0;
    UINT32 uiDifChipId                     = 0;
    UINT32 uiDifChn                        = 0;
    UINT32 uiFrameSetVal                   = 0;
    UINT32 uiAcFrDelayClk                  = 0;
    UINT32 uiAcFrDelayNs                   = 0;
    UINT32 uiAcFrLead                      = 0;

    //参数获取
    uiacCpLen            = ptAcParaInfo->acCpLen;
    uiacSeqLen           = ptAcParaInfo->acSeqLen;
    uiacSample           = ptAcParaInfo->sample;
    uiInsertNum          = ptAcPara->insertTimes;
    uiAntIdMax           = ptAcPara->acIcMaxAntNo;
    uiIcNo               = BspGetRpuId();
    uiFrameSetVal        = (frameNo + 1025) % 1024;//上行采数帧号相比下行发数帧号加一
    uiAcFrDelayNs        = 215000;
    uiAcFrDelayClk       = NsToClk(uiAcFrDelayNs, CLK_RATE_737P28);

    dbgInfo("[%s] uiacCpLen :%d,uiacSeqLen :%d,uiacSample :%d,uiInsertNum :%d, uiAntIdMax:%d \n", __FUNCTION__,uiacCpLen, uiacSeqLen,uiacSample,uiInsertNum, uiAntIdMax);
    //采数延时计算
    //开关保护间隔获取
    uiSwitchProtectTime = BspFddGetSwitchProtectTime(radioMode);
    uiSwitchProtectClk = NsToClk(uiSwitchProtectTime,uiacSample);

    //获取内插前延时配置
    uiacinSertDly  = BspGetFddAcInsertDelay(actype, radioMode, bandWidth,slotNo, subframeNo);

    //获取精时延补偿值
    uiPreciseCompDly = BspFddGetPreciseCompDly(actype,uiacSample);

    //获取各带宽延迟值
    uiWaitAcDly     = BspGetAcFddUlCompensateWaitDly(radioMode,bandWidth);

    //由于锁存AC帧头延迟215us，采数时延需提前
    uiAcFrLead = NsToClk(uiAcFrDelayNs,uiacSample);

    //采数延时计算
    uiAcSmpDly = uiSwitchProtectClk + uiacinSertDly + uiPreciseCompDly + uiWaitAcDly;
    if(uiAcSmpDly >= uiAcFrLead)
    {
        uiAcSmpDly = uiAcSmpDly - uiAcFrLead;
    }
    dbgInfo("[%s] uiAcSmpDly:%d,uiSwitchProtectClk :%d,uiacinSertDly :%d,uiPreciseCompDly :%d,uiWaitAcDly :%d, uiAcFrLead:%d \n", __FUNCTION__,uiAcSmpDly,uiSwitchProtectClk,uiacinSertDly,uiPreciseCompDly,uiWaitAcDly, uiAcFrLead);

    //inslot 延时配置
    uiUlInsertZeroNum = 0;

    //上行迭代采数次数配置
    uiacInsertDataNum = uiInsertNum - 1;

    //上行HoldNum和 GetNum配置
    uiFddDlHoldNum   = uiacCpLen + uiacSeqLen;
    uiFddDlGetNum    = uiacSeqLen - 1;

    //寄存器配置
    dbgInfo("\n[%s]**************** round %d, ic %d ****************\n", __FUNCTION__, uiRound, uiIcNo);
    for(uiAntId = 0; uiAntId < uiAntIdMax; uiAntId++)
    {
        if(1 == ulAcBlockBankBandInfo[uiIcNo].bBInfo[uiRound].ulIsSet[uiAntId])
        {
            uiAntNoTmp = ulAcRoundAntSel[uiIcNo].ant[uiAntId];
            uiAntNoTmp = uiAntNoTmp + 1; //对应map表中的天线号列，需要加1
            (void)BspGetDifInfoByAntInfo(uiAntNoTmp, uiBand, TX, &uiDifChipId, &uiDifChn);

            //inslot模式使能
            IcHalApiSetAccbAcInslotEn(uiBlockId, uiDifChn, acInslotEn);
            //insert延时配置
            IcHalApiSetAccbAcInslotDelay(uiBlockId, uiDifChn, uiUlInsertZeroNum);
            //采数延时配置
            IcHalApiSetAccbDelayNum(uiBlockId, uiDifChn, uiAcSmpDly);
            //上行迭代次数配置
            IcHalApiSetAccbCycleNum(uiBlockId, uiDifChn, uiacInsertDataNum);
            //GetNum配置
            IcHalApiSetAccbGetNum(uiBlockId, uiDifChn, uiFddDlGetNum);
            //HolNum配置
            IcHalApiSetAccbHoldNum(uiBlockId, uiDifChn, uiFddDlHoldNum);

            //无线帧号配置
            IcHalSetUlbankFddFrameNo(uiFrameIdEn, uiFrameSetVal, uiDifChn);
            dbgInfo("[%s] uiAntId:%d, acInslotEn:%d,uiUlInsertZeroNum :%d,uiAcSmpDly :%d,uiacInsertDataNum :%d,uiFddDlGetNum :%d,uiFddDlHoldNum :%d, uiFrameSetVal:%d\n",
                    __FUNCTION__, uiAntId, acInslotEn,uiUlInsertZeroNum,uiAcSmpDly,uiacInsertDataNum,uiFddDlGetNum,uiFddDlHoldNum, uiFrameSetVal);
            //添加AC锁存帧号延迟，解决T12较大时，帧号不同步问题
            IcHalApiSetSnapPreFrDly(uiBlockId, uiDifChn, uiAcFrDelayClk);
            dbgInfo("[%s]uiAcFrDelayNs:%d, uiAcFrDelayClk:%d\n", __FUNCTION__, uiAcFrDelayNs, uiAcFrDelayClk);
        }
    }

    return BSP_OK;
}

//FDD 下行AC 下行配置
UINT32 IcHalSetFddDlInsertCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn,
                                  T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara)
{
    UINT32 uiSwitchProtectTime     = 0;
    UINT32 uiSwitchProtectClk      = 0;
    UINT32 uiAcSample              = 0;
    UINT32 uiInsertNum             = 0;
    UINT32 uiInsertFrontZero       = 0;
    UINT32 uiDlshortZero           = 0;
    UINT32 uiDlLongZero            = 0;
    UINT32 uiIcNo                  = 0;
    UINT32 uiacinSertDly           = 0;
    UINT32 uiacinSertDlyTmp        = 0;
    UINT32 uiDlZeroPos             = 0;
    UINT32 uiBlockId               = 0;
    UINT32 uiFrameIdEn             = 1;
    UINT32 uiFrameNoTran           = 0;
    UINT32 uiRet                   = 0;
    UINT32 uiDifChipId             = 0;
    UINT32 uiRound                 = 0;
    UINT32 uiRoundMax              = 0;
    UINT32 uiAntId                 = 0;
    UINT32 uiAntIdMax              = 0;
    UINT32 uiAntNoTmp              = 0;
    UINT32 uiDifChn                = 0;
    UINT32 uiBand                  = 0;
    UINT32 uiSectionSel            = 0;
    UINT32 uiSectionMax            = 8;

    //参数获取
    uiAcSample           = ptAcParaInfo->sample;
    uiAntIdMax           = ptAcPara->acIcMaxAntNo;
    uiInsertNum          = ptAcPara->insertTimes;
    uiFrameNoTran        = frameNo;
    uiIcNo               = BspGetRpuId();
    uiRoundMax           = ptAcPara->acDlRoundNo;

    dbgInfo("[%s] uiacSample :%d,uiacMaxAntNum :%d,uiInsertNum :%d,uiIcNo :%d,uiFrameNoTran:%d\n", __FUNCTION__, uiAcSample, uiAntIdMax, uiInsertNum, uiIcNo, uiFrameNoTran);

    ///开关保护间隔获取
    uiSwitchProtectTime = BspFddGetSwitchProtectTime(radioMode);
    uiSwitchProtectClk  = NsToClk(uiSwitchProtectTime, uiAcSample);

    //获取内插前延时配置
    uiacinSertDlyTmp  = BspGetFddAcInsertDelay(actype, radioMode, bandWidth, slotNo, subframeNo);
    uiacinSertDly     = uiacinSertDlyTmp + 1;

    ///前插0计算
    uiInsertFrontZero = uiSwitchProtectClk;

    ///短后插0计算
    uiDlshortZero     = 0;

    //后长插0计算
    uiDlLongZero      = 0;

    //长插0的位次
    uiDlZeroPos       = 31;

    for(uiRound = 0; uiRound < uiRoundMax; uiRound++)
    {
        dbgInfo("\n[%s]**************** round %d, ic %d ****************\n", __FUNCTION__, uiRound, uiIcNo);
        for(uiAntId = 0; uiAntId < uiAntIdMax; uiAntId++)
        {
            if(1 == dlAcBlockBankBandInfo[uiIcNo].bBInfo[uiRound].dlIsSet[uiAntId])
            {
                uiAntNoTmp = dlAcRoundAntSel[uiIcNo].ant[uiRound][uiAntId];
                uiAntNoTmp = uiAntNoTmp + 1; //对应map表中的天线号列，需要加1
                uiRet = BspGetDifInfoByAntInfo(uiAntNoTmp, uiBand, RX, &uiDifChipId, &uiDifChn);
                RETURN_RESULT_CHECK(uiRet);
                dbgInfo("\n[%s] uiAntNoTmp:%d, uiDifChn:%d \n", __FUNCTION__, uiAntNoTmp, uiDifChn);

                IcHalApiSetAcInsrtTimeCa(uiBlockId, uiDifChn, uiInsertNum);                    //通道内插次数
                IcHalApiSetPostLongDlyTimesCa(uiBlockId, uiDifChn, uiDlZeroPos);               //通道长插0的位次
                for(uiSectionSel = 0;uiSectionSel < uiSectionMax;uiSectionSel++)
                {
                    IcHalApiSetPreAcInsrtDlyCa(uiBlockId, uiDifChn, uiSectionSel, uiacinSertDly);                //通道的内插前延时
                }
                IcHalApiSetAcInsrtZeroNumCa(uiBlockId, uiDifChn, uiInsertFrontZero);           //通道前插0值
                IcHalApiSetPostAcInsrtDlyCa(uiBlockId, uiDifChn, uiDlshortZero);               //通道短插0值
                IcHalApiSetPostAcInsrtLongDlyCa(uiBlockId, uiDifChn, uiDlLongZero);            //通道长插0值
                dbgInfo("[%s] dlBlockSel :%d,uiInsertNum :%d,uiDlZeroPos :%d,uiacinSertDly :%d,uiInsertFrontZero :%d,uiDlshortZero :%d,uiDlLongZero :%d, uiDifChn:%d, uiFrameNoTran:%d",
                        __FUNCTION__,uiBlockId, uiInsertNum, uiDlZeroPos, uiacinSertDly, uiInsertFrontZero, uiDlshortZero, uiDlLongZero, uiDifChn, uiFrameNoTran);
                ////无线帧号配置
                IcHalSetDlbankFddFrameNo(uiFrameIdEn, uiFrameNoTran, uiDifChn);
            }
        }
    }

    return BSP_OK;
}

//下行AC 上行配置
UINT32 IcHalSetFddDlCatchCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo,
                                 UINT32 subframeNo, UINT32 slotNo, UINT32 refChn, T_AcParaInfo *ptAcParaInfo,
                                 T_ICHAL_ACPARA* ptAcPara, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 uiSwitchProtectTime             = 0;
    UINT32 uiSwitchProtectClk              = 0;
    UINT32 uiacCpLen                       = 0;
    UINT32 uiacSeqLen                      = 0;
    UINT32 uiacSample                      = 0;
    UINT32 uiacRoundNum                    = 0;
    UINT32 uiPreciseCompDly                = 0;
    UINT32 uiWaitAcDly                     = 0;
    UINT32 uiAcSmpDly                      = 0;
    UINT32 uiFddDlHoldNum                  = 0;
    UINT32 uiFddDlGetNum                   = 0;
    UINT32 uiacInsertDataNum               = 0;
    UINT32 uiacinSertDly                   = 0;
    UINT32 uiUlInsertZeroNum               = 0;
    UINT32 uiBlockId                       = 0;
    UINT32 acInslotEn                      = 0;
    UINT32 uiInsertNum                     = 0;
    UINT32 uiFrameIdEn                     = 1;
    UINT32 uiIcNo                          = 0;
    UINT32 uiRet                           = 0;
    UINT32 uiDifChipId                     = 0;
    UINT32 uiRpuId                         = 0;
    UINT32 uiCalcAnt                       = 0;
    UINT32 uiCalcDifChan                   = 0;
    T_AcCarrCfgNxp* AcCarrCfg              = NULL;
    UINT32 uiFrameSetVal                   = 0;
    UINT32 uiAcFrDelayNs                   = 0;
    UINT32 uiAcFrDelayClk                  = 0;
    UINT32 uiAcFrLead                      = 0;

    //参数获取
    uiacCpLen            = ptAcParaInfo->acCpLen;
    uiacSeqLen           = ptAcParaInfo->acSeqLen;
    uiacSample           = ptAcParaInfo->sample;
    uiInsertNum          = ptAcPara->insertTimes;
    uiacRoundNum         = ptAcPara->acDlRoundNo;
    uiRpuId              = shareInfo->catchAcRpuId;
    uiIcNo               = BspGetRpuId();
    uiFrameSetVal        = (frameNo + 1025) % 1024;//上行采数帧号相比下行发数帧号加一
    uiAcFrDelayNs        = 215000;
    uiAcFrDelayClk       = NsToClk(uiAcFrDelayNs, CLK_RATE_737P28);

    if(uiIcNo != uiRpuId)
    {
        dbgInfo("[%s] CalcChn is not on this chip \n", __FUNCTION__);
        return BSP_OK;
    }
    uiCalcAnt = shareInfo->acCatchDataChan + 1;//对应map表中的天线号列，需要加1
    AcCarrCfg = (T_AcCarrCfgNxp*)GetAcCarrCfg();

    uiRet = BspGetDifInfoByAntInfo(uiCalcAnt, AcCarrCfg->bandNo, TX, &uiDifChipId, &uiCalcDifChan);
    RETURN_RESULT_CHECK(uiRet);

    dbgInfo("[%s] uiacCpLen :%d,uiacSeqLen :%d,uiacSample :%d,uiInsertNum :%d,uiacRoundNum :%d\n", __FUNCTION__,uiacCpLen, uiacSeqLen,uiacSample,uiInsertNum,uiacRoundNum);
    //采数延时计算
    //开关保护间隔获取
    uiSwitchProtectTime = BspFddGetSwitchProtectTime(radioMode);
    uiSwitchProtectClk = NsToClk(uiSwitchProtectTime,uiacSample);

    //获取内插前延时配置
    uiacinSertDly  = BspGetFddAcInsertDelay(actype, radioMode, bandWidth,slotNo, subframeNo);

    //获取精时延补偿值
    uiPreciseCompDly = BspFddGetPreciseCompDly(actype,uiacSample);

    //获取各带宽延迟值
    uiWaitAcDly     = BspGetAcFddUlCompensateWaitDly(radioMode,bandWidth);

    //由于锁存AC帧头延迟215us，采数时延需提前
    uiAcFrLead      = NsToClk(uiAcFrDelayNs,uiacSample);

    //采数延时计算
    uiAcSmpDly = uiSwitchProtectClk + uiacinSertDly + uiPreciseCompDly + uiWaitAcDly;
    if(uiAcSmpDly >= uiAcFrLead)
    {
        uiAcSmpDly = uiAcSmpDly - uiAcFrLead;
    }
    dbgInfo("[%s] uiAcSmpDly:%d,uiSwitchProtectClk :%d,uiacinSertDly :%d,uiPreciseCompDly :%d,uiWaitAcDly :%d, uiAcFrLead:%d\n", __FUNCTION__,uiAcSmpDly,uiSwitchProtectClk,uiacinSertDly,uiPreciseCompDly,uiWaitAcDly, uiAcFrLead);

    //inslot 延时配置
    uiUlInsertZeroNum = 0;

    //上行迭代采数次数配置
    uiacInsertDataNum = uiInsertNum - 1 ;

    //上行HoldNum和 GetNum配置
    uiFddDlHoldNum   = uiacCpLen + uiacSeqLen;
    uiFddDlGetNum    = uiacSeqLen - 1;

    //寄存器配置

    //inslot模式使能
    IcHalApiSetAccbAcInslotEn(uiBlockId, uiCalcDifChan, acInslotEn);
    //insert延时配置
    IcHalApiSetAccbAcInslotDelay(uiBlockId, uiCalcDifChan, uiUlInsertZeroNum);
    //采数延时配置
    IcHalApiSetAccbDelayNum(uiBlockId, uiCalcDifChan, uiAcSmpDly);
    //上行迭代次数配置
    IcHalApiSetAccbCycleNum(uiBlockId, uiCalcDifChan, uiacInsertDataNum);
    //GetNum配置
    IcHalApiSetAccbGetNum(uiBlockId, uiCalcDifChan, uiFddDlGetNum);
    //HolNum配置
    IcHalApiSetAccbHoldNum(uiBlockId, uiCalcDifChan, uiFddDlHoldNum);

    ////无线帧号配置
    IcHalSetUlbankFddFrameNo(uiFrameIdEn, uiFrameSetVal, uiCalcDifChan);
    dbgInfo("[%s] acInslotEn:%d,uiUlInsertZeroNum :%d,uiAcSmpDly :%d,uiacInsertDataNum :%d,uiFddDlGetNum :%d,uiFddDlHoldNum :%d,\n", __FUNCTION__,
              acInslotEn,uiUlInsertZeroNum,uiAcSmpDly,uiacInsertDataNum,uiFddDlGetNum,uiFddDlHoldNum);

    //添加AC锁存帧号延迟，解决T12较大时，帧号不同步问题
    IcHalApiSetSnapPreFrDly(uiBlockId, uiCalcDifChan, uiAcFrDelayClk);
    dbgInfo("[%s]uiAcFrDelayNs:%d, uiAcFrDelayClk:%d\n", __FUNCTION__, uiAcFrDelayNs, uiAcFrDelayClk);

    return BSP_OK;
}

UINT32 IcHalSetFddAcRamPara(UINT32 seqLen,UINT32 cpLen,T_ICHAL_ACPARA* acPara,UINT32 acType,UINT32 radioMode)
{
    UINT32 uiInsertTimes       = 0;
    UINT32 acRamSeqLen         = 0;
    UINT32 uiBlockId           = 0;
    UINT32 uiAcIdx             = 0;

    //参数获取
    uiInsertTimes   = acPara->insertTimes;
    ///ACRAM长度获取
    acRamSeqLen = uiInsertTimes * seqLen  - 1;
    //内插AC数据长度
    IcHalSetAcInsertData(seqLen, cpLen);
    //AC RAM长度配置
    for(uiAcIdx = 0; uiAcIdx < ANT_NUM_PER_IC; uiAcIdx++)
    {
        IcHalApiSetAccbCbLength(uiBlockId, uiAcIdx, acRamSeqLen);
    }
    //上行ACRAM 去使能
    IcHalSetUlBankAllBlockCatchRamEnOff();

    return BSP_OK;
}

UINT32 BspGetSlotDlyTime(UINT32 radioMode,UINT32 subframeNo,UINT32 slotNo)
{
    UINT32 uiDlyTime = 0;

    if(RADIO_STANDARD_LTE_FDD == radioMode)
    {
        uiDlyTime = subframeNo * 1000000; //ns
    }
    else if(RADIO_STANDARD_FDD_5G == radioMode)
    {
        uiDlyTime = slotNo * 1000000; //ns
    }
    else
    {
        //do nothing
    }

    return uiDlyTime;
}

UINT32 BspGetInslotWidth(UINT32 radioMode)
{
    UINT32 uiInslotWidth  = 900000; //900us

    return uiInslotWidth;
}

UINT32 BspSetAcInslotIoCtrl(UINT32 acType,UINT32 radioMode,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{
    UINT32 uiIdx                   = 0;
    UINT32 uiIdxMax                = 9;
    UINT32 uiTddIdx                = 0;
    UINT32 uiFrameNoForIo          = 0;
    UINT32 uiInslotEnable          = 0;
    UINT32 uiPaInslotEnable        = 0;
    UINT32 uiLnaInslotEnable       = 0;
    UINT32 uiInslotDlyTime         = 0;
    UINT32 uiInslotDlyClk          = 0;
    UINT32 uiInslotPulseWidthTime  = 0;
    UINT32 uiInslotPulseWidthClk   = 0;
    UINT32 uiInslotPulseTimes      = 1;
    UINT32 uiInslotFrameCut        = 2;   //frameNo 10bit
    UINT32 ui10msFrPeriod          = 7372800;
    T_AC_INSLOT_PARA tAcInslotPara = {0};
    T_AC_INSLOT_PARA tPaLnaAcInslotPara = {0};
    T_AC_CTRL_AC_INSLOT_PARA tAcCtrlInsotPara = {0};
    T_ICHAL_ACPARA* acPara         = NULL;
    UINT32 uiSwitchType            = 0;

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    uiFrameNoForIo = frameNo;
    if(E_AC_TYPE_FDD_DL == acType)
    {
        uiInslotEnable = 1;
        uiPaInslotEnable = 0;
        uiLnaInslotEnable = 1;
        uiSwitchType = E_AC_TYPE_FDD_DL;
    }
    else if(E_AC_TYPE_FDD_UL == acType)
    {
        uiInslotEnable = 1;
        uiPaInslotEnable = 1;
        uiLnaInslotEnable = 0;
        uiSwitchType = E_AC_TYPE_FDD_UL;
    }
    else
    {
        uiInslotEnable = 0;
        uiPaInslotEnable = 0;
        uiLnaInslotEnable = 0;
        uiSwitchType = E_AC_TYPE_FDD;
    }

    // inslot Dly
    uiInslotDlyTime = BspGetSlotDlyTime(radioMode,subframeNo,slotNo);
    uiInslotDlyClk = NsToClk(uiInslotDlyTime,CLK_RATE_737P28);
    // Pulse Width
    uiInslotPulseWidthTime = BspGetInslotWidth(radioMode);
    uiInslotPulseWidthClk = NsToClk(uiInslotPulseWidthTime,CLK_RATE_737P28);

    dbgInfo("[%s] acType:%d, uiInslotEnable:%d, uiFrameNoForIo:%d, uiInslotDlyClk:%d, uiInslotPulseWidthClk:%d, uiInslotPulseTimes:%d, uiInslotFrameCut:%d, ui10msFrPeriod:%d \n",
            __FUNCTION__, uiSwitchType, uiInslotEnable, uiFrameNoForIo, uiInslotDlyClk, uiInslotPulseWidthClk, uiInslotPulseTimes, uiInslotFrameCut, ui10msFrPeriod);

    tAcInslotPara.tDlPara.uiEnable = uiInslotEnable;
    tAcInslotPara.tDlPara.uiFraNum = uiFrameNoForIo;
    tAcInslotPara.tDlPara.uiFrDly  = uiInslotDlyClk;
    tAcInslotPara.tDlPara.uiWidth  = uiInslotPulseWidthClk;
    tAcInslotPara.tDlPara.uiTimes  = uiInslotPulseTimes;
    tAcInslotPara.tDlPara.uiFrCut  = uiInslotFrameCut;
    tAcInslotPara.tDlPara.ui5msPrd = ui10msFrPeriod;

    tAcInslotPara.tUlPara.uiEnable = uiInslotEnable;
    tAcInslotPara.tUlPara.uiFraNum = uiFrameNoForIo;
    tAcInslotPara.tUlPara.uiFrDly  = uiInslotDlyClk;
    tAcInslotPara.tUlPara.uiWidth  = uiInslotPulseWidthClk;
    tAcInslotPara.tUlPara.uiTimes  = uiInslotPulseTimes;
    tAcInslotPara.tUlPara.uiFrCut  = uiInslotFrameCut;
    tAcInslotPara.tUlPara.ui5msPrd = ui10msFrPeriod;

    tPaLnaAcInslotPara.tDlPara.uiEnable = uiPaInslotEnable;
    tPaLnaAcInslotPara.tDlPara.uiFraNum = uiFrameNoForIo;
    tPaLnaAcInslotPara.tDlPara.uiFrDly  = uiInslotDlyClk;
    tPaLnaAcInslotPara.tDlPara.uiWidth  = uiInslotPulseWidthClk;
    tPaLnaAcInslotPara.tDlPara.uiTimes  = uiInslotPulseTimes;
    tPaLnaAcInslotPara.tDlPara.uiFrCut  = uiInslotFrameCut;
    tPaLnaAcInslotPara.tDlPara.ui5msPrd = ui10msFrPeriod;

    tPaLnaAcInslotPara.tUlPara.uiEnable = uiLnaInslotEnable;
    tPaLnaAcInslotPara.tUlPara.uiFraNum = uiFrameNoForIo;
    tPaLnaAcInslotPara.tUlPara.uiFrDly  = uiInslotDlyClk;
    tPaLnaAcInslotPara.tUlPara.uiWidth  = uiInslotPulseWidthClk;
    tPaLnaAcInslotPara.tUlPara.uiTimes  = uiInslotPulseTimes;
    tPaLnaAcInslotPara.tUlPara.uiFrCut  = uiInslotFrameCut;
    tPaLnaAcInslotPara.tUlPara.ui5msPrd = ui10msFrPeriod;

    tAcCtrlInsotPara.tBaseAcInslot.tDlPara.uiEnable = uiInslotEnable;
    tAcCtrlInsotPara.tBaseAcInslot.tDlPara.uiFraNum = uiFrameNoForIo;
    tAcCtrlInsotPara.tBaseAcInslot.tDlPara.uiFrDly  = uiInslotDlyClk;
    tAcCtrlInsotPara.tBaseAcInslot.tDlPara.uiWidth  = uiInslotPulseWidthClk;
    tAcCtrlInsotPara.tBaseAcInslot.tDlPara.uiTimes  = uiInslotPulseTimes;
    tAcCtrlInsotPara.tBaseAcInslot.tDlPara.uiFrCut  = uiInslotFrameCut;
    tAcCtrlInsotPara.tBaseAcInslot.tDlPara.ui5msPrd = ui10msFrPeriod;

    tAcCtrlInsotPara.tBaseAcInslot.tUlPara.uiEnable = uiInslotEnable;
    tAcCtrlInsotPara.tBaseAcInslot.tUlPara.uiFraNum = uiFrameNoForIo;
    tAcCtrlInsotPara.tBaseAcInslot.tUlPara.uiFrDly  = uiInslotDlyClk;
    tAcCtrlInsotPara.tBaseAcInslot.tUlPara.uiWidth  = uiInslotPulseWidthClk;
    tAcCtrlInsotPara.tBaseAcInslot.tUlPara.uiTimes  = uiInslotPulseTimes;
    tAcCtrlInsotPara.tBaseAcInslot.tUlPara.uiFrCut  = uiInslotFrameCut;
    tAcCtrlInsotPara.tBaseAcInslot.tUlPara.ui5msPrd = ui10msFrPeriod;

    tAcCtrlInsotPara.tFddAc1.uiFrDly = uiInslotDlyClk;
    tAcCtrlInsotPara.tFddAc1.uiWidth = uiInslotPulseWidthClk;
    tAcCtrlInsotPara.tFddAc1.ui5msPrd = ui10msFrPeriod;

    tAcCtrlInsotPara.tFddAc2.uiFrDly = uiInslotDlyClk;
    tAcCtrlInsotPara.tFddAc2.uiWidth = uiInslotPulseWidthClk;
    tAcCtrlInsotPara.tFddAc2.ui5msPrd = ui10msFrPeriod;

    IcHalApiSetLinkAcInSlotPara(&tAcInslotPara, uiTddIdx);
    for(uiIdx = 0;uiIdx < uiIdxMax;uiIdx++)
    {
        IcHalApiSetAcCtrlAcInSlotPara(&tAcCtrlInsotPara, uiTddIdx, uiIdx);
    }
    IcHalApiSetIoTddDlyAcInSlotPara(&tAcInslotPara, uiTddIdx);

    IcHalApiSetPaLnaAcInSlotPara(&tPaLnaAcInslotPara, uiTddIdx);

    BspTddSwModeSel(uiTddIdx, uiSwitchType);
    BspUpdateTddIoVariablePara(uiTddIdx, uiSwitchType);
    INPUT_POINTER_CHECK(acPara->pSetAcTddRfSwitch);
    acPara->pSetAcTddRfSwitch(acType);

    return BSP_OK;
}

/****************************************************************
* 函数名称: BspAcKoInit
* 函数说明:
* 输入参数:
* 输出参数：
* 返回参数： BSP_OK,  BSP_ERROR
*****************************************************************/
UINT32 BspAcKoInit(VOID)
{
    BspSystem("rmmod  hirq_trans_usr_d42_ac.ko");
    BspSystem("insmod hirq_trans_usr_d42_ac.ko brdtype=0");
    BspSystem("mdev -s");
    return BSP_OK;
}

UINT32 BspRestAcInt(VOID)
{
    UINT32 uiPsyncInt10IntNo = 58; //244在中频内部映射的中断号
    UINT32 uiPsyncOff        = 1;
    UINT32 uiIntOff          = 0;
    UINT32 uiAcAntIdx        = 0;
    UINT32 uiIcMaxAntNo      = 8;
    UINT32 uiBlock           = 0;

    dbgInfo("[%s] resetAcInt Begin\n", __FUNCTION__);
    IcHalPsyncTimSetIntMask(uiPsyncInt10IntNo, uiPsyncOff);
    for(uiAcAntIdx = 0;uiAcAntIdx < uiIcMaxAntNo;uiAcAntIdx++)
    {
        IcHalApiSetAccbDoneIntEn(uiBlock, uiAcAntIdx, uiIntOff); //去使能接收中断
    }
    BspSysMsDelay(10); //内核要求增加延时，消耗掉可能的历史中断标志，再在之后的流程中卸载&重载KO
    dbgInfo("[%s] resetAcInt End\n", __FUNCTION__);

    return BSP_OK;
}


void BspSetBbuSuperFrameNo(UINT32 frameNo)
{
    s_bbuSuperFrameNo = frameNo;
}

static UINT32 BspGetUtDlIoCfg(UINT32 difChan,T_BspHalAdaptUtDlIoPara * pUtIo)
{
    UINT32 retVal = BSP_OK;
    
    INPUT_POINTER_CHECK(pUtIo);
    retVal |= BspGetTxEnIoInfoByRfChn(difChan,LINK_TYPE_TX,&pUtIo->uiTxenIdx);
    retVal |= BspGetAmpIoInfoByRfChn(difChan,LINK_TYPE_TX,&pUtIo->uiAmpIdx);
    retVal |= BspGetPaIoInfoByRfChn(difChan,LINK_TYPE_TX,&pUtIo->uiPaIdx);

    return retVal;
}

static UINT32 BspGetUtUlIoCfg(UINT32 difChan,T_BspHalAdaptUtUlIoPara * pUtIo)
{
    UINT32 ulRetVal = BSP_OK;

    INPUT_POINTER_CHECK(pUtIo);
    ulRetVal |=BspGetRxEnIoInfoByRfChn(difChan,LINK_TYPE_RX,&pUtIo->uiRxenIdx);
    ulRetVal |=BspGetLnaIoInfoByRfChn(difChan,LINK_TYPE_RX,&pUtIo->uiLnaIdx);

    return ulRetVal;
}

static UINT32 BspSetOutOfSyncIoConfig(UINT32 radioMode)
{
    UINT32 loop    = 0;
    UINT32 frTmVal = 0;

    dbgInfoEx("%s>> start! \n", __FUNCTION__);
    for (loop = 0; loop < MAX_OUTOFSYNC_ANT_NUM; loop++)
    {
        frTmVal = IcHalApiGetFrTmVal(0,radioMode);
        BspGetUtDlIoCfg(loop,&s_bspIoDlCfg[loop]);
        BspGetUtUlIoCfg(loop,&s_bspIoUlCfg[loop]);
        s_bspIoDlCfg[loop].uiAmpIdx  &= 0xf;
        s_bspIoDlCfg[loop].uiPaIdx   &= 0xf;
        s_bspIoDlCfg[loop].uiTxenIdx &= 0xf;
        s_bspIoUlCfg[loop].uiLnaIdx  &= 0xf;
        s_bspIoUlCfg[loop].uiRxenIdx &= 0xf;
        BspHalAdaptSetUePaAntFrDly(s_bspIoDlCfg[loop].uiPaIdx, frTmVal);
        BspHalAdaptSetUeLnaAntFrDly(s_bspIoUlCfg[loop].uiLnaIdx, frTmVal);
        BspHalAdaptSetUeTxEnAntFrDly(s_bspIoDlCfg[loop].uiTxenIdx, frTmVal);
        BspHalAdaptSetUeRxEnAntFrDly(s_bspIoUlCfg[loop].uiRxenIdx, frTmVal);
        BspHalAdaptSetUeAmpAntFrDly(s_bspIoDlCfg[loop].uiAmpIdx, frTmVal);
        dbgInfoEx("%s>> DifChan:%d uiAmpIdx:%d uiPaIdx:%d uiTxenIdx:%d frTmVal:%d \n", __FUNCTION__,loop,s_bspIoDlCfg[loop].uiAmpIdx,
        s_bspIoDlCfg[loop].uiPaIdx,s_bspIoDlCfg[loop].uiTxenIdx,frTmVal);
        dbgInfoEx("%s>> DifChan:%d uiLnaIdx:%d uiRxenIdx:%d\n", __FUNCTION__,loop,s_bspIoUlCfg[loop].uiLnaIdx,s_bspIoUlCfg[loop].uiRxenIdx);
    }
    dbgInfoEx("%s>> end! \n", __FUNCTION__);

    return BSP_OK;
}


/****************************************************************
* 函数名称: BspCopyOutOfPsyncParaToKo
* 函数说明: 失步干扰检测,把BBU下发的超帧号和IoCfg参数发给Ko中断
* 输入参数: 高层下发的帧号参数等
*
* 输出参数
* 返回参数： BSP_OK,  BSP_ERROR
* 修改说明：
*****************************************************************/
UINT32 BspCopyOutOfPsyncParaToKo(UINT32 radioMode)
{
    VOID * dstBaseAddr   = 0;
    UINT32 dstAddrOffset = 0;
    VOID * dstAddr       = 0;
    VOID* p_superFrameNo = &s_bbuSuperFrameNo;

    BspSetOutOfSyncIoConfig(radioMode);
    dstBaseAddr = s_acDrvBoard.shareMemVirAddrBase;

    dstAddrOffset = IC_AC_SHARE_MEM_OUT_SYNC_FRAMENO_ADDR0_OFFSET;
    dstAddr       = dstBaseAddr + dstAddrOffset;
    memcpy_s((VOID*)dstAddr, sizeof(UINT32), (VOID*)p_superFrameNo, sizeof(UINT32));

    dstAddrOffset = IC_AC_SHARE_MEM_OUT_SYNC_IODLCFG_ADDR0_OFFSET;
    dstAddr       = dstBaseAddr + dstAddrOffset;
    memcpy_s((VOID*)dstAddr, sizeof(T_BspHalAdaptUtDlIoPara)*MAX_OUTOFSYNC_ANT_NUM, (VOID*)s_bspIoDlCfg, sizeof(T_BspHalAdaptUtDlIoPara)*MAX_OUTOFSYNC_ANT_NUM);

    dstAddrOffset = IC_AC_SHARE_MEM_OUT_SYNC_IOULCFG_ADDR0_OFFSET;
    dstAddr       = dstBaseAddr + dstAddrOffset;
    memcpy_s((VOID*)dstAddr, sizeof(T_BspHalAdaptUtUlIoPara)*MAX_OUTOFSYNC_ANT_NUM, (VOID*)s_bspIoUlCfg, sizeof(T_BspHalAdaptUtUlIoPara)*MAX_OUTOFSYNC_ANT_NUM);

    return BSP_OK;
}

UINT32 BspGetIfType(A53R8AcDebugShareInfo* shareInfo, UINT32 radioMode,UINT32 CarrId,UINT32 *uiIfType)
{
    UINT32 uiDifChan   = 0;
    UINT32 uiTdmId     = 0;
    UINT32 uiTdmPosId  = 0;
    UINT32 uiStartPos  = 0;
    UINT32 uiTdmNum    = 0;

    uiDifChan = shareInfo->dlCatchDifChn;
    IcHalGetRxDifCarrTdmId(uiDifChan,CarrId,radioMode,&uiTdmId,&uiTdmPosId,&uiStartPos, uiIfType, &uiTdmNum);
    dbgInfo("%s>> DifChan:%d uiIfType:%d\n", __FUNCTION__,uiDifChan, *uiIfType);

    return BSP_OK;
}


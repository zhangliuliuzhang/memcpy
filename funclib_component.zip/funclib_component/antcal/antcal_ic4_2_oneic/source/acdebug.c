/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : acdebug.c
* 文件标识 : {[N/A]}
* 内容摘要 : 该文件主要是AC维测信息
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2021-01-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2021-01-04
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/


#include "acdebug.h"
#include "antcalapi.h"
//#include "antcalcommon.h"
//#include "freqcfgcommon.h"
//#include "powerctrl_ic4.h"
//#include "devdrv_att.h"
//#include "linkcfgcommon.h"
//#include "chnmapcommon.h"
#include "vxadp.h"
#include "antcal_ic4_2_oneic.h"
#include "resource_alloc_api.h"
//#include "pa_ctr_api.h"
#include "dsp_dbg.h"

// #include "antcalcommon.h"
// #include "freqcfgcommon.h"
#include "vxadp.h"
#include "powerctrl_ic4_2.h"
#include "devdrv_att.h"
#include "vxadp.h"
#include "antcal_ic4_2_oneic.h"
#include "powerctrl_ic4_2_dbg.h"
#include "powerctrl_ic4_2.h"
#include "pa_ic4_2_ctrl.h"
#include "dl_post.h"
#include "funccommon_carrmap.h"
#include "dif_router.h"
#include "cfg_gain_api.h"
#include "resource_alloc_info.h"
/**************************************************************************
 *                             宏定义                                             *
 **************************************************************************/
#define MAX_AC_S_TICK_NUM  24
#define AC_TYPE_DL (0)
#define AC_TYPE_UL (1)

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/






/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
UINT32 g_acSmpDlyFlag = 0;
UINT32 g_acSmpDlyDbg = 0;

UINT32 g_maxCarrNum = 0;

T_BspAcIc4InfoDir g_BspAcInfo[E_VSWR_TYPE_STOP] = {0,};
T_RecordAcDoInfo tRecordAcDoInfo = {0,};

UINT32 g_acSTick[MAX_AC_S_TICK_NUM][5] = {{0,},};
UINT32 g_acSTickIndex = 0;

static UINT32 g_AcFuncLogFileNum = 1;
static CHAR cAcFuncLogPrefixM[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogM_";
static CHAR cAcFuncLogFileDirM[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogM_0.txt";
CHAR * const cAcFuncPathList[2] = {"/bin/rm", "/bin/mv"};
rsize_t rAcFuncPathListSize = 2;

static UINT32 g_AcFuncLogFileNumS = 1;
static CHAR cAcFuncLogPrefixS[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogS_ic0_";
static CHAR cAcFuncLogFileDirS[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogS_ic0_0.txt";

UINT32 g_acFuncLogLevel = AC_FUNC_LOG_HIGH;
UINT32 g_lastAcRst = 0;

/**************************************************************************
 *                         外部函数声明                                   *
 **************************************************************************/

/**************************************************************************
 *                         函数实现                                   *
 **************************************************************************/
/*
VOID showAcTickInfo(VOID);
UINT32 isAcCarrNoExist(UINT32 carrNo,UINT32* pRadioMode)
{
    return BSP_OK;
}

VOID BspClearAcAddInfo(VOID)
{}
*/
VOID RecordShareAcSeqStartFrameNo(UINT32 acType,UINT32 bitMap,UINT32 frameNo,UINT32 realNo)
{
    if (acType < E_AC_TYPE_STOP)
    {
        g_BspAcInfo[acType].BitMap = bitMap;
        g_BspAcInfo[acType].synFrameNo = frameNo;
        g_BspAcInfo[acType].LocalFrameNo = realNo;
    }
}

UINT32 checkWaitR8SmpOverTime(UINT32 acType, UINT32 waitR8TimeCnt)
{
    if(WAITR8TIMEMeasCNT <= waitR8TimeCnt)
    {
        g_BspAcInfo[acType].waitR8OvertimeFlag = 1;
        dbgErr("[%s]R8 sample overtime!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    else
    {
        g_BspAcInfo[acType].waitR8OvertimeFlag = 0;
        return BSP_OK;
    }

    return BSP_OK;
}

VOID recordErsUpdateTime(UINT32 acType, UINT32 acFlag)
{}

VOID recordWaitR8TimeCnt(UINT32 acType, UINT32 waitR8TimeCnt)
{
    g_BspAcInfo[acType].waitR8Time = waitR8TimeCnt;
}

VOID recordToDspPackets(UINT32 acType, UINT32 retVal)
{
    (retVal == BSP_OK)?(g_BspAcInfo[acType].toDspPackets++):(g_BspAcInfo[acType].toDspPacketsErr++);
    g_BspAcInfo[acType].toDspPacketsAll++;
}

VOID RecordSetAcSeqIcInfo(UINT32 carr,UINT32 pasteCarrFlag,UINT32 deviate,UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode,UINT32 acType)
{}

VOID RecordSetAcParaIcInfo(UINT32 acType,UINT32 refChn,UINT32 acChnChgFlag)
{
    if (acType < E_AC_TYPE_STOP)
    {
        g_BspAcInfo[acType].refChn = refChn;
        g_BspAcInfo[acType].acChnChgFlag = acChnChgFlag;
    }
}
/*
VOID getpow(UINT32 acType)
{}

VOID getatt(UINT32 acType)
{}

VOID getDatacloseInfo(UINT32 acType)
{}

VOID geticreg(UINT32 acType)
{}

VOID getcarrcfg(UINT32 acType,UINT32 difChan)
{}

VOID getrssi(UINT32 acType)
{}

VOID getfreqInfo(UINT32 acType)
{}

VOID getNrLteTddInfo(UINT32 acType)
{}

VOID getR8GenInt4Info(UINT32 acType)
{}

VOID getdelayInfo(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{}

UINT32 getcarrstatus(UINT32 acType)
{
    return BSP_OK;
}

VOID getAcInfo(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{}

//显示g_BspAcInfo内容,0表示下行，1表示上行
UINT32 BspShowAcAddInfo(UINT32 acType)
{
    return BSP_OK;
}

//显示g_BspAcInfo内容,0表示下行，1表示上行
UINT32 BspShowAcExtraInfo(UINT32 acType)
{
    return BSP_OK;
}


*/
UINT32 BspGetAcIc4MeasInfo(UINT32 acType,T_BspAcIc4InfoDir *pAcInfo)
{
    return BSP_OK;
}

VOID getAcInfo(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{}

VOID recordAcDataInitCnt(VOID)
{
    tRecordAcDoInfo.AcDataInitCnt++;
}

VOID recordCalAcSeqIcCnt(VOID)
{
    if (tRecordAcDoInfo.CalAcSeqIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.CalAcSeqIcCnt++;
    }
}

VOID recordChkAcSeqIcCnt(VOID)
{
    if (tRecordAcDoInfo.ChkAcSeqIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.ChkAcSeqIcCnt++;
    }
}

VOID recordGetAcSeqIcCnt(VOID)
{
    if (tRecordAcDoInfo.GetAcSeqIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.GetAcSeqIcCnt++;
    }
}

VOID recordCalAcWgtIcCnt(VOID)
{
    if (tRecordAcDoInfo.CalAcWgtIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.CalAcWgtIcCnt++;
    }
}

VOID recordChkAcWgtIcCnt(VOID)
{
    if (tRecordAcDoInfo.ChkAcWgtIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.ChkAcWgtIcCnt++;
    }
}

VOID recordGetAcWgtIcCnt(VOID)
{
    if (tRecordAcDoInfo.GetAcWgtIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.GetAcWgtIcCnt++;
    }
}

UINT32 JudgeWaitR8TimeCnt(UINT32 acType,UINT32 waitR8TimeCnt)
{
    if (waitR8TimeCnt >= WAITR8TIMEMeasCNT)
    {
        (E_AC_TYPE_DL == acType)?(tRecordAcDoInfo.DlWaitR8TimeCnt++):(tRecordAcDoInfo.UlWaitR8TimeCnt++);
    }
    if (waitR8TimeCnt == WAITR8TIMESPILLCNT)
    {
        (E_AC_TYPE_DL == acType)?(tRecordAcDoInfo.DlWaitR8TimeSpillCnt++):(tRecordAcDoInfo.UlWaitR8TimeSpillCnt++);
        dbgErr("%s sendRecvAcSeqData not finished.\n",__FUNCTION__);
    }
    return BSP_OK;
}

VOID recordSendHaulBackAcCnt(VOID)
{
    tRecordAcDoInfo.SendHaulBackAcSeqIcCnt++;
}

VOID recordSetAcWgtIcCnt(VOID)
{
    tRecordAcDoInfo.SetAcWgtIcCnt++;
}

VOID recordWriteAcMsgCnt(VOID)
{
    tRecordAcDoInfo.WriteAcMsgCnt++;
}

VOID recordGetAcSyncTimeCnt(VOID)
{
    tRecordAcDoInfo.GetAcSyncTimeCnt++;
}

VOID RecordSetAcSyncTimeCnt(UINT32 syncTime)
{
	UINT32 Cnt = 0;
	tRecordAcDoInfo.SetAcSyncTimeCnt++;
	Cnt = tRecordAcDoInfo.SetAcSyncTimeCnt - 1;
	tRecordAcDoInfo.SetAcSyncTimeSta.SyncTimeIndex[Cnt % MAX_AcSyncTime_NUM] = Cnt;
	tRecordAcDoInfo.SetAcSyncTimeSta.SyncTime[Cnt % MAX_AcSyncTime_NUM] = syncTime;
}

UINT32 ShowRecordAcDoInfo(VOID)
{
    UINT32 loop = 0;
    dbgInfo("AcDataInitCnt:%d\n",tRecordAcDoInfo.AcDataInitCnt);
    dbgInfo("WriteAcMsgCnt:%d\n",tRecordAcDoInfo.WriteAcMsgCnt);
    dbgInfo("SetAcSeqIcCnt:%d\n",tRecordAcDoInfo.SetAcSeqIcCnt);
    dbgInfo("GetAcSyncTimeCnt:%d\n",tRecordAcDoInfo.GetAcSyncTimeCnt);
    dbgInfo("SetAcParaIcCnt:%d\n",tRecordAcDoInfo.SetAcParaIcCnt);
    dbgInfo("GetAcCatchDataStaCnt:%d\n",tRecordAcDoInfo.GetAcCatchDataStaCnt);
    dbgInfo("SendHaulBackAcSeqIcCnt:%d\n",tRecordAcDoInfo.SendHaulBackAcSeqIcCnt);
    dbgInfo("DlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeCnt);
    dbgInfo("DlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeSpillCnt);
    dbgInfo("UlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeCnt);
    dbgInfo("UlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeSpillCnt);
    dbgInfo("SetAcWgtIcCnt:%d\n",tRecordAcDoInfo.SetAcWgtIcCnt);
    for (loop = 0; loop < MAX_AcSyncTime_NUM; loop++)
    {
        dbgInfo("SyncTimeIndex[%d]:%d SyncTime[%d]:%d \n",loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTimeIndex[loop % MAX_AcSyncTime_NUM],loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTime[loop % MAX_AcSyncTime_NUM]);
    }
    return BSP_OK;
}

UINT32 ShowRecordAcDoInfoFor8T(VOID)  //主要针对不区分主从的机型，打印AC接口执行次数统计
{
    UINT32 loop = 0;
    dbgInfo("AcDataInitCnt:%d\n",tRecordAcDoInfo.AcDataInitCnt);
    dbgInfo("WriteAcMsgCnt:%d\n",tRecordAcDoInfo.WriteAcMsgCnt);
    dbgInfo("SetAcSeqIcCnt:%d\n",tRecordAcDoInfo.SetAcSeqIcCnt);
    dbgInfo("GetAcSyncTimeCnt:%d\n",tRecordAcDoInfo.GetAcSyncTimeCnt);
    dbgInfo("SetAcParaIcCnt:%d\n",tRecordAcDoInfo.SetAcParaIcCnt);
    dbgInfo("GetAcCatchDataStaCnt:%d\n",tRecordAcDoInfo.GetAcCatchDataStaCnt);
    dbgInfo("SendHaulBackAcSeqIcCnt:%d\n",tRecordAcDoInfo.SendHaulBackAcSeqIcCnt);
    dbgInfo("DlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeCnt);
    dbgInfo("DlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeSpillCnt);
    dbgInfo("UlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeCnt);
    dbgInfo("UlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeSpillCnt);
    dbgInfo("SetAcWgtIcCnt:%d\n",tRecordAcDoInfo.SetAcWgtIcCnt);
    dbgInfo("CalAcSeqIcCnt:%d\n",tRecordAcDoInfo.CalAcSeqIcCnt);
    dbgInfo("GetAcSeqIcCnt:%d\n",tRecordAcDoInfo.GetAcSeqIcCnt);
    dbgInfo("CalAcWgtIcCnt:%d\n",tRecordAcDoInfo.CalAcWgtIcCnt);
    dbgInfo("GetAcWgtIcCnt:%d\n",tRecordAcDoInfo.GetAcWgtIcCnt);
    dbgInfo("ChkAcWgtIcCnt:%d\n",tRecordAcDoInfo.ChkAcWgtIcCnt);
    for (loop = 0; loop < MAX_AcSyncTime_NUM; loop++)
    {
        dbgInfo("SyncTimeIndex[%d]:%d SyncTime[%d]:%d \n",loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTimeIndex[loop % MAX_AcSyncTime_NUM],loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTime[loop % MAX_AcSyncTime_NUM]);
    }
    return BSP_OK;
}

VOID recordGetAcCatchDataStaCnt(VOID)
{
    tRecordAcDoInfo.GetAcCatchDataStaCnt++;
}

VOID recordSetAcParaIcCnt(UINT32 acType)
{
    if (acType <= E_AC_TYPE_STOP)
    {
        if (tRecordAcDoInfo.SetAcParaIcCnt < UINT32_MAX)
        {
            tRecordAcDoInfo.SetAcParaIcCnt++;
        }
    }
}

UINT32 SetRecordAcDoInfoInit(VOID)
{
    //清空初始AC计数
    memset((VOID*)&tRecordAcDoInfo,0,sizeof(T_RecordAcDoInfo));
    return BSP_OK;
}

VOID recordAcTickInfo(UINT32 type,UINT32 funIdx,UINT32 exceptionExit)
{
    UINT32 index = g_acSTickIndex % MAX_AC_S_TICK_NUM;
    if(0 == type)//start
    {
        g_acSTick[index][0] = g_acSTickIndex;  
        g_acSTick[index][1] = funIdx;
    }
    else//end
    {
        g_acSTick[index][4] = exceptionExit;        
        g_acSTickIndex++;
    }   
}

VOID showAcTickInfo(VOID)
{
    UINT32 loop = 0;
    dbgInfo("\nfun Idx(0:SetAcSeqIc, 1:SetAcParaIc, 2:SetAcSyncTime, 3:SendHaulBackAcSeqIc)\n");
    for(loop = 0; loop < MAX_AC_S_TICK_NUM; loop++)
    {
        dbgInfo("g_acSTickIndex:%d\n",g_acSTick[loop][0]);
        dbgInfo("fun Idx:%d\n",g_acSTick[loop][1]);
        dbgInfo("exceptionExit:%d\n",g_acSTick[loop][4]);
    } 
}


/***********************************************AC DSP维测*****************************************************/
VOID AcHelp(VOID)
{
    dbgInfo("\n***********************************AC CPU CMD***************************************************\n");
    dbgInfo(" Enable Automatic AC:      setAcEnFlag 1\n");
    dbgInfo(" Disable Automatic AC:     setAcEnFlag 0\n");
    dbgInfo(" AC test manually(TDD):    testAcProc  acType, carrNo,radioMode,cellId\n");
    dbgInfo(" AC test manually(FDD):    testCellFddAc  acType, cellId, radioMode, bandWidth, subFrameNo, slotNo\n");
    dbgInfo(" Show Ac UlBank Delay:     GetUlBankWaitDelay\n");
    dbgInfo(" Set Ac NR UlBank Delay:   SetUlBankWaitDelay bandWidth,delay\n");
    dbgInfo(" Set Ac LTE UlBank Delay:  SetLteUlBankWaitDelay bandWidth,delay\n");
    dbgInfo("\n*************************************AcSta******************************************************\n");
    dbgInfo(" AC Dsp Para:              AcSta 0x11\n");
    dbgInfo(" AC Result:                AcSta 0x12\n");
    dbgInfo(" AC Result in Details:     AcSta 0x13,1,IterationNo\n");
    dbgInfo(" AC SNR/PWDIFF/TA:         AcSta 0x13,2,IterationNo\n");
    dbgInfo(" AC Wgt Sta Info:          AcSta 0x13,3,CarrNo\n");
    dbgInfo(" AC Pha Err Info:          AcSta 0x1d\n");
    dbgInfo("\n**********************************AcSetPara*****************************************************\n");
    dbgInfo(" AC Couple Net:            AcSetPara 0xeb,value(0:Compen/1:No Compen)\n");
    dbgInfo(" AC Wgt to 1.0:            AcSetPara 0xee,value(0:Cal Wgt/1:1.0 Wgt)\n");
    dbgInfo(" AC DL Seq Factor:         AcSetPara 0x10e,value(dbfs)\n");
    dbgInfo(" AC UL Seq Factor:         AcSetPara 0x10f,value(dbfs)\n");
    dbgInfo(" AC DL SigLen:             AcSetPara 0xec,value\n");
    dbgInfo(" AC UL SigLen:             AcSetPara 0xed,value\n");
    dbgInfo(" AC DL Pwr CompenFlg:      AcSetPara 0x133,value (0:compen/1:no compen)\n");
    dbgInfo(" AC UL Pwr CompenFlg:      AcSetPara 0x134,value (0:compen/1:no compen)\n");
    dbgInfo(" AC Ul VGA CompenFlg:      AcSetPara 0x138,value (0:compen/1:no compen)\n");
    dbgInfo("\n**********************************AcSample******************************************************\n");
    dbgInfo(" AC Sample Wgt:            AcSample 0x1e,\"fileName.bin\" \n");
    dbgInfo(" AC Sample Data:           AcSample 0x1f,\"fileName.bin\" \n");
    dbgInfo(" AC Fix Seq:               AcSample 0x38,\"fileName.bin\" \n");
    dbgInfo(" AC Float Couple Net:      AcSample 0x20,\"fileName.bin\" \n");
}

UINT32 AcSta(UINT32 index, INT32 data0, INT32 data1, INT32 data2, INT32 data3)
{
    return acGetDpdStrAcDsp(index, data0, data1, data2, data3);
}

UINT32 AcSetPara(INT32 index, INT32 funcIndex, INT32 par0, INT32 par1, INT32 par2)
{
    return acSetParaAcDsp(index, funcIndex, par0, par1, par2);
}

UINT32 AcSample(UINT32 dataType,const char* filename)
{
    INPUT_POINTER_CHECK(filename);
    return acUpLoadDataAcDspBin(dataType,filename);
}


UINT32 AcFuncLogGetLogLevel(VOID)
{
    return g_acFuncLogLevel;
}

VOID AcFuncLogLevelSet(UINT32 uiLogLevel)
{
    g_acFuncLogLevel = uiLogLevel;
}

//AC Func离线log
INT64 AcFuncLogGetFileLen(INT64 *size)
{
    FILE *pFile;
    INT64 liTmpSize;
    INT32 iRet = 0;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;

    iRet = zte_fopen_s(&pFile, cAcFuncLogFileDirM, "rb", cDirList, rDirListSize);
    if(pFile == NULL)
    {
        liTmpSize = 0;
    }
    else
    {
        iRet =fseek(pFile, 0, SEEK_END);
        FSEEK_CHECK(iRet);
        liTmpSize = ftell(pFile);
        if(liTmpSize < ((INT64)0))
        {
            dbgErr("%s(%d) warning! > ftell ret'%lld! \n", __FUNCTION__, __LINE__, liTmpSize);
        }
        iRet = fclose(pFile);
        FCLOSE_CHECK(iRet);
    }
    *size = liTmpSize;

    return BSP_OK;
}

/* Started by AICoder, pid:x489ct678fmfe4f148a4093b00545e5968f94c13 */
INT32 AcFuncLogM(UINT32 logLevel, const CHAR *format, ...)
{
    FILE *pFile = NULL;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;
    INT32 iRet           = 0;
    UINT32 uiAclogLevel  = 0;

    uiAclogLevel = AcFuncLogGetLogLevel();
    if(logLevel > uiAclogLevel)
    {
        return BSP_OK;
    }

    iRet = zte_fopen_s(&pFile, cAcFuncLogFileDirM, "a+", cDirList, rDirListSize);
    ZTE_SECURITY_FUNC_CHECK(iRet);

    if(pFile == NULL)
    {
        dbgErr("%s %d, fail to open file! \n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    va_list arg;
    va_start(arg, format);
    struct tm timelog;
    struct tm* tm_log = NULL;
    struct timeval nowtime;
    gettimeofday(&nowtime, NULL);
    //coverity[declaration_with_small_time_t:SUPPRESS]
    time_t seconds = nowtime.tv_sec;
    zte_memset_s(&timelog, sizeof(timelog), 0x00, sizeof(timelog));
    tm_log = localtime_r(&seconds, &timelog);

    if(tm_log != NULL)
    {
        iRet = fprintf(pFile, "%04d-%02d-%02d %02d:%02d:%02d.%06ld|%d| ",
                                tm_log->tm_year + 1900,
                                tm_log->tm_mon+1,
                                tm_log->tm_mday,
                                tm_log->tm_hour,
                                tm_log->tm_min,
                                tm_log->tm_sec,
                                nowtime.tv_usec,
                                logLevel);
        FPRINTF_CHECK(iRet);
    }

    //ZTE_SECURITY_FUNC_CHECK(iRet);
    (void)zte_vfprintf_s(pFile, format, arg);
    //FPRINTF_CHECK(iRet);
    va_end(arg);
    iRet = fflush(pFile);
    FFLUSH_CHECK(iRet);
    iRet = zte_fclose_s(pFile);
    FCLOSE_CHECK(iRet);

    return iRet;
}
/* Ended by AICoder, pid:x489ct678fmfe4f148a4093b00545e5968f94c13 */

/* Started by AICoder, pid:p89b0ibb80nc29d14b4e0a61006a800efec448f6 */
VOID BspRecordLastAcRst(UINT32 uiAcRst)
{
    g_lastAcRst = uiAcRst;
}
/* Ended by AICoder, pid:p89b0ibb80nc29d14b4e0a61006a800efec448f6 */
/* Started by AICoder, pid:6db56p0fcfa9a61140dc0b5800600e2d95b25c71 */
UINT32 BspGetLastAcRst(VOID)
{
    return g_lastAcRst;
}

VOID BspAcFuncLogCount()
{
    g_AcFuncLogFileNum++;
    if(g_AcFuncLogFileNum >= AC_FUNC_LOG_FILE_MAX)
    {
        g_AcFuncLogFileNum = 1;
    }
}

VOID BspAcFuncLogCountS()
{
    g_AcFuncLogFileNumS++;
    if(g_AcFuncLogFileNumS >= AC_FUNC_LOG_FILE_MAX)
    {
        g_AcFuncLogFileNumS = 1;
    }
}
/* Ended by AICoder, pid:6db56p0fcfa9a61140dc0b5800600e2d95b25c71 */

/* Started by AICoder, pid:58092oc6d6c4e4914e8b083520f26d765003b016 */
UINT32 BspHandleAcFuncLog(VOID)
{
    INT32 iRet = 0;
    CHAR cAcFuncLogBuffix[AC_FUNC_LOG_MAX_STRING];
    CHAR cAcFuncLogBakDir[AC_FUNC_LOG_MAX_STRING];
    CHAR cAcFuncLogBuffixS[AC_FUNC_LOG_MAX_STRING];
    CHAR cAcFuncLogBakDirS[AC_FUNC_LOG_MAX_STRING];
    CHAR * const cCommandRmFile[3] = {"rm", cAcFuncLogFileDirM, NULL};
    CHAR * const cCommandRmFileS[3] = {"rm", cAcFuncLogFileDirS, NULL};
    rsize_t uiCommandRmFileLen = 3;
    CHAR * const cCommandMvFile[4] = {"mv", cAcFuncLogFileDirM, cAcFuncLogBakDir, NULL};
    CHAR * const cCommandMvFileS[4] = {"mv", cAcFuncLogFileDirS, cAcFuncLogBakDirS, NULL};
    rsize_t uiCommandMvFileLen = 4;

    if(AC_FUNC_LOG_RST_SUCCES == BspGetLastAcRst())
    {
        iRet = zte_system_s("/bin/rm",
                            cCommandRmFile,
                            uiCommandRmFileLen,
                            cAcFuncPathList,
                            rAcFuncPathListSize);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_system_s("/bin/rm",
                            cCommandRmFileS,
                            uiCommandRmFileLen,
                            cAcFuncPathList,
                            rAcFuncPathListSize);
        ZTE_SECURITY_FUNC_CHECK(iRet);
        
    }
    else
    {
        iRet = zte_strncpy_s(cAcFuncLogBakDir, sizeof(cAcFuncLogBakDir), cAcFuncLogPrefixM, sizeof(cAcFuncLogPrefixM));
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_snprintf_s(cAcFuncLogBuffix, sizeof(cAcFuncLogBuffix), "%d.txt", g_AcFuncLogFileNum);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_strncat_s(cAcFuncLogBakDir, sizeof(cAcFuncLogBakDir), cAcFuncLogBuffix, sizeof(cAcFuncLogBuffix));
        ZTE_SECURITY_FUNC_CHECK(iRet);


        iRet = zte_system_s("/bin/mv",
                            cCommandMvFile,
                            uiCommandMvFileLen,
                            cAcFuncPathList,
                            rAcFuncPathListSize);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        BspAcFuncLogCount();

        iRet = zte_strncpy_s(cAcFuncLogBakDirS, sizeof(cAcFuncLogBakDirS), cAcFuncLogPrefixS, sizeof(cAcFuncLogPrefixS));
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_snprintf_s(cAcFuncLogBuffixS, sizeof(cAcFuncLogBuffixS), "%d.txt", g_AcFuncLogFileNumS);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_strncat_s(cAcFuncLogBakDirS, sizeof(cAcFuncLogBakDirS), cAcFuncLogBuffixS, sizeof(cAcFuncLogBuffixS));
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_system_s("/bin/mv",
                            cCommandMvFileS,
                            uiCommandMvFileLen,
                            cAcFuncPathList,
                            rAcFuncPathListSize);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        BspAcFuncLogCountS();
    }

    return iRet;
}
/* Ended by AICoder, pid:58092oc6d6c4e4914e8b083520f26d765003b016 */

/* Started by AICoder, pid:a19a1ca646355d61431e0a9a00b250675856caf6 */
UINT32 AcFuncDspAddrInfo(UINT32 uiMode)
{
    T_Pulm2CmacAntAdjustRspIc3* ptAcRdInfo      = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* ptAcWrInfo = NULL;
    UINT8 *pucBaseAddr                          = NULL;

    if(NULL == (pucBaseAddr = BspGetAcDspMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n", __FUNCTION__);
        return BSP_ERROR;
    }
    if (AC_DDR_HANDLE_READ == uiMode)
    {
        ptAcRdInfo = (T_Pulm2CmacAntAdjustRspIc3*)((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + pucBaseAddr));
        AcFuncLogM(AC_FUNC_LOG_HIGH, "DspRst acType:%d, acRst:%d, radioMode:%d, carrNo:%d, niAbnormalFlag:%d, ucAppParaErrCode:%d, acChnBitmap: 0x%02x \n",
                  ptAcRdInfo->acMsgHeaderRsk.uwACType,
                  ptAcRdInfo->acMsgHeaderRsk.uwACResult,
                  ptAcRdInfo->acMsgHeaderRsk.uwRadioMode,
                  ptAcRdInfo->acMsgHeaderRsk.uiCellId,
                  ptAcRdInfo->acMsgHeaderRsk.ucNiAbnormalFlag,
                  ptAcRdInfo->acMsgHeaderRsk.ucAppParaErrCode,
                  ptAcRdInfo->acMsgBodyRsk.aucAcChnBitmap[0]);
        BspRecordLastAcRst(ptAcRdInfo->acMsgHeaderRsk.uwACResult);
        AcFuncLogM(AC_FUNC_LOG_HIGH, "DspRst antIdx: 0 ~ 7 SNR: %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d \n",
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[0],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[1],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[2],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[3],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[4],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[5],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[6],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[7]);
        AcFuncLogM(AC_FUNC_LOG_HIGH, "DspRst antIdx: 0 ~ 7 PwrDiff: %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d \n",
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[0],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[1],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[2],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[3],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[4],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[5],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[6],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[7]);
        AcFuncLogM(AC_FUNC_LOG_HIGH, "DspRst antIdx: 0 ~ 7 TA: %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d \n",
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[0],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[1],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[2],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[3],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[4],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[5],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[6],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[7]);
    }
    else
    {
        ptAcWrInfo = (T_Cmac2PulmAntAdjustScheInfoIc3*)((VOID *)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + pucBaseAddr));
        AcFuncLogM(AC_FUNC_LOG_HIGH, "AppPara acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, refChn:%d, preciseDelayFlag:%d, appBitmap:0x%02x \n",
                  ptAcWrInfo->acMsgHeaderReq.uwACType,
                  ptAcWrInfo->acMsgHeaderReq.uwRadioMode,
                  ptAcWrInfo->acfillInfoReq.uiBandWidth,
                  ptAcWrInfo->acMsgHeaderReq.uiCellId,
                  ptAcWrInfo->acMsgBodyReq.ucAcUpDownChnNo,
                  ptAcWrInfo->acMsgBodyReq.uPreciseDelayFlag,
                  ptAcWrInfo->acMsgBodyReq.aucDUlValidAntBitMap[0]);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:a19a1ca646355d61431e0a9a00b250675856caf6 */

/* Started by AICoder, pid:j283877e16v4800148670a5d708fe96418206d4c */
// 增加从片aclog
INT32 AcFuncLogS(UINT32 logLevel, const CHAR *format, ...)
{
    FILE *pFile = NULL;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;
    INT32 iRet           = 0;
    UINT32 uiAclogLevel  = 0;

    uiAclogLevel = AcFuncLogGetLogLevel();
    if(logLevel > uiAclogLevel)
    {
        return BSP_OK;
    }

    iRet = zte_fopen_s(&pFile, cAcFuncLogFileDirS, "a+", cDirList, rDirListSize);
    ZTE_SECURITY_FUNC_CHECK(iRet);

    if(pFile == NULL)
    {
        dbgErr("%s %d, fail to open file! \n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    va_list arg;
    va_start(arg, format);
    struct tm timelog;
    struct tm* tm_log = NULL;
    struct timeval nowtime;
    gettimeofday(&nowtime, NULL);
    //coverity[declaration_with_small_time_t:SUPPRESS]
    time_t seconds = nowtime.tv_sec;
    zte_memset_s(&timelog, sizeof(timelog), 0x00, sizeof(timelog));
    tm_log = localtime_r(&seconds, &timelog);

    if(tm_log != NULL)
    {
        iRet = fprintf(pFile, "%04d-%02d-%02d %02d:%02d:%02d.%06ld|%d| ",
                                tm_log->tm_year + 1900,
                                tm_log->tm_mon+1,
                                tm_log->tm_mday,
                                tm_log->tm_hour,
                                tm_log->tm_min,
                                tm_log->tm_sec,
                                nowtime.tv_usec,
                                logLevel);
        FPRINTF_CHECK(iRet);
    }

    //ZTE_SECURITY_FUNC_CHECK(iRet);
    (void)zte_vfprintf_s(pFile, format, arg);
    //FPRINTF_CHECK(iRet);
    va_end(arg);
    iRet = fflush(pFile);
    FFLUSH_CHECK(iRet);
    iRet = zte_fclose_s(pFile);
    FCLOSE_CHECK(iRet);

    return iRet;
}
/* Ended by AICoder, pid:j283877e16v4800148670a5d708fe96418206d4c */
/* Started by AICoder, pid:854f7ob09f7e151142470991a0cf625019b3be89 */
UINT32 AcFuncPasta(VOID)
{
    UINT32 uiPaChnNum = BspGetTxChannel();
    UINT32 uiLnaChnNum = BspGetRxChannel();
    UINT32 *pPaSta;
    UINT32 *pLnaSta;
    UINT32 uiLoop;

    if(0 == BspGetTddIoInitFlag())
    {
        AcFuncLogS(AC_FUNC_LOG_HIGH, "[%s] Err: Please wait for TDDIOINIT!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pPaSta = malloc(uiPaChnNum * sizeof(UINT32));
    if(pPaSta == NULL)
    {
        return BSP_ERROR;
    }
    pLnaSta = malloc(uiLnaChnNum * sizeof(UINT32));
    if(pLnaSta == NULL)
    {
        free(pPaSta);
        return BSP_ERROR;
    }

    for(uiLoop = 0; uiLoop < uiPaChnNum; uiLoop++)
    {
        pPaSta[uiLoop] = BspGetPaSwitch(uiLoop);
    }

    for(uiLoop = 0; uiLoop < uiLnaChnNum; uiLoop++)
    {
        pLnaSta[uiLoop] = BspGetLnaSwitch(uiLoop);
    }

    AcFuncLogS(AC_FUNC_LOG_HIGH, "pa switch status(0:OFF,1:ON 2:FDDON):\n");
    for(uiLoop = 0;uiLoop < uiPaChnNum;uiLoop++)
    {
        AcFuncLogS(AC_FUNC_LOG_HIGH, "pa [%d]%d \n", uiLoop, pPaSta[uiLoop]);
    }

    AcFuncLogS(AC_FUNC_LOG_HIGH, "lna switch status(0:OFF,1:ON 2:FDDON):\n");
    for(uiLoop = 0;uiLoop < uiLnaChnNum;uiLoop++)
    {
        AcFuncLogS(AC_FUNC_LOG_HIGH, "lna [%d]%d \n", uiLoop, pLnaSta[uiLoop]);
    }

    free(pPaSta);
    free(pLnaSta);

    return BSP_OK;
}
/* Ended by AICoder, pid:854f7ob09f7e151142470991a0cf625019b3be89 */

/* Started by AICoder, pid:db998de50b509fb14a0a0b1ae0748211ece788aa */
VOID AcFuncDbfs(VOID)
{
    UINT32 uiRetVal = 0;
    UINT32 ulBand = 0;
    UINT32 uiBspChn = 0;
    ePowType powType = BSP_TSSI_FWD_INFO;
    T_TxPow tPowDbfs = {0};

    for (uiBspChn = 0; uiBspChn < BspGetTxChannel(); uiBspChn++)
    {
        uiRetVal |= GetTssiPowDbfs(uiBspChn, ulBand, powType, &tPowDbfs);
        AcFuncLogS(AC_FUNC_LOG_HIGH, "Chan %2d:FwdTssi=%6d | FbFwd=%6d | RevTssi=%6d | FbRev=%6d | isPowValid=%6d\n",
                                     uiBspChn, tPowDbfs.tFwdPow.ifTssiPow, tPowDbfs.tFwdPow.fbPow,
                                     tPowDbfs.tRevPow.ifTssiPow, tPowDbfs.tRevPow.fbPow,
                                     tPowDbfs.isPowValid);
    }
}
/* Ended by AICoder, pid:db998de50b509fb14a0a0b1ae0748211ece788aa */

/* Started by AICoder, pid:nff09e6cb2d2b3c145230a4e209d1e373c08a3c4 */
VOID AcFuncAttshow(VOID)
{
    UINT32 uiChn;
    UINT32 uiLoop;
    struct
    {
        const char *pDesc;
        INT32  *buf;
        UINT32 (*pGetAtt)(UINT32 chan,INT32 *attVal);
        UINT32 chanNum;
    } attInfo[] = {
        {"txAtt" ,      NULL, BspGetTxAtt,      BspGetTxChannel()},
        {"rxAtt" ,      NULL, BspGetRxAtt,      BspGetRxChannel()},
        {"rxVga" ,      NULL, BspGetRxVga,      BspGetRxChannel()}
    };

    for(uiLoop = 0;uiLoop < NELEMENTS(attInfo);uiLoop++)
    {
        attInfo[uiLoop].buf = malloc(attInfo[uiLoop].chanNum * sizeof(INT32));
        if(attInfo[uiLoop].buf)
        {
            zte_memset_s(attInfo[uiLoop].buf, attInfo[uiLoop].chanNum * sizeof(INT32), 0xff, attInfo[uiLoop].chanNum * sizeof(INT32));
            for(uiChn = 0;uiChn < attInfo[uiLoop].chanNum;uiChn++)
            {
                attInfo[uiLoop].pGetAtt(uiChn, &attInfo[uiLoop].buf[uiChn]);
            }
            for (uiChn = 0;uiChn < attInfo[uiLoop].chanNum;uiChn++)
            {
                AcFuncLogS(AC_FUNC_LOG_HIGH, "%s [%d]%d \n", attInfo[uiLoop].pDesc, uiChn, attInfo[uiLoop].buf[uiChn]);
            }
            free(attInfo[uiLoop].buf);
        }
        else
        {
            dbgErr("get %s malloc failed\n",attInfo[uiLoop].pDesc);
        }
    }
}
/* Ended by AICoder, pid:nff09e6cb2d2b3c145230a4e209d1e373c08a3c4 */

/* Started by AICoder, pid:ad2848168ewe60614c720a97f0583b40c1f45bf1 */
UINT32 AcFuncDlpostPaptAlm(VOID)
{
    UINT32 uiRet = BSP_OK;
    UINT32 uiIndex_block = 0;
    UINT32 uiIndex_chan = 0;
    UINT32 outBandCnt = 0;
    UINT32 cfrLAvgCnt = 0;
    UINT32 cfrSAvgCnt = 0;
    UINT32 sigPwrCnt = 0;
    UINT32 dpdAvgCnt = 0;
    UINT32 daOffRpt = 0;

    AcFuncLogS(AC_FUNC_LOG_HIGH, "PrnDlpostPaptAlm for All Channel:\n");
    AcFuncLogS(AC_FUNC_LOG_HIGH, "|%-8s\t|%-8s\t|%-8s\t|%-8s\t|%-8s\t|%-8s\t\n",
                                "outBandCnt", "cfrLAvgCnt", "cfrSAvgCnt", "sigPwrCnt", "dpdAvgCnt", "realStaRpt");
    for(uiIndex_block = 0;uiIndex_block < DL_POST_BLOCK_NUM;uiIndex_block++)
    {
        for(uiIndex_chan = 0;uiIndex_chan < DL_POST_FREQ_NUM_IN_BLOCK;uiIndex_chan++)
        {
            uiRet = DlPostGetPaptOutbandUnusCnt(uiIndex_block, uiIndex_chan, &outBandCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptLongAvgUnusCnt(uiIndex_block, uiIndex_chan, &cfrLAvgCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptShortAvgUnusCnt(uiIndex_block, uiIndex_chan, &cfrSAvgCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptIQUnusCnt(uiIndex_block, uiIndex_chan, &sigPwrCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptAvgPowUnusCnt(uiIndex_block, uiIndex_chan, &dpdAvgCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptDataOffUnusSta(uiIndex_block, uiIndex_chan, &daOffRpt);
            RETURN_RESULT_CHECK(uiRet);

            AcFuncLogS(AC_FUNC_LOG_HIGH, "|%-8u\t|%-8u\t|%-8u\t|%-8u\t|%-8u\t|%-8u\t\n",
                                        outBandCnt, cfrLAvgCnt, cfrSAvgCnt, sigPwrCnt, dpdAvgCnt, daOffRpt);
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:ad2848168ewe60614c720a97f0583b40c1f45bf1 */

/* Started by AICoder, pid:l70e9r815bgd1cf147cc0b7b1011ea8a5038c901 */
VOID AcFuncRssi(UINT32 uiRadioMode, UINT32 uiCarrNo)
{
    CHAR *pstrDbfsBuf  = NULL;
    CHAR *pstrDbmBuf   = NULL;
    UINT32 uiChnNum    = BspGetRxLogicChanNum();
    UINT32 uiChnLoop   = 0;
    UINT32 uiRadioNum  = 0;
    UINT32 uiRadioLoop = 0;
    INT32  iRssiDbm    = 0;
    INT32  iRssiDbfs   = 0;
    INT32 snpRet       = 0;
    CHAR strDbfsTemp[50] = {0};
    CHAR strDbmTemp[50]  = {0};

    struct sRadio
    {
        UINT32 uMode;
        CHAR *pcModeString;
        UINT32 slotNum;
    }atRadio[] =
    {
        {BSP_RADIO_STANDARD_LTE_TDD, "LTE_TDD",1},
        {BSP_RADIO_STANDARD_LTE_FDD, "LTE_FDD",1},
        {BSP_RADIO_STANDARD_5G,      "5G-NR-TDD",1},
        {BSP_RADIO_STANDARD_FDD_5G,  "5G-NR-FDD",1},
        {BSP_RADIO_STANDARD_UMTS,    "UMTS",1},
        {BSP_RADIO_STANDARD_NB_IOT,  "NB-IOT",1},
    };
    uiRadioNum = sizeof(atRadio) / sizeof(atRadio[0]);

    pstrDbfsBuf = malloc(sizeof(CHAR) * RSSI_BUF_SIZE);
    if (pstrDbfsBuf == NULL)
    {
        dbgErr("%s: pstrDbfsBuf malloc failed \n",__FUNCTION__);
        return;
    }

    pstrDbmBuf = malloc(sizeof(CHAR) * RSSI_BUF_SIZE);
    if (pstrDbmBuf == NULL)
    {
        dbgErr("%s: pstrDbmBuf malloc failed \n",__FUNCTION__);
        free(pstrDbfsBuf);
        return;
    }

    zte_memset_s(pstrDbfsBuf, sizeof(CHAR) * RSSI_BUF_SIZE, 0, sizeof(CHAR) * RSSI_BUF_SIZE);
    zte_memset_s(pstrDbmBuf, sizeof(CHAR) * RSSI_BUF_SIZE, 0, sizeof(CHAR) * RSSI_BUF_SIZE);

    for(uiRadioLoop = 0;uiRadioLoop < uiRadioNum;uiRadioLoop++)
    {
        if(uiRadioMode == atRadio[uiRadioLoop].uMode)
        {
            break;
        }
    }
    if(uiRadioLoop >= uiRadioNum)
    {
        dbgErr("[%s], unSupport RadioMode\n", __FUNCTION__);
        free(pstrDbfsBuf);
        free(pstrDbmBuf);
        return;
    }

    AcFuncLogS(AC_FUNC_LOG_HIGH, "-----------------%s ChnlSum'%d RSSI---------------\n", atRadio[uiRadioLoop].pcModeString, uiChnNum);
    for (uiChnLoop = 0;uiChnLoop < uiChnNum;uiChnLoop++)
    {
        BspGetRssiPowInfoByMode(uiChnLoop, uiCarrNo, uiRadioMode, 0, 0, &iRssiDbm, &iRssiDbfs);

        snpRet = snprintf_s(strDbfsTemp, sizeof(strDbfsTemp), "C%dA%d:%d %s", uiCarrNo, uiChnLoop,
                            iRssiDbfs, (uiChnLoop == uiChnNum - 1) ? "\n" : "");
        SNPRINTF_S_CHECK(snpRet, sizeof(strDbfsTemp));

        snpRet = snprintf_s(pstrDbfsBuf, RSSI_BUF_SIZE, "%s", strDbfsTemp);
        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE);

        snpRet = snprintf_s(strDbmTemp, sizeof(strDbmTemp), "C%dA%d:%d %s", uiCarrNo, uiChnLoop,
                            iRssiDbfs, (uiChnLoop == uiChnNum - 1) ? "\n" : "");
        SNPRINTF_S_CHECK(snpRet, sizeof(strDbmTemp));

        snpRet = snprintf_s(pstrDbmBuf, RSSI_BUF_SIZE, "%s", strDbmTemp);
        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE);
    }
    AcFuncLogS(AC_FUNC_LOG_HIGH, "dbfs: %s\n", pstrDbfsBuf);
    AcFuncLogS(AC_FUNC_LOG_HIGH, "dbm : %s\n", pstrDbmBuf);

    free(pstrDbfsBuf);
    free(pstrDbmBuf);
}
/* Ended by AICoder, pid:l70e9r815bgd1cf147cc0b7b1011ea8a5038c901 */

/* Started by AICoder, pid:5332ese8fccaf66142890a69f05bad5fc7f25b2e */
UINT32 AcFuncCarrSta(VOID)
{
    UINT32 uiRet        = 0;
    UINT32 uiDifChanNum = 0;
    UINT32 uiDifChanIdx = 0;
    UINT32 uiCarrIdx    = 0;
    UINT32 uiCarrId     = 0;
    UINT32 uiCarrRadio  = 0;
    UINT32 uiCarrNum    = 0;
    UINT32 uiTdmCarrSta = 0;
    UINT32 uiAptuneSta  = 0;
    UINT32 uiDgainSta   = 0;

    UINT32 auiCarrId[BSP_DIF_CARR_MAX_NUM] = {0};
    UINT32 auiCarrRadio[BSP_DIF_CARR_MAX_NUM] = {0};

    uiRet = IcHalGetTxDifChanNum(&uiDifChanNum);
    RETURN_RESULT_CHECK(uiRet);

    for (uiDifChanIdx = 0; uiDifChanIdx < uiDifChanNum; uiDifChanIdx++)
    {
        uiRet = IcHalGetTxRadioModeByDifChan(uiDifChanIdx, auiCarrId, auiCarrRadio, &uiCarrNum);
        RETURN_RESULT_CHECK(uiRet);

        if (uiCarrNum > 0)
        {
            for (uiCarrIdx = 0; uiCarrIdx < uiCarrNum; uiCarrIdx++)
            {
                uiCarrId = auiCarrId[uiCarrIdx];
                uiCarrRadio = auiCarrRadio[uiCarrIdx];

                uiRet = IcHalApiGetDlpreGainDataEnStatus(uiDifChanIdx, uiCarrId, uiCarrRadio, &uiTdmCarrSta);
                RETURN_RESULT_CHECK(uiRet);

                uiRet = IcHalApiGetDlbankAptuneDataEnStatus(uiDifChanIdx, uiCarrId, uiCarrRadio, &uiAptuneSta);
                RETURN_RESULT_CHECK(uiRet);

                uiRet = IcHalApiDlbankDgainDataEnStatus(uiDifChanIdx, uiCarrId, uiCarrRadio, &uiDgainSta);
                RETURN_RESULT_CHECK(uiRet);

                AcFuncLogS(AC_FUNC_LOG_HIGH, "|ChanId |CarrId |CarrRadio |TdmCarr |Aptune |Dgain (0: off, 1:on)\n");
                AcFuncLogS(AC_FUNC_LOG_HIGH, "|%-u    |%-u    |%-u       |%-u     |%-u    |%-u \n", uiDifChanIdx, uiCarrId, uiCarrRadio, uiTdmCarrSta, uiAptuneSta, uiDgainSta);
            }
        }
        else
        {
            AcFuncLogS(AC_FUNC_LOG_HIGH, "DifChan[%u] dont have valid carries!\n", uiDifChanIdx);
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:5332ese8fccaf66142890a69f05bad5fc7f25b2e */
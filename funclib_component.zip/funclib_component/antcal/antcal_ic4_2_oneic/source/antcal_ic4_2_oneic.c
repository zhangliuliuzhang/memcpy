#include "bsppub.h"
#include "bspcomm.h"
#include <stdint.h>
//#include <fcntl.h>
//#include <errno.h>
//#include <math.h>
//#include <time.h>
//#include <sys/socket.h>
//#include <sys/ioctl.h>
//#include <unistd.h>
//#include <sys/types.h>
//#include <sys/stat.h>
//#include <linux/if_ether.h>
//#include <linux/if_packet.h>
//#include <linux/if.h>
//#include <stdio.h>
//#include <stdlib.h>
#include <string.h>
//#include <netinet/in.h>
//#include <netdb.h>
//#include <linux/errno.h>
//#include <sys/time.h>
//#include <sys/mman.h>
#include "systemcallapi.h"
#include "antcal_ic4_2_oneic.h"
//#include "regdrv.h"
#include "freqcfgcommon.h"
#include "psyncdrv.h"
#include "vxadp.h"
#include "chnmap_a.h"
#include "acdebug.h"
#include "rftable.h"
#include "exprn.h"
#include "antcalcommon.h"
//#include "icp.h"
#include "acdrv_ic4_2_oneic.h"
#include "icopthalcomm.h"
//#include "powerctrlapi.h"
//#include "regdrv_accesstbl.h"
#include "chnmapapi.h"
#include "resource_alloc_api.h"
#include "ac_ext_api.h"
#include "psync.h"
#include "dlyapi.h"
#include "funccommon_a.h"
#include "cellcfg.h"
#include "dif_dly_api.h"
#include "cellcfgapi.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "optctrl_inter_def.h"
#include "ac_app.h"
#include "ac_api.h"
#include "acdrv_ic4_2_oneic.h"
#include "mesginter_drv.h"
#include "pa_ic4_2_calcpara.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/

typedef struct T_TagAcPrach
{
    UINT32 HighAddr;  //高地址
    UINT32 LowAddr;   //低地址
}TagAcPrach;

typedef struct tagT_aacWgtDataPara
{
    UINT32 logicCarrNo;
    UINT32 radioMode;
    UINT32 aacErrWgtbak[IC42_MAX_CHAN_NUM];
    UINT32 aacWgtLength;  /* AAC权值的长度，单位为byte */
    UINT32 aacInitiateNum;
}T_aacWgtDataPara;

/**************************************************************************
 *                        宏                                              *
 **************************************************************************/
#define SOCK_SEND_MACTYPE             (0x1081)
#define ANTCAL_PI                     (3.14159265359)    /* 圆周率 */
#define AC_FREQ_STEP                  (20)
#define _LINEAR_INSERT(x,x1,y1,x2,y2) ((INT32)(((FLOAT)((y2) - (y1)) / ((x2) - (x1) + 0.000001)) * ((x) - (x1)) + (y1)+0.5))

#define AC_WGTDATA_GROUP_NUM           16
#define AC_PSYNC_FRAMENO_WAIT          260      //AC 发数、采数等待时间
#define DPDIC3_ULBANK_AGC_VGA_0DB_GAIN_REF      450 //ulbank采数结果的0dB参考常数:450
#define AC_MAX_FRAME_NO                (1023)
#define MIX_NR_MODE   20313  //(2496)/122.88*1000
#define FIX_ATT_ENABLE                      1    /* 1:固定ATT使能 0:固定ATT不使能 */
#define CHANGE_ATT_DISABLE                  1    /* 1:修改ATT使能 0:修改ATT不使能 */
#define AAC_TYPE_CJT                (0)
#define AAC_TYPE_UTDOA              (1)
#define AAC_STAGE_BIG_ERGODIC       (0)
#define AAC_STAGE_SMALL_ERGODIC     (1)
#define BIT_PER_LINE                 8

#define AC_SMP_PARA_CHECK(a,b,c,d)                       \
{                                                        \
    if ((a >= BspGetTxChannel()) || (b >= 8) || (c > d)) \
    {                                                    \
        dbgErr("para input error\n");                    \
        return BSP_ERROR;                                \
    }                                                    \
}

#define INDEX_RANGE_CHECK(ParamVal, MaxVal)              \
{                                                        \
    if ((ParamVal) >= (MaxVal))                          \
    {                                                    \
        dbgErr("%s>>Error!Param Over; Idx(0~%u)= %u\n",  \
                __FUNCTION__, (MaxVal), (ParamVal));     \
        return BSP_ERROR;                                \
    }                                                    \
}

#ifndef CASE
#define CASE(x) case (x):
#endif

#ifndef DEFAULT
#define DEFAULT default:
#endif

#ifndef IF_CHK
#define IF_CHK(x) if(x)
#endif

#ifndef ELSE
#define ELSE else
#endif

#ifndef FOR_LOOP
#define FOR_LOOP(x) for(x)
#endif

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
UINT32 BspSetBoardAcInfo(VOID);
UINT32 CheckAcCarrNo(UINT32 carrNo,UINT32 radioMode);

UINT32 SetAacWgtIc(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 bitAntMap, UINT32 *data, UINT32 length);
UINT32 SetPimRbWgtIc(T_PimWgtCarrInfo *aacCarrInfo, UINT32 disableRbStart, UINT32 disableRbNum, UINT32 disableTxChanMap);
UINT32 InitStoredCarrWgt(UINT32 logicCarrNo, UINT32 radioMode);
static UINT32 GetSaveWgtIndex(UINT32 logicCarrNo, UINT32 radioMode);
static UINT32 SaveLatestDlAcWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pAcWgtData, UINT32 acWgtLength);
static UINT32 SaveLatestAacWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pAacWgtData, UINT32 aacWgtLength);
static UINT32 GetAcWgtLength(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pacWgtLength);
static UINT32 CalcUpdateAcWgt(UINT32 carrIndex, UINT32 *pUpdataWgt, UINT32 updataWgtLength);
static UINT32 CheckAacWgtRange(UINT32 *pAacWgt, UINT32 aacWgtLength);
static UINT32 UpdateAcWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pUpdataWgt, UINT32 updataWgtLength, UINT32 *pAcWgtLength);
static UINT32 DbgSaveAbnormalAacPara(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pAacWgtData, UINT32 aacWgtLength);
static UINT32 BspDisableWgt(UINT32 *pWgt, UINT32 wgtLength, UINT32 carrNo, UINT32 radioMode);
UINT32 SendDspAcDataMultiIc(T_AcDataPara *ptAcDataPara);
UINT32 GetAcSeqMultiIc(UINT32 uiSocId, UINT32 uiAcType, UINT32 *pSeq, UINT32 *pSeqLen);

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
UINT32 s_printCtrl = 0;
UINT32 board_type_flag = 0;
struct ac_info acinfo;
ac_user_AddrCfg s_acUserAddrCfg = {IC_AC_SHARE_MEM_ADDR_PHY_BASE, IC_AC_SHARE_MEM_ADDR_SIZE}; /* IC A53和R8 共享内存 */
ac_user_AddrCfg s_acAcDspUserAddrCfg = {IC_AC_SHARE_MEM_ADDR_PHY_BASE_A53_ACDSP, IC_AC_SHARE_MEM_ADDR_SIZE_A53_ACDSP}; /* 主控A53和AC DSP 共享内存 */
T_AcDspDataCfg  s_acDspDataCfg = {0};
INT32 s_cpswacFd = -1;
VOID *s_ucRamDspAddr = NULL;
UINT8 *s_ucRamAcDspAddr = NULL;  /* 主控A53和AC DSP 共享内存映射基址 */
UINT32 s_acFuncVerId                                                   = 0;
T_AcCarrCfgNxp g_acCarrCfgNxp                                          = {0};
UINT32 carrPasteFlagM[MAX_CARR_NUM]                                    = {0};
UINT32 s_ulCellFre                                                     = 0;
UINT32 acBitmap[2]                                                     = {0,};
UINT32 carrPasteFlag[MAX_CARR_NUM]                                     = {0};
DOUBLE s_Gp2AcEnd                                                      = 0;
DOUBLE s_Gp2Ac                                                         = 0;
UINT32 g_acFunctionLib_Init_STA                                        = 0;
UINT32 g_uiJacMode                                                     = 0;
UINT32 g_uiJacHandleType                                               = 0;
UINT8 g_uiJacBitMap                                                    = 0;
UINT32 g_uiSuperFr = 0;
T_JacSuperFrInfo g_tJacFrInfo[JAC_FR_DEBUG_CNT_MAX];
UINT32 g_uiJacSuperFrDebugCnt = 0;
UINT32 g_aiDupCarryArry[AC_MAX_RB_NUM*IC42_MAX_CHAN_NUM]               = {0};
UINT32 g_aiOrgCarryArry[AC_MAX_RB_NUM*IC42_MAX_CHAN_NUM]               = {0};
UINT32 g_aiCoupNetApp[COUPNET_APP_LIST*AC_WEIGHT_DATA_NUM_FOR_APP]     = {0};
UINT32 g_aiCoupNetOrg[IC42_MAX_CHAN_NUM*AC_WEIGHT_DATA_NUM]            = {0};
UINT32 g_arryTest[COUPNET_APP_LIST][AC_WEIGHT_DATA_NUM_FOR_APP]        = {0};
DOUBLE g_dCatchFwdDbfs = 0.0;
DOUBLE g_dCatchRevDbfs = 0.0;
UINT32 g_uiFrNumAdjust  = 200;
UINT32 g_uiISeqGain      = 0x400;
UINT32 g_uiQSeqGain      = 0;
UINT32 g_uiSetVswrValFlag = 0;

/* AAC维测 */
static UINT32 s_aacInitiateNum                                         = 0;
static UINT32 s_errAacNum                                              = 0;
static T_aacWgtDataPara s_dbgAacWgtDataPara[BSP_MAX_CARR_NUM]          = {0};
static UINT32 s_testAacWgt[IC42_MAX_CHAN_NUM]                          = {0};

/* vswr驻波检测数据保存 */
T_VswrDetectInfo g_atVswrDetectInfo[RCUA_MAX_CAL_PORT_NUM] = {0,};
static T_AacBitmapCfg dbg_aacBitmapCfg = {0,};
static T_AacSampPointDly s_sampPointDlyInfo = {{{0}}};
static UINT16 s_aacFrameMode[BSP_AAC_MAX_FRAME_NUM] = {0};
static T_AacSuperFrameInfo dbg_superFrameInfo[BSP_MAX_CARR_NUM] = {0,};
static T_AacCaliPeriodInfo s_superFrameInfoBak[BSP_MAX_CARR_NUM] = {0};
static T_aacWgtData s_dbgAacWgtData[BSP_MAX_CARR_NUM] = {0};

enum
{
    TDDIO_TYPE_PA,
    TDDIO_TYPE_LNA,
    TDDIO_TYPE_TXEN,
    TDDIO_TYPE_RXEN,
    TDDIO_TYPE_AMP,
    TDDIO_TYPE_NUM,
};

//所有制式下参数，注意主从数据长度单位不一样
T_AcAllParaInfo g_acAllParaInfo[] = \
{
    /****************************************TDD  Begin*****************************************************/
    {RADIO_STANDARD_5G, BANDWIDTH_100M_MHz, CLK_RATE_122P88, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_5G, BANDWIDTH_90M_MHz, CLK_RATE_122P88, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_5G, BANDWIDTH_80M_MHz, CLK_RATE_92P16, AC_DATA_LEN_768, AC_DATA_OFFSET_96, AC_CP_48},
    {RADIO_STANDARD_5G, BANDWIDTH_70M_MHz, CLK_RATE_92P16, AC_DATA_LEN_768, AC_DATA_OFFSET_96, AC_CP_48},
    {RADIO_STANDARD_5G, BANDWIDTH_60M_MHz, CLK_RATE_61P44, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_5G, BANDWIDTH_50M_MHz, CLK_RATE_61P44, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_5G, BANDWIDTH_40M_MHz, CLK_RATE_61P44, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_5G, BANDWIDTH_30M_MHz, CLK_RATE_30P72, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},
    {RADIO_STANDARD_5G, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},
    {RADIO_STANDARD_5G, BANDWIDTH_25M_MHz, CLK_RATE_30P72, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},

    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_15M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_10M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_5M_MHz,  CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_60M_MHz, CLK_RATE_122P88, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},

    /****************************************TDD  End*******************************************************/

    /****************************************FDD  Begin*****************************************************/
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_40M_MHz, CLK_RATE_61P44, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz, CLK_RATE_15P36, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},

    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz, CLK_RATE_15P36, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,  CLK_RATE_7P68,  AC_DATA_LEN_128, AC_DATA_OFFSET_16, AC_CP_8},
    /****************************************FDD  End*******************************************************/
};

//延时参数配置
T_AcLenInfo g_tAcLenInfo[] = \
{
    /*******************************TDD  Begin*****************************************/
    {RADIO_STANDARD_5G,BANDWIDTH_100M_MHz,CLK_RATE_122P88 ,GP_AC_SQUENCE_LEN_NR_122880},
    {RADIO_STANDARD_5G,BANDWIDTH_90M_MHz ,CLK_RATE_122P88 ,GP_AC_SQUENCE_LEN_NR_122880},
    {RADIO_STANDARD_5G,BANDWIDTH_80M_MHz ,CLK_RATE_92P16  ,GP_AC_SQUENCE_LEN_NR_92160},
    {RADIO_STANDARD_5G,BANDWIDTH_70M_MHz ,CLK_RATE_92P16  ,GP_AC_SQUENCE_LEN_NR_92160},
    {RADIO_STANDARD_5G,BANDWIDTH_60M_MHz ,CLK_RATE_61P44  ,GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_5G,BANDWIDTH_50M_MHz ,CLK_RATE_61P44 ,GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_5G,BANDWIDTH_40M_MHz ,CLK_RATE_61P44 ,GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_5G,BANDWIDTH_30M_MHz ,CLK_RATE_30P72 ,GP_AC_SQUENCE_LEN_NR_30720},
    {RADIO_STANDARD_5G,BANDWIDTH_20M_MHz ,CLK_RATE_30P72 ,GP_AC_SQUENCE_LEN_NR_30720},
    {RADIO_STANDARD_5G,BANDWIDTH_25M_MHz ,CLK_RATE_30P72 ,GP_AC_SQUENCE_LEN_NR_30720},

    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_20M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_15M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_10M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_5M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_60M_MHz, CLK_RATE_122P88, GP_AC_SQUENCE_LEN_NR_122880},
    /*******************************TDD  End*******************************************/

    /*******************************FDD  Begin*****************************************/
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_40M_MHz, CLK_RATE_61P44 ,GP_AC_SQUENCE_LEN_NR_122880},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz, CLK_RATE_15P36, GP_AC_SQUENCE_LEN_LTE_15360},

    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz, CLK_RATE_30P72 ,GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz, CLK_RATE_15P36, GP_AC_SQUENCE_LEN_LTE_15360},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,  CLK_RATE_7P68,  GP_AC_SQUENCE_LEN_LTE_7680},
    /*******************************FDD  End*******************************************/
};

T_AcWgtInfo g_acWgtInfo[] = \
{
    /****************TDD  Begin************************/
    {RADIO_STANDARD_5G,  BANDWIDTH_100M_MHz, 273},
    {RADIO_STANDARD_5G,  BANDWIDTH_90M_MHz,  245},
    {RADIO_STANDARD_5G,  BANDWIDTH_80M_MHz,  217},
    {RADIO_STANDARD_5G,  BANDWIDTH_70M_MHz,  189},
    {RADIO_STANDARD_5G,  BANDWIDTH_60M_MHz,  162},
    {RADIO_STANDARD_5G,  BANDWIDTH_50M_MHz,  133},
    {RADIO_STANDARD_5G,  BANDWIDTH_40M_MHz,  106},
    {RADIO_STANDARD_5G,  BANDWIDTH_30M_MHz,  78},
    {RADIO_STANDARD_5G,  BANDWIDTH_25M_MHz,  65},
    {RADIO_STANDARD_5G,  BANDWIDTH_20M_MHz,  51},

    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_20M_MHz,  100},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_10M_MHz,  50},
    /****************TDD  End**************************/

    /****************FDD  Begin************************/
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_40M_MHz,  216},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz,  160},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz,  106},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz,  79},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz,  52},

    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz,  100},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz,  75},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz,  50},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,   25},
    /****************FDD  End**************************/
};

const UINT32 ac_WgtDataNum[AC_WGTDATA_GROUP_NUM][2]=
{
    {100000,99},
    {80000 ,79},
    {60000 ,59},
    {50000 ,49},
    {40000 ,39},
    {30000 ,29},
    {20000 ,19},
    {15000 ,14},
    {10000 ,9},
    {5000  ,4},
    {4800  ,3},
    {4600  ,3},
    {4400  ,3},
    {4200  ,3},
    {3840  ,2},
    {3800  ,2}
};

/**************************************************************************
 *                         外部变量声明                                   *
 **************************************************************************/
UINT32 s_AcDebugModeIc = 0;
INT32 SendHaulBackAcSeqIcUlAcCnt = 0;
//32个bit，bit=0降秩，bit=1不降秩
UINT32 s_wgtUpdateBitMap = 0;

T_wgtBakDataPara s_wgtBakDataPara[BSP_MAX_CARR_NUM] = {0};
static UINT32 s_IsSupportAac = NO_SUPPORT;

extern ICRRBlockBankDL dlAcBlockBankBandInfo[AC_IC_NUM] ;//2片IC
extern ICRRBlockBankUL ulAcBlockBankBandInfo[AC_IC_NUM] ;//2片IC

/**************************************************************************
 *                         外部函数声明                                   *
 **************************************************************************/
//extern UINT32 BspGetCarrCfg(UINT32 difChan,T_AcCarrcfg *recordcarrcfg);

/**************************************************************************
 *                         局部函数声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         全局函数实现                                   *
 **************************************************************************/
UINT32 IcHalAcChangCalcChan(A53R8AcDebugShareInfo* shareInfo, T_ICHAL_ACPARA* acPara, UINT32 calcChanFlag);
/* Started by AICoder, pid:c57c4reb5ff1d39149710afd807ed40d5d97a993 */
UINT32 BspSetCouplingMode(UINT32 uiAdapteEn, UINT32 uiAdapteType)
{
    UINT32 uiRet = 0;
    T_ICHAL_ACPARA* ptAcPara = NULL;

    ptAcPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(ptAcPara);
    INPUT_POINTER_CHECK(ptAcPara->pBspSetCouplingAdapte);

    uiRet = ptAcPara->pBspSetCouplingAdapte(uiAdapteEn, uiAdapteType);
    RETURN_RESULT_CHECK(uiRet);

    return BSP_OK;
}
/* Ended by AICoder, pid:c57c4reb5ff1d39149710afd807ed40d5d97a993 */
UINT32 BspGetAcFuncLibSta(VOID)
{
    dbgInfo("[%s] acFuncLib sta:%d\n", __FUNCTION__, g_acFunctionLib_Init_STA);
    return g_acFunctionLib_Init_STA;
}

UINT32 BspSetAcFuncLibSta(UINT32 sta)
{
    g_acFunctionLib_Init_STA = sta;
    dbgInfo("[%s] acFuncLib sta:%d\n", __FUNCTION__, g_acFunctionLib_Init_STA);
    return BSP_OK;
}

UINT32 BspJudgeAcType(UINT32 acType)
{
    UINT32 uiAcType = 0;

    switch(acType)
    {
        case E_AC_TYPE_DL:
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_BRIDGE_DL:
        {
            uiAcType = 0;
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_FDD_UL:
        {
            uiAcType = 1;
            break;
        }
        case E_AC_TYPE_STOP:
        {
            uiAcType = 2;
            break;
        }
        default:
        {
            dbgErr("%s unknow ac type \n", __FUNCTION__);
            break;
        }
    }

    return uiAcType;
}

UINT32 BspGetTrxTypeByAcType(UINT32 acType)
{
    UINT32 trxType = 0;

    switch(acType)
    {
        case E_AC_TYPE_DL:
        case E_AC_TYPE_FDD_DL:
        {
            trxType = TX;
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_FDD_UL:
        {
            trxType = RX;
            break;
        }
        default:
        {
            trxType = BSP_ERROR;
            break;
        }
    }

    return trxType;
}

UINT32 BspSetBoardTypeFlag(void)
{
    board_type_flag = 1;
    return BSP_OK;
}

UINT8* BspGetAcMemBaseAddr(VOID)
{
    return (UINT8 *)s_ucRamDspAddr;
}

UINT8* BspGetAcDspMemBaseAddr(VOID)
{
    return s_ucRamAcDspAddr;
}

/******************************************************************************
* 函数名称   : BspGetAcRecvPacks()
* 功能描述   : 获取内核中接收ac数据包数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
*              
* 输出参数   : 无
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
UINT32 GetAcRecvPacks(VOID)
{
    UINT32 acRcvPacks=0;
    UINT32 temp = 0;

    if (s_cpswacFd <= 0)
    {
        s_cpswacFd = open(KXCPSW_AC_DEV,O_RDWR | O_SYNC);
        dbgInfo("open /dev/cpsw_ac dev \n ");
    }
    if(-1 == s_cpswacFd)
    {
        dbgInfo("Open cpsw_ac error \n");
    }
    
    /*获取接收包数*/
    temp = ioctl(s_cpswacFd, CPSW_AC_DATA_GET, &acRcvPacks);   
    dbgInfo("get the cpsw ac recv packets is = %d, temp:%#x\n",acRcvPacks, temp);


    return acRcvPacks;
}

/**************************************************************************
 * 函数名称: BspShowAcInfo
 * 功能描述:
 * 输入参数: VOID
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                   牛彦茹    创建
 **************************************************************************/
VOID BspShowAcInfo(VOID)
{
    UINT32 RecvPacks=0;
    
    dbgInfo("g_cpswacFd = %d\n",s_cpswacFd);
    
    dbgInfo("AC recv and send packs is:\n");
    dbgInfo("send pack ok: %d\n",acinfo.sendPackets_ok);
    dbgInfo("send pack err: %d\n",acinfo.sendPackets_err);

    RecvPacks = GetAcRecvPacks();
    dbgInfo("recv pack ok: %d\n",RecvPacks);

    dbgInfo("s_ucRamDspAddr = %p\n",s_ucRamDspAddr);
    dbgInfo("s_ucRamAcDspAddr = %p\n", (void*)s_ucRamAcDspAddr);

    dbgInfo("\nuser cfg info is:\n");
    dbgInfo("%20s = 0x%lx\n", "acaddr",s_acUserAddrCfg.acaddr);
    dbgInfo("%20s = 0x%lx\n","aclength", s_acUserAddrCfg.aclength);
    dbgInfo("%20s = 0x%lx\n", "acaddr",s_acAcDspUserAddrCfg.acaddr);
    dbgInfo("%20s = 0x%lx\n","aclength", s_acAcDspUserAddrCfg.aclength);

    return;
}

/**************************************************************************
 * 函数名称: BspAcDspAcDataInit
 * 功能描述: 整个ac模块初始化,专用于 IC A53和AC DSP 共享内存映射，目前用于IC3作为主控的机型，例如R8998G
 * 输入参数: pAddcfg: 给内核的各个配置
             pUserAddCfg: 给用户态的各个配置
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2021年9月23日                   李阳    创建
 **************************************************************************/
UINT32 BspAcDspAcDataInit(VOID)
{
    INT32 Fd = 0; /*内存设备的文件描述符*/
    UINT32 ulAcRamLen = 0;
    ac_user_AddrCfg *pUserAddCfg = NULL;

    pUserAddCfg = malloc(sizeof(ac_user_AddrCfg));
    if (pUserAddCfg == NULL)
    {
        dbgErr("%s[%d]malloc faild!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    memcpy(pUserAddCfg, &s_acAcDspUserAddrCfg, sizeof(ac_user_AddrCfg)); 

    /*通过mmap将物理地址映射到用户进程的虚拟地址空间*/
    Fd = open("/dev/memnc", O_RDWR | O_SYNC);  /*打开内存设备的文件描述符*/
    if (Fd == -1)
    {
        dbgInfo("open /dev/cachedmem failed\n");
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    /*设置用户态共享内存基址和长度*/
    ulAcRamLen = pUserAddCfg->aclength;
    s_ucRamAcDspAddr = mmap(0, ulAcRamLen, PROT_READ | PROT_WRITE, MAP_SHARED, Fd, pUserAddCfg->acaddr);//0x02e8_0000        
    if (s_ucRamAcDspAddr == MAP_FAILED)
    {
        dbgInfo("mmap g_ulRamDspAddr failed %s, %d\n",strerror(errno),errno);
        close(Fd);
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    close(Fd);
    free(pUserAddCfg);

    //清空16M共享空间(按照R8998G典型配置)
    memset((VOID*)s_ucRamAcDspAddr, 0, ulAcRamLen);
    dbgInfo("%s>>ShareRamDspAddr= %p; RamLen= (0x%08X) %d\n",__FUNCTION__, (void*)s_ucRamAcDspAddr, ulAcRamLen, ulAcRamLen);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspAcDataInit
 * 功能描述: 整个ac模块初始化
 * 输入参数: pAddcfg: 给内核的各个配置
             pUserAddCfg: 给用户态的各个配置
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2021年9月23日                   10263250    创建
 **************************************************************************/
UINT32 AcDataInit(VOID)
{
    INT32 Fd = 0; /*内存设备的文件描述符*/
    UINT32 ulAcRamLen = 0;
    ac_user_AddrCfg *pUserAddCfg = NULL;
    UINT32 acFuncLibSta = 0;

    //如果ac funclib已经被初始化过，直接返回
    acFuncLibSta = BspGetAcFuncLibSta();
    if(1 == acFuncLibSta)
    {
        dbgInfo("[%s] ac FuncLib already Inited \n", __FUNCTION__);
        return BSP_OK;
    }
	
    
    SetRecordAcDoInfoInit();
    recordAcDataInitCnt();

    pUserAddCfg = malloc(sizeof(ac_user_AddrCfg));
    if (pUserAddCfg == NULL)
    {
        dbgErr("%s[%d]malloc faild!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    memcpy_s(pUserAddCfg, sizeof(ac_user_AddrCfg), &s_acUserAddrCfg, sizeof(ac_user_AddrCfg)); 

    /*通过mmap将物理地址映射到用户进程的虚拟地址空间*/
    Fd = open("/dev/memnc", O_RDWR | O_SYNC);  /*打开内存设备的文件描述符*/
    if (Fd == -1)
    {
        dbgInfo("open /dev/cachedmem failed\n");
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    /*设置用户态共享内存基址和长度*/
    ulAcRamLen = pUserAddCfg->aclength;
    s_ucRamDspAddr = mmap(0, ulAcRamLen, PROT_READ | PROT_WRITE, MAP_SHARED, Fd, pUserAddCfg->acaddr);//0xC000_0000        
    if (s_ucRamDspAddr == (UINT8 *)(-1))
    {
        dbgInfo("mmap g_ulRamDspAddr failed %s, %d\n",strerror(errno),errno);
        close(Fd);
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    close(Fd);
    free(pUserAddCfg);
    memset((VOID*)s_ucRamDspAddr, 0, ulAcRamLen);
	
    BspSetBoardAcInfo();
    BspAcDspAcDataInit();
    BspRestAcInt();
    BspAcKoInit();
    BspSetAcFuncLibSta(1); //标记ac funclib已经被初始化过

    dbgInfo("%s>>ShareRamDspAddr= %p; RamLen= (0x%08X) %d\n",__FUNCTION__, s_ucRamDspAddr, ulAcRamLen, ulAcRamLen);
    

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 BspGetPauRelativeAmp(UINT32 ulChan, INT32 lFreq, INT32 *plAmp)
{
    TPauRelativeAmpCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;
    UINT32 ulBand = 0;
   
    INPUT_POINTER_CHECK(plAmp);
    *plAmp = 1000;                /*正常范围默认值*/
    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);

    ptCaliData = (TPauRelativeAmpCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEAMP,0);
    PAURELATIVEAMP_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    INPUT_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    if (lFreq <= (INT32)ulStartFreq)
    {
        ulIndex = 0;
        lComps = ptRecord[0].lCompVal;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        ulIndex = ulRecordNum - 1;
        lComps = ptRecord[ulRecordNum-1].lCompVal;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lCompVal,\
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lCompVal);
    }

    *plAmp = lComps;
    dbgInfoEx("%s>>Chnl'%d Band'%d Freq(Step'%d Sta'%d End'%d)'%d:Idx= %d, phase= %d\n",
              __FUNCTION__, ulChan, ulBand, ulStepFreq, ulStartFreq,
              ulEndFreq, lFreq, ulIndex, lComps);

    return BSP_OK;
}

UINT32 BspGetPauRelativeAmpDup(UINT32 ulChan, INT32 lFreq, INT32 *plAmp)
{
    TPauRelativeAmpCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;
    UINT32 ulBand = 0;
   
    INPUT_POINTER_CHECK(plAmp);
    *plAmp = 1000;                /*正常范围默认值*/
    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);

    ptCaliData = (TPauRelativeAmpCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEAMP,0);
    PAURELATIVEAMP_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    INPUT_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    INPUT_AC_ZERO_CHECK(ulStepFreq);

    if (lFreq <= (INT32)ulStartFreq)
    {
        ulIndex = 0;
        lComps = ptRecord[0].lBoardTemp;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        ulIndex = ulRecordNum - 1;
        lComps = ptRecord[ulRecordNum-1].lBoardTemp;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lBoardTemp,\
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lBoardTemp);
    }

    *plAmp = lComps;
    dbgInfoEx("%s>>Chnl'%d Band'%d Freq(Step'%d Sta'%d End'%d)'%d:Idx= %d, phase= %d\n",
              __FUNCTION__, ulChan, ulBand, ulStepFreq, ulStartFreq,
              ulEndFreq, lFreq, ulIndex, lComps);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 BspGetPauRelativePhase(UINT32 ulChan, UINT32 ulBand, INT32 lFreq, INT32 *plPhase)
{
    TPauRelativePhaseCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;
   
    INPUT_POINTER_CHECK(plPhase);
    *plPhase = 0;                 /*正常范围默认值*/
    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);

    ptCaliData = (TPauRelativePhaseCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEPHASE,0);
    PAURELATIVEPHASE_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    INPUT_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    INPUT_AC_ZERO_CHECK(ulStepFreq);

    if (lFreq <= (INT32)ulStartFreq)
    {
        ulIndex = 0;
        lComps = ptRecord[0].lCompVal;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        ulIndex = ulRecordNum - 1;
        lComps = ptRecord[ulRecordNum-1].lCompVal;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lCompVal,\
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lCompVal);
    }

    *plPhase = lComps;
    dbgInfoEx("%s>>Chnl'%d Band'%d Freq(Step'%d Sta'%d End'%d)'%d:Idx= %d, phase= %d\n",
              __FUNCTION__, ulChan, ulBand, ulStepFreq, ulStartFreq,
              ulEndFreq, lFreq, ulIndex, lComps);

    return BSP_OK;
}

/* Started by AICoder, pid:7efba82467o3d8e14a020aad60430e7ffea5748d */
UINT32 BspGetPauRelativePhaseData(UINT32 ulChan, UINT32 ulBand, UINT32 pauIdx, INT32 lFreq, INT32 *plPhase)
{
    TPauRelativePhaseCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq = 0;
    UINT32 ulRecordNum, ulIndex = 0;
    INT32  lComps = 0;

    INPUT_POINTER_CHECK(plPhase);
    *plPhase = 0;                 /*正常范围默认值*/
    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);

    ptCaliData = (TPauRelativePhaseCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEPHASE,0);
    PAURELATIVEPHASE_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    INPUT_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    INPUT_AC_ZERO_CHECK(ulStepFreq);

    if (lFreq <= (INT32)ulStartFreq)
    {
        ulIndex = 0;
        if(pauIdx == 0)
        {
            lComps = ptRecord[0].lCompVal;
        }
        else
        {
            lComps = ptRecord[0].lBoardTemp;
        }
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        ulIndex = ulRecordNum - 1;
        if(pauIdx == 0)
        {
            lComps = ptRecord[ulRecordNum-1].lCompVal;
        }
        else
        {
            lComps = ptRecord[ulRecordNum-1].lBoardTemp;
        }
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        if(ulIndex + 1 >= ulRecordNum)
        {
            ulIndex = ulRecordNum - 2; /* 确保索引有效 */
        }
        if(pauIdx == 0)
        {
            lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lCompVal,\
                                    ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lCompVal);
        }
        else
        {
            lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lBoardTemp,\
                                    ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lBoardTemp);
        }
    }

    *plPhase = lComps;
    dbgInfoEx("%s>>Chnl'%d Band'%d Freq(Step'%d Sta'%d End'%d)'%d:Idx= %d, phase= %d\n",
              __FUNCTION__, ulChan, ulBand, ulStepFreq, ulStartFreq,
              ulEndFreq, lFreq, ulIndex, lComps);

    return BSP_OK;
}
/* Ended by AICoder, pid:7efba82467o3d8e14a020aad60430e7ffea5748d */

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 BspGetPauRelativeAmpPhase(UINT32 dir, UINT32 chan, INT32 centFreq, UINT32 bandWidth, T_AcWeightData pData[AC_WEIGHT_DATA_NUM])
{

    INT32  freqStep, freq;
    INT32  loop, center;
    INT32  amp, phase;
    UINT32 acwgtdatanum = AC_WEIGHT_DATA_NUM;
    UINT32 uiChanOrgNum;
    UINT32 chanTmp;

    uiChanOrgNum = BspGetAntNum();
    INPUT_POINTER_CHECK(pData);
    INPUT_AC_ZERO_CHECK(uiChanOrgNum);

    for(loop = 0;loop<AC_WGTDATA_GROUP_NUM;loop++)
    {
        if(bandWidth==ac_WgtDataNum[loop][0])
        {
            acwgtdatanum = ac_WgtDataNum[loop][1];
            dbgInfoEx("chan:%d,bw:%d,centfreq:%d,loop:%d,acwgtdatanum:%d\n",chan,bandWidth,centFreq,loop,acwgtdatanum);
            break;
        }
    }

    /*先填成默认值*/
    for (loop = 0; loop < AC_WEIGHT_DATA_NUM; loop++)
    {
        pData[loop].amplitude = 1000;
        pData[loop].phase = 0;
    }

    /*根据实际要求修改*/
    freqStep = (INT32)bandWidth/ acwgtdatanum / 100 * 100;
    center   = acwgtdatanum / 2;
    for (loop = 0; loop < acwgtdatanum; loop++)
    {
        freq = (loop - center) * freqStep + centFreq;
        amp = 1000, phase = 0;
        if( (uiChanOrgNum-1) < chan) 
        {
            chanTmp = chan % uiChanOrgNum;
            BspGetPauRelativePhaseDup(chanTmp,0,freq,&phase);
        }
        else
        {
            BspGetPauRelativePhase(chan,0,freq,&phase);
        }
        pData[loop].amplitude = amp;
        pData[loop].phase = phase;

        dbgInfoEx("dir:%d,chn:%d,bw:%d,centfreq:%d,freq:%d,idx:%d,amp:%d,phase:%d\n",dir,
                  chan,bandWidth,centFreq,freq,loop,amp,phase);
    }

    return BSP_OK;
}

UINT32 BspGetPauRelativeAmpPhaseLte(UINT32 chan, INT32 centFreq, T_PauRelativeRec *ptData)
{
#if 0
    INT32  freqStep, freq;
    INT32  loop, center;
    INT32  amp, phase;
    UINT32 bandWidth = 20000; //4G固定20M带宽
    UINT32 acWeightDataNum = 19;
    UINT32 aauChann = 0;

    dbgInfoEx("%s:chn:%d,centfreq:%d\n", __FUNCTION__, chan,centFreq);
    GetAauAntNumFromUserAntNum(chan, &aauChann);

    /* 按带宽等分，最小颗粒100KHz */
    freqStep = (INT32)bandWidth/ acWeightDataNum / 100 * 100; // 固定按1M间隔，离线文件
    center   = acWeightDataNum / 2;
    for (loop = 0; loop < acWeightDataNum; loop++)
    {
        freq = (loop - center) * freqStep + centFreq;
        amp = 1000, phase = 0;
        BspGetPauRelativeAmp(aauChann,freq,&amp);
        BspGetPauRelativePhase(aauChann,0,freq,&phase);
        ptData->sAmp[loop] = amp;
        ptData->sPhase[loop] = phase;

        dbgInfoEx("aauchn:%d,centfreq:%d,freq:%d,idx:%d,amp:%d,phase:%d\n",
                  aauChann,centFreq,freq,loop,amp,phase);
    }
#endif
    return BSP_OK;
}

UINT32 BspGetAntAmpPhase(UINT32 ulPath, UINT32 ulCarrFreq, T_PauRelativeRec *ptData)
{
    T_PauRelativeRec * ptVal = ptData;

    TBL_CHAN_VALID_CHECK(ulPath);
    INPUT_POINTER_CHECK(ptData);

    ptVal->ulPath = ulPath;

    if(BspGetPauRelativeAmpPhaseLte(ulPath, ulCarrFreq, ptData) != BSP_OK)
    {
        dbgInfo("[%s]ulPath'%d, ulCarrFreq = %d\n",__FUNCTION__, ulPath, ulCarrFreq);
        return BSP_ERROR;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetACWeightData(*)
 * 功能描述: 获取AC权值
 * 输入参数: ulChn - 通道号(从0开始)
             ulCarr- 载波号(从0开始)
             ulDir - 上下行(1:TX,0:RX)
 * 输出参数: pData - 99组权重值,以载波ulCarr为中心的上下各49个
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月14日 10090699    创建
 **************************************************************************/
/* Started by AICoder, pid:l286bj10a42719d148770aebd0c9af3774e8291b */
UINT32 BspGetACWeightData(UINT32 chan, UINT32 carrNo, UINT32 dir, T_AcWeightData pData[AC_WEIGHT_DATA_NUM])
{
    UINT32 ret;
    UINT32 centFreq;
    UINT32 bandWidth;
    UINT32 uiChanOrgNum;
    UINT32 uichanTmp;
    UINT32 uiLoop = 0;
    TPauRelativeAmpCaliData *ptCaliData = NULL;

    INPUT_POINTER_CHECK(pData);
    TBL_CHAN_VALID_CHECK(chan);

    ptCaliData = (TPauRelativeAmpCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEAMP, 0);
    INPUT_POINTER_CHECK(ptCaliData);

    uiChanOrgNum = BspGetAntNum();
    INPUT_AC_ZERO_CHECK(uiChanOrgNum);
    dbgInfoEx("%s<< chan:%d,dir:%d\n", __FUNCTION__, chan, dir);
    uichanTmp = chan % uiChanOrgNum;

    if (TBL_LOAD_SUCC != (ptCaliData->atPath[uichanTmp].ulLoadFlag))
    {
        for (uiLoop = 0; uiLoop < AC_WEIGHT_DATA_NUM; uiLoop++)
        {
            pData[uiLoop].amplitude = 1000;
            pData[uiLoop].phase = 0;
        }
        dbgInfoEx("[%s], PAURELATIVEAMP not loaded \n", __FUNCTION__);
        return BSP_OK;
    }

    centFreq = BspGetCarrFreq(dir, uichanTmp, carrNo);
    bandWidth = BspGetFreqBw(dir, uichanTmp, carrNo);
    dbgInfoEx("%s<< centFreq:%d,bandWidth:%d\n", __FUNCTION__, centFreq, bandWidth);
    ret = BspGetPauRelativeAmpPhase(dir, chan, (INT32)centFreq, bandWidth, pData);
    return ret;
}
/* Ended by AICoder, pid:l286bj10a42719d148770aebd0c9af3774e8291b */



void BspGetCoupleNetFactor_m(UINT32 dir, UINT32* aulData, UINT32 chanEnd, T_Cmac2PulmAntAdjustScheInfoIc3* ptInfo)
{
    UINT32 chan = 0;
    UINT32 retVal = 0;
    for (chan = 0; chan < chanEnd; chan++)
    {
        retVal = BspGetCoupleNetFactor(chan, ptInfo->acMsgHeaderReq.uiCellId, dir, &aulData[0]);
        if(retVal == BSP_OK)
        {
            BspGetCoupleNetFactor(chan, ptInfo->acMsgHeaderReq.uiCellId, dir, &aulData[0]);
            memcpy_s((VOID *)ptInfo->axsCoupleNetFactor[chan], sizeof(UINT32) * AC_WEIGHT_DATA_NUM, (VOID *)aulData, sizeof(UINT32) * AC_WEIGHT_DATA_NUM);
            dbgInfo("%s Factor=%d\n", __FUNCTION__,ptInfo->axsCoupleNetFactor[chan][0]);
        }
    }
    return;
}


UINT32 BspGetCoupleNetFactor(UINT32 antNo, UINT32 carrNo, UINT32 dir, UINT32 aulData[])
{
    UINT32 loop     = 0;
    DOUBLE amp      = 0.0;
    DOUBLE angle    = 0.0;
    UINT16 iData    = 0;
    UINT16 qData    = 0;
    
    T_AcWeightData *ptData = NULL;

    ptData = malloc(sizeof(T_AcWeightData) * AC_WEIGHT_DATA_NUM);
    INPUT_POINTER_CHECK(ptData);
    dbgInfoEx("BspGetCoupleNetFactor  carrNo:%d,dir:%d,antNo:%d\n",carrNo,dir,antNo);
    memset((VOID*)ptData, 0, sizeof(T_AcWeightData) * AC_WEIGHT_DATA_NUM);
    BspGetACWeightData(antNo, carrNo, dir, ptData);
    for (loop = 0; loop < AC_WEIGHT_DATA_NUM; loop++)
    {
        amp   = (DOUBLE)ptData[loop].amplitude / 1000.0;
        angle = ((DOUBLE)ptData[loop].phase / 100.0) * ANTCAL_PI / 180; 

        iData = (UINT16)(((INT32)(amp * cos(angle) * pow(2, 14)) + 65536) % 65536);
        qData = (UINT16)(((INT32)(amp * sin(angle) * pow(2, 14)) + 65536) % 65536);
        aulData[loop] = (iData << 16) + qData;
        dbgInfoEx("BspGetCoupleNetFactor  aulData:%x\n",aulData[loop]);
    }
    
    free(ptData);
    return BSP_OK;
}
/* Started by AICoder, pid:3341849e70d4c55147c00b578078985efb6277d4 */
UINT32 BspGetIf0LteCoupleNetFactor(UINT32 uiAnt, UINT32 uiCenterFreq, UINT32 uiBandWidth, T_acCoupleNet *pAcCpNet)
{
    INT32  iFreqStep = 0;
    INT32  iFreq = 0;
    INT32  iLoop = 0;
    INT32  iCenterFeq = 0;
    INT32  iPhase = 0;
    INT32  iDataNum = AC_LTE_COUPLE_NUM;
    UINT32 uiDataOffset = 0;
    T_acCoupleNet tAcLteCpNet[AC_LTE_COUPLE_NUM] = {0};
    UINT32 uiDataMap[AC_LTE_COUPLE_BAND_NUM_MAX][2] = {{20000, 0}, {15000, 3}, {10000, 5}, {5000, 7}};

    INPUT_AC_ZERO_CHECK(pAcCpNet);

    dbgInfoEx("uiAnt:%d, uiBandWidth:%d, centfreq:%d \n", uiAnt, uiBandWidth, uiCenterFreq);
    for(iLoop = 0;iLoop < AC_WGTDATA_GROUP_NUM;iLoop++)
    {
        if(uiBandWidth == ac_WgtDataNum[iLoop][0])
        {
            iDataNum = ac_WgtDataNum[iLoop][1];
            dbgInfoEx("iLoop:%d, iDataNum:%d \n", iLoop, iDataNum);
            break;
        }
    }

    for (iLoop = 0; iLoop < AC_LTE_COUPLE_NUM; iLoop++)
    {
        tAcLteCpNet[iLoop].uiAmp = 10000; //幅度默认值
        tAcLteCpNet[iLoop].uiPha = 18000; //相位默认值
    }

    /*根据实际要求修改*/
    iFreqStep  = (INT32)uiBandWidth / iDataNum / 100 * 100;
    iCenterFeq = iDataNum / 2;
    for (iLoop = 0; iLoop < iDataNum; iLoop++)
    {
        iFreq = (iLoop - iCenterFeq) * iFreqStep + uiCenterFreq;
        BspGetPauRelativePhase(uiAnt, 0, iFreq, &iPhase);
        dbgInfoEx("uiAnt:%d, iFreq:%d, iPhase:%d \n", uiAnt, iFreq, iPhase);
        tAcLteCpNet[iLoop].uiPha = iPhase + 18000; //与BBU约定原始相位加180°乘100
    }

    for(iLoop = 0; iLoop < AC_LTE_COUPLE_BAND_NUM_MAX; iLoop++)
    {
        if(uiBandWidth == uiDataMap[iLoop][0])
        {
            uiDataOffset = uiDataMap[iLoop][1];
            dbgInfoEx("iLoop:%d, iDataNum:%d \n", iLoop, uiDataOffset);
            break;
        }
    }
    for(iLoop = 0; iLoop < iDataNum; iLoop++)
    {
        pAcCpNet[iLoop + uiDataOffset].uiPha = tAcLteCpNet[iLoop].uiPha;
        pAcCpNet[iLoop + uiDataOffset].uiAmp = tAcLteCpNet[iLoop].uiAmp;
        dbgInfoEx("dataOffset:%d, Pha:%d \n", (iLoop + uiDataOffset), pAcCpNet[iLoop + uiDataOffset].uiPha);
        dbgInfoEx("dataOffset:%d, Amp:%d \n", (iLoop + uiDataOffset), pAcCpNet[iLoop + uiDataOffset].uiAmp);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:3341849e70d4c55147c00b578078985efb6277d4 */
/* Started by AICoder, pid:nd224v2a7e1834c1437b0805e0a1077ac264a76c */
UINT32 BspGetAcRelativePhaseData(UINT32 chan, UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep, UINT32 **pData)
{
    TPauRelativePhaseCaliData *ptCaliData = NULL;
    UINT32 startFreq = 0;
    UINT32 stopFreq  = 0;
    UINT32 freqStep  = 0;
    UINT32 freq  = 0;
    INT32  phase = 0;
    DOUBLE amp   = 1.0;
    DOUBLE angle = 0.0;
    UINT16 iData = 0;
    UINT16 qData = 0;
    UINT32 index = 0;
    UINT32 pauNum = 0;
    UINT32 pauIndex = 0;
    T_AllRfBridgeInfo info = {0};
    UINT32 retVal = BSP_OK;

    TBL_CHAN_VALID_CHECK(chan);
    INPUT_POINTER_CHECK(pStartFreq);
    INPUT_POINTER_CHECK(pStopFreq);
    INPUT_POINTER_CHECK(pStep);
    INPUT_POINTER_CHECK(pData);
    ptCaliData = (TPauRelativePhaseCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEPHASE,0);
    PAURELATIVEPHASE_LOADED_CHECK(ptCaliData,chan);
    startFreq = ptCaliData->atPath[chan].tHeader.aulStartFreq[0];
    stopFreq = ptCaliData->atPath[chan].tHeader.aulStopFreq[0];
    freqStep  = ptCaliData->atPath[chan].tHeader.aulRfStep[0];
    *pStartFreq = startFreq;
    *pStopFreq = stopFreq;
    *pStep = freqStep;
    retVal = BspGetRfBridgeInfoMap(&info);
    pauNum = info.rfBridgeInfo[0].rfBridgeInPort;
    dbgInfoEx("pauNum:%x\n",pauNum);

    for(freq = startFreq, index = 0; freq <= stopFreq; freq += freqStep, index++)
    {
        for(pauIndex = 0; pauIndex < pauNum; pauIndex++)
        {
            if(index >= MAX_RF_BRIDGE_FREQ_NUM || pauIndex >= VSWR_MAX_RF_BRIDGE_PORT_NUM)
            {
                dbgErr("index or pauIndex is over!\n");
                return BSP_ERROR;
            }
            retVal |= BspGetPauRelativePhaseData(chan,0,pauIndex,freq,&phase);
            pData[index][pauIndex] = (UINT32)phase;

            dbgInfoEx("chn:%d,pauIndex:%d,freq:%d,idx:%d,phase:%d\n",
                      chan,pauIndex,freq,index,pData[index][pauIndex]);
            angle = ((DOUBLE)phase / 100.0) * ANTCAL_PI / 180;
            iData = (UINT16)(((INT32)(amp * cos(angle) * pow(2, 14)) + 65536) % 65536);
            qData = (UINT16)(((INT32)(amp * sin(angle) * pow(2, 14)) + 65536) % 65536);
            pData[index][pauIndex] = (iData << 16) + qData;
            dbgInfoEx("aulData:%x\n",pData[index][pauIndex]);
        }
    }
    return retVal;
}
/* Ended by AICoder, pid:nd224v2a7e1834c1437b0805e0a1077ac264a76c */

/**************************************************************************
 * 函数名称: BspCaliTaDfNs
 * 功能描述: 计算频点为ulFre的TaDfNs值
 * 输入参数: ulChan - 通道号(从0开始)
             ulFre- 中心频点
 * 输出参数: wTaDfNs - 计算结果
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年09月04日 xuping    创建
 **************************************************************************/
INT32 BspCaliTaDfNs(UINT32 ulChan, UINT32 ulFre ,UINT16 *wTaDfNs)
{
    INT32  lFilterDelay = 0;
    INT32  lAntDelay    = 0;
    INT32  lFilterDelay0= 0;
    INT32  lAntDelay0   = 0;
    INT16  wTaDf        = 0;
       
    if(_BspGetFilterDelayVal(0, ulFre, &lFilterDelay0) != BSP_OK)
    {		
        return BSP_ERROR;
    }
    
    if(_BspGetAntDelayVal(0, ulFre, &lAntDelay0) != BSP_OK)
    {
        return BSP_ERROR;
    }
    
    if(_BspGetFilterDelayVal(ulChan, ulFre, &lFilterDelay) != BSP_OK)
    {
        return BSP_ERROR;
    }
    
    if(_BspGetAntDelayVal(ulChan, ulFre, &lAntDelay) != BSP_OK)
    {
        return BSP_ERROR;
    }
    
    wTaDf = (INT16)(lFilterDelay0+lAntDelay0-lFilterDelay-lAntDelay);
    *wTaDfNs = wTaDf;
    
    dbgInfoEx("%s<< FreRbi = %d, TaDfNs[%d] = FilterDelay0[%d] + AntDelay0[%d] - FilterDelay[%d] - AntDelay[%d]\n", \
        __FUNCTION__,ulFre,wTaDf,lFilterDelay0,lAntDelay0,lFilterDelay,lAntDelay);
    
    return BSP_OK; 
}

/**************************************************************************
 * 函数名称: BspGetTaDfNs
 * 功能描述: 计算以载波ulCarr为中心的RB值对应的TaDfNs
 * 输入参数: ulChan - 通道号(从0开始)
             ulCellFre- 中心频点
 * 输出参数: wTaDfNs - 以载波ulCarr为中心的RB值对应的TaDfNs
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年09月02日 xuping    创建
 **************************************************************************/
UINT32 BspGetTaDfNs(UINT32 ulChan,UINT32 ulCellFre, INT16 wTaDfNs[])
{
#if 0
    UINT32 ulLoop    = 0;
    UINT32 ulFreRbi  = 0;
    UINT32 ulRet     = 0;
    s_ulCellFre = ulCellFre;
    if(BspGetRfTblLoadResult(TBL_KIND_OF_FILTERDELAY) == TBL_LOAD_SUCC && BspGetRfTblLoadResult(TBL_KIND_OF_ANTDELAY) == TBL_LOAD_SUCC)
    {		
        for (ulLoop = 0; ulLoop < AC_ANT_WGT_NUM_NR_MAX; ulLoop++)
        {
            ulFreRbi=((ulLoop*(UINT32)12+(UINT32)6)*(UINT32)30-(UINT32)1638*(UINT32)30)+ulCellFre;
            dbgInfoEx("%s<< Loop = %d, ", __FUNCTION__,ulLoop);
            ulRet = BspCaliTaDfNs(ulChan,ulFreRbi,&wTaDfNs[ulLoop]);
            if(ulRet != BSP_OK)
            {
                dbgInfoEx("%s err, BspCaliTaDfNs Get Ch%d TaDfNsValue failed\n", __FUNCTION__,ulLoop);
                return BSP_ERROR;
            }
        }
    }
    else
    {
        for (ulLoop = 0; ulLoop < AC_ANT_WGT_NUM_NR_MAX; ulLoop++)
        {
            wTaDfNs[ulLoop]=10; //先给定10，后期再修改
        }
        /*如果文件加载失败，后期需要给定默认值？*/
        dbgInfoEx("%s err, antdelay.txt Or filterdelay.txt initialization failed\n", __FUNCTION__);
    }
#endif
    return BSP_OK;
}

VOID BspGetTaDfNsTest(VOID)
{
    INT16  wTaDfNs[273] = {0};
    for (UINT32 chan = 0; chan < BspGetTxChannel(); chan++)
    {
        dbgInfo("\n################PathNum[%d]###############\n",chan);
        BspGetTaDfNs(chan,2565000, wTaDfNs);
    }
}

UINT32 BspSetAcFuncVerId(UINT32 verId)
{
    s_acFuncVerId = verId;
    return BSP_OK;
}

UINT32 BspGetAcFuncVerId(VOID)
{
    return s_acFuncVerId;
}

/**********************************************************************
* 函数名称：BspDirDataLoad
* 功能描述：获取单音频点对应的广播权值
* 输入参数：index : 选择第几组测试
* 输出参数：dirData:  返回对应的64天线方向权值数据
* 返 回 值：BSP_OK - 成功
* 其它说明：天线权值文件23组,每组64*23行数据,每个天线23行,先
* 修改日期       版本号      修改人      修改内容
* -----------------------------------------------
*
***********************************************************************/
UINT32 BspDirDataLoad(UINT32 index,UINT32 *dirData,UINT32 *dataLen)
{
    UINT32 *buf;
    FILE   *fp;
    struct stat statInfo;
    char   fileName[32] = {0};
    char   lineData[100] = {0};
    UINT32 num = 0;
    UINT32 loop = 0;
    UINT32 chanNum = BspGetTxChannel();
    INT32  snpRet = 0;
    INT32  lClsRet = 0;

    INPUT_POINTER_CHECK(dirData);
    INPUT_POINTER_CHECK(dataLen);

    snpRet = snprintf_s(fileName,sizeof(fileName),"/ata/%dantBCweight.dat",chanNum);
    SNPRINTF_S_CHECK(snpRet, sizeof(fileName));

    fp = fopen(fileName, "r");
    if (fp == NULL)
    {
        dbgErr("failed to open file %s\n", fileName);
        return BSP_ERROR;
    }
    if (BSP_OK != stat(fileName,&statInfo))
    {
        dbgErr("not exist file %s\n", fileName);
        lClsRet = fclose(fp);
        FCLOSE_CHECK(lClsRet);
        return BSP_ERROR;
    }
    buf = (UINT32 *)malloc(statInfo.st_size);
    if (buf == NULL)
    {
        dbgErr("malloc failed\n");
        lClsRet = fclose(fp);
        FCLOSE_CHECK(lClsRet);
        return BSP_ERROR;
    }
    memset(buf, 0, statInfo.st_size);

    while (!feof(fp) && fgets(lineData,sizeof(lineData),fp) != NULL)
    {
        buf[num++] = strtoul(lineData,NULL,16);
        memset(lineData,0,sizeof(lineData));
    }

    if (!feof(fp)) /* 读文件未到结尾,说明有异常退出 */
    {
        lClsRet = fclose(fp);
        FCLOSE_CHECK(lClsRet);
        free(buf);
        dbgErr("abnormal assert!");
        return BSP_ERROR;
    }
    lClsRet = fclose(fp);
    FCLOSE_CHECK(lClsRet);

    if ((index+1)*chanNum > num)
    {
        dbgErr("%s index %d or num %d error\n",__FUNCTION__,index,num);
        free(buf);
        return BSP_ERROR;
    }

    *dataLen = min(chanNum, *dataLen);
    for(loop = 0; loop < *dataLen; loop++)
    {
        dirData[loop] = buf[index*chanNum+loop];
    }
    
    free(buf);
    return BSP_OK;
}

/**********************************************************************
* 函数名称：BspGetTsgFreRb
* 功能描述：获取单音对应的RB索引
* 输入参数：signalToneFreq : 单音频点
* 输出参数：无
* 返 回 值：BSP_OK - 成功
* 其它说明：无
* 修改日期       版本号      修改人      修改内容
* -----------------------------------------------
*
***********************************************************************/
UINT32 BspGetTsgFreRb(INT32 toneFreq)
{
    UINT32 rbNo = 0;

    if(toneFreq < 0)
    {
        rbNo = (floor)(136 + (0-toneFreq - 15) / 360.0);
    }
    else
    {
        rbNo = (floor)(135 - (toneFreq - 15) / 360.0);
    }
    return rbNo;
}

UINT32 BspSetAcBcWgt(T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    return BSP_OK;
}

UINT32 testnetfactor(UINT32 antNo, UINT32 carrNo,UINT32 dir)
{
    UINT32 showColSum = 8;
    UINT32 netFactor[AC_WEIGHT_DATA_NUM] = {0,};

    BspGetCoupleNetFactor(antNo, carrNo, dir, netFactor);
    showColSum = 8;
    dbgInfo("%s>>Ant'%d Carr'%d AcDataSum''%d CoupleNetFactor:\n",
            __FUNCTION__, antNo, carrNo, AC_WEIGHT_DATA_NUM);
    TEST_DATA_BUF_PRINT(2, (0 << 16) | showColSum, 0, netFactor, 0, AC_WEIGHT_DATA_NUM - 1);
    return BSP_OK;
}

///启动计算AC序列
UINT32 CalAcSeqIc(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag)
{  
    UINT32 chan              = 0;
    UINT32 freqNo            = carrNo;
    UINT32 cellId            = carrNo;
    UINT32 retVal            = BSP_OK;
    UINT32 uiAcType          = 0;
    UINT32 uiAcNetFactorMode     = 0;
    uiAcNetFactorMode = BspGetAcNetMode();
    T_ICHAL_ACPARA* acPara   = NULL;

    recordCalAcSeqIcCnt();
    
    dbgInfoEx("carrNo:%d,pasteCarrFlag:%d,deviate:%d,bandWidth:%d,sampleRate:%d,\
            radioMode:%d,acType:%d,seqType:%d,refChan:%d,preciseDlyFlag:%d\n",carrNo,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,acType,seqType,refChan,preciseDlyFlag);
    carrPasteFlagM[carrNo%MAX_CARR_NUM] = pasteCarrFlag;
    uiAcType = acType;
    dbgInfo("[%s] uiAcType:%d, acType:%d \n", __FUNCTION__, uiAcType, acType);
    //RunPrndlpostpaptalm();
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);

    if(AC_NETMODE_DUP == uiAcNetFactorMode)
    {
        refChan = acPara->acStartChan;  //9626e机型高层下发参数从通道0开始，实际发采数从通道2开始
    }

    BspHandleAcFuncLog();
    AcFuncLogM(AC_FUNC_LOG_HIGH, "SeqCal acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, seqType:%d, refChn:%d, preciseDlyFlag:%d \n",
                                acType, radioMode, bandWidth, carrNo, seqType, refChan, preciseDlyFlag);

    retVal = BspAcSeqCalcIc4(chan, freqNo, cellId, pasteCarrFlag, deviate, bandWidth, sampleRate,radioMode,uiAcType,seqType,refChan,preciseDlyFlag);
    

    return retVal;
}

//检查序列是否计算完
UINT32 ChkAcSeqIc(UINT32 chan)
{
    //目前的策略是等待1秒钟
    recordChkAcSeqIcCnt();
    return 0;
}

UINT32 g_saveAcSeqFlag = 0;
VOID setSaveAcSeqFlag(UINT32 val)
{
    g_saveAcSeqFlag = val;
}
UINT32 saveAcSeqNxp(UINT32* seq, UINT32 length)
{
    UINT32 ret          = BSP_OK;
    UINT32 jLoop        = 0;
    INT32  lFprtfRet    = 0;
    INT32  lClsRet      = 0;

    if(0 == g_saveAcSeqFlag)
    {
        return ret;
    }
    INPUT_POINTER_CHECK(seq);
    
    FILE*  fp     = fopen("AcSeqNxp.txt", "w+");
    if(fp == NULL)
    {
        return BSP_ERROR;
    }

    for (jLoop = 0; jLoop < length/4; jLoop++)
    {
        lFprtfRet = fprintf_s(fp,"0x%08x\n",seq[jLoop]);
        FPRINTF_CHECK(lFprtfRet);
        dbgInfoEx("[%d] Data = 0x%08x \n", jLoop, seq[jLoop]);
    }

    lClsRet = fclose(fp);
    FCLOSE_CHECK(lClsRet);
	
    dbgInfo("\n**** see file AcSeqNxp.txt ****\n\n");
    return ret;
}

//获取AC序列
UINT32 GetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length)
{
    UINT8  *seqAddr  = NULL;
    UINT8  *baseAddr = NULL;
    UINT32 seqSize   = 0;
    UINT32 jLoop     = 0;
    UINT32 loopSel   = 0;
    UINT32 offsetAddr = 0;
    UINT32 antAddrOffset = 0;
    UINT32 difChipId = 0;
    UINT32 difChan   = 0;
    UINT32 antNo     = 0;
    UINT32 antChn    = 0;
    UINT32 targetAntChn = 0;
    UINT8  *seqTmp   = NULL;
    UINT32 uiDir     = 0;
    UINT32 uiAcType  = 0;

    recordGetAcSeqIcCnt();
    
    dbgInfo("carr:%d,pasteCarrFlag:%d,deviate:%d,bandWidth:%d,sampleRate:%d,radioMode:%d,\
               acType:%d\n",carr,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,acType);
    INPUT_POINTER_CHECK(seq);
    INPUT_POINTER_CHECK(length);

    seqTmp = (UINT8 *)seq;
    if(NULL == (baseAddr = BspGetAcDspMemBaseAddr())) /*  需要修改AC共享内存基址 ，修改为 BspGetAcDspMemBaseAddr*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }
    offsetAddr = NXP_AC_MEM_CPU_RD_AC_SEQ_ADDR;//0x00D80000
    seqAddr = offsetAddr + baseAddr;

    uiAcType = BspJudgeAcType(acType);
    dbgInfo("[%s] uiAcType:%d, acType:%d \n", __FUNCTION__, uiAcType, acType);
    uiDir = (0 == uiAcType) ? TX : RX;
    dbgInfo("[%s] uiAcType:%d, rfDir:%d \n", __FUNCTION__, uiAcType, uiDir);

    //序列拷贝
    for (loopSel = 0; loopSel < BspGetTxChannel(); loopSel++)
    {
        if(BSP_OK != BspGetDifInfoByRfChn(loopSel, uiDir, &difChipId, &difChan))
        {
            dbgErr("%s BspGetDifInfoByRfChn(%d,%d) return error\n", __FUNCTION__, loopSel, uiAcType);
            return BSP_ERROR;
        }
        dbgInfoEx("BspGetDifInfoByRfChn chan = %d, difChipId = %d, difChan = %d\n",loopSel,difChipId,difChan);

        if(BSP_OK != BspGetAntInfoByRfChn(loopSel, uiDir, &antNo, &antChn))
        {
            dbgErr("%s BspGetAntInfoByRfChn(%d,%d) return error\n", __FUNCTION__, loopSel, uiAcType);
            return BSP_ERROR;
        }
        antNo = antNo -1; //主控link表定义中的天线号为控制面天线号,从1开始，这里必须-1;
        dbgInfoEx("BspGetAntInfoByRfChn chan = %d, antNo = %d, antChn = %d\n",loopSel,antNo,antChn);
        if(E_AC_TYPE_DL == uiAcType)
        {
            antAddrOffset = antNo * NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
            if(targetAntChn == antChn)
            {
                memcpy_s((UINT8*)seqTmp, NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024, (UINT8*)(seqAddr+ antAddrOffset), NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024);
                seqTmp += NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
                seqSize += NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
                dbgInfoEx("seqTmp:%p,sourceAddr:%p,seqSize:%d\n", (void*)seqTmp, (void*)(seqAddr+ antAddrOffset),seqSize);
            }
        }
        else if(E_AC_TYPE_UL == uiAcType)
        {
            memcpy_s((UINT8*)seqTmp, NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024, (UINT8*)(seqAddr), NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024);
            seqSize += NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
            dbgInfoEx("seqTmp:%p,sourceAddr:%p,seqSize:%d\n", (void*)seqTmp, (void*)seqAddr, seqSize);
            break;
        }
        else
        {
            //do nothing
        }
    }
    *length = seqSize;

    jLoop = 0;
    for (jLoop = 0; jLoop < seqSize/4; jLoop++)
    {
        dbgInfoEx("[%d] Data = 0x%08x \n", jLoop, seq[jLoop]);
    }

    AcFuncLogM(AC_FUNC_LOG_HIGH, "SeqGet socId:%d, acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, seqLen:%d \n",
                                0, acType, radioMode, bandWidth, carr, *length);

    dbgInfo("[%s]baseAddr %p, seqAddr %p, seqSize 0x%08X\n", __FUNCTION__, (void*)baseAddr, (void*)seqAddr, seqSize);
    

    return BSP_OK;
}

UINT32 BspGetAcParaInfo(UINT32 radioMode, UINT32 pasteCarrFlag, UINT32 bandWidth, T_AcParaInfo* ptAcParaInfo)
{
    UINT32 loop     = 0;
    UINT32 num      = 0;
    UINT32 retVal = BSP_ERROR;

    num = (sizeof(g_acAllParaInfo) / sizeof(g_acAllParaInfo[0]));
    for(loop=0;loop < num;loop++)
    {
        if (CARR_NOT_PASTE != pasteCarrFlag)
        {
            ptAcParaInfo->sample       = CLK_RATE_122P88;
            ptAcParaInfo->acSeqLen     = AC_DATA_LEN_1024;
            ptAcParaInfo->acDataOffset = AC_DATA_OFFSET_128;
            ptAcParaInfo->acCpLen      = AC_CP_64;
            retVal = BSP_OK;
            break;
        }
        if((radioMode == g_acAllParaInfo[loop].radio)&&(bandWidth == g_acAllParaInfo[loop].bandWidth))
        {
            ptAcParaInfo->sample       = g_acAllParaInfo[loop].sample;
            ptAcParaInfo->acSeqLen     = g_acAllParaInfo[loop].acSeqLen;
            ptAcParaInfo->acDataOffset = g_acAllParaInfo[loop].acDataOffset;
            ptAcParaInfo->acCpLen      = g_acAllParaInfo[loop].acCpLen;
            retVal = BSP_OK;
        }
    }

    dbgInfo("\n%s sample:%d acSeqLen:%d acDataOffset:%d acCpLen:%d\n",__FUNCTION__,\
            ptAcParaInfo->sample, ptAcParaInfo->acSeqLen, ptAcParaInfo->acDataOffset,ptAcParaInfo->acCpLen);

    return retVal;
}

UINT32 g_saveAcSeqIc3 = 0;
VOID setSaveAcSeqIc3(UINT32 val)
{
    g_saveAcSeqIc3 = val;
}

UINT32 saveAcSeqIc3(UINT32* seq, UINT32 length)
{
    UINT32 ret    = BSP_OK;
    UINT32 jLoop  = 0;
    INT32 iTmpRet    = 0;

    if(0 == g_saveAcSeqIc3)
    {
        return ret;
    }
    INPUT_POINTER_CHECK(seq);
    
    FILE*  fp = fopen("AcSeqIc.txt", "w+");
    if(fp == NULL)
    {
        return BSP_ERROR;
    }

    for (jLoop = 0; jLoop < length/4; jLoop++)
    {
        iTmpRet = fprintf(fp,"0x%08x\n",seq[jLoop]);
        FPRINTF_CHECK(iTmpRet);
        dbgInfoEx("[%d] Data = 0x%08x \n", jLoop, seq[jLoop]);
    }

    if(-1 == fclose(fp))
    {
        dbgErr("fclose err\n");
        return BSP_ERROR;
    }

    dbgInfo("\n**** see file AcSeqIc.txt ****\n\n");
    return ret;
}

UINT32 printAcSeqFromOam(UINT32* seq, UINT32 length)
{
    INPUT_POINTER_CHECK(seq);
    UINT32 point = 0;

    if(0 == g_saveAcSeqIc3)
    {
        return BSP_OK;
    }

    for(point = 0; point < length/4; point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, seq[point]);
    }

    saveAcSeqIc3(seq, length);

    return BSP_OK;
}

//设置AC序列生效
UINT32 SetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 length, UINT32 seqMode)
{
    UINT32 dataLen           = 0;
    T_AcParaInfo acParaInfo  = {0};
    UINT8* baseAddr          = 0;
    UINT32 uiAcType          = 0;

    INPUT_POINTER_CHECK(seq);
    	
    //记录函数执行时间戳

    AcFuncLogS(AC_FUNC_LOG_HIGH, "SeqCfg acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, seqLen:%d \n",
                                acType, radioMode, bandWidth, carr, length);

    recordAcTickInfo(0,0,0);//SetAcSeqIc 对应索引 0

    uiAcType = BspJudgeAcType(acType);
    dbgInfo("[%s] uiAcType:%d, acType:%d \n", __FUNCTION__, uiAcType, acType);

    RecordSetAcSeqIcInfo(carr,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,uiAcType);

    //AC初始清空A53和R8的共享内存中的AC数据
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }
    memset((VOID*)(baseAddr + IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET), 0, IC_AC_SHARE_MEM_DL_CATCH_DATA_SIZE);
    memset((VOID*)(baseAddr + IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET), 0, IC_AC_SHARE_MEM_UL_CATCH_DATA_SIZE);

    dbgInfo("[%s] setSeqData length %d,radioMode %d,bandWidth %d,pasteCarrFlag %d,deviate %d\n",__FUNCTION__,length,radioMode,bandWidth,pasteCarrFlag,deviate);
    dbgInfo("[%s] seqMode %d(0:正常模式,1:残余相差模式)\n",__FUNCTION__,seqMode);
    printAcSeqFromOam(seq,length);
    
    //获取各制式下差异性参数(不包含时延)
    if(BSP_OK != BspGetAcParaInfo(radioMode,pasteCarrFlag,bandWidth,&acParaInfo))
    {
        dbgErr("%s get AcParaInfo error! \n",__FUNCTION__);
    }

    dataLen = acParaInfo.acSeqLen;
    if(BSP_OK != IcHalAcInsrtDataWrRam(uiAcType, seq, dataLen, length, radioMode, carr))
    {
        return BSP_ERROR;
    }

    
    recordAcTickInfo(1,0,0);//SetAcSeqIc 对应索引 0

    return BSP_OK;
}

UINT32 testAcSeq[4096];

UINT32 testSetAcSeq(UINT32 carr, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 length)
{
    UINT32 pasteCarrFlag = 0;
    UINT32 deviate = 0;
    UINT32 seqMode = 0;
    SetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, testAcSeq, length, seqMode);

    return BSP_OK;
}

VOID PrintSendHaulBackAcSeqIc(UINT32 retry,UINT32 roundTime,UINT32 round,T_DpdMsgSendAcData_NEW *sendData)
{
    dbgInfoEx("\n--------%d--------\n",(retry*roundTime+round-1));
    dbgInfoEx("0 uwDataLen =%d\n",sendData->stDa[0].uwDataLen);
    dbgInfoEx("0 ucCeLLId=%d\n",sendData->stDa[0].ucCeLLId);
    dbgInfoEx("0 ucAcType=%d\n",sendData->stDa[0].ucAcType);
    dbgInfoEx("0 ucIterationNo=%d\n",sendData->stDa[0].ucIterationNo);
    dbgInfoEx("0 ucGroupNo=%d\n",sendData->stDa[0].ucGroupNo);
    dbgInfoEx("0 uwAntNo=%d\n",sendData->stDa[0].uwAntNo);
    dbgInfoEx("0 ComplexData[0].real=%d\n",sendData->stDa[0].ComplexData[0].real);
    dbgInfoEx("0 ComplexData[1023].real=%d\n",sendData->stDa[0].ComplexData[1023].real);
    dbgInfoEx("\n--------%d--------\n",(retry*roundTime+round));
    dbgInfoEx("1 uwDataLen =%d\n",sendData->stDa[1].uwDataLen);
    dbgInfoEx("1 ucCeLLId=%d\n",sendData->stDa[1].ucCeLLId);
    dbgInfoEx("1 ucAcType=%d\n",sendData->stDa[1].ucAcType);
    dbgInfoEx("1 ucIterationNo=%d\n",sendData->stDa[1].ucIterationNo);
    dbgInfoEx("1 ucGroupNo=%d\n",sendData->stDa[1].ucGroupNo);
    dbgInfoEx("1 uwAntNo=%d\n",sendData->stDa[1].uwAntNo);
    dbgInfoEx("1 ComplexData[0].real=%d\n",sendData->stDa[1].ComplexData[0].real);
    dbgInfoEx("1 ComplexData[1023].real=%d\n",sendData->stDa[1].ComplexData[1023].real);
}

UINT32 GetRetryPara(UINT32 acType, T_ICHAL_ACPARA* acPara, UINT32 *uiRetryTime, UINT32 *roundTime)
{   
    UINT32 uiAcType = 0;

    if((E_AC_TYPE_FDD_DL == acType) || (E_AC_TYPE_FDD_UL == acType))
    {
        *uiRetryTime = acPara->insertTimes;
    }
    else if((E_AC_TYPE_DL == acType) || (E_AC_TYPE_UL == acType))
    {
        *uiRetryTime = IC_AC_RETRY_TIME;
    }
    else
    {
        // do nothing
    }

    uiAcType = BspJudgeAcType(acType);
    *roundTime = (E_AC_TYPE_DL == uiAcType) ? acPara->acDlRoundNo : acPara->acUlRoundNo;

    dbgInfo("[%s] uiAcType:%d, acType:%d, uiRetryTime=%d, roundTime=%d\n", __FUNCTION__, uiAcType, acType, *uiRetryTime, *roundTime);

    return BSP_OK;
}

UINT32 GetNcoPara(UINT32 acType, INT32 *iAcDspNcoValid, INT32 *iAcDspNcoAdj)
{
    T_ICHAL_ACPARA*        acPara        = NULL; 
    UINT8*                 baseAddr      = NULL;
    A53R8AcDebugShareInfo* shareInfo     = NULL;
    UINT32                 uiSendAcRpuId = 0;
    UINT32                 uiRpuId       = 0;
    INT32                  iAcDspNco     = 0;

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);
    baseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(baseAddr);
    shareInfo = (A53R8AcDebugShareInfo*)(baseAddr + IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET);

    uiSendAcRpuId = shareInfo->sendAcRpuId;//耦合通道所在ic
    uiRpuId       = BspGetRpuId();
    if((uiRpuId == uiSendAcRpuId) && ((E_AC_TYPE_FDD_DL == acType) || (E_AC_TYPE_FDD_UL == acType)))
    {
        *iAcDspNcoValid = 0x8000;
        INPUT_POINTER_CHECK(acPara->pGetAcDspNco);
        iAcDspNco = acPara->pGetAcDspNco();
        *iAcDspNcoAdj = iAcDspNco & 0x7fff;
    }
    dbgInfoEx("[%s]acType=%d, iAcDspNcoValid=%d, iAcDspNcoAdj=%d\n", __FUNCTION__, acType, *iAcDspNcoValid, *iAcDspNcoAdj);

    return BSP_OK;
}

UINT32 GetDmaState(UINT32 acType, A53R8AcDebugShareInfo *ptShareInfo)
{
    UINT32 uiSendAcRpuId   = 0;
    UINT32 uiRpuId         = 0;
    UINT32 uiWaitR8TimeCnt = 0;
    UINT32 uiAcType        = 0;
    UINT32 uiRealFrNo = IcHalGetFrameNo();

    uiSendAcRpuId = ptShareInfo->sendAcRpuId;//耦合通道所在ic
    uiRpuId       = BspGetRpuId();

    uiAcType = BspJudgeAcType(acType);
    dbgInfo("RealFrNo_Prt %s_IN line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);
    //查询发数、采数、DMA搬数是否完成
    if((uiAcType == E_AC_TYPE_DL) && (uiRpuId == uiSendAcRpuId))
    {
        while((!(ptShareInfo->acDlDoneFlag))&&(uiWaitR8TimeCnt < 3))
        {
            BspSysMsDelay(1000);
            uiWaitR8TimeCnt++;
        }
        JudgeWaitR8TimeCnt(uiAcType,uiWaitR8TimeCnt);
        recordWaitR8TimeCnt(uiAcType, uiWaitR8TimeCnt);
        ptShareInfo->acDlDoneFlag = 0;
        AcFuncLogS(AC_FUNC_LOG_HIGH, "DataSend dlDmaSta:ok, waitCnt:%d \n", uiWaitR8TimeCnt);
    }
    else if(uiAcType == E_AC_TYPE_UL)
    {
        while((!(ptShareInfo->acUlDoneFlag))&&(uiWaitR8TimeCnt < 3))
        {
            BspSysMsDelay(1000);
            uiWaitR8TimeCnt++;
        }
        JudgeWaitR8TimeCnt(uiAcType, uiWaitR8TimeCnt);
        recordWaitR8TimeCnt(uiAcType, uiWaitR8TimeCnt);
        ptShareInfo->acUlDoneFlag = 0; 
        AcFuncLogS(AC_FUNC_LOG_HIGH, "DataSend ulDmaSta:ok, waitCnt:%d \n", uiWaitR8TimeCnt);    
    }

    if(checkWaitR8SmpOverTime(uiAcType, uiWaitR8TimeCnt) != BSP_OK)
    {
        uiRealFrNo = IcHalGetFrameNo();
        dbgInfo("RealFrNo_Prt %s _OUT line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);
        dbgErr("[%s] failed! Dma sample for AC overtime!\n",__FUNCTION__);
        AcFuncLogS(AC_FUNC_LOG_HIGH, "DataSend ulDmaSta:ok, waitCnt:%d \n", uiWaitR8TimeCnt);  
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 SetVgaPara(T_AcCarrInfo* ptAcCarrInfo, UINT32 retry, UINT32 round, acDataToDsp* acData)
{
    UINT32       acType         = 0;
    UINT32       radioMode      = 0;
    UINT32       carrNo         = 0;
    UINT32       uiAcType       = 0;
    INT32        iAcDspNcoValid = 0;
    INT32        iAcDspNcoAdj   = 0;
    UINT8*       baseAddr       = NULL;
    UlAcVgaData* VgaData        = NULL;
    UINT32       uiAntNoTmp     = 0;
    UINT32       uiBand         = 0;
    UINT32       uiDifChipId    = 0;
    UINT32       uiDifChn       = 0;
    INT32        iVgaValue      = 0;
    INT32        iVgaValueAdj   = 0;
    INT32        iPreAtt        = 0;
    INT32        iVgaPreAtt     = 0;
    UINT32       retVal         = 0;

    acType    = ptAcCarrInfo->acType;
    carrNo    = ptAcCarrInfo->carrNo;
    radioMode = ptAcCarrInfo->radioMode;

    retVal = GetNcoPara(acType, &iAcDspNcoValid, &iAcDspNcoAdj);
    dbgInfoEx("[%s]acType=%d, iAcDspNcoAdj=%d\n", __FUNCTION__,acType, iAcDspNcoAdj);
    RETURN_RESULT_CHECK(retVal);

    uiAcType = BspJudgeAcType(acType);
    if(E_AC_TYPE_DL == uiAcType)
    {
        acData->iScale = (iAcDspNcoAdj | iAcDspNcoValid); //FDD AC DSP NCO传递
        acData->iCrc = (UINT32)retry << 16;
        dbgInfoEx("[%s] acType=%u acData->iScale=%d\n", __FUNCTION__,acType,  acData->iScale);

    }
    else
    {
        baseAddr = BspGetAcMemBaseAddr();
        INPUT_POINTER_CHECK(baseAddr);
        VgaData    = (UlAcVgaData *)(baseAddr + IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET);
        uiAntNoTmp = BspGetAntNoByRoundInfo(BspGetRpuId(), round);

        INPUT_FALSE_NO_WARNING_AC(uiAntNoTmp);

        uiAntNoTmp = uiAntNoTmp + 1u; //对应map表中的天线号列，需要加1

        retVal = BspGetDifInfoByAntInfo(uiAntNoTmp, uiBand, RX, &uiDifChipId, &uiDifChn);
        RETURN_RESULT_CHECK(retVal);

        retVal = IcHalApiGetRxPcGain(uiDifChn, radioMode, carrNo, &iPreAtt); //iPreAtt获取到的值单位是0.01db
        RETURN_RESULT_CHECK(retVal);

        if(BSP_OK == IcHalApiGetRxVgaGain(uiDifChn, radioMode, carrNo, &iVgaPreAtt)) //iVgaPreAtt获取到的值单位是0.01db
        {
            iVgaValue = VgaData->vga[retry][round]*5 + (iPreAtt/10) + (iVgaPreAtt/10); 
            iVgaValueAdj = (iVgaValue << 16) & 0xffff0000;
            dbgInfoEx("[%s]Agc Retry=%2d, acType=%d, Ant=%2d, CarrNo=%d, radioMode=0x%08X, iVgaValue=%d, iVgaValueAdj=%d, iVgaPreAtt=%d, iPreAtt=%d, acData->iScale=%d, acData->iCrc=%d\n",
                __FUNCTION__, retry, acType, round, carrNo, radioMode, iVgaValue, iVgaValueAdj, iVgaPreAtt, iPreAtt, acData->iScale, acData->iCrc);
        }
        else
        {
            dbgErr("[%s]get vga comp error!\n", __FUNCTION__);
        }

        acData->iScale = (iAcDspNcoAdj | iAcDspNcoValid | iVgaValueAdj); //FDD AC DSP NCO传递
        acData->iCrc = ((UINT32)retry << 16) | (round << 8);
    }

    return BSP_OK;
}

UINT32 g_TxAttValue = 0;
UINT32 g_ChangeAttvalueFlag = 0;


VOID BspSetTxAttValue(UINT32 attValue, UINT32 flag)
{
    g_ChangeAttvalueFlag = flag;
    g_TxAttValue = attValue;
}

UINT32 BspGetTxAttValue(VOID)
{
    return g_TxAttValue;
}

//设置上行ac 固定tx att值
UINT32 BspFixTxAttValue(UINT32 acType, T_ICHAL_ACPARA* acPara, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 uimask     = 0;
    UINT32 uiAttValue = 0;
    UINT32 uichan     = 0;
    UINT32 uiChannum  = 0;
    UINT32 uiBspChn   = 0;
    UINT32 uiRfChn    = 0;
    UINT32 uiRet      = 0;

    uichan     = shareInfo->acSendDataChan + 1;
    uiAttValue = acPara->acTxAttValue;

    dbgInfoEx("[%s] acType=%d, acFixTxAttFlag=%d, acTxAttValue=%d, chan=%d\n", 
    __FUNCTION__, acType, acPara->acFixTxAttFlag, uiAttValue, uichan);

    if ((acPara->acFixTxAttFlag != FIX_ATT_ENABLE) ||(E_AC_TYPE_DL ==  acType ))
    {
        return BSP_OK;
    }
    // 加桩修改att值
    if(CHANGE_ATT_DISABLE == g_ChangeAttvalueFlag)
    {
        uiAttValue = g_TxAttValue;
    }

    if(AC_TYPE_STOP == acType)
    {
        uimask = 1;
        uiAttValue = 0;
    }

    uiRet = BspGetBspChnByAntId(uichan, TX, &uiChannum, &uiBspChn);
    RETURN_RESULT_CHECK(uiRet);

    uiRet = BspGetRfChnByBspChn(uiBspChn, TX, &uiRfChn);
    RETURN_RESULT_CHECK(uiRet);

    dbgInfoEx("[%s] uiBspChn=%d, uiRfChn=%d\n", __FUNCTION__, uiBspChn, uiRfChn);

    INPUT_POINTER_CHECK(acPara->pBspSetTxAttValue);
    acPara->pBspSetTxAttValue(uiRfChn, uiAttValue,uimask);
    return BSP_OK;
}

UINT32 g_RxAttValue = 0;
UINT32 g_ChangeRxAttvalueFlag = 0;

VOID BspSetRxAttValue(UINT32 attValue, UINT32 flag)
{
    g_ChangeRxAttvalueFlag = flag;
    g_RxAttValue = attValue;
}

UINT32 BspGetRxAttValue(VOID)
{
    return g_RxAttValue;
}

//设置下行ac 固定Rx att值
UINT32 BspFixRxAttValue(UINT32 acType, T_ICHAL_ACPARA* acPara, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 uimask     = 0;
    UINT32 uiAttValue = 0;
    UINT32 uichan     = 0;
    UINT32 uiChannum  = 0;
    UINT32 uiBspChn   = 0;
    UINT32 uiRfChn    = 0;
    UINT32 uiRet      = 0;

    uichan     = shareInfo->acCatchDataChan + 1;
    uiAttValue = acPara->acRxAttValue;

    dbgInfoEx("[%s] acType=%d, acFixTxAttFlag=%d, acTxAttValue=%d, chan=%d\n", 
    __FUNCTION__, acType, acPara->acFixRxAttFlag, uiAttValue, uichan);

    if ((acPara->acFixRxAttFlag != FIX_ATT_ENABLE) ||(E_AC_TYPE_UL ==  acType ))
    {
        return BSP_OK;
    }
    // 加桩修改att值
    if(CHANGE_ATT_DISABLE == g_ChangeRxAttvalueFlag)
    {
        uiAttValue = g_RxAttValue;
    }

    if(AC_TYPE_STOP == acType)
    {
        uimask = 1;
        uiAttValue = 0;
    }

    uiRet = BspGetBspChnByAntId(uichan, RX, &uiChannum, &uiBspChn);
    RETURN_RESULT_CHECK(uiRet);

    uiRet = BspGetRfChnByBspChn(uiBspChn, RX, &uiRfChn);
    RETURN_RESULT_CHECK(uiRet);

    dbgInfoEx("[%s] uiBspChn=%d, uiRfChn=%d\n", __FUNCTION__, uiBspChn, uiRfChn);
    
    INPUT_POINTER_CHECK(acPara->pBspSetRxAttValue);
    acPara->pBspSetRxAttValue(uiRfChn, uiAttValue,uimask);
    return BSP_OK;
}

UINT32 SendDlAcDataToDsp(T_ICHAL_ACPARA* ptAcPara, T_AcCarrInfo* ptAcCarrInfo, T_AcParaInfo* ptAcParaInfo)
{
    UINT32       acType         = 0;
    UINT32       carrNo         = 0; 
    UINT32       radioMode      = 0;
    UINT8*       pBaseAddr      = NULL;
    UINT8*       pBaseAddrAc    = NULL;
    acDataToDsp* ptAcData       = NULL;
    UINT8*       pSrcMemAddr    = NULL;
    UINT8*       pSrcMemAddrTmp = NULL;
    UINT32       retry          = 0; //IC_AC_RETRY_TIME;
    UINT32       uiRetryTime    = 0;
    UINT32       round          = 0; //IC_AC_ROUND_TIME;
    UINT32       roundTime      = 0;
    UINT32       roundMaxNum    = 1;
    UINT32       retVal         = 0;

    acType    = ptAcCarrInfo->acType;
    carrNo    = ptAcCarrInfo->carrNo;
    radioMode = ptAcCarrInfo->radioMode;

    pBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pBaseAddr);

    pBaseAddrAc = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(pBaseAddrAc);

    ptAcData    = (acDataToDsp *)(pBaseAddrAc + NXP_AC_MEM_DSP_TRAN_AC_SEQ_ADDR);
    pSrcMemAddr = (pBaseAddr + IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET);
    dbgInfoEx("[%s]acType=%d, carrNo=%d, radioMode=%d, pBaseAddr=%p, pBaseAddrAc=%p, ptAcData=%p, pSrcMemAddr=%p\n",
              __FUNCTION__, acType, carrNo, radioMode, (void*)pBaseAddr, (void*)pBaseAddrAc, (void*)ptAcData, (void*)pSrcMemAddr);

    retVal = GetRetryPara(acType, ptAcPara, &uiRetryTime, &roundTime);
    RETURN_RESULT_CHECK(retVal);
    
    for(retry = 0; retry < uiRetryTime; retry++)
    {
        for(round = 0;round < roundTime;round++)
        {
            retVal = SetVgaPara(ptAcCarrInfo, retry, round, ptAcData);
            INPUT_FALSE_CONTINUE_AC(((BSP_OK == retVal) || (AC_NETMODE_DUP == BspGetAcNetMode())));

            if(E_AC_TYPE_DL == acType)
            {
                memcpy_s((void *)(ptAcData->ComplexData), AC_DATA_TO_DSP_LEN * sizeof(UINT32), (void *)pSrcMemAddr, AC_DATA_TO_DSP_LEN * sizeof(UINT32));
                ptAcData++;
                pSrcMemAddr += (AC_DATA_TO_DSP_LEN * sizeof(UINT32) * roundMaxNum);
            }
            else
            {
                pSrcMemAddrTmp = pSrcMemAddr + (retry * roundTime * ptAcParaInfo->acSeqLen * sizeof(UINT32) + round * ptAcParaInfo->acSeqLen * sizeof(UINT32));
                memcpy_s((void *)(ptAcData->ComplexData), ptAcParaInfo->acSeqLen * sizeof(UINT32), (void *)pSrcMemAddrTmp, ptAcParaInfo->acSeqLen * sizeof(UINT32));
                dbgInfoEx("[%s] pSrcMemAddrTmp[0]=0x%08X, ptAcData->ComplexData[0]=0x%08X\n", __FUNCTION__,
                    ((UINT32 *)pSrcMemAddrTmp)[0], ptAcData->ComplexData[0]); 
                ptAcData++;
            }
            dbgInfoEx("[%s]retry=%d, roundDl=%d, antDlMax=%d, pSrcMemAddr=%p, pSrcMemAddrTmp=%p\n", __FUNCTION__, retry, round, roundTime, (void*)pSrcMemAddr, (void*)pSrcMemAddrTmp);
        }
    }

    return BSP_OK;
}

UINT32 SendUlAcDataToDsp(T_ICHAL_ACPARA* ptAcPara, T_AcCarrInfo* ptAcCarrInfo, T_AcParaInfo* ptAcParaInfo)
{
    UINT32       acType         = 0;
    UINT32       carrNo         = 0; 
    UINT32       radioMode      = 0;
    UINT8*       pBaseAddr      = NULL;
    UINT8*       pBaseAddrAc    = NULL;
    acDataToDsp* ptAcData       = NULL;
    UINT8*       pSrcMemAddr    = NULL;
    UINT8*       pSrcMemAddrTmp = NULL;
    UINT32       retry          = 0; //IC_AC_RETRY_TIME;
    UINT32       uiRetryTime    = 0;
    UINT32       round          = 0; //IC_AC_ROUND_TIME;
    UINT32       roundTime      = 0;
    UINT32       retVal         = 0;

    acType    = ptAcCarrInfo->acType;
    carrNo    = ptAcCarrInfo->carrNo;
    radioMode = ptAcCarrInfo->radioMode;

    pBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pBaseAddr);

    pBaseAddrAc = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(pBaseAddrAc);

    ptAcData   = (acDataToDsp *)(pBaseAddrAc + NXP_AC_MEM_DSP_RECV_AC_SEQ_ADDR);
    pSrcMemAddr = (pBaseAddr + IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET);

    dbgInfoEx("[%s]acType=%d, carrNo=%d, radioMode=%d, pBaseAddr=%p, pBaseAddrAc=%p, ptAcData=%p, pSrcMemAddr=%p\n",
              __FUNCTION__, acType, carrNo, radioMode, (void*)pBaseAddr, (void*)pBaseAddrAc, (void*)ptAcData, (void*)pSrcMemAddr);

    retVal = GetRetryPara(acType, ptAcPara, &uiRetryTime, &roundTime);
    RETURN_RESULT_CHECK(retVal);

    for(retry = 0; retry < uiRetryTime; retry++)
    {
        for(round = 0;round < roundTime;round++)
        {
            retVal = SetVgaPara(ptAcCarrInfo, retry, round, ptAcData);
            INPUT_FALSE_CONTINUE_AC(((BSP_OK == retVal) || (AC_NETMODE_DUP == BspGetAcNetMode())));
        
            if(E_AC_TYPE_UL == acType)
            {
                memcpy_s((void *)(ptAcData->ComplexData), AC_DATA_TO_DSP_LEN * sizeof(UINT32), (void *)pSrcMemAddr, AC_DATA_TO_DSP_LEN * sizeof(UINT32));
                ptAcData++;
                pSrcMemAddr += (AC_DATA_TO_DSP_LEN * sizeof(UINT32));
            }
            else
            {
                pSrcMemAddrTmp = pSrcMemAddr + (round * roundTime * AC_DATA_TO_DSP_LEN * sizeof(UINT32) + retry * ptAcParaInfo->acSeqLen * sizeof(UINT32)); 
                memcpy_s((void *)(ptAcData->ComplexData), ptAcParaInfo->acSeqLen * sizeof(UINT32), (void *)pSrcMemAddrTmp, ptAcParaInfo->acSeqLen * sizeof(UINT32));
                ptAcData++;
            }
            dbgInfoEx("[%s]retry=%d, antUl=%d, antUlMax=%d, pSrcMemAddr=%p, pSrcMemAddrTmp=%p\n", __FUNCTION__, retry, round, roundTime, (void*)pSrcMemAddr, (void*)pSrcMemAddrTmp);
        }
    }

    return BSP_OK;
}

UINT32 SendAcDataToDsp(T_ICHAL_ACPARA* ptAcPara,  T_AcCarrInfo* ptAcCarrInfo, T_AcParaInfo* ptAcParaInfo)
{
    UINT32 uiAcType = 0;

    uiAcType = BspJudgeAcType(ptAcCarrInfo->acType);
    if (E_AC_TYPE_DL == uiAcType)
    {
        //下行AC 采数拷贝至 AC DSP共享内存
        SendDlAcDataToDsp(ptAcPara, ptAcCarrInfo, ptAcParaInfo);
    }
    else if (E_AC_TYPE_UL == uiAcType)
    {
        //上行AC 采数拷贝至 AC DSP共享内存
        SendUlAcDataToDsp(ptAcPara, ptAcCarrInfo, ptAcParaInfo);
    }
    else
    {
        // do nothing		
    }

    return BSP_OK;
}

UINT32 GetAcCarrInfo(UINT32 acType, UINT32 radioMode, UINT32 carrNo, UINT32 bandWidth, T_AcCarrInfo* ptAcCarrInfo)
{
    ptAcCarrInfo->acType    = acType;
    ptAcCarrInfo->radioMode = radioMode;
    ptAcCarrInfo->carrNo    = carrNo;
    ptAcCarrInfo->bandWidth = bandWidth;

    dbgInfoEx("\n%s acType=%d radioMode=%d carrNo=%d bandWidth=%d\n",__FUNCTION__,\
              ptAcCarrInfo->acType, ptAcCarrInfo->radioMode, ptAcCarrInfo->carrNo, ptAcCarrInfo->bandWidth);

    return BSP_OK;
}

//IC上采的AC序列回传到NXP上去
/****************************************************
【下行AC】重复16遍，每遍发9次，每次选择8T发送
    retry0  round0 [Point0][Point1]......[Point1023]
    retry0  round1 [Point0][Point1]......[Point1023]
          .............................
          .............................
    retry0  round8 [Point0][Point1]......[Point1023]

    retry1  round0 [Point0][Point1]......[Point1023]
    retry1  round1 [Point0][Point1]......[Point1023]
        .............................
        .............................
    retry1  round8 [Point0][Point1]......[Point1023]

        .............................
        .............................
        .............................
        .............................

    retry15 round0 [Point0][Point1]......[Point1023]
    retry15 round1 [Point0][Point1]......[Point1023]
        .............................
        .............................
    retry15 round8 [Point0][Point1]......[Point1023]

【上行AC】:重复16遍，每遍发1次，每次64T发送
    retry0  round0 [Point0][Point1]......[Point1023]
    retry1  round0 [Point0][Point1]......[Point1023]
          .............................
          .............................
    retry15 round0 [Point0][Point1]......[Point1023]

****************************************************/
UINT32 SendHaulBackAcSeqIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    UINT8*                 pBaseAddr       = NULL;
    A53R8AcDebugShareInfo* ptShareInfo     = NULL;
    T_ICHAL_ACPARA*        ptAcPara        = NULL;
    T_AcCarrInfo           tAcCarrInfo     = {0};
    T_AcParaInfo           tAcParaInfo     = {0};
    UINT32                 uiAcType        = 0;
    UINT32                 retVal          = 0;
    T_AcDataPara           tAcDataPara     = {0};

    //记录函数执行时间戳
    recordAcTickInfo(0,3,0);//SendHaulBackAcSeqIc 对应索引 3
    recordErsUpdateTime(acType,2);
    recordSendHaulBackAcCnt();
    
    dbgInfoEx("acType:%d, carrNo:%d, pasteCarrFlag:%d, deviate:%d, bandWidth:%d, sampleRate:%d, radioMode:%d\n",\
                acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);

    ptAcPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    AcFuncLogS(AC_FUNC_LOG_HIGH, "DataSend localFr:%d, socId:%d, acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, \n",
                                 IcHalGetFrameNo(), 0, acType, radioMode, bandWidth, carrNo);
    INPUT_POINTER_CHECK(ptAcPara);
    
    if(AC_MULTI_CHIP == ptAcPara->acMultiChip)
    {
        tAcDataPara.uiAcType        = acType;
        tAcDataPara.uiBandWidth     = bandWidth;
        tAcDataPara.uiCarrNo        = carrNo;
        tAcDataPara.uiPasteCarrFlag = pasteCarrFlag;
        tAcDataPara.uiRadioMode     = radioMode;
        retVal = SendDspAcDataMultiIc(&tAcDataPara);
        RETURN_RESULT_CHECK(retVal);

        return retVal;
    }
    pBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pBaseAddr);
    ptShareInfo = (A53R8AcDebugShareInfo*)(pBaseAddr + IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET);

    retVal = GetDmaState(acType, ptShareInfo);
    RETURN_RESULT_CHECK(retVal);

    retVal = BspGetAcParaInfo(radioMode, pasteCarrFlag, bandWidth, &tAcParaInfo);
    RETURN_RESULT_CHECK(retVal);

    retVal = GetAcCarrInfo(acType, radioMode, carrNo, bandWidth, &tAcCarrInfo);
    RETURN_RESULT_CHECK(retVal);

    retVal = SendAcDataToDsp(ptAcPara, &tAcCarrInfo, &tAcParaInfo);
    RETURN_RESULT_CHECK(retVal);
	
    uiAcType = BspJudgeAcType(acType);
    getAcInfo(uiAcType, carrNo, radioMode);
    
    recordAcTickInfo(1,3,0);//SendHaulBackAcSeqIc 对应索引 3

    return retVal;
}

//启动AC权值计算
UINT32 CalAcWgtIc(UINT32 acType, UINT32 carr,  UINT32 radioMode, UINT32 refChan)
{
    UINT32 retVal = BSP_OK;
    recordCalAcWgtIcCnt();
    dbgInfoEx("[%s](in): acType:%d,carr:%d,radioMode:%d,refChan:%d\n",__FUNCTION__,acType,carr,radioMode,refChan);
    retVal = BspAcWgtCalcIc(acType,carr, radioMode,refChan);
    AcFuncLogM(AC_FUNC_LOG_HIGH, "WgtCal localFr:%d, acType:%d, radioMode:%d, carrNo:%d \n", IcHalGetFrameNo(), acType, radioMode, carr);
    

    return retVal;
}

//检查是否完成权值计算
UINT32 ChkAcWgtIc(UINT32 acType, UINT32 carr, UINT32 radioMode)
{
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;
    recordChkAcWgtIcCnt();
    dbgInfoEx("[%s](in): acType:%d,carr:%d,radioMode:%d\n",__FUNCTION__,acType,carr,radioMode);
    retVal = BspGetAcWgtCalcSta(chan, acType);
    

    return retVal;
}

/**********************************************JAC新增接口-BEGIN*****************************************************/
//启动参考通道H计算
UINT32 CalJacRefHCalcIc(UINT32 acType, UINT32 carr)
{
    UINT32 retVal = BSP_OK;

    dbgInfoEx("[%s](in): acType:%d,carr:%d \n", __FUNCTION__, acType, carr);
    AcFuncLogM(AC_FUNC_LOG_HIGH, "CalJacRefH frNo:%d, acType:%d, carr:%d\n", IcHalGetFrameNo(), acType, carr);
    retVal = BspJacRefChHCalc(acType, carr);    

    return retVal;
}

//获取参考通道H计算结果
UINT32 GetJacRefHRstIc(UINT32 *puiRefHRst)
{
    T_Pulm2CmacAntAdjustRspIc3* ptAcRspInfo = NULL;
    UINT8 *baseAddr = NULL;

    if(NULL == (baseAddr = BspGetAcDspMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    //coverity[cert_exp36_c_violation:SUPPRESS]
    ptAcRspInfo = (T_Pulm2CmacAntAdjustRspIc3*) ((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr));

    if(0 == ptAcRspInfo->acMsgHeaderRsk.ucRefHResult)
    {
        *puiRefHRst = JAC_REF_FAILED;
    }
    else
    {
        *puiRefHRst = JAC_REF_SUC;
    }
    dbgInfo("[%s], JacRefH cal result:%d \n", __FUNCTION__, *puiRefHRst);
    AcFuncLogM(AC_FUNC_LOG_HIGH, "GetJacRefHRst frNo:%d, result:%d\n", IcHalGetFrameNo(), *puiRefHRst);
    return BSP_OK;
}

UINT32 GetJacRefHIc(UINT32 *puiRefHData, UINT32 *puiDataLength, UINT8 *pciScale, UINT32 *puiScaleLenth)
{
    UINT8 *pcRefHAddr    = NULL;
    UINT8 *pcBaseAddr    = NULL;
    UINT8 *pcScaleAddr   = NULL;
    UINT32 uiRefHDataLen = 0;
    UINT32 uiScaleLen    = 0;

    
    INPUT_POINTER_CHECK(puiRefHData);
    INPUT_POINTER_CHECK(puiDataLength);

    pcBaseAddr = BspGetAcDspMemBaseAddr(); //虚拟基址
    INPUT_POINTER_CHECK(pcBaseAddr);

    uiRefHDataLen = 4 * AC_DATA_LEN * sizeof(UINT32); //JAC下，TDD、FDD均为4次迭代，每次迭代存储空间按照1024点
    pcRefHAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR;

    *puiDataLength = uiRefHDataLen;
    memcpy_s((UINT8 *)((VOID *)puiRefHData), uiRefHDataLen, pcRefHAddr, uiRefHDataLen);

    uiScaleLen = JAC_REF_H_SCALE * sizeof(INT8); //JAC下，TDD、FDD均为4次迭代，对应4次迭代的定标因子
    pcScaleAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR;

    *puiScaleLenth = uiScaleLen;
    memcpy_s(pciScale, uiScaleLen, pcScaleAddr, uiScaleLen);

    AcFuncLogM(AC_FUNC_LOG_HIGH, "GetJacRefH frNo:%d, uiRefHDataLen:%d, uiScaleLen:%d\n", IcHalGetFrameNo(), uiRefHDataLen, uiScaleLen);
    dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR: 0x%x, uiRefHDataLen:%d, uiScaleLen:%d \n", __FUNCTION__, NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR, uiRefHDataLen, uiScaleLen);
    dbgInfo("[%s]:pcBaseAddr: %p, pcRefHAddr:%p, pcScaleAddr:%p \n", __FUNCTION__, (void*)pcBaseAddr, (void*)pcRefHAddr, (void*)pcScaleAddr);
    

    return BSP_OK;
}

UINT32 SetJacRefHIc(UINT32 *puiRefHData, UINT32 uiDataLength, UINT8 *pciScale, UINT32 uiScaleLenth)
{
    UINT8 *pcRefHAddr    = NULL;
    UINT8 *pcBaseAddr    = NULL;
    UINT8 *pcScaleAddr   = NULL;
    UINT32 uiRefHDataLen = 0;
    UINT32 uiScaleLen    = 0;

    
    INPUT_POINTER_CHECK(puiRefHData);

    pcBaseAddr = BspGetAcDspMemBaseAddr(); //虚拟基址
    INPUT_POINTER_CHECK(pcBaseAddr);

    pcRefHAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR;
    uiRefHDataLen = uiDataLength;
    memcpy_s(pcRefHAddr, uiRefHDataLen, (UINT8 *)((VOID *)puiRefHData), uiRefHDataLen);

    pcScaleAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR;
    uiScaleLen = uiScaleLenth;
    memcpy_s(pcScaleAddr, uiScaleLen, pciScale, uiScaleLen);

    dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR);
    dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR);
    dbgInfo("[%s]:pcBaseAddr: %p, pcRefHAddr:%p, uiRefHDataLen:%d, pcScaleAddr:%p, uiScaleLen:%d\n",
            __FUNCTION__, (void*)pcBaseAddr, (void*)pcRefHAddr, uiRefHDataLen, (void*)pcScaleAddr, uiScaleLen);
    
    AcFuncLogM(AC_FUNC_LOG_HIGH, "SetJacRefH frNo:%d, uiRefHDataLen:%d, uiScaleLen:%d\n", IcHalGetFrameNo(), uiRefHDataLen, uiScaleLen);
    return BSP_OK;
}

UINT32 SetJacMode(UINT32 uiJacMode, UINT32 uiJacHandleType, UINT8 uiBitMap)
{
    g_uiJacMode = uiJacMode;
    g_uiJacHandleType = uiJacHandleType;
    g_uiJacBitMap = uiBitMap;
    dbgInfo("[%s], g_uiJacMode:%d, g_uiJacHandleType:%d, g_uiJacBitMap:0x%x \n", __FUNCTION__, g_uiJacMode, g_uiJacHandleType, g_uiJacBitMap);
    AcFuncLogS(AC_FUNC_LOG_HIGH, "SetJacMode frNo:%d, uiJacMode:%d, uiJacHandleType:%d, uiBitMap:0x%x \n", IcHalGetFrameNo(), uiJacMode, uiJacHandleType, uiBitMap);
    return BSP_OK;
}

UINT32 GetJacMode(VOID)
{
    dbgInfoEx("[%s], g_uiJacMode:%d \n", __FUNCTION__, g_uiJacMode);

    return g_uiJacMode;
}

UINT32 GetJacType(VOID)
{
    dbgInfoEx("[%s], g_uiJacHandleType:%d \n", __FUNCTION__, g_uiJacHandleType);

    return g_uiJacHandleType;
}

UINT8 GetJacBitMap(VOID)
{
    dbgInfoEx("[%s], g_uiJacBitMap:0x%x \n", __FUNCTION__, g_uiJacBitMap);

    return g_uiJacBitMap;
}

UINT32 BspCheckJacBitMap(UINT32 uiAntNum)
{
    UINT8  uiBitMap = 0;
    UINT32 uiAntValid = 0;

    if(JAC_DISABLE == GetJacMode())
    {
        return BSP_OK;
    }

    uiBitMap = GetJacBitMap();
    uiAntValid = BIT_VAL(uiBitMap, uiAntNum);
    dbgInfoEx("[%s], ant:%d, uiAntValid:%d, uiBitMap:0x%x \n", __FUNCTION__, uiAntNum, uiAntValid, uiBitMap);
    if(0 == uiAntValid)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 GetJacOrgData(UINT32 uiJacType, UINT32 *puiOrgJacData, UINT32 *puiJacDataLen)
{
    UINT8 *pcBaseAddr     = NULL;
    UINT8 *ptJAcData      = NULL;
    UINT8 *ptTarAddr      = NULL;
    UINT8 *ptSrcAddr      = NULL;
    UINT32 uiDataLength   = 0;
    UINT32 uiDataLoop     = 0;

    
    INPUT_POINTER_CHECK(puiOrgJacData);
    INPUT_POINTER_CHECK(puiJacDataLen);

    pcBaseAddr = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);

    if((E_AC_TYPE_FDD_DL == uiJacType) || (E_AC_TYPE_DL == uiJacType))
    {
        ptJAcData = pcBaseAddr + NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR;
        uiDataLength = JAC_DATA_ORG_DATA_LEN * sizeof(UINT32);
        dbgInfo("[%s]:NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR);
    }
    else
    {
        dbgErr("[%s] unsupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    //高层获取的数据为4次迭代*1024点，DSP数据摆放为4次迭代*1026点
    for(uiDataLoop = 0;uiDataLoop < JAC_ITERATIONS;uiDataLoop++)
    {
        ptTarAddr = (UINT8 *)((void *)puiOrgJacData) + (uiDataLoop * JAC_DATA_ORG_DATA_LEN * sizeof(UINT32));
        ptSrcAddr = (UINT8 *)ptJAcData + (uiDataLoop * JAC_DATA_ORG_DATA_OFFSET * sizeof(UINT32));
        memcpy_s(ptTarAddr, uiDataLength, ptSrcAddr, uiDataLength);
        *puiJacDataLen += uiDataLength;
        dbgInfoEx("[%s]ptTarAddrData[0]:%x\n",__FUNCTION__,((UINT32 *)ptTarAddr)[0]);

    }
    dbgInfo("[%s]:pcBaseAddr: %p, ptJAcData:%p, uiDataLength:%d, puiJacDataLen:%d\n", __FUNCTION__, (void*)pcBaseAddr, (void*)ptJAcData, uiDataLength, *puiJacDataLen);
    AcFuncLogM(AC_FUNC_LOG_HIGH, "GetJacOrgData frNo:%d, uiJacDataLen:%d \n", IcHalGetFrameNo(), *puiJacDataLen);   
    

    return BSP_OK;
}

UINT32 SetJacOrgData(UINT32 uiJacType, UINT32 *puiOrgJacData, UINT32 uiJacDataLen)
{
    UINT8 *pcBaseAddr = NULL;
    UINT8 *ptJAcData  = NULL;
    UINT8 *ptTarAddr  = NULL;
    UINT8 *ptSrcAddr  = NULL;
    UINT32 uiDataLen  = 0;
    UINT32 uiDataLoop = 0;

    
    INPUT_POINTER_CHECK(puiOrgJacData);

    pcBaseAddr = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);

    if((E_AC_TYPE_FDD_DL == uiJacType) || (E_AC_TYPE_DL == uiJacType))
    {
        ptJAcData = pcBaseAddr + NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR;
        dbgInfo("[%s]:NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR);
    }
    else
    {
        dbgErr("[%s] unsupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    //高层下发的数据为4次迭代，每次1024点，DSP数据摆放为4次迭代，每次1026点
    for(uiDataLoop = 0;uiDataLoop < JAC_ITERATIONS;uiDataLoop++)
    {
        ptTarAddr = (UINT8 *)ptJAcData + (uiDataLoop * JAC_DATA_ORG_DATA_OFFSET * sizeof(UINT32));
        ptSrcAddr = (UINT8 *)((void *)puiOrgJacData) + (uiDataLoop * JAC_DATA_ORG_DATA_LEN * sizeof(UINT32));
        uiDataLen = uiJacDataLen / JAC_ITERATIONS;
        memcpy_s((void *)ptTarAddr, uiDataLen, (void *)ptSrcAddr, uiDataLen);
    }
    dbgInfo("[%s]:pcBaseAddr: %p, ptJAcData:%p, uiJacDataLen:%d \n", __FUNCTION__, (void*)pcBaseAddr, (void*)ptJAcData, uiJacDataLen);
    
    AcFuncLogM(AC_FUNC_LOG_HIGH, "SetJacOrgData frNo:%d, uiJacDataLen:%d \n", IcHalGetFrameNo(), uiJacDataLen);
    return BSP_OK;
}

UINT32 SetJacSuperFr(UINT32 uiSuperFr)
{
    g_uiSuperFr = uiSuperFr;
    dbgInfo("[%s], uiSuperFr:%d \n", __FUNCTION__, uiSuperFr);

    return BSP_OK;
}

UINT32 GetJacSuperFr(VOID)
{
    dbgInfoEx("[%s], uiSuperFr:%d \n", __FUNCTION__, g_uiSuperFr);

    return g_uiSuperFr;
}

UINT32 BspRecordJacSuperFr(A53R8AcDebugShareInfo* shareInfo)
{
    INPUT_POINTER_CHECK(shareInfo);
    if(JAC_SUPER_FR_ERR == shareInfo->acJacSuperFrErr)
    {
        g_uiJacSuperFrDebugCnt = (g_uiJacSuperFrDebugCnt >= JAC_FR_DEBUG_CNT_MAX)? 0 : g_uiJacSuperFrDebugCnt;
        g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiCfgFr = shareInfo->acJacCfgSuperFr;
        g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiRealFr = shareInfo->acJacRealSuperFr;
        g_tJacFrInfo[g_uiJacSuperFrDebugCnt].timeRet  = time(NULL);
        dbgInfo("[%s], g_uiJacSuperFrDebugCnt:%d uiCfgFr:%d, uiRealFr:%d \n", __FUNCTION__, g_uiJacSuperFrDebugCnt,
                g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiCfgFr, g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiRealFr);
        g_uiJacSuperFrDebugCnt++;
    }

    return BSP_OK;
}

UINT32 JacConvertTime(char *paucStrTime, UINT32 uiLen, LONG lTime)
{
    INT32 uiRet   = 0;
    LONG lJacTime = lTime;
    struct tm *ptTransTime = NULL;

    ptTransTime = gmtime((LONG *)&lJacTime);
    if ((struct tm *)NULL != ptTransTime)
    {
        uiRet = snprintf_s(paucStrTime, uiLen, "%04d-%02d-%02d %02d:%02d:%02d\0",
                           ptTransTime->tm_year + 1900, ptTransTime->tm_mon + 1,
                           ptTransTime->tm_mday, ptTransTime->tm_hour,
                           ptTransTime->tm_min,  ptTransTime->tm_sec);
        SNPRINTF_S_CHECK(uiRet, uiLen);
    }

    return BSP_OK;
}


VOID ShowJacSuperFrDebug(VOID)
{
    UINT32 uiFrDebugCnt = 0;
    char   aucStrTime[20] = {0};

    for(uiFrDebugCnt = 0;uiFrDebugCnt < JAC_FR_DEBUG_CNT_MAX; uiFrDebugCnt++)
    {
        JacConvertTime(aucStrTime, sizeof(aucStrTime), g_tJacFrInfo[uiFrDebugCnt].timeRet);
        dbgInfo("[%s], DL:g_tJacFrInfo[%d]: uiCfgFr:%d, uiRealFr:%d \n", aucStrTime, uiFrDebugCnt,
                g_tJacFrInfo[uiFrDebugCnt].uiCfgFr,
                g_tJacFrInfo[uiFrDebugCnt].uiRealFr);
    }
}
/**********************************************JAC维测接口-BEGIN*****************************************************/
UINT32 g_uiRefHData[4096] = {0};
UINT32 g_uiRefHLen = 0;
UINT8  g_ciScaleData[4] = {0};
UINT32 g_uiScaleLen = 0;
UINT32 TestGetJacRefHIc(VOID)
{
    UINT32 point = 0;

    GetJacRefHIc(g_uiRefHData, &g_uiRefHLen, g_ciScaleData, &g_uiScaleLen);

    for(point = 0; point < g_uiRefHLen/4; point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, g_uiRefHData[point]);
    }

    for(point = 0;point < g_uiScaleLen;point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, g_ciScaleData[point]);
    }

    return BSP_OK;
}

UINT32 TestSetJacRefHIc(VOID)
{
    SetJacRefHIc(g_uiRefHData, g_uiRefHLen, g_ciScaleData, g_uiScaleLen);

    return BSP_OK;
}

UINT32 g_uiOrgJacData[4096] = {0};
UINT32 g_uiJacDataLen = 0;
UINT32 TestGetJacOrgData(UINT32 uiJacType)
{
    UINT32 point = 0;

    g_uiJacDataLen = 0;
    GetJacOrgData(uiJacType, g_uiOrgJacData, &g_uiJacDataLen);
    for(point = 0; point < g_uiJacDataLen/4; point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, g_uiOrgJacData[point]);
    }

    return BSP_OK;
}

UINT32 TestSetJacOrgData(UINT32 uiJacType)
{
    SetJacOrgData(uiJacType, g_uiOrgJacData, g_uiJacDataLen);

    return BSP_OK;
}
/**********************************************JAC维测接口-END*****************************************************/
/**********************************************JAC新增接口-END*****************************************************/

/**********************************************RCUA新增接口-START*****************************************************/
UINT32 g_uiCalRoute = 0;
UINT32 SetCalRoute(UINT32 uiCalRoute)
{
    g_uiCalRoute = uiCalRoute;
    AcFuncLogS(AC_FUNC_LOG_HIGH, "SetCalRoute frNo:%d, g_uiCalRoute:%d \n", IcHalGetFrameNo(), g_uiCalRoute);
    return BSP_OK;
}
UINT32 GetCalRoute()
{
    AcFuncLogS(AC_FUNC_LOG_HIGH, "GetCalRoute frNo:%d, g_uiCalRoute:%d \n", IcHalGetFrameNo(), g_uiCalRoute);
    return g_uiCalRoute + 1;
}

//Jac更新上行AC序列的标志，1为更新，0为不更新
UINT32 g_JacConjFreqSeqUpdateFlag = 1;
VOID setJacConjFreqSeqUpdateFlag(UINT32 inPut)
{
    g_JacConjFreqSeqUpdateFlag = inPut;
}
UINT32 getJacConjFreqSeqUpdateFlag()
{
    return g_JacConjFreqSeqUpdateFlag;
}

UINT32 GetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiSeqLen)
{
    UINT8 *pcBaseAddr = NULL;
    UINT8 *ptJacConjFreqBaseSeqShareDdr  = NULL;
    UINT32 jLoop = 0;
    UINT32 uiJacSeqLen = 0;

    
    INPUT_POINTER_CHECK(puiAcSeq);

    pcBaseAddr = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);
    uiJacSeqLen = (uiSeqLen > IC_AC_POINT_NUM)?IC_AC_POINT_NUM:uiSeqLen;

    if(E_AC_TYPE_FDD_UL == uiJacType)
    {
        ptJacConjFreqBaseSeqShareDdr = pcBaseAddr + NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR;
        dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR);
    }
    else
    {
        dbgErr("[%s] unsupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    memcpy_s((void *)puiAcSeq, uiJacSeqLen * sizeof(UINT32), (void *)ptJacConjFreqBaseSeqShareDdr, uiJacSeqLen * sizeof(UINT32));
    for (jLoop = 0; jLoop < uiJacSeqLen/4; jLoop++)
    {
        dbgInfoEx("[%d] puiAcSeq = 0x%08x \n", jLoop, puiAcSeq[jLoop]);
    }
    AcFuncLogM(AC_FUNC_LOG_HIGH, "GetJacConjFreqBaseSeq frNo:%d, uiJacType:%d, uiSeqLen:%d \n", IcHalGetFrameNo(), uiJacType, uiJacSeqLen);
    dbgInfo("[%s]:ptJacConjFreqBaseSeqShareDdr: %p, puiAcSeq:%p, uiSeqLen:%d, uiJacSeqLen:%d \n", __FUNCTION__, (void*)ptJacConjFreqBaseSeqShareDdr, (void*)puiAcSeq, uiSeqLen, uiJacSeqLen);
    

    return BSP_OK;
}

UINT32 SetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiSeqLen)
{
    UINT8 *pcBaseAddr = NULL;
    UINT8 *ptJacConjFreqBaseSeqShareDdr  = NULL;
    UINT32 uiJacSeqLen = 0;
    UINT32 jLoop = 0;
    UINT32 JacConjFreqSeqUpdateFlag =  getJacConjFreqSeqUpdateFlag();

    
    INPUT_POINTER_CHECK(puiAcSeq);

    pcBaseAddr = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);
    uiJacSeqLen = (uiSeqLen > IC_AC_POINT_NUM)?IC_AC_POINT_NUM:uiSeqLen;

    if(E_AC_TYPE_FDD_UL == uiJacType)
    {
        ptJacConjFreqBaseSeqShareDdr = pcBaseAddr + NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR;
        dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR);
    }
    else
    {
        dbgErr("[%s] unsupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    memcpy_s((void *)ptJacConjFreqBaseSeqShareDdr, uiJacSeqLen * sizeof(UINT32), (void *)puiAcSeq, uiJacSeqLen * sizeof(UINT32));
    for (jLoop = 0; jLoop < uiJacSeqLen/4; jLoop++)
    {
        dbgInfoEx("[%d] puiAcSeq = 0x%08x \n", jLoop, puiAcSeq[jLoop]);
    }

    //通知DSP更新AC共轭频域基序列
    JacUpdateAcConjFreqSeq(JacConjFreqSeqUpdateFlag);
    dbgInfo("[%s]:ptJacConjFreqBaseSeqShareDdr: %p, puiAcSeq:%p, uiSeqLen:%d, uiJacSeqLen:%d \n", __FUNCTION__, (void*)ptJacConjFreqBaseSeqShareDdr, (void*)puiAcSeq, uiSeqLen, uiJacSeqLen);
    
    AcFuncLogM(AC_FUNC_LOG_HIGH, "SetJacConjFreqBaseSeq frNo:%d, uiJacType:%d, uiSeqLen:%d \n", IcHalGetFrameNo(), uiJacType, uiJacSeqLen);
    return BSP_OK;
}


UINT32 SetJacDspBitMap(UINT8 uiRcuaAcBitMap, UINT8 ucRcuaFlg)
{ 
    UINT8  *baseAddr = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* pAcMsgIc3;
    if(NULL == (baseAddr = BspGetAcDspMemBaseAddr()))//虚拟基址  /* 调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    pAcMsgIc3 = (T_Cmac2PulmAntAdjustScheInfoIc3*)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr);
    pAcMsgIc3->uiRcuaAcBitMap = uiRcuaAcBitMap;
    pAcMsgIc3->ucRcuaFlg = ucRcuaFlg;
    AcFuncLogM(AC_FUNC_LOG_HIGH, "SetJacDspBitMap frNo:%d, uiRcuaAcBitMap:0x%x, ucRcuaFlg:%d \n", IcHalGetFrameNo(), uiRcuaAcBitMap, ucRcuaFlg);
    dbgInfo("%s:pAcMsgIc3= %p\n",__FUNCTION__, (void*)pAcMsgIc3);
    dbgInfo("%s:uiRcuaAcBitMap= %x, ucRcuaFlg:%d\n",__FUNCTION__, pAcMsgIc3->uiRcuaAcBitMap,pAcMsgIc3->ucRcuaFlg);
    return BSP_OK;
}

UINT32 GetJacDspBitMap()
{ 
    UINT8  *baseAddr = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* pAcMsgIc3;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址  /* 调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    pAcMsgIc3 = (T_Cmac2PulmAntAdjustScheInfoIc3*)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr);
    dbgInfo("%s:uiRcuaAcBitMap= %x, ucRcuaFlg:%d\n",__FUNCTION__, pAcMsgIc3->uiRcuaAcBitMap,pAcMsgIc3->ucRcuaFlg);
    return BSP_OK;
}

/**********************************************RCUA新增接口-END*****************************************************/


UINT32 BspGetAcWgtRbNum(UINT32 radioMode,UINT32 bandWidth,UINT32 pasteCarrFlag,UINT32 If0TypeOrIf1Type)
{
    UINT32 loop = 0;
    UINT32 num  = 0;
    UINT32 acWidth = 0;
    UINT32 retVal = BSP_ERROR;

    if(AC_IF0_TYPE == If0TypeOrIf1Type)
    {
        acWidth = IF0_RB_NUM_LTE;
        return acWidth;
    }

    if((radioMode == RADIO_STANDARD_LTE_TDD)&&(CARR_IS_PASTE == pasteCarrFlag)) //LTE载波拼接
    {
        acWidth = PASTE_CARR_RB_NUM;
        return acWidth;
    }

    num = (sizeof(g_acWgtInfo) / sizeof(g_acWgtInfo[0]));
    for(loop=0; loop < num;loop++)
    {
        if((radioMode == g_acWgtInfo[loop].radioMode)&&(bandWidth == g_acWgtInfo[loop].bandWidth))
        {
            acWidth = g_acWgtInfo[loop].rbNum;
            retVal = BSP_OK;
        }
    }
    dbgInfoEx("%s:radioMode= %#x,bandWidth=%d,acWidth=%d\n",__FUNCTION__,radioMode,bandWidth,acWidth);
    if(BSP_OK == retVal)
    {
        return acWidth;
    }

    return BSP_ERROR;
}

UINT32 GetAcWgtLenOffset(UINT32 uiJacMode, UINT32 uiRadioMode, UINT32 uiBandWidth, UINT32 *puiAcWidth, UINT32 *puiDdrOffset)
{
    UINT32 uiPasteCarrFlag = 0;

    *puiAcWidth = BspGetAcWgtRbNum(uiRadioMode, uiBandWidth, uiPasteCarrFlag, AC_IF1_TYPE);
    if(JAC_ENABLE == uiJacMode)
    {
        *puiDdrOffset = JAC_DDR_DATA_OFFSET;
    }
    else
    {
        *puiDdrOffset = AC_DDR_DATA_OFFSET;
    }

    return BSP_OK;
}

UINT32 GetAcWgtDdr(T_AC_WGT_ADDR_INFO *ptAcWgtAddr, UINT32 **uiData, UINT32 *puiDataLen, UINT32 uiWgtType)
{
    UINT32 uiLoop         = 0;
    UINT32 uiDifChipId    = 0;
    UINT32 uiDifChan      = 0;
    UINT32 uiAntNo        = 0;
    UINT32 uiAntChn       = 0;
    UINT32 uiTargetAntChn = 0;
    UINT32 uiAddrOffset   = 0;
    UINT32 uiRet          = 0;
    UINT32 uiSocId        = 0;
    UINT32 uiDir          = 0;
    UINT32 uiDdrOffset    = 0;
    UINT32 uiAcWidth      = 0;
    UINT8 *pucWgtAddr     = NULL;
    UINT32 uiTaData       = 1;
    UINT32 uiTaAddrOffset = 0;
    UINT32 uiAcNetFactorMode = 0;
    UINT32 uiLoopEnd      = 0;

    INPUT_POINTER_CHECK(ptAcWgtAddr);
    INPUT_POINTER_CHECK(*uiData);
    INPUT_POINTER_CHECK(uiData);
    INPUT_POINTER_CHECK(puiDataLen);

    uiSocId        = ptAcWgtAddr->uiSocId;
    uiDir          = ptAcWgtAddr->uiDir;
    uiDdrOffset    = ptAcWgtAddr->uiDdrOffset;
    uiAcWidth      = ptAcWgtAddr->uiAcWidth;
    pucWgtAddr     = ptAcWgtAddr->pucWgtAddr;
    dbgInfo("[%s] uiSocId:%d, uiDir:%d, uiDdrOffset:%d uiAcWidth:%d, pucWgtAddr:%p\n", __FUNCTION__, uiSocId, uiDir, uiDdrOffset, uiAcWidth, (void*)pucWgtAddr);

    uiAcNetFactorMode = BspGetAcNetMode();
    if(AC_NETMODE_DUP == uiAcNetFactorMode)
    {
        uiLoopEnd = BspGetDupTxChannel();
    }
    else
    {
        uiLoopEnd = BspGetTxChannel();
    }
    for (uiLoop = 0; uiLoop < uiLoopEnd; uiLoop++)
    {
        if(uiLoop >= BspGetTxChannel())
        {
            uiAntNo = uiLoop;
        }
        else
        {
            uiRet = BspGetDifInfoByRfChn(uiLoop, uiDir, &uiDifChipId, &uiDifChan);
            RETURN_RESULT_CHECK(uiRet);
            dbgInfo("BspGetDifInfoByRfChn chan = %d, difChipId = %d, difChan = %d,socId = %d \n", uiLoop, uiDifChipId, uiDifChan, uiSocId);
            if (uiSocId != uiDifChipId)
            {
                dbgInfo("ant:%d not on this chip\n", uiLoop);
                continue;
            }
            dbgInfo("BspGetAntInfoByRfChn chan = %d, antNo = %d, antChn = %d,socId = %d\n", uiLoop, uiAntNo, uiAntChn, uiSocId);
            
            BspGetAntInfoByRfChn(uiLoop, uiDir, &uiAntNo, &uiAntChn);
            uiAntNo = uiAntNo -1; //主控link表定义中的天线号为控制面天线号,从1开始，这里必须-1;
        }
        
        //JAC场景有前4或后四天线配置
        if(RX == uiDir)
        {
        uiRet = BspCheckJacBitMap(uiAntNo);
        RESULT_CHECK_CONTINUE_AC(uiRet);
        }
        uiAddrOffset = uiAntNo * uiDdrOffset * sizeof(UINT32);
        if(uiTargetAntChn != uiAntChn)
        {
            dbgInfo("uiAntChn:%d not equal to uiTargetAntChn:%d\n", uiAntChn, uiTargetAntChn);
            continue;
        }
        if(AC_WGT_TA == uiWgtType)
        {
            uiTaAddrOffset = AC_ANT_WGT_NUM_NR_MAX * sizeof(UINT32);
            memcpy_s((UINT8 *)((VOID *)(*uiData)), uiTaData * sizeof(UINT32), (UINT8 *)(pucWgtAddr + uiAddrOffset + uiTaAddrOffset), uiTaData * sizeof(UINT32));
            dbgInfo("Ta:0x%x \n", **uiData);
            *uiData += uiTaData;
            *puiDataLen += uiTaData * sizeof(UINT32);
             AcFuncLogM(AC_FUNC_LOG_MID, "WgtGet antNo:%d, jacTaLen:%d \n", uiAntNo, uiTaData);
        }
        else
        {
            memcpy_s((UINT8 *)((VOID *)(*uiData)), uiAcWidth * sizeof(UINT32), (UINT8 *)(pucWgtAddr + uiAddrOffset), uiAcWidth * sizeof(UINT32));
            *uiData += uiAcWidth;
            *puiDataLen += uiAcWidth * sizeof(UINT32);
            AcFuncLogM(AC_FUNC_LOG_MID, "WgtGet antNo:%d, wgtLen:%d \n", uiAntNo, uiAcWidth);
        }
    }
    dbgInfo("[%s], uiData:0x%x, puiDataLen:%d uiAddrOffset:%d \n", __FUNCTION__, **uiData, *puiDataLen, uiAddrOffset);

    return BSP_OK;
}

UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
{
    T_Pulm2CmacAntAdjustRspIc3 *ptAcInfo           = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3 *ptSendInfo    = NULL;
    T_AC_WGT_ADDR_INFO tAcWgtAddr                  = {0};
    UINT8  *freqWgtAddr                            = NULL;
    UINT8  *timeWgtAddr                            = NULL;
    UINT8  *baseAddr                               = NULL;
    UINT32 acWidth                                 = 0;
    UINT32 uiRet                                   = 0;
    UINT32 uiAcType                                = 0;
    UINT32 uiJacMode                               = 0;
    UINT32 uiDir                                   = 0;
    UINT32 uiDdrOffset                             = 0;
    UINT32 uiPrachNum                              = 0;
    UINT32 uiPrachId                               = 0;

    recordGetAcWgtIcCnt();
    
    dbgInfoEx("carrNo:%d, pasteCarrFlag:%d, If0OrIf1Type:%d, bandWidth:%d, sampleRate:%d, radioMode:%d, actype:%d\n",\
               carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype);
    //INPUT_POINTER_CHECK(data);
    INPUT_POINTER_CHECK(trxLength);
    INPUT_POINTER_CHECK(prachRxLength);
    baseAddr = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(baseAddr);
    AcFuncLogM(AC_FUNC_LOG_HIGH, "WgtGet socId:%d, acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, OptProt:%d \n",
                                 socId, actype, radioMode, bandWidth, carrNo, deviate);

    uiAcType = BspJudgeAcType(actype);
    uiJacMode = GetJacMode();
    dbgInfo("[%s] uiAcType:%d, acType:%d, uiJacMode:%d \n", __FUNCTION__, uiAcType, actype, uiJacMode);

    uiDir = (E_AC_TYPE_DL == uiAcType)? TX : RX;

    if (uiAcType == ANT_CAL_TX)//下行频域权
    {
        freqWgtAddr = NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_ADDR + baseAddr;
    }
    else                     //上行频域权
    {
        freqWgtAddr = NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_ADDR + baseAddr;
    }

    GetAcWgtLenOffset(uiJacMode, radioMode, bandWidth, &acWidth, &uiDdrOffset);
    if(BSP_ERROR == acWidth)
    {
        dbgErr("Get acWidth error, radioMode=%d, bandWidth=%d\n", radioMode, bandWidth);
        return BSP_ERROR;
    }

    if(AC_IF0_TYPE == deviate)
    {
        acWidth = IF0_RB_NUM_LTE;
    }
    
    dbgInfo("[%s], uiDir:%d, acWidth:%d, uiDdrOffset:%d \n",__FUNCTION__, uiDir, acWidth, uiDdrOffset);

    // 频域权值
    tAcWgtAddr.uiSocId     = socId;
    tAcWgtAddr.uiDir       = uiDir;
    tAcWgtAddr.uiDdrOffset = uiDdrOffset;
    tAcWgtAddr.uiAcWidth   = acWidth;
    tAcWgtAddr.pucWgtAddr  = freqWgtAddr;
    dbgInfo("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);
    uiRet = GetAcWgtDdr(&tAcWgtAddr, &data, trxLength, AC_WGT_FREQ);
    RETURN_RESULT_CHECK(uiRet);
    dbgInfo("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);

    //JAC时延TA值
    if(JAC_ENABLE == uiJacMode)
    {
        uiRet = GetAcWgtDdr(&tAcWgtAddr, &data, trxLength, AC_WGT_TA);
        RETURN_RESULT_CHECK(uiRet);
        dbgInfo("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);
    }

    if(AC_IF0_TYPE == deviate)
    {
        dbgInfo("[%s]IF0 Not Send TimeWgt To Opt\n",__FUNCTION__);
        return BSP_OK;
    }

    /* ************时域权的拷贝************ */
    ptAcInfo    = (T_Pulm2CmacAntAdjustRspIc3*)((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr));
    timeWgtAddr = (UINT8*)((VOID *)(ptAcInfo->acfillInfoRsk.axsAcULPrachWeight));
    ptSendInfo  = (T_Cmac2PulmAntAdjustScheInfoIc3*)((VOID *)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr));
    uiPrachNum  = ptSendInfo->ulPrachNum;
    dbgInfo("NXP_AC_MEM_CPU_RD_AC_INFO_ADDR: %x\n",NXP_AC_MEM_CPU_RD_AC_INFO_ADDR);
    dbgInfo("baseAddr: %p,timeWgtAddr:%p, uiPrachNum:%d\n", (void*)baseAddr, (void*)timeWgtAddr, uiPrachNum);

    uiPrachNum = MAX(uiPrachNum, 1);
    for(uiPrachId = 0; uiPrachId < uiPrachNum; uiPrachId++)
    {
        timeWgtAddr = timeWgtAddr + (uiPrachId * 64 * sizeof(UINT32)); //数据结构axsAcULPrachWeight[2][64]
        tAcWgtAddr.uiDdrOffset    = 1; //Prach权值，每个天线一个权值
        tAcWgtAddr.uiAcWidth      = 1; //Prach权值，每个天线一个权值
        tAcWgtAddr.pucWgtAddr     = timeWgtAddr;
        uiRet = GetAcWgtDdr(&tAcWgtAddr, &data, prachRxLength, AC_WGT_TIME);
        RETURN_RESULT_CHECK(uiRet);
        dbgInfo("[%s], OrgDataAddr:%p uiPrachId:%d BspAntNum:%d\n", __FUNCTION__, (void*)data, uiPrachId, BspGetTxChannel());
    }

    dbgInfo("[%s]SocId %d, actype %d, baseAddr %p, freqWgtAddr %p, trxLength:%d, timeWgtAddr %p, prachRxLength:%d \n",
             __FUNCTION__, socId, actype, (void*)baseAddr, (void*)freqWgtAddr, *trxLength, (void*)timeWgtAddr, *prachRxLength);
    

    return BSP_OK;
}

UINT32 saveAcWgtFromNxp(UINT32* pBuf, UINT32 trxLength,  UINT32 prachRxLength,UINT32 pasteCarrFlag,UINT32 deviate,UINT32 bandWidth,UINT32 carrNo,UINT32 acType)
{
    UINT32 ret          = 0;
    UINT32 loop         = 0;
    UINT32 fRet         = 0;
    CHAR   bufName[64]  = {0};
    INT32  snpRet       = 0;
    UINT32 totalLength  = (trxLength + prachRxLength)/4;
    INPUT_POINTER_CHECK(pBuf);

    //coverity[cert_exp37_c_violation:SUPPRESS]	
    snpRet = snprintf_s(bufName,sizeof(bufName),"%sAcWgtFromNxp_Carr%d_Type%d.txt", BspGetLogPath(), carrNo,acType);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_fio32_c_violation:SUPPRESS]
    FILE*  fp     = fopen(bufName, "w+");
    if(fp == NULL)
    {
        return BSP_ERROR;
    }
    for(loop = 0;loop < totalLength;loop++)
    {
        if(0 > fprintf(fp,"0x%08x\n",pBuf[loop]))
        {
            dbgErr("saveAcWgtFromNxp sprintf err\n");
        }
    }
    fRet = fclose(fp);
    FCLOSE_CHECK(fRet);
    acprintf("\n**** see file AcWgtFromNxp.txt ****\n\n");
    return ret;
}

//设置AC权值
UINT32 SetAcWgtIc(UINT32 carrNo,UINT32 pasteCarrFlag,\
UINT32 deviate,UINT32 bandWidth,UINT32 sampleRate,UINT32 radioMode,\
UINT32 actype, UINT32* pBuf, UINT32 trxLength,  UINT32 prachRxLength)
{
    UINT32 ret              = 0;
    UINT32 trxType          = 0;
    UINT32 *pWgtData        = NULL;
    UINT32 *pPrachWgtData   = NULL;
    UINT32 trxLengthTmp     = trxLength/4;
    UINT32 prachRxLengthTmp = prachRxLength/4;
    UINT32 uiAcType         = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 ulBitMap = BspGetSepareBitmap();
    UINT32 acWgtLength = 0;
    UINT32 uiAcNetFactorMode = 0;
    T_AcCarrInfo tAcCarrInfo = {0};
    T_AcWgtData  tAcWgtData  = {0};
    T_ICHAL_ACPARA *ptAcPara = NULL;

    tAcCarrInfo.carrNo = carrNo;
    tAcCarrInfo.radioMode = radioMode;
    tAcCarrInfo.bandWidth = bandWidth;

    recordSetAcWgtIcCnt();

    INPUT_POINTER_CHECK(pBuf);

    pWgtData      = pBuf;
    pPrachWgtData = pBuf + trxLengthTmp;
    dbgInfo("[%s]carrNo:%d,actype:%d,trxLength:%d,prachRxLength:%d\n",__FUNCTION__,carrNo,actype,trxLength,prachRxLength);
    
    

    uiAcType = BspJudgeAcType(actype);
    dbgInfo("[%s] uiAcType:%d, acType:%d \n", __FUNCTION__, uiAcType, actype);

    saveAcWgtFromNxp(pWgtData,trxLength,prachRxLength,pasteCarrFlag, deviate, bandWidth, carrNo, uiAcType);
    uiAcNetFactorMode = BspGetAcNetMode();
    AcFuncLogS(AC_FUNC_LOG_HIGH, "WgtCfg acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, wgtLen:%d, prachWgtLen:%d \n",
                                  actype, radioMode, bandWidth, carrNo, trxLengthTmp, prachRxLengthTmp);

    trxType = (0 == uiAcType)?1:0;//底层接口０代表上行，与AC相反；
    tAcCarrInfo.acType = trxType;
    dbgInfoEx("[%s] trxType:%d\n", __FUNCTION__, trxType);

    if(E_AC_TYPE_UL == uiAcType)
    {
        //do nothing
    }
    else
    {
        prachRxLengthTmp = 0;//下行AC时prach权值不应该被设置
    }
    dbgInfoEx("[%s]: AC_NETMODE_DUP:%d, AC_CELL_SEPARATE_MODE:%d \n",__FUNCTION__,uiAcNetFactorMode,acCellSeparateMode);

    ptAcPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(ptAcPara);

    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (ptAcPara->acMultiChip != AC_MULTI_CHIP))
    {
        trxLengthTmp /= 2;
        prachRxLengthTmp /= 2;
        if((UINT32)0xF0 == ulBitMap)
        {
            pWgtData += trxLengthTmp;
            pPrachWgtData += prachRxLengthTmp;
        }
        ret = IcHalApiUpdataAcWgt(carrNo,trxType,radioMode,pWgtData,trxLengthTmp,pPrachWgtData,prachRxLengthTmp,s_wgtUpdateBitMap);
    }
    else
    {
        if (((E_AC_TYPE_FDD_DL == actype) || (E_AC_TYPE_DL == actype)) && (s_IsSupportAac == SUPPORT))
        {
            SaveLatestDlAcWgt(carrNo, radioMode, pBuf, trxLength);
            UpdateAcWgt(carrNo, radioMode, pBuf, trxLength, &acWgtLength);
            BspDisableWgt(pBuf, acWgtLength, carrNo, radioMode);
        }
        if(AC_NETMODE_DUP == uiAcNetFactorMode)
        {
            tAcWgtData.pWgt        = pWgtData;
            tAcWgtData.uiWgtLength = trxLengthTmp;
            tAcWgtData.pPrachWgt   = pPrachWgtData;
            tAcWgtData.uiPrachLength = prachRxLengthTmp;
            tAcWgtData.uiPasteCarrFlag = pasteCarrFlag;
            ret= SetAcWgtIcPro(&tAcCarrInfo, &tAcWgtData);
        }
        else
        {
            ret = IcHalApiUpdataAcWgt(carrNo,trxType,radioMode,pWgtData,trxLengthTmp,pPrachWgtData,prachRxLengthTmp,0xff);
        }
    }
    dbgInfoEx("[%s](out): ulBitMap = 0x%x, trxLengthTmp = %d, prachRxLengthTmp = %d,  *pWgtData = 0x%x!\n",__FUNCTION__,s_wgtUpdateBitMap,trxLengthTmp,prachRxLengthTmp,*pWgtData);

    return ret;
}

UINT32 SetAcWgtIcPro(T_AcCarrInfo* ptAcCarrInfo, T_AcWgtData* ptAcWgtData)
{
    UINT32 DupcarrNo = 0;
    UINT32 uidataLen        = 0;
    UINT32 ret = 0;
    UINT32 optacType = 0;
    UINT32 carrNo = 0;
    UINT32 radioMode = 0;
    UINT32 bandWidth = 0;
    UINT32 *pWgtData        = NULL;
    UINT32 trxLengthTmp     = 0;
    UINT32 *pPrachWgtData   = NULL;
    UINT32 prachRxLengthTmp = 0;
    UINT32 pasteCarrFlag    = 0;
 
    INPUT_POINTER_CHECK(ptAcCarrInfo);
    INPUT_POINTER_CHECK(ptAcWgtData);

    INPUT_POINTER_CHECK(ptAcWgtData->pWgt);
    pWgtData = ptAcWgtData->pWgt;
    trxLengthTmp = ptAcWgtData->uiWgtLength;
    INPUT_POINTER_CHECK(ptAcWgtData->pPrachWgt);
    pPrachWgtData = ptAcWgtData->pPrachWgt;
    prachRxLengthTmp = ptAcWgtData->uiPrachLength;
    pasteCarrFlag = ptAcWgtData->uiPasteCarrFlag;

    optacType = ptAcCarrInfo->acType;
    carrNo    = ptAcCarrInfo->carrNo;
    radioMode = ptAcCarrInfo->radioMode;
    bandWidth = ptAcCarrInfo->bandWidth;

    uidataLen = BspGetAcWgtRbNum(radioMode, bandWidth, pasteCarrFlag, AC_IF1_TYPE);

    dbgInfoEx("optacType = %d, carrNo=%d\n", optacType, carrNo);

    BspSetWgtPostPro(g_aiDupCarryArry,pWgtData,g_aiOrgCarryArry,uidataLen,s_wgtUpdateBitMap);
    
    if(1 == optacType)  //下行
    {
        trxLengthTmp = trxLengthTmp/4;//8路数据传2路
        prachRxLengthTmp = prachRxLengthTmp/4;
        ret = IcHalApiUpdataAcWgt(carrNo,optacType,radioMode,g_aiOrgCarryArry,trxLengthTmp,pPrachWgtData,prachRxLengthTmp,s_wgtUpdateBitMap);
        dbgInfoEx("[%s]: *g_aiOrgCarryArry[0] = 0x%x\n",__FUNCTION__, *(g_aiOrgCarryArry));
        dbgInfoEx("[%s]: *g_aiOrgCarryArry[1] = 0x%x\n",__FUNCTION__, *(g_aiOrgCarryArry+1));

        DupcarrNo = IcHalCellGetCpyCarrNoByCarrNo(carrNo, radioMode);
        dbgInfo("optacType = %d, DupcarrNo=%d,carrNo=%d,trxLengthTmp=%d,prachRxLengthTmp=%d\n",optacType, DupcarrNo,carrNo,trxLengthTmp,prachRxLengthTmp);
        RESULT_CHECK_RETURN_AC(DupcarrNo);
        ret = IcHalApiUpdataAcWgt(DupcarrNo,optacType,radioMode,g_aiDupCarryArry,trxLengthTmp,pPrachWgtData,prachRxLengthTmp,s_wgtUpdateBitMap); 
        dbgInfoEx("[%s]: *g_aiDupCarryArry[0] = 0x%x\n",__FUNCTION__, *(g_aiDupCarryArry));
        dbgInfoEx("[%s]: *g_aiDupCarryArry[1] = 0x%x\n",__FUNCTION__, *(g_aiDupCarryArry+1));
        
    }
    else  //上行
    {
        trxLengthTmp = trxLengthTmp/4;
        prachRxLengthTmp = prachRxLengthTmp/4;
        dbgInfo("optacType = %d, carrNo=%d,trxLengthTmp=%d,prachRxLengthTmp=%d\n",optacType, carrNo,trxLengthTmp,prachRxLengthTmp);
        ret = IcHalApiUpdataAcWgt(carrNo,optacType,radioMode,g_aiOrgCarryArry,trxLengthTmp,pPrachWgtData,prachRxLengthTmp,s_wgtUpdateBitMap);
    }
    return ret;
}


//acType = 0是下行AC, acType = 1是上行AC
VOID testSetAcWgtIc(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype)
{
    UINT32* pBuf         = 0;
    UINT32 trxLength     = 0;//频域权的长度，上下行AC都有频域权
    UINT32 prachRxLength = 0;//时域权的长度，只有上行AC才有时域权
    UINT32 loop          = 0;
    UINT8* pdata         = 0;
    UINT32 wgtRbNum      = 0;
    UINT32 uiIcMaxAntNo  = 0;
    UINT32 uiDataLength  = 0;
    T_ICHAL_ACPARA*      acPara  = NULL;
    
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    uiIcMaxAntNo = acPara->acIcMaxAntNo;

    switch(bandWidth)
    {
        case BANDWIDTH_100M_MHz:
        {
            wgtRbNum = 273;
            break;
        }
        case BANDWIDTH_60M_MHz:
        {
            wgtRbNum = 162;
            break;
        }
        case BANDWIDTH_20M_MHz:
        {
            if (radioMode == 0x2000)
            {
                wgtRbNum = 51;
            }
            else
            {
                wgtRbNum = 100;
            }
            break;
        }
        default:
            break;
    }
    //下行AC权值数据量:只有频域权，整板的数据量为64个天线*273个RB*4个字节bytes
    //每个IC只获得32个天线*273个RB*4个字节bytes
    if(0 == actype)//下行AC
    {
        trxLength     = uiIcMaxAntNo * wgtRbNum * 4;//字节长度
        prachRxLength = 0;

    }
    //上行AC权值数据量:频域权+时域权，频域权同下行AC，
    //即频域权: 每个IC分到32个天线*273个RB*4个字节bytes时域权: 整板64天线*4个字节，即每个IC分到32个天线*4字节
    if(1 == actype)//上行AC
    {
        trxLength     = uiIcMaxAntNo * wgtRbNum * 4;//字节长度
        prachRxLength = uiIcMaxAntNo * 4;//字节长度
    }
       
    if(NULL == (pBuf = malloc(trxLength)))
    {
        dbgErr("malloc error\n");
        return;
    }
    uiDataLength = trxLength + prachRxLength;

    memset((VOID*)pBuf, 0, uiDataLength);
    pdata = (UINT8*)pBuf;
    for(loop = 0; loop < uiDataLength; loop++)
    {
        pdata[loop] = loop % 0xFF;
    }
    
    SetAcWgtIc(carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, pBuf, trxLength, prachRxLength);
    free(pBuf);
}
/**************************************************************************
 * 函数名称: BspWriteTxAcMsg
 * 功能描述:将oam传下来的信令消息写入共享内存
 * 输入参数: ucmode=0,   tx message;  ucmode = 1, rx message
                            pdata : 传入数据地址
                            uLength:传入数据长度
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                   牛彦茹    创建
 **************************************************************************/
UINT32 WriteAcMsg(UINT8 mode, UINT8 *pdata, UINT32 length)
{
    UINT8* dstAddr   = NULL;
    UINT8* srcAddr   = NULL;
    UINT32 dataSize  = 0;
    UINT8  *baseAddr = NULL;
    UINT32 retVal    = BSP_OK;

    recordWriteAcMsgCnt();    
    dbgInfoEx("[%s](in):  mode:%d, length:%d\n",__FUNCTION__,mode,length);
    INPUT_POINTER_CHECK(pdata);

    if(NULL == (baseAddr = BspGetAcDspMemBaseAddr()))//调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }

    if (0 == mode)//CPU读DDR存的消息
    {
        srcAddr = NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr;
        dstAddr = pdata;
        dataSize = length;
    }
    else          //CPU往DDR写消息
    {
        srcAddr = pdata;
        dstAddr = NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr;
        dataSize = length;
    }
    
    memcpy_s((VOID*)dstAddr, dataSize, (VOID*)srcAddr, dataSize);
    dbgInfo("[%s]mode %d(1:wr, 0:rd), baseAddr %p, srcAddr %p, dstAddr %p, size 0x%08X\n",\
             __FUNCTION__, mode, (void*)baseAddr, (void*)srcAddr, (void*)dstAddr, dataSize);
    retVal = AcFuncDspAddrInfo(mode);
    RETURN_RESULT_CHECK(retVal);
    
    return BSP_OK;
}

UINT32 GetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    UINT32 syncTimeVal = 0;
    INPUT_POINTER_CHECK(syncTime);
    recordGetAcSyncTimeCnt();

    dbgInfoEx("[%s](in): acType:%d,syncType:%d\n",__FUNCTION__,acType,syncType);
    syncTimeVal = IcHalGetFrameNo();

    (*syncTime) = syncTimeVal;
    AcFuncLogM(AC_FUNC_LOG_HIGH, "SyncGet acType:%d, frNum:%d \n", acType, syncTimeVal);
    
    return BSP_OK;
}

UINT32 sendRecvAcSeqData(UINT32 acType, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 RpuId = 0;
    
    RpuId = BspGetRpuId();
    //初始化
    if(acType == E_AC_TYPE_DL)
    {
        //下行配置
        IcHalDlSetUlBankCatchRamRoundCfg(RpuId,shareInfo);
        testDlAcSeqIc();
    }
    else
    {
        IcHalUlSetUlBankCatchRamRoundCfg(RpuId,shareInfo);
        testUlAcSeqIc();
    }

    return BSP_OK;
}

UINT32 UpdateShareAcWgtStartFrameNo(UINT32 frameNo)
{
    UINT8* baseAddr = NULL;
    A53R8AcDebugShareInfo* shareInfo = NULL;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }

    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + baseAddr);
    shareInfo->acWgtEnableFrameNo = frameNo;
    //发核间中断通知R8取帧号信息
    //tstArmSendIcptoArm(ARM_A53_ICP_CORE,ARM_R8_0_ICP_CORE,msg);//2020.12.30 只发给R8_0 ???

    dbgInfoEx("ShareInfoAddr = %p, frameNo %d, shareInfo->acWgtEnableFrameNo = %d\n",\
              shareInfo, frameNo, shareInfo->acWgtEnableFrameNo);
    return BSP_OK;
}

UINT32 UpdateShareAcSeqStartFrameNo(UINT32 frameNo, UINT32 acType, UINT32 bitMap)
{
    UINT32 uiRealFrNo        = 0;
    UINT8* baseAddr          = NULL;
    UINT32 uiAntNum          = 0;
    UINT32 uiMaxAntNum       = 0;
    UINT32 uiBankSelectFlag  = 0;
    UINT32 uiAcType          = 0;
    UINT32 uiIcNum           = 0;
    UINT32 uiRound           = 0;
    A53R8AcDebugShareInfo* shareInfo = NULL;

    dbgInfo("**************Master deliver frameNo = %d****************\n", frameNo);
	
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }
    uiAcType = BspJudgeAcType(acType);
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + baseAddr);
    if((E_AC_TYPE_DL == acType) ||(E_AC_TYPE_UL == acType) )
    {
        frameNo += AC_PSYNC_FRAMENO_WAIT;
        frameNo %= 1024;
        shareInfo->acSeqStartFrameNo = frameNo;
    }
    uiMaxAntNum = shareInfo->icMaxAntNo;
    uiIcNum = BspGetRpuId();

    if(E_AC_TYPE_DL == uiAcType)
    {
        shareInfo->dlBitMap = 0;
        for(uiAntNum=0; uiAntNum<uiMaxAntNum; uiAntNum++)
        {
            uiBankSelectFlag = BIT_VAL(bitMap, uiAntNum);
            INPUT_AC_PARAMETER_CHECK(uiIcNum, AC_IC_NUM);
            INPUT_AC_PARAMETER_CHECK(uiRound, AC_ROUND_NUM);
            INPUT_AC_PARAMETER_CHECK(uiAntNum, AC_DL_ANTS_NUM);
            if((uiBankSelectFlag) && (dlAcBlockBankBandInfo[uiIcNum].bBInfo[uiRound].dlIsSet[uiAntNum] == 1))
            {
                VAR_BIT_SET(shareInfo->dlBitMap, uiAntNum);
            }
        }
        ///设置上行bitmap图
        shareInfo->ulBitMap = 0xffffffff;
        dbgInfo("%s DL bitMap = %d, shareInfo->dlBitMap = 0x%08X,\n", __FUNCTION__, bitMap, shareInfo->dlBitMap);
    }
    else if(E_AC_TYPE_UL == uiAcType)
    {
        shareInfo->ulBitMap = 0;
        for(uiAntNum=0; uiAntNum<uiMaxAntNum; uiAntNum++)
        {
            uiBankSelectFlag = BIT_VAL(bitMap, uiAntNum);
            INPUT_AC_PARAMETER_CHECK(uiIcNum, AC_IC_NUM);
            INPUT_AC_PARAMETER_CHECK(uiRound, 1);
            INPUT_AC_PARAMETER_CHECK(uiAntNum, AC_UL_ANTS_NUM);
            if((uiBankSelectFlag) && (ulAcBlockBankBandInfo[uiIcNum].bBInfo[uiRound].ulIsSet[uiAntNum] == 1))
            {
                VAR_BIT_SET(shareInfo->ulBitMap, uiAntNum);
            }
        }
        ///设置下行bitmap图
        shareInfo->dlBitMap = 0xffffffff;
        dbgInfo("%s UL bitMap = %d, shareInfo->ulBitMap = 0x%08X \n", __FUNCTION__, bitMap, shareInfo->ulBitMap);
    }
    else
    {
        dbgErr("%s actype error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    //发核间中断,重新绑定中断blockNo
    uiRealFrNo = IcHalGetFrameNo();
    RecordShareAcSeqStartFrameNo(uiAcType,bitMap,frameNo, uiRealFrNo);
    dbgInfo("\n\nShareInfoAddr = %p, frameNo %d, Tdd shareInfo->acSeqStartFrameNo = %d, /FDD startframeNo:%d, stopframeNo:%d \n\n",\
            shareInfo, frameNo, shareInfo->acSeqStartFrameNo, shareInfo->startframeNo, shareInfo->stopframeNo);
    dbgInfo("\n%s ***************DPDIC Real  FrameNo  %d ***************\n",__FUNCTION__, uiRealFrNo);

    //在这里完成AC序列的发送和回收
    sendRecvAcSeqData(uiAcType, shareInfo);

    return BSP_OK;
}

UINT32 bspGetAcWgtOptBitmap(UINT32 bitMap)
{
    UINT32 tmpBitmap  = bitMap;
    return tmpBitmap;
}

UINT32 SetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32 syncTime,UINT32 bitMap)
{
    UINT32 uiAcType              = 0;
    UINT32 uiAcNetFactorMode     = 0;
    UINT32 uiBitmapChangbit      = 0;
    T_ICHAL_ACPARA* acPara       = NULL;
    UINT32 uiRealFrNo = IcHalGetFrameNo();
    dbgInfo("RealFrNo_Prt %s_IN line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);
    uiAcNetFactorMode = BspGetAcNetMode();
    
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);
    uiBitmapChangbit = acPara->acStartChan;

    if(AC_NETMODE_DUP == uiAcNetFactorMode)
    {
        bitMap = bitMap << uiBitmapChangbit;  //9626e机型高层下发参数从通道0开始，实际发采数从通道2开始
    }
    //记录函数执行时间戳
    recordAcTickInfo(0,2,0);//SetAcSyncTime 对应索引 2

    dbgInfoEx("[%s](in): ,acType:%d,syncType:%d,syncTime:%d,bitMap:%d\n",__FUNCTION__,acType,syncType,syncTime,bitMap);

    s_wgtUpdateBitMap = bspGetAcWgtOptBitmap(bitMap);

    uiAcType = BspJudgeAcType(acType);
    if(uiAcType <= 1)
    {
        acBitmap[uiAcType] = bitMap;
    }

    dbgInfo("\n-----bitmap = %d------\n",s_wgtUpdateBitMap);
    if(0 == syncType)//更新AC序列生效的时刻，syncTime即psync的帧号，传给R8的共享内存
    {
        RecordSetAcSyncTimeCnt(syncTime);
        AcFuncLogS(AC_FUNC_LOG_HIGH, "SyncCfg acType:%d, localFr:%d, appBitmap:0x%08x \n", acType, IcHalGetFrameNo(), bitMap);
        UpdateShareAcSeqStartFrameNo(syncTime, acType, bitMap);
    }
    else             //更新AC权值生效的时刻，syncTime即psync的帧号，传给R8的共享内存
    {
        UpdateShareAcWgtStartFrameNo(syncTime);
        dbgInfo("[%s] acType %d,  syncType %d,  syncTime %d,  bitMap %08X\n", __FUNCTION__, uiAcType, syncType, syncTime, bitMap);
    }

    
    recordAcTickInfo(1,2,0);//SetAcSyncTime 对应索引 2
    uiRealFrNo = IcHalGetFrameNo();
    dbgInfo("RealFrNo_Prt %s_OUT line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);
    return BSP_OK;
}

static UINT32 s_CatchCoupleDataChan = 0 ;
static UINT32 s_CatchCoupleDataIc   = 0 ;
static UINT32 s_BandNo              = 0 ;

UINT32 BspSetAcCatchChan(UINT32 catchCoupleDataChan,UINT32 catchCoupleDataIc,UINT32 bandNo)
{
    s_CatchCoupleDataChan = catchCoupleDataChan ;
    s_CatchCoupleDataIc = catchCoupleDataIc ;
    s_BandNo = bandNo;

    dbgInfoEx("CatchCoupleDataChan is %d,CatchCoupleDataIc is %d,bandNo is %d\n",s_CatchCoupleDataChan,s_CatchCoupleDataIc,s_BandNo);
    return BSP_OK ;
}

UINT32 BspGetAcCatchChan(UINT32 *pCatchDataChan, UINT32 *pAcRpuId, UINT32 *pBandNo)
{
    INPUT_POINTER_CHECK(pCatchDataChan);
    INPUT_POINTER_CHECK(pAcRpuId);
    INPUT_POINTER_CHECK(pBandNo);

    *pCatchDataChan = s_CatchCoupleDataChan ;
    *pAcRpuId = s_CatchCoupleDataIc ;
    *pBandNo = s_BandNo;

    return BSP_OK ;
}

VOID testGetBspGetAcCatchChan(VOID)
{
    UINT32 testCatchCoupleDataChan = 0;
    UINT32 testCatchCoupleDataIc = 0;
    UINT32 bandNo = 0;
    (void)BspGetAcCatchChan(&testCatchCoupleDataChan,&testCatchCoupleDataIc,&bandNo);
    dbgInfo("[%s]CoupleDataChan:%d,CoupleDataIc:%d,bandNo:%d\n",__FUNCTION__,testCatchCoupleDataChan,testCatchCoupleDataIc,bandNo);
}

UINT32 IcHalSetInfoToDdrForKo(UINT32 acType, T_ICHAL_ACPARA* acPara ,A53R8AcDebugShareInfo* shareInfo,UINT32 radioMode,UINT32 acSeqLen,UINT32 uCarrNo, UINT32 frameNo)
{
    UINT32 uiFrameType         = 0;
    UINT32 uiAcInsertPos       = 0;
    UINT32 uiStartFrameNo      = 0;
    UINT32 uiStopFrameNo       = 0;
    UINT32 acCellSeparateMode  = BspGetAcCellSeparateMode();

    uiAcInsertPos = GetAcInsertPos();
    //根据小区配置帧结构
    uiFrameType = IcHalGetFrameTypeForAc(uCarrNo,radioMode);
    uiStartFrameNo = (frameNo + AC_MAX_FRAME_NO - 2) % (AC_MAX_FRAME_NO + 1);
    uiStopFrameNo = (frameNo + AC_MAX_FRAME_NO + 3) % (AC_MAX_FRAME_NO + 1);

    shareInfo->a53KoMsgId            = acType;
    shareInfo->icMaxAntNo            = acPara->acIcMaxAntNo;
    shareInfo->acDmaDataLen          = sizeof(UINT32)*acSeqLen;
    shareInfo->frameType             = uiFrameType;
    shareInfo->acInsertPos           = uiAcInsertPos;
    shareInfo->acDlDoneFlag          = 0;
    shareInfo->acUlDoneFlag          = 0;
    shareInfo->acInsertTimes         = acPara->insertTimes;
    shareInfo->startframeNo          = uiStartFrameNo;
    shareInfo->stopframeNo           = uiStopFrameNo;
    shareInfo->acCellSeparateMode    = acCellSeparateMode;
    shareInfo->acJacFlag             = GetJacMode();
    shareInfo->acJacHandleType       = GetJacType();
    shareInfo->acJacCfgSuperFr       = GetJacSuperFr();
    dbgInfo("[%s] ParaSet dmaLen:%d, startFr:%d, stopFr:%d, jacFlag:%d, jacHandleType:%d,acJacCfgSuperFr:%d \n", __FUNCTION__,
    shareInfo->acDmaDataLen, shareInfo->startframeNo, shareInfo->stopframeNo, 
    shareInfo->acJacFlag, shareInfo->acJacHandleType,shareInfo->acJacCfgSuperFr);
    dbgInfo("[%s] shareInfo->a53KoMsgId:%d, shareInfo->acDmaDataLen:%d, frameType:%d, shareInfo->acCellSeparateMode:%d\n",\
        __FUNCTION__, shareInfo->a53KoMsgId, shareInfo->acDmaDataLen, uiFrameType, acCellSeparateMode);

    AcFuncLogS(AC_FUNC_LOG_HIGH, "ParaSet dmaLen:%d, startFr:%d, stopFr:%d, jacFlag:%d, jacHandleType:%d \n",
                                 shareInfo->acDmaDataLen, shareInfo->startframeNo, shareInfo->stopframeNo, shareInfo->acJacFlag, shareInfo->acJacHandleType);

    return BSP_OK;
}

UINT32 IcHalAcGetCalInfo(A53R8AcDebugShareInfo* shareInfo, T_ICHAL_ACPARA* acPara)
{

    UINT32 uiBandNo ;
    UINT32 uiCatchAcRpuId ;
    UINT32 uiSendAcRpuId ;

    uiBandNo = BspGetBandNo();
    uiCatchAcRpuId = acGetRpuIdByBandNo(uiBandNo,acPara->catchAcRpuId);
    uiSendAcRpuId  = acGetRpuIdByBandNo(uiBandNo,acPara->sendAcRpuId);

    shareInfo->acCatchDataChan = acPara->acCatchDataChan;
    shareInfo->catchAcRpuId    = uiCatchAcRpuId;
    shareInfo->acSendDataChan  = acPara->acSendDataChan;
    shareInfo->sendAcRpuId     = uiSendAcRpuId;

    return BSP_OK;
}

UINT32 IcHalSetFixedAcSwitch(A53R8AcDebugShareInfo* shareInfo, T_ICHAL_ACPARA* acPara, UINT32 acChnChgFlag, UINT32 acType)
{
    UINT32 uiRpuId              = BspGetRpuId();
    UINT32 uiCatchDifChan       = 0;
    UINT32 uiSendDifChn         = 0;

    INPUT_POINTER_CHECK(shareInfo);
    INPUT_POINTER_CHECK(acPara);

    if(uiRpuId != shareInfo->sendAcRpuId)
    {
        dbgInfo("[%s], not the sw ic\n", __FUNCTION__);
        return BSP_OK;
    }

    dbgInfoEx("[%s] rpuId:%d, uiCatchDifChan:%d, uiSendDifChn:%d \n", __FUNCTION__, uiRpuId, uiCatchDifChan, uiSendDifChn);
    if(E_AC_TYPE_DL == acType)
    {
        BspSetTxAcSwitch(uiCatchDifChan, SWITCH_ON);
        dbgInfoEx("[%s] BspSetRxAcSwitch uiCatchDifChan:%d SWITCH_ON\n", __FUNCTION__, uiCatchDifChan);
    }
    else if(E_AC_TYPE_UL == acType)
    {
        BspSetRxAcSwitch(uiSendDifChn, SWITCH_ON);
        dbgInfoEx("[%s] BspSetTxAcSwitch uiSendDifChn:%d SWITCH_ON\n", __FUNCTION__, uiSendDifChn);
    }
    else
    {
        BspSetTxAcSwitch(uiCatchDifChan, SWITCH_OFF);
        BspSetRxAcSwitch(uiSendDifChn, SWITCH_OFF);
        dbgInfoEx("[%s] BspSetAcSwitch uiCatchDifChan:%d, uiSendDifChn:%d SWITCH_OFF\n", __FUNCTION__, uiCatchDifChan, uiSendDifChn);
    }

    return BSP_OK;
}

UINT32 g_AcPos = 0;
VOID testSetAcPos(UINT32 val)
{
    g_AcPos = val;
}
UINT32 g_CatchDataPos = 0; 
VOID testSetCatchDataPos(UINT32 val)
{
    g_CatchDataPos = val;
}

UINT32 g_acRadioModeValue = 0;
UINT32 BspGetRadioModeValue(VOID)
{
    return g_acRadioModeValue;
}

UINT32 BspSetRadioModeValue(UINT32 radio)
{
    g_acRadioModeValue = radio;
    return BSP_OK;
}

//帧号配置维测
INT32 g_frNumOffset = 0;
UINT32 BspSetFrNumDebug(INT32 frNumOffset)
{
    g_frNumOffset = frNumOffset;

    return BSP_OK;
}

UINT32 SetAcParaIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 refChn,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{
    UINT32 uiAcGpNum        = 0;
    UINT8 *pucBaseAddr      = NULL;
    UINT32 uiDataOffset     = 0;
    UINT32 uiCpLen          = 0;
    UINT32 uiSeqLen         = 0;
    UINT32 uiTddsel         = 0;
    UINT32 uiAcMode         = 1;
    T_AcParaInfo acParaInfo = {0};
    UINT32 uiAcType         = 0;
    UINT32 uiFrameSetVal    = 0;
    UINT32 uiRet            = 0;
    UINT32 uiIfType         = 0;
    UINT32 uiRealFrNo  = IcHalGetFrameNo();
    g_acRadioModeValue = radioMode;

    AcFuncLogS(AC_FUNC_LOG_HIGH, "ParaSet acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, refChn:%d, chnChgFlag:%d, frNo:%d, slotNo:%d, subframe:%d \n",
                                acType, radioMode, bandWidth, carrNo, refChn, acChnChgFlag, frameNo, slotNo, subframeNo);

    uiAcType = BspJudgeAcType(acType);
    dbgInfo("[%s] uiAcType:%d, acType:%d, frameNo:%d \n", __FUNCTION__, uiAcType, acType, frameNo);
    dbgInfo("RealFrNo_Prt %s_IN line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);
    uiFrameSetVal = (frameNo + g_frNumOffset + 1024) % 1024; //帧号配置维测

    //记录函数执行时间戳
    recordAcTickInfo(0,1,0);//SetAcParaIc 对应索引 1
    RecordSetAcParaIcInfo(uiAcType,refChn,acChnChgFlag);
    recordSetAcParaIcCnt(uiAcType);
    recordErsUpdateTime(uiAcType, uiAcType);

    
    dbgInfo("[%s] radioMode %d\n",__FUNCTION__, radioMode);
    dbgInfo("[%s] bandWidth %d\n",__FUNCTION__, bandWidth);
    dbgInfo("[%s] pasteCarrFlag %d\n",__FUNCTION__, pasteCarrFlag);
    dbgInfo("[%s] deviate %d\n",__FUNCTION__, deviate);
    dbgInfo("[%s] refChn %d\n",__FUNCTION__, refChn);
    dbgInfo("[%s] calcChnChangFlag  %d [0:M_chn;1:S_chn] \n",__FUNCTION__, acChnChgFlag);
    dbgInfo("[%s] carrNo before CA %d\n",__FUNCTION__, carrNo);
    dbgInfo("[%s] frameNo %d\n",__FUNCTION__, uiFrameSetVal);
    dbgInfo("[%s] subFrameNo %d\n",__FUNCTION__, subframeNo);
    dbgInfo("[%s] slotNo %d\n",__FUNCTION__, slotNo);
    carrPasteFlag[carrNo%MAX_CARR_NUM] = pasteCarrFlag;

    A53R8AcDebugShareInfo* shareInfo = NULL;
    T_ICHAL_ACPARA* acPara           = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        recordAcTickInfo(1,1,1);//SetAcParaIc 对应索引 1
        return BSP_ERROR;    
    }
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr);

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    
    uiRet = BspGetAcParaInfo(radioMode, pasteCarrFlag, bandWidth, &acParaInfo);
    dbgInfo("%s get AcParaInfo uiRet:%d \n", __FUNCTION__, uiRet);

    uiDataOffset = acParaInfo.acDataOffset;
    uiCpLen      = acParaInfo.acCpLen;
    uiSeqLen     = acParaInfo.acSeqLen;

    //psync中断初始化
    bspAcPsyncInit(radioMode);

    //AC dlbank 发数位置设置
    IcHalSetDlbankAcInsertPos(g_AcPos);

    //设置AC或者AAC模式
    IcHalSetAcOrAAcMode(uiAcMode);

    //AC ulbank输入数据选择配置
    ICHalSetUlbankAcDataRouterCfg(g_CatchDataPos);

    //获取校准通道和耦合通道信息
    IcHalAcGetCalInfo(shareInfo, acPara);

    //确认耦合通道，适配小区劈裂场景
    IcHalAcChangCalcChan(shareInfo, acPara, acChnChgFlag);

    acCatchDataChnInfo(shareInfo, radioMode);

    //高层建完小区后重新配置:
    IcHalSetBlockBankInfo(radioMode, carrNo, uiDataOffset, acType, shareInfo);

    //共享内存传参数
    IcHalSetInfoToDdrForKo(acType, acPara, shareInfo, radioMode, uiSeqLen, carrNo, uiFrameSetVal);

    
    uiRet = BspGetIfType(shareInfo, radioMode, carrNo, &uiIfType);
    RETURN_RESULT_CHECK(uiRet);

    if((RADIO_STANDARD_5G == radioMode)||((RADIO_STANDARD_LTE_TDD == radioMode)&&(1 == uiIfType)))
    {
        //AC TddFlg延时设置
        IcHalSetTddFlgDly(radioMode,carrNo,g_AcPos);
        //帧频配置
        IcHalSetFrPara(acType,acPara);

        IcHalGetFrameGpNum(0,carrNo,radioMode,0, &uiAcGpNum);

        //射频开关控制,默认第一套TDD
        //获取AC起止时间
        BspGp2Ac(acType, radioMode, carrNo, &s_Gp2Ac);
        BspGp2AcEnd(acType, radioMode ,carrNo, &s_Gp2AcEnd);
        BspTddSwModeSel(uiTddsel, acType);
        BspSetAcSwitchAntMask(acType, acPara);
        INPUT_POINTER_CHECK(acPara->pBspSetAcTddSwitchPwrShare);
        acPara->pBspSetAcTddSwitchPwrShare(acType, shareInfo);
        BspUpdateTddIoVariablePara(uiTddsel, acType);
        INPUT_POINTER_CHECK(acPara->pSetAcTddRfSwitch);
        acPara->pSetAcTddRfSwitch(acType);

        //下行内插前延时
        IcHalSetDlInsertFrontDelayPoint(acType,carrNo,radioMode,pasteCarrFlag,bandWidth, uiAcGpNum);

        //补偿上行接收时延
        IcHalCompensateUlBankCatchRamWaitDelayPoint(acType,carrNo,radioMode,pasteCarrFlag,bandWidth, uiAcGpNum);

        //设置ACRAM的发数长度和采数长度，且将上行AC RAM去使能
        IcHalSetAcRamPara(uiSeqLen, uiCpLen);

        //设置GPEN 使能或是去使能
        IcHalAcSetDlGpEn(acType, carrNo, radioMode);

        dbgInfoEx("acGpNum=%d, acCellSeparateMode:%d\n", uiAcGpNum, shareInfo->acCellSeparateMode);
    }
    else if(RADIO_STANDARD_LTE_TDD == radioMode)
    {
        //射频开关控制,默认第一套TDD
        //获取AC起止时间
        BspGp2Ac(acType, radioMode, carrNo, &s_Gp2Ac);
        BspGp2AcEnd(acType, radioMode ,carrNo, &s_Gp2AcEnd);
        BspTddSwModeSel(uiTddsel, acType);
        BspSetAcSwitchAntMask(acType, acPara);
        BspUpdateTddIoVariablePara(uiTddsel, acType);
        INPUT_POINTER_CHECK(acPara->pSetAcTddRfSwitch);
        acPara->pSetAcTddRfSwitch(acType);

        //设置GPEN 使能或是去使能
        IcHalAcSetDlGpEn(acType, carrNo, radioMode);
        BspFixTxAttValue(acType,acPara,shareInfo);
        BspFixRxAttValue(acType,acPara,shareInfo);
    }
    else
    {
        //帧频配置
        IcHalFddSetFrPara(acPara, uiFrameSetVal);

        //下行AC配置
        if (E_AC_TYPE_FDD_DL == acType)
        {
            //下行内插配置
            IcHalSetFddDlInsertCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara);
            //下行采数配置
            IcHalSetFddDlCatchCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara, shareInfo);
        }
        else if (E_AC_TYPE_FDD_UL == acType) //上行AC配置
        {
            //上行内插配置
            IcHalSetFddUlInsertCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara, shareInfo);
            //上行采数配置
            IcHalSetFddUlCatchCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara);
        }
        else
        {
            dbgInfo("[%s] Ac Stop \n", __FUNCTION__);
        }
        //设置ACRAM的发数长度和采数长度，且将上行AC RAM去使能
        IcHalSetFddAcRamPara(uiSeqLen, uiCpLen, acPara, acType, radioMode);
        //MTS配频
        INPUT_POINTER_CHECK(acPara->pMtsNcoCfg);
        acPara->pMtsNcoCfg(acType, carrNo, radioMode, bandWidth, shareInfo);
        //开关inslot参数配置
        BspSetAcInslotIoCtrl(acType, radioMode, uiFrameSetVal, subframeNo, slotNo);
        SetVswrPara(acType);
        dbgInfo("%s line[%u] actype=%u\n", __FUNCTION__, __LINE__,acType);
    }
    //配置AcSync
    INPUT_POINTER_CHECK(acPara->pSetAcSyncEn);
    acPara->pSetAcSyncEn(acType);

    //设置AC固定att的开关，根据主备耦合通道
    IcHalSetFixedAcSwitch(shareInfo, acPara, acChnChgFlag, uiAcType);
    
    recordAcTickInfo(1,1,0);//SetAcParaIc 对应索引 1
    uiRealFrNo  = IcHalGetFrameNo();
    dbgInfo("RealFrNo_Prt %s_OUT line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);

    return BSP_OK;
}

UINT32 g_ulRefChn = 0;
UINT32 testChangeRefChn(UINT32 ulRefChn)
{
    g_ulRefChn = ulRefChn;
    dbgInfo("g_ulRefChn = %d!\n",g_ulRefChn);
    return BSP_OK;
}

UINT32 testSetAcParaIc(UINT32 acType, UINT32 carrNo,  UINT32 bandWidth, UINT32 radioMode, UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{
    UINT32 pasteCarrFlag = 0;
    UINT32 deviate       = 0;
    UINT32 acChnChgFlag  = 0;
    UINT32 refChn        = g_ulRefChn;

    SetAcParaIc(acType, carrNo, pasteCarrFlag, deviate, bandWidth, acChnChgFlag, radioMode, refChn, frameNo, subframeNo, slotNo);

    return BSP_OK;
}

UINT32 GetAcCatchDataSta(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{
    recordGetAcCatchDataStaCnt();
    return 0;
}

UINT32 BspSetAcCarrCfg(T_AcCarrCfgNxp* pCarrCfg)
{
    INPUT_POINTER_CHECK(pCarrCfg);

    memcpy_s((void*)&(g_acCarrCfgNxp),sizeof(T_AcCarrCfgNxp),(void*)pCarrCfg,sizeof(T_AcCarrCfgNxp));
    dbgInfo("[%s] carrNo%d, radioMode%d, carrFreq(kHz)%d, bandWidth(kHz)%d\n",__FUNCTION__,pCarrCfg->carrNo,pCarrCfg->radioMode,pCarrCfg->carrFreq,pCarrCfg->bandWidth);
    return BSP_OK;
}

T_AcCarrCfgNxp* GetAcCarrCfg(VOID)
{
    return (T_AcCarrCfgNxp*)(&g_acCarrCfgNxp);
}

UINT32 showAcCarrCfg()
{
    dbgInfo("carrNo%d, radioMode%d, carrFreq(kHz)%d, bandWidth(kHz)%d,bandNo:%d\n",
    g_acCarrCfgNxp.carrNo,g_acCarrCfgNxp.radioMode,g_acCarrCfgNxp.carrFreq,g_acCarrCfgNxp.bandWidth,g_acCarrCfgNxp.bandNo);
    return BSP_OK;
}

UINT32 BspInitAcModuleFunc(VOID)
{
    T_AcFunc *pAcModule = NULL;
    
    pAcModule = (T_AcFunc *)BspGetAcModuleInfo();

    pAcModule->pDevInit               = AcDataInit;
    pAcModule->pWrMsg                 = WriteAcMsg;

    pAcModule->pCalAcSeqIc4           = CalAcSeqIc;//计算AC序列
    pAcModule->pChkAcSeqIc            = ChkAcSeqIc;//查询AC序列的计算结果
    pAcModule->pGetAcSeqIc            = GetAcSeqIc;//获取AC序列
    pAcModule->pSetAcSeqIc            = SetAcSeqIc;//设置AC序列
    pAcModule->pGetAcSeqMultiIc       = GetAcSeqMultiIc; //多片机型获取序列

    pAcModule->pSetAcParaIc           = SetAcParaIc;//IC配置
    pAcModule->pGetAcSyncTime         = GetAcSyncTime;//获取AC序列/权值同步时刻
    pAcModule->pSetAcSyncTime         = SetAcSyncTime;//设置AC序列/权值同步时刻

    pAcModule->pGetAcCatchDataSta     = GetAcCatchDataSta; //查询AC采数是否完成
    pAcModule->pSendHaulBackAcSeqIc   = SendHaulBackAcSeqIc;//回收的AC序列传给AC DSP

    pAcModule->pCalAcWgtIc            = CalAcWgtIc;//计算AC权值
    pAcModule->pChkAcWgtIc            = ChkAcWgtIc;//查询AC权值的计算结果

    pAcModule->pGetAcWgtIc            = GetAcWgtIc;
    pAcModule->pSetAcWgtIc            = SetAcWgtIc;//设置AC权值
    pAcModule->pBspGetULCoupleNetFactor   = BspGetULCoupleNetFactor;//耦合网络后处理

    //Jac新增
    pAcModule->pCalJacRefHIc          = CalJacRefHCalcIc; //计算参考通道H
    pAcModule->pGetJacRefHRstIc       = GetJacRefHRstIc; //获取参考通道H计算结果
    pAcModule->pGetJacRefHIc          = GetJacRefHIc; //获取参考通道H
    pAcModule->pSetJacRefHIc          = SetJacRefHIc; //下发参考通道H
    pAcModule->pSetJacMode            = SetJacMode;//下发JAC模式和JAC发采数选择
    pAcModule->pGetJacOrgData         = GetJacOrgData; //获取JAC原始数据
    pAcModule->pSetJacOrgData         = SetJacOrgData; //下发JAC原始数据
    pAcModule->pSetJacSuperFr         = SetJacSuperFr; //下发JAC超帧号
    // RCUA新增
    pAcModule->pSetCalRoute           = SetCalRoute; //设置cal口路由
    pAcModule->pSetJacDspBitMap       = SetJacDspBitMap; //APP向DSP配置位图
    pAcModule->pGetJacConjFreqBaseSeq = GetJacConjFreqBaseSeq; //RCUA上行AC用，校准盒子的APP获取AC基序列，上报给BBU OAM
    pAcModule->pSetJacConjFreqBaseSeq = SetJacConjFreqBaseSeq; //RCUA上行AC用，APP通知RRU0，RRU1的DSP替换校准盒子生成的基序列

    pAcModule->pCheckAcCarrNo         = CheckAcCarrNo;//获取载波信息

    pAcModule->pSetAacWgtIc           = SetAacWgtIc;  /* 设置Aac权值 */
    pAcModule->pSetPimWgtIc           = SetPimRbWgtIc;  /* 禁用指定位置的rb */

    pAcModule->pBspSetCouplingSw      = BspSetCouplingMode;//TDD 8T内外耦合切换
    pAcModule->pSetVswrPara           = SetVswrPara; /* 配置驻波检测参数 */
    pAcModule->pGetVswrCalFinishSta   = GetVswrCalFinishSta;/* 获取驻波计算完成标志 */
    pAcModule->pSetFwdPara            = SetVswrFwdPara;/* 配置FWD参数 */
    pAcModule->pGetVswrData           = GetVswrData;/* 获取驻波值 */
    pAcModule->pBspGetLteCoupleNet    = BspGetIf0LteCoupleNetFactor; //TDD IF0 LTE上传幅相参数

    return BSP_OK;
}

/*****************调试信息上传时删除*******************************/
UINT32 BspAcPrintCtrl(UINT32 ulCtrl)
{
    s_printCtrl = ulCtrl;
    printf("[%s] Print Value %d\n",__FUNCTION__,s_printCtrl);
    return BSP_OK;
}

UINT32 BspAcPrint()
{
    printf("[%s] Print Value %d\n",__FUNCTION__,s_printCtrl);
    return BSP_OK;
}

/*******************调试信息上传时删除************************/
UINT32 BspGetAcWgtIcForTest(UINT32 socId,UINT32 carrNo,UINT32 acType,UINT32 *data,UINT32 *trxLength,UINT32 *prachRxLength)
{
    UINT32 *pDestRamDspAddr   = NULL;
    UINT32 *pAcWeightData     = NULL;
    INT32  iRet               = 0;
    UINT32 acweightBaseOffset = 0;
    UINT32 iLoop              = 0;
    UINT32 upDown = 0;
    upDown = acType;
    
    if(ANT_CAL_RX == upDown)             /*上行*/
    {
        acweightBaseOffset = 0x00c00000;   /*上行共享内存偏移地址*/
        dbgInfo("[%s] Write AC Weight Rx(Up Link). \n",__FUNCTION__);
    }
    else                                 /*下行*/
    {
        acweightBaseOffset = 0x00d00000;   /*下行共享内存偏移地址*/
        dbgInfo("[%s] Write AC Weight Tx(Down Link). \n",__FUNCTION__);
    }

    pDestRamDspAddr = (UINT32*)(s_ucRamDspAddr + acweightBaseOffset);
    if(NULL == pDestRamDspAddr)
    {
        dbgErr("pDestRamDspAddr = null\n");
        return BSP_ERROR;
    }

    pAcWeightData = (UINT32*)malloc(8*273*sizeof(UINT32));
    if (pAcWeightData == NULL)
    {
        dbgInfo("%s[%d]malloc failed!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    memset((UINT32 *)pAcWeightData,0,8*273*sizeof(UINT32));
    
    dbgInfoEx("[%s]Base Addr %p,Static Base Addr %p,Offset Length 0x%x\n",__FUNCTION__,pDestRamDspAddr,s_ucRamDspAddr,acweightBaseOffset);
    
    memcpy((UINT32 *)pAcWeightData, (UINT32 *)pDestRamDspAddr, 8*273*sizeof(UINT32));/*共享内存数据拷贝到开辟的堆中*/

    
    UINT32 printCtrl = 274; //默认打印20次
    
    for(iLoop = 0;iLoop < printCtrl;iLoop ++)
    {
        dbgInfo("[%s]Number %d,Data 0x%08x\n",__FUNCTION__,iLoop,pAcWeightData[iLoop]);         //入库更改为前dbgInfoEx
    }
    memcpy((UINT32 *)data,(UINT32 *)pAcWeightData, 8*273*sizeof(UINT32));
    free(pAcWeightData);
    *trxLength     = 1023;
    *prachRxLength = 1024;

    return iRet;
}

UINT32 BspGetProWgt(UINT32 dir,UINT32 chanNo,UINT32 carrNo,UINT32 *pData,UINT32 *length)
{
    return BSP_OK;
}

UINT32 BspSetAcBitMap(UINT32 sw)
{
    return BSP_OK;
}

UINT32 BspAntCalInitByBw(VOID)
{
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetAcDspSwTaTc
 * 功能描述: 从DSP获取RTT中AAU计算的AC环回时延值(RTT)
 *				第2次上行AC之后读取该值才有效
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年08月26日 xuping    创建
 **************************************************************************/
 INT16 BspGetAcDspSwTaTc(VOID)
{
    T_Pulm2CmacAntAdjustRspIc3* acInfoIc3 = NULL;
    UINT8 * baseAddr = NULL;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return (UINT16)BSP_ERROR;
    }
    acInfoIc3 = (T_Pulm2CmacAntAdjustRspIc3*)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr);
	
    dbgInfo("acInfoIc3 Addr: %p, uiVersionNo 0x%08X, swTaTc 0x%08X\n",\
            (void*)acInfoIc3, acInfoIc3->acMsgHeaderRsk.uiVersionNo, acInfoIc3->acMsgBodyRsk.swTaTc);

    return acInfoIc3->acMsgBodyRsk.swTaTc;
}

/**************************************************************************
 * 函数名称: BspGetCellFreq
 * 功能描述: 获取100M小区中心频点(RTT)
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 100M小区中心频点
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年08月26日 xuping    创建
 **************************************************************************/
UINT32 BspGetCellFreq(VOID)
{			
    UINT8  *baseAddr = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* pAcMsgIc3;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址  /* 调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }
    pAcMsgIc3 = (T_Cmac2PulmAntAdjustScheInfoIc3*)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr);

    //打印出从APP下发的小区频点
    dbgInfo("Get From App CellFreq = 0x%08X\n",s_ulCellFre);
    
    //打印出从DDR读取的小区频点
    dbgInfo("Get From DDR CellFreq = 0x%08X\n, AcMsgIc3 Addr: %p,  ",pAcMsgIc3->ulCellFreq, (void*)pAcMsgIc3);
    
    return pAcMsgIc3->ulCellFreq;
}

//同步模式:fr(1)、GP(0)
//设置数据格式:大数(1)、序列(0)
UINT32 IcHalDltest(UINT32 acType)
{
    UINT32 RpuId = 0;
    UINT32 round = 0;
    RpuId = BspGetRpuId();

    //for循环里面的东西需要挪到R8去做,DLroundcfg
    for(round = 0; round < 9; round++)
    {
        IcHalSetDlBankAcSequenceInsertRoundCfg(RpuId, round);
        BspSysMsDelay(20);
        //清中断
        IcHalSetUlBankCatchRamClearAllInts();
        BspSysMsDelay(2);
        //DMA搬数
        IcHalDmaMoveDataFromUlBankCatchRamToDdrShareMem(round,acType);
    }
    return BSP_OK;
}

//同步模式:fr(1)、GP(0)
//设置数据格式:大数(1)、序列(0)
UINT32 IcHalUltest(UINT32 acType)
{
    //ULroundcfg
    IcHalUlAcRoundCfg(0,0);
    BspSysMsDelay(5000);
    //清中断
    IcHalSetUlBankCatchRamClearAllInts();
    BspSysMsDelay(2); //10ms
    IcHalDmaMoveDataFromUlBankCatchRamToDdrShareMem(0,acType);
    return BSP_OK;  
}

UINT32 showUlAcAllProgressCnt(VOID)
{
    dbgInfo("SendHaulBackAcSeqIcUlAcCnt %d\n", SendHaulBackAcSeqIcUlAcCnt);
    return 0;
}

UINT32 showUlAcVgaData(UINT32 carrNo, UINT32 radioMode)
{
    /*DPDIC4编译修改*/
#if 0
    UINT8*              baseAddr = 0;
    UINT32              sendData = 0;
    IcAcShareMemInfo*   memInfo  = NULL;
    UINT32              retry    = 0;//IC_AC_RETRY_TIME;
    UINT32              round    = 0;//IC_AC_ROUND_T    UINT32              retVal   = 0;
    INT32               preAtt   = 0;
    UINT32              acType = (UINT32)E_AC_TYPE_UL;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }

    memInfo = (IcAcShareMemInfo*)(IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET + baseAddr);
    for(retry = 0; retry < IC_AC_RETRY_TIME; retry++)
    {
        //上行每片C round=16;下行9round
        for(round = 0; round < IC_AC_ULBANK_RAM_NUM; round++)
        {
            if(BSP_OK == BspGetVgaCompCarrFacx(round, carrNo, radioMode, &preAtt))
            {
                sendData = (memInfo->ulAcVgaData.vga[retry][round] - 5*preAtt ) / 5; //ATT单位是0.1dB
                dbgInfo("[%s]retry %d, acType %d, round(Ant) %d, carrNo %d, radioMode %d, [vga %d(0.5) - 5*preAtt %d(0.1)]/5 = %d(0.1)\n", 
                        __FUNCTION__,retry,acType, round, carrNo, radioMode, memInfo->ulAcVgaData.vga[retry][round], preAtt, sendData);
            }
            else
            {
                dbgInfo("[%s]get vga comp error!\n", __FUNCTION__);
            }
        }
    }
#endif
    return BSP_OK;
}

VOID showUlAcData(VOID)
{
    IcAcShareMemInfo*   memInfo  = NULL;
    UINT8*              baseAddr = 0;
    UINT32              retry    = 0;
    UINT32              chan     = 0;
    UINT32              point    = 0;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return;    
    }
    memInfo = (IcAcShareMemInfo*)(IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET + baseAddr);
    for(retry = 0; retry < IC_AC_RETRY_TIME; retry++)
    {
        dbgInfo("\n/************************************retry:%d************************************/\n\n",retry);
        for(chan = 0; chan < IC_AC_ULBANK_RAM_NUM; chan++)
        {
            dbgInfo("\n/************************************chan:%d************************************/\n",chan);
            for(point = 0; point < AC_DATA_LEN_1024; point++)
            {
                if(point % 4 == 0)
                {
                    dbgInfo("\n0x%08x: ", point);
                }
                dbgInfo("0x%08x ", memInfo->ulAcCatch[retry].ulAcCatchData[chan][point]);
            }
        }
    }
}

VOID showDlAcData(VOID)
{
    IcAcShareMemInfo*   memInfo  = NULL;
    UINT8*              baseAddr = 0;
    UINT32              retry    = 0;
    UINT32              round     = 0;
    UINT32              point    = 0;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return;    
    }
    memInfo = (IcAcShareMemInfo*)(IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET + baseAddr);
    for(retry = 0; retry < IC_AC_RETRY_TIME; retry++)
    {
        dbgInfo("\n/************************************retry:%d************************************/\n\n",retry);
        for(round = 0; round < IC_AC_ROUND_TIME; round++)
        {
            dbgInfo("\n/************************************round:%d************************************/\n",round);
            for(point = 0; point < AC_DATA_LEN_1024; point++)
            {
                if(point % 4 == 0)
                {
                    dbgInfo("\n0x%08x: ", point);
                }
                dbgInfo("0x%08x ", memInfo->dlAcCatch[retry].dlAcCatchData[round][point]);
            }
        }
    }
}

UINT32 smpAcDdrData(UINT32 acType, UINT32 retry, CHAR* fileName)
{
    IcAcShareMemInfo*   memInfo  = NULL;
    UINT8*              baseAddr = 0;
    UINT32              round    = 0;
    UINT32              point    = 0;
    UINT32            roundMax   = 0;
    FILE *fp         = NULL;
    CHAR buff[128]   = {0};
    CHAR outFile[64] = {0};
    INT32 iTmpRet    = 0;
    UINT32 data      = 0;

    //INPUT_AC_PARAMETER_CHECK(retry, IC_AC_RETRY_TIME);

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    memInfo = (IcAcShareMemInfo*)(IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET + baseAddr);
    if(E_AC_TYPE_DL == acType)
    {
        roundMax = IC_AC_ROUND_TIME;
    }
    else if(E_AC_TYPE_UL == acType)
    {
        roundMax = IC_AC_ULBANK_RAM_NUM;
    }
    else
    {
        return BSP_ERROR;
    }

    iTmpRet = snprintf_s(outFile,sizeof(outFile) - 1,"ulbankDDR_actype%d_retry%d.txt",acType,retry);
    SNPRINTF_S_CHECK(iTmpRet, sizeof(outFile) - 1);
    fp = fopen(outFile,"w+");
    if(NULL == fp)
    {
        dbgErr("%s open error!",outFile);
        return BSP_ERROR;
    }

    dbgInfo("retry:%d\n",retry);
    for(round = 0; round < roundMax; round++)
    {
        dbgInfo("round:%d\n",round);
        for(point = 0; point < AC_DATA_LEN_1024; point++)
        {
            if(point % 4 == 0)
            {
                iTmpRet = fprintf(fp,"\n0x%08x:",point);
                FPRINTF_CHECK(iTmpRet);
            }
            if(E_AC_TYPE_DL == acType)
            {
                data = memInfo->dlAcCatch[retry].dlAcCatchData[round][point];
            }
            else if(E_AC_TYPE_UL == acType)
            {
                data = memInfo->ulAcCatch[retry].ulAcCatchData[round][point];
            }
            iTmpRet = fprintf(fp," 0x%08x",data);
            FPRINTF_CHECK(iTmpRet);
        }
    }

    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    iTmpRet = snprintf_s(buff,sizeof(buff)-1,"ftpput -u data -p data 198.33.33.2 %s %s",(fileName? fileName : outFile),outFile);
    SNPRINTF_S_CHECK(iTmpRet, sizeof(buff)-1);
    dbgInfo("%s\n",buff);
    BspSystem(buff);
    dbgInfo("*** check file %s ***\n", outFile);
    return BSP_OK;
}

UINT32 IcHalNotifyMsgToKernel(VOID)
{
    INT32 psyfd = 0;
    INT32 ret = 0;
    UINT32 uRet = 0;
    T_NOTIFY_MSG_DATA param = {0};

    psyfd = open("/dev/hirq_misc_usr_d42_ac", O_RDWR);
    if (psyfd < 0)
    {
        dbgInfo("%s >> open /dev/hirq_misc_usr_d42_ac\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ret = ioctl(psyfd, RTTST_RTIOC_MSG_OPT_NOTIFY, &param);
    if (ret < 0)
    {
        dbgInfo("%s >> ioctl RTTST_RTIOC_MSG_OPT_NOTIFY fail\n", __FUNCTION__);
        uRet = BSP_ERROR;
    }
    (VOID)close(psyfd);

    return uRet;
}

VOID testDlAcSeqIc(VOID)
{
    UINT32 psyncOn = 0;
    UINT32 halPsyncInt10IntNo = 58;

    //将下行分组信息拷贝到共享内存
    IcHalCopyBlockBankInfoToShareMem();
    IcHalNotifyMsgToKernel();
    //打开psync中断  拷贝下行分组信息给KO的 ulAcBlockBankInfo
    IcHalPsyncTimSetIntMask(halPsyncInt10IntNo,psyncOn);
    AcFuncCarrSta();
    AcFuncPasta();
    AcFuncAttshow();
    AcFuncDbfs();
    AcFuncDlpostPaptAlm();
    return;
}

VOID testUlAcSeqIc(VOID)
{
    UINT32 psyncOn = 0;
    UINT32 halPsyncInt10IntNo = 58;

    //将上行分组信息拷贝到共享内存
    IcHalCopyBlockBankInfoToShareMem();
    IcHalNotifyMsgToKernel();
    //打开psync中断  拷贝上行分组信息给KO的 ulAcBlockBankInfo
    IcHalPsyncTimSetIntMask(halPsyncInt10IntNo,psyncOn);

    return;
}

UINT32 printAcBitmap(VOID)
{
    dbgInfo("upAcBitmap = 0x%X\n",acBitmap[1]);
    dbgInfo("downAcBitmap = 0x%X\n",acBitmap[0]);
    dbgInfo("s_wgtUpdateBitMap = 0x%X\n",s_wgtUpdateBitMap);

    return BSP_OK;
}

UINT32 bspGetFrameAcLen(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag)
{
    UINT32 loop = 0;
    UINT32 num  = 0;
    UINT32 acLen = 0;
    num = (sizeof(g_tAcLenInfo) / sizeof(g_tAcLenInfo[0]));
    for(loop=0;loop < num;loop++)
    {
        if(CARR_NOT_PASTE != pasteCarrFlag)
        {
            acLen = GP_AC_SQUENCE_LEN_NR_122880;
            break;
        }
        if((radio == g_tAcLenInfo[loop].radio)&&(bw == g_tAcLenInfo[loop].bandWidth))
        {
            acLen = g_tAcLenInfo[loop].acLen;
        }
    }
    dbgInfoEx("%s:radio= %#x,bw=%d,acLen=%d\n",__FUNCTION__,radio,bw,acLen);

    return acLen;   
}

UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag)
{
    UINT32 loop = 0;
    UINT32 num  = 0;
    UINT32 sample = 0;

    num = (sizeof(g_tAcLenInfo) / sizeof(g_tAcLenInfo[0]));
    for(loop=0; loop < num;loop++)
    {
        if(CARR_NOT_PASTE != pasteCarrFlag) 
        {
            sample = CLK_RATE_122P88;
            break;
        }
        if((radio == g_tAcLenInfo[loop].radio)&&(bw == g_tAcLenInfo[loop].bandWidth))
        {
            sample = g_tAcLenInfo[loop].sample;
        }
    }
    dbgInfoEx("%s:radio= %#x,bw=%d,sample=%d\n",__FUNCTION__,radio,bw,sample);

    return sample;  
}

//获取AC内插后插0点数
UINT32 BspGetAcEndInsert0Num(UINT32 acType,UINT32 radioMode,UINT32 carrNo,UINT32 bw,UINT32 pasteCarrFlag)
{
    UINT32 endInsert0Num         = 0;
    FLOAT  factor                = 0.0;
    UINT32 uidifChan             = 0;
    UINT32 uiValidNum            = 0;
    UINT32 uiAcInsertPos         = 0;
    UINT32 acInsertPosRate[20]   = {0};
    UINT32 uiAcRpuId             = 0;
    UINT32 uibandNo              = 0;

    uiAcInsertPos = GetAcInsertPos();
    BspGetAcCatchChan(&uidifChan,&uiAcRpuId,&uibandNo);

    //根据AC发数位置获取该位置采样率
    IcHalApiGetAcTxNodeSampleRate(uidifChan, radioMode, carrNo, uiAcInsertPos, &acInsertPosRate[0], &uiValidNum);

    if(RADIO_STANDARD_5G == radioMode)
    {
        if(E_AC_TYPE_UL == acType)
        {
            endInsert0Num = 2200 ;
        }
        else if(E_AC_TYPE_DL == acType)
        {
            endInsert0Num = 2696 ;
        }
        factor = (FLOAT)acInsertPosRate[0] / (FLOAT)(122880);
    }
    else if(RADIO_STANDARD_LTE_TDD == radioMode)
    {
        endInsert0Num = 2224;//4384-576-1584=2224
        factor = (FLOAT)acInsertPosRate[0] / (FLOAT)(30720);
    }
    endInsert0Num *= factor;
    dbgInfoEx("%s:acType=%d,radioMode=%d,endInsert0Num=%d,acInsertPosRate=%d\n",__FUNCTION__,acType,radioMode,endInsert0Num,acInsertPosRate[0]);
    return endInsert0Num;
}

UINT32 BspGetAcFrToDlEnd(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 bw, UINT32 pasteCarrFlag)
{
    FLOAT fFrameDlyUs                = 0;
    UINT32 uiFreamDly                = 0;
    UINT32 uiDifChn                  = 0;
    UINT32 uiAcInsertPos             = 0;
    UINT32 uiValidNum                = 0;
    UINT32 uiAcInsertPosRate[20]     = {0};
    UINT32 uiCalAntNum               = 0;   
    UINT32 uiAcRpuId                 = 0;
    UINT32 uibandNo                  = 0; 
    UINT8* baseAddr                  = NULL;
    A53R8AcDebugShareInfo* shareInfo = NULL;
    UINT32 acCellSeparateMode        = BspGetAcCellSeparateMode();
    UINT32 separateBit               = BspGetSepareBitmap();

    BspGetAcCatchChan(&uiDifChn,&uiAcRpuId,&uibandNo);
    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        uiDifChn = 4;
    }

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;    
    }
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + baseAddr);
    //coverity[cert_exp39_c_violation:SUPPRESS] 
    uiCalAntNum = (E_AC_TYPE_DL == acType) ? shareInfo->acCatchDataChan : shareInfo->acSendDataChan;


    uiAcInsertPos = GetAcInsertPos();
    IcHalApiGetAcTxNodeSampleRate(uiDifChn, radioMode, carrNo, uiAcInsertPos, &uiAcInsertPosRate[0], &uiValidNum);
    fFrameDlyUs = IcHalGetDLFrameDly(uiCalAntNum, carrNo, radioMode);
    uiFreamDly = NsToClk(((UINT32)(fFrameDlyUs * 1000)), uiAcInsertPosRate[0]);
    
    if(RADIO_STANDARD_5G == radioMode)
    {
        uiFreamDly += 80 * uiAcInsertPosRate[0] / 122880;  //以100M为例，3.5ms×1000×122.88+(4384+64)(S时隙第一个d符号的TS)+5×4384(S时隙5个D符号的TS个数);与代码计算有72的差额，这里再加上8TS的保护；
    }
    else if(RADIO_STANDARD_LTE_TDD == radioMode)
    {
        uiFreamDly = uiFreamDly;
    }
    else
    {
        //do nothing
    }
    dbgInfo("[%s] uiAcInsertPosRate:%d uiFreamDly:%d\n", __FUNCTION__, uiAcInsertPosRate[0], uiFreamDly);

    return uiFreamDly;
}

UINT32 BspGetAcFrontOrEndZeroDelay(UINT32 acType, UINT32 radio, UINT32 carrNo,UINT32 gpNum,UINT32 bw,UINT32 pasteCarrFlag, UINT32 frontOrEnd)
{
    UINT32 delay               = 0;
    UINT32 gpPos               = 0;
    FLOAT factor               = 0;
    UINT32 ret                 = 0;
    UINT32 difChan             = 0;
    UINT32 gpLen               = 0;
    UINT32 symbol0             = 0;
    UINT32 symbol1             = 0;
    UINT32 uiValidNum          = 0;
    UINT32 ueAdvValns          = 0;
    UINT32 acInsertPos         = 0;
    UINT32 acInsertPosRate     = 0;
    UINT32 uiAcRpuId           = 0;
    UINT32 uibandNo            = 0;
    UINT32 acCellSeparateMode  = BspGetAcCellSeparateMode();
    UINT32 separateBit         = BspGetSepareBitmap();

    BspGetAcCatchChan(&difChan,&uiAcRpuId,&uibandNo);
    if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
    {
        difChan = 4;
    }

    acInsertPos = GetAcInsertPos();
    //根据AC发数位置获取该位置采样率
    IcHalApiGetAcTxNodeSampleRate(difChan, radio, carrNo, acInsertPos, &acInsertPosRate, &uiValidNum);

    //获取UE提前量
    ret = IcHalApiGetUeAdvVal(radio, &ueAdvValns);
    dbgInfo("%s ret:%d ueAdvValns:%u, MIX_NR_MODE:%d, radio:%u \n",__FUNCTION__, ret, ueAdvValns, MIX_NR_MODE,radio);

    IcHalGetFrameGpLen(acType,carrNo,radio,&symbol0,&symbol1);
    if(RADIO_STANDARD_5G == radio)
    {
        gpLen = NsToClk(symbol1, CLK_RATE_122P88);
    }
    else
    {
        gpLen = NsToClk(symbol1, CLK_RATE_30P72);
    }
    /*NR 混模场景 && NR UE提前量为2469ts@122.88M  */
    if( ((RADIO_STANDARD_5G | RADIO_STANDARD_LTE_TDD) == (BspGetRadioStandard() & RADIO_STANDARD_45G))||((UINT32)MIX_NR_MODE == ueAdvValns))
    {
        gpPos = 2; //插在倒数第二个gp
        if (1 == gpNum) //当只有一个gp时，无法支持做AC
        {
            dbgErr("%s only one gp, not support to do Ac Test\n",__FUNCTION__);
        }
    }
    else
    {
        gpPos = 1; //插在倒数第一个gp
    }

    if(RADIO_STANDARD_5G == radio)
    {
        if(E_AC_TYPE_UL == acType)
        {
            if(FRONT_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen * (gpNum - gpPos) + GP_TIME_BASE_UPLINK;
            }
            else if(END_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen - (GP_TIME_BASE_UPLINK + AC_SEQ_NR_BASIC_LEN);
            }
        }
        else if(E_AC_TYPE_DL == acType)
        {
            if(FRONT_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen * (gpNum - gpPos) + GP_TIME_BASE_DOWNLIK;
            }
            else if(END_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen - (GP_TIME_BASE_DOWNLIK + AC_SEQ_NR_BASIC_LEN);
            }
        }
        //gplen：NR以122.88M为基础，所以算出的延时也是以122.88M为基础，其他采样率下的延时必须加以转换
        //根据AC发数位置速率折算延时
        factor =  (FLOAT)acInsertPosRate / (FLOAT)(122880);
        delay  = factor*delay;
    }
    else if(RADIO_STANDARD_LTE_TDD == radio)
    {
        //gplen：LTE以30.72M为基础，所以算出的延时也是以30.72M为基础，其他采样率下的延时必须加以转换
        factor = (FLOAT)acInsertPosRate / (FLOAT)(30720);
        if(FRONT_ZERO_TYPE == frontOrEnd)
        {
            delay = factor*(gpLen * gpNum - AC_LTE_SEQ_WITH_RF_DELAY);
        }
        else if(END_ZERO_TYPE == frontOrEnd)
        {
            delay = factor*(AC_LTE_SEQ_WITH_RF_DELAY - AC_SEQ_LTE_BASIC_LEN);
        }
    }
    dbgInfo("%s:delayTpye:%d, radio%#x,delay=%d,gpLen=%d,gpNum=%d,gpPos=%d,acInsertPosRate=%d\n", __FUNCTION__, frontOrEnd, radio, delay, gpLen, gpNum, gpPos, acInsertPosRate);

    AcFuncLogS(AC_FUNC_LOG_HIGH, "radiomode:%d, gpLen:%d, gpNum:%d, gpPos:%d, acInsertPosRate:%d",
                                 BspGetRadioStandard(), gpLen, gpNum, gpPos, acInsertPosRate);

    return delay;
}
/*
提供给射频开关控制调用
*/
UINT32 GetdGp2Ac(UINT32 acType, UINT32 radio,DOUBLE* Gp2Ac)
{
    *Gp2Ac = s_Gp2Ac;
    return BSP_OK;
}

UINT32 GetdGp2AcEnd(UINT32 acType, UINT32 radio, DOUBLE* Gp2AcEnd)
{
    *Gp2AcEnd = s_Gp2AcEnd;
    return BSP_OK;
}

UINT32 SetGp2Ac(UINT32 val)
{
    s_Gp2Ac = val;
    return BSP_OK;
}

UINT32 BspGp2Ac(UINT32 acType, UINT32 radio, UINT32 carrNo,DOUBLE* Gp2Ac)
{
    UINT32 acGpNum   = 0;
    UINT32 bandWidth = 0;
    UINT32 pasteCarrFlag = 0;
    UINT32 acInsertDataDelayClk = 0;
    UINT32 difChan = 0;
    UINT32 uicalcAnt = 0;
    UINT32 uiValidNum = 0;
    UINT32 acInsertPos = 0;
    UINT32 acInsertPosRate = 0;
    UINT32 uiAcRpuId = 0;
    UINT32 bandNo = 0;
    UINT32 uiRet = 0;
    UINT32 difChipId = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();
    T_ICHAL_ACPARA* ptAcPara = NULL;
    UINT32 uiAntId = 0;
    UINT32 uiAntTmp = 0;

    INPUT_POINTER_CHECK(Gp2Ac);

    ptAcPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    if(AC_MULTI_CHIP != ptAcPara->acMultiChip)
    {
        if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == 0xf0))
        {
            difChan = 4;
        }
        else
        {
            BspGetAcCatchChan(&uicalcAnt,&uiAcRpuId,&bandNo);
            uicalcAnt = uicalcAnt +1;
            uiRet = BspGetDifInfoByAntInfo(uicalcAnt, bandNo, TX, &difChipId, &difChan);
            RETURN_RESULT_CHECK(uiRet);
        }
    }
    else
    {
        for(uiAntId = 0;uiAntId < ptAcPara->acIcMaxAntNo; uiAntId++)
        {
            uiAntTmp = BspGetAntNoByDlAcRoundAntSel(0, BspGetRpuId(), uiAntId);
            CHECK_AC_ANT_VALID(uiAntTmp);
            uiAntTmp = uiAntId + 1; //对应map表中的天线号列，需要加1
            uiRet = BspGetDifInfoByAntInfo(uiAntTmp, bandNo, TX, &difChipId, &difChan);
            RESULT_CHECK_BREAK_AC(uiRet);
        }
    }
    acInsertPos = GetAcInsertPos();
    //根据AC发数位置获取该位置采样率
    IcHalApiGetAcTxNodeSampleRate(difChan, radio, carrNo, acInsertPos, &acInsertPosRate, &uiValidNum);

    IcHalGetFrameGpNum(0u,carrNo,radio,0u,&acGpNum);
    acInsertDataDelayClk = BspGetAcFrontOrEndZeroDelay(acType, radio, carrNo, acGpNum, bandWidth, pasteCarrFlag, FRONT_ZERO_TYPE);

    if(acInsertPosRate > 0)
    {
        *Gp2Ac = 1000.0 * (DOUBLE)acInsertDataDelayClk /(DOUBLE)acInsertPosRate ;
    }
    else
    {
        dbgErr("%s acInsertPosRate error!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("%s acType:%d, radio:%X, carrNo:%d , Gp2Ac:%.6f\n",__FUNCTION__, acType, radio,carrNo,*Gp2Ac);

    return BSP_OK;
}

UINT32 BspGp2AcEnd(UINT32 acType, UINT32 radio,UINT32 carrNo, DOUBLE* Gp2AcEnd)
{
    DOUBLE  Gp2Ac = 0;
    UINT32 AcDataLen = 0;
    UINT32 clkRate   = 0;
    if(RADIO_STANDARD_5G == radio)
    {
        AcDataLen = 1088; //32+1024+32
        clkRate = CLK_RATE_122P88;
    }
    else if(RADIO_STANDARD_LTE_TDD == radio)
    {
        AcDataLen = 544; //16+512+16
        clkRate = CLK_RATE_30P72;
    }
    else
    {
        dbgErr("%s clkRate error!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    BspGp2Ac(acType, radio, carrNo,&Gp2Ac);
    *Gp2AcEnd = Gp2Ac + 1000.0 * (DOUBLE)AcDataLen / (DOUBLE)clkRate;

    dbgInfo("%s acType:%d, radio:%X, carrNo:%d , Gp2Ac:%.6f , Gp2AcEnd:%.6f\n",__FUNCTION__, acType, radio,carrNo,Gp2Ac,*Gp2AcEnd);

    return BSP_OK;
}

VOID IcHalShowA53R8AcDebugShareInfo(VOID)
{
    UINT8* baseAddr = NULL;

    A53R8AcDebugShareInfo* shareInfo = NULL;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return ;    
    }
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + baseAddr);
    
    dbgInfo("acSeqStartFrameNo      %d \n",shareInfo->acSeqStartFrameNo);
    dbgInfo("acWgtEnableFrameNo     %d \n",shareInfo->acWgtEnableFrameNo);
    dbgInfo("acCellSeparateMode     %d \n",shareInfo->acCellSeparateMode);
    dbgInfo("acDlDoneFlag           %d \n",shareInfo->acDlDoneFlag);
    dbgInfo("acUlDoneFlag           %d \n",shareInfo->acUlDoneFlag);
    dbgInfo("acDmaDataLen           %d \n",shareInfo->acDmaDataLen);
    dbgInfo("acCatchDataChan        %d \n",shareInfo->acCatchDataChan);
    dbgInfo("acSendDataChan         %d \n",shareInfo->acSendDataChan);
    dbgInfo("acBackUpCatchDataChan  %d \n",shareInfo->acBackUpCatchDataChan);
    dbgInfo("acBackUpSendDataChan   %d \n",shareInfo->acBackUpSendDataChan);
    dbgInfo("dlCatchDifChn          %d \n",shareInfo->dlCatchDifChn);
    dbgInfo("ulSendDifChn           %d \n",shareInfo->ulSendDifChn);
    dbgInfo("dlBitMap               0x%X \n",shareInfo->dlBitMap);
    dbgInfo("ulBitMap               0x%X \n",shareInfo->ulBitMap);
    dbgInfo("sendAcRpuId            %d \n",shareInfo->sendAcRpuId);
    dbgInfo("catchAcRpuId           %d \n",shareInfo->catchAcRpuId);
    dbgInfo("icMaxAntNo             %d \n",shareInfo->icMaxAntNo);
    dbgInfo("frameType              %d \n",shareInfo->frameType);
    dbgInfo("startframeNo           %d \n",shareInfo->startframeNo);
    dbgInfo("stopframeNo            %d \n",shareInfo->stopframeNo);
    dbgInfo("acInsertPos            %d \n",shareInfo->acInsertPos);
    dbgInfo("acInsertTimes          %d \n",shareInfo->acInsertTimes);
    dbgInfo("a53KoMsgId             %d \n",shareInfo->a53KoMsgId);
}

UINT32 BspSetBoardAcInfo(VOID)
{
    IcHalAcBoardInfo data = {0};

    //从60M，开始的A53-R8的共享空间，大小为4M<物理地址基址、虚拟地址基址>
    data.shareMemPhyAddrBase         = IC_AC_SHARE_MEM_ADDR_PHY_BASE;
    data.shareMemVirAddrBase         = s_ucRamDspAddr;
    data.shareMemAllSize             = IC_AC_SHARE_MEM_ADDR_SIZE;

    //下行AC和上行AC的采数回读区域，用DMA从IC的片内RAM搬到DDR中
    data.dlAcUlBankCatchAddrOffset   = IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET;
    data.ulAcUlBankCatchAddrOffset   = IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET;

    //下行AC和上行AC的天线分组(block和bank)信息，用直接memcpy或者写地址形式，A53写入，R8读出
    data.dlAcBlockBankInfoAddrOffset = IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_ADDR_OFFSET;
    data.dlAcBlockBankInfoSize       = IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_SIZE;
    data.ulAcBlockBankInfoAddrOffset = IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_ADDR_OFFSET;
    data.ulAcBlockBankInfoSize       = IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_SIZE;

    //下行AC和上行AC的权值更新信息，用直接memcpy或者写地址形式，A53写入，R8读出
    //上下行公用，所以定义的地址相同
    data.AcWgtDmaInfoAddrOffset      = IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_ADDR_OFFSET;
    data.AcWgtDmaInfoSize            = IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_SIZE;

    data.a53R8DebugInfoAddrOffset    = IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET;
    data.a53R8DebugInfoSize          = IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_SIZE;

    data.vgaDataAddrOffset           = IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET;
    data.vgaDataSize                 = IC_AC_SHARE_MEM_UL_AC_VGA_DATA_SIZE;

    return IcHalSetBoardInfoInit(&data);
}

UINT32 ac_carr_err = 0;
UINT32 CheckAcCarrNo(UINT32 carrNo,UINT32 radioMode)
{
    UINT32 retVal = BSP_ERROR;
    /*
    UINT32 loopSel = 0;
    UINT32 maxCarrNum = 0;
    T_AcCarrcfg recordcarrcfg = {0,};
    UINT32 retVal = BSP_ERROR;
    UINT32 difChan = 0;
    
    maxCarrNum = BspGetCarrCfg(difChan,&recordcarrcfg);
    maxCarrNum = min(8, maxCarrNum);
    dbgInfoEx("[%s] carrNo'%d, radioMode'%d, difChan'%d,\n",__FUNCTION__,carrNo,radioMode,difChan);

    for (loopSel = 0;loopSel < maxCarrNum;loopSel++)
    {
        if(carrNo == recordcarrcfg.carrcfgInfo[loopSel][0][1])
        {
            retVal = BSP_OK;
            break;
        }
    }    
    if(maxCarrNum == loopSel)
    {
        ac_carr_err++;
    }
    */
    return retVal;
}

UINT32 bspAcPsyncInit(UINT32 radioMode)
{
    UINT32 PsyncInt10IntNo    = 244;
    UINT32 halPsyncInt10IntNo = 58; //244在中频内部映射的中断号
    UINT32 uTimePeriod        = 10000000;//10ms
    UINT32 frPeriod           = 5000000;// 帧周期5ms
    UINT32 psyncOff           = 1;
    UINT32 uInter             = 0;
    UINT32 frTmVal            = 0;
    UINT32 uTimeOffset        = 4500000;//4.5ms

   //通用Psync中断初始化
   frTmVal = IcHalApiGetFrTmVal(0,radioMode);
   //psync中断位置 = （帧头延时+4.5）% 5 ，不区分单模或者混模 frTmVal单位是ns,折算到ms
   uTimeOffset = (frTmVal + 4500000) % frPeriod;
   HalIcPsyncTimGernXInit(PsyncInt10IntNo,uTimePeriod,uTimeOffset,uInter,SWITCH_ON);
   //关Psync
   IcHalPsyncTimSetIntMask(halPsyncInt10IntNo,psyncOff);
   dbgInfo("radioMode=%d,frTmVal = %d,uTimeOffset = %d\n",radioMode,frTmVal,uTimeOffset);

   return BSP_OK;
}
UINT32 IcHalAcChangCalcChan(A53R8AcDebugShareInfo* shareInfo, T_ICHAL_ACPARA* acPara, UINT32 calcChanFlag)
{
    UINT32 acCatchDataChan = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();
    UINT32 ulRpuId = BspGetRpuId();
    UINT32 ulBandNo = 0;

    if(AC_NOT_CHANGE_CALC_CHN == calcChanFlag)
    {
        if((AC_CELL_SEPARATE_MODE == acCellSeparateMode) && (separateBit == (UINT32)0xF0)) //8T机型后四劈裂场景启用备用耦合通道
        {
            shareInfo->acCatchDataChan = acPara->acBackUpCatchDataChan;
            shareInfo->acSendDataChan = acPara->acBackUpSendDataChan;
            acCatchDataChan = shareInfo->acCatchDataChan;
        }
        else
        {
            shareInfo->acCatchDataChan = acPara->acCatchDataChan;
            shareInfo->acSendDataChan = acPara->acSendDataChan;
            acCatchDataChan = shareInfo->acCatchDataChan;
        }

    }
    else if(AC_CHANGE_CALC_CHN == calcChanFlag)
    {
        shareInfo->acCatchDataChan = acPara->acBackUpCatchDataChan;
        shareInfo->acSendDataChan = acPara->acBackUpSendDataChan;
        acCatchDataChan = shareInfo->acCatchDataChan;
    }
    else
    {
        dbgErr("[%s] calcChanFlag : %d error!\n",__FUNCTION__, calcChanFlag);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] acCatchDataChan : %d!\n",__FUNCTION__, acCatchDataChan);
    BspSetAcCatchChan(acCatchDataChan,ulRpuId,ulBandNo);
    return BSP_OK;
}

/* Started by AICoder, pid:1c38cvb276m73c514b5f095b8057d329e5785987 */
/* 权值初始化为0x40000000 */
UINT32 BspSetWgtToDefValNew(UINT32 (*pWgtData)[IC42_AC_MAX_RB_NUM], UINT32 rowsNum)
{
    UINT32 rows = 0;
    UINT32 cols = 0;
    const UINT32 defWgtVal = 0x40000000;

    for (rows = 0; rows < rowsNum; rows++)
    {
        for (cols = 0; cols < IC42_AC_MAX_RB_NUM; cols++)
        {
            pWgtData[rows][cols] = defWgtVal;
        }
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:1c38cvb276m73c514b5f095b8057d329e5785987 */

UINT32 InitStoredCarrWgt(UINT32 logicCarrNo, UINT32 radioMode)
{
    UINT32 index = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        if ((s_wgtBakDataPara[index].carrNo == logicCarrNo) && (s_wgtBakDataPara[index].radioMode == radioMode))
        {
            s_wgtBakDataPara[index].carrNo = 0;
            s_wgtBakDataPara[index].radioMode = 0;
            BspSetWgtToDefVal(s_wgtBakDataPara[index].aacWgtbak, IC42_MAX_CHAN_NUM);
            BspSetWgtToDefVal(s_wgtBakDataPara[index].dlAcWgtbak, AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM);
            BspSetWgtToDefValNew(s_wgtBakDataPara[index].aacCjtWgtbak, IC42_MAX_POLA_CHAN);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

UINT32 BspInitAllSaveWgt(void)
{
    UINT32 index = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        BspSetWgtToDefVal(s_wgtBakDataPara[index].aacWgtbak, IC42_MAX_CHAN_NUM);
        BspSetWgtToDefVal(s_wgtBakDataPara[index].dlAcWgtbak, AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM);
        BspSetWgtToDefValNew(s_wgtBakDataPara[index].aacCjtWgtbak, IC42_MAX_POLA_CHAN);
    }
    BspInitStoredCarrWgtCallback(InitStoredCarrWgt);

    s_IsSupportAac = SUPPORT;

    return BSP_OK;
}

static UINT32 GetSaveWgtIndex(UINT32 logicCarrNo, UINT32 radioMode)
{
    UINT32 index = 0;
    UINT32 carrIndex = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        if ((s_wgtBakDataPara[index].carrNo == logicCarrNo) && (s_wgtBakDataPara[index].radioMode == radioMode))
        {
            carrIndex = index;
            return carrIndex;
        }
    }

    if(index >= NELEMENTS(s_wgtBakDataPara))
    {
        for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
        {
            if ((s_wgtBakDataPara[index].carrNo == 0) && (s_wgtBakDataPara[index].radioMode == 0))
            {
                carrIndex = index;
                return carrIndex;
            }
        }
    }

    return index;
}

static UINT32 SaveLatestDlAcWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pAcWgtData, UINT32 acWgtLength)
{
    UINT32 wgtLoop = 0;
    UINT32 carrIndex = 0;
    UINT32 acWgtLengthTmp = acWgtLength / sizeof(UINT32);
    UINT32 chanNum = BspGetTxChanNum();

    INPUT_POINTER_CHECK(pAcWgtData);

    carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);

    if ((acWgtLengthTmp > AC_MAX_RB_NUM * chanNum) || (carrIndex >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    s_wgtBakDataPara[carrIndex].carrNo = logicCarrNo;
    s_wgtBakDataPara[carrIndex].radioMode = radioMode;
    s_wgtBakDataPara[carrIndex].dlAcWgtLength = acWgtLength;

    for (wgtLoop = 0; wgtLoop < acWgtLengthTmp; wgtLoop++)
    {
        s_wgtBakDataPara[carrIndex].dlAcWgtbak[wgtLoop] = pAcWgtData[wgtLoop];
    }

    return BSP_OK;
}

static UINT32 SaveLatestAacWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pAacWgtData, UINT32 aacWgtLength)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    UINT32 validChanNum = aacWgtLength / sizeof(UINT32);
    UINT32 chanNum = BspGetTxChanNum();

    INPUT_POINTER_CHECK(pAacWgtData);

    carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    if ((validChanNum > chanNum) || (carrIndex >= BSP_MAX_CARR_NUM))
    {
        dbgErr("%s: validChanNum(%d) or carrIndex(%d) error!!\n", __FUNCTION__, validChanNum, carrIndex);
        return BSP_ERROR;
    }

    s_wgtBakDataPara[carrIndex].carrNo = logicCarrNo;
    s_wgtBakDataPara[carrIndex].radioMode = radioMode;
    s_wgtBakDataPara[carrIndex].aacWgtLength = aacWgtLength;

    for (bspChan = 0; bspChan < validChanNum; bspChan++)
    {
        s_wgtBakDataPara[carrIndex].aacWgtbak[bspChan] = pAacWgtData[bspChan];
    }

    return BSP_OK;
}

static UINT32 GetAcWgtLength(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pacWgtLength)
{
    T_RruRfCfgInfo rruCfgPara = {0};
    UINT32 carrLoop = 0;
    UINT32 rfChan = 0;
    UINT32 bandWidth = 0;
    UINT32 rbNum = 0;
    UINT32 chanNum = BspGetTxChanNum();

    INPUT_POINTER_CHECK(pacWgtLength);

    /* 方案确认：暂时不支持劈裂场景，先获取通道0载波信息，后续等方案确认是否需要加位图信息，通过位图来获取通道号 */
    BspGetChnlCfgCarrPara(rfChan, &rruCfgPara);

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
    {
        if ((rruCfgPara.carr[carrLoop].carrTxNo == logicCarrNo) && (rruCfgPara.carr[carrLoop].carrTxRadio == radioMode))
        {
            bandWidth = rruCfgPara.carr[carrLoop].carrTxBw / 1000; /* 带宽单位转换 */
            rbNum = BspGetAcWgtRbNum(radioMode, bandWidth, 0,AC_IF1_TYPE);
            if(rbNum == BSP_ERROR)
            {
                return BSP_ERROR;
            }
            *pacWgtLength = rbNum * chanNum * sizeof(UINT32);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

static UINT32 CalcUpdateAcWgt(UINT32 carrIndex, UINT32 *pUpdataWgt, UINT32 updataWgtLength)
{
    UINT32 bspChan = 0;
    UINT32 rbIndex = 0;
    UINT32 rbNum = 0;
    UINT32 acWgtIndex = 0;
    UINT32 chanNum = BspGetTxChanNum();
    T_AcWgtComplexData acData = {0};
    T_AcWgtComplexData aacData = {0};
    T_AcWgtComplexData wgtNew = {0};
    UINT32 polaChan = 0;

    INPUT_POINTER_CHECK(pUpdataWgt);

    if ((chanNum == 0) || (updataWgtLength < s_wgtBakDataPara[carrIndex].dlAcWgtLength))
    {
        dbgErr("%s: Parameter check Failed!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    rbNum = s_wgtBakDataPara[carrIndex].dlAcWgtLength / chanNum / sizeof(UINT32);

    for(bspChan = 0; bspChan < chanNum; bspChan++)
    {
        aacData.real = s_wgtBakDataPara[carrIndex].aacWgtbak[bspChan] >> 16;
        aacData.imag = s_wgtBakDataPara[carrIndex].aacWgtbak[bspChan] & 0xFFFF;

        for (rbIndex = 0; rbIndex < rbNum; rbIndex++)
        {
            acWgtIndex = bspChan * rbNum + rbIndex;

            /* Started by AICoder, pid:o1e83t0daak9bd314606096cf0fcaf14e055dcf1 */
            polaChan = bspChan % 2;
            if(SUPPORT == BspGetIsSupportAac())
            {
                aacData.real = (s_wgtBakDataPara[carrIndex].aacCjtWgtbak[polaChan][rbIndex] >> 16) & 0xFFFF;
                aacData.imag = s_wgtBakDataPara[carrIndex].aacCjtWgtbak[polaChan][rbIndex] & 0xFFFF;
            }
            /* Ended by AICoder, pid:o1e83t0daak9bd314606096cf0fcaf14e055dcf1 */
            acData.real = s_wgtBakDataPara[carrIndex].dlAcWgtbak[acWgtIndex] >> 16;
            acData.imag = s_wgtBakDataPara[carrIndex].dlAcWgtbak[acWgtIndex] & 0xFFFF;

            BspGetWgtByCmplNumMult(&acData, &aacData, &wgtNew);

            pUpdataWgt[acWgtIndex] = ((((INT16)(wgtNew.real)) << 16) & 0xFFFF0000) | ((INT16)(wgtNew.imag) & 0xFFFF);
            dbgInfoEx("aacData.real: %d,aacData.imag:%d,acData.real: %d,acData.imag:%d,wgtNew.real: %d,wgtNew.imag:%d,pUpdataWgt:0x%x\n",
                    aacData.real, aacData.imag, acData.real, acData.imag, wgtNew.real, wgtNew.imag, pUpdataWgt[acWgtIndex]);
        }
    }

    return BSP_OK;
}

/* Started by AICoder, pid:n512833a67df6a91473f0a12706379621a279908 */
UINT32 CalcUpdateAcWgtNew(UINT32 saveWgtIndex, UINT32 *pUpdataWgt, UINT32 updataWgtLength)
{
    UINT32 bspChan = 0;
    UINT32 rbIndex = 0;
    UINT32 rbNum = 0;
    UINT32 acWgtIndex = 0;
    UINT32 polaChan = 0;
    UINT32 chanNum = BspGetTxChanNum();
    T_AcWgtComplexData acData = {0};
    T_AcWgtComplexData aacData = {0};
    T_AcWgtComplexData wgtNew = {0};

    INPUT_POINTER_CHECK(pUpdataWgt);

    if ((chanNum == 0) || (updataWgtLength < s_wgtBakDataPara[saveWgtIndex].dlAcWgtLength))
    {
        dbgErr("%s: Parameter check Failed!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /* rb数目在上一层UpdateAcWgt通过更新length 已经更新过了 */
    rbNum = s_wgtBakDataPara[saveWgtIndex].rbNum;

    for(bspChan = 0; bspChan < chanNum; bspChan++)
    {
        for (rbIndex = 0; rbIndex < rbNum; rbIndex++)
        {
            acWgtIndex = bspChan * rbNum + rbIndex;

            /* 按极化通道划分aac权值 */
            polaChan = bspChan % 2;
            aacData.real = (s_wgtBakDataPara[saveWgtIndex].aacCjtWgtbak[polaChan][rbIndex] >> 16) & 0xFFFF;
            aacData.imag = s_wgtBakDataPara[saveWgtIndex].aacCjtWgtbak[polaChan][rbIndex] & 0xFFFF;

            acData.real = s_wgtBakDataPara[saveWgtIndex].dlAcWgtbak[acWgtIndex] >> 16;
            acData.imag = s_wgtBakDataPara[saveWgtIndex].dlAcWgtbak[acWgtIndex] & 0xFFFF;

            BspGetWgtByCmplNumMult(&acData, &aacData, &wgtNew);

            pUpdataWgt[acWgtIndex] = ((((INT16)(wgtNew.real)) << 16) & 0xFFFF0000) | ((INT16)(wgtNew.imag) & 0xFFFF);
            dbgInfoEx("aacData.real: %#x,aacData.imag:%#x,acData.real: %#x,acData.imag:%#x,wgtNew.real: %#x,wgtNew.imag:%#x,pUpdataWgt: 0x%x\n",
                    aacData.real, aacData.imag, acData.real, acData.imag, wgtNew.real, wgtNew.imag, pUpdataWgt[acWgtIndex]);
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:n512833a67df6a91473f0a12706379621a279908 */

static UINT32 UpdateAcWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pUpdataWgt, UINT32 updataWgtLength, UINT32 *pAcWgtLength)
{
    UINT32 carrIndex = 0;
    UINT32 acWgtLength = 0;

    INPUT_POINTER_CHECK(pUpdataWgt);
    INPUT_POINTER_CHECK(pAcWgtLength);

    carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    if (carrIndex >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }

    if (s_wgtBakDataPara[carrIndex].dlAcWgtLength == 0)
    {
        if (GetAcWgtLength(logicCarrNo, radioMode, &acWgtLength) != BSP_OK)
        {
            return BSP_ERROR;
        }
        s_wgtBakDataPara[carrIndex].dlAcWgtLength = acWgtLength;
    }

    *pAcWgtLength = s_wgtBakDataPara[carrIndex].dlAcWgtLength;

    CalcUpdateAcWgt(carrIndex, pUpdataWgt, updataWgtLength);

    return BSP_OK;
}

/* Started by AICoder, pid:pc982tac6048fda148a40abed031374ac606d015 */
UINT32 UpdateAcWgtNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pUpdataWgt, UINT32 updataWgtLength, UINT32 *pAcWgtLength)
{
    UINT32 carrIndex = 0;
    UINT32 acWgtLength = 0;

    INPUT_POINTER_CHECK(pUpdataWgt);
    INPUT_POINTER_CHECK(pAcWgtLength);

    carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    if (carrIndex >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }

    if (s_wgtBakDataPara[carrIndex].dlAcWgtLength == 0)
    {
        if (GetAcWgtLength(logicCarrNo, radioMode, &acWgtLength) != BSP_OK)
        {
            return BSP_ERROR;
        }
        s_wgtBakDataPara[carrIndex].dlAcWgtLength = acWgtLength;
    }

    *pAcWgtLength = s_wgtBakDataPara[carrIndex].dlAcWgtLength;

    CalcUpdateAcWgtNew(carrIndex, pUpdataWgt, updataWgtLength);

    return BSP_OK;
}
/* Ended by AICoder, pid:pc982tac6048fda148a40abed031374ac606d015 */

static UINT32 CheckAacWgtRange(UINT32 *pAacWgt, UINT32 aacWgtNum)
{
    UINT16 wgtI = 0;
    UINT16 wgtQ = 0;
    UINT32 loop = 0;
    const UINT16 negAacWgtThr = 0xC000;
    const UINT16 posiAacWgtThr = 0x4000;

    INPUT_POINTER_CHECK(pAacWgt);

    for (loop = 0; loop < aacWgtNum; loop++)
    {
        wgtI = pAacWgt[loop] >> 16;
        wgtQ = pAacWgt[loop] & 0xFFFF;
        if (((wgtI < negAacWgtThr) && (wgtI > posiAacWgtThr)) ||
            ((wgtQ < negAacWgtThr) && (wgtQ > posiAacWgtThr)))
        {
            dbgErr("AAC Wgt Out of Range!!\n");
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

static UINT32 SaveLatestPimWgt(T_PimWgtCarrInfo *aacCarrInfo, UINT32 disableRbStart, UINT32 disableRbNum, UINT32 disableTxChanMap)
{
    UINT32 carrIndex = 0;

    INPUT_POINTER_CHECK(aacCarrInfo);

    carrIndex = GetSaveWgtIndex(aacCarrInfo->carrNo, aacCarrInfo->radioMode);
    if (carrIndex >= BSP_MAX_CARR_NUM)
    {
        dbgErr("%s>>>carrIndex(%d) error!!\n", __FUNCTION__, carrIndex);
        return BSP_ERROR;
    }

    s_wgtBakDataPara[carrIndex].carrNo = aacCarrInfo->carrNo;
    s_wgtBakDataPara[carrIndex].radioMode = aacCarrInfo->radioMode;
    s_wgtBakDataPara[carrIndex].disableRbStart = disableRbStart;
    s_wgtBakDataPara[carrIndex].disableRbNum = disableRbNum;
    s_wgtBakDataPara[carrIndex].disableTxChanMap = disableTxChanMap;

    return BSP_OK;
}

static UINT32 ClrRbWgtByPos(UINT32 *pWgt, UINT32 wgtLength, UINT32 rbStartPos, UINT32 rbEndPos)
{
    INPUT_POINTER_CHECK(pWgt);
    if (rbEndPos >= wgtLength)
    {
        return BSP_ERROR;
    }

    for (; rbStartPos < rbEndPos; rbStartPos++)
    {
        pWgt[rbStartPos] = 0;
    }

    return BSP_OK;
}

static UINT32 BspDisableWgt(UINT32 *pWgt, UINT32 wgtLength, UINT32 carrNo, UINT32 radioMode)
{
    UINT32 chanNum = BspGetTxChannel();
    UINT32 rbNum = 0;
    UINT32 loop = 0;
    UINT32 rbStartPos = 0;
    UINT32 rbEndPos = 0;
    UINT32 carrNoRbStart = 0;
    UINT32 carrNoRbNum = 0;
    UINT32 txChanMap = 0;
    UINT32 carrIndex = 0;

    INPUT_POINTER_CHECK(pWgt);

    carrIndex = GetSaveWgtIndex(carrNo, radioMode);
    if ((carrIndex >= BSP_MAX_CARR_NUM) || (chanNum == 0))
    {
        dbgErr("%s>>>carrIndex(%d) or chanNum(%d) error!!\n", __FUNCTION__, carrIndex, chanNum);
        return BSP_ERROR;
    }

    carrNoRbStart = s_wgtBakDataPara[carrIndex].disableRbStart;
    carrNoRbNum = s_wgtBakDataPara[carrIndex].disableRbNum;
    txChanMap = s_wgtBakDataPara[carrIndex].disableTxChanMap;
    if (carrNoRbNum == 0)
    {
        return BSP_OK;
    }

    rbNum = wgtLength / (chanNum * sizeof(UINT32));
    dbgInfo("%s>>>rbNum[%d], carrNoRbStart[%d], carrNoRbNum[%d], txChanMap[%d]\n", __FUNCTION__, rbNum, carrNoRbStart, carrNoRbNum, txChanMap);
    for (loop = 0; loop < chanNum; loop++)
    {
        if (txChanMap & BIT_SET(loop))
        {
            rbStartPos = carrNoRbStart + rbNum * loop;
            rbEndPos = carrNoRbNum + rbStartPos;
            dbgInfo("loop[%d], rbStartPos[%d], rbStartPos[%d]\n", loop, rbStartPos, rbEndPos);
            ClrRbWgtByPos(pWgt, wgtLength, rbStartPos, rbEndPos);
        }
    }
    return BSP_OK;
}

UINT32 SetPimRbWgtIc(T_PimWgtCarrInfo *aacCarrInfo, UINT32 disableRbStart, UINT32 disableRbNum, UINT32 disableTxChanMap)
{
    UINT32 acMaxWgtLength = 0;
    UINT32 acWgtLength     = 0;
    UINT32 ret             = BSP_OK;
    UINT32 *pWgt           = NULL;
    UINT32 carrNo          = 0;
    UINT32 radioMode       = 0;
    UINT32 trxType         = 0;
    UINT32 acWgtLengthTmp  = 0;
    UINT32 prachWgtData    = 0;

    INPUT_POINTER_CHECK(aacCarrInfo);

    carrNo = aacCarrInfo->carrNo;
    radioMode = aacCarrInfo->radioMode;
    trxType = aacCarrInfo->trxType;

    if (trxType != TX)
    {
        dbgErr("%s>>>trxType(%u) is error!\n", __FUNCTION__, trxType);
        return BSP_ERROR;
    }

    dbgInfo("%s>>>carrNoRbStart[%d], carrNoRbNum[%d], txChanMap[%d]\n", __FUNCTION__, disableRbStart, disableRbNum, disableTxChanMap);
    if (BSP_OK != SaveLatestPimWgt(aacCarrInfo, disableRbStart, disableRbNum, disableTxChanMap))
    {
        return BSP_ERROR;
    }

    acMaxWgtLength = AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM * sizeof(UINT32); /* 长度为byte */
    pWgt = (UINT32*)malloc(acMaxWgtLength);
    if(pWgt == NULL)
    {
        dbgErr("%s: malloc error!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((UINT32 *)pWgt, acMaxWgtLength, 0, acMaxWgtLength);

    if (BSP_OK != UpdateAcWgt(carrNo, radioMode, pWgt, acMaxWgtLength, &acWgtLength))
    {
        dbgErr("%s: Updata wgt fail!!\n", __FUNCTION__);
        free(pWgt);
        return BSP_ERROR;
    }

    acWgtLengthTmp = acWgtLength / sizeof(UINT32);
    dbgInfo("acWgtLength[%d], carrNo[%d], radioMode[%d]\n", acWgtLength, carrNo, radioMode);
    BspDisableWgt(pWgt, acWgtLength, carrNo, radioMode);

    ret = IcHalApiUpdataAcWgt(carrNo, trxType, radioMode, pWgt, acWgtLengthTmp, &prachWgtData, 0, disableTxChanMap);

    free(pWgt);

    return ret;
}

UINT32 SetAacWgtIc(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 bitAntMap, UINT32 *data, UINT32 length)
{
    UINT32 dlAcMaxWgtLength = 0;
    UINT32 prachRxLength   = 0;
    UINT32 acWgtLengthTmp  = 0;
    UINT32 acWgtLength     = 0;
    UINT32 prachWgtData    = 0;
    UINT32 trxType         = 0;
    UINT32 validChanNum    = length / sizeof(UINT32);
    UINT32 ret             = BSP_OK;
    UINT32 wgtBitMap       = 0xff; /* 先传所有通道位图 */
    UINT32 *pWgt           = NULL;

    INPUT_POINTER_CHECK(data);

    s_aacInitiateNum++;

    dbgInfo("%s: logicCarrNo:%d, radioMode:%d, acType:%d, length:%d\n", __FUNCTION__, logicCarrNo, radioMode, acType, length);

    if (validChanNum > BspGetTxChannel())
    {
        dbgErr("%s: validChanNum(%d) error!!\n", __FUNCTION__, validChanNum);
        return BSP_ERROR;
    }

    if (BSP_OK != CheckAacWgtRange(data, validChanNum))
    {
        DbgSaveAbnormalAacPara(logicCarrNo, radioMode, data, length);
        return BSP_ERROR;
    }

    trxType = BspGetTrxTypeByAcType(acType);
    if (BSP_ERROR == trxType)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != SaveLatestAacWgt(logicCarrNo, radioMode, data, length))
    {
        return BSP_ERROR;
    }

    dlAcMaxWgtLength = AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM * sizeof(UINT32); /* 长度为byte */
    pWgt = (UINT32*)malloc(dlAcMaxWgtLength);
    if(pWgt == NULL)
    {
        dbgErr("%s: malloc error!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((UINT32 *)pWgt, dlAcMaxWgtLength, 0, dlAcMaxWgtLength);

    if (BSP_OK != UpdateAcWgt(logicCarrNo, radioMode, pWgt, dlAcMaxWgtLength, &acWgtLength))
    {
        dbgErr("%s: Updata wgt fail!!\n", __FUNCTION__);
        free(pWgt);
        return BSP_ERROR;
    }

    acWgtLengthTmp = acWgtLength / sizeof(UINT32);
    BspDisableWgt(pWgt, acWgtLength, logicCarrNo, radioMode);

    ret = IcHalApiUpdataAcWgt(logicCarrNo, trxType, radioMode, pWgt, acWgtLengthTmp, &prachWgtData, prachRxLength, wgtBitMap);

    free(pWgt);

    return ret;
}

/* Started by AICoder, pid:y90d05700e4a994141650b2bd0db81742936a67e */
/* 检测下发的AAC权值是否错误 */
UINT32 BspCheckAacWgtRangeNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 pAacWgt[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM])
{
    UINT32 rbIndex = 0;
    INT16 wgtReal = 0;
    INT16 wgtImag = 0;
    DOUBLE initialWgtReal = 0.0;
    DOUBLE initialWgtImag = 0.0;
    DOUBLE realWgtAbs = 0.0;
    DOUBLE imagWgtAbs = 0.0;
    DOUBLE wgtAbs = 0.0;
    UINT32 polaChan = 0;
    UINT32 rbNum = 0;
    UINT32 saveWgtIndex = 0;
    UINT32 pacWgtLength = 0;
    UINT32 bspChanNum = BspGetTxChannel();
    const DOUBLE wgtOffetVal = 0x4000;
    const DOUBLE wgtAbsThr = 1.01;

    INPUT_POINTER_CHECK(pAacWgt);
    saveWgtIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    INDEX_RANGE_CHECK(saveWgtIndex, BSP_MAX_CARR_NUM);
    rbNum = s_wgtBakDataPara[saveWgtIndex].rbNum;
    if(0 == rbNum)
    {
        GetAcWgtLength(logicCarrNo, radioMode, &pacWgtLength);
        rbNum = pacWgtLength / bspChanNum / sizeof(UINT32);
    }
    for(polaChan = 0; polaChan < IC42_MAX_POLA_CHAN; polaChan++)
    {
        for (rbIndex = 0; rbIndex < rbNum; rbIndex++)
        {
            wgtReal = (pAacWgt[polaChan][rbIndex] >> 16) & 0xFFFF;
            initialWgtReal = wgtReal / wgtOffetVal;
            wgtImag = pAacWgt[polaChan][rbIndex] & 0xFFFF;
            initialWgtImag = wgtImag / wgtOffetVal;
            /* 获取权值的模值，理论是等于1，但是由于计算的精度导致部分权值模值略大于1 */
            realWgtAbs = initialWgtReal * initialWgtReal;       //计算值略大于1
            imagWgtAbs = initialWgtImag * initialWgtImag;       //计算值略大于1
            wgtAbs = realWgtAbs + imagWgtAbs;
            if ((realWgtAbs > wgtAbsThr) || (imagWgtAbs > wgtAbsThr) || (wgtAbs > wgtAbsThr))
            {
                dbgErr("real:%d, imag:%d, realWgtAbs:%f, imagWgtAbs:%f, AAC Wgt Out of Range!!\n", wgtReal, wgtImag, realWgtAbs, imagWgtAbs);
                return BSP_ERROR;
            }
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:y90d05700e4a994141650b2bd0db81742936a67e */

/* Started by AICoder, pid:j32c680267wbe2f14dcc084e90665d6e7024b42c */
/* 保存下行的AAC权值，按照极性通道进行保存 */
UINT32 SaveLatestAacWgtNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 pAacWgtData[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM], UINT32 aacWgtLength)
{
    UINT32 rbIndex = 0;
    UINT32 saveWgtIndex = 0;
    UINT32 chanNum = BspGetTxChanNum();
    UINT32 polaChan = 0;
    UINT32 rbNum = 0;
    UINT32 pacWgtLength = 0;

    INPUT_POINTER_CHECK(pAacWgtData);

    saveWgtIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    INDEX_RANGE_CHECK(saveWgtIndex, BSP_MAX_CARR_NUM);
    rbNum = s_wgtBakDataPara[saveWgtIndex].rbNum;

    if(0 == rbNum)
    {   /* 带宽需要转换一下，才能获取rbNum */
        GetAcWgtLength(logicCarrNo, radioMode, &pacWgtLength);
        rbNum = pacWgtLength / chanNum / sizeof(UINT32);
    }

    s_wgtBakDataPara[saveWgtIndex].carrNo = logicCarrNo;
    s_wgtBakDataPara[saveWgtIndex].radioMode = radioMode;
    s_wgtBakDataPara[saveWgtIndex].aacWgtLength = aacWgtLength;
    s_wgtBakDataPara[saveWgtIndex].rbNum = rbNum;

    for(polaChan = 0; polaChan < IC42_MAX_POLA_CHAN; polaChan++)
    {
        for (rbIndex = 0; rbIndex < rbNum; rbIndex++)
        {
            s_wgtBakDataPara[saveWgtIndex].aacCjtWgtbak[polaChan][rbIndex] = pAacWgtData[polaChan][rbIndex];
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:j32c680267wbe2f14dcc084e90665d6e7024b42c */

/* Started by AICoder, pid:b0d88vc7fem8dd814aef09423080cd54c6a79730 */
/* 保存错误的AAC权值 */
static UINT32 DbgSaveAbnormalAacParaNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 pAacWgtData[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM], UINT32 aacWgtLength)
{
    UINT32 polaChan = 0;
    UINT32 rbNum = 0;
    UINT32 rbIndex = 0;
    UINT32 pacWgtLength = 0;
    UINT32 saveWgtIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    UINT32 chanNum = BspGetTxChanNum();

    INPUT_POINTER_CHECK(pAacWgtData);

    s_errAacNum = (s_errAacNum % BSP_MAX_CARR_NUM);
    INDEX_RANGE_CHECK(saveWgtIndex, BSP_MAX_CARR_NUM);
    rbNum = s_wgtBakDataPara[saveWgtIndex].rbNum;
    if (0 == rbNum)
    {
        GetAcWgtLength(logicCarrNo, radioMode, &pacWgtLength);
        rbNum = pacWgtLength / chanNum / sizeof(UINT32);
    }

    s_dbgAacWgtData[s_errAacNum].logicCarrNo = logicCarrNo;
    s_dbgAacWgtData[s_errAacNum].radioMode = radioMode;
    s_dbgAacWgtData[s_errAacNum].aacWgtLength = aacWgtLength;
    s_dbgAacWgtData[s_errAacNum].aacInitiateNum = s_aacInitiateNum;
    s_dbgAacWgtData[s_errAacNum].aacRbNum = rbNum;

    for(polaChan = 0; polaChan < IC42_MAX_POLA_CHAN; polaChan++)
    {
        for (rbIndex = 0; rbIndex < rbNum; rbIndex++)
        {
            s_dbgAacWgtData[s_errAacNum].aacErrWgtbak[polaChan][rbIndex] = pAacWgtData[polaChan][rbIndex];
        }
    }
    s_errAacNum++;

    return BSP_OK;
}
/* Ended by AICoder, pid:b0d88vc7fem8dd814aef09423080cd54c6a79730 */

/* Started by AICoder, pid:e0d88cc7fe78dd814aef09423080cd74c6a39730 */
UINT32 SetAacWgtIcNew(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 data[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM], UINT32 length)
{
    UINT32 dlAcMaxWgtLength = 0;
    UINT32 prachRxLength   = 0;
    UINT32 loop   = 0;
    UINT32 acWgtLengthTmp  = 0;
    UINT32 acWgtLength     = 0;
    UINT32 prachWgtData    = 0;
    UINT32 trxType         = 0;
    UINT32 ret             = BSP_OK;
    UINT32 *pWgt           = NULL;
    UINT32 pacWgtLength    = 0;
    UINT32 ulAcBitMap   = 0xffffffff;

    INPUT_POINTER_CHECK(data);

    s_aacInitiateNum++;

    dbgInfo("%s: logicCarrNo:%d, radioMode:%d, acType:%d, length:%d\n", __FUNCTION__, logicCarrNo, radioMode, acType, length);

    GetAcWgtLength(logicCarrNo, radioMode, &pacWgtLength);
    length = pacWgtLength / sizeof(UINT32);

    if (BSP_OK != BspCheckAacWgtRangeNew(logicCarrNo, radioMode, data))
    {
        DbgSaveAbnormalAacParaNew(logicCarrNo, radioMode, data, length);
        return BSP_ERROR;
    }

    trxType = BspGetTrxTypeByAcType(acType);
    if (BSP_ERROR == trxType)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != SaveLatestAacWgtNew(logicCarrNo, radioMode, data, length))
    {
        return BSP_ERROR;
    }

    dlAcMaxWgtLength = IC42_AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM * sizeof(UINT32);
    pWgt = (UINT32*)malloc(dlAcMaxWgtLength);

    if(pWgt == NULL)
    {
        dbgErr("%s: malloc error!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((UINT32 *)pWgt, dlAcMaxWgtLength, 0, dlAcMaxWgtLength);

    if (BSP_OK != UpdateAcWgtNew(logicCarrNo, radioMode, pWgt, dlAcMaxWgtLength, &acWgtLength))
    {
        dbgErr("%s: Updata wgt fail!!\n", __FUNCTION__);
        free(pWgt);
        return BSP_ERROR;
    }

    acWgtLengthTmp = acWgtLength / sizeof(UINT32);

    for(loop = 0; loop < acWgtLengthTmp; loop++)
    {
        dbgInfoEx("loop %d data %#x\n", loop, pWgt[loop]);
    }

    ret = IcHalApiUpdataAcWgt(logicCarrNo, trxType, radioMode, pWgt, acWgtLengthTmp, &prachWgtData, prachRxLength, ulAcBitMap);

    free(pWgt);

    return ret;
}
/* Ended by AICoder, pid:e0d88cc7fe78dd814aef09423080cd74c6a39730 */

/* AAC维测接口 */
static UINT32 DbgSaveAbnormalAacPara(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pAacWgtData, UINT32 aacWgtLength)
{
    UINT32 bspChan = 0;
    UINT32 validChanNum = aacWgtLength / sizeof(UINT32);

    INPUT_POINTER_CHECK(pAacWgtData);

    s_errAacNum = (s_errAacNum % BSP_MAX_CARR_NUM);

    if (validChanNum > IC42_MAX_CHAN_NUM)
    {
        dbgErr("%s: validChanNum(%d) error!!\n", __FUNCTION__, validChanNum);
        return BSP_ERROR;
    }

    s_dbgAacWgtDataPara[s_errAacNum].logicCarrNo = logicCarrNo;
    s_dbgAacWgtDataPara[s_errAacNum].radioMode = radioMode;
    s_dbgAacWgtDataPara[s_errAacNum].aacWgtLength = aacWgtLength;
    s_dbgAacWgtDataPara[s_errAacNum].aacInitiateNum = s_aacInitiateNum;

    for (bspChan = 0; bspChan < validChanNum; bspChan++)
    {
        s_dbgAacWgtDataPara[s_errAacNum].aacErrWgtbak[bspChan] = pAacWgtData[bspChan];
    }
    s_errAacNum++;

    return BSP_OK;
}

static VOID dbgshowerraacpara(VOID)
{
    UINT32 loop = 0;
    UINT32 wgtIndex = 0;

    for (loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
    {
        if (s_dbgAacWgtDataPara[loop].radioMode == 0)
        {
            break;
        }
        dbgInfo("logicCarrNo:%d, radioMode:%d, aacWgtLength:%d, aacInitiateNum:%d\n",
                s_dbgAacWgtDataPara[loop].logicCarrNo,
                s_dbgAacWgtDataPara[loop].radioMode,
                s_dbgAacWgtDataPara[loop].aacWgtLength,
                s_dbgAacWgtDataPara[loop].aacInitiateNum);
        dbgInfo("AAC Wgt:\n");

        for (wgtIndex = 0; wgtIndex < IC42_MAX_CHAN_NUM; wgtIndex++)
        {
            dbgInfo("0x%x ,",s_dbgAacWgtDataPara[loop].aacErrWgtbak[wgtIndex]);
        }
        dbgInfo("\n");
    }
    return ;
}

static VOID dbgsetaacwgt(UINT32 bspChan, UINT32 aacWgt)
{
    if(bspChan < IC42_MAX_CHAN_NUM)
    {
        s_testAacWgt[bspChan] = aacWgt;
        return ;
    }
    dbgErr("bspChan is Error!!\n");

    return ;
}

static UINT32 dbgtestaacwgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 bitAntMap, UINT32 length)
{
    return SetAacWgtIc(logicCarrNo, radioMode, acType, bitAntMap, s_testAacWgt, length);
}

static UINT32 dbgshowacwgt(UINT32 radioMode, UINT32 logicCarrNo)
{
    UINT32 index = 0;
    UINT32 loop = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        if ((s_wgtBakDataPara[index].carrNo == logicCarrNo) && (s_wgtBakDataPara[index].radioMode == radioMode))
        {
            for(loop = 0; loop < IC42_MAX_CHAN_NUM; loop++)
            {
                dbgInfo("0x%x, ",s_wgtBakDataPara[index].aacWgtbak[loop]);
            }
            dbgInfo("\n aacWgtLength:%d\n",s_wgtBakDataPara[index].aacWgtLength);
            dbgInfo("disableRbStart:%d, disableRbNum:%d, disableTxChanMap:%d \n",
                s_wgtBakDataPara[index].disableRbStart, s_wgtBakDataPara[index].disableRbNum, s_wgtBakDataPara[index].disableTxChanMap);

            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

/****************************************************************
* 函数名称: BspOutOfPsyncDetectPsyncInit
* 函数说明: 失步干扰检测 10ms中断使能
* 输入参数:
*
* 输出参数
* 返回参数： BSP_OK,  BSP_ERROR
* 修改说明：
*****************************************************************/
UINT32 BspOutOfPsyncDetectPsyncInit(VOID)
{
    
    UINT32 timePeriod        = 10000000;/*10ms*/
    UINT32 psyncOff           = 1;
    UINT32 inter              = 0;
    UINT32 timeOffset         = 9924000;/*提前2个符号打开中断*/
    UINT32 PsyncInt10IntNo    = 246;
    UINT32 halPsyncInt10IntNo = 60; /*246在中频内部映射的中断号*/

    HalIcPsyncTimGernXInit(PsyncInt10IntNo, timePeriod, timeOffset, inter, SWITCH_ON);
    //关Psync
    IcHalPsyncTimSetIntMask(halPsyncInt10IntNo, psyncOff);
    dbgInfo("PsyncInt10IntNo=%d,TimeOffset = %d\n",PsyncInt10IntNo, timeOffset);

    return BSP_OK;
}


UINT32 BspGetPauRelativePhaseDup(UINT32 ulChan, UINT32 ulBand, INT32 lFreq, INT32 *plPhase)
{
    TPauRelativePhaseCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;

    INPUT_POINTER_CHECK(plPhase);
    *plPhase = 0;                 /*正常范围默认值*/

    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);

    ptCaliData = (TPauRelativePhaseCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEPHASE,0);
    PAURELATIVEPHASE_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    INPUT_POINTER_CHECK(ptRecord);

    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    INPUT_AC_ZERO_CHECK(ulStepFreq);

    if (lFreq <= (INT32)ulStartFreq)
    {
        ulIndex = 0;
        lComps = ptRecord[0].lBoardTemp;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        ulIndex = ulRecordNum - 1;
        lComps = ptRecord[ulRecordNum-1].lBoardTemp;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lBoardTemp,
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lBoardTemp);
    }
    *plPhase = lComps;
    dbgInfoEx("%s>>Chnl'%d Band'%d Freq(Step'%d Sta'%d End'%d)'%d:Idx= %d, phase= %d\n",
              __FUNCTION__, ulChan, ulBand, ulStepFreq, ulStartFreq,
              ulEndFreq, lFreq, ulIndex, lComps);
    return BSP_OK;
}



VOID testGetCoupNetAcIc1(UINT32 chan, UINT32 carrNo, UINT32 dir)
{
    UINT16 validFre       = 0;
    UINT16* validFreNum = NULL;

    validFreNum = &validFre;
    BspGetULCoupleNetFactor(carrNo, chan, validFreNum, (UINT32*)(VOID*)g_arryTest);

}

UINT32 BspGetDupTxChannel(VOID)
{
    UINT32 uiChanNum = 0;
    uiChanNum = 2 * BspGetTxChannel();//原始通道数翻倍，9626e机型通道数特殊处理
    return uiChanNum;
}


UINT32 BspGetCoupNetPostPro(UINT32 *pUlNetFactorApp,UINT32 *pUlNetFactorSource,UINT32 uiChan,UINT16 *pvalidFreNum,UINT32 carryno)
{
    UINT32 antTmp = 0;
    UINT32 antNum = BspGetTxChannel();
    UINT16 uiValidFreNum = 0;
    UINT32 uiFreqTmp = 0;
    UINT32 dir = 1;

    INPUT_POINTER_CHECK(pUlNetFactorApp);
    INPUT_POINTER_CHECK(pUlNetFactorSource);
    INPUT_POINTER_CHECK(pvalidFreNum);
    uiFreqTmp = BspGetFreqBw(dir, uiChan, carryno)/1000;

    if(AC_WEIGHT_MAX_BAND_NUM < uiFreqTmp)
    {
        return BSP_ERROR;
    }

    uiValidFreNum = (UINT16)(uiFreqTmp & 0xFFFF);
    
    zte_memcpy_s((VOID*)&pUlNetFactorApp[0], sizeof(UINT32) * AC_WEIGHT_DATA_NUM, (VOID*)&pUlNetFactorSource[uiChan * AC_WEIGHT_DATA_NUM], sizeof(UINT32) * AC_WEIGHT_DATA_NUM);
    dbgInfo("%s>>Chnl'%d antTmp:'%d  Orgfactorapp= %d,;pUlNetFactorSourceOrg:%d\n",
       __FUNCTION__, uiChan,antTmp,pUlNetFactorApp[0],pUlNetFactorSource[uiChan * AC_WEIGHT_FOR_APP_ARR]);
    
    pUlNetFactorApp[(uiValidFreNum - 1)] = pUlNetFactorSource[uiChan * AC_WEIGHT_DATA_NUM + uiValidFreNum-2];//传送给BBU数据新增至100个点
    dbgInfo("%s>>Chnl'%d antTmp:'%d  Orgfactorapp= %d,;pUlNetFactorSourceOrg:%d\n",
       __FUNCTION__, uiChan,antTmp,pUlNetFactorApp[(uiValidFreNum - 1)],pUlNetFactorSource[uiChan * AC_WEIGHT_FOR_APP_ARR + uiValidFreNum - 2]);
    
    zte_memcpy_s((VOID*)&pUlNetFactorApp[AC_WEIGHT_DATA_NUM_FOR_APP], sizeof(UINT32) * AC_WEIGHT_DATA_NUM, (VOID*)&pUlNetFactorSource[(uiChan + antNum)* AC_WEIGHT_DATA_NUM], sizeof(UINT32) * AC_WEIGHT_DATA_NUM);
    dbgInfo("%s>>antNum:Chnl'%d antTmp:'%d  Dupfactorapp= %d;pUlNetFactorSourceOrg:%d\n",
       __FUNCTION__, uiChan,antTmp,pUlNetFactorApp[(antTmp +1) * AC_WEIGHT_DATA_NUM_FOR_APP],pUlNetFactorSource[(uiChan + antNum)* AC_WEIGHT_FOR_APP_ARR]);
    
    pUlNetFactorApp[AC_WEIGHT_DATA_NUM_FOR_APP + (uiValidFreNum - 1)] = pUlNetFactorSource[(uiChan + antNum)* AC_WEIGHT_FOR_APP_ARR + uiValidFreNum -2];
    dbgInfo("%s>>antNum:Chnl'%d antTmp:'%d  DupFactorapp = %d;pUlNetFactorSourceOrg:%d;\n",
       __FUNCTION__, uiChan,antTmp,pUlNetFactorApp[AC_WEIGHT_DATA_NUM_FOR_APP + (uiValidFreNum - 1)],pUlNetFactorSource[(uiChan + antNum)* AC_WEIGHT_FOR_APP_ARR + uiValidFreNum-2]);
    *pvalidFreNum = uiValidFreNum;
    return BSP_OK;
}

UINT32 BspGetChanCoupleNetFactor(UINT32* ptInfo,UINT32 Carryno)
{
    UINT32 dir                      = 0;
    UINT32 data[AC_WEIGHT_DATA_NUM] = {0};
    UINT16 uwACType                 = 0;
    UINT32 chanEnd                  = 0;
    UINT32 chan                     = 0;
    INPUT_POINTER_CHECK(ptInfo);

    uwACType = RX;
    /*OAM 0下行1上行*/
    dir = BspGetOamAcType(uwACType);

    if(AC_NETMODE_DUP == BspGetAcNetMode())
    {
        chanEnd = BspGetDupTxChannel();
    }
    else
    {
        chanEnd = BspGetTxChannel();
    }
    dbgInfo("%s chanEnd:%d\n", __FUNCTION__,chanEnd);
    
    for (chan = 0; chan < chanEnd; chan++)
    {
        BspGetCoupleNetFactor(chan, Carryno, dir, &data[0]);
        zte_memcpy_s((VOID *)&ptInfo[chan * AC_WEIGHT_DATA_NUM], sizeof(UINT32) * AC_WEIGHT_DATA_NUM, (VOID *)data, sizeof(UINT32) * AC_WEIGHT_DATA_NUM);
        dbgInfo("%s chan:%d,Factor=%d\n", __FUNCTION__,chan,ptInfo[chan * AC_WEIGHT_DATA_NUM]);
    }

    return BSP_OK;
}


UINT32 BspGetULCoupleNetFactor(UINT32 carryno, UINT16 channelId, UINT16* pvalidFreNum, UINT32 *pBridegPara)
{
    UINT32 dir            = 0;
    UINT32 uiFrecolum     = 0;
    UINT32 uiColum        = 0;
    UINT32 uiNum          = 0;
    UINT32 uiRet            = 0;
    uiNum = AC_WEIGHT_DATA_NUM_FOR_APP * COUPNET_APP_LIST;
    dbgInfoEx("%s uiNum:%d,carryno:%d\n", __FUNCTION__,uiNum,carryno);

    INPUT_POINTER_CHECK(pvalidFreNum);
    INPUT_POINTER_CHECK(pBridegPara);

    BspSetAcNetMode(1);
    BspGetChanCoupleNetFactor(g_aiCoupNetOrg, carryno);
    
    uiRet = BspGetCoupNetPostPro(g_aiCoupNetApp,g_aiCoupNetOrg,channelId,pvalidFreNum,carryno);
    RETURN_RESULT_CHECK(uiRet);

    for (uiColum = 0; uiColum < (COUPNET_APP_LIST-1); uiColum++)
    {
        for (uiFrecolum = 0; uiFrecolum < (AC_WEIGHT_DATA_NUM_FOR_APP -1); uiFrecolum++)
        {
            dbgInfoEx("%s chan:%x,FactorApp=%x\n", __FUNCTION__,channelId,g_aiCoupNetApp[uiColum*AC_WEIGHT_DATA_NUM_FOR_APP+uiFrecolum]);
            if(1 < uiColum)
            {
                dbgInfoEx("%s chan:%x,Factor=%x\n", __FUNCTION__,channelId,g_aiCoupNetOrg[(channelId+4)*AC_WEIGHT_DATA_NUM+uiFrecolum]);
            }
            else
            {
                dbgInfoEx("%s chan:%x,Factor=%x\n", __FUNCTION__,channelId,g_aiCoupNetOrg[channelId*AC_WEIGHT_DATA_NUM+uiFrecolum]);
            }
            
        }
    }

    *pvalidFreNum = BspGetFreqBw(dir, channelId, carryno)/1000;

    zte_memcpy_s((VOID*)&pBridegPara[0], sizeof(UINT32) * uiNum, (VOID*)&g_aiCoupNetApp[0], sizeof(UINT32) * uiNum);

    for (uiColum = 0; uiColum < (COUPNET_APP_LIST-1); uiColum++)
    {
        for (uiFrecolum = 0; uiFrecolum < AC_WEIGHT_DATA_NUM_FOR_APP; uiFrecolum++)
        {
            dbgInfoEx("%s bridegPara chan:%d,bridegPara=%d,Org=%d\n", __FUNCTION__,channelId,pBridegPara[uiColum*AC_WEIGHT_DATA_NUM_FOR_APP+uiFrecolum],g_aiCoupNetApp[uiColum*AC_WEIGHT_DATA_NUM_FOR_APP+uiFrecolum]);
        }
    }

    dbgInfo("%s chan:%d,Factor=%d,validFreNum:%d\n", __FUNCTION__,channelId,g_aiCoupNetApp[0],*pvalidFreNum);
    BspSetAcNetMode(0);
    return BSP_OK;
}

UINT32 BspSetWgtPostPro(UINT32* pDupCarryWgt,UINT32* pOriWgt,UINT32* pOrgCarryWgt,UINT32 uiDateLen,UINT32 uiAntBitmap)
{
    UINT32 antTemp = 0;
    UINT32 ant = 0;
    UINT32 antCount = 0;
    antTemp = BspGetTxChannel();

    INPUT_POINTER_CHECK(pOrgCarryWgt);
    INPUT_POINTER_CHECK(pOriWgt);

    dbgInfo("%s uiAntBitmap:%d\n", __FUNCTION__,uiAntBitmap);
    for(ant = 0; ant < antTemp; ant++)
    {
        if(((uiAntBitmap >> ant) & 1) == 1)
        {
            zte_memcpy_s((VOID*)&pOrgCarryWgt[antCount * uiDateLen], sizeof(UINT32) * uiDateLen, (VOID*)&pOriWgt[ant * uiDateLen], sizeof(UINT32) * uiDateLen);
            zte_memcpy_s((VOID*)&pDupCarryWgt[antCount * uiDateLen], sizeof(UINT32) * uiDateLen, (VOID*)&pOriWgt[(ant + antTemp)* uiDateLen], sizeof(UINT32) * uiDateLen);
            antCount ++;
            dbgInfo(" ant:%d, uiDateLen:%d,antCount:%d end\n",ant,uiDateLen,antCount);
        }
    }
    return BSP_OK;
}

UINT32 BspGetOamAcType(UINT32 uwACType)
{
    UINT32 dir = 0;
    if (8 == uwACType) //FDD AC下行
    {
        dir = TX;
    }
    else if (9 == uwACType) //FDD AC上行
    {
        dir = RX;
    }
    else
    {
        dir = (uwACType == 0)?(TX):(RX); //TDD AC
    }
    return dir;
}
/* Started by AICoder, pid:rc665272b6b2f6314b1b08d7803b5a2195b47510 */
UINT32 BspInitSendData(UINT32 uiAcType, UINT32 uiCarrNo, T_DpdMsgSendAcData_NEW_IC4 *ptSendData)
{
    UINT16 uiDataLen = UDPMSG_HTONS((UINT16)4114);
    UINT8 ucIcId     = (UINT8)BspGetRpuId();
    UINT32 i         = 0;

    INPUT_POINTER_CHECK(ptSendData);
    zte_memset_s(ptSendData, sizeof(T_DpdMsgSendAcData_NEW_IC4), 0, sizeof(T_DpdMsgSendAcData_NEW_IC4));
    for(i = 0;i < AC_UDP_MAX_PACK;i++)
    {
        ptSendData->stDa[i].uwDataLen = uiDataLen;
        ptSendData->stDa[i].ucCeLLId = (UINT8)uiCarrNo;
        ptSendData->stDa[i].ucAcType = (UINT8)uiAcType;
        ptSendData->stDa[i].uwAntNo = 0;
        ptSendData->stDa[i].ucDpdIcId = ucIcId;
        
    }
    if((E_AC_TYPE_UL == uiAcType) || (E_AC_TYPE_FDD_UL == uiAcType))
    {
        //计数器，记录总的历史校正次数
        SendHaulBackAcSeqIcUlAcCnt++;
    }
    for(i = 0;i < AC_UDP_MAX_PACK;i++)
    {
        ptSendData->stDa[i].iCrc = SendHaulBackAcSeqIcUlAcCnt;
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:rc665272b6b2f6314b1b08d7803b5a2195b47510 */
/* Started by AICoder, pid:d1f2cge4120d20814c1f0bf5d0db098e7b994130 */
UINT32 BspGetVgaData(UINT32 *pSendNum, T_AcRetryInfo *ptAcRetryInfo, T_AcCarrInfo *ptAcCarrInfo, T_DpdMsgSendAcData_NEW_IC4 *ptSendData)
{
    UINT8* pcBaseAddr     = 0;
    UINT32 uiAntNo        = 0;
    UINT32 uiRpuId        = 0;
    UINT32 uiBandNo       = 0;
    UINT32 uiBspChn       = 0;
    UINT32 difChipId      = 0;
    UINT32 uiDifChn       = 0;
    UINT32 uiAcType       = 0;
    UINT32 uiCarrNo       = 0;
    UINT32 uiRadioMode    = 0;
    UINT32 uiRet          = 0;
    UINT32 uiRetry        = 0;
    UINT32 uiRound        = 0;
    UINT32 uiRoundTime    = 0;
    INT32 iPreAtt         = 0;
    INT32 iVgaPreAtt      = 0;
    INT32 iVgaValue       = 0;
    INT32 iVgaValueAdj    = 0;
    INT32 iAcDspNcoValid  = 0;
    INT32 iAcDspNco       = 0;
    INT32 iAcDspNcoAdj    = 0;
    UINT32 uiSendAcRpuId  = 0;
    UINT32 uiCatchAcRpuId = 0;
    UlAcVgaData *ptVgaData   = NULL;
    T_ICHAL_ACPARA *ptAcPara = NULL;
    A53R8AcDebugShareInfo* shareInfo = NULL;

    INPUT_POINTER_CHECK(pSendNum);
    INPUT_POINTER_CHECK(ptAcRetryInfo);
    INPUT_POINTER_CHECK(ptAcCarrInfo);
    INPUT_POINTER_CHECK(ptSendData);

    pcBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);
    ptVgaData  = (UlAcVgaData *)((VOID *)(pcBaseAddr + IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET));
    shareInfo  = (A53R8AcDebugShareInfo*)((VOID *)(pcBaseAddr + IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET));
    ptAcPara   = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(ptAcPara);

    uiSendAcRpuId  = shareInfo->sendAcRpuId;
    uiCatchAcRpuId = shareInfo->catchAcRpuId;

    uiAcType = BspJudgeAcType(ptAcCarrInfo->acType);
    uiCarrNo = ptAcCarrInfo->carrNo;
    uiRadioMode = ptAcCarrInfo->radioMode;

    uiRetry = ptAcRetryInfo->retry;
    uiRound = ptAcRetryInfo->round;
    uiRoundTime = ptAcRetryInfo->roundTime;
    uiRpuId  = BspGetRpuId();

    if(((E_AC_TYPE_FDD_UL == ptAcCarrInfo->acType) && (uiRpuId == uiSendAcRpuId)) ||
      ((E_AC_TYPE_FDD_DL == ptAcCarrInfo->acType) && (uiRpuId == uiCatchAcRpuId)))
    {
        iAcDspNcoValid = 0x80000000;
        iAcDspNco = ptAcPara->pGetAcDspNco();
        iAcDspNcoAdj = ((iAcDspNco<<16) & 0x7fff0000);
    }

    if(E_AC_TYPE_UL == uiAcType)//上行AC
    {
        uiAntNo = BspGetAntNoByRoundInfo(uiRpuId, uiRound);
        dbgInfoEx("[%s] antNoTmp:%d\n", __FUNCTION__, uiAntNo);
        if(AC_ANT_NUM_INVALID == uiAntNo)
        {
            dbgInfoEx("[%s] UL round:%d is not set\n", __FUNCTION__, uiRound);
            return BSP_ERROR;
        }
        uiRet = BspCheckJacBitMap(uiAntNo);
        RETURN_RESULT_CHECK_AC(uiRet);
        *pSendNum = *pSendNum % AC_UDP_MAX_PACK;
        //获取中频通道号
        ptSendData->stDa[*pSendNum].uwAntNo = UDPMSG_HTONS((UINT16)uiAntNo);
        uiAntNo = MIN(uiAntNo, AC_UL_ANTS_NUM);
        uiAntNo = uiAntNo + 1; //对应map表中的天线号列，需要加1
        uiRet = BspGetBspChanByAntAndBandInfo(uiAntNo, uiBandNo, RX, &uiBspChn);
        RETURN_RESULT_CHECK_AC(uiRet);
        uiRet = BspGetDifInfoByBspChn(uiBspChn, RX, &difChipId, &uiDifChn);
        RETURN_RESULT_CHECK_AC(uiRet);
        dbgInfoEx("[%s] uiDifChn:%d, uiBspChn:%d \n", __FUNCTION__, uiDifChn, uiBspChn);
        uiRet = IcHalApiGetRxPcGain(uiDifChn, uiRadioMode, uiCarrNo, &iPreAtt);//iPreAtt获取到的值单位是0.01db
        RETURN_RESULT_CHECK_AC(uiRet);
        if(BSP_OK == IcHalApiGetRxVgaGain(uiDifChn, uiRadioMode, uiCarrNo, &iVgaPreAtt))
        {
            iVgaValue = (INT32)(ptVgaData->vga[uiRetry][uiRound]*5 + (iPreAtt/10) + (iVgaPreAtt/10)); //iScale即ATT单位是0.1dB
            iVgaValueAdj = iVgaValue & 0x0000ffff;
            AcFuncLogS(AC_FUNC_LOG_HIGH, "DataSend retry:%d, ant:%d, pcGain:%d, vgaGain:%d, slicer:%d, vgaGainFinal:%d \n",
                                         uiRetry, uiRound, iPreAtt, iVgaPreAtt, ptVgaData->vga[uiRetry][uiRound], iVgaValue);
            dbgInfoEx("[%s]Agc Retry %2d,acType %d, Ant%2d, Carr%d, radioMode 0x%08X, iPreAtt %d, iVgaPreAtt %d, iVgaValue %d, vga:%d\n",
             __FUNCTION__, uiRetry, uiAcType, uiRound, uiCarrNo, uiRadioMode, iPreAtt, iVgaPreAtt, iVgaValue, ptVgaData->vga[uiRetry][uiRound]);
        }
        else
        {
            dbgErr("[%s]get vga comp error!\n", __FUNCTION__);
            return BSP_ERROR;
        }
    }
    else if(E_AC_TYPE_DL == uiAcType)
    {
        *pSendNum = (uiRetry * uiRoundTime + uiRound) % AC_UDP_MAX_PACK;
    }
    else
    {
        dbgErr("[%s] unknow ac type:%d \n", __FUNCTION__, uiAcType);
        return BSP_ERROR;
    }
    dbgInfoEx("sendData->stDa[%d].uwAntNo = %d, difChn=%d\n", *pSendNum, ptSendData->stDa[*pSendNum].uwAntNo, uiDifChn);
    ptSendData->stDa[*pSendNum].iScale        = (iVgaValueAdj | iAcDspNcoAdj | iAcDspNcoValid);
    ptSendData->stDa[*pSendNum].ucIterationNo = uiRetry; //迭代次数
    ptSendData->stDa[*pSendNum].ucGroupNo     = uiRound; //组号，下行：0-8

    return BSP_OK;
}
/* Ended by AICoder, pid:d1f2cge4120d20814c1f0bf5d0db098e7b994130 */
/* Started by AICoder, pid:me8b7tfbf3pb3cd14bae0987f03bc85986a43f6c */
UINT32 BspSetSendData(UINT32 uiAcType, UINT32 uiDataLen, UINT32 *pSendNum, T_AcRetryInfo *ptAcRetryInfo, T_DpdMsgSendAcData_NEW_IC4 *ptSendData)
{
    UINT32 uiPoint   = 0;
    UINT8  *pcBaseAddr = 0;
    UINT32 *pDlMemInfo = NULL;
    UINT32 *pUlMemInfo = NULL;
    UINT32 uiRound   = 0;
    UINT32 uiRoundTime = 0;
    UINT32 uiRetry   = 0;

    pcBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);
    pDlMemInfo = (UINT32*)((VOID *)(pcBaseAddr + IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET));
    pUlMemInfo = (UINT32*)((VOID *)(pcBaseAddr + IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET));

    uiRetry = ptAcRetryInfo->retry;
    uiRound = ptAcRetryInfo->round;
    uiRoundTime = ptAcRetryInfo->roundTime;

    for(uiPoint = 0; uiPoint < uiDataLen; uiPoint++)
    {
        if((AC_UDP_MAX_PACK <= *pSendNum) || (IC_AC_POINT_NUM <= uiPoint))
        {
            dbgErr("[%s] out of range, sendNum:%d, point:%d\n", __FUNCTION__, *pSendNum, uiPoint);
            return BSP_ERROR;
        }
        if(E_AC_TYPE_DL == uiAcType)
        {
            ptSendData->stDa[*pSendNum].ComplexData[uiPoint].real = (UINT16)(*(pDlMemInfo + (IC_AC_POINT_NUM * uiRetry * uiRoundTime) +
                                                                    uiPoint) >> 16) & 0xFFFF;
            ptSendData->stDa[*pSendNum].ComplexData[uiPoint].imag = (UINT16)(*(pDlMemInfo + (IC_AC_POINT_NUM * uiRetry * uiRoundTime) +
                                                                    uiPoint) >> 0) & 0xFFFF;
        }
        else
        {
            ptSendData->stDa[*pSendNum].ComplexData[uiPoint].real = (UINT16)(*(pUlMemInfo + (IC_AC_POINT_NUM * uiRound) +
                                                                    (IC_AC_POINT_NUM * uiRetry * uiRoundTime) + uiPoint) >> 16) & 0xFFFF;
            ptSendData->stDa[*pSendNum].ComplexData[uiPoint].imag = (UINT16)(*(pUlMemInfo + (IC_AC_POINT_NUM * uiRound) +
                                                                    (IC_AC_POINT_NUM * uiRetry * uiRoundTime) + uiPoint) >> 0) & 0xFFFF;
        }
        dbgInfoEx("[%s]retry %2d, round %2d point %4d real 0x%04x, imag 0x%04x\n", \
                __FUNCTION__, uiRetry, uiRound, uiPoint, ptSendData->stDa[*pSendNum].ComplexData[uiPoint].real, ptSendData->stDa[*pSendNum].ComplexData[uiPoint].imag);
    }
    dbgInfoEx("[%s]retry %2d, round %2d, sendnum %2d, real 0x%04x, imag 0x%04x\n", \
             __FUNCTION__, uiRetry, uiRound, *pSendNum, ptSendData->stDa[*pSendNum].ComplexData[0].real, ptSendData->stDa[*pSendNum].ComplexData[0].imag);

    AcFuncLogS(AC_FUNC_LOG_HIGH, "DataSend retry:%d, round:%d, real:0x%04x, imag:0x%04x \n",
                                 uiRetry, uiRound, ptSendData->stDa[*pSendNum].ComplexData[0].real, ptSendData->stDa[*pSendNum].ComplexData[0].imag);
    return BSP_OK;
}
/* Ended by AICoder, pid:me8b7tfbf3pb3cd14bae0987f03bc85986a43f6c */
/* Started by AICoder, pid:87210661f1tc48f141e50a86d110ee0c34a71417 */
UINT32 SendDspAcDataMultiIc(T_AcDataPara *ptAcDataPara)
{
    UINT32             uiDataLen = 0;
    UINT32               uiRetry = 0;
    UINT32               uiRound = 0;
    UINT32             roundTime = 0;
    UINT32                uiRet  = 0;
    UINT32              uiErrCnt = 0;
    UINT32             uiSendNum = 0;
    UINT32              totalNum = 0;
    UINT32              uiAcType = 0;
    UINT32        uiCatchAcRpuId = 0;
    UINT32               uiRpuId = 0;
    UINT32           uiRetryTime = 0;
    UINT8*            pcBaseAddr = 0;
    T_AcParaInfo     tAcParaInfo = {0};
    T_AcCarrInfo     tAcCarrInfo = {0};
    T_AcRetryInfo   tAcRetryInfo = {0};
    T_ICHAL_ACPARA       *ptAcPara          = NULL;
    A53R8AcDebugShareInfo *ptShareInfo      = NULL;
    T_DpdMsgSendAcData_NEW_IC4 *ptSendData  = NULL;
    UINT32 uiRealAcType          = 0;
    UINT32 uiCarrNo              = 0;
    UINT32 uiPasteCarrFlag       = 0;
    UINT32 uiBandWidth           = 0;
    UINT32 uiRadioMode           = 0;

    INPUT_POINTER_CHECK(ptAcDataPara);
    recordSendHaulBackAcCnt();

    uiRealAcType    = ptAcDataPara->uiAcType;
    uiCarrNo        = ptAcDataPara->uiCarrNo;
    uiPasteCarrFlag = ptAcDataPara->uiPasteCarrFlag;
    uiBandWidth     = ptAcDataPara->uiBandWidth;
    uiRadioMode     = ptAcDataPara->uiRadioMode;

    
    dbgInfoEx("acType:%d, carrNo:%d, pasteCarrFlag:%d, bandWidth:%d, radioMode:%d\n",\
              uiRealAcType, uiCarrNo, uiPasteCarrFlag, uiBandWidth, uiRadioMode);
    dbgInfo("[%s] IC real FrameNo:%d\n", __FUNCTION__, IcHalGetFrameNo());

    uiAcType = BspJudgeAcType(uiRealAcType);
    uiRpuId = BspGetRpuId();

    ptAcPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(ptAcPara);
    pcBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);

    ptShareInfo = (A53R8AcDebugShareInfo*)((VOID *)(pcBaseAddr + IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET));
    uiCatchAcRpuId = ptShareInfo->catchAcRpuId;
    getAcInfo(uiAcType, uiCarrNo, uiRadioMode);
    if((uiAcType == E_AC_TYPE_DL) && (uiCatchAcRpuId != uiRpuId))
    {
        dbgInfo("[%s] catch ant is not on this chip\n ", __FUNCTION__);
        return BSP_OK;
    }

    tAcCarrInfo.acType    = uiRealAcType;
    tAcCarrInfo.bandWidth = uiBandWidth;
    tAcCarrInfo.carrNo    = uiCarrNo;
    tAcCarrInfo.radioMode = uiRadioMode;

    uiRet = GetDmaState(uiRealAcType, ptShareInfo);
    RETURN_RESULT_CHECK_AC(uiRet);
    uiRet = BspGetAcParaInfo(uiRadioMode, uiPasteCarrFlag, uiBandWidth, &tAcParaInfo);
    RETURN_RESULT_CHECK_AC(uiRet);

    uiDataLen = tAcParaInfo.acSeqLen;
    uiRet = GetRetryPara(uiRealAcType, ptAcPara, &uiRetryTime, &roundTime);
    RETURN_RESULT_CHECK(uiRet);
    dbgInfo("[%s] uiRetryTime:%d, roundTime:%d\n", __FUNCTION__, uiRetryTime, roundTime);

    ptSendData = (T_DpdMsgSendAcData_NEW_IC4*)malloc(sizeof(T_DpdMsgSendAcData_NEW_IC4));
    INPUT_POINTER_CHECK(ptSendData);

    uiRet = BspInitSendData(uiRealAcType, uiCarrNo, ptSendData);
    RETURN_RESULT_CHECK_AC(uiRet);

    for(uiRetry = 0; uiRetry < uiRetryTime; uiRetry++)
    {
        for(uiRound = 0; uiRound < roundTime; uiRound++)
        {
            tAcRetryInfo.retry = uiRetry;
            tAcRetryInfo.retryTime = uiRetryTime;
            tAcRetryInfo.round = uiRound;
            tAcRetryInfo.roundTime = roundTime;
            uiRet = BspGetVgaData(&uiSendNum, &tAcRetryInfo, &tAcCarrInfo, ptSendData);
            RESULT_CHECK_CONTINUE_AC(uiRet);
            uiRet = BspSetSendData(uiRealAcType, uiDataLen, &uiSendNum, &tAcRetryInfo, ptSendData);
            RESULT_CHECK_CONTINUE_AC(uiRet);
            if((((uiRpuId == uiCatchAcRpuId) && (E_AC_TYPE_DL == uiAcType)) || (E_AC_TYPE_UL == uiAcType)) && ((uiSendNum % AC_UDP_MAX_PACK == AC_UDP_SEND_PACK)
              ||(uiRetry * roundTime + uiRound == (roundTime * uiRetryTime - 1))))
            {
                uiErrCnt |= (uiRet = BspSendHaulBackAcDataIc4(ptSendData, uiRealAcType));
                recordToDspPackets(uiAcType, uiRet);
                totalNum++;
                dbgInfoEx("[%s]retryA %2d,roundTime %2d, roundA %2d, sendnumA %2d, realA 0x%04x, imagA 0x%04x\n", \
                          __FUNCTION__, uiRetry, roundTime, uiRound, uiSendNum, ptSendData->stDa[uiSendNum].ComplexData[0].real, ptSendData->stDa[uiSendNum].ComplexData[0].imag);
            }
            dbgInfoEx("[%s]AcType %d:retry %2d, round %2d, result 0x%08X\n", __FUNCTION__, uiRealAcType, uiRetry, uiRound, uiRet);
            if(E_AC_TYPE_UL == uiAcType)
            {
                dbgInfoEx("[%s] UL sendNum++ \n", __FUNCTION__);
                uiSendNum++;
            }
        }
    }
    dbgInfo("\n----------------total udp send num = %d\n",totalNum);
    free(ptSendData);

    dbgInfo("[%s]AcType %d, Send Finished, with retVal 0x%08X\n", __FUNCTION__, uiRealAcType, uiErrCnt);

    return uiErrCnt;
}
/* Ended by AICoder, pid:87210661f1tc48f141e50a86d110ee0c34a71417 */
/* Started by AICoder, pid:d8427ka94epcfe3142ff0a6fe0285419b1b0a720 */
UINT32 BspDebugPrnSeq(UINT32 *pSeq, UINT32 uiSeqLen)
{
    UINT32 uiLoop = 0;

    INPUT_POINTER_CHECK(pSeq);
    for (uiLoop = 0; uiLoop < (uiSeqLen / 4); uiLoop++)
    {
        dbgInfoEx("[%d] Seq = 0x%08x \n", uiLoop, pSeq[uiLoop]);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:d8427ka94epcfe3142ff0a6fe0285419b1b0a720 */
/* Started by AICoder, pid:dbfb8nb1a4992a8141600ad2e01072574be16986 */
UINT32 GetAcSeqMultiIc(UINT32 uiSocId, UINT32 uiAcType, UINT32 *pSeq, UINT32 *pSeqLen)
{
    UINT8  *pcSeqAddr   = NULL;
    UINT8  *pcBaseAddr  = NULL;
    UINT8  *pcSeqTmp    = NULL;
    UINT32 uiSeqSize    = 0;
    UINT32 uiRfChn      = 0;
    UINT32 uiOffsetAddr = 0;
    UINT32 uiChipNo     = 0;
    UINT32 uiDifChan    = 0;
    UINT32 uiAntNo      = 0;
    UINT32 uiAntChn     = 0;
    UINT32 uiDir        = 0;
    UINT32 uiRet        = 0;

    
    dbgInfoEx("uiSocId:%d, uiAcType:%d \n", uiSocId, uiAcType);
    INPUT_POINTER_CHECK(pSeq);
    INPUT_POINTER_CHECK(pSeqLen);

    pcSeqTmp = (UINT8 *)((VOID *)pSeq);
    pcBaseAddr = BspGetAcDspMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);
    pcSeqAddr = NXP_AC_MEM_CPU_RD_AC_SEQ_ADDR + pcBaseAddr;
    uiDir = (E_AC_TYPE_DL == uiAcType) ? TX : RX;

    //序列拷贝
    for (uiRfChn = 0; uiRfChn < BspGetAntNum(); uiRfChn++)
    {
        uiRet = BspGetDifInfoByRfChn(uiRfChn, uiDir, &uiChipNo, &uiDifChan);
        RETURN_RESULT_CHECK_AC(uiRet);
        dbgInfoEx("BspGetDifInfoByRfChn chan = %d, uiChipNo = %d, uiDifChan = %d, socId = %d \n", uiRfChn, uiChipNo, uiDifChan, uiSocId);
        INPUT_COMPARE_CONTINUE_AC(uiSocId, uiChipNo);

        uiRet = BspGetAntInfoByRfChn(uiRfChn, uiDir, &uiAntNo, &uiAntChn);
        RETURN_RESULT_CHECK_AC(uiRet);

        HAL_INPUT_NUMBER_OF_THRESHOLD_MIN_CHECK(uiAntNo,0);
        
        uiAntNo = uiAntNo -1; //主控link表定义中的天线号为控制面天线号,从1开始，这里必须-1;
        dbgInfoEx("BspGetAntInfoByRfChn chan = %d, antNo = %d, antChn = %d,socId = %d\n", uiRfChn, uiAntNo, uiAntChn, uiSocId);

        uiOffsetAddr = uiAntNo * NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
        memcpy_s((UINT8*)pcSeqTmp, NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024, (UINT8*)(pcSeqAddr + uiOffsetAddr), NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024);
        pcSeqTmp += NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
        uiSeqSize += NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
        dbgInfoEx("seqTmp:%p, sourceAddr:%p, seqSize:%d \n", (void*)pcSeqTmp, (void*)(pcSeqAddr + uiOffsetAddr), uiSeqSize);
    }
    *pSeqLen = uiSeqSize;
    uiRet = BspDebugPrnSeq(pSeq, uiSeqSize);
    RETURN_RESULT_CHECK_AC(uiRet);
    AcFuncLogM(AC_FUNC_LOG_HIGH, "SeqGet socId:%d, acType:%d, seqLen:%d \n", uiSocId, uiAcType, *pSeqLen);
    dbgInfo("[%s]baseAddr %p, seqAddr %p, seqSize %d \n", __FUNCTION__, (void*)pcBaseAddr, (void*)pcSeqAddr, uiSeqSize);
    

    return BSP_OK;
}
/* Ended by AICoder, pid:dbfb8nb1a4992a8141600ad2e01072574be16986 */

/* Started by AICoder, pid:d711a371fah136e1404f092c43cabe1f07316204 */
/**
 ******************************************************************************
 * SetVswrPara
 * 配置驻波参数
 * @param[in]   acType    AC类型
 * @return      BSP_OK/BSP_ERROR
 * @author      晏珠峰10307430
 * @date        2024/11/13
 ******************************************************************************
*/
UINT32 SetVswrPara(UINT32 acType)
{
    UINT32 uiRet = 0;
    UINT32 uiBoardFlag = 0; //单板标志，RCUA为1，其余为0
    UINT32 uiCatchDataChan = 0; //AC采数通道
    UINT32 uiSeqNum = 0; //支持6段序列配置,AC默认用第0段
    UINT32 uiISeqGain = 0x400;//0x400代表无增益也无衰减 [31]正负号,[30:27]整数位, [26:16]小数位，需要算法给出
    UINT32 uiQSeqGain = 0;//Q路数据增益
    
    T_ICHAL_ACPARA* acPara = NULL;
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);
    uiBoardFlag = acPara->RcuaBoardFlag;    //uiBoardFlag在RCUA单板侧的AC参数初始化中已设为1
    A53R8AcDebugShareInfo* a53R8ShareInfo = NULL;
    UINT8 *pucBaseAddr = NULL;
    dbgInfo("%s line[%u] uiBoardFlag = %u\n", __FUNCTION__, __LINE__, uiBoardFlag);
    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    a53R8ShareInfo = (A53R8AcDebugShareInfo*)((VOID *)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr));
    if((1 == uiBoardFlag))
    {
        dbgInfo("%s line[%u] acType = %u\n", __FUNCTION__, __LINE__, acType);
        /* 检REV */
        if(AC_TYPE_FDD_UL == acType)
        {
            uiRet = IcHalApiSetAccbRssiEn(0, uiCatchDataChan, 1);
            RETURN_RESULT_CHECK(uiRet);
            a53R8ShareInfo->acVswrFlag = VSWR_TYPE_REV;
            INPUT_POINTER_CHECK(acPara->pSetAcTddRfSwitch);
            acPara->pSetAcTddRfSwitch(VSWR_TYPE_REV);//切REV开关
        }
        else if(AC_TYPE_STOP == acType)
        {
            uiRet = IcHalApiSetAccbRssiEn(0, uiCatchDataChan, 0);
            RETURN_RESULT_CHECK(uiRet);
            uiRet = IcHalApiSetAcGainICa(0, uiCatchDataChan, uiSeqNum, uiISeqGain);
            RETURN_RESULT_CHECK(uiRet);
            uiRet = IcHalApiSetAcGainQCa(0, uiCatchDataChan, uiSeqNum, uiQSeqGain);
            RETURN_RESULT_CHECK(uiRet);
        }
        else
        {
            //do nothing
        }
    }
    return BSP_OK;
}

/**
 ******************************************************************************
 * GetVswrData
 * 将驻波检测结果从共享内存中搬到A53侧的全局变量中
 * @param[in]   acType    AC类型
 * @return      BSP_OK/BSP_ERROR
 * @author      晏珠峰10307430
 * @date        2024/11/13
 ******************************************************************************
*/
UINT32 GetVswrData(UINT32 acType)
{
    UINT32 uiAcType       = 0;
    UINT32 uiCalPort      = 0;
    UINT32 uiFreq         = 0;
    UINT32 uiChanId       = 0;  //RCUA只检测通道0
    UINT32 uiBoardFlag    = 0;
    INT32 iFwdVal         = 0;
    INT32 iRevVal         = 0;
    UINT32 uiRet          = 0;
    UINT32 *puiFwdMemInfo = NULL;
    UINT32 *puiRevMemInfo = NULL;
    
    T_ICHAL_ACPARA* acPara = NULL;
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);
    uiBoardFlag = acPara->RcuaBoardFlag;    //uiBoardFlag在RCUA单板侧的AC参数初始化中已设为1
    dbgInfo("%s line[%u] uiBoardFlag = %u\n", __FUNCTION__, __LINE__, uiBoardFlag);
    if((1 == uiBoardFlag))
    {
        UINT8 *pucBaseAddr = NULL;
        if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
        {
            dbgErr("%s get baseAddr error \n",__FUNCTION__);
            return BSP_ERROR;
        }
        uiAcType = BspJudgeAcType(acType);
        dbgInfo("%s line[%u] acType[%u] uiAcType[%u]\n", __FUNCTION__, __LINE__, acType, uiAcType);
        //查询发数、采数、DMA搬数是否完成
        if((acType == E_AC_TYPE_STOP) && (1 == g_uiSetVswrValFlag))//仅在FWD-->结束AC场景取功率，而在下行AC-->结束AC 场景不取功率
        {
            uiCalPort = GetCalRoute(); //获取CAL口
            INPUT_POINTER_CHECK(acPara->pBspGetRfIoIndex);
            uiFreq = acPara->pBspGetRfIoIndex(acType); //获取频段号
            dbgInfo("%s line[%u] uiFreq[%u]\n", __FUNCTION__, __LINE__, uiFreq);
            HAL_INPUT_NUMBER_OF_THRESHOLD_MIN_CHECK(uiFreq , 3);//下面要对频段号-4，因此Freq≤3时报错
            uiFreq -= BSP_RF_FREQ1_NUM;//将获取的到的频段号转换成0~4
            HAL_INPUT_NUMBER_OF_THRESHOLD_MIN_CHECK(uiCalPort , 0);//下面要对uiCalPort-1，因此uiCalPort≤0时报错
            uiCalPort -= 1; //软件保存功率的CAL口从0开始计
            HAL_INPUT_NUMBER_OF_THRESHOLD_MAX_CHECK(uiCalPort, RCUA_MAX_CAL_PORT_NUM -1);//uiCalPort≤2
            HAL_INPUT_NUMBER_OF_THRESHOLD_MAX_CHECK(uiFreq, RCUA_MAX_FREQ_NUM -1);//uiFreq≤4

            puiFwdMemInfo = (UINT32*)((VOID *)(pucBaseAddr + IC_AC_SHARE_MEM_OUT_VSWR_FWD_ADDR0_OFFSET));
            puiRevMemInfo = (UINT32*)((VOID *)(pucBaseAddr + IC_AC_SHARE_MEM_OUT_VSWR_REV_ADDR0_OFFSET));
            g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiFwdBasicInfo = (UINT32)(*(puiFwdMemInfo + uiChanId * 4));
            g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiFwdValue = (UINT32)(*(puiFwdMemInfo + uiChanId * 4 + 1));
            dbgInfo("[%s] ,Cal[%u],Freq[%u],puiFwdMemInfo[%p],FwdBasicInfo[0x%x],FwdVal[%u]\n",
            __FUNCTION__, uiCalPort, uiFreq, (void*)puiFwdMemInfo, g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiFwdBasicInfo, \
            g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiFwdValue);

            g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiRevBasicInfo = (UINT32)(*(puiRevMemInfo + uiChanId * 4));
            g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiRevValue = (UINT32)(*(puiRevMemInfo + uiChanId * 4 + 1));
            dbgInfo("[%s] ,Cal[%u],Freq[%u],puiRevMemInfo[%p], RevBasicInfo[0x%x],RevVal[%u]\n",
            __FUNCTION__, uiCalPort, uiFreq, (void*)puiRevMemInfo,g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiRevBasicInfo, \
            g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiRevValue);
            uiRet = BspConvertRegToDbfs(uiCalPort, uiFreq, &iFwdVal, &iRevVal);/* 将线性值转换成dbfs */
            uiRet |= BspSetVswrDetectValue(uiCalPort, uiFreq, iFwdVal, iRevVal);/* 将功率配给bsp */
            g_uiSetVswrValFlag = VSWR_INVAILD_FLAG;//恢复标志
            dbgInfo("%s line[%u] g_uiSetVswrValFlag = %u \n", __FUNCTION__, __LINE__, g_uiSetVswrValFlag);
            RETURN_RESULT_CHECK(uiRet);
        }
    }
    return BSP_OK;
}

/**
 ******************************************************************************
 * BspConvertRegToDbfs
 * 将线性值转换成dbfs
 * @param[in]   uiCalPort    Cal口
 * @param[in]   uiFreq       频段号
 * @param[out]  piFwdVal    fwd检测值
 * @param[out]  piRevVal    rev检测值
 * @return      BSP_OK/BSP_ERROR
 * @author      晏珠峰10307430
 * @date        2024/11/30
 ******************************************************************************
*/
UINT32 BspConvertRegToDbfs(UINT32 uiCalPort, UINT32 uiFreq, INT32 *piFwdVal, INT32 *piRevVal)
{
    UINT32 uiOriFwdBasicInfo = 0;//寄存器中的fwd检测时的基础信息
    UINT32 uiOriFwdVal       = 0;//寄存器中的fwd检测时的功率上报值
    UINT32 uiOriRevBasicInfo = 0;//寄存器中的rev检测时的基础信息
    UINT32 uiOriRevVal       = 0;//寄存器中的rev检测时的功率上报值
    UINT32 uiVgaFactor       = 0;
    DOUBLE dRssiData         = 0;
    DOUBLE dCatchDbfs        = 0;
    
    HAL_INPUT_POINTER_CHECK(piFwdVal);
    HAL_INPUT_POINTER_CHECK(piRevVal);
    HAL_INPUT_NUMBER_OF_THRESHOLD_MAX_CHECK(uiCalPort, RCUA_MAX_CAL_PORT_NUM - 1);
    HAL_INPUT_NUMBER_OF_THRESHOLD_MAX_CHECK(uiFreq, RCUA_MAX_FREQ_NUM - 1);
    
    /* FWD */
    uiOriFwdBasicInfo = g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiFwdBasicInfo;
    uiOriFwdVal = g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiFwdValue;
    uiVgaFactor = uiOriFwdBasicInfo & 0x7F;

    dRssiData = (DOUBLE)(10.0 * log10_s((DOUBLE)uiOriFwdVal, 0.0));
    dCatchDbfs = (DOUBLE)((dRssiData + uiVgaFactor) * 100.0);
    *piFwdVal = (INT32)((DOUBLE)(dCatchDbfs - DBFS_VALUE_16BIT));
    g_dCatchFwdDbfs = *piFwdVal;
    
    dbgInfo("Cal[%u] FreqId[%u] OriFwdBasicInfo = 0x%x, OriFwdVal = 0x%x, VgaFactor = %d, dRssiData = %.2lf, dCatchDbfs = %.2lf, g_dCatchFwdDbfs = %.2lf\n",
             uiCalPort, uiFreq, uiOriFwdBasicInfo, uiOriFwdVal, uiVgaFactor, dRssiData, dCatchDbfs, g_dCatchFwdDbfs);
    /* REV */
    uiOriRevBasicInfo = g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiRevBasicInfo;
    uiOriRevVal = g_atVswrDetectInfo[uiCalPort].atVswrFreqInfo[uiFreq].uiRevValue;
    uiVgaFactor = uiOriRevBasicInfo & 0x7F;

    dRssiData = (DOUBLE)(10.0 * log10_s((DOUBLE)uiOriRevVal, 0.0));
    dCatchDbfs = (DOUBLE)((dRssiData + uiVgaFactor) * 100.0);
    *piRevVal = (INT32)((DOUBLE)(dCatchDbfs - DBFS_VALUE_16BIT));
    g_dCatchRevDbfs = *piRevVal;

    dbgInfo("Cal[%u] FreqId[%u] OriRevBasicInfo = 0x%x, OriRevVal = 0x%x, VgaFactor = %d, dRssiData = %.2lf, dCatchDbfs = %.2lf, g_dCatchRevDbfs = %.2lf\n",
             uiCalPort, uiFreq, uiOriRevBasicInfo, uiOriRevVal, uiVgaFactor, dRssiData, dCatchDbfs, g_dCatchRevDbfs);
    return BSP_OK;
}

/**
 ******************************************************************************
 * showvswrval
 * 打印驻波值
 * @param[in]   uiCalPort    Cal口
 * @param[in]   uiFreq       频段号
 * @return      BSP_OK/BSP_ERROR
 * @author      晏珠峰10307430
 * @date        2024/11/30
 ******************************************************************************
*/
UINT32 showvswrval(UINT32 uiCalPort, UINT32 uiFreq)
{
    UINT32 uiRet  = 0;
    UINT32 uiCalLoopIdx = 0;
    UINT32 uiFreqLoopIdx = 0;
    INT32 iFwdVal = 0;
    INT32 iRevVal = 0;

    if(0xFF == uiCalPort)
    {
        for(uiCalLoopIdx = 0; uiCalLoopIdx < RCUA_MAX_CAL_PORT_NUM; uiCalLoopIdx++)
        {   
            for(uiFreqLoopIdx = 0; uiFreqLoopIdx < RCUA_MAX_FREQ_NUM; uiFreqLoopIdx++)
            {
                uiRet = BspConvertRegToDbfs(uiCalLoopIdx, uiFreqLoopIdx, &iFwdVal, &iRevVal);
                RETURN_RESULT_CHECK(uiRet);
            }
        }
    }
    else
    {
        uiRet = BspConvertRegToDbfs(uiCalPort, uiFreq, &iFwdVal, &iRevVal);
        RETURN_RESULT_CHECK(uiRet);
    }
    return BSP_OK;
}

/**
 ******************************************************************************
 * SetVswrFwdPara
 * 配置FWD检测参数
 * @param[in]   acType    
 * @return      BSP_OK/BSP_ERROR
 * @author      晏珠峰10307430
 * @date        2024/11/30
 ******************************************************************************
*/
UINT32 SetVswrFwdPara(UINT32 acType)
{
    UINT32 uiRet           = 0;
    UINT32 block           = 0;
    UINT32 uiRealFrNo      = 0;
    UINT32 uiFrameIdEn     = 1;
    UINT32 uiCalcDifChan   = 0;
    UINT32 uiFrNumAdjust   = g_uiFrNumAdjust;//帧号调整
    UINT32 uiStartFrameNo  = 0;
    UINT32 uiStopFrameNo   = 0;
    UINT32 uiAntNum        = 0;
    UINT32 uiIseqGain      = g_uiISeqGain;//0x400代表无增益也无衰减 [31]正负号,[30:27]整数位, [26:16]小数位
    UINT32 uiQseqGain      = g_uiQSeqGain;//0x400代表无增益也无衰减 [31]正负号,[30:27]整数位, [26:16]小数位

    /* 获取当前无线帧号 */
    uiRealFrNo = IcHalGetFrameNo();
    uiRealFrNo = (uiFrNumAdjust + uiRealFrNo) % (AC_MAX_FRAME_NO + 1);
    uiStartFrameNo = (uiRealFrNo + AC_MAX_FRAME_NO - 2) % (AC_MAX_FRAME_NO + 1);
    uiStopFrameNo = (uiRealFrNo + AC_MAX_FRAME_NO + 3) % (AC_MAX_FRAME_NO + 1);
    
    A53R8AcDebugShareInfo* shareInfo = NULL;
    UINT8 *pucBaseAddr = NULL;
    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    shareInfo = (A53R8AcDebugShareInfo*)((VOID *)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr));
    shareInfo->startframeNo = uiStartFrameNo;
    shareInfo->stopframeNo  = uiStopFrameNo;

    uiRet = IcHalApiSetAccbRssiEn(0, uiCalcDifChan, 1);
    RETURN_RESULT_CHECK(uiRet);
    shareInfo->acVswrFlag = acType;
    dbgInfo("%s line[%u] acType[%u] shareInfo->acVswrFlag[%u]\n", __FUNCTION__, __LINE__, acType, shareInfo->acVswrFlag);
    dbgInfo("RealFrNo_Prt %s line[%u] acType[%u] uiRealFrNo[%u] StartFrameNo[%u] StopFrameNo[%u]\n", __FUNCTION__, __LINE__, acType, uiRealFrNo, uiStartFrameNo,uiStopFrameNo);
    //无线帧号配置
    uiRet = IcHalSetDlbankFddFrameNo(uiFrameIdEn, uiRealFrNo, uiCalcDifChan);
    dbgInfo("%s line[%u] uiRealFrNo[%u] \n", __FUNCTION__, __LINE__, uiRealFrNo);
    RETURN_RESULT_CHECK(uiRet);
    uiRet = IcHalSetUlbankFddFrameNo(uiFrameIdEn, (uiRealFrNo + 1025) % 1024, uiCalcDifChan);
    RETURN_RESULT_CHECK(uiRet);
    dbgInfo("%s line[%u] ulbankFrameNo[%u] \n", __FUNCTION__, __LINE__, (uiRealFrNo + 1025) % 1024);
    /* 配置序列发射功率 */
    for(uiAntNum = 0; uiAntNum < ANT_NUM_PER_IC; uiAntNum++)
    {
        IcHalApiSetAcGainICa(block, uiAntNum, 0, uiIseqGain);
        IcHalApiSetAcGainQCa(block, uiAntNum, 0, uiQseqGain);
    }
    /* 切换开关8,使能FWD链路  */
    T_ICHAL_ACPARA* acPara = NULL;
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);
    INPUT_POINTER_CHECK(acPara->pSetAcTddRfSwitch);
    acPara->pSetAcTddRfSwitch(VSWR_TYPE_FWD);//切FWD开关
    
    g_uiSetVswrValFlag = VSWR_VAILD_FLAG;//做完fwd之后，将驻波完成标志置起。
    dbgInfo("%s line[%u] g_uiSetVswrValFlag = %u \n", __FUNCTION__, __LINE__, g_uiSetVswrValFlag);
    return BSP_OK;
}
     
/**
 ******************************************************************************
 * GetVswrCalFinishSta
 * 获取驻波完成标志
 * @param[out]   *puiCalSta    
 * @return      BSP_OK/BSP_ERROR
 * @author      晏珠峰10307430
 * @date        2024/11/30
 ******************************************************************************
*/
UINT32 GetVswrCalFinishSta(UINT32 *puiCalSta)
{
    INPUT_POINTER_CHECK(puiCalSta);
    UINT32 waitR8TimeCnt   = 0;
    UINT32 acType          = AC_TYPE_FDD_UL;
    UINT32 uiAcType        = 0;
    UINT32 VswrFinshFlag   = 0;
    UINT32 uiRealFrNo      = IcHalGetFrameNo();

    uiAcType = BspJudgeAcType(acType);
    dbgInfo("RealFrNo_Prt %s_IN line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);

    A53R8AcDebugShareInfo* shareInfo = NULL;
    UINT8 *pucBaseAddr = NULL;
    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    shareInfo = (A53R8AcDebugShareInfo*)((VOID *)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr));

    /* 采数完成，将完成标志清零并保存REV结果 */
    VswrFinshFlag = (0 == shareInfo->acVswrFinshFlag)?1:0;
    while((VswrFinshFlag)&&(waitR8TimeCnt < 3))
    {
        dbgInfo("%s line[%u] shareInfo->acVswrFinshFlag[%u] waitR8TimeCnt[%u]\n", __FUNCTION__, __LINE__, shareInfo->acVswrFinshFlag, waitR8TimeCnt);
        BspSysMsDelay(1000);
        waitR8TimeCnt++;
    }
    JudgeWaitR8TimeCnt(uiAcType,waitR8TimeCnt);
    recordWaitR8TimeCnt(uiAcType, waitR8TimeCnt);
    *puiCalSta = shareInfo->acVswrFinshFlag;
    shareInfo->acVswrFinshFlag = 0;
    
    if(checkWaitR8SmpOverTime(uiAcType,waitR8TimeCnt) != BSP_OK)
    {
        dbgErr("[%s] failed! R8 VswrSample for AC overtime!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    uiRealFrNo = IcHalGetFrameNo();
    dbgInfo("RealFrNo_Prt %s _OUT line[%u] uiRealFrNo[%u]\n", __FUNCTION__, __LINE__,uiRealFrNo);
    return BSP_OK;
}
/* Ended by AICoder, pid:d711a371fah136e1404f092c43cabe1f07316204 */

UINT32 SetFrAdjustId(UINT32 uiFrAdjust)
{
    g_uiFrNumAdjust = uiFrAdjust;
    dbgInfo("uiFrAdjust = %u", g_uiFrNumAdjust);
    return BSP_OK;
}

UINT32 SetSeqGain(UINT32 uiISeqGain,UINT32 uiQSeqGain)
{
    g_uiISeqGain = uiISeqGain;
    g_uiQSeqGain = uiQSeqGain;
    dbgInfo("uiISeqGain = 0x%x, uiQSeqGain = 0x%x", uiISeqGain,uiQSeqGain);
    return BSP_OK;
}

/* Started by AICoder, pid:p9e4e201384773314e810a92d78f5c1f75107ce8 */
UINT32 BspAacModeMapSelPsyncSw(UINT32 sw)
{
    UINT32 ulRet              = BSP_OK;
    UINT32 psyncGenInt2IntNo  = 239;
    UINT32 ulTimePeriod       = 10000000;   //10ms
    UINT32 ulTimeOffset       = 9924000;    //单位ns
    UINT32 ulInter            = 10000000;   //ns

    ulRet = HalIcPsyncTimGernXInit(psyncGenInt2IntNo, ulTimePeriod, ulTimeOffset, ulInter, sw);
    return ulRet;
}

UINT32 BspAacSampPointDlyPsyncSw(UINT32 sw)
{
    UINT32 ulRet              = BSP_OK;
    UINT32 psyncGenInt2IntNo  = 242;
    UINT32 ulTimePeriod       = 10000000;   //10ms
    UINT32 ulTimeOffset       = 9924000;    //单位ns
    UINT32 ulInter            = 10000000;   //ns

    ulRet = HalIcPsyncTimGernXInit(psyncGenInt2IntNo, ulTimePeriod, ulTimeOffset, ulInter, sw);
    return ulRet;
}

static UINT32 InitAacModuleFunc(VOID)
{
    T_AcFunc *pAcModule = NULL;

    pAcModule = (T_AcFunc *)BspGetAcModuleInfo();
    INPUT_POINTER_CHECK(pAcModule);

    pAcModule->pSetAacWgtIcNew = SetAacWgtIcNew; /* 设置Aac权值 */

    return BSP_OK;
}

UINT32 SwAppAacTypeToIcType(UINT32 type, UINT32 *aacType, UINT32 *aacStage)
{
    INPUT_POINTER_CHECK(aacType);
    INPUT_POINTER_CHECK(aacStage);

    switch(type)
    {
        case CJT_BIG_ERGODIC:
        {
            *aacType = AAC_TYPE_CJT;
            *aacStage = AAC_STAGE_BIG_ERGODIC;
            break;
        }
        case CJT_SMALL_ERGODIC:
        {
            *aacType = AAC_TYPE_CJT;
            *aacStage = AAC_STAGE_SMALL_ERGODIC;
            break;
        }
        case UTDOA_BIG_ERGODIC:
        {
            *aacType = AAC_TYPE_UTDOA;
            *aacStage = AAC_STAGE_BIG_ERGODIC;
            break;
        }
        case UTDOA_SMALL_ERGODIC:
        {
            *aacType = AAC_TYPE_UTDOA;
            *aacStage = AAC_STAGE_SMALL_ERGODIC;
            break;
        }
        default:
        {
            dbgErr("aacType[%d] error\n", type);
            return BSP_ERROR;
        }
    }

    return BSP_OK;
}

/* AAC序列增益控制 */
UINT32 BspIcStartAacProcess(UINT32 uCellId, UINT8 *pAacFrameBitMap, UINT32 frameLen, UINT32 type)
{
    UINT32 aacType = 0;
    UINT32 aacStage = 0;
    T_AacFrameBitMapInfo aacFrameBitMapInfo = {0,};
    INPUT_POINTER_CHECK(pAacFrameBitMap);
    if(frameLen > 128)
    {
        dbgErr("%s>> frameLen[%d] err!\n", __FUNCTION__, frameLen);
        return BSP_ERROR;
    }
    memcpy_s(aacFrameBitMapInfo.uR2R_TxFrameBitMap, frameLen, pAacFrameBitMap, frameLen);    /*TX的位图需要按照载波传图，高层传下来的是载波*/
    memcpy_s(aacFrameBitMapInfo.uR2R_RxFrameBitMap, frameLen, &dbg_aacBitmapCfg.rxBitmap[0], frameLen); /*RX的位图不需要按照载波传*/
    SwAppAacTypeToIcType(type, &aacType, &aacStage);

    dbgInfo(">>>%s uCellId:%d, type:%d, aacType:%d, aacStage:%d\n", __FUNCTION__, uCellId, type, aacType, aacStage);
    return BspHalAdaptStartAacProcess(uCellId, &aacFrameBitMapInfo, frameLen, aacType, aacStage);
}

UINT32 BspIcSetAacFrameGainPara(UINT32 uCellId, T_AacFrameGain *pFrameGain, UINT32 type)     //AAC序列增益控制
{
    INT32 defaultGain = 0;
    INT32 rfBackGain = 0;
    UINT32 aacStage = 0;
    UINT32 aacType = 0;

    INPUT_POINTER_CHECK(pFrameGain);
    SwAppAacTypeToIcType(type, &aacType, &aacStage);
    return BspHalAdaptSetAacFrameGainPara(uCellId, pFrameGain, defaultGain, rfBackGain, aacType);
}

UINT32 BspIcStopAacProcess(UINT32 uCellId)
{
    return BspHalAdaptStopAacProcess(uCellId, AAC_TYPE_CJT);
}

UINT32 BspSetSpecialCfgFlag(E_SPECIAL_CFG_TYPE uFlag)
{
    return BspHalAdaptSetSpecialCfgFlag(uFlag);
}

UINT32 BspSetAacTddIoLinkMapPara(void)
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;
    T_AacTddIoLinkMap *para = NULL;
    UINT32 chanNum = BspGetTxChannel();

    para = (T_AacTddIoLinkMap*)malloc(sizeof(T_AacTddIoLinkMap));
    PARAM_POINTER_NULL_CHK_WITH_RET(ERROR_INVALID_PARA, aacTddIoLinkMapPara, para);
    memset_s(para, sizeof(T_AacTddIoLinkMap), 0, sizeof(T_AacTddIoLinkMap));
    for(loop = 0; loop < chanNum;loop++)
    {
        ret = BspGetPaIoInfoByRfChn(loop,LINK_TYPE_TX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            para->info[0].linkType = TDDIO_TYPE_PA;
            para->info[0].rfChNum = chanNum;
            para->info[0].tddIoNo[loop] = ioIdx;
        }
        ret = BspGetLnaIoInfoByRfChn(loop,LINK_TYPE_RX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            para->info[1].linkType = TDDIO_TYPE_LNA;
            para->info[1].rfChNum = chanNum;
            para->info[1].tddIoNo[loop] = ioIdx;
        }
        ret = BspGetTxEnIoInfoByRfChn(loop,LINK_TYPE_TX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            para->info[2].linkType = TDDIO_TYPE_TXEN;
            para->info[2].rfChNum = chanNum;
            para->info[2].tddIoNo[loop] = ioIdx;
        }
        ret = BspGetRxEnIoInfoByRfChn(loop,LINK_TYPE_RX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            para->info[3].linkType = TDDIO_TYPE_RXEN;
            para->info[3].rfChNum = chanNum;
            para->info[3].tddIoNo[loop] = ioIdx;
        }
        ret = BspGetAmpIoInfoByRfChn(loop,LINK_TYPE_TX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            para->info[4].linkType = TDDIO_TYPE_AMP;
            para->info[4].rfChNum = chanNum;
            para->info[4].tddIoNo[loop] = ioIdx;
        }
    }

    ret = BspHalAdaptSetAacTddIoLinkMapPara(para);

    free(para);
    return ret;
}

/* AAC权值初始化，单板初始化调用 */
UINT32 BspInitAac(VOID)
{
    UINT32 retVal = BSP_OK;

    /* AAC模式中断初始化 */
    retVal |= BspAacModeMapSelPsyncSw(SWITCH_OFF);
    /* AAC样点时延中断初始化 */
    retVal |= BspAacSampPointDlyPsyncSw(SWITCH_OFF);
    /* 光口AAC flag */
    retVal |= BspSetSpecialCfgFlag(1);

    retVal |= BspInitAllSaveWgt();
    retVal |= InitAacModuleFunc();
    retVal |= BspSetAacTddIoLinkMapPara();

    return retVal;
}

UINT32 BspRstAacWgtIc(UINT32 logicCarrNo, UINT32 bandWidth)
{
    UINT32 radioMode        = RADIO_STANDARD_5G;
    UINT32 dlAcMaxWgtLength = 0;
    UINT32 prachRxLength    = 0;
    UINT32 loop             = 0;
    UINT32 acWgtLengthTmp   = 0;
    UINT32 prachWgtData     = 0;
    UINT32 trxType          = 0;
    UINT32 carrIndex        = GetSaveWgtIndex(logicCarrNo, radioMode);
    UINT32 bspChan          = 0;
    UINT32 bspChanNum       = BspGetTxChanNum();
    UINT32 rbNum            = 0;
    UINT32 polaChan         = 0;
    UINT32 rbIndex          = 0;
    UINT32 acType           = 0;
    UINT32 ret              = BSP_OK;
    UINT32 *pWgt            = NULL;
    UINT32 ulAcBitMap   = 0xffffffff;
    UINT32 acWgtIndex = 0;

    INDEX_RANGE_CHECK(carrIndex, BSP_MAX_CARR_NUM);

    dbgInfo("%s: logicCarrNo:%d, bandWidth:%d \n", __FUNCTION__, logicCarrNo, bandWidth);
    
    rbNum = BspGetAcWgtRbNum(radioMode, bandWidth, 0,AC_IF1_TYPE);
    if(BSP_ERROR == rbNum || 0 == rbNum)
    {
        dbgErr("%s: rb error!!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    s_wgtBakDataPara[carrIndex].rbNum = rbNum;
    s_wgtBakDataPara[carrIndex].carrNo = logicCarrNo;
    s_wgtBakDataPara[carrIndex].radioMode = radioMode;

    for(bspChan = 0; bspChan < bspChanNum; bspChan++)
    {
        polaChan = bspChan % 2;
        for (rbIndex = 0; rbIndex < rbNum; rbIndex++)
        {
            acWgtIndex = bspChan * rbNum + rbIndex;
            s_wgtBakDataPara[carrIndex].dlAcWgtbak[acWgtIndex] = 0x40000000;
            s_wgtBakDataPara[carrIndex].aacCjtWgtbak[polaChan][rbIndex] = 0x40000000;
        }
    }

    trxType = BspGetTrxTypeByAcType(acType);
    if (BSP_ERROR == trxType)
    {
        return BSP_ERROR;
    }

    dlAcMaxWgtLength = rbNum * bspChanNum * sizeof(UINT32);
    pWgt = (UINT32*)malloc(dlAcMaxWgtLength);
    if(pWgt == NULL)
    {
        dbgErr("%s: malloc error!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((UINT32 *)pWgt, dlAcMaxWgtLength, 0, dlAcMaxWgtLength);

    acWgtLengthTmp = dlAcMaxWgtLength / sizeof(UINT32);

    for(loop = 0; loop < acWgtLengthTmp; loop++)
    {
        pWgt[loop] = 0x40000000;
    }

    ret = IcHalApiUpdataAcWgt(logicCarrNo, trxType, radioMode,  pWgt, acWgtLengthTmp, &prachWgtData, prachRxLength, ulAcBitMap);

    free(pWgt);

    return ret;
}

/* 恢复时延补偿信息 */
UINT32 BspResetAacCarrFwdDelayBase(UINT32 logicCarrNo)
{
    UINT32 difChan = 0;
    UINT32 radioMode = RADIO_STANDARD_5G;
    UINT32 carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    UINT32 chanNum = BspGetTxChanNum();
    UINT32 ret = BSP_OK;
    INDEX_RANGE_CHECK(carrIndex, BSP_MAX_CARR_NUM);
    for(difChan = 0; difChan < chanNum; difChan++)
    {
        ret = IcHalApiSetDlPreSampPointDly(difChan, logicCarrNo, radioMode, s_wgtBakDataPara[carrIndex].oriDlyTs[difChan]);
    }
    return ret;
}

/* 获取时延补偿信息 */
UINT32 BspGetAacCarrFwdDelayBase(UINT32 logicCarrNo)
{
    UINT32 difChan = 0;
    UINT32 radioMode = RADIO_STANDARD_5G;
    UINT32 carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    UINT32 ret = BSP_OK;
    INDEX_RANGE_CHECK(carrIndex, BSP_MAX_CARR_NUM);
    UINT32 chanNum = BspGetTxChanNum();
    s_wgtBakDataPara[carrIndex].carrNo = logicCarrNo;
    s_wgtBakDataPara[carrIndex].radioMode = radioMode;
    for(difChan = 0; difChan < chanNum; difChan++)
    {
        ret = IcHalApiGetDlPreSampPointDly(difChan, logicCarrNo, radioMode, &s_wgtBakDataPara[carrIndex].oriDlyTs[difChan]);
    }
    return ret;
}

UINT32 BspSetAacBitmapToIcHal(UINT8 *TxBitmapdata, UINT8 *RxBitmapdata, UINT32 ulLength)
{
    UINT32 ulIndex = 0;
    UINT8 ulTxTempData = 0;
    UINT8 ulRxTempData = 0;
    UINT32 ulBitIndex = 0;
    UINT16 compareBitMap = 0;
    T_AacFrameModePara *para = NULL;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(TxBitmapdata);
    INPUT_POINTER_CHECK(RxBitmapdata);
    for(ulIndex = 0; ulIndex < ulLength; ulIndex++)
    {
        dbg_aacBitmapCfg.txBitmap[ulIndex] = TxBitmapdata[ulIndex];
        dbg_aacBitmapCfg.rxBitmap[ulIndex] = RxBitmapdata[ulIndex];
    }

    para = (T_AacFrameModePara*)malloc(sizeof(T_AacFrameModePara));
    PARAM_POINTER_NULL_CHK_WITH_RET(ERROR_INVALID_PARA, aacFrameModePara, para);
    memset_s(para, sizeof(T_AacFrameModePara), 0, sizeof(T_AacFrameModePara));
    for(loop = 0; loop < BSP_AAC_MAX_FRAME_NUM; loop++)
    {
        ulIndex = loop / 8;       /*获取哪一个bit与帧号对应*/
        dbgInfoEx("ulIndex: %d\n", ulIndex);
        ulBitIndex = loop % 8;    /*获取哪一个bit位 */
        dbgInfoEx("ulBitIndex: %d\n", ulBitIndex);
        ulTxTempData = (TxBitmapdata[ulIndex] & (0x1 << ulBitIndex));
        dbgInfoEx("ulTxTempData: %d\n", ulTxTempData);
        ulTxTempData = (!ulTxTempData)? 0 : 1;
        dbgInfoEx("ulTxTempData: %d\n", ulTxTempData);
        ulRxTempData = (RxBitmapdata[ulIndex] & (0x1 << ulBitIndex));
        dbgInfoEx("ulRxTempData: %d\n", ulRxTempData);
        ulRxTempData = (!ulRxTempData)? 0 : 1;
        dbgInfoEx("ulRxTempData: %d\n", ulRxTempData);
        compareBitMap = (ulTxTempData << 1) | ulRxTempData;
        compareBitMap = (compareBitMap << 14) |(compareBitMap << 12) |(compareBitMap << 10) |(compareBitMap << 8) |
                        (compareBitMap << 6) | (compareBitMap << 4) | (compareBitMap << 2) | compareBitMap;
        dbgInfoEx("compareBitMap: %hx\n", compareBitMap);

        s_aacFrameMode[loop] = compareBitMap;
        para->aacFrameMode[loop] = compareBitMap;
    }
    BspHalAdaptSetAacFrameModePara(para);

    free(para);
    return BSP_OK;
}

UINT32 dbgGetAacBitmapToIcHal(VOID)
{
    UINT32 rows = 0;
    UINT32 cols = 0;

    dbgInfo("txBitmap:\n");
    for(rows = 0; rows < 8; rows++)
    {
        dbgInfo("tx bitmap[%3d ~ %3d]: ", rows*16, rows*16 + 15);
        for(cols = 0; cols < 16; cols++)
        {
            dbgInfo("0x%02x ", dbg_aacBitmapCfg.txBitmap[rows*16 + cols]);
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");
    dbgInfo("rxBitmap:\n");
    for(rows = 0; rows < 8; rows++)
    {
        dbgInfo("rx bitmap[%3d ~ %3d]: ", rows*16, rows*16 + 15);
        for(cols = 0; cols < 16; cols++)
        {
            dbgInfo("0x%02x ", dbg_aacBitmapCfg.rxBitmap[rows*16 + cols]);
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    return BSP_OK;
}

UINT32 testSetAacBitmapToIcHal(UINT8 txBitmapData, UINT8 rxBitmapData, UINT32 dir, UINT32 startIndex, UINT32 endIndex)
{
    UINT32 index = 0;

    switch(dir)
    {
        case TX:        //TX = 1
        {
            for(index = startIndex; index < endIndex + 1; index++)
            {
                dbg_aacBitmapCfg.txBitmap[index] = txBitmapData;
            }
            break;
        }
        case RX:        //RX = 0
        {
            for(index = startIndex; index < endIndex + 1; index++)
            {
                dbg_aacBitmapCfg.rxBitmap[index] = rxBitmapData;
            }
            break;
        }
        case 255:
        {
            for(index = startIndex; index < endIndex + 1; index++)
            {
                dbg_aacBitmapCfg.txBitmap[index] = txBitmapData;
                dbg_aacBitmapCfg.rxBitmap[index] = rxBitmapData;
            }
            break;
        }
        default:
        {
            break;
        }
    }
    BspSetAacBitmapToIcHal(dbg_aacBitmapCfg.txBitmap, dbg_aacBitmapCfg.rxBitmap, BITMAP_MAX_NUM);

    return BSP_OK;
}

UINT32 BspSetDlGpEnAllChanForAac(UINT32 radioMode, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 chan = 0;
    UINT32 radio = 0;
    UINT32 carrNo = 0;
    UINT32 txChanNum = BspGetTxChannel();
    T_ChanRfCfgPara *pRfCfg = NULL;
    dbgInfo("%s>> start! \n", __FUNCTION__);

    for (chan = 0; chan < txChanNum; chan++)
    {
        pRfCfg = GetRfCfgPara(chan, TX);
        if(NULL == pRfCfg)
        {
            continue;
        }

        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            carrNo = pRfCfg->para.carrInfo[loop].carrNo;
            radio = pRfCfg->para.carrInfo[loop].radioMode;

            if(radioMode == radio)
            {
                retVal |= BspHalAdaptSetDlGpEn(chan, radio,carrNo, sw);
                dbgInfo("carrNo'%d,radio'0x%x,sw'%d\n", carrNo, radio, sw);
            }
        }
        dbgInfo("\n");
    }
    return retVal;
}

/* Aac使能开关接口 */
UINT32 BspSetIcHalAacEn(UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    BspSetAacRfSwitchParaUpdateSw(sw);

    if(SWITCH_ON == sw)
    {
        s_sampPointDlyInfo.addrNum = 0;
        BspSetIoGpEn(0, 0);
        BspSetDlGpEnAllChanForAac(RADIO_STANDARD_5G, SWITCH_ON);/*目前只支持TDD AAC*/
        BspAacModeMapSelPsyncSw(SWITCH_ON);
        BspAacSampPointDlyPsyncSw(SWITCH_ON);
        BspUpdateTddIoVariablePara(0,2);  /*TDD AAC时序选择0*/
    }
    else
    {
        BspAacModeMapSelPsyncSw(SWITCH_OFF);
        BspAacSampPointDlyPsyncSw(SWITCH_OFF);
        BspSetDlGpEnAllChanForAac(RADIO_STANDARD_5G, SWITCH_OFF);/*目前只支持TDD AAC*/
        BspUpdateTddIoVariablePara(0,2);  /*TDD AAC时序选择0*/
        BspSysMsDelay(100);
        BspRecoverTddIoUeOut2Sel1();
        s_sampPointDlyInfo.addrNum = 0;
    }
    BspLog(LOG_LEVEL_0,"%s AAC sw= %u\n", __FUNCTION__, sw);

    return retVal;
}

/* AAC GPEN使能 */
UINT32 BspSetAacGpEnSwitch(UINT32 sw, UINT32 carrNo, UINT32 radioMode)
{
    UINT32 icMaxAntNo = 0;
    UINT32 difChan    = 0;
    UINT32 ret        = 0;
    T_ICHAL_ACPARA* acPara   = (T_ICHAL_ACPARA*)getAcParaAddr();

    //获取IC内部天线数目
    icMaxAntNo = acPara->acIcMaxAntNo;
    //GP设置：设置下行链路中是否包含GP符号
    for(difChan = 0; difChan < icMaxAntNo; difChan++)
    {
        ret |= IcHalSetDlGpEn(difChan, radioMode, carrNo, sw);
    }

    dbgInfoEx("[%s]  sw=%d, carrNo=%d, radioMode=%d, ret=%d \n",__FUNCTION__,sw,carrNo,radioMode,ret);

    return ret;
}

/* 配置时延补偿信息 */
UINT32 BspSetAacCarrFwdDelayTddoffset(UINT32 chipId, UINT32 difChan, UINT32 radioMode, UINT32 logicCarrNo, INT32 ts, UINT32 effectSFrmNo)
{
    UINT32 carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    UINT32 chanNum = BspGetTxChanNum();
    UINT32 dlyAddr = 0;
    INT32 oriDlyTs = 0;
    INT32 tmpDlyTs = 0;
    UINT32 loop = 0;
    UINT32 flag = 0;
    UINT32 retVal = BSP_OK;

    INDEX_RANGE_CHECK(difChan, chanNum);
    INDEX_RANGE_CHECK(difChan, IC42_MAX_CHAN_NUM);
    INDEX_RANGE_CHECK(carrIndex, BSP_MAX_CARR_NUM);
    oriDlyTs = s_wgtBakDataPara[carrIndex].oriDlyTs[difChan];
    tmpDlyTs = oriDlyTs - ts;
    s_wgtBakDataPara[carrIndex].tsBak[difChan] = ts;
    retVal = BspHalAdaptGetDlpreSampPointPhyAddr(difChan, logicCarrNo, radioMode, &dlyAddr);

    INDEX_RANGE_CHECK(s_sampPointDlyInfo.addrNum, BSP_AAC_MAX_CARR_NUM);
    for(loop = 0; loop < s_sampPointDlyInfo.addrNum; loop++)
    {
        if(dlyAddr == s_sampPointDlyInfo.info[loop].addr)
        {
            flag = 1;
            break;
        }
    }
    if(flag == 0)
    {
        s_sampPointDlyInfo.info[s_sampPointDlyInfo.addrNum].addr = dlyAddr;
        s_sampPointDlyInfo.info[s_sampPointDlyInfo.addrNum].dlyVal = tmpDlyTs;
        s_sampPointDlyInfo.info[s_sampPointDlyInfo.addrNum].superFrmNo = effectSFrmNo;
        s_sampPointDlyInfo.addrNum ++;
    }
    else
    {
        s_sampPointDlyInfo.info[loop].dlyVal = tmpDlyTs;
        s_sampPointDlyInfo.info[loop].superFrmNo = effectSFrmNo;
    }
    dbgInfoEx("carr[%d], addr 0x%x, dlyVal %d, oriDlyTs %d, ts %d, superFrmNo %d\n",
            logicCarrNo, dlyAddr, tmpDlyTs, oriDlyTs, ts, effectSFrmNo);
    retVal |= BspHalAdaptSetAacSampPointDlyPara(&s_sampPointDlyInfo);

    return retVal;
}

UINT32 dbgPrintAacFrameMode(VOID)
{
    UINT32 loop = 0;

    for(loop = 0; loop < BSP_AAC_MAX_FRAME_NUM; loop++)
    {
        dbgInfo("frameNo[%d], mode %d \n", loop, s_aacFrameMode[loop]);
    }
    return BSP_OK;
}

UINT32 dbgPrintAacSampPointDly(VOID)
{
    UINT32 loop = 0;

    for(loop = 0; loop < BSP_AAC_MAX_CARR_NUM; loop++)
    {
        dbgInfo("carr[%d], addr 0x%x, dlyVal %d, superFrmNo %d\n",
                loop, s_sampPointDlyInfo.info[loop].addr, s_sampPointDlyInfo.info[loop].dlyVal, s_sampPointDlyInfo.info[loop].superFrmNo);
    }
    return BSP_OK;
}

UINT32 BspCfgAacCaliPeriodInfo(UINT32 carrNo, T_AacCaliPeriodInfo *periodInfo, UINT32 type)
{
    UINT16 rttStartNo = 0;
    UINT8 rttSuperFrameNum = 0;
    UINT16 r2rStartNo = 0;
    UINT8 r2rSuperFrameNum = 0;
    UINT16 period = 0;
    UINT16 offset = 0;
    UINT16 periodNum = 0;
    UINT32 i,j,loop = 0;
    UINT32 ret = 0;
    UINT32 aacType = 0;
    UINT32 aacStage = 0;
    T_AacSuperFrameInfo superFrameInfo = {0,};

    INPUT_POINTER_CHECK(periodInfo);
    rttStartNo = periodInfo->rttStartSuperFrame;
    rttSuperFrameNum = periodInfo->rttSuperFrameNum;
    r2rStartNo = periodInfo->r2rStartSuperFrame;
    r2rSuperFrameNum = periodInfo->r2rSuperFrameNum;
    period = periodInfo->calilPeriod;
    if(period == 0)
    {
        dbgErr("%s: carrNo[%u] period[%u] is error! \n",__FUNCTION__, carrNo, period);
        BspLog(LOG_LEVEL_0,"%s: carrNo[%u] period[%u] is error! \n",__FUNCTION__, carrNo, period);
        return BSP_ERROR;
    }
    periodNum = 1024 / period;
    offset = periodInfo->startFrameOffset;

    s_superFrameInfoBak[carrNo].calilPeriod         = period;
    s_superFrameInfoBak[carrNo].startFrameOffset    = offset;
    s_superFrameInfoBak[carrNo].rttStartSuperFrame  = rttStartNo;
    s_superFrameInfoBak[carrNo].rttSuperFrameNum    = rttSuperFrameNum;
    s_superFrameInfoBak[carrNo].r2rStartSuperFrame  = r2rStartNo;
    s_superFrameInfoBak[carrNo].r2rSuperFrameNum    = r2rSuperFrameNum;

    BspLog(LOG_LEVEL_0,"%s period=%d,offset=%d,rttStartNo=%d,rttSuperFrameNum=%d\n", __FUNCTION__, period, offset, periodInfo->rttStartSuperFrame, periodInfo->rttSuperFrameNum);
    BspLog(LOG_LEVEL_0,"%s r2rStartNo=%d,r2rSuperFrameNum=%d\n", __FUNCTION__,periodInfo->r2rStartSuperFrame, periodInfo->r2rSuperFrameNum);
    dbgInfo("%s >>> period=%u, periodNum = %u, offset=%u\n", __FUNCTION__, period, periodNum, offset);
    dbgInfo("%s >>> rttStartNo=%u, rttSuperFrameNum=%u\n", __FUNCTION__, rttStartNo, rttSuperFrameNum);
    dbgInfo("%s >>> r2rStartNo=%u, r2rSuperFrameNum=%u\n", __FUNCTION__, r2rStartNo, r2rSuperFrameNum);

    //ret = BspUtdoaCaliPeriodInfoHandle(carrNo, periodInfo);

    for(loop = 0; loop < periodNum; loop++)
    {
        for(j = 0; j < r2rSuperFrameNum; j++)
        {
            if((r2rStartNo + j) >= 1024)
            {
                dbgErr(">>>%s para err,r2rStartNo=%u,j=%u\n",__FUNCTION__,r2rStartNo,j);
                return BSP_ERROR;
            }
            dbgInfo("r2r super_frame:%d\n",r2rStartNo+j);
            superFrameInfo.superframe_r2rbitmap[r2rStartNo+j] = (UINT32)1;
        }
        r2rStartNo += period;
    }

    for(loop = 0; loop < periodNum; loop++)
    {
        for(i = 0; i < rttSuperFrameNum; i++)
        {
            if(rttStartNo >= 1024)
            {
                dbgErr(">>>%s para err,r2rStartNo=%u,i=%u\n",__FUNCTION__,r2rStartNo,i);
                return BSP_ERROR;
            }
            dbgInfo("rtt super_frame:%d\n",rttStartNo+i);
            superFrameInfo.superframe_rttbitmap[rttStartNo+i] = (UINT32)1;
        }
        rttStartNo += period;
    }
    superFrameInfo.superframe_cycle = periodInfo->calilPeriod;
    SwAppAacTypeToIcType(type, &aacType, &aacStage);

    memcpy_s(dbg_superFrameInfo[carrNo].superframe_r2rbitmap, 1024, &superFrameInfo.superframe_r2rbitmap[0], 1024);
    memcpy_s(dbg_superFrameInfo[carrNo].superframe_rttbitmap, 1024, &superFrameInfo.superframe_rttbitmap[0], 1024);
    dbg_superFrameInfo[carrNo].superframe_cycle = superFrameInfo.superframe_cycle;

    dbgInfo(">>>%s carrNo:%u, type:%u, aacType:%u, aacStage:%u superFrameInfo:%p\n", __FUNCTION__, carrNo, type, aacType, aacStage, &superFrameInfo);
    BspLog(LOG_LEVEL_0,">>>%s carrNo:%u, type:%u, aacType:%u, aacStage:%u superFrameInfo:%p\n", __FUNCTION__, carrNo, type, aacType, aacStage, &superFrameInfo);
    ret = BspHalAdaptSetAacSuperFrameInfo(carrNo, &superFrameInfo, aacType);
    dbgInfo(">>>%s ret:%d\n", __FUNCTION__,ret);
    BspLog(LOG_LEVEL_0,">>>%s ret:%d\n", __FUNCTION__,ret);

    return ret;
}

VOID dbgShowUtdoaSuperFrameInfo(UINT32 carrNo)
{
    if(carrNo >= BSP_MAX_CARR_NUM)
    {
        dbgErr(">>>>%s carrNo[%u] err!\n", __FUNCTION__, carrNo);
        return;
    }
    dbgInfo("calilPeriod = %u, \n",          s_superFrameInfoBak[carrNo].calilPeriod);
    dbgInfo("startFrameOffset = %u, \n",     s_superFrameInfoBak[carrNo].startFrameOffset);
    dbgInfo("rttStartSuperFrame = %u, \n",   s_superFrameInfoBak[carrNo].rttStartSuperFrame);
    dbgInfo("rttSuperFrameNum = %u, \n",     s_superFrameInfoBak[carrNo].rttSuperFrameNum);
    dbgInfo("r2rStartSuperFrame = %u, \n",   s_superFrameInfoBak[carrNo].r2rStartSuperFrame);
    dbgInfo("r2rSuperFrameNum = %u, \n",     s_superFrameInfoBak[carrNo].r2rSuperFrameNum);
}

void PrintStr(const char *pStrName, UINT8 *pStr, UINT32 length)
{
    UINT32 loop = 0;
    UINT32 startBit = 0;
    UINT32 endBit = 0;

    INPUT_POINTER_CHECK_RETURN(pStrName);
    INPUT_POINTER_CHECK_RETURN(pStr);

    dbgInfo("%s: \n", pStrName);
    for (UINT32 i = 0; i < length; ++i)
    {
        if (i % BIT_PER_LINE == 0)
        {
            // 计算当前行的起始和结束 bit 位置
            startBit = loop * 8;
            endBit = startBit + 7;
            dbgInfo("bit[%u~%u]: ", startBit, endBit);
            loop++;
        }
        dbgInfo("%02X ", pStr[i]);
        if ((i + 1) % BIT_PER_LINE == 0 || i == length - 1)
        {
            // 换行并在行末添加换行符
            dbgInfo("\n");
        }
    }
}

void prnaacsupframebitmap(UINT32 carrNo)
{
    if(carrNo >= BSP_MAX_CARR_NUM)
    {
        dbgErr(">>>>%s carrNo[%u] err!\n", __FUNCTION__, carrNo);
        return;
    }
    dbgInfo("SUPER FRAME BITMAP:\n");
    PrintStr("aac_superframe_rttbitmap", (UINT8 *)dbg_superFrameInfo[carrNo].superframe_rttbitmap, 1024);
    PrintStr("aac_superframe_r2rbitmap", (UINT8 *)dbg_superFrameInfo[carrNo].superframe_r2rbitmap, 1024);
    dbgInfo("superframe_cycle: %u\n", dbg_superFrameInfo[carrNo].superframe_cycle);
}
/* Ended by AICoder, pid:p9e4e201384773314e810a92d78f5c1f75107ce8 */

/* Started by AICoder, pid:d7024v7ba73412a140070955e0c9e54f3931d379 */
VOID showerraacpara(VOID)
{
    UINT32 loop = 0;
    UINT32 rbIndex = 0;
    UINT32 polaChan = 0;

    for (loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
    {
        if (s_dbgAacWgtData[loop].radioMode == 0)
        {
            break;
        }
        dbgInfo("logicCarrNo:%d, radioMode:%d, aacWgtLength:%d, aacInitiateNum:%d, aacRbNum:%d\n",
                s_dbgAacWgtData[loop].logicCarrNo,
                s_dbgAacWgtData[loop].radioMode,
                s_dbgAacWgtData[loop].aacWgtLength,
                s_dbgAacWgtData[loop].aacInitiateNum,
                s_dbgAacWgtData[loop].aacRbNum);
        dbgInfo("AAC Wgt:\n");

        for(polaChan = 0; polaChan < IC42_MAX_POLA_CHAN; polaChan++)
        {
            for (rbIndex = 0; rbIndex < s_dbgAacWgtData[loop].aacRbNum; rbIndex++)
            {
                dbgInfo("0x%x ,",s_dbgAacWgtData[loop].aacErrWgtbak[polaChan][rbIndex]);
            }
        }
        dbgInfo("\n");
    }
    return ;
}
/* Ended by AICoder, pid:d7024v7ba73412a140070955e0c9e54f3931d379 */

/* Started by AICoder, pid:y7024k7ba74412a140070955e0c9e54f3931d379 */
UINT32 dbgshowaacwgt(UINT32 radioMode, UINT32 logicCarrNo)
{
    UINT32 index = 0;
    UINT32 rbIndex = 0;
    UINT32 polaChan = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        if ((s_wgtBakDataPara[index].carrNo == logicCarrNo) && (s_wgtBakDataPara[index].radioMode == radioMode))
        {
            for(polaChan = 0; polaChan < IC42_MAX_POLA_CHAN; polaChan++)
            {
                for(rbIndex = 0; rbIndex < s_wgtBakDataPara[index].rbNum; rbIndex++)
                {
                    dbgInfo("0x%x, ",s_wgtBakDataPara[index].aacCjtWgtbak[polaChan][rbIndex]);
                }
            }
            dbgInfo("\n aacWgtLength:%d aacRbNum:%d\n",s_wgtBakDataPara[index].aacWgtLength, s_wgtBakDataPara[index].rbNum);

            return BSP_OK;
        }
    }

    return BSP_ERROR;
}
/* Ended by AICoder, pid:y7024k7ba74412a140070955e0c9e54f3931d379 */

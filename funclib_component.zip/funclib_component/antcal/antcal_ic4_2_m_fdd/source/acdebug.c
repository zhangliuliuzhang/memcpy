/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : acdebug.c
* 文件标识 : {[N/A]}
* 内容摘要 : 该文件主要是AC维测信息
* 注意事项 : 无
* 作    者 :
* 创建日期 : 2021-01-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2021-01-04
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#include "acdebug.h"
#include "antcal_ic4_2_oneic.h"
#include "ac_app.h"

static UINT32 g_AcFuncLogFileNum = 0;
static CHAR cAcFuncLogPrefix[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogM_";
static CHAR cAcFuncLogFileDir[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogM.txt";
CHAR * const cAcFuncPathList[2] = {"/bin/rm", "/bin/mv"};
rsize_t rAcFuncPathListSize = 2;

UINT32 g_acFuncLogLevel = AC_FUNC_LOG_HIGH;
UINT32 g_lastAcRst = 0;

VOID AcHelp(VOID)
{
    dbgInfo("\n***********************************AC CPU CMD***************************************************\n");
    dbgInfo(" Enable Automatic AC:      setAcEnFlag 1\n");
    dbgInfo(" Disable Automatic AC:     setAcEnFlag 0\n");
    dbgInfo(" AC test manually(TDD):    testAcProc  acType, carrNo,radioMode,cellId\n");
    dbgInfo(" AC test manually(FDD):    testCellFddAc  acType, cellId, radioMode, bandWidth, subFrameNo, slotNo\n");
    dbgInfo("\n*************************************AcSta******************************************************\n");
    dbgInfo(" AC Dsp Para:              AcSta 0x11\n");
    dbgInfo(" AC Result:                AcSta 0x12\n");
    dbgInfo(" AC Result in Details:     AcSta 0x13,1,IterationNo\n");
    dbgInfo(" AC SNR/PWDIFF/TA:         AcSta 0x13,2,IterationNo\n");
    dbgInfo(" AC Wgt Sta Info:          AcSta 0x13,3,CarrNo\n");
    dbgInfo(" AC Pha Err Info:          AcSta 0x1d\n");
    dbgInfo("\n**********************************AcSetPara*****************************************************\n");
    dbgInfo(" AC Couple Net:            AcSetPara 0xeb,value(0:Compen/1:No Compen)\n");
    dbgInfo(" AC Wgt to 1.0:            AcSetPara 0xee,value(0:Cal Wgt/1:1.0 Wgt)\n");
    dbgInfo(" AC DL Seq Factor:         AcSetPara 0x10e,value(dbfs)\n");
    dbgInfo(" AC UL Seq Factor:         AcSetPara 0x10f,value(dbfs)\n");
    dbgInfo(" AC DL SigLen:             AcSetPara 0xec,value\n");
    dbgInfo(" AC UL SigLen:             AcSetPara 0xed,value\n");
    dbgInfo(" AC DL Pwr CompenFlg:      AcSetPara 0x133,value (0:compen/1:no compen)\n");
    dbgInfo(" AC UL Pwr CompenFlg:      AcSetPara 0x134,value (0:compen/1:no compen)\n");
    dbgInfo(" AC Ul VGA CompenFlg:      AcSetPara 0x138,value (0:compen/1:no compen)\n");
    dbgInfo("\n**********************************AcSample******************************************************\n");
    dbgInfo(" AC Sample Wgt:            AcSample 0x1e,\"fileName.bin\" \n");
    dbgInfo(" AC Sample Data:           AcSample 0x1f,\"fileName.bin\" \n");
    dbgInfo(" AC Fix Seq:               AcSample 0x38,\"fileName.bin\" \n");
    dbgInfo(" AC Float Couple Net:      AcSample 0x20,\"fileName.bin\" \n");
}

UINT32 AcSta(UINT32 index, INT32 data0, INT32 data1, INT32 data2, INT32 data3)
{
    return acGetDpdStrAcDsp(index, data0, data1, data2, data3);
}

UINT32 AcSetPara(INT32 index, INT32 funcIndex, INT32 par0, INT32 par1, INT32 par2)
{
    return acSetParaAcDsp(index, funcIndex, par0, par1, par2);
}

UINT32 AcSample(UINT32 dataType,const char* filename)
{
    INPUT_POINTER_CHECK(filename);
    return acUpLoadDataAcDspBin(dataType,filename);
}

UINT32 AcFuncLogGetLogLevel(VOID)
{
    return g_acFuncLogLevel;
}

VOID AcFuncLogLevelSet(UINT32 uiLogLevel)
{
    g_acFuncLogLevel = uiLogLevel;
}

INT32 AcFuncLog(UINT32 logLevel, const CHAR *format, ...)
{
    FILE *pFile = NULL;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;
    INT32 iRet           = 0;
    UINT32 uiAclogLevel  = 0;

    uiAclogLevel = AcFuncLogGetLogLevel();
    if(logLevel > uiAclogLevel)
    {
        return BSP_OK;
    }

    iRet = zte_fopen_s(&pFile, cAcFuncLogFileDir, "a+", cDirList, rDirListSize);
    ZTE_SECURITY_FUNC_CHECK(iRet);

    if(pFile == NULL)
    {
        dbgErr("%s %d, fail to open file! \n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    va_list arg;
    va_start(arg, format);
    struct tm timelog;
    struct tm* tm_log = NULL;
    struct timeval nowtime;
    gettimeofday(&nowtime, NULL);
    //coverity[declaration_with_small_time_t:SUPPRESS]
    time_t seconds = nowtime.tv_sec;
    zte_memset_s(&timelog, sizeof(timelog), 0x00, sizeof(timelog));
    tm_log = localtime_r(&seconds, &timelog);

    if(tm_log != NULL)
    {
        iRet = fprintf(pFile, "%04d-%02d-%02d %02d:%02d:%02d.%06ld|%d| ",
                                tm_log->tm_year + 1900,
                                tm_log->tm_mon+1,
                                tm_log->tm_mday,
                                tm_log->tm_hour,
                                tm_log->tm_min,
                                tm_log->tm_sec,
                                nowtime.tv_usec,
                                logLevel);
        FPRINTF_CHECK(iRet);
    }

    //ZTE_SECURITY_FUNC_CHECK(iRet);
    (void)zte_vfprintf_s(pFile, format, arg);
    //FPRINTF_CHECK(iRet);
    va_end(arg);
    iRet = fflush(pFile);
    FFLUSH_CHECK(iRet);
    iRet = fclose(pFile);
    FCLOSE_CHECK(iRet);

    return iRet;
}

UINT32 AcFuncDspAddrInfo(UINT32 uiMode)
{
    T_Pulm2CmacAntAdjustRspIc3* ptAcRdInfo      = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* ptAcWrInfo = NULL;
    UINT8 *pucBaseAddr                          = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (AC_DDR_HANDLE_READ == uiMode)
    {
        ptAcRdInfo = (T_Pulm2CmacAntAdjustRspIc3*)((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + pucBaseAddr));
        AcFuncLog(AC_FUNC_LOG_HIGH, "DspRst acType:%d, acRst:%d, radioMode:%d, carrNo:%d, niAbnormalFlag:%d, ucAppParaErrCode:%d, acChnBitmap: 0x%02x \n",
                  ptAcRdInfo->acMsgHeaderRsk.uwACType,
                  ptAcRdInfo->acMsgHeaderRsk.uwACResult,
                  ptAcRdInfo->acMsgHeaderRsk.uwRadioMode,
                  ptAcRdInfo->acMsgHeaderRsk.uiCellId,
                  ptAcRdInfo->acMsgHeaderRsk.ucNiAbnormalFlag,
                  ptAcRdInfo->acMsgHeaderRsk.ucAppParaErrCode,
                  ptAcRdInfo->acMsgBodyRsk.aucAcChnBitmap[0]);
        BspRecordLastAcRst(ptAcRdInfo->acMsgHeaderRsk.uwACResult);
        AcFuncLog(AC_FUNC_LOG_HIGH, "DspRst antIdx: 0 ~ 7 SNR: %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d \n",
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[0],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[1],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[2],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[3],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[4],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[5],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[6],
                  ptAcRdInfo->acMsgBodyRsk.acchAcSinr[7]);
        AcFuncLog(AC_FUNC_LOG_HIGH, "DspRst antIdx: 0 ~ 7 PwrDiff: %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d \n",
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[0],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[1],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[2],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[3],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[4],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[5],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[6],
                  ptAcRdInfo->acMsgBodyRsk.acchAcPwrDiff[7]);
        AcFuncLog(AC_FUNC_LOG_HIGH, "DspRst antIdx: 0 ~ 7 TA: %3d, %3d, %3d, %3d, %3d, %3d, %3d, %3d \n",
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[0],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[1],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[2],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[3],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[4],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[5],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[6],
                  ptAcRdInfo->acMsgBodyRsk.acchAcTa[7]);
    }
    else
    {
        ptAcWrInfo = (T_Cmac2PulmAntAdjustScheInfoIc3*)((VOID *)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + pucBaseAddr));
        AcFuncLog(AC_FUNC_LOG_HIGH, "AppPara acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, refChn:%d, preciseDelayFlag:%d, appBitmap:0x%02x \n",
                  ptAcWrInfo->acMsgHeaderReq.uwACType,
                  ptAcWrInfo->acMsgHeaderReq.uwRadioMode,
                  ptAcWrInfo->acfillInfoReq.uiBandWidth,
                  ptAcWrInfo->acMsgHeaderReq.uiCellId,
                  ptAcWrInfo->acMsgBodyReq.ucAcUpDownChnNo,
                  ptAcWrInfo->acMsgBodyReq.uPreciseDelayFlag,
                  ptAcWrInfo->acMsgBodyReq.aucDUlValidAntBitMap[0]);
    }

    return BSP_OK;
}

VOID BspRecordLastAcRst(UINT32 uiAcRst)
{
    g_lastAcRst = uiAcRst;
}

UINT32 BspGetLastAcRst(VOID)
{
    return g_lastAcRst;
}

VOID BspAcFuncLogCount()
{
    g_AcFuncLogFileNum++;
    if(g_AcFuncLogFileNum >= AC_FUNC_LOG_FILE_MAX)
    {
        g_AcFuncLogFileNum = 0;
    }
}

UINT32 BspHandleAcFuncLog(VOID)
{
    INT32 iRet = 0;
    CHAR cAcFuncLogBuffix[AC_FUNC_LOG_MAX_STRING];
    CHAR cAcFuncLogBakDir[AC_FUNC_LOG_MAX_STRING];
    CHAR * const cCommandRmFile[3] = {"rm", cAcFuncLogFileDir, NULL};
    rsize_t uiCommandRmFileLen = 3;
    CHAR * const cCommandMvFile[4] = {"mv", cAcFuncLogFileDir, cAcFuncLogBakDir, NULL};
    rsize_t uiCommandMvFileLen = 4;
    UINT32 auiOutput[10] = {0};
    UINT32 uiChipIdx = 0;

    if(AC_FUNC_LOG_RST_SUCCES == BspGetLastAcRst())
    {
        iRet = zte_system_s("/bin/rm",
                            cCommandRmFile,
                            uiCommandRmFileLen,
                            cAcFuncPathList,
                            rAcFuncPathListSize);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        for(uiChipIdx = 0;uiChipIdx < BspGetRpuNum();uiChipIdx++)
        {
            iRet = BspAcSocCmd(uiChipIdx, "BspHandleAcLogRstSuc", auiOutput);
            RESULT_CHECK_WITHOUT_HANDLE_AC(iRet);
        }
    }
    else
    {
        iRet = zte_strncpy_s(cAcFuncLogBakDir, sizeof(cAcFuncLogBakDir), cAcFuncLogPrefix, sizeof(cAcFuncLogPrefix));
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_snprintf_s(cAcFuncLogBuffix, sizeof(cAcFuncLogBuffix), "%d.txt", g_AcFuncLogFileNum);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_strncat_s(cAcFuncLogBakDir, sizeof(cAcFuncLogBakDir), cAcFuncLogBuffix, sizeof(cAcFuncLogBuffix));
        ZTE_SECURITY_FUNC_CHECK(iRet);

        iRet = zte_system_s("/bin/mv",
                            cCommandMvFile,
                            uiCommandMvFileLen,
                            cAcFuncPathList,
                            rAcFuncPathListSize);
        ZTE_SECURITY_FUNC_CHECK(iRet);

        for(uiChipIdx = 0;uiChipIdx < BspGetRpuNum();uiChipIdx++)
        {
            iRet = BspAcSocCmd(uiChipIdx, "BspHandleAcLogRstFail", auiOutput);
            RESULT_CHECK_WITHOUT_HANDLE_AC(iRet);
        }
        BspAcFuncLogCount();
    }

    return iRet;
}

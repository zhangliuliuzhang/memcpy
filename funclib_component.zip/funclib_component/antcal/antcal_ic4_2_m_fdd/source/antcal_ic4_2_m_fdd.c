/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : anmtcal.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include <stdint.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <time.h>
#include<sys/socket.h>
#include<sys/ioctl.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<errno.h>
#include<linux/if.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<netinet/in.h>
#include<netdb.h>
#include<linux/errno.h>
#include<sys/time.h>
/*#include <linux/sysctl.h> coverity check*/
#include <sys/mman.h>
#include "systemcallapi.h"
#include "antcal_ic4_2_oneic.h"
#include "regdrv.h"
#include "rftable.h"
#include "freqcfgcommon.h"
#include "exprn.h"
#include "antcalcommon.h"
//#include "dsp_msg.h"
#include "vxadp.h"
#include "chnmap_a.h"
#include "dpd_app.h"
#include "ac_app.h"
#include "psync.h"
#include "acdebug.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/

/**************************************************************************
 *                        宏                                              *
 **************************************************************************/
#define ANTCAL_PI                     (3.14159265359)    /* 圆周率 */
#define AC_FREQ_STEP                  (20)
#define _LINEAR_INSERT(x,x1,y1,x2,y2) ((INT32)(((FLOAT)((y2) - (y1)) / ((x2) - (x1) + 0.000001)) * ((x) - (x1)) + (y1)+0.5))
#define AC_WGTDATA_GROUP_NUM           18
/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/

/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
UINT32 board_type_flag = 0;
ac_user_AddrCfg s_acUserAddrCfg;
INT32 s_cpswacFd = -1;
UINT8 *s_ucRamDspAddr = NULL;
T_AcCarrCfgNxp g_acCarrCfgNxp = {0};
UINT32 s_ulCellFre = 0;
INT8 avgTaDl   = 0;
INT8 avgTaUl   = 0;
UINT32 g_uiJacMode = 0;
UINT32 g_uiJacHandleType = 0;
UINT8 g_uiJacBitMap = 0;
UINT32 g_nonStandBandFlag = 0;
UINT32 g_nonStandOptNco = 0;
UINT32 g_uiAlgTimeSw = 0; //时域法开关，0:不使用时域法,1:使用时域法
T_AcAntMapInfo g_acAntMapInfo = {0};
//幅相表维测
static UINT32 acPhaAmpDbgSw = 0;
static INT32 acAmpDbgVal = 1000;
static INT32 acPhaseDbgVal = 0;
UINT32 g_uiAcValidAntNum = 0;

// 计数器上报存储
//ACTYPE BANDNO  RADIOMODE CARRNO  CHAN
INT8 g_acSaveSnr[MAX_TYPEIDX][MAX_BANDNO][MAX_RADIOIDX][MAX_CARRNO][MAX_CHANNO] = {0};
FLOAT g_acSaveDly[MAX_TYPEIDX][MAX_BANDNO][MAX_RADIOIDX][MAX_CARRNO][MAX_CHANNO] = {0};
FLOAT g_acSavePha[MAX_TYPEIDX][MAX_BANDNO][MAX_RADIOIDX][MAX_CARRNO][MAX_CHANNO] = {0};

UINT32 g_uiRcuaFlag = 0;
UINT32 g_uiRcuaBitMap = 0;
UINT32 g_RcuaAntNoMap = 0;
const UINT32 ac_WgtDataNum[AC_WGTDATA_GROUP_NUM][2]=
{
    /*带宽,点数*/
    {100000,99},
    {90000 ,89},
    {80000 ,79},
    {60000 ,59},
    {50000 ,49},
    {45000 ,44},
    {40000 ,39},
    {30000 ,29},
    {20000 ,19},
    {15000 ,14},
    {10000 ,9},
    {5000  ,4},
    {4800  ,3},
    {4600  ,3},
    {4400  ,3},
    {4200  ,3},
    {3840  ,2},
    {3800  ,2}
};

T_AcWgtInfo g_acWgtInfo[] = \
{
    /****************TDD  Begin************************/
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_100M_MHz, 273},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_90M_MHz,  245},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_80M_MHz,  217},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_60M_MHz,  162},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_50M_MHz,  133},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_40M_MHz,  106},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_30M_MHz,  78},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_25M_MHz,  65},
    {CARR_TYPE_IF1, RADIO_STANDARD_5G,  BANDWIDTH_20M_MHz,  51},

    {CARR_TYPE_IF1, RADIO_STANDARD_LTE_TDD, BANDWIDTH_20M_MHz,  100},
    {CARR_TYPE_IF1, RADIO_STANDARD_LTE_TDD, BANDWIDTH_10M_MHz,  50},
    /****************TDD  End**************************/

    /****************FDD  Begin************************/
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_50M_MHz,  270},
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_45M_MHz,  242},
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_40M_MHz,  216},
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz,  160},
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz,  106},
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz,  79},
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz,  52},
    {CARR_TYPE_IF1, RADIO_STANDARD_FDD_5G, BANDWIDTH_5M_MHz,   25},

    {CARR_TYPE_IF0, RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz,  160},
    {CARR_TYPE_IF0, RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz,  160},
    {CARR_TYPE_IF0, RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz,  160},
    {CARR_TYPE_IF0, RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz,  160},
    {CARR_TYPE_IF0, RADIO_STANDARD_FDD_5G, BANDWIDTH_5M_MHz,   160},

    {CARR_TYPE_IF1, RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz,  100},
    {CARR_TYPE_IF1, RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz,  75},
    {CARR_TYPE_IF1, RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz,  50},
    {CARR_TYPE_IF1, RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,   25},

    {CARR_TYPE_IF0, RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz,  160},
    {CARR_TYPE_IF0, RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz,  160},
    {CARR_TYPE_IF0, RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz,  160},
    {CARR_TYPE_IF0, RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,   160},

    //UMTS DSP按照273偏移，在DDR中0、1位置存储相位值和时延值
    {CARR_TYPE_IF0, RADIO_STANDARD_UMTS, BANDWIDTH_5M_MHz,  273},
    {CARR_TYPE_IF0, RADIO_STANDARD_UMTS, BANDWIDTH_4M_MHz,  273},
    {CARR_TYPE_IF0, RADIO_STANDARD_UMTS, BANDWIDTH_3M_MHz,  273},
    //SDR LTE IF0 按照时域法补, DSP按照273偏移，在DDR中0、1位置存储相位值和时延值
    {CARR_TYPE_IF2, RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz,  273},
    {CARR_TYPE_IF2, RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz,  273},
    {CARR_TYPE_IF2, RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz,  273},
    {CARR_TYPE_IF2, RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,   273},
    {CARR_TYPE_IF0, RADIO_STANDARD_GSM, GSM_BANDWIDTH_MHz, 273},
    /****************FDD  End**************************/
};
/**************************************************************************
 *                         外部变量声明                                   *
 **************************************************************************/

/**************************************************************************
 *                         外部函数声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         局部函数声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         全局函数实现                                   *
 **************************************************************************/

UINT32 BspSetBoardTypeFlag(void)
{
    board_type_flag = 1;

    return BSP_OK;
}

UINT8* BspGetAcMemBaseAddr(VOID)
{
    return s_ucRamDspAddr;
}

UINT32 IcHalSetDlavgTA(INT8 inPut)
{
    avgTaDl = inPut;

    return BSP_OK;
}

UINT32 IcHalSetUlavgTA(INT8 inPut)
{
    avgTaUl = inPut;

    return BSP_OK;
}

T_BandNoRedefinition g_acBandNoRedef = {0};

UINT32 BspGetBandNo(VOID)
{
    UINT32 uiBandNo = 0;
    UINT32 i = 0;

    if(1 == g_acBandNoRedef.uiRedefFlag)
    {
        for(i=0; i< MAX_BANDNO_NUM;i++)
        {
            if(g_acCarrCfgNxp.bandNo == g_acBandNoRedef.uiRceBandNo[i][0])
            {
                uiBandNo = g_acBandNoRedef.uiRceBandNo[i][1];
                dbgInfoEx("Search BandNo [%s]\n",__FUNCTION__);
                break;
            }
        }
        dbgInfoEx("[%s],BandNo:%d Change BandNo :%d\n",__FUNCTION__,g_acCarrCfgNxp.bandNo ,uiBandNo);
        return uiBandNo;
    }   
    return g_acCarrCfgNxp.bandNo;
}
/* Started by AICoder, pid:yf6e789775w8c5a14f5a0aa2b01e481982237873 */
UINT32 BspGetAcCarrFreq(VOID)
{
    dbgInfo("[%s], CarrFreq:%d \n", __FUNCTION__, g_acCarrCfgNxp.carrFreq);

    return g_acCarrCfgNxp.carrFreq;
}

UINT32 BspGetAcCarrBw(VOID)
{
    dbgInfo("[%s], CarrBandWidth:%d \n", __FUNCTION__, g_acCarrCfgNxp.bandWidth);

    return g_acCarrCfgNxp.bandWidth;
}
/* Ended by AICoder, pid:yf6e789775w8c5a14f5a0aa2b01e481982237873 */
/* Started by AICoder, pid:gc09cu3f25s5dee1429f097c20455d16a9453f34 */
UINT32 BspSetAcAlgTimeSw(UINT32 uiSw)
{
    UINT8  *baseAddr = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* pAcMsgIc3;

    g_uiAlgTimeSw = uiSw;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址  /* 调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    pAcMsgIc3 = (T_Cmac2PulmAntAdjustScheInfoIc3*)((VOID *)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr));
    pAcMsgIc3->ucAlgTimeSw = uiSw;

    return BSP_OK;
}

UINT32 BspGetAcAlgTimeSw(VOID)
{
    return g_uiAlgTimeSw;
}
/* Ended by AICoder, pid:gc09cu3f25s5dee1429f097c20455d16a9453f34 */
/******************************************************************************
* 函数名称   : BspGetAcRecvPacks()
* 功能描述   : 获取内核中接收ac数据包数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
*
* 输出参数   : 无
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
UINT32 GetAcRecvPacks(VOID)
{
    UINT32 acRcvPacks=0;
    UINT32 temp = 0;

    if (s_cpswacFd <= 0)
    {
        s_cpswacFd = open(KXCPSW_AC_DEV,O_RDWR | O_SYNC);
        dbgInfo("open /dev/cpsw_ac dev \n ");
    }
    if(-1 == s_cpswacFd)
    {
        dbgInfo("Open cpsw_ac error \n");
    }

    /*获取接收包数*/
    temp = ioctl(s_cpswacFd, CPSW_AC_DATA_GET, &acRcvPacks);
    dbgInfo("get the cpsw ac recv packets is = %d, temp:%#x\n",acRcvPacks, temp);


    return acRcvPacks;
}

/**************************************************************************
 * 函数名称: BspAcDataInit
 * 功能描述: 整个ac模块初始化
 * 输入参数: pAddcfg: 给内核的各个配置
             pUserAddCfg: 给用户态的各个配置
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                   牛彦茹    创建
 **************************************************************************/
UINT32 AcDataInit(VOID)
{
    INT32 Fd = 0; /*内存设备的文件描述符*/
    UINT32 ulAcRamLen = 0;
    ac_user_AddrCfg *pUserAddCfg = NULL;

    pUserAddCfg = malloc(sizeof(ac_user_AddrCfg));
    if (pUserAddCfg == NULL)
    {
        dbgErr("%s[%d]malloc faild!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    memcpy(pUserAddCfg, &s_acUserAddrCfg, sizeof(ac_user_AddrCfg));

    /*通过mmap将物理地址映射到用户进程的虚拟地址空间*/
    Fd = open("/dev/memnc", O_RDWR | O_SYNC);  /*打开内存设备的文件描述符*/
    if (Fd == -1)
    {
        dbgInfo("open /dev/memnc failed\n");
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    /*设置用户态共享内存基址和长度*/
    ulAcRamLen = pUserAddCfg->aclength;
    s_ucRamDspAddr = mmap(0, ulAcRamLen, PROT_READ | PROT_WRITE, MAP_SHARED, Fd, pUserAddCfg->acaddr);//0xC000_0000
    if (s_ucRamDspAddr == MAP_FAILED)
    {
        dbgInfo("mmap g_ulRamDspAddr failed %s, %d\n",strerror(errno),errno);
        close(Fd);
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    close(Fd);
    free(pUserAddCfg);

    dbgInfo("%s>>ShareRamDspAddr= %p; RamLen= (0x%08X) %d\n",  __FUNCTION__, (void*)s_ucRamDspAddr, ulAcRamLen, ulAcRamLen);
    

    return BSP_OK;
}

UINT32 InitAcCaliDevPara(VOID *pUserAddCfg)
{
    memcpy(&s_acUserAddrCfg,pUserAddCfg,sizeof(ac_user_AddrCfg));

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 BspGetPauRelativeAmp(UINT32 ulChan, INT32 lFreq, INT32 *plAmp)
{
    TPauRelativeAmpCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;
    UINT32 ulBand = 0;

    INPUT_POINTER_CHECK(plAmp);
    *plAmp = 1000;                /*正常范围默认值*/
    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);

    ptCaliData = (TPauRelativeAmpCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEAMP,0);
    PAURELATIVEAMP_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    INPUT_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    if (lFreq <= (INT32)ulStartFreq)
    {
        ulIndex = 0;
        lComps = ptRecord[0].lCompVal;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        ulIndex = ulRecordNum - 1;
        lComps = ptRecord[ulRecordNum-1].lCompVal;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lCompVal,\
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lCompVal);
    }

    *plAmp = lComps;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 BspGetPauRelativePhase(UINT32 ulChan, UINT32 ulBand, INT32 lFreq, INT32 *plPhase)
{
    TPauRelativePhaseCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;

    INPUT_POINTER_CHECK(plPhase);
    *plPhase = 0;                 /*正常范围默认值*/
    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);

    ptCaliData = (TPauRelativePhaseCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEPHASE,0);
    PAURELATIVEPHASE_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    INPUT_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    if (lFreq <= (INT32)ulStartFreq)
    {
        ulIndex = 0;
        lComps = ptRecord[0].lCompVal;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        ulIndex = ulRecordNum - 1;
        lComps = ptRecord[ulRecordNum-1].lCompVal;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lCompVal,\
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lCompVal);
    }

    *plPhase = lComps;
    dbgInfoEx("%s>>Chnl'%d Band'%d Freq(Step'%d Sta'%d End'%d)'%d:Idx= %d, phase= %d\n",
              __FUNCTION__, ulChan, ulBand, ulStepFreq, ulStartFreq,
              ulEndFreq, lFreq, ulIndex, lComps);

    return BSP_OK;
}
/* Started by AICoder, pid:n1026ac030b5a3914c64092440f7d3460431c0b4 */
UINT32 BspReCfgPhaAmpRelativeValue(INT32 *amp, INT32 *phase)
{
    INPUT_POINTER_CHECK(amp);
    INPUT_POINTER_CHECK(phase);

    *amp = 1000; /* 上下行都不做补偿，幅度值置1处理 */
    if(acPhaAmpDbgSw == 1)
    {
        *amp = acAmpDbgVal;
        *phase = acPhaseDbgVal;
    }

    return BSP_OK;
}

UINT32 BspSetAcPhaAmpDbgSw(UINT32 uiSw, INT32 iAmpVal, INT32 iPhaVal)
{
    acPhaAmpDbgSw = uiSw;
    acAmpDbgVal   = iAmpVal;
    acPhaseDbgVal = iPhaVal;

    dbgInfoEx("[%s], acPhaAmpDbgSw:%d, acAmpDbgVal:%d, acPhaseDbgVal:%d \n", __FUNCTION__, acPhaAmpDbgSw, acAmpDbgVal, acPhaseDbgVal);

    return BSP_OK;
}
/* Ended by AICoder, pid:n1026ac030b5a3914c64092440f7d3460431c0b4 */
/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 BspGetPauRelativeAmpPhase(UINT32 dir, UINT32 chan, INT32 centFreq, UINT32 bandWidth, T_AcWeightData pData[AC_WEIGHT_DATA_NUM])
{
    INT32  freqStep, freq;
    INT32  loop, center;
    INT32  amp, phase;
    UINT32 acwgtdatanum = AC_WEIGHT_DATA_NUM;

    for(loop = 0;loop<AC_WGTDATA_GROUP_NUM;loop++)
    {
        if(bandWidth==ac_WgtDataNum[loop][0])
        {
            acwgtdatanum = ac_WgtDataNum[loop][1];
            dbgInfoEx("chan:%d,bw:%d,centfreq:%d,loop:%d,acwgtdatanum:%d\n",chan,bandWidth,centFreq,loop,acwgtdatanum);
            break;
        }
    }

    /*先填成默认值*/
    for (loop = 0; loop < AC_WEIGHT_DATA_NUM; loop++)
    {
        pData[loop].amplitude = 1000;
        pData[loop].phase = 0;
    }
    /*根据实际要求修改*/
    freqStep = (INT32)bandWidth/ acwgtdatanum / 100 * 100;
    center   = acwgtdatanum / 2;
    for (loop = 0; loop < acwgtdatanum; loop++)
    {
        freq = (loop - center) * freqStep + centFreq;
        amp = 1000, phase = 0;
        BspGetPauRelativeAmp(chan,freq,&amp);
        BspGetPauRelativePhase(chan,0,freq,&phase);
        BspReCfgPhaAmpRelativeValue(&amp, &phase);
        pData[loop].amplitude = amp;
        pData[loop].phase = phase;

        dbgInfoEx("dir:%d,chn:%d,bw:%d,centfreq:%d,freq:%d,idx:%d,amp:%d,phase:%d\n",dir,
                  chan,bandWidth,centFreq,freq,loop,amp,phase);
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetACWeightData(*)
 * 功能描述: 获取AC权值
 * 输入参数: ulChn - 通道号(从0开始)
             ulCarr- 载波号(从0开始)
             ulDir - 上下行(1:TX,0:RX)
 * 输出参数: pData - 99组权重值,以载波ulCarr为中心的上下各49个
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月14日 10090699    创建
 **************************************************************************/
UINT32 BspGetACWeightData(UINT32 chan, UINT32 carrNo, UINT32 dir, T_AcWeightData pData[AC_WEIGHT_DATA_NUM])
{
    UINT32 uiRet;
    UINT32 uiCentFreq = 0;
    UINT32 uiBandWidth = 0;
    UINT32 uiRfChn   = 0;
    UINT32 uiAntId   = 0;
    UINT32 uiBandNo  = 0;
    UINT32 uiBspChn  = 0;
    UINT32 uiLoop    = 0;
    TPauRelativeAmpCaliData *ptCaliData = NULL;

    INPUT_POINTER_CHECK(pData);
    TBL_CHAN_VALID_CHECK(chan);

    ptCaliData = (TPauRelativeAmpCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEAMP,0);
    INPUT_POINTER_CHECK(ptCaliData);
    if (TBL_LOAD_SUCC != (ptCaliData->atPath[chan].ulLoadFlag))
    {
        for (uiLoop = 0; uiLoop < AC_WEIGHT_DATA_NUM; uiLoop++)
        {
            pData[uiLoop].amplitude = 1000;
            pData[uiLoop].phase = 0;
        }
        dbgInfoEx("[%s], PAURELATIVEAMP not loaded \n", __FUNCTION__);
        return BSP_OK;
    }

    uiBandNo = BspGetBandNo();
    uiAntId = chan + 1; //Bsp天线表中天线从1开始
    uiRet = BspGetBspChanByAntAndBandInfo(uiAntId, uiBandNo, dir, &uiBspChn);
    //RESULT_CHECK_WITHOUT_HANDLE_AC(uiRet);
    if(uiRet != BSP_OK)
    {
        dbgInfo("[%s], BspGetBspChanByAntAndBandInfo: uiRet:%d uiAntId:%d  uiBandNo:%d dir:%d  uiBspChn:%d   \n", __FUNCTION__, uiRet,uiAntId,uiBandNo,dir, uiBspChn);
        return uiRet;
    }
    uiRet = BspGetRfChnByBspChn(uiBspChn, dir, &uiRfChn);
    RESULT_CHECK_WITHOUT_HANDLE_AC(uiRet);

    dbgInfo("[%s], BandNo:%d, AntId:%d, uiRfChn:%d \n", __FUNCTION__, BspGetBandNo(), uiAntId, uiRfChn);

    uiCentFreq = BspGetAcCarrFreq();
    uiBandWidth = BspGetAcCarrBw() * 1000;
    dbgInfo("[%s], uiCentFreq:%d, uiBandWidth:%d \n", __FUNCTION__, uiCentFreq, uiBandWidth);

    uiRet = BspGetPauRelativeAmpPhase(dir, uiRfChn, (INT32)uiCentFreq, uiBandWidth, pData);

    return uiRet;
}


/* Started by AICoder, pid:sa353je4484066d142b20bb450eba0120d58bde0 */
void BspGetCoupleNetFactor_m(UINT32 dir, UINT32* aulData, UINT32 chanEnd, T_Cmac2PulmAntAdjustScheInfoIc3* ptInfo)
{
    UINT32 chan = 0;
    UINT32 uiAcNetFactorOffset = 0;
    UINT32 retVal = 0;
    for (chan = 0; chan < chanEnd; chan++)
    {
        retVal = BspGetCoupleNetFactor(chan, ptInfo->acMsgHeaderReq.uiCellId, dir, &aulData[0]);
        if(retVal == BSP_OK)
        {
            memcpy_s((VOID *)ptInfo->axsCoupleNetFactor[uiAcNetFactorOffset], sizeof(UINT32) * AC_WEIGHT_DATA_NUM, (VOID *)aulData, sizeof(UINT32) * AC_WEIGHT_DATA_NUM);
            uiAcNetFactorOffset++;
            dbgInfo("%s Factor=%d, uiAcNetFactorOffset = %d \n", __FUNCTION__,ptInfo->axsCoupleNetFactor[uiAcNetFactorOffset][0], uiAcNetFactorOffset);
        }
    }
    return;
}

/* Ended by AICoder, pid:sa353je4484066d142b20bb450eba0120d58bde0 */


UINT32 BspGetCoupleNetFactor(UINT32 antNo, UINT32 carrNo, UINT32 dir, UINT32 aulData[])
{
    UINT32 loop     = 0;
    DOUBLE amp      = 0.0;
    DOUBLE angle    = 0.0;
    UINT16 iData    = 0;
    UINT16 qData    = 0;
    UINT32 uiRet  =  0;
    T_AcWeightData *ptData = NULL;

    ptData = malloc(sizeof(T_AcWeightData) * AC_WEIGHT_DATA_NUM);
    INPUT_POINTER_CHECK(ptData);

    uiRet = BspGetACWeightData(antNo, carrNo, dir, ptData);
    if(uiRet != BSP_OK)
    {
        free(ptData);
        dbgInfo("[%s], BspGetCoupleNetFactor: uiRet:%d", __FUNCTION__,uiRet);
        return uiRet;
    }
    for (loop = 0; loop < AC_WEIGHT_DATA_NUM; loop++)
    {
        amp   = (DOUBLE)ptData[loop].amplitude / 1000.0;
        angle = ((DOUBLE)ptData[loop].phase / 100.0) * ANTCAL_PI / 180;

        iData = (UINT16)(((INT32)(amp * cos(angle) * pow(2, 14)) + 65536) % 65536);
        qData = (UINT16)(((INT32)(amp * sin(angle) * pow(2, 14)) + 65536) % 65536);
        aulData[loop] = (iData << 16) + qData;
    }
    free(ptData);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspCaliTaDfNs
 * 功能描述: 计算频点为ulFre的TaDfNs值
 * 输入参数: ulChan - 通道号(从0开始)
             ulFre- 中心频点
 * 输出参数: wTaDfNs - 计算结果
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年09月04日 xuping    创建
 **************************************************************************/
 INT32 BspCaliTaDfNs(UINT32 ulChan, UINT32 ulFre ,UINT16 *wTaDfNs)
{
    INT32  lFilterDelay = 0;
    INT32  lAntDelay    = 0;
    INT32  lFilterDelay0= 0;
    INT32  lAntDelay0   = 0;
    INT16  wTaDf        = 0;


    if(_BspGetFilterDelayVal(0, ulFre, &lFilterDelay0) != BSP_OK)
    {
        return BSP_ERROR;
    }

    if(_BspGetAntDelayVal(0, ulFre, &lAntDelay0) != BSP_OK)
    {
        return BSP_ERROR;
    }

    if(_BspGetFilterDelayVal(ulChan, ulFre, &lFilterDelay) != BSP_OK)
    {
        return BSP_ERROR;
    }

    if(_BspGetAntDelayVal(ulChan, ulFre, &lAntDelay) != BSP_OK)
    {
        return BSP_ERROR;
    }

    wTaDf = (INT16)(lFilterDelay0+lAntDelay0-lFilterDelay-lAntDelay);
    *wTaDfNs = wTaDf;

    dbgInfoEx("%s<< FreRbi = %d, TaDfNs[%d] = FilterDelay0[%d] + AntDelay0[%d] - FilterDelay[%d] - AntDelay[%d]\n", \
        __FUNCTION__,ulFre,wTaDf,lFilterDelay0,lAntDelay0,lFilterDelay,lAntDelay);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetTaDfNs
 * 功能描述: 计算以载波ulCarr为中心的RB值对应的TaDfNs
 * 输入参数: ulChan - 通道号(从0开始)
             ulCellFre- 中心频点
 * 输出参数: wTaDfNs - 以载波ulCarr为中心的RB值对应的TaDfNs
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年09月02日 xuping    创建
 **************************************************************************/
UINT32 BspGetTaDfNs(UINT32 ulChan,UINT32 ulCellFre, INT16 wTaDfNs[])
{
//    UINT32 ulLoop    = 0;
//    UINT32 ulFreRbi  = 0;
//    UINT32 ulRet     = 0;
//    s_ulCellFre = ulCellFre;
//
//    if(BspGetRfTblLoadResult(TBL_KIND_OF_FILTERDELAY) == TBL_LOAD_SUCC && BspGetRfTblLoadResult(TBL_KIND_OF_ANTDELAY) == TBL_LOAD_SUCC)
//    {
//        for (ulLoop = 0; ulLoop < AC_ANT_WGT_NUM_NR_MAX; ulLoop++)
//        {
//            ulFreRbi=((ulLoop*(UINT32)12+(UINT32)6)*(UINT32)30-(UINT32)1638*(UINT32)30)+ulCellFre;
//
//            dbgInfoEx("%s<< Loop = %d, ", __FUNCTION__,ulLoop);
//            ulRet = BspCaliTaDfNs(ulChan,ulFreRbi,&wTaDfNs[ulLoop]);
//            if(ulRet != BSP_OK)
//            {
//             dbgInfoEx("%s err, BspCaliTaDfNs Get Ch%d TaDfNsValue failed\n", __FUNCTION__,ulLoop);
//             return BSP_ERROR;
//            }
//        }
//    }
//    else
//    {
//        for (ulLoop = 0; ulLoop < AC_ANT_WGT_NUM_NR_MAX; ulLoop++)
//        {
//            wTaDfNs[ulLoop]=10; //先给定10，后期再修改
//        }
//        /*如果文件加载失败，后期需要给定默认值？*/
//        dbgInfoEx("%s err, antdelay.txt Or filterdelay.txt initialization failed\n", __FUNCTION__);
//    }

    return BSP_OK;
}

/**********************************************************************
* 函数名称：BspDirDataLoad
* 功能描述：获取单音频点对应的广播权值
* 输入参数：index : 选择第几组测试
* 输出参数：dirData:  返回对应的64天线方向权值数据
* 返 回 值：BSP_OK - 成功
* 其它说明：天线权值文件23组,每组64*23行数据,每个天线23行,先
* 修改日期       版本号      修改人      修改内容
* -----------------------------------------------
*
***********************************************************************/
UINT32 BspDirDataLoad(UINT32 index,UINT32 *dirData,UINT32 *dataLen)
{
    UINT32 *buf;
    FILE   *fp;
    struct stat statInfo;
    char fileName[32] = {0};
    char lineData[100] = {0};
    UINT32 num = 0;
    UINT32 loop = 0;
    UINT32 chanNum = BspGetAntNum();
    INT32  snpRet = 0;
    INT32  lClsRet = 0;

    INPUT_POINTER_CHECK(dirData);
    INPUT_POINTER_CHECK(dataLen);

    snpRet = snprintf_s(fileName,sizeof(fileName),"/ata/%dantBCweight.dat",chanNum);
    SNPRINTF_S_CHECK(snpRet, sizeof(fileName));

    fp = fopen(fileName, "r");
    if (fp == NULL)
    {
        dbgErr("failed to open file %s\n", fileName);
        return BSP_ERROR;
    }
    if (BSP_OK != stat(fileName,&statInfo))
    {
        dbgErr("not exist file %s\n", fileName);
        lClsRet = fclose(fp);
        FCLOSE_CHECK(lClsRet);
        return BSP_ERROR;
    }
    buf = (UINT32 *)malloc(statInfo.st_size);
    if (buf == NULL)
    {
        dbgErr("malloc failed\n");
        lClsRet = fclose(fp);
        FCLOSE_CHECK(lClsRet);
        return BSP_ERROR;
    }
    memset(buf, 0, statInfo.st_size);

    while (!feof(fp) && fgets(lineData,sizeof(lineData),fp) != NULL)
    {
        buf[num++] = strtoul(lineData,NULL,16);
        memset(lineData,0,sizeof(lineData));
    }

    if (!feof(fp)) /* 读文件未到结尾,说明有异常退出 */
    {
        lClsRet = fclose(fp);
        FCLOSE_CHECK(lClsRet);
        free(buf);
        dbgErr("abnormal assert!");
        return BSP_ERROR;
    }
    lClsRet = fclose(fp);
    FCLOSE_CHECK(lClsRet);

    if ((index+1)*chanNum > num)
    {
        dbgErr("%s index %d or num %d error\n",__FUNCTION__,index,num);
        free(buf);
        return BSP_ERROR;
    }

    *dataLen = min(chanNum, *dataLen);
    for(loop = 0; loop < *dataLen; loop++)
    {
        dirData[loop] = buf[index*chanNum+loop];
    }

    free(buf);
    return BSP_OK;
}

/**********************************************************************
* 函数名称：BspGetTsgFreRb
* 功能描述：获取单音对应的RB索引
* 输入参数：signalToneFreq : 单音频点
* 输出参数：无
* 返 回 值：BSP_OK - 成功
* 其它说明：无
* 修改日期       版本号      修改人      修改内容
* -----------------------------------------------
*
***********************************************************************/
UINT32 BspGetTsgFreRb(INT32 toneFreq)
{
    UINT32 rbNo = 0;

    if(toneFreq < 0)
    {
        rbNo = (floor)(136 + (0-toneFreq - 15) / 360.0);
    }
    else
    {
        rbNo = (floor)(135 - (toneFreq - 15) / 360.0);
    }
    return rbNo;
}

UINT32 BspSetAcBcWgt(T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    return BSP_OK;
}

///启动计算AC序列
UINT32 CalAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag)
{
    UINT32 chan      = 0;
    UINT32 freqNo    = carr;
    UINT32 cellId    = carr;
    UINT32 retVal    = BSP_OK;
    
    dbgInfoEx("carr:%d,pasteCarrFlag:%d,deviate:%d,bandWidth:%d,sampleRate:%d,\
            radioMode:%d,acType:%d,seqType:%d,refChan:%d,preciseDlyFlag:%d\n",carr,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,acType,seqType,refChan,preciseDlyFlag);
    BspHandleAcFuncLog();
    AcFuncLog(AC_FUNC_LOG_HIGH, "SeqCal acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, seqType:%d, refChn:%d, preciseDlyFlag:%d \n",
                                acType, radioMode, bandWidth, carr, seqType, refChan, preciseDlyFlag);
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]

    retVal = BspAcSeqCalcIc4(chan, freqNo, cellId, pasteCarrFlag, deviate, bandWidth, sampleRate,radioMode,acType,seqType,refChan,preciseDlyFlag);
    

    return retVal;
}

//检查序列是否计算完
UINT32 ChkAcSeqIc(UINT32 chan)
{
    //目前的策略是等待1秒钟
    return 0;
}

UINT32 g_saveAcSeqFlag = 0;
VOID setSaveAcSeqFlag(UINT32 val)
{
    g_saveAcSeqFlag = val;
}

UINT32 saveAcSeqNxp(UINT32* seq, UINT32 length)
{
    UINT32 ret          = BSP_OK;
    UINT32 jLoop        = 0;
    INT32  lFprtfRet    = 0;
    INT32  lClsRet      = 0;

    if(0 == g_saveAcSeqFlag)
    {
        return ret;
    }
    INPUT_POINTER_CHECK(seq);

    FILE*  fp     = fopen("AcSeqNxp.txt", "w+");
    if(fp == NULL)
    {
        return BSP_ERROR;
    }

    for (jLoop = 0; jLoop < length/4; jLoop++)
    {
        lFprtfRet = fprintf_s(fp,"0x%08x\n",seq[jLoop]);
        FPRINTF_CHECK(lFprtfRet);
        dbgInfoEx("[%d] Data = 0x%08x \n", jLoop, seq[jLoop]);
    }

    lClsRet = fclose(fp);
    FCLOSE_CHECK(lClsRet);

    dbgInfo("\n**** see file AcSeqNxp.txt ****\n\n");
    return ret;
}
/* Started by AICoder, pid:i7ed9n342ebca5614f91093c3059e6357670c459 */
UINT32 BspGetAntNumFromAcMap(UINT32 uiSocId, UINT32 uiDir, UINT32 uiAntLoop, UINT32 *puiAntNum, UINT32 *puiAntTmp)
{
    UINT32 uiRet = BSP_ERROR;
    UINT32 uiAntMapLoop = 0;

    INPUT_POINTER_CHECK(puiAntNum);
    INPUT_POINTER_CHECK(puiAntTmp);
    for(uiAntMapLoop = 0;uiAntMapLoop < AC_MAP_ELEMENT_MAX;uiAntMapLoop++)
    {
        if((g_acAntMapInfo.uiaAntMap[uiAntMapLoop][DIF_CHIP_ID] == uiSocId)
           && (g_acAntMapInfo.uiaAntMap[uiAntMapLoop][TRX_TYPE] == uiDir)
           && (g_acAntMapInfo.uiaAntMap[uiAntMapLoop][RRU_ANT_ID] == uiAntLoop))
        {
            *puiAntNum = g_acAntMapInfo.uiaAntMap[uiAntMapLoop][DSP_ANT_ID];
            uiRet = BSP_OK;
            break;
        }
    }
    *puiAntTmp = uiAntLoop;
    dbgInfoEx("[%s], uiRet:%d, socId:%d, dir:%d, AntLoop:%d\n", __FUNCTION__, uiRet, uiSocId, uiDir, uiAntLoop);

    return uiRet;
}
/* Ended by AICoder, pid:i7ed9n342ebca5614f91093c3059e6357670c459 */
//获取AC序列
UINT32 GetAcSeqIc(UINT32 socId, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length)
{
    UINT8  *seqAddr  = NULL;
    UINT8  *baseAddr = NULL;
    UINT32 seqSize   = 0;
    UINT32 jLoop     = 0;
    UINT32 loopSel   = 0;
    UINT32 offsetAddr = 0;
    UINT32 antAddrOffset = 0;
    UINT32 difChipId = 0;
    UINT32 difChan   = 0;
    UINT32 antNo     = 0;
    UINT32 antChn    = 0;
    UINT8  *seqTmp   = NULL;
    UINT32 TxOrRxdir = 0;
    UINT32 uiRet = 0;
    UINT32 antNoTmp = 0;
    UINT32 uiBspChn = 0;
    UINT32 uiAntMapValid = 0;
    UINT32 uiAntTmp = 0;

    
    dbgInfoEx("carr:%d,pasteCarrFlag:%d,deviate:%d,bandWidth:%d,sampleRate:%d,radioMode:%d,\
                    acType:%d,socId:%d\n",carr,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,acType,socId);
    INPUT_POINTER_CHECK(seq);
    INPUT_POINTER_CHECK(length);

    if(BSP_RADIO_STANDARD_GSM == radioMode)
    {
        return BSP_OK;
    }

    seqTmp = (UINT8 *)seq;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    offsetAddr = NXP_AC_MEM_CPU_RD_AC_SEQ_ADDR;
    seqAddr = offsetAddr + baseAddr;

    TxOrRxdir = (E_AC_TYPE_FDD_DL == acType) ? (UINT32)TX : (UINT32)RX; //上下行类型
    uiAntMapValid = (MAP_INFO_VALID == g_acAntMapInfo.uiAcMapValid) ? MAP_INFO_VALID : MAP_INFO_INVALID;  //AC位图映射使能
    //序列拷贝
    for (loopSel = 0; loopSel < BspGetAntNum(); loopSel++)
    {
        if(MAP_INFO_VALID == uiAntMapValid)
        {
            uiRet = BspGetAntNumFromAcMap(socId, TxOrRxdir, loopSel, &antNo, &uiAntTmp);
            RESULT_CHECK_CONTINUE_AC(uiRet);
            VAR_BIT_SET(g_RcuaAntNoMap, uiAntTmp);
        }
        else
        {
            antNoTmp = loopSel +1 ;
            uiRet = BspGetBspChanByAntAndBandInfo(antNoTmp, BspGetBandNo(), TxOrRxdir, &uiBspChn);
            dbgInfo("BspGetDifInfoByRfChn antNoTmp = %d, BandNo = %d, uiBspChn = %d\n",antNoTmp,BspGetBandNo(),uiBspChn);
            RESULT_CHECK_CONTINUE_AC(uiRet);
            uiRet = BspGetDifInfoByBspChn(uiBspChn,TxOrRxdir,&difChipId,&difChan);
            RETURN_RESULT_CHECK(uiRet);
            dbgInfo("BspGetDifInfoByRfChn chan = %d, difChipId = %d, difChan = %d,socId = %d \n",uiBspChn,difChipId,difChan,socId);
            if (socId != difChipId)
            {
                dbgInfo("[%s], difChipId != socId \n", __FUNCTION__);
                continue;
            }
            uiRet = BspGetAntInfoByRfChn(loopSel,TxOrRxdir, &antNo,&antChn);
            RETURN_RESULT_CHECK(uiRet);
            antNo = antNo -1; //主控link表定义中的天线号为控制面天线号,从1开始，这里必须-1;
            VAR_BIT_SET(g_RcuaAntNoMap,antNo);
        }
        dbgInfo("BspGetAntInfoByRfChn chan = %d, antNo = %d, antChn = %d,socId = %d\n",loopSel,antNo,antChn,socId);
        antAddrOffset = antNo * NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
        memcpy_s((UINT8*)seqTmp, NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024, (UINT8*)(seqAddr+ antAddrOffset), NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024);
        seqTmp += NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
        seqSize += NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024;
        dbgInfo("seqTmp:%p,sourceAddr:%p,seqSize:%d\n", (void*)seqTmp, (void*)(seqAddr+ antAddrOffset), seqSize);
    }
    *length = seqSize;

    dbgInfoEx("[%s],g_RcuaAntNoMap %d\n", __FUNCTION__, g_RcuaAntNoMap);
    jLoop = 0;
    for (jLoop = 0; jLoop < seqSize/4; jLoop++)
    {
        dbgInfoEx("[%d] Data = 0x%08x \n", jLoop, seq[jLoop]);
    }
    dbgInfo("[%s]baseAddr %p, seqAddr %p, seqSize 0x%08X\n", __FUNCTION__, (void*)baseAddr, (void*)seqAddr, seqSize);
    AcFuncLog(AC_FUNC_LOG_HIGH, "SeqGet socId:%d, acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, seqLen:%d \n",
                                socId, acType, radioMode, bandWidth, carr, *length);
    

    return BSP_OK;
}
UINT32 testAcSeq[8192] = {0};
UINT32 seqsize = 0;
UINT32 testGetAcSeqIc(UINT32 socId, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType)
{
    UINT32 i =0;
    GetAcSeqIc(socId, carr,pasteCarrFlag,deviate, bandWidth, sampleRate,radioMode, acType, testAcSeq, &seqsize);
    dbgInfoEx("seqSize:%d\n",seqsize);
    for(i = 0; i<8192 ; i++)
    {
        dbgInfoEx("testAcSeq:0x%08X\n",testAcSeq[i]);
    }

    return BSP_OK;
}

//设置AC序列生效
UINT32 SetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 length, UINT32 seqMode)
{
    return 0;
}

UINT32 SendHaulBackAcSeqIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return 0;
}

UINT32 SendFwdRevDataToDsp(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return 0;
}

//启动AC权值计算
UINT32 CalAcWgtIc(UINT32 acType, UINT32 carr,  UINT32 radioMode, UINT32 refChan)
{
    UINT32 retVal = BSP_OK;
    dbgInfoEx("[%s](in): tick = %d,acType:%d,carr:%d,radioMode:%d,refChan:%d\n",__FUNCTION__,tickGet(),acType,carr,radioMode,refChan);
    retVal = BspAcWgtCalcIc(acType,carr, radioMode,refChan);
    AcFuncLog(AC_FUNC_LOG_HIGH, "WgtCal localFr:%d, acType:%d, radioMode:%d, carrNo:%d \n", IcHalGetFrameNo(), acType, radioMode, carr);
    

    return retVal;
}

//检查是否完成权值计算
UINT32 ChkAcWgtIc(UINT32 acType, UINT32 carr, UINT32 radioMode)
{
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;
    dbgInfoEx("[%s](in): tick = %d,acType:%d,carr:%d,radioMode:%d\n",__FUNCTION__,tickGet(),acType,carr,radioMode);
    retVal = BspGetAcWgtCalcSta(chan, acType);
    

    return retVal;
}
/**********************************************JAC新增接口-BEGIN*****************************************************/
//启动参考通道H计算
UINT32 CalJacRefHCalcIc(UINT32 acType, UINT32 carr)
{
    UINT32 retVal = BSP_OK;

    dbgInfoEx("[%s](in): tick = %d,acType:%d,carr:%d \n", __FUNCTION__, tickGet(), acType, carr);
    retVal = BspJacRefChHCalc(acType, carr);
    

    return retVal;
}

//获取参考通道H计算结果
UINT32 GetJacRefHRstIc(UINT32 *puiRefHRst)
{
    T_Pulm2CmacAntAdjustRspIc3* ptAcRspInfo = NULL;
    UINT8 *baseAddr = NULL;

    INPUT_POINTER_CHECK(puiRefHRst);
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    //coverity[cert_exp36_c_violation:SUPPRESS]
    ptAcRspInfo = (T_Pulm2CmacAntAdjustRspIc3*) ((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr));

    if(0 == ptAcRspInfo->acMsgHeaderRsk.ucRefHResult)
    {
        *puiRefHRst = JAC_REF_FAILED;
    }
    else
    {
        *puiRefHRst = JAC_REF_SUC;
    }
    dbgInfo("[%s], JacRefH cal result:%d \n", __FUNCTION__, *puiRefHRst);

    return BSP_OK;
}

UINT32 GetJacRefHIc(UINT32 *puiRefHData, UINT32 *puiDataLength, UINT8 *pciScale, UINT32 *puiScaleLenth)
{
    UINT8 *pcRefHAddr    = NULL;
    UINT8 *pcBaseAddr    = NULL;
    UINT8 *pcScaleAddr   = NULL;
    UINT32 uiRefHDataLen = 0;
    UINT32 uiScaleLen    = 0;

    
    INPUT_POINTER_CHECK(puiRefHData);
    INPUT_POINTER_CHECK(puiDataLength);

    pcBaseAddr = BspGetAcMemBaseAddr(); //虚拟基址
    INPUT_POINTER_CHECK(pcBaseAddr);

    uiRefHDataLen = 4 * AC_DATA_LEN * sizeof(UINT32); //JAC下，TDD、FDD均为4次迭代，每次迭代存储空间按照1024点
    pcRefHAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR;

    *puiDataLength = uiRefHDataLen;
    memcpy_s((UINT8 *)((VOID *)puiRefHData), uiRefHDataLen, pcRefHAddr, uiRefHDataLen);

    uiScaleLen = JAC_REF_H_SCALE * sizeof(INT8); //JAC下，TDD、FDD均为4次迭代，对应4次迭代的定标因子
    pcScaleAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR;

    *puiScaleLenth = uiScaleLen;
    memcpy_s(pciScale, uiScaleLen, pcScaleAddr, uiScaleLen);


    dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR: 0x%x, uiRefHDataLen:%d, uiScaleLen:%d \n", __FUNCTION__, NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR, uiRefHDataLen, uiScaleLen);
    dbgInfo("[%s]:pcBaseAddr: %p, pcRefHAddr:%p, pcScaleAddr:%p \n", __FUNCTION__, (void*)pcBaseAddr, (void*)pcRefHAddr, (void*)pcScaleAddr);
    

    return BSP_OK;
}

UINT32 SetJacRefHIc(UINT32 *puiRefHData, UINT32 uiDataLength, UINT8 *pciScale, UINT32 uiScaleLenth)
{
    UINT8 *pcRefHAddr    = NULL;
    UINT8 *pcBaseAddr    = NULL;
    UINT8 *pcScaleAddr   = NULL;
    UINT32 uiRefHDataLen = 0;
    UINT32 uiScaleLen    = 0;

    
    INPUT_POINTER_CHECK(puiRefHData);

    pcBaseAddr = BspGetAcMemBaseAddr(); //虚拟基址
    INPUT_POINTER_CHECK(pcBaseAddr);

    pcRefHAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR;
    uiRefHDataLen = uiDataLength;
    memcpy_s(pcRefHAddr, uiRefHDataLen, (UINT8 *)((VOID *)puiRefHData), uiRefHDataLen);

    pcScaleAddr = pcBaseAddr + NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR;
    uiScaleLen = uiScaleLenth;
    memcpy_s(pcScaleAddr, uiScaleLen, pciScale, uiScaleLen);

    dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR);
    dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR);
    dbgInfo("[%s]:pcBaseAddr: %p, pcRefHAddr:%p, uiRefHDataLen:%d, pcScaleAddr:%p, uiScaleLen:%d\n",
            __FUNCTION__, (void*)pcBaseAddr, (void*)pcRefHAddr, uiRefHDataLen, (void*)pcScaleAddr, uiScaleLen);
    

    return BSP_OK;
}

VOID BspSetNonStandBandFlag(UINT32 uiFlag)
{
    g_nonStandBandFlag = uiFlag;
}

UINT32 BspGetNonStandBandFlag(VOID)
{
    return g_nonStandBandFlag;
}

VOID BspSetOptNcoValue(UINT32 uiOptNco)
{
    g_nonStandOptNco = uiOptNco;
}

UINT32 BspGetOptNcoValue(VOID)
{
    return g_nonStandOptNco;
}

/* Started by AICoder, pid:q09efo5ebfd353814d290825c0be0d2fc815924d */
UINT32 SetAcNonStandBandSw(UINT32 uiSwitch, UINT32 uiBandWidth)
{
    UINT32 uiRet = 0;
    dbgInfo("[%s], uiSwitch:%d uiBandWidth:%d \n", __FUNCTION__, uiSwitch, uiBandWidth);
    uiRet = BspAcSetNonStandardBandSw(uiSwitch, uiBandWidth);
    // 更新非标准频段的标志位
    BspSetNonStandBandFlag(uiSwitch);
    return uiRet;
}
/* Ended by AICoder, pid:q09efo5ebfd353814d290825c0be0d2fc815924d */

UINT32 SetJacMode(UINT32 uiJacMode, UINT32 uiJacHandleType, UINT8 uiBitMap)
{
    g_uiJacMode = uiJacMode;
    g_uiJacHandleType = uiJacHandleType;
    g_uiJacBitMap = uiBitMap;
    dbgInfo("[%s], g_uiJacMode:%d, g_uiJacHandleType:%d, g_uiJacBitMap:0x%x \n", __FUNCTION__, g_uiJacMode, g_uiJacHandleType, g_uiJacBitMap);

    return BSP_OK;
}

UINT32 GetJacMode(VOID)
{
    dbgInfoEx("[%s], g_uiJacMode:%d \n", __FUNCTION__, g_uiJacMode);

    return g_uiJacMode;
}

UINT32 GetJacType(VOID)
{
    dbgInfoEx("[%s], g_uiJacHandleType:%d \n", __FUNCTION__, g_uiJacHandleType);

    return g_uiJacHandleType;
}

UINT8 GetJacBitMap(VOID)
{
    dbgInfoEx("[%s], g_uiJacBitMap:0x%x \n", __FUNCTION__, g_uiJacBitMap);

    return g_uiJacBitMap;
}

UINT32 BspCheckJacBitMap(UINT32 uiAntNum)
{
    UINT8  uiBitMap = 0;
    UINT32 uiAntValid = 0;
    UINT32 uiAntMapValid = 0;

    uiAntMapValid = g_acAntMapInfo.uiAcMapValid; //AC位图映射使能

    if((JAC_DISABLE == GetJacMode()) || (MAP_INFO_VALID == uiAntMapValid))
    {
        return BSP_OK;
    }

    uiBitMap = GetJacBitMap();
    uiAntValid = BIT_VAL(uiBitMap, uiAntNum);
    dbgInfo("[%s], ant:%d, uiAntValid:%d, uiBitMap:0x%x \n", __FUNCTION__, uiAntNum, uiAntValid, uiBitMap);
    if(0 == uiAntValid)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspCheckSepareBitMap(UINT32 uiAntNum)
{
    UINT32 uiAntValid = 0;
    UINT32 acCellSeparateMode = BspGetAcCellSeparateMode();
    UINT32 separateBit = BspGetSepareBitmap();
    dbgInfo("[%s], ant:%d, uiBitMap:0x%x \n", __FUNCTION__, uiAntNum, separateBit);
    
    if(AC_CELL_SEPARATE_MODE == acCellSeparateMode)
    {
        uiAntValid = BIT_VAL(separateBit, uiAntNum);
        if(0 == uiAntValid)
        {
            return BSP_ERROR;
        }  
    }
    else
    {
        //do nothing
    }

    return BSP_OK;
}

UINT32 GetJacOrgData(UINT32 uiJacType, UINT32 *puiOrgJacData, UINT32 *puiJacDataLen)
{
    UINT8 *pcBaseAddr     = NULL;
    UINT8 *ptJAcData      = NULL;
    UINT8 *ptTarAddr      = NULL;
    UINT8 *ptSrcAddr      = NULL;
    UINT32 uiDataLength   = 0;
    UINT32 uiDataLoop     = 0;

    
    INPUT_POINTER_CHECK(puiOrgJacData);
    INPUT_POINTER_CHECK(puiJacDataLen);

    pcBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);

    if(E_AC_TYPE_FDD_DL == uiJacType)
    {
        ptJAcData = pcBaseAddr + NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR;
        uiDataLength = JAC_DATA_ORG_DATA_LEN * sizeof(UINT32);
        dbgInfo("[%s]:NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR);
    }
    else
    {
        dbgErr("[%s] unsupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    //高层获取的数据为4次迭代*1024点，DSP数据摆放为4次迭代*1026点
    for(uiDataLoop = 0;uiDataLoop < JAC_ITERATIONS;uiDataLoop++)
    {
        ptTarAddr = (UINT8 *)((void *)puiOrgJacData) + (uiDataLoop * JAC_DATA_ORG_DATA_LEN * sizeof(UINT32));
        ptSrcAddr = (UINT8 *)ptJAcData + (uiDataLoop * JAC_DATA_ORG_DATA_OFFSET * sizeof(UINT32));
        memcpy_s(ptTarAddr, uiDataLength, ptSrcAddr, uiDataLength);
        *puiJacDataLen += uiDataLength;
    }
    dbgInfo("[%s]:pcBaseAddr: %p, ptJAcData:%p, uiDataLength:%d, puiJacDataLen:%d\n", __FUNCTION__, (void*)pcBaseAddr, (void*)ptJAcData, uiDataLength, *puiJacDataLen);
    

    return BSP_OK;
}

UINT32 SetJacOrgData(UINT32 uiJacType, UINT32 *puiOrgJacData, UINT32 uiJacDataLen)
{
    UINT8 *pcBaseAddr = NULL;
    UINT8 *ptJAcData  = NULL;
    UINT8 *ptTarAddr  = NULL;
    UINT8 *ptSrcAddr  = NULL;
    UINT32 uiDataLen  = 0;
    UINT32 uiDataLoop = 0;

    
    INPUT_POINTER_CHECK(puiOrgJacData);

    pcBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);

    if(E_AC_TYPE_FDD_DL == uiJacType)
    {
        ptJAcData = pcBaseAddr + NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR;
        dbgInfo("[%s]:NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR);
    }
    else
    {
        dbgErr("[%s] unsupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    //高层下发的数据为4次迭代，每次1024点，DSP数据摆放为4次迭代，每次1026点
    for(uiDataLoop = 0;uiDataLoop < JAC_ITERATIONS;uiDataLoop++)
    {
        ptTarAddr = (UINT8 *)ptJAcData + (uiDataLoop * JAC_DATA_ORG_DATA_OFFSET * sizeof(UINT32));
        ptSrcAddr = (UINT8 *)((void *)puiOrgJacData) + (uiDataLoop * JAC_DATA_ORG_DATA_LEN * sizeof(UINT32));
        uiDataLen = uiJacDataLen / JAC_ITERATIONS;
        memcpy_s((void *)ptTarAddr, uiDataLen, (void *)ptSrcAddr, uiDataLen);
        dbgInfoEx("[%s] ptTarAddrData[0]:%x,ptSrcAddrData[0]:%x\n",__FUNCTION__,((UINT32 *)ptTarAddr)[0],((UINT32 *)ptSrcAddr)[0]);
    }
    dbgInfo("[%s]:pcBaseAddr: %p, ptJAcData:%p, uiJacDataLen:%d \n", __FUNCTION__, (void*)pcBaseAddr, (void*)ptJAcData, uiJacDataLen);
    

    return BSP_OK;
}
/**********************************************JAC维测接口-BEGIN*****************************************************/
UINT32 g_uiRefHData[4096] = {0};
UINT32 g_uiRefHLen = 0;
UINT8  g_ciScaleData[4] = {0};
UINT32 g_uiScaleLen = 0;
UINT32 TestGetJacRefHIc(VOID)
{
    UINT32 point = 0;

    GetJacRefHIc(g_uiRefHData, &g_uiRefHLen, g_ciScaleData, &g_uiScaleLen);

    for(point = 0; point < g_uiRefHLen/4; point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, g_uiRefHData[point]);
    }

    for(point = 0;point < g_uiScaleLen;point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, g_ciScaleData[point]);
    }

    return BSP_OK;
}

UINT32 TestSetJacRefHIc(VOID)
{
    SetJacRefHIc(g_uiRefHData, g_uiRefHLen, g_ciScaleData, g_uiScaleLen);

    return BSP_OK;
}

UINT32 g_uiOrgJacData[4096] = {0};
UINT32 g_uiJacDataLen = 0;
UINT32 TestGetJacOrgData(UINT32 uiJacType)
{
    UINT32 point = 0;

    g_uiJacDataLen = 0;
    GetJacOrgData(uiJacType, g_uiOrgJacData, &g_uiJacDataLen);
    for(point = 0; point < g_uiJacDataLen/4; point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, g_uiOrgJacData[point]);
    }

    return BSP_OK;
}

UINT32 TestSetJacOrgData(UINT32 uiJacType)
{
    SetJacOrgData(uiJacType, g_uiOrgJacData, g_uiJacDataLen);

    return BSP_OK;
}
/**********************************************JAC维测接口-END*****************************************************/
/**********************************************RCUA新增接口-START*****************************************************/

UINT32 SetJacDspBitMap(UINT8 uiRcuaAcBitMap, UINT8 ucRcuaFlg)
{ 
    UINT8  *baseAddr = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* pAcMsgIc3;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址  /* 调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    pAcMsgIc3 = (T_Cmac2PulmAntAdjustScheInfoIc3*)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr);
    pAcMsgIc3->uiRcuaAcBitMap = uiRcuaAcBitMap;
    pAcMsgIc3->ucRcuaFlg = ucRcuaFlg;
    g_uiRcuaFlag = ucRcuaFlg;
    g_uiRcuaBitMap = uiRcuaAcBitMap;
    dbgInfo("%s:uiRcuaAcBitMap= %x, ucRcuaFlg:%d\n",__FUNCTION__, pAcMsgIc3->uiRcuaAcBitMap,pAcMsgIc3->ucRcuaFlg);
    AcFuncLog(AC_FUNC_LOG_HIGH, "%s:uiRcuaAcBitMap= %x, ucRcuaFlg:%d\n", __FUNCTION__, pAcMsgIc3->uiRcuaAcBitMap,pAcMsgIc3->ucRcuaFlg);
    return BSP_OK;
}

UINT32 GetJacDspBitMap()
{ 
    UINT8  *baseAddr = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* pAcMsgIc3;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址  /* 调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    pAcMsgIc3 = (T_Cmac2PulmAntAdjustScheInfoIc3*)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr);
    dbgInfo("%s:uiRcuaAcBitMap= %x, ucRcuaFlg:%d\n",__FUNCTION__, pAcMsgIc3->uiRcuaAcBitMap,pAcMsgIc3->ucRcuaFlg);
    return BSP_OK;
}
//Jac更新上行AC序列的标志，1为更新，0为不更新 
UINT32 g_JacConjFreqSeqUpdateFlag = 1;
VOID setJacConjFreqSeqUpdateFlag(UINT32 inPut)
{
    g_JacConjFreqSeqUpdateFlag = inPut;
}
UINT32 getJacConjFreqSeqUpdateFlag()
{
    return g_JacConjFreqSeqUpdateFlag;
}

UINT32 GetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiSeqLen)
{
    UINT8 *pcBaseAddr = NULL;
    UINT8 *ptJacConjFreqBaseSeqShareDdr  = NULL;
    UINT32 jLoop = 0;
    UINT32 uiJacSeqLen = 0;

    
    INPUT_POINTER_CHECK(puiAcSeq);

    pcBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);
    uiJacSeqLen = (uiSeqLen > IC_AC_POINT_NUM)?IC_AC_POINT_NUM:uiSeqLen;

    if(E_AC_TYPE_FDD_UL == uiJacType)
    {
        ptJacConjFreqBaseSeqShareDdr = pcBaseAddr + NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR;
        dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR);
    }
    else
    {
        dbgInfo("[%s] unSupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    memcpy_s((void *)puiAcSeq, uiJacSeqLen * sizeof(UINT32), (void *)ptJacConjFreqBaseSeqShareDdr, uiJacSeqLen * sizeof(UINT32));
    for (jLoop = 0; jLoop < uiJacSeqLen/4; jLoop++)
    {
        dbgInfoEx("[%d] puiAcSeq = 0x%08x \n", jLoop, puiAcSeq[jLoop]);
    }

    dbgInfo("[%s]:ptJacConjFreqBaseSeqShareDdr: %p, puiAcSeq:%p, uiSeqLen:%d, uiJacSeqLen:%d \n", __FUNCTION__, (void*)ptJacConjFreqBaseSeqShareDdr, (void*)puiAcSeq, uiSeqLen, uiJacSeqLen);
    

    return BSP_OK;
}

UINT32 SetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiSeqLen)
{
    UINT8 *pcBaseAddr = NULL;
    UINT8 *ptJacConjFreqBaseSeqShareDdr  = NULL;
    UINT32 uiJacSeqLen = 0;
    UINT32 jLoop = 0;
    UINT32 JacConjFreqSeqUpdateFlag =  getJacConjFreqSeqUpdateFlag();

    
    INPUT_POINTER_CHECK(puiAcSeq);

    pcBaseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(pcBaseAddr);
    uiJacSeqLen = (uiSeqLen > IC_AC_POINT_NUM)?IC_AC_POINT_NUM:uiSeqLen;

    if(E_AC_TYPE_FDD_UL == uiJacType)
    {
        ptJacConjFreqBaseSeqShareDdr = pcBaseAddr + NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR;
        dbgInfo("[%s]:NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR: 0x%x\n", __FUNCTION__, NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR);
    }
    else
    {
        dbgInfo("[%s] unsupport JacType:%d \n", __FUNCTION__, uiJacType);
        return BSP_ERROR;
    }
    memcpy_s((void *)ptJacConjFreqBaseSeqShareDdr, uiJacSeqLen * sizeof(UINT32), (void *)puiAcSeq, uiJacSeqLen * sizeof(UINT32));
    for (jLoop = 0; jLoop < uiJacSeqLen/4; jLoop++)
    {
        dbgInfoEx("[%d] puiAcSeq = 0x%08x \n", jLoop, puiAcSeq[jLoop]);
    }

    //通知DSP更新AC共轭频域基序列
    JacUpdateAcConjFreqSeq(JacConjFreqSeqUpdateFlag);
    dbgInfo("[%s]:ptJacConjFreqBaseSeqShareDdr: %p, puiAcSeq:%p, uiSeqLen:%d, uiJacSeqLen:%d \n", __FUNCTION__, (void*)ptJacConjFreqBaseSeqShareDdr, (void*)puiAcSeq, uiSeqLen, uiJacSeqLen);
    

    return BSP_OK;
}

/**********************************************RCUA维测接口-END*****************************************************/
/* Started by AICoder, pid:v300bj1aadfb225147d708e250397a13467341fa */
UINT32 BspGetAcCarrType(UINT32 uiRadioMode, UINT32 uiDeviate)
{
    UINT32 uiCarrType = 0;

    uiCarrType = (BSP_RADIO_STANDARD_UMTS == uiRadioMode) ? 0 : uiDeviate;

    if(BSP_RADIO_STANDARD_GSM == uiRadioMode)
    {
        uiCarrType = 0;//GSM默认为IF0
    }

    if(AC_ALG_TIME_ON == BspGetAcAlgTimeSw())
    {
        uiCarrType = CARR_TYPE_IF2;
    }
    dbgInfo("[%s], radioMode:%d, uiDeviate:%d, carrType:%d \n", __FUNCTION__, uiRadioMode, uiDeviate, uiCarrType);

    return uiCarrType;
}
/* Ended by AICoder, pid:v300bj1aadfb225147d708e250397a13467341fa */
UINT32 BspGetAcWgtRbNum(UINT32 uiRadioMode,UINT32 uiBandWidth,UINT32 uiCarrType)
{
    UINT32 loop = 0;
    UINT32 num  = 0;
    UINT32 acWidth = 0;
    UINT32 retVal = BSP_ERROR;

    num = (sizeof(g_acWgtInfo) / sizeof(g_acWgtInfo[0]));
    for(loop=0; loop < num;loop++)
    {
        if((uiRadioMode == g_acWgtInfo[loop].radioMode) && (uiBandWidth == g_acWgtInfo[loop].bandWidth) && (uiCarrType == g_acWgtInfo[loop].carrType))
        {
            acWidth = g_acWgtInfo[loop].rbNum;
            retVal = BSP_OK;
        }
    }
    dbgInfo("%s:uiCarrType:%d, radioMode= %#x,bandWidth=%d,acWidth=%d\n", __FUNCTION__, uiCarrType, uiRadioMode, uiBandWidth, acWidth);
    if(BSP_OK == retVal)
    {
        return acWidth;
    }

    return BSP_ERROR;
}

UINT32 GetAcWgtLenOffset(T_AcWgtLenInfo *ptAcWgtLenInfo, UINT32 *puiAcWidth, UINT32 *puiDdrOffset)
{
    UINT32 uiRadioMode = 0;
    UINT32 uiBandWidth = 0;
    UINT32 uiCarrType  = 0;
    UINT32 uiAcMode    = 0;

    INPUT_POINTER_CHECK(ptAcWgtLenInfo);
    INPUT_POINTER_CHECK(puiAcWidth);
    INPUT_POINTER_CHECK(puiDdrOffset);

    uiAcMode    = ptAcWgtLenInfo->uiAcMode;
    uiCarrType  = ptAcWgtLenInfo->uiCarrType;
    uiRadioMode = ptAcWgtLenInfo->uiRadioMode;
    uiBandWidth = ptAcWgtLenInfo->uiBandWidth;

    *puiAcWidth = BspGetAcWgtRbNum(uiRadioMode, uiBandWidth, uiCarrType);
    if(JAC_ENABLE == uiAcMode)
    {
        *puiDdrOffset = JAC_DDR_DATA_OFFSET;
    }
    else
    {
        *puiDdrOffset = AC_DDR_DATA_OFFSET;
    }

    return BSP_OK;
}

UINT32 GetAcWgtDdr(T_AC_WGT_ADDR_INFO *ptAcWgtAddr, UINT32 **uiData, UINT32 *puiDataLen, UINT32 uiWgtType)
{
    UINT32 uiLoop       = 0;
    UINT32 uiDifChipId  = 0;
    UINT32 uiDifChan    = 0;
    UINT32 uiAntNo      = 0;
    UINT32 uiAntChn     = 0;
    UINT32 uiAddrOffset = 0;
    UINT32 uiRet        = 0;
    UINT32 uiSocId      = 0;
    UINT32 uiDir        = 0;
    UINT32 uiDdrOffset  = 0;
    UINT32 uiAcWidth    = 0;
    UINT8 *pucWgtAddr   = NULL;
    UINT32 uiTaData     = 1;
    UINT32 uiTaAddrOffset = 0;
    UINT32 uiBspChn = 0;
    UINT32 antNoTmp = 0;
    UINT32 uiAntMapValid = 0;
    UINT32 uiAntTmp = 0;

    INPUT_POINTER_CHECK(ptAcWgtAddr);
    INPUT_POINTER_CHECK(*uiData);
    INPUT_POINTER_CHECK(uiData);
    INPUT_POINTER_CHECK(puiDataLen);

    uiSocId        = ptAcWgtAddr->uiSocId;
    uiDir          = ptAcWgtAddr->uiDir;
    uiDdrOffset    = ptAcWgtAddr->uiDdrOffset;
    uiAcWidth      = ptAcWgtAddr->uiAcWidth;
    pucWgtAddr     = ptAcWgtAddr->pucWgtAddr;
    dbgInfo("[%s] uiSocId:%d, uiDir:%d, uiDdrOffset:%d uiAcWidth:%d, pucWgtAddr:%p\n", __FUNCTION__, uiSocId, uiDir, uiDdrOffset, uiAcWidth, (void*)pucWgtAddr);

    uiAntMapValid = g_acAntMapInfo.uiAcMapValid;  //AC位图映射使能
    for (uiLoop = 0; uiLoop < BspGetAntNum(); uiLoop++)
    {
        if(MAP_INFO_VALID == uiAntMapValid)
        {
            uiRet = BspGetAntNumFromAcMap(uiSocId, uiDir, uiLoop, &uiAntNo,&uiAntTmp);
            RESULT_CHECK_CONTINUE_AC(uiRet);
        }
        else
        {
            antNoTmp = uiLoop+1;
            uiRet = BspGetBspChanByAntAndBandInfo(antNoTmp, BspGetBandNo(), uiDir, &uiBspChn);
            dbgInfoEx("BspGetDifInfoByRfChn antNoTmp = %d, BandNo = %d, uiBspChn = %d\n",antNoTmp,BspGetBandNo(),uiBspChn);
            RESULT_CHECK_CONTINUE_AC(uiRet);

            uiRet = BspGetDifInfoByBspChn(uiBspChn,uiDir,&uiDifChipId,&uiDifChan);
            RETURN_RESULT_CHECK(uiRet);
            dbgInfoEx("BspGetDifInfoByBspChn chan = %d, difChipId = %d, difChan = %d,socId = %d \n",uiBspChn,uiDifChipId,uiDifChan,uiSocId);
            if (uiSocId != uiDifChipId)
            {
                continue;
                dbgInfo("ant:%d not on this chip\n", uiLoop);
            }
            uiRet = BspGetAntInfoByRfChn(uiLoop, uiDir, &uiAntNo, &uiAntChn);
            RETURN_RESULT_CHECK(uiRet);
            uiAntNo = uiAntNo -1; //主控link表定义中的天线号为控制面天线号,从1开始，这里必须-1;
        }
        dbgInfo("BspGetAntInfoByRfChn chan = %d, antNo = %d, antChn = %d,socId = %d\n", uiLoop, uiAntNo, uiAntChn, uiSocId);
        
        //劈裂场景有效天线判断
        uiRet = BspCheckSepareBitMap(uiAntNo);
        RESULT_CHECK_CONTINUE_AC(uiRet);
        
        //JAC场景有前4或后四天线配置
        uiRet = BspCheckJacBitMap(uiAntNo);
        RESULT_CHECK_CONTINUE_AC(uiRet);

        uiAddrOffset = uiAntNo * uiDdrOffset * sizeof(UINT32);
        if(AC_WGT_TA == uiWgtType)
        {
            uiTaAddrOffset = AC_ANT_WGT_NUM_NR_MAX * sizeof(UINT32);
            memcpy_s((UINT8 *)((VOID *)(*uiData)), uiTaData * sizeof(UINT32), (UINT8 *)(pucWgtAddr + uiAddrOffset + uiTaAddrOffset), uiTaData * sizeof(UINT32));
            dbgInfo("uiData:0x%x \n", **uiData);
            *uiData += uiTaData;
            *puiDataLen += uiTaData * sizeof(UINT32);
            AcFuncLog(AC_FUNC_LOG_MID, "WgtGet antNo:%d, jacTaLen:%d \n", uiAntNo, uiTaData);
        }
        else
        {
            memcpy_s((UINT8 *)((VOID *)(*uiData)), uiAcWidth * sizeof(UINT32), (UINT8 *)(pucWgtAddr + uiAddrOffset), uiAcWidth * sizeof(UINT32));
            *uiData += uiAcWidth;
            *puiDataLen += uiAcWidth * sizeof(UINT32);
            AcFuncLog(AC_FUNC_LOG_MID, "WgtGet antNo:%d, wgtLen:%d \n", uiAntNo, uiAcWidth);
        }
    }
    dbgInfo("[%s], uiData:%p, puiDataLen:%d uiAddrOffset:%d \n", __FUNCTION__, (void*)*uiData, *puiDataLen, uiAddrOffset);

    return BSP_OK;
}

UINT32 BspSaveChangeAcType(UINT32 uiAcType)
{
    if((E_AC_TYPE_FDD_DL == uiAcType)||(E_AC_TYPE_DL == uiAcType))
    {
        return E_AC_TYPE_DL;
    }
    else if((E_AC_TYPE_FDD_UL == uiAcType)||(E_AC_TYPE_UL == uiAcType))
    {
        return E_AC_TYPE_UL;
    }

    dbgInfo("[%s] Change Actype fault\n",__FUNCTION__);
    return E_AC_TYPE_DL;
}

UINT32 BspSaveChangeAcRadioMode(UINT32 uiRadioMode)
{
    UINT32 uiRadioIdx = 0;
    if(RADIO_STANDARD_LTE_FDD == uiRadioMode)
    {
        uiRadioIdx = 0;
    }
    else if(RADIO_STANDARD_FDD_5G == uiRadioMode)
    {
        uiRadioIdx = 1;
    }
    else
    {
        dbgInfoEx("[%s] Change Ac RadioMode fault\n",__FUNCTION__);
        //do nothing;
    }
    
    return uiRadioIdx;
}

UINT32 BspSaveChangeAcBandNo(UINT32 uiBandNo)
{
    UINT32 uiBandNoIdx = 0;
    UINT32 i = 0;

    if(1 == g_acBandNoRedef.uiRedefFlag)
    {
        for(i=0; i< MAX_BANDNO_NUM;i++)
        {
            if(uiBandNo == g_acBandNoRedef.uiRceBandNo[i][0])
            {
                uiBandNoIdx = g_acBandNoRedef.uiRceBandNo[i][1];
                dbgInfoEx("Search BandNo [%s]\n",__FUNCTION__);
                break;
            }
        }
        dbgInfoEx("[%s],BandNo:%d Change BandNo :%d\n",__FUNCTION__,uiBandNo,uiBandNoIdx);
    }   
    else
    {
        dbgInfoEx("[%s] Change Ac BandNo fault\n",__FUNCTION__);
    }
    return uiBandNoIdx;
}

UINT32 SaveAcData(UINT32 actype, UINT32 radioMode, UINT32 carrNo)
{
    UINT32 TxOrRx           = 0;
    T_Pulm2CmacAntAdjustRspIc3* ptAcRdInfo      = NULL;
    UINT8 *pucBaseAddr                          = NULL;
    UINT32 uiRadioIdx       = 0;
    UINT32 uiBandNo = BspGetBandNo();
    UINT32 i = 0;
    UINT32 j = 0;
    UINT32 k = 0;
    UINT32 uiValidAntNum = 0;
    UINT32 uiLogicAnt    = 0;

    if((g_uiRcuaFlag  == 0)||(g_RcuaAntNoMap == 0))
    {   
        g_RcuaAntNoMap = 0;
        dbgInfoEx("Not Rcua\n");
        return BSP_ERROR;
    }

    if(uiBandNo >= MAX_BANDNO)
    {
        dbgInfo("[%s], not Serach BandNo\n",__FUNCTION__);
        uiBandNo = 0;
    }

    //g_uiRcuaBitMap UINT类型最大支持搜寻32天线
    for(i = 0; i<32;i++)
    {
        if(BIT_VAL(g_uiRcuaBitMap, i) == 1)
        {
            uiLogicAnt = i;
            break;
        }
    }

    dbgInfoEx("g_RcuaAntNoMap :%d\n",g_RcuaAntNoMap);
    for(j = 0;j<32;j++)
    {
        if(BIT_VAL(g_RcuaAntNoMap, j) == 1)
        {
            uiValidAntNum = j;
            break;
        }
    }
    TxOrRx = BspSaveChangeAcType(actype);
    dbgInfoEx("[%s] i %d, j %d", __FUNCTION__, i,j);

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    ptAcRdInfo = (T_Pulm2CmacAntAdjustRspIc3*)((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + pucBaseAddr));
    for(k=0;k<4;k++) //Rcua最大天线数为4
    {
        g_acSaveDly[TxOrRx][uiBandNo][uiRadioIdx][carrNo][uiValidAntNum + k] = ptAcRdInfo->acfillInfoRsk.afAcWgtDly[uiLogicAnt + k];
        g_acSavePha[TxOrRx][uiBandNo][uiRadioIdx][carrNo][uiValidAntNum + k] = ptAcRdInfo->acfillInfoRsk.afAcWgtPha[uiLogicAnt + k];
        g_acSaveSnr[TxOrRx][uiBandNo][uiRadioIdx][carrNo][uiValidAntNum + k] = ptAcRdInfo->acMsgBodyRsk.acchAcSinr[uiLogicAnt + k];
    }
    g_RcuaAntNoMap = 0;
    dbgInfoEx("[%s], do all \n",__FUNCTION__);
    return BSP_OK;
}

UINT32 BspGetAcSaveData(UINT32 actypeIdx, UINT32 radioIdx, UINT32 bandIdx , UINT32 carrIdx, UINT32 antMax,UINT32 flag)
{
    UINT32 i = 0;

    if((actypeIdx >= MAX_TYPEIDX)||(radioIdx >=MAX_RADIOIDX)||(bandIdx >= MAX_BANDNO)||(carrIdx >=MAX_CARRNO))
    {
        return BSP_ERROR;
    }
    if(antMax>= MAX_CHANNO)
    {
        return BSP_ERROR;
    }
    
    if(0 == flag)
    {
        for(i=0; i<antMax;i++)
        {
            dbgInfo("[%s]",__FUNCTION__);
            dbgInfo("dly:%f\n",g_acSaveDly[actypeIdx][bandIdx][radioIdx][carrIdx][i]);
        }
    }
    else if (1 == flag)
    {
        for(i=0; i<antMax;i++)
        {
            dbgInfo("[%s]",__FUNCTION__);
            dbgInfo("Phase :%f\n",g_acSavePha[actypeIdx][bandIdx][radioIdx][carrIdx][i]);
        }
    }
    else if(2 == flag)
    {
        for(i=0; i<antMax;i++)
        {
            dbgInfo("[%s]",__FUNCTION__);
            dbgInfo("snr :%d\n",g_acSaveSnr[actypeIdx][bandIdx][radioIdx][carrIdx][i]);
        }
    }
    return BSP_OK;
}

UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
{
    UINT8 *pFreqWgtAddr   = NULL;
    UINT8 *pTimeWgtAddr   = NULL;
    UINT8 *pBaseAddr      = NULL;
    UINT32 uiAcWidth      = 0;
    UINT32 uiDir          = 0;
    UINT32 uiJacMode      = 0;
    UINT32 uiDdrOffset    = 0;
    UINT32 uiRet          = 0;
    UINT32 uiPrachNum     = 0;
    UINT32 uiPrachId      = 0;
    T_AC_WGT_ADDR_INFO tAcWgtAddr               = {0};
    T_Pulm2CmacAntAdjustRspIc3 *ptAcInfo        = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3 *ptSendInfo = NULL;
    T_AcWgtLenInfo tAcWgtLenInfo                = {0};
    UINT32 uiCarrType     = 0;

    
    dbgInfoEx("socId:%d,carrNo:%d,pasteCarrFlag:%d,deviate:%d,bandWidth:%d,sampleRate:%d,radioMode:%d,actype:%d\n",\
               socId,carrNo,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,actype);
    INPUT_POINTER_CHECK(data);
    INPUT_POINTER_CHECK(trxLength);
    INPUT_POINTER_CHECK(prachRxLength);
    AcFuncLog(AC_FUNC_LOG_HIGH, "WgtGet socId:%d, acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, OptProt:%d \n",
                                 socId, actype, radioMode, bandWidth, carrNo, deviate);

    uiJacMode = GetJacMode();
    pBaseAddr = BspGetAcMemBaseAddr();//虚拟基址
    INPUT_POINTER_CHECK(pBaseAddr);

    SaveAcData(actype, radioMode, carrNo);

    if(0 == BspGetRpuNum())
    {
        dbgErr("%s get BspGetRpuNum error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(actype == E_AC_TYPE_FDD_DL)
    {
        pFreqWgtAddr = NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_ADDR + pBaseAddr; //下行频域权
        uiDir = TX;
    }
    else
    {
        pFreqWgtAddr = NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_ADDR + pBaseAddr; //上行频域权
        uiDir = RX;
    }
    uiCarrType = BspGetAcCarrType(radioMode, deviate);
    tAcWgtLenInfo.uiAcMode    = uiJacMode;
    tAcWgtLenInfo.uiBandWidth = bandWidth;
    tAcWgtLenInfo.uiCarrType  = uiCarrType;
    tAcWgtLenInfo.uiRadioMode = radioMode;

    GetAcWgtLenOffset(&tAcWgtLenInfo, &uiAcWidth, &uiDdrOffset);

    if(BSP_ERROR == uiAcWidth)
    {
        dbgErr("bandWidth input ERROR\n");
        return BSP_ERROR;
    }
    dbgInfo("[%s], uiDir:%d, acWidth:%d, uiDdrOffset:%d \n",__FUNCTION__, uiDir, uiAcWidth, uiDdrOffset);

    //频域权值
    tAcWgtAddr.uiSocId        = socId;
    tAcWgtAddr.uiDir          = uiDir;
    tAcWgtAddr.uiDdrOffset    = uiDdrOffset;
    tAcWgtAddr.uiAcWidth      = uiAcWidth;
    tAcWgtAddr.pucWgtAddr     = pFreqWgtAddr;
    dbgInfoEx("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);
    uiRet = GetAcWgtDdr(&tAcWgtAddr, &data, trxLength, AC_WGT_FREQ);
    RETURN_RESULT_CHECK(uiRet);
    dbgInfoEx("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);

    if(CARR_TYPE_IF0 == deviate)
    {
        dbgInfo("[%s] Carr If0, Not Send TimeWgt\n",__FUNCTION__);
        return BSP_OK;
    }
    
    //JAC时延TA值
    if(JAC_ENABLE == uiJacMode)
    {
        uiRet = GetAcWgtDdr(&tAcWgtAddr, &data, trxLength, AC_WGT_TA);
        RETURN_RESULT_CHECK(uiRet);
        dbgInfoEx("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);
    }

    //Prach权值
    ptAcInfo   = (T_Pulm2CmacAntAdjustRspIc3 *)((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + pBaseAddr));
    pTimeWgtAddr = (UINT8 *)((VOID *)(ptAcInfo->acfillInfoRsk.axsAcULPrachWeight));
    ptSendInfo = (T_Cmac2PulmAntAdjustScheInfoIc3*)((VOID *)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + pBaseAddr));
    uiPrachNum = ptSendInfo->ulPrachNum;
    dbgInfo("NXP_AC_MEM_CPU_RD_AC_INFO_ADDR: 0x%x\n", NXP_AC_MEM_CPU_RD_AC_INFO_ADDR);
    dbgInfo("baseAddr: %p,timeWgtAddr:%p, uiPrachNum:%d \n", (void*)pBaseAddr, (void*)pTimeWgtAddr, uiPrachNum);

    uiPrachNum = MAX(uiPrachNum, 1);
    for(uiPrachId = 0;uiPrachId < uiPrachNum;uiPrachId++)
    {
        pTimeWgtAddr = pTimeWgtAddr + (uiPrachId * 64 * sizeof(UINT32)); //数据结构axsAcULPrachWeight[2][64]
        tAcWgtAddr.uiDdrOffset    = 1; //Prach权值，每个天线一个权值
        tAcWgtAddr.uiAcWidth      = 1; //Prach权值，每个天线一个权值
        tAcWgtAddr.pucWgtAddr     = pTimeWgtAddr;
        uiRet = GetAcWgtDdr(&tAcWgtAddr, &data, prachRxLength, AC_WGT_TIME);
        RETURN_RESULT_CHECK(uiRet);
        dbgInfo("[%s], OrgDataAddr:%p uiPrachId:%d BspAntNum:%d\n", __FUNCTION__, (void*)data, uiPrachId, BspGetAntNum());
    }

    dbgInfo("[%s]SocId %d, actype %d, baseAddr %p, freqWgtAddr %p, trxLength:%d, timeWgtAddr %p, prachRxLength:%d \n",
             __FUNCTION__, socId, actype, (void*)pBaseAddr, (void*)pFreqWgtAddr, *trxLength, (void*)pTimeWgtAddr, *prachRxLength);
    

    return BSP_OK;
}

UINT32 GetAcWgtDdrIfZero(T_AC_WGT_ADDR_INFO *ptAcWgtAddr, UINT32 **uiData, UINT32 *puiDataLen)
{
    UINT32 uiLoop       = 0;
    UINT32 uiAddrOffset = 0;
    UINT32 uiDdrOffset  = 0;
    UINT32 uiAcWidth    = 0;
    UINT8 *pucWgtAddr   = NULL;
    UINT32 uiAcValidNum = 0;
    T_UpAcValidAntInfo tUpAcValidAntInfo = {0};

    INPUT_POINTER_CHECK(ptAcWgtAddr);
    INPUT_POINTER_CHECK(*uiData);
    INPUT_POINTER_CHECK(uiData);
    INPUT_POINTER_CHECK(puiDataLen);

    uiDdrOffset    = ptAcWgtAddr->uiDdrOffset;
    uiAcWidth      = ptAcWgtAddr->uiAcWidth;
    pucWgtAddr     = ptAcWgtAddr->pucWgtAddr;
    uiAcValidNum   = GetAcVaildAntNum(&tUpAcValidAntInfo);
    dbgInfo("[%s] uiDdrOffset:%d uiAcWidth:%d, pucWgtAddr:%p\n", __FUNCTION__, uiDdrOffset, uiAcWidth, (void*)pucWgtAddr);
    dbgInfo("[%s] uiAcValidNum:%d\n", __FUNCTION__, uiAcValidNum);

    for (uiLoop = 0; uiLoop < uiAcValidNum; uiLoop++)
    {       
        uiAddrOffset = uiLoop * uiDdrOffset * sizeof(UINT32);

        memcpy_s((UINT8 *)((VOID *)(*uiData)), uiAcWidth * sizeof(UINT32), (UINT8 *)(pucWgtAddr + uiAddrOffset), uiAcWidth * sizeof(UINT32));
        *uiData += uiAcWidth;
        *puiDataLen += uiAcWidth * sizeof(UINT32);
        AcFuncLog(AC_FUNC_LOG_MID, "WgtGet antNo:%d, wgtLen:%d \n", uiLoop, uiAcWidth);

    }
    dbgInfo("[%s], uiData:%p, puiDataLen:%d uiAddrOffset:%d \n", __FUNCTION__, (void*)*uiData, *puiDataLen, uiAddrOffset);

    return BSP_OK;
}

/* Started by AICoder, pid:na422a639d3744714e750944e05b975634436f17 */
UINT32 GetAcWgtIcIfZero(UINT32 bandWidth, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength)
{
    UINT8 *pFreqWgtAddr   = NULL;
    UINT8 *pBaseAddr      = NULL;
    UINT32 uiAcWidth      = 0;
    UINT32 uiDdrOffset    = 0;
    UINT32 uiRet          = 0;
    UINT32 uiCarrType     = 0;

    T_AC_WGT_ADDR_INFO tAcWgtAddr               = {0};

    dbgInfoEx("bandWidth:%d,radioMode:%d,actype:%d\n",\
               bandWidth,radioMode,actype);
    INPUT_POINTER_CHECK(data);
    INPUT_POINTER_CHECK(trxLength);

    AcFuncLog(AC_FUNC_LOG_HIGH, "WgtGet acType:%d, radioMode:%d, bandWidth:%d \n",
                                 actype, radioMode, bandWidth);

    pBaseAddr = BspGetAcMemBaseAddr();//虚拟基址
    INPUT_POINTER_CHECK(pBaseAddr);

    if(actype == E_AC_TYPE_FDD_DL)
    {
        pFreqWgtAddr = NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_ADDR + pBaseAddr; //下行频域权
    }
    else
    {
        pFreqWgtAddr = NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_ADDR + pBaseAddr; //上行频域权
    }

    uiDdrOffset = AC_DDR_DATA_OFFSET;

    uiAcWidth = BspGetAcWgtRbNum(radioMode, bandWidth, uiCarrType);

    if(BSP_ERROR == uiAcWidth)
    {
        dbgErr("bandWidth input ERROR\n");
        return BSP_ERROR;
    }
    dbgInfo("[%s], acWidth:%d, uiDdrOffset:%d \n",__FUNCTION__, uiAcWidth, uiDdrOffset);

    //频域权值
    tAcWgtAddr.uiDdrOffset    = uiDdrOffset;
    tAcWgtAddr.uiAcWidth      = uiAcWidth;
    tAcWgtAddr.pucWgtAddr     = pFreqWgtAddr;
    dbgInfoEx("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);
    uiRet = GetAcWgtDdrIfZero(&tAcWgtAddr, &data, trxLength);
    RETURN_RESULT_CHECK(uiRet);
    dbgInfoEx("[%s], OrgDataAddr:%p\n", __FUNCTION__, (void*)data);

    return BSP_OK;
}
/* Ended by AICoder, pid:na422a639d3744714e750944e05b975634436f17 */

 UINT32 GetVswrValueIc(T_AcVswrValue *acVswrValue)
 {
    return BSP_OK;
 }


//设置AC权值
UINT32 SetAcWgtIc(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32 trxLength, UINT32 prachRxLength)
{
    //IC从片做
    return BSP_OK;
}

UINT32 GetAcVaildAntNum(T_UpAcValidAntInfo* ptAcValidAntInfo)
{
    if(NULL == ptAcValidAntInfo)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo(" g_uiAcValidAntNum = %d \n",g_uiAcValidAntNum);
    return g_uiAcValidAntNum;
}

UINT32 SetAcVaildAntNum(UINT32 data, T_UpAcValidAntInfo* ptAcValidAntInfo)
{
    if(NULL == ptAcValidAntInfo)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    g_uiAcValidAntNum = data;
    dbgInfo(" g_uiAcValidAntNum = %d \n",g_uiAcValidAntNum);
    return BSP_OK; 
}

UINT32 BspPrintAcMsgRecvInfo(UINT32 mode)
{
    T_Pulm2CmacAntAdjustRspIc3* acInfoIc4 = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* acInfoSendIc4 = NULL;
    UINT8 *baseAddr = NULL;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    if ((UINT32)0 == mode)
    {
        //coverity[cert_exp36_c_violation:SUPPRESS]
        acInfoIc4 = (T_Pulm2CmacAntAdjustRspIc3*)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr);
        //coverity[cert_exp39_c_violation:SUPPRESS]
        dbgInfo("[%s]uiCellId:%d,uwACType:%d,uwRadioMode:%d\n",__FUNCTION__,acInfoIc4->acMsgHeaderRsk.uiCellId,acInfoIc4->acMsgHeaderRsk.uwACType,acInfoIc4->acMsgHeaderRsk.uwRadioMode);
    }
    else
    {
        //coverity[cert_exp36_c_violation:SUPPRESS]
        acInfoSendIc4 = (T_Cmac2PulmAntAdjustScheInfoIc3*)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr);
        //coverity[cert_exp39_c_violation:SUPPRESS]
        dbgInfo("[%s]mode:%d,uiCellId:%d,uwACType:%d,uwRadioMode:%d\n",__FUNCTION__,mode,acInfoSendIc4->acMsgHeaderReq.uiCellId,acInfoSendIc4->acMsgHeaderReq.uwACType,acInfoSendIc4->acMsgHeaderReq.uwRadioMode);
    }

    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspWriteTxAcMsg
 * 功能描述:将oam传下来的信令消息写入共享内存
 * 输入参数: ucmode=0,   tx message;  ucmode = 1, rx message
                            pdata : 传入数据地址
                            uLength:传入数据长度
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                   牛彦茹    创建
 **************************************************************************/
UINT32 WriteAcMsg(UINT8 mode, UINT8 *pdata, UINT32 length)
{
    UINT8* dstAddr   = NULL;
    UINT8* srcAddr   = NULL;
    UINT32 dataSize  = 0;
    UINT8  *baseAddr = NULL;
    UINT32 retVal    = BSP_OK;

    dbgInfoEx("[%s](in): tick = %d, mode:%d, length:%d\n",__FUNCTION__,tickGet(),mode,length);
    INPUT_POINTER_CHECK(pdata);

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    if (0 == mode)//CPU读DDR存的消息
    {
        srcAddr = NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr;
        dstAddr = pdata;
        dataSize = length;
    }
    else          //CPU往DDR写消息
    {
        srcAddr = pdata;
        dstAddr = NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr;
        dataSize = length;
    }
    memcpy_s((VOID*)dstAddr, dataSize, (VOID*)srcAddr, dataSize);

    retVal = BspPrintAcMsgRecvInfo(mode);
    dbgInfo("[%s]mode %d(1:wr, 0:rd), baseAddr %p, srcAddr %p, dstAddr %p, size 0x%08X\n",\
             __FUNCTION__, mode, (void*)baseAddr, (void*)srcAddr, (void*)dstAddr, dataSize);
    retVal = AcFuncDspAddrInfo(mode);
    RETURN_RESULT_CHECK(retVal);
    

    return retVal;
}

UINT32 GetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    UINT32 syncTimeVal = 0;
    INPUT_POINTER_CHECK(syncTime);

    syncTimeVal = IcHalGetFrameNo();
    dbgInfo("[%s](in): tick = %d, acType:%d, syncType:%d, syncTimeVal:%d \n",__FUNCTION__, tickGet(), acType, syncType, syncTimeVal);

    (*syncTime) = syncTimeVal;
    AcFuncLog(AC_FUNC_LOG_HIGH, "SyncGet acType:%d, frNum:%d \n", acType, syncTimeVal);
    

    return BSP_OK;
}

UINT32 SetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32 syncTime, UINT32 bitMap)
{
    return 0;
}

UINT32 SetAcParaIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 refChn,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{
    return 0;
}

UINT32 GetAcCatchDataSta(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{
    return 0;
}

UINT32 BspSetAcCarrCfg(T_AcCarrCfgNxp* pCarrCfg)
{
    INPUT_POINTER_CHECK(pCarrCfg);

    UINT32 retVal = 0;
    memcpy_s((void*)&(g_acCarrCfgNxp),sizeof(T_AcCarrCfgNxp),(void*)pCarrCfg,sizeof(T_AcCarrCfgNxp));
    dbgInfo("[%s] carrNo%d, radioMode%d, carrFreq(kHz)%d, bandWidth(MHz)%d,bandNo:%d\n",__FUNCTION__,pCarrCfg->carrNo,pCarrCfg->radioMode,pCarrCfg->carrFreq,pCarrCfg->bandWidth,BspGetBandNo());


    retVal = BspAcBandInfoIc42(pCarrCfg->carrNo,pCarrCfg->radioMode ,pCarrCfg->carrFreq, pCarrCfg->bandWidth, BspGetBandNo());
    
    dbgInfo("[%s],retVal%d\n ",__FUNCTION__,  retVal);
    // RESULT_CHECK_CONTINUE(retVal);
    return BSP_OK;
}

UINT32 showAcCarrCfg()
{
    dbgInfo("carrNo%d, radioMode%d, carrFreq(kHz)%d, bandWidth(MHz)%d, bandNo:%d\n",g_acCarrCfgNxp.carrNo,g_acCarrCfgNxp.radioMode,g_acCarrCfgNxp.carrFreq,g_acCarrCfgNxp.bandWidth, g_acCarrCfgNxp.bandNo);

    return BSP_OK;
}

UINT32 BspInitAcModuleFunc(VOID)
{
    T_AcFunc *pAcModule = NULL;

    pAcModule = (T_AcFunc *)BspGetAcModuleInfo();

    pAcModule->pDevInit               = AcDataInit;
    pAcModule->pWrMsg                 = WriteAcMsg;

    pAcModule->pCalAcSeqIc4           = CalAcSeqIc;//计算AC序列
    pAcModule->pChkAcSeqIc            = ChkAcSeqIc;//查询AC序列的计算结果
    pAcModule->pGetAcSeqIcNew         = GetAcSeqIc;//获取AC序列
    pAcModule->pSetAcSeqIc            = SetAcSeqIc;//设置AC序列

    pAcModule->pSendHaulBackAcSeqIc   = SendHaulBackAcSeqIc;//回收的AC序列传给AC DSP

    pAcModule->pSendFwdRevDataToDsp   = SendFwdRevDataToDsp;//将FWD或REV数据传给AC DSP

    pAcModule->pCalAcWgtIc            = CalAcWgtIc;//计算AC权值
    pAcModule->pChkAcWgtIc            = ChkAcWgtIc;//查询AC权值的计算结果

    pAcModule->pGetAcWgtIc            = GetAcWgtIc;
    pAcModule->pGetAcWgtIcIfZero      = GetAcWgtIcIfZero;
    
    pAcModule->pGetVswrValueIc        = GetVswrValueIc;
    pAcModule->pSetAcWgtIc            = SetAcWgtIc;//设置AC权值

    pAcModule->pGetAcSyncTime         = GetAcSyncTime;     //获取AC序列/权值同步时刻
    pAcModule->pSetAcSyncTime         = SetAcSyncTime;     //设置AC序列/权值同步时刻

    pAcModule->pSetAcParaIc           = SetAcParaIc;       //启停AC，包括设置参考通道
    pAcModule->pGetAcCatchDataSta     = GetAcCatchDataSta; //查询AC采数是否完成

    //Jac新增
    pAcModule->pCalJacRefHIc          = CalJacRefHCalcIc; //计算参考通道H
    pAcModule->pGetJacRefHRstIc       = GetJacRefHRstIc; //获取参考通道H计算结果
    pAcModule->pGetJacRefHIc          = GetJacRefHIc; //获取参考通道H
    pAcModule->pSetJacRefHIc          = SetJacRefHIc; //下发参考通道H
    pAcModule->pSetJacMode            = SetJacMode;//下发JAC模式和JAC发采数选择
    pAcModule->pGetJacOrgData         = GetJacOrgData; //获取JAC原始数据
    pAcModule->pSetJacOrgData         = SetJacOrgData; //下发JAC原始数据

     //RCUA新增 
    pAcModule->pSetJacDspBitMap       = SetJacDspBitMap; //APP向DSP配置位图
    pAcModule->pGetJacConjFreqBaseSeq = GetJacConjFreqBaseSeq; //RCUA上行AC用，校准盒子的APP获取AC基序列，上报给BBU OAM
    pAcModule->pSetJacConjFreqBaseSeq = SetJacConjFreqBaseSeq; //RCUA上行AC用，APP通知RRU0，RRU1的DSP替换校准盒子生成的基序列

    pAcModule->pBspSetNonStandardSw = SetAcNonStandBandSw; /* 非标带宽切换开关 */
    //时域法切换开关
    pAcModule->pBspSetAcAlgTimeSw     = BspSetAcAlgTimeSw;

    pAcModule->pBspGetChanDelay       = BspGetRcuaChanTimeDly;
    pAcModule->pBspGetChanPhase       = BspGetRcuaChanPhase;
    pAcModule->pBspGetChanSnr         = BspGetRcuaChanSnr;

    pAcModule->pBspGetAcVaildAntNum       = GetAcVaildAntNum;
    pAcModule->pBspSetAcVaildAntNum       = SetAcVaildAntNum;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetAcDspSwTaTc
 * 功能描述: 从DSP获取RTT中AAU计算的AC环回时延值(RTT)
 *                第2次上行AC之后读取该值才有效
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年08月26日 xuping    创建
 **************************************************************************/
 INT16 BspGetAcDspSwTaTc(VOID)
{
    T_Pulm2CmacAntAdjustRspIc3* acInfoIc3 = NULL;
    UINT8 * baseAddr = NULL;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return (INT16)BSP_ERROR;
    }
    acInfoIc3 = (T_Pulm2CmacAntAdjustRspIc3*)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + baseAddr);

    dbgInfo("acInfoIc3 Addr: %p, uiVersionNo 0x%08X, swTaTc 0x%08X\n",\
        (void*)acInfoIc3, acInfoIc3->acMsgHeaderRsk.uiVersionNo, acInfoIc3->acMsgBodyRsk.swTaTc);

    return acInfoIc3->acMsgBodyRsk.swTaTc;
}

/**************************************************************************
 * 函数名称: BspGetCellFreq
 * 功能描述: 获取100M小区中心频点(RTT)
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: 100M小区中心频点
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年08月26日 xuping    创建
 **************************************************************************/
 UINT32 BspGetCellFreq(VOID)
{
    UINT8  *baseAddr = NULL;
    T_Cmac2PulmAntAdjustScheInfoIc3* pAcMsgIc3;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))//虚拟基址  /* 调整为 BspGetAcDspMemBaseAddr, 用于IC A53与AC DSP共享内存基址*/
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    pAcMsgIc3 = (T_Cmac2PulmAntAdjustScheInfoIc3*)(NXP_AC_MEM_CPU_WR_AC_INFO_ADDR + baseAddr);

    //打印出从APP下发的小区频点
    dbgInfo("Get From App CellFreq = 0x%08X\n",s_ulCellFre);

    //打印出从DDR读取的小区频点
    dbgInfo("Get From DDR CellFreq = 0x%08X\n, AcMsgIc3 Addr: %p,  ",pAcMsgIc3->ulCellFreq, (void*)pAcMsgIc3);

    return pAcMsgIc3->ulCellFreq;
}

UINT32 GetdGp2Ac(UINT32 acType, UINT32 radio,DOUBLE* Gp2Ac)
{
    return BSP_OK;
}

UINT32 GetdGp2AcEnd(UINT32 acType, UINT32 radio, DOUBLE* Gp2AcEnd)
{
    return BSP_OK;
}

UINT32  BspGetRadioModeValue(VOID)
{
    return BSP_OK;
}


//1、 新增函数，查询AC执行状态，（DSP记录的时候，执行记录一个标志， 执行并成功记为另外一个标志
UINT32 BspGetCarrDoAcState(UINT32 uiAcType,UINT32 uiCarrNo,UINT32 uiRaidoMode, UINT32 uiBandNo)
{
    T_Pulm2CmacAntAdjustRspIc3* ptAcRdInfo      = NULL;
    UINT8 *pucBaseAddr                          = NULL;

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))//虚拟基址
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
 
    ptAcRdInfo = (T_Pulm2CmacAntAdjustRspIc3*)((VOID *)(NXP_AC_MEM_CPU_RD_AC_INFO_ADDR + pucBaseAddr));
    
    dbgInfoEx("[%s] auiAcDoAcState = %d\n ",__FUNCTION__,ptAcRdInfo->auiAcDoAcState[uiAcType][uiBandNo][uiRaidoMode][uiCarrNo]);
    dbgInfoEx("[%s] uiAcType %d, uiBandNo %d, uiRaidoMode %d, uiCarrNo %d \n ",__FUNCTION__, uiAcType,uiBandNo,uiRaidoMode,uiCarrNo);
    return ptAcRdInfo->auiAcDoAcState[uiAcType][uiBandNo][uiRaidoMode][uiCarrNo];
}

UINT32 BspGetRcuaChanTimeDly(T_AcRepDspPara *ptAcReqDspPara,INT32 *piTimeDly)
{
    UINT32 uiAcTypeIdx = 0;
    UINT32 uiRadioModeIdx = 0;
    UINT32 uiBandNoIdx = 0;
    UINT32 uiResult = 0;
    FLOAT  fTmp = 0.0;

    INPUT_POINTER_CHECK(ptAcReqDspPara);

    uiAcTypeIdx = BspSaveChangeAcType(ptAcReqDspPara->uiAcType);
    uiRadioModeIdx = BspSaveChangeAcRadioMode(ptAcReqDspPara->uiRadioMode);
    uiBandNoIdx = BspSaveChangeAcBandNo(ptAcReqDspPara->uiBandNo);

    uiResult = BspGetCarrDoAcState(uiAcTypeIdx,ptAcReqDspPara->uiCarrNo,uiRadioModeIdx, uiBandNoIdx);
    if((0 == uiResult)||(BSP_ERROR == uiResult))
    {
        dbgInfoEx("[%s] _cannot get\n", __FUNCTION__);
        return BSP_ERROR;
    }

    UINT32 TxOrRxdir = 0;
    UINT32 antNo = 0;
    UINT32 antChn = 0;
    UINT32 uiRet = 0 ;
    TxOrRxdir = (E_AC_TYPE_FDD_DL == ptAcReqDspPara->uiAcType) ? (UINT32)TX : (UINT32)RX; //上下行类型

    uiRet = BspGetAntInfoByRfChn(ptAcReqDspPara->uiChan,TxOrRxdir, &antNo,&antChn);
    RETURN_RESULT_CHECK(uiRet);
    antNo = antNo -1;

    fTmp = g_acSaveDly[uiAcTypeIdx][uiBandNoIdx][uiRadioModeIdx][ptAcReqDspPara->uiCarrNo][antNo];

    *piTimeDly = (INT32)(fTmp);

    dbgInfoEx("[%s], *piTimeDly %d, ftmp:%f\n",__FUNCTION__, *piTimeDly,fTmp);

    return BSP_OK;
}

UINT32 BspGetRcuaChanSnr(T_AcRepDspPara *ptAcReqDspPara,INT32 *piSnr)
{
    UINT32 uiAcTypeIdx = 0;
    UINT32 uiRadioModeIdx = 0;
    UINT32 uiBandNoIdx = 0;
    UINT32 uiResult = 0;
    UINT32 TxOrRxdir = 0;
    UINT32 antNo = 0;
    UINT32 antChn = 0;
    UINT32 uiRet = 0 ;
    
    INPUT_POINTER_CHECK(ptAcReqDspPara);

    uiAcTypeIdx = BspSaveChangeAcType(ptAcReqDspPara->uiAcType);
    uiRadioModeIdx = BspSaveChangeAcRadioMode(ptAcReqDspPara->uiRadioMode);
    uiBandNoIdx = BspSaveChangeAcBandNo(ptAcReqDspPara->uiBandNo);

    uiResult = BspGetCarrDoAcState(uiAcTypeIdx,ptAcReqDspPara->uiCarrNo,uiRadioModeIdx, uiBandNoIdx);
    if((0 == uiResult)||(BSP_ERROR == uiResult))
    {
        dbgInfoEx("[%s] _cannot get\n", __FUNCTION__);
        return BSP_ERROR;
    }

    TxOrRxdir = (E_AC_TYPE_FDD_DL == ptAcReqDspPara->uiAcType) ? (UINT32)TX : (UINT32)RX; //上下行类型
    uiRet = BspGetAntInfoByRfChn(ptAcReqDspPara->uiChan,TxOrRxdir, &antNo,&antChn);
    RETURN_RESULT_CHECK(uiRet);
    antNo = antNo -1;

    *piSnr = (INT32)(g_acSaveSnr[uiAcTypeIdx][uiBandNoIdx][uiRadioModeIdx][ptAcReqDspPara->uiCarrNo][antNo]);
    dbgInfoEx("[%s], acchAcSinr %d\n",__FUNCTION__, *piSnr);

    return BSP_OK;
}

UINT32 BspGetRcuaChanPhase(T_AcRepDspPara *ptAcReqDspPara,INT32 *piPhase)
{
    UINT32 uiAcTypeIdx = 0;
    UINT32 uiRadioModeIdx = 0;
    UINT32 uiBandNoIdx = 0;
    UINT32 uiResult = 0;
    FLOAT fTmpPhase = 0.0f;
    UINT32 TxOrRxdir = 0;
    UINT32 antNo = 0;
    UINT32 antChn = 0;
    UINT32 uiRet = 0 ;

    INPUT_POINTER_CHECK(ptAcReqDspPara);

    uiAcTypeIdx = BspSaveChangeAcType(ptAcReqDspPara->uiAcType);
    uiRadioModeIdx = BspSaveChangeAcRadioMode(ptAcReqDspPara->uiRadioMode);
    uiBandNoIdx = BspSaveChangeAcBandNo(ptAcReqDspPara->uiBandNo);

    uiResult = BspGetCarrDoAcState(uiAcTypeIdx,ptAcReqDspPara->uiCarrNo,uiRadioModeIdx, uiBandNoIdx);
    if((0 == uiResult)||(BSP_ERROR == uiResult))
    {
        dbgInfoEx("[%s] _cannot get\n", __FUNCTION__);
        return BSP_ERROR;
    }

    TxOrRxdir = (E_AC_TYPE_FDD_DL == ptAcReqDspPara->uiAcType) ? (UINT32)TX : (UINT32)RX; //上下行类型

    uiRet = BspGetAntInfoByRfChn(ptAcReqDspPara->uiChan,TxOrRxdir, &antNo,&antChn);
    RETURN_RESULT_CHECK(uiRet);
    antNo = antNo -1;

    fTmpPhase = g_acSavePha[uiAcTypeIdx][uiBandNoIdx][uiRadioModeIdx][ptAcReqDspPara->uiCarrNo][antNo];

    *piPhase = (INT32)(fTmpPhase) ; 
    dbgInfoEx("[%s], *piPhase %d, ftmp:%f\n",__FUNCTION__, *piPhase,fTmpPhase);

    return BSP_OK;
}

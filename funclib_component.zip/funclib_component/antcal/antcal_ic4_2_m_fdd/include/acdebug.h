#ifndef FUNCLIB_ACDEBUG_H_INCLUDED
#define FUNCLIB_ACDEBUG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "dsp_dbg.h"

#define AC_FUNC_LOG_MAX_STRING ((UINT32)100) //绝对路径最大字符数
#define AC_FUNC_LOG_RST_SUCCES 0
#define AC_FUNC_LOG_FILE_MAX 10

enum
{
    AC_FUNC_LOG_HIGH = 0,
    AC_FUNC_LOG_MID,
    AC_FUNC_LOG_LOW
};

enum
{
    AC_DDR_HANDLE_READ = 0,
    AC_DDR_HANDLE_WRITE
};

#define ZTE_SECURITY_FUNC_CHECK(iRet)                                                             \
    {                                                                                             \
        if (BSP_FAIL == (INT32)(iRet))                                                            \
        {                                                                                         \
            dbgErr("[%s], line: %u, zte_s func iRet'%d Error \n", __FUNCTION__, __LINE__, (iRet));\
            return (iRet);                                                                        \
        }                                                                                         \
    }

INT32 AcFuncLog(UINT32 logLevel, const CHAR *format, ...);
VOID BspRecordLastAcRst(UINT32 uiAcRst);
UINT32 BspHandleAcFuncLog(VOID);
UINT32 AcFuncDspAddrInfo(UINT32 uiMode);

#ifdef __cplusplus
}
#endif
#endif /*endif FUNCLIB_ACDEBUG_H_INCLUDED*/

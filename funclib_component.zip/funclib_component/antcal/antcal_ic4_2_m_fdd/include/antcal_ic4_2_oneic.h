/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : antcal.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了天线校正接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 
* 修改日戳: 2019-03-21
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _ANTCAL_IC4_2_FDD_H_
#define _ANTCAL_IC4_2_FDD_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "antcalapi.h"
#include "pub_typedef.h"

#define KXCPSW_AC_DEV                    "/dev/cpsw_ac"
#define CPSW_AC_DATA_GET                (0x55)
#define CPSW_AC_START_SET               (0x66)  
#define AC_SIZE_1K                      (1024)
#define AC_SIZE_512K                    (AC_SIZE_1K*512)
#define AC_SIZE_1M                      (AC_SIZE_1K*1024)
#define AC_SIZE_1G                      (AC_SIZE_1M*1024)
#define AC_SIZE_H_OFFSET                (0x70000)
#define AC_SIZE_JAC_CONJ_FREQ_SEQ_OFFSET      (0x75000)
#define AC_CELL_SEPARATE_MODE     1

#define GSM_BANDWIDTH_MHz       0

/*********** NXP主片AC数据在共享内存中的地址和大小定义 ***********
0x0000_0000~0x7FFF_FFFF  0GB~2GB      系统外设
0x8000_0000~0xBFFF_FFFF  2GB~3GB      小系统 + MGR
0xC000_0000~0xCFFF_FFFF  2GB~2GB+256M AC进程 + A53/AC共享内存空间
*****************************************************************/
#define NXP_AC_MEM_ADDR_BASE                   AC_SIZE_1G*3  //绝对地址3GB
//DSP自己使用的偏移地址
#define NXP_AC_MEM_DSP_UL_ORG_DATA_ADDR        0              //CPU读取DSP存储的上行AC数据 地址 0x0000_0000
#define NXP_AC_MEM_DSP_UL_ORG_DATA_SIZE        16*8*1026*4    //CPU读取DSP存储的上行AC数据大小
#define NXP_AC_MEM_DSP_DL_ORG_DATA_ADDR        10*AC_SIZE_1M  //CPU读取DSP存储的下行AC数据 地址 0x00A0_0000
#define NXP_AC_MEM_DSP_DL_ORG_DATA_SIZE        16*1026*4      //CPU读取DSP存储的下行AC数据大小

//上行频域权值的偏移地址
#define NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_ADDR  12*AC_SIZE_1M //CPU读取DSP存储的上行频域权 地址 0x00C0_0000
#define NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_SIZE  64*273*4      //CPU读取DSP存储的上行频域权 大小
//下行频域权值的偏移地址
#define NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_ADDR  13*AC_SIZE_1M //CPU读取DSP存储的下行频域权 地址 0x00D0_0000
#define NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_SIZE  64*273*4      //CPU读取DSP存储的下行频域权 大小
//参考通道信道估计
#define NXP_AC_MEM_CPU_RD_REF_AC_H_ADDR        13*AC_SIZE_1M + AC_SIZE_H_OFFSET //CPU读取DSP存储的参考通道H 地址 0x00D7_0000
#define NXP_AC_MEM_CPU_RD_REF_AC_H_SIZE        4*1024*4                         //CPU读取DSP存储的参考通道H 大小

//参考通道信道估计
#define NXP_AC_MEM_CPU_RD_REF_SCALE_ADDR       13*AC_SIZE_1M + AC_SIZE_H_OFFSET + 4*1024*4 //CPU读取DSP存储的H定标因子 地址 0x00D7_4000
#define NXP_AC_MEM_CPU_RD_REF_SCALE_SIZE       4                                           //CPU读取DSP存储的H定标因子 大小

//AC频域定点基序列的偏移地址
#define NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_ADDR  13*AC_SIZE_1M + AC_SIZE_JAC_CONJ_FREQ_SEQ_OFFSET//CPU读取DSP计算出来的AC频域定点基序列 地址 0x00D7_5000
#define NXP_AC_MEM_CPU_RD_JAC_CONJ_FREQ_SEQ_SIZE  1024*4     
//AC序列的偏移地址 
#define NXP_AC_MEM_CPU_RD_AC_SEQ_ADDR          13*AC_SIZE_1M + AC_SIZE_512K//CPU读取DSP计算出来的AC发送序列 地址 0x00D8_0000
//AC序列的大小
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024     1024*4    //CPU读取DSP计算出来的AC发送序列 大小
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_768      768*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_512      512*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_384      384*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_256      256*4

//载波拼接拆分标志
enum
{
    CARR_NOT_PASTE = 0,
    CARR_IS_PASTE  = 1,
    CARR_IS_SPLIT  = 2
};

enum JAC_HANDLE_TYPE
{
    JAC_SEND_DATA = 0,
    JAC_CATCH_DATA,
    JAC_SEND_CATCH_DATA
};

enum JAC_EN_FLAG
{
    JAC_DISABLE = 0,
    JAC_ENABLE
};

enum JAC_REF_RST
{
    JAC_REF_SUC = 0,
    JAC_REF_FAILED
};

enum AC_WGT_TYPE
{
    AC_WGT_FREQ = 0,
    AC_WGT_TIME,
    AC_WGT_TA
};

enum CARR_TYPE
{
    CARR_TYPE_IF0 = 0,
    CARR_TYPE_IF1,
    CARR_TYPE_IF2 //SDR LTE IF0载波，按照时域法补偿
};

//重置后bandNo索引
enum
{
    CALC_BANDNO_0 = 0,
    CALC_BANDNO_1,
    CALC_BANDNO_2,
    CALC_BANDNO_3,
    CALC_BANDNO_4,
};

#define MAX_BANDNO_NUM      12

enum AC_ALG_TIME_SW
{
    AC_ALG_TIME_OFF = 0,
    AC_ALG_TIME_ON,
};

#define AC_DATA_LEN 1024
#define AC_DDR_DATA_OFFSET    273
#define JAC_DDR_DATA_OFFSET   274
#define JAC_DATA_ORG_DATA_LEN 1024
#define JAC_DATA_ORG_DATA_OFFSET 1026
#define JAC_ITERATIONS 4
#define JAC_REF_H_SCALE 4

#define MAX_TYPEIDX     2
#define MAX_CARRNO     16
#define MAX_CHANNO     64
#define MAX_BANDNO      6
#define MAX_RADIOIDX    2

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

//下面定义对应结构体 T_Cmac2PulmAntAdjustScheInfo 这是APP发给BSP并写共享内存的DSP需要的信息
//的偏移地址
#define NXP_AC_MEM_CPU_WR_AC_INFO_ADDR         14*AC_SIZE_1M //CPU写DSP需要的各种AC计算参数 地址0x00E0_0000
#define NXP_AC_MEM_CPU_WR_AC_INFO_SIZE         0x12D43       //CPU写DSP需要的各种AC计算参数 大小
//下面定义对应结构体T_Pulm2CmacAntAdjustRsp 这是DSP写入共享内存BSP需要的信息，包含prach权
//的偏移地址
#define NXP_AC_MEM_CPU_RD_AC_INFO_ADDR         15*AC_SIZE_1M //CPU读DSP存储的恢复信息，包括prach权 地址0x00F0_0000
#define NXP_AC_MEM_CPU_RD_AC_INFO_SIZE         0x866         //CPU读DSP存储的恢复信息，包括prach权 大小

/*********** IC A53与R8共享内存中的地址和大小定义 ***********
0x0000_0000~0x033F_FFFF  0MB  ~ 52MB    R8的程序和业务代码空间
0x0340_0000~0x03BF_FFFF  52MB ~ 60MB    A53与R8的其它共享空间
0x03C0_0000~0x03FF_FFFF  60MB ~ 64MB    A53与R8的AC共享空间

*****************************************************************/
#define IC_AC_RETRY_TIME 16
#define IC_AC_ROUND_TIME 9
#define IC_AC_POINT_NUM  1024

//IC A53与R8共享内存起始和大小
#define IC_AC_SHARE_MEM_ADDR_BASE                AC_SIZE_1M*60   //绝对地址60MB
#define IC_AC_SHARE_MEM_ADDR_SIZE                AC_SIZE_1M*4    //大小是4M

//下行校正采数:16轮重复迭代*每轮9次发完64T(每次8发1收)*采数是1024个点*4字节
//大小为16*9*1024*4Bytes = 0x0009_0000 = 576K
#define IC_AC_SHARE_MEM_DL_AC_CATCH_DATA_ADDR    0               //偏移地址是0,绝对地址60MB
#define IC_AC_SHARE_MEM_DL_AC_CATCH_DATA_SIZE    \
        IC_AC_RETRY_TIME*IC_AC_ROUND_TIME*IC_AC_POINT_NUM*4      //大小是16*9*1024*4字节 = 576K

//上行校正采数:16轮重复迭代*每轮1次发完64T(每次64发1收)*采数是1024个点*4字节
//大小为16*1024*4Bytes
#define IC_AC_SHARE_MEM_UL_AC_CATCH_DATA_ADDR    576*AC_SIZE_1K      //偏移地址是576K,绝对地址60MB+576K
#define IC_AC_SHARE_MEM_UL_AC_CATCH_DATA_SIZE    \
        IC_AC_RETRY_TIME*IC_AC_POINT_NUM*4      //大小是16*1024*4字节 = 64K

#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif

#ifndef RESULT_CHECK_CONTINUE_AC
#define RESULT_CHECK_CONTINUE_AC(uiRet)                                                              \
    {                                                                                                \
        if (BSP_OK != (uiRet))                                                                       \
        {                                                                                            \
            dbgInfo("[%s], line: %u, AC Result Check Continue uiRet'0x%X\n", __FUNCTION__, __LINE__, (uiRet)); \
            continue;                                                                                \
        }                                                                                            \
    }
#endif

#ifndef RESULT_CHECK_WITHOUT_HANDLE_AC
#define RESULT_CHECK_WITHOUT_HANDLE_AC(uiRet)                                                         \
    {                                                                                                 \
        if (BSP_OK != (uiRet))                                                                        \
        {                                                                                             \
            dbgInfo("[%s], line: %u, AC Result Check uiRet'0x%X\n", __FUNCTION__, __LINE__, (uiRet)); \
        }                                                                                             \
    }
#endif

#define AC_MAP_ELEMENT_MAX (24)
enum MAP_TYPE_DEF
{
    DIF_CHIP_ID = 0,
    TRX_TYPE,
    RRU_ANT_ID,
    DSP_ANT_ID,
    MAP_TYPE_MAX
};

enum
{
    MAP_INFO_INVALID = 0,
    MAP_INFO_VALID
};

typedef struct tagIcAcShareMemInfo
{
    UINT32 dlAcCatchData[IC_AC_RETRY_TIME][IC_AC_ROUND_TIME][IC_AC_POINT_NUM];
    UINT32 ulAcCatchData[IC_AC_RETRY_TIME][IC_AC_POINT_NUM];
    
}IcAcShareMemInfo;

typedef struct tag_T_AC_ALL_PARA
{
    UINT32 radio;
    UINT32 bandWidth; 
    UINT32 acSeqLen;
}T_AcAllParaInfo;

typedef struct tag_T_AC_WGT_INFO
{
    UINT32 carrType;
    UINT32 radioMode;
    UINT32 bandWidth;
    UINT32 rbNum;
}T_AcWgtInfo;

struct ac_info
{
    INT32 sendPackets_ok;
    INT32 sendPackets_err;
};

typedef struct tag_T_AC_WGT_ADDR_INFO
{
    UINT32 uiSocId;
    UINT32 uiDir;
    UINT32 uiDdrOffset;
    UINT32 uiAcWidth;
    UINT8 *pucWgtAddr;
}T_AC_WGT_ADDR_INFO;

typedef struct tag_T_AC_WGT_LEN_INFO
{
    UINT32 uiAcMode;
    UINT32 uiCarrType;
    UINT32 uiRadioMode;
    UINT32 uiBandWidth;
}T_AcWgtLenInfo;

typedef struct tBandNoRedefinition
{
    UINT32 uiRedefFlag;  // 是否使用新的频段号匹配规则
    UINT32 uiRceBandNo[MAX_BANDNO_NUM][2];  // 一列为APP下发的频段号(与协议保持一致)，二列为转义后的频段号
    UINT32 reserve;     // 保留
}T_BandNoRedefinition;

typedef struct tAcAntMapInfo
{
    UINT32 uiAcMapValid;
    UINT32 uiaAntMap[AC_MAP_ELEMENT_MAX][MAP_TYPE_MAX];
}T_AcAntMapInfo;


extern INT8 g_acSaveSnr[MAX_TYPEIDX][MAX_BANDNO][MAX_RADIOIDX][MAX_CARRNO][MAX_CHANNO];
extern FLOAT g_acSaveDly[MAX_TYPEIDX][MAX_BANDNO][MAX_RADIOIDX][MAX_CARRNO][MAX_CHANNO];
extern FLOAT g_acSavePha[MAX_TYPEIDX][MAX_BANDNO][MAX_RADIOIDX][MAX_CARRNO][MAX_CHANNO];

extern UINT32 g_uiRcuaFlag ;
extern UINT32 g_uiRcuaBitMap ;
extern UINT32 g_RcuaAntNoMap ;

extern UINT32 g_uiAcValidAntNum;


extern T_AcAntMapInfo g_acAntMapInfo;
extern T_BandNoRedefinition g_acBandNoRedef;
extern T_AcCarrCfgNxp g_acCarrCfgNxp;
extern UINT8 *s_ucRamDspAddr ;
extern UINT32 g_uiAlgTimeSw;
UINT32 BspGetBandNo(VOID);
UINT32 BspAcSeqCalcIc4(UINT32 chan, UINT32 freqNo, UINT32 cellId, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth,UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag);
UINT32 InitAcCaliDevPara(VOID *pUserAddCfg);
UINT8* BspGetAcMemBaseAddr(VOID);
UINT32 SetJacDspBitMap(UINT8 uiRcuaAcBitMap, UINT8 ucRcuaFlg);
UINT32 GetJacDspBitMap();
VOID setJacConjFreqSeqUpdateFlag(UINT32 inPut);
UINT32 GetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiSeqLen);
UINT32 SetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiSeqLen);
UINT32 getJacConjFreqSeqUpdateFlag();

UINT32 BspAcSetNonStandardBandSw(UINT32 uiSwitch, UINT32 uiBandWidth);

VOID BspSetNonStandBandFlag(UINT32 uiFlag);
UINT32 BspGetNonStandBandFlag(VOID);
VOID BspSetOptNcoValue(UINT32 uiOptNco);
UINT32 BspGetOptNcoValue(VOID);
UINT32 SetAcNonStandBandSw(UINT32 uiSwitch, UINT32 uiBandWidth);
UINT32 BspSetAcAlgTimeSw(UINT32 uiSw);
UINT32 BspGetAcAlgTimeSw(VOID);
UINT32 BspGetAcCarrType(UINT32 uiRadioMode, UINT32 uiDeviate);
UINT32 GetAcWgtLenOffset(T_AcWgtLenInfo *ptAcWgtLenInfo, UINT32 *puiAcWidth, UINT32 *puiDdrOffset);
UINT32 GetAcWgtDdr(T_AC_WGT_ADDR_INFO *ptAcWgtAddr, UINT32 **uiData, UINT32 *puiDataLen, UINT32 uiWgtType);
UINT32 GetAcSeqIc(UINT32 socId, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length);
UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength);
UINT32 CalAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag);
UINT32 GetAcSeqIc(UINT32 socId, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length);
UINT32 BspGetAcWgtRbNum(UINT32 uiRadioMode,UINT32 uiBandWidth,UINT32 uiCarrType);
UINT32 BspCheckJacBitMap(UINT32 uiAntNum);
UINT32 SetJacMode(UINT32 uiJacMode, UINT32 uiJacHandleType, UINT8 uiBitMap);
UINT32 BspGetAntNumFromAcMap(UINT32 uiSocId, UINT32 uiDir, UINT32 uiAntLoop, UINT32 *puiAntNum, UINT32 *puiAntTmp);
UINT32 BspCheckSepareBitMap(UINT32 uiAntNum);

UINT32 BspReCfgPhaAmpRelativeValue(INT32 *amp, INT32 *phase);
UINT32 BspSetAcPhaAmpDbgSw(UINT32 uiSw, INT32 iAmpVal, INT32 iPhaVal);
UINT32 BspGetAcCarrFreq(VOID);
UINT32 BspGetAcCarrBw(VOID);
UINT32 BspSaveChangeAcType(UINT32 uiAcType);
UINT32 BspSaveChangeAcRadioMode(UINT32 uiRadioMode);
UINT32 BspSaveChangeAcBandNo(UINT32 uiBandNo);
UINT32 SaveAcData(UINT32 actype, UINT32 radioMode, UINT32 carrNo);
UINT32 BspGetAcSaveData(UINT32 actypeIdx, UINT32 radioIdx, UINT32 bandIdx , UINT32 carrIdx, UINT32 antMax,UINT32 flag);
UINT32 BspGetCarrDoAcState(UINT32 uiAcType,UINT32 uiCarrNo,UINT32 uiRaidoMode, UINT32 uiBandNo);

UINT32 BspGetRcuaChanPhase(T_AcRepDspPara *ptAcReqDspPara,INT32 *piPhase);
UINT32 BspGetRcuaChanSnr(T_AcRepDspPara *ptAcReqDspPara,INT32 *piSnr);
UINT32 BspGetRcuaChanTimeDly(T_AcRepDspPara *ptAcReqDspPara,INT32 *piTimeDly);

UINT32 GetAcVaildAntNum(T_UpAcValidAntInfo* ptAcValidAntInfo);
UINT32 SetAcVaildAntNum(UINT32 data, T_UpAcValidAntInfo* ptAcValidAntInfo);
UINT32 GetAcWgtIcIfZero(UINT32 bandWidth, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength);
UINT32 GetAcWgtDdrIfZero(T_AC_WGT_ADDR_INFO *ptAcWgtAddr, UINT32 **uiData, UINT32 *puiDataLen);

#ifdef __cplusplus
}
#endif
#endif

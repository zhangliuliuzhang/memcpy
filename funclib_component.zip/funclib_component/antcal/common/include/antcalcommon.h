/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : antcalapi.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了天线校正对外接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/



#ifndef _FUNCLIB_ANTCALCOMMON_H_
#define _FUNCLIB_ANTCALCOMMON_H_




#ifdef __cplusplus
extern "C" {
#endif

#include "antcalapi.h"
#include "funccommon_log.h"


#define AC_BANDTYPE_NUM_MAX            10
#define AC_CARRITYPE_NUM_MAX           8
#define AC_CARR_NUM_MAX                6
#define AC_PHASE_DIFF_MODE             1

#define AC_ANT_NO_CON                  1
#define AC_ANT_DUAL_BAND               2

#define AC_FREQ_BAND_S35               0
#define AC_FREQ_BAND_S26               1
#define AC_FREQ_3G_HZ                  3000000
#define AC_MAX_RB_NUM                 (273)
#define IC42_MAX_POLA_CHAN             (2)
#define IC42_AC_MAX_RB_NUM             (273)

typedef UINT32 (*Ac_DevInit)(VOID);
typedef UINT32 (*Ac_StartRecv)(UINT8 fpgaIdx, UINT16 upDown, UINT32 carrNo, UINT32 radioMode, UINT16 powerFactor);
typedef UINT32 (*Ac_WrMsg)(UINT8 mode, UINT8 *pdata, UINT32 length);
typedef UINT32 (*Ac_GetWeight)(UINT8 *pdata);

typedef UINT32 (*Ac_CalAcWgtIc)(UINT32 acType, UINT32 carr, UINT32 radioMode, UINT32 refChan);
typedef UINT32 (*Ac_ChkAcWgtIc)(UINT32 acType, UINT32 carr, UINT32 radioMode);

typedef UINT32 (*Ac_GetAcWgtIc)(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength);
typedef UINT32 (*Ac_GetAcWgtIcIfZero)(UINT32 bandWidth, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength);
typedef UINT32 (*Ac_GetVswrValueIc)(T_AcVswrValue *acVswrValue);
typedef UINT32 (*Ac_SetAcWgtIc)(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode,UINT32 actype, UINT32* data, UINT32 trxLength,  UINT32 prachRxLength);
typedef UINT32 (*Ac_CheckAcCarrNo)(UINT32 carrNo,UINT32 radioMode);

typedef UINT32 (*Ac_CalAcSeqIc)(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType);
typedef UINT32 (*Ac_CalAcSeqIc4)(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag);
typedef UINT32 (*Ac_ChkAcSeqIc)(UINT32 chan);
typedef UINT32 (*Ac_GetAcSeqIc)(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length);
typedef UINT32 (*Ac_GetAcSeqIcNew)(UINT32 socId, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length);
typedef UINT32 (*Ac_SetAcSeqIc)(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 length, UINT32 seqMode);

typedef UINT32 (*Ac_SendHaulBackAcSeqIc)(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode);
typedef UINT32 (*Ac_SendFwdRevDataToDsp)(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode);
typedef UINT32 (*Ac_SendTddInslotDataToDsp)(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode);

typedef UINT32 (*Ac_GetAcSyncTime)(UINT32 acType, UINT32 syncType, UINT32* syncTime);
typedef UINT32 (*Ac_SetAcSyncTime)(UINT32 acType, UINT32 syncType, UINT32 syncTime, UINT32 bitMap);
typedef UINT32 (*Ac_BspGetULCoupleNetFactor)(UINT32 cellId, UINT16 channelId,UINT16* pvalidFreNum, UINT32 *pBridegPara);
typedef UINT32 (*Ac_SetAcParaIc)(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 refChn,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo);

typedef UINT32 (*Ac_GetAcCatchDataSta)(UINT32 acType, UINT32 carrNo, UINT32 radioMode);
typedef UINT32 (*Ac_SendAcCathData)(UINT32 acType, UINT32 carrNo);

typedef UINT32 (*Ac_GetRecvStat)(UINT8 fpgaIdx, UINT32 carrNo, UINT32 radioMode);
typedef UINT32 (*Ac_SendWgt)(UINT8 fpgaIdx, UINT8 upDown, UINT32 carrNo, UINT32 radioMode);
typedef UINT32 (*Ac_SendPrach)(UINT8 upDown, UINT32 carrNo, UINT32 radioMode);
//typedef UINT32  (*Ac_SetIqPara)(UINT32 acMode, UINT32 carrNo);
typedef UINT32 (*Ac_SetPara)(UINT32 acMode, UINT32 carrNo, UINT32 radioMode, UINT32 acChanChagFlag);
typedef UINT32 (*Ac_SetRefChan)(UINT32 caliChan);
typedef UINT32 (*Ac_SetStubData)(UINT32 sw);
typedef UINT32 (*Ac_PreFunc)(UINT32 dir, UINT32 chan, UINT32 carrNo);/*此处实际为带宽获取*/
typedef UINT32 (*Ac_ReCfgPauFunc)(UINT32 dir,INT32 *amp,INT32 *phase);/*此处为重配天线耦合网络因子*/
typedef UINT32 (*Ac_GetWeightEx)(T_AcTWghtCalSta *tWgtInfo);
typedef UINT32 (*Ac_SetTimeWeight)(T_AcTimeWeight *ptAcTmWgtInfo);
typedef UINT32 (*Vswr_RevParaSet)(UINT32 acType,UINT32 startTranNum,UINT32 stopTranNum,UINT32 VswrRevTransceiverNum);

typedef UINT32 (*Vswr_SetSeq)(UINT32 radioMode, UINT32 bandWidth);
typedef UINT32 (*Vswr_GetFwdRevData)(UINT32 *VswrFwdData, UINT32 *VswrRevData);
typedef UINT32 (*Vswr_UpdateR8StartFrameNo)(UINT32 frameNo, UINT32 acType, UINT32 bitMap);
typedef UINT32 (*Vswr_GetCoupleingIcType)(UINT32 *puiVswrCoupleingIcType);
typedef UINT32 (*Vswr_SetFwdVal)(UINT32 *puiVswrFwdVal);
typedef UINT32 (*Vswr_GetCalSta)(UINT32 *puiCalSta);
typedef UINT32 (*Vswr_SetTddType)(UINT32 radioMode, UINT32 carrNo);

typedef UINT32 (*Aac_SetAacWgt)(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 bitAntMap, UINT32 *data, UINT32 length);
typedef UINT32 (*Aac_SetWgtIc)(UINT32 carrNo, UINT32 radioMode, UINT32 actype, UINT32 data[2][273], UINT32 Length);
typedef UINT32 (*Pim_SetRbWgt)(T_PimWgtCarrInfo *aacCarrInfo, UINT32 disableRbStart, UINT32 disableRbNum, UINT32 disableTxChanMap);

//JAC新增
typedef UINT32 (*JAc_CalJacRefHIc)(UINT32 uiJacType, UINT32 carr);
typedef UINT32 (*JAc_CalJacRefHRstIc)(UINT32 *puiRefHRst);
typedef UINT32 (*JAc_GetJacRefHIc)(UINT32 *puiRefHData, UINT32 *puiDataLength, UINT8 *pciScale, UINT32 *puiScaleLenth);
typedef UINT32 (*JAc_SetJacRefHIc)(UINT32 *puiRefHData, UINT32 uiDataLength, UINT8 *pciScale, UINT32 uiScaleLenth);
typedef UINT32 (*JAc_SetJacMode)(UINT32 uiJacMode, UINT32 uiJacHandleType, UINT8 uiBitMap);
typedef UINT32 (*JAc_GetJacOrgData)(UINT32 uiJacType, UINT32 *uiOrgJacData, UINT32 *uiJacDataLen);
typedef UINT32 (*JAc_SetJacOrgData)(UINT32 uiJacType, UINT32 *uiOrgJacData, UINT32 uiJacDataLen);
typedef UINT32 (*JAc_SetJacSuperFr)(UINT32 uiSuperFr);
//TDD多片机型接口
typedef UINT32 (*AC_GetAcSeqMultiIc)(UINT32 uiSocId, UINT32 uiAcType, UINT32 *pSeq, UINT32 *pSeqLen);
//TDD 8T内外耦合切换
typedef UINT32 (*AC_CouplingSwitch)(UINT32 uiAdapteEn, UINT32 uiAdapteType);
//RCUA新增
typedef UINT32 (*Rcua_SetJacDspBitMap)(UINT8 uiRcuaAcBitMap, UINT8 ucRcuaFlg);
typedef UINT32 (*Rcua_GetJacConjFreqBaseSeq)(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiJacSeqLen);
typedef UINT32 (*Rcua_SetJacConjFreqBaseSeq)(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiJacSeqLen);
typedef UINT32 (*Rcua_SetCalRoute)(UINT32 uiCalRoute);
typedef UINT32 (*Rcua_SetVswrPara)(UINT32 acType);
typedef UINT32 (*Rcua_GetVswrCalFinishSta)(UINT32 *puiCalSta);
typedef UINT32 (*Rcua_SetFwdPara)(UINT32 acType);
typedef UINT32 (*Rcua_GetVswrData)(UINT32 acType);
//非标带宽开关切换
typedef UINT32 (*AC_NonStandardSwitch)(UINT32 uiSwitch, UINT32 uiBandWidth);
//增强覆盖需求，LTE IF0按照时域法补偿
typedef UINT32 (*AC_SetAcAlgTimeSwitch)(UINT32 uiSwitch);

typedef UINT32 (*AC_GetRcuaSnr)(T_AcRepDspPara *ptAcReqDspPara,INT32 *piSnr);
typedef UINT32 (*AC_GetRcuaDelay)(T_AcRepDspPara *ptAcReqDspPara,INT32 *piTimeDly);
typedef UINT32 (*AC_GetRcuaPhase)(T_AcRepDspPara *ptAcReqDspPara,INT32 *piPhase);

typedef UINT32 (*AC_BspGetAcVaildAntNum)(T_UpAcValidAntInfo* ptAcValidAntInfo);
typedef UINT32 (*AC_BspSetAcVaildAntNum)(UINT32 data, T_UpAcValidAntInfo* ptAcValidAntInfo);

typedef UINT32 (*AC_BspGetLteCoupleNetFactor)(UINT32 uiAnt, UINT32 uiCenterFreq, UINT32 uiBandWidth, T_acCoupleNet *pAcCpNet);

#if 1
/*和DSP的共享内存地址和长度*/
typedef struct tagT_AcWgtComplexData
{
    INT16 real;
    INT16 imag;
}T_AcWgtComplexData;

typedef struct tagT_wgtBakDataPara
{
    UINT32 carrNo;
    UINT32 radioMode;
    UINT32 dlAcWgtbak[AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM];
    UINT32 dlAcWgtLength; /* AC权值的长度，单位为byte */
    UINT32 aacWgtbak[IC42_MAX_CHAN_NUM];
    UINT32 aacWgtLength;  /* AAC权值的长度，单位为byte */
    UINT32 aacCjtWgtbak[IC42_MAX_POLA_CHAN][IC42_AC_MAX_RB_NUM];     /* 按照2个极性通道下发2*273 */
    UINT32 bitAntMap;  /* 天线位图 */
    UINT32 disableRbStart;
    UINT32 disableRbNum;
    UINT32 disableTxChanMap;
    UINT32 rbNum;                                               /* aac与ac共用rb */
    INT32  oriDlyTs[IC42_MAX_CHAN_NUM];                          /* 32个通道 */
    INT32  tsBak[IC42_MAX_CHAN_NUM];                             /* 下发的ts保存 */
}T_wgtBakDataPara;
#pragma pack(1)
typedef struct T_acaddrCfg
{
   UINT32 acaddr;
   UINT32 aclength;
   UINT8 acCellNum;   
   UINT8 acAntNum;
   UINT8 acGroupNum;   
   UINT8 acIteraNum;
   UINT32 acAntByte;
   UINT32 acAntUidByte;   
   UINT32 acGroupByte;
   UINT32 acGrpUidByte;  
   UINT32 acCellUpByte;
   UINT32 acCellDownByte;
   UINT8  acRruMode;//默认为0(5G低频)，5G高频为1
   UINT8  acSubDivision;//子分频
}acAddrCfg;
#pragma pack()
#pragma pack(1)
typedef struct T_ac64bitaddrCfg
{
   unsigned long long acaddr;
   unsigned long long aclength;
   UINT8 acCellNum;   
   UINT8 acAntNum;
   UINT8 acGroupNum;   
   UINT8 acIteraNum;
   UINT32 acAntByte;
   UINT32 acAntUidByte;   
   UINT32 acGroupByte;
   UINT32 acGrpUidByte;  
   UINT32 acCellUpByte;
   UINT32 acCellDownByte;
   UINT8  acRruMode;//默认为0(5G低频)，5G高频为1
   UINT8  acSubDivision;//子分频
}ac64bitAddrCfg;
#pragma pack()
typedef struct T_user_acaddrCfg
{
   unsigned long acaddr;
   unsigned long aclength;
}ac_user_AddrCfg;

/*DSP配置数据*/
typedef struct T_acDspDataCfg
{
    UINT32 acBand;
    UINT32 acRBNum;
    UINT32 acWgtLength;      /*单通道长度:RBNum*2(IQ数据)*2(每个I和Q都是2字节)  */
    UINT32 acMaskRes0;
    UINT32 acMaskRes1;
    UINT32 acMaskRes2;
}T_ac_DspDataCfg;

typedef struct tag_acdsp_cfg_para
{
    T_ac_DspDataCfg * pCfgPara;
    UINT32            cfgNum;
}T_AcDspDataCfg;
#endif

typedef struct T_acCarriFpgaMap
{
    UINT32 acBand;
    UINT32 acCarriFpgaMap[AC_CARRITYPE_NUM_MAX];/*载波FPGA MASK*/
}T_ac_CarriFpgaMap;
typedef struct T_acCtrlCfgMap
{
    UINT32 acCfgFpga;/*配置FPGA寄存器*/
    UINT32 acReplyFpga;/*AC数据发送FPGA寄存器(FPGA->CPU)*/
    UINT32 acMaskRes0;
    UINT32 acMaskRes1;
    UINT32 acMaskRes2;
}T_ac_CtrlCfgMap;
typedef struct T_acBcWgtInfo
{
    //UINT32 acBcCfgEnable;
    UINT32 acCarrNo;
    UINT32 acRadioMode;
    UINT32 acFpgaMask;
    UINT32 acCarrOffset;
    UINT32 acChanOffset;
}T_ac_BcWgtInfo;
typedef struct T_acWgtValSend
{
    Ac_PreFunc pPreFunc;
    UINT32 acBandNum;
    T_ac_CarriFpgaMap acCarriBandFpgaMap[AC_BANDTYPE_NUM_MAX];/*带宽*/
    T_ac_CtrlCfgMap acCtrlCfgMap;
    UINT32 acBcWgtCarrNum;
    T_ac_BcWgtInfo acBcWgtInfo[AC_CARR_NUM_MAX];
}T_ac_WgtVal_Send;

typedef struct T_AcShareMemPara
{
	UINT32 uAcCellBytes;
	UINT32 uAcUpCellBytes;
	
} T_ACSHARE_MEM_PARA;

typedef struct T_Ac_Para{
	UINT32 uHfCarrBw;
	UINT32 carrNo;
	UINT32 acUlcellsize;	
	UINT32 acDlcellsize; 
	UINT32 acUlcellProsize;
	UINT32 acDlcellProsize;
	UINT32 acwUDlcellsize;	
	UINT32 acwUDlcellProsize;
	UINT32 uAcWgtUlSidNum;
	UINT32 uAcWgtDlSidNum;		
	
} T_AC_PARA;

typedef struct T_Ac_CpuConFpga{
	UINT32 uAcWgtUlSidNum;
	UINT32 uAcWgtDlSidNum;
	UINT32 acAntByte ;
	UINT32 acAntUidByte;
       UINT32 acGroupByte  ;
       UINT32 acGrpUidByte ;
	 
} T_AC_CPU_CON_FPGA;


typedef UINT32 (*Ac_SetAcWeightFunc)(T_AcIQWeight *iqWgtInfo);
typedef UINT32 (*Ac_GetAcWeightFunc)(T_AcIQWeight *iqWgtInfo);
typedef UINT32 (*Ac_SendAcWeightDoneFlagFunc)(UINT32 carr, UINT32 radioMode, UINT32 trx);
typedef UINT32 (*Ac_SendAcPrachWeight)(T_AcPrachWeight *prachInfo);

typedef struct tag_func_ac
{   
    Ac_DevInit       pDevInit;
    Ac_StartRecv     pStartRecv;
    Ac_WrMsg         pWrMsg;
    Ac_GetWeight     pGetWeight;
    Ac_GetRecvStat   pGetRecvSta;
    Ac_SendWgt       pSendWgt;
    //Ac_SetIqPara     pSetIqPara;
    Ac_SetPara       pSetPara;
    Ac_SendPrach   pSendPrach;
    Ac_SetRefChan pSetRefChan;
    Ac_SetStubData pSetStubData;
    Ac_SetAcWeightFunc pSetAcWeight;
    Ac_GetAcWeightFunc pGetAcWeight;
    Ac_SendAcWeightDoneFlagFunc pSendAcWeightDoneFlag;
    Ac_SendAcPrachWeight pSendAcPrachWeight;
    //以下为NR3.0新增
    Ac_CalAcSeqIc        pCalAcSeqIc;       //计算AC序列
    Ac_ChkAcSeqIc        pChkAcSeqIc;       //查询AC序列的计算结果
    Ac_GetAcSeqIc        pGetAcSeqIc;       //获取AC序列
    Ac_SetAcSeqIc        pSetAcSeqIc;       //设置AC序列
    Ac_SendHaulBackAcSeqIc pSendHaulBackAcSeqIc;//将采集的AC序列传回ACDSP
    Ac_SendFwdRevDataToDsp pSendFwdRevDataToDsp;//将采集的Fwd和Rev数据传回ACDSP
    Ac_SendTddInslotDataToDsp pSendTddInslotDataToDsp; ///将采集到的TDD ULINSLOT数据传回ACDSP


    Ac_CalAcWgtIc          pCalAcWgtIc;         //计算AC权值
    Ac_ChkAcWgtIc          pChkAcWgtIc;         //查询AC权值的计算结果
    Ac_GetAcWgtIc          pGetAcWgtIc;         //获取AC权值
    Ac_GetAcWgtIcIfZero    pGetAcWgtIcIfZero;   //获取IF0 AC权值
    Ac_SetAcWgtIc          pSetAcWgtIc;         //设置AC权值
    Ac_GetVswrValueIc      pGetVswrValueIc;     //获取VSWR的FWD和REV值
	Ac_CheckAcCarrNo       pCheckAcCarrNo;      //获取载波信息

    Ac_GetAcSyncTime       pGetAcSyncTime;      //获取AC序列/权值同步时刻
    Ac_SetAcSyncTime       pSetAcSyncTime;      //设置AC序列/权值同步时刻

    Ac_SetAcParaIc         pSetAcParaIc;        //启停AC，包括设置参考通道
    Ac_GetAcCatchDataSta   pGetAcCatchDataSta;  //查询AC采数是否完成
    Ac_GetWeightEx         pGetWeightExt;
    Ac_SetTimeWeight       pSetAcTimeWgt;
    Vswr_RevParaSet        pVswrRevParaSet;

    //以下为NR4.0新增
    Ac_GetAcSeqIcNew       pGetAcSeqIcNew;       //获取AC序列
    Ac_CalAcSeqIc4         pCalAcSeqIc4;         //计算AC序列

    ///驻波
    Vswr_SetSeq                  pVswrSetSeq;            ///驻波序列设置
    Vswr_GetFwdRevData           pVswrGetFwdRevData ;    ///获取FWD值和REV值
    Vswr_UpdateR8StartFrameNo    pVswrUpdateR8StartFrameNo ;  ///更新帧号，触发发数以及采数
    Vswr_GetCoupleingIcType      pVswrGetCoupleingIcType ;//获取耦合通道所在的IC
    Vswr_SetFwdVal               pVswrSetFwdVal;          //FWD值设置
    Vswr_GetCalSta               pVswrGetCalSta;          //获取驻波完成状态
    Vswr_SetTddType              pVswrTypeToVswrType;     //恢复成tdd状态

    Aac_SetAacWgt                pSetAacWgtIc;     /* 设置AAC权值(空口校准) */
    Aac_SetWgtIc                 pSetAacWgtIcNew;     //设置supermimo的aac权值
    Pim_SetRbWgt                 pSetPimWgtIc;     /* 根据通道掩码禁用指定位置的Rb */
    //JAC新增
    JAc_CalJacRefHIc         pCalJacRefHIc; //计算参考通道H
    JAc_CalJacRefHRstIc      pGetJacRefHRstIc; //获取参考通道H计算结果
    JAc_GetJacRefHIc         pGetJacRefHIc; //获取参考通道H
    JAc_SetJacRefHIc         pSetJacRefHIc; //下发参考通道H
    JAc_SetJacMode           pSetJacMode; //下发JAC模式开关和Jac发数采数选择
    JAc_GetJacOrgData        pGetJacOrgData; //获取JAC原始数据
    JAc_SetJacOrgData        pSetJacOrgData; //下发JAC原始数据
    JAc_SetJacSuperFr        pSetJacSuperFr; //下发JAC超帧号
    //4.2新增
    Ac_BspGetULCoupleNetFactor  pBspGetULCoupleNetFactor;
    //TDD多片机型
    AC_GetAcSeqMultiIc       pGetAcSeqMultiIc;
    //TDD 8T内外耦合切换
    AC_CouplingSwitch        pBspSetCouplingSw;
    //RCUA新增
    Rcua_SetJacDspBitMap             pSetJacDspBitMap;   //APP向DSP配置位图
    Rcua_GetJacConjFreqBaseSeq       pGetJacConjFreqBaseSeq;     //RCUA上行AC用，校准盒子的APP获取AC基序列，上报给BBU OAM
    Rcua_SetJacConjFreqBaseSeq       pSetJacConjFreqBaseSeq;     //RCUA上行AC用，APP通知RRU0，RRU1的DSP替换校准盒子生成的基序列
    Rcua_SetCalRoute                 pSetCalRoute;        //设置cal口路由
    Rcua_SetVswrPara                 pSetVswrPara;        //配置驻波参数
    Rcua_GetVswrCalFinishSta         pGetVswrCalFinishSta;//获取驻波完成标志
    Rcua_SetFwdPara                  pSetFwdPara;         //配置FWD参数
    Rcua_GetVswrData                 pGetVswrData;     //获取驻波值
    //非标带宽切换开关
    AC_NonStandardSwitch     pBspSetNonStandardSw;
    //时域法切换开关
    AC_SetAcAlgTimeSwitch    pBspSetAcAlgTimeSw;

    AC_GetRcuaSnr              pBspGetChanSnr;
    AC_GetRcuaDelay            pBspGetChanDelay;
    AC_GetRcuaPhase            pBspGetChanPhase;

    AC_BspGetAcVaildAntNum      pBspGetAcVaildAntNum;
    AC_BspSetAcVaildAntNum      pBspSetAcVaildAntNum;
    AC_BspGetLteCoupleNetFactor pBspGetLteCoupleNet;
}T_AcFunc;

#define AC_ANT_NUM_MAX (8)

typedef struct A53R8AcDebugShareInfo
{
    UINT32 acSeqStartFrameNo; //AC序列更新的帧号
    UINT32 acWgtEnableFrameNo;//AC权值更新的帧号
    UINT32 acCellSeparateMode;
    UINT32 acDlDoneFlag;
    UINT32 acUlDoneFlag;
    UINT32 acDmaDataLen;
    UINT32 acCatchDataChan;
    UINT32 acSendDataChan;
    UINT32 acBackUpCatchDataChan;
    UINT32 acBackUpSendDataChan;
    UINT32 dlCatchDifChn;
    UINT32 ulSendDifChn;
    UINT32 dlBitMap;
    UINT32 ulBitMap;
    UINT32 sendAcRpuId;
    UINT32 catchAcRpuId;
    UINT32 icMaxAntNo;
    UINT32 frameType; //帧类型 5ms/10ms/20ms
    UINT32 startframeNo;
    UINT32 stopframeNo;
    UINT32 acInsertPos;
    UINT32 acInsertTimes;
    UINT32 a53KoMsgId;
    UINT32 acSlotNum;
    UINT32 acInslotFr;
    UINT32 acDlBankId[8][16]; //中频最大载波数16
    UINT32 acDlBankNum[8];
    UINT32 acDlBankClrSw;
    UINT32 acJacFlag;
    UINT32 acJacHandleType;
    UINT32 acJacCfgSuperFr;
    UINT32 acJacSuperFrErr;
    UINT32 acJacRealSuperFr;
    UINT32 uiMgcAttCtrlSw;
    UINT32 uiMgcCtrlDifChn;
    UINT32 uiMgcCtrlAttValue;
    UINT32 uiUlchBandNum;
    UINT32 auiUlchPort[AC_ANT_NUM_MAX];
    UINT32 acVswrFlag;  //驻波标志，FWD为3，REV为4
    UINT32 acVswrFinshFlag; //驻波完成标志
    UINT32 reserve[74];//凑成1K
}A53R8AcDebugShareInfo;//凑成1K

extern T_AcFunc s_AcModule;
T_AcFunc * BspGetAcModuleInfo(VOID);
UINT32 BspInitAcModuleFunc(VOID);
UINT32 BspGetCoupleNetFactor(UINT32 antNo, UINT32 carrNo, UINT32 dir, UINT32 aulData[]);
void BspGetCoupleNetFactor_m(UINT32 dir, UINT32* aulData, UINT32 chanEnd, T_Cmac2PulmAntAdjustScheInfoIc3* ptInfo);
UINT32 BspInitAc(VOID);
UINT32 BspSetUlBcWgtPara(UINT32 adWeightUlAntComb[],UINT32 size);
UINT32 BspSetAcWgtValSend(T_ac_WgtVal_Send *pacWgtValSend);
T_ac_WgtVal_Send *BspGetAcWgtValSend(UINT32 BdType);
UINT32 BspSetReCfgPauFun(Ac_ReCfgPauFunc ptPauReCfg);
UINT32 BspReCfgPauRelativeAmpPhase(UINT32 dir, INT32 *amp,INT32 *phase);
UINT32 BspSetCellidCovFlag(UINT32 uCellidCovFlag);
UINT32 BspGetCellidCovFlag(VOID);
UINT32 BspSetAcPhaseDiffMode(UINT32 phaDiff);
UINT32 BspGetAcPhaseDiffMode(VOID);
UINT32 BspGetAcFuncVerId(VOID);
UINT32 BspSetRfSwitchDelay(UINT32 gpNum);
UINT32 BspSetRfSwitchDelayTdd2(UINT32 gpNum);
UINT32 BspGetAcFreqBandId(VOID);
UINT32 BspGetTaDfNs(UINT32 ulChan,UINT32 ulCellFre, INT16 wTaDfNs[]);
UINT32 BspInitAcDevPara(VOID);

UINT32 BspGetAntInfoByRfChn(UINT32 rfChn,UINT32 dir,UINT32 *antId,UINT32 *antChn);
/* UINT32 BspGetAcCatchChan(UINT32 *puiCatchDataChan,UINT32 *puiAcRpuId); */
/* 调试接口,为修改kw,在此声明,不要调用以下接口 */
void sendacprachwgttest(UINT32 carrNo, UINT32 radioMode, UINT32 trx);
void setaciqwgttest(UINT32 carrNo, UINT32 radioMode, UINT32 trx);
UINT32 GetAcRecvPacks(VOID);
UINT32 InitAcCaliDevPara(VOID *pUserAddCfg);
UINT32 BspGetSepareBitmap(VOID);
UINT32 BspGetAcCellSeparateMode(VOID);
UINT32 BspSetAacWgtIc(T_wgtAacCarrInfo *aacCarrInfo, UINT32 *data, UINT32 length);
UINT32 BspGetWgtByCmplNumMult(T_AcWgtComplexData *pxfDatInA, T_AcWgtComplexData *pxfDatInB, T_AcWgtComplexData *pxfDatOut);
UINT32 BspSetWgtToDefVal(UINT32 *pWgtData, UINT32 length);
UINT32 GetdGp2Ac(UINT32 acType, UINT32 radio,DOUBLE* Gp2Ac);
UINT32 GetdGp2AcEnd(UINT32 acType, UINT32 radio, DOUBLE* Gp2AcEnd);
UINT32 BspGetRadioModeValue(VOID);
UINT32 BspGetAcNetMode(VOID);
UINT32 BspGetBridgeOffLinePara(UINT32 cellId, UINT16 channelId, UINT16* validFreNum, UINT32(*bridegPara)[100]);
UINT32 BspSetAcNetMode(UINT32 AcNetMode);
UINT32 BspSetAacChoiceAntMask(UINT32 uCellIdx, UINT32 uAntMask);
UINT32 BspConvertRegToDbfs(UINT32 uiCalPort, UINT32 uiFreq, INT32 *piFwdVal, INT32 *piRevVal);/* 获取驻波检测值 */
UINT32 BspSetSepareBitmap(UINT32 Bitmap,UINT32 acCellSeparateMode);
UINT32 BspGetLteCoupleNetFactor(UINT32 uiAnt, UINT32 uiCenterFreq, UINT32 uiBandWidth, T_acCoupleNet *pAcCpNet);
#ifdef __cplusplus
}
#endif
#endif 

UINT32 acGetAcWgtIcAll(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype);
UINT32 BspSetNonStandardBandIc(UINT32 uiSwitch, UINT32 uiBandWidth);

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : cfrcommon.c
* 文件标识 : {[N/A]}
* 内容摘要 : cfr 模块公共功能具体实现接口
* 注意事项 : 无
* 作    者 : wangfei
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: wangfei
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bspcomm.h"
#include "bsppub.h"
#include "regdrv.h"
#include "antcalapi.h"
#include "antcalcommon.h"
#include "freqcfgcommon.h"
#include "rruinfo.h"
#include "exprn.h"
#include "regdrv_accesstbl.h"

#ifdef _NR3_UDP_MSG_EN_
#include "udpmsg_ic.h"
#include "socmsg.h"
#endif

#include "chnmapcommon.h"
#include "psync.h"

#define  ACV3_FLAG 0x5a

T_AcFunc s_AcModule = {0};
UINT32 s_adWeightUlAntComb[BSP_MAX_ANT_NUM] = {0};
T_ac_WgtVal_Send * s_WgtValSend;
Ac_ReCfgPauFunc  ptPauReCfgFunc = NULL;
UINT32 s_cellid_con = 0;
UINT32 s_acPhaseDiffMode = 0;
UINT32 s_carrNo_98g = 0;
UINT32 s_acCellSeparateMode = 0;
UINT32 s_SeparateBit =0;
UINT32 s_acAcNetMode = 0;



static T_AcCarrCfgNxp g_acCarrCfgNxp = {0};

T_AcFunc * BspGetAcModuleInfo(VOID)
{   
    return &(s_AcModule);
}
static void BspSetBandNo(UINT32 inPut)
{
    g_acCarrCfgNxp.bandNo = inPut;
}
static UINT32 BspGetBandNo(VOID)
{
    return g_acCarrCfgNxp.bandNo;
}
UINT32 BspSetAcWgtValSend(T_ac_WgtVal_Send *pacWgtValSend)
{
    INPUT_POINTER_CHECK(pacWgtValSend);
    s_WgtValSend = pacWgtValSend;
    return BSP_OK;
}

T_ac_WgtVal_Send *BspGetAcWgtValSend(UINT32 BdType)
{
    return &s_WgtValSend[BdType];
}

UINT32 BspSetReCfgPauFun(Ac_ReCfgPauFunc ptPauReCfg)
{
    INPUT_POINTER_CHECK(ptPauReCfg);
    ptPauReCfgFunc = ptPauReCfg;
    return BSP_OK;
}

UINT32 BspReCfgPauRelativeAmpPhase(UINT32 dir, INT32 *amp,INT32 *phase)
{
    UINT32 ulRet = BSP_OK;
    
    if(ptPauReCfgFunc!=NULL)
    {
        ulRet = ptPauReCfgFunc(dir,amp,phase);
    }
    return ulRet;
}

UINT32 BspInitAc(VOID)
{
    return BspInitAcModuleFunc();
}

UINT32 BspSetAcPhaseDiffMode(UINT32 phaDiff)
{
    dbgInfo("[%s]phaDiffMode:%d.\n",__FUNCTION__,phaDiff);
    s_acPhaseDiffMode = phaDiff;
    return BSP_OK;
}

UINT32 BspGetAcPhaseDiffMode(VOID)
{
    return s_acPhaseDiffMode;
}

UINT32 BspSetAcCellSeparateMode(UINT32 Cellsepa)
{
    dbgInfo("[%s]CellSeparate:%d.\n",__FUNCTION__,Cellsepa);
    s_acCellSeparateMode = Cellsepa;
    return BSP_OK;
}

UINT32 BspGetAcCellSeparateMode(VOID)
{
    return s_acCellSeparateMode;
}

UINT32 BspSetSepareBitmap(UINT32 Bitmap,UINT32 acCellSeparateMode)
{
    if(acCellSeparateMode == (UINT32)1)
    {
        s_acCellSeparateMode = acCellSeparateMode;
        s_SeparateBit = Bitmap;
    }
    dbgInfo("[%s]s_acCellSeparateMode:%d.s_SeparateBit:%d\n",__FUNCTION__,s_acCellSeparateMode,s_SeparateBit);
    return BSP_OK;
}

UINT32 BspGetSepareBitmap(VOID)
{
    return s_SeparateBit;
}

UINT32 BspSetAcNetMode(UINT32 AcNetMode)
{
    dbgInfo("[%s]AcNetMode:%d.\n",__FUNCTION__,AcNetMode);
    s_acAcNetMode = AcNetMode;
    return BSP_OK;
}

UINT32 BspGetAcNetMode(VOID)
{
    return s_acAcNetMode;
}







/*****************************************************************************
*  函数名称   : BspInitAcDevPara
*  功能描述   : ac模块初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : cellNum --支持的小区数 antNum --支持的天线数
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   :  天线校正前先初始化一次
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* 
*----------------------------------------------------------------------------
*/
UINT32 BspInitAcDevPara(VOID)
{
    if(s_AcModule.pDevInit == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pDevInit();
}

//VOID BspSetMSChanFlag(UINT32 acChanChagFlag)
//{
//    UINT32 fpgaIdx = 0;
//    UINT32 chipNum = 2;
//    UINT32 chipInfo[8] = {0, 1};
//
//    if (BSP_OK != BspGetRegChip(REG_COUPLE_ANT_SEL, chipInfo, &chipNum))
//    {
//        return;
//    }
//
//    /* 设置主备耦合通道, BB0和BB1都需要设置寄存器 */
//    for (fpgaIdx = 0;fpgaIdx < chipNum;fpgaIdx++)
//    {
//        BspRegWr(fpgaIdx, REG_COUPLE_ANT_SEL, 0, acChanChagFlag);
//        BspRegWr(fpgaIdx, REG_UL_RF_SEL, 0, acChanChagFlag);
//    }
//    return;
//}
//
//UINT32 BspSetAcPara(UINT32 acMode, UINT32 carrNo, UINT32 radioMode)
//{
//    UINT32 uRetVal   = 0;
//    AntcalCfgLog(LOG_INFO,"%s(%d,%d,%#x) enter \n", __FUNCTION__, acMode,carrNo,radioMode);
//    if(s_AcModule.pSetPara == NULL)
//    {
//        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
//        return BSP_ERROR;
//    }
//
//    uRetVal = s_AcModule.pSetPara(acMode, carrNo, radioMode,0);
//    AntcalCfgLog(LOG_INFO,"%s(%d,%d,%#x) retVal = 0x%x \n", __FUNCTION__, acMode,carrNo,radioMode,uRetVal);
//    return uRetVal;
//}

/**************************************************************************
 * 函数名称:  BspStartAcRecv
 * 功能描述:  FPGA开始发送数据，cpu开始接收ac数据
 * 输入参数:  ucFpga:发送给哪个fpga
                            ucUpDown:0:下行  1: 上行
                            carrNo:选择载波号
                            radioMode:载波制式
 * 输出参数:  无
 * 返 回 值   :  BSP_OK 执行成功
 *                         其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                   牛彦茹    创建
 * 2019-07-22                      zxt       将cell改为carrNo+radioMode
 **************************************************************************/
 /*需要跟上层沟通接口入参,增加制式选择*/
UINT32 BspStartAcRecv(UINT16 upDown, UINT32 carrNo, UINT32 radioMode, UINT16 powerFactor)
{
    UINT8 fpgaIdx = 0;
     UINT32  uRetVal = 0;
   BspLog(LOG_LEVEL_0,"%s(%d,%d,%#x,%d) enter \n", __FUNCTION__, upDown,carrNo,radioMode,powerFactor);
    if(s_AcModule.pStartRecv == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    //fpgaIdx = cell;/*各规格模块具体填充,fpgaIdx入参是否删除?*/
    uRetVal =  s_AcModule.pStartRecv(fpgaIdx, upDown, carrNo, radioMode, powerFactor);
    return uRetVal;
}
/*NR2.0上层需要调用*/
UINT32 BspSetUlBcWgtPara(UINT32 adWeightUlAntComb[],UINT32 size)
{
    /* UINT32 loop = 0; */
    UINT32 len = 0;
    
    INPUT_POINTER_CHECK(adWeightUlAntComb);
    len = min(size*sizeof(UINT32), BSP_MAX_ANT_NUM * sizeof(UINT32));
    memcpy((UINT8 *)s_adWeightUlAntComb, (UINT8 *)adWeightUlAntComb,len);
    return BSP_OK;
}

/**************************************************************************
 * 函数名称:   BspSendAcMsg
 * 功能描述:   将oam传下来的信令消息(结构体)写入共享内存DDR
 * 输入参数:   
 * 输出参数:  无
 * 返 回 值:      BSP_OK 执行成功
 *                          其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
UINT32 BspSendAcMsg(T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    UINT32 chan = 0;
    /* UINT32 loop = 0; */
    UINT32 retVal = 0;
    UINT32 data[AC_WEIGHT_DATA_NUM] = {0};
    UINT32 dir = TX;/*默认下行*/    
    UINT32 ulFreqBw = 0;
	UINT32 uLocalCellid = 0; 
	UINT32 uRadioMode = 0;
		
    INPUT_POINTER_CHECK(ptInfo);  
    BspLog(LOG_LEVEL_0,"%s(%d,%d,%d,%d) enter\n", __FUNCTION__, ptInfo->uiBandWidth, ptInfo->ulPrachRbNum,ptInfo->ulPrachRbStart,ptInfo->wCellId);
	
    if (s_AcModule.pWrMsg == NULL)
    {
        dbgErr("%s>>Error! AcModule.pWrMsg cannot NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if((UINT32)(1)==BspGetCellidCovFlag())//9815v2 s_cellid_con = 1,V2
    {        
        ulFreqBw = BspGetCarrCfgBw();        
        if((ulFreqBw != 100000)&&(ulFreqBw != 200000)&&(ulFreqBw != 400000))
        {
             BspLog(LOG_LEVEL_0,"%s(%#x) retVal=-1\n", __FUNCTION__,(uintptr_t)ptInfo);
             return BSP_ERROR;
        }
            ptInfo->wCellId = ptInfo->wCellId/( ulFreqBw/(UINT32)100000);
	 	
    }

	if((UINT32)(ACV3_FLAG)==BspGetCellidCovFlag())////9815v3 s_cellid_con = 0x5a,V3 AC send kernel localCellid
    {
        if(BspCarrIdMapGetLocalCarrId(ptInfo->wCellId,&uLocalCellid,&uRadioMode) == BSP_OK)
        {
            ptInfo->wCellId = uLocalCellid;
        }
    }               
   
	
    /*OAM 0下行1上行*/
    dir = (ptInfo->wACType==0)?(TX):(RX);

#ifndef _NR30_AC_DSP_DEBUG_
    for (chan = 0; chan < BspGetTxChannel(); chan++)
    {
        BspGetCoupleNetFactor(chan, ptInfo->wCellId, dir, &data[0]); /* 前期调试，暂时写死为0x4000 */
    //  for(loop = 0; loop < AC_WEIGHT_DATA_NUM; loop++)
    //  {
    //      ptInfo->axwCoupleNetFactor[chan][loop] = data[loop];
    //  }
        memcpy((VOID *)ptInfo->axwCoupleNetFactor[chan], (VOID *)data, sizeof(UINT32) * AC_WEIGHT_DATA_NUM);
        //ptInfo->adWwightUlAntComb[chan] = s_adWeightUlAntComb[chan];-------此处由App填写，BSP不再配置成默认值
    }
#endif
    dbgInfoEx("%s>>Trx'%d ChSum'%d: Factor[%d~%d]= Ant0'(0x%08X 0x%08X) Ant1'(0x%08X 0x%08X)\n",
              __FUNCTION__, ptInfo->wACType, BspGetTxChannel(), AC_WEIGHT_DATA_NUM - 1,
              AC_WEIGHT_DATA_NUM, ptInfo->axwCoupleNetFactor[0][AC_WEIGHT_DATA_NUM - 1],
              ptInfo->axwCoupleNetFactor[0][AC_WEIGHT_DATA_NUM],
              ptInfo->axwCoupleNetFactor[1][AC_WEIGHT_DATA_NUM - 1],
              ptInfo->axwCoupleNetFactor[1][AC_WEIGHT_DATA_NUM]);
   
    retVal = s_AcModule.pWrMsg(1, (UINT8 *)ptInfo, sizeof(T_Cmac2PulmAntAdjustScheInfo));	
     BspLog(LOG_LEVEL_0,"%s , %d, retVal=%#x\n", __FUNCTION__, ptInfo->wCellId, retVal);
    return  retVal;
}

/**************************************************************************
* 函数名称:   BspSendAcMsgIc3
* 功能描述:   将oam传下来的信令消息(结构体)写入共享内存DDR
* 输入参数:   
* 输出参数:  无
* 返 回 值:      BSP_OK 执行成功
*                          其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 
**************************************************************************/
UINT32 BspSendAcMsgIc3(T_Cmac2PulmAntAdjustScheInfoIc3* ptInfo)
{
    UINT32 data[AC_WEIGHT_DATA_NUM] = {0};
    UINT32 dir = TX;/*默认下行*/
    UINT32 retVal = 0;
    UINT32 chanEnd = 0;
    UINT32 uiAcNetFactorMode = 0;

    INPUT_POINTER_CHECK(ptInfo); 
	
    if (s_AcModule.pWrMsg == NULL)
    {
        dbgErr("%s>>Error! AcModule.pWrMsg cannot NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    
    /*OAM 0下行1上行*/
    if (8 == ptInfo->acMsgHeaderReq.uwACType) //FDD AC下行
    {
        dir = TX;
    }
    else if (9 == ptInfo->acMsgHeaderReq.uwACType) //FDD AC上行
    {
        dir = RX;
    }
    else
    {
        dir = (ptInfo->acMsgHeaderReq.uwACType == 0)?(TX):(RX); //TDD AC
    }

    uiAcNetFactorMode = BspGetAcNetMode();
    if(1 == uiAcNetFactorMode)
    {
        chanEnd = 2 * BspGetTxChannel();//9626e机型存在复制载波通道，总通道数为整机通道数的2倍
    }
    else
    {
        chanEnd = BspGetTxChannel();
    }
    dbgInfo("%s chanEnd:%d\n", __FUNCTION__,chanEnd);
    BspGetCoupleNetFactor_m(dir, &data[0], chanEnd, ptInfo);


    retVal = s_AcModule.pWrMsg(1, (UINT8 *)ptInfo, sizeof(T_Cmac2PulmAntAdjustScheInfoIc3));   

    return retVal;
}





UINT32 BspGetBridgeOffLinePara(UINT32 cellId, UINT16 channelId, UINT16* validFreNum, UINT32(*bridegPara)[100])
{
    UINT32 retVal    = BSP_OK;


    dbgInfoEx("[%s]\n",__FUNCTION__);
    INPUT_POINTER_CHECK(bridegPara);
    INPUT_POINTER_CHECK(validFreNum);

    if (s_AcModule.pBspGetULCoupleNetFactor == NULL)
    {
        dbgErr("%s>>Error! AcModule.pBspGetULCoupleNetFactor cannot NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    
    retVal = s_AcModule.pBspGetULCoupleNetFactor(cellId, channelId, validFreNum, (UINT32*)(VOID*)bridegPara);
    return retVal;
}


/**************************************************************************
 * 函数名称:   BspRecvAcMsg
 * 功能描述:   将DSP 返回的信令消息回传OAM
 * 输入参数:   
 * 输出参数:   无
 * 返 回 值   :    BSP_OK 执行成功
 *                          其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
UINT32 BspRecvAcMsg(T_Pulm2CmacAntAdjustRsp *ptInfo)
{
     UINT32 retVal = 0;
    INPUT_POINTER_CHECK(ptInfo);
    BspLog(LOG_LEVEL_0,"%s(%#x) enter \n", __FUNCTION__, (uintptr_t)ptInfo);
    if(s_AcModule.pWrMsg== NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    } 
    retVal 	= s_AcModule.pWrMsg(0,(UINT8 *)ptInfo,sizeof(T_Pulm2CmacAntAdjustRsp));
    BspLog(LOG_LEVEL_0,"%s(%#x) retVal = 0x%x\n", __FUNCTION__, (uintptr_t)ptInfo,retVal);
    return retVal;
}

//混模新增函数
/**************************************************************************
* 函数名称:   BspRecvAcMsgIc3
* 功能描述:   将DSP 返回的信令消息回传OAM
* 输入参数:   
* 输出参数:   无
* 返 回 值   :    BSP_OK 执行成功
*                          其它   执行失败
* 其它说明:
* 修改日期       版本号           修改人    修改内容
* ------------------------------------------------------------------------
* 
**************************************************************************/
UINT32 BspRecvAcMsgIc3(T_Pulm2CmacAntAdjustRspIc3* ptInfo)
{
    UINT32 retVal = 0;
    INPUT_POINTER_CHECK(ptInfo);
    BspLog(LOG_LEVEL_0,"%s(%#x) enter \n", __FUNCTION__, (uintptr_t)ptInfo);
    if(s_AcModule.pWrMsg== NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    } 
    retVal  = s_AcModule.pWrMsg(0,(UINT8 *)ptInfo,sizeof(T_Pulm2CmacAntAdjustRspIc3));  //???
    BspLog(LOG_LEVEL_0,"%s(%#x) retVal = 0x%x\n", __FUNCTION__, (uintptr_t)ptInfo,retVal);

    return retVal;
}

/**************************************************************************
 * 函数名称:   BspGetAcRecvSta
 * 功能描述:   获取FPGA发数是否完成
 * 输入参数:   
 * 输出参数:   无
 * 返 回 值   :    BSP_OK 执行成功
 *                          其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
UINT32 BspGetAcRecvSta(UINT32 carrNo, UINT32 radioMode)
{
    UINT8 fpgaIdx = 0;

    if(s_AcModule.pGetRecvSta== NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    fpgaIdx = (UINT8)carrNo;
    return s_AcModule.pGetRecvSta(fpgaIdx,carrNo,radioMode);
}

/**************************************************************************
 * 函数名称:   BspSendAcWgt
 * 功能描述:   发送AC 权值给FPGA
 * 输入参数:   
 * 输出参数:   无
 * 返 回 值   :    BSP_OK 执行成功
 *                          其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
UINT32 BspSendAcWgt(UINT8 upDown, UINT32 carrNo, UINT32 radioMode)
{
    UINT8 fpgaIdx = 0;
    UINT32 retVal = 0;
    
    BspLog(LOG_LEVEL_0,"%s(%d,%d,%#x) enter \n", __FUNCTION__, upDown,carrNo,radioMode);
    if(s_AcModule.pSendWgt== NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    retVal = s_AcModule.pSendWgt(fpgaIdx,upDown,carrNo,radioMode);
    BspLog(LOG_LEVEL_0,"%s(%d,%d,%#x) retVal = 0x%x \n", __FUNCTION__, upDown,carrNo,radioMode,retVal);
    return retVal;
}
/* Started by AICoder, pid:02a49g7c85n94161442b09b1e08f9a1f5be2dcbb */
UINT32 BspSetAcAlgTimeIc(UINT32 uiSwitch)
{
    if(s_AcModule.pBspSetAcAlgTimeSw == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspSetAcAlgTimeSw(uiSwitch);
}
/* Ended by AICoder, pid:02a49g7c85n94161442b09b1e08f9a1f5be2dcbb */
//非标带宽切换
/* Started by AICoder, pid:s904fia1fa85c4014bf808ffa068f81022e41149 */
UINT32 BspSetNonStandardBandIc(UINT32 uiSwitch, UINT32 uiBandWidth)
{
    if(s_AcModule.pBspSetNonStandardSw == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspSetNonStandardSw(uiSwitch, uiBandWidth);
}
/* Ended by AICoder, pid:s904fia1fa85c4014bf808ffa068f81022e41149 */
//3.0 00 NXP开始计算AC序列，然后等待0.2S以上即可获取AC序列
UINT32 BspStartAcSeqCalcIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType)
{
    UINT32 seqType = 1;
    if(s_AcModule.pCalAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pCalAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType);
}

//4.0新增00 NXP开始计算AC序列，然后等待0.2S以上即可获取AC序列
UINT32 BspStartAcSeqCalcIc4(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 refChan, UINT32 preciseDlyFlag, INT32 freqNcoOffset)
{
    UINT32 seqType = 1;
    if(s_AcModule.pCalAcSeqIc4 == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pCalAcSeqIc4(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType, refChan, preciseDlyFlag);
}

//获取配频信息
UINT32 BspGetAcCarrInfo(UINT32 carrNo,UINT32 radioMode)
{
    if(s_AcModule.pCheckAcCarrNo == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pCheckAcCarrNo(carrNo,radioMode);
}

//01 NXP查询AC序列计算结果，延时0.2s以上认为肯定计算完了
UINT32 BspGetAcSeqCalcResultIc(UINT32 chan)
{
    if(s_AcModule.pChkAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pChkAcSeqIc(chan);
}

//02 NXP读取计算完毕的AC序列数据  3.0新增
UINT32 BspGetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length)  
{
    if(s_AcModule.pGetAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pGetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length);
}

//02 NXP读取计算完毕的AC序列数据  4.0新增
UINT32 BspGetAcSeqIcNew(UINT32 socId, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length)  
{
    if(s_AcModule.pGetAcSeqIcNew == (Ac_GetAcSeqIcNew)NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pGetAcSeqIcNew(socId, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length);
}
/* Started by AICoder, pid:r9c9fqd30fye55e1461d08d250000b1d3bd01df5 */
UINT32 BspGetAcSeqMultiIc(UINT32 uiSocId, UINT32 uiAcType, UINT32 *pSeq, UINT32 *pSeqLen)
{
    if(s_AcModule.pGetAcSeqMultiIc == (AC_GetAcSeqMultiIc)NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pGetAcSeqMultiIc(uiSocId, uiAcType, pSeq, pSeqLen);
}
/* Ended by AICoder, pid:r9c9fqd30fye55e1461d08d250000b1d3bd01df5 */
/* Started by AICoder, pid:a46f7i610e91d5114c6e09df70dca81539718b54 */
UINT32 BspSetAcCouplingMode(UINT32 uiAdapteEn, UINT32 uiAdapteType)
{
    if(s_AcModule.pBspSetCouplingSw == (AC_CouplingSwitch)NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspSetCouplingSw(uiAdapteEn, uiAdapteType);
}
/* Ended by AICoder, pid:a46f7i610e91d5114c6e09df70dca81539718b54 */
//03从片设置AC序列
UINT32 BspSetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 length, UINT32 seqMode)   
{
	s_carrNo_98g = carr;
    if(s_AcModule.pSetAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length, seqMode);
}

//10 NXP开始计算权值 
UINT32 BspStartAcWgtCalcIc(UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChan)
{
    if(s_AcModule.pCalAcWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pCalAcWgtIc(acType, carr, radioMode, refChan);
}

//11 NXP查询权值计算结果的接口BspGetAcSta //0x8007
UINT32 BspGetAcWgtResultIc(UINT32 acType, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 carr, UINT32 radioMode)
{
    if(s_AcModule.pChkAcWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
   
    return s_AcModule.pChkAcWgtIc(acType, carr, radioMode);
}

//12 NXP获取AC权值
UINT32 BspGetAcWgtIc(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
{
    if(s_AcModule.pGetAcWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }//    UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo,UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
    dbgErr("Innter addr 0x%08X\n", *data);
   
    return s_AcModule.pGetAcWgtIc(socId, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, data, trxLength, prachRxLength);
}

// NXP获取AC权值 IF0
UINT32 BspGetAcWgtIcIfZero(UINT32 bandWidth, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength)
{
    if(s_AcModule.pGetAcWgtIcIfZero == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }//    UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo,UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
    dbgErr("Innter addr 0x%08X\n", *data);
   
    return s_AcModule.pGetAcWgtIcIfZero(bandWidth, radioMode, actype, data, trxLength);
}

UINT32 g_acWgtOnOff = 0;
VOID setAcWgtSw(UINT32 sw)
{
    dbgInfo("0-Enable, 1-Disable\n");
    g_acWgtOnOff = sw;
}

//13 IC设置AC权值
UINT32 BspSetAcWgtIc(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode,UINT32 actype, UINT32* data, UINT32 trxLength,  UINT32 prachRxLength)    
{
    if(g_acWgtOnOff)
    {
        return BSP_OK;
    }
    
    if(s_AcModule.pSetAcWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
	dbgInfo("\nBspSetAcWgtIc: carrNo %d,pasteCarrFlag %d,deviate %d,bandWidth %d,sampleRate %d,radioMode %d,actype %d,data %08x, trxLength %d,prachRxLength %d\n",\
	        carrNo,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,actype,*data,trxLength,prachRxLength);
    return s_AcModule.pSetAcWgtIc(carrNo,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,actype, data, trxLength, prachRxLength);
}

UINT32 BspSetAacWgtIc(T_wgtAacCarrInfo *aacCarrInfo, UINT32 *data, UINT32 length)
{
    INPUT_POINTER_CHECK(aacCarrInfo);
    INPUT_POINTER_CHECK(data);

    UINT32 carrNo     = aacCarrInfo->carrNo;
    UINT32 radioMode  = aacCarrInfo->radioMode;
    UINT32 actype     = aacCarrInfo->acType;
    UINT32 antBitMap  = aacCarrInfo->bitAntMap;   /* 天线位图 */

    if(s_AcModule.pSetAacWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("\nBspSetAacWgtIc: carrNo %d, radioMode %d, actype %d, antBitMap %d, length %d\n",carrNo, radioMode, actype, antBitMap, length);

    return s_AcModule.pSetAacWgtIc(carrNo, radioMode, actype, antBitMap, data, length);
}

/* Started by AICoder, pid:w9f36ea107211bc14d310a64c0bd0a2d1e03765d */
UINT32 BspSetAacWgtIcNew(UINT32 carrNo, UINT32 radioMode, UINT32 actype, UINT32 data[2][273], UINT32 Length)
{
    if (s_AcModule.pSetAacWgtIcNew == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetAacWgtIcNew(carrNo, radioMode, actype, data, Length);
}
/* Ended by AICoder, pid:w9f36ea107211bc14d310a64c0bd0a2d1e03765d */

UINT32 BspSetPimRbWgt(T_PimWgtCarrInfo *aacCarrInfo, UINT32 disableRbStart, UINT32 disableRbNum, UINT32 disableTxChanMap)
{
    INPUT_POINTER_CHECK(aacCarrInfo);

    if(s_AcModule.pSetPimWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("%s>>>carrNo %d, radioMode %d, actype %d, disableRbStart%d, disableRbNum%d, disableTxChanMap%d\n",
        __FUNCTION__, aacCarrInfo->carrNo, aacCarrInfo->radioMode, aacCarrInfo->trxType, disableRbStart, disableRbNum, disableTxChanMap);

    return s_AcModule.pSetPimWgtIc(aacCarrInfo, disableRbStart, disableRbNum, disableTxChanMap);
}

//获取同步帧时刻，支持AC序列发送和权值更新两个过程，都能用这个接口
//syncType 0代表AC序列时间， syncType 1代表权值时间
UINT32 BspGetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32* syncTime) 
{
    INPUT_POINTER_CHECK(syncTime);
    if(s_AcModule.pGetAcSyncTime == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    
    return s_AcModule.pGetAcSyncTime(acType, syncType, syncTime);
}

//syncType 0代表AC序列时间， syncType 1代表权值时间
UINT32 BspSetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32 syncTime,UINT32 bitMap) 
{
    if(s_AcModule.pSetAcSyncTime == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetAcSyncTime(acType, syncType, syncTime, bitMap);
}

//设置AC启动和发起，启动时，acType = 2代表结束AC，acTYpe = 0和1分别代表下行和上行AC，
//注意第三个参数，包含参考通道的设置
UINT32 BspSetAcParaIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 refChn,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{	
    if(s_AcModule.pSetAcParaIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetAcParaIc(acType, carrNo, pasteCarrFlag, deviate, bandWidth, acChnChgFlag,radioMode, refChn,frameNo,subframeNo,slotNo);
}

UINT32 BspVswrRevParaSet(UINT32 acType,UINT32 startTranNum,UINT32 stopTranNum,UINT32 VswrRevTransceiverNum)
{
    if(s_AcModule.pVswrRevParaSet == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pVswrRevParaSet(acType, startTranNum, stopTranNum, VswrRevTransceiverNum);
}


//查询从片是否已经发数&采数完毕
UINT32 BspGetAcDataCatchSta(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    if(s_AcModule.pGetAcCatchDataSta == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pGetAcCatchDataSta(acType, carrNo, radioMode);
}

//启动从片往主片发数，数据搬移
UINT32 BspSendAcCatchData(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    if(s_AcModule.pSendHaulBackAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSendHaulBackAcSeqIc(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

//启动从片往主片发数，数据搬移
UINT32 BspSendAcTddUlInslotCatchData(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    if(s_AcModule.pSendTddInslotDataToDsp == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSendTddInslotDataToDsp(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

UINT32 BspSendAcResult(UINT8 upDown, UINT32 carrNo, UINT32 radioMode)
{
    if(s_AcModule.pSendPrach== NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSendPrach(upDown,carrNo,radioMode);
}

UINT32 BspSendCaliChan(UINT32 caliChan)
{
    if(s_AcModule.pSetRefChan == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetRefChan(caliChan);
}

UINT32 BspSendAcStubData(UINT32 sw)
{
    if(s_AcModule.pSetStubData == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetStubData(sw);
}

UINT32 BspSetAcWeight(T_AcIQWeight *iqWgtInfo)
{
    INPUT_POINTER_CHECK(iqWgtInfo);
    if (s_AcModule.pSetAcWeight == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetAcWeight(iqWgtInfo);
}

UINT32 BspGetAcWeight(T_AcIQWeight *iqWgtInfo)
{
    INPUT_POINTER_CHECK(iqWgtInfo);
    if (s_AcModule.pGetAcWeight == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pGetAcWeight(iqWgtInfo);
}

UINT32 BspSetAcTimeWeight(T_AcTimeWeight *ptWgtInfo)
{
    INPUT_POINTER_CHECK(ptWgtInfo);
    if (s_AcModule.pSetAcTimeWgt == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetAcTimeWgt(ptWgtInfo);
} 
/**************************************************************************
 * 函数名称:   BspGetAcWeightExt
 * 功能描述:   将DSP 返回的扩展权值回传OAM  (第二次AC后的精时延等)
 * 输入参数:   
 * 输出参数:   无
 * 返 回 值   :    BSP_OK 执行成功
 *                          其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 
 **************************************************************************/
UINT32 BspGetAcWeightExt(T_AcTWghtCalSta *ptInfo)
{
     UINT32 retVal = 0;
    INPUT_POINTER_CHECK(ptInfo);
    BspLog(LOG_LEVEL_0,"%s(%p) enter \n", __FUNCTION__, ptInfo);
    if(s_AcModule.pGetWeightExt== NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    } 
    retVal 	= s_AcModule.pGetWeightExt(ptInfo);
    BspLog(LOG_LEVEL_0,"%s(%p) retVal = 0x%x\n", __FUNCTION__, ptInfo,retVal);
    return retVal;
}

UINT32 BspSendAcWeightDoneFlag(UINT32 carr, UINT32 radioMode, UINT32 trx)
{
    if (s_AcModule.pSendAcWeightDoneFlag == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSendAcWeightDoneFlag(carr, radioMode, trx);
}

UINT32 BspSendAcPrachWeight(T_AcPrachWeight *prachInfo)
{
    if (s_AcModule.pSendAcPrachWeight == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSendAcPrachWeight(prachInfo);
}

//JAC新增
//通知DSP计算参考通道H
UINT32 BspStartCalJacRefH(UINT32 uiJacType, UINT32 uiCarrNo)
{
    if (s_AcModule.pCalJacRefHIc == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pCalJacRefHIc(uiJacType, uiCarrNo);
}

UINT32 BspGetJacRefHRst(UINT32 *puiRefHRst)
{
    if (s_AcModule.pGetJacRefHRstIc == NULL)
    {
        dbgInfo("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pGetJacRefHRstIc(puiRefHRst);
}

//获取DSP所计算的参考通道H
UINT32 BspGetJacRefH(UINT32 *puiRefHData, UINT32 *puiDataLength, UINT8 *pciScale, UINT32 *puiScaleLenth)
{
    if (s_AcModule.pGetJacRefHIc == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pGetJacRefHIc(puiRefHData, puiDataLength, pciScale, puiScaleLenth);
}

//下发配置DSP所计算的参考通道H
UINT32 BspSetJacRefH(UINT32 *puiRefHData, UINT32 uiDataLength, UINT8 *pciScale, UINT32 uiScaleLenth)
{
    if (s_AcModule.pSetJacRefHIc == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetJacRefHIc(puiRefHData, uiDataLength, pciScale, uiScaleLenth);
}

//配置JAC模式使能，IC发采数策略
UINT32 BspSetJacMode(UINT32 uiJacMode, UINT32 uiJacHandleType, UINT8 uiBitMap)
{
    if (s_AcModule.pSetJacMode == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetJacMode(uiJacMode, uiJacHandleType, uiBitMap);
}
//获取JAC原始数据
UINT32 BspGetJacOrgData(UINT32 uiJacType, UINT32 *puiOrgJacData, UINT32 *puiJacDataLen)
{
    if (s_AcModule.pGetJacOrgData == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pGetJacOrgData(uiJacType, puiOrgJacData, puiJacDataLen);
}
//下发配置JAC原始数据
UINT32 BspSetJacOrgData(UINT32 uiJacType, UINT32 *puiOrgJacData, UINT32 uiJacDataLen)
{
    if (s_AcModule.pSetJacOrgData == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetJacOrgData(uiJacType, puiOrgJacData, uiJacDataLen);
}
//下发配置JAC超帧号
UINT32 BspSetJacSuperFr(UINT32 uiSuperFr)
{
    if (s_AcModule.pSetJacSuperFr == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetJacSuperFr(uiSuperFr);
}
//配置校准盒子、RRU0\RRU1标志和位图
UINT32 BspSetJacDspBitMap(UINT8 uiRcuaAcBitMap, UINT8 ucRcuaFlg)
{
    if (s_AcModule.pSetJacDspBitMap == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetJacDspBitMap(uiRcuaAcBitMap, ucRcuaFlg);
}

//获取ACDSP计算的共轭频域序列
UINT32 BspGetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiJacSeqLen)
{
    if (s_AcModule.pGetJacConjFreqBaseSeq == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pGetJacConjFreqBaseSeq(uiJacType, puiAcSeq,uiJacSeqLen);
}


//设置ACDSP计算的共轭频域序列
UINT32 BspSetJacConjFreqBaseSeq(UINT32 uiJacType, UINT32 *puiAcSeq, UINT32 uiJacSeqLen)
{
    if (s_AcModule.pSetJacConjFreqBaseSeq == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetJacConjFreqBaseSeq(uiJacType, puiAcSeq,uiJacSeqLen);
}

//设置RCUA cal口路由
UINT32 BspSetCalRoute(UINT32 uiCalRoute)
{
    if (s_AcModule.pSetCalRoute == NULL)
    {
        dbgInfoEx("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetCalRoute(uiCalRoute);
}
#ifdef BUILD_WITH_OM_FUNC
/**************************************************************************
 *                         手敲调试命令区
 **************************************************************************/
UINT32 PrnAcResult(VOID)
{
    UINT32 loop = 0;
    UINT32 data = 0;
    T_Pulm2CmacAntAdjustRsp *ptInfo = NULL;

    ptInfo = (T_Pulm2CmacAntAdjustRsp *)malloc(sizeof(T_Pulm2CmacAntAdjustRsp));
    memset_s(ptInfo->ucAntCopyIdx,sizeof(ptInfo->ucAntCopyIdx),0, sizeof(ptInfo->ucAntCopyIdx));
    if (ptInfo == NULL)
    {
        dbgErr("%s[%d]malloc faild!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    BspRecvAcMsg(ptInfo);

    for(loop = 0; loop < BspGetTxChannel(); loop++)
    {
        data = ptInfo->ucAntCopyIdx[loop];
        dbgInfo("  %d", data);
        if(loop % 8 == 7)
        {
            dbgInfo("\n");
        }
    }
    free(ptInfo);
    return BSP_OK;
}
#endif

UINT32 testPrnAcWgtValSend(UINT32 RruType)
{
    T_ac_WgtVal_Send * pacWgtValSend;
    UINT32 ulBandCnt = 0;
    UINT32 ulCarrCnt = 0;

    pacWgtValSend = BspGetAcWgtValSend(RruType);
    dbgInfo("AcBandNum %d,CfgFpga0x%x,ReplyFpga0x%x,Res2 0x%x\n",pacWgtValSend->acBandNum, \
        pacWgtValSend->acCtrlCfgMap.acCfgFpga, pacWgtValSend->acCtrlCfgMap.acReplyFpga, \
        pacWgtValSend->acCtrlCfgMap.acMaskRes2);
    for(ulBandCnt=0;ulBandCnt<min(AC_BANDTYPE_NUM_MAX,pacWgtValSend->acBandNum);ulBandCnt++)
    {
        dbgInfo("Band[%d],acCarriBandFpgaMap %d\n",ulBandCnt,pacWgtValSend->acCarriBandFpgaMap[ulBandCnt].acBand);
        for(ulCarrCnt=0;ulCarrCnt<8;ulCarrCnt++)
        {
            dbgInfo("Carr[%d],acCarriFpgaMap[0x%x]\n",ulCarrCnt,pacWgtValSend->acCarriBandFpgaMap[ulBandCnt].acCarriFpgaMap[ulCarrCnt]);
        }
    }
    return BSP_OK;        
}

UINT32 setAcBcWgt(UINT32 carrNo, UINT32 radioMode)
{
    UINT32 ant = 0;
    UINT32 ret = 0;
    T_Cmac2PulmAntAdjustScheInfo *info = NULL;

    info = (T_Cmac2PulmAntAdjustScheInfo *)malloc(sizeof(T_Cmac2PulmAntAdjustScheInfo));
    if(NULL == info)
    {
        dbgErr("malloc Error\n");
        return BSP_ERROR;
    }
    memset(info, 0, sizeof(T_Cmac2PulmAntAdjustScheInfo));

    info->wCellId = carrNo;
    if (radioMode == BSP_RADIO_STANDARD_5G)
    {
        info->ucRRUId = 0;
    }
    else
    {
        info->ucRRUId = 1;
    }
    
    for(ant = 0; ant < BspGetTxChanNum(); ant++)
    {
        info->adWwightUlAntComb[ant] = (ant << 16) | (ant + 1);
        dbgInfo("ant'%d,bcData=0x%08x\n", ant, info->adWwightUlAntComb[ant]);
    }
    
    ret = BspSetAcBcWgt(info);
    free(info);
    return ret;
}

/************************************
      NR3.0 调试区域 
     acType = 2 代表结束AC
     acType = 0 代表下行
     acType = 1 代表上行
 ************************************/

//AC序列计算acSeqCalc
UINT32 acStartAcSeqCalcIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType)
{
    return BspStartAcSeqCalcIc(carr,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,acType);
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 acGetAcSeqCalcResultIc(UINT32 chan)
{
    //目前是空操作@2019-5-3 19:53:56
    return BspGetAcSeqCalcResultIc(chan);
}
#endif
UINT32 acGetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType)  
{
    UINT32* seq   = NULL;
    UINT32 length = 0;
    UINT32 retVal = 0;
    UINT32 loop   = 0;
    FILE*  fp     = NULL;
    INT32  lFprtRet = 0;
	INT32  lClsRet = 0;
                           //读DDR
    if(NULL == (fp = fopen("acGetAcSeqIc.txt", "w+")))
    {
        dbgErr("open file Error\n");
        return BSP_ERROR;
    }   

    if(NULL == (seq = (UINT32*)malloc(4*4*1024)))
    {
        dbgErr("malloc error\n");
        lClsRet =fclose(fp);
        FCLOSE_CHECK(lClsRet);
        return BSP_ERROR;
    }

    if(BSP_OK != (retVal = BspGetAcSeqIcNew(0, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, &length)))
    {
        dbgErr("get AC sequence error\n");
        lClsRet = fclose(fp);
		FCLOSE_CHECK(lClsRet);
        free(seq);
        return BSP_ERROR;
    }

    for(loop = 0; loop < length/4; loop++)
    {
        if(0 == loop % 16)
        {
            lFprtRet = fprintf_s(fp, "\nIndex %4d: ", loop);
			FPRINTF_CHECK(lFprtRet);
        }
        
        lFprtRet = fprintf_s(fp, "%08X ", seq[loop]);
        FPRINTF_CHECK(lFprtRet);
    }

    for(loop = 0; loop < length/4; loop++)
    {
        dbgInfoEx("point %4d, data 0x%08X\n", loop, seq[loop]);
    }

    lFprtRet = fprintf_s(fp, "\n");
	FPRINTF_CHECK(lFprtRet);
    dbgInfo("\nretVal = 0x%08X, please open file /acGetAcSeqIc.txt\n\n", retVal);
    lClsRet = fclose(fp);
	FCLOSE_CHECK(lClsRet);
    free(seq);
    return BSP_OK;
}

//让DSP开始计算AC权值
UINT32 acStartAcWgtCalcIc(UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChan)
{
    return BspStartAcWgtCalcIc(acType, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode ,refChan);
}

//给DSP发UDP消息，查询状态
UINT32 acGetAcWgtResultIc(UINT32 acType, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 carr, UINT32 radioMode)
{
    return BspGetAcWgtResultIc(acType, pasteCarrFlag, deviate, bandWidth, sampleRate, carr, radioMode);
}
/**************************************************************************
 * //频域权在DDR中的摆放
 * [通道0 RB0] [通道0 RB1] [通道0 RB2] ....... [通道0 RB271][通道0 RB272] //273*4
 * [通道1 RB0] [通道1 RB1] [通道1 RB2] ....... [通道1 RB271][通道1 RB272] //273*4
 * [通道2 RB0] [通道2 RB1] [通道2 RB2] ....... [通道2 RB271][通道2 RB272]
 * ................
 * [通道63 RB0] [通道63 RB1] [通道63 RB2] .... [通道63 RB271][通道63 RB272]
 *
 * //prach时域权在DDR中的摆放: 每个通道暂时只回传1个Prach权值
 * [通道0 1个RB] [通道1 1个RB] [通道2 1个RB] [通道3 1个RB] .... [通道64 1个RB]
 **************************************************************************/
UINT32 acGetAcWgtIc(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode,UINT32 actype)
{
    UINT32* data          = NULL;
    UINT32  trxLength     = 0;
    UINT32  prachRxLength = 0; 
    
    UINT32  retVal        = 0;
    UINT32  loop          = 0;
    /* UINT32  prachDeviate  = 0; */
    FILE*   fp            = NULL;
    INT32   snpRet = 0; 
    
    if(NULL == (fp = fopen("acGetAcWgtIc.txt", "w+")))
    {
        dbgErr("open file Error\n");
        return BSP_ERROR;
    }
    
    //1个soc至少需要16T*273RB*4Bytes + 16T*1RB*4Bytes = 17.5KB，取32KB
    if(NULL == (data = (UINT32*)malloc(32*1024)))
    {
        dbgErr("malloc error\n");
		if(-1 == fclose(fp))
			dbgErr("fclose Err\n");
        return BSP_ERROR;
    }
                           //读DDR
    if(BSP_OK != (retVal = BspGetAcWgtIc(socId, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, data, &trxLength, &prachRxLength)))
    {
    //    UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo,UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
        dbgErr("get AC Wgt error\n");
        free(data);
		if(-1 == fclose(fp))
			dbgErr("fclose Err\n");
        return BSP_ERROR;
    }
	dbgInfo("\ntrxLength = %d\n", trxLength);

    for(loop = 0; loop < trxLength/4; loop++)
    {
        snpRet =fprintf(fp, "[%d]0x%08X\n ",loop, data[loop]);
        FPRINTF_CHECK(snpRet);
    }

    for(loop = 0; loop < prachRxLength/4; loop++)
    {
        if(0 > fprintf(fp, "[%d]%08X\n ",loop, data[loop + trxLength/4]))
			dbgErr("fprintf err\n");
    }

    if(0 > fprintf(fp, "\n"))
    {
		dbgErr("fprintf err\n");
    }
    dbgInfo("\nretVal = 0x%08X, please open file /acGetAcWgtIc.txt\n\n", retVal);
    free(data);
	if(-1 == fclose(fp))
	{
		dbgErr("fclose err\n");
	}
    return BSP_OK;
}


UINT32 acGetAcWgtIcAll(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype)
{
    UINT32* data          = NULL;
    UINT32  trxLength     = 0;
    UINT32  prachRxLength = 0; 
    UINT32  retVal        = 0;
    UINT32  loop          = 0;
    FILE*   fp            = NULL;
	UINT32  socId 		  = 0;
	//fopen_s(&fp,"/acGetAcWgtIcAll.txt", "w+");
    if(NULL == (fp = fopen("acGetAcWgtIcAll.txt", "w+")))
    //if(NULL == fp)
    {
        dbgErr("open file Error\n");
        return BSP_ERROR;
    }
    
    //1个soc至少需要16T*273RB*4Bytes + 16T*1RB*4Bytes = 17.5KB，取32KB
    if(NULL == (data = (UINT32*)malloc(32*1024*4)))
    {
        dbgErr("malloc error\n");
		if(-1 == fclose(fp))
			dbgErr("fclose Err\n");
        return BSP_ERROR;
    }
	for(socId = 0;socId<4; socId++)
	{
	    //读DDR
		if(BSP_OK != (retVal = BspGetAcWgtIc(socId, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, data, &trxLength, &prachRxLength)))
	    {
	    //    UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo,UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
	        dbgErr("get AC Wgt error\n");
	        free(data);
			if(-1 == fclose(fp))
				dbgErr("fclose Err\n");
	        return BSP_ERROR;
	    }
		if(0 > fprintf(fp, "\n**************** socId %d, FreqDomainData **************\n", socId))
		{
			dbgErr("fprintf err\n");
		}
	    for(loop = 0 ; loop < trxLength/4; loop++)
	    {
			if(0 > fprintf(fp, "[%4d]0x%08X\n",loop, data[loop]))
			{
				dbgErr("fprintf err\n");
			}
	    }

	    if(0 > fprintf(fp, "\n**************** socId %d, TimeDomainData **************\n", socId))
	    {
	    	dbgErr("fprintf err\n");
	    }
	    for(loop = 0; loop < prachRxLength/4; loop++)
	    {
			if(0 > fprintf(fp, "[%4d]0x%08X\n", loop, data[loop + trxLength/4]))
			{
				dbgErr("fprintf err\n");
			}
	    }
	}

    if(0 > fprintf(fp, "\n"))
    {
    	dbgErr("fprintf err\n");
    }
    
    dbgInfo("\nretVal = 0x%08X, please open file /acGetAcWgtIc.txt\n\n", retVal);
    free(data);
	if(-1 == fclose(fp))
	{
		dbgErr("fclose err\n");
		return BSP_ERROR;
	}
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 acGetAcWgtIcUl(void)
{
    INT32  Fd          =0; /*内存设备的文件描述符*/
	UINT32 *baseAddr   = NULL;    /*通过mmap将物理地址映射到用户进程的虚拟地址空间*/
	UINT32 loop        = 0;
	UINT32 antLoop     = 0;
    UINT32  innerLoop  = 0;
    FILE*  fp          = NULL;
    FILE*  fpDsp       = NULL;	
	INT32  lClsRet     = 0;
	INT32  lFprtfRet   = 0;
	
	
  	/*按BSP要求格式打印*/  
    if(NULL == (fp = fopen("acGetAcWgtIcUl.txt", "w+")))
    {
        dbgErr("open file Error\n");
        return BSP_ERROR;
    }	
  	/*按DSP要求格式打印*/ 
    if(NULL == (fpDsp = fopen("acGetAcWgtIcUlDsp.txt", "w+")))
    {
        dbgErr("open file Error\n");
        lClsRet = fclose(fp);
		FCLOSE_CHECK(lClsRet);
        return BSP_ERROR;
    }	
	
    Fd = open("/dev/cachedmem", O_RDWR | O_SYNC);  /*打开内存设备的文件描述符*/
    if (Fd == -1)
    {
        dbgInfo("open /dev/cachedmem failed\n");
        lClsRet = fclose(fp);
		FCLOSE_CHECK(lClsRet);
        lClsRet = fclose(fpDsp);
		FCLOSE_CHECK(lClsRet);
        return BSP_ERROR;
    }
	
    /*设置用户态共享内存基址和长度*/
    baseAddr = (UINT32 *)mmap(0, 64*273*4, PROT_READ | PROT_WRITE, MAP_SHARED, Fd, 0xc0c00000);        
    if (baseAddr == (UINT32 *)(uintptr_t)(-1))
    {
        dbgInfo("mmap s_ucAcDataAddrMap failed %s, %d\n",strerror(errno),errno);
        close(Fd);
        lClsRet = fclose(fp);
		FCLOSE_CHECK(lClsRet);
        lClsRet = fclose(fpDsp);
		FCLOSE_CHECK(lClsRet); 
        return BSP_ERROR;
    }
	
    //memcpy((VOID*)seq, (VOID*)baseAddr, 4096);
    //*length = 4096;
    for(loop = 0, innerLoop = 0; loop < 64*273; loop++, innerLoop++)
    {
        if(0 == loop % 273)
        {
            lFprtfRet = fprintf_s(fp, "\n\nAntenna %2d: \n", antLoop);
			FPRINTF_CHECK(lFprtfRet);
            antLoop++;
            innerLoop = 0;
        }
        
        if(0 == innerLoop % 16)
        {
            lFprtfRet = fprintf_s(fp, "\nIndex %4d: ", innerLoop);
			FPRINTF_CHECK(lFprtfRet);
        }

        lFprtfRet = fprintf_s(fp, "%08X ", baseAddr[loop]);
		FPRINTF_CHECK(lFprtfRet);
    }
	
    for(loop = 0; loop < 64*273; loop++)
    {
        lFprtfRet = fprintf_s(fpDsp, "%08X,\r", baseAddr[loop]);
		FPRINTF_CHECK(lFprtfRet);
    }
	
    lClsRet = fclose(fp);
	FCLOSE_CHECK(lClsRet);
	lClsRet = fclose(fpDsp);
	FCLOSE_CHECK(lClsRet);
    close(Fd);
	
    if(0==munmap(baseAddr,64*273*4))
    {
        dbgInfo("munmap s_ucAcDataAddrMap suc !\n");
    }
    else
    {
        dbgErr("munmap s_ucAcDataAddrMap failed !\n");
    }
  
    return BSP_OK;
}
#endif

UINT32  BspSetCellidCovFlag(UINT32 uCellidCovFlag)
{
    s_cellid_con = uCellidCovFlag;
    return BSP_OK;	
}

UINT32  BspGetCellidCovFlag(VOID)
{
    return s_cellid_con;
}
void sendacprachwgttest(UINT32 carrNo, UINT32 radioMode, UINT32 trx)
{
    T_AcPrachWeight prachInfo = {0};
    UINT32 retVal = 0;
    UINT32 i, j;

    prachInfo.carrNo = carrNo;
    prachInfo.radioMode = radioMode;
    prachInfo.trx = trx;
    for (i=0; i<2; ++i)
    {
        for (j=0; j<BSP_MAX_TX_CHAN_ANTCAL; ++j)
        {
            prachInfo.prachWeight[i][j] = (((i+1) << 16) | j);
            dbgInfo("[%d][%d] %#x\n", i, j, prachInfo.prachWeight[i][j]);
        }
    }

    retVal = BspSendAcPrachWeight(&prachInfo);
    if (retVal != BSP_OK)
    {
        dbgInfo("send ac prach weight failed\n");
    }
}

void setaciqwgttest(UINT32 carrNo, UINT32 radioMode, UINT32 trx)
{
    T_AcIQWeight *acIqInfo = NULL;
    UINT32 retVal = 0;
    UINT32 i, j;
    UINT32 chanNum = min(BspGetTxChanNum(), AC_ANT_WGT_NUM_NR_MAX);

    acIqInfo = (T_AcIQWeight*)malloc(sizeof(T_AcIQWeight));
    if (acIqInfo == NULL)
    {
        dbgInfo("malloc failed!\n");
        return ;
    }

    acIqInfo->carrNo = carrNo;
    acIqInfo->radioMode = radioMode;
    acIqInfo->trx = trx;
    for (i=0; i<chanNum; ++i)
    {
        for (j=0; j<AC_ANT_WGT_NUM_NR_MAX; ++j)
        {
            acIqInfo->iqWeight[i][j] = (((i+1) << 16) | j);
            dbgInfo("[%d][%d] %#x\n", i, j, acIqInfo->iqWeight[i][j]);
        }
    }

    retVal = BspSetAcWeight(acIqInfo);
    if (retVal != BSP_OK)
    {
        dbgInfo("send ac prach weight failed\n");
    }
    free(acIqInfo);
}

UINT32 BspSetRfSwitchDelay(UINT32 gpNum)
{
    UINT32 dlDelayClk      = 0;
    UINT32 ulDelayClk      = 0;
    UINT32 chip = 0;

    if(gpNum > 1)
    {
        dlDelayClk = 0xBF8;  //600/2+45us*61.44M
        ulDelayClk = 0xCB1;  //600/2+48us*61.44M
    }
    else
    {
        dlDelayClk = 0x3C7;  //(600+1088)/2+2us*61.44M
        ulDelayClk = 0x47F;  //(600+1088)/2+5us*61.44M
    }

    dbgInfo("%s gpNum = %d, dlDelayClk = 0x%x, ulDelayClk = 0x%x \n", __FUNCTION__, gpNum, dlDelayClk, ulDelayClk);
    BspRegWr(chip,REG_IC3_PA_OFF_AC_DLY,0,dlDelayClk);
    BspRegWr(chip,REG_IC3_LNA_ON_AC_DLY,0,ulDelayClk);
    BspRegWr(chip,REG_IC3_TX_AMP_OFF_AC_DLY,0,dlDelayClk);
    BspRegWr(chip,REG_IC3_RX_AMP_ON_AC_DLY,0,ulDelayClk);
    BspRegWr(chip,REG_IC3_TX_OFF_AC_DLY,0,dlDelayClk);
    BspRegWr(chip,REG_IC3_RX_ON_AC_DLY,0,ulDelayClk);

    return BSP_OK;
}

//UINT32 BspSetRfSwitchDelayTdd2(UINT32 gpNum)
//{
//    UINT32 dlDelayClk      = 0;
//    UINT32 ulDelayClk      = 0;
//    UINT32 chip = 0;
//
//    if(gpNum > 1)
//    {
//        dlDelayClk = 0xBF8;  //600/2+45us*61.44M
//        ulDelayClk = 0xCB1;  //600/2+48us*61.44M
//    }
//    else
//    {
//        dlDelayClk = 0x3C7;  //(600+1088)/2+2us*61.44M
//        ulDelayClk = 0x47F;  //(600+1088)/2+5us*61.44M
//    }
//
//    dbgInfo("%s gpNum = %d, dlDelayClk = 0x%x, ulDelayClk = 0x%x \n", __FUNCTION__, gpNum, dlDelayClk, ulDelayClk);
//    BspRegWr(chip,REG_IC3_TDD2_PA_OFF_AC_DLY,0,dlDelayClk);
//    BspRegWr(chip,REG_IC3_TDD2_LNA_ON_AC_DLY,0,ulDelayClk);
//    BspRegWr(chip,REG_IC3_TDD2_TX_AMP_OFF_AC_DLY,0,dlDelayClk);
//    BspRegWr(chip,REG_IC3_TDD2_RX_AMP_ON_AC_DLY,0,ulDelayClk);
//    BspRegWr(chip,REG_IC3_TDD2_TX_OFF_AC_DLY,0,dlDelayClk);
//    BspRegWr(chip,REG_IC3_TDD2_RX_ON_AC_DLY,0,ulDelayClk);
//
//    return BSP_OK;
//}


//00 NXP开始计算VSWR序列，然后等待0.2S以上即可获取AC序列
UINT32 BspStartVswrSeqCalcIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType)
{
    if(s_AcModule.pCalAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pCalAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType);
}

//02 NXP读取计算完毕的VSWR序列数据  3.0新增
UINT32 BspGetVswrSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length)
{
    if(s_AcModule.pGetAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pGetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length);
}

//03从片设置VSWR序列
UINT32 BspSetVswrSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 length, UINT32 seqMode)
{
    if(s_AcModule.pSetAcSeqIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length, seqMode);
}

//设置VSWR的FWD/REV启动，acType = 3和4分别代表FWD和REV，
UINT32 BspSetVswrParaIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 refChn,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{
    if(s_AcModule.pSetAcParaIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pSetAcParaIc(acType, carrNo, pasteCarrFlag, deviate, bandWidth, acChnChgFlag,radioMode, refChn,frameNo,subframeNo,slotNo);
}

//获取同步帧时刻，支持AC序列发送和权值更新两个过程，都用这个接口
UINT32 BspGetVswrSyncTime(UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    if(NULL == syncTime)
    {
	dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);
	return BSP_ERROR;
    }
    if(s_AcModule.pGetAcSyncTime == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pGetAcSyncTime(acType, syncType, syncTime);
}

//syncType 0代表VSWR序列时间
UINT32 BspSetVswrSyncTime(UINT32 acType, UINT32 syncType, UINT32 syncTime,UINT32 bitMap)
{
    if(s_AcModule.pSetAcSyncTime == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pSetAcSyncTime(acType, syncType, syncTime, bitMap);
}

//启动从片往主片发数，数据搬移
UINT32 BspSendVswrCatchData(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    if(s_AcModule.pSendFwdRevDataToDsp == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    //BspGetVswrModeByAcType(&acType);
    return s_AcModule.pSendFwdRevDataToDsp(acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

/**************************************************************************
 * 函数名称:   BspGetVswrRecvSta
 * 功能描述:   获取FPGA发数是否完成
 * 输入参数:
 * 输出参数:   无
 * 返 回 值   :    BSP_OK 执行成功
 *                          其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 *
 **************************************************************************/
UINT32 BspGetVswrRecvSta(UINT32 carrNo, UINT32 radioMode)
{
    UINT8 fpgaIdx = 0;

    if(s_AcModule.pGetRecvSta== NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    fpgaIdx = (UINT8)carrNo;
    return s_AcModule.pGetRecvSta(fpgaIdx,carrNo,radioMode);
}

//获取配频信息
UINT32 BspGetVswrCarrInfo(UINT32 carrNo,UINT32 radioMode)
{
    if(s_AcModule.pCheckAcCarrNo == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pCheckAcCarrNo(carrNo,radioMode);
}

//查询从片是否已经发数&采数完毕
UINT32 BspGetVswrDataCatchSta(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    if(s_AcModule.pGetAcCatchDataSta == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pGetAcCatchDataSta(acType, carrNo, radioMode);
}

//10 NXP开始计算权值
UINT32 BspStartVswrWgtCalcIc(UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChan)
{
    if(s_AcModule.pCalAcWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pCalAcWgtIc(acType, carr, radioMode, refChan);
}

//11 NXP查询权值计算结果的接口BspGetAcSta //0x8007
UINT32 BspGetVswrWgtResultIc(UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    UINT32 chan = 0;
    if(s_AcModule.pChkAcWgtIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    //BspGetVswrModeByAcType(&acType);
    return s_AcModule.pChkAcWgtIc(acType, chan, radioMode);
}

//12 NXP获取AC权值
UINT32 BspGetVswrValueIc(T_AcVswrValue  *acVswrValue)
{
    if(s_AcModule.pGetVswrValueIc == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(acVswrValue == NULL)
    {
        dbgErr("Func [%s] acVswrValue is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pGetVswrValueIc(acVswrValue);
}

///写入AC序列
UINT32 BspSetVswrSeq(UINT32 radioMode, UINT32 bandWidth)
{
    return s_AcModule.pVswrSetSeq(radioMode,bandWidth);
}


//设置驻波发数帧号
UINT32 BspUpdateR8VswrStartFrameNo(UINT32 frameNo, UINT32 acType, UINT32 bitMap)
{
    return s_AcModule.pVswrUpdateR8StartFrameNo(frameNo,acType,bitMap);
}


//获取驻波值
UINT32 BspGetVswrFwdRevData(UINT32 *pVswrFwdData, UINT32 *pVswrRevData)
{
    if((pVswrFwdData == NULL)||(pVswrRevData == NULL))
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    return s_AcModule.pVswrGetFwdRevData(pVswrFwdData,pVswrRevData);

}

//查询驻波完成状态接口,*puiCalSta为0表示未完成，1表示完成
UINT32 BspGetVswrCalSta(UINT32 *puiCalSta)
{
    if(puiCalSta == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pVswrGetCalSta(puiCalSta);
}

//fwd数据保存bsp接口
UINT32 BspSetVswrFwdVal(UINT32 *puiVswrFwdVal)
{
    if(puiVswrFwdVal == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pVswrSetFwdVal(puiVswrFwdVal);
}

//判断是否是耦合通道所在的IC芯片，为0表示不是耦合通道所在的IC芯片，1表示耦合通道所在的IC芯片
UINT32 BspGetVswrCoupleingIcType(UINT32 *puiVswrCoupleingIcType)
{
    if(puiVswrCoupleingIcType == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pVswrGetCoupleingIcType(puiVswrCoupleingIcType);
}

///切换TDD状态
UINT32 BspSetVswrTypeToTddType(UINT32 radioMode, UINT32 carrNo)
{

    return s_AcModule.pVswrTypeToVswrType(radioMode,carrNo);
}

//配置驻波参数
UINT32 BspSetVswrPara(UINT32 acType)
{
    INPUT_POINTER_CHECK(s_AcModule.pSetVswrPara);
    return s_AcModule.pSetVswrPara(acType);
}

//配置驻波的FWD参数
UINT32 BspSetVswrFwdPara(UINT32 acType)
{
    INPUT_POINTER_CHECK(s_AcModule.pSetFwdPara);
    return s_AcModule.pSetFwdPara(acType);
}

//获取驻波状态
UINT32 BspGetVswrCalFinishSta(UINT32 *puiCalSta)
{
    INPUT_POINTER_CHECK(puiCalSta);
    INPUT_POINTER_CHECK(s_AcModule.pGetVswrCalFinishSta);
    return s_AcModule.pGetVswrCalFinishSta(puiCalSta);
}

//获取驻波值
UINT32 BspGetVswrData(UINT32 acType)
{
    INPUT_POINTER_CHECK(s_AcModule.pGetVswrData);
    return s_AcModule.pGetVswrData(acType);
}

UINT32 BspFtmGetFrameNo(VOID)
{
    UINT32 frameNo = 0;
    frameNo = IcHalGetFrameNo();
    return frameNo;
}

UINT32 BspGetWgtByCmplNumMult(T_AcWgtComplexData *pxfDatInA, T_AcWgtComplexData *pxfDatInB, T_AcWgtComplexData *pxfDatOut)
{
    INT16 wgtI = 0;
    INT16 wgtQ = 0;
    DOUBLE cxfDatInBReal = 0;
    DOUBLE cxfDatInBImag = 0;
    const DOUBLE wgtOffetVal = 16384;   /* pow(2,14) */;

    INPUT_POINTER_CHECK(pxfDatInB);
    INPUT_POINTER_CHECK(pxfDatInA);
    INPUT_POINTER_CHECK(pxfDatOut);

    cxfDatInBReal = pxfDatInB->real / wgtOffetVal;
    cxfDatInBImag = pxfDatInB->imag / wgtOffetVal;
    wgtI = (INT16)(pxfDatInA->real * cxfDatInBReal - pxfDatInA->imag * cxfDatInBImag);
    wgtQ = (INT16)(pxfDatInA->real * cxfDatInBImag + pxfDatInA->imag * cxfDatInBReal);
    pxfDatOut->real = wgtI;
    pxfDatOut->imag = wgtQ;

    return BSP_OK;
}

UINT32 BspSetWgtToDefVal(UINT32 *pWgtData, UINT32 wgtNum)
{
    UINT32 wgtLoop = 0;
    const UINT32 defWgtVal = 0x40000000;

    INPUT_POINTER_CHECK(pWgtData);

    for (wgtLoop = 0; wgtLoop < wgtNum; wgtLoop++)
    {
        pWgtData[wgtLoop] = defWgtVal;
    }

    return BSP_OK;
}

UINT32 testpimrbwgt(UINT32 rbStart, UINT32 rbNum, UINT32 chanMap)
{
    T_PimWgtCarrInfo aacCarrInfo = { 0 };
    UINT32 disableRbStart = 0;
    UINT32 disableRbNum = 0;
    UINT32 disableTxChanMap = 0;

    aacCarrInfo.carrNo = 0;
    aacCarrInfo.radioMode = 0x4000;
    aacCarrInfo.trxType = 1;
    disableRbStart = rbStart;
    disableRbNum = rbNum;
    disableTxChanMap = chanMap;

    return BspSetPimRbWgt(&aacCarrInfo, disableRbStart, disableRbNum, disableTxChanMap);
}

/* AAC天线选择功能 D42空接口 */
UINT32 BspSetAacChoiceAntMask(UINT32 uCellIdx, UINT32 uAntMask)
{
    return BSP_OK;
}

UINT32 BspGetChanSnr(T_AcRepDspPara *ptAcReqDspPara,INT32 *piSnr)
{
    if(ptAcReqDspPara == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspGetChanSnr(ptAcReqDspPara,piSnr);
}

UINT32 BspGetChanTimeDly(T_AcRepDspPara *ptAcReqDspPara,INT32 *piTimeDly)
{
    if(ptAcReqDspPara == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspGetChanDelay(ptAcReqDspPara,piTimeDly);
}

UINT32 BspGetChanPhase(T_AcRepDspPara *ptAcReqDspPara,INT32 *piPhase)
{
    if(ptAcReqDspPara == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspGetChanPhase(ptAcReqDspPara,piPhase);
}

UINT32 BspGetAcVaildAntNum(T_UpAcValidAntInfo* ptAcValidAntInfo)
{
    
    if((s_AcModule.pBspGetAcVaildAntNum == NULL)||(ptAcValidAntInfo == NULL))
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspGetAcVaildAntNum(ptAcValidAntInfo);
}

UINT32 BspSetAcVaildAntNum(UINT32 data, T_UpAcValidAntInfo* ptAcValidAntInfo)
{
    if((s_AcModule.pBspSetAcVaildAntNum == NULL)||(ptAcValidAntInfo == NULL))
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspSetAcVaildAntNum(data, ptAcValidAntInfo);
}
/* Started by AICoder, pid:e01fbv109bvdec014af608fb4038261d80198ea2 */
UINT32 BspGetLteCoupleNetFactor(UINT32 uiAnt, UINT32 uiCenterFreq, UINT32 uiBandWidth, T_acCoupleNet *pAcCpNet)
{
    if(s_AcModule.pBspGetLteCoupleNet == NULL)
    {
        dbgErr("Func [%s] is NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(pAcCpNet == NULL)
    {
        dbgErr("Func [%s] input para NULL \n",__FUNCTION__);
        return BSP_ERROR;
    }

    return s_AcModule.pBspGetLteCoupleNet(uiAnt, uiCenterFreq, uiBandWidth, pAcCpNet);
}
/* Ended by AICoder, pid:e01fbv109bvdec014af608fb4038261d80198ea2 */

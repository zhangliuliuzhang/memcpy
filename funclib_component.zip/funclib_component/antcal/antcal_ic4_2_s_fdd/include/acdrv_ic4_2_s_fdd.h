#ifndef _DPDICHAL_ACDRV_H_
#define _DPDICHAL_ACDRV_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "exprn.h"
#include "secure_func.h"
#include "vxadp.h"
#include "resource_alloc_info.h"
#include "vgactrl_api.h"
#include "antcalcommon.h"
#include "ichaladaptbspapi.h"
#include "antcal_ic4_2_oneic.h"
//#include "io_ctrl.h"

#define AC_TYPE_DL                0   //代表下行
#define AC_TYPE_UL                1   //代表上行
#define AC_TYPE_STOP              2   //代表结束AC
#define VSWR_TYPE_FWD             3   //代表FWD
#define VSWR_TYPE_REV             4   //代表REV
#define VSWR_TYPE_STOP            5   //代表结束VSWR

#define AC_TYPE_FDD_DL            8   //代表fdd下行
#define AC_TYPE_FDD_UL            9   //代表fdd上行

#define IC_AC_RETRY_TIME 16
#define IC_AC_ROUND_TIME 9
#define IC_AC_POINT_NUM  1024
#define IC_AC_ULBANK_RAM_NUM 32

#define acDrvAcSeqPntCnt          1024
#define acDrvAcSeqPntCntLte       512
#define acDrvAcSeqPntCntLtePaste  1024
#define acPulseDataLen           ((acDrvAcSeqPntCnt)*64)
#define AC_CELL_SEPARATE_MODE     1

#define AC_INSERT_0_POS     0
#define AC_INSERT_1_POS     1
#define AC_INSERT_2_POS     2
#define AC_INSERT_3_POS     3

#define AC_PHASE_DIFF_MODE        1

#define AC_NOT_CHANGE_CALC_CHN    0
#define AC_CHANGE_CALC_CHN        1

#define CATCH_RAM_EN_ON   1
#define CATCH_RAM_EN_OFF  0
#define BAND_IS_SELECT    1

#define AC_DATA_LEN_1024          1024
#define AC_DATA_LEN_768           768
#define AC_DATA_LEN_512           512
#define AC_DATA_LEN_384           384
#define AC_DATA_LEN_256           256
#define AC_DATA_LEN_128           128
#define GSM_AC_DATA_LEN           0

#define AC_DATA_OFFSET_128        128
#define AC_DATA_OFFSET_96         96
#define AC_DATA_OFFSET_64         64
#define AC_DATA_OFFSET_48         48
#define AC_DATA_OFFSET_32         32
#define AC_DATA_OFFSET_16         16
#define GSM_AC_DATA_OFFSET        0

#define AC_CP_64                  64
#define AC_CP_48                  48
#define AC_CP_32                  32
#define AC_CP_24                  24
#define AC_CP_16                  16
#define AC_CP_8                   8
#define GSM_AC_CP                 0

#define AC_GP_LEN_NR                 4388   //(4448+4384*13)/14=4388
#define AC_DL_DATA_POS_TO_3GP_LEN_NR 600
#define AC_UL_DATA_POS_TO_3GP_LEN_NR 1096

#define AC_EPLD_GP_NUM_1      1
#define AC_EPLD_GP_NUM_2      2

#define AC_FREQ_BAND_S35     0
#define AC_FREQ_BAND_S26     1

#define ANT_NUM_PER_IC     (8)

#define FRAME_TYPE_2P5MS           2500
#define FRAME_TYPE_5MS             5000
#define FRAME_TYPE_10MS            10000
#define FRAME_TYPE_20MS            20000

#define PER_SLOT_NUM_NR (61440)
#define PER_SUB_FRAME_NUM_LTE (30720)
#define UMTS_INSERT_DELAY (11520)

//参数范围检查
#define INPUT_AC_PARAMETER_CHECK(para, maxVal)                                 \
    do                                                                         \
    {                                                                          \
        if ((para) >= (maxVal))                                                \
        {                                                                      \
            dbgErr("[%s] Input para'%lu (>= maxVal'%lu) Error!! \n", __FUNCTION__, ((unsigned long)para), ((unsigned long)maxVal)); \
            return BSP_ERROR;                                                  \
        }                                                                      \
    } while(0)

#define INPUT_AC_CHECK_OVERTAKE(para, maxVal)                                 \
    do                                                                         \
    {                                                                          \
        if ((para) > (maxVal))                                                \
        {                                                                      \
            dbgErr("[%s] Input para'%d (> maxVal'%d) Error!! \n", __FUNCTION__, (para), (maxVal)); \
            return BSP_ERROR;                                                  \
        }                                                                      \
    } while(0)

#define INPUT_AC_ZERO_CHECK(para)                                     \
    do                                                                \
    {                                                                 \
        if ((para) == 0 )                                             \
        {                                                             \
            dbgErr("[%s] Input para is zero!! \n", __FUNCTION__);     \
            return BSP_ERROR;                                         \
        }                                                             \
    } while(0)

#define Bit_VAL_VALID 1

#define JAC_TA_MAX 200
#define JAC_TA_MIN -200

#define SAMPLE_DLY_MAX 32
#define SAMPLE_DLY_MIN -32

#define MAX_BANDNO_NUM      12
#define RESET_BANDNO_ENABLE 1

#define MGC_ATT_CTRL_ON 1

//载波拼接拆分标志
enum
{
    CARR_NOT_PASTE = 0,
    CARR_IS_PASTE  = 1,
    CARR_IS_SPLIT  = 2
};

enum
{
    AC_BAND_0 = 0,
    AC_BAND_1,
    AC_BAND_2,
    AC_BAND_3,
    AC_BAND_4
    
};
//重置后bandNo索引
/* Started by AICoder, pid:xc732t84d73251b1401a0b8890a3391d36374c0c */
#include <stdio.h>

// 定义一个枚举类型
enum 
{
    CALC_BANDNO_0 = 0,
    CALC_BANDNO_1,
    CALC_BANDNO_2,
    CALC_BANDNO_3,
    CALC_BANDNO_4,
    CALC_BANDNO_MAX
};
/* Ended by AICoder, pid:xc732t84d73251b1401a0b8890a3391d36374c0c */

enum 
{
    ICNO_0 = 0,
    ICNO_1,
    ICNO_2,
    ICNO_3,
    ICNO_4,
    ICNO_5,
    ICNO_6,
    ICNO_7,
    ICNO_MAX
};
typedef enum
{
    AC_ROUND_0 = 0,
    AC_ROUND_1,
    AC_ROUND_2,
    AC_ROUND_3,
    AC_ROUND_4,
    AC_ROUND_5,
    AC_ROUND_6,
    AC_ROUND_7,
    AC_ROUND_8,
    AC_ROUND_9,
    AC_ROUND_NUM = 9
}E_AC_ROUND_LIST;

typedef enum
{
    AC_DL_ANTS_NUM_0 = 0,
    AC_DL_ANTS_NUM_1,
    AC_DL_ANTS_NUM_2,
    AC_DL_ANTS_NUM_3,
    AC_DL_ANTS_NUM_4,
    AC_DL_ANTS_NUM_5,
    AC_DL_ANTS_NUM_6,
    AC_DL_ANTS_NUM_7,
    AC_DL_ANTS_NUM_8,
    AC_DL_ANTS_NUM_9,
    AC_DL_ANTS_NUM_10,
    AC_DL_ANTS_NUM_11,
    AC_DL_ANTS_NUM = 12,
    AC_UL_ANTS_NUM = 12,
    MAX_ANT_NUM    = 64
}E_AC_DL_ANTS_NUM_LIST;//同时发送的天线个数

typedef enum
{
    AC_IC_0 = 0,
    AC_IC_1,
    AC_IC_2,
    AC_IC_3,
    AC_IC_4,
    AC_IC_5,
    AC_IC_6 = 6,
    AC_IC_7,
    AC_IC_NUM = 8
}E_AC_IC_LIST;//同时发送的天线个数

typedef struct CMPL16
{
    INT16 real;
    INT16 imag;
}CMPL16;

enum
{
    AC_SEQ_GAIN_ON = 0,
    AC_SEQ_GAIN_OFF
};

enum
{
    OPT_PROTOCOL_CPRI = 0,
    OPT_PROTOCOL_IR
};

enum
{
    SCENE_RCUA_OFF = 0,
    SCENE_RCUA_ON
};

enum
{
    IO_INVALID_CHIP = 0,
    IO_VALID_CHIP
};

typedef struct tag_ichal_acpara_delay_structure_para
{
    UINT32 acUlBankCompensateWaitDelay;       /* UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelay50MNr;  /* NR 50M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelay45MNr;  /* NR 45M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelay40MNr;  /* NR 40M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr80M;  /* NR 80M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr60M;  /* NR 60M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr20M;  /* NR 20M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr25M;  /* NR 20M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr30M;  /* NR 30M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr15M;  /* NR 15M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr10M;  /* NR 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayNr5M;   /* NR 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayPasteCarr;
    UINT32 acUlBankCompensateWaitDelayLte15M; /* LTE 15M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayLte10M; /* LTE 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayLte5M;  /* LTE 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acUlBankCompensateWaitDelayUmts;   /* UMTS UlBank采数等待延时补偿值*/
    //RCUA新增
    UINT32 acRcuaUlBankCompensateWaitDelayLte20M; /* LTE 15M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acRcuaUlBankCompensateWaitDelayLte15M; /* LTE 15M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acRcuaUlBankCompensateWaitDelayLte10M; /* LTE 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
    UINT32 acRcuaUlBankCompensateWaitDelayLte5M;  /* LTE 10M UlBank采数等待延时补偿值(用来规避链路延时误差)*/
}T_ICHAL_ACPARA_DELAY;

typedef struct tBandNoRedefinition
{
    UINT32 uiRedefFlag;  // 是否使用新的频段号匹配规则
    UINT32 uiRceBandNo[MAX_BANDNO_NUM][2];  // 一列为APP下发的频段号(与协议保持一致)，二列为转义后的频段号
    UINT32 reserve;      // 保留
}T_BandNoRedefinition;

#pragma pack()
typedef struct tag_ichal_ac_drv_structure_para
{
    //A53
    T_ICHAL_ACPARA_DELAY acNrCfgPara;
    T_ICHAL_ACPARA_DELAY acLteCfgPara;
    T_ICHAL_ACPARA_DELAY acUmtsCfgPara;
    T_BandNoRedefinition acBandNoRedefinition;        /* 配置BandNo*/

    UINT32 acOffset;                    /* 序列偏移 */
    UINT32 icNum;                       /* IC数 */
    UINT32 dlAntNum;                    /* 下行每轮天线数 */
    UINT32 acIcMaxAntNo;                /* 每片IC最大天线数 */
    UINT32 insertTimes;                 /* FDD inslot 内插次数*/
    UINT32 uiUmtsInsertTimes;           /* UMTS inslot 内插次数 */

    UINT32 acDlRoundNo;                 /* 下行校正分组数 */
    UINT32 acUlRoundNo;                 /* 上行校正天线数 */

    UINT32 acCatchData[ICNO_MAX][CALC_BANDNO_MAX];   /* 耦合通道 */
    UINT32 acSendData[ICNO_MAX][CALC_BANDNO_MAX];    /* 校准通道 */
    UINT32 acIoCatchInvaildChip[ICNO_MAX];                /* 耦合开关控制有效IC */
    UINT32 acIoSendInvaildChip[ICNO_MAX];                 /* 校准开关控制有效IC */


    UINT32 uiFddCtrlIc;                  /* fDD控制开关所在的芯片号 */
    UINT32 uiAttCtrlIc;                 /* MGC模式控制rx att开关 */
    UINT32 uiAttValue;                  /* MGC模式rx att衰减值 */
    UINT32 uiRcuaScene;                 /* Rcua并柜场景*/

    UINT32 (*pSetAcSyncEn)(UINT32 actype);
    UINT32 (*pMtsNcoCfg)(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 uiBandWidth, A53R8AcDebugShareInfo* shareInfo); /*MTS 配频接口*/
    INT32  (*pGetAcDspNco)(VOID);        /* 获取AC DSP NCO */
    UINT32 (*pSetAcTddRfSwitch)(UINT32 acType); /* 切换AC开关TDD时序*/
    UINT32 (*pAntBitToChanBit)(UINT32 *puiBitMap);

}T_ICHAL_ACPARA;

typedef struct IcHalAcBoardInfo
{
    UINT32 shareMemPhyAddrBase;      //物理首地址
    VOID* shareMemVirAddrBase;      //虚拟首地址
    UINT32 shareMemAllSize;          //共享空间总大小
    
    UINT32 dlAcUlBankCatchAddrOffset;//存放用于下行校正的ulBank采数，需要区分不同的RAM
    UINT32 dlAcUlBankCatchSize;      //存放用于下行校正的ulBank采数，需要区分不同的RAM
    UINT32 ulAcUlBankCatchAddrOffset;//存放用于上行校正的ulBank采数，需要区分不同的RAM
    UINT32 ulAcUlBankCatchSize;      //存放用于上行校正的ulBank采数，需要区分不同的RAM
    
    UINT32 dlBank0AxisDmaAddrOffset; //存放4个dlBank Axis写序列的地址，用于维测回读用

    UINT32 dlAcBlockBankInfoAddrOffset;  //存放下行AC的block和bank信息的地址，要传给R8
    UINT32 dlAcBlockBankInfoSize;        //存放下行AC的block和bank信息的地址，要传给R8
    UINT32 ulAcBlockBankInfoAddrOffset;  //存放上行AC的block和bank信息的地址，要传给R8
    UINT32 ulAcBlockBankInfoSize;        //存放上行AC的block和bank信息的地址，要传给R8

    UINT32 AcWgtDmaInfoAddrOffset;  //存放下行和上行AC权值的DMA信息，要传给R8
    UINT32 AcWgtDmaInfoSize;        //存放下行和上行AC权值的DMA信息，要传给R8

    UINT32 a53KoDebugInfoAddrOffset;  //存放上行AC权值的DMA信息，要传给R8
    UINT32 a53KoDebugInfoSize;        //存放上行AC权值的DMA信息，要传给R8

    UINT32 vgaDataAddrOffset;  //存放上行AC读取的vga数据的地址
    UINT32 vgaDataSize;        //存放上行AC读取的vga数据的数据长度

    UINT32 phaDiffSeqAddrOffset;  //残余相差模式下16通道序列数据
    UINT32 phaDiffSeqSize;

    UINT32 phaDiffAxisDmaAddrOffset;  //残余相差模式下,存放4个dlBank Axis写序列的地址，用于维测回读用

    UINT32 VswrBlockBankOffset;     //用于存放驻波计算时的block和bank信息
    UINT32 VswrBlockBankSize;      //用于存放驻波计算时的block和bank信息的大小

    UINT32 VswrTddSwitchOffset;     //用于存放驻波计算时的Tdd参数信息
    UINT32 VswrTddSwitchSize;      //用于存放驻波计算时的Tdd参数大小

    UINT32 VswrRevSwitchOffset;     //用于存放驻波计算时的Tdd参数信息
    UINT32 VswrRevSwitchSize;      //用于存放驻波计算时的Tdd参数大小

}IcHalAcBoardInfo;

typedef struct ICRDlRBlockBankInfo
{
    UINT32 dlIsSet[AC_DL_ANTS_NUM];   //用于动态配置
    UINT32 dlBank[AC_DL_ANTS_NUM];    //bank

    UINT32 ulIsSet[AC_DL_ANTS_NUM];   //用于动态配置
    UINT32 ulBank[AC_DL_ANTS_NUM];    //bank
    UINT32 ulVgaChn[AC_DL_ANTS_NUM];  //vga chan
    UINT32 ulVgaDelay[AC_DL_ANTS_NUM];//vga delay

    UINT32 dlDifChn[AC_DL_ANTS_NUM];
    UINT32 ulDifChn[AC_DL_ANTS_NUM];
    UINT32 reserve[160];
}ICRDlRBlockBankInfo;//必须是1024字节

typedef struct ICRRBlockBankDL
{
    ICRDlRBlockBankInfo bBInfo[AC_ROUND_NUM];//9轮,9*1024 = 9K
}ICRRBlockBankDL;//IC内部的处理，总共9轮，每一轮的信息

typedef struct ICRUlRBlockBankInfo
{
    UINT32 dlIsSet[AC_UL_ANTS_NUM];    //用于动态配置
    UINT32 dlBank[AC_UL_ANTS_NUM];     //bank

    UINT32 ulIsSet[AC_UL_ANTS_NUM];    //用于动态配置
    UINT32 ulBank[AC_UL_ANTS_NUM];     //bank
    UINT32 ulVgaChn[AC_UL_ANTS_NUM];   //vga chan
    UINT32 ulVgaDelay[AC_UL_ANTS_NUM]; //vga delay

    UINT32 dlDifChn[AC_UL_ANTS_NUM];
    UINT32 ulDifChn[AC_UL_ANTS_NUM];
    UINT32 reserve[160];
}ICRUlRBlockBankInfo;//必须是1024字节

typedef struct ICRRBlockBankUL
{
    ICRUlRBlockBankInfo bBInfo[1];
}ICRRBlockBankUL;//IC内部的处理，总共9轮，每一轮的信息

typedef struct L2dAcWgtR8DmaInfo
{
    UINT32 srcPhyAddr;
    UINT32 dstPhyAddr;
    UINT32 dataSize;
    UINT32 frameNo;
	UINT32 uDir;
	UINT32 pasteCarrFlag;
    UINT32 reserve[250];
}L2dAcWgtR8DmaInfo;//凑成1K

typedef struct tagIcAcShareMemInfo_dlAcCatchData
{
    UINT32 dlAcCatchData[IC_AC_ROUND_TIME][IC_AC_POINT_NUM];//4*16*9*1024 = 576KB
}dlAcCatchData;

typedef struct tagIcAcShareMemInfo_ulAcCatchData
{
    UINT32 ulAcCatchData[IC_AC_ULBANK_RAM_NUM][IC_AC_POINT_NUM]; //4*64*1024   = 64KB
}ulAcCatchData;

typedef struct tagIcAcShareMemInfo_dlSeqDmaStore
{
    UINT32 dlBankDmaSeq[IC_AC_POINT_NUM];                  //4*1024*4    = 16KB
}dlSeqDmaStore;

typedef struct UlAcVgaData
{
    UINT32 vga[IC_AC_RETRY_TIME][AC_UL_ANTS_NUM];//2KB，正好是2KB
}UlAcVgaData;//凑成2K

typedef struct tagIcAcShareMemInfo
{
    ulAcCatchData ulAcCatch[IC_AC_RETRY_TIME];//4*32*1024*16 = 2MB
    dlAcCatchData dlAcCatch[IC_AC_RETRY_TIME];//4*16*9*1024  = 576KB

    ICRRBlockBankDL dlbBInfo;                   //9*1024       = 9KB 下行AC的分组关系
    ICRRBlockBankUL ulbBInfo;                   //2*1024       = 2KB 上行AC的分组关系

    L2dAcWgtR8DmaInfo AcWgtR8DmaInfo;          //权值的DMA信息，下行AC和上行AC公用1段地址，1KB，实际没有那么大，预留了很多，凑成1K

    A53R8AcDebugShareInfo  a53R8ShareInfo; //调试信息，1KB，实际没有那么大，预留了很多，凑成1K
    UlAcVgaData ulAcVgaData;//2KB的16轮迭代的的上行VGA采数结果
}IcAcShareMemInfo;

typedef struct ULROUNDANTSELInfo
{
    UINT32 ant[AC_UL_ANTS_NUM];
}ULROUNDANTSELInfo;

typedef struct DLROUNDANTSEL
{
    UINT32 ant[AC_ROUND_NUM][AC_DL_ANTS_NUM];
}DLROUNDANTSEL;

typedef struct ACBLOCKBANKNEEDINFO
{
    DLROUNDANTSEL dlAcRoundAntSel[AC_IC_NUM];//下行天线选择信息
    ULROUNDANTSELInfo ulAcRoundAntSel[AC_IC_NUM];//上行天线选择信息
}ACBLOCKBANKNEEDINFO;

typedef struct _T_AC_CHN_MAP_
{
    UINT32 linkInfo[4];
} T_AC_CHN_MAP;

typedef struct _T_AC_INSLOT_SW_PARA
{
    UINT32 uiInslotDlEnable;
    UINT32 uiInslotUlEnable;
    UINT32 uiPaInslotEnable;
    UINT32 uiLnaInslotEnable;
    UINT32 uiSwitchType;
}T_AC_INSLOT_SW_PARA;

enum _AC_MAP_DEF_
{
    AC_RFCHN = 0,     /* 射频通道 */
    AC_DIFCHIPID,     /* 中频芯片id */
    AC_ANTID,         /* 天线号 */
    AC_ANTCHN,        /* 频段*/
    MAP_INFO_NUM
};

typedef enum
{
    E_CORE_INT_DL_AC_CATCH_DATA_INDEX       = 0x0100,//下行AC时的采数结果
    E_CORE_INT_UL_AC_CATCH_DATA_INDEX       = 0x0101,//上行AC时的采数结果
    E_CORE_INT_DL_BANKS_AXIS_DMA_DATA_INDEX = 0x0102,//从dlbank写序列的地方，用DMA方式把序列搬到DDR
    E_CORE_INT_DL_AC_BLOCK_BANK_INFO_INDEX  = 0x0103,//存放下行AC每轮的block和bank信息（也即天线分组信息）
    E_CORE_INT_UL_AC_BLOCK_BANK_INFO_INDEX  = 0x0104,//存放上行AC每轮的block和bank信息（也即天线分组信息）
    E_CORE_INT_AC_WGT_DMA_INFO_INDEX        = 0x0105,//存放上行或者下行AC的权值进行DMA的源地址、目的地址、长度等信息
    /*************************************
    存放调试和维测信息
    1，AC序列生效的psync无线帧时刻，即无线帧号
    2，AC权值生效的psync无线帧时刻，即无线帧号
    3，。。。预留
    *************************************/
    E_CORE_INT_AC_DEBUG_SHARE_INFO_INDEX    = 0x0106,
    E_CORE_INT_UL_AC_VGA_DATA_INDEX         = 0x0107,
    E_CORE_INT_PHASE_DIFF_SEQ_DATA_INDEX    = 0x0108,
    E_CORE_INT_UPDAT_ACCA_PHASE_COMPVAL     = 0x0109,
    E_CORE_INT_DL_AC_CATCH_DATA_MAX         = 0x010a,
    E_CORE_INT_CATCH_RAM_BLOCK_INDEX        = 0x010b,
    E_CORE_INT_VSWR_RAM_BLOCK_INDEX         = 0x010c
}E_A53_R8_CORE_INT_INDEX;

typedef struct _T_JAC_TA_PARA
{
    UINT32 uiJacType;
    UINT32 uiCarrId;
    UINT32 uiRadioMode;
    UINT32 uiBandWidth;
    UINT32 uiPasteCarrFlag;
    UINT32 uiAntBitmap;
    UINT32 uiSampleRate;
}T_JAC_TA_PARA;

extern UINT32 g_acCatchDataPos; 
extern UINT32 g_acInsertPos; 
void SetAcInsertPos(UINT32 inPut);
UINT32 GetAcInsertPos();
VOID   BspSetBandNo(UINT32 inPut);
UINT32 BspGetBandNo(VOID);
UINT32 BspGetBandSendChn(UINT32 uiBandNo);
UINT32 BspGetBandSendChipId(VOID);
UINT32 BspGetBandCatchChn(VOID);
UINT32 BspGetBandCatchChipId(VOID);
UINT32 IcHalSetBoardInfoInit(IcHalAcBoardInfo* data);
UINT32 IcHalInitUlBank(VOID);//静态上电写死
UINT32 IcHalInitDlBank(VOID);//静态上电写死
UINT32 BspGetAntNoByRoundInfo(UINT32 rpuId, UINT32 round);
UINT32 BspGetAntNoByDlAcRoundAntSel(UINT32 round, UINT32 rpuId, UINT32 array);
UINT32 BspAcChanMapInfoInit(const T_AC_CHN_MAP *pLinkMap, UINT32 linkNum);
UINT32 BspSetAcFreqBandId(UINT32 FreqId);
UINT32 BspGetAcFreqBandId(VOID);
UINT32 IcHalAcInsrtDataWrRam(UINT32 acType, UINT32 *seq, UINT32 dataLen,UINT32 length,UINT32 radioMode,UINT32 carrNo);
UINT32 IcHalDlSetUlBankCatchRamRoundCfg(UINT32 ic, A53R8AcDebugShareInfo* a53R8ShareInfo);
UINT32 IcHalInitAntSelInfo(ACBLOCKBANKNEEDINFO* acBlockBankNeedInfo);
UINT32 BspInitAcCfgPara(T_ICHAL_ACPARA* acCfgPara);
UINT32 IcHalUlSetUlBankCatchRamRoundCfg(UINT32 ic, A53R8AcDebugShareInfo* a53R8ShareInfo);
UINT32 GetdGp2Ac(UINT32 acType, UINT32 radio,DOUBLE* Gp2Ac);
UINT32 GetdGp2AcEnd(UINT32 acType, UINT32 radio, DOUBLE* Gp2AcEnd);
UINT32 BspGp2Ac(UINT32 acType, UINT32 radio, UINT32 carrNo,DOUBLE* Gp2Ac);
UINT32 BspGp2AcEnd(UINT32 acType, UINT32 radio,UINT32 carrNo, DOUBLE* Gp2AcEnd);
UINT32 BspGetAcEndInsert0Num(UINT32 acType,UINT32 radioMode,UINT32 carrNo,UINT32 bw,UINT32 pasteCarrFlag);
UINT32 BspGetAcInsertDelay(UINT32 acType, UINT32 radio, UINT32 carrNo,UINT32 gpNum,UINT32 bw,UINT32 pasteCarrFlag);
T_ICHAL_ACPARA* getAcParaAddr(VOID);
UINT32 acReduceRankAntSel(A53R8AcDebugShareInfo* shareInfo, UINT32 refChn, UINT32 radioMode);
UINT32 getCoupleChanRpuId(UINT32* calcChnIcNo, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetBlockBankInfo(UINT32 radioMode, UINT32 carrNo,UINT32 dataOffset, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalsetRefChnInfoToKo(A53R8AcDebugShareInfo* shareInfo,UINT32 refChn,UINT32 radioMode);
UINT32 IcHalSetAcInsertData(UINT32 acSeqLen, UINT32 acCpLen);
UINT32 IcHalSetDlInsertFrontDelayPoint(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 pasteCarrFlag,UINT32 bandWidth,UINT32 acGpNum);
UINT32 IcHalSetUlBankAllBlockCatchRamEnOff(VOID);
UINT32 IcHalCompensateUlBankCatchRamWaitDelayPoint(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 pasteCarrFlag,UINT32 bandWidth,UINT32 acGpNum);
VOID   IcHalUlAcRoundCfg(UINT32 ic, UINT32 round);
UINT32 IcHalSetDlBankAcSequenceInsertRoundCfg(UINT32 ic, UINT32 round);
UINT32 IcHalSetUlBankCatchRamClearAllInts(VOID);
UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag);
UINT32 IcHalCopyBlockBankInfoToShareMem();
UINT32 IcHalSetDlbankAcInsertPos(UINT32 acInsertPos);
UINT32 IcHalSetTddFlgDly(UINT32 radioMode, UINT32 carrNo,UINT32 acInsertPos);
UINT32 IcHalGetDLFrameDly(UINT32 uiCalAntNum, UINT32 uiCarrNo, UINT32 uiRadioMode);
UINT32 IcHalDmaMoveDataFromUlBankCatchRamToDdrShareMem(UINT32 round,UINT32 actype);
UINT32 BspSetAcInslotIoCtrl(UINT32 acType,UINT32 radioMode,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo,A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetFddDlInsertCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn,
                                  T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara);
UINT32 IcHalGetFrameTypeForAc(UINT32 uCarrNo,UINT32 radioMode);
UINT32 IcHalSetAcOrAAcMode(UINT32 Mode);
UINT32 IcHalFddSetFrPara(T_ICHAL_ACPARA* acPara, UINT32 frameNo);
UINT32 IcHalSetFddUlInsertCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn,
                                  T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalAcSetDlGpEn(UINT32 acType, UINT32 carrNo, UINT32 radioMode);
UINT32 IcHalSetAcRamPara(UINT32 seqLen,UINT32 cpLen);
UINT32 IcHalSetFrPara(UINT32 acType,T_ICHAL_ACPARA* acPara);
UINT32 acCatchDataChnInfo(A53R8AcDebugShareInfo* shareInfo, UINT32 radioMode, T_ICHAL_ACPARA* acPara);
UINT32 ICHalSetUlbankAcDataRouterCfg(UINT32 acCatchDataPos);
UINT32 IcHalSetFddAcRamPara(UINT32 seqLen,UINT32 cpLen,T_ICHAL_ACPARA* acPara,UINT32 acType,UINT32 radioMode);
UINT32 BspSetMtsNcoPara(UINT32 acType, UINT32 carrNo, UINT32 radioMode, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetFddDlCatchCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo,
                                 UINT32 slotNo, UINT32 refChn, T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara, A53R8AcDebugShareInfo* shareInfo);
UINT32 IcHalSetFddUlCatchCfgPara(UINT32 actype,UINT32 carrNo,UINT32 radioMode,UINT32 bandWidth,UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo, UINT32 refChn, T_AcParaInfo *ptAcParaInfo,T_ICHAL_ACPARA* ptAcPara);
UINT32 BspAcKoInit(VOID);
UINT32 BspGetRfChnbyAntNum(UINT32 uiAntNo, UINT32 uiBandNo, UINT32 dir);
UINT32 BspGetAntCpyInfo(UINT32 uiDestDifChn, UINT32 uiSrcDifChn, A53R8AcDebugShareInfo* shareInfo);
UINT32 BspRestAcInt(VOID);
UINT32 BspGetWgtBitmap(UINT32 uiAcType);
UINT32 BspProcJacTaDelay(T_JAC_TA_PARA *ptJacTapara, UINT32 *puiWgtByteLen, UINT32 *puiWgtDataLen, UINT32 *pWgtData, UINT32 trxLength);
UINT32 BspSetAcSeqGainSw(UINT32 uiSw);
UINT32 BspCheckJacBitMap(UINT32 uiAntNum);
UINT32 BspSetAlgTimePhaAndGain(UINT32 uiAcType, UINT32 uiCarrNo, UINT32 uiRadioMode, UINT32* puiWgt, T_AcParaInfo *ptAcParaInfo);
UINT32 BspGetDifChnbyAntNum(UINT32 uiAntNo, UINT32 uiBandNo, UINT32 dir, UINT32 *uiDifChn);
void BspSetBandChangeFlag(UINT32 input);
UINT32 BspGetBandChangeFlag();
UINT32 BspAdjustUmtsFr(UINT32 uiRadioMode, UINT32 *puiFrameNo);


#ifdef _AC_PRINTF_EN_
#define acprintf(fmt,...)     printf(fmt,##__VA_ARGS__)
#define acprintfEx(fmt,...)   dbgInfoEx(fmt,##__VA_ARGS__)
#else
#define acprintf(fmt,...)
#define acprintfEx(fmt,...)
#endif

#ifdef __cplusplus
}
#endif
#endif

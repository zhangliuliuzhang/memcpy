/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : antcal.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了天线校正接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳: 2019-03-21
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _ANTCAL_IC4_2_FDD_H_
#define _ANTCAL_IC4_2_FDD_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "antcalapi.h"
#include <linux/if_packet.h>

#define KXCPSW_AC_DEV                    "/dev/cpsw_ac"
#define CPSW_SET_ADDR_INFO              (0x11)
#define CPSW_AC_DEBUG                   (0x33)
#define CPSW_GET_INFO                   (0x44)
#define CPSW_AC_DATA_GET                (0x55)
#define CPSW_AC_START_SET               (0x66)  
#define AC_SIZE_1K                      (1024)
#define AC_SIZE_512K                    (AC_SIZE_1K*512)
#define AC_SIZE_1M                      (AC_SIZE_1K*1024)
#define AC_SIZE_1G                      (AC_SIZE_1M*1024)

//AC序列的大小
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_1024     1024*4  //CPU读取DSP计算出来的AC发送序列 大小
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_768      768*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_512      512*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_384      384*4
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE_256      256*4
/****************************************************************/

/**********************IC A53与R8共享内存起始和大小*****************************
****************************************************************/
#define IC_AC_SHARE_MEM_ADDR_PHY_BASE           0x01200000
#define IC_AC_SHARE_MEM_ADDR_SIZE               0x00400000   //4.5M

/**********************上行校正采数*****************************
 16轮重复迭代*每轮1次发完64T(每次1发64收)*采数是1024个点*4字节
 由于每个IC各收各的，所以实际每个IC是1发32收，对应大小是1024*4*32*16 = 2MB
 绝对地址:0x0200_0000
 大小:    2MB
 范围:    0x0200_0000 ~ 0x021F_FFFF
****************************************************************/
#define IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET 0x00000000//偏移地址0x0000_0000
#define IC_AC_SHARE_MEM_UL_CATCH_DATA_SIZE         0x00200000//大小为0x0020_0000，2MB

/**********************下行校正采数*****************************
 16轮重复迭代*每轮9次发完64T(每次8发1收)*采数是1024个点*4字节
 绝对地址:0x0220_0000
 大小:    16*9*1024*4Bytes = 0x0009_0000 = 576K
 范围:    0x0220_0000 ~ 0x0228_FFFF
****************************************************************/
#define IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET 0x00200000//偏移地址为0x0020_0000
#define IC_AC_SHARE_MEM_DL_CATCH_DATA_SIZE         0x00090000//大小为0x0009_0000, 576KB

/**************下行的9轮天线规则对应的Block Bank信息****************
 绝对地址:0x0229_0000
 大小:   ICRRBBdlBlockBankBandInfo这个结构体就是9KB大小
 范围:    0x0229_0000 ~ 0x0229_23FF
**********************************************/
#define IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_ADDR_OFFSET 0x00290000//偏移地址是0x0029_0000
#define IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_SIZE        0x00002400//大小为0x0000_2400，9K

/**************上行1轮天线规则对应Block Bank信息****************
 绝对地址:0x0229_2400
 大小:   ICRRBBulBlockBankBandInfo这个结构体就是2KB大小
 范围:    0x0229_2400 ~ 0x0229_2BFF
**********************************************/
#define IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_ADDR_OFFSET  0x00292400//偏移地址是0x0029_2400
#define IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_SIZE         0x00000800//大小为0x0000_0800，2K

/**************下行和上行AC权值数据信息:DMA搬移的源地址、目的地址、长度等信息****************
 绝对地址:0x0229_2C00
 大小:   1K
 范围:    0x0229_2C00 ~ 0x0229_2FFF
**********************************************/
#define IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_ADDR_OFFSET 0x00292C00//偏移地址是0x0029_2C00
#define IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_SIZE        0x00000400//大小为1K，即0x0000_0400

/**************调试和维测信息****************
 绝对地址:0x0229_3000
 大小:  1K
 范围:    0x0229_3000~0x0229_33FF
**********************************************/
#define IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET 0x00293000 //偏移地址是0x0029_3000
#define IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_SIZE        0x00000400//大小为1K，即0x0000_0400

/**************调试和维测信息****************
上行VGA上报数据，32根天线，每根UINT32大小数据，分16次采，共16*4*32 = 2KB
 绝对地址:0x0229_3000
 大小:  2KB
 范围:    0x0229_3000~0x0229_33FF
**********************************************/
#define IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET 0x00293400//偏移地址是0x0029_3400
#define IC_AC_SHARE_MEM_UL_AC_VGA_DATA_SIZE        0x00000800//大小为2K，即0x0000_0800

/*************************************************************/

/**********************IC A53与AC DSP共享内存起始和大小*****************************
****************************************************************/

#define IC_AC_SHARE_MEM_ADDR_PHY_BASE_A53_ACDSP 0x01600000
#define IC_AC_SHARE_MEM_ADDR_SIZE_A53_ACDSP     0x00FF0000    //A53和DSP的有效存放地址

//DSP使用的偏移地址，用于存放上下行的AC数据
#define NXP_AC_MEM_DSP_RECV_AC_SEQ_ADDR        0              //CPU读取DSP存储的上行AC数据 地址 0x00A0_0000
#define NXP_AC_MEM_DSP_RECV_AC_SEQ_SIZE        16*8*1026*4    //CPU读取DSP存储的上行AC数据大小
#define NXP_AC_MEM_DSP_TRAN_AC_SEQ_ADDR        10*AC_SIZE_1M   //CPU读取DSP存储的下行AC数据 地址 0x00B0_0000
#define NXP_AC_MEM_DSP_TRAN_AC_SEQ_SIZE        16*1026*4      //CPU读取DSP存储的下行AC数据大小

//上行频域权值的偏移地址
#define NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_ADDR  12*AC_SIZE_1M  //CPU读取DSP存储的上行频域权 地址 0x00C0_0000
#define NXP_AC_MEM_CPU_RD_UL_AC_FREQ_WGT_SIZE  64*273*4      //CPU读取DSP存储的上行频域权 大小

//下行频域权值的偏移地址
#define NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_ADDR  13*AC_SIZE_1M  //CPU读取DSP存储的下行频域权 地址 0x00D0_0000
#define NXP_AC_MEM_CPU_RD_DL_AC_FREQ_WGT_SIZE  64*273*4      //CPU读取DSP存储的下行频域权 大小

//AC序列的偏移地址
#define NXP_AC_MEM_CPU_RD_AC_SEQ_ADDR          13*AC_SIZE_1M + AC_SIZE_512K //CPU读取DSP计算出来的AC发送序列 地址 0x00D8_0000
#define NXP_AC_MEM_CPU_RD_AC_SEQ_SIZE          1024*4                      //CPU读取DSP计算出来的AC发送序列 大小

//下面定义对应结构体 T_Cmac2PulmAntAdjustScheInfo 这是APP发给BSP并写共享内存的DSP需要的信息的偏移地址
#define NXP_AC_MEM_CPU_WR_AC_INFO_ADDR         14*AC_SIZE_1M  //CPU写DSP需要的各种AC计算参数 地址0x00E0_0000
#define NXP_AC_MEM_CPU_WR_AC_INFO_SIZE         0x12D43       //CPU写DSP需要的各种AC计算参数 大小

//下面定义对应结构体T_Pulm2CmacAntAdjustRsp 这是DSP写入共享内存BSP需要的信息，包含prach权的偏移地址
#define NXP_AC_MEM_CPU_RD_AC_INFO_ADDR         15*AC_SIZE_1M  //CPU读DSP存储的恢复信息，包括prach权 地址0x00F0_0000
#define NXP_AC_MEM_CPU_RD_AC_INFO_SIZE         0x866         //CPU读DSP存储的恢复信息，包括prach权 大小

//频段号
#define BAND_18 0
#define BAND_21 1
#define BAND_26 2

#define CHIP0 0
#define CHIP1 1
#define CHIP2 2

//内插前延时
#define FRONT_ZERO_TYPE 0
#define END_ZERO_TYPE   1

#define GSM_BANDWIDTH_MHz       0

/****************************************************************/
/* GP位置计算公式类型 中移混模NR&LTE 及 单模NR */
//AC序列长度= AC原始长度+CP长度
#define GP_AC_SQUENCE_LEN_NR_122880 (1024+64) //1088
#define GP_AC_SQUENCE_LEN_NR_92160  (768+48)  //816
#define GP_AC_SQUENCE_LEN_NR_61440  (512+32)  //544
#define GP_AC_SQUENCE_LEN_NR_46080  (384+24)  //408
#define GP_AC_SQUENCE_LEN_NR_30720  (256+16)  //272

#define GP_AC_SQUENCE_LEN_LTE_30720 (512+32)  //544
#define GP_AC_SQUENCE_LEN_LTE_23040 (384+32)  //416
#define GP_AC_SQUENCE_LEN_LTE_15360 (256+16)  //272
#define GP_AC_SQUENCE_LEN_LTE_7680  (128+8)   //136

#define GP_AC_SQUENCE_LEN_UMTS_7680 (512+32)  //544

#define GP_AC_SQUENCE_LEN_FDD_NR_61440   (1024+64) //1088
#define GP_AC_SQUENCE_LEN_FDD_NR_30720   (512+32)  //544
#define GP_AC_SQUENCE_LEN_FDD_NR_15360   (256+16)  //272
#define GP_AC_SQUENCE_LEN_FDD_NR_7680    (128+8)   //136

#define GP_TIME_BASE_UPLINK  (1096)
#define GP_TIME_BASE_DOWNLIK (600)
#define AC_SEQ_NR_BASIC_LEN  (1088)
#define AC_SEQ_LTE_BASIC_LEN (544)
#define AC_LTE_SEQ_WITH_RF_DELAY (1584)

#define GP_DW_PTS_TS_NR (4384)

#define VSWR_FWD_MODE              1             /*VSWR FWD模式*/

#define RTIOC_TYPE_PSYNC        RTIO_CLASS_PSYNC
#define RTTST_RTIOC_MSG_OPT_NOTIFY    _IOW(RTIOC_TYPE_PSYNC, 0x00, T_NOTIFY_MSG_DATA)

#define UDP_PACK_NUM (UINT32)4


#ifndef RETURN_RESULT_CHECK_AC
#define RETURN_RESULT_CHECK_AC(uiRet)                                                            \
    {                                                                                            \
        if (BSP_OK != (uiRet))                                                                   \
        {                                                                                        \
            dbgInfo("[%s], line: %u, AC Result Check 0x%X \n", __FUNCTION__, __LINE__, (uiRet)); \
            return uiRet;                                                                        \
        }                                                                                        \
    }
#endif

#ifndef RESULT_CHECK_CONTINUE_AC
#define RESULT_CHECK_CONTINUE_AC(uiRet)                                                              \
    {                                                                                                \
        if (BSP_OK != (uiRet))                                                                       \
        {                                                                                            \
            dbgInfo("[%s], line: %u, AC Result Check Continue uiRet'0x%X\n", __FUNCTION__, __LINE__, (uiRet)); \
            continue;                                                                                \
        }                                                                                            \
    }
#endif

#ifndef UMTS_DLY_VALID_CHECK
#define UMTS_DLY_VALID_CHECK(uiWgt)                                                                        \
    {                                                                                                \
        if(0x2d2d == (uiWgt))                                                                        \
        {                                                                                            \
            dbgInfo("[%s], line: %u, AC UMTS Wgt Check, Wgt not valid\n", __FUNCTION__, __LINE__);   \
            continue;                                                                                \
        }                                                                                            \
    }
#endif

#ifndef UMTS_PHA_VALID_CHECK
#define UMTS_PHA_VALID_CHECK(iRealCoef, iImagCoef)                                                             \
    {                                                                                                          \
        if(((0x2d2d == (iRealCoef)) && (0x2d2d == (iImagCoef))) || ((0 == (iRealCoef)) && (0 == (iImagCoef)))) \
        {                                                                                                      \
            dbgInfo("[%s], line: %u, AC UMTS Wgt Check, Wgt not valid, iRealCoef:0x%08x, iImagCoef:0x%08x\n",  \
                    __FUNCTION__, __LINE__, iRealCoef, iImagCoef);                                             \
            continue;                                                                                          \
        }                                                                                                      \
    }
#endif

//Jac新增
#define JAC_FR_DEBUG_CNT_MAX  10

enum JAC_SUPER_FR_RESULT
{
    JAC_SUPER_FR_SUC = 0,
    JAC_SUPER_FR_ERR
};

enum JAC_HANDLE_TYPE
{
    JAC_SEND_DATA = 0,
    JAC_CATCH_DATA,
    JAC_SEND_CATCH_DATA
};

enum JAC_EN_FLAG
{
    JAC_DISABLE = 0,
    JAC_ENABLE
};

enum AC_ALG_TIME_SW
{
    AC_ALG_TIME_OFF = 0,
    AC_ALG_TIME_ON,
};

#define AC_IC_ANT_NUM  8
#define AC_PRACH_MAX_NUM 8
#define AC_WGT_DDR_OFFSET 273

/*************************************************************/
typedef struct tag_T_AC_WGT_INFO
{
    UINT32 radioMode;
    UINT32 bandWidth;
    UINT32 rbNum;
}T_AcWgtInfo;

typedef struct T_socks {
    INT32  fd;
    struct sockaddr_ll addr;
}t_sock;

struct ac_info
{
    INT32 sendPackets_ok;
    INT32 sendPackets_err;
};

typedef struct tag_T_AC_LEN_TS
{
    UINT32 radio;
    UINT32 bandWidth;
    UINT32 sample;
    UINT32 acLen;  //acLen = acSeqLen + 前后CP
}T_AcLenInfo;

//所有制式下参数
typedef struct tag_T_AC_ALL_PARA
{
    UINT32 radio;
    UINT32 bandWidth;
    UINT32 sample;  
    UINT32 acSeqLen;
    UINT32 acDataOffset;
    UINT32 acCpLen;
}T_AcAllParaInfo;

//目前制式下参数
typedef struct tag_T_AC_PARA
{
    UINT32 sample;  
    UINT32 acSeqLen;
    UINT32 acDataOffset;
    UINT32 acCpLen;
}T_AcParaInfo;

typedef struct tag_T_AC_CARR_INFO
{
    UINT32 acType;
    UINT32 carrNo;
    UINT32 radioMode;
    UINT32 bandWidth;
}T_AcCarrInfo;

typedef struct tag_T_AC_RETRY_INFO
{
    UINT32 retry;
    UINT32 retryTime;
    UINT32 round;
    UINT32 roundTime;
}T_AcRetryInfo;

#pragma pack(1) /*按照单字节对齐*/
typedef struct t_acpackHeadType
{
    UINT8 macHead[14];
    UINT8 length[2];      /*包长:从小区号到ac数据结尾*/
    UINT8 cell;           /*小区号*/
    UINT8 iteraTimes;
    UINT8 groupNum;       /*组号*/
    UINT8 antNo[2];       /*天线号*/
    UINT8 sid;            /*分片包序号*/
    UINT8 reserve;
}acPackHead;
#pragma pack()
typedef struct tag_T_JAC_SUERP_FR_DEBUG
{
    UINT32 uiCfgFr;
    UINT32 uiRealFr;
    LONG timeRet;
}T_JacSuperFrInfo;

// typedef struct tagAcSeqComplexData
// {
//     UINT16 real;//从IC寄存器中读取的，已经是带符号型
//     UINT16 imag;//
// }AcSeqComplexData;
// typedef struct tagT_DpdMsgSendAcData
// {
//     UINT16 uwDataLen;     //从小区索引到ACdata结尾的字节数
//     UINT8  ucCeLLId;      //小区索引，0：小区0,1：小区1
//     UINT8  ucAcType;      //AC数据类型，0：下行，1：上行
//     UINT8  ucIterationNo; //迭代次数
//     UINT8  ucGroupNo;     //组号，下行：0-8，上行固定为0 下行
//     UINT16 uwAntNo;       //天线号,0表示0天线，上行有用，下行没用
//     UINT8  ucDpdIcId;     //DPDIC_ID
//     UINT8  uacReserve[3]; //保留
//     AcSeqComplexData ComplexData[1024];
//     INT32  iScale;
//     INT32  iCrc;
// }T_DpdMsgSendAcData;
// typedef struct tagT_DpdMsgSendAcData_NEW
// {
//     T_DpdMsgSendAcData stDa[4];
// }T_DpdMsgSendAcData_NEW_IC4;
#pragma pack(1)
typedef struct notify_to_kernel
{
    UINT32 private[1];
}T_NOTIFY_MSG_DATA;
///////////////////////tmp/////////////////////////////
#pragma pack() /*取消指定对齐，恢复缺省对齐*/

UINT32 showUlAcAllProgressCnt(VOID);
UINT32 showUlAcVgaData(UINT32 carrNo, UINT32 radioMode);
UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag);
VOID testDlAcSeqIc(VOID);
VOID testUlAcSeqIc(VOID);
UINT32 bspAcPsyncInit(UINT32 radioMode);
UINT32 BspSetRxAcSwitch(UINT32 chan,UINT32 sw);
UINT32 BspSetTxAcSwitch(UINT32 chan, UINT32 sw);
UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag);
T_AcCarrCfgNxp* GetAcCarrCfg(VOID);
UINT32 BspGetAcFrToDlEnd(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 bw, UINT32 pasteCarrFlag);
UINT32 BspGetAcFrontOrEndZeroDelay(UINT32 acType, UINT32 radio, UINT32 carrNo,UINT32 gpNum,UINT32 bw,UINT32 pasteCarrFlag, UINT32 frontOrEnd);
UINT8* BspGetAcMemBaseAddr(VOID);
UINT32 BspSetBoardAcInfo(VOID);
UINT32 CheckAcCarrNo(UINT32 carrNo,UINT32 radioMode);
UINT32 BspJudgeAcType(UINT32 acType);
UINT32 BspInitAllSaveWgt(void);
UINT32 SetAacWgtIc(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 bitAntMap, UINT32 *data, UINT32 length);
//Jac新增
UINT32 BspGetAcWgtRbNum(UINT32 radioMode,UINT32 bandWidth,UINT32 pasteCarrFlag);
UINT32 GetJacMode(VOID);
UINT32 GetJacType(VOID);
UINT8 GetJacBitMap(VOID);
#ifdef __cplusplus
}
#endif
#endif 


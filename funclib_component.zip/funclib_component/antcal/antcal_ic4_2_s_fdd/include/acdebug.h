#ifndef FUNCLIB_ACDEBUG_H_INCLUDED
#define FUNCLIB_ACDEBUG_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"


/**************************************************************************
 *                             宏定义                                             *
 **************************************************************************/
#define WAITR8TIMEMeasCNT           3
#define WAITR8TIMESPILLCNT          6
#define MAX_AcSyncTime_NUM          10

#define AC_FUNC_LOG_MAX_STRING ((UINT32)100) //绝对路径最大字符数
#define AC_FUNC_LOG_FILE_MAX 10
#define AC_FUNC_LOG_MAX_SIZE ((UINT32)1048576) //1M = 1024 * 1024 * 1

enum
{
    AC_FUNC_LOG_HIGH = 0,
    AC_FUNC_LOG_MID,
    AC_FUNC_LOG_LOW
};

#define ZTE_SECURITY_FUNC_CHECK(iRet)                                                             \
    {                                                                                             \
        if (BSP_FAIL == (INT32)(iRet))                                                            \
        {                                                                                         \
            dbgErr("[%s], line: %u, zte_s func iRet'%d Error \n", __FUNCTION__, __LINE__, (iRet));\
            return (iRet);                                                                        \
        }                                                                                         \
    }

#define AC_DEBUG_RESULT_CHECK(uiRet)                                                       \
    {                                                                                      \
        if(BSP_OK != (uiRet))                                                              \
        {                                                                                  \
            dbgInfo("[%s], line: %u, result error %d \n", __FUNCTION__, __LINE__, (uiRet));\
            return;                                                                        \
        }                                                                                  \
    }

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/
typedef struct t_RecordAcSyncTime
{	
	UINT32 SyncTimeIndex[MAX_AcSyncTime_NUM];
	UINT32 SyncTime[MAX_AcSyncTime_NUM];
}T_RecordAcSyncTime;

typedef struct t_RecordAcDoInfo
{
	UINT32 AcDataInitCnt;
	UINT32 WriteAcMsgCnt;
	UINT32 SetAcSeqIcCnt;         
	UINT32 GetAcSyncTimeCnt;      
	UINT32 SetAcParaIcCnt;              
	UINT32 GetAcCatchDataStaCnt;  
	UINT32 SendHaulBackAcSeqIcCnt;
	UINT32 DlWaitR8TimeCnt;
	UINT32 DlWaitR8TimeSpillCnt;
	UINT32 UlWaitR8TimeCnt;
	UINT32 UlWaitR8TimeSpillCnt;
	UINT32 SetAcWgtIcCnt;
	UINT32 ChkAcSeqIcCnt;
	UINT32 SetAcSyncTimeCnt;
	UINT32 CalAcSeqIcCnt;
	UINT32 GetAcSeqIcCnt;
	UINT32 CalAcWgtIcCnt;
	UINT32 GetAcWgtIcCnt;
	UINT32 ChkAcWgtIcCnt;
	T_RecordAcSyncTime SetAcSyncTimeSta;
}T_RecordAcDoInfo; 

typedef struct tag_Carrcfg
{   
    UINT32 carrcfgInfo[16][1][4];
}T_AcCarrcfg;



/**************************************************************************
 *                            函数声明                                   *
 **************************************************************************/
UINT32 getGenInt4CallBackCnt(VOID);
UINT32 getRetryDmaCnt(UINT32 acType);
UINT32 getR8Dog(VOID);

UINT32 checkWaitR8SmpOverTime(UINT32 acType, UINT32 waitR8TimeCnt);
VOID recordErsUpdateTime(UINT32 acType, UINT32 acFlag);
VOID recordWaitR8TimeCnt(UINT32 acType, UINT32 waitR8TimeCnt);
VOID recordToDspPackets(UINT32 acType, UINT32 retVal);
VOID RecordSetAcSeqIcInfo(UINT32 carr,UINT32 pasteCarrFlag,UINT32 deviate,UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode,UINT32 acType);
VOID RecordSetAcParaIcInfo(UINT32 acType,UINT32 refChn,UINT32 acChnChgFlag);
VOID getAcInfo(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 uiBandNo);

VOID recordAcDataInitCnt(VOID);
UINT32 JudgeWaitR8TimeCnt(UINT32 acType,UINT32 waitR8TimeCnt);
VOID recordSendHaulBackAcCnt(VOID);
VOID recordSetAcWgtIcCnt(VOID);
VOID recordWriteAcMsgCnt(VOID);
VOID recordGetAcSyncTimeCnt(VOID);
VOID RecordSetAcSyncTimeCnt(UINT32 syncTime);
VOID recordGetAcCatchDataStaCnt(VOID);
VOID recordSetAcParaIcCnt(UINT32 acType);
UINT32 SetRecordAcDoInfoInit(VOID);

VOID recordAcTickInfo(UINT32 type,UINT32 funIdx,UINT32 exceptionExit);
VOID recordGetAcWgtIcCnt(VOID);
VOID recordChkAcWgtIcCnt(VOID);
VOID recordCalAcWgtIcCnt(VOID);
VOID recordGetAcSeqIcCnt(VOID);
VOID recordChkAcSeqIcCnt(VOID);
VOID RecordAcTransFrameNo(UINT32 acType, UINT32 frameNo);
VOID RecordR8AcSeqStartFrameNo(UINT32 acType, UINT32 bitMap, UINT32 realNo);

INT32 AcFuncLog(UINT32 logLevel, const CHAR *format, ...);
UINT32 AcFuncPasta(VOID);
VOID AcFuncDbfs(VOID);
VOID AcFuncAttshow(VOID);
UINT32 AcFuncDlpostPaptAlm(VOID);
VOID AcFuncRssi(UINT32 uiRadioMode, UINT32 uiCarrNo);
UINT32 AcFuncCarrSta(VOID);

#ifdef __cplusplus
}
#endif
#endif /*endif FUNCLIB_ACDEBUG_H_INCLUDED*/

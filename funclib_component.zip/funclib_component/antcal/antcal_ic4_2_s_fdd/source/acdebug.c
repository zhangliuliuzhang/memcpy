/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : acdebug.c
* 文件标识 : {[N/A]}
* 内容摘要 : 该文件主要是AC维测信息
* 注意事项 : 无
* 作    者 :  
* 创建日期 : 2021-01-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 
* 修改日戳: 2021-01-04
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/

#include "acdebug.h"
#include "antcalcommon.h"
#include "freqcfgcommon.h"
#include "vxadp.h"
#include "powerctrl_ic4_2.h"
#include "devdrv_att.h"
#include "vxadp.h"
#include "antcal_ic4_2_oneic.h"
#include "chnmap_a.h"
#include "powerctrl_ic4_2_dbg.h"
#include "powerctrl_ic4_2.h"
#include "pa_ic4_2_ctrl.h"
#include "dl_post.h"
#include "funccommon_carrmap.h"
#include "acdrv_ic4_2_s_fdd.h"
#include "dif_router.h"
#include "cfg_gain_api.h"

/**************************************************************************
 *                             宏定义                                             *
 **************************************************************************/
#define MAX_AC_S_TICK_NUM  24

#define DBG_WRAP(a,b) if ((a) % b == 0)  { dbgInfo("\n"); }
#define CHECK_DATA_NONZERO(a) if (a == 0){ continue; }
#define CHECK_AC_TYPE(a,b) if(a >= b) {return BSP_ERROR; }

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/






/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
UINT32 g_acSmpDlyFlag = 0;
UINT32 g_acSmpDlyDbg = 0;

UINT32 g_maxCarrNum = 0;

T_BspAcIc4InfoDir g_BspAcInfo[E_AC_TYPE_NUM] = {0,};
T_RecordAcDoInfo tRecordAcDoInfo = {0,};

UINT32 g_acSTick[MAX_AC_S_TICK_NUM][5] = {{0,},};
UINT32 g_acSTickIndex = 0;

static UINT32 g_AcFuncLogFileNum = 0;
static CHAR cAcFuncLogPrefix[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogS_";
static CHAR cAcFuncLogFileDir[AC_FUNC_LOG_MAX_STRING] = "/tmplog/dsp_log/acfunclogS.txt";
CHAR * const cAcFuncPathList[2] = {"/bin/rm", "/bin/mv"};
rsize_t rAcFuncPathListSize = 2;

UINT32 g_acFuncLogLevel = AC_FUNC_LOG_HIGH;
/**************************************************************************
 *                         外部函数声明                                   *
 **************************************************************************/
extern VOID BspGetDbfs(T_TxPow *pDbfs, UINT32 num);
extern VOID BspGetAtt(T_TxRxatt *pAtt,UINT32 num);
/**************************************************************************
 *                         函数实现                                   *
 **************************************************************************/
VOID showAcTickInfo(VOID);
UINT32 BspHandleAcLogRstSuc();

UINT32 IcHalApiGetTxCarrCfg(UINT32 uiDifChan, T_AcCarrcfg *recordcarrcfg)
{
    T_DifChanTxCarrInfo *pDifCarr = NULL;
    UINT32 uiloopIdx = 0;
    UINT32 uiMaxCarrNum = 0;
    UINT32 uiRealCarrNum = 0;

    if(IC_CHAN_MAX_NUM <= uiDifChan)
    {
        return BSP_OK;
    }

    pDifCarr = &g_atTxCarrInfo[uiDifChan];
    uiMaxCarrNum = BSP_DIF_CARR_MAX_NUM; 
    for(uiloopIdx=0; uiloopIdx < uiMaxCarrNum; uiloopIdx++)
    {
        if(pDifCarr->atCarrInfo[uiloopIdx].tSingCarrInfo.uiCarrRadio == 0)
        {
            continue;
        }
        recordcarrcfg->carrcfgInfo[uiRealCarrNum][0][0] = pDifCarr->atCarrInfo[uiloopIdx].tSingCarrInfo.uiCarrRadio;
        recordcarrcfg->carrcfgInfo[uiRealCarrNum][0][1] = pDifCarr->atCarrInfo[uiloopIdx].tSingCarrInfo.uiCarrId;
        recordcarrcfg->carrcfgInfo[uiRealCarrNum][0][2] = pDifCarr->atCarrInfo[uiloopIdx].tSingCarrInfo.uiCarrFreq;
        recordcarrcfg->carrcfgInfo[uiRealCarrNum][0][3] = pDifCarr->atCarrInfo[uiloopIdx].tSingCarrInfo.uiCarrBw;
        uiRealCarrNum++;
    }

    return uiRealCarrNum;
}

UINT32 BspHalAdaptGetTxCarrCfg(UINT32 difChan, T_AcCarrcfg *recordcarrcfg)
{
    return IcHalApiGetTxCarrCfg(difChan,recordcarrcfg);
}


UINT32 BspGetCarrCfg(UINT32 bspChan, T_AcCarrcfg *recordcarrcfg)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;   
    UINT32 retVal = BSP_OK;

    if(bspChan >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);    
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
  
    return BspHalAdaptGetTxCarrCfg(difChan, recordcarrcfg);
}

VOID RecordAcTransFrameNo(UINT32 acType, UINT32 frameNo)
{
    if (acType < E_AC_TYPE_STOP)
    {
        g_BspAcInfo[acType].synFrameNo = frameNo;
    }
}

VOID RecordR8AcSeqStartFrameNo(UINT32 acType, UINT32 bitMap, UINT32 realNo)
{   
    if (acType < E_AC_TYPE_STOP)
    {
        g_BspAcInfo[acType].BitMap = bitMap;
        g_BspAcInfo[acType].LocalFrameNo = realNo;  
    } 
}

UINT32 isAcCarrNoExist(UINT32 carrNo,UINT32* pRadioMode)
{
    UINT32 loopSel = 0;
    UINT32 maxCarrNum = 0;
    T_AcCarrcfg recordcarrcfg = {0};
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(pRadioMode);
    maxCarrNum = BspGetCarrCfg(difChan,&recordcarrcfg);
    maxCarrNum = min(BSP_MAX_BANK_NUM_ONEBLOCK, maxCarrNum);
    dbgInfoEx("[%s] carrNo'%d, difChan'%d\n",__FUNCTION__,carrNo,difChan);
    for (loopSel = 0;loopSel < maxCarrNum;loopSel++)
    {
        if(carrNo == recordcarrcfg.carrcfgInfo[loopSel][0][1])
        {
            *pRadioMode = recordcarrcfg.carrcfgInfo[loopSel][0][0];
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

VOID BspClearAcAddInfo(VOID)
{   
    UINT32 acDlNum = g_BspAcInfo[0].acNum;
    UINT32 acUlNum = g_BspAcInfo[1].acNum;
    
    memset((VOID*)&(g_BspAcInfo[0]),0,sizeof(T_BspAcIc4InfoDir)*2);
    g_BspAcInfo[0].acNum = acDlNum;
    g_BspAcInfo[1].acNum = acUlNum;   
}

UINT32 checkWaitR8SmpOverTime(UINT32 acType, UINT32 waitR8TimeCnt)
{
    if(WAITR8TIMEMeasCNT <= waitR8TimeCnt)
    {
        g_BspAcInfo[acType].waitR8OvertimeFlag = 1;
        dbgErr("[%s]R8 sample overtime!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    else
    {
        g_BspAcInfo[acType].waitR8OvertimeFlag = 0;
        return BSP_OK;
    }

    return BSP_OK;
}

VOID recordErsUpdateTime(UINT32 acType, UINT32 acFlag)
{}

VOID recordWaitR8TimeCnt(UINT32 acType, UINT32 waitR8TimeCnt)
{
    g_BspAcInfo[acType].waitR8Time = waitR8TimeCnt;
}

VOID recordToDspPackets(UINT32 acType, UINT32 retVal)
{
    (retVal == BSP_OK)?(g_BspAcInfo[acType].toDspPackets++):(g_BspAcInfo[acType].toDspPacketsErr++);
    g_BspAcInfo[acType].toDspPacketsAll++;
}

VOID RecordSetAcSeqIcInfo(UINT32 carr,UINT32 pasteCarrFlag,UINT32 deviate,UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode,UINT32 acType)
{    
    UINT32 uiAcType = 0;

    uiAcType =  BspJudgeAcType(acType);
    tRecordAcDoInfo.SetAcSeqIcCnt++;
    BspClearAcAddInfo();
    dbgInfoEx("[%s], app acType:%d, uiAcType:%d \n", __FUNCTION__, acType, uiAcType);

    if (acType < E_AC_TYPE_NUM)
    {
        (E_AC_TYPE_DL == uiAcType)?(g_BspAcInfo[0].acNum++):(g_BspAcInfo[1].acNum++);
        //g_BspAcInfo[acType].Fisr8dog = getR8Dog();
        //g_BspAcInfo[acType].genInt4Cnt1st = getGenInt4CallBackCnt();
        g_BspAcInfo[uiAcType].carrNo = carr;
        g_BspAcInfo[uiAcType].pasteCarrFlag = pasteCarrFlag;
        g_BspAcInfo[uiAcType].deviate = deviate;
        g_BspAcInfo[uiAcType].bandWidth = bandWidth;
        g_BspAcInfo[uiAcType].sampleRate = sampleRate;
        g_BspAcInfo[uiAcType].radioMode = radioMode;
        g_BspAcInfo[uiAcType].acType = acType;
    }
}

VOID RecordSetAcParaIcInfo(UINT32 acType,UINT32 refChn,UINT32 acChnChgFlag)
{
    if (acType < E_AC_TYPE_STOP)
    {
        g_BspAcInfo[acType].refChn = refChn;
        g_BspAcInfo[acType].acChnChgFlag = acChnChgFlag;  
    }  
}

VOID getpow(UINT32 acType)
{   
    UINT32 maxChn = min(8, BspGetTxChannel());
    UINT32 bspChn = 0;
    T_TxPow pow[8];
   
    if (acType < E_AC_TYPE_STOP)
    {
        BspGetDbfs(&(pow[0]),8); //获取8个通道的数据
        //存储到本地数据
        for (bspChn = 0; bspChn < maxChn; bspChn++)
        {
            g_BspAcInfo[acType].pow[bspChn][0] = pow[bspChn].tFwdPow.ifTssiPow;
            g_BspAcInfo[acType].pow[bspChn][1] = pow[bspChn].tFwdPow.fbPow;
            g_BspAcInfo[acType].pow[bspChn][2] = pow[bspChn].tRevPow.ifTssiPow;
            g_BspAcInfo[acType].pow[bspChn][3] = pow[bspChn].tRevPow.fbPow;
            g_BspAcInfo[acType].pow[bspChn][4] = (INT32)pow[bspChn].isPowValid;
        }  
    }  
}

VOID getatt(UINT32 acType)
{   
    UINT32 maxChn  = min(8, BspGetTxChannel());
    UINT32 bspChn  = 0;
    INT32  loopSel = 0;
    T_TxRxatt attinfo = {0};
    
    if (acType < E_AC_TYPE_STOP)
    {
        BspGetAtt(&attinfo,8);  //获取8个通道的数据
        for (loopSel = 0; loopSel < 5; loopSel++)
        {
            for (bspChn = 0; bspChn < maxChn; bspChn++)
            {
                g_BspAcInfo[acType].att[loopSel][bspChn] = attinfo.att[loopSel][bspChn];
            }
        } 
    }  
}

VOID getDatacloseInfo(UINT32 acType)
{}

VOID geticreg(UINT32 acType)
{}

VOID getcarrcfg(UINT32 acType,UINT32 difChan)
{
    UINT32 loopSel = 0;
    UINT32 maxCarrNum = 0;
    UINT32 uiBspChn = 0;
    UINT32 uiRet = 0;
    T_AcCarrcfg recordcarrcfg = {0,};
    
    if (acType < E_AC_TYPE_STOP)
    {
        uiRet = BspGetBspChanByAntAndBandInfo(1, BspGetBandNo(), TX, &uiBspChn);
        AC_DEBUG_RESULT_CHECK(uiRet);
        maxCarrNum = BspGetCarrCfg(uiBspChn, &recordcarrcfg);
        maxCarrNum = min(BSP_MAX_BANK_NUM_ONEBLOCK, maxCarrNum);
        g_maxCarrNum = maxCarrNum;
        
        for (loopSel = 0;loopSel < maxCarrNum;loopSel++)
        {
            g_BspAcInfo[acType].carrcfg[loopSel][0][0] = recordcarrcfg.carrcfgInfo[loopSel][0][0];
            g_BspAcInfo[acType].carrcfg[loopSel][0][1] = recordcarrcfg.carrcfgInfo[loopSel][0][1];
            g_BspAcInfo[acType].carrcfg[loopSel][0][2] = recordcarrcfg.carrcfgInfo[loopSel][0][2];
            g_BspAcInfo[acType].carrcfg[loopSel][0][3] = recordcarrcfg.carrcfgInfo[loopSel][0][3];
        } 
    }   
}

VOID getrssi(UINT32 acType)
{   
    UINT32 chanNum = 0;
    UINT32 carrNum = 0;
    UINT32 chnLoop = 0;
    UINT32 carr    = 0;
    UINT32 maxCarrNum = 0;
    UINT32 maxChanNum = 0;
    UINT32 radioMode = BSP_RADIO_STANDARD_5G;
    	
    T_RssiInfo recordRssi = {0};
    	
    BspGetRssiInfo(0,&recordRssi,&carrNum,&chanNum);
    dbgInfoEx("carrNum:%d chanNum:%d\n",carrNum,chanNum);
	
    maxCarrNum = min(8,carrNum);
    maxChanNum = min(8,chanNum);
    	
    for (carr = 0; carr < maxCarrNum; carr++)
    {
        if(BSP_OK != isAcCarrNoExist(carr,&radioMode))
        {
            continue;
        }
        for (chnLoop = 0; chnLoop < maxChanNum; chnLoop++)
        {
            g_BspAcInfo[acType].NrRssiDbfs[carr][chnLoop] = recordRssi.NrRssiDbfs[carr][chnLoop];
            g_BspAcInfo[acType].NrRssiDbm[carr][chnLoop] = recordRssi.NrRssiDbm[carr][chnLoop];
            g_BspAcInfo[acType].LteRssiDbfs[carr][chnLoop] = recordRssi.LteRssiDbfs[carr][chnLoop];
            g_BspAcInfo[acType].LteRssiDbm[carr][chnLoop] = recordRssi.LteRssiDbm[carr][chnLoop];
        }
    }   
}

VOID getfreqInfo(UINT32 acType)
{    
    UINT32 centerFreq = 0;
    UINT32 rfpllFreq = 0;
    UINT32 uDir = 0;

    uDir = (E_AC_TYPE_UL == acType)? (RX):(TX);	
    centerFreq = BspGetCenterFreq(uDir,0);
    rfpllFreq = BspGetLoFreq(uDir,0);
    g_BspAcInfo[acType].centerFreq = centerFreq;
    g_BspAcInfo[acType].rfpllFreq = rfpllFreq;   
}

VOID getNrLteTddInfo(UINT32 acType)
{}

VOID getR8GenInt4Info(UINT32 acType)
{}

VOID getdelayInfo(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{}

UINT32 getcarrstatus(UINT32 acType)
{ 
    return BSP_OK;
}

VOID getDifChan(UINT32 uiBandNo, UINT32 *pDifChan)
{
    UINT32 uiRet       = 0;
    UINT32 uiAntNo     = 1;
    UINT32 uiBspChn    = 0;
    UINT32 uiDifChipId = 0;

    uiRet = BspGetBspChanByAntAndBandInfo(uiAntNo, uiBandNo, TX, &uiBspChn);
    uiRet |= BspGetDifInfoByBspChn(uiBspChn, TX, &uiDifChipId, pDifChan);
    dbgInfoEx("[%s] uiDifChan:%d uiRet:%u\n", __FUNCTION__, *pDifChan, uiRet);
}

VOID getAcInfo(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 uiBandNo)
{
    UINT32 uiDifChan   = 0;
    getDifChan(uiBandNo, &uiDifChan);
    getpow(acType);
    getatt(acType);
    getcarrcfg(acType,uiDifChan); //各通道一致，只获取每个频段一个通道的载波信息即可
    getfreqInfo(acType);
    getrssi(acType);    
}

//显示g_BspAcInfo内容,0表示下行，1表示上行
UINT32 BspShowAcPowerInfo(UINT32 acType)
{   
    UINT32 maxChn = min(8, BspGetTxChannel());
    UINT32 chan = 0;
    UINT32 loopSel = 0;

    CHECK_AC_TYPE(acType,E_AC_TYPE_NUM);	
    
    dbgInfo("\n ******1.功率信息tssi/fwd/rev******\n");
    for (chan = 0;chan < maxChn;chan++)
    {
        dbgInfo("Chan %d:FwdTssi=%d|FbFwd=%d|RevTssi=%d|FbRev=%d|isPowValid=%d\n",chan,g_BspAcInfo[acType].pow[chan][0],\
            g_BspAcInfo[acType].pow[chan][1],g_BspAcInfo[acType].pow[chan][2],g_BspAcInfo[acType].pow[chan][3],g_BspAcInfo[acType].pow[chan][4]);
    }
    dbgInfo("\n ******2.16通道attshow,包括txAtt、prxAtt、prxAttDpd、rxAtt、rxVga******\n");
    for (loopSel = 0;loopSel<5;loopSel++)
    {
        for (chan = 0;chan< maxChn;chan++)
        {
            dbgInfo("[%d]:%-10d",chan,g_BspAcInfo[acType].att[loopSel][chan]);
            if ((chan+1) % maxChn == 0)
            {
                dbgInfo("\n");
            }
        }
    }

    dbgInfo("\n ******3.AC高层帧号、本地帧号、UDP发包数和中心、本振频点******\n");
    dbgInfo("synFrameNo:%d, LocalFrameNo:%d\n",g_BspAcInfo[acType].synFrameNo,g_BspAcInfo[acType].LocalFrameNo);
    dbgInfo("toDspPackets:%d, toDspPacketsErr:%d, toDspPacketsAll:%d\n",g_BspAcInfo[acType].toDspPackets,g_BspAcInfo[acType].toDspPacketsErr,g_BspAcInfo[acType].toDspPacketsAll);
    dbgInfo("本振频点centerFreq:%d, 射频频点rfpllFreq:%d\n",g_BspAcInfo[acType].centerFreq,g_BspAcInfo[acType].rfpllFreq);
    g_BspAcInfo[acType].SetAcSeqCnt = tRecordAcDoInfo.SetAcSeqIcCnt;
    g_BspAcInfo[acType].SetAcParaCnt = tRecordAcDoInfo.SetAcParaIcCnt;
    g_BspAcInfo[acType].SendHaulBackAcSeqCnt = tRecordAcDoInfo.SendHaulBackAcSeqIcCnt;
    g_BspAcInfo[acType].SetAcWgtCnt = tRecordAcDoInfo.SetAcWgtIcCnt;
    dbgInfo("SetAcSeqCnt:%d, SetAcParaCnt:%d, SendHaulBackAcSeqCnt:%d, SetAcWgtCnt:%d\n",g_BspAcInfo[acType].SetAcSeqCnt,\
        g_BspAcInfo[acType].SetAcParaCnt,g_BspAcInfo[acType].SendHaulBackAcSeqCnt,g_BspAcInfo[acType].SetAcWgtCnt);
	
    dbgInfo("\n ******4.重要监控寄存器******\n");
    //待补充
    dbgInfo("\n***帧头偏移量***\n");
    dbgInfo("[Opt] NR:%d, LTE:%d\n",g_BspAcInfo[acType].optFrAdjDly[0],g_BspAcInfo[acType].optFrAdjDly[1]);
    dbgInfo("[Dif] NR:%d, LTE:%d\n",g_BspAcInfo[acType].difFrAdjDly[0],g_BspAcInfo[acType].difFrAdjDly[1]);

    dbgInfo("***show Ac tick***\n");
    showAcTickInfo();
	
    return BSP_OK;
}

UINT32 BspShowAcCarrInfo(UINT32 acType)
{
    UINT32 chan = 0;
    UINT32 loopSel = 0;
    UINT32 loop = 0;
    UINT32 maxChn = min(8, BspGetTxChannel());
    
    CHECK_AC_TYPE(acType,E_AC_TYPE_NUM);
    
    dbgInfo("\n ******5.数据关断delta值******\n");
    dbgInfo("  chan  outbandCnt longAvgCnt shortAvgcnt singPowCnt dpdAvgCnt\n");
    for (chan = 0;chan < maxChn;chan++)
    {
        dbgInfo("%5d %10d %10d %10d %10d %10d \n",chan,g_BspAcInfo[acType].outbandCnt[chan],g_BspAcInfo[acType].longAvgCnt[chan],\
            g_BspAcInfo[acType].shotAvgCnt[chan],g_BspAcInfo[acType].singPowCnt[chan],g_BspAcInfo[acType].dpdAvgCnt[chan]);
    }
	
    dbgInfo("\n ******6.AC上下行执行次数统计和记录R8心跳和waitR8TimeCnt******\n");
    dbgInfo("下行执行次数:%d\n",g_BspAcInfo[0].acNum);
    dbgInfo("上行执行次数:%d\n",g_BspAcInfo[1].acNum);
    //g_BspAcInfo[acType].Secr8dog = getR8Dog();
    dbgInfo("第一次记录R8心跳:%d\n",g_BspAcInfo[acType].Fisr8dog);
    dbgInfo("第二次记录R8心跳:%d\n",g_BspAcInfo[acType].Secr8dog);
    dbgInfo("waitR8TimeCnt:%d\n",g_BspAcInfo[acType].waitR8Time);
    dbgInfo("waitR8OvertimeFlag:%d\n",g_BspAcInfo[acType].waitR8OvertimeFlag);
    dbgInfo("第一次记录genInt4中断次数:%d\n",g_BspAcInfo[acType].genInt4Cnt1st);
    dbgInfo("第二次记录genInt4中断次数:%d\n",g_BspAcInfo[acType].genInt4Cnt2nd);
    dbgInfo("r8RetryDmaCnt:%d\n",g_BspAcInfo[acType].r8RetryDmaCnt);
    
    dbgInfo("\n ******7.高层下发的参数信息，载波号、载波制式、ac类型、参考天线号、天线位图等******\n");
    dbgInfo("carrNo:%d, radioMode:%d, acType:%d\n",g_BspAcInfo[acType].carrNo,g_BspAcInfo[acType].radioMode,g_BspAcInfo[acType].acType);
    dbgInfo("BitMap:%d, bandWidth:%d, sampleRate:%d\n",g_BspAcInfo[acType].BitMap,g_BspAcInfo[acType].bandWidth,g_BspAcInfo[acType].sampleRate);
    dbgInfo("deviate:%d, pasteCarrFlag:%d, refChn:%d, acChnChgFlag:%d\n",g_BspAcInfo[acType].deviate,g_BspAcInfo[acType].pasteCarrFlag,g_BspAcInfo[acType].refChn,g_BspAcInfo[acType].acChnChgFlag);
    
    dbgInfo("\n ******8.记录BSP已保存的载波信息******\n");
    dbgInfo("chan  RADIOMOD  CARRID  CARRFREQ  CARRWIDTH\n");
    for (loopSel = 0;loopSel < g_maxCarrNum;loopSel++)
    {
        dbgInfo("%d   %8x     %2d      %8d  %8d\n",0,g_BspAcInfo[acType].carrcfg[loopSel][0][0],\
            g_BspAcInfo[acType].carrcfg[loopSel][0][1],g_BspAcInfo[acType].carrcfg[loopSel][0][2],g_BspAcInfo[acType].carrcfg[loopSel][0][3]);
    }

    dbgInfo("\n ******9.小信号状态信息0x50******\n");
    for (loop = 0;loop < 8;loop++)
    {
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].paTxPowMode[loop]);
        DBG_WRAP((loop+1),4);
    }
    dbgInfo("\n ******小信号开关0x42******\n");
    for (loop = 0;loop < 8;loop++)
    {
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].PaPowTxSwitch[loop]);
        DBG_WRAP((loop+1),8);
    }

    return BSP_OK;
}

UINT32 BspShowAcRssiInfo(UINT32 acType)
{
    UINT32 chan = 0;
    UINT32 carr = 0;
    
    CHECK_AC_TYPE(acType,E_AC_TYPE_NUM);
	
    dbgInfo("\n ******10.rssi信息--5G NR******\n");
    dbgInfo("***5G NR dbfs***\n");
    for (carr = 0;carr < 8;carr++)
    {
        CHECK_DATA_NONZERO(g_BspAcInfo[acType].NrRssiDbfs[carr][0]);
        for (chan = 0;chan < 8;chan++)
        {
            dbgInfo("C%dA%d:%d  ",carr,chan,g_BspAcInfo[acType].NrRssiDbfs[carr][chan]);
            DBG_WRAP((chan+1),8);
        }
    }
    dbgInfo("***5G NR dbm***\n");
    for (carr = 0;carr < 8;carr++)
    {
        CHECK_DATA_NONZERO(g_BspAcInfo[acType].NrRssiDbm[carr][0]);
        
        for (chan = 0;chan < 8;chan++)
        {
            dbgInfo("C%dA%d:%d  ",carr,chan,g_BspAcInfo[acType].NrRssiDbm[carr][chan]);
            DBG_WRAP((chan+1),8);
        }
    }
	
    dbgInfo(" ******rssi信息--4G LTE******\n");
    dbgInfo("***4G Lte dbfs***\n");
    for (carr = 0;carr < 8;carr++)
    {
        CHECK_DATA_NONZERO(g_BspAcInfo[acType].LteRssiDbfs[carr][0]);
    
        for (chan = 0;chan < 8;chan++)
        {
            dbgInfo("C%dA%d:%d  ",carr,chan,g_BspAcInfo[acType].LteRssiDbfs[carr][chan]);
            DBG_WRAP((chan+1),8);
        }
    }
    dbgInfo("***4G Lte dbm***\n");
    for (carr = 0;carr < 8;carr++)
    {
        CHECK_DATA_NONZERO(g_BspAcInfo[acType].LteRssiDbm[carr][0]);
        
        for (chan = 0;chan < 8;chan++)
        {
            dbgInfo("C%dA%d:%d  ",carr,chan,g_BspAcInfo[acType].LteRssiDbm[carr][chan]);
            DBG_WRAP((chan+1),8);
        }
    }

    return BSP_OK;   
}

UINT32 BspShowAcSlotInfo(UINT32 acType)
{
    UINT32 chan = 0;
    UINT32 loopSel = 0;
    UINT32 loop = 0;
    UINT32 carr = 0;
    UINT32 dlUlNrSwNum = 0;
    UINT32 dlUlLteSwNum = 0;
    UINT32 radioMode = BSP_RADIO_STANDARD_5G;
    
    CHECK_AC_TYPE(acType,E_AC_TYPE_NUM); 

    dlUlNrSwNum = min(2,g_BspAcInfo[acType].dlUlNrSwNum);
    dlUlLteSwNum = min(2,g_BspAcInfo[acType].dlUlLteSwNum);
	
    dbgInfo("\n ******12 5G Nr 帧结构******\n");
    dbgInfo("DL UL Switch Num: %d ,Switch Period: %-2.1f (ms)\n",g_BspAcInfo[acType].dlUlNrSwNum,((float)g_BspAcInfo[acType].dlUlNrSwPeriod) / 1000);
    for (loopSel = 0;loopSel < dlUlNrSwNum;loopSel++)
    {
        dbgInfo("DlSlotNum'%2d SymbolBakwardSlot'%2d\n", g_BspAcInfo[acType].dlNrSlotNum[loopSel], g_BspAcInfo[acType].dlNrSymbolNum[loopSel]);
        dbgInfo("UlSlotNum'%2d SymbolForwardSlot'%2d\n", g_BspAcInfo[acType].ulNrSlotNum[loopSel], g_BspAcInfo[acType].ulNrSymbolNum[loopSel]);
        dbgInfo("GpSlotNum'%2d SymbolSpecialSlot'%2d\n", g_BspAcInfo[acType].gpNrSlotNum[loopSel], g_BspAcInfo[acType].gpNrBackSlot[loopSel]);
    }
    
    dbgInfo("\n ******4G LTE 帧结构 (Dl0+Dl1)= D*14+x, Ul=U*14+y******\n");
    dbgInfo("DL UL Switch Num: %d ,Switch Period: %-2.1f (ms)\n",g_BspAcInfo[acType].dlUlLteSwNum,((float)g_BspAcInfo[acType].dlUlLteSwPeriod) / 1000);
    for (loopSel = 0;loopSel < dlUlLteSwNum;loopSel++)
    {
        dbgInfo("LteSubFrameSymbolSum: Dl0= %d; Dl1= %d; Ul= %d\n",g_BspAcInfo[acType].dlLteSlotNum0[loopSel],\
            g_BspAcInfo[acType].dlLteSlotNum1[loopSel],g_BspAcInfo[acType].ulLteSlotNum[loopSel]);
    }
    
    dbgInfo("\n ******12 中频时延补偿,时延补偿+SRC******\n");
    dbgInfo("BspGetFrGpPhaseOffset4Ac：difRefCarrDelay = %d\n",g_BspAcInfo[acType].difRefCarrDelay);
    dbgInfo("BspGetDl1Dly: dltotaldly = %d\n",g_BspAcInfo[acType].dltotaldly);
    
    dbgInfo("\n ******13 ERS快配信息******\n");
    for (loop = 0;loop < 2;loop++)
    {
        char * msg[2] = {"in","out"};
        dbgInfo("ersUpdateSuccessTime(%s): %10d ersUpdateFailTime(%s):%10d\n", msg[loop], g_BspAcInfo[acType].ersUpdateSuccessTime[loop],\
            msg[loop], g_BspAcInfo[acType].ersUpdateFailTime[loop]);
    }
    
    dbgInfo("\n ******14 载波关断信息******\n");
    dbgInfo("***carrier switch status(0:OFF,1:ON)***\n");
    for (carr = 0;carr < 8;carr++)
    {
        if(BSP_OK != isAcCarrNoExist(carr,&radioMode))
        {
            continue;
        }
        dbgInfo("carr%d TX ",carr);
        for (chan = 0;chan < 8;chan++)
        {
            dbgInfo("[%d]%d%s",chan,g_BspAcInfo[acType].carrStatus[carr][chan],((chan+1)%16)?" ":"\n");
        }
    }
    return BSP_OK;

}

//显示g_BspAcInfo内容,0表示下行，1表示上行
UINT32 BspShowAcExtraInfo(UINT32 acType)
{  
    UINT32 loop = 0;
    
    CHECK_AC_TYPE(acType,E_AC_TYPE_NUM); 
		
    dbgInfo("\n ******18、4.0新增AC寄存器******\n");
    dbgInfo("******rdic 0xcca01aa8|c[bit0]:AC启动上报******\n");
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acSyncRpt[loop]);
    }
    dbgInfo("\n******rdic 0xcca01ab0|4[bit0~15]:AC内插次数上报******\n");
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acInsertTimeRpt[loop]);
    }
    dbgInfo("\n******rdic 0xcb2020b0|4[bit16~31][bit0]:AC采数中断计数、inslot等待异常上报******\n");
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acCbIntCnt[loop]);
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acCbInslotWaitAbl[loop]);
    }
    dbgInfo("\n******rdic 0xcb2020d0|4[bit0~25]:AC帧头到采数使能延时上报******\n");
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acCbFrMeas[loop]);
    }
    dbgInfo("\n******rdic 0xcb2020e8[bit0~1]:AC采数成功中断上报******\n");
    dbgInfo("[%d]:0x%08x  ",0,g_BspAcInfo[acType].acCbDoneInt);
    
    dbgInfo("\n******rdic 0xcb202140|4、0xcb202150|4:AC模块0~1迭代VGA上报******\n");
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acCbVga0Value[loop]);
    }
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acCbVga1Value[loop]);
    }
    dbgInfo("\n******rdic 0xcb202160|4、0xcb202170|4:AC模块2~3迭代VGA上报******\n");
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acCbVga2Value[loop]);
    }
    for (loop = 0;loop < 2;loop++)
    {	
        dbgInfo("[%d]:0x%08x  ",loop,g_BspAcInfo[acType].acCbVga3Value[loop]);
    }
   
    return BSP_OK;
}

UINT32 BspGetAcIc4MeasInfo(UINT32 acType,T_BspAcIc4InfoDir *pAcInfo)
{
    UINT32 uiAcType = 0;

    CHECK_AC_TYPE(acType,E_AC_TYPE_NUM);
    uiAcType =  BspJudgeAcType(acType);
    
    dbgInfoEx("[%s]:app acType:%d, uiAcType:%d \n", __FUNCTION__, acType, uiAcType);

    INPUT_POINTER_CHECK(pAcInfo);
  
    //g_BspAcInfo[acType].Secr8dog = getR8Dog();
    g_BspAcInfo[uiAcType].SetAcSeqCnt = tRecordAcDoInfo.SetAcSeqIcCnt;
    g_BspAcInfo[uiAcType].SetAcParaCnt = tRecordAcDoInfo.SetAcParaIcCnt;
    g_BspAcInfo[uiAcType].SendHaulBackAcSeqCnt = tRecordAcDoInfo.SendHaulBackAcSeqIcCnt;
    g_BspAcInfo[uiAcType].SetAcWgtCnt = tRecordAcDoInfo.SetAcWgtIcCnt;
    
    memcpy_s((void*)pAcInfo,sizeof(T_BspAcIc4InfoDir),(void*)&(g_BspAcInfo[uiAcType]),sizeof(T_BspAcIc4InfoDir));
    
    return BSP_OK;
}

VOID recordAcDataInitCnt(VOID)
{
    tRecordAcDoInfo.AcDataInitCnt++;
}

VOID recordCalAcSeqIcCnt(VOID)
{
    if (tRecordAcDoInfo.CalAcSeqIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.CalAcSeqIcCnt++;
    }
}

VOID recordChkAcSeqIcCnt(VOID)
{
    if (tRecordAcDoInfo.ChkAcSeqIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.ChkAcSeqIcCnt++;
    }
}

VOID recordGetAcSeqIcCnt(VOID)
{
    if (tRecordAcDoInfo.GetAcSeqIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.GetAcSeqIcCnt++;
    }
}

VOID recordCalAcWgtIcCnt(VOID)
{
    if (tRecordAcDoInfo.CalAcWgtIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.CalAcWgtIcCnt++;
    }
}

VOID recordChkAcWgtIcCnt(VOID)
{
    if (tRecordAcDoInfo.ChkAcWgtIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.ChkAcWgtIcCnt++;
    }
}

VOID recordGetAcWgtIcCnt(VOID)
{
    if (tRecordAcDoInfo.GetAcWgtIcCnt < UINT32_MAX)
    {
        tRecordAcDoInfo.GetAcWgtIcCnt++;
    }
}

UINT32 JudgeWaitR8TimeCnt(UINT32 acType,UINT32 waitR8TimeCnt)
{
    if (waitR8TimeCnt >= WAITR8TIMEMeasCNT)
    {
        (E_AC_TYPE_DL == acType)?(tRecordAcDoInfo.DlWaitR8TimeCnt++):(tRecordAcDoInfo.UlWaitR8TimeCnt++);
    }
    if (waitR8TimeCnt == WAITR8TIMESPILLCNT)
    {
        (E_AC_TYPE_DL == acType)?(tRecordAcDoInfo.DlWaitR8TimeSpillCnt++):(tRecordAcDoInfo.UlWaitR8TimeSpillCnt++);
        dbgErr("%s sendRecvAcSeqData not finished.\n",__FUNCTION__);
    }
    return BSP_OK;
}

VOID recordSendHaulBackAcCnt(VOID)
{
    tRecordAcDoInfo.SendHaulBackAcSeqIcCnt++;
}

VOID recordSetAcWgtIcCnt(VOID)
{
    tRecordAcDoInfo.SetAcWgtIcCnt++;
}

VOID recordWriteAcMsgCnt(VOID)
{
    tRecordAcDoInfo.WriteAcMsgCnt++;
}

VOID recordGetAcSyncTimeCnt(VOID)
{
    tRecordAcDoInfo.GetAcSyncTimeCnt++;
}

VOID RecordSetAcSyncTimeCnt(UINT32 syncTime)
{
	UINT32 Cnt = 0;
	tRecordAcDoInfo.SetAcSyncTimeCnt++;
	Cnt = tRecordAcDoInfo.SetAcSyncTimeCnt - 1;
	tRecordAcDoInfo.SetAcSyncTimeSta.SyncTimeIndex[Cnt % MAX_AcSyncTime_NUM] = Cnt;
	tRecordAcDoInfo.SetAcSyncTimeSta.SyncTime[Cnt % MAX_AcSyncTime_NUM] = syncTime;
}

UINT32 ShowRecordAcDoInfo(VOID)
{
    UINT32 loop = 0;
    dbgInfo("AcDataInitCnt:%d\n",tRecordAcDoInfo.AcDataInitCnt);
    dbgInfo("WriteAcMsgCnt:%d\n",tRecordAcDoInfo.WriteAcMsgCnt);
    dbgInfo("SetAcSeqIcCnt:%d\n",tRecordAcDoInfo.SetAcSeqIcCnt);
    dbgInfo("GetAcSyncTimeCnt:%d\n",tRecordAcDoInfo.GetAcSyncTimeCnt);
    dbgInfo("SetAcParaIcCnt:%d\n",tRecordAcDoInfo.SetAcParaIcCnt);
    dbgInfo("GetAcCatchDataStaCnt:%d\n",tRecordAcDoInfo.GetAcCatchDataStaCnt);
    dbgInfo("SendHaulBackAcSeqIcCnt:%d\n",tRecordAcDoInfo.SendHaulBackAcSeqIcCnt);
    dbgInfo("DlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeCnt);
    dbgInfo("DlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeSpillCnt);
    dbgInfo("UlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeCnt);
    dbgInfo("UlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeSpillCnt);
    dbgInfo("SetAcWgtIcCnt:%d\n",tRecordAcDoInfo.SetAcWgtIcCnt);
    for (loop = 0; loop < MAX_AcSyncTime_NUM; loop++)
    {
        dbgInfo("SyncTimeIndex[%d]:%d SyncTime[%d]:%d \n",loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTimeIndex[loop % MAX_AcSyncTime_NUM],loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTime[loop % MAX_AcSyncTime_NUM]);
    }
    return BSP_OK;
}

UINT32 ShowRecordAcDoInfoFor8T(VOID)  //主要针对不区分主从的机型，打印AC接口执行次数统计
{
    UINT32 loop = 0;
    dbgInfo("AcDataInitCnt:%d\n",tRecordAcDoInfo.AcDataInitCnt);
    dbgInfo("WriteAcMsgCnt:%d\n",tRecordAcDoInfo.WriteAcMsgCnt);
    dbgInfo("SetAcSeqIcCnt:%d\n",tRecordAcDoInfo.SetAcSeqIcCnt);
    dbgInfo("GetAcSyncTimeCnt:%d\n",tRecordAcDoInfo.GetAcSyncTimeCnt);
    dbgInfo("SetAcParaIcCnt:%d\n",tRecordAcDoInfo.SetAcParaIcCnt);
    dbgInfo("GetAcCatchDataStaCnt:%d\n",tRecordAcDoInfo.GetAcCatchDataStaCnt);
    dbgInfo("SendHaulBackAcSeqIcCnt:%d\n",tRecordAcDoInfo.SendHaulBackAcSeqIcCnt);
    dbgInfo("DlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeCnt);
    dbgInfo("DlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.DlWaitR8TimeSpillCnt);
    dbgInfo("UlWaitR8TimeCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeCnt);
    dbgInfo("UlWaitR8TimeSpillCnt:%d\n",tRecordAcDoInfo.UlWaitR8TimeSpillCnt);
    dbgInfo("SetAcWgtIcCnt:%d\n",tRecordAcDoInfo.SetAcWgtIcCnt);
    dbgInfo("CalAcSeqIcCnt:%d\n",tRecordAcDoInfo.CalAcSeqIcCnt);
    dbgInfo("GetAcSeqIcCnt:%d\n",tRecordAcDoInfo.GetAcSeqIcCnt);
    dbgInfo("CalAcWgtIcCnt:%d\n",tRecordAcDoInfo.CalAcWgtIcCnt);
    dbgInfo("GetAcWgtIcCnt:%d\n",tRecordAcDoInfo.GetAcWgtIcCnt);
    dbgInfo("ChkAcWgtIcCnt:%d\n",tRecordAcDoInfo.ChkAcWgtIcCnt);
    for (loop = 0; loop < MAX_AcSyncTime_NUM; loop++)
    {
        dbgInfo("SyncTimeIndex[%d]:%d SyncTime[%d]:%d \n",loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTimeIndex[loop % MAX_AcSyncTime_NUM],loop,tRecordAcDoInfo.SetAcSyncTimeSta.SyncTime[loop % MAX_AcSyncTime_NUM]);
    }
    return BSP_OK;
}

VOID recordGetAcCatchDataStaCnt(VOID)
{
    tRecordAcDoInfo.GetAcCatchDataStaCnt++;
}

VOID recordSetAcParaIcCnt(UINT32 acType)
{ 
    if (acType < E_AC_TYPE_STOP)
    {
        if (tRecordAcDoInfo.SetAcParaIcCnt < UINT32_MAX)
        {
            tRecordAcDoInfo.SetAcParaIcCnt++;
        } 
    }   
}

UINT32 SetRecordAcDoInfoInit(VOID)
{
    //清空初始AC计数
    memset((VOID*)&tRecordAcDoInfo,0,sizeof(T_RecordAcDoInfo));
    return BSP_OK;
}

VOID recordAcTickInfo(UINT32 type,UINT32 funIdx,UINT32 exceptionExit)
{
    UINT32 index = g_acSTickIndex % MAX_AC_S_TICK_NUM;
    if(0 == type)//start
    {
        g_acSTick[index][0] = g_acSTickIndex;  
        g_acSTick[index][1] = funIdx;
    }
    else//end
    {
        g_acSTick[index][4] = exceptionExit;        
        g_acSTickIndex++;
    }   
}

VOID showAcTickInfo(VOID)
{
    UINT32 loop = 0;
    dbgInfo("\nfun Idx(0:SetAcSeqIc, 1:SetAcParaIc, 2:SetAcSyncTime, 3:SendHaulBackAcSeqIc)\n");
    for(loop = 0; loop < MAX_AC_S_TICK_NUM; loop++)
    {
        dbgInfo("g_acSTickIndex:%d\n",g_acSTick[loop][0]);
        dbgInfo("fun Idx:%d\n",g_acSTick[loop][1]);
        dbgInfo("exceptionExit:%d\n",g_acSTick[loop][4]);
    } 
}

/* 打印FR_PHA寄存器的值 */
UINT32 BspShowFrPha(VOID)
{
    return BSP_OK;
}

VOID acsmpdlydbg(UINT32 flag, UINT32 val)
{
    g_acSmpDlyFlag = flag;
    g_acSmpDlyDbg = val;
}

UINT32 acsmpcarrset(UINT32 way,UINT32 mode,UINT32 delay)
{
    return BSP_OK;
}

UINT32 acsmpchanset(UINT32 way,UINT32 frame,UINT32 delay)
{
    return BSP_OK;
}

UINT32 acsmpcfg(UINT32 dir,UINT32 bspChan,UINT32 carrNo,UINT32 sw)
{
    return BSP_OK;
}

UINT32 acsmpdlbank(UINT32 bspChan, UINT32 carrNo, UINT32 pos, UINT32 upLoadFlag)
{
    return BSP_OK;
}

UINT32 acsmpdlpost(UINT32 bspChan,UINT32 carrNo,UINT32 pos,UINT32 frepos, UINT32 upLoadFlag)
{
    return BSP_OK;
}

UINT32 acsmpulchan(UINT32 bspChan,UINT32 carrNo, UINT32 pos, UINT32 upLoadFlag)
{
    return BSP_OK;
}

UINT32 acsmpulbank(UINT32 bspChan,UINT32 carrNo,UINT32 pos, UINT32 upLoadFlag)
{
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetRfAcDelayIc4
 * 功能描述:打印二次精时延补偿后的值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
*                    10252261
 **************************************************************************/
VOID BspGetRfAcDelayIc4(UINT32 acType,UINT32 radioMode,UINT32 carrNo)
{}

VOID AcHelp(VOID)
{
    dbgInfo(" Show Ac UlBank Delay:     GetUlBankWaitDelay\n");
    dbgInfo(" Set Ac NR UlBank Delay:   SetUlBankWaitDelay bandWidth,delay\n");
    dbgInfo(" Set Ac LTE UlBank Delay:  SetLteUlBankWaitDelay bandWidth,delay\n");
}

UINT32 AcFuncLogGetLogLevel(VOID)
{
    return g_acFuncLogLevel;
}

VOID AcFuncLogLevelSet(UINT32 uiLogLevel)
{
    g_acFuncLogLevel = uiLogLevel;
}

//AC Func离线log
INT64 AcFuncLogGetFileLen(INT64 *size)
{
    FILE *pFile;
    INT64 liTmpSize;
    INT32 iRet = 0;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;

    iRet = zte_fopen_s(&pFile, cAcFuncLogFileDir, "rb", cDirList, rDirListSize);
    if(pFile == NULL)
    {
        liTmpSize = 0;
    }
    else
    {
        iRet =fseek(pFile, 0, SEEK_END);
        FSEEK_CHECK(iRet);
        liTmpSize = ftell(pFile);
        if(liTmpSize < ((INT64)0))
        {
            dbgErr("%s(%d) warning! > ftell ret'%lld! \n", __FUNCTION__, __LINE__, liTmpSize);
        }
        iRet = fclose(pFile);
        FCLOSE_CHECK(iRet);
    }
    *size = liTmpSize;

    return BSP_OK;
}

INT32 AcFuncLog(UINT32 logLevel, const CHAR *format, ...)
{
    FILE *pFile = NULL;
    CHAR * const cDirList[1] = {"/"};
    rsize_t rDirListSize = 1;
    INT32 iRet           = 0;
    UINT32 uiAclogLevel  = 0;
    INT64 iLogSize       = 0;

    uiAclogLevel = AcFuncLogGetLogLevel();
    if(logLevel > uiAclogLevel)
    {
        return BSP_OK;
    }

    iRet = AcFuncLogGetFileLen(&iLogSize);
    if ((INT32)BSP_OK != (iRet))
    {
        dbgErr("[%s], line: %u iRet'%d Error \n", __FUNCTION__, __LINE__, (iRet));
        return BSP_INT_ERROR;
    }
    if(iLogSize >= AC_FUNC_LOG_MAX_SIZE)
    {
        BspHandleAcLogRstSuc();
    }
    iRet = zte_fopen_s(&pFile, cAcFuncLogFileDir, "a+", cDirList, rDirListSize);
    ZTE_SECURITY_FUNC_CHECK(iRet);

    if(pFile == NULL)
    {
        dbgErr("%s %d, fail to open file! \n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    va_list arg;
    va_start(arg, format);
    struct tm timelog;
    struct tm* tm_log = NULL;
    struct timeval nowtime;
    gettimeofday(&nowtime, NULL);
    //coverity[declaration_with_small_time_t:SUPPRESS]
    time_t seconds = nowtime.tv_sec;
    zte_memset_s(&timelog, sizeof(timelog), 0x00, sizeof(timelog));
    tm_log = localtime_r(&seconds, &timelog);

    if(tm_log != NULL)
    {
        iRet = fprintf(pFile, "%04d-%02d-%02d %02d:%02d:%02d.%06ld|%d| ",
                                tm_log->tm_year + 1900,
                                tm_log->tm_mon+1,
                                tm_log->tm_mday,
                                tm_log->tm_hour,
                                tm_log->tm_min,
                                tm_log->tm_sec,
                                nowtime.tv_usec,
                                logLevel);
        FPRINTF_CHECK(iRet);
    }

    //ZTE_SECURITY_FUNC_CHECK(iRet);
    (void)zte_vfprintf_s(pFile, format, arg);
    //FPRINTF_CHECK(iRet);
    va_end(arg);
    iRet = fflush(pFile);
    FFLUSH_CHECK(iRet);
    iRet = fclose(pFile);
    FCLOSE_CHECK(iRet);

    return iRet;
}

VOID BspAcFuncLogCount()
{
    g_AcFuncLogFileNum++;
    if(g_AcFuncLogFileNum >= AC_FUNC_LOG_FILE_MAX)
    {
        g_AcFuncLogFileNum = 0;
    }
}

UINT32 BspHandleAcLogRstSuc()
{
    INT32 iRet = 0;
    CHAR * const cCommandRmFile[3] = {"rm", cAcFuncLogFileDir, NULL};
    rsize_t uiCommandRmFileLen = 3;

    iRet = zte_system_s("/bin/rm",
                        cCommandRmFile,
                        uiCommandRmFileLen,
                        cAcFuncPathList,
                        rAcFuncPathListSize);/*删除原始log*/
    ZTE_SECURITY_FUNC_CHECK(iRet);

    return iRet;
}

UINT32 BspHandleAcLogRstFail()
{
    INT32 iRet = 0;
    CHAR cAcFuncLogBuffix[AC_FUNC_LOG_MAX_STRING];
    CHAR cAcFuncLogBakDir[AC_FUNC_LOG_MAX_STRING];
    CHAR * const cCommandMvFile[4] = {"mv", cAcFuncLogFileDir, cAcFuncLogBakDir, NULL};
    rsize_t uiCommandMvFileLen = 4;

    iRet = zte_strncpy_s(cAcFuncLogBakDir, sizeof(cAcFuncLogBakDir), cAcFuncLogPrefix, sizeof(cAcFuncLogPrefix));
    ZTE_SECURITY_FUNC_CHECK(iRet);

    iRet = zte_snprintf_s(cAcFuncLogBuffix, sizeof(cAcFuncLogBuffix), "ic%d_%d.txt", BspGetRpuId(), g_AcFuncLogFileNum);
    ZTE_SECURITY_FUNC_CHECK(iRet);

    iRet = zte_strncat_s(cAcFuncLogBakDir, sizeof(cAcFuncLogBakDir), cAcFuncLogBuffix, sizeof(cAcFuncLogBuffix));
    ZTE_SECURITY_FUNC_CHECK(iRet);

    iRet = zte_system_s("/bin/mv",
                        cCommandMvFile,
                        uiCommandMvFileLen,
                        cAcFuncPathList,
                        rAcFuncPathListSize);/* 备份log  */
    BspAcFuncLogCount();

    return iRet;
}

UINT32 AcFuncPasta(VOID)
{
    UINT32 uiPaChnNum = BspGetTxChannel();
    UINT32 uiLnaChnNum = BspGetRxChannel();
    UINT32 *pPaSta;
    UINT32 *pLnaSta;
    UINT32 uiLoop;

    if(0 == BspGetTddIoInitFlag())
    {
        AcFuncLog(AC_FUNC_LOG_HIGH, "[%s] Err: Please wait for TDDIOINIT!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    pPaSta = malloc(uiPaChnNum * sizeof(UINT32));
    if(pPaSta == NULL)
    {
        return BSP_ERROR;
    }
    pLnaSta = malloc(uiLnaChnNum * sizeof(UINT32));
    if(pLnaSta == NULL)
    {
        free(pPaSta);
        return BSP_ERROR;
    }

    for(uiLoop = 0; uiLoop < uiPaChnNum; uiLoop++)
    {
        pPaSta[uiLoop] = BspGetPaSwitch(uiLoop);
    }

    for(uiLoop = 0; uiLoop < uiLnaChnNum; uiLoop++)
    {
        pLnaSta[uiLoop] = BspGetLnaSwitch(uiLoop);
    }

    AcFuncLog(AC_FUNC_LOG_HIGH, "pa switch status(0:OFF,1:ON 2:FDDON):\n");
    for(uiLoop = 0;uiLoop < uiPaChnNum;uiLoop++)
    {
        AcFuncLog(AC_FUNC_LOG_HIGH, "pa [%d]%d \n", uiLoop, pPaSta[uiLoop]);
    }

    AcFuncLog(AC_FUNC_LOG_HIGH, "lna switch status(0:OFF,1:ON 2:FDDON):\n");
    for(uiLoop = 0;uiLoop < uiLnaChnNum;uiLoop++)
    {
        AcFuncLog(AC_FUNC_LOG_HIGH, "lna [%d]%d \n", uiLoop, pLnaSta[uiLoop]);
    }

    free(pPaSta);
    free(pLnaSta);

    return BSP_OK;
}

VOID AcFuncDbfs(VOID)
{
    UINT32 uiRetVal = 0;
    UINT32 ulBand = 0;
    UINT32 uiBspChn = 0;
    ePowType powType = BSP_TSSI_FWD_INFO;
    T_TxPow tPowDbfs = {0};

    for (uiBspChn = 0; uiBspChn < BspGetTxChannel(); uiBspChn++)
    {
        uiRetVal |= GetTssiPowDbfs(uiBspChn, ulBand, powType, &tPowDbfs);
        AcFuncLog(AC_FUNC_LOG_HIGH, "Chan %2d:FwdTssi=%6d | FbFwd=%6d | RevTssi=%6d | FbRev=%6d | isPowValid=%6d\n",\
                                     uiBspChn, tPowDbfs.tFwdPow.ifTssiPow, tPowDbfs.tFwdPow.fbPow\
                                     ,tPowDbfs.tRevPow.ifTssiPow, tPowDbfs.tRevPow.fbPow\
                                     ,tPowDbfs.isPowValid);
    }
}

VOID AcFuncAttshow(VOID)
{
    UINT32 uiChn;
    UINT32 uiLoop;
    struct
    {
        const char *pDesc;
        INT32  *buf;
        UINT32 (*pGetAtt)(UINT32 chan,INT32 *attVal);
        UINT32 chanNum;
    } attInfo[] = {
        {"txAtt" ,      NULL, BspGetTxAtt,      BspGetTxChannel()},
        {"rxAtt" ,      NULL, BspGetRxAtt,      BspGetRxChannel()},
        {"rxVga" ,      NULL, BspGetRxVga,      BspGetRxChannel()}
    };

    for(uiLoop = 0;uiLoop < NELEMENTS(attInfo);uiLoop++)
    {
        attInfo[uiLoop].buf = malloc(attInfo[uiLoop].chanNum * sizeof(INT32));
        if(attInfo[uiLoop].buf)
        {
            zte_memset_s(attInfo[uiLoop].buf, attInfo[uiLoop].chanNum * sizeof(INT32), 0xff, attInfo[uiLoop].chanNum * sizeof(INT32));
            for(uiChn = 0;uiChn < attInfo[uiLoop].chanNum;uiChn++)
            {
                attInfo[uiLoop].pGetAtt(uiChn, &attInfo[uiLoop].buf[uiChn]);
            }
            for (uiChn = 0;uiChn < attInfo[uiLoop].chanNum;uiChn++)
            {
                AcFuncLog(AC_FUNC_LOG_HIGH, "%s [%d]%d \n", attInfo[uiLoop].pDesc, uiChn, attInfo[uiLoop].buf[uiChn]);
            }
            free(attInfo[uiLoop].buf);
        }
        else
        {
            dbgErr("get %s malloc failed\n",attInfo[uiLoop].pDesc);
        }
    }
}

UINT32 AcFuncDlpostPaptAlm(VOID)
{
    UINT32 uiRet = BSP_OK;
    UINT32 uiIndex_block = 0;
    UINT32 uiIndex_chan = 0;
    UINT32 outBandCnt = 0;
    UINT32 cfrLAvgCnt = 0;
    UINT32 cfrSAvgCnt = 0;
    UINT32 sigPwrCnt = 0;
    UINT32 dpdAvgCnt = 0;
    UINT32 daOffRpt = 0;

    AcFuncLog(AC_FUNC_LOG_HIGH, "PrnDlpostPaptAlm for All Channel:\n");
    AcFuncLog(AC_FUNC_LOG_HIGH, "|%-8s\t|%-8s\t|%-8s\t|%-8s\t|%-8s\t|%-8s\t\n",
                                "outBandCnt", "cfrLAvgCnt", "cfrSAvgCnt", "sigPwrCnt", "dpdAvgCnt", "realStaRpt");
    for(uiIndex_block = 0;uiIndex_block < DL_POST_BLOCK_NUM;uiIndex_block++)
    {
        for(uiIndex_chan = 0;uiIndex_chan < DL_POST_FREQ_NUM_IN_BLOCK;uiIndex_chan++)
        {
            uiRet = DlPostGetPaptOutbandUnusCnt(uiIndex_block, uiIndex_chan, &outBandCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptLongAvgUnusCnt(uiIndex_block, uiIndex_chan, &cfrLAvgCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptShortAvgUnusCnt(uiIndex_block, uiIndex_chan, &cfrSAvgCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptIQUnusCnt(uiIndex_block, uiIndex_chan, &sigPwrCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptAvgPowUnusCnt(uiIndex_block, uiIndex_chan, &dpdAvgCnt);
            RETURN_RESULT_CHECK(uiRet);

            uiRet = DlPostGetPaptDataOffUnusSta(uiIndex_block, uiIndex_chan, &daOffRpt);
            RETURN_RESULT_CHECK(uiRet);

            AcFuncLog(AC_FUNC_LOG_HIGH, "|%-8u\t|%-8u\t|%-8u\t|%-8u\t|%-8u\t|%-8u\t\n",
                                        outBandCnt, cfrLAvgCnt, cfrSAvgCnt, sigPwrCnt, dpdAvgCnt, daOffRpt);
        }
    }

    return BSP_OK;
}

VOID AcFuncRssi(UINT32 uiRadioMode, UINT32 uiCarrNo)
{
    CHAR *pstrDbfsBuf  = NULL;
    CHAR *pstrDbmBuf   = NULL;
    UINT32 uiChnNum    = BspGetRxLogicChanNum();
    UINT32 uiChnLoop   = 0;
    UINT32 uiRadioNum  = 0;
    UINT32 uiRadioLoop = 0;
    INT32  iRssiDbm    = 0;
    INT32  iRssiDbfs   = 0;
    INT32 snpRet       = 0;
    CHAR strDbfsTemp[50] = {0};
    CHAR strDbmTemp[50]  = {0};

    struct sRadio
    {
        UINT32 uMode;
        CHAR *pcModeString;
        UINT32 slotNum;
    }atRadio[] =
    {
        {BSP_RADIO_STANDARD_LTE_TDD, "LTE_TDD",1},
        {BSP_RADIO_STANDARD_LTE_FDD, "LTE_FDD",1},
        {BSP_RADIO_STANDARD_5G,      "5G-NR-TDD",1},
        {BSP_RADIO_STANDARD_FDD_5G,  "5G-NR-FDD",1},
        {BSP_RADIO_STANDARD_UMTS,    "UMTS",1},
        {BSP_RADIO_STANDARD_NB_IOT,  "NB-IOT",1},
        {BSP_RADIO_STANDARD_GSM,     "GSM",1},
    };
    uiRadioNum = sizeof(atRadio) / sizeof(atRadio[0]);

    pstrDbfsBuf = malloc(sizeof(CHAR) * RSSI_BUF_SIZE);
    if (pstrDbfsBuf == NULL)
    {
        dbgErr("%s: pstrDbfsBuf malloc failed \n",__FUNCTION__);
        return;
    }

    pstrDbmBuf = malloc(sizeof(CHAR) * RSSI_BUF_SIZE);
    if (pstrDbmBuf == NULL)
    {
        dbgErr("%s: pstrDbmBuf malloc failed \n",__FUNCTION__);
        free(pstrDbfsBuf);
        return;
    }

    zte_memset_s(pstrDbfsBuf, sizeof(CHAR) * RSSI_BUF_SIZE, 0, sizeof(CHAR) * RSSI_BUF_SIZE);
    zte_memset_s(pstrDbmBuf, sizeof(CHAR) * RSSI_BUF_SIZE, 0, sizeof(CHAR) * RSSI_BUF_SIZE);

    for(uiRadioLoop = 0;uiRadioLoop < uiRadioNum;uiRadioLoop++)
    {
        if(uiRadioMode == atRadio[uiRadioLoop].uMode)
        {
            break;
        }
    }
    if(uiRadioLoop >= uiRadioNum)
    {
        dbgErr("[%s], unSupport RadioMode\n", __FUNCTION__);
        free(pstrDbfsBuf);
        free(pstrDbmBuf);
        return;
    }

    AcFuncLog(AC_FUNC_LOG_HIGH, "-----------------%s ChnlSum'%d RSSI---------------\n", atRadio[uiRadioLoop].pcModeString, uiChnNum);
    for (uiChnLoop = 0;uiChnLoop < uiChnNum;uiChnLoop++)
    {
        BspGetRssiPowInfoByMode(uiChnLoop, uiCarrNo, uiRadioMode, 0, 0, &iRssiDbm, &iRssiDbfs);

        snpRet = snprintf_s(strDbfsTemp, sizeof(strDbfsTemp), "C%dA%d:%d %s", uiCarrNo, uiChnLoop,
                            iRssiDbfs, (uiChnLoop == uiChnNum - 1) ? "\n" : "");
        SNPRINTF_S_CHECK(snpRet, sizeof(strDbfsTemp));

        snpRet = snprintf_s(pstrDbfsBuf, RSSI_BUF_SIZE, "%s", strDbfsTemp);
        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE);

        snpRet = snprintf_s(strDbmTemp, sizeof(strDbmTemp), "C%dA%d:%d %s", uiCarrNo, uiChnLoop,
                            iRssiDbfs, (uiChnLoop == uiChnNum - 1) ? "\n" : "");
        SNPRINTF_S_CHECK(snpRet, sizeof(strDbmTemp));

        snpRet = snprintf_s(pstrDbmBuf, RSSI_BUF_SIZE, "%s", strDbmTemp);
        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE);
    }
    AcFuncLog(AC_FUNC_LOG_HIGH, "dbfs: %s\n", pstrDbfsBuf);
    AcFuncLog(AC_FUNC_LOG_HIGH, "dbm : %s\n", pstrDbmBuf);

    free(pstrDbfsBuf);
    free(pstrDbmBuf);
}

UINT32 AcFuncCarrSta(VOID)
{
    UINT32 uiRet        = 0;
    UINT32 uiDifChanNum = 0;
    UINT32 uiDifChanIdx = 0;
    UINT32 uiCarrIdx    = 0;
    UINT32 uiCarrId     = 0;
    UINT32 uiCarrRadio  = 0;
    UINT32 uiCarrNum    = 0;
    UINT32 uiTdmCarrSta = 0;
    UINT32 uiAptuneSta  = 0;
    UINT32 uiDgainSta   = 0;

    UINT32 auiCarrId[BSP_DIF_CARR_MAX_NUM] = {0};
    UINT32 auiCarrRadio[BSP_DIF_CARR_MAX_NUM] = {0};

    uiRet = IcHalGetTxDifChanNum(&uiDifChanNum);
    RETURN_RESULT_CHECK(uiRet);

    for (uiDifChanIdx = 0;uiDifChanIdx < uiDifChanNum;uiDifChanIdx++)
    {
        uiRet = IcHalGetTxRadioModeByDifChan(uiDifChanIdx, auiCarrId, auiCarrRadio, &uiCarrNum);
        RETURN_RESULT_CHECK(uiRet);

        if (uiCarrNum > 0)
        {
            for (uiCarrIdx = 0;uiCarrIdx < uiCarrNum;uiCarrIdx++)
            {
                uiCarrId = auiCarrId[uiCarrIdx];
                uiCarrRadio = auiCarrRadio[uiCarrIdx];

                uiRet = IcHalApiGetDlpreGainDataEnStatus(uiDifChanIdx, uiCarrId, uiCarrRadio, &uiTdmCarrSta);
                RETURN_RESULT_CHECK(uiRet);

                uiRet = IcHalApiGetDlbankAptuneDataEnStatus(uiDifChanIdx, uiCarrId, uiCarrRadio, &uiAptuneSta);
                RETURN_RESULT_CHECK(uiRet);

                uiRet = IcHalApiDlbankDgainDataEnStatus(uiDifChanIdx, uiCarrId, uiCarrRadio, &uiDgainSta);
                RETURN_RESULT_CHECK(uiRet);

                AcFuncLog(AC_FUNC_LOG_HIGH, "|ChanId |CarrId |CarrRadio |TdmCarr |Aptune |Dgain (0: off, 1:on)\n");
                AcFuncLog(AC_FUNC_LOG_HIGH, "|%-u    |%-u    |%-u       |%-u     |%-u    |%-u \n", uiDifChanIdx, uiCarrId, uiCarrRadio, uiTdmCarrSta, uiAptuneSta, uiDgainSta);
            }
        }
        else
        {
            AcFuncLog(AC_FUNC_LOG_HIGH, "DifChan[%u] dont have valid carries!\n", uiDifChanIdx);
        }
    }

    return BSP_OK;
}

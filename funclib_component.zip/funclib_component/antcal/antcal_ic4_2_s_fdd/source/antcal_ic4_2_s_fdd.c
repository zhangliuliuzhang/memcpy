#include "bsppub.h"
#include "bspcomm.h"
#include <stdint.h>
#include <fcntl.h>
#include <errno.h>
#include <math.h>
#include <time.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <linux/if_ether.h>
#include <linux/if_packet.h>
#include <linux/if.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <netdb.h>
#include <linux/errno.h>
#include <sys/time.h>
#include <sys/mman.h>
#include "systemcallapi.h"
#include "antcal_ic4_2_oneic.h"
#include "regdrv.h"
#include "freqcfgcommon.h"
#include "vxadp.h"
#include "chnmap_a.h"
#include "rftable.h"
#include "exprn.h"
#include "antcalcommon.h"
#include "acdrv_ic4_2_s_fdd.h"
#include "icopthalcomm.h"
#include "regdrv_accesstbl.h"
#include "chnmapapi.h"
#include "resource_alloc_api.h"
#include "ac_ext_api.h"
#include "psync.h"
#include "dlyapi.h"
#include "funccommonapi.h"
#include "cellcfg.h"
#include "dsp_msg.h"
#include "ac_app.h"
#include "ac_ext_api.h"
#include "acdebug.h"
#include "cellcfgapi.h"
#include "dif_dly_api.h"
#include "dpd_app.h"
#include "psyncdrv.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "optctrl_inter_def.h"
#include "powerctrl_ic4_2.h"
#include "dif_router.h"
/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                        宏                                              *
 **************************************************************************/
#define AC_PSYNC_FRAMENO_WAIT          260      //AC 发数、采数等待时间
#define AC_MAX_FRAME_NO                (1023)
#define MIX_NR_MODE                    20313  //(2496)/122.88*1000
/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/
ac_user_AddrCfg s_acUserAddrCfg = {IC_AC_SHARE_MEM_ADDR_PHY_BASE, IC_AC_SHARE_MEM_ADDR_SIZE}; /* IC A53和KO 共享内存 */
INT32 s_cpswacFd = -1;
UINT8 *s_ucRamDspAddr = NULL;
T_AcCarrCfgNxp g_acCarrCfgNxp = {0};
UINT32 s_ulCellFre = 0;
UINT32 acBitmap[2] = {0,};
DOUBLE s_Gp2AcEnd = 0;
DOUBLE s_Gp2Ac = 0;
INT32 SendHaulBackAcSeqIcUlAcCnt = 0;
//32个bit，bit=0降秩，bit=1不降秩
UINT32 s_wgtUpdateBitMap = 0;
UINT32 g_acFunctionLib_Init_STA = 0;
//JAC新增
UINT32 g_uiJacMode = 0;
UINT32 g_uiJacHandleType = 0;
UINT8 g_uiJacBitMap = 0;
UINT32 g_uiSuperFr = 0;
T_JacSuperFrInfo g_tJacFrInfo[JAC_FR_DEBUG_CNT_MAX];
UINT32 g_uiJacSuperFrDebugCnt = 0;
UINT32 g_uiAlgTimeSw = 0;
static T_wgtBakDataPara s_wgtBakDataPara[BSP_MAX_CARR_NUM] = {0};
static UINT32 s_IsSupportAac = NO_SUPPORT;

/* AAC维测 */
typedef struct tagT_aacWgtDataPara
{
    UINT32 logicCarrNo;
    UINT32 radioMode;
    UINT32 aacErrWgtbak[IC42_MAX_CHAN_NUM];
    UINT32 aacWgtLength;  /* AAC权值的长度，单位为byte */
    UINT32 aacInitiateNum;
}T_aacWgtDataPara;

static UINT32 s_aacInitiateNum = 0;
static UINT32 s_errAacNum = 0;
static T_aacWgtDataPara s_dbgAacWgtDataPara[BSP_MAX_CARR_NUM] = {0};
static UINT32 s_testAacWgt[IC42_MAX_CHAN_NUM] = {0};

//所有制式下参数，注意主从数据长度单位不一样
T_AcAllParaInfo g_acAllParaInfo[] = \
{
    /****************************************TDD  Begin*****************************************************/
    {RADIO_STANDARD_5G, BANDWIDTH_100M_MHz, CLK_RATE_122P88, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_5G, BANDWIDTH_90M_MHz, CLK_RATE_122P88, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_5G, BANDWIDTH_80M_MHz, CLK_RATE_92P16, AC_DATA_LEN_768, AC_DATA_OFFSET_96, AC_CP_48},
    {RADIO_STANDARD_5G, BANDWIDTH_70M_MHz, CLK_RATE_92P16, AC_DATA_LEN_768, AC_DATA_OFFSET_96, AC_CP_48},
    {RADIO_STANDARD_5G, BANDWIDTH_60M_MHz, CLK_RATE_61P44, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_5G, BANDWIDTH_50M_MHz, CLK_RATE_61P44, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_5G, BANDWIDTH_40M_MHz, CLK_RATE_61P44, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_5G, BANDWIDTH_30M_MHz, CLK_RATE_30P72, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},
    {RADIO_STANDARD_5G, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},
    {RADIO_STANDARD_5G, BANDWIDTH_25M_MHz, CLK_RATE_30P72, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},

    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_15M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_10M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_5M_MHz,  CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_60M_MHz, CLK_RATE_122P88, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},

    /****************************************TDD  End*******************************************************/

    /****************************************FDD  Begin*****************************************************/
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_50M_MHz, CLK_RATE_61P44, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_45M_MHz, CLK_RATE_61P44, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_40M_MHz, CLK_RATE_61P44, AC_DATA_LEN_1024, AC_DATA_OFFSET_128, AC_CP_64},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_25M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz, CLK_RATE_15P36, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_5M_MHz,   CLK_RATE_7P68, AC_DATA_LEN_128, AC_DATA_OFFSET_16, AC_CP_8},

    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz, CLK_RATE_30P72, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz, CLK_RATE_15P36, AC_DATA_LEN_256, AC_DATA_OFFSET_32, AC_CP_16},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,   CLK_RATE_7P68, AC_DATA_LEN_128, AC_DATA_OFFSET_16, AC_CP_8},

    {RADIO_STANDARD_UMTS, BANDWIDTH_5M_MHz, CLK_RATE_7P68, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_UMTS, BANDWIDTH_4M_MHz, CLK_RATE_7P68, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_UMTS, BANDWIDTH_3M_MHz, CLK_RATE_7P68, AC_DATA_LEN_512, AC_DATA_OFFSET_64, AC_CP_32},
    {RADIO_STANDARD_GSM,  GSM_BANDWIDTH_MHz, CLK_RATE_7P68 ,GSM_AC_DATA_LEN,GSM_AC_DATA_OFFSET,GSM_AC_CP},
    /****************************************FDD  End*******************************************************/
};

//延时参数配置
T_AcLenInfo g_tAcLenInfo[] = \
{
    /*******************************TDD  Begin*****************************************/
    {RADIO_STANDARD_5G,BANDWIDTH_100M_MHz,CLK_RATE_122P88 ,GP_AC_SQUENCE_LEN_NR_122880},
    {RADIO_STANDARD_5G,BANDWIDTH_90M_MHz ,CLK_RATE_122P88 ,GP_AC_SQUENCE_LEN_NR_122880},
    {RADIO_STANDARD_5G,BANDWIDTH_80M_MHz ,CLK_RATE_92P16  ,GP_AC_SQUENCE_LEN_NR_92160},
    {RADIO_STANDARD_5G,BANDWIDTH_70M_MHz ,CLK_RATE_92P16  ,GP_AC_SQUENCE_LEN_NR_92160},
    {RADIO_STANDARD_5G,BANDWIDTH_60M_MHz ,CLK_RATE_61P44  ,GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_5G,BANDWIDTH_50M_MHz ,CLK_RATE_61P44  ,GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_5G,BANDWIDTH_40M_MHz ,CLK_RATE_61P44  ,GP_AC_SQUENCE_LEN_NR_61440},
    {RADIO_STANDARD_5G,BANDWIDTH_30M_MHz ,CLK_RATE_30P72  ,GP_AC_SQUENCE_LEN_NR_30720},
    {RADIO_STANDARD_5G,BANDWIDTH_20M_MHz ,CLK_RATE_30P72  ,GP_AC_SQUENCE_LEN_NR_30720},
    {RADIO_STANDARD_5G,BANDWIDTH_25M_MHz ,CLK_RATE_30P72  ,GP_AC_SQUENCE_LEN_NR_30720},

    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_20M_MHz, CLK_RATE_30P72 ,GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_15M_MHz, CLK_RATE_23P04 ,GP_AC_SQUENCE_LEN_LTE_23040},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_10M_MHz, CLK_RATE_15P36 ,GP_AC_SQUENCE_LEN_LTE_15360},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_5M_MHz , CLK_RATE_15P36 ,GP_AC_SQUENCE_LEN_LTE_15360},
    {RADIO_STANDARD_LTE_TDD,BANDWIDTH_60M_MHz, CLK_RATE_122P88,GP_AC_SQUENCE_LEN_NR_122880},
    /*******************************TDD  End*******************************************/

    /*******************************FDD  Begin*****************************************/
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_50M_MHz, CLK_RATE_61P44, GP_AC_SQUENCE_LEN_FDD_NR_61440},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_45M_MHz, CLK_RATE_61P44, GP_AC_SQUENCE_LEN_FDD_NR_61440},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_40M_MHz, CLK_RATE_61P44, GP_AC_SQUENCE_LEN_FDD_NR_61440},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_FDD_NR_30720},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_25M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_FDD_NR_30720},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_FDD_NR_30720},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_FDD_NR_30720},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz, CLK_RATE_15P36, GP_AC_SQUENCE_LEN_FDD_NR_15360},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_5M_MHz,  CLK_RATE_7P68,  GP_AC_SQUENCE_LEN_FDD_NR_7680},

    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz, CLK_RATE_30P72, GP_AC_SQUENCE_LEN_LTE_30720},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz, CLK_RATE_15P36, GP_AC_SQUENCE_LEN_LTE_15360},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,  CLK_RATE_7P68,  GP_AC_SQUENCE_LEN_LTE_7680},

    {RADIO_STANDARD_UMTS, BANDWIDTH_5M_MHz, CLK_RATE_7P68, GP_AC_SQUENCE_LEN_UMTS_7680},
    {RADIO_STANDARD_UMTS, BANDWIDTH_4M_MHz, CLK_RATE_7P68, GP_AC_SQUENCE_LEN_UMTS_7680},
    {RADIO_STANDARD_UMTS, BANDWIDTH_3M_MHz, CLK_RATE_7P68, GP_AC_SQUENCE_LEN_UMTS_7680},
    /*******************************FDD  End*******************************************/
};

T_AcWgtInfo g_acWgtInfo[] = \
{
    /****************TDD  Begin************************/
    {RADIO_STANDARD_5G,  BANDWIDTH_100M_MHz, 273},
    {RADIO_STANDARD_5G,  BANDWIDTH_90M_MHz,  245},
    {RADIO_STANDARD_5G,  BANDWIDTH_80M_MHz,  217},
    {RADIO_STANDARD_5G,  BANDWIDTH_60M_MHz,  162},
    {RADIO_STANDARD_5G,  BANDWIDTH_50M_MHz,  133},
    {RADIO_STANDARD_5G,  BANDWIDTH_40M_MHz,  106},
    {RADIO_STANDARD_5G,  BANDWIDTH_30M_MHz,  78},
    {RADIO_STANDARD_5G,  BANDWIDTH_25M_MHz,  65},
    {RADIO_STANDARD_5G,  BANDWIDTH_20M_MHz,  51},

    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_20M_MHz,  100},
    {RADIO_STANDARD_LTE_TDD, BANDWIDTH_10M_MHz,  50},
    /****************TDD  End**************************/

    /****************FDD  Begin************************/
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_50M_MHz,  270},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_45M_MHz,  242},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_40M_MHz,  216},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_30M_MHz,  160},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_25M_MHz,  133},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_20M_MHz,  106},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_15M_MHz,  79},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_10M_MHz,  52},
    {RADIO_STANDARD_FDD_5G, BANDWIDTH_5M_MHz,   25},

    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_20M_MHz,  100},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_15M_MHz,  75},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_10M_MHz,  50},
    {RADIO_STANDARD_LTE_FDD, BANDWIDTH_5M_MHz,   25},
    /****************FDD  End**************************/
};

/**************************************************************************
 *                         外部变量声明                                   *
 **************************************************************************/
extern ICRRBlockBankDL dlAcBlockBankBandInfo[AC_IC_NUM];//2片IC
extern ICRRBlockBankUL ulAcBlockBankBandInfo[AC_IC_NUM];//2片IC

/**************************************************************************
 *                         外部函数声明                                   *
 **************************************************************************/

/**************************************************************************
 *                         局部函数声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         全局函数实现                                   *
 **************************************************************************/
/* Started by AICoder, pid:jc8dcgebd5t3c30142e30ad4c0efa810fc07b72f */
UINT32 BspSetAcAlgTimeSw(UINT32 uiSw)
{
    g_uiAlgTimeSw = uiSw;

    return BSP_OK;
}

UINT32 BspGetAcAlgTimeSw(VOID)
{
    return g_uiAlgTimeSw;
}
/* Ended by AICoder, pid:jc8dcgebd5t3c30142e30ad4c0efa810fc07b72f */
UINT32 BspGetAcFuncLibSta(VOID)
{
    dbgInfo("[%s] acFuncLib sta:%d\n", __FUNCTION__, g_acFunctionLib_Init_STA);
    return g_acFunctionLib_Init_STA;
}

UINT32 BspSetAcFuncLibSta(UINT32 sta)
{
    g_acFunctionLib_Init_STA = sta;
    dbgInfo("[%s] acFuncLib sta:%d\n", __FUNCTION__, g_acFunctionLib_Init_STA);
    return BSP_OK;
}

UINT32 BspJudgeAcType(UINT32 acType)
{
    UINT32 uiAcType = 0;

    switch(acType)
    {
        case E_AC_TYPE_DL:
        case E_AC_TYPE_FDD_DL:
        {
            uiAcType = 0;
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_FDD_UL:
        {
            uiAcType = 1;
            break;
        }
        case E_AC_TYPE_STOP:
        {
            uiAcType = 2;
            break;
        }
        default:
        {
            dbgErr("%s unknow ac type \n", __FUNCTION__);
            break;
        }
    }

    return uiAcType;
}

//JAC新增
UINT32 SetJacMode(UINT32 uiJacMode, UINT32 uiJacHandleType, UINT8 uiBitMap)
{
    g_uiJacMode = uiJacMode;
    g_uiJacHandleType = uiJacHandleType;
    g_uiJacBitMap = uiBitMap;
    dbgInfo("[%s], g_uiJacMode:%d, g_uiJacHandleType:%d, g_uiJacBitMap:0x%x \n", __FUNCTION__, g_uiJacMode, g_uiJacHandleType, g_uiJacBitMap);

    return BSP_OK;
}

UINT32 GetJacMode(VOID)
{
    dbgInfoEx("[%s], g_uiJacMode:%d \n", __FUNCTION__, g_uiJacMode);

    return g_uiJacMode;
}

UINT32 GetJacType(VOID)
{
    dbgInfoEx("[%s], g_uiJacHandleType:%d \n", __FUNCTION__, g_uiJacHandleType);

    return g_uiJacHandleType;
}

UINT8 GetJacBitMap(VOID)
{
    dbgInfoEx("[%s], g_uiJacBitMap:0x%x \n", __FUNCTION__, g_uiJacBitMap);

    return g_uiJacBitMap;
}

UINT32 SetJacSuperFr(UINT32 uiSuperFr)
{
    g_uiSuperFr = uiSuperFr;
    dbgInfo("[%s], uiSuperFr:%d \n", __FUNCTION__, uiSuperFr);

    return BSP_OK;
}

UINT32 GetJacSuperFr(VOID)
{
    dbgInfoEx("[%s], uiSuperFr:%d \n", __FUNCTION__, g_uiSuperFr);

    return g_uiSuperFr;
}

UINT32 BspRecordJacSuperFr(A53R8AcDebugShareInfo* shareInfo)
{
    INPUT_POINTER_CHECK(shareInfo);
    if(JAC_SUPER_FR_ERR == shareInfo->acJacSuperFrErr)
    {
        g_uiJacSuperFrDebugCnt = (g_uiJacSuperFrDebugCnt >= JAC_FR_DEBUG_CNT_MAX)? 0 : g_uiJacSuperFrDebugCnt;
        g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiCfgFr = shareInfo->acJacCfgSuperFr;
        g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiRealFr = shareInfo->acJacRealSuperFr;
        g_tJacFrInfo[g_uiJacSuperFrDebugCnt].timeRet  = time(NULL);
        dbgInfo("[%s], g_uiJacSuperFrDebugCnt:%d uiCfgFr:%d, uiRealFr:%d \n", __FUNCTION__, g_uiJacSuperFrDebugCnt,
                g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiCfgFr, g_tJacFrInfo[g_uiJacSuperFrDebugCnt].uiRealFr);
        g_uiJacSuperFrDebugCnt++;
    }

    return BSP_OK;
}

UINT32 JacConvertTime(char *paucStrTime, UINT32 uiLen, LONG lTime)
{
    INT32 uiRet   = 0;
    LONG lJacTime = lTime;
    struct tm *ptTransTime = NULL;

    ptTransTime = gmtime((LONG *)&lJacTime);
    if ((struct tm *)NULL != ptTransTime)
    {
        uiRet = snprintf_s(paucStrTime, uiLen, "%04d-%02d-%02d %02d:%02d:%02d\0",
                           ptTransTime->tm_year + 1900, ptTransTime->tm_mon + 1,
                           ptTransTime->tm_mday, ptTransTime->tm_hour,
                           ptTransTime->tm_min,  ptTransTime->tm_sec);
        SNPRINTF_S_CHECK(uiRet, uiLen);
    }

    return BSP_OK;
}

VOID ShowJacSuperFrDebug(VOID)
{
    UINT32 uiFrDebugCnt = 0;
    char   aucStrTime[20] = {0};

    for(uiFrDebugCnt = 0;uiFrDebugCnt < JAC_FR_DEBUG_CNT_MAX; uiFrDebugCnt++)
    {
        JacConvertTime(aucStrTime, sizeof(aucStrTime), g_tJacFrInfo[uiFrDebugCnt].timeRet);
        dbgInfo("[%s], DL:g_tJacFrInfo[%d]: uiCfgFr:%d, uiRealFr:%d \n", aucStrTime, uiFrDebugCnt,
                g_tJacFrInfo[uiFrDebugCnt].uiCfgFr,
                g_tJacFrInfo[uiFrDebugCnt].uiRealFr);
    }
}

UINT8* BspGetAcMemBaseAddr(VOID)
{
    return s_ucRamDspAddr;
}

/******************************************************************************
* 函数名称   : BspGetAcRecvPacks()
* 功能描述   : 获取内核中接收ac数据包数
* 读全局变量 : 无
* 写全局变量 : 无
* 输入参数   : 无
*
* 输出参数   : 无
* 返 回 值   : BSP_OK :成功
               其他   :错误码
* 其它说明   : 对外接口
* ----------------------------------------------------------------------------*
* 历史记录(变更单, 责任人 @修改日期,      操作说明)
* $0000000(N/A),   牛彦茹                 创建
******************************************************************************/
UINT32 GetAcRecvPacks(VOID)
{
    UINT32 acRcvPacks=0;
    UINT32 temp = 0;

    if (s_cpswacFd <= 0)
    {
        s_cpswacFd = open(KXCPSW_AC_DEV,O_RDWR | O_SYNC);
        dbgInfo("open /dev/cpsw_ac dev \n ");
    }
    if(-1 == s_cpswacFd)
    {
        dbgInfo("Open cpsw_ac error \n");
    }

    /*获取接收包数*/
    temp = ioctl(s_cpswacFd, CPSW_AC_DATA_GET, &acRcvPacks);
    dbgInfo("get the cpsw ac recv packets is = %d, temp:%#x\n",acRcvPacks, temp);

    return acRcvPacks;
}
/**************************************************************************
 * 函数名称: BspAcDataInit
 * 功能描述: 整个ac模块初始化
 * 输入参数: pAddcfg: 给内核的各个配置
             pUserAddCfg: 给用户态的各个配置
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2021年9月23日                   10263250    创建
 **************************************************************************/
UINT32 AcDataInit(VOID)
{
    INT32 Fd                     = 0; /*内存设备的文件描述符*/
    UINT32 ulAcRamLen            = 0;
    ac_user_AddrCfg *pUserAddCfg = NULL;
    UINT32 acFuncLibSta = 0;

    //如果ac funclib已经被初始化过，直接返回
    acFuncLibSta = BspGetAcFuncLibSta();
    if(1 == acFuncLibSta)
    {
        dbgInfo("[%s] ac FuncLib already Inited \n", __FUNCTION__);
        return BSP_OK;
    }

    
    SetRecordAcDoInfoInit();
    recordAcDataInitCnt();

    pUserAddCfg = malloc(sizeof(ac_user_AddrCfg));
    if (pUserAddCfg == NULL)
    {
        dbgErr("%s[%d]malloc faild!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    memcpy_s(pUserAddCfg, sizeof(ac_user_AddrCfg), &s_acUserAddrCfg, sizeof(ac_user_AddrCfg));

    /*通过mmap将物理地址映射到用户进程的虚拟地址空间*/
    Fd = open("/dev/memnc", O_RDWR | O_SYNC);  /*打开内存设备的文件描述符*/
    if (Fd == -1)
    {
        dbgInfo("open /dev/memnc failed\n");
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    /*设置用户态共享内存基址和长度*/
    ulAcRamLen = pUserAddCfg->aclength;
    s_ucRamDspAddr = mmap(0, ulAcRamLen, PROT_READ | PROT_WRITE, MAP_SHARED, Fd, pUserAddCfg->acaddr);//0xC000_0000
    if (s_ucRamDspAddr == MAP_FAILED)
    {
        dbgInfo("mmap g_ulRamDspAddr failed %s, %d\n",strerror(errno),errno);
        close(Fd);
        free(pUserAddCfg);
        return BSP_ERROR;
    }
    close(Fd);
    free(pUserAddCfg);
    memset((VOID*)s_ucRamDspAddr, 0, ulAcRamLen);

    BspSetBoardAcInfo();
    BspRestAcInt();
    BspAcKoInit();
    BspSetAcFuncLibSta(1); //标记ac funclib已经被初始化过

    dbgInfo("%s>>ShareRamDspAddr= %p; RamLen= (0x%08X) %d\n",__FUNCTION__, (VOID*)s_ucRamDspAddr, ulAcRamLen, ulAcRamLen);

    return BSP_OK;
}

UINT32 BspGetTrxTypeByAcType(UINT32 acType)
{
    UINT32 trxType = 0;

    switch(acType)
    {
        case E_AC_TYPE_DL:
        case E_AC_TYPE_FDD_DL:
        {
            trxType = TX;
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_FDD_UL:
        {
            trxType = RX;
            break;
        }
        default:
        {
            trxType = BSP_ERROR;
            break;
        }
    }

    return trxType;
}

UINT32 BspSetAcBcWgt(T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    return BSP_OK;
}

///启动计算AC序列
UINT32 CalAcSeqIc(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate,UINT32 radioMode, UINT32 acType, UINT32 seqType, UINT32 refChan, UINT32 preciseDlyFlag)
{
    return BSP_OK;
}

//检查序列是否计算完
UINT32 ChkAcSeqIc(UINT32 chan)
{
    //目前的策略是等待1秒钟
    recordChkAcSeqIcCnt();
    return 0;
}

//获取AC序列
UINT32 GetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 *length)
{
    return BSP_OK;
}

UINT32 BspGetAcParaInfo(UINT32 radioMode, UINT32 pasteCarrFlag, UINT32 bandWidth, T_AcParaInfo* acParaInfo)
{
    UINT32 loop     = 0;
    UINT32 num      = 0;
    UINT32 retVal = BSP_ERROR;

    num = (sizeof(g_acAllParaInfo) / sizeof(g_acAllParaInfo[0]));
    for(loop=0;loop < num;loop++)
    {
        if((radioMode == g_acAllParaInfo[loop].radio)&&(bandWidth == g_acAllParaInfo[loop].bandWidth))
        {
            acParaInfo->sample       = g_acAllParaInfo[loop].sample;
            acParaInfo->acSeqLen     = g_acAllParaInfo[loop].acSeqLen;
            acParaInfo->acDataOffset = g_acAllParaInfo[loop].acDataOffset;
            acParaInfo->acCpLen      = g_acAllParaInfo[loop].acCpLen;
            retVal = BSP_OK;
        }
    }

    dbgInfo("\n%s sample:%d acSeqLen:%d acDataOffset:%d acCpLen:%d\n",__FUNCTION__,\
            acParaInfo->sample,acParaInfo->acSeqLen,acParaInfo->acDataOffset,acParaInfo->acCpLen);

    return retVal;
}

UINT32 g_saveAcSeqIc3 = 0;
VOID setSaveAcSeqIc3(UINT32 val)
{
    g_saveAcSeqIc3 = val;
}

UINT32 saveAcSeqIc3(UINT32* seq, UINT32 length)
{
    UINT32 ret    = BSP_OK;
    UINT32 jLoop  = 0;
    INT32 iTmpRet    = 0;

    if(0 == g_saveAcSeqIc3)
    {
        return ret;
    }
    INPUT_POINTER_CHECK(seq);

    FILE*  fp = fopen("AcSeqIc.txt", "w+");
    if(fp == NULL)
    {
        return BSP_ERROR;
    }

    for (jLoop = 0; jLoop < length/4; jLoop++)
    {
        iTmpRet = fprintf(fp,"0x%08x\n",seq[jLoop]);
        FPRINTF_CHECK(iTmpRet);
        dbgInfoEx("[%d] Data = 0x%08x \n", jLoop, seq[jLoop]);
    }

    if(-1 == fclose(fp))
    {
        dbgErr("fclose err\n");
        return BSP_ERROR;
    }

    dbgInfo("\n**** see file AcSeqIc.txt ****\n\n");
    return ret;
}

UINT32 printAcSeqFromOam(UINT32* seq, UINT32 length)
{
    INPUT_POINTER_CHECK(seq);
    UINT32 point = 0;

    if(0 == g_saveAcSeqIc3)
    {
        return BSP_OK;
    }

    for(point = 0; point < length/4; point++)
    {
        dbgInfo("point %4d, data 0x%08X\n", point, seq[point]);
    }

    saveAcSeqIc3(seq, length);

    return BSP_OK;
}

//设置AC序列生效
UINT32 SetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32* seq, UINT32 length, UINT32 seqMode)
{
    UINT32 dataLen           = 0;
    T_AcParaInfo acParaInfo  = {0};
    UINT8* baseAddr          = 0;
    UINT32 uiAcType          = 0;
    T_ICHAL_ACPARA *acPara  = NULL;

    INPUT_POINTER_CHECK(seq);

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);

    if((BSP_RADIO_STANDARD_GSM == radioMode) || ((SCENE_RCUA_ON == acPara->uiRcuaScene) && (E_AC_TYPE_FDD_UL == acType)))
    {
        return BSP_OK;
    }

    
    AcFuncLog(AC_FUNC_LOG_HIGH, "SeqCfg acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, seqLen:%d \n",
                                acType, radioMode, bandWidth, carr, length);
    //记录函数执行时间戳
    recordAcTickInfo(0,0,0);//SetAcSeqIc 对应索引 0
    dbgInfo("[%s] IC real FrameNo:%d\n", __FUNCTION__, IcHalGetFrameNo());

    uiAcType = BspJudgeAcType(acType);
    dbgInfo("[%s] uiAcType:%d, acType:%d \n", __FUNCTION__, uiAcType, acType);

    RecordSetAcSeqIcInfo(carr,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode,acType);

    //AC初始清空A53和Ko的共享内存中的AC数据
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset((VOID*)(baseAddr + IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET), 0, IC_AC_SHARE_MEM_DL_CATCH_DATA_SIZE);
    memset((VOID*)(baseAddr + IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET), 0, IC_AC_SHARE_MEM_UL_CATCH_DATA_SIZE);

    dbgInfo("[%s] setSeqData length %d,radioMode %d,bandWidth %d,pasteCarrFlag %d,deviate %d\n",__FUNCTION__,length,radioMode,bandWidth,pasteCarrFlag,deviate);
    dbgInfo("[%s] seqMode %d(0:正常模式,1:残余相差模式)\n",__FUNCTION__,seqMode);
    printAcSeqFromOam(seq,length);

    //获取各制式下差异性参数(不包含时延)
    if(BSP_OK != BspGetAcParaInfo(radioMode,pasteCarrFlag,bandWidth,&acParaInfo))
    {
        dbgErr("%s get AcParaInfo error! \n",__FUNCTION__);
    }

    dataLen = acParaInfo.acSeqLen;
    if(BSP_OK != IcHalAcInsrtDataWrRam(uiAcType, seq, dataLen, length, radioMode, carr))
    {
        return BSP_ERROR;
    }

    recordAcTickInfo(1,0,0);//SetAcSeqIc 对应索引 0

    return BSP_OK;
}

UINT32 testAcSeq[4096];
UINT32 testSetAcSeq(UINT32 carr, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 length)
{
    UINT32 pasteCarrFlag = 0;
    UINT32 deviate = 0;
    UINT32 seqMode = 0;
    SetAcSeqIc(carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, testAcSeq, length, seqMode);

    return BSP_OK;
}

VOID PrintSendHaulBackAcSeqIc(UINT32 retry,UINT32 roundTime,UINT32 round,T_DpdMsgSendAcData_NEW_IC4 *sendData)
{
    dbgInfoEx("\n--------%d--------\n",(retry*roundTime+round-1));
    dbgInfoEx("0 uwDataLen =%d\n",sendData->stDa[0].uwDataLen);
    dbgInfoEx("0 ucCeLLId=%d\n",sendData->stDa[0].ucCeLLId);
    dbgInfoEx("0 ucAcType=%d\n",sendData->stDa[0].ucAcType);
    dbgInfoEx("0 ucIterationNo=%d\n",sendData->stDa[0].ucIterationNo);
    dbgInfoEx("0 ucGroupNo=%d\n",sendData->stDa[0].ucGroupNo);
    dbgInfoEx("0 uwAntNo=%d\n",sendData->stDa[0].uwAntNo);
    dbgInfoEx("0 ComplexData[0]=%d\n",sendData->stDa[0].ComplexData[0].real);
    dbgInfoEx("0 ComplexData[1023]=%d\n",sendData->stDa[0].ComplexData[1023].real);
    dbgInfoEx("\n--------%d--------\n",(retry*roundTime+round));
    dbgInfoEx("1 uwDataLen =%d\n",sendData->stDa[1].uwDataLen);
    dbgInfoEx("1 ucCeLLId=%d\n",sendData->stDa[1].ucCeLLId);
    dbgInfoEx("1 ucAcType=%d\n",sendData->stDa[1].ucAcType);
    dbgInfoEx("1 ucIterationNo=%d\n",sendData->stDa[1].ucIterationNo);
    dbgInfoEx("1 ucGroupNo=%d\n",sendData->stDa[1].ucGroupNo);
    dbgInfoEx("1 uwAntNo=%d\n",sendData->stDa[1].uwAntNo);
    dbgInfoEx("1 ComplexData[0]=%d\n",sendData->stDa[1].ComplexData[0].real);
    dbgInfoEx("1 ComplexData[1023]=%d\n",sendData->stDa[1].ComplexData[1023].real);
}

UINT32 GetDmaState(UINT32 acType, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 waitR8TimeCnt = 0;
    UINT32 uiAcType      = 0;

    if((JAC_ENABLE == GetJacMode()) && (JAC_SEND_DATA == GetJacType()))
    {
        return BSP_OK;
    }

    uiAcType = BspJudgeAcType(acType);
    //查询发数、采数、DMA搬数是否完成
    if(uiAcType == E_AC_TYPE_DL)
    {
        while((!(shareInfo->acDlDoneFlag))&&(waitR8TimeCnt < 3))
        {
            BspSysMsDelay(1000);
            waitR8TimeCnt++;
        }
        JudgeWaitR8TimeCnt(uiAcType,waitR8TimeCnt);
        recordWaitR8TimeCnt(uiAcType, waitR8TimeCnt);
        shareInfo->acDlDoneFlag = 0;
        AcFuncLog(AC_FUNC_LOG_HIGH, "DataSend dlDmaSta:ok, waitCnt:%d \n", waitR8TimeCnt);
    }
    else if(uiAcType == E_AC_TYPE_UL)
    {
        while((!(shareInfo->acUlDoneFlag))&&(waitR8TimeCnt < 3))
        {
            BspSysMsDelay(1000);
            waitR8TimeCnt++;
        }
        JudgeWaitR8TimeCnt(uiAcType,waitR8TimeCnt);
        recordWaitR8TimeCnt(uiAcType, waitR8TimeCnt);
        shareInfo->acUlDoneFlag = 0;
        AcFuncLog(AC_FUNC_LOG_HIGH, "DataSend ulDmaSta:ok, waitCnt:%d \n", waitR8TimeCnt);
    }
    if(checkWaitR8SmpOverTime(uiAcType,waitR8TimeCnt) != BSP_OK)
    {
        dbgErr("[%s] failed! R8 sample for AC overtime!\n",__FUNCTION__);
        AcFuncLog(AC_FUNC_LOG_HIGH, "DataSend dmaSta:overtime \n");
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspInitSendData(UINT32 acType, UINT32 carrNo, T_DpdMsgSendAcData_NEW_IC4 *sendData)
{
    zte_memset_s(sendData, sizeof(T_DpdMsgSendAcData_NEW_IC4), 0, sizeof(T_DpdMsgSendAcData_NEW_IC4));
    sendData->stDa[0].uwDataLen     = UDPMSG_HTONS((UINT16)4114);  //UDPMSG_HTONS(4114) T_DpdMsgSendAcData结构体的大小
    sendData->stDa[0].ucCeLLId      = (UINT8)carrNo;//小区索引，0：小区0,1：小区1
    sendData->stDa[0].ucAcType      = (UINT8)acType;//AC数据类型，0：下行，1：上行
    sendData->stDa[0].uwAntNo       = 0;     //天线号,0表示0天线
    sendData->stDa[0].ucDpdIcId     = (UINT8)BspGetRpuId(); //DPDIC_ID

    sendData->stDa[1].uwDataLen     = UDPMSG_HTONS((UINT16)4114);  //UDPMSG_HTONS(4114) T_DpdMsgSendAcData结构体的大小
    sendData->stDa[1].ucCeLLId      = (UINT8)carrNo;//小区索引，0：小区0,1：小区1
    sendData->stDa[1].ucAcType      = (UINT8)acType;//AC数据类型，0：下行，1：上行
    sendData->stDa[1].uwAntNo       = 0;     //天线号,0表示0天线
    sendData->stDa[1].ucDpdIcId     = (UINT8)BspGetRpuId(); //DPDIC_ID

    sendData->stDa[2].uwDataLen     = UDPMSG_HTONS((UINT16)4114);  //UDPMSG_HTONS(4114) T_DpdMsgSendAcData结构体的大小
    sendData->stDa[2].ucCeLLId      = (UINT8)carrNo;//小区索引，0：小区0,1：小区1
    sendData->stDa[2].ucAcType      = (UINT8)acType;//AC数据类型，0：下行，1：上行
    sendData->stDa[2].uwAntNo       = 0;     //天线号,0表示0天线
    sendData->stDa[2].ucDpdIcId     = (UINT8)BspGetRpuId(); //DPDIC_ID

    sendData->stDa[3].uwDataLen     = UDPMSG_HTONS((UINT16)4114);  //UDPMSG_HTONS(4114) T_DpdMsgSendAcData结构体的大小
    sendData->stDa[3].ucCeLLId      = (UINT8)carrNo;//小区索引，0：小区0,1：小区1
    sendData->stDa[3].ucAcType      = (UINT8)acType;//AC数据类型，0：下行，1：上行
    sendData->stDa[3].uwAntNo       = 0;     //天线号,0表示0天线
    sendData->stDa[3].ucDpdIcId     = (UINT8)BspGetRpuId(); //DPDIC_ID
    if((E_AC_TYPE_UL == acType) || (E_AC_TYPE_FDD_UL == acType))
    {
        //计数器，记录总的历史校正次数
        SendHaulBackAcSeqIcUlAcCnt++;
    }
    sendData->stDa[0].iCrc = SendHaulBackAcSeqIcUlAcCnt; //DPDIC_ID
    sendData->stDa[1].iCrc = SendHaulBackAcSeqIcUlAcCnt; //DPDIC_ID
    sendData->stDa[2].iCrc = SendHaulBackAcSeqIcUlAcCnt; //DPDIC_ID
    sendData->stDa[3].iCrc = SendHaulBackAcSeqIcUlAcCnt; //DPDIC_ID

    return BSP_OK;
}

UINT32 BspSetSendDataAntInfo(UINT32 uiAntNum, T_ICHAL_ACPARA* acPara, T_DpdMsgSendAcData_NEW_IC4 *sendData, UINT32 *sendNum)
{
    INPUT_POINTER_CHECK(acPara);
    INPUT_POINTER_CHECK(sendData);
    INPUT_POINTER_CHECK(sendNum);

    dbgInfo("[%s], in uiAntNum:%d\n", __FUNCTION__, uiAntNum);
    if(SCENE_RCUA_ON == acPara->uiRcuaScene)
    {
        uiAntNum = uiAntNum % 4;
    }
    sendData->stDa[*sendNum].uwAntNo = UDPMSG_HTONS((UINT16)uiAntNum);

    dbgInfo("[%s], out uiAntNum:%d\n", __FUNCTION__, uiAntNum);

    return BSP_OK;
}

UINT32 BspGetVgaData(UINT32 *sendNum, T_AcRetryInfo *ptAcRetryInfo, T_AcCarrInfo *ptAcCarrInfo, T_DpdMsgSendAcData_NEW_IC4 *sendData)
{
    UINT8*  baseAddr = 0;
    UINT32  antNoTmp = 0;
    UINT32  uiRpuId  = 0;
    UINT32  uiBandNo = 0;
    UINT32  uiBspChn = 0;
    UINT32 difChipId = 0;
    UINT32 uiDifChn  = 0;
    UINT32 uiAcType  = 0;
    UINT32 uiCarrNo  = 0;
    UINT32 uiRadioMode = 0;
    UINT32 uiRet     = 0;
    UINT32 uiRetry   = 0;
    UINT32 uiRound   = 0;
    UINT32 uiRoundTime = 0;
    INT32 iPreAtt    = 0;
    INT32 iVgaPreAtt = 0;
    INT32 iVgaValue  = 0;
    INT32 iVgaValueAdj = 0;
    INT32 iAcDspNcoValid = 0;
    INT32 iAcDspNco  = 0;
    INT32 iAcDspNcoAdj = 0;
    UINT32 uiSendAcRpuId = 0;
    UINT32 uiCatchAcRpuId = 0;
    UlAcVgaData *VgaData  = NULL;
    T_ICHAL_ACPARA *acPara  = NULL;
    A53R8AcDebugShareInfo* shareInfo = NULL;

    baseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(baseAddr);
    VgaData   = (UlAcVgaData *)((VOID *)(baseAddr + IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET));
    shareInfo = (A53R8AcDebugShareInfo*)(baseAddr + IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET);
    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);

    uiSendAcRpuId = shareInfo->sendAcRpuId;
    uiCatchAcRpuId = shareInfo->catchAcRpuId;

    uiAcType = BspJudgeAcType(ptAcCarrInfo->acType);
    uiCarrNo = ptAcCarrInfo->carrNo;
    uiRadioMode = ptAcCarrInfo->radioMode;

    uiRetry = ptAcRetryInfo->retry;
    uiRound = ptAcRetryInfo->round;
    uiRoundTime = ptAcRetryInfo->roundTime;

    uiBandNo = BspGetBandNo();
    uiRpuId  = BspGetRpuId();

    if(((E_AC_TYPE_FDD_UL == ptAcCarrInfo->acType) && (uiRpuId == uiSendAcRpuId))
      || ((E_AC_TYPE_FDD_DL == ptAcCarrInfo->acType) && (uiRpuId == uiCatchAcRpuId)))
    {
        iAcDspNcoValid = 0x80000000;
        iAcDspNco = acPara->pGetAcDspNco();
        iAcDspNcoAdj = ((iAcDspNco<<16) & 0x7fff0000);
    }

    if(E_AC_TYPE_UL == uiAcType)//上行AC
    {
        antNoTmp = BspGetAntNoByRoundInfo(uiRpuId, uiRound);
        dbgInfoEx("[%s] antNoTmp:%d\n", __FUNCTION__, antNoTmp);
        if(64 == antNoTmp)
        {
            dbgInfoEx("[%s] UL round:%d is not set\n", __FUNCTION__, uiRound);
            return BSP_ERROR;
        }
        uiRet = BspCheckJacBitMap(antNoTmp);
        RETURN_RESULT_CHECK_AC(uiRet);
        *sendNum = *sendNum % 4;
        uiRet = BspSetSendDataAntInfo(antNoTmp, acPara, sendData, sendNum);
        RETURN_RESULT_CHECK_AC(uiRet);
        //sendData->stDa[*sendNum].uwAntNo = UDPMSG_HTONS((UINT16)antNoTmp);
        antNoTmp = antNoTmp + 1; //对应map表中的天线号列，需要加1
        uiRet = BspGetBspChanByAntAndBandInfo(antNoTmp, uiBandNo, RX, &uiBspChn);
        RETURN_RESULT_CHECK_AC(uiRet);
        uiRet = BspGetDifInfoByBspChn(uiBspChn, RX, &difChipId, &uiDifChn);
        RETURN_RESULT_CHECK_AC(uiRet);
        dbgInfoEx("[%s] uiDifChn:%d, uiBspChn:%d \n", __FUNCTION__, uiDifChn, uiBspChn);
        uiRet = IcHalApiGetRxPcGain(uiDifChn, uiRadioMode, uiCarrNo, &iPreAtt);//iPreAtt获取到的值单位是0.01db
        RETURN_RESULT_CHECK_AC(uiRet);
        if(BSP_OK == IcHalApiGetRxVgaGain(uiDifChn, uiRadioMode, uiCarrNo, &iVgaPreAtt))
        {
            iVgaValue = (INT32)(VgaData->vga[uiRetry][uiRound]*5 + (iPreAtt/10) + (iVgaPreAtt/10)); //iScale即ATT单位是0.1dB
            iVgaValueAdj = iVgaValue & 0x0000ffff;
            dbgInfoEx("[%s]Agc Retry %2d,acType %d, Ant%2d, Carr%d, radioMode 0x%08X, iPreAtt %d, iVgaPreAtt %d, iVgaValue %d, vga:%d\n",
             __FUNCTION__, uiRetry, uiAcType, uiRound, uiCarrNo, uiRadioMode, iPreAtt, iVgaPreAtt, iVgaValue, VgaData->vga[uiRetry][uiRound]);
            AcFuncLog(AC_FUNC_LOG_HIGH, "DataSend retry:%d, ant:%d, pcGain:%d, vgaGain:%d, slicer:%d, vgaGainFinal:%d \n",
                                         uiRetry, uiRound, iPreAtt, iVgaPreAtt, VgaData->vga[uiRetry][uiRound], iVgaValue);
        }
        else
        {
            dbgErr("[%s]get vga comp error!\n", __FUNCTION__);
            return BSP_ERROR;
        }
    }
    else if(E_AC_TYPE_DL == uiAcType)
    {
        *sendNum = (uiRetry*uiRoundTime+uiRound)%4;
    }
    else
    {
        dbgErr("[%s] unknow ac type:%d \n", __FUNCTION__, uiAcType);
        return BSP_ERROR;
    }
    dbgInfoEx("sendData->stDa[%d].uwAntNo = %d, difChn=%d\n", *sendNum, sendData->stDa[*sendNum].uwAntNo, uiDifChn);
    sendData->stDa[*sendNum].iScale        = (iVgaValueAdj | iAcDspNcoAdj | iAcDspNcoValid);
    sendData->stDa[*sendNum].ucIterationNo = uiRetry; //迭代次数
    sendData->stDa[*sendNum].ucGroupNo     = uiRound; //组号，下行：0-8

    return BSP_OK;
}

UINT32 BspSetSendData(UINT32 uiAcType, UINT32 uiDataLen, UINT32 *sendNum, T_AcRetryInfo *ptAcRetryInfo, T_DpdMsgSendAcData_NEW_IC4 *sendData)
{
    UINT32 uiPoint   = 0;
    UINT8  *baseAddr = 0;
    UINT32 *pDlMemInfo = NULL;
    UINT32 *pUlMemInfo = NULL;
    UINT32 uiRound   = 0;
    UINT32 uiRoundTime = 0;
    UINT32 uiRetry   = 0;
    UINT32 uiRetryTime = 0;

    baseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(baseAddr);
    pDlMemInfo = (UINT32*)((VOID *)(baseAddr + IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET));
    pUlMemInfo = (UINT32*)((VOID *)(baseAddr + IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET));

    uiRetry = ptAcRetryInfo->retry;
    uiRound = ptAcRetryInfo->round;
    uiRoundTime = ptAcRetryInfo->roundTime;
    uiRetryTime = ptAcRetryInfo->retryTime;

    for(uiPoint = 0; uiPoint < uiDataLen; uiPoint++)
    {
        if((UDP_PACK_NUM <= *sendNum) || (IC_AC_POINT_NUM<= uiPoint))
        {
            dbgErr("[%s] out of range, sendNum:%d, point:%d\n", __FUNCTION__, *sendNum, uiPoint);
            return BSP_ERROR;
        }
        if(E_AC_TYPE_DL == uiAcType)//下行AC
        {
            sendData->stDa[*sendNum].ComplexData[uiPoint].real = (UINT16)(*(pDlMemInfo + uiRound*uiDataLen + uiRetry*uiDataLen*uiRoundTime + uiPoint) >> 16) & 0xFFFF;
            sendData->stDa[*sendNum].ComplexData[uiPoint].imag = (UINT16)(*(pDlMemInfo + uiRound*uiDataLen + uiRetry*uiDataLen*uiRoundTime + uiPoint) >> 0) & 0xFFFF;
        }
        else
        {
            sendData->stDa[*sendNum].ComplexData[uiPoint].real = (UINT16)(*(pUlMemInfo + uiRetry*uiDataLen + uiRound*IC_AC_POINT_NUM*uiRetryTime + uiPoint) >> 16) & 0xFFFF;
            sendData->stDa[*sendNum].ComplexData[uiPoint].imag = (UINT16)(*(pUlMemInfo + uiRetry*uiDataLen + uiRound*IC_AC_POINT_NUM*uiRetryTime + uiPoint) >> 0) & 0xFFFF;
        }
        dbgInfoEx("[%s]retry %2d, round %2d point %4d real 0x%04x, imag 0x%04x\n", \
                __FUNCTION__, uiRetry, uiRound, uiPoint, sendData->stDa[*sendNum].ComplexData[uiPoint].real, sendData->stDa[*sendNum].ComplexData[uiPoint].imag);
    }
    dbgInfoEx("[%s]retry %2d, round %2d, sendnum %2d, real 0x%04x, imag 0x%04x\n", \
             __FUNCTION__, uiRetry, uiRound, *sendNum, sendData->stDa[*sendNum].ComplexData[0].real, sendData->stDa[*sendNum].ComplexData[0].imag);
    AcFuncLog(AC_FUNC_LOG_HIGH, "DataSend retry:%d, round:%d, real:0x%04x, imag:0x%04x \n",
                                 uiRetry, uiRound, sendData->stDa[*sendNum].ComplexData[0].real, sendData->stDa[*sendNum].ComplexData[0].imag);

    return BSP_OK;
}

INT32 g_sendoffset = 100;

VOID BspSetSendDataOffset(UINT32 offset)
{
    g_sendoffset = offset;
}
UINT32 BspGetSendDataOffset(void)
{    
    return g_sendoffset;
}

UINT32 SendHaulBackAcSeqIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    UINT32               dataLen = 0;
    UINT32                 retry = 0;
    UINT32                 round = 0;
    UINT32             roundTime = 0;
    UINT32                retVal = 0;
    UINT32                errCnt = 0;
    UINT32               sendNum = 0;
    UINT32              totalNum = 0;
    UINT32              uiAcType = 0;
    UINT32        uiCatchAcRpuId = 0;
    UINT32               uiRpuId = 0;
    UINT32           uiRetryTime = 0;
    UINT32              uiBandNo = 0;
    UINT8*              baseAddr = 0;
    T_AcParaInfo      acParaInfo = {0};
    T_AcCarrInfo     tAcCarrInfo = {0};
    T_AcRetryInfo   tAcRetryInfo = {0};
    T_ICHAL_ACPARA*       acPara = NULL;
    A53R8AcDebugShareInfo* shareInfo = NULL;
    T_DpdMsgSendAcData_NEW_IC4* sendData  = NULL;

    if(BSP_RADIO_STANDARD_GSM == radioMode)
    {
        return BSP_OK;
    }

    //记录函数执行时间戳
    recordAcTickInfo(0,3,0);//SendHaulBackAcSeqIc 对应索引 3
    recordErsUpdateTime(acType,2);
    recordSendHaulBackAcCnt();

    
    dbgInfoEx("acType:%d,carrNo:%d,pasteCarrFlag:%d,deviate:%d,bandWidth:%d,sampleRate:%d,radioMode:%d\n",\
                acType,carrNo,pasteCarrFlag,deviate,bandWidth,sampleRate,radioMode);
    dbgInfo("[%s] IC real FrameNo:%d\n", __FUNCTION__, IcHalGetFrameNo());

    uiAcType = BspJudgeAcType(acType);
    uiRpuId = BspGetRpuId();
    uiBandNo = BspGetBandNo();

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    INPUT_POINTER_CHECK(acPara);
    baseAddr = BspGetAcMemBaseAddr();
    INPUT_POINTER_CHECK(baseAddr);

    if(uiAcType == E_AC_TYPE_UL)
    {
        BspSysMsDelay(g_sendoffset*BspGetRpuId()); 
    }

    shareInfo = (A53R8AcDebugShareInfo*)(baseAddr + IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET);
    uiCatchAcRpuId = shareInfo->catchAcRpuId;
    getAcInfo(uiAcType,carrNo,radioMode,uiBandNo);
    if((uiAcType == E_AC_TYPE_DL) && (uiCatchAcRpuId != uiRpuId))
    {
        dbgInfo("[%s] catch ant is not on this chip\n ", __FUNCTION__);
        return BSP_OK;
    }
    AcFuncLog(AC_FUNC_LOG_HIGH, "DataSend localFr:%d, socId:%d, acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, \n",
                                 IcHalGetFrameNo(), uiRpuId, acType, radioMode, bandWidth, carrNo);
    AcFuncDlpostPaptAlm();

    tAcCarrInfo.acType    = acType;
    tAcCarrInfo.bandWidth = bandWidth;
    tAcCarrInfo.carrNo    = carrNo;
    tAcCarrInfo.radioMode = radioMode;

    retVal = GetDmaState(acType, shareInfo);
    RETURN_RESULT_CHECK_AC(retVal);
    retVal = BspGetAcParaInfo(radioMode, pasteCarrFlag, bandWidth, &acParaInfo);
    RETURN_RESULT_CHECK_AC(retVal);

    dataLen = acParaInfo.acSeqLen;
    roundTime = (E_AC_TYPE_DL == uiAcType) ? acPara->acDlRoundNo : acPara->acUlRoundNo;
    uiRetryTime = acPara->insertTimes;
    dbgInfo("[%s] uiRetryTime:%d, roundTime:%d\n", __FUNCTION__, uiRetryTime, roundTime);

    sendData = (T_DpdMsgSendAcData_NEW_IC4*)malloc(sizeof(T_DpdMsgSendAcData_NEW_IC4));
    INPUT_POINTER_CHECK(sendData);

    retVal = BspInitSendData(acType, carrNo, sendData);
    RETURN_RESULT_CHECK_AC(retVal);

    for(retry = 0; retry < uiRetryTime; retry++)
    {
        for(round = 0; round < roundTime; round++)
        {
            tAcRetryInfo.retry = retry;
            tAcRetryInfo.retryTime = uiRetryTime;
            tAcRetryInfo.round = round;
            tAcRetryInfo.roundTime = roundTime;
            retVal = BspGetVgaData(&sendNum, &tAcRetryInfo, &tAcCarrInfo, sendData);
            RESULT_CHECK_CONTINUE_AC(retVal);
            retVal = BspSetSendData(uiAcType, dataLen, &sendNum, &tAcRetryInfo, sendData);
            RESULT_CHECK_CONTINUE_AC(retVal);
            //发送16*9或者16次，其中如果报错一次，可能要延时再发送(前期先不考虑特殊处理)
            if((((uiRpuId == uiCatchAcRpuId)&&(E_AC_TYPE_DL == uiAcType))||(E_AC_TYPE_UL == uiAcType))&&((sendNum%4 == 3)
              ||(retry*roundTime+round==(roundTime*uiRetryTime-1))))
            {
                errCnt |= (retVal = BspSendHaulBackAcDataIc4(sendData, acType));
                recordToDspPackets(uiAcType, retVal);
                totalNum++;
                dbgInfoEx("[%s]retryA %2d,roundTime %2d, roundA %2d, sendnumA %2d, realA 0x%04x, imagA 0x%04x\n", \
                          __FUNCTION__, retry, roundTime, round, sendNum, sendData->stDa[sendNum].ComplexData[0].real, sendData->stDa[sendNum].ComplexData[0].imag);
            }
            dbgInfoEx("[%s]AcType %d:retry %2d, round %2d, result 0x%08X\n", __FUNCTION__, acType, retry, round, retVal);
            if(E_AC_TYPE_UL == uiAcType)
            {
                dbgInfoEx("[%s] UL sendNum++ \n", __FUNCTION__);
                sendNum++;
            }
        }
    }
    dbgInfo("\n----------------total udp send num = %d\n",totalNum);
    free(sendData);

    dbgInfo("[%s]AcType %d, Send Finished, with retVal 0x%08X\n", __FUNCTION__, acType, errCnt);
    recordAcTickInfo(1,3,0);//SendHaulBackAcSeqIc 对应索引 3

    return errCnt;
}

//启动AC权值计算
UINT32 CalAcWgtIc(UINT32 acType, UINT32 carr,  UINT32 radioMode, UINT32 refChan)
{
    return BSP_ERROR;
}

//检查是否完成权值计算
UINT32 ChkAcWgtIc(UINT32 acType, UINT32 carr, UINT32 radioMode)
{
    return BSP_ERROR;
}

UINT32 GetAcWgtIc(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32* data, UINT32* trxLength, UINT32* prachRxLength)
{
    return BSP_OK;
}

UINT32 saveAcWgtFromNxp(UINT32* pBuf, UINT32 trxLength,  UINT32 prachRxLength,UINT32 pasteCarrFlag,UINT32 deviate,UINT32 bandWidth,UINT32 carrNo,UINT32 acType)
{
    UINT32 ret          = 0;
    UINT32 loop         = 0;
    UINT32 fRet         = 0;
    CHAR   bufName[64]  = {0};
    INT32  snpRet       = 0;
    UINT32 totalLength  = (trxLength + prachRxLength)/4;
    INPUT_POINTER_CHECK(pBuf);

    //coverity[cert_exp37_c_violation:SUPPRESS]
    snpRet = snprintf_s(bufName,sizeof(bufName),"%sAcWgtFromNxp_Carr%d_Type%d.txt", BspGetLogPath(), carrNo,acType);
    SNPRINTF_S_CHECK(snpRet, sizeof(bufName));
    //coverity[cert_exp37_c_violation:SUPPRESS]
    //coverity[cert_fio32_c_violation:SUPPRESS]
    FILE*  fp     = fopen(bufName, "w+");
    if(fp == NULL)
    {
        return BSP_ERROR;
    }
    for(loop = 0;loop < totalLength;loop++)
    {
        if(0 > fprintf(fp,"0x%08x\n",pBuf[loop]))
        {
            dbgErr("saveAcWgtFromNxp sprintf err\n");
        }
    }
    fRet = fclose(fp);
    FCLOSE_CHECK(fRet);
    acprintf("\n**** see file AcWgtFromNxp.txt ****\n\n");
    return ret;
}

/* AAC维测接口 */
static UINT32 DbgSaveAbnormalAacPara(UINT32 logicCarrNo, UINT32 radioMode, UINT32 bitAntMap, UINT32 *pAacWgtData, UINT32 aacWgtLength)
{
    UINT32 bspChan = 0;
    UINT32 validChanNum = aacWgtLength / sizeof(UINT32);
    UINT32 chanNum = BspGetTxChanNum();

    INPUT_POINTER_CHECK(pAacWgtData);

    s_errAacNum = (s_errAacNum % BSP_MAX_CARR_NUM);

    if (validChanNum > IC42_MAX_CHAN_NUM)
    {
        dbgErr("%s: validChanNum(%d) error!!\n", __FUNCTION__, validChanNum);
        return BSP_ERROR;
    }

    s_dbgAacWgtDataPara[s_errAacNum].logicCarrNo = logicCarrNo;
    s_dbgAacWgtDataPara[s_errAacNum].radioMode = radioMode;
    s_dbgAacWgtDataPara[s_errAacNum].aacWgtLength = aacWgtLength;
    s_dbgAacWgtDataPara[s_errAacNum].aacInitiateNum = s_aacInitiateNum;

    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        if((BIT_SET(bspChan) & bitAntMap) != 0)
        {
            s_dbgAacWgtDataPara[s_errAacNum].aacErrWgtbak[bspChan] = pAacWgtData[bspChan];
        }

    }
    s_errAacNum++;

    return BSP_OK;
}

static VOID dbgshowerraacpara(VOID)
{
    UINT32 loop = 0;
    UINT32 wgtIndex = 0;

    for (loop = 0; loop < BSP_MAX_CARR_NUM; loop++)
    {
        if (s_dbgAacWgtDataPara[loop].radioMode == 0)
        {
            break;
        }
        dbgInfo("logicCarrNo:%d, radioMode:%d, aacWgtLength:%d, aacInitiateNum:%d\n",
                s_dbgAacWgtDataPara[loop].logicCarrNo,
                s_dbgAacWgtDataPara[loop].radioMode,
                s_dbgAacWgtDataPara[loop].aacWgtLength,
                s_dbgAacWgtDataPara[loop].aacInitiateNum);
        dbgInfo("AAC Wgt:\n");

        for (wgtIndex = 0; wgtIndex < IC42_MAX_CHAN_NUM; wgtIndex++)
        {
            dbgInfo("0x%x ,",s_dbgAacWgtDataPara[loop].aacErrWgtbak[wgtIndex]);
        }
        dbgInfo("\n");
    }
    return;
}

static VOID dbgsetaacwgt(UINT32 bspChan, UINT32 aacWgt)
{
    if(bspChan < IC42_MAX_CHAN_NUM)
    {
        s_testAacWgt[bspChan] = aacWgt;
        return ;
    }
    dbgErr("bspChan is Error!!\n");

    return ;
}

static UINT32 dbgtestaacwgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 antBitMap,  UINT32 length)
{
    return SetAacWgtIc(logicCarrNo,  radioMode, acType, antBitMap, s_testAacWgt, length);
}

static UINT32 dbgshowacwgt(UINT32 radioMode, UINT32 logicCarrNo)
{
    UINT32 index = 0;
    UINT32 loop = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        if ((s_wgtBakDataPara[index].carrNo == logicCarrNo) && (s_wgtBakDataPara[index].radioMode == radioMode))
        {
            for(loop = 0; loop < IC42_MAX_CHAN_NUM; loop++)
            {
                dbgInfo("0x%x, ",s_wgtBakDataPara[index].aacWgtbak[loop]);
            }
            dbgInfo("\n carrNo:%d\n", s_wgtBakDataPara[index].carrNo);
            dbgInfo("\n radioMode:%d\n", s_wgtBakDataPara[index].radioMode);
            dbgInfo("\n dlAcWgtLength:%d\n", s_wgtBakDataPara[index].dlAcWgtLength);
            dbgInfo("\n bitAntMap:%d\n", s_wgtBakDataPara[index].bitAntMap);
            dbgInfo("\n aacWgtLength:%d\n",s_wgtBakDataPara[index].aacWgtLength);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

UINT32 BspGetChanNumByAntMap(UINT32 bitAntMap)
{
    UINT32 bspChan = 0;
    UINT32 chanNum = 0;

    for (bspChan = 0; bspChan < BspGetTxChanNum(); bspChan++)
    {
        if((BIT_SET(bspChan) & bitAntMap) != 0)
        {
            chanNum++;
        }
    }

    return chanNum;
}

static UINT32 GetSaveWgtIndex(UINT32 logicCarrNo, UINT32 radioMode)
{
    UINT32 index = 0;
    UINT32 carrIndex = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        if ((s_wgtBakDataPara[index].carrNo == logicCarrNo) && (s_wgtBakDataPara[index].radioMode == radioMode))
        {
            carrIndex = index;
            return carrIndex;
        }
    }

    if(index >= NELEMENTS(s_wgtBakDataPara))
    {
        for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
        {
            if ((0 == s_wgtBakDataPara[index].carrNo) && (0 == s_wgtBakDataPara[index].radioMode))
            {
                carrIndex = index;
                return carrIndex;
            }
        }
    }

    return index;
}

UINT32 BspGetAcWgtRbNum(UINT32 radioMode,UINT32 bandWidth,UINT32 pasteCarrFlag)
{
    UINT32 loop = 0;
    UINT32 num  = 0;
    UINT32 acWidth = 0;
    UINT32 retVal = BSP_ERROR;

    num = (sizeof(g_acWgtInfo) / sizeof(g_acWgtInfo[0]));
    for(loop = 0; loop < num; loop++)
    {
        if((g_acWgtInfo[loop].radioMode == radioMode) && (g_acWgtInfo[loop].bandWidth == bandWidth))
        {
            acWidth = g_acWgtInfo[loop].rbNum;
            retVal = BSP_OK;
        }
    }

    dbgInfoEx("%s:radioMode= %#x,bandWidth=%d,acWidth=%d\n",__FUNCTION__,radioMode,bandWidth,acWidth);
    if(BSP_OK == retVal)
    {
        return acWidth;
    }

    return BSP_ERROR;
}

static UINT32 GetAcWgtLength(UINT32 logicCarrNo, UINT32 radioMode, UINT32 antBitMap, UINT32 *pacWgtLength)
{
    T_RruRfCfgInfo rruCfgPara = {0};
    UINT32 carrLoop = 0;
    UINT32 bspChan = 0;
    UINT32 bandWidth = 0;
    UINT32 rbNum = 0;
    UINT32 validChanNum = BspGetChanNumByAntMap(antBitMap);

    INPUT_POINTER_CHECK(pacWgtLength);

    for (bspChan = 0; bspChan < BspGetTxChanNum(); bspChan++)
    {
        if((BIT_SET(bspChan) & antBitMap) != 0)
        {
            BspGetChnlCfgCarrPara(bspChan, &rruCfgPara);
            break;
        }
    }

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
    {
        if ((rruCfgPara.carr[carrLoop].carrTxNo == logicCarrNo) && (rruCfgPara.carr[carrLoop].carrTxRadio == radioMode))
        {
            bandWidth = rruCfgPara.carr[carrLoop].carrTxBw / 1000; /* 带宽单位转换 */
            rbNum = BspGetAcWgtRbNum(radioMode, bandWidth, 0);
            if(BSP_ERROR == rbNum)
            {
                return BSP_ERROR;
            }
            *pacWgtLength = rbNum * validChanNum * sizeof(UINT32);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

static UINT32 CalcUpdateAcWgt(UINT32 carrIndex, UINT32 antBitMap, UINT32 *pUpdataWgt, UINT32 updataWgtLength)
{
    UINT32 bspChan = 0;
    UINT32 validChan = 0;
    UINT32 rbIndex = 0;
    UINT32 rbNum = 0;
    UINT32 acWgtIndex[2] = {0};
    UINT32 validChanNum = BspGetChanNumByAntMap(antBitMap);
    T_AcWgtComplexData acData = {0};
    T_AcWgtComplexData aacData = {0};
    T_AcWgtComplexData wgtNew = {0};

    INPUT_POINTER_CHECK(pUpdataWgt);

    if (updataWgtLength < s_wgtBakDataPara[carrIndex].dlAcWgtLength)
    {
        dbgErr("%s: carrIndex:%d,antBitMap:%d,WgtLength=%d,AcWgtLength=%d, Failed!!\n", __FUNCTION__, carrIndex, antBitMap, updataWgtLength, s_wgtBakDataPara[carrIndex].dlAcWgtLength);
        return BSP_ERROR;
    }
    if (0 != validChanNum)
    {
        rbNum = s_wgtBakDataPara[carrIndex].dlAcWgtLength / validChanNum / sizeof(UINT32);
    }

    for(bspChan = 0; bspChan < BspGetTxChanNum(); bspChan++)
    {
        if((BIT_SET(bspChan) & antBitMap) != 0)
        {
            aacData.real = s_wgtBakDataPara[carrIndex].aacWgtbak[bspChan] >> 16;
            aacData.imag = s_wgtBakDataPara[carrIndex].aacWgtbak[bspChan] & 0xFFFF;

            for (rbIndex = 0; rbIndex < rbNum; rbIndex++)
            {
                acWgtIndex[0] = bspChan * rbNum + rbIndex;
                acWgtIndex[1] = validChan * rbNum + rbIndex;
                acData.real = s_wgtBakDataPara[carrIndex].dlAcWgtbak[acWgtIndex[0]] >> 16;
                acData.imag = s_wgtBakDataPara[carrIndex].dlAcWgtbak[acWgtIndex[0]] & 0xFFFF;

                BspGetWgtByCmplNumMult(&acData, &aacData, &wgtNew);

                pUpdataWgt[acWgtIndex[1]] = ((((INT16)(wgtNew.real)) << 16) & 0xFFFF0000) | ((INT16)(wgtNew.imag) & 0xFFFF);
                dbgInfoEx("aacData.real: %d,aacData.imag:%d,acData.real: %d,acData.imag:%d,wgtNew.real: %d,wgtNew.imag:%d,pUpdataWgt:0x%x\n",
                                aacData.real, aacData.imag, acData.real, acData.imag, wgtNew.real, wgtNew.imag, pUpdataWgt[acWgtIndex[1]]);
            }

            validChan++;
        }
    }

    return BSP_OK;
}

static UINT32 UpdateAcWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pUpdataWgt, UINT32 updataWgtLength, UINT32 *pAcWgtLength)
{
    UINT32 carrIndex = 0;
    UINT32 acWgtLength = 0;
    UINT32 antBitMap = 0;

    INPUT_POINTER_CHECK(pUpdataWgt);
    INPUT_POINTER_CHECK(pAcWgtLength);

    carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    if (carrIndex >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }

    antBitMap = s_wgtBakDataPara[carrIndex].bitAntMap;

    if (0 == s_wgtBakDataPara[carrIndex].dlAcWgtLength)
    {
        if (GetAcWgtLength(logicCarrNo, radioMode, antBitMap, &acWgtLength) != BSP_OK)
        {
            return BSP_ERROR;
        }
        s_wgtBakDataPara[carrIndex].dlAcWgtLength = acWgtLength;
    }

    *pAcWgtLength = s_wgtBakDataPara[carrIndex].dlAcWgtLength;

    CalcUpdateAcWgt(carrIndex, antBitMap, pUpdataWgt, updataWgtLength);

    return BSP_OK;
}

static UINT32 SaveLatestDlAcWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 *pAcWgtData, UINT32 acWgtLength)
{
    UINT32 wgtLoop = 0;
    UINT32 carrIndex = 0;
    UINT32 acWgtLengthTmp = acWgtLength / sizeof(UINT32);
    UINT32 chanNum = BspGetTxChanNum();

    INPUT_POINTER_CHECK(pAcWgtData);

    carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);

    if ((acWgtLengthTmp > AC_MAX_RB_NUM * chanNum) || (carrIndex >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }

    s_wgtBakDataPara[carrIndex].carrNo = logicCarrNo;
    s_wgtBakDataPara[carrIndex].radioMode = radioMode;
    s_wgtBakDataPara[carrIndex].dlAcWgtLength = acWgtLength;

    for (wgtLoop = 0; wgtLoop < acWgtLengthTmp; wgtLoop++)
    {
        s_wgtBakDataPara[carrIndex].dlAcWgtbak[wgtLoop] = pAcWgtData[wgtLoop];
    }

    return BSP_OK;
}

//设置AC权值
UINT32 SetAcWgtIc(UINT32 carrNo,UINT32 pasteCarrFlag,\
UINT32 deviate,UINT32 bandWidth,UINT32 sampleRate,UINT32 radioMode,\
UINT32 actype, UINT32* pBuf, UINT32 trxLength,  UINT32 prachRxLength)
{
    UINT32 uiRet            = 0;
    UINT32 uiTrxType        = 0;
    UINT32 uiAcType         = 0;
    UINT32 *pWgtData        = NULL;
    UINT32 *pPrachWgtData   = NULL;
    UINT32 uiWgtByteLen     = trxLength;
    UINT32 uiWgtDataLen     = trxLength/4;
    UINT32 uiPrachDataLen   = prachRxLength/4;
    T_JAC_TA_PARA tJacTapara = {0};
    UINT32 acWgtLength      = 0;
    UINT32 uiAntBitmap      = 0;
    UINT32 uiJacMode        = 0;
    T_AcParaInfo tAcParaInfo = {0};

    recordSetAcWgtIcCnt();
    pWgtData      = pBuf;
    pPrachWgtData = pBuf + uiWgtDataLen;
    dbgInfo("[%s]carrNo:%d,actype:%d,trxLength:%d,prachRxLength:%d\n",__FUNCTION__,carrNo,actype,trxLength,prachRxLength);
    
    dbgInfo("[%s] IC real FrameNo:%d\n", __FUNCTION__, IcHalGetFrameNo());
    INPUT_POINTER_CHECK(pWgtData);
    saveAcWgtFromNxp(pWgtData,trxLength,prachRxLength,pasteCarrFlag, deviate, bandWidth, carrNo, actype);
    AcFuncLog(AC_FUNC_LOG_HIGH, "WgtCfg acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, wgtLen:%d, prachWgtLen:%d \n",
                                 actype, radioMode, bandWidth, carrNo, uiWgtDataLen, uiPrachDataLen);

    if((BSP_RADIO_STANDARD_UMTS == radioMode) || (AC_ALG_TIME_ON == BspGetAcAlgTimeSw()) || ((BSP_RADIO_STANDARD_GSM == radioMode)) )
    {
        uiRet = BspGetAcParaInfo(radioMode, pasteCarrFlag, bandWidth, &tAcParaInfo);
        RETURN_RESULT_CHECK_AC(uiRet);
        uiRet = BspSetAlgTimePhaAndGain(actype, carrNo, radioMode, pBuf, &tAcParaInfo);
        RETURN_RESULT_CHECK_AC(uiRet);

        return BSP_OK;
    }

    uiAcType = BspJudgeAcType(actype);
    uiJacMode = GetJacMode();
    dbgInfo("[%s] uiJacMode:%d \n", __FUNCTION__, uiJacMode);

    uiTrxType = (0 == uiAcType)?1:0;//底层接口０代表上行，与AC相反；

    if(E_AC_TYPE_DL == uiAcType)
    {
        uiPrachDataLen = 0;//下行AC时prach权值不应该被设置
    }
    dbgInfo("[%s], uiWgtByteLen:%d, uiWgtDataLen:%d, uiPrachDataLen:%d \n",
            __FUNCTION__, uiWgtByteLen, uiWgtDataLen, uiPrachDataLen);
    uiAntBitmap = BspGetWgtBitmap(uiAcType);
    dbgInfoEx("[%s] uiDir:%d, uiAntBitmap:0x%08X\n", __FUNCTION__, uiTrxType, uiAntBitmap);

    if(JAC_ENABLE == uiJacMode)
    {
        tJacTapara.uiJacType = actype;
        tJacTapara.uiCarrId = carrNo;
        tJacTapara.uiRadioMode = radioMode;
        tJacTapara.uiBandWidth = bandWidth;
        tJacTapara.uiPasteCarrFlag = pasteCarrFlag;
        tJacTapara.uiAntBitmap = uiAntBitmap;
        uiRet = BspGetAcParaInfo(radioMode, pasteCarrFlag, bandWidth, &tAcParaInfo);
        RETURN_RESULT_CHECK_AC(uiRet);
        tJacTapara.uiSampleRate = tAcParaInfo.sample;

        uiRet = BspProcJacTaDelay(&tJacTapara, &uiWgtByteLen, &uiWgtDataLen, pWgtData, trxLength);
        RETURN_RESULT_CHECK(uiRet);
    }

    if ((E_AC_TYPE_FDD_DL == actype) && (s_IsSupportAac == SUPPORT))
    {
        SaveLatestDlAcWgt(carrNo, radioMode, pBuf, uiWgtByteLen);
        UpdateAcWgt(carrNo, radioMode, pBuf, uiWgtByteLen, &acWgtLength);
    }
    uiRet = IcHalApiUpdataAcWgt(carrNo, uiTrxType, radioMode, pWgtData, uiWgtDataLen, pPrachWgtData, uiPrachDataLen, uiAntBitmap);


    return uiRet;
}

UINT32 g_antNum = 2;

VOID setAntNum(UINT32 num)
{
    g_antNum =  num;
}

//acType = 0是下行AC, acType = 1是上行AC
VOID testSetAcWgtIc(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype)
{
    UINT32* pBuf         = 0;
    UINT32 trxLength     = 0;//频域权的长度，上下行AC都有频域权
    UINT32 prachRxLength = 0;//时域权的长度，只有上行AC才有时域权
    UINT32 loop          = 0;
    UINT8* pdata         = 0;
    UINT32 wgtRbNum      = 0;
    UINT32 uiIcMaxAntNo  = 0;
    UINT32 uiDataLength  = 0;

    uiIcMaxAntNo = g_antNum;

    switch(bandWidth)
    {
        case BANDWIDTH_40M_MHz:
        {
            wgtRbNum = 216;
            break;
        }
        case BANDWIDTH_60M_MHz:
        {
            wgtRbNum = 162;
            break;
        }
        case BANDWIDTH_25M_MHz:
        {
            if (radioMode == 0x4000)
            {
                wgtRbNum = 133;
            }
            break;
        }
        case BANDWIDTH_20M_MHz:
        {
            if (radioMode == 0x2000)
            {
                wgtRbNum = 51;
            }
            else
            {
                wgtRbNum = 100;
            }
            break;
        }
        default:
            break;
    }
    //下行AC权值数据量:只有频域权，整板的数据量为64个天线*273个RB*4个字节bytes
    //每个IC只获得32个天线*273个RB*4个字节bytes
    if(0 == actype)//下行AC
    {
        trxLength     = uiIcMaxAntNo * wgtRbNum * 4;//字节长度
        prachRxLength = 0;

    }
    //上行AC权值数据量:频域权+时域权，频域权同下行AC，
    //即频域权: 每个IC分到32个天线*273个RB*4个字节bytes时域权: 整板64天线*4个字节，即每个IC分到32个天线*4字节
    if(1 == actype)//上行AC
    {
        trxLength     = uiIcMaxAntNo * wgtRbNum * 4;//字节长度
        prachRxLength = uiIcMaxAntNo*4;//字节长度
    }
    uiDataLength = trxLength + prachRxLength;

    if(NULL == (pBuf = malloc(uiDataLength)))
    {
        dbgErr("malloc error\n");
        return;
    }

    memset((VOID*)pBuf, 0, uiDataLength);
    pdata = (UINT8*)pBuf;
    for(loop = 0; loop < uiDataLength; loop++)
    {
        pdata[loop] = loop % 0xFF;
    }

    SetAcWgtIc(carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, pBuf, trxLength, prachRxLength);
    free(pBuf);
}
/**************************************************************************
 * 函数名称: BspWriteTxAcMsg
 * 功能描述:将oam传下来的信令消息写入共享内存
 * 输入参数: ucmode=0,   tx message;  ucmode = 1, rx message
                            pdata : 传入数据地址
                            uLength:传入数据长度
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                   牛彦茹    创建
 **************************************************************************/
UINT32 WriteAcMsg(UINT8 mode, UINT8 *pdata, UINT32 length)
{
    return BSP_OK;
}

UINT32 GetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    return BSP_OK;
}

UINT32 sendRecvAcSeqData(UINT32 acType, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 RpuId = 0;

    RpuId = BspGetRpuId();
    //初始化
    if(acType == E_AC_TYPE_FDD_DL)
    {
        //下行配置
        IcHalDlSetUlBankCatchRamRoundCfg(RpuId,shareInfo);
        testDlAcSeqIc();
    }
    else if(acType == E_AC_TYPE_FDD_UL)
    {
        IcHalUlSetUlBankCatchRamRoundCfg(RpuId,shareInfo);
        testUlAcSeqIc();
    }
    else
    {
        //doNothing
    }

    return BSP_OK;
}

UINT32 GetULACIntBankNo(UINT32 icNo, UINT32 bitMap, UINT32 *bankNo)
{
    UINT32 uiTxChnNum       = 0;
    UINT32 uiBspChan        = 0;
    UINT32 uiBankSelectFlag = 0;

    uiTxChnNum = BspGetAntNum();

    for(uiBspChan=0; uiBspChan<uiTxChnNum; uiBspChan++)
    {
        uiBankSelectFlag = BIT_VAL(bitMap, uiBspChan);
        if(1 == uiBankSelectFlag)
        {
            *bankNo = ulAcBlockBankBandInfo[icNo].bBInfo[0].dlBank[uiBspChan] ;
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

UINT32 UpdateShareAcSeqStartFrameNo(UINT32 frameNo, UINT32 acType, UINT32 bitMap)
{
    UINT32 uiRealFrNo        = 0;
    UINT8* baseAddr          = NULL;
    UINT32 uiAntNum          = 0;
    UINT32 uiMaxAntNum       = 0;
    UINT32 uiBankSelectFlag  = 0;
    UINT32 uiIcNum           = 0;
    UINT32 uiRound           = 0;
    UINT32 uiAcType          = 0;
    //UINT32 uiDifChn          = 0;
    A53R8AcDebugShareInfo* shareInfo = NULL;
    T_ICHAL_ACPARA* acPara           = NULL;


    dbgInfo("**************Master deliver frameNo = %d****************\n", frameNo);

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    uiAcType = BspJudgeAcType(acType);
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + baseAddr);

    uiMaxAntNum = shareInfo->icMaxAntNo;
    uiIcNum = BspGetRpuId();

    //根据机型进行bitmap图调整
	acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
	acPara->pAntBitToChanBit(&bitMap);
	if(SCENE_RCUA_ON == acPara->uiRcuaScene)
	{
	    for(uiAntNum = 0; uiAntNum < uiMaxAntNum;uiAntNum++)
	    {
	        VAR_BIT_SET(bitMap, uiAntNum);
	    }
	}

    if(E_AC_TYPE_FDD_DL == acType)
    {
        shareInfo->dlBitMap = 0;
        for(uiAntNum=0; uiAntNum<uiMaxAntNum; uiAntNum++)
        {
            uiBankSelectFlag = BIT_VAL(bitMap, uiAntNum);
            INPUT_AC_PARAMETER_CHECK(uiIcNum, AC_IC_NUM);
            INPUT_AC_PARAMETER_CHECK(uiRound, AC_ROUND_NUM);
            INPUT_AC_PARAMETER_CHECK(uiAntNum, AC_DL_ANTS_NUM);
            if((uiBankSelectFlag) && (dlAcBlockBankBandInfo[uiIcNum].bBInfo[uiRound].dlIsSet[uiAntNum] == 1))
            {
                //uiDifChn = dlAcBlockBankBandInfo[uiIcNum].bBInfo[uiRound].dlDifChn[uiAntNum];
                VAR_BIT_SET(shareInfo->dlBitMap, uiAntNum);
            }
        }
        ///设置上行bitmap图
        shareInfo->ulBitMap = 0xffffffff;
        dbgInfo("%s DL bitMap = %d, shareInfo->dlBitMap = 0x%08X \n", __FUNCTION__, bitMap, shareInfo->dlBitMap);
    }
    else if(E_AC_TYPE_FDD_UL == acType)
    {
        shareInfo->ulBitMap = 0;
        for(uiAntNum=0; uiAntNum<uiMaxAntNum; uiAntNum++)
        {
            uiBankSelectFlag = BIT_VAL(bitMap, uiAntNum);
            INPUT_AC_PARAMETER_CHECK(uiIcNum, AC_IC_NUM);
            INPUT_AC_PARAMETER_CHECK(uiRound, 1);
            INPUT_AC_PARAMETER_CHECK(uiAntNum, AC_UL_ANTS_NUM);
            if((uiBankSelectFlag) && (ulAcBlockBankBandInfo[uiIcNum].bBInfo[uiRound].ulIsSet[uiAntNum] == 1))
            {
                //uiDifChn = ulAcBlockBankBandInfo[uiIcNum].bBInfo[uiRound].ulDifChn[uiAntNum];
                VAR_BIT_SET(shareInfo->ulBitMap, uiAntNum);
            }
        }
        ///设置下行bitmap图
        shareInfo->dlBitMap = 0xffffffff;
        dbgInfo("%s UL bitMap = %d, shareInfo->ulBitMap = 0x%08X \n", __FUNCTION__, bitMap, shareInfo->ulBitMap);
    }
    else
    {
        dbgErr("%s actype error \n",__FUNCTION__);
        return BSP_ERROR;
    }
    uiRealFrNo = IcHalGetFrameNo();
    RecordR8AcSeqStartFrameNo(uiAcType, bitMap, uiRealFrNo);
    dbgInfo("\n\nShareInfoAddr = %p, frameNo %d, Tdd shareInfo->acSeqStartFrameNo = %d, /FDD startframeNo:%d, stopframeNo:%d \n\n",\
            shareInfo, frameNo, shareInfo->acSeqStartFrameNo, shareInfo->startframeNo, shareInfo->stopframeNo);
    dbgInfo("\n%s ***************DPDIC Real  FrameNo  %d ***************\n",__FUNCTION__, uiRealFrNo);

    //在这里完成AC序列的发送和回收
    sendRecvAcSeqData(acType, shareInfo);

    return BSP_OK;
}

UINT32 bspGetAcWgtOptBitmap(UINT32 bitMap)
{
    UINT32 tmpBitmap  = bitMap;
    return tmpBitmap;
}

UINT32 SetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32 syncTime,UINT32 bitMap)
{
    UINT32 uiAcType      = 0;

    //记录函数执行时间戳
    recordAcTickInfo(0,2,0);//SetAcSyncTime 对应索引 2
    dbgInfo("[%s] IC real FrameNo:%d\n", __FUNCTION__, IcHalGetFrameNo());
    dbgInfoEx("[%s](in): acType:%d,syncType:%d,syncTime:%d,bitMap:%d\n",__FUNCTION__,acType,syncType,syncTime,bitMap);

    s_wgtUpdateBitMap = bspGetAcWgtOptBitmap(bitMap);

    uiAcType = BspJudgeAcType(acType);
    if(uiAcType <= 1)
    {
        acBitmap[uiAcType] = bitMap;
    }
    dbgInfo("\n-----bitmap = %d------\n",s_wgtUpdateBitMap);

    if(0 == syncType)//更新AC序列生效的时刻，syncTime即psync的帧号，传给KO的共享内存
    {
        RecordSetAcSyncTimeCnt(syncTime);
        AcFuncLog(AC_FUNC_LOG_HIGH, "SyncCfg acType:%d, localFr:%d, appBitmap:0x%08x \n", acType, IcHalGetFrameNo(), bitMap);
        UpdateShareAcSeqStartFrameNo(syncTime, acType, bitMap);
    }

    recordAcTickInfo(1,2,0);//SetAcSyncTime 对应索引 2

    return BSP_OK;
}

UINT32 BspGetAcSlotNum(UINT32 radioMode, T_ICHAL_ACPARA* acPara, A53R8AcDebugShareInfo* shareInfo, UINT32 slotNo, UINT32 subframeNo)
{
    INPUT_POINTER_CHECK(acPara);
    INPUT_POINTER_CHECK(shareInfo);

    switch(radioMode)
    {
        case BSP_RADIO_STANDARD_FDD_5G:
        {
            shareInfo->acSlotNum     = slotNo;
            shareInfo->acInsertTimes = acPara->insertTimes;
            break;
        }
        case BSP_RADIO_STANDARD_LTE_FDD:
        {
            shareInfo->acSlotNum     = subframeNo;
            shareInfo->acInsertTimes = acPara->insertTimes;
            break;
        }
        case BSP_RADIO_STANDARD_UMTS:
        {
            shareInfo->acSlotNum     = 1;
            shareInfo->acInsertTimes = acPara->uiUmtsInsertTimes;
            break;
        }
        default:
        {
            dbgInfo("[%s], unsupport radioMode:%d \n", __FUNCTION__, radioMode);
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspGetMgcAttCtrlInfo(UINT32 uiAcType, T_ICHAL_ACPARA* ptAcPara ,A53R8AcDebugShareInfo* ptShareInfo)
{
    UINT32 uiRet         = 0;
    UINT32 uiUlchBandNum = 0;
    UINT32 uiDifChan     = 0;
    UINT32 auiUlchPort[UL_CH_FREQ_NUM_IN_BLOCK] = {0};
    UINT32 uiAcCatchChn  = 0;

    INPUT_POINTER_CHECK(ptAcPara);
    INPUT_POINTER_CHECK(ptShareInfo);

    if((uiAcType != E_AC_TYPE_FDD_DL) || (ptAcPara->uiAttCtrlIc != MGC_ATT_CTRL_ON))
    {
        dbgInfo("[%s], No need MGC att Ctrl\n", __FUNCTION__);
        ptShareInfo->uiMgcAttCtrlSw = 0;
        return BSP_OK;
    }
    if(BspGetBandCatchChipId() != BspGetRpuId())
    {
        dbgInfo("[%s], MGC att Ctrl not on this chip", __FUNCTION__);
        return BSP_OK;
    }

    uiAcCatchChn = BspGetBandCatchChn();
    uiRet = BspGetDifChnbyAntNum(uiAcCatchChn, BspGetBandNo(), RX, &uiDifChan);
    RETURN_RESULT_CHECK(uiRet);
    dbgInfo("[%s], uiAcCatchChn:%d, uiDifChan:%d \n", __FUNCTION__, uiAcCatchChn, uiDifChan);

    HAL_INPUT_NUMBER_OF_THRESHOLD_CHECK(uiDifChan, IC_CHAN_MAX_NUM);
    uiRet = IcHalGetUlchRouterOutIdByDifChan(uiDifChan, auiUlchPort, &uiUlchBandNum);        // 通过中频通道号查找对应的Ulch通道号
    RETURN_RESULT_CHECK(uiRet);

    ptShareInfo->uiMgcAttCtrlSw = ptAcPara->uiAttCtrlIc;
    ptShareInfo->uiMgcCtrlAttValue = ptAcPara->uiAttValue;
    ptShareInfo->uiMgcCtrlDifChn = uiDifChan;
    ptShareInfo->uiUlchBandNum  = uiUlchBandNum;
    zte_memcpy_s((VOID *)ptShareInfo->auiUlchPort, sizeof(ptShareInfo->auiUlchPort), (VOID *)auiUlchPort, sizeof(auiUlchPort));

    return BSP_OK;
}

INT32 ioFrOffset = 0;

VOID setIoFrOffset(INT32 offset)
{
    ioFrOffset = offset;
}

UINT32 IcHalSetInfoToDdrForKo(UINT32 acType, T_ICHAL_ACPARA* acPara ,A53R8AcDebugShareInfo* shareInfo,UINT32 radioMode,UINT32 acSeqLen,UINT32 uCarrNo, UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo)
{
    UINT32 uiFrameType         = 0;
    UINT32 uiAcInsertPos       = 0;
    UINT32 uiStartFrameNo      = 0;
    UINT32 uiStopFrameNo       = 0;
    UINT32 uiRet               = 0;

    uiAcInsertPos  = GetAcInsertPos();
    //根据小区配置帧结构
    uiFrameType = IcHalGetFrameTypeForAc(uCarrNo,radioMode);
    uiStartFrameNo = (frameNo + AC_MAX_FRAME_NO - 2) % (AC_MAX_FRAME_NO + 1);
    uiStopFrameNo = (frameNo + AC_MAX_FRAME_NO + 3) % (AC_MAX_FRAME_NO + 1);

    uiRet = BspGetAcSlotNum(radioMode, acPara, shareInfo, slotNo, subframeNo);
    RETURN_RESULT_CHECK(uiRet);


    uiRet = BspGetMgcAttCtrlInfo(acType, acPara, shareInfo);
    RETURN_RESULT_CHECK(uiRet);

    shareInfo->a53KoMsgId            = acType;
    shareInfo->icMaxAntNo            = acPara->acIcMaxAntNo;
    shareInfo->acDmaDataLen          = sizeof(UINT32)*acSeqLen;
    shareInfo->frameType             = uiFrameType;
    shareInfo->acInsertPos           = uiAcInsertPos;
    shareInfo->acDlDoneFlag          = 0;
    shareInfo->acUlDoneFlag          = 0;
    shareInfo->startframeNo          = uiStartFrameNo;
    shareInfo->stopframeNo           = uiStopFrameNo;
    shareInfo->acInslotFr            = frameNo + ioFrOffset;
    shareInfo->acJacFlag             = GetJacMode();
    shareInfo->acJacHandleType       = GetJacType();
    shareInfo->acJacCfgSuperFr       = GetJacSuperFr();

    dbgInfo("[%s] shareInfo->acDmaDataLen %d, sendAcRpuId %d frameType %d\n", __FUNCTION__, shareInfo->acDmaDataLen, shareInfo->sendAcRpuId, uiFrameType);
    dbgInfoEx("[%s]ParaSet dmaLen:%d, startFr:%d, stopFr:%d, jacFlag:%d, jacHandleType:%d ,acJacCfgSuperFr:%d\n", __FUNCTION__,
    shareInfo->acDmaDataLen, shareInfo->startframeNo, shareInfo->stopframeNo, shareInfo->acJacFlag, shareInfo->acJacHandleType,shareInfo->acJacCfgSuperFr);
    AcFuncLog(AC_FUNC_LOG_HIGH, "ParaSet dmaLen:%d, startFr:%d, stopFr:%d, jacFlag:%d, jacHandleType:%d \n",
                                 shareInfo->acDmaDataLen, shareInfo->startframeNo, shareInfo->stopframeNo, shareInfo->acJacFlag, shareInfo->acJacHandleType);

    return BSP_OK;
}

UINT32 IcHalUlSetDlBankInfoToKo(UINT32 acType, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 uiSendDifChn = 0;
    UINT32 uiBankNum    = 0;
    UINT32 uiBankIdx    = 0;
    UINT32 uiRet        = 0;
    UINT32 uiBankId[BSP_DIF_CARR_MAX_NUM];

    INPUT_POINTER_CHECK(shareInfo);

    if(E_AC_TYPE_FDD_UL != acType)
    {
        shareInfo->acDlBankClrSw = 0x2d2d;
        return BSP_OK;
    } 
    uiSendDifChn = shareInfo->ulSendDifChn;

    uiRet = IcHalGetDlbankBankIdByDifChan(uiSendDifChn, uiBankId, &uiBankNum);
    RETURN_RESULT_CHECK(uiRet);

    for(uiBankIdx = 0;uiBankIdx < uiBankNum;uiBankIdx++)
    {
        shareInfo->acDlBankId[0][uiBankIdx] = uiBankId[uiBankIdx];
        dbgInfo("[%s] Ul SendDifChn:%d, uiBankIdx:%d, uiBankId:%d\n", __FUNCTION__, uiSendDifChn, uiBankIdx, uiBankId[uiBankIdx]);
        AcFuncLog(AC_FUNC_LOG_HIGH, "ParaSet Ul AC sendDifChn:%d, bankId:%d \n", uiSendDifChn, uiBankId[uiBankIdx]);
    }
    shareInfo->acDlBankNum[0] = uiBankNum;
    shareInfo->acDlBankClrSw = 0x5a5a; //自清AC子帧开关使能

    return uiRet;
}

UINT32 IcHalDlSetDlBankInfoToKo(UINT32 acType, A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 uiBankNum    = 0;
    UINT32 uiBankIdx    = 0;
    UINT32 uiRet        = 0;
    UINT32 uiChnIdx     = 0;
    UINT32 uiBankId[BSP_DIF_CARR_MAX_NUM];
    UINT32 uiMaxAntNum  = shareInfo->icMaxAntNo;
    UINT32 antNoTmp     = 0;
    UINT32 uiBspChn     = 0;
    UINT32 difChipId    = 0;
    UINT32 difChan      = 0;
    UINT32 frameNo      = shareInfo->acInslotFr;

    INPUT_POINTER_CHECK(shareInfo);
    INPUT_AC_CHECK_OVERTAKE(uiMaxAntNum, AC_DL_ANTS_NUM);

    if(BSP_RADIO_STANDARD_UMTS != BspGetRadioModeValue()||((E_AC_TYPE_FDD_DL != acType)))
    {
        // shareInfo->acDlBankClrSw = 0x2d2d;
        return BSP_OK;
    } 

    for (uiChnIdx = 0; uiChnIdx < uiMaxAntNum; uiChnIdx++)
    {
        antNoTmp = uiChnIdx +1;
        uiRet = BspGetBspChanByAntAndBandInfo(antNoTmp, BspGetBandNo(), TX, &uiBspChn);
        if(BSP_ERROR == uiRet)
        {
            dbgInfoEx("[%s] TX Ant:%d not on this chip\n", __FUNCTION__, antNoTmp);
            continue;
        }
        uiRet = BspGetDifInfoByBspChn(uiBspChn, TX, &difChipId, &difChan);
        RETURN_RESULT_CHECK(uiRet); 
        uiRet = IcHalGetDlbankBankIdByDifChan(difChan, uiBankId, &uiBankNum);
        RETURN_RESULT_CHECK(uiRet);
        for (uiBankIdx = 0; uiBankIdx < uiBankNum; uiBankIdx++)
        {
            shareInfo->acDlBankId[difChan][uiBankIdx] = uiBankId[uiBankIdx];
            dbgInfo("[%s] uiChnIdx:%d, Dl DifChn:%d, uiBankIdx:%d, uiBankId:%d\n", __FUNCTION__, uiChnIdx, difChan, uiBankIdx, uiBankId[uiBankIdx]);
            AcFuncLog(AC_FUNC_LOG_HIGH, "ParaSet Dl AC DifChn:%d, bankId:%d \n", difChan, uiBankId[uiBankIdx]);
        }
        shareInfo->acDlBankNum[difChan] = uiBankNum;
    }

    uiRet = BspAdjustUmtsFr(BspGetRadioModeValue(), &frameNo);
    RETURN_RESULT_CHECK(uiRet);
    shareInfo->acInslotFr = frameNo;
    
    shareInfo->acDlBankClrSw = 0x5a5a; //自清AC子帧开关使能

    dbgInfo("[%s] acDlBankClrSw:%d", __FUNCTION__,shareInfo->acDlBankClrSw);

    return uiRet;
}

UINT32 IcHalAcGetCalInfo(A53R8AcDebugShareInfo* shareInfo)
{
    UINT32 uiBandNo = 0;

    uiBandNo                   = BspGetBandNo();
    shareInfo->acCatchDataChan = BspGetBandCatchChn();
    shareInfo->catchAcRpuId    = BspGetBandCatchChipId();
    shareInfo->acSendDataChan  = BspGetBandSendChn(uiBandNo);
    shareInfo->sendAcRpuId     = BspGetBandSendChipId();

    return BSP_OK;
}

UINT32 BspSetAcSeqGain(UINT32 uiJacType)
{
    UINT32 uiJacMode       = 0;
    UINT32 uiJacHandleType = 0;

    uiJacMode       = GetJacMode();
    uiJacHandleType = GetJacType();

    if(JAC_ENABLE == uiJacMode)
    {
        if((AC_TYPE_STOP != uiJacType) && (JAC_CATCH_DATA == uiJacHandleType))
        {
            BspSetAcSeqGainSw(AC_SEQ_GAIN_OFF);
        }
        else
        {
            BspSetAcSeqGainSw(AC_SEQ_GAIN_ON);
        }
        dbgInfo("[%s], uiJacMode:%d, uiJacType:%d, uiJacHandleType:%d \n", __FUNCTION__, uiJacMode, uiJacType, uiJacHandleType);
    }

    return BSP_OK;
}

UINT32 BspSetFixedAcSw(UINT32 uiAcType)
{
    UINT32 uiDifChn  = 0;

    if(E_AC_TYPE_FDD_DL == uiAcType)
    {
        BspSetTxAcSwitch(uiDifChn, SWITCH_ON);
        BspSetRxAcSwitch(uiDifChn, SWITCH_OFF);
    }
    else if(E_AC_TYPE_FDD_UL == uiAcType)
    {
        BspSetTxAcSwitch(uiDifChn, SWITCH_OFF);
        BspSetRxAcSwitch(uiDifChn, SWITCH_ON);
    }
    else
    {
        BspSetTxAcSwitch(uiDifChn, SWITCH_OFF);
        BspSetRxAcSwitch(uiDifChn, SWITCH_OFF);
    }

    return BSP_OK;
}

UINT32 BspSetFixedJacSw(UINT32 uiAcType)
{
    UINT32 uiJacHandleType = 0;

    uiJacHandleType = GetJacType();
    if(JAC_SEND_CATCH_DATA == uiJacHandleType)
    {
        BspSetFixedAcSw(uiAcType);
    }
    else
    {
        //do nothing
    }

    return BSP_OK;
}

UINT32 IcHalSetFixedAcSwitch(A53R8AcDebugShareInfo* shareInfo, T_ICHAL_ACPARA* acPara, UINT32 acChnChgFlag, UINT32 acType)
{
    UINT32 uiRpuId   = BspGetRpuId();
    UINT32 uiJacMode = 0;

    if(BspGetBandCatchChipId() != uiRpuId)
    {
        dbgInfo("[%s] this is not the io ctl Chip\n", __FUNCTION__);
        return BSP_OK;
    }

    uiJacMode = GetJacMode();
    if(JAC_ENABLE == uiJacMode)
    {
        BspSetFixedJacSw(acType);
    }
    else
    {
        BspSetFixedAcSw(acType);
    }

    return BSP_OK;
}

UINT32 BspSetAcCarrCfg(T_AcCarrCfgNxp* pCarrCfg)
{
    INPUT_POINTER_CHECK(pCarrCfg);

    memcpy_s((void*)&(g_acCarrCfgNxp),sizeof(T_AcCarrCfgNxp),(void*)pCarrCfg,sizeof(T_AcCarrCfgNxp));
    dbgInfo("[%s] carrNo%d, radioMode%d, carrFreq(kHz)%d, bandWidth(kHz)%d\n",__FUNCTION__,pCarrCfg->carrNo,pCarrCfg->radioMode,pCarrCfg->carrFreq,pCarrCfg->bandWidth);
    return BSP_OK;
}

T_AcCarrCfgNxp* GetAcCarrCfg(VOID)
{
    return (T_AcCarrCfgNxp*)(&g_acCarrCfgNxp);
}

UINT32 g_acRadioModeValue = 0;
UINT32 BspGetRadioModeValue(VOID)
{
    return g_acRadioModeValue;
}

UINT32 BspSetRadioModeValue(UINT32 radio)
{
    g_acRadioModeValue = radio;
    return BSP_OK;
}

INT32 iFrameOffset = 0;
UINT32 BspSetFrameOffset(INT32 offset)
{
    iFrameOffset = offset;

    return BSP_OK;
}

INT32 BspGetFrameOffset(VOID)
{
    dbgInfo("[%s] iFrameOffset:%d \n", __FUNCTION__, iFrameOffset);
    return iFrameOffset;
}

UINT32 SetAcParaIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 refChn,UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{
    UINT8 *pucBaseAddr      = NULL;
    UINT32 uiDataOffset     = 0;
    UINT32 uiCpLen          = 0;
    UINT32 uiSeqLen         = 0;
    UINT32 uiAcMode         = 1;
    T_AcParaInfo acParaInfo = {0};
    UINT32 uiFrameSetVal    = 0;
    UINT32 uiAcType         = 0;
    UINT32 uiRet            = 0;

    g_acRadioModeValue = radioMode;
    AcFuncLog(AC_FUNC_LOG_HIGH, "ParaSet acType:%d, radioMode:%d, bandWidth:%d, carrNo:%d, refChn:%d, chnChgFlag:%d, frNo:%d, slotNo:%d, subframe:%d \n",
                                acType, radioMode, bandWidth, carrNo, refChn, acChnChgFlag, frameNo, slotNo, subframeNo);

    dbgInfo("[%s] IC real FrameNo:%d, set frameNo:%d \n", __FUNCTION__, IcHalGetFrameNo(), frameNo);
    uiFrameSetVal = (frameNo + BspGetFrameOffset() + 1024) % 1024; //维测调整帧号

    uiAcType = BspJudgeAcType(acType);
    dbgInfo("[%s] uiAcType:%d, acType:%d \n", __FUNCTION__, uiAcType, acType);

    //记录函数执行时间戳
    recordAcTickInfo(0,1,0);//SetAcParaIc 对应索引 1
    RecordSetAcParaIcInfo(uiAcType,refChn,acChnChgFlag);
    recordSetAcParaIcCnt(uiAcType);
    recordErsUpdateTime(uiAcType, uiAcType);
    RecordAcTransFrameNo(uiAcType, frameNo);

    
    dbgInfo("[%s] acType:%d, frameNo:%d \n", __FUNCTION__, acType, frameNo);
    dbgInfo("[%s] radioMode %d\n",__FUNCTION__, radioMode);
    dbgInfo("[%s] bandWidth %d\n",__FUNCTION__, bandWidth);
    dbgInfo("[%s] pasteCarrFlag %d\n",__FUNCTION__, pasteCarrFlag);
    dbgInfo("[%s] deviate %d\n",__FUNCTION__, deviate);
    dbgInfo("[%s] refChn %d\n",__FUNCTION__, refChn);
    dbgInfo("[%s] calcChnChangFlag  %d [0:M_chn;1:S_chn] \n",__FUNCTION__, acChnChgFlag);
    dbgInfo("[%s] carrNo before CA %d\n",__FUNCTION__, carrNo);
    dbgInfo("[%s] frameNo %d\n",__FUNCTION__, uiFrameSetVal);
    dbgInfo("[%s] subFrameNo %d\n",__FUNCTION__, subframeNo);
    dbgInfo("[%s] slotNo %d\n",__FUNCTION__, slotNo);

    A53R8AcDebugShareInfo* shareInfo = NULL;
    T_ICHAL_ACPARA* acPara           = NULL;

    if(BSP_RADIO_STANDARD_GSM == radioMode)
    {
        return BSP_OK;
    }

    if(NULL == (pucBaseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        recordAcTickInfo(1,1,1);//SetAcParaIc 对应索引 1
        return BSP_ERROR;
    }
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + pucBaseAddr);

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();

    uiRet = BspGetAcParaInfo(radioMode, pasteCarrFlag, bandWidth, &acParaInfo);
    dbgInfo("%s get AcParaInfo uiRet:%d \n", __FUNCTION__, uiRet);

    uiDataOffset = acParaInfo.acDataOffset;
    uiCpLen      = acParaInfo.acCpLen;
    uiSeqLen     = acParaInfo.acSeqLen;

    //psync中断初始化
    bspAcPsyncInit(radioMode);

    //AC dlbank 发数位置设置
    IcHalSetDlbankAcInsertPos(g_acInsertPos);

    //设置AC或者AAC模式
    IcHalSetAcOrAAcMode(uiAcMode);

    //AC ulbank输入数据选择配置
    ICHalSetUlbankAcDataRouterCfg(g_acCatchDataPos);

    //获取校准通道和耦合通道信息
    IcHalAcGetCalInfo(shareInfo);

    //获取耦合通道所在round
    acCatchDataChnInfo(shareInfo, radioMode, acPara);

    //高层建完小区后重新配置:
    IcHalSetBlockBankInfo(radioMode, carrNo, uiDataOffset, shareInfo);

    //共享内存传参数
    IcHalSetInfoToDdrForKo(acType, acPara, shareInfo, radioMode, uiSeqLen, carrNo, uiFrameSetVal, subframeNo, slotNo);

    //传递耦合通道所有载波使用的bank号
    IcHalUlSetDlBankInfoToKo(acType, shareInfo);

    IcHalDlSetDlBankInfoToKo(acType, shareInfo);


    //帧频配置
    IcHalFddSetFrPara(acPara, uiFrameSetVal);

    //下行AC配置
    if (E_AC_TYPE_FDD_DL == acType)
    {
        //下行内插配置
        IcHalSetFddDlInsertCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara);
        //下行采数配置
        IcHalSetFddDlCatchCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara, shareInfo);
    }
    else if (E_AC_TYPE_FDD_UL == acType) //上行AC配置
    {
        //上行内插配置
        IcHalSetFddUlInsertCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara, shareInfo);
        //上行采数配置
        IcHalSetFddUlCatchCfgPara(acType, carrNo, radioMode, bandWidth, uiFrameSetVal, subframeNo, slotNo, refChn, &acParaInfo, acPara);
    }
    else
    {
        BspRecordJacSuperFr(shareInfo);
        dbgInfo("[%s] Ac Stop \n", __FUNCTION__);
    }
    //设置ACRAM的发数长度和采数长度，且将上行AC RAM去使能
    IcHalSetFddAcRamPara(uiSeqLen, uiCpLen, acPara, acType, radioMode);
    //MTS配置
    INPUT_POINTER_CHECK(acPara->pMtsNcoCfg);
    acPara->pMtsNcoCfg(acType, carrNo, radioMode, bandWidth, shareInfo);
    //配置AcSync
    INPUT_POINTER_CHECK(acPara->pSetAcSyncEn);
    acPara->pSetAcSyncEn(acType);
    //开关inslot参数配置
    BspSetAcInslotIoCtrl(acType, radioMode, uiFrameSetVal, subframeNo, slotNo, shareInfo);
    //设置AC固定att的开关，根据主备耦合通道
    IcHalSetFixedAcSwitch(shareInfo, acPara, acChnChgFlag, acType);
    //Jac只采数场景,将AC序列增益置零
    BspSetAcSeqGain(acType);
    AcFuncRssi(radioMode, carrNo);

    recordAcTickInfo(1,1,0);//SetAcParaIc 对应索引 1

    return BSP_OK;
}

UINT32 testSetAcParaIc(UINT32 acType, UINT32 carrNo,  UINT32 bandWidth, UINT32 radioMode, UINT32 frameNo,UINT32 subframeNo,UINT32 slotNo)
{
    UINT32 pasteCarrFlag = 0;
    UINT32 deviate       = 0;
    UINT32 acChnChgFlag  = 0;
    UINT32 refChn        = 0;

    SetAcParaIc(acType, carrNo, pasteCarrFlag, deviate, bandWidth, acChnChgFlag, radioMode, refChn, frameNo, subframeNo, slotNo);

    return BSP_OK;
}

UINT32 GetAcCatchDataSta(UINT32 acType, UINT32 carrNo, UINT32 radioMode)
{
    recordGetAcCatchDataStaCnt();
    return BSP_OK;
}

UINT32 BspInitAcModuleFunc(VOID)
{
    T_AcFunc *pAcModule = NULL;

    pAcModule = (T_AcFunc *)BspGetAcModuleInfo();

    pAcModule->pDevInit               = AcDataInit;
    pAcModule->pWrMsg                 = WriteAcMsg;

    pAcModule->pCalAcSeqIc4           = CalAcSeqIc;//计算AC序列
    pAcModule->pChkAcSeqIc            = ChkAcSeqIc;//查询AC序列的计算结果
    pAcModule->pGetAcSeqIc            = GetAcSeqIc;//获取AC序列
    pAcModule->pSetAcSeqIc            = SetAcSeqIc;//设置AC序列

    pAcModule->pSetAcParaIc           = SetAcParaIc;//IC配置
    pAcModule->pGetAcSyncTime         = GetAcSyncTime;//获取AC序列/权值同步时刻
    pAcModule->pSetAcSyncTime         = SetAcSyncTime;//设置AC序列/权值同步时刻

    pAcModule->pGetAcCatchDataSta     = GetAcCatchDataSta; //查询AC采数是否完成
    pAcModule->pSendHaulBackAcSeqIc   = SendHaulBackAcSeqIc;//回收的AC序列传给AC DSP

    pAcModule->pCalAcWgtIc            = CalAcWgtIc;//计算AC权值
    pAcModule->pChkAcWgtIc            = ChkAcWgtIc;//查询AC权值的计算结果

    pAcModule->pGetAcWgtIc            = GetAcWgtIc;
    pAcModule->pSetAcWgtIc            = SetAcWgtIc;//设置AC权值

    pAcModule->pCheckAcCarrNo         = CheckAcCarrNo;//获取载波信息

    pAcModule->pSetAacWgtIc           = SetAacWgtIc;  /* 设置Aac权值 */

    //JAC新增
    pAcModule->pSetJacMode            = SetJacMode; //下发JAC模式和JAC发采数选择
    pAcModule->pSetJacSuperFr         = SetJacSuperFr; //下发JAC超帧号

    //时域法切换开关
    pAcModule->pBspSetAcAlgTimeSw     = BspSetAcAlgTimeSw;

    return BSP_OK;
}

UINT32 BspGetProWgt(UINT32 dir,UINT32 chanNo,UINT32 carrNo,UINT32 *pData,UINT32 *length)
{
    return BSP_OK;
}

UINT32 BspSetAcBitMap(UINT32 sw)
{
    return BSP_OK;
}

UINT32 BspAntCalInitByBw(VOID)
{
    return BSP_OK;
}

UINT32 showUlAcAllProgressCnt(VOID)
{
    dbgInfo("SendHaulBackAcSeqIcUlAcCnt %d\n", SendHaulBackAcSeqIcUlAcCnt);
    return BSP_OK;
}

UINT32 showUlAcVgaData(UINT32 carrNo, UINT32 radioMode)
{
    /*DPDIC4编译修改*/
#if 1
    UINT8*              baseAddr = 0;
    UlAcVgaData*        VgaData  = NULL;
    UINT32              retry    = 0;//IC_AC_RETRY_TIME;
    UINT32              round    = 0;//IC_AC_ROUND_T    UINT32              retVal   = 0;
    UINT32              acType = (UINT32)E_AC_TYPE_UL;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    VgaData = (UlAcVgaData *)((VOID *)(baseAddr + IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET));
    for(retry = 0; retry < IC_AC_RETRY_TIME; retry++)
    {
        //上行每片C round=16;下行9round
        for(round = 0; round < AC_UL_ANTS_NUM; round++)
        {
            dbgInfo("[%s]retry %d, acType %d, round(Ant) %d, vga %d\n",
                    __FUNCTION__, retry,acType, round, VgaData->vga[retry][round]);
        }
    }
#endif
    return BSP_OK;
}

VOID showUlAcData(VOID)
{
    IcAcShareMemInfo*   memInfo  = NULL;
    UINT8*              baseAddr = 0;
    UINT32              retry    = 0;
    UINT32              chan     = 0;
    UINT32              point    = 0;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return;
    }
    memInfo = (IcAcShareMemInfo*)(IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET + baseAddr);
    for(retry = 0; retry < IC_AC_RETRY_TIME; retry++)
    {
        dbgInfo("\n/************************************retry:%d************************************/\n\n",retry);
        for(chan = 0; chan < IC_AC_ULBANK_RAM_NUM; chan++)
        {
            dbgInfo("\n/************************************chan:%d************************************/\n",chan);
            for(point = 0; point < AC_DATA_LEN_1024; point++)
            {
                if(point % 4 == 0)
                {
                    dbgInfo("\n0x%08x: ", point);
                }
                dbgInfo("0x%08x ", memInfo->ulAcCatch[retry].ulAcCatchData[chan][point]);
            }
        }
    }
}

VOID showDlAcData(VOID)
{
    IcAcShareMemInfo*   memInfo  = NULL;
    UINT8*              baseAddr = 0;
    UINT32              retry    = 0;
    UINT32              round     = 0;
    UINT32              point    = 0;
    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return;
    }
    memInfo = (IcAcShareMemInfo*)(IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET + baseAddr);
    for(retry = 0; retry < IC_AC_RETRY_TIME; retry++)
    {
        dbgInfo("\n/************************************retry:%d************************************/\n\n",retry);
        for(round = 0; round < IC_AC_ROUND_TIME; round++)
        {
            dbgInfo("\n/************************************round:%d************************************/\n",round);
            for(point = 0; point < AC_DATA_LEN_1024; point++)
            {
                if(point % 4 == 0)
                {
                    dbgInfo("\n0x%08x: ", point);
                }
                dbgInfo("0x%08x ", memInfo->dlAcCatch[retry].dlAcCatchData[round][point]);
            }
        }
    }
}

UINT32 smpAcDdrData(UINT32 acType, UINT32 retry, CHAR* fileName)
{
    IcAcShareMemInfo*   memInfo  = NULL;
    UINT8*              baseAddr = 0;
    UINT32              round    = 0;
    UINT32              point    = 0;
    UINT32            roundMax   = 0;
    FILE *fp         = NULL;
    CHAR buff[128]   = {0};
    CHAR outFile[64] = {0};
    INT32 iTmpRet    = 0;
    UINT32 data      = 0;

    //INPUT_AC_PARAMETER_CHECK(retry, IC_AC_RETRY_TIME);

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return BSP_ERROR;
    }

    memInfo = (IcAcShareMemInfo*)(IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET + baseAddr);
    if(E_AC_TYPE_DL == acType)
    {
        roundMax = IC_AC_ROUND_TIME;
    }
    else if(E_AC_TYPE_UL == acType)
    {
        roundMax = IC_AC_ULBANK_RAM_NUM;
    }
    else
    {
        return BSP_ERROR;
    }

    iTmpRet = snprintf_s(outFile,sizeof(outFile) - 1,"ulbankDDR_actype%d_retry%d.txt",acType,retry);
    SNPRINTF_S_CHECK(iTmpRet, sizeof(outFile) - 1);
    fp = fopen(outFile,"w+");
    if(NULL == fp)
    {
        dbgErr("%s open error!",outFile);
        return BSP_ERROR;
    }

    dbgInfo("retry:%d\n",retry);
    for(round = 0; round < roundMax; round++)
    {
        dbgInfo("round:%d\n",round);
        for(point = 0; point < AC_DATA_LEN_1024; point++)
        {
            if(point % 4 == 0)
            {
                iTmpRet = fprintf(fp,"\n0x%08x:",point);
                FPRINTF_CHECK(iTmpRet);
            }
            if(E_AC_TYPE_DL == acType)
            {
                data = memInfo->dlAcCatch[retry].dlAcCatchData[round][point];
            }
            else if(E_AC_TYPE_UL == acType)
            {
                data = memInfo->ulAcCatch[retry].ulAcCatchData[round][point];
            }
            iTmpRet = fprintf(fp," 0x%08x",data);
            FPRINTF_CHECK(iTmpRet);
        }
    }

    iTmpRet = fclose(fp);
    FCLOSE_CHECK(iTmpRet);

    iTmpRet = snprintf_s(buff,sizeof(buff)-1,"ftpput -u data -p data 198.33.33.2 %s %s",(fileName? fileName : outFile),outFile);
    SNPRINTF_S_CHECK(iTmpRet, sizeof(buff)-1);
    dbgInfo("%s\n",buff);
    BspSystem(buff);
    dbgInfo("*** check file %s ***\n", outFile);
    return BSP_OK;
}

UINT32 IcHalNotifyMsgToKernel(VOID)
{
    INT32 psyfd = 0;
    INT32 ret = 0;
    UINT32 uRet = 0;
    T_NOTIFY_MSG_DATA param = {0};

    psyfd = open("/dev/hirq_misc_usr_d42_ac", O_RDWR);
    if (psyfd < 0)
    {
        dbgInfo("%s >> open /dev/hirq_misc_usr_d42_ac\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ret = ioctl(psyfd, RTTST_RTIOC_MSG_OPT_NOTIFY, &param);
    if (ret < 0)
    {
        dbgInfo("%s >> ioctl RTTST_RTIOC_MSG_OPT_NOTIFY fail\n", __FUNCTION__);
        uRet = BSP_ERROR;
    }
    (VOID)close(psyfd);

    return uRet;
}

VOID testDlAcSeqIc(VOID)
{
    UINT32 psyncOn = 0;
    UINT32 halPsyncInt10IntNo = 58;

    //将下行分组信息拷贝到共享内存
    IcHalCopyBlockBankInfoToShareMem();
    IcHalNotifyMsgToKernel();
    //打开psync中断  拷贝下行分组信息给KO的 ulAcBlockBankInfo
    IcHalPsyncTimSetIntMask(halPsyncInt10IntNo,psyncOn);
    AcFuncCarrSta();
    AcFuncPasta();
    AcFuncAttshow();
    AcFuncDbfs();
    AcFuncDlpostPaptAlm();

    return;
}

VOID testUlAcSeqIc(VOID)
{
    UINT32 psyncOn            = 0;
    UINT32 halPsyncInt10IntNo = 58;
    UINT8* baseAddr           = NULL;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return ;
    }

    //将上行分组信息拷贝到共享内存
    IcHalCopyBlockBankInfoToShareMem();
    IcHalNotifyMsgToKernel();
    //打开psync中断  拷贝上行分组信息给KO的 ulAcBlockBankInfo
    IcHalPsyncTimSetIntMask(halPsyncInt10IntNo,psyncOn);
    AcFuncCarrSta();
    AcFuncPasta();
    AcFuncAttshow();
    AcFuncDbfs();
    AcFuncDlpostPaptAlm();

    return;
}

UINT32 printAcBitmap()
{
    dbgInfo("upAcBitmap = 0x%X\n",acBitmap[1]);
    dbgInfo("downAcBitmap = 0x%X\n",acBitmap[0]);
    dbgInfo("s_wgtUpdateBitMap = 0x%X\n",s_wgtUpdateBitMap);

    return BSP_OK;
}

UINT32 bspGetSampleFromBw(UINT32 radio,UINT32 bw,UINT32 pasteCarrFlag)
{
    UINT32 loop = 0;
    UINT32 num  = 0;
    UINT32 sample = 0;

    num = (sizeof(g_tAcLenInfo) / sizeof(g_tAcLenInfo[0]));
    for(loop=0; loop < num;loop++)
    {
        if((radio == g_tAcLenInfo[loop].radio)&&(bw == g_tAcLenInfo[loop].bandWidth))
        {
            sample = g_tAcLenInfo[loop].sample;
            break;
        }
    }
    dbgInfoEx("%s:radio= %#x,bw=%d,sample=%d\n",__FUNCTION__,radio,bw,sample);

    return sample;
}

//获取AC内插后插0点数
UINT32 BspGetAcEndInsert0Num(UINT32 acType,UINT32 radioMode,UINT32 carrNo,UINT32 bw,UINT32 pasteCarrFlag)
{
    UINT32 endInsert0Num       = 0;
    FLOAT  factor              = 0.0;
    UINT32 difChan             = 0;
    UINT32 uiValidNum          = 0;
    UINT32 uiAcInsertPos       = 0;
    UINT32 acInsertPosRate[20] = {0};

    uiAcInsertPos = GetAcInsertPos();

    //根据AC发数位置获取该位置采样率
    IcHalApiGetAcTxNodeSampleRate(difChan, radioMode, carrNo, uiAcInsertPos, &acInsertPosRate[0], &uiValidNum);

    if(RADIO_STANDARD_5G == radioMode)
    {
        if(E_AC_TYPE_UL == acType)
        {
            endInsert0Num = 2200 ;
        }
        else if(E_AC_TYPE_DL == acType)
        {
            endInsert0Num = 2696 ;
        }
        factor = (FLOAT)acInsertPosRate[0] / (FLOAT)(122880);
    }
    else if(RADIO_STANDARD_LTE_TDD == radioMode)
    {
        endInsert0Num = 2224;//4384-576-1584=2224
        factor = (FLOAT)acInsertPosRate[0] / (FLOAT)(30720);
    }
    endInsert0Num *= factor;
    dbgInfoEx("%s:acType=%d,radioMode=%d,endInsert0Num=%d,acInsertPosRate=%d\n",__FUNCTION__,acType,radioMode,endInsert0Num,acInsertPosRate[0]);

    return endInsert0Num;
}

UINT32 BspGetAcFrToDlEnd(UINT32 acType, UINT32 carrNo, UINT32 radioMode, UINT32 bw, UINT32 pasteCarrFlag)
{
    UINT32 uiFrameDlyUs        = 0;
    UINT32 uiFreamDly          = 0;
    UINT32 uiDifChn            = 0;
    UINT32 uiAcInsertPos       = 0;
    UINT32 uiValidNum          = 0;
    UINT32 uiAcInsertPosRate[20] = {0};
    T_ICHAL_ACPARA* acPara     = NULL;
    UINT32 uiCalAntNum         = 0;

    acPara = (T_ICHAL_ACPARA*)getAcParaAddr();
    uiCalAntNum = (E_AC_TYPE_DL == acType) ? acPara->acCatchData[0][0] : acPara->acSendData[0][0];

    uiAcInsertPos = GetAcInsertPos();
    IcHalApiGetAcTxNodeSampleRate(uiDifChn, radioMode, carrNo, uiAcInsertPos, &uiAcInsertPosRate[0], &uiValidNum);
    uiFrameDlyUs = IcHalGetDLFrameDly(uiCalAntNum, carrNo, radioMode);
    uiFreamDly = NsToClk((uiFrameDlyUs * 1000), uiAcInsertPosRate[0]);
    dbgInfo("[%s] uiAcInsertPosRate:%d uiFreamDly:%d\n", __FUNCTION__, uiAcInsertPosRate[0], uiFreamDly);

    return uiFreamDly;
}

UINT32 BspGetAcFrontOrEndZeroDelay(UINT32 acType, UINT32 radio, UINT32 carrNo,UINT32 gpNum,UINT32 bw,UINT32 pasteCarrFlag, UINT32 frontOrEnd)
{
    UINT32 delay   = 0;
    UINT32 gpPos   = 0;
    FLOAT factor   = 0;
    UINT32 ret     = 0;
    UINT32 difChan = 0;
    UINT32 gpLen   = 0;
    UINT32 symbol0 = 0;
    UINT32 symbol1 = 0;
    UINT32 uiValidNum = 0;
    UINT32 ueAdvValns = 0;
    UINT32 acInsertPos = 0;
    UINT32 acInsertPosRate = 0;
    acInsertPos = GetAcInsertPos();
    //根据AC发数位置获取该位置采样率
    IcHalApiGetAcTxNodeSampleRate(difChan, radio, carrNo, acInsertPos, &acInsertPosRate, &uiValidNum);

    //获取UE提前量
    ret = IcHalApiGetUeAdvVal(radio, &ueAdvValns);
    dbgInfo("%s ret:%d ueAdvValns:%u, MIX_NR_MODE:%d, radio:%u \n",__FUNCTION__, ret, ueAdvValns, MIX_NR_MODE,radio);

    IcHalGetFrameGpLen(acType,carrNo,radio,&symbol0,&symbol1);
    if(RADIO_STANDARD_5G == radio)
    {
        gpLen = NsToClk(symbol1, CLK_RATE_122P88);
    }
    else
    {
        gpLen = NsToClk(symbol1, CLK_RATE_30P72);
    }
    /*NR 混模场景 && NR UE提前量为2469ts@122.88M  */
    if( ((RADIO_STANDARD_5G | RADIO_STANDARD_LTE_TDD) == BspGetRadioStandard())||((UINT32)MIX_NR_MODE == ueAdvValns))
    {
        gpPos = 2; //插在倒数第二个gp
        if (1 == gpNum) //当只有一个gp时，无法支持做AC
        {
            dbgErr("%s only one gp, not support to do Ac Test\n",__FUNCTION__);
        }
    }
    else
    {
        gpPos = 1; //插在倒数第一个gp
    }

    if(RADIO_STANDARD_5G == radio)
    {
        if(E_AC_TYPE_UL == acType)
        {
            if(FRONT_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen * (gpNum - gpPos) + GP_TIME_BASE_UPLINK;
            }
            else if(END_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen * (gpNum - gpPos) - (GP_TIME_BASE_UPLINK + AC_SEQ_NR_BASIC_LEN);
            }
        }
        else if(E_AC_TYPE_DL == acType)
        {
            if(FRONT_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen * (gpNum - gpPos) + GP_TIME_BASE_DOWNLIK;
            }
            else if(END_ZERO_TYPE == frontOrEnd)
            {
                delay = gpLen * (gpNum - gpPos) - (GP_TIME_BASE_DOWNLIK + AC_SEQ_NR_BASIC_LEN);
            }
        }
        //gplen：NR以122.88M为基础，所以算出的延时也是以122.88M为基础，其他采样率下的延时必须加以转换
        //根据AC发数位置速率折算延时
        factor =  (FLOAT)acInsertPosRate / (FLOAT)(122880);
        delay  = factor*delay;
    }
    else if(RADIO_STANDARD_LTE_TDD == radio)
    {
        //gplen：LTE以30.72M为基础，所以算出的延时也是以30.72M为基础，其他采样率下的延时必须加以转换
        factor = (FLOAT)acInsertPosRate / (FLOAT)(30720);
        if(FRONT_ZERO_TYPE == frontOrEnd)
        {
            delay = factor*(gpLen * gpNum - AC_LTE_SEQ_WITH_RF_DELAY);
        }
        else if(END_ZERO_TYPE == frontOrEnd)
        {
            delay = factor*(AC_LTE_SEQ_WITH_RF_DELAY - AC_SEQ_LTE_BASIC_LEN);
        }
    }
    dbgInfo("%s:delayTpye:%d, radio%#x,delay=%d,gpLen=%d,gpNum=%d,gpPos=%d,acInsertPosRate=%d\n", __FUNCTION__, frontOrEnd, radio, delay, gpLen, gpNum, gpPos, acInsertPosRate);

    return delay;
}
/*
提供给射频开关控制调用
*/
UINT32 GetdGp2Ac(UINT32 acType, UINT32 radio,DOUBLE* Gp2Ac)
{
    *Gp2Ac = s_Gp2Ac;
    return BSP_OK;
}

UINT32 GetdGp2AcEnd(UINT32 acType, UINT32 radio, DOUBLE* Gp2AcEnd)
{
    *Gp2AcEnd = s_Gp2AcEnd;
    return BSP_OK;
}

UINT32 BspGp2Ac(UINT32 acType, UINT32 radio, UINT32 carrNo,DOUBLE* Gp2Ac)
{
    UINT32 acGpNum   = 0;
    UINT32 bandWidth = 0;
    UINT32 pasteCarrFlag = 0;
    UINT32 acInsertDataDelayClk = 0;
    UINT32 difChan = 0;
    UINT32 uiValidNum = 0;
    UINT32 acInsertPos = 0;
    UINT32 acInsertPosRate = 0;
    acInsertPos = GetAcInsertPos();
    //根据AC发数位置获取该位置采样率
    IcHalApiGetAcTxNodeSampleRate(difChan, radio, carrNo, acInsertPos, &acInsertPosRate, &uiValidNum);

    IcHalGetFrameGpNum(0u,carrNo,radio,0u,&acGpNum);
    acInsertDataDelayClk = BspGetAcFrontOrEndZeroDelay(acType, radio, carrNo, acGpNum, bandWidth, pasteCarrFlag, FRONT_ZERO_TYPE);

    if(acInsertPosRate > 0)
    {
        *Gp2Ac = 1000.0 * (DOUBLE)acInsertDataDelayClk /(DOUBLE)acInsertPosRate ;
    }
    else
    {
        dbgErr("%s acInsertPosRate error!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("%s acType:%d, radio:%X, carrNo:%d , Gp2Ac:%.6f\n",__FUNCTION__, acType, radio,carrNo,*Gp2Ac);

    return BSP_OK;
}

UINT32 BspGp2AcEnd(UINT32 acType, UINT32 radio,UINT32 carrNo, DOUBLE* Gp2AcEnd)
{
    DOUBLE  Gp2Ac = 0;
    UINT32 AcDataLen = 0;
    UINT32 clkRate   = 0;
    if(RADIO_STANDARD_5G == radio)
    {
        AcDataLen = 1088; //32+1024+32
        clkRate = CLK_RATE_122P88;
    }
    else if(RADIO_STANDARD_LTE_TDD == radio)
    {
        AcDataLen = 544; //16+512+16
        clkRate = CLK_RATE_30P72;
    }
    else
    {
        dbgErr("%s clkRate error!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    BspGp2Ac(acType, radio, carrNo,&Gp2Ac);
    *Gp2AcEnd = Gp2Ac + 1000.0 * (DOUBLE)AcDataLen / (DOUBLE)clkRate;

    dbgInfo("%s acType:%d, radio:%X, carrNo:%d , Gp2Ac:%.6f , Gp2AcEnd:%.6f\n",__FUNCTION__, acType, radio,carrNo,Gp2Ac,*Gp2AcEnd);

    return BSP_OK;
}

VOID IcHalShowA53R8AcDebugShareInfo(VOID)
{
    UINT8* baseAddr = NULL;

    A53R8AcDebugShareInfo* shareInfo = NULL;

    if(NULL == (baseAddr = BspGetAcMemBaseAddr()))
    {
        dbgErr("%s get baseAddr error \n",__FUNCTION__);
        return ;
    }
    shareInfo = (A53R8AcDebugShareInfo*)(IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET + baseAddr);

    dbgInfo("acSeqStartFrameNo      %d \n",shareInfo->acSeqStartFrameNo);
    dbgInfo("acWgtEnableFrameNo     %d \n",shareInfo->acWgtEnableFrameNo);
    dbgInfo("acCellSeparateMode     %d \n",shareInfo->acCellSeparateMode);
    dbgInfo("acDlDoneFlag           %d \n",shareInfo->acDlDoneFlag);
    dbgInfo("acUlDoneFlag           %d \n",shareInfo->acUlDoneFlag);
    dbgInfo("acDmaDataLen           %d \n",shareInfo->acDmaDataLen);
    dbgInfo("acCatchDataChan        %d \n",shareInfo->acCatchDataChan);
    dbgInfo("acSendDataChan         %d \n",shareInfo->acSendDataChan);
    dbgInfo("acBackUpCatchDataChan  %d \n",shareInfo->acBackUpCatchDataChan);
    dbgInfo("acBackUpSendDataChan   %d \n",shareInfo->acBackUpSendDataChan);
    dbgInfo("dlCatchDifChn          %d \n",shareInfo->dlCatchDifChn);
    dbgInfo("ulSendDifChn           %d \n",shareInfo->ulSendDifChn);
    dbgInfo("dlBitMap               0x%X \n",shareInfo->dlBitMap);
    dbgInfo("ulBitMap               0x%X \n",shareInfo->ulBitMap);
    dbgInfo("sendAcRpuId            %d \n",shareInfo->sendAcRpuId);
    dbgInfo("catchAcRpuId           %d \n",shareInfo->catchAcRpuId);
    dbgInfo("icMaxAntNo             %d \n",shareInfo->icMaxAntNo);
    dbgInfo("frameType              %d \n",shareInfo->frameType);
    dbgInfo("startframeNo           %d \n",shareInfo->startframeNo);
    dbgInfo("stopframeNo            %d \n",shareInfo->stopframeNo);
    dbgInfo("acInsertPos            %d \n",shareInfo->acInsertPos);
    dbgInfo("acInsertTimes          %d \n",shareInfo->acInsertTimes);
    dbgInfo("a53KoMsgId             %d \n",shareInfo->a53KoMsgId);
}

UINT32 BspSetBoardAcInfo(VOID)
{
    IcHalAcBoardInfo data = {0};

    //从60M，开始的A53-R8的共享空间，大小为4M<物理地址基址、虚拟地址基址>
    data.shareMemPhyAddrBase         = IC_AC_SHARE_MEM_ADDR_PHY_BASE;
    data.shareMemVirAddrBase         = s_ucRamDspAddr;
    data.shareMemAllSize             = IC_AC_SHARE_MEM_ADDR_SIZE;

    //下行AC和上行AC的采数回读区域，用DMA从IC的片内RAM搬到DDR中
    data.dlAcUlBankCatchAddrOffset   = IC_AC_SHARE_MEM_DL_CATCH_DATA_ADDR0_OFFSET;
    data.ulAcUlBankCatchAddrOffset   = IC_AC_SHARE_MEM_UL_CATCH_DATA_ADDR0_OFFSET;

    //下行AC和上行AC的天线分组(block和bank)信息，用直接memcpy或者写地址形式，A53写入，KO读出
    data.dlAcBlockBankInfoAddrOffset = IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_ADDR_OFFSET;
    data.dlAcBlockBankInfoSize       = IC_AC_SHARE_MEM_DL_AC_BLOCK_BANK_INFO_SIZE;
    data.ulAcBlockBankInfoAddrOffset = IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_ADDR_OFFSET;
    data.ulAcBlockBankInfoSize       = IC_AC_SHARE_MEM_UL_AC_BLOCK_BANK_INFO_SIZE;

    //下行AC和上行AC的权值更新信息，用直接memcpy或者写地址形式，A53写入，KO读出
    //上下行公用，所以定义的地址相同
    data.AcWgtDmaInfoAddrOffset      = IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_ADDR_OFFSET;
    data.AcWgtDmaInfoSize            = IC_AC_SHARE_MEM_AC_WGT_DMA_INFO_SIZE;

    data.a53KoDebugInfoAddrOffset    = IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_ADDR_OFFSET;
    data.a53KoDebugInfoSize          = IC_AC_SHARE_MEM_A53_R8_AC_SHARE_INFO_SIZE;

    data.vgaDataAddrOffset           = IC_AC_SHARE_MEM_UL_AC_VGA_DATA_ADDR_OFFSET;
    data.vgaDataSize                 = IC_AC_SHARE_MEM_UL_AC_VGA_DATA_SIZE;

    return IcHalSetBoardInfoInit(&data);
}

UINT32 ac_carr_err = 0;
UINT32 CheckAcCarrNo(UINT32 carrNo,UINT32 radioMode)
{
    UINT32 retVal = BSP_ERROR;
    /*
    UINT32 loopSel = 0;
    UINT32 maxCarrNum = 0;
    T_AcCarrcfg recordcarrcfg = {0,};
    UINT32 retVal = BSP_ERROR;
    UINT32 difChan = 0;

    maxCarrNum = BspGetCarrCfg(difChan,&recordcarrcfg);
    maxCarrNum = min(8, maxCarrNum);
    dbgInfoEx("[%s] carrNo'%d, radioMode'%d, difChan'%d,\n",__FUNCTION__,carrNo,radioMode,difChan);

    for (loopSel = 0;loopSel < maxCarrNum;loopSel++)
    {
        if(carrNo == recordcarrcfg.carrcfgInfo[loopSel][0][1])
        {
            retVal = BSP_OK;
            break;
        }
    }
    if(maxCarrNum == loopSel)
    {
        ac_carr_err++;
    }
    */
    return retVal;
}

UINT32 bspAcPsyncInit(UINT32 radioMode)
{
    UINT32 PsyncInt10IntNo    = 244;
    UINT32 halPsyncInt10IntNo = 58; //244在中频内部映射的中断号
    UINT32 PsyncInt1IntNo     = 245;
    UINT32 halPsyncInt1IntNo  = 59; //245在中频内部映射的中断号
    UINT32 uTimePeriodInt1    = 1000000;//1ms
    UINT32 psyncOff           = 1;
    UINT32 uInter             = 0;
    UINT32 frTmVal            = 0;
    UINT32 uTimeOffset        = 0;//0ms
    UINT32 uTimeOffsetInt1    = 0;//0ms

   HalIcPsyncTimGernXInit(PsyncInt10IntNo, uTimePeriodInt1, uTimeOffset, uInter, SWITCH_ON);
   //关Psync
   IcHalPsyncTimSetIntMask(halPsyncInt10IntNo, psyncOff);
   dbgInfo("psync Int 244:radioMode=%d,frTmVal = %d,uTimeOffset = %d\n", radioMode, frTmVal, uTimeOffset);

   HalIcPsyncTimGernXInit(PsyncInt1IntNo, uTimePeriodInt1, uTimeOffsetInt1, uInter, SWITCH_ON);
   //关Psync
   IcHalPsyncTimSetIntMask(halPsyncInt1IntNo, psyncOff);
   dbgInfo("psync Int 245:radioMode=%d,frTmVal = %d, uTimeOffsetIn1:%d\n", radioMode, frTmVal, uTimeOffsetInt1);

   return BSP_OK;
}

void BspGetCoupleNetFactor_m(UINT32 dir, UINT32* aulData, UINT32 chanEnd, T_Cmac2PulmAntAdjustScheInfoIc3* ptInfo)
{
    return;
}

UINT32 BspGetCoupleNetFactor(UINT32 antNo, UINT32 carrNo, UINT32 dir, UINT32 aulData[])
{
    return BSP_OK;
}

UINT32 BspGetTaDfNs(UINT32 ulChan,UINT32 ulCellFre, INT16 wTaDfNs[])
{
    return BSP_OK;
}

UINT32 InitStoredCarrWgt(UINT32 logicCarrNo, UINT32 radioMode)
{
    UINT32 index = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        if ((s_wgtBakDataPara[index].carrNo == logicCarrNo) && (s_wgtBakDataPara[index].radioMode == radioMode))
        {
            s_wgtBakDataPara[index].carrNo = 0;
            s_wgtBakDataPara[index].radioMode = 0;
            BspSetWgtToDefVal(s_wgtBakDataPara[index].aacWgtbak, IC42_MAX_CHAN_NUM);
            BspSetWgtToDefVal(s_wgtBakDataPara[index].dlAcWgtbak, AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

UINT32 BspInitAllSaveWgt(void)
{
    UINT32 index = 0;

    for (index = 0; index < NELEMENTS(s_wgtBakDataPara); index++)
    {
        BspSetWgtToDefVal(s_wgtBakDataPara[index].aacWgtbak, IC42_MAX_CHAN_NUM);
        BspSetWgtToDefVal(s_wgtBakDataPara[index].dlAcWgtbak, AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM);
    }
    BspInitStoredCarrWgtCallback(InitStoredCarrWgt);

    s_IsSupportAac = SUPPORT;

    return BSP_OK;
}

static UINT32 SaveLatestAacWgt(UINT32 logicCarrNo, UINT32 radioMode, UINT32 antBitMap, UINT32 *pAacWgtData, UINT32 aacWgtLength)
{
    UINT32 bspChan = 0;
    UINT32 carrIndex = 0;
    UINT32 validChanNum = BspGetChanNumByAntMap(antBitMap);
    UINT32 chanNum = BspGetTxChanNum();

    INPUT_POINTER_CHECK(pAacWgtData);

    carrIndex = GetSaveWgtIndex(logicCarrNo, radioMode);
    if ((validChanNum > chanNum) || (carrIndex >= BSP_MAX_CARR_NUM))
    {
        dbgErr("%s: validChanNum(%d) or carrIndex(%d) error!!\n", __FUNCTION__, validChanNum, carrIndex);
        return BSP_ERROR;
    }

    s_wgtBakDataPara[carrIndex].carrNo = logicCarrNo;
    s_wgtBakDataPara[carrIndex].radioMode = radioMode;
    s_wgtBakDataPara[carrIndex].aacWgtLength = aacWgtLength;
    s_wgtBakDataPara[carrIndex].bitAntMap = antBitMap;

    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        if((BIT_SET(bspChan) & antBitMap) != 0)
        {
            s_wgtBakDataPara[carrIndex].aacWgtbak[bspChan] = pAacWgtData[bspChan];
        }
    }

    return BSP_OK;
}

static UINT32 CheckAacWgtRange(UINT32 *pAacWgt, UINT32 bitAntMap)
{
    UINT32 bspChan = 0;
    INT16 wgtReal = 0;
    INT16 wgtImag = 0;
    DOUBLE initialWgtReal = 0.0;
    DOUBLE initialWgtImag = 0.0;
    DOUBLE realWgtAbs = 0.0;
    DOUBLE imagWgtAbs = 0.0;
    DOUBLE wgtAbs = 0.0;
    const DOUBLE wgtOffetVal = 0x4000;
    const DOUBLE wgtThr = 1.0;
    const DOUBLE wgtAbsThr = 1.01;

    INPUT_POINTER_CHECK(pAacWgt);

    for (bspChan = 0; bspChan < BspGetTxChannel(); bspChan++)
    {
        if((BIT_SET(bspChan) & bitAntMap) != 0)
        {
            wgtReal = (pAacWgt[bspChan] >> 16) & 0xFFFF;
            initialWgtReal = wgtReal / wgtOffetVal;
            wgtImag = pAacWgt[bspChan] & 0xFFFF;
            initialWgtImag = wgtImag / wgtOffetVal;
            /* 获取权值的模值，理论是等于1，但是由于计算的精度导致部分权值模值略大于1 */
            realWgtAbs = initialWgtReal * initialWgtReal;
            imagWgtAbs = initialWgtImag * initialWgtImag;
            wgtAbs = realWgtAbs + imagWgtAbs;
            if ((realWgtAbs > wgtThr) || (imagWgtAbs > wgtThr) || (wgtAbs > wgtAbsThr))
            {
                dbgErr("real:%d, imag:%d, realWgtAbs:%f, imagWgtAbs:%f, AAC Wgt Out of Range!!\n", wgtReal, wgtImag, realWgtAbs, imagWgtAbs);
                return BSP_ERROR;
            }
        }
    }

    return BSP_OK;
}

UINT32 SetAacWgtIc(UINT32 logicCarrNo, UINT32 radioMode, UINT32 acType, UINT32 bitAntMap, UINT32 *data, UINT32 length)
{
    UINT32 dlAcMaxWgtLength = 0;
    UINT32 prachRxLength   = 0;
    UINT32 loop   = 0;
    UINT32 acWgtLengthTmp  = 0;
    UINT32 acWgtLength     = 0;
    UINT32 prachWgtData    = 0;
    UINT32 trxType         = 0;
    UINT32 validChanNum    = 0;
    UINT32 ret             = BSP_OK;
    UINT32 *pWgt           = NULL;
    INPUT_POINTER_CHECK(data);

    s_aacInitiateNum++;

    dbgInfo("%s: logicCarrNo:%d, radioMode:%d, antBitMap:%d, acType:%d, length:%d\n", __FUNCTION__, logicCarrNo, radioMode, bitAntMap, acType, length);

    validChanNum = BspGetChanNumByAntMap(bitAntMap);
    if (validChanNum > BspGetTxChannel())
    {
        dbgErr("%s: validChanNum(%d) error!!\n", __FUNCTION__, validChanNum);
        return BSP_ERROR;
    }

    if (BSP_OK != CheckAacWgtRange(data, bitAntMap))
    {
        DbgSaveAbnormalAacPara(logicCarrNo, radioMode, bitAntMap, data, length);
        return BSP_ERROR;
    }

    trxType = BspGetTrxTypeByAcType(acType);
    if (BSP_ERROR == trxType)
    {
        return BSP_ERROR;
    }

    if (BSP_OK != SaveLatestAacWgt(logicCarrNo, radioMode, bitAntMap, data, length))
    {
        return BSP_ERROR;
    }

    dlAcMaxWgtLength = AC_MAX_RB_NUM * IC42_MAX_CHAN_NUM * sizeof(UINT32); /* 长度为byte */
    pWgt = (UINT32*)malloc(dlAcMaxWgtLength);
    if(pWgt == NULL)
    {
        dbgErr("%s: malloc error!!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset_s((UINT32 *)pWgt, dlAcMaxWgtLength, 0, dlAcMaxWgtLength);

    if (BSP_OK != UpdateAcWgt(logicCarrNo, radioMode, pWgt, dlAcMaxWgtLength, &acWgtLength))
    {
        dbgErr("%s: Updata wgt fail!!\n", __FUNCTION__);
        free(pWgt);
        return BSP_ERROR;
    }

    acWgtLengthTmp = acWgtLength / sizeof(UINT32);

    for(loop = 0; loop < acWgtLengthTmp; loop++)
    {
        dbgInfoEx("loop %d data %d\n", loop, pWgt[loop]);
    }

    ret = IcHalApiUpdataAcWgt(logicCarrNo, trxType, radioMode, pWgt, acWgtLengthTmp, &prachWgtData, prachRxLength, bitAntMap);

    free(pWgt);

    return ret;
}


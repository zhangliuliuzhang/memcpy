/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : xxx.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 原始作者 : N/A
* 创建日期 : N/A
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: N/A
* 修改日戳:
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "pa_ic4_2_calcpara.h"
#include "pa_ic4_2_basepara.h"
#include "pa_ic4_2_ctrl.h"
//#include "antcalcommon.h"
#include "cellcfg.h"
#include "exprn.h"
#include "hal_comm.h"
#include "pacommon.h"
#include "pa_ic4_2_tddrfctrl.h"
//#include "antcal_ic4_2_oneic.h"
#include "chnmap_a.h"
#include "freqcfgcommon.h"
#include "funccommon_a.h"
/******************************************************************************************
                             宏、全局变量 辅助性接口 调试接口等定义
******************************************************************************************/
#define TS_MIN_GPNUM           (2)
#ifndef CASE
#define CASE(x) case x:
#endif

UINT32 g_tddIoTddId = 0;  
UINT32 g_tddIoGpNum = 2;  //默认GPNUM=2
UINT32 g_tddIoErrRcdGpNumCnt = 0;
UINT32 g_tddIoCurRadioMode = RADIO_STANDARD_LTE_TDD;
T_TDD_IO_BASE_PARA_INFO s_TddIoBaseParaInfo = {0};
RFSWITCH_PARA_CALLBACK pRfSwitchParaCallBack = NULL;
static UINT32 s_aacRfSwitchParaUpdateSw = AAC_RF_SWITCH_PARA_UPDATE_OFF;
static DOUBLE s_aacProtectVal = 3.5;
#if 0
//T_TddIoRcdPreVal g_tddIoRcdPreVal = {0};
/*T_TddIoRcdPreVal此结构体的作用在于，4.0里某些参数 给的算法是 “使用参数x”,结构体中的元素用来保存x的值，4.2暂时无此场景，先屏蔽*/
UINT32 BspPrnTddIoRcdPreVal(VOID)
{
    dbgInfo("para3Pa = %.6f\n", g_tddIoRcdPreVal.para3Pa);
    dbgInfo("para3TxEn = %.6f\n", g_tddIoRcdPreVal.para3TxEn);
    dbgInfo("para8Lna = %.6f\n", g_tddIoRcdPreVal.para8Lna);
    dbgInfo("para8RxEn = %.6f\n", g_tddIoRcdPreVal.para8RxEn);
    dbgInfo("para8Tivalid = %.6f\n", g_tddIoRcdPreVal.para8Tivalid);
    dbgInfo("para11S3 = %.6f\n", g_tddIoRcdPreVal.para11S3);
    dbgInfo("para11LnaSw = %.6f\n", g_tddIoRcdPreVal.para11LnaSw);

    return BSP_OK;
}
#endif

CHAR g_ioctrlClcParaExprn[][IOCTRL_EXPRNADD_LEN] =
{
    //"BspGetTddIoGpNum",
    "BspCalcTsStartTime",
    "BspCalcTsEndTime",
    "dGp2Ac",
    "dGp2AcEnd",
    //"dUeGap",
    //"BspGetTddIoGpNum",
    "d1SymTime",
    "Para1_DlyOff_PaTxSw",
    "Para1_DlyOff_TrxTxEn",
	"Para1_DlyOff_TxAmpPwr",
    "Para2_DlyOff_PaTxSw",
    "Para2_DlyOff_TrxTxEn",
	"Para2_DlyOff_TxAmpPwr",
    "Para5_AdvOn_PaTxSw",
    "Para5_AdvOn_TrxTxEn",
    "Para5_AdvOn_TxAmpPwr",
    "Para7_AdvOn_LnaRxSw",
    "Para7_AdvOn_TrxRxEn",
    "Para7_AdvOn_LnaRxPwr",
    "Para8_AdvOn_LnaRxSw",
    "Para8_AdvOn_TrxRxEn",
    "Para8_AdvOn_LnaRxPwr",
    "Para11_DlyOff_LnaRxPwr",
    "Para11_DlyOff_LnaRxSw",
    "Para11_DlyOff_TrxRxEn",
    "Para13_DlyOff_TrxRxEnAc",
    "Para13_DlyOff_TrxTxEnAc",
    "Para13_S1_AcTxSw",
    "Para13_S2Rev_AcRxSw",
    "Para13_S3Rev_AcCalSw",
    "Para14_DlyOff_TrxRxEnAc",
    "Para14_DlyOff_TrxTxEnAc",
    "Para14_S1_AcTxSw",
    "Para14_S2Rev_AcRxSw",
    "Para14_S3Rev_AcCalSw",
};

static T_AntCalInterface s_AntCalInterface = {0};
static DOUBLE tsMinTimeLimit = (DOUBLE)71.0000000; //满足TS最小门限时间

UINT32 ioclcparaexprnadd(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    udPrintCnt = sizeof(g_ioctrlClcParaExprn) / IOCTRL_EXPRNADD_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        exprnadd(g_ioctrlClcParaExprn[udCnt]);
    }
    return BSP_OK;
}

UINT32 ioexprnadd(VOID)
{
    exprnadd("BspGetTddIoGpNum");
    exprnadd("dUeGap");
    exprnadd("dUeAdvGap");
    
    return BSP_OK;
}

/*预留单板下设置 开关基础时序参数*/
UINT32 BspRfSwitchParaCallBack(RFSWITCH_PARA_CALLBACK pFuncCallback)
{
    pRfSwitchParaCallBack = pFuncCallback;
    return BSP_OK;
}

/*单板下实现时序参数配置*/
UINT32 BspFixRfSwitchPara(UINT32 ioParaType,UINT32 acType, UINT32 radio, double *pTmpPara)
{
    UINT32 retVal = BSP_OK;
    double tmpVal = 0.0;

    if((NULL == pRfSwitchParaCallBack)||(NULL == pTmpPara))
    {
        return retVal;   /*单板下不回调，使用平台计算的默认值*/
    }
    dbgInfoEx("%s before %d %d %d *pTmpPara %f \n", __FUNCTION__,ioParaType, acType, radio, *pTmpPara);
    tmpVal = pRfSwitchParaCallBack(ioParaType, acType, radio);
    if(fabs(tmpVal) > 0.001)    /*小于这个值说明没更新*/
    {
        *pTmpPara = tmpVal;
    }
    dbgInfoEx("%s after *pTmpPara %f\n", __FUNCTION__,*pTmpPara);

    return retVal;
}
/******************************************************************************************
                           单板下设置和保存基础时序参数
******************************************************************************************/
/*只是预留修改接口，其实未修改参数，excel中提供的是静态通用的基础时序参数*/
UINT32 BspSetRfBasePara(VOID)
{
    UINT32 ret = BSP_OK;
    UINT32 uPaGap = 0;
    UINT32 uLnaGap = 0;
    UINT32 uLnaAdvOn = 0;

    uPaGap = (UINT32)(dPaGap*1000);
    uLnaGap = (UINT32)(dLnaGap*1000);
    uLnaAdvOn = (UINT32)(dLnaAdvOn*1000);
   // ret |= IcHalApiSetPaProGapVal(uPaGap);
   // ret |= IcHalApiSetLnaProGapVal(uLnaGap);
  //  ret |= IcHalApiSetLnaAdvOnVal(uLnaAdvOn);
    dbgInfoEx("%s >>>>>> dLnaAdvOn = %.6f, uLnaAdvOn = %d.\n", __FUNCTION__, dLnaAdvOn, uLnaAdvOn);
    dbgInfoEx("%s >>>>>> dPaGap = %.6f, uPaGap = %d, dLnaGap = %.6f, uLnaGap = %d.\n", __FUNCTION__, dPaGap, uPaGap, dLnaGap, uLnaGap);

    return ret;
}

UINT32 BspSaveTddIoBasePara(T_TDD_IO_BASE_PARA_INFO* pPara)
{
    INPUT_POINTER_CHECK(pPara);
    memcpy_s((VOID*)&s_TddIoBaseParaInfo, sizeof(T_TDD_IO_BASE_PARA_INFO),(VOID*)pPara, sizeof(T_TDD_IO_BASE_PARA_INFO));
    
    return BSP_OK;
}

T_TDD_IO_BASE_PARA_INFO* BspGetTddIoBasePara(VOID)
{
    return &s_TddIoBaseParaInfo;
}

UINT32 BspTddIoBaseParaStrPrint(VOID)
{   
    dbgInfo("dTxEnAdvOn   = %.6f\n", s_TddIoBaseParaInfo.txEnAdvOn);
    dbgInfo("dPaAdvOn     = %.6f\n", s_TddIoBaseParaInfo.paAdvOn);
    dbgInfo("dTxEnDlyOff  = %.6f\n", s_TddIoBaseParaInfo.txEnDlyOff);
    dbgInfo("dPaDlyOff    = %.6f\n", s_TddIoBaseParaInfo.paDlyOff);
    dbgInfo("dRxEnAdvOn   = %.6f\n", s_TddIoBaseParaInfo.rxEnAdvOn);
    dbgInfo("dLnaAdvOn    = %.6f\n", s_TddIoBaseParaInfo.lnaAdvOn);
    dbgInfo("dRxEnDlyOff  = %.6f\n", s_TddIoBaseParaInfo.rxEnDlyOff);
    dbgInfo("dLnaDlyOff   = %.6f\n", s_TddIoBaseParaInfo.lnaDlyOff);
    dbgInfo("dTxEnGap     = %.6f\n", s_TddIoBaseParaInfo.txEnGap);
    dbgInfo("dPaGap       = %.6f\n", s_TddIoBaseParaInfo.paGap);
    dbgInfo("dRxEnGap     = %.6f\n", s_TddIoBaseParaInfo.rxEnGap);
    dbgInfo("dLnaGap      = %.6f\n", s_TddIoBaseParaInfo.lnaGap);
    dbgInfo("dSwitchAdv   = %.6f\n", s_TddIoBaseParaInfo.switchAdv);
    dbgInfo("dSwitchDly   = %.6f\n", s_TddIoBaseParaInfo.switchDly);

    return BSP_OK;
}
UINT32 BspTddIoBaseParaGloValPrint(VOID)
{
    dbgInfo("dTxEnAdvOn   = %.6f\n", dTxEnAdvOn);
    dbgInfo("dPaAdvOn     = %.6f\n", dPaAdvOn);
    dbgInfo("dTxEnDlyOff  = %.6f\n", dTxEnDlyOff);
    dbgInfo("dPaDlyOff    = %.6f\n", dPaDlyOff);
    dbgInfo("dRxEnAdvOn   = %.6f\n", dRxEnAdvOn);
    dbgInfo("dLnaAdvOn    = %.6f\n", dLnaAdvOn);
    dbgInfo("dRxEnDlyOff  = %.6f\n", dRxEnDlyOff);
    dbgInfo("dLnaDlyOff   = %.6f\n", dLnaDlyOff);
    dbgInfo("dTxEnGap     = %.6f\n", dTxEnGap);
    dbgInfo("dPaGap       = %.6f\n", dPaGap);
    dbgInfo("dRxEnGap     = %.6f\n", dRxEnGap);
    dbgInfo("dLnaGap      = %.6f\n", dLnaGap);
    dbgInfo("dSwitchAdv   = %.6f\n", dSwitchAdv);
    dbgInfo("dSwitchDly   = %.6f\n", dSwitchDly);
    return BSP_OK;
}
UINT32 BspSetTddIoBasePara(T_TDD_IO_BASE_PARA_INFO *pBaseParaInfo)
{
    //BspTddIoBaseParaGloValPrint();

    //BspTddIoBaseParaStrPrint();

    //pBaseParaInfo = BspGetTddIoBasePara();
    INPUT_POINTER_CHECK(pBaseParaInfo);

    dTxEnAdvOn = pBaseParaInfo->txEnAdvOn;
    dPaAdvOn = pBaseParaInfo->paAdvOn;
    dTxEnDlyOff = pBaseParaInfo->txEnDlyOff;
    dPaDlyOff = pBaseParaInfo->paDlyOff;
    dRxEnAdvOn = pBaseParaInfo->rxEnAdvOn;
    dLnaAdvOn = pBaseParaInfo->lnaAdvOn;
    dRxEnDlyOff = pBaseParaInfo->rxEnDlyOff;
    dLnaDlyOff = pBaseParaInfo->lnaDlyOff;
    dTxEnGap = pBaseParaInfo->txEnGap;
    dPaGap = pBaseParaInfo->paGap;
    dRxEnGap = pBaseParaInfo->rxEnGap;
    dLnaGap = pBaseParaInfo->lnaGap;
    dSwitchAdv = pBaseParaInfo->switchAdv;
    dSwitchDly = pBaseParaInfo->switchDly;
    
    
    return BSP_OK;

}
UINT32 BspTddIoBaseParaInit(T_TDD_IO_BASE_PARA_INFO* pPara)
{
    INPUT_POINTER_CHECK(pPara);
    
    BspSetTddIoBasePara(pPara);
    
    return BSP_OK;
}

UINT32 BspBoardTddIoInfoInit(T_TDD_IO_BASE_PARA_INFO *pParaInfo)  /*单板下传入基础时延参数，目前看单板之间无差异*/
{
    UINT32 ret = BSP_OK;

    ret |= BspTddIoBaseParaGloValPrint();

    ret |= BspTddIoBaseParaInit(pParaInfo);

    ret |= BspSaveTddIoBasePara(pParaInfo);  //维测

    return ret;
}

UINT32 BspPaCtrlAcCallBackFuncInit(T_AntCalInterface *pInterFace)
{
    if(NULL == pInterFace)
    {
        dbgErr("%s input null pointer\n", __func__);
        return BSP_ERROR;
    }

    memcpy_s(&s_AntCalInterface, sizeof(T_AntCalInterface), pInterFace, sizeof(T_AntCalInterface));

    return BSP_OK;
}


/******************************************************************************************
                           参数1-15的计算使用的中间接口
******************************************************************************************/
/******************************************************************************/
/*从hal获取LTE和NR的GP个数均失败的次数 ，维测打印用*/
UINT32 BspGetTddIoErrRcdGpNum(VOID)
{
    return g_tddIoErrRcdGpNumCnt;
}
/*保存的是当前使用的是哪一套TDD 获取当前gp个数的时候要把TDD下标当入参 */
UINT32 BspGetTddIoTddId(VOID)
{
    return g_tddIoTddId;
}
UINT32 BspSetTddIoTddId(UINT32 tddIdx)/*使用BspUpdateTddIoDlyPara更新对应tdd使用的参数的同时会调用此接口保存当前要配置的tdd下标，更新参数的过程先算再配，算的过程就要用到此参数*/
{
    g_tddIoTddId = tddIdx;
    return BSP_OK;
}

UINT32 BspGetTddIoRadioMode(VOID)
{
    return g_tddIoCurRadioMode;
}
UINT32 BspSetTddIoRadioMode(UINT32 radio)
{
    g_tddIoCurRadioMode = radio;
    return BSP_OK;
}

UINT32 BspSetTddIoGpNum(UINT32 gpNum)
{
    g_tddIoGpNum = gpNum;
    return BSP_OK;
}

UINT32 BspGetTddIoGpNumByDefault(VOID)
{
    return g_tddIoGpNum;
}

UINT32 BspSetTddIoGpNumByRadio(UINT32 radio)
{
    switch(radio)
    {
        case RADIO_STANDARD_45G:
        {
            g_tddIoGpNum = 4;
            break;
        }
        case RADIO_STANDARD_5G:
        case RADIO_STANDARD_LTE_TDD:
        {
            g_tddIoGpNum =  1;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, radio);
            break;
        }
    }

    return g_tddIoGpNum;
}

UINT32 BspGetTddIoGpNum(UINT32 radio, UINT32* GpNumX)
{
    UINT32 tddId = BspGetTddIoTddId();
	UINT32 swIdx = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(GpNumX);

    if(RADIO_STANDARD_45G == radio)  //混模NR和LTE先下发哪个制式不确定，而且其中1个下发后，另一个不会再配置
    {
        ret = IcHalGetGpNumByTddIdx(tddId, RADIO_STANDARD_LTE_TDD, swIdx, GpNumX); //混模取LTE制式
        if(BSP_OK == ret) 
        {
            BspSetTddIoRadioMode(RADIO_STANDARD_LTE_TDD);  //主要是给d1SymTime用，两者的制式需要匹配
            dbgInfoEx("[%s] radio = %d, GpNum = %d.\n", __FUNCTION__, radio, *GpNumX);
            return BSP_OK;
        }
        
        ret = IcHalGetGpNumByTddIdx(tddId, RADIO_STANDARD_5G, swIdx, GpNumX);   //混模取NR制式
/*
        if(tddId == 2)
        {
            ret  = BSP_OK;
            *GpNumX = 4;
        }
*/
        if(BSP_OK == ret) 
        {
            BspSetTddIoRadioMode(RADIO_STANDARD_5G);
            dbgInfoEx("[%s] radio = %d, GpNum = %d.\n", __FUNCTION__, radio, *GpNumX);
            return BSP_OK;
        }
        //如果2个制式都获取失败，则按异常处理取默认值
        dbgInfoEx("[%s] IcHalGetGpNumByTddIdx fail !!! tddId = %d, radio = %d, GpNum = %d.\n", __FUNCTION__, tddId, radio, *GpNumX);
        *GpNumX = BspGetTddIoGpNumByDefault();   //如果获取失败则设默认值
        if(BspGetTddIoInitFlag() == 1)
        {
            if(g_tddIoErrRcdGpNumCnt < 0xFFFF) g_tddIoErrRcdGpNumCnt++;
        }
        dbgInfoEx("[%s] radio = %d, GpNum = %d.\n", __FUNCTION__, radio, *GpNumX);

    }
    else
    {           
        if(BSP_OK !=IcHalGetGpNumByTddIdx(tddId, radio, swIdx, GpNumX)) 
        {
            dbgInfoEx("[%s] IcHalGetGpNumByTddIdx fail !!! tddId = %d, radio = %d, GpNum = %d.\n", __FUNCTION__, tddId, radio, *GpNumX);
            *GpNumX = BspGetTddIoGpNumByDefault();   //如果获取失败则设默认值
            if(BspGetTddIoInitFlag() == 1)
            {
                if(g_tddIoErrRcdGpNumCnt < 0xFFFF) g_tddIoErrRcdGpNumCnt++;
            }
            dbgInfoEx("[%s] radio = %d, GpNum = %d.\n", __FUNCTION__, radio, *GpNumX);
        }
    }
    dbgInfoEx("[%s] radio = %d, GpNum = %d, g_tddIoErrRcdGpNumCnt = %d.\n", __FUNCTION__, radio, *GpNumX, g_tddIoErrRcdGpNumCnt);
    return ret;
}

/*Gp个数*/
static UINT32 GpNum(UINT32 radio, UINT32* GpNumX)
{
    UINT32 ret = BSP_OK;
    //INPUT_POINTER_CHECK(GpNumX); 修改KW

    if (NULL == GpNumX)                                                 \
    {                                                                     \
        dbgInfo("%s:Input Pointer is NULL!\n",__FUNCTION__);               \
        return BSP_ERROR;                                        \
    }
    ret = BspGetTddIoGpNum(radio, GpNumX);

    return ret;
}
/*1符号时间 单GP长度*/
/**************************************************************************************************/
static UINT32 d1SymTime(UINT32 radio, DOUBLE* SymTime)
{
    UINT32 curRadio = RADIO_STANDARD_LTE_TDD;
    INPUT_POINTER_CHECK(SymTime);
    switch(radio)
    {
        case RADIO_STANDARD_5G:
        {
            *SymTime = d1SymTime5G;
            dbgInfoEx("%s radio = %d, SymTime = %.6f\n",__FUNCTION__, radio, *SymTime);   
            break;
        }
        case RADIO_STANDARD_45G:
        {
            curRadio = BspGetTddIoRadioMode();
            if(curRadio == RADIO_STANDARD_LTE_TDD)
            {
                *SymTime = d1SymTime4G;
            }
            else
            {
                *SymTime = d1SymTime5G;
            }
            dbgInfoEx("%s radio = %d, curRadio = %d, SymTime = %.6f\n",__FUNCTION__, radio, curRadio, *SymTime);  
            break;
        }
        case RADIO_STANDARD_LTE_TDD:
        {
            *SymTime =  d1SymTime4G;
            dbgInfoEx("%s radio = %d, SymTime = %.6f\n",__FUNCTION__, radio, *SymTime);  
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, radio);
            return BSP_ERROR;
            break;
        }
    }
    return BSP_OK;
}

UINT32 BspGetD1SymTime(UINT32 radio, DOUBLE* SymTime)
{
    return d1SymTime(radio, SymTime);
}

/*
acType:
E_AC_TYPE_DL   = 0, //代表下行
E_AC_TYPE_UL   = 1, //代表上行
*/
/*获取AC起始位置*/
/**************************************************************************************************/
UINT32 BspCalcTsStartTime(UINT32 acType, UINT32 radio, DOUBLE* acStartTime)
{
    UINT32 switchCase = radio | acType;
    UINT32 GpNumX = 0;

    INPUT_POINTER_CHECK(acStartTime);

    if(NULL == s_AntCalInterface.pFuncGetModeVal)
    {
        dbgErr("%s pFuncGetModeVal is null \n", __func__);
        return BSP_ERROR;
    }

    if(BSP_OK != GpNum(radio,&GpNumX))
    {
        dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }

    if((radio == RADIO_STANDARD_45G) && (BspGetTddIoRadioMode() == RADIO_STANDARD_LTE_TDD))  //与GPNUM使用同一种制式
    {
        GpNumX = GpNumX*2;
    }
    
    if((radio == RADIO_STANDARD_45G) && (s_AntCalInterface.pFuncGetModeVal() == RADIO_STANDARD_LTE_TDD))  //方案中增加混模下LTE载波: 若AC为混模下的LTE载波，则与单模LTE一致
    {
        radio = RADIO_STANDARD_LTE_TDD;
        switchCase = radio | acType;
    }
    if((radio == RADIO_STANDARD_45G) && (BspGetCarrRadioMixMode() == RADIO_STANDARD_LTE_TDD))  //方案中增加混模下LTE载波
    {
        radio = RADIO_STANDARD_LTE_TDD;
        switchCase = radio | acType;
    }
    switch(switchCase)
    {

        case (RADIO_STANDARD_45G |E_DPD_TYPE_TS):
        {
            *acStartTime =  (GpNumX - 2) * d1SymTime45G + dGp1Sym2DLAc45G;
            dbgInfoEx("[%s] (GpNumX[%d] -2) * [%.6f] + [%.6f] = %.6f\n",
             __FUNCTION__, GpNumX, d1SymTime45G, dGp1Sym2DLAc45G,  *acStartTime);
            break;
        }
        case (RADIO_STANDARD_5G |E_DPD_TYPE_TS):
        {
            *acStartTime =  (GpNumX - 1) * d1SymTime5G + dGp1Sym2DLAc5G;
            dbgInfoEx("[%s] (GpNumX[%d] -1) * [%.6f] + [%.6f] = %.6f\n",
             __FUNCTION__, GpNumX, d1SymTime5G, dGp1Sym2DLAc5G,  *acStartTime);
            break;
        }
        case (RADIO_STANDARD_LTE_TDD |E_DPD_TYPE_TS):
        {
            *acStartTime = d1SymTime4G*2 - 1072 * d1TsTime4G - 512 * d1TsTime4G;//
            dbgInfoEx("[%s] [%.6f] - 1072*[%.6f] - 512*[%.6f] = %.6f\n",__FUNCTION__,
                d1SymTime4G, d1TsTime4G, d1TsTime4G, *acStartTime);
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d, %d) error\n", __FUNCTION__, acType, radio);
            return BSP_ERROR;
            break;
        }
    }
    return BSP_OK;
}

static UINT32 dGp2Ac(UINT32 acType, UINT32 radio, DOUBLE* Gp2Ac)
{
    
    INPUT_POINTER_CHECK(Gp2Ac);

    if(NULL == s_AntCalInterface.pFuncGetdGp2Ac)
    {
        dbgErr("%s pFuncGetdGp2Ac is null \n", __func__);
        return BSP_ERROR;
    }

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        {
            s_AntCalInterface.pFuncGetdGp2Ac(acType, radio, Gp2Ac);  //AC和驻波时间转AC模块计算，解耦
            dbgInfoEx("[%s]input(%d, %d), Gp2Ac = %.6f\n", __FUNCTION__, acType, radio, *Gp2Ac);
            break;
        }
        case E_DPD_TYPE_TS:
        {
            if(BSP_OK == BspCalcTsStartTime(acType, radio, Gp2Ac))   //TS时间按照之前的实现，仍放在TDDIO模块计算
            {
                dbgInfoEx("[%s]input(%d, %d), Gp2Ac = %.6f\n", __FUNCTION__, acType, radio, *Gp2Ac);
            }
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d, %d) err\n", __FUNCTION__, acType, radio);
            return BSP_ERROR;
            break;
        }
    }
    
    if(0 > *Gp2Ac)
    {
        dbgInfo("[%s] Err: Gp2Ac[%.6f] < 0\n", __FUNCTION__, *Gp2Ac);
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*获取AC结束位置*/
/**************************************************************************************************/
UINT32 BspCalcTsEndTime(UINT32 acType, UINT32 radio, DOUBLE* acEndTime)
{
    UINT32 GpNumX = 0;
    DOUBLE SymTime = 0.0;

    INPUT_POINTER_CHECK(acEndTime);
    if(BSP_OK != GpNum(radio,&GpNumX))
    {
        dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }

    if(BSP_OK != d1SymTime(radio, &SymTime))
    {
        dbgInfo("[%s]Getd1SymTime error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }

    if(GpNumX * SymTime < tsMinTimeLimit)  /*此场景不支持TS*/
    {
        dbgInfo("[%s]GetGpNum error,GpNum %d not support TS\n", __FUNCTION__,GpNumX);
        return BSP_ERROR;
    }

    *acEndTime = (dTsRealLength+dTsResLength)/dTsSampRate;
    dbgInfoEx("[%s] ,acType %d, radio 0x%x, *acEndTime= %.6f \n",__FUNCTION__,acType,radio,*acEndTime);

    return BSP_OK;
}

static UINT32 dGp2AcEnd(UINT32 acType, UINT32 radio, DOUBLE* Gp2AcEnd)
{
    
    INPUT_POINTER_CHECK(Gp2AcEnd);

    if(NULL == s_AntCalInterface.pFuncGetdGp2AcEnd)
    {
        dbgErr("%s pFuncGetdGp2AcEnd is null \n", __func__);
        return BSP_ERROR;
    }

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        {
            s_AntCalInterface.pFuncGetdGp2AcEnd(acType, radio, Gp2AcEnd);  //AC和驻波时间转AC模块计算，解耦
            dbgInfoEx("[%s]input(%d, %d), Gp2AcEnd = %.6f\n", __FUNCTION__, acType, radio, *Gp2AcEnd);
            break;
        }
        case E_DPD_TYPE_TS:
        {
            if(BSP_OK == BspCalcTsEndTime(acType, radio, Gp2AcEnd))   //TS时间按照之前的实现，仍放在TDDIO模块计算
            {
                dbgInfoEx("[%s]input(%d, %d), Gp2AcEnd = %.6f\n", __FUNCTION__, acType, radio, *Gp2AcEnd);
            }
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d, %d) err\n", __FUNCTION__, acType, radio);
            return BSP_ERROR;
            break;
        }
    }
    if(0 > *Gp2AcEnd)
    {
        dbgInfo("[%s] Err: Gp2AcEnd[%.6f] < 0\n", __FUNCTION__, *Gp2AcEnd);
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*获取UE保护量*/
/**************************************************************************************************/
UINT32 dUeGap(UINT32 radio, DOUBLE* UeGap)
{
    UINT32 ueGapTemp = 0;
    UINT32 ueAdvTemp = 0;
    UINT32 mixModAdvCompTemp = 0;
    UINT32 ret = BSP_OK;
    UINT32 radioMode = 0;

    radioMode = BspGetRadioStandard();
    radioMode = radioMode&RADIO_STANDARD_45G;
    
    INPUT_POINTER_CHECK(UeGap);

    ret = BspHalAdaptGetTddIoUeAdvGapVal(&ueAdvTemp, &ueGapTemp, &mixModAdvCompTemp);
    if (((RADIO_STANDARD_45G == radioMode)&&(BspGetCarrRadioMixMode() == RADIO_STANDARD_LTE_TDD))
        || (IS_NCR == BspIsNcr()))  /*按表格有 但是高层不调用BspSetCpeTxTimingAdvance 获取不到*/
    {
        BspHalAdaptGetUeAdvGapVal(radioMode, &ueAdvTemp, &ueGapTemp, &mixModAdvCompTemp);  /*此场景直接从ic取 不依赖于高层*/
    }
    *UeGap = ((DOUBLE)ueGapTemp)/((DOUBLE)1000);
    
    dbgInfoEx("[%s] radio = %d, UeGap = %f, ueGapTemp = %d.\n", __FUNCTION__, radio, *UeGap, ueGapTemp);
    
    return ret;
}
/**************************************************************************************************/

/*获取UE提前量+保护量*/
/**************************************************************************************************/
UINT32 dUeAdvGap(UINT32 radio, DOUBLE* UeAdvGap)
{
    UINT32 ueGapTemp = 0;
    UINT32 ueAdvTemp = 0;
    UINT32 mixModAdvCompTemp = 0;
    UINT32 ret = BSP_OK;
    UINT32 radioMode = 0;

    radioMode = BspGetRadioStandard();
    radioMode = radioMode&RADIO_STANDARD_45G;
    
    INPUT_POINTER_CHECK(UeAdvGap);

    ret = BspHalAdaptGetTddIoUeAdvGapVal(&ueAdvTemp, &ueGapTemp, &mixModAdvCompTemp);
    if (((RADIO_STANDARD_45G == radioMode)&&(BspGetCarrRadioMixMode() == RADIO_STANDARD_LTE_TDD))
        || (IS_NCR == BspIsNcr()))  /*按表格有 但是高层不调用BspSetCpeTxTimingAdvance 获取不到*/
    {
        BspHalAdaptGetUeAdvGapVal(radioMode, &ueAdvTemp, &ueGapTemp, &mixModAdvCompTemp);  /*此场景直接从ic取 不依赖于高层*/
    }
    *UeAdvGap = ((DOUBLE)ueAdvTemp)/((DOUBLE)1000) + ((DOUBLE)ueGapTemp)/((DOUBLE)1000);
    
    dbgInfoEx("[%s] radio = %d, UeAdv = %f, UeAdvTemp = %d.\n", __FUNCTION__, radio,  ((DOUBLE)ueAdvTemp)/((DOUBLE)1000), ueAdvTemp);
    dbgInfoEx("[%s] radio = %d, UeGap = %f, ueGapTemp = %d.\n", __FUNCTION__, radio,  ((DOUBLE)ueGapTemp)/((DOUBLE)1000), ueGapTemp);
    dbgInfoEx("[%s] UeAdvGap = %f.\n", __FUNCTION__, *UeAdvGap);

    return ret;
}

/*UE提前量相关参数获取 参数与制式强相关，制式预留特殊处理时使用 和4.0保持一致*/
UINT32 dMixAdvDiffComp(UINT32 radio, DOUBLE* mixAdvDiffCompVal)
{
    UINT32 ueGapTemp = 0; /*UE保护间隔*/
    UINT32 ueAdvTemp = 0; /*UE提前量*/
    UINT32 mixModAdvCompTemp = 0;/*混模时提前差补偿*/
    UINT32 radioMode = 0;

    radioMode = BspGetRadioStandard();
    radioMode = radioMode&RADIO_STANDARD_45G;

    INPUT_POINTER_CHECK(mixAdvDiffCompVal);
    BspHalAdaptGetTddIoUeAdvGapVal(&ueAdvTemp, &ueGapTemp, &mixModAdvCompTemp);
    if (((RADIO_STANDARD_45G == radioMode)&&(BspGetCarrRadioMixMode() == RADIO_STANDARD_LTE_TDD))
        || (IS_NCR == BspIsNcr()))  /*按表格有 但是高层不调用BspSetCpeTxTimingAdvance 获取不到*/
    {
        BspHalAdaptGetUeAdvGapVal(radioMode, &ueAdvTemp, &ueGapTemp, &mixModAdvCompTemp);  /*此场景直接从ic取 不依赖于高层*/
    }
    *mixAdvDiffCompVal = ((DOUBLE)mixModAdvCompTemp)/((DOUBLE)1000);
    dbgInfoEx("[%s] radio = %d, ueAdvTemp = %d, ueGapTemp = %d mixModAdvCompTemp = %d.\n", __FUNCTION__, radio, ueAdvTemp, ueGapTemp, mixModAdvCompTemp);

    return BSP_OK;
}
/**************************************************************************************************/
/*获取提前差补偿值*/
/**************************************************************************************************/
UINT32 g_advDiffBoardFlag = 0;
UINT32 BspSetAdvDiffBoardFlag(UINT32 Flag)
{
    g_advDiffBoardFlag = Flag;
    return BSP_OK;
}

UINT32 BspGetAdvDiffBoardDiffFlag(VOID)
{
    return g_advDiffBoardFlag;
}

/**************************************************************************************************/

UINT32 BspGetIoBasePara(UINT32 radio)
{
    UINT32 ret = BSP_OK;
    UINT32 GpNumX = 0;
    DOUBLE UeGap = 0;
    DOUBLE UeAdvGap = 0;
    DOUBLE mixAdvDiffCompVal = 0;

    ret |= GpNum(radio, &GpNumX);
    ret |= dUeGap(radio, &UeGap);
    ret |= dUeAdvGap(radio, &UeAdvGap);
    ret |= dMixAdvDiffComp(radio, &mixAdvDiffCompVal);
    dbgInfo("%s>>>>>> GpNum = %d, UeGap = %f, UeAdvGap = %f, mixAdvDiffCompVal = %f.\n", __FUNCTION__, GpNumX, UeGap, UeAdvGap, mixAdvDiffCompVal);

    return ret;    
}

UINT32 BspGetIoAcBasePara(UINT32 radio, UINT32 acType)
{
    UINT32 ret = BSP_OK;
    DOUBLE Gp2Ac = 0;
    DOUBLE Gp2AcEnd = 0;
    
    ret |= dGp2Ac(acType, radio, &Gp2Ac);
    ret |= dGp2AcEnd(acType, radio, &Gp2AcEnd);
    dbgInfo("%s>>>>>> Gp2Ac = %f, Gp2AcEnd = %f.\n", __FUNCTION__, Gp2Ac, Gp2AcEnd);

    return ret;
}

/******************************************************************************************
                           参数1-15的计算（入参是模式和通道制式）
                           C1/C2目前没使用
******************************************************************************************/
/********************* 参数1：延迟关闭PA\TRX_TXEN\AMP **********************/
/*参数1 延迟关闭 PA_*_TX_SW   几种TDD模式下一样*/ //inslot ac和内环自检不需要？
UINT32 Para1_DlyOff_PaTxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP://正常TDD的意思 正常DPD采数也是这个

        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = dPaDlyOff;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d, %d) error\n", __FUNCTION__, acType, radio);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_PA1, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}

UINT32 Para1_DlyOff_PaTxSw_NCR2(UINT32 radio, UINT32 *delay)
{
    DOUBLE temp = 0.0;
    DOUBLE dUeGapVal = 0;
    DOUBLE dmixAdvDiffCompVal = 0;

    INPUT_POINTER_CHECK(delay);
    dUeGap(radio, &dUeGapVal);
    dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);

    temp = dUeGapVal + dmixAdvDiffCompVal + dLnaAdvOn + dPaDlyOff;
    dbgInfoEx("[%s] dUeGapVal[%.6f] + dmixAdvDiffCompVal[%.6f] + dLnaAdvOn[%.6f] + dPaDlyOff[%.6f] = %.6f\n",
            __FUNCTION__, dUeGapVal, dmixAdvDiffCompVal, dLnaAdvOn, dPaDlyOff, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}

/*参数1 延迟关闭 TRX_TXEN*/
UINT32 Para1_DlyOff_TrxTxEn(UINT32 acType, UINT32 radio)
{    
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = dTxEnDlyOff;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }        
        default:
        {
            dbgInfo("[%s]input(%d, %d) error\n", __FUNCTION__, acType, radio);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_TXEN1, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}

UINT32 Para1_DlyOff_TrxTxEn_NCR2(UINT32 radio, UINT32 *delay)
{    
    DOUBLE temp = 0.0;
    DOUBLE dUeGapVal = 0;
    DOUBLE dmixAdvDiffCompVal = 0;

    INPUT_POINTER_CHECK(delay);
    dUeGap(radio, &dUeGapVal);
    dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);

    temp = dUeGapVal + dmixAdvDiffCompVal + dTxEnDlyOff + dRxEnAdvOn;
    dbgInfoEx("[%s] dUeGapVal[%.6f] + dmixAdvDiffCompVal[%.6f] + dTxEnDlyOff[%.6f] + dRxEnAdvOn[%.6f] = %.6f\n",
            __FUNCTION__, dUeGapVal, dmixAdvDiffCompVal, dTxEnDlyOff, dRxEnAdvOn, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}

/*参数1  延迟关闭  TX_AMP*_PWR*/
UINT32 Para1_DlyOff_TxAmpPwr(UINT32 acType, UINT32 radio)
{
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = dTxEnDlyOff;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;//通过mode_map选择常1输出，ac_ctrl0_timing
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_AMP1, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
/*参数1  延迟关闭  TRX_ORFB_SW*/
UINT32 Para1_DlyOff_TrxOrfbSw(UINT32 acType, UINT32 radio)
{
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;//通过mode_map选择常1输出，ac_ctrl0_timing
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }

    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
UINT32 Para1_DlyOff(UINT32 ioType, UINT32 acType, UINT32 radio, UINT32 baseType)
{
	UINT32 delay = 0;
	switch(ioType)
	{
	    case LINK_INFO_PACHN_TDDIO:
	    {
	    	delay = Para1_DlyOff_PaTxSw(acType,radio);  /*功放一直以pa时序为基准*/
	    	break;
	    }
	    case LINK_INFO_AMPCHN_TDDIO:
	    case LINK_INFO_TXCHN_TDDIO:
	    {
	    	if(baseType == TDDIOPARA_BASEON_TXEN)
	    	{
	    		delay = Para1_DlyOff_TrxTxEn(acType,radio);
	    	}
	    	else if(baseType == TDDIOPARA_BASEON_PA)
	    	{
	    		delay = Para1_DlyOff_PaTxSw(acType,radio);
	    	}
	    	else if(baseType == TDDIOPARA_BASEON_AMP)
	    	{
	    		delay = Para1_DlyOff_TxAmpPwr(acType,radio);
	    	}
	    	else
	    	{
	    		dbgInfoEx("ioType %d not used \n",ioType);
	    	}
	    	break;
	    }
	    default:
	    {
	    	delay = 0;
	    	break;
	    }
	}
    return delay;
}
/********************************************************************/

/********************* 参数2：延迟关闭PA\TRX_TXEN、AMP **********************/
/*参数2 延迟关闭 PA_*_TX_SW*/
UINT32 Para2_DlyOff_PaTxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    DOUBLE dGp2AcEndX = 0;
    UINT32 uiGpNum = 0;
    UINT32 GpNumX = 0;
    UINT32 retVal = BSP_OK;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE dmixAdvDiffCompVal = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP://正常TDD的意思 正常DPD采数也是这个
        {
            retVal = GpNum(radio,&uiGpNum);
            CHECK_RETVAL_PRN(GpNum, retVal);
            /* Started by AICoder, pid:a8310b412ao5d12147970a8d5055b40f5fb5ecac */
            retVal = d1SymTime(radio, &d1SymTimeX);
            dbgInfoEx("[%s]d1SymTime retVal = %d\n", __FUNCTION__,retVal);
            /* Ended by AICoder, pid:a8310b412ao5d12147970a8d5055b40f5fb5ecac */
            /*temp =  109.113;*/
            temp =  (DOUBLE)uiGpNum *d1SymTimeX - dUeAdv45G - 0 - dLnaAdvOn- dDmimoTxRxGap  ;/*dmimo配置在正常时隙加两个GP?待梁sir 确认,中频hal 确认不波及其它*/
            break;
        }
        case E_AC_TYPE_UL:
        {
            temp = dPaDlyOff;
            break;
        }
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        {
            if(BSP_ERROR == dGp2AcEnd(acType,radio, &dGp2AcEndX))
            {
                dbgInfoEx("[%s]dGp2AcEndX err, acType %d, radio 0x%08X\n", __FUNCTION__,acType, radio);
                return BSP_ERROR;
            }
            temp = dPaDlyOff + dGp2AcEndX; /*注意4.0上两种模式获取AC结束位置的方法不一样，跟excel对不上*/
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);
            if (0 > (temp = (GpNumX * d1SymTimeX - dPaGap - dUeAdvGapX - dmixAdvDiffCompVal - 2*dLnaAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dPaGap[%.6f] - dUeAdvGapX[%.6f] - dmixAdvDiffCompVal[%.6f] - 2*dLnaAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dPaGap, dUeAdvGapX, dmixAdvDiffCompVal, dLnaAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] GpNumX[%d] * d1SymTimeX[%.6f] - dPaGap[%.6f] - dUeAdvGapX[%.6f] - dmixAdvDiffCompVal[%.6f] - 2*dLnaAdvOn[%.6f]  = %.6f\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dPaGap, dUeAdvGapX, dmixAdvDiffCompVal, dLnaAdvOn, temp);
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d, %d) error\n", __FUNCTION__, acType, radio);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_PA2, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}

/*参数2 延迟关闭 TRX_TXEN*/
UINT32 Para2_DlyOff_TrxTxEn(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcEndX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    UINT32 uiGpNum = 0;
    UINT32 GpNumX = 0;
    UINT32 retVal = BSP_OK;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE dmixAdvDiffCompVal = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        {
            if(BSP_ERROR == dGp2AcEnd(acType,radio,&dGp2AcEndX))
            {
                dbgInfoEx("[%s]dGp2AcEndX err, acType %d, radio 0x%08X\n", __FUNCTION__,acType, radio);
                return BSP_ERROR;
            }
            temp = dTxEnDlyOff + dGp2AcEndX;
            break;
        }
        case E_AC_TYPE_STOP:
        {
            retVal = GpNum(radio,&uiGpNum);
            CHECK_RETVAL_PRN(GpNum, retVal);
            /* Started by AICoder, pid:a8310b412ao5d12147970a8d5055b40f5fb5ecac */
            retVal = d1SymTime(radio, &d1SymTimeX);
            dbgInfoEx("[%s]d1SymTime retVal = %d\n", __FUNCTION__,retVal);
            /* Ended by AICoder, pid:a8310b412ao5d12147970a8d5055b40f5fb5ecac */
           /*temp = 109.813; */  /*这个地方要改成DMIMO专用的参数*/
            temp =  (DOUBLE)uiGpNum * d1SymTimeX -dUeAdv45G - 0 - dLnaAdvOn - dDmimoTxRxGap + dDmimoTxenTxAmpDly ;

            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);
            if (0 > (temp = (GpNumX * d1SymTimeX - dPaGap - dUeAdvGapX - dmixAdvDiffCompVal - dRxEnAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dPaGap[%.6f] - dUeAdvGapX[%.6f] - dmixAdvDiffCompVal[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dPaGap, dUeAdvGapX, dmixAdvDiffCompVal, dRxEnAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] GpNumX[%d] * d1SymTimeX[%.6f] - dPaGap[%.6f] - dUeAdvGapX[%.6f] - dmixAdvDiffCompVal[%.6f] - dRxEnAdvOn[%.6f]  = %.6f\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dPaGap, dUeAdvGapX, dmixAdvDiffCompVal, dRxEnAdvOn, temp);
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error, not use para3(use para1)\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_TXEN2, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}

/*参数2  延迟关闭  TX_AMP*_PWR*/
UINT32 Para2_DlyOff_TxAmpPwr(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcEndX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE dmixAdvDiffCompVal = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            temp = dTxEnDlyOff;
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        {
            if(BSP_ERROR == dGp2AcEnd(acType,radio,&dGp2AcEndX))
            {
                dbgInfoEx("[%s]dGp2AcEndX err, acType %d, radio 0x%08X\n", __FUNCTION__,acType, radio);
                return BSP_ERROR;
            }
        	temp = dPaDlyOff + dGp2AcEndX; /*下行延后关闭时间+AC结束位置*/
           break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);
            if (0 > (temp = (GpNumX * d1SymTimeX - dPaGap - dUeAdvGapX - dmixAdvDiffCompVal - dLnaAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dPaGap[%.6f] - dUeAdvGapX[%.6f] - dmixAdvDiffCompVal[%.6f] - dLnaAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dPaGap, dUeAdvGapX, dmixAdvDiffCompVal, dLnaAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] GpNumX[%d] * d1SymTimeX[%.6f] - dPaGap[%.6f] - dUeAdvGapX[%.6f] - dmixAdvDiffCompVal[%.6f] - dLnaAdvOn[%.6f]  = %.6f\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dPaGap, dUeAdvGapX, dmixAdvDiffCompVal, dLnaAdvOn, temp);
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_AMP2, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
/*参数2 延迟关闭  TRX_ORFB_SW*/
UINT32 Para2_DlyOff_TrxOrfbSw(UINT32 acType, UINT32 radio)
{
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;//通过mode_map选择常1输出，ac_ctrl0_timing
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }

    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
/* Started by AICoder, pid:x70307ebc6rdf9514ea3088a1062ac5d1bb352ea */
/* 计算延迟时间 */
UINT32 Para2_DlyOff_PaTxSw_NCR(UINT32 radio, UINT32 acType, UINT32 *delay)
{
    INPUT_POINTER_CHECK(delay);

    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0.0;
    DOUBLE temp = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            temp = 0.0;
            break;
        }
        case E_AC_TYPE_DL:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }

            temp = (GpNumX / 2 * d1SymTimeX + dPaDlyOff);
            dbgInfoEx("[%s] GpNumX[%d] / 2 * d1SymTimeX[%.6f] + dPaDlyOff[%.6f] = %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dPaDlyOff, temp);
            break;
        }
        case E_DPD_TYPE_TS:
        {
            temp = dDspLen + dPaDlyOff;
            dbgInfoEx("[%s] dDspLen + dPaDlyOff = %.6f\n", __FUNCTION__, temp);
            break;
        }
        default:
        {
            dbgErr("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
        }
    }

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s] input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n",
            __FUNCTION__, radio, acType, temp, *delay, *delay);

    return BSP_OK;
}
/* Ended by AICoder, pid:x70307ebc6rdf9514ea3088a1062ac5d1bb352ea */


/* Started by AICoder, pid:18be2d721dw33f914a900a5960f8265c1c837c79 */
/* 计算延迟时间 */
UINT32 Para2_DlyOff_TrxTxEn_NCR(UINT32 radio, UINT32 acType, UINT32 *delay)
{
    INPUT_POINTER_CHECK(delay);

    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0.0;
    DOUBLE temp = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            temp = 0.0;
            break;
        }
        case E_AC_TYPE_DL:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }

            temp = (GpNumX / 2 * d1SymTimeX + dTxEnDlyOff);
            dbgInfoEx("[%s] GpNumX[%d] / 2 * d1SymTimeX[%.6f] + dPaDlyOff[%.6f] = %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dPaDlyOff, temp);
            break;
        }
        case E_DPD_TYPE_TS:
        {
            temp = dDspLen + dTxEnDlyOff;
            dbgInfoEx("[%s] dDspLen + dTxEnDlyOff = %.6f\n", __FUNCTION__, temp);
            break;
        }
        default:
        {
            dbgErr("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
        }
    }

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n",
            __FUNCTION__, radio, acType, temp, *delay, *delay);
    
    return BSP_OK;
}
/* Ended by AICoder, pid:18be2d721dw33f914a900a5960f8265c1c837c79 */


UINT32 Para2_DlyOff(UINT32 ioType, UINT32 acType, UINT32 radio,UINT32 baseType)
{
	UINT32 delay = 0;
	switch(ioType)
	{
	    case LINK_INFO_PACHN_TDDIO:
	    {
	    	delay = Para2_DlyOff_PaTxSw(acType,radio);  /*功放一直以pa时序*/
	    	break;
	    }
	    case LINK_INFO_AMPCHN_TDDIO:
	    case LINK_INFO_TXCHN_TDDIO:
	    {
	    	if(baseType == TDDIOPARA_BASEON_TXEN)
	    	{
	    		delay = Para2_DlyOff_TrxTxEn(acType,radio);
	    	}
	    	else if(baseType == TDDIOPARA_BASEON_PA)
	    	{
	    		delay = Para2_DlyOff_PaTxSw(acType,radio);
	    	}
	    	else if(baseType == TDDIOPARA_BASEON_AMP)
	    	{
	    		delay = Para2_DlyOff_TxAmpPwr(acType,radio);
	    	}
	    	else
	    	{
	    		dbgInfoEx("ioType %d not used \n",ioType);
	    	}
	    	break;
	    }
	    default:
	    {
	    	delay = 0;
	    	break;
	    }
	}
    return delay;
}
/********************* 参数3不使用**********************/
/********************* 参数4不使用**********************/

/********************* 参数5 提前打开PA/TXEN/AMP**********************/
/*参数5 提前打开 PA_*_TX_SW*/
UINT32 Para5_AdvOn_PaTxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dUeAdvGapX + dLnaGap + dLnaAdvOn - dPaAdvOn)))
            {
               dbgInfo("[%s] Err: dUeAdvGapX[%.6f] + dLnaGap[%.6f] + dLnaAdvOn[%.6f] - dPaAdvOn[%.6f] < 0\n", __FUNCTION__,
                        dUeAdvGapX, dLnaGap, dLnaAdvOn, dPaAdvOn);
               return BSP_ERROR;
            }

            dbgInfoEx("[%s]dUeAdvGapX[%.6f] + dLnaGap[%.6f] + dLnaAdvOn[%.6f] - dPaAdvOn[%.6f] = %.6f\n", __FUNCTION__,
                        dUeAdvGapX, dLnaGap, dLnaAdvOn, dPaAdvOn, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(ADVON_PA5, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/* Started by AICoder, pid:6f0c4l1b57m850614aa909b630d564680a9208d9 */
UINT32 Para5_AdvOn_PaTxSw_NCR(UINT32 radio, UINT32 *delay)
{
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;

    INPUT_POINTER_CHECK(delay);
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__, radio);
        return BSP_ERROR;
    }
    if (0 > (temp = (dUeAdvGapX + dLnaAdvOn - dPaAdvOn + dLnaGap)))
    {
        dbgErr("[%s] Err: dUeAdvGapX[%.6f] + dLnaAdvOn[%.6f] - dPaAdvOn[%.6f] + dLnaGap[%.6f] < 0\n",
            __FUNCTION__, dUeAdvGapX, dLnaAdvOn, dPaAdvOn, dLnaGap);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s]dUeAdvGapX[%.6f] + dLnaAdvOn[%.6f] - dPaAdvOn[%.6f] + dLnaGap[%.6f] = %.6f\n",
            __FUNCTION__, dUeAdvGapX, dLnaAdvOn, dPaAdvOn, dLnaGap, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}

/* Started by AICoder, pid:40a90477f6z027a14f020abbc072054ba1d8cafa */
/* 计算延迟时间 */
UINT32 Para5_AdvOn_PaTxSw_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay)
{
    INPUT_POINTER_CHECK(delay);

    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0.0;
    DOUBLE dUeAdvGapX = 0.0;
    DOUBLE temp = 0.0;

    if(BSP_ERROR == GpNum(radio, &GpNumX))
    {
        dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
    {
        dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }

    temp = GpNumX * d1SymTimeX - dUeAdvGapX + dLnaGap - dPaAdvOn;

    if(E_DPD_TYPE_TS == acType && temp > dDspLen_9us)
    {
        temp -= dDspLen_9us;
    }

    if (0 > temp)
    {
        dbgErr("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dPaAdvOn[%.6f] + dLnaGap[%.6f] < 0\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dPaAdvOn, dLnaGap);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dPaAdvOn[%.6f] + dLnaGap[%.6f] = %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dPaAdvOn, dLnaGap, temp);
    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d) %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}
/* Ended by AICoder, pid:40a90477f6z027a14f020abbc072054ba1d8cafa */

/* Ended by AICoder, pid:6f0c4l1b57m850614aa909b630d564680a9208d9 */

/*参数5 提前打开 TRX_TXEN*/
UINT32 Para5_AdvOn_TrxTxEn(UINT32 acType, UINT32 radio)
{
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    
    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dUeAdvGapX + dLnaGap + dLnaAdvOn - dTxEnAdvOn)))
            {
               dbgInfo("[%s] Err: dUeAdvGapX[%.6f] + dLnaGap[%.6f] + dLnaAdvOn[%.6f] - dTxEnAdvOn[%.6f] < 0\n",
                __FUNCTION__, dUeAdvGapX, dLnaGap, dLnaAdvOn, dTxEnAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s]dUeAdvGapX[%.6f] + dLnaGap[%.6f] + dLnaAdvOn[%.6f] - dTxEnAdvOn[%.6f] = %.6f\n",
                __FUNCTION__, dUeAdvGapX, dLnaGap, dLnaAdvOn, dTxEnAdvOn, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(ADVON_TXEN5, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
/* Started by AICoder, pid:h2d5591946n1b5e140da0be6b06b0b6835a34d94 */
UINT32 Para5_AdvOn_TrxTxEn_NCR(UINT32 radio, UINT32 *delay)
{
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;

    INPUT_POINTER_CHECK(delay);
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if (0 > (temp = (dUeAdvGapX + dRxEnGap + dRxEnAdvOn - dTxEnAdvOn)))
    {
        dbgErr("[%s] Err: dUeAdvGapX[%.6f] + dRxEnGap[%.6f] + dRxEnAdvOn[%.6f] - dTxEnAdvOn[%.6f] < 0\n",
            __FUNCTION__, dUeAdvGapX, dRxEnGap, dRxEnAdvOn, dTxEnAdvOn);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]dUeAdvGapX[%.6f] + dRxEnGap[%.6f] + dRxEnAdvOn[%.6f] - dTxEnAdvOn[%.6f] = %.6f\n",
        __FUNCTION__, dUeAdvGapX, dRxEnGap, dRxEnAdvOn, dTxEnAdvOn, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__,radio, temp, *delay, *delay);

    return BSP_OK;
}

/* Started by AICoder, pid:gf292j7219b083014f4c0813002aab483e77fbbb */
/* 计算延迟时间 */
UINT32 Para5_AdvOn_TrxTxEn_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay)
{
    INPUT_POINTER_CHECK(delay);

    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0.0;
    DOUBLE dUeAdvGapX = 0.0;
    DOUBLE temp = 0.0;

    if(BSP_ERROR == GpNum(radio, &GpNumX))
    {
        dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
    {
        dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }

    temp = GpNumX * d1SymTimeX - dUeAdvGapX + dLnaGap - dTxEnAdvOn;
    if(E_DPD_TYPE_TS == acType && temp > dDspLen_9us)
    {
        temp -= dDspLen_9us;
    }

    if (0 > temp)
    {
        dbgErr("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] + dLnaGap[%.6f] - dTxEnAdvOn[%.6f] < 0\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaGap, dTxEnAdvOn);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] + dLnaGap[%.6f] - dTxEnAdvOn[%.6f]= %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaGap, dTxEnAdvOn, temp);
    
    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}
/* Ended by AICoder, pid:gf292j7219b083014f4c0813002aab483e77fbbb */

/* Ended by AICoder, pid:h2d5591946n1b5e140da0be6b06b0b6835a34d94 */
/*参数5 提前打开 TX_AMP_PWR*/
UINT32 Para5_AdvOn_TxAmpPwr(UINT32 acType, UINT32 radio)
{
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dUeAdvGapX + dLnaGap + dLnaAdvOn - dPaAdvOn)))
            {
                dbgInfo("[%s] Err: dUeAdvGapX[%.6f] + dLnaGap[%.6f] + dLnaAdvOn[%.6f] - dPaAdvOn[%.6f] < 0\n",
                    __FUNCTION__, dUeAdvGapX, dLnaGap, dLnaAdvOn, dPaAdvOn);
                return BSP_ERROR;
            }
            dbgInfoEx("[%s]dUeAdvGapX[%.6f] + dLnaGap[%.6f] + dLnaAdvOn[%.6f] - dPaAdvOn[%.6f] = %.6f\n",
                    __FUNCTION__, dUeAdvGapX, dLnaGap, dLnaAdvOn, dPaAdvOn, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(ADVON_AMP5, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
/*参数5  提前打开 TRX_ORFB_SW*/
UINT32 Para5_AdvOn_TrxOrfbSw(UINT32 acType, UINT32 radio)
{
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;//通过mode_map选择常1输出，ac_ctrl0_timing
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }

    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
UINT32 Para5_AdvOn(UINT32 ioType, UINT32 acType, UINT32 radio,UINT32 baseType)
{
	UINT32 delay = 0;
	switch(ioType)
	{
	    case LINK_INFO_PACHN_TDDIO:
	    {
	    	delay = Para5_AdvOn_PaTxSw(acType,radio);  /*功放一直以pa时序*/
	    	break;
	    }
	    case LINK_INFO_AMPCHN_TDDIO:
	    case LINK_INFO_TXCHN_TDDIO:
	    {
	    	if(baseType == TDDIOPARA_BASEON_TXEN)
	    	{
	    		delay = Para5_AdvOn_TrxTxEn(acType,radio);
	    	}
	    	else if(baseType == TDDIOPARA_BASEON_PA)
	    	{
	    		delay = Para5_AdvOn_PaTxSw(acType,radio);
	    	}
	    	else if(baseType == TDDIOPARA_BASEON_AMP)
	    	{
	    		delay = Para5_AdvOn_TxAmpPwr(acType,radio);
	    	}
	    	else
	    	{
	    		dbgInfoEx("ioType %d not used \n",ioType);
	    	}
	    	break;
	    }
	    default:
	    {
	    	delay = 0;
	    	break;
	    }
	}
    return delay;
}
/***************************** 参数6: 不使用 *******************************/
/********************* 参数7：提前打开:LNA_PWR\TRX_RXEN  参数7和参数8一样 不太对，应该是按4.0处理 待确认 **********************/
/*参数7 提前打开: RX#*_LNA_SW*/
UINT32 Para7_AdvOn_LnaRxSw(UINT32 acType, UINT32 radio)
{
    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX err, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dGp2AcX - dLnaAdvOn)))
            {
               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dLnaAdvOn[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dLnaAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] dGp2AcX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                    __FUNCTION__, dGp2AcX, dLnaAdvOn,temp);

            break;
        }
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dLnaAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                     __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error, not use para5(use para8)\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(ADVON_LNASW7, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/* Started by AICoder, pid:21d0580225bb37114c4e09ac30476f63a1f1f97b */
UINT32 Para7_AdvOn_LnaRxSw_NCR(UINT32 radio, UINT32 *delay)
{
    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;

    INPUT_POINTER_CHECK(delay);
    if(BSP_ERROR == GpNum(radio, &GpNumX))
    {
        dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
    {
        dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dLnaAdvOn)))
    {
        dbgErr("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] < 0\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d) %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}

UINT32 Para7_AdvOn_LnaRxSw_NCR2(UINT32 radio, UINT32 *delay)
{
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;

    INPUT_POINTER_CHECK(delay);
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if (0 > (temp = (dUeAdvGapX - dPaAdvOn - dPaGap + dLnaAdvOn)))
    {
        dbgErr("[%s] Err: dUeAdvGapX[%.6f] - dPaAdvOn[%.6f] - dPaGap[%.6f] + dLnaAdvOn[%.6f] < 0\n",
                __FUNCTION__, dUeAdvGapX, dPaAdvOn, dPaGap, dLnaAdvOn);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] dUeAdvGapX[%.6f] - dPaAdvOn[%.6f] - dPaGap[%.6f] + dLnaAdvOn[%.6f] = %.6f\n",
                __FUNCTION__, dUeAdvGapX, dPaAdvOn, dPaGap, dLnaAdvOn, temp);
    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d) %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}
/* Ended by AICoder, pid:21d0580225bb37114c4e09ac30476f63a1f1f97b */
/*参数7  提前打开: TRX_RXEN  这里要注意4.0没有完全按excel实现，而是一种在参数4.0的参数5 一种在4.0的参数8*/
/* Started by AICoder, pid:3ddfb0aac4de47ff9694bfa5a3232cca */
/* Started by AI-VerifyCI-CodeComplexity, pid:3ddfb0aac4de47ff9694bfa5a3232cca */ 
UINT32 Para7_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio)
{
    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX err, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dGp2AcX - dRxEnAdvOn)))
            {
               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dRxEnAdvOn[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dRxEnAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s]dGp2AcX[%.6f] - dRxEnAdvOn[%.6f] = %.6f\n", __FUNCTION__, dGp2AcX, dRxEnAdvOn, temp);
            break;
        }
        case E_AC_TYPE_STOP:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dRxEnAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dRxEnAdvOn);
               return BSP_ERROR;
            }

            temp = dDmimoRxenDlyOff;  /*dmimo使用*/
            dbgInfoEx("[%s] GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
            break;
        }
        case E_DPD_TYPE_TS:
        CASE(E_VSWR_TYPE_STOP)
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dRxEnAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dRxEnAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error, not use para8(use para5)\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(ADVON_RXEN7, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/* Ended by AI-VerifyCI-CodeComplexity, pid:3ddfb0aac4de47ff9694bfa5a3232cca */
/* Ended by AICoder, pid:3ddfb0aac4de47ff9694bfa5a3232cca */ 
/* Started by AICoder, pid:w4038rf06f8c32714d8c09c9706e6a6b29215f8e */
UINT32 Para7_AdvOn_TrxRxEn_NCR(UINT32 radio, UINT32 *delay)
{
    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;

    INPUT_POINTER_CHECK(delay);
    if(BSP_ERROR == GpNum(radio, &GpNumX))
    {
        dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
    {
        dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dRxEnAdvOn)))
    {
        dbgErr("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dRxEnAdvOn);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}

UINT32 Para7_AdvOn_TrxRxEn_NCR2(UINT32 radio, UINT32 *delay)
{
    DOUBLE dUeAdvGapX = 0;
    DOUBLE temp = 0.0;

    INPUT_POINTER_CHECK(delay);
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgErr("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if (0 > (temp = (dUeAdvGapX - dTxEnAdvOn - dTxEnGap + dRxEnAdvOn)))
    {
        dbgErr("[%s] Err: dUeAdvGapX[%.6f] - dTxEnAdvOn[%.6f] - dTxEnGap[%.6f] + dRxEnAdvOn[%.6f] < 0\n",
                __FUNCTION__, dUeAdvGapX, dTxEnAdvOn, dTxEnGap, dRxEnAdvOn);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s] dUeAdvGapX[%.6f] - dTxEnAdvOn[%.6f] - dTxEnGap[%.6f] + dRxEnAdvOn[%.6f] = %.6f\n",
                __FUNCTION__, dUeAdvGapX, dTxEnAdvOn, dTxEnGap, dRxEnAdvOn, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);

    return BSP_OK;
}
/* Ended by AICoder, pid:w4038rf06f8c32714d8c09c9706e6a6b29215f8e */
/*参数7 提前打开: RX#*_LNA_PWR*/
/* Started by AICoder, pid:2ab0101eafc7475eb3396524e5e8c732 */
/* Started by AI-VerifyCI-CodeComplexity, pid:2ab0101eafc7475eb3396524e5e8c732 */ 
UINT32 Para7_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio)
{
	   UINT32 GpNumX = 0;
	    DOUBLE d1SymTimeX = 0;
	    DOUBLE dUeAdvGapX = 0;
	    DOUBLE dGp2AcX = 0;
	    DOUBLE temp = 0.0;
	    UINT32 delay = 0;

	    switch(acType)
	    {
	        case E_AC_TYPE_UL:
	        {
	    	    if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
	    	    {
	    	        dbgInfo("[%s]dGp2AcX err, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
	    	        return BSP_ERROR;
	    	    }
	            if (0 > (temp = (dGp2AcX - dLnaAdvOn)))
	            {
	               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dLnaAdvOn[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dRxEnAdvOn);
	               return BSP_ERROR;
	            }
	            dbgInfoEx("[%s] dGp2AcX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
	                    __FUNCTION__, dGp2AcX, dRxEnAdvOn,temp);

	            break;
	        }
	        case E_AC_TYPE_STOP:
	        {
	    	    if(BSP_ERROR == GpNum(radio, &GpNumX))
	    	    {
	    	        dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	    	    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
	    	    {
	    	        dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	    	    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
	    	    {
	    	        dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dLnaAdvOn)))
	            {
	               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
	                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn);
	               return BSP_ERROR;
	            }
	            dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] = %.6f\n",
	                     __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);

	            temp = dDmimoLnaDlyOff;  /*dmimo配置在正常时隙加两个GP？  待梁sir确认,中频hal 确认不波及其它*/
	            break;
	        }
	        case E_DPD_TYPE_TS:
            CASE(E_VSWR_TYPE_STOP)
	        case E_AC_TYPE_DL: /*注意下行AC V0.3 表格中值不对 需要更新*/
	        {
	    	    if(BSP_ERROR == GpNum(radio, &GpNumX))
	    	    {
	    	        dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	    	    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
	    	    {
	    	        dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	    	    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
	    	    {
	    	        dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dLnaAdvOn)))
	            {
	               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
	                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn);
	               return BSP_ERROR;
	            }
	            dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] = %.6f\n",
	                     __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
	            break;
	        }
	        case E_AC_TYPE_FDD_DL:
	        case E_AC_TYPE_FDD_UL:
	        case E_AC_TYPE_FDD:
	        {
	            temp = 0;
	            break;
	        }
	        default:
	        {
	            dbgInfo("[%s]input(%d) error, not use para5(use para8)\n", __FUNCTION__, acType);
	            return BSP_ERROR;
	            break;
	        }
	    }
	    BspFixRfSwitchPara(ADVON_LNAPWR7, acType, radio ,&temp);
	    delay = DOUBLE_US_2_UINT32_737(temp);
	    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
	    return delay;
}
/* Ended by AI-VerifyCI-CodeComplexity, pid:2ab0101eafc7475eb3396524e5e8c732 */
/* Ended by AICoder, pid:2ab0101eafc7475eb3396524e5e8c732 */ 

/********************* 参数8：提前打开:LNA_PWR\TRX_RXEN **********************/
/*参数8 提前打开: RX#*_LNA_SW*/
UINT32 Para8_AdvOn_LnaRxSw(UINT32 acType, UINT32 radio)
{
    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX err, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dGp2AcX - dLnaAdvOn)))
            {
               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dLnaAdvOn[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dLnaAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] dGp2AcX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                    __FUNCTION__, dGp2AcX, dLnaAdvOn,temp);

            break;
        }
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dLnaAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                     __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        case E_VSWR_TYPE_STOP:
        {
            temp = dRxEnAdvOn + dTxEnGap;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error, not use para5(use para8)\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(ADVON_LNASW8, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/*参数8  提前打开: TRX_RXEN  这里要注意4.0没有完全按excel实现，而是一种在参数4.0的参数5 一种在4.0的参数8*/
UINT32 Para8_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio)
{
    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0;
    DOUBLE dUeAdvGapX = 0;
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX err, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dGp2AcX - dRxEnAdvOn)))
            {
               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dRxEnAdvOn[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dRxEnAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s]dGp2AcX[%.6f] - dRxEnAdvOn[%.6f] = %.6f\n", __FUNCTION__, dGp2AcX, dRxEnAdvOn, temp);
            break;
        }
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
            {
                dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dRxEnAdvOn)))
            {
               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dRxEnAdvOn);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        case E_VSWR_TYPE_STOP:
        {
            temp = dRxEnAdvOn + dTxEnGap;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error, not use para8(use para5)\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(ADVON_RXEN8, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/*参数8 提前打开: RX#*_LNA_PWR*/
UINT32 Para8_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio)
{
	   UINT32 GpNumX = 0;
	    DOUBLE d1SymTimeX = 0;
	    DOUBLE dUeAdvGapX = 0;
	    DOUBLE dGp2AcX = 0;
	    DOUBLE temp = 0.0;
	    UINT32 delay = 0;

	    switch(acType)
	    {
	        case E_AC_TYPE_UL:
	        {
	    	    if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
	    	    {
	    	        dbgInfo("[%s]dGp2AcX err, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
	    	        return BSP_ERROR;
	    	    }
	            if (0 > (temp = (dGp2AcX - dLnaAdvOn)))
	            {
	               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dLnaAdvOn[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dRxEnAdvOn);
	               return BSP_ERROR;
	            }
	            dbgInfoEx("[%s] dGp2AcX[%.6f] - dLnaAdvOn[%.6f] = %.6f\n",
	                    __FUNCTION__, dGp2AcX, dRxEnAdvOn,temp);

	            break;
	        }
	        case E_AC_TYPE_DL:
	        case E_AC_TYPE_STOP:
	        case E_DPD_TYPE_TS:
	        {
	    	    if(BSP_ERROR == GpNum(radio, &GpNumX))
	    	    {
	    	        dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	    	    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
	    	    {
	    	        dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	    	    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
	    	    {
	    	        dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
	    	        return BSP_ERROR;
	    	    }
	            if (0 > (temp = (GpNumX * d1SymTimeX - dUeAdvGapX - dLnaAdvOn)))
	            {
	               dbgInfo("[%s] Err: GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] < 0\n",
	                        __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn);
	               return BSP_ERROR;
	            }
	            dbgInfoEx("[%s]GpNumX[%d] * d1SymTimeX[%.6f] - dUeAdvGapX[%.6f] - dRxEnAdvOn[%.6f] = %.6f\n",
	                     __FUNCTION__, GpNumX, d1SymTimeX, dUeAdvGapX, dLnaAdvOn, temp);
	            break;
	        }
	        case E_AC_TYPE_FDD_DL:
	        case E_AC_TYPE_FDD_UL:
	        case E_AC_TYPE_FDD:
	        {
	            temp = 0;
	            break;
	        }
            case E_VSWR_TYPE_STOP:
            {
                temp = dLnaAdvOn + dPaGap;
                break;
            }
	        default:
	        {
	            dbgInfo("[%s]input(%d) error, not use para5(use para8)\n", __FUNCTION__, acType);
	            return BSP_ERROR;
	            break;
	        }
	    }
	    BspFixRfSwitchPara(ADVON_LNAPWR8, acType, radio ,&temp);
	    delay = DOUBLE_US_2_UINT32_737(temp);
	    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
	    return delay;
}


/********************************************************************/

/******************** 参数9不使用，参数9不使用，参数9不使用 *******************/
/******************** 参数10不使用，参数10不使用，参数10不使用 *******************/
/********************* 参数11：延迟关闭LNA\TRX_RXEN **********************/
/*参数11 延迟关闭 RX#*_LNA_SW*/
UINT32 Para11_DlyOff_LnaRxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dUeGapX = 0;
    DOUBLE dmixAdvDiffCompVal = 0.0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    
    dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == dUeGap(radio, &dUeGapX))
            {
                dbgInfo("[%s]dUeGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            temp = dPaGap + dUeGapX + dLnaAdvOn + dLnaDlyOff + dmixAdvDiffCompVal;
            dbgInfoEx("[%s] dPaGap[%.6f] + dLnaAdvOn[%.6f] + dUeGapX[%.6f] + dLnaDlyOff[%.6f] + dmixAdvDiffCompVal[%.6f] = %.6f\n",
                __FUNCTION__, dPaGap, dLnaAdvOn, dUeGapX, dLnaDlyOff, dmixAdvDiffCompVal, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_LNASW11, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/* Started by AICoder, pid:a0a0127078379b9143060ab97044af19b163cd11 */
UINT32 Para11_DlyOff_LnaRxSw_NCR(UINT32 radio, UINT32 *delay)
{
    DOUBLE temp = 0.0;
    DOUBLE dUeGapVal = 0;
    DOUBLE dmixAdvDiffCompVal = 0;

    INPUT_POINTER_CHECK(delay);
    dUeGap(radio, &dUeGapVal);
    dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);

    temp = dUeGapVal + dmixAdvDiffCompVal + dLnaAdvOn + dLnaDlyOff + dPaGap;
    dbgInfoEx("[%s] dUeGapVal[%.6f] + dmixAdvDiffCompVal[%.6f] + dLnaAdvOn[%.6f] + dLnaDlyOff[%.6f] + dPaGap[%.6f] = %.6f\n",
            __FUNCTION__, dUeGapVal, dmixAdvDiffCompVal, dLnaAdvOn, dLnaDlyOff, dPaGap, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);
    
    return BSP_OK;
}
/* Ended by AICoder, pid:a0a0127078379b9143060ab97044af19b163cd11 */

/* Started by AICoder, pid:7f95795a06t554f145a40bf7c0e66f5501b038cd */
/* 计算延迟时间 */
UINT32 Para11_DlyOff_LnaRxSw_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay)
{
    INPUT_POINTER_CHECK(delay);

    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0.0;
    DOUBLE temp = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        {
            temp = dLnaDlyOff + dLnaGap;
            dbgInfoEx("[%s] dLnaDlyOff[%.6f] + dLnaGap[%.6f] = %.6f\n",
                __FUNCTION__, dLnaDlyOff, dLnaGap, temp);
            break;
        }
        case E_AC_TYPE_DL:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }

            temp = (GpNumX / 2 * d1SymTimeX + dLnaDlyOff);
            dbgInfoEx("[%s] GpNumX[%d] / 2 * d1SymTimeX[%.6f] + dLnaDlyOff[%.6f] = %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dLnaDlyOff, temp);
            break;
        }
        default:
        {
            dbgErr("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
        }
    }

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n",
            __FUNCTION__, radio, acType, temp, *delay, *delay);

    return BSP_OK;
}
/* Ended by AICoder, pid:7f95795a06t554f145a40bf7c0e66f5501b038cd */


/*参数11 延迟关闭 TRX_RX_EN*/
UINT32 Para11_DlyOff_TrxRxEn(UINT32 acType, UINT32 radio)
{
    DOUBLE dUeGapX = 0;
    DOUBLE dmixAdvDiffCompVal = 0.0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == dUeGap(radio, &dUeGapX))
            {
                dbgInfo("[%s]dUeGapX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            temp = dPaGap + dUeGapX + dLnaAdvOn + dRxEnDlyOff + dmixAdvDiffCompVal;
            dbgInfoEx("[%s] dPaGap[%.6f] + dLnaAdvOn[%.6f] + dUeGapX[%.6f] + dRxEnDlyOff[%.6f] + dmixAdvDiffCompVal[%.6f] = %.6f\n",
                __FUNCTION__, dPaGap, dLnaAdvOn, dUeGapX, dRxEnDlyOff, dmixAdvDiffCompVal, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_RXEN11, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/* Started by AICoder, pid:t08cd0668dtf3b914b880b81f044ae13ed538037 */
UINT32 Para11_DlyOff_TrxRxEn_NCR(UINT32 radio, UINT32 *delay)
{
    DOUBLE temp = 0.0;
    DOUBLE dUeGapVal = 0;
    DOUBLE dmixAdvDiffCompVal = 0;

    INPUT_POINTER_CHECK(delay);
    dUeGap(radio, &dUeGapVal);
    dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);

    temp = dUeGapVal + dmixAdvDiffCompVal + dLnaAdvOn + dRxEnDlyOff + dPaGap;
    dbgInfoEx("[%s] dUeGapVal[%.6f] + dmixAdvDiffCompVal[%.6f] + dLnaAdvOn[%.6f] + dRxEnDlyOff[%.6f] + dPaGap[%.6f] = %.6f\n",
            __FUNCTION__, dUeGapVal, dmixAdvDiffCompVal, dLnaAdvOn, dRxEnDlyOff, dPaGap, temp);

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, radio, temp, *delay, *delay);
    
    return BSP_OK;
}
/* Ended by AICoder, pid:t08cd0668dtf3b914b880b81f044ae13ed538037 */

/* Started by AICoder, pid:md1a7g17afs731414ae00b0eb0fd465fbd70ef77 */
/* 计算延迟时间 */
UINT32 Para11_DlyOff_TrxRxEn_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay)
{
    INPUT_POINTER_CHECK(delay);

    UINT32 GpNumX = 0;
    DOUBLE d1SymTimeX = 0.0;
    DOUBLE temp = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        {
            temp = dRxEnGap + dRxEnDlyOff;
            dbgInfoEx("[%s] dRxEnGap[%.6f] + dRxEnDlyOff[%.6f] = %.6f\n",
                __FUNCTION__, dRxEnGap, dRxEnDlyOff, temp);
            break;
        }
        case E_AC_TYPE_DL:
        {
            if(BSP_ERROR == GpNum(radio, &GpNumX))
            {
                dbgErr("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }
            if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
            {
                dbgErr("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
                return BSP_ERROR;
            }

            temp = (GpNumX / 2 * d1SymTimeX + dRxEnDlyOff);
            dbgInfoEx("[%s] GpNumX[%d] / 2 * d1SymTimeX[%.6f] + dRxEnDlyOff[%.6f] = %.6f\n",
                __FUNCTION__, GpNumX, d1SymTimeX, dRxEnDlyOff, temp);
            break;
        }
        default:
        {
            dbgErr("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
        }
    }

    *delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n",
            __FUNCTION__, radio, acType, temp, *delay, *delay);
    
    return BSP_OK;
}
/* Ended by AICoder, pid:md1a7g17afs731414ae00b0eb0fd465fbd70ef77 */

/*参数11 延迟关闭 RX#*_LNA_PWR*/
UINT32 Para11_DlyOff_LnaRxPwr(UINT32 acType, UINT32 radio)
{
    DOUBLE dUeGapX = 0;
    DOUBLE dmixAdvDiffCompVal = 0.0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        case E_AC_TYPE_UL:
        case E_AC_TYPE_DL:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            if(BSP_ERROR == dUeGap(radio, &dUeGapX))
            {
                dbgInfo("[%s]dUeGapX error, radio 0x%08X\n", __FUNCTION__,radio);
               return BSP_ERROR;
            }
            temp = dPaGap + dUeGapX + dLnaAdvOn + dLnaDlyOff + dmixAdvDiffCompVal;
            dbgInfoEx("[%s] dPaGap[%.6f] + dLnaAdvOn[%.6f] + dUeGapX[%.6f] + dRxEnDlyOff[%.6f] + dmixAdvDiffCompVal[%.6f] = %.6f\n",
                __FUNCTION__, dPaGap, dLnaAdvOn, dUeGapX, dLnaDlyOff, dmixAdvDiffCompVal, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    BspFixRfSwitchPara(DLYOFF_LNAPWR11, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}

/************************** 参数12 不使用 *************************/
/************************** 参数A1/A2: inslot专用 *************************/
/************************** 参数B1/B2: inslot专用 *************************/
/********************* 参数13：S1\S2取反\S3取反\RXEN_AC\TXEN_AC *********************************/
/*参数13：S1   AC*_TX_SW*/
UINT32 Para13_S1_AcTxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcX = 0; 
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL://只在AC位置置1
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dGp2AcX - dSwitchAdv)))
            {
               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dSwitchAdv[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dSwitchAdv);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s] dGp2AcX[%.6f] - dSwitchAdv[%.6f] = %.6f\n", __FUNCTION__, dGp2AcX, dSwitchAdv,temp);
            break;
        }
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d, %d) error\n", __FUNCTION__, acType, radio);
            return BSP_ERROR;
            break;
        }
    }
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}

/*参数13：S2取反  AC*_RX_SW*/
UINT32 Para13_S2Rev_AcRxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    
    switch(acType)
    {
        case E_AC_TYPE_DL://只在AC时刻置1
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dGp2AcX - dSwitchAdv)))
            {
               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dSwitchAdv[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dSwitchAdv);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s]dGp2AcX[%.6f] - dSwitchAdv[%.6f] = %.6f\n", __FUNCTION__, dGp2AcX, dSwitchAdv, temp);
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;//通过mode_map选择常0输出，ac_ctrl1_timing
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;//通过mode_map选择常0输出，ac_ctrl1_timing
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}

/*参数13：S3取反    AC*_CAL_SW */
UINT32 Para13_S3Rev_AcCalSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    
    switch(acType)
    {
        case E_AC_TYPE_UL://只在AC位置置0
        case E_AC_TYPE_DL:
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            if (0 > (temp = (dGp2AcX - dSwitchAdv)))
            {
               dbgInfo("[%s] Err: dGp2AcX[%.6f] - dSwitchAdv[%.6f] < 0\n", __FUNCTION__, dGp2AcX, dSwitchAdv);
               return BSP_ERROR;
            }
            dbgInfoEx("[%s]dGp2AcX[%.6f] - dSwitchAdv[%.6f] = %.6f\n", __FUNCTION__, dGp2AcX, dSwitchAdv, temp);
            break;
        }
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;
            dbgInfoEx("[%s]Use para12, keep previous value. %.6f\n", __FUNCTION__, temp);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/*参数13    TRX_TXEN_AC  对应txatt 注意4.0上硬件连线反了，所以上下行AC起始位置取反了*/
UINT32 Para13_DlyOff_TrxTxEnAc(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_DL://只在AC位置置1
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            //return dGp2AcX - dSwitchAdv;
            if(0 > (temp = (dGp2AcX - dSwitchAdv)))
            {
                dbgInfo("[%s] Err: dGp2AcX[%.6f] < dSwitchAdv[%.6f]\n", __FUNCTION__, dGp2AcX, dSwitchAdv);
                return BSP_ERROR;
            }
            dbgInfoEx("[%s]dGp2AcX[%.6f] - dSwitchAdv[%.6f] = %.6f\n", __FUNCTION__, dGp2AcX, dSwitchAdv, temp);
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;//通过mode_map选择常1输出，ac_ctrl0_timing
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;//通过mode_map选择常1输出，ac_ctrl0_timing
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }

    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}

/*参数13    TRX_RXEN_AC*/
UINT32 Para13_DlyOff_TrxRxEnAc(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL://只在AC时刻置1
        {
            if(BSP_ERROR == dGp2Ac(acType, radio, &dGp2AcX))
            {
                dbgInfo("[%s]dGp2AcX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            //return (dGp2AcX - dSwitchAdv);
            if(0 > (temp = (dGp2AcX - dSwitchAdv)))
            {
                dbgInfo("[%s] Err: dGp2AcX[%.6f] < dSwitchAdv[%.6f]\n", __FUNCTION__, dGp2AcX, dSwitchAdv);
                return BSP_ERROR;
            }
            dbgInfoEx("[%s]dGp2AcX[%.6f] - dSwitchAdv[%.6f] = %.6f\n", __FUNCTION__, dGp2AcX, dSwitchAdv, temp);
            break;
        }
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;//通过mode_map选择常0输出，ac_ctrl1_timing
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }

    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
/********************************************************************/

/********************* 参数14：S1\S2取反\S3取反 *********************************/
/*参数14：S1   AC_TX_SW*/
UINT32 Para14_S1_AcTxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcEndX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL://只在AC位置置1
        {
            if(BSP_ERROR == dGp2AcEnd(acType, radio, &dGp2AcEndX))
            {
                dbgInfo("[%s]dGp2AcEndX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            temp = dGp2AcEndX;
            break;
        }
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}

/*参数14：S2取反    AC_RX_SW*/
UINT32 Para14_S2Rev_AcRxSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcEndX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    
    switch(acType)
    {
        case E_AC_TYPE_DL://只在AC位置置1
        {
            if(BSP_ERROR == dGp2AcEnd(acType, radio, &dGp2AcEndX))
            {
                dbgInfo("[%s]dGp2AcEndX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            temp = dGp2AcEndX;
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}

/*参数14：S3取反    AC_CAL_SW*/
UINT32 Para14_S3Rev_AcCalSw(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcEndX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;
    
    switch(acType)
    {
        case E_AC_TYPE_DL://只在AC位置置1
        case E_AC_TYPE_UL:
        {
            if(BSP_ERROR == dGp2AcEnd(acType, radio, &dGp2AcEndX))
            {
                dbgInfo("[%s]dGp2AcEndX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            temp = dGp2AcEndX;
            break;
        }
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
/*参数14    TRX_TXEN_AC [应用在上行AC固定发射/下行AC固定接收]*/
UINT32 Para14_DlyOff_TrxTxEnAc(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcEndX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_DL://只在AC位置置1
        {
            if(BSP_ERROR == dGp2AcEnd(acType, radio, &dGp2AcEndX))
            {
                dbgInfo("[%s]dGp2AcEndX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            temp = dGp2AcEndX + dSwitchDly;
            break;
        }
        case E_AC_TYPE_UL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }

    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}

/*参数14    TRX_RXEN_AC*/
UINT32 Para14_DlyOff_TrxRxEnAc(UINT32 acType, UINT32 radio)
{
    DOUBLE dGp2AcEndX = 0;
    DOUBLE temp = 0.0;
    UINT32 delay = 0;

    switch(acType)
    {
        case E_AC_TYPE_UL:
        {
            if(BSP_ERROR == dGp2AcEnd(acType, radio, &dGp2AcEndX))
            {
                dbgInfo("[%s]dGp2AcEndX error, acType %d, radio 0x%08X\n", __FUNCTION__, acType, radio);
                return BSP_ERROR;
            }
            temp = dGp2AcEndX + dSwitchDly;
            break;
        }
        case E_AC_TYPE_DL:
        case E_AC_TYPE_STOP:
        case E_DPD_TYPE_TS:
        case E_VSWR_TYPE_STOP:
        {
            temp = 0;
            break;
        }
        case E_AC_TYPE_FDD_DL:
        case E_AC_TYPE_FDD_UL:
        case E_AC_TYPE_FDD:
        {
            temp = 0;
            break;
        }
        default:
        {
            dbgInfo("[%s]input(%d) error\n", __FUNCTION__, acType);
            return BSP_ERROR;
            break;
        }
    }
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);
    return delay;
}
UINT32 Para13_AcEnDly(UINT32 acType, UINT32 radio,UINT32 acCtrlType)
{
    UINT32 ulRet = BSP_OK;

    switch(acCtrlType%3)
    {
        case 0:
        {
            ulRet = Para13_S1_AcTxSw(acType,radio);
            break;
        }
        case 1:
        {
            ulRet = Para13_S2Rev_AcRxSw(acType,radio);
            break;
        }
        case 2:
        {
            ulRet = Para13_S3Rev_AcCalSw(acType,radio);
            break;
        }
    }
    return ulRet;
}

UINT32 Para14_AcDisEnDly(UINT32 acType, UINT32 radio,UINT32 acCtrlType)
{
    UINT32 ulRet = BSP_OK;

    switch(acCtrlType%3)
    {
        case 0:
        {
            ulRet = Para14_S1_AcTxSw(acType,radio);
            break;
        }
        case 1:
        {
            ulRet = Para14_S2Rev_AcRxSw(acType,radio);
            break;
        }
        case 2:
        {
            ulRet = Para14_S3Rev_AcCalSw(acType,radio);
            break;
        }
    }
    return ulRet;
}
/********************************************************************/
/********************* 参数15: 不使用 *********************************/
UINT32 BspGetGpTimeAndUeAdvGap(UINT32 radio, DOUBLE *pGpTime, DOUBLE *pUeAdvGap)
{
    UINT32  GpNumX = 0;
    DOUBLE  d1SymTimeX = 0;
    DOUBLE  dUeAdvGapX = 0;

    INPUT_POINTER_CHECK(pGpTime);
    INPUT_POINTER_CHECK(pUeAdvGap);
    if(BSP_ERROR == GpNum(radio, &GpNumX))
    {
        dbgInfo("[%s]GetGpNum error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    if(BSP_ERROR == d1SymTime(radio, &d1SymTimeX))
    {
        dbgInfo("[%s]d1SymTimeX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    *pGpTime = GpNumX*d1SymTimeX;
    if(BSP_ERROR == dUeAdvGap(radio, &dUeAdvGapX))
    {
        dbgInfo("[%s]dUeAdvGapX error, radio 0x%08X\n", __FUNCTION__,radio);
        return BSP_ERROR;
    }
    *pUeAdvGap = dUeAdvGapX;
    dbgInfoEx("[%s]GpNumX[%d]*d1SymTimeX[%.6f]=*pGpTime[%.6f] dUeAdvGapX[%.6f]\n",
         __FUNCTION__, GpNumX, d1SymTimeX, *pGpTime, dUeAdvGapX);

    return BSP_OK;
}


/***********************************acctrl管脚基础参数生成*********************************************/
UINT32 Para1_DlyOff_AcSw(UINT32 acType, UINT32 radio,UINT32 acCtrlType)
{
    UINT32 delay = 0;
    DOUBLE temp = 0.0;
    UINT32 paraType = 0xff;

    switch(acCtrlType)
    {
        case AC0_CTRL_TX_SW:
             paraType = DLYOFF_ACTX0_SW1;
             break;
        case AC0_CTRL_RX_SW:
             paraType = DLYOFF_ACTX0_SW1;
             break;
        case AC0_CTRL_CAL_SW:
             paraType = DLYOFF_ACTX0_SW1;
             break;
        default:
            break;
    }
    BspFixRfSwitchPara(paraType, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}
UINT32 Para5_AdvOn_AcSw(UINT32 acType, UINT32 radio,UINT32 acCtrlType)
{
    UINT32 delay = 0;
    DOUBLE temp = 0.0;
    UINT32 paraType = 0xff;

    switch(acCtrlType)
    {
        case AC0_CTRL_TX_SW:
             paraType = ADVON_ACTX0_SW5;
             break;
        case AC0_CTRL_RX_SW:
             paraType = ADVON_ACRX0_SW5;
             break;
        case AC0_CTRL_CAL_SW:
             paraType = ADVON_ACCAL0_SW5;
             break;
        default:
            break;
    }
    BspFixRfSwitchPara(paraType, acType, radio ,&temp);
    delay = DOUBLE_US_2_UINT32_737(temp);
    dbgInfoEx("[%s]input(%d, %d), %.6f(us), retVal = 0x%08X(%d)\n", __FUNCTION__, acType, radio, temp, delay, delay);

    return delay;
}

UINT32 BspGetD1GpTime45G(VOID)
{
    return d1GpTime45G;
}

UINT32 BspGetDUeAdv45G(VOID)
{
    return dUeAdv45G;
}
/* Started by AICoder, pid:ge6e0u838am75ae1435e08534095bf0210b425c6 */
DOUBLE BspGetPaAdvOn(VOID)
{
    return dPaAdvOn;
}
/* Ended by AICoder, pid:ge6e0u838am75ae1435e08534095bf0210b425c6 */

/* Started by AICoder, pid:b8254ufb08v8168143cc0a49b0a9e70406982263 */
DOUBLE BspGetPaDlyOff(VOID)
{
    return dPaDlyOff;
}
/* Ended by AICoder, pid:b8254ufb08v8168143cc0a49b0a9e70406982263 */

/* Started by AICoder, pid:r860ev032erb96e149b60ae582de6f56e103a35c */
/*********************************************参数2**************************************************/
UINT32 BspCalAacPara2_DlyOff_PaTxSw(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara)
{
    DOUBLE tmpVal = 0.0;
    UINT32 retVal = 0;
    DOUBLE gpTime   = 0.0;
    DOUBLE ueAdvGap = 0.0;
    DOUBLE dmixAdvDiffCompVal = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            retVal = BspGetGpTimeAndUeAdvGap(radio, &gpTime, &ueAdvGap);
            CHECK_RETVAL_PRN(BspGetGpTimeAndUeAdvGap, retVal);
            retVal = dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);
            CHECK_RETVAL_PRN(dMixAdvDiffComp, retVal);
            tmpVal = gpTime - ueAdvGap - s_TddIoBaseParaInfo.lnaAdvOn - dmixAdvDiffCompVal - s_aacProtectVal;
            break;
        }
        default:
        {
            break;
        }
    }
    *pTmpPara = tmpVal;
    dbgInfoEx("[%s] %.6f(us) \n", __FUNCTION__, tmpVal);

    return retVal;
}

UINT32 BspCalAacPara2_DlyOff_TrxTxEn(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara)
{
    DOUBLE tmpVal = 0.0;
    UINT32 retVal = 0;
    DOUBLE gpTime   = 0.0;
    DOUBLE ueAdvGap = 0.0;
    DOUBLE dmixAdvDiffCompVal = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            retVal = BspGetGpTimeAndUeAdvGap(radio, &gpTime, &ueAdvGap);
            CHECK_RETVAL_PRN(BspGetGpTimeAndUeAdvGap, retVal);
            retVal = dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);
            CHECK_RETVAL_PRN(dMixAdvDiffComp, retVal);
            tmpVal = gpTime - ueAdvGap  - s_TddIoBaseParaInfo.rxEnAdvOn - dmixAdvDiffCompVal - s_aacProtectVal;
            break;
        }
        default:
        {
            break;
        }
    }
    *pTmpPara = tmpVal;
    dbgInfoEx("[%s] %.6f(us) \n", __FUNCTION__, tmpVal);

    return retVal;
}

UINT32 BspCalAacPara2_DlyOff_AmpSw(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara)
{
    DOUBLE tmpVal = 0.0;
    UINT32 retVal = 0;
    DOUBLE gpTime   = 0.0;
    DOUBLE ueAdvGap = 0.0;
    DOUBLE dmixAdvDiffCompVal = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            retVal = BspGetGpTimeAndUeAdvGap(radio, &gpTime, &ueAdvGap);
            CHECK_RETVAL_PRN(BspGetGpTimeAndUeAdvGap, retVal);
            retVal = dMixAdvDiffComp(radio, &dmixAdvDiffCompVal);
            CHECK_RETVAL_PRN(dMixAdvDiffComp, retVal);
            tmpVal = gpTime - ueAdvGap - s_TddIoBaseParaInfo.lnaAdvOn - dmixAdvDiffCompVal - s_aacProtectVal;
            break;
        }
        default:
        {
            break;
        }
    }
    *pTmpPara = tmpVal;
    dbgInfoEx("[%s] %.6f(us) \n", __FUNCTION__, tmpVal);

    return retVal;
}

/*********************************************参数8**************************************************/
UINT32 BspCalAacPara8_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara)
{
    DOUBLE tmpVal = 0.0;
    UINT32 retVal = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            tmpVal = s_TddIoBaseParaInfo.paDlyOff + s_aacProtectVal;
            break;
        }
        default:
        {
            break;
        }
    }
    *pTmpPara = tmpVal;

    return retVal;
}

UINT32 BspCalAacPara8_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara)
{
    DOUBLE tmpVal = 0.0;
    UINT32 retVal = 0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            tmpVal = s_TddIoBaseParaInfo.txEnDlyOff + s_aacProtectVal;
            break;
        }
        default:
        {
            break;
        }
    }
    *pTmpPara = tmpVal;

    return retVal;
}

/*********************************************参数7**************************************************/
UINT32 BspCalAacPara7_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara)
{
    DOUBLE tmpVal = 0.0;
    UINT32 retVal = 0;
    DOUBLE gpTime   = 0.0;
    DOUBLE ueAdvGap = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            retVal = BspGetGpTimeAndUeAdvGap(radio, &gpTime, &ueAdvGap);
            CHECK_RETVAL_PRN(BspGetGpTimeAndUeAdvGap, retVal);
            tmpVal = gpTime - ueAdvGap - s_TddIoBaseParaInfo.lnaAdvOn;
            break;
        }
        default:
        {
            break;
        }
    }
    *pTmpPara = tmpVal;
    dbgInfoEx("[%s] %.6f(us) \n", __FUNCTION__, tmpVal);

    return retVal;
}

UINT32 BspCalAacPara7_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara)
{
    DOUBLE tmpVal = 0.0;
    UINT32 retVal = 0;
    DOUBLE gpTime   = 0.0;
    DOUBLE ueAdvGap = 0.0;

    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            retVal = BspGetGpTimeAndUeAdvGap(radio, &gpTime, &ueAdvGap);
            CHECK_RETVAL_PRN(BspGetGpTimeAndUeAdvGap, retVal);
            tmpVal = gpTime - ueAdvGap  - s_TddIoBaseParaInfo.rxEnAdvOn;
            break;
        }
        default:
        {
            break;
        }
    }
    *pTmpPara = tmpVal;
    dbgInfoEx("[%s] %.6f(us) \n", __FUNCTION__, tmpVal);

    return retVal;
}

T_AacRfSwitchParaCal s_aacRfSwitchParaCal[PARA_TYPE_NUM] =
{
    {DLYOFF_PA2,      BspCalAacPara2_DlyOff_PaTxSw    ,    "BspCalAacPara2_DlyOff_PaTxSw"},
    {DLYOFF_TXEN2,    BspCalAacPara2_DlyOff_TrxTxEn   ,    "BspCalAacPara2_DlyOff_TrxTxEn"},
    {DLYOFF_AMP2,     BspCalAacPara2_DlyOff_AmpSw     ,    "BspCalAacPara2_DlyOff_AmpSw"},
    {ADVON_LNAPWR7,   BspCalAacPara7_AdvOn_LnaRxPwr   ,    "BspCalAacPara7_AdvOn_LnaRxPwr"},
    {ADVON_RXEN7,     BspCalAacPara7_AdvOn_TrxRxEn    ,    "BspCalAacPara7_AdvOn_TrxRxEn"},
    {ADVON_LNAPWR8,   BspCalAacPara8_AdvOn_LnaRxPwr   ,    "BspCalAacPara8_AdvOn_LnaRxPwr"},
    {ADVON_RXEN8,     BspCalAacPara8_AdvOn_TrxRxEn    ,    "BspCalAacPara8_AdvOn_TrxRxEn"},
};

/*使用单板下回调的接口计算开关的时序参数*/
DOUBLE BspAacRfSwitchCalPara(UINT32 ioParaType,UINT32 acType, UINT32 radio)
{
    UINT32 loop = 0;
    DOUBLE tmp = 0.0;

    if(s_aacRfSwitchParaUpdateSw == AAC_RF_SWITCH_PARA_UPDATE_ON) /* 只有AAC使能时更新时延值，去使能后恢复原来的值 */
    {
        for(loop = 0; loop < PARA_TYPE_NUM; loop++)
        {
            if(s_aacRfSwitchParaCal[loop].ioParaType == ioParaType)
            {
                if(NULL != s_aacRfSwitchParaCal[loop].pFunc)
                {
                    s_aacRfSwitchParaCal[loop].pFunc(acType, radio, &tmp);
                }
                break;
            }
        }
    }

    return tmp;   /*没挂接的参数，这里返回0  目前看没问题  但是如果需要保持之前的值，可以改tmp的默认值为异常值，pa模块取的时候判断下*/
}

void BspSetAacRfSwitchParaUpdateSw(UINT32 sw)
{
    s_aacRfSwitchParaUpdateSw = sw;
    return ;
}
/* Ended by AICoder, pid:r860ev032erb96e149b60ae582de6f56e103a35c */

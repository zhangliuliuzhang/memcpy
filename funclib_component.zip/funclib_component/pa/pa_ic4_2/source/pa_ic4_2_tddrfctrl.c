/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_ic4_2_tddrfctrl.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 原始作者 : N/A
* 创建日期 :
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: N/A
* 修改日戳:
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "io_ctrl.h"
//#include "antcalcommon.h"
#include "funccommon_a.h"
#include "pa_ic4_2_calcpara.h"
#include "pa_ic4_2_ctrl.h"
#include "exprn.h"
#include "chnmap_a.h"
#include "pacommon.h"
#include "io_api.h"
#include "devdrv_transceiver.h"
#include "funccommon_log.h"
#include "pa_ic4_2_calcpara.h"
#include "freqcfgcommon.h"
/******************************************************************************************
                             宏、全局变量 辅助性接口等定义
******************************************************************************************/
#define IOCTRL_HELP_LEN (200)
#define TDDIO_RECORD_MAX_NUM ((UINT32)20)
#define IS_CONFIG_OK  (UINT32)(1)
#define INVALID_TDDID (UINT32)(0xffff)


static UINT32 s_rfSwitchCtrlMethod = E_RF_SWITCH_EPLD_CTRL_INNER;//E_RF_SWITCH_EPLD_CTRL_EXT 为默认外扩FPGA
static UINT32 s_rfSwitchTddModeMapNum = E_AC_TYPE_NUM;//默认是12个，实际看配置
static UINT32 s_rfSwitchTddSwModeSel[DPDIC_MAX_TDD_NUM] = {E_AC_TYPE_STOP};  //初始化，默认正常TDD
static T_TDDIO_EXCEPT_CTRL s_tddIoExceptCtrlX = {E_TDDIO_CTRL_NORMAL,};
static UINT32 s_avoidHardwareFlag = 0;

UINT32 BspSkipTxEnOeX = 0;

/*基础时序参数*/
T_PA_LNA_CFG g_paLnaPara[DPDIC_MAX_TDD_NUM] = {0};
T_AMP_CFG g_AmpPara[DPDIC_MAX_TDD_NUM] = {0};
T_TRANS_CFG g_transPara[DPDIC_MAX_TDD_NUM] = {0};
T_AC_CTRL_CFG g_acCtrlPara[DPDIC_MAX_TDD_NUM][AC_CTRL_TYPE_NUM] = {0};
T_AC_CTRL_FDD_CFG g_acCtrlFddPara[DPDIC_MAX_TDD_NUM][AC_CTRL_TYPE_NUM] = {0};
T_TRX_ACINSLOT_PARA g_trxAcInslotPara[DPDIC_MAX_TDD_NUM] = {0};
/*mux配置*/
T_TDD_BASE_PALNAAMP_OUT_CFGA g_paMux[TDD_IO_PIN_NUM_COMMON_8] = {0};
T_TDD_BASE_PALNAAMP_OUT_CFGA g_lnaMux[TDD_IO_PIN_NUM_COMMON_8] = {0};
T_TDD_BASE_PALNAAMP_OUT_CFGA g_ampMux[TDD_IO_PIN_NUM_COMMON_8]={0};
T_TDD_BASE_SW_OUT_CFG g_transTxMux[TDD_IO_PIN_NUM_COMMON_4]= {0};
T_TDD_BASE_SW_OUT_CFG g_transRxMux[TDD_IO_PIN_NUM_COMMON_4]= {0};
T_TDD_BASE_ORX_OUT_CFG g_transOrxMux[TDD_IO_PIN_NUM_COMMON_4]= {0};
T_COMB_2INSTANTIATE_PARA g_trxAcEnMux[TDD_IO_PIN_TRX_EN_AC_NUM_2] = {0};
T_AC_CTRL_SW_OUT_CFG g_acCtrlMux[AC_CTRL_TYPE_NUM] = {0};

UINT32 g_tddIoPrnFlag = 0;
UINT32 g_extTddIoPrnFlag = SWITCH_ON;

T_TDD_IO_RECORD_INFO g_tddIoRecordInfo[TDDIO_RECORD_MAX_NUM] = {0};

UINT32 g_tddIoRecordCnt = 0;
UINT32 g_fddIoRecordCnt = 0;
UINT32 g_tddIoErrRcdRadioCnt = 0;
UINT32 g_tddIoErrRcdAcTypeCnt = 0;
UINT32 g_tddIoBoardDiffFlag = 0;
/*dtx相关*/
T_DL_DTX_SEL g_PaDtxPara[DTX_CHAN_MAX] = {0};
T_DL_DTX_SEL g_AmpDtxPara[DTX_CHAN_MAX] = {0};
T_DL_DTX_SEL g_TxDtxPara[DTX_CHAN_MAX] = {0};
T_UL_DTX_SEL g_LnaDtxPara[TDD_IO_PIN_NUM_COMMON_8] = {0};
T_UL_DTX_SEL g_RxDtxPara[TDD_IO_PIN_NUM_COMMON_8] = {0};
UINT32 DlyDlDtxOutSelX[TDD_IO_PIN_NUM_COMMON_8] = {0};

UINT32 DlyDlDtxTrxOutSelX[TDD_IO_PIN_NUM_COMMON_8] = {0};
UINT32 DlyDlDtxPaOutSelX[TDD_IO_PIN_NUM_COMMON_8] = {0};
UINT32 DlyDlDtxAmpOutSelX[TDD_IO_PIN_NUM_COMMON_8] = {0};

UINT32 g_ulAcBandNo = 0;    /*UBR支持多频段分开做ac 需要设置频段信息 通知funclib切换时序参数和开关*/
static T_TDDIO_FDDAC_BASE_PARA *s_ulTddIoFddAcPara =NULL;     /*FDD AC开关基础时序生成 参数初始化*/
static UINT32              s_TddIoFddAcParaNum       = 0;
/* Started by AICoder, pid:958bc57fee17529145ea0a2950c0bb195d564c53 */
UINT32 support_utdoa = UTDOA_NOT_SUPPORT;
FUNC_GET_CHAN_MASK_BY_TDDID p_FuncGetChanMaskByTddId = NULL;
UINT32 acidx_corr_tddid[AC_CTRL_TYPE_NUM] = {\
INVALID_TDDID, INVALID_TDDID, INVALID_TDDID, INVALID_TDDID,\
INVALID_TDDID, INVALID_TDDID, INVALID_TDDID, INVALID_TDDID, INVALID_TDDID
};
UINT32* BspGetAcIdxCorrTddId(VOID)
{
    return &(acidx_corr_tddid[0]);
}
VOID BspSetUtSupportFlag(UINT32 supportFlag)
{
    support_utdoa = supportFlag;
}
/* Ended by AICoder, pid:958bc57fee17529145ea0a2950c0bb195d564c53 */

T_TDDIO_CONCTRL_PARA g_ulTddIoControlPara = {0};
T_TDD_CONCTRL_BASE_TIMING_GEN g_tddTimingGenSel[DPDIC_MAX_TIMING_GEN_SEL_TYPE]=
{
    {  /*tdd目前使用此套参数*/
       {  /*PA/LNA使用的T_TDD_BASE_TIMING_GEN_SEL  只有tx_timing和rx_timing*/
           {TDD_BASE_TX_FALL1,TDD_BASE_TX_RISE1},    /** T_TDD_BASE_TX_TIMING_SEL tTxTiming --产生tx_timing时序的选择 */
           {TDD_BASE_TX_FALL2,TDD_BASE_TX_RISE1},    /**T_TDD_BASE_TX_TIMING_SEL      --产生tx_ac_timing时序的选择*/
           {0,0,0,0}, /**T_TDD_BASE_TX_ACINSLOT_TIMING_SEL tTxAcInslotTiming-- 产生tx_acinslot_timing时序的选择,TDD不使用此模式，参数先置为0*/
           {TDD_BASE_RX_RISE2,TDD_BASE_RX_FALL1},    /** T_TDD_BASE_RX_TIMING_SEL tRxTiming-- 产生rx_timing时序的选择 */
           {TDD_BASE_RX_RISE1,TDD_BASE_RX_FALL1},    /** T_TDD_BASE_RX_TIMING_SEL tRxAcTiming --产生rx_ac_timing时序的选择 */
           {0,0,0,0}, /**T_TDD_BASE_RX_ACINSLOT_TIMING_SEL tRxAcInslotTiming --产生tRxAcInslotTiming时序的选择,TDD不使用此模式，参数先置为0*/
       },
       {   /*TR  X使用的T_TRX_BASE_TIMING_GEN_SEL 区分校准和非校准通道所以有*x_timing和*x_ac_timing*/
           { /*TX_EN RX_EN使用*/
               {TDD_BASE_TX_FALL1,TDD_BASE_TX_RISE1},     /** T_TDD_BASE_TX_TIMING_SEL tTxTiming --产生tx_timing时序的选择 */
               {TDD_BASE_TX_FALL2,TDD_BASE_TX_RISE1},     /** T_TDD_BASE_TX_TIMING_SEL tTxAcTiming-- 产生tx_ac_timing时序的选择 */
               {0,0,0,0},/**T_TDD_BASE_TX_ACINSLOT_TIMING_SEL tTxAcInslotTiming-- 产生tx_acinslot_timing时序的选择,TDD不使用此模式，参数先置为0*/
               {TDD_BASE_RX_RISE2,TDD_BASE_RX_FALL1},  /** T_TDD_BASE_RX_TIMING_SEL tRxTiming-- 产生rx_timing时序的选择 */
               {TDD_BASE_RX_RISE1,TDD_BASE_RX_FALL1},     /** T_TDD_BASE_RX_TIMING_SEL tRxAcTiming --产生rx_ac_timing时序的选择 */
               {0,0,0,0},/**T_TDD_BASE_RX_ACINSLOT_TIMING_SEL tRxAcInslotTiming --产生tRxAcInslotTiming时序的选择,TDD不使用此模式，参数先置为0*/
           },
           { /*ORX_EN使用 目前看ORX_EN直接读TX_EN取反，以下参数未使用*/
               {TDD_BASE_TX_FALL1,TDD_BASE_TX_RISE1},
               {TDD_BASE_TX_FALL2,TDD_BASE_TX_RISE1},
               {0,0,0,0},
               {TDD_BASE_RX_RISE2,TDD_BASE_RX_FALL1},
               {TDD_BASE_RX_RISE1,TDD_BASE_RX_FALL1},
               {0,0,0,0},
           },
       },
       {  /*AMP使用的T_TDD_BASE_TIMING_GEN_SEL  amp不需要上行的控制信号,所以只有tx_timing*/
           {TDD_BASE_TX_FALL1,TDD_BASE_TX_RISE1},    /**T_TDD_BASE_TX_TIMING_SEL tTxTiming --产生tx_timing时序的选择 */
           {TDD_BASE_TX_FALL2,TDD_BASE_TX_RISE1},    /**T_TDD_BASE_TX_TIMING_SEL tTxAcTiming-- 产生tx_ac_timing时序的选择 */
           {0,0,0,0},                                /**T_TDD_BASE_TX_ACINSLOT_TIMING_SEL tTxAcInslotTiming-- 产生tx_acinslot_timing时序的选择,TDD不使用此模式，参数先置为0*/
           {0,0},                                     /**T_TDD_BASE_RX_TIMING_SEL tRxTiming-- 产生rx_timing时序的选择 */
           {0,0},                                    /**T_TDD_BASE_RX_TIMING_SEL tRxAcTiming --产生rx_ac_timing时序的选择 */
           {0,0,0,0},                                /**T_TDD_BASE_RX_ACINSLOT_TIMING_SEL tRxAcInslotTiming --产生tRxAcInslotTiming时序的选择,TDD不使用此模式，参数先置为0*/
       },
    },
    { /*fdd 目前使用此套参数 要么使用常1 要么使用ac-inslot-timing，*_timing和*_ac_timing其实不使用 */
       {  /*PA/LNA使用的T_TDD_BASE_TIMING_GEN_SEL 没分校准和非校准 不使用*_timing和*_ac_timing一直常1*/
           {0,0},
           {0,0},
           {0,0,DL_AC_IN_SLOT,TDD_BASE_AC_INSLOT_TIMING_AND_REV},
           {0,0},
           {0,0},
           {0,0,UL_AC_IN_SLOT,TDD_BASE_AC_INSLOT_TIMING_AND_REV},
       },
       { /*TRX使用的T_TRX_BASE_TIMING_GEN_SEL*/
           { /*TX_EN RX_EN使用*/
               {0,0}, /** tx_timing时序不使用 直接选择常1输出*/
               {0,0}, /** tx_ac_timing时序不使用 */
               /* tx_acinslot_timing时序,马工意思TX_BASE产生的0和AC_BASE产生inslot信号或产生此信号，
                * TX_BASE输出长高，TDD_BASE_TX_FALL1 TDD_BASE_TX_RISE1只是临时添加，和粘琳理解这两个参数不需要 反向与，才能保证inslot-timing的输出由AC_BASE决定*/
               {TDD_BASE_TX_FALL1,TDD_BASE_TX_RISE1,DL_AC_IN_SLOT,TDD_BASE_AC_INSLOT_TIMING_AND_REV},
               {0,0}, /** rx_timing时序不使用 *直接选择常1输出*/
               {0,0}, /** rx_ac_timing时序不使用 */
               /* rx_acinslot_timing时序,马工意思RX_BASE产生的0和AC_BASE产生inslot信号或产生此信号，如何产生0信号待确认，TDD_BASE_RX_FALL1 TDD_BASE_RX_RISE1只是临时添加，和粘琳理解这两个参数不需要*/
               {TDD_BASE_RX_RISE1,TDD_BASE_RX_FALL1,UL_AC_IN_SLOT,TDD_BASE_AC_INSLOT_TIMING_AND_REV},
           },
           { /*ORX_EN使用 目前看ORX_EN直接读TX_EN取反，以下参数未使用*/
               {0,0}, /** tx_timing时序不使用 直接选择常1输出*/
               {0,0}, /** tx_ac_timing时序不使用 */
               /* tx_acinslot_timing时序,马工意思TX_BASE产生的0和AC_BASE产生inslot信号或产生此信号，
                * TX_BASE输出长高，TDD_BASE_TX_FALL1 TDD_BASE_TX_RISE1只是临时添加，和粘琳理解这两个参数不需要 反向与，才能保证inslot-timing的输出由AC_BASE决定*/
               {TDD_BASE_TX_FALL1,TDD_BASE_TX_RISE1,DL_AC_IN_SLOT,TDD_BASE_AC_INSLOT_TIMING_AND_REV},
               {0,0}, /** rx_timing时序不使用 *直接选择常1输出*/
               {0,0}, /** rx_ac_timing时序不使用 */
               /* rx_acinslot_timing时序,马工意思RX_BASE产生的0和AC_BASE产生inslot信号或产生此信号，如何产生0信号待确认，TDD_BASE_RX_FALL1 TDD_BASE_RX_RISE1只是临时添加，和粘琳理解这两个参数不需要*/
               {TDD_BASE_RX_RISE1,TDD_BASE_RX_FALL1,UL_AC_IN_SLOT,TDD_BASE_AC_INSLOT_TIMING_AND_REV},
           },
       },
       {  /*AMP使用的T_TDD_BASE_TIMING_GEN_SEL  amp不需要上行的控制信号 不使用*_timing和*_ac_timing 一直常1*/
           {0,0},
           {0,0},
           {0,0,0,0},
           {0,0},
           {0,0},
           {0,0,0,0},
       },
    },
};

/*ac模块tddtiminggen参数配置*/
T_AC_CTRL_TIMING_GEN_SEL g_tddAcTimingGenSel[DPDIC_MAX_TIMING_GEN_SEL_TYPE] =
{
       {
           {TDD_BASE_TX_FALL1,TDD_BASE_TX_RISE1},    /**T_TDD_BASE_TX_TIMING_SEL tTxTiming --产生tx_timing时序的选择 */
           {TDD_BASE_TX_FALL2,TDD_BASE_TX_RISE1},    /**T_TDD_BASE_TX_TIMING_SEL tTxAcTiming-- 产生tx_ac_timing时序的选择 */
           {0,0,0,0},                                /**T_TDD_BASE_TX_ACINSLOT_TIMING_SEL tTxAcInslotTiming-- 产生tx_acinslot_timing时序的选择,TDD不使用此模式，参数先置为0*/
           {0,0},                                     /**T_TDD_BASE_RX_TIMING_SEL tRxTiming-- 产生rx_timing时序的选择 */
           {0,0},                                    /**T_TDD_BASE_RX_TIMING_SEL tRxAcTiming --产生rx_ac_timing时序的选择 */
           {0,0,0,0},                                /**T_TDD_BASE_RX_ACINSLOT_TIMING_SEL tRxAcInslotTiming --产生tRxAcInslotTiming时序的选择,TDD不使用此模式，参数先置为0*/
       },
};
VOID showboardioexcept(VOID)
{

}
/*打印开关 打印时延delay和mux开关*/
UINT32 BspSetTddIoPrnFlag(UINT32 flag)
{
    g_tddIoPrnFlag = flag;
    return BSP_OK;
}
/******************************************************************************************
                            模块初始化相关接口定义
******************************************************************************************/
/*board 单板差异化处理标志，目前965x上用此标志判断是否初始化第二套TDD 4.2可能会不同通道同时存在多套TDD*/
UINT32 BspSetTddIoBoardDiffFlag(UINT32 Flag)
{
    g_tddIoBoardDiffFlag = Flag;
    return BSP_OK;
}

UINT32 BspGetTddIoBoardDiffFlag(VOID)
{
    return g_tddIoBoardDiffFlag;
}
/*board 单板差异化硬件规避标志 部分硬件连线错误，需要兼容处理暂时保留接口*/
UINT32 BspSetAvoidHardwareFlag(UINT32 flag)
{
    s_avoidHardwareFlag = flag;
    return BSP_OK;
}
/*board 设置各个管脚的高低电平，默认是高电平E_TDDIO_CTRL_NORMAL 如果硬件取反，需要置值为E_TDDIO_CTRL_EXCEPT 对应单板下接口BspBoardTddIoExceptCtrl*/
UINT32 BspTddIoExceptCtrl(T_TDDIO_EXCEPT_CTRL* tddIoExcept)
{
    INPUT_POINTER_CHECK(tddIoExcept);
    /*要求结构体全量配置，不允许单个赋值*/
    memset_s((VOID*)&s_tddIoExceptCtrlX, sizeof(T_TDDIO_EXCEPT_CTRL), 0, sizeof(T_TDDIO_EXCEPT_CTRL));
    memcpy_s((VOID*)&s_tddIoExceptCtrlX, sizeof(T_TDDIO_EXCEPT_CTRL), (VOID*)tddIoExcept, sizeof(T_TDDIO_EXCEPT_CTRL));
    return BSP_OK;
}
/*目前未调用，用以标识射频开关控制是通过内部IO 还是外部fpga,目前都是前一种*/
UINT32 BspInitRfSwitchCtrlMethod(UINT32 epldMethod)
{
    s_rfSwitchCtrlMethod = epldMethod;
    return BSP_OK;
}
UINT32 BspGetRfSwitchCtrlMethod(VOID)
{
    return s_rfSwitchCtrlMethod;
}
/*board 初始化设置支持的mode_map最大种类数，条件判断时使用，详见方案中图2.3 mode_map寄存器示意图*/
UINT32 BspInitRfSwitchCtrlTddModeMapNum(UINT32 TddModeMapNum)
{
    s_rfSwitchTddModeMapNum = TddModeMapNum;
    return BSP_OK;
}
UINT32 BspGetRfSwitchCtrlTddModeMapNum(VOID)
{
    return s_rfSwitchTddModeMapNum;
}
/******************************************************************************************
                             开关状态获取
******************************************************************************************/
/*从hal读回来的状态需要转成funclib使用的开关状态 即0：常1；1：常0；2：前级信号；3：前级信号取反  -->转换成funclib的开关状态on off on_fdd*/
UINT32 BspGetIoSwitchStatus(UINT32 muxSel)
{
   UINT32 sta = SWITCH_OFF;

   switch(muxSel)
   {
       case IO_OUT_SEL_PRE_SIG:   //前级信号
       {
           sta = SWITCH_ON;
           break;
       }
       case IO_OUT_SEL_ZERO:   //常0，关
       {
           sta = SWITCH_OFF;
           break;
       }
       case IO_OUT_SEL_ONE:   //常1，FDD开
       {
           sta = SWITCH_ON_FDD;
           break;
       }
       default:
       {
           dbgErr("[%s] MUX is error!!! MuxSel is %d\n", __FUNCTION__, muxSel);
           break;
       }
   }
   return sta;
}

UINT32 BspGetIoSwitchStatus_Lna(UINT32 muxSel)
{
    UINT32 sta = SWITCH_OFF;

    switch(muxSel)
    {
        case IO_OUT_SEL_PRE_SIG_REV:   /*lna与其他开关不一样，是前级取反*/
        {
            sta = SWITCH_ON;
            break;
        }
        case IO_OUT_SEL_ONE:   //常1，表示关
        {
            sta = SWITCH_OFF;
            break;
        }
        case IO_OUT_SEL_ZERO:   //常0，FDD开
        {
            sta = SWITCH_ON_FDD;
            break;
        }
        default:
        {
            dbgErr("[%s] MUX is error!!! MuxSel is %d\n", __FUNCTION__, muxSel);
            break;
        }
    }
    return sta;
}
/*pa trx反馈开关状态由于单板初始化存在对射频开关高低电平有效的例外处理，所以获取状态的时候也要有对应转换*/
UINT32 BspGetIoSwitchStatus_Fb(UINT32 muxSel)
{
    UINT32 sta = SWITCH_OFF;

    switch(muxSel)
    {
        case IO_ORX_OUT_SEL_TRX_RXEN_REV:   //trx_rx_en信号取反
        {
            sta = SWITCH_ON;
            break;
        }
        case IO_ORX_OUT_SEL_ZERO:   //常0，关
        {
            sta = SWITCH_OFF;
            break;
        }
        case IO_ORX_OUT_SEL_ONE:   //常1，FDD开
        {
            sta = SWITCH_ON_FDD;
            break;
        }
        default:
        {
            dbgErr("[%s] MUX is error!!! MuxSel is %d\n", __FUNCTION__, muxSel);
            break;
        }
    }
    return sta;
}
/*pa ACCTRL开关状态由于单板初始化存在对射频开关高低电平有效的例外处理，所以获取状态的时候也要有对应转换*/
UINT32 BspGetIoSwitchStatus_AcCtrl_Tx(UINT32 muxSel)
{
    UINT32 sta = SWITCH_OFF;

    switch(muxSel)
    {
        case IO_OUT_SEL_PRE_SIG:   //前级信号
        {
            sta = SWITCH_ON;
            break;
        }
        case IO_OUT_SEL_ZERO:   //常0，关
        {
            sta = SWITCH_OFF;
            break;
        }
        case IO_OUT_SEL_ONE:   //常1，FDD开
        {
            sta = SWITCH_ON_FDD;
            break;
        }
        default:
        {
            dbgErr("[%s] MUX is error!!! MuxSel is %d\n", __FUNCTION__, muxSel);
            break;
        }
    }
    return sta;
}
/*pa ACCTRL开关状态由于单板初始化存在对射频开关高低电平有效的例外处理，所以获取状态的时候也要有对应转换*/
UINT32 BspGetIoSwitchStatus_AcCtrl_RxCal(UINT32 muxSel)
{
    UINT32 sta = SWITCH_OFF;

    switch(muxSel)
    {
        case IO_OUT_SEL_PRE_SIG_REV:   //前级信号取反
        {
            sta = SWITCH_ON;
            break;
        }
        case IO_OUT_SEL_ZERO:   //常0，开
        {
            sta = SWITCH_ON_FDD;
            break;
        }
        case IO_OUT_SEL_ONE:   //常1，关
        {
            sta = SWITCH_OFF;
            break;
        }
        default:
        {
            dbgErr("[%s] MUX is error!!! MuxSel is %d\n", __FUNCTION__, muxSel);
            break;
        }
    }
    return sta;
}
UINT32 BspGetAcCtrlSwitchCtrl(UINT32 type)
{
    UINT32 acCtrlSwCtrl    = AC_CTRL_SWITCH_OFF;
    UINT32 acCtrlMuxRst    = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;

    ret = BspHalAdaptGetAcCtrlOutSel(type, &acCtrlMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    switch(type)
    {
        case AC0_CTRL_TX_SW:
        case AC1_CTRL_TX_SW:
        case AC2_CTRL_TX_SW:
        {
            acCtrlSwCtrl = BspGetIoSwitchStatus_AcCtrl_Tx(acCtrlMuxRst);
            break;
        }
        case AC0_CTRL_RX_SW:
        case AC0_CTRL_CAL_SW:
        case AC1_CTRL_RX_SW:
        case AC1_CTRL_CAL_SW:
        case AC2_CTRL_RX_SW:
        case AC2_CTRL_CAL_SW:
        {
            acCtrlSwCtrl = BspGetIoSwitchStatus_AcCtrl_RxCal(acCtrlMuxRst);
            break;
        }
        default:
        {
            dbgInfo("[%s] AcCtrl Type is Error!!! Type = %d.\n", __FUNCTION__, type);
            break;
        }
    }

    return acCtrlSwCtrl;
}

UINT32 BspGetTddIoOutSel(UINT32 ioIdx,UINT32 ioType, UINT32 *uiSel)
{
    UINT32 ret = BSP_ERROR;

    switch(ioType)
    {
        case LINK_INFO_PACHN_TDDIO:
        {
             ret = BspHalAdaptGetPaOutSel(ioIdx, uiSel);
             break;
        }
        case LINK_INFO_AMPCHN_TDDIO:
        {
             ret = BspHalAdaptGetAmpOutSel(ioIdx, uiSel);
             break;
        }
        case LINK_INFO_LNACHN_TDDIO:
        {
             ret = BspHalAdaptGetLnaOutSel(ioIdx, uiSel);
             break;
        }
        case LINK_INFO_TXCHN_TDDIO:
        {
             ret = BspHalAdaptGetTrxTxEnOutSel(ioIdx, uiSel);
             break;
        }
        case LINK_INFO_RXCHN_TDDIO:
        {
             ret = BspHalAdaptGetTrxRxEnOutSel(ioIdx, uiSel);
             break;
        }
        case LINK_INFO_FBCHN_TDDIO:
        {
             ret = BspHalAdaptGetTrxFbEnOutSel(ioIdx, uiSel);
             break;
        }
        default:
        {
             break;
        }
    }
    return ret;
}
UINT32 BspGetTddIoSwitch(UINT32 ioType,UINT32 muxSel)
{
    UINT32 sta = SWITCH_OFF;

    switch(ioType)
    {
        case LINK_INFO_FBCHN_TDDIO:
        {
             sta = BspGetIoSwitchStatus_Fb(muxSel);
              break;
        }
        case LINK_INFO_LNACHN_TDDIO:
        {
             sta = BspGetIoSwitchStatus_Lna(muxSel);
              break;
        }
        case LINK_INFO_PACHN_TDDIO:
        case LINK_INFO_AMPCHN_TDDIO:
        case LINK_INFO_TXCHN_TDDIO:
        case LINK_INFO_RXCHN_TDDIO:
        default:
        {
             sta = BspGetIoSwitchStatus(muxSel);
             break;
        }
    }

    return sta;
}

/******************************************************************************************
                             模式\tdd选择、参数初始化（注意没有TI器件的相关控制）
******************************************************************************************/
/***************************************************************************
每套TDD中的mode_map选择 tddSel表示用哪一套tdd,而modeSel 即表示正常TDD TDD_AC 等模式
(1)ac模块会设置对应的ac模式
(2)tddcfg模块会配置TDD模式
(3)对DPD模块，TS功能使能时设置E_TDD_TYPE_TS模式否则是正常TDD模式E_TDD_TYPE_NORMAL
(4)此接口只是记录，没有实际配置动作，其他接口会将tddSel modeSel用来选择对应参数并配置给hal
**************************************************************************/
UINT32 BspTddSwModeSel(UINT32 tddSel,UINT32 modeSel)
{
    if(tddSel >= DPDIC_MAX_TDD_NUM || modeSel >= BspGetRfSwitchCtrlTddModeMapNum())
    {
        dbgErr("%s: input tddSel %d or modeSel %d out of range. ModeMapNum = %d.\n", __FUNCTION__, tddSel, modeSel,BspGetRfSwitchCtrlTddModeMapNum());
        return BSP_ERROR;
    }

    s_rfSwitchTddSwModeSel[tddSel] = modeSel;
    return BSP_OK;
}
UINT32 BspGetTddSwModeSel(UINT32 tddSel)
{
    return s_rfSwitchTddSwModeSel[tddSel];
}
UINT32 BspInitTddIoConctrlPara(T_TDDIO_CONCTRL_PARA *pPara)
{
    memcpy_s((VOID*)&g_ulTddIoControlPara,sizeof(T_TDDIO_CONCTRL_PARA),pPara,sizeof(T_TDDIO_CONCTRL_PARA));

    return BSP_OK;
}

UINT32 BspGetInitTddNum(VOID)
{
    return g_ulTddIoControlPara.tddNum;
}
UINT32 BspGetTddTimingGenSelByTddSel(UINT32 tddSel)/*这套tdd，对应于哪个genType，是fdd还是tdd*/
{
    if(tddSel >= DPDIC_MAX_TDD_NUM )
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    return g_ulTddIoControlPara.tddTimingGenType[tddSel];
}
/*使用哪一套tdd,配置对应的TddBaseTimingGen，单板下选择使用哪一套TimingGen，目前平台只有两套可用，对应EXCEL，一套为TDD射频开关，一套为FDD射频开关使用 */
UINT32 BspInitTddBaseTimingGenSel(UINT32 tddSel,UINT32 genType)
{/*单板下参数初始化为一个数组 [0,0,0,0],每个位置对应对应tdd的genType*/
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx = 0;

    if(genType >= DPDIC_MAX_TIMING_GEN_SEL_TYPE)
    {
        dbgErr("Input genType is invalid \n");
        return BSP_ERROR;
    }
/* Started by AICoder, pid:m5817l48e52c50f146f4092f20171f071ee58eab */
    if (IS_NCR == BspIsNcr())
    {
        g_tddTimingGenSel[genType].paLnaTimingGen.tRxTiming.uiRxRise4Sel1 = TDD_BASE_RX_RISE1;
        g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxTiming.uiRxRise4Sel1 = TDD_BASE_RX_RISE1;

        g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcTiming = g_tddTimingGenSel[genType].paLnaTimingGen.tRxTiming;
        g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcTiming = g_tddTimingGenSel[genType].paLnaTimingGen.tTxTiming;
        g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcTiming = g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxTiming;
        g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcTiming = g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxTiming;
        g_tddTimingGenSel[genType].ampTimingGen.tRxAcTiming = g_tddTimingGenSel[genType].ampTimingGen.tRxTiming;
        g_tddTimingGenSel[genType].ampTimingGen.tTxAcTiming = g_tddTimingGenSel[genType].ampTimingGen.tTxTiming;

        if (1 == tddSel)
        {
            g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcTiming.uiTxFall4Sel1 = TDD_BASE_TX_FALL2;
            g_tddTimingGenSel[genType].ampTimingGen.tTxAcTiming.uiTxFall4Sel1 = TDD_BASE_TX_FALL2;
        }
    }
/* Ended by AICoder, pid:m5817l48e52c50f146f4092f20171f071ee58eab */
    retVal = BspHalAdaptSetPaLnaBaseGenSel(&g_tddTimingGenSel[genType].paLnaTimingGen,tddSel);
    retVal |= BspHalAdaptSetAmpBaseGenSel(&g_tddTimingGenSel[genType].ampTimingGen,tddSel);
    retVal |= BspHalAdaptSetTransBaseGenSel(&g_tddTimingGenSel[genType].trxTimingGen,tddSel);
    if(E_INIT_TYPE_MS != BspGetInitTddNum())
    {
        return retVal;   /*非1拖三机型不需要后续动作*/
    }
    for(ioIdx = 0; ioIdx < AC_CTRL_TYPE_NUM; ioIdx++)
    {
        retVal |= BspHalAdaptSetAcCtrlBaseGenSel(&g_tddAcTimingGenSel[genType],tddSel,ioIdx);     /*其他机型ModeMap没有使用AC里的tddTimingGen 不影响*/
    }
    return retVal;
}

/**************************************************************************
 *pa lna 基础时延参数和modemap选择设置  BspInitPaLnaPara 是初始化第一套TDD BspInitPaLnaPara2是第二套TDD 以此类推
 * 参数由马运华提供
 * (1)部分参数需要从AC模块获取 Para2_AdvOn_PaTxSw中dUeAdvGap
 * (2)timing时序选择在EXCEL TDD射频开关中标注，虽然方案中timing选择是固定的，但是应该需要增加接口有能力修改，避免后续特殊需求（965x已经有和平台不同的差异化处理）
 *（3）PA/LNA 不区分校准和非校准通道，但是FDD TDD机型要分开配置，这块先使用两套TDD，后边方案明晰之后还要进行二次优化
 **************************************************************************/
/* 第一套TDD */
UINT32 BspInitPaLnaPara_Tdd(UINT32 acType,UINT32 baseType, T_PA_LNA_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    UINT32 para2Fix = 0;
    UINT32 para5Fix = 0;
    UINT32 para7Fix = 0;
    UINT32 para11Fix = 0;

    radio = radio&RADIO_STANDARD_45G;
    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_PA_LNA_CFG),0,sizeof(T_PA_LNA_CFG));
    if(radio == 0)
    {
        BspSetRadioStandard(RADIO_STANDARD_5G);  //若因小区未建立等原因获取制式失败，则取默认值单模NR
        radio = BspGetRadioStandard();
        g_tddIoErrRcdRadioCnt++;
    }
    dbgInfoEx("PaLna Para acType: %d baseType %d\n",acType, baseType);
    /*生成基础时序所需的参数  把EXCEL里跟PA/LNA相关的加入
    tx_timing 参数1+参数C1-->TX_FALL1 参数5-->TX_RISE1   PA/LNA  hal会再提供一层FALL|RISE选择
    tx_ac_timing  参数2+参数C1-->TX_FALL2 参数5-->TX_RISE1
    EXCEL中是这样提供，但是如果生成TDD基础时序时，如果用到了参数6、那么C1就需要配置；如果用到参数9和参数10，那么C2就要用 当前实际C1 C2不需要配置*/
    tPara->tBasePara.uiDlDIsEnDly1          = Para1_DlyOff(LINK_INFO_PACHN_TDDIO, acType, radio,baseType);  /*参数1*/
    tPara->tBasePara.uiAcDlDisEnDly1        = Para2_DlyOff(LINK_INFO_PACHN_TDDIO, acType, radio,baseType);  /*参数2*/
    tPara->tBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tBasePara.uiDlPreEn1             = Para5_AdvOn(LINK_INFO_PACHN_TDDIO, acType, radio,baseType);    /*参数5*/
    tPara->tBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    tPara->tBasePara.uiAcUlPreEn1           = Para7_AdvOn_LnaRxPwr(acType, radio);    /*参数7*/
    tPara->tBasePara.uiUlPreEn1             = Para8_AdvOn_LnaRxPwr(acType, radio);    /*参数8*/
    tPara->tBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    tPara->tBasePara.uiUlDIsEnDly1          = Para11_DlyOff_LnaRxPwr(acType, radio);    /*参数11*/
    tPara->tBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用 注意13 14 15与PA LNA无关，是TRX_AN_EN使用 参数15不使用*/
    tPara->tBasePara.uiDlLagEn              = 0; /*参数C1，使用参数6时才需要配置，见icenter说明*/
    tPara->tBasePara.uiUlLagEn              = 0; /*参数C2，使用参数9、10时才需要配置*/
    /*uiModeNum 表示支持的最大模式，4.0上pa/lna/txen/rxen/orfbsw对应TDD_timing_gen,图2.3 2.5 2.5里有9种
    uiModeMapSel中的mode选择，在hal层会拼接成一个数，每种模式占3个或者4个Bit  TDD_IO_MODE_TDD具体是几其实影响占哪几bit,所以需要hal提供
    uiModeMapSel 每种AC模式对应一种，4.2具体配置见方案图2.3，inslot 4.0上暂时没用，4.2也暂时不用，内环自检不确认是否需要，其他应该都需要，注意4.2有单独的dpd加塞模式
    对COM_tdd_timing  TDD 只要是上下行ac, 选择tx_ac_timing/rx_ac_timing,其他都是tx_timing/rx_timing，能力上modemap支持选择常0常1，只是TDD没这么用  对TS应该还是和AC一样处理
    具体到此接口，pa控制 不分ac通道和非ac通道 但是这块图上又画了ac和非ac通道，目前沟通应该还是不需要*/
    tPara->tTxComSwMap.uiModeNum                        = TDD_MODE_MAP_NUM;        /*最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]    = TDD_BASE_TX_TIMING1;     /*tdd正常模式          --tx_timing*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]  = TDD_BASE_TX_TIMING2;     /*下行ac校准(normal)   --tx_ac_timing*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_TX_TIMING2;     /*上行ac校准           --tx_ac_timing*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS] = TDD_BASE_TX_TIMING2;     /*dpd加塞，这里给TDD使用,--tx_ac_timing*/

    tPara->tRxComSwMap.uiModeNum                        = TDD_MODE_MAP_NUM;
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]    = TDD_BASE_RX_TIMING1;     /*tdd正常模式 --rx_timing*/
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]  = TDD_BASE_RX_TIMING2 ;    /*下行ac校准(normal) --rx_ac_timing*/
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_RX_TIMING2 ;    /*上行ac校准(normal) --rx_ac_timing*/
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS] = TDD_BASE_RX_TIMING1;     /*dpd加塞   --对TDD机型rx_timing*/

     /*dmimo UTDOA 功能 添加AcSwMap 功能使用，和中频确认对其它功能无害*/
    tPara->tTxAcSwMap.uiModeNum = TDD_MODE_MAP_NUM; /*最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样*/
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD] = TDD_BASE_TX_TIMING2; /*tdd正常模式  --tx_ac_timing*/
    tPara->tRxAcSwMap.uiModeNum = TDD_MODE_MAP_NUM;/*最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样*/
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD] = TDD_BASE_RX_TIMING2; /*tdd正常模式  --rx_ac_timing*/

    if(0 != s_tddIoExceptCtrlX.tddOutSel[E_TDD_IO_DEF_TYPE_PA_MODEMAP][E_TDD_IO_DEF_TYPE_ENGAGED])
    {
        tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_TX_TIMING1;     /*上行ac校准           --tx_timing*/
        tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC] = TDD_BASE_TX_TIMING2;
    }

    if (IS_NCR == BspIsNcr())
    {
        Para2_DlyOff_PaTxSw_NCR(radio, acType, &para2Fix);
        tPara->tBasePara.uiAcDlDisEnDly1 = para2Fix;   /*参数2在隔离度检测时使用*/
        Para5_AdvOn_PaTxSw_NCR(radio, &para5Fix);
        tPara->tBasePara.uiDlPreEn1 = para5Fix;     /*参数5*/
        Para7_AdvOn_LnaRxSw_NCR(radio, &para7Fix);
        tPara->tBasePara.uiAcUlPreEn1 = para7Fix;    /*参数7*/
        tPara->tBasePara.uiUlPreEn1 = 0;    /*参数8不使用*/
        Para11_DlyOff_LnaRxSw_NCR(radio, &para11Fix);
        tPara->tBasePara.uiUlDIsEnDly1 = para11Fix;    /*参数11*/
    }

    return BSP_OK;
}

/* Started by AICoder, pid:wc52d1c86b0e85d14ca30bef6055bc6454e236cc */
/* Started by AICoder, pid:w7959j8b19oa8d714919089fd03ed67eeff17da7 */
/* 第二套TDD */
UINT32 BspInitPaLnaPara2_Tdd(UINT32 acType, UINT32 baseType, T_PA_LNA_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    UINT32 para1Fix = 0;
    UINT32 para5Fix = 0;
    UINT32 para7Fix = 0;
    UINT32 para11Fix = 0;

    radio = radio&RADIO_STANDARD_45G;
    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_PA_LNA_CFG),0,sizeof(T_PA_LNA_CFG));
    if(radio == 0)
    {
        BspSetRadioStandard(RADIO_STANDARD_5G);  //若因小区未建立等原因获取制式失败，则取默认值单模NR
        radio = BspGetRadioStandard();
        g_tddIoErrRcdRadioCnt++;
    }
    dbgInfoEx("PaLna Para acType: %d baseType %d\n",acType, baseType);
    /*生成基础时序所需的参数  把EXCEL里跟PA/LNA相关的加入
    tx_timing 参数1+参数C1-->TX_FALL1 参数5-->TX_RISE1   PA/LNA  hal会再提供一层FALL|RISE选择
    tx_ac_timing  参数2+参数C1-->TX_FALL2 参数5-->TX_RISE1
    EXCEL中是这样提供，但是如果生成TDD基础时序时，如果用到了参数6、那么C1就需要配置；如果用到参数9和参数10，那么C2就要用 当前实际C1 C2不需要配置*/
    Para1_DlyOff_PaTxSw_NCR2(radio, &para1Fix);
    tPara->tBasePara.uiDlDIsEnDly1          = para1Fix;    /*参数1*/
    tPara->tBasePara.uiAcDlDisEnDly1        = 0;/*参数2不使用*/
    tPara->tBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    Para5_AdvOn_PaTxSw_NCR2(radio, acType, &para5Fix);
    tPara->tBasePara.uiDlPreEn1             = para5Fix;    /*参数5*/
    tPara->tBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    Para7_AdvOn_LnaRxSw_NCR2(radio, &para7Fix);
    tPara->tBasePara.uiAcUlPreEn1           = para7Fix;    /*参数7*/
    tPara->tBasePara.uiUlPreEn1             = 0;/*参数8不使用*/
    tPara->tBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    Para11_DlyOff_LnaRxSw_NCR2(radio, acType, &para11Fix);
    tPara->tBasePara.uiUlDIsEnDly1          = para11Fix;    /*参数11*/
    tPara->tBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用 注意13 14 15与PA LNA无关，是TRX_AN_EN使用 参数15不使用*/
    tPara->tBasePara.uiDlLagEn              = 0; /*参数C1，使用参数6时才需要配置，见icenter说明*/
    tPara->tBasePara.uiUlLagEn              = 0; /*参数C2，使用参数9、10时才需要配置*/
    /*uiModeNum 表示支持的最大模式，4.0上pa/lna/txen/rxen/orfbsw对应TDD_timing_gen,图2.3 2.5 2.5里有9种
    uiModeMapSel中的mode选择，在hal层会拼接成一个数，每种模式占3个或者4个Bit  TDD_IO_MODE_TDD具体是几其实影响占哪几bit,所以需要hal提供
    uiModeMapSel 每种AC模式对应一种，4.2具体配置见方案图2.3，inslot 4.0上暂时没用，4.2也暂时不用，内环自检不确认是否需要，其他应该都需要，注意4.2有单独的dpd加塞模式
    对COM_tdd_timing  TDD 只要是上下行ac, 选择tx_ac_timing/rx_ac_timing,其他都是tx_timing/rx_timing，能力上modemap支持选择常0常1，只是TDD没这么用  对TS应该还是和AC一样处理
    具体到此接口，pa控制 不分ac通道和非ac通道 但是这块图上又画了ac和非ac通道，目前沟通应该还是不需要*/
    tPara->tTxComSwMap.uiModeNum                        = TDD_MODE_MAP_NUM;        /*最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]    = TDD_BASE_TX_TIMING1;     /*tdd正常模式          --tx_timing*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]  = TDD_BASE_TX_TIMING2;     /*下行ac校准(normal)   --tx_ac_timing*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_TX_TIMING2;     /*上行ac校准           --tx_ac_timing*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS] = TDD_BASE_TX_TIMING2;     /*dpd加塞，这里给TDD使用,--tx_ac_timing*/

    tPara->tRxComSwMap.uiModeNum                        = TDD_MODE_MAP_NUM;
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]    = TDD_BASE_RX_TIMING1;     /*tdd正常模式 --rx_timing*/
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]  = TDD_BASE_RX_TIMING2 ;    /*下行ac校准(normal) --rx_ac_timing*/
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_RX_TIMING2 ;    /*上行ac校准(normal) --rx_ac_timing*/
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS] = TDD_BASE_RX_TIMING1;     /*dpd加塞   --对TDD机型rx_timing*/

     /*dmimo UTDOA 功能 添加AcSwMap 功能使用，和中频确认对其它功能无害*/
    tPara->tTxAcSwMap.uiModeNum = TDD_MODE_MAP_NUM; /*最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样*/
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD] = TDD_BASE_TX_TIMING2; /*tdd正常模式  --tx_ac_timing*/
    tPara->tRxAcSwMap.uiModeNum = TDD_MODE_MAP_NUM;/*最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样*/
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD] = TDD_BASE_RX_TIMING2; /*tdd正常模式  --rx_ac_timing*/

    if(0 != s_tddIoExceptCtrlX.tddOutSel[E_TDD_IO_DEF_TYPE_PA_MODEMAP][E_TDD_IO_DEF_TYPE_ENGAGED])
    {
        tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_TX_TIMING1;     /*上行ac校准           --tx_timing*/
        tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC] = TDD_BASE_TX_TIMING2;
    }
    return BSP_OK;
}
/* Ended by AICoder, pid:w7959j8b19oa8d714919089fd03ed67eeff17da7 */

/* Ended by AICoder, pid:wc52d1c86b0e85d14ca30bef6055bc6454e236cc */

UINT32 BspInitPaLnaPara_Fdd(UINT32 acType, T_PA_LNA_CFG *tPara)
{
    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_PA_LNA_CFG),0,sizeof(T_PA_LNA_CFG));

    dbgInfoEx(">>>>>>%s: acType %d.\n", __FUNCTION__, acType);//维测，打印传入该函数的acType。
    //生成8种基础时序所需的参数  把EXCEL里跟PA/LNA相关的加入
     //tx_timing 参数1+参数C1-->TX_FALL1 参数5-->TX_RISE1   PA/LNAQISH hal会再提供一层FALL|RISE选择
     //tx_ac_timing  参数2+参数C1-->TX_FALL2 参数5-->TX_RISE1
    //对FDD而言，除了AC和DTX有开关冲突，其他基本就是长收长发，所以对FDD而言这些时延参数基本不会使用到
     tPara->tBasePara.uiDlDIsEnDly1          = 0;   /*参数1*/
     tPara->tBasePara.uiAcDlDisEnDly1        = 0;   /*参数2*/
     tPara->tBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
     tPara->tBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
     tPara->tBasePara.uiDlPreEn1             = 0;    /*参数5*/
     tPara->tBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
     tPara->tBasePara.uiAcUlPreEn1           = 0;    /*参数7*/
     tPara->tBasePara.uiUlPreEn1             = 0;    /*参数8*/
     tPara->tBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
     tPara->tBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
     tPara->tBasePara.uiUlDIsEnDly1          = 0;    /*参数11*/
     tPara->tBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用 13 14 15与PA LNA无关 参数15不使用*/
     tPara->tBasePara.uiDlLagEn              = 0;
     tPara->tBasePara.uiUlLagEn              = 0;
     /*uiModeNum 表示支持的最大模式，4.0上pa/lna/txen/rxen/orfbsw对应TDD_timing_gen,图2.3 2.5 2.5里有9种
     uiModeMapSel中的mode选择，在hal层会拼接成一个数，每种模式占3个或者4个Bit  TDD_IO_MODE_TDD具体是几其实影响占哪几bit,所以需要hal提供
     uiModeMapSel 每种AC模式对应一种，4.2具体配置见方案图2.3，inslot 4.0上暂时没用，4.2也暂时不用，内环自检不确认是否需要，其他应该都需要，注意4.2有单独的dpd加塞模式
     对COM_tdd_timing  FDD 只要是上下行ac, 选择tx_ac_inslot_timing/rx_ac_inslot_timing,其他都是常1(DPD加塞理解需要例外，待最终确认)*/
     tPara->tTxComSwMap.uiModeNum                            = TDD_MODE_MAP_NUM;     //最大支持的模式个数 图2.3
     tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD]        = TDD_BASE_TX_ONE;      //FDD正常               --常1
     tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]     = TDD_BASE_TX_TIMING3;  //dpd加塞 tx_acinslot_timing
     tPara->tRxComSwMap.uiModeNum                            = TDD_MODE_MAP_NUM;
     tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD]        = TDD_BASE_RX_ONE;               //FDD正常 选择常1
      tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]  = TDD_BASE_RX_ONE;               //dpd加塞              --和正常TDD模式下上行一致

     tPara->tTxAcSwMap.uiModeNum                            = TDD_MODE_MAP_NUM;     //最大支持的模式个数 图2.3
     tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = TDD_BASE_TX_TIMING3;  //下行ac校准(normal)    --tx_acinslot_timing
     tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = TDD_BASE_TX_TIMING3;  //上行ac校准            --tx_acinslot_timing
     tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]     = TDD_BASE_TX_TIMING3;  //dpd加塞 tx_acinslot_timing
     tPara->tRxAcSwMap.uiModeNum                            = TDD_MODE_MAP_NUM;
     tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = TDD_BASE_RX_TIMING3;           //下行ac校准(normal)    --rx_acinslot_timing
     tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = TDD_BASE_RX_TIMING3;           //上行ac校准(normal)    --rx_acinslot_timing
     tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]  = TDD_BASE_RX_ONE;               //dpd加塞              --和正常TDD模式下上行一致

     return BSP_OK;
}

UINT32 BspInitAmpPara_Tdd(UINT32 acType,UINT32 baseType, T_AMP_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    UINT32 para2Fix = 0;
    UINT32 para5Fix = 0;

    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_AMP_CFG),0,sizeof(T_AMP_CFG));

    radio = radio&RADIO_STANDARD_45G;
    if(radio == 0)
    {
        BspSetRadioStandard(RADIO_STANDARD_5G);  //若因小区未建立等原因获取制式失败，则取默认值单模NR
        radio = BspGetRadioStandard();
        g_tddIoErrRcdRadioCnt++;
    }
    dbgInfoEx("Amp Para acType: %d baseType %d\n",acType, baseType);
    //生成8种基础时序所需的参数
    //tx_timing 参数1+参数C1-->TX_FALL1 参数5-->TX_RISE1   PA/LNA hal会再提供一层FALL|RISE选择
    //tx_ac_timing  参数2+参数C1-->TX_FALL2 参数5-->TX_RISE1
    //EXCEL中是这样提供，但是如果生成TDD基础时序时，如果用到了参数6、那么C1就需要配置；如果用到参数9和参数10，那么C2就要用 当前实际C1 C2不需要配置
    tPara->tAmpBasePara.uiDlDIsEnDly1          = Para1_DlyOff(LINK_INFO_AMPCHN_TDDIO, acType, radio,baseType);  /*参数1*/
    tPara->tAmpBasePara.uiAcDlDisEnDly1        = Para2_DlyOff(LINK_INFO_AMPCHN_TDDIO, acType, radio,baseType);  /*参数2*/
    tPara->tAmpBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tAmpBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tAmpBasePara.uiDlPreEn1             = Para5_AdvOn(LINK_INFO_AMPCHN_TDDIO, acType, radio,baseType);    /*参数5*/
    tPara->tAmpBasePara.uiDlPreEn2             = 0;/*参数6不使用*/

    /* 4.2 上Amp_pwr是下行小信号放大器，只控下行，不区分校准和非校准通道*/
    tPara->tAmpComSwMap.uiModeNum                        = TDD_MODE_MAP_NUM; //最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]    = TDD_BASE_TX_TIMING1;    //tdd正常模式 --tx_timing
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]  = TDD_BASE_TX_TIMING2;      //下行ac校准(normal)  /** tx ac timing */
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_TX_TIMING2;      //上行ac校准          /** tx ac timing */
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS] = TDD_BASE_TX_TIMING2;     //dpd加塞，--tx_ac_timing

    /*dmimo UTDOA 功能 添加AcSwMap 功能使用，和中频确认对其它功能无害*/
    tPara->tAmpAcSwMap.uiModeNum  = TDD_MODE_MAP_NUM; //最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样
    tPara->tAmpAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD] = TDD_BASE_TX_TIMING2; /*tdd正常模式    tx ac timing */
    
    if (IS_NCR == BspIsNcr())
    {
        Para2_DlyOff_TrxTxEn_NCR(radio, acType, &para2Fix);
        tPara->tAmpBasePara.uiAcDlDisEnDly1 = para2Fix;   /*参数2在隔离度检测时使用*/
        Para5_AdvOn_TrxTxEn_NCR(radio, &para5Fix); 
        tPara->tAmpBasePara.uiDlPreEn1 = para5Fix;   /*参数5*/
    }

    return BSP_OK;
}

/* Started by AICoder, pid:g603ck932c9266e1465c0b4e907e9a37a3884e01 */
/* 第二套TDD */
/* Started by AICoder, pid:ha5e5i2a71jdc4c14ee608c5e0d5b94fa781af1b */
UINT32 BspInitAmpPara2_Tdd(UINT32 acType,UINT32 baseType, T_AMP_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    UINT32 para1Fix = 0;
    UINT32 para5Fix = 0;

    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_AMP_CFG),0,sizeof(T_AMP_CFG));

    radio = radio&RADIO_STANDARD_45G;
    if(radio == 0)
    {
        BspSetRadioStandard(RADIO_STANDARD_5G);  //若因小区未建立等原因获取制式失败，则取默认值单模NR
        radio = BspGetRadioStandard();
        g_tddIoErrRcdRadioCnt++;
    }
    dbgInfoEx("Amp Para acType: %d baseType %d\n",acType, baseType);
    //生成8种基础时序所需的参数
    //tx_timing 参数1+参数C1-->TX_FALL1 参数5-->TX_RISE1   PA/LNA hal会再提供一层FALL|RISE选择
    //tx_ac_timing  参数2+参数C1-->TX_FALL2 参数5-->TX_RISE1
    //EXCEL中是这样提供，但是如果生成TDD基础时序时，如果用到了参数6、那么C1就需要配置；如果用到参数9和参数10，那么C2就要用 当前实际C1 C2不需要配置
    Para1_DlyOff_TrxTxEn_NCR2(radio, &para1Fix); 
    tPara->tAmpBasePara.uiDlDIsEnDly1          = para1Fix;    /*参数1*/
    tPara->tAmpBasePara.uiAcDlDisEnDly1        = 0;/*参数2不使用*/
    tPara->tAmpBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tAmpBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    Para5_AdvOn_TrxTxEn_NCR2(radio, acType, &para5Fix); 
    tPara->tAmpBasePara.uiDlPreEn1             = para5Fix;    /*参数5*/
    tPara->tAmpBasePara.uiDlPreEn2             = 0;/*参数6不使用*/

    /* 4.2 上Amp_pwr是下行小信号放大器，只控下行，不区分校准和非校准通道*/
    tPara->tAmpComSwMap.uiModeNum                        = TDD_MODE_MAP_NUM; //最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]    = TDD_BASE_TX_TIMING1;    //tdd正常模式 --tx_timing
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]  = TDD_BASE_TX_TIMING2;      //下行ac校准(normal)  /** tx ac timing */
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_TX_TIMING2;      //上行ac校准          /** tx ac timing */
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS] = TDD_BASE_TX_TIMING2;     //dpd加塞，--tx_ac_timing

    /*dmimo UTDOA 功能 添加AcSwMap 功能使用，和中频确认对其它功能无害*/
    tPara->tAmpAcSwMap.uiModeNum  = TDD_MODE_MAP_NUM; //最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样
    tPara->tAmpAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD] = TDD_BASE_TX_TIMING2; /*tdd正常模式    tx ac timing */

    return BSP_OK;
}
/* Ended by AICoder, pid:ha5e5i2a71jdc4c14ee608c5e0d5b94fa781af1b */

/* Ended by AICoder, pid:g603ck932c9266e1465c0b4e907e9a37a3884e01 */

UINT32 BspInitAmpPara_Fdd(UINT32 acType, T_AMP_CFG *tPara)
{
    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_AMP_CFG),0,sizeof(T_AMP_CFG));

    //生成8种基础时序所需的参数
    tPara->tAmpBasePara.uiDlDIsEnDly1          = 0; /*参数1*/
    tPara->tAmpBasePara.uiAcDlDisEnDly1        = 0; /*参数2*/
    tPara->tAmpBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tAmpBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tAmpBasePara.uiDlPreEn1             = 0;/*参数5*/
    tPara->tAmpBasePara.uiDlPreEn2             = 0;/*参数6不使用*/

    /* 4.2 上Amp_pwr是下行小信号放大器，只控下行，不区分校准和非校准通道*/
    tPara->tAmpComSwMap.uiModeNum                            = TDD_MODE_MAP_NUM; //最大支持的模式个数 图2.3，不像4.0 基础时序和TRX_AN_EN模式个数还不一样
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_FDD]        = TDD_BASE_TX_ONE;      //FDD正常              --常1
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = TDD_BASE_TX_ONE;  //下行ac校准(normal)    --tx_acinslot_timing 20230704 ac时序图上看TXEN/RXEN 一直长高 所以选择跟正常FDD一致
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = TDD_BASE_TX_ONE;  //上行ac校准            --tx_acinslot_timing
    tPara->tAmpComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]     = TDD_BASE_TX_TIMING3;  //dpd加塞，这里给TDD使用,FDD还要再加一套，保证T+F机型  --tx_acinslot_timing
    //这块可能要增加dpd加塞和内环自检

    return BSP_OK;
}
/**************************************************************************
 *transceiver 基础时延参数和modemap选择设置 BspInitTransPara 是初始化第一套TDD BspInitTransPara2是第二套TDD
 * 参数由马运华提供
 * 基础时序参数
 * TX_EN RX_EN ORX_EN TX_AC_ATT RX_AC_ATT  注意对TX_EN RX_EN要区分校准通道和非校准通道，所以有tTxComSwMap tTxAcSwMap之分
 **************************************************************************/
UINT32 BspInitTransPara_Tdd(UINT32 acType,UINT32 baseType, T_TRANS_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    UINT32 para7Fix = 0;
    UINT32 para11Fix = 0;

    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_TRANS_CFG),0,sizeof(T_TRANS_CFG));

    radio = radio&RADIO_STANDARD_45G;
    if(radio == 0)
    {
        BspSetRadioStandard(RADIO_STANDARD_5G);  //若因小区未建立等原因获取制式失败，则取默认值单模NR
        radio = BspGetRadioStandard();
        g_tddIoErrRcdRadioCnt++;
    }
    dbgInfoEx("TRANS txen Para acType: %d baseType %d\n",acType, baseType);
    /* TRX 生成8种基础时序所需的参数 */
    tPara->tTrxBasePara.uiDlDIsEnDly1          = Para1_DlyOff(LINK_INFO_TXCHN_TDDIO, acType, radio,baseType);  /*参数1*/
    tPara->tTrxBasePara.uiAcDlDisEnDly1        = Para2_DlyOff(LINK_INFO_TXCHN_TDDIO, acType, radio,baseType);  /*参数2*/
    tPara->tTrxBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tTrxBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tTrxBasePara.uiDlPreEn1             = Para5_AdvOn(LINK_INFO_TXCHN_TDDIO, acType, radio,baseType);;    /*参数5*/
    tPara->tTrxBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    tPara->tTrxBasePara.uiAcUlPreEn1           = Para7_AdvOn_TrxRxEn(acType, radio);    /*参数7*/
    tPara->tTrxBasePara.uiUlPreEn1             = Para8_AdvOn_TrxRxEn(acType, radio);    /*参数8*/
    tPara->tTrxBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tTrxBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    tPara->tTrxBasePara.uiUlDIsEnDly1          = Para11_DlyOff_TrxRxEn(acType, radio);    /*参数11*/
    tPara->tTrxBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用*/
    tPara->tTrxBasePara.uiDlLagEn              = 0;/*参数C1不使用*/
    tPara->tTrxBasePara.uiUlLagEn              = 0;/*参数C2不使用*/
    /*modemap选择，区分校准和非校准通道 modemap支持选择常0常1，只是TDD没这么用*/
    tPara->tTxComSwMap.uiModeNum                          = TDD_MODE_MAP_NUM;       //最大支持的模式个数 图2.3  非校准通道固定tx_timing
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]      = TDD_BASE_TX_TIMING1;    //tdd正常模式
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]    = TDD_BASE_TX_TIMING1;    //下行ac校准(normal)
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]    = TDD_BASE_TX_TIMING1;    //上行ac校准
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]   = TDD_BASE_TX_TIMING2;    //dpd加塞，这里给TDD使用,FDD还要再加一套，保证T+F机型

    tPara->tRxComSwMap.uiModeNum                          = TDD_MODE_MAP_NUM;        //非校准通道固定rx_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]      = TDD_BASE_RX_TIMING1;     //tdd正常模式 --rx_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]    = TDD_BASE_RX_TIMING1 ;    //下行ac校准(normal) --rx_ac_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]    = TDD_BASE_RX_TIMING1 ;    //上行ac校准(normal) --rx_ac_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]   = TDD_BASE_RX_TIMING1;     //dpd加塞

    tPara->tTxAcSwMap.uiModeNum                           = TDD_MODE_MAP_NUM;       //校准通道固定tx_ac_timing
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD]       = TDD_BASE_TX_TIMING2;    //tdd正常模式
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]     = TDD_BASE_TX_TIMING2;    //下行ac校准(normal)
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]     = TDD_BASE_TX_TIMING2;    //上行ac校准
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]   = TDD_BASE_TX_TIMING2;    //dpd加塞，这里给TDD使用,FDD还要再加一套，保证T+F机型

    tPara->tRxAcSwMap.uiModeNum                           = TDD_MODE_MAP_NUM;        //校准通道固定rx_ac_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD]       = TDD_BASE_RX_TIMING2;     //tdd正常模式 --rx_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]     = TDD_BASE_RX_TIMING2 ;    //下行ac校准(normal) --rx_ac_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]     = TDD_BASE_RX_TIMING2 ;    //上行ac校准(normal) --rx_ac_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]    = TDD_BASE_RX_TIMING1;     //dpd加塞   --对TDD机型rx_ac_timing 对FDD机型这块应该是常1

    /* ORX 目前方案是TRX_RX_EN取反，实际并未使用该组配置 4.2也一样  注意*/
    /*生成8种基础时序所需的参数*/
    tPara->tOrxBasePara.uiDlDIsEnDly1          = Para1_DlyOff_TrxOrfbSw(acType, radio);/*参数1*/
    tPara->tOrxBasePara.uiAcDlDisEnDly1        = Para2_DlyOff_TrxOrfbSw(acType, radio);  /*参数2*/
    tPara->tOrxBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tOrxBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tOrxBasePara.uiDlPreEn1             = Para5_AdvOn_TrxOrfbSw(acType, radio);    /*参数5*/
    tPara->tOrxBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    tPara->tOrxBasePara.uiAcUlPreEn1           = 0;/*参数7不相关*/
    tPara->tOrxBasePara.uiUlPreEn1             = 0;/*参数8不相关*/
    tPara->tOrxBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tOrxBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    tPara->tOrxBasePara.uiUlDIsEnDly1          = 0;/*参数11不相关*/
    tPara->tOrxBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用*/
    tPara->tOrxBasePara.uiDlLagEn              = 0;/*参数C1不相关*/
    tPara->tOrxBasePara.uiUlLagEn              = 0;/*参数C2不相关*/

    tPara->tOrxComSwMap.uiModeNum                        = TDD_MODE_MAP_NUM;    /*反馈以TX 见图2.7  不区分校准和非校准通道按正常tdd控制*/
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]    = TDD_BASE_TX_TIMING1; //tdd正常模式  tx timing
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]  = TDD_BASE_TX_TIMING1; //下行ac校准(normal)
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]  = TDD_BASE_TX_TIMING1; //上行ac校准(normal)
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS] = TDD_BASE_TX_TIMING1; //dpd加塞   --对TDD机型rx_timing 对FDD机型这块应该是常1

    /* TXACEN1 */ /*这里设计两组 目前理解是出4bit 分别控制4个AC_ATT(tx/rx各两个)*/
    //注意一个Trx_enac_timing 模块生效txen_ac_sw  另一个Trx_enac_timing 模块生效rxen_ac_sw
    //生成基础时序所需的参数 见图2.5 参数13+参数14 -->acen_timing1  参数13+参数15-->acen_timing2
     tPara->tTxAcEnMap1.uiModeNum       = TDD_MODE_MAP_NUM; /*4.0与4.2不同，4.0 ACEN的modemap比PA多2个 MODENUM_9 MODENUM_11*/
     tPara->tTxACEnPara1.uiAcEnDly      = Para13_DlyOff_TrxTxEnAc(acType, radio);    //参数13对应TRX_TX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
     tPara->tTxACEnPara1.uiAcDisEnDly1  = Para14_DlyOff_TrxTxEnAc(acType, radio);    //参数14
     tPara->tTxACEnPara1.uiAcDisEnDly2  = 0;                                         //参数15不使用
     tPara->tTxACEnPara1.uiAcEnTiming2Sel1  = 1;
     tPara->tTxAcEnMap1.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_TIME_ZERO;  //选择常0
     tPara->tTxAcEnMap1.uiModeMapSel[TDD_IO_MODE_DL_AC]  = AC_TIME1;      //选择axen_timing1
     tPara->tTxAcEnMap1.uiModeMapSel[TDD_IO_MODE_UL_AC]  = AC_TIME_ZERO;  //选择常0
     /* TXACEN2 */
     tPara->tTxAcEnMap2.uiModeNum        = TDD_MODE_MAP_NUM;
     tPara->tTxACEnPara2.uiAcEnDly       = Para13_DlyOff_TrxTxEnAc(acType, radio);    //参数13对应TRX_TX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
     tPara->tTxACEnPara2.uiAcDisEnDly1   = Para14_DlyOff_TrxTxEnAc(acType, radio);    //参数14
     tPara->tTxACEnPara2.uiAcDisEnDly2   = 0;                                         //参数15不使用
     tPara->tTxACEnPara2.uiAcEnTiming2Sel1  = 1;
     tPara->tTxAcEnMap2.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_TIME_ZERO;  //选择常0
     tPara->tTxAcEnMap2.uiModeMapSel[TDD_IO_MODE_DL_AC]  = AC_TIME1;      //选择axen_timing1
     tPara->tTxAcEnMap2.uiModeMapSel[TDD_IO_MODE_UL_AC]  = AC_TIME_ZERO;  //选择常0

     /* RXACEN1 */
     //生成基础时序所需的参数 见图2.5 参数13+参数14 -->acen_timing1  参数13+参数15-->acen_timing2
      tPara->tRxAcEnMap1.uiModeNum      = TDD_MODE_MAP_NUM; /*4.0余4.2不同，4.0 ACEN的modemap比PA多2个 MODENUM_9 MODENUM_11*/
      tPara->tRxACEnPara1.uiAcEnDly      = Para13_DlyOff_TrxRxEnAc(acType, radio);    //参数13对应TRX_RX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
      tPara->tRxACEnPara1.uiAcDisEnDly1  = Para14_DlyOff_TrxRxEnAc(acType, radio);     //参数14
      tPara->tRxACEnPara1.uiAcDisEnDly2  = 0;    //参数15不使用
      tPara->tRxACEnPara1.uiAcEnTiming2Sel1  = 1;
      tPara->tRxAcEnMap1.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_TIME_ZERO;      //选择常0
      tPara->tRxAcEnMap1.uiModeMapSel[TDD_IO_MODE_DL_AC]  = AC_TIME_ZERO;      //选择常0
      tPara->tRxAcEnMap1.uiModeMapSel[TDD_IO_MODE_UL_AC]  = AC_TIME1;          //选择rxen_timing1
      /* RXACEN2 */
      tPara->tRxAcEnMap2.uiModeNum        = TDD_MODE_MAP_NUM;
      tPara->tRxACEnPara2.uiAcEnDly      = Para13_DlyOff_TrxRxEnAc(acType, radio);    //参数13对应TRX_RX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
      tPara->tRxACEnPara2.uiAcDisEnDly1  = Para14_DlyOff_TrxRxEnAc(acType, radio);     //参数14
      tPara->tRxACEnPara2.uiAcDisEnDly2  = 0;    //参数15不使用
      tPara->tRxACEnPara2.uiAcEnTiming2Sel1  = 1;
      tPara->tRxAcEnMap2.uiModeMapSel[TDD_IO_MODE_TDD]  = AC_TIME_ZERO;      //选择常0
      tPara->tRxAcEnMap2.uiModeMapSel[TDD_IO_MODE_DL_AC]  = AC_TIME_ZERO;    //选择常0
      tPara->tRxAcEnMap2.uiModeMapSel[TDD_IO_MODE_UL_AC]  = AC_TIME1;        //选择rxen_timing1

    if (IS_NCR == BspIsNcr())
    {
        Para7_AdvOn_TrxRxEn_NCR(radio, &para7Fix);
        tPara->tTrxBasePara.uiAcUlPreEn1 = para7Fix;    /*参数7*/
        tPara->tTrxBasePara.uiUlPreEn1 = 0;    /*参数8不使用*/
        Para11_DlyOff_TrxRxEn_NCR(radio, &para11Fix);
        tPara->tTrxBasePara.uiUlDIsEnDly1 = para11Fix;    /*参数11*/
    }

    return BSP_OK;
}

/* Started by AICoder, pid:r5d13hce8dv2c5e148c609ca501ad75bf5b60527 */
/* 第二套TDD */
UINT32 BspInitTransPara2_Tdd(UINT32 acType,UINT32 baseType, T_TRANS_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    UINT32 para7Fix = 0;
    UINT32 para11Fix = 0;

    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_TRANS_CFG),0,sizeof(T_TRANS_CFG));

    radio = radio&RADIO_STANDARD_45G;
    if(radio == 0)
    {
        BspSetRadioStandard(RADIO_STANDARD_5G);  //若因小区未建立等原因获取制式失败，则取默认值单模NR
        radio = BspGetRadioStandard();
        g_tddIoErrRcdRadioCnt++;
    }
    dbgInfoEx("TRANS txen Para acType: %d baseType %d\n",acType, baseType);
    /* TRX 生成8种基础时序所需的参数 */
    tPara->tTrxBasePara.uiDlDIsEnDly1          = Para1_DlyOff(LINK_INFO_TXCHN_TDDIO, acType, radio,baseType);  /*参数1*/
    tPara->tTrxBasePara.uiAcDlDisEnDly1        = Para2_DlyOff(LINK_INFO_TXCHN_TDDIO, acType, radio,baseType);  /*参数2*/
    tPara->tTrxBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tTrxBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tTrxBasePara.uiDlPreEn1             = Para5_AdvOn(LINK_INFO_TXCHN_TDDIO, acType, radio,baseType);    /*参数5*/
    tPara->tTrxBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    Para7_AdvOn_TrxRxEn_NCR2(radio, &para7Fix);
    tPara->tTrxBasePara.uiAcUlPreEn1           = para7Fix;    /*参数7*/
    tPara->tTrxBasePara.uiUlPreEn1             = 0;/*参数8不使用*/
    tPara->tTrxBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tTrxBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    Para11_DlyOff_TrxRxEn_NCR2(radio, acType, &para11Fix);
    tPara->tTrxBasePara.uiUlDIsEnDly1          = para11Fix;    /*参数11*/
    tPara->tTrxBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用*/
    tPara->tTrxBasePara.uiDlLagEn              = 0;/*参数C1不使用*/
    tPara->tTrxBasePara.uiUlLagEn              = 0;/*参数C2不使用*/
    /*modemap选择，区分校准和非校准通道 modemap支持选择常0常1，只是TDD没这么用*/
    tPara->tTxComSwMap.uiModeNum                          = TDD_MODE_MAP_NUM;       //最大支持的模式个数 图2.3  非校准通道固定tx_timing
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]      = TDD_BASE_TX_TIMING1;    //tdd正常模式
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]    = TDD_BASE_TX_TIMING1;    //下行ac校准(normal)
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]    = TDD_BASE_TX_TIMING1;    //上行ac校准
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]   = TDD_BASE_TX_TIMING2;    //dpd加塞，这里给TDD使用,FDD还要再加一套，保证T+F机型

    tPara->tRxComSwMap.uiModeNum                          = TDD_MODE_MAP_NUM;        //非校准通道固定rx_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_TDD]      = TDD_BASE_RX_TIMING1;     //tdd正常模式 --rx_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]    = TDD_BASE_RX_TIMING1 ;    //下行ac校准(normal) --rx_ac_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]    = TDD_BASE_RX_TIMING1 ;    //上行ac校准(normal) --rx_ac_timing
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]   = TDD_BASE_RX_TIMING1;     //dpd加塞

    tPara->tTxAcSwMap.uiModeNum                           = TDD_MODE_MAP_NUM;       //校准通道固定tx_ac_timing
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD]       = TDD_BASE_TX_TIMING2;    //tdd正常模式
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]     = TDD_BASE_TX_TIMING2;    //下行ac校准(normal)
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]     = TDD_BASE_TX_TIMING2;    //上行ac校准
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]   = TDD_BASE_TX_TIMING2;    //dpd加塞，这里给TDD使用,FDD还要再加一套，保证T+F机型

    tPara->tRxAcSwMap.uiModeNum                           = TDD_MODE_MAP_NUM;        //校准通道固定rx_ac_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_TDD]       = TDD_BASE_RX_TIMING2;     //tdd正常模式 --rx_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_DL_AC]     = TDD_BASE_RX_TIMING2 ;    //下行ac校准(normal) --rx_ac_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_UL_AC]     = TDD_BASE_RX_TIMING2 ;    //上行ac校准(normal) --rx_ac_timing
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]    = TDD_BASE_RX_TIMING1;     //dpd加塞   --对TDD机型rx_ac_timing 对FDD机型这块应该是常1

    return BSP_OK;
}
/* Ended by AICoder, pid:r5d13hce8dv2c5e148c609ca501ad75bf5b60527 */
/*这一套配置给FDD使用*/
UINT32 BspInitTransPara_Fdd(UINT32 acType, T_TRANS_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_TRANS_CFG),0,sizeof(T_TRANS_CFG));

    //tx_timing 参数1+参数C1-->TX_FALL1 参数5-->TX_RISE1   PA/LNAQISH hal会再提供一层FALL|RISE选择
    //tx_ac_timing  参数2+参数C1-->TX_FALL2 参数5-->TX_RISE1
    //EXCEL中是这样提供，但是如果生成TDD基础时序时，如果用到了参数6、那么C1就需要配置；如果用到参数9和参数10，那么C2就要用 实际C1 C2不需要配置
    /* TRX */
    //生成8种基础时序所需的参数
    tPara->tTrxBasePara.uiDlDIsEnDly1          = 0;  /*参数1*/
    tPara->tTrxBasePara.uiAcDlDisEnDly1        = 0;  /*参数2*/
    tPara->tTrxBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tTrxBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tTrxBasePara.uiDlPreEn1             = 0;    /*参数5*/
    tPara->tTrxBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    tPara->tTrxBasePara.uiAcUlPreEn1           = 0;    /*参数7*/
    tPara->tTrxBasePara.uiUlPreEn1             = 0;    /*参数8*/
    tPara->tTrxBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tTrxBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    tPara->tTrxBasePara.uiUlDIsEnDly1          = 0;    /*参数11*/
    tPara->tTrxBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用*/
    tPara->tTrxBasePara.uiDlLagEn              = 0;
    tPara->tTrxBasePara.uiUlLagEn              = 0;
    //对FDD这块使用ac_inslot_timing  具体产生和tdd不一样 对应结构体T_AC_INSLOT_PARA   接口是SetFddAcInslotPara
    tPara->tTxComSwMap.uiModeNum                            = TDD_MODE_MAP_NUM; //最大支持的模式个数 图2.3  /*非校准通道固定常1输出*/
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD]        = TDD_BASE_TX_ONE;  //FDD正常               --常1
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = TDD_BASE_TX_ONE;  //下行ac校准
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = TDD_BASE_TX_ONE;  //上行ac校准
    tPara->tTxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]     = TDD_BASE_TX_ONE;  //dpd加塞，TDD fdd不一样FDD这里要填常1
    //这块可能要增加dpd加塞和内环自检，另外4.0 上下行模式个数不对称是什么意思
    tPara->tRxComSwMap.uiModeNum                            = TDD_MODE_MAP_NUM;              /*非校准通道固定常1输出*/
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD]        = TDD_BASE_RX_ONE;           //FDD正常 选择常1
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = TDD_BASE_RX_ONE;           //下行ac校准
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = TDD_BASE_RX_ONE;           //上行ac校准
    tPara->tRxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]     = TDD_BASE_RX_ONE;           //dpd加塞   TDD fdd不一样FDD这里要填常1

    tPara->tTxAcSwMap.uiModeNum                             = TDD_MODE_MAP_NUM;         /*校准通道固定输出tx_acinslot_timing*/
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD]         = TDD_BASE_TX_ONE;      //FDD正常
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]   = TDD_BASE_TX_ONE;      //下行ac校准(normal)
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]   = TDD_BASE_TX_ONE;      //上行ac校准
    tPara->tTxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]      = TDD_BASE_TX_TIMING3;      //dpd加塞，TDD fdd不一样

    tPara->tRxAcSwMap.uiModeNum                             = TDD_MODE_MAP_NUM;                 /*校准通道固定输出rx_acinslot_timing*/
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD]        = TDD_BASE_RX_ONE;            //FDD正常 选择常1
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = TDD_BASE_RX_ONE;            //下行ac校准 20230704从时序图rxen 也是长高
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = TDD_BASE_RX_ONE;            //上行ac校准 20230704从时序图rxen 也是长高
    tPara->tRxAcSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]     = TDD_BASE_RX_ONE;          //dpd加塞
    /* ORX */ //目前方案是TRX_RX_EN取反，实际并未使用该组配置 4.2也一样  注意
    //生成8种基础时序所需的参数
    tPara->tOrxBasePara.uiDlDIsEnDly1          = Para1_DlyOff_TrxOrfbSw(acType, radio);/*参数1*/
    tPara->tOrxBasePara.uiAcDlDisEnDly1        = Para2_DlyOff_TrxOrfbSw(acType, radio);  /*参数2*/
    tPara->tOrxBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tOrxBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tOrxBasePara.uiDlPreEn1             = Para5_AdvOn_TrxOrfbSw(acType, radio);    /*参数5*/
    tPara->tOrxBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    tPara->tOrxBasePara.uiAcUlPreEn1           = 0;   /*参数7不相关*/
    tPara->tOrxBasePara.uiUlPreEn1             = 0;    /*参数8不相关*/
    tPara->tOrxBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tOrxBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    tPara->tOrxBasePara.uiUlDIsEnDly1          = 0;    /*参数11不相关*/
    tPara->tOrxBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用*/
    tPara->tOrxBasePara.uiDlLagEn              = 0;/*参数C1不相关*/
    tPara->tOrxBasePara.uiUlLagEn              = 0;/*参数C2不相关*/

    tPara->tOrxComSwMap.uiModeNum                            = TDD_MODE_MAP_NUM;    /*反馈 见图2.7*/
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD]        = TDD_BASE_TX_ONE;     /* FDD正常 选择常1*/
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = TDD_BASE_TX_ONE;     /*下行ac校准(normal)*/
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = TDD_BASE_TX_ONE;     /*上行ac校准(normal)*/
    tPara->tOrxComSwMap.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]     = TDD_BASE_TX_ONE;     /*dpd加塞*/

    /* TXACEN1 */ /*这里设计两组 目前理解是出4bit 分别控制4个AC_ATT(tx/rx各两个)*/
    //生成基础时序所需的参数 见图2.5 对FDDAC,需要选inslot模式下的ac有效标志，其他模式选择常0 咨询赵吉涛，需要给acdsp预留接口来产生此信号 SetFddAcInslotPara  EXCEL描述较为模糊以注释为准，已与马工确认
     tPara->tTxAcEnMap1.uiModeNum              = TDD_MODE_MAP_NUM; /*4.0余4.2不同，4.0 ACEN的modemap比PA多2个 MODENUM_9 MODENUM_11*/
     tPara->tTxACEnPara1.uiAcEnDly             = 0;    //参数13对应TRX_TX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
     tPara->tTxACEnPara1.uiAcDisEnDly1         = 0;     //参数14
     tPara->tTxACEnPara1.uiAcDisEnDly2         = 0;    //参数15不使用
     tPara->tTxAcEnMap1.uiModeMapSel[TDD_IO_MODE_FDD]        = AC_TIME_ZERO;  //选择常0
     tPara->tTxAcEnMap1.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = AC_TIME_DL_AC_IN_SLOT;  //对FDDAC或者TDD-INLSOT AC,需要选inslot模式下的 下行ac有效标志
     tPara->tTxAcEnMap1.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = AC_TIME_ZERO;  //选择常0
     /* TXACEN2 */
     tPara->tTxAcEnMap2.uiModeNum             = TDD_MODE_MAP_NUM;
     tPara->tTxACEnPara2.uiAcEnDly            = 0;    //参数13对应TRX_TX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
     tPara->tTxACEnPara2.uiAcDisEnDly1        = 0;     //参数14
     tPara->tTxACEnPara2.uiAcDisEnDly2        = 0;    //参数15不使用
     tPara->tTxAcEnMap2.uiModeMapSel[TDD_IO_MODE_FDD]        = AC_TIME_ZERO;  //选择常0
     tPara->tTxAcEnMap2.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = AC_TIME_DL_AC_IN_SLOT;  //对FDDAC或者TDD-INLSOT AC,需要选inslot模式下的ac有效标志
     tPara->tTxAcEnMap2.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = AC_TIME_ZERO;  //选择常0

     /* RXACEN1 */
     //生成基础时序所需的参数 见图2.5 参数13+参数14 -->acen_timing1  参数13+参数15-->acen_timing2
      tPara->tRxAcEnMap1.uiModeNum           = TDD_MODE_MAP_NUM; /*4.0余4.2不同，4.0 ACEN的modemap比PA多2个 MODENUM_9 MODENUM_11*/
      tPara->tRxACEnPara1.uiAcEnDly          = 0;    //参数13对应TRX_RX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
      tPara->tRxACEnPara1.uiAcDisEnDly1      = 0;     //参数14
      tPara->tRxACEnPara1.uiAcDisEnDly2      = 0;    //参数15不使用
      tPara->tRxAcEnMap1.uiModeMapSel[TDD_IO_MODE_FDD]        = AC_TIME_ZERO;  //选择常0
      tPara->tRxAcEnMap1.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = AC_TIME_ZERO;  //选择常0
      tPara->tRxAcEnMap1.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = AC_TIME_UL_AC_IN_SLOT;   //对FDDAC或者TDD-INLSOT AC,需要选inslot模式下的上行ac有效标志
      /* RXACEN2 */
      tPara->tRxAcEnMap2.uiModeNum          = TDD_MODE_MAP_NUM;
      tPara->tRxACEnPara2.uiAcEnDly         = 0;    //参数13对应TRX_RX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
      tPara->tRxACEnPara2.uiAcDisEnDly1     = 0;     //参数14
      tPara->tRxACEnPara2.uiAcDisEnDly2     = 0;    //参数15不使用
      tPara->tRxAcEnMap2.uiModeMapSel[TDD_IO_MODE_FDD]        = AC_TIME_ZERO;  //选择常0
      tPara->tRxAcEnMap2.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC]  = AC_TIME_ZERO;  //选择axen_timing1
      tPara->tRxAcEnMap2.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC]  = AC_TIME_UL_AC_IN_SLOT;  //对FDDAC或者TDD-INLSOT AC,需要选inslot模式下的上行ac有效标志

    return BSP_OK;
}
/*单板下根据chanmap获取对应通道使用的tdd编号，然后tdd 使用TDD的初始化接口还是FDD的初始化接口需要有个对应关系，约束0对应TDD 1对应FDD*/

UINT32 BspSetTddConctolBaseParaAndModeMap(UINT32 acType,UINT32 tddSel)    /*对应于1个tdd_conctrol_base的参数初始化*/
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulBaseParaType = TDDIOPARA_BASEON_NOONE;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(g_ulTddIoControlPara.tddCtrlBaseCfgType[tddSel]== 0)
    {
        ulRetVal = BspGetBaseParaTypeByTddIoInfo(tddSel, LINK_INFO_PACHN_TDDIO,&ulBaseParaType); /*同一类管脚，不同tdd基础时序可以不一样*/
        if(ulRetVal == BSP_OK)/*pa和lna必不可少，所以一定会初始化，没有别的管脚能代替*/
        {
            if ((IS_NCR == BspIsNcr()) && (tddSel == 2))
            {
                ulRet = BspInitPaLnaPara2_Tdd(acType, ulBaseParaType, &g_paLnaPara[tddSel]);
            }
            else
            {
                ulRet = BspInitPaLnaPara_Tdd(acType,ulBaseParaType, &g_paLnaPara[tddSel]);
            }
        }
        ulBaseParaType = TDDIOPARA_BASEON_NOONE;
        ulRetVal = BspGetBaseParaTypeByTddIoInfo(tddSel, LINK_INFO_AMPCHN_TDDIO,&ulBaseParaType);
        if(ulRetVal == BSP_OK)/*amp可以没有对应硬件amp，也可以完全由其他管脚控amp，或者amp管脚用来控其他器件，只有不需要ic内amp控任何器件才不需要初始化*/
        {
            if ((IS_NCR == BspIsNcr()) && (tddSel == 2))
            {
                ulRet |= BspInitAmpPara2_Tdd(acType,ulBaseParaType, &g_AmpPara[tddSel]);
            }
            else
            {
                ulRet |= BspInitAmpPara_Tdd(acType,ulBaseParaType, &g_AmpPara[tddSel]);
            }
        }
        ulBaseParaType = TDDIOPARA_BASEON_NOONE;
        (void)BspGetBaseParaTypeByTddIoInfo(tddSel, LINK_INFO_TXCHN_TDDIO,&ulBaseParaType);
        /*TxEN完全由其他管脚控时不需要初始化，但是rxen orxen比不可少，所以trans模块肯定需要初始化,*/
        if ((IS_NCR == BspIsNcr()) && (tddSel == 2))
        {
            BspInitTransPara2_Tdd(acType,ulBaseParaType, &g_transPara[tddSel]);
        }
        else
        {
            BspInitTransPara_Tdd(acType,ulBaseParaType, &g_transPara[tddSel]);
        }
    }
    else
    {
        ulRet |= BspInitPaLnaPara_Fdd(acType, &g_paLnaPara[tddSel]);
        ulRet |= BspInitAmpPara_Fdd(acType, &g_AmpPara[tddSel]);
        ulRet |= BspInitTransPara_Fdd(acType, &g_transPara[tddSel]);
    }
    ulRet |= BspHalAdaptSetPaLnaPara(&g_paLnaPara[tddSel],tddSel);
    ulRet |= BspHalAdaptSetAmpPara(&g_AmpPara[tddSel],tddSel);
    ulRet |= BspHalAdaptSetTransPara(&g_transPara[tddSel],tddSel);

    return ulRet;
}
/*TDD AC: 初始化一套tdd_ac_control  T_AC_CTRL_CFG 只表示一个ac_ctrl_timing，一套tdd有9个相同的模块 一套TDD就对应3套AC开关，但是支持3套AC开关分别取自不同tdd */
/*按照excel，其实三套AC开关，让使用三套TDD分别产生*/
/*这块要考虑T+F机型怎么处理*/
/*T_AC_CTRL_CFG 代表的是一套TDD中一个tdd_ac_conctrol_timing的参数，全量，不要考虑后边实际选择哪一套，用了几套*/
UINT32 BspInitAcCtrlParaOfTddAcCtrolTiming(UINT32 acType, UINT32 radio,UINT32 acCtrlType,T_AC_CTRL_CFG *tPara)
{
    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_AC_CTRL_CFG),0,sizeof(T_AC_CTRL_CFG));
    /*(1)生成基础时序所需的参数,以马运华工给的配置参数而言，基础时序参数没用使用，即tdd_ac_control_timing里的TDD_timing_gen没有使用目前只使用了里边的TRX_EN_AC模块使用了，在modemap3是选择tx_acen_timing
     *(2)与4.0不同，分别初始化S1 S2 S3,4.2上统一初始化，9个tdd_ac_conctrol_timing模块，每个模块10种模式，每种模式3路输出* */
    //第一步：初始化生成8种基础时序所需的参数  这里一是目前用不到产生的基础时序，二是底层结构体T_AC_CTRL_CFG中的tAcBasePara也不支持分别对AC_TX_SW/AC_RX_SW/AC_CAL_SW分别初始化参数
    //第二步：初始化TRX_EN_AC使用的基础参数  注意这里只有一个TRX_ENAC_timing模块，和基础开关里边相比少一个
     /*目前先按马工提供的参数，每个tdd_ac_conctrol_timing配置一样，后续要增加接口可以分别配置  这里的指的是每套tdd有9个tdd_ac_conctrol_timing中的一个*/
    tPara->tTxACEnPara.uiAcEnDly      = Para13_AcEnDly(acType, radio, acCtrlType);   //参数13对应TRX_TX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
    tPara->tTxACEnPara.uiAcDisEnDly1  = Para14_AcDisEnDly(acType, radio,acCtrlType);     //参数14
    tPara->tTxACEnPara.uiAcDisEnDly2  = 0;    //参数15不使用
    tPara->tTxACEnPara.uiAcEnTiming2Sel1 = 1;  /*选择tx_acen_timing1  0对应timing1 1对应timing2*/
         /* RXACEN1 */
    tPara->tRxACEnPara.uiAcEnDly      = Para13_AcEnDly(acType, radio, acCtrlType);    //参数13对应TRX_RX_AC_RXATT，《4.2射频开关》的TRX_TXEN_AC
    tPara->tRxACEnPara.uiAcDisEnDly1  = Para14_AcDisEnDly(acType, radio,acCtrlType);     //参数14
    tPara->tRxACEnPara.uiAcDisEnDly2  = 0;    //参数15不使用
         //生成基础时序所需的参数 见图2.5 参数13+参数14 -->acen_timing1  参数13+参数15-->acen_timing2
    tPara->tRxACEnPara.uiAcEnTiming2Sel1 = 1;  /*选择rx_acen_timing1*/

    tPara->tAcSwMap0.uiModeNum =TDD_MODE_MAP_NUM;
    tPara->tAcSwMap0.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_CTRL_TIMING_ZERO;  /* 正常TDD和下行AC，输出常0 */
    tPara->tAcSwMap0.uiModeMapSel[TDD_IO_MODE_DL_AC]  = AC_CTRL_TIMING_ZERO;  /* 正常TDD和下行AC，输出常0 */
    tPara->tAcSwMap0.uiModeMapSel[TDD_IO_MODE_UL_AC]  = AC_CTRL_TIMING9;  /*上行AC输出选择tx_acen_timing 前边AC_EN模块已经直接选tx_acen_timing1*/
    tPara->tAcSwMap0.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]    = AC_CTRL_TIMING_ZERO;  /* DPD加塞，输出常0 */

    tPara->tAcSwMap1.uiModeNum =TDD_MODE_MAP_NUM;
    tPara->tAcSwMap1.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_CTRL_TIMING_ZERO;  /* 正常TDD和上行AC，输出常0 */
    tPara->tAcSwMap1.uiModeMapSel[TDD_IO_MODE_DL_AC]  = AC_CTRL_TIMING10;  /* 下行AC输出选择rx_acen_timing 前边AC_EN模块已经直接选tx_acen_timing1*/
    tPara->tAcSwMap1.uiModeMapSel[TDD_IO_MODE_UL_AC]  = AC_CTRL_TIMING_ZERO;  /* 正常TDD和上行AC，输出常0 */
    tPara->tAcSwMap1.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]    = AC_CTRL_TIMING_ZERO;  /* DPD加塞，输出常0 */

    tPara->tAcSwMap2.uiModeNum =TDD_MODE_MAP_NUM;
    tPara->tAcSwMap2.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_CTRL_TIMING_ZERO;  /* 正常TDD输出常0 */
    tPara->tAcSwMap2.uiModeMapSel[TDD_IO_MODE_DL_AC]  = AC_CTRL_TIMING10;  /* 下行AC输出选择rx_acen_timing */
    tPara->tAcSwMap2.uiModeMapSel[TDD_IO_MODE_UL_AC]  = AC_CTRL_TIMING9;  /* 上行AC输出选择tx_acen_timing */
    tPara->tAcSwMap2.uiModeMapSel[TDD_IO_MODE_DPD_TRANS]    = AC_CTRL_TIMING_ZERO;  /* DPD加塞，输出常0 */
   /*以下寄存器 是按管脚给的  和其他模块按tdd给的 不一样*/
    tPara->tAcBasePara.uiDlDIsEnDly1          = Para1_DlyOff_AcSw(acType, radio, acCtrlType);  /*参数1*/
    tPara->tAcBasePara.uiAcDlDisEnDly1        = 0; /*参数2*/
    tPara->tAcBasePara.uiDlDisEnDly2          = 0;/*参数3不使用*/
    tPara->tAcBasePara.uiAcDlDisEnDly2        = 0;/*参数4不使用*/
    tPara->tAcBasePara.uiDlPreEn1             = Para5_AdvOn_AcSw( acType, radio, acCtrlType);    /*参数5*/
    tPara->tAcBasePara.uiDlPreEn2             = 0;/*参数6不使用*/
    tPara->tAcBasePara.uiAcUlPreEn1           = 0;    /*参数7*/
    tPara->tAcBasePara.uiUlPreEn1             = 0;    /*参数8*/
    tPara->tAcBasePara.uiAcUlPreEn2           = 0;/*参数9不使用*/
    tPara->tAcBasePara.uiUlPreEn2             = 0;/*参数10不使用*/
    tPara->tAcBasePara.uiUlDIsEnDly1          = 0;    /*参数11*/
    tPara->tAcBasePara.uiUlDIsEnDly2          = 0;/*参数12不使用 注意13 14 15与PA LNA无关，是TRX_AN_EN使用 参数15不使用*/
    tPara->tAcBasePara.uiDlLagEn              = 0; /*参数C1，使用参数6时才需要配置，见icenter说明*/
    tPara->tAcBasePara.uiUlLagEn              = 0; /*参数C2，使用参数9、10时才需要配置*/
/* Started by AICoder, pid:db1088b80ek5a9a14756085c301b0c1bbd11f44e */
    if(BSP_OK != BspIsSupportRfsRemote())   /*一拖三机型*/
    {
        tPara->tAcSwMap0.uiModeNum =TDD_MODE_MAP_NUM;
        tPara->tAcSwMap0.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_CTRL_TIMING1;   /*tx_timing 一种时序满足所有需求 前边参数要配合 选4个参数即可 不用改6个参数 */
        tPara->tAcSwMap1.uiModeNum =TDD_MODE_MAP_NUM;
        tPara->tAcSwMap1.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_CTRL_TIMING1;
        tPara->tAcSwMap2.uiModeNum =TDD_MODE_MAP_NUM;
        tPara->tAcSwMap2.uiModeMapSel[TDD_IO_MODE_TDD]    = AC_CTRL_TIMING1;
    }
/* Ended by AICoder, pid:db1088b80ek5a9a14756085c301b0c1bbd11f44e */
    return BSP_OK;
}
/*初始化4套TDD配置 待后续选择*/
UINT32 BspInitAcCtrlPara_Tdd(UINT32 acType, UINT32 acCtrlType, T_AC_CTRL_CFG *tPara)
{
    UINT32 radio = BspGetRadioStandard();
    INPUT_POINTER_CHECK(tPara);
    radio = radio&RADIO_STANDARD_45G;
    if(radio == 0)
    {
        BspSetRadioStandard(RADIO_STANDARD_5G);  //若因小区未建立等原因获取制式失败，则取默认值单模NR
        radio = BspGetRadioStandard();
        g_tddIoErrRcdRadioCnt++;
    }
    BspInitAcCtrlParaOfTddAcCtrolTiming(acType, radio,acCtrlType,tPara);/*tPara指的是某一套TDD的一个tdd_ac_control中的参数配置*/

    return BSP_OK;
}

/*设置发起AC的频段号 单频默认是0*/
VOID BspSetAcBandNo(UINT32 bandNo)
{
    g_ulAcBandNo = bandNo;
}

/*获取发起AC 的频段号*/
UINT32 BspGetAcBandNo(VOID)
{
    return g_ulAcBandNo;
}

/*初始化	AC 开关的时序生成参数*/
UINT32 BspInitFddAcCtrlPara(T_TDDIO_FDDAC_BASE_PARA *pFddAcBasePara, UINT32 paraNum)
{
    INPUT_POINTER_CHECK(pFddAcBasePara);
    s_ulTddIoFddAcPara = pFddAcBasePara;
    s_TddIoFddAcParaNum = paraNum;

    return BSP_OK;
}

/*获取当前频段 当前管脚 对应的时序配置参数*/
UINT32 BspGetFddAcCtrlPara(UINT32 acCtrlType,UINT32 paraType, UINT32 *pPara)
{
    UINT32 loopIndex = 0;
    UINT32 bandNo = 0;

    INPUT_POINTER_CHECK(pPara);
    INPUT_POINTER_CHECK(s_ulTddIoFddAcPara);
    bandNo = BspGetAcBandNo();
    for(loopIndex = 0; loopIndex < s_TddIoFddAcParaNum; loopIndex++)
    {
        dbgInfoEx("acCtrlType %d, bandNo %d \n", s_ulTddIoFddAcPara[loopIndex].acCtrlType,s_ulTddIoFddAcPara[loopIndex].bandNo);
        if((acCtrlType == s_ulTddIoFddAcPara[loopIndex].acCtrlType)&&(bandNo == s_ulTddIoFddAcPara[loopIndex].bandNo))
        {
             *pPara = s_ulTddIoFddAcPara[loopIndex].regPara[paraType];
             break;
        }
    }
    if(loopIndex == s_TddIoFddAcParaNum)
    {
         return BSP_ERROR;
    }
    dbgInfoEx("acCtrlType %d, paraType %d pPara %d\n",acCtrlType,paraType,*pPara);

    return BSP_OK;
}

/*兼容原有FDD机型 AC 增加，通过通用规则设置基础时序生成参数*/
VOID BspModifyFddAcCtrlPara(UINT32 acCtrlType,UINT32 paraType, UINT32 *pPara)
{
    UINT32 tmpPara = 0;
    UINT32 retVal = BSP_ERROR;

    retVal = BspGetFddAcCtrlPara(acCtrlType, paraType, &tmpPara);
    if(BSP_OK == retVal)
    {
        *pPara = tmpPara;
    }
    dbgInfoEx("final acCtrlType %d, paraType %d pPara %d\n",acCtrlType,paraType,*pPara);

}

/*初始化一个fdd_ac_conctrol_timing*/
UINT32 BspInitAcCtrlParaOfFddAcCtrolTiming(T_AC_CTRL_FDD_CFG *tPara,UINT32 acCtrlType,UINT32 acType)
{
    INPUT_POINTER_CHECK(tPara);
    memset_s(tPara,sizeof(T_AC_CTRL_FDD_CFG),0,sizeof(T_AC_CTRL_FDD_CFG));
    /*fdd_ac_conctrol_sta0使用*/
    switch(acType)
    {
        case E_AC_TYPE_FDD:
        {
            tPara->tAcSw0.uiRegA = 0;  /*这个寄存器只在正常FDD时生效，TX/RX/CAL都从这个寄存器输出时序*/
            BspModifyFddAcCtrlPara(acCtrlType,0,&tPara->tAcSw0.uiRegA);
            break;
        }
        case E_AC_TYPE_FDD_DL:
        {
            tPara->tAcSw0.uiRegD = 0;
            tPara->tAcSw0.uiRegE = 1;
            tPara->tAcSw0.uiDE2Sel1 = 0; /*二选一是指对上行acinslot和下行acinslot的二选一,非ac时间选D-0，下行ac是acinslot两路标志(两路一样)来选，选的是E*/
            BspModifyFddAcCtrlPara(acCtrlType,4,&tPara->tAcSw0.uiRegD);
            BspModifyFddAcCtrlPara(acCtrlType,5,&tPara->tAcSw0.uiRegE);
            BspModifyFddAcCtrlPara(acCtrlType,6,&tPara->tAcSw0.uiDE2Sel1);
            break;
        }
        case E_AC_TYPE_FDD_UL:
        {
            tPara->tAcSw0.uiRegB = 0;
            if((acCtrlType == 3)||(acCtrlType == 5))
            {
                tPara->tAcSw0.uiRegC = 1;
            }
            else
            {
                tPara->tAcSw0.uiRegC = 0;
            }
            tPara->tAcSw0.uiBC2Sel1 =1;  /*AC有效标志为1时选择regc,否则选择regb  逻辑自动检测，不需要软件配置,非ac时刻选B 上行ac选C*/
            BspModifyFddAcCtrlPara(acCtrlType,1,&tPara->tAcSw0.uiRegB);
            BspModifyFddAcCtrlPara(acCtrlType,2,&tPara->tAcSw0.uiRegC);
            BspModifyFddAcCtrlPara(acCtrlType,3,&tPara->tAcSw0.uiBC2Sel1);
            break;
        }
        default:
            break;
    }
    tPara->tAcSw0.tAcSwMap0.uiModeNum = TDD_MODE_MAP_NUM;
    tPara->tAcSw0.tAcSwMap0.uiModeMapSel[TDD_IO_MODE_FDD] = FDD_AC_CTRL_TIMING_A; /*正常fdd输出rega，常0*/
    tPara->tAcSw0.tAcSwMap0.uiModeMapSel[TDD_IO_MODE_FDD_UL_AC] =FDD_AC_CTRL_TIMING_BC;  /*上行ac输出红点*/
    tPara->tAcSw0.tAcSwMap0.uiModeMapSel[TDD_IO_MODE_FDD_DL_AC] = FDD_AC_CTRL_TIMING_DE; /*下行ac输出绿点*/
    /*fdd_ac_conctrol_sta12暂不使用*/
    tPara->tAcSw1.uiRegG     = 0;
    tPara->tAcSw1.uiRegF     = 0;
    tPara->tAcSw2.uiRegG     = 0;
    tPara->tAcSw2.uiRegF     = 0;
    return BSP_OK;
}
/*初始化4套FDD配置 待后续选择*/
UINT32 BspInitAcCtrlPara_Fdd(UINT32 acType,UINT32 acCtrlType,T_AC_CTRL_FDD_CFG *tPara)
{
    INPUT_POINTER_CHECK(tPara);
    BspInitAcCtrlParaOfFddAcCtrolTiming(tPara,acCtrlType, acType); /*tPara指的是某一套TDD的fdd_ac_control中的参数配置*/
    return BSP_OK;
}

UINT32 BspInitTrxAcInSlotPara(UINT32 acType,UINT32 tddSel,T_TRX_ACINSLOT_PARA *tPara)
{
    INPUT_POINTER_CHECK(tPara);
/*1 表示 ACEN的inslot来源于tdd_conctrol 中的第二个Com_tdd_timing 即trans对应的基础时序生成模块 不代表tdd的编号*/
    tPara->uiTrx0AcInSlot4Sel1 = 1;
    tPara->uiTrx1AcInSlot4Sel1 = 1;
    return BSP_OK;
}

/* Started by AICoder, pid:2f0cdv838cf7bd81429e0b06d0451e9f30056e64 */
VOID BspSetFuncGetChanMaskByTddId(FUNC_GET_CHAN_MASK_BY_TDDID pfunc)
{
    p_FuncGetChanMaskByTddId = pfunc;
}

UINT32 BspGetChanMaskByTddId(UINT32 tddIndex, UINT32 dir)
{
    if (NULL != p_FuncGetChanMaskByTddId)
    {
        return p_FuncGetChanMaskByTddId(tddIndex, dir);
    }
    
    return 0;
}

UINT32 BspGetRadioByChanMask(UINT32 chanMask)
{
    UINT32 chn = 0;
    T_RfCfgPara *pRfCfgPara = NULL;
    UINT32 radioMode = 0;
    UINT32 carrIdx = 0;

    for(chn = 0; chn < BspGetTxChannel(); chn++)
    {
        if(chanMask & (0x1 << chn))
        {
            pRfCfgPara = (T_RfCfgPara *)BspGetRfCfgPara(chn, TX);
            if (NULL == pRfCfgPara)
            {
                BspLog(LOG_LEVEL_0,"[%s]chanMask 0x%x  Tx No CarrPara\n", __FUNCTION__,chanMask);
                continue;
            }
            
            for (carrIdx = 0 ; ((carrIdx < pRfCfgPara->carrNum) && (carrIdx < BSP_MAX_CARR_NUM)) ; carrIdx++)
            {
                radioMode |= pRfCfgPara->carrInfo[carrIdx].radioMode;
            }

        }
    }

    if ((RADIO_STANDARD_45G != radioMode) && (RADIO_STANDARD_5G != radioMode) && (RADIO_STANDARD_LTE_TDD != radioMode))
    {
        radioMode = 0;
        BspLog(LOG_LEVEL_0,"[%s]radioMode 0x%x  , not 45G/NR/LTE TDD\n", __FUNCTION__,radioMode);
    }

    BspLog(LOG_LEVEL_0,"[%s]chanMask 0x%x, radioMode 0x%x \n", __FUNCTION__,chanMask, radioMode);
    return radioMode;
}


UINT32 BspQcellSetAcCtrlPara(T_AC_CTRL_CFG *acCtrlPara, UINT32 tddId)
{
    UINT32 gpNum = 0;
    UINT32 ret = BSP_OK;
    DOUBLE utD1GpTime = 0;
    DOUBLE utDUeAdv45G = 0;
    UINT32 chanMask = 0;
    UINT32 radioMode = 0;

    // utD1GpTime = BspGetD1GpTime45G();
    // utDUeAdv45G = BspGetDUeAdv45G();
    INPUT_POINTER_CHECK(acCtrlPara);

    // GP符号数*GP符号长度 - UE提前量 -- (1)符号长度和UE提前量都使用混模的（已经和中频确认过）(2)公式计算出来的结果直接强转UINT就行，无论向下/向上
    //     通过tddid获取通道掩码
    chanMask = BspGetChanMaskByTddId(tddId,TX);
    if(0 == chanMask)
    {
        BspLog(LOG_LEVEL_0,"[%s] tddId:%x chanMask 0x%x, get chanMask error! \n", __FUNCTION__,tddId, chanMask);
        return BSP_ERROR;
    }
    //      通过通道掩码，获取对应的制式：和APP张凯确认，BspSetTxRfCfg（小区信息下发）在前，BspUpdateTxTddCfg（调用了本接口）在后，可以获取到小区信息
    radioMode = BspGetRadioByChanMask(chanMask);
    if(0 == radioMode){
        BspLog(LOG_LEVEL_0,"[%s] tddId:%x chanMask 0x%x, radioMode 0x%x get radioMode error! \n", __FUNCTION__,tddId, chanMask, radioMode);
        return BSP_ERROR;
    }

    acCtrlPara->tRxACEnPara.uiAcEnTiming2Sel1 = 1;
    acCtrlPara->tRxACEnPara.uiAcEnDly = 3358;

    ret |= BspGetTddIoGpNum(radioMode, &gpNum); // 不能校验返回值，即使报错，也会获取默认的gpNum
    ret |= BspGetD1SymTime(radioMode, &utD1GpTime);
    ret |= dUeAdvGap(radioMode, &utDUeAdv45G); // 这里的制式，实际上没有用
    acCtrlPara->tRxACEnPara.uiAcDisEnDly1 = DOUBLE_US_2_UINT32_737(gpNum*utD1GpTime - utDUeAdv45G);
    // num文档是1，数组第一个赋值就行
    acCtrlPara->tAcSwMap0.uiModeMapSel[0]  = 1;
    acCtrlPara->tAcSwMap1.uiModeMapSel[0]  = 2;
    acCtrlPara->tAcSwMap0.uiModeNum = 1;
    acCtrlPara->tAcSwMap1.uiModeNum = 1;

    dbgInfoEx("[%s] tddId:%d chanMask 0x%x, radioMode 0x%x \n",__FUNCTION__,tddId, chanMask, radioMode);
    dbgInfoEx("[%s]  uiAcDisEnDly1:%d tAcSwMap0.uiModeMapSel[0]:%d tAcSwMap1.uiModeMapSel[0]:%d tAcSwMap0.uiModeNum:%d tAcSwMap1.uiModeNum:%d\n", \
            __FUNCTION__, acCtrlPara->tRxACEnPara.uiAcDisEnDly1, acCtrlPara->tAcSwMap0.uiModeMapSel[0],acCtrlPara->tAcSwMap1.uiModeMapSel[0], \
            acCtrlPara->tAcSwMap0.uiModeNum, acCtrlPara->tAcSwMap1.uiModeNum);
    
    return ret;
}
/* Ended by AICoder, pid:2f0cdv838cf7bd81429e0b06d0451e9f30056e64 */

UINT32 BspSetTddAcControlParaAndModeMap(UINT32 acType,UINT32 tddSel)  /*对应于1个tdd_ac_conctol的参数初始化--一个tdd*/
{
    UINT32 ulRet = BSP_OK;
    UINT32 loop = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }

    for(loop= 0; loop< AC_CTRL_TYPE_NUM;loop++) /*这里的9指的是每套tdd有9个相同配置的tdd_ac_conctrol_timing*/
    {
        if( g_ulTddIoControlPara.tddTimingGenType[tddSel] == 0)
        {
            ulRet |= BspInitAcCtrlPara_Tdd(acType,loop, &g_acCtrlPara[tddSel][loop]);
            if((UTDOA_SUPPORT == support_utdoa))
            {
                BspQcellSetAcCtrlPara(&g_acCtrlPara[tddSel][loop], tddSel);
            }
            ulRet |= BspHalAdaptSetAcCtrlPara(&g_acCtrlPara[tddSel][loop], tddSel,loop);
        }
        else
        {
            ulRet |= BspInitAcCtrlPara_Fdd(acType,loop,&g_acCtrlFddPara[tddSel][loop]);
            ulRet |= BspHalAdaptSetAcCtrlFddPara(&g_acCtrlFddPara[tddSel][loop], tddSel,loop);
        }
    }
    BspInitTrxAcInSlotPara(acType,tddSel,&g_trxAcInslotPara[tddSel]);
    BspHalAdaptSetTrxEnAcAcInSlotSel(&g_trxAcInslotPara[tddSel],tddSel);
    return ulRet;
}

UINT32 BspGetAcCtrlParaUt(T_AC_CTRL_CFG (*acCtrlparaTmp)[AC_CTRL_TYPE_NUM])
{
    UINT32 loop = 0;
    for ( loop = 0; loop < DPDIC_MAX_TDD_NUM; loop++)
    {
        memcpy_s(&(acCtrlparaTmp[loop][0]),sizeof(T_AC_CTRL_CFG)*AC_CTRL_TYPE_NUM,&(g_acCtrlPara[loop][0]),sizeof(T_AC_CTRL_CFG)*AC_CTRL_TYPE_NUM);
    }
    return BSP_OK;
}
UINT32 BspGetAcCtrlMux(T_AC_CTRL_SW_OUT_CFG *acCtrlMuxTmp)
{
    memcpy_s(&(acCtrlMuxTmp[0]),sizeof(T_AC_CTRL_SW_OUT_CFG)*AC_CTRL_TYPE_NUM,&(g_acCtrlMux[0]),sizeof(T_AC_CTRL_SW_OUT_CFG)*AC_CTRL_TYPE_NUM);
    return BSP_OK;
}
UINT32 BspUpdateTddIoDlyPara(UINT32 tddSel, UINT32 acType)
{
    UINT32 ret = BSP_OK;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }
    ret = BspSetTddIoTddId(tddSel);
    /* 生成各路信号 */
    ret |= BspSetTddConctolBaseParaAndModeMap(acType,tddSel);
    ret |= BspSetTddAcControlParaAndModeMap(acType,tddSel);

    dbgInfoEx("%s: tddSel %d, acType %d, after Set. ret = %d.\n", __FUNCTION__, tddSel, acType,ret);

   return ret;
}

/******************************************************************************************
                                  mux配置
*分成两大部分，参数赋值和参数配置生效动作，每一部分又分成init和update
*(1)初始化参数赋值，这里选择从io的角度出发即T_RU_LINK_MAP_TDDIO_TO_RF，而非从单板通道出发，是预防后续mux参数不同单板有差异，可以从T_RU_LINK_MAP_TDDIO_TO_RF往后增加一列
*(2)tdd选择 最终输出 DTX合入等参数修改更新赋值
*(3)配置初始化参数到hal
*(4)配置update参数到hal,此项:对于tdd 4选1单纯根据chanmap更新即可  对于dtx合入，实际是dtx功能里边的dtx使能  对于最后一级的输出，实际是执行开关的动作，比如pa的开关
******************************************************************************************/

/************************** pa/lna/amp mux初始化配置参数************************************************/
UINT32 BspInitPaMuxPara(UINT32 chnIdx, UINT32 tddSel, T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara)
{
    UINT32 tddOut4Sel1x = 0;
    UINT32 ret = BSP_OK;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};
    UINT32 loop = 0;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;

    INPUT_POINTER_CHECK(tPara);

    //ret = BspGetWorkAsTypeByTddIoInfo(chnIdx,LINK_INFO_PACHN_TDDIO,&ioWorkAs); /*预留，防止pa管脚控不同器件时，默认参数不一样*/
    ret = BspGetRealTddNoByTddIoInfo(chnIdx,LINK_INFO_PACHN_TDDIO, &tddOut4Sel1x);
    if(ret != BSP_OK)
    {
        dbgInfoEx("pa chn %d is not used\n ",chnIdx);  /*咨询微院同事，不使用的管脚不用管，不用初始化也不需要最后一级开关打成常0*/
        return BSP_ERROR;    /*此管脚未使用*/
    }
    if(tddSel != tddOut4Sel1x)
    {
        dbgErr("pa tddSel in chanmap %d ,now is tddSel %d\n",tddOut4Sel1x,tddSel);/*此管脚不使用此套tdd，此时不用初始化配置*/
        return BSP_ERROR;
    }

    tPara->uiBaseCfg.uiTddOut4Sel1x = tddSel;
    tPara->uiBaseCfg.uiDtxComOrNot  = DTX_SIG_NON_SEL;  /*所有管脚默认初始化时不合入DTX，会额外提供接口update此参数，即DTX通道使能开关配置，DTX使能时会打开*/
    tPara->uiBaseCfg.uiUeOut2Sel1   = UE_OUT_SIG_NONAC;   /*所有管脚默认初始化时不使用UE定位，pa选不带ac 即不使用UE定位功能，直接软件静态选择是否带后缀_acch*/
    tPara->uiBaseCfg.uiTddOutSelx   = IO_OUT_SEL_ZERO;  /*所有管脚默认初始化时常关,不管实际做什么使用*/

    dbgInfoEx("[%s]PaCfg:uiTddOut4Sel1x %d, uiDtxComOrNot %d, uiTddOutSelx %d, uiTddOut2Sel1 %d \n", __FUNCTION__,
        tPara->uiBaseCfg.uiTddOut4Sel1x, tPara->uiBaseCfg.uiDtxComOrNot, tPara->uiBaseCfg.uiTddOutSelx, tPara->uiBaseCfg.uiUeOut2Sel1);
    /*告警信息*/
    BspGetDifInfoByIoChn(chnIdx , LINK_INFO_PACHN_TDDIO, &Val);
    for(loop = 0; loop < Val.rfChNum; loop++)
    {
        ret |= BspGetLnaIoInfoByRfChn(Val.rfCh[loop],LINK_TYPE_RX,&iochan);
        ioIdx = iochan&0xf;
        dbgInfoEx("pa %d lna ioIdx%d \n",chnIdx,ioIdx);
        tPara->uiAlarmEn  = tPara->uiAlarmEn | (1<<ioIdx);          /** 功放告警8通道合路，8bit合路使能掩码  4.2功放开关1控1，目前看不需要合并告警 所以对应bit置为1，即表示1对1的使能*/
    }
    dbgInfoEx("[%s]uiPaAlarmEn %d\n", __FUNCTION__,tPara->uiAlarmEn);

    return BSP_OK;
}
UINT32 BspInitLnaMuxPara(UINT32 chnIdx, UINT32 tddSel, T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara)
{
    UINT32 tddOut4Sel1x = 0;
    UINT32 ret = BSP_OK;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};
    UINT32 loop = 0;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;


    INPUT_POINTER_CHECK(tPara);

    ret = BspGetRealTddNoByTddIoInfo(chnIdx,LINK_INFO_LNACHN_TDDIO, &tddOut4Sel1x);
    if(ret != BSP_OK)
    {
        dbgInfoEx("lna chn %d is not used\n ",chnIdx);  /*咨询微院同事，不使用的管脚不用管，不用初始化也不需要最后一级开关打成常0*/
        return BSP_ERROR;    /*此管脚未使用*/
    }
    if(tddSel != tddOut4Sel1x)
    {
        dbgErr("lna tddSel in chanmap %d ,now is tddSel %d\n",tddOut4Sel1x,tddSel);/*此管脚不使用此套tdd，此时不用初始化配置*/
        return BSP_ERROR;
    }
    /*LNA*/
    tPara->uiBaseCfg.uiTddOut4Sel1x = tddSel;
    tPara->uiBaseCfg.uiDtxComOrNot  = DTX_SIG_NON_SEL;  /*不合入*/
    tPara->uiBaseCfg.uiTddOutSelx   = IO_OUT_SEL_ONE;  /*电初始化第一次调用时默认关闭*/
    tPara->uiBaseCfg.uiUeOut2Sel1   = UE_OUT_SIG_NONAC; /** 4选1选择的1套信号和cpu静态配置信号2选1 *//*目前看固定先选择一套tdd，然后cpu静态选择一个输出*/
    dbgInfoEx("[%s]LnaCfg:uiTddOut4Sel1x %d, uiDtxComOrNot %d, uiTddOutSelx %d, uiTddOut2Sel1 %d \n", __FUNCTION__,
        tPara->uiBaseCfg.uiTddOut4Sel1x, tPara->uiBaseCfg.uiDtxComOrNot, tPara->uiBaseCfg.uiTddOutSelx, tPara->uiBaseCfg.uiUeOut2Sel1);

    BspGetDifInfoByIoChn(chnIdx , LINK_INFO_LNACHN_TDDIO, &Val);
    for(loop = 0; loop < Val.rfChNum; loop++)
    {
        ret |= BspGetPaIoInfoByRfChn(Val.rfCh[loop],LINK_TYPE_TX,&iochan);
        ioIdx = iochan&0xf;
        dbgInfoEx("pa %d lna ioIdx%d \n",chnIdx,ioIdx);
        tPara->uiAlarmEn  = tPara->uiAlarmEn | (1<< ioIdx);          /** LNA告警8通道合路，8bit合路使能掩码  4.2开关1控1，目前看不需要合并告警 所以对应bit置为1，即表示1对1的使能*/
    }
    dbgInfoEx("[%s]uiLnaAlarmEn %d \n", __FUNCTION__,tPara->uiAlarmEn);
    return BSP_OK;
}
UINT32 BspInitAmpMuxPara(UINT32 chnIdx, UINT32 tddSel, T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara)
{
    UINT32 tddOut4Sel1x = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(tPara);

    ret = BspGetRealTddNoByTddIoInfo(chnIdx,LINK_INFO_AMPCHN_TDDIO, &tddOut4Sel1x);
    if(ret != BSP_OK)
    {
        dbgInfoEx("amp chn %d is not used\n ",chnIdx);  /*咨询微院同事，不使用的管脚不用管，不用初始化也不需要最后一级开关打成常0*/
        return BSP_ERROR;    /*此管脚未使用*/
    }
    if(tddSel != tddOut4Sel1x)
    {
        dbgInfoEx("amp tddSel in chanmap %d ,now is tddSel %d\n",tddOut4Sel1x,tddSel);/*此管脚不使用此套tdd，此时不用初始化配置*/
        return BSP_ERROR;
    }
    /*AMP*/
    tPara->uiBaseCfg.uiTddOut4Sel1x = tddSel;
    tPara->uiBaseCfg.uiDtxComOrNot  = DTX_SIG_NON_SEL;  /*不合入*/
    tPara->uiBaseCfg.uiTddOutSelx   = IO_OUT_SEL_ZERO;  /*电初始化第一次调用时默认关闭*/
    tPara->uiBaseCfg.uiUeOut2Sel1   = UE_OUT_SIG_NONAC; /*4选1选择的1套信号和cpu静态配置信号2选1 *//*目前看固定先选择一套tdd，然后cpu静态选择一个输出*/
    dbgInfoEx("[%s]AmpCfg:uiTddOut4Sel1x %d, uiDtxComOrNot %d, uiTddOutSelx %d, uiTddOut2Sel1 %d \n", __FUNCTION__,
        tPara->uiBaseCfg.uiTddOut4Sel1x, tPara->uiBaseCfg.uiDtxComOrNot, tPara->uiBaseCfg.uiTddOutSelx, tPara->uiBaseCfg.uiUeOut2Sel1);

    return BSP_OK;
}
/************************** transceiver mux初始化配置***********************************************************************/
UINT32 BspInitTransTxMuxPara(UINT32 chnIdx, UINT32 tddSel, T_TDD_BASE_SW_OUT_CFG *tPara)
{
    UINT32 tddOut4Sel1x = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(tPara);

    ret = BspGetRealTddNoByTddIoInfo(chnIdx,LINK_INFO_TXCHN_TDDIO, &tddOut4Sel1x);
    if(ret != BSP_OK)
    {
        dbgInfoEx("txen chn %d is not used\n ",chnIdx);  /*咨询微院同事，不使用的管脚不用管，不用初始化也不需要最后一级开关打成常0*/
        return BSP_ERROR;    /*此管脚未使用*/
    }
    if(tddSel != tddOut4Sel1x)
    {
        dbgInfoEx("ddSel in chanmap %d ,now is tddSel %d\n",tddOut4Sel1x,tddSel);/*此管脚不使用此套tdd，此时不用初始化配置*/
        return BSP_ERROR;
    }
    tPara->uiTddOut4Sel1x = tddSel;                                                         /** 四套TDD时序产生的基础信号，四选一*/
    tPara->uiDtxComOrNot  = DTX_SIG_NON_SEL;                                                /** DTX信号是否合入,1：合入；0：不合入；*/
    tPara->uiTddOutSelx   = IO_OUT_SEL_ZERO;                                                /** 输出选择配置；0：常1；1：常0；2：前级信号；3：前级信号取反*/
    tPara->uiUeOut2Sel1   = UE_OUT_SIG_NONAC;                                               /** UE输出信号选择：不带ac 带ac */
    dbgInfoEx("[%s]tTxEnCfg: uiTddOut4Sel1x %d, uiDtxComOrNot %d, uiTddOutSelx %d  uiTddOut2Sel1 %d\n", __FUNCTION__,
    tPara->uiTddOut4Sel1x,tPara->uiDtxComOrNot, tPara->uiTddOutSelx,tPara->uiTddOutSelx);

    return BSP_OK;
}
UINT32 BspInitTransRxMuxPara(UINT32 chnIdx, UINT32 tddSel, T_TDD_BASE_SW_OUT_CFG *tPara)
{
    UINT32 tddOut4Sel1x = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(tPara);

    ret = BspGetRealTddNoByTddIoInfo(chnIdx,LINK_INFO_RXCHN_TDDIO, &tddOut4Sel1x);
    if(ret != BSP_OK)
    {
        dbgInfoEx("rxen chn %d is not used\n ",chnIdx);  /*咨询微院同事，不使用的管脚不用管，不用初始化也不需要最后一级开关打成常0*/
        return BSP_ERROR;    /*此管脚未使用*/
    }
    if(tddSel != tddOut4Sel1x)
    {
        dbgInfoEx("TddSel in chanmap %d ,now is tddSel %d\n",tddOut4Sel1x,tddSel);/*此管脚不使用此套tdd，此时不用初始化配置*/
        return BSP_ERROR;
    }
    tPara->uiTddOut4Sel1x = tddSel;                                                         /** 四套TDD时序产生的基础信号，四选一*/
    tPara->uiDtxComOrNot  = DTX_SIG_NON_SEL;                                                /** DTX信号是否合入,1：合入；0：不合入；*/
    tPara->uiTddOutSelx   = IO_OUT_SEL_ZERO;                                                /** 输出选择配置；0：常1；1：常0；2：前级信号；3：前级信号取反*/
    tPara->uiUeOut2Sel1   = UE_OUT_SIG_NONAC;                                               /** UE输出信号选择：不带ac 带ac */
    dbgInfoEx("[%s]tRxEnCfg: uiTddOut4Sel1x %d, uiDtxComOrNot %d, uiTddOutSelx %d  uiTddOut2Sel1 %d \n", __FUNCTION__,
    tPara->uiTddOut4Sel1x,tPara->uiDtxComOrNot, tPara->uiTddOutSelx,tPara->uiTddOutSelx );

    return BSP_OK;
}

UINT32 g_ulTransOrxRxMuxMap[TDD_IO_PIN_NUM_COMMON_4] = {0,1,2,3};
/*设置ORX 对RX 取反时的映射关系*/
// UINT32 BspModifyTransOrxRxMuxMap(UINT32 orxIdx, UINT32 rxIdx)
UINT32 BspModifyTransOrxRxMuxMap(UINT32 *pTransOrxRxMuxMap)
{
    UINT32 retVal = BSP_OK;
    if(NULL == pTransOrxRxMuxMap)
    {
        return BSP_ERROR;
    }
    
    memcpy_s(g_ulTransOrxRxMuxMap,sizeof(UINT32)*NELEMENTS(g_ulTransOrxRxMuxMap),pTransOrxRxMuxMap,sizeof(UINT32)*NELEMENTS(g_ulTransOrxRxMuxMap));
    return retVal;
}

UINT32 BspInitTransOrxMuxPara(UINT32 chnIdx, UINT32 tddSel, T_TDD_BASE_ORX_OUT_CFG *tPara)
{
    INPUT_POINTER_CHECK(tPara);

    /*FB 对rx取反，但是如果软件不直接控制orxen,所以初始化需要配置好取反，否则上电默认寄存器值不对*/
    tPara->uiTddOut4Sel1x = tddSel;                                                         /** 四套TDD时序产生的基础信号，四选一*/
    tPara->uiDtxComOrNot  = DTX_SIG_NON_SEL;                                                /** DTX信号是否合入,1：合入；0：不合入；*/
    if(chnIdx >= TDD_IO_PIN_NUM_COMMON_4)
    {
        return BSP_ERROR;
    }
    /** 输出选择配置；0:TRXRXEN；1：TRXRXEN取反；2：1；3：0；4：前级；5：前级取反*/
    tPara->uiTddOutSelx   = (E_TDDIO_CTRL_EXCEPT != \
                            s_tddIoExceptCtrlX.tddOutSel[E_TDD_IO_DEF_TYPE_ORXENEXCEPT][E_TDD_IO_DEF_TYPE_ENGAGED])?
                            (IO_ORX_OUT_SEL_TRX_RXEN_REV):\
                            (s_tddIoExceptCtrlX.tddOutSel[E_TDD_IO_DEF_TYPE_ORXENEXCEPT][E_TDD_IO_DEF_TYPE_ENGAGED_SETS]);
    tPara->uiUeOut2Sel1   = UE_OUT_SIG_NONAC;                                               /** UE输出信号选择：不带ac 带ac */
    tPara->uiRxEn4Sel1   =  g_ulTransOrxRxMuxMap[chnIdx];                                                         /** rxen0~3 */
    dbgInfoEx("[%s]tORxEnCfg: uiTddOut4Sel1x %d, uiDtxComOrNot %d, uiTddOutSelx %d  uiTddOut2Sel1 %d uiRxEn4Sel1 %d\n", __FUNCTION__,
    tPara->uiTddOut4Sel1x,tPara->uiDtxComOrNot, tPara->uiTddOutSelx,tPara->uiTddOutSelx, tPara->uiRxEn4Sel1 );

    return BSP_OK;
}
/*T_TDD_BASE_ENAN_OUT_CFG结构体要在往上封装一层 区分上下行，两个AC_EN模块分别控制rxacatt 和txacatt*/
UINT32 BspInitMuxTrxAcEnPara(UINT32 chnIdx, UINT32 tddSel, T_COMB_2INSTANTIATE_PARA *tPara)
{
    UINT32 tddOut4Sel1x = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(tPara);

    ret = BspGetRealTddNoByTddIoInfo(chnIdx,LINK_INFO_TXACCHN_TDDIO, &tddOut4Sel1x);  /*TX0和RX0 TX1和RX1必然在一套TDD 不在分开*/
    if(ret != BSP_OK)
    {
        dbgInfoEx("tx_acatt chn %d is not used\n ",chnIdx);  /*咨询微院同事，不使用的管脚不用管，不用初始化也不需要最后一级开关打成常0*/
        return BSP_ERROR;    /*此管脚未使用*/
    }
    if(tddSel != tddOut4Sel1x)
    {
         dbgInfoEx("TddSel in chanmap %d ,now is tddSel %d\n",tddOut4Sel1x,tddSel);/*此管脚不使用此套tdd，此时不用初始化配置*/
        return BSP_ERROR;
    }
    /* TXENAC――chnidx*/
    tPara->tTxEnAcCfg.uiEnAc4Sel1= tddSel;             /*一套tdd 对应一个trx0_txen_ac信号，初始化会给一个，配置tdd后会调用BspUpdateMuxTrxAcEnPara再修改各自的tdd选择*/ /** TRXENAC前级4种时序选1 */
    tPara->tTxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_ZERO;  /** 输出选择配置；0：常1；1：常0；2：前级信号；3：前级信号取反 输出选择Tx和rx是分开设置，所以管脚可以分开配置*/

    /*     RXENAC――chnidx*/
    tPara->tRxEnAcCfg.uiEnAc4Sel1= tddSel;             /*一套tdd 对应一个trx0_txen_ac信号*/ /** TRXENAC前级4种时序选1 */
    tPara->tRxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_ZERO;  /** 输出选择配置；0：常1；1：常0；2：前级信号；3：前级信号取反*/


    dbgInfoEx("[%s]chnIdx %d, tddSel %d, uiTrxEnAc4Sel1x %d, uiTrxEnAcOutSelx %d, uiTrxEnAc4Sel1x %d, uiTrxEnAcOutSelx %d\n", __FUNCTION__,
        chnIdx, tddSel, tPara->tTxEnAcCfg.uiEnAc4Sel1, tPara->tTxEnAcCfg.uiTddOutSelx,
        tPara->tRxEnAcCfg.uiEnAc4Sel1, tPara->tRxEnAcCfg.uiTddOutSelx);
    return BSP_OK;
}
/*AC_CTRL*/
UINT32 BspInitMuxAcCtrlPara(UINT32 acCtrlType, UINT32 tddSel, T_AC_CTRL_SW_OUT_CFG *tPara)
{
    INPUT_POINTER_CHECK(tPara);

    switch(acCtrlType)
    {
        case AC0_CTRL_TX_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW0;        /*选择0*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;        /*默认0,常关，开时选前级信号*/
            break;
        }
        case AC0_CTRL_RX_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW1;        /*选择1*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;        /*默认1，开时选前级信号取反*/
            break;
        }
        case AC0_CTRL_CAL_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW2;        /*选择2*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;        /*默认1，开时选前级信号取反*/
            break;
        }
        case AC1_CTRL_TX_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW0;        /*选择0*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;        /*默认0，开时选前级信号*/
            break;
        }
        case AC1_CTRL_RX_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW1;        /*选择0*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;        /*默认1，开时选前级信号取反*/
            break;
        }
        case AC1_CTRL_CAL_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW2;        /*选择0*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;        /*默认1，开时选前级信号取反*/
            break;
        }
        case AC2_CTRL_TX_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW0;        /*选择0*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;        /*默认0，开时选前级信号*/
            break;
        }
        case AC2_CTRL_RX_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW1;        /*选择1*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;        /*默认1，开时选前级信号取反*/
            break;
        }
        case AC2_CTRL_CAL_SW:
        {
            tPara->uiAcOut3Sel1 = AC_CTRL_SW2;        /*选择2*/
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;        /*默认1，开时选前级信号取反*/
            break;
        }
    }
    if(g_ulTddIoControlPara.tddCtrlBaseCfgType[0] == 0) /*这里按整机级  不按第几套TDD*/
    {
        tPara->uiAcCtrl4Sel1 = 0;
        tPara->uiAcCtrl2Sel1 = AC_CTRL_TDD;   /*控制TDD频段的选择TDD,控制FDD频段的则需要选择FDD*//*按照当前excel中给的选择，第一套AC开关给TDD用，那么AC_0的三个管脚需要对应到TDD频段*/
    }
    else
    {
        tPara->uiAcCtrlFdd4Sel1 = 0;
        tPara->uiAcCtrl2Sel1 = AC_CTRL_FDD;   /*控制TDD频段的选择TDD,控制FDD频段的则需要选择FDD*//*按照当前excel中给的选择，第一套AC开关给TDD用，那么AC_0的三个管脚需要对应到TDD频段*/
        tPara->uiAcOut3Sel1 = AC_CTRL_SW0;    /*这块目前FDD机型使用第二套开关，先固定写SW0*/
    }

    return BSP_OK;
}
/*******************************tdd 四选一配置参数更新************************************************/
/*更新PA/LNA mux使用的tdd  与tddcfg和chanmap关联 哪些通道共用一套TDD  更新tdd 4选1的参数*/
#if 0  /*tdd目前看是静态的，不需要动态更新*/
UINT32 BspUpdateMuxPaLna4Sel1Para(UINT32 chnIdx, T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara)
{
    UINT32 rfChnNum = 0;
    UINT32 bspChnNum = 0;
    UINT32 bspChn = 0;
    UINT32 chanmask = 0;
    UINT32 chn = 0;
    UINT32 tddSel = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    INPUT_POINTER_CHECK(tPara);
    /*PA*/
    if(BSP_OK == BspGetDifInfoByIoChn(chn, LINK_INFO_PACHN_TDDIO, &Val))
    {
        rfChnNum = Val.rfCh[0];
    }
    else
    {
        dbgErr(">>>[%s] >>> [%S] RfChn get failed!", __FUNCTION__, "Pa");
        return BSP_ERROR;
    }
    if(BSP_OK == BspGetBspChnByRfChn(rfChnNum, LINK_TYPE_TX, &bspChnNum))//返回值BspChnNum就是BspChn通道号
    {
        bspChn = bspChnNum;
    }
    else
    {
        dbgErr(">>>[%s] >>> [%S] BspChn get failed!", __FUNCTION__, "Pa");
        return BSP_ERROR;
    }
    chanmask = BIT_SET(bspChn);
    tddSel = BspGetTddCfgIdByChanMask(chanmask);//通过bsp通道获取tdd的接口，入参是用掩码的方式
    tPara->uiBaseCfg.uiTddOut4Sel1x = tddSel;

    /*Lna*/
    if(BSP_OK == BspGetDifInfoByIoChn(chn, LINK_INFO_LNACHN_TDDIO, &Val))
    {
        rfChnNum = Val.rfCh[0];//????获取第几个通道
    }
    else
    {
        dbgErr(">>>[%s] >>> [%S] RfChn get failed!", __FUNCTION__, "Lna");
        return BSP_ERROR;
    }
    if(BSP_OK == BspGetBspChnByRfChn(rfChnNum, LINK_TYPE_RX, &bspChnNum))//返回值BspChnNum就是BspChn通道号吗？
    {
        bspChn = bspChnNum;
    }
    else
    {
        dbgErr(">>>[%s] >>> [%S] BspChn get failed!", __FUNCTION__, "Lna");
        return BSP_ERROR;
    }
    chanmask = BIT_SET(bspChn);
    tddSel = BspGetTddCfgIdByChanMask(chanmask);//通过bsp通道获取tdd的接口，入参是用掩码的方式
    tPara->uiBaseCfg.uiTddOut4Sel1x = tddSel;

    dbgInfoEx("[%s] Pa tddSelNum: %d, Lna tddSelNum: %d\n", __FUNCTION__, tPara->uiBaseCfg.uiTddOut4Sel1x, tPara->uiBaseCfg.uiTddOut4Sel1x);
    return BSP_OK;
}

UINT32 BspUpdateMuxAmp4Sel1Para(UINT32 chnIdx, T_TDD_BASE_SW_OUT_CFG *tPara)
{
    UINT32 RfChnNum = 0;
    UINT32 BspChnNum = 0;
    UINT32 BspChn = 0;
    UINT32 chanmask = 0;
    UINT32 chn = 0;
    UINT32 tddSel = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    INPUT_POINTER_CHECK(tPara);
    /*AMP*/
    if(BSP_OK == BspGetDifInfoByIoChn(chn, LINK_INFO_AMPCHN_TDDIO, &Val))
    {
        RfChnNum = Val.rfCh[0];
    }
    else
    {
        dbgErr(">>>[%s] >>> [%S] RfChn get failed!", __FUNCTION__, "Pa");
        return BSP_ERROR;
    }
    if(BSP_OK == BspGetBspChnByRfChn(RfChnNum, LINK_TYPE_TX, &BspChnNum))
    {
        BspChn = BspChnNum;
    }
    else
    {
        dbgErr(">>>[%s] >>> [%S] BspChn get failed!", __FUNCTION__, "Pa");
        return BSP_ERROR;
    }
    chanmask = BIT_SET(BspChn);
    tddSel = BspGetTddCfgIdByChanMask(chanmask);/*通过bsp通道获取tdd的接口，入参是用掩码的方式*/
    tPara->uiTddOut4Sel1x = tddSel;
    dbgInfoEx("[%s] Amp tddSelNum: %d\n", __FUNCTION__, tPara->uiTddOut4Sel1x);

    return BSP_OK;
}
/*设置transceiver中每个通道TX_EN RX_EN使用哪一套TDD*/

UINT32 BspUpdateMuxTrans4Sel1Para(UINT32 chnIdx, T_COMB_TRANS_8INSTANTIATE_PARA *tPara)
{
    UINT32 RfChnNum = 0;
    UINT32 BspChnNum = 0;
    UINT32 BspChn = 0;
    UINT32 chanmask = 0;
    UINT32 chn = 0;
    UINT32 tddSel = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    INPUT_POINTER_CHECK(tPara);
    //TX
    if(BSP_OK == BspGetDifInfoByIoChn(chn, LINK_INFO_TXCHN_TDDIO, &Val))
    {
        RfChnNum = Val.rfCh[0];
    }
    else
    {
        dbgErr(">>>[%s] >>> [%S]  RfChn get failed!", __FUNCTION__, "TranTx");
        return BSP_ERROR;
    }
    if(BSP_OK == BspGetBspChnByRfChn(RfChnNum, LINK_TYPE_TX, &BspChnNum))//返回值BspChnNum就是BspChn通道号吗？
    {
        BspChn = BspChnNum;
    }
    else
    {
        dbgErr(">>>[%s] >>> [%s] BspChn get failed!", __FUNCTION__, "TranTx");
        return BSP_ERROR;
    }

    chanmask = BIT_SET(BspChn);
    tddSel = BspGetTddCfgIdByChanMask(chanmask);//通过bsp通道获取tdd的接口，入参是用掩码的方式
    tPara->tTxEnCfg.uiTddOut4Sel1x  = tddSel;

    //RX
    if(BSP_OK == BspGetDifInfoByIoChn(chn, LINK_INFO_RXCHN_TDDIO, &Val))
    {
        RfChnNum = Val.rfCh[0];
    }
    else
    {
        dbgErr(">>>[%s] >>>[%s] RfChn get failed!", __FUNCTION__, "TranRx");
        return BSP_ERROR;
    }
    if(BSP_OK == BspGetBspChnByRfChn(RfChnNum, LINK_TYPE_RX, &BspChnNum))
    {
        BspChn = BspChnNum;
    }
    else
    {
        dbgErr(">>>[%s] >>>[%s] BspChn get failed!", __FUNCTION__, "TranRx");
        return BSP_ERROR;
    }
    chanmask = BIT_SET(BspChn);
    tddSel = BspGetTddCfgIdByChanMask(chanmask);  /*通过bsp通道获取tdd的接口，入参是用掩码的方式*/
    tPara->tRxEnCfg.uiTddOut4Sel1x = tddSel;

    return BSP_OK;
}

UINT32 BspUpdateMuxTrxAcEn4Sel1Para(UINT32 chnIdx, T_COMB_2INSTANTIATE_PARA *tPara)
{
    UINT32 RfChnNum = 0;
    UINT32 BspChnNum = 0;
    UINT32 BspChn = 0;
    UINT32 chanmask = 0;
    UINT32 chn = 0;
    UINT32 tddSel = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    INPUT_POINTER_CHECK(tPara);
    //TxEnAC
    if(BSP_OK == BspGetDifInfoByIoChn(chn, LINK_INFO_TXACCHN_TDDIO, &Val))
    {
        RfChnNum = Val.rfCh[0];//????获取第几个通道
    }
    else
    {
        dbgErr(">>>[%s] >>>[%s] RfChn get failed!", __FUNCTION__, "TxEnAC");
        return BSP_ERROR;
    }
    if(BSP_OK == BspGetBspChnByRfChn(RfChnNum, LINK_TYPE_TX, &BspChnNum))//返回值BspChnNum就是BspChn通道号吗？
    {
        BspChn = BspChnNum;
    }
    else
    {
        dbgErr(">>>[%s] >>>[%s] BspChn get failed!", __FUNCTION__, "TxEnAC");
        return BSP_ERROR;
    }
    chanmask = BIT_SET(BspChn);
    tddSel = BspGetTddCfgIdByChanMask(chanmask);//通过bsp通道获取tdd的接口，入参是用掩码的方式
    tPara->tTxEnAcCfg.uiEnAc4Sel1 = tddSel;

    //RxEnAC
    if(BSP_OK == BspGetDifInfoByIoChn(chn, LINK_INFO_RXACCHN_TDDIO, &Val))
    {
        RfChnNum = Val.rfCh[0];//????获取第几个通道
    }
    else
    {
        dbgErr(">>>[%s] >>>[%s] RfChn get failed!", __FUNCTION__, "RxEnAC");
        return BSP_ERROR;
    }
    if(BSP_OK == BspGetBspChnByRfChn(RfChnNum, LINK_TYPE_RX, &BspChnNum))//返回值BspChnNum就是BspChn通道号吗？
    {
        BspChn = BspChnNum;
    }
    else
    {
        dbgErr(">>>[%s] >>>[%s] RfChn get failed!", __FUNCTION__, "RxEnAC");
        return BSP_ERROR;
    }
    chanmask = BIT_SET(BspChn);
    tddSel = BspGetTddCfgIdByChanMask(chanmask);//通过bsp通道获取tdd的接口，入参是用掩码的方式
    tPara->tRxEnAcCfg.uiEnAc4Sel1 = tddSel;

    dbgInfoEx("[%s] TxEnAc tddSelNum: %d, RxEnAc tddSelNum:\n", __FUNCTION__, tPara->tTxEnAcCfg.uiEnAc4Sel1, tPara->tRxEnAcCfg.uiEnAc4Sel1);
    return BSP_OK;
}
UINT32 BspUpdataMuxAcCtrl4Sel1Para(UINT32 tddSel, T_AC_CTRL_SW_OUT_CFG *tPara)
{
    INPUT_POINTER_CHECK(tPara);

    tPara->uiAcCtrl4Sel1 = tddSel;

    return BSP_OK;
}
#endif
/*******************************射频开关最后一级输出配置参数（常0 常1 前级输出 前级反向）*******************************************/
/*PA*/
UINT32 BspUpdateMuxPaOutSelPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case PA_SWITCH_ON:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_PRE_SIG; //前级信号
            break;
        }
        case PA_SWITCH_OFF:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_ZERO; //常0，关pa
            break;
        }
        case PA_SWITCH_ON_FDD:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_ONE; //常1，FDD开
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }
    return BSP_OK;
}
/*LNA*/
UINT32 BspUpdateMuxLnaOutSelPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case LNA_SWITCH_ON:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_PRE_SIG_REV; //前级信号取反
            break;
        }
        case LNA_SWITCH_OFF:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_ONE ; //常1，关lna
            break;
        }
        case LNA_SWITCH_ON_FDD:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_ZERO; //常0，FDD开lna
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }
    return BSP_OK;
}
/*AMP*/
UINT32 BspUpdateMuxAmpOutSelPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case AMP_SWITCH_ON:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_PRE_SIG; //前级信号
            break;
        }
        case AMP_SWITCH_OFF:
        {
            tPara->uiBaseCfg.uiTddOutSelx =IO_OUT_SEL_ZERO ; //常0，关lna
            break;
        }
        case AMP_SWITCH_ON_FDD:
        {
            tPara->uiBaseCfg.uiTddOutSelx = IO_OUT_SEL_ONE; //常1，FDD开lna
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }
    return BSP_OK;
}
/*TX_EN*/
UINT32 BspUpdateMuxTxOutSelPara(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case TX_SWITCH_ON:
        {
            tPara->uiTddOutSelx = IO_OUT_SEL_PRE_SIG; //前级信号
            break;
        }
        case TX_SWITCH_OFF:
        {
            tPara->uiTddOutSelx = IO_OUT_SEL_ZERO; //常0，关tx
            break;
        }
        case TX_SWITCH_ON_FDD:
        {
            tPara->uiTddOutSelx = IO_OUT_SEL_ONE; //常1，FDD开
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }
    return BSP_OK;
}
/*RX_EN*/
UINT32 BspUpdateMuxRxOutSelPara(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case RX_SWITCH_ON:
        {
            tPara->uiTddOutSelx = IO_OUT_SEL_PRE_SIG; //前级信号: 寄存器写2选前级
            break;
        }
        case RX_SWITCH_OFF:
        {
            tPara->uiTddOutSelx = IO_OUT_SEL_ZERO; //常0，关rx: 寄存器写1选常0
            break;
        }
        case RX_SWITCH_ON_FDD:
        {
            tPara->uiTddOutSelx = IO_OUT_SEL_ONE; //常1，FDD开: 寄存器写0选常1
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    dbgInfoEx("[%s] SwitchStatus is %d, uiTddOutSelx %d\n", __FUNCTION__, sw, tPara->uiTddOutSelx);
    return BSP_OK;
}
/*ORX_EN*/
UINT32 BspUpdateMuxFbOutSelPara(T_TDD_BASE_ORX_OUT_CFG *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);
    (E_TDDIO_CTRL_EXCEPT != s_tddIoExceptCtrlX.tddOutSel[E_TDD_IO_DEF_TYPE_ORXENEXCEPT][E_TDD_IO_DEF_TYPE_ENGAGED])? ({}):
                           ({
                                tPara->uiTddOutSelx = \
                                s_tddIoExceptCtrlX.tddOutSel[E_TDD_IO_DEF_TYPE_ORXENEXCEPT][E_TDD_IO_DEF_TYPE_ENGAGED_SETS];
                                return BSP_OK;
                            });

    switch(sw)
    {
        case FB_SWITCH_ON:
        {
            tPara->uiTddOutSelx = IO_ORX_OUT_SEL_TRX_RXEN_REV;  /*对RX_EN取反*/
            break;
        }
        case FB_SWITCH_OFF:
        {
            tPara->uiTddOutSelx = IO_ORX_OUT_SEL_ZERO; //常0，关rx
            break;
        }
        case FB_SWITCH_ON_FDD:
        {
            tPara->uiTddOutSelx = IO_ORX_OUT_SEL_ONE; //常1，FDD开
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }
    return BSP_OK;
}
/*TX_AC_ATT ac_en*/
UINT32 BspUpdateMuxTxAcOutSelPara(T_COMB_2INSTANTIATE_PARA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case TX_AC_SWITCH_ON:
        {
            tPara->tTxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_PRE_SIG; //前级信号
            break;
        }
        case TX_AC_SWITCH_OFF:
        {
            tPara->tTxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_ZERO; //常0，关txAc
            break;
        }
        case TX_AC_SWITCH_ON_FDD:
        {
            tPara->tTxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_ONE; //常1，FDD开
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }
    return BSP_OK;
}
/*RX_AC_ATT ac_en*/
UINT32 BspUpdateMuxRxAcOutSelPara(T_COMB_2INSTANTIATE_PARA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case RX_AC_SWITCH_ON:
        {
            tPara->tRxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_PRE_SIG; //前级信号
            break;
        }
        case RX_AC_SWITCH_OFF:
        {
            tPara->tRxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_ZERO; //常0，关rxAc
            break;
        }
        case RX_AC_SWITCH_ON_FDD:
        {
            tPara->tRxEnAcCfg.uiTddOutSelx = IO_OUT_SEL_ONE; //常1，FDD开
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
/*AC_CTRL*/
UINT32 BspUpdateMuxActrlOutSelPara_Tx0(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    //UINT32 uiAcCtrl = IO_OUT_SEL_PRE_SIG_REV;//S0/S1/S2的默认值都不一样，这里写默认前级

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspUpdateMuxActrlOutSelPara_Rx0(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    //UINT32 uiAcCtrl = IO_OUT_SEL_PRE_SIG_REV;//S0/S1/S2的默认值都不一样，这里写默认前级

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG_REV;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspUpdateMuxActrlOutSelPara_Cal0(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    //UINT32 uiAcCtrl = IO_OUT_SEL_PRE_SIG_REV;//S0/S1/S2的默认值都不一样，这里写默认前级

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG_REV;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspUpdateMuxActrlOutSelPara_Tx1(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    //UINT32 uiAcCtrl = IO_OUT_SEL_PRE_SIG_REV;//S0/S1/S2的默认值都不一样，这里写默认前级

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspUpdateMuxActrlOutSelPara_Rx1(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    //UINT32 uiAcCtrl = IO_OUT_SEL_PRE_SIG_REV;//S0/S1/S2的默认值都不一样，这里写默认前级

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG_REV;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspUpdateMuxActrlOutSelPara_Cal1(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    //UINT32 uiAcCtrl = IO_OUT_SEL_PRE_SIG_REV;//S0/S1/S2的默认值都不一样，这里写默认前级

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG_REV;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspUpdateMuxActrlOutSelPara_Tx2(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    //UINT32 uiAcCtrl = IO_OUT_SEL_PRE_SIG_REV;//S0/S1/S2的默认值都不一样，这里写默认前级

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspUpdateMuxActrlOutSelPara_Rx2(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG_REV;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspUpdateMuxActrlOutSelPara_Cal2(T_AC_CTRL_SW_OUT_CFG *tPara, UINT32 sw)
{

    INPUT_POINTER_CHECK(tPara);

    if(AC_CTRL_SWITCH_ON_FDD < sw)
    {
        dbgErr("[%s] Input switch %d error!!! \n", __func__, sw);
    }

    /*****************************************************
      S0正常选 _PRE_SIG_REV ，关选 _ZERO ，FDD_ON选 _ONE
      如果是Except场景需要相应取反
     *****************************************************/
    switch(sw)
    {
        case AC_CTRL_SWITCH_ON:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_PRE_SIG_REV;
            break;
        }
        case AC_CTRL_SWITCH_OFF:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ONE;
            break;
        }
        case AC_CTRL_SWITCH_ON_FDD:
        {
            tPara->uiAcCtrlOutSel = IO_OUT_SEL_ZERO;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
/********************************************mux初始化参数配置生效**********************************************/
/*初始化palna/amp的mux选择，还要额外提供可以修改参数的接口*/
UINT32 BspInitSetPaMuxPara(UINT32 chn, UINT32 tddSel)
{
    UINT32 ret = BSP_OK;

    ret = BspInitPaMuxPara(chn, tddSel, &g_paMux[chn]);
    if(ret != BSP_OK)
    {
        return ret ;   /*这个bit不使用，或者不需要配置，或者丝印错误*/
    }
    ret = BspHalAdaptSetPaMuxPara(&g_paMux[chn],chn);
    return ret;
}
UINT32 BspInitSetLnaMuxPara(UINT32 chn, UINT32 tddSel)
{
    UINT32 ret = BSP_OK;
    ret = BspInitLnaMuxPara(chn, tddSel, &g_lnaMux[chn]);
    if(ret != BSP_OK)
    {
        return ret ;   /*这个bit不使用，或者不需要配置，或者丝印错误*/
    }
    ret = BspHalAdaptSetLnaMuxPara(&g_lnaMux[chn],chn);
    return ret;
}
UINT32 BspInitSetAmpMuxPara(UINT32 chn, UINT32 tddSel)
{
    UINT32 ret = BSP_OK;
    ret = BspInitAmpMuxPara(chn, tddSel, &g_ampMux[chn]);
    if(ret != BSP_OK)
    {
        return ret ;   /*这个bit不使用，或者不需要配置，或者丝印错误*/
    }
    ret = BspHalAdaptSetAmpMuxPara(&g_ampMux[chn],chn);
    return ret;
}
/*初始化trans的mux选择，还要额外提供可以修改参数的接口*/
UINT32 BspInitSetTransTxMuxPara(UINT32 chn, UINT32 tddSel, UINT32 acType)
{
    UINT32 ret = BSP_OK;

    ret = BspInitTransTxMuxPara(chn, tddSel, &g_transTxMux[chn]);
    if(ret != BSP_OK)
    {
        return ret ;   /*这个bit不使用，或者不需要配置，或者丝印错误*/
    }
    ret |= BspHalAdaptSetTransTxMuxPara(&g_transTxMux[chn], chn);

    return ret;
}
UINT32 BspInitSetTransRxMuxPara(UINT32 chn, UINT32 tddSel, UINT32 acType)
{
    UINT32 ret = BSP_OK;

    ret = BspInitTransRxMuxPara(chn, tddSel, &g_transRxMux[chn]);
    if(ret != BSP_OK)
    {
        return ret ;   /*这个bit不使用，或者不需要配置，或者丝印错误*/
    }
    ret |= BspHalAdaptSetTransRxMuxPara(&g_transRxMux[chn], chn);

    return ret;
}
UINT32 BspInitSetTransOrxMuxPara(UINT32 chn, UINT32 tddSel, UINT32 acType)
{
    UINT32 ret = BSP_OK;

    ret = BspInitTransOrxMuxPara(chn, tddSel, &g_transOrxMux[chn]);
    if(ret != BSP_OK)
    {
        return ret ;   /*这个bit不使用，或者不需要配置，或者丝印错误*/
    }
    ret |= BspHalAdaptSetTransOrxMuxPara(&g_transOrxMux[chn], chn);

    return ret;
}
/*初始化trans acen的mux选择，还要额外提供可以修改参数的接口 这里底层实际将txatt0和txatt1 分别对应第1套和第2套acen
 * chn =0 相当于同时初始化了txatt0 和rxatt0*/
UINT32 BspInitSetTrxAcEnMuxPara(UINT32 chn, UINT32 tddSel)
{
    UINT32 ret = BSP_OK;

    ret |= BspInitMuxTrxAcEnPara(chn, tddSel, &g_trxAcEnMux[chn]);
    ret |= BspHalAdaptSetAcEnMuxPara(&g_trxAcEnMux[chn], chn);

    return ret;
}

/* Started by AICoder, pid:a1e49d1869w0435143c60980d025e62d9457d847 */
UINT32 BspQcellSetAcCtrlMuxPara(T_AC_CTRL_SW_OUT_CFG* g_acCtrlMuxPara, UINT32 acCtrlType)
{

    INPUT_PARAM_RANGE_CHECK(acCtrlType, AC_CTRL_TYPE_NUM);
    INPUT_POINTER_CHECK(g_acCtrlMuxPara);
    if(INVALID_TDDID != acidx_corr_tddid[acCtrlType])
    {
        g_acCtrlMuxPara->uiAcCtrl4Sel1 = acidx_corr_tddid[acCtrlType];
        g_acCtrlMuxPara->uiAcCtrl2Sel1 = 1;
        g_acCtrlMuxPara->uiAcCtrlOutSel = 2;
        g_acCtrlMuxPara->uiAcOut3Sel1 = 0;
    }
    // else
    // {
    //     BspLog(LOG_LEVEL_0,"[%s] acidx_corr_tddid[acCtrlType(%d)]:%d \n",__FUNCTION__,acCtrlType,acidx_corr_tddid[acCtrlType]);
    // }
        
    BspLog(LOG_LEVEL_0,"[%s] acidx_corr_tddid[acCtrlType(%d)]:%d uiAcCtrl4Sel1 %d, uiAcCtrl2Sel1 %d, uiAcCtrlOutSel %d uiAcOut3Sel1:%d \n",__FUNCTION__,\
    acCtrlType, acidx_corr_tddid[acCtrlType], g_acCtrlMuxPara->uiAcCtrl4Sel1, g_acCtrlMuxPara->uiAcCtrl2Sel1, g_acCtrlMuxPara->uiAcCtrlOutSel, g_acCtrlMuxPara->uiAcOut3Sel1);
    return BSP_OK;
}
/* Ended by AICoder, pid:a1e49d1869w0435143c60980d025e62d9457d847 */

/*初始化acctrl的mux选择，还要额外提供可以修改参数的接口*/
UINT32 BspInitSetAcCtrlMuxPara(UINT32 acCtrlType, UINT32 tddSel)
{
    UINT32 ret = BSP_OK;

    ret |= BspInitMuxAcCtrlPara(acCtrlType, tddSel, &g_acCtrlMux[acCtrlType]);
    
    // 如果是 QCELL 并且支持UTDOA，并且是TDD
    if(UTDOA_SUPPORT == support_utdoa) /* && (g_ulTddIoControlPara.tddTimingGenType[tddSel] == 0) */ 
    {
        BspQcellSetAcCtrlMuxPara(&g_acCtrlMux[acCtrlType], acCtrlType);
    }
    ret |= BspHalAdaptSetAcCtrlMuxPara(&g_acCtrlMux[acCtrlType], acCtrlType);  //参数2是指9个bit的ac开关控制信号每种信号只例化1次

    return ret;
}

/*actype 4.0 muxspc功能需要，4.2上暂时保留方便后续需求扩展*/
UINT32 BspInitTddIoMuxPara(UINT32 tddSel, UINT32 acType)   /*mux的初始化参数赋值及初始化参数生效 代替4.0 BspUpdateTddIoMuxPara接口的功能*/
{
    UINT32 chn = 0;
    UINT32 acCtrlType = 0;
    UINT32 ret = BSP_OK;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }

    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }

    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {  /*目前看管脚复用时初始化参数不受影响，所有暂时不启用BspGetWorkAsTypeByTddIoInfo，但是由于有些管脚不使用，
        IC内部同一类型的管脚不同bit可以使用不同tdd，所以不能像4.0一样所有bit使用同一套参数，统一初始化，要分别判断*/
        ret |= BspInitSetPaMuxPara(chn, tddSel);
        ret |= BspInitSetLnaMuxPara(chn, tddSel);
        ret |= BspInitSetAmpMuxPara(chn, tddSel);
    }
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_4; chn++) /*trans txen rxen等开关共4bit*/
    {
        ret |= BspInitSetTransTxMuxPara(chn, tddSel,acType);
        ret |= BspInitSetTransRxMuxPara(chn, tddSel,acType);
        ret |= BspInitSetTransOrxMuxPara(chn, tddSel,acType);
    }
    for(chn = 0; chn < TDD_IO_PIN_TRX_EN_AC_NUM_2; chn++)  /*两套ac_en，一套中就包含tx和rx各一个 一套对应一个transceiver*/
    {
        ret |= BspInitSetTrxAcEnMuxPara(chn, tddSel);         /*txac/rxac/等开关共2bit，每bit对应2通道*/

    }
    for(acCtrlType = 0; acCtrlType < AC_CTRL_TYPE_NUM; acCtrlType++)
    {
        ret |= BspInitSetAcCtrlMuxPara(acCtrlType, tddSel);    /*acctrl开关共9bit，每bit对应1种信号*/
    }

    return ret;
}

/********************************************mux  tdd4选1参数配置生效**********************************************/
#if 0    /*目前看tdd是静态选择的，不用动态切，先注释掉，后续看是否有需求*/
UINT32 BspUpdatePaLnaAmpMux4Sel1Para(UINT32 chn)
{
    UINT32 ret = BSP_OK;

    if(chn >= TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chn);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxPaLna4Sel1Para(chn, &g_paLnaMux[chn]);
    ret |= BspHalAdaptSetPaLnaMuxPara(&g_paLnaMux[chn], chn);

    ret |= BspUpdateMuxAmp4Sel1Para(chn, &g_ampMux[chn]);
    ret |= BspHalAdaptSetAmpMuxPara(&g_ampMux[chn],chn);

    return ret;
}
UINT32 BspUpdateTrxMux4Sel1Para(UINT32 chn)
{
    UINT32 ret = BSP_OK;

    if(chn >= TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chn);
        return BSP_ERROR;
    }
    ret |= BspUpdateMuxTrans4Sel1Para(chn, &g_transMux[chn]);
    ret |= BspHalAdaptSetTransMuxPara(&g_transMux[chn], chn);
    return ret;
}

UINT32 BspUpdateTrxAcEnMux4Sel1Para(UINT32 chn)
{
    UINT32 ret = BSP_OK;

    if(chn >= TDD_IO_PIN_TRX_EN_AC_NUM_2)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chn);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxTrxAcEn4Sel1Para(chn, &g_trxAcEnMux[chn]);
    ret |= BspHalAdaptSetAcEnMuxPara(&g_trxAcEnMux[chn], chn);

    return ret;
}

UINT32 BspUpdateAcCtrlMux4Sel1Para(UINT32 tddSel)
{
    UINT32 ret = BSP_OK;
    UINT32 acCtrlType = 0;

    for(acCtrlType = 0; acCtrlType < AC_CTRL_TYPE_NUM; acCtrlType++)
    {
        ret |= BspUpdataMuxAcCtrl4Sel1Para(tddSel, &g_acCtrlMux[acCtrlType]);
        ret |= BspHalAdaptSetAcCtrlMuxPara(&g_acCtrlMux[acCtrlType], acCtrlType);  //参数2是指S0、S1、S2共3种信号，每种信号只例化1次
    }

    return ret;
}
/*mux的TDD 4选1参数更新及更新参数生效  注意这里目前不包含acctrl的处理，后续要分析是否添加  代替4.0上BspUpdateTddIoMuxPara2接口的功能*/
UINT32 BspUpdateTddIoMux4Sel1Para(VOID)
{
    UINT32 chn = 0;
    UINT32 ret = BSP_OK;

    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {
        ret |= BspUpdatePaLnaAmpMux4Sel1Para(chn);
    }
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_4; chn++)
    {
        ret |= BspUpdateTrxMux4Sel1Para(chn);
    }
    for(chn = 0; chn < TDD_IO_PIN_TRX_EN_AC_NUM_2; chn++)
    {
        ret |= BspUpdateTrxAcEnMux4Sel1Para(chn);
    }

    return ret;
}
#endif
/********************************************mux 最后一级输出更新，也即开关控制**********************************************/
/*设置pa的开关*/
UINT32 BspSetPaTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxPaOutSelPara(&g_paMux[chan], sw);
    ret |= BspHalAdaptSetPaOutSel(chan,g_paMux[chan].uiBaseCfg.uiTddOutSelx );
    return ret;
}
/*设置lna的开关*/
UINT32 BspSetLnaTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxLnaOutSelPara(&g_lnaMux[chan], sw);
    ret |= BspHalAdaptSetLnaOutSel(chan, g_lnaMux[chan].uiBaseCfg.uiTddOutSelx);
    return ret;
}

UINT32 BspSetAmpTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxAmpOutSelPara(&g_ampMux[chan], sw);
    ret |= BspHalAdaptSetAmpOutSel(chan,g_ampMux[chan].uiBaseCfg.uiTddOutSelx);
    return ret;
}
UINT32 BspSetTxTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxTxOutSelPara(&g_transTxMux[chan], sw);
    ret |= BspHalAdaptSetTxEnOutSel(chan,g_transTxMux[chan].uiTddOutSelx);
    return ret;
}

UINT32 BspSetRxTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxRxOutSelPara(&g_transRxMux[chan], sw);
    ret |= BspHalAdaptSetRxEnOutSel(chan, g_transRxMux[chan].uiTddOutSelx);
    return ret;
}

UINT32 BspSetFbTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxFbOutSelPara(&g_transOrxMux[chan], sw);
    ret |= BspHalAdaptSetTransOrxMuxPara(&g_transOrxMux[chan], chan);
    return ret;
}
/*ac_en tx_att*/
UINT32 BspSetTxAcTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxTxAcOutSelPara(&g_trxAcEnMux[chan], sw);
    ret |= BspHalAdaptSetAcEnMuxPara(&g_trxAcEnMux[chan], chan);
    return ret;
}
/*ac_en rx_att*/
UINT32 BspSetRxAcTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    /*目前只变化IO末级的MUX选择*/
    ret |= BspUpdateMuxRxAcOutSelPara(&g_trxAcEnMux[chan], sw);
    ret |= BspHalAdaptSetAcEnMuxPara(&g_trxAcEnMux[chan], chan);

    return ret;

}
/*ac_ctrl*/
UINT32 BspSetAcCtrlTddIoCfg(UINT32 type, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    if(AC_CTRL_SWITCH_ON_FDD < sw || AC_CTRL_TYPE_NUM <= type)
    {
        dbgErr("[%s] Input switch %d type %d error!!!\n", __func__, sw, type);
        return BSP_ERROR;
    }
    switch(type)
      {
          case AC0_CTRL_TX_SW:
          {
              BspUpdateMuxActrlOutSelPara_Tx0(&g_acCtrlMux[type], sw);
              break;
          }
          case AC0_CTRL_RX_SW:
          {
              BspUpdateMuxActrlOutSelPara_Rx0(&g_acCtrlMux[type], sw);
              break;
          }
          case AC0_CTRL_CAL_SW:
          {
                 BspUpdateMuxActrlOutSelPara_Cal0(&g_acCtrlMux[type], sw);
              break;
          }
          case AC1_CTRL_TX_SW:
          {
              BspUpdateMuxActrlOutSelPara_Tx1(&g_acCtrlMux[type], sw);
              break;
          }
          case AC1_CTRL_RX_SW:
          {
              BspUpdateMuxActrlOutSelPara_Rx1(&g_acCtrlMux[type], sw);
              break;
          }
          case AC1_CTRL_CAL_SW:
          {
                 BspUpdateMuxActrlOutSelPara_Cal1(&g_acCtrlMux[type], sw);
              break;
          }
          case AC2_CTRL_TX_SW:
          {
              BspUpdateMuxActrlOutSelPara_Tx2(&g_acCtrlMux[type], sw);
              break;
          }
          case AC2_CTRL_RX_SW:
          {
              BspUpdateMuxActrlOutSelPara_Rx2(&g_acCtrlMux[type], sw);
              break;
          }
          case AC2_CTRL_CAL_SW:
          {
                 BspUpdateMuxActrlOutSelPara_Cal2(&g_acCtrlMux[type], sw);
              break;
          }
          default:
          {
              dbgInfo("%s: Input [%d] Error, Invalid acCtrlType\n", __func__, type);
              break;
          }
      }

    ret |= BspHalAdaptSetAcCtrlMuxPara(&g_acCtrlMux[type], type);

    return ret;
}
UINT32 BspSetTddIoOutSel(UINT32 ioIdx,UINT32 ioType, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    switch(ioType)
    {
        case LINK_INFO_PACHN_TDDIO:
        {
             ret = BspSetPaTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_AMPCHN_TDDIO:
        {
             ret = BspSetAmpTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_LNACHN_TDDIO:
        {
             ret = BspSetLnaTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_TXCHN_TDDIO:
        {
             ret = BspSetTxTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_RXCHN_TDDIO:
        {
             ret = BspSetRxTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_FBCHN_TDDIO:
        {
             ret = BspSetFbTddIoCfg(ioIdx, sw);
             break;
        }
        default:
        {
             dbgErr("ioIdx %d ioType %d can not ctrl\n",ioIdx,ioType);
             break;
        }
    }
    dbgInfoEx("%s:ioIdx %d ioType %d ctrl\n", __FUNCTION__, ioIdx, ioType);
    return ret;
}

/************************************************************************************/
UINT32 BspUpdateMuxPaUeOut2Sel1Para(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case IO_DISABLE:
        {
            tPara->uiBaseCfg.uiUeOut2Sel1 = UE_OUT_SIG_NONAC;
            break;
        }
        case IO_ENABLE:
        {
            tPara->uiBaseCfg.uiUeOut2Sel1 =  UE_OUT_SIG_AC;//按要求修改默认配置
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}

UINT32 BspSetPaUeOutTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    if(chan >= TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s chan = %d.\n",  __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxPaUeOut2Sel1Para(&g_paMux[chan], sw);
    ret |= BspHalAdaptSetPaUeOut2Sel1(chan,g_paMux[chan].uiBaseCfg.uiUeOut2Sel1);
    return ret;
}

UINT32 BspUpdateMuxLnaUeOut2Sel1Para(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case IO_DISABLE:
        {
            tPara->uiBaseCfg.uiUeOut2Sel1 = UE_OUT_SIG_NONAC;
            break;
        }
        case IO_ENABLE:
        {
            tPara->uiBaseCfg.uiUeOut2Sel1 = UE_OUT_SIG_AC;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspSetLnaUeOutTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    if(chan >= TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s chan = %d.\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxLnaUeOut2Sel1Para(&g_lnaMux[chan], sw);
    ret |= BspHalAdaptSetLnaUeOut2Sel1(chan, g_lnaMux[chan].uiBaseCfg.uiUeOut2Sel1);
    return ret;
}

UINT32 BspUpdateMuxAmpUeOut2Sel1Para(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case IO_DISABLE:
        {
            tPara->uiBaseCfg.uiUeOut2Sel1 = UE_OUT_SIG_NONAC;
            break;
        }
        case IO_ENABLE:
        {
            tPara->uiBaseCfg.uiUeOut2Sel1 = UE_OUT_SIG_AC;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspSetAmpUeOutTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    if(chan >= TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s chan = %d.\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxAmpUeOut2Sel1Para(&g_ampMux[chan], sw);
    ret |= BspHalAdaptSetAmpUeOut2Sel1(chan,g_ampMux[chan].uiBaseCfg.uiUeOut2Sel1);
    return ret;
}

UINT32 BspUpdateMuxTransTxUeOut2Sel1Para(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case IO_DISABLE:
        {
            tPara->uiUeOut2Sel1 = UE_OUT_SIG_NONAC;
            break;
        }
        case IO_ENABLE:
        {
            tPara->uiUeOut2Sel1 = UE_OUT_SIG_AC;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspUpdateMuxTransRxUeOut2Sel1Para(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case IO_DISABLE:
        {
            tPara->uiUeOut2Sel1 = UE_OUT_SIG_NONAC;
            break;
        }
        case IO_ENABLE:
        {
            tPara->uiUeOut2Sel1 = UE_OUT_SIG_AC;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspUpdateMuxTransOrxUeOut2Sel1Para(T_TDD_BASE_ORX_OUT_CFG *tPara, UINT32 sw)
{
    INPUT_POINTER_CHECK(tPara);

    switch(sw)
    {
        case IO_DISABLE:
        {
            tPara->uiUeOut2Sel1 = UE_OUT_SIG_NONAC;
            break;
        }
        case IO_ENABLE:
        {
            tPara->uiUeOut2Sel1 = UE_OUT_SIG_AC;
            break;
        }
        default:
        {
            dbgErr("[%s] Input switch is error!!! SwitchStatus is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    return BSP_OK;
}
UINT32 BspSetTxUeOutTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    if(chan >= TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgInfo("%s chan = %d.\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxTransTxUeOut2Sel1Para(&g_transTxMux[chan], sw);
    ret |= BspHalAdaptSetTxEnUeOut2Sel1(chan,g_transTxMux[chan].uiUeOut2Sel1);
    return ret;
}

UINT32 BspSetRxUeOutTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    if(chan >= TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgInfo("%s chan = %d.\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxTransRxUeOut2Sel1Para(&g_transRxMux[chan], sw);
    ret |= BspHalAdaptSetRxEnUeOut2Sel1(chan,g_transRxMux[chan].uiUeOut2Sel1);
    return ret;
}

UINT32 BspSetOrxUeOutTddIoCfg(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    if(chan >= TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgInfo("%s chan = %d.\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    ret |= BspUpdateMuxTransOrxUeOut2Sel1Para(&g_transOrxMux[chan], sw);
    ret |= BspHalAdaptSetTransOrxMuxPara(&g_transOrxMux[chan], chan);
    return ret;
}
/*整体更新各个管脚是否带ac  初始化的时候默认都不带ac,ac校准模式下需要使能调此接口*/
UINT32 BspSetTddIoUeOut2Sel1(UINT32 ioIdx,UINT32 ioType, UINT32 sw)
{
    UINT32 ret = BSP_OK;

    switch(ioType)
    {
        case LINK_INFO_PACHN_TDDIO:
        {
             ret = BspSetPaUeOutTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_AMPCHN_TDDIO:
        {
             ret = BspSetAmpUeOutTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_LNACHN_TDDIO:
        {
             ret = BspSetLnaUeOutTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_TXCHN_TDDIO:
        {
             ret = BspSetTxUeOutTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_RXCHN_TDDIO:
        {
             ret = BspSetRxUeOutTddIoCfg(ioIdx, sw);
             break;
        }
        case LINK_INFO_FBCHN_TDDIO:
        {
             ret = BspSetOrxUeOutTddIoCfg(ioIdx, sw);
             break;
        }
        default:
        {
             break;
        }
    }
    return ret;
}
/******************************************************************************************
                                对外配置接口
******************************************************************************************/
/* Started by AICoder, pid:2e4bf5179a5a404c8ac2832a9117bd3f */
/* Started by AICoder */    /* AI中台代码-星云 start */
/* Ended by AICoder, pid:2e4bf5179a5a404c8ac2832a9117bd3f */
UINT32 FromAcTypeToModeMapSel(UINT32 acType)
{
    switch(acType)
    {
        case E_AC_TYPE_STOP:
        {
            return TDD_IO_MODE_TDD;
        }
        case E_AC_TYPE_DL:
        {
            return TDD_IO_MODE_DL_AC;
        }
        case E_AC_TYPE_UL:
        {
            return TDD_IO_MODE_UL_AC;
        }
        case E_DPD_TYPE_TS:
        {
            return TDD_IO_MODE_DPD_TRANS;
        }
        case E_AC_TYPE_FDD_DL :
        {
            return TDD_IO_MODE_FDD_DL_AC;
        }
        case E_AC_TYPE_FDD_UL :
        {
            return TDD_IO_MODE_FDD_UL_AC;
        }
        case E_AC_TYPE_FDD :
        {
            return TDD_IO_MODE_FDD;
        }
        case E_VSWR_TYPE_STOP :    /*4.2上复用这个宏来产生NR失步检测的时序*/
        {
            return TDD_IO_MODE_TDD;
        }
        default:
        {
            dbgInfo("%s: Input [%d] Error, Invalid actype\n", __FUNCTION__, acType);
            return BSP_ERROR;
        }
    }
}
/* Started by AICoder, pid:2e4bf5179a5a404c8ac2832a9117bd3f */
/* Ended by AICoder */      /* AI中台代码-星云 end */
/* Ended by AICoder, pid:2e4bf5179a5a404c8ac2832a9117bd3f */

UINT32 g_ulDlAcChanMask[DPDIC_MAX_TDD_NUM][PRX] = {0};
UINT32 g_ulUlAcChanMask[DPDIC_MAX_TDD_NUM][PRX] = {0};
UINT32 g_ulAcchInfo[LINK_INFO_TYPE_NUM_TDDIO] = {0};
/* Started by AICoder, pid:b2cb9w1cfa791dc14ef30b09103c9711ec34eecf */
UINT32 setAcchInfo(UINT32 type, UINT32 val)
{
    // 检查类型是否超出有效范围
    if (type >= LINK_INFO_TYPE_NUM_TDDIO)
    {
        return BSP_ERROR;
    }
    // 设置全局数组中的值
    g_ulAcchInfo[type] = val;
    // 返回操作成功状态
    return BSP_OK;
}
/* Ended by AICoder, pid:b2cb9w1cfa791dc14ef30b09103c9711ec34eecf */

/*此IO控制的外部硬件管脚是否是AC通道(1表示ac序列要通过此管脚)，这个参数需要分上下行,下行AC多发一收 上行AC一发多收 [rx,tx]*/
UINT32 BspSetAcMuxSpcChanMask(UINT32 tddSel, UINT32 acType, UINT32 txChanMask, UINT32 rxChanMask)
{
    if((tddSel >= DPDIC_MAX_TDD_NUM)||(acType >= PRX))
    {
        dbgErr("%s: input tddSel %d  or actype %d out of range\n", __FUNCTION__, tddSel,acType);
        return BSP_OK;  /*有提示打印即可*/
    }
    g_ulDlAcChanMask[tddSel][acType] = txChanMask;  /*预留，TXEN由于都由amp控制，所以不存在acch和ch切换，两个输出一直是一样的*/
    g_ulUlAcChanMask[tddSel][acType] = rxChanMask;
    return BSP_OK;
}
UINT32 BspGetAcMuxSpcRxChanMask(UINT32 tddSel, UINT32 acType)
{
    if((tddSel >= DPDIC_MAX_TDD_NUM)||(acType >= PRX))
    {
        dbgInfoEx("%s: input tddSel %d  or actype %d out of range\n", __FUNCTION__, tddSel,acType);
        return BSP_ERROR;
    }
    return g_ulUlAcChanMask[tddSel][acType];
}
UINT32 BspGetAcMuxSpcTxChanMask(UINT32 tddSel, UINT32 acType)
{
    if((tddSel >= DPDIC_MAX_TDD_NUM)||(acType >= PRX))
    {
        dbgInfoEx("%s: input tddSel %d  or actype %d out of range\n", __FUNCTION__, tddSel,acType);
        return BSP_ERROR;
    }
    return g_ulDlAcChanMask[tddSel][acType];
}

/*TDD设置io acch和ch切换的通道*/
UINT32 BspSetTddCommonAcMuxSpcChanMask(UINT32 tddSel, UINT32 acType, UINT32 swType, UINT32 chanMask)
{
    UINT32 loop = 0;
    UINT32 iochan = 0;
    UINT32 ioIdx = 0;
    UINT32 ioTpye = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgInfoEx("%s: input tddSel %d  or actype %d out of range\n", __FUNCTION__, tddSel,acType);
        return BSP_ERROR;
    }
    if(LINK_INFO_AMPCHN_TDDIO == swType)
    {
        for(loop = 0; loop < BSP_IC42_MAX_TX_CHAN_NUM; loop++)
        {
                iochan = 0;
                BspGetAmpIoInfoByRfChn(loop,TX,&iochan);
                ioIdx = iochan&0xf;
                ioTpye = (iochan>>8)&0xf;
                dbgInfoEx("%d %d %d %d\n", acType, swType, loop, iochan);
                if(ioTpye < LINK_INFO_TYPE_NUM_TDDIO)
                {
                    if((1<<loop)&chanMask)
                    {
                        g_ulAcchInfo[ioTpye] |= BIT_SET(ioIdx);
                    }
                    else
                    {
                        g_ulAcchInfo[ioTpye] &= BIT_REV(ioIdx);
                    }
                }
        }
    }
    /* Started by AICoder, pid:c6889a54c1oc38814ddc08c7c05536613c54c38a */
    // 处理 PA 通道类型
    if (swType == LINK_INFO_PACHN_TDDIO)
    {
        for (loop = 0; loop < BSP_IC42_MAX_TX_CHAN_NUM; loop++)
        {
            iochan = 0;
            BspGetPaIoInfoByRfChn(loop, TX, &iochan);
            ioIdx = iochan & 0xf;
            ioTpye = (iochan >> 8) & 0xf;
            dbgInfoEx("%d %d %d %d\n", acType, swType, loop, iochan);

            if (ioTpye < LINK_INFO_TYPE_NUM_TDDIO)
            {
                if ((1 << loop) & chanMask)
                {
                    g_ulAcchInfo[ioTpye] |= BIT_SET(ioIdx);
                }
                else
                {
                    g_ulAcchInfo[ioTpye] &= BIT_REV(ioIdx);
                }
            }
        }
    }
    /* Ended by AICoder, pid:c6889a54c1oc38814ddc08c7c05536613c54c38a */
    return BSP_OK;
}

/*TDD机型，PA LNA AMP(TXEN不使用)，在切换到ac模式时，_ch和_acch同一模式下输出一致*/
UINT32 BspSetMuxSpcTddIoCfg(UINT32 tddsel,UINT32 ioIdx, UINT32 acType)
{
    UINT32 ret = BSP_OK;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};
    UINT32 rxChanMask = 0;
    UINT32 chn = 0;

    ret = BspGetDifInfoByIoChn(ioIdx,LINK_INFO_RXCHN_TDDIO,&Val);
    rxChanMask = BspGetAcMuxSpcRxChanMask(tddsel, acType);
    if((ret != BSP_OK)||(Val.tddNo != tddsel)||(rxChanMask == BSP_ERROR)) /*不属于此套TDD不执行*/
    {
        ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_RXCHN_TDDIO,IO_DISABLE);  /*正常TDD的时候(rxChanMask异常)，要把时序切回*/
        return ret;
    }
    for(chn = 0; chn < Val.rfChNum; chn++)
    {
        dbgInfoEx("%d %d\n",Val.rfChNum,Val.rfCh[chn]);
        if((1<<Val.rfCh[chn])&rxChanMask)
        {
            break;
        }
    }
    if(chn == Val.rfChNum)
    {
        return BSP_OK;
    }
    dbgInfoEx("ioIdx %d acType %d, rxChanMask  0x%x\n",ioIdx,acType,rxChanMask);
    ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_RXCHN_TDDIO,IO_ENABLE);/*ac数据经过的通道设置成ac时序 选择_acch*/
    return ret;
}

/*设置开关的UE 2选1 提供给AC模块使用*/
/* Started by AICoder, pid:51ffa7dedd0e4818a03e649fc099991f */
UINT32 BspSetTddCommonMuxSpcTddIoCfg(UINT32 tddsel, UINT32 ioType,UINT32 ioIdx, UINT32 acType)
{
    UINT32 ret = BSP_OK;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    if((acType != E_AC_TYPE_DL)&&(acType != E_AC_TYPE_UL)&&(acType != E_AC_TYPE_STOP))
    {
        return ret;
    }
    ret = BspGetDifInfoByIoChn(ioIdx,ioType,&Val);
    dbgInfoEx("ioIdx %d  ioType %d Val.tddNo %d g_ulAcchInfo[ioType] %d\n", ioIdx, ioType, Val.tddNo, g_ulAcchInfo[ioType]);
    if((ret != BSP_OK)||(Val.tddNo != tddsel)||(0 == g_ulAcchInfo[ioType])) /*不属于此套TDD不执行*/
    {
        ret = BspSetTddIoUeOut2Sel1(ioIdx,ioType,IO_DISABLE);  /*正常TDD的时候(rxChanMask异常)，要把时序切回*/
        return ret;
    }
    if(0 != (g_ulAcchInfo[ioType]&(1<<ioIdx)))
    {
         ret = BspSetTddIoUeOut2Sel1(ioIdx,ioType,IO_ENABLE);/*ac数据经过的通道设置成ac时序 选择_acch*/
    }
    else
    {
         ret = BspSetTddIoUeOut2Sel1(ioIdx,ioType,IO_DISABLE);/*设置成非ac时序 选择_ch*/
    }

    return ret;
}
/* Ended by AICoder, pid:51ffa7dedd0e4818a03e649fc099991f */

UINT32 BspSetMuxSpcTddIoCfg_FddPa(UINT32 tddsel,UINT32 ioIdx, UINT32 acType)
{
    UINT32 ret = BSP_OK;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};
    UINT32 chn = 0;
    UINT32 ioWorkAs = TDDIO_WORKAS_SELF;

    if((acType != E_AC_TYPE_FDD_DL)&&(acType != E_AC_TYPE_FDD_UL)&&(acType != E_AC_TYPE_FDD))
    {
        return ret;
    }
    ret = BspGetDifInfoByIoChn(ioIdx,LINK_INFO_PACHN_TDDIO,&Val);
    if((ret != BSP_OK)||(Val.tddNo != tddsel)) /*不属于此套TDD不执行*/
    {
        ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_PACHN_TDDIO,IO_DISABLE);  /*正常TDD的时候(rxChanMask异常)，要把时序切回*/
        return ret;
    }

    ret = BspGetWorkAsTypeByTddIoInfo(ioIdx,LINK_INFO_PACHN_TDDIO,&ioWorkAs); /*预留，防止pa管脚控不同器件时，默认参数不一样*/
    if((ret != BSP_OK )||(ioWorkAs != TDDIO_WORKAS_PA))  /*IC内部 pa管脚控制外部amp 直接返回*/
    {
        dbgInfoEx("pa chn %d is not used or not work as pa\n",chn);
        return ret;
    }

    if((acType == E_AC_TYPE_FDD_DL)||(acType == E_AC_TYPE_FDD_UL))
    {
         if(0 == (g_ulAcchInfo[LINK_INFO_PACHN_TDDIO]&(1<<ioIdx)))
         {
              ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_PACHN_TDDIO,IO_ENABLE);/*ac模式选择_acch*/
         }
         else
         {
              ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_PACHN_TDDIO,IO_DISABLE);/*设置成非ac时序 选择_ch*/
         }
    }
    else
    {
        ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_PACHN_TDDIO,IO_DISABLE);/*非ac模式选择非acch*/
    }
    return ret;
}

UINT32 BspSetMuxSpcTddIoCfg_FddLna(UINT32 tddsel,UINT32 ioIdx, UINT32 acType)
{
    UINT32 ret = BSP_OK;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     if((acType != E_AC_TYPE_FDD_DL)&&(acType != E_AC_TYPE_FDD_UL)&&(acType != E_AC_TYPE_FDD))
     {
         return ret;
     }
    ret = BspGetDifInfoByIoChn(ioIdx,LINK_INFO_LNACHN_TDDIO,&Val);
    if((ret != BSP_OK)||(Val.tddNo != tddsel)) /*不属于此套TDD不执行*/
    {
        ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_LNACHN_TDDIO,IO_DISABLE);  /*正常TDD的时候(rxChanMask异常)，要把时序切回*/
        return ret;
    }

    if((acType == E_AC_TYPE_FDD_DL)||(acType == E_AC_TYPE_FDD_UL))
    {
         ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_LNACHN_TDDIO,IO_ENABLE);/*ac模式选择_acch*/
    }
    else
    {
        ret = BspSetTddIoUeOut2Sel1(ioIdx,LINK_INFO_LNACHN_TDDIO,IO_DISABLE);/*非ac模式选择非acch*/
    }
    return ret;
}

UINT32 BspInitTddIoPara(UINT32 tddSel, UINT32 acType)/*代替BspUpdateTddIoPara接口*/
{
    UINT32 modeMapSel = 0;
    UINT32 ret = BSP_OK;
    UINT32 genType = 0;  /*此参数从单板下传入 每套tdd对应的genType*/

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }
    genType = BspGetTddTimingGenSelByTddSel(tddSel);
    /* ModeMap模式配置 */
    if(BSP_ERROR == (modeMapSel = FromAcTypeToModeMapSel(acType)))
    {
        dbgInfo("%s: acType%d, get modeMapSel error!\n", __FUNCTION__, acType);
        modeMapSel = TDD_IO_MODE_TDD;//查找错误，就使用默认正常TDD
        acType = E_AC_TYPE_STOP;
        g_tddIoErrRcdAcTypeCnt++;
    }

    /* TDDIO延时参数配置 */
    ret = BspUpdateTddIoDlyPara(tddSel, acType);
    /* TDDIO延时TDD_timing_gen配置 */
    ret |= BspInitTddBaseTimingGenSel(tddSel,genType);
    /* TDDIO MUX初始化参数配置 */
    ret |= BspInitTddIoMuxPara(tddSel, acType);
    /*设置对应tdd下的mode*/
    ret |= BspSetSwitchModeCtrl(acType,tddSel);

    //ret |= BspInitDtxCfg();   //默认DTX不合入，此时该配置并未生效；DTX开启后配置生效
    //ret |= BspHalAdaptSetDifIoGpEnAll(IO_DTX_GP_SEL);
    dbgInfoEx("%s:> tddSel %d, acType %d\n", __FUNCTION__, tddSel, acType);
    return ret;
}
/*每套TDD的各个提前和滞后时延参数调整量，注意所有参数的单位是CLK@737.28
TDDIO模块总接口BspInitTddSwDelayPara，仅在上电初始化调用1次，所有开关为关闭状态
后续参数更新使用接口BspUpdateTddIoVariablePara，以确保不会变更开关状态*/
UINT32 BspInitTddSwDelayPara(UINT32 tddSel, UINT32 acType)  /*直接上层调用下这个接口两遍即可*/
{
    UINT32 ret = BSP_OK;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }

    if(g_tddIoRecordCnt == 0)
    {
        ret |= BspInitTddIoPara(tddSel, acType);
    }
    else if((acType == E_AC_TYPE_STOP) ||
        (g_tddIoRecordInfo[(g_tddIoRecordCnt-1)%TDDIO_RECORD_MAX_NUM].acType == E_AC_TYPE_STOP))
    {
        ret |= BspInitTddIoPara(tddSel, acType);
    }
    else
    {
        /*若非上一次为非正常TDD模式，则先将参数刷成正常TDD，防止开关存在互斥*/
        ret |= BspInitTddIoPara(tddSel, E_AC_TYPE_STOP);
        BspSysMsDelay(10);
        ret |= BspInitTddIoPara(tddSel, acType);
    }

    g_tddIoRecordInfo[g_tddIoRecordCnt%TDDIO_RECORD_MAX_NUM].acType = acType;
    g_tddIoRecordInfo[g_tddIoRecordCnt%TDDIO_RECORD_MAX_NUM].tddIdx = tddSel;
    g_tddIoRecordCnt++;


    return ret;
}
UINT32 BspInitFddSwDelayPara(UINT32 tddSel, UINT32 acType)  /*直接上层调用下这个接口两遍即可*/
{
    UINT32 ret = BSP_OK;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }

    ret = BspInitTddIoPara(tddSel, acType);  /*上电第一次初始化配置*/

    return ret;
}
UINT32 BspTddIoParaInit(VOID)    //上电初始化调用
{
    UINT32 retVal = BSP_OK;
    UINT32 tddInitNum = 1;

    retVal |= BspSwitchOffStaInit();
    retVal |= BspInitRfSwitchCtrlTddModeMapNum(E_AC_TYPE_NUM);
    tddInitNum = BspGetInitTddNum();
    retVal |= BspSetPaLnaCfg(tddInitNum); //在OE使能前配置,功放保护使能
    switch(tddInitNum)
    {
        case E_INIT_TYPE_SINGLE_TDD:  /*TDD机型*/
              retVal |= BspInitTddSwDelayPara(0,E_AC_TYPE_STOP); /*TDD使用*/
              break;
        case E_INIT_TYPE_FDD:  /*FDD机型*/
              retVal |= BspInitTddSwDelayPara(0,E_AC_TYPE_FDD);  /*FDD使用*/
              break;
        case E_INIT_TYPE_TDDFDD:  /*T+F机型*/
             retVal |= BspInitTddSwDelayPara(0,E_AC_TYPE_STOP);  /*注意对于T+F要初始化两套，一套给TDD通道使用,一套给FDD通道使用*/
             retVal |= BspInitTddSwDelayPara(1,E_AC_TYPE_FDD);
             break;
        case E_INIT_TYPE_MULTI_TDD:  /*FAD双TDD机型，注意这里tdd的编号要和chanmap对应上*/
             retVal |= BspInitTddSwDelayPara(0,E_AC_TYPE_STOP);
             retVal |= BspInitTddSwDelayPara(1,E_AC_TYPE_STOP);
             break;
        case E_INIT_TYPE_QCELL:  /*QCELL TDD +FDD +TDD*/
             retVal |= BspInitTddSwDelayPara(0,E_AC_TYPE_STOP);
             retVal |= BspInitTddSwDelayPara(1,E_AC_TYPE_FDD);
             retVal |= BspInitTddSwDelayPara(2,E_AC_TYPE_STOP);
             break;
        case E_INIT_TYPE_MS:  /*新增特殊场景 子母端*/
        {
            retVal |= BspInitTddSwDelayPara(0,E_AC_TYPE_STOP);
            BspSetPaLnaCfg(E_INIT_TYPE_SINGLE_TDD);
            break;
        }
        /* Started by AICoder, pid:h8fccie90973de314f8a0a549028fa58bde125bd */
        case E_INIT_TYPE_NCR:  /*NCR FDD +TDD +TDD*/
        {
             retVal |= BspInitTddSwDelayPara(0,E_AC_TYPE_FDD);
             retVal |= BspInitTddSwDelayPara(1,E_AC_TYPE_STOP);
             retVal |= BspInitTddSwDelayPara(2,E_AC_TYPE_STOP);
             break;
        }
        /* Ended by AICoder, pid:h8fccie90973de314f8a0a549028fa58bde125bd */
        default:
        {
            break;
        }
    }
    (VOID)BspSetDtxChanIoDly();
    retVal |= BspSetTddIoInitFlag(1);
    return retVal;
}
UINT32 BspUpdateTddIoVariableParaSub(UINT32 tddSel, UINT32 acType)
{
    UINT32 ret = BSP_OK;
    UINT32 chn = 0;
    UINT32 modeMapSel = 0;

    /*判断入参错误*/
    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }

    /* ModeMap模式配置 */
    if(BSP_ERROR == (modeMapSel = FromAcTypeToModeMapSel(acType)))
    {
        dbgInfo("%s: acType%d, get modeMapSel error!\n", __FUNCTION__, acType);
        modeMapSel = TDD_IO_MODE_TDD;//查找错误，就使用默认正常TDD
        acType = E_AC_TYPE_STOP;
        g_tddIoErrRcdAcTypeCnt++;
    }
    ret |= BspUpdateTddIoDlyPara(tddSel, acType);
    ret |= BspSetSwitchModeCtrl(acType,tddSel);
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_4; chn++)
    {
        ret |= BspSetMuxSpcTddIoCfg(tddSel,chn, acType);  /*这里4.0上是根据actype选择_ch和_acch 4.2则对应于UE定位功能*/
        ret |= BspSetDtxByIoChn(chn, acType);
    }
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_4; chn++)
    {
        ret |= BspSetMuxSpcTddIoCfg_FddLna(tddSel,chn, acType);
    }
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {
        ret |= BspSetMuxSpcTddIoCfg_FddPa(tddSel,chn, acType);
        ret |= BspSetTddCommonMuxSpcTddIoCfg(tddSel,LINK_INFO_PACHN_TDDIO, chn, acType);
    }
    //ret |= BspSetSwitchModeCtrl(acType,tddSel);

    ret |= BspSetIoGpEn(tddSel,acType);   /*待hal提供接口*/
    if(E_INIT_TYPE_MS == BspGetInitTddNum())
    {
        for(chn = 0; chn < BspGetTxChannel(); chn++)
        {
            BspHalAdaptSetTsGpEn(chn, SWITCH_ON);   /*一拖三机型 链路GP使能一直打开*/
        }
    }
    ret |= BspSetAllPaLnaBitmap();

    return ret;
}

/* Started by AICoder, pid:x3229m37e4t8b94140db0a4780955f49ff2704ed */
UINT32 BspUpdateTddIoVariablePara(UINT32 tddSel, UINT32 acType)  /*对外提供的调用接口 目前是给DPD AC tddcfg模块调用*/
{
    UINT32 ret = BSP_OK;
    UINT32 exPrn = SWITCH_ON;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }
    if((E_INIT_TYPE_MS == BspGetInitTddNum())&&(E_DPD_TYPE_TS == acType))
    {
        return BSP_ERROR;   /*R9124不支持切换 母端通道即使做TS  基础TDD也满足时序*/
    }
    BspTddSwModeSel(tddSel,acType);

    if(g_tddIoRecordCnt == 0)
    {
        ret |= BspUpdateTddIoVariableParaSub(tddSel, acType);
    }
    else if((acType == E_AC_TYPE_STOP) ||
        (g_tddIoRecordInfo[(g_tddIoRecordCnt-1)%TDDIO_RECORD_MAX_NUM].acType == E_AC_TYPE_STOP))
    {
        ret |= BspUpdateTddIoVariableParaSub(tddSel, acType);
    }
    else
    {
        /*若非上一次为非正常TDD模式，则先将参数刷成正常TDD，防止开关存在互斥*/
        ret |= BspUpdateTddIoVariableParaSub(tddSel, E_AC_TYPE_STOP);
        BspSysMsDelay(10);
        ret |= BspUpdateTddIoVariableParaSub(tddSel, acType);
    }

    g_tddIoRecordInfo[g_tddIoRecordCnt%TDDIO_RECORD_MAX_NUM].acType = acType;
    g_tddIoRecordInfo[g_tddIoRecordCnt%TDDIO_RECORD_MAX_NUM].tddIdx = tddSel;
    g_tddIoRecordCnt++;

    if(1 == g_tddIoPrnFlag)
    {
       BspTddSwDelayParaPrint(tddSel, acType, exPrn);
       BspTddSwMuxParaPrint();
    }
    return ret;

}
/* Ended by AICoder, pid:x3229m37e4t8b94140db0a4780955f49ff2704ed */


/******************************************************************************************
                             功放保护/UE使能/OE使能
******************************************************************************************/
/*功放保护使能 功放保护间隔设置*/
/* Started by AICoder, pid:9c851w46a1sfa7b140b8080a5014059a23279669 */
UINT32 BspSetPaLnaCfg(UINT32 type)    /*单板初始化调用*/
{
    UINT32 chn = 0;
    UINT32 uRet = BSP_OK;
    UINT32 ioWorkAs = TDDIO_WORKAS_SELF;
    T_PA_LNA_PROT_CFG *tPaLnaProt = NULL;
    UINT32 uiProtPaEn = 0;  /*互斥使能关闭*/
    UINT32 uiProtLnaEn = 0;
    UINT32 tddSel = 0;

    tPaLnaProt = (T_PA_LNA_PROT_CFG *)malloc(sizeof(T_PA_LNA_PROT_CFG));
    if (NULL == tPaLnaProt)
    {
        dbgErr("%s>>tPaLnaProt Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    tPaLnaProt ->uiPaNvldVal  = 0;  /*pa和lna同时有效时，功放输出的无效值 功放1是开，0是关，所以0是无效值*/
    tPaLnaProt ->uiLnaNvldVal = 0;  /*低噪放 0是开，1是关，所有1是无效值 ???实际测试结果不是，需要进一步确认*/
    tPaLnaProt ->uiPaProtGap = 0; /*FDD 直接传0*/
    tPaLnaProt ->uiLnaProtGap = 0;
    if(type != 1)  /*FDD收发分离不需要配置，对T+F前4通道TDD需要，后四通道FDD不需要*/
    {
        tPaLnaProt ->uiPaProtGap  = DOUBLE_US_2_UINT32_737(3.5); /*EXCEL F72位置固定3.5us*/
        tPaLnaProt ->uiLnaProtGap = DOUBLE_US_2_UINT32_737(3.5);
        uiProtPaEn = 1;
        uiProtLnaEn = 1;
    }
    uRet = BspHalAdaptSetPaLnaProtCfg(tPaLnaProt);  //配置功放和低噪放的无效值（也即关闭状态的值）
    if(uRet != BSP_OK)
    {
        dbgErr("BspHalAdaptSetPaLnaProtCfg failed \n");
        free(tPaLnaProt);
        return BSP_ERROR;
    }
    /*按理应该是遍历各个类型所有管脚，找出所有用于控制pa和lna的管脚进行设置，但是由于ic内部只有pa和lna有相关寄存器，所以只需要遍历这两类即可，
     * 这里也体现出pa和lna的特殊性，只能他们额外控制别的管脚，不存在其他管脚来控制pa和lna*/
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)  /*Pa和lna的管脚号不再是相同的，分开配置，但是还是配对的*/
    {
        uRet = BspGetWorkAsTypeByTddIoInfo(chn,LINK_INFO_PACHN_TDDIO,&ioWorkAs); /*预留，防止pa管脚控不同器件时，默认参数不一样*/
        if((uRet != BSP_OK )||(ioWorkAs != TDDIO_WORKAS_PA))
        {
            dbgInfoEx("pa chn %d is not used or not work as pa\n",chn);
            continue;
        }
        uRet = BspGetRealTddNoByTddIoInfo(chn,LINK_INFO_PACHN_TDDIO,&tddSel);
        IF_CHK(IS_NCR == BspIsNcr())
        {
            uiProtPaEn = (0 == tddSel) ? 0 : 1;  // FDD不使能，TDD使能
        }
        ELSE
        {
            if( ((type == 2)||(type==4)) && (tddSel==1))/*T+F QCELL 机型FDD 不使能*/
            {
                uiProtPaEn = 0;
            }
            if( (type == 4) && (tddSel != 1) )
            {
                uiProtPaEn = 1;
            }
        }
        dbgInfoEx("lna chn %d  tddSel:%d uiProtPaEn:%d\n",chn,tddSel,uiProtLnaEn);
        uRet |= BspHalAdaptSetPaProtEnCfg(chn,uiProtPaEn); /* 配置互斥保护使能*/
    }
    tddSel = 0;
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {
        uRet = BspGetWorkAsTypeByTddIoInfo(chn,LINK_INFO_LNACHN_TDDIO,&ioWorkAs); /*预留，防止lna管脚控不同器件时，默认参数不一样*/
        if((uRet != BSP_OK )||(ioWorkAs != TDDIO_WORKAS_SELF))
        {
            dbgInfoEx("lna chn %d is not used or not work as lna\n",chn); /*目前只有not used*/
            continue;
        }
        uRet = BspGetRealTddNoByTddIoInfo(chn,LINK_INFO_LNACHN_TDDIO,&tddSel);
        IF_CHK(IS_NCR == BspIsNcr())
        {
            uiProtLnaEn = (0 == tddSel) ? 0 : 1;  // FDD不使能，TDD使能
        }
        ELSE
        {
            if( ((type == 2) || (type==4)) && (tddSel==1))/*T+F QCELL 机型FDD 不使能*/
            {
                uiProtLnaEn = 0;
            }
            if( (type == 4) && (tddSel != 1) )
            {
                uiProtLnaEn = 1;
            }
        }
        dbgInfoEx("lna chn %d  tddSel:%d uiProtPaEn:%d\n",chn,tddSel,uiProtLnaEn);
        uRet |= BspHalAdaptSetLnaProtEnCfg(chn,uiProtLnaEn);/* 配置互斥保护使能*/
    }

    free(tPaLnaProt);

    return uRet;
}
/* Ended by AICoder, pid:9c851w46a1sfa7b140b8080a5014059a23279669 */

/*UE使能配置,这里对外接口按功能类型分别进行初始化，子接口为按管脚进行配置*/
UINT32 BspSetPaTddIoUeEnCfg(UINT32 ioIdx,T_UE_EN_CFG *pUeEnCfg)
{
    UINT32 uRet = BSP_OK;

    uRet = BspHalAdaptSetPaUeEnCfg(pUeEnCfg, ioIdx);

    return uRet;
}

UINT32 BspSetLnaTddIoUeEnCfg(UINT32 ioIdx,T_UE_EN_CFG *pUeEnCfg)
{
    UINT32 uRet = BSP_OK;

    uRet = BspHalAdaptSetLnaUeEnCfg(pUeEnCfg, ioIdx);

    return uRet;
}
UINT32 BspSetTxTddIoUeEnCfg(UINT32 ioIdx,T_UE_EN_CFG *pUeEnCfg)
{
    UINT32 uRet = BSP_OK;

    uRet = BspHalAdaptSetTxUeEnCfg(pUeEnCfg, ioIdx);

    return uRet;
}
UINT32 BspSetRxTddIoUeEnCfg(UINT32 ioIdx,T_UE_EN_CFG *pUeEnCfg)
{
    UINT32 uRet = BSP_OK;

    uRet = BspHalAdaptSetRxUeEnCfg(pUeEnCfg, ioIdx);

    return uRet;
}
UINT32 BspSetOrxTddIoUeEnCfg(UINT32 ioIdx,T_UE_EN_CFG *pUeEnCfg)
{
    UINT32 uRet = BSP_OK;

    uRet = BspHalAdaptSetOrxUeEnCfg(pUeEnCfg, ioIdx);

    return uRet;
}
/*此接口按功能 按通道遍历配置*/
UINT32 BspSetTddIoUeEnCfg(UINT32 ioIdx,UINT32 ioType, T_UE_EN_CFG *pUeEnCfg)
{
    UINT32 ret = BSP_OK;

    switch(ioType)
    {
        case LINK_INFO_PACHN_TDDIO:
        {
             ret = BspSetPaTddIoUeEnCfg(ioIdx, pUeEnCfg);
             break;
        }
        case LINK_INFO_LNACHN_TDDIO:
        {
             ret = BspSetLnaTddIoUeEnCfg(ioIdx, pUeEnCfg);
             break;
        }
        case LINK_INFO_TXCHN_TDDIO:
        {
             ret = BspSetTxTddIoUeEnCfg(ioIdx, pUeEnCfg);
             break;
        }
        case LINK_INFO_RXCHN_TDDIO:
        {
             ret = BspSetRxTddIoUeEnCfg(ioIdx, pUeEnCfg);
             break;
        }
        case LINK_INFO_FBCHN_TDDIO:
        {
             ret = BspSetOrxTddIoUeEnCfg(ioIdx, pUeEnCfg);
             break;
        }
        default:
        {
             break;
        }
    }
    return ret;
}

/*OE使能默认是需要打开的，目前rxen orxen的OE使能在hal写死DIF_HAL_ENABLE，pa lna txen需要funclib控制*/
UINT32 BspSetPaOeEn(UINT32 isEn)
{
    UINT32 ret      = BSP_OK;
    UINT32 chn      = 0;
    UINT32 ioWorkAs = 0;
    UINT32 tmp = 0;

    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {
        ioWorkAs = 0;
        tmp = isEn;
        (VOID)BspGetWorkAsTypeByTddIoInfo(chn,LINK_INFO_PACHN_TDDIO,&ioWorkAs);
        if((ioWorkAs == TDDIO_WORKAS_PA)&&(isEn == 1))
        {
            dbgInfoEx("pa %d oeen should be last\n",chn);
            continue;
        }
        if(isEn == 2)
        {
           tmp = 1;
        }
       dbgInfoEx("chn %d tmp %d\n",chn,tmp);
       ret |= BspHalAdaptSetPaOeEnCfg(chn, tmp);
    }
    return ret;
}
UINT32 BspSetLnaOeEn(UINT32 isEn)
{
    UINT32 ret      = BSP_OK;
    UINT32 chn      = 0;

    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {
        ret |= BspHalAdaptSetLnaOeEnCfg(chn, isEn);
    }
    return ret;
}

UINT32 BspSetTxOeEn(UINT32 isEn)
{
    UINT32 ret      = BSP_OK;
    UINT32 chn      = 0;
    UINT32 chns     = (BspSkipTxEnOeX) ? 2 : 0;

    for(chn = chns; chn < TDD_IO_PIN_NUM_COMMON_4; chn++)
    {
        ret |= BspHalAdaptSetTxOeEnCfg(chn, isEn);
    }
    return ret;
}
UINT32 BspSetRxOeEn(UINT32 isEn)
{
    UINT32 ret = BSP_OK;
    UINT32 chn = 0;

    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_4; chn++)
    {
        ret |= BspHalAdaptSetRxOeEnCfg(chn, isEn);
    }
    return ret;
}
UINT32 BspSetOrxOeEn(UINT32 isEn)
{
    UINT32 ret = BSP_OK;
    UINT32 chn = 0;

    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_4; chn++)
    {
        ret |= BspHalAdaptSetOrxOeEnCfg(chn, isEn);
    }
    return ret;
}

UINT32 BspSetAmpOeEn(UINT32 isEn)
{
    UINT32 ret = BSP_OK;
    UINT32 chn = 0;

    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {
        ret |= BspHalAdaptSetAmpOeEnCfg(chn, isEn);
    }
    return ret;
}

UINT32 BspSetExceptPaLnaOeEnable(VOID)  /*trx校准要开amp 往前挪*/
{
    UINT32 ret = BSP_OK;
    ret = BspSetPaOeEn(1);  /*pa 作amp时开*/
    ret |= BspSetTxOeEn(1);
    ret |= BspSetAmpOeEn(1);
    ret |= BspSetRxOeEn(1);
    ret |= BspSetOrxOeEn(1);
    return ret;
}
UINT32 BspSetPaLnaOeEnable(VOID)    /*保护功放低噪放 放单板初始化最后边*/
{
    UINT32 ret = BSP_OK;

    ret = BspSetPaOeEn(2); /*pa 作pa时开*/
    ret |= BspSetLnaOeEn(1);

    return ret;
}
/******************************************************************************************
                                          DTX相关
（1）除了AC_EN控制的att管脚，其他开关都需要支持DTX是否合入的功能
（2）4.2上dtx实现比4.0复杂，需要选择tdd 不同模式设置是否合入(mux里设置的是对应开关是否合入dtx，这里相当于又加了一级开关选择)，另外不同开关增益合并使能 gp选择
（3）由于hal底层还未实现对应结构体和api，这部分先做遗留
******************************************************************************************/
UINT32 BspSetDlDtxPaCombEn(UINT32 chan, UINT32 mask)  /** 下行DTX PA通道合路配置 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxPaCombEn(chan,mask);
    return ret;
}
UINT32 BspSetDlDtxPaModeMap(UINT32 chan, UINT32 mask) /** 下行DTX PA通道modemap配置 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxPaModeMap(chan,mask);
    return ret;
}
UINT32 BspSetDlDtxPa4Sel1(UINT32 chan, UINT32 sel)  /** 下行DTX PA通道4套tddbase选1 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxPa4Sel1(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxPaOutSel(UINT32 chan, UINT32 sel)  /** 下行DTX PA通道输出选择 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxPaOutSel(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxPaGpSel(UINT32 chan, UINT32 sel)  /** 下行DTX PA通道输出选择 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxPaGpSel(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxComPaSel(UINT32 uiIdx)  /*uiIdx 管脚号  mask :中频通道号对应的掩码 合路时需要两个*/
{
    UINT32 mask = 0;
    UINT32 ret = 0;
    UINT32 ioWorkAs = 0;
    UINT32 loop =0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    ret = BspGetWorkAsTypeByTddIoInfo(uiIdx,LINK_INFO_PACHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK)
    {
       dbgInfoEx("pa chn %d is not used\n ",uiIdx);
       return BSP_ERROR;    /*此管脚未使用*/
    }
    BspGetDifInfoByIoChn(uiIdx , LINK_INFO_PACHN_TDDIO, &Val);
    for(loop = 0; loop < Val.rfChNum; loop++)
    {
        mask |= 1<<Val.rfCh[loop] ;  /*不管实际用途 只管管哪些通道*/
    }
    dbgInfoEx("pa uiIdx %d mask %d\n",uiIdx,mask);

    ret |= BspHalAdaptSetDlDtxComPaSel(uiIdx,mask);

   return ret;
}
UINT32 BspSetDlDtxAmpCombEn(UINT32 chan, UINT32 mask)  /** 下行DTX Amp通道合路配置 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxAmpCombEn(chan,mask);
    return ret;
}
UINT32 BspSetDlDtxAmpModeMap(UINT32 chan, UINT32 mask) /** 下行DTX Amp通道modemap配置 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxAmpModeMap(chan,mask);
    return ret;
}
UINT32 BspSetDlDtxAmp4Sel1(UINT32 chan, UINT32 sel)  /** 下行DTX Amp通道4套tddbase选1 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxAmp4Sel1(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxAmpOutSel(UINT32 chan, UINT32 sel)  /** 下行DTX Amp通道输出选择 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxAmpOutSel(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxAmpGpSel(UINT32 chan, UINT32 sel)  /** 下行DTX Amp通道输出选择 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxAmpGpSel(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxComAmpSel(UINT32 uiIdx)  /*uiIdx 管脚号  mask :中频通道号对应的掩码 合路时需要两个*/
{
    UINT32 mask = 0;
    UINT32 ret = 0;
    UINT32 ioWorkAs = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};
    UINT32 loop =0;

    ret = BspGetWorkAsTypeByTddIoInfo(uiIdx,LINK_INFO_AMPCHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK)
    {
       dbgInfoEx("amp chn %d is not used\n ",uiIdx);
       return BSP_ERROR;    /*此管脚未使用*/
    }
    BspGetDifInfoByIoChn(uiIdx , LINK_INFO_AMPCHN_TDDIO, &Val);
    for(loop = 0; loop < Val.rfChNum; loop++)
    {
        mask |= 1<<Val.rfCh[loop] ;  /*不管实际用途 只管管哪些通道*/
    }
    dbgInfoEx("amp uiIdx %d mask %d\n",uiIdx,mask);

    ret = BspHalAdaptSetDlDtxComAmpSel(uiIdx,mask);
    return ret;
}


UINT32 BspSetDlDtxTxCombEn(UINT32 chan, UINT32 mask)  /** 下行DTX Tx通道合路配置 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxTxCombEn(chan,mask);
    return ret;
}
UINT32 BspSetDlDtxTxModeMap(UINT32 chan, UINT32 mask) /** 下行DTX Tx通道modemap配置 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxTxModeMap(chan,mask);
    return ret;
}
UINT32 BspSetDlDtxTx4Sel1(UINT32 chan, UINT32 sel)  /** 下行DTX Tx通道4套tddbase选1 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxTx4Sel1(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxTxOutSel(UINT32 chan, UINT32 sel)  /** 下行DTX Trx通道输出选择 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxTxOutSel(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxTxGpSel(UINT32 chan, UINT32 sel)  /** 下行DTX Trx通道输出选择 */
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetDlDtxTxGpSel(chan,sel);
    return ret;
}
UINT32 BspSetDlDtxComTxSel(UINT32 uiIdx)  /*uiIdx 管脚号  mask :中频通道号对应的掩码 合路时需要两个*/
{
    UINT32 mask = 0;
    UINT32 ret = 0;
    UINT32 ioWorkAs = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};
    UINT32 loop =0;

    ret = BspGetWorkAsTypeByTddIoInfo(uiIdx,LINK_INFO_TXCHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK)
    {
        dbgInfoEx("tx chn %d is not used\n ",uiIdx);
        return BSP_ERROR;    /*此管脚未使用*/
    }
    BspGetDifInfoByIoChn(uiIdx , LINK_INFO_TXCHN_TDDIO, &Val);
    for(loop = 0; loop < Val.rfChNum; loop++)
    {
        mask |= 1<<Val.rfCh[loop] ;  /*不管实际用途 只管管哪些通道*/
    }
    dbgInfoEx("tx uiIdx %d mask %d\n",uiIdx,mask);

    ret = BspHalAdaptSetDlDtxComTxSel(uiIdx,mask);
    return ret;
}

UINT32 BspSetDlDtxPaCfg(UINT32 chan, T_DL_DTX_SEL *cfg)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(cfg);
    ret |= BspSetDlDtxPaCombEn(chan, cfg->uiDtxEnMask);  /** 下行DTX PA通道合路配置 */
    ret |= BspSetDlDtxPaModeMap(chan, cfg->uiModeMap);   /** 下行DTX PA通道modemap配置 */
    ret |= BspSetDlDtxPa4Sel1(chan, cfg->uiModeMap4Sel1);/** 下行DTX PA通道4套tddbase选1 */
    ret |= BspSetDlDtxPaOutSel(chan, cfg->uiDtxOutSel) ; /** 下行DTX PA通道输出选择 */
    ret |= BspSetDlDtxPaGpSel(chan, cfg->uiGpSel);

    return ret;
}

UINT32 BspSetDlDtxAmpCfg(UINT32 chan, T_DL_DTX_SEL *cfg)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(cfg);
    ret = BspSetDlDtxAmpCombEn(chan, cfg->uiDtxEnMask);   /** 下行DTX amp通道合路配置 */
    ret |= BspSetDlDtxAmpModeMap(chan, cfg->uiModeMap);   /** 下行DTX amp通道modemap配置 */
    ret |= BspSetDlDtxAmp4Sel1(chan, cfg->uiModeMap4Sel1);/** 下行DTX amp通道4套tddbase选1 */
    ret |= BspSetDlDtxAmpOutSel(chan, cfg->uiDtxOutSel) ; /** 下行DTX amp通道输出选择 */
    ret |= BspSetDlDtxAmpGpSel(chan, cfg->uiGpSel);

    return ret;
}

UINT32 BspSetDlDtxTxCfg(UINT32 chan, T_DL_DTX_SEL *cfg)
{
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(cfg);
    ret = BspSetDlDtxTxCombEn(chan, cfg->uiDtxEnMask);      /** 下行DTX Tx通道合路配置 */
    ret |= BspSetDlDtxTxModeMap(chan, cfg->uiModeMap);      /** 下行DTX Tx通道modemap配置 */
    ret |= BspSetDlDtxTx4Sel1(chan, cfg->uiModeMap4Sel1);   /** 下行DTX Tx通道4套tddbase选1 */
    ret |= BspSetDlDtxTxOutSel(chan, cfg->uiDtxOutSel) ;    /** 下行DTX Tx通道输出选择 */
    ret |= BspSetDlDtxTxGpSel(chan, cfg->uiGpSel);

    return ret;
}

UINT32 BspSetUlDtxLnaCfg(UINT32 chan, T_UL_DTX_SEL *cfg)
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetUlDtxLnaSel(chan,cfg);
    return ret;
}
UINT32 BspSetUlDtxRxCfg(UINT32 chan, T_UL_DTX_SEL *cfg)
{
    UINT32 ret = 0;
    ret = BspHalAdaptSetUlDtxRxEnSel(chan,cfg);
    return ret;
}
/*chan:dtx通道号  sel: 选择前边哪个中频通道，目前一一对应配置 一个寄存器，只配置一次，这里还没有分到各个不同管脚模块上去*/
UINT32 BspSetDlDtxRouter(VOID)  /** 下行dlpre 8通道到8通道全路由 */
{
    UINT32 chan = 0;
    UINT32 ret = 0;

    for(chan = 0; chan < DTX_CHAN_MAX; chan++)
    {
/*讨论认为8到8全路由和dtx多通道合并 先一一对应，在IO处理单元DTX合路时实现路由 直接配值而不是掩码 这里没有通道转换*/
        ret |= BspHalAdaptSetDlDtxRouter(chan,chan);
    }
    return ret;
}
/*目前没有上行DTX 需求先不管*/
UINT32 BspSetUlDtxRouter(VOID)  /** 下行送来的8路40bit合路使能掩码配置 */
{
    UINT32 chan = 0;
    UINT32 ret = 0;
    for(chan = 0; chan < DTX_CHAN_MAX; chan++)
    {
        ret |= BspHalAdaptSetUlDtxRouter(chan,chan);
    }
    return ret;
}

/*解决DTX开启时pa\amp\txen使用同样的控制时序，但pa\amp\txen响应时间不同，pa响应快，实际提前TXEN打开，造成MTS本振泄露，可能烧毁功放问题*/
/* Started by AICoder, pid:b569f0f714xd5cd1451e085150fb89508f111996 */
UINT32 BspSetDtxChanIoDly(VOID)
{
    UINT32 loop = 0;
    UINT32 ret = 0;
    UINT32 retVal = 0;
    UINT32 difchan = 0;
    UINT32 chip = 0;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;
    UINT32 ioType = 0;

    if(0 == BspHalAdaptGetDtxDiffDlyFlag())
    {
        return BSP_OK;  /*按需求目前限定在R9614TF机型 其他机型看实际验证情况考虑是否放开*/
    }
    for(loop = 0; loop < BspGetTxChannel(); loop++)
    {
         ret = BspGetDifInfoByBspChn(loop,TX, &chip, &difchan);
         ret |= BspGetTxEnIoInfoByRfChn(loop,TX,&iochan);
         dbgInfo("%s >>>>>>ret = %d chan = %d, difchan = %d, iochan = 0x%x.\n", __FUNCTION__, ret, loop, difchan, iochan);
         ioIdx = iochan&0xf;
         ioType = (iochan>>8)&0xf;
         if(BSP_OK == ret)
         {/*第一路延时：9us-5us = 4us 第二路延时：9+1.3us - 0.5us = 10.3us  前提是外围PA实际硬件是IC内部pa模块控制*/
              retVal |= BspHalAdaptSetDlDtxPaDly(difchan, 4000, 9800);
              switch(ioType)
              {
                  case LINK_INFO_AMPCHN_TDDIO:   /*外部txen由ic内部amp模块控制*/
                  {
                       retVal |= BspHalAdaptSetDlDtxAmpDly(difchan, 0, 10500);
                       break;
                  }
                  case LINK_INFO_TXCHN_TDDIO: /*外部txen由ic内部txen模块控制*/
                  {
                       retVal |= BspHalAdaptSetDlDtxTxenDly(difchan, 0, 10500);
                       break;
                  }
                  default:
                  {
                       dbgErr("ioIdx %d ioType %d can not ctrl\n",ioIdx,ioType);
                       break;
                  }
              }
         }
    }
    return retVal;
}
/* Ended by AICoder, pid:b569f0f714xd5cd1451e085150fb89508f111996 */

UINT32 BspInitDtxCfg(VOID)
{
    UINT32 difchan = 0;
    UINT32 bspchn = 0;
    UINT32 chip = 0;
    UINT32 ioidx = 0;
    UINT32 ret = BSP_OK;
    UINT32 tddIndex =0;
    UINT32 chanNum = 0;
    UINT32 loop = 0;
    UINT32 linkNum = 0;
    T_DifCfgSave* pSaveCfg = NULL;
    T_BspHalAdaptDifTxRoutePara* pPara = NULL;
    UINT32 gpsel =0;
    UINT32 modemap =0;
    UINT32 iochan = 0;

    chanNum = BspGetTxChannel();
    pSaveCfg = GetDifCfgSave(E_DIF_ROUTEPARA_TX);
    INPUT_POINTER_CHECK(pSaveCfg);
    pPara = (T_BspHalAdaptDifTxRoutePara*)pSaveCfg->pAddr;
    INPUT_POINTER_CHECK(pPara);
    linkNum = pSaveCfg->difChNum;
    /*8到8全路由配置 一一对应*/
    BspSetDlDtxRouter();
    /*BspSetUlDtxRouter();*/     /*上行先不配置*/
    /*按中频通道配置 不是管脚*/
    for(bspchn = 0; bspchn < chanNum; bspchn++)  /*是否按实际使用的通道来配置*/
    {
/*        chanmask =  BIT_SET(bspchn);  模块耦合会互相调用不能使用
        tddIndex = BspGetTddCfgIdByChanMask(chanmask);*/
        BspGetPaIoInfoByRfChn(bspchn,TX,&iochan);
        ioidx = iochan&0xf;
        ret = BspGetRealTddNoByTddIoInfo(ioidx,LINK_INFO_PACHN_TDDIO, &tddIndex);
        BspGetDifInfoByBspChn(bspchn,TX, &chip, &difchan);

        for(loop = 0; loop < linkNum; loop++)
        {
            if(pPara[loop].uiDifChan == difchan)
            {
                break;
            }
        }
        if(pPara[loop].uiTddMode  == 0)
        {
            gpsel = 9;
            modemap = 0x1e0;
        }
        else
        {
            gpsel = tddIndex+1;
            modemap = 0x27;
        }
        g_PaDtxPara[difchan].uiDtxEnMask  = 1<<difchan;  /*中频通道号，到io处理单元DTX合入前全是中频通道号*/
        g_PaDtxPara[difchan].uiDtxOutSel  = 2;        /*内部输出 选择前级DTX*/
        g_PaDtxPara[difchan].uiGpSel = gpsel;             /* FDD为9，TDD按当前通道用哪一套tdd 选择下行编号,这里都选择gp时dtx合入，dlpre会选择是否使能*/
        g_PaDtxPara[difchan].uiModeMap = modemap;        /*正常FDD 正常tdd*/
        g_PaDtxPara[difchan].uiModeMap4Sel1 = tddIndex;
        BspSetDlDtxPaCfg(difchan,&g_PaDtxPara[difchan]);

        g_AmpDtxPara[difchan].uiDtxEnMask  = 1<<difchan;
        g_AmpDtxPara[difchan].uiDtxOutSel  = 2;
        g_AmpDtxPara[difchan].uiGpSel = gpsel;
        g_AmpDtxPara[difchan].uiModeMap = modemap;
        g_AmpDtxPara[difchan].uiModeMap4Sel1 = tddIndex;
        BspSetDlDtxAmpCfg(difchan,&g_AmpDtxPara[difchan]);

        g_TxDtxPara[difchan].uiDtxEnMask  = 1<<difchan;
        g_TxDtxPara[difchan].uiDtxOutSel  = 2;    /*内部输出*/
        g_TxDtxPara[difchan].uiGpSel = gpsel;
        g_TxDtxPara[difchan].uiModeMap = modemap;      /*AC不合入 0：DTX选择常1 不合入；1：DTX等于前级DTX*/
        g_TxDtxPara[difchan].uiModeMap4Sel1 = tddIndex;
        BspSetDlDtxTxCfg(difchan,&g_TxDtxPara[difchan]);
    }
    for(ioidx = 0; ioidx < TDD_IO_PIN_NUM_COMMON_8; ioidx++)
    {
        BspSetDlDtxComPaSel(ioidx);
        BspSetDlDtxComAmpSel(ioidx);
    }
    for(ioidx = 0; ioidx < TDD_IO_PIN_NUM_COMMON_4; ioidx++)
    {
        BspSetDlDtxComTxSel(ioidx);
    }
/*上行先不管*/
/*    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_8; chn++)
    {
        //tddIndex = BspGetTddCfgIdByChanMask(bspChanMask);
        tddIndex = 0;
        g_LnaDtxPara[chn].uiDtxEnMask  = chn;
        g_LnaDtxPara[chn].uiDtxOutSel  = 2;    内部输出
        g_LnaDtxPara[chn].uiGpSel = 0;
        g_LnaDtxPara[chn].uiModeMap = 0x181;      AC不合入 0：DTX选择常1 不合入；1：DTX等于前级DTX
        g_LnaDtxPara[chn].uiModeMap4Sel1 = tddIndex;
        BspSetUlDtxLnaCfg(chn,&g_LnaDtxPara[chn]);
    }
    for(chn = 0; chn < TDD_IO_PIN_NUM_COMMON_4; chn++)
    {
       // tddIndex = BspGetTddCfgIdByChanMask(bspChanMask);
        tddIndex = 0;
        g_RxDtxPara[chn].uiDtxEnMask  = chn;
        g_RxDtxPara[chn].uiDtxOutSel  = 2;    内部输出
        g_RxDtxPara[chn].uiGpSel = 0;
        g_RxDtxPara[chn].uiModeMap = 0x181;      AC不合入 0：DTX选择常1 不合入；1：DTX等于前级DTX
        g_RxDtxPara[chn].uiModeMap4Sel1 = tddIndex;
        BspSetUlDtxRxCfg(chn,&g_RxDtxPara[chn]);
    }*/
    return ret;
}

UINT32 BspGetPaDtxGpSelByWorkAs(UINT32 bspChn, UINT32 *pGpSel)
{
    UINT32 iochan = 0;
    UINT32 ioTpye = 0;
    UINT32 ret = 0;
    UINT32 difChan = 0;
    UINT32 chip = 0;

    INPUT_POINTER_CHECK(pGpSel);
    ret = BspGetDifInfoByBspChn(bspChn,TX, &chip, &difChan);
    if((ret != BSP_OK)||(difChan >= DTX_CHAN_MAX))
    {
        dbgErr("get difchan error\n");
        return BSP_ERROR;
    }
    BspGetAmpIoInfoByRfChn(bspChn,TX,&iochan);
    ioTpye = (iochan>>8)&0xf;
    if(LINK_INFO_PACHN_TDDIO == ioTpye)     /*pa和amp一样 则需要按amp配置dtx gpsel*/
    {
        dbgInfoEx("%s bspChn %d gpSel %d\n", __func__, bspChn, *pGpSel);
        *pGpSel = g_PaDtxPara[difChan].uiGpSel;
    }

    return BSP_OK;
}
/*gpsel是0--9 表示dtx生效，但是在gp符号 dtx的信号全是0  gp发不出信号  1-gp0 表示dtx生效在第一套tdd的gp   0--1 表示 dtx常1  不生效*/
UINT32 BspSetIoGpEn(UINT32 tddSel,UINT32 acType)
{
    UINT32 ret = BSP_OK;
    UINT32 chanNum = 0;
    UINT32 difChan = 0;
    UINT32 bspChn = 0;
    UINT32 paGpsel = 0;
    UINT32 txGpsel = 0;
    UINT32 txMuxSpcChan = 0;
    UINT32 chip = 0;
    UINT32 flag = 0;

    chanNum = BspGetTxChannel();
    txMuxSpcChan = BspGetAcMuxSpcTxChanMask(tddSel,acType);
    /*按中频通道配置 不是管脚*/
    for(bspChn = 0; bspChn < chanNum; bspChn++)  /*是否按实际使用的通道来配置*/
    {
        ret = BspGetDifInfoByBspChn(bspChn,TX, &chip, &difChan);
        if((ret != BSP_OK)||(difChan >= DTX_CHAN_MAX))
        {
            dbgErr("get difchan error\n");
            return ret;
        }
        if( g_TxDtxPara[difChan].uiGpSel == 9)  /*FDD机型 不调这个大接口 但是T+F 会调用  这块要进行处理*/
        {
            continue;
        }

        switch(acType)
        {
            case E_AC_TYPE_UL:
            {
                paGpsel = 0;  /*上行ac  pa:不合入gp*/
                txGpsel = 0;    /* 上行ac:txen:非校准通道不合入GP*/
                if(txMuxSpcChan&(1<<difChan))
                {
                    txGpsel =  g_TxDtxPara[difChan].uiGpSel;   /* 上行ac:txen:动态校准通道合入GP*/
                    BspGetPaDtxGpSelByWorkAs(bspChn, &paGpsel);
                }
                break;
            }
            case E_AC_TYPE_DL:
            case E_DPD_TYPE_TS:
            {
                paGpsel =  g_PaDtxPara[difChan].uiGpSel;  /*下行ac、TS:txen和pa都合入GP*/
                txGpsel =  g_TxDtxPara[difChan].uiGpSel;
                break;
            }
            case E_AC_TYPE_STOP:
            {
                paGpsel = 0;
                txGpsel = 0;
                break;
            }
            default:
            {
                paGpsel = 0;
                txGpsel = 0;
                break;
            }
        }
        if(paGpsel == 0)
        {
            paGpsel = 9; /*GP为0的入参不是0，而是9~15的任意值*/
        }
        if(txGpsel == 0)
        {
            txGpsel = 9; /*GP为0的入参不是0，而是9~15的任意值*/
        }
        flag = BspIsRemoteSlaveChan(bspChn, 0);
        if(LINK_REMOTE == flag)
        {
            paGpsel = 1;
            txGpsel = 1;
        }
        ret = BspSetDlDtxPaGpSel(difChan,paGpsel);
        ret |= BspSetDlDtxTxGpSel(difChan,txGpsel);
        ret |= BspSetDlDtxAmpGpSel(difChan,txGpsel);
        dbgInfoEx("tddSel %d acType %d paGpsel %d txGpsel %d\n" ,tddSel,acType,paGpsel,txGpsel);
    }

    return ret;
}
INT32 BspSetDtxByIoChn(UINT32 chan, UINT32 acType) /*这个接口目前看要去掉，4.0是因为mux_spc功能在切换通道,要对应变化dtx合入*/
{
    return BSP_OK;
#if 0
    UINT32 ret = BSP_OK;

    if(acType == E_AC_TYPE_UL)
    {
        ret |= BspSetDtxTxEnTddIoCfg(chan, IO_DTX_OFF);
    }
    else
    {
        if(s_tddIoExceptCtrlX.dlTxEnDtxExecept == E_TDDIO_CTRL_NORMAL)
        {
            ret |= BspSetDtxTxEnTddIoCfg(chan, IO_DTX_ON);
        }
        else
        {
            ret |= BspSetDtxTxEnTddIoCfg(chan, IO_DTX_OFF);
        }
    }

    return ret;
#endif
}

VOID BspDlyDlDtxOutSelDataSaveAndOff(VOID)
{
    UINT32 bspchn = 0;
    UINT32 chanNum = 0;
    UINT32 difchan = 0;
    UINT32 chip = 0;
    chanNum = BspGetTxChannel();
    for(bspchn = 0; bspchn < chanNum; bspchn++)
    {
        if (BspGetDifInfoByBspChn(bspchn,TX, &chip, &difchan) != BSP_OK)
        {
            return;
        }
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        DlyDlDtxTrxOutSelX[difchan] = IcHalApiGetDlDtxTrxOutSel(difchan);
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        DlyDlDtxPaOutSelX[difchan] = IcHalApiGetDlDtxPaOutSel(difchan);
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        DlyDlDtxAmpOutSelX[difchan] = IcHalApiGetDlDtxAmpOutSel(difchan);
        IcHalApiSetDlDtxTrxOutSel(difchan, IO_DTXOUT_ONE);
        IcHalApiSetDlDtxPaOutSel(difchan, IO_DTXOUT_ONE);
        IcHalApiSetDlDtxAmpOutSel(difchan, IO_DTXOUT_ONE);
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        dbgInfo("[%s],bspchn=%d,difchan=%d,saveDtxTrxOut=%d,saveDtxPaOut=%d,saveDtxAmpOut=%d\n",
                __FUNCTION__, bspchn, difchan,
                DlyDlDtxTrxOutSelX[difchan], DlyDlDtxPaOutSelX[difchan], DlyDlDtxAmpOutSelX[difchan]);
    }
}

//IcHalApiSetDlyDlDtxOutSel
VOID BspDlyDlDtxOutSelRecover(VOID)
{
    UINT32 bspchn = 0;
    UINT32 chanNum = 0;
    UINT32 difchan = 0;
    UINT32 chip = 0;
    chanNum = BspGetTxChannel();
    for(bspchn = 0; bspchn < chanNum; bspchn++)
    {
        if (BspGetDifInfoByBspChn(bspchn,TX, &chip, &difchan) != BSP_OK)
        {
            return;
        }
        IcHalApiSetDlDtxTrxOutSel(difchan, IO_DTXOUT_INNER_RET);
        IcHalApiSetDlDtxPaOutSel(difchan, IO_DTXOUT_INNER_RET);
        IcHalApiSetDlDtxAmpOutSel(difchan, IO_DTXOUT_INNER_RET);
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        dbgInfo("[%s],bspchn=%d,difchan=%d,RecoverDtxTrxOut=%d,RecoverDtxPaOut=%d,RecoverDtxAmpOut=%d\n",
                __FUNCTION__, bspchn, difchan,
                DlyDlDtxTrxOutSelX[difchan], DlyDlDtxPaOutSelX[difchan], DlyDlDtxAmpOutSelX[difchan]);
    }
}

UINT32 BspUpdateDtxPa(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 isEn)
{
    INPUT_POINTER_CHECK(tPara);

    switch(isEn)
    {
        case IO_DTX_ON:
        {
            tPara->uiBaseCfg.uiDtxComOrNot = DTX_SIG_SEL;
            break;
        }
        case IO_DTX_OFF:
        {
            tPara->uiBaseCfg.uiDtxComOrNot = DTX_SIG_NON_SEL;
            break;
        }
        default:
        {
            dbgErr("[%s] Input en is error!!! isEn is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    return BSP_OK;
}
UINT32 BspUpdateDtxLna(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 isEn)
{
    INPUT_POINTER_CHECK(tPara);

    switch(isEn)
    {
        case IO_DTX_ON:
        {
            tPara->uiBaseCfg.uiDtxComOrNot = DTX_SIG_SEL;
            break;
        }
        case IO_DTX_OFF:
        {
            tPara->uiBaseCfg.uiDtxComOrNot = DTX_SIG_NON_SEL;
            break;
        }
        default:
        {
            dbgErr("[%s] Input en is error!!! isEn is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    return BSP_OK;
}
UINT32 BspUpdateDtxAmp(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 isEn)
{
    INPUT_POINTER_CHECK(tPara);

    switch(isEn)
    {
        case IO_DTX_ON:
        {
            tPara->uiBaseCfg.uiDtxComOrNot = DTX_SIG_SEL;
            break;
        }
        case IO_DTX_OFF:
        {
            tPara->uiBaseCfg.uiDtxComOrNot = DTX_SIG_NON_SEL;
            break;
        }
        default:
        {
            dbgErr("[%s] Input en is error!!! isEn is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    return BSP_OK;
}
UINT32 BspUpdateDtxTxEn(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 isEn)
{
    INPUT_POINTER_CHECK(tPara);

    switch(isEn)
    {
        case IO_DTX_ON:
        {
            tPara->uiDtxComOrNot = DTX_SIG_SEL;
            break;
        }
        case IO_DTX_OFF:
        {
            tPara->uiDtxComOrNot = DTX_SIG_NON_SEL;
            break;
        }
        default:
        {
            dbgErr("[%s] Input en is error!!! isEn is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    return BSP_OK;
}
UINT32 BspUpdateDtxRxEn(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 isEn)
{
    INPUT_POINTER_CHECK(tPara);

    switch(isEn)
    {
        case IO_DTX_ON:
        {
            tPara->uiDtxComOrNot = DTX_SIG_SEL;
            break;
        }
        case IO_DTX_OFF:
        {
            tPara->uiDtxComOrNot = DTX_SIG_NON_SEL;
            break;
        }
        default:
        {
            dbgErr("[%s] Input en is error!!! isEn is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    return BSP_OK;
}
UINT32 BspUpdateDtxFbEn(T_TDD_BASE_ORX_OUT_CFG *tPara, UINT32 isEn)
{
    INPUT_POINTER_CHECK(tPara);

    switch(isEn)
    {
        case IO_DTX_ON:
        {
            tPara->uiDtxComOrNot = DTX_SIG_SEL;
            break;
        }
        case IO_DTX_OFF:
        {
            tPara->uiDtxComOrNot = DTX_SIG_NON_SEL;
            break;
        }
        default:
        {
            dbgErr("[%s] Input en is error!!! isEn is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    return BSP_OK;
}

UINT32 BspSetDtxPaTddIoCfg(UINT32 chan, UINT32 isEn)
{
    UINT32 ret = BSP_OK;

    if(chan >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s chan [%d] over %d!!!\n", __FUNCTION__, chan,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    ret |= BspUpdateDtxPa(&g_paMux[chan], isEn);
    ret |= BspHalAdaptSetPaDtxCombEn(chan,g_paMux[chan].uiBaseCfg.uiDtxComOrNot);
    return ret;
}

UINT32 BspSetDtxLnaTddIoCfg(UINT32 chan, UINT32 isEn)
{
    UINT32 ret = BSP_OK;

    if(chan >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s chan [%d] over %d!!!\n", __FUNCTION__, chan,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    ret |= BspUpdateDtxLna(&g_lnaMux[chan], isEn);
    ret |= BspHalAdaptSetLnaDtxCombEn(chan, g_lnaMux[chan].uiBaseCfg.uiDtxComOrNot);
    return ret;
}
UINT32 BspSetDtxAmpTddIoCfg(UINT32 chan, UINT32 isEn)
{
    UINT32 ret = BSP_OK;

    if(chan >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s chan [%d] over %d!!!\n", __FUNCTION__, chan,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    ret |= BspUpdateDtxAmp(&g_ampMux[chan], isEn);
    ret |= BspHalAdaptSetAmpDtxCombEn(chan,g_ampMux[chan].uiBaseCfg.uiDtxComOrNot);
    return ret;
}

UINT32 BspSetDtxTxTddIoCfg(UINT32 chan, UINT32 isEn)
{
    UINT32 ret = BSP_OK;

    if(chan >= (UINT32)TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgInfo("%s chan [%d] over %d!!!\n", __FUNCTION__, chan,TDD_IO_PIN_NUM_COMMON_4);
        return BSP_ERROR;
    }

    ret |= BspUpdateDtxTxEn(&g_transTxMux[chan], isEn);
    ret |= BspHalAdaptSetTxEnDtxCombEn(chan,g_transTxMux[chan].uiDtxComOrNot);
    return ret;

}
UINT32 BspSetDtxRxTddIoCfg(UINT32 chan, UINT32 isEn)
{
    UINT32 ret = BSP_OK;

    if(chan >= (UINT32)TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgInfo("%s chan [%d] over %d!!!\n", __FUNCTION__, chan,TDD_IO_PIN_NUM_COMMON_4);
        return BSP_ERROR;
    }

    ret |= BspUpdateDtxRxEn(&g_transRxMux[chan], isEn);
    ret |= BspHalAdaptSetRxEnDtxCombEn(chan,g_transRxMux[chan].uiDtxComOrNot);
    return ret;

}

UINT32 BspSetDtxFbTddIoCfg(UINT32 chan, UINT32 isEn)
{
    UINT32 ret = BSP_OK;

    if(chan >= (UINT32)TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgInfo("%s chan [%d] over %d!!!\n", __FUNCTION__, chan,TDD_IO_PIN_NUM_COMMON_4);
        return BSP_ERROR;
    }

    ret |= BspUpdateDtxFbEn(&g_transOrxMux[chan], isEn);
    ret |= BspHalAdaptSetTransOrxMuxPara(&g_transOrxMux[chan], chan);
    return ret;

}
UINT32 BspSetTddIoDtxEnCfg(UINT32 ioIdx,UINT32 ioType, UINT32 isEn)
{
    UINT32 ret = BSP_OK;

    switch(ioType)
    {
        case LINK_INFO_PACHN_TDDIO:
        {
             ret = BspSetDtxPaTddIoCfg(ioIdx, isEn);
             break;
        }
        case LINK_INFO_LNACHN_TDDIO:
        {
             ret = BspSetDtxLnaTddIoCfg(ioIdx, isEn);
             break;
        }
        case LINK_INFO_TXCHN_TDDIO:
        {
             ret = BspSetDtxTxTddIoCfg(ioIdx, isEn);
             break;
        }
        case LINK_INFO_RXCHN_TDDIO:
        {
             ret = BspSetDtxRxTddIoCfg(ioIdx, isEn);
             break;
        }
        case LINK_INFO_FBCHN_TDDIO:
        {
             ret = BspSetDtxFbTddIoCfg(ioIdx, isEn);
             break;
        }
        case LINK_INFO_AMPCHN_TDDIO:
        {
             ret = BspSetDtxAmpTddIoCfg(ioIdx, isEn);
             break;
        }
        default:
        {
             break;
        }
    }
    return ret;
}


/*以下为维测接口*/
/* Started by AICoder, pid:13029g2340ec1f1140fa0931017ec38a61a7441c */
UINT32 BspPaLnaParaPrint(UINT32 tddSel, UINT32 acType)
{
    UINT32 modeMap = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range.\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }

    modeMap = FromAcTypeToModeMapSel(acType);
    if(modeMap == BSP_ERROR)
    {
        return BSP_ERROR;
    }
    dbgInfo(">>>>>>> %s: PaLnaPara Output: tddSel: %d, tddMode: %d\n", __FUNCTION__, tddSel, BspGetTddSwModeSel(tddSel));
    dbgInfo(">>>>>>> Pa&Lna BasePara and ModeMap\n");
    dbgInfo(" 参数1: %d[CLK@737.28], %.6f[us]\n 参数2: %d[CLK@737.28], %.6f[us]\n 参数5: %d[CLK@737.28], %.6f[us]\n 参数7: %d[CLK@737.28], %.6f[us]\n 参数8: %d[CLK@737.28], %.6f[us]\n 参数11: %d[CLK@737.28], %.6f[us]\n\n",
        g_paLnaPara[tddSel].tBasePara.uiDlDIsEnDly1,     UINT32_737_2_DOUBLE_US(g_paLnaPara[tddSel].tBasePara.uiDlDIsEnDly1),
        g_paLnaPara[tddSel].tBasePara.uiAcDlDisEnDly1,   UINT32_737_2_DOUBLE_US(g_paLnaPara[tddSel].tBasePara.uiAcDlDisEnDly1),
        g_paLnaPara[tddSel].tBasePara.uiDlPreEn1,        UINT32_737_2_DOUBLE_US(g_paLnaPara[tddSel].tBasePara.uiDlPreEn1),
        g_paLnaPara[tddSel].tBasePara.uiAcUlPreEn1,      UINT32_737_2_DOUBLE_US(g_paLnaPara[tddSel].tBasePara.uiAcUlPreEn1),
        g_paLnaPara[tddSel].tBasePara.uiUlPreEn1,        UINT32_737_2_DOUBLE_US(g_paLnaPara[tddSel].tBasePara.uiUlPreEn1),
        g_paLnaPara[tddSel].tBasePara.uiUlDIsEnDly1,     UINT32_737_2_DOUBLE_US(g_paLnaPara[tddSel].tBasePara.uiUlDIsEnDly1));

    if(SWITCH_ON == g_extTddIoPrnFlag)
    {
        dbgInfo(" Tx_ModeMapSel: txcom %d\n txac: %d\n Rx_ModeMapSel: rxcom %d\n rxac: %d\n",
            g_paLnaPara[tddSel].tTxComSwMap.uiModeMapSel[modeMap], g_paLnaPara[tddSel].tTxAcSwMap.uiModeMapSel[modeMap],
            g_paLnaPara[tddSel].tRxComSwMap.uiModeMapSel[modeMap], g_paLnaPara[tddSel].tRxAcSwMap.uiModeMapSel[modeMap]);
    }
    return BSP_OK;
}
UINT32 BspAmpParaPrint(UINT32 tddSel, UINT32 acType)
{
    UINT32 modeMap = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range.\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }

    modeMap = FromAcTypeToModeMapSel(acType);
    if(modeMap == BSP_ERROR)
    {
        return BSP_ERROR;
    }
    dbgInfo(">>>>>>> %s: AmpPara Output:\n tddSel: %d, tddMode: %d\n", __FUNCTION__, tddSel, BspGetTddSwModeSel(tddSel));
    dbgInfo(">>>>>>> Amp BasePara and ModeMap\n");
    dbgInfo(" 参数1: %d[CLK@737.28], %.6f[us]\n  参数2: %d[CLK@737.28], %.6f[us]\n  参数3: %d[CLK@737.28], %.6f[us]\n  参数4: %d[CLK@737.28], %.6f[us]\n  参数5: %d[CLK@737.28], %.6f[us]\n  参数6: %d[CLK@737.28], %.6f[us]\n  参数7: %d[CLK@737.28], %.6f[us]\n \
参数8: %d[CLK@737.28], %.6f[us]\n  参数9: %d[CLK@737.28], %.6f[us]\n  参数10: %d[CLK@737.28], %.6f[us]\n  参数11: %d[CLK@737.28], %.6f[us]\n  参数12: : %d[CLK@737.28], %.6f[us]\n",
        g_AmpPara[tddSel].tAmpBasePara.uiDlDIsEnDly1,     UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiDlDIsEnDly1),
        g_AmpPara[tddSel].tAmpBasePara.uiAcDlDisEnDly1,   UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiAcDlDisEnDly1),
        g_AmpPara[tddSel].tAmpBasePara.uiDlDisEnDly2,     UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiDlDisEnDly2),
        g_AmpPara[tddSel].tAmpBasePara.uiAcDlDisEnDly2,   UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiAcDlDisEnDly2),
        g_AmpPara[tddSel].tAmpBasePara.uiDlPreEn1,        UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiDlPreEn1),
        g_AmpPara[tddSel].tAmpBasePara.uiDlPreEn2,        UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiDlPreEn2),
        g_AmpPara[tddSel].tAmpBasePara.uiAcUlPreEn1,      UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiAcUlPreEn1),
        g_AmpPara[tddSel].tAmpBasePara.uiUlPreEn1,        UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiUlPreEn1),
        g_AmpPara[tddSel].tAmpBasePara.uiAcUlPreEn2,      UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiAcUlPreEn2),
        g_AmpPara[tddSel].tAmpBasePara.uiUlPreEn2,        UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiUlPreEn2),
        g_AmpPara[tddSel].tAmpBasePara.uiUlDIsEnDly1,     UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiUlDIsEnDly1),
        g_AmpPara[tddSel].tAmpBasePara.uiUlDIsEnDly2,     UINT32_737_2_DOUBLE_US(g_AmpPara[tddSel].tAmpBasePara.uiUlDIsEnDly2));
    if(SWITCH_ON == g_extTddIoPrnFlag)
    {
        dbgInfo(" Tx_ModeMapSel: txcom %d\n : txac %d\n\n",
                g_AmpPara[tddSel].tAmpComSwMap.uiModeMapSel[modeMap], g_AmpPara[tddSel].tAmpAcSwMap.uiModeMapSel[modeMap]);
    }
    return BSP_OK;
}

UINT32 BspTransParaPrint(UINT32 tddSel, UINT32 acType)
{
    UINT32 modeMap = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)   //因HAL目前结构体中uiModeMapSel定义的是9，实际ACEN是11，待HAL修改后优化
    {
        dbgErr("%s: input acType %d out of range\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }
    modeMap = FromAcTypeToModeMapSel(acType);
    if(modeMap == BSP_ERROR)
    {
        return BSP_ERROR;
    }
    dbgInfo(">>>>>>>%s: TransPara Output: tddSel: %d, tddMode: %d\n", __FUNCTION__, tddSel, BspGetTddSwModeSel(tddSel));

    dbgInfo(">>>>>>> TRX BasePara and ModeMap\n");

    dbgInfo("  参数1: %d[CLK@737.28], %.6f[us]\n  参数2: %d[CLK@737.28], %.6f[us]\n  参数3: %d[CLK@737.28], %.6f[us]\n  参数4: %d[CLK@737.28], %.6f[us]\n  参数5: %d[CLK@737.28], %.6f[us]\n  参数6: %d[CLK@737.28], %.6f[us]\n  参数7: %d[CLK@737.28], %.6f[us]\n \
 参数8: %d[CLK@737.28], %.6f[us]\n  参数9: %d[CLK@737.28], %.6f[us]\n  参数10: %d[CLK@737.28], %.6f[us]\n  参数11: %d[CLK@737.28], %.6f[us]\n  参数12: %d[CLK@737.28], %.6f[us]\n",
             g_transPara[tddSel].tTrxBasePara.uiDlDIsEnDly1,     UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiDlDIsEnDly1),
             g_transPara[tddSel].tTrxBasePara.uiAcDlDisEnDly1,   UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiAcDlDisEnDly1),
             g_transPara[tddSel].tTrxBasePara.uiDlDisEnDly2,     UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiAcDlDisEnDly2),
             g_transPara[tddSel].tTrxBasePara.uiAcDlDisEnDly2,   UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiAcDlDisEnDly1),
             g_transPara[tddSel].tTrxBasePara.uiDlPreEn1,        UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiDlPreEn1),
             g_transPara[tddSel].tTrxBasePara.uiDlPreEn2,        UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiDlPreEn2),
             g_transPara[tddSel].tTrxBasePara.uiAcUlPreEn1,      UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiAcUlPreEn1),
             g_transPara[tddSel].tTrxBasePara.uiUlPreEn1,        UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiUlPreEn1),
             g_transPara[tddSel].tTrxBasePara.uiAcUlPreEn2,      UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiAcUlPreEn2),
            g_transPara[tddSel].tTrxBasePara.uiUlPreEn2,         UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiUlPreEn2),
            g_transPara[tddSel].tTrxBasePara.uiUlDIsEnDly1,      UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiUlDIsEnDly1),
            g_transPara[tddSel].tTrxBasePara.uiUlDIsEnDly2,      UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTrxBasePara.uiUlDIsEnDly2));
    if(SWITCH_ON == g_extTddIoPrnFlag)
    {
        dbgInfo(" TxCom_ModeMapSel: %d\n TxCom_ModeNum: %d\n TxAc_ModeMapSel: %d\n TxAc_ModeNum: %d\n RxCom_ModeMapSel: %d\n RxCom_ModeNum: %d\n RxAc_ModeMapSel: %d\n RxAc_ModeNum: %d\n",
        g_transPara[tddSel].tTxComSwMap.uiModeMapSel[modeMap], g_transPara[tddSel].tTxComSwMap.uiModeNum,
        g_transPara[tddSel].tTxAcSwMap.uiModeMapSel[modeMap], g_transPara[tddSel].tTxAcSwMap.uiModeNum,
        g_transPara[tddSel].tRxComSwMap.uiModeMapSel[modeMap], g_transPara[tddSel].tRxComSwMap.uiModeNum,
        g_transPara[tddSel].tRxAcSwMap.uiModeMapSel[modeMap], g_transPara[tddSel].tRxAcSwMap.uiModeNum);

        dbgInfo(">>>>>>> ORX BasePara and ModeMap选择\n");
        dbgInfo("  参数1: %d[CLK@737.28], %.6f[us]\n  参数2: %d[CLK@737.28], %.6f[us]\n  参数3: %d[CLK@737.28], %.6f[us]\n  参数4: %d[CLK@737.28], %.6f[us]\n  参数5: %d[CLK@737.28], %.6f[us]\n  参数6: %d[CLK@737.28], %.6f[us]\n  参数7: %d[CLK@737.28], %.6f[us]\n \
    参数8: %d[CLK@737.28], %.6f[us]\n  参数9: %d[CLK@737.28], %.6f[us]\n  参数10: %d[CLK@737.28], %.6f[us]\n  参数11: %d[CLK@737.28], %.6f[us]\n  参数12: : %d[CLK@737.28], %.6f[us]\n",
                g_transPara[tddSel].tOrxBasePara.uiDlDIsEnDly1,     UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiDlDIsEnDly1),
                g_transPara[tddSel].tOrxBasePara.uiAcDlDisEnDly1,   UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiAcDlDisEnDly1),
                g_transPara[tddSel].tOrxBasePara.uiDlDisEnDly2,     UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiAcDlDisEnDly2),
                g_transPara[tddSel].tOrxBasePara.uiAcDlDisEnDly2,   UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiAcDlDisEnDly1),
                g_transPara[tddSel].tOrxBasePara.uiDlPreEn1,        UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiDlPreEn1),
                g_transPara[tddSel].tOrxBasePara.uiDlPreEn2,        UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiDlPreEn2),
                g_transPara[tddSel].tOrxBasePara.uiAcUlPreEn1,      UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiAcUlPreEn1),
                g_transPara[tddSel].tOrxBasePara.uiUlPreEn1,        UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiUlPreEn1),
                g_transPara[tddSel].tOrxBasePara.uiAcUlPreEn2,      UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiAcUlPreEn2),
                g_transPara[tddSel].tOrxBasePara.uiUlPreEn2,        UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiUlPreEn2),
                g_transPara[tddSel].tOrxBasePara.uiUlDIsEnDly1,     UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiUlDIsEnDly1),
                g_transPara[tddSel].tOrxBasePara.uiUlDIsEnDly2,     UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tOrxBasePara.uiUlDIsEnDly2));
        dbgInfo(" ModeMapSel: %d ModeNum: %d\n",
            g_transPara[tddSel].tOrxComSwMap.uiModeMapSel[modeMap], g_transPara[tddSel].tOrxComSwMap.uiModeNum);

        dbgInfo(">>>>>>> TX AC_EN1 BasePara and ModeMap\n");
        dbgInfo(" 参数13: %d[CLK@737.28], %f[us]\n 参数14: %d[CLK@737.28], %f[us]\n 参数15: %d[CLK@737.28], %f[us] txen_timing: %d %f[us] \n",
            g_transPara[tddSel].tTxACEnPara1.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara1.uiAcEnDly),
            g_transPara[tddSel].tTxACEnPara1.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara1.uiAcDisEnDly1),
            g_transPara[tddSel].tTxACEnPara1.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara1.uiAcDisEnDly2),
            g_transPara[tddSel].tTxACEnPara1.uiAcEnTiming2Sel1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara1.uiAcEnTiming2Sel1));
        dbgInfo(" ModeMapSel: %d ModeNum: %d\n",
            g_transPara[tddSel].tTxAcEnMap1.uiModeMapSel[modeMap], g_transPara[tddSel].tTxAcEnMap1.uiModeNum);

        dbgInfo(">>>>>>> TX AC_EN2 BasePara and ModeMap\n");
        dbgInfo(" 参数13: %d[CLK@737.28], %f[us]\n 参数14: %d[CLK@737.28], %f[us]\n 参数15: %d[CLK@737.28], %f[us] txen_timing选择（0对应timing1 1对应timing2）：: %d %f[us] \n",
            g_transPara[tddSel].tTxACEnPara2.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara2.uiAcEnDly),
            g_transPara[tddSel].tTxACEnPara2.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara2.uiAcDisEnDly1),
            g_transPara[tddSel].tTxACEnPara2.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara2.uiAcDisEnDly2),
            g_transPara[tddSel].tTxACEnPara2.uiAcEnTiming2Sel1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tTxACEnPara2.uiAcEnTiming2Sel1));
        dbgInfo("ModeMapSel: %d ModeNum: %d\n",
            g_transPara[tddSel].tTxAcEnMap2.uiModeMapSel[modeMap], g_transPara[tddSel].tTxAcEnMap2.uiModeNum);

        dbgInfo(">>>>>>> RX AC_EN1 BasePara and ModeMap\n");
        dbgInfo(" 参数13: %d[CLK@737.28], %f[us]\n 参数14: %d[CLK@737.28], %f[us]\n 参数15: %d[CLK@737.28], %f[us] txen_timing选择（0对应timing1 1对应timing2）：: %d %f[us] \n",
            g_transPara[tddSel].tRxACEnPara1.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara1.uiAcEnDly),
            g_transPara[tddSel].tRxACEnPara1.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara1.uiAcDisEnDly1),
            g_transPara[tddSel].tRxACEnPara1.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara1.uiAcDisEnDly2),
            g_transPara[tddSel].tRxACEnPara1.uiAcEnTiming2Sel1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara1.uiAcEnTiming2Sel1));
        dbgInfo(" ModeMapSel: %d ModeNum: %d\n",
            g_transPara[tddSel].tRxAcEnMap1.uiModeMapSel[modeMap], g_transPara[tddSel].tRxAcEnMap1.uiModeNum);

        dbgInfo(">>>>>>> RX AC_EN2 BasePara and ModeMap\n");
        dbgInfo(" 参数13: %d[CLK@737.28], %f[us]\n 参数14: %d[CLK@737.28], %f[us]\n 参数15: %d[CLK@737.28], %f[us] txen_timing选择（0对应timing1 1对应timing2）：: %d %f[us] \n",
            g_transPara[tddSel].tRxACEnPara2.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara2.uiAcEnDly),
            g_transPara[tddSel].tRxACEnPara2.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara2.uiAcDisEnDly1),
            g_transPara[tddSel].tRxACEnPara2.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara2.uiAcDisEnDly2),
            g_transPara[tddSel].tRxACEnPara2.uiAcEnTiming2Sel1, UINT32_737_2_DOUBLE_US(g_transPara[tddSel].tRxACEnPara2.uiAcEnTiming2Sel1));
    
    }
    dbgInfo(" ModeMapSel: %d ModeNum: %d\n",
        g_transPara[tddSel].tRxAcEnMap2.uiModeMapSel[modeMap], g_transPara[tddSel].tRxAcEnMap2.uiModeNum);
    return BSP_OK;
}
/* Ended by AICoder, pid:13029g2340ec1f1140fa0931017ec38a61a7441c */

UINT32 BspPaMuxPrint(UINT32 chn)
{
    UINT32 genType = 0;
    UINT32 tddSel = 0;
    UINT32 ret = BSP_OK;
    UINT32 ioWorkAs = 0;

    if(chn >= TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chn);
        return BSP_ERROR;
    }
      ret = BspGetWorkAsTypeByTddIoInfo(chn,LINK_INFO_PACHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK )
    {
        dbgInfoEx("PA chn %d is not used\n",chn);
        return BSP_ERROR;
    }
    tddSel = g_paMux[chn].uiBaseCfg.uiTddOut4Sel1x;
    genType = BspGetTddTimingGenSelByTddSel(tddSel);

    INPUT_PARAM_RANGE_CHECK(genType, DPDIC_MAX_TIMING_GEN_SEL_TYPE);

    dbgInfo("%s: PaMux Output: chn: %d tddSel%d ioWorkAs %d \n", __FUNCTION__, chn,tddSel,ioWorkAs);

    dbgInfo(">>>>>>>TX timingGel Setting\n"); /*上升沿和下降沿的选择*/
    dbgInfo("tTxTiming:         uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tTxTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcTiming:       uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcInslotTiming: uiTxFall4Sel1: %d,uiTxRise2Sel1: %d uiTxAcInslot2Sel1: %d uiTxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxRise2Sel1,
            g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxAcInslot2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxAcInslotOut2Sel1);
    dbgInfo("tRxTiming:         uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tRxTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcTiming:       uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcInslotTiming: uiRxFall2Sel1: %d,uiRxRise4Sel1: %d uiRxAcInslot2Sel1: %d uiRxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxRise4Sel1,
            g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxAcInslot2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxAcInslotOut2Sel1);

    dbgInfo(">>>>>>> Alarm MUX Setting\n");
    dbgInfo("tPaLnaAlarmCfg: uiPaAlarmEn: %d\n",g_paMux[chn].uiAlarmEn);

    dbgInfo(">>>>>>> PA MUX Setting\n");
    dbgInfo("tPaCfg: uiPaLna4Sel1x: %d,uiDtxComOrNot: %d, uiPaLnaOutSelx: %d, uiAlarmComOrNot: %d\n",
            g_paMux[chn].uiBaseCfg.uiTddOut4Sel1x, g_paMux[chn].uiBaseCfg.uiDtxComOrNot, g_paMux[chn].uiBaseCfg.uiTddOutSelx, g_paMux[chn].uiBaseCfg.uiUeOut2Sel1);
    dbgInfo("\n");
    return BSP_OK;
}
UINT32 BspLnaMuxPrint(UINT32 chn)
{
    UINT32 genType = 0;
    UINT32 tddSel = 0;
    UINT32 ret = BSP_OK;
    UINT32 ioWorkAs = 0;

    if(chn >= TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chn);
        return BSP_ERROR;
    }
      ret = BspGetWorkAsTypeByTddIoInfo(chn,LINK_INFO_LNACHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK )
    {
        dbgInfoEx("lna chn %d is not used\n",chn);
        return BSP_ERROR;
    }
    tddSel = g_paMux[chn].uiBaseCfg.uiTddOut4Sel1x;
    genType = BspGetTddTimingGenSelByTddSel(tddSel);

    INPUT_PARAM_RANGE_CHECK(genType, DPDIC_MAX_TIMING_GEN_SEL_TYPE);

    dbgInfo("%s: LnaMux Output: chn: %d tddSel%d ioWorkAs %d \n", __FUNCTION__, chn,tddSel,ioWorkAs);

    dbgInfo(">>>>>>>TX timingGel Setting\n"); /*上升沿和下降沿的选择*/
    dbgInfo("tTxTiming:         uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tTxTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcTiming:       uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcInslotTiming: uiTxFall4Sel1: %d,uiTxRise2Sel1: %d uiTxAcInslot2Sel1: %d uiTxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxRise2Sel1,
            g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxAcInslot2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tTxAcInslotTiming.uiTxAcInslotOut2Sel1);
    dbgInfo("tRxTiming:         uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tRxTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcTiming:       uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcInslotTiming: uiRxFall2Sel1: %d,uiRxRise4Sel1: %d uiRxAcInslot2Sel1: %d uiRxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxRise4Sel1,
            g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxAcInslot2Sel1,g_tddTimingGenSel[genType].paLnaTimingGen.tRxAcInslotTiming.uiRxAcInslotOut2Sel1);

    dbgInfo(">>>>>>> Alarm MUX Setting\n");
    dbgInfo("tPaLnaAlarmCfg:uiLnaAlarmEn: %d\n",g_lnaMux[chn].uiAlarmEn);

    dbgInfo(">>>>>>> LNA MUX Setting\n");
    dbgInfo("tLnaCfg: uiPaLna4Sel1x: %d, uiDtxComOrNot: %d, uiPaLnaOutSelx: %d, uiAlarmComOrNot: %d\n",
            g_lnaMux[chn].uiBaseCfg.uiTddOut4Sel1x, g_lnaMux[chn].uiBaseCfg.uiDtxComOrNot, g_lnaMux[chn].uiBaseCfg.uiTddOutSelx, g_lnaMux[chn].uiBaseCfg.uiUeOut2Sel1);
    dbgInfo("\n");
    return BSP_OK;
}

UINT32 BspAmpMuxPrint(UINT32 chn)
{
    UINT32 genType = 0;
    UINT32 tddSel = 0;
    UINT32 ret = BSP_OK;
    UINT32 ioWorkAs = 0;

    if(chn >= TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chn);
        return BSP_ERROR;
    }
      ret = BspGetWorkAsTypeByTddIoInfo(chn,LINK_INFO_AMPCHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK )
    {
        dbgInfoEx("amp chn %d is not used\n",chn);
        return BSP_ERROR;
    }

    tddSel = g_ampMux[chn].uiBaseCfg.uiTddOut4Sel1x;
    genType = BspGetTddTimingGenSelByTddSel(tddSel);

    INPUT_PARAM_RANGE_CHECK(genType, DPDIC_MAX_TIMING_GEN_SEL_TYPE);

    dbgInfo("%s: AmpMux Output: chn: %d tddSel%d ioWorkAs %d \n", __FUNCTION__, chn,tddSel,ioWorkAs);

    dbgInfo(">>>>>>>TX timingGel Setting\n"); /*上升沿和下降沿的选择*/
    dbgInfo("tTxTiming:         uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].ampTimingGen.tTxTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].ampTimingGen.tTxTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcTiming:       uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].ampTimingGen.tTxAcTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].ampTimingGen.tTxAcTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcInslotTiming: uiTxFall4Sel1: %d,uiTxRise2Sel1: %d uiTxAcInslot2Sel1: %d uiTxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].ampTimingGen.tTxAcInslotTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].ampTimingGen.tTxAcInslotTiming.uiTxRise2Sel1,
            g_tddTimingGenSel[genType].ampTimingGen.tTxAcInslotTiming.uiTxAcInslot2Sel1,g_tddTimingGenSel[genType].ampTimingGen.tTxAcInslotTiming.uiTxAcInslotOut2Sel1);
    dbgInfo("tRxTiming:         uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].ampTimingGen.tRxTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].ampTimingGen.tRxTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcTiming:       uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].ampTimingGen.tRxAcTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].ampTimingGen.tRxAcTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcInslotTiming: uiRxFall2Sel1: %d,uiRxRise4Sel1: %d uiRxAcInslot2Sel1: %d uiRxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].ampTimingGen.tRxAcInslotTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].ampTimingGen.tRxAcInslotTiming.uiRxRise4Sel1,
            g_tddTimingGenSel[genType].ampTimingGen.tRxAcInslotTiming.uiRxAcInslot2Sel1,g_tddTimingGenSel[genType].ampTimingGen.tRxAcInslotTiming.uiRxAcInslotOut2Sel1);


    dbgInfo(">>>>>>> Amp MUX Setting\n");
    dbgInfo("tPaCfg: uiPaLna4Sel1x: %d,uiDtxComOrNot: %d, uiPaLnaOutSelx: %d, uiAlarmComOrNot: %d\n",
            g_ampMux[chn].uiBaseCfg.uiTddOut4Sel1x, g_ampMux[chn].uiBaseCfg.uiDtxComOrNot, g_ampMux[chn].uiBaseCfg.uiTddOutSelx, g_ampMux[chn].uiBaseCfg.uiUeOut2Sel1);
    dbgInfo("\n");
    return BSP_OK;
}
UINT32 BspTransTxMuxPrint(UINT32 chnIdx)
{
    UINT32 genType = 0;
    UINT32 tddSel = 0;
    UINT32 ret = BSP_OK;
    UINT32 ioWorkAs = 0;

    if(chnIdx >= TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chnIdx);
        return BSP_ERROR;
    }
      ret = BspGetWorkAsTypeByTddIoInfo(chnIdx,LINK_INFO_TXCHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK )
    {
        dbgInfoEx("TXEN chn %d is not used\n",chnIdx);
        return BSP_ERROR;
    }

    tddSel = g_transTxMux[chnIdx].uiTddOut4Sel1x;  /*TX/RX/ORX肯定一套tdd下*/
    genType = BspGetTddTimingGenSelByTddSel(tddSel);
    INPUT_PARAM_RANGE_CHECK(genType, DPDIC_MAX_TIMING_GEN_SEL_TYPE);
    dbgInfo("%s: TransTxen Output:\n chn: %d tddSel%d ioWorkAs %d \n", __FUNCTION__, chnIdx,tddSel,ioWorkAs);

    dbgInfo(">>>>>>>TRANS TX/RX_EN timingGel Setting\n"); /*上升沿和下降沿的选择*/
    dbgInfo("tTxTiming:         uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcTiming:       uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcInslotTiming: uiTxFall4Sel1: %d,uiTxRise2Sel1: %d uiTxAcInslot2Sel1: %d uiTxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxRise2Sel1,
            g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxAcInslot2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxAcInslotOut2Sel1);
    dbgInfo("tRxTiming:         uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcTiming:       uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcInslotTiming: uiRxFall2Sel1: %d,uiRxRise4Sel1: %d uiRxAcInslot2Sel1: %d uiRxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxRise4Sel1,
            g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxAcInslot2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxAcInslotOut2Sel1);

    dbgInfo(">>>>>>> TxEn MUX Setting\n");
    dbgInfo("TxEnCfg: uiTddOut4Sel1x: %d,\n uiDtxComOrNot: %d,\n uiTddOutSelx: %d,\n uiUeOut2Sel1: %d\n",
            g_transTxMux[chnIdx].uiTddOut4Sel1x, g_transTxMux[chnIdx].uiDtxComOrNot,
            g_transTxMux[chnIdx].uiTddOutSelx, g_transTxMux[chnIdx].uiUeOut2Sel1);
    dbgInfo("\n");
   return BSP_OK;
}
UINT32 BspTransRxMuxPrint(UINT32 chnIdx)
{
    UINT32 genType = 0;
    UINT32 tddSel = 0;
    UINT32 ret = BSP_OK;
    UINT32 ioWorkAs = 0;

    if(chnIdx >= TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chnIdx);
        return BSP_ERROR;
    }
      ret = BspGetWorkAsTypeByTddIoInfo(chnIdx,LINK_INFO_RXCHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK )
    {
        dbgInfoEx("RXEN chn %d is not used\n",chnIdx);
        return BSP_ERROR;
    }

    tddSel = g_transRxMux[chnIdx].uiTddOut4Sel1x;  /*TX/RX/ORX肯定一套tdd下*/
    genType = BspGetTddTimingGenSelByTddSel(tddSel);
    INPUT_PARAM_RANGE_CHECK(genType, DPDIC_MAX_TIMING_GEN_SEL_TYPE);
    dbgInfo("%s: RXEN Output:\n chn: %d tddSel%d ioWorkAs %d \n", __FUNCTION__, chnIdx,tddSel,ioWorkAs);

    dbgInfo(">>>>>>>TRANS TX/RX_EN timingGel Setting\n"); /*上升沿和下降沿的选择*/
    dbgInfo("tTxTiming:         uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcTiming:       uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcInslotTiming: uiTxFall4Sel1: %d,uiTxRise2Sel1: %d uiTxAcInslot2Sel1: %d uiTxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxRise2Sel1,
            g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxAcInslot2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tTxAcInslotTiming.uiTxAcInslotOut2Sel1);
    dbgInfo("tRxTiming:         uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcTiming:       uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcInslotTiming: uiRxFall2Sel1: %d,uiRxRise4Sel1: %d uiRxAcInslot2Sel1: %d uiRxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxRise4Sel1,
            g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxAcInslot2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tTxRxEn.tRxAcInslotTiming.uiRxAcInslotOut2Sel1);

    dbgInfo(">>>>>>> RxEn MUX Setting\n");
    dbgInfo("RxEnCfg: uiTddOut4Sel1x: %d,\n uiDtxComOrNot: %d,\n uiTddOutSelx: %d,\n uiUeOut2Sel1: %d\n",
            g_transRxMux[chnIdx].uiTddOut4Sel1x, g_transRxMux[chnIdx].uiDtxComOrNot,
            g_transRxMux[chnIdx].uiTddOutSelx, g_transRxMux[chnIdx].uiUeOut2Sel1);
   dbgInfo("\n");
   return BSP_OK;
}
UINT32 BspTransOrxMuxPrint(UINT32 chnIdx)
{
    UINT32 genType = 0;
    UINT32 tddSel = 0;
    UINT32 ret = BSP_OK;
    UINT32 ioWorkAs = 0;

    if(chnIdx >= TDD_IO_PIN_NUM_COMMON_4)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chnIdx);
        return BSP_ERROR;
    }
      ret = BspGetWorkAsTypeByTddIoInfo(chnIdx,LINK_INFO_FBCHN_TDDIO,&ioWorkAs);
    if(ret != BSP_OK )
    {
        dbgInfoEx("ORXEN chn %d is not used\n",chnIdx);
        return BSP_ERROR;
    }

    tddSel = g_transOrxMux[chnIdx].uiTddOut4Sel1x;  /*TX/RX/ORX肯定一套tdd下*/
    genType = BspGetTddTimingGenSelByTddSel(tddSel);
    INPUT_PARAM_RANGE_CHECK(genType, DPDIC_MAX_TIMING_GEN_SEL_TYPE);
    dbgInfo("%s: ORXEN Output:\n chn: %d tddSel%d ioWorkAs %d \n", __FUNCTION__, chnIdx,tddSel,ioWorkAs);

    dbgInfo(">>>>>>>TRANS ORX_EN timingGel Setting\n"); /*上升沿和下降沿的选择*/
    dbgInfo("tTxTiming:         uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcTiming:       uiTxFall4Sel1: %d,uiTxRise2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxAcTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxAcTiming.uiTxRise2Sel1);
    dbgInfo("tTxAcInslotTiming: uiTxFall4Sel1: %d,uiTxRise2Sel1: %d uiTxAcInslot2Sel1: %d uiTxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxAcInslotTiming.uiTxFall4Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxAcInslotTiming.uiTxRise2Sel1,
            g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxAcInslotTiming.uiTxAcInslot2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tTxAcInslotTiming.uiTxAcInslotOut2Sel1);
    dbgInfo("tRxTiming:         uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcTiming:       uiRxFall2Sel1: %d,uiRxRise4Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxAcTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxAcTiming.uiRxRise4Sel1);
    dbgInfo("tRxAcInslotTiming: uiRxFall2Sel1: %d,uiRxRise4Sel1: %d uiRxAcInslot2Sel1: %d uiRxAcInslotOut2Sel1: %d\n",g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxAcInslotTiming.uiRxFall2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxAcInslotTiming.uiRxRise4Sel1,
            g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxAcInslotTiming.uiRxAcInslot2Sel1,g_tddTimingGenSel[genType].trxTimingGen.tOrxEn.tRxAcInslotTiming.uiRxAcInslotOut2Sel1);


    dbgInfo(">>>>>>> OrxEn MUX Setting\n");
    dbgInfo("OrxEnAcCfg: uiTddOut4Sel1x: %d,\n uiDtxComOrNot: %d uiTddOutSelx : %d  uiUeOut2Sel1 : %d uiRxEn4Sel1 : %d\n\n\n",
            g_transOrxMux[chnIdx].uiTddOut4Sel1x, g_transOrxMux[chnIdx].uiDtxComOrNot, g_transOrxMux[chnIdx].uiTddOutSelx, g_transOrxMux[chnIdx].uiUeOut2Sel1, g_transOrxMux[chnIdx].uiRxEn4Sel1);
    dbgInfo("\n");
   return BSP_OK;
}
UINT32 BspTrxAcEnMuxPrint(UINT32 chn)
{
    if(chn >= TDD_IO_PIN_TRX_EN_AC_NUM_2)
    {
        dbgErr("%s: input chn %d out of range\n", __FUNCTION__, chn);
        return BSP_ERROR;
    }
    dbgInfo("%s: TrxAcEnMux Output:\n chn: %d\n", __FUNCTION__, chn);

    dbgInfo(">>>>>>> TxAcEn MUX Setting\n");
    dbgInfo("TxEnAcCfg: uiTrxEnAc4Sel1x: %d,\n uiTrxEnAcOutSelx: %d\n",
        g_trxAcEnMux[chn].tTxEnAcCfg.uiEnAc4Sel1, g_trxAcEnMux[chn].tTxEnAcCfg.uiTddOutSelx);

    dbgInfo(">>>>>>> RxAcEn MUX Setting\n");
    dbgInfo("RxEnAcCfg: uiTrxEnAc4Sel1x: %d,\n uiTrxEnAcOutSelx: %d\n\n\n",
        g_trxAcEnMux[chn].tRxEnAcCfg.uiEnAc4Sel1, g_trxAcEnMux[chn].tRxEnAcCfg.uiTddOutSelx);
    dbgInfo("\n");
   return BSP_OK;
}

UINT32 BspAcCtrlParaPrint(UINT32 tddSel, UINT32 acType)  /*每个管脚参数一样,AC控制不需要基础时序参数，只需要参数13 14 15给TRX_AC_EN模块使用以产生*x_acen_timing信号,且9个tdd_ac_control_timing模块参数一致*/
{
    UINT32 modeMap = BSP_OK;
    UINT32 loop = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range (maxValue is 10).\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }
    modeMap = FromAcTypeToModeMapSel(acType);
    if(modeMap == BSP_ERROR)
    {
        return BSP_ERROR;
    }
    dbgInfo(">>>>>>>%s: AcCtrlPara Output: tddSel: %d, tddMode: %d\n", __FUNCTION__, tddSel, BspGetTddSwModeSel(tddSel));
    dbgInfo(">>>>>>>TRX_AC_EN BasePara and ModeMap\n");
    for(loop = 0; loop < AC_CTRL_TYPE_NUM; loop++)
    {
      dbgInfo("acCtrlType %d\n",loop);
      dbgInfo("Tx:\n uiAcEnDly: %d[CLK@737.28], %f[us]\n uiAcDisEnDly1: %d[CLK@737.28], %f[us]\n uiAcDisEnDly2: %d[CLK@737.28], %f[us]\n uiAcEnTiming2Sel1: %d\n",
        g_acCtrlPara[tddSel][loop].tTxACEnPara.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_acCtrlPara[tddSel][loop].tTxACEnPara.uiAcEnDly),
        g_acCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_acCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly1),
        g_acCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_acCtrlPara[tddSel][loop].tTxACEnPara.uiAcDisEnDly2),
        g_acCtrlPara[tddSel][loop].tTxACEnPara.uiAcEnTiming2Sel1);

      dbgInfo("Rx:\n uiAcEnDly: %d[CLK@737.28], %f[us]\n uiAcDisEnDly1: %d[CLK@737.28], %f[us]\n uiAcDisEnDly2: %d[CLK@737.28], %f[us]\n uiAcEnTiming2Sel1: %d\n",
        g_acCtrlPara[tddSel][loop].tRxACEnPara.uiAcEnDly,UINT32_737_2_DOUBLE_US(g_acCtrlPara[tddSel][loop].tRxACEnPara.uiAcEnDly),
        g_acCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly1, UINT32_737_2_DOUBLE_US(g_acCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly1),
        g_acCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly2, UINT32_737_2_DOUBLE_US(g_acCtrlPara[tddSel][loop].tRxACEnPara.uiAcDisEnDly2),
        g_acCtrlPara[tddSel][loop].tRxACEnPara.uiAcEnTiming2Sel1);

      dbgInfo("ac_sw_tdd0 ModeMapSel: %d ModeNum: %d\n",
        g_acCtrlPara[tddSel][loop].tAcSwMap0.uiModeMapSel[modeMap], g_acCtrlPara[tddSel][loop].tAcSwMap0.uiModeNum);
      dbgInfo("ac_sw_tdd1 ModeMapSel: %d ModeNum: %d\n",
        g_acCtrlPara[tddSel][loop].tAcSwMap1.uiModeMapSel[modeMap], g_acCtrlPara[tddSel][loop].tAcSwMap1.uiModeNum);
      dbgInfo("ac_sw_tdd2 ModeMapSel: %d ModeNum: %d\n",
        g_acCtrlPara[tddSel][loop].tAcSwMap2.uiModeMapSel[modeMap], g_acCtrlPara[tddSel][loop].tAcSwMap2.uiModeNum);
      dbgInfo("\n");
    }
    return BSP_OK;
}
UINT32 BspFddAcCtrlParaPrint(UINT32 tddSel, UINT32 acType)
{
    UINT32 loop = 0;

    if(tddSel >= DPDIC_MAX_TDD_NUM)
    {
        dbgErr("%s: input tddSel %d out of range\n", __FUNCTION__, tddSel);
        return BSP_ERROR;
    }
    if(acType >= E_AC_TYPE_NUM)
    {
        dbgErr("%s: input acType %d out of range (maxValue is 10).\n", __FUNCTION__, acType);
        return BSP_ERROR;
    }
    for(loop = 0; loop < AC_CTRL_TYPE_NUM; loop++)
    {
      dbgInfo("acCtrlType %d bandNo %d, Reg [%d %d %d %d %d %d %d]\n",loop,BspGetAcBandNo(),g_acCtrlFddPara[tddSel][loop].tAcSw0.uiRegA,
        g_acCtrlFddPara[tddSel][loop].tAcSw0.uiRegB,g_acCtrlFddPara[tddSel][loop].tAcSw0.uiRegC,g_acCtrlFddPara[tddSel][loop].tAcSw0.uiBC2Sel1,
        g_acCtrlFddPara[tddSel][loop].tAcSw0.uiRegD,g_acCtrlFddPara[tddSel][loop].tAcSw0.uiRegE,g_acCtrlFddPara[tddSel][loop].tAcSw0.uiDE2Sel1);
    }

    return BSP_OK;
}
UINT32 BspAcCtrlMuxPrint(UINT32 sigTypeIdx)
{
    if(sigTypeIdx >= AC_CTRL_TYPE_NUM)
    {
        dbgErr("%s: input sigTypeIdx %d out of range\n", __FUNCTION__, sigTypeIdx);
        return BSP_ERROR;
    }
    dbgInfo("%s: AcCtrl Output: sigType: %d\n", __FUNCTION__, sigTypeIdx);

    dbgInfo(">>>>>>> AcCtrl %d MUX Setting\n", (sigTypeIdx+1));
    dbgInfo("uiAcCtrl4Sel1: %d \n uiAcCtrlFdd4Sel1: %d\n uiAcCtrl2Sel1: %d\n  uiAcOut3Sel1: %d\n  uiAcCtrlOutSel: %d\n \n\n",
        g_acCtrlMux[sigTypeIdx].uiAcCtrl4Sel1, g_acCtrlMux[sigTypeIdx].uiAcCtrlFdd4Sel1, g_acCtrlMux[sigTypeIdx].uiAcCtrl2Sel1,
        g_acCtrlMux[sigTypeIdx].uiAcOut3Sel1,g_acCtrlMux[sigTypeIdx].uiAcCtrlOutSel);
    dbgInfo("\n");
   return BSP_OK;
}

/* Started by AICoder, pid:7b7c7fa13475f5e14ff60a1b90a619193dd50841 */
/* 打印TDD开关延迟参数 */
UINT32 BspTddSwDelayParaPrint(UINT32 tddSel, UINT32 acType, UINT32 exPrn)
{
    g_extTddIoPrnFlag = exPrn;
    BspPaLnaParaPrint(tddSel, acType);
    BspTransParaPrint(tddSel, acType);
    BspAmpParaPrint(tddSel, acType);
    BspAcCtrlParaPrint(tddSel, acType);

    return BSP_OK;
}
/* Ended by AICoder, pid:7b7c7fa13475f5e14ff60a1b90a619193dd50841 */

UINT32 BspTddSwMuxParaPrint(VOID)
{
    UINT32 uRet = BSP_OK;
    UINT32 chnIdx = 0;
    UINT32 sigTypeIdx = 0;

    for(chnIdx = 0; chnIdx < TDD_IO_PIN_NUM_COMMON_8; chnIdx++)
    {
        uRet |= BspPaMuxPrint(chnIdx);
        uRet |= BspLnaMuxPrint(chnIdx);
        uRet |= BspAmpMuxPrint(chnIdx);
    }
    for(chnIdx = 0; chnIdx < TDD_IO_PIN_NUM_COMMON_4; chnIdx++)
    {
        uRet |= BspTransTxMuxPrint(chnIdx);
        uRet |= BspTransRxMuxPrint(chnIdx);
        uRet |= BspTransOrxMuxPrint(chnIdx);
    }
    for(chnIdx = 0; chnIdx < TDD_IO_PIN_TRX_EN_AC_NUM_2; chnIdx++)
    {
        uRet |= BspTrxAcEnMuxPrint(chnIdx);
    }

    for(sigTypeIdx = 0; sigTypeIdx < AC_CTRL_TYPE_NUM; sigTypeIdx++)
    {
        uRet |= BspAcCtrlMuxPrint(sigTypeIdx);
    }

    return uRet;
}

UINT32 BspTddIoRecordInfoPrint(VOID)
{
    UINT32 cnt = 0;
    dbgInfo("%s>>>>>> callcnt = %d, curcnt = %d.\n", __FUNCTION__, g_tddIoRecordCnt, g_tddIoRecordCnt%TDDIO_RECORD_MAX_NUM);
    for(cnt = 0; cnt < TDDIO_RECORD_MAX_NUM; cnt++)
    {
        dbgInfo("%s>>>>>> cnt = %d, acType = %d, tddSel = %d.\n", __FUNCTION__, cnt, g_tddIoRecordInfo[cnt].acType, g_tddIoRecordInfo[cnt].tddIdx);
    }
    dbgInfo("%s>>>>>> ErrRcdRadioCnt = %d, g_tddIoErrRcdGpNumCnt = %d, g_tddIoErrRcdAcTypeCnt = %d.\n", __FUNCTION__, g_tddIoErrRcdRadioCnt, BspGetTddIoErrRcdGpNum(),g_tddIoErrRcdAcTypeCnt);
    return BSP_OK;
}

UINT32 BspGetTddIoRecordInfo(VOID)
{
    UINT32 tddIoCnt = 0;
    UINT32 tddIoActype = 0;

    tddIoCnt = (g_tddIoRecordCnt % TDDIO_RECORD_MAX_NUM) - 1;
    if (tddIoCnt >= (UINT32)1)
    {
        tddIoActype = g_tddIoRecordInfo[tddIoCnt].acType;
    }
    return tddIoActype;
}


char tddIoType[LINK_INFO_TYPE_NUM_TDDIO+1][IOCTRL_EXPRNADD_LEN]= {
  "LINK_INFO_RFCHN_TDDIO",
  "LINK_INFO_LINKTYPE_TDDIO",
  "LINK_INFO_TXCHN_TDDIO",
  "LINK_INFO_RXCHN_TDDIO",
  "LINK_INFO_FBCHN_TDDIO",
  "LINK_INFO_PACHN_TDDIO",
  "LINK_INFO_LNACHN_TDDIO",
  "LINK_INFO_LNASWCHN_TDDIO",
  "LINK_INFO_TXACCHN_TDDIO",
  "LINK_INFO_RXACCHN_TDDIO",
  "LINK_INFO_AMPCHN_TDDIO",
  "LINK_INFO_TYPE_NUM_TDDIO",
  };
char tddIoWorkAs[TDDIO_MAX_FUNC_NUM+1][IOCTRL_EXPRNADD_LEN]=
{
  "TDDIO_WORKAS_NOONE",
  "TDDIO_WORKAS_SELF",
  "TDDIO_WORKAS_PA"   ,
  "TDDIO_WORKAS_AMP"  ,
  "TDDIO_WORKAS_TXEN" ,
  "TDDIO_MAX_FUNC_NUM",
};
char tddIoPrintInfo[][IOCTRL_EXPRNADD_LEN]=
{
    "BspPaLnaParaPrint tddSel, acType",
    "BspTransParaPrint tddSel, acType",
    "BspAmpParaPrint tddSel, acType",
    "BspAcCtrlParaPrint tddSel, acType",
    "BspFddAcCtrlParaPrint tddSel, acType", /* 11-tdd 8-dl 9-ul*/
    "BspPaMuxPrint chnIdx",
    "BspLnaMuxPrint chnIdx",
    "BspAmpMuxPrint chnIdx",
    "BspTransTxMuxPrint chnIdx",
    "BspTransRxMuxPrint chnIdx",
    "BspTransOrxMuxPrint chnIdx",
    "BspTrxAcEnMuxPrint chnIdx",
    "BspAcCtrlMuxPrint sigTypeIdx",
    "ioclcparaexprnadd",
    "prnpaiomap",
    "prnlnaiomap",
    "prnampiomap",
    "prntxeniomap",
    "prnrxeniomap",
    "BspGetIoBasePara radio",          /*gp ue提前量参数*/
    "BspGetIoAcBasePara radio, acType",/*AC起止位置*/
    "BspUpdateTddIoVariablePara tddSel, acType",  /*手动更新时序*/
    "fpgapaon",
    "fpgapaonfdd",
    "fpgapaoff",
    "fpgalnaon",
    "fpgalnaonfdd",
    "fpgalnaoff",
    "fpgatxampon",
    "fpgatxamponfdd",
    "fpgatxampoff",
    "fpgarxampon",
    "fpgarxamponfdd",
    "fpgarxampoff",
    "fpgaiosta",
    "prnswbit chan",
    "boardioexprnadd"
};

void tddiohelp()
{
    UINT32 loop = 0;
    for(loop = 0; loop < NELEMENTS(tddIoPrintInfo);loop++)
    {
        dbgInfo("%s\n",tddIoPrintInfo[loop]);
    }
}
void prnpaiomap()
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;
    UINT32 ioTpye = 0;
    UINT32 ioWorkAs = 0;
    for(loop = 0; loop < BspGetTxChannel();loop++)
    {
        ret = BspGetPaIoInfoByRfChn(loop,LINK_TYPE_TX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            ioTpye = (iochan>>8)&0xf;
            (void)BspGetWorkAsTypeByTddIoInfo(ioIdx,ioTpye,&ioWorkAs);
            dbgInfo("rchan %d, tddIoType %s, ioIdx %d, ioWorkAs %s, iochan 0x%x\n",loop,tddIoType[ioTpye],ioIdx,tddIoWorkAs[ioWorkAs],iochan);
        }
    }
}
void prnampiomap()
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;
    UINT32 ioTpye = 0;
    UINT32 ioWorkAs = 0;
    for(loop = 0; loop < BspGetTxChannel();loop++)
    {
        ret = BspGetAmpIoInfoByRfChn(loop,LINK_TYPE_TX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            ioTpye = (iochan>>8)&0xf;
            (void)BspGetWorkAsTypeByTddIoInfo(ioIdx,ioTpye,&ioWorkAs);
            dbgInfo("rchan %d, tddIoType %s, ioIdx %d, ioWorkAs %s, iochan 0x%x\n",loop,tddIoType[ioTpye],ioIdx,tddIoWorkAs[ioWorkAs],iochan);
        }
    }
}

void prntxeniomap()
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;
    UINT32 ioTpye = 0;
    UINT32 ioWorkAs = 0;
    for(loop = 0; loop < BspGetTxChannel();loop++)
    {
        ret = BspGetTxEnIoInfoByRfChn(loop,LINK_TYPE_TX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            ioTpye = (iochan>>8)&0xf;
            (void)BspGetWorkAsTypeByTddIoInfo(ioIdx,ioTpye,&ioWorkAs);
            dbgInfo("rchan %d, tddIoType %s, ioIdx %d, ioWorkAs %s, iochan 0x%x\n",loop,tddIoType[ioTpye],ioIdx,tddIoWorkAs[ioWorkAs],iochan);
        }
    }
}

void prnrxeniomap()
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;
    UINT32 ioTpye = 0;
    UINT32 ioWorkAs = 0;
    for(loop = 0; loop < BspGetTxChannel();loop++)
    {
        ret = BspGetRxEnIoInfoByRfChn(loop,LINK_TYPE_RX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            ioTpye = (iochan>>8)&0xf;
            (void)BspGetWorkAsTypeByTddIoInfo(ioIdx,ioTpye,&ioWorkAs);
            dbgInfo("rchan %d, tddIoType %s, ioIdx %d, ioWorkAs %s, iochan 0x%x\n",loop,tddIoType[ioTpye],ioIdx,tddIoWorkAs[ioWorkAs],iochan);
        }
    }
}
void prnlnaiomap()
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;
    UINT32 ioTpye = 0;
    UINT32 ioWorkAs = 0;
    for(loop = 0; loop < BspGetTxChannel();loop++)
    {
        ret = BspGetLnaIoInfoByRfChn(loop,LINK_TYPE_RX,&iochan);
        if(ret == BSP_OK)
        {
            ioIdx = iochan&0xf;
            ioTpye = (iochan>>8)&0xf;
            (void)BspGetWorkAsTypeByTddIoInfo(ioIdx,ioTpye,&ioWorkAs);
            dbgInfo("rchan %d, tddIoType %s, ioIdx %d, ioWorkAs %s, iochan 0x%x\n",loop,tddIoType[ioTpye],ioIdx,tddIoWorkAs[ioWorkAs],iochan);
        }
    }
}

/*PA ue使能*/
UINT32 BspSetPaUeEn(UINT32 chn, UINT32 sw)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetPaIoInfoByRfChn(chn,TX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get pa iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetPaUeEn(ioIdx, sw);

    return retVal;
}

/*LNA ue使能*/
UINT32 BspSetLnaUeEn(UINT32 chn, UINT32 sw)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetLnaIoInfoByRfChn(chn,RX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get lna iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetLnaUeEn(ioIdx, sw);

    return retVal;
}

/* Started by AICoder, pid:c54e1h65c5p96fa144e30bb0b0391a50c9b6df57 */
/*Txen ue使能*/
UINT32 BspSetTxenUeEn(UINT32 chn, UINT32 sw)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetTxEnIoInfoByRfChn(chn,TX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get txen iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetTxenUeEn(ioIdx, sw);

    return retVal;
}

/*Rxen ue使能*/
UINT32 BspSetRxenUeEn(UINT32 chn, UINT32 sw)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetRxEnIoInfoByRfChn(chn,RX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get rxen iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetRxenUeEn(ioIdx, sw);

    return retVal;
}

/*Amp ue使能*/
UINT32 BspSetAmpUeEn(UINT32 chn, UINT32 sw)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetAmpIoInfoByRfChn(chn,TX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get amp iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetAmpUeEn(ioIdx, sw);

    return retVal;
}
/* Ended by AICoder, pid:c54e1h65c5p96fa144e30bb0b0391a50c9b6df57 */

/*PA BITMAP设置  先要打开UE使能才生效*/
UINT32 BspSetPaBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetPaIoInfoByRfChn(chn,TX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get pa iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetPaBitmap(ioIdx, bitmapLoop, bitmapVal);

    return retVal;
}

/*LNA BITMAP设置  先要打开UE使能才生效*/
UINT32 BspSetLnaBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetLnaIoInfoByRfChn(chn,RX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get lna iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetLnaBitmap(ioIdx, bitmapLoop, bitmapVal);

    return retVal;
}


/*TXEN BITMAP设置  先要打开UE使能才生效*/
UINT32 BspSetTxEnBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetTxEnIoInfoByRfChn(chn,TX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get lna iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetAmpBitmap(ioIdx, bitmapLoop, bitmapVal);    /*9614 8T机型txen使用amp控制*/

    return retVal;
}

/*AMP BITMAP设置  先要打开UE使能才生效*/
UINT32 BspSetAmpBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetAmpIoInfoByRfChn(chn,TX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get lna iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetAmpBitmap(ioIdx, bitmapLoop, bitmapVal);

    return retVal;
}

/*RxEn BITMAP设置  先要打开UE使能才生效*/
UINT32 BspSetRxEnBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal)
{
    UINT32 iochan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 ioIdx  = 0;

    retVal = BspGetRxEnIoInfoByRfChn(chn,RX,&iochan);
    if(BSP_OK != retVal)
    {
        dbgErr("chn %d get lna iochan failed\n", chn);
        return retVal;
    }
    ioIdx = iochan&0xf;
    retVal = BspHalAdaptSetRxenBitmap(ioIdx, bitmapLoop, bitmapVal);

    return retVal;
}

/*typedef struct
    {
        UINT32 uiEnable; * acinslot信号使能标志位  1
        UINT32 uiFraNum; * acinslot信号产生无线帧号  0
        UINT32 uiFrDly;  * 产生上行acinslot所需帧头延时 可变
        UINT32 uiWidth;  * 脉冲宽度 可变
        UINT32 uiTimes;  * 脉冲次数 255
        UINT32 uiFrCut;  * 帧号截位 0：0比特截位  1：1比特截取  2：2比特截取  3：3比特截取  3
        UINT32 ui5msPrd; * 5ms分频配置  7372800
    } T_AC_INSLOT_BASE_PARA;*/
/*工装dtx测试需求 可变脉冲宽度和时延*/
UINT32 BspSetTestDtxPacCfg(UINT32 chn, UINT32 sw, UINT32 frDly, UINT32 width)
{
    UINT32 retVal = BSP_OK;
    T_AC_INSLOT_PARA tmpPara = {0};
    UINT32 tddIndex = 0;
    UINT32 iochan = 0;
    UINT32 ioIdx  = 0;

    BspGetPaIoInfoByRfChn(chn,TX,&iochan);
    ioIdx = iochan&0xf;
    BspGetRealTddNoByTddIoInfo(ioIdx,LINK_INFO_PACHN_TDDIO, &tddIndex);

    retVal = BspSetDtxSwitch(chn, 0);              /*前提DTX不合入 没有高层流程默认就应该是关*/
    retVal |= BspSetDtxEnFlag(chn, 0);
    retVal |= BspHalAdaptSetDtxIoLteEn(chn,1-sw);   /*前级DTX控制成0  配频的时候默认是开启--中频资源分析的时候会配置dtx路由，会配置此接口DlPreSetDtxIoLteEn  0xcb905ccc*/
    retVal |= BspSetDtxPaEn(chn, sw);   /*pa的DTX合入*/
    if(SWITCH_ON == sw)                             /*4、前级的pa信号置1：通过modemap控制pa输出为1*/
    {
        tmpPara.tDlPara.uiEnable = SWITCH_ON;
        tmpPara.tDlPara.uiFraNum = 0;
        tmpPara.tDlPara.uiFrDly = frDly;
        tmpPara.tDlPara.uiWidth = width;
        tmpPara.tDlPara.uiTimes = 0xff;
        tmpPara.tDlPara.uiFrCut = 3;
        tmpPara.tDlPara.ui5msPrd = 7372800;
        BspHalAdaptSetLinkAcInSlotPara(&tmpPara,tddIndex);
    }
    else
    {
        tmpPara.tDlPara.uiEnable = SWITCH_OFF;
        BspHalAdaptSetLinkAcInSlotPara(&tmpPara,tddIndex);
    }

    return retVal;
}

/* Started by AICoder, pid:kb165ie496c252a144d109ef504dd64cb26288d5 */
UINT32 BspRecoverTddIoUeOut2Sel1(void)
{
    UINT32 chan = 0;
    UINT32 retVal = BSP_OK;

    for(chan = 0; chan < TDD_IO_PIN_NUM_COMMON_8; chan ++)
    {
        retVal |= BspSetTddIoUeOut2Sel1(chan, LINK_INFO_TXCHN_TDDIO, IO_DISABLE);
        retVal |= BspSetTddIoUeOut2Sel1(chan, LINK_INFO_RXCHN_TDDIO, IO_DISABLE);
        retVal |= BspSetTddIoUeOut2Sel1(chan, LINK_INFO_PACHN_TDDIO, IO_DISABLE);
        retVal |= BspSetTddIoUeOut2Sel1(chan, LINK_INFO_LNACHN_TDDIO, IO_DISABLE);
        retVal |= BspSetTddIoUeOut2Sel1(chan, LINK_INFO_AMPCHN_TDDIO, IO_DISABLE);
    }
    BspLog(LOG_LEVEL_0,"%s done!\n", __FUNCTION__);

    return retVal;
}
/* Ended by AICoder, pid:kb165ie496c252a144d109ef504dd64cb26288d5 */

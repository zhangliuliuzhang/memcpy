/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_c_eeprom.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "boardid.h"
#include "devdrv_eeprom.h"
#include "pa_ic4_2_eeprom.h"

/* 返回值仅用于表示成功或失败，实际读取长度用*pLength返回，此变量同时还用于指定需要读取的最大长度 */
UINT32 BspGetPaEepromData(UINT32 chan, CHAR* pCh, UINT32* pLength)
{
    UINT32 ret = BSP_OK;
    char   bufName[PA_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32  lSnpRet = 0;

    INPUT_POINTER_CHECK(pCh);
    INPUT_POINTER_CHECK(pLength);
    
    lSnpRet = snprintf_s(bufName,sizeof(bufName),"EepromPa%d",chan);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    ret = BspGetEepromInfo(devid, 0, pCh, *pLength);

    *pLength = ret; /* 返回值就是实际读取到的长度，用指针返回 */

    return (ret)?BSP_OK:BSP_ERROR;
}

UINT32 BspSetPaEepromData(UINT32 chan, CHAR* pCh, UINT32 Length)
{
    char   bufName[PA_PARA_LENGTH] ={0};
    UINT32 devid = 0;
    INT32  lSnpRet = 0;

    INPUT_POINTER_CHECK(pCh);
    
    lSnpRet = snprintf_s(bufName,sizeof(bufName),"EepromPa%d",chan);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);

    return BspSetEepromInfo(devid, 0, pCh, Length);
}



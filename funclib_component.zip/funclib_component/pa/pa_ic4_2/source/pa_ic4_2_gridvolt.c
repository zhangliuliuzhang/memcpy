/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_c_gridvolt.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "boardid.h"
#include "exprn.h"
#include "rftable.h"
#include "rftable_padacset.h"
#include "chnmap_a.h"
#include "devdrv_dac.h"
#include "pa_ic4_2_gridvolt.h"
#include "freqcfgapi.h"
#include "rftable_padacset.h"
#include "funccommon_log.h"

#ifndef MAX_RFCHAN_NUM
#define MAX_RFCHAN_NUM 32
#endif

#define VIBAS_TYPE_NUM             (8)

UINT32 paVibasUpdate[MAX_RFCHAN_NUM] = {1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1};
UINT32 g_pachnRfchnMismatchFlag = 0; /* 多片机型 pa通道与rf通道并非一一对应，静态调压中两次pa rf通道对应带来报错*/


T_PaChipDacCfgInfo s_paChanChipDacMore = {0};
static INT32 s_paGirdVoltTempComp[BSP_MAX_TX_CHAN][VIBAS_TYPE_NUM] = {0};

typedef  UINT32 (*BSP_SET_PAVIBAS_CALLBACK_FUNCPTR)(UINT32 index);

BSP_SET_PAVIBAS_CALLBACK_FUNCPTR pSetPaVibasCallBack = NULL;

/* Started by AICoder, pid:4719ckabb7id14d14cd40b77c093c11b7ba36ba3 */
UINT32 BspSetPachnRfchnMismatchFlag(UINT32 flag)
{
    UINT32 retVal = BSP_OK;

    g_pachnRfchnMismatchFlag = flag;

    return retVal;
}

UINT32 BspGetPachnRfchnMismatchFlag(VOID)
{
    return g_pachnRfchnMismatchFlag;
}
/* Ended by AICoder, pid:4719ckabb7id14d14cd40b77c093c11b7ba36ba3 */

UINT32 BspPaSetVibasCallBack(UINT32 (*pFuncCallback)(UINT32 index))
{
    pSetPaVibasCallBack = pFuncCallback;

    return BSP_OK;
}

/*PaChan 与 ChipChan 关系，暂时保留*/
T_PaChipDacCfgInfo* BspGetPaChanChipDacCfg(VOID)
{ 
	return &s_paChanChipDacMore;    
}

UINT32 BspSetPaChanChipDacCfg(T_PaChipDacChanInfo* pPaPara,UINT32 cfgNum)
{ 
    s_paChanChipDacMore.pPara = pPaPara;
    s_paChanChipDacMore.num   = cfgNum;
	return BSP_OK;    
}

pQorvoFunc pGetQorvoAnaCall = NULL;

UINT32 BspRegisterQorvoAnaCall(pQorvoFunc pGetQorvoCall)
{
   pGetQorvoAnaCall = pGetQorvoCall;
   return BSP_OK;
}

pGetGridVoltAdjustFunc pGetGridVoltAdjustCall = NULL;

UINT32 BspRegisterGetGridAdjustFunc(pGetGridVoltAdjustFunc pGetGridVolt)
{
    if(pGetGridVolt != NULL)
    {
        pGetGridVoltAdjustCall = pGetGridVolt;
    }
    return BSP_OK;
}

UINT32 BspDacChanToPaChan(UINT32 chip, UINT32 dac, UINT32* pa)
{
    T_PaChipDacCfgInfo  *pPaCfg  = NULL;
    T_PaChipDacChanInfo      *pPaInfo = NULL;
    UINT32 idx                = 0;
    INPUT_POINTER_CHECK(pa);
    
    pPaCfg = BspGetPaChanChipDacCfg();
    if(NULL != pPaCfg->pPara)
    {
        for(idx = 0; idx < pPaCfg->num; idx++)
        {
            pPaInfo = &(pPaCfg->pPara[idx]);
            
            dbgInfoEx("num'%d,idx'%d,chip'%d,dac'%d\n",pPaCfg->num,idx,
                pPaInfo->dacInfo[E_PA_DAC_CHIP_INDEX],pPaInfo->dacInfo[E_PA_DAC_CHIP_INNER_CHAN]);
            if(chip == pPaInfo->dacInfo[E_PA_DAC_CHIP_INDEX] && dac  == pPaInfo->dacInfo[E_PA_DAC_CHIP_INNER_CHAN])
            {
                *pa = pPaInfo->dacInfo[E_PA_DAC_RF_CHAN];
                break;
            }
        }
        if(idx >= pPaCfg->num)
        {
            return BSP_ERROR;
        }
        return BSP_OK;
    }
    return BSP_ERROR;
}

UINT32 dacChanToPaChan(UINT32 chip, UINT32 dac)
{
    UINT32 pa  = 0;
    UINT32 ret = 0;
    ret = BspDacChanToPaChan(chip,dac,&pa);
    dbgInfo("\nchip'%d,dac'%d,GetPaChan'%d\n",chip,dac,pa);
    return ret;
}
/*PaChan 与 ChipChan 关系*/

UINT32 BspGetPaGridVoltDevId(UINT32 ulPaChnl,UINT32 ulVbiasType)
{
    static UINT32 PaProType = 0xff;
    char  ucNameBuf[PA_PARA_LENGTH] = {0};
    UINT32 ulDevId = 0xFFFFFFFF;
    INT32  SnRet;

    if((0 == PaProType) || (0xff == PaProType))
    {
        SnRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", ulPaChnl);
        SNPRINTF_S_CHECK(SnRet,sizeof(ucNameBuf));
        ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
        ulDevId = BspDevIdGetByDevIdName(ucNameBuf);
        if (BSP_ERROR != ulDevId)
        {
            PaProType = 0;
            return ulDevId;
        }
        else
        {
            BspLog(LOG_LEVEL_0, "[%s] PaType:%u, PaChnl:%u, Vbias:%u, Name:%s\n",
                       __FUNCTION__, PaProType, ulPaChnl, ulVbiasType, ucNameBuf);
            PaProType = 0xff;  //如返回错误，则恢复初始值
        }
    }
    if((1 == PaProType) || (0xff == PaProType))
    {
        SnRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d_%d", ulPaChnl,ulVbiasType);
        SNPRINTF_S_CHECK(SnRet,sizeof(ucNameBuf));
        ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
        ulDevId = BspDevIdGetByDevIdName(ucNameBuf);
        if (BSP_ERROR != ulDevId)
        {
            PaProType = 1;
            return ulDevId;
        }
        else
        {
            BspLog(LOG_LEVEL_0, "[%s] PaType:%u, PaChnl:%u, Vbias:%u, Name:%s\n",
                       __FUNCTION__, PaProType, ulPaChnl, ulVbiasType, ucNameBuf);
            PaProType = 0xff; //如返回错误，则恢复初始值
            return BSP_ERROR;
        }
    }
	return BSP_ERROR;
}
UINT32 BspGetPaGridVolt(UINT32 ulRfChnl, UINT32 ulSubChnl, INT32 *piVolt)
{
    INT32  iGridVolt = 0;
    UINT32 ulDevId = 0;
    UINT32 ulPaChnl = 0;
    UINT32 ulFuncRet = BSP_OK;
    char   ucNameBuf[PA_PARA_LENGTH] = {0};
    INT32  lSnpRet = 0;

    ulFuncRet = BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulFuncRet);
        return BSP_ERROR;
    }
    lSnpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", ulPaChnl);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d DevName'%s ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ucNameBuf, ulDevId);
        return BSP_ERROR;
    }

    ulFuncRet = BspGetDacGridInfo(ulDevId, ulSubChnl, &iGridVolt);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d DevId'%d GetDacGrid Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulDevId, ulFuncRet);
    }

    if (NULL != piVolt)
    {
        *piVolt = iGridVolt;
        dbgInfoEx("%s>>TxRfChnl'%2d PaChnl'%2d SubChnl'%2d DevId'%d: %s = %d mv\n", __FUNCTION__,
                  ulRfChnl, ulPaChnl, ulSubChnl, ulDevId, ucNameBuf, iGridVolt);
    }
    else
    {
        ulFuncRet = BSP_ERROR;
        dbgInfo("%s>TxRfChnl'%2d PaChnl'%2d SubChnl'%2d DevId'%d: %s = %d mv\n", __FUNCTION__,
                ulRfChnl, ulPaChnl, ulSubChnl, ulDevId, ucNameBuf, iGridVolt);
    }

    return ulFuncRet;
}
UINT32 BspGetPaGridVoltFix(UINT32 ulRfChnl, UINT32 ulVbiasType,UINT32 ulDacPath, INT32 *piVolt)
{
    INT32  iGridVolt = 0;
    UINT32 ulDevId = 0;
    UINT32 ulPaChnl = 0;
    UINT32 ulFuncRet = BSP_OK;

    dbgInfoEx("%s, ulRfChnl:%d,ulVbiasType:%d, ulDacPath:%d\n", __FUNCTION__, ulRfChnl, ulVbiasType, ulDacPath);

    ulFuncRet = BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulFuncRet);
        return BSP_ERROR;
    }
#if 0    
    snprintf(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", ulPaChnl);
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d DevName'%s ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ucNameBuf, ulDevId);
        return BSP_ERROR;
    }
#endif
    ulDevId = BspGetPaGridVoltDevId(ulPaChnl,ulVbiasType);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d PaChnl'%d VbiasType'%d ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulPaChnl, ulVbiasType, ulDevId);
        return BSP_ERROR;
    }

    ulFuncRet = BspGetDacGridInfo(ulDevId, ulDacPath, &iGridVolt);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d DevId'%d GetDacGrid Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulDevId, ulFuncRet);
    }

    if (NULL != piVolt)
    {
        *piVolt = iGridVolt;
        dbgInfoEx("%s>>TxRfChnl'%2d PaChnl'%2d VbiasType'%2d DacPath'%2d DevId'%d: %d mv\n", __FUNCTION__,
                  ulRfChnl, ulPaChnl, ulVbiasType,ulDacPath, ulDevId, iGridVolt);
    }
    else
    {
        ulFuncRet = BSP_ERROR;
        RedirPrintf("%s>TxRfChnl'%2d PaChnl'%2d VbiasType'%2d DacPath'%2d DevId'%d: %d mv\n", __FUNCTION__,
                ulRfChnl, ulPaChnl, ulVbiasType, ulDacPath, ulDevId, iGridVolt);
    }

    return ulFuncRet;
}

UINT32 BspSetPaGridVolt(UINT32 ulRfChnl, UINT32 ulSubChnl, INT32 iVolt)
{
    UINT32 ulDevId = 0;
    UINT32 ulPaChnl = 0;
    UINT32 ulFuncRet = BSP_OK;
    char   ucNameBuf[PA_PARA_LENGTH] = {0};
    INT32  lSnpRet = 0;

    ulFuncRet = BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulFuncRet);
        return BSP_ERROR;
    }
    lSnpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", ulPaChnl);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d DevName'%s ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ucNameBuf, ulDevId);
        return BSP_ERROR;
    }

    ulFuncRet = BspSetDacGridInfo(ulDevId, ulSubChnl, iVolt);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d DevId'%d SetDacGrid Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulDevId, ulFuncRet);
        return ulFuncRet;
    }

    dbgInfoEx("%s>>TxRfChnl'%2d PaChnl'%2d SubChnl'%2d DevId'%d: %s = %d mv\n", __FUNCTION__,
              ulRfChnl, ulPaChnl, ulSubChnl, ulDevId, ucNameBuf, iVolt);
    return ulFuncRet;
}
UINT32 BspSetPaGridVoltFix(UINT32 ulRfChnl, UINT32 ulVbiasType,UINT32 ulDacPath, INT32 iVolt)
{
    UINT32 ulDevId = 0;
    UINT32 ulPaChnl = 0;
    UINT32 ulFuncRet = BSP_OK;
    //UINT8  ucNameBuf[PA_PARA_LENGTH] = {0};

    ulFuncRet = BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulFuncRet);
        return BSP_ERROR;
    }
    ulDevId = BspGetPaGridVoltDevId(ulPaChnl,ulVbiasType);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d PaChnl'%d VbiasType'%d ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulPaChnl, ulVbiasType, ulDevId);
        return BSP_ERROR;
    }

    ulFuncRet = BspSetDacGridInfo(ulDevId, ulDacPath, iVolt);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d DevId'%d SetDacGrid Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulDevId, ulFuncRet);
        return ulFuncRet;
    }

    dbgInfoEx("%s>>TxRfChnl'%2d PaChnl'%2d VbiasType'%2d DacPath'%2d DevId'%d: %d mv\n", __FUNCTION__,
              ulRfChnl, ulPaChnl, ulVbiasType, ulDacPath, ulDevId, iVolt);
    return ulFuncRet;
}

UINT32 BspClrPaGridVolt(UINT32 ulRfChnl, UINT32 ulSubChnl)
{
    UINT32 ulDevId = 0;
    UINT32 ulPaChnl = 0;
    UINT32 ulFuncRet = BSP_OK;
    INT32  snpRet=0;
    char   ucNameBuf[PA_PARA_LENGTH] = {0};

    ulFuncRet = BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulFuncRet);
        return BSP_ERROR;
    }

    snpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", ulPaChnl);
    SNPRINTF_S_CHECK(snpRet,sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d DevName'%s ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ucNameBuf, ulDevId);
        return BSP_ERROR;
    }

    ulFuncRet = BspClrDacGridInfo(ulDevId, ulSubChnl);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d DevId'%d SetDacGrid Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulDevId, ulFuncRet);
        return ulFuncRet;
    }

    dbgInfoEx("%s>>TxRfChnl'%2d PaChnl'%2d SubChnl'%2d DevId'%d: %s\n", __FUNCTION__,
              ulRfChnl, ulPaChnl, ulSubChnl, ulDevId, ucNameBuf);
    return ulFuncRet;
}
UINT32 BspClrPaGridVoltFix(UINT32 ulRfChnl,UINT32 ulVbiasType,UINT32 ulDacPath)
{
    UINT32 ulDevId = 0;
    UINT32 ulPaChnl = 0;
    UINT32 ulFuncRet = BSP_OK;
    //UINT8  ucNameBuf[PA_PARA_LENGTH] = {0};


    ulFuncRet = BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulFuncRet);
        return BSP_ERROR;
    }
#if 0
    snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", ulPaChnl);
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d DevName'%s ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ucNameBuf, ulDevId);
        return BSP_ERROR;
    }
#endif
    ulDevId = BspGetPaGridVoltDevId(ulPaChnl,ulVbiasType);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d PaChnl'%d VbiasType'%d ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulPaChnl, ulVbiasType, ulDevId);
        return BSP_ERROR;
    }

    ulFuncRet = BspClrDacGridInfo(ulDevId, ulDacPath);
    if (BSP_OK != ulFuncRet)
    {
        dbgErr("%s>>TxRfCh'%d DevId'%d  DacChan [%u] SetDacGrid Error! Ret= 0x%X\n",
               __FUNCTION__, ulRfChnl, ulDevId, ulDacPath, ulFuncRet);
        return ulFuncRet;
    }

    dbgInfoEx("%s>>TxRfChnl'%2d PaChnl'%2d VbiasType'%2d DacPath'%2d DevId'%d\n", __FUNCTION__,
              ulRfChnl, ulPaChnl, ulVbiasType, ulDacPath, ulDevId);
    return ulFuncRet;
}

UINT32 BspPaDacDataInit(VOID)
{
    UINT32 retVal = BSP_OK;
    UINT32 chan = 0;
    UINT32 loop = 0;
    UINT32 dacChip = 0;
    UINT32 dacChan = 0;
    UINT32 vbiasType = 0;
    INT32  defData = 0;
    T_PaDacSetCaliData *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    INPUT_POINTER_CHECK(ptData);
    INPUT_POINTER_CHECK(ptData->pCaliPath[0]);
    for (chan = 0; chan < BspGetTxChannel(); chan++)
    {
        
        ptRecord = ptData->pCaliPath[0][chan].ptRecord;
        if (ptRecord == NULL)
        {
            retVal |= BIT_SET(chan);
            dbgInfoEx("%s,error\n", __FUNCTION__);
            continue;
        }

        for (loop = 0; loop < ptData->pCaliPath[0][chan].ulRecordNum; loop++)
        {
            if (NULL != ptRecord)
            {
                dacChip = ptRecord->ulDacPhyIndex;
                dacChan = ptRecord->ulDacChanIndex;
                defData = (INT32)(ptRecord->ulGridVoltDataDef);
                vbiasType  = ptRecord->ulGridVoltType;
                BspSetPaGridVoltFix(chan, vbiasType,dacChan, defData);
                dbgInfo("Recd'%d,paChan'%d,vbiasType'%d,DacChan'%d,DefVoltData'%d DacChip'%d \n",
                           ptData->pCaliPath[0][chan].ulRecordNum,chan,vbiasType,dacChan,defData,dacChip);
                BspLog(LOG_ERR,LOG_LEVEL_0, "[%s] Recd'%d,paChan'%d,vbiasType'%d,DacChan'%d,DefVoltData'%d DacChip'%d \n",
            __FUNCTION__, ptData->pCaliPath[0][chan].ulRecordNum,chan,vbiasType,dacChan,defData,dacChip);
            }
            ptRecord++;
        }
    }

    return retVal;
}

///* 根据 离线文件 PaEnergySavingAdj.txt 温度分段和折算系数补偿栅压。基准电压、温度和 DAC内部映射关系 依然使用PaDacSet.txt */
/* 根据 离线文件 PaEnergySavingAdj.txt 温度分段和折算系数补偿栅压,需要知道以下信息 */
#define PA_TEMP_POINT_MAX_NUM 10
#define PA_VIBAS_TYPE_MAX   6
UINT32 g_parLevel[TBL_MAX_TX_CHAN_NUM] = {0,};
UINT32 g_dataIndex[TBL_MAX_TX_CHAN_NUM] = {0,};
UINT32 g_PavbiasTypeErr = 0;



UINT32 BspSetPaVibasNewIndex(UINT32 chanNo, UINT32 parLevel, UINT32 dataIndex)
{
    TBL_CHAN_VALID_CHECK(chanNo);
    g_parLevel[chanNo] = parLevel;
    g_dataIndex[chanNo] = dataIndex;
        return BSP_OK;
}

UINT32 BspGetPaVibasNewParLevel(UINT32 chanNo, UINT32 *pparLevel, UINT32 *pdataIndex)
{
    INPUT_POINTER_CHECK(pparLevel);
    INPUT_POINTER_CHECK(pdataIndex);
    TBL_CHAN_VALID_CHECK(chanNo);
    *pparLevel = g_parLevel[chanNo];
    *pdataIndex = g_dataIndex[chanNo];
    return BSP_OK;
}


/**************************************************************************
 * 函数名称: BspSetPaVibasByEnSavAdj
 * 功能描述: 从离线表中获取获取参数并设置栅压
 * 输入参数: dacData tempOfDacData vbiasType - PaDacSet.txt 中栅压、额定温度、栅压类型
 * 输入参数: ulRfChnl - 通道号
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年10月20日     创建
 **************************************************************************/
UINT32 BspSetPaVibasByEnSavAdj(INT32 rdTemp,INT32 *dacData,INT32 tempOfDacData,UINT32 vbiasType,UINT32 ulRfChnl)
{
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    INT32  tempPoint[PA_TEMP_POINT_MAX_NUM] = {0};
    INT32  tempCoef[PA_TEMP_POINT_MAX_NUM]  = {0};
    UINT32 vbiasTypeNum  = 4;
    UINT32 VgsDeltaNum   = 4;
    UINT32 paGainNum     = 1;
    UINT32 tempPointIndex= 0;
    UINT32 tempCoefItem  = 0;
    /* INT32  paGain  = 0; */
    UINT32 parLevel = 0;
    UINT32 dataIndex = 0;
    INT32  tempInf = 0;
    UINT32 stdInfIndex = 0;
    UINT32 currInfIndex = 0;
    UINT32 loop = 0;
    UINT32 pointNum  = 0;
    UINT32 coefNum  = 0;
    UINT32 tblIndex = 0;
    UINT32 tblChn = 0;

    BspUpdateRfTblIndexAndChn(ulRfChnl, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    IF_CHK(tblIndex > 0)
    {
        return BSP_OK;    /*按照方案子母端机型 子端不在静态调压流程调整栅压直接返回OK 子端表的编号是234*/
    }
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);

    if (NULL == ptEnSavAdjData)
    {
        return BSP_ERROR;
    }

//    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    INPUT_POINTER_CHECK(dacData);

    vbiasTypeNum  = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].vbiasTypeNum;
    VgsDeltaNum   = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].vgsDeltaNum;
    if(vbiasType >= (EN_SAV_ADJ_MAX_ITEM - vbiasTypeNum))
    {
        dbgErr("%s: vbiasType is out of range.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    //ptEnSavAdjData初始化时 vbiasTypeNum、VgsDeltaNum默认值为0
    if(vbiasTypeNum == 0 || VgsDeltaNum == 0)
    {
        dbgInfoEx("%s: vbiasTypeNum and VgsDeltaNum are wrong.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    BspGetPaVibasNewParLevel(ulRfChnl, &parLevel, &dataIndex);
    //paGain获取并设置
    /* paGain = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].pCombiData[parLevel].combiItem[dataIndex][vbiasTypeNum+VgsDeltaNum]; */

    /*待后续文件统一后放开*/
    //BspSetPaGain(ulRfChnl,paGain);

    /* 折点温度点数 */
    pointNum = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].aGridVoltN[0];
    if(pointNum >= PA_TEMP_POINT_MAX_NUM)
    {
        dbgErr("%s: pointNum is out of range.\n", __FUNCTION__);
        return BSP_ERROR;;
    }

    /* 补偿系数种类数 */
    coefNum = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].aGridVoltN[1];
    if(coefNum >= PA_TEMP_POINT_MAX_NUM)
    {
        dbgErr("%s: coefNum is out of range.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    /* 取出所有折点温度 */
    tempPointIndex = vbiasTypeNum+VgsDeltaNum+paGainNum;
    for(loop = 0; loop < pointNum; loop++)
    {
        tempPoint[loop] = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].pCombiData[parLevel].combiItem[dataIndex][tempPointIndex+loop];
        dbgInfoEx("tempPonit[%d]  = %d    ", loop, tempPoint[loop]);
    }

    /* 取出所有补偿系数 */
    for(loop = 0; loop < coefNum; loop++)
    {
        tempCoefItem = tempPointIndex+pointNum+vbiasType*coefNum+loop;
        if(tempCoefItem >= EN_SAV_ADJ_MAX_ITEM)
        {
            dbgErr("%s: tempCoefItem is out of range.\n", __FUNCTION__);
            return BSP_ERROR;
        }
        tempCoef[loop] = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].pCombiData[parLevel].combiItem[dataIndex][tempCoefItem];
        dbgInfoEx("Coef[%d]  = %d    ", loop, tempCoef[loop]);
    }
    dbgInfoEx("\n");
    dbgInfoEx("%s ulRfChnl=%d pointNum=%d coefNum=%d vbiasTypeNum=%d VgsDeltaNum=%d tempPointIndex=%d\n",\
            __FUNCTION__,ulRfChnl,pointNum,coefNum,vbiasTypeNum,VgsDeltaNum,tempPointIndex);
    /* 找出基准值落在哪段折线上 */
    for (loop = 0; loop < pointNum; loop++)
    {
        /* 温度点 */
        tempInf = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].pCombiData[parLevel].combiItem[dataIndex][tempPointIndex+loop];
        if (tempOfDacData <= tempInf)
        {
            break;
        }
    }

    stdInfIndex  = loop;

    /* 找出当前温度落在哪段折线上 */
    for (loop = 0; loop < pointNum; loop++)
    {
        tempInf = ptEnSavAdjData->atEnSavAdjPath[ulRfChnl].pCombiData[parLevel].combiItem[dataIndex][tempPointIndex+loop];
        if (rdTemp <= tempInf)
        {
            break;
        }
    }

    currInfIndex = loop;

    /* 计算当前温度的DAC值 */
    if (currInfIndex > stdInfIndex)
    {
        for (loop = stdInfIndex; loop < currInfIndex; loop++)
        {
            /*  (折点温度-基准温度) * 补偿系数 */
            *dacData += (((tempPoint[loop] - tempOfDacData) * tempCoef[loop]) / 100);
            tempOfDacData = tempPoint[loop];
        }
    }
    else if (currInfIndex < stdInfIndex)
    {
        for (loop = stdInfIndex; loop > currInfIndex; loop--)
        {
            /*  (折点温度-基准温度) * 补偿系数 */
            *dacData += (((tempPoint[loop-1] - tempOfDacData) * tempCoef[loop]) / 100);
            tempOfDacData = tempPoint[loop-1];
        }
    }
    else
    {
        loop = currInfIndex;
    }

    *dacData += (((rdTemp - tempOfDacData) * tempCoef[loop]) / 100);

    return BSP_OK;
}

UINT32 BspGetPaDacClassNumIdx(T_PaDacSetCaliData *ptData, UINT32 paChn)
{
    UINT32 carrCenterFreq = 0;
    UINT32 band = 0;
    UINT32 classIdx = 0;

    if (ptData->tHeader.ulClassNum <= 1)
    {
        return classIdx;
    }
    carrCenterFreq = BspGetMultiCarrCenterFreq(TX, paChn);
    if (carrCenterFreq == 0 || carrCenterFreq == BSP_ERROR)
    {
        return classIdx;
    }

    for (band = 0; band < TBL_PA_MAX_FREQ_NUM; band++)
    {
        for (classIdx = 0; classIdx < ptData->tHeader.ulClassNum; classIdx++)
        {
            /*跟功放沟通边界点取左侧class*/
            if ((ptData->tHeader.paFreq[band][classIdx] <= carrCenterFreq) && (carrCenterFreq < ptData->tHeader.paFreq[band][1 + classIdx]))
            {
                dbgInfoEx("%s: paChn=%u find classIdx=%u\n", __FUNCTION__, paChn, classIdx);
                return classIdx;
            }
            /*频段最后一个分界点取最后一个class*/
            if((classIdx == ptData->tHeader.ulClassNum -1) && (carrCenterFreq == ptData->tHeader.paFreq[band][1 + classIdx]))
            {
                classIdx = ptData->tHeader.ulClassNum -1;
                dbgInfoEx("%s: paChn=%u find classIdx=%u\n", __FUNCTION__, paChn, classIdx);
                return classIdx;
            }
        }
    }
    dbgInfoEx("%s: paChn=%u classIdx=%u\n", __FUNCTION__, paChn, classIdx);
    return (classIdx >= TBL_MAX_CHAN_CLASSNUM ? 0 : classIdx);
}

UINT32 BspGetPaChanMaxNum(VOID)
{
    UINT32 uiValidPathNum = 0;
    UINT32 txChanNum = 0;
    UINT32 PaMaxChanNum = 0;

    txChanNum = BspGetTxChannel();
    uiValidPathNum = PADACSET_GetValidPathNum();

    if(uiValidPathNum < txChanNum)
    {
        PaMaxChanNum =  uiValidPathNum;
    }
    else
    {
        PaMaxChanNum = txChanNum;//宏站这里是否先保持现状？
    }
    return PaMaxChanNum;
}

/*****************************************************************************
 *  函数名称   : BspSetPaVibas(*)
 *  功能描述   : 根据温度查表配置栅压,根据PaDacSet.txt 温度分段和系数补偿栅压
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulIndex  -  功放索引
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 成功; BSP_ERROR - 失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 5GNR@2017-07-05 09:56 创建函数。
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaVibas(UINT32 index)
{
    INT32  rdTemp  = 0;
    INT32  tempInf = 0;
    INT32  dacData = 0;
    UINT32 num   = 0;
    UINT32 paChan = 0;
    UINT32 loop   = 0;
    UINT32 dacChan = 0;
    UINT32 coefNum  = 0;
    UINT32 pointNum  = 0;
    UINT32 stdInfIndex = 0;
    UINT32 currInfIndex = 0;
    INT32  tempOfDacData = 0;
    INT32  tempPoint[10] = {0};
    INT32  tempCoef[10]  = {0};
    INT32  odacData = 0;
    UINT32 vbiasType = 0;
    T_PaDacSetCaliData  *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    INT32 digGainQorvo = 0;
    INT32 dacVoltGain = 0;
    UINT32 paType = 0;
    UINT32 classNumIdx = 0;
    UINT32  PaMaxChanNum = 0;
    if(pSetPaVibasCallBack != NULL)  /* 由于规格不统一，在单板下实现 */
    {
        return pSetPaVibasCallBack(index);
    }

    /* 获取写表数据 */
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, index);
    INPUT_POINTER_CHECK(ptData);
    PaMaxChanNum = BspGetPaChanMaxNum();
    for(paChan = 0; paChan < PaMaxChanNum;paChan++)
    {
        if(0 == paVibasUpdate[paChan%MAX_RFCHAN_NUM])
        {
            continue;
        }
        classNumIdx = BspGetPaDacClassNumIdx(ptData, paChan);
        if (ptData->pCaliPath[classNumIdx] == NULL)
        {
            continue;
        }
        /* 解析后的paChan通道数据 */
        ptRecord = ptData->pCaliPath[classNumIdx][paChan].ptRecord;
        INPUT_POINTER_CHECK_CONTINUE(ptRecord);

        /* 获取paChan通道PA温度 */
        if (BSP_OK != BspGetPaTemp(paChan, &rdTemp))
        {
            dbgInfoEx("%s paChan%d get temp failed\n",__FUNCTION__,paChan);
            continue;
        }
        /* 配置DAC:一个 PA 需要 ulRecordNum 条配置 */
        for (num = 0; num < ptData->pCaliPath[classNumIdx][paChan].ulRecordNum; num++)
        {
            dacChan       = ptRecord->ulDacChanIndex;     /* DAC通道索引 */
            dacData       = ptRecord->ulGridVoltDataDef;   /* 基准电压 */
            tempOfDacData = ptRecord->lGridVoltTempFixDef; /* 基准温度 */
            vbiasType   = ptRecord->ulGridVoltType ;/*PA驱动类型 peak carrier driver*/

            /*静态调压启用节能调压表后放开 */
#if 0
            if(BSP_OK == BspSetPaVibasByEnSavAdj(rdTemp,&dacData,tempOfDacData,vbiasType,paChan)) //读取离线表设置栅压
            {
                dbgInfoEx("[%s]*********PaEnergySavingAdj.txt load successful !!!!**********\n",__FUNCTION__);

                if(dacData < ptRecord->ulGridVoltLower)
                {
                    dacData = ptRecord->ulGridVoltLower;
                }

                if(dacData > ptRecord->ulGridVoltUpper)
                {
                    dacData = ptRecord->ulGridVoltUpper;
                }

                /* 设置DAC值 */
                dbgInfoEx("%s:paChan %d,temp %d,dacChan %d,defData %d: odacData %d, dacData %d, Lower %d, Upper %d\n",
                    __FUNCTION__, paChan, rdTemp, dacChan, ptRecord->ulGridVoltDataDef, dacData, dacData,
                    ptRecord->ulGridVoltLower, ptRecord->ulGridVoltUpper);

                BspSetPaGridVoltFix(paChan, vbiasType, dacChan, dacData);

                ptRecord++;

                continue;
            }
            dbgInfoEx("[%s]*********PaEnergySavingAdj.txt load failed !!!!**********\n",__FUNCTION__);
#endif
            /* 折点温度点数 */
            pointNum = ptData->tHeader.aGridVoltN[0];

            /* 补偿系数种类数 */
            coefNum = ptData->tHeader.aGridVoltN[1];

            /* 是否溢出 */
            if ((pointNum + coefNum) > NELEMENTS(ptRecord->lPointAndCoefficient))
            {
                /* 停止整个paChan配置 */
                break;
            }

            /* 取出所有折点温度 */
            for(loop = 0; loop < pointNum; loop++)
            {
                tempPoint[loop] = ptRecord->lPointAndCoefficient[loop];
            }

            /* 取出所有补偿系数 */
            for(loop = 0; loop < coefNum; loop++)
            {
                tempCoef[loop] = ptRecord->lPointAndCoefficient[pointNum + loop];
            }

            /* 找出基准值落在哪段折线上 */
            for (loop = 0; loop < pointNum; loop++)
            {
                /* 温度点 */
                tempInf = ptRecord->lPointAndCoefficient[loop];
                if (tempOfDacData <= tempInf)
                {
                    break;
                }
            }

            stdInfIndex  = loop;

            /* 找出当前温度落在哪段折线上 */
            for (loop = 0; loop < pointNum; loop++)
            {
                tempInf = ptRecord->lPointAndCoefficient[loop];
                if (rdTemp <= tempInf)
                {
                    break;
                }
            }

            currInfIndex = loop;

            /* 计算当前温度的DAC值 */
            if (currInfIndex > stdInfIndex)
            {
                for (loop = stdInfIndex; loop < currInfIndex; loop++)
                {
                    /*  (折点温度-基准温度) * 补偿系数 */
                    dacData += (((tempPoint[loop] - tempOfDacData) * tempCoef[loop]) / 100);
                    tempOfDacData = tempPoint[loop];
                }
            }
            else if (currInfIndex < stdInfIndex)
            {
                for (loop = stdInfIndex; loop > currInfIndex; loop--)
                {
                    /*  (折点温度-基准温度) * 补偿系数 */
                    dacData += (((tempPoint[loop-1] - tempOfDacData) * tempCoef[loop]) / 100);
                    tempOfDacData = tempPoint[loop-1];
                }
            }
            else
            {
                loop = currInfIndex;
            }

            dacData += (((rdTemp - tempOfDacData) * tempCoef[loop]) / 100);

            BspSetPaGridVoltTempComp(paChan, vbiasType, ((rdTemp - tempOfDacData) * tempCoef[loop]) / 100);

            odacData = dacData;
            if(dacData < ptRecord->ulGridVoltLower)
            {
                dacData = ptRecord->ulGridVoltLower;
            }

            if(dacData > ptRecord->ulGridVoltUpper)
            {
                dacData = ptRecord->ulGridVoltUpper;
            }
            /*新增Qorvo外场升级栅压方案*/
           if(NULL != pGetQorvoAnaCall)
           {
               pGetQorvoAnaCall(paChan, &digGainQorvo, &dacVoltGain, &paType);
               if( ptRecord->ulGridVoltType == paType)
               {
                     dacData += dacVoltGain; //满足条件，增加100mv
                     dbgInfoEx("%s: paChan = %d, Qorvo dacData1 = %d, dacVoltGain = %d\n", __FUNCTION__, paChan, dacData, dacVoltGain);
                }
           }

            if(NULL != pGetGridVoltAdjustCall)
            {
                pGetGridVoltAdjustCall(paChan, ptRecord->ulGridVoltType, &dacVoltGain);
                dacData += dacVoltGain; //满足条件，增加200mv
                dbgInfoEx("%s: paChan = %d, Qorvo dacData1 = %d, dacVoltGain = %d\n", __FUNCTION__, paChan, dacData, dacVoltGain);
                
            }
            /* 设置DAC值 */
            dbgInfoEx("%s:paChan %d,temp %d,vbiasType %d,dacChan %d,defData %d: odacData %d, dacData %d, Lower %d, Upper %d\n",
                __FUNCTION__, paChan, rdTemp, vbiasType,dacChan, ptRecord->ulGridVoltDataDef, odacData, dacData,
                ptRecord->ulGridVoltLower, ptRecord->ulGridVoltUpper);

            BspSetPaGridVoltFix(paChan, vbiasType,dacChan, dacData);

            ptRecord++;
        }
    }
    return BSP_OK;

}

UINT32 BspGetDacChan(UINT32 ulRfChnl, UINT32 vbiasType, UINT32 *pulDacChn, UINT32 *pulRecId)
{
    UINT32 ulChnlIdx = 0;
    UINT32 ulRecordSum = 0;
    UINT32 ulRecordIdx = 0;
    UINT32 ulPaRfChnnl = 0;
    UINT32 ulPaSubChnl = 0;
    UINT32 ulPaChipIdx = 0;
    UINT32 ulFuncRet = BSP_ERROR;
    T_PaDacSetCaliData *ptPaDacData = NULL;
    T_PaDacSetCaliPath *ptPaCaliPath = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;

    INPUT_POINTER_CHECK(pulDacChn);
    INPUT_POINTER_CHECK(pulRecId);

    ptPaDacData  = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    if (NULL == ptPaDacData)
    {
        dbgErr("%s>>Error! pPaDacData NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    ptPaCaliPath = ptPaDacData->pCaliPath[0];

    if (NULL == ptPaCaliPath)
    {
        dbgErr("%s>>Error! pPaCaliPath NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if((ulRfChnl >= BspGetTxChannel())||(ulRfChnl >=  ptPaDacData->tComHeader.ulPathNum))
    {
    	return BSP_ERROR;
    }
    ulChnlIdx = ulRfChnl;
    ptRecord    = ptPaDacData->pCaliPath[0][ulChnlIdx].ptRecord;
    ulRecordSum = ptPaDacData->pCaliPath[0][ulChnlIdx].ulRecordNum;

    if (NULL == ptRecord)
	{
		dbgInfo("%s>>Error! TxRfCh'%d RecordSum'%d ptRecord NULL!\n",
				__FUNCTION__, ulChnlIdx, ulRecordSum);
		return BSP_ERROR;
	}
	if (0 == ulRecordSum)
	{
		dbgInfo("%s>>TxRfCh'%d RecordSum==%d Error!!\n",
				__FUNCTION__, ulChnlIdx, ulRecordSum);
		return BSP_ERROR;
	}

    for (ulRecordIdx = 0; ulRecordIdx < ulRecordSum; ulRecordIdx++)
    {
    	ulPaRfChnnl = ptRecord->ulPaChan;
    	ulPaChipIdx = ptRecord->ulDacPhyIndex;
    	ulPaSubChnl = ptRecord->ulDacChanIndex;
    	if(vbiasType == ptRecord->ulGridVoltType)
    	{
    		*pulDacChn = ulPaSubChnl;
    		*pulRecId = ulRecordIdx;
        	dbgInfoEx("%s(%d)>>ch:%d, ulRecordIdx:%d, PaChan:%d, PaChip:%d, DacChan:%d, vbiasType:%d\n",
        			 __FUNCTION__, __LINE__, ulRfChnl, ulRecordIdx, ulPaRfChnnl, ulPaChipIdx, ulPaSubChnl, vbiasType);
        	ulFuncRet = BSP_OK;
    		break;
    	}
    	dbgInfoEx("%s(%d)>>ch:%d, ulRecordIdx:%d, PaChan:%d, PaChip:%d, DacChan:%d, vbiasType:%d\n",
    			 __FUNCTION__, __LINE__, ulRfChnl, ulRecordIdx, ulPaRfChnnl, ulPaChipIdx, ulPaSubChnl, vbiasType);
    	ptRecord++;
    }

    return ulFuncRet;
}

/* 根据温度查表配置栅压,根据PaDacSet.txt 温度分段和系数补偿栅压 */
UINT32 BspSetPaVibasByChan(UINT32 index,UINT32 ulRfChnl)
{
    INT32  rdTemp  = 0;
    INT32  tempInf = 0;
    INT32  dacData = 0;
    UINT32 num   = 0;
    UINT32 loop   = 0;
    UINT32 dacChan = 0;
    UINT32 coefNum  = 0;
    UINT32 pointNum  = 0;
    UINT32 stdInfIndex = 0;
    UINT32 currInfIndex = 0;
    INT32  tempOfDacData = 0;
    INT32  tempPoint[10] = {0};
    INT32  tempCoef[10]  = {0};
    UINT32 ulPaChnl = 0;
    UINT32 vbiasType = 0;
    T_PaDacSetCaliData  *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    INT32 digGainQorvo = 0;
    INT32 dacVoltGain = 0;
    UINT32 paType = 0;
    UINT32 classNumIdx = 0;

    /* 获取写表数据 */
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, index);
    if(ptData == NULL)
    {
        dbgErr("%s>>_BspGetCalibData retun null, may by no PaDacSet.txt file!\n",__FUNCTION__);
        return ERROR_NULL_POINTER;
    }
    classNumIdx = BspGetPaDacClassNumIdx(ptData, ulRfChnl);
    INPUT_POINTER_CHECK(ptData->pCaliPath[classNumIdx]);
    if (BSP_OK != BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl))
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error!\n",
               __FUNCTION__, ulRfChnl);
        return BSP_ERROR;
    }

    /* 解析后的paChan通道数据 */
    ptRecord = ptData->pCaliPath[classNumIdx][ulPaChnl].ptRecord;
    INPUT_POINTER_CHECK(ptRecord);
    if(0 == paVibasUpdate[ulRfChnl])
    {
        return BSP_OK;
    }
    /* 获取paChan通道PA温度 */
    if (BSP_OK != BspGetPaTemp(ulRfChnl, &rdTemp))
    {
        dbgInfoEx("%s paChan%d get temp failed\n",__FUNCTION__,ulRfChnl);
        return BSP_ERROR;
    }

    /* 配置DAC:一个 PA 需要 ulRecordNum 条配置 */
    for (num = 0; num < ptData->pCaliPath[classNumIdx][ulPaChnl].ulRecordNum; num++)
    {
        dacChan       = ptRecord->ulDacChanIndex;     /* DAC通道索引 */
        dacData       = ptRecord->ulGridVoltDataDef;   /* 基准电压 */
        tempOfDacData = ptRecord->lGridVoltTempFixDef; /* 基准温度 */
        vbiasType      = ptRecord->ulGridVoltType;
        /* 折点温度点数 */
        pointNum = ptData->tHeader.aGridVoltN[0];

        /* 补偿系数种类数 */
        coefNum = ptData->tHeader.aGridVoltN[1];

        /* 是否溢出 */
        if ((pointNum + coefNum) > NELEMENTS(ptRecord->lPointAndCoefficient))
        {
            /* 停止整个paChan配置 */
            break;
        }

        /* 取出所有折点温度 */
        for(loop = 0; loop < pointNum; loop++)
        {
            tempPoint[loop] = ptRecord->lPointAndCoefficient[loop]; 
        }
        
        /* 取出所有补偿系数 */
        for(loop = 0; loop < coefNum; loop++)
        {
            tempCoef[loop] = ptRecord->lPointAndCoefficient[pointNum + loop];
        }

        /* 找出基准值落在哪段折线上 */
        for (loop = 0; loop < pointNum; loop++)
        {
            /* 温度点 */
            tempInf = ptRecord->lPointAndCoefficient[loop];
            if (tempOfDacData <= tempInf)
            {
                break;
            }
        }
        
        stdInfIndex  = loop;
                
        /* 找出当前温度落在哪段折线上 */
        for (loop = 0; loop < pointNum; loop++)
        {
            tempInf = ptRecord->lPointAndCoefficient[loop];
            if (rdTemp <= tempInf)
            {
                break;
            }
        }

        currInfIndex = loop;
        
        /* 计算当前温度的DAC值 */
        if (currInfIndex > stdInfIndex)
        {
            for (loop = stdInfIndex; loop < currInfIndex; loop++)
            {              
                /*  (折点温度-基准温度) * 补偿系数 */
                dacData += (((tempPoint[loop] - tempOfDacData) * tempCoef[loop]) / 100);
                tempOfDacData = tempPoint[loop];
            }
        }
        else if (currInfIndex < stdInfIndex)
        {
            for (loop = stdInfIndex; loop > currInfIndex; loop--)
            {                
                /*  (折点温度-基准温度) * 补偿系数 */
                dacData += (((tempPoint[loop-1] - tempOfDacData) * tempCoef[loop]) / 100);
                tempOfDacData = tempPoint[loop-1];
            }
        }
        else
        {
            loop = currInfIndex;
        }

        dacData += (((rdTemp - tempOfDacData) * tempCoef[loop]) / 100);

        if(dacData < ptRecord->ulGridVoltLower)
        {
            dacData = ptRecord->ulGridVoltLower;
        }

        if(dacData > ptRecord->ulGridVoltUpper)
        {
            dacData = ptRecord->ulGridVoltUpper;
        }
        /*新增Qorvo外场升级栅压方案*/
        if(NULL != pGetQorvoAnaCall)
        {
            pGetQorvoAnaCall(ulRfChnl, &digGainQorvo, &dacVoltGain, &paType);
            if(ptRecord->ulGridVoltType == paType)
            {
                dacData += dacVoltGain; //满足条件，增加100mv
                dbgInfoEx("%s: ulRfChnl = %d, Qorvo dacData1 = %d, dacVoltGain = %d\n", __FUNCTION__, ulRfChnl, dacData,dacVoltGain);
            }
        }

        /* 设置DAC值 */
        dbgInfoEx("%s:ulRfChnl%d paChan %d,temp %d,vbiasType %d,dacChan %d,dacData %d,defData %d\n",
            __FUNCTION__, ulRfChnl, ulPaChnl,rdTemp, vbiasType,dacChan, dacData, ptRecord->ulGridVoltDataDef);
        BspSetPaGridVoltFix(ulRfChnl, vbiasType, dacChan, dacData);
        
        ptRecord++;
    }    
    
    return BSP_OK;
}


/* 栅压配置记录数据，从单板目录调整   */
ChanPwrInfo s_paVoltAdjInfo = {0};
VOID BspRecordPaGridVoltByChanPower(UINT32 chanNum, ChanPower pChanPwr[])
{
    UINT32 ulLoop = 0;
    UINT32 chanNo = 0;
    UINT32 txChnl = 0;

    txChnl = BspGetTxChannel();
    s_paVoltAdjInfo.ulChanValidNum = chanNum;
    for(ulLoop = 0; ulLoop < s_paVoltAdjInfo.ulChanValidNum; ulLoop++)
    {
        chanNo = pChanPwr[ulLoop].chanNo;
        if(chanNo >= txChnl)
        {
            dbgErr("%s: chanNo'%d >= %d\n", __FUNCTION__, chanNo,txChnl);
            return;
        }
        s_paVoltAdjInfo.ulChanPwrInfo[chanNo].chanNo   = pChanPwr[ulLoop].chanNo;
        s_paVoltAdjInfo.ulChanPwrInfo[chanNo].powerDbm = pChanPwr[ulLoop].chanPwr;
    }
    return ;
}

VOID BspRecordPaGridAdjVolt(UINT32 chanNo, UINT32 vbiasType, UINT32 dacChanNo, INT32 paVolt)
{
    UINT32 paDacChanNo = 0;
    UINT32 txChnl = 0;

    txChnl = BspGetTxChannel();
    //paDacChanNo = dacChanNo % 4;
    paDacChanNo = vbiasType % 4;

    dbgInfoEx("%s>>chanNo:%d, vbiasType:%d, dacChanNo:%d, paVolt:%d\n",__FUNCTION__, chanNo, vbiasType, dacChanNo, paVolt);
    if(chanNo >= txChnl)
    {
        dbgErr("%s: chanNo'%d >= %d\n", __FUNCTION__, chanNo,txChnl);
        return;
    }
    
    s_paVoltAdjInfo.ulChanPwrInfo[chanNo].paGridVolt[paDacChanNo] = paVolt;

    return ;
}

VOID showPaVoltAdjInfo(VOID)
{
    UINT32 ulLoop      = 0;
    UINT32 ulInterLoop = 0;
    UINT32 dacChan     = 0;
    UINT32 ret         = 0;
    UINT32 ulRecId     = 0;
    INT32  piVolt[PA_GRID_CHANNUL_NUM] = {0};
    UINT32 txChnl = 0;

    txChnl = BspGetTxChannel();

    dbgInfo("\n=================TargetPaGridVolt(mV)=========================\n");
    dbgInfo("ChanNo  PowerDbm  vbiasType[0]  vbiasType[1] vbiasType[2] vbiasType[3] vbiasType[4] vbiasType[5]\n");
    for(ulLoop = 0; ulLoop < txChnl; ulLoop++)
    {
        if(0 == s_paVoltAdjInfo.ulChanValidNum)
        {
            break;
        }
        dbgInfo(" [%d]\t%6d%10d%12d%11d%11d%11d%11d\n", s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].chanNo,
                                                s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].powerDbm,
                                                s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].paGridVolt[0],
                                                s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].paGridVolt[1],
                                                s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].paGridVolt[2],
                                                s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].paGridVolt[3],
                                                s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].paGridVolt[4],
                                                s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].paGridVolt[5]);

    }
    dbgInfo("=================RealityPaGridVolt(mV)========================\n");
    dbgInfo("ChanNo\t\t  vbiasType[0]  vbiasType[1] vbiasType[2] vbiasType[3] vbiasType[4] vbiasType[5]\n");
    for(ulLoop = 0; ulLoop < txChnl; ulLoop++)
    {
        for(ulInterLoop = 0; ulInterLoop < PA_GRID_CHANNUL_NUM; ulInterLoop++)
        {
            //dacChan = (s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].chanNo * 4 + ulInterLoop) % 32;
        	ret = BspGetDacChan(s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].chanNo, ulInterLoop, &dacChan, &ulRecId);
        	if(BSP_OK != ret)
        	{
        		dbgErr("%s(%d) vbiasType:%d>>error\n", __FUNCTION__, __LINE__,ulInterLoop);
        		continue;
        	}
        	if(ulRecId >= PA_GRID_CHANNUL_NUM)
        	{
        		dbgErr("%s(%d)>>error\n", __FUNCTION__, __LINE__);
        		continue;
        	}
            dbgInfoEx("ulLoop:%d, ulInterLoop:%d, dacChan:%d, RecId:%d\n", ulLoop, ulInterLoop, dacChan, ulRecId);
            BspGetPaGridVoltFix(s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].chanNo, ulInterLoop, dacChan, &piVolt[ulInterLoop]);
        }
        dbgInfo(" [%d]\t\t%8d%12d%11d%11d%11d%11d\n", s_paVoltAdjInfo.ulChanPwrInfo[ulLoop].chanNo,
                                            piVolt[0],piVolt[1],piVolt[2],piVolt[3],piVolt[4],piVolt[5]);
    }
    dbgInfo("\n");
    return;
}

UINT32 BspGetChanPaGrid(ULONG ulchan, CHAR *pcGridInf)
{
	uint32_t ret     = BSP_OK;
	uint32_t loop    = 0;
	uint32_t dacChan = 0;
	uint32_t ulRecId = 0;
	INT32 piVolt[PA_GRID_CHANNUL_NUM]  = {0,};
	int32_t  snpRet  = 0;
	INPUT_POINTER_CHECK(pcGridInf);
	
	for(loop = 0;loop<PA_GRID_CHANNUL_NUM;loop++)
	{
		ret |= BspGetDacChan(ulchan, loop, &dacChan, &ulRecId);
		ret |= BspGetPaGridVoltFix(ulchan,loop,dacChan,&piVolt[loop]);
		dbgInfoEx("ulchan %d, loop %d, dacChan %d, ulRecId %d, piVolt %d\n",ulchan,loop,dacChan,ulRecId,piVolt[loop]);
	}
	if(BSP_OK == ret)
	{
		snpRet = snprintf_s(pcGridInf,255,"Grid0:%d,Grid1:%d,Grid2:%d,Grid3:%d,Grid4:%d,Grid5:%d",
		        piVolt[0],piVolt[1],piVolt[2],piVolt[3],piVolt[4],piVolt[5]);
        SNPRINTF_S_CHECK(snpRet, 255);
	}
	return ret;
}

UINT32 testBspGetChanPaGrid(ULONG ulchan)
{
	CHAR s[255] = {0};
	if(BSP_OK == BspGetChanPaGrid(ulchan,s))
	{
		dbgInfo("%s\n",s);
		return BSP_OK;
	}
	else
	{
		dbgInfo("BspGetChanPaGrid failed\n");
		return BSP_ERROR;
	}
}


/* @20200502:根据功放宋林东要求，需要根据 离线文件 PaEnergySavingAdj.txt 温度分段和折算系数补偿栅压。基准电压、温度和 DAC内部映射关系 依然使用PaDacSet.txt */

UINT32 g_BspSetPaVibasByChanIn = 0;
UINT32 g_BspSetPaVibasByChanEndOk = 0;
INT32 g_DeltaDacVolt[PA_VIBAS_TYPE_MAX] = {0,0,0,0};  /*20200523,功放要求：周期性栅压温补需要补偿配置功率调整带来的栅压调整值 */

#ifdef BUILD_WITH_OM_FUNC
VOID showpavibasInfo(VOID)
{
	UINT32 loop = 0;
    dbgInfo("g_BspSetPaVibasByChanIn = %d\n", g_BspSetPaVibasByChanIn);
    dbgInfo("g_PavbiasTypeErr = %d\n", g_PavbiasTypeErr);
    dbgInfo("g_BspSetPaVibasByChanEndOk = %d\n", g_BspSetPaVibasByChanEndOk);
    dbgInfo("DeltaDacVolt:\n");
    for(loop = 0; loop < PA_VIBAS_TYPE_MAX; loop++)
    {
    	dbgInfo("[%d]%d\n", loop, g_DeltaDacVolt[loop]);
    }
}
#endif

VOID BspSetPaVibasDeltaDacVolt(UINT32 vbiasType, INT32 volt)
{
	g_DeltaDacVolt[vbiasType % PA_VIBAS_TYPE_MAX] = volt;
}

INT32 BspGetPaVibasDeltaDacVolt(UINT32 vbiasType)
{
	return g_DeltaDacVolt[vbiasType % PA_VIBAS_TYPE_MAX];
}

UINT32 BspSetPaVibasByChanNew(UINT32 index,UINT32 ulRfChnl)
{
    INT32  rdTemp  = 0;
    INT32  tempInf = 0;
    UINT32 num   = 0;
    UINT32 loop   = 0;
    UINT32 dacChan = 0;
    UINT32 coefNum  = 0;
    UINT32 pointNum  = 0;
    UINT32 stdInfIndex = 0;
    UINT32 currInfIndex = 0;
    INT32  tempOfDacData = 0;
    INT32  tempPoint[PA_TEMP_POINT_MAX_NUM] = {0};
    INT32  tempCoef[PA_TEMP_POINT_MAX_NUM]  = {0};
    UINT32 ulPaChnl = 0;  
    T_PaDacSetCaliData  *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    UINT32 vbiasTypeNum  = 4;
    UINT32 VgsDeltaNum   = 4;
    UINT32 paGainNum     = 1;
    UINT32 parLevel = 0;
    UINT32 dataIndex = 0;
    UINT32 vbiasType     = 0;
    UINT32 ret = BSP_OK;
    UINT32 paChan = 0;
    UINT32 tempPointIndex= 0;
    UINT32 tempCoefItem  = 0;
    INT32  dacVolt       = 0;
    INT32  odacData      = 0;
    INT32 digGainQorvo  = 0;
    INT32 dacVoltGain = 0;
    INT32  deltaVolt     = 0;
    UINT32 paType = 0;
    UINT32 tblIndex = 0;
    UINT32 tblChn = 0;

    BspUpdateRfTblIndexAndChn(ulRfChnl, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    IF_CHK(tblIndex > 0)
    {
        return BSP_OK;    /*按照方案子母端机型 子端不在静态调压流程调整栅压直接返回OK 子端表的编号是234*/
    }
    g_BspSetPaVibasByChanIn++;
    /* 获取写表数据 */
/* Started by AICoder, pid:f967ed4bf7ia0021467a0995501d0d1fa97428dc */
    /*RF PA通道号非一一对应时，不进行转换*/
    if (BspGetPachnRfchnMismatchFlag() == PARfCHAN_MISMATCH)
    {
        paChan = ulRfChnl;
    }
    else
    {
        if (BSP_OK != BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl))
        {
            dbgErr("%s>>TxRfCh'%d GetPaChnl Error!\n",
                   __FUNCTION__, ulRfChnl);
            return BSP_ERROR;
        }
        paChan = ulPaChnl;
    }
/* Ended by AICoder, pid:f967ed4bf7ia0021467a0995501d0d1fa97428dc */
    
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, index);
    INPUT_POINTER_CHECK(ptData);
    INPUT_POINTER_CHECK(ptData->pCaliPath[0]);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

	TBL_CHAN_VALID_CHECK(paChan);
    ret = BspGetPaVibasNewParLevel(paChan, &parLevel, &dataIndex);
    
    if ((BSP_OK != ret) || (dataIndex >= EN_SAV_ADJ_MAX_ROW) || (parLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
    	dbgErr("%s--error--, chan:%d, dataIndex:%d, parLevel:%d\n", __FUNCTION__, ulRfChnl, dataIndex,  parLevel);
        return BSP_ERROR;
    }

    /* 解析后的paChan通道数据 */
    ptRecord = ptData->pCaliPath[0][paChan].ptRecord;
    INPUT_POINTER_CHECK(ptRecord);
    if(0 == paVibasUpdate[ulRfChnl % MAX_RFCHAN_NUM])
    {
        return BSP_OK;
    }
    /* 获取paChan通道PA温度 */
    if (BSP_OK != BspGetPaTemp(ulRfChnl, &rdTemp))
    {
        dbgInfoEx("%s paChan%d get temp failed\n",__FUNCTION__,paChan);
        return BSP_ERROR;
    }
    /* 配置DAC:一个 PA 需要 ulRecordNum 条配置 */
    for (num = 0; num < ptData->pCaliPath[0][paChan].ulRecordNum; num++)
    {
        dacChan       = ptRecord->ulDacChanIndex;     /* DAC通道索引 */
        dacVolt       = ptRecord->ulGridVoltDataDef;   /* 基准电压 */
        tempOfDacData = ptRecord->lGridVoltTempFixDef; /* 基准温度 */
        vbiasType     = ptRecord->ulGridVoltType;
        vbiasTypeNum  = ptEnSavAdjData->atEnSavAdjPath[paChan].vbiasTypeNum;
        VgsDeltaNum   = ptEnSavAdjData->atEnSavAdjPath[paChan].vgsDeltaNum;
        if(vbiasType >= (EN_SAV_ADJ_MAX_ITEM - vbiasTypeNum))  /* ? 这个判断条件目的?          */
        {
        	g_PavbiasTypeErr++;
            dbgErr("%s: vbiasType is out of range.\n", __FUNCTION__);
            continue;
        }
        
        /* 折点温度点数 */
       //pointNum = ptData->tHeader.aGridVoltN[0];
        pointNum = ptEnSavAdjData->atEnSavAdjPath[paChan].aGridVoltN[0];
        if(pointNum >= PA_TEMP_POINT_MAX_NUM)
        {            	
        	g_PavbiasTypeErr++;
            dbgErr("%s: pointNum is out of range.\n", __FUNCTION__);
            break;
        }
        
        /* 补偿系数种类数 */
        //coefNum = ptData->tHeader.aGridVoltN[1];
        coefNum = ptEnSavAdjData->atEnSavAdjPath[paChan].aGridVoltN[1];
        if(coefNum >= PA_TEMP_POINT_MAX_NUM)
        {
        	g_PavbiasTypeErr++;
            dbgErr("%s: coefNum is out of range.\n", __FUNCTION__);
            break;
        }
        
        /* 取出所有折点温度 */
        tempPointIndex = vbiasTypeNum+VgsDeltaNum+paGainNum;
        for(loop = 0; loop < pointNum; loop++)
        {
            tempPoint[loop] = ptEnSavAdjData->atEnSavAdjPath[paChan].pCombiData[parLevel].combiItem[dataIndex][tempPointIndex+loop];
            dbgInfoEx("tempPonit[%d]  = %d    ", loop, tempPoint[loop]);
        }

        /* 取出所有补偿系数 */
        for(loop = 0; loop < coefNum; loop++)
        {
            tempCoefItem = tempPointIndex+pointNum+vbiasType*coefNum+loop;
            if(tempCoefItem >= EN_SAV_ADJ_MAX_ITEM)
            {
                dbgErr("%s: tempCoefItem is out of range.\n", __FUNCTION__);
                break;
            }
            tempCoef[loop] = ptEnSavAdjData->atEnSavAdjPath[paChan].pCombiData[parLevel].combiItem[dataIndex][tempCoefItem];
            dbgInfoEx("Coef[%d]  = %d    ", loop, tempCoef[loop]);
        }
        dbgInfoEx("\n");
        dbgInfoEx("%s paChan=%d pointNum=%d coefNum=%d vbiasTypeNum=%d VgsDeltaNum=%d tempPointIndex=%d\n",\
                __FUNCTION__,paChan,pointNum,coefNum,vbiasTypeNum,VgsDeltaNum,tempPointIndex);
        /* 找出基准值落在哪段折线上 */
        for (loop = 0; loop < pointNum; loop++)
        {
            /* 温度点 */
            tempInf = ptEnSavAdjData->atEnSavAdjPath[paChan].pCombiData[parLevel].combiItem[dataIndex][tempPointIndex+loop];
            if (tempOfDacData <= tempInf)
            {
                break;
            }
        }

        stdInfIndex  = loop;

        /* 找出当前温度落在哪段折线上 */
        for (loop = 0; loop < pointNum; loop++)
        {
            tempInf = ptEnSavAdjData->atEnSavAdjPath[paChan].pCombiData[parLevel].combiItem[dataIndex][tempPointIndex+loop];
            if (rdTemp <= tempInf)
            {
                break;
            }
        }

        currInfIndex = loop;

        /* 计算当前温度的DAC值 */
        if (currInfIndex > stdInfIndex)
        {
            for (loop = stdInfIndex; loop < currInfIndex; loop++)
            {
                /*  (折点温度-基准温度) * 补偿系数 */
                dacVolt += (((tempPoint[loop] - tempOfDacData) * tempCoef[loop]) / 100);
                tempOfDacData = tempPoint[loop];
            }
        }
        else if (currInfIndex < stdInfIndex)
        {
            for (loop = stdInfIndex; loop > currInfIndex; loop--)
            {
                /*  (折点温度-基准温度) * 补偿系数 */
                dacVolt += (((tempPoint[loop-1] - tempOfDacData) * tempCoef[loop]) / 100);
                tempOfDacData = tempPoint[loop-1];
            }
        }
        else
        {
            loop = currInfIndex;
        }

        dacVolt += (((rdTemp - tempOfDacData) * tempCoef[loop]) / 100);

        odacData = dacVolt;
        deltaVolt = BspGetPaVibasDeltaDacVolt(vbiasType); /* @20200523 功放要求补偿配置功率带来的栅压差 */
        dacVolt -= deltaVolt; /* 20200528：功放张胜杰要求修改为：dacVolt - deltaVolt */

        if(dacVolt < ptRecord->ulGridVoltLower)
        {
            dacVolt = ptRecord->ulGridVoltLower;
        }

        if(dacVolt > ptRecord->ulGridVoltUpper)
        {
            dacVolt = ptRecord->ulGridVoltUpper;
        }
        /*新增Qorvo外场升级栅压方案*/
        if(NULL != pGetQorvoAnaCall)
        {
            pGetQorvoAnaCall(ulRfChnl, &digGainQorvo, &dacVoltGain, &paType);
            if( ptRecord->ulGridVoltType == paType)
            {
                dacVolt += dacVoltGain; //满足条件，增加100mv
                dbgInfoEx("%s: ulRfChnl = %d, Qorvo dacData1 = %d, dacVoltGain = %d\n", __FUNCTION__, ulRfChnl, dacVolt, dacVoltGain);
            }
        }
        /* 设置DAC值 */
        dbgInfoEx("%s(%d): vbiasType:%d, deltaVolt:%d\n", __FUNCTION__, __LINE__, vbiasType, deltaVolt);
        dbgInfoEx("paChan %d,temp %d,vbiasType %d,dacChan %d,defData %d: odacData %d, dacVolt %d, Lower %d, Upper %d\n",
            paChan, rdTemp, vbiasType,dacChan, ptRecord->ulGridVoltDataDef, odacData, dacVolt,
            ptRecord->ulGridVoltLower, ptRecord->ulGridVoltUpper);

        //BspSetPaGridVolt(paChan, dacChan, dacVolt);
        BspSetPaGridVoltFix(paChan, vbiasType, dacChan, dacVolt);        
        BspRecordPaGridAdjVolt(paChan, vbiasType,dacChan, dacVolt);
        ptRecord++;
    }
    g_BspSetPaVibasByChanEndOk++;
    return BSP_OK;
}

UINT32 BspClrPaVibasByChan(UINT32 index,UINT32 ulRfChnl)
{
    UINT32 num   = 0;
    UINT32 dacChan = 0;
    UINT32 ulPaChnl = 0;
    UINT32 vbiasType = 0;
    T_PaDacSetCaliData  *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;

    /* 获取写表数据 */
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, index);
    INPUT_POINTER_CHECK(ptData);
    INPUT_POINTER_CHECK(ptData->pCaliPath[0]);
    if (BSP_OK != BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl))
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error!\n",
               __FUNCTION__, ulRfChnl);
        return BSP_ERROR;
    }
    dbgInfoEx("BspClrPaVibasByChan> chipIndex [%u], rfChn[%u], PaChn[%u]\r\n", index, ulRfChnl, ulPaChnl);
    /* 解析后的paChan通道数据 */
    ptRecord = ptData->pCaliPath[0][ulPaChnl].ptRecord;
    INPUT_POINTER_CHECK(ptRecord);


    /* 配置DAC:一个 PA 需要 ulRecordNum 条配置 */
    for (num = 0; num < ptData->pCaliPath[0][ulPaChnl].ulRecordNum; num++)
    {
        dacChan       = ptRecord->ulDacChanIndex;     /* DAC通道索引 */
        vbiasType      = ptRecord->ulGridVoltType;

        /* 清除DAC值 */
        dbgInfoEx("%s:ulRfChnl%d paChan %d,vbiasType %d,dacChan %d\n",__FUNCTION__, ulRfChnl, ulPaChnl,vbiasType, dacChan);
        BspClrPaGridVoltFix(ulRfChnl, vbiasType, dacChan);

        ptRecord++;
    }

    return BSP_OK;
}

VOID BspPaDacGirdVoltPrint(UINT32 chn, UINT32 num)
{
    UINT32 ulLoop = 0;
    UINT32 ulDacChip = 0;
    UINT32 ulDacChan = 0;
    INT32 sVoltData = 0;
    INT32 sDefData  = 0;
    UINT32 chnLoop  = 0;
    UINT32 vbiasType = 0;
    T_PaDacSetCaliData *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    dbgInfo("[1]path\t [2]dacChn\t [3]dacIdx\t [4]defVolt(Mv)\t [5]rdVolt(Mv)\t\n\n");
    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    INPUT_POINTER_CHECK_RETURN(ptData);
    INPUT_POINTER_CHECK_RETURN(ptData->pCaliPath[0]);

    if(num == 0)
    {
        num = 8;
    }
    if((chn + num)> BspGetTxChannel())
    {
        num = BspGetTxChannel() - chn ;
    }
    for (chnLoop = chn  ; chnLoop <= chn + num -1; chnLoop++)
    {
        ptRecord = ptData->pCaliPath[0][chnLoop].ptRecord;
        if(ptRecord == NULL)
        {
            continue;
        }

        for (ulLoop = 0; ulLoop < ptData->pCaliPath[0][chnLoop].ulRecordNum; ulLoop++)
        {
            ulDacChip = 0;
            ulDacChan = 0;
            sDefData  = 0;
            sVoltData = 0;

            if (NULL != ptRecord)
            {
                ulDacChip =  ptRecord->ulDacPhyIndex;
                ulDacChan =  ptRecord->ulDacChanIndex;
                sDefData  =  ptRecord->ulGridVoltDataDef;
                vbiasType = ptRecord->ulGridVoltType;
                BspGetPaGridVoltFix(chnLoop, vbiasType,ulDacChan, &sVoltData);
            }
            else
            {
                dbgInfoEx("%s,error\n", __FUNCTION__);
            }

            dbgInfo("[1]%-4d\t [2]%-6d\t [3]%-6d\t [4]%-7d\t [5]%-6d\t [6]%-5d\t\n", chnLoop, ulDacChan, ulDacChip, sDefData, sVoltData,vbiasType);
            ptRecord++;
        }
    }
    return;
}

/*栅压温补使能*/
VOID BspSetVibasDisable(UINT32 chanNo)
{
    paVibasUpdate[chanNo] = 0;
}

VOID BspSetVibasEnable(UINT32 chanNo)
{
    paVibasUpdate[chanNo] = 1;
}

UINT32 BspGetVibasEnableFlag(UINT32 chanNo, UINT32 *pPaVibasFlag)
{
    UINT32 ulLoop = 0;

    INPUT_POINTER_CHECK(pPaVibasFlag);
    if (chanNo >= MAX_RFCHAN_NUM)
    {
        dbgErr("%s chanNo'%d overload!\n", __FUNCTION__, chanNo);
        return BSP_ERROR;
    }
    for (ulLoop = 0; ulLoop < MAX_RFCHAN_NUM; ulLoop++)
    {
        if(ulLoop == chanNo)
        {
            *pPaVibasFlag = paVibasUpdate[chanNo];
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

//返回amc器件索引
UINT32 BspGetPaDacDevIndexByChan(UINT32 chanNo)
{
    UINT32 retVal  = 0;
    UINT32 bspChan = 0;
    UINT32 ulDevId = 0;
    char   ucNameBuf[PA_PARA_LENGTH] = {0};
    TRruDeviceDescription dev      = {0};
    INT32  lSnpRet = 0;

    retVal = BspGetPaChnByRfChn(chanNo, TX, &bspChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>TxRfCh'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, chanNo, retVal);
        return BSP_ERROR;
    }

    lSnpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", bspChan);
    SNPRINTF_S_CHECK(lSnpRet,sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);
    if (BSP_ERROR == ulDevId)
    {
        dbgErr("%s>>TxRfCh'%d DevName'%s ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, chanNo, ucNameBuf, ulDevId);
        return BSP_ERROR;
    }

    dbgInfo("%s: ulDevId=%d\n", __FUNCTION__, ulDevId);
   
    retVal = BspDevInfoGetByDevId(ulDevId, &dev);
    if(BSP_OK != retVal)
    {
        printf("%s: Get DeviceIndex failed!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfo("%s: dev.ulDeviceIndex=%d\n", __FUNCTION__, dev.ulDeviceIndex);

    return dev.ulDeviceIndex;
}

/*====================== Test Funcs ==========================*/
#ifdef BUILD_WITH_OM_FUNC
VOID vibasdisable()
{
    UINT32 i = 0;
    for(i = 0; i < MAX_RFCHAN_NUM; i++)
    {
        paVibasUpdate[i] = 0;   
    }
    
}
VOID vibasenable()
{
    UINT32 i = 0;
    for(i = 0; i < MAX_RFCHAN_NUM; i++)
    {
        paVibasUpdate[i] = 1;   
    }
}
#endif

VOID ShowPaDacGridVolt(UINT32 ulStaRfChnl, UINT32 ulEndRfChnl)
{
    INT32 iPaGirdVolt = 0;
    INT32 iDefDacVolt = 0;
    UINT32 ulChnlIdx = 0;
    UINT32 ulChnlMin = 0;
    UINT32 ulChnlMax = 0;
    UINT32 ulRecordSum = 0;
    UINT32 ulRecordIdx = 0;
    UINT32 ulPaRfChnnl = 0;
    UINT32 ulPaSubChnl = 0;
    UINT32 ulPaChipIdx = 0;
    UINT32 ulFuncRet = BSP_OK;
    UINT32 vbiasType = 0;
    UINT32 classNumIdx = 0;
    T_PaDacSetCaliData *ptPaDacData = NULL;
    T_PaDacSetCaliPath *ptPaCaliPath = NULL; 
    T_PaDacSetGridVoltRecord *ptRecord = NULL;

    ptPaDacData  = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    if (NULL == ptPaDacData)
    {
        RedirPrintf("%s>>Error! TxRfCh'%2d~%2d pPaDacData NULL!\n",
               __FUNCTION__, ulStaRfChnl, ulEndRfChnl);
        return;
    }
    ptPaCaliPath = ptPaDacData->pCaliPath[0];
    if (NULL == ptPaCaliPath)
    {
        RedirPrintf("%s>>Error! TxRfCh'%2d~%2d pPaCaliPath NULL!\n",
               __FUNCTION__, ulStaRfChnl, ulEndRfChnl);
        return;
    }

    ulChnlMin = ulStaRfChnl;
    ulChnlMax = max(ulStaRfChnl, ulEndRfChnl);
    ulChnlMax = min(ulChnlMax + 1, BspGetTxChannel());
    for (ulChnlIdx = ulChnlMin; ulChnlIdx < ulChnlMax; ulChnlIdx++)
    {

        classNumIdx = BspGetPaDacClassNumIdx(ptPaDacData, ulChnlIdx);
        if (ptPaDacData->pCaliPath[classNumIdx] == NULL)
        {
            continue;
        }
        /* 解析后的paChan通道数据 */
        ptRecord = ptPaDacData->pCaliPath[classNumIdx][ulChnlIdx].ptRecord;
        ulRecordSum = ptPaDacData->pCaliPath[classNumIdx][ulChnlIdx].ulRecordNum;
        if (NULL == ptRecord)
        {
            RedirPrintf("%s>>Error! TxRfCh'%d RecordSum'%d ptRecord NULL!\n",
                    __FUNCTION__, ulChnlIdx, ulRecordSum);
            continue;
        }
        if (0 == ulRecordSum)
        {
            RedirPrintf("%s>>TxRfCh'%d RecordSum==%d Error!!\n",
                    __FUNCTION__, ulChnlIdx, ulRecordSum);
            continue;
        }

        for (ulRecordIdx = 0; ulRecordIdx < ulRecordSum; ulRecordIdx++)
        {
            if (NULL != ptRecord)
            {
                iPaGirdVolt = 0;
                ulPaRfChnnl = ptRecord->ulPaChan;
                ulPaChipIdx = ptRecord->ulDacPhyIndex;
                ulPaSubChnl = ptRecord->ulDacChanIndex;
                iDefDacVolt = ptRecord->ulGridVoltDataDef;
                vbiasType = ptRecord->ulGridVoltType;
                ulFuncRet = BspGetPaGridVoltFix(ulChnlIdx, vbiasType,ulPaSubChnl, &iPaGirdVolt);
                RedirPrintf("TxRfCh'%d PaChnl'%d vbiasType'%2d DacPath'%2d Chip'%d Volt[%d](mv)= Def'%-5d RdBack'%-5d returnValue'%d \n",
                        ulChnlIdx, ulPaRfChnnl, vbiasType,ulPaSubChnl, ulPaChipIdx, ulRecordIdx,
                        iDefDacVolt, iPaGirdVolt,ulFuncRet);
            }
            else
            {
                dbgErr("%s>>Error! TxRfCh'%d Record(Sum'%d Idx'%d) ptRecord NULL!\n",
                       __FUNCTION__, ulChnlIdx, ulRecordSum, ulRecordIdx);
            }

            ptRecord++;
        }
    }

    return;
}

UINT32 BspGetPaGirdValByType(UINT32 ulRfChnl, UINT32 vbiasType, INT32 *pVal)
{
    UINT32 ulRecordSum = 0;
    UINT32 ulRecordIdx = 0;
    UINT32 ulPaRfChnnl = 0;
    UINT32 ulPaSubChnl = 0;
    UINT32 ulPaChipIdx = 0;
    INT32 iPaGirdVolt = 0;
    INT32 iDefDacVolt = 0;
    UINT32 ulFuncRet = BSP_ERROR;
    T_PaDacSetCaliData *ptPaDacData = NULL;
    T_PaDacSetCaliPath *ptPaCaliPath = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;

    INPUT_POINTER_CHECK(pVal);

    ptPaDacData  = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    if (NULL == ptPaDacData)
    {
        dbgErr("%s>>Error! pPaDacData NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    ptPaCaliPath = ptPaDacData->pCaliPath[0];

    if (NULL == ptPaCaliPath)
    {
        dbgErr("%s>>Error! pPaCaliPath NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(ulRfChnl >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    //ulChnlIdx = ulRfChnl;
    ptRecord    = ptPaDacData->pCaliPath[0][ulRfChnl].ptRecord;
    ulRecordSum = ptPaDacData->pCaliPath[0][ulRfChnl].ulRecordNum;

    if (NULL == ptRecord)
    {
        dbgErr("%s>>Error! TxRfCh'%d RecordSum'%d ptRecord NULL!\n",
                __FUNCTION__, ulRfChnl, ulRecordSum);
        return BSP_ERROR;
    }
    if (0 == ulRecordSum)
    {
        dbgInfo("%s>>TxRfCh'%d RecordSum==%d Error!!\n",
                __FUNCTION__, ulRfChnl, ulRecordSum);
        return BSP_ERROR;
    }

    for (ulRecordIdx = 0; ulRecordIdx < ulRecordSum; ulRecordIdx++)
    {
        iPaGirdVolt = 0;
        ulPaRfChnnl = ptRecord->ulPaChan;
        ulPaChipIdx = ptRecord->ulDacPhyIndex;
        ulPaSubChnl = ptRecord->ulDacChanIndex;
        //coverity[cert_int31_c_violation:SUPPRESS]
        iDefDacVolt = ptRecord->ulGridVoltDataDef;
        if(vbiasType == ptRecord->ulGridVoltType)
        {
            ulFuncRet = BspGetPaGridVoltFix(ulRfChnl, vbiasType,ulPaSubChnl, &iPaGirdVolt);
            *pVal = iPaGirdVolt;
            dbgInfoEx("TxRfCh'%d PaChnl'%d vbiasType'%2d DacPath'%2d Chip'%d Volt[%d](mv)= Def'%-5d RdBack'%-5d returnValue'%d \n",
                    ulRfChnl, ulPaRfChnnl, vbiasType,ulPaSubChnl, ulPaChipIdx, ulRecordIdx,
                                    iDefDacVolt, iPaGirdVolt,ulFuncRet);
            break;
        }
        ptRecord++;
    }

    return ulFuncRet;
}

/**************************************************************************
 * 函数名称: SetPaDacGridByVbiastype
 * 功能描述: 调整栅压carier、dvier和peak值
 * 输入参数: startChan：起始通道
 *           endChan：接收通道
 *           vbiasType：0：carier，1：driver，2：peak
 *           adjustVal：调整量，单位（MV）
 * 输出参数: 无
 * 返 回 值:  无
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2022年1月06日                   殷嘉宾创建
 **************************************************************************/
static void SetPaDacGridByVbiastype(UINT32 startChan, UINT32 endChan, UINT32 vbiasType, INT32 adjustVal)
{
    UINT32 ret = BSP_ERROR;
    INT32 val = 0;
    INT32 dacVolt = 0;
    UINT32 dacChan = 0;
    UINT32 recId = 0;
    UINT32 chanMin = 0;
    UINT32 chanMax = 0;
    UINT32 chan = 0;


    chanMin = startChan;
    chanMax = max(startChan, endChan);
    chanMax = min(chanMax + 1, BspGetTxChannel());

    for (chan = chanMin; chan < chanMax; chan++)
    {
        BspSetVibasDisable(chan);

        ret = BspGetPaGirdValByType(chan, vbiasType, &val);
        if (ret != BSP_OK)
        {
            dbgErr("%s>>BspGetPaGirdValByType Error! chan: %d vbiasType: %d,ret: %d \n",
                            __FUNCTION__, chan, vbiasType, ret);
            continue;
        }
        ret = BspGetDacChan(chan, vbiasType, &dacChan, &recId);
        if (ret != BSP_OK)
        {
            dbgErr("%s>>BspGetPaGirdValByType Error! chan: %d vbiasType: %d,ret: %d \n",
                            __FUNCTION__, chan, vbiasType, ret);
            continue;
        }
        //coverity[cert_int32_c_violation:SUPPRESS]
        dacVolt = val + adjustVal;
        dbgInfoEx("%s>>chan: %d vbiasType: %d,dacChan: %d, dacVolt: %d, val: %d, adjustVal: %d \n",
                                __FUNCTION__, chan, vbiasType, dacChan, dacVolt, val, adjustVal);
        ret = BspSetPaGridVoltFix(chan, vbiasType, dacChan, dacVolt);
        if (ret != BSP_OK)
        {
            dbgErr("%s>>BspGetPaGirdValByType Error! chan: %d vbiasType: %d,ret: %d \n",
                            __FUNCTION__, chan, vbiasType, ret);
            continue;
        }
    }
}

#ifdef BUILD_WITH_OM_FUNC
/*A99不可用*/
VOID showpagridvolt(UINT32 loopStart,UINT32 loopEnd,UINT32 chanStart,UINT32 chanEnd)
{
    INT32 sVoltData = 0;
    UINT32 ulLoopCnt = 0;
    UINT32 ulChanCnt = 0;
    for(ulLoopCnt=loopStart;ulLoopCnt<=loopEnd;ulLoopCnt++)
    {
        for(ulChanCnt=chanStart;ulChanCnt<=chanEnd;ulChanCnt++)
        {
            BspGetPaGridVolt(ulLoopCnt, ulChanCnt, &sVoltData);
            dbgInfo("%s>>Loop %d,Chan %d,Volt %d\n",__FUNCTION__,ulLoopCnt,ulChanCnt,sVoltData);
        }
    }
}
#endif

UINT32 prnPaDacSetFile(UINT32 paChan)
{
    T_PaDacSetCaliData  *ptData = NULL;
    T_PaDacSetGridVoltRecord *ptRecord = NULL;
    UINT32 idx = 0;
    UINT32 loop = 0;

    ptData = (T_PaDacSetCaliData *)_BspGetCalibData(TBL_KIND_OF_PADACSET, 0);
    INPUT_POINTER_CHECK(ptData);
    INPUT_POINTER_CHECK(ptData->pCaliPath[0]);

    /* 解析后的paChan通道数据 */
    ptRecord = ptData->pCaliPath[0][paChan].ptRecord;
    INPUT_POINTER_CHECK(ptRecord);

    dbgInfo("Ver:%d,\nPathNum:%d,\nDate:%s,\nOperator:%s,\nChecker:%s\n",
        ptData->tComHeader.ulVer,
        ptData->tComHeader.ulPathNum,
        ptData->tComHeader.aucDate,
        ptData->tComHeader.aucOperator,
        ptData->tComHeader.aucChecker);

    dbgInfo("DacNum:%d,\nGridVoltN:%d  %d,\nClassNum:%d\n",
        ptData->tHeader.ulDacNum,
        ptData->tHeader.aGridVoltN[0],
        ptData->tHeader.aGridVoltN[1],
        ptData->tHeader.ulClassNum);
    dbgInfo("DacPath:");
    for(idx=0;idx<TBL_PA_DAC_MAX_NUM;idx++)
    {
        dbgInfo("%d  ",ptData->tHeader.ulDacPath[idx]);
    }

    dbgInfo("\nPathLoadFlag=%d, RecordNum=%d\n",ptData->pCaliPath[0][paChan].ulPathLoadFlag,ptData->pCaliPath[0][paChan].ulRecordNum);

    for (idx = 0; idx < ptData->pCaliPath[0][paChan].ulRecordNum; idx++)
    {
        dbgInfo("PaChan[%d] DacPhyIndex[%d] DacChanIndex[%d] GridVoltType[%d]\n",
            ptRecord->ulPaChan,
            ptRecord->ulDacPhyIndex,
            ptRecord->ulDacChanIndex,
            ptRecord->ulGridVoltType);
        dbgInfo("GridVoltDataDef:%d\nGridVoltTempFixDef:%d\nGridVoltRange:%d~%d\n",
            ptRecord->ulGridVoltDataDef,   /* 基准电压 */
            ptRecord->lGridVoltTempFixDef, /* 基准温度 */
            ptRecord->ulGridVoltLower,
            ptRecord->ulGridVoltUpper);
        dbgInfo("PointAndCoefficient:\n");
        for(loop=0;loop<TBL_PA_DAC_SET_ITEM;loop++)
        {
            dbgInfo("%d\t",ptRecord->lPointAndCoefficient[loop]);
            if(0==(loop+1)%5)
            {
                dbgInfo("\n");
            }
        }

        ptRecord++;
    }
    return BSP_OK;
}

UINT32 BspGetPaGridVoltTempComp(UINT32 paChan, UINT32 vbiasType, INT32 *pTempComp)
{
    INPUT_POINTER_CHECK(pTempComp);

    if (paChan >= BSP_MAX_TX_CHAN || vbiasType >= VIBAS_TYPE_NUM)
    {
        return BSP_ERROR;
    }
    *pTempComp = s_paGirdVoltTempComp[paChan][vbiasType];
    dbgInfoEx("paChan= %d,vbiasType = %d, pVolt = %d\n", paChan, vbiasType, *pTempComp);

    return BSP_OK;
}

UINT32 BspSetPaGridVoltTempComp(UINT32 paChan, UINT32 vbiasType, INT32 tempComp)
{
    if (paChan >= BSP_MAX_TX_CHAN || vbiasType >= VIBAS_TYPE_NUM)
    {
        return BSP_ERROR;
    }
    s_paGirdVoltTempComp[paChan][vbiasType] = tempComp;

    return BSP_OK;
}

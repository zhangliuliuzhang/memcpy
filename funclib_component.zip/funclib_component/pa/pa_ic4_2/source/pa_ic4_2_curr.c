/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_c_curr.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 : 190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件

*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "boardid.h"
#include "chnmap_a.h"
#include "rruinfo.h"
#include "devdrv_adc.h"
#include "pa_ic4_2_curr.h"
#include "pacommon.h"
#include "rftable_pacurrentcali.h"
#include "funccommon.h"

#define WT_AMC783X_ADC_TRIGGER                   0xC0
#define WT_AMC783X_ADC_CURRENT_L                 0x40
#define PACURR_MAXNUM                            10


static UINT32  s_setReadPaCurrFlag = 0;
T_PaPmosCfgInfo s_paPMosChanInfo = {0};
static FUNC_GetSlavePaCurrAdVal pGetSlavePaCurrAdVal = NULL;

T_PaPmosCfgInfo* BspGetPaPmosChanCfg(VOID)
{ 
	return &s_paPMosChanInfo;    
}

UINT32 BspSetReadPaCurrFlag(UINT32 flag)
{
    s_setReadPaCurrFlag = flag;
    return BSP_OK;
}

UINT32 BspGetReadPaCurrFlag(VOID)
{
    return s_setReadPaCurrFlag;
}

UINT32 BspSetPaPmosChanCfg(T_PaPmosChanInfo* pPaPara,UINT32 cfgNum)
{ 
    s_paPMosChanInfo.pPara = pPaPara;
    s_paPMosChanInfo.num   = cfgNum;
	return BSP_OK;    
}

UINT32 BspPaChanToPmosChan(UINT32 pa, UINT32* pmos)
{
    T_PaPmosCfgInfo  *pPaCfg  = NULL;
    T_PaPmosChanInfo *pPaInfo = NULL;
    UINT32 idx                = 0;
    INPUT_POINTER_CHECK(pmos);
    
    pPaCfg = BspGetPaPmosChanCfg();
    if(NULL != pPaCfg->pPara)
    {
        for(idx = 0; idx < pPaCfg->num; idx++)
        {
            pPaInfo = &(pPaCfg->pPara[idx]);
            
            dbgInfoEx("num'%d,idx'%d,pa'%d,pmos'%d\n",pPaCfg->num,idx,
                pPaInfo->dacInfo[E_PA_PMOS_RF_CHAN],pPaInfo->dacInfo[E_PA_PMOS_PROTECT_CHAN]);
            if(pa == pPaInfo->dacInfo[E_PA_PMOS_RF_CHAN])
            {
                *pmos = pPaInfo->dacInfo[E_PA_PMOS_PROTECT_CHAN];
                break;
            }
        }
        if(idx >= pPaCfg->num)
        {
            return BSP_ERROR;
        }
        return BSP_OK;
    }
    return BSP_ERROR;
}

UINT32 BspGetPaCurr(UINT32 paChan, UINT32 adc, INT32 *pCurr, UINT32 *pRegVal)
{
    INT32  iPaCurr                   = 0;
    UINT32 ulAdcVal                = 0;   
    UINT32 ulDevId = 0;
    char   ucNameBuf[PA_PARA_LENGTH] = {0};
    UINT32 funcRet0 = BSP_OK;
    UINT32 funcRet1 = BSP_OK;
    INT32  lSnpRet =0;
    
    lSnpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "Curr%d", paChan);
    SNPRINTF_S_CHECK(lSnpRet,sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);  
    
    funcRet0 = BspGetAdcValue(ulDevId,0,&ulAdcVal);
    if (BSP_OK != funcRet0)
    {
        dbgErr("%s>>PaCh'%d DevId'%d GetPaAdcValue Error! Ret= 0x%X\n",
               __FUNCTION__, paChan, ulDevId, funcRet0);
        funcRet0 = BSP_ERROR;        
    }
    funcRet1 = BspGetAdcCurrent(ulDevId,0,&iPaCurr);
    if (BSP_OK != funcRet1)
    {
        dbgErr("%s>>PaCh'%d DevId'%d GetPaCurrent Error! Ret= 0x%X\n",
               __FUNCTION__, paChan, ulDevId, funcRet1);
         funcRet1 = BSP_ERROR;        
    }        
    dbgInfoEx("%s>>PaCh'%d DevId'%d GetPaCurrent Suc ! AdcVal = %d;Curr = %d\n",
               __FUNCTION__, paChan, ulDevId, ulAdcVal,iPaCurr);
    if((pCurr==NULL)&&(pRegVal==NULL))
    {
         dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);
         return BSP_ERROR;
    }   
    if((pRegVal!=NULL)&&(funcRet0==BSP_OK))
    {
        *pRegVal = ulAdcVal;
    }
     if((pCurr!=NULL)&&(funcRet1==BSP_OK))
    {
        *pCurr = iPaCurr;
    }
    return (funcRet0)|(funcRet1);
}

UINT32 BspGetPaAdcVal(UINT32 paChan,UINT32 *pRegVal)
{
    char   ucNameBuf[PA_PARA_LENGTH] = {0};
    UINT32 ulDevId = 0;
    UINT32 ulAdcVal  = 0;       
    UINT32 funcRet0 = BSP_OK;
    INT32  lSnpRet = 0;

    if(pRegVal==NULL)
    {
        dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    lSnpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "Curr%d", paChan);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);  
    
    if (BSP_OK != BspGetAdcValue(ulDevId,0,&ulAdcVal))
    {
        dbgErr("%s>>PaCh'%d DevId'%d GetPaAdcValue Error! Ret= 0x%X\n",
               __FUNCTION__, paChan, ulDevId, funcRet0);
        return BSP_ERROR;        
    }
    *pRegVal = ulAdcVal;
    return BSP_OK;
}

UINT32 BspGetPaAdcValByAdcPath(UINT32 paChan, UINT32 adcChn, UINT32 *pRegVal)
{
    char ucNameBuf[PA_PARA_LENGTH] = {0};
    UINT32 ulDevId = 0;
    UINT32 ulAdcVal  = 0;       
    UINT32 funcRet0 = BSP_OK;
    INT32  lSnpRet = 0;

    INPUT_POINTER_CHECK(pRegVal);

    lSnpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "Curr%d", paChan);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);  
    
    if (BSP_OK != BspGetAdcValueByAdcPath(ulDevId, adcChn, &ulAdcVal))
    {
        dbgErr("[%s] paChan'%d, ulDevId'%d, GetPaAdcValue Error! Ret= 0x%X\n",
               __FUNCTION__, paChan, ulDevId, funcRet0);
        return BSP_ERROR;        
    }

    *pRegVal = ulAdcVal;
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
VOID showpacurr(UINT32 fisrtPa, UINT32 lastPa)
{
    INT32  curr   = 0;
    UINT32 regVal = 0;
    UINT32 ulChnlIdx = 0;
    UINT32 ulChnlMin = 0;
    UINT32 ulChnlMax = 0;
    UINT32 ulFuncRet = BSP_OK;
    UINT32 adc       = 0;
    UINT32 chanTmp   = 0;
    
    ulChnlMin = fisrtPa;
    ulChnlMax = max(fisrtPa, lastPa);
    ulChnlMax = min(ulChnlMax + 1, BspGetTxChannel());
    for (ulChnlIdx = ulChnlMin; ulChnlIdx < ulChnlMax; ulChnlIdx++)
    {
        if(ulChnlIdx >= BspGetTxChanNum()/2)
        {
            chanTmp = ulChnlIdx % (BspGetTxChanNum()/2);
            adc     = (0 == chanTmp / 2) ? 1:0;
        }
        else
        {
            adc = ulChnlIdx / 2;
        }
        ulFuncRet = BspGetPaCurr(ulChnlIdx,adc,&curr,&regVal);
        
        if (BSP_OK == ulFuncRet)
        {
            dbgInfo("[%s]TxRfCh'%2d PaCurr Get OK: curr = %d\n",__FUNCTION__, ulChnlIdx, curr);
        }
        else
        {
            dbgInfo("[%s]TxRfCh'%2d PaCurr Get Error! Ret= 0x%X\n",__FUNCTION__, ulChnlIdx, ulFuncRet);
        }
    }

}

VOID rdpacurr(UINT32 paChan)
{
    INT32  curr    = 0;
    UINT32 regVal  = 0;
    UINT32 adc     = 0;
    UINT32 chanTmp = 0;
    if(paChan >= BspGetTxChanNum()/2)
    {
        chanTmp = paChan % (BspGetTxChanNum()/2);
        adc     = (0 == chanTmp / 2) ? 1:0;
    }
    else
    {
        adc = paChan / 2;
    }
    BspGetPaCurr(paChan,adc,&curr,&regVal);
    dbgInfo("pa:%d curr:%d\n",paChan,curr);
}
VOID showpaadcval(UINT32 fisrtPa, UINT32 lastPa)
{
    INT32  curr   = 0;
    UINT32 regVal = 0;
    UINT32 ulChnlIdx = 0;
    UINT32 ulChnlMin = 0;
    UINT32 ulChnlMax = 0;
    UINT32 ulFuncRet = BSP_OK;
    UINT32 adc       = 0;
    
    ulChnlMin = fisrtPa;
    ulChnlMax = max(fisrtPa, lastPa);
    ulChnlMax = min(ulChnlMax + 1, BspGetTxChannel());
    for (ulChnlIdx = ulChnlMin; ulChnlIdx < ulChnlMax; ulChnlIdx++)
    {
        ulFuncRet = BspGetPaCurr(ulChnlIdx,adc,&curr,&regVal);
        
        if (BSP_OK == ulFuncRet)
        {
            dbgInfo("[%s]TxRfCh'%2d PaAdcValue Get OK: AdcVal = %d\n",__FUNCTION__, ulChnlIdx, regVal);
        }
        else
        {
            dbgInfo("[%s]TxRfCh'%2d PaAdcValue Get Error! Ret= 0x%X\n",__FUNCTION__, ulChnlIdx, ulFuncRet);
        }
    }

}

VOID rdpaadcval(UINT32 paChan)
{
    INT32  curr    = 0;
    UINT32 regVal  = 0;
    UINT32 adc     = 0;
    
    BspGetPaCurr(paChan,adc,&curr,&regVal);
    dbgInfo("pa:%d adcval:%d\n",paChan,regVal);
}
UINT32 prnpaadacfg(VOID)
{
    T_Pa_AdaSocInfo *paAdaSocInfo = NULL;  
    UINT32 chanCnt = 0;

    paAdaSocInfo = (T_Pa_AdaSocInfo *)BspGetPaAdaCfg();
    if(paAdaSocInfo!=NULL)
    {
        dbgInfo("%s>>chanNum %d\n",__FUNCTION__,paAdaSocInfo->chanNum);
        for(chanCnt=0;chanCnt<paAdaSocInfo->chanNum;chanCnt++)
        {
            dbgInfo("[%d]PaChan %d,PaFixChnl %d\n",chanCnt,paAdaSocInfo->paAdaChanInfo[chanCnt].paAdaChan,paAdaSocInfo->paAdaChanInfo[chanCnt].paAdaFixChan);
        }
    }
    else
    {
        dbgInfo("%s>>paAdaSocInfo is NULL !\n",__FUNCTION__);
    }

    return BSP_OK;
}
#endif

/*****************************************************************************
 *  函数名称   : _BspGetPaCurrDate(*)
 *  功能描述   : 获取功放电流校准表值，
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : pachan    - 通道号
            VbiasType    - dac驱动源类型
 *  输出参数   : ptReData       - 电流校准表行值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10229672@2019-1-19 16:36 创建
 *----------------------------------------------------------------------------
 *----------------------------------------------------------------------------
 *----------------------------------------------------------------------------*/

UINT32 _BspGetPaCurrDate(UINT32 pachan, UINT32 VbiasType, T_PaCurAdRecord *ptReData)
{
	UINT32 retVal = BSP_OK;
	UINT32 ulLoop   = 0;
    UINT32 portId = 0;
    UINT32 subPortSw = 0;
    UINT32 tblIdx = 0;
    UINT32 bspChn = 0;
    UINT32 slaveChn = 0;
	T_PaCurCali ptRecord ;
	T_PaCurCaliData *ptData = NULL;
	T_PaCurAdRecord *ptReDataTemp = NULL;

    INPUT_POINTER_CHECK(ptReData);

    /* T+F例外处理 */
    if(1 == s_setReadPaCurrFlag)
    {
        pachan = 8 + pachan;
    }
    /* r9124特殊处理 */
    if(2 == s_setReadPaCurrFlag)
    {
        subPortSw = BspBoardGetSubPortSw();
        BspGetBspChnByPaChn(pachan, TX, &bspChn);
        BspGetPortIdByBspChn(bspChn, TX, &portId);
        if((0xf == portId) || ((1 == subPortSw) && (0 == portId)))    /* r9124母端只用0表，4T+4T形态下端口0属于母端 */
        {
            tblIdx = 0;
        }
        else
        {
            BspGetPortSlaveChnByBspChn(bspChn, TX, &slaveChn);
            dbgInfoEx("%s>>portId=%d,pachn=%d,bspchn=%d,slaveChn=%d \n", __FUNCTION__, portId, pachan, bspChn, slaveChn);
            pachan = slaveChn;
            tblIdx = portId + 2;
        }
        dbgInfoEx("%s>>subPortSw=%d,pachn=%d,bspchn=%d,tblIdx=%d \n", __FUNCTION__, subPortSw, pachan, bspChn, tblIdx);
        ptData = (T_PaCurCaliData *)BspGetPaCurrentCalibDataByIndex(tblIdx);
    }
    else
    {
        ptData = (T_PaCurCaliData *)_BspGetPaCurrentCalibData();
    }

	INPUT_POINTER_CHECK(ptData);

	if(TBL_LOAD_SUCC !=ptData->tPaCurCaliPath.tCurCali.ulCurAdLoadFlag)
	{
		dbgInfoEx("%s: PaCurrentCali.txt not load!\n", __FUNCTION__);
		return  BSP_ERROR;
	}
	/* 解析后的paChan通道数据*/
	ptRecord = ptData->tPaCurCaliPath.tCurCali;
	ptReDataTemp = ptRecord.ptCurAdRecord;

	for (ulLoop = 0; ulLoop < ptData->tHeader.ulnValue[0]; ulLoop++)
	{
		if((pachan == ptReDataTemp->ulPaChan) && (VbiasType == ptReDataTemp->ulVbiasType))
		{
			*ptReData = *ptReDataTemp;
			break;
		}
		ptReDataTemp++;
	}
	return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetPaCurrDate
 *  功能描述   : 获取功放电流校准表值，
 *  输入参数   : pachan - 通道号
                adcChan - ADC通道号
                VbiasType - dac驱动源类型
 *  输出参数   : ptReData - 电流校准表行值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------*/
UINT32 BspGetPaCurrDate(UINT32 pachan, UINT32 adcChan, UINT32 VbiasType, T_PaCurAdRecord *ptReData)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulLoop   = 0;
    UINT32 portId = 0;
    UINT32 subPortSw = 0;
    UINT32 tblIdx = 0;
    UINT32 bspChn = 0;
    UINT32 slaveChn = 0;
    T_PaCurCali ptRecord = {0};
    T_PaCurCaliData *ptData = NULL;
    T_PaCurAdRecord *ptReDataTemp = NULL;

    INPUT_POINTER_CHECK(ptReData);

    /* T+F例外处理 */
    if(1 == BspGetReadPaCurrFlag())
    {
        pachan = 8 + pachan;
    }
    /* r9124特殊处理 */
    if(2 == BspGetReadPaCurrFlag())
    {
        subPortSw = BspBoardGetSubPortSw();
        BspGetBspChnByPaChn(pachan, TX, &bspChn);
        BspGetPortIdByBspChn(bspChn, TX, &portId);
        if((0xf == portId) || ((1 == subPortSw) && (0 == portId)))    /* r9124母端只用0表，4T+4T形态下端口0属于母端 */
        {
            tblIdx = 0;
        }
        else
        {
            BspGetPortSlaveChnByBspChn(bspChn, TX, &slaveChn);
            dbgInfo("%s>>portId=%d, pachn=%d, bspchn=%d, slaveChn=%d \n", __FUNCTION__, portId, pachan, bspChn, slaveChn);
            pachan = slaveChn;
            tblIdx = portId + 2;
        }
        dbgInfo("%s>>subPortSw=%d, pachn=%d, bspchn=%d, tblIdx=%d \n", __FUNCTION__, subPortSw, pachan, bspChn, tblIdx);
        ptData = (T_PaCurCaliData *)BspGetPaCurrentCalibDataByIndex(tblIdx);
    }
    else
    {
        ptData = (T_PaCurCaliData *)_BspGetPaCurrentCalibData();
    }

    INPUT_POINTER_CHECK(ptData);

    if(TBL_LOAD_SUCC != ptData->tPaCurCaliPath.tCurCali.ulCurAdLoadFlag)
    {
        dbgInfo("%s: PaCurrentCali.txt not load!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    /* 解析后的paChan通道数据*/
    ptRecord = ptData->tPaCurCaliPath.tCurCali;
    ptReDataTemp = ptRecord.ptCurAdRecord;
    INPUT_POINTER_CHECK(ptReDataTemp);

    for (ulLoop = 0; ulLoop < ptData->tHeader.ulnValue[0]; ulLoop++)
    {
        if((pachan == ptReDataTemp->ulPaChan) && (VbiasType == ptReDataTemp->ulVbiasType) && (adcChan == ptReDataTemp->ulAdcPath))
        {
            *ptReData = *ptReDataTemp;
            break;
        }
        ptReDataTemp++;
    }
    return retVal;
}

/*获取子端电流Ad值*/
UINT32 BspGetSlavePaCurrAdValCallBack(FUNC_GetSlavePaCurrAdVal pFunc)
{
    INPUT_POINTER_CHECK(pFunc);

    pGetSlavePaCurrAdVal = pFunc;
    return BSP_OK;
}

UINT32 BspSlavePaCurrAdValGet(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, UINT32 *pAdVal)
{
    INPUT_POINTER_CHECK(pAdVal);

    if(NULL != pGetSlavePaCurrAdVal)
    {
        return pGetSlavePaCurrAdVal(portId, pwrIndex, adcChan, pAdVal);
    }

    return BSP_OK;
}

UINT32 _BspGetPaAdVal(UINT32 currNo, UINT32 adcPath, UINT32 *paadval)
{
    char   ucNameBuf[PA_PARA_LENGTH] = {0};
    UINT32 ulDevId = 0;
    UINT32 ulAdcVal  = 0;
    UINT32 ulAdValSum = 0;
    UINT32 funcRet0 = BSP_OK;
    UINT32 ulLoop = 0;
    UINT32 retVal = 0;
    INT32  snpRet=0;
    UINT32 subPortSw = 0;
    UINT32 bspChn = 0;
    UINT32 portId = 0;
    UINT32 currAdVal = 0;

    if(paadval==NULL)
    {
        dbgErr("%s:Input Pointer is NULL!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    /* r9124特殊处理 */
    if(2 == s_setReadPaCurrFlag)
    {
        subPortSw = BspBoardGetSubPortSw();
        BspGetBspChnByPaChn(currNo, TX, &bspChn);
        BspGetPortIdByBspChn(bspChn, TX, &portId);
        dbgInfoEx("%s>>subPortSw=%d,pachn=%d,bspchn=%d,portId=%d \n", __FUNCTION__, subPortSw, currNo, bspChn, portId);
        if((0xf == portId) || ((1 == subPortSw) && (0 == portId)))    /* r9124母端通道走正常查询流程，4T+4T形态下端口0属于母端 */
        {
            dbgInfoEx("%s>>portId=%d,subPortSw=%d\n", __FUNCTION__, portId, subPortSw);
        }
        else
        {
            retVal = BspSlavePaCurrAdValGet(portId, 0, adcPath, &currAdVal);
            *paadval = currAdVal;
            dbgInfoEx("%s>>adcPath=%d,paadval=%d,retVal=%d\n", __FUNCTION__, adcPath, currAdVal, retVal);
            return retVal;
        }
    }

    snpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "Curr%d", currNo);
    SNPRINTF_S_CHECK(snpRet,sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);

	for(ulLoop=0; ulLoop<PACURR_MAXNUM; ulLoop++)
	{
		retVal |= BspGetAdcValueByAdcPath(ulDevId,adcPath,&ulAdcVal);
		ulAdValSum += ulAdcVal;
		BspSysMsDelay(10);
	}
	if(BSP_OK != retVal)
    {
        dbgErr("%s>>PaCh'%d DevId'%d GetPaAdcValue Error! Ret= 0x%X\n",
               __FUNCTION__, 0, ulDevId, funcRet0);
        return BSP_ERROR;
    }
    *paadval = ulAdValSum/PACURR_MAXNUM;
    return BSP_OK;

}

/*****************************************************************************
 *  函数名称   : _BspGetPaCurrValueTwoPonit(*)
 *  功能描述   : 获取功放电流校准表值，
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulAdValue    - AD值
            ptReData 	 - 校准表数据
 *  输出参数   : pcurrval     - 电流校准表行值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10229672@2019-1-19 16:36 创建
 *----------------------------------------------------------------------------*/
UINT32 _BspGetPaCurrValueTwoPonit(UINT32 ulAdValue,UINT32 delt, T_PaCurAdRecord *ptReData, float *pcurrval)
{
	INT32  currCoef = 0;
	INPUT_POINTER_CHECK(ptReData);
	INPUT_POINTER_CHECK(pcurrval);
	if(ulAdValue < ptReData->ulAdVal[1])
	{
		ulAdValue = ulAdValue -delt;  /*delt 为0电流偏移量*/
		if(ulAdValue < ptReData->ulAdVal[0])
		{/*分开判断的意义在于 负数浮点数的除法计算会产生异常大的值*/
            DIV_CHK_PRN_RET(ptReData->ulAdVal[0] - ptReData->ulAdVal[2]);
            currCoef = (INT32)((ptReData->ulCurrent[0] - ptReData->ulCurrent[2])*1000/(ptReData->ulAdVal[0] - ptReData->ulAdVal[2]));  /*用0电流算*/
			*pcurrval = ptReData->ulCurrent[0] - ( ptReData->ulAdVal[0] -ulAdValue)*currCoef/1000.0;  /*具体折算的时候需要按减去偏移之后的ad值计算*/
		}
		else
		{
            DIV_CHK_PRN_RET(ptReData->ulAdVal[1] - ptReData->ulAdVal[0]);
            currCoef = (INT32)((ptReData->ulCurrent[1] - ptReData->ulCurrent[0])*1000/(ptReData->ulAdVal[1] - ptReData->ulAdVal[0])); /*斜率以原始的data计算*/
			*pcurrval = ptReData->ulCurrent[0] + (ulAdValue - ptReData->ulAdVal[0])*currCoef/1000.0;
		}
	}
	else
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[3] - ptReData->ulAdVal[1]);
		currCoef = (INT32)((ptReData->ulCurrent[3] - ptReData->ulCurrent[1])*1000/(ptReData->ulAdVal[3] - ptReData->ulAdVal[1]));
		if(ulAdValue < ptReData->ulAdVal[1])
		{
			*pcurrval = ptReData->ulCurrent[1] - ( ptReData->ulAdVal[1] -ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[1] + (ulAdValue - ptReData->ulAdVal[1])*currCoef/1000.0;
		}
	}

	dbgInfoEx(" %d  %d  %d", ptReData->ulAdVal[1] ,ptReData->ulAdVal[3],currCoef);
	dbgInfoEx("ulAdValue %d currCoef %d *pcurrval %f",ulAdValue ,currCoef, *pcurrval);
	return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : _BspGetPaCurrValueThreePonit(*)
 *  功能描述   : 获取功放电流校准表值，
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulAdValue    - AD值
            ptReData 	 - 校准表数据
 *  输出参数   : pcurrval     - 电流校准表行值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10229672@2019-1-19 16:36 创建
 *----------------------------------------------------------------------------*/
UINT32 _BspGetPaCurrValueThreePonit(UINT32 ulAdValue,UINT32 delt, T_PaCurAdRecord *ptReData, float *pcurrval)
{
	INT32  currCoef = 0;
	INPUT_POINTER_CHECK(ptReData);
	INPUT_POINTER_CHECK(pcurrval);
	if(ulAdValue < ptReData->ulAdVal[1])
	{
		ulAdValue = ulAdValue -delt;  /*delt 为0电流偏移量*/
		if(ulAdValue < ptReData->ulAdVal[0])
		{/*分开判断的意义在于 负数浮点数的除法计算会产生异常大的值*/
            DIV_CHK_PRN_RET(ptReData->ulAdVal[0] - ptReData->ulAdVal[3]);
            currCoef = (INT32)((ptReData->ulCurrent[0] - ptReData->ulCurrent[3])*1000/(ptReData->ulAdVal[0] - ptReData->ulAdVal[3])); /*用0电流算*/
			*pcurrval = ptReData->ulCurrent[0] - ( ptReData->ulAdVal[0] -ulAdValue)*currCoef/1000.0;  /*具体折算的时候需要按减去偏移之后的ad值计算*/
		}
		else
		{
            DIV_CHK_PRN_RET(ptReData->ulAdVal[1] - ptReData->ulAdVal[0]);
            currCoef = (INT32)((ptReData->ulCurrent[1] - ptReData->ulCurrent[0])*1000/(ptReData->ulAdVal[1] - ptReData->ulAdVal[0])); /*斜率以原始的data计算*/
			*pcurrval = ptReData->ulCurrent[0] + (ulAdValue - ptReData->ulAdVal[0])*currCoef/1000.0;
		}
	}
	else if(ulAdValue < ptReData->ulAdVal[2])
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[2] - ptReData->ulAdVal[1]);
		currCoef = (INT32)((ptReData->ulCurrent[2] - ptReData->ulCurrent[1])*1000/(ptReData->ulAdVal[2] - ptReData->ulAdVal[1]));
		if(ulAdValue < ptReData->ulAdVal[1])
		{
			*pcurrval = ptReData->ulCurrent[1] - ( ptReData->ulAdVal[1] -ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[1] + (ulAdValue - ptReData->ulAdVal[1])*currCoef/1000.0;
		}
	}
	else /*超过最后一组  使用此组和满电流 有效最大3组  还有两组是0电流和满电流*/
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[4] - ptReData->ulAdVal[2]);
		currCoef = (INT32)((ptReData->ulCurrent[4] - ptReData->ulCurrent[2])*1000/(ptReData->ulAdVal[4] - ptReData->ulAdVal[2]));
		if(ulAdValue < ptReData->ulAdVal[2])
		{
			*pcurrval = ptReData->ulCurrent[2] -(ptReData->ulAdVal[2] - ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[2] + (ulAdValue - ptReData->ulAdVal[2])*currCoef/1000.0;
		}
	}
	dbgInfoEx(" %d  %d  %d %d", ptReData->ulAdVal[1] , ptReData->ulAdVal[2],  ptReData->ulAdVal[4],currCoef);
	dbgInfoEx("ulAdValue %d currCoef %d *pcurrval %f",ulAdValue ,currCoef, *pcurrval);
	return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : _BspGetPaCurrValueFourPonit(*)
 *  功能描述   : 获取功放电流校准表值，
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulAdValue    - AD值
            ptReData 	 - 校准表数据
 *  输出参数   : pcurrval     - 电流校准表行值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10229672@2019-1-19 16:36 创建
 *----------------------------------------------------------------------------*/
UINT32 _BspGetPaCurrValueFourPonit(UINT32 ulAdValue,UINT32 delt, T_PaCurAdRecord *ptReData, float *pcurrval)
{
	INT32  currCoef = 0;
	INPUT_POINTER_CHECK(ptReData);
	INPUT_POINTER_CHECK(pcurrval);

	if(ulAdValue < ptReData->ulAdVal[1])
	{
		ulAdValue = ulAdValue -delt;
		if(ulAdValue < ptReData->ulAdVal[0])
		{
            DIV_CHK_PRN_RET(ptReData->ulAdVal[0] - ptReData->ulAdVal[4]);
            currCoef = (INT32)((ptReData->ulCurrent[0] - ptReData->ulCurrent[4])*1000/(ptReData->ulAdVal[0] - ptReData->ulAdVal[4])); /*用0电流算*/
			*pcurrval = ptReData->ulCurrent[0] - ( ptReData->ulAdVal[0] -ulAdValue)*currCoef/1000.0;
		}
		else
		{
            DIV_CHK_PRN_RET(ptReData->ulAdVal[1] - ptReData->ulAdVal[0]);
            currCoef = (INT32)((ptReData->ulCurrent[1] - ptReData->ulCurrent[0])*1000/(ptReData->ulAdVal[1] - ptReData->ulAdVal[0]));
			*pcurrval = ptReData->ulCurrent[0] + (ulAdValue - ptReData->ulAdVal[0])*currCoef/1000.0;
		}
	}
	else if(ulAdValue < ptReData->ulAdVal[2])
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[2] - ptReData->ulAdVal[1]);
		currCoef = (INT32)((ptReData->ulCurrent[2] - ptReData->ulCurrent[1])*1000/(ptReData->ulAdVal[2] - ptReData->ulAdVal[1]));
		if(ulAdValue < ptReData->ulAdVal[1])
		{
			*pcurrval = ptReData->ulCurrent[1] - ( ptReData->ulAdVal[1] -ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[1] + (ulAdValue - ptReData->ulAdVal[1])*currCoef/1000.0;
		}
	}
	else if(ulAdValue < ptReData->ulAdVal[3])
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[3] - ptReData->ulAdVal[2]);
		currCoef = (INT32)((ptReData->ulCurrent[3] - ptReData->ulCurrent[2])*1000/(ptReData->ulAdVal[3] - ptReData->ulAdVal[2]));
		if(ulAdValue < ptReData->ulAdVal[2])
		{
			*pcurrval = ptReData->ulCurrent[2] -(ptReData->ulAdVal[2] - ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[2] + (ulAdValue - ptReData->ulAdVal[2])*currCoef/1000.0;
		}
	}
	else  /*超过最后一组  使用此组和满电流*/
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[5] - ptReData->ulAdVal[3]);
		currCoef = (INT32)((ptReData->ulCurrent[5] - ptReData->ulCurrent[3])*1000/(ptReData->ulAdVal[5] - ptReData->ulAdVal[3]));
		if(ulAdValue < ptReData->ulAdVal[3])
		{
			*pcurrval = ptReData->ulCurrent[3] -(ptReData->ulAdVal[3] - ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[3] + (ulAdValue - ptReData->ulAdVal[3])*currCoef/1000.0;
		}
	}
	dbgInfoEx(" %d  %d  %d %d %d", ptReData->ulAdVal[1] , ptReData->ulAdVal[2],  ptReData->ulAdVal[3],ptReData->ulAdVal[5],currCoef);
	dbgInfoEx("ulAdValue %d currCoef %d *pcurrval %f",ulAdValue ,currCoef, *pcurrval);
	return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : _BspGetPaCurrValueFivePonit(*)
 *  功能描述   : 获取功放电流校准表值，
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulAdValue    - AD值
            ptReData 	 - 校准表数据
 *  输出参数   : pcurrval     - 电流校准表行值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10229672@2019-1-19 16:36 创建
 *----------------------------------------------------------------------------*/
UINT32 _BspGetPaCurrValueFivePonit(UINT32 ulAdValue,UINT32 delt, T_PaCurAdRecord *ptReData, float *pcurrval)
{
	INT32  currCoef = 0;
	INPUT_POINTER_CHECK(ptReData);
	INPUT_POINTER_CHECK(pcurrval);

	if(ulAdValue < ptReData->ulAdVal[1])
	{
		ulAdValue = ulAdValue -delt;
		if(ulAdValue < ptReData->ulAdVal[0])
		{
            DIV_CHK_PRN_RET(ptReData->ulAdVal[0] - ptReData->ulAdVal[5]);
            currCoef = (INT32)((ptReData->ulCurrent[0] - ptReData->ulCurrent[5])*1000/(ptReData->ulAdVal[0] - ptReData->ulAdVal[5])); /*用0电流算*/
			*pcurrval = ptReData->ulCurrent[0] - ( ptReData->ulAdVal[0] -ulAdValue)*currCoef/1000.0;
		}
		else
		{
            DIV_CHK_PRN_RET(ptReData->ulAdVal[1] - ptReData->ulAdVal[0]);
            currCoef = (INT32)((ptReData->ulCurrent[1] - ptReData->ulCurrent[0])*1000/(ptReData->ulAdVal[1] - ptReData->ulAdVal[0]));
			*pcurrval = ptReData->ulCurrent[0] + (ulAdValue - ptReData->ulAdVal[0])*currCoef/1000.0;
		}
	}
	else if(ulAdValue < ptReData->ulAdVal[2])
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[2] - ptReData->ulAdVal[1]);
		currCoef = (INT32)((ptReData->ulCurrent[2] - ptReData->ulCurrent[1])*1000/(ptReData->ulAdVal[2] - ptReData->ulAdVal[1]));
		if(ulAdValue < ptReData->ulAdVal[1])
		{
			*pcurrval = ptReData->ulCurrent[1] - ( ptReData->ulAdVal[1] -ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[1] + (ulAdValue - ptReData->ulAdVal[1])*currCoef/1000.0;
		}
	}
	else if(ulAdValue < ptReData->ulAdVal[3])
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[3] - ptReData->ulAdVal[2]);
		currCoef = (INT32)((ptReData->ulCurrent[3] - ptReData->ulCurrent[2])*1000/(ptReData->ulAdVal[3] - ptReData->ulAdVal[2]));
		if(ulAdValue < ptReData->ulAdVal[2])
		{
			*pcurrval = ptReData->ulCurrent[2] -(ptReData->ulAdVal[2] - ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[2] + (ulAdValue - ptReData->ulAdVal[2])*currCoef/1000.0;
		}
	}
	else if(ulAdValue < ptReData->ulAdVal[4])
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[4] - ptReData->ulAdVal[3]);
		currCoef = (INT32)((ptReData->ulCurrent[4] - ptReData->ulCurrent[3])*1000/(ptReData->ulAdVal[4] - ptReData->ulAdVal[3]));
		if(ulAdValue < ptReData->ulAdVal[3])
		{
			*pcurrval = ptReData->ulCurrent[3] -(ptReData->ulAdVal[3] - ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[3] + (ulAdValue - ptReData->ulAdVal[3])*currCoef/1000.0;
		}
	}
	else  /*超过最后一组  使用此组和满电流*/
	{
		ulAdValue = ulAdValue -delt;
		DIV_CHK_PRN_RET(ptReData->ulAdVal[6] - ptReData->ulAdVal[4]);
		currCoef = (INT32)((ptReData->ulCurrent[6] - ptReData->ulCurrent[4])*1000/(ptReData->ulAdVal[6] - ptReData->ulAdVal[4]));
		if(ulAdValue < ptReData->ulAdVal[4])
		{
			*pcurrval = ptReData->ulCurrent[4] -(ptReData->ulAdVal[4] - ulAdValue)*currCoef/1000.0;
		}
		else
		{
			*pcurrval = ptReData->ulCurrent[4] + (ulAdValue - ptReData->ulAdVal[4])*currCoef/1000.0;
		}
	}
	dbgInfoEx(" %d  %d  %d %d %d %d", ptReData->ulAdVal[1] , ptReData->ulAdVal[2],  ptReData->ulAdVal[3],  ptReData->ulAdVal[4],  ptReData->ulAdVal[6],currCoef);
	dbgInfoEx("ulAdValue %d currCoef %d *pcurrval %f",ulAdValue ,currCoef, *pcurrval);
	return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : _BspGetPaCurrValue(*)
 *  功能描述   : 获取功放电流校准表值，
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulAdValue    - AD值
            ptReData 	 - 校准表数据
 *  输出参数   : pcurrval     - 电流校准表行值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10229672@2019-1-19 16:36 创建
 *----------------------------------------------------------------------------*/

UINT32 _BspGetPaCurrValue(UINT32 ulAdValue,UINT32 ulAdValue0, T_PaCurAdRecord *ptReData, float *pcurrval)
{
	UINT32 retVal = BSP_OK;
	UINT32 delt = 0;
	UINT32 ulCurrentNum = 0;
	INPUT_POINTER_CHECK(ptReData);
	INPUT_POINTER_CHECK(pcurrval);

	ulCurrentNum = ptReData->ulCurrentNum;  /*实际有效的组数，从第7列开始计数*/
    if(ulAdValue0 != 0)
    {/*ulAdValue0 为当前环境不配置栅压时的ad值 ptReData->ulAdVal[ulCurrentNum]表示的是校准表中0电流（产线校准时不配栅压的ad值） 环境变化 器件老化会导致两者有差异*/
        delt =ulAdValue0 - ptReData->ulAdVal[ulCurrentNum] ;
     }
     else
     {
        delt = 0;
     }

	dbgInfoEx("delt %d,ulAdValue0 %d,ulCurrentNum %d\n",delt,ulAdValue0, ulCurrentNum);
	switch(ulCurrentNum)
	{
		case 2:
			retVal = _BspGetPaCurrValueTwoPonit(ulAdValue,delt, ptReData, pcurrval);
			break;
		case 3:
			retVal = _BspGetPaCurrValueThreePonit(ulAdValue,delt, ptReData, pcurrval);
			break;
		case 4:
			retVal = _BspGetPaCurrValueFourPonit(ulAdValue,delt, ptReData, pcurrval);
			break;
		case 5:
			retVal = _BspGetPaCurrValueFivePonit(ulAdValue,delt, ptReData, pcurrval);
			break;
		default:
			retVal = BSP_ERROR;
			break;
	}
	dbgInfoEx("%s:ulAdValue %u, pcurrval %f \n", __FUNCTION__, ulAdValue, *pcurrval);
	return retVal;
}

/*****************************************************************************
 *  函数名称   : _BspGetPaCurrVal(*)
 *  功能描述   : 获取功放电流校准值，
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : pachan    - 通道号
            VbiasType    - 28V驱动源类型
 *  输出参数   : padval       - 读取ADC原始值
 *  		pcurrval     - 校准后电流值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10229672@2019-1-19 16:36 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaCurrValFix(UINT32 pachan, UINT32 VbiasType,UINT32 adValCurr0, float *pcurrval)
{
	UINT32 ret = BSP_OK;
    UINT32 ulAdValue  = 0;
	T_PaCurAdRecord *ptReDataTemp = NULL;
	INPUT_POINTER_CHECK(pcurrval);

	ptReDataTemp = (T_PaCurAdRecord*)malloc(sizeof(T_PaCurAdRecord));

	if (NULL == ptReDataTemp)
	{
		return BSP_ERROR;
	}

	memset_s(ptReDataTemp, sizeof(T_PaCurAdRecord), 0, sizeof(T_PaCurAdRecord));

	if (BSP_OK != _BspGetPaCurrDate(pachan, VbiasType, ptReDataTemp))
	{
		free(ptReDataTemp);
		dbgInfoEx("%s paChan%u get CurrDate failed\n",__FUNCTION__,pachan);
		return  BSP_ERROR;
	}
	if (BSP_OK != _BspGetPaAdVal(pachan, ptReDataTemp->ulAdcPath, &ulAdValue))
	{
		free(ptReDataTemp);
		dbgInfoEx("%s paChan%u get ulAdValue failed\n",__FUNCTION__,pachan);
		return  BSP_ERROR;
	}
	dbgInfoEx("pachan %d, ptReDataTemp->ulAdcPath %d, ulAdValue %d\n",pachan, ptReDataTemp->ulAdcPath, ulAdValue);
	if (BSP_OK != _BspGetPaCurrValue(ulAdValue,adValCurr0, ptReDataTemp, pcurrval))
	{
		free(ptReDataTemp);
		dbgInfoEx("%s paChan%u _BspGetPaCurrValue  failed\n",__FUNCTION__,pachan);
		return  BSP_ERROR;
	}
	free(ptReDataTemp);
	return ret;
}

/*****************************************************************************
 *  函数名称   : BspGetPaCurrVal
 *  功能描述   : 获取功放电流校准值，
 *  输入参数   : pachan - PA通道号
                adcChan - ADC通道号
                VbiasType - 28V驱动源类型
                adValCurr0 - 当前环境不配置栅压时的ad值
 *  输出参数   : pcurrval - 校准后电流值
 *  返 回 值   : BSP_OK 表示正常，其它表示异常
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaCurrVal(UINT32 pachan, UINT32 adcChan, UINT32 VbiasType, UINT32 adValCurr0, float *pcurrval)
{
    UINT32 ret = BSP_OK;
    UINT32 ulAdValue  = 0;
    T_PaCurAdRecord *ptReDataTemp = NULL;
    INPUT_POINTER_CHECK(pcurrval);

    ptReDataTemp = (T_PaCurAdRecord*)malloc(sizeof(T_PaCurAdRecord));
    INPUT_POINTER_CHECK(ptReDataTemp);
    memset_s(ptReDataTemp, sizeof(T_PaCurAdRecord), 0, sizeof(T_PaCurAdRecord));

    if (BSP_OK != BspGetPaCurrDate(pachan, adcChan, VbiasType, ptReDataTemp))
    {
        free(ptReDataTemp);
        dbgInfoEx("%s paChan%u get CurrDate failed\n",__FUNCTION__,pachan);
        return  BSP_ERROR;
    }

    if (BSP_OK != _BspGetPaAdVal(pachan, ptReDataTemp->ulAdcPath, &ulAdValue))
    {
        free(ptReDataTemp);
        dbgInfoEx("%s paChan%u get ulAdValue failed\n",__FUNCTION__,pachan);
        return  BSP_ERROR;
    }

    dbgInfoEx("pachan %d, ptReDataTemp->ulAdcPath %d, ulAdValue %d\n",pachan, ptReDataTemp->ulAdcPath, ulAdValue);
    if (BSP_OK != _BspGetPaCurrValue(ulAdValue, adValCurr0, ptReDataTemp, pcurrval))
    {
        free(ptReDataTemp);
        dbgInfoEx("%s paChan%u _BspGetPaCurrValue  failed\n",__FUNCTION__,pachan);
        return  BSP_ERROR;
    }

    free(ptReDataTemp);
    return ret;
}

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_fpga_tddrfctrl.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 原始作者 : N/A
* 创建日期 :
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: N/A
* 修改日戳:
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "bspcomm.h"
#include "funccommon_a.h"
#include "pa_ic4_2_ctrl.h"
#include "exprn.h"
#include "chnmap_a.h"
#include "pacommon.h"
#include "regdrv_access.h"
#include "pa_fpga_tddrfctrl.h"


#define CHECK_RF_CHAN_NUM(a) if((a) >= BspGetTxChanNum() || (a) >= CHN_NUM_PER_CHIP)\
                                {dbgErr("%s: input chan num'%d out of range\n", __func__, (a)); return BSP_ERROR;}
UINT32 g_ulSlavePortExistSta[MAX_TX_CHAN] = {0,0,0,0,1,1,1,1};

/*端口子母端切换时需要保存且切换部分开关的状态*/
UINT32 BspUpdateSlavePortExistSta(UINT32 chn, UINT32 portSta)
{
    UINT32  lastSta = 0;

    if(chn >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    lastSta = g_ulSlavePortExistSta[chn];
    if(lastSta != portSta)
    {
        BspSetPaSwitch_Fpga(chn,0); /*切换控制方式了 其他开关也要切 注意这里预期只处理2 3通道*/
        BspSetLnaSwitch_Fpga(chn,0);
    }
    g_ulSlavePortExistSta[chn] = portSta;

    return BSP_OK;
}
UINT32 BspGetSlavePortExistSta(UINT32 chn)
{
    if(chn >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    return g_ulSlavePortExistSta[chn];
}

/************************************pa相关******************************************/
/*****************************************************************************
 * 函数名称: BspSetPaModeCtrl(*)
 * 功能描述: 设置FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 *         : mode - 使能模式, 0: 正常TDD模式, 1: 使能测试模式
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaModeCtrl_Fpga(UINT32 bspChan, UINT32 mode)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 paTddMode   = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_PA_PWR_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_PACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*默认一一对应按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    paTddMode = (SWITCH_TDD_CTRL_MODE == mode) ? 0 : 1;
    funcRet = BspRegBitValWr(difId, regIdx, 0, paTddMode,chnBit,chnBit);

    return funcRet;
}
/*****************************************************************************
 * 函数名称: BspGetPaModeCtrl(*)
 * 功能描述: 获取FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- TDD 模式, 1- FDD 模式, BSP_ERROR- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaModeCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 paTddMode   = SWITCH_TDD_CTRL_MODE;
    UINT32 ctrlMode    = 0;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_PA_PWR_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_PACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &paTddMode);
    ctrlMode = (paTddMode & BIT_SET(chnBit)) ? SWITCH_FDD_CTRL_MODE : SWITCH_TDD_CTRL_MODE;
    dbgInfoEx("bspChan %d regIdx %d chnBit %d paTddMode 0x%x ctrlMode %d\n",bspChan,regIdx,chnBit,paTddMode,ctrlMode);

    return ctrlMode;
}

/*****************************************************************************
 * 函数名称: BspSetPaSwitchCtrl(*)
 * 功能描述: 设置FPGA输出到PA的信号开关
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关, 1: 开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit      = 0;

    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_PATDD_SWITCH;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_PACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegBitValWr(difId, regIdx, 0, sw,chnBit,chnBit);
    dbgInfoEx("bspChan %d regIdx %d chnBit %d sw %d\n",bspChan,regIdx,chnBit,sw);

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetPaSwitch(*)
 * 功能描述: 功放开关设置，开和关，TDD设置
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaSwitch_Fpga(UINT32 bspChan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, bspChan, sw);
    funcRet  = BspSetPaModeCtrl_Fpga(bspChan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetPaSwitchCtrl_Fpga(bspChan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, bspChan, sw);

    return funcRet;
}

UINT32 BspSetPaFddSwitch_Fpga(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);

    funcRet |= BspSetPaSwitchCtrl_Fpga(chan, sw);
    funcRet  = BspSetPaModeCtrl_Fpga(chan, SWITCH_FDD_CTRL_MODE);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspGetPaSwitchCtrl(*)
 * 功能描述: 获取FPGA输出到PA的信号开关
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- 关, 1- 开, BSP_ERROR- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaSwitchCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 paSwCtrl    = PA_SWITCH_OFF;
    UINT32 chnBit      = 0;
    UINT32 swBitOffset = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_PATDD_SWITCH;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_PACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &swBitOffset);
    paSwCtrl = (swBitOffset & BIT_SET(chnBit)) ? PA_SWITCH_ON : PA_SWITCH_OFF;
    dbgInfoEx("bspChan %d chnBit %d swBitOffset 0x%x paSwCtrl %d\n",bspChan,chnBit,swBitOffset,paSwCtrl);

    return paSwCtrl;
}

UINT32 BspGetPaSwitch_Fpga(UINT32 chan)
{
    UINT32 paSwitch = PA_SWITCH_OFF;

    CHECK_RF_CHAN_NUM(chan);
    paSwitch = BspGetPaSwitchCtrl_Fpga(chan);

    return paSwitch;
}
UINT32 fpgapaon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
       BspSetPaSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*pa tdd_fdd*/
UINT32 fpgapaonfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        BspSetPaFddSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}
UINT32 fpgapaoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetPaSwitch_Fpga(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}

/************************************lna相关******************************************/
/*****************************************************************************
 * 函数名称: BspSetLnaModeCtrl(*)
 * 功能描述: 设置FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 *         : mode - 使能模式, 0: 正常TDD模式, 1: 使能测试模式
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaModeCtrl_Fpga(UINT32 bspChan, UINT32 mode)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 lnaTddMode   = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_LNA_PWR_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    lnaTddMode = (SWITCH_TDD_CTRL_MODE == mode) ? 0 : 1;
    funcRet = BspRegBitValWr(difId, regIdx, 0, lnaTddMode,chnBit,chnBit);

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspGetLnaModeCtrl(*)
 * 功能描述: 获取FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- TDD 模式, 1- FDD 模式, BSP_ERROR- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaModeCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 lnaTddMode   = SWITCH_TDD_CTRL_MODE;
    UINT32 ctrlMode    = 0;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_LNA_PWR_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &lnaTddMode);
    ctrlMode = (lnaTddMode & BIT_SET(chnBit)) ? SWITCH_FDD_CTRL_MODE : SWITCH_TDD_CTRL_MODE;
    dbgInfoEx("bspChan %d regIdx %d chnBit %d lnaTddMode 0x%x ctrlMode %d\n",bspChan,regIdx,chnBit,lnaTddMode,ctrlMode);

    return ctrlMode;
}

/*****************************************************************************
 * 函数名称: BspSetLnaSwitchCtrl(*)
 * 功能描述: 设置FPGA输出到Lna的信号开关
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关, 1: 开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_LNATDD_SWITCH;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegBitValWr(difId, regIdx, 0, sw,chnBit,chnBit);
    dbgInfoEx("bspChan %d regIdx %d chnBit %d sw %d\n",bspChan,regIdx,chnBit,sw);

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetLnaSwitch(*)
 * 功能描述: LNA开关设置，开和关，TDD设置
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaSwitch_Fpga(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);
    funcRet  = BspSetLnaModeCtrl_Fpga(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetLnaSwitchCtrl_Fpga(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}

UINT32 BspSetLnaFddSwitch_Fpga(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);

    funcRet |= BspSetLnaSwitchCtrl_Fpga(chan, sw);
    funcRet  = BspSetLnaModeCtrl_Fpga(chan, SWITCH_FDD_CTRL_MODE);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}
/*****************************************************************************
 * 函数名称: BspGetLnaSwitchCtrl(*)
 * 功能描述: 获取FPGA输出到Lna的信号开关
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- 关, 1- 开, BSP_ERROR- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaSwitchCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 swCtrl      = LNA_SWITCH_OFF;
    UINT32 chnBit      = 0;
    UINT32 swBitOffset = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_LNATDD_SWITCH;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNACHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &swBitOffset);
    swCtrl = (swBitOffset & BIT_SET(chnBit)) ? LNA_SWITCH_ON : LNA_SWITCH_OFF;
    dbgInfoEx("bspChan %d chnBit %d swBitOffset 0x%x lnaSwCtrl %d\n",bspChan,chnBit,swBitOffset,swCtrl);

    return swCtrl;
}

UINT32 BspGetLnaSwitch_Fpga(UINT32 chan)
{
    UINT32 lnaSwitch = LNA_SWITCH_OFF;

    CHECK_RF_CHAN_NUM(chan);
    lnaSwitch = BspGetLnaSwitchCtrl_Fpga(chan);

    return lnaSwitch;
}
UINT32 fpgalnaon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
       BspSetLnaSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*pa tdd_fdd*/
UINT32 fpgalnaonfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        BspSetLnaFddSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}
UINT32 fpgalnaoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetLnaSwitch_Fpga(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}
/************************************下行小信号放大器txamp相关******************************************/
/*****************************************************************************
 * 函数名称: BspSetPaTxPowModeCtrl(*)
 * 功能描述: 设置FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 *         : mode - 使能模式, 0: 正常TDD模式, 1: 使能测试模式
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPowTxModeCtrl_Fpga(UINT32 bspChan, UINT32 mode)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 rfChan     = 0;
    UINT32 txAmpTddMode   = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_POW_TX_EN_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_AMPCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetDifInfoByRfChn failed\n",rfChan);
        return BSP_ERROR;
    }
    txAmpTddMode = (SWITCH_TDD_CTRL_MODE == mode) ? 0 : 1;
    funcRet = BspRegBitValWr(difId, regIdx, 0, txAmpTddMode,chnBit,chnBit);

    return funcRet;
}
/*****************************************************************************
 * 函数名称: BspGetPaTxPowModeCtrl_Fpga(*)
 * 功能描述: 获取FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- TDD 模式, 1- FDD 模式, BSP_ERROR- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaPowTxModeCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 txAmpTddMode= SWITCH_TDD_CTRL_MODE;
    UINT32 ctrlMode    = 0;
    UINT32 chnBit = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_POW_TX_EN_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_AMPCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &txAmpTddMode);
    ctrlMode = (txAmpTddMode & BIT_SET(chnBit)) ? SWITCH_FDD_CTRL_MODE : SWITCH_TDD_CTRL_MODE;
    dbgInfoEx("bspChan %d regIdx %d txAmpTddMode 0x%x ctrlMode %d\n",bspChan,regIdx,txAmpTddMode,ctrlMode);

    return ctrlMode;
}

/*****************************************************************************
 * 函数名称: BspSetPaPowTxSwitchCtrl(*)
 * 功能描述: 设置FPGA输出到txamp的信号开关
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关, 1: 开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPowTxSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_TX_POWSW;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_AMPCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegBitValWr(difId, regIdx, 0, sw,chnBit,chnBit);
    dbgInfoEx("bspChan %d regIdx %d sw %d\n",bspChan,regIdx,sw);

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetPaPowTxSwitch(*)
 * 功能描述: txamp开关设置，开和关，TDD设置
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPowTxSwitch_Fpga(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);
    funcRet  = BspSetPaPowTxModeCtrl_Fpga(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetPaPowTxSwitchCtrl_Fpga(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}

UINT32 BspSetPaPowTxFddSwitch_Fpga(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);

    funcRet |= BspSetPaPowTxSwitchCtrl_Fpga(chan, sw);
    funcRet  = BspSetPaPowTxModeCtrl_Fpga(chan, SWITCH_FDD_CTRL_MODE);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}

/*上行小信号放大器通过fpga方式常开*/
UINT32 BspSetAllLnaPowRxFddSwitch_Fpga(UINT32 sw)
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;

    for(loop = 0; loop < BspGetRxChannel(); loop++)
    {
        ret |= BspSetLnaPowRxFddSwitch_Fpga(loop, sw);
    }

    return ret;
}
/*****************************************************************************
 * 函数名称: BspGetPaPowTxSwitchCtrl(*)
 * 功能描述: 获取FPGA输出到txemp的信号开关
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- 关, 1- 开, BSP_ERROR- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaPowTxSwitchCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 swCtrl      = LNA_SWITCH_OFF;
    UINT32 swBitOffset = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;
    UINT32 chnBit = 0;

    regIdx = REG_TX_POWSW;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, TX, LINK_INFO_AMPCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &swBitOffset);
    swCtrl = (swBitOffset & BIT_SET(chnBit)) ? LNA_SWITCH_ON : LNA_SWITCH_OFF;
    dbgInfoEx("bspChan %d swBitOffset 0x%x lnaSwCtrl %d\n",bspChan,swBitOffset,swCtrl);

    return swCtrl;
}

UINT32 BspGetPaPowTxSwitch_Fpga(UINT32 chan)
{
    UINT32 txAmpSwitch = AMP_SWITCH_OFF;

    CHECK_RF_CHAN_NUM(chan);
    txAmpSwitch = BspGetPaPowTxSwitchCtrl_Fpga(chan);

    return txAmpSwitch;
}

UINT32 fpgatxampon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
       BspSetPaPowTxSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*pa tdd_fdd*/
UINT32 fpgatxamponfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        BspSetPaPowTxFddSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}
UINT32 fpgatxampoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetPaPowTxSwitch_Fpga(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}
/************************************rxamp相关******************************************/
/*****************************************************************************
 * 函数名称: BspSetLnaPowRxModeCtrl(*)
 * 功能描述: 设置FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 *         : mode - 使能模式, 0: 正常TDD模式, 1: 使能测试模式
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaPowRxModeCtrl_Fpga(UINT32 bspChan, UINT32 mode)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 rfChan     = 0;
    UINT32 rxAmpTddMode= 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_POW_RX_EN_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNASWCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",rfChan);
        return BSP_ERROR;
    }
    rxAmpTddMode = (SWITCH_TDD_CTRL_MODE == mode) ? 0 : 1;
    funcRet = BspRegBitValWr(difId, regIdx, 0, rxAmpTddMode,chnBit,chnBit);

    return funcRet;
}
/*****************************************************************************
 * 函数名称: BspGetLnaPowRxModeCtrl(*)
 * 功能描述: 获取FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- TDD 模式, 1- FDD 模式, BSP_ERROR- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaPowRxModeCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 rxAmpTddMode   = SWITCH_TDD_CTRL_MODE;
    UINT32 ctrlMode    = 0;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_POW_RX_EN_TEST;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNASWCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &rxAmpTddMode);
    ctrlMode = (rxAmpTddMode & BIT_SET(chnBit)) ? SWITCH_FDD_CTRL_MODE : SWITCH_TDD_CTRL_MODE;
    dbgInfoEx("bspChan %d regIdx %d chnBit %d rxAmpTddMode 0x%x ctrlMode %d\n",bspChan,regIdx,chnBit,rxAmpTddMode,ctrlMode);

    return ctrlMode;
}

/*****************************************************************************
 * 函数名称: BspSetLnaPowRxSwitchCtrl(*)
 * 功能描述: 设置FPGA输出到Lna的信号开关
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关, 1: 开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaPowRxSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;

    regIdx = REG_RX_POWSW;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNASWCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegBitValWr(difId, regIdx, 0, sw,chnBit,chnBit);
    dbgInfoEx("bspChan %d regIdx %d chnBit %d sw %d\n",bspChan,regIdx,chnBit,sw);

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetLnaPowRxSwitch(*)
 * 功能描述: rxamp开关设置，开和关，TDD设置
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaPowRxSwitch_Fpga(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);
    funcRet  = BspSetLnaPowRxModeCtrl_Fpga(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetLnaPowRxSwitchCtrl_Fpga(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}

UINT32 BspSetLnaPowRxFddSwitch_Fpga(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);

    funcRet  = BspSetLnaPowRxModeCtrl_Fpga(chan, SWITCH_FDD_CTRL_MODE);
    funcRet |= BspSetLnaPowRxSwitchCtrl_Fpga(chan, sw);
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}
/*****************************************************************************
 * 函数名称: BspGetLnaPowRxSwitchCtrl(*)
 * 功能描述: 获取FPGA输出到Lna的信号开关
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- 关, 1- 开, BSP_ERROR- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaPowRxSwitchCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 swCtrl      = LNA_SWITCH_OFF;
    UINT32 chnBit      = 0;
    pGetRfSwitchCtrlBit pGetBit = NULL;
    UINT32 swBitOffset = 0;

    regIdx = REG_RX_POWSW;
    pGetBit = BspGetRfSwitchCtrlBitCallBack();
    if(pGetBit != NULL)
    {
        funcRet = pGetBit(bspChan, RX, LINK_INFO_LNASWCHN_TDDIO,&chnBit);
    }
    else
    {
        chnBit = bspChan; /*按需求可能需要修改*/
    }
    if(BSP_OK != funcRet)
    {
        dbgErr("chan %d BspGetRfSwitchCtrlBit failed\n",bspChan);
        return BSP_ERROR;
    }
    funcRet = BspRegRd(difId, regIdx, 0, &swBitOffset);
    swCtrl = (swBitOffset & BIT_SET(chnBit)) ? LNA_SWITCH_ON : LNA_SWITCH_OFF;
    dbgInfoEx("bspChan %d chnBit %d swBitOffset 0x%x swCtrl %d\n",bspChan,chnBit,swBitOffset,swCtrl);

    return swCtrl;
}

UINT32 BspGetLnaPowRxSwitch_Fpga(UINT32 chan)
{
    UINT32 rxAmpSwitch = LNA_SWITCH_OFF;

    CHECK_RF_CHAN_NUM(chan);
    rxAmpSwitch = BspGetLnaPowRxSwitchCtrl_Fpga(chan);

    return rxAmpSwitch;
}

UINT32 fpgarxampon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
       BspSetLnaPowRxSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*pa tdd_fdd*/
UINT32 fpgarxamponfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        BspSetLnaPowRxFddSwitch_Fpga(chn,SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}
UINT32 fpgarxampoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetLnaPowRxSwitch_Fpga(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}
UINT32 fpgaiosta(VOID)
{
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 rxChnNum= BspGetRxChannel();
    UINT32 *paSta, *lnaSta,  *txAmpSta, *rxAmpSta;
    UINT32 loop = 0;

    paSta = malloc(txChnNum*sizeof(UINT32));
    if (paSta == NULL)
    {
        return BSP_ERROR;
    }
    lnaSta= malloc(rxChnNum*sizeof(UINT32));
    if (lnaSta == NULL)
    {
        free(paSta);
        return BSP_ERROR;
    }
    txAmpSta = malloc(txChnNum*sizeof(UINT32));
    if (txAmpSta  == NULL)
    {
        free(paSta);
        free(lnaSta);
        return BSP_ERROR;
    }
    rxAmpSta= malloc(rxChnNum*sizeof(UINT32));
    if (rxAmpSta == NULL)
    {
        free(paSta);
        free(lnaSta);
        free(txAmpSta);
        return BSP_ERROR;
    }
    for (loop = 0; loop < txChnNum; loop++)
    {
        paSta[loop] = BspGetPaSwitch_Fpga(loop);
        txAmpSta[loop] = BspGetPaPowTxSwitch_Fpga(loop);
    }

    for (loop = 0; loop < rxChnNum; loop++)
    {
        lnaSta[loop] = BspGetLnaSwitch_Fpga(loop);
        rxAmpSta[loop] = BspGetLnaPowRxSwitch_Fpga(loop);
    }

    dbgInfo("pa switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,paSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("lna switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < rxChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,lnaSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("txamp switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,txAmpSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("rxamp switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < rxChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,rxAmpSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    free(paSta);
    free(lnaSta);
    free(txAmpSta);
    free(rxAmpSta);

    return BSP_OK;
}

/*控制5选1和2选1开关 chan: 0x181 bit0-3 mode: 0x181 bit4(0-fwd 1-rev)  sw:0 去使能 1使能*/
UINT32 BspSetCbSwitchByFpga(UINT32 chan, UINT32 mode, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 regVal = 0;

    regVal = chan|mode<<4;
    retVal = BspRegWr(0, REG_POW_SW_TEST_MODE_EN, 0, sw);
    retVal |= BspRegWr(0, REG_POW_SW_TEST, 0, regVal);

    return retVal;
}

/*TXEN*/
/* Started by AICoder, pid:o32f265871c3e1a14d2c0b2910f15e1c5b499124 */
UINT32 BspSetTxSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit = 0;

    regIdx = REG_POW_TX_EN;
    chnBit = bspChan; /*按需求可能需要修改*/

    funcRet = BspRegBitValWr(difId, regIdx, 0, sw,chnBit,chnBit);
    dbgInfoEx("bspChan %d regIdx %d sw %d\n",bspChan,regIdx,sw);

    return funcRet;
}
/* Ended by AICoder, pid:o32f265871c3e1a14d2c0b2910f15e1c5b499124 */

/* Started by AICoder, pid:t5c3452ef1r1bcd141c009b8b097a226864600c3 */
UINT32 BspGetTxenSwitchCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 paSwCtrl    = TX_SWITCH_OFF;
    UINT32 chnBit      = 0;
    UINT32 swBitOffset = 0;

    regIdx = REG_POW_TX_EN;
    chnBit = bspChan; /*按需求可能需要修改*/

    BspRegRd(difId, regIdx, 0, &swBitOffset);
    paSwCtrl = (swBitOffset & BIT_SET(chnBit)) ? TX_SWITCH_ON : TX_SWITCH_OFF;
    dbgInfoEx("bspChan %d chnBit %d swBitOffset 0x%x paSwCtrl %d\n",bspChan,chnBit,swBitOffset,paSwCtrl);

    return paSwCtrl;
}
/* Ended by AICoder, pid:t5c3452ef1r1bcd141c009b8b097a226864600c3 */

/* Started by AICoder, pid:lafa2m0c11zebe6146a9082610c3281719c3bea7 */
UINT32 BspGetTxenSwitch_Fpga(UINT32 chan)
{
    UINT32 txenSwitch = TX_SWITCH_OFF;

    CHECK_RF_CHAN_NUM(chan);
    txenSwitch = BspGetTxenSwitchCtrl_Fpga(chan);

    return txenSwitch;
}
/* Ended by AICoder, pid:lafa2m0c11zebe6146a9082610c3281719c3bea7 */

/*RXEN*/
/* Started by AICoder, pid:64ef5o607cr8cd0142c309b820304a14d8291c77 */
UINT32 BspSetRxSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 funcRet     = BSP_OK;
    UINT32 chnBit = 0;

    regIdx = REG_POW_RX_EN;

    chnBit = bspChan; /*按需求可能需要修改*/

    funcRet = BspRegBitValWr(difId, regIdx, 0, sw,chnBit,chnBit);
    dbgInfoEx("bspChan %d regIdx %d sw %d\n",bspChan,regIdx,sw);

    return funcRet;
}
/* Ended by AICoder, pid:64ef5o607cr8cd0142c309b820304a14d8291c77 */

/* Started by AICoder, pid:8c46776e44k14ed144a50848409a382f42c62f35 */
UINT32 BspGetRxenSwitchCtrl_Fpga(UINT32 bspChan)
{
    UINT32 difId       = 0;
    UINT32 regIdx      = 0;
    UINT32 paSwCtrl    = RX_SWITCH_OFF;
    UINT32 chnBit      = 0;
    UINT32 swBitOffset = 0;

    regIdx = REG_POW_RX_EN;
    chnBit = bspChan; /*按需求可能需要修改*/

    BspRegRd(difId, regIdx, 0, &swBitOffset);
    paSwCtrl = (swBitOffset & BIT_SET(chnBit)) ? RX_SWITCH_ON : RX_SWITCH_OFF;
    dbgInfoEx("bspChan %d chnBit %d swBitOffset 0x%x paSwCtrl %d\n",bspChan,chnBit,swBitOffset,paSwCtrl);

    return paSwCtrl;
}
/* Ended by AICoder, pid:8c46776e44k14ed144a50848409a382f42c62f35 */

/* Started by AICoder, pid:d546co2b08xd6ae144800b9600816819a5f37b8d */
UINT32 BspGetRxenSwitch_Fpga(UINT32 chan)
{
    UINT32 rxenSwitch = RX_SWITCH_OFF;

    CHECK_RF_CHAN_NUM(chan);
    rxenSwitch = BspGetRxenSwitchCtrl_Fpga(chan);

    return rxenSwitch;
}
/* Ended by AICoder, pid:d546co2b08xd6ae144800b9600816819a5f37b8d */

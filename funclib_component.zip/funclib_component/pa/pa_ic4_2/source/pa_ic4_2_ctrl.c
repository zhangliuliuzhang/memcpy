/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_ic4_ctrl.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作   者 :
* 创建日期 :
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人:
* 修改日戳:
* 变更说明: 创建文件
(1)辅助性定义和接口
(2)射频开关关联
(3)射频开关控制
(4)调试接口
(5)其他接口
(6)功放保护 --从此模块移走，单独加一个功放保护模块
*----------------------------------------------------------------------------
*/
#include "bsppub.h"
#include "bspcomm.h"
#include "boardid.h"
#include "chnmap_a.h"
#include "regdrv_accesstbl.h"
#include "regdrv_access.h"
#include "pa_ic4_2_ctrl.h"
#include "rruinfo.h"
#include "devdrv_dac.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "io_ctrl.h"
#include "pacommon.h"
#include "dif_common.h"
#include "cpri_sw.h"
#include "pa_ic4_2_gridvolt.h"
#include "ichaladapt_ic4_2.h"
#include "funccommon_a.h"
#include "timedelay_ic4_2_interface.h"
#include "rftable_pabasicinfo.h"
#include "pa_fpga_tddrfctrl.h"
#include "funccommon_fpga.h"

/******************************************************************************************
                             宏、全局变量 辅助性接口等定义
******************************************************************************************/
typedef UINT32 (*PGetPaLnaSwStatus)(UINT32 chan);

#define MODE_TDDFDD_NAME_STR(ctrlMode, pNameStr)         \
{                                                        \
    if ((SWITCH_TDD_CTRL_MODE) == (ctrlMode))            \
    {                                                    \
        (pNameStr) = "TDD";                              \
    }                                                    \
    else if ((SWITCH_FDD_CTRL_MODE) == (ctrlMode))       \
    {                                                    \
        (pNameStr) = "FDD";                              \
    }                                                    \
    else                                                 \
    {                                                    \
        (pNameStr) = "Invalid";                          \
    }                                                    \
}
UINT32 s_NegativeVccWarnStatus = 0;
UINT32 s_NegativeVccWarnType   = 0;
extern UINT32 BspSetDpdChanOff(UINT32 chanmask);
SEM_ID semPaDet = NULL;

UINT32 s_ulPaLnaSwitchPrn      = 0;
UINT32 s_paPmosPwrCtrlMethod   = E_PA_PMOS_PWR_CTRL_METHOD_DAC;  /*通过io控制功放*/
UINT32 s_PaPmosCtrl = PA_PMOS_CTRL_WITH_FPGA_DEFAULT;
UINT32 s_PaPmosCtrlWidth = PA_PMOS_CTRL_WITH_FPGA_DEFAULT;/*0表示默认，单bit控制所有通道*/
UINT32 s_PaSwCtrl = PA_PMOS_CTRL_WITH_GPIO_DEFAULT;
UINT32 s_LnaSwCtrl = LNA_CTRL_WITH_DEFAULT;
UINT32 s_ulPaCtrlChnlSelFlag = 0;
#define PA_SWITCH_CTRL_FOURINONE   1
#define PA_SWITCH_CTRL_ONEBYONE    0

/*记录栅压和LNA通道开关状态*/
static UINT32 g_PaSwFlag[CHN_NUM_PER_CHIP] = {0};
static UINT32 g_LnaSwFlag[CHN_NUM_PER_CHIP] = {0};
static UINT32 g_AmpSwFlag[CHN_NUM_PER_CHIP] = {0};

#define CHECK_RF_CHAN_NUM(a) if((a) >= BspGetTxChanNum() || (a) >= CHN_NUM_PER_CHIP)\
                                {dbgErr("%s: input chan num'%d out of range\n", __func__, (a)); return BSP_ERROR;}

#define CHECK_PA_SW_VALID(chn,sw) if((sw) > PA_SWITCH_ON_FDD)\
                                {dbgErr("%s chan [%d] sw [%d] is error!!!\n", __func__, (chn),(sw)); return BSP_ERROR;}

#define PA_TDD_SEL_MODE        (UINT32)(2)

PASW_CALLBACK_FUNCPTR pPaSwCtrlCallBack = NULL;
UINT32 g_RfSwitchMode = 0; 
UINT32 g_TddIoLnaswFlag = 1;

static UINT32  g_ulPaNorMalFlag[CHN_NUM_PER_CHIP] = {0};
static UINT32  g_ulPaStatus[CHN_NUM_PER_CHIP]={0};
static UINT32  g_ulDlVgaStatus[CHN_NUM_PER_CHIP]={DLVGA_NORMAL};
static BOOL  g_bDlVgaSupportFlag = FALSE;

UINT8 g_dtxPaOnSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_dtxLnaOnSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_dtxAmpOnSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_dtxTxOnSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_dtxRxOnSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_dtxOrxOnSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
/*用来记录IO通道关闭状态，并不是开关的真正状态*/
UINT8 g_PaSwitchOffSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_LnaSwitchOffSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_AmpSwitchOffSta[TDD_IO_PIN_NUM_COMMON_8][CHN_NUM_PER_CHIP] = {0};
UINT8 g_TxSwitchOffSta[TDD_IO_PIN_NUM_COMMON_4][CHN_NUM_PER_CHIP] = {0};
UINT8 g_RxSwitchOffSta[TDD_IO_PIN_NUM_COMMON_4][CHN_NUM_PER_CHIP] = {0};
UINT8 g_FbSwitchOffSta[TDD_IO_PIN_NUM_COMMON_4][CHN_NUM_PER_CHIP] = {0};
UINT8 g_TxAcSwitchOffSta[TDD_IO_PIN_TRX_EN_AC_NUM_2][CHN_NUM_PER_CHIP] = {0};
UINT8 g_RxAcSwitchOffSta[TDD_IO_PIN_TRX_EN_AC_NUM_2][CHN_NUM_PER_CHIP] = {0};

static T_TDDIO_AC_SWITCH_PARA *s_ulTddIoAcSwitchPara = NULL;
static UINT32           s_TddIoAcSwitchParaNum = 0;

RFSWITCH_GETGP_CALLBACK pRfSwitchGetGpCallBack = NULL;
SLAVE_RFSWITCH_CALLBACK pSlaveRfSwitchCallBack = NULL;
static SET_SLAVE_PORT_RFSWITCH pSetSlavePortRfSwitch = NULL;
static GET_SLAVE_PORT_RFSWITCH pGetSlavePortRfSwitch = NULL;
static GET_PA_REAL_SWITCH pGetPaSwitchSta = NULL;
static UINT32 s_slavePaStatus[CHN_NUM_PER_CHIP] = {0};
static UINT32 s_slaveLnaStatus[CHN_NUM_PER_CHIP] = {0};
static UINT32 s_tddFddSelMode = PA_TDD_SEL_MODE;

//4套TDD的情况
UINT32 _SwitchModeCtrlX[4][2] = 
{
    [0 ... 4-1][0 ... 1] = 0xFFFF,
};

UINT32 BspSetSlavePaStatus(UINT32 chan, UINT32 sta)
{
    if(chan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %u Error!\n", chan);
        return BSP_ERROR;
    }
    s_slavePaStatus[chan] = sta;
    return BSP_OK;
}

UINT32 BspSetSlaveLnaStatus(UINT32 chan, UINT32 sta)
{
    if(chan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulRxChan %u Error!\n", chan);
        return BSP_ERROR;
    }
    s_slaveLnaStatus[chan] = sta;
    return BSP_OK;
}

VOID BspSetTddFddSelMode(UINT32 mode)
{
    s_tddFddSelMode = mode;
}

UINT32 BspSetAppPaStatus(UINT32 chan,UINT32 sw)
{
    if (chan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %u Error!\n", chan);
        return BSP_ERROR;
    }

    g_ulPaStatus[chan] = sw;
    return BSP_OK;
}

UINT32 BspGetAppPaStatus(UINT32 chan)
{
   if (chan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %u Error!\n", chan);
        return BSP_ERROR;
    }
    return g_ulPaStatus[chan];
}

UINT32 BspSetSlavePortRfSwitchCallBack(SET_SLAVE_PORT_RFSWITCH pFuncCallback)
{
    pSetSlavePortRfSwitch = pFuncCallback;
    return BSP_OK;
}

static UINT32 BspSetRfsDevRfSwitch(UINT32 chan, UINT32 swType, UINT32 sw, UINT32 swDly)
{
    UINT32 retVal = BSP_OK;

    if(NULL != pSetSlavePortRfSwitch)
    {
         return pSetSlavePortRfSwitch(chan, swType, sw, swDly);
    }
    dbgInfoEx("Set Slave Port Rf Switch Call Back is NULL!\n");
    return retVal;
}

UINT32 BspGetSlavePortRfSwitchCallBack(GET_SLAVE_PORT_RFSWITCH pFuncCallback)
{
    pGetSlavePortRfSwitch = pFuncCallback;
    return BSP_OK;
}

static UINT32 BspGetRfsDevRfSwitch(UINT32 portId, T_SlavePortRfSwitchSta *pRfSta)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pRfSta);
    if(NULL != pGetSlavePortRfSwitch)
    {
        return pGetSlavePortRfSwitch(portId, pRfSta);
    }
    dbgInfoEx("Get Slave Port Rf Switch Call Back is NULL!\n");
    return retVal;
}

UINT32 BspGetPaSwitchStaCallBack(GET_PA_REAL_SWITCH pFuncCallback)
{
    pGetPaSwitchSta = pFuncCallback;
    return BSP_OK;
}

UINT32 BspSetPaSwitchForUnNomal(UINT32 chan, UINT32 sw);

/*预留回调接口，针对PA_SW特殊控制要求，目前没有使用*/
UINT32 BspPaSwCtrlCallBack(PASW_CALLBACK_FUNCPTR pFuncCallback)
{
    pPaSwCtrlCallBack = pFuncCallback;

    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : GetPaDacChipByBspChan(*)
 *  功能描述   : 通过bsp通道号获取DAC的芯片号
 *  输入参数   : bsp通道号
 *  输出参数   : 芯片号
 *  返 回 值   : BSP_OK 成功
 *            其他     失败
 *  其它说明   :
 *  工装使用申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $10263627(N/A),  创建@2021-07-22 19:34:52
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaDacChipByBspChan(UINT32 ulRfChnl)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulPaChnl = 0;
    UINT32 ulDevId = 0;
    INT32  lSnpRet = 0;
    char  ucNameBuf[PA_PARA_LENGTH] = {0};
    TRruDeviceDescription dev = {0};

    if (ulRfChnl >= BspGetTxChanNum())
    {
        dbgInfo("PaDac index%u Error!\n", ulRfChnl);
    }

    ulRetVal = BspGetPaChnByRfChn(ulRfChnl, TX, &ulPaChnl);

    /* 通过查找PA通道号，DAC的序号 */
    lSnpRet = snprintf_s(ucNameBuf, sizeof(ucNameBuf), "GridVoltPa%d", ulPaChnl);
    SNPRINTF_S_CHECK(lSnpRet, sizeof(ucNameBuf));
    ucNameBuf[PA_PARA_LENGTH - 1] = '\0';
    ulDevId = BspDevNameToId(ucNameBuf);

    ulRetVal |= BspDevInfoGetByDevId(ulDevId, &dev);

    if(BSP_OK == ulRetVal)
    {
        return dev.ulDeviceIndex;
    }
    else
    {
        return BSP_ERROR;
    }
}


/******************************************************************************************
                             射频开关关联、通道选择、bit对应关系设置
1 lna_pwr和lna_sw是否联动控制，一起开关
2 pa控制是否除了IO，还需要依赖于栅压（管脚1控多的场景），从方案看，4.2上是一对一控制PA电源开关
******************************************************************************************/
/*单板下设置LNA_PWR_TEST（lna电源）和LNA_SW_TEST（小信号放大） 是否联动一起开关*/
UINT32 BspGetTddIoLnaswFlag(VOID)
{
    return g_TddIoLnaswFlag;
}
/*单板下设置LNA_PWR_TEST（lna电源）和LNA_SW_TEST（小信号放大） 是否联动一起开关*/
UINT32 BspSetTddIoLnaswFlag(UINT32 flag)
{
    g_TddIoLnaswFlag = flag;
    return BSP_OK;
}

/*单板下设置LNA和PA控制是以中频通道还是射频通道，默认是中频通道*/
UINT32 BspSetPaCtrlChnlSelFlag(UINT32 ulSelFlag)
{
    s_ulPaCtrlChnlSelFlag = ulSelFlag;
    return BSP_OK;
}
/*单板下设置LNA和PA控制是以中频通道还是射频通道，默认是中频通道*/
UINT32 PaCtrlChnlSelect(UINT32 ulDifChnl, UINT32 ulPaChnl)
{
    UINT32 ulSelChnlNo = 0;

    if (0 == s_ulPaCtrlChnlSelFlag)
    {
        ulSelChnlNo = ulDifChnl;
    }
    else
    {
        ulSelChnlNo = ulPaChnl;
    }

    return ulSelChnlNo;
}
UINT32 paSwitchMethod = PA_SWITCH_CTRL_ONEBYONE;
UINT32 BspSetPaSwMeThod(UINT32 method)
{
    paSwitchMethod = method;
    return BSP_OK;
}

UINT32 BspGetPaSwMethod(VOID)
{
    return paSwitchMethod;
}
/*****************************************************************************
 * 函数名称: BspSetPaPwrCtrlMethod(*)
 * 功能描述: 设置功放开关是通过写DAC 栅压（IO管脚+dac栅压--4.0使用）控还是通过pmos控（原来是fpga寄存器）
 *                            E_PA_PMOS_PWR_CTRL_METHOD_DAC    E_PA_PMOS_PWR_CTRL_METHOD_FPGA
 *                            目前看都是第一种，第二种的接口4.0上没有具体实现，4.2上先保留
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPwrCtrlMethod(UINT32 method)
{
    return (s_paPmosPwrCtrlMethod = method);
}

/*****************************************************************************
 * 函数名称: BspGetPaPwrCtrlMethod(*)
 * 功能描述:
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaPwrCtrlMethod(VOID)
{
    return s_paPmosPwrCtrlMethod;
}

/*****************************************************************************
 * 函数名称: BspSetPaPmosCtrlFpgaMode(*)
 * 功能描述: 当通过pmos控制pa开关时区分，4.0未使用
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10226011@2018-12-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPmosCtrlFpgaMode(UINT32 ulSelecMode)
{
    dbgInfoEx("[%s]Select Mode Is %d\n",__FUNCTION__,ulSelecMode);    
    s_PaPmosCtrl = (PA_PMOS_CTRL_WITH_FPGA_REPLACE_GPIO == ulSelecMode)?PA_PMOS_CTRL_WITH_FPGA_REPLACE_GPIO: PA_PMOS_CTRL_WITH_FPGA_DEFAULT;
    BspLog(LOG_LEVEL_1, "%s:  ulSelecMode:%d s_PaPmosCtrl:%d \n", __FUNCTION__,ulSelecMode,s_PaPmosCtrl);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetPaPmosCtrlFpgaMode(*)
 * 功能描述:
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10226011@2018-12-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaPmosCtrlFpgaMode(VOID)
{
    dbgInfoEx("[%s]Select Mode Is %d\n",__FUNCTION__,s_PaPmosCtrl);  
    return s_PaPmosCtrl;
}
/*****************************************************************************
 * 函数名称: BspSetPaPmosCtrlFpgaModeWidth(*)
 * 功能描述:配置28v/48v单bit控制的通道数 原来0x47寄存器
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10226011@2018-12-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPmosCtrlFpgaModeWidth(UINT32 ulWidth)
{
    dbgInfoEx("[%s]Select ulWidth Is %d\n",__FUNCTION__,ulWidth);
    s_PaPmosCtrlWidth = ulWidth;
    BspLog(LOG_LEVEL_1, "%s: ulWidth:%d \n", __FUNCTION__, ulWidth);
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetPaPmosCtrlFpgaMode(*)
 * 功能描述:获取28v/48v单bit控制的通道数 原来0x47寄存器
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10226011@2018-12-20, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaPmosCtrlFpgaModeWidth(VOID)
{
    dbgInfoEx("[%s]Select lWidth Is %d\n",__FUNCTION__,s_PaPmosCtrlWidth);
    return s_PaPmosCtrlWidth;
}

/*****************************************************************************
 * 函数名称: BspSetPaPmosNegaVccWarnType(*)
 * 功能描述: 设置-8v告警判断标准,默认为状态告警
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2019-01-07, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPmosNegaVccWarnType(UINT32 warnType)
{
    dbgInfoEx("[%s]Select warnType Is %d\n",__FUNCTION__,warnType);
    s_NegativeVccWarnType = (PA_VCC_NEGATIVE_8V_EVENT_WARNING == warnType)?PA_VCC_NEGATIVE_8V_EVENT_WARNING: PA_VCC_NEGATIVE_8V_STATUS_WARNING;
    BspLog(LOG_LEVEL_1, "%s: warnType:%d s_NegativeVccWarnType:%d \n", __FUNCTION__,warnType,s_NegativeVccWarnType);
    return BSP_OK;
}

UINT32 BspGetPaPmosNegaVccWarnType(VOID)
{
    dbgInfoEx("[%s]Select warnType Is %d\n",__FUNCTION__,s_NegativeVccWarnType);
    return s_NegativeVccWarnType;
}


/**********************************4.2*******************************************
 * 函数名称: BspSetPaSwCtrlMode(*)
 * 功能描述: 设置功放开关控制类型
 * 输入参数:paType：0--正常gpio控制，1--栅压控制，由于4.0存在IO一控多，为实现单通道的开关，需要借助于每个通道栅压，所以这里实际上是IO+栅压
 *                 4.2待确认，看方案IO是1控1，所以可能不需要再控制栅压，先保留
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2019-01-07, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaSwCtrlMode(UINT32 paType)
{
    dbgInfoEx("[%s]Select ctrlMode Is %d\n",__FUNCTION__,paType);
    s_PaSwCtrl = paType;
    BspLog(LOG_LEVEL_1, "%s: paType:%d  \n", __FUNCTION__,paType);
    return BSP_OK;
}

UINT32 BspGetPaSwCtrlMode(VOID)
{
    dbgInfoEx("[%s]Select ctrlMode Is %d\n",__FUNCTION__,s_PaSwCtrl);
    return s_PaSwCtrl;
}
/*************************************4.2****************************************
 * 函数名称: BspSetPaSwCtrlMode(*)
 * 功能描述: 设置LNA开关控制类型，lna_pwr和Lna_sw\Lna_bypass是否联动控制，4.2上没有Lna_bypass Lna_sw，4.2 下行方向多了一个小信号放大器需要控制
 * 输入参数:paType：0--正常只控制lna_pwr，1--lna_pwr\Lna_sw\Lna_bypass
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: 这个接口4.2上目前看不需要使用，上行只有一个LNA 电源开关
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), @2019-01-07, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaSwCtrlMode(UINT32 lnaType)
{
    dbgInfoEx("[%s]Select ctrlMode Is %d\n",__FUNCTION__,lnaType);
    s_LnaSwCtrl = lnaType;
    
    BspLog(LOG_LEVEL_1, "%s: lnaType:%d  \n", __FUNCTION__,lnaType);
    return BSP_OK;
}

UINT32 BspGetLnaSwCtrlMode(VOID)
{
    dbgInfoEx("[%s]Select ctrlMode Is %d\n",__FUNCTION__,s_LnaSwCtrl);
    return s_LnaSwCtrl;
}


/******************************************************************************************
                             射频开关控制模式设置和获取（FDD模式、TDD模式即cpu控、fpga控）
每种开关占用1bit
******************************************************************************************/
/*设置和获取射频开关控制模式总接口，各个开关有子接口分别设置对应bit  0- TDD 模式, 1- FDD 模式*/
UINT32 BspSetRfSwitchMode(UINT32 mode)
{
    g_RfSwitchMode = mode;
    BspLog(LOG_LEVEL_1, "%s: mode:%d  \n", __FUNCTION__,mode);
    return BSP_OK;
}
UINT32 BspGetRfSwitchMode(VOID)
{
    return g_RfSwitchMode;
}
/**************************************************************************
 * 函数名称: BspSetPaModeCtrl
 * 功能描述: Pa模式选择
 * 输入参数: UINT32 chan  UINT32 mode
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                       创建
 **************************************************************************/
UINT32 BspSetPaModeCtrl(UINT32 chan, UINT32 mode)
{
    UINT32 valMask = PA_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);
    }

    return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspGetPaModeCtrl(*)
 * 功能描述: 获取FPGA的TDD模式，是CPU控制还是FPGA控制
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- TDD 模式, 1- FDD 模式, BSP_ERROR- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaModeCtrl(UINT32 chan)
{
    UINT32 valMask = PA_PWR_TEST;
    UINT32 paTddMode = 0;

    paTddMode = (g_RfSwitchMode >> valMask) & 0x1;
    return paTddMode;
}
/**************************************************************************
 * 函数名称: BspSetLnaModeCtrl
 * 功能描述: Lna模式选择
 * 输入参数: VOID
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                       创建
 **************************************************************************/
UINT32 BspSetLnaModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = LNA_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);
    }
    return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspGetLnaModeCtrl(*)
 * 功能描述: 获取FPGA的TDD模式，是FDD(CPU)控制还是TDD(FPGA)控制
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- TDD 模式, 1- FDD 模式, BSP_ERROR- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaModeCtrl(UINT32 chan)
{
    UINT32 valMask = LNA_PWR_TEST;
    UINT32 lnaTddMode = 0;

    lnaTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return lnaTddMode;

}
/*****************************************************************************
 * 函数名称: BspGetPaLnaCtrlMode(*)
 * 功能描述: 获取Pa/Lna FPGA的控制模式，是FDD(CPU)控制还是TDD(FPGA)控制
 * 输入参数: typePaLna - 放大器类型, 0: PA, 1:LNA
 *           chan      - 天线通道号
 * 输出参数: pCtrlMode - 控制模式; 0- TDD(FPGA)控制, 1- FDD(CPU)控制, BSP_ERROR- 失败
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaLnaCtrlMode(UINT32 typePaLna, UINT32 chan, UINT32 *pCtrlMode)
{
    UINT32 ctrlMode = 0;
    UINT32 funcRet = BSP_OK;
    const char  *pPaLnaTypeStr = NULL;

    if (AMP_TYPE_PA == typePaLna)
    {
        pPaLnaTypeStr = "Pa";
        ctrlMode = BspGetPaModeCtrl(chan);
    }
    else
    {
        pPaLnaTypeStr = "Lna";
        ctrlMode = BspGetLnaModeCtrl(chan);
    }

    if (NULL != pCtrlMode)
    {
        *pCtrlMode = ctrlMode; // SWITCH_TDD_CTRL_MODE/ SWITCH_FDD_CTRL_MODE
    }
    else
    {
        dbgInfo("%s>>%s'%d Chnl'%d: Mode(0:TDD_FPGA 1:FDD_CPU)= %d\n",
                __FUNCTION__, pPaLnaTypeStr, typePaLna, chan, ctrlMode);
    }

    if (BSP_ERROR == ctrlMode)
    {
        funcRet = BSP_ERROR;
    }

    return funcRet;
}

UINT32 BspSetAmpModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = AMP_SW_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);

    }
    return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspGetLnaSwModeCtrl(*)
 * 功能描述: 获取LNA SW的TDD模式
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- TDD 模式, 1- FDD 模式, BSP_ERROR- 失败
 * 其它说明: 测试模式使能时，各个开关电平由对应测试
 *           模式寄存器控制，否则由TDD控制模块控制
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetAmpSwModeCtrl(UINT32 chan)
{
    UINT32 valMask = AMP_SW_TEST;
    UINT32 lnaSwTddMode = 0;

    lnaSwTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return lnaSwTddMode;
}

UINT32 BspSetTxModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = TX_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);

    }
    return BSP_OK;
}
UINT32 BspGetTxModeCtrl(UINT32 chan)
{
    UINT32 valMask = TX_PWR_TEST;
    UINT32 TxTddMode = 0;

    TxTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return TxTddMode;

}
UINT32 BspSetRxModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = RX_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);

    }
    return BSP_OK;
}
UINT32 BspGetRxModeCtrl(UINT32 chan)
{
    UINT32 valMask = RX_PWR_TEST;
    UINT32 RxTddMode = 0;

    RxTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return RxTddMode;

}
UINT32 BspSetFbModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = FB_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);

    }
    return BSP_OK;
}
UINT32 BspGetFbModeCtrl(UINT32 chan)
{
    UINT32 valMask = FB_PWR_TEST;
    UINT32 FbTddMode = 0;

    FbTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return FbTddMode;
}
UINT32 BspSetTxAcModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = TXAC_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);

    }

    return BSP_OK;
}
UINT32 BspGetTxAcModeCtrl(UINT32 chan)
{
    UINT32 valMask = TXAC_PWR_TEST;
    UINT32 TxAcTddMode = 0;

    TxAcTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return TxAcTddMode;
}
UINT32 BspSetRxAcModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = RXAC_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);

    }

    return BSP_OK;
}
UINT32 BspGetRxAcModeCtrl(UINT32 chan)
{
    UINT32 valMask = RXAC_PWR_TEST;
    UINT32 RxAcTddMode = 0;

    RxAcTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return RxAcTddMode;
}
UINT32 BspSetAcCtrlModeCtrl(UINT32 chan, UINT32 mode)
{
    /* 对于V4来说ModeMap暂时用不到整体的FDD，使用FDD的时候也是按最简单的TDDIO末级直接选择0 or 1*/
    /* 这块代码暂时注掉，针对FDD商用机型的需求，需要启用TDD基础时序产生单元的timing和modemap sel选择*/

    UINT32 valMask = ACCTRL_PWR_TEST;

    if(mode == 1)
    {
        g_RfSwitchMode = g_RfSwitchMode | BIT_SET(valMask);
    }
    else
    {
        g_RfSwitchMode = g_RfSwitchMode & BIT_REV(valMask);

    }

    return BSP_OK;
}
UINT32 BspGetAcCtrlModeCtrl(UINT32 type)
{
    UINT32 valMask = ACCTRL_PWR_TEST;
    UINT32 AcCtrlTddMode = 0;

    AcCtrlTddMode = (g_RfSwitchMode >> valMask) & 0x1;

    return AcCtrlTddMode;

}

/* Started by AICoder, pid:4acddh27d540f911491e09bd50c8ca2a46f88623 */
/* 设置开关模式控制 */
UINT32 BspSetSwitchModeCtrl(UINT32 acType, UINT32 tddsel)
{
    UINT32 modeMapSel = 0;

    if(BSP_ERROR == (modeMapSel = FromAcTypeToModeMapSel(acType)))
    {
        dbgInfo("%s: acType%d, get modeMapSel error!\n", __FUNCTION__, acType);
        modeMapSel = TDD_IO_MODE_TDD;//查找错误，就使用默认正常TDD
    }

    if(IS_NCR == BspIsNcr() && E_DPD_TYPE_TS == acType)
    {
        modeMapSel = TDD_IO_MODE_DL_AC;
    }
    _SwitchModeCtrlX[tddsel%4][0] = acType;
    _SwitchModeCtrlX[tddsel%4][1] = modeMapSel;

    dbgInfoEx("%s: acType %d, tddsel %d modeMapSel %d\n", __FUNCTION__, 
                acType, tddsel, modeMapSel );

    IcHalApiSetModeMapSel(tddsel,modeMapSel);
    if((RRU_PB_BBU ==  BspGetPbOrBbuMode()) || (RRU_BBU_EP214 ==  BspGetPbOrBbuMode()) || (RRU_BBU ==  BspGetPbOrBbuMode()) ){
        modeMapSel = 0; // 和中频沟通：QCELL 无论任何情况，modeMapSel都是0
    }
    IcHalApiSetAcCtrlModeMapSel(tddsel,modeMapSel);
    return BSP_OK;
}
/* Ended by AICoder, pid:4acddh27d540f911491e09bd50c8ca2a46f88623 */


/*********************************null********************************************
 * 函数名称: BspSetPaTxPowModeCtrl(*)
 * 功能描述: 设置FPGA的TDD模式，是CPU控制还是FPGA控制  下行小信号放大器
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaPowTxModeCtrl(UINT32 chan, UINT32 mode)
{
	UINT32 ulRet = BSP_OK;
	ulRet = BspSetAmpModeCtrl(chan, mode);
	return ulRet;
}
/*低噪放旁路使能 4.0 4.2均无此信号*/
UINT32 BspSetLnaBypassModeCtrl(UINT32 chan, UINT32 mode)
{
	/*4.0 上未修改实现，仍然访问fpga 0x52*/
    return BSP_OK;
}
/***********************************null******************************************
 * 函数名称: BspSetLnaPowRxModeCtrl(*)
 * 功能描述: 设置RX POW模式     上行小信号放大器控制模式设置
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaPowRxModeCtrl(UINT32 chan, UINT32 mode)
{
    /*A9651A S26机型应该是没有专门的小信号放大器开关配置的，硬件上，下行小信号放大器开关和TX_EN合并，上行没有小信号放大器*/
    return BSP_OK;
}
/*****************************************************************************
 * 函数名称: BspGetLnaBypassModeCtrl(*)
 * 功能描述: 获取LNA Bypass的TDD模式
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaBypassModeCtrl(UINT32 chan)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}

/******************************************************************************************
                             射频开关控制实际动作设置和开关状态获取
第一部分: IO控制接口
第二部分: 模式选择+IO控制，封装接口
******************************************************************************************/
UINT32 BspSwitchOffStaInit(VOID)
{
     memset((VOID*)g_PaSwitchOffSta, 0x01, sizeof(g_PaSwitchOffSta));
     memset((VOID*)g_LnaSwitchOffSta, 0x01, sizeof(g_LnaSwitchOffSta));
     memset((VOID*)g_AmpSwitchOffSta, 0x01, sizeof(g_AmpSwitchOffSta));
     memset((VOID*)g_TxSwitchOffSta, 0x01, sizeof(g_TxSwitchOffSta));
     memset((VOID*)g_RxSwitchOffSta, 0x01, sizeof(g_RxSwitchOffSta));
     memset((VOID*)g_FbSwitchOffSta, 0x01, sizeof(g_FbSwitchOffSta));
     memset((VOID*)g_TxAcSwitchOffSta, 0x01, sizeof(g_TxAcSwitchOffSta));
     memset((VOID*)g_RxAcSwitchOffSta, 0x01, sizeof(g_RxAcSwitchOffSta));
    return BSP_OK;
}
UINT32 BspSwitchOffStaSet(UINT32 ioChan, UINT32 linkPro, UINT8 *offSta)
{
    UINT32 chn = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
    for(chn = 0; chn < Val.rfChNum; chn++)
    {
        offSta[Val.rfCh[chn]] = 0;
    }
    return BSP_OK;
 }

UINT32 BspSetPaNormalFlag(UINT32 ulTxChan,UINT32 ulPaNormalFlag)
{
	UINT32 bspChanMask = 0;
	UINT32 bspChan = 0;
	UINT32 paStatus = 0;
	UINT32 chanbitmask = 0;
    if (ulTxChan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %d Error!\n", ulTxChan);
        return BSP_ERROR;
    }
    if(ulPaNormalFlag == PA_UNNORMAL)
    {
        BspSetPaSwitchForUnNomal(ulTxChan, SWITCH_OFF);
    }
    else
    {
		if (SWITCH_ON == g_ulPaStatus[ulTxChan])
		{
			BspSetPaSwitchForUnNomal(ulTxChan, SWITCH_ON);
		}
    }
    g_ulPaNorMalFlag[ulTxChan] = ulPaNormalFlag;
    for (bspChan = 0; bspChan < BspGetTxChanNum(); bspChan++)
	{
    	paStatus = g_ulPaNorMalFlag[bspChan];
    	chanbitmask = (paStatus << bspChan);
    	bspChanMask |= chanbitmask;
	}
    BspSetDpdChanOff(bspChanMask);
    return BSP_OK;
}

UINT32 BspGetPaNormalFlag(UINT32 ulTxChan)
{
    if (ulTxChan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %d Error!\n", ulTxChan);
        return BSP_ERROR;
    }
    return g_ulPaNorMalFlag[ulTxChan];
}

UINT32 BspSetDlVgaTpyeFlag(UINT32 ulTxChan, UINT32 ulStatus)
{
    if (ulTxChan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %d Error!\n", ulTxChan);
        return BSP_ERROR;
    }
    g_ulDlVgaStatus[ulTxChan] = ulStatus;
    return BSP_OK;
}

UINT32 BspGetDlVgaTpyeFlag(UINT32 ulTxChan)
{
    if (ulTxChan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %d Error!\n", ulTxChan);
        return BSP_ERROR;
    }
    return g_ulDlVgaStatus[ulTxChan];
}

void BspSetDlVgaSupportSwitchType(BOOL flag)
{
    g_bDlVgaSupportFlag = flag;
    return ;
}

BOOL BspGetDlVgaSupportSwitchType(VOID)
{
    return g_bDlVgaSupportFlag;
}

/******************************************************************************************
                                        IO控制接口
******************************************************************************************/
static UINT32 BspSetPaSwitchCtrlD42(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;
    UINT32 realSw = 0;
    CHECK_RF_CHAN_NUM(chan);

    CHECK_PA_SW_VALID(chan,sw);

    dbgInfoEx("%s chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);

    if((BspGetPaModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == PA_SWITCH_ON))
    {
        sw = PA_SWITCH_ON_FDD;
    }

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        return BspSetPaSwitchCtrl_Fpga(chan, sw);
    }

    ret |= BspGetPaIoInfoByRfChn(chan,dir,&iochan);

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;

    realSw = BspChangePaSwitchCtrl(sw);

   /*PA的IO开关4.0上是1驱4，4通道全关则关，1通道开则开，4.2目前看都是1控1*/
   /*如果开1个通道实际没关，也返回OK*/
    switch(realSw)
    {
        case PA_SWITCH_ON:
        case PA_SWITCH_ON_FDD:
        {
            g_PaSwitchOffSta[ioIdx][chan] = 0;
            ret |= BspSetTddIoOutSel(ioIdx,ioTpye, realSw);

            if(PA_PMOS_CTRL_WITH_GRID_VOLT == BspGetPaSwCtrlMode())  /*如果pa 1控多，通过栅压控制实现1控1*/
            {
                BspSetVibasEnable(chan);
                ret |= BspSetPaVibasByChan(0,chan);
                if(BSP_OK==ret)
                {
                    g_PaSwFlag[chan] = PA_SWITCH_ON;
                }
            }
            else  /*直接1控1*/
            {
            	g_PaSwFlag[chan] = PA_SWITCH_ON;
            }
            break;
        }
        case PA_SWITCH_OFF:
        {
            g_PaSwitchOffSta[ioIdx][chan] = 1;
            if(BSP_OK==IsPaAllChnsOff(ioIdx,ioTpye,realSw)) /*1控1的时候要把丝印表配对，否则开关会出问题*/
            {
                 ret |= BspSetTddIoOutSel(ioIdx,ioTpye,realSw);
            }
            if(PA_PMOS_CTRL_WITH_GRID_VOLT == BspGetPaSwCtrlMode())
            {
                BspSetVibasDisable(chan);
                BspSysUsDelay(100);
                ret |= BspClrPaVibasByChan(0, chan);
                if(BSP_OK==ret)
                {
                    g_PaSwFlag[chan] = PA_SWITCH_OFF;
                }
            }
            else  /*直接1控1*/
            {
            	g_PaSwFlag[chan] = PA_SWITCH_OFF;
            }
            break;
        }
        default:
        {
            dbgInfo("[%s] PA Switch Status is Error!!! Sta is %d\n", __FUNCTION__, realSw);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspSetPaSwitchCtrl(UINT32 chan, UINT32 sw)
{
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();
    CHECK_RF_CHAN_NUM(chan);
    CHECK_PA_SW_VALID(chan,sw);

    dbgInfoEx("%s chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[chan] && NULL != pFpgaInfo->pFuncSetFpgaPaSw)
    {
        return pFpgaInfo->pFuncSetFpgaPaSw(chan, sw);
    }
    else
    {
        return BspSetPaSwitchCtrlD42(chan, sw);
    }
}

/*****************************************************************************
 *  函数名称   : BspSetPaTddIoSwitch(*)
 *  功能描述   : pa开关设置
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : chan:通道号
 *  输出参数   : sw：开关,2表示fddon
 *  返 回 值      : BSP_OK －成功 ＢSP_ERROE
 *  其它说明   : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaTddIoSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        return BspSetPaSwitchCtrl_Fpga(chan, sw);
    }

    ret |= BspGetPaIoInfoByRfChn(chan,dir,&iochan);

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;

    switch(sw)
    {
        case PA_SWITCH_ON:
        case PA_SWITCH_ON_FDD:
        {
            ret |= BspSwitchOffStaSet(iochan,ioTpye, (UINT8 *)&g_PaSwitchOffSta[iochan]);
            ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);
            break;
        }
        case PA_SWITCH_OFF:
        {
            g_PaSwitchOffSta[ioIdx][chan] = 1;
            if(BSP_OK==IsPaAllChnsOff(ioIdx,ioTpye,sw))
            {
                 ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);
            }
            break;
        }
        default:
        {
            dbgInfo("[%s] PA Switch Status is Error!!! Sta is %d\n", __FUNCTION__, sw);
            break;
        }
    }

     if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}
/*LNA_PWR lna电源开关*/
UINT32 BspSetLnaSwitchCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    if(sw >LNA_SWITCH_ON_FDD)
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo)
    {
        INPUT_BSPCHN_CHECK(chan);
        if (FPGA_CHAN == pFpgaInfo->rxFpgaChanFlag[chan] && NULL != pFpgaInfo->pFuncSetFpgaLnaSw)
        {
            return pFpgaInfo->pFuncSetFpgaLnaSw(chan, sw);
        }
    }

    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);
    if((BspGetLnaModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == LNA_SWITCH_ON))
    {
        sw = LNA_SWITCH_ON_FDD;
    }

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        return BspSetLnaSwitchCtrl_Fpga(chan, sw);
    }

    ret |= BspGetLnaIoInfoByRfChn(chan,dir,&iochan);

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
   /*4.0LNA的IO开关1驱4，4通道全开则开，1通道关则关 4.2目前看都是1控1*/
   /*如果开1个通道实际没开，也返回OK*/
    switch(sw)
    {
        case LNA_SWITCH_ON:
        case LNA_SWITCH_ON_FDD:
        {
            g_LnaSwitchOffSta[ioIdx][chan] = 0;
            ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);
            if(BSP_OK==ret)
            {
                g_LnaSwFlag[chan] = LNA_SWITCH_ON;
            }
            break;
        }
        case LNA_SWITCH_OFF:
        {
            g_LnaSwitchOffSta[ioIdx][chan] = 1;
            if(BSP_OK==IsLnaAllChnsOff(ioIdx,ioTpye,sw))
            {
                ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);

            }
            g_LnaSwFlag[chan] = LNA_SWITCH_OFF;
            break;
        }
        default:
        {
            dbgInfo("[%s] LNA Switch Status is Error!!! Sta is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*AMP电源开关*/
UINT32 BspSetAmpSwitchCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(sw >AMP_SWITCH_ON_FDD)
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);
    if((BspGetAmpSwModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == AMP_SWITCH_ON))
    {
        sw = AMP_SWITCH_ON_FDD;
    }

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        return BspSetPaPowTxSwitchCtrl_Fpga(chan, sw);
    }

    ret |= BspGetAmpIoInfoByRfChn(chan,dir,&iochan);

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
   /*4.0LNA的IO开关1驱4，4通道全开则开，1通道关则关 4.2目前看都是1控1*/
   /*如果开1个通道实际没开，也返回OK*/
    switch(sw)
    {
        case AMP_SWITCH_ON:
        case AMP_SWITCH_ON_FDD:
        {
        	g_AmpSwitchOffSta[ioIdx][chan] = 0;
            ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);
            if(BSP_OK==ret)
            {
            	g_AmpSwFlag[chan] = AMP_SWITCH_ON;
            }
            break;
        }
        case AMP_SWITCH_OFF:
        {
        	g_AmpSwitchOffSta[ioIdx][chan] = 1;
            if(BSP_OK==IsLnaAllChnsOff(ioIdx,ioTpye,sw))
            {
                ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);

            }
            g_AmpSwFlag[chan] = AMP_SWITCH_OFF;
            break;
        }
        default:
        {
            dbgInfo("[%s] amp Switch Status is Error!!! Sta is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspSetTxSwitchCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(sw > TX_SWITCH_ON_FDD)
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);
    if((BspGetTxModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == TX_SWITCH_ON))
    {
        sw = TX_SWITCH_ON_FDD;
    }

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        return BspSetTxSwitchCtrl_Fpga(chan,sw);
    }

    ret |= BspGetTxEnIoInfoByRfChn(chan,dir,&iochan);

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
    switch(sw)
    {
        case TX_SWITCH_ON:
        case TX_SWITCH_ON_FDD:
        {
            g_TxSwitchOffSta[ioIdx][chan] = 0;
            ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);

            break;
        }
        case TX_SWITCH_OFF:
        {
            g_TxSwitchOffSta[ioIdx][chan] = 1;
            if(BSP_OK==IsTxAllChnsOff(ioIdx,ioTpye,sw))
            {
                 ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);
            }
            break;
        }

        default:
        {
            dbgInfo("[%s] Tx Switch Status is Error!!! Sta is %d.\n", __FUNCTION__, sw);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
UINT32 BspSetRxSwitchCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioType = 0;

    if(sw > RX_SWITCH_ON_FDD)
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);
    if((BspGetRxModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == RX_SWITCH_ON))
    {
        sw = RX_SWITCH_ON_FDD;
    }

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        return BspSetRxSwitchCtrl_Fpga(chan, sw);
    }

    ret |= BspGetRxEnIoInfoByRfChn(chan,dir,&iochan);

	ioIdx = iochan&0xf;
	ioType = (iochan>>8)&0xf;

	INPUT_PARAM_RANGE_CHECK(ioIdx, TDD_IO_PIN_NUM_COMMON_4);
	INPUT_PARAM_RANGE_CHECK(chan, CHN_NUM_PER_CHIP);

    switch(sw)
    {
        case RX_SWITCH_ON://1
        case RX_SWITCH_ON_FDD://2
        {
            g_RxSwitchOffSta[ioIdx][chan] = 0;
            ret |= BspSetTddIoOutSel(ioIdx,ioType,sw);
            break;
        }
        case RX_SWITCH_OFF://0
        {
            g_RxSwitchOffSta[ioIdx][chan] = 1;
            if(BSP_OK==IsRxAllChnsOff(ioIdx,ioType,sw))
            {
                 ret |= BspSetTddIoOutSel(ioIdx,ioType,sw);
            }
            break;
        }
        default:
        {
            dbgInfo("[%s] Rx Switch Status is Error!!! Sta is %d.\n", __FUNCTION__, sw);
            break;
        }
    }
    dbgInfoEx("%s:chan %d, sw %d, iochan 0x%x, ioIdx %d, ioType 0x%x, ret 0x%x, g_RxSwitchOffSta 0x%x\n",
        __FUNCTION__, chan, sw, iochan, ioIdx, ioType, ret, g_RxSwitchOffSta[ioIdx][chan]);

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
UINT32 BspSetFbSwitchCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(sw > FB_SWITCH_ON_FDD)
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);
    if((BspGetFbModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == FB_SWITCH_ON))
    {
        sw = FB_SWITCH_ON_FDD;
    }

    ret |= BspGetFbIoInfoByRfChn(chan,dir,&iochan);

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;

    switch(sw)
    {
        case FB_SWITCH_ON:
        case FB_SWITCH_ON_FDD:
        {
            //ret |= BspSwitchOffStaSet(iochan,LINK_INFO_FBCHN_TDDIO, &g_FbSwitchOffSta[iochan]);
            g_FbSwitchOffSta[ioIdx][chan] = 0;
            ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);

            break;
        }
        case FB_SWITCH_OFF:
        {
            g_FbSwitchOffSta[ioIdx][chan] = 1;
            if(BSP_OK==IsFbAllChnsOff(ioIdx,ioTpye,sw))
            {
                 ret |= BspSetTddIoOutSel(ioIdx,ioTpye,sw);
            }
            break;
        }
        default:
        {
            dbgInfo("[%s] Rx Switch Status is Error!!! Sta is %d.\n", __FUNCTION__, sw);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
/*对tx和rx来说  管脚号都只有0 1分别对应第1套和第二套ac_en模块*/
UINT32 BspSetTxAcSwitchCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;

    if(sw > TX_AC_SWITCH_ON_FDD)
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);

    if((BspGetTxAcModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == TX_AC_SWITCH_ON))
    {
        sw = TX_AC_SWITCH_ON_FDD;
    }

    if(BSP_OK != BspGetTxAcIoInfoByRfChn(chan,dir,&iochan))
    {
        dbgInfo("%s BspGetTxAcIoInfoByRfChn ERROR!!! chan = %d, sw = %d.\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);

    switch(sw)
    {
        case TX_AC_SWITCH_ON:
        {
            g_TxAcSwitchOffSta[iochan][chan] = TX_AC_SWITCH_ON;
            ret |= BspSetTxAcTddIoCfg(iochan,sw);
            break;
        }
        case TX_AC_SWITCH_OFF:
        {
            g_TxAcSwitchOffSta[iochan][chan] = TX_AC_SWITCH_OFF;
            ret |= BspSetTxAcTddIoCfg(iochan,sw);
            break;
        }
        case TX_AC_SWITCH_ON_FDD:
        {
            g_TxAcSwitchOffSta[iochan][chan] = TX_AC_SWITCH_ON_FDD;
            ret |= BspSetTxAcTddIoCfg(iochan,sw);
            break;
        }
        default:
        {
            dbgInfo("[%s] TxAc Switch Status is Error!!! Sta is %d\n", __FUNCTION__, sw);
            break;
        }
    }


    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspSetRxAcSwitchCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;

    if(sw > RX_AC_SWITCH_ON_FDD)
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, sw);

    if((BspGetRxAcModeCtrl(chan) == SWITCH_FDD_CTRL_MODE) && (sw == RX_AC_SWITCH_ON))
    {
        sw = RX_AC_SWITCH_ON_FDD;
    }

    if(BSP_OK != BspGetRxAcIoInfoByRfChn(chan,dir,&iochan))
    {
        dbgInfo("%s BspGetRxAcIoInfoByRfChn ERROR!!! chan = %d, sw = %d.\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d, iochan = 0x%x.\n", __FUNCTION__, chan, sw, iochan);

    switch(sw)
    {
        case RX_AC_SWITCH_ON:
        {
            g_RxAcSwitchOffSta[iochan][chan] = RX_AC_SWITCH_ON;
            ret |= BspSetRxAcTddIoCfg(iochan,sw);
            break;
        }
        case RX_AC_SWITCH_OFF:
        {
            g_RxAcSwitchOffSta[iochan][chan] = RX_AC_SWITCH_OFF;
            ret |= BspSetRxAcTddIoCfg(iochan,sw);
            break;
        }
        case RX_AC_SWITCH_ON_FDD:
        {
            g_RxAcSwitchOffSta[iochan][chan] = RX_AC_SWITCH_ON_FDD;
            ret |= BspSetRxAcTddIoCfg(iochan,sw);
            break;
        }
        default:
        {
            dbgInfo("[%s] RxAc Switch Status is Error!!! Sta is %d\n", __FUNCTION__, sw);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}


UINT32 BspSetAcCtrlSwitchCtrl(UINT32 type, UINT32 sw)
{

    UINT32 ret = BSP_OK;

    if(sw > AC_CTRL_SWITCH_ON_FDD)
    {
        dbgInfo("%s type [%d] sw [%d] is error!!!\n", __FUNCTION__, type, sw);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> type [%d] sw [%d].\n", __FUNCTION__, type, sw);

    if((BspGetAcCtrlModeCtrl(type) == SWITCH_FDD_CTRL_MODE) && (sw == AC_CTRL_SWITCH_ON))
    {
        sw = AC_CTRL_SWITCH_ON_FDD;
    }
    dbgInfoEx("%s >>>>>> type = %d, sw = %d.\n", __FUNCTION__, type, sw);

    ret |= BspSetAcCtrlTddIoCfg(type,sw);

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*.0 功放开关控制*/
/*****************************************************************************
 * 函数名称: BspSetPaFddSwitch(*)
 * 功能描述: 功放FDD模式设置，常发
 * 输入参数: chan - 天线通道号
 *       : sw   - 控制开关, 0: 关断, 1: 常发
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaFddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    CHECK_RF_CHAN_NUM(chan);
    if(sw >=PA_SWITCH_ON_FDD) /*入参必须是0 1*/
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    if(sw == PA_SWITCH_ON)
    {
        s_slavePaStatus[chan] = PA_SWITCH_ON_FDD;
        if((BspGetChanModeType(chan) == 1)&& (BspGetLnaSwitch(chan)!= LNA_SWITCH_OFF)) /*PA 常开时，lna必须是关着的*/
        {
    	     dbgErr("Error!!! chan %d is Tdd type,lna is not off,cannot switch paonfdd,please switch lnaoff first\n",chan);
     	     return BSP_ERROR;
        }
    }
    else
    {
        s_slavePaStatus[chan] = sw;
    }
    funcRet  = BspSetPaModeCtrl(chan, SWITCH_FDD_CTRL_MODE);
    funcRet |= BspSetPaSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetPaTddSwitch(*)
 * 功能描述: 功放Tdd模式设置，提供给高层控制开关
 * 输入参数: chan - 天线通道号
 *        : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaTddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    if(sw >=PA_SWITCH_ON_FDD) /*入参必须是0 1*/
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }

    if(sw == PA_SWITCH_ON)
    {
        if((BspGetChanModeType(chan) == 1)&& (BspGetLnaSwitch(chan)== LNA_SWITCH_ON_FDD)) /*PA tdd打开时，lna不能是常开*/
        {
     	     dbgErr("Error!!! chan %d is Tdd type,lna is fddon,cannot switch paon,please switch lnaoff first\n",chan);
     	     return BSP_ERROR;
        }
    }
    funcRet  = BspSetPaModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetPaSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetPaSwitch(*)
 * 功能描述: 功放开关设置，开和关，TDD模式
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaSwitchForUnNomal(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetPaTddSwitch(chan, sw);
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetPaSwitchSlaveOnline(*)
 * 功能描述: 子端在位时功放开关设置
 * 输入参数: chan - 天线通道号
 *          sw  - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: 子端在位时：开，先开子端，后开母端
 *                    关，先关母端，后关子端
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *----------------------------------------------------------------------------*/
static UINT32 BspSetPaSwitchSlaveOnline(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    if(chan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulTxChan %u Error!\n", chan);
        return BSP_ERROR;
    }

    if(SWITCH_ON == sw)
    {
        funcRet = BspSetRfsDevRfSwitch(chan, SWITCH_TYPE_PA, sw, 0);
        if(BSP_OK != funcRet)
        {
            s_slavePaStatus[chan] = 0;
        }
        else
        {
            s_slavePaStatus[chan] = sw;
        }
        funcRet |= BspSetPaTddSwitch(chan, sw);
    }
    if(SWITCH_OFF == sw)
    {
        funcRet = BspSetPaTddSwitch(chan, sw);
        funcRet |= BspSetRfsDevRfSwitch(chan, SWITCH_TYPE_PA, sw, 0);
        s_slavePaStatus[chan] = sw;
    }

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetPaSwitch(*)
 * 功能描述: 功放开关设置，开和关，TDD模式
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetPaSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 portId = 0;
    UINT32 portType = 0;
    UINT32 portSta = 0;
    UINT32 funcRet = BSP_OK;

    CHECK_RF_CHAN_NUM(chan);
    if (chan < CHN_NUM_PER_CHIP)
    {
        BspSetAppPaStatus(chan, sw);

        if((BspGetPaNormalFlag(chan) == PA_UNNORMAL) && (sw == SWITCH_ON))
        {
            return BSP_OK;
        }
    }

    BspGetPortIdByBspChn(chan, TX, &portId);
    BspGetSlavePortCfgTpye(portId, &portType);
    BspGetSlavePortCfgSta(portId, &portSta);
    dbgInfoEx("bspchan %d portId %d portType %d portSta %d\n", chan, portId, portType, portSta);
    if(SLAVE_PORT == portType)
    {
        if(ValidVal == portSta)
        {
            funcRet = BspSetPaSwitchSlaveOnline(chan, sw);
        }
        else  /*子端不在位时，仅设置母端开关，并将APP设置的开关状态存到全局变量*/
        {
            funcRet = BspSetPaTddSwitch(chan, sw);
            s_slavePaStatus[chan] = sw;
        }
    }
    else
    {
        funcRet = BspSetPaTddSwitch(chan, sw);
    }

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*.1 LNA电源开关控制*/
/*****************************************************************************
 * 函数名称: BspSetLnaFddSwitch(*)
 * 功能描述: LNA FDD模式设置，常收
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 常收
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaFddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;
    
    if(chan >= CHN_NUM_PER_CHIP)
    {
        return BSP_ERROR;
    }
    if(sw >=LNA_SWITCH_ON_FDD) /*入参必须是0 1*/
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    if(sw == LNA_SWITCH_ON)
    {
        s_slaveLnaStatus[chan] = LNA_SWITCH_ON_FDD;
        if((BspGetChanModeType(chan) == 1)&& (BspGetPaSwitch(chan)!= PA_SWITCH_OFF)) /*lna常开时，pa必须关闭*/
        {
     	     dbgErr("Error!!! chan %d is Tdd type,pa is not off,cannot switch lnaonfdd,please switch paoff first\n",chan);
     	     return BSP_ERROR;
        }
    }
    else
    {
        s_slaveLnaStatus[chan] = sw;
    }
    funcRet  = BspSetLnaModeCtrl(chan, SWITCH_FDD_CTRL_MODE);
    funcRet |= BspSetLnaSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetLnaTddSwitch(*)
 * 功能描述: LNA TDD模式设置，常收
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 常发
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaTddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    if(sw >=LNA_SWITCH_ON_FDD) /*入参必须是0 1*/
    {
        dbgInfo("%s chan [%d] sw [%d] is error!!!\n", __FUNCTION__, chan, sw);
        return BSP_ERROR;
    }
    if(sw == LNA_SWITCH_ON)
    {
        if((BspGetChanModeType(chan) == 1)&& (BspGetPaSwitch(chan)== PA_SWITCH_ON_FDD)) /*lna tdd打开时，pa不能常开*/
        {
     	     dbgErr("Error!!! chan %d is Tdd type,pa is fddon,cannot switch lnaon,please switch paoff first\n",chan);
     	     return BSP_ERROR;
        }
    }
    funcRet  = BspSetLnaModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetLnaSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*.2 amp开关控制 4.2上*/
UINT32 BspSetAmpTddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;


    funcRet  = BspSetAmpModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetAmpSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}
UINT32 BspSetAmpFddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet  = BspSetAmpModeCtrl(chan, SWITCH_FDD_CTRL_MODE);
    funcRet |= BspSetAmpSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}
/*AMP开关控制*/
UINT32 BspSetAmpSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetAmpTddSwitch(chan, sw);
    BspLog(LOG_LEVEL_0,"%s{%d,%d} ok\n",__FUNCTION__,chan,sw);
    return funcRet;
}
/*****************************************************************************
 * 函数名称: BspSetLnaSwCtrl(*)
 * 功能描述: 设置FPGA输出到LNA的信号开关。  低噪放开关使能0x56,3.0未按规范使用寄存器 4.0和4.2 只有LNA电源开关（0x45），没有这个
 * 4.0和4.2 只有LNA电源开关（0x45），没有这个
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaSwCtrl(UINT32 chan, UINT32 sw)
{
    /*4.0 上未修改实现，仍然访问fpga 0x54*/
    return BSP_OK;
}
/****************************************************************************
 * 函数名称: BspSetLnaBypassCtrl(*)
 * 功能描述: 设置FPGA输出到LNA的信号开关。 LNA旁路 0x57寄存器
 *  4.0和4.2 只有LNA电源开关（0x45），没有这个
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaBypassCtrl(UINT32 chan, UINT32 sw)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}

static UINT32 BspSetLnaSwitchSlaveOnline(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    if(chan >= CHN_NUM_PER_CHIP)
    {
        dbgInfo("ulRxChan %u Error!\n", chan);
        return BSP_ERROR;
    }

    funcRet = BspSetRfsDevRfSwitch(chan, SWITCH_TYPE_DSLNA, sw, 0);
    if(BSP_OK != funcRet)
    {
        s_slaveLnaStatus[chan] = 0;
    }
    else
    {
        s_slaveLnaStatus[chan] = sw;
    }
    funcRet |= BspSetLnaTddSwitch(chan, sw);

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetLnaSwitch(*)
 * 功能描述: LNA_pwr开关设置，开和关，TDD设置
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 portId = 0;
    UINT32 portType = 0;
    UINT32 portSta = 0;
    UINT32 funcRet = BSP_OK;

    if(chan >= CHN_NUM_PER_CHIP)
    {
        return BSP_ERROR;
    }

    BspGetPortIdByBspChn(chan, TX, &portId);
    BspGetSlavePortCfgTpye(portId, &portType);
    BspGetSlavePortCfgSta(portId, &portSta);
    dbgInfoEx("bspchan %d portId %d portType %d portSta %d\n", chan, portId, portType, portSta);
    if(SLAVE_PORT == portType)
    {
        if(ValidVal == portSta)
        {
            funcRet = BspSetLnaSwitchSlaveOnline(chan, sw);
        }
        else
        {
            funcRet = BspSetLnaTddSwitch(chan, sw);
            s_slaveLnaStatus[chan] = sw;
        }
    }
    else
    {
        funcRet = BspSetLnaTddSwitch(chan, sw);
    }
    BspLog(LOG_LEVEL_0,"%s{%d,%d} ok\n",__FUNCTION__,chan,sw);
    return funcRet;
}
/*.3 transceiver TX_EN开关控制*/
UINT32 BspSetTxSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    
    retVal = BspSetTxModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    retVal |= BspSetTxSwitchCtrl(chan, sw);
    
    BspLog(LOG_LEVEL_0,"%s{%d,%d} ok\n",__FUNCTION__,chan,sw);
    dbgInfoEx("%s >>>>>> chan = %d, sw = %d.\n", __FUNCTION__, chan, sw);
    return retVal;
}

UINT32 BspSetTxSwitchFdd(UINT32 chan, UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSetTxModeCtrl(chan, SWITCH_FDD_CTRL_MODE);
    retVal |= BspSetTxSwitchCtrl(chan, sw);
    
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    dbgInfoEx("%s >>>>>> chan = %d, sw = %d.\n", __FUNCTION__, chan, sw);
    return retVal;
}
/*.4 transceiver RX_EN开关控制*/
UINT32 BspSetRxSwitch(UINT32 chan,UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    //减少冗余打印
    //BspLog(LOG_LEVEL_0,"%s{%d,%d} enter\n",__FUNCTION__,chan,sw);

    retVal = BspSetRxModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    retVal |= BspSetRxSwitchCtrl(chan, sw);  

    BspLog(LOG_LEVEL_0,"%s{%d,%d} ok\n",__FUNCTION__,chan,sw);

    dbgInfoEx("%s >>>>>> chan = %d, sw = %d.\n", __FUNCTION__, chan, sw);
    return retVal;
}
UINT32 BspSetRxSwitchFdd(UINT32 chan, UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSetRxModeCtrl(chan, SWITCH_FDD_CTRL_MODE);
    retVal |= BspSetRxSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    dbgInfoEx("%s >>>>>> chan = %d, sw = %d.\n", __FUNCTION__, chan, sw);
    return retVal;
}
/*transceiver RX_EN开关控制*/
UINT32 BspSetRxSwitchAll(UINT32 isOn)
{
    UINT32 loop  = 0;
    UINT32 retVal = BSP_OK;

    for (loop = 0; loop < BspGetRxChannel(); loop++)
    {
        retVal |= BspSetRxSwitch(loop,isOn);
    }
    return retVal;
}
/* transceiver TX_EN RX_EN开关控制*/
UINT32 BspSetTrxEnTddSwitch(UINT32 chan, UINT32 sw, UINT32 dir)
{
    UINT32 funcRet = BSP_OK;

    if(dir == LINK_TYPE_TX)
    {
        funcRet  = BspSetTxModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
        funcRet |= BspSetTxSwitchCtrl(chan, sw);
    }
    else if(dir == LINK_TYPE_RX)
    {
        funcRet  = BspSetRxModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
        funcRet |= BspSetRxSwitchCtrl(chan, sw);
    }
    else
    {
        dbgErr("%s>>> dir[%d] is error!!!", __FUNCTION__, dir);
    }

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}
/* transceiver TX_EN RX_EN*/
UINT32 BspSetTrxEnSwitch(UINT32 chan, UINT32 sw, UINT32 dir)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetTrxEnTddSwitch(chan, sw, dir);
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/* transceiver ORX_EN开关控制*/
UINT32 BspSetFbTddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet  = BspSetFbModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetFbSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);

    return funcRet;
}
UINT32 BspSetFbSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetFbTddSwitch(chan, sw);
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}
/*.5 transceiver TXAC_EN开关控制*/
UINT32 BspSetTxAcSwitch(UINT32 chan, UINT32 sw)
{

    UINT32 retVal = BSP_OK;

    retVal = BspSetTxAcModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    retVal |= BspSetTxAcSwitchCtrl(chan, sw);
    
    BspLog(LOG_LEVEL_0,"%s{%d,%d} ok\n",__FUNCTION__,chan,sw);
    return retVal;
}
/*.6 transceiver RXAC_EN开关控制*/
UINT32 BspSetRxAcSwitch(UINT32 chan,UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSetRxAcModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    retVal |= BspSetRxAcSwitchCtrl(chan, sw);  

    BspLog(LOG_LEVEL_0,"%s{%d,%d} ok\n",__FUNCTION__,chan,sw);
    return retVal;
}

/*transceiver TXAC_EN RXAC_EN开关控制*/
UINT32 BspSetTrxAcTddSwitch(UINT32 chan, UINT32 sw, UINT32 dir)
{
    UINT32 funcRet = BSP_OK;
    //BspLog(LOG_LEVEL_0, "%s{%d,%d,%d} enter\n", __FUNCTION__, chan, sw, dir);

    if(dir == LINK_TYPE_TX)
    {
        funcRet  = BspSetTxAcModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
        funcRet |= BspSetTxAcSwitchCtrl(chan, sw);
    }
    else if(dir == LINK_TYPE_RX)
    {
        funcRet  = BspSetRxAcModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
        funcRet |= BspSetRxAcSwitchCtrl(chan, sw);
    }
    else
    {
        dbgErr("%s>>> dir[%d] is error!!!", __FUNCTION__, dir);
    }

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}
/*transceiver TXAC_EN RXAC_EN开关控制*/
UINT32 BspSetTrxAcSwitch(UINT32 chan, UINT32 sw, UINT32 dir)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetTrxAcTddSwitch(chan, sw, dir);
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}
/*AC CTRL控制*/
UINT32 BspSetAcCtrlTddSwitch(UINT32 type, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetAcCtrlModeCtrl(type, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetAcCtrlSwitchCtrl(type, sw);

    return funcRet;
}
/*AC CTRL控制 TDD*/
UINT32 BspSetAcCtrlSwitch(UINT32 type, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetAcCtrlTddSwitch(type, sw);

    return funcRet;
}

/*AC CTRL控制 FDD*/
UINT32 BspSetAcCtrlFddSwitch(UINT32 type, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;
    //BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, type, sw);

    funcRet = BspSetAcCtrlModeCtrl(type, SWITCH_FDD_CTRL_MODE);
    funcRet |= BspSetAcCtrlSwitchCtrl(type, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, type, sw);
    return funcRet;
}
/*AC CTRL控制 FDD*/
UINT32 BspSetAcCtrlSwitchFdd(UINT32 type, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet = BspSetAcCtrlFddSwitch(type, sw);
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, type, sw);
    return funcRet;
}

/*下行小信号放大控制*/
UINT32 BspSetPaPowTxSwitchCtrl(UINT32 chan,UINT32 onOff)
{
    (void)BspSetAmpSwitchCtrl(chan, onOff);
    return BSP_OK;
}
/*下行小信号放大控制*/
UINT32 BspGetPaPowTxSwitchCtrl(UINT32 chan)
{
    UINT32 onOff      = 0;
    onOff = BspGetAmpSwitch(chan);
    return onOff;
}
/*下行小信号放大控制 4.2没有*/
UINT32 BspSetPaPowTxFddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;
    //BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);

    funcRet  = BspSetPaPowTxModeCtrl(chan, SWITCH_FDD_CTRL_MODE);
    funcRet |= BspSetPaPowTxSwitchCtrl(chan, sw);

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*下行小信号放大控制*/
UINT32 BspSetPaPowTxTddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet  = BspSetPaPowTxModeCtrl(chan, SWITCH_TDD_CTRL_MODE);
    funcRet |= BspSetPaPowTxSwitchCtrl(chan, sw);
    return funcRet;
}
/*控制下行小信号放大器开关-0x42寄存器*/
UINT32 BspSetPaPowTxSwitch(UINT32 chan, UINT32 sw)
{
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return BspSetPaPowTxTddSwitch(chan,sw);
}

/*初始化每个acctrl管脚在三种模式下的开关状态 单板下传入*/
UINT32 BspInitAcCtrlSwitchPara(T_TDDIO_AC_SWITCH_PARA *pAcSwitchPara, UINT32 paraNum)
{
    s_ulTddIoAcSwitchPara = pAcSwitchPara;
    s_TddIoAcSwitchParaNum = paraNum;

    return BSP_OK;
}

/*设置AC 控制管脚开关 和固定ATT管脚开关  由于4.2上ac使用哪些通道不固定 */
UINT32 BspSetTddIoAcCtrlSwitch(UINT32 acType)
{
    UINT32 retVal = BSP_OK;
    UINT32 loopIndex = 0;
    UINT32 acSwitch = 0;
    UINT32 paraType = 0;
    UINT32 acCtrlType = 0;
    UINT32 bandNo = 0;

    INPUT_POINTER_CHECK(s_ulTddIoAcSwitchPara);
    bandNo = BspGetAcBandNo();
    if((E_AC_TYPE_UL == acType)||(E_AC_TYPE_FDD_UL == acType))
    {
    	paraType = 2;    /*上行AC*/
    }
    else if((E_AC_TYPE_DL == acType)||(E_AC_TYPE_FDD_DL == acType))
    {
    	paraType = 1;    /*下行AC*/
    }
    else
    {
    	paraType = 0;    /*正常TDD 2 11*/
    }
    for(loopIndex = 0; loopIndex < s_TddIoAcSwitchParaNum; loopIndex++)
    {
        dbgInfoEx("acCtrlType %d, bandNo %d \n", s_ulTddIoAcSwitchPara[loopIndex].acCtrlType,s_ulTddIoAcSwitchPara[loopIndex].bandNo);
        if(bandNo == s_ulTddIoAcSwitchPara[loopIndex].bandNo)
        {
             acCtrlType = s_ulTddIoAcSwitchPara[loopIndex].acCtrlType;
             acSwitch = s_ulTddIoAcSwitchPara[loopIndex].switchPara[paraType];
             retVal |= BspSetAcCtrlSwitch(acCtrlType, acSwitch);
             dbgInfoEx("acCtrlType %d, paraType %d acSwich %d\n",acCtrlType,paraType,acSwitch);
             BspLog(LOG_LEVEL_0, "%s: acCtrlType %d, paraType %d acSwich %d\n", __FUNCTION__,acCtrlType,paraType,acSwitch);
        }
    }

    return retVal;
}

/*设置AC 控制管脚开关 和固定ATT管脚开关  由于4.2上ac使用哪些通道不固定(工装打开) */
UINT32 BspSetTddIoAcCtrlSwitchFdd(UINT32 acType)
{
    UINT32 retVal = BSP_OK;
    UINT32 loopIndex = 0;
    UINT32 acSwitch = 0;
    UINT32 paraType = 0;
    UINT32 acCtrlType = 0;
    UINT32 bandNo = 0;

    INPUT_POINTER_CHECK(s_ulTddIoAcSwitchPara);
    bandNo = BspGetAcBandNo();
    if((E_AC_TYPE_UL == acType)||(E_AC_TYPE_FDD_UL == acType))
    {
        paraType = 2;    /*上行AC*/
    }
    else if((E_AC_TYPE_DL == acType)||(E_AC_TYPE_FDD_DL == acType))
    {
        paraType = 1;    /*下行AC*/
    }
    else
    {
        paraType = 0;    /*正常TDD 2 11*/
    }
    for(loopIndex = 0; loopIndex < s_TddIoAcSwitchParaNum; loopIndex++)
    {
        dbgInfoEx("acCtrlType %d, bandNo %d \n", s_ulTddIoAcSwitchPara[loopIndex].acCtrlType,s_ulTddIoAcSwitchPara[loopIndex].bandNo);
        if(bandNo == s_ulTddIoAcSwitchPara[loopIndex].bandNo)
        {
             acCtrlType = s_ulTddIoAcSwitchPara[loopIndex].acCtrlType;
             acSwitch = s_ulTddIoAcSwitchPara[loopIndex].switchPara[paraType];
             retVal |= BspSetAcCtrlSwitchFdd(acCtrlType, acSwitch);
             dbgInfoEx("acCtrlType %d, paraType %d acSwich %d\n",acCtrlType,paraType,acSwitch);
             BspLog(LOG_LEVEL_0, "%s: acCtrlType %d, paraType %d acSwich %d\n", __FUNCTION__,acCtrlType,paraType,acSwitch);
        }
    }

    return retVal;
}

/*****************************************************************************
 * 函数名称: BspSetLnaPowRxSwitchCtrl(*)
 * 功能描述: 设置RX POW开关     上行小信号放大器开关 0x44寄存器
 *----------------------------------------------------------------------------*/
UINT32 BspSetLnaPowRxSwitchCtrl(UINT32 chan,UINT32 onOff)
{
    /*A9651A S26机型应该是没有专门的小信号放大器开关配置的，硬件上，下行小信号放大器开关和TX_EN合并，上行没有小信号放大器*/
    return BSP_OK;
}
/*****************************************************************************
 * 功能描述: 获取RX POW开关为FDD模式  上行小信号放大器开关 0x44寄存器
 */
UINT32 BspSetLnaPowRxFddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;
    //减少冗余打印
    //BspLog(LOG_LEVEL_0, "%s{%d,%d} enter\n", __FUNCTION__, chan, sw);

    funcRet  = BspSetLnaPowRxModeCtrl(chan, SWITCH_FDD_CTRL_MODE);//0x9050的bit13写1置成FDD
    funcRet |= BspSetLnaPowRxSwitchCtrl(chan, sw);                //0x9051对低8bit按bit位写0或者写1

    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetLnaPowRxTddSwitch(*)
 * 功能描述: 设置RX POW开关为TDD模式
 */
UINT32 BspSetLnaPowRxTddSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 funcRet = BSP_OK;

    funcRet  = BspSetLnaPowRxModeCtrl(chan, SWITCH_TDD_CTRL_MODE);//0x9050的bit13写0置成TDD
    funcRet |= BspSetLnaPowRxSwitchCtrl(chan, sw);                //0x9051对低8bit按bit位写0或者写1

    return funcRet;
}

/*****************************************************************************
 * 函数名称: BspSetLnaPowRxSwitch(*)
 * 功能描述: RX POW开关在TDD模式下的开关控制
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 常发
 *----------------------------------------------------------------------------
 */
UINT32 BspSetLnaPowRxSwitch(UINT32 chan, UINT32 sw)
{
    BspLog(LOG_LEVEL_0, "%s{%d,%d} ok\n", __FUNCTION__, chan, sw);
    return BspSetLnaPowRxTddSwitch(chan,sw);
}
/*********************************************开关状态获取接口************************************************/
UINT32 IsPaAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
{
    UINT32 chn = 0;
    UINT32 rst = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
    for(chn = 0; chn < Val.rfChNum; chn++)
    {
        if(sw == g_PaSwitchOffSta[ioChan][Val.rfCh[chn]])
        {
            rst += g_PaSwitchOffSta[ioChan][Val.rfCh[chn]];
        }
        dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d\n", ioChan, Val.rfCh[chn], g_PaSwitchOffSta[ioChan][Val.rfCh[chn]]);
    }
    if(rst == sw * Val.rfChNum)
    {
        return BSP_OK;
    }

    return BSP_ERROR;
 }

 UINT32 IsPaAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
{
    UINT32 chn = 0;
    UINT32 rst = 0;
    T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

    BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
    for(chn = 0; chn < Val.rfChNum; chn++)
    {
        if(1 == g_PaSwitchOffSta[ioChan][Val.rfCh[chn]])
        {
            rst += g_PaSwitchOffSta[ioChan][Val.rfCh[chn]];
        }
        dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d\n", ioChan, Val.rfCh[chn], g_PaSwitchOffSta[ioChan][Val.rfCh[chn]]);
    }
    if(rst == Val.rfChNum)
    {
        return BSP_OK;
    }

    return BSP_ERROR;
 }

/**************************************************************************
 * 函数名称: BspSetLnaSwitchCtrl
 * 功能描述: Lna开关
 * 输入参数: 开关选择，0关闭，1打开
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年3月03日                       创建
 **************************************************************************/
UINT32 IsLnaAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(sw == g_LnaSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_LnaSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_LnaSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == sw * Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsLnaAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(1 == g_LnaSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_LnaSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_LnaSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsAmpAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(sw == g_AmpSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_AmpSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_AmpSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == sw*Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsAmpAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(1 == g_AmpSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_AmpSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_AmpSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}


UINT32 IsRxAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(sw == g_RxSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_RxSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d\n", ioChan, Val.rfCh[chn], g_RxSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == sw*Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsRxAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(1 == g_RxSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_RxSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_RxSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsFbAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(sw == g_FbSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_FbSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_FbSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == sw*Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsFbAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(1 == g_FbSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_FbSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_FbSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsTxAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(sw == g_TxSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_TxSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_TxSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == sw*Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 IsTxAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};

     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(1 == g_TxSwitchOffSta[ioChan][Val.rfCh[chn]])
         {
             rst += g_TxSwitchOffSta[ioChan][Val.rfCh[chn]];
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], g_TxSwitchOffSta[ioChan][Val.rfCh[chn]]);
     }
     if(rst == Val.rfChNum)
     {
         return BSP_OK;
     }

     return BSP_ERROR;
}

UINT32 BspChangePaSwitchCtrl(UINT32 sw)
{
    UINT32 realSw = sw;
    if (pGetPaSwitchSta != NULL)
    {
        realSw = pGetPaSwitchSta(sw);
    }
    return realSw;
}

/*****************************************************************************
 *
 * 函数名称: BspGetPaSwitchCtrl(*)
 * 功能描述: 获取FPGA输出到PA的信号开关
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- 关, 1- 开, BSP_ERROR- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaSwitchCtrl(UINT32 chan)
{
    UINT32 paSwCtrl    = PA_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 paMuxRst = 0;
    UINT32 ret = BSP_OK;
    UINT32 ioIdx  = 0;
    UINT32 ioType  = 0;
    UINT32 realSw = 0;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo)
    {
        INPUT_BSPCHN_CHECK(chan);
        if (FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[chan] && NULL != pFpgaInfo->pFuncGetFpgaPaSw)
        {
            realSw = pFpgaInfo->pFuncGetFpgaPaSw(chan);
            return realSw;
        }
    }

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        realSw = BspGetPaSwitch_Fpga(chan);
        return realSw;
    }

    ret = BspGetPaIoInfoByRfChn(chan,dir,&iochan); /*依赖于chanmap中的丝印，4.2目前看没有1对多*/
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

	ioIdx = iochan&0xf;
	ioType = (iochan>>8)&0xf;
    ret |= BspGetTddIoOutSel(ioIdx,ioType, &paMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    paSwCtrl = BspGetTddIoSwitch(ioType,paMuxRst);

    if(PA_PMOS_CTRL_WITH_GRID_VOLT == BspGetPaSwCtrlMode()) /*4.0上IO 一控多，所以需要结合栅压才能判断真正的开关状态*/
    {
        /*保存的栅压状态为关时，才返回关。其他场景下，直接返回io真实状态，
        防止有人底层直接操作io，导致软件上报状态错误。
        这种处理方式仍无法解决直接操作底层栅压接口，暂时不考虑*/
        if(PA_SWITCH_OFF == g_PaSwFlag[chan])
        {
            return PA_SWITCH_OFF;
        }
    }

    realSw = BspChangePaSwitchCtrl(paSwCtrl);

    return realSw;
}

/*
rfSwSta：开关状态，0关1开
bit0  : ch0_amp
bit1  : ch0_pa
bit2  : ch0_trx
bit3  : ch0_dslna
bit4  : ch0_lna
bit5  : ch0_dpdsw
bit8  : ch1_amp
bit9  : ch1_pa
bit10 : ch1_trx
bit11 : ch1_dslna
bit12 : ch1_lna
bit13 : ch1_dpdsw
*/
static UINT32 BspGetSlavePortRfSwitch(UINT32 chan, UINT32 dir, UINT32 *sw)
{
    UINT32 portId = 0;
    UINT32 slaveChn = 0;
    T_SlavePortRfSwitchSta rfSw = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(sw);
    BspGetPortIdByBspChn(chan, dir, &portId);
    BspGetPortSlaveChnByBspChn(chan, TX, &slaveChn);
    retVal = BspGetRfsDevRfSwitch(portId, &rfSw);
    if(TX == dir)
    {
        *sw = ((UINT32)rfSw.rfSwSta >> (1 + slaveChn * 8)) & 0x1;
    }
    else
    {
        *sw = ((UINT32)rfSw.rfSwSta >> (3 + slaveChn * 8)) & 0x1;
    }
    return retVal;
}

UINT32 BspGetPaSwitch(UINT32 chan)
{
    UINT32 portId = 0;
    UINT32 portType = 0;
    UINT32 paSwitch = PA_SWITCH_OFF;

    CHECK_RF_CHAN_NUM(chan);

    if(BspGetPaNormalFlag(chan) == PA_UNNORMAL)
    {
        return g_ulPaStatus[chan];
    }

    BspGetPortIdByBspChn(chan, TX, &portId);
    BspGetSlavePortCfgTpye(portId, &portType);
    if(SLAVE_PORT == portType)  /*子端开关状态从全局变量获取*/
    {
        paSwitch = BspGetPaSwitchCtrl(chan);
        paSwitch &= s_slavePaStatus[chan];
    }
    else
    {
        paSwitch = BspGetPaSwitchCtrl(chan);
    }

    return paSwitch;
}
/*****************************************************************************
 * 函数名称: BspGetLnaSwitchCtrl(*)
 * 功能描述: 设置FPGA输出到LNA PWR的信号开关。
 * 输入参数: chan - 天线通道号
 * 输出参数: 无
 * 返 回 值: 0- 关, 1- 开, BSP_ERROR- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaSwitchCtrl(UINT32 chan)
{
    UINT32 lnaSwCtrl    = LNA_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 lnaMuxRst = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;
    UINT32 ioIdx  = 0;
    UINT32 ioType  = 0;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo)
    {
        INPUT_BSPCHN_CHECK(chan);
        if(FPGA_CHAN == pFpgaInfo->rxFpgaChanFlag[chan] && NULL != pFpgaInfo->pFuncGetFpgaLnaSw)
        {
            return pFpgaInfo->pFuncGetFpgaLnaSw(chan);
        }
    }

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        lnaSwCtrl = BspGetLnaSwitch_Fpga(chan);
        return lnaSwCtrl;
    }

    ret = BspGetLnaIoInfoByRfChn(chan,dir,&iochan);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }
	ioIdx = iochan&0xf;
	ioType = (iochan>>8)&0xf;
    ret |= BspGetTddIoOutSel(ioIdx,ioType, &lnaMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    lnaSwCtrl = BspGetTddIoSwitch(ioType,lnaMuxRst);
    return lnaSwCtrl;
}
UINT32 BspGetLnaSwitch(UINT32 chan)
{
    UINT32 portId = 0;
    UINT32 portType = 0;
    UINT32  portSta  = 0;
    UINT32 lnaSwitch = LNA_SWITCH_OFF;

    if(chan >= CHN_NUM_PER_CHIP)
    {
        return BSP_ERROR;
    }
    BspGetPortIdByBspChn(chan, TX, &portId);
    BspGetSlavePortCfgTpye(portId, &portType);
    BspGetSlavePortCfgSta(portId, &portSta);
    if(SLAVE_PORT == portType)
    {
        lnaSwitch = BspGetLnaSwitchCtrl(chan);
        lnaSwitch &= s_slaveLnaStatus[chan];
    }
    else
    {
        lnaSwitch = BspGetLnaSwitchCtrl(chan);
    }

    return lnaSwitch;
}
/*****************************************************************************
 * 函数名称: BspGetLnaSwitchCtrl(*)
 *   获取低噪放的开关使能
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaSwCtrl(UINT32 chan)
{
	/*4.0 上未修改实现，仍然访问fpga 0X54 控制LNA_SW*/
    return BSP_OK;
}
/****************************************************************************
 * 函数名称: BspGetLnaSwitchCtrl(*)
 * 功能描述: 获取低噪放的旁路使能
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaBypassCtrl(UINT32 chan)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}
/****************************************************************************
 * 函数名称: BspGetPaPowTxSwitch(*)
 * 功能描述: 获取下行小信号放大器的开关状态
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaPowTxSwitch(UINT32 chan)
{
    return BspGetPaPowTxSwitchCtrl(chan);
}

/*****************************************************************************
 * 函数名称: BspGetLnaPowRxSwitchCtrl(*)
 * 功能描述: 获取RX POW开关   获取上行行小信号放大器的开关状态
 *----------------------------------------------------------------------------
 */
UINT32 BspGetLnaPowRxSwitchCtrl(UINT32 chan)
{
    UINT32 onOff      = 0;
     /*A9651A S26机型应该是没有专门的小信号放大器开关配置的，硬件上，下行小信号放大器开关和TX_EN合并，上行没有小信号放大器*/
    return onOff;
}

UINT32 BspGetLnaPowRxSwitch(UINT32 chan)
{
    return BspGetLnaPowRxSwitchCtrl(chan);
}

/*****************************************************************************
 * 函数名称: BspFpgaSetPaPwrSwitch(*)
 * 功能描述: pa 电源控制 28V、48V    PA漏压开关控制（48/28V 输出控制）--0x47寄存器
 * 输入参数: chan - 天线通道号
 *         : sw   - 控制开关, 0: 关断, 1: 打开
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 *           本接口是由逻辑控制的28V总开关
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
//UINT32 BspSetPaPwrSwitch(UINT32 chan, UINT32 sw)
UINT32 BspFpgaSetPaPwrSwitch(UINT32 chan, UINT32 sw)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}
/* PA漏压开关控制（48/28V 输出控制）*/
UINT32 BspFpgaGetPaPwrSwitch(UINT32 chan, UINT32* sw)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}
//获取-8V电源告警
UINT32 BspGetPaNegaVccStatus(UINT32 *pStatus)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}

UINT32 BspClrPaNegaVccAlarm(UINT32 chanNo)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}
/*pmos开关--0x47寄存器*/
UINT32 BspPaPowerPmosSwitch(UINT32 chanNo, UINT32 switchCtrl)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}
/*功放漏压控制相关4.2目前看不需要 BspFpgaSetPaPwrSwitch BspFpgaGetPaPwrSwitch  BspGetPaNegaVccStatus BspClrPaNegaVccAlarm BspPaPowerPmosSwitch */
UINT32 BspSetPaPwrSwitch(UINT32 chan, UINT32 sw)
{
    UINT32 ret     = BSP_OK;

    switch (BspGetPaPwrCtrlMethod())
    {
        case E_PA_PMOS_PWR_CTRL_METHOD_FPGA:
        {
            if (PA_PMOS_CTRL_WITH_FPGA_REPLACE_GPIO == BspGetPaPmosCtrlFpgaMode())
            {
                ret = BspPaPowerPmosSwitch(chan, sw);
            }
            else
            {
                ret = BspFpgaSetPaPwrSwitch(chan, sw);
            }
            break;
        }
        case E_PA_PMOS_PWR_CTRL_METHOD_NULL:/*无Pa漏压电源开关*/
        {
            dbgInfoEx("%s>>No PA PMOS PWR CTRL !\n",__FUNCTION__);            
            return BSP_OK;
        }
        case E_PA_PMOS_PWR_CTRL_METHOD_DAC:  /*D3切D4部分机型，通过栅压开关控制*/
        {
            ret = BspSetPaSwitchCtrl(chan, sw);
            break;
        }
        default:
        {
            dbgErr("[%s]case switch error!\n", __FUNCTION__);
            return BSP_ERROR;
        }
    }
    
    BspLog(LOG_LEVEL_0, "%s{%d,%d} %s\n", __FUNCTION__, chan, sw, (BSP_OK == ret) ? "OK" : "Err");
    return ret;
}

UINT32 BspGetPaPwrSwitch(UINT32 chan, UINT32* status)
{
    UINT32 ret = BSP_OK;
    UINT32 sw  = 0;

    INPUT_POINTER_CHECK(status);
    
    switch (BspGetPaPwrCtrlMethod())
    {
        case E_PA_PMOS_PWR_CTRL_METHOD_FPGA://A8101NR / A9603 由FPGA控
        {
            if (PA_PMOS_CTRL_WITH_FPGA_REPLACE_GPIO == BspGetPaPmosCtrlFpgaMode())
            {
              //  ret = BspGetPaPowerPmosSwitch(chan, &sw); //A9611E S49A/S49B采用fpga寄存器控制PMOS
            }
            else
            {
                ret = BspFpgaGetPaPwrSwitch(chan, &sw);
            }
            break;
        }
        case E_PA_PMOS_PWR_CTRL_METHOD_NULL:/*无Pa漏压电源开关*/
        {
            dbgInfoEx("%s>>No PA PMOS PWR CTRL !\n",__FUNCTION__);
            return BSP_OK;
        }
        default:
        {
            ret = BSP_ERROR;
            dbgErr("[%s]case switch error!\n", __FUNCTION__);
            break;
        }
    }
    
    *status = sw;
    return ret;
}

/*****************************************************************************
 * 函数名称: BspGetPaPwrOffStatus(*)
 * 功能描述: 获取功放掉电状态
 * 输入参数: chan    - 功放索引
 * 输出参数: pStatus - 输出状态指针
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 * 工装申明:
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaPwrOffStatus(UINT32 chan, UINT32 *pStatus)
{
	/*4.0 上未修改实现，仍然访问fpga*/
    return BSP_OK;
}

/*****************************************************************************
 * 函数名称: BspGetPaStatus(*)
 * 功能描述: 查看PA是否正常存在，有的RRU PA是插板式的。
 * 输入参数: chan    - 功放索引
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功, 其他- 失败
 * 其它说明: RRU公共接口函数
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 10119095@2017-11-02, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetPaStatus(UINT32 chan)
{
    return BSP_OK;
}

UINT32 BspSetPaSwitchOnOff(UINT32 chan, UINT32 sw)
{
    CHECK_RF_CHAN_NUM(chan);
    if (BspGetPaSwMethod() == PA_SWITCH_CTRL_FOURINONE)
    {
        pPaSwCtrlCallBack(chan, sw);
    }

    if(PA_TDD_SEL_MODE != s_tddFddSelMode)
    {
        s_slavePaStatus[chan] = PA_TDD_SEL_MODE;
    }
    else
    {
        s_slavePaStatus[chan] = sw;
    }
    return BspSetPaSwitchCtrl(chan, sw);
}

UINT32 BspSetLnaSwitchOnOff(UINT32 chan, UINT32 sw)
{
    if(chan >= CHN_NUM_PER_CHIP)
    {
        return BSP_ERROR;
    }
    if(LNA_CTRL_WITH_PWR_SW_BYPASS == BspGetLnaSwCtrlMode())
    {
        BspSetLnaSwCtrl(chan, sw);
        BspSetLnaBypassCtrl(chan, sw);
    }

    if(PA_TDD_SEL_MODE != s_tddFddSelMode)
    {
        s_slaveLnaStatus[chan] = PA_TDD_SEL_MODE;
    }
    else
    {
        s_slaveLnaStatus[chan] = sw;
    }
    return BspSetLnaSwitchCtrl(chan, sw);
}

UINT32 BspPwrSavePaCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 retPa = BSP_OK;
    retPa = BspSetPaSwitch(chan, sw);
    return retPa;
}

UINT32 BspPwrSaveLnaCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 retLna = BSP_OK;
    retLna = BspSetLnaSwitch(chan, sw);
    return retLna;
}

UINT32 BspPwrSavePmosCtrl(UINT32 chan, UINT32 sw)
{
    UINT32 ret = BSP_OK;
    ret = BspSetPaPwrSwitch( chan,  sw);
    return ret;
}

UINT32 BspGetAmpSwitch(UINT32 chan)
{
    UINT32 ampSwCtrl    = TX_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ampMuxRst = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;
    UINT32 ioIdx  = 0;
    UINT32 ioType  = 0;

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        ampSwCtrl = BspGetPaPowTxSwitch_Fpga(chan);
        return ampSwCtrl;
    }

    ret = BspGetAmpIoInfoByRfChn(chan,dir,&iochan);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }
	ioIdx = iochan&0xf;
	ioType = (iochan>>8)&0xf;
    ret |= BspGetTddIoOutSel(ioIdx,ioType, &ampMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    ampSwCtrl = BspGetTddIoSwitch(ioType,ampMuxRst);
    dbgInfoEx("chan  %d,ioIdx %d ioType %d ampMuxRst %d ampSwCtrl%d\n",chan,ioIdx,ioType,ampMuxRst, ampSwCtrl);
    return ampSwCtrl;
}

 
UINT32 BspGetTxSwitchCtrl(UINT32 chan)
{    
    UINT32 txSwCtrl    = TX_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 txMuxRst = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;
    UINT32 ioIdx  = 0;
    UINT32 ioType  = 0;

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        txSwCtrl = BspGetTxenSwitch_Fpga(chan);
        return txSwCtrl;
    }

    ret = BspGetTxEnIoInfoByRfChn(chan,dir,&iochan);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }
	ioIdx = iochan&0xf;
	ioType = (iochan>>8)&0xf;
    ret |= BspGetTddIoOutSel(ioIdx,ioType,&txMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }
    
    txSwCtrl = BspGetTddIoSwitch(ioType,txMuxRst);
    dbgInfoEx("chan  %d,ioIdx %d ioType %d txMuxRst %d txSwCtrl%d(1:on 0:off 2:fddon)\n",chan,ioIdx,ioType,txMuxRst, txSwCtrl);
    return txSwCtrl;
}

UINT32 BspGetRxSwitchCtrl(UINT32 chan)
{    
    UINT32 rxSwCtrl    = RX_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 rxMuxRst = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;
    UINT32 ioIdx  = 0;
    UINT32 ioType  = 0;

    if(BspGetPaCtrlMode() == PA_CTRL_MODE_FPGA)
    {
        rxSwCtrl = BspGetRxenSwitch_Fpga(chan);
        return rxSwCtrl;
    }

    ret = BspGetRxEnIoInfoByRfChn(chan,dir,&iochan);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }
	ioIdx = iochan&0xf;
	ioType = (iochan>>8)&0xf;
    ret |= BspGetTddIoOutSel(ioIdx,ioType, &rxMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    rxSwCtrl = BspGetTddIoSwitch(ioType,rxMuxRst);
    dbgInfoEx("chan  %d,ioIdx %d ioType %d rxMuxRst %d rxSwCtrl%d(1:on 0:off 2:fddon)\n",chan,ioIdx,ioType,rxMuxRst, rxSwCtrl);
    return rxSwCtrl;
}

UINT32 BspGetTxSwitch(UINT32 chan)
{
    UINT32 retVal = BSP_OK;
    
    retVal = BspGetTxSwitchCtrl(chan);

    return retVal;
}

UINT32 BspGetRxSwitch(UINT32 chan)
{
    UINT32 retVal    = BSP_OK;
    
    retVal = BspGetRxSwitchCtrl(chan);

    return retVal;
}


UINT32 BspGetFbSwitchCtrl(UINT32 chan)
{    
    UINT32 fbSwCtrl    = FB_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 fbMuxRst = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;
    UINT32 ioIdx  = 0;
    UINT32 ioType  = 0;

    ret = BspGetFbIoInfoByRfChn(chan,dir,&iochan);

	ioIdx = iochan&0xf;
	ioType = (iochan>>8)&0xf;
    ret |= BspGetTddIoOutSel(ioIdx,ioType,&fbMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    fbSwCtrl = BspGetTddIoSwitch(ioType,fbMuxRst);
    dbgInfo("chan  %d,ioIdx %d ioType %d fbMuxRst %d fbSwCtrl%d(1:on 0:off 2: fddon)\n",chan,ioIdx,ioType,fbMuxRst, fbSwCtrl);
    return fbSwCtrl;
}

UINT32 BspGetFbSwitch(UINT32 chan)
{
    UINT32 retVal    = BSP_OK;
    retVal = BspGetFbSwitchCtrl(chan);
    return retVal;
}


UINT32 BspGetTxAcSwitchCtrl(UINT32 chan)
{    
    UINT32 txAcSwCtrl    = TX_AC_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 txAcMuxRst = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;

    ret = BspGetTxAcIoInfoByRfChn(chan,dir,&iochan);

    ret |= BspHalAdaptGetTrxTxEnACOutSel(iochan, &txAcMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    txAcSwCtrl = BspGetIoSwitchStatus(txAcMuxRst);

    return txAcSwCtrl;
}

UINT32 BspGetTxAcSwitch(UINT32 chan)
{
    UINT32 retVal    = BSP_OK;

    retVal = BspGetTxAcSwitchCtrl(chan);
    return retVal;
}


UINT32 BspGetRxAcSwitchCtrl(UINT32 chan)
{    
    UINT32 rxAcSwCtrl    = RX_AC_SWITCH_OFF;
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 rxAcMuxRst = IO_OUT_SEL_ZERO;
    UINT32 ret = BSP_OK;

    ret = BspGetRxAcIoInfoByRfChn(chan,dir,&iochan);

    ret |= BspHalAdaptGetTrxRxEnACOutSel(iochan, &rxAcMuxRst);
    if(ret != BSP_OK)
    {
        return BSP_ERROR;
    }

    rxAcSwCtrl = BspGetIoSwitchStatus(rxAcMuxRst);

    return rxAcSwCtrl;
}

UINT32 BspGetRxAcSwitch(UINT32 chan)
{
    UINT32 retVal    = BSP_OK;

    retVal = BspGetRxAcSwitchCtrl(chan);
    return retVal;
}

UINT32 BspGetAcCtrlSwitch(UINT32 type)   /*这块处理待确认，AC开关有3套，对应9个bit type表示AC0_CTRL_TX_SW等*/
{
    UINT32 retVal    = BSP_OK;
    
    retVal = BspGetAcCtrlSwitchCtrl(type);

    return retVal;
}

/******************************************************************************************
                             DTX接口相关
******************************************************************************************/

UINT32 IsDtxAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT8 * sta)
 {
     UINT32 chn = 0;
     UINT32 rst = 0;
     T_RU_LINK_MAP_TDDIO_TO_RF Val = {0};
     
     BspGetDifInfoByIoChn(ioChan , linkPro, &Val);
     for(chn = 0; chn < Val.rfChNum; chn++)
     {
         if(1 == sta[Val.rfCh[chn]])
         {
            if(rst < 0x7fff)
            {
                rst += sta[Val.rfCh[chn]];
            }
         }
         dbgInfoEx("ioChn: %d, difChan: %d, Sta: %d.\n", ioChan, Val.rfCh[chn], sta[Val.rfCh[chn]]);
     }
     if(rst == Val.rfChNum)
     {
         return BSP_OK;
     }
 
     return BSP_ERROR;
}

UINT32 BspSetDtxPaEn(UINT32 chan, UINT32 isEn)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(isEn > IO_DTX_ON)
    {
        dbgInfo("%s chan [%d] isEn [%d] is error!!!\n", __FUNCTION__, chan, isEn);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, isEn);

    ret |= BspGetPaIoInfoByRfChn(chan,dir,&iochan);  
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
    if(ioIdx >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s iochan [%d] over %d!!!\n", __FUNCTION__, ioIdx,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    dbgInfoEx("%s >>>>>> chan = %d, isEn = %d, iochan = 0x%x.\n", __FUNCTION__, chan, isEn, iochan);
  
   /*PALNA的DTX开关1驱4，4通道全开则开，1通道关则关*/
   /*如果开1个通道实际没开，也返回OK*/
    switch(isEn)
    {
        case IO_DTX_ON:
        {
            g_dtxPaOnSta[ioIdx][chan] = 1;
            if(BSP_OK==IsDtxAllChnsOn(ioIdx,ioTpye,&g_dtxPaOnSta[ioIdx][0]))
            {
                ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);
            }

            break;
        }
        case IO_DTX_OFF:
        {
            ret |= BspSwitchOffStaSet(ioIdx,ioTpye, (UINT8 *)&g_dtxPaOnSta[ioIdx][0]);
            ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);

            break;
        }
        default:
        {
            dbgInfo("[%s] PA Switch Status is Error!!! Sta is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    
    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
UINT32 BspSetDtxLnaEn(UINT32 chan, UINT32 isEn)
{
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(isEn > IO_DTX_ON)
    {
        dbgInfo("%s chan [%d] isEn [%d] is error!!!\n", __FUNCTION__, chan, isEn);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, isEn);

    ret |= BspGetLnaIoInfoByRfChn(chan,dir,&iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
    if(ioIdx >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s iochan [%d] over %d!!!\n", __FUNCTION__, ioIdx,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    dbgInfoEx("%s >>>>>> chan = %d, isEn = %d, iochan = 0x%x.\n", __FUNCTION__, chan, isEn, iochan);

   /*PALNA的DTX开关1驱4，4通道全开则开，1通道关则关*/
   /*如果开1个通道实际没开，也返回OK*/
    switch(isEn)
    {
        case IO_DTX_ON:
        {
        	g_dtxLnaOnSta[ioIdx][chan] = 1;
            if(BSP_OK==IsDtxAllChnsOn(ioIdx,ioTpye,&g_dtxLnaOnSta[ioIdx][0]))
            {
                ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);
            }

            break;
        }
        case IO_DTX_OFF:
        {
            ret |= BspSwitchOffStaSet(ioIdx,ioTpye, (UINT8 *)&g_dtxLnaOnSta[ioIdx][0]);
            ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);

            break;
        }
        default:
        {
            dbgInfo("[%s] PA Switch Status is Error!!! Sta is %d\n", __FUNCTION__, isEn);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
UINT32 BspSetDtxAmpEn(UINT32 chan, UINT32 isEn)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(isEn > IO_DTX_ON)
    {
        dbgInfo("%s chan [%d] isEn [%d] is error!!!\n", __FUNCTION__, chan, isEn);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, isEn);

    ret |= BspGetAmpIoInfoByRfChn(chan,dir,&iochan);
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
    if(ioIdx >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s iochan [%d] over %d!!!\n", __FUNCTION__, ioIdx,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    dbgInfoEx("%s >>>>>> chan = %d, isEn = %d, iochan = 0x%x.\n", __FUNCTION__, chan, isEn, iochan);

   /*PALNA的DTX开关1驱4，4通道全开则开，1通道关则关*/
   /*如果开1个通道实际没开，也返回OK*/
    switch(isEn)
    {
        case IO_DTX_ON:
        {
        	g_dtxAmpOnSta[ioIdx][chan] = 1;
            if(BSP_OK==IsDtxAllChnsOn(ioIdx,ioTpye,&g_dtxAmpOnSta[ioIdx][0]))
            {
                ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);
            }

            break;
        }
        case IO_DTX_OFF:
        {
            ret |= BspSwitchOffStaSet(ioIdx,ioTpye, (UINT8 *)&g_dtxAmpOnSta[ioIdx][0]);
            ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);

            break;
        }
        default:
        {
            dbgInfo("[%s] PA Switch Status is Error!!! Sta is %d\n", __FUNCTION__, isEn);
            break;
        }
    }

    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
UINT32 BspSetDtxTxEn(UINT32 chan, UINT32 isEn)
{
    UINT32 dir = LINK_TYPE_TX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(isEn > IO_DTX_ON)
    {
        dbgInfo("%s chan [%d] isEn [%d] is error!!!\n", __FUNCTION__, chan, isEn);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, isEn);

    ret |= BspGetTxEnIoInfoByRfChn(chan,dir,&iochan);    //dtx改版前，trx和pa对应关系不一致，讨论决定都使用pa的对应关系
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
    if(ioIdx >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s iochan [%d] over %d!!!\n", __FUNCTION__, ioIdx,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    dbgInfoEx("%s >>>>>> chan = %d, isEn = %d, iochan = 0x%x.\n", __FUNCTION__, chan, isEn, iochan);
  
   /*TX的DTX开关1驱4，4通道全开则开，1通道关则关*/
   /*如果开1个通道实际没开，也返回OK*/
    switch(isEn)
    {
        case IO_DTX_ON:
        {
            g_dtxTxOnSta[ioIdx][chan] = 1;
            if(BSP_OK==IsDtxAllChnsOn(ioIdx,ioTpye,&g_dtxTxOnSta[ioIdx][0]))
            {
                ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);
            }

            break;
        }
        case IO_DTX_OFF:
        {
            ret |= BspSwitchOffStaSet(ioIdx,ioTpye, (UINT8 *)&g_dtxTxOnSta[ioIdx][0]);
            ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);

            break;
        }
        default:
        {
            dbgInfo("[%s] TX Switch Status is Error!!! Sta is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    
    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspSetDtxRxEn(UINT32 chan, UINT32 isEn)
{
    UINT32 dir = LINK_TYPE_RX;
    UINT32 iochan = 0;
    UINT32 ret = BSP_OK;
	UINT32 ioIdx  = 0;
	UINT32 ioTpye = 0;

    if(isEn > IO_DTX_ON)
    {
        dbgInfo("%s chan [%d] isEn [%d] is error!!!\n", __FUNCTION__, chan, isEn);
        return BSP_ERROR;
    }
    dbgInfoEx("%s >>>>>> chan [%d] sw [%d].\n", __FUNCTION__, chan, isEn);

    ret |= BspGetPaIoInfoByRfChn(chan,dir,&iochan);    //dtx改版前，trx和pa对应关系不一致，讨论决定都使用pa的对应关系
	ioIdx = iochan&0xf;
	ioTpye = (iochan>>8)&0xf;
    if(ioIdx >= (UINT32)TDD_IO_PIN_NUM_COMMON_8)
    {
        dbgInfo("%s iochan [%d] over %d!!!\n", __FUNCTION__, iochan,TDD_IO_PIN_NUM_COMMON_8);
        return BSP_ERROR;
    }

    dbgInfoEx("%s >>>>>> chan = %d, isEn = %d, iochan = 0x%x.\n", __FUNCTION__, chan, isEn, iochan);
  
   /*TRANS的DTX开关1驱4，4通道全开则开，1通道关则关*/
   /*如果开1个通道实际没开，也返回OK*/
    switch(isEn)
    {
        case IO_DTX_ON:
        {
            g_dtxRxOnSta[ioIdx][chan] = 1;
            if(BSP_OK==IsDtxAllChnsOn(ioIdx,ioTpye,&g_dtxRxOnSta[ioIdx][0]))
            {
                ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);
            }

            break;
        }
        case IO_DTX_OFF:
        {
            ret |= BspSwitchOffStaSet(ioIdx,ioTpye,(UINT8 *)&g_dtxRxOnSta[ioIdx][0]);
            ret |= BspSetTddIoDtxEnCfg(ioIdx,ioTpye,isEn);

            break;
        }
        default:
        {
            dbgInfo("[%s] TRANS Switch Status is Error!!! Sta is %d\n", __FUNCTION__, isEn);
            break;
        }
    }
    
    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}
/******************************************************************************************
                             功放保护接口相关
******************************************************************************************/
#if 0
/*光口功放保护代码开发*/
//0xC2402350
UINT32 BspSetSerdesAlmMaskPaptCfg(Opt_Serdes_Alm_Mask_Info ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_int31_c_violation:SUPPRESS]	
    //coverity[cert_dcl40_c_violation:SUPPRESS]
    ret |= OptCpriSetPaptOptSerdesIpAlmMask(0,ulRegVal.lane0AlmMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]		
	ret |= OptCpriSetPaptOptSerdesIpAlmMask(1,ulRegVal.lane1AlmMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]		
	ret |= OptCpriSetPaptOptSerdesIpAlmMask(2,ulRegVal.lane2AlmMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]		
	ret |= OptCpriSetPaptOptSerdesIpAlmMask(3,ulRegVal.lane3AlmMaskInfo);
    return ret;
}

//0xC2408014~0xC2408020
UINT32 BspSetLocalDaOffAlmMaskPaptCfg(Local_Logic_Port_Da_Off_Alm_Mask_Info ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_c_violation:SUPPRESS]    
    ret |= OptCpriSetLocalDaOffAlmMask(0,ulRegVal.localLogic0MaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS] 	
	ret |= OptCpriSetLocalDaOffAlmMask(1,ulRegVal.localLogic1MaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS] 	
	ret |= OptCpriSetLocalDaOffAlmMask(2,ulRegVal.localLogic2MaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS] 	
	ret |= OptCpriSetLocalDaOffAlmMask(3,ulRegVal.localLogic3MaskInfo);
    return ret;
}

//0xC2408024~0xC2408030
UINT32 BspSetCascDaOffAlmMaskPaptCfg(Casc_Logic_Port_Da_Off_Alm_Mask_Info ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_int31_c_violation:SUPPRESS]
    //coverity[cert_dcl40_c_violation:SUPPRESS]    
    ret |= OptCpriSetCascDaOffAlmMask(0,ulRegVal.cascLogic0MaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriSetCascDaOffAlmMask(1,ulRegVal.cascLogic1MaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriSetCascDaOffAlmMask(2,ulRegVal.cascLogic2MaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriSetCascDaOffAlmMask(3,ulRegVal.cascLogic3MaskInfo);
    return ret;
}

//0xC2408034
UINT32 BspSetSbcResDaOffAlmMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_int31_c_violation:SUPPRESS] 
    //coverity[cert_dcl40_c_violation:SUPPRESS]   
    ret = OptCpriSetSbcResDaOffAlmMask(ulRegVal);
    return ret;
}

//0xC2408038
UINT32 BspSetDaOffDlyPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_int31_c_violation:SUPPRESS]	
    //coverity[cert_dcl40_c_violation:SUPPRESS]
    ret = OptCpriSetDaOffDly(ulRegVal);
    return ret;
}

//0xC240803C
UINT32 BspSetDaOnDlyPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_dcl40_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]	
    ret = OptCpriSetDaOnDly(ulRegVal);
    return ret;
}

//0xC2410800~0xC2410818
UINT32 BspSetDifDaOffAlmMaskPaptCfg(Dif_Da_Off_Alm_Mask_Info ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_dcl40_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]		
    ret |= OptCpriSetDifDaOffAlmMask(0,ulRegVal.logic0DaOffMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriSetDifDaOffAlmMask(1,ulRegVal.logic1DaOffMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriSetDifDaOffAlmMask(2,ulRegVal.logic2DaOffMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriSetDifDaOffAlmMask(3,ulRegVal.logic3DaOffMaskInfo);
    return ret;
}

//0xC2410820
UINT32 BspSetDifDaOffOptAlmMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_dcl40_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]	
    ret = OptCpriSetDifDaOffOptAlmMask(ulRegVal);
    return ret;
}

//0xC2400060
UINT32 BspSetDifDaOffSecMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_dcl40_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]    
    ret = OptCpriSetDifDaOffSecMask(ulRegVal);
    return ret;
}

//0xC2410804~0xC241080C
UINT32 BspSetDifPaOffAlmMaskPaptCfg(Dif_Pa_Off_Alm_Mask_Info ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_dcl40_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]    
    ret |= OptCpriSetDifPaOffAlmMask(0,ulRegVal.logic0PaOffMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS] 	
	ret |= OptCpriSetDifPaOffAlmMask(1,ulRegVal.logic1PaOffMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS] 	
	ret |= OptCpriSetDifPaOffAlmMask(2,ulRegVal.logic2PaOffMaskInfo);
    //coverity[cert_int31_c_violation:SUPPRESS] 	
	ret |= OptCpriSetDifPaOffAlmMask(3,ulRegVal.logic3PaOffMaskInfo);
    return ret;
}

//0xC2410824
UINT32 BspSetDifPaOffOptAlmMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_dcl40_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]    
    ret = OptCpriSetDifPaOffOptAlmMask(ulRegVal);
    return ret;
}

//0xC2400064
UINT32 BspSetDifPaOffSecMaskPaptCfg(UINT32 ulRegVal)
{
    UINT32 ret = 0;

    //coverity[cert_dcl40_c_violation:SUPPRESS]
    //coverity[cert_int31_c_violation:SUPPRESS]    
    ret = OptCpriSetDifPaOffSecMask(ulRegVal);
    return ret;
}

/*光口功放保护初始化接口*/
VOID BspPaptCfgInit(Papt_Opt_Cfg_Info optCfgInfo)
{
     BspSetSerdesAlmMaskPaptCfg(optCfgInfo.serdesAlmMaskInfo);   //serdes告警掩码 0xFFF2
	 BspSetSbcResDaOffAlmMaskPaptCfg(optCfgInfo.sbcDaOffMaskInfo);  //辅光口响应主光口告警IQ关断 0X1
	 BspSetDaOffDlyPaptCfg(optCfgInfo.daOffDlyInfo);//主辅光口告警IQ关断延迟关断配置0x10
	 BspSetDaOnDlyPaptCfg(optCfgInfo.daOnDlyInfo);//主辅光口告警IQ关断延迟打开配置0x1
	 BspSetDifDaOffOptAlmMaskPaptCfg(optCfgInfo.difDaOffAlmMaskInfo);//光口中频数据屏蔽告警掩码0x1
	 BspSetDifDaOffSecMaskPaptCfg(optCfgInfo.difDaOffSecMaskInfo);//中频数据屏蔽告警掩码0x7
	 BspSetDifPaOffOptAlmMaskPaptCfg(optCfgInfo.difPaOffAlmMaskInfo);//光口中频关功放告警掩码0x1
	 BspSetDifPaOffSecMaskPaptCfg(optCfgInfo.difPaOffSecMaskInfo);//中频关功放告警掩码0x1
	 BspSetLocalDaOffAlmMaskPaptCfg(optCfgInfo.localLogicAlmMaskInfo);//链路告警关断本级数据掩码配置0x09FCF
	 BspSetCascDaOffAlmMaskPaptCfg(optCfgInfo.cascLogicAlmMaskInfo);//链路告警关断转发数据掩码配置0x09FCF
	 BspSetDifDaOffAlmMaskPaptCfg(optCfgInfo.logicDaOffAlmMaskInfo);//U0口中频数据屏蔽告警掩码寄存器0x1FCF
	 BspSetDifPaOffAlmMaskPaptCfg(optCfgInfo.logicPaOffAlmMaskInfo);//U0口中频关功放告警掩码0x800
}

/*光口功放保护维测打印配置命令*/
UINT32 HalPrnPaptSerdesAlm()
{
    UINT32 phyOpt = 0;
	UINT32 serdesAlmReal = 0;
	UINT32 serdesAlmEvt = 0;
	UINT32 serdesAlmMask = 0;
	UINT32 uRet = 0;
	
	dbgPrn("|phyOpt\t||serdesAlmReal\t|serdesAlmEvt\t|serdesAlmMask  \t|\n");
	for(phyOpt = 0; phyOpt < 4; phyOpt++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS] 		
		uRet = OptCpriGetSerdesAlmRealStaRpt(phyOpt, &serdesAlmReal);
		RETURN_RESULT_CHECK(uRet);

        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]		
		uRet = OptCpriGetSerdesAlmEvtStaRpt(phyOpt, &serdesAlmEvt);
		RETURN_RESULT_CHECK(uRet);

		//uRet = OptCpriGetSerdesIpAlmMask(phyOpt, &serdesAlmMask);
		//RETURN_RESULT_CHECK(uRet);

		dbgPrn("|%-8d\t|%-8d\t|%-8d\t|%-8d\t|\n",phyOpt,serdesAlmReal,\
				serdesAlmEvt,serdesAlmMask);
	}
   return BSP_OK;
}

UINT32 HalPrnPaptDifOptAlm()
{
	UINT32 logicOpt = 0;
	UINT32 logicOptAlm = 0;
	UINT32 difDaOffMask = 0;
	UINT32 difPaOffMask = 0;
	UINT32 uRet = 0;

	dbgPrn("|logicOpt\t||logicOptAlm\t|difDaOffMask\t|difPaOffMask  \t|\n");
	for(logicOpt = 0; logicOpt < 4; logicOpt++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]		
		uRet = OptCpriGetLogicOptAlm(logicOpt, &logicOptAlm);
		RETURN_RESULT_CHECK(uRet);

        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]		
		uRet = OptCpriGetDifDaOffAlmMask(logicOpt, &difDaOffMask);
		RETURN_RESULT_CHECK(uRet);

        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]		 
		uRet = OptCpriGetDifPaOffAlmMask(logicOpt, &difPaOffMask);
		RETURN_RESULT_CHECK(uRet);

		dbgPrn("|%-8d\t|%-8d\t|%-8d\t|%-8d\t|\n",logicOpt,logicOptAlm,\
				difDaOffMask,difPaOffMask);
	}
   return BSP_OK;
}

UINT32 HalPrnPaptOptAlm()
{
	UINT32 logicOpt = 0;
	UINT32 localDaOffMask = 0;
	UINT32 CascDaOffMask = 0;
	UINT32 uRet = 0;

	dbgPrn("|logicOpt\t||localDaOffMask\t|CascDaOffMask  \t|\n");
	for(logicOpt = 0; logicOpt < 4; logicOpt++)
	{
        //coverity[cert_int31_c_violation:SUPPRESS]			
		uRet = OptCpriGetLocalDaOffAlmMask(logicOpt, &localDaOffMask);
		RETURN_RESULT_CHECK(uRet);

        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]			 
		uRet = OptCpriGetCascDaOffAlmMask(logicOpt, &CascDaOffMask);
		RETURN_RESULT_CHECK(uRet);

		dbgPrn("|%-8d\t|%-8d\t|%-8d\t|%-8d\t|\n",logicOpt,localDaOffMask,\
				CascDaOffMask);
	}
   return BSP_OK;
}


/*计数*/
UINT32 BspGetPaptLogOptRoeAlmEdgCntStatus(UINT32 LogicOpt)

{   UINT32 cntLoop = 0;
	UINT32 cnt = 0;	
	UINT32 ret = 0;

	for(cntLoop = 0;cntLoop < 3;cntLoop++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]			
    	ret = OptCpriGetRoeAlmEdgCnt(LogicOpt,&cnt);
		BspSysMsDelay(50);
		dbgInfoEx("%s LogicOpt[%d],cntLoop=%d,cnt=%d\n",__FUNCTION__,LogicOpt,cntLoop,cnt);
	}
	return ret;
}

UINT32 BspGetPaptLogOptRoeAlmClkCntStatus(UINT32 LogicOpt)

{   UINT32 cntLoop = 0;
	UINT32 cnt = 0;
	UINT32 ret;

	for(cntLoop = 0;cntLoop < 3;cntLoop++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]			
    	ret = OptCpriGetRoeAlmClkCnt(LogicOpt,&cnt);
		BspSysMsDelay(50);
		dbgInfoEx("%s LogicOpt[%d],cntLoop=%d,cnt=%d\n",__FUNCTION__,LogicOpt,cntLoop,cnt);
	}
	return ret;
}

UINT32 BspGetPaptOptAlmDifDaOffEdgCntStatus()

{   UINT32 cntLoop = 0;
	UINT32 cnt = 0;	
	UINT32 ret;

	for(cntLoop = 0;cntLoop < 3;cntLoop++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]			
    	ret = OptCpriGetDifDaOffAlmEdgCnt(&cnt);
		BspSysMsDelay(50);
		dbgInfoEx("%s cntLoop=%d,cnt=%d\n",__FUNCTION__,cntLoop,cnt);
	}
	return ret;
}

UINT32 BspGetPaptOptAlmDifPaOffEdgCntStatus()

{   UINT32 cntLoop = 0;
	UINT32 cnt = 0;	
	UINT32 ret;

	for(cntLoop = 0;cntLoop < 3;cntLoop++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]	 		
    	ret = OptCpriGetDifPaOffAlmEdgCnt(&cnt);
		BspSysMsDelay(50);
		dbgInfoEx("%s cntLoop=%d,cnt=%d\n",__FUNCTION__,cntLoop,cnt);
	}
	return ret;
}

/*告警清零*/
UINT32 BspPaptClearSerdesAlmEvt()
{
    UINT32 clrMask = 0;
	UINT32 lockMask = 0;
	UINT32 phyOpt = 0;
	UINT32 ret = 0;

	clrMask = 0x1ffff;
	lockMask = 0x0;
	for (phyOpt = 0;phyOpt <4;phyOpt++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]		
    	ret |= OptCpriSerdesIpAlmEvtClr(phyOpt,lockMask);
        //coverity[cert_int31_c_violation:SUPPRESS]			
		ret |= OptCpriSerdesIpAlmEvtClr(phyOpt,clrMask);
        //coverity[cert_int31_c_violation:SUPPRESS]			
		ret |= OptCpriSerdesIpAlmEvtClr(phyOpt,lockMask);
	}
	return ret;	
}

UINT32 BspPaptClearLogicOptAlmEvt()
{
    UINT32 clrMask = 0;
	UINT32 lockMask = 0;
	UINT32 logicOpt = 0;
	UINT32 ret = 0;

	clrMask = 0xffff;	
	lockMask = 0x0;
	for (logicOpt = 0;logicOpt <4;logicOpt++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]		
    	ret |= OptCpriLogicOptClr(logicOpt,lockMask);
        //coverity[cert_int31_c_violation:SUPPRESS]			
		ret |= OptCpriLogicOptClr(logicOpt,clrMask);
        //coverity[cert_int31_c_violation:SUPPRESS]	 		
		ret |= OptCpriLogicOptClr(logicOpt,lockMask);
	}
	return ret;	
}

UINT32 BspPaptClearPhyOptAlmEvt()
{
    UINT32 clrMask = 0;	
	UINT32 lockMask = 0;
	UINT32 PhyOpt = 0;
	UINT32 ret = 0;

	clrMask = 0xffff;
	lockMask = 0x0;
	for (PhyOpt = 0;PhyOpt <4;PhyOpt++)
	{
        //coverity[cert_dcl40_c_violation:SUPPRESS]
        //coverity[cert_int31_c_violation:SUPPRESS]	 		
    	ret |= OptCpriPhyOptClr(PhyOpt,lockMask);
        //coverity[cert_int31_c_violation:SUPPRESS]			
		ret |= OptCpriPhyOptClr(PhyOpt,clrMask);
        //coverity[cert_int31_c_violation:SUPPRESS]			
		ret |= OptCpriPhyOptClr(PhyOpt,lockMask);
	}
	return ret;	
}

UINT32 BspPaptClearDifDataAlmEvt()
{
    UINT32 clrMask = 0;
	UINT32 lockMask = 0;
    UINT32 PhyOpt = 0;	
	UINT32 ret = 0;

	clrMask = 0x1;
	lockMask = 0x0;
    for (PhyOpt = 0;PhyOpt <4;PhyOpt++)
	{	
        //coverity[cert_exp37_c_violation:SUPPRESS]	
        //coverity[cert_int31_c_violation:SUPPRESS]	
	    ret |= OptCpriPhyOptClr(PhyOpt,lockMask);
        //coverity[cert_exp37_c_violation:SUPPRESS]	
        //coverity[cert_int31_c_violation:SUPPRESS]	
	    ret |= OptCpriPhyOptClr(PhyOpt,clrMask);
        //coverity[cert_exp37_c_violation:SUPPRESS]	
        //coverity[cert_int31_c_violation:SUPPRESS]	
	    ret |= OptCpriPhyOptClr(PhyOpt,lockMask);
    }	
	return ret;	
}

UINT32 BspPaptClearDifPaAlmEvt()
{
    UINT32 clrMask = 0;
	UINT32 lockMask = 0;
	UINT32 ret = 0;

	clrMask = 0x1;
	lockMask = 0x0;
    //coverity[cert_dcl40_c_violation:SUPPRESS]	
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriDifPaOffAlmClr(lockMask);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriDifPaOffAlmClr(clrMask);
    //coverity[cert_int31_c_violation:SUPPRESS]	
	ret |= OptCpriDifPaOffAlmClr(lockMask);
	return ret;	
}
#endif
/******************************************************************************************
                             调试接口相关
******************************************************************************************/
UINT32 SwitchPrnSet(UINT32 ulSwPrnFlag)
{
    UINT32 ulTmpDbg = 0;
    const char *pucStr[] = {"OFF", "ON"};

    ulTmpDbg = ulSwPrnFlag ? 1 : 0;
    if (ulTmpDbg != s_ulPaLnaSwitchPrn)
    {
        dbgInfo("%s>>PaLna PrnSwitch Change from %s to %s\n", __FUNCTION__,
                pucStr[s_ulPaLnaSwitchPrn & 0x01], pucStr[ulTmpDbg]);
        s_ulPaLnaSwitchPrn = ulTmpDbg;
    }

    return s_ulPaLnaSwitchPrn;
}
#if 0
#ifdef BUILD_WITH_OM_FUNC
UINT32 patddsw(UINT32 staChnl, UINT32 endChnl, UINT32 paSw)
{
    UINT32 chnlIdx = 0;
    UINT32 chnlMin = 0;
    UINT32 chnlMax = 0;
    UINT32 swOnOff = 0;
    UINT32 tmpRet = BSP_OK;

    chnlMin = staChnl;
    chnlMax = min(BspGetTxChannel(), endChnl + 1);
    swOnOff = (SWITCH_OFF == paSw) ? SWITCH_OFF : SWITCH_ON;

    for (chnlIdx = chnlMin; chnlIdx < chnlMax; chnlIdx += 1)
    {
        tmpRet |= BspSetPaTddSwitch(chnlIdx, swOnOff);
    }

    if (BSP_OK == tmpRet)
    {
        dbgInfo("%s>>Tdd PaChnl'%d~%d %s SUCC!\n", __FUNCTION__, chnlMin,
                chnlMax, (SWITCH_OFF == paSw) ? "SW_OFF" : "SW_ON");
    }
    else
    {
        dbgErr("%s>>Tdd PaChnl'%d~%d %s FAIL!\n", __FUNCTION__, chnlMin,
               chnlMax, (SWITCH_OFF == paSw) ? "SW_OFF" : "SW_ON");
    }

    return tmpRet;
}

UINT32 pafddsw(UINT32 staChnl, UINT32 endChnl, UINT32 paSw)
{
    UINT32 chnlIdx = 0;
    UINT32 chnlMin = 0;
    UINT32 chnlMax = 0;
    UINT32 swOnOff = 0;
    UINT32 tmpRet = BSP_OK;

    chnlMin = staChnl;
    chnlMax = min(BspGetTxChannel(), endChnl + 1);
    swOnOff = (SWITCH_OFF == paSw) ? SWITCH_OFF : SWITCH_ON;

    for (chnlIdx = chnlMin; chnlIdx < chnlMax; chnlIdx += 1)
    {
        tmpRet |= BspSetPaFddSwitch(chnlIdx, swOnOff);
    }

    if (BSP_OK == tmpRet)
    {
        dbgInfo("%s>>Fdd PaChnl'%d~%d %s SUCC!\n", __FUNCTION__, chnlMin,
                chnlMax, (SWITCH_OFF == paSw) ? "SW_OFF" : "SW_ON");
    }
    else
    {
        dbgErr("%s>>Fdd PaChnl'%d~%d %s FAIL!\n", __FUNCTION__, chnlMin,
               chnlMax, (SWITCH_OFF == paSw) ? "SW_OFF" : "SW_ON");
    }

    return tmpRet;
}

UINT32 lnatddsw(UINT32 staChnl, UINT32 endChnl, UINT32 lnaSw)
{
    UINT32 chnlIdx = 0;
    UINT32 chnlMin = 0;
    UINT32 chnlMax = 0;
    UINT32 swOnOff = 0;
    UINT32 tmpRet = BSP_OK;

    chnlMin = staChnl;
    chnlMax = min(BspGetTxChannel(), endChnl + 1);
    swOnOff = (SWITCH_OFF == lnaSw) ? SWITCH_OFF : SWITCH_ON;

    for (chnlIdx = chnlMin; chnlIdx < chnlMax; chnlIdx += 1)
    {
        tmpRet |= BspSetLnaTddSwitch(chnlIdx, swOnOff);
    }

    if (BSP_OK == tmpRet)
    {
        dbgInfo("%s>>Tdd LnaChnl'%d~%d %s SUCC!\n", __FUNCTION__, chnlMin,
                chnlMax, (SWITCH_OFF == lnaSw) ? "SW_OFF" : "SW_ON");
    }
    else
    {
        dbgErr("%s>>Tdd LnaChnl'%d~%d %s FAIL!\n", __FUNCTION__, chnlMin,
               chnlMax, (SWITCH_OFF == lnaSw) ? "SW_OFF" : "SW_ON");
    }

    return tmpRet;
}

UINT32 lnafddsw(UINT32 staChnl, UINT32 endChnl, UINT32 lnaSw)
{
    UINT32 chnlIdx = 0;
    UINT32 chnlMin = 0;
    UINT32 chnlMax = 0;
    UINT32 swOnOff = 0;
    UINT32 tmpRet = BSP_OK;

    chnlMin = staChnl;
    chnlMax = min(BspGetRxChannel(), endChnl + 1);
    swOnOff = (SWITCH_OFF == lnaSw) ? SWITCH_OFF : SWITCH_ON;

    for (chnlIdx = chnlMin; chnlIdx < chnlMax; chnlIdx += 1)
    {
        tmpRet |= BspSetLnaFddSwitch(chnlIdx, swOnOff);
    }

    if (BSP_OK == tmpRet)
    {
        dbgInfo("%s>>Fdd LnaChnl'%d~%d %s SUCC!\n", __FUNCTION__, chnlMin,
                chnlMax, (SWITCH_OFF == lnaSw) ? "SW_OFF" : "SW_ON");
    }
    else
    {
        dbgErr("%s>>Fdd LnaChnl'%d~%d %s FAIL!\n", __FUNCTION__, chnlMin,
               chnlMax, (SWITCH_OFF == lnaSw) ? "SW_OFF" : "SW_ON");
    }

    return tmpRet;
}
#endif


/*pa tdd*/
UINT32 BspSetPaon(UINT32 startChn,UINT32 endChn)
{
    return paon(startChn, endChn);
}

/*pa tdd_fdd*/
UINT32 BspSetPaonfdd(UINT32 startChn,UINT32 endChn)
{
    return paonfdd(startChn, endChn);
}

/*lna off*/
UINT32 BspSetLnaoff(UINT32 startChn,UINT32 endChn)
{
    return lnaoff(startChn, endChn);
}

/*lna tdd*/
UINT32 BspSetLnaon(UINT32 startChn,UINT32 endChn)
{
    return lnaon(startChn, endChn);
}

UINT32 BspSetLnaonfdd(UINT32 startChn,UINT32 endChn)
{
    return lnaonfdd(startChn, endChn);
}

UINT32 BspSetTxenoff(UINT32 startChn,UINT32 endChn)
{
    return txenoff(startChn, endChn);
}

UINT32 BspSetTxenonfdd(UINT32 startChn,UINT32 endChn)
{
    return txenonfdd(startChn, endChn);
}

UINT32 BspSetRxenoff(UINT32 startChn,UINT32 endChn)
{
    return rxenoff(startChn, endChn);
}

UINT32 BspSetRxenon(UINT32 startChn,UINT32 endChn)
{
    return rxenon(startChn, endChn);
}

UINT32 BspSetRxenonfdd(UINT32 startChn,UINT32 endChn)
{
    return rxenonfdd(startChn, endChn);
}

UINT32 BspSetAcctrlon(UINT32 startType,UINT32 endType)
{
    return acctrlon(startType, endType);
}

//固定AC下行模式：S0/S1/S2=0/1/1
UINT32 BspSetAcFixTxMode(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = acctrloff(0,0);
    retVal |= acctrlonfdd(1,1);
    retVal |= acctrlonfdd(2,2);

    return retVal;
}

//固定AC上行模式：S0/S1/S2=1/0/0
UINT32 BspSetAcFixRxMode(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = acctrlonfdd(0,0);
    retVal |= acctrloff(1,1);
    retVal |= acctrloff(2,2);

    return retVal;
}

UINT32 BspTddIoDtxSwOnStaPrn(VOID)
{
    UINT32 iochn = 0;
    UINT32 chn = 0;

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_dtxPaLnaOnSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_dtxTransOnSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    return BSP_OK;
}


UINT32 BspTddIoSwOffStaPrn(VOID)
{
    UINT32 iochn = 0;
    UINT32 chn = 0;

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_PaSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_LnaSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_LnaSwSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_TxSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_RxSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_NUM_COMMON_8; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_FbSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_TRX_EN_AC_NUM_2; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_TxAcSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    for(iochn = 0; iochn < TDD_IO_PIN_TRX_EN_AC_NUM_2; iochn++)
    {
        for(chn = 0; chn < CHN_NUM_PER_CHIP; chn++)
        {
            dbgInfo("[%d][%d]%d%s",iochn,chn,g_RxAcSwitchOffSta[iochn][chn]," ");
        }
        dbgInfo("\n");
    }
    dbgInfo("\n");

    return BSP_OK;
}
UINT32 ShowPaLnaSwStatus(UINT32 typePaLna)
{
    UINT32 chnlIdx = 0;
    UINT32 showRowNo = 0;
    UINT32 colSumFlg = 0;
    UINT32 channelSum = 0;
    UINT32 mallocSize = 0;
    UINT32 oldTddFddMode = 0;
    UINT32 newTddFddMode = 0;
    UINT32 *pPaLnaSwStatus = NULL;
    const UINT8  *pPaLnaTypeStr = NULL;
    const UINT8  *pTddFddModeStr = NULL;
    PGetPaLnaSwStatus pFuncGetSwStatus = NULL;

    if (AMP_TYPE_PA == typePaLna)
    {
        pPaLnaTypeStr = "Pa ";
        channelSum = BspGetTxChannel();
        pFuncGetSwStatus = BspGetPaSwitch;
        mallocSize = (BspGetTxChannel() + 7) / 8 * 8;
    }
    else
    {
        pPaLnaTypeStr = "Lna";
        channelSum = BspGetRxChannel();
        pFuncGetSwStatus = BspGetLnaSwitch;
        mallocSize = (BspGetRxChannel() + 7) / 8 * 8;
    }

    pPaLnaSwStatus  = malloc(mallocSize * sizeof(UINT32));
    if (NULL == pPaLnaSwStatus)
    {
        dbgErr("%s>>PaLnaSwStatus malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset((VOID *)pPaLnaSwStatus, 0 , mallocSize * sizeof(UINT32));

    BspGetPaLnaCtrlMode(typePaLna, 0, &oldTddFddMode);
    for (chnlIdx = 0; chnlIdx < channelSum; chnlIdx += 1)
    {
        pPaLnaSwStatus[chnlIdx] = pFuncGetSwStatus(chnlIdx);

        BspGetPaLnaCtrlMode(typePaLna, chnlIdx, &newTddFddMode);
        if (oldTddFddMode != newTddFddMode)
        {
            oldTddFddMode = BSP_ERROR;
            dbgErr("%s>>Error! ChnlIdx(Sum:%d)'%d TddFdd'%d Not Same!\n",
                   __FUNCTION__, channelSum, chnlIdx, newTddFddMode);
        }
    }

    showRowNo = 8;
    colSumFlg = (255 << 16) | showRowNo;
    MODE_TDDFDD_NAME_STR(oldTddFddMode, pTddFddModeStr);
    dbgInfo("======= %s %s SW(0:OFF 1:ON) =======\n", pPaLnaTypeStr, pTddFddModeStr);
    for (chnlIdx = 0; chnlIdx < channelSum; chnlIdx += showRowNo)
    {
        dbgInfo("%sChnl[%2d~%2d]:", pPaLnaTypeStr, chnlIdx, chnlIdx + showRowNo - 1);
        TEST_DATA_BUF_PRINT(3, colSumFlg, 0, &pPaLnaSwStatus[chnlIdx], chnlIdx, chnlIdx + showRowNo - 1);
    }

    free(pPaLnaSwStatus);
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 palnaswstatus(VOID)
{
    ShowPaLnaSwStatus(AMP_TYPE_PA);
    ShowPaLnaSwStatus(AMP_TYPE_LNA);

    return BSP_OK;
}
#endif
#endif
UINT32 ampsta()
{
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 *ampSta = NULL;
    UINT32 loop = 0;
    ampSta = malloc(txChnNum*sizeof(UINT32));
    if (ampSta == NULL)
    {
        return BSP_ERROR;
    }
    memset(ampSta,0,txChnNum*sizeof(UINT32));
    for (loop = 0; loop < txChnNum; loop++)
    {
    	ampSta[loop] = BspGetAmpSwitch(loop);
    }
    dbgInfo("amp switch status(0:OFF,1:ON,2:FDDON):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,ampSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    free(ampSta);
    return BSP_OK;
}
UINT32 transsta()
{
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 rxChnNum= BspGetRxChannel();
    UINT32 *txSta= NULL;
    UINT32 *rxSta= NULL;
    UINT32 loop = 0;

    txSta = malloc(txChnNum*sizeof(UINT32));
    if (txSta == NULL)
    {
        return BSP_ERROR;
    }
    rxSta= malloc(rxChnNum*sizeof(UINT32));
    if (rxSta == NULL)
    {
        free(txSta);
        return BSP_ERROR;
    }

    memset(txSta,0,txChnNum*sizeof(UINT32));
    for (loop = 0; loop < txChnNum; loop++)
    {
        txSta[loop] = BspGetTxSwitch(loop);
    }

    memset(rxSta,0,rxChnNum*sizeof(UINT32));
    for (loop = 0; loop < rxChnNum; loop++)
    {
        rxSta[loop] = BspGetRxSwitch(loop);
    }

    dbgInfo("tx switch status(0:OFF,1:ON,2:FDDON):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,txSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("rx switch status(0:OFF,1:ON,2:FDDON):\n");
    for (loop = 0; loop < rxChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,rxSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    free(txSta);
    free(rxSta);
    return BSP_OK;
}

static UINT32 dtxpaall(UINT32 on)
{
    UINT32 loop = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 retTotal    = BSP_OK;

    for(loop=0; loop<BspGetTxBspChanNum(); loop++)
    {
        retVal = BspSetDtxPaEn(loop, on);
        retTotal |= retVal;
    }

    return retVal;
}
static UINT32 dtxampall(UINT32 on)
{
    UINT32 loop = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 retTotal    = BSP_OK;

    for(loop=0; loop<BspGetTxBspChanNum(); loop++)
    {
        retVal = BspSetDtxAmpEn(loop, on);
        retTotal |= retVal;
    }

    return retVal;
}

static UINT32 dtxlnall(UINT32 on)
{
    UINT32 loop = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 retTotal    = BSP_OK;

    for(loop=0; loop<BspGetRxBspChanNum(); loop++)
    {
        retVal = BspSetDtxLnaEn(loop, on);
        retTotal |= retVal;
    }

    return retVal;
}

static UINT32 dtxtxall(UINT32 on)
{
    UINT32 loop = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 retTotal    = BSP_OK;

    for(loop=0; loop<BspGetTxBspChanNum(); loop++)
    {
        retVal = BspSetDtxTxEn(loop, on);
        retTotal |= retVal;
    }

    return retVal;
}

static UINT32 dtxrxall(UINT32 on)
{
    UINT32 loop = 0;
    UINT32 retVal    = BSP_OK;
    UINT32 retTotal    = BSP_OK;

    for(loop=0; loop<BspGetRxBspChanNum(); loop++)
    {
        retVal = BspSetDtxRxEn(loop, on);
        retTotal |= retVal;
    }

    return retVal;
}

/*isEn:IO_DTX_ON/IO_DTX_OFF*/
UINT32 BspSetTddIoDtxEn(UINT32 bspChan, UINT32 isEn)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSetDtxPaEn(bspChan, isEn);
    retVal |= BspSetDtxAmpEn(bspChan, isEn);
    retVal |= BspSetDtxTxEn(bspChan, isEn);

    return retVal;
}

/*UE使能*/
UINT32 BspSetPaLnaUeEn(UINT32 chn, UINT32 sw)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSetPaUeEn(chn, sw);
    retVal |= BspSetLnaUeEn(chn, sw);

    return retVal;
}

/*BITMAP设置*/
UINT32 BspSetPaLnaBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal)
{
    UINT32 retVal = BSP_OK;

    retVal = BspSetPaBitmap(chn, bitmapLoop, bitmapVal);
    retVal |= BspSetLnaBitmap(chn, bitmapLoop, bitmapVal);

    return retVal;
}

UINT32 BspSetPaLnaBitmapByChn(UINT32 chn, UINT32 bitmapVal)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 maxCnt = 64;   /*一个管脚共64个寄存器*/

    for(loop = 0; loop < maxCnt; loop++)
    {
         retVal |= BspSetPaLnaBitmap(chn,loop,bitmapVal);
    }

    return retVal;
}

UINT32 BspRfSwitchGetGpCallBack(RFSWITCH_GETGP_CALLBACK pFuncCallback)
{
    pRfSwitchGetGpCallBack = pFuncCallback;
    return BSP_OK;
}

/*根据帧头提前量和帧结构 动态切换bitmap*/
UINT32 BspSetAllPaLnaBitmap(VOID)
{
    UINT32 loop = 0;
    UINT32 chanNum = 0;
    UINT32 bitmap0 = 0xaaaaaaaa;  /*每个bit为0 或1 选择xxx_ch和xxx_acch*/
    UINT32 bitmap1 = 0x55555555;
    UINT32 bitmap = 0;
    UINT32 retVal = BSP_OK;
    INT32 frVal = 0;
    UINT32 firstGp = 0;
    INT32 tmpVal = 0;
    UINT32 radioMode =0;

    if(NULL == pRfSwitchGetGpCallBack)
    {
        return BSP_OK;
    }
    chanNum = BspGetTxChannel();
    retVal = pRfSwitchGetGpCallBack(0, &radioMode, &firstGp);
    if(BSP_OK != retVal)
    {
        return BSP_OK;
    }
    frVal = BspGetFrameAlignmentVal(0, radioMode);
    tmpVal = firstGp + frVal;
    if((tmpVal >0)&&(tmpVal < 5000000)) /*以0-5ms作为判断标准*/
    {
        bitmap = bitmap0;
    }
    else
    {
        bitmap = bitmap1;
    }
    dbgInfo("radioMode 0x%x (ns)-firstGp %d frVal %d tmpVal %d bitmap 0x%x\n",
    radioMode, firstGp, frVal, tmpVal, bitmap);
    BspLog(LOG_LEVEL_0, "%s: radioMode 0x%x (ns)-firstGp %d frVal %d tmpVal %d bitmap 0x%x\n",
     __FUNCTION__, radioMode, firstGp, frVal, tmpVal, bitmap);
    for(loop = 0; loop < chanNum; loop++)
    {
         if(loop%2 == 0)   /*偶数奇数通道错开*/
         {
             retVal |= BspSetPaLnaBitmapByChn(loop,bitmap);
         }
         else
         {
             retVal |= BspSetPaLnaBitmapByChn(loop,0xffffffff - bitmap);
         }
    }

    return retVal;
}

UINT32 BspSlaveRfSwitchCallBack(SLAVE_RFSWITCH_CALLBACK pFuncCallback)
{
    pSlaveRfSwitchCallBack = pFuncCallback;
    return BSP_OK;
}

/*开关打成强制模式  下行长发反馈长收*/
UINT32 BspSetSlaveRfSwitch(UINT32 bspChan, UINT32 mode, UINT32 sw)
{
     UINT32 retVal = BSP_OK;

     BspLog(LOG_LEVEL_0, "%s: bspChan:%d mode:%d sw %d\n", __FUNCTION__, bspChan, mode, sw);
     dbgInfoEx("%s: bspChan:%d mode:%d sw %d\n", __FUNCTION__, bspChan, mode, sw);
     if(NULL != pSlaveRfSwitchCallBack)
     {
         retVal |= pSlaveRfSwitchCallBack(bspChan, mode, sw);
     }

     return retVal;
}

/* 从PaBasicInfo.txt离线文件获取功放是否高效字段的值 */
UINT32 BspGetEfficientType(UINT32 bspChan, UINT32 *effVal)
{
    UINT32 retVal = BSP_OK;
    UINT32 retComp = BSP_OK;
    const CHAR  *pCompareTime = "2024-05-30";

    INPUT_POINTER_CHECK(effVal);

    retVal = BspGetPaEfficientVal(bspChan, effVal);
    retComp = BspRruProductTimeCompare(pCompareTime);
    if(BSP_OK == retComp)
    {
        *effVal = 0;
    }

    dbgInfoEx("[%s]: chan'%u, effVal'%u, retComp'%d, retVal'%d \n", __FUNCTION__, bspChan, *effVal, retComp, retVal);

    return retVal;
}

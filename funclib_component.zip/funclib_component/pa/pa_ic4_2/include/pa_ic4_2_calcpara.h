/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 :
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 原始作者 : N/A
* 创建日期 :
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: N/A
* 修改日戳:
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_PA_IC4_2_CALCPARA_H_
#define _FUNCLIB_PA_IC4_2_CALCPARA_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pacommon.h"
#include "ichaladaptbspapi.h"

#define IOCTRL_EXPRNADD_LEN 50
/*DPDIC4_2中的硬件寄存器单位底层是737.28单位，单位转换: us转换成737.28CLK数*/
#define DOUBLE_US_2_UINT32_737(a)   (UINT32)(((DOUBLE)(a))*((DOUBLE)737.28))

/*DPDIC4_2中的硬件寄存器单位底层是737.28单位，单位转换: 737.28CLK数转换成us*/
#define UINT32_737_2_DOUBLE_US(a)   (DOUBLE)(((DOUBLE)(a))/((DOUBLE)737.28))
#define AAC_RF_SWITCH_PARA_UPDATE_OFF    (UINT32)(0)
#define AAC_RF_SWITCH_PARA_UPDATE_ON     (UINT32)(1)

typedef struct
{
    DOUBLE txEnAdvOn;          
    DOUBLE paAdvOn;  
    DOUBLE txEnDlyOff;
    DOUBLE paDlyOff;
    DOUBLE rxEnAdvOn;
    DOUBLE lnaAdvOn;
    DOUBLE rxEnDlyOff;
    DOUBLE lnaDlyOff;
    DOUBLE txEnGap;
    DOUBLE paGap;
    DOUBLE rxEnGap;
    DOUBLE lnaGap;
    DOUBLE switchAdv;
    DOUBLE switchDly;
} T_TDD_IO_BASE_PARA_INFO;  /*14个基础固定的延时参数*/


#if 0/*  T_TddIoRcdPreVal此结构体的作用在于，4.0里某些参数 给的算法是 “使用参数x”,结构体中的元素用来保存x的值，4.2暂时无此场景，先屏蔽*/
typedef struct TddIoRcdPreVal
{
    DOUBLE para3Pa;
    DOUBLE para3TxEn;
    DOUBLE para8Lna;
    DOUBLE para8RxEn;
    DOUBLE para8Tivalid;
    DOUBLE para11S3;
    DOUBLE para11LnaSw;
}T_TddIoRcdPreVal;
#endif

/* 用于和AC功能模块进行信息交互 */
typedef UINT32 (*FUNC_GET_MODE_VAL)(VOID);
typedef UINT32 (*FUNC_GET_AC_VAL)(UINT32 acType, UINT32 radio, DOUBLE* pfVal);
typedef double (*RFSWITCH_PARA_CALLBACK)(UINT32 ioParaType,UINT32 acType, UINT32 radio);
typedef struct Tag_AntCalInterface
{
    FUNC_GET_MODE_VAL pFuncGetModeVal;
    FUNC_GET_AC_VAL pFuncGetdGp2Ac;
    FUNC_GET_AC_VAL pFuncGetdGp2AcEnd;
}T_AntCalInterface;

enum _RFSWITCH_PARA_TYPE
{
   DLYOFF_PA1,
   DLYOFF_TXEN1,
   DLYOFF_AMP1,
   DLYOFF_PA2,
   DLYOFF_TXEN2,
   DLYOFF_AMP2,
   ADVON_PA5,
   ADVON_TXEN5,
   ADVON_AMP5,
   ADVON_LNASW7,
   ADVON_RXEN7,
   ADVON_LNAPWR7,
   ADVON_LNASW8,
   ADVON_RXEN8,
   ADVON_LNAPWR8,
   DLYOFF_LNASW11,
   DLYOFF_RXEN11,
   DLYOFF_LNAPWR11,
   DLYOFF_ACTX0_SW1,
   ADVON_ACTX0_SW5,
   DLYOFF_ACRX0_SW1,
   ADVON_ACRX0_SW5,
   DLYOFF_ACCAL0_SW1,
   ADVON_ACCAL0_SW5,
   PARA_TYPE_NUM,
};

typedef UINT32 (*AacRfSwitchParaCal)(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);
typedef struct tag_AacRfSwitchParaCal
{
    UINT32 ioParaType;
    AacRfSwitchParaCal pFunc;
    const CHAR *pFuncName;
}T_AacRfSwitchParaCal;

UINT32 Para1_DlyOff_PaTxSw(UINT32 acType, UINT32 radio);
UINT32 Para1_DlyOff_TrxTxEn(UINT32 acType, UINT32 radio);
UINT32 Para1_DlyOff_TxAmpPwr(UINT32 acType, UINT32 radio);
UINT32 Para2_DlyOff_PaTxSw(UINT32 acType, UINT32 radio);
UINT32 Para2_DlyOff_TrxTxEn(UINT32 acType, UINT32 radio);
UINT32 Para2_DlyOff_TxAmpPwr(UINT32 acType, UINT32 radio);
UINT32 Para5_AdvOn_PaTxSw(UINT32 acType, UINT32 radio);
UINT32 Para5_AdvOn_TrxTxEn(UINT32 acType, UINT32 radio);
UINT32 Para5_AdvOn_TxAmpPwr(UINT32 acType, UINT32 radio);
UINT32 Para7_AdvOn_LnaRxSw(UINT32 acType, UINT32 radio);
UINT32 Para7_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio);
UINT32 Para7_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio);
UINT32 Para8_AdvOn_LnaRxSw(UINT32 acType, UINT32 radio);
UINT32 Para8_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio);
UINT32 Para8_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio);
UINT32 Para11_DlyOff_LnaRxPwr(UINT32 acType, UINT32 radio);
UINT32 Para11_DlyOff_LnaRxSw(UINT32 acType, UINT32 radio);
UINT32 Para11_DlyOff_TrxRxEn(UINT32 acType, UINT32 radio);
UINT32 Para13_DlyOff_TrxRxEnAc(UINT32 acType, UINT32 radio);
UINT32 Para13_DlyOff_TrxTxEnAc(UINT32 acType, UINT32 radio);
UINT32 Para13_S1_AcTxSw(UINT32 acType, UINT32 radio);
UINT32 Para13_S2Rev_AcRxSw(UINT32 acType, UINT32 radio);
UINT32 Para13_S3Rev_AcCalSw(UINT32 acType, UINT32 radio);
UINT32 Para14_DlyOff_TrxRxEnAc(UINT32 acType, UINT32 radio);
UINT32 Para14_DlyOff_TrxTxEnAc(UINT32 acType, UINT32 radio);
UINT32 Para14_S1_AcTxSw(UINT32 acType, UINT32 radio);
UINT32 Para14_S2Rev_AcRxSw(UINT32 acType, UINT32 radio);
UINT32 Para14_S3Rev_AcCalSw(UINT32 acType, UINT32 radio);
UINT32 Para5_AdvOn(UINT32 ioType, UINT32 acType, UINT32 radio,UINT32 baseType);
UINT32 Para2_DlyOff(UINT32 ioType, UINT32 acType, UINT32 radio,UINT32 baseType);
UINT32 Para1_DlyOff(UINT32 ioType, UINT32 acType, UINT32 radio, UINT32 baseType);
UINT32 BspSetTddIoTddId(UINT32 tddIdx);
UINT32 BspGetTddIoErrRcdGpNum(VOID);
UINT32 BspSetRfBasePara(VOID);
UINT32 BspTddIoBaseParaInit(T_TDD_IO_BASE_PARA_INFO* pPara);
UINT32 BspSaveTddIoBasePara(T_TDD_IO_BASE_PARA_INFO* pPara);
T_TDD_IO_BASE_PARA_INFO* BspGetTddIoBasePara(VOID);
UINT32 BspTddIoBaseParaGloValPrint(VOID);
UINT32 BspSetAdvDiffBoardFlag(UINT32 Flag);
UINT32 BspGetAdvDiffBoardDiffFlag(VOID);
UINT32 Para1_DlyOff_TrxOrfbSw(UINT32 acType, UINT32 radio);
UINT32 Para2_DlyOff_TrxOrfbSw(UINT32 acType, UINT32 radio);
UINT32 Para5_AdvOn_TrxOrfbSw(UINT32 acType, UINT32 radio);
UINT32 BspBoardTddIoInfoInit(T_TDD_IO_BASE_PARA_INFO *pParaInfo);  /*单板下传入基础时延参数，目前看单板之间无差异*/

UINT32 BspPaCtrlAcCallBackFuncInit(T_AntCalInterface *pInterFace);
UINT32 Para13_AcEnDly(UINT32 acType, UINT32 radio,UINT32 acCtrlType);
UINT32 Para14_AcDisEnDly(UINT32 acType, UINT32 radio,UINT32 acCtrlType);
UINT32 BspRfSwitchParaCallBack(RFSWITCH_PARA_CALLBACK pFuncCallback);
UINT32 BspFixRfSwitchPara(UINT32 ioParaType,UINT32 acType, UINT32 radio, double *pTmpPara);
UINT32 BspGetGpTimeAndUeAdvGap(UINT32 radio, DOUBLE *pGpTime, DOUBLE *pUeAdvGap);
UINT32 dUeAdvGap(UINT32 radio, DOUBLE* UeAdvGap);
UINT32 dUeGap(UINT32 radio, DOUBLE* UeGap);
UINT32 dMixAdvDiffComp(UINT32 radio, DOUBLE* mixAdvDiffCompVal);
UINT32 Para1_DlyOff_AcSw(UINT32 acType, UINT32 radio,UINT32 acCtrlType);
UINT32 Para5_AdvOn_AcSw(UINT32 acType, UINT32 radio,UINT32 acCtrlType);
UINT32 Para1_DlyOff_PaTxSw_NCR2(UINT32 radio, UINT32 *delay);
UINT32 Para1_DlyOff_TrxTxEn_NCR2(UINT32 radio, UINT32 *delay);
UINT32 Para2_DlyOff_PaTxSw_NCR(UINT32 radio, UINT32 acType, UINT32 *delay);
UINT32 Para2_DlyOff_TrxTxEn_NCR(UINT32 radio, UINT32 acType, UINT32 *delay);
UINT32 Para5_AdvOn_PaTxSw_NCR(UINT32 radio, UINT32 *delay);
UINT32 Para5_AdvOn_PaTxSw_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay);
UINT32 Para5_AdvOn_TrxTxEn_NCR(UINT32 radio, UINT32 *delay);
UINT32 Para5_AdvOn_TrxTxEn_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay);
UINT32 Para7_AdvOn_LnaRxSw_NCR(UINT32 radio, UINT32 *delay);
UINT32 Para7_AdvOn_LnaRxSw_NCR2(UINT32 radio, UINT32 *delay);
UINT32 Para7_AdvOn_TrxRxEn_NCR(UINT32 radio, UINT32 *delay);
UINT32 Para7_AdvOn_TrxRxEn_NCR2(UINT32 radio, UINT32 *delay);
UINT32 Para11_DlyOff_LnaRxSw_NCR(UINT32 radio, UINT32 *delay);
UINT32 Para11_DlyOff_LnaRxSw_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay);
UINT32 Para11_DlyOff_TrxRxEn_NCR(UINT32 radio, UINT32 *delay);
UINT32 Para11_DlyOff_TrxRxEn_NCR2(UINT32 radio, UINT32 acType, UINT32 *delay);
UINT32 BspGetTddIoGpNum(UINT32 radio, UINT32* GpNumX);
UINT32 BspGetD1GpTime45G(VOID);
UINT32 BspGetDUeAdv45G(VOID);
DOUBLE BspGetPaAdvOn(VOID);
DOUBLE BspGetPaDlyOff(VOID);
DOUBLE BspAacRfSwitchCalPara(UINT32 ioParaType,UINT32 acType, UINT32 radio);
void BspSetAacRfSwitchParaUpdateSw(UINT32 sw);
UINT32 BspCalAacPara2_DlyOff_PaTxSw(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);
UINT32 BspCalAacPara2_DlyOff_TrxTxEn(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);
UINT32 BspCalAacPara2_DlyOff_AmpSw(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);
UINT32 BspCalAacPara8_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);
UINT32 BspCalAacPara8_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);
UINT32 BspCalAacPara7_AdvOn_LnaRxPwr(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);
UINT32 BspCalAacPara7_AdvOn_TrxRxEn(UINT32 acType, UINT32 radio, DOUBLE *pTmpPara);

#ifdef __cplusplus
}
#endif

#endif 



/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pa_ic4_2_ctrl.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功放控制接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _FUNCLIB_PA_IC4_2_CTRL_H_
#define _FUNCLIB_PA_IC4_2_CTRL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pacommon.h"
#include "funccommon.h"

#define AMP_TYPE_PA                         0
#define AMP_TYPE_LNA                        1
#define PA_VCC_NEGATIVE_8V_STATUS_WARNING   0  //存在-8V状态告警
#define PA_VCC_NEGATIVE_8V_STATUS_NORMAL    1  //-8V告警状态ok
#define PA_VCC_NEGATIVE_8V_EVENT_WARNING    1  //存在-8V事件告警
#define PA_VCC_NEGATIVE_8V_EVENT_NORMAL     0  //-8V告警事件ok

#define InvalidVal 0
#define ValidVal 1

#define TDD_IO_PIN_NUM_COMMON_8 ((UINT32)8)
#define TDD_IO_PIN_NUM_COMMON_4 ((UINT32)4)
#define TDD_IO_PIN_TRX_EN_AC_NUM_2 ((UINT32)2)
#define AC0_CTRL_TX_SW ((UINT32)0)
#define AC0_CTRL_RX_SW ((UINT32)1)
#define AC0_CTRL_CAL_SW ((UINT32)2)
#define AC1_CTRL_TX_SW ((UINT32)3)
#define AC1_CTRL_RX_SW ((UINT32)4)
#define AC1_CTRL_CAL_SW ((UINT32)5)
#define AC2_CTRL_TX_SW ((UINT32)6)
#define AC2_CTRL_RX_SW ((UINT32)7)
#define AC2_CTRL_CAL_SW ((UINT32)8)
#define AC_CTRL_TYPE_NUM ((UINT32)9)

#define DPDIC_MAX_TDD_NUM    4

#define PA_SWITCH_OFF 0
#define PA_SWITCH_ON  1
#define PA_SWITCH_ON_FDD   2


#define LNA_SWITCH_OFF 0
#define LNA_SWITCH_ON  1
#define LNA_SWITCH_ON_FDD 2

#define AMP_SWITCH_OFF 0
#define AMP_SWITCH_ON  1
#define AMP_SWITCH_ON_FDD 2

#define TX_SWITCH_OFF 0
#define TX_SWITCH_ON  1
#define TX_SWITCH_ON_FDD   2

#define RX_SWITCH_OFF 0
#define RX_SWITCH_ON  1
#define RX_SWITCH_ON_FDD   2

#define FB_SWITCH_OFF 0
#define FB_SWITCH_ON  1
#define FB_SWITCH_ON_FDD   2

#define TX_AC_SWITCH_OFF 0
#define TX_AC_SWITCH_ON   1
#define TX_AC_SWITCH_ON_FDD    2

#define RX_AC_SWITCH_OFF 0
#define RX_AC_SWITCH_ON   1
#define RX_AC_SWITCH_ON_FDD    2

#define AC_CTRL_SWITCH_OFF 0
#define AC_CTRL_SWITCH_ON   1
#define AC_CTRL_SWITCH_ON_FDD    2

#define SWITCH_FDD_CTRL_MODE    1   /*FDD 模式*/
#define SWITCH_TDD_CTRL_MODE    0   /*TDD 模式*/

#define IO_DTX_OFF 0
#define IO_DTX_ON  1

#define IO_DTX_GP_SEL 1
#define IO_DTX_GP_NON_SEL   0

#define IO_DISABLE 0
#define IO_ENABLE  1

#define AC_SWITCH_TYPE_NUM (3)

#define HOST_PORT            (UINT32)(0)
#define SLAVE_PORT           (UINT32)(1)

enum _TEST_MODE_DEF_
{
    PA_PWR_TEST   = 0,  /* PA */
    LNA_PWR_TEST,      /* LNA*/
    TX_PWR_TEST,       /* TX*/
    RX_PWR_TEST,       /* RX*/
    AMP_SW_TEST,       /* AMP*/
    FB_PWR_TEST,       /* FB*/
    TXAC_PWR_TEST,     /* TxAc*/
    RXAC_PWR_TEST,     /* RxAc*/
    ACCTRL_PWR_TEST,   /* AcCtrl*/
    MODE_TYPE_NUM
};

typedef enum
{
    E_RF_SWITCH_EPLD_CTRL_INNER      = 0,//默认内置EPLD
    E_RF_SWITCH_EPLD_CTRL_EXT = 1,
}E_RF_SWITCH_EPLD_CTRL_METHOD;

enum
{
    SWITCH_TYPE_AMP,
    SWITCH_TYPE_PA,
    SWITCH_TYPE_TRX,
    SWITCH_TYPE_DSLNA,
    SWITCH_TYPE_LNA,
    SWITCH_TYPE_DPD,
    SWITCH_TYPE_MAX,
};

typedef struct
{
    UINT32 acCtrlType;  /*AC管脚号*/
    UINT32 tddNo;
    UINT32 bandNo;     /*band号 不同band 开关选择可能不一样*/
    UINT32 switchPara[AC_SWITCH_TYPE_NUM];
} T_TDDIO_AC_SWITCH_PARA;

/*---------------------------------------------------------*/
/*                        数据类型                         */
/*---------------------------------------------------------*/
typedef UINT32 (*PASW_CALLBACK_FUNCPTR)(UINT32 paChan, UINT32 sw);
typedef UINT32 (*RFSWITCH_GETGP_CALLBACK)(UINT32 tddId, UINT32 *pRadio, UINT32 *pTime);
typedef UINT32 (*SLAVE_RFSWITCH_CALLBACK)(UINT32 bspChan, UINT32 mode, UINT32 sw);
typedef UINT32 (*SET_SLAVE_PORT_RFSWITCH)(UINT32 chan, UINT32 swType, UINT32 sw, UINT32 swDly);
typedef UINT32 (*GET_SLAVE_PORT_RFSWITCH)(UINT32 portId, T_SlavePortRfSwitchSta *pStaAck);
typedef UINT32 (*GET_PA_REAL_SWITCH)(UINT32 sw);
/*---------------------------------------------------------*/
/*                        函数声明                         */
/*---------------------------------------------------------*/
UINT32 BspSetPaPwrSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetPaTddSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaTddSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetPaPowTxFddSwitch(UINT32 chan,UINT32 sw);
UINT32 BspSetLnaPowRxFddSwitch(UINT32 chan,UINT32 sw);
UINT32 BspSetLnaPowRxSwitch(UINT32 chan, UINT32 sw);
UINT32 BspGetLnaPowRxSwitch(UINT32 chan);
UINT32 BspGetPaPwrSwitch(UINT32 chan, UINT32* status);
UINT32 BspSetTxSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetRxSwitch(UINT32 chan,UINT32 sw);
UINT32 BspSetPaFddSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaFddSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetTxSwitchFdd(UINT32 chan, UINT32 sw);
UINT32 BspSetRxSwitchFdd(UINT32 chan, UINT32 sw);
UINT32 BspSetPaPowTxTddSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaPowRxTddSwitch(UINT32 chan, UINT32 sw);

UINT32 BspSetPaSwitchOnOff(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaSwitchOnOff(UINT32 chan, UINT32 sw);

UINT32 BspSetPaPmosCtrlFpgaMode(UINT32 ulSelecMode);
UINT32 BspSetPaPmosNegaVccWarnType(UINT32 warnType);

UINT32 BspPwrSavePaCtrl(UINT32 chan, UINT32 sw);
UINT32 BspPwrSaveLnaCtrl(UINT32 chan, UINT32 sw);
UINT32 BspPwrSavePmosCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetAcCtrlTddSwitch(UINT32 type, UINT32 sw);
UINT32 BspSetPaCtrlChnlSelFlag(UINT32 ulSelFlag);

UINT32 BspSetPaModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetPaSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetLnaSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaSwModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetLnaSwSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetTxAcModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetRxAcModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetTxAcSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetRxAcSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetAcCtrlModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetAcCtrlSwitchCtrl(UINT32 type, UINT32 sw);
UINT32 BspSwitchOffStaInit(VOID);
UINT32 BspSetPaTddIoSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetRxAcSwitch(UINT32 chan,UINT32 sw);
UINT32 BspSetTxAcSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetTddIoLnaswFlag(UINT32 flag);
UINT32 BspSetPaPowerPmosSwitch(UINT32 chanNo, UINT32 switchCtrl);
UINT32 BspSetDtxPaLnaEn(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxTransEn(UINT32 chan, UINT32 isEn);
UINT32 BspGetPaDacChipByBspChan(UINT32 ulRfChnl);
UINT32 BspSetDtxPaEn(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxLnaEn(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxTxEn(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxAmpEn(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxRxEn(UINT32 chan, UINT32 isEn);
UINT32 BspSetTddIoAcCtrlSwitch(UINT32 acType);
UINT32 BspSetTddIoAcCtrlSwitchFdd(UINT32 acType);
UINT32 BspSetPaSwCtrlMode(UINT32 paType);
UINT32 BspSetLnaSwCtrlMode(UINT32 lnaType);
UINT32 BspSetTxenoff(UINT32 startChn,UINT32 endChn);
UINT32 BspSetTxenonfdd(UINT32 startChn,UINT32 endChn);
UINT32 BspSetRxenoff(UINT32 startChn,UINT32 endChn);
UINT32 BspSetRxenon(UINT32 startChn,UINT32 endChn);
UINT32 BspSetRxenonfdd(UINT32 startChn,UINT32 endChn);
UINT32 BspSetAcctrlon(UINT32 startType,UINT32 endType);
UINT32 BspSetPaon(UINT32 startChn,UINT32 endChn);
UINT32 BspSetPaonfdd(UINT32 startChn,UINT32 endChn);
UINT32 BspSetLnaoff(UINT32 startChn,UINT32 endChn);
UINT32 BspSetLnaon(UINT32 startChn,UINT32 endChn);
UINT32 BspSetLnaonfdd(UINT32 startChn,UINT32 endChn);
UINT32 BspSetAcCtrlSwitch(UINT32 type, UINT32 sw);
UINT32 BspSetAcFixTxMode(VOID);
UINT32 BspSetAcFixRxMode(VOID);
VOID BspSetAcBandNo(UINT32 bandNo);

UINT32 BspSetTddIoInitFlag(UINT32 flag);
UINT32 BspGetTddIoInitFlag(VOID);
UINT32 paon(UINT32 startChn,UINT32 endChn);
UINT32 paoff(UINT32 startChn,UINT32 endChn);
UINT32 ampon(UINT32 startChn,UINT32 endChn);
UINT32 ampoff(UINT32 startChn,UINT32 endChn);
UINT32 amponfdd(UINT32 startChn,UINT32 endChn);
UINT32 lnaon(UINT32 startChn,UINT32 endChn);
UINT32 lnaoff(UINT32 startChn,UINT32 endChn);

UINT32 paonfdd(UINT32 startChn,UINT32 endChn);
UINT32 lnaonfdd(UINT32 startChn,UINT32 endChn);
UINT32 txenoff(UINT32 startChn,UINT32 endChn);
UINT32 txenon(UINT32 startChn,UINT32 endChn);
UINT32 txenonfdd(UINT32 startChn,UINT32 endChn);
UINT32 rxenoff(UINT32 startChn,UINT32 endChn);
UINT32 rxenon(UINT32 startChn,UINT32 endChn);
UINT32 rxenonfdd(UINT32 startChn,UINT32 endChn);
UINT32 acctrloff(UINT32 startType,UINT32 endType);
UINT32 acctrlon(UINT32 startType,UINT32 endType);
UINT32 acctrlonfdd(UINT32 startType,UINT32 endType);
UINT32 BspGetLnaModeCtrl(UINT32 chan);
UINT32 BspGetPaModeCtrl(UINT32 chan);
UINT32 BspSetLnaBypassCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaSwCtrl(UINT32 chan, UINT32 sw);
UINT32 BspGetPaLnaCtrlMode(UINT32 typePaLna, UINT32 chan, UINT32 *pCtrlMode);
UINT32 IsLnaAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsLnaAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsLnaSwAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsLnaSwAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsRxAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsRxAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsFbAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsFbAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsTxAllChnsOn(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 IsPaAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 BspSwitchOffStaSet(UINT32 ioChan, UINT32 linkPro, UINT8 *offSta);
UINT32 IsTxAllChnsOff(UINT32 ioChan, UINT32 linkPro, UINT32 sw);
UINT32 BspGetAmpSwitch(UINT32 chan);
UINT32 BspSetAmpSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetPaPowTxSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetPaSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetSwitchModeCtrl(UINT32 acType, UINT32 tddsel);
UINT32 BspSetAmpFddSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetAmpTddSwitch(UINT32 chan, UINT32 sw);
UINT32 BspGetAmpSwitch(UINT32 chan);
UINT32 BspGetTxSwitch(UINT32 chan);
UINT32 BspGetRxSwitch(UINT32 chan);
UINT32 BspSetAppPaStatus(UINT32 chan,UINT32 sw);
UINT32 BspGetAppPaStatus(UINT32 chan);
UINT32 BspSetTddIoDtxEn(UINT32 bspChan, UINT32 isEn);
UINT32 BspInitAcCtrlSwitchPara(T_TDDIO_AC_SWITCH_PARA *pAcSwitchPara, UINT32 paraNum);
UINT32 BspSetAcCtrlFddSwitch(UINT32 type, UINT32 sw);
UINT32 BspSetPaLnaUeEn(UINT32 chn, UINT32 sw);
UINT32 BspSetPaLnaBitmapByChn(UINT32 chn, UINT32 bitmapVal);
UINT32 BspSetAllPaLnaBitmap(VOID);
UINT32 BspRfSwitchGetGpCallBack(RFSWITCH_GETGP_CALLBACK pFuncCallback);
UINT32 BspSlaveRfSwitchCallBack(SLAVE_RFSWITCH_CALLBACK pFuncCallback);
UINT32 BspSetSlavePortRfSwitchCallBack(SET_SLAVE_PORT_RFSWITCH pFuncCallback);
UINT32 BspGetSlavePortRfSwitchCallBack(GET_SLAVE_PORT_RFSWITCH pFuncCallback);
UINT32 BspGetPaSwitchStaCallBack(GET_PA_REAL_SWITCH pFuncCallback);
UINT32 BspChangePaSwitchCtrl(UINT32 sw);
VOID BspSetTddFddSelMode(UINT32 mode);
UINT32 BspGetLnaSwitchCtrl(UINT32 chan);
#ifdef __cplusplus
}
#endif

#endif 



/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pa_c_gridvolt.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功放控制接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _FUNCLIB_PA_IC4_2_GRIDVOLT_H_
#define _FUNCLIB_PA_IC4_2_GRIDVOLT_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "paapi.h"
#include "rftable_padacset.h"
#include "bsppub.h"

typedef UINT32 (*pQorvoFunc)(UINT32 chan, INT32 *pDigGainQorvo, INT32 *pDacVolt, UINT32 *paType);
typedef UINT32 (*pGetGridVoltAdjustFunc)(UINT32 ulPathNum, UINT32 GridVoltType, INT32 *pDacVolt);

#define TEMP_POINT_MAX_NUM     10
#define PA_GRID_CHANNUL_NUM     6
#define PARfCHAN_MISMATCH        1

#define INPUT_POINTER_CHECK_CONTINUE(ppointer)                     \
    if (NULL == ppointer)                                          \
    {                                                              \
        dbgInfoEx("%s:Input Pointer is NULL!\n",__FUNCTION__);     \
        continue;                                                  \
    }

typedef struct _PaGridVoltAdjInfo
{
    UINT32 chanNo;
    INT32  powerDbm;
    INT32  paGridVolt[PA_GRID_CHANNUL_NUM];
}PaGridVoltAdjInfo;

typedef struct _ChanPwrInfo
{
    PaGridVoltAdjInfo ulChanPwrInfo[ANT_CHANNEL_NUM_MAX];
    UINT32 ulChanValidNum;
}ChanPwrInfo;

UINT32 BspPaDacDataInit(VOID);
UINT32 BspSetPaVibas(UINT32 index);
UINT32 BspClrPaVibasByChan(UINT32 index,UINT32 ulRfChnl);
UINT32 BspDacChanToPaChan(UINT32 chip, UINT32 dac, UINT32 *pa);
UINT32 BspSetPaChanChipDacCfg(T_PaChipDacChanInfo* pPaPara,UINT32 cfgNum);
VOID BspSetVibasDisable(UINT32 chanNo);
VOID BspSetVibasEnable(UINT32 chanNo);
UINT32 BspRegisterQorvoAnaCall(pQorvoFunc pGetQorvoCall);
UINT32 BspSetPaGridVolt(UINT32 ulRfChnl, UINT32 ulSubChnl, INT32 iVolt);
UINT32 BspGetPaGridVolt(UINT32 ulRfChnl, UINT32 ulSubChnl, INT32 *piVolt);

UINT32 BspSetPaVibasNewIndex(UINT32 chanNo, UINT32 parLevel, UINT32 dataIndex); /* 使用PaEnergySavingAdj.txt栅压温补，需要从其他模块传入parLevel和 dataIndex */
VOID BspSetPaVibasDeltaDacVolt(UINT32 vbiasType, INT32 volt);
UINT32 BspSetPaGridVoltFix(UINT32 ulRfChnl, UINT32 ulVbiasType,UINT32 ulDacPath, INT32 iVolt);
UINT32 BspGetPaGridVoltFix(UINT32 ulRfChnl, UINT32 ulVbiasType,UINT32 ulDacPath, INT32 *piVolt);
VOID BspRecordPaGridVoltByChanPower(UINT32 chanNum, ChanPower pChanPwr[]);
UINT32 BspSetPaVibasByChanNew(UINT32 index,UINT32 ulRfChnl);
UINT32 BspGetPaGirdValByType(UINT32 ulRfChnl, UINT32 vbiasType, INT32 *pVal);
UINT32 BspRegisterGetGridAdjustFunc(pGetGridVoltAdjustFunc pGetGridVolt);
UINT32 BspGetVibasEnableFlag(UINT32 chanNo, UINT32 *pPaVibasFlag);
UINT32 BspGetPaDacClassNumIdx(T_PaDacSetCaliData *ptData, UINT32 paChn);
UINT32 BspGetPaGridVoltTempComp(UINT32 ulChan, UINT32 vbiasType, INT32 *pVoltVibas);
UINT32 BspSetPaGridVoltTempComp(UINT32 ulChan, UINT32 vbiasType, INT32 pVoltVibas);
UINT32 BspPaSetVibasCallBack(UINT32 (*pFuncCallback)(UINT32 index));
UINT32 BspGetPaChanMaxNum(VOID);
UINT32 BspSetPachnRfchnMismatchFlag(UINT32 flag);
UINT32 BspGetPachnRfchnMismatchFlag(VOID);

#ifdef __cplusplus
}
#endif
#endif 



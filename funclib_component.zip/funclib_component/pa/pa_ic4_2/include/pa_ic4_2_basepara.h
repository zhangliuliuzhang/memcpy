/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RHP Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 :
* 文件名称 :
* 文件标识 :
* 内容摘要 :此文件对应射频开关excel配置数据中TDD可配场景
* 注意事项 :
* 原始作者 :
* 创建日期 :
* 当前版本 :
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单:
* 责 任 人:
* 修改日戳:
* 变更说明:
*----------------------------------------------------------------------------
*/

//该文件只允许被调用1次，请勿随意调用
#ifndef _FUNCLIB_PA_IC4_2_BASEPARA_H_
#define _FUNCLIB_PA_IC4_2_BASEPARA_H_

#ifdef __cplusplus
extern "C" {
#endif
    
/*************** 射频提供的RF基础参数(1.1 ~ 1.6), Unit: us 此部分参数固定****************/
/*1.1 射频提供的RF基础参数：下行提前打开*/
static DOUBLE dTxEnAdvOn   = 9.000000;
static DOUBLE dPaAdvOn    =  5.000000;

/*1.2 射频提供的RF基础参数：下行延迟关闭*/
static DOUBLE dTxEnDlyOff = 2.000000;
static DOUBLE dPaDlyOff  = 1.300000;

/*1.3 射频提供的RF基础参数：上行提前打开*/
static DOUBLE dRxEnAdvOn   = 4.000000;
static DOUBLE dLnaAdvOn   = 3.500000;

/*1.4 射频提供的RF基础参数：上行延迟关闭*/
static DOUBLE dRxEnDlyOff   = 3.0000000;
static DOUBLE dLnaDlyOff   = 3.500000;

/*1.5 射频提供的RF基础参数：发送关闭到接收打开的保护间隔*/
static DOUBLE dTxEnGap   = 0.000000;
static DOUBLE dPaGap   = 0.000000; //3.500000;方案原来基于的TDD_UL包含该间隔，现不包含，所以变更为0
static DOUBLE dDmimoTxRxGap = 0.500000;

/*1.6 射频提供的RF基础参数：接收关闭到发送打开的保护间隔*/
static DOUBLE dRxEnGap   = 0.000000;
static DOUBLE dLnaGap   = 0.000000; //3.500000;

/*1.7 Dmimo TXEN TXAMP滞后功放关闭量 */
static DOUBLE dDmimoTxenTxAmpDly = 1.0000000;
/*Dmimo 下行LNA延迟关闭量*/
static DOUBLE dDmimoLnaDlyOff  = 6.000000;
/*Dmimo 下行RXEN延迟关闭量*/
static DOUBLE dDmimoRxenDlyOff    = 5.500000;

/* NCR 下行dspLen耗时 20us */
static DOUBLE dDspLen     = 20.00000;
static DOUBLE dDspLen_9us = 9.00000;


/******************************************************************/

/*************** 通用的Switch基础参数(2.1 ~ 2.2), Unit: us 此部分参数固定****************/
/*2.1通用的Switch基础参数：提前量*/
static DOUBLE dSwitchAdv   = 2.000000;

/*2.2通用的Switch基础参数：滞后量*/
static DOUBLE dSwitchDly   = 2.000000;
/******************************************************************/

/************ Ue提前、Ue保护量、GP、Ts（3.1~3.10）, Unit: us 此部分都是通过接口获取，并没有实际使用**************/
/*3.1 混模UE提前量： 624@30.72，系统和算法确定的公式，和带宽无关 */
static DOUBLE dUeAdv45G = (DOUBLE)20.312500;

/*3.2 混模UE保护量：16@30.72，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeGap45G = (DOUBLE)0.520833;

/*3.3 混模UE提前量+保护量：624+16@30.72 ，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeAdvGap45G = (DOUBLE)20.833333;

/*3.4 NR单模UE提前量： 400@30.72，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeAdv5G = (DOUBLE)13.020833;

/*3.5 NR单模UE保护量：16@30.72，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeGap5G = (DOUBLE)0.520833;

/*3.6 NR单模UE提前量+保护量：400+16@30.72 ，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeAdvGap5G = (DOUBLE)13.541666;

/*3.7 LTE单模UE提前量： 624@30.72，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeAdv4G = (DOUBLE)20.312500;

/*3.8 LTE单模UE保护量： 16@30.72，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeGap4G = (DOUBLE)0.520833;

/*3.9 LTE单模UE提前量+保护量： 624+16@30.72 ，系统和算法确定的公式，和带宽无关 */
//static DOUBLE dUeAdvGap4G = (DOUBLE)20.833333;

/*3.10 */
//static DOUBLE dUeAdvGap45G = (DOUBLE)20.833333; //

/************ GP、Ts（4.1~4.6）, Unit: us 此部分都是通过接口获取，并没有实际使用 **************/
/*4.1 混模的1Gp符号时间 or 1SymTime: 4384/122.88， 和带宽无关*/
static DOUBLE d1GpTime45G = (DOUBLE)35.6770833;
static DOUBLE d1SymTime45G = (DOUBLE)35.6770833;//d1GpTime45G;

/*4.2 混模的1Ts时间: 1/122.88，和带宽无关*/
//static DOUBLE d1TsTime45G = (DOUBLE)0.00813802;

/*4.3 NR单模的1Gp符号时间 or 1SymTime: 4384/122.88， 和带宽无关*/
//static DOUBLE d1GpTime5G =  (DOUBLE)35.6770833; //d1GpTime45G;    //NR单模同混模
static DOUBLE d1SymTime5G = (DOUBLE)35.6770833; //d1SymTime45G;//NR单模同混模

/*4.4 NR单模的1Ts时间: 1/122.88，和带宽无关*/
//static DOUBLE d1TsTime5G =  (DOUBLE)0.00813802;//d1TsTime45G;//NR单模同混模

/*4.5 LTE单模的1Gp符号时间 or 1SymTime: 4384/30.72 ，2/7、3/8？ 和带宽无关*/
//static DOUBLE d1GpTime4G = 71.3541667; //142.7083333;//方案的表格中按GP数 LTE/NR=1/4，而实际是LTE/NR=1/2，所以时间有所变化
static DOUBLE d1SymTime4G = 71.3541667; //142.7083333;//

/*4.6 LTE单模的1Ts时间: 1/30.72，和带宽无关*/
static DOUBLE d1TsTime4G = 0.0325520;
/******************************************************************/

/************ AC前、AC起始位置、AC结束位置, Unit: us 此部分都是通过接口获取，并没有实际使用*********************/
/*4.1 混模上行AC前（AC所在GP符号开始位置到AC序列位置）: 1096*1TsTime，和带宽无关*/
//static DOUBLE dGp1Sym2ULAc45G = (DOUBLE)8.919270;

/*4.2 混模下行AC前（AC所在GP符号开始位置到AC序列位置）: 600*1TsTime，和带宽无关*/
static DOUBLE dGp1Sym2DLAc45G = (DOUBLE)4.882812;

/*4.3 NR单模上行AC前（AC所在GP符号开始位置到AC序列位置）: 1096*1TsTime，和带宽无关*/
//static DOUBLE dGp1Sym2ULAc5G = (DOUBLE)8.919270;

/*4.4 NR单模下行AC前（AC所在GP符号开始位置到AC序列位置）: 600*1TsTime，和带宽无关*/
static DOUBLE dGp1Sym2DLAc5G = (DOUBLE)4.882812;

/*4.5 LTE单模上行AC前（AC所在GP符号开始位置到AC序列位置）: d1GpTime4G-1584*1TsTime，excel中是根据AC结束位置倒推*/
//static DOUBLE dGp1Sym2ULAc4G = (DOUBLE)91.145965;

/*4.6 LTE单模下行AC前（AC所在GP符号开始位置到AC序列位置）:  d1GpTime4G-1584*1TsTime*/
//static DOUBLE dGp1Sym2DLAc4G = (DOUBLE)91.145965;
/******************************************************************/

static DOUBLE dTsRealLength = (DOUBLE)8192.0; /*8192为Ts真实序列长度*/
static DOUBLE dTsResLength = (DOUBLE)2457.6; /*2457.6为预留前插0和后插0长度*/
static DOUBLE dTsSampRate =  (DOUBLE)245.76; /*245.76为采样率*/

#ifdef __cplusplus
}
#endif

#endif


/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_ic4_tddrfctrl.h
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 原始作者 : N/A
* 创建日期 : 2020-11-18 21:01:35
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: N/A
* 修改日戳: 2020-11-18 21:01:35
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_PA_IC4_2_TDDRFCTRL_H_
#define _FUNCLIB_PA_IC4_2_TDDRFCTRL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pacommon.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"
#include "io_api.h"

/***************************************************************************************/
#define DPDIC_MAX_TDD_NUM    4  /*最大支持4套tdd*/
#define DPDIC_MAX_TIMING_GEN_SEL_TYPE    DPDIC_MAX_TDD_NUM  /*最大支持4种timing_gen的配置方案，目前只有两种，fdd机型用一种，tdd机型用一种，T+F组合用*/
#define DPDIC_MAX_MODE_MAP_SEL 10   /*最大支持10种modemap选择*/

enum E_TDD_IO_DEF_TYPE
{
    E_TDD_IO_DEF_TYPE_ENGAGED,
    E_TDD_IO_DEF_TYPE_ENGAGED_SETS,
    E_TDD_IO_DEF_TYPE_ENGAGED_MAX,
    E_TDD_IO_DEF_TYPE_PAEXCEPT = 0,            //0默认不例外的常规情况，即PA是1开0关，例外时要颠倒成0开1关
    E_TDD_IO_DEF_TYPE_LNAEXCEPT,           //0默认不例外的常规情况，即LNA是0开1关，例外时要颠倒成1开0关
    
    E_TDD_IO_DEF_TYPE_TXENEXCEPT,          //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_TXENACCHANEXCEPT,    //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_RXENEXCEPT,          //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_RXENACCHANEXCEPT,    //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_ORXENEXCEPT,         //0默认不例外的常规情况，
    
    E_TDD_IO_DEF_TYPE_TXACENEXCEPT,        //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_RXACENEXCEPT,        //0默认不例外的常规情况，
    
    E_TDD_IO_DEF_TYPE_ACCTRL0EXCEPT,       //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_ACCTRL1EXCEPT,       //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_ACCTRL2EXCEPT,       //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_ACCTRL3EXCEPT,       //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_ACCTRL4EXCEPT,       //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_ACCTRL5EXCEPT,       //0默认不例外的常规情况，
    
    E_TDD_IO_DEF_TYPE_LNASWITCHEXCEPT,     //0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_TIVALIDEXCEPT,      //0默认不例外的常规情况，
    
    E_TDD_IO_DEF_TYPE_DLPADTXEXECEPT,      //DTX合路，0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_DLTXENDTXEXECEPT,    //DTX合路，0默认不例外的常规情况，
    
    E_TDD_IO_DEF_TYPE_DLPAPAPTEXECEPT,     //PAPT合路，0默认不例外的常规情况，
    E_TDD_IO_DEF_TYPE_DLTXENPAPTEXECEPT,   //PAPT合路，0默认不例外的常规情况，
    
    E_TDD_IO_DEF_TYPE_PAALARMCOMORNOT,  //PA告警合路，0默认不例外的常规情况
    E_TDD_IO_DEF_TYPE_LNAALARMCOMORNOT,  //LNA告警合路，0默认不例外的常规情况
    E_TDD_IO_DEF_TYPE_DLPOSTALARMOUTSELX, //告警输出选择，0默认不例外的常规情况
    E_TDD_IO_DEF_TYPE_PA_MODEMAP,        /*PA模块的modemap 0不特殊处理1需要特殊处理*/
    E_TDD_IO_DEF_TYPE_MAX
};

/***************************************************************************************/

//0:1；1:0；2：内部DTX结果；其他：常1（若设置其他值，则等同0:1）；
#define IO_DTXOUT_ONE          0
#define IO_DTXOUT_ZERO         1
#define IO_DTXOUT_INNER_RET    2

//0:1；1:0；2;GP0; 3:GP1; 4:GP2 5:GP3; 其他：1
#define IO_DTX_GPSEL_ONE    0
#define IO_DTX_GPSEL_ZERO   1
#define IO_DTX_GPSEL_GP0    2
#define IO_DTX_GPSEL_GP1    3
#define IO_DTX_GPSEL_GP2    4
#define IO_DTX_GPSEL_GP3    5


#define IO_DTX_ALL_MODE_SEL    0x3ff

#define IO_OE_ENABLE 1
#define IO_OE_DISABLE 0

#define DTX_CHAN_MAX  8
#define FDDAC_REG_CFG_NUM  (7)
typedef struct
{
    UINT32 tddIdx;          
    UINT32 acType;          
} T_TDD_IO_RECORD_INFO;   


typedef enum
{
    E_TDDIO_CTRL_NORMAL    = 0,//常规情况
    E_TDDIO_CTRL_EXCEPT    = 1,//例外的处理，需要对平台这取反
}E_TDDIO_EXCEPT_CTRL;

typedef enum
{
    E_TRX_TXEN_TDDIO = 0,
    E_TRX_RXEN_TDDIO,
    E_TRX_ORXEN_TDDIO,
    E_TRX_MAX_TDDIO,
}E_TDDIO_TRX_TDDIO;

typedef enum
{
    E_INIT_TYPE_SINGLE_TDD = 0,
    E_INIT_TYPE_FDD,
    E_INIT_TYPE_TDDFDD,
    E_INIT_TYPE_MULTI_TDD,
    E_INIT_TYPE_QCELL,
    E_INIT_TYPE_MS,
    /* Started by AICoder, pid:oca13z6c1680ca91449c09d0301b5b183d75ff75 */
    E_INIT_TYPE_NCR,
    /* Ended by AICoder, pid:oca13z6c1680ca91449c09d0301b5b183d75ff75 */
    E_INIT_TYPE_MAX,
}E_TDDIO_INIT_TYPE;
/* 定义Tdd Io控制的例外情况的结构体，注意下面的Except为1时代表例外，需要对平台默认值进行反转
 * 目前主要为以下几项，同时添加预留字段方便后续扩充
 * (1)各个管脚的最后一级输出
 * (2)DTX合入/使能
 * (3)功放保护告警合入
 *  */

typedef struct T_TDDIO_EXCEPT_CTRL
{
	UINT32 tddOutSel[E_TDD_IO_DEF_TYPE_MAX][E_TDD_IO_DEF_TYPE_ENGAGED_MAX];  /*按管脚类型，不按照数量*/
	UINT32 reserve;  /*后续根据需要扩展*/
}T_TDDIO_EXCEPT_CTRL;

typedef struct
{
	T_TDD_BASE_TIMING_GEN_SEL paLnaTimingGen;  /*对应1套tdd里边的第一个COM_tdd_timing 提供给功放低噪放使用*/
	T_TRX_BASE_TIMING_GEN_SEL trxTimingGen;     /*对应1套tdd里边的第二、四个COM_tdd_timing 提供给trans的txen/rxen/orxen使用*/
	T_TDD_BASE_TIMING_GEN_SEL ampTimingGen;     /*对应1套tdd里边的第三个COM_tdd_timing 提供给AMP使用*/
} T_TDD_CONCTRL_BASE_TIMING_GEN;  /*一套TDD的timing_gen_sel，其中trx_acen_timng没有timing_gen_sel,只需要配置para和mux*/

typedef struct
{
	UINT32 tddNum;                                         /*上电初始化几套tdd，0 TDD机型 1 FDD机型 2T+F机型 3 FAD双TDD机型*/
	UINT32 tddTimingGenType[DPDIC_MAX_TIMING_GEN_SEL_TYPE];/*默认都是TDD，以单板下传入参数的参数为准,用于选择timinggen模块的上升沿、下降沿 TDD机型：0 0 0 0 FDD机型：1 1 1 1 T+F 0 1 0 0*/
	UINT32 tddCtrlBaseCfgType[DPDIC_MAX_TDD_NUM];          /*0对应tdd 基础参数和modemap配置流程 1对应fdd接口和流程 后续可以持续增加 单板下传参进行修改*/
	//T_TDDIO_EXCEPT_CTRL tddIoExcept[];
} T_TDDIO_CONCTRL_PARA;

typedef struct
{/*后边有T+F 分别做AC 预留tdd编号*/
    UINT32 acCtrlType;  /*AC管脚号*/
    UINT32 tddNo;
    UINT32 bandNo;
    UINT32 regPara[FDDAC_REG_CFG_NUM];
/*    UINT32 regA;
    UINT32 regB;
    UINT32 regC;
    UINT32 regBc2Sel1;
    UINT32 regD;
    UINT32 regE;
    UINT32 regDe2Sel1;*/
} T_TDDIO_FDDAC_BASE_PARA;



UINT32 BspInitTddSwDelayPara(UINT32 tddSel, UINT32 acType);
UINT32 BspInitFddSwDelayPara(UINT32 tddSel, UINT32 acType);
UINT32 BspTddSwModeSel(UINT32 tddSel,UINT32 modeSel);
UINT32 BspUpdateTddIoVariablePara(UINT32 tddSel, UINT32 acType);
UINT32 BspSetPaLnaCfg(UINT32 type);
UINT32 BspInitRfSwitchCtrlTddModeMapNum(UINT32 TddModeMapNum);
UINT32 BspTddSwDelayParaPrint(UINT32 tddSel, UINT32 acType, UINT32 extPrn);
UINT32 BspTddSwMuxParaPrint(VOID);

UINT32 BspTddIoExceptCtrl(T_TDDIO_EXCEPT_CTRL* tddIoExcept);
UINT32 BspGetIoSwitchStatus(UINT32 muxSel);
UINT32 BspGetIoSwitchStatus_Lna(UINT32 muxSel);
UINT32 BspGetIoSwitchStatus_AcCtrl(UINT32 muxSel);
UINT32 BspGetIoSwitchStatus_Fb(UINT32 muxSel);
UINT32 BspGetAcCtrlSwitchCtrl(UINT32 type);

UINT32 BspSetDtxPaLnaTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxTransTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspInitDTXCfg(VOID);
UINT32 BspSetDtxTxEnTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxRxEnTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxLnaTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxPaTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspSetDtxAmpTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspSetTddIoBoardDiffFlag(UINT32 Flag);
UINT32 BspGetTddIoBoardDiffFlag(VOID);
UINT32 BspUpdateTddIoMuxPara2(VOID);
UINT32 BspSetPaOeEn(UINT32 isEn);
UINT32 BspSetLnaOeEn(UINT32 isEn);
UINT32 BspGetTddIoRecordInfo(VOID);
UINT32 BspSetAvoidHardwareFlag(UINT32 flag);
UINT32 BspSetTddIoDtxEnCfg(UINT32 ioIdx,UINT32 ioType, UINT32 isEn);
UINT32 BspSetPaTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 FromAcTypeToModeMapSel(UINT32 acType);
UINT32 BspSetLnaTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspSetAmpTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspSetFbTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspSetRxTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspSetTxTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspSetTxAcTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspGetTddIoSwitch(UINT32 ioType,UINT32 muxSel);
UINT32 BspSetRxAcTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspSetAcCtrlTddIoCfg(UINT32 type, UINT32 sw);
UINT32 BspInitTddIoConctrlPara(T_TDDIO_CONCTRL_PARA *pPara);
UINT32 BspGetTddIoOutSel(UINT32 ioIdx,UINT32 ioType, UINT32 *uiSel);
UINT32 BspSetTddIoOutSel(UINT32 ioIdx,UINT32 ioType, UINT32 sw);
UINT32 BspGetPaDtxGpSelByWorkAs(UINT32 bspChn, UINT32 *pGpSel);
#if 0
UINT32 BspSetTddRfCtrlAcSyncEn(UINT32 acType,UINT32 mOrS,UINT32 acEn);
UINT32 BspSetTddSwAcDelayParaAc(UINT32 tddSel, T_TddSwDelayPara* para);
UINT32 BspGetTddSwAcDelayParaAc(UINT32 tddSel, T_TddSwDelayPara* para);
UINT32 BspFddDlAcCtrlIoParaSet(UINT32 acType,UINT32 uiCatachAcSeqrfChan,UINT32 uiIcValidFlag);
UINT32 BspFddUlAcCtrlIoParaSet(UINT32 acType,UINT32 uiTranAcSeqrfChan,UINT32 uiIcValidFlag);
UINT32 BspFddNormalAcCtrlIoParaSet(UINT32 acType);
UINT32 BspSetFddAcIoParaSet(UINT32 acType,UINT32 uiCatachAcSeqrfChan,UINT32 uiTranAcSeqrfChan,UINT32 uiIcValidFlag);
UINT32 BspSetAcCatchChan(UINT32 catchCoupleDataChan,UINT32 catchCoupleDataIc,UINT32 bandNo);
UINT32 BspGetTddselByBandNo(UINT32 bandNo, UINT32 acCatchDataChan);
UINT32 BspGetAcCatchChan(UINT32 *puiCatchDataChan, UINT32 *puiAcRpuId, UINT32 *pBandNo);
VOID BspDlyDlDtxOutSelDataSaveAndOff(VOID);
VOID BspDlyDlDtxOutSelRecover(VOID);
#endif
UINT32 BspGetIoSwitchStatus_Lna(UINT32 muxSel);
INT32 BspSetDtxByIoChn(UINT32 chan, UINT32 acType); /*这个接口目前看要去掉，4.0是因为mux_spc功能在切换通道,要对应变化dtx合入*/
UINT32 BspTddIoParaInit(VOID);    //上电初始化调用
UINT32 BspSetExceptPaLnaOeEnable(VOID);
UINT32 BspSetPaLnaOeEnable(VOID);
UINT32 BspSetAcMuxSpcChanMask(UINT32 tddSel, UINT32 acType, UINT32 txChanMask, UINT32 rxChanMask);
UINT32 setAcchInfo(UINT32 type, UINT32 val);
UINT32 BspSetMuxSpcTddIoCfg_FddPa(UINT32 tddsel,UINT32 ioIdx, UINT32 acType);
UINT32 BspSetTddCommonAcMuxSpcChanMask(UINT32 tddSel, UINT32 acType, UINT32 swType, UINT32 chanMask);
UINT32 BspInitDtxCfg(VOID);
UINT32 BspSetIoGpEn(UINT32 tddSel,UINT32 acType);
VOID BspDlyDlDtxOutSelDataSaveAndOff(VOID);
VOID BspDlyDlDtxOutSelRecover(VOID);
UINT32 BspModifyTransOrxRxMuxMap(UINT32 *pTransOrxRxMuxMap);
UINT32 BspInitFddAcCtrlPara(T_TDDIO_FDDAC_BASE_PARA *pFddAcBasePara, UINT32 paraNum);
UINT32 BspGetAcBandNo(VOID);
VOID BspSetAcBandNo(UINT32 bandNo);
UINT32 BspGetInitTddNum(VOID);
UINT32 BspSetPaUeEn(UINT32 chn, UINT32 sw);
UINT32 BspSetLnaUeEn(UINT32 chn, UINT32 sw);
UINT32 BspSetTxenUeEn(UINT32 chn, UINT32 sw);
UINT32 BspSetAmpUeEn(UINT32 chn, UINT32 sw);
UINT32 BspSetRxenUeEn(UINT32 chn, UINT32 sw);
UINT32 BspSetPaBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal);
UINT32 BspSetLnaBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal);
UINT32 BspSetDlDtxPaGpSel(UINT32 chan, UINT32 sel);
UINT32 BspSetDlDtxTxGpSel(UINT32 chan, UINT32 sel);
UINT32 BspSetDlDtxAmpGpSel(UINT32 chan, UINT32 sel);
UINT32 BspSetTxEnBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal);
UINT32 BspSetAmpBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal);
UINT32 BspSetRxEnBitmap(UINT32 chn, UINT32 bitmapLoop, UINT32 bitmapVal);
UINT32 BspSetTestDtxPacCfg(UINT32 chn, UINT32 sw, UINT32 frDly, UINT32 width);
UINT32 BspInitPaLnaPara_Tdd(UINT32 acType,UINT32 baseType, T_PA_LNA_CFG *tPara);
UINT32 BspInitPaLnaPara2_Tdd(UINT32 acType,UINT32 baseType, T_PA_LNA_CFG *tPara);
UINT32 BspInitAmpPara_Tdd(UINT32 acType,UINT32 baseType, T_AMP_CFG *tPara);
UINT32 BspInitAmpPara2_Tdd(UINT32 acType,UINT32 baseType, T_AMP_CFG *tPara);
UINT32 BspInitTransPara_Tdd(UINT32 acType,UINT32 baseType, T_TRANS_CFG *tPara);
UINT32 BspInitTransPara2_Tdd(UINT32 acType,UINT32 baseType, T_TRANS_CFG *tPara);
UINT32 BspSetTddConctolBaseParaAndModeMap(UINT32 acType,UINT32 tddSel);
UINT32 BspInitAcCtrlParaOfTddAcCtrolTiming(UINT32 acType, UINT32 radio,UINT32 acCtrlType,T_AC_CTRL_CFG *tPara);
UINT32 BspGetAcCtrlParaUt(T_AC_CTRL_CFG (*acCtrlparaTmp)[AC_CTRL_TYPE_NUM]);
UINT32 BspGetAcCtrlMux(T_AC_CTRL_SW_OUT_CFG *acCtrlMuxTmp);
UINT32 BspSetDtxChanIoDly(VOID);
UINT32 BspGetTddSwModeSel(UINT32 tddSel);
UINT32 BspInitAcCtrlPara_Tdd(UINT32 acType, UINT32 acCtrlType, T_AC_CTRL_CFG *tPara);
UINT32 BspRecoverTddIoUeOut2Sel1(void);
UINT32 BspUpdateMuxLnaOutSelPara(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw);
UINT32 BspUpdateMuxRxOutSelPara(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 sw);
UINT32 BspSetLnaUeOutTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspUpdateMuxLnaUeOut2Sel1Para(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 sw);
UINT32 BspSetRxUeOutTddIoCfg(UINT32 chan, UINT32 sw);
UINT32 BspUpdateMuxTransRxUeOut2Sel1Para(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 sw);
UINT32 BspUpdateDtxLna(T_TDD_BASE_PALNAAMP_OUT_CFGA *tPara, UINT32 isEn);
UINT32 BspSetDtxRxTddIoCfg(UINT32 chan, UINT32 isEn);
UINT32 BspUpdateDtxRxEn(T_TDD_BASE_SW_OUT_CFG *tPara, UINT32 isEn);
UINT32 BspSetTddIoUeOut2Sel1(UINT32 ioIdx,UINT32 ioType, UINT32 sw);
/* Started by AICoder, pid:fea4ek2307c1bc914fe8082c402007121a733c41 */
typedef UINT32 (*FUNC_GET_CHAN_MASK_BY_TDDID)(UINT32 tddIndex, UINT32 dir);
VOID BspSetFuncGetChanMaskByTddId(FUNC_GET_CHAN_MASK_BY_TDDID pfunc);
UINT32* BspGetAcIdxCorrTddId(VOID);
VOID BspSetUtSupportFlag(UINT32 supportFlag);
UINT32 BspGetRadioByChanMask(UINT32 chanMask);
UINT32 BspQcellSetAcCtrlPara(T_AC_CTRL_CFG *acCtrlPara, UINT32 tddId);
UINT32 BspGetChanMaskByTddId(UINT32 tddIndex, UINT32 dir);
UINT32 BspSetTddAcControlParaAndModeMap(UINT32 acType,UINT32 tddSel);
UINT32 BspQcellSetAcCtrlMuxPara(T_AC_CTRL_SW_OUT_CFG* g_acCtrlMuxPara, UINT32 acCtrlType);
UINT32 BspInitMuxAcCtrlPara(UINT32 acCtrlType, UINT32 tddSel, T_AC_CTRL_SW_OUT_CFG *tPara);
UINT32 BspInitSetAcCtrlMuxPara(UINT32 acCtrlType, UINT32 tddSel);
/* Ended by AICoder, pid:fea4ek2307c1bc914fe8082c402007121a733c41 */
#ifdef __cplusplus
}
#endif

#endif 



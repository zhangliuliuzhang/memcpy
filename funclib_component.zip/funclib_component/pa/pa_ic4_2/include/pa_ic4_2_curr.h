/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pa_c_curr.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功放控制接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#ifndef _FUNCLIB_PA_IC4_2_CURR_H_
#define _FUNCLIB_PA_IC4_2_CURR_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "paapi.h"
#include "rftable_pacurrentcali.h"

typedef UINT32 (*FUNC_GetSlavePaCurrAdVal)(UINT32 portId, UINT32 pwrIndex, UINT32 adcChan, UINT32 *pAdVal);

UINT32 _BspGetPaCurrDate(UINT32 pachan, UINT32 VbiasType, T_PaCurAdRecord *ptReData);
UINT32 _BspGetPaAdVal(UINT32 currNo, UINT32 adcPath, UINT32 *paadval);
UINT32 _BspGetPaCurrValue(UINT32 ulAdValue,UINT32 ulAdValue0, T_PaCurAdRecord *ptReData, float *pcurrval);
UINT32 BspGetPaCurrDate(UINT32 pachan, UINT32 adcChan, UINT32 VbiasType, T_PaCurAdRecord *ptReData);
UINT32 BspSetPaPmosChanCfg(T_PaPmosChanInfo* pPaPara,UINT32 cfgNum);
UINT32 BspPaChanToPmosChan(UINT32 pa, UINT32* pmos);
UINT32 BspGetPaAdcVal(UINT32 paChan,UINT32 *pRegVal);
UINT32 BspGetPaCurr(UINT32 paChan, UINT32 adc, INT32 *pCurr, UINT32 *pRegVal);
UINT32 BspGetPaCurrValFix(UINT32 pachan, UINT32 VbiasType,UINT32 adValCurr0, float *pcurrval);
UINT32 BspGetPaCurrVal(UINT32 pachan, UINT32 adcChan, UINT32 VbiasType, UINT32 adValCurr0, float *pcurrval);
UINT32 BspGetPaAdcValByAdcPath(UINT32 paChan, UINT32 adcChn, UINT32 *pRegVal);
UINT32 BspGetReadPaCurrFlag(VOID);
UINT32 BspSetReadPaCurrFlag(UINT32 flag);
UINT32 BspGetSlavePaCurrAdValCallBack(FUNC_GetSlavePaCurrAdVal pFunc);
#ifdef __cplusplus
}
#endif
#endif 



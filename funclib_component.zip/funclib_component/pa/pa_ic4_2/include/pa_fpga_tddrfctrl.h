/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : pa_ic4_tddrfctrl.h
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 原始作者 : N/A
* 创建日期 : 2020-11-18 21:01:35
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: N/A
* 修改日戳: 2020-11-18 21:01:35
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_PA_FPGA_TDDRFCTRL_H_
#define _FUNCLIB_PA_FPGA_TDDRFCTRL_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "pacommon.h"
#define SLAVE_PORT_EXIST      (1)
#define SLAVE_PORT_NOT_EXIST  (0)

UINT32 BspSetPaSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaPowRxSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspSetLnaSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspGetSlavePortExistSta(UINT32 chn);
UINT32 BspUpdateSlavePortExistSta(UINT32 chn, UINT32 portSta);
UINT32 BspSetCbSwitchByFpga(UINT32 chan, UINT32 mode, UINT32 sw);
UINT32 BspSetLnaPowRxFddSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspSetAllLnaPowRxFddSwitch_Fpga(UINT32 sw);
UINT32 BspSetLnaFddSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspSetPaFddSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspSetPaPowTxFddSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspSetPaPowTxSwitch_Fpga(UINT32 chan, UINT32 sw);
UINT32 BspPaLnaParaPrint(UINT32 tddSel, UINT32 acType);
UINT32 BspSetPaSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw);
UINT32 BspSetLnaSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw);
UINT32 BspSetPaPowTxSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw);
UINT32 BspSetTxSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw);
UINT32 BspSetRxSwitchCtrl_Fpga(UINT32 bspChan, UINT32 sw);
UINT32 BspGetPaSwitch_Fpga(UINT32 chan);
UINT32 BspGetLnaSwitch_Fpga(UINT32 chan);
UINT32 BspGetPaPowTxSwitch_Fpga(UINT32 chan);
UINT32 BspGetTxenSwitch_Fpga(UINT32 chan);
UINT32 BspGetRxenSwitch_Fpga(UINT32 chan);
UINT32 BspGetTxenSwitchCtrl_Fpga(UINT32 bspChan);
UINT32 BspGetRxenSwitchCtrl_Fpga(UINT32 bspChan);

#ifdef __cplusplus
}
#endif

#endif 



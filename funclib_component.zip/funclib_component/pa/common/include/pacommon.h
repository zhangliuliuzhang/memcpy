/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : pacommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功放控制对内接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_PACOMMON_H_
#define _FUNCLIB_PACOMMON_H_


#ifdef __cplusplus
extern "C" {
#endif

#include "paapi.h"
#include "funccommon_log.h"

#define SWITCH_FDD_CTRL_MODE    1   /*FDD 模式*/
#define SWITCH_TDD_CTRL_MODE    0   /*TDD 模式*/

#define    PA_PMOS_CTRL_WITH_FPGA_DEFAULT            0  //A9611E和A9603相区别，采用寄存器不同
#define    PA_PMOS_CTRL_WITH_FPGA_REPLACE_GPIO       1  //A9611E和A9611的PMOS控制采用不同方式，A9611E通过FPGA去控制
#define    PA_PMOS_CTRL_WITH_FPGA_WIDTH_8            8  //采用寄存器控制时，每bit控制的通道数

#define    PA_PMOS_CTRL_WITH_GPIO_DEFAULT            0  //功放开关控制通过gpio控制
#define    PA_PMOS_CTRL_WITH_GRID_VOLT               1  //功放开关控制通过栅压控制

#define    LNA_CTRL_WITH_DEFAULT                     0  //默认只控制lna_pwr
#define    LNA_CTRL_WITH_PWR_SW_BYPASS               1  //控制lna_pwr、lna_sw、lna_bypass

#define AC_CTRL_TYPE_NUM ((UINT32)9)                //9种ACtype s0-2 tx rx cal
#define BSP_TEST_MODE           2

/*根据bsp通道和开关类型获取对应的寄存器的bit*/
typedef UINT32 (*pGetRfSwitchCtrlBit)(UINT32 bspChan, UINT32 dir, UINT32 ioSwType, UINT32 *pCtrlBit);
typedef UINT32 (*pAcDlModeSw)(UINT32 sw);

UINT32 BspGetTddIoInitFlag(VOID);
UINT32 BspSetFbSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetFbModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetRxSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetRxModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetTxSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetTxModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetAmpSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetAmpModeCtrl(UINT32 chan, UINT32 mode);

UINT32 BspSetTxAcModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetTxAcSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetRxAcModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetRxAcSwitchCtrl(UINT32 chan, UINT32 sw);
UINT32 BspSetAcCtrlModeCtrl(UINT32 chan, UINT32 mode);
UINT32 BspSetAcCtrlSwitchCtrl(UINT32 chan, UINT32 sw);
T_Pa_AdaSocInfo *BspGetPaAdaCfg(VOID);
pGetRfSwitchCtrlBit BspGetRfSwitchCtrlBitCallBack(VOID);
UINT32 BspInitRfSwitchCtrlBitCallBack(pGetRfSwitchCtrlBit pCallBackFunc);
UINT32 pasta();
VOID BspSetDtpMtsFreq(UINT32 freqKhz);
UINT32 BspGetDtpMtsFreq(VOID);
VOID BspRegisterAcDlModeSwFunc(pAcDlModeSw func);
UINT32 BspGetD1SymTime(UINT32 radio, DOUBLE* SymTime);
#ifdef __cplusplus
}
#endif
#endif 



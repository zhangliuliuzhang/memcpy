#include "bsppub.h"
#include "bspcomm.h"
#include "pacommon.h"
#include "pa_ic4_2_ctrl.h"
#include "lo_common.h"
#include "devdrv_lo.h"
#include "exprn.h"

T_Pa_AdaSocInfo * s_paAdaSocCfg = NULL;
UINT32 g_tddIoInitFlag = 1;
static pGetRfSwitchCtrlBit pGetRfSwCtrlBit = NULL;
static UINT32 s_dtpMtsFreq = 0;
static pAcDlModeSw s_pAcDlModeSw = NULL;

UINT32 BspGetTddIoInitFlag(VOID)
{
    return g_tddIoInitFlag;
}

UINT32 BspSetTddIoInitFlag(UINT32 flag)
{
    g_tddIoInitFlag = flag;
    return BSP_OK;
}

UINT32 BspSetPaAdaCfg(T_Pa_AdaSocInfo *paAdaSocCfg)
{
    INPUT_POINTER_CHECK(paAdaSocCfg);
    s_paAdaSocCfg = paAdaSocCfg;
    return BSP_OK;
}
T_Pa_AdaSocInfo *BspGetPaAdaCfg(VOID)
{
    return s_paAdaSocCfg;
}

UINT32 BspInitRfSwitchCtrlBitCallBack(pGetRfSwitchCtrlBit pCallBackFunc)
{
    pGetRfSwCtrlBit = pCallBackFunc;
    return BSP_OK;
}
pGetRfSwitchCtrlBit BspGetRfSwitchCtrlBitCallBack(VOID)
{
   return pGetRfSwCtrlBit;
}


/*===================测试接口====================*/
/*pa 关闭*/
UINT32 paoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetPaSwitch(chn, SWITCH_OFF);   //off时是TDD模式

    } while (++chn < chnNum);
    return retVal;
}

#ifdef BUILD_WITH_OM_FUNC
/*pa tdd*/
UINT32 paon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetPaSwitch(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*pa tdd_fdd*/
UINT32 paonfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetPaFddSwitch(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}
#endif

/*lna off*/
UINT32 lnaoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetLnaSwitch(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}

#ifdef BUILD_WITH_OM_FUNC
/*lna tdd*/
UINT32 lnaon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetLnaSwitch(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*lna 长收*/
UINT32 lnaonfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetLnaFddSwitch(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}
#endif

UINT32 pastatus()
{
    UINT32 paChnNum = BspGetTxChannel();
    UINT32 lnaChnNum= BspGetRxChannel();
    UINT32 *paSta, *lnaSta;
    UINT32 loop;

    if(BspGetTddIoInitFlag()==0)
    {
        RedirPrintf("[%s] Err: Please wait for TDDIOINIT!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    paSta = malloc(paChnNum*sizeof(UINT32));
    if (paSta == NULL)
    {
        return BSP_ERROR;
    }
    lnaSta= malloc(lnaChnNum*sizeof(UINT32));
    if (lnaSta == NULL)
    {
        free(paSta);
        return BSP_ERROR;
    }

    for (loop = 0; loop < paChnNum; loop++)
    {
        paSta[loop] = BspGetPaSwitch(loop);
    }

    for (loop = 0; loop < lnaChnNum; loop++)
    {
        lnaSta[loop] = BspGetLnaSwitch(loop);
    }

    RedirPrintf("pa switch status(0:OFF,1:ON 2:FDDON):\n");
    for (loop = 0; loop < paChnNum; loop++)
    {
        RedirPrintf("[%d]%d%s",loop,paSta[loop],((loop+1)%8)?" ":"\n");
    }
    RedirPrintf("\n");

    RedirPrintf("lna switch status(0:OFF,1:ON 2:FDDON):\n");
    for (loop = 0; loop < lnaChnNum; loop++)
    {
        RedirPrintf("[%d]%d%s",loop,lnaSta[loop],((loop+1)%8)?" ":"\n");
    }
    RedirPrintf("\n");

    free(paSta);
    free(lnaSta);
    return BSP_OK;
}
UINT32 pasta()
{
    return pastatus();
}
/*amp off*/
UINT32 ampoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetAmpModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetAmpSwitchCtrl(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}

/*amp tdd*/
UINT32 ampon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetAmpModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetAmpSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*Amp fdd*/
UINT32 amponfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetAmpModeCtrl(chn, SWITCH_FDD_CTRL_MODE);
        retVal |= BspSetAmpSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*tx tdd*/
UINT32 txenoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetTxSwitchCtrl(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}

/*tx tdd*/
UINT32 txenon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetTxSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*tx fdd*/
UINT32 txenonfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxModeCtrl(chn, SWITCH_FDD_CTRL_MODE);
        retVal |= BspSetTxSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*rx off*/
UINT32 rxenoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetRxSwitchCtrl(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}


/*rx tdd*/
UINT32 rxenon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetRxSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*rx fdd*/
UINT32 rxenonfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxModeCtrl(chn, SWITCH_FDD_CTRL_MODE);
        retVal |= BspSetRxSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*fb off*/
UINT32 fboff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetFbModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetFbSwitchCtrl(chn, SWITCH_OFF);
    } while (++chn < chnNum);
    return retVal;
}

/*fb tdd*/
UINT32 fbon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetFbModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetFbSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*fb fdd*/
UINT32 fbonfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetFbModeCtrl(chn, SWITCH_FDD_CTRL_MODE);
        retVal |= BspSetFbSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}


/*txac off*/
UINT32 txacoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxAcModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetTxAcSwitchCtrl(chn, SWITCH_OFF);

    } while (++chn < chnNum);
    return retVal;
}

/*txac tdd*/
UINT32 txacon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxAcModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetTxAcSwitchCtrl(chn, SWITCH_ON);
    } while (++chn < chnNum);
    return retVal;
}

/*txac fdd*/
UINT32 txaconfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspSetTxAcModeCtrl(chn, SWITCH_FDD_CTRL_MODE);
        retVal |= BspSetTxAcSwitchCtrl(chn, SWITCH_ON);

    } while (++chn < chnNum);
    return retVal;
}

/*rxac off*/
UINT32 rxacoff(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxAcModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetRxAcSwitchCtrl(chn, SWITCH_OFF);

    } while (++chn < chnNum);
    return retVal;
}

/*rxac tdd*/
UINT32 rxacon(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxAcModeCtrl(chn, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetRxAcSwitchCtrl(chn, SWITCH_ON);

    } while (++chn < chnNum);
    return retVal;
}

/*rxac fdd*/
UINT32 rxaconfdd(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspSetRxAcModeCtrl(chn, SWITCH_FDD_CTRL_MODE);
        retVal |= BspSetRxAcSwitchCtrl(chn, SWITCH_ON);

    } while (++chn < chnNum);
    return retVal;
}

/*acctrl off*/
UINT32 acctrloff(UINT32 startType,UINT32 endType)
{
    UINT32 retVal = BSP_OK;
    UINT32 acCtrlType = startType;
    UINT32 acCtrlNum = min(AC_CTRL_TYPE_NUM, endType+1);

    do
    {
        //retVal |= BspSetAcCtrlSwitch(acCtrlType, SWITCH_OFF);

        retVal |= BspSetAcCtrlModeCtrl(acCtrlType, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetAcCtrlSwitchCtrl(acCtrlType, SWITCH_OFF);

    } while (++acCtrlType < acCtrlNum);
    return retVal;
}


/*acctrl tdd*/
UINT32 acctrlon(UINT32 startType,UINT32 endType)
{
    UINT32 retVal = BSP_OK;
    UINT32 acCtrlType = startType;
    UINT32 acCtrlNum = min(AC_CTRL_TYPE_NUM, endType+1);

    do
    {
        //retVal |= BspSetAcCtrlSwitch(acCtrlType, SWITCH_ON);

        retVal |= BspSetAcCtrlModeCtrl(acCtrlType, SWITCH_TDD_CTRL_MODE);
        retVal |= BspSetAcCtrlSwitchCtrl(acCtrlType, SWITCH_ON);

    } while (++acCtrlType < acCtrlNum);
    return retVal;
}


/*acctrl fdd*/
UINT32 acctrlonfdd(UINT32 startType,UINT32 endType)
{
    UINT32 retVal = BSP_OK;
    UINT32 acCtrlType = startType;
    UINT32 acCtrlNum = min(AC_CTRL_TYPE_NUM, endType+1);

    do
    {
        //retVal |= BspSetAcCtrlSwitch(acCtrlType, SWITCH_ON_FDD);

        retVal |= BspSetAcCtrlModeCtrl(acCtrlType, SWITCH_FDD_CTRL_MODE);
        retVal |= BspSetAcCtrlSwitchCtrl(acCtrlType, SWITCH_ON);

    } while (++acCtrlType < acCtrlNum);
    return retVal;
}

UINT32 iosta(VOID)
{
    UINT32 txChnNum = BspGetTxChannel();
    UINT32 rxChnNum= BspGetRxChannel();
    UINT32 *paSta, *lnaSta,  *txSta, *rxSta, *fbSta, *txAcSta, *rxAcSta, *acCtrlSta, *ampSta;
    UINT32 loop;

    if(BspGetTddIoInitFlag()==0)
    {
        dbgInfo("[%s] Err: Please wait for TDDIOINIT!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    paSta = malloc(txChnNum*sizeof(UINT32));
    if (paSta == NULL)
    {
        return BSP_ERROR;
    }
    lnaSta= malloc(rxChnNum*sizeof(UINT32));
    if (lnaSta == NULL)
    {

        free(paSta);
        return BSP_ERROR;
    }

    txSta = malloc(txChnNum*sizeof(UINT32));
    if (txSta  == NULL)
    {
        free(paSta);
        free(lnaSta);
        return BSP_ERROR;
    }
    rxSta= malloc(rxChnNum*sizeof(UINT32));
    if (rxSta == NULL)
    {
        free(paSta);
        free(lnaSta);
        free(txSta);
        return BSP_ERROR;
    }
    fbSta= malloc(rxChnNum*sizeof(UINT32));
    if (fbSta == NULL)
    {
        free(paSta);
        free(lnaSta);
        free(txSta);
        free(rxSta);
        return BSP_ERROR;
    }
    txAcSta= malloc(1*sizeof(UINT32));
    if (txAcSta == NULL)
    {
        free(paSta);
        free(lnaSta);
        free(txSta);
        free(rxSta);
        free(fbSta);
        return BSP_ERROR;
    }
    rxAcSta= malloc(1*sizeof(UINT32));
    if (rxAcSta == NULL)
    {
        free(paSta);
        free(lnaSta);
        free(txSta);
        free(rxSta);
        free(fbSta);
        free(txAcSta);
        return BSP_ERROR;
    }
    acCtrlSta= malloc(9*sizeof(UINT32));
    if (acCtrlSta == NULL)
    {
        free(paSta);
        free(lnaSta);
        free(txSta);
        free(rxSta);
        free(fbSta);
        free(txAcSta);
        free(rxAcSta);
        return BSP_ERROR;
    }

    ampSta = malloc(txChnNum*sizeof(UINT32));
    if (ampSta == NULL)
    {
        free(paSta);
        free(lnaSta);
        free(txSta);
        free(rxSta);
        free(fbSta);
        free(txAcSta);
        free(rxAcSta);
        free(acCtrlSta);
        return BSP_ERROR;
    }

    for (loop = 0; loop < txChnNum; loop++)
    {
        paSta[loop] = BspGetPaSwitch(loop);
        txSta[loop] = BspGetTxSwitchCtrl(loop);
        ampSta[loop] = BspGetAmpSwitch(loop);
    }

    for (loop = 0; loop < rxChnNum; loop++)
    {
        lnaSta[loop] = BspGetLnaSwitch(loop);
        rxSta[loop] = BspGetRxSwitchCtrl(loop);
        fbSta[loop] = BspGetFbSwitchCtrl(loop);
    }

    txAcSta[0] = BspGetTxAcSwitchCtrl(0);   //ac为0
    rxAcSta[0] = BspGetRxAcSwitchCtrl(0);

    for (loop = 0; loop < AC_CTRL_TYPE_NUM; loop++)     //AC_CTRL_TYPE_NUM
    {
        acCtrlSta[loop] = BspGetAcCtrlSwitchCtrl(loop);
    }

    dbgInfo("pa switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,paSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("lna switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < rxChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,lnaSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("tx switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,txSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("rx switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < rxChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,rxSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("fb switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < rxChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,fbSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("txac att status(0:OFF,1:ON, 2:FDD ON, 3:ON_REV):\n");
    for (loop = 0; loop < 1; loop++)
    {
        dbgInfo("[%d]%d%s",loop,txAcSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("rxac att status(0:OFF,1:ON, 2:FDD ON, 3:ON_REV):\n");
    for (loop = 0; loop < 1; loop++)
    {
        dbgInfo("[%d]%d%s",loop,rxAcSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("acctrl switch status(0:OFF,1:ON 2:FDD ON):\n");
    for (loop = 0; loop < 9; loop++)
    {
        dbgInfo("[%d]%d%s",loop,acCtrlSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    dbgInfo("amp switch status(0:OFF,1:ON 2:FDD ON *<<T+F: TDD:AMP = TXEN ; FDD: AMP = DVGA>>*):\n");
    for (loop = 0; loop < txChnNum; loop++)
    {
        dbgInfo("[%d]%d%s",loop,ampSta[loop],((loop+1)%8)?" ":"\n");
    }
    dbgInfo("\n");

    free(paSta);
    free(lnaSta);
    free(txSta);
    free(rxSta);
    free(fbSta);
    free(txAcSta);
    free(rxAcSta);
    free(acCtrlSta);
    free(ampSta);

    return BSP_OK;
}

UINT32 BspSetAcCtrlTddMode(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = acctrloff(0, 2);
    retVal |= acctrloff(5, 5);

    return retVal;
}

UINT32 BspSetAcCtrlRxMode(UINT32 actype) //0:FDD(无时序模式)；1：TDD（有时序模式）
{
    UINT32 retVal = BSP_OK;

    switch (actype)
    {
        case BSP_FDD_MODE:
            retVal = acctrlonfdd(0, 0);
            retVal |= acctrloff(1, 1);
            retVal |= acctrlonfdd(2, 2);
            retVal |= acctrlonfdd(5, 5);
            break;

        case BSP_TDD_MODE:
            retVal = acctrlon(0, 0);
            retVal |= acctrloff(1, 1);
            retVal |= acctrlon(2, 2);
            retVal |= acctrlon(5, 5);
            break;

        case BSP_TEST_MODE: //测试：开关全部打开，测试是否按照TDD时序
            retVal = acctrlon(0, 2);
            retVal |= acctrlon(5, 5);
            break;

        default:
            dbgInfo("actype is [%d], out of range [0,2]!\n", actype);
    }

    return retVal;
}

UINT32 BspSetAcCtrlTxMode(UINT32 actype) //0:FDD(无时序模式)；1：TDD（有时序模式）
{
    UINT32 retVal = BSP_OK;

    switch (actype)
    {
        case BSP_FDD_MODE:
            retVal = acctrloff(0, 0);
            retVal |= acctrlonfdd(1, 2);
            retVal |= acctrlonfdd(5, 5);
            break;

        case BSP_TDD_MODE:
            retVal = acctrloff(0, 0);
            retVal |= acctrlon(1, 2);
            retVal |= acctrlon(5, 5);
            break;

        case BSP_TEST_MODE: //测试：开关全部打开，测试是否按照TDD时序
            retVal = acctrlon(0, 2);
            retVal |= acctrlon(5, 5);
            break;

        default:
            dbgInfo("actype is [%d], out of range [0,2]!\n", actype);
    }

    return retVal;
}

UINT32 BspGetByPaRecordInfo(T_ByPaLogInfo **logInfo, UINT32 *logCnt)
{
    return BSP_ERROR;
}

/* R9214E 逻辑机型数模差异重配PA DAC 打桩 */
UINT32 BspGetPaDacGroupInfo(T_PaDacGroupInfo *ptPaDacGroupInfo)
{
    INPUT_POINTER_CHECK(ptPaDacGroupInfo);
    return BSP_OK;
}

UINT32 BspPaDacReCfg(UINT32 groupIdx)
{
    return BSP_OK;
}

UINT32 BspGetDtpMtsFreq(VOID)
{
    return s_dtpMtsFreq;
}

VOID BspSetDtpMtsFreq(UINT32 freqKhz)
{
    s_dtpMtsFreq = freqKhz;
}

VOID BspRegisterAcDlModeSwFunc(pAcDlModeSw func)
{
    s_pAcDlModeSw = func;
}

/* Started by AICoder, pid:odceaz9e68aca4e14e4209db30f0616aac8771e8 */
UINT32 BspDtpAcDlModeSwitch(UINT32 sw)
{
    UINT32 retVal = BSP_OK;
    UINT32 devNo = 0;
    T_RfPllCfgPriv *pPllPrivCfg = NULL;
    TRruDeviceDescription dev = {0};
    static UINT32 freqKhz = 0;

    dbgInfoEx("%s>>>sw'%d, freqKhz'%d\n", __FUNCTION__, sw, freqKhz);

    memset_s((void *)&dev, sizeof(dev), 0, sizeof(dev));
    retVal = BspChipInfoGetByRfPathDef(0, RX, DEVICE_TYPE_RFPLL, &dev);
    if(retVal != BSP_OK)
    {
        dbgErr("%s>>>BspChipInfoGetByRfPathDef Error\n", __FUNCTION__);
        return BSP_ERROR;
    }
    devNo = BspLoPllDevIdToDevNo(dev.ulDeviceId);
    pPllPrivCfg = BspGetRfPllCfgPriv(devNo);

    if(pPllPrivCfg == NULL)
    {
        dbgErr("%s>>>pPllPrivCfg is null\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(sw == SWITCH_ON)
    {
        if((pPllPrivCfg->pGetFreq != NULL) && (pPllPrivCfg->pSetFreq != NULL) && (freqKhz == 0))
        {
            retVal |= pPllPrivCfg->pGetFreq(dev.ulDeviceIndex, &freqKhz);
            retVal |= pPllPrivCfg->pSetFreq(dev.ulDeviceIndex, BspGetDtpMtsFreq());
        }
    }
    else if(sw == SWITCH_OFF)
    {
        if((pPllPrivCfg->pSetFreq != NULL) && (freqKhz != 0))
        {
            retVal |= pPllPrivCfg->pSetFreq(dev.ulDeviceIndex, freqKhz);
            freqKhz = 0;
        }
    }

    if(s_pAcDlModeSw != NULL)
    {
        retVal |= s_pAcDlModeSw(sw);
    }

    return retVal;
}
/* Ended by AICoder, pid:odceaz9e68aca4e14e4209db30f0616aac8771e8 */

UINT32 BspGetPaSelfExcitationLevel(UINT32 bspChan)
{
    return 0;
}

UINT32 BspSetPaSelfExcitationLevel(UINT32 bspChan, UINT32 level)
{
    return BSP_OK;
}
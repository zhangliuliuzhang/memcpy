/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dbootctrl.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 用户态双boot初始化
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-01-23 19:53
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:
 *----------------------------------------------------------------------------
 */
#ifndef _DBOOTCTRL_NEW_H_
#define _DBOOTCTRL_NEW_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MSBOOT_INIT_FLAG                      0xabcdabcd

typedef struct tagTDbootPara
{
    UINT32  ulBootBase[5][2];                 /* BOOT在flash中的起始地址 */
    UINT32  ulBootSize[5];                    /* BOOT大小 */
    UINT32  ulBootZoneNum;    
    UINT32  (*pGetMsBoot)(VOID);   
    UINT32  (*pSetMsBoot)(UINT32 ulBootFlag);
    UINT32  (*pGetCpuType)(UINT8 *pucCpuType);  /* CPU类型 */
}TDbootPara;

typedef UINT32 (*FUNC_SET_BOOT_FLAG)(UINT32 writeval);
typedef UINT32 (*FUNC_GET_BOOT_FLAG)(VOID);

UINT32 BspDbootParaInit(TDbootPara *ptPara);
UINT32 GetMsBoot(VOID);

UINT32 BspSetBootFlagCallback(FUNC_SET_BOOT_FLAG pFunc);
UINT32 BspGetBootFlagCallback(FUNC_GET_BOOT_FLAG pFunc);
UINT8  DbootGetMsBootFlag(VOID);
// UINT32 GetBootArea(UINT32 bootFlag, UINT32 bootCtrlWord);
// UINT8  SetBootValid(UINT16 val);
// UINT32 BootflagGet(VOID);
// UINT32 BootflagSet(UINT32 writeval);

#ifdef __cplusplus
}
#endif

#endif

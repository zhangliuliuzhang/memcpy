/*****************************************************************************
 * 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : dbootctrl.c
 * 文件标识 : 用户态双boot初始化
 * 注意事项 : 无
 * 作    者 : 10090699
 * 创建日期 : 2017-1-23 15:21:10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:
 *----------------------------------------------------------------------------
 */
#include <fcntl.h>
#include <sys/mman.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "regdrv.h"
#include "dualbootapi.h"
#include "dbootctrl_new.h"

UINT32 s_ulBootInitFlag = MSBOOT_INIT_FLAG;

FUNC_SET_BOOT_FLAG pSetBootFlagFunc = NULL;
FUNC_GET_BOOT_FLAG pGetBootFlagFunc = NULL;

/* 主从BOOT标志设置函数指针注册 */
UINT32 BspSetBootFlagCallback(FUNC_SET_BOOT_FLAG pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pSetBootFlagFunc = pFunc;
    return BSP_OK;
}
/* 主从BOOT标志查询函数指针注册 */
UINT32 BspGetBootFlagCallback(FUNC_GET_BOOT_FLAG pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pGetBootFlagFunc = pFunc;
    return BSP_OK;
}

VOID SetMsbootFlag(UINT32 ulFlag)
{
    /* 默认值: MSBOOT_INIT_FLAG= 0xabcdabcd */
    s_ulBootInitFlag = ulFlag;
}
#if 0
/*****************************************************************************
 *  函数名称   : BootflagSet()
 *  功能描述   : 设置boot启动标志
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   :
 *  输出参数   : 无
 *  返 回 值   : 错误码
 *  其它说明   :
    #define  MASTER_BOOT_OK       0x11
    #define  MASTER_KUBOOT_OK     0x22
    #define  SLAVE_BOOT_OK        0x33
    #define  SLAVE_KUBOOT_OK      0x44
    yam inform:
    These four  flags above, are used to discriminate different conditions of low boot area destroyed
    and high boot area destroyed. Inorder to let RRU start from another boot area when one boot area
    is destroyed. Significantly enough, these four flags above are not used to distinguish current boot
    area any more!!! What's more, the key flag which used to show and prove current boot area is
    offset addr 0x480000 length 0x4 KB in spi flash of dpdic. 0x7f7f7f7f means start from low boot
    area, 0x00000000 means start from high boot area.
 *--------------------------------------------------------- */
UINT32 BootflagSet(UINT32 writeval)
{
    return BspRegWr(0,REG_BOOTFLAG_SET,0,writeval);
}

/*****************************************************************************
 *  函数名称   : BootflagGet()
 *  功能描述   : 获取boot启动标志
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值: 
                #define  MASTER_BOOT_OK       0x11
                #define  MASTER_KUBOOT_OK     0x22
                #define  SLAVE_BOOT_OK        0x33
                #define  SLAVE_KUBOOT_OK      0x44
 *  其它说明   :
 *--------------------------------------------------------- */
UINT32 BootflagGet(VOID)
{
    UINT32 data = 0xfe;
    BspRegRd(0,REG_BOOTFLAG_SET,0,&data);
    return data&0xff;
}

UINT8 SetBootValid(UINT16 val)
{
    if (val == 1)
    {
        return BootflagSet(SLAVE_BOOT_OK);
    }
    else
    {
        return BootflagSet(MASTER_BOOT_OK);
    }
}

UINT32 GetBootArea(UINT32 bootFlag, UINT32 bootCtrlWord)
{
    UINT32 bootArea = BSP_ERROR;

    if (bootFlag == MASTER_KUBOOT_OK || bootFlag == SLAVE_BOOT_OK)
    {
        bootArea = (bootCtrlWord == 0) ? HIGH_ADDR_BOOT : LOW_ADDR_BOOT;
    }
    else if (bootFlag == MASTER_BOOT_OK || bootFlag == SLAVE_KUBOOT_OK)
    {
        bootArea = (bootCtrlWord == 0) ? LOW_ADDR_BOOT : HIGH_ADDR_BOOT;
    }

    return bootArea;
}
#endif
/*****************************************************************************
*  函数名称   : GetMsBoot(*)
*  功能描述   : 获取当前是主或从BOOT启动
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 1 - 高端BOOT启动，0 - 低端启动
*  其它说明   : 根据EPLD中Boot指示及翻转标志寄存器判断
*               0 - 低端BOOT启动
*               1 - 高端BOOT启动
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), yam@2016-2-16 16:02 根据新架构的DBoot 模块修改
*----------------------------------------------------------------------------
*/
UINT32 GetMsBoot(VOID)
{
    /*UINT32 val = 0;
    UINT8  buf[8] = {0};
    UINT32 bootCtrlWord = 0; */

    if (s_ulBootInitFlag != MSBOOT_INIT_FLAG)
    {
        return s_ulBootInitFlag;
    }
#if 0
    if (BSP_OK != BspGetBootCtrl(buf, sizeof(buf)))
    {
        dbgErr("%s>>BootCtrlWord In Flash Get Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    bootCtrlWord = *(UINT32 *)buf;

    /* *if the boot control word in flash is set to low/high address boot,
       *and the value in RTC register denotes master/slave boot running,so
       *the running boot is low/high address boot version. */
    val = BootflagGet();
    s_ulBootInitFlag = GetBootArea(val, bootCtrlWord);
    if (s_ulBootInitFlag == BSP_ERROR)
    {
        dbgErr("%s>>BootFlag'0x%02X CtrlWord'0x%02X Get Error!\n",
               __FUNCTION__, val, bootCtrlWord);
    }
#endif
    if(pGetBootFlagFunc != NULL)
    {
        s_ulBootInitFlag = pGetBootFlagFunc();
    }
    return s_ulBootInitFlag;
}

UINT8 DbootGetMsBootFlag(VOID)
{
    UINT8 ucBootFlag = 0;

    ucBootFlag = (UINT8)GetMsBoot();

    return ucBootFlag;
}

/*****************************************************************************
*  函数名称   : BspDbootParaInit(*)
*  功能描述   : 双boot控制参数初始化
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : 成功 - BSP_OK
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), yam@2016-2-23
*----------------------------------------------------------------------------
*/
UINT32 BspDbootParaInit(TDbootPara *ptPara)
{
    UINT32 ulCnt = 0;
    T_BOOTROM_DEVICE_PARA bootRomPara;

    memset((CHAR *)&bootRomPara, 0, sizeof(T_BOOTROM_DEVICE_PARA));
    if ((TDbootPara *)NULL == ptPara)
    {
        dbgErr("%s>>Para Error! pPara NULL;\n", __FUNCTION__);
        return BSP_ERROR;
    }
    if (NULL == ptPara->pGetCpuType)
    {
        dbgErr("%s>>Para Error! pGetCpuType NULL;\n", __FUNCTION__);
        return BSP_ERROR;
    }

    for (ulCnt = 0; ulCnt < 5; ulCnt++)
    {
        bootRomPara.ulBootBaseAddr[ulCnt][0] = ptPara->ulBootBase[ulCnt][0];
        bootRomPara.ulBootBaseAddr[ulCnt][1] = ptPara->ulBootBase[ulCnt][1];
        bootRomPara.ulSize[ulCnt]            = ptPara->ulBootSize[ulCnt];
    }

    bootRomPara.ulBootZoneNum = ptPara->ulBootZoneNum;
    bootRomPara.pGetCpuType   = ptPara->pGetCpuType; // BspGetCpuType
    /* 结构和函数返回应该定义为UINT32类型??? */
    bootRomPara.pGetMsBoot    = ptPara->pGetMsBoot; // DbootGetMsBootFlag;
    bootRomPara.pSetMsBoot    = ptPara->pSetMsBoot;

    return BootLoadInit(&bootRomPara);
}


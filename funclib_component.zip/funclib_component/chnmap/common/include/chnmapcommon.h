#ifndef _FUNCLIB_CHNMAPCOMMON_H_
#define _FUNCLIB_CHNMAPCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "chnmapapi.h"

#define MCS_ID_MAP_NUM_MAX           32

enum 
{
    E_FPGA_TYPE_OPT = 0,
    E_FPGA_TYPE_RF,
    E_FPGA_TYPE_NUM
};

enum
{
    E_FPGA_TYPE_CLK_368P64 = 0,
    E_FPGA_TYPE_CLK_184P32,
    E_FPGA_TYPE_CLK_NUM
};

enum
{
    /* °´bit¶¨Òå */
    E_OPT_MAP_PRO_INV   = 0, 
    E_OPT_MAP_PRO_CPRI  = 1,
    E_OPT_MAP_PRO_ECPRI = 2
};

typedef enum eTYPE_OPT_MAP
{
    E_OPT_MAP_LGC_OPT = 0,
    E_OPT_MAP_PHY_OPT,
    E_OPT_MAP_SFP_TYPE,
    E_OPT_MAP_SFP_INDEX,
    E_OPT_MAP_SFP_CHAN,
    E_OPT_MAP_FPGA_IDX,
    E_OPT_MAP_FPGA_CHAN,
    E_OPT_MAP_FPGA_TYPE,
    E_OPT_MAP_FPGA_CLK_TYPE,
    E_OPT_MAP_RADIO_MODE,
    E_OPT_MAP_OPT_PRO,
    E_OPT_MAP_NUM
}eTYPE_OPT_MAP;

typedef struct tagT_OptMapMng
{
    UINT32 opt[E_OPT_MAP_NUM];
}T_OptMapMng;

typedef struct tagT_CarrMapMng
{
    UINT32 dir;
    UINT32 bspCarrNo;
    UINT32 logicCarrNo;
    UINT32 difCarrNo;
    UINT32 radioMode;
}T_CarrMapMng;

typedef UINT32 (*pGetBspChnlByAntFreq)(UINT32 ulTrxDir, UINT32 ulAntNo, UINT32 ulFreqKHz, UINT32 *pulBspChnl);
typedef UINT32 (*pUpdateLogicCarrMap)(UINT32 trx, T_RfCfgPara *pRfCfg, T_CarrMapMng *map, UINT32 num);
typedef UINT32 (*FUNC_SET_MCSID_MAP)(VOID);

UINT32 BspGetTxBspChanNum(VOID);
UINT32 BspGetRxBspChanNum(VOID);
UINT32 BspGetBspCarrNum(VOID);

UINT32 BspOptMapMngInit(T_OptMapMng *pOptMap, UINT32 optMapNum);
UINT32 BspGetSfpMapInfoByPhyOpt(UINT32 phyOpt,UINT32 *sfpType,UINT32 *sfpIndex,UINT32 *sfpChan);
UINT32 BspGetSfpTypeBySfpId(UINT32 sfpIndex);
UINT32 BspSetSfpTypeBySfpId(UINT32 ulSfpIndex, UINT32 ulSfpType);
UINT32 BspGetLogicOptStartBySfpId(UINT32 sfpIndex);
UINT32 BspGetFpgaIdxByPhyOpt(UINT32 phyOpt,UINT32 *fpgaIndex,UINT32 *fpgaChan,UINT32 uFpgaType);
UINT32 BspGetSfpChanByPhyOpt(UINT32 phyOpt,UINT32 * sfpChan);
UINT32 BspGetSfpTypeByLgcId(UINT32 sfpIndex);
UINT32 BspGetSfpIdxBySfpId(UINT32 optLgcId);
UINT32 BspGetOptRaidoByPhyOpt(UINT32 phyOpt,UINT32 *radioMode,UINT32 *optPro);
UINT32 BspOptMapNumGet(VOID);

UINT32 BspCarrMapMngInit(T_CarrMapMng *pMap, UINT32 num);
UINT32 BspGetBspCarrMap(UINT32 dir,UINT32 logicCarr,UINT32 radioMode,UINT32 *bspCarr,UINT32 *difCarr);
UINT32 BspGetBspCarrRadioMode(UINT32 dir,UINT32 bspCarr);
UINT32 BspGetLogicCarrRadioMode(UINT32 dir,UINT32 logicCarr);
UINT32 BspUpdateLogicCarrMap(UINT32 dir,T_RfCfgPara *pRfCfg);
UINT32 BspGetCarrMapInfo(T_CarrMapMng *pMap, UINT32 mapNum, UINT32 *retNum);

UINT32 BspCarrIdMapInit(T_McsCarrIdMap *pMap, UINT32 num);
UINT32 BspGetLocalCarrIdMap(T_McsCarrIdMap *pMap,UINT32 *num);
UINT32 BspCarrIdMapGetLocalCarrId(UINT32 logicCarrNo,UINT32 *localCarrId,UINT32 *radioMode);
UINT32 BspLocalCarrIdMapGetCarrId(UINT32 localCarrId);
UINT32 BspReMapCarrMap(VOID);

UINT32 BspUpdateLogicCarrMapCallInit(pUpdateLogicCarrMap pCallBackFunc);
UINT32 BspSetMcsIdMapCallbackInit(FUNC_SET_MCSID_MAP pFunc);
UINT32 BspGetBspChnlByAntFreqCallInit(pGetBspChnlByAntFreq pCallBackFunc);
UINT32 BspGetSfpMapInfoByLogicOpt(UINT32 logicOpt,UINT32 *sfpType,UINT32 *sfpIndex,UINT32 *sfpChan);
UINT32 BspGetFpgaIdxByLogicOpt(UINT32 logicOpt,UINT32 *fpgaIndex,UINT32 *fpgaChan);
UINT32 BspCarrIdMapGetLocalCarrId(UINT32 logicCarrNo,UINT32 *localCarrId,UINT32 *radioMode);
#ifdef __cplusplus
}
#endif
#endif 



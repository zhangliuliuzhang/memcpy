
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmapcommon.h"
#include "funccommon.h"
#include "exprn.h"

#define CARR_MAP_MNG_INIT_FLAT       0xa5a55a5a

#define STR_SEM_MCS_ID_MAP           "semMcsIdMap"

#define STR_SEM_CARR_MAP             "semCarrMap"

#define CARR_MAP_MNG_INIT_CHK()      \
{                                    \
    if (s_carrMapMngGrp.init != CARR_MAP_MNG_INIT_FLAT) \
    {                                \
        return BSP_OK;               \
    }                                \
    if (s_carrMapMngGrp.num == 0)    \
    {                                \
        return ERROR_INVALID_PARA;   \
    }                                \
    INPUT_POINTER_CHECK(s_carrMapMngGrp.pCarrMap); \
}

#define CARRID_MAP_INIT_CHK()        \
{                                    \
    if (s_carrIdMapGrp.init != CARR_MAP_MNG_INIT_FLAT) \
    {                                \
        return BSP_ERROR;            \
    }                                \
    if (s_carrIdMapGrp.num == 0)     \
    {                                \
        return BSP_ERROR;            \
    }                                \
    if (s_carrIdMapGrp.pMap == NULL) \
    {                                \
        return BSP_ERROR;            \
    }                                \
}

typedef struct tagT_CarrMapMngGrp
{
    T_CarrMapMng *pCarrMap;
    UINT32 num;
    UINT32 init;
}T_CarrMapMngGrp;

typedef struct tagT_McsCarrIdMapGrp
{
    T_McsCarrIdMap *pMap;
    UINT32 num;
    UINT32 init;
}T_McsCarrIdMapGrp;

static UINT32      s_optMapNum    = 0;
static T_OptMapMng *s_pOptMapInfo = NULL;

static T_CarrMapMngGrp s_carrMapMngGrp = {0, 0, 0};
static T_McsCarrIdMapGrp s_carrIdMapGrp = {0, 0, 0};

static pUpdateLogicCarrMap pFuncUpdateLogicCarrMap = NULL;
static FUNC_SET_MCSID_MAP  pFuncSetMcsIdMapCallback = NULL;

UINT32 BspGetTxBspChanNum(VOID)
{
    return BspGetTxChannel();
}

UINT32 BspGetRxBspChanNum(VOID)
{
    return BspGetRxChannel();
}

UINT32 BspGetBspCarrNum(VOID)
{
    return BspGetCarrierNum();
}


UINT32 BspOptMapMngInit(T_OptMapMng *pOptMap, UINT32 optMapNum)
{
    s_pOptMapInfo = pOptMap;
    s_optMapNum   = optMapNum;
    return BSP_OK;
}

UINT32 BspOptMapNumGet(VOID)
{
    return s_optMapNum;
}


static T_OptMapMng *GetOptMapMngInfo(UINT32 prop,UINT32 propVal, UINT32 uFpgaType )
{
    T_OptMapMng *pOptMap = s_pOptMapInfo;
    UINT32 loop = 0;

    if (prop >= E_OPT_MAP_NUM)
    {
        return NULL;
    }
    for (loop = 0; loop < s_optMapNum; loop++, pOptMap++)
    {
        if ((propVal == pOptMap->opt[prop]) && (uFpgaType == pOptMap->opt[E_OPT_MAP_FPGA_TYPE]))
        {
            return pOptMap;
        }
    }

    return NULL;
}

UINT32 BspGetSfpMapInfoByPhyOpt(UINT32 phyOpt,UINT32 *sfpType,UINT32 *sfpIndex,UINT32 *sfpChan)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_PHY_OPT, phyOpt, E_FPGA_TYPE_OPT);
    INPUT_POINTER_CHECK(pOptMap);

    if (sfpType)
    {
        *sfpType = pOptMap->opt[E_OPT_MAP_SFP_TYPE];
    }
    if (sfpIndex)
    {
        *sfpIndex = pOptMap->opt[E_OPT_MAP_SFP_INDEX];
    }
    if (sfpChan)
    {
        *sfpChan = pOptMap->opt[E_OPT_MAP_SFP_CHAN];
    }

    return BSP_OK;
}

UINT32 BspGetSfpMapInfoByLogicOpt(UINT32 logicOpt,UINT32 *sfpType,UINT32 *sfpIndex,UINT32 *sfpChan)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_LGC_OPT, logicOpt, E_FPGA_TYPE_OPT);
    INPUT_POINTER_CHECK(pOptMap);

    if (sfpType)
    {
        *sfpType = pOptMap->opt[E_OPT_MAP_SFP_TYPE];
    }
    if (sfpIndex)
    {
        *sfpIndex = pOptMap->opt[E_OPT_MAP_SFP_INDEX];
    }
    if (sfpChan)
    {
        *sfpChan = pOptMap->opt[E_OPT_MAP_SFP_CHAN];
    }

    return BSP_OK;
}

/*****************************************************************************
 * 函数名称 : BspSetSfpTypeBySfpId(*)
 * 功能描述 : 根据光模块索引配置光模块类型
 * 输入参数 : ulSfpIndex - 光模块索引号
 *            ulSfpType  - 光模块类型(E_SFP/E_DSFP/E_QSFP)
 * 输出参数 : 无
 * 返 回 值 : BSP_OK- 成功, 其它- 失败
 * 其它说明 : 无
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), liuheyu@2021-03-10 14:30:00, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspSetSfpTypeBySfpId(UINT32 ulSfpIndex, UINT32 ulSfpType)
{
    UINT32 ulPropType = 0;
    UINT32 ulFpgaType = 0;
    T_OptMapMng *ptOptMap = NULL;

    ulPropType = E_OPT_MAP_SFP_INDEX;
    ulFpgaType = E_FPGA_TYPE_OPT;
    ptOptMap = GetOptMapMngInfo(ulPropType, ulSfpIndex, ulFpgaType);
    INPUT_POINTER_CHECK(ptOptMap);

    ptOptMap->opt[E_OPT_MAP_SFP_TYPE] = ulSfpType; // E_SFP E_DSFP E_QSFP

    return BSP_OK;
}

/***************************************
 *  函数名称: BspGetSfpTypeBySfpId
 *  功能描述: 根据光模块索引获取光模块类型 (QSFP/SFP)
 *  入参说明:
 *  返 回 值:
 *  其它说明:
-------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), dumin10126090@2018-2-3, 创建
-------------------------------------------------------------------------*/
UINT32 BspGetSfpTypeBySfpId(UINT32 sfpIndex)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_SFP_INDEX, sfpIndex,E_FPGA_TYPE_OPT);
    INPUT_POINTER_CHECK(pOptMap);

    return pOptMap->opt[E_OPT_MAP_SFP_TYPE];
}

UINT32 BspGetSfpTypeByLgcId(UINT32 optLgcId)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_LGC_OPT, optLgcId, E_FPGA_TYPE_OPT);
    INPUT_POINTER_CHECK(pOptMap);

    return pOptMap->opt[E_OPT_MAP_SFP_TYPE];
}

UINT32 BspGetSfpIdxBySfpId(UINT32 optLgcId)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_LGC_OPT, optLgcId,E_FPGA_TYPE_OPT);
    INPUT_POINTER_CHECK(pOptMap);

    return pOptMap->opt[E_OPT_MAP_SFP_INDEX];
}


/***************************************
 *  函数名称: BspGetLogicOptStartBySfpIndex
 *  功能描述: 根据光模块索引获取第一个逻辑光口号
 *  入参说明:
 *  返 回 值:
 *  其它说明: 要求optMapInfo按逻辑光口号升序排列
-------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), dumin10126090@2018-2-3, 创建
-------------------------------------------------------------------------*/
UINT32 BspGetLogicOptStartBySfpId(UINT32 sfpIndex )
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_SFP_INDEX, sfpIndex,E_FPGA_TYPE_OPT);
    INPUT_POINTER_CHECK(pOptMap);

    return pOptMap->opt[E_OPT_MAP_LGC_OPT];
}

#ifdef BUILD_WITH_OM_FUNC
UINT32 BspGetFpgaClkTypeByFpgaIndex(UINT32 fpgaIndex, UINT32 fpgaType, UINT32 *fpgaClkType)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_FPGA_IDX, fpgaIndex, E_FPGA_TYPE_OPT);
    INPUT_POINTER_CHECK(pOptMap);

    *fpgaClkType = pOptMap->opt[E_OPT_MAP_FPGA_CLK_TYPE];

    return BSP_OK;
}

#endif

UINT32 BspGetFpgaIdxByPhyOpt(UINT32 phyOpt,UINT32 *fpgaIndex,UINT32 *fpgaChan,UINT32 uFpgaType)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_PHY_OPT, phyOpt,uFpgaType);

    if(pOptMap == NULL)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(fpgaIndex);
    INPUT_POINTER_CHECK(fpgaChan);
    *fpgaIndex = pOptMap->opt[E_OPT_MAP_FPGA_IDX];
    *fpgaChan  = pOptMap->opt[E_OPT_MAP_FPGA_CHAN];
    return BSP_OK;
}

UINT32 BspGetSfpChanByPhyOpt(UINT32 phyOpt,UINT32 *sfpChan)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_PHY_OPT, phyOpt,E_FPGA_TYPE_OPT);
    if (pOptMap == NULL)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(sfpChan);
    *sfpChan = pOptMap->opt[E_OPT_MAP_SFP_CHAN];
    return BSP_OK;
}

UINT32 BspGetFpgaIdxByLogicOpt(UINT32 logicOpt,UINT32 *fpgaIndex,UINT32 *fpgaChan)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_LGC_OPT, logicOpt, E_FPGA_TYPE_OPT);
    if (pOptMap == NULL)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(fpgaIndex);
    INPUT_POINTER_CHECK(fpgaChan);
    *fpgaIndex = pOptMap->opt[E_OPT_MAP_FPGA_IDX];
    *fpgaChan  = pOptMap->opt[E_OPT_MAP_FPGA_CHAN];
    return BSP_OK;
}

UINT32 BspGetOptRaidoByPhyOpt(UINT32 phyOpt,UINT32 *radioMode,UINT32 *optPro)
{
    T_OptMapMng *pOptMap = GetOptMapMngInfo(E_OPT_MAP_PHY_OPT, phyOpt,E_FPGA_TYPE_OPT);
    if (pOptMap == NULL)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(radioMode);
    INPUT_POINTER_CHECK(optPro);
    *radioMode = pOptMap->opt[E_OPT_MAP_RADIO_MODE];
    *optPro = pOptMap->opt[E_OPT_MAP_OPT_PRO];
    return BSP_OK;
}


UINT32 BspCarrMapMngInit(T_CarrMapMng *pMap, UINT32 num)
{
    UINT32 retVal = 0;
    const CHAR *semOwner = STR_SEM_CARR_MAP;
    const CHAR *semFunc = __FUNCTION__;

    INPUT_POINTER_CHECK(pMap);
    if (num > BSP_MAX_CARR_NUM*2)  /* 同时会把上下行载波设置，所以此处*2 */
    {
        return BSP_ERROR;
    }
    if (s_carrMapMngGrp.pCarrMap == NULL)
    {
        s_carrMapMngGrp.pCarrMap = (T_CarrMapMng *)calloc(BSP_MAX_CARR_NUM*2,sizeof(T_CarrMapMng));
        INPUT_POINTER_CHECK(s_carrMapMngGrp.pCarrMap);
    }

    retVal = BspSemMgrTake(semOwner,(UINT32)WAIT_FOREVER,semFunc);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }

    memcpy(s_carrMapMngGrp.pCarrMap, pMap, num*sizeof(T_CarrMapMng));
    s_carrMapMngGrp.num = num;
    s_carrMapMngGrp.init = CARR_MAP_MNG_INIT_FLAT;

    BspSemMgrGive(semOwner);
    return BSP_OK;
}

UINT32 BspGetCarrMapInfo(T_CarrMapMng *pMap, UINT32 mapNum, UINT32 *retNum)
{
    UINT32 cpyNum = 0;
    UINT32 retVal = 0;
    const CHAR *semOwner = STR_SEM_CARR_MAP;
    const CHAR *semFunc = __FUNCTION__;

    INPUT_POINTER_CHECK(pMap);
    INPUT_POINTER_CHECK(retNum);
    CARR_MAP_MNG_INIT_CHK();

    retVal = BspSemMgrTake(semOwner,(UINT32)WAIT_FOREVER,semFunc);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }

    if (mapNum >= s_carrMapMngGrp.num)
    {
        cpyNum = s_carrMapMngGrp.num;
    }
    else
    {
        cpyNum = mapNum;
    }
    memcpy(pMap, s_carrMapMngGrp.pCarrMap, cpyNum*sizeof(T_CarrMapMng));
    *retNum = cpyNum;

    BspSemMgrGive(semOwner);
    return BSP_OK;
}

UINT32 BspGetBspCarrMap(UINT32 dir,UINT32 logicCarr,UINT32 radioMode,UINT32 *bspCarr,UINT32 *difCarr)
{
    UINT32 loop;
    CARR_MAP_MNG_INIT_CHK();
    for (loop = 0; loop < s_carrMapMngGrp.num; loop++)
    {

          dbgInfoEx("%s>> Loop %d,num %d,dir %d,bspCarr %d,lgcCarr %d,difCarr %d,radio %d[dir %d,logiCarr %d,radio %d]\n",__FUNCTION__,loop,s_carrMapMngGrp.num,\
            s_carrMapMngGrp.pCarrMap[loop].dir,s_carrMapMngGrp.pCarrMap[loop].bspCarrNo,s_carrMapMngGrp.pCarrMap[loop].logicCarrNo,\
            s_carrMapMngGrp.pCarrMap[loop].difCarrNo,s_carrMapMngGrp.pCarrMap[loop].radioMode,
            dir,logicCarr,radioMode);
        if ((dir == s_carrMapMngGrp.pCarrMap[loop].dir) && \
            (logicCarr == s_carrMapMngGrp.pCarrMap[loop].logicCarrNo) && \
            (radioMode == s_carrMapMngGrp.pCarrMap[loop].radioMode))
        {
            if (bspCarr)
            {
                *bspCarr = s_carrMapMngGrp.pCarrMap[loop].bspCarrNo;
                dbgInfoEx("%s>>bspCarr %d\n",__FUNCTION__,*bspCarr);
            }
            if (difCarr)
            {
                *difCarr= s_carrMapMngGrp.pCarrMap[loop].difCarrNo;
                dbgInfoEx("%s>>difCarr %d\n",__FUNCTION__,*difCarr);
            }
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

UINT32 getCarrMap(UINT32 dir, UINT32 logicCarr,UINT32 radioMode)
{
    UINT32 bspCarr = 0;
    UINT32 difCarr = 0;
    UINT32 retVal  = 0;
    retVal = BspGetBspCarrMap(dir,logicCarr,radioMode,&bspCarr,&difCarr);

    printf("bspCarr %d, difCarr %d, retVal = 0x%08X\n", bspCarr, difCarr, retVal);

    return retVal;
}

UINT32 BspGetBspCarrRadioMode(UINT32 dir,UINT32 bspCarr)
{
     UINT32 loop;
     CARR_MAP_MNG_INIT_CHK();
     for (loop = 0; loop < s_carrMapMngGrp.num; loop++)
     {
         if (dir == s_carrMapMngGrp.pCarrMap[loop].dir &&
             bspCarr == s_carrMapMngGrp.pCarrMap[loop].bspCarrNo)
         {
             return s_carrMapMngGrp.pCarrMap[loop].radioMode;
         }
     }
     return 0;
}

UINT32 BspGetLogicCarrRadioMode(UINT32 dir,UINT32 logicCarr)
{
    UINT32 loop;
    CARR_MAP_MNG_INIT_CHK();
    for (loop = 0; loop < s_carrMapMngGrp.num; loop++)
    {
        if (dir == s_carrMapMngGrp.pCarrMap[loop].dir &&
            logicCarr == s_carrMapMngGrp.pCarrMap[loop].logicCarrNo)
        {
            return s_carrMapMngGrp.pCarrMap[loop].radioMode;
        }
    }
    return 0;
}

UINT32 BspUpdateLogicCarrMapCallInit(pUpdateLogicCarrMap pCallBackFunc)
{
    pFuncUpdateLogicCarrMap = pCallBackFunc;
    return BSP_OK;
}

/* 单板注册回调实现 */
UINT32 BspUpdateLogicCarrMap(UINT32 dir,T_RfCfgPara *pRfCfg)
{
    INPUT_POINTER_CHECK(pRfCfg);
    CARR_MAP_MNG_INIT_CHK();

    return BSP_OK;
}

UINT32 carrmapinfo()
{
    UINT32 loop;
    const CHAR  *strRadioMode;
    CARR_MAP_MNG_INIT_CHK();
    dbgInfo("dir bspCarr logicCarr difCarr radioMode\n");
    for (loop = 0; loop < s_carrMapMngGrp.num; loop++)
    {
        STD_RADIOMODE_NAME_STR(s_carrMapMngGrp.pCarrMap[loop].radioMode, strRadioMode);
        dbgInfo("%-3s %-7d %-9d %-8d %-9s\n",
                s_carrMapMngGrp.pCarrMap[loop].dir == TX ? "TX" : "RX",
                s_carrMapMngGrp.pCarrMap[loop].bspCarrNo,
                s_carrMapMngGrp.pCarrMap[loop].logicCarrNo,
                s_carrMapMngGrp.pCarrMap[loop].difCarrNo,
                strRadioMode);
    }
    return BSP_OK;
}

UINT32 BspSetMcsIdMapCallbackInit(FUNC_SET_MCSID_MAP pFunc)
{
    pFuncSetMcsIdMapCallback = pFunc;
    return BSP_OK;
}

UINT32 BspCarrIdMapInit(T_McsCarrIdMap *pMap, UINT32 num)
{
    INPUT_POINTER_CHECK(pMap);

    if (num > MCS_ID_MAP_NUM_MAX)
    {
        return BSP_ERROR;
    }
    if (s_carrIdMapGrp.pMap == NULL)
    {
        s_carrIdMapGrp.pMap = (T_McsCarrIdMap *)malloc(MCS_ID_MAP_NUM_MAX*sizeof(T_McsCarrIdMap));
        INPUT_POINTER_CHECK(s_carrIdMapGrp.pMap);
        memset(s_carrIdMapGrp.pMap, 0, MCS_ID_MAP_NUM_MAX*sizeof(T_McsCarrIdMap));
    }

    memcpy(s_carrIdMapGrp.pMap, pMap, num*sizeof(T_McsCarrIdMap));
    s_carrIdMapGrp.num = num;
    s_carrIdMapGrp.init = CARR_MAP_MNG_INIT_FLAT;
    return BSP_OK;
}

UINT32 BspSetMcsCarrIdMap(T_McsCarrIdMap *pMap, UINT32 num)
{
    UINT32 retVal = 0;
    const CHAR *semOwner = STR_SEM_MCS_ID_MAP;
    const CHAR *semFunc = __FUNCTION__;

    BspLog(LOG_LEVEL_0,"%s,{%d} \n",__FUNCTION__,num);
    retVal = BspSemMgrTake(semOwner,(UINT32)WAIT_FOREVER,semFunc);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }
    retVal = BspCarrIdMapInit(pMap,num);
    BspSemMgrGive(semOwner);

    if (pFuncSetMcsIdMapCallback)
    {
        pFuncSetMcsIdMapCallback();
    }
    BspLog(LOG_LEVEL_0,"%s,{%d} return %d\n",__FUNCTION__,num,retVal);
    return retVal;
}

static UINT32 GetMcsCarrIdMap(T_McsCarrIdMap *pMap,UINT32 *num)
{
    INPUT_POINTER_CHECK(pMap);
    INPUT_POINTER_CHECK(num);
    CARRID_MAP_INIT_CHK();
    if (*num < s_carrIdMapGrp.num)
    {
        return BSP_ERROR;
    }
    memcpy(pMap, s_carrIdMapGrp.pMap, s_carrIdMapGrp.num*sizeof(T_McsCarrIdMap));
    *num = s_carrIdMapGrp.num;
    return BSP_OK;
}

UINT32 BspGetMcsCarrIdMap(T_McsCarrIdMap *pMap,UINT32 *num)
{
    UINT32 retVal = 0;
    const CHAR *semOwner = STR_SEM_MCS_ID_MAP;
    const CHAR *semFunc = __FUNCTION__;
    INPUT_POINTER_CHECK(pMap);
    INPUT_POINTER_CHECK(num);

    retVal = BspSemMgrTake(semOwner,(UINT32)WAIT_FOREVER,semFunc);
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }

    retVal = GetMcsCarrIdMap(pMap, num);
    BspSemMgrGive(semOwner);
    return retVal;
}

UINT32 BspCarrIdMapGetRadioMode(UINT32 logicCarrNo)
{
    UINT32 loop;
    T_McsCarrIdMap mapInfo[MCS_ID_MAP_NUM_MAX] = {0};
    UINT32 mapInfoNum = MCS_ID_MAP_NUM_MAX;
    if (BSP_OK != BspGetMcsCarrIdMap(mapInfo,&mapInfoNum))
    {
        return BSP_ERROR;
    }
    for (loop = 0; loop < mapInfoNum; loop++)
    {
        if (logicCarrNo == mapInfo[loop].logicCarrNo)
        {
            return mapInfo[loop].radioMode;
        }
    }
    return BSP_ERROR;
}

UINT32 BspCarrIdMapGetLocalCarrId(UINT32 logicCarrNo,UINT32 *localCarrId,UINT32 *radioMode)
{
    UINT32 loop;
    T_McsCarrIdMap mapInfo[MCS_ID_MAP_NUM_MAX] = {0};
    UINT32 mapInfoNum = MCS_ID_MAP_NUM_MAX;
    INPUT_POINTER_CHECK(localCarrId);
    INPUT_POINTER_CHECK(radioMode);
    if (BSP_OK != BspGetMcsCarrIdMap(mapInfo,&mapInfoNum))
    {
        return BSP_ERROR;
    }

    for (loop = 0; loop < mapInfoNum; loop++)
    {
        if (logicCarrNo == mapInfo[loop].logicCarrNo)
        {
            *localCarrId = mapInfo[loop].localCarrId;
            *radioMode = mapInfo[loop].radioMode;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

UINT32 BspLocalCarrIdMapGetCarrId(UINT32 localCarrId)
{
    UINT32 loop;
    T_McsCarrIdMap mapInfo[MCS_ID_MAP_NUM_MAX] = {0};
    UINT32 mapInfoNum = MCS_ID_MAP_NUM_MAX;
    if (BSP_OK != BspGetMcsCarrIdMap(mapInfo,&mapInfoNum))
    {
        return BSP_ERROR;
    }
    for (loop = 0; loop < mapInfoNum; loop++)
    {
        if (localCarrId == mapInfo[loop].localCarrId)
        {
            return mapInfo[loop].logicCarrNo;
        }
    }
    return BSP_ERROR;
}

UINT32 BspCarrIdMapGetoptId(UINT32 logicCarrNo)
{
    UINT32 loop;
    T_McsCarrIdMap mapInfo[MCS_ID_MAP_NUM_MAX] = {0};
    UINT32 mapInfoNum = MCS_ID_MAP_NUM_MAX;
    if (BSP_OK != BspGetMcsCarrIdMap(mapInfo,&mapInfoNum))
    {
        return BSP_ERROR;
    }
    for (loop = 0; loop < mapInfoNum; loop++)
    {
        if (logicCarrNo == mapInfo[loop].logicCarrNo)
        {
            return mapInfo[loop].optId;
        }
    }
    return BSP_ERROR;
}

UINT32 BspGetLocalCarrIdMap(T_McsCarrIdMap *pMap, UINT32 *num)
{
    UINT32 loop, idx;
    UINT32 cnt = 0;
    UINT32 logicCarrNo = 0;
    UINT32 found = 0;
    T_McsCarrIdMap mapInfo[MCS_ID_MAP_NUM_MAX] = {0};
    UINT32 mapInfoNum = MCS_ID_MAP_NUM_MAX;

    INPUT_POINTER_CHECK(pMap);
    INPUT_POINTER_CHECK(num);
    if (BSP_OK != BspGetMcsCarrIdMap(mapInfo,&mapInfoNum))
    {
        return BSP_ERROR;
    }

    for (cnt = loop = 0; loop < mapInfoNum; loop++)
    {
        logicCarrNo = mapInfo[loop].logicCarrNo;
        for (found = idx = 0; idx < cnt; idx++)
        {
            if (logicCarrNo == pMap[idx].logicCarrNo)
            {
                found = 1;
                break;
            }
        }
        if (found == 1)
        {
            continue;
        }
        memcpy(&pMap[cnt],&mapInfo[loop],sizeof(T_McsCarrIdMap));
        cnt++;
    }
    *num = cnt;
    return BSP_OK;
}

UINT32 carridmap(VOID)
{
    UINT32 ulLoop = 0;
    UINT32 ulMapInfoSum = 0;
    UINT32 ulTmpRet = BSP_OK;
    const CHAR *pucStrRadioMode = NULL;
    T_McsCarrIdMap tCarrIdMapInfo[MCS_ID_MAP_NUM_MAX] = {0};

    ulMapInfoSum = MCS_ID_MAP_NUM_MAX;
    ulTmpRet = BspGetMcsCarrIdMap(&tCarrIdMapInfo[0], &ulMapInfoSum);
    if (BSP_OK == ulTmpRet)
    {
        dbgInfo("LogicCarrNo LocalCarrId RadioMode McsId McsCoreIdMask bandWidth optId\n");
        for (ulLoop = 0; ulLoop < ulMapInfoSum; ulLoop++)
        {
            STD_RADIOMODE_NAME_STR(tCarrIdMapInfo[ulLoop].radioMode, pucStrRadioMode);
            dbgInfo("  %-11d %-10d %-10s %-5d 0x%-11x %-9d %-5d\n",
            tCarrIdMapInfo[ulLoop].logicCarrNo,
            tCarrIdMapInfo[ulLoop].localCarrId,
            pucStrRadioMode,
            tCarrIdMapInfo[ulLoop].mcsId,
            tCarrIdMapInfo[ulLoop].mcsCoreIdMask,
            tCarrIdMapInfo[ulLoop].bandWidth,
            tCarrIdMapInfo[ulLoop].optId);
        }
    }
    else
    {
        dbgErr("%s>>McsCarrIdMap Get Error!\n", __FUNCTION__);
    }

    return BSP_OK;
}

UINT32 localcarridmap(VOID)
{
    UINT32 num = MCS_ID_MAP_NUM_MAX;
    UINT32 loop = 0;
    const CHAR  *strRadioMode = NULL;
    T_McsCarrIdMap carrIdMap[MCS_ID_MAP_NUM_MAX] = {0};

    if (BspGetLocalCarrIdMap(carrIdMap,&num) != BSP_OK)
    {
        dbgErr("%s get failed\n",__FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("logicCarrNo localCarrId radioMode  mcsId mcsCoreIdMask bandWidth optId\n");
    for (loop = 0; loop < num; loop++)
    {
        STD_RADIOMODE_NAME_STR(carrIdMap[loop].radioMode, strRadioMode);
        dbgInfo("%-11d %-11d %-10s %-5d 0x%-11x %-9d %-5d\n",
        carrIdMap[loop].logicCarrNo,
        carrIdMap[loop].localCarrId,
        strRadioMode,
        carrIdMap[loop].mcsId,
        carrIdMap[loop].mcsCoreIdMask,
        carrIdMap[loop].bandWidth,
        carrIdMap[loop].optId);
    }
    return BSP_OK;
}

static pGetBspChnlByAntFreq pFunGetBspChnlByAntFreq = NULL;

UINT32 BspGetBspChnlByAntFreqCallInit(pGetBspChnlByAntFreq pCallBackFunc)
{
    pFunGetBspChnlByAntFreq = pCallBackFunc;

    return BSP_OK;
}

UINT32 BspGetBspChnlByAntAndFreq(UINT32 ulTrxDir, UINT32 ulRfAntNo, UINT32 ulRfFreqKHz, UINT32 *pulBspChnl)
{
    UINT32 ulRetVal = BSP_OK;

    if (NULL != pulBspChnl)
    {
        if (NULL != pFunGetBspChnlByAntFreq)
        {
        //  MapGetBspChnlByAntAndFreq(ulTrxDir, ulRfAntNo, ulRfFreqKHz, pulBspChnl);
            ulRetVal = pFunGetBspChnlByAntFreq(ulTrxDir, ulRfAntNo, ulRfFreqKHz, pulBspChnl);
        }
        else
        {
            *pulBspChnl = ulRfAntNo; /* 一一对应 */
        }
    }
    else
    {
        ulRetVal = BSP_ERROR;
    }

    return ulRetVal;
}
UINT32 BspReMapCarrMap(VOID)
{
    UINT32 loop = 0;
    UINT32 num = 0;
    UINT32 loop1 = 0;
    UINT32 num1 = 0;

    num =  s_carrMapMngGrp.num;
    num1 = s_carrIdMapGrp.num;

    for(loop=0; loop<num; ++loop)
    {
        for(loop1=0; loop1<num1; ++loop1)
        {
            if(s_carrMapMngGrp.pCarrMap[loop].difCarrNo == s_carrIdMapGrp.pMap[loop1].localCarrId )
            {
                s_carrMapMngGrp.pCarrMap[loop].logicCarrNo = s_carrIdMapGrp.pMap[loop1].logicCarrNo;
                s_carrMapMngGrp.pCarrMap[loop].bspCarrNo = s_carrIdMapGrp.pMap[loop1].logicCarrNo;
                dbgInfo("%s loop:%d loop1: %d bspCarrNo:%d logicCarrNo:%d difCarrNo:%d\n",__FUNCTION__,loop,loop1,s_carrMapMngGrp.pCarrMap[loop].bspCarrNo,s_carrMapMngGrp.pCarrMap[loop].logicCarrNo,s_carrMapMngGrp.pCarrMap[loop].difCarrNo);
                //boardLog(LOG_INFO,"%s loop:%d loop1: %d bspCarrNo:%d logicCarrNo:%d difCarrNo:%d\n",__FUNCTION__,loop,loop1,s_carrMapMngGrp.pCarrMap[loop].bspCarrNo,s_carrMapMngGrp.pCarrMap[loop].logicCarrNo,s_carrMapMngGrp.pCarrMap[loop].difCarrNo);
                continue;
            }
        }
    }
    return BSP_OK;
}


VOID Lcmaplocalctest(VOID)
{
    UINT32 uLoop = 0;
    T_McsCarrIdMap upMap[8] = {0};
    UINT32  uCarriNO[8]={0,2,4,3,5,7,6,1};
    UINT32  ulocarrid[8]={3,5,4,7,0,1,2,6};

    UINT32  uCarriNO200M[4]={0,2,1,3};
    UINT32  ulocarrid200M[4]={3,1,0,2};

    UINT32  uCarriNO400M[2]={0,1};
    UINT32  ulocarrid400M[2]={1,0};

    dbgInfo("\n100M ******************************************** \n");

    for(uLoop =0;uLoop<8;uLoop++)
    {
        upMap[uLoop].bandWidth = 100;
        upMap[uLoop].localCarrId =ulocarrid[uLoop];
        upMap[uLoop].logicCarrNo =uCarriNO[uLoop];
    }

    BspSetMcsCarrIdMap(((T_McsCarrIdMap *)(&upMap)),  8);

    dbgInfo("\n200M ******************************************** \n");

    for(uLoop =0;uLoop<4;uLoop++)
    {
        upMap[uLoop].bandWidth = 200;
        upMap[uLoop].localCarrId =ulocarrid200M[uLoop];
        upMap[uLoop].logicCarrNo =uCarriNO200M[uLoop];
    }

    BspSetMcsCarrIdMap(((T_McsCarrIdMap *)(&upMap)),  4);

     dbgInfo("\n400M ******************************************** \n");

    for(uLoop =0;uLoop<2;uLoop++)
    {
        upMap[uLoop].bandWidth = 400;
        upMap[uLoop].localCarrId =ulocarrid400M[uLoop];
        upMap[uLoop].logicCarrNo =uCarriNO400M[uLoop];
    }

    BspSetMcsCarrIdMap(((T_McsCarrIdMap *)(&upMap)),  2);

}



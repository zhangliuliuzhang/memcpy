/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : chnmap_a.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供rru的丝印映射模块的实现
 * 注意事项 : 无
 * 作    者 : wangfei
 * 创建日期 : 2017-3-06 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#ifndef FUNCLIB_CHN_MAP_H_INCLUDED
#define FUNCLIB_CHN_MAP_H_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "chnmapcommon.h"



/**************************************************************************
 *                        宏定义
 **************************************************************************/


/* 检查中频通道 返回BSP_ERROR*/
#define INPUT_DIFCHAN_CHECK(difchn)                                      \
    if (difchn >= BspGetDifChnTotalNum())                                \
    {                                                                    \
        return BSP_ERROR;                                                \
    }
    
#define   LINK_REMOTE             (1)
#define   LINK_HOME               (0)


/**************************************************************************
*                         数据类型                                       *
**************************************************************************/
enum _LINK_INFO_DEF_
{
    LINK_INFO_LINKID   = 0,  /* LINK编号 */
    LINK_INFO_LINKTYPE,      /* LINK类型 RX/TX*/
    LINK_INFO_RFCHN,         /* LINK所属通道射频 RRU高层通道号*/
    LINK_INFO_BSPCHN,        /* LINK所属BSP通道号*/

    LINK_INFO_DIFCHIPID,     /* LINK对应的中频芯片id */
    LINK_INFO_DIFCHN,        /* LINK对应的中频通道号 */
    LINK_INFO_CALICHN,       /* LINK对应的射频校准补偿通道号 */
    LINK_INFO_ANTID,         /* LINK对应天线号 */

    LINK_INFO_ANTCHN,        /* LINK对应天线通道*/
    LINK_INFO_DFLID,         /* LINK对应DFL索引 */
    LINK_INFO_DFLCHN,        /* LINK对应DFL通道 */
    LINK_INFO_PAID,          /* LINK对应Pa索引 */

    LINK_INFO_PACHN,         /* LINK对应Pa通道 */
    LINK_INFO_FBCH,          /* 发射通道对应的反馈通道的编号 */
    LINK_BAND_MASK,
    LINK_INFO_PORTID,        /*子端端口号*/

    LINK_INFO_PORT_SLAVECHN, /*子端通道号*/

    LINK_INFO_TYPE_NUM

};

enum _LINK_INFO_DEF_TDDIO
{
    LINK_INFO_RFCHN_TDDIO   = 0,   /* LINK所属射频通道 RRU高层通道号*/
    LINK_INFO_LINKTYPE_TDDIO,      /* LINK类型 RX/TX*/
    LINK_INFO_TXCHN_TDDIO,         /* LINK对应Tx通道 */
    LINK_INFO_RXCHN_TDDIO,         /* LINK对应Rx通道 */
    LINK_INFO_FBCHN_TDDIO,        /* LINK对应Fb反馈通道 */
    LINK_INFO_PACHN_TDDIO,         /* LINK对应PA通道 */
    LINK_INFO_LNACHN_TDDIO,        /* LINK对应LNA通道 */
    LINK_INFO_LNASWCHN_TDDIO,        /* LINK对应LnaSwitch通道 */
    LINK_INFO_TXACCHN_TDDIO,         /* LINK对应TxAc通道 */
    LINK_INFO_RXACCHN_TDDIO,         /* LINK对应RxAc通道 */
    LINK_INFO_AMPCHN_TDDIO,         /* LINK对应AMP通道 */
    LINK_INFO_TYPE_NUM_TDDIO
};

enum _TDD_INFO_DEF_TDDIO
{
    TDD_INFO_IOCHN_TDDIO   = 0,   /* TDD所属IO通道 RRU高层通道号*/
    TDD_INFO_LINKTYPE_TDDIO,      /* TDD类型 RX/TX*/
    TDD_INFO_TXCHN_TDDIO,         /* TDD对应Tx通道 */
    TDD_INFO_RXCHN_TDDIO,         /* TDD对应Rx通道 */
    TDD_INFO_FBCHN_TDDIO,        /* TDD对应Fb反馈通道 */
    TDD_INFO_PACHN_TDDIO,         /* TDD对应PA通道 */
    TDD_INFO_LNACHN_TDDIO,        /* TDD对应LNA通道 */
    TDD_INFO_LNASWCHN_TDDIO,        /* TDD对应LnaSwitch通道 */
    TDD_INFO_TXACCHN_TDDIO,         /* TDD对应TxAc通道 */
    TDD_INFO_RXACCHN_TDDIO,         /* TDD对应RxAc通道 */
    TDD_INFO_TYPE_NUM_TDDIO
};

enum _ANT_DET_MAP_INFO_DEF_CHAN
{
    MAP_INFO_BSP_CHAN,              /* bsp通道号 */
    MAP_INFO_ANT_CHAN,              /* 天线号 */
    MAP_INFO_ANT_DET_PIN_CHAN,      /* 天馈检测引脚号 */
    MAP_INFO_NUM_MAX
};

typedef struct _T_TDD_MAP_TDDIO
{
    UINT32 TddInfo[TDD_INFO_TYPE_NUM_TDDIO];
} T_RU_TDD_MAP_TDDIO;

typedef struct _T_LINK_MAP_
{
    UINT32 linkInfo[LINK_INFO_TYPE_NUM];
} T_RU_LINK_MAP;

typedef struct _T_RU_LINK_MAP_APP_CFG_
{
    UINT32 rfCh;
    UINT32 fwdType;  //1：NCR大下行；0：NCR 大上行
    UINT32 trxType;  //1：rfCh发射； 0：rfCh接收
    UINT32 radioMode;
    UINT32 groupId;
    UINT32 tddId;
    UINT32 rfChRx;
} T_RU_LINK_MAP_APP_CFG;

typedef struct _T_ANT_DET_MAP_
{
    UINT32 linkInfo[MAP_INFO_NUM_MAX];
} T_RU_ANT_DET_MAP;

typedef struct _T_LINK_MAP_TDDIO
{
    UINT32 linkInfo[LINK_INFO_TYPE_NUM_TDDIO];
} T_RU_LINK_MAP_TDDIO;

//qcell 第二级低噪放bypass功能，硬件规避
typedef struct _T_LNA2_BYPASS_MAP
{
    UINT32 rfCh;/* 射频通道与bsp通道一一对应 */
    INT32 lna2BypassGain;/* 反补增益值 */
    UINT32 acBitIndex;/* ac bit位索引 需要跟硬件方案确认与bsp通道的对应关系 */
    UINT32 acBitSw;/* ac bit位使能 */
    UINT32 uiSel;/* 4选1 0:1  1:0  2：前级信号  3：前级信号取反  输出常1 */
    UINT32 uiHalPadName;/* 标模名称 */
    UINT32 padVal;/* 需要与硬件方案确认 */
} T_RU_LNA2_BYPASS_MAP;

//qcell 第二级低噪放bypass功能，硬件规避
typedef struct _T_UTDOA_AC_INDEX_MAP
{
    UINT32 rfCh;/* 射频通道与bsp通道一一对应 */
    UINT32 uiHalPadName;/* 标模名称 */
    UINT32 offset;/* 偏移量，就是ac管脚编号 */
} T_UTDOA_AC_INDEX_MAP;

/* Started by AICoder, pid:jc8ec1e1e4938d014cab09527000fc0e4938d90c */
typedef struct _T_AC_INDEX_MAP
{
    UINT32 rfCh;/* 射频通道与bsp通道一一对应 */
    UINT32 uiHalPadName;/* 标模名称 */
    UINT32 offset;/* 偏移量 */
} T_AC_INDEX_MAP;
/* Ended by AICoder, pid:jc8ec1e1e4938d014cab09527000fc0e4938d90c */

#define CHN_NUM_PER_CHIP ((UINT32)16)
enum _TDD_INFO_DEF_TDDIO_REALFUNC
{
    TDDIO_WORKAS_NOONE,       /*ic内部管脚不控制外部管脚*/
    TDDIO_WORKAS_SELF,       /* ic内部此IO用来控制与自己定义相同的外部管脚*/
    TDDIO_WORKAS_PA   ,      /* ic内部此IO用来控制外部功放管脚*/
    TDDIO_WORKAS_AMP  ,      /* ic内部此IO用来控制外部AMP管脚*/
    TDDIO_WORKAS_TXEN ,      /* ic内部此IO用来控制外部TXEN管脚*/
    TDDIO_MAX_FUNC_NUM
};

enum _TDD_INFO_DEF_TDDIO_BASEDLYPARA
{
	TDDIOPARA_BASEON_NOONE,     /* ic内部此IO不需要单独输出时序，不配置参数和设置mux 不使用此管脚 此管脚功能由其他类型管脚替换 其他管脚1控2，不需要单独控此管脚*/
	TDDIOPARA_BASEON_SELF,     /* ic内部此IO的时序以自身为准，不依赖耦合其他管脚 上行管脚使用*/
    TDDIOPARA_BASEON_PA    ,   /* ic内部此IO的时序以PA为准，即将PA的时序参数写到此io对应的寄存器*/
	TDDIOPARA_BASEON_AMP   ,   /* ic内部此IO的时序以AMP为准*/
	TDDIOPARA_BASEON_TXEN ,    /* ic内部此IO的时序以TXEN为准*/
    TDDIO_MAX_BASE_NUM
};
typedef struct _T_RU_LINK_MAP_TDDIO_TO_RF
{
    UINT32 tddIoNo;   /*IO的编号0~7/0~1，不使用的bit不要体现*/
    UINT32 linkType;  /*分上下行:参考_LINK_INFO_DEF_TDDIO这个枚举的用法，举例。TXEN全由AMP控制，则不填TXEN对应的行*/
    UINT32 baseOn;    /*基础时序参数以哪个管脚的为准,PA/AMP/TXEN目前有复用，填真实的，其他都填TDDIOPARA_BASEON_SELF，不用的管脚不会体现在这个表中*/
    UINT32 workAs;    /*这个管脚实际控制外部哪个管脚，PA/AMP/TXEN目前有复用，填真实的，TDDIO_WORKAS_SELF*/
    UINT32 tddNo;     /*此IO管脚使用哪一套tdd，比如AMP的8个bit 可能来自两套tdd,则每套tdd内部各个bit时序一致，tdd直接可以有差异*/
    UINT32 rfChNum;   /*1个IO挂了多少个射频通道*/
    UINT32 rfCh[4];   /*挂的射频通道具体个数 目前不会超过*/
    UINT32 rfChanPro; /*此IO控制的外部硬件管脚的属性，TDD-0或者FDD-1*/
} T_RU_LINK_MAP_TDDIO_TO_RF;

typedef struct tagT_DifSecMapInfo
{
    UINT32  rfchan;
    UINT32  difsecchan;
}T_DifSecMapInfo;

enum _OPT_SWITCH_INFO_DEF_
{
    OPT_SWITCH_INFO_OPTID   = 0,  
    OPT_SWITCH_INFO_LOGIC_OPT_ID,
    OPT_SWITCH_INFO_BSP_OPT_ID,   
    OPT_SWITCH_INFO_SFP_ID,
    OPT_SWITCH_INFO_BBFPGA_ID,
    OPT_SWITCH_INFO_EPLD_ID,
    OPT_SWITCH_INFO_TYPE_NUM
};

typedef struct _T_OPT_SWITCH_MAP_
{
    UINT32 optSwitchInfo[OPT_SWITCH_INFO_TYPE_NUM];
} T_RU_OPT_SWITCH_MAP;

enum _LINK_TYPE_DEF_
{
	LINK_TYPE_RX = 0,             /* 接收通道 */
	LINK_TYPE_TX,                 /* 发射通道 */
	LINK_TYPE_RX_M,               /* 接收通道主集 */
	LINK_TYPE_RX_S,               /* 接收通道分集 */
	LINK_TYPE_RX_S_Div,           /* 接收通道分集 */
	LINK_TYPE_RX_AC,             /* 接收通道 */
	LINK_TYPE_TX_AC,
	LINK_TYPE_TYPE_NUM
};

enum _BS_UE_LINK_TYPE_
{
    LINK_TYPE_UE_2_BS = 0,
    LINK_TYPE_BS_2_UE
};

typedef struct tagT_PWR_MAP_CHAN
{
    UINT32 pwrNum;/*48v电源砖个数*/
    UINT32 chnPwrIdx[BSP_MAX_CHAN_NUM];
}T_PWR_MAP_CHAN;

/* QCELL用于获取bsp通道和BBU下发的天线号的回调函数 */
typedef struct tagT_BspChanAndAntNo
{
    UINT32 (*pFuncGetBspChanFromAntNo)(UINT32 antNo);
    UINT32 (*pFuncGetAntNoFromBspChan)(UINT32 bspChan);
}T_BspChanAndAntNo;

/**************************************************************************
*                         函数接口
**************************************************************************/

UINT32 BspChanLinkInfoInit( const T_RU_LINK_MAP *pLinkMap, UINT32 linkNum);
UINT32 BspGetDifLinkMapInfo(const T_RU_LINK_MAP **pptMap , UINT32 *ulpSize);
UINT32 BspAntDetMapInfoInit( const T_RU_ANT_DET_MAP *pMapInfo, UINT32 antNum);
UINT32 BspGetAntDetMapInfo(const T_RU_ANT_DET_MAP **pptMap, UINT32 *ulpSize);
UINT32 BspSetDifChipNum(UINT32 difChipNum);
UINT32 BspGetDifChipNum(VOID);
UINT32 BspSetDifChnNumPerChip(UINT32 difChnNum);
UINT32 BspGetDifChnNumPerChip(VOID);
UINT32 BspGetDifChnTotalNum(VOID);
UINT32 BspGetRfChnInfoByDifChn(UINT32 difChn, UINT32 dir, UINT32 * pRfChn);
UINT32 BspGetBspChnInfoByDifChn(UINT32 difChn, UINT32 dir,UINT32 *bspChn);
UINT32 BspGetBspChnByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pBspChn);
UINT32 BspGetMaxOptNum(VOID);
UINT32 BspGetBbFpgaIdByOptId(UINT32 OptId, UINT32 * pBbFpgaId);
UINT32 BspGetEpldIdByOptId(UINT32 OptId, UINT32 *pEpldId);
UINT32 BspGetSfpIdByOptId(UINT32 OptId, UINT32 *pSfpId);
UINT32 BspGetDifInfoByAntInfo(UINT32 antId, UINT32 antChnl,UINT32 dir,UINT32 *pdifChipId, UINT32 *pdifChan);
UINT32 BspGetDifInfoByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pdifChipId, UINT32 *pdifChan);
UINT32 BspGetBandMaskByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *chipId, UINT32 *bandMask);
UINT32 BspGetPaChnByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *paChn);
UINT32 BspGetRfChnByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pRfChn);
UINT32 BspGetCaliChnByBspChn(UINT32 bspchn,UINT32 dir, UINT32 *pCaliChn);
UINT32 BspGetCaliChnByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pCaliChn);
UINT32 BspGetPaChnByCaliChn(UINT32 caliChn,UINT32 dir, UINT32 *paChn);
UINT32 BspGetBspChnByCaliChn(UINT32 caliChn,UINT32 dir, UINT32 *pBspChn);
UINT32 BspGetFbChnInfoByRfChn(UINT32 rfChn,UINT32 *pFbChn);
UINT32 BspGetChanLinkNum();
UINT32 BspGetLinkInfoByLinkId(UINT32 linkId, UINT32 inChnInfo,UINT32 *pChn);
UINT32 BspGetLinkInfoByLinkType(UINT32 linkType, UINT32 inChnType,ULONG inChnNum,UINT32 *pLinkId,UINT32 *pLinkNum);
UINT32 BspGetAntInfoByRfChn(UINT32 rfChn,UINT32 dir,UINT32 *antId,UINT32 *antChn);
UINT32 BspGetDflInfoByRfChn(UINT32 rfChn,UINT32 dir,UINT32 *dflId,UINT32 *dflChn);
UINT32 BspGetPaInfoByBspChn(UINT32 bspChn,UINT32 dir,UINT32*paId, UINT32 *paChn);
UINT32 BspGetAntInfoByBspChn(UINT32 Chn,UINT32 dir,UINT32 *antId,UINT32 *antChn);
UINT32 BspGetAntInfoByBspChnAndMode(UINT32 Chn,UINT32 dir, UINT32 ulRadioMode, UINT32 *antId,UINT32 *antChn);
UINT32 BspGetDflInfoByBspChn(UINT32 Chn,UINT32 dir,UINT32 *dflId,UINT32 *dflChn);
UINT32 BspGetI2cOptStatus();
UINT32 BspGetBspChnByPaInfo(UINT32 paId, UINT32 paChn, UINT32*bspChn);
UINT32 BspGetRxDifChanSecMap(UINT32 rfChan,UINT32 carrMode, UINT32 *difsecchan);
UINT32 BspSetDifChanSecMapTbl(UINT32 tblnum ,T_DifSecMapInfo* maptbl);
UINT32 BspGetBspChnByAntId(UINT32 antId,UINT32 dir, UINT32 *channum, UINT32 *pbspchan);
UINT32 BspChanOptSwitchInfoInit(T_RU_OPT_SWITCH_MAP *pOptSwitchMap, UINT32 OptSwitchNum);
UINT32 BspGetBspChnByDifChn(UINT32 difChn,UINT32 dir, UINT32 *BspChn);
UINT32 BspGetRealTddNoByTddIoInfo(UINT32 ioChan , UINT32 DeslinkPro, UINT32 *pVal);
UINT32 BspGetPaChnByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *paChn);
UINT32 BspGetLnaIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *plnaIo);
UINT32 BspGetRxEnIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *prxEnIo);
UINT32 BspGetTxEnIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *ptxEnIo);
UINT32 BspGetPaIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *ppaIo);
UINT32 BspGetLnaSwIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *plnaSwIo);
UINT32 BspGetFbIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pfbIo);
UINT32 BspGetTxAcIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *ptxAcIo);
UINT32 BspGetRxAcIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *prxAcIo);
UINT32 BspGetDownLinkChanNoConvert(UINT32 chan, UINT32 linkDir, UINT32 dir);


UINT32 BspChanLinkInfoInitTddIo( const T_RU_LINK_MAP_TDDIO *pLinkMap, UINT32 linkNum);
UINT32 BspGetBspChnInfoByDifInfo(UINT32 difChipId,UINT32 difChn, UINT32 dir,UINT32 *bspChn);
UINT32 BspGetDifInfoByIoChn(UINT32 ioChn , UINT32 DeslinkPro,T_RU_LINK_MAP_TDDIO_TO_RF *pVal);

UINT32 BspSetChanLinkInfoIoChnToTddIo(T_RU_TDD_MAP_TDDIO *pLinkMap, UINT32 linkNum);
UINT32 BspGetChanLinkInfoIoChnToTddIo(T_RU_TDD_MAP_TDDIO **pptMap, UINT32 *ulpSize);
UINT32 BspGetTddIobyIoChn(UINT32 ioChn, UINT32 DeslinkPro, UINT32 Deslinkinfo, UINT32 *pVal);
UINT32 BspGetFirstBspChanByPwrIdx(UINT32 pwrIdx, UINT32 *bspChan);
UINT32 BspGetPaVoltPwrNum(UINT32 *paVoltNum);

UINT32 BspChanMapPwrIdxInit(T_PWR_MAP_CHAN *pPwrIdxMap);
UINT32 BspGetMSFlagByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *MSFlag);
UINT32 BspChanLinkInfoInitTddIoToRf( const T_RU_LINK_MAP_TDDIO_TO_RF *pLinkMap, UINT32 linkNum);
UINT32 BspGetTrxChipIdAndChanNoByRfChan(UINT32 rfChan, UINT32 dir, UINT32 *mtschip, UINT32 *mtschan);
UINT32 BspGetAmpIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pAmpIo);
UINT32 BspGetWorkAsTypeByTddIoInfo(UINT32 ioChan , UINT32 DeslinkPro, UINT32 *pVal);
UINT32 BspGetRealIoByTddIoInfo(UINT32 tddsel , UINT32 DeslinkPro, UINT32 *pVal);
UINT32 BspGetBaseParaTypeByTddIoInfo(UINT32 tddsel , UINT32 DeslinkPro, UINT32 *pVal);
UINT32 BspGetBspChanByAntAndBandInfo(UINT32 antId, UINT32 bandNo,UINT32 dir,UINT32 *pbspChan);		
UINT32 BspGetAntDetPinIdByAntId(UINT32 antId, UINT32 *pAntDetPinId);
UINT32 BspGetIoProByTddIoInfo(UINT32 ioChan, UINT32 DeslinkPro, UINT32 *pVal);
UINT32 BspGetFbChnInfoByBspChn(UINT32 bspChn,UINT32 *pFbChn);
UINT32 BspGetAntDetPinIdByBspChn(UINT32 bspChn, UINT32 *pAntDetPinId);
UINT32 BspGetAntIdByPortId(UINT32 portId,UINT32 dir, UINT32 *antNum, UINT32 *pAntId);
UINT32 BspGetBspChnByPortId(UINT32 portId,UINT32 dir, UINT32 *chanNum, UINT32 *pBspChn);
UINT32 BspGetAnotherSlaveChnByBspChn(UINT32 bspChn, UINT32 dir, UINT32 *pAnotherChn);
UINT32 BspGetPortSlaveChnByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pSlaveChn);
UINT32 BspGetPortIdByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pPortId);
UINT32 BspGetPortIdByAntId(UINT32 antId,UINT32 dir, UINT32 *pPortId);
UINT32 BspGetBspChnByPaChn(UINT32 paChn, UINT32 dir, UINT32 *bspChn);
UINT32 BspIsRemoteSlaveChan(UINT32 bspChn, UINT32 type);
UINT32 BspSetRailWayAntDuplicationMap(T_RailWayAntDuplicationMap *pAntDupMap, UINT32 duplicationGroupNum);
UINT32 BspGetBspChanFromAntNo(UINT32 antNo);
UINT32 BspGetAntNoFromBspChan(UINT32 bspChan);
UINT32 BspFwdLinkInfoInit(T_RU_LINK_MAP_APP_CFG *pLinkMap, UINT32 linkNum);
T_BspChanAndAntNo * BspGetQcellChanAndAntNoMode(VOID);
UINT32 BspGetRxChByTxChInOneLink(UINT32 rfChTx, UINT32 dir, UINT32 *rfChRx);
UINT32 BspGetTddIdByTxChInOneLink(UINT32 rfChTx, UINT32 dir, UINT32 *tddId);
UINT32 BspGetGroupIdByTxChInOneLink(UINT32 rfChTx, UINT32 dir, UINT32 *groupId);
UINT32 BspGetTrxTypeByTxChAndFwdType(UINT32 rfChTx, UINT32 linkdir, UINT32 *type);
UINT32 testgettrxtype(UINT32 rfCh, UINT32 linkdir);
UINT32 BspGetFwdDirByRfInfo(UINT32 rfCh, UINT32 dir, UINT32 *fwdDir);
UINT32 BspGetRadioModeByFwdInfo(UINT32 chan, UINT32 fwdDir, UINT32 *pVal);
UINT32 BspGetAppCfgMap(T_RU_LINK_MAP_APP_CFG **ppMap, UINT32 *pMapNum);

#ifdef __cplusplus
}
#endif	
#endif //FUNCLIB_CHN_MAP_H_INCLUDED



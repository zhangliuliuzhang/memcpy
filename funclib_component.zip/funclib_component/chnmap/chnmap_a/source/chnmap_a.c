/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : CFR
 * 文件名称 : chnmap.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供funclib模块下chanmap模块的功能实现。
 * 注意事项 : 无
 * 作    者 : wangfei
 * 创建日期 : 2017-03-05 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmap_a.h"
#include "rruinfo.h"
#include "funccommon_carrmap.h"
#include "funccommon_a.h"
#include "exprn.h"
#include "property.h"
#include "ichaladapt_ic4_2.h"
/**************************************************************************
 *                        宏定义
 **************************************************************************/
static UINT32           s_linkNum            = 0;
const T_RU_LINK_MAP    *s_linkMapInfo       = NULL;

UINT32                 g_fwdLinkNum       = 0;
T_RU_LINK_MAP_APP_CFG  *g_fwdLinkMapInfo  = NULL;

static UINT32           s_antNum            = 0;
const T_RU_ANT_DET_MAP    *s_antDetMapInfo       = NULL;

static UINT32              s_linkNumTddIo       = 0;
const T_RU_LINK_MAP_TDDIO    *s_linkMapInfoTddIo = NULL;

static UINT32              s_linkNumTddIoToRf       = 0;
const T_RU_LINK_MAP_TDDIO_TO_RF    *s_linkMapInfoTddIoToRf = NULL;


static UINT32              s_optSwitchNum       = 0;
static T_RU_OPT_SWITCH_MAP *s_pOptSwitchMapInfo = NULL;

static UINT32           s_difChipNum         = 1;/*CPU自己可以控制的中频逻辑芯片数*/
static UINT32           s_difChnNumPerChip   = 8;/*1片逻辑芯片可以控制的中频通道数*/
static UINT32           s_difChnNumTotal     = 0;/*CPU可以控制的中频通道数 = s_difChipNum *s_difChnNumPerChip */
static UINT32           s_difChipNumPerBoard = 1;/*每个单板上的中频逻辑芯片数*/

static T_DifSecMapInfo *s_DifSecMap = NULL;
static UINT32         s_DifSecMapNum  = 0;

static UINT32          s_linkIoChnToTddIoNum     = 0;
T_RU_TDD_MAP_TDDIO    *s_linkMapInfoIoChnToTddIo = NULL;

const T_PWR_MAP_CHAN  *s_pPwrMapChnInfo     = NULL;

static T_RailWayAntDuplicationMap s_antDuplicationMap = {0}; /*保存支持功率共享机型的天线绑定信息*/
static T_BspChanAndAntNo g_tBspChanAndAntNoLinkMap = {0};/* QCELL Mode的一些信息 */
/**************************************************************************
*                         全局变量定义                                   *
**************************************************************************/

/**************************************************************************
*                         数据类型                                       *
**************************************************************************/

/**************************************************************************
 *                         函数实现
 **************************************************************************/
/**************************************************************************
 * 函数名称:BspGetQcellChanAndAntNoMode
 * 功能描述:QCELL Mode的一些信息 用于APP通过天线号获取到BSP通道号
 * 输入参数: VOID
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月06日    wangfei    创建
 **************************************************************************/
T_BspChanAndAntNo * BspGetQcellChanAndAntNoMode(VOID)
{
    return &g_tBspChanAndAntNoLinkMap;
}

/**************************************************************************
 * 函数名称:IntPub_Unit_LinkInfoInit
 * 功能描述:初始化单板Link信息，需要单板初始化时提供
 * 输入参数: pLinkMap:Link Map映射表格
 *           ulLinkNum:Link Map表格长度
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月06日    wangfei    创建
 **************************************************************************/
UINT32 BspChanLinkInfoInit( const T_RU_LINK_MAP *pLinkMap, UINT32 linkNum)
{
    s_linkMapInfo  = (T_RU_LINK_MAP *) pLinkMap;
    s_linkNum      = linkNum;
    return BSP_OK;
}

/* Started by AICoder, pid:l1ebaeafde612631463a09dbe0143c5a53407155 */
/**************************************************************************
 * 函数名称: BspFwdLinkInfoInit
 * 功能描述: 初始化NCR机型射频通道全链路方向
 * 输入参数: pLinkMap:Link Map映射表格
 *           ulLinkNum:Link Map表格长度
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2024年06月20日    陈显宝    创建
 **************************************************************************/
/* Started by AICoder, pid:0256clcd62ia70d142eb0b7d20553e177721b87f */
UINT32 BspFwdLinkInfoInit(T_RU_LINK_MAP_APP_CFG *pLinkMap, UINT32 linkNum)
{
    INPUT_POINTER_CHECK(pLinkMap);

    g_fwdLinkMapInfo  = (T_RU_LINK_MAP_APP_CFG *) pLinkMap;
    g_fwdLinkNum      = linkNum;
    return BSP_OK;
}
/* Ended by AICoder, pid:0256clcd62ia70d142eb0b7d20553e177721b87f */

/**************************************************************************
 * 函数名称: BspGetAppCfgMap
 * 功能描述: APP获取BSP单板映射数组（T_RU_LINK_MAP_APP_CFG），APP构造载波编排信息
 * 输入参数: 无
 * 输出参数: **ppMap：*ppMap指向 T_RU_LINK_MAP_APP_CFG数组第一行
 *           *pMapNum: T_RU_LINK_MAP_APP_CFG数组元素个数
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2024年06月20日    陈显宝    创建
 **************************************************************************/
UINT32 BspGetAppCfgMap(T_RU_LINK_MAP_APP_CFG **ppMap, UINT32 *pMapNum)
{
    INPUT_POINTER_CHECK(ppMap);
    INPUT_POINTER_CHECK(pMapNum);

    *ppMap = g_fwdLinkMapInfo;
    *pMapNum = g_fwdLinkNum;

    return BSP_OK;
}
/* Ended by AICoder, pid:l1ebaeafde612631463a09dbe0143c5a53407155 */

/* Started by AICoder, pid:m4bfam6bdag732414830083e50612e2b86a0d553 */
UINT32 prnfwddir(VOID)
{
    UINT32 loop = 0;
    UINT32 mapNum = 0;
    T_RU_LINK_MAP_APP_CFG *pMap = NULL;

    if(BSP_OK != BspGetAppCfgMap(&pMap, &mapNum))
    {
        return BSP_ERROR;
    }
    dbgInfo("/******%6s, %6s, %6s, %6s******/\n", "rfChan", "fwdDir", "TxRx", "radiomode");

    for(loop = 0; loop < mapNum; loop++)
    {
        dbgInfo("%13d, %6d, %6d, %9d\n", pMap->rfCh,  pMap->fwdType, pMap->trxType, pMap->radioMode);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:m4bfam6bdag732414830083e50612e2b86a0d553 */

/* Started by AICoder, pid:0fc05ff307z6574142ed0b89105b3b3ceea14eeb */
UINT32 BspGetRadioModeByFwdInfo(UINT32 chan, UINT32 fwdDir, UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    T_RU_LINK_MAP_APP_CFG *pMap   = NULL;   

    ret = BspGetAppCfgMap(&pMap, &size);
    dbgInfoEx("[%s] call Bsp Get App Cfg Map ret:%d\n", __FUNCTION__, ret);
    for(idx = 0; idx < size; idx++, pMap++)
    {
        if(pMap->rfCh == chan && pMap->fwdType == fwdDir)
        {
            *pVal = pMap->radioMode;            
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}
/* Ended by AICoder, pid:0fc05ff307z6574142ed0b89105b3b3ceea14eeb */


/**************************************************************************
 * 函数名称:BspAntDetMapInfoInit
 * 功能描述:初始化单板天线号和天馈检测引脚号映射关系，需要单板初始化时提供
 * 输入参数: pMapInfo:ant det映射表格
 *           antNum:天线数
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月06日    wangfei    创建
 **************************************************************************/
UINT32 BspAntDetMapInfoInit( const T_RU_ANT_DET_MAP *pMapInfo, UINT32 antNum)
{
    s_antDetMapInfo  = (T_RU_ANT_DET_MAP *) pMapInfo;
    s_antNum         = antNum;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称:BspChanLinkInfoInitTddIo
 * 功能描述:初始化单板Link信息，需要单板初始化时提供
 * 输入参数: pLinkMap:Link Map映射表格
 *           ulLinkNum:Link Map表格长度
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月06日    wangfei    创建
 **************************************************************************/
UINT32 BspChanLinkInfoInitTddIo( const T_RU_LINK_MAP_TDDIO *pLinkMap, UINT32 linkNum)
{
    s_linkMapInfoTddIo  = pLinkMap;
    s_linkNumTddIo      = linkNum;
    return BSP_OK;
}

UINT32 BspChanLinkInfoInitTddIoToRf( const T_RU_LINK_MAP_TDDIO_TO_RF *pLinkMap, UINT32 linkNum)
{
    s_linkMapInfoTddIoToRf  = pLinkMap;
    s_linkNumTddIoToRf      = linkNum;
    return BSP_OK;
}

UINT32 BspSetChanLinkInfoIoChnToTddIo(T_RU_TDD_MAP_TDDIO *pLinkMap, UINT32 linkNum)
{
    INPUT_POINTER_CHECK(pLinkMap);
    s_linkMapInfoIoChnToTddIo  = (T_RU_TDD_MAP_TDDIO *) pLinkMap;
    s_linkIoChnToTddIoNum      = linkNum;
    return BSP_OK;
}

UINT32 BspGetChanLinkInfoIoChnToTddIo(T_RU_TDD_MAP_TDDIO **pptMap, UINT32 *ulpSize)
{
    INPUT_POINTER_CHECK(pptMap);
    INPUT_POINTER_CHECK(ulpSize);
    *pptMap     = (T_RU_TDD_MAP_TDDIO *)s_linkMapInfoIoChnToTddIo;
    *ulpSize    = s_linkIoChnToTddIoNum;
    if (NULL == (*pptMap))
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspGetTddIobyIoChn(UINT32 ioChn, UINT32 DeslinkPro, UINT32 Deslinkinfo, UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0; 
    T_RU_TDD_MAP_TDDIO *pMap   = NULL; 
    
    INPUT_POINTER_CHECK(pVal);
    if(Deslinkinfo >= TDD_INFO_TYPE_NUM_TDDIO)
    {
        dbgErr("%s: input Deslinkinfo %d out of range\n", __FUNCTION__, Deslinkinfo);
        return BSP_ERROR;
    }
    ret = BspGetChanLinkInfoIoChnToTddIo((T_RU_TDD_MAP_TDDIO**)&pMap, &size);   
    dbgInfoEx("BspGetChanLinkInfoIoChnToTddIo call BspGetTddIobyIoChan ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->TddInfo[TDD_INFO_IOCHN_TDDIO] == ioChn &&
            pMap->TddInfo[TDD_INFO_LINKTYPE_TDDIO] == DeslinkPro)
        {
            *pVal = pMap->TddInfo[Deslinkinfo];
            return BSP_OK;
        }
    }
    if(idx >= size)
    {
        dbgErr("%s: Func Copy Ret Error!\n\n", __FUNCTION__);
    }
    return BSP_ERROR;
}

UINT32 BspChanOptSwitchInfoInit(T_RU_OPT_SWITCH_MAP *pOptSwitchMap, UINT32 OptSwitchNum)
{
    s_pOptSwitchMapInfo = pOptSwitchMap;
    s_optSwitchNum      = OptSwitchNum;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称:IntPub_Unit_GetDifLinkInfo
 * 功能描述:获取link参数信息
 * 输入参数: ulLinkType:想要获取的link类型(_LINK_TYPE_DEF_详见该结构定义，不考虑可以传0)
 *           ulInChnType:输入通道类型
 *           ulInChnNum:输入通道号
 *           *pLinkNum:输入pLinkId能容纳的UINT32个数
 * 输出参数: pLinkId:记录匹配到的LINKID
 *           pLinkNum:记录匹配的LINK个数
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月09日    wangfei    创建
 **************************************************************************/

UINT32 BspGetDifLinkMapInfo(const T_RU_LINK_MAP **pptMap, UINT32 *ulpSize)
{
    INPUT_POINTER_CHECK(pptMap);
    INPUT_POINTER_CHECK(ulpSize);
    *pptMap     = (T_RU_LINK_MAP *)s_linkMapInfo;
    *ulpSize    = s_linkNum;

    if (NULL == (*pptMap))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspGetAntDetMapInfo(const T_RU_ANT_DET_MAP **pptMap, UINT32 *ulpSize)
{
    INPUT_POINTER_CHECK(pptMap);
    INPUT_POINTER_CHECK(ulpSize);
    *pptMap     = (T_RU_ANT_DET_MAP *)s_antDetMapInfo;
    *ulpSize    = s_antNum;

    if (NULL == (*pptMap))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspGetDifLinkMapTddIoInfo(const T_RU_LINK_MAP_TDDIO **pptMap, UINT32 *ulpSize)
{
    INPUT_POINTER_CHECK(pptMap);
    INPUT_POINTER_CHECK(ulpSize);
    *pptMap     = s_linkMapInfoTddIo;
    *ulpSize    = s_linkNumTddIo;
    if (NULL == (*pptMap))
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspGetDifLinkMapTddIoToRfInfo(const T_RU_LINK_MAP_TDDIO_TO_RF **pptMap, UINT32 *ulpSize)
{
    INPUT_POINTER_CHECK(pptMap);
    INPUT_POINTER_CHECK(ulpSize);
    *pptMap     = (T_RU_LINK_MAP_TDDIO_TO_RF *)s_linkMapInfoTddIoToRf;
    *ulpSize    = s_linkNumTddIoToRf;
    if (NULL == (*pptMap))
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspGetDifOptSwitchMapInfo(T_RU_OPT_SWITCH_MAP **pptMap, UINT32 *ulpSize)
{
    INPUT_POINTER_CHECK(pptMap);
    INPUT_POINTER_CHECK(ulpSize);
    *pptMap     = s_pOptSwitchMapInfo;
    *ulpSize    = s_optSwitchNum;

    if (NULL == (*pptMap))
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:BspSetDifChipNum
 * 功能描述:设置本CPU可以操作中频逻辑芯片数
 * 输入参数: difChipNum:芯片数
 * 输出参数:
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月09日    wangfei    创建
 **************************************************************************/


UINT32 BspSetDifChipNum(UINT32 difChipNum)
{
    s_difChipNum = difChipNum;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称:BspGetDifChipNum
 * 功能描述:获取本CPU可以操作中频逻辑芯片数
 * 输入参数: difChipNum:芯片数
 * 输出参数:
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月09日    wangfei    创建
 **************************************************************************/
UINT32 BspGetDifChipNum(VOID)
{
    return s_difChipNum;
}

/**************************************************************************
 * 函数名称:BspSetBoardDifChipNum
 * 功能描述:设置本单板包含的中频逻辑芯片数
 * 输入参数: difChipNum:芯片数
 * 输出参数:
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月09日    wangfei    创建
 **************************************************************************/
UINT32 BspSetBoardDifChipNum(UINT32 difChipNum)
{
    s_difChipNumPerBoard = difChipNum;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称:s_difChipNumPerBoard
 * 功能描述:获取本单板包含的中频逻辑芯片数
 * 输入参数: difChipNum:芯片数
 * 输出参数:
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月09日    wangfei    创建
 **************************************************************************/
UINT32 BspGetBoardDifChipNum(VOID)
{
    return s_difChipNumPerBoard;
}

/**************************************************************************
 * 函数名称:BspSetDifChnPerChip
 * 功能描述:设置1片逻辑芯片可以支持的逻辑通道数
 * 输入参数: difChipNum:芯片数
 * 输出参数:
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2015年10月16日 1232   wangfei    创建
 **************************************************************************/
UINT32 BspSetDifChnNumPerChip(UINT32 difChnNum)
{
    s_difChnNumPerChip = difChnNum;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称:BspGetDifChipTotalNum
 * 功能描述:获取1片逻辑芯片可以支持的逻辑通道数
 * 输入参数: difChipNum:芯片数
 * 输出参数:
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月09日    wangfei    创建
 **************************************************************************/
UINT32 BspGetDifChnNumPerChip(VOID)
{
    return s_difChnNumPerChip;
}
/**************************************************************************
 * 函数名称:BspGetDifChnTotalNum
 * 功能描述:获取本CPU可以操作中频通道数
 * 输入参数: difChipNum:芯片数
 * 输出参数:
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月09日    wangfei    创建
 **************************************************************************/
UINT32 BspGetDifChnTotalNum(VOID)
{
    UINT32 difChnNumPerChip = 0;
    UINT32 difChipNum       = 0;
    difChipNum       = BspGetDifChipNum();
    difChnNumPerChip = BspGetDifChnNumPerChip();
    s_difChnNumTotal = difChipNum * difChnNumPerChip;
    return s_difChnNumTotal;
}

/**************************************************************************
 * 函数名称: BspGetChanLinkNum*(*)
 * 功能描述: 获取link的总行数
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 **************************************************************************/
UINT32 BspGetChanLinkNum()
{
    UINT32 ulLinkCnt=0;
    UINT32 ret = 0;
    T_RU_LINK_MAP *pMap=NULL;
    
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap,&ulLinkCnt);
    if(BSP_ERROR == ret)
    {
        return 0;
    }
	return ulLinkCnt;
}


/**************************************************************************
 * 函数名称: BspGetDifInfoByLinkProp*(*)
 * 功能描述: 根据link属性信息查询所需要属性的信息
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetDifInfoByLinkProp(UINT32 linkProp,UINT32 proVal , UINT32 dir, UINT32 DeslinkPro,UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    T_RU_LINK_MAP *pMap   = NULL;   
    
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->linkInfo[linkProp] == proVal &&
            pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
        {
            *pVal = pMap->linkInfo[DeslinkPro];            
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称: BspGetDifInfoByLinkPropInfo*(*)
 * 功能描述: 根据link属性信息查询所需要属性的信息
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
static UINT32 BspGetDifInfoByLinkPropInfo(UINT32 chipID,UINT32 linkProp,UINT32 proVal , UINT32 dir, UINT32 DeslinkPro,UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const  T_RU_LINK_MAP *pMap   = NULL;
    
    ret = BspGetDifLinkMapInfo(&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->linkInfo[linkProp] == proVal &&
            pMap->linkInfo[LINK_INFO_LINKTYPE] == dir&&pMap->linkInfo[LINK_INFO_DIFCHIPID] == chipID)
        {
            *pVal = pMap->linkInfo[DeslinkPro];            
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}


/**************************************************************************
 * 函数名称: BspGetDifInfoByLinkPropTddIo*(*)
 * 功能描述: 根据link属性信息查询所需要属性的信息 针对IC4新增结构体
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日     创建
 **************************************************************************/
static UINT32 BspGetDifInfoByLinkPropTddIo(UINT32 linkProp,UINT32 proVal , UINT32 dir, UINT32 DeslinkPro,UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0; 
    const  T_RU_LINK_MAP_TDDIO *pMap   = NULL;
    
    INPUT_POINTER_CHECK(pVal);
    ret = BspGetDifLinkMapTddIoInfo(&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->linkInfo[linkProp] == proVal &&
            pMap->linkInfo[LINK_INFO_LINKTYPE_TDDIO] == dir)
        {
            *pVal = pMap->linkInfo[DeslinkPro];            
            return BSP_OK;
        }
    }
    if(idx >= size)
    {
        dbgInfoEx("%s: Func Copy Ret Error!\n\n", __FUNCTION__);
    }
    return BSP_ERROR;
}

UINT32 BspGetDifInfoByIoChn(UINT32 ioChn , UINT32 DeslinkPro,T_RU_LINK_MAP_TDDIO_TO_RF *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0; 
    const  T_RU_LINK_MAP_TDDIO_TO_RF *pMap   = NULL;

    INPUT_POINTER_CHECK(pVal);
    ret = BspGetDifLinkMapTddIoToRfInfo(&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->tddIoNo == ioChn &&
            pMap->linkType == DeslinkPro)
        {
            memcpy_s(pVal, sizeof(T_RU_LINK_MAP_TDDIO_TO_RF), pMap, sizeof(T_RU_LINK_MAP_TDDIO_TO_RF));
            return BSP_OK;
        }
    }
    if(idx >= size)
    {
        dbgInfoEx("%s: Func Copy Ret Error!\n\n", __FUNCTION__);
    }
    return BSP_ERROR;
}

UINT32 BspGetBaseParaTypeByTddIoInfo(UINT32 tddsel , UINT32 DeslinkPro, UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP_TDDIO_TO_RF *pMap   = NULL;

    INPUT_POINTER_CHECK(pVal);
    ret = BspGetDifLinkMapTddIoToRfInfo((const T_RU_LINK_MAP_TDDIO_TO_RF**)&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->tddNo == tddsel &&
            pMap->linkType == DeslinkPro)
        {
            *pVal =  pMap->baseOn;
            return BSP_OK;
        }
    }
    if(idx >= size)
    {
        dbgInfoEx("%s: Func Copy Ret Error!\n\n", __FUNCTION__);
    }
    return BSP_ERROR;
}
UINT32 BspGetWorkAsTypeByTddIoInfo(UINT32 ioChan , UINT32 DeslinkPro, UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP_TDDIO_TO_RF *pMap   = NULL;

    INPUT_POINTER_CHECK(pVal);
    ret = BspGetDifLinkMapTddIoToRfInfo((const T_RU_LINK_MAP_TDDIO_TO_RF**)&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->tddIoNo == ioChan &&
            pMap->linkType == DeslinkPro)
        {
            *pVal =  pMap->workAs;
            return BSP_OK;
        }
    }
    if(idx >= size)
    {
        dbgInfoEx("%s: Func Copy Ret Error!\n\n", __FUNCTION__);
    }
    return BSP_ERROR;
}

UINT32 BspGetRealTddNoByTddIoInfo(UINT32 ioChan , UINT32 DeslinkPro, UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP_TDDIO_TO_RF *pMap   = NULL;

    INPUT_POINTER_CHECK(pVal);
    ret = BspGetDifLinkMapTddIoToRfInfo((const T_RU_LINK_MAP_TDDIO_TO_RF**)&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->tddIoNo == ioChan &&
            pMap->linkType == DeslinkPro)
        {
            *pVal =  pMap->tddNo;
            return BSP_OK;
        }
    }
    if(idx >= size)
    {
        dbgInfoEx("%s: Func Copy Ret Error!\n\n", __FUNCTION__);
    }
    return BSP_ERROR;
}
UINT32 BspGetIoProByTddIoInfo(UINT32 ioChan , UINT32 DeslinkPro, UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP_TDDIO_TO_RF *pMap   = NULL;

    INPUT_POINTER_CHECK(pVal);
    ret = BspGetDifLinkMapTddIoToRfInfo((const T_RU_LINK_MAP_TDDIO_TO_RF**)&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->tddIoNo == ioChan &&
            pMap->linkType == DeslinkPro)
        {
            *pVal =  pMap->rfChanPro;
            return BSP_OK;
        }
    }
    if(idx >= size)
    {
        dbgInfoEx("%s: Func Copy Ret Error!\n\n", __FUNCTION__);
    }
    return BSP_ERROR;
}

static UINT32 BspGetDifInfoByOptSwitchProp(UINT32 srcProp, UINT32 proVal, UINT32 desProp,UINT32 *pVal)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    T_RU_OPT_SWITCH_MAP *pMap   = NULL;   
    
    ret = BspGetDifOptSwitchMapInfo(&pMap, &size);
    dbgInfoEx("BspGetDifInfoByOptSwitchProp call BspGetDifOptSwitchMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->optSwitchInfo[srcProp] == proVal)
        {
            *pVal = pMap->optSwitchInfo[desProp];
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}



UINT32 BspGetI2cOptStatus()
{
    UINT32 ret = BSP_OK;
    return ret ;
}

UINT32 BspGetEpldIdByOptId(UINT32 OptId, UINT32 *pEpldId)
{
    /* UINT32 ret = BSP_OK; */
    if(NULL == pEpldId)
    {
        return BSP_ERROR;
    }
    return BspGetDifInfoByOptSwitchProp(OPT_SWITCH_INFO_BSP_OPT_ID, OptId, OPT_SWITCH_INFO_EPLD_ID, pEpldId);
    //return BSP_OK;
}

UINT32 BspGetSfpIdByOptId(UINT32 OptId, UINT32 *pSfpId)
{
	/* UINT32 ret = BSP_OK; */
    if(NULL == pSfpId)
    {
        return BSP_ERROR;
    }
	
    return BspGetDifInfoByOptSwitchProp(OPT_SWITCH_INFO_BSP_OPT_ID, OptId, OPT_SWITCH_INFO_SFP_ID, pSfpId);
}

/***************************************
 *  函数名称: BspGetOptNumBySfpId
 *  功能描述: 根据sfp索引获取当前光模块有几个光口 (QSFP：4, SFP及其他: 1)
 *  入参说明:
 *  返 回 值:
 *  其它说明:
-------------------------------------------------------------------------
 *  历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), dumin10126090@2018-2-3, 创建
-------------------------------------------------------------------------*/
UINT32 BspGetOptNumBySfpId(UINT32 sfpId)
{
	UINT32 ulGetSfpType = E_SFP;
	UINT32 ulDsfpDefine = E_DSFP;
	UINT32 ulQsfpDefine = E_QSFP;

	ulGetSfpType = BspGetSfpTypeBySfpId(sfpId);
    if(ulQsfpDefine == ulGetSfpType)
	{
		return 4;
	}
    if(ulDsfpDefine == ulGetSfpType)
	{
		return 2;
	}
	else 
	{
		return 1;
	}
}

UINT32 BspGetAddrOffsetByOptId(UINT32 OptId, UINT32 *pOffSet)
{
    /* UINT32 ret = BSP_OK; */
    if(NULL == pOffSet)
    {
        return BSP_ERROR;
    }
    return BspGetDifInfoByOptSwitchProp(OPT_SWITCH_INFO_BSP_OPT_ID, OptId, OPT_SWITCH_INFO_BBFPGA_ID, pOffSet);
    //return BSP_OK;
}

UINT32 BspGetBbFpgaOptIdByOptId(UINT32 OptId, UINT32 *pBbFpgaOpt)
{
    /* UINT32 ret = BSP_OK; */
    if(NULL == pBbFpgaOpt)
    {
        return BSP_ERROR;
    }
    return BspGetDifInfoByOptSwitchProp(OPT_SWITCH_INFO_BSP_OPT_ID, OptId, OPT_SWITCH_INFO_LOGIC_OPT_ID, pBbFpgaOpt);
    //return BSP_OK;
}

UINT32 BspGetMaxOptNum(VOID)
{
    return s_optSwitchNum;
}

/**************************************************************************
 * 函数名称: BspGetBandMaskByBspChn*(*)
 * 功能描述: 根据BSP通道号属性信息查询芯片号以及频段掩码
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 *
 **************************************************************************/
UINT32 BspGetBandMaskByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *chipId, UINT32 *bandMask)
{
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(bandMask);
    INPUT_POINTER_CHECK(chipId);

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN, bspChn, linkType, LINK_INFO_DIFCHIPID, chipId);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN, bspChn, linkType, LINK_BAND_MASK, bandMask);

    if((BSP_OK != ret)&&(dir == RX))
    {
        linkType = LINK_TYPE_RX_S_Div;
        ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN, bspChn, linkType, LINK_INFO_DIFCHIPID, chipId);
        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN, bspChn, linkType, LINK_BAND_MASK, bandMask);
    }

    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetDifInfoByBspChn*(*)
 * 功能描述: 根据BSP通道号属性信息查询芯片号以及中频通道
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetDifInfoByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pdifChipId, UINT32 *pdifChan)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pdifChan);
    INPUT_POINTER_CHECK(pdifChipId);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHIPID,pdifChipId);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHN,pdifChan);
    if((BSP_OK != ret)&&(dir == RX))
	{
    	linkType = LINK_TYPE_RX_S_Div;
        ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHIPID,pdifChipId);
        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHN,pdifChan);
	}

    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetBspChnByDifChn*(*)
 * 功能描述: 根据中频通道号属性信息查询BSP通道
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2025年07月29日 10293411    创建
 **************************************************************************/
UINT32 BspGetBspChnByDifChn(UINT32 difChn,UINT32 dir, UINT32 *BspChn)
{
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(BspChn);

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_DIFCHN,difChn,linkType,LINK_INFO_BSPCHN,BspChn);

    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetMSFlagByBspChn*(*)
 * 功能描述: 根据BSP通道号属性信息查询主分集标志
 * 输入参数: 无
 * 输出参数:MSFlag:0主集；其他分集
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetMSFlagByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *MSFlag)
{       
    UINT32 ret = BSP_OK;
	
    INPUT_POINTER_CHECK(MSFlag);
	
    if(RX == dir)
    { 
        *MSFlag = bspChn/BspGetTxChannel();
	}
	else 
	{
	    *MSFlag = 0;
	}
    return ret ;
}


/**************************************************************************
 * 函数名称: BspGetPaChnByRfChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetPaChnByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *paChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(paChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_PACHN,paChn);
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetPaChnByBspChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetPaInfoByBspChn(UINT32 bspChn,UINT32 dir,UINT32*paId, UINT32 *paChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(paId);
    INPUT_POINTER_CHECK(paChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_PAID,paId);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_PACHN,paChn);
	if((BSP_OK != ret)&&(dir == RX))
	{
    	linkType = LINK_TYPE_RX_S_Div;
        ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_PAID,paId);
        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_PACHN,paChn);
	}
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetBspChnByPaInfo(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetBspChnByPaInfo(UINT32 paId, UINT32 paChn, UINT32*bspChn)
{       
    UINT32 paIdTmp  = 0;
	UINT32 paChnTmp = 0;
	UINT32 uIdx     = 0;
	UINT32 uMaxChn  = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(bspChn);
	uMaxChn = BspGetTxChannel();

	for(uIdx = 0; uIdx < uMaxChn; uIdx++)
	{
        ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,uIdx,TX,LINK_INFO_PAID,&paIdTmp);
		if((BSP_OK != ret)||(paId != paIdTmp))
		{
            continue;
		}
        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,uIdx,TX,LINK_INFO_PACHN,&paChnTmp);
		if((BSP_OK != ret)||(paChn != paChnTmp))
		{
    		continue;
		}
		break;
	}
	if(uIdx<uMaxChn)
	{
        *bspChn  = uIdx;
	}
	else
	{
	    *bspChn = 0;
        ret = BSP_ERROR;
	}
    return ret ;
}




/**************************************************************************
 * 函数名称: BspGetPaChnByCaliChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetPaInfoByCaliChn(UINT32 caliChn,UINT32 dir,UINT32*paId, UINT32 *paChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(paId);
    INPUT_POINTER_CHECK(paChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_CALICHN,caliChn,linkType,LINK_INFO_PAID,paId);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_CALICHN,caliChn,linkType,LINK_INFO_PACHN,paChn);
    return ret ;
}



/**************************************************************************
 * 函数名称: BspGetPaChnByBspChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetPaChnByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *paChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(paChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_PACHN,paChn);
    return ret ;
}


/**************************************************************************
 * 函数名称: BspGetBspChnByPaChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetBspChnByPaChn(UINT32 paChn,UINT32 dir, UINT32 *bspChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(bspChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_PACHN,paChn,linkType,LINK_INFO_BSPCHN,bspChn);
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetPaChnByCaliChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetPaChnByCaliChn(UINT32 caliChn,UINT32 dir, UINT32 *paChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(paChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_CALICHN,caliChn,linkType,LINK_INFO_PACHN,paChn);
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetCaliChnByRfChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetCaliChnByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pCaliChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pCaliChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_CALICHN,pCaliChn);
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetBspChnByCaliChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetBspChnByCaliChn(UINT32 caliChn,UINT32 dir, UINT32 *pBspChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pBspChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_CALICHN,caliChn,linkType,LINK_INFO_BSPCHN,pBspChn);
    return ret ;
}


/**************************************************************************
 * 函数名称: BspGetDivCaliChnByBspChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetDivCaliChnByBspChn(UINT32 bspchn,UINT32 dir, UINT32 *pCaliChn)
{       
    UINT32 linkType = 0;
	UINT32 msFlag   = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pCaliChn);
	BspGetMSFlagByBspChn(bspchn,dir,&msFlag);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        if(0==msFlag)
        {
            linkType = LINK_TYPE_RX;
		}
		else
		{
           linkType = LINK_TYPE_RX_S_Div;
		}
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspchn,linkType,LINK_INFO_CALICHN,pCaliChn);
    return ret ;
}


/**************************************************************************
 * 函数名称: BspGetCaliChnByBspChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetCaliChnByBspChn(UINT32 bspchn,UINT32 dir, UINT32 *pCaliChn)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pCaliChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspchn,linkType,LINK_INFO_CALICHN,pCaliChn);
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetRfChnByBspChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:对高层接口全部是以射频通道号,BSP内部接口都按照BSP通道号。
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetRfChnByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pRfChn)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pRfChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_RFCHN,pRfChn);    
    return ret ;
}


/**************************************************************************
 * 函数名称: BspGetBspChnByRfChn*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:对高层接口全部是以射频通道号,BSP内部接口都按照BSP通道号。
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetBspChnByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pBspChn)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pBspChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_BSPCHN,pBspChn);    
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetBspChnByRfChn*(*)
 * 功能描述: 根据高层射频通道号属性信息查询BSP通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:对高层接口全部是以射频通道号,BSP内部接口都按照BSP通道号。
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetDifInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pdifChipId, UINT32 *pdifChan)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    UINT32 bspChn = 0;
    INPUT_POINTER_CHECK(pdifChipId);
    INPUT_POINTER_CHECK(pdifChan);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_BSPCHN,&bspChn);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHIPID,pdifChipId);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHN,pdifChan);
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetDifInfoByAntId*(*)
 * 功能描述: 通过天线号查找射频通道信息.
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetDifInfoByAntId(UINT32 antId,UINT32 dir, UINT32 *pdifChipId, UINT32 *pdifChan)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    UINT32 bspChn = 0;
    INPUT_POINTER_CHECK(pdifChipId);
    INPUT_POINTER_CHECK(pdifChan);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_ANTID,antId,linkType,LINK_INFO_BSPCHN,&bspChn);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHIPID,pdifChipId);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,linkType,LINK_INFO_DIFCHN,pdifChan);
    return ret ;
}

//通过天线号和频段号查找中频通道信息: antId天线号,antChnl频段号(天线组)
UINT32 BspGetDifInfoByAntInfo(UINT32 antId, UINT32 antChnl,UINT32 dir,UINT32 *pdifChipId, UINT32 *pdifChan)
{
    //UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    UINT32 idx  = 0;
    UINT32 size = 0;
    const  T_RU_LINK_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pdifChipId);
    INPUT_POINTER_CHECK(pdifChan);

#if 0 //linkType没有用到，消告警注掉这几行代码
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
#endif
    ret = BspGetDifLinkMapInfo(&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        if (pMap->linkInfo[LINK_INFO_ANTID]  == antId &&
            pMap->linkInfo[LINK_INFO_ANTCHN] == antChnl &&
            pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
        {
            *pdifChipId = pMap->linkInfo[LINK_INFO_DIFCHIPID];
            *pdifChan   = pMap->linkInfo[LINK_INFO_DIFCHN];
            dbgInfoEx("%s>> antId'%d, antChnl'%d, difChipId=%d, difChan=%d\n",__FUNCTION__,antId,antChnl,*pdifChipId,*pdifChan);
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

//通过天线号和频段号查找Bsp通道信息: antId天线号,bandNo频段号
UINT32 BspGetBspChanByAntAndBandInfo(UINT32 antId, UINT32 bandNo,UINT32 dir,UINT32 *pbspChan)
{
    //UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    UINT32 idx  = 0;
    UINT32 size = 0;
    UINT32 bandMask = 0;
    const  T_RU_LINK_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pbspChan);

    ret = BspGetDifLinkMapInfo(&pMap, &size);
    dbgInfoEx("BspGetDifInfoByLinkProp call BspGetDifLinkMapInfo ret:%#x\n", ret);
    for (idx = 0; idx < size; idx++, pMap++)
    {
        bandMask = pMap->linkInfo[LINK_BAND_MASK];
        if(bandMask == 0)
        {
            bandMask = 1;
        }
        if ((pMap->linkInfo[LINK_INFO_ANTID]  == antId) &&
            (bandMask & BIT_SET(bandNo)) &&
            (pMap->linkInfo[LINK_INFO_LINKTYPE] == dir))
        {
            *pbspChan = pMap->linkInfo[LINK_INFO_BSPCHN];
            dbgInfoEx("%s>> antId'%d, bandNo'%d, pbspChan=%d, bandMask=%d\n",__FUNCTION__,antId,bandNo,*pbspChan,bandMask);
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}


/**************************************************************************
 * 函数名称: BspGetRfChanByBandId(*)
 * 功能描述: 通过频段号查找天线通道.
 * 输入参数: bandId
 * 输出参数: 无
 * 返 回 值: 天线通道
 * 其它说明: 目前bandId = antChn,预留该接口
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
 UINT32 BspGetAntChnByBandId(UINT32 bandId)
 {
     return bandId;
 }

/**************************************************************************
 * 函数名称: BspGetBandIdByAntInfo(*)
 * 功能描述: 通过天线信息查找频段号.
 * 输入参数: bandId
 * 输出参数: 无
 * 返 回 值: 天线通道
 * 其它说明: 目前bandId = antChn,预留该接口
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
 UINT32 BspGetBandIdByAntInfo(UINT32 antId, UINT32 antChn)
 {
     return antChn;
 }

/**************************************************************************
 * 函数名称: BspGetBspChnByAntInfo(*)
 * 功能描述: 通过天线号查找射频通道信息.
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetBspChanByAntInfo(UINT32 antId,UINT32 bandId, UINT32 dir, UINT32 *pBspChan)
{   
    UINT32 idx = 0;
    UINT32 ret = BSP_OK;
    UINT32 antChn = 0;
    UINT32 size   = 0;
    const T_RU_LINK_MAP *pMap = NULL;

    INPUT_POINTER_CHECK(pBspChan);
    antChn = BspGetAntChnByBandId(bandId);
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap, &size);
    dbgInfoEx("BspGetDifLinkMapInfop ret = %d\n", ret);
    for (idx = 0; idx <size; idx++,pMap++)
    {
        if (pMap->linkInfo[LINK_INFO_ANTID]  == antId &&
            pMap->linkInfo[LINK_INFO_ANTCHN] == antChn &&
            pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
        {
            *pBspChan = pMap->linkInfo[LINK_INFO_BSPCHN];
            dbgInfoEx("%s >> antId = %d, antChn = %d, bspChn = %d\n", __FUNCTION__,antId, antChn, *pBspChan);
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称: BspGetRfChanByAntId*(*)
 * 功能描述: 通过天线号查找射频通道信息.
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetRfChanByAntId(UINT32 antId,UINT32 bandId, UINT32 dir, UINT32 *pRfChan)
{
    UINT32 ret = BSP_OK;
    UINT32 idx    = 0;
    UINT32 size   = 0;
    UINT32 antChn = 0;
    const T_RU_LINK_MAP *pMap = NULL;

    INPUT_POINTER_CHECK(pRfChan);
    antChn = BspGetAntChnByBandId(bandId);
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap, &size);
    dbgInfoEx("BspGetDifLinkMapInfop ret = %d\n", ret);
    for (idx = 0; idx <size; idx++,pMap++)
    {
        if (pMap->linkInfo[LINK_INFO_ANTID]  == antId &&
            pMap->linkInfo[LINK_INFO_ANTCHN] == antChn &&
            pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
        {
            *pRfChan = pMap->linkInfo[LINK_INFO_RFCHN];
            dbgInfoEx("%s >> antId = %d, bandId = %d, rfCChn = %d\n", __FUNCTION__,antId, bandId, *pRfChan);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称: BspGetRfChnInfoByDifChn*(*)
 * 功能描述: 根据中频通道查询射频通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:对高层接口全部是以射频通道号,BSP内部接口都按照BSP通道号。
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetRfChnInfoByDifChn(UINT32 difChn,UINT32 dir, UINT32 *pRfChn)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pRfChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_DIFCHN,difChn,linkType,LINK_INFO_RFCHN,pRfChn);    
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetBspChnInfoByDifChn*(*)
 * 功能描述: 根据中频通道查询BSP通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年07月07日 xx 创建
 **************************************************************************/
UINT32 BspGetBspChnInfoByDifChn(UINT32 difChn, UINT32 dir,UINT32 *bspChn)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(bspChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    else if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkProp(LINK_INFO_DIFCHN, difChn, linkType, LINK_INFO_BSPCHN, bspChn);    
    return ret;
}

/**************************************************************************
 * 函数名称: BspGetRfChnInfoByDifInfo*(*)
 * 功能描述: 根据中频通道和中频芯片id查询射频通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:对高层接口全部是以射频通道号,BSP内部接口都按照BSP通道号。
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetRfChnInfoByDifInfo(UINT32 difChipId,UINT32 difChn,UINT32 dir, UINT32 *pRfChn)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pRfChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkPropInfo(difChipId,LINK_INFO_DIFCHN,difChn,linkType,LINK_INFO_RFCHN,pRfChn);    
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetBspChnInfoByDifInfo*(*)
 * 功能描述: 根据中频通道和中频芯片id查询BSP通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年07月07日 xx 创建
 **************************************************************************/
UINT32 BspGetBspChnInfoByDifInfo(UINT32 difChipId,UINT32 difChn, UINT32 dir,UINT32 *bspChn)
{   
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(bspChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    else if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret = BspGetDifInfoByLinkPropInfo(difChipId,LINK_INFO_DIFCHN, difChn, linkType, LINK_INFO_BSPCHN, bspChn);    
    return ret;
}



/**************************************************************************
 * 函数名称: BspGetRfChnInfoByDifChn*(*)
 * 功能描述: 根据中频通道查询射频通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:对高层接口全部是以射频通道号,BSP内部接口都按照BSP通道号。
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetFbChnInfoByRfChn(UINT32 rfChn,UINT32 *pFbChn)
{   
    /* UINT32 linkType = 0; */
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pFbChn);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,LINK_TYPE_TX,LINK_INFO_FBCH,pFbChn);    
    return ret ;
}

/**************************************************************************
 * 函数名称: BspGetRfChnInfoByDifChn*(*)
 * 功能描述: 根据中频通道查询射频通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:对高层接口全部是以射频通道号,BSP内部接口都按照BSP通道号。
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetFbChnInfoByBspChn(UINT32 bspChn,UINT32 *pFbChn)
{   
    /* UINT32 linkType = 0; */
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pFbChn);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,bspChn,LINK_TYPE_TX,LINK_INFO_FBCH,pFbChn);    
    return ret ;
}

UINT32 BspGetLinkInfoByLinkId(UINT32 linkId, UINT32 inChnInfo,UINT32 *pChn)
{
    UINT32 loop = 0;
    UINT32 linkNum = 0;
    UINT32 ret = 0;
    T_RU_LINK_MAP *pMap = NULL;
    
    INPUT_POINTER_CHECK(pChn);
    
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap,&linkNum);
    if(BSP_ERROR==ret)
    {
        return BSP_ERROR;
    }
	if(inChnInfo>=LINK_INFO_TYPE_NUM)
	{
	    dbgErr("ulInChnType = %d,LINK_INFO_TYPE_NUM = %d\n",inChnInfo,LINK_INFO_TYPE_NUM);
	    dbgErr("%s InValid Input Para\n",__FUNCTION__);
        return BSP_ERROR;
	}
	for(loop = 0; loop < linkNum; loop++)
	{
        if(linkId == pMap[loop].linkInfo[LINK_INFO_LINKID])
        {
            *pChn = pMap[loop].linkInfo[inChnInfo];
			return BSP_OK;
		}
	}
	return BSP_ERROR;

}

UINT32 BspGetLinkInfoByLinkType(UINT32 linkType, UINT32 inChnType,ULONG inChnNum,UINT32 *pLinkId,UINT32 *pLinkNum)
{
    UINT32 linkNum    = 0;
    UINT32 loop       = 0;
    UINT32 typeIdx    = 0;
    UINT32 chnType    = 0;
    UINT32 flag       = 0;
	UINT32 aRxChnType[LINK_TYPE_TYPE_NUM] = {0};
    UINT32 cnt=0;
    UINT32 ret=0;
    UINT32 inChnVal = 0;
    T_RU_LINK_MAP *pMap = NULL;
    
    INPUT_POINTER_CHECK(pLinkId);
    INPUT_POINTER_CHECK(pLinkNum);
    
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap,&linkNum);
    if(BSP_ERROR == ret)
    {
        return BSP_ERROR;
    }

	if((linkType >= LINK_TYPE_TYPE_NUM)||(inChnType >= LINK_INFO_TYPE_NUM))
	{
	    dbgErr("ulLinkType  = %d,LINK_TYPE_TYPE_NUM = %d\n",linkType,LINK_TYPE_TYPE_NUM);
	    dbgErr("ulInChnType = %d,LINK_INFO_TYPE_NUM = %d\n",inChnType,LINK_INFO_TYPE_NUM);
	    dbgErr("%s InValid Input Para\n",__FUNCTION__);
        return BSP_ERROR;
	}
	chnType     = 0;
	switch(linkType)
	{
        case LINK_TYPE_TX:
		case LINK_TYPE_RX_M:
		case LINK_TYPE_RX_S:
			aRxChnType[0] = linkType;
			chnType     = 1;
			break;
		case LINK_TYPE_RX:   
			chnType	  = 2;
            
            /* 仅传入Rx通道号，会找到主分集 */
			aRxChnType[0] = LINK_TYPE_RX_M;
			/* 交叉分集情况下,接收通道类型有变化 */
			aRxChnType[1] = LINK_TYPE_RX_S;
			break;
		default :
			chnType	  = 0;
			break;
	}

	for(loop = 0; loop < linkNum; loop++)
	{
	    flag = 0;
	    for(typeIdx = 0; typeIdx < chnType; typeIdx++)
	    {
            if(aRxChnType[typeIdx]==pMap[loop].linkInfo[LINK_INFO_LINKTYPE])
            {
                flag = 1;
				break;
			}
		}
		if(flag)
		{
            inChnVal = pMap[loop].linkInfo[inChnType];
            if(inChnVal == inChnNum)
            {
                if(cnt < *pLinkNum)
                {
					pLinkId[cnt] = 
                        pMap[loop].linkInfo[LINK_INFO_LINKID];
				}
				cnt++;
			}
		}

	}
	if(cnt>*pLinkNum)
	{
        dbgInfo("%s find Link Num %d more than %d,out range\n",__FUNCTION__, cnt, *pLinkNum);
		return BSP_ERROR;
	}
	else
	{
        *pLinkNum = cnt;
	}
	return BSP_OK;
}



UINT32 BspGetAntInfoByRfChn(UINT32 rfChn,UINT32 dir,UINT32 *antId,UINT32 *antChn)
{
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(antId);
    INPUT_POINTER_CHECK(antChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_ANTID,antId);    
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_ANTCHN,antChn);
    return ret ;
}

UINT32 BspGetAntInfoByBspChn(UINT32 Chn,UINT32 dir,UINT32 *antId,UINT32 *antChn)
{
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    UINT32 msFlag   = 0;
    INPUT_POINTER_CHECK(antId);
    INPUT_POINTER_CHECK(antChn);

    BspGetMSFlagByBspChn(Chn,dir,&msFlag);

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;

        /*解决R9222配置交叉分集下，rssi补偿tma异常问题*/
        if((SWITCH_ON == BspGetDivFlag()) && (0 != msFlag))
        {
        	linkType = LINK_TYPE_RX_S_Div;
        }
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTID,antId);    
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTCHN,antChn);

    if((BSP_OK != ret)&&(dir == RX))
    {
    	/*有些单板找不到LINK_TYPE_RX_S_Div*/
    	ret = BSP_OK;
    	linkType = LINK_TYPE_RX;

        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTID,antId);
        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTCHN,antChn);
    }

    return ret ;
}

UINT32 BspGetAntInfoByBspChnAndMode(UINT32 Chn,UINT32 dir, UINT32 ulRadioMode, UINT32 *antId,UINT32 *antChn)
{
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    UINT32 msFlag   = 0;
    INPUT_POINTER_CHECK(antId);
    INPUT_POINTER_CHECK(antChn);

    BspGetMSFlagByBspChn(Chn,dir,&msFlag);

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;

        /*解决R9222配置交叉分集下，rssi补偿tma异常问题*/
        if((SWITCH_ON == BspGetDivFlag()) && (0 != msFlag))
        {
        	linkType = LINK_TYPE_RX_S_Div;
        }
        if((ulRadioMode==BSP_RADIO_STANDARD_5G) || (ulRadioMode==BSP_RADIO_STANDARD_LTE_FDD) || (ulRadioMode==BSP_RADIO_STANDARD_NB_IOT))
        {
        	linkType = LINK_TYPE_RX;
        }
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTID,antId);
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTCHN,antChn);

    if((BSP_OK != ret)&&(dir == RX))
    {
    	/*有些单板找不到LINK_TYPE_RX_S_Div*/
    	ret = BSP_OK;
    	linkType = LINK_TYPE_RX;

        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTID,antId);
        ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_ANTCHN,antChn);
    }

    return ret ;
}


UINT32 BspGetDflInfoByRfChn(UINT32 rfChn,UINT32 dir,UINT32 *dflId,UINT32 *dflChn)
{
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(dflId);
    INPUT_POINTER_CHECK(dflChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_DFLID,dflId);    
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_RFCHN,rfChn,linkType,LINK_INFO_DFLCHN,dflChn);
    return ret ;
}

UINT32 BspGetDflInfoByBspChn(UINT32 Chn,UINT32 dir,UINT32 *dflId,UINT32 *dflChn)
{
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(dflId);
    INPUT_POINTER_CHECK(dflChn);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_DFLID,dflId);    
    ret |= BspGetDifInfoByLinkProp(LINK_INFO_BSPCHN,Chn,linkType,LINK_INFO_DFLCHN,dflChn);
    return ret ;
}

UINT32 BspGetRxDifChanSecMap(UINT32 rfChan,UINT32 carrMode, UINT32 *difsecchan)
{
    UINT32 i = 0;
    UINT32 mapval = ERROR_NULL_POINTER;    
  
    INPUT_POINTER_CHECK(difsecchan);    
    INPUT_POINTER_CHECK(s_DifSecMap);

    if((carrMode == BSP_RADIO_STANDARD_LTE_FDD) ||(carrMode == BSP_RADIO_STANDARD_5G))
    {
        for(i = 0;i<s_DifSecMapNum;i++)       
        {    
            if((s_DifSecMap[i]).rfchan == rfChan)
            {
                *difsecchan = (s_DifSecMap[i]).difsecchan;
                return BSP_OK;
            }
        }
    }

    return mapval;    
}


/**************************************************************************
 * 函数名称: BspGetDifInfoByAntId*(*)
 * 功能描述: 通过天线号查找射频通道信息.
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetBspChnByAntId(UINT32 antId,UINT32 dir, UINT32 *channum, UINT32 *pbspchan)
{   
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    T_RU_LINK_MAP *pMap   = NULL;  

    INPUT_POINTER_CHECK(channum);
    INPUT_POINTER_CHECK(pbspchan); 
    
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap, &size);
    if(BSP_ERROR != ret)
    {
        for (idx = 0; idx < size; idx++, pMap++)
        {
            if (pMap->linkInfo[LINK_INFO_ANTID] == antId &&
                pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
            {
                *(pbspchan++) = pMap->linkInfo[LINK_INFO_BSPCHN];  
                *channum = *channum+1;
                if(*channum >= BSP_MAX_TX_CHAN)
                {
                    break;
                }
            }
        }
    }

    if(*channum > 0 )
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}

UINT32 BspGetPortIdByAntId(UINT32 antId,UINT32 dir, UINT32 *pPortId)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pPortId);

    ret = BspGetDifLinkMapInfo(&pMap, &size);
    if(BSP_ERROR != ret)
    {
        for (idx = 0; idx < size; idx++, pMap++)
        {
            if (pMap->linkInfo[LINK_INFO_ANTID] == antId &&
                pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
            {
                *pPortId = pMap->linkInfo[LINK_INFO_PORTID];
                break;
            }
        }
    }

    if(idx == size)
    {
        return BSP_ERROR;
    }
    else
    {
        return BSP_OK;
    }
}

UINT32 BspGetPortIdByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pPortId)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pPortId);

    ret = BspGetDifLinkMapInfo(&pMap, &size);
    if(BSP_ERROR != ret)
    {
        for (idx = 0; idx < size; idx++, pMap++)
        {
            if (pMap->linkInfo[LINK_INFO_BSPCHN] == bspChn &&
                pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
            {
                *pPortId = pMap->linkInfo[LINK_INFO_PORTID];
                break;
            }
        }
    }

    if(idx == size)
    {
        return BSP_ERROR;
    }
    else
    {
        return BSP_OK;
    }
}

UINT32 BspGetBspChnByPortId(UINT32 portId,UINT32 dir, UINT32 *chanNum, UINT32 *pBspChn)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pBspChn);
    INPUT_POINTER_CHECK(chanNum);

    ret = BspGetDifLinkMapInfo(&pMap, &size);
    if(BSP_ERROR != ret)
    {
        for (idx = 0; idx < size; idx++, pMap++)
        {
            if (pMap->linkInfo[LINK_INFO_PORTID] == portId &&
                pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
            {
                *(pBspChn++) = pMap->linkInfo[LINK_INFO_BSPCHN];
                *chanNum = *chanNum+1;
            }
        }
    }

    if(*chanNum > 0 )
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}

/*通过bsp通道获取子端通道号*/
UINT32 BspGetPortSlaveChnByBspChn(UINT32 bspChn,UINT32 dir, UINT32 *pSlaveChn)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pSlaveChn);

    ret = BspGetDifLinkMapInfo(&pMap, &size);
    if(BSP_ERROR != ret)
    {
        for (idx = 0; idx < size; idx++, pMap++)
        {
            if (pMap->linkInfo[LINK_INFO_BSPCHN] == bspChn &&
                pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
            {
                *pSlaveChn = pMap->linkInfo[LINK_INFO_PORT_SLAVECHN];
                break;
            }
        }
    }

    if(idx == size)
    {
        return BSP_ERROR;
    }
    else
    {
        return BSP_OK;
    }
}

UINT32 BspGetAntIdByPortId(UINT32 portId,UINT32 dir, UINT32 *antNum, UINT32 *pAntId)
{
    UINT32 idx  = 0;
    UINT32 ret  = BSP_OK;
    UINT32 size = 0;
    const T_RU_LINK_MAP *pMap   = NULL;

    INPUT_POINTER_CHECK(pAntId);
    INPUT_POINTER_CHECK(antNum);

    ret = BspGetDifLinkMapInfo(&pMap, &size);
    if(BSP_ERROR != ret)
    {
        for (idx = 0; idx < size; idx++, pMap++)
        {
            if (pMap->linkInfo[LINK_INFO_PORTID] == portId &&
                pMap->linkInfo[LINK_INFO_LINKTYPE] == dir)
            {
                *(pAntId++) = pMap->linkInfo[LINK_INFO_ANTID];
                *antNum = *antNum+1;
            }
        }
    }

    if(*antNum > 0 )
    {
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}

/*根据一个子端bsp通道号  获取另一个同一子端另一个bsp通道号*/
UINT32 BspGetAnotherSlaveChnByBspChn(UINT32 bspChn, UINT32 dir, UINT32 *pAnotherChn)
{
    UINT32 portId =0;
    UINT32 chanNum = 0;
    UINT32 chanInfo[4] = {0};
    UINT32 totalChan = 0;
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pAnotherChn);
    retVal = BspGetPortIdByBspChn(bspChn, dir, &portId);
    retVal |= BspGetBspChnByPortId(portId, dir, &chanNum, chanInfo);
    if((BSP_OK != retVal)||(portId >= 0xf))  /*portid为0xf表示异常 此通道无子端*/
    {
         return BSP_ERROR;
    }
    for(loop = 0; loop < chanNum; loop++)
    {
       totalChan += chanInfo[loop];   /*子端的两个通道是相互配合(开关 变频 目前认为只有两个通道)*/
    }
    *pAnotherChn = totalChan - bspChn; /*同一子端另一个通道的通道号*/
    dbgInfoEx("bspChn %d dir %d portId %d *pAnotherChn %d\n", bspChn, dir, portId, *pAnotherChn);

    return BSP_OK;
}

UINT32 BspSetDifChanSecMapTbl(UINT32 tblnum ,T_DifSecMapInfo* maptbl)
{
    INPUT_POINTER_CHECK(maptbl);
    
    s_DifSecMapNum = tblnum;
    s_DifSecMap = maptbl;
    
    return BSP_OK;
}

/*调试函数*/
UINT32 PrnLinkDefine(VOID)
{
    T_RU_LINK_MAP *pMap   = NULL;
    UINT32 size          = 0;
    UINT32 ret           = 0;
    UINT32 loop          = 0;
    printf("ulpSize=%d\n", size);
    ret = BspGetDifLinkMapInfo((const T_RU_LINK_MAP **)&pMap, &size);

    if (ret != BSP_OK)
    {
        dbgInfo("Link Map Info is Null\n");
        return BSP_ERROR;
    }

    for (loop = 0; loop < size; loop++)
    {
        dbgInfo("LinkId= %3d Type= %d Rruch= %2d BspCh= %2d AntId= %2d AntCh= %2d DifId= %2d DifCh= %2d DflId= %2d PaCh= %2d portId= %2d\n",
                pMap[loop].linkInfo[LINK_INFO_LINKID],
                pMap[loop].linkInfo[LINK_INFO_LINKTYPE],
                pMap[loop].linkInfo[LINK_INFO_RFCHN],
                pMap[loop].linkInfo[LINK_INFO_BSPCHN],
                pMap[loop].linkInfo[LINK_INFO_ANTID],
                pMap[loop].linkInfo[LINK_INFO_ANTCHN],
                pMap[loop].linkInfo[LINK_INFO_DIFCHIPID],
                pMap[loop].linkInfo[LINK_INFO_DIFCHN],
                pMap[loop].linkInfo[LINK_INFO_DFLID],
                pMap[loop].linkInfo[LINK_INFO_PACHN],
                pMap[loop].linkInfo[LINK_INFO_PORTID]);
    }
    return BSP_OK;
}

/*调试函数*/
UINT32 PrnOptSwitchDefine(VOID)
{
    T_RU_OPT_SWITCH_MAP *pMap   = NULL;
    UINT32 size          = 0;
    UINT32 ret           = 0;
    UINT32 loop          = 0;
    ret = BspGetDifOptSwitchMapInfo(&pMap, &size);

    if (ret != BSP_OK)
    {
        dbgInfo("OptSwitch Map Info is Null\n");
        return BSP_ERROR;
    }

    for (loop = 0; loop < size; loop++)
    {
        dbgInfo("Optid = %d LogicOpt = %d BspOpt = %d SfpId = %d BbFpgaId = %d\n",
                pMap[loop].optSwitchInfo[OPT_SWITCH_INFO_OPTID],
                pMap[loop].optSwitchInfo[OPT_SWITCH_INFO_LOGIC_OPT_ID],
                pMap[loop].optSwitchInfo[OPT_SWITCH_INFO_BSP_OPT_ID],
                pMap[loop].optSwitchInfo[OPT_SWITCH_INFO_SFP_ID],
                pMap[loop].optSwitchInfo[OPT_SWITCH_INFO_BBFPGA_ID]
               );
    }
    return BSP_OK;
}



/**************************************************************************
 * 函数名称: BspIsRfChannelUnion*(*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2018年03月29日秦菲  创建
 **************************************************************************/
UCHAR BspIsRfChannelUnion(UCHAR ucAntNo, UCHAR aucBandNo[4])
{
    UINT32  ulLinkNum   = BspGetChanLinkNum();
    UINT32  ulIdx       = 0;
    UINT32 *pulLinkId   = NULL;
    UINT32  *pulInfo = NULL;

    UINT32  ulLinkType[2] = {LINK_TYPE_RX,LINK_TYPE_TX};
    UINT32  ulAntCombFlag[2] = {0,0};
    UINT32 ulChnType;
    UINT32 ulTempCnt1;
    UINT32 ulTempCnt2;
    UINT32 *pulArry = NULL; /*最大的射频通道号*/

    pulLinkId = (UINT32 *)malloc(sizeof(UINT32)*ulLinkNum*3);
    if (NULL == pulLinkId)
    {
        return (UCHAR)BSP_ERROR;
    }

    pulInfo = pulLinkId + ulLinkNum;

    pulArry = pulLinkId + ulLinkNum*2;


    /*暂时先按照BSP通道号来判断，未考虑一个物理通道多频*/
    for( ulChnType = 0; ulChnType< (sizeof(ulLinkType)/sizeof(ulLinkType[0])); ulChnType++)
    {

        ulLinkNum   = BspGetChanLinkNum();
        memset(pulInfo,0x0,sizeof(ULONG)*ulLinkNum);
        memset(pulArry,0x0,sizeof(ULONG)*ulLinkNum);

        dbgInfoEx("ulChnType[%d] ulLinkNum = %d \n",ulChnType,ulLinkNum);

        if(BSP_OK == BspGetLinkInfoByLinkType(ulLinkType[ulChnType],LINK_INFO_ANTID,ucAntNo-1,pulLinkId,&ulLinkNum))
        {
            for(ulIdx = 0; ulIdx < ulLinkNum; ulIdx ++)
            {
                if(BSP_OK!=BspGetLinkInfoByLinkId(pulLinkId[ulIdx],LINK_INFO_RFCHN,&pulInfo[ulIdx]))
                {
                    pulInfo[ulIdx] = 0xFFFF;
                    continue;
                }

                dbgInfoEx("ulChnType[%d],uIdx[%d]:RfChn[%d]\n",ulChnType,ulIdx,pulInfo[ulIdx]);
            }

            /*有效性检查*/
            for (ulIdx = 0; ulIdx < ulLinkNum; ulIdx ++)
            {
                if (0xFFFF != pulInfo[ulIdx])
                {
                    break;
                }
            }

            if (ulIdx >= ulLinkNum)
            {
                ulAntCombFlag[ulChnType] = 0;  /*出错默认为非合路*/
                continue;
            }

            for (ulTempCnt1 = 0; ulTempCnt1 < ulLinkNum ; ulTempCnt1 ++)
            {
                if (0xFFFF != pulInfo[ulTempCnt1])
                {
                    pulArry[pulInfo[ulTempCnt1]]++;
                }

            }

            ulAntCombFlag[ulChnType] = 0;
            for (ulTempCnt2 = 0; ulTempCnt2 < ulLinkNum ; ulTempCnt2 ++)
            {
                if( pulArry[ulTempCnt2]>0 )
                {
                    ulAntCombFlag[ulChnType]++;  /*认为合路*/

                    dbgInfoEx("RfChn[%d],Num[%d]\n",ulTempCnt2,pulArry[ulTempCnt2]);
                }
            }
        }
        else
        {
            ulAntCombFlag[ulChnType] = 0;  /*出错默认为非合路*/
        }
		
		if( ulAntCombFlag[ulChnType] >1 )
		{
    		free(pulLinkId);
			return 1;

		}

    }

    free(pulLinkId);

    return 0;
	
}

#if (0)
/**************************************************************************
 * 函数名称: BspGetTrsvInfoByBspChn*(*)
 * 功能描述: 根据BSP通道号属性信息查询Transceiver芯片号以及芯片内的通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetTrsvInfoByBspChn(UINT32 ulBspChnl, UINT32 ulTrxDir, UINT32 *pulChipId, UINT32 *pulChnlOfChip)
{       
    UINT32 ulLinkType = 0;
    UINT32 ulChnlInfo = 0;
    UINT32 ulTrsvIdx  = 0;
    UINT32 ulTrsvChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    INPUT_POINTER_CHECK(pulChipId);
    INPUT_POINTER_CHECK(pulChnlOfChip);

    if (ulTrxDir == TX)
    {
        ulLinkType = LINK_TYPE_TX;
    }
    else // if (ulTrxDir == RX)
    {
        ulLinkType = LINK_TYPE_RX;
    }
    ulChnlInfo = LINK_INFO_BSPCHN;
    ulTrsvIdx  = LINK_INFO_TRSV_IDX;
    ulTrsvChnl = LINK_INFO_TRSV_CHN;
    ulRetVal |= BspGetDifInfoByLinkProp(ulChnlInfo, ulBspChnl, ulLinkType, ulTrsvIdx, pulChipId);
    ulRetVal |= BspGetDifInfoByLinkProp(ulChnlInfo, ulBspChnl, ulLinkType, ulTrsvChnl, pulChnlOfChip);

    return ulRetVal;
}

/**************************************************************************
 * 函数名称: BspGetBspChnByTrsvInfo(*)
 * 功能描述: 根据Transceiver芯片号以及芯片内的通道号查询BSP通道号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2020年07月07日 xx 创建
 **************************************************************************/
UINT32 BspGetBspChnByTrsvInfo(UINT32 ulChipId, UINT32 ulChnlOfChip, UINT32 ulTrxDir, UINT32 *pulBspChnl)
{   
    UINT32 ulLinkType = 0;
    UINT32 ulLoopChnl = 0;
    UINT32 ulTmpChips = 0;
    UINT32 ulChipChnl = 0;
    UINT32 ulChnlInfo = 0;
    UINT32 ulTrsvIdx  = 0;
    UINT32 ulTrsvChnl = 0;
    UINT32 ulRetVal = BSP_OK;
    INPUT_POINTER_CHECK(pulBspChnl);

    if (ulTrxDir == TX)
    {
        ulLinkType = LINK_TYPE_TX;
    }
    else// if (ulTrxDir == RX)
    {
        ulLinkType = LINK_TYPE_RX;
    }

    ulChnlInfo = LINK_INFO_BSPCHN;
    ulTrsvIdx  = LINK_INFO_TRSV_IDX;
    ulTrsvChnl = LINK_INFO_TRSV_CHN;
    for (ulLoopChnl = 0; ulLoopChnl < 16; ulLoopChnl++)
    {
        ulRetVal |= BspGetDifInfoByLinkProp(ulChnlInfo, ulLoopChnl, ulLinkType, ulTrsvIdx, &ulTmpChips);
        ulRetVal |= BspGetDifInfoByLinkProp(ulChnlInfo, ulLoopChnl, ulLinkType, ulTrsvChnl, &ulChipChnl);
        if ((ulChipId == ulTmpChips) && (ulChnlOfChip == ulChipChnl))
        {
            break;
        }
    }
    if (ulLoopChnl < 16)
    {
        *pulBspChnl = ulLoopChnl;
    }
    else
    {
        *pulBspChnl = 0;
        ulRetVal = BSP_ERROR;
    }

    return ulRetVal;
}
#endif


/**************************************************************************
 * 函数名称: BspGetTxEnIoInfoByRfChn*(*)
 * 功能描述: 根据射频通道号属性信息查询芯片号以及Tx通道
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日     创建
 **************************************************************************/
UINT32 BspGetTxEnIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *ptxEnIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(ptxEnIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }

    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_TXCHN_TDDIO,ptxEnIo);
    return ret ;
}


/**************************************************************************
 * 函数名称: BspGetRxEnIoInfoByRfChn*(*)
 * 功能描述: 根据射频通道号属性信息查询芯片号以及Rx通道
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日     创建
 **************************************************************************/
UINT32 BspGetRxEnIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *prxEnIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(prxEnIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_RXCHN_TDDIO,prxEnIo);
    return ret ;
}


/**************************************************************************
 * 函数名称: BspGetLnaIoInfoByRfChn*(*)
 * 功能描述: 根据射频通道号属性信息查询芯片号以及Lna通道
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日     创建
 **************************************************************************/
UINT32 BspGetPaIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *ppaIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(ppaIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_PACHN_TDDIO,ppaIo);
    return ret ;
}

UINT32 BspGetLnaIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *plnaIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(plnaIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_LNACHN_TDDIO,plnaIo);
    return ret ;
}

UINT32 BspGetLnaSwIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *plnaSwIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(plnaSwIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_LNASWCHN_TDDIO,plnaSwIo);
    return ret ;
}

UINT32 BspGetAmpIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pAmpIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pAmpIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_AMPCHN_TDDIO,pAmpIo);
    return ret ;
}


UINT32 BspGetFbIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *pfbIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(pfbIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_FBCHN_TDDIO,pfbIo);
    return ret ;
}

UINT32 BspGetTxAcIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *ptxAcIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(ptxAcIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX_AC;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX_AC;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_TXACCHN_TDDIO,ptxAcIo);
    return ret ;
}


UINT32 BspGetRxAcIoInfoByRfChn(UINT32 rfChn,UINT32 dir, UINT32 *prxAcIo)
{       
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;
    INPUT_POINTER_CHECK(prxAcIo);
    if(dir == TX)
    {
        linkType = LINK_TYPE_TX_AC;
    }
    if(dir == RX)
    {
        linkType = LINK_TYPE_RX_AC;
    }
    ret |= BspGetDifInfoByLinkPropTddIo((UINT32)LINK_INFO_RFCHN_TDDIO,rfChn,linkType,(UINT32)LINK_INFO_RXACCHN_TDDIO,prxAcIo);
    return ret ;
}

UINT32 BspChanMapPwrIdxInit(T_PWR_MAP_CHAN *pPwrIdxMap)
{
    s_pPwrMapChnInfo = pPwrIdxMap;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称:BspGetPwrIdxByBspChan
 * 功能描述:对外接口，提供bsp通道与功放48V模块索引对应关系，供高层调压使用
 * 输入参数: bspChan:bsp通道
 * 输出参数: pPwrIdx：功放48V模块索引
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明: 返回失败即老机型单板无传进对应关系或单板配置有误，高层按以前方式/默认的处理；
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2017年03月06日    wangfei    创建
 **************************************************************************/
UINT32 BspGetPwrIdxByBspChan(UINT32 bspChan, UINT32 *pPwrIdx)
{
    INPUT_POINTER_CHECK(pPwrIdx);
    INPUT_POINTER_CHECK(s_pPwrMapChnInfo);

    if (bspChan >= BSP_MAX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    if (s_pPwrMapChnInfo->chnPwrIdx[bspChan] <= s_pPwrMapChnInfo->pwrNum)
    {
        *pPwrIdx = s_pPwrMapChnInfo->chnPwrIdx[bspChan];
        return BSP_OK;
    }
    return BSP_ERROR;
}

UINT32 BspGetPaVoltPwrNum(UINT32 *paVoltNum)
{
    INPUT_POINTER_CHECK(paVoltNum);
    if (NULL == s_pPwrMapChnInfo)
    {
        dbgInfoEx("%s:Input Pointer is NULL!\n",__FUNCTION__);
        return ERROR_NULL_POINTER;
    }
    *paVoltNum = s_pPwrMapChnInfo->pwrNum;

    return BSP_OK;
}

UINT32 BspGetFirstBspChanByPwrIdx(UINT32 pwrIdx, UINT32 *bspChan)
{
    UINT32 loop = 0;
    UINT32 txNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(bspChan);
    INPUT_POINTER_CHECK(s_pPwrMapChnInfo);

    if (pwrIdx >= s_pPwrMapChnInfo->pwrNum)
    {
        return BSP_ERROR;
    }
    for(loop = 0; loop < txNum; loop++)
    {
        if (pwrIdx == s_pPwrMapChnInfo->chnPwrIdx[loop])
        {
            *bspChan = loop;
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

/* 通过射频通道获取 transceiver 的通道等信息 */
UINT32 BspGetTrxChipIdAndChanNoByRfChan(UINT32 rfChan, UINT32 dir, UINT32 *mtschip, UINT32 *mtschan)
{
    UINT32 retVal = BSP_OK;
    TRruDeviceDescription *pDev = NULL;
    eDeviceType deviceType = DEVICE_TYPE_TRANSCEIVER;

    INPUT_POINTER_CHECK(mtschip);
    INPUT_POINTER_CHECK(mtschan)

    if((rfChan > BspGetTxChannel()) || (dir > (UINT32) PRX))
    {
        dbgErr("%s>>: input rfChan(%d) or dir(%d) faild！\n", __FUNCTION__, rfChan, dir);
        retVal |= BSP_ERROR;
    }
    deviceType = (dir == TX) ? DEVICE_TYPE_DAC : DEVICE_TYPE_ADC;
    retVal |= BspChipInfoPtrGetByRfPathDef(rfChan, dir, deviceType, &pDev);
    if(BSP_OK != retVal)
    {
        dbgErr("%s>>: retVal = %d \n", __FUNCTION__, retVal);
        retVal |= BSP_ERROR;
    }
    else
    {
        *mtschip = pDev->ulDeviceIndex;
        *mtschan = pDev->ulDeviceInterIndex;
        dbgInfoEx("%s>>: rfChan = %d, dir = %d, mtschip = %d, mtschan = %d \n", __FUNCTION__, rfChan, dir, *mtschip, *mtschan);
    }

    return retVal;
}

/**************************************************************************
 * 函数名称: BspGetRfChanByAntId*(*)
 * 功能描述: 通过天线号查找射频通道信息.
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetAntDetPinIdByBspChn(UINT32 bspChn, UINT32 *pAntDetPinId)
{
    UINT32 ret = BSP_OK;
    UINT32 idx    = 0;
    UINT32 size   = 0;
    const T_RU_ANT_DET_MAP *pMap = NULL;

    INPUT_POINTER_CHECK(pAntDetPinId);
    ret = BspGetAntDetMapInfo((const T_RU_ANT_DET_MAP **)&pMap, &size);
    dbgInfoEx("BspGetAntDetMapInfo ret = %d\n", ret);
    for (idx = 0; idx < size; idx++,pMap++)
    {
        if (pMap->linkInfo[MAP_INFO_BSP_CHAN]  == bspChn)
        {
            *pAntDetPinId = pMap->linkInfo[MAP_INFO_ANT_DET_PIN_CHAN];
            dbgInfoEx("%s >> bspChn = %d, antDetPinId = %d\n", __FUNCTION__,bspChn,*pAntDetPinId);
            return BSP_OK;
        }
    }

    return BSP_ERROR;
}

/**************************************************************************
 * 函数名称: BspGetFwdDirByRfInfo(*)
 * 功能描述: 根据射频通道号和收发方向查询全链路大方向
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2024年06月20日 xx 创建
 **************************************************************************/
/* Started by AICoder, pid:e4889e6765q8f671458e0addd04cca39e609d600 */
UINT32 BspGetFwdDirByRfInfo(UINT32 rfCh, UINT32 dir, UINT32 *fwdDir)
{   
    UINT32 ret = BSP_OK;
    UINT32 linkType = 0;
    UINT32 ulLoop = 0;

    INPUT_POINTER_CHECK(fwdDir);

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    else if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }

    for(ulLoop = 0; ulLoop < g_fwdLinkNum; ulLoop++)
    {
       if((g_fwdLinkMapInfo[ulLoop].rfCh == rfCh) && (g_fwdLinkMapInfo[ulLoop].trxType == linkType))
       {
           break;
       }
    }

    if(ulLoop >= g_fwdLinkNum)
    {
        return BSP_ERROR;
    }

    *fwdDir = g_fwdLinkMapInfo[ulLoop].fwdType;
    dbgInfoEx("ulLoop = %d, fwdType = %d\n", ulLoop, *fwdDir);

    return ret;
}

/**************************************************************************
 * 函数名称: BspGetRxChByTxChInOneLink(*)
 * 功能描述: 根据发射通道号和大方查询通道类型
 * 输入参数: rfChTx：发射通道号；dir：1：NCR大下行；0：NCR 大上行
 * 输出参数: *type：通道类型(1：rfCh发射； 0：rfCh接收)
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2024年07月16日 xx 创建
 **************************************************************************/
/* Started by AICoder, pid:abed8o4320h6f81145e60b85d08f865127595110 */
UINT32 BspGetTrxTypeByTxChAndFwdType(UINT32 rfChTx, UINT32 linkdir, UINT32 *type)
{
    UINT32 ulLoop = 0;
    UINT32 fwdType = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(type);

    fwdType = linkdir;

    for(ulLoop = 0; ulLoop < g_fwdLinkNum; ulLoop++)
    {
        if((g_fwdLinkMapInfo[ulLoop].fwdType == fwdType) && (g_fwdLinkMapInfo[ulLoop].rfCh == rfChTx))
        {
            break;
        }
    }

    if(ulLoop >= g_fwdLinkNum)
    {
        ret = BSP_ERROR;
    }

    *type = g_fwdLinkMapInfo[ulLoop].trxType;
    dbgInfoEx("ulLoop = %d, *type = %d\n", ulLoop, *type);

    return ret;
}

UINT32 testgettrxtype(UINT32 rfCh, UINT32 linkdir)
{
    UINT32 type = 0;

    if(BSP_OK != BspGetTrxTypeByTxChAndFwdType(rfCh, linkdir, &type))
    {
        return BSP_ERROR;
    }

    return type;
}
/* Ended by AICoder, pid:abed8o4320h6f81145e60b85d08f865127595110 */

/* Started by AICoder, pid:ac3ca1f9dc2a1ba14b7d0a9e71c76235d7d7f8ce */
/**************************************************************************
 * 函数名称: BspGetRxChByTxChInOneLink(*)
 * 功能描述: 根据发射通道号查找同一大方向的接收通道号
 * 输入参数: rfChTx：发射通道号；dir：发射/接收
 * 输出参数: *rfChRx：接收通道号
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2024年07月16日 xx 创建
 **************************************************************************/
UINT32 BspGetRxChByTxChInOneLink(UINT32 rfChTx, UINT32 dir, UINT32 *rfChRx)
{
    UINT32 ulLoop = 0;
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(rfChRx);

    *rfChRx = g_fwdLinkNum;

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    else if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }

    for(ulLoop = 0; ulLoop < g_fwdLinkNum; ulLoop++)
    {
        if((g_fwdLinkMapInfo[ulLoop].trxType == linkType) && (g_fwdLinkMapInfo[ulLoop].rfCh == rfChTx))
        {
            break;
        }
    }

    if(ulLoop >= g_fwdLinkNum)
    {
        return BSP_ERROR;
    }

    *rfChRx = g_fwdLinkMapInfo[ulLoop].rfChRx;
    dbgInfoEx("ulLoop = %d, *rfChRx = %d\n", ulLoop, *rfChRx);

    return ret;
}

UINT32 testgetrxch(UINT32 rfCh, UINT32 dir)
{
    UINT32 rxCh = 0;

    if(BSP_OK != BspGetRxChByTxChInOneLink(rfCh, dir, &rxCh))
    {
        return BSP_ERROR;
    }

    return rxCh;
}

/**************************************************************************
 * 函数名称: BspGetTddIdByTxChInOneLink(*)
 * 功能描述: 根据发射通道号查找同一大方向的tddId
 * 输入参数: rfChTx：发射通道号；dir：发射/接收
 * 输出参数: *tddId：第几套tdd
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2024年07月16日 xx 创建
 **************************************************************************/
UINT32 BspGetTddIdByTxChInOneLink(UINT32 rfChTx, UINT32 dir, UINT32 *tddId)
{
    UINT32 ulLoop = 0;
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(tddId);

    *tddId = g_fwdLinkNum;

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    else if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }

    for(ulLoop = 0; ulLoop < g_fwdLinkNum; ulLoop++)
    {
        if((g_fwdLinkMapInfo[ulLoop].trxType == linkType) && (g_fwdLinkMapInfo[ulLoop].rfCh == rfChTx))
        {
            break;
        }
    }

    if(ulLoop >= g_fwdLinkNum)
    {
        ret = BSP_ERROR;
    }

    *tddId = g_fwdLinkMapInfo[ulLoop].tddId;
    dbgInfoEx("ulLoop = %d, *tddId = %d\n", ulLoop, *tddId);

    return ret;
}

UINT32 testgettddid(UINT32 rfCh, UINT32 dir)
{
    UINT32 tddId = 0;

    if(BSP_OK != BspGetTddIdByTxChInOneLink(rfCh, dir, &tddId))
    {
        return BSP_ERROR;
    }

    return tddId;
}

/**************************************************************************
 * 函数名称: BspGetGroupIdByTxChInOneLink(*)
 * 功能描述: 根据发射通道号查找同一大方向的groupId
 * 输入参数: rfChTx：发射通道号；dir：发射/接收
 * 输出参数: *groupId：天线组号，一个小区一个groupId
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2024年07月16日 xx 创建
 **************************************************************************/
UINT32 BspGetGroupIdByTxChInOneLink(UINT32 rfChTx, UINT32 dir, UINT32 *groupId)
{
    UINT32 ulLoop = 0;
    UINT32 linkType = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(groupId);

    *groupId = g_fwdLinkNum;

    if(dir == TX)
    {
        linkType = LINK_TYPE_TX;
    }
    else if(dir == RX)
    {
        linkType = LINK_TYPE_RX;
    }

    for(ulLoop = 0; ulLoop < g_fwdLinkNum; ulLoop++)
    {
        if((g_fwdLinkMapInfo[ulLoop].trxType == linkType) && (g_fwdLinkMapInfo[ulLoop].rfCh == rfChTx))
        {
            break;
        }
    }

    if(ulLoop >= g_fwdLinkNum)
    {
        ret = BSP_ERROR;
    }

    *groupId = g_fwdLinkMapInfo[ulLoop].groupId;
    dbgInfoEx("ulLoop = %d, *groupId = %d\n", ulLoop, *groupId);

    return ret;
}

UINT32 testgetgroupid(UINT32 rfCh, UINT32 dir)
{
    UINT32 groupId = 0;

    if(BSP_OK != BspGetGroupIdByTxChInOneLink(rfCh, dir, &groupId))
    {
        return BSP_ERROR;
    }

    return groupId;
}
/* Ended by AICoder, pid:ac3ca1f9dc2a1ba14b7d0a9e71c76235d7d7f8ce */

UINT32 testgetfwddir(UINT32 rfCh, UINT32 dir)
{
    UINT32 fwdDir = 0;

    if(BSP_OK != BspGetFwdDirByRfInfo(rfCh, dir, &fwdDir))
    {
        return BSP_ERROR;
    }

    return fwdDir;
}
/* Ended by AICoder, pid:e4889e6765q8f671458e0addd04cca39e609d600 */
/**************************************************************************
 * 函数名称: BspGetAntNoFromBspChan(*)
 * 功能描述: 通过bspcahn查询AntNo.--QCELL用
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明: 收发不对称机型中，QCELL的APP侧对于BBU下发的天线号转BSP通道关系发生变化，以前是天线号减1就是bsp通道号
 *          现在映射关系变成bsp0~3对应天线号1 3 2 4 ，由于区分机型，所以需要向APP暴露接口
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年03月29日 王飞    创建
 **************************************************************************/
UINT32 BspGetAntNoFromBspChan(UINT32 bspChan)
{
    if ( NULL == g_tBspChanAndAntNoLinkMap.pFuncGetAntNoFromBspChan )/* ZHYZHYZHY：可以不？ */
    {
        return BSP_ERROR;
    }
    
    return g_tBspChanAndAntNoLinkMap.pFuncGetAntNoFromBspChan(bspChan);
}

UINT32 BspGetBspChanFromAntNo(UINT32 antNo)
{
    if (NULL == g_tBspChanAndAntNoLinkMap.pFuncGetBspChanFromAntNo)
    {
        return BSP_ERROR;
    }
    return g_tBspChanAndAntNoLinkMap.pFuncGetBspChanFromAntNo(antNo);
}

#ifdef BUILD_WITH_OM_FUNC
VOID prnpwridxmap(VOID)
{
    UINT32 chan    = 0;
    UINT32 chanNum = BspGetTxChannel();
    UINT32 pwrIdx  = 0;

    for (chan = 0; chan < chanNum; chan++)
    {
        BspGetPwrIdxByBspChan(chan, &pwrIdx);
        if ((chan%8)==0)
        {
            dbgInfo("\n %2d-%2d: ", chan,chan+8);
        }
        dbgInfo("%d ", pwrIdx);       
    }
    dbgInfo("\n");
    return;
}
#endif

/*根据不同的判断标准判断当前通道是否拉远*/
UINT32 BspIsRemoteSlaveChan(UINT32 bspChn, UINT32 type)
{
    UINT32 portId = 0;
    UINT32 portType = 0;
    UINT32 portSta = 0;
    UINT32 retVal = BSP_OK;
    UINT32 flag = LINK_HOME;   /*默认通道都是非拉远的*/

    if(BSP_OK == BspIsSupportRfsRemote())    /*非子母端机型*/
    {
        return flag;
    }
    retVal = BspGetPortIdByBspChn(bspChn, TX, &portId);
    retVal |= BspGetSlavePortCfgTpye(portId, &portType);
    retVal |= BspGetSlavePortCfgSta(portId, &portSta);
    dbgInfoEx("bspchan %d portId %d portType %d portSta %d retVal %d\n", bspChn, portId, portType, portSta, retVal);
    if((LINK_REMOTE == portType)&&(BSP_OK == retVal))  /*非拉远通道retVal 不是OK*/
    {
        if(0 == type)   /*只判断网管是否配置拉远*/
        {
            flag = LINK_REMOTE;
        }
        else         /*还判断是否建链*/
        {
            if(LINK_OK == portSta)
            {
                flag = LINK_REMOTE;
            }
        }
    }
    return flag;
}

UINT32 BspSetRailWayAntDuplicationMap(T_RailWayAntDuplicationMap *pAntDupMap, UINT32 duplicationGroupNum)
{
    UINT32 loop = 0;

    INPUT_POINTER_CHECK(pAntDupMap);
    if(duplicationGroupNum > MAX_ANT_DUP_MAP)
    {
        dbgErr("%s>>: input DuplicationGroupNum is %u error!\n", __FUNCTION__, duplicationGroupNum);
        return BSP_ERROR;
    }

    s_antDuplicationMap.isSupportDupliction = pAntDupMap->isSupportDupliction;
    s_antDuplicationMap.duplicationGroup = pAntDupMap->duplicationGroup;
    for(loop = 0;loop < duplicationGroupNum; loop++)
    {
        s_antDuplicationMap.antDupMap[loop] = pAntDupMap->antDupMap[loop];
    }

    return BSP_OK;
}


UINT32 BspGetRailWayAntDuplicationMap(T_RailWayAntDuplicationMap *pAntDupMap)
{
    INPUT_POINTER_CHECK(pAntDupMap);
    memcpy_s(pAntDupMap, sizeof(T_RailWayAntDuplicationMap), &s_antDuplicationMap, sizeof(T_RailWayAntDuplicationMap));
    
    return BSP_OK;
}

static UINT32 dbgShowAntDupInfo(VOID)
{
    UINT32 loopIdx = 0;
    T_RailWayAntDuplicationMap pAntDupMap = {0};
    
    BspGetRailWayAntDuplicationMap(&pAntDupMap);
    dbgInfo("IsSupportDupliction: %d\n",pAntDupMap.isSupportDupliction);
    dbgInfo("DuplicationGroup:    %d\n",pAntDupMap.duplicationGroup);

    dbgInfo("GROUP  ORIANTNO  DUPANTNO \n");
    for(loopIdx = 0; loopIdx < pAntDupMap.duplicationGroup; loopIdx++)
    {
        dbgInfo("%4d  %4d  %4d \n",loopIdx,
            pAntDupMap.antDupMap[loopIdx].oriAntNo,
            pAntDupMap.antDupMap[loopIdx].dupAntNo);
    }

    return BSP_OK;
}

/* Started by AICoder, pid:gcf36sea85u2c7714d560889100b8b3b9c26a059 */
/* 获取频段支持的通道位图 */
UINT32 BspGetRfChnBitMapByFreqBandId(UINT32 bandId, UINT32 dir, UCHAR *rfChanBitMap, UINT32 bitMapLen)
{
    UINT32 bspChan = 0;
    UINT32 bandMask = 0;
    UINT32 chipId = 0;
    UINT32 rfChan = 0;
    UINT32 chanNum = 0;
    UCHAR  byteTmp = 0;
    UINT32 bitMapIdx = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(rfChanBitMap);
    memset_s(rfChanBitMap,bitMapLen,0,bitMapLen);
    if(bandId >= BspGetFddRruBandNum(dir))
    {
        return BSP_ERROR;
    }
    chanNum = dir == TX ? BspGetTxChannel():BspGetRxChannel();
    if(chanNum/8 > bitMapLen)
    {
        return BSP_ERROR;
    }

    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        ret = BspGetBandMaskByBspChn(bspChan, dir, &chipId, &bandMask);
        if (BSP_ERROR == ret)
        {
            dbgErr("%s>>>bspChan[%d] Get bandMask Failed!\n", __FUNCTION__, bspChan);
            return BSP_ERROR;
        }
        if(BIT_SET(bandId) & bandMask)
        {
            BspGetRfChnByBspChn(bspChan, dir, &rfChan);
            bitMapIdx = rfChan/8;
            byteTmp = rfChanBitMap[bitMapIdx];
            rfChanBitMap[bitMapIdx] = byteTmp | (1<<(rfChan%8));
            dbgInfoEx("%s>> rfChan[%d] bandId[%d] BitMap[%d]=0x%X\n",__FUNCTION__,rfChan,bandId,bitMapIdx,rfChanBitMap[bitMapIdx]);
        }
    }
    return ret;
}
/* Ended by AICoder, pid:gcf36sea85u2c7714d560889100b8b3b9c26a059 */

/* Started by AICoder, pid:sfadcd1d021e8d314e970b73e09a1c3c44039dbc */
/* 获取电源砖支持的通道位图 */
UINT32 BspGetPwrIdxBitMapByBspChan(UINT32 pwrbrickNo, UINT32 *pwrbrickbitmap, UINT32 bitMapLen)
{
    UINT32 rfChan = 0;
    UINT32 bspChan = 0;
    UINT32 pwrIdx = 0;
    UINT32 chanNum = 0;
    UINT32 tmpBitVal = 0;
    UINT32 bitMapIdx = 0;
    UINT32 bitNum = sizeof(UINT32)*8;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(pwrbrickbitmap);
    INPUT_POINTER_CHECK(s_pPwrMapChnInfo);
    memset_s(pwrbrickbitmap, sizeof(UINT32)*bitMapLen, 0, sizeof(UINT32)*bitMapLen);
    if(pwrbrickNo >= s_pPwrMapChnInfo->pwrNum)
    {
        return BSP_ERROR;
    }
    chanNum = BspGetTxChannel();
    if(chanNum > bitNum*bitMapLen)
    {
        return BSP_ERROR;
    }

    for (rfChan = 0; rfChan < chanNum; rfChan++)
    {
        ret |= BspGetBspChnByRfChn(rfChan, TX, &bspChan);
        ret |= BspGetPwrIdxByBspChan(bspChan, &pwrIdx);
        if(pwrIdx != pwrbrickNo)
        {
            continue;
        }
        bitMapIdx = rfChan/bitNum;
        tmpBitVal = pwrbrickbitmap[bitMapIdx];
        pwrbrickbitmap[bitMapIdx] = tmpBitVal | (1<<(rfChan%bitNum));
        dbgInfoEx("%s>> rfChan[%d] pwrIdx[%d] BitMap[%d]=0x%X\n",__FUNCTION__,rfChan,pwrIdx,bitMapIdx,pwrbrickbitmap[bitMapIdx]);
    }
    return ret;
}
/* Ended by AICoder, pid:sfadcd1d021e8d314e970b73e09a1c3c44039dbc */

/* Started by AICoder, pid:4444cqc490971cc14f9a08e6107e834c6d15f10f */
/**
 * 函数名称: BspGetFddRfChnBitMapByFreqBandId
 * 功能描述: 根据频段ID获取FDD射频通道位图
 * 输入参数: bandId - 频段ID
 *           dir - 方向（TX或RX）
 *           rfChanBitMap - 射频通道位图
 *           len - 位图长度
 * 输出参数: rfChanBitMap - 射频通道位图
 * 返 回 值: BSP_OK - 成功
 *           BSP_ERROR - 失败
 * rfChanBitMap已经与方案确认，按照UINT32上报，网络按照字节发送，BBU会处理大小端转序
*/
UINT32 BspGetFddRfChnBitMapByFreqBandId(UINT32 bandId, UINT32 dir, UINT32 *rfChanBitMap, UINT32 len)
{
    UINT32 bspChan = 0;
    UINT32 bandMask = 0;
    UINT32 chipId = 0;
    UINT32 rfChan = 0;
    UINT32 chanNum = 0;
    UINT32 tmpBitVal = 0;
    UINT32 bitMapIdx = 0;
    UINT32 ret = BSP_OK;
    const UINT32 uintBitNum = sizeof(UINT32) * 8;

    INPUT_POINTER_CHECK(rfChanBitMap);
    memset_s(rfChanBitMap, len*sizeof(UINT32), 0, len*sizeof(UINT32));
    if (bandId >= BspGetFddRruBandNum(dir))
    {
        return BSP_ERROR;
    }

    chanNum = (dir == TX) ? BspGetTxChannel() : BspGetRxChannel();
    if (chanNum > len * uintBitNum)
    {
        return BSP_ERROR;
    }

    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        ret = BspGetBandMaskByBspChn(bspChan, dir, &chipId, &bandMask);
        if (BSP_ERROR == ret)
        {
            dbgErr("%s>>>bspChan[%d] Get bandMask Failed!\n", __FUNCTION__, bspChan);
            return BSP_ERROR;
        }
        if(BIT_SET(bandId) & bandMask)
        {
            BspGetRfChnByBspChn(bspChan, dir, &rfChan);
            bitMapIdx = rfChan / uintBitNum;
            tmpBitVal = rfChanBitMap[bitMapIdx];
            rfChanBitMap[bitMapIdx] = (tmpBitVal | BIT_SET(rfChan % uintBitNum));
            dbgInfoEx("%s>> rfChan[%d] bandId[%d] BitMap[%d]=0x%X\n", __FUNCTION__, rfChan, bandId, bitMapIdx, rfChanBitMap[bitMapIdx]);
        }
    }

    return ret;

}
/* Ended by AICoder, pid:4444cqc490971cc14f9a08e6107e834c6d15f10f */

/* Started by AICoder, pid:9bdabf458047263146ef081cd0715c2f5a59922f */
/**
 * 函数名称: BspGetRruRatedFullPowTx
 * 功能描述: 获取RRU满功率发射
 * 输入参数: pRruRatedPowerTx - RRU整机标称功率
 * 输出参数: pRruRatedPowerTx - RRU整机标称功率
 * 返 回 值: BSP_OK - 成功
 *           BSP_ERROR - 失败
*/
UINT32 BspGetRruRatedFullPowTx(UINT32 *pRruRatedPowerTx)
{
    UINT32 chanNum = BspGetTxChannel();
    UINT32 antNum = BspGetMapAntNum();
    UINT32 chanLoop = 0;
    UINT32 antRatedPow = 0;
    UINT32 tmpRatedPow = 0;
    UINT32 ret = BSP_OK;
    UINT32 rruPowRet = BSP_OK;
    UINT32 rruPowerSupport = 0;
    UINT32 rruPower = 0;

    INPUT_POINTER_CHECK(pRruRatedPowerTx);
    rruPowRet = BspGetSpecialRruPower(&rruPowerSupport, &rruPower);/* 单板下设置的整机功率 */
    if((rruPowRet == BSP_OK) && (SUPPORT == rruPowerSupport))
    {
        *pRruRatedPowerTx = rruPower;
        dbgInfoEx("%s>> Special RruRatedPowerTx %u\n", __FUNCTION__, *pRruRatedPowerTx);
        return rruPowRet;
    }

    tmpRatedPow = BspGetRruFullPow();
    if (tmpRatedPow == BSP_ERROR)
    {
        /* FDD有些机型RruInfo没有RruRatedPowerTx字段 */
        tmpRatedPow = 0;
        for (chanLoop = 1; chanLoop <= antNum; chanLoop++)
        {
            ret |= BspGetRruAntRatedPower(chanLoop, &antRatedPow);
            if (ret != BSP_OK)
            {
                break;
            }
            tmpRatedPow = tmpRatedPow + antRatedPow;
        }
    }

    if (ret != BSP_OK) //如果在单板侧没有配置天线口功率参数
    {
        ret = BSP_OK;
        tmpRatedPow = 0;
        for (chanLoop = 0; chanLoop < chanNum; chanLoop++)
        {
            ret |= BspGetRruPathRatedPower(chanLoop, &antRatedPow);
            if (ret != BSP_OK)
            {
                return ret;
            }
            tmpRatedPow = tmpRatedPow + antRatedPow;
        }
    }
    *pRruRatedPowerTx = tmpRatedPow;

    dbgInfoEx("%s>> RruRatedPowerTx %u\n", __FUNCTION__, *pRruRatedPowerTx);
    return ret;
}
/* Ended by AICoder, pid:9bdabf458047263146ef081cd0715c2f5a59922f */

/* Started by AICoder, pid:yafe2r88f0768d01412e0a6cf0e4f7396ab5557a */
/* 获取频段的额定功率 */
UINT32 BspGetRruFreqRatedFullPowTx(UINT32 bandID, UINT32 *pFreqPower)
{
    UINT32 bspChan = 0;
    UINT32 bandMask = 0;
    UINT32 chipId = 0;
    UINT32 chanPower = 0;
    UINT32 bandPower = 0;
    UINT32 chanNum = 0;
    UINT32 ret = BSP_OK;

    INPUT_POINTER_CHECK(pFreqPower);
    if(bandID >= BspGetFddRruBandNum(TX))
    {
        return BSP_ERROR;
    }

    chanNum = BspGetTxChannel();
    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        ret = BspGetBandMaskByBspChn(bspChan, TX, &chipId, &bandMask);
        if (BSP_ERROR == ret)
        {
            dbgErr("%s>>>bspChan[%d] Get bandMask Failed!\n", __FUNCTION__, bspChan);
            return BSP_ERROR;
        }
        if(BIT_SET(bandID) & bandMask)
        {
            ret |= BspGetRruPathRatedPower(bspChan, &chanPower);
            bandPower = bandPower + chanPower;
        }
    }
    *pFreqPower = bandPower;
    dbgInfoEx("%s>> bandid[%d] RruRatedPowerTx %d\n", __FUNCTION__, bandID, *pFreqPower);
    return ret;
}
/* Ended by AICoder, pid:yafe2r88f0768d01412e0a6cf0e4f7396ab5557a */

/* Started by AICoder, pid:ba4bbo24e69514a1495f08cf508d3436cbd74bbe */
/* 返回整机频段数 */
UINT32 BspGetFddRruBandNum(UINT32 dir)
{
    UINT32 ret = BSP_OK;
    UINT32 bspChan = 0;
    UINT32 bandMask = 0;
    UINT32 chipId = 0;
    UINT32 chanNum = 0;
    UINT32 bandLoop = 0;
    UINT32 rruBandMask = 0;
    UINT32 rruBandNum = 0;

    chanNum = dir == TX ? BspGetTxChannel():BspGetRxChannel();
    for (bspChan = 0; bspChan < chanNum; bspChan++)
    {
        ret = BspGetBandMaskByBspChn(bspChan, dir, &chipId, &bandMask);
        if (BSP_ERROR == ret)
        {
            dbgErr("%s>>>bspChan[%d] dir[%d] Get bandMask Failed!\n", __FUNCTION__, bspChan, dir);
            return BSP_ERROR;
        }
        rruBandMask |= bandMask;
        dbgInfoEx("%s>> bspChan[%d] dir:%d bandMask %d  rruBandMask:%d\n", __FUNCTION__, bspChan, dir, bandMask, rruBandMask);
    }
    for (bandLoop = 0; bandLoop < RRU_MAX_BAND_NUM; bandLoop++)
    {
        if(BIT_SET(bandLoop) & rruBandMask)
        {
            rruBandNum++;
        }
    }
    if(0 == rruBandNum)
    {
        rruBandNum = BspGetRruFreqBandNum();
    }

    return rruBandNum;
}
/* Ended by AICoder, pid:ba4bbo24e69514a1495f08cf508d3436cbd74bbe */

/* Started by AICoder, pid:7a3b2ofdb2o9b3d14fc20a20c0c18613fdd2d099 */
UINT32 BspGetChnMaskByPwrTempType(UINT32 pwrTempType, T_PwrMapChan *pPwrChanMapInfo)
{
    UINT32 retVal  = BSP_OK;
    UINT32 chnMask = 0;
    UINT32 chanNum = 0;

    INPUT_POINTER_CHECK(pPwrChanMapInfo);
    retVal = BspGetChanInfoByPwrTempType(pwrTempType, &chanNum, &chnMask);
    pPwrChanMapInfo->chanNum = chanNum;
    pPwrChanMapInfo->chanMask[0] = chnMask;

    return retVal;
}
/* Ended by AICoder, pid:7a3b2ofdb2o9b3d14fc20a20c0c18613fdd2d099 */


/**************************************************************************
 * 函数名称: BspGetDownLinkChanNoConvert(*)
 * 功能描述: 根据发射通道号和大方向、上下行查询bsp通道号s_ruLinkMap
 * 输入参数: chan：发射通道号；linkDir：大方向；dir：小方向
  * 返 回 值: BSP_ERROR 执行失败
 *           其它   通道号
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2025年01月02日 xx 创建
 **************************************************************************/
/* Started by AICoder, pid:9427alccb568e5a144c00b2a70ffc57a9a11aa60 */
UINT32 BspGetDownLinkChanNoConvert(UINT32 chan, UINT32 linkDir, UINT32 dir)
{
    UINT32 fwdDir = 0;
    UINT32 ConvChan = 0;
    UINT32 BspChan = 0;

    if((chan >7)||(linkDir>1)||(dir>1))
    {
        dbgErr("[%s] input error chan:%d linkDir:%d dir:%d\n", __FUNCTION__,chan,linkDir,dir);
        BspLog(LOG_LEVEL_0,"[%s] input error chan:%d linkDir:%d dir:%d\n", __FUNCTION__,chan,linkDir,dir);
        return BSP_ERROR;
    }

    if(BSP_OK == BspGetFwdDirByRfInfo(chan, dir, &fwdDir))
    {
        if(linkDir==fwdDir)
        {
            if(BSP_OK == BspGetBspChnByRfChn(chan,dir,&BspChan))
            {
                dbgInfo("[%s] [%d] BspChan=%d.\n", __FUNCTION__, __LINE__,BspChan);
                BspLog(LOG_LEVEL_0,"[%s] [%d] BspChan=%d.\n", __FUNCTION__, __LINE__,BspChan);
                return BspChan;
            }
            return BSP_ERROR;
        }
        else
        {
            if(BSP_OK == BspGetRxChByTxChInOneLink(chan, dir, &ConvChan))
            {
                if(BSP_OK == BspGetBspChnByRfChn(ConvChan,dir,&BspChan))
                {
                    dbgInfo("[%s] [%d] BspChan=%d.\n", __FUNCTION__, __LINE__,BspChan);
                    BspLog(LOG_LEVEL_0,"[%s] [%d] BspChan=%d.\n", __FUNCTION__, __LINE__,BspChan);
                    return BspChan;
                }
                return BSP_ERROR;
            }
            return BSP_ERROR;
        }
    }

    return BSP_ERROR;
}
/* Ended by AICoder, pid:9427alccb568e5a144c00b2a70ffc57a9a11aa60 */

/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP 
* 文件名称 : gainctrl_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了DPDIC4.2增益控制模块接口声明
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2021-12-13
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2021-12-13
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef ITRANAAU_PLATFORM_BSP_FUNCLIB_GAINCTRL_GAINCTRL_IC4_2_INCLUDE_GAINCTRL_IC4_2_H_
#define ITRANAAU_PLATFORM_BSP_FUNCLIB_GAINCTRL_GAINCTRL_IC4_2_INCLUDE_GAINCTRL_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "ichalstub_ic4_2.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"


/**************************************************************************
 *                        宏
 **************************************************************************/
#define GAIN_CTRL_NOT_EMBODY_PREATT          0
#define GAIN_CTRL_EMBODY_PREATT              0x5a
#define IC4_2_MAX_CHN_NUM   8  /* IC4.2芯片，上行（或下行）最大支持通道数 */


/**************************************************************************
 *                         数据类型
 **************************************************************************/
/* 增益初始化参数 */
typedef struct T_GainCommParaStruct
{
    INT32 preCfrGain[IC4_2_MAX_CHN_NUM];         /** CFR入口，K0增益值 */
    INT32 preDpdGain[IC4_2_MAX_CHN_NUM];         /** 进DPD增益 */
    INT32 outDpdGain[IC4_2_MAX_CHN_NUM];         /** 出DPD增益 */   
    INT32 dlPreGain[IC4_2_MAX_CHN_NUM];          /** dlpre载波增益*/
    INT32 dlBankDgain[IC4_2_MAX_CHN_NUM];           /** dlbank dgain载波增益*/
    INT32 dlBankApTuneGain[IC4_2_MAX_CHN_NUM];       /** dlbank aptune载波增益*/
} T_GainCommPara;


/**************************************************************************
*                         函数声明
**************************************************************************/
UINT32 BspSetGainCtrlPreAttMode(UINT32 gainCtrlPreAttMode);
UINT32 BspGetGainCtrlPreAttMode();
UINT32 BspSetRxPcPreAtt(UINT32 chan, INT32 preAtt);
UINT32 BspGetRxCarrGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 *gain);
UINT32 BspGetTxPcGain(UINT32 chan, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain);
UINT32 BspSetTxPcGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspSetTxPcGainAll(UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspSetTxPcTune(UINT32 sw);
UINT32 BspSetCarrGainSw(UINT32 bspChn, UINT32 radioMode, UINT32 carrIndex, UINT32 trx, INT32 isOn);
UINT32 BspGetCarrGainSw(UINT32 bspChn,UINT32 radioMode,UINT32 carrIndex,UINT32 trx,INT32 *pIsOn);
UINT32 BspSetTxPcCarrGain(UINT32 bspChn, UINT32 carrIndex,INT32 gain, UINT32 radioMode);
UINT32 BspGetTxPcCarrGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 *pcarrGain);
UINT32 BspSetMixGain(UINT32 bspChn, UINT32 band, INT32 gain);
UINT32 BspGetMixGain(UINT32 bspChn, UINT32 band, INT32 *pGain);
UINT32 BspSetKfGain(UINT32 bspChn, INT32 gain);
UINT32 BspGetKfGain(UINT32 bspChn, INT32 *pGain);
UINT32 BspSetKdGain(UINT32 bspChn, INT32 gain);
UINT32 BspGetKdGain(UINT32 bspChn, INT32 *pGain);
UINT32 BspGetTxCarrGain(UINT32 ulBspChnl, UINT32 ulPhyCarr, INT32 *plCarrGain);
UINT32 BspSetTxUmtsAgcCfg(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, T_BspHalAdaptUmtsTxAgcCfg *umtsTxAgcCfg);
UINT32 BspSetRxUmtsAgcInit(T_UmtsDagcInfo *umtsRxDagcInfo);
UINT32 BspSetRxPcGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 gain);
UINT32 BspGetRxPcGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain);
UINT32 BspGetChanCarrNum(UINT32 dir,UINT32 chan);
UINT32 BspGetRxPcGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 *pGain);
UINT32 BspGetIcUlPostGain(UINT32 bspChn,UINT32 carrIndex, UINT32 radioMode, INT32 *preAtt);
UINT32 BspGetVgaCompGain(UINT32 ulBspChnl, UINT32 ulPhyCarr, INT32 *plCarrGain);
UINT32 BspGetTsgGain(UINT32 chan, INT32 *pGain);
UINT32 BspGetKnGainMax(UINT32 chan, INT32 *pGain);
UINT32 BspGetGainCommPara(T_GainCommPara *pGainCommPara);
UINT32 BspSetGainCommPara(T_GainCommPara *pGainCommPara);
UINT32 BspSetTxBbtssiGain(UINT32 bspChn, UINT32 carr, UINT32 radioMode, UINT32 carrPow);
UINT32 BspGetCarrBalanceGain(UINT32 bspChn, UINT32 carr, INT32 *gain);
#ifdef __cplusplus
}
#endif

#endif /* ITRANAAU_PLATFORM_BSP_FUNCLIB_GAINCTRL_GAINCTRL_IC4_2_INCLUDE_GAINCTRL_IC4_2_H_ */

/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : gainctrl_ic4_2_debug.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了增益控制调试接口定义
* 注意事项 : 无
* 作    者 :   10307448
* 创建日期 : 2022-01-20
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10307448
* 修改日戳: 2022-01-20
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "gainctrl_ic4_2_debug.h"
#include "gainctrl_ic4_2.h"
#include "devdrv_att.h"
#include "freqcfgcommon.h"

/*****************************************************************************
*  函数名称   : showgain
*  功能描述   : 链路增益显示
*  输入参数   : radioMode：载波制式
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-26, 创建
*----------------------------------------------------------------------------
*/
UINT32 showgain(UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    UINT32 loop = 0;
    UINT32 chan = 0;
    INT32 gain = 0;
    UINT32 radio = 0;
    UINT32 carrNo = 0;
    UINT32 txChanNum = 0;
    UINT32 rxChanNum = 0;
    char   temp[32] = {0};
    INT32  snprtRet = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    struct 
    {
        const char *pDesc;
        INT32  *buf;
        UINT32 (*pGetAtt)(UINT32 chan,INT32 *attVal);
        UINT32 chanNum;
    } attInfo[] = {
        {"preCfrGain" , NULL, BspHalAdaptGetK0Gain, BspGetTxChannel()},
        {"preDpdGain",  NULL, BspGetKfGain,         BspGetTxChannel()},
        {"KdGain",      NULL, BspGetKdGain,         BspGetTxChannel()},
    };

    attshow();
    txChanNum = BspGetTxChannel();
    rxChanNum = BspGetRxChannel();
    
    for (loop = 0; loop < NELEMENTS(attInfo); loop++)
    {
        attInfo[loop].buf = malloc(attInfo[loop].chanNum*sizeof(INT32));
        if (attInfo[loop].buf)
        {
            memset(attInfo[loop].buf,0xff,attInfo[loop].chanNum*sizeof(INT32));
            for (chan = 0; chan < attInfo[loop].chanNum; chan++)
            {
                attInfo[loop].pGetAtt(chan, &attInfo[loop].buf[chan]);
            }
            
            RedirPrintf("%-10s: ", attInfo[loop].pDesc);
            for (chan = 0; chan < attInfo[loop].chanNum; chan++)
            {
                snprtRet = snprintf_s(temp,sizeof(temp),"[%d]%d\0",chan,attInfo[loop].buf[chan]);
                SNPRINTF_S_CHECK(snprtRet, sizeof(temp));
                RedirPrintf("%-10s%s",temp,((chan+1)%8)?" ":"\n        ");
            }
            RedirPrintf("\n");

            free(attInfo[loop].buf);
        }
        else
        {
            dbgErr("get %s malloc failed\n",attInfo[loop].pDesc);
        }
    }

    for (chan = 0; chan < txChanNum; chan++)
    {
        pRfCfg = GetRfCfgPara(chan, TX);
        if(NULL == pRfCfg)
        {
            continue;
        }

        RedirPrintf("%-8s(chn%d): ", "txPcGain", chan);
        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            carrNo = pRfCfg->para.carrInfo[loop].carrNo;
            radio = pRfCfg->para.carrInfo[loop].radioMode;

            retVal |= BspGetTxPcGain(chan, carrNo, radio, &gain);

            RedirPrintf("[c%d/0x%x]%d\0", carrNo, radio, gain);
            RedirPrintf("%-1s%s"," ",((chan+1)%8)?" ":"\n        ");
        }
        RedirPrintf("\n");
    }

    for (chan = 0; chan < rxChanNum; chan++)
    {
        pRfCfg = GetRfCfgPara(chan, RX);
        if(NULL == pRfCfg)
        {
            continue;
        }

        RedirPrintf("%-8s(chn%d): ", "rxPcGain", chan);
        for (loop = 0; loop < pRfCfg->para.carrNum; loop++)
        {
            carrNo = pRfCfg->para.carrInfo[loop].carrNo;
            radio = pRfCfg->para.carrInfo[loop].radioMode;

            retVal |= BspGetRxPcGain(chan, carrNo, radio, &gain);

            RedirPrintf("[c%d/0x%x]%d\0", carrNo, radio, gain);
            RedirPrintf("%-1s%s"," ",((chan+1)%8)?" ":"\n        ");
        }
        RedirPrintf("\n");
    }

    return retVal;
}
  
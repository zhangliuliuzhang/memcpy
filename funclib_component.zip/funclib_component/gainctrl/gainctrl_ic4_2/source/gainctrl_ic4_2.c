/*****************************************************************************
* 版权所有(C) 2021, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : gainctrl_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了DPDIC4.2增益控制模块接口
* 注意事项 : 无
* 作    者 : 徐利波10307448
* 创建日期 : 2021-12-13
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 徐利波10307448
* 修改日戳: 2021-12-13
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include <math.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"
#include "gainctrl_ic4_2.h"
#include "chnmap_a.h"
#include "devdrv_att.h"
#include "funccommon.h"
#include "freqcfgcommon.h"

static UINT32 gs_gainCtrlPreAttMode = GAIN_CTRL_NOT_EMBODY_PREATT;
/* static INT32  s_preAtt[BSP_MAX_RX_CHAN] = {0}; */
static UINT32 s_gainCtrlDerateRefVal = 0;
T_GainCommPara *s_pGainCommPara = NULL;
static INT32 s_carrBalanceGain[BSP_IC42_MAX_TX_CHAN_NUM][BSP_MAX_CARR_NUM] = {0};

/*****************************************************************************
*  函数名称   : BspSetGainCtrlPreAttMode
*  功能描述   : 设置增益控制预衰模式
*  输入参数   : gainCtrlVer：增益版本
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-5, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetGainCtrlPreAttMode(UINT32 gainCtrlPreAttMode)
{
    gs_gainCtrlPreAttMode = gainCtrlPreAttMode;
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetGainCtrlPreAttMode
*  功能描述   : 获取增益控制预衰模式
*  输入参数   : 无
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 用于基带rssi分载波功率计算
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-5, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetGainCtrlPreAttMode()
{
    return gs_gainCtrlPreAttMode;
}

/*****************************************************************************
*  函数名称   : BspSetRxPcPreAtt
*  功能描述   : 设置上行分载att
*  输入参数   : chan：通道号
               preAtt：增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 上行开环定标中设置预衰
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-2-7, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxPcPreAtt(UINT32 chan, INT32 preAtt)
{
#if 0
    if (chan >= BspGetRxChanNum())
    {
        dbgInfoEx("chan=%d overload!\n", chan);
        return BSP_ERROR;
    }
    s_preAtt[chan] = preAtt;
#endif
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetRxCarrGain
*  功能描述   : 获取上行分载波增益
*  输入参数   : bspChn：BSP通道号
               carrIndex：载波ID
*  输出参数   : gain：增益值
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 仅被维测接口showgain调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-2-7, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxCarrGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 *gain)
{
    INPUT_POINTER_CHECK(gain);
    return BspGetRxPcGain(bspChn,carrIndex,radioMode,gain);
}

/*****************************************************************************
*  函数名称   : BspGetTxPcGain
*  功能描述   : 获取分载波增益
*  输入参数   : chan：BSP通道号
               carr：载波号
               radioMode：载波制式
*  输出参数   : pGain：分载波增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-28, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetTxPcGain(UINT32 chan, UINT32 carr, UINT32 radioMode, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    INT32 dlBankDgain = 0;
    T_GainCommPara gainCommPara = {0};

    INPUT_POINTER_CHECK(pGain);

    if(BspGetDifInfoByBspChn(chan,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: DifInfoByBspChn Get Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    retVal |= BspGetGainCommPara(&gainCommPara);
    retVal = BspHalAdaptGetDlbankDgain(difChan, carr, radioMode, &dlBankDgain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: chan'%d carr'%d radio'%d Get Tx carr gain Err!\n", __FUNCTION__, __LINE__,chan,carr,radioMode);
        BspLog(LOG_LEVEL_0,"[%s]: chan'%d carr'%d radio'%d Get Tx carr gain Err! gain=%d.\n", __FUNCTION__, chan,carr,radioMode,*pGain);
        return BSP_ERROR;
    }

    if(dlBankDgain == GAIN_INVALID) /*GAIN_INVALID*/
    {
        retVal = BSP_ERROR;
        dbgErr("[%s] get carr gain error, gain is zero!", __FUNCTION__);
    }
    else
    {
        *pGain = dlBankDgain - gainCommPara.dlBankDgain[difChan];
    }
    dbgInfoEx("[%s] chan'%d carr'%d radio'%d gain'%d dlBankDgain'%d dlBankDgainPreGain'%d !\n", __FUNCTION__, chan,carr,radioMode,*pGain,dlBankDgain,gainCommPara.dlBankDgain[difChan]);
        //BspLog(LOG_LEVEL_0,"[%s] chan'%d carr'%d radio'%d gain'%d dlBankDgain'%d dlBankDgainPreGain!\n", __FUNCTION__, chan,carr,radioMode,*pGain,dlBankDgain,gainCommPara.dlBankDgain[difChan]);
    
    
#if 0
    if ((radioMode == RADIO_STANDARD_GSM) || (radioMode == RADIO_STANDARD_NB_IOT)
        || (radioMode == RADIO_STANDARD_UMTS))
    {
        retVal = BspHalAdaptGetDlpreGain(difChan, carr, radioMode, pGain);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: Get Tx carr gain Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_LEVEL_0,"[%s]: Get Tx carr gain Err! gain=%d.\n", __FUNCTION__, *pGain);
            return BSP_ERROR;
        }
    }
    else
    {
        retVal = BspHalAdaptGetDlbankAptune(difChan, carr, radioMode, pGain);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: Get Tx carr gain Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_LEVEL_0,"[%s]: Get Tx carr gain Err! gain=%d.\n", __FUNCTION__, *pGain);
            return BSP_ERROR;
        }
    }
#endif
    return retVal;
}

UINT32 BspSetCarrBalanceGain(UINT32 bspChn, UINT32 carr, INT32 gain)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    if((bspChn >= BSP_IC42_MAX_TX_CHAN_NUM) ||(carr >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }
    if(BspGetDifInfoByBspChn(bspChn,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    s_carrBalanceGain[difChan][carr] = gain;
    return BSP_OK;
}

UINT32 BspGetCarrBalanceGain(UINT32 bspChn, UINT32 carr, INT32 *gain)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(gain);
    if((bspChn >= BSP_IC42_MAX_TX_CHAN_NUM) ||(carr >= BSP_MAX_CARR_NUM))
    {
        return BSP_ERROR;
    }
    if(BspGetDifInfoByBspChn(bspChn,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    *gain = s_carrBalanceGain[difChan][carr];
    return BSP_OK;
}

/* Started by AICoder, pid:71a2b95a1be470c1401b0aa2c05b02273bf270d2 */
static UINT32 BspSetCarrBalanceAptuneGain(UINT32 bspChn, UINT32 carr, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;

    if(POWER_UNIT_UW == BspGetPowerUnit())
    {
        if((bspChn >= BSP_IC42_MAX_TX_CHAN_NUM) ||(carr >= BSP_MAX_CARR_NUM))
        {
            return BSP_ERROR;
        }
        retVal = BspHalAdaptSetDlbankAptune(bspChn, carr, radioMode, s_carrBalanceGain[bspChn][carr]);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: set aptune gain Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d aptune = %d: set aptune gain Err!\n",
                    __FUNCTION__,__LINE__,bspChn, carr, radioMode, s_carrBalanceGain[bspChn][carr]);
        }
    }

    return retVal;
}
/* Ended by AICoder, pid:71a2b95a1be470c1401b0aa2c05b02273bf270d2 */

/*****************************************************************************
*  函数名称   : BspSetTxPcGain
*  功能描述   : 设置分载波增益
*  输入参数   : bspChn：BSP通道号
               carr：载波号
               radioMode：载波制式
               gain：增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 被APP调用。
               功能：1)分载波增益调节；2)降额（过驻波降额,电源过载降额,过温降额）
               1、FDD：UMTS不需配分载增益；G和NB载波分载增益及U的降额在TDM配置；
                  FDD_LTE、FDD_NR分载增益使用dlbank的aptune配置。
               2、TDD：TDD_LTE 和 TDD_NR均不需要配置分载波增益。
               3、分载波降额，使用分载波增益配置节点。
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-28, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetTxPcGain(UINT32 bspChn, UINT32 carr, UINT32 radioMode, INT32 gain)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    INT32 bbtssiGain = 0;
    INT32 dlPreGain = 0;
    INT32 dlBankDgain = 0;
    INT32 dlCfrGain = 0;
    INT32 dlBankAPtuneGain = 0;
    T_GainCommPara gainCommPara = {0};

    if(BspGetDifInfoByBspChn(bspChn,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: DifInfoByBspChn Get Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    
    if(gain == GAIN_INVALID)  /*GAIN_INVALID*/
    {
        dlBankDgain = GAIN_INVALID;
        bbtssiGain = GAIN_INVALID;
        dlPreGain = GAIN_INVALID;
    }
    else
    {
        retVal |= BspGetGainCommPara(&gainCommPara);
        dlBankDgain = gainCommPara.dlBankDgain[difChan] + gain;
        dlCfrGain = gainCommPara.preCfrGain[difChan];
        dlBankAPtuneGain = gainCommPara.dlBankApTuneGain[difChan];
        bbtssiGain = (dlBankAPtuneGain + dlBankDgain + dlCfrGain)* 2;
        dlPreGain = gainCommPara.dlPreGain[difChan];
    }
    
    retVal |= BspHalAdaptSetDlpreBbtssiGain(difChan, carr, radioMode, bbtssiGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set dlpre bbtssi gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d bbtssiGain = %d: set dlpre bbtssi gain Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, bbtssiGain);
        
    }
    retVal |= BspHalAdaptSetDlpreGain(difChan, carr, radioMode, dlPreGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set dlpre gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d dlPreGain = %d: set dlpre gain Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, dlPreGain);
        
    }
    retVal |= BspHalAdaptSetDlbankDgain(difChan, carr, radioMode, dlBankDgain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set dlbank gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d dlBankDgain = %d: set dlbank gain Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, dlBankDgain);
        
    }

    retVal |= BspSetCarrBalanceAptuneGain(difChan, carr, radioMode);

    dbgInfo("[%s] chan'%d carr'%d radio'%d set Tx carr gain dlPreGain'%d bbtssiGain'%d dlBankAPtuneGain'%d dlBankDgain'%d dlCfrGain'%d !\n",
                    __FUNCTION__,bspChn,carr,radioMode,dlPreGain,bbtssiGain,dlBankAPtuneGain,dlBankDgain,dlCfrGain);
    BspLog(LOG_LEVEL_0,"[%s] chan'%d carr'%d radio'%d set Tx carr gain dlPreGain'%d bbtssiGain'%d dlBankAPtuneGain'%d dlBankDgain'%d dlCfrGain'%d !\n",
                    __FUNCTION__,bspChn,carr,radioMode,dlPreGain,bbtssiGain,dlBankAPtuneGain,dlBankDgain,dlCfrGain); 
#if 0
    if ((radioMode == RADIO_STANDARD_GSM) || (radioMode == RADIO_STANDARD_NB_IOT)
        || (radioMode == RADIO_STANDARD_UMTS))
    {
        /* bbtssi增益配置用于削峰模块，确保削峰入口的单载波功率与检测功率相等 */
        bbtssiGain = gainCommPara.preCfrGain[difChan] * 2;

        retVal |= BspHalAdaptSetDlpreBbtssiGain(difChan, carr, radioMode, bbtssiGain);
        retVal |= BspHalAdaptSetDlpreGain(difChan, carr, radioMode, gain);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: set Tx carr gain Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_LEVEL_0,"[%s]: set Tx carr gain Err! gain=%d.\n", __FUNCTION__, gain);
            return BSP_ERROR;
        }
    }
    else
    {
        /* bbtssi增益配置用于削峰模块，确保削峰入口的单载波功率与检测功率相等 */
        bbtssiGain = (gain + gainCommPara.preCfrGain[difChan]) * 2;

        retVal |= BspHalAdaptSetDlpreBbtssiGain(difChan, carr, radioMode, bbtssiGain);
        retVal |= BspHalAdaptSetDlbankAptune(difChan, carr, radioMode, gain);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: set Tx carr gain Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_LEVEL_0,"[%s]: set Tx carr gain Err! gain=%d.\n", __FUNCTION__, gain);
            return BSP_ERROR;
        }
    }
#endif
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetTxPcGain
*  功能描述   : 设置分载波增益
*  输入参数   : bspChn：BSP通道号
               carr：载波号
               radioMode：载波制式
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 在BspSetCarrPow调用。
               功能：启用cfr，需要配置BBTSSI增益
*----------------------------------------------------------------------------*/
UINT32 BspSetTxBbtssiGain(UINT32 bspChn, UINT32 carr, UINT32 radioMode, UINT32 carrPow)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    INT32 bbtssiGain = 0;
    INT32 dlPreGain = 0;
    INT32 dlBankDgain = 0;
    INT32 dlCfrGain = 0;
    INT32 dlBankAPtuneGain = 0;
    T_GainCommPara gainCommPara = {0};

    if(BspGetDifInfoByBspChn(bspChn,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: DifInfoByBspChn Get Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal |= BspGetGainCommPara(&gainCommPara);
    dlBankDgain = gainCommPara.dlBankDgain[difChan];
    dlCfrGain = gainCommPara.preCfrGain[difChan];
    dlBankAPtuneGain = gainCommPara.dlBankApTuneGain[difChan];
    bbtssiGain = (dlBankAPtuneGain + dlBankDgain + dlCfrGain)* 2;
    dlPreGain = gainCommPara.dlPreGain[difChan];

    if((0 == carrPow) && (BSP_RADIO_STANDARD_UMTS == radioMode))
    {
        bbtssiGain = GAIN_INVALID;
        dlPreGain = GAIN_INVALID;
    }

    retVal |= BspHalAdaptSetDlpreBbtssiGain(difChan, carr, radioMode, bbtssiGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set dlpre bbtssi gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d bbtssiGain = %d: set dlpre bbtssi gain Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, bbtssiGain);
        
    }
    retVal |= BspHalAdaptSetDlpreGain(difChan, carr, radioMode, dlPreGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set dlpre gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d dlPreGain = %d: set dlpre gain Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, dlPreGain);
        
    } 

    dbgInfo("[%s] chan'%d carr'%d radio'%d set Tx carr gain dlPreGain'%d bbtssiGain'%d dlBankAPtuneGain'%d dlCfrGain'%d !\n",
                    __FUNCTION__,bspChn,carr,radioMode,dlPreGain,bbtssiGain,dlBankAPtuneGain,dlCfrGain);
    BspLog(LOG_LEVEL_0,"[%s] chan'%d carr'%d radio'%d set Tx carr gain dlPreGain'%d bbtssiGain'%d dlBankAPtuneGain'%d dlCfrGain'%d !\n",
                    __FUNCTION__,bspChn,carr,radioMode,dlPreGain,bbtssiGain,dlBankAPtuneGain,dlCfrGain);

    return retVal;
}


/*****************************************************************************
*  函数名称   : BspSetTxPcGainAll
*  功能描述   : 设置所有分载波增益
*  输入参数   : carr：载波号
               radioMode：载波制式
               gain：增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-28, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetTxPcGainAll(UINT32 carr, UINT32 radioMode, INT32 gain)
{
    UINT32 loop = 0;
    INT32 pcGain = gain*10;
    UINT32 chnNum = BspGetTxChannel();
    UINT32 retVal = BSP_OK;

    for (loop = 0; loop < chnNum; loop++)
    {
       retVal |=  BspSetTxPcGain(loop, carr, radioMode, pcGain);
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetCarrGainSw
*  功能描述   : 设置载波增益开关
*  输入参数   : bspChn：BSP通道号
               carr：载波号
               radioMode：载波制式
               trx：链路方向
               isOn：数据状态 1：打开 0：关断
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-28, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetCarrGainSw(UINT32 bspChn, UINT32 radioMode, UINT32 carr, UINT32 trx, INT32 isOn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    if(BspGetDifInfoByBspChn(bspChn,trx,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(trx == TX)
    {
        retVal = BspHalAdaptSetDlCarrGainSw(difChan, radioMode, carr, isOn);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: set dlCarr gain SW Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d sw = %d: set dlCarr gain SW Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, isOn);
            return retVal;
        }        
    }
    else
    {
        retVal = BspHalAdaptSetUlCarrGainSw(difChan, radioMode, carr, isOn);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: set ulCarr gain SW Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d sw = %d: set ulCarr gain SW Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, isOn);
            return retVal;
        } 
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetCarrGainSw
*  功能描述   : 获取载波增益开关
*  输入参数   : bspChn：BSP通道号
               carr：载波号
               radioMode：载波制式
               trx：链路方向
*  输出参数   : pIsOn：开关状态：0：on，1：off
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-28, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetCarrGainSw(UINT32 bspChn,UINT32 radioMode,UINT32 carr,UINT32 trx,INT32 *pIsOn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(pIsOn);

    if(BspGetDifInfoByBspChn(bspChn,trx,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(trx == TX)
    {
        retVal = BspHalAdaptGetDlCarrGainSw(difChan, radioMode, carr, pIsOn);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: get dlCarr gain SW Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d sw = %d: get dlCarr gain SW Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, pIsOn);
            return retVal;
        } 
    }
    else
    {
        retVal = BspHalAdaptGetUlCarrGainSw(difChan, radioMode, carr, pIsOn);
        if(retVal != BSP_OK)
        {
            dbgErr("[%s] line %d: get ulCarr gain SW Err!\n", __FUNCTION__, __LINE__);
            BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d sw = %d: get ulCarr gain SW Err!\n", __FUNCTION__,__LINE__,difChan, carr, radioMode, pIsOn);
            return retVal;
        } 
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetTxPcCarrGain
*  功能描述   : 设置下行分载波增益
*  输入参数   : bspChn：BSP通道号
               carrIndex：载波号
               radioMode：载波制式
               gain：载波增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 分载波功率均衡功能（4.2不再具备该调节点）；被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetTxPcCarrGain(UINT32 bspChn, UINT32 carrIndex,INT32 gain, UINT32 radioMode)
{
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetTxPcCarrGain
*  功能描述   : 获取下行分载波增益
*  输入参数   : chan：BSP通道号
               carrIndex：载波号
               radioMode：载波制式
*  输出参数   : pcarrGain：载波增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : IC4.2不再具备分载波增益均衡调节点；被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetTxPcCarrGain(UINT32 chan, UINT32 carrIndex, UINT32 radioMode, INT32 *pcarrGain)
{
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetTxPcCarrGainEn
*  功能描述   : 获取下行分载波增益使能
*  输入参数   : bspChn：BSP通道号
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : IC4.2不再具备分载波增益均衡调节点；被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetTxPcCarrGainEn(UINT32 bspChn)
{
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspSetMixGain
*  功能描述   : 设置进入CFR时的增益
*  输入参数   : chan：BSP通道号
               band：频段号
               gain：增益，0.01dbfs
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetMixGain(UINT32 chan, UINT32 band, INT32 gain)
{
    UINT32 difId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;

    if(BspGetDifInfoByBspChn(chan,TX,&difId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptSetK0Gain(difChan,gain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set k0 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: set k0 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetMixGain
*  功能描述   : 获取进入CFR时的增益
*  输入参数   : chan：BSP通道号
               band：频段号
*  输出参数   : gain：增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetMixGain(UINT32 chan, UINT32 band, INT32 *pGain)
{
    UINT32 difChipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pGain);

    if(BspGetDifInfoByBspChn(chan, TX, (UINT32*)&difChipId, (UINT32*)&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetK0Gain(difChan,pGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: get k0 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get k0 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s]: k0 gain is %d\n",__FUNCTION__, *pGain);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetMixGainDiff
*  功能描述   : 设置异厂家进入CFR时的增益
*  输入参数   : bspChn：BSP通道号
               freqBand：频段号
               gain：增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-05-26, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetMixGainDiff(UINT32 bspChn, UINT32 freqBand, INT32 gain)
{
    UINT32 difId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;

    if(BspGetDifInfoByBspChn(bspChn,TX,&difId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptSetK0GainDiff(difChan, gain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set k0 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: set k0 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetMixGainDiff
*  功能描述   : 获取异厂家进入CFR时的增益
*  输入参数   : bspChn：BSP通道号
               freqBand：频段号
*  输出参数   : gain：增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-05-26, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetMixGainDiff(UINT32 bspChn, UINT32 freqBand, INT32 *pGain)
{
    UINT32 difChipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pGain);

    if(BspGetDifInfoByBspChn(bspChn, TX, (UINT32*)&difChipId, (UINT32*)&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetK0GainDiff(difChan,pGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: get k0 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get k0 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s]: k0 gain is %d\n",__FUNCTION__, *pGain);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetKfGain
*  功能描述   : 设置进入DPD时的增益
*  输入参数   : chan：BSP通道号
               gain：增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetKfGain(UINT32 chan, INT32 gain)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    if(BspGetDifInfoByBspChn(chan,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptSetK1Gain(difChan,gain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set k1 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: set k1 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetKfGain
*  功能描述   : 获取进入DPD时的增益
*  输入参数   : chan：BSP通道号
*  输出参数   : pGain：增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetKfGain(UINT32 chan, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(pGain);

    if(BspGetDifInfoByBspChn(chan,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetK1Gain(difChan, pGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: get k1 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get k1 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s]: k1 gain is %d\n",__FUNCTION__, *pGain);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetKdGain
*  功能描述   : 设置合载波闭环功控数字域增益值
*  输入参数   : chan：BSP通道号
               gain：增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 此处进行增益的精调整；被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetKdGain(UINT32 chan, INT32 gain)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    if(BspGetDifInfoByBspChn(chan,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    BspLog(LOG_LEVEL_1, "[%s]: difChan:%d gain:%d!\n", __FUNCTION__, difChan, gain);
    retVal = BspHalAdaptSetK2Gain(difChan,gain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set k2 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: set k2 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetKdGain
*  功能描述   : 获取合载波闭环功控数字域增益值
*  输入参数   : chan：BSP通道号
*  输出参数   : pGain：增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetKdGain(UINT32 chan, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(pGain);

    if(BspGetDifInfoByBspChn(chan,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetK2Gain(difChan,pGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: get k2 gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get k2 gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s]: k2 gain is %d\n",__FUNCTION__, *pGain);
    BspLog(LOG_LEVEL_1, "[%s]: difChan:%d gain:%d!\n", __FUNCTION__, difChan, *pGain);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetTxCarrGain
*  功能描述   : 获取载波增益
*  输入参数   : bspChn：BSP通道号
               carrIndex：载波号
*  输出参数   : plCarrGain：增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 被APP调用
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-12, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetTxCarrGain(UINT32 ulBspChnl, UINT32 ulPhyCarr, INT32 *plCarrGain)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulGetCarrRadio = 0;
    UINT32 ulCarrRadioStd = 0;
    UINT32 ulLogicCarrNo  = 0;

    INPUT_POINTER_CHECK(plCarrGain);

    ulLogicCarrNo = ulPhyCarr;
    ulGetCarrRadio = BspGetCarrMode(TX, ulBspChnl, ulLogicCarrNo);
    if (BSP_ERROR != ulGetCarrRadio)
    {
        ulCarrRadioStd = ulGetCarrRadio;
    }
    else
    {
        ulCarrRadioStd = 0x2000; // BSP_RADIO_STANDARD_5G;
    }

    ulRetVal = BspGetTxPcGain(ulBspChnl, ulLogicCarrNo, ulCarrRadioStd, plCarrGain);
    dbgInfoEx("%s>>BspChnl'%2d carr'%d Radio'0x%04X: Ret(0:OK)= 0x%02X; TxCarrGain= %d\n",
              __FUNCTION__, ulBspChnl, ulPhyCarr, ulCarrRadioStd, ulRetVal, *plCarrGain);

    return ulRetVal;
}

/*****************************************************************************
*  函数名称   : BspGetVgaCompGain
*  功能描述   : 获取VGA增益
*  输入参数   : bspChn：BSP通道号
               carrIndex：载波ID
*  输出参数   : plCarrGain：增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 仅用于维测接口，待完善
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-2-7, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetVgaCompGain(UINT32 bspChn, UINT32 carrIndex, INT32 *plCarrGain)
{
    INPUT_POINTER_CHECK(plCarrGain);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetVgaCompGain
*  功能描述   : 获取测试信号增益
*  输入参数   : bspChn：BSP通道号
*  输出参数   : pGain：增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 用于维测接口，待完善
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-2-7, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetTsgGain(UINT32 bspChn, INT32 *pGain)
{
    INPUT_POINTER_CHECK(pGain);
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetIcUlPostGain
*  功能描述   : 获取上行post增益
*  输入参数   : bspChn：BSP通道号
               carrIndex：载波ID
*  输出参数   : preAtt：前向增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 仅用于showgain维测接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-2-7, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetIcUlPostGain(UINT32 bspChn,UINT32 carrIndex, UINT32 radioMode, INT32 *preAtt)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChn = 0;
    INT32 vgaUlpostfacx = 0;

    INPUT_POINTER_CHECK(preAtt);
    *preAtt = 0;

    if(BspGetDifInfoByBspChn(bspChn, RX, &chipId, &difChn) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

#if 0
    vgaUlpostfacx = getVgaCompCarrFacxByTdmPos(chipId,tdmId,tdmPos);
#endif

    retVal = BspHalAdaptGetRxVgaGain(difChn, radioMode, carrIndex, &vgaUlpostfacx);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: get ulpost gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get ulpost gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    
    *preAtt = vgaUlpostfacx * 10;  //0.1db * 10 => 0.01db

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetTxUmtsAgcCfg
*  功能描述   : 设置下行UMTS自动增益控制
*  输入参数   : bspChn：BSP通道号
               carrIndex：载波号
               radioMode：载波制式
               umtsTxAgcCfg：UMTS的AGC配置信息
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 该配置节点位于dl_pre的tdm通道
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-24, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetTxUmtsAgcCfg(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, T_BspHalAdaptUmtsTxAgcCfg *umtsTxAgcCfg)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(umtsTxAgcCfg);

    if(BspGetDifInfoByBspChn(bspChn,TX,&chipId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptSetTxUmtsAgcCfg(difChan, carrIndex, radioMode, umtsTxAgcCfg);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set Tx umts agc gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: set Tx umts agc gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetRxUmtsAgcInit
*  功能描述   : 设置上行UMTS的AGC初始化配置
*  输入参数   : bspChn：BSP通道号
               carrIndex：载波号
               radioMode：载波制式
               umtsTxAgcCfg：UMTS的AGC配置
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 该配置节点位于dl_pre的tdm通道
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-25, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxUmtsAgcInit(T_UmtsDagcInfo *umtsRxDagcInfo)
{
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(umtsRxDagcInfo);

    retVal = BspHalAdaptSetUmtsDagcInit(umtsRxDagcInfo);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set Rx umts agc gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: set Rx umts agc gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspSetRxPcGain
*  功能描述   : 设置上行分载波增益
*  输入参数   : chan：BSP通道号
               carr：载波号
               radioMode：载波制式
               gain：增益
*  输出参数   : 无
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-24, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSetRxPcGain(UINT32 chan, UINT32 carr, UINT32 radioMode, INT32 gain)
{
    UINT32 difId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;

    if(BspGetDifInfoByRfChn(chan,RX,&difId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptSetUlbankAptune(difChan,carr , radioMode, gain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: set Rx Pc gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: set Rx Pc gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetRxPcGain
*  功能描述   : 获取上行分载波增益
*  输入参数   : chan：BSP通道号
               carr：载波号
               radioMode：载波制式
*  输出参数   : pGain：分载波增益
*  返 回 值   : BSP_OK - 成功; 其它值为失败
*  其它说明   : 用于维测接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-24, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetRxPcGain(UINT32 chan, UINT32 carr, UINT32 radioMode, INT32 *pGain)
{
    UINT32 difId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pGain);

    if(BspGetDifInfoByRfChn(chan,RX,&difId,&difChan) != BSP_OK)
    {
        dbgErr("[%s] line %d: get difChan Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get difChan Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetUlbankAptune(difChan, carr, radioMode, pGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] line %d: get Rx Pc gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get Rx Pc gain Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetChanCarrNum
*  功能描述   : 获取通道载波数
*  输入参数   : dir：链路方向
               chan：BSP通道号
*  输出参数   : 无
*  返 回 值   : carrNum：通道载波数
*  其它说明   : 用于维测接口
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 徐利波@2022-1-24, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetChanCarrNum(UINT32 dir,UINT32 chan)
{
    T_ChanRfCfgPara *pRfCfg = NULL;
    UINT32 carrNum = 0;

    pRfCfg = GetRfCfgPara(chan,dir);
    if(NULL == pRfCfg)
    {
        dbgErr("[%s] line %d: get pRfCfg Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_LEVEL_0,"[%s]: get pRfCfg Err!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    carrNum = pRfCfg->para.carrNum;
    return carrNum;
}

/**  获取增益公共参数  **/
UINT32 BspGetGainCommPara(T_GainCommPara *pGainCommPara)
{
    if(s_pGainCommPara == NULL)
	{
        dbgInfo("[%s] s_pGainCommPara is not initialized！\n", __FUNCTION__);
		return BSP_ERROR;
	}
    memcpy_s(pGainCommPara, sizeof(T_GainCommPara), s_pGainCommPara, sizeof(T_GainCommPara));

    return BSP_OK;
}

VOID showGainCommPara(VOID)
{
    UINT32 difChan          = 0;

    INT32 dlPreGain0        = 0;
    INT32 dlBankAPtuneGain1 = 0;
    INT32 dlBankDgain2      = 0;
    INT32 dlCfrGain3        = 0;
    INT32 bbtssiGain4       = 0;
    T_GainCommPara gainCommPara = {0};

    (VOID)BspGetGainCommPara(&gainCommPara);
    while(difChan < BspGetTxChanNum())
    {
        dlPreGain0         = gainCommPara.dlPreGain[difChan];

        dlBankAPtuneGain1 = gainCommPara.dlBankApTuneGain[difChan];
        dlBankDgain2      = gainCommPara.dlBankDgain[difChan];
        dlCfrGain3        = gainCommPara.preCfrGain[difChan];
        bbtssiGain4       = (dlBankAPtuneGain1 + dlBankDgain2 + dlCfrGain3)* 2;
        dbgInfo("[%s] chan %d dlPreGain0 %d dlBankAPtuneGain1 %d dlBankDgain2  %d dlCfrGain3  %d bbtssiGain4 %d\n", 
                __FUNCTION__, difChan, dlPreGain0, dlBankAPtuneGain1, dlBankDgain2, dlCfrGain3, bbtssiGain4);
        difChan++;
    }

}

/**  配置增益公共参数  **/
UINT32 BspSetGainCommPara(T_GainCommPara *pGainCommPara)
{
    INPUT_POINTER_CHECK(pGainCommPara);
    s_pGainCommPara = pGainCommPara;

    return BSP_OK;
}

UINT32 BspGetKnGainMax(UINT32 chan, INT32 *pGain)
{
    UINT32 retVal=BSP_OK;
    *pGain = 50;
    return retVal;
}

/*BSP提供PC gain上电初始化增益给APP作为增益基准值，TDD上电默认为0*/
UINT32 BspSetDerateRefVal(UINT32 chn, UINT32 carrNo, UINT32 radioMode, UINT32 refGain)
{
    s_gainCtrlDerateRefVal = refGain;
    return BSP_OK;
}

UINT32 BspGetDerateRefVal(UINT32 chn, UINT32 carrNo, UINT32 radioMode, UINT32 *refGain)
{
    INPUT_POINTER_CHECK(refGain);
    *refGain = s_gainCtrlDerateRefVal;
    return BSP_OK;
}

UINT32 BspSetInherentGain(UINT32 uiDifChan, UINT32 uiRadioMode, UINT32 uiCarrNo, INT32 iPreAtt)
{
	return BspHalAdaptSetInherentGain(uiDifChan,uiRadioMode,uiCarrNo,iPreAtt);
}

UINT32 BspSetK0GainByDelt(UINT32 chan, UINT32 uBand, INT32 delt)
{
    return BSP_OK;
}

/* Started by AICoder, pid:439e403663x33b1142840a81908c9052bf36be5a */
/* 本接口调整角度为绝对值,不是增量;4096为IC寄存器默认值,实部4096且虚部0是不调整 */
UINT32 BspSetCarrGainWithAngle(UINT32 bspChan, UINT32 carrNo, UINT32 radio, INT32 angleId)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 chipidx = 0;
    INT32 realCoef = 4096;
    INT32 imagCoef = 0;

    retVal |= BspGetDifInfoByBspChn(bspChan, TX, &chipidx, &difChn);
    if(BSP_OK != retVal)
    {
        dbgInfoEx("[%s] bspChan'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    if(CARR_GAIN_ANGLE_P90_DEG == angleId)
    {
        realCoef = 0;
        imagCoef = 4096;
    }

    if(CARR_GAIN_ANGLE_N90_DEG == angleId)
    {
        realCoef = 0;
        imagCoef = -4096;
    }

    retVal |= BspHalAdaptSetDlbankAptuneWithPhase(difChn, carrNo, radio, realCoef, imagCoef);
    BspLog(LOG_LEVEL_0,"[%s] chan'%u, carrNo'%u, radio'0x%x, angleId'%d, realCoef'%d, imagCoef'%d, retVal'%d \n",
            __FUNCTION__, bspChan, carrNo, radio, angleId, realCoef, imagCoef, retVal);

    return retVal;
}
/* Ended by AICoder, pid:439e403663x33b1142840a81908c9052bf36be5a */

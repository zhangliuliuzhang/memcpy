
#include "bsppub.h"
#include "bspcomm.h"
#include "rruinfo.h"
#include "devdrv_att.h"
#include "gainctrlcommon.h"

static FUNC_GET_TXATT_MAXMIN s_pGetTxattMaxMinFunc = NULL;
static FUNC_SET_DSAATT s_pSetDsaAttFunc = NULL;
static FUNC_GET_DSAATT s_pGetDsaAttFunc = NULL;
static FUNC_SET_COMBINE_TXATT_BASE s_pSetCombineTxattBaseFunc = NULL;

UINT32 BspGetTxattMaxMinInit(FUNC_GET_TXATT_MAXMIN pCallBackFunc)
{
    s_pGetTxattMaxMinFunc = pCallBackFunc;

   return BSP_OK;
}

UINT32 BspSetDsaAttCallBackInit(FUNC_SET_DSAATT pCallBackFunc)
{
   s_pSetDsaAttFunc = pCallBackFunc;
   return BSP_OK;
}

UINT32 BspGetDsaAttCallBackInit(FUNC_GET_DSAATT pCallBackFunc)
{
   s_pGetDsaAttFunc = pCallBackFunc;
   return BSP_OK;
}

UINT32 BspSetTxattBaseCallBackInit(FUNC_SET_COMBINE_TXATT_BASE pCallBackFunc)
{
    s_pSetCombineTxattBaseFunc = pCallBackFunc;
    return BSP_OK;
}

UINT32 BspSetTxAttBase(UINT32 chn, INT32 val)
{
    UINT32 ulRetVal    = BSP_OK;

    if(NULL != s_pSetCombineTxattBaseFunc)
    {
        BspLog(LOG_INFO,LOG_LEVEL_0,"%s{ chan %d, val %d} enter\n",__FUNCTION__, chn, val);
        return s_pSetCombineTxattBaseFunc(chn, val);
    }

    return ulRetVal;
}

/*gain id  0 - 7 */
UINT32 BspSetTxGain(UINT32 chn, INT32 val)
{
    return BspSetTxAtt(chn,-abs(val));
}

UINT32 BspGetTxGain(UINT32 chn, INT32 *pVal)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pVal);
    retVal = BspGetTxAtt(chn,pVal);
    return retVal;
}

/*gain id  0 - 7 */
UINT32 BspSetRxGain(UINT32 chn, INT32 val)
{
    BspLog(LOG_LEVEL_0,"%s{%d,%d} enter\n",__FUNCTION__,chn,val);
    return BspSetRxAtt(chn,-abs(val));
}

UINT32 BspSetRxAgcGain(UINT32 chn, INT32 val)
{
    BspLog(LOG_LEVEL_0,"%s{%d,%d} enter\n",__FUNCTION__,chn,val);
    return BspSetAgcRxAtt(chn,-abs(val));
}


UINT32 BspSetVgaGain(UINT32 chn, INT32 val)
{
    BspLog(LOG_LEVEL_0,"%s{%d,%d} enter\n",__FUNCTION__,chn,val);
    return BspSetRxVga(chn,-abs(val));
}

UINT32 BspGetRxGain(UINT32 chn, INT32 *pVal)
{
    INPUT_POINTER_CHECK(pVal);
    return BspGetRxAtt(chn,pVal);
}

/*gain id  0 - 7 */
UINT32 BspSetPrxGain(UINT32 chn, INT32 val)
{
    BspLog(LOG_LEVEL_0,"%s{%d,%d} enter\n",__FUNCTION__,chn,val);
    return BspSetPrxAtt(chn,-abs(val));
}

UINT32 BspGetPrxGain(UINT32 chn, INT32 *pVal)
{
    INPUT_POINTER_CHECK(pVal);
    return BspGetPrxAtt(chn,pVal);
}

UINT32 BspGetTxGainMax(UINT32 chan, INT32 *pGain)
{
    UINT32 retVal=0;
    INT32 txGainMax=0;
    INPUT_POINTER_CHECK(pGain);
    if(s_pGetTxattMaxMinFunc != NULL)
    {
        retVal = s_pGetTxattMaxMinFunc(chan,ATT_GET_MAX_FLAG,&txGainMax);
    }
    else
    {
        retVal = BspGetAttLimitedVal(chan,TX,DEVICE_TYPE_ATT,ATT_GET_MAX_FLAG,&txGainMax);
    }
    *pGain = txGainMax;
    return retVal;
}

UINT32 BspGetTxGainMin(UINT32 chan, INT32 *pGain)
{
    UINT32 retVal=0;
    INT32 txGainMin=0;
    INPUT_POINTER_CHECK(pGain);
    if(s_pGetTxattMaxMinFunc != NULL)
    {
        retVal = s_pGetTxattMaxMinFunc(chan,ATT_GET_MIN_FLAG,&txGainMin);
    }
    else
    {
        retVal = BspGetAttLimitedVal(chan,TX,DEVICE_TYPE_ATT,ATT_GET_MIN_FLAG,&txGainMin);
    }
    *pGain = txGainMin;
    return retVal;
}

void show(UINT32 chan)
{
    INT32 txGainMin=0;
    INT32 txGainMax=0;
    BspGetTxGainMax(chan,&txGainMax);
    BspGetTxGainMin(chan,&txGainMin);
    dbgInfo("max %d min %d \n", txGainMax,txGainMin);
}

/*按方向设置dsa衰减值*/
UINT32 BspSetSlaveDsaAtt(UINT32 chan, UINT32 dir, INT32 attVal)
{
    BspLog(LOG_INFO,LOG_LEVEL_0,"%s{%d,%d,%d} enter\n",__FUNCTION__, chan, dir, attVal);
    if(NULL != s_pSetDsaAttFunc)
    {
        return s_pSetDsaAttFunc(chan, dir, attVal);
    }
    return BSP_OK;
}

/*按方向获取dsa衰减值*/
UINT32 BspGetSlaveDsaAtt(UINT32 chan, UINT32 dir, INT32 *pDsaAtt)
{
    INT32 tmp = 0;

    INPUT_POINTER_CHECK(pDsaAtt);
    if(NULL != s_pGetDsaAttFunc)
    {
        (void)s_pGetDsaAttFunc(chan, dir, &tmp);
        *pDsaAtt = abs(tmp);
    }
    return BSP_OK;
}

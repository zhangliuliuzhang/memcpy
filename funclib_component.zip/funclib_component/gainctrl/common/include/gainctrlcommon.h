/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : gainctrlcommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了增益控制对内接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_GAINCTRLCOMMON_H_
#define _FUNCLIB_GAINCTRLCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif


#include "gainctrlapi.h"
#include "funccommon_log.h"


typedef UINT32 (*FUNC_GET_TXATT_MAXMIN)(UINT32 chn, UINT32 flag, INT32 *val);
typedef UINT32 (*FUNC_SET_DSAATT)(UINT32 chan, UINT32 dir, INT32 attVal);
typedef UINT32 (*FUNC_GET_DSAATT)(UINT32 chan, UINT32 dir, INT32 *pDsaAtt);
typedef UINT32 (*FUNC_SET_COMBINE_TXATT_BASE)(UINT32 chn, INT32 val);

UINT32 BspSetRxGain(UINT32 chn, INT32 val);
UINT32 BspSetVgaGain(UINT32 chn, INT32 val);
UINT32 BspGetRxGain(UINT32 chn, INT32 *pVal);



UINT32 BspSetTxGain(UINT32 chn, INT32 val);
UINT32 BspGetTxGain(UINT32 chn, INT32 *pVal);
UINT32 BspSetPrxGain(UINT32 chn, INT32 val);
UINT32 BspGetPrxGain(UINT32 chn, INT32 *pVal);

UINT32 BspGetTxGainMax(UINT32 chan, INT32 *pGain);
UINT32 BspGetTxGainMin(UINT32 chan, INT32 *pGain);

UINT32 BspGetTxattMaxMinInit(FUNC_GET_TXATT_MAXMIN pCallBackFunc);
UINT32 BspSetDsaAttCallBackInit(FUNC_SET_DSAATT pCallBackFunc);
UINT32 BspGetDsaAttCallBackInit(FUNC_GET_DSAATT pCallBackFunc);
UINT32 BspSetDerateRefVal(UINT32 chn, UINT32 carrNo, UINT32 radioMode, UINT32 refGain);
UINT32 BspGetDerateRefVal(UINT32 chn, UINT32 carrNo, UINT32 radioMode, UINT32 *refGain);
UINT32 BspSetInherentGain(UINT32 uiDifChan, UINT32 uiRadioMode, UINT32 uiCarrNo, INT32 iPreAtt);
UINT32 BspSetMixGainDiff(UINT32 bspChn, UINT32 freqBand, INT32 gain);
UINT32 BspGetMixGainDiff(UINT32 bspChn, UINT32 freqBand, INT32 *pGain);
UINT32 BspSetTxattBaseCallBackInit(FUNC_SET_COMBINE_TXATT_BASE pCallBackFunc);
#ifdef __cplusplus
}
#endif
#endif 




/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : datalayout.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了文件解析用数据布局注入的软件框架和对外接口
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2022-03-23
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
*/

#include "datalayout.h"
#include "zcson.h"
#include "hashlist.h"

#define LAYOUT_INIT_FUNC_MAX (20)

static hash_t g_hash = NULL;
static UINT32 s_InitFuncCnt = 0;
static FUNC_DATA_LAYOUT_INIT s_InitFuncArray[LAYOUT_INIT_FUNC_MAX] = {0};

VOID* BspLayoutGetKeyValue(const CHAR* keyWord)
{
    return FindHashNode(g_hash, keyWord, 0);
}

UINT32 BspLayoutSetKeyValue(const char* keyWord, void* value)
{
    AddHashNode(g_hash, keyWord, 0, value);
    /*PrintHashList(g_hash);*/
    return BSP_OK;
}

UINT32 BspAddLayOutInitFunc(FUNC_DATA_LAYOUT_INIT pFunc)
{
    if(s_InitFuncCnt >= LAYOUT_INIT_FUNC_MAX)
    {
        return BSP_ERROR;
    }
    s_InitFuncArray[s_InitFuncCnt++] = pFunc;
    return BSP_OK;
}

UINT32 BspDataLayoutInit(void)
{
    UINT32 cnt = 0;
    UINT32 retVal = BSP_OK;

    /* 创建用于管理子数据块及回调函数的hashlist */
    g_hash = CreateHashList(100);

    /* 遍历执行数据布局初始化函数 */
    for(cnt=0; cnt<s_InitFuncCnt; cnt++)
    {
        if(s_InitFuncArray[cnt])
        {
            retVal |= (*s_InitFuncArray[cnt])();
        }
    }

    return retVal;
}



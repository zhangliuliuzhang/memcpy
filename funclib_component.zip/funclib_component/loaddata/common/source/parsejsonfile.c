#include "parsejsonfile.h"
#include "cJSON.h"
#include "zcson.h"
#include "datalayout.h"
#include "boardmodlecommon.h"
#include "hashlist.h"
#include "rruinfo.h"
#include "zprintf.h"

/* ----------------------------------------------------- */
#define CHECK_NULL_POINTER(ppointer)  \
    if(NULL == ppointer)              \
    {                                 \
        dbgErr("%s %s is NULL!\n", __func__, #ppointer); \
        return BSP_ERROR; \
    }


/*
数据等级定义
LEVEL0 子数据块，隶属于某个LEVEL2以上数据
LEVEL1 不区分机型的通用数据
LEVEL2 区分机型的定制数据
LEVEL3 区分芯片号的数据
LEVEL4 区分机型且区分芯片号的数据
LEVEL5 待定义
LEVEL6 待定义
LEVEL7 待定义
LEVEL8 待定义
LEVEL9 待定义
...
*/
#define FUNC_PARSE_DATA_MAX (10)
#define JSON_FILE_TYPE_MAX (10)

#define BOARD_HIT     (1)
#define BOARD_NOT_HIT (0)

#define CHIP_HIT     (1)
#define CHIP_NOT_HIT (0)

/* ----------------------------------------------------- */
typedef UINT32 (*FuncParseData)(cJSON *item);

typedef struct tag_DataBlock
{
   VOID  *pBlockData;
   UINT32 dataNum;
} T_DataBlock;

typedef struct tag_JsonFileInfo
{
   const CHAR *fileName;
   UINT32 levelMask;
} T_JsonFileInfo;

static UINT32 ParseDataLevel0(cJSON *item);
static UINT32 ParseDataLevel1(cJSON *item);
static UINT32 ParseDataLevel2(cJSON *item);

/* ----------------------------------------------------- */
/* 全局变量 */
static hash_t g_hash = NULL;
static CHAR s_BomIdString[32] = {0};
static FuncParseData s_FuncParseData[FUNC_PARSE_DATA_MAX] =
{
    ParseDataLevel0,
    ParseDataLevel1,
    ParseDataLevel2
};

static T_JsonFileInfo s_jsonCommonFileTbl[JSON_FILE_TYPE_MAX] = {0};
static T_JsonFileInfo s_jsonCustomFileTbl[JSON_FILE_TYPE_MAX] = {0};
static const CHAR *s_FileBasePath = NULL;
/* ----------------------------------------------------- */
static UINT32 CreateBomIdString(VOID)
{
    UINT32 modId = BspGetModuleGroupId();
    UINT32 grpId = BspGetBoardGroupId();
    UINT32 typeId = BspGetBoardTypeId();
    UINT32 changeId = BspGetHardwareChangeId();
    sprintf(s_BomIdString,"0x%x,0x%x,0x%x,0x%x", modId,grpId,typeId,changeId); /* bomid的格式待优化 todo */
    return BSP_OK;
}

const CHAR *GetBoardBomIdStr(VOID)
{
    return s_BomIdString;
}

static UINT32 GetFileLen(const CHAR *ucFileName, UINT32 *fileSize)
{
   struct stat tStatInfo = {0};

   if (-1 == stat(ucFileName, &tStatInfo))
   {
       return BSP_ERROR;
   }
   else
   {
       *fileSize = (UINT32)tStatInfo.st_size;
       return BSP_OK;
   }
}

static CHAR *read_json_file(const CHAR *filename)
{
    FILE *fp = NULL;
    UINT32 fileSize = 0;

    if ((fopen_s(&fp, filename, "r")) != 0 || NULL == fp)
    {
        dbgErr("Error: Cannot open file[ %s]! \n", filename);
        return NULL;
    }

    // 获取文件大小
    if (BSP_OK != GetFileLen(filename, &fileSize))
    {
        dbgErr("Error: fail to get file[%s] size! \n", filename);
        fclose(fp);
        return NULL;
    }

    // 分配内存空间
    CHAR *buffer = (CHAR *)malloc(fileSize + 1);
    if (buffer == NULL)
    {
        dbgErr("Error: Cannot allocate memory for reading file[%s]! \n", filename);
        fclose(fp);
        return NULL;
    }

    // 读取文件内容
    if (0 == fread(buffer, fileSize, 1, fp))
    {
        dbgErr("Error: read file[%s] error! \n", filename);
        fclose(fp);
        free(buffer);
        return NULL;
    }
    buffer[fileSize] = '\0';

    fclose(fp);
    return buffer;
}
static VOID *FindDataBlock(const CHAR *blkName)
{
    T_DataBlock *pDataBlk =  FindHashNode(g_hash, blkName, 0);
    if(NULL != pDataBlk)
    {
        return pDataBlk->pBlockData;
    }
    else
    {
        dbgErr("%s>> pDataBlk is NULL!\n", __func__);
        return NULL;
    }
}

static VOID *FindCallBack(const CHAR *funcName)
{
    return BspLayoutGetKeyValue(funcName);
}

static VOID PrintDataBlock(VOID* private)
{
    T_DataBlock *pDataBlk = private;
    if(NULL != pDataBlk) 
    {
        dbgInfo("BlockAddr=%p, dataNum=%d", pDataBlk->pBlockData, pDataBlk->dataNum);
    }
    return;
}

static UINT32 AddDataBlock(const CHAR*keyWord, VOID* pData, UINT32 num)
{
    T_DataBlock *pDataBlk = (T_DataBlock*)malloc(sizeof(T_DataBlock));
    if (NULL == pDataBlk)
    {
        return BSP_ERROR;
    }
    pDataBlk->pBlockData = pData;
    pDataBlk->dataNum = num;
    
    AddHashNode(g_hash, keyWord, 0, pDataBlk);
    //PrintHashList(g_hash);
    return BSP_OK;
}

static UINT32 IsBoardHit(cJSON *item)
{
    UINT32 hit = BOARD_NOT_HIT;
    cJSON *sitem = NULL;
    const CHAR *boardStr = GetBoardBomIdStr();

    /* 有board项，则严格进行匹配 */
    if (cJSON_HasObjectItem(item, "board"))
    {
        cJSON *board = cJSON_GetObjectItem(item, "board");
        CHECK_NULL_POINTER(board);
        cJSON_ArrayForEach(sitem, board) {
            //dbgInfo("%s \n", sitem->valuestring);
            CHECK_NULL_POINTER(sitem);
            if(0 == strcmp(boardStr,sitem->valuestring))
            {
                hit = BOARD_HIT;
                break;
            }
        }
    }
    /* 无board项，则默认为匹配 */
    else
    {
        hit = BOARD_HIT;
    }
    return hit; 
}

static UINT32 IsChipHit(cJSON *item)
{
    UINT32 hit = CHIP_NOT_HIT;
    cJSON *pChipObj = NULL;
    UINT32 chipMask = 0;
    UINT32 rpuID = BspGetRpuId();

    /* 有chipMask项，则严格进行匹配 */
    if (cJSON_HasObjectItem(item, "chipmask"))
    {
        pChipObj = cJSON_GetObjectItem(item, "chipmask");
        if(NULL != pChipObj && cJSON_IsNumber(pChipObj))
        {
            chipMask = pChipObj->valueint;
            if(0 != BIT_VAL(chipMask,rpuID))
            {
                hit = BOARD_HIT;
            }
        }
    }
    /* 无chipMask项，则默认为匹配 */
    else
    {
        hit = BOARD_HIT;
    }
    return hit;
}

static UINT32 CheckVersion(UINT32 layoutVersion, cJSON *item, UINT32 actType, UINT32 idx, UINT32 part)
{
    UINT32 fileVersion = 0;
    cJSON *pVerObj = NULL;

    if (cJSON_HasObjectItem(item, "version"))
    {
        pVerObj = cJSON_GetObjectItem(item, "version");
        if (NULL != pVerObj && cJSON_IsNumber(pVerObj))
        {
            fileVersion = pVerObj->valueint;
        }
        else
        {
            return BSP_ERROR;
        }
    }
    else
    {
        return BSP_ERROR;
    }

    if (fileVersion != layoutVersion)
    {
        return BSP_ERROR;
    }
    else
    {
        return BSP_OK;
    }
}

static UINT32 ParseDataArray(cJSON *pDataObj, layout_item_t* tbl, VOID **pOutData, UINT32 *pOutNum)
{
    UINT32 objSize = 0;
    UINT32 objNum = 0;
    VOID *pData = NULL;
    cJSON *sitem = NULL;

    objSize = ZcsonGetSturceSize(tbl);
    objNum = cJSON_GetArraySize(pDataObj);
    pData = malloc(objSize*objNum);
    CHECK_NULL_POINTER(pData);
    memset_s(pData,objSize*objNum,0,objSize*objNum);
    for (int i=0; i<objNum; i++)
    {
        sitem = cJSON_GetArrayItem(pDataObj, i);
        if (NULL == sitem)
        {
            free(pData);
            return BSP_ERROR;
        }
        if (ZcsonJsonObj2Struct(sitem, (CHAR*)pData+objSize*i, tbl) != 0)
        {
            free(pData);
            return BSP_ERROR;
        }
    }
    *pOutData = pData;
    *pOutNum = objNum;

    return BSP_OK;
}

static UINT32 ParseData(cJSON *item, layout_item_t* tbl, VOID **pOutData, UINT32 *pOutNum)
{
    UINT32 objSize = 0;
    UINT32 objNum = 0;
    VOID *pData = NULL;
    cJSON *pDataObj = NULL;


    if (cJSON_HasObjectItem(item, "data"))
    {
        pDataObj = cJSON_GetObjectItem(item, "data");
    }
    CHECK_NULL_POINTER(pDataObj);

    if (cJSON_IsArray(pDataObj))
    {
        if (BSP_OK != ParseDataArray(pDataObj, tbl, &pData, &objNum))
        {
            return BSP_ERROR;
        }
    }
    else
    {
        objNum = 1;
        objSize = ZcsonGetSturceSize(tbl);
        pData = malloc(objSize);
        CHECK_NULL_POINTER(pData);
        memset_s(pData,objSize,0,objSize);
        if (ZcsonJsonObj2Struct(pDataObj, pData, tbl) != 0)
        {
            free(pData);
            return BSP_ERROR;
        }
    }
    *pOutData = pData;
    *pOutNum = objNum;

    return BSP_OK;
}

static UINT32 ParseDataLevel0(cJSON *item)
{
    VOID *pData = NULL;
    UINT32 dataNum = 0;
    CHAR *layout  = NULL;
    CHAR *Keyword = NULL;
    layout_item_t* tbl = NULL;

    /* 检查单板是否匹配 */
    if (BOARD_NOT_HIT == IsBoardHit(item))
    {
        return BSP_OK;
    }

    /* 检查片号是否匹配 */
    if (CHIP_NOT_HIT == IsChipHit(item))
    {
        return BSP_OK;
    }

    if (cJSON_HasObjectItem(item, "layout") && (NULL != cJSON_GetObjectItem(item, "layout")))
    {
        layout = cJSON_GetObjectItem(item, "layout")->valuestring;
    }

    if (cJSON_HasObjectItem(item, "keyword") && (NULL != cJSON_GetObjectItem(item, "keyword")))
    {
        Keyword = cJSON_GetObjectItem(item, "keyword")->valuestring;
    }

    tbl = BspLayoutGetKeyValue(layout);
    if (NULL == layout || NULL == Keyword || NULL == tbl)
    {
        return BSP_ERROR;
    }

    /* 数据解析 */
    if (BSP_OK != ParseData(item, tbl, &pData, &dataNum))
    {
        return BSP_ERROR;
    }

    /* 加入DataBlock */
    return AddDataBlock(Keyword, pData, dataNum);
}

static UINT32 CheckDataLevel1(cJSON *item, UINT32 *actType, UINT32 *actIdx)
{
    cJSON *pActTypeObj = NULL;
    cJSON *pIdxObj = NULL;

    if (cJSON_HasObjectItem(item, "acttype") && cJSON_HasObjectItem(item, "dataidx"))
    {
        pActTypeObj = cJSON_GetObjectItem(item, "acttype");
        pIdxObj = cJSON_GetObjectItem(item, "dataidx");
        if (NULL != pActTypeObj && cJSON_IsNumber(pActTypeObj))
        {
            *actType = cJSON_GetObjectItem(item, "acttype")->valueint;
        }
        else
        {
            return BSP_ERROR;
        }
        if (NULL != pIdxObj && cJSON_IsNumber(pIdxObj))
        {
            *actIdx = cJSON_GetObjectItem(item, "dataidx")->valueint;
        }
        else
        {
            return BSP_ERROR;
        }
    }
    else
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

static UINT32 ParseDataLevel1(cJSON *item)
{
    VOID *pData = NULL;
    UINT32 dataNum = 0;
    UINT32 actType = 0;
    UINT32 actIdx = 0;
    layout_item_t* tbl = NULL;
    UINT32 version = 0;

    if (BSP_OK != CheckDataLevel1(item, &actType, &actIdx))
    {
        return BSP_ERROR;
    }

    if (BSP_OK != BspBoardModleGetDataLayout(actType,actIdx,0,(void**)(&tbl),&version))
    {
        return BSP_ERROR;
    }

    if (NULL == tbl)
    {
        return BSP_ERROR;
    }

    /* 版本比对 */
    if (BSP_OK != CheckVersion(version, item, actType, actIdx, 0))
    {
        return BSP_ERROR;
    }

    /* 数据解析 */
    if (BSP_OK != ParseData(item, tbl, &pData, &dataNum))
    {
        return BSP_ERROR;
    }

    /* 数据写回 */ 
    return BspBoardModleSetFileData(actType,actIdx,0, pData, dataNum, 0); /* todo size */
}

static UINT32 CheckDataLevel2(cJSON *item, UINT32 *actType, UINT32 *actIdx, UINT32 *part)
{
    cJSON *pActTypeObj = NULL;
    cJSON *pIdxObj = NULL;
    cJSON *pPartObj = NULL;

    if (cJSON_HasObjectItem(item, "acttype") &&
       cJSON_HasObjectItem(item, "dataidx") &&
       cJSON_HasObjectItem(item, "part"))
    {
        pActTypeObj = cJSON_GetObjectItem(item, "acttype");
        pIdxObj = cJSON_GetObjectItem(item, "dataidx");
        pPartObj = cJSON_GetObjectItem(item, "part");
        if (NULL != pActTypeObj && cJSON_IsNumber(pActTypeObj))
        {
            *actType = cJSON_GetObjectItem(item, "acttype")->valueint;
        }
        else
        {
            return BSP_ERROR;
        }
        if (NULL != pIdxObj && cJSON_IsNumber(pIdxObj))
        {
            *actIdx = cJSON_GetObjectItem(item, "dataidx")->valueint;
        }
        else
        {
            return BSP_ERROR;
        }
        if (NULL != pPartObj && cJSON_IsNumber(pPartObj))
        {
            *part = cJSON_GetObjectItem(item, "part")->valueint;
        }
        else
        {
            return BSP_ERROR;
        }
    }
    else
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

static UINT32 ParseDataLevel2(cJSON *item)
{
    VOID *pData = NULL;
    UINT32 dataNum = 0;
    UINT32 actType = 0;
    UINT32 actIdx = 0;
    UINT32 dataPart = 0;
    layout_item_t* tbl = NULL;
    UINT32 version = 0;

    /* 检查单板是否匹配 */
    if (BOARD_NOT_HIT == IsBoardHit(item))
    {
        return BSP_OK;
    }

    /* 检查片号是否匹配 */
    if (CHIP_NOT_HIT == IsChipHit(item))
    {
        return BSP_OK;
    }

    if (BSP_OK != CheckDataLevel2(item, &actType, &actIdx, &dataPart))
    {
        return BSP_ERROR;
    }

    if (BSP_OK != BspBoardModleGetDataLayout(actType,actIdx,dataPart,(void**)(&tbl),&version))
    {
        return BSP_ERROR;
    }

    if (NULL == tbl)
    {
        return BSP_ERROR;
    }

    /* 版本比对 */
    if (BSP_OK != CheckVersion(version, item, actType, actIdx, dataPart))
    {
        return BSP_ERROR;
    }

    /* 数据解析 */
    if (BSP_OK != ParseData(item, tbl, &pData, &dataNum))
    {
        return BSP_ERROR;
    }

    /* 数据写回 */
    return BspBoardModleSetFileData(actType,actIdx,0, pData, dataNum, 0);/* todo size */
}

static UINT32 ParseJsonString(const CHAR *json_text, UINT32 targetLevelMask)
{
    UINT32 ret = BSP_OK;
    cJSON *root = cJSON_Parse(json_text);
    cJSON *item;

    if (root == NULL)
    {
        dbgInfo("Error: Cannot parse json text.\n");
        return BSP_ERROR;
    }

    cJSON *config = cJSON_GetObjectItem(root, "config");
    if (config == NULL)
    {
        dbgInfo("Error: Cannot find key 'config' in json text.\n");
        cJSON_Delete(root);
        return BSP_ERROR;
    }

    cJSON_ArrayForEach(item, config) {
        UINT32 level = 0;
        if (cJSON_HasObjectItem(item, "level") && cJSON_IsNumber(cJSON_GetObjectItem(item, "level")))
        {
            if(NULL != cJSON_GetObjectItem(item, "level"))
            {
                level = cJSON_GetObjectItem(item, "level")->valueint;
            }
            //dbgInfo("Level: %d\n", level);
        }
        else
        {
            dbgInfo("%s can't find level\n", __FUNCTION__);
            continue;
        }
        
        if (level >= FUNC_PARSE_DATA_MAX)
        {
            continue;
        }

        /* 略过不属于目标level的数据 */
        if (0 == ((0x1<<level) & targetLevelMask))
        {
            continue;
        }

        ret = (*s_FuncParseData[level])(item);
        if (BSP_OK != ret)
        {
            dbgInfo("%s parse data fail!\n", __FUNCTION__);
            continue;
        }
    }

    cJSON_Delete(root);
    return ret;
}

static UINT32 ParseJsonFile(const CHAR * fileName, UINT32 targetLevelMask)
{
    UINT32 ret = BSP_OK;
    char *json_text = NULL;

    if (NULL == fileName)
    {
        return BSP_OK;
    }

    json_text = read_json_file(fileName);
    if (json_text == NULL)
    {
        return BSP_ERROR;
    }

    /* 校验checksum */
    /* todo */

    ret = ParseJsonString(json_text, targetLevelMask);
    if (BSP_OK != ret)
    {
        dbgInfo("Error: Failed to parse %s.\n", fileName);
        free(json_text);
        return BSP_ERROR;
    }
    free(json_text);
    return BSP_OK;
}

static UINT32 ParseFile(T_JsonFileInfo *pFileInfo)
{
    UINT32 i = 0;
    UINT32 ret = BSP_OK;
    CHAR *fullPath = NULL;
    UINT32 pathLen = 0;

    for (i=0; i<JSON_FILE_TYPE_MAX; i++)
    {
        if (NULL != pFileInfo[i].fileName && NULL != s_FileBasePath)
        {
            pathLen = strlen(pFileInfo[i].fileName)+strlen(s_FileBasePath)+2;
            fullPath = (CHAR*)malloc(pathLen);
            if (NULL == fullPath)
            {
                dbgErr("%s parse file[%s] malloc error!\n", __FUNCTION__, pFileInfo[i].fileName);
                continue;
            }
            memset(fullPath, 0, pathLen);
            sprintf(fullPath,"%s/%s", s_FileBasePath, pFileInfo[i].fileName);
            ret |= ParseJsonFile(fullPath, pFileInfo[i].levelMask);
            free(fullPath);
        }
    }
    return ret;
}

/* 对外接口 - 文件解析的初始化 */
UINT32 BspParseFileInit(void)
{
    /* 创建hashlist */
    g_hash = CreateHashList(100);
    if (NULL == g_hash)
    {
        return BSP_ERROR;
    }

    /* 注册打印接口-维测用 */
    RegisterPrintFunc(g_hash, PrintDataBlock);

    /* 注册接口给zcson，以支持ZCSON_BLOCK */
    ZcsonSetBlockCallBack(FindDataBlock);

    /* 注册接口给zcson，以支持ZCSON_FUNC */
    ZcsonSetFuncCallBack(FindCallBack);

    return BSP_OK;
}

/* 对外接口 - 解析不区分机型的功能项目 */
UINT32 BspParseCommonFile(void)
{
    return ParseFile(s_jsonCommonFileTbl);
}

/* 对外接口 - 解析区分机型的功能项目 */
UINT32 BspParseCustomFile(void)
{
    /* 创建bomid字符串 */
    CreateBomIdString();

    return ParseFile(s_jsonCustomFileTbl);
}

/* 对外接口 */
UINT32 BspSetCommonFileInfo(UINT32 index, const CHAR* fileName, UINT32 levelMask)
{
    if(index >= JSON_FILE_TYPE_MAX)
    {
        return BSP_ERROR;
    }

    s_jsonCommonFileTbl[index].fileName = fileName;
    s_jsonCommonFileTbl[index].levelMask = levelMask;
    return BSP_OK;
}

/* 对外接口 */
UINT32 BspSetCustomFileInfo(UINT32 index, const CHAR* fileName, UINT32 levelMask)
{
    if (index >= JSON_FILE_TYPE_MAX)
    {
        return BSP_ERROR;
    }

    s_jsonCustomFileTbl[index].fileName = fileName;
    s_jsonCustomFileTbl[index].levelMask = levelMask;
    return BSP_OK;
}

/* 对外接口 */
UINT32 BspSetFileBasePath(const CHAR* filePath)
{
    s_FileBasePath = filePath;
    return BSP_OK;
}


#ifndef _PARSE_JSON_FILE_H_
#define _PARSE_JSON_FILE_H_

#ifdef __cplusplus
extern "C" {
#endif


#include "bsppub.h"

UINT32 BspParseFileInit(void);
UINT32 BspParseCommonFile(void);
UINT32 BspParseCustomFile(void);
UINT32 BspSetCommonFileInfo(UINT32 index, const CHAR* fileName, UINT32 levelMask);
UINT32 BspSetCustomFileInfo(UINT32 index, const CHAR* fileName, UINT32 levelMask);
UINT32 BspSetFileBasePath(const CHAR* filePath);

#ifdef __cplusplus
}
#endif

#endif /* _PARSE_JSON_FILE_H_ */

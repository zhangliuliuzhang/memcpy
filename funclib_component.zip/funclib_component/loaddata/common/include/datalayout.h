
#ifndef _DATA_LAYOUT_H_
#define _DATA_LAYOUT_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"

typedef UINT32 (*FUNC_DATA_LAYOUT_INIT)(VOID);

UINT32 BspDataLayoutInit(void);
VOID* BspLayoutGetKeyValue(const CHAR* keyWord);
UINT32 BspLayoutSetKeyValue(const CHAR* keyWord, VOID* value);
UINT32 BspAddLayOutInitFunc(FUNC_DATA_LAYOUT_INIT pFunc);

#ifdef __cplusplus
}
#endif

#endif /* _DATA_LAYOUT_INIT_H_ */



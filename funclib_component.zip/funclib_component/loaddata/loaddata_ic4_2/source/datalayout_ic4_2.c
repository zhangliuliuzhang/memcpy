/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : datalayout_ic4_2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了IC4_2系列单板的数据布局
* 注意事项 : 无
* 作    者 :   王涛10248577
* 创建日期 : 2022-03-23
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2022-03-23
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "bsppub.h"
#include "zcson.h"
#include "hashlist.h"
#include "hardfeaturewrapperbase.h"
#include "boardpapt.h"
#include "ichaladapt_crm_ic4_2.h"
#include "att_common.h"
#include "datalayout.h"
#include "boardmodle_ic4_2.h"
#include "pa_ic4_2_tddrfctrl.h"
#include "cfr_ic4_2.h"
#include "pwr_a.h"
#include "chippoweronwrapper.h"
#include "powerctrlcommon.h"
#include "padctrl.h"
#include "cbswcfg.h"
#include "j204_ic4_2.h"
#include "j204_trx.h"
#include "transceiver_common.h"
#include "dac_common.h"
#include "datalayout_ic4_2.h"
#include "functionwrapper.h"
#include "boardverprotect.h"
#include "boardcpuid.h"
#include "powerctrl_ic4_2.h"
#include "powerctrl_comps_ic4_2.h"
#include "functionwrapper.h"
#include "papt_common.h"
#include "freqcfgcommon.h"
#include "flash.h"
#include "fpgaloadprocess.h"
#include "gainctrl_ic4_2.h"
#include "tddcfg_ic4_2.h"
#include "pa_ic4_2_calcpara.h"
#include "boardid.h"
#include "rftableinit.h"
#include "ichaladapt_ic4_2.h"
#include "gainctrlcommon.h"

/*  -------------------------------------------------------------------------  */
/*
    结构体 E_HARD_FEATURE_GET_BOMID
*/
layout_item_t BomidFlashInfo_ref_tbl[] = {
    _object_int(T_BomidFlashInfo, flashBomidOffset),
    _object_int(T_BomidFlashInfo, flashBomidSize),
    _object_end(T_BomidFlashInfo)
};

layout_item_t T_BspHalAdaptDifTxRouteMap_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifTxRouteMap, uiLinkId),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiDifChan),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiFreqId),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiBankOut),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiCfrPort),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiCfrPortNum),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiCfrCombIn),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiCfrCombOut),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiCfrCombPortNum),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiCfrOut),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiDpdPort),
    _object_int(T_BspHalAdaptDifTxRouteMap, uiCfrOutPortNum),
    _object_end(T_BspHalAdaptDifTxRouteMap)
};

layout_item_t T_BspHalAdaptDifTxRoutePara_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifTxRoutePara, uiLinkId),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiDifChan),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiFreqId),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiSrc2Mode),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiSrc3Mode),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiSrc3BypassEn),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiDpdMode),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiEtMode),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiCfrPhase2x),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiDpdPhase2x),
    _object_int(T_BspHalAdaptDifTxRoutePara, uiTddMode),
    _object_end(T_BspHalAdaptDifTxRoutePara)
};

layout_item_t T_BspHalAdaptDifTx204RouteMap_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifTx204RouteMap, uiLinkId),
    _object_int(T_BspHalAdaptDifTx204RouteMap, uiDifChan),
    _object_int(T_BspHalAdaptDifTx204RouteMap, uiFreqId),
    _object_int(T_BspHalAdaptDifTx204RouteMap, uiDpdPort),
    _object_int(T_BspHalAdaptDifTx204RouteMap, uiDlPostPort),
    _object_int(T_BspHalAdaptDifTx204RouteMap, uiDlPostPortNum),
    _object_int(T_BspHalAdaptDifTx204RouteMap, ui204PortI),
    _object_int(T_BspHalAdaptDifTx204RouteMap, ui204PortQ),
    _object_end(T_BspHalAdaptDifTx204RouteMap)
};

layout_item_t T_BspHalAdaptDifRxRouteMap_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifRxRouteMap, uiLinkId),
    _object_int(T_BspHalAdaptDifRxRouteMap, uiDifChan),
    _object_int(T_BspHalAdaptDifRxRouteMap, ui204Port),
    _object_int(T_BspHalAdaptDifRxRouteMap, uiUlChPort),
    _object_int(T_BspHalAdaptDifRxRouteMap, uiUlChPortNum),
    _object_int(T_BspHalAdaptDifRxRouteMap, uiUlChSwap),
    _object_int(T_BspHalAdaptDifRxRouteMap, uiTddMode),
    _object_end(T_BspHalAdaptDifRxRouteMap)
};

layout_item_t T_BspHalAdaptDifFbRouteMap_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifFbRouteMap, uiLinkId),
    _object_int(T_BspHalAdaptDifFbRouteMap, uiDifChan),
    _object_int(T_BspHalAdaptDifFbRouteMap, uiJ204Port),
    _object_int(T_BspHalAdaptDifFbRouteMap, uiFbPort),
    _object_int(T_BspHalAdaptDifFbRouteMap, uiFbChSel),
    _object_int(T_BspHalAdaptDifFbRouteMap, uiFbChMode),
    _object_int(T_BspHalAdaptDifFbRouteMap, uiFbPhaseNum),
    _object_int(T_BspHalAdaptDifFbRouteMap, uiFbDataIqExch),
    _object_end(T_BspHalAdaptDifFbRouteMap)
};

layout_item_t T_BspHalAdaptFrInitCfg_ref_tbl[] = {
    _object_int(T_BspHalAdaptFrInitCfg, uiLitFrPeriod),
    _object_int(T_BspHalAdaptFrInitCfg, uiBigFrPeriod),
    _object_int(T_BspHalAdaptFrInitCfg, uiDPDSampFrPeriod),
    _object_int(T_BspHalAdaptFrInitCfg, uiCbSWFrPeriod),
    _object_int(T_BspHalAdaptFrInitCfg, uiCBFrFrameId),
    _object_end(T_BspHalAdaptFrInitCfg)
};

layout_item_t T_BspHalAdaptSysrefCfg_ref_tbl[] = {
    _object_int(T_BspHalAdaptSysrefCfg, sysrefEn),
    _object_int(T_BspHalAdaptSysrefCfg, mode),
    _object_int(T_BspHalAdaptSysrefCfg, sysrefNum),
    _object_int(T_BspHalAdaptSysrefCfg, tsEnable),
    _object_int(T_BspHalAdaptSysrefCfg, sysrefFrDelay),
    _object_int(T_BspHalAdaptSysrefCfg, localcntSyncEn),
    _object_int(T_BspHalAdaptSysrefCfg, syncSrc),
    _object_int(T_BspHalAdaptSysrefCfg, period),
    _object_int(T_BspHalAdaptSysrefCfg, width),
    _object_int(T_BspHalAdaptSysrefCfg, sysPha),
    _object_int(T_BspHalAdaptSysrefCfg, isExtSysref),
    _object_end(T_BspHalAdaptSysrefCfg)
};

layout_item_t T_J204SerdesTxEqPara_ref_tbl[] = {
    _object_int(T_J204SerdesTxEqPara, laneId),
    _object_int(T_J204SerdesTxEqPara, eqPre),
    _object_int(T_J204SerdesTxEqPara, eqPost),
    _object_int(T_J204SerdesTxEqPara, eqMain),
    _object_end(T_J204SerdesTxEqPara)
};

layout_item_t T_RruDefAbility_ref_tbl[] = {
    _object_int(T_RruDefAbility, carrNum),
    _object_int(T_RruDefAbility, defRadio),
    _object_end(T_RruDefAbility)
};

layout_item_t T_RruCarrAbility_ref_tbl[] = {
    _object_int(T_RruCarrAbility, singleNrCarrNum),
    _object_int(T_RruCarrAbility, singleLteCarrNum),
    _object_int(T_RruCarrAbility, mixNrCarrNum),
    _object_int(T_RruCarrAbility, mixLteCarrNum),
    _object_end(T_RruCarrAbility)
};

layout_item_t T_BspHalAdaptCfrParCommPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptCfrParCommPara, uiBitcutId),
    _object_int(T_BspHalAdaptCfrParCommPara, uiMongateBypass),
    _object_int(T_BspHalAdaptCfrParCommPara, uiMonitorThreshold),
    _object_end(T_BspHalAdaptCfrParCommPara)
};


layout_item_t T_BspHalAdaptDpdParCommPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptDpdParCommPara, uiBitcutId),
    _object_int(T_BspHalAdaptDpdParCommPara, uiMonitorThreshold),
    _object_end(T_BspHalAdaptDpdParCommPara)
};

layout_item_t T_PowUpdateTime_ref_tbl[] = {
    _object_int(T_PowUpdateTime, powCalcTime),
    _object_end(T_PowUpdateTime)
};

layout_item_t T_UlPowCalcPara_ref_tbl[] = {
    _object_int(T_UlPowCalcPara, lRxTargetGain),
    _object_int(T_UlPowCalcPara, lRxDefAttVal),
    _object_int(T_UlPowCalcPara, lTxAcCalDefVal),
    _object_int(T_UlPowCalcPara, lRxIsoCalDefVal),
    _object_int(T_UlPowCalcPara, lRxDigAttVal),
    _object_end(T_UlPowCalcPara)
};

layout_item_t T_BspHalAdaptLinkDeltDly_ref_tbl[] = {
    _object_int(T_BspHalAdaptLinkDeltDly, uiRadioMode),
    _object_int(T_BspHalAdaptLinkDeltDly, uiFrType),
    _object_int(T_BspHalAdaptLinkDeltDly, iTrxDeltaDelay),
    _object_end(T_BspHalAdaptLinkDeltDly)
};

layout_item_t T_BspHalAdaptVgaCompPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptVgaCompPara, iRfFixGian),
    _object_int(T_BspHalAdaptVgaCompPara, iDiffFacx),
    _object_int(T_BspHalAdaptVgaCompPara, uiCompPerd),
    _object_int(T_BspHalAdaptVgaCompPara, uiCompKsec),
    _object_int(T_BspHalAdaptVgaCompPara, uiCompIdx),
    _object_int(T_BspHalAdaptVgaCompPara, uiCompMode),
    _object_int(T_BspHalAdaptVgaCompPara, uiThr1),
    _object_int(T_BspHalAdaptVgaCompPara, uiThr2),
    _object_int(T_BspHalAdaptVgaCompPara, uiThr3),
    _object_int(T_BspHalAdaptVgaCompPara, uiCompUndecLen),
    _object_end(T_BspHalAdaptVgaCompPara)
};

layout_item_t T_DpdEqData_ref_tbl[] = {
    _object_int(T_DpdEqData, supportFlag),
    _object_end(T_DpdEqData)
};

layout_item_t T_VerProtectInfo_ref_tbl[] = {
    _object_int(T_VerProtectInfo, startAddr),
    _object_int(T_VerProtectInfo, size),
    _object_int(T_VerProtectInfo, verType),
    _object_end(T_VerProtectInfo)
};

layout_item_t _T_Reg_Drv_Tbl_ref_tbl[] = {
    _object_int(_T_Reg_Drv_Tbl, chipIdx),
    _object_int(_T_Reg_Drv_Tbl, regType),
    _object_int(_T_Reg_Drv_Tbl, regAddr),
    _object_int(_T_Reg_Drv_Tbl, bitNum),
    _object_int(_T_Reg_Drv_Tbl, defVal),
    _object_end(_T_Reg_Drv_Tbl)
};

layout_item_t _T_Dev_Reg_Tbl_Modify_ref_tbl[] = {
    _object_int(_T_Dev_Reg_Tbl_Modify, modiIdx),
    _object_int(_T_Dev_Reg_Tbl_Modify, chipIdx),
    _object_int(_T_Dev_Reg_Tbl_Modify, regType),
    _object_int(_T_Dev_Reg_Tbl_Modify, regAddr),
    _object_int(_T_Dev_Reg_Tbl_Modify, bitNum),
    _object_int(_T_Dev_Reg_Tbl_Modify, defVal),
    _object_end(_T_Dev_Reg_Tbl_Modify)
};

layout_item_t T_CpuIdInfo_ref_tbl[] = {
    _object_int(T_CpuIdInfo, isPeerPu),
    _object_int(T_CpuIdInfo, puId),
    _object_int(T_CpuIdInfo, cpuId),
    _object_int(T_CpuIdInfo, coreId),
    _object_end(T_CpuIdInfo)
};

layout_item_t T_PaptCrmCfg_ref_tbl[] = {
    _object_int(T_PaptCrmCfg, openCrmPaDaFlag),
    _object_int(T_PaptCrmCfg, openOptPaDaFlag),
    _object_int(T_PaptCrmCfg, crmPaMask),
    _object_int(T_PaptCrmCfg, crmDaMask),
    _object_int(T_PaptCrmCfg, crmEnMask),
    _object_int(T_PaptCrmCfg, crmReportMask),
    _object_end(T_PaptCrmCfg)
};

layout_item_t T_PowerAdjustDelta_ref_tbl[] = {
    _object_int(T_PowerAdjustDelta, chanNo),
    _object_bool(T_PowerAdjustDelta, isSupport),
    _object_int(T_PowerAdjustDelta, thresVal),
    _object_end(T_PowerAdjustDelta)
};

layout_item_t T_Reg_Tbl_ref_tbl[] = {
    _object_int(T_Reg_Tbl, regFuncDomainId),
    _object_int(T_Reg_Tbl, regProperty),
    _object_int(T_Reg_Tbl, regAddr),
    _object_int(T_Reg_Tbl, regMask),
    _object_int(T_Reg_Tbl, isMask),
    _object_int(T_Reg_Tbl, regVal),
    _object_int(T_Reg_Tbl, initFlag),
    _object_int(T_Reg_Tbl, chipInfo),
    _object_end(T_Reg_Tbl)
};

/*  -------------------------------------------------------------------------  */
/*
    结构体嵌套子结构体 E_HARD_FEATURE_PAPT_UPDATA
*/
layout_item_t T_PaptCfgUpdata_ref_tbl[] = {
    _object_int(T_RfPaptCfgUpdata, lnaFalg),
    _object_int(T_RfPaptCfgUpdata, mtsAlarmNo),
    _object_int(T_RfPaptCfgUpdata, paMask),
    _object_int(T_RfPaptCfgUpdata, daMask),
    _object_end(T_RfPaptCfgUpdata)
};

layout_item_t T_PaptUpdata_ref_tbl[] = {
    _object_int(T_PaptUpdata, chanSelect),
    _object_obj(T_PaptUpdata, updataCfgPara, T_PaptCfgUpdata_ref_tbl),
    _object_end(T_PaptUpdata)
};

layout_item_t T_BspHalAdaptCbSwRfTbl_ref_tbl[] = {
    _object_int(T_BspHalAdaptCbSwRfTbl, uiChanNum),
    _object_array_int(T_BspHalAdaptCbSwRfTbl, uiOneLine, int, SW_MAX_CHANNEL),
    _object_end(T_BspHalAdaptCbSwRfTbl)
};

layout_item_t T_BspCbSwRfTbl_ref_tbl[] = {
    _object_int(T_BspCbSwRfTbl, swIndex),
    _object_int(T_BspCbSwRfTbl, rfType),
    _object_obj(T_BspCbSwRfTbl, pCbSwRfTbl, T_BspHalAdaptCbSwRfTbl_ref_tbl),
    _object_end(T_BspCbSwRfTbl)
};

layout_item_t T_TssiChk_ref_tbl[] = {
    _object_int(T_TssiChk, uiDtssiAsynMod),
    _object_int(T_TssiChk, uiDtssiAvgThred),
    _object_int(T_TssiChk, uiDtssiSingleThred),
    _object_int(T_TssiChk, uiDtssiGroupThred),
    _object_int(T_TssiChk, uiTssiMinLen),
    _object_int(T_TssiChk, uiTssiGroupThred),
    _object_int(T_TssiChk, uiTssiSingleThred),
    _object_int(T_TssiChk, uiVsSingleThred),
    _object_int(T_TssiChk, uiSfLen),
    _object_int(T_TssiChk, uiTssiEn),
    _object_int(T_TssiChk, uiAvgSymLen),
    _object_int(T_TssiChk, uiTxPwcStart),
    _object_int(T_TssiChk, uiTxPwcEnd),
    _object_end(T_TssiChk)
};

layout_item_t T_RssiChk_ref_tbl[] = {
    _object_int(T_RssiChk, uiSfLen),
    _object_int(T_RssiChk, uiRxStart),
    _object_int(T_RssiChk, uiRxEnd),
    _object_int(T_RssiChk, uiRx1Start),
    _object_int(T_RssiChk, uiRx1End),
    _object_int(T_RssiChk, uiRxSfEn),
    _object_int(T_RssiChk, uiRx1SfEn),
    _object_int(T_RssiChk, uiRssiCalGrp),
    _object_int(T_RssiChk, uiRssiCalThr),
    _object_int(T_RssiChk, uiRssi1CalThr),
    _object_int(T_RssiChk, uiNbRssiCalThr),
    _object_int(T_RssiChk, uiNbRssi1CalThr),
    _object_int(T_RssiChk, uiModelSel),
    _object_int(T_RssiChk, uiNbModelSel),
    _object_end(T_RssiChk)
};

layout_item_t T_PowCtrl_Para_ref_tbl[] = {
    _object_int(T_PowCtrl_Para, uiRfSwitchDly),
    _object_end(T_PowCtrl_Para)
};

layout_item_t T_PowCtrl_ref_tbl[] = {
    _object_int(T_PowCtrl, ChanNoMask),
    _object_obj(T_PowCtrl, tTssiCheck, T_TssiChk_ref_tbl),
    _object_obj(T_PowCtrl, tRssiCheck, T_RssiChk_ref_tbl),
    _object_obj(T_PowCtrl, tPowCtrlPara, T_PowCtrl_Para_ref_tbl),
    _object_end(T_PowCtrl)
};

layout_item_t T_RfPllCfgInit_ref_tbl[] = {
    _object_int(T_RfPllCfgInit, ifFreq),
    _object_int(T_RfPllCfgInit, loStep),
    _object_int(T_RfPllCfgInit, ncoStep),
    _object_int(T_RfPllCfgInit, cfgSolution),
    _object_int(T_RfPllCfgInit, ncoSolution),
    _object_int(T_RfPllCfgInit, defLoFreqKHz),
    _object_int(T_RfPllCfgInit, defLoFreqKHz0),
    _object_int(T_RfPllCfgInit, IfBw),
    _object_int(T_RfPllCfgInit, dpdRangeLow),
    _object_int(T_RfPllCfgInit, dpdRangeHigh),
    _object_fun(T_RfPllCfgInit, pFixLo),
    _object_int(T_RfPllCfgInit, loToCarrThre),
    _object_int(T_RfPllCfgInit, loToFilterThre),
    _object_int(T_RfPllCfgInit, bandNcoFlag),
    _object_int(T_RfPllCfgInit, bandNcoStep),
    _object_int(T_RfPllCfgInit, bandNcoBase),
    _object_int(T_RfPllCfgInit, WfsAcNcoBase),
    _object_int(T_RfPllCfgInit, loChangeSelectMargin),
    _object_fun(T_RfPllCfgInit, pLoCfg),
    _object_fun(T_RfPllCfgInit, pLoGet),
    _object_fun(T_RfPllCfgInit, pLoCali),
    _object_fun(T_RfPllCfgInit, pGetNcoStep),
    _object_fun(T_RfPllCfgInit, pGetFreqRange),
    _object_fun(T_RfPllCfgInit, pSetCarrBand),
    _object_fun(T_RfPllCfgInit, pSetMtsNco),
    _object_end(T_RfPllCfgInit)
};

layout_item_t T_FreqCfgData_ref_tbl[] = {
    _object_int(T_FreqCfgData, chanSelect),
    _object_obj(T_FreqCfgData, freqPara, T_RfPllCfgInit_ref_tbl),
    _object_end(T_FreqCfgData)
};


/*layout_item_t T_RfPaptCfgUpdata_ref_tbl[] = {
    _object_int(T_RfPaptCfgUpdata, lnaFalg),
    _object_int(T_RfPaptCfgUpdata, mtsAlarmNo),
    _object_int(T_RfPaptCfgUpdata, paMask),
    _object_int(T_RfPaptCfgUpdata, daMask),
    _object_end(T_RfPaptCfgUpdata)
};

layout_item_t T_PaptUpdata_ref_tbl[] = {
    _object_int(T_PaptUpdata, chanSelect),
    _object_obj(T_PaptUpdata, updataCfgPara, T_RfPaptCfgUpdata_ref_tbl),
    _object_end(T_PaptUpdata)
};*/


/*  -------------------------------------------------------------------------  */
/*
    结构体包含指向结构体的指针 E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK
*/
layout_item_t T_BspHalAdaptSocCrmClk_ref_tbl[] = {
    _object_int(T_BspHalAdaptSocCrmClk, clk_spifc1_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spifc2_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spi0_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spi1_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spi2_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spi3_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spi4_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spi5_sys),
    _object_int(T_BspHalAdaptSocCrmClk, clk_spi6_sys),
    _object_end(T_BspHalAdaptSocCrmClk)
};

layout_item_t T_BspHalAdaptCrmPara_BeforeClk_ref_tbl[] = {
    _object_blk(T_BspHalAdaptCrmPara_BeforeClk, tSocClkPara),
    _object_end(T_BspHalAdaptCrmPara_BeforeClk)
};

layout_item_t T_BspHalAdaptPllCrmPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptPllCrmPara, ifType),
    _object_end(T_BspHalAdaptPllCrmPara)
};

layout_item_t T_BspHalAdaptOptCrmClk_ref_tbl[] = {
    _object_int(T_BspHalAdaptOptCrmClk, clk_opt_variable),
    _object_end(T_BspHalAdaptOptCrmClk)
};

layout_item_t T_BspHalAdaptDifCrmClk_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifCrmClk, clk_ul_logic1_0),
    _object_int(T_BspHalAdaptDifCrmClk, clk_ul_logic1_1),
    _object_int(T_BspHalAdaptDifCrmClk, clk_dl_logic2),
    _object_int(T_BspHalAdaptDifCrmClk, clk_dl_logic3_0),
    _object_int(T_BspHalAdaptDifCrmClk, clk_dl_logic3_1),
    _object_int(T_BspHalAdaptDifCrmClk, clk_fb_logic1_0),
    _object_int(T_BspHalAdaptDifCrmClk, clk_fb_logic1_1),
    _object_int(T_BspHalAdaptDifCrmClk, clk_dl_j204_work_0),
    _object_int(T_BspHalAdaptDifCrmClk, clk_dl_j204_work_1),
    _object_int(T_BspHalAdaptDifCrmClk, clk_fb_j204_work),
    _object_int(T_BspHalAdaptDifCrmClk, clk_ul_j204_work),
    _object_end(T_BspHalAdaptDifCrmClk)
};

layout_item_t T_BspHalAdaptCrmRstCommonPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptCrmRstCommonPara, rst_fft_pranch),
    _object_int(T_BspHalAdaptCrmRstCommonPara, rst_roe),
    _object_int(T_BspHalAdaptCrmRstCommonPara, rst_opt),
    _object_int(T_BspHalAdaptCrmRstCommonPara, rst_dif),
    _object_end(T_BspHalAdaptCrmRstCommonPara)
};

layout_item_t T_BspHalAdaptDifCrmClkSelect_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_ulch_0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_ulch_1),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_dlpost_0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_dlpost_1),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_dl_logic6),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_fb0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_fb1),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_cblms),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_fb_logic2_0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_fb_logic2_1),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_dl_logic5_0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_dl_logic5_1),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_sysref),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_fb_logic3_0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_fb_logic3_1),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_dl_logic4_0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_dl_logic4_1),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_ul_logic2_0),
    _object_int(T_BspHalAdaptDifCrmClkSelect, mux_clk_j204_ul_logic2_1),
    _object_end(T_BspHalAdaptDifCrmClkSelect)
};

layout_item_t T_BspHalAdaptCrmPara_AfterClk_ref_tbl[] = {
    _object_blk(T_BspHalAdaptCrmPara_AfterClk, tPllClkPara),
    _object_blk(T_BspHalAdaptCrmPara_AfterClk, tOptClkPara),
    _object_blk(T_BspHalAdaptCrmPara_AfterClk, tDifClkPara),
    _object_blk(T_BspHalAdaptCrmPara_AfterClk, tCommRst),
    _object_blk(T_BspHalAdaptCrmPara_AfterClk, tDifClkSelectPara),
    _object_end(T_BspHalAdaptCrmPara_AfterClk)
};

/*  -------------------------------------------------------------------------  */
/*
    结构体嵌套结构体数组
*/
layout_item_t T_DifResourceAllocFreqPara_ref_tbl[] = {
    _object_int(T_DifResourceAllocFreqPara, uiFreqStart),
    _object_int(T_DifResourceAllocFreqPara, uiFreqEnd),
    _object_int(T_DifResourceAllocFreqPara, uiPimcFlag),
    _object_end(T_DifResourceAllocFreqPara)
};

layout_item_t T_DifResourceAllocChanPara_ref_tbl[] = {
    _object_int(T_DifResourceAllocChanPara, uiTxFreqNum),
    _object_int(T_DifResourceAllocChanPara, uiRxFreqNum),
    _object_array_struct(T_DifResourceAllocChanPara, tTxFreqPara, T_DifResourceAllocFreqPara_ref_tbl, T_DifResourceAllocFreqPara, IC_CHAN_FREQ_MAX_NUM),
    _object_array_struct(T_DifResourceAllocChanPara, tRxFreqPara, T_DifResourceAllocFreqPara_ref_tbl, T_DifResourceAllocFreqPara, IC_CHAN_FREQ_MAX_NUM),
    _object_end(T_DifResourceAllocChanPara)
};

layout_item_t T_BspHalAdaptCbSwStaTbl_ref_tbl[] = {
    _object_int(T_BspHalAdaptCbSwStaTbl, uiStatus),
    _object_int(T_BspHalAdaptCbSwStaTbl, uiChan),
    _object_int(T_BspHalAdaptCbSwStaTbl, uiPeriod),
    _object_end(T_BspHalAdaptCbSwStaTbl)
};

layout_item_t T_BspCbSwStaTbl_ref_tbl[] = {
    _object_int(T_BspCbSwStaTbl, swIndex),
    _object_blk(T_BspCbSwStaTbl, pCbSwStaTbl),
    _object_int(T_BspCbSwStaTbl, tblLen),
    _object_end(T_BspCbSwStaTbl)
};

layout_item_t T_TrxJ204SerdesTxEqPara_ref_tbl[] = {
    _object_int(T_TrxJ204SerdesTxEqPara, chipId),
    _object_int(T_TrxJ204SerdesTxEqPara, laneId),
    _object_int(T_TrxJ204SerdesTxEqPara, eqPre),
    _object_int(T_TrxJ204SerdesTxEqPara, eqPost),
    _object_int(T_TrxJ204SerdesTxEqPara, eqMain),
    _object_end(T_TrxJ204SerdesTxEqPara)
};

layout_item_t T_SERDES_PARAM_ref_tbl[] = {
    _object_int(T_SERDES_PARAM, serdesId),
    _object_int(T_SERDES_PARAM, laneId),
    _object_int(T_SERDES_PARAM, rate),
    _object_double(T_SERDES_PARAM, chlen),
    _object_int(T_SERDES_PARAM, txEqEn),
    _object_int(T_SERDES_PARAM, eoh0),
    _object_int(T_SERDES_PARAM, eoh1),
    _object_int(T_SERDES_PARAM, eoh2),
    _object_int(T_SERDES_PARAM, eoh3),
    _object_end(T_SERDES_PARAM)
};

layout_item_t T_BspHalAdaptSerdesTxCfg_ref_tbl[] = {
    _object_int(T_BspHalAdaptSerdesTxCfg, rate),
    _object_double(T_BspHalAdaptSerdesTxCfg, chlen),
    _object_int(T_BspHalAdaptSerdesTxCfg, txEqEn),
    _object_int(T_BspHalAdaptSerdesTxCfg, eoh0),
    _object_int(T_BspHalAdaptSerdesTxCfg, eoh1),
    _object_int(T_BspHalAdaptSerdesTxCfg, eoh2),
    _object_int(T_BspHalAdaptSerdesTxCfg, eoh3),
    _object_end(T_BspHalAdaptSerdesTxCfg)
};

layout_item_t T_BspHalAdaptSerdesRxCfg_ref_tbl[] = {
    _object_int(T_BspHalAdaptSerdesRxCfg, phaseMin),
    _object_int(T_BspHalAdaptSerdesRxCfg, phaseMax),
    _object_int(T_BspHalAdaptSerdesRxCfg, uVga),
    _object_int(T_BspHalAdaptSerdesRxCfg, uCmtermCtrl),
    _object_end(T_BspHalAdaptSerdesRxCfg)
};

layout_item_t T_OPTRATE_SERDES_PARAM_ref_tbl[] = {
    _object_array_struct(T_OPTRATE_SERDES_PARAM, txRatePara, T_BspHalAdaptSerdesTxCfg_ref_tbl, T_BspHalAdaptSerdesTxCfg, OPT_RATE_TYPE),
    _object_array_struct(T_OPTRATE_SERDES_PARAM, rxRatePara, T_BspHalAdaptSerdesRxCfg_ref_tbl, T_BspHalAdaptSerdesRxCfg, OPT_RATE_TYPE),
    _object_array_struct(T_OPTRATE_SERDES_PARAM, txRateParaEx, T_BspHalAdaptSerdesTxCfg_ref_tbl, T_BspHalAdaptSerdesTxCfg, OPT_RATE_TYPE),
    _object_end(T_OPTRATE_SERDES_PARAM)
};

layout_item_t T_BspHalAdaptPcsCfg_ref_tbl[] = {
    _object_int(T_BspHalAdaptPcsCfg, uPcsPortIdx),
    _object_int(T_BspHalAdaptPcsCfg, uEthOrCpri),
    _object_int(T_BspHalAdaptPcsCfg, uBindMode1x4x),
    _object_int(T_BspHalAdaptPcsCfg, uPortMode),
    _object_int(T_BspHalAdaptPcsCfg, uProtocolType),
    _object_int(T_BspHalAdaptPcsCfg, uFecMode),
    _object_int(T_BspHalAdaptPcsCfg, uGearBoxBW),
    _object_int(T_BspHalAdaptPcsCfg, uEvenOutEn),
    _object_int(T_BspHalAdaptPcsCfg, uEvenOutSpeed1x),
    _object_int(T_BspHalAdaptPcsCfg, uSelfdefEthEn),    
    _object_end(T_BspHalAdaptPcsCfg)
};


layout_item_t T_OPT_SERDES_PCS_PARAM_ref_tbl[] = {
    _object_int(T_OPT_SERDES_PCS_PARAM, laneMask),
    _object_array_struct(T_OPT_SERDES_PCS_PARAM, serdesParam, T_SERDES_PARAM_ref_tbl, T_SERDES_PARAM, OPT_SERDES_LANE_MAX_NUM),
    _object_array_struct(T_OPT_SERDES_PCS_PARAM, serdesRxCfg, T_BspHalAdaptSerdesRxCfg_ref_tbl, T_BspHalAdaptSerdesRxCfg, OPT_SERDES_LANE_MAX_NUM),
    _object_array_struct(T_OPT_SERDES_PCS_PARAM, pcsCfg, T_BspHalAdaptPcsCfg_ref_tbl, T_BspHalAdaptPcsCfg, OPT_PCS_LANE_MAX_NUM),
    _object_obj(T_OPT_SERDES_PCS_PARAM, optRatePara, T_OPTRATE_SERDES_PARAM_ref_tbl),
    _object_int(T_OPT_SERDES_PCS_PARAM, innerLanMask),
    _object_end(T_OPT_SERDES_PCS_PARAM)
};

layout_item_t T_J204LaneCfg_ref_tbl[] = { 
    _object_int(T_J204LaneCfg, laneIdMask),
    _object_int(T_J204LaneCfg, mapMask),
    _object_int(T_J204LaneCfg, dateRate),
    _object_blk(T_J204LaneCfg, pLinkInfo), 
    _object_int(T_J204LaneCfg, linkSize),
    _object_blk(T_J204LaneCfg, pMapInfo), 
    _object_int(T_J204LaneCfg, mapSize),
    _object_blk(T_J204LaneCfg, pCmdInfo),
    _object_int(T_J204LaneCfg, cmdSize),   
    _object_end(T_J204LaneCfg)
};

layout_item_t T_J204LinkPara_ref_tbl[] = { // 二维数组暂不支持
    _object_int(T_J204LinkPara, j204Mode),
    _object_array_struct(T_J204LinkPara, laneCfg, T_J204LaneCfg_ref_tbl, T_J204LaneCfg, J204_LANE_GRP_NUM),
    _object_end(T_J204LinkPara)
};

layout_item_t T_PreAllocBaseInfo_ref_tbl[] = {
    _object_int(T_PreAllocBaseInfo, uMode),
    _object_int(T_PreAllocBaseInfo, uScs),
    _object_int(T_PreAllocBaseInfo, uAntNum),
    _object_int(T_PreAllocBaseInfo, uIfType), 
    _object_int(T_PreAllocBaseInfo, uBw),
    _object_int(T_PreAllocBaseInfo, uAllocType),
    _object_end(T_PreAllocBaseInfo)
};

layout_item_t T_BspHalAdaptPreAllocCarrInfo_ref_tbl[] = {
    _object_int(T_BspHalAdaptPreAllocCarrInfo, senceType),
    _object_array_struct(T_BspHalAdaptPreAllocCarrInfo, preAllocInfo, T_PreAllocBaseInfo_ref_tbl, T_PreAllocBaseInfo, PRE_ALLOC_INFO_TYPE),
    _object_end(T_BspHalAdaptPreAllocCarrInfo)
};


layout_item_t T_BspHalAdaptPowChk_ref_tbl[] = {
    _object_int(T_BspHalAdaptPowChk, uiPowNum),
    _object_array_struct(T_BspHalAdaptPowChk, tPow, T_PowCtrl_ref_tbl, T_PowCtrl, BSP_MAX_TDD_NUM),
    _object_end(T_BspHalAdaptPowChk)
};
/*  -------------------------------------------------------------------------  */
/*
    结构体数组 E_CHIP_POWERON_ATT_INIT
*/
layout_item_t T_ATTVGA_CFGPARA_ref_tbl[] = {
    _object_int(T_ATTVGA_CFGPARA, pathType),
    _object_int(T_ATTVGA_CFGPARA, chipIdx),
    _object_int(T_ATTVGA_CFGPARA, chipInnerIdx),
    _object_int(T_ATTVGA_CFGPARA, chipType),
    _object_int(T_ATTVGA_CFGPARA, deFaultVal),
    _object_int(T_ATTVGA_CFGPARA, attMaxVal),
    _object_int(T_ATTVGA_CFGPARA, attMinVal),
    _object_int(T_ATTVGA_CFGPARA, attStep),
    _object_int(T_ATTVGA_CFGPARA, attMask),
    _object_int(T_ATTVGA_CFGPARA, attValInversedCfg),
    _object_int(T_ATTVGA_CFGPARA, attValInversedGet),
    _object_int(T_ATTVGA_CFGPARA, attFpgaLeast),
    _object_end(T_ATTVGA_CFGPARA)
};

layout_item_t T_RfPllInit_Para_ref_tbl[] = {
    _object_int(T_RfPllInit_Para, dlDirect),
    _object_int(T_RfPllInit_Para, ulDirect),
    _object_int(T_RfPllInit_Para, prlDirect),
    _object_end(T_RfPllInit_Para)
};

layout_item_t T_DpdicPwrSaveSel_ref_tbl[] = {
    _object_int(T_DpdicPwrSaveSel, difTxUnusedResSel),
    _object_int(T_DpdicPwrSaveSel, difRxUnusedResSel),
    _object_int(T_DpdicPwrSaveSel, a53CoreMask),
    _object_int(T_DpdicPwrSaveSel, optDifIf0CompMask),
    _object_int(T_DpdicPwrSaveSel, optDifIf1CompMask),
    _object_int(T_DpdicPwrSaveSel, optDifAximMask),
    _object_int(T_DpdicPwrSaveSel, optGfOranMask),
    _object_int(T_DpdicPwrSaveSel, optGfBdrMask),
    _object_int(T_DpdicPwrSaveSel, optGfChMask),
    _object_int(T_DpdicPwrSaveSel, optBifOranMask),
    _object_int(T_DpdicPwrSaveSel, optBifChMask),
    _object_int(T_DpdicPwrSaveSel, optSw1OptSw1Sel),
    _object_int(T_DpdicPwrSaveSel, optSw1MapSel),
    _object_int(T_DpdicPwrSaveSel, optCpriFrmMask),
    _object_int(T_DpdicPwrSaveSel, optCpriSerdesMask),
    _object_int(T_DpdicPwrSaveSel, optPrach01Sel),
    _object_int(T_DpdicPwrSaveSel, optPrach00Sel),
    _object_int(T_DpdicPwrSaveSel, optFft1Sel),
    _object_int(T_DpdicPwrSaveSel, optFft0Sel),
    _object_int(T_DpdicPwrSaveSel, optRoeIq0Sel),
    _object_int(T_DpdicPwrSaveSel, optRoeIq1Sel),
    _object_int(T_DpdicPwrSaveSel, optRoeIq2Sel),
    _object_int(T_DpdicPwrSaveSel, optRoeIq3Sel),
    _object_int(T_DpdicPwrSaveSel, optRoeNtlCtrlSel),
    _object_int(T_DpdicPwrSaveSel, difAllSel),
    _object_int(T_DpdicPwrSaveSel, j204DlLaneMask),
    _object_int(T_DpdicPwrSaveSel, j204FbLaneMask),
    _object_int(T_DpdicPwrSaveSel, j204UlLaneMask),
    _object_int(T_DpdicPwrSaveSel, j204DlMapMask),
    _object_int(T_DpdicPwrSaveSel, j204FbMapMask),
    _object_int(T_DpdicPwrSaveSel, j204UlMapMask),
    _object_end(T_DpdicPwrSaveSel)
};

layout_item_t T_TRXACATT_CFGPARA_ref_tbl[] = {
    _object_int(T_TRXACATT_CFGPARA, pathType),
    _object_int(T_TRXACATT_CFGPARA, chipIdx),
    _object_int(T_TRXACATT_CFGPARA, chan),
    _object_int(T_TRXACATT_CFGPARA, attValue),
    _object_int(T_TRXACATT_CFGPARA, mask),
    _object_end(T_TRXACATT_CFGPARA)
};

layout_item_t T_PHY_OPT_PROPERTY_ref_tbl[] = {
    _object_int(T_PHY_OPT_PROPERTY, uProperty),
    _object_int(T_PHY_OPT_PROPERTY, uPropertyCfgEn),
    _object_int(T_PHY_OPT_PROPERTY, uChipInterConn),
    _object_end(T_PHY_OPT_PROPERTY)
};

layout_item_t T_LOG_OPT_PROPERTY_ref_tbl[] = {
    _object_int(T_LOG_OPT_PROPERTY, uRelationPhyopt),
    _object_int(T_LOG_OPT_PROPERTY, uBindOptSel),
    _object_int(T_LOG_OPT_PROPERTY, uExternMode),
    _object_int(T_LOG_OPT_PROPERTY, uFrameAlignPeriod),
    _object_int(T_LOG_OPT_PROPERTY, uSwAlignPeriod),
    _object_end(T_LOG_OPT_PROPERTY)
};

layout_item_t T_BspHalAdaptOptCpriInfo_ref_tbl[] = {
    _object_int(T_BspHalAdaptOptCpriInfo, uQcellEn),
    _object_int(T_BspHalAdaptOptCpriInfo, uNetMode),
    _object_int(T_BspHalAdaptOptCpriInfo, uCpuCfgEn),
    _object_int(T_BspHalAdaptOptCpriInfo, uMainOpt),
    _object_int(T_BspHalAdaptOptCpriInfo, uPhyOptCfgMask),
    _object_array_struct(T_BspHalAdaptOptCpriInfo, phyOptProp, T_PHY_OPT_PROPERTY_ref_tbl, T_PHY_OPT_PROPERTY, OPT_MAX + 1),
    _object_int(T_BspHalAdaptOptCpriInfo, uLogOptCfgMask),
    _object_array_struct(T_BspHalAdaptOptCpriInfo, logOptProp, T_LOG_OPT_PROPERTY_ref_tbl, T_LOG_OPT_PROPERTY, OPT_MAX + 1),
    _object_end(T_BspHalAdaptOptCpriInfo)
};

layout_item_t T_BspHalAdaptDifResAllocChanPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifResAllocChanPara, uiTxFreqNum),
    _object_int(T_BspHalAdaptDifResAllocChanPara, uiRxFreqNum),
    _object_array_struct(T_BspHalAdaptDifResAllocChanPara, tTxFreqPara, T_DifResourceAllocFreqPara_ref_tbl, T_DifResourceAllocFreqPara, IC_CHAN_FREQ_MAX_NUM),
    _object_array_struct(T_BspHalAdaptDifResAllocChanPara, tRxFreqPara, T_DifResourceAllocFreqPara_ref_tbl, T_DifResourceAllocFreqPara, IC_CHAN_FREQ_MAX_NUM),
    _object_end(T_BspHalAdaptDifResAllocChanPara)
};

layout_item_t T_J204OnePairEnds_ref_tbl[] = {
    _object_int(T_J204OnePairEnds, dpdicLaneMask),
    _object_int(T_J204OnePairEnds, dpdicGrpMask),
    _object_int(T_J204OnePairEnds, transIdMask),
    _object_end(T_J204OnePairEnds)
};


layout_item_t T_J204PairEndsInfo_ref_tbl[] = {
    _object_array_struct(T_J204PairEndsInfo, onePairEnds, T_J204OnePairEnds_ref_tbl, T_J204OnePairEnds, J204_PAIRS_NUM_MAX),
    _object_end(T_J204PairEndsInfo)
};

layout_item_t T_PartitionMap_ref_tbl[] = {
    _object_array_string(T_PartitionMap, acPartitionName, char, BLOCK_NAME_LEN),
    _object_int(T_PartitionMap, ulPartitionOffset),
    _object_int(T_PartitionMap, ulPartitionSize), 
    _object_end(T_PartitionMap)
};

layout_item_t T_FlashInfo_ref_tbl[] = {
    _object_int(T_FlashInfo, ulFlashSize),
    _object_int(T_FlashInfo, ulSectorSize),
    _object_int(T_FlashInfo, ulPartitionNum),
    _object_array_struct(T_FlashInfo, atPartitionMap, T_PartitionMap_ref_tbl, T_PartitionMap, MAX_BLOCK_NUM),
    _object_end(T_FlashInfo)
};

layout_item_t T_PartRunVerList_ref_tbl[] = {
    _object_int(T_PartRunVerList, ulSoftType),
    _object_array_string(T_PartRunVerList, acFileName, char, 32),
    _object_array_string(T_PartRunVerList, acVerName, char, 32),
    _object_end(T_PartRunVerList)
};

layout_item_t T_AllRunVerList_ref_tbl[] = {
    _object_int(T_AllRunVerList, ulMasterVerNum),
    _object_int(T_AllRunVerList, ulSlaveVerNum),
    _object_array_struct(T_AllRunVerList, tMasterRunVerList, T_PartRunVerList_ref_tbl, T_PartRunVerList, MASTER_VER_NUM_MAX),
    _object_array_struct(T_AllRunVerList, tSlaveRunVerList, T_PartRunVerList_ref_tbl, T_PartRunVerList, SLAVE_VER_NUM_MAX),
    _object_int(T_AllRunVerList, writeXmlFile),
    _object_end(T_AllRunVerList)
};

layout_item_t T_DpdicSocReset_ref_tbl[] = {
    _object_int(T_DpdicSocReset, rstType),
    _object_int(T_DpdicSocReset, chipMask),
    _object_end(T_DpdicSocReset)
};

/*  -------------------------------------------------------------------------  */
/*
    结构体嵌套整形数组
*/
layout_item_t T_DefPaPara_ref_tbl[] = {
    _object_array_int(T_DefPaPara, ulPaVolt, int, BSP_MAX_TX_CHAN),
    _object_array_int(T_DefPaPara, uDflTxInsertLoss, int, BSP_MAX_TX_CHAN),
    _object_int(T_DefPaPara, ulTempdelta),
    _object_end(T_DefPaPara)
};

layout_item_t T_IC_TRX_PIN_MAP_ref_tbl[] = {
    _object_array_int(T_IC_TRX_PIN_MAP, icPinId, int, HALADAPT_TRANS_MAX_NUM),
    _object_end(T_IC_TRX_PIN_MAP)
};

layout_item_t T_BspHalAdaptOptInitCfgInfo_ref_tbl[] = {
    _object_array_int(T_BspHalAdaptOptInitCfgInfo, reserved, int, 4),
    _object_int(T_BspHalAdaptOptInitCfgInfo, optWorkMode),
    _object_int(T_BspHalAdaptOptInitCfgInfo, ulRate),
    _object_end(T_BspHalAdaptOptInitCfgInfo)
};

layout_item_t T_BspHalAdaptDifClkPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifClkPara, ui737Clk),
    _object_int(T_BspHalAdaptDifClkPara, uiDlCfrClk),
    _object_int(T_BspHalAdaptDifClkPara, uiDlDpdClk),
    _object_array_int(T_BspHalAdaptDifClkPara, uiDlPostClk, int, CLK_DL_LOGIC4_NUM),
    _object_int(T_BspHalAdaptDifClkPara, uiDlPimcClk),
    _object_array_int(T_BspHalAdaptDifClkPara, uiUlChClk, int, CLK_UL_LOGIC1_NUM),
    _object_array_int(T_BspHalAdaptDifClkPara, uiCbClk, int, CLK_FB_LOGIC1_NUM),
    _object_int(T_BspHalAdaptDifClkPara, uiDlJ204SampleClk),
    _object_int(T_BspHalAdaptDifClkPara, uiDlJ204WorkClk),
    _object_int(T_BspHalAdaptDifClkPara, uiDlJ204SerdesClk),
    _object_int(T_BspHalAdaptDifClkPara, uiUlJ204SampleClk),
    _object_int(T_BspHalAdaptDifClkPara, uiUlJ204WorkClk),
    _object_int(T_BspHalAdaptDifClkPara, uiUlJ204SerdesClk),
    _object_int(T_BspHalAdaptDifClkPara, uiFbJ204SampleClk),    
    _object_int(T_BspHalAdaptDifClkPara, uiFbJ204WorkClk), 
    _object_int(T_BspHalAdaptDifClkPara, uiFbJ204SerdesClk), 
    _object_int(T_BspHalAdaptDifClkPara, uiJ204UlLogic2Clk), 
    _object_int(T_BspHalAdaptDifClkPara, uiJ204DlLogic5Clk), 
    _object_int(T_BspHalAdaptDifClkPara, uiJ204FbLogic2Clk), 
    _object_end(T_BspHalAdaptDifClkPara)
};

layout_item_t T_BspHalAdaptDifSamRatePara_ref_tbl[] = {
    _object_array_int(T_BspHalAdaptDifSamRatePara, uiDpdSamRate, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifSamRatePara, uiCfrSamRate, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifSamRatePara, uiAdcSamRate, int, DIF_SAMP_RATE_NUM),
    _object_int(T_BspHalAdaptDifSamRatePara, uiAdcSamMode),
    _object_array_int(T_BspHalAdaptDifSamRatePara, uiDacSamRate, int, DIF_SAMP_RATE_NUM),
    _object_int(T_BspHalAdaptDifSamRatePara, uiDacSamMode),
    _object_array_int(T_BspHalAdaptDifSamRatePara, uiCbAdcSamRate, int, DIF_SAMP_RATE_NUM),
    _object_int(T_BspHalAdaptDifSamRatePara, uiCbAdcSamMode),
    _object_end(T_BspHalAdaptDifSamRatePara)
};

layout_item_t T_BspHalAdaptDifCfgPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptDifCfgPara, uiIqDataMode),
    _object_int(T_BspHalAdaptDifCfgPara, uiRruType),
    _object_array_int(T_BspHalAdaptDifCfgPara, ui204ValidWidth, int, IC_CHAN_MAX_NUM),
    _object_end(T_BspHalAdaptDifCfgPara)
};

layout_item_t T_BspHalAdaptDifCommCfrPara_ref_tbl[] = {
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCfrPeakMode, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCfrGrade, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCfrSample, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCfrClk, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiInter, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCpgPhase, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiDelayEqualFlag, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCpgCoefLenHalfMax, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCfrBypassMode, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCfrProtectMode, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCpgLen, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCpgMsLutProtect, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiCpgMode, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiThrSel, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptDifCommCfrPara, uiDlpreEpld, int, IC_CHAN_MAX_NUM),
    _object_end(T_BspHalAdaptDifCommCfrPara)
};

layout_item_t T_BspHalAdaptCfrParaHardCpg_ref_tbl[] = {
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiKiLut, int, DLCFR_KILUT_LEN),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiFreqIndexMode, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiFreqCalMode, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiStepGate, int, DLCFR_STEP_GATE_LEN),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiSymNum0, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiSymNum1, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiSymNum2, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiPowThr, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiSymNumFrclr, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiPowDvSel, int, IC_CHAN_MAX_NUM),
    _object_array_int(T_BspHalAdaptCfrParaHardCpg, uiPowDvDly, int, IC_CHAN_MAX_NUM),
    _object_end(T_BspHalAdaptCfrParaHardCpg)
};
layout_item_t T_BspHalAdaptCfrKnWordPara_ref_tbl[] = {
    _object_array_int(T_BspHalAdaptCfrKnWordPara, uiKnLut, int, DLCFR_KNLUT_LEN),
    _object_array_int(T_BspHalAdaptCfrKnWordPara, uiMidLut, int, DLCFR_FREQ_WORD_LUT_LEN),
    _object_array_int(T_BspHalAdaptCfrKnWordPara, uiHighLut, int, DLCFR_FREQ_WORD_LUT_LEN),
    _object_array_int(T_BspHalAdaptCfrKnWordPara, uiLowLut, int, DLCFR_FREQ_WORD_LUT_LEN),
    _object_end(T_BspHalAdaptCfrKnWordPara)
};

layout_item_t T_GainCommPara_ref_tbl[] = {
    _object_array_int(T_GainCommPara, preCfrGain, int, IC4_2_MAX_CHN_NUM),
    _object_array_int(T_GainCommPara, preDpdGain, int, IC4_2_MAX_CHN_NUM),
    _object_array_int(T_GainCommPara, outDpdGain, int, IC4_2_MAX_CHN_NUM),
    _object_array_int(T_GainCommPara, dlPreGain, int, IC4_2_MAX_CHN_NUM),
    _object_array_int(T_GainCommPara, dlBankDgain, int, IC4_2_MAX_CHN_NUM),
    _object_array_int(T_GainCommPara, dlBankApTuneGain, int, IC4_2_MAX_CHN_NUM),
    _object_end(T_GainCommPara)
};

layout_item_t T_DlPowCalcPara_ref_tbl[] = {
    _object_array_int(T_DlPowCalcPara, lvVal, int, E_POW_CALC_MAX),
    _object_end(T_DlPowCalcPara)
};

layout_item_t T_ChanGroupInfo_ref_tbl[] = {
    _object_int(T_ChanGroupInfo, txChanGroupNum),
    _object_array_int(T_ChanGroupInfo, txChanGroupMask, int, MAX_TDD_GROUP_NUM),
    _object_int(T_ChanGroupInfo, rxChanGroupNum),
    _object_array_int(T_ChanGroupInfo, rxChanGroupMask, int, MAX_TDD_GROUP_NUM),
    _object_end(T_ChanGroupInfo)
};

layout_item_t T_BspHalAdaptVgaCtrlComPara_ref_tbl[] = {
    _object_int(T_BspHalAdaptVgaCtrlComPara, uiVgaMode),
    _object_int(T_BspHalAdaptVgaCtrlComPara, uiAgcJ204Switch),
    _object_int(T_BspHalAdaptVgaCtrlComPara, uiAdcSlicerMode),
    _object_array_int(T_BspHalAdaptVgaCtrlComPara, uiVgaLutTab, int, 64),
    _object_end(T_BspHalAdaptVgaCtrlComPara)
};

layout_item_t T_PowThreInitPara_ref_tbl[] = {
    _object_int(T_PowThreInitPara, chanmask),
    _object_int(T_PowThreInitPara, powAvgCnt),
    _object_array_int(T_PowThreInitPara, powDbmThreshold, int, THRESHOLD_NUM),
    _object_array_int(T_PowThreInitPara, vswrThreshold, int, THRESHOLD_NUM),
    _object_array_int(T_PowThreInitPara, vswrPowThresHold, int, THRESHOLD_NUM),
    _object_end(T_PowThreInitPara)
};

layout_item_t T_TempThreInitPara_ref_tbl[] = {
    _object_int(T_ThresholdPara, devIdVal),
    _object_int(T_ThresholdPara, tempType),
    _object_int(T_ThresholdPara, thresholdType),
    _object_int(T_ThresholdPara, alarmThreshold),
    _object_int(T_ThresholdPara, recoverThreshold),
    _object_end(T_ThresholdPara)
};

layout_item_t T_RU_LINK_MAP_ref_tbl[] = {
    _object_array_int(T_RU_LINK_MAP, linkInfo, int, LINK_INFO_TYPE_NUM),
    _object_end(T_RU_LINK_MAP)
};

layout_item_t T_RU_LINK_MAP_TDDIO_ref_tbl[] = {
    _object_array_int(T_RU_LINK_MAP_TDDIO, linkInfo, int, LINK_INFO_TYPE_NUM_TDDIO),
    _object_end(T_RU_LINK_MAP_TDDIO)
};

layout_item_t T_TDDIO_CONCTRL_PARA_ref_tbl[] = {
    _object_int(T_TDDIO_CONCTRL_PARA, tddNum),
    _object_array_int(T_TDDIO_CONCTRL_PARA, tddTimingGenType, int, DPDIC_MAX_TIMING_GEN_SEL_TYPE),
    _object_array_int(T_TDDIO_CONCTRL_PARA, tddCtrlBaseCfgType, int, DPDIC_MAX_TDD_NUM),
    _object_end(T_TDDIO_CONCTRL_PARA)
};

layout_item_t T_TDDIO_EXCEPT_CTRL_ref_tbl[] = {
    _object_array_int(T_TDDIO_EXCEPT_CTRL, tddOutSel, int, E_TDD_IO_DEF_TYPE_MAX),
    _object_int(T_TDDIO_EXCEPT_CTRL, reserve),
    _object_end(T_TDDIO_EXCEPT_CTRL)
};

layout_item_t T_PWR_MAP_CHAN_ref_tbl[] = {
    _object_int(T_PWR_MAP_CHAN, pwrNum),
    _object_array_int(T_PWR_MAP_CHAN, chnPwrIdx, int, BSP_MAX_CHAN_NUM),
    _object_end(T_PWR_MAP_CHAN)
};

layout_item_t Papt_Opt_Cfg_Info_ref_tbl[] = {
    _object_int(Papt_Opt_Cfg_Info, openPaDaFlag),
    _object_int(Papt_Opt_Cfg_Info, sbcDaOffMaskInfo),
    _object_int(Papt_Opt_Cfg_Info, daOffDlyInfo),
    _object_int(Papt_Opt_Cfg_Info, daOnDlyInfo),
    _object_int(Papt_Opt_Cfg_Info, difDaOffAlmMaskInfo),
    _object_int(Papt_Opt_Cfg_Info, difPaOffAlmMaskInfo),
    _object_int(Papt_Opt_Cfg_Info, difDaOffSecMaskInfo),
    _object_int(Papt_Opt_Cfg_Info, difPaOffSecMaskInfo),
    _object_array_int(Papt_Opt_Cfg_Info, serdesAlmMaskInfo, int, IC4_2_OPT_NUM_MAX),
    _object_array_int(Papt_Opt_Cfg_Info, localLogicAlmMaskInfo, int, IC4_2_OPT_NUM_MAX),
    _object_array_int(Papt_Opt_Cfg_Info, cascLogicAlmMaskInfo, int, IC4_2_OPT_NUM_MAX),
    _object_array_int(Papt_Opt_Cfg_Info, logicDaOffAlmMaskInfo, int, IC4_2_OPT_NUM_MAX),
    _object_array_int(Papt_Opt_Cfg_Info, logicPaOffAlmMaskInfo, int, IC4_2_OPT_NUM_MAX),
    _object_int(Papt_Opt_Cfg_Info, DifPhyAlmDaMaskInfo),
    _object_int(Papt_Opt_Cfg_Info, DifPaOffSecMaskInfo),
    _object_int(Papt_Opt_Cfg_Info, DifPaOffPhyAlmDaMaskInfo),
    _object_end(Papt_Opt_Cfg_Info)
};

layout_item_t T_DpdicSocLoadOrder_ref_tbl[] = {
    _object_int(T_DpdicSocLoadOrder, chipMask),
    _object_array_int(T_DpdicSocLoadOrder, socLoadChipNo, int, DPDIC_SOC_MAX_NUM),
    _object_end(T_DpdicSocLoadOrder)
};
/*  -------------------------------------------------------------------------  */
/*
    float数据
*/
layout_item_t T_CfrDynPara_TDD_ref_tbl[] = {
    _object_float(T_CfrDynPara_TDD, lowbound),
    _object_float(T_CfrDynPara_TDD, upbound),
    _object_array_int(T_CfrDynPara_TDD, cfrgate, int, E_CFR_THR_NUM),
    _object_array_int(T_CfrDynPara_TDD, cfrwin, int, E_CFR_THR_NUM),
    _object_array_int(T_CfrDynPara_TDD, cfrdelt, int, E_CFR_THR_NUM),
    _object_array_int(T_CfrDynPara_TDD, cfrwinlevel, int, E_CFR_THR_NUM),
    _object_end(T_CfrDynPara_TDD)
};

layout_item_t T_TDD_IO_BASE_PARA_INFO_ref_tbl[] = {
    _object_double(T_TDD_IO_BASE_PARA_INFO, txEnAdvOn),
    _object_double(T_TDD_IO_BASE_PARA_INFO, paAdvOn),
    _object_double(T_TDD_IO_BASE_PARA_INFO, txEnDlyOff),
    _object_double(T_TDD_IO_BASE_PARA_INFO, paDlyOff),
    _object_double(T_TDD_IO_BASE_PARA_INFO, rxEnAdvOn),
    _object_double(T_TDD_IO_BASE_PARA_INFO, lnaAdvOn),
    _object_double(T_TDD_IO_BASE_PARA_INFO, rxEnDlyOff),
    _object_double(T_TDD_IO_BASE_PARA_INFO, lnaDlyOff),
    _object_double(T_TDD_IO_BASE_PARA_INFO, txEnGap),
    _object_double(T_TDD_IO_BASE_PARA_INFO, paGap),
    _object_double(T_TDD_IO_BASE_PARA_INFO, rxEnGap),
    _object_double(T_TDD_IO_BASE_PARA_INFO, lnaGap),
    _object_double(T_TDD_IO_BASE_PARA_INFO, switchAdv),
    _object_double(T_TDD_IO_BASE_PARA_INFO, switchDly), 
    _object_end(T_TDD_IO_BASE_PARA_INFO)
};

/*  -------------------------------------------------------------------------  */
/*
    字符串数据
*/
layout_item_t T_FileMoveList_ref_tbl[] = {
    _object_string(T_FileMoveList, pSourcePath),
    _object_string(T_FileMoveList, pDestPath),
    _object_int(T_FileMoveList, moveWay),
    _object_end(T_FileMoveList)
};

layout_item_t TVerGroup_ref_tbl[] = {
    _object_array_string(TVerGroup, cNickname, char, TMP_MAX_LENGTH),
    _object_int(TVerGroup, nameIdx),
    _object_array_int(TVerGroup, HardId, int, BOM_ID_NUM),
    _object_end(TVerGroup)
};

layout_item_t T_BoardIdItem_ref_tbl[] = {
    _object_int(T_BoardIdItem, ulIdVal),
    _object_string(T_BoardIdItem, pucName),
    _object_string(T_BoardIdItem, pucAlias),
    _object_int(T_BoardIdItem, ulIdNum), 
    _object_int(T_BoardIdItem, ulIdAddr),
    _object_end(T_BoardIdItem)
};

layout_item_t T_RruPropertyInfo_ref_tbl[] = {
    _object_string(T_RruPropertyInfo, ascbuf),
    _object_int(T_RruPropertyInfo, bufSize),
    _object_end(T_RruPropertyInfo)
};


/*  -------------------------------------------------------------------------  */
/*
    函数指针 act4
*/
typedef void (*CallBackRruTest)(void);

void RruTestFunc1(void)
{
    printf("I am rru test1\n");
    return;
}

void RruTestFunc2(void)
{
    printf("I am rru test2\n");
    return;
}

typedef struct tag_RruTest
{
    UINT32 rruType;
    CallBackRruTest pFunc;
}T_RruTest;

layout_item_t T_RruTest_ref_tbl[] = {
    _object_int(T_RruTest, rruType),
    _object_fun(T_RruTest, pFunc),
    _object_end(T_RruTest)
};

/*  -------------------------------------------------------------------------  */
/*
    函数指针 act4  T_RxOpenLoopPara
*/

/*  -------------------------------------------------------------------------  */
layout_item_t T_RxOpenLoopPara_ref_tbl[] = {
    _object_array_int(T_RxOpenLoopPara, preAttMin, int, BSP_MAX_RX_CHAN),
    _object_array_int(T_RxOpenLoopPara, preAttMax, int, BSP_MAX_RX_CHAN),
    _object_fun(T_RxOpenLoopPara, pSetPreAtt),
    _object_fun(T_RxOpenLoopPara, pSetPostAtt),
    _object_array_int(T_RxOpenLoopPara, preAtt, int, BSP_MAX_RX_CHAN),
    _object_array_int(T_RxOpenLoopPara, digAttMin, int, BSP_MAX_RX_CHAN),
    _object_array_int(T_RxOpenLoopPara, digAttMax, int, BSP_MAX_RX_CHAN),
    _object_end(T_RxOpenLoopPara)
};

layout_item_t T_BspCbSwPara_ref_tbl[] = {
    _object_int(T_BspCbSwPara, swIndex),
    _object_int(T_BspCbSwPara, transBitSel),
    _object_int(T_BspCbSwPara, ConnectMode),
    _object_int(T_BspCbSwPara, frameNo),
    _object_int(T_BspCbSwPara, swMode),
    _object_int(T_BspCbSwPara, frBitEn),
    _object_int(T_BspCbSwPara, fwdRevLen),
    _object_end(T_BspCbSwPara)
};

layout_item_t T_GpioPadInfoModify_ref_tbl[] = {
    _object_int(T_GpioPadInfoModify, padName),
    _object_string(T_GpioPadInfoModify, padStrName),
    _object_int(T_GpioPadInfoModify, padType),
    _object_int(T_GpioPadInfoModify, padStCfg),
    _object_int(T_GpioPadInfoModify, padSlCfg),
    _object_int(T_GpioPadInfoModify, padPullCfg),
    _object_int(T_GpioPadInfoModify, padDsCfg),
    _object_int(T_GpioPadInfoModify, padFuncSel),
    _object_int(T_GpioPadInfoModify, padCfgDone),
    _object_end(T_GpioPadInfoModify)
};

layout_item_t T_DACVOLT_CFGPARA_ref_tbl[] = {
    _object_int(T_DACVOLT_CFGPARA, chipIdx),
    _object_int(T_DACVOLT_CFGPARA, chainLen),
    _object_int(T_DACVOLT_CFGPARA, refVolt),
    _object_fun(T_DACVOLT_CFGPARA, pSetVoltVal),
    _object_fun(T_DACVOLT_CFGPARA, pGetVoltVal),
    _object_fun(T_DACVOLT_CFGPARA, pGetDacType),
    _object_fun(T_DACVOLT_CFGPARA, pGetDacNum),
    _object_fun(T_DACVOLT_CFGPARA, pGetAdcTempVal),  
    _object_fun(T_DACVOLT_CFGPARA, pTakeCtrlSpi),
    _object_end(T_DACVOLT_CFGPARA)
};

layout_item_t T_J204TrxCallBackCfg_ref_tbl[] = {
    _object_int(T_J204TrxCallBackCfg, deviceType),
    _object_fun(T_J204TrxCallBackCfg, pTrxCheckSysrefFunc),
    _object_fun(T_J204TrxCallBackCfg, pTrxCheck204LinkFunc),
    _object_fun(T_J204TrxCallBackCfg, pTrxSendSysrefFunc),
    _object_end(T_J204TrxCallBackCfg)
};

layout_item_t T_PaPwrVoltCtrlPara_ref_tbl[] = {
    _object_int(T_PaPwrVoltCtrlPara, period),
    _object_fun(T_PaPwrVoltCtrlPara, cycleTime),
    _object_fun(T_PaPwrVoltCtrlPara, pSetVolt),
    _object_fun(T_PaPwrVoltCtrlPara, pGetVolt),
    _object_fun(T_PaPwrVoltCtrlPara, pGetInputPwrConsu),
    _object_end(T_PaPwrVoltCtrlPara)
};

layout_item_t T_NtfCfgData_ref_tbl[] = {
    _object_int(T_NtfCfgData, ntfSupportFlag),
    _object_int(T_NtfCfgData, ntfPowFlag),
    _object_int(T_NtfCfgData, ntfTssiFwdDiffThreshold),
    _object_int(T_NtfCfgData, adcStatusMask),
    _object_fun(T_NtfCfgData, pTest204c),
    _object_end(T_NtfCfgData)
};

layout_item_t T_RfTblFileMenu_ref_tbl[] = {
    _object_int(T_RfTblFileMenu, ulFileType),
    _object_int(T_RfTblFileMenu, ulFileProp),
    _object_int(T_RfTblFileMenu, ulLoadState),
    _object_int(T_RfTblFileMenu, ulIsErrAlm),
    _object_int(T_RfTblFileMenu, ulSubFileNum),
    _object_string(T_RfTblFileMenu, pAtaFile),
    _object_string(T_RfTblFileMenu, pFsFile),
    _object_int(T_RfTblFileMenu, ulChanPro),
    _object_fun(T_RfTblFileMenu, pTblConvert),
    _object_end(T_RfTblFileMenu)
};

layout_item_t T_ChBndSupInfo_ref_tbl[] = {
    _object_int(T_ChBndSupInfo, dir),
    _object_int(T_ChBndSupInfo, chan),
    _object_array_int(T_ChBndSupInfo, band, UINT32, 3),
    _object_end(T_ChBndSupInfo)
};

layout_item_t T_PwrSupplyConfig_ref_tbl[] = {
    _object_int(T_PwrSupplyConfig, chipIdx),
    _object_int(T_PwrSupplyConfig, paBitMask),
    _object_end(T_PwrSupplyConfig)
};

layout_item_t T_PwrSupplyCfg_ref_tbl[] = {
    _object_int(T_PwrSupplyCfg, pwrSupplyNodeNum),
    _object_int(T_PwrSupplyCfg, supportAbility),
    _object_array_struct(T_PwrSupplyCfg, pwrSupplyConfig, T_PwrSupplyConfig_ref_tbl, T_PwrSupplyConfig, PWR_MAX_PWR_OUTLET_NUM),
    _object_end(T_PwrSupplyCfg)
};

layout_item_t T_FreqIdCaCap_ref_tbl[] = {
    _object_int(T_FreqIdCaCap, byFreqId),
    _object_int(T_FreqIdCaCap, byDir),
    _object_int(T_FreqIdCaCap, byCarrNum),
    _object_int(T_FreqIdCaCap, byCaStartNo),
    _object_int(T_FreqIdCaCap, byCaEndNo),
    _object_array_int(T_FreqIdCaCap, abyChnMap, UCHAR, CHN_MAP_MAX),
    _object_int(T_FreqIdCaCap, dwFreqStart),
    _object_int(T_FreqIdCaCap, dwFreqEnd),
    _object_int(T_FreqIdCaCap, dwBandNo),
    _object_array_int(T_FreqIdCaCap, abyRsv, UCHAR, 20),
    _object_end(T_FreqIdCaCap)
};

layout_item_t T_FreqIdRadioCaCap_ref_tbl[] = {
    _object_int(T_FreqIdRadioCaCap, dwRadioMode),
    _object_int(T_FreqIdRadioCaCap, dwNum),
    _object_array_int(T_FreqIdRadioCaCap, abyRsv, UCHAR, 4),
    _object_array_struct(T_FreqIdRadioCaCap, atFreqIdCaCap, T_FreqIdCaCap_ref_tbl, T_FreqIdCaCap, CARR_MAX_INDEX),
    _object_end(T_FreqIdRadioCaCap)
};

layout_item_t T_RruFreqIdCaCap_ref_tbl[] = {
    _object_int(T_RruFreqIdCaCap, dwRadioNum),
    _object_array_int(T_RruFreqIdCaCap, abyRsv, UCHAR, 4),
    _object_array_struct(T_RruFreqIdCaCap, atRadioFreqBandCap, T_FreqIdRadioCaCap_ref_tbl, T_FreqIdRadioCaCap, RADIO_MODE_MAX_INDEX),
    _object_end(T_RruFreqIdCaCap)
};

layout_item_t T_PwrInputCurrCfg_ref_tbl[] = {
    _object_int(T_PwrInputCurrCfg, index),
    _object_int(T_PwrInputCurrCfg, voltHighAlmThre),
    _object_int(T_PwrInputCurrCfg, highAlmThre),
    _object_int(T_PwrInputCurrCfg, highRecThre),
    _object_int(T_PwrInputCurrCfg, deratingStep),
    _object_int(T_PwrInputCurrCfg, deratingTotal),   
    _object_int(T_PwrInputCurrCfg, paBitMask), 
    _object_end(T_PwrInputCurrCfg)
};

layout_item_t T_PwrInputCurrAlarmCfg_ref_tbl[] = {
    _object_int(T_PwrInputCurrAlarmCfg, num),
    _object_int(T_PwrInputCurrAlarmCfg, ability),
    _object_int(T_PwrInputCurrAlarmCfg, testType),
    _object_array_struct(T_PwrInputCurrAlarmCfg, pwrInputCurr, T_PwrInputCurrCfg_ref_tbl, T_PwrInputCurrCfg, PWR_INPUTCURRENT_POINT_NUM),
    _object_end(T_PwrInputCurrAlarmCfg)
};

layout_item_t T_CombinationAntInfo_ref_tbl[] = {
    _object_int(T_CombinationAntInfo, power),
    _object_int(T_CombinationAntInfo, antNum),
    _object_array_int(T_CombinationAntInfo, antInfo, UINT32, RRU_COMBINATION_ANTNUM_MAX),
    _object_end(T_CombinationAntInfo)
};
layout_item_t T_MultiAntCfgInfo_ref_tbl[] = {
    _object_int(T_MultiAntCfgInfo, num),
    _object_array_struct(T_MultiAntCfgInfo, combinationAntCfg, T_CombinationAntInfo_ref_tbl, T_CombinationAntInfo, CONSTRAINT_TYPE_NUM),
    _object_end(T_MultiAntCfgInfo)
};

layout_item_t T_SignalAntCfgInfo_ref_tbl[] = {
    _object_int(T_SignalAntCfgInfo, power),
    _object_int(T_SignalAntCfgInfo, antIndex),
    _object_int(T_SignalAntCfgInfo, bandNum),
    _object_array_int(T_SignalAntCfgInfo, bandInfo, UINT32, RRU_SIGNALANT_BANDNUM_MAX),
    _object_end(T_SignalAntCfgInfo)
};
layout_item_t T_SignalAntBandCfgInfo_ref_tbl[] = {
    _object_int(T_SignalAntBandCfgInfo, num),
    _object_array_struct(T_SignalAntBandCfgInfo, antCfg, T_SignalAntCfgInfo_ref_tbl, T_SignalAntCfgInfo, CONSTRAINT_TYPE_NUM),
    _object_end(T_SignalAntBandCfgInfo)
};
layout_item_t T_RruPowerCfgInfo_ref_tbl[] = {
    _object_int(T_RruPowerCfgInfo, rruPowerSupport),
    _object_int(T_RruPowerCfgInfo, antCombinaSupport),
    _object_int(T_RruPowerCfgInfo, bandCombinaSupport),
    _object_int(T_RruPowerCfgInfo, chanSupport),
    _object_int(T_RruPowerCfgInfo, rruPower),
    _object_obj(T_RruPowerCfgInfo, multiAntCfg, T_MultiAntCfgInfo_ref_tbl),
    _object_obj(T_RruPowerCfgInfo, signalAntBandCfg, T_SignalAntBandCfgInfo_ref_tbl),
    _object_array_int(T_RruPowerCfgInfo, chanPow, UINT32, BSP_MAX_CHAN_NUM),
    _object_end(T_RruPowerCfgInfo)
};

static UINT32 BspDataLayoutInit_ic4_2(VOID)
{
    UINT32 version = 10;

    /* 增加子数据块布局 */
    BspLayoutSetKeyValue("T_BspHalAdaptSocCrmClk_ref_tbl", (VOID*)T_BspHalAdaptSocCrmClk_ref_tbl);
    BspLayoutSetKeyValue("T_BspHalAdaptCbSwStaTbl_ref_tbl", (VOID*)T_BspHalAdaptCbSwStaTbl_ref_tbl);
    BspLayoutSetKeyValue("T_BspHalAdaptPllCrmPara", (VOID*)T_BspHalAdaptPllCrmPara_ref_tbl);
    BspLayoutSetKeyValue("T_BspHalAdaptOptCrmClk", (VOID*)T_BspHalAdaptOptCrmClk_ref_tbl);
    BspLayoutSetKeyValue("T_BspHalAdaptDifCrmClk", (VOID*)T_BspHalAdaptDifCrmClk_ref_tbl);
    BspLayoutSetKeyValue("T_BspHalAdaptCrmRstCommonPara", (VOID*)T_BspHalAdaptCrmRstCommonPara_ref_tbl);
    BspLayoutSetKeyValue("T_BspHalAdaptDifCrmClkSelect", (VOID*)T_BspHalAdaptDifCrmClkSelect_ref_tbl);

    /* 登记回调函数 */
    BspLayoutSetKeyValue("RruTestFunc1", (VOID*)RruTestFunc1);
    BspLayoutSetKeyValue("RruTestFunc2", (VOID*)RruTestFunc2);
    BspLayoutSetKeyValue("BspSetRxGain", (UINT32*)BspSetRxGain);

    /* 针对初始化功能增加数据布局 */
    BspBoardModleSetDataLayout(E_HARD_FEATURE_GET_BOMID, 0, 0, (VOID*)BomidFlashInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_PAPT_UPDATA, 0, 0, (VOID*)T_PaptUpdata_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_PAD, 0, 0, (VOID*)T_GpioPadInfoModify_ref_tbl,version);// T_DataCfgGroup数组对应单板类型取第0组数据布局
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_PAD, 1, 0, (VOID*)T_GpioPadInfoModify_ref_tbl,version);// T_DataCfgGroup数组对应单板类型取第1组数据布局
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_PAD, 2, 0, (VOID*)T_GpioPadInfoModify_ref_tbl,version);// T_DataCfgGroup数组对应单板类型取第2组数据布局
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_PAD, 3, 0, (VOID*)T_GpioPadInfoModify_ref_tbl,version);// T_DataCfgGroup数组对应单板类型取第3组数据布局
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA, 0, 0, (VOID*)T_BspCbSwPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK, 0, 0, (VOID*)T_BspHalAdaptCrmPara_BeforeClk_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_ATT_INIT, 0, 0, (VOID*)T_ATTVGA_CFGPARA_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_PA_VOLT_INIT, 0, 0, (VOID*)T_DefPaPara_ref_tbl,version);// UINT32类型暂不支持
    BspBoardModleSetDataLayout(E_FUNCTION_CFR_DYN_PARA_INIT, 0, 0, (VOID*)T_CfrDynPara_TDD_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_FILE_MOVE, 0, 0, (VOID*)T_FileMoveList_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_RESALLOC, 0, 0, (VOID*)T_DifResourceAllocChanPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_OPENLOOP_PARA_INIT, 0, 0, (VOID*)T_RxOpenLoopPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA, 0, 0, (VOID*)T_BspCbSwStaTbl_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA, 0, 0, (VOID*)T_BspCbSwRfTbl_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA, 0, 0, (VOID*)T_BspCbSwRfTbl_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK, 0, 0, (VOID*)T_BspHalAdaptCrmPara_AfterClk_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_RFPLL_INIT, 0, 0, (VOID*)T_RfPllInit_Para_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_TRANSCEIVER_INIT, 0, 0, (VOID*)T_IC_TRX_PIN_MAP_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_PWRSAVE, 0, 0, (VOID*)T_DpdicPwrSaveSel_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_PWRSAVE_PRE, 0, 0, (VOID*)T_DpdicPwrSaveSel_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_ACATT_INIT, 0, 0, (VOID*)T_TRXACATT_CFGPARA_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT, 0, 0, (VOID*)T_TrxJ204SerdesTxEqPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DAC_CALLBACK, 0, 0, (VOID*)T_DACVOLT_CFGPARA_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_SOC_RESET, 0, 0, (VOID*)T_DpdicSocReset_ref_tbl,version);
    BspBoardModleSetDataLayout(E_CHIP_POWERON_DPDIC_LOAD_ORDER_CHIPNO,0, 0, (VOID*)T_DpdicSocLoadOrder_ref_tbl,version);

    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_OPT_TX_SERDES,0, 0, (VOID*)T_OPT_SERDES_PCS_PARAM_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,0, 0, (VOID*)T_BspHalAdaptOptCpriInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_OPT_HAL_INIT,0, 0, (VOID*)T_BspHalAdaptOptInitCfgInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_CLK,0, 0, (VOID*)T_BspHalAdaptDifClkPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_SAMRATE,0, 0, (VOID*)T_BspHalAdaptDifSamRatePara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_CFG,0, 0, (VOID*)T_BspHalAdaptDifCfgPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_RESALLOC,0, 0, (VOID*)T_BspHalAdaptDifResAllocChanPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_TX_ROUTE,0, 0, (VOID*)T_BspHalAdaptDifTxRouteMap_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_TX_PARA,0, 0, (VOID*)T_BspHalAdaptDifTxRoutePara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_TX_204,0, 0, (VOID*)T_BspHalAdaptDifTx204RouteMap_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_RX_ROUTE,0, 0, (VOID*)T_BspHalAdaptDifRxRouteMap_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_FB_ROUTE,0, 0, (VOID*)T_BspHalAdaptDifFbRouteMap_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_DIF_FR,0, 0, (VOID*)T_BspHalAdaptFrInitCfg_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_204_LINK,0, 0, (VOID*)T_J204LinkPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_204_SYSREF,0, 0, (VOID*)T_BspHalAdaptSysrefCfg_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_204_TXEQ,0, 0, (VOID*)T_J204SerdesTxEqPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,0, 0, (VOID*)T_J204TrxCallBackCfg_ref_tbl,version);
    
    BspBoardModleSetDataLayout(E_FUNCTION_PRE_ALLOC,0, 0, (VOID*)T_BspHalAdaptPreAllocCarrInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_RRU_DEFABILITY,0, 0, (VOID*)T_RruDefAbility_ref_tbl,version); // 一组数据由结构体与int型数据组成，暂不支持
    BspBoardModleSetDataLayout(E_FUNCTION_RRU_CARR_ABILITY,0, 0, (VOID*)T_RruCarrAbility_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_CFR_COMM_PARA_INIT,0, 0, (VOID*)T_BspHalAdaptDifCommCfrPara_ref_tbl,version); 
    BspBoardModleSetDataLayout(E_FUNCTION_CFR_KICOMM_PARA_INIT,0, 0, (VOID*)T_BspHalAdaptCfrParaHardCpg_ref_tbl,version); 
    BspBoardModleSetDataLayout(E_FUNCTION_CFR_KNCOMM_PARA_INIT,0, 0, (VOID*)T_BspHalAdaptCfrKnWordPara_ref_tbl,version); 
    BspBoardModleSetDataLayout(E_FUNCTION_CFR_PAR_PARA_INIT,0, 0, (VOID*)T_BspHalAdaptCfrParCommPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_TRX_DIG_GAIN_INIT,0, 0, (VOID*)T_GainCommPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_DPD_PAR_PARA_INIT,0, 0, (VOID*)T_BspHalAdaptDpdParCommPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_POWCALC_INIT,0, 0, (VOID*)T_BspHalAdaptPowChk_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_POWCALC_THREAD_INIT,0, 0, (VOID*)T_PowUpdateTime_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_DL_POWCALC_PARA_INIT,0, 0, (VOID*)T_DlPowCalcPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_UL_POWCALC_PARA_INIT,0, 0, (VOID*)T_UlPowCalcPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_TX_DELT_DELAY,0, 0, (VOID*)T_BspHalAdaptLinkDeltDly_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_RX_DELT_DELAY,0, 0, (VOID*)T_BspHalAdaptLinkDeltDly_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_TX_FREQ_CFG,0, 0, (VOID*)T_FreqCfgData_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_RX_FREQ_CFG,0, 0, (VOID*)T_FreqCfgData_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_CHAN_GROUP_INIT,0, 0, (VOID*)T_ChanGroupInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_VGA_CTRL_PARA_INIT,0, 0, (VOID*)T_BspHalAdaptVgaCtrlComPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_VGA_CTRL_COMP_PARA_INIT,0, 0, (VOID*)T_BspHalAdaptVgaCompPara_ref_tbl,version); 
    BspBoardModleSetDataLayout(E_FUNCTION_PAPT_REPORT_RECOVER,0, 0, (VOID*)T_J204PairEndsInfo_ref_tbl,version); 
    BspBoardModleSetDataLayout(E_FUNCTION_PA_PWRVOLT_INIT,0, 0, (VOID*)T_PaPwrVoltCtrlPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,0, 0, (VOID*)T_PowThreInitPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_TEMP_THRESHOLD_PARA_INIT,0, 0, (VOID*)T_TempThreInitPara_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_NTF_PARA_INIT,0, 0, (VOID*)T_NtfCfgData_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_DPD_SET_EQ_INIT,0, 0, (VOID*)T_DpdEqData_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_CHANFREQ_BAND_INIT,0, 0, (VOID*)T_ChBndSupInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_FUNCTION_RRU_CARR_CAP,0, 0, (VOID*)T_RruFreqIdCaCap_ref_tbl,version);

    BspBoardModleSetDataLayout(E_HARD_FEATURE_BOARD_ID, 0, 0, (VOID*)TVerGroup_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_DEV_ID, 0, 0, (VOID*)T_BoardIdItem_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_FUNC_ID, 0, 0, (VOID*)T_BoardIdItem_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_THRESHOLD_ID, 0, 0, (VOID*)T_BoardIdItem_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_GAIN_ID,0, 0, (VOID*)T_BoardIdItem_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_FLASH_INIT,0, 0, (VOID*)T_FlashInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_INIT_VER_PROTECT,0, 0, (VOID*)T_VerProtectInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_INIT_PROTECT_FILELIST,0, 0, (VOID*)T_AllRunVerList_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_LINK_INFO_INIT,0, 0, (VOID*)T_RU_LINK_MAP_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_RRU_PROPERTY,0, 0, (VOID*)T_RruPropertyInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_REG_TBL,0, 0, (VOID*)T_Reg_Tbl_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_DRV_TBL,0, 0, (VOID*)_T_Reg_Drv_Tbl_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_DRV_TBL,1, 0, (VOID*)_T_Dev_Reg_Tbl_Modify_ref_tbl,version);//TODO
    BspBoardModleSetDataLayout(E_HARD_FEATURE_CPUID_INIT,0, 0, (VOID*)T_CpuIdInfo_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_CALI_FILE,0, 0, (VOID*)T_RfTblFileMenu_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,0, 0, (VOID*)T_RU_LINK_MAP_TDDIO_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_TDDIO_CTRL_INIT,0, 0, (VOID*)T_TDDIO_CONCTRL_PARA_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_TDDIO_CTRL_INIT,1, 0, (VOID*)T_TDD_IO_BASE_PARA_INFO_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_TDDIO_CTRL_INIT,2, 0, (VOID*)T_TDDIO_EXCEPT_CTRL_ref_tbl,version);// TODO 二维数组
    BspBoardModleSetDataLayout(E_HARD_FEATURE_PWR_MAP_CHAN_INIT,0, 0, (VOID*)T_PWR_MAP_CHAN_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_OPT_PAPT_INIT,0, 0, (VOID*)Papt_Opt_Cfg_Info_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_PAPT_UPDATA,0, 0, (VOID*)T_PaptUpdata_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_CRM_PAPT_INIT,0, 0, (VOID*)T_PaptCrmCfg_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_POWER_ADJUST_DELTA,0, 0, (VOID*)T_PowerAdjustDelta_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_PWR_CONFIG_INIT,0, 0, (VOID*)T_PwrSupplyCfg_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_PWRCURRENT_CFG,0, 0, (VOID*)T_PwrInputCurrAlarmCfg_ref_tbl,version);
    BspBoardModleSetDataLayout(E_HARD_FEATURE_RRUPOWERCONSTRAINT_CFG,0, 0, (VOID*)T_RruPowerCfgInfo_ref_tbl,version);
    return BSP_OK;
}

/**************************************************************************
                            自举接口
**************************************************************************/
static __attribute((constructor)) void DataLayoutInit_IC4_2()
{
    BspAddLayOutInitFunc(BspDataLayoutInit_ic4_2);

    /* 数据空间初始化 */
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_GET_BOMID,0,BomidFlashInfo)
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_PAPT_UPDATA,0,PaptUpdata)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_PAD,0,T_GpioPadInfoModify)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_PAD,1,T_GpioPadInfoModify_1)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_PAD,2,T_GpioPadInfoModify_2)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_PAD,3,T_GpioPadInfoModify_3)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA,0,T_BspCbSwPara)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK,0,CrmParaBeforeClk)

    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_ATT_INIT,0,ATTVGA_CFGPARA)
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_PA_VOLT_INIT,0,T_DefPaPara)
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_CFR_DYN_PARA_INIT,0,T_CfrDynPara_TDD)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_FILE_MOVE,0,T_FileMoveList)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_RESALLOC,0,T_DifResourceAllocChanPara)
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_OPENLOOP_PARA_INIT,0,T_RxOpenLoopPara)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA,0,T_BspCbSwStaTbl)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA,0,T_BspCbSwRfTbl)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA_FPGA,0,T_BspCbSwRfTbl_1)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK,0,T_BspHalAdaptCrmPara_AfterClk)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_RFPLL_INIT,0,T_RfPllInit_Para)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_TRANSCEIVER_INIT,0,T_IC_TRX_PIN_MAP)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_PWRSAVE,0,T_DpdicPwrSaveSel)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_PWRSAVE_PRE,0,T_DpdicPwrSaveSel_pre)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_ACATT_INIT,0,T_TRXACATT_CFGPARA)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT,0,T_TrxJ204SerdesTxEqPara)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DAC_CALLBACK,0,T_DACVOLT_CFGPARA)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_SOC_RESET,0,T_DpdicSocReset)
    BOARD_MODLE_GROUP_INIT(E_CHIP_POWERON_DPDIC_LOAD_ORDER_CHIPNO,0,T_DpdicSocLoadOrder)

    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_OPT_TX_SERDES,0,T_OPT_SERDES_PCS_PARAM)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_OPT_CPRI_PARA,0,T_BspHalAdaptOptCpriInfo)
    //BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_OPT_MEAS,0,T_OPT_SERDES_PCS_PARAM)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_OPT_HAL_INIT,0,T_BspHalAdaptOptInitCfgInfo)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_CLK,0,T_BspHalAdaptDifClkPara)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_SAMRATE,0,T_BspHalAdaptDifSamRatePara)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_CFG,0,T_BspHalAdaptDifCfgPara)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_RESALLOC,0,T_BspHalAdaptDifResAllocChanPara)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_TX_ROUTE,0,T_BspHalAdaptDifTxRouteMap)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_TX_PARA,0,T_BspHalAdaptDifTxRoutePara)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_TX_204,0,T_BspHalAdaptDifTx204RouteMap)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_RX_ROUTE,0,T_BspHalAdaptDifRxRouteMap)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_FB_ROUTE,0,T_BspHalAdaptDifFbRouteMap)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_DIF_FR,0,T_BspHalAdaptFrInitCfg)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_204_LINK,0,T_J204LinkPara)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_204_SYSREF,0,T_BspHalAdaptSysrefCfg)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_204_TXEQ,0,T_J204SerdesTxEqPara)
    BOARD_MODLE_GROUP_INIT(E_TRX_LINK_DPDIC_204_TRX_FUNC_INIT,0,T_J204TrxCallBackCfg)

    BOARD_MODLE_GROUP_INIT(E_FUNCTION_PRE_ALLOC,0,T_BspHalAdaptPreAllocCarrInfo)
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_RRU_DEFABILITY,0,T_RruDefAbility);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_RRU_CARR_ABILITY,0,T_RruCarrAbility);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_CFR_COMM_PARA_INIT,0,T_BspHalAdaptDifCommCfrPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_CFR_KICOMM_PARA_INIT,0, T_BspHalAdaptCfrParaHardCpg);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_CFR_KNCOMM_PARA_INIT,0, T_BspHalAdaptCfrKnWordPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_CFR_PAR_PARA_INIT,0, T_BspHalAdaptCfrParCommPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_TRX_DIG_GAIN_INIT,0, T_GainCommPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_DPD_PAR_PARA_INIT,0, T_BspHalAdaptDpdParCommPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_POWCALC_INIT,0, T_BspHalAdaptPowChk);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_POWCALC_THREAD_INIT,0, T_PowUpdateTime);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_DL_POWCALC_PARA_INIT,0, T_DlPowCalcPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_UL_POWCALC_PARA_INIT,0, T_UlPowCalcPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_TX_DELT_DELAY,0, T_BspHalAdaptLinkDeltDly); 
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_TX_FREQ_CFG,0, T_FreqCfgData);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_CHAN_GROUP_INIT,0, T_ChanGroupInfo);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_VGA_CTRL_PARA_INIT,0, T_BspHalAdaptVgaCtrlComPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_VGA_CTRL_COMP_PARA_INIT,0, T_BspHalAdaptVgaCompPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_PAPT_REPORT_RECOVER,0, T_J204PairEndsInfo);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_PA_PWRVOLT_INIT,0, T_PaPwrVoltCtrlPara);
 
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_POWCALC_THRESHOLD_PARA_INIT,0, T_PowThreInitPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_TEMP_THRESHOLD_PARA_INIT,0, T_ThresholdPara);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_NTF_PARA_INIT,0, T_NtfCfgData);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_DPD_SET_EQ_INIT,0, T_DpdEqData);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_CHANFREQ_BAND_INIT, 0, T_ChBndSupInfo);
    BOARD_MODLE_GROUP_INIT(E_FUNCTION_RRU_CARR_CAP,0, T_RruFreqIdCaCap);

    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_BOARD_ID,0, TVerGroup);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_DEV_ID,0, T_BoardIdItem);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_FLASH_INIT,0, T_FlashInfo);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_INIT_VER_PROTECT,0, T_VerProtectInfo);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_INIT_PROTECT_FILELIST,0, T_AllRunVerList);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_LINK_INFO_INIT,0, T_RU_LINK_MAP);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_RRU_PROPERTY,0, T_RruPropertyInfo);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_REG_TBL,0, T_Reg_Tbl);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_DRV_TBL,0, _T_Reg_Drv_Tbl);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_DRV_TBL,1, _T_Dev_Reg_Tbl_Modify);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_CPUID_INIT,0, T_CpuIdInfo);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_CALI_FILE,0, T_RfTblFileMenu);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,0, T_RU_LINK_MAP_TDDIO);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_TDDIO_CTRL_INIT,0, T_TDDIO_CONCTRL_PARA);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_TDDIO_CTRL_INIT,1, T_TDD_IO_BASE_PARA_INFO);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_TDDIO_CTRL_INIT,2, T_TDDIO_EXCEPT_CTRL);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_PWR_MAP_CHAN_INIT,0, T_PWR_MAP_CHAN);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_OPT_PAPT_INIT,0, Papt_Opt_Cfg_Info);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_PAPT_UPDATA,0, T_PaptUpdata);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_CRM_PAPT_INIT,0, T_PaptCrmCfg);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_POWER_ADJUST_DELTA,0, T_PowerAdjustDelta);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_PWR_CONFIG_INIT,0, T_PwrSupplyCfg);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_PWRCURRENT_CFG,0, T_PwrInputCurrAlarmCfg);
    BOARD_MODLE_GROUP_INIT(E_HARD_FEATURE_RRUPOWERCONSTRAINT_CFG,0, T_RruPowerCfgInfo);
 
}

VOID PrintBomidFlashInfo(VOID *pData, UINT32 dataNum) {
    T_BomidFlashInfo *pTmp = ((T_BomidFlashInfo*)pData);
    for(UINT32 i=0; i<dataNum;i++)
    {
        printf("flashBomidOffset=%d flashBomidSize=%d\n", (pTmp+i)->flashBomidOffset, (pTmp+i)->flashBomidSize);
        printf(" ------------------------------------------------------\n");
    }
}

VOID PrintPaptUpdata(VOID *pData, UINT32 dataNum) {
    T_PaptUpdata *pTmp = ((T_PaptUpdata*)pData);
    for(UINT32 i=0; i<dataNum;i++)
    {
        printf("chanSelect=%d, lnaFalg=%d, mtsAlarmNo=%d, paMask=%d, daMask=%d\n",\
                (pTmp+i)->chanSelect, (pTmp+i)->updataCfgPara.lnaFalg, (pTmp+i)->updataCfgPara.mtsAlarmNo, (pTmp+i)->updataCfgPara.paMask, (pTmp+i)->updataCfgPara.daMask);
        printf(" ------------------------------------------------------\n");
    }
}

VOID PrintBspCbSwPara(VOID *pData, UINT32 dataNum) {
    T_BspCbSwPara *pTmp = ((T_BspCbSwPara*)pData);
    for(UINT32 i=0; i<dataNum;i++)
    {
        printf("swIndex=%d, transBitSel=%d, ConnectMode=%d, frameNo=%d, swMode=%d, frBitEn=%d, fwdRevLen=%d\n", \
                (pTmp+i)->swIndex, (pTmp+i)->transBitSel, (pTmp+i)->ConnectMode, (pTmp+i)->frameNo, (pTmp+i)->swMode, (pTmp+i)->frBitEn, (pTmp+i)->fwdRevLen);
        printf(" ------------------------------------------------------\n");
    }
}

VOID PrintBspCrmBeforeClk(VOID *pData, UINT32 dataNum) {
    T_BspHalAdaptCrmPara_BeforeClk *pTmp = ((T_BspHalAdaptCrmPara_BeforeClk*)pData);
    for(UINT32 i=0; i<dataNum;i++)
    {
        printf("clk_spifc1_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spifc1_sys);
        printf("clk_spifc2_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spifc2_sys);
        printf("clk_spi0_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spi0_sys);
        printf("clk_spi1_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spi1_sys);
        printf("clk_spi2_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spi2_sys);
        printf("clk_spi3_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spi3_sys);
        printf("clk_spi4_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spi4_sys);
        printf("clk_spi5_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spi5_sys);
        printf("clk_spi6_sys=%d\n", (pTmp+i)->tSocClkPara->clk_spi6_sys);
        printf(" ------------------------------------------------------\n");
    }
}

VOID Print_ATTVGA_CFGPARA(VOID *pData, UINT32 dataNum) {
    T_ATTVGA_CFGPARA *pTmp = ((T_ATTVGA_CFGPARA*)pData);
    for(int i=0; i<dataNum; i++)
    {
        printf("    [chan%d] pathType=%d\n", i, (pTmp+i)->pathType);
        printf("    [chan%d] chipIdx=%d\n", i, (pTmp+i)->chipIdx);
        printf("    [chan%d] chipInnerIdx=%d\n", i, (pTmp+i)->chipInnerIdx);
        printf("    [chan%d] chipType=%d\n", i, (pTmp+i)->chipType);
        printf("    [chan%d] deFaultVal=%d\n", i, (pTmp+i)->deFaultVal);
        printf("    [chan%d] attMaxVal=%d\n", i, (pTmp+i)->attMaxVal);
        printf("    [chan%d] attMinVal=%d\n", i, (pTmp+i)->attMinVal);
        printf("    [chan%d] attStep=%d\n", i, (pTmp+i)->attStep);
        printf("    [chan%d] attMask=%d\n", i, (pTmp+i)->attMask);
        printf("    [chan%d] attValInversedCfg=%d\n", i, (pTmp+i)->attValInversedCfg);
        printf("    [chan%d] attValInversedGet=%d\n", i, (pTmp+i)->attValInversedGet);
        printf("    [chan%d] attFpgaLeast=%d\n", i, (pTmp+i)->attFpgaLeast);
        printf("    ------------------------------------------------------\n");
    }
}

VOID PrintDefPaPara(VOID *pData, UINT32 dataNum) {
    T_DefPaPara *pTmp = ((T_DefPaPara*)pData);
    for(int i=0; i<dataNum; i++)
    {
        printf("ulPaVolt:[0]=%d,[1]=%d,[2]=%d,[3]=%d \n", (pTmp+i)->ulPaVolt[0], (pTmp+i)->ulPaVolt[1], (pTmp+i)->ulPaVolt[2], (pTmp+i)->ulPaVolt[3]);
        printf("uDflTxInsertLoss:[0]=%d,[1]=%d,[2]=%d,[3]=%d \n", (pTmp+i)->uDflTxInsertLoss[0], (pTmp+i)->uDflTxInsertLoss[1], (pTmp+i)->uDflTxInsertLoss[2], (pTmp+i)->uDflTxInsertLoss[3]);
        printf("ulTempdelta:=%d\n", (pTmp+i)->ulTempdelta);
        printf("    ------------------------------------------------------\n");
    }
}

VOID PrintCfrDynParaTDD(VOID *pData, UINT32 dataNum) { 
    T_CfrDynPara_TDD *pTmp = ((T_CfrDynPara_TDD*)pData);
    for(int i=0; i<dataNum; i++)
    {
        printf("lowbound=%f \n", (pTmp+i)->lowbound);
        printf("upbound=%f \n", (pTmp+i)->upbound);
        printf("    ------------------------------------------------------\n");
    }
}

VOID PrintFileMoveList(VOID *pData, UINT32 dataNum) {
    T_FileMoveList *pTmp = ((T_FileMoveList*)pData);
    for(int i=0; i<dataNum; i++)
    {
        printf("pSourcePath:=%s\n", (pTmp+i)->pSourcePath);
        printf("uDflTxInsertLoss:=%s \n", (pTmp+i)->pDestPath);
        printf("moveWay:=%d\n", (pTmp+i)->moveWay);
        printf("    ------------------------------------------------------\n");
    }
}

VOID PrintDifResourceAllocChanPara(VOID *pData, UINT32 dataNum) {
    T_DifResourceAllocChanPara *pTmp = ((T_DifResourceAllocChanPara*)pData);
    for(int i=0; i<dataNum; i++)
    {
        printf("tTxFreqPara[0].uiFreqStart:=%d\n", (pTmp+i)->tTxFreqPara[0].uiFreqStart);
        printf("tRxFreqPara[0].uiFreqEnd:=%d\n", (pTmp+i)->tRxFreqPara[0].uiFreqEnd);
        printf("uiRxFreqNum:=%d \n", (pTmp+i)->uiRxFreqNum);
        printf("uiTxFreqNum:=%d\n", (pTmp+i)->uiTxFreqNum);
        printf("    ------------------------------------------------------\n");
    }
}

VOID PrintGpioPadInfoModify(VOID *pData, UINT32 dataNum) {
    T_GpioPadInfoModify *pTmp = ((T_GpioPadInfoModify*)pData);
    for(int i=0; i<dataNum; i++)
    {
        printf("    padName=%d\n", (pTmp+i)->padName);
        printf("    padStrName=%s\n", (pTmp+i)->padStrName);
        printf("    padType=%d\n", (pTmp+i)->padType);
        printf("    padStCfg=%d\n", (pTmp+i)->padStCfg);
        printf("    padSlCfg=%d\n", (pTmp+i)->padSlCfg);
        printf("    padPullCfg=%d\n", (pTmp+i)->padPullCfg);
        printf("    padDsCfg=%d\n", (pTmp+i)->padDsCfg);
        printf("    padFuncSel=%d\n", (pTmp+i)->padFuncSel);
        printf("    padCfgDone=%d\n", (pTmp+i)->padCfgDone);
        printf("    ------------------------------------------------------\n");
    }
}

VOID PrintBspCbSwStaTbl(VOID *pData, UINT32 dataNum) {
    T_BspCbSwStaTbl *pTmp = (T_BspCbSwStaTbl*)pData;
    printf("    swIndex=%d\n", pTmp->swIndex);
    printf("    tblLen=%d\n", pTmp->tblLen);
    T_BspHalAdaptCbSwStaTbl *tmpCbSw = pTmp->pCbSwStaTbl;
    
    for(int i=0;i<pTmp->tblLen;i++)
    {
        printf(" uiStatus=%d, uiChan=%d,uiPeriod=%d\n",(*(tmpCbSw+i)).uiStatus,(*(tmpCbSw+i)).uiChan,(*(tmpCbSw+i)).uiPeriod);
    }
    printf("    ------------------------------------------------------\n");
}

VOID PrintBspCbSwRfTbl(VOID *pData, UINT32 dataNum) {
    T_BspCbSwRfTbl *pTmp = (T_BspCbSwRfTbl*)pData;
    printf("    swIndex=%d\n", pTmp->swIndex);
    printf("    rfType=%d\n", pTmp->rfType);
    T_BspHalAdaptCbSwRfTbl tmpRf = pTmp->pCbSwRfTbl;
    printf("    uiChanNum=%d\n", tmpRf.uiChanNum);
    for(int i=0;i<tmpRf.uiChanNum;i++)
    {   
       printf(" uiOneLine[%d]=%d\\n",i,tmpRf.uiOneLine[i]);
    }
    printf("    ------------------------------------------------------\n");
}

VOID PrintBspHalAdaptCrmParaAfterClk(VOID *pData, UINT32 dataNum) {
    T_BspHalAdaptCrmPara_AfterClk *pTmp = (T_BspHalAdaptCrmPara_AfterClk*)pData;
    T_BspHalAdaptPllCrmPara *tmpPll = pTmp->tPllClkPara;
    T_BspHalAdaptOptCrmClk *tmpOpt = pTmp->tOptClkPara;
    T_BspHalAdaptDifCrmClk *tmpDif = pTmp->tDifClkPara;
    T_BspHalAdaptCrmRstCommonPara *tmpCom = pTmp->tCommRst;
    T_BspHalAdaptDifCrmClkSelect  *tmpSel = pTmp->tDifClkSelectPara;
    if(tmpPll == NULL || tmpOpt==NULL || tmpDif==NULL || tmpCom==NULL || tmpSel==NULL)
    {
        return;
    }
    printf(" ifType=%d\n",tmpPll->ifType);
    printf(" clk_opt_variable=%d\n",tmpOpt->clk_opt_variable);
    printf(" clk_ul_logic1_0=%d,clk_ul_logic1_1=%d,clk_dl_logic2=%d,clk_dl_logic3_0=%d,clk_dl_logic3_1=%d\n",tmpDif->clk_ul_logic1_0,\
             tmpDif->clk_ul_logic1_1,tmpDif->clk_dl_logic2,tmpDif->clk_dl_logic3_0,tmpDif->clk_dl_logic3_1);
    printf(" rst_fft_pranch=%d,rst_roe=%d,rst_opt=%d,rst_dif=%d\n",tmpCom->rst_fft_pranch,tmpCom->rst_roe,tmpCom->rst_opt,tmpCom->rst_dif);
    printf(" mux_clk_ulch_0=%d,mux_clk_ulch_1=%d,mux_clk_dlpost_0=%d,mux_clk_dlpost_1=%d\n",tmpSel->mux_clk_ulch_0,\
             tmpSel->mux_clk_ulch_1,tmpSel->mux_clk_dlpost_0,tmpSel->mux_clk_dlpost_1);
    printf("    ------------------------------------------------------\n");
}

VOID PrintRfPllInitPara(VOID *pData, UINT32 dataNum) {
    T_RfPllInit_Para *pTmp = (T_RfPllInit_Para*)pData;
    printf("dlDirect=%d,ulDirect=%d,prlDirect=%d\n", pTmp->dlDirect, pTmp->ulDirect, pTmp->prlDirect);
    printf("    ------------------------------------------------------\n");
}

VOID PrintIcTrxPinMap(VOID *pData, UINT32 dataNum) {
    T_IC_TRX_PIN_MAP *pTmp = (T_IC_TRX_PIN_MAP*)pData;
    for(int i=0;i<HALADAPT_TRANS_MAX_NUM;i++)
    {
        printf("icPinId[%d]=%d,", i,pTmp->icPinId[i]);
    }  
    printf("   \n ------------------------------------------------------\n");
}

VOID PrintDpdicPwrSaveSel(VOID *pData, UINT32 dataNum) {
    T_DpdicPwrSaveSel *pTmp = (T_DpdicPwrSaveSel*)pData;
    printf("difTxUnusedResSel=%d,difRxUnusedResSel=%d,a53CoreMask=%d\n", pTmp->difTxUnusedResSel, pTmp->difRxUnusedResSel, pTmp->a53CoreMask); 
    printf("    ------------------------------------------------------\n");
}

VOID PrintTrxacattCfgpara(VOID *pData, UINT32 dataNum) {
    T_TRXACATT_CFGPARA *pTmp = (T_TRXACATT_CFGPARA*)pData;
    printf("pathType=%d,chipIdx=%d,chan=%d,attValue=%d,mask=%d\n", pTmp->pathType,pTmp->chipIdx,pTmp->chan,pTmp->attValue,pTmp->mask); 
    printf("    ------------------------------------------------------\n");
}

VOID PrintTrxJ204SerdesTxEqPara(VOID *pData, UINT32 dataNum) {
    T_TrxJ204SerdesTxEqPara *pTmp = (T_TrxJ204SerdesTxEqPara*)pData;
    printf("chipId=%d,laneId=%d,eqPre=%d,eqPost=%d,eqMain=%d\n", pTmp->chipId,pTmp->laneId,pTmp->eqPre,pTmp->eqPost,pTmp->eqMain); 
    printf("    ------------------------------------------------------\n");
}

VOID PrintTVerGroup(VOID *pData, UINT32 dataNum){
    TVerGroup *pTmp = (TVerGroup*)pData;
    printf("cNickname=%s,nameIdx=%d,HardId[0]=%d\n", pTmp->cNickname,pTmp->nameIdx,pTmp->HardId[0]); 
    printf("    ------------------------------------------------------\n");
}

VOID PrintBoardIdItem(VOID *pData, UINT32 dataNum){
    T_BoardIdItem *pTmp = (T_BoardIdItem*)pData;
    printf("ulIdVal=%d,pucName=%s,pucAlias=%s,ulIdNum=%d,ulIdAddr=%d\n", pTmp->ulIdVal,pTmp->pucName,pTmp->pucAlias,pTmp->ulIdNum,pTmp->ulIdAddr); 
    printf("    ------------------------------------------------------\n");
}

VOID PrintRuLinkMap(VOID *pData, UINT32 dataNum){
    T_RU_LINK_MAP *pTmp = (T_RU_LINK_MAP*)pData;
    for(int i=0;i<LINK_INFO_TYPE_NUM;i++)
    {
        printf("linkInfo[%d]=[%d],",i,pTmp->linkInfo[i]);
    }
    printf("\n ------------------------------------------------------\n");
}

VOID PrintRruPropertyInfo(VOID *pData, UINT32 dataNum){
    T_RruPropertyInfo *pTmp = (T_RruPropertyInfo*)pData;
    printf("ascbuf=%s,bufSize=%d\n",pTmp->ascbuf,pTmp->bufSize);   
    printf("\n ------------------------------------------------------\n");
}

VOID PrintRegTbl(VOID *pData, UINT32 dataNum){
    T_Reg_Tbl *pTmp = (T_Reg_Tbl*)pData;
    printf("regFuncDomainId=%d,regProperty=%d,regAddr=%lu,regMask=%d,isMask=%d,regVal=%d,initFlag=%d,chipInfo=%d\n", \
           pTmp->regFuncDomainId,pTmp->regProperty,pTmp->regAddr,pTmp->regMask,pTmp->isMask,pTmp->regVal,pTmp->initFlag,pTmp->chipInfo);
    printf("\n ------------------------------------------------------\n");
}

VOID PrintRegDrvTbl(VOID *pData, UINT32 dataNum){
    _T_Reg_Drv_Tbl *pTmp = (_T_Reg_Drv_Tbl*)pData;
    printf("chipIdx=%d,regType=%d,regAddr=%d,bitNum=%d,defVal=%d\n", \
           pTmp->chipIdx,pTmp->regType,pTmp->regAddr,pTmp->bitNum,pTmp->defVal);
    printf("\n ------------------------------------------------------\n");
}

VOID PrintRfTblFileMenu(VOID *pData, UINT32 dataNum){
    T_RfTblFileMenu *pTmp = (T_RfTblFileMenu*)pData;
    printf("ulFileType=%d,ulFileProp=%d,ulLoadState=%d,ulIsErrAlm=%d,ulSubFileNum=%d,pAtaFile=%s,pFsFile=%s,ulChanPro=%d\n", \
           pTmp->ulFileType,pTmp->ulFileProp,pTmp->ulLoadState,pTmp->ulIsErrAlm,pTmp->ulSubFileNum,pTmp->pAtaFile,pTmp->pFsFile, \
           pTmp->ulChanPro);
    printf(" ------------------------------------------------------\n");
}

VOID PrintCpuIdInfo(VOID *pData, UINT32 dataNum){
    T_CpuIdInfo *pTmp = (T_CpuIdInfo*)pData;
    printf("isPeerPu=%d,puId=%d,cpuId=%d,coreId=%d\n", pTmp->isPeerPu,pTmp->puId,pTmp->cpuId,pTmp->coreId);
    printf("------------------------------------------------------\n");
}

VOID PrintTDDIoBaseParaInfo(VOID *pData, UINT32 dataNum){
    T_TDD_IO_BASE_PARA_INFO *pTmp = (T_TDD_IO_BASE_PARA_INFO*)pData; //part 1
    printf("txEnAdvOn=%f,paAdvOn=%f,txEnDlyOff=%f,paDlyOff=%f\n", pTmp->txEnAdvOn,pTmp->paAdvOn,pTmp->txEnDlyOff,pTmp->paDlyOff);
    printf("------------------------------------------------------\n");
}

VOID PrintRuLinkMapTddTo(VOID *pData, UINT32 dataNum){
    T_RU_LINK_MAP_TDDIO *pTmp = (T_RU_LINK_MAP_TDDIO*)pData;
    for(int i=0;i<LINK_INFO_TYPE_NUM_TDDIO;i++)
    {
        printf("linkInfo[%d]=[%d],",i,pTmp->linkInfo[i]);
    }
    printf("\n------------------------------------------------------\n");
}

VOID PrintAllRunVerList(VOID *pData, UINT32 dataNum){
    T_AllRunVerList *pTmp = (T_AllRunVerList*)pData;
    for(int i=0;i<MASTER_VER_NUM_MAX/2;i++)
    {
        printf("[%d]ulSoftType=%d,acFileName=%s,acVerName=%s\n",i,pTmp->tMasterRunVerList[i].ulSoftType,pTmp->tMasterRunVerList[i].acFileName,pTmp->tMasterRunVerList[i].acVerName);
    }
    printf("\n------------------------------------------------------\n");
}

static T_PrintFuncInfo printFuncInfos[] = {
        {E_HARD_FEATURE_GET_BOMID, PrintBomidFlashInfo},
        {E_HARD_FEATURE_PAPT_UPDATA, PrintPaptUpdata},
        {E_CHIP_POWERON_DPDIC_CBSW_COMMON_PARA, PrintBspCbSwPara},
        {E_CHIP_POWERON_DPDIC_CRM_BEFORE_CLK, PrintBspCrmBeforeClk},
        {E_CHIP_POWERON_ATT_INIT, Print_ATTVGA_CFGPARA},
        {E_HARD_FEATURE_PA_VOLT_INIT, PrintDefPaPara},
        {E_FUNCTION_CFR_DYN_PARA_INIT, PrintCfrDynParaTDD},
        {E_CHIP_POWERON_FILE_MOVE, PrintFileMoveList},
        {E_TRX_LINK_DPDIC_DIF_RESALLOC, PrintDifResourceAllocChanPara},
        {E_CHIP_POWERON_DPDIC_PAD, PrintGpioPadInfoModify},
        {E_CHIP_POWERON_DPDIC_CBSW_STATBL_PARA, PrintBspCbSwStaTbl},
        {E_CHIP_POWERON_DPDIC_CBSW_RFTBL_PARA, PrintBspCbSwRfTbl},
        {E_CHIP_POWERON_DPDIC_CRM_AFTER_CLK, PrintBspHalAdaptCrmParaAfterClk},
        {E_CHIP_POWERON_RFPLL_INIT, PrintRfPllInitPara},
        {E_CHIP_POWERON_TRANSCEIVER_INIT, PrintIcTrxPinMap},
        {E_CHIP_POWERON_DPDIC_PWRSAVE, PrintDpdicPwrSaveSel},
        {E_CHIP_POWERON_ACATT_INIT, PrintTrxacattCfgpara},
        {E_CHIP_POWERON_TRANSCEIVER_TXEQ_INIT, PrintTrxJ204SerdesTxEqPara},
        {E_HARD_FEATURE_BOARD_ID, PrintTVerGroup},
        {E_HARD_FEATURE_DEV_ID, PrintBoardIdItem},
        {E_HARD_FEATURE_FUNC_ID, PrintBoardIdItem},
        {E_HARD_FEATURE_THRESHOLD_ID, PrintBoardIdItem},
        {E_HARD_FEATURE_GAIN_ID, PrintBoardIdItem},
        {E_HARD_FEATURE_LINK_INFO_INIT, PrintRuLinkMap},
        {E_HARD_FEATURE_RRU_PROPERTY, PrintRruPropertyInfo},
        {E_HARD_FEATURE_REG_TBL, PrintRegTbl},
        {E_HARD_FEATURE_DRV_TBL, PrintRegDrvTbl},
        {E_HARD_FEATURE_CALI_FILE, PrintRfTblFileMenu},
        {E_HARD_FEATURE_CPUID_INIT, PrintCpuIdInfo},
        {E_HARD_FEATURE_TDDIO_CTRL_INIT, PrintTDDIoBaseParaInfo},
        {E_HARD_FEATURE_TDDIO_LINK_INFO_INIT,PrintRuLinkMapTddTo},
        {E_HARD_FEATURE_INIT_PROTECT_FILELIST,PrintAllRunVerList},
};

/* Started by AICoder, pid:516192a8c93333f1470a099560ee4041ac890740 */
static UINT32 BspPrintParseDataByActType(UINT32 actType, UINT32 idx, UINT32 part)
{
    void *pData = NULL;
    unsigned int dataNum = 0;

    for (int i = 0; i < sizeof(printFuncInfos)/sizeof(T_PrintFuncInfo); i++) {
        if(printFuncInfos[i].actType != actType)
        {
            continue;
        }

        BspBoardModleGetData(actType, idx, part, &pData, &dataNum);
        printf("%s>> actType = [%d], idx = %d, part = %d, dataNum=%d\n",__FUNCTION__, actType, idx, part, dataNum);
        if( dataNum > 0 && pData != NULL)
        {
            printFuncInfos[i].printFunc(pData, dataNum);
        }
    }

    return 0;
}

UINT32 BspPrintParseData(void){
    void *pData = NULL;
    unsigned int dataNum = 0;

    for (int i = 0; i < sizeof(printFuncInfos)/sizeof(T_PrintFuncInfo); i++) {
        BspBoardModleGetData(printFuncInfos[i].actType, 0, 0, &pData, &dataNum);
        printf("%s>> actType = [%d], idx = 0, part = 0, dataNum=%d\n",__FUNCTION__, printFuncInfos[i].actType, dataNum);
        if( dataNum > 0 && printFuncInfos[i].printFunc!=NULL)
        {
            printFuncInfos[i].printFunc(pData, dataNum);
        }
    }

    return 0;
}

/* Ended by AICoder, pid:516192a8c93333f1470a099560ee4041ac890740 */

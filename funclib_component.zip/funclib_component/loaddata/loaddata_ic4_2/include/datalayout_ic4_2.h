
#ifndef _DATA_LAYOUT_IC4_2_H_
#define _DATA_LAYOUT_IC4_2_H_

#ifdef __cplusplus 
extern "C" { 
#endif

#include "bsppub.h"

typedef struct T_PrintFuncInfo {
    UINT32 actType;
    VOID (*printFunc)(VOID *pData, UINT32 dataNum);
} T_PrintFuncInfo;

UINT32 BspPrintParseData(void);

#ifdef __cplusplus
}
#endif

#endif /* _DATA_LAYOUT_IC4_2_H_ */



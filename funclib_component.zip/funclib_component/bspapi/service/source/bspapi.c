#include "bsppub.h"
#include "dpdapi.h"
#include "ru_univdef.h"
#include "linkcfgapi.h"
#include "bspvswr.h"
#include "LzmaDec.h"
#include "pub_svmdef.h"
#include "gnssapi.h"
#include "freqcfg_ic4_2.h"
#include "antcalapi.h"
#include "lzmaapi.h"
#include "rruabilityapi.h"
#include "funccommon_chncfg.h"
#include "optctrlapi.h"
#include "powerctrlapi.h"
#include "chnmapapi.h"
#include "funccommonapi.h"
#include "freqcfgapi.h"
#include "bspcommon.h"
#include "vxadapt_adapt.h"

#include "bsp_func_api.h"
#include "bsp_framework_api.h"

#include "bspservice_adapt.h"

UINT32 BspGetRxCenterFreqCfg(UINT32 rfchn)
{
    return BspCallService(BSP_CMD_GET_RX_CENTER_FREQ_CFG, rfchn);
}

UINT32 BspSetEcpriUdpPort(UINT32 ecpriPort, UINT32 roePort)
{
    return BspCallService(BSP_CMD_SET_ECPRI_UDP_PORT, ecpriPort, roePort);
}

UINT32 BspRruLinkPwrOffChkByVerAct(UINT32 *pIsPwrOff)
{
    return BspCallService(BSP_CMD_RRU_LINK_PWR_OFF_CHK_BY_VER_ACT, pIsPwrOff);
}

UINT32 BspChkCevaVersionStatus(VOID)
{
    return BspCallService(BSP_CMD_CHK_CEVA_VERSION_STATUS);
}

UINT32 BspGetFpgaAntiIntfMode(VOID)
{
    return BspCallService(BSP_CMD_GET_FPGA_ANTI_INTF_MODE);
}

UINT32 BspUpdateCarrCfgFlag(UINT32 bspChan, UINT32 dir, T_RfCfgPara *rfCfg)
{
    return BspCallService(BSP_CMD_UPDATE_CARR_CFG_FLAG, bspChan, dir, rfCfg);
}

UINT32 BspGetCarrierNum(VOID)
{
    return BspCallService(BSP_CMD_GET_CARRIER_NUM);
}

UINT32 BspCheckFpgaStatus(UINT32 *status, UINT8 *strInfo, UINT32 strLen)
{
    return BspCallService(BSP_CMD_CHECK_FPGA_STATUS, status, strInfo, strLen);
}

UINT32 BspSetRruCfgPara_5G(UINT32 rfChn, T_RruVswrInfo *pRruVswrInfo)
{
    return BspCallService(BSP_CMD_SET_RRU_CFG_PARA_5G, rfChn, pRruVswrInfo);
}

UINT32 BspRruLinkPwrOffRecCfg(VOID)
{
    return BspCallService(BSP_CMD_RRU_LINK_PWR_OFF_REC_CFG);
}

UINT32 BspGetProcessStrategy(UINT32 socMap, UINT32 socNum, UINT32 *delaTime, UINT32 *pOutSocStrategy)
{
    return BspCallService(BSP_CMD_GET_PROCESS_STRATEGY, socMap, socNum, delaTime, pOutSocStrategy);
}

VOID BspSetTsgMode(UINT8 enable)
{
    BspCallService(BSP_CMD_SET_TSG_MODE, enable);
    return;
}

UINT32 BspGetRruSupportCarrNum(UINT32 uChn, UINT32 uBand, UINT32 uMode)
{
    return BspCallService(BSP_CMD_GET_RRU_SUPPORT_CARR_NUM, uChn, uBand, uMode);
}

UINT32 BspSetEcpriUdpPortDefault()
{
    return BspCallService(BSP_CMD_SET_ECPRI_UDP_PORT_DEFAULT);
}

UINT32 BspSetCellAntInfo(T_FddCellAntInfo *pCellAntInfo)
{
    return BspCallService(BSP_CMD_SET_CELL_ANT_INFO, pCellAntInfo);
}

E_BoardOptProType BspGetOptProType(UINT32 optIndex)
{
    return BspCallService(BSP_CMD_GET_OPT_PRO_TYPE, optIndex);
}

UINT32 BspGetVirtualCarrNoOffsetPara(UINT32 *offset, UINT32 *mod)
{
    return BspCallService(BSP_CMD_GET_VIRTUAL_CARR_NO_OFFSET_PARA, offset, mod);
}

UINT32 BspProcessStategy(UINT32 rpuId)
{
    return BspCallService(BSP_CMD_PROCESS_STATEGY, rpuId);
}

UINT32 BspSetResetTypeCause(UINT32 resetType, UINT32 cause)
{
    return BspCallService(BSP_CMD_SET_RESET_TYPE_CAUSE, resetType, cause);
}

UINT32 BspSetCarrActiveStatus(UINT32 ulChan, UINT32 dir, UINT32 ulRadioMode, UINT32 ulCarrNo, UINT32 ulActSta)
{
    return BspCallService(BSP_CMD_SET_CARR_ACTIVE_STATUS, ulChan, dir, ulRadioMode, ulCarrNo, ulActSta);
}

UINT32 BspGetPowonStrategy()
{
    return BspCallService(BSP_CMD_GET_POWON_STRATEGY);
}

UINT32 BspSetCarrAntPortNum(T_RruCfgCarrAntPortInfo *stRruCarrPortCfg)
{
    return BspCallService(BSP_CMD_SET_CARR_ANT_PORT_NUM, stRruCarrPortCfg);
}

UINT32 BspSetNtfRssiSwitch(UINT32 sw)
{
    return BspCallService(BSP_CMD_SET_NTF_RSSI_SWITCH, sw);
}

UINT32 BspSetNtfAvoidFlag(UINT32 ntfAvoidFlag)
{
    return BspCallService(BSP_CMD_SET_NTF_AVOID_FLAG, ntfAvoidFlag);
}

UINT32 BspGetSharePowerRisingLevel(UINT32 *quotaLimit)
{
    return BspCallService(BSP_CMD_GET_SHARE_POWER_RISING_LEVEL, quotaLimit);
}

UINT32 BspGetSharePowerTimeGap(UINT32 *timeLimit)
{
    return BspCallService(BSP_CMD_GET_SHARE_POWER_TIME_GAP, timeLimit);
}

UINT32 BspRruLinkPwrOffChk(UINT32 *pIsPwrOff, UINT8 *pDesc, UINT32 descLen)
{
    return BspCallService(BSP_CMD_RRU_LINK_PWR_OFF_CHK, pIsPwrOff, pDesc, descLen);
}

UINT32 BspResetDevice(OSS_ULONG devId, UINT32 resetType, UINT32 cause)
{
    return BspCallService(BSP_CMD_RESET_DEVICE, devId, resetType, cause);
}

UINT32 BspRruLinkBreakTimeClr(VOID)
{
    return BspCallService(BSP_CMD_RRU_LINK_BREAK_TIME_CLR);
}

VOID BspBoardReset(VOID)
{
    BspCallService(BSP_CMD_BOARD_RESET);
    return;
}

UINT32 BspGetDryContactStatus(T_RruDryContactInfo *pInfo)
{
    return BspCallService(BSP_CMD_GET_DRY_CONTACT_STATUS, pInfo);
}

UINT32 BspGetRadioStandard(VOID)
{
    return BspCallService(BSP_CMD_GET_RADIO_STANDARD);
}

UINT32 BspIsClkSupportSw(VOID)
{
    return BspCallService(BSP_CMD_IS_CLK_SUPPORT_SW);
}

UINT32 BspSetRadioStandard(UINT32 stdRadio)
{
    return BspCallService(BSP_CMD_SET_RADIO_STANDARD, stdRadio);
}

UINT32 BspIsClkCauseUnLock(VOID)
{
    return BspCallService(BSP_CMD_IS_CLK_CAUSE_UN_LOCK);
}

UINT8 BspGetCpuId(VOID)
{
    return BspCallService(BSP_CMD_GET_CPU_ID);
}

UINT32 BspIsMtsTransceiver(UINT32 *uIsMtsTrans)
{
    return BspCallService(BSP_CMD_IS_MTS_TRANSCEIVER, uIsMtsTrans);
}

UINT32 BspGetCurrClkType(VOID)
{
    return BspCallService(BSP_CMD_GET_CURR_CLK_TYPE);
}

UINT32 BspSwClkType(UINT32 type)
{
    return BspCallService(BSP_CMD_SW_CLK_TYPE, type);
}

UINT32 BspIsPllFreqNormal(VOID)
{
    return BspCallService(BSP_CMD_IS_PLL_FREQ_NORMAL);
}

UINT16 BspSubFrameNumGet(VOID)
{
    return BspCallService(BSP_CMD_SUB_FRAME_NUM_GET);
}

UINT8  BspGetCoreId(VOID)
{
    return BspCallService(BSP_CMD_GET_CORE_ID);
}

UINT32 BspGetDiskFree(VOID)
{
    return BspCallService(BSP_CMD_GET_DISK_FREE);
}

UINT32 BspGetFpgaMaxTempResult(INT32 *lMaxTemp)
{
    return BspCallService(BSP_CMD_GET_FPGA_MAX_TEMP_RESULT, lMaxTemp);
}

UINT32 BspCheckPllStatus(OSS_ULONG ulDevId)
{
    return BspCallService(BSP_CMD_CHECK_PLL_STATUS, ulDevId);
}

UINT32 BspIsClkAllowSw(VOID)
{
    return BspCallService(BSP_CMD_IS_CLK_ALLOW_SW);
}

UINT32 BspGetRfTempByChanBand(UINT32 ulChan, UINT32 ulBand, INT32 *pTemp)
{
    return BspCallService(BSP_CMD_GET_RF_TEMP_BY_CHAN_BAND, ulChan, ulBand, pTemp);
}

UINT32 BspGetDeviceStatus(OSS_ULONG devId)
{
    return BspCallService(BSP_CMD_GET_DEVICE_STATUS, devId);
}

UINT32 BspGetTxFaultFromMtsUnByChan(UINT32 *uRegVal, UINT32 *uStatus)
{
    return BspCallService(BSP_CMD_GET_TX_FAULT_FROM_MTS_UN_BY_CHAN, uRegVal, uStatus);
}

UINT32 BspIsPllUnLock(VOID)
{
    return BspCallService(BSP_CMD_IS_PLL_UN_LOCK);
}

UINT32 BspGetTxFaultFromMtsByChan(UINT32 uChan, UINT32 *uRegVal, UINT32 *uStatus)
{
    return BspCallService(BSP_CMD_GET_TX_FAULT_FROM_MTS_BY_CHAN, uChan, uRegVal, uStatus);
}

UINT32 BspOptNetCfgSemPost(VOID)
{
    return BspCallService(BSP_CMD_OPT_NET_CFG_SEM_POST);
}

UINT32 BspGetOptNetCfgStatus(VOID)
{
    return BspCallService(BSP_CMD_GET_OPT_NET_CFG_STATUS);
}

VOID BspSetFpgaReLoadFlag(UINT32 fpgaLoadFlag)
{
    BspCallService(BSP_CMD_SET_FPGA_RE_LOAD_FLAG, fpgaLoadFlag);
    return;
}

UINT32 BspGetPhysAddr(T_BSP_PHYSICAL_ADDR *ptHwAddr)
{
    return BspCallService(BSP_CMD_GET_PHYS_ADDR, ptHwAddr);
}

T_RruCfgInfo *BspGetCfgInfo(VOID)
{
    T_RruCfgInfo *rruCfgInfo = NULL;

    BspCallService(BSP_CMD_GET_CFG_INFO, (T_RruCfgInfo **)&rruCfgInfo);

    return rruCfgInfo;
}

UINT32 BspGetMch1Ip(UINT8 *pAddr)
{
    return BspCallService(BSP_CMD_GET_MCH1_IP, pAddr);
}

UINT32 BspGetSerdesAndCpriStatus(UINT32 *pSerdesCpriStatus)
{
    return BspCallService(BSP_CMD_GET_SERDES_AND_CPRI_STATUS, pSerdesCpriStatus);
}

UINT32 BspGetMch2Ip(UINT8 *pAddr)
{
    return BspCallService(BSP_CMD_GET_MCH2_IP, pAddr);
}

UINT32 BspGetRruIp(UINT32 index)
{
    return BspCallService(BSP_CMD_GET_RRU_IP, index);
}

UINT32 BspGetFsIp(VOID)
{
    return BspCallService(BSP_CMD_GET_FS_IP);
}

UINT32 BspGetDataNetLinkState(UINT32 *pNetStatus)
{
    return BspCallService(BSP_CMD_GET_DATA_NET_LINK_STATE, pNetStatus);
}

UINT32 BspGetMchMaster(VOID)
{
    return BspCallService(BSP_CMD_GET_MCH_MASTER);
}

UINT32 BspDtiControl(T_BSP_DEV_PARA *pPara)
{
    return BspCallService(BSP_CMD_DTI_CONTROL, pPara);
}

UINT32 BSPGetHardID(VOID)
{
    return BspCallService(BSP_CMD_BSP_GET_HARD_ID);
}

UINT32 BspGetDiskTotalSize(VOID)
{
    return BspCallService(BSP_CMD_GET_DISK_TOTAL_SIZE);
}

UINT32 BspSetOptNetCfgStatus(UINT32 optCfgStatus)
{
    return BspCallService(BSP_CMD_SET_OPT_NET_CFG_STATUS, optCfgStatus);
}

UINT32 BspSetCfgInfo(T_RruCfgInfo *pTRruCfgInfo)
{
    return BspCallService(BSP_CMD_SET_CFG_INFO, pTRruCfgInfo);
}

UINT32 BspSetBootpInfo(T_RruCfgInfo *pRruCfgInfo)
{
    return BspCallService(BSP_CMD_SET_BOOTP_INFO, pRruCfgInfo);
}

UINT32 BspGetRootDir(CHAR *pcDirBuf,UINT32 len)
{
    return BspCallService(BSP_CMD_GET_ROOT_DIR, pcDirBuf, len);
}

UINT32 BspOptNetCfgSemWait(VOID)
{
    return BspCallService(BSP_CMD_OPT_NET_CFG_SEM_WAIT);
}

UINT32 BspGetHardId(VOID)
{
    return BspCallService(BSP_CMD_GET_HARD_ID);
}

UINT32 BspGetBoardInitStatus(VOID)
{
    return BspCallService(BSP_CMD_GET_BOARD_INIT_STATUS);
}

UINT32 BspGetBbuUniqueId(UCHAR *uniqueId)
{
    return BspCallService(BSP_CMD_GET_BBU_UNIQUE_ID, uniqueId);
}

UINT32 BspSetBbuUniqueId(UCHAR uniqueId, UCHAR secondSet)
{
    return BspCallService(BSP_CMD_SET_BBU_UNIQUE_ID, uniqueId, secondSet);
}

UINT32 BspGetBbuUniqueIdEx(UCHAR *uniqueId,  UCHAR ucFunction)
{
    return BspCallService(BSP_CMD_GET_BBU_UNIQUE_ID_EX, uniqueId, ucFunction);
}

UINT32 BspSetBbuUniqueIdEx(UCHAR uniqueIdInput, UCHAR secondSet, UCHAR ucFunction)
{
    return BspCallService(BSP_CMD_SET_BBU_UNIQUE_ID_EX, uniqueIdInput, secondSet, ucFunction);
}

UINT32 BspSetAntiThefLockFlag(UINT32 mode, UCHAR lockFlag)
{
    return BspCallService(BSP_CMD_SET_ANTI_THEF_LOCK_FLAG, mode, lockFlag);
}

UINT32 BspGetAntiThefLockFlag(ULONG mode)
{
    return BspCallService(BSP_CMD_GET_ANTI_THEF_LOCK_FLAG, mode);
}

UINT32 BspGetSfpTypeByLgcId(UINT32 sfpIndex)
{
    return BspCallService(BSP_CMD_GET_SFP_TYPE_BY_LGC_ID, sfpIndex);
}

UINT32 BspGetOptRaidoByPhyOpt(UINT32 phyOpt, UINT32 *radioMode, UINT32 *optPro)
{
    return BspCallService(BSP_CMD_GET_OPT_RAIDO_BY_PHY_OPT, phyOpt, radioMode, optPro);
}

UINT32 BspGetMcsCarrIdMap(T_McsCarrIdMap *pMap, UINT32 *num)
{
    return BspCallService(BSP_CMD_GET_MCS_CARR_ID_MAP, pMap, num);
}

UINT32 BspSetMcsCarrIdMap(T_McsCarrIdMap *pMap, UINT32 num)
{
    return BspCallService(BSP_CMD_SET_MCS_CARR_ID_MAP, pMap, num);
}

UINT32 BspGetPwrIdxByBspChan(UINT32 bspChan, UINT32 *pPwrIdx)
{
    return BspCallService(BSP_CMD_GET_PWR_IDX_BY_BSP_CHAN, bspChan, pPwrIdx);
}

UINT32 BspHandlePreLoReCfg(UINT32 trx, UINT32 chan)
{
    return BspCallService(BSP_CMD_HANDLE_PRE_LO_RE_CFG, trx, chan);
}

UINT32 BspSetNbTxFreqOffset(UINT32 bspChn, UINT32 carrNo, INT32 offset)
{
    return BspCallService(BSP_CMD_SET_NB_TX_FREQ_OFFSET, bspChn, carrNo, offset);
}

UINT32 BspSetCenterFreq(UINT32 dir, UINT32 chan, UINT32 freq)
{
    return BspCallService(BSP_CMD_SET_CENTER_FREQ, dir, chan, freq);
}

UINT32 BspGetLoFreq(UINT32 dir, UINT32 chan)
{
    return BspCallService(BSP_CMD_GET_LO_FREQ, dir, chan);
}

UINT32 BspSetNbRxFreqOffset(UINT32 bspChn, UINT32 carrNo, INT32 offset)
{
    return BspCallService(BSP_CMD_SET_NB_RX_FREQ_OFFSET, bspChn, carrNo, offset);
}

UINT32 BspSetTransceiverLoFreq(UINT32 trx, UINT32 chan, UINT32 freq)
{
    return BspCallService(BSP_CMD_SET_TRANSCEIVER_LO_FREQ, trx, chan, freq);
}

UINT32 BspGetRfCfgCarrSum(UINT32 dir, UINT32 chan)
{
    return BspCallService(BSP_CMD_GET_RF_CFG_CARR_SUM, dir, chan);
}

UINT32 BspHandlePostLoReCfg(UINT32 trx, UINT32 chan)
{
    return BspCallService(BSP_CMD_HANDLE_POST_LO_RE_CFG, trx, chan);
}

UINT32 BspRfCfgInfoCollect(VOID)
{
    return BspCallService(BSP_CMD_RF_CFG_INFO_COLLECT);
}

UINT32 BspSetTsgSwitch(UINT32 chan, UINT32 carr, UINT32 carrRadio, UINT32 isOn)
{
    return BspCallService(BSP_CMD_SET_TSG_SWITCH, chan, carr, carrRadio, isOn);
}

UINT32 BspSetRxRfCfg(UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
    return BspCallService(BSP_CMD_SET_RX_RF_CFG, chan, pRfCfgPara);
}

UINT32 BspIsExistTxLink(UINT32 bspChan, UINT32 *txCarrNum)
{
    return BspCallService(BSP_CMD_IS_EXIST_TX_LINK, bspChan, txCarrNum);
}

UINT32 BspGetCenterFreq(UINT32 dir, UINT32 chan)
{
    return BspCallService(BSP_CMD_GET_CENTER_FREQ, dir, chan);
}

UINT32 BspSetTxRfCfg(UINT32 chan, T_RfCfgPara *pRfCfgPara)
{
    return BspCallService(BSP_CMD_SET_TX_RF_CFG, chan, pRfCfgPara);
}

UINT32 BspSetTxRxCarrFreq(UINT32 bspChan, UINT32 carrNo, UINT32 radioMode, UINT32 dir,UINT32 carrFreq)
{
    return BspCallService(BSP_CMD_SET_TX_RX_CARR_FREQ, bspChan, carrNo, radioMode, dir, carrFreq);
}

UINT32 BspSetUmtsCarrFreq(UINT32 bspChan, UINT32 dir, UINT32 umtsCarrNo, INT32 freqOffset)
{
    return BspCallService(BSP_CMD_SET_UMTS_CARR_FREQ, bspChan, dir, umtsCarrNo, freqOffset);
}

UINT32 BspSetUmtsTxNco(UINT32 chanId, UINT32 carrNo, INT32 swFreqOffset)
{
    return BspCallService(BSP_CMD_SET_UMTS_TX_NCO, chanId, carrNo, swFreqOffset);
}

UINT32 BspAnalyseRfcCfgFreqCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    return BspCallService(BSP_CMD_ANALYSE_RFC_CFG_FREQ_CARR_INFO, pCarrInfoAllChans);
}

UINT32 BspChangePllCfgPreAnalyse(UINT32 trx, T_RfCfgParaAllChan *allChanCfgInfo , T_PllChangeInfoAllChan *allChanChangeInfo)
{
    return BspCallService(BSP_CMD_CHANGE_PLL_CFG_PRE_ANALYSE, trx, allChanCfgInfo, allChanChangeInfo);
}

UINT32 BspResourceAllocRpt(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    return BspCallService(BSP_CMD_RESOURCE_ALLOC_RPT, pCarrInfoAllChans);
}

UINT32 BspSetUmtsDlFilterCoef(UINT32 bspChan, UINT32 radioMod, UINT32 carrNo, UINT32 bandWidth)
{
    return BspCallService(BSP_CMD_SET_UMTS_DL_FILTER_COEF, bspChan, radioMod, carrNo, bandWidth);
}

UINT32 BspGetPublicDlFilterPara(UINT32 bspChan, UINT32 carrNo, UINT32 radioMod, T_carrFilterPara *carrPara)
{
    return BspCallService(BSP_CMD_GET_PUBLIC_DL_FILTER_PARA, bspChan, carrNo, radioMod, carrPara);
}

UINT32 BspIsFreqCfgDynamic(void)
{
    return BspCallService(BSP_CMD_IS_FREQ_CFG_DYNAMIC);
}

UINT32 BspSetTsgTdmInfo(T_Tsg_TdmInfo *ptTdmInfo)
{
    return BspCallService(BSP_CMD_SET_TSG_TDM_INFO, ptTdmInfo);
}

UINT32 BspIsExistRxLink(UINT32 bspChan, UINT32 *rxCarrNum)
{
    return BspCallService(BSP_CMD_IS_EXIST_RX_LINK, bspChan, rxCarrNum);
}

UINT32 BspResourceAllocCfg(UINT32 dir, UINT32 rfChan, T_RfChanCfgEn *pRfChanCfgEn)
{
    return BspCallService(BSP_CMD_RESOURCE_ALLOC_CFG, dir, rfChan, pRfChanCfgEn);
}

UINT32 BspSetGsmCellInfo(T_GsmCellInfo *gsmCellInfo)
{
    return BspCallService(BSP_CMD_SET_GSM_CELL_INFO, gsmCellInfo);
}

UINT32 BspUpdateVswrComps(UINT32 uBspChan, UINT32 uFreqKHz)
{
    return BspCallService(BSP_CMD_UPDATE_VSWR_COMPS, uBspChan, uFreqKHz);
}

UINT32 BspPreAnalyseCarrInfo(T_DestCarrInfoAllChans *pCarrInfoAllChans)
{
    return BspCallService(BSP_CMD_PRE_ANALYSE_CARR_INFO, pCarrInfoAllChans);
}

UINT32 BspGetRcfCoefByBandWith(UINT32 bspChan, UINT32 radioMod, UINT32 bandWidth)
{
    return BspCallService(BSP_CMD_GET_RCF_COEF_BY_BAND_WITH, bspChan, radioMod, bandWidth);
}

UINT32 BspGetBbTa3Delay(UINT32 phyOpt)
{
    return BspCallService(BSP_CMD_GET_BB_TA3_DELAY, phyOpt);
}

UINT32 BspSetOptCarrDelay(UINT32 uChan, UINT32 uRadioMode, T_BspCarrDelayItem *ptCarrDelayItem)
{
    return BspCallService(BSP_CMD_SET_OPT_CARR_DELAY, uChan, uRadioMode, ptCarrDelayItem);
}

UINT32 BspSetFrameDelay(UINT32 phyOpt, UINT32 tadv)
{
    return BspCallService(BSP_CMD_SET_FRAME_DELAY, phyOpt, tadv);
}

UINT32 BspSetUlTimePhaseOffset(UINT32 carrNo, UINT32 radioMode, UINT32 value)
{
    return BspCallService(BSP_CMD_SET_UL_TIME_PHASE_OFFSET, carrNo, radioMode, value);
}

UINT32 BspGetBbT2aDelay(UINT32 phyOpt)
{
    return BspCallService(BSP_CMD_GET_BB_T2A_DELAY, phyOpt);
}

UINT32 BspSetToffset(UINT32 phyOpt, UINT32 toffset)
{
    return BspCallService(BSP_CMD_SET_TOFFSET, phyOpt, toffset);
}

UINT32 BspSetCpeTxTimingAdvance(UINT32 cellId, UINT32 radioMod, UINT32 cpeMode)
{
    return BspCallService(BSP_CMD_SET_CPE_TX_TIMING_ADVANCE, cellId, radioMod, cpeMode);
}

UINT32 BspSetT12(T_RruDelayReq *ptT12)
{
    return BspCallService(BSP_CMD_SET_T12, ptT12);
}

UINT32 BspSetFrameAlignment(UINT32 bandId, UINT32 radioMode, INT32 lFrameDelay)
{
    return BspCallService(BSP_CMD_SET_FRAME_ALIGNMENT, bandId, radioMode, lFrameDelay);
}

UINT32 BspGetOptDelayPara(UINT32 ulIsLogVal, UINT32 ulRadioMode, T_NewRruOptDelayPara *ptOptDelayPara)
{
    return BspCallService(BSP_CMD_GET_OPT_DELAY_PARA, ulIsLogVal, ulRadioMode, ptOptDelayPara);
}

UINT32 BspSetFrameAlignment_Fdd(UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 lFrameDelay)
{
    return BspCallService(BSP_CMD_SET_FRAME_ALIGNMENT__FDD, bspChn, radioMode, carrNo, lFrameDelay);
}

UINT32 BspSetFddNrIf1DiffTa(UINT32 TaValue, INT32 TxDiffTa)
{
    return BspCallService(BSP_CMD_SET_FDD_NR_IF1_DIFF_TA, TaValue, TxDiffTa);
}

UINT32 BspSetRfAcDelayIc42(UINT32 acType, UINT32 chanNo, INT8 delayTa, INT8 Tac, UINT32 bandWith, UINT32 radioMode, UINT32 carrNo)
{
    return BspCallService(BSP_CMD_SET_RF_AC_DELAY_IC42, acType, chanNo, delayTa, Tac, bandWith, radioMode, carrNo);
}

UINT32 BspSetTaValue_Fdd(UINT32 TaValue)
{
    return BspCallService(BSP_CMD_SET_TA_VALUE__FDD, TaValue);
}

UINT32 BspGetOptEthName(UINT32 rruOpt, CHAR *ethName, UINT32 ethNameSize)
{
    return BspCallService(BSP_CMD_GET_OPT_ETH_NAME, rruOpt, ethName, ethNameSize);
}

UINT32 BspOptCellInfoInit(T_CellCfgInfo *pPara)
{
    return BspCallService(BSP_CMD_OPT_CELL_INFO_INIT, pPara);
}

UINT32 BspFftWinSet(UINT32 uCellId, UINT32 uWinMode, UINT32 uTblIndex)
{
    return BspCallService(BSP_CMD_FFT_WIN_SET, uCellId, uWinMode, uTblIndex);
}

UINT32 BspOptIqSlaveCfg(UINT32 uCfgNum, T_IQRecord_Slave *pPara)
{
    return BspCallService(BSP_CMD_OPT_IQ_SLAVE_CFG, uCfgNum, pPara);
}

UINT32 BspGetSfpTemp(UINT32 sfpId, INT32 *pTemp)
{
    return BspCallService(BSP_CMD_GET_SFP_TEMP, sfpId, pTemp);
}

UINT32 BspSaveOptSpeedFromApp(UINT32 ulLogicOpt, UINT32 ulCpriRate)
{
    return BspCallService(BSP_CMD_SAVE_OPT_SPEED_FROM_APP, ulLogicOpt, ulCpriRate);
}

UINT32 BspGetBbuFiberPort(UINT32 ruOptPort)
{
    return BspCallService(BSP_CMD_GET_BBU_FIBER_PORT, ruOptPort);
}

UINT32 BspOptL1CellPrachInfoInit(UINT32 uRachNum, T_PrachCellInfo *pPara)
{
    return BspCallService(BSP_CMD_OPT_L1_CELL_PRACH_INFO_INIT, uRachNum, pPara);
}

UINT32 BspGetLogicOptByMsOpt(UINT32 *uUpLinkLogicOpt, UINT32 *uDownLinkLogicOpt)
{
    return BspCallService(BSP_CMD_GET_LOGIC_OPT_BY_MS_OPT, uUpLinkLogicOpt, uDownLinkLogicOpt);
}

UINT32 BspGetBbuShelfIndex(UINT32 optIndex)
{
    return BspCallService(BSP_CMD_GET_BBU_SHELF_INDEX, optIndex);
}

UINT32 BspSetCsirsPortAntMap(T_CsirsPortAntMap *csirsPortAntMap)
{
    return BspCallService(BSP_CMD_SET_CSIRS_PORT_ANT_MAP, csirsPortAntMap);
}

UINT32 BspOamCellPreAlloc(T_DestCarrInfoAllChans* cfgInfo, T_PreAllocResult* preAllocResult)
{
    return BspCallService(BSP_CMD_OAM_CELL_PRE_ALLOC, cfgInfo, preAllocResult);
}

UINT32 BspGetOptStatus(UINT32 optId)
{
    return BspCallService(BSP_CMD_GET_OPT_STATUS, optId);
}

UINT32 BspClrAllPreAllocSource(VOID)
{
    return BspCallService(BSP_CMD_CLR_ALL_PRE_ALLOC_SOURCE);
}

UINT32 BspGetOptBer(UINT32 optIndex, UINT32 *pValue)
{
    return BspCallService(BSP_CMD_GET_OPT_BER, optIndex, pValue);
}

UINT32 BspSetOptTxDisable(UINT32 ulIndex, UINT32 ulHighFlag)
{
    return BspCallService(BSP_CMD_SET_OPT_TX_DISABLE, ulIndex, ulHighFlag);
}

UINT32 BspOptIqInfoCfg(UINT32 uCfgNum, T_IQRecord_TDD *pPara)
{
    return BspCallService(BSP_CMD_OPT_IQ_INFO_CFG, uCfgNum, pPara);
}

UINT32 BspOamPreAllocReMap(UINT32 preAllocRet)
{
    return BspCallService(BSP_CMD_OAM_PRE_ALLOC_RE_MAP, preAllocRet);
}

UINT32 BspOptSetFFTPara(UINT32 uCellId, UINT32 uDir, UINT32 uScs, T_FFTAParam *pPara)
{
    return BspCallService(BSP_CMD_OPT_SET_FFT_PARA, uCellId, uDir, uScs, pPara);
}

UINT32 BspOptCellInfoCfg(UINT32 uCellIdx)
{
    return BspCallService(BSP_CMD_OPT_CELL_INFO_CFG, uCellIdx);
}

UINT32 BspIqCfgInit(VOID)
{
    return BspCallService(BSP_CMD_IQ_CFG_INIT);
}

UINT32 BspSetOptWorkMode(UINT32 optMode)
{
    return BspCallService(BSP_CMD_SET_OPT_WORK_MODE, optMode);
}

UINT32 BspClrPreAlloc(void)
{
    return BspCallService(BSP_CMD_CLR_PRE_ALLOC);
}

UINT32 BspSetRfTestSwitch(UINT32 carrNo, UINT32 radioMode, UINT32 sw)
{
    return BspCallService(BSP_CMD_SET_RF_TEST_SWITCH, carrNo, radioMode, sw);
}

UINT32 BspSetPhaCompPara(UINT32 uCellId, UINT32 uDir, UINT32 uFreq)
{
    return BspCallService(BSP_CMD_SET_PHA_COMP_PARA, uCellId, uDir, uFreq);
}

UINT32 BspClrOptSpdChgRecord(VOID)
{
    return BspCallService(BSP_CMD_CLR_OPT_SPD_CHG_RECORD);
}

UINT32 BspGetOptSpdChgRecord(VOID)
{
    return BspCallService(BSP_CMD_GET_OPT_SPD_CHG_RECORD);
}

UINT32 BspGetSwitchMainPhyOptFlag(void)
{
    return BspCallService(BSP_CMD_GET_SWITCH_MAIN_PHY_OPT_FLAG);
}

UINT32 BspGetOptSpeed(UINT32 ulIndex)
{
    return BspCallService(BSP_CMD_GET_OPT_SPEED, ulIndex);
}

UINT32 BspGetCurrentFiberPort(VOID)
{
    return BspCallService(BSP_CMD_GET_CURRENT_FIBER_PORT);
}

UINT32 BspGetSfpStatus(UINT32 sfpId)
{
    return BspCallService(BSP_CMD_GET_SFP_STATUS, sfpId);
}

UINT32 BspGetOptCnt(UINT32 ulType)
{
    return BspCallService(BSP_CMD_GET_OPT_CNT, ulType);
}

UINT32 BspGetRruId(UINT32 ulIndex)
{
    return BspCallService(BSP_CMD_GET_RRU_ID, ulIndex);
}

UINT32 BspGetTxGainMax(UINT32 chan, INT32 *pGain)
{
    return BspCallService(BSP_CMD_GET_TX_GAIN_MAX, chan, pGain);
}

UINT32 BspGetTxGain(UINT32 chn, INT32 *pVal)
{
    return BspCallService(BSP_CMD_GET_TX_GAIN, chn, pVal);
}

UINT32 BspGetTxGainMin(UINT32 chan, INT32 *pGain)
{
    return BspCallService(BSP_CMD_GET_TX_GAIN_MIN, chan, pGain);
}

UINT32 BspSetTxGain(UINT32 chn, INT32 val)
{
    return BspCallService(BSP_CMD_SET_TX_GAIN, chn, val);
}

UINT32 BspSetKdGain(UINT32 bspChn, INT32 gain)
{
    return BspCallService(BSP_CMD_SET_KD_GAIN, bspChn, gain);
}

UINT32 BspSetMixGain(UINT32 chan, UINT32 band, INT32 gain)
{
    return BspCallService(BSP_CMD_SET_MIX_GAIN, chan, band, gain);
}

UINT32 BspGetTxPcGain(UINT32 chan, UINT32 carr, UINT32 radioMode, INT32 *pGain)
{
    return BspCallService(BSP_CMD_GET_TX_PC_GAIN, chan, carr, radioMode, pGain);
}

UINT32 BspGetKdGain(UINT32 chan, INT32 *pGain)
{
    return BspCallService(BSP_CMD_GET_KD_GAIN, chan, pGain);
}

UINT32 BspGetTxCarrGain(UINT32 ulBspChnl, UINT32 ulPhyCarr, INT32 *plCarrGain)
{
    return BspCallService(BSP_CMD_GET_TX_CARR_GAIN, ulBspChnl, ulPhyCarr, plCarrGain);
}

UINT32 BspSetTxPcGain(UINT32 chan, UINT32 carr, UINT32 radioMode, INT32 gain)
{
    return BspCallService(BSP_CMD_SET_TX_PC_GAIN, chan, carr, radioMode, gain);
}

UINT32 BspGetKnGainMax(UINT32 chan, INT32 *pGain)
{
    return BspCallService(BSP_CMD_GET_KN_GAIN_MAX, chan, pGain);
}

UINT32 BspSetPaNormalFlag(UINT32 chan, UINT32 normalFlag)
{
    return BspCallService(BSP_CMD_SET_PA_NORMAL_FLAG, chan, normalFlag);
}

UINT32 BspSetPaVibasByChan(UINT32 index, UINT32 paChan)
{
    return BspCallService(BSP_CMD_SET_PA_VIBAS_BY_CHAN, index, paChan);
}

UINT32 BspSetPaVibas(UINT32 index)
{
    return BspCallService(BSP_CMD_SET_PA_VIBAS, index);
}

UINT32 BspSetPaFddSwitch(UINT32 chan,UINT32 sw)
{
    return BspCallService(BSP_CMD_SET_PA_FDD_SWITCH, chan, sw);
}

UINT32 BspGetPaSwitch(UINT32 chan)
{
    return BspCallService(BSP_CMD_GET_PA_SWITCH, chan);
}

UINT32 BspSetPaSwitch(UINT32 chan, UINT32 sw)
{
    return BspCallService(BSP_CMD_SET_PA_SWITCH, chan, sw);
}

UINT32 BspSetCfrDisable(UINT32 bspChn)
{
    return BspCallService(BSP_CMD_SET_CFR_DISABLE, bspChn);
}

UINT32 BspSetCfrEnable(UINT32 bspChn)
{
    return BspCallService(BSP_CMD_SET_CFR_ENABLE, bspChn);
}

UINT32 BspSetCfrGateByCoef(UINT32 ulChn, DOUBLE dCfrPara)
{
    return BspCallService(BSP_CMD_SET_CFR_GATE_BY_COEF, ulChn, dCfrPara);
}

UINT32 BspSetCfrCpgPara(UINT32 bspChn)
{
    return BspCallService(BSP_CMD_SET_CFR_CPG_PARA, bspChn);
}

UINT32 BspSetCfrCpgDelay(UINT32 bspChn)
{
    return BspCallService(BSP_CMD_SET_CFR_CPG_DELAY, bspChn);
}

UINT32 BspSetNBCarrMode(UINT32 ulChan, UINT32 ulCarr, UINT32 ulMode)
{
    return BspCallService(BSP_CMD_SET_N_B_CARR_MODE, ulChan, ulCarr, ulMode);
}

UINT32 BspSetUmtsCpgCoef(UINT32 bspChan, UINT32 ulCarrId, UINT32 radioMod, UINT32 bandWidth, UINT32 cfgflag)
{
    return BspCallService(BSP_CMD_SET_UMTS_CPG_COEF, bspChan, ulCarrId, radioMod, bandWidth, cfgflag);
}

UINT32 BspCfrClrHwCpgRam(UINT32 bspChnChgMask)
{
    return BspCallService(BSP_CMD_CFR_CLR_HW_CPG_RAM, bspChnChgMask);
}

UINT32 BspGetFwdCpIfTssi(UINT32 bspChn, UINT32 ulBand, INT32 *pFwdCpIfTssiDbm)
{
    return BspCallService(BSP_CMD_GET_FWD_CP_IF_TSSI, bspChn, ulBand, pFwdCpIfTssiDbm);
}

UINT32 BspGetTempGainComps(UINT32 chanNo, UINT32 type, INT32 *pComps)
{
    return BspCallService(BSP_CMD_GET_TEMP_GAIN_COMPS, chanNo, type, pComps);
}

UINT32 BspGetTxIfTssi(UINT32 bspChn, UINT32 ulBand, INT32 *pTxIfTssiDbm)
{
    return BspCallService(BSP_CMD_GET_TX_IF_TSSI, bspChn, ulBand, pTxIfTssiDbm);
}

UINT32 BspGetScalarVswr(UINT32 chan, UINT32 *pVswrVal)
{
    return BspCallService(BSP_CMD_GET_SCALAR_VSWR, chan, pVswrVal);
}

UINT32 BspSetPowLevel(UINT32 ulChan, UINT32 ulPowLevel)
{
    return BspCallService(BSP_CMD_SET_POW_LEVEL, ulChan, ulPowLevel);
}

void powshow()
{
    BspCallService(BSP_CMD_POWSHOW);
    return;
}

UINT32 BspSetUmtsTxCarrPow(UINT32 bspChn, UINT32 carrIdx, UINT32 carrdb)
{
    return BspCallService(BSP_CMD_SET_UMTS_TX_CARR_POW, bspChn, carrIdx, carrdb);
}

UINT32 BspGetThreshold(UINT32 chn, OSS_ULONG ulThresholdId, UINT32 *pulHighVal, UINT32 *pulLowVal)
{
    return BspCallService(BSP_CMD_GET_THRESHOLD, chn, ulThresholdId, pulHighVal, pulLowVal);
}

UINT32 BspTxOpenLoopPowCail(UINT32 chanNo)
{
    return BspCallService(BSP_CMD_TX_OPEN_LOOP_POW_CAIL, chanNo);
}

UINT32 BspGetTempThreshold(UINT32 ulChan, UINT32 ulThresholdId, INT32 *plWarning, INT32 *plResume)
{
    return BspCallService(BSP_CMD_GET_TEMP_THRESHOLD, ulChan, ulThresholdId, plWarning, plResume);
}

UINT32 BspSetNbicSwitch(UINT32 bspChn, UINT32 carrNo, UINT32 sw)
{
    return BspCallService(BSP_CMD_SET_NBIC_SWITCH, bspChn, carrNo, sw);
}

UINT32 BspGetTxOpenRl(UINT32 Index, INT32 *pTxOpenRl)
{
    return BspCallService(BSP_CMD_GET_TX_OPEN_RL, Index, pTxOpenRl);
}

UINT32 BspRxOpenLoopPowCail(UINT32 chanNo)
{
    return BspCallService(BSP_CMD_RX_OPEN_LOOP_POW_CAIL, chanNo);
}

UINT32 BspGetTxOpenLoopPwrDiff(UINT32 chanNo, INT32* attVal)
{
    return BspCallService(BSP_CMD_GET_TX_OPEN_LOOP_PWR_DIFF, chanNo, attVal);
}

UINT32 BspRxShutSwitchByCarr(UINT32 uChn, UINT32 ulCarr, UINT32 uSwitch)
{
    return BspCallService(BSP_CMD_RX_SHUT_SWITCH_BY_CARR, uChn, ulCarr, uSwitch);
}

UINT32 BspGetPaVswrVal(UINT32 ulChan, UINT32 ulFreqBand, UINT32 ulPaOrAntenaMode)
{
    return BspCallService(BSP_CMD_GET_PA_VSWR_VAL, ulChan, ulFreqBand, ulPaOrAntenaMode);
}

UINT32 BspAdpGetPwrVoltLimitDown(UINT32 ulIndex, UINT32 *pVoltDown)
{
    return BspCallService(BSP_CMD_ADP_GET_PWR_VOLT_LIMIT_DOWN, ulIndex, pVoltDown);
}

UINT32 BspSetRxAnfCfg(T_RxAnfCfg *ptRxAnfCfg, UINT32 ulCount)
{
    return BspCallService(BSP_CMD_SET_RX_ANF_CFG, ptRxAnfCfg, ulCount);
}

UINT32 BspAdpGetPwrVoltLimitUp(UINT32 ulIndex, UINT32 *pVoltUp)
{
    return BspCallService(BSP_CMD_ADP_GET_PWR_VOLT_LIMIT_UP, ulIndex, pVoltUp);
}

UINT32 BspGetUmtsTxCarrPow(UINT32 bspChn, UINT32 carrNo)
{
    return BspCallService(BSP_CMD_GET_UMTS_TX_CARR_POW, bspChn, carrNo);
}

UINT32 BspTempParaUpdate()
{
    return BspCallService(BSP_CMD_TEMP_PARA_UPDATE);
}

UINT32 BspGetRssiPow(UINT32 chan,UINT32 radio, UINT32 carr, INT32 *pBbPow)
{
    return BspCallService(BSP_CMD_GET_RSSI_POW, chan, radio, carr, pBbPow);
}

UINT32 BspFbOpenLoopPowCail(UINT32 chanNo)
{
    return BspCallService(BSP_CMD_FB_OPEN_LOOP_POW_CAIL, chanNo);
}

UINT32 BspGetTssiPowInfo(UINT32 chan, UINT32 radio, UINT32 carr, INT32 *pTssiDbm, INT32 *pTssiDbfs)
{
    return BspCallService(BSP_CMD_GET_TSSI_POW_INFO, chan, radio, carr, pTssiDbm, pTssiDbfs);
}

UINT32 BspGetTssiTcpw(UINT32 chan, T_TxDualPow *fwd, T_TxDualPow *rev, UINT32 *num)
{
    return BspCallService(BSP_CMD_GET_TSSI_TCPW, chan, fwd, rev, num);
}

UINT32 BspSetTmaGain(UINT32 uAntNo, UINT32 uTmaGain)
{
    return BspCallService(BSP_CMD_SET_TMA_GAIN, uAntNo, uTmaGain);
}

UINT32 BspGetPaDefaultVolt(UINT32 ulChan, UINT32 *pVolt)
{
    return BspCallService(BSP_CMD_GET_PA_DEFAULT_VOLT, ulChan, pVolt);
}

UINT32 BspGetPaGainByVolt(UINT32 ulChanSel, UINT32 ulBand, UINT32 ulPaVolt, UINT32 ulCfgPower, DOUBLE *pCfrPara, INT32 *ulPaGain)
{
    return BspCallService(BSP_CMD_GET_PA_GAIN_BY_VOLT, ulChanSel, ulBand, ulPaVolt, ulCfgPower, pCfrPara, ulPaGain);
}

UINT32 BspGetPaVoltByCfgPower(UINT32 ulChanSel, UINT32 ulBand, UINT32 ulCfgPower, UINT32 ulVoltFlag, UINT32 *pVolt, DOUBLE *pCfrPara, INT32 *ulPaGain)
{
    return BspCallService(BSP_CMD_GET_PA_VOLT_BY_CFG_POWER, ulChanSel, ulBand, ulCfgPower, ulVoltFlag, pVolt, pCfrPara, ulPaGain);
}

UINT32 BspSetTxCompCenterFreq(UINT32 ulChan, UINT32 ulFreqBand, UINT32 ulFreq)
{
    return BspCallService(BSP_CMD_SET_TX_COMP_CENTER_FREQ, ulChan, ulFreqBand, ulFreq);
}

UINT32 BspGetBbTssiPow(UINT32 chan, UINT32 radio, UINT32 carr, INT32 *pBbPow)
{
    return BspCallService(BSP_CMD_GET_BB_TSSI_POW, chan, radio, carr, pBbPow);
}

UINT32 BspGetBoardTemp(UINT32 index, INT32 *pTemp)
{
    return BspCallService(BSP_CMD_GET_BOARD_TEMP, index, pTemp);
}

VOID rssi(UINT32 rssiType)
{
    BspCallService(BSP_CMD_RSSI, rssiType);
    return;
}

UINT32 BspGetRevCpIfTssi(UINT32 bspChn, UINT32 ulBand, INT32 *pRevCpIfTssiDbm)
{
    return BspCallService(BSP_CMD_GET_REV_CP_IF_TSSI, bspChn, ulBand, pRevCpIfTssiDbm);
}

UINT32 BspGetNbicSwitch(UINT32 bspChn, UINT32 carrNo, UINT32 *sw)
{
    return BspCallService(BSP_CMD_GET_NBIC_SWITCH, bspChn, carrNo, sw);
}

UINT32 BspGetTssiTcpwFlag(UINT32 bspChn, UINT32 ulBand, T_TxDualPow *ptDualPow, UINT32 *ulValidFlag)
{
    return BspCallService(BSP_CMD_GET_TSSI_TCPW_FLAG, bspChn, ulBand, ptDualPow, ulValidFlag);
}

UINT32 BspTxCaliProc(UINT32 TxRfGroup, UINT32 ulBand, INT32 lAttValue)
{
    return BspCallService(BSP_CMD_TX_CALI_PROC, TxRfGroup, ulBand, lAttValue);
}

UINT32 BspSetCarrPow(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_SET_CARR_POW, bspChn, carrIndex, carrPow, radioMode);
}

UINT32 BspGetDl60msTagState(UINT32 bspChn)
{
    return BspCallService(BSP_CMD_GET_DL60MS_TAG_STATE, bspChn);
}

UINT32 BspSetCarrCfgPow(UINT32 bspChn, UINT32 carrNo, UINT32 carrPow, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_SET_CARR_CFG_POW, bspChn, carrNo, carrPow, radioMode);
}

UINT32 BspGetPaTemp(UINT32 bspChn, INT32 *patmp)
{
    return BspCallService(BSP_CMD_GET_PA_TEMP, bspChn, patmp);
}

UINT32 BspGetBbTssiTcpw(UINT32 chan, UINT32 radio, UINT32 carr, INT32 *pTssi, INT32 *pTcpw)
{
    return BspCallService(BSP_CMD_GET_BB_TSSI_TCPW, chan, radio, carr, pTssi, pTcpw);
}

UINT32 BspSetOnlinePimPowerLevel(UINT32 percent)
{
    return BspCallService(BSP_CMD_SET_ONLINE_PIM_POWER_LEVEL, percent);
}

UINT32 BspSetPimData(T_PimOnline *pimOnlineData)
{
    return BspCallService(BSP_CMD_SET_PIM_DATA, pimOnlineData);
}

UINT32 BspGetOnlinePim2(UINT32 rxchnNo, UINT32 *carrNum, T_PimOnlineReportItemDsp *pimOnlineItem)
{
    return BspCallService(BSP_CMD_GET_ONLINE_PIM2, rxchnNo, carrNum, pimOnlineItem);
}

UINT32 BspSetOnlinePimMode(UINT32 mode)
{
    return BspCallService(BSP_CMD_SET_ONLINE_PIM_MODE, mode);
}

UINT32 BspSetOnlinePimDpd(UINT32 clearLutFlag)
{
    return BspCallService(BSP_CMD_SET_ONLINE_PIM_DPD, clearLutFlag);
}

UINT32 BspIsSupportDpdVswr(UINT32 chan)
{
    return BspCallService(BSP_CMD_IS_SUPPORT_DPD_VSWR, chan);
}

UINT32 BspGetDspVerStatus(VOID)
{
    return BspCallService(BSP_CMD_GET_DSP_VER_STATUS);
}

UINT32 BspStartOnlinePim2(UINT32 chan)
{
    return BspCallService(BSP_CMD_START_ONLINE_PIM2, chan);
}

UINT32 setWaitDspMode(UINT32 wait_dsp_mode)
{
    return BspCallService(BSP_CMD_SET_WAIT_DSP_MODE, wait_dsp_mode);
}

UINT32 BspGetAcSta(UINT32 chan)
{
    return BspCallService(BSP_CMD_GET_AC_STA, chan);
}

UINT32 BspDpdTsExpQuery(T_DpdTsExpQueryResult *queryResult)
{
    return BspCallService(BSP_CMD_DPD_TS_EXP_QUERY, queryResult);
}

UINT32 BspGetDpdStatus(UINT32 chan, UINT32 *status)
{
    return BspCallService(BSP_CMD_GET_DPD_STATUS, chan, status);
}

UINT32 BspGetPtsLmsSta(T_DpdLmsStatusAck *lmsPtsStatus)
{
    return BspCallService(BSP_CMD_GET_PTS_LMS_STA, lmsPtsStatus);
}

UINT32 BspStartDpd(UINT32 chan,UINT32 bandId)
{
    return BspCallService(BSP_CMD_START_DPD, chan, bandId);
}

UINT32 BspNoiseCheckStart(UINT32 slotindex)
{
    return BspCallService(BSP_CMD_NOISE_CHECK_START, slotindex);
}

UINT32 BspGetOnlinePim(UINT32 bspChn, UINT32 bandNo, INT32 *pimVal, INT32 *mutiPimVal, INT32 *noiseVal, UINT16 *rxPimFreq, UINT16 *rhoVal)
{
    return BspCallService(BSP_CMD_GET_ONLINE_PIM, bspChn, bandNo, pimVal, mutiPimVal, noiseVal, rxPimFreq, rhoVal);
}

UINT32 BspInitDpd(UINT32 Chan, UINT32 bandId)
{
    return BspCallService(BSP_CMD_INIT_DPD, Chan, bandId);
}

UINT32 BspStartPtsLmsStart(VOID)
{
    return BspCallService(BSP_CMD_START_PTS_LMS_START);
}

UINT32 BspGetPimOnlineRruInfo(T_DpdPimOnlineHwRruInfo *PimOnlineRruInfo)
{
    return BspCallService(BSP_CMD_GET_PIM_ONLINE_RRU_INFO, PimOnlineRruInfo);
}

UINT32 acGetDpdStrAcDsp(UINT32 index, INT32 data0, INT32 data1, INT32 data2, INT32 data3)
{
    return BspCallService(BSP_CMD_AC_GET_DPD_STR_AC_DSP, index, data0, data1, data2, data3);
}

UINT32 BspGetDpdLutDowmNum(UINT32 chan, INT32 *pNum)
{
    return BspCallService(BSP_CMD_GET_DPD_LUT_DOWM_NUM, chan, pNum);
}

UINT32 BspGetNoiseCheckSta(T_DpdDpdNoiseStaAck *pimOnlineNoiseCheckSta)
{
    return BspCallService(BSP_CMD_GET_NOISE_CHECK_STA, pimOnlineNoiseCheckSta);
}

UINT32 BspDpdMsgPimDpdStart(UINT32 chan)
{
    return BspCallService(BSP_CMD_DPD_MSG_PIM_DPD_START, chan);
}

UINT32 BspMsgInsOnLineCal(UINT32 uiBandWidth, UINT32 OnlineInsType, UINT32 uiSampleRate, UINT32 uMode)
{
    return BspCallService(BSP_CMD_MSG_INS_ON_LINE_CAL, uiBandWidth, OnlineInsType, uiSampleRate, uMode);
}

UINT32 BspPimOnlineEnergyCalStart(T_DpdPimOnlineEnergyCalCtrl *pimOnlineEngCalCtrl)
{
    return BspCallService(BSP_CMD_PIM_ONLINE_ENERGY_CAL_START, pimOnlineEngCalCtrl);
}

UINT32 BspGetDspCallChain(UINT32 *pData)
{
    return BspCallService(BSP_CMD_GET_DSP_CALL_CHAIN, pData);
}

UINT32 BspGetPimOnlineCheckSta(UINT32 *PimOnlineCheckSta)
{
    return BspCallService(BSP_CMD_GET_PIM_ONLINE_CHECK_STA, PimOnlineCheckSta);
}

UINT32 acGetDpdStrAcDspInfo(UINT32 index, INT32 data0, INT32 data1, UINT8 *pAcDspBufStr)
{
    return BspCallService(BSP_CMD_AC_GET_DPD_STR_AC_DSP_INFO, index, data0, data1, pAcDspBufStr);
}

UINT32 BspStartAcCalc(UINT32 chan)
{
    return BspCallService(BSP_CMD_START_AC_CALC, chan);
}

UINT32 BspGetVswrSta(UINT32 chan, UINT32 acType)
{
    return BspCallService(BSP_CMD_GET_VSWR_STA, chan, acType);
}

UINT32 BspClearDpd(UINT32 chan, UINT32 bandId)
{
    return BspCallService(BSP_CMD_CLEAR_DPD, chan, bandId);
}

UINT32 BspSetDpdParaMode(UINT32 chan, UINT32 bandId, INT32 modesel)
{
    return BspCallService(BSP_CMD_SET_DPD_PARA_MODE, chan, bandId, modesel);
}

UINT32 BspGetPimOnlineChkResult(T_DpdPimOnlineCheckResultAck *pimOnlineCheckRes)
{
    return BspCallService(BSP_CMD_GET_PIM_ONLINE_CHK_RESULT, pimOnlineCheckRes);
}

UINT32 BspDpdTsQuery(UINT32 para)
{
    return BspCallService(BSP_CMD_DPD_TS_QUERY, para);
}

UINT32 BspDpdSetPowAdjInfo(UINT32 chan, UINT32 bandId)
{
    return BspCallService(BSP_CMD_DPD_SET_POW_ADJ_INFO, chan, bandId);
}

UINT32 BspStartOnlinePim(UINT32 BspChn, UINT32 BandNo, UINT32 order, UINT32 Mode)
{
    return BspCallService(BSP_CMD_START_ONLINE_PIM, BspChn, BandNo, order, Mode);
}

UINT32 BspGetDpdPimState(UINT32 chan, UINT32 freqNo)
{
    return BspCallService(BSP_CMD_GET_DPD_PIM_STATE, chan, freqNo);
}

UINT32 BspGetDpdFixDlyStat(UINT32 chan)
{
    return BspCallService(BSP_CMD_GET_DPD_FIX_DLY_STAT, chan);
}

UINT32 BspDpdMsgSetFrameSlotCfg(UINT32 slotIndex, UINT32 gpNum)
{
    return BspCallService(BSP_CMD_DPD_MSG_SET_FRAME_SLOT_CFG, slotIndex, gpNum);
}

UINT32 BspStopDpd(UINT32 chan, UINT32 bandId)
{
    return BspCallService(BSP_CMD_STOP_DPD, chan, bandId);
}

UINT32 BspDpdTsCtrl(UINT32 para, UINT32 ctrl, UINT32 gpNum)
{
    return BspCallService(BSP_CMD_DPD_TS_CTRL, para, ctrl, gpNum);
}

UINT32 BspDpdUpdateRruInfo(UINT32 exceptType, UINT32 exceptMask)
{
    return BspCallService(BSP_CMD_DPD_UPDATE_RRU_INFO, exceptType, exceptMask);
}

UINT32 BspSetPaVolt(UINT32 index, INT32 volt)
{
    return BspCallService(BSP_CMD_SET_PA_VOLT, index, volt);
}

UINT32 BspGetPowerSupplyInsufficient(UINT32 *pStatus)
{
    return BspCallService(BSP_CMD_GET_POWER_SUPPLY_INSUFFICIENT, pStatus);
}

UINT32 BspGetPwrProtectInfo(UINT32 index, UINT32 ulInterChan, UINT32 *uiStatus)
{
    return BspCallService(BSP_CMD_GET_PWR_PROTECT_INFO, index, ulInterChan, uiStatus);
}

UINT32 BspPwrCutCheck(VOID)
{
    return BspCallService(BSP_CMD_PWR_CUT_CHECK);
}

UINT32 BspGetHighOverTempAlmStatus(UINT32 *pStatus)
{
    return BspCallService(BSP_CMD_GET_HIGH_OVER_TEMP_ALM_STATUS, pStatus);
}

UINT32 BspGetPwrCurr(UINT32 index, INT32 *pCurr)
{
    return BspCallService(BSP_CMD_GET_PWR_CURR, index, pCurr);
}

UINT32 BspGetVindownIsEffective(VOID)
{
    return BspCallService(BSP_CMD_GET_VINDOWN_IS_EFFECTIVE);
}

UINT32 BspGetBoardVinType(UINT32 index, UINT32 *type)
{
    return BspCallService(BSP_CMD_GET_BOARD_VIN_TYPE, index, type);
}

UINT32 BspGetBoardVolt(UINT32 index, INT32 *pVolt)
{
    return BspCallService(BSP_CMD_GET_BOARD_VOLT, index, pVolt);
}

UINT32 BspGetPwrTemp(UINT32 index, INT32 *pTemp)
{
    return BspCallService(BSP_CMD_GET_PWR_TEMP, index, pTemp);
}

UINT32 BspGetPwrVolt(UINT32 index, INT32 *pVolt)
{
    return BspCallService(BSP_CMD_GET_PWR_VOLT, index, pVolt);
}

INT32 BspGetPaVolt(UINT32 index)
{
    return BspCallService(BSP_CMD_GET_PA_VOLT, index);
}

UINT32 BspGetPowerStatus(VOID)
{
    return BspCallService(BSP_CMD_GET_POWER_STATUS);
}

UINT32 BspGetMonitorPwrVoltOut(UINT32 index, INT32 *pVolt)
{
    return BspCallService(BSP_CMD_GET_MONITOR_PWR_VOLT_OUT, index, pVolt);
}

UINT32 BspCtrlPm(UINT32 index, UINT32 cmd)
{
    return BspCallService(BSP_CMD_CTRL_PM, index, cmd);
}

UINT32 BspGetRruConsumedPower(UINT32 index, INT32 *pPower)
{
    return BspCallService(BSP_CMD_GET_RRU_CONSUMED_POWER, index, pPower);
}

UINT32 BspGetModuleStatus(UINT32 ulModuleId, UINT32 *pulModuleStatus)
{
    return BspCallService(BSP_CMD_GET_MODULE_STATUS, ulModuleId, pulModuleStatus);
}

UINT32 BspGetUartSelected(UINT32 index)
{
    return BspCallService(BSP_CMD_GET_UART_SELECTED, index);
}

UINT32 BspGetAisgNsbtControlNum(VOID)
{
    return BspCallService(BSP_CMD_GET_AISG_NSBT_CONTROL_NUM);
}

UINT32 BspSetUartSelected(UINT32 index, UINT32 type)
{
    return BspCallService(BSP_CMD_SET_UART_SELECTED, index, type);
}

UINT32 BspUartSend(UINT32 index, UINT8 *buf, UINT32 len)
{
    return BspCallService(BSP_CMD_UART_SEND, index, buf, len);
}

UINT32 BspUartRecv(UINT32 index, UINT8 *buf, UINT32 len)
{
    return BspCallService(BSP_CMD_UART_RECV, index, buf, len);
}

UINT32 BspGetExternalDryContactStatus(T_RruDryContactInfo *pInfo)
{
    return BspCallService(BSP_CMD_GET_EXTERNAL_DRY_CONTACT_STATUS, pInfo);
}

UINT32 BspMonSend(UINT8 *buf, UINT32 len)
{
    return BspCallService(BSP_CMD_MON_SEND, buf, len);
}

UINT32 BspSetAisgVolt(UINT32 devIndex, UINT32 pwrVoltType)
{
    return BspCallService(BSP_CMD_SET_AISG_VOLT, devIndex, pwrVoltType);
}

UINT32 BspFanSend(UINT8 *buf, UINT32 len)
{
    return BspCallService(BSP_CMD_FAN_SEND, buf, len);
}

UINT32 BspGetAisgVolt(UINT32 devIndex)
{
    return BspCallService(BSP_CMD_GET_AISG_VOLT, devIndex);
}

UINT32 BspSetAisgPwrStatus(UINT32 devIndex, UINT32 isOn)
{
    return BspCallService(BSP_CMD_SET_AISG_PWR_STATUS, devIndex, isOn);
}

VOID BspEmbFunctionEnable(UINT32 ulIndex)
{
    BspCallService(BSP_CMD_EMB_FUNCTION_ENABLE, ulIndex);
    return;
}

UINT32 BspGetAisgPwrStatus(UINT32 devIndex)
{
    return BspCallService(BSP_CMD_GET_AISG_PWR_STATUS, devIndex);
}

UINT32 BspMonRecv(UINT8 *buf, UINT32 len)
{
    return BspCallService(BSP_CMD_MON_RECV, buf, len);
}

UINT32 BspGetPwrShortAlarm(UINT32 ulIndex, BYTE *ulStatus)
{
    return BspCallService(BSP_CMD_GET_PWR_SHORT_ALARM, ulIndex, ulStatus);
}

UINT32 BspAisgSetVoltRange(UINT32 devIndex)
{
    return BspCallService(BSP_CMD_AISG_SET_VOLT_RANGE, devIndex);
}

UINT32 BspGetRxScanData(UINT32 count, T_RxScan *pRxScanData)
{
    return BspCallService(BSP_CMD_GET_RX_SCAN_DATA, count, pRxScanData);
}

UINT32 BspRxScanParaReInit(VOID)
{
    return BspCallService(BSP_CMD_RX_SCAN_PARA_RE_INIT);
}

UINT32 BspGetRxScanFreq(UINT32 bspRxChn, UINT32 *pStartFreq, UINT32 *pStopFreq, UINT32 *pStep)
{
    return BspCallService(BSP_CMD_GET_RX_SCAN_FREQ, bspRxChn, pStartFreq, pStopFreq, pStep);
}

UINT32 BspRxScanCal(UINT32 bspRxChn, UINT32 band, UINT32 antStat, UINT32 cellStat)
{
    return BspCallService(BSP_CMD_RX_SCAN_CAL, bspRxChn, band, antStat, cellStat);
}

UINT32 BspRxScanSample(UINT32 bspRxChn, UINT32 band)
{
    return BspCallService(BSP_CMD_RX_SCAN_SAMPLE, bspRxChn, band);
}

UINT32 BspRestRxScanData(VOID)
{
    return BspCallService(BSP_CMD_REST_RX_SCAN_DATA);
}

UINT32 BspRxScanDpdStatus(UINT32 bspRxChn, UINT32 bspTxChn, UINT32 * pDpdFlag)
{
    return BspCallService(BSP_CMD_RX_SCAN_DPD_STATUS, bspRxChn, bspTxChn, pDpdFlag);
}

UINT32 BspGetVswrTao(UINT32 ulTxChan, T_VswrTaoInfo *pVswrTao)
{
    return BspCallService(BSP_CMD_GET_VSWR_TAO, ulTxChan, pVswrTao);
}

UINT32 BspStartOnlineVswr(UINT32 rfChan, UINT32 bandId, T_VswrPosCalcPara para)
{
    return BspCallService(BSP_CMD_START_ONLINE_VSWR, rfChan, bandId, &para);
}

UINT32 BspGetOnlineVswrStatus(UINT32 rfChan, UINT32 bandId, UINT32 *state)
{
    return BspCallService(BSP_CMD_GET_ONLINE_VSWR_STATUS, rfChan, bandId, state);
}

UINT32 BspGetAveragePhase(UINT32 rfChan, UINT32 bandid, INT32 *value)
{
    return BspCallService(BSP_CMD_GET_AVERAGE_PHASE, rfChan, bandid, value);
}

UINT32 BspGetCarrSwitch(UINT32 chan, UINT32 radio, UINT32 carr, UINT32 trx, UINT32 *isOn)
{
    return BspCallService(BSP_CMD_GET_CARR_SWITCH, chan, radio, carr, trx, isOn);
}

UINT32 BspSetRfFpgaBitmap(UINT32 carrNo, UINT32 radioMode, UINT32 isON)
{
    return BspCallService(BSP_CMD_SET_RF_FPGA_BITMAP, carrNo, radioMode, isON);
}

UINT32 BspSetFftaPara(T_CellFftaPara *ptInfo)
{
    return BspCallService(BSP_CMD_SET_FFTA_PARA, ptInfo);
}

UINT32 BspSetIfBbPrachPara(T_IfBbPrachPara *ifBbPrachPara)
{
    return BspCallService(BSP_CMD_SET_IF_BB_PRACH_PARA, ifBbPrachPara);
}

UINT32 BspSetIfBbPrachParaV2(T_IfBbPrachParaV2 *ifBbPrachParaV2)
{
    return BspCallService(BSP_CMD_SET_IF_BB_PRACH_PARA_V2, ifBbPrachParaV2);
}

UINT32 BspSetErsScale(UINT32 ulCarrNo, INT32 lCellReRefPwr, UINT32 ulBandWith, UINT32 ulRbNum)
{
    return BspCallService(BSP_CMD_SET_ERS_SCALE, ulCarrNo, lCellReRefPwr, ulBandWith, ulRbNum);
}

UINT32 BspSetPrachPara(T_CellPrachPara *ptInfo)
{
    return BspCallService(BSP_CMD_SET_PRACH_PARA, ptInfo);
}

UINT32 BspSetGapSymbolNum(UINT32 gapNum)
{
    return BspCallService(BSP_CMD_SET_GAP_SYMBOL_NUM, gapNum);
}

UINT32 BspSetRepeatPeriod(UINT32 periodType)
{
    return BspCallService(BSP_CMD_SET_REPEAT_PERIOD, periodType);
}

UINT32 BspSetCarrSwitch(UINT32 chan, UINT32 radio, UINT32 carr, UINT32 trx, UINT32 isOn)
{
    return BspCallService(BSP_CMD_SET_CARR_SWITCH, chan, radio, carr, trx, isOn);
}

UINT32 BspSetSrsSymbolNum(UINT32 srsNum)
{
    return BspCallService(BSP_CMD_SET_SRS_SYMBOL_NUM, srsNum);
}

UINT32 BspSetUlTddSel(UINT32 bspChan)
{
    return BspCallService(BSP_CMD_SET_UL_TDD_SEL, bspChan);
}

UINT32 BspSetDlTddSel(UINT32 bspChan)
{
    return BspCallService(BSP_CMD_SET_DL_TDD_SEL, bspChan);
}

UINT32 BspOptSetSpectrumShare(UINT32 cellId, UINT32 specShare)
{
    return BspCallService(BSP_CMD_OPT_SET_SPECTRUM_SHARE, cellId, specShare);
}

/* 此接口高层直接调用IC接口，这里做处理：在ichaladapt_ic4_2模块中对HalSampleDlCfr1再封装一层BspHalAdaptSampleDlCfr1
   然后在bspapi内依然提供HalSampleDlCfr1这个原接口，并且使用统一接口调用的时候去调用BspHalAdaptSampleDlCfr1，杜绝对IC
   接口的直接调用 */
UINT32 HalSampleDlCfr1(UINT32 uiDifChan, UINT32 uiPosSel)
{
    return BspCallService(BSP_CMD_HAL_ADAPT_SAMPLE_DL_CFR1, uiDifChan, uiPosSel);
}

T_RruForm BspGetRruForm(UINT32 bandNo)
{
    return BspCallService(BSP_CMD_GET_RRU_FORM, bandNo);
}

UINT32 BspGetRruAbilityInfo(UINT32 fuIndex, VOID *pRruChlAbilityFuInfo, UINT32 dataLen)
{
    return BspCallService(BSP_CMD_GET_RRU_ABILITY_INFO, fuIndex, pRruChlAbilityFuInfo, dataLen);
}

UINT32 BspGetRruChlAbilityInfo(BYTE chan, BYTE dir, UINT32 fuIndex, VOID *pRruChlAbilityFuInfo, UINT32 dataLen)
{
    return BspCallService(BSP_CMD_GET_RRU_CHL_ABILITY_INFO, chan, dir, fuIndex, pRruChlAbilityFuInfo, dataLen);
}

UINT32 BspGetTopoCascadeNum(VOID)
{
    return BspCallService(BSP_CMD_GET_TOPO_CASCADE_NUM);
}

UINT32 BspGetDlDelayCmpAbility(VOID)
{
    return BspCallService(BSP_CMD_GET_DL_DELAY_CMP_ABILITY);
}

UINT32 BspGetFuRuIf1Abilty(VOID *pRruAbilityFuInfo, UINT32 dataLen)
{
    return BspCallService(BSP_CMD_GET_FU_RU_IF1_ABILTY, pRruAbilityFuInfo, dataLen);
}

UINT32 BspGetOptSpeedListAbility(T_OptSpeedList *ptSpeedList)
{
    return BspCallService(BSP_CMD_GET_OPT_SPEED_LIST_ABILITY, ptSpeedList);
}

UINT32 BspGetUlDelayCmpAbility(VOID)
{
    return BspCallService(BSP_CMD_GET_UL_DELAY_CMP_ABILITY);
}

UINT32 BspGetVswrValueIc(T_AcVswrValue *acVswrValue)
{
    return BspCallService(BSP_CMD_GET_VSWR_VALUE_IC, acVswrValue);
}

UINT32 BspSendAcStubData(UINT32 sw)
{
    return BspCallService(BSP_CMD_SEND_AC_STUB_DATA, sw);
}

UINT32 BspGetAcCarrInfo(UINT32 carrNo, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_AC_CARR_INFO, carrNo, radioMode);
}

UINT32 BspGetVswrSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 *length)
{
    return BspCallService(BSP_CMD_GET_VSWR_SEQ_IC, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length);
}

UINT32 BspSendAcWgt(UINT8 upDown, UINT32 carrNo, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_SEND_AC_WGT, upDown, carrNo, radioMode);
}

UINT32 BspStartVswrSeqCalcIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 seqType)
{
    return BspCallService(BSP_CMD_START_VSWR_SEQ_CALC_IC, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seqType);
}

UINT32 BspStartVswrWgtCalcIc(UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChan)
{
    return BspCallService(BSP_CMD_START_VSWR_WGT_CALC_IC, acType, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, refChan);
}

UINT32 BspRecvAcMsg(T_Pulm2CmacAntAdjustRsp *ptInfo)
{
    return BspCallService(BSP_CMD_RECV_AC_MSG, ptInfo);
}

UINT32 BspGetVswrDataCatchSta(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_VSWR_DATA_CATCH_STA, acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

UINT32 BspStartAcSeqCalcIc4(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 refChan, UINT32 preciseDlyFlag, INT32 freqNcoOffset)
{
    return BspCallService(BSP_CMD_START_AC_SEQ_CALC_IC4, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, refChan, preciseDlyFlag, freqNcoOffset);
}

UINT32 BspSetVswrParaIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChn, UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo)
{
    return BspCallService(BSP_CMD_SET_VSWR_PARA_IC, acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, refChn, frameNo, subframeNo, slotNo);
}

UINT32 BspSetVswrSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 length, UINT32 seqMode)
{
    return BspCallService(BSP_CMD_SET_VSWR_SEQ_IC, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length, seqMode);
}

UINT32 BspSetAcWgtIc(UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32 *data, UINT32 trxLength, UINT32 prachRxLength)
{
    return BspCallService(BSP_CMD_SET_AC_WGT_IC, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, data, trxLength, prachRxLength);
}

UINT32 BspGetVswrSyncTime(UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    return BspCallService(BSP_CMD_GET_VSWR_SYNC_TIME, acType, syncType, syncTime);
}

UINT32 BspInitAcDevPara(VOID)
{
    return BspCallService(BSP_CMD_INIT_AC_DEV_PARA);
}

UINT32 BspGetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32* syncTime)
{
    return BspCallService(BSP_CMD_GET_AC_SYNC_TIME, acType, syncType, syncTime);
}

UINT32 BspStartAcRecv(UINT16 upDown, UINT32 carrNo, UINT32 radioMode, UINT16 powerFactor)
{
    return BspCallService(BSP_CMD_START_AC_RECV, upDown, carrNo, radioMode, powerFactor);
}

UINT32 BspSendCaliChan(UINT32 caliChan)
{
    return BspCallService(BSP_CMD_SEND_CALI_CHAN, caliChan);
}

UINT32 BspGetAcDataCatchSta(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_AC_DATA_CATCH_STA, acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

UINT32 BspSetAcParaIc(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 acChnChgFlag, UINT32 radioMode, UINT32 referChnNo, UINT32 frameNo, UINT32 subframeNo, UINT32 slotNo)
{
    return BspCallService(BSP_CMD_SET_AC_PARA_IC, acType, carrNo, pasteCarrFlag, deviate, bandWidth, acChnChgFlag, radioMode, referChnNo, frameNo, subframeNo, slotNo);
}

UINT32 BspGetAcWgtIc(UINT32 socId, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 actype, UINT32 *data, UINT32 *trxLength, UINT32 *prachRxLength)
{
    return BspCallService(BSP_CMD_GET_AC_WGT_IC, socId, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, actype, data, trxLength, prachRxLength);
}

UINT32 BspSetAcSyncTime(UINT32 acType, UINT32 syncType, UINT32 syncTime, UINT32 bitMap)
{
    return BspCallService(BSP_CMD_SET_AC_SYNC_TIME, acType, syncType, syncTime, bitMap);
}

UINT32 BspSetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 length, UINT32 seqMode)
{
    return BspCallService(BSP_CMD_SET_AC_SEQ_IC, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length, seqMode);
}

UINT32 BspSendAcResult(UINT8 upDown, UINT32 carrNo, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_SEND_AC_RESULT, upDown, carrNo, radioMode);
}

UINT32 BspGetVswrCarrInfo(UINT32 carrNo, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_VSWR_CARR_INFO, carrNo, radioMode);
}

UINT32 BspSendAcCatchData(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_SEND_AC_CATCH_DATA, acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

UINT32 BspSendAcTddUlInslotCatchData(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_SEND_AC_TDD_UL_INSLOT_CATCH_DATA, acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

UINT32 BspGetAcRecvSta(UINT32 carrNo, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_AC_RECV_STA, carrNo, radioMode);
}

UINT32 BspStartAcWgtCalcIc(UINT32 acType, UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 refChan)
{
    return BspCallService(BSP_CMD_START_AC_WGT_CALC_IC, acType, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, refChan);
}

UINT32 BspStartAcSeqCalcIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType)
{
    return BspCallService(BSP_CMD_START_AC_SEQ_CALC_IC, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType);
}

UINT32 BspGetAcWgtResultIc(UINT32 acType, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 carr, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_AC_WGT_RESULT_IC, acType, pasteCarrFlag, deviate, bandWidth, sampleRate, carr, radioMode);
}

UINT32 BspGetAcSeqIc(UINT32 carr, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode, UINT32 acType, UINT32 *seq, UINT32 *length)
{
    return BspCallService(BSP_CMD_GET_AC_SEQ_IC, carr, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode, acType, seq, length);
}

UINT32 BspRecvAcMsgIc3(T_Pulm2CmacAntAdjustRspIc3* ptInfo)
{
    return BspCallService(BSP_CMD_RECV_AC_MSG_IC3, ptInfo);
}

UINT32 BspGetVswrRecvSta(UINT32 carrNo, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_VSWR_RECV_STA, carrNo, radioMode);
}

UINT32 BspFtmGetFrameNo()
{
    return BspCallService(BSP_CMD_FTM_GET_FRAME_NO);
}

UINT32 BspSendAcMsgIc3(T_Cmac2PulmAntAdjustScheInfoIc3* ptInfo)
{
    return BspCallService(BSP_CMD_SEND_AC_MSG_IC3, ptInfo);
}

UINT32 BspSendVswrCatchData(UINT32 acType, UINT32 carrNo, UINT32 pasteCarrFlag, UINT32 deviate, UINT32 bandWidth, UINT32 sampleRate, UINT32 radioMode)
{
    return BspCallService(BSP_CMD_SEND_VSWR_CATCH_DATA, acType, carrNo, pasteCarrFlag, deviate, bandWidth, sampleRate, radioMode);
}

UINT32 BspSendAcMsg(T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    return BspCallService(BSP_CMD_SEND_AC_MSG, ptInfo);
}

UINT32 BspGetAntAmpPhase(UINT32 ulPath, UINT32 ulCarrFreq, T_PauRelativeRec *ptData)
{
    return BspCallService(BSP_CMD_GET_ANT_AMP_PHASE, ulPath, ulCarrFreq, ptData);
}

UINT32 BspSetAcBcWgt(T_Cmac2PulmAntAdjustScheInfo *ptInfo)
{
    return BspCallService(BSP_CMD_SET_AC_BC_WGT, ptInfo);
}

UINT32 BspDirDataLoad(UINT32 index, UINT32 *dirData, UINT32 *dataLen)
{
    return BspCallService(BSP_CMD_DIR_DATA_LOAD, index, dirData, dataLen);
}

UINT32 BspSetAcBitMap(UINT32 sw)
{
    return BspCallService(BSP_CMD_SET_AC_BIT_MAP, sw);
}

UINT32 BspGetProWgt(UINT32 dir, UINT32 chanNo, UINT32 carrNo, UINT32 *pData, UINT32 *length)
{
    return BspCallService(BSP_CMD_GET_PRO_WGT, dir, chanNo, carrNo, pData, length);
}

UINT32 BspGetTsgFreRb(INT32 toneFreq)
{
    return BspCallService(BSP_CMD_GET_TSG_FRE_RB, toneFreq);
}

UINT32 BspGetAcIc4MeasInfo(UINT32 acType, T_BspAcIc4InfoDir *pAcInfo)
{
    return BspCallService(BSP_CMD_GET_AC_IC4_MEAS_INFO, acType, pAcInfo);
}

UINT32 BspGetPimcDpdSamplingRate(UINT32 bspChn, UINT32 *pDpdSamplingRate)
{
    return BspCallService(BSP_CMD_GET_PIMC_DPD_SAMPLING_RATE, bspChn, pDpdSamplingRate);
}

UINT32 BspGetPimcDpdFreOffset(UINT32 bspChn, INT32 *pDpdFreOffset)
{
    return BspCallService(BSP_CMD_GET_PIMC_DPD_FRE_OFFSET, bspChn, pDpdFreOffset);
}

UINT32 BspPimCheckFreq(UINT32 bspChn, UINT32 uFreq)
{
    return BspCallService(BSP_CMD_PIM_CHECK_FREQ, bspChn, uFreq);
}

UINT32 BspPimDataRead(UINT32 bspChn, UINT32 *pPimVal)
{
    return BspCallService(BSP_CMD_PIM_DATA_READ, bspChn, pPimVal);
}

UINT32 BspPimSwitch(UINT32 bspChn, UINT32 uSwitch)
{
    return BspCallService(BSP_CMD_PIM_SWITCH, bspChn, uSwitch);
}

UINT32 BspPimcStop(UINT32 bspChn, UINT32 bandId)
{
    return BspCallService(BSP_CMD_PIMC_STOP, bspChn, bandId);
}

UINT32 BspPimcStart(UINT32 bspChn, UINT32 bandId)
{
    return BspCallService(BSP_CMD_PIMC_START, bspChn, bandId);
}

UINT32 BspGNSSDrvStatusGet(UINT32 index, UINT32 radioMode, T_GNSS_RECEIVER_STATE *pGNSSRcvStatus)
{
    return BspCallService(BSP_CMD_GNSS_DRV_STATUS_GET, index, radioMode, pGNSSRcvStatus);
}

UINT32 BspGnssAlarmStatus(UINT32 index, T_GNSS_ALARM_STATUS *ptGnssAlarmStatus)
{
    return BspCallService(BSP_CMD_GNSS_ALARM_STATUS, index, ptGnssAlarmStatus);
}

UINT32 BspRegisterGnssCallback(UINT32 index, UINT32 radioMode, FUNC_BUF_CTRL pFunc)
{
    return BspCallService(BSP_CMD_REGISTER_GNSS_CALLBACK, index, radioMode, pFunc);
}

UINT32 BspConfigGnss(UINT32 radioMode, T_GNSS_PARA_CFG *ptGnssParaCfg)
{
    return BspCallService(BSP_CMD_CONFIG_GNSS, radioMode, ptGnssParaCfg);
}

INT32 BspPaProAlmRecover(UINT32 ulPaProAlmType, UINT64 u64EventAlmMask)
{
    return BspCallService(BSP_CMD_PA_PRO_ALM_RECOVER, ulPaProAlmType, u64EventAlmMask);
}

UINT32 BspGetPaProPastAlm(T_PaProInputParam *ptPaProParam, T_PaProFlagOutput *ptPaProOutput)
{
    return BspCallService(BSP_CMD_GET_PA_PRO_PAST_ALM, ptPaProParam, ptPaProOutput);
}

UINT32 BspRecoverLedCtrl()
{
    return BspCallService(BSP_CMD_RECOVER_LED_CTRL);
}

UINT32 BspDisableLedCtrl()
{
    return BspCallService(BSP_CMD_DISABLE_LED_CTRL);
}

UINT32 BspLedCtrl(UINT32 ledName, UINT32 operation)
{
    return BspCallService(BSP_CMD_LED_CTRL, ledName, operation);
}

UINT32 BspCheckLeakageWaterState(VOID)
{
    return BspCallService(BSP_CMD_CHECK_LEAKAGE_WATER_STATE);
}

unsigned long BspGetReservedMemAddr(UCHAR ucModuleId)
{
    ULONG reservedMemAddr = 0;

    BspCallService(BSP_CMD_GET_RESERVED_MEM_ADDR, ucModuleId, &reservedMemAddr);

    return reservedMemAddr;
}

UINT32 BspLoadAcHp(UINT32 ctrl)
{
    return BspCallService(BSP_CMD_LOAD_AC_HP, ctrl);
}

UINT32 BspLoadDspHp(UINT32 ctrl)
{
    return BspCallService(BSP_CMD_LOAD_DSP_HP, ctrl);
}

UINT32 BspGetCaliFileAlarmedString(UINT32 *pulAlarmed, INT8 *pucCaliFileString)
{
    return BspCallService(BSP_CMD_GET_CALI_FILE_ALARMED_STRING, pulAlarmed, pucCaliFileString);
}

UINT32 BspGetRfFpgaMaxTempResult(INT32 *lMaxTemp)
{
    return BspCallService(BSP_CMD_GET_RF_FPGA_MAX_TEMP_RESULT, lMaxTemp);
}

UINT32 BspGetDtxCounter(UINT32 ulRfChnl, UINT32 *pDtxCounter)
{
    return BspCallService(BSP_CMD_GET_DTX_COUNTER, ulRfChnl, pDtxCounter);
}

UINT32 BspStartAgcCtrl(VOID)
{
    return BspCallService(BSP_CMD_START_AGC_CTRL);
}

UINT32 BspGetDtxChkAbility(UINT32 radioMode)
{
    return BspCallService(BSP_CMD_GET_DTX_CHK_ABILITY, radioMode);
}

UINT32 BspGetDtxSwitch(UINT32 bspChan, UINT32 *sw)
{
    return BspCallService(BSP_CMD_GET_DTX_SWITCH, bspChan, sw);
}

UINT32 BspClrDtxCounter(UINT32 ulRfChnl)
{
    return BspCallService(BSP_CMD_CLR_DTX_COUNTER, ulRfChnl);
}

UINT32 BspSetDtxSwitch(UINT32 bspChan, UINT32 on)
{
    return BspCallService(BSP_CMD_SET_DTX_SWITCH, bspChan, on);
}

VOID BspSlaveBoardHwReset(UINT32 index)
{
    BspCallService(BSP_CMD_SLAVE_BOARD_HW_RESET, index);
    return;
}

UINT32 BspGetModuleGroupIdPara(VOID)
{
    return BspCallService(BSP_CMD_GET_MODULE_GROUP_ID_PARA);
}

UINT32 BspGetBoardGroupIdPara(VOID)
{
    return BspCallService(BSP_CMD_GET_BOARD_GROUP_ID_PARA);
}

UINT32 BspGetBoardTypeIdPara(VOID)
{
    return BspCallService(BSP_CMD_GET_BOARD_TYPE_ID_PARA);
}

UINT32 BspGetHardwareChangeIdPara(VOID)
{
    return BspCallService(BSP_CMD_GET_HARDWARE_CHANGE_ID_PARA);
}

UINT32 BspGetReservedMemSize(UINT8 moduleId)
{
    return BspCallService(BSP_CMD_GET_RESERVED_MEM_SIZE, moduleId);
}

UINT32 BspGetBoardResetType(VOID)
{
    return BspCallService(BSP_CMD_GET_BOARD_RESET_TYPE);
}

UINT32 BspCfgSecVerifyFun(VOID)
{
    return BspCallService(BSP_CMD_CFG_SEC_VERIFY_FUN);
}

UINT32 BspGetCpuType(UINT8 *cpuType)
{
    return BspCallService(BSP_CMD_GET_CPU_TYPE, cpuType);
}

UINT32 BspDeepSleepSw(UINT32 sw)
{
    return BspCallService(BSP_CMD_DEEP_SLEEP_SW, sw);
}

UINT32 BspBoardPreInit(VOID)
{
    return BspCallService(BSP_CMD_BOARD_PRE_INIT);
}

UINT32 BspBoardInit(VOID)
{
    return BspCallService(BSP_CMD_BOARD_INIT);
}

VOID ver(UINT32 flag)
{
    BspCallService(BSP_CMD_VER, flag);
    return;
}

UINT32 BspGetClkPllSysLd(UINT32 devId)
{
    return BspCallService(BSP_CMD_GET_CLK_PLL_SYS_LD, devId);
}

UINT32 BspGetClkPllSysLd3(UINT32 devId)
{
    return BspCallService(BSP_CMD_GET_CLK_PLL_SYS_LD3, devId);
}

UINT32 BspGetPrxAtt(UINT32 chn, INT32 *pVal)
{
    return BspCallService(BSP_CMD_GET_PRX_ATT, chn, pVal);
}

UINT32 BspGetClkPllSysLd4(UINT32 devId)
{
    return BspCallService(BSP_CMD_GET_CLK_PLL_SYS_LD4, devId);
}

UINT32 BspGetRxAtt(UINT32 chn, INT32 *pVal)
{
    return BspCallService(BSP_CMD_GET_RX_ATT, chn, pVal);
}

UINT32 BspGetClkPllSysLd2(UINT32 devId)
{
    return BspCallService(BSP_CMD_GET_CLK_PLL_SYS_LD2, devId);
}

VOID attshow(VOID)
{
    BspCallService(BSP_CMD_ATTSHOW);
    return;
}

int BspLoadModules(void)
{
    return BspCallService(BSP_CMD_LOAD_MODULES);
}

UINT32 BspGetWriteXmlToProtectEnable(void)
{
    return BspCallService(BSP_CMD_GET_WRITE_XML_TO_PROTECT_ENABLE);
}

UINT32 BspGetDspSoftVersion(CHAR *pcDspSoftVer, UCHAR ucSizeofBytes)
{
    return BspCallService(BSP_CMD_GET_DSP_SOFT_VERSION, pcDspSoftVer, ucSizeofBytes);
}

UINT32 BspGetModuleVerErrReason(UINT32 ulSoftType, T_CtrlVerErrReason *ptModuleErrReason)
{
    return BspCallService(BSP_CMD_GET_MODULE_VER_ERR_REASON, ulSoftType, ptModuleErrReason);
}

UINT32 FlushRuSwToProtect()
{
    return BspCallService(BSP_CMD_FLUSH_RU_SW_TO_PROTECT);
}

UINT32 BspGetVerProtectType(VOID)
{
    return BspCallService(BSP_CMD_GET_VER_PROTECT_TYPE);
}

UINT32 BspGetVerProtectAddr(VOID)
{
    return BspCallService(BSP_CMD_GET_VER_PROTECT_ADDR);
}

UINT32 BspGetCpuVerErrReason(T_CpuErrReason *ptCpuErrReason)
{
    return BspCallService(BSP_CMD_GET_CPU_VER_ERR_REASON, ptCpuErrReason);
}

UINT32 BspGetPackVerData(char *pcFileName, UINT32 ulVerOffset, T_VerFileHeader *ptVerHeader, BYTE *pbyImgBuf)
{
    return BspCallService(BSP_CMD_GET_PACK_VER_DATA, pcFileName, ulVerOffset, ptVerHeader, pbyImgBuf);
}

UINT32 BspGetFpgaLoadStatus(UINT32 ulIndex)
{
    return BspCallService(BSP_CMD_GET_FPGA_LOAD_STATUS, ulIndex);
}

BOOLEAN BspShowProtectFpgaVer(VOID)
{
    return BspCallService(BSP_CMD_SHOW_PROTECT_FPGA_VER);
}

BOOLEAN BspShowProtectCpuVer(VOID)
{
    return BspCallService(BSP_CMD_SHOW_PROTECT_CPU_VER);
}

UINT32 BspFlushProtectToFileSystem(VOID)
{
    return BspCallService(BSP_CMD_FLUSH_PROTECT_TO_FILE_SYSTEM);
}

UINT32 BspGetFlushSysVerToProFlag(INT32 *uJudgeFlag)
{
    return BspCallService(BSP_CMD_GET_FLUSH_SYS_VER_TO_PRO_FLAG, uJudgeFlag);
}

UINT32 BspGetCpuSoftVersion(CHAR *pcCpuSoftVer, UCHAR ucSizeofBytes)
{
    return BspCallService(BSP_CMD_GET_CPU_SOFT_VERSION, pcCpuSoftVer, ucSizeofBytes);
}

UINT32 BspGetFpgaVerErrReason(T_CtrlVerErrReason *ptFpgaErrReason)
{
    return BspCallService(BSP_CMD_GET_FPGA_VER_ERR_REASON, ptFpgaErrReason);
}

UINT32 BspGetVerProtectLen(VOID)
{
    return BspCallService(BSP_CMD_GET_VER_PROTECT_LEN);
}

UINT32 BspGetPackVerInfo(char *pcFileName, UINT32 ulVerIndex, UINT32 *pulVerOffset, T_VerFileHeader *ptVerHeader)
{
    return BspCallService(BSP_CMD_GET_PACK_VER_INFO, pcFileName, ulVerIndex, pulVerOffset, ptVerHeader);
}

UINT32 BspGetFpgaSoftVersion(CHAR *pcFpgaVer, UCHAR ucSizeofBytes)
{
    return BspCallService(BSP_CMD_GET_FPGA_SOFT_VERSION, pcFpgaVer, ucSizeofBytes);
}

UINT32 BspIsSupportFlashProtect(void)
{
    return BspCallService(BSP_CMD_IS_SUPPORT_FLASH_PROTECT);
}

UINT32 BspGetModuleSoftInfo(UINT32 ulSoftType, T_VER_INFO* ptVerInfo)
{
    return BspCallService(BSP_CMD_GET_MODULE_SOFT_INFO, ulSoftType, ptVerInfo);
}

UINT32 BspSetBootStartStep(WORD32 ulMode)
{
    return BspCallService(BSP_CMD_SET_BOOT_START_STEP, ulMode);
}

UINT32 BspGetFlashEraseSectorSize(VOID)
{
    return BspCallService(BSP_CMD_GET_FLASH_ERASE_SECTOR_SIZE);
}

UINT32 BspFlashRead(UINT32 ulOffset, UCHAR *pucBuff, UINT32 ulLen)
{
    return BspCallService(BSP_CMD_FLASH_READ, ulOffset, pucBuff, ulLen);
}

UINT32 BspGetBootVersion(CHAR *pcBootVer, UCHAR ucSizeofBytes)
{
    return BspCallService(BSP_CMD_GET_BOOT_VERSION, pcBootVer, ucSizeofBytes);
}

UINT32 BspBootLoad(UCHAR *pucLogicDataBuf, UINT32 ulBufLen)
{
    return BspCallService(BSP_CMD_BOOT_LOAD, pucLogicDataBuf, ulBufLen);
}

UINT32 BspGetSfpInfo(UCHAR ucOptId, T_RruSfpInfo *ptDiagCfg)
{
    return BspCallService(BSP_CMD_GET_SFP_INFO, ucOptId, ptDiagCfg);
}

UINT32 BspGetQsfpInfo(UCHAR ucOptId, T_RruQsfpInfo *ptDiagCfg)
{
    return BspCallService(BSP_CMD_GET_QSFP_INFO, ucOptId, ptDiagCfg);
}

UINT32 BspGetSfpSosSta(UCHAR ucOptId, T_OptSosInfo *ptStatus)
{
    return BspCallService(BSP_CMD_GET_SFP_SOS_STA, ucOptId, ptStatus);
}

UINT32 BspGetOptRxPowerAlarm(UINT32 ulOptId)
{
    return BspCallService(BSP_CMD_GET_OPT_RX_POWER_ALARM, ulOptId);
}

UINT32 BspGetOptTxPowerAlarm(UINT32 ulOptId)
{
    return BspCallService(BSP_CMD_GET_OPT_TX_POWER_ALARM, ulOptId);
}

UINT32 BspGetSfpMaximalUsedbleSpeed(UINT32 ulOptId)
{
    return BspCallService(BSP_CMD_GET_SFP_MAXIMAL_USEDBLE_SPEED, ulOptId);
}

UINT32 BspGetSfpProtocol(UINT32 optId)
{
    return BspCallService(BSP_CMD_GET_SFP_PROTOCOL, optId);
}

UINT32 BspGetOptSignalRateAlarm(UINT32 ulOptId)
{
    return BspCallService(BSP_CMD_GET_OPT_SIGNAL_RATE_ALARM, ulOptId);
}

UINT32 BspGetSfpDigiDiagInfo(UINT32 ulOptId, T_SfpDigiDiagInfo *ptDiagInfo)
{
    return BspCallService(BSP_CMD_GET_SFP_DIGI_DIAG_INFO, ulOptId, ptDiagInfo);
}

void BspPrintSfpInfo(UCHAR ucOptId)
{
    BspCallService(BSP_CMD_PRINT_SFP_INFO, ucOptId);
    return;
}

UINT32 BspGetSfpZteIdentity(UINT32 ucOptId, UINT32 *pStatus)
{
    return BspCallService(BSP_CMD_GET_SFP_ZTE_IDENTITY, ucOptId, pStatus);
}

UINT32 BspGetSfpCdrStatus(UINT32 optId, UINT8 *pStatus)
{
    return BspCallService(BSP_CMD_GET_SFP_CDR_STATUS, optId, pStatus);
}

UINT32 BspGetSfpInitStatus(UINT32 ulIndex)
{
    return BspCallService(BSP_CMD_GET_SFP_INIT_STATUS, ulIndex);
}

UINT32 BspMonUartRecv(UINT8 *buf, UINT32 len)
{
    return BspCallService(BSP_CMD_MON_UART_RECV, buf, len);
}

UINT32 BspGetMonRxStatus(VOID)
{
    return BspCallService(BSP_CMD_GET_MON_RX_STATUS);
}

UINT32 BspMonUartIoctl(UINT32 cmd, UINT32 para)
{
    return BspCallService(BSP_CMD_MON_UART_IOCTL, cmd, para);
}

UINT32 BspMonUartSend(UINT8 *buf, UINT32 len)
{
    return BspCallService(BSP_CMD_MON_UART_SEND, buf, len);
}

int LzmaGetHeaderInfo(unsigned char * srcbuf, unsigned long BufLength,T_lzma_header *ptLocalHeader)
{
    return BspCallService(BSP_CMD_LZMA_GET_HEADER_INFO, srcbuf, BufLength, ptLocalHeader);
}

INT BspSystem(const CHAR *pcCommand)
{
    return BspCallService(BSP_CMD_SYSTEM, pcCommand);
}

UINT32 BspGetPaVoltAdjustType(UINT32 ulIndex)
{
    return BspCallService(BSP_CMD_GET_PA_VOLT_ADJUST_TYPE, ulIndex);
}

static unsigned long long start_point_tmp = 0;
ULONG tickGetTmp()
{
    unsigned long long uptime;
    struct timespec t;
    t.tv_sec = 0;
    t.tv_nsec = 0;
    clock_gettime(CLOCK_MONOTONIC, &t);
    uptime = (unsigned long long)((unsigned long long)t.tv_sec*1000+(t.tv_nsec)/1000000);
    if(start_point_tmp==0)
        start_point_tmp=uptime;
    return (ULONG)(uptime - start_point_tmp);
}

UINT32 BspInstallSystemCallBack(BSP_SYSTEM_CALLBACK pfSystem)
{
    printf("%s start, ticks %d\n", __FUNCTION__, tickGetTmp());
    BspDynLibInit("bspservice.json");
    BspLoadModules();
    printf("%s end, ticks %d\n", __FUNCTION__, tickGetTmp());
    return BspCallService(BSP_CMD_INSTALL_SYSTEM_CALL_BACK, pfSystem);
}

ULONG RspDelayFuncInstall(ULONG (*pDelay10MsFunc)(USHORT ulDelayMs))
{
    return BspCallService(BSP_CMD_RSP_DELAY_FUNC_INSTALL, (pDelay10MsFunc));
}

void blockticksig(void)
{
    BspCallService(BSP_CMD_BLOCKTICKSIG);
    return;
}

void inet_ntoa_b(in_addr inetAddress, char *pString)
{
    BspCallService(BSP_CMD_INET_NTOA_B, &inetAddress, pString);
    return;
}

INT intLock(void)
{
    return BspCallService(BSP_CMD_INT_LOCK);
}

char *taskName(int tid)
{
    char *tastName = NULL;

    BspCallService(BSP_CMD_TASK_NAME, tid, (char **)&tastName);

    return tastName;
}

int intDisable(int irq)
{
    return BspCallService(BSP_CMD_INT_DISABLE, irq);
}

int taskIdListGet(int idList[], int maxTasks)
{
    return BspCallService(BSP_CMD_TASK_ID_LIST_GET, idList, maxTasks);
}

WIND_TCB *taskTcb(int tid)
{
    WIND_TCB *pTaskTcb = NULL;

    BspCallService(BSP_CMD_TASK_TCB, tid, (WIND_TCB **)&pTaskTcb);

    return pTaskTcb;
}

STATUS sysAuxClkRateSet(int ticksPerSecond)
{
    return BspCallService(BSP_CMD_SYS_AUX_CLK_RATE_SET, ticksPerSecond);
}

STATUS intConnect(VOIDFUNCPTR *vector, VOIDFUNCPTR routine, int parameter)
{
    return BspCallService(BSP_CMD_INT_CONNECT, vector, routine, parameter);
}

STATUS sysAuxClkConnect(FUNCPTR routine, int arg)
{
    return BspCallService(BSP_CMD_SYS_AUX_CLK_CONNECT, routine, arg);
}

VOID sysAuxClkEnable(VOID)
{
    BspCallService(BSP_CMD_SYS_AUX_CLK_ENABLE);
    return;
}

int taskSpawn(const char *name, int pri, int opts, int stksize,int (*funcptr) (int, int, int, int, int, int, int, int, int,int), int arg1, int arg2, int arg3, int arg4,int arg5, int arg6, int arg7, int arg8, int arg9, int arg10)
{
    return BspCallService(BSP_CMD_TASK_SPAWN, name, pri, opts, stksize, funcptr,  arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10);
}

ULONG tickGet()
{
    ULONG ulTickGet = 0;

    BspCallService(BSP_CMD_TICK_GET, &ulTickGet);

    return ulTickGet;
}

INT intUnlock(int LockKey)
{
    return BspCallService(BSP_CMD_INT_UNLOCK, LockKey);
}

int intEnable(int irq)
{
    return BspCallService(BSP_CMD_INT_ENABLE, irq);
}

STATUS taskDelay(int interval)
{
    return BspCallService(BSP_CMD_TASK_DELAY, interval);
}

int sysClkRateGet(void)
{
    return BspCallService(BSP_CMD_SYS_CLK_RATE_GET);
}

UINT32 BspNetDeviceClose(const char *eth)
{
    return BspCallService(BSP_CMD_NET_DEVICE_CLOSE, eth);
}

UINT32 BspNetDeviceOpen(const char *eth)
{
    return BspCallService(BSP_CMD_NET_DEVICE_OPEN, eth);
}

UINT32 BspThresholdNameToId(const char *pucThresholdName)
{
    return BspCallService(BSP_CMD_THRESHOLD_NAME_TO_ID, pucThresholdName);
}

UINT32 BspDevNameToId(const char *pucDevName)
{
    return BspCallService(BSP_CMD_DEV_NAME_TO_ID, pucDevName);
}

UINT32 BspGetCaliFileLoadString(UINT32 *pulAlarmed, INT8 *pucCaliFileString)
{
    return BspCallService(BSP_CMD_GET_CALI_FILE_LOAD_STRING, pulAlarmed, pucCaliFileString);
}

UINT32 BspGetRruPathDeratingPower(UINT32 ulTxChan, UINT32 *pValue)
{
    return BspCallService(BSP_CMD_GET_RRU_PATH_DERATING_POWER, ulTxChan, pValue);
}

UINT32 BspAdpGetRruPibNum(UINT32 *pValue)
{
    return BspCallService(BSP_CMD_ADP_GET_RRU_PIB_NUM, pValue);
}

UINT32 BspGetHardwareChangeId(VOID)
{
    return BspCallService(BSP_CMD_GET_HARDWARE_CHANGE_ID);
}

UINT32 BspGetPlusAndPlayVerRestrict(char *verRestrict, UINT32 bufLen)
{
    return BspCallService(BSP_CMD_GET_PLUS_AND_PLAY_VER_RESTRICT, verRestrict, bufLen);
}

UINT32 BspAdpGetRruPaNum(UINT32 *pValue)
{
    return BspCallService(BSP_CMD_ADP_GET_RRU_PA_NUM, pValue);
}

UINT32 BspGetRruInfo(UINT32 ulType, UINT32 index, T_BspDevInfo *ptDevInfo)
{
    return BspCallService(BSP_CMD_GET_RRU_INFO, ulType, index, ptDevInfo);
}

UINT32 BspGetModuleNumInfo(T_ModuleNumInfo *ptModuleNumInfo)
{
    return BspCallService(BSP_CMD_GET_MODULE_NUM_INFO, ptModuleNumInfo);
}

UINT32 BspGetModuleBarCodeInfo(UINT32 ulUnitIndex, UINT32 ulUnitType, CHAR *pBarInfo, UINT32 ulBarLen)
{
    return BspCallService(BSP_CMD_GET_MODULE_BAR_CODE_INFO, ulUnitIndex, ulUnitType, pBarInfo, ulBarLen);
}

UINT32 BspGetRruBoardType(VOID)
{
    return BspCallService(BSP_CMD_GET_RRU_BOARD_TYPE);
}

UINT32 BspGetPwrType(UINT32 pwrNo)
{
    return BspCallService(BSP_CMD_GET_PWR_TYPE, pwrNo);
}

UINT32 BspGetRfPllNum(T_BSP_RfPllNum *ptRfPllNum)
{
    return BspCallService(BSP_CMD_GET_RF_PLL_NUM, ptRfPllNum);
}

UINT32 BspGetModuleGroupId(VOID)
{
    return BspCallService(BSP_CMD_GET_MODULE_GROUP_ID);
}

UINT32 BspGetRruInventory(T_BspInventoryInfo *ptDevInfo)
{
    return BspCallService(BSP_CMD_GET_RRU_INVENTORY, ptDevInfo);
}

UINT32 BspGetFpgaVerSoftType(void)
{
    return BspCallService(BSP_CMD_GET_FPGA_VER_SOFT_TYPE);
}

UINT32 BspGetRxChanNum(VOID)
{
    return BspCallService(BSP_CMD_GET_RX_CHAN_NUM);
}

UINT32 BspGetTxChanNum(VOID)
{
    return BspCallService(BSP_CMD_GET_TX_CHAN_NUM);
}

UINT32 BspGetRruType(VOID)
{
    return BspCallService(BSP_CMD_GET_RRU_TYPE);
}

UINT32 BspSetPlusAndPlaySwid(UINT32 swId)
{
    return BspCallService(BSP_CMD_SET_PLUS_AND_PLAY_SWID, swId);
}

UINT32 BspGetBandValByCenterFreq(UINT32 bspchn, UINT32 dir, UINT32 Freq, UINT32 *freqBandType)
{
    return BspCallService(BSP_CMD_GET_BAND_VAL_BY_CENTER_FREQ, bspchn, dir, Freq, freqBandType);
}

UINT32 BspGetFpgaVerComparFlag(void)
{
    return BspCallService(BSP_CMD_GET_FPGA_VER_COMPAR_FLAG);
}

UINT32 BspSetExtraFilterCfg(UINT32 ulChannel, UINT32 ulBand, UINT32 ulDir, UINT32 ulStartFreqKHz, UINT32 ulEndFreqKHz)
{
    return BspCallService(BSP_CMD_SET_EXTRA_FILTER_CFG, ulChannel, ulBand, ulDir, ulStartFreqKHz, ulEndFreqKHz);
}

UINT32 BspGetAntNum(VOID)
{
    return BspCallService(BSP_CMD_GET_ANT_NUM);
}

UINT32 BspGetAauBarCodeId(UINT8* pCode)
{
    return BspCallService(BSP_CMD_GET_AAU_BAR_CODE_ID, pCode);
}

UINT32 BspGetOptNum(VOID)
{
    return BspCallService(BSP_CMD_GET_OPT_NUM);
}

UINT32 BspGetRruTypeInfo(UINT32 len, UINT8 *rruTypeStr)
{
    return BspCallService(BSP_CMD_GET_RRU_TYPE_INFO, len, rruTypeStr);
}

UINT32 BspGetVersionLoadType(void)
{
    return BspCallService(BSP_CMD_GET_VERSION_LOAD_TYPE);
}

UINT32 BspGetRpuNum()
{
    return BspCallService(BSP_CMD_GET_RPU_NUM);
}

UINT32 BspGetRruRfModuleInfoNew(UINT32 ulChannel, T_RruRfModuleInfoNew *ptRfModuleInfo)
{
    return BspCallService(BSP_CMD_GET_RRU_RF_MODULE_INFO_NEW, ulChannel, ptRfModuleInfo);
}

UINT32 BspGetBoardLgcType(VOID)
{
    return BspCallService(BSP_CMD_GET_BOARD_LGC_TYPE);
}

UINT32 BspGetPlusAndPlayEnable(void)
{
    return BspCallService(BSP_CMD_GET_PLUS_AND_PLAY_ENABLE);
}

UINT32 BspGetFreqBandNum(UINT32 uChan, UINT32 uDir, UINT32 freq)
{
    return BspCallService(BSP_CMD_GET_FREQ_BAND_NUM, uChan, uDir, freq);
}

UINT32 BspGetBandFreqRangeByCenterFreq(UINT32 dir, UINT32 freqBandType, UINT32 *startFreq, UINT32 *endFreq)
{
    return BspCallService(BSP_CMD_GET_BAND_FREQ_RANGE_BY_CENTER_FREQ, dir, freqBandType, startFreq, endFreq);
}

UINT32 BspIsSupportDeratingPow(VOID)
{
    return BspCallService(BSP_CMD_IS_SUPPORT_DERATING_POW);
}

UINT32 BspGetRruPathRatedPower(UINT32 ulTxChan, UINT32 *pValue )
{
    return BspCallService(BSP_CMD_GET_RRU_PATH_RATED_POWER, ulTxChan, pValue);
}

UINT32 BspGetRruAddInventory(T_BspAddInventoryInfo *ptAddAssetInfo)
{
    return BspCallService(BSP_CMD_GET_RRU_ADD_INVENTORY, ptAddAssetInfo);
}

UINT32 BspGetRruRfModuleInfo(UINT32 ulChannel, T_RruRfModuleInfo *ptRfModuleInfo)
{
    return BspCallService(BSP_CMD_GET_RRU_RF_MODULE_INFO, ulChannel, ptRfModuleInfo);
}

UINT32 BspAdpGetRruPwrNum(UINT32 *pValue)
{
    return BspCallService(BSP_CMD_ADP_GET_RRU_PWR_NUM, pValue);
}

UINT32 BspGetAAUPid(UINT32 *radarModel, UINT8 *pid)
{
    return BspCallService(BSP_CMD_GET_AAU_PID, radarModel, pid);
}

UINT32 BspGetDryctNum(VOID)
{
    return BspCallService(BSP_CMD_GET_DRYCT_NUM);
}

UINT32 BspGetBoardTypeId(VOID)
{
    return BspCallService(BSP_CMD_GET_BOARD_TYPE_ID);
}

UINT32 BspGetPlusAndPlaySwid(UINT32 *swId)
{
    return BspCallService(BSP_CMD_GET_PLUS_AND_PLAY_SWID, swId);
}

UINT32 BspAdpGetRruDflNum(UINT32 *pValue)
{
    return BspCallService(BSP_CMD_ADP_GET_RRU_DFL_NUM, pValue);
}

UINT32 BspSupportantiInterference(VOID)
{
    return BspCallService(BSP_CMD_SUPPORTANTI_INTERFERENCE);
}

UINT32 BspGetBoardGroupId(VOID)
{
    return BspCallService(BSP_CMD_GET_BOARD_GROUP_ID);
}

UINT32 BspGetRruAntRatedPower(UINT32 ulTxAnt, UINT32 *pValue)
{
    return BspCallService(BSP_CMD_GET_RRU_ANT_RATED_POWER, ulTxAnt, pValue);
}

UINT32 BspGetBoardInfo_16(T_HARDWARE_MODULE_INFO_16 *pBoardInfo)
{
    return BspCallService(BSP_CMD_GET_BOARD_INFO_16, pBoardInfo);
}

UINT32 BspGetSfpNum(VOID)
{
    return BspCallService(BSP_CMD_GET_SFP_NUM);
}

UINT32 BspCheckSystemVerSign(UCHAR *pucVerName, UINT32 ulCurTmp)
{
    return BspCallService(BSP_CMD_CHECK_SYSTEM_VER_SIGN, pucVerName, ulCurTmp);
}

#ifdef DYNAMIC_API_TEST
/* 以下为测试接口，新增功能接口请放在此行上边 */
UINT32 IcHalCpriSetFrTestMode(UINT32 ulLogOptNo, UINT32 ulTestMode)
{
    return BspCallService(BSP_CMD_IC_HAL_CPRI_SET_FR_TEST_MODE, ulLogOptNo, ulTestMode);
}

UINT32 BspUpdateTddCfg(UINT32 groupId)
{
    return BspCallService(BSP_CMD_UPDATE_TDD_CFG, groupId);
}

UINT32 BspHalAdaptSetFrSelect(UINT32 difChan, T_BspHalAdaptFrTypeCfg *pFrTypeCfg)
{
    return BspCallService(BSP_CMD_HAL_ADAPT_SET_FR_SELECT, difChan, pFrTypeCfg);
}

UINT32 IcHalApiOptTsgSwitch(UINT32 uAntChan, UINT32 uCarrNo, UINT32 uRadioMode, UINT32 uTsgType, UINT32 uSwitch)
{
    return BspCallService(BSP_CMD_IC_HAL_API_OPT_TSG_SWITCH, uAntChan, uCarrNo, uRadioMode, uTsgType, uSwitch);
}

UINT32 BspHalAdaptSetUlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw)
{
    return BspCallService(BSP_CMD_HAL_ADAPT_SET_UL_CARR_GAIN_SW, difChan, radioMode, carrIndex, sw);
}

UINT32 BspGetRxBspChanNum(VOID)
{
    return BspCallService(BSP_CMD_GET_RX_BSP_CMD_CHAN_NUM);
}

UINT32 BspResourceAllocClr(UINT32 dir)
{
    return BspCallService(BSP_CMD_RESOURCE_ALLOC_CLR, dir);
}

UINT32 IcHalCpriInternalLoopback(UINT32 ulLogOptNo, UINT32 ulSwitch)
{
    return BspCallService(BSP_CMD_IC_HAL_CPRI_INTERNAL_LOOPBACK, ulLogOptNo, ulSwitch);
}

UINT32 BspHalAdaptSetFrSelectByDir(UINT32 difChan, UINT32 dir)
{
    return BspCallService(BSP_CMD_HAL_ADAPT_SET_FR_SELECT_BY_DIR, difChan, dir);
}

UINT32 BspHalAdaptSetGsmCellInfo(T_GsmCellInfo *gsmCellInfo)
{
    return BspCallService(BSP_CMD_HAL_ADAPT_SET_GSM_CELL_INFO, gsmCellInfo);
}

UINT32 IcHalApiDCTsgCtrl(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiEn)
{
    return BspCallService(BSP_CMD_IC_HAL_API_D_C_TSG_CTRL, uiDifChan, uiCarrId, uiRadioMode, uiEn);
}

UINT32 BspHalAdaptPsyncCfg(UINT32 psyncMode)
{
    return BspCallService(BSP_CMD_HAL_ADAPT_PSYNC_CFG, psyncMode);
}

UINT32 BspUpdateCarrDelay(UINT32 bspChn)
{
    return BspCallService(BSP_CMD_UPDATE_CARR_DELAY, bspChn);
}

UINT32 BspGetTddSwitchResult(UINT32 groupId,UINT32 *result)
{
    return BspCallService(BSP_CMD_GET_TDD_SWITCH_RESULT, groupId, result);
}

UINT32 test_TddCfg(UINT32 groupId, UINT32 radioMode, UINT32 chanMask)
{
    return BspCallService(BSP_CMD_TEST__TDD_CFG, groupId, radioMode, chanMask);
}

UINT32 BspStubInit(VOID)
{
    return BspCallService(BSP_CMD_STUB_INIT);
}

UINT32 BspHalAdaptSetDlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw)
{
    return BspCallService(BSP_CMD_HAL_ADAPT_SET_DL_CARR_GAIN_SW, difChan, radioMode, carrIndex, sw);
}

UINT32 BspGetTxBspChanNum(VOID)
{
    return BspCallService(BSP_CMD_GET_TX_BSP_CMD_CHAN_NUM);
}

UINT32 Bsp_WfsAddCellInfo(UINT32 cellId,UINT32 carrNo, UINT32 radioMode, UINT32 bandWidth, UINT32 txFreq, UINT32 rxFreq, UINT32 txChanMask,UINT32 rxChanMask)
{
    return BspCallService(BSP_CMD__WFS_ADD_CELL_INFO, cellId, carrNo, radioMode, bandWidth, txFreq, rxFreq, txChanMask, rxChanMask);
}

VOID Bsp_WfsCellBuild(UINT32 antMask)
{
    BspCallService(BSP_CMD__WFS_CELL_BUILD, antMask);
    return;
}

UINT32 temp(UINT8 *devIdName)
{
    return BspCallService(BSP_CMD_TEMP, devIdName);
}

INT32 mcucall(int chip, const char *fun, INT32 *pRet)
{
    return BspCallService(BSP_CMD_MCUCALL, chip, fun, pRet);
}

VOID showpagridvolt(UINT32 loopStart, UINT32 loopEnd, UINT32 chanStart, UINT32 chanEnd)
{
    BspCallService(BSP_CMD_SHOWPAGRIDVOLT, loopStart, loopEnd, chanStart, chanEnd);
    return;
}

int ushell_init()
{
    return BspCallService(BSP_CMD_USHELL_INIT);
}
#endif

#ifndef _BSPAPI_VER_H_
#define _BSPAPI_VER_H_

#define BSPAPI_VERSION_NUMBERS "1.0.0"

#endif

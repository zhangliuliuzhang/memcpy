/****************************************************************************
* 版权所有 (C)2002，深圳市中兴通讯股份有限公司。
*
* 文件名称：TodPlusPpsDrv.c
* 文件标识：
* 内容摘要：针对1pps+tod协议标准的解析函数
* 其他说明：
* 当前版本：1.0
* 作   者： 贾冉
* 完成日期：2010-9-6
*
* 修改记录1：
*        修改日期：2010-9-6
*        版 本 号：1.0
*        修 改 人：贾冉
*        修改内容：创建
* 修改记录1：
*        修改日期：
*        版 本 号：
*        修 改 人：
*        修改内容：
****************************************************************************/
/* pp1s+tod 方式目前AAU/RRU并没有实际使用，只是前期V5平台调试使用。暂定为冗余代码流程，将gnss_a,gnss_a_nr30文件夹下文件删除，放到common文件夹。
   后面如果有机型需要，在gnss模块搜索if(1==gucRef)将代码放开 */
#if 0
/* sys h */
#ifndef VOS_LINUX
#include "vxworks.h"       /*for standard define*/
#include "tasklib.h"       /*for task functions*/
#include "ticklib.h"
#include "intlib.h"
#include "loglib.h"
#include "semlib.h"
#include "msgqlib.h"
#endif
#include "stdio.h"
#include "time.h"
#include "string.h"
#include "math.h"

/* usr h */
#include "bsp.h"
#include "todplusppsdrv.h"
#include "gnss_gps.h"
#include "gnss_ublox.h"

/*----------------------------------------------------------------------------*
 *                                常量                                        *
 *----------------------------------------------------------------------------*/


/*----------------------------------------------------------------------------*
 *                                 宏                                         *
 *----------------------------------------------------------------------------*/
#define CHINA_MOBILE             (0) /* 中国移动 */
#define CHINA_TELECOM            (1) /* 中国电信 */
#define DEFAULT_UNICOM           (2) /* 其它通用运营商 */

#define FRAME_SEARCH_MAX_TIME    (50)
/* uart status */
#define PPS_TOD_UART_OK          (0)
#define PPS_TOD_UART_ERR         (1)
/*----------------------------------------------------------------------------*
 *                               数据类型                                     *
 *----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*
 *                               变量定义与声明                               *
 *----------------------------------------------------------------------------*/
static ULONG  gulPpsTodStateInfoUsedFlag = 0;
static ULONG  todppslog = 0;/* 打印开关 */
extern UCHAR gucRef;
/*----------------------------------------------------------------------------*
 *                               函数声明                                     *
 *----------------------------------------------------------------------------*/

ULONG PpsTodFrameGet(T_FpgaUartBuffer *pUartSwBuf, UCHAR * const pucFrameBuf,USHORT *pusFrameLen, UCHAR *pFrameMode);
ULONG PpsTodDecodeInfo(const UCHAR *pucPayload,USHORT usPayloadLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG PpsTodDecodeState(const UCHAR *pucPayload,USHORT usPayloadLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG PpsTodFrameProcess(const UCHAR *pucBuf,USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG PpsTodFrameDecode(T_GPS_RCV_DRV_DATA *pRcvDrvData, T_FpgaUartBuffer *ptGcmInput);
void  PpsTodMRtCallBack(ULONG ulStepIn10, T_GPS_RCV_DRV_DATA *pRcvDrvData, T_FpgaUartBuffer *ptGcmInput);
ULONG PpsTodCreateUsableInfo(T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG BspPpsTodRefStateUsedSet(ULONG ulUsedFlag);
ULONG BspPpsTodRefStateUsedGet(void);
ULONG BspGetPpsQl(T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG BspCheckPpsTraceState(T_GPS_RCV_DRV_DATA *pRcvDrvData);


VOID SetTodPpsLogFlag(ULONG flag)
{
    todppslog = flag;

}

/**************************************************************************
* 函数名称： ULONG UbxFrameGet(T_SAT_UART_BUF *pUartSwBuf,
*                           UCHAR * const pucFrameBuf, USHORT *pusFrameLen)
* 功能描述： 从fpga UART sw缓冲区获取1pps+tod帧
* 输入参数： pUartSwBuf:fpga UART sw缓冲区指针；
* 输出参数： pucFrameBuf：1pps+tod帧缓冲区指针；pusFrameLen：1pps+tod帧缓冲区有效数据长度；
*            pFrameMode:运营商标示
* 返 回 值： 成功： BSP_OK；
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 1pps+tod协议定义的帧结构如下：
* --------------------------------------------------------------------------------------------
* 字段名称  | SYNC CHAR | Message Class | Message ID | Payload Length | Payload | CK_A | CK_B |
* 字段长度  | 2 byte    | 1 byte        | 1 byte     | 2 byte         | variable|1 byte|1 byte|
* 字段内容  | 0X43,0X4D | X             | X          | X              | XXX...  | X    | X    |
* --------------------------------------------------------------------------------------------
* 修改日期     版本号     修改人         修改内容
* 2010-9-7     V1.0       jiaran           创建
**************************************************************************/
ULONG PpsTodFrameGet(T_FpgaUartBuffer *pUartSwBuf, UCHAR * const pucFrameBuf,
                     USHORT *pusFrameLen, UCHAR *pFrameMode)
{
    ULONG  i = 0;
    short  sPpsTodCursor = 0;
    USHORT usPayloadLen = 0;
    UCHAR  ucPayloadLenMsb = 0, ucPayloadLenLsb = 0;
    short  sPpsTodxFrameFoundLen = 0;
    UCHAR  aucCrcBuf[25] = {0};
    UCHAR  ucMsgCRC = 0;
    /* 0 入参检测 */
    if((NULL == pUartSwBuf)
    || (NULL == pucFrameBuf)
    || (NULL == pusFrameLen)
    || (NULL == pFrameMode))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 1 初始化 */
    *pusFrameLen = 0;

    /* 2 寻找帧 */
    /* 初始化游标 */
    sPpsTodCursor = pUartSwBuf->ulHead;
    /* 循环处理，每次只比较一个字节，如果找到整帧就拷贝到帧缓冲区 */
    while (sPpsTodCursor != pUartSwBuf->ulTail)
    {
        /* 状态机实现1pps+tod帧的查找 */
        if (0 == sPpsTodxFrameFoundLen) /* 如果不是在帧的内部找到0x43 */
        {
            if (0x43 == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]) /* 如果找到0x43 */
            {
                sPpsTodxFrameFoundLen = 1;
            }
            else
            {
                sPpsTodxFrameFoundLen = 0;
            }
        }
        else if (1 == sPpsTodxFrameFoundLen) /* 如果已经找到0x43 */
        {
            if (0x4D == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]) /* 如果又找到0x4D */
            {
                sPpsTodxFrameFoundLen = 2;
                *pFrameMode = CHINA_MOBILE; /* 中国移动标准 */
            }
            else if(0x4E == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]) /* 或者又找到0x54 */
            {
                sPpsTodxFrameFoundLen = 2;
                *pFrameMode = DEFAULT_UNICOM;/* 其它通用运营商 */
            }
            else if(0x54 == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]) /* 或者又找到0x54 */
            {
                sPpsTodxFrameFoundLen = 2;
                *pFrameMode = CHINA_TELECOM;/* 中国电信标准 */
            }
            else /* 如果没找到0x4D或者0x54，回退，从该位置重新找0x43 */
            {
                sPpsTodxFrameFoundLen = 0;
                sPpsTodCursor--;
                sPpsTodCursor = (sPpsTodCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
            }
        }
        else if (2 == sPpsTodxFrameFoundLen) /* 如果游标处于message clase或者message ID,则继续向下找 */
        {
            if (0x01 == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]) /* 如果又找到0x01 */
            {
                sPpsTodxFrameFoundLen = 3;
                aucCrcBuf[0] = pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE];
            }
            else /* 如果没找到0x01，回退，从该位置重新找0x43 */
            {
                sPpsTodxFrameFoundLen = 0;
                sPpsTodCursor-= 2;
                sPpsTodCursor = (sPpsTodCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
            }
        }
        else if (3 == sPpsTodxFrameFoundLen)/* 如果游标处于message clase或者message ID,则继续向下找 */
        {
            if ((0x03 == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]) ||(0x20 == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]))/* 如果又找到0x01 */
            {
                sPpsTodxFrameFoundLen = 4;
                aucCrcBuf[1] = pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE];
            }
            else /* 如果没找到0x20/0x03，回退，从该位置重新找0x43 */
            {
                sPpsTodxFrameFoundLen = 0;
                sPpsTodCursor-= 3;
                sPpsTodCursor = (sPpsTodCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
            }
        }
        else if (4 == sPpsTodxFrameFoundLen)/* 大端模式，如果游标到达Payload Length的MSB */
        {
            ucPayloadLenMsb = pUartSwBuf->aucBuf[sPpsTodCursor];
            sPpsTodxFrameFoundLen = 5;
            aucCrcBuf[2] = pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE];
        }
        else if (5 == sPpsTodxFrameFoundLen)/* 如果游标到达Payload Length的LSB */
        {
            ucPayloadLenLsb = pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE];
            usPayloadLen = (((USHORT)ucPayloadLenMsb) << 8) + (USHORT)ucPayloadLenLsb;
            sPpsTodxFrameFoundLen = 6;
            aucCrcBuf[3] = pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE];
        }
        else if ((6 <= sPpsTodxFrameFoundLen) && ((usPayloadLen + 6) > sPpsTodxFrameFoundLen))/* 如果游标处于Payload中 */
        {
            if(25 > (sPpsTodxFrameFoundLen - 2))  /* 防止越界 */
            {
                aucCrcBuf[sPpsTodxFrameFoundLen - 2] = pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE];
                sPpsTodxFrameFoundLen++;
            }
        }
        else if ((usPayloadLen + 6) == sPpsTodxFrameFoundLen)/* 如果游标到达校验字节1 */
        {
            /* 游标继续下移，保证不会重复进入 */
            sPpsTodxFrameFoundLen = usPayloadLen + 7;
            /* 电文异常保护，避免引起出参错误 */
            if ((GCM_UART_QUEUE_SIZE - 8) <= usPayloadLen)
            {
                /* lUbxCursor回退，从0x43,0x4D/54后面紧跟的字节重新开始查找帧头 */
                sPpsTodCursor -= (usPayloadLen + 6);
                sPpsTodCursor = (sPpsTodCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                sPpsTodxFrameFoundLen = 0;
                PPS_PLUS_TOD_LOG("Pps Tod Frame Get: (GCM_UART_QUEUE_SIZE - 8) <= usPayloadLen\n");
                continue;
            }
            if(2 == todppslog)
            {
                PPS_PLUS_TOD_LOG("The CrcCheck data: ");
                for(i = 0; i < 20; i++)
                {
                    PPS_PLUS_TOD_LOG("%2x ", aucCrcBuf[i]);
                }
                PPS_PLUS_TOD_LOG("\n");
            }
            /* 对不包括帧头两个字节的其余数据进行校验 */
            ucMsgCRC = ClockCalcCRCChecksum(&(aucCrcBuf[0]), 20);
            if(ucMsgCRC == pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE])
            {
                /* 设置完整帧长（包括帧头和校验的长度），应为23 */
                *pusFrameLen = usPayloadLen + 7;

                /* 更新缓冲区头指针，下一次调用从此处开始 */
                pUartSwBuf->ulHead = (sPpsTodCursor + 1) % GCM_UART_QUEUE_SIZE;

                /* 将找到的一个完整帧拷贝到帧缓冲区，包括帧头和校验，从帧头开始 */
                sPpsTodCursor -= (usPayloadLen + 6);
                sPpsTodCursor = (sPpsTodCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1);
                /* copy包括帧头、消息头、负载，不包括校验的数据 */
                for(i = 0; i < usPayloadLen + 6; i++)
                {
                    pucFrameBuf[i] = pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE];
                    sPpsTodCursor++;
                    sPpsTodCursor &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                }
                return BSP_OK;
            }
            else
            {
                PPS_PLUS_TOD_LOG("Pps Tod Frame Data Get ok,But checksum crc = 0x%x, frame real = 0x%x,check Phy Medium.\n", ucMsgCRC, pUartSwBuf->aucBuf[sPpsTodCursor%FPGA_UART_QUEUE_SIZE]);
                /* 丢弃此帧数据并，更新缓冲区头指针，下一次调用从此处开始 */
                pUartSwBuf->ulHead = (sPpsTodCursor + 1) % GCM_UART_QUEUE_SIZE;
                return BSP_ERROR;
            }

        }
        else/* 如果不是帧内字段 */
        {
            sPpsTodxFrameFoundLen = 0;
        }
        /* 指向下一个字节 */
        sPpsTodCursor++;
        sPpsTodCursor &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
    } /* while(sPpsTodCursor != pUartSwBuf->ulTail) */

    return  BSP_ERROR;
}
/**************************************************************************
* 函数名称： PpsTodDecodeInfo
* 功能描述： 解析1pps+tod信息帧
* 输入参数： pucPayload：帧净负荷起始地址
*            usPayloadLen：净负荷的长度
* 输出参数： pRcvDrvData：结构体实例
* 返 回 值： BSP_OK：成功；其它：失败
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-9-7     V1.0       贾冉            创建
**************************************************************************/
extern UINT64 guiGpsSec;
extern void SetTime(UCHAR ucRef, UINT64 ullTime);
ULONG PpsTodDecodeInfo(const UCHAR *pucPayload,USHORT usPayloadLen,T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    UCHAR weekday = 0;
    USHORT DayOfTime = 0, temdays = 0, lastyeardays = 0, temyear = 1980;
    ULONG ulSecond, ulTmp;
    USHORT usGpsWeek = 0;
    ULONG ulCmpOkFlag = 0;
    T_Clock_Tod tLocalGpsDate;
    T_GPS_RCV_DRV_DATA *pDecodeInfoRcvData = NULL;
    /* 入参检测 */
    if ((NULL == pucPayload)
      ||(16 != usPayloadLen)
      ||(NULL == pRcvDrvData))
    {
        PPS_PLUS_TOD_LOG("PpsTodDecodeInfo input err，and usPayloadLen = %d.\n", usPayloadLen);
        return BSP_ERROR_NULL_POINTER;
    }
    /* prepare */
    memset(&tLocalGpsDate,0,sizeof(tLocalGpsDate));
    pDecodeInfoRcvData = pRcvDrvData;

    pDecodeInfoRcvData->ucLeapSeconds = pucPayload[10]; /* 闰秒信息 */
    pDecodeInfoRcvData->ucTacc = pucPayload[12];        /* pps抖动量级信息 */
    pDecodeInfoRcvData->ucPpsStatus = pucPayload[11];   /* 秒脉冲信息 */
    if(BSP_CLOCK_REF_1PPS_AND_TOD_BACKUP == pDecodeInfoRcvData->ulRcvPlace)
    {
        PPS_PLUS_TOD_LOG("S 1PPS+TOD: PpsStatus = %u. tick = %u.\n", pDecodeInfoRcvData->ucPpsStatus,tickGet());
    }
    else if(BSP_CLOCK_REF_1PPS_AND_TOD == pDecodeInfoRcvData->ulRcvPlace)
    {
        PPS_PLUS_TOD_LOG("M 1PPS+TOD: PpsStatus = %u. tick = %u.\n", pDecodeInfoRcvData->ucPpsStatus,tickGet());
    }
    else
    {
        /* do nothing */
    }
    /* 获取GPS SECOND */
    ulSecond = 0;
    ulSecond += (ULONG)(pucPayload[0]) << 24;
    ulSecond += (ULONG)(pucPayload[1]) << 16;
    ulSecond += (ULONG)(pucPayload[2]) << 8;
    ulSecond += pucPayload[3];
    /* 保存GPS WEEK */
    usGpsWeek = 0;
    usGpsWeek += (USHORT)(pucPayload[8]) << 8;
    usGpsWeek += pucPayload[9];

    /*计算到当前时间代表的秒数*/
    guiGpsSec = (UINT64)usGpsWeek * (UINT64)SEC_OF_WEEK + (UINT64)ulSecond;
    PPS_PLUS_TOD_LOG("sec=%llu; week=%u, secinweek=%u\n",guiGpsSec,usGpsWeek,ulSecond);
    if(1 == gucRef)
    {
        SetTime(1, guiGpsSec);
    }
    ulTmp = ulSecond / SEC_OF_DAY;
    weekday = (UCHAR)ulTmp; /*s到天，当前星期的天的浮点数*/

    ulSecond = ulSecond - ulTmp * SEC_OF_DAY;
    ulTmp = ulSecond / 3600;
    tLocalGpsDate.HOUR = (UCHAR)ulTmp;  /*得到当前时*/

    ulSecond = ulSecond - ulTmp * 3600;
    ulTmp = ulSecond / 60; /*分的浮点数*/
    tLocalGpsDate.MIN = (UCHAR)ulTmp;   /*得到当前分*/

    ulSecond = ulSecond - ulTmp * 60;
    ulTmp = ulSecond;
    tLocalGpsDate.SEC = (UCHAR)ulTmp;   /*得到当前秒*/

    DayOfTime = usGpsWeek * 7 + 5;/*1980年1月1号0时起*/
    DayOfTime = DayOfTime + weekday;/*计算出1980年到现在的总天数*/
    while(temdays <= DayOfTime)
    {
        lastyeardays = temdays; /*保存到上一年的总天数*/
        temdays = temdays + ClockCalcDaysInCertainYear(temyear);
        temyear++;
    }

    tLocalGpsDate.YEAR = temyear - 1;/*得到当前年*/
    tLocalGpsDate.DAYS = DayOfTime - lastyeardays; /*得到当前天*/

    ClockChangeDaysToMonDay(&tLocalGpsDate); /*得到当前月日数*/
    /* gps时间赋值给实例 */
    memcpy(&(pDecodeInfoRcvData->tGpsDate),&tLocalGpsDate,sizeof(tLocalGpsDate));
    ClockChangeDaysToMonDay(&(pDecodeInfoRcvData->tGpsDate)); /*得到驱动实例当前月日数*/
    /* 为打印信息增加对M S的区分 */
    if(BSP_CLOCK_REF_1PPS_AND_TOD_BACKUP == pDecodeInfoRcvData->ulRcvPlace)
    {
        PPS_PLUS_TOD_LOG("Slave,");
    }
    else if(BSP_CLOCK_REF_1PPS_AND_TOD == pDecodeInfoRcvData->ulRcvPlace)
    {
        PPS_PLUS_TOD_LOG("Master,");
    }
    else
    {
        /* do nothing */
    }
    /* 比较电文tod和驱动本地维护tod时间是否差1 */
    ClockIncrementTime(&(pDecodeInfoRcvData->tLastGpsDate));/* 驱动本地维护tod更新 */
    ClockChangeDaysToMonDay(&(pDecodeInfoRcvData->tLastGpsDate)); /*得到当前月日数*/
    /* 判断电文解析的tod是否是累加1 */
    if((pDecodeInfoRcvData->tLastGpsDate.YEAR == pDecodeInfoRcvData->tGpsDate.YEAR)
     &&(pDecodeInfoRcvData->tLastGpsDate.DAYS == pDecodeInfoRcvData->tGpsDate.DAYS)
     &&(pDecodeInfoRcvData->tLastGpsDate.HOUR == pDecodeInfoRcvData->tGpsDate.HOUR)
     &&(pDecodeInfoRcvData->tLastGpsDate.MIN  == pDecodeInfoRcvData->tGpsDate.MIN)
     &&(pDecodeInfoRcvData->tLastGpsDate.SEC  == pDecodeInfoRcvData->tGpsDate.SEC))
    {
        ulCmpOkFlag = 1;
    }
    else
    {
        pDecodeInfoRcvData->ulSatTodAbnormalTimes++;/* 统计tod跳秒次数 */
        PPS_PLUS_TOD_LOG("1pp+tod rcv appear jump tod,check it.\n");
        PPS_PLUS_TOD_LOG("1PPS+TOD: %d-%d-%d | %d:%d:%d. (last time)\n",
                         pDecodeInfoRcvData->tLastGpsDate.YEAR,
                         pDecodeInfoRcvData->tLastGpsDate.MON,
                         pDecodeInfoRcvData->tLastGpsDate.DAY,
                         pDecodeInfoRcvData->tLastGpsDate.HOUR,
                         pDecodeInfoRcvData->tLastGpsDate.MIN,
                         pDecodeInfoRcvData->tLastGpsDate.SEC);
        PPS_PLUS_TOD_LOG("1PPS+TOD: %d-%d-%d | %d:%d:%d. (cur time)\n",
                         pDecodeInfoRcvData->tGpsDate.YEAR,
                         pDecodeInfoRcvData->tGpsDate.MON,
                         pDecodeInfoRcvData->tGpsDate.DAY,
                         pDecodeInfoRcvData->tGpsDate.HOUR,
                         pDecodeInfoRcvData->tGpsDate.MIN,
                         pDecodeInfoRcvData->tGpsDate.SEC);
    }

    /* 电文解析的tod是连续增长的*/
    if(1 == ulCmpOkFlag)
    {
        pDecodeInfoRcvData->ulRcvTodOkCnt++;
        if(100 <= pDecodeInfoRcvData->ulRcvTodOkCnt)
        {
           pDecodeInfoRcvData->ulRcvTodOkCnt = 100;/* 防止计数变量溢出 */
        }
    }
    else
    {
        pDecodeInfoRcvData->ulRcvTodOkCnt = 0;
    }
    /* 计算驱动tod是否可用标志 */
    if(CLOCK_REF_BAD_TO_OK_LIMIT < pDecodeInfoRcvData->ulRcvTodOkCnt)
    {

        pDecodeInfoRcvData->ulRcvTodOkFlag = 1; /* 驱动解析tod可用 */
    }
    else
    {
        pDecodeInfoRcvData->ulRcvTodOkFlag = 0; /* 驱动解析tod不可用 */
    }
    /* 更新驱动本地维护时间 */
    memcpy(&(pDecodeInfoRcvData->tLastGpsDate),&tLocalGpsDate,sizeof(tLocalGpsDate));

    PPS_PLUS_TOD_LOG("1PPS+TOD: %u-%u-%u | %u:%u:%u. (gps time)\n",
                     tLocalGpsDate.YEAR, tLocalGpsDate.MON, tLocalGpsDate.DAY,
                     tLocalGpsDate.HOUR, tLocalGpsDate.MIN, tLocalGpsDate.SEC);
    if (1 == ulCmpOkFlag)
    {
        pDecodeInfoRcvData->ulRcvTodStas = TOD_RCV_OK;   /* TOD 正常*/
    }
    return BSP_OK;
}
/**************************************************************************
* 函数名称： PpsTodDecodeState
* 功能描述： 解析1pps+tod状态帧
* 输入参数： pucPayload：帧净负荷起始地址
*            usPayloadLen：净负荷的长度
* 输出参数： 无
* 返 回 值： BSP_OK：成功；其它：失败
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-9-7     V1.0       贾冉            创建
**************************************************************************/
ULONG PpsTodDecodeState(const UCHAR *pucPayload,USHORT usPayloadLen,T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    T_GPS_RCV_DRV_DATA *pDecodeStateRcvData = NULL;
    USHORT usTempVal;
    /* 入参检测 */
    if ((NULL == pucPayload)
      ||(16 != usPayloadLen)
      ||(NULL == pRcvDrvData))
    {
        PPS_PLUS_TOD_LOG("Pps Tod Decode State input err，and usPayloadLen = %d.\n", usPayloadLen);
        return BSP_ERROR_NULL_POINTER;
    }
    /* prepare */
    pDecodeStateRcvData = pRcvDrvData;
    /* 时钟源类型 */
    pDecodeStateRcvData->ucClkSrcType = pucPayload[0];
    /* 时钟源工作状态 */
    usTempVal = 0;
    usTempVal += (USHORT)(pucPayload[1]) << 8;
    usTempVal += pucPayload[2];
    pDecodeStateRcvData->ulRcvFixStatus = (ULONG)usTempVal;
    /* 为打印信息增加对M S的区分 */
    if(BSP_CLOCK_REF_1PPS_AND_TOD_BACKUP == pDecodeStateRcvData->ulRcvPlace)
    {
        PPS_PLUS_TOD_LOG("Slave,");
    }
    else if(BSP_CLOCK_REF_1PPS_AND_TOD == pDecodeStateRcvData->ulRcvPlace)
    {
        PPS_PLUS_TOD_LOG("Master,");
    }
    else
    {
        /* do nothing */
    }
    PPS_PLUS_TOD_LOG("1PPS+TOD: ClkSrcState = %d(fixed state).\n", pDecodeStateRcvData->ulRcvFixStatus);
    /* 监控告警，时钟源状态告警 */
    usTempVal = 0;
    usTempVal += (USHORT)(pucPayload[3]) << 8;
    usTempVal += pucPayload[4];
    pDecodeStateRcvData->usClkSrcAlarm = usTempVal;
    PPS_PLUS_TOD_LOG("1PPS+TOD: ClkSrcAlarm = %d.\n", pDecodeStateRcvData->usClkSrcAlarm);
    /* 其它保留字段暂不使用 */
    return BSP_OK;

}
/**************************************************************************
* 函数名称： PpsTodFrameProcess
* 功能描述： 解析1pps+tod帧
* 输入参数： pucBuf：帧起始地址，包括完整的帧头和校验
*            usFrameLen：包括帧头和校验的整个帧长
* 输出参数： pRcvDrvData：结构体实例
* 返 回 值： BSP_OK：成功；其它：失败。
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-9-7     V1.0       贾冉            创建
**************************************************************************/
ULONG PpsTodFrameProcess(const UCHAR *pucBuf,USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    UCHAR ucMsgClass = 0, ucMsgId = 0;
    const UCHAR *pucPayload = NULL; /* 数据载荷起始 */
    USHORT usPayloadLen = 0;
    ULONG ulRetVal = BSP_OK;
    T_GPS_RCV_DRV_DATA *pLocalTodFrameData = NULL;

    /* 入参保护 */
    if ((NULL == pucBuf) || (NULL == pRcvDrvData))
    {
        PPS_PLUS_TOD_LOG("PpsTodFrameProcess input err.\n");
        return BSP_ERROR_NULL_POINTER;
    }
    if(8 > usFrameLen)
    {
        return 0xff;
    }
    pLocalTodFrameData = pRcvDrvData;

    ucMsgClass = *(pucBuf + 2); /* 获取Message Class */
    ucMsgId    = *(pucBuf + 3); /* 获取Message ID */
    pLocalTodFrameData->ulRcvMsgStas = 1;   /* 接收到PPS+TOD  协议电文*/
    pucPayload = (UCHAR *)pucBuf + 6;/* 负载头是在帧头基础上加6，帧头、消息头、消息长度各占2个字节 */
    usPayloadLen = usFrameLen - 7; /* 减去帧头、消息头、帧长度、校验 = 7 */

    /* 根据Message Class和Message ID判断接收帧类型，并调用相应帧解析函数 */
    switch(ucMsgClass)
    {
        case 0x01: /* 1pps+tod帧Class */
        {
            switch(ucMsgId)
            {
                case 0x03: /* 帧状态消息帧 */
                {
                    if(BSP_OK != PpsTodDecodeState(pucPayload,usPayloadLen,pLocalTodFrameData))
                    {
                        PPS_PLUS_TOD_LOG("Pps Tod Decode Info return err.\n");
                    }
                    break;
                }
                case 0x20: /* 帧信息消息帧 */
                {
                    if(BSP_OK != PpsTodDecodeInfo(pucPayload,usPayloadLen,pLocalTodFrameData))
                    {
                        PPS_PLUS_TOD_LOG("Pps Tod Decode State return err.\n");
                    }
                    break;
                }
                default:
                {
                    break;
                }
            }
            break;
        }
        /* 扩展使用 */

        default:
            break;
    }
    return ulRetVal;
}
/**************************************************************************
* 函数名称： PpsTodFrameDecode
* 功能描述： 解析1pps+tod帧
* 输入参数： pRcvDrvData: 驱动结构体指针
* 输出参数： 无
* 返 回 值： BSP_OK：成功；其它：失败
* -----------------------------------------------------------------------
* 其它说明：初始化完成后，该返回值即没有意义
* 修改日期     版本号     修改人         修改内容
* 2010-9-7     V1.0       jiaran           创建
**************************************************************************/
ULONG PpsTodFrameDecode(T_GPS_RCV_DRV_DATA *pRcvDrvData, T_FpgaUartBuffer *ptGcmInput)
{
    UCHAR aucFrameBuf[GCM_UART_QUEUE_SIZE];
    USHORT usFrameLen = 0;
    ULONG ulFrameCnt = 0;
    ULONG ulTmpVal = BSP_ERROR;
    ULONG ulRetVal = BSP_ERROR;
    UCHAR ucFrameMode;

    /* 数据清零 */
    bzero(aucFrameBuf, sizeof(aucFrameBuf));

    /* 解析现存所有数据,循环次数要大于电文信息中最长帧的长度 */
    for(ulFrameCnt = 0; ulFrameCnt < FRAME_SEARCH_MAX_TIME; ulFrameCnt++)
    {
        /* 从sw缓冲区解析电文并比对 */
        ulTmpVal = PpsTodFrameGet(ptGcmInput, aucFrameBuf, &usFrameLen, &ucFrameMode);
        /* 没有完整帧表示当前缓冲区已经处理完 */
        if((BSP_OK != ulTmpVal) || (GCM_UART_QUEUE_SIZE <= usFrameLen))
        {
            break;
        }
        else /* 使用continue语句是因为需要解析完所有得到完整帧*/
        {
            pRcvDrvData->ucFrameMode = ucFrameMode;
            /* 帧处理，未获取到帧则不处理 */
            PpsTodFrameProcess(aucFrameBuf,usFrameLen,pRcvDrvData);
            ulRetVal = BSP_OK;
            continue;
        }
    }

    return ulRetVal;
}
/**************************************************************************
* 函数名称： PpsTodMRtCallBack
* 功能描述： 1pps+tod帧主解析处理函数
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK            成功
*            BSP_ERROR         失败
* -----------------------------------------------------------------------
* 其它说明：对外接口函数
*
* 修改日期     版本号     修改人         修改内容
* 2010-9-1     V1.0       贾冉            创建
**************************************************************************/
void PpsTodMRtCallBack(ULONG ulStepIn10, T_GPS_RCV_DRV_DATA *pRcvDrvData, T_FpgaUartBuffer *ptGcmInput)
{
    T_GPS_RCV_DRV_DATA *ptLocalRcvDrvData = NULL;

    /* 入参检查 */
    if(9 < ulStepIn10)
    {
        PPS_PLUS_TOD_LOG("PpsTodMRtCallBack input error,=%d.\n", ulStepIn10);
        return;
    }
    ptLocalRcvDrvData = pRcvDrvData;

    /* 将Buffer1(phy)的数据copy到Buffer2(sw)中,解析Buffer2(sw)中具体的数据 */
    if(BSP_OK != PpsTodFrameDecode(ptLocalRcvDrvData, ptGcmInput))
    {
        /**/
    }
    /* 1s更新一次状态 */
    if(5 == ulStepIn10)
    {
        /* 更新驱动对外综合状态 */
        if(BSP_OK != PpsTodCreateUsableInfo(ptLocalRcvDrvData))
        {
            PPS_PLUS_TOD_LOG("M Pps Tod Create Usable Info return err.\n");
        }

        /* 增加对1PPS+TOD分路合路配置检测 *
        ptLocalRcvDrvData->ucInputLineCfgStatus = g_tSatCallBack.pfuncLineCfgStatusGet(BSP_CLOCK_REF_1PPS_AND_TOD);
        * 非异常的情况下，通过不断更新当前时刻来实现故障时间的清0 *
        if((PPS_TOD_UART_OK != ptLocalRcvDrvData->ucGpsUartErr)
           || (3 < (BspCommonClkBookTimeGet() - ptLocalRcvDrvData->ulLastRcvTodOkTime)))
        {
            * uart口收不到电文且tod信息接收异常，则清除相关数据 *
            ptLocalRcvDrvData->ucPpsStatus = PPS_STATUS_NOT_OK;
            ptLocalRcvDrvData->usClkSrcAlarm = 0;
            ptLocalRcvDrvData->ulRcvFixStatus = SATELLITE_NOT_FIX;
            ptLocalRcvDrvData->ulRcvTodOkFlag = 0;
            PPS_PLUS_TOD_LOG("1pps+tod M Uart and Tod Get Abnorma,clear the Rcv data !\n");
        }
        if(10 <= (BspCommonClkBookTimeGet() - ptLocalRcvDrvData->ulLastRcvTodOkTime))
        {
            ptLocalRcvDrvData->ulTodStasErrFlag = 1;
        }
        else
        {
            ptLocalRcvDrvData->ulTodStasErrFlag = 0;
        }
        g_tSatCallBack.pFuncPp1sStatusGet(ptLocalRcvDrvData);*/
    }
    return;
}

/**************************************************************************
* 函数名称： PpsTodCreateUsableInfo
* 功能描述： 1pps+tod是否可用，提供给卫星类驱动框架
* 输入参数： 1pps+tod各种详细的状态信息(驱动实例结构体)
* 输出参数： 1pps+tod是否可用的总的标志，供卫星类驱动框架调用
* 返 回 值： BSP_OK: 获取信息成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-9-10   V1.0       jiaran          创建
**************************************************************************/
ULONG PpsTodCreateUsableInfo(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulLocalRcvInfo = 0;/* 驱动信息汇总 */
    T_GPS_RCV_DRV_DATA *pUsableInfoRcvData = NULL;

    /* 入参检测 */
    if(NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    pUsableInfoRcvData = pRcvDrvData;

    /* 若配置使能 */
    if(1 == BspPpsTodRefStateUsedGet())
    {
        /* BD/GPS使用 */
        if((PPS_TOD_BD_REF == pUsableInfoRcvData->ucClkSrcType)
        ||(PPS_TOD_GPS_REF == pUsableInfoRcvData->ucClkSrcType))
        {
            /* 有天馈开路、短路、锁定卫星为0告警 */
            if(0 != ((pUsableInfoRcvData->usClkSrcAlarm) & 0x000f))
            {
                ulLocalRcvInfo |= 0x00000004;
            }
            /* 不是3d Fix和time only Fix状态 */
            if((SATELLITE_3D_FIX != pUsableInfoRcvData->ulRcvFixStatus)
              &&(SATELLITE_TIME_ONLY_FIX != pUsableInfoRcvData->ulRcvFixStatus)
              )
            {
                ulLocalRcvInfo |= 0x00000008;
            }
        }
    }

    /* tod时间信息是否ok */
    if(TOD_RCV_ERR == pUsableInfoRcvData->ulRcvTodOkFlag)
    {
        ulLocalRcvInfo |= 0x00000020;
    }
    if(0 == ulLocalRcvInfo)
    {
        pUsableInfoRcvData->ulRcvUseableFlag = CLOCK_REF_USEABLE;
    }
    else
    {
        pUsableInfoRcvData->ulRcvUseableFlag = CLOCK_REF_UNUSEABLE;
    }
    PPS_PLUS_TOD_LOG("PpsTod Usable %u, details 0x%x\n",pUsableInfoRcvData->ulRcvUseableFlag, ulLocalRcvInfo);

    return ulRetVal;
}

/**************************************************************************
* 函数名称： BspPpsTodRefStateUsedSet
* 功能描述： 设置是否使能状态消息函数
* 输入参数： ulUsedFlag：0 = 不使用；1 = 使用；
* 输出参数： 无
* 返 回 值： BSP_OK;
*            BSP_ERROR;
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-10-28    V1.0         jiaran         创建
**************************************************************************/
ULONG BspPpsTodRefStateUsedSet(ULONG ulUsedFlag)
{
    gulPpsTodStateInfoUsedFlag = ulUsedFlag;
    return BSP_OK;
}
/**************************************************************************
* 函数名称： BspUniCasd1PpsTodStateUsedGet
* 功能描述： 获取是否使能状态消息函数
* 输入参数： 无
* 输出参数： 无
* 返 回 值： ulUsedFlag：0 = 不使用；1 = 使用；
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-10-28   V1.0         jiaran         创建
**************************************************************************/
ULONG BspPpsTodRefStateUsedGet(void)
{
    return gulPpsTodStateInfoUsedFlag;
}
#endif

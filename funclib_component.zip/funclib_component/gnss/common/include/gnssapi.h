/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : gnssapi.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了GNSS对外接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_GNSSAPI_H_
#define _FUNCLIB_GNSSAPI_H_



#ifdef __cplusplus
extern "C" {
#endif

typedef UINT32 (*FUNC_BUF_CTRL)(VOID *pBuf, UINT32 ulLenth);
typedef UINT32 (*FUNC_GPS_INT_MODE_CFG)(VOID);
typedef UINT32 (*FUNC_GPS_VER_CFG)(UINT32 *pulIntVer);
typedef UINT32 (*FUNC_GPS_PP1S_PHASE_RATE)(UINT32 *pulSampeRateHz);
typedef UINT32 (*FUNC_GPS_LOCAL_CLK_STA)(VOID);
typedef UINT32 (*FUNC_GPS_GET_FPGA_ID)(VOID);
typedef UINT32 (*FUNC_GPS_UART_INIT)(VOID);
typedef UINT32 (*FUNC_GPS_UART_BAUDRATE)(UINT32 ulBaudRate);
typedef UINT32 (*FUNC_GPS_SET_REF)(UINT32 flag);
typedef UINT32 (*FUNC_GPS_1PPS_SOURCE)(UINT32 sw);
typedef UINT32 (*FUNC_GPS_MCS_FLAG)(VOID);
#pragma pack(1)

typedef struct
{
    UINT8 ucRackNo;
    UINT8 ucGnssId; /* GPS ID号, 正常是0\1\2*/
    UINT8 ucGnssWorkMode; 
    UINT8 ucResv;
    INT32 lAntCabDelay;   /* 天馈线缆延时 */ 

    /* 单星授时功能相关 */
    UINT32 ulTimeMode;               /* auto mode or fix mode */
    DOUBLE dLongitude;              /* 经度，单位是度 */
    DOUBLE dLatitude;               /* 维度，单位是度 */
    DOUBLE dAltitude;               /* 高度，单位是米 */

    UINT32 ulLeastSatNum;           /* 最小开控、告警搜星数，参考源1，2，3，5时有效 */
	UINT32 ulRadioMode;             /* 新增：按位组合，LTE-TDD：0x20;5G:0x2000*/
    UINT32 ulAlmReportThre;         /* 20200310新增:告警上报时间,单位分钟,如果上报和恢复时间下发配置是0,则按默认10分钟 */
    UINT32 ulAlmRecoverThre;        /* 20200310新增:告警恢复时间,单位分钟,如果上报和恢复时间下发配置是0,则按默认5分钟 */
    UINT32 ulResv[10];
}T_GNSS_PARA_CFG;

typedef struct
{
    UINT8 ucGpsUartErr;             /* 接收机串口不通指示，0表示正常，1表示不通 */
    UINT8 ucGpsAntennaStatus;       /* 天馈状态。1:正常，126:初始化，127:未知，128:短路，129:开路， */
    UINT8 ucLockSatState;           /* 接收机搜星状态。0表示搜星成功，1表示正在搜星，2表示搜星失败 */
    UINT8 ucSatLost;               /* 卫星丢失状态，卫星丢失即锁定卫星数为0。0表示正常，1表示丢星 */
    UINT8 ucRefPpsStatus;           /* 参考源PP1S丢失告警，0表示正常，1表示参考PP1S丢失 *//* 该值从逻辑寄存器获取 */
} T_GNSS_ALARM_STATUS; 

typedef struct
{
    INT32 lLongitude; /* 单位: 1/3600000度 */
    INT32 lLatitude; /* 单位: 1/3600000度 */
    INT32 lAltitude; /* 单位: 厘米 */
}T_POSITION;

typedef struct
{
    UINT8  ucSatId;          /* 卫星号 SV ID (GPS: 1-32, SBAS 33-64 (33=PRN120))  */
    UINT8  ucSatType;        /* 卫星类型  */
    UINT8  ucElevation;      /* 仰角 Maximum 90  */
    USHORT usAzimuth;        /* 方位角 Range 0 to 359 */
    USHORT usCno;            /* 信噪比(强度, dbHz) Range 0 to 99, null when not tracking */
    UINT8  ucState;          /* 卫星状态，0--未可见，1--可见，2--锁定 */
}T_SAT_DETAILS;

typedef struct
{
    UINT8 ucGnssId;                /* Gnss ID */
    UINT8 ucRcvWorkMode;           /* 接收机配置工作模式，参考源为外置面板和外置背板时显示 */
    UINT8 ucGpsReceiverType;       /* 接收机类型。2:M12_Receiver,6:K161_Receiver,7:CRESCENT_Receiver,
                                                  8:TRIMBLE_Receiver,9:ublox,11:QUICK200,12:SigNav,
                                                  13:光口RGPS,15:RGB, */
    UINT8 ucGpsReceiverVersion;    /* 接收机版本。对ublox，4表示4T，5表示5T;对于QUICK200和SigNav，为0，暂不区分版本*/
    UINT8 ucGpsFixType;            /* 接收机定位类型。对于任何接收机，0:not fix,1:Dead Reckoning only,
                                      2:2D-Fix,3:3D-Fix,4:GPS + dead reckoning combined,5:Time only fix */
    UINT8 ucLockGpsSatNum;         /* 锁定的GPS卫星数 */
    UINT8 ucLockBDSatNum;          /* 锁定的北斗卫星数 */
    UINT8 ucLockGnsSatNum;         /* 锁定的GNS卫星数 */
    UINT8 ucGpsAntennaStatus;      /* 天馈状态。1:正常，126:初始化，127:未知，128:短路，129:开路， */
    UINT32 ulAntLeapTimes;          /* 天馈故障次数 */
    UINT8 ucGpsReceiverInitFinish; /* GPS接收机初始化是否成功。0表示成功，1表示失败 */
    UINT8 ucGpsInitStatus;         /* 接收机进入的初始化阶段 */
    UINT8 ucLockSatState;          /* 接收机搜星状态。0表示搜星成功，1表示正在搜星，2表示搜星失败 */
    UINT8 ucGpsUartErr;            /* 接收机串口不通指示，0表示正常，1表示不通 */
    UINT8 ulSatLostTimes;          /* 卫星丢失次数 */
    UINT32 ulPhaseValue;            /* 鉴相值，单位ns */
    UINT8 ucFrameMode;             /* 帧号属性，0x01:  CPRI(UMTS/LTE)
                                                0x02:  TD-SCDMA
                                                0x03:  GSM
                                                0x04:  其它  */
                                                
    UINT64 ullFrameNo;             /* 帧号 */
    T_POSITION tPosition;          /* 位置信息。0~3byte:经度；4~7byte:纬度；8~11byte:高度 */
    UINT8 aucRcvGpsTime[12];       /* GPS时间 */
    UINT8 aucRcvUtcTime[12];       /* UTC时间 */
    CHAR  cLeapSeconds;            /* 闰秒信息，GPS-UTC */

    T_SAT_DETAILS tSatDetails[64];      /* 可见卫星信息 */
}T_GNSS_RECEIVER_STATE;


UINT32 BspGetGnssId(UINT32 radioMode);
UINT32 BspConfigGnss(UINT32 radioMode, T_GNSS_PARA_CFG *ptGnssParaCfg);
UINT32 BspGnssAlarmStatus(UINT32 index, T_GNSS_ALARM_STATUS *ptGnssAlarmStatus);
UINT32 BspGNSSDrvStatusGet(UINT32 index,UINT32 radioMode,T_GNSS_RECEIVER_STATE *pGNSSRcvStatus);
UINT32 BspRegisterGnssCallback(UINT32 index, UINT32 radioMode, FUNC_BUF_CTRL pFunc);
UINT32 BspGpsVerCfgCallback(UINT32 index, FUNC_GPS_VER_CFG pFunc);
UINT32 BspGpsIntModeCfgCallback(UINT32 index, FUNC_GPS_INT_MODE_CFG pFunc);
UINT32 BspGpsPp1sPhaseRateCallback(UINT32 index, FUNC_GPS_PP1S_PHASE_RATE pFunc);
UINT32 BspGpsLocalClkStaCallback(UINT32 index, FUNC_GPS_LOCAL_CLK_STA pFunc);
UINT32 BspSetGpsFrOffset(UINT32 index, INT32 lDelayTOff);
UINT32 BspSetGpsFrameNoOffset(UINT32 index, INT32 lOffset);
UINT32 BspSetLteGnssValid(VOID);
UINT32 BspAasSend(UINT8 *buf, UINT32 len);
UINT32 BspAasRecv(UINT8 *data, UINT32 len);
UINT32 BspAasExist(VOID);
UINT32 BspAasModuleInit(VOID);

#pragma pack()



#ifdef __cplusplus
}
#endif
#endif 


/****************************************************************************
* 版权所有 (C)2002，深圳市中兴通讯股份有限公司。
*----------------------------------------------------------------------------
* 文件名称: UbloxReceiverDrv.c
* 文件标识:
* 内容摘要: Ublox接收机驱动
* 其他说明:
* 当前版本: 1.0
* 作    者: 罗焕发
* 完成日期: 2014-12-09
*----------------------------------------------------------------------------
* 修改记录1：
*     修改日期: 2014-12-09 16:45:07
*     版 本 号: 1.0
*     修 改 人: 罗焕发
*     修改内容: 从R8974移植过来
****************************************************************************/

#include <stdio.h>
#include <math.h>

#include "bsppub.h"
#include "bspcomm.h"
#include "vxadp.h"
#include "gnss_gps.h"
#include "gnss_ublox.h"
#include "time.h"
#include "exprn.h"
#include "funccommon.h"

#define UBLOX_ANT_CABLE_MAX_LEN       (8355)
#define UBLOX_ANT_CABLE_DELAY_UNIT    (5)   /* 时延5ns/m左右 */
#define UBLOX_ANT_CABLE_DEV_DELAY     (140)


#define UBLOX_FSEEK_CHECK(lFskRet)                                    \
    if (0 != lFskRet)                                               \
    {                                                               \
        dbgErr("%s:fseek failed!\n",__FUNCTION__);                  \
    }
#define UBLOX_FREAD_CHECK(iReadLen)                              \
    if (0 == iReadLen)                                                 \
    {                                                                \
        dbgErr("%s:fread failed!\n",__FUNCTION__);                    \
    }



/* 定义一个内置接收机驱动数据实例 */
volatile T_GPS_RCV_DRV_DATA *g_IntRcvDrvData = NULL;
T_FpgaUartBuffer    g_tUartIdentifyBuf;/* 接收机识别所用电文缓冲区 */
T_FpgaUartBuffer    g_tGcmUartPhyBuf;    /* GPS接收机物理侧缓冲区，供UART0的HOOK使用 */
T_FpgaUartBuffer    g_tGcmUartIdPhyBuf = {0};   /* GPS接收及物理侧缓冲区，供接收机识别使用*/

/* 定义框架操作函数_内置接收机 */
T_SAT_RCV_FUNC gSatIntRcvFunc;

T_FpgaUartBuffer    g_tGcmUartSwBuf = {0};/* GPS模块的输入输出缓冲区 */
UCHAR  g_ucIntGpsUartErr = 0;

unsigned long sulIntRcvTaskId = 0xFFFFFFFF;
ULONG sulSlaveRcvTaskId = 0xFFFFFFFF;
ULONG g_ulAgpsGetId = 0xFFFFFFFF;
ULONG g_ulAgpsSetId = 0xFFFFFFFF;

UINT32 s_ubloxAlmReportThre = SAT_REF_ALARM_LIMIT;
UINT32 s_ubloxAlmRecoverThre = SAT_REF_ALARM_RECOVER_LIMIT;



extern UCHAR g_aucUbxCmd[GNSS_CMD_MAX_NUM][GNSS_CMD_MAX_LEN];
extern T_GpsInfo g_GpsInfo;
extern T_GnssSndInfo tgnsssndInfo;
//coverity[cert_dcl60_cpp_violation:SUPPRESS]
extern FUNC_GPS_SEL_8T pGpsGetSel8tFunc;
/* 天馈故障次数统计变量 */
ULONG g_ulAntCheckPrn = 0;

T_BSP_SAT_ANT_POS gtSatAntPosInfo = {0};
ULONG gulSatRcvModeCfged = SATELLITE_AUTO_MODE;   /* 上层配置的接收机模式：1. normal, 2. fix. 3. selfManaged fix */

typedef ULONG(*UGpsFunPtr)(VOID);

/* 函数声明 */
ULONG UbloxRcvCreateUsableInfo(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG GpsReceiverReset(UCHAR ucResetMode, T_GPS_RCV_DRV_DATA *pRcvDrvData);

ULONG g_ulNormal = 0;
ULONG g_ulAbnormal = 0;

ULONG g_GpsInfoErr = 0;

ULONG gulUbxBaudRate = 9600;
UCHAR g_ucEphSatNum = 0;
UCHAR g_ucEphSatNumLast = 0;


T_UBX_CMD_PARA g_tUbxCmdPara[UBX_CFG_DATA_MAX];
T_Clock_Tod g_tAgpsInfoTime;
T_AGPS_INFO g_tAgpsInfo;


extern ULONG _BspSetUartIoCtrl(ULONG id, ULONG cmd, ULONG ctrl);

extern FUNC_GPS_UART_BAUDRATE pFuncGpsUartBaudRateCallBack;
extern FUNC_GPS_UART_INIT pFuncGpsUartInitCallBack;

/*******************************************************************************
 *                          ublox接收机驱动函数                                *
 ******************************************************************************/

ULONG ulGpsDbgPrnFlag = 0;

ULONG ctrlGpsPrnLevel(ULONG ulCtrl)
{
    ulGpsDbgPrnFlag = ulCtrl;
    return ulGpsDbgPrnFlag;
}


/******************************************************
* 函数名称：ULONG GetBookTime(void)
* 功能描述：获取单板运行时间，单位为s
* 输入参数：
* 输出参数：无
* 返 回 值：无
* 其他说明：顺序1
* 修改日期   版本号    修改人  修改内容
* ----------------------------------------------------
* 2007/05/08   V1.0       朱伟           移植到CBM
* 2008/01/08   V2.0       刘骏儒         移植到CC单板GPS模块
******************************************************/
ULONG GetBookTime(void)
{
    time_t rawtime;
    time_t ret;
    ret = time(&rawtime);
    TIME_CHECK(ret);
    //timeinfo = localtime ( &rawtime );
    //dbgInfo ( "/007The current date/time is: %s", asctime (timeinfo) );
    //dbgInfo("Second = %d\n", rawtime);
    return (UINT32)rawtime;
}

/**************************************************************************
* 函数名称： SatRefUpdateUartErrState
* 功能描述： 获取卫星类入参Id对应的uart通断情况维护
* 输入参数： 无
* 输出参数： 无
* 返 回 值： uart口通断状态
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-10-30   V1.0       贾冉            创建
**************************************************************************/
UCHAR SatRefUartErrState(ULONG ulBabyId)
{
    UCHAR ucSatRefUartErr = 0;

    ucSatRefUartErr = g_ucIntGpsUartErr;
    return ucSatRefUartErr;
}
/**************************************************************************
* 函数名称： UbloxRcvDrv
* 功能描述： UBLOX接收机维护任务。
* 输入参数： UBLOX接收机实例结构体
* 输出参数： 无
* 返 回 值： OK       成功
*            ERROR    失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-4-7     V1.0       SDRBSP            create
**************************************************************************/
ULONG UbloxRcvDrv(void)
{
#ifdef UT_FT_TEST
        return BSP_OK;
#endif

    if (0xFFFFFFFF == sulIntRcvTaskId)
    {
        sulIntRcvTaskId = (unsigned long)taskSpawn("[GPS]tUbxIntRcv", \
                                    80, /* priority */    \
                                    0x0008/*VX_FP_TASK,for linux*/, /* option,   */    \
                                    0x40000,/* stack size */ \
                                    (FUNCPTR)UbloxRcvTask, 0, 0, 0, 0, 0, 0, 0, 0 , 0, 0);
    }

    return BSP_OK;
}


/**************************************************************************
* 函数名称： ULONG GpsSatLostRecord(void)
* 功能描述： 统计卫星丢失次数、接收机锁定状态、以及B类故障接收机相关触发收集
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK
* -----------------------------------------------------------------------
* 其它说明：其中的B类故障这里只是收集接收机相关，卫星框架要有一个统一的写逻辑处理
*
* 修改日期     版本号     修改人         修改内容
* 2010-3-18    V1.0       SDRBSP           创建
**************************************************************************/
ULONG GpsSatLostRecord(T_GPS_RCV_DRV_DATA *pRcvData)
{
    ULONG ulRetVal = BSP_OK;
    UCHAR ucUartErrState = 0;
    ULONG ulRecoverLimit = CLOCK_REF_BAD_TO_OK_LIMIT;
    T_GPS_RCV_DRV_DATA *pLocalSatLostRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pLocalSatLostRcvData = pRcvData;
    /* 同8974告警策略保持一致， 不使用ulSatLost告警上报， @2018.4.5 */
    /* 获取uart口的状态 */
    ucUartErrState = SatRefUartErrState(pLocalSatLostRcvData->ulRcvPlace);

    dbgInfoEx("%s>>(%d)ulRcvPlace=%d, ulRcvInitFinishFlag =%d\n", __FUNCTION__, __LINE__,pLocalSatLostRcvData->ulRcvPlace, pLocalSatLostRcvData ->ulRcvInitFinishFlag);

    /* 天馈正常、能收到电文且模块启动时间超过12min再进行丢星统计 */
    if (((GPS_ANTENNA_STATE_OK == pLocalSatLostRcvData->ulRcvAntennaStateShow)
        && (0 == ucUartErrState))
        ||((BSP_CLOCK_REF_INTERNAL_GPS != pLocalSatLostRcvData->ulRcvPlace) && (0 == pLocalSatLostRcvData ->ulRcvInitFinishFlag))
       )
    {
        dbgInfoEx("%s>>(%d)ulRcvPlace=%d, ulRcvInitFinishFlag =%d\n", __FUNCTION__, __LINE__,pLocalSatLostRcvData->ulRcvPlace, pLocalSatLostRcvData ->ulRcvInitFinishFlag);

        /* 不是3d Fix\time only Fix状态 */
        if (((SATELLITE_3D_FIX != pLocalSatLostRcvData->ulRcvFixStatus)\
             && (SATELLITE_TIME_ONLY_FIX != pLocalSatLostRcvData->ulRcvFixStatus))\
            || ((pLocalSatLostRcvData->ulLeastSatNum > (pLocalSatLostRcvData->ulTrackedSatCnt[GPS_SAT_TYPE] + pLocalSatLostRcvData->ulTrackedSatCnt[BEIDOU_SAT_TYPE])))) //暂时只看GPS+北斗
        {
            pLocalSatLostRcvData->ulLastLockSatErrTime = GetBookTime();

            if ((GetBookTime() - pLocalSatLostRcvData->ulSatStartTime) < 720)
            {
                /* 处于搜星状态，不告警 */
                pLocalSatLostRcvData->ulLockSatState = 1;
                GPS_LOG(GPS_DBG_UBX_DRV, "(GetBookTime() - pLocalSatLostRcvData->ulSatStartTime) < 720.\n");
            }
            else
            {
                /* 持续时间大于等于告警门限，则上报搜不到星告警 */
                /* CLOCK_REF_BAD_TO_OK_LIMIT是为了与CC保持告警上的同步 */
                GPS_LOG(GPS_DBG_UBX_DRV, "pLocalSatLostRcvData->ulLastLockSatOkTime=%d.\n",pLocalSatLostRcvData->ulLastLockSatOkTime);
                if (s_ubloxAlmReportThre <= (GetBookTime() - pLocalSatLostRcvData->ulLastLockSatOkTime))
                {
                    /* 搜不到星，告警 */
                    pLocalSatLostRcvData->ulLockSatState = 2;
                    GPS_LOG(GPS_DBG_UBX_DRV, "SAT_REF_ALARM_LIMIT - CLOCK_REF_BAD_TO_OK_LIMIT) <= (GetBookTime() - pLocalSatLostRcvData->ulLastLockSatOkTime).\n");
                }
            }
        }
        else
        {
            /* 上报搜星告警时，恢复门限为300秒 */
            if (2 == pLocalSatLostRcvData->ulLockSatState)
            {
                ulRecoverLimit = s_ubloxAlmRecoverThre;
            }

            /* 持续时间超过恢复门限满足(3d Fix\time only Fix状态)，则上报搜星成功，恢复告警 */
            if (ulRecoverLimit <= (GetBookTime() - pLocalSatLostRcvData->ulLastLockSatErrTime))
            {
                pLocalSatLostRcvData->ulLockSatState = 0;
                pLocalSatLostRcvData->ulLastLockSatOkTime = GetBookTime();
            }
        }
    }
    else
    {
        pLocalSatLostRcvData->ulLockSatState = 1;
        /* 通信链路或天馈异常时重新计时 */
        pLocalSatLostRcvData->ulLastLockSatOkTime = GetBookTime();
        pLocalSatLostRcvData->ulLastLockSatErrTime = GetBookTime();
    }

    return ulRetVal;
}


/**************************************************************************
* 函数名称： GpsRcvOkErrTimeRecord
* 功能描述： 接收机可用或者不可用时间统计函数
* 输入参数： 接收机驱动实例指针(接收机具体状态)
* 输出参数： 接收机可用或不可用持续时间
* 返 回 值： 成功：BSP_OK，失败：其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-4-12    V1.0       SDRBSP          创建
**************************************************************************/
ULONG GpsRcvOkErrTimeRecord(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    BOOL bBrdRunEnoughTime = FALSE;
    ULONG ulTmpVal = 0;
    ULONG ulBookTimeOldForGpsLost = 0;        /* 上一次记录的BOOK TIME */
    T_GPS_RCV_DRV_DATA *pLocalOkErrTimeData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pLocalOkErrTimeData = pRcvDrvData;

    /* 生成GCM模块上电足够长时间的标志；由于tickGet的计时较快，1年左右会发生溢出，所以不能用tickGet()大小作为标志，需要增设一个标志变量；*/
    /* 具体条件：单板带电12min以上，软件本次启动6min以上 */
    if ((OCXO_WARM_UP_TIME < GetBookTime()) && (360 < (unsigned long long)(tick64Get() / (ULONG)sysClkRateGet())))
    {
        bBrdRunEnoughTime = TRUE;
    }

    /* GPS模块不可用的持续时间（检测预置条件：GetBookTime()12min以上，当前次软件上电6min以上） */
    if (TRUE == bBrdRunEnoughTime)
    {
        /* Gcmmain的循环时间小于1秒，这个跳变检测机制可以控制天馈异常的检测代码每秒才处理一次，不会多也不会漏 */
        ulTmpVal = GetBookTime();/* 记录到局部变量，用于避免连续两次GetBookTime()调用碰巧赶上BOOKTIME更新 */

        if (ulTmpVal != ulBookTimeOldForGpsLost)
        {
            /* check GPS OK:使用了GPS实时控制的大部分条件，去掉了时间、启动标志的判断；
               启动标志如果不去掉会引起GPS故障一次以后永远无法上报可用 */
            if ((1 == pLocalOkErrTimeData->ulRcvInitFinishFlag)
                && (GPS_ANTENNA_STATE_OK == pLocalOkErrTimeData->ulRcvAntennaStateShow)
                && (pLocalOkErrTimeData->ulLeastSatNum <= (pLocalOkErrTimeData->ulTrackedSatCnt[GPS_SAT_TYPE] + pLocalOkErrTimeData->ulTrackedSatCnt[BEIDOU_SAT_TYPE]))
                && ((SATELLITE_3D_FIX == pLocalOkErrTimeData->ulRcvFixStatus) || (SATELLITE_TIME_ONLY_FIX == pLocalOkErrTimeData->ulRcvFixStatus))
               )
            {
                pLocalOkErrTimeData->ulRcvOkTime++;      /* 正常计数器++ */
            }
            else
            {
                pLocalOkErrTimeData->ulRcvErrTime++;    /* 异常时计数 */
                pLocalOkErrTimeData->ulRcvOkTime = 0;    /* 正常计数器清0 */
            }

            /* GPS正常后的状态恢复 */
            if (pLocalOkErrTimeData->ulRcvOkTime > 10)
            {
                pLocalOkErrTimeData->ulRcvErrTime = 0; /* 连续10s正常才清0，避免受电文偶尔误报的影响 */
            }
        }

        /* 更新记录变量 */
        ulBookTimeOldForGpsLost = ulTmpVal;
    }

    return BSP_OK;
}


/**************************************************************************
* 函数名称： BspStoreLockedSatNumInfoForOmitAntBreak(ULONG ulLockedSatNum)
* 功能描述： 存储用于屏蔽天馈假开路的锁定卫星数信息
* 输入参数： ulLockedSatNum    锁定卫星数
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明： 改函数要求每秒至少被调用一次
*
* 修改日期     版本号     修改人         修改内容
* 2008/04/21   V2.0       朱伟           创建
**************************************************************************/
ULONG  BspStoreLockedSatNumInfoForOmitAntBreak(T_GPS_RCV_DRV_DATA *pRcvData)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulLockSatCnt = 0;

    /* 入参检测 */
    if (NULL == pRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 确保每秒至多检测一次 */
    if (GetBookTime() == pRcvData->ulLastBookTime)
    {
        return ulRetVal;
    }

    /* 更新时间 */
    pRcvData->ulLastBookTime = GetBookTime();

    /* 数量统计 */
    ulLockSatCnt = (pRcvData->ulLockedSatCnt[GPS_SAT_TYPE] + pRcvData->ulLockedSatCnt[BEIDOU_SAT_TYPE]);/* 目前只支持GPS+北斗 */
    if (ulLockSatCnt >= LEAST_LOCKED_SAT_NUM_FOR_OMIT_ANT_BREAK)
    {
        pRcvData->ulOmitAntBreakLockSatOkTimes++;

        /* 防抖处理 */
        if (pRcvData->ulOmitAntBreakLockSatOkTimes >= LEAST_SAT_LOCK_OK_TIME_IN_SEC)
        {
            pRcvData->ulOmitAntBreakLockSatErrTimes = 0;    /* 异常后累计（非连续）60s锁定卫星数达标则设置‘忽略天馈开路’的标志 */
            pRcvData->ulLockedSatNumIsEnoughForOmitAntBreak = 1;
        }
    }
    else
    {
        pRcvData->ulOmitAntBreakLockSatErrTimes++;

        /* 防抖处理 */
        if (pRcvData->ulOmitAntBreakLockSatErrTimes >= LEAST_SAT_LOCK_OK_TIME_IN_SEC)
        {
            pRcvData->ulOmitAntBreakLockSatOkTimes = 0;     /* 正常后累计（非连续）60s锁定卫星数均不达标则清除‘忽略天馈开路’的标志 */
            pRcvData->ulLockedSatNumIsEnoughForOmitAntBreak = 0;
        }
    }

    return ulRetVal;
}


/**************************************************************************
* 函数名称： BspSatOmitAntBreak
* 功能描述： 存储用于屏蔽天馈假开路的锁定卫星数信息
* 输入参数： pRcvData:Locked sat num
* 输出参数： pRcvData->ulRcvAntennaStateShow
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明： 该函数要求每秒至少被调用一次，适用于内置接收机
*
* 修改日期     版本号     修改人         修改内容
* 2008/04/21   V2.0       朱伟           创建
**************************************************************************/
ULONG BspSatOmitAntBreak(T_GPS_RCV_DRV_DATA *pRcvData)
{

    /* 入参检测 */
    if (NULL == pRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 内置接收机，天馈开短路检测由逻辑实现；需要结合锁定卫星数来处理；
     * 这个函数返回的仅供告警、时钟切换来使用，不影响GPS模块的内部异常防护流程。*/
    /* 实际的天馈状态赋值 */
    pRcvData->ulRcvAntennaStateShow = pRcvData->ulRcvAntennaState;

    /* 制造天馈开路异常，为天馈假开路，制造该异常的时候，屏蔽天馈假开路的防护 */
    if(GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_ANT_OPEN))
    {
        return BSP_OK;
    }

    /* 天馈假开路的防护 */
    if (GPS_ANTENNA_STATE_BREAK == pRcvData->ulRcvAntennaState)
    {
        /* 为防止上电虚警，在软件启动后的前180s内不上报天馈开路，因为这阶段接收机在初始化，锁定卫星需要一点时间 */
        if (180 > (tick64Get() / (ULONG)sysClkRateGet()))
        {
            pRcvData->ulRcvAntennaStateShow = GPS_ANTENNA_STATE_OK;
        }

        /* 根据卫星数来防护*/
        if (1 == pRcvData->ulLockedSatNumIsEnoughForOmitAntBreak)
        {
            pRcvData->ulRcvAntennaStateShow = GPS_ANTENNA_STATE_OK;
        }

    }

    return BSP_OK;
}


/**************************************************************************
* 函数名称： BspUbloxRcv
* 功能描述： UBLOX接收机维护任务实体函数。
* 输入参数： UBLOX接收机实例结构体
* 输出参数： 无
* 返 回 值： OK       成功
*            ERROR    失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-4-7     V1.0       SDRBSP            create
**************************************************************************/
void UbloxRcvTask(void)
{
    T_GPS_RCV_DRV_DATA *pUbloxRcvTaskData = NULL;
    ULONG ulCnt = 0;

    /* 驱动实例指针检测 */
    if (NULL == g_IntRcvDrvData)
    {
        return;
    }

    pUbloxRcvTaskData = (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData;
    pUbloxRcvTaskData->ucRcvInitStep = 1;/* 从步骤1开始初始化接收机，即热启，单板重启时，先热启接收机 */
    /* GPS遗留问题: 这两个值需要从后台配置下来 */
    pUbloxRcvTaskData->ulRefConfigFlag = 1;
    pUbloxRcvTaskData->ulRcvPlace = BSP_CLOCK_REF_INTERNAL_GPS;
#ifdef UT_FT_TEST
        return;
#endif

    while (1)
    {
        /* 没有配置时直接退出 */
        if (g_IntRcvDrvData->ulRefConfigFlag == 0)
        {
            //BspGnssTaskQuit();
            //return BSP_OK;
            sleep(1);
            continue;
        }

        /* 后台配置时开始处理电文信息 */
        if (1 == pUbloxRcvTaskData->ulRefConfigFlag)
        {
            /* 本任务计时变量，与任务延时对应 */
            if (29 == ulCnt++)
            {
                ulCnt = 0;
            }

            if (BSP_OK != UbloxReceiverDeal(pUbloxRcvTaskData))
            {
                GPS_LOG(GPS_DBG_UBX_DRV, "Gps Receiver Deal Input Null.\n");
            }

            /* 接收机是否可用信息生成 */
            /* 1s更新一次状态 */
            if (0 == ulCnt%10)
            {
                if (BSP_OK != UbloxRcvCreateUsableInfo(pUbloxRcvTaskData))
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "Rcv Create Usable info Input Null.\n");
                }

                /* 统计卫星丢失次数 */
                if (BSP_OK != GpsSatLostRecord(pUbloxRcvTaskData))
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "Gps Sat LostRecord input Null.\n");
                }

                /* 接收机可用or不可用时间统计，源质量检测用 */
                if (BSP_OK != GpsRcvOkErrTimeRecord(pUbloxRcvTaskData))
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, " Rcv OkErrTime Record Input Null.\n");
                }

                /* 天馈假开路处理 */
                if (BSP_OK != BspStoreLockedSatNumInfoForOmitAntBreak(pUbloxRcvTaskData))
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "ubx Bsp StoreLockedSatNumInfo For OmitAntBreak return not ok.\n");
                }

                if (BSP_OK != BspSatOmitAntBreak(pUbloxRcvTaskData))
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "ubx Bsp Sat OmitAntBreak return not ok.\n");
                }

                /* 工作模式维护，使实际工作模式与配置一致 */
                if (BSP_OK != UbxRunModeMain(pUbloxRcvTaskData))
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "ubx Bsp UbxRunModeMain return not ok.\n");
                }
            }
        }

        if (UBLOX_Receiver != g_tGcmUartSwBuf.ulRcvId)
        {
            sulIntRcvTaskId = 0xFFFFFFFF;
            sulSlaveRcvTaskId = 0xFFFFFFFF;
            return;         /*任务返回，避免干扰其他接收机*/
        }

        taskDelay((sysClkRateGet()) / 10); /* 延时0.1s */
    }
}


/**************************************************************************
* 函数名称： GpsSendCmd
* 功能描述： GPS接收机命令发送函数
*            该函数仅为一个命令流程控制函数，具体命令发送、结果解析由相应的
*            功能载体函数完成。
* 输入参数： pCmdFunc     GPS接收机命令函数指针
*            pRcvData     接收机驱动实例指针
* 输出参数： 无
* 返 回 值： OK       解读电文完
*            ERROR    解读电文未完
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2007/05/08   V1.0       朱伟            创建
**************************************************************************/
ULONG GpsSendCmd(ULONG(*pCmdFunc)(void), T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    T_GPS_RCV_DRV_DATA *pLocalCmdRcvData = NULL; /* 接收机数据实例在本函数中的指针 */
    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d)\n", __FUNCTION__, __LINE__);
        return BSP_ERROR_NULL_POINTER;
    }

    pLocalCmdRcvData = pRcvDrvData;  /* 实例赋值 */
    /* 没有命令在运行，执行新命令 */
    if (0 == pLocalCmdRcvData->ulRcvCmdRunFlag)
    {
        /* 发送命令，同时记录该命令函数的返回值 */
        pLocalCmdRcvData->ulRcvCmdNum = (*pCmdFunc)();           /*发指令到接收机 */
        /* 记录命令发起时间 */
        pLocalCmdRcvData->ulRcvCmdStartTime = tickGet();
    }

    /* 命令未超时 */
    if ((ULONG)GPS_CMD_TIME_OUT_IN_SEC > (tickGet() - pLocalCmdRcvData->ulRcvCmdStartTime))
    {
        /* 置命令执行中标志 */
        pLocalCmdRcvData->ulRcvCmdRunFlag = 1;

        /* 解析命令结果 */
        if (BSP_OK == UbxCmdDecode(pLocalCmdRcvData))
        {
            pLocalCmdRcvData->ulRcvCmdRunFlag = 0;
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d)\n", __FUNCTION__, __LINE__);
            return BSP_OK;
        }
        else
        {
            pLocalCmdRcvData->ulRcvCmdRunFlag = 0;
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d)\n", __FUNCTION__, __LINE__);
            return BSP_ERROR;
        }
    }
    else    /* 命令超时处理 */
    {
        pLocalCmdRcvData->ulRcvCmdRunFlag = 0;
        pLocalCmdRcvData->ulRcvCmdTimeOutCnt++;/* 命令超时记录加1 */
        /* 连续20次命令超时时间（约200s）内未收到电文 */
        if (20 < pLocalCmdRcvData->ulRcvCmdTimeOutCnt)
        {
            if (1 == pLocalCmdRcvData->ulReceiverCtrl)
            {
                /* 命令超时周期数清0 */
                pLocalCmdRcvData->ulRcvCmdTimeOutCnt = 0;
                /* 因为命令超时复位接收机记录次数 */
                pLocalCmdRcvData->ulRcvRstTimesSinceCmd++;
                pLocalCmdRcvData->ulRcvRstDetails[4] += 1;
                /* 接收机保护，之前有接收机维护标志 */
                GpsReceiverReset(1, pLocalCmdRcvData);
                GPS_LOG(GPS_DBG_UBX_DRV, "ublox timeout 400s, cold reset ublox receiver!\n");
            }
        }
        GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d)\n", __FUNCTION__, __LINE__);

        /* 命令响应等待超时 */
        return 0x33333333;
    }

    return  BSP_OK;
}

/**************************************************************************
* 函数名称： ULONG UbxRunModeMain
* 功能描述： 维护工作模式设置
* 输入参数： pRcvData    驱动数据结构体
* 输出参数： 无
* 返 回 值： BSP_OK
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2012/05/18             V1.0           刘新蕊             创建
**************************************************************************/
ULONG UbxRunModeMain(T_GPS_RCV_DRV_DATA *pRcvData)
{
    UCHAR ucTimeGrid = 0;
    if(NULL == pRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    if(IS_MULTI_RCV(pRcvData->ucRcvVersion))
    {
        if(BSP_OK != UbxCreateCfgWorkModeCmd(pRcvData))
        {
            return BSP_ERROR;
        }
        /* 设置工作模式 */
        if(pRcvData->ulRcvRealWorkMode != pRcvData->ulRcvWorkMode)
        {
            GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgGnssQuery, pRcvData);
            GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgGnss, pRcvData);
        }

        /* 设置timegrid */
        ucTimeGrid = (g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] >> 7) + ((g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] << 1) & 0x0E);
        if(pRcvData->ucTimeGrid != ucTimeGrid)
        {
            dbgInfo("ucTimeGrid default %04x, current %04x.\n", ucTimeGrid, pRcvData->ucTimeGrid);
            if(BSP_OK != UbxCreateCableDelayCmd(pRcvData->lAntCabDelay, pRcvData))
            {
                return BSP_ERROR;
            }
            GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgTp, pRcvData);
            GpsSendCmd((UGpsFunPtr)UbxSendCmdPollCfgTp, pRcvData);
        }
    }
    return BSP_OK;
}


void  GpsUnitGetData(T_FpgaUartBuffer *pUartBuf)
{
    ULONG ulByteCnt = 0;
    ULONG ulPhyTail = 0;/* 记录后使用，相当于g_tGcmUartPhyBuf.ulTail的一个拷贝，
                           避免计算过程中g_tGcmUartPhyBuf.ulTail发生改变对计算结果的影响 */
    ULONG i = 0;

    if (NULL == pUartBuf)
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "pUartBuf is NULL,check it\n");
        return;
    }

    /* 计算及保护 */
    ulPhyTail = g_tGcmUartPhyBuf.ulTail;
    /* + GCM_UART_QUEUE_SIZE 是为了处理队尾下标小于队首下标的情况 */
    ulByteCnt = (ulPhyTail + GCM_UART_QUEUE_SIZE - g_tGcmUartPhyBuf.ulHead) % GCM_UART_QUEUE_SIZE;

    /* 拷贝数据：g_tGcmUartPhyBuf to *pUartBuf */
    for (i = 0; i < ulByteCnt; i++)
    {
        /* 注释中的代码引起的问题是，如果不是收到1整帧，那么着帧将被错放，并导致被解析函数丢弃 */
        pUartBuf->aucBuf [(pUartBuf->ulTail + i) % GCM_UART_QUEUE_SIZE] =
            g_tGcmUartPhyBuf.aucBuf[(g_tGcmUartPhyBuf.ulHead + i) % GCM_UART_QUEUE_SIZE];
    }

    /* 修改Uart Phy, Gcm Sw缓冲区下标 */
    g_tGcmUartPhyBuf.ulHead += ulByteCnt;
    g_tGcmUartPhyBuf.ulHead %= GCM_UART_QUEUE_SIZE;
    pUartBuf->ulTail += ulByteCnt;
    pUartBuf->ulTail %= GCM_UART_QUEUE_SIZE;
    GPS_LOG(GPS_DBG_DRV_PRN, "%d Byte get head %d  tail %d\n", ulByteCnt, g_tGcmUartPhyBuf.ulHead, g_tGcmUartPhyBuf.ulTail);
    return;
}


/**************************************************************************
* 函数名称： void  UbloxGpsUnitGetIdData(T_FpgaUartBuffer *pUartBuf)
* 功能描述： 从UART0 IdPhy缓冲区拷贝数据到g_tUartIdentifyBuf缓冲区
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2011/01/22   V1.0       张全士           创建
**************************************************************************/
void  UbloxGpsUnitGetIdData(T_FpgaUartBuffer *pUartBuf)
{
    ULONG ulByteCnt = 0;
    ULONG ulPhyTail = 0;/* 记录后使用，相当于g_tGcmUartIdPhyBuf.ulTail的一个拷贝，
                           避免计算过程中g_tGcmUartIdPhyBuf.ulTail发生改变对计算结果的影响 */
    ULONG i = 0;

    if (NULL == pUartBuf)
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "pUartBuf is NULL,check it\n");
        return;
    }

    /* 计算及保护 */
    ulPhyTail = g_tGcmUartIdPhyBuf.ulTail;
    /* + GCM_UART_QUEUE_SIZE 是为了处理队尾下标小于队首下标的情况 */
    ulByteCnt = (ulPhyTail - g_tGcmUartIdPhyBuf.ulHead + GCM_UART_QUEUE_SIZE) % GCM_UART_QUEUE_SIZE;

    /* 拷贝数据：g_tGcmUartIdPhyBuf to *pUartBuf */
    for (i = 0; i < ulByteCnt; i++)
    {
        /* 注释中的代码引起的问题是，如果不是收到1整帧，那么着帧将被错放，并导致被解析函数丢弃 */
        pUartBuf->aucBuf [(pUartBuf->ulTail + i) % GCM_UART_QUEUE_SIZE] =
            g_tGcmUartIdPhyBuf.aucBuf[(g_tGcmUartIdPhyBuf.ulHead + i) % GCM_UART_QUEUE_SIZE];
    }

    /* 修改Uart Phy, Gcm Sw缓冲区下标 */
    g_tGcmUartIdPhyBuf.ulHead += ulByteCnt;
    g_tGcmUartIdPhyBuf.ulHead %= GCM_UART_QUEUE_SIZE;
    pUartBuf->ulTail += ulByteCnt;
    pUartBuf->ulTail %= GCM_UART_QUEUE_SIZE;
    /*
    GPS_LOG(GPS_DBG_UBX_DRV, "%d Byte get head %d  tail %d\n", ulByteCnt, g_tGcmUartIdPhyBuf.ulHead, g_tGcmUartIdPhyBuf.ulTail);
    */
    return;
}



/**************************************************************************
* 函数名称： GpsReceiverReset
* 功能描述： 复位GPS接收机(目前只支持内置ublox)
* 输入参数： ucResetMode: 0: 重新初始化；1: 断电再初始化
* 输出参数： 无
* 返 回 值： BSP_OK:复位成功；BSP_ERROR:复位失败
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2008/06/30   V1.0       刘骏儒         创建
**************************************************************************/
ULONG GpsReceiverReset(UCHAR ucResetMode, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    T_GPS_RCV_DRV_DATA *pResetRcvData = NULL;
    char buf[GNSS_LOG_LINE_SIZE] = {0};
    INT32 len      = 0;
    CHAR devNameStr[] = "Gps0";
    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "Gps Receiver Reset input Null.\n");
        return BSP_ERROR_NULL_POINTER;
    }
    gulUbxBaudRate = 9600;  /* 让接收机初始化时重新匹配波特率 */
    pResetRcvData = pRcvDrvData;
    if (0 != ucResetMode)
    {
        /* 发送硬件复位信号 */
        /* GPS遗留问题: 下面的复位需要实现 */
        BspResetDevice((uintptr_t)devNameStr, 0, 0);
        BspResetGnss();
        GPS_LOG(GPS_DBG_UBX_DRV, "reset ublox receiver with epld low pulse! "
            "tick = %d\n", tickGet());
    }
    else
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "reset ublox receiver without epld low pulse! "
            "tick = %d\n", tickGet());
    }
    dbgInfo("[%s](%d),reset ublox receiver\n", __FUNCTION__, __LINE__);
    /* 置初始化状态，保证软件重新初始化接收机 */
    pResetRcvData->ucRcvInitStep = 0;
    /* 可见、锁定卫星信息清除 */
    bzero(pResetRcvData->ulAvlSatCnt, sizeof(pResetRcvData->ulAvlSatCnt));
    bzero(pResetRcvData->ulTrackedSatCnt, sizeof(pResetRcvData->ulTrackedSatCnt));
    bzero(pResetRcvData->ulLockedSatCnt, sizeof(pResetRcvData->ulLockedSatCnt));

    pResetRcvData->ulRcvFixStatus = SATELLITE_NOT_FIX;
    /* pResetRcvData->ulRcvAntennaState = GPS_ANTENNA_STATE_DONTKNOW; */
    /* pResetRcvData->ulRcvAntennaStateShow = GPS_ANTENNA_STATE_DONTKNOW; */
    /* 给驱动实例赋值 */
    pResetRcvData->ulRcvInitFinishFlag  = 0;
    /* pResetRcvData->ulRcvInitStartTime  = GetBookTime(); */
    /* pResetRcvData->ulRcvInitFinishTime = GetBookTime(); */
    pResetRcvData->ulRcvInitNotDoneTime = GetBookTime();
    pResetRcvData->ulRcvResetTimes += 1;
    len = snprintf_s(buf,sizeof(buf),"rst time %d",pResetRcvData->ulRcvResetTimes);
    SNPRINTF_S_CHECK(len, sizeof(buf));
    BspAddGnssLog(GNSS_LOG_TYPE_RST,buf, len);
    return BSP_OK;
}

/**************************************************************************
* 函数名称： VOID DualReceiverProtect(VOID)
* 功能描述： 双模接收机保护
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明： GPS+北斗双模接收机可能会自身异常复位，需要对其进行保护切换到单模接收机工作模式上
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2017-12-12   V1.0   何t10099908        创建
**************************************************************************/
VOID DualRcvProtect(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return;
    }

    if( (OUTER_GPS_BD_RECEIVER == pRcvDrvData->ulRcvWorkMode) && IS_MULTI_RCV(pRcvDrvData->ucRcvVersion))
    {
        switch(pRcvDrvData->ucDualRcvProtectStep)
        {
            case 0:
                /* 串口60秒不通，则修改本地波特率为9600bps */
                if((GetBookTime() > pRcvDrvData->ulUartNormalTime + DUAL_RCV_UART_ERR_LIMIT) && (0 != pRcvDrvData->ulUartNormalTime))
                {
                    SetUartBaudrate(9600, 0);
                    pRcvDrvData->ucDualRcvProtectStep = 1;
                    pRcvDrvData->ulDualRcvProtectTime1 = GetBookTime();
                }
                break;
            case 1:
                /* 修改9600bps解决不了通讯异常，波特率修改成115200bps */
                if( GetBookTime() > pRcvDrvData->ulDualRcvProtectTime1 + DUAL_RCV_UART_ERR_LIMIT )
                {
                    SetUartBaudrate(115200, 0);
                    pRcvDrvData->ucDualRcvProtectStep = 2;
                    pRcvDrvData->ulDualRcvProtectTime2 = GetBookTime();
                }
                /* 修改本地波特率为9600bps后通讯正常了，说明接收机异常复位，则发送修改单模接收机指令 */
                if( 0 == pRcvDrvData->ucGpsUartErr )
                {
                    /* 分别尝试GPS和北斗 */
                    if( 0 == (pRcvDrvData->ucDualRcvProtectCnt%2) )
                    {
                        pRcvDrvData->ulDualRcvProtectWorkMode = OUTER_GPS_RECEIVER;
                    }
                    else
                    {
                        pRcvDrvData->ulDualRcvProtectWorkMode = OUTER_BD_RECEIVER;
                    }
                    pRcvDrvData->ucDualRcvProtectCnt++;
                    GpsReceiverReset(1, pRcvDrvData);
                    pRcvDrvData->ucDualRcvProtectStep = 2;
                    pRcvDrvData->ulDualRcvProtectTime2 = GetBookTime();
                    GPS_LOG(GPS_DBG_UBX_DRV_TEST, "GNSS Dual Receiver protect, change to %s mode! tick = %u\n",
                        (pRcvDrvData->ulDualRcvProtectWorkMode==OUTER_GPS_RECEIVER)?"GPS":"BEIDOU", tickGet());
                }
                break;
            case 2:
                /* 如果修改115200或单模接收机持续60秒不能通讯正常，回到步骤0 */
                if( ( GetBookTime() > pRcvDrvData->ulDualRcvProtectTime2 + DUAL_RCV_UART_ERR_LIMIT ) &&
                    ( GetBookTime() > pRcvDrvData->ulUartNormalTime + DUAL_RCV_UART_ERR_LIMIT ))
                {
                    pRcvDrvData->ucDualRcvProtectStep = 0;
                    pRcvDrvData->ulDualRcvProtectWorkMode = 0;
                }
                /* 每隔1小时15分钟恢复双模接收机，保证时钟锁定和具有保持能力的时间 */
                if( GetBookTime() > pRcvDrvData->ulDualRcvProtectTime2 + 4500 )
                {
                    pRcvDrvData->ulDualRcvProtectWorkMode = 0;
                    GpsReceiverReset(1, pRcvDrvData);
                    pRcvDrvData->ucDualRcvProtectStep = 0;
                }
                break;
            default:
                break;

        }

    }
    else
    {
        /* 如果后台修改成单模，需要重置 */
        pRcvDrvData->ucDualRcvProtectStep = 0;
        pRcvDrvData->ulDualRcvProtectWorkMode = 0;
    }

    return;
}

/**************************************************************************
* 函数名称： UbxReceiverProtect
* 功能描述： UBLOX接收机保护
* 输入参数： 驱动结构体实例数据结构
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2006/02/28   V1.0       朱伟           创建
**************************************************************************/
ULONG  UbxReceiverProtect(T_GPS_RCV_DRV_DATA *pProtectRcv)
{
    /* 定义接收机驱动实例结构体指针，并将入参赋给之 */
    T_GPS_RCV_DRV_DATA *pLocalProtectRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pProtectRcv)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pLocalProtectRcvData = pProtectRcv;

    /* 天馈状态正常但是锁定卫星数小于门限持续时间超过5分钟，冷启动复位并重新初始化接收机 */
    if ((GPS_ANTENNA_STATE_OK == pLocalProtectRcvData->ulRcvAntennaStateShow)
        && (pLocalProtectRcvData->ulLeastSatNum > (pLocalProtectRcvData->ulTrackedSatCnt[GPS_SAT_TYPE] + pLocalProtectRcvData->ulTrackedSatCnt[BEIDOU_SAT_TYPE])))
    {
        if (0 == pLocalProtectRcvData->ulLockFailedTime) /* 该函数第一次初始化，要初始化g_ulLockFailedTime变量 */
        {
            pLocalProtectRcvData->ulLockFailedTime = GetBookTime();
        }
        else if (300 < (GetBookTime() - pLocalProtectRcvData->ulLockFailedTime)) /* 持续时间大于5分钟，冷启并重新初始化 */
        {
            if (1 == pLocalProtectRcvData->ulReceiverCtrl)
            {
                /* 统计复位次数 */
                pLocalProtectRcvData->ulRcvRstDetails[1] += 1;
                GpsReceiverReset(1, pLocalProtectRcvData);
                pLocalProtectRcvData->ulLockFailedTime = GetBookTime();
                GPS_LOG(GPS_DBG_UBX_DRV, "Ublox: antenna ok but lock satellite "
                    "too few for 5min, cold reset ublox receiver!\n");
            }
        }
        else /* 持续时间不足5min，累计时间 */
        {
        }
    }
    else
    {
        pLocalProtectRcvData->ulLockFailedTime = GetBookTime();
    }

    /* 持续10分钟接收机搜星4颗以上但是进不了3D或TIME模式，冷启复位UBLOX接收机 */
    if ((SATELLITE_3D_FIX != pLocalProtectRcvData->ulRcvFixStatus)
        && (SATELLITE_TIME_ONLY_FIX != pLocalProtectRcvData->ulRcvFixStatus)
        && (pLocalProtectRcvData->ulLeastSatNum < (pLocalProtectRcvData->ulTrackedSatCnt[GPS_SAT_TYPE] + pLocalProtectRcvData->ulTrackedSatCnt[BEIDOU_SAT_TYPE])))
    {
        if (0 == pLocalProtectRcvData->ulGpsFixNotOkTime) /* 该函数第一次初始化，要初始化ulLockFailedTime变量 */
        {
            pLocalProtectRcvData->ulGpsFixNotOkTime = GetBookTime();
        }
        else if (600 < (GetBookTime() - pLocalProtectRcvData->ulGpsFixNotOkTime)) /* 持续时间大于10分钟，冷启并重新初始化 */
        {
            if (1 == pLocalProtectRcvData->ulReceiverCtrl)
            {
                pLocalProtectRcvData->ulRcvRstDetails[2] += 1;
                GpsReceiverReset(1, pLocalProtectRcvData);
                pLocalProtectRcvData->ulGpsFixNotOkTime = GetBookTime();
                dbgInfo("ublox receiver can not enter 3D or TIME mode for 10min with more than 4 satellites locked, cold reset ublox receiver!\n");
            }
        }
        else /* 持续时间不足，累计时间 */
        {
        }
    }
    else
    {
        pLocalProtectRcvData->ulGpsFixNotOkTime = GetBookTime();
    }

    /* 初始化完成后，接收机持续10s没有收到电文，冷启复位UBLOX接收机 */
    if (1 == pLocalProtectRcvData->ulRcvInitFinishFlag)
    {
        if (0 == pLocalProtectRcvData->ulRcvMsgStas)
        {
            if (0 == pLocalProtectRcvData->ulGpsNoAckTime) /* 该函数第一次初始化，要初始化ulNoAckTime变量 */
            {
                pLocalProtectRcvData->ulGpsNoAckTime = GetBookTime();
                GPS_LOG(GPS_DBG_UBX_DRV, "GPS: booktime is %d, ulGpsNoAckTime = 0\n",
                    GetBookTime());
            }
            else if (10 < (GetBookTime() - pLocalProtectRcvData->ulGpsNoAckTime)) /* 持续时间大于10秒，冷启并重新初始化 */
            {
                if (1 == pLocalProtectRcvData->ulReceiverCtrl)
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "ublox receiver no ack for 10s after init, reset (%d,%d)\n",
                        GetBookTime(), pLocalProtectRcvData->ulGpsNoAckTime);
                    GpsReceiverReset(1, pLocalProtectRcvData);
                    pLocalProtectRcvData->ulGpsNoAckTime = GetBookTime();/* 重新初始化赋值，是否必要？ */
                }
            }
            else
            {
                /*GPS_LOG(GPS_DBG_UBX_DRV, "GPS: booktime is %d, wait\n",GetBookTime());*/
            }
        }
        else
        {
            pLocalProtectRcvData->ulGpsNoAckTime = GetBookTime();
        }
    }

    /* 双模接收机异常保护 */
    DualRcvProtect(pLocalProtectRcvData);

    return BSP_OK;
}

/**************************************************************************
* 函数名称： ULONG GpsAntennaStateBadRecord(void)
* 功能描述： 统计天馈异常次数
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK
* -----------------------------------------------------------------------
* 其它说明：1s最多统计一次
*
* 修改日期     版本号     修改人         修改内容
* 2010-3-18    V1.0       SDRBSP           创建
**************************************************************************/
ULONG GpsAntStateBadRecord(T_GPS_RCV_DRV_DATA *pAntRcvData)
{
    ULONG ulRetVal = BSP_OK;
    T_GPS_RCV_DRV_DATA *pLocalAntRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pAntRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pLocalAntRcvData = pAntRcvData;

    /* 当天馈状态OK时，清除天馈曾经不可用状态 */
    if (GPS_ANTENNA_STATE_OK == pLocalAntRcvData->ulRcvAntennaStateShow)
    {
        if (0 == pLocalAntRcvData->ulAntState)
        {
            pLocalAntRcvData->ulAntState = 1;
        }
    }

    /* 当天馈统计状态正常(曾经不可用状态为0)时，若出现天馈不可用，则进行统计 */
    if (1 == pLocalAntRcvData->ulAntState)
    {
        if (GPS_ANTENNA_STATE_OK != pLocalAntRcvData->ulRcvAntennaStateShow)
        {
            pLocalAntRcvData->ulAntennaBadTimes ++;
            pLocalAntRcvData->ulAntState = 0;
            GPS_LOG(GPS_DBG_UBX_DRV, "antenna Leap Num = %d, tick = %d.\n",
                pLocalAntRcvData->ulAntennaBadTimes, tickGet());
        }
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称： ULONG  GpsGetAntState(void)
* 功能描述： 从FPGA获取天馈状态
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2008/04/21   V2.0       刘骏儒         创建
**************************************************************************/
ULONG GpsGetAntState(void)
{
    #if 0
    USHORT usVal;
    USHORT ulGpsStatus = GPS_ANTENNA_STATE_DONTKNOW;
/*
    0x20ff

    bit0 - O_pwr_gps_en     应该是高有效
    bit1 - I_gps_ant_short_n  从命名看是短路告警 低-告警
    bit2 - I_gps_ant_open    从命名看是开路告警 高-告警
*/
    INPUT_POINTER_CHECK(g_GpsInfo.GetAntStatus);
    usVal = g_GpsInfo.GetAntStatus();
    //dbgInfo("GpsGetAntState==> GetAntStatus:%d.\n",usVal);
    if(usVal == BSP_ERROR)
    {
        return GPS_ANTENNA_STATE_DONTKNOW;
    }
    else
    {
        switch((usVal>>1)&0x3)
        {
            case 1:
               ulGpsStatus = GPS_ANTENNA_STATE_OK;
               break;

            case 0:
                ulGpsStatus = GPS_ANTENNA_STATE_SHORT;
                break;

            case 3:
                ulGpsStatus = GPS_ANTENNA_STATE_BREAK;
                break;

            default:
                ulGpsStatus = GPS_ANTENNA_STATE_DONTKNOW;
                break;
        }
    }

    return ulGpsStatus;
    #else
    /* 制造天馈开路异常，恢复时按照正常流程 */
    if(GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_ANT_OPEN))
    {
        return GPS_ANTENNA_STATE_BREAK;
    }
    /* 制造天馈短路异常，恢复时按照正常流程 */
    if(GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_ANT_SHORT))
    {
        return GPS_ANTENNA_STATE_SHORT;
    }
    return GPS_ANTENNA_STATE_OK;
    #endif
}

/**************************************************************************
* 函数名称： ULONG UbloxReceiverDeal(T_GPS_RCV_DRV_DATA *pDealRcvDrvData)
* 功能描述： 接收机定时管理
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2006/02/28   V1.0       朱伟           创建
**************************************************************************/
ULONG UbloxReceiverDeal(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    T_GPS_RCV_DRV_DATA *pDealLocalRcvDrvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 驱动实例对本地结构体赋值 */
    pDealLocalRcvDrvData = pRcvDrvData;

    /* 当前是内置接收机时采用逻辑进行检测 */
    if (BSP_CLOCK_REF_INTERNAL_GPS == pDealLocalRcvDrvData->ulRcvPlace)
    {
        /* 20次检测一次逻辑 */
        if (20 < pDealLocalRcvDrvData->ulAntCheckCnt)
        {
            pDealLocalRcvDrvData->ulRcvAntennaState = GpsGetAntState();
            pDealLocalRcvDrvData->ulAntCheckCnt = 0;
        }
        else
        {
            pDealLocalRcvDrvData->ulAntCheckCnt++;
        }
    }
    /* gps级联默认天馈ok，只是对外显示为未知状态 */
    else if (BSP_CLOCK_REF_SLAVE_PANNEL == pDealLocalRcvDrvData->ulRcvPlace)
    {
        pDealLocalRcvDrvData->ulRcvAntennaState = GPS_ANTENNA_STATE_OK;
    }
    /* 外置 */
    else if (BSP_CLOCK_REF_EXTERNAL_FRONT_SATELLITE == pDealLocalRcvDrvData->ulRcvPlace)
    {
        pDealLocalRcvDrvData->ulRcvAntennaState = GpsGetAntState();
    }

    if (1 == g_ulAntCheckPrn)
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "AntCheckCnt = %d,FinishFlag is %d\n",
            pDealLocalRcvDrvData->ulAntCheckCnt, pDealLocalRcvDrvData->ulRcvInitFinishFlag);
    }

    if (0 == pDealLocalRcvDrvData->ulRcvInitFinishFlag)
    {
        /* 热启时记录接收机启动时间，冷启启动时间由reset函数记录 */
        if (1 == pDealLocalRcvDrvData->ucRcvInitStep)
        {
            pDealLocalRcvDrvData->ulRcvInitStartTime  = GetBookTime();
            pDealLocalRcvDrvData->ulRcvInitFinishTime = GetBookTime();
            GPS_LOG(GPS_DBG_UBX_DRV, "ublox init step is in 1, tick = %d\n", tickGet());
        }

        /* 接收机初始化 */
        UbxGpsReceiverInit(pDealLocalRcvDrvData);
        /* 热启保护：每个0.1s */
        pDealLocalRcvDrvData->ulRcvWarmStartCnt++;

        /* 2分钟后热启不成功就切换到冷启 */
        if ((pDealLocalRcvDrvData->ulRcvWarmStartCnt > 1200) && (0 == pDealLocalRcvDrvData->ulRcvColdInitFlag))
        {
            pDealLocalRcvDrvData->ulRcvColdInitFlag = 1;
            dbgInfo("warm start failed，switch to cold start! tick = %d\n", tickGet());
        }

        /* 从热启切换到冷启 */
        if ((0 == pDealLocalRcvDrvData->ulRcvColdInitFlagLast) && (1 == pDealLocalRcvDrvData->ulRcvColdInitFlag))
        {
            if (1 == pDealLocalRcvDrvData->ulReceiverCtrl)
            {
                GpsReceiverReset(0, pDealLocalRcvDrvData);
                dbgInfo("warm to cold start,tick = %d.\n", tickGet());
            }
        }

        /* 记录热启、冷启的上一次状态 */
        pDealLocalRcvDrvData->ulRcvColdInitFlagLast = pDealLocalRcvDrvData->ulRcvColdInitFlag;
    }
    /* 初始化完成后，信息解析 */
    else
    {
        UbxCmdDecode(pDealLocalRcvDrvData);/* 注意，没有关注返回值 */
    }

    /* 统计天馈故障次数 */
    if (BSP_OK != GpsAntStateBadRecord(pDealLocalRcvDrvData))
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "GpsAntState BadRecord input Null.\n");
    }

    /* ublox接收机保护 */
    if (BSP_OK != UbxReceiverProtect(pDealLocalRcvDrvData))
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "Ubx Receiver Protect input Null.\n");
    }

    /* 更新天馈位置信息，用于支持本地维护数据的单星授时 */
#if  0
    SatAntPosInfoUpdate(&gtSatAntPosInfo, g_IntRcvDrvData->ulLockedSatCnt[BspGetSatType()], g_IntRcvDrvData->ulRcvFixStatus);
#endif
    return BSP_OK;
}

/*******************************************************************************
 *                          ublox接收机驱动函数                                *
 ******************************************************************************/


/**************************************************************************
* 函数名称： void UbxUartSendData(UCHAR NUM)
* 功能描述： 解析ublox帧（除去帧头和校验部分）
* 输入参数： pucBuf：帧起始地址，从MESSAGE CLASS开始
*            usPayloadLen：净荷长度
* 输出参数： 无
* 返 回 值： 帧类型编号
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
/* 每个一维子数组第一行为头信息（其中第一个字节为帧长），最后一行为校验，中间为净荷 */
/*lint -e785*/
UCHAR g_aucUbxCmd[GNSS_CMD_MAX_NUM][GNSS_CMD_MAX_LEN] =
{
    /* step0: RESET,Coldstart */
    [UBLOX_INIT_RESET] =
    {
        12, 0XB5, 0X62, 0X06, 0X04, 0X04, 0X00,
        0XFF, 0XFF, 0X00, 0X00,
        0X0C, 0X5D
    },
    /* step1: 查询ublox接收机版本，区分4T和5T */
    [UBLOX_INIT_MON_VER] =
    {
        8, 0XB5, 0X62, 0X0A, 0X04, 0X00, 0X00,
        0X0E, 0X34
    },
    /* step2:  关闭NMEA自动上报信息，除了GPGGA/GPGSA/GPGSV */
    [UBLOX_INIT_CLOSE_MSG] =
    {
        50, 0XB5, 0X62, 0X06, 0X01, 0X2A, 0X00,
        0XF0, 0X00, 0X00, 0X01, 0X00, 0X00, /* GPGGA */
        0XF0, 0X01, 0X00, 0X00, 0X00, 0X00,
        0XF0, 0X02, 0X00, 0X01, 0X00, 0X00, /* GPGSA */
        0XF0, 0X03, 0X00, 0X01, 0X00, 0X00, /* GPGSV */
        0XF0, 0X04, 0X00, 0X00, 0X00, 0X00,
        0XF0, 0X05, 0X00, 0X00, 0X00, 0X00,
        0XF0, 0X08, 0X00, 0X00, 0X00, 0X00,
        0XDB, 0X95
    },
    /* step3: CFG_TP PP1S延时设置，输出的是负脉冲 */
    [UBLOX_INIT_CFG_TP] =
    {
        28, 0XB5, 0X62, 0X06, 0X07, 0X14, 0X00,
        0X40, 0X42, 0X0F, 0X00, 0X20, 0XA1, 0X07, 0X00,
        0XFF, 0X01, 0X00, 0X00, 0X32, 0X00, 0X34, 0X03,
        0X00, 0X00, 0X00, 0X00,
        0XE3, 0X84
    },
    /* step4:  天馈状态检测参数设置*/
    [UBLOX_INIT_CFG_ANT] =
    {
        12, 0XB5, 0X62, 0X06, 0X13, 0X04, 0X00,
        0X1F/*此处的1为经验值，与协议文档有出入*/, 0X00, 0X0F, 0X38,
        0X83, 0X9F
    },
    /* step5:  使能MON-HW以获取天馈信息 */
    [UBLOX_INIT_MON_ANT] =
    {
        11, 0XB5, 0X62, 0X06, 0X01, 0X03, 0X00,
        0X0A, 0X09, 0X01,
        0X1E, 0X70
    },
    /* step6: CFG_NAV2 设置stationary模式, Auto 2D/3D，高度默认500m。 */
    [UBLOX_INIT_CFG_NAV] =
    {
        48, 0XB5, 0X62, 0X06, 0X1A, 0X28, 0X00,
        0X01, 0X00, 0X00, 0X00, 0X01, 0X01, 0X10, 0X02,
        0X50, 0XC3, 0X00, 0X00, 0X18, 0X14, 0X05, 0X3C,
        0X00, 0X01, 0X00, 0X00, 0XFA, 0X00, 0XFA, 0X00,
        0X64, 0X00, 0X2C, 0X01, 0X00, 0X00, 0X00, 0X00,
        0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00,
        0X63, 0X66
    },
    /* step7: CFG_TMODE 激活time模式, 15分钟达到15m的精度则进time模式 */
    [UBLOX_INIT_CFG_TMODE] =
    {
        36, 0XB5, 0X62, 0X06, 0X1D, 0X1C, 0X00,
        0X01, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00,
        0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00,
        0X00, 0X00, 0X00, 0X00, 0X84, 0X03, 0X00, 0X00,
        0X40, 0X3A, 0X69, 0X0D,
        0XB7, 0X69
    },
    /* step8: CFG_MSG 使能NAV_SOL信息输出1S一次，确认是否已经定位 */
    [UBLOX_INIT_CFG_MSG_NAV_SOL] =
    {
        11, 0XB5, 0X62, 0X06, 0X01, 0X03, 0X00,
        0X01, 0X06, 0X01,
        0X12, 0X4F
    },
    /* step9: CFG_MSG 使能NAV-POSLLH 位置信息输出*/
    [UBLOX_INIT_CFG_MSG_NAV_POSLLH] =
    {
        11, 0XB5, 0X62, 0X06, 0X01, 0X03, 0X00,
        0X01, 0X02, 0X01,
        0X0E, 0X47
    },
    /* step10: CFG_MSG 使能NAV-TIMEGPS 时间信息输出*/
    [UBLOX_INIT_CFG_MSG_NAV_TIMEGPS] =
    {
        11, 0XB5, 0X62, 0X06, 0X01, 0X03, 0X00,
        0X01, 0X20, 0X01,
        0X2C, 0X83
    },

    /* 以下为兼容5T接收机的配置电文 */
    /* step11～step15，设置接收机电文 */
    /* step11：5T兼容 响应：关闭GPGLL输出 */
    [UBLOX_INIT_5T_CLOSE_MSG_GPGLL] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0XF0,0X01,0X00,
        0XFB,0X11
    },
    /* step12：5T兼容 响应：GPGSV每1秒输出一次 */
    [UBLOX_INIT_5T_CFG_MSG_GPGSV] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0XF0,0X03,0X01,
        0XFE,0X16
    },
    /* step13：5T兼容 响应：关闭GPRMC输出 */
    [UBLOX_INIT_5T_CLOSE_MSG_GPRMC] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0XF0,0X04,0X00,
        0XFE,0X17
    },
    /* step14：5T兼容 响应：关闭GPVTG输出 */
    [UBLOX_INIT_5T_CLOSE_MSG_GPVTG] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0XF0,0X05,0X00,
        0XFF,0X19
    },
    /* step15：5T兼容 响应：关闭GPZDA输出 */
    [UBLOX_INIT_5T_CLOSE_MSG_GPZDA] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0XF0,0X08,0X00,
        0X02,0X1F
    },
    /* step16: 5T兼容  CFG-NAV5  设置stationary模式 */
    [UBLOX_INIT_5T_CFG_NAV5] =
    {
        44, 0XB5, 0X62, 0X06, 0X24, 0X24, 0X00,
        0XFF, 0XFF, 0X02, 0X03, 0X50, 0XC3, 0X00, 0X00,
        0X10, 0X27, 0X00, 0X00, 0X05, 0X00, 0XFA, 0X00,
        0XFA, 0X00, 0X64, 0X00, 0X2C, 0X01, 0X00, 0X00,
        0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00,
        0X00, 0X00, 0X00, 0X00,
        0X25, 0XF1
    },
    /* step17: 5T兼容 CFG_TP  PP1S延时设置 */
    [UBLOX_INIT_5T_CFG_TP] =
    {
        28, 0XB5, 0X62, 0X06, 0X07, 0X14, 0X00,
        0X40, 0X42, 0X0F, 0X00, 0X20, 0XA1, 0X07, 0X00,
        0X01, 0X01, 0X01, 0X00, 0X32, 0X00, 0X00, 0X00,
        0X00, 0X00, 0X00, 0X00,
        0Xaf, 0X5f
    },
    /* step18: 确认TMOD发送的查询指令 */
    [UBLOX_INIT_5T_CFG_TMODE_QUERY] =
    {
        8, 0XB5, 0X62, 0X06, 0X1D, 0X00, 0X00,
        0X23, 0X6F
    },
    /* step19: Disable SBAS功能(因为SBAS系统信号的原因,ublox接收机存在晚上丢星情况) */
    [UBLOX_INIT_CFG_SBAS] =
    {
        16, 0XB5, 0X62, 0X06, 0X16, 0X08, 0X00,
        0X00, 0X03, 0X01, 0X00, 0X00, 0X00, 0X00, 0X00,
        0X28, 0XA5
    },
    [UBLOX_INIT_5T_CFG_NAV5_MOV] =
    {
        44,0XB5,0X62,0X06,0X24,0X24,0X00,
        0XFF,0XFF,0X04,0X02,0X00,0X00,0X00,0X00,
        0X10,0X27,0X00,0X00,0X05,0X00,0XFA,0X00,
        0XFA,0X00,0X64,0X00,0X64,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,
        0X4A,0XE8
    }, /* step20: 5T兼容  CFG-NAV5  设置Automotive模式 */
    [UBLOX_INIT_CFG_TMODE_NOT_SURVEY_IN] =
    {36,0XB5,0X62,0X06,0X1D,0X1C,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X80,0X51,0X01,0X00,
        0X01,0X00,0X00,0X00,
        0X12,0XCC
    }, /* step21: CFG_TMODE 去激活SurveyIn模式 */
    [UBLOX_INIT_POLL_MSG_AID_INI] =
    {
        8,0XB5,0X62,0X0B,0X01,0X00,0X00,
        0X0C,0X2F
    }, /* step22: POLL_MSG AID_INI信息输出*/
    [UBLOX_INIT_POLL_MSG_AID_HUI] =
    {
        8,0XB5,0X62,0X0B,0X02,0X00,0X00,
        0X0D,0X32
    }, /* step23: POLL_MSG AID_HUI信息输出*/
    [UBLOX_INIT_POLL_MSG_AID_EPH] =
    {
        9,0XB5,0X62,0X0B,0X31,0X01,0X00,
        0x00,0X00,0X00
    }, /* step24: POLL_MSG AID_EPH信息输出*/
    [UBLOX_INIT_SEND_MSG_AID_INI] =
    {
        56,0XB5,0X62,0X0B,0X01,0X30,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00
    }, /* step25: SEND_MSG AID_INI(Initial Aiding Data)信息*/
    [UBLOX_INIT_SEND_MSG_AID_HUI] =
    {
        80,0XB5,0X62,0X0B,0X02,0X48,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00
    }, /* step26: SEND_MSG AID_HUI(Health, UTC and ionosphere parameters)信息*/
    [UBLOX_INIT_SEND_MSG_AID_EPH] =
    {
        112,0XB5,0X62,0X0B,0X31,0X68,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00
    }, /* step27: SEND_MSG AID_EPH(Aiding Ephemeris Data)信息*/
    [UBLOX_INIT_POLL_MSG_AID_DATA] =
    {
        8,0XB5,0X62,0X0B,0X10,0X00,0X00,
        0X1B,0X5C
    }, /* step28: POLL_MSG 使能AID_DATA信息输出*/
    [UBLOX_INIT_CFG_MSG_AID_EPH] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0X0B,0X31,0X01,0X47,0XC3
    }, /* step29: CFG_MSG 使能AID_EPH(Aiding Ephemeris Data)信息输出*/
    [UBLOX_INIT_CFG_MSG_AID_HUI] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0X0B,0X02,0X01,0X18,0X65
    }, /* step30: CFG_MSG 使能AID_HUI(Health, UTC and ionosphere parameters)信息输出*/
    [UBLOX_INIT_CFG_MSG_AID_INI] =
    {
        11,0XB5,0X62,0X06,0X01,0X03,0X00,
        0X0B,0X01,0X01,0X17,0X63
    }, /* step31: CFG_MSG 使能AID_INI(Initial Aiding Data)信息输出*/
    [UBLOX_INIT_CFG_TP5] =
    {
        40,0XB5,0X62,0X06,0X31,0X20,0X00,
        0X00,0X01,0X00,0X00,0X32,0X00,0X00,0X00,
        0X40,0X42,0X0F,0X00,0X40,0X42,0X0F,0X00,
        0X90,0XD0,0X03,0X00,0X20,0XA1,0X07,0X00,
        0X00,0X00,0X00,0X00,0XB7,0X00,0X00,0X00,
        0X8E,0X75
    }, /* step32: 8T兼容 CFG_TP5  锁定PP1S延时设置 %50占空比, 随机1PPS脉宽%25, 负脉冲*/
    [UBLOX_INIT_CFG_TMODE2] =
    {
        36,0XB5,0X62,0X06,0X3D,0X1C,0X00,
        0X01,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X00,0X00,0X00,0X00,
        0X00,0X00,0X00,0X00,0X84,0X03,0X00,0X00,
        0X98,0X3A,0X00,0X00,
        0XB9,0XCA
    }, /* step33 8T兼容 CFG_TMODE2 激活time模式, 15分钟达到15m的精度则进time模式 */
    [UBLOX_INIT_CFG_GNSS] =
    {
        52,0XB5,0X62,0X06,0X3E,0X2C,0X00,
        0X00,0X00,0X20,0X05,0X00,0X08,0X10,0X00,
        0X01,0X00,0X01,0X01,0X01,0X01,0X03,0X00,    /* GPS */
        0X00,0X00,0X01,0X01,0X03,0X08,0X10,0X00,    /* SBAS */
        0X01,0X00,0X01,0X01,0X05,0X00,0X03,0X00,    /* BEIDOU */
        0X01,0X00,0X01,0X01,0X06,0X08,0X0E,0X00,    /* QZSS */
        0X00,0X00,0X01,0X01,                        /* GLONASS */
        0XFE,0X31
    }, /* step34 8T兼容 CFG_GNSS 设置接收机工作模式，默认以双模启动 */
    [UBLOX_INIT_CFG_TMODE2_QUERY] =
    {
        8,0XB5,0X62,0X06,0X3D,0X00,0X00,
        0X43,0XCF
    }, /* step35: 确认TMOD2发送的查询指令 */
    [UBLOX_INIT_CFG_GNSS_QUERY] =
    {
        8,0XB5,0X62,0X06,0X3E,0X00,0X00,
        0X44,0XD2
    }, /* step36: 确认CFG_GNSS发送的查询指令 */
    [UBLOX_INIT_CFG_NMEA] =
    {
        28,0XB5,0X62,0X06,0X17,0X14,0X00,
        0X00,0X41,0X00,0X04,0X00,0X00,0X00,0X00, /* limit82 */
        0X01,0X00,0X00,0X01,0X00,0X00,0X00,0X00, /* Extended - Use proprietary numbering */
        0X00,0X00,0X00,0X00,
        0X78,0X85
    }, /* step37 8T接收机 配置NMEA报文输出 */
    [UBLOX_INIT_POLL_CFG_TP] =
    {
        8, 0XB5,0X62,0X06,0X07,0X00,0X00,  /* step38 查询CFG-TP配置 */
        0X0D,0X2D
    },
    [UBLOX_INIT_POLL_CFG_TP5] =
    {
        8, 0XB5,0X62,0X06,0X31,0X00,0X00,  /* step39 8T接收机查询CFG-TP5配置 */
        0X37,0XAB
    },
    [UBLOX_INIT_CFG_PRT] =
    {
        28,0XB5,0X62,0X06,0X00,0X14,0X00, /* step40 8T接收机设置UART波特率为115200 */
        0X01,0X00,0X00,0X00,0XD0,0X08,0X00,0X00,
        0X00,0XC2,0X01,0X00,0X07,0X00,0X03,0X00,
        0X00,0X00,0X00,0X00,
        0XC0,0X7E
    },
    [UBLOX_INIT_POLL_CFG_PRT] =
    {
        9, 0XB5,0X62,0X06,0X00,0X01,0X00, /* step41 8T接收机查询UART波特率 */
        0X01,0X08,0X22
    },
};
ULONG UbxUartSendData(UCHAR NUM)
{
    if (NUM >= UBLOX_INIT_NUM)
    {
        return BSP_ERROR;
    }
    return GpsUartOutput(g_aucUbxCmd[NUM][0], &g_aucUbxCmd[NUM][1]);
}

/**************************************************************************
* 函数名称： ULONG UbxUpdateCheckSum(ULONG ulCmdIndex)
* 功能描述： 更新UBX指令的校验和
* 输入参数： ulCmdIndex: UBX指令索引
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       刘骏儒         创建
**************************************************************************/
ULONG UbxCalcCheckSum(ULONG ulCmdLen, UCHAR *ucCmdBuf)
{
    UCHAR ucCheckA = 0;
    UCHAR ucCheckB = 0;
    ULONG i = 0;

    /* Part0. 入参检测 */
    if (NULL == ucCmdBuf)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    for (i = 2; i <= (ulCmdLen - 3); i++)
    {
        ucCheckA += ucCmdBuf[i];
        ucCheckB += ucCheckA;
    }

    if (ulCmdLen < 2)
    {
        return BSP_ERROR;
    }

    ucCmdBuf[ulCmdLen - 2] = ucCheckA;
    ucCmdBuf[ulCmdLen - 1] = ucCheckB;
    return BSP_OK;
}

/**************************************************************************
* 函数名称： ULONG UbxUpdateCheckSum(ULONG ulCmdIndex)
* 功能描述： 更新UBX指令的校验和
* 输入参数： ulCmdIndex: UBX指令索引
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       刘骏儒         创建
**************************************************************************/
ULONG UbxUpdateCheckSum(ULONG ulCmdIndex)
{
    UCHAR cCheckA = 0;
    UCHAR cCheckB = 0;
    UCHAR i = 0;
    UCHAR transValue = 0;

    if(ulCmdIndex >= UBLOX_INIT_NUM)
    {
        return BSP_ERROR;
    }

    for (i = 3; i <= (g_aucUbxCmd[ulCmdIndex][0] - 2); i++)
    {
        cCheckA += g_aucUbxCmd[ulCmdIndex][i];
        cCheckB += cCheckA;
    }

    transValue = g_aucUbxCmd[ulCmdIndex][0];

    if((transValue < 1) || (transValue >= sizeof(g_aucUbxCmd[ulCmdIndex])))
    {
        return BSP_ERROR;
    }

    g_aucUbxCmd[ulCmdIndex][(UINT32)(transValue - 1)] = cCheckA;
    g_aucUbxCmd[ulCmdIndex][g_aucUbxCmd[ulCmdIndex][0]] = cCheckB;
    return BSP_OK;
}

/*===================================================
函数名  ：  UbxSendCmdCfgRst
功能    ：  UBLOX接收机指令，复位接收机
返回值说明：UBLOX_INIT_RESET
======================================================*/
ULONG UbxSendCmdCfgRst(void)
{
    UbxUartSendData(UBLOX_INIT_RESET);
    GPS_LOG(GPS_DBG_UBX_DRV, "ubx cmd: cold reset ublox receiver!\n");
    return(UBLOX_INIT_RESET);
}

/*===================================================
函数名  ：  UbxSendCmdMonVer
功能    ：  UBLOX接收机指令，查询接收机版本，区分4T和5T
返回值说明：UBLOX_INIT_MON_VER
======================================================*/
ULONG UbxSendCmdMonVer(void)
{
    UbxUartSendData(UBLOX_INIT_MON_VER);
    return (UBLOX_INIT_MON_VER);
}

/*===================================================
函数名  ：  UbxSendCmdCloseAllMsg
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CLOSE_MSG
======================================================*/
ULONG UbxSendCmdCloseAllMsg(void)
{
    UbxUartSendData(UBLOX_INIT_CLOSE_MSG);
    return (UBLOX_INIT_CLOSE_MSG);
}

/*===================================================
函数名  ：  UbxSendCmdCfgTp
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_TP
======================================================*/
ULONG UbxSendCmdCfgTp(void)
{
    UbxUartSendData(g_tUbxCmdPara[UBX_CFG_TP_IDX].ucCmdIdx);
    return (g_tUbxCmdPara[UBX_CFG_TP_IDX].ulAckRet);
}

/*===================================================
函数名  ：  UbxSendCmdCfgAnt
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_ANT
======================================================*/
ULONG UbxSendCmdCfgAnt(void)
{
    if(IS_MULTI_RCV(g_IntRcvDrvData->ucRcvVersion))
    {
        g_aucUbxCmd[UBLOX_INIT_CFG_ANT][7]  = 0x1B;
        g_aucUbxCmd[UBLOX_INIT_CFG_ANT][9]  = 0xF0;
        g_aucUbxCmd[UBLOX_INIT_CFG_ANT][10] = 0x7D;
    }
    else
    {
        g_aucUbxCmd[UBLOX_INIT_CFG_ANT][7]  = 0x1F;
        g_aucUbxCmd[UBLOX_INIT_CFG_ANT][9]  = 0x0F;
        g_aucUbxCmd[UBLOX_INIT_CFG_ANT][10] = 0x38;
    }

    /* 重新计算校验和 */
    UbxUpdateCheckSum(4);
    UbxUartSendData(UBLOX_INIT_CFG_ANT);
    return (UBLOX_INIT_CFG_ANT);
}

/*===================================================
函数名  ：  UbxSendCmdMonHw
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_MON_ANT
======================================================*/
ULONG UbxSendCmdMonHw(void)
{
    UbxUartSendData(UBLOX_INIT_MON_ANT);
    return (UBLOX_INIT_MON_ANT);
}

/*===================================================
函数名  ：  UbxSendCmdCfgNav2
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_NAV
======================================================*/
ULONG UbxSendCmdCfgNav2(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_NAV);
    return (UBLOX_INIT_CFG_NAV);
}

/*===================================================
函数名  ：  UbxSendCmdCfgTmode
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_TMODE
======================================================*/
ULONG UbxSendCmdCfgTmode(void)
{
    UbxUartSendData(g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucCmdIdx);
    return (g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ulAckRet);
}

/*===================================================
函数名  ：  UbxSendCmdCfgMsgNavSol
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_MSG_NAV_SOL
======================================================*/
ULONG UbxSendCmdCfgMsgNavSol(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_MSG_NAV_SOL);
    return (UBLOX_INIT_CFG_MSG_NAV_SOL);
}

/*===================================================
函数名  ：  UbxSendCmdCfgMsgNavPosllh
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_MSG_NAV_POSLLH
======================================================*/
ULONG UbxSendCmdCfgMsgNavPosllh(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_MSG_NAV_POSLLH);
    return (UBLOX_INIT_CFG_MSG_NAV_POSLLH);
}

/*===================================================
函数名  ：  UbxSendCmdCfgMsgNavTimegps
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_MSG_NAV_TIMEGPS
======================================================*/
ULONG UbxSendCmdCfgMsgNavTimegps(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_MSG_NAV_TIMEGPS);
    return (UBLOX_INIT_CFG_MSG_NAV_TIMEGPS);
}

/*===================================================
函数名  ：  UbxSendCmd5TCloseGpgll
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_5T_CLOSE_MSG_GPGLL
======================================================*/
ULONG UbxSendCmd5TCloseGpgll(void)
{
    UbxUartSendData(UBLOX_INIT_5T_CLOSE_MSG_GPGLL);
    return (UBLOX_INIT_5T_CLOSE_MSG_GPGLL);
}

/*===================================================
函数名  ：  UbxSendCmd5TCfgGpgsv
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_5T_CFG_MSG_GPGSV
======================================================*/
ULONG UbxSendCmd5TCfgGpgsv(void)
{
    UbxUartSendData(UBLOX_INIT_5T_CFG_MSG_GPGSV);
    return (UBLOX_INIT_5T_CFG_MSG_GPGSV);
}

/*===================================================
函数名  ：  UbxSendCmd5TCloseGprmc
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_5T_CLOSE_MSG_GPRMC
======================================================*/
ULONG UbxSendCmd5TCloseGprmc(void)
{
    UbxUartSendData(UBLOX_INIT_5T_CLOSE_MSG_GPRMC);
    return (UBLOX_INIT_5T_CLOSE_MSG_GPRMC);
}

/*===================================================
函数名  ：  UbxSendCmd5TCloseGpvtg
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_5T_CLOSE_MSG_GPVTG
======================================================*/
ULONG UbxSendCmd5TCloseGpvtg(void)
{
    UbxUartSendData(UBLOX_INIT_5T_CLOSE_MSG_GPVTG);
    return (UBLOX_INIT_5T_CLOSE_MSG_GPVTG);
}

/*===================================================
函数名  ：  UbxSendCmd5TCloseGpzda
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_5T_CLOSE_MSG_GPZDA
======================================================*/
ULONG UbxSendCmd5TCloseGpzda(void)
{
    UbxUartSendData(UBLOX_INIT_5T_CLOSE_MSG_GPZDA);
    return (UBLOX_INIT_5T_CLOSE_MSG_GPZDA);
}

/*===================================================
函数名  ：  UbxSendCmd5TCfgNav5
功能    ：  UBLOX接收机指令, 5T
返回值说明：UBLOX_INIT_5T_CFG_NAV5
======================================================*/
ULONG UbxSendCmd5TCfgNav5(void)
{
    if(IS_MULTI_RCV(g_IntRcvDrvData->ucRcvVersion))
    {
        /* 修改指令参数 */
        g_aucUbxCmd[UBLOX_INIT_5T_CFG_NAV5][30] = 0x3C;  /* DGPS timeout */
        g_aucUbxCmd[UBLOX_INIT_5T_CFG_NAV5][35] = 0xC8;  /* staticHoldMaxDist */
        g_aucUbxCmd[UBLOX_INIT_5T_CFG_NAV5][37] = 0x03;  /* utcStandard */
    }
    else
    {
        /* 修改指令参数 */
        g_aucUbxCmd[UBLOX_INIT_5T_CFG_NAV5][30] = 0x00;
        g_aucUbxCmd[UBLOX_INIT_5T_CFG_NAV5][35] = 0x00;
        g_aucUbxCmd[UBLOX_INIT_5T_CFG_NAV5][37] = 0x00;
    }
    /* 重新计算校验和 */
    UbxUpdateCheckSum(UBLOX_INIT_5T_CFG_NAV5);
    UbxUartSendData(UBLOX_INIT_5T_CFG_NAV5);
    return (UBLOX_INIT_5T_CFG_NAV5);
}

/*===================================================
函数名  ：  UbxSendCmd5TCfgTp
功能    ：  UBLOX接收机指令, 5T
返回值说明：UBLOX_INIT_5T_CFG_TP
======================================================*/
ULONG UbxSendCmd5TCfgTp(void)
{
    UbxUartSendData(UBLOX_INIT_5T_CFG_TP);
    return (UBLOX_INIT_5T_CFG_TP);
}

/*===================================================
函数名  ：  UbxSendCmd5TCfgTmodeQuery
功能    ：  UBLOX接收机指令, 5T
返回值说明：UBLOX_INIT_5T_CFG_TMODE_QUERY
======================================================*/
ULONG UbxSendCmd5TCfgTmodeQuery(void)
{
    UbxUartSendData(g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucCmdIdx);
    return g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ulAckRet;
}

/*===================================================
函数名  ：  UCHAR UbxSendCmdCfgSbas(void)
功能    ：  UBLOX接收机指令
返回值说明：UBLOX_INIT_CFG_SBAS
======================================================*/
ULONG UbxSendCmdCfgSbas(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_SBAS);
    return (UBLOX_INIT_CFG_SBAS);
}

/*===================================================
函数名  ：  UbxSendCmd5TCfgTp5
功能    ：  UBLOX接收机指令, 8M
返回值说明：32
======================================================*/
ULONG UbxSendCmdCfgTp5(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_TP5);
    return (UBLOX_INIT_CFG_TP5);
}

/*===================================================
函数名  ：  UbxSendCmdCfgTmode2
功能    ：  UBLOX接收机指令, 8M
返回值说明：33
======================================================*/
ULONG UbxSendCmdCfgTmode2(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_TMODE2);
    return (UBLOX_INIT_CFG_TMODE2);
}

/*===================================================
函数名  ：  UbxSendCmdCfgGnss
功能    ：  UBLOX接收机指令, 8M
返回值说明：34
======================================================*/
ULONG UbxSendCmdCfgGnss(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_GNSS);
    return (UBLOX_INIT_CFG_GNSS);
}

/*===================================================
函数名  ：  UbxSendCmdCfgTmode2Query
功能    ：  UBLOX接收机指令, 5T
返回值说明：35
======================================================*/
ULONG UbxSendCmdCfgTmode2Query(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_TMODE2_QUERY);
    return (UBLOX_INIT_CFG_TMODE2_QUERY);
}

/*===================================================
函数名  ：  UbxSendCmdCfgGnssQuery
功能    ：  UBLOX接收机指令, 8M
返回值说明：36
======================================================*/
ULONG UbxSendCmdCfgGnssQuery(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_GNSS_QUERY);
    return (UBLOX_INIT_CFG_GNSS_QUERY);
}

/*===================================================
函数名  ：  UbxSendCmdCfgNmea
功能    ：  UBLOX接收机指令, 8M
返回值说明：37
======================================================*/
ULONG UbxSendCmdCfgNmea(void)
{
    UbxUartSendData(UBLOX_INIT_CFG_NMEA);
    return (UBLOX_INIT_CFG_NMEA);
}

/*===================================================
函数名  ：  UbxSendCmdPollCfgTp
功能    ：  UBLOX接收机指令, 4T/5T/6T/8M
返回值说明：38/39
======================================================*/
ULONG UbxSendCmdPollCfgTp(void)
{
    UbxUartSendData(g_tUbxCmdPara[UBX_POLL_TP_IDX].ucCmdIdx);
    return g_tUbxCmdPara[UBX_POLL_TP_IDX].ulAckRet;
}

/*===================================================
函数名  ：  UbxSendCmdCfgBaudRate
功能    ：  UBLOX接收机指令, 4T/5T/6T/8M
返回值说明：40
======================================================*/
ULONG UbxSendCmdCfgBaudRate(ULONG ulBaudRate)
{
    g_aucUbxCmd[UBLOX_INIT_CFG_PRT][15] = ulBaudRate & 0xff;
    g_aucUbxCmd[UBLOX_INIT_CFG_PRT][16] = (ulBaudRate >> 8) & 0xff;
    g_aucUbxCmd[UBLOX_INIT_CFG_PRT][17] = (ulBaudRate >> 16) & 0xff;
    g_aucUbxCmd[UBLOX_INIT_CFG_PRT][18] = (ulBaudRate >> 24) & 0xff;

    /* 重新计算校验和 */
    UbxUpdateCheckSum(UBLOX_INIT_CFG_PRT);
    UbxUartSendData(UBLOX_INIT_CFG_PRT);
    GPS_LOG(GPS_DBG_INIT_PRN,"Set BaudRate %d\n", ulBaudRate);
    return UBLOX_INIT_CFG_PRT;
}

/*===================================================
函数名  ：  UbxSendCmdPollBaudRate
功能    ：  UBLOX接收机指令, 4T/5T/6T/8M
返回值说明：41
======================================================*/
ULONG UbxSendCmdPollBaudRate(void)
{
    UbxUartSendData(UBLOX_INIT_POLL_CFG_PRT);
    GPS_LOG(GPS_DBG_INIT_PRN,"Poll BaudRate\n");
    return UBLOX_INIT_POLL_CFG_PRT;
}

/**************************************************************************
* 函数名称： UbloxCreatePositionHoldCmd(double dX, double dY, double dZ)
* 功能描述： 转换经纬度、高度数据为接收机识别的指令，并生成位置保持模式配置指令
* 输入参数： dLongitude: 经度，单位度
*            dLatitude: 纬度，单位度
*            dAltitude: 高度，单位米
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明： Ublox
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-1-29   V1.0       SDRBSP            创建
**************************************************************************/
ULONG UbloxCreatePositionHoldCmd(double dX, double dY, double dZ)
{
    LONG  lLont, lLat, lAlt;
    ULONG ulCmdIdx = UBLOX_INIT_CFG_TMODE;

    lLont = (long)(dX * 100);
    lLat  = (long)(dY * 100);
    lAlt  = (long)(dZ * 100);
    GPS_LOG(GPS_DBG_UBX_DRV, "x = %ld cm, y = %ld cm, z = %ld cm.\n", lLont, lLat, lAlt);
    /* 将survey in模式改为fixed模式 */
    g_aucUbxCmd[ulCmdIdx][7] = 2;
    /* 写入坐标 */
    g_aucUbxCmd[ulCmdIdx][11] = (lLont      ) & 0xff;
    g_aucUbxCmd[ulCmdIdx][12] = (lLont >> 8 ) & 0xff;
    g_aucUbxCmd[ulCmdIdx][13] = (lLont >> 16) & 0xff;
    g_aucUbxCmd[ulCmdIdx][14] = (lLont >> 24) & 0xff;

    g_aucUbxCmd[ulCmdIdx][15] = (lLat      ) & 0xff;
    g_aucUbxCmd[ulCmdIdx][16] = (lLat >> 8 ) & 0xff;
    g_aucUbxCmd[ulCmdIdx][17] = (lLat >> 16) & 0xff;
    g_aucUbxCmd[ulCmdIdx][18] = (lLat >> 24) & 0xff;

    g_aucUbxCmd[ulCmdIdx][19] = (lAlt      ) & 0xff;
    g_aucUbxCmd[ulCmdIdx][20] = (lAlt >> 8 ) & 0xff;
    g_aucUbxCmd[ulCmdIdx][21] = (lAlt >> 16) & 0xff;
    g_aucUbxCmd[ulCmdIdx][22] = (lAlt >> 24) & 0xff;

    /* 重新计算校验和 */
    UbxUpdateCheckSum(ulCmdIdx);
    return BSP_OK;
}

/**************************************************************************
* 函数名称： UbloxCreateAutoTimeModeCmd(void)
* 功能描述： 生成设置为survey in模式指令
* 输入参数：
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明： Ublox
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-1-29   V1.0       SDRBSP            创建
**************************************************************************/
ULONG UbloxCreateAutoTimeModeCmd(void)
{
    ULONG ulRetVal = BSP_OK;
    UCHAR ucCmdIdx = 0;

    ucCmdIdx = g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucCmdIdx;
    /* 设置为survey in模式 */
    g_aucUbxCmd[ucCmdIdx][7] = 1;
    /* 重新计算校验和 */
    UbxUpdateCheckSum(ucCmdIdx);
    return ulRetVal;
}

/**************************************************************************
* 函数名称： ULONG UbxCreateCableDelayCmd(long lLenth,T_GPS_RCV_DRV_DATA *pRcvDrvData)
* 功能描述： 转换线缆长度为接收机识别的指令
* 输入参数： ulLenth：线缆长度，单位：ns
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明： 用在级联时
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-1-29   V1.0       SDRBSP            创建
**************************************************************************/
ULONG UbxCreateCableDelayCmd(long lLenth, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    long lAntCableDelay = 0x32; /* 天馈线缆延时，单位ns */
    UCHAR ucCmdIdx = 0;
    UCHAR ucByteOffset = 0;

    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 入参保护，接收机支持的天馈线缆延时最大32767ns，即8355.585米的长度 */
    if (abs(lLenth) > UBLOX_ANT_CABLE_MAX_LEN)
    {
        return BSP_ERROR_INVALID_PARA;
    }

    lAntCableDelay = (lLenth * 1000) / (3 * 85);  /* 计算天馈线缆延时。 */
    if (NULL != pGpsGetSel8tFunc)
    {
        lAntCableDelay += UBLOX_ANT_CABLE_DEV_DELAY; /* 新增代码：增加补偿140ns 器件延时加起来（主要是差分与单端之间的转换）有140ns左右 */
    }
    ucCmdIdx = g_tUbxCmdPara[UBX_CFG_TP_IDX].ucCmdIdx;
    ucByteOffset = g_tUbxCmdPara[UBX_CFG_TP_IDX].ucByteOffset;
    /* 加上payload前的部分 */
    ucByteOffset += (UBX_MSG_PAYLOAG_OFFSET + 1);

    if(ucCmdIdx >= GNSS_CMD_MAX_NUM)
    {
        return BSP_ERROR;
    }

    if(ucByteOffset < (GNSS_CMD_MAX_LEN-1))
    {
        g_aucUbxCmd[ucCmdIdx][ucByteOffset]     = (char)(lAntCableDelay & 0xff);
    }

    if((ucByteOffset + 1) < (GNSS_CMD_MAX_LEN - 1))
    {
        g_aucUbxCmd[ucCmdIdx][(UINT32)(ucByteOffset + 1)] = (UCHAR)((lAntCableDelay >> 8) & 0xff);
    }

    UbxUpdateCheckSum(ucCmdIdx);

    return BSP_OK;
}

/**************************************************************************
* 函数名称: UbxCreateCfgWorkModeCmd
* 功能描述: 生成接收机识别的接收机工作模式指令
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明: QZSS必须和GPS同时使能
* 修改日期     版本号     修改人     修改内容
* ------------------------------------------------------------------------
* 2014-09-08    V1.0      张全士       创建
**************************************************************************/
ULONG UbxCreateCfgWorkModeCmd(T_GPS_RCV_DRV_DATA *pRcvData)
{
    ULONG ulRetVal = BSP_OK;
    if(NULL == pRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    switch(pRcvData->ulRcvWorkMode)
    {
        case OUTER_GPS_RECEIVER: /* gps */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][15] = 0x01; /* GPS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][23] = 0x00; /* SBAS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][31] = 0x00; /* BEIDOU */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][39] = 0x01; /* QZSS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][47] = 0x00; /* GLONASS */

            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<7);/* timegrid to use GPS */
            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<6);
            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] &= ~1;
            break;

        case OUTER_BD_RECEIVER: /* bd */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][15] = 0x00; /* GPS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][23] = 0x00; /* SBAS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][31] = 0x01; /* BEIDOU */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][39] = 0x00; /* QZSS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][47] = 0x00; /* GLONASS */

            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<7); /* timegrid to use BDS */
            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<6);
            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] |= 1;
            break;

        case OUTER_GLO_RECEIVER: /* glo */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][15] = 0x00; /* GPS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][23] = 0x00; /* SBAS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][31] = 0x00; /* BEIDOU */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][39] = 0x00; /* QZSS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][47] = 0x01; /* GLONASS */

            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] &= ~(1<<7); /* timegrid to use gln */
            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<6);
            g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] |= 1;

            break;

        case OUTER_GPS_BD_RECEIVER:
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][15] = 0x01; /* GPS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][23] = 0x00; /* SBAS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][31] = 0x01; /* BEIDOU */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][39] = 0x01; /* QZSS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][47] = 0x00; /* GLONASS */

            /* 接收机初始化完成并且无GPS锁定卫星时，切换为北斗时，否则使用GPS时 */
            if((1 == pRcvData->ulRcvInitFinishFlag)\
            && (2 > pRcvData->ulLockedSatCnt[GPS_SAT_TYPE])\
            && (2 <= pRcvData->ulLockedSatCnt[BEIDOU_SAT_TYPE]) && (IS_MULTI_RCV(pRcvData->ucRcvVersion)))
            {
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<7); /* timegrid to use BDS */
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<6);
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] |= 1;
            }
            else
            {
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<7); /* timegrid to use GPS */
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<6);
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] &= ~1;
            }

            break;
        case OUTER_GPS_GLO_RECEIVER: /* GPS-GLO */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][15] = 0x01; /* GPS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][23] = 0x00; /* SBAS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][31] = 0x00; /* BEIDOU */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][39] = 0x01; /* QZSS */
            g_aucUbxCmd[UBLOX_INIT_CFG_GNSS][47] = 0x01; /* GLONASS */

            if((1 == pRcvData->ulRcvInitFinishFlag) \
            && (2 > pRcvData->ulLockedSatCnt[GPS_SAT_TYPE])\
            && (2 <= pRcvData->ulLockedSatCnt[GLONSS_SAT_TYPE]))
            {
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] &= ~(1<<7); /* timegrid to use GLN */
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<6);
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] |= 1;
            }
            else
            {
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<7); /* timegrid to use GPS */
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][35] |= (1<<6);
                g_aucUbxCmd[UBLOX_INIT_CFG_TP5][36] &= ~1;
            }
            break;

         default:
            ulRetVal = BSP_ERROR;
            break;
    }
    UbxUpdateCheckSum(UBLOX_INIT_CFG_GNSS);
    UbxUpdateCheckSum(UBLOX_INIT_CFG_TP5);
    return ulRetVal;
}

/***************************************************************************
* 函数名称： UbxCfgMsgOut
* 功能描述： 设置UBX/泰斗接收机电文输出
* 输入参数： ulRefId 时钟源: 1 内置； 2 外置面板；3 外置背板
             ucMsgId: 电文编号
                     DTM 0x0A
                     GBS 0x09
                     GGA 0x00
                     GLL 0x01
                     GPQ 0x40
                     GRS 0x06
                     GSA 0x02
                     GST 0x07
                     GSV 0x03
                     RMC 0x04
                     TXT 0x41
                     VTG 0x05
                     ZDA 0x08
           ucRate:输出速率,1秒内输出的次数，0表示不输出
* 输出参数： 无
* 返 回 值： BSP_OK:成功；BSP_ERROR:失败
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2014/3/19    V1.0       刘骏儒         创建
**************************************************************************/
ULONG UbxCfgMsgOut(ULONG ulRefId, UCHAR ucClassId, UCHAR ucMsgId, UCHAR ucRate)
{
    ULONG ulRetVal = BSP_OK;
    UCHAR aucMsg[] =
       {0XB5,0X62,0X06,0X01,0X03,0X00,
        0XF0,0X00,0X00, /* GPGGA */
        0X00,0X00};

    aucMsg[6] = ucClassId;
    aucMsg[7] = ucMsgId;
    aucMsg[8] = ucRate;

    UbxCalcCheckSum(sizeof(aucMsg), aucMsg);

    ulRetVal = GpsUartOutput(sizeof(aucMsg), aucMsg);

    return ulRetVal;
}

/**************************************************************************
* 函数名称： void UbxGpsReceiverInit(T_GPS_RCV_DRV_DATA *pRcvData)
* 功能描述： ublox接收机初始化
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
void UbxGpsReceiverInit(T_GPS_RCV_DRV_DATA *pRcvData)
{
    T_GPS_RCV_DRV_DATA *pRcvDataInit = NULL;
    /* ULONG ulGpsSendCmdValue = 0; */
    ULONG ulRetVal = BSP_OK;

    if (NULL == pRcvData)
    {
        return;
    }

    pRcvDataInit = pRcvData; /* 入参实例数据指针赋值 */
    /* 20次打印一次 */
    if (20 < (pRcvDataInit->ulRcvInitCnt))
    {
        pRcvDataInit->ulRcvInitCnt = 0;
        GPS_LOG(GPS_DBG_UBX_DRV, "UBLOX receiver enter init stage%d, tick = %d.\n",
                pRcvDataInit->ucRcvInitStep, tickGet());
    }
    else
    {
        pRcvDataInit->ulRcvInitCnt++;
    }

    switch (pRcvDataInit->ucRcvInitStep)
    {
        case UBLOX_INIT_RESET:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgRst, pRcvDataInit);
            pRcvDataInit->ucRcvInitStep = UBLOX_INIT_MON_VER;
            break;
        case UBLOX_INIT_MON_VER:
            #if 0
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            if((115200 != gulUbxBaudRate) && (IS_MULTI_RCV(pRcvDataInit->ucRcvVersion)))
            {
                pRcvDataInit->ulResv = 0;
                GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_PRT;
                break;
            }
            #endif
            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdMonVer, pRcvDataInit))
            {
                switch (pRcvDataInit->ucRcvVersion)
                {
                    case UBLOX_VERSION_4T:
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CLOSE_MSG;
                        break;
                    case UBLOX_VERSION_5T:
                    case UBLOX_VERSION_6T:
                    case UBLOX_VERSION_8T:
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_5T_CLOSE_MSG_GPGLL;
                        break;
                    default:
                        break;
                }
            }
            break;
        case UBLOX_INIT_CLOSE_MSG:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCloseAllMsg, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_TP;
            }
            break;
        case UBLOX_INIT_CFG_TP:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            /* 根据配置参数生成指令 */
            if (BSP_OK != UbxCreateCableDelayCmd(pRcvDataInit->lAntCabDelay, pRcvDataInit))
            {
                /* 参数无效则直接跳过 */
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_ANT;
                break;
            }

            if(BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgTp,pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_ANT;
            }
            break;

        case UBLOX_INIT_CFG_ANT:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgAnt, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_MON_ANT;
            }
            break;
            /* 天馈状态由逻辑检测 */
        case UBLOX_INIT_MON_ANT:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            if(BSP_CLOCK_REF_INTERNAL_GPS != pRcvDataInit->ulRcvPlace)
            {
                GpsSendCmd((UGpsFunPtr)UbxSendCmdMonHw, pRcvDataInit); /* 直接发送命令，不做返回值判断 2010-3-26 9:37:59 */
            }
            pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_NAV;
            break;
        case UBLOX_INIT_CFG_NAV:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            switch (pRcvDataInit->ucRcvVersion)
            {
                case UBLOX_VERSION_4T:

                    if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgNav2, pRcvDataInit))
                    {
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_TMODE;
                    }
                    break;
                case UBLOX_VERSION_5T:
                case UBLOX_VERSION_6T:
                case UBLOX_VERSION_8T:

                    if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmd5TCfgNav5, pRcvDataInit))
                    {
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_TMODE;
                    }
                    break;
                default:
                    break;
            }
            break;
        case UBLOX_INIT_CFG_TMODE:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            if(BSP_OK != UbloxCreatTimeModeCmd(pRcvDataInit))   /* 根据配置参数生成指令 */
            {   /* 参数无效则直接跳过 */
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_SBAS;
                break;
            }
            switch (pRcvDataInit->ucRcvVersion)
            {
                case UBLOX_VERSION_4T:

                    if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgTmode, pRcvDataInit))
                    {
                        pRcvDataInit->ulUsingTimeMode = pRcvDataInit->ulTimeMode;
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_SBAS;
                    }
                    break;
                case UBLOX_VERSION_5T:
                case UBLOX_VERSION_6T:
                case UBLOX_VERSION_8T:
                    pRcvDataInit->ulSetTMode = 1; /* 配置状态机写1 */
                    if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgTmode, pRcvDataInit))
                    {
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_5T_CFG_TMODE_QUERY;
                    }

                    break;
                default:
                    break;
            }
            break;
        case UBLOX_INIT_CFG_SBAS:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgSbas, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_MSG_NAV_SOL;
            }
            break;
        case UBLOX_INIT_CFG_MSG_NAV_SOL:

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgMsgNavSol, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_MSG_NAV_POSLLH;
            }
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            break;
        case UBLOX_INIT_CFG_MSG_NAV_POSLLH:

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgMsgNavPosllh, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_MSG_NAV_TIMEGPS;
            }
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            break;
        case UBLOX_INIT_CFG_MSG_NAV_TIMEGPS:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgMsgNavTimegps, pRcvDataInit))
            {
                pRcvDataInit->ulRcvInitFinishFlag  = 1;
                pRcvDataInit->ulRcvInitFinishTime = GetBookTime();
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_RESET;
                GPS_LOG(GPS_DBG_UBX_DRV, "UBLOX receiver initialize finished!\n");
                return;
            }
            break;
            /* 5T接收机初始化步骤 */
        case UBLOX_INIT_5T_CLOSE_MSG_GPGLL:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmd5TCloseGpgll, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_5T_CFG_MSG_GPGSV;
            }
            break;
        case UBLOX_INIT_5T_CFG_MSG_GPGSV:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmd5TCfgGpgsv, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_5T_CLOSE_MSG_GPRMC;
            }
            break;
        case UBLOX_INIT_5T_CLOSE_MSG_GPRMC:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmd5TCloseGprmc, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_5T_CLOSE_MSG_GPVTG;
            }
            break;
        case UBLOX_INIT_5T_CLOSE_MSG_GPVTG:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmd5TCloseGpvtg, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_5T_CLOSE_MSG_GPZDA;
            }
            break;
        case UBLOX_INIT_5T_CLOSE_MSG_GPZDA:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);

            if (BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmd5TCloseGpzda, pRcvDataInit))
            {
                if(IS_MULTI_RCV(pRcvDataInit->ucRcvVersion))
                {
                    #if 0
                    if(115200 != gulUbxBaudRate)
                    {
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_PRT;
                    }
                    else
                    {
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_NMEA;
                    }
                    #else
                    pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_NMEA;
                    #endif
                }
                else
                {
                    pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_TP;
                }
            }
            break;
        case UBLOX_INIT_5T_CFG_TMODE_QUERY:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            pRcvDataInit->ulGetTMode = 1; /* 查询状态机写1 */
            if((BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmd5TCfgTmodeQuery,pRcvDataInit))
               && (pRcvDataInit->ulUsingTimeMode == pRcvDataInit->ulTimeMode))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_SBAS;
                pRcvDataInit->ucCurWaitCnt = 0;
            }
            else
            {
                pRcvDataInit->ucCurWaitCnt++;
                if(pRcvDataInit->ucCurWaitCnt > 2)
                {
                    pRcvDataInit->ucCurWaitCnt = 0;
                    pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_TMODE;
                }
            }
            break;

        case UBLOX_INIT_CFG_PRT:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            if(BSP_OK == UbxCfgBaudRate(115200, pRcvDataInit))
            {
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_MON_VER;
            }
            break;

        case UBLOX_INIT_CFG_NMEA:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            if(BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgNmea, pRcvDataInit))
            {
                /* 关闭GPGGA输出 */
                UbxCfgMsgOut(pRcvDataInit->ulRcvPlace, 0XF0, 0X00, 0);
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_GNSS;
            }
            break;

        case UBLOX_INIT_CFG_GNSS:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
            ulRetVal = UbxCreateCfgWorkModeCmd(pRcvDataInit);
            if(BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdCfgGnss, pRcvDataInit))
            {
                if(BSP_OK == ulRetVal)
                {
                    pRcvDataInit->ulRcvRealWorkMode = pRcvDataInit->ulRcvWorkMode;
                }
                pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_GNSS_QUERY;
            }
            break;
        case UBLOX_INIT_CFG_GNSS_QUERY:
            GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d): step= %d\n", __FUNCTION__, __LINE__, pRcvDataInit->ucRcvInitStep);
                    /* 查询当前接收机工作模式 */
                    if(BSP_OK == GpsSendCmd(UbxSendCmdCfgGnssQuery, pRcvDataInit))
                    {
                        pRcvDataInit->ucRcvInitStep = UBLOX_INIT_CFG_TP;
                    }
                    break;


        default:
            pRcvDataInit->ucRcvInitStep = UBLOX_INIT_RESET;
            break;
    }
}


/**************************************************************************
* 函数名称： ULONG UbxDecodePosition(const UCHAR *pucCmd, USHORT usCmdLen)
* 功能描述： 获取位置信息
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 成功： BSP_OK；
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
ULONG UbxDecodePosition(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    LONG  lLong, lLat, lHeight;
    T_GPS_RCV_DRV_DATA *pPositionRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pPositionRcvData = pRcvDrvData;

    /* 电文合法性检测 */
    if ((NULL == pucCmd) || (28 != usCmdLen))
    {
        return 0xFF;
    }


    lLat  = UBLOX_LONG(pucCmd + 8); /* latitud-纬度 */
    lLong = UBLOX_LONG(pucCmd + 4); /* longitud-经度 */
    lHeight = UBLOX_LONG(pucCmd + 12);/* Height above Ellipsoid */

    GPS_LOG(GPS_DBG_UBX_DRV, "latitud:%ld.%07d,longitud:%ld.%07d,evelation:%ld.%03d\n",
            lLat / 10000000, abs(lLat % 10000000),
            lLong / 10000000, abs(lLong % 10000000),
            lHeight / 1000, abs(lHeight % 1000));
    /* 转换为后台所需类型。经纬度单位: 1/3600000度；高度单位: 厘米 */
    pPositionRcvData->tPositionInfo.lLongitude = (lLong / 100) * 36;
    pPositionRcvData->tPositionInfo.lLatitude = (lLat / 100) * 36;
    pPositionRcvData->tPositionInfo.lAltitude = lHeight / 10;
    return UBLOX_INIT_CFG_MSG_NAV_POSLLH;
}

/**************************************************************************
* 函数名称： ClockChangeDaysToMonDay(T_Clock_Tod *D)
* 功能描述： 获取实时UTC时间
* 输入参数： TOD信息
* 输出参数： 无
* 返 回 值： 成功： BSP_OK；
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
ULONG ClockChangeDaysToMonDay(T_Clock_Tod *D)
{
    UCHAR    MON_DAYS[13] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31, 0};
    UCHAR    i;
    USHORT   usDaysOfPreviousMonths = 0;

    /* 入参检测 */
    if (NULL == D)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 如果是闰年，则二月份为29天 */
    if (TRUE == ClockLeapYearCheck(D->YEAR))
    {
        MON_DAYS[1] = 29;
    }

    for (i = 0; i < 12; i++)
    {
        if (D->DAYS < (usDaysOfPreviousMonths + MON_DAYS[i]))
        {
            break;
        }
        else
        {
            usDaysOfPreviousMonths += MON_DAYS[i];
        }
    }

    D->MON = i + 1;
    D->DAY = (UCHAR)(D->DAYS - usDaysOfPreviousMonths);
    /* 天数转换成月日时需要加上1 */
    D->DAY += 1;
    return BSP_OK;
}


/**************************************************************************
* 函数名称： ULONG UbxDecodeGpsTime(UCHAR *pucCmd, USHORT usCmdLen)
* 功能描述： 获取实时GPS时间
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 成功： 10
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
ULONG UbxDecodeGpsTime(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG WeekSecond;
    UCHAR weekday, temp;
    USHORT DayOfTime = 0, temdays = 0, lastyeardays = 0, temyear = 1980;
    ULONG ulSecond, ulTmp;
    ULONG ulGpsSecond = 0;
    USHORT usGpsWeek = 0;
    ULONG ulCmpOkFlag = 0;
    ULONG ulLockSatCnt = 0;
    T_Clock_Tod tLocalGpsDate;
    T_GPS_RCV_DRV_DATA *pGpsTimeRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pGpsTimeRcvData = pRcvDrvData;

    /* 电文合法性检测 */
    if ((NULL == pucCmd) || (16 != usCmdLen))
    {
        return 0xff;
    }

    temp = pucCmd[11];
    if ((temp & 0x03) != 0x03)
    {
        return 0; /*时间无效则返回*/
    }

    /* 闰秒有效才解析 */
    if (0x04 == (temp & 0x04))
    {
        pGpsTimeRcvData->ucLeapSeconds = pucCmd[10]; /* 闰秒信息 */
    }
    else
    {
        pGpsTimeRcvData->ucLeapSeconds = 16;
    }

    WeekSecond = UBLOX_ULONG(pucCmd);
    ulSecond = ((WeekSecond + 500) / 1000); /*ms到s,当前星期的秒的时间,浮点数*/
    ulGpsSecond = ulSecond; /* 保存GPS SECOND */
    ulTmp = ulSecond / SEC_OF_DAY;
    weekday = (UCHAR)ulTmp; /*s到天，当前星期的天的浮点数*/
    ulSecond = ulSecond - ulTmp * SEC_OF_DAY;
    ulTmp = ulSecond / 3600;
    tLocalGpsDate.HOUR = (UCHAR)ulTmp;  /*得到当前时*/
    ulSecond = ulSecond - ulTmp * 3600;
    ulTmp = ulSecond / 60; /*分的浮点数*/
    tLocalGpsDate.MIN = (UCHAR)ulTmp;   /*得到当前分*/
    ulSecond = ulSecond - ulTmp * 60;
    ulTmp = ulSecond;
    tLocalGpsDate.SEC = (UCHAR)ulTmp;   /*得到当前秒*/

    usGpsWeek = UBLOX_USHORT(pucCmd + 8);
    DayOfTime = usGpsWeek * 7 + 5; /*1980年1月1号0时起*/
    DayOfTime = DayOfTime + weekday;/*计算出1980年到现在的总天数*/
    GPS_LOG(GPS_DBG_UBX_DRV, "DECODE: week = %d, second = %d. DayOfTime = %d. weekday = %d. tick = %d.\n", \
            usGpsWeek, ulGpsSecond, DayOfTime, weekday, tickGet());

    while (temdays <= DayOfTime)
    {
        lastyeardays = temdays; /*保存到上一年的总天数*/
        temdays = temdays + ClockCalcDaysInCertainYear(temyear);
        temyear++;
    }

    tLocalGpsDate.YEAR = temyear - 1;/*得到当前年*/
    tLocalGpsDate.DAYS = DayOfTime - lastyeardays; /*得到当前天数*/
    ClockChangeDaysToMonDay(&tLocalGpsDate); /*得到当前月日数*/
    /* gps时间赋值给实例 */
    memcpy_s(&(pGpsTimeRcvData->tGpsDate), sizeof(tLocalGpsDate), &tLocalGpsDate, sizeof(tLocalGpsDate));

    ClockChangeDaysToMonDay(&(pGpsTimeRcvData->tGpsDate)); /*得到驱动实例当前月日数*/

    if (1 == pGpsTimeRcvData->ulRcvInitFinishFlag)
    {
        /*---------------------------------------------------------------*/
        /* 比较电文tod和驱动本地维护tod时间是否差1 */
        ClockIncrementTime(&(pGpsTimeRcvData->tLastGpsDate));/* 驱动本地维护tod更新 */
        ClockChangeDaysToMonDay(&(pGpsTimeRcvData->tLastGpsDate)); /*得到当前月日数*/
        /* 判断电文解析的tod是否是累加1 */
        if ((pGpsTimeRcvData->tLastGpsDate.YEAR == pGpsTimeRcvData->tGpsDate.YEAR)
            && (pGpsTimeRcvData->tLastGpsDate.DAYS == pGpsTimeRcvData->tGpsDate.DAYS)
            && (pGpsTimeRcvData->tLastGpsDate.HOUR == pGpsTimeRcvData->tGpsDate.HOUR)
            && (pGpsTimeRcvData->tLastGpsDate.MIN == pGpsTimeRcvData->tGpsDate.MIN)
            && (pGpsTimeRcvData->tLastGpsDate.SEC == pGpsTimeRcvData->tGpsDate.SEC))
        {
            ulCmpOkFlag = 1;
        }
        else
        {
            pGpsTimeRcvData->ulSatTodAbnormalTimes++;/* 统计tod跳秒次数 */
            GPS_LOG(GPS_DBG_UBX_DRV, "ublox rcv appear jump tod,check it.\n");
            GPS_LOG(GPS_DBG_UBX_DRV, "TOD: %d-%d-%d | %d:%d:%d. (last time)\n",
                pGpsTimeRcvData->tLastGpsDate.YEAR, pGpsTimeRcvData->tLastGpsDate.MON,
                pGpsTimeRcvData->tLastGpsDate.DAY, pGpsTimeRcvData->tLastGpsDate.HOUR,
                pGpsTimeRcvData->tLastGpsDate.MIN, pGpsTimeRcvData->tLastGpsDate.SEC);
            GPS_LOG(GPS_DBG_UBX_DRV, "TOD: %d-%d-%d | %d:%d:%d. (cur time)\n",
                pGpsTimeRcvData->tGpsDate.YEAR, pGpsTimeRcvData->tGpsDate.MON,
                pGpsTimeRcvData->tGpsDate.DAY, pGpsTimeRcvData->tGpsDate.HOUR,
                pGpsTimeRcvData->tGpsDate.MIN, pGpsTimeRcvData->tGpsDate.SEC);
        }

        /* 天馈正常、
              搜星数不为零(或者是大于设定的最小搜星数)、
              电文解析的tod是连续增长的*/
        ulLockSatCnt = (pGpsTimeRcvData->ulLockedSatCnt[GPS_SAT_TYPE] + pGpsTimeRcvData->ulLockedSatCnt[BEIDOU_SAT_TYPE]);
        if ((GPS_ANTENNA_STATE_OK == pGpsTimeRcvData->ulRcvAntennaStateShow)
            && (0 != ulLockSatCnt)
            && (1 == ulCmpOkFlag))
        {
            pGpsTimeRcvData->ulRcvTodOkCnt++;

            if (100 <= pGpsTimeRcvData->ulRcvTodOkCnt)
            {
                pGpsTimeRcvData->ulRcvTodOkCnt = 100;/* 防止计数变量溢出 */
            }
        }
        else
        {
            pGpsTimeRcvData->ulRcvTodOkCnt = 0;
        }

        /* 计算驱动tod是否可用标志 */
        if (30 < pGpsTimeRcvData->ulRcvTodOkCnt)
        {
            pGpsTimeRcvData->ulRcvTodOkFlag = 1; /* 驱动解析tod可用 */
        }
        else
        {
            pGpsTimeRcvData->ulRcvTodOkFlag = 0; /* 驱动解析tod不可用 */
        }

        /* 更新驱动本地维护时间 */
        memcpy_s(&(pGpsTimeRcvData->tLastGpsDate), sizeof(tLocalGpsDate), &tLocalGpsDate, sizeof(tLocalGpsDate));

    }
    else
    {
        pGpsTimeRcvData->ulRcvTodOkFlag = 0; /* 驱动解析tod不可用，接收机重启时 */
        memcpy_s(&(pGpsTimeRcvData->tLastGpsDate), sizeof(tLocalGpsDate), &tLocalGpsDate, sizeof(tLocalGpsDate));
    }

    /*---------------------------------------------------------------*/
    GPS_LOG(GPS_DBG_UBX_DRV, "TOD: %d-%d-%d | %d:%d:%d. (GPS time)\n",
        tLocalGpsDate.YEAR, tLocalGpsDate.MON, tLocalGpsDate.DAY,
        tLocalGpsDate.HOUR, tLocalGpsDate.MIN, tLocalGpsDate.SEC);
    pGpsTimeRcvData->ulRcvMsgStas = 1;   /*电文接收正常*/
    return UBLOX_INIT_CFG_MSG_NAV_TIMEGPS;
}


/**************************************************************************
* 函数名称： ULONG UbxDecodeAntennaStatus(UCHAR *pucCmd, USHORT usCmdLen)
* 功能描述： 获取接收机天馈状态，看天馈是否正常
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 4：天馈正常
*            其他：天馈异常
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
ULONG UbxDecodeAntennaStatus(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    /* USHORT usMonHwCmdLen = 0; */
    /* ULONG ulGpsAntennaState = GPS_ANTENNA_STATE_DONTKNOW; */
    /* T_GPS_RCV_DRV_DATA *pAntStatusRcvData = NULL; */


    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }
#if 0
    pAntStatusRcvData = pRcvDrvData;

    /* 级联从框不使用天馈状态，直接默认成ok，但对外诊断为未知 */
    if (BSP_CLOCK_REF_SLAVE_PANNEL == pAntStatusRcvData->ulRcvPlace)
    {
        ulGpsAntennaState = GPS_ANTENNA_STATE_OK;
        GPS_LOG(GPS_DBG_UBX_DRV, "slave antenna status OK!\n");
    }
    else
    {
        if (UBLOX_VERSION_4T == pAntStatusRcvData->ucRcvVersion)/* 实测长度为0x48,手册上写的是64 */
        {
            usMonHwCmdLen = 0x48;
        }
        else if ((UBLOX_VERSION_5T == pAntStatusRcvData->ucRcvVersion) ||
                 (UBLOX_VERSION_6T == pAntStatusRcvData->ucRcvVersion))
        {
            usMonHwCmdLen = 0x44;
        }

        /* 电文入参检查 */
        if ((NULL == pucCmd) || (usMonHwCmdLen != usCmdLen))
        {
            return 0xff;
        }

        switch (pucCmd[20])
        {
            case 2:
                /* 天线正常 */
                ulGpsAntennaState = GPS_ANTENNA_STATE_OK;
                GPS_LOG(GPS_DBG_UBX_DRV, "antenna status OK!\n");
                break;
            case 0:
                /* 天线初始化 */
                ulGpsAntennaState = GPS_ANTENNA_STATE_INIT;
                GPS_LOG(GPS_DBG_UBX_DRV, "antenna status INIT!\n");
                break;
            case 1:
                /* 天线状态未知 */
                ulGpsAntennaState = GPS_ANTENNA_STATE_DONTKNOW;
                GPS_LOG(GPS_DBG_UBX_DRV, "antenna status DONTKNOW!\n");
                break;
            case 3:
                /* 天线短路告警 */
                ulGpsAntennaState = GPS_ANTENNA_STATE_SHORT;
                GPS_LOG(GPS_DBG_UBX_DRV, "antenna status SHORT!\n");
                break;
            case 4:
                /* 天线开路告警 */
                ulGpsAntennaState = GPS_ANTENNA_STATE_BREAK;
                GPS_LOG(GPS_DBG_UBX_DRV, "antenna status OPEN!\n");
                break;
            default:
                /* 天线状态未知 */
                ulGpsAntennaState = GPS_ANTENNA_STATE_DONTKNOW;
                GPS_LOG(GPS_DBG_UBX_DRV, "antenna status DONTKNOW!\n");
                break;
        }
    }

    bookTime = GetBookTime();
    if (pAntStatusRcvData->ulRcvAntennaLastState == ulGpsAntennaState)
    {
        if ((bookTime - pAntStatusRcvData->ulRcvAntennaStateStart) >= 10)
        {
            pAntStatusRcvData->ulRcvAntennaStateStart = bookTime;
            pAntStatusRcvData->ulRcvAntennaState = ulGpsAntennaState;
        }
    }
    else
    {
        pAntStatusRcvData->ulRcvAntennaStateStart = bookTime;
        pAntStatusRcvData->ulRcvAntennaLastState = ulGpsAntennaState;
    }
#endif
    return UBLOX_INIT_MON_ANT;
}

/**************************************************************************
* 函数名称: UbxCfgDataInit
* 功能描述: 接收机配置数据初始化
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期     版本号     修改人     修改内容
* ------------------------------------------------------------------------
* 2014-09-28    V1.0      张全士       创建
**************************************************************************/
ULONG UbxCfgDataInit(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    if(NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    switch(pRcvDrvData->ucRcvVersion)
    {
        case UBLOX_VERSION_5T:
        case UBLOX_VERSION_6T:
        case TD_VERSION_T302G:
        case TD_VERSION_T303G:
            pRcvDrvData->ulRcvRealWorkMode = OUTER_GPS_RECEIVER;
            /* CFG-TP */
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucCmdIdx = 17;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ulAckRet = UBLOX_INIT_5T_CFG_TP;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucPayLoadLen = 20;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucByteOffset = 12;
            /* POLL-TP */
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucCmdIdx = 38;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ulAckRet = UBLOX_INIT_5T_CFG_TP;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucPayLoadLen = 0;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucByteOffset = 0;
            /* CFG-TMODE */
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucCmdIdx = 7;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ulAckRet = UBLOX_INIT_CFG_TMODE;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucPayLoadLen = 28;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucByteOffset = 0;
            /* CFG-TMODE_QUERY */
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucCmdIdx = 18;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ulAckRet = UBLOX_INIT_5T_CFG_TMODE_QUERY;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucPayLoadLen = 0;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucByteOffset = 0;
            break;

        case UBLOX_VERSION_8T:
        case TD_VERSION_T302:
        case TD_VERSION_T303:
            /* CFG-TP */
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucCmdIdx = 32;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ulAckRet = UBLOX_INIT_CFG_TP5;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucPayLoadLen = 32;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucByteOffset = 4;
            /* POLL-TP */
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucCmdIdx = 39;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ulAckRet = UBLOX_INIT_CFG_TP5;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucPayLoadLen = 0;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucByteOffset = 0;
            /* CFG-TOMD */
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucCmdIdx = 33;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ulAckRet = UBLOX_INIT_CFG_TMODE;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucPayLoadLen = 28;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucByteOffset = 0;
            /* CFG-TMODE_QUERY */
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucCmdIdx = 35;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ulAckRet = UBLOX_INIT_5T_CFG_TMODE_QUERY;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucPayLoadLen = 0;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucByteOffset = 0;
            break;

        case UBLOX_VERSION_4T:
            pRcvDrvData->ulRcvRealWorkMode = OUTER_GPS_RECEIVER;
            /* CFG-TP */
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucCmdIdx = 3;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ulAckRet = UBLOX_INIT_CFG_TP;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucPayLoadLen = 20;
            g_tUbxCmdPara[UBX_CFG_TP_IDX].ucByteOffset = 12;
            /* POLL-TP */
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucCmdIdx = 38;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ulAckRet = UBLOX_INIT_5T_CFG_TP;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucPayLoadLen = 0;
            g_tUbxCmdPara[UBX_POLL_TP_IDX].ucByteOffset = 0;
            /* CFG-TMODE */
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucCmdIdx = 7;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ulAckRet = UBLOX_INIT_CFG_TMODE;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucPayLoadLen = 28;
            g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucByteOffset = 0;
            /* CFG-TMODE_QUERY */
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucCmdIdx = 18;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ulAckRet = UBLOX_INIT_5T_CFG_TMODE_QUERY;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucPayLoadLen = 0;
            g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ucByteOffset = 0;
            break;

        default:
           break;
    }
    return BSP_OK;
}


/**************************************************************************
* 函数名称： ULONG UbxDecodeVersion(UCHAR *pucCmd, USHORT usCmdLen)
* 功能描述： 获取接收机版本，区分4T和5T
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 成功： 1
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
ULONG UbxDecodeVersion(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{

    UCHAR ucUbxVersion = 0;
    UCHAR aucHwVer[10] = {0x30,0x30,0x30,0x38,0x30,0x30,0x30,0x30,0x00,0x00};
    /* 泰斗接收机版本 */
    /* UCHAR aucTdHwVer[10] = {0x54,0x33,0x30,0x32,0x00,0x00,0x00,0x00,0x00,0x00}; */
    /* UCHAR i = 0; */
    /* 入参检查 */
    T_GPS_RCV_DRV_DATA *pVerRcvData = NULL;
    /* 驱动实例指针检测 */
    if(NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    pVerRcvData = pRcvDrvData;

    if ((NULL == pucCmd) || (10 != (usCmdLen % 30)))
    {
        return 0xff;
    }

    if(0x31 == pucCmd[37])
    {
        ucUbxVersion = UBLOX_VERSION_4T;
    }
    else if(0x35 == pucCmd[37])
    {
        ucUbxVersion = UBLOX_VERSION_5T;
    }
    /*6T的pucCmd[37]为0x37,Trimble暂未支持，pucCmd[37]也是35，
    但pucCmd[30]~pucCmd[33]为33 30 31 33可以此来判断*/
    else
    {
        if(0 == memcmp(aucHwVer, pucCmd + 30, 10))
        {
            ucUbxVersion = UBLOX_VERSION_8T;
        }
        else if(0 == memcmp("T3", pucCmd + 30, 2))
        {
            if(0 == memcmp("02", pucCmd + 32, 2))
            {
                if('G' == pucCmd[34])
                {
                    ucUbxVersion = TD_VERSION_T302G;
                }
                else
                {
                    ucUbxVersion = TD_VERSION_T302;
                }
            }
            else if(0 == memcmp("03", pucCmd + 32, 2))
            {
                if('G' == pucCmd[34])
                {
                    ucUbxVersion = TD_VERSION_T303G;
                }
                else
                {
                    ucUbxVersion = TD_VERSION_T303;
                }
            }
            else
            {
                dbgInfo("Map to an error tai dou type!\n");
            }

            pVerRcvData->ucRcvType = TAIDOU_RECEIVER;
        }
        else
        {
            ucUbxVersion = UBLOX_VERSION_6T;
        }
    }

    /* 接收机版本信息赋给实例结构体 */
    pVerRcvData->ucRcvVersion = ucUbxVersion;

    UbxCfgDataInit(pVerRcvData);

    GPS_LOG(GPS_DBG_UBX_DRV, "ublox receiver version is %dT!\n", ucUbxVersion);
    return UBLOX_INIT_MON_VER;
}


/**************************************************************************
* 函数名称： UbxDecodeAck
* 功能描述： 解析UBX的配置应答电文，初始化时使用
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 成功： p->ucRcvInitStep;
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
ULONG UbxDecodeAck(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    /* 入参检查 */
    T_GPS_RCV_DRV_DATA *pAckRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pAckRcvData = pRcvDrvData;

    /* 电文合法性检查 */
    if ((NULL == pucCmd) || (2 != usCmdLen))
    {
        return 0xff;
    }

    /* step2/11/12/13/14/15:  关闭所有NMEA自动上报信息，除了GPGSV（包含卫星信号信息）――收到反馈 */
    if ((0x06 == pucCmd[0]) && (0x01 == pucCmd[1]))
    {
        switch (pAckRcvData->ucRcvInitStep)
        {
                /* 4T */
            case UBLOX_INIT_CLOSE_MSG:
                /* 5T */
            case UBLOX_INIT_5T_CLOSE_MSG_GPGLL:
            case UBLOX_INIT_5T_CFG_MSG_GPGSV:
            case UBLOX_INIT_5T_CLOSE_MSG_GPRMC:
            case UBLOX_INIT_5T_CLOSE_MSG_GPVTG:
            case UBLOX_INIT_5T_CLOSE_MSG_GPZDA:
                return pAckRcvData->ucRcvInitStep;
            default:
                return 0xff;
        }
    }
    /* step3:  天馈状态检测参数设置 ――收到反馈 */
    else if ((0x06 == pucCmd[0]) && (0x13 == pucCmd[1]))
    {
        return UBLOX_INIT_CFG_ANT;
    }
    /* step5: CFG_NAV2 设置stationary模式 ――收到反馈 */
    else if ((0x06 == pucCmd[0]) && (0x1A == pucCmd[1]))
    {
        return UBLOX_INIT_CFG_NAV;
    }
    /* step6: CFG_TMODE 激活time模式,Survey-in minimum duration = 24 hour  ――收到反馈 */
    else if ((0x06 == pucCmd[0]) && ((0x1D == pucCmd[1]) || (0x3D == pucCmd[1])))
    {
        /* 设置接收机工作模式更改标志，只在接收机工作模式被设置时才执行 */
        if (1 == pAckRcvData->ulSetTMode)
        {
            pAckRcvData->ulSetTMode = 2;
        }

        /* 设置接收机工作模式获取标志，只在接收机工作模式被查询时才执行 */
        if (1 == pAckRcvData->ulGetTMode)
        {
            pAckRcvData->ulGetTMode = 2;
        }

        return UBLOX_INIT_CFG_TMODE;
    }
    /* step7: CFG_TP PP1S延时设置，输出的是负脉冲 ――收到反馈 */
    else if ((0x06 == pucCmd[0]) && ((0x07 == pucCmd[1]) || (0x31 == pucCmd[1])))
    {
        /* 设置天馈线缆更改标志，只在天馈线缆被重新设置时才执行 */
        if (1 == pAckRcvData->ulAntCableLenChange)
        {
            pRcvDrvData->ulAntCableLenChange = 2;
            dbgInfo("UbxDecodeAck==> cfg gps ant cable lenth ack OK.\n");
            /* 查询天馈线缆时延 */
            UbxPollCfgTp(UBX_CFG_TP_QUERY, 0, pRcvDrvData);
        }
        return g_tUbxCmdPara[UBX_CFG_TP_IDX].ulAckRet;  /* UBLOX_INIT_CFG_TP5 */

    }
    /* step16: CFG_NAV5 设置5T接收机stationary模式 ――收到反馈 */
    else if((0x06 == pucCmd[0]) && (0x24 == pucCmd[1]))
    {
        return UBLOX_INIT_5T_CFG_NAV5;
    }
    /* step19: CFG_SBAS disable SBAS功能 */
    else if((0x06 == pucCmd[0]) && (0x16 == pucCmd[1]))
    {
        return UBLOX_INIT_CFG_SBAS;
    }
    else if((0x06 == pucCmd[0]) && (0x3E == pucCmd[1]))
    {
        return UBLOX_INIT_CFG_GNSS;
    }
    else if((0x06 == pucCmd[0]) && (0x17 == pucCmd[1]))
    {
        return UBLOX_INIT_CFG_NMEA;
    }
    else if((0x06 == pucCmd[0]) && (0x00 == pucCmd[1]))
    {
        return UBLOX_INIT_CFG_PRT;
    }
    else
    {
        return 0xff;
    }
}


/**************************************************************************
* 函数名称： ULONG UbxDecodeStatus(UCHAR *pucCmd, USHORT usCmdLen)
* 功能描述： 解析接收机状态，看是否定位
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 成功： 9
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2007/12/6    V1.0       刘骏儒           创建
**************************************************************************/
ULONG UbxDecodeStatus(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    UCHAR ucGpsReceiverStatus = SATELLITE_NOT_FIX;
    T_GPS_RCV_DRV_DATA *pFixRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pFixRcvData = pRcvDrvData;

    /* 电文合法性检查 */
    if ((NULL == pucCmd) || (52 != usCmdLen))
    {
        return 0xff;
    }

    /* 天馈异常保护 */
    if (GPS_ANTENNA_STATE_OK != pFixRcvData->ulRcvAntennaStateShow)
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "ant fix status: not Fix!\n");
        ucGpsReceiverStatus = SATELLITE_NOT_FIX;
        pFixRcvData->ulRcvFixStatus = ucGpsReceiverStatus;
        return 0xff;
    }

    switch (pucCmd[10])
    {
        case 0:
            GPS_LOG(GPS_DBG_UBX_DRV, "fix status: not Fix!\n");
            ucGpsReceiverStatus = SATELLITE_NOT_FIX;
            pFixRcvData->ulRcvFixStatus = ucGpsReceiverStatus;
            return 0xff;
        case 1:
            GPS_LOG(GPS_DBG_UBX_DRV, "fix status: dead reckoning only!\n");
            ucGpsReceiverStatus = SATELLITE_DEAD_RECKONING_ONLY;
            break;
        case 2:
            GPS_LOG(GPS_DBG_UBX_DRV, "fix status: 2D-Fix!\n");
            ucGpsReceiverStatus = SATELLITE_2D_FIX;
            break;
        case 3:
            GPS_LOG(GPS_DBG_UBX_DRV, "fix status: 3D-Fix!\n");
            ucGpsReceiverStatus = SATELLITE_3D_FIX;
            break;
        case 4:
            GPS_LOG(GPS_DBG_UBX_DRV, "fix status: GPS + dead reckoning combined!\n");
            ucGpsReceiverStatus = SATELLITE_GPS_AND_DEAD_RECKONING_COMBINED;
            break;
        case 5:
            GPS_LOG(GPS_DBG_UBX_DRV, "fix status: Time only fix!\n");
            ucGpsReceiverStatus = SATELLITE_TIME_ONLY_FIX;
            break;
        default:
            GPS_LOG(GPS_DBG_UBX_DRV, "fix status: err data!\n");
            ucGpsReceiverStatus = SATELLITE_NOT_FIX;
            pFixRcvData->ulRcvFixStatus = ucGpsReceiverStatus;
            return 0xff;
    }

    /* 实例赋值 */
    pFixRcvData->ulRcvFixStatus = ucGpsReceiverStatus;
    return UBLOX_INIT_CFG_MSG_NAV_SOL;
}


/**************************************************************************
* 函数名称： ULONG UbxDecodeTmode(UCHAR *pucCmd, USHORT usCmdLen)
* 功能描述： 解析TMODE帧，看TMODE设置是否成功
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 成功： 18；
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建
**************************************************************************/
ULONG UbxDecodeTmode(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    /* ULONG i = 0; */
    //UCHAR ucCmdIdx = 0;
    union chartolong uTimeMode;
    ULONG ulRetVal = UBLOX_INIT_5T_CFG_TMODE_QUERY; /* 返回值只有初始化的时候使用 */
    T_GPS_RCV_DRV_DATA *pTmodeRcvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pTmodeRcvData = pRcvDrvData;

    /* 电文合法性检查 */
    if ((NULL == pucCmd) || (28 != usCmdLen))
    {
        return 0xff;
    }

    /* 获取time模式 */
    uTimeMode.CharMode.LLBYTE = pucCmd[0];
    uTimeMode.CharMode.LHBYTE = pucCmd[1];
    uTimeMode.CharMode.HLBYTE = pucCmd[2];
    uTimeMode.CharMode.HHBYTE = pucCmd[3];
    dbgInfoEx("%s: uTimeMode.CharMode.HHBYTE: %d\n", __FUNCTION__, uTimeMode.CharMode.HHBYTE);
    //pTmodeRcvData->ulUsingTimeMode = uTimeMode.LongMode;
    pTmodeRcvData->ulUsingTimeMode = pTmodeRcvData->ulTimeMode;
    //ucCmdIdx = g_tUbxCmdPara[UBX_CFG_TMODE_IDX].ucCmdIdx;
    ulRetVal = g_tUbxCmdPara[UBX_CFG_TMODE_QUERY_IDX].ulAckRet;
    if (2 == pTmodeRcvData->ulSetTMode) /* 获取的Tmode不稳定，暂时不关注 */
    {
        dbgInfo("decode tmode: query time mode = %d\n", pTmodeRcvData->ulUsingTimeMode);
    }

#if 0
    /* 处理接收机time模式查询流程 */
    if (1 == pTmodeRcvData->ulGetTMode)
    {
        pTmodeRcvData->ulGetTMode = 2;
        dbgInfo("decode tmode: query time mode = %d\n", pTmodeRcvData->ulUsingTimeMode);
        return ucRetVal;
    }

    if ((UBLOX_VERSION_5T == pTmodeRcvData->ucRcvVersion) || (UBLOX_VERSION_6T == pTmodeRcvData->ucRcvVersion)|| (UBLOX_VERSION_8T == pTmodeRcvData->ucRcvVersion))
    {
        /* 处理接收机time模式设置流程 */
        if (2 == pTmodeRcvData->ulSetTMode)
        {
            for (i = 0; i <= 15; i++)
            {
                if (pucCmd[i] != g_aucUbxCmd[UBLOX_INIT_CFG_TMODE][i+7])
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "decode tmode: buf[%d] = %d, array[%d] = %d. not equal!\n",
                        i, pucCmd[i], i, g_aucUbxCmd[UBLOX_INIT_CFG_TMODE][i+7]);
                    return 0xff;
                }
            }

            pTmodeRcvData->ulSetTMode = 3;
            dbgInfo("decode tmode: set time mode = %d\n", pTmodeRcvData->ulUsingTimeMode);
            return ucRetVal;
        }

        /* 处理接收机初始化流程 */
        if ((1 != pTmodeRcvData->ulRcvInitFinishFlag) && (ucRetVal == pTmodeRcvData->ucRcvInitStep))
        {
            for (i = 0; i <= 3; i++)
            {
                if (pucCmd[i] != g_aucUbxCmd[UBLOX_INIT_CFG_TMODE][i+7])
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "decode tmode: buf[%d] = %d, array[%d] = %d. not equal!\n",
                        i, pucCmd[i], i, g_aucUbxCmd[UBLOX_INIT_CFG_TMODE][i+7]);
                    ucRetVal = 0xff;
                }
            }

            for (i = 20; i <= 27; i++)
            {
                if (pucCmd[i] != g_aucUbxCmd[UBLOX_INIT_CFG_TMODE][i+7])
                {
                    GPS_LOG(GPS_DBG_UBX_DRV, "decode tmode: buf[%d] = %d, array[%d] = %d. not equal!\n",
                        i, pucCmd[i], i, g_aucUbxCmd[UBLOX_INIT_CFG_TMODE][i+7]);
                    ucRetVal = 0xff;
                }
            }
        }
    }
#endif
    return ulRetVal;
}


/**************************************************************************
* 函数名称: ULONG UbxDecodeBaudRate(UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
* 功能描述: 解析CFG-PRT帧
* 输入参数: pucCmd：帧起始地址，只包含净荷
*           usCmdLen：净荷长度
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:
* 修改日期     版本号     修改人     修改内容
* ------------------------------------------------------------------------
* 2014-09-20    V1.0      张全士       创建
**************************************************************************/
ULONG UbxDecodeBaudRate(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulBaudRate = 0;
    if((NULL == pRcvDrvData) || (NULL == pucCmd))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    ulBaudRate = ((ULONG)pucCmd[11] << 24) + ((ULONG)pucCmd[10] << 16) + ((ULONG)pucCmd[9] << 8) + pucCmd[8];
    GPS_LOG(GPS_DBG_UBX_DRV_TEST,"BaudRate: 0x%02x %02x %02x %02x, %d\n", \
            pucCmd[11], pucCmd[10], pucCmd[9], pucCmd[8], ulBaudRate);

    return UBLOX_INIT_POLL_CFG_PRT;
}


/**************************************************************************
* 函数名称： ULONG UbxDecodeCfgTp(UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData)
* 功能描述： 解析CFG-TP帧，看时延设置是否成功设置是否成功
* 输入参数： pucCmd：帧起始地址，只包含净荷
*            usCmdLen：净荷长度
* 输出参数： 无
* 返 回 值： 成功： 3或17；
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建
**************************************************************************/
ULONG UbxDecodeCfgTp(const UCHAR *pucCmd, USHORT usCmdLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    short sAntCableDelay = 0;
    UCHAR ucCmdIdx = 0;
    UCHAR ucAntDlyOffset = 0; /* 天馈时延字段在净荷中的偏移 */
    UCHAR ucIdxH = 0;
    UCHAR ucIdxL = 0;

    if ((NULL == pucCmd) || (NULL == pRcvDrvData))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    if(g_tUbxCmdPara[UBX_CFG_TP_IDX].ucPayLoadLen != usCmdLen)
    {
        return BSP_ERROR;
    }

    if(32 == g_tUbxCmdPara[UBX_CFG_TP_IDX].ucPayLoadLen)
     {
         pRcvDrvData->ucTimeGrid = (pucCmd[28] >> 7) + ((pucCmd[29] << 1) & 0x0E);
     }

    ucCmdIdx = g_tUbxCmdPara[UBX_CFG_TP_IDX].ucCmdIdx;
    ucAntDlyOffset = g_tUbxCmdPara[UBX_CFG_TP_IDX].ucByteOffset;
    /* 天馈时延字段之前包括g_aucUbxCmd长度(1字节) 和
           6个字节的报文头 */
        ucIdxL = UBX_MSG_PAYLOAG_OFFSET + 1 + ucAntDlyOffset;
        ucIdxH = UBX_MSG_PAYLOAG_OFFSET + 1 + ucAntDlyOffset + 1;
        if((pucCmd[ucAntDlyOffset] == g_aucUbxCmd[ucCmdIdx][ucIdxL])\
                && (pucCmd[ucAntDlyOffset + 1] == g_aucUbxCmd[ucCmdIdx][ucIdxH]))
        {
            /* 设置天馈线缆更改标志，只在天馈线缆被重新设置时才执行 */
            if (1 == pRcvDrvData->ulAntCableLenChange)
            {
                pRcvDrvData->ulAntCableLenChange = 2;
            }
            sAntCableDelay = ((USHORT)pucCmd[ucAntDlyOffset + 1] << 8) + pucCmd[ucAntDlyOffset];
            if(sAntCableDelay >= 0)
            {
                sAntCableDelay = (SHORT)((float)sAntCableDelay * 3 * 85 / 1000 + 0.5);
            }
            else
            {
                sAntCableDelay = (SHORT)((float)sAntCableDelay * 3 * 85 / 1000 - 0.5);
            }
            pRcvDrvData->lAntCabDelayInLength = (long)sAntCableDelay;
            return ucCmdIdx;
        }
        else
        {
            GPS_LOG(GPS_DBG_UBX_DRV, "cfg delay: 0x%02x%02x, decode delay: 0x%02x%02x, not equal!\n", \
                g_aucUbxCmd[ucCmdIdx][ucIdxH], \
                g_aucUbxCmd[ucCmdIdx][ucIdxL], \
                pucCmd[ucAntDlyOffset + 1], pucCmd[ucAntDlyOffset]);
        }

    return 0xff;
}


/**************************************************************************
* 函数名称： ULONG UbxPollCfgTp(ULONG ulCmd, long lLenth)
* 功能描述： 查询CFG-TP帧，看时延设置是否成功设置是否成功
* 输入参数： ulCmd：0-发送查询命令，1-设置天馈延时(调试使用)，2-获取实际天馈延时
*            lLenth：待设置的天馈时延参数(调试时使用)
* 输出参数： 无
* 返 回 值： 实际天馈延时值
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建
**************************************************************************/
ULONG UbxPollCfgTp(ULONG ulCmd, long lLenth, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    if(UBX_CFG_TP_QUERY == ulCmd)
    {
        UbxSendCmdPollCfgTp();
    }
    else if(UBX_CFG_TP_SET == ulCmd)
    {
        return UbloxSetAntCableLenth(lLenth, pRcvDrvData);
    }
    else if(UBX_ANT_CABLE_DELAY_GET == ulCmd)
    {
        UbxSendCmdPollCfgTp();
        taskDelay(sysClkRateGet() * 2);
        return pRcvDrvData->lAntCabDelayInLength;
    }

    return BSP_OK;
}


/**************************************************************************
* 函数名称: UbxDecodeRunMode
* 功能描述: 解析接收机工作模式
* 输入参数: 无
* 输出参数: 无
* 返 回 值: BSP_OK 执行成功
*           其它   执行失败
* 其它说明:     GLN  BD  GPS  (1表示enable, BD和GLN不共存)
*                0   0   1
*                0   1   0
*                0   1   1
*                1   0   0
*                1   0   1
* 修改日期     版本号     修改人     修改内容
* ------------------------------------------------------------------------
* 2014-09-08    V1.0      张全士       创建
**************************************************************************/
ULONG UbxDecodeRunMode(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvData)
{
    UCHAR ucNumCfgBlock = 0;
    UCHAR ucIdx = 0;
    UCHAR ucGpsMode = 0;
    UCHAR ucBdMode = 0;
    UCHAR ucGlnMode = 0;
    if((NULL == pucCmd) || (NULL == pRcvData))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    ucNumCfgBlock = pucCmd[3];

    if((4 + 8 * ucNumCfgBlock) != usCmdLen)
    {
        GPS_LOG(GPS_DBG_UBX_DRV_TEST,"%s Line %d input check err\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    for(ucIdx = 0; ucIdx < ucNumCfgBlock; ucIdx++)
    {
        if(0x01 == pucCmd[8 + ucIdx * 8])
        {
            /* GPS enable */
            if(0 == pucCmd[4 + ucIdx * 8])
            {
                ucGpsMode = 1;
            }
            /* BEIDOU enable */
            else if(3 == pucCmd[4 + ucIdx * 8])
            {
                ucBdMode = 1;
            }
            /* GLONASS enable */
            else if(6 == pucCmd[4 + ucIdx * 8])
            {
                ucGlnMode = 1;
            }
        }
    }

    ucIdx = (ucGlnMode << 2) + (ucBdMode << 1) + ucGpsMode;
    dbgInfo("UbxDecodeRunMode, gps:%d,bd:%d,gln:%d.\n",ucGpsMode,ucBdMode ,ucGlnMode);
    switch(ucIdx)
    {
        case 1:
            pRcvData->ulRcvRealWorkMode = OUTER_GPS_RECEIVER;
            break;
        case 2:
            pRcvData->ulRcvRealWorkMode = OUTER_BD_RECEIVER;
            break;
        case 3:
            pRcvData->ulRcvRealWorkMode = OUTER_GPS_BD_RECEIVER;
            break;
        case 4:
            pRcvData->ulRcvRealWorkMode = OUTER_GLO_RECEIVER;
            break;
        case 5:
            pRcvData->ulRcvRealWorkMode = OUTER_GPS_GLO_RECEIVER;
            break;
        default:
            return BSP_ERROR;
            break;
    }

    return UBLOX_INIT_CFG_GNSS_QUERY;
}

/**************************************************************************
函数名称:  RcvMarkLockSat
功能描述:  标记可见卫星中锁定卫星
输入参数:  ptSatInView ：可见卫星信息
输出参数:
返 回 值:  BSP_OK:操作成功
附加说明:  需要被接收机驱动信息获取函数调用 2010-3-25
附加说明:  卫星状态
*                    0    未可见，没有卫星号
*                    1    可见，有卫星号且信噪比大于等于0DB小于10DB
*                    2    锁定，有卫星号且信噪比大于等于10DB
修改说明:
修改日期          版本号      修改人      修改内容
-----------------------------------------------
**************************************************************************/
ULONG RcvMarkLockSat(ULONG ulSatType, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG Cnt;
    ULONG CntUse;
    UCHAR ucInviewSatCnt = 0;  /* 有数据的卫星数 */
    ULONG ulSatLockedNum = 0;
    T_GPS_RCV_DRV_DATA *pMarkSatRcvData = NULL;

    /* 入参检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pMarkSatRcvData = pRcvDrvData;
    ucInviewSatCnt= pMarkSatRcvData->tSatInVew[ulSatType].ucNumOfSatInView;
    /* 可见卫星数大于0时 */
    if (ucInviewSatCnt > 0)
    {
        ucInviewSatCnt = min(pMarkSatRcvData->tSatInVew[ulSatType].ucNumOfSatInView, GPS_SAT_INVIEW_MAX);
        for (Cnt = 0; Cnt < ucInviewSatCnt; Cnt++)
        {
            if (pMarkSatRcvData->tSatInVew[ulSatType].atSatInViewDetails[Cnt].usCno >= GPS_SAT_LOCK_SN_THRESHOLD)
            {
                for (CntUse = 0; CntUse < NUM_OF_UBLOX_LOCK_SAT_CHANNEL; CntUse++)
                {
                    if ((pMarkSatRcvData->aucSatInUse[ulSatType][CntUse] == pMarkSatRcvData->tSatInVew[ulSatType].atSatInViewDetails[Cnt].ucSatId)
                        && (pMarkSatRcvData->aucSatInUse[ulSatType][CntUse] != 0)
                       )
                    {
                        pMarkSatRcvData->tSatInVew[ulSatType].atSatInViewDetails[Cnt].ucState = 2;
                        ulSatLockedNum++;
                        break;
                    }
                    else
                    {
                        pMarkSatRcvData->tSatInVew[ulSatType].atSatInViewDetails[Cnt].ucState = 1;
                    }
                }
            }
            else
            {
                pMarkSatRcvData->tSatInVew[ulSatType].atSatInViewDetails[Cnt].ucState = 1;
            }
        }
    }

    pMarkSatRcvData->ulTrackedSatCnt[ulSatType] = ulSatLockedNum;
    pMarkSatRcvData->ulLockedSatCnt[ulSatType] = ulSatLockedNum;
    GPS_LOG(GPS_DBG_UBX_DRV, "Int ublox SatType %d available: %d  tracked: %d  locked: %d  tick = %d\n",\
            ulSatType,\
            pMarkSatRcvData->ulAvlSatCnt[ulSatType],\
            pMarkSatRcvData->ulTrackedSatCnt[ulSatType],\
            pMarkSatRcvData->ulLockedSatCnt[ulSatType],\
                               tickGet());

    return BSP_OK;
}



T_SAT_IN_VIEW g_tSatInVew = {0};   /* 卫星信息 */

/**************************************************************************
* 函数名称： UCHAR NmeaDecodeGpgsv(UCHAR *pucBuf, const USHORT usFrameLen)
* 功能描述： 解析NMEA帧的GPGSV电文，根据卫星信号强度计算跟踪和锁定卫星数
* 输入参数： pucBuf：帧起始地址，从“$GPGSV”后面的第一个逗号开始
*            usFrameLen：帧长，不包括帧头和帧尾，包括校验
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：（可见卫星数位10）
* $GPGSV,3,1,10,23,38,230,44,29,71,156,47,07,29,116,41,08,09,081,36*7F
* $GPGSV,3,2,10,10,07,189,,05,05,220,,09,34,274,42,18,25,309,44*72
* $GPGSV,3,3,10,26,82,187,47,28,43,056,46*77
* 0x24 47 50 47 53 56 2c 33 2c 31 2c
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建  NmeaDecodeGsv
**************************************************************************/
ULONG NmeaDecodeGsv(UCHAR *pucBuf, const USHORT usFrameLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG i = 0;
    UCHAR ucSubstrNum = 0; /* 字段号，从1开始编号 */
    UCHAR  cIndex = 0;
    UCHAR ucTotalNumOfMsg = 0; /* 当前消息的总帧数 */
    UCHAR ucThisMsgNum = 0;    /* 当前消息的帧编号 */
    UCHAR ucInviewSatCnt = 0;  /* 有数据的卫星数 */
    UCHAR ulSatType = 0;
    UCHAR ucSatTypeTemp = 0;
    ULONG ulData = 0;
    static UCHAR sucCnoSatCnt = 0; /* 信噪比不为零的卫星数 */
    T_GPS_RCV_DRV_DATA *pLocalGpgsvData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pLocalGpgsvData = pRcvDrvData;

    if (NULL == pucBuf)
    {
        return 0xff;
    }

    if(0 == memcmp("$GP", pucBuf, 3))
    {
        ulSatType = GNSS_SYSTEM_TYPE_GPS;
        ucSatTypeTemp = RCV_USED_SAT_TYPE_GPS;
    }
    else if((0 == memcmp("$GB", pucBuf, 3)) || (0 == memcmp("$BD", pucBuf, 3)))
    {
        ulSatType = RCV_USED_SAT_TYPE_BD;
        ucSatTypeTemp = RCV_USED_SAT_TYPE_BD;
    }
    else if(0 == memcmp("$GL", pucBuf, 3))
    {
        ulSatType = GNSS_SYSTEM_TYPE_GLONASS;
        ucSatTypeTemp = RCV_USED_SAT_TYPE_GLN;
    }
    else
    {
        dbgInfo("Ublox Decode Gsv Error: %s\n",pucBuf);
        return 0xff;
    }
    GPS_LOG(GPS_DBG_UBX_DRV_TEST,"ulSatType = %d!\n",ulSatType);
    /* 将逗号和*号改为'\0'，方便后续字符串处理 */
    for (i = 0; i < usFrameLen; i++)
    {
        GPS_LOG(GPS_MSG_DRV_PRN, "%c", pucBuf[i]);

        if ((',' == pucBuf[i]) || ('*' == pucBuf[i]))
        {
            pucBuf[i] = '\0';
        }
    }

    /* 定位所需字段,并获取数据到相应变量存储 */
    for (i = 0; i < usFrameLen; i++)
    {
        if ('\0' == pucBuf[i])
        {
            ucSubstrNum++;

            /* 获取第1个字段，一个完整电文的总帧数 */
            if (1 == ucSubstrNum)
            {
                ulData = strtoul((CHAR *)(pucBuf + i + 1),NULL,10);
                STRTOUL_CHECK(ulData);
                ucTotalNumOfMsg = (UCHAR)ulData;
            }

            /* 获取第2个字段，当前帧编号，从1开始编 */
            if (2 == ucSubstrNum)
            {

                ulData = strtoul((CHAR *)(pucBuf + i + 1),NULL,10);
                STRTOUL_CHECK(ulData);
                ucThisMsgNum = (UCHAR)ulData;
            }

            /* 获取第3个字段，完整电文包含的卫星数 */
            if (3 == ucSubstrNum)
            {
                ulData = strtoul((CHAR *)(pucBuf + i + 1), NULL, 10);
                STRTOUL_CHECK(ulData);
                ucInviewSatCnt = (UCHAR)ulData;
            }

            /* 找到卫星号，存放到缓数组中 */
            if ((ucThisMsgNum >= 1) && (ucSubstrNum >= 4) && (0 == ((ucSubstrNum - 4) % 4)))
            {
                cIndex = ((ucThisMsgNum - 1) * 4) + ((ucSubstrNum - 4) / 4);

                if (cIndex < 16)
                {
                    ulData = (UCHAR)strtoul((CHAR *)(pucBuf + i + 1), NULL, 10);
                    STRTOUL_CHECK(ulData);
                    pLocalGpgsvData->atSatDetails[cIndex].ucSatId = (UINT8)ulData;
                    pLocalGpgsvData->atSatDetails[cIndex].ucSatType = ulSatType;
                }
            }

            /* 找到仰角，存放到缓数组中 */
            if ((ucThisMsgNum >= 1) && (ucSubstrNum >= 5) && (0 == ((ucSubstrNum - 5) % 4)))
            {
                cIndex = ((ucThisMsgNum - 1) * 4) + ((ucSubstrNum - 5) / 4);

                if (cIndex < 16)
                {
                  ulData = (UCHAR)strtoul((CHAR *)(pucBuf + i + 1), NULL, 10);
                  STRTOUL_CHECK(ulData);
                  pLocalGpgsvData->atSatDetails[cIndex].ucElevation = (UINT8)ulData;
                  pLocalGpgsvData->atSatDetails[cIndex].ucSatType = ulSatType;
                }
            }

            /* 找到方位角，存放到缓数组中 */
            if ((ucThisMsgNum >= 1) && (ucSubstrNum >= 6) && (0 == ((ucSubstrNum - 6) % 4)))
            {
                cIndex = ((ucThisMsgNum - 1) * 4) + ((ucSubstrNum - 6) / 4);

                if (cIndex < 16)
                {
                    ulData = (UCHAR)strtoul((CHAR *)(pucBuf + i + 1), NULL, 10);
                    STRTOUL_CHECK(ulData);
                    pLocalGpgsvData->atSatDetails[cIndex].usAzimuth = (USHORT)ulData;
                    pLocalGpgsvData->atSatDetails[cIndex].ucSatType = ulSatType;
                }
            }

            /* 找到卫星信号强度C/No(db)，存放到缓冲数组中 */
            if ((ucThisMsgNum >= 1) && (ucSubstrNum >= 7) && (0 == ((ucSubstrNum - 7) % 4)))
            {
                cIndex = ((ucThisMsgNum - 1) * 4) + ((ucSubstrNum - 7) / 4);

                if (cIndex < 16)
                {
                    ulData = (UCHAR)strtoul((CHAR *)(pucBuf + i + 1), NULL, 10);
                    STRTOUL_CHECK(ulData);
                    pLocalGpgsvData->atSatDetails[cIndex].usCno = (USHORT)ulData;
                    pLocalGpgsvData->atSatDetails[cIndex].ucSatType = ulSatType;
                }
            }
        }
    }

    /* 收到属于同一次输出的所有GPGSV帧，则统计数据输出 */
    if (ucTotalNumOfMsg == ucThisMsgNum)
    {
        /* 天馈正常时进行卫星详细信息赋值 */
        bzero((char *)&pLocalGpgsvData->tSatInVew[ucSatTypeTemp], sizeof(pLocalGpgsvData->tSatInVew[0]));

        /* 天馈正常时进行卫星详细信息赋值 */
        if (GPS_ANTENNA_STATE_OK == pLocalGpgsvData->ulRcvAntennaStateShow)
        {
            ucInviewSatCnt = min(ucInviewSatCnt, GPS_SAT_INVIEW_MAX);
            for (i = 0; i < ucInviewSatCnt; i++)
            {
                /* 过滤掉信噪比0的卫星 */
                if (0 != pLocalGpgsvData->atSatDetails[i].usCno)
                {
                    pLocalGpgsvData->tSatInVew[ucSatTypeTemp].atSatInViewDetails[sucCnoSatCnt].ucSatId = pLocalGpgsvData->atSatDetails[i].ucSatId;
                    pLocalGpgsvData->tSatInVew[ucSatTypeTemp].atSatInViewDetails[sucCnoSatCnt].ucElevation = pLocalGpgsvData->atSatDetails[i].ucElevation;
                    pLocalGpgsvData->tSatInVew[ucSatTypeTemp].atSatInViewDetails[sucCnoSatCnt].usAzimuth = pLocalGpgsvData->atSatDetails[i].usAzimuth;
                    pLocalGpgsvData->tSatInVew[ucSatTypeTemp].atSatInViewDetails[sucCnoSatCnt].usCno = pLocalGpgsvData->atSatDetails[i].usCno;
                    pLocalGpgsvData->tSatInVew[ucSatTypeTemp].atSatInViewDetails[sucCnoSatCnt].ucSatType = pLocalGpgsvData->atSatDetails[i].ucSatType;
                    pLocalGpgsvData->tSatInVew[ucSatTypeTemp].atSatInViewDetails[sucCnoSatCnt].ucState = pLocalGpgsvData->atSatDetails[i].ucState;
                    sucCnoSatCnt ++;
                }
            }

            pLocalGpgsvData->tSatInVew[ucSatTypeTemp].ucNumOfSatInView = sucCnoSatCnt;
            bzero(pLocalGpgsvData->atSatDetails, sizeof(pLocalGpgsvData->atSatDetails)); /* 缓冲区清0 */
            RcvMarkLockSat(ucSatTypeTemp,pLocalGpgsvData);/* 标记可见卫星信息中的锁定卫星 */
            pLocalGpgsvData->ulAvlSatCnt[ucSatTypeTemp] = sucCnoSatCnt; /* 可见卫星数 */
            sucCnoSatCnt = 0;
        }
        else
        {
            pLocalGpgsvData->ulAvlSatCnt[ucSatTypeTemp] = 0;
        }

        return 0;
    }

    return 0xff;
}

/**************************************************************************
函数名称:  NmeaDecodeGpgsa
功能描述:  GSA电文解析
输入参数:
               *pucBuf -- 帧起始地址，从“$GPGSA”后面的第一个逗号开始
               usFrameLen -- 帧长，不包括帧头和帧尾，包括校验
输出参数:
返 回 值:  BSP_OK:操作成功
附加说明:
修改说明:
  修改日期          版本号      修改人      修改内容
  -----------------------------------------------
  2009年1月19日      1.0       wood        创建
  2011-02-08         1.0       zhangqs     修改   NmeaDecodeGsa
**************************************************************************/
UCHAR NmeaDecodeGsa(UCHAR *pucBuf, const USHORT usFrameLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    CHAR   *tok;
    UCHAR   cnt;
    UCHAR   SatInUse[12] = {0};
    CHAR    *end = NULL;
    UCHAR   subString[1024] = {0};
    char    *strtokBuf;
    ULONG   length;
    ULONG ulData = 0;
    UCHAR ucGnssSysId = GNSS_SYSTEM_TYPE_GPS;
    T_GPS_RCV_DRV_DATA *pLocalGpgsaData = NULL;

    /* 驱动实例指针检测 */
    if ((NULL == pRcvDrvData) || (NULL == pucBuf))
    {
        return 0xff;
    }

    pLocalGpgsaData = pRcvDrvData;

    if(0 == memcmp("$GN", pucBuf, 3))
    {
        if(OUTER_GPS_BD_RECEIVER == pRcvDrvData->ulRcvRealWorkMode)
        {
            pRcvDrvData->ulRcvUsedSatType = RCV_USED_SAT_TYPE_GPS_BD;
            memset(&pRcvDrvData->tSatInVew[GLONSS_SAT_TYPE],0,sizeof(T_SAT_IN_VIEW));
            memcpy_s(&(pRcvDrvData->aucSatInUse[GLONSS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            pRcvDrvData->ulLockedSatCnt[GLONSS_SAT_TYPE] = 0;
        }
        else if(OUTER_GPS_GLO_RECEIVER == pRcvDrvData->ulRcvRealWorkMode)
        {
            pRcvDrvData->ulRcvUsedSatType = RCV_USED_SAT_TYPE_GPS_GLN;
            memset(&pRcvDrvData->tSatInVew[BEIDOU_SAT_TYPE],0,sizeof(T_SAT_IN_VIEW));
            memcpy_s(&(pRcvDrvData->aucSatInUse[BEIDOU_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            pRcvDrvData->ulLockedSatCnt[BEIDOU_SAT_TYPE] = 0;
        }
    }
    else if(0 == memcmp("$GP", pucBuf, 3))
    {
        if(OUTER_GPS_RECEIVER == pRcvDrvData->ulRcvRealWorkMode)
        {
            pRcvDrvData->ulRcvUsedSatType = RCV_USED_SAT_TYPE_GPS;
            memset(&pRcvDrvData->tSatInVew[GLONSS_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
            memset(&pRcvDrvData->tSatInVew[BEIDOU_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
            memcpy_s(&(pRcvDrvData->aucSatInUse[GLONSS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            memcpy_s(&(pRcvDrvData->aucSatInUse[BEIDOU_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            pRcvDrvData->ulLockedSatCnt[GLONSS_SAT_TYPE] = 0;
            pRcvDrvData->ulLockedSatCnt[BEIDOU_SAT_TYPE] = 0;
        }
        else if(OUTER_GPS_BD_RECEIVER == pRcvDrvData->ulRcvRealWorkMode)
        {
            pRcvDrvData->ulRcvUsedSatType = RCV_USED_SAT_TYPE_GPS_BD;
            memset(&pRcvDrvData->tSatInVew[GLONSS_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
            memcpy_s(&(pRcvDrvData->aucSatInUse[GLONSS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            pRcvDrvData->ulLockedSatCnt[GLONSS_SAT_TYPE] = 0;
        }
    }
    else if((0 == memcmp("$GB", pucBuf, 3)) || (0 == memcmp("$BD", pucBuf, 3)))
    {
        ucGnssSysId = GNSS_SYSTEM_TYPE_BEIDOU;
        if(OUTER_BD_RECEIVER == pRcvDrvData->ulRcvRealWorkMode)
        {
            pRcvDrvData->ulRcvUsedSatType = RCV_USED_SAT_TYPE_BD;
            memset(&pRcvDrvData->tSatInVew[GPS_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
            memset(&pRcvDrvData->tSatInVew[GLONSS_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
            memcpy_s(&(pRcvDrvData->aucSatInUse[GLONSS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            memcpy_s(&(pRcvDrvData->aucSatInUse[GPS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            pRcvDrvData->ulLockedSatCnt[GLONSS_SAT_TYPE] = 0;
            pRcvDrvData->ulLockedSatCnt[GPS_SAT_TYPE] = 0;
        }
        else if(OUTER_GPS_BD_RECEIVER == pRcvDrvData->ulRcvRealWorkMode)
        {
            pRcvDrvData->ulRcvUsedSatType = RCV_USED_SAT_TYPE_GPS_BD;
            memset(&pRcvDrvData->tSatInVew[GLONSS_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
            memcpy_s(&(pRcvDrvData->aucSatInUse[GLONSS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
            pRcvDrvData->ulLockedSatCnt[GLONSS_SAT_TYPE] = 0;
        }
    }
    else if(0 == memcmp("$GL", pucBuf, 3))
    {
        pRcvDrvData->ulRcvUsedSatType = RCV_USED_SAT_TYPE_GLN;
        memset(&pRcvDrvData->tSatInVew[GPS_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
        memset(&pRcvDrvData->tSatInVew[BEIDOU_SAT_TYPE], 0, sizeof(T_SAT_IN_VIEW));
        memcpy_s(&(pRcvDrvData->aucSatInUse[BEIDOU_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        memcpy_s(&(pRcvDrvData->aucSatInUse[GPS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        pRcvDrvData->ulLockedSatCnt[BEIDOU_SAT_TYPE] = 0;
        pRcvDrvData->ulLockedSatCnt[GPS_SAT_TYPE] = 0;
    }
    else
    {
        dbgInfo("Ublox Decode Gsa Error: %s\n",pucBuf);
        return 0xff;
    }

    if(',' == pucBuf[usFrameLen - 2])
    {
        ulData = (UCHAR)strtoul((CHAR *)(pucBuf + usFrameLen - 1), NULL, 10);
        STRTOUL_CHECK(ulData);
        if(IS_MULTI_RCV(pRcvDrvData->ucRcvVersion))
        {
            ucGnssSysId = (UCHAR)ulData;
        }
    }

    bzero(SatInUse, sizeof(SatInUse));
    bzero(subString, sizeof(subString));
    /* 寻找连续两个','的字符串，截取之前的子字符串 */
    end = strstr((CHAR *)pucBuf, ",,");

    if (NULL == end)
    {
        /* 未找到,则提取整个字符串作为子串, 去掉校验和帧尾5字节 */
        length = strlen((CHAR *)pucBuf) - 5;
    }
    else
    {
        /* 提取开始到两个','之间的字符串 */
        length = (size_t)end - (size_t)pucBuf;
    }

    if ((length > (ULONG)usFrameLen) || ((length + 1) > sizeof(subString)))
    {
        return 0xff;
    }

    /* 将开始到两个连续','之间的字符拷贝到子字符串中 */
    memcpy_s(subString, (length + 1), pucBuf, (length + 1));
    subString[length] = '\0';

    GPS_LOG(GPS_DBG_UBX_DRV, "GPGSA:%s\n", subString);

    /* 指向$ */
    tok = strtok_s((CHAR *)subString, ",",&strtokBuf);
    STRTOK_CHECK(tok);

    /* 指向Smode *//* 指向Mode字段 */
    tok = strtok_s((CHAR *)NULL, ",",&strtokBuf);
    STRTOK_CHECK(tok);

    /* 指向FS *//* 指向Solution字段 */
    tok = strtok_s(NULL, ",",&strtokBuf);
    STRTOK_CHECK(tok);

    /* 提取连续12个channel *//* 首次指向First SV ID */
    for (cnt = 0; cnt < NUM_OF_UBLOX_LOCK_SAT_CHANNEL; cnt++)
    {
        tok = strtok_s(NULL, ",",&strtokBuf);
        //STRTOK_CHECK(tok);

        if (NULL != tok)
        {
            ulData = (UCHAR)strtoul((CHAR *)(tok), NULL, 10);
            STRTOUL_CHECK(ulData);
            SatInUse[cnt]  = (UCHAR)ulData;
        }
    }

    if ((GPS_ANTENNA_STATE_OK != pLocalGpgsaData->ulRcvAntennaStateShow) || (0 == SatInUse[0]))
    {
        /* 根据电文实际内容清除对应数据 */
        if(GNSS_SYSTEM_TYPE_GPS == ucGnssSysId)
        {
            bzero((char *)&(pLocalGpgsaData->aucSatInUse[GPS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        }
        else if(GNSS_SYSTEM_TYPE_BEIDOU == ucGnssSysId)
        {
            bzero((char *)&(pLocalGpgsaData->aucSatInUse[BEIDOU_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        }
        else if(GNSS_SYSTEM_TYPE_GLONASS == ucGnssSysId)
        {
            bzero((char *)&(pLocalGpgsaData->aucSatInUse[GLONSS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        }
    }
    else
    {
        /* 卫星号1~32为GPS,65~96为GLONASS */
        if(GNSS_SYSTEM_TYPE_GPS == ucGnssSysId)
        {
            memcpy_s(&(pLocalGpgsaData->aucSatInUse[GPS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        }
        else if(GNSS_SYSTEM_TYPE_BEIDOU == ucGnssSysId)
        {
            memcpy_s(&(pLocalGpgsaData->aucSatInUse[BEIDOU_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        }
        else if(GNSS_SYSTEM_TYPE_GLONASS == ucGnssSysId)
        {
            memcpy_s(&(pLocalGpgsaData->aucSatInUse[GLONSS_SAT_TYPE]), NUM_OF_UBLOX_LOCK_SAT_CHANNEL, SatInUse, NUM_OF_UBLOX_LOCK_SAT_CHANNEL);
        }
    }
    GPS_LOG(GPS_DBG_UBX_DRV_TEST,"ucGnssSysId = %d!\n",ucGnssSysId);
    return BSP_OK;
}


/**************************************************************************
* 函数名称： ULONG UbxFrameGet(T_FpgaUartBuffer *ptGcmInput,
*                           UCHAR * const pucFrameBuf, USHORT *pusFrameLen)
* 功能描述： 从UART0 sw缓冲区获取Ubx帧
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 成功： BSP_OK；
*            失败： 其他
* -----------------------------------------------------------------------
* 其它说明：
* UBX协议定义的帧结构如下：
* --------------------------------------------------------------------------------------------
* 字段名称  | SYNC CHAR | Message Class | Message ID | Payload Length | Payload | CK_A | CK_B |
* 字段长度  | 2 byte    | 1 byte        | 1 byte     | 2 byte         | variable|1 byte|1 byte|
* 字段内容  | 0XB5,0X62 | X             | X          | X              | XXX...  | X    | X    |
* --------------------------------------------------------------------------------------------
* 修改日期     版本号     修改人         修改内容
* 2007/12/4   V1.0        SDRBSP           创建
**************************************************************************/
ULONG UbxFrameGet(T_FpgaUartBuffer *ptGcmInput, UCHAR *const pucFrameBuf, USHORT *pusFrameLen, UCHAR *pucProtocol)
{
    ULONG  i = 0;
    USHORT  sUbxCursor = 0;
    USHORT  sNmeaCursor = 0;
    UCHAR  ucCK_A = 0, ucCK_B = 0;
    USHORT usPayloadLen = 0;
    UCHAR  ucPayloadLenMsb = 0, ucPayloadLenLsb = 0;
    short  sUbxFrameFoundLen = 0;
    USHORT usNmeaFrameFoundLen = 0;
    ULONG  ulNmeaTailFoundLen = 0;

    /* 0 入参检测 */
    if ((NULL == ptGcmInput)  ||
        (NULL == pucFrameBuf) ||
        (NULL == pusFrameLen))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 1 初始化 */
    *pusFrameLen = 0;
    /* 初始化游标 */
    sUbxCursor = ptGcmInput->ulHead;
    sNmeaCursor = ptGcmInput->ulHead;

    /* 循环处理，每次只比较一个字节，如果找到整帧就拷贝到帧缓冲区 */
    while ((sUbxCursor != ptGcmInput->ulTail)
           || (sNmeaCursor != ptGcmInput->ulTail))
    {
        /* 2 寻UBX找帧 */
        if (sUbxCursor != ptGcmInput->ulTail)
        {
            /* 状态机实现ubx帧的查找 */
            if (0 == sUbxFrameFoundLen) /* 如果不是在帧的内部找到0xB5 */
            {
                if (0xB5 == ptGcmInput->aucBuf[sUbxCursor]) /* 如果找到0xB5 */
                {
                    sUbxFrameFoundLen = 1;
                }
            }
            else if (1 == sUbxFrameFoundLen) /* 如果已经找到0xB5 */
            {
                if (0x62 == ptGcmInput->aucBuf[sUbxCursor]) /* 如果又找到0x62 */
                {
                    sUbxFrameFoundLen = 2;
                    ucCK_A = 0;
                    ucCK_B = 0;
                }
                else /* 如果没找到0x62，回退，从该位置重新找0xB5 */
                {
                    sUbxCursor--;
                    sUbxCursor = (sUbxCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                    sUbxFrameFoundLen = 0;
                    break;
                }
            }
            else if ((2 == sUbxFrameFoundLen) || (3 == sUbxFrameFoundLen))/* 如果游标处于message clase或者message ID */
            {
                sUbxFrameFoundLen++;
                ucCK_A = ucCK_A + ptGcmInput->aucBuf[sUbxCursor];
                ucCK_B = ucCK_B + ucCK_A;
            }
            else if (4 == sUbxFrameFoundLen)/* 如果游标到达Payload Length的LSB */
            {
                ucPayloadLenLsb = ptGcmInput->aucBuf[sUbxCursor];
                sUbxFrameFoundLen = 5;
                ucCK_A = ucCK_A + ptGcmInput->aucBuf[sUbxCursor];
                ucCK_B = ucCK_B + ucCK_A;
            }
            else if (5 == sUbxFrameFoundLen)/* 如果游标到达Payload Length的MSB */
            {
                ucPayloadLenMsb = ptGcmInput->aucBuf[sUbxCursor];
                usPayloadLen = (((USHORT)ucPayloadLenMsb) << 8) + (USHORT)ucPayloadLenLsb;
                sUbxFrameFoundLen = 6;
                ucCK_A = ucCK_A + ptGcmInput->aucBuf[sUbxCursor];
                ucCK_B = ucCK_B + ucCK_A;
            }
            else if ((6 <= sUbxFrameFoundLen) && (usPayloadLen + 6) > sUbxFrameFoundLen)/* 如果游标处于Payload */
            {
                ucCK_A = ucCK_A + ptGcmInput->aucBuf[sUbxCursor];
                ucCK_B = ucCK_B + ucCK_A;
                sUbxFrameFoundLen++;
            }
            else if ((usPayloadLen + 6) == sUbxFrameFoundLen)/* 如果游标到达校验字节1 */
            {
                if (ucCK_A == ptGcmInput->aucBuf[sUbxCursor])/* 如果校验字节1校验成功 */
                {
                    sUbxFrameFoundLen = usPayloadLen + 7;
                }
                else/* 如果校验字节1校验失败 */
                {
                    /* lUbxCursor回退，从0xB5,0x62后面紧跟的字节重新开始查找帧头 */
                    sUbxCursor -= usPayloadLen + 5;
                    sUbxCursor = (sUbxCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                    sUbxFrameFoundLen = 0;
                    break;
                }
            }
            else if ((usPayloadLen + 7) == sUbxFrameFoundLen)/* 如果游标到达校验字节2 */
            {
                if (ucCK_B == ptGcmInput->aucBuf[sUbxCursor])/* 如果校验字节2校验成功 */
                {
                    /* 电文异常保护，避免引起出参错误 */
                    if ((GCM_UART_QUEUE_SIZE - 8) <= usPayloadLen)
                    {
                        /* lUbxCursor回退，从0xB5,0x62后面紧跟的字节重新开始查找帧头 */
                        sUbxCursor -= usPayloadLen + 6;
                        sUbxCursor = (sUbxCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                        sUbxFrameFoundLen = 0;
                        continue;
                    }

                    /* 设置帧长（包括帧头和校验的长度） */
                    *pusFrameLen = (ULONG)usPayloadLen + 8;
                    /* 设置协议类型指示 */
                    *pucProtocol = 0;
                    /* 更新缓冲区头指针，下一次调用从此处开始 */
                    ptGcmInput->ulHead = (sUbxCursor + 1);
                    ptGcmInput->ulHead &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                    /* 将找到的一个完整帧拷贝到帧缓冲区，包括帧头和校验 */
                    sUbxCursor -= usPayloadLen + 7;
                    sUbxCursor = (sUbxCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1);

                    for (i = 0; i < usPayloadLen + 8; i++)
                    {
                        pucFrameBuf[i] = ptGcmInput->aucBuf[sUbxCursor];
                        sUbxCursor++;
                        sUbxCursor &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                    }

                    /* 正常返回 */
                    return BSP_OK;
                }
                else/* 如果校验字节2校验失败 */
                {
                    /* lUbxCursor回退，从0xB5,0x62后面紧跟的字节重新开始查找帧头 */
                    sUbxCursor -= usPayloadLen + 6;
                    sUbxCursor = (sUbxCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                    /*              if(0 > sUbxCursor)
                                    {
                                        sUbxCursor += GCM_UART_QUEUE_SIZE;
                                    }*/
                    sUbxFrameFoundLen = 0;
                    break;
                }
            }
            else/* 如果不是帧内字段 */
            {
                sUbxFrameFoundLen = 0;
            }

            sUbxCursor++;
            sUbxCursor &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
        }

        /* 3 寻找NMEA帧 */
        if (sNmeaCursor != ptGcmInput->ulTail)
        {
            /* 状态机实现nmea帧的查找 */
            if (0 == usNmeaFrameFoundLen)
            {
                if ('$' == ptGcmInput->aucBuf[sNmeaCursor])
                {
                    usNmeaFrameFoundLen = 1;
                }
                else
                {
                    usNmeaFrameFoundLen = 0;
                }
            }
            else if ( GCM_UART_QUEUE_SIZE > usNmeaFrameFoundLen)
            {
                usNmeaFrameFoundLen++;

                /* 状态机实现nmea帧尾<CR><LF>,即13，10的查找 */
                if (0 == ulNmeaTailFoundLen)
                {
                    if (0x0d == ptGcmInput->aucBuf[sNmeaCursor])
                    {
                        ulNmeaTailFoundLen = 1;
                    }
                }
                else
                {
                    if (0x0a == ptGcmInput->aucBuf[sNmeaCursor])
                    {
                        /* 设置帧长（包括帧尾的长度） */
                        *pusFrameLen = usNmeaFrameFoundLen;
                        /* 设置协议类型指示 */
                        *pucProtocol = 1;
                        /* 更新缓冲区头指针，下一次调用从此处开始 */
                        ptGcmInput->ulHead = (sNmeaCursor + 1);
                        ptGcmInput->ulHead &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */

                        /* 找到完整的NMEA帧，拷贝到帧缓冲区（包括尾标志），返回 */
                        sNmeaCursor -= (usNmeaFrameFoundLen - 1);
                        sNmeaCursor = (sNmeaCursor + GCM_UART_QUEUE_SIZE) & (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */

                        for (i = 0; i < usNmeaFrameFoundLen; i++)
                        {
                            pucFrameBuf[i] = ptGcmInput->aucBuf[sNmeaCursor];
                            sNmeaCursor++;
                            sNmeaCursor &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
                        }
                        /* 正常返回 */
                        return BSP_OK;
                    }
                    else
                    {
                        ulNmeaTailFoundLen = 0;
                    }
                }
            }
            else
            {
                usNmeaFrameFoundLen = 0;
            }

            sNmeaCursor++;
            sNmeaCursor &= (GCM_UART_QUEUE_SIZE - 1); /* 要求GCM_UART_QUEUE_SIZE必须是2的幂 */
        }
    } /* end of while */

    return  BSP_ERROR;
}


/**************************************************************************
* 函数名称： UCHAR UbxFrameProcess(const UCHAR *pucBuf, USHORT usFrameLen)
* 功能描述： 解析ublox帧, 使用了UBX和NMEA两种协议
* 输入参数： pucBuf：帧起始地址，包括完整的帧头和校验
*            usFrameLen：包括帧头和校验的整个帧长
* 输出参数： 无
* 返 回 值： 帧类型编号
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建
**************************************************************************/
ULONG UbxFrameProcess(const UCHAR *pucBuf, USHORT usFrameLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    UCHAR ucMsgClass = 0, ucMsgId = 0;
    const UCHAR *pucPayload = NULL; /* 数据载荷起始 */
    USHORT usPayloadLen = 0;
    T_GPS_RCV_DRV_DATA *pLocalRcvDrvData = NULL;
    static UCHAR ucAgpsSatIndex = 0;

    if ((NULL == pucBuf) || (8 > usFrameLen) || (NULL == pRcvDrvData))
    {
        return 0xff;
    }
    pLocalRcvDrvData = pRcvDrvData;

    /* 接收机宏观状态 */
    pLocalRcvDrvData->ulRcvCmdTimeOutCnt = 0;
    /* 收到对应协议电文标志 */
    pLocalRcvDrvData->ulRcvMsgStas = 1;     /* 接收到UBLOX 协议的电文 */
    ucMsgClass = *(pucBuf + 2); /* 获取Message Class */
    ucMsgId    = *(pucBuf + 3); /* 获取Message ID */
    pucPayload = (UCHAR *)pucBuf + 6;
    usPayloadLen = usFrameLen - 8;
    //GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d)\n", __FUNCTION__, __LINE__);

    /* 根据Message Class和Message ID判断接收帧类型，并调用相应帧解析函数 */
    switch (ucMsgClass)
    {
        case 0x01: /* NAV */
        {
            switch (ucMsgId)
            {
                case 0x02: /* NAV-POSLLH */
                    return UbxDecodePosition(pucPayload, usPayloadLen, pLocalRcvDrvData); /* 解析位置信息 */
                case 0x06: /* NAV-SOL */
                    return UbxDecodeStatus(pucPayload, usPayloadLen, pLocalRcvDrvData); /* 解析状态信息（是否fixed） */
                case 0x20: /* NAV-TIMEGPS */
                    return UbxDecodeGpsTime(pucPayload, usPayloadLen, pLocalRcvDrvData); /* 解析GPS时间信息 */
                default:
                    break;
            }

            break;
        }
        case 0x02: /* RXM */
        {
            switch (ucMsgId)
            {
                case 0x10: /* RXM-RAW */
                    break;
                default:
                    break;
            }

            break;
        }
        case 0x05: /* ACK */
        {
            switch (ucMsgId)
            {
                case 0x01: /* ACK-ACK */
                    return UbxDecodeAck(pucPayload, usPayloadLen, pLocalRcvDrvData); /* 解析配置确认信息 */
                default:
                    break;
            }

            break;
        }
        case 0x06: /* CFG */
        {
            switch (ucMsgId)
            {
                case 0x1D: /* CFG-TMODE */
                case 0x3D: /* CFG-TMODE2 */
                    return UbxDecodeTmode(pucPayload, usPayloadLen,pLocalRcvDrvData); /* 解析配置确认信息 */
                case 0x07: /* CFG-TP */
                case 0x31: /* CFG-TP5 */
                    return UbxDecodeCfgTp(pucPayload, usPayloadLen, pLocalRcvDrvData); /* 解析天馈长度信息 */
                case 0x3E: /* CFG-GNSS */
                    return UbxDecodeRunMode(pucPayload, usPayloadLen, pLocalRcvDrvData);/* 解析接收机工作模式 */
                case 0x00: /* CFG-PRT */
                    return UbxDecodeBaudRate(pucPayload, usPayloadLen, pLocalRcvDrvData);
                default:
                    break;
            }

            break;
        }
        case 0x0A: /* MON */
        {
            switch (ucMsgId)
            {
                case 0x04: /* MON-VER */
                    return UbxDecodeVersion(pucPayload, usPayloadLen, pLocalRcvDrvData); /* 解析配置确认信息 */
                case 0x09: /* MON-HW */
                    /* 外置接收机或者从框，天馈开短路检测通过电文解析实现;
                       主框在接收机初始化时要使能天馈电文的上报 */

                    return UbxDecodeAntennaStatus(pucPayload, usPayloadLen, pLocalRcvDrvData); /* 解析天馈状态 */
                    break;
                default:
                    break;
            }

            break;
        }
        case 0x0B: /* AID */
        {
            switch(ucMsgId)
            {
                case 0x01: /* AID_INI */

                    if (AGPS_UBX_AID_INI_LEN < usFrameLen)
                    {
                        //GPS_LOG(GPS_DBG_UBX_DRV_TEST,"AidIni decode failed!\n");
                        return 0xff;
                    }
                    memcpy_s(&g_tAgpsInfo.tAgpsUbxInfo.aucAidIni, usFrameLen, pucBuf, usFrameLen); /* 拷贝INI信息 */

                    break;

                case 0x02: /* AID_HUI */

                    if (AGPS_UBX_AID_HUI_LEN < usFrameLen)
                    {
                        //GPS_LOG(GPS_DBG_UBX_DRV_TEST,"AidHui decode failed!\n");
                        return 0xff;
                    }
                    memcpy_s(&g_tAgpsInfo.tAgpsUbxInfo.aucAidHui, usFrameLen, pucBuf, usFrameLen); /* 拷贝HUI信息 */

                    break;

                case 0x31: /* AID_EPH */

                    g_ucEphSatNum =  pucBuf[6];
                    if (AGPS_UBX_AID_EPH_LEN < usFrameLen)
                    {
                        //GPS_LOG(GPS_DBG_UBX_DRV_TEST,"AidEph decode failed!\n");
                        return 0xff;
                    }
                    memcpy_s(&g_tAgpsInfo.tAgpsUbxInfo.aucAidEph[ucAgpsSatIndex], usFrameLen, pucBuf, usFrameLen); /* 拷贝EPH信息 */
                    if(g_ucEphSatNum != g_ucEphSatNumLast)
                    {
                        ucAgpsSatIndex++;
                        g_ucEphSatNumLast = g_ucEphSatNum;
                    }
                    //if(ucAgpsSatIndex >= pLocalRcvDrvData->tGpsInfo.ulNumOfSatLocked)
                        ucAgpsSatIndex = 0;

                    break;

                default:
                    break;
            }
            break;
        }
        default:
            break;
    }

    return 0xff;
}


/**************************************************************************
* 函数名称： UCHAR NmeaFrameProcess(UCHAR *pucBuf, USHORT usFrameLen)
* 功能描述： 解析NMEA帧，尚未利用checksum
* 输入参数： pucBuf：帧起始地址，从'$'开始
*            usFrameLen：帧长，包括帧头和帧尾
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建
**************************************************************************/
UCHAR NmeaFrameProcess(UCHAR *pucBuf, USHORT usFrameLen, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    UCHAR aucHeadStr[7];
    T_GPS_RCV_DRV_DATA *pLocalRcvDrvData = NULL;
    UCHAR ucRet = 0;
    pLocalRcvDrvData = pRcvDrvData;
    UINT32 i = 0;

    if ((NULL == pucBuf) || (8 > usFrameLen) || (NULL == pRcvDrvData))
    {
        GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d)\n", __FUNCTION__, __LINE__);
        return 0xff;
    }

    bzero(aucHeadStr, sizeof(aucHeadStr));
    /* 解析锁定卫星数 */
    memcpy_s(aucHeadStr, 6, pucBuf, 6);
    aucHeadStr[6] = '\0';

    for (i = 0; i < usFrameLen; i++)
    {
        GPS_LOG(GPS_DBG_UBX_DRV_TEST, "%c", pucBuf[i]);
    }
    GPS_LOG(GPS_DBG_UBX_DRV_TEST, "\n");

#if 0     /* 多模不用电文回复锁定指示 */
    if (0 == memcmp("$GPGGA", aucHeadStr, 6))
    {
        ucRet = NmeaDecodeGpgga(pucBuf + 6, usFrameLen - 8, pLocalRcvDrvData);
        GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d),ret = %d\n", __FUNCTION__, __LINE__, ucRet);
        return ucRet;
    }
#endif

    /* 解析可见卫星数和可见卫星的信号强度 */
    if (0 == memcmp("GSV", aucHeadStr+3, 3))
    {
        /* 去掉*,两个校验字节以及帧尾\r\n 共5 个字节 */
        ucRet = (UCHAR)NmeaDecodeGsv(pucBuf, usFrameLen - 5, pLocalRcvDrvData);
        GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d),usFrameLen = %d,ret = %d\n", __FUNCTION__, __LINE__, usFrameLen,ucRet);
        return ucRet;
    }

    /* 解析锁定卫星信息 */
    if (0 == memcmp("GSA", aucHeadStr+3, 3))
    {
        ucRet = NmeaDecodeGsa(pucBuf, usFrameLen - 5, pLocalRcvDrvData);
        GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d),usFrameLen = %d,ret = %d\n", __FUNCTION__, __LINE__, usFrameLen,ucRet);
        return ucRet;
    }

    /* GPS接收机初始化完成后300秒后，如果发现搜到了未使能的GPZDA电文，说明接收机自己重启了，要重新启动并初始化 */
    if (0 == memcmp("$GPZDA", aucHeadStr, 6))
    {
        if ((1 == pLocalRcvDrvData->ulRcvInitFinishFlag) && (300 < (GetBookTime() - pLocalRcvDrvData->ulRcvInitFinishTime)))
        {
            if (1 == pLocalRcvDrvData->ulReceiverCtrl)
            {
                pLocalRcvDrvData->ulRcvRstDetails[3] += 1;
                GpsReceiverReset(1, pLocalRcvDrvData);
                dbgInfo("GPZDA appeared，cold reset UBLOX!\n");
            }
        }
    }
    GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d)\n", __FUNCTION__, __LINE__);

    return 0;
}

/**************************************************************************
* 函数名称： UCHAR TdFrameProcess(UCHAR *pucBuf, USHORT usFrameLen)
* 功能描述： 解析TD-SDBP帧
* 输入参数： pucBuf：帧起始地址，从0x40开始
*            usFrameLen：帧长，包括帧头和帧尾
* 输出参数： 无
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建
**************************************************************************/
UCHAR TdFrameProcess(UCHAR *pucBuf, USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvData)
{

    return 0;
}

/**************************************************************************
* 函数名称： UbxCmdDecode
* 功能描述： 解析ublox帧, 使用了UBX和NMEA两种协议
* 输入参数： p->ulRcvCmdNum：自定义的帧编号，用于初始化阶段的应答,
* 输出参数： 无
* 返 回 值： 帧类型编号
* -----------------------------------------------------------------------
* 其它说明：初始化完成后，该返回值即没有意义
* 修改日期     版本号     修改人         修改内容
* 2010-04-06    V1.0       SDRBSP           创建
**************************************************************************/
ULONG UbxCmdDecode(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    UCHAR aucFrameBuf[GCM_UART_QUEUE_SIZE];
    USHORT usFrameLen = 0;
    ULONG ulFrameCnt = 0;
    ULONG ulTmpVal = BSP_ERROR;
    ULONG ulRetVal = BSP_ERROR;
    UCHAR ucRetCmdNum;
    UCHAR ucProtocol;
    T_GPS_RCV_DRV_DATA *pLocalRcvDrvData = NULL;

    /* Part0. 入参检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pLocalRcvDrvData = pRcvDrvData;
    bzero(aucFrameBuf, sizeof(aucFrameBuf));
    /* 从UART0 phy缓冲区拷贝数据到sw缓冲区 */
    GpsUnitGetData(&g_tGcmUartSwBuf);

    /* 解析现存所有数据 */
    for (ulFrameCnt = 0; ulFrameCnt < 200; ulFrameCnt++)
    {
        bzero(aucFrameBuf, sizeof(aucFrameBuf));
        /* 从sw缓冲区解析电文并比对 */
        ulTmpVal = UbxFrameGet(&g_tGcmUartSwBuf, aucFrameBuf, &usFrameLen, &ucProtocol);
        {
            if (3 == ulGpsDbgPrnFlag)
            {
                zprintf("pucSource MapAddr %p:\n%2, 512,\n16@!04x\n", aucFrameBuf,  aucFrameBuf);
            }
        }

        /* 没有完整帧表示当前缓冲区已经处理完 */
        if ((BSP_OK != ulTmpVal) || (GCM_UART_QUEUE_SIZE <= usFrameLen))
        {
            break;
        }
        else /* 使用continue语句保证即使找到所要的帧，还是继续解析，直到解析完所有帧 */
        {
            if (ulGpsDbgPrnFlag & 0x1000)
            {
                zprintf("OK!pucSource MapAddr %p:\n%1, 256,\n16@!02x\n", aucFrameBuf,  aucFrameBuf);
            }

            /* 如果是UBX协议的帧 */
            if (0 == ucProtocol)
            {
                /* 帧处理 */
                ucRetCmdNum = UbxFrameProcess(aucFrameBuf, usFrameLen, pLocalRcvDrvData);

                /* 获得了期望的ack frame */
                if (ucRetCmdNum == pLocalRcvDrvData->ulRcvCmdNum)
                {
                    ulRetVal = BSP_OK;
                    continue;
                }
            }
            /* 如果是NMEA协议的帧 */
            else if (1 == ucProtocol)
            {
                ucRetCmdNum = NmeaFrameProcess(aucFrameBuf, usFrameLen, pLocalRcvDrvData);

                /* 获得了期望的ack frame */
                if ((0 == pLocalRcvDrvData->ulRcvCmdNum) && (0 == ucRetCmdNum))
                {
                    ulRetVal = BSP_OK;
                    continue;
                }
            }
        }
    }
    //GPS_LOG(GPS_DBG_UBX_DRV_TEST, "[%s](%d),Ret = %d\n", __FUNCTION__, __LINE__, ulRetVal);

    /* 返回命令号，0xFF是非法命令号 */
    return ulRetVal;
}

/**************************************************************************
* 函数名称： ULONG BspGpsSetPositionEcef(double dX, double dY, double dZ)
* 功能描述： 设置接收机位置（ECEF坐标），并将授时模式改为fixed模式(单星授时模式)
* 输入参数： dX: ECEF坐标下的X值，单位米
*            dY: ECEF坐标下的Y值，单位米
*            dZ: ECEF坐标下的Z值，单位米
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       SDRBSP         创建
**************************************************************************/
double g_dEcefX; /* XYZ形式的位置信息 */
double g_dEcefY;
double g_dEcefZ;
ULONG BspGpsSetPositionEcef(double dX, double dY, double dZ, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_ERROR;
    ULONG ulCnt = 0;
    T_GPS_RCV_DRV_DATA *pSetPositionData = NULL;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pSetPositionData = pRcvDrvData;
    /* 设置接收机工作模式更改标志 */
    pSetPositionData->ulSetTMode = 1;

    /* 发送接收机指令并确认，最多3次 */
    for (ulCnt = 0; ulCnt < 3; ulCnt++)
    {
        dbgInfo("set XYZ the %d times!\n", ulCnt);
        UbxSendCmdCfgTmode();
        taskDelay(sysClkRateGet() * 1);

        /* 收到接收机工作模式更改的应答 */
        if (2 == pSetPositionData->ulSetTMode)
        {
            /* 4T接收机认为设置成功 */
            if (UBLOX_VERSION_4T == pSetPositionData->ucRcvVersion)
            {
                pSetPositionData->ulUsingTimeMode = SATELLITE_FIXED_MODE;
                dbgInfo("set XYZ succeed!\n");
                ulRetVal = BSP_OK;
            }

            break;
        }

        dbgInfo("set XYZ failed!\n");
    }

    /* 5T/6T接收机还要查询才能确认设置是否成功 */
    if (UBLOX_VERSION_4T!= pSetPositionData->ucRcvVersion)
    {
        for (ulCnt = 0; ulCnt < 3; ulCnt++)
        {
            dbgInfo("UBLOX 5t tmode query the %d times!\n", ulCnt);
            UbxSendCmd5TCfgTmodeQuery();
            taskDelay(sysClkRateGet() * 1);

            if (3 == pSetPositionData->ulSetTMode)
            {
                ulRetVal = BSP_OK;
                dbgInfo("UBLOX 5t tmode query ack ok!\n");
                break;
            }

            dbgInfo("UBLOX 5t tmode query failed!\n");
        }
    }

    if (BSP_OK == ulRetVal)
    {
        /* 将开控的锁定卫星数门限设置为1 */
        pSetPositionData->ulLeastSatNum = 1;
        /* 保存位置信息供查询 */
        g_dEcefX = dX;
        g_dEcefY = dY;
        g_dEcefZ = dZ;
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称： ULONG UbloxGetTimeMode(ULONG *pulTimeMode,T_GPS_RCV_DRV_DATA *pRcvDrvData)
* 功能描述： 获取接收机的授时模式
* 输入参数：
* 输出参数： *pulTimeMode: Time Transfer Mode:
*            1: Survey In
*            2: Fixed Mode (true position information required)
*            其他: Reserved
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明： 如果曾经设置过位置(ECEF坐标或者经纬度)，则返回设置的位置，
*            否则返回接收机自己解析的位置
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       SDRBSP         创建
**************************************************************************/
ULONG UbloxGetTimeMode(ULONG *pulTimeMode,T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_ERROR;
    /* ULONG ulCnt = 0; */
#if 0
    if((NULL == pulTimeMode)||(NULL == pRcvDrvData))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pRcvDrvData->ulGetTMode = 1;
    for (ulCnt = 0; ulCnt < 3; ulCnt++)
    {
        dbgInfo("Get Time Mode the %d Times!\n", ulCnt);
        UbxSendCmd5TCfgTmodeQuery();/* 4T或者5T接收机都使用该命令进行模式查询 */

        taskDelay(sysClkRateGet() * 1);

        if (2 == pRcvDrvData->ulGetTMode)
        {
            *pulTimeMode = pRcvDrvData->ulUsingTimeMode;
            dbgInfo("Get Time Mode succeed!\n");
            ulRetVal = BSP_OK;
            break;
        }
        dbgInfo("Get Time Mode failed!\n");
    }
#endif
    return ulRetVal;
}

/**************************************************************************
* 函数名称： ULONG UbloxSetAutoTimeMode(void)
* 功能描述： 设置接收机的授时模式为auto/suvery in mode
* 输入参数： 无
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       SDRBSP         创建
**************************************************************************/
ULONG UbloxSetAutoTimeMode(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_ERROR;
    ULONG ulCnt = 0;
    T_GPS_RCV_DRV_DATA *pSetAutoModeData;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 驱动实例对本地结构体赋值 */
    pSetAutoModeData = pRcvDrvData;
    /* 防止CFG-TMODE指令冲突_不可能出现冲突 */
    pSetAutoModeData->ulSetTMode = 1;
    /* 生成auto模式指令 */
    UbloxCreateAutoTimeModeCmd();

    /* 发送接收机指令并确认，最多3次 */
    for (ulCnt = 0; ulCnt < 3; ulCnt++)
    {
        dbgInfo("set  the auto time mode  %d times,tick=%d!\n", ulCnt, tickGet());
        UbxSendCmdCfgTmode();
        taskDelay(sysClkRateGet() * 1);

        /* 收到接收机工作模式更改的应答 */
        if (2 == pSetAutoModeData->ulSetTMode)
        {
            /* 4T接收机认为设置成功 */
            if (UBLOX_VERSION_4T == pSetAutoModeData->ucRcvVersion)
            {
                dbgInfo("set the auto time mode  succeed!\n");
                ulRetVal = BSP_OK;
            }

            break;
        }

        dbgInfo("set the auto time mode failed,tick=%d!\n", tickGet());
    }

    /* 5T/6T接收机还要查询才能确认设置是否成功 */
    if (UBLOX_VERSION_4T != pSetAutoModeData->ucRcvVersion)
    {
        for (ulCnt = 0; ulCnt < 3; ulCnt++)
        {
            dbgInfo("UBLOX 5t tmode query the %d times,tick=%d!\n", ulCnt, tickGet());
            UbxSendCmd5TCfgTmodeQuery();
            taskDelay(sysClkRateGet() * 1);

            if (3 == pSetAutoModeData->ulSetTMode)
            {
                ulRetVal = BSP_OK;
                dbgInfo("UBLOX 5t tmode query ack ok!\n");
                break;
            }

            dbgInfo("UBLOX 5t tmode query failed,tick=%d!\n", tickGet());
        }
    }

    if (BSP_OK == ulRetVal)
    {
        /* 将开控的锁定卫星数门限设置为后台设置值 */
        pSetAutoModeData->ulLeastSatNum =  pSetAutoModeData->ulLeastSatNumBackup;
    }

    return ulRetVal;
}


/**************************************************************************
* 函数名称： ULONG UbloxSetAntCableLenth(long lLenth)
* 功能描述： 设置GPS接收机天馈线缆长度
* 输入参数： lLenth: 要设置的天馈线缆长度，单位米
* 输出参数： 无
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明： 天馈线缆的传输速率为光速的0.85倍。
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       刘骏儒         创建
**************************************************************************/
ULONG UbloxSetAntCableLenth(long lLenth, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_ERROR;
    ULONG ulCnt = 0;
    T_GPS_RCV_DRV_DATA *pSetAntCableData = NULL;

    /* 入参保护，ulbox接收机支持的天馈线缆延时较短，以ublox为基准(32767ns) */
    if (lLenth > 32767 / (1000 / (3 * 85)))
    {
        return BSP_ERROR_INVALID_PARA;
    }

    /* 结构体实例不为空 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pSetAntCableData = pRcvDrvData;

    if (pSetAntCableData->lAntCabDelayInLength == lLenth)
    {
        return BSP_OK;
    }

    /* 设置天馈线缆长度更改标志 */
    pSetAntCableData->ulAntCableLenChange = 1;

    UbxCreateCableDelayCmd(lLenth,pSetAntCableData);

    /* 发送接收机指令并确认，最多重复3次 */
    for (ulCnt = 0; ulCnt < 3; ulCnt++)
    {
        dbgInfo("cfg gps ant cable lenth the %d times.\n", ulCnt + 1);

        /* 发送指令 */
        UbxSendCmdCfgTp();

        taskDelay(sysClkRateGet() * 1);

        /* 收到接收机设置天馈线缆的应答，才认为设置成功 */
        if (2 == pSetAntCableData->ulAntCableLenChange)
        {
            ulRetVal = BSP_OK;
            dbgInfo("cfg gps ant cable lenth succeed!\n");
            break;
        }
        if (2 == ulCnt)
        {
            dbgInfo("cfg gps ant cable lenth failed!\n");
        }
    }

    return ulRetVal;
}


/**************************************************************************
* 函数名称： ULONG UbloxGetAntCableLenth(void)
* 功能描述： 获取GPS接收机天馈线缆长度
* 输入参数：
* 输出参数：
* 返 回 值： 天馈线缆长度，单位毫米
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       SDRBSP         创建
**************************************************************************/
ULONG UbloxGetAntCableLenth(void)
{
    T_GPS_RCV_DRV_DATA *pGetAntCableData = NULL;
    pGetAntCableData = (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData;
    return pGetAntCableData->lAntCabDelayInLength;
}

void SetUartBaudrate(ULONG ulRate, UCHAR ucParity)
{
    if(NULL != pFuncGpsUartBaudRateCallBack)
    {
        pFuncGpsUartBaudRateCallBack(ulRate);
    }

    if(NULL != pFuncGpsUartInitCallBack)
    {
        pFuncGpsUartInitCallBack();
    }
    //_BspSetUartIoCtrl(1, 5, ulRate);
}

/**************************************************************************
* 函数名称： void SatRefCleanUartPhyBuf(void)
* 功能描述： 清除GPS接收机PHY BUF缓冲区，在任务级调用可以保证没问题。
*            在中断级调用，因可能与UART中断重叠，可能存在数据互斥访问问题。
* 输入参数： 无
* 输出参数：
* 返 回 值：
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2007/05/08   V1.0       朱伟           移植到CBM
* 2008/01/08   V2.0       刘骏儒         移植到CC单板GPS模块
**************************************************************************/
void SatRefCleanUartPhyBuf(void)
{
    ULONG  ulOldLevel = 0;
    ulOldLevel = intLock();
    g_tGcmUartPhyBuf.ulHead = 0;
    g_tGcmUartPhyBuf.ulTail = 0;
    memset(g_tGcmUartPhyBuf.aucBuf, 0, GCM_UART_QUEUE_SIZE); /* liujr，2008-3-13 */
    intUnlock(ulOldLevel);
}
/**************************************************************************
* 函数名称： ULONG BspUbloxRcvIdentify(T_GPS_RCV_DRV_DATA *pRcvData)
* 功能描述： Ublox接收机类型辨识
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 接收机型号
* -----------------------------------------------------------------------
* 其它说明：会影响正常的电文接收以及解析
* 修改日期     版本号     修改人         修改内容
* 2010-1-26    V1.0       SDRBSP            创建
**************************************************************************/
ULONG BspUbloxRcvIdentify(T_GPS_RCV_DRV_DATA *pRcvData)
{
    UCHAR aucFrameBuf[GCM_UART_QUEUE_SIZE];
    USHORT usFrameLen = 0;
    ULONG ulFrameCnt = 0;
    ULONG ulTmpVal = BSP_ERROR;
    UCHAR ucProtocol = 0xff;
    ULONG i = 0;
    T_GPS_RCV_DRV_DATA *pRcvIdentifyData = NULL;

    /* 结构体实例不为空 */
    if (NULL == pRcvData)
    {
        dbgPrn("Null Point!!!");
        return BSP_ERROR_NULL_POINTER;
    }

    if (UBLOX_Receiver == pRcvData->ucRcvType)
    {
        dbgPrn("Ublox receiver is already identified!");
        return BSP_OK;
    }

    pRcvIdentifyData = pRcvData;
    /************1、尝试识别UBlOX Receiver *******************/
    /* 串口波特率改设为9600bps */
    //SetUartBaudrate(9600, 0);
#if 1
    if(0 == pRcvIdentifyData->ulResv)
    {
        pRcvIdentifyData->ulResv = 1;
        SetUartBaudrate(9600, 0);
    }
    else
    {
        pRcvIdentifyData->ulResv = 0;
        SetUartBaudrate(115200, 0);
    }
#endif
    /* 4T关闭电文 */
    UbxSendCmdCloseAllMsg();
    /* 5T接收机关闭电文 */
    UbxSendCmd5TCloseGpgll();
    UbxSendCmd5TCfgGpgsv();
    UbxSendCmd5TCloseGprmc();
    UbxSendCmd5TCloseGpvtg();
    UbxSendCmd5TCloseGpzda();
    /* 清除串口缓冲区电文信息 */
    SatRefCleanUartPhyBuf();
    bzero((char *)(&g_tUartIdentifyBuf), sizeof(g_tUartIdentifyBuf));

    /* 检查10次 */
    for (i = 0; i < 10; i++)
    {
        UbxSendCmdMonVer();
        UbxSendCmdCfgMsgNavTimegps();
        taskDelay(sysClkRateGet() / 10); /* 延时0.1s */
        UbxSendCmdMonVer();
        UbxSendCmdCfgMsgNavTimegps();
        /* 从UART0 phy缓冲区拷贝数据到识别缓冲区 */
        /* GSP遗留问题: 后续UART访问接口 */
        UbloxGpsUnitGetIdData(&g_tUartIdentifyBuf);

        /* 检查看是不是ublox接收机 */
        for(ulFrameCnt = 0; ulFrameCnt < 200; ulFrameCnt++)
        {
            /* 抽取UBLOX接收机自动上报的帧 */
            ulTmpVal = UbxFrameGet(&g_tUartIdentifyBuf, aucFrameBuf, &usFrameLen, &ucProtocol);

            if (ucProtocol == 0)
            {
                GPS_LOG(GPS_DBG_INIT_PRN, "ucProtocol is  %d and ulTmpVal is 0x%x\n",
                    ucProtocol, ulTmpVal);
            }

            /* 没有完整帧表示当前缓冲区已经处理完 */
            if ((BSP_OK != ulTmpVal) || (GCM_UART_QUEUE_SIZE <= usFrameLen))
            {
                break;
            }
            else
            {
                /* 如果是UBX协议的帧 */
                if (0 == ucProtocol)
                {
                    pRcvIdentifyData->ucRcvType = UBLOX_Receiver;
                    dbgInfo("ublox GPS reciever is identify!!!\n");
                    return ulTmpVal;
                }
            }

            usleep(1000 * 10);
        }
    }

    dbgInfoEx("Ublox reciever Type dectct failed!\n");
    return ulTmpVal;
}

/*******************************ublox接收机驱动对外接口函数 start********************/
/**************************************************************************
* 函数名称： ULONG WGS84_BLHToXYZ(double B, double L, double H, double *x, double *y, double *z)
* 功能描述： WGS84坐标系下，大地坐标转换为空间直角坐标
* 输入参数： B: 纬度，单位度；L: 经度，单位度；H: 高度，单位米。
* 输出参数： xyz：空间直角坐标，单位米。
* 返 回 值： BSP_OK:成功；其他：失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/12/12  V1.0       SDRBSP         创建
**************************************************************************/
ULONG WGS84BLHToXYZ(double B, double L, double H, double *x, double *y, double *z)
{
    double e2 = 0.0, N = 0.0;
    double a = 6378137; /* WGS84椭球参数 */
    double f = 1 / 298.257223563;

    if ((NULL == x) || (NULL == y) || (NULL == z))
    {
        return  BSP_ERROR_NULL_POINTER;
    }

    e2 = 2 * f - f * f;
    B = B * PI / 180.0;
    L = L * PI / 180.0;
    N = a / sqrt(1 - e2 * sin(B) * sin(B));
    *x = (N + H) * cos(B) * cos(L);
    *y = (N + H) * cos(B) * sin(L);
    *z = (N * (1 - e2) + H) * sin(B);
    return BSP_OK;
}


/**************************************************************************
* 函数名称： ULONG WGS84XYZToBLH(double x, double y, double z, double &B, double &L, double &H)
* 功能描述： WGS84坐标系下，空间直角坐标转换为大地坐标
* 输入参数： xyz：空间直角坐标，单位米。
* 输出参数： B: 纬度，单位度；L: 经度，单位度；H: 高度，单位米。
* 返 回 值： BSP_OK:成功；其他：失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/12/12  V1.0       SDRBSP         创建
**************************************************************************/
ULONG WGS84XYZToBLH(double x, double y, double z, double *B, double *L, double *H)
{
    double e2 = 0.0, mu = 0.0, p = 0.0, r = 0.0;
    double a = 6378137; /* WGS84椭球参数 */
    double f = 1 / 298.257223563;

    if ((NULL == B) || (NULL == L) || (NULL == H))
    {
        return  BSP_ERROR_NULL_POINTER;
    }

    e2 = 2 * f - f * f;
    p = sqrt(x * x + y * y);
    r = sqrt(p * p + z * z);
    mu = atan(z * ((1 - f) + e2 * a / r) / p);
    *B = atan((z * (1 - f) + e2 * a * sin(mu) * sin(mu) * sin(mu)) / ((1 - f) * (p - e2 * a * cos(mu) * cos(mu) * cos(mu))));
    *L = atan(y / x);
    *H = p * cos(*B) + z * sin(*B) - a * sqrt(1 - e2 * sin(*B) * sin(*B));

    if (x < 0 && y > 0)
    {
        (*L) += PI;
    }

    if (x < 0 && y < 0)
    {
        (*L) -= PI;
    }

    *B = (*B) * 180 / PI;
    *L = (*L) * 180 / PI;
    return BSP_OK;
}


/**************************************************************************
* 函数名称： void ClockDecrementTime(T_Clock_Tod *D)
* 功能描述： 本地维护tod信息递减函数
* 输入参数： tod信息
* 输出参数： 更新之后的tod信息
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2008-9-16    V1.0         SDR BSP         创建
**************************************************************************/
void ClockDecrementTime(T_Clock_Tod *D)
{
    /* 入参检测 */
    if (NULL == D)
    {
        return;
    }

    if ((--(*D).SEC) == 0xff)      /* CPU计时 */
    {
        (*D).SEC = 59;

        if ((--(*D).MIN) == 0xff)
        {
            (*D).MIN = 59;

            if ((--(*D).HOUR) == 0xff)
            {
                (*D).HOUR = 23;

                if (--(*D).DAYS == 0xff)
                {
                    if (ClockLeapYearCheck((*D).YEAR) == FALSE)      /*平年365天*/
                    {
                        (*D).DAYS = 365;
                        (*D).YEAR--;
                    }
                    else
                    {
                        if ((*D).DAYS == 0xff)      /*润年366天*/
                        {
                            (*D).DAYS = 366;
                            (*D).YEAR--;
                        }
                    }
                }
            }
        }
    }
}

/**************************************************************************
* 函数名称： ULONG BspGpsGetTimeMode(ULONG *pulTimeMode,T_GPS_RCV_DRV_DATA *pRcvDrvData)
* 功能描述： 获取接收机的授时模式
* 输入参数：
* 输出参数： *pulTimeMode: Time Transfer Mode:
*            1: Survey In
*            2: Fixed Mode (true position information required)
*            其他: Reserved
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明： 如果曾经设置过位置(ECEF坐标或者经纬度)，则返回设置的位置，
*            否则返回接收机自己解析的位置
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       SDRBSP         创建
**************************************************************************/
ULONG BspGpsGetTimeMode(ULONG *pulTimeMode, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_ERROR;
    ULONG ulCnt = 0;

    if ((NULL == pulTimeMode) || (NULL == pRcvDrvData))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pRcvDrvData->ulGetTMode = 1;

    for (ulCnt = 0; ulCnt < 3; ulCnt++)
    {
        dbgInfo("Get Time Mode the %d Times!\n", ulCnt);
        UbxSendCmd5TCfgTmodeQuery();/* 4T或者5T接收机都使用该命令进行模式查询 */
        taskDelay(sysClkRateGet() * 1);

        if (2 == pRcvDrvData->ulGetTMode)
        {
            *pulTimeMode = pRcvDrvData->ulUsingTimeMode;
            dbgInfo("Get Time Mode succeed!\n");
            ulRetVal = BSP_OK;
            break;
        }

        dbgInfo("Get Time Mode failed!\n");
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称： ClockCreateUtcTime
* 功能描述： 计算出utc时间
* 输入参数： tGpsTime：GPS时间；cLeaps：闰秒
* 输出参数： pUtcTime:utc时间
* 返 回 值： BSP_OK：成功；其它：失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-2-9     V1.0       jiaran            创建
**************************************************************************/
ULONG ClockCreateUtcTime(T_Clock_Tod tGpsTime, char cLeaps, T_Clock_Tod *pUtcTime)
{
    ULONG ulRetVal = BSP_OK;
    char  cCnt = 0;
    T_Clock_Tod tTempTime;

    /* 入参检测 */
    if (0 == tGpsTime.YEAR)
    {
        return BSP_ERROR;
    }

    memcpy_s(&tTempTime, sizeof(tGpsTime), &tGpsTime, sizeof(tGpsTime));

    /* 判断闰秒的符号 */
    for (cCnt = 0; cCnt < cLeaps; cCnt++)
     {
        ClockDecrementTime(&tTempTime);
     }

    /* utc time */
    memcpy_s(pUtcTime, sizeof(tTempTime), &tTempTime, sizeof(tTempTime));

    /* convert to date */
    if (BSP_OK != ClockChangeDaysToMonDay(pUtcTime))
    {
        ulRetVal = BSP_ERROR;
    }

    return ulRetVal;
}


/**************************************************************************
* 函数名称： ULONG UbloxSetGpsRcvTimeMode(double dLatitude, double dLongitude, double dAltitude)
* 功能描述： 设置接收机天馈的位置（经纬度和高度表示），并将授时模式改为position hold or auto mode
* 输入参数： ulTimeMode:接收机工作模式1: Survey In 2: Fixed Mode
*            dLongitudeInput: 经度，单位度
*            dLatitudeInput: 纬度，单位度
*            dAltitudeInput: 高度，单位米
* 输出参数：
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-3-4    V1.0       SDRBSP             创建
**************************************************************************/
ULONG UbloxSetGpsRcvTimeMode(ULONG ulTimeMode, double dLatitudeInput, double dLongitudeInput, double dAltitudeInput, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_OK;
    double dX = 0;
    double dY = 0;
    double dZ = 0;
    T_GPS_RCV_DRV_DATA *pSetGpsRcvTimeModeData;
    double dLatitude = 0.0;
    double dLongitude = 0.0;
    double dAltitude = 0.0;

    /* 驱动实例指针检测 */
    if (NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 驱动实例对本地结构体赋值 */
    pSetGpsRcvTimeModeData = pRcvDrvData;

    /* 接收机工作模式入参保护 */
    /* 接收机工作模式入参保护 */
    if ((SATELLITE_AUTO_MODE != ulTimeMode) && (SATELLITE_FIXED_MODE != ulTimeMode) && (SATELLITE_SELF_CTRL_FIXED_MODE != ulTimeMode))
    {
        dbgInfo("Ublox Set GpsRcv TimeMode fail,and ulTimeMode=%d\n", ulTimeMode);
        return BSP_ERROR_INVALID_PARA;
    }

    /* 当模式为单星授时模式时需要检查位置信息 */
    if (SATELLITE_FIXED_MODE == ulTimeMode)
    {
        /* 单星授时模式下，经纬高度信息入参保护，海拔高度不得超过10km */
        if ((10000.0 < dAltitudeInput)
            || (-180.0 > dLongitudeInput) || (180.0 < dLongitudeInput)
            || (-90.0 > dLatitudeInput) || (90.0 < dLatitudeInput)
           )
        {
            dbgInfo("Ublox Set GpsRcv TimeMode fail 2\n");
            return BSP_ERROR_INVALID_PARA;
        }
    }

    /* 生成接收机位置保持的位置信息 */
    if (SATELLITE_FIXED_MODE == ulTimeMode)
    {
        dLatitude  = dLatitudeInput;
        dLongitude = dLongitudeInput;
        dAltitude  = dAltitudeInput;
    }
    else if (SATELLITE_SELF_CTRL_FIXED_MODE == ulTimeMode) /* 前台自维护的单星授时模式下，不用检查位置信息正确性 */
    {
        dLatitude  = gtSatAntPosInfo.dLatitude;
        dLongitude = gtSatAntPosInfo.dLongitude;
        dAltitude  = gtSatAntPosInfo.dAltitude;
        dLatitudeInput  = dLatitude ;
        dLongitudeInput = dLongitude;
        dAltitudeInput  = dAltitude ;

        if (0 == gtSatAntPosInfo.usCrc16)
        {
            /* 没有可用位置数据，设置失败；设置接收机进入自动运行模式，并返回错误 */
            ulRetVal = UbloxSetAutoTimeMode(pSetGpsRcvTimeModeData);
            return BSP_ERROR;
        }
    }
    else
    {
        /* do nothing */
    }

    /* 记录接收机模式到全局变量 */
    gulSatRcvModeCfged = ulTimeMode;

    /* 设置接收机为auto/suver mode */
    if (SATELLITE_AUTO_MODE == ulTimeMode)
    {
        ulRetVal = UbloxSetAutoTimeMode(pSetGpsRcvTimeModeData);
    }
    else  /* set position hold mode */
    {
        /* 先将经纬度转换为直角坐标以备查询使用 */
        if (BSP_OK != WGS84BLHToXYZ(dLatitude, dLongitude, dAltitude, &dX, &dY, &dZ))
        {
            return 1;
        }

        /* Ublox接收机生成配置指令 */
        UbloxCreatePositionHoldCmd(dX, dY, dZ);

        /* 再对接收机进行设置，即将命令发给接收机 */
        if (BSP_OK != BspGpsSetPositionEcef(dX, dY, dZ, pSetGpsRcvTimeModeData))
        {
            return 2;
        }
    }

    return ulRetVal;
}


ULONG UbloxCreatTimeModeCmd(T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulRetVal = BSP_OK;
    double dX = 0;
    double dY = 0;
    double dZ = 0;
    T_GPS_RCV_DRV_DATA *pSetGpsRcvTimeModeData;

    double dLatitude = 0.0;
    double dLongitude = 0.0;
    double dAltitude = 0.0;
    ULONG ulTimeMode = 0;

    /* 驱动实例指针检测 */
    if(NULL == pRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    /* 驱动实例对本地结构体赋值 */
    pSetGpsRcvTimeModeData = pRcvDrvData;

    ulTimeMode = pSetGpsRcvTimeModeData->ulTimeMode;
    /* 接收机工作模式入参保护 */
    if((SATELLITE_AUTO_MODE != ulTimeMode) && (SATELLITE_FIXED_MODE != ulTimeMode) && (SATELLITE_SELF_CTRL_FIXED_MODE != ulTimeMode))
    {
        dbgInfo("Set GpsRcv TimeMode fail1, and ulTimeMode=%uld\n",ulTimeMode);
        return BSP_ERROR_INVALID_PARA;
    }
    /* 当模式为单星授时模式时需要检查位置信息 */
    if(SATELLITE_FIXED_MODE == ulTimeMode)
    {
        /* 单星授时模式下，经纬高度信息入参保护，海拔高度不得超过10km */
        if( (10000.0 < pSetGpsRcvTimeModeData->dAltitude)
          ||(-180.0 > pSetGpsRcvTimeModeData->dLongitude)||(180.0 < pSetGpsRcvTimeModeData->dLongitude)
          ||(-90.0 > pSetGpsRcvTimeModeData->dLatitude)||(90.0 < pSetGpsRcvTimeModeData->dLatitude)
          )
        {
            dbgInfo("Set GpsRcv TimeMode fail 2\n");
            return BSP_ERROR_INVALID_PARA;
        }
    }

    /* 生成接收机位置保持的位置信息 */
    if (SATELLITE_FIXED_MODE == ulTimeMode)
    {
        dLatitude  = pSetGpsRcvTimeModeData->dLatitude;
        dLongitude = pSetGpsRcvTimeModeData->dLongitude;
        dAltitude  = pSetGpsRcvTimeModeData->dAltitude;
    }
    else if(SATELLITE_SELF_CTRL_FIXED_MODE == ulTimeMode)/* 前台自维护的单星授时模式下，不用检查位置信息正确性 */
    {
        dLatitude  = gtSatAntPosInfo.dLatitude;
        dLongitude = gtSatAntPosInfo.dLongitude;
        dAltitude  = gtSatAntPosInfo.dAltitude;
        if(0 == gtSatAntPosInfo.usCrc16)
        {
            /* 没有可用位置数据，设置失败；设置接收机进入自动运行模式 */
            UbloxCreateAutoTimeModeCmd();
        }
    }
    else
    {
        /* do nothing */
    }

    /* 设置接收机为auto/suver mode */
    if(SATELLITE_AUTO_MODE == ulTimeMode)
    {
        /* 生成auto模式指令 */
        UbloxCreateAutoTimeModeCmd();
    }
    else  /* set position hold mode */
    {
        /* 先将经纬度转换为直角坐标以备查询使用 */
        WGS84BLHToXYZ(dLatitude, dLongitude, dAltitude, &dX, &dY, &dZ);

          /* Ublox接收机生成配置指令 */
        UbloxCreatePositionHoldCmd(dX, dY, dZ);
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称： ULONG UbloxGetGpsRcvTimeMode(ULONG *pulTimeMode,double *pdLatitude, double *pdLongitude, double *pdAltitude)
* 功能描述： 获取接收机天馈的位置信息以及授时模式
* 输入参数：
* 输出参数： *pulTimeMode:授时模式，(position hold or auto mode)
*            *pdLongitude: 经度，单位度
*            *pdLatitude: 纬度，单位度
*            *pdAltitude: 高度，单位米
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明： 如果是survey in/auto模式，则返回接收机自己解析的经纬度；
*            如果是position hold模式，则返回人工设置的经纬度。
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-3-4    V1.0       SDRBSP             创建
**************************************************************************/
ULONG UbloxGetGpsRcvTimeMode(ULONG *pulTimeMode, double *pdLatitude, double *pdLongitude, double *pdAltitude, T_GPS_RCV_DRV_DATA *pRcvDrvData)
{
    ULONG ulTimeMode = 0;
    T_GPS_RCV_DRV_DATA *pGetGpsRcvTimeModeData;

    if ((NULL == pulTimeMode) || (NULL == pdLatitude) || (NULL == pdLongitude) || (NULL == pdAltitude) || (NULL == pRcvDrvData))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /* 驱动实例对本地结构体赋值 */
    pGetGpsRcvTimeModeData = pRcvDrvData;

    if (BSP_OK != BspGpsGetTimeMode(&ulTimeMode, pGetGpsRcvTimeModeData))
    {
        dbgInfo("Bsp Gps Get TimeMode fail\n");
        return 1;
    }

    dbgInfo("Bsp Gps Get TimeMode ok，and ulTimeMode is  %d \n", ulTimeMode);
    *pulTimeMode = ulTimeMode;/* 将从接收机获取到的模式赋给出参 */
    /* 如果是survey in模式，则返回接收机自己解析的地址 */
    if (SATELLITE_AUTO_MODE == ulTimeMode)
    {
        *pdLatitude = (double)((double)pGetGpsRcvTimeModeData->tPositionInfo.lLatitude / 3600000);
        *pdLongitude = (double)((double)pGetGpsRcvTimeModeData->tPositionInfo.lLongitude / 3600000);
        *pdAltitude = (double)((double)pGetGpsRcvTimeModeData->tPositionInfo.lAltitude / 100);
        return BSP_OK;
    }
    /* 如果是fixed模式，则返回设置成功的值 */
    else if (SATELLITE_FIXED_MODE == ulTimeMode)
    {
        WGS84XYZToBLH(g_dEcefX, g_dEcefY, g_dEcefZ, pdLatitude, pdLongitude, pdAltitude);
    }
    else
    {
        dbgInfo("TimeMode is not auto ether fix,unknown mode.\n");
        return 2;
    }

    return BSP_OK;
}

/**************************************************************************
* 函数名称： UbloxRcvStatusGet
* 功能描述： ublox诊断信息获取接口
* 输入参数： 无
* 输出参数： pRcvData
* 返 回 值： BSP_OK:成功；  BSP_ERROR:失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-12-8    V1.0         jiaran           创建
**************************************************************************/
ULONG UbloxRcvStatusGet(UINT32 radioMode, T_GNSS_RECEIVER_STATE *pGNSSRcvStatus, T_GPS_RCV_DRV_DATA *pRcvData)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulLoop = 0;
    ULONG ulSatCnt = 0;
    UCHAR ucTmpChar = 0;
    UCHAR ucUartErrState = 0;
    T_Clock_Tod tLocalUtcOriginTod;

    if ((NULL == pGNSSRcvStatus) || (NULL == pRcvData))
    {
        return BSP_ERROR_NULL_POINTER;
    }

    /*每次进入后相关数据清零*/
    memset(pGNSSRcvStatus, 0, sizeof(T_GNSS_RECEIVER_STATE));   /*10207549 周敏*/
    memset(&tLocalUtcOriginTod, 0, sizeof(T_Clock_Tod));        /*10207549 周敏*/

    /* 当GPS被拔下来后，通过该接口获取的GPS状态无效，返回零状态(天馈状态和串口状态除外):ylc,2015.7.3*/
    if(1 == SatRefUartErrState(pRcvData->ulRcvPlace))
    {
        pGNSSRcvStatus->ucGpsUartErr = 1;
        pGNSSRcvStatus->ucLockSatState = 1;
        if (BSP_CLOCK_REF_EXTERNAL_FRONT_SATELLITE == pRcvData->ulRcvPlace) /* 外置GPS，设置为未知态 */
        {
            pGNSSRcvStatus->ucGpsAntennaStatus = GPS_ANTENNA_STATE_DONTKNOW;
        }
        return BSP_OK;
    }

    pGNSSRcvStatus->ucGnssId = pRcvData->ucGnssId;

    if (pGNSSRcvStatus->ucGnssId >= 0xff)
    {
        return BSP_ERROR;
    }

    pGNSSRcvStatus->ucFrameMode = BspGetGpsFrameMode(radioMode);
    pGNSSRcvStatus->ullFrameNo = pRcvData->ullFrameNo;
    pGNSSRcvStatus->ulPhaseValue = pRcvData->ulPhaseValue;
    /*pGNSSRcvStatus->ulRefConfigFlag = pRcvData->ulRefConfigFlag;  */
    pGNSSRcvStatus->ucRcvWorkMode = (UCHAR)(pRcvData->ulRcvWorkMode);

    pGNSSRcvStatus->ulSatLostTimes = 0;
    pGNSSRcvStatus->ulAntLeapTimes = pRcvData->ulAntennaBadTimes;
    pGNSSRcvStatus->ucGpsReceiverType = pRcvData->ucRcvType;

    if (UBLOX_Receiver == pRcvData->ucRcvType)
    {
        pGNSSRcvStatus->ucGpsReceiverVersion = pRcvData->ucRcvVersion;
    }

    /* GPS天馈状态。1:正常，126:初始化，127:未知，128:短路，129:开路 */
    if (BSP_CLOCK_REF_SLAVE_PANNEL != pRcvData->ulRcvPlace)
    {
        pGNSSRcvStatus->ucGpsAntennaStatus = pRcvData->ulRcvAntennaStateShow;
    }
    else  /* 级联对外显示天馈状态未知 */
    {
        pGNSSRcvStatus->ucGpsAntennaStatus = GPS_ANTENNA_STATE_DONTKNOW;
    }

    pGNSSRcvStatus->ucGpsReceiverInitFinish = (1 == pRcvData->ulRcvInitFinishFlag) ? 0 : 1;
    pGNSSRcvStatus->ucGpsInitStatus = pRcvData->ucRcvInitStep;
    /* GPS遗留 */
    pGNSSRcvStatus->ucLockBDSatNum = pRcvData->ulLockedSatCnt[BEIDOU_SAT_TYPE];
    pGNSSRcvStatus->ucLockGpsSatNum = pRcvData->ulLockedSatCnt[GPS_SAT_TYPE];
    pGNSSRcvStatus->ucLockGnsSatNum = pRcvData->ulLockedSatCnt[GLONSS_SAT_TYPE];
    pGNSSRcvStatus->ucLockSatState = pRcvData->ulLockSatState;
    pGNSSRcvStatus->cLeapSeconds = pRcvData->ucLeapSeconds;

    /* 内置或gps级联接收机串口不通指示，0表示正常，1表示不通 */
    if (GPS_ANTENNA_STATE_OK == pRcvData->ulRcvAntennaStateShow)
    {
        ucUartErrState = SatRefUartErrState(pRcvData->ulRcvPlace);
        pGNSSRcvStatus->ucGpsUartErr = ucUartErrState;
    }

    pGNSSRcvStatus->ucGpsFixType = pRcvData->ulRcvFixStatus;
    /* 同8854告警策略保持一致，如果检测到UART链路断， 清空记录卫星数据，置链路状态断 @2018.4.5*/
    if (pGNSSRcvStatus->ucGpsUartErr != 0)
    {
        pGNSSRcvStatus->ucGpsAntennaStatus = GPS_ANTENNA_STATE_DONTKNOW;
        pGNSSRcvStatus->ucLockGpsSatNum = 0;
        pGNSSRcvStatus->ucLockBDSatNum = 0;
        pGNSSRcvStatus->ucGpsUartErr = 1;
        pGNSSRcvStatus->ucGpsFixType = 0;
        memset((pGNSSRcvStatus->tSatDetails), 0, sizeof(T_SAT_DETAILS) * 16);
    }

    /* gps time */
    if (0 == pRcvData->tGpsDate.YEAR)
    {
        ucTmpChar = 0;
    }
    else
    {
        ucTmpChar = (UCHAR)(pRcvData->tGpsDate.YEAR - 2000);
    }

    pGNSSRcvStatus->aucRcvGpsTime[0] = ucTmpChar / 10;
    pGNSSRcvStatus->aucRcvGpsTime[1] = ucTmpChar % 10;
    pGNSSRcvStatus->aucRcvGpsTime[2] = (UCHAR)(pRcvData->tGpsDate.DAYS / 100);    /*Hundreds of Days*/
    ucTmpChar = (UCHAR)(pRcvData->tGpsDate.DAYS % 100);
    pGNSSRcvStatus->aucRcvGpsTime[3] = ucTmpChar / 10;         /* TENS OF DAYS*/
    pGNSSRcvStatus->aucRcvGpsTime[4] = ucTmpChar % 10;         /* UNITE OF DAYS*/
    pGNSSRcvStatus->aucRcvGpsTime[5] = pRcvData->tGpsDate.HOUR / 10;    /* TENS OF HOURS*/
    pGNSSRcvStatus->aucRcvGpsTime[6] = pRcvData->tGpsDate.HOUR % 10;    /* UNITE OF HOURS*/
    pGNSSRcvStatus->aucRcvGpsTime[7] = pRcvData->tGpsDate.MIN / 10;     /* TENS OF MIN */
    pGNSSRcvStatus->aucRcvGpsTime[8] = pRcvData->tGpsDate.MIN % 10;     /* UNITE OF MIN*/
    pGNSSRcvStatus->aucRcvGpsTime[9] = pRcvData->tGpsDate.SEC / 10;     /* TENS OF SEC */
    pGNSSRcvStatus->aucRcvGpsTime[10] = pRcvData->tGpsDate.SEC % 10;    /* UNITE OF SEC */
    /* utc time */
    if (BSP_OK == ClockCreateUtcTime(pRcvData->tGpsDate, (char)(pRcvData->ucLeapSeconds), &tLocalUtcOriginTod))
    {
        if (0 == tLocalUtcOriginTod.YEAR)
        {
            ucTmpChar = 0;
        }
        else
        {
            ucTmpChar = (UCHAR)(tLocalUtcOriginTod.YEAR - 2000);
        }

        pGNSSRcvStatus->aucRcvUtcTime[0] = ucTmpChar / 10;
        pGNSSRcvStatus->aucRcvUtcTime[1] = ucTmpChar % 10;
        pGNSSRcvStatus->aucRcvUtcTime[2] = (UCHAR)(tLocalUtcOriginTod.DAYS / 100);    /*Hundreds of Days*/
        ucTmpChar = (UCHAR)(tLocalUtcOriginTod.DAYS % 100);
        pGNSSRcvStatus->aucRcvUtcTime[3] = ucTmpChar / 10;         /* TENS OF DAYS*/
        pGNSSRcvStatus->aucRcvUtcTime[4] = ucTmpChar % 10;         /* UNITE OF DAYS*/
        pGNSSRcvStatus->aucRcvUtcTime[5] = tLocalUtcOriginTod.HOUR / 10;    /* TENS OF HOURS*/
        pGNSSRcvStatus->aucRcvUtcTime[6] = tLocalUtcOriginTod.HOUR % 10;    /* UNITE OF HOURS*/
        pGNSSRcvStatus->aucRcvUtcTime[7] = tLocalUtcOriginTod.MIN / 10;     /* TENS OF MIN */
        pGNSSRcvStatus->aucRcvUtcTime[8] = tLocalUtcOriginTod.MIN % 10;     /* UNITE OF MIN*/
        pGNSSRcvStatus->aucRcvUtcTime[9] = tLocalUtcOriginTod.SEC / 10;     /* TENS OF SEC */
        pGNSSRcvStatus->aucRcvUtcTime[10] = tLocalUtcOriginTod.SEC % 10;    /* UNITE OF SEC */
    }
    else
    {
        /* 转换失败则赋值gps时间给utc时间，应该全部为0 */
        memcpy_s((pGNSSRcvStatus->aucRcvUtcTime), sizeof(pGNSSRcvStatus->aucRcvUtcTime), (pGNSSRcvStatus->aucRcvGpsTime), sizeof(pGNSSRcvStatus->aucRcvGpsTime));
    }

    memcpy_s(&(pGNSSRcvStatus->tPosition), sizeof(T_POSITION), &(pRcvData->tPositionInfo), sizeof(T_POSITION)); /* 位置信息 */
    if(GPS_ANTENNA_STATE_OK == pRcvData->ulRcvAntennaStateShow)
    {
        if(0 != pRcvData->tSatInVew[GPS_SAT_TYPE].ucNumOfSatInView)
        {
            for(ulLoop = 0; ulLoop < pRcvData->tSatInVew[GPS_SAT_TYPE].ucNumOfSatInView; ulLoop++)
            {
                memcpy_s(&(pGNSSRcvStatus->tSatDetails[ulSatCnt++]),sizeof(T_SAT_DETAILS),&(pRcvData->tSatInVew[GPS_SAT_TYPE].atSatInViewDetails[ulLoop]),sizeof(T_SAT_DETAILS));
            }
        }

        if(0 != pRcvData->tSatInVew[BEIDOU_SAT_TYPE].ucNumOfSatInView)
        {
            for(ulLoop = 0; ulLoop < pRcvData->tSatInVew[BEIDOU_SAT_TYPE].ucNumOfSatInView; ulLoop++)
            {
                memcpy_s(&(pGNSSRcvStatus->tSatDetails[ulSatCnt++]),sizeof(T_SAT_DETAILS),&(pRcvData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[ulLoop]),sizeof(T_SAT_DETAILS));
            }
        }
        else if(0 != pRcvData->tSatInVew[GLONSS_SAT_TYPE].ucNumOfSatInView)
        {
            for(ulLoop = 0; ulLoop < pRcvData->tSatInVew[GLONSS_SAT_TYPE].ucNumOfSatInView; ulLoop++)
            {
                memcpy_s(&(pGNSSRcvStatus->tSatDetails[ulSatCnt++]),sizeof(T_SAT_DETAILS),&(pRcvData->tSatInVew[GLONSS_SAT_TYPE].atSatInViewDetails[ulLoop]),sizeof(T_SAT_DETAILS));
            }
        }
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称： UbloxRcvManualReset
* 功能描述： 手动复位ubx接收机(目前只支持内置ublox)
* 输入参数： ucResetMode: 0: 重新初始化；1: 断电再初始化
* 输出参数： 无
* 返 回 值： BSP_OK:复位成功；BSP_ERROR:复位失败
* -----------------------------------------------------------------------
* 其它说明：
* 修改日期     版本号     修改人         修改内容
* 2010-11-30   V1.0       jiaran         创建
**************************************************************************/
ULONG UbloxRcvManualReset(UCHAR ucResetMode)
{
    ULONG ulRetVal = BSP_OK;

    if (BSP_OK != GpsReceiverReset(ucResetMode, (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData))
    {
        ulRetVal = BSP_ERROR;
    }

    return ulRetVal;
}

/* 增加告警防抖 */
enum
{
    GPS_ALM_GPS_UART_ERR = 0,
    GPS_ALM_GPS_ANT_BREAK_ERR,
    GPS_ALM_GPS_ANT_SHORT_ERR,
    GPS_ALM_GPS_SAT_ERR,
    GPS_ALM_GPS_SAT_FAKE,
    GPS_ALM_GPS_PPS_ERR,
    GPS_ALM_GPS_ERR_NUM
};


struct tagT_GpsAlmTimeThre
{
    const char *desc;
    ULONG almThre;
    ULONG almRecThre;
    ULONG norRecThre;
    ULONG almValue;
    ULONG okValue;
    ULONG lastAlmState;
    ULONG lastOkTime;
    ULONG lastErrTime;
} tGpsAlmThre[GPS_ALM_GPS_ERR_NUM] =
{
    {"uartErr  ", 566, 300, 30, 1,  0, 0, 0, 0},
    {"antBreak ",568, 300, 30, GPS_ANTENNA_STATE_BREAK,1, 0, 0, 0},
    {"antShort ",568, 300, 30, GPS_ANTENNA_STATE_SHORT,1, 0, 0, 0},
    {"satUnlock", 0,   0,  0, 2,  0, 0, 0, 0},
    {"fakeGps", 0,   0,  0, 3,  0, 0, 0, 0},
    {"ppsLost  ", 570, 300, 30, 1,  0, 0, 0, 0}
};

VOID gpsalmvar(VOID)
{
    ULONG ulLoop = 0;

    dbgInfo("staDesc  almThre almRecThre norRecThre almValue okValue lastAlmState   lastOkTime   lastErrTime\n");
    for (ulLoop = 0; ulLoop < NELEMENTS(tGpsAlmThre); ulLoop++)
    {
        dbgInfo("%-8s %-7d %-10d %-10d %-8d %-12d %-12d %-12d %-12d\n",
                tGpsAlmThre[ulLoop].desc, tGpsAlmThre[ulLoop].almThre,
                tGpsAlmThre[ulLoop].almRecThre, tGpsAlmThre[ulLoop].norRecThre,
                tGpsAlmThre[ulLoop].almValue, tGpsAlmThre[ulLoop].okValue, tGpsAlmThre[ulLoop].lastAlmState,
                tGpsAlmThre[ulLoop].lastOkTime, tGpsAlmThre[ulLoop].lastErrTime);
    }
}

VOID GpsAlmStateInit(VOID)
{
    UINT32 loop;
    for (loop = 0; loop < NELEMENTS(tGpsAlmThre); loop++)
    {
        tGpsAlmThre[loop].lastAlmState = 0;
    }
}

ULONG GetGpsAlmRecThre(ULONG ucAlmType, T_GPS_RCV_DRV_DATA *ptRcvData, ULONG *almThre, ULONG *recThre, UCHAR *lastState)
{
    UCHAR ucAlmState = 0;
    UCHAR ucAlmValue = 0;
    if ((NULL == ptRcvData) || (NULL == almThre) || (NULL == recThre) || (NULL == lastState))
    {
        return BSP_ERROR_NULL_POINTER;
    }
    if (ucAlmType >= GPS_ALM_GPS_ERR_NUM)
    {
        return BSP_ERROR;
    }
    ucAlmValue = (UCHAR)tGpsAlmThre[ucAlmType].almValue;
    if (ucAlmType == GPS_ALM_GPS_UART_ERR)
    {
        ucAlmState = ptRcvData->tAlmStatus.ucGpsUartErr;
    }
    else if (ucAlmType == GPS_ALM_GPS_ANT_BREAK_ERR)
    {
        ucAlmState = ptRcvData->tAlmStatus.ucGpsAntennaStatus;
    }
    else if (ucAlmType == GPS_ALM_GPS_ANT_SHORT_ERR)
    {
        ucAlmState = ptRcvData->tAlmStatus.ucGpsAntennaStatus;
    }
    else if (ucAlmType == GPS_ALM_GPS_SAT_ERR)
    {
        ucAlmState = ptRcvData->tAlmStatus.ucLockSatState;
    }
    else
    {
        ucAlmState = ptRcvData->tAlmStatus.ucRefPpsStatus;
    }

    *almThre = tGpsAlmThre[ucAlmType].almThre;
    if (ucAlmState == ucAlmValue)
    {
        *recThre = tGpsAlmThre[ucAlmType].almRecThre;
    }
    else
    {
        *recThre = tGpsAlmThre[ucAlmType].norRecThre;
    }
    *lastState = ucAlmState;
    GPS_LOG(GPS_ALM_PRN, "almThre = %u, recThre = %u,lastState = %u.\n", *almThre, *recThre, *lastState);
    return BSP_OK;
}

UCHAR GpsAlmMask(UCHAR ucAlmType, UCHAR ucAlmState,T_GPS_RCV_DRV_DATA *ptRcvData)
{
    ULONG almThre = 0;
    ULONG recThre = 0;
    UCHAR state   = 0;
    ULONG bookTime = 0;

    if (ucAlmType >= GPS_ALM_GPS_ERR_NUM)
    {
        return state;
    }

    state = tGpsAlmThre[ucAlmType].okValue;
    bookTime = GetBookTime();
    GetGpsAlmRecThre(ucAlmType,ptRcvData,&almThre,&recThre,&state);

    if (ucAlmState == tGpsAlmThre[ucAlmType].almValue)
    {
        if (tGpsAlmThre[ucAlmType].lastAlmState == tGpsAlmThre[ucAlmType].almValue)
        {
            if (bookTime > (tGpsAlmThre[ucAlmType].lastErrTime + almThre))
            {
                state = tGpsAlmThre[ucAlmType].almValue;
            }
        }
        else
        {
            tGpsAlmThre[ucAlmType].lastErrTime  = bookTime;
            tGpsAlmThre[ucAlmType].lastAlmState = ucAlmState;
        }
    }
    else if (ucAlmState == tGpsAlmThre[ucAlmType].okValue)
    {
        if (tGpsAlmThre[ucAlmType].lastAlmState == tGpsAlmThre[ucAlmType].okValue)
        {
            if (bookTime > (tGpsAlmThre[ucAlmType].lastOkTime + recThre))
            {
                state = tGpsAlmThre[ucAlmType].okValue;
            }
        }
        else
        {
            tGpsAlmThre[ucAlmType].lastOkTime  = bookTime;
            tGpsAlmThre[ucAlmType].lastAlmState = ucAlmState;
        }
    }
    else
    {
        tGpsAlmThre[ucAlmType].lastOkTime   = bookTime;
        tGpsAlmThre[ucAlmType].lastErrTime  = bookTime;
        tGpsAlmThre[ucAlmType].lastAlmState = ucAlmState;
    }
    GPS_LOG(GPS_ALM_PRN, "ucAlmState = %u, state = %u.\n", ucAlmState, state);
    return state;
}

UCHAR uartErrLastSta = 0;
UCHAR refPpsLastSta  = 0;
UCHAR antennaLastSta = GPS_ANTENNA_STATE_OK;
UCHAR lockSatLastSta = 0;

ULONG UbloxRcvAlarmGet(T_GNSS_ALARM_STATUS *ptGnssAlarmStatus, T_GPS_RCV_DRV_DATA *ptRcvData)
{

    UCHAR ucUartErrState = 0;
    UCHAR ucRefPpsState  = 0;
    UCHAR ucAntennaState = 0;
    UCHAR ucLockSatState = 0;
    UCHAR ucTmpShortSta  = 0;
    UCHAR ucTmpOpenSta   = 0;
    UCHAR ucAntShortState= 0;
    UCHAR ucAntBreakState= 0;
    UINT8 ucTmpLockState = 0;
    INT32 len            = 0;
    T_GNSS_ALARM_STATUS tmpAlmStatus = {0};
    char almStrLog[GNSS_LOG_LINE_SIZE] = {0};

    if((NULL == ptGnssAlarmStatus) || (NULL == ptRcvData))
    {
       return BSP_ERROR_NULL_POINTER;
    }

    memset(ptGnssAlarmStatus, 0,sizeof(T_GNSS_ALARM_STATUS));
    memset(&tmpAlmStatus, 0, sizeof(T_GNSS_ALARM_STATUS));

    ucUartErrState = SatRefUartErrState(ptRcvData->ulRcvPlace);
    ucAntennaState = (UCHAR)ptRcvData->ulRcvAntennaStateShow;
    ucLockSatState = (UCHAR)ptRcvData->ulLockSatState;
    ucRefPpsState  = _BspGetPp1sLostEvent();

    if ((ucUartErrState != uartErrLastSta) || (ucRefPpsState != refPpsLastSta) ||
        (ucAntennaState != antennaLastSta) || (ucLockSatState!=lockSatLastSta))
    {
        len = snprintf_s(almStrLog, sizeof(almStrLog),"uart(%d),refpps(%d),antsta(%d),locksta(%d)\0",
            ucUartErrState, ucRefPpsState, ucAntennaState,ucLockSatState);
        SNPRINTF_S_CHECK(len, sizeof(almStrLog));
        BspAddGnssLog(GNSS_LOG_TYPE_ALARM, almStrLog,len);
    }
    uartErrLastSta = ucUartErrState;
    refPpsLastSta  = ucRefPpsState;
    antennaLastSta = ucAntennaState;
    lockSatLastSta = ucLockSatState;
    ucAntShortState= (ucAntennaState == GPS_ANTENNA_STATE_SHORT) ? ucAntennaState : GPS_ANTENNA_STATE_OK;
    ucAntBreakState= (ucAntennaState == GPS_ANTENNA_STATE_BREAK) ? ucAntennaState : GPS_ANTENNA_STATE_OK;

    if (ucUartErrState == 1)
    {
        if (BSP_CLOCK_REF_INTERNAL_GPS != ptRcvData->ulRcvPlace)
        {
            ucAntShortState = GPS_ANTENNA_STATE_OK;
            ucAntBreakState = GPS_ANTENNA_STATE_OK;
        }
        ucLockSatState = 0;
        ucRefPpsState = 0;
    }

    tmpAlmStatus.ucSatLost = 0;
    tmpAlmStatus.ucGpsUartErr        = GpsAlmMask(GPS_ALM_GPS_UART_ERR,ucUartErrState,ptRcvData);
    ucTmpShortSta                    = GpsAlmMask(GPS_ALM_GPS_ANT_SHORT_ERR,ucAntShortState,ptRcvData);
    ucTmpOpenSta                     = GpsAlmMask(GPS_ALM_GPS_ANT_BREAK_ERR,ucAntBreakState,ptRcvData);

    if (ucTmpShortSta == GPS_ANTENNA_STATE_SHORT)
    {
       tmpAlmStatus.ucGpsAntennaStatus = GPS_ANTENNA_STATE_SHORT;
    }
    else if (ucTmpOpenSta == GPS_ANTENNA_STATE_BREAK)
    {
       tmpAlmStatus.ucGpsAntennaStatus = GPS_ANTENNA_STATE_BREAK;
    }
    else
    {
       tmpAlmStatus.ucGpsAntennaStatus = GPS_ANTENNA_STATE_OK;
    }

    if (tmpAlmStatus.ucGpsAntennaStatus != GPS_ANTENNA_STATE_OK)
    {
        ucLockSatState = 0;
        ucRefPpsState = 0;
    }

    ucTmpLockState = GpsAlmMask(GPS_ALM_GPS_SAT_ERR,ucLockSatState,ptRcvData);
    ucTmpLockState |= GpsAlmMask(GPS_ALM_GPS_SAT_FAKE,ucLockSatState,ptRcvData);

    tmpAlmStatus.ucLockSatState      = ucTmpLockState;
    tmpAlmStatus.ucRefPpsStatus      = GpsAlmMask(GPS_ALM_GPS_PPS_ERR,ucRefPpsState,ptRcvData);

    if (tmpAlmStatus.ucGpsUartErr == 1)
    {
       tmpAlmStatus.ucLockSatState = 1;
       tmpAlmStatus.ucRefPpsStatus = 0;
       if (BSP_CLOCK_REF_INTERNAL_GPS != ptRcvData->ulRcvPlace)
       {
           tmpAlmStatus.ucGpsAntennaStatus = GPS_ANTENNA_STATE_DONTKNOW;
        }
    }

    if (tmpAlmStatus.ucGpsAntennaStatus != GPS_ANTENNA_STATE_OK)
    {
       tmpAlmStatus.ucLockSatState = 1;
       tmpAlmStatus.ucRefPpsStatus = 0;
    }

    /*  清除Pp1s丢失事件告警 */
    _BspClrPp1sLostEvent();

    memcpy_s(&ptRcvData->tAlmStatus, sizeof(T_GNSS_ALARM_STATUS), &tmpAlmStatus, sizeof(T_GNSS_ALARM_STATUS));
    memcpy_s(ptGnssAlarmStatus, sizeof(T_GNSS_ALARM_STATUS), &tmpAlmStatus, sizeof(T_GNSS_ALARM_STATUS));
    return BSP_OK;
}

/*******************************ublox接收机驱动对外接口函数 end********************/
/* 可维可测函数系列 */
/**************************************************************************
函数名称:  ShowUbxRcvInfo
功能描述:  显示GPS常用信息
输入参数:  ulShowMode:接收机模式：
           0/1：内置信息，
           ulMoreInfo:0xff：全部信息
输出参数:
返 回 值:  BSP_OK:操作成功
附加说明:
修改说明:
修改日期          版本号      修改人      修改内容
-----------------------------------------------
2010-4-8             1.0         SDRBSP        创建
**************************************************************************/
void ShowUbxRcvInfo(ULONG ulShowMode, ULONG ulMoreInfo)
{
    UCHAR Cnt;
    T_GPS_RCV_DRV_DATA *pShowData = NULL;

    /* 内置 */
    if ((0 == ulShowMode) || (1 == ulShowMode))
    {
        if (NULL == g_IntRcvDrvData)
        {
            dbgInfo("Int Rcv Data is Null\n");
            return;
        }

        pShowData = (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData;
    }
    else
    {
        dbgInfo("Ublox Rcv Help Input Err,Corresponding Ref Baby Id.\n");
        return;
    }

    dbgInfo("-----------------------Config Data -------------------------\n");
    dbgInfo("ulRcvPlace = %d (correspond with Baby Id)\n", pShowData->ulRcvPlace);
    dbgInfo("ulRefConfigFlag = %s\n", pShowData->ulRefConfigFlag ? "Configed" : "Not Config");
    dbgInfo("ulLeastSatNum = %d \n", pShowData->ulLeastSatNum);
    dbgInfo("lAntCabDelay = %d (ns)\n", pShowData->lAntCabDelay);
    dbgInfo("ulTimeMode = %d (1:auto;2:fix)\n", pShowData->ulTimeMode);
    dbgInfo("ulTimeModeLast = %d (1:auto;2:fix)\n", pShowData->ulTimeModeLast);

    if (SATELLITE_FIXED_MODE == pShowData->ulTimeMode)
    {
        dbgInfo("dLatitude = %f (°)\n", pShowData->dLatitude);
        dbgInfo("dLongitude = %f (°)\n", pShowData->dLongitude);
        dbgInfo("dAltitude = %f (m)\n", pShowData->dAltitude);
    }

    dbgInfo("-----------------------Extern Rcv Variable Info ------------\n");
    dbgInfo("ulRcvUseableFlag = %d (1：not Ok; 2:OK)\n", pShowData->ulRcvUseableFlag);
    dbgInfo("-----------------------Rcv Invariable Info -----------------\n");
    dbgInfo("ucRcvType = %d \n", pShowData->ucRcvType);
    dbgInfo("ucRcvVersion = %d (4:4T;5:5T)\n", pShowData->ucRcvVersion);
    taskDelay(sysClkRateGet() / 2);
    dbgInfo("-----------------------Rcv Variable Info -------------------\n");
    dbgInfo("ulRcvInitStartTime = %d \n", pShowData->ulRcvInitStartTime);
    dbgInfo("ulRcvInitFinishTime = %d \n", pShowData->ulRcvInitFinishTime);
    dbgInfo("ulRcvInitFinishFlag = %d \n", pShowData->ulRcvInitFinishFlag);
    dbgInfo("ucRcvInitStep = %d \n", pShowData->ucRcvInitStep);
    dbgInfo("ulRcvAntennaState = %d (1:ok;128:short;129:open)\n", pShowData->ulRcvAntennaState);
    dbgInfo("ulRcvAntennaStateShow = %d (1:ok;128:short;129:open)\n", pShowData->ulRcvAntennaStateShow);
    dbgInfo("ulRcvFixStatus = %d (3:2D;4:3D;5:T_only)\n", pShowData->ulRcvFixStatus);
    dbgInfo("ulUsedTimeMode = %d (1:auto;2:fix)\n", pShowData->ulUsingTimeMode);
    dbgInfo("ulRealWorkMode = %d (1:gps;5:bd;6:gps-bd)\n", pShowData->ulRcvRealWorkMode);
    dbgInfo("ulLockSatState = %d \n", pShowData->ulLockSatState);
    dbgInfo("ulAntennaBadTimes = %d \n", pShowData->ulAntennaBadTimes);
    dbgInfo("ulRcvResetTimes = %d \n", pShowData->ulRcvResetTimes);
    dbgInfo("ulAvlSatCnt = %d \n", pShowData->ulAvlSatCnt[GPS_SAT_TYPE] + pShowData->ulAvlSatCnt[BEIDOU_SAT_TYPE]);
    dbgInfo("ulTrackedSatCnt = %d \n", pShowData->ulTrackedSatCnt[GPS_SAT_TYPE] + pShowData->ulTrackedSatCnt[BEIDOU_SAT_TYPE]);
    dbgInfo("ulLockedSatCnt = %d \n", pShowData->ulLockedSatCnt[GPS_SAT_TYPE] + pShowData->ulLockedSatCnt[BEIDOU_SAT_TYPE]);
    //dbgInfo("Gln ulAvlSatCnt = %d \n", pShowData->ulAvlSatCnt[GLONSS_SAT_TYPE]);
    //dbgInfo("Gln ulTrackedSatCnt = %d \n", pShowData->ulTrackedSatCnt[GLONSS_SAT_TYPE]);
    //dbgInfo("Gln ulLockedSatCnt = %d \n", pShowData->ulLockedSatCnt[GLONSS_SAT_TYPE]);
    //dbgInfo("Bd ulAvlSatCnt = %d \n", pShowData->ulAvlSatCnt[BEIDOU_SAT_TYPE]);
    //dbgInfo("Bd ulTrackedSatCnt = %d \n", pShowData->ulTrackedSatCnt[BEIDOU_SAT_TYPE]);
    //dbgInfo("Bd ulLockedSatCnt = %d \n", pShowData->ulLockedSatCnt[BEIDOU_SAT_TYPE]);
    taskDelay(sysClkRateGet() * 1);
    if (0 != (pShowData->tSatInVew[GPS_SAT_TYPE].ucNumOfSatInView + pShowData->tSatInVew[BEIDOU_SAT_TYPE].ucNumOfSatInView))
    {
        dbgInfo("\tNo.\tElevation\tAzimuth\tCno\tState\tsattype(gpsnum:%d,beidounum:%d)\n",
            pShowData->tSatInVew[GPS_SAT_TYPE].ucNumOfSatInView, pShowData->tSatInVew[BEIDOU_SAT_TYPE].ucNumOfSatInView);

        for (Cnt = 0; Cnt < pShowData->tSatInVew[GPS_SAT_TYPE].ucNumOfSatInView; Cnt++)
        {
            dbgInfo("\t%d\t\t%d\t%d\t%d\t%d\t%d\n",
                   pShowData->tSatInVew[GPS_SAT_TYPE].atSatInViewDetails[Cnt].ucSatId,
                   pShowData->tSatInVew[GPS_SAT_TYPE].atSatInViewDetails[Cnt].ucElevation,
                   pShowData->tSatInVew[GPS_SAT_TYPE].atSatInViewDetails[Cnt].usAzimuth,
                   pShowData->tSatInVew[GPS_SAT_TYPE].atSatInViewDetails[Cnt].usCno,
                   pShowData->tSatInVew[GPS_SAT_TYPE].atSatInViewDetails[Cnt].ucState,
                   pShowData->tSatInVew[GPS_SAT_TYPE].atSatInViewDetails[Cnt].ucSatType);
        }

        dbgInfo("****************************************************************\n");
        for (Cnt = 0; Cnt < pShowData->tSatInVew[BEIDOU_SAT_TYPE].ucNumOfSatInView; Cnt++)
        {
            dbgInfo("\t%d\t\t%d\t%d\t%d\t%d\t%d\n",
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].ucSatId,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].ucElevation,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].usAzimuth,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].usCno,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].ucState,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].ucSatType);
        }
    }
#if 0
    if (0 != pShowData->tSatInVew[GLONSS_SAT_TYPE].ucNumOfSatInView)
    {
        dbgInfo("\tNo.\tElevation\tAzimuth\tCno\tState\n");

        for (Cnt = 0; Cnt < pShowData->tSatInVew[GLONSS_SAT_TYPE].ucNumOfSatInView; Cnt++)
        {
            dbgInfo("\t%d\t\t%d\t%d\t%d\t%d\n",
                   pShowData->tSatInVew[GLONSS_SAT_TYPE].atSatInViewDetails[Cnt].ucSatId,
                   pShowData->tSatInVew[GLONSS_SAT_TYPE].atSatInViewDetails[Cnt].ucElevation,
                   pShowData->tSatInVew[GLONSS_SAT_TYPE].atSatInViewDetails[Cnt].usAzimuth,
                   pShowData->tSatInVew[GLONSS_SAT_TYPE].atSatInViewDetails[Cnt].usCno,
                   pShowData->tSatInVew[GLONSS_SAT_TYPE].atSatInViewDetails[Cnt].ucState);
        }
    }
    if (0 != pShowData->tSatInVew[BEIDOU_SAT_TYPE].ucNumOfSatInView)
    {
        dbgInfo("\tNo.\tElevation\tAzimuth\tCno\tState\n");

        for (Cnt = 0; Cnt < pShowData->tSatInVew[BEIDOU_SAT_TYPE].ucNumOfSatInView; Cnt++)
        {
            dbgInfo("\t%d\t\t%d\t%d\t%d\t%d\n",
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].ucSatId,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].ucElevation,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].usAzimuth,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].usCno,
                   pShowData->tSatInVew[BEIDOU_SAT_TYPE].atSatInViewDetails[Cnt].ucState);
        }
    }
#endif

    /* 详细信息 */
    if (0xFF == ulMoreInfo)
    {
        taskDelay(sysClkRateGet() / 2);
        dbgInfo("-----------------------Rcv send cmd-------------------------\n");
        dbgInfo("ulRcvCmdNum = %d \n", pShowData->ulRcvCmdNum);
        dbgInfo("ulRcvCmdRunFlag = %d (0:idle；1、running)\n", pShowData->ulRcvCmdRunFlag);
        dbgInfo("ulRcvCmdStartTime = %d (tick)\n", pShowData->ulRcvCmdStartTime);
        dbgInfo("ulRcvCmdTimeOutCnt = %d \n", pShowData->ulRcvCmdTimeOutCnt);
        dbgInfo("ulRcvRstTimesSinceCmd = %d \n", pShowData->ulRcvRstTimesSinceCmd);
        dbgInfo("-----------------------check Rcv is Useable-----------------\n");
        dbgInfo("ulRcvStatusChgSttTime = %d (s)\n", pShowData->ulRcvStatusChgSttTime);
        dbgInfo("-----------------------Rcv Protect--------------------------\n");
        dbgInfo("ulLockFailedTime(start) = %d (s)\n", pShowData->ulLockFailedTime);
        dbgInfo("ulGpsFixNotOkTime(start) = %d (s)\n", pShowData->ulGpsFixNotOkTime);
        dbgInfo("ulGpsNoAckTime(start) = %d (s)\n", pShowData->ulGpsNoAckTime);
        dbgInfo("\nulSatStartTime(start) = %d (s)\n", pShowData->ulSatStartTime);
        dbgInfo("\nulRcvInitNotDoneTime(start) = %d (s)\n", pShowData->ulRcvInitNotDoneTime);
        dbgInfo("Ref Quality Check,Ok Time = %d (s)\n", pShowData->ulRcvOkTime);
        dbgInfo("Ref Quality Check,Err Time = %d (s)\n", pShowData->ulRcvErrTime);
        taskDelay(sysClkRateGet() / 2);
        dbgInfo("-----------------------Rcv reset Info-----------------------\n");

        for (Cnt = 0; Cnt < 5; Cnt++)
        {
            dbgInfo("Rcv Reset Statistic Details[%d] = %d (times)\n", Cnt, pShowData->ulRcvRstDetails[Cnt]);
        }

        dbgInfo("Ref 0:NULL;1:LockFailed;2:FixNotOk;3:ZdaAppear;4:RcvCmdTimeOut \n");
    }

    dbgInfo("-----------------------Fpga reg-----------------------------\n");
    dbgInfo("-----------------------Rcv message--------------------------\n");
    dbgInfo("ucLeapSeconds = %d (s)\n", pShowData->ucLeapSeconds);
    dbgInfo("GpsTime: %d-%d-%d | %d:%d:%d \n", pShowData->tGpsDate.YEAR, pShowData->tGpsDate.MON, pShowData->tGpsDate.DAY,
           pShowData->tGpsDate.HOUR, pShowData->tGpsDate.MIN, pShowData->tGpsDate.SEC);
    dbgInfo("ulRcvTodOkFlag = %d (0:not ok；1、ok)\n", pShowData->ulRcvTodOkFlag);
    dbgInfo("ulSatTodAbnormalTimes = %d (times)\n", pShowData->ulSatTodAbnormalTimes);
    dbgInfo("-----------------------Referrence time----------------------\n");
    dbgInfo("now the tick = %d\n", tickGet());
    dbgInfo("now the BookTime = %d\n", GetBookTime());

    dbgInfo("ucGpsUartErr = %d(0:OK,1:not ok)\n",pShowData->tAlmStatus.ucGpsUartErr);
    dbgInfo("ucGpsAntennaStatus = %d(1:OK,128:short,129:open)\n",pShowData->tAlmStatus.ucGpsAntennaStatus);
    dbgInfo("ucLockSatState = %d(0:OK,2:not ok)\n",pShowData->tAlmStatus.ucLockSatState);
    dbgInfo("ucSatLost = %d(0:OK,1:not ok)\n",pShowData->tAlmStatus.ucSatLost);
    dbgInfo("ucRefPpsStatus = %d(0:OK,1:not ok)\n",pShowData->tAlmStatus.ucRefPpsStatus);
}

/**************************************************************************
* 函数名称： ULONG testFixMode(void)
* 功能描述： 测试接收机的fixed模式
* 输入参数： 0:查询，1: Survey In 2: Fixed Mode
* 输出参数： 无
* 返 回 值： BSP_OK:  测试成功；其他: 测试失败
* 其它说明： 过程说明，首先是获取当前模式，如果与要设置的一致，则不设置，直接返回ok，
*            若不一致，则进行设置，设置成功后再进行当前状态的获取，获取位置信息。
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/11/07  V1.0       SDRBSP         创建
**************************************************************************/

ULONG testFixMode(ULONG ulTimeMode)
{
    double latitud = 22.5830506;
    double longitud = 113.9289650;
    double evelation = 64.139;
    double templatitud = 22.5830506;
    double templongitud = 113.9289650;
    double tempevelation = 64.139;
    ULONG ulRetVal = BSP_OK;
    ULONG ultempTimeMode = 0;
    /* 1、获取当前模式 */
    ulRetVal = UbloxGetGpsRcvTimeMode(&ultempTimeMode, &templatitud, &templongitud, &tempevelation, (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData);

    /* 查询模式时 */
    if (0 == ulTimeMode)
    {
        dbgInfo("--------Time Mode is %d,cur position Get: latitud = %f degree, longitud = %f degree, evelation = %f degree!--------\n",
               ultempTimeMode, templatitud, templongitud, tempevelation);
        return BSP_OK;
    }

    if (ultempTimeMode == ulTimeMode)
    {
        dbgInfo("the receiver is already in mode %d\n", ulTimeMode);
        dbgInfo("--------cur position Get: latitud = %f degree, longitud = %f degree, evelation = %f degree!--------\n",
               templatitud, templongitud, tempevelation);
        return 1;
    }

    if (ulRetVal != BSP_OK)
    {
        dbgInfo("the ulRetVal is %d\n", ulRetVal);
    }

    /*2、当前与要设置模式不一致时，进行设置  */
    dbgInfo("--------FixMode Set: latitud = %f degree, longitud = %f degree, evelation = %f degree!--------\n",
           latitud, longitud, evelation);
    ulRetVal = UbloxSetGpsRcvTimeMode(ulTimeMode, latitud, longitud, evelation, (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData);

    if (BSP_OK != ulRetVal)
    {
        dbgInfo("Ublox Set GpsRcv TimeMode Failed,and the return value is %d\n", ulRetVal);
        return 2;
    }

    /* 设置入参模式后进行当前模式获取(包括模式和位置) */
    ulRetVal = UbloxGetGpsRcvTimeMode(&ultempTimeMode, &templatitud, &templongitud, &tempevelation, (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData);

    if (BSP_OK != ulRetVal)
    {
        dbgInfo("Ublox Get GpsRcv TimeMode Failed,and the return value is %d\n", ulRetVal);
        return 3;
    }
    else
    {
        dbgInfo("--------rcv Work Mode is %d after Set!--------\n", ultempTimeMode);
        dbgInfo("--------TMODE Get: latitud = %f degree, longitud = %f degree, evelation = %f degree!--------\n",
               templatitud, templongitud, tempevelation);
    }

    dbgInfo("--------please check the print info!--------\n");
    return BSP_OK;
}


/**************************************************************************
* 函数名称： UbloxRcvCreateUsableInfo
* 功能描述： 接收机是否可用，提供给卫星类驱动框架
* 输入参数： 接收机各种详细的状态信息(驱动实例结构体)
* 输出参数： 接收机是否可用的总的标志，供卫星类驱动框架调用
* 返 回 值： BSP_OK: 获取信息成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-4-6    V1.0       SDRBSP           创建
**************************************************************************/
ULONG UbloxRcvCreateUsableInfo(T_GPS_RCV_DRV_DATA *pRcvData)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulLocalRcvInfo = 0;/* 接收机信息汇总 */
    T_GPS_RCV_DRV_DATA *pUsableInfoRcvData = NULL;

    /* 入参检测 */
    if (NULL == pRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    pUsableInfoRcvData = pRcvData;
#if 0

    /* 预热时间不够，是否需要？不是接收机的信息 */
    if (OCXO_WARM_UP_TIME > GetBookTime())
    {
        ulLocalRcvInfo |= 0x00000001;
    }

#endif

    /* 除级联从框其他模式外都需要判断天馈状态  */
    if (BSP_CLOCK_REF_SLAVE_PANNEL != pUsableInfoRcvData->ulRcvPlace)
    {
        /* 天馈状态不可用，适用于内置和外置带接收机的情况 */
        if (GPS_ANTENNA_STATE_OK != pUsableInfoRcvData->ulRcvAntennaStateShow)
        {
            ulLocalRcvInfo |= 0x00000002;
        }
    }

    /* 锁定卫星数小于开控门限数 */
    if (pUsableInfoRcvData->ulLeastSatNum > (pUsableInfoRcvData->ulTrackedSatCnt[GPS_SAT_TYPE] + pUsableInfoRcvData->ulTrackedSatCnt[BEIDOU_SAT_TYPE]))
    {
        ulLocalRcvInfo |= 0x00000004;
    }

    /* 不是3d Fix和time only Fix状态 */
    if (
        (SATELLITE_3D_FIX != pUsableInfoRcvData->ulRcvFixStatus)
        && (SATELLITE_TIME_ONLY_FIX != pUsableInfoRcvData->ulRcvFixStatus)
    )
    {
        ulLocalRcvInfo |= 0x00000008;
    }

    /* 除级联从框其他模式外都需要判断接收机是否初始化完成 */
    if (BSP_CLOCK_REF_SLAVE_PANNEL != pUsableInfoRcvData->ulRcvPlace)
    {
        /* 接收机没有初始化完成 */
        if (0 == pUsableInfoRcvData->ulRcvInitFinishFlag)
        {
            ulLocalRcvInfo |= 0x00000010;
        }
    }

    GPS_LOG(GPS_DBG_UBX_DRV, "Rcv Usable details 0x%x\n", ulLocalRcvInfo);
    tgnsssndInfo.localRcvInfo = ulLocalRcvInfo;
    /* 对接收机实例数据进行赋值：是否可用以及持续时间 */
    if (0 == ulLocalRcvInfo)
    {
        pUsableInfoRcvData->ulRcvUseableFlag = CLOCK_REF_USEABLE; /* 接收机可用 */

        if (pUsableInfoRcvData->ulRcvUseableFlag != pUsableInfoRcvData->ulRcvOldUseableFlag)
        {
            pUsableInfoRcvData->ulRcvStatusChgSttTime = GetBookTime();/* 接收机可用开始时刻 */
        }

        pUsableInfoRcvData->ulRcvStatusLastTime = GetBookTime() - pUsableInfoRcvData->ulRcvStatusChgSttTime;
        pUsableInfoRcvData->ulRcvOldUseableFlag = pUsableInfoRcvData->ulRcvUseableFlag;
    }
    else
    {
        pUsableInfoRcvData->ulRcvUseableFlag = CLOCK_REF_UNUSEABLE; /* 接收机不可用 */

        if (pUsableInfoRcvData->ulRcvUseableFlag != pUsableInfoRcvData->ulRcvOldUseableFlag)
        {
            pUsableInfoRcvData->ulRcvStatusChgSttTime = GetBookTime();/* 接收机不可用开始时刻 */
        }

        pUsableInfoRcvData->ulRcvStatusLastTime = GetBookTime() - pUsableInfoRcvData->ulRcvStatusChgSttTime;
        pUsableInfoRcvData->ulRcvOldUseableFlag = pUsableInfoRcvData->ulRcvUseableFlag;
    }

    return ulRetVal;
}



/**************************************************************************
* 函数名称: UbxCfgBaudRate
* 功能描述: 接收机波特率配置
* 输入参数: ulBaudRate:接收机波特率，pRcvData接收机驱动实例指针
* 输出参数: 无
* 返 回 值: BSP_OK 配置成功
*           其它   配置失败
* 其它说明:
* 修改日期     版本号     修改人     修改内容
* ------------------------------------------------------------------------
* 2014-10-20    V1.0      张全士       创建
**************************************************************************/
ULONG UbxCfgBaudRate(ULONG ulBaudRate, T_GPS_RCV_DRV_DATA *pRcvData)
{
    if(NULL == pRcvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    if((9600 != ulBaudRate) && (115200 != ulBaudRate))
    {
        return BSP_ERROR_INVALID_PARA;
    }

    if(0 == pRcvData->ulResv)
    {
        /* 设置接收机波特率 */
        UbxSendCmdCfgBaudRate(ulBaudRate);
    }
    else if(10 == pRcvData->ulResv)
    {
        /* 修改CPU的UART口波特率，以便查询接收机波特率 */
        SetUartBaudrate(ulBaudRate, 0);
        GPS_LOG(GPS_DBG_INIT_PRN,"Set Cpu BaudRate %d\n", ulBaudRate);
    }
    else if((10 < pRcvData->ulResv) && (20 > pRcvData->ulResv))
    {
        /* 查询接收机波特率 */
        if(BSP_OK == GpsSendCmd((UGpsFunPtr)UbxSendCmdPollBaudRate, pRcvData))
        {
            pRcvData->ulResv = 0;
            gulUbxBaudRate = ulBaudRate;
            GPS_LOG(GPS_DBG_INIT_PRN,"Poll BaudRate success!\n");
            return BSP_OK;
        }
    }
    else if(20 <= pRcvData->ulResv)
    {
        /* 查询失败，修改波特率为默认波特率 */
        pRcvData->ulResv = 0;
        SetUartBaudrate(9600, 0);
        GPS_LOG(GPS_DBG_INIT_PRN,"Set Cpu to BaudRate 9600!\n");
        return BSP_ERROR;
    }

    pRcvData->ulResv++;
    return BSP_ERROR;
}

UINT32 BspSetUbloxAlmThre(UINT32 reportTime,UINT32 recoverTime)
{
    if (reportTime == 0 && recoverTime == 0)
    {
        s_ubloxAlmReportThre = SAT_REF_ALARM_LIMIT;
        s_ubloxAlmRecoverThre = SAT_REF_ALARM_RECOVER_LIMIT;
    }
    else
    {
        s_ubloxAlmReportThre  = (reportTime == 0) ? 60 : (reportTime*60);
        s_ubloxAlmRecoverThre = (recoverTime == 0) ? 30 : (recoverTime*60);
    }

    GpsAlmThreUpdate();
    return BSP_OK;
}
VOID GpsAlmThreUpdate(VOID)
{
    UINT32 loop;
    for (loop = 0; loop < NELEMENTS(tGpsAlmThre); loop++)
    {
        if (loop == GPS_ALM_GPS_SAT_ERR)
        {
            continue;
        }
        tGpsAlmThre[loop].almThre = s_ubloxAlmReportThre - CLOCK_REF_BAD_TO_OK_LIMIT;
        tGpsAlmThre[loop].almRecThre = s_ubloxAlmRecoverThre;
    }
}

UINT32 BspGetSatType(VOID)
{
    if (NULL == g_IntRcvDrvData)
    {
        dbgInfo("Int Rcv Data is Null\n");
        return GPS_SAT_TYPE;
    }

    switch(g_IntRcvDrvData->ulRcvWorkMode)
    {
        case 1:
        {
            return GPS_SAT_TYPE;
        }

        case 5:
        {
            return BEIDOU_SAT_TYPE;
        }

        default:
        {
            return GPS_SAT_TYPE;
        }
    }

    return GPS_SAT_TYPE;
}


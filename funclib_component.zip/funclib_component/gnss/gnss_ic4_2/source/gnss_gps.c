/*****************************************************************************
 * 版权所有(C) 2014, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : gps.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : DPDIC 的Gps模块
 * 注意事项 : 无
 * 作    者 : 宋志强
 * 创建日期 : 2014-05-12 10:28:34
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单: $0000000(N/A)
 * 责 任 人: 宋志强
 * 修改日戳: 2014-05-12 10:28:34
 * 变更说明: 创建文件
 *----------------------------------------------------------------------------
 */
#include "bsperrcode.h"
#include "bsppub.h"
#include "bspcomm.h"
#include "chnmapcommon.h"
#include "zte_slibc.h"
#include "bspcommon.h"

/* 单板头文件 */
#include "gnssapi.h"
#include "gnss_gps.h"
#include "gnss_ublox.h"
#include "regdrv_accesstbl.h"
#include "regdrv_access.h"
#include "funccommon.h"
#include "exprn.h"
#include "uart_ic4_2.h"
#include "timedelay_ic4_2.h"
#include "optctrl_cpri_ic4_2.h"

#undef FPGA_SIM_UART

/**************************************************************************
 *                        宏                                              *
 **************************************************************************/
#define GPS_TIMESTAMP_FILE  "./ata/gpstimestamp.txt"


/* IOCTL参数定义 */
#define GPS_UART_LOOP_ENABLE    1

/*GPS_UART_LOOP_DISABLE宏值2在cgel4.x的arm体系和系统宏值定义冲突,因此修改*/
#define GPS_UART_IOCTL_BASE       'g'
#define GPS_UART_LOOP_DISABLE     _IOW (GPS_UART_IOCTL_BASE, 1, unsigned long)
#define GPS_UART_NEW_IOCTRL_BASE  'G'
#define GPS_UART_NEW_LOOP_DISABLE _IOW (GPS_UART_NEW_IOCTRL_BASE, 2, unsigned int)


/**************************************************************************
 *                        常量                                            *
 **************************************************************************/

/**************************************************************************
 *                         数据类型                                       *
 **************************************************************************/

extern UCHAR gucRef;


/**************************************************************************
 *                         全局变量定义                                   *
 **************************************************************************/

FUNC_BUF_CTRL pFuncGnssCallBack = NULL;
FUNC_BUF_CTRL pFuncGnssOfEcpriCallBack = NULL;
FUNC_GPS_INT_MODE_CFG pGpsIntModeCfgCallBack = NULL;
FUNC_GPS_LOCAL_CLK_STA  pFuncGpsLocalClkStatus = NULL;
FUNC_GPS_GET_FPGA_ID pFuncGpsGetFpgaId = NULL;

FUNC_GPS_UART_BAUDRATE pFuncGpsUartBaudRateCallBack = NULL;
FUNC_GPS_UART_INIT pFuncGpsUartInitCallBack = NULL;
FUNC_GPS_SET_REF pFuncGpsSetRefCallBack = NULL;
FUNC_GPS_1PPS_SOURCE pFuncGps1ppsSourceCallBack = NULL;

FUNC_GPS_SEL_8T pGpsGetSel8tFunc = NULL;

#define GNSS_CFG_VALID_ID       0x5a5a5a5a
#define GNSS_CFG_MAX_NUM        4


//UINT32 g_usRruSndCnt = 0;
T_GnssParaInfo s_gnssParaInfo[GNSS_CFG_MAX_NUM] = {0};
static T_GnssBoardInfo s_GnssBoardInfo = {0};
static UINT8 s_RgpsDevInitCtrlFlag = TRUE;


#define GNSS_REGISTER_FUNC_RUN(pSubFunc,...)  if (s_GnssBoardInfo.pSubFunc) return s_GnssBoardInfo.pSubFunc(__VA_ARGS__)
#define GNSS_CFG_VALID_CHK_CON(flag)          if ((flag) != GNSS_CFG_VALID_ID) continue

/* 定义一个接收机驱动实例，框架使用 */
T_GPS_RCV_DRV_DATA *g_RcvDrvData = NULL;


T_RRU_GNSS_FRAME g_tRruGnssFrame = {0};
T_Clock_Tod gtSatLocalTod;
ULONG   g_bIntRcvMsgOn = 0;          /* 内置接收机接受电文状态标志 */
ULONG gulTodAsyncFlag;   /* tod ok flag */
static ULONG sulSatTodTAsyncTimes = 0;
static ULONG sulSyncRcvTodFlag = 0;
static unsigned long sulIntRcvIdenTaskId = 0xFFFFFFFF;
ULONG g_ulProtectTimes = 0xFFFFFFFF;
ULONG g_ulFirstGpsInit = 1;
SEM_ID  g_GpsIntSem = NULL;

LONG    g_ltClkRtTaskId = 0xFFFF;
LONG    g_lGpsRecvTaskId = 0xFFFF;

LONG    g_lPp1sProtectTaskId = (LONG)0xFFFFFFFF;
ULONG   gulSatSyncTodToLocalTimes = 0;
BOOL g_bTodAsync;

UINT32 gul1PpsTodFrameMode = CHINA_MOBILE; /* 主要是来兼容不同运营商的细微区别 */

static UINT32 s_ulPp1sProtectCnt = 0;
/* static UINT32 s_ulDisableIntRun = 0; */ /* 去使能中断执行 */
static UINT32 s_ulPp1sIsrCnt = 0; /* 进入中断次数 */
static UINT32 s_ulPp1sIsrOkCnt = 0; /* 中断顺利返回次数 */
static UINT32 s_ulPp1sInitFlag = 0; /* 中断处理初始化标志 */


UINT32 g_ulClkRunCnt = 0;

static unsigned char g_ucGnssCfgPrint = 0; /* 打开GPS*/

UINT32 ulLostCnt = 0;   /* 连续未收到串口数据次数 */

USHORT g_usRruSndCnt = 0;


UINT32 gnssLogSize  = (1024*1024);
FILE *gnssFp        = NULL;
SEM_ID recordSem    = NULL;
T_LogList *logList  = NULL;
T_GnssSndInfo tgnsssndInfo = {0};
T_GnssCfgLog  tgnssCfgLog  = {0};

UINT32 gnssPhaseErr = 0;

static UINT64 s_RgpsAbnormalStatus = 0;
static UINT32 s_LeastSatNum = 0;
static UINT32 s_LeastSatNumBackup = 0;

/**************************************************************************
 *                         外部变量声明                                   *
 **************************************************************************/
extern UCHAR g_ucIntGpsUartErr;

extern volatile T_GPS_RCV_DRV_DATA *g_IntRcvDrvData;
extern T_FpgaUartBuffer    g_tGcmUartIdPhyBuf;
extern T_FpgaUartBuffer    g_tGcmUartPhyBuf;    /* GPS接收机物理侧缓冲区，供UART0的HOOK使用 */
extern T_FpgaUartBuffer g_tGcmUartSwBuf;/* GPS模块的输入输出缓冲区 */

extern SEM_ID g_AasIntSem;

extern T_FpgaUartBuffer    g_tGcmUartSwBuf;/* GPS模块的输入输出缓冲区 */
extern T_SAT_RCV_FUNC gSatIntRcvFunc;

/**************************************************************************
 *                         外部函数声明                                   *
 **************************************************************************/


/**************************************************************************
 *                         局部函数声明                                   *
 **************************************************************************/
BOOL BspGetSatLocalTodStas(void);
UINT32 BspRecordGnssLog(VOID);
/**************************************************************************
 *                         全局函数实现                                   *
 **************************************************************************/
T_GpsInfo g_GpsInfo = {0,};

/*@@@@@@@@@@@@@@@@@@@@@@@@@公共局部函数@@@@@@@@@@@@@@@@@@@@@@@@@@@*/



/**************************************************************************
*                         函数实现
**************************************************************************/
ULONG _BspInitGpsInfo(T_GpsInfo *pgpsInfo)
{
    INPUT_POINTER_CHECK(pgpsInfo)
    INPUT_POINTER_CHECK(pgpsInfo->GetPp1sLost);
    INPUT_POINTER_CHECK(pgpsInfo->ClrPp1sLost);
    INPUT_POINTER_CHECK(pgpsInfo->GetPp1sOffset);
    INPUT_POINTER_CHECK(pgpsInfo->GetGpsLockFrame);
    INPUT_POINTER_CHECK(pgpsInfo->InitPp1sInt);
    INPUT_POINTER_CHECK(pgpsInfo->Send);
    INPUT_POINTER_CHECK(pgpsInfo->Recv);
    if(NULL == pgpsInfo->FuncSem)
    {
        dbgErr("%s:sem is NULL!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset((char *)&g_GpsInfo, 0 , sizeof(T_GpsInfo));
    memcpy((char *)&g_GpsInfo, (char *)pgpsInfo, sizeof(T_GpsInfo));
    return BSP_OK;
}

UINT32 BspSetGpsBoardInfo(T_GnssBoardInfo *pInfo)
{
    memmove((void *)&s_GnssBoardInfo, pInfo, sizeof(T_GnssBoardInfo));
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetPp1sLostEvent(*)
 * 功能描述: 封装一层bsp接口
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年04月29日 尧小安00109169    创建
 **************************************************************************/
ULONG _BspGetPp1sLostEvent(void)
{
    #if 0
    INPUT_POINTER_CHECK(g_GpsInfo.GetPp1sLost);
    return g_GpsInfo.GetPp1sLost();
    #else
    UINT32 ulEvt    = 0;
    UINT32 ulRet    = 0;
    UINT32 bbFpgaId = 0;
    UINT32 fpgaChan = 0;
    UINT32 phyOpt   = 0;

    GNSS_REGISTER_FUNC_RUN(pGetPp1sLostEvent);

    if((BSP_RADIO_STANDARD_LTE_TDD == BspGetRadioStandard())||(BSP_RADIO_STANDARD_LTE_FDD == BspGetRadioStandard()))
    {
        phyOpt = BspGetCurrFiberPort();
        BspGetFpgaIdxByPhyOpt(phyOpt, &bbFpgaId, &fpgaChan,E_FPGA_TYPE_OPT);
    }

    BspRegRd(bbFpgaId, REG_FPGA_RGPS_PP1S_LOST_EVENT, 0, &ulEvt);
    ulRet = (ulEvt == 0)? GPS_PP1S_STATE_OK : GPS_PP1S_STATE_ALARM;

    /* 制造PP1S丢失异常，上报PP1S异常告警 */
    if(GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GNSS_PP1S_LOST))
    {
        return GPS_PP1S_STATE_ALARM;
    }

    return ulRet;
    #endif
}

/**************************************************************************
 * 函数名称: _BspClrPp1sLostEvent(*)
 * 功能描述: 封装一层bsp接口
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年04月29日 尧小安00109169    创建
 **************************************************************************/
ULONG _BspClrPp1sLostEvent(VOID)
{
    #if 0
    INPUT_POINTER_CHECK(g_GpsInfo.ClrPp1sLost);
    return g_GpsInfo.ClrPp1sLost();
    #else
    UINT32  bbFpgaId = 0;
    UINT32  fpgaChan = 0;
    UINT32  phyOpt   = 0;

    GNSS_REGISTER_FUNC_RUN(pClrPp1sLostEvent);

    if((BSP_RADIO_STANDARD_LTE_TDD == BspGetRadioStandard())||(BSP_RADIO_STANDARD_LTE_FDD == BspGetRadioStandard()))
    {
        phyOpt = BspGetCurrFiberPort();
        BspGetFpgaIdxByPhyOpt(phyOpt, &bbFpgaId, &fpgaChan,E_FPGA_TYPE_OPT);
    }

    BspRegWr(bbFpgaId, REG_FPGA_RGPS_PP1S_LOST_EVENT_CLR, 0, 1);
    BspSysUsDelay(100);
    BspRegWr(bbFpgaId, REG_FPGA_RGPS_PP1S_LOST_EVENT_CLR, 0, 0);
    return BSP_OK;
    #endif
}


/*---------------------------------------------------------------------------*/
/*                           BSP内部函数实现                                    */
/*---------------------------------------------------------------------------*/
/**************************************************************************
 * 函数名称: _BspGetPp1sOffset(*)
 * 功能描述: 鉴相值
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: GPS鉴相值
 * 其它说明: GPS鉴相值 25bit,0x01000为低16bit，0x01001为高9bit
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年07月18日 周敏10207549      创建
 **************************************************************************/
ULONG _BspGetPp1sOffset(UINT32 radioMode)
{
    UINT32 ulCurPhaseVal = 0;
    ulCurPhaseVal = _BspGpsGetPhaseCnt();
    return ulCurPhaseVal;

}

/**************************************************************************
 * 函数名称: _BspGetGpsLockFrame(*)
 * 功能描述: GPS鉴相10ms锁存帧号
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: GPS鉴相锁存帧号
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2017年07月18日 周敏10207549      创建
 **************************************************************************/
ULONG _BspGetGpsLockFrame(UINT32 radioMode)
{
    UINT32 ulFrame    = 0;
    ulFrame = _BspGpsGetLockBfn();
    return ulFrame;
}

UINT32 BspGpsSetBfnAdjust(VOID)
{
    _BspGpsSetBfnAdjust();
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspInitPp1sInt(*)
 * 功能描述: pp1s中断挂接程序
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年04月30日 尧小安00109169    创建
 **************************************************************************/
ULONG _BspInitPp1sInt(VOID)
{
    LONG  lFuncVal = BSP_OK;
    unsigned long ulGpsIntVer = 0xFF;

    if(0x5a5a == s_ulPp1sInitFlag)
    {
        /*计数不为0，说明中断已经挂接过，不需要重新挂接*/
        dbgInfo("pp1s Isr is init ok!\n");
        return BSP_OK;
    }
    _BspDisablePp1sInt();

    getGpsIntVer(&ulGpsIntVer);

    lFuncVal = intConnect((VOIDFUNCPTR *)ulGpsIntVer, (VOIDFUNCPTR)BspPp1sIsr, (int)NULL);
    dbgInfo("%s>> lFuncVal=0x%lx.\n",__FUNCTION__,lFuncVal);
    if(BSP_OK == lFuncVal)
    {
        s_ulPp1sInitFlag = 0x5a5a;
    }
    if(NULL != pGpsIntModeCfgCallBack)
    {
        pGpsIntModeCfgCallBack();
    }

    _BspClrPp1sInt();

    _BspEnablePp1sInt();

    return BSP_OK;
}
/******************************************************************************
 * 函数名称: (*)
 * 功能描述: GPS UART串口相关
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * ---------------------------------------------------------------------------
 * 修改日期         修改人    修改内容
 * 2015年05月29日   罗焕发    创建
 * ---------------------------------------------------------------------------
 */
ULONG _BspGpsUartRecv(UCHAR *pucRecvBuf, ULONG ulLen)
{
    #if 0
    INPUT_POINTER_CHECK(g_GpsInfo.Recv);
    return g_GpsInfo.Recv(pucRecvBuf,ulLen);
    #else
    return BspGpsRecv(pucRecvBuf, ulLen);
    #endif
}

ULONG _BspGpsUartSend(UCHAR *pucSendBuf,  ULONG  ulLen)
{
    #if 0
    INPUT_POINTER_CHECK(g_GpsInfo.Send);
    return g_GpsInfo.Send(pucSendBuf,ulLen);
    #else
    return BspGpsSend(pucSendBuf, ulLen);
    #endif
}

ULONG ReceiveDataFromFpgaSimUart()
{
    ULONG  ValidByte;
    ULONG  ulLoop;
    UCHAR  aucTmp[1500];
    ULONG  ulTime1, ulTime2;

#ifdef FPGA_SIM_UART
    BspSetFpgaReg(0x0f00028E, 4);
    BspSetFpgaReg(0x0f0002AE, 1);
    BspSetFpgaReg(0x0f0002AE, 0);
#endif

    while (1)
    {
        /* 没有配置时空转 */
        if (NULL == g_IntRcvDrvData || g_IntRcvDrvData->ulRefConfigFlag == 0)
        {
            sleep(1);
            continue;
        }

        ulTime1 = tickGet();
        #if 0
        ValidByte = _BspGpsUartRecv(aucTmp, 1500);
        #else
        ValidByte = BspGpsRecv(aucTmp, 1500);
        #endif
        if(ValidByte > 1500)
        {
            /* 返回值错误，应该需要判断为是错误码或者为异常场景 */
            ValidByte = 0;
        }
        GPS_LOG(GPS_DBG_DATA_PRN, "Rx Len: %d\n", ValidByte);

        for (ulLoop = 0; (ulLoop < ValidByte) ; ulLoop++)
        {
            g_tGcmUartPhyBuf.aucBuf[g_tGcmUartPhyBuf.ulTail] = (UCHAR)aucTmp[ulLoop];
            g_tGcmUartIdPhyBuf.aucBuf[g_tGcmUartIdPhyBuf.ulTail] = (UCHAR)aucTmp[ulLoop];
            g_tGcmUartPhyBuf.ulTail++;
            g_tGcmUartPhyBuf.ulTail = (g_tGcmUartPhyBuf.ulTail) % FPGA_UART_QUEUE_SIZE;
            g_tGcmUartPhyBuf.ulRcvMsgOkFlag = 1;
            g_tGcmUartIdPhyBuf.ulTail++;
            g_tGcmUartIdPhyBuf.ulRcvMsgOkFlag = 1;
            g_tGcmUartIdPhyBuf.ulTail = (g_tGcmUartIdPhyBuf.ulTail) % FPGA_UART_QUEUE_SIZE;
            /* 设置电文接收标志为0 */
            g_bIntRcvMsgOn = 0;
            GPS_LOG(GPS_DBG_DATA_PRN, "%02x ", aucTmp[ulLoop]);
            GPS_LOG(GPS_DBG_DATA_PRN, "%s", ((ulLoop+1)%16)?"":"\n");
        }
        GPS_LOG(GPS_DBG_DATA_PRN, "\n");

        ulTime2 = tickGet();
        GPS_LOG(GPS_DBG_DATA_PRN, "ReceiveDataFromFpgaSimUart use %d*10ms\n", (ulTime2-ulTime1));

        taskDelay(sysClkRateGet() / 20); /* 0.05s */

        /* 检测GPS是否长时间未收到数据，由此判断GPS通信是否正常 */
        if(0 == ValidByte)
        {
            if(ulLostCnt < 100)   /* 对应5s+ */
            {
                ulLostCnt++;
            }
        }
        else
        {
            ulLostCnt = 0;
        }

    }
}

ULONG SendDataToFpgaSimUart(ULONG ulByteNum, UCHAR *pucData)
{
    /* ULONG   ulLoop = 0; */
    /* USHORT  usTxData = 0; */

    return BSP_ERROR;

}

#if 0
ULONG GpsUartOutput(ULONG ulLen, UCHAR *pucBuf)
{
    /* Gsp遗留问题: 这个只是FPGA模拟的接口  */
#ifdef FPGA_SIM_UART
    SendDataToFpgaSimUart(ulLen, pucBuf);
#else
    _BspGpsUartSend(pucBuf, ulLen);
#endif
    return BSP_OK;
}
#else
UINT32 GpsUartOutput(UINT32 ulLen, UINT8 *pucBuf)
{
    BspGpsSend(pucBuf, ulLen);
    return BSP_OK;
}
#endif

static ULONG _GpsFrameHostToNet(T_RRU_GNSS_FRAME *ptFrame)
{
    T_TodInfoTime *ptTodTime = &ptFrame->tTimeFrame.tTimeInfo;
    T_TodInfoState *ptTodState = &ptFrame->tStasFrame.tStateInfo;
    ptTodTime->ulGpsTow    = htonl(ptTodTime->ulGpsTow);
    ptTodTime->ulReserved1 = htonl(ptTodTime->ulReserved1);
    ptTodTime->usMsgLength = htons(ptTodTime->usMsgLength);
    ptTodTime->usGpsWeek   = htons(ptTodTime->usGpsWeek);
    /* 需要重新进行校验 */
    ptTodTime->ucMsgCRC = ClockCalcCRCChecksum((UCHAR *) & (ptTodTime->ucMsgHeadClass), 20);
    ptTodState->ulFrameNum2   = htonl(ptTodState->ulFrameNum2);
    ptTodState->ulPp1sOffset  = htonl(ptTodState->ulPp1sOffset);
    ptTodState->usClkSrcAlarm = htons(ptTodState->usClkSrcAlarm);
    ptTodState->usClkSrcState = htons(ptTodState->usClkSrcState);
    ptTodState->usMsgLength   = htons(ptTodState->usMsgLength);
    /* 需要重新进行校验 */
    ptTodState->ucMsgCRC = ClockCalcCRCChecksum((UCHAR *) & (ptTodState->ucMsgHeadClass), 20);
    ptFrame->usRev = htons(ptFrame->usRev);
    return BSP_OK;
}

UINT32 BspIncGnssSendCount(UINT32 radioMode)
{
    /* UINT32 loop; */
    T_GnssParaInfo *pInfo = BspGetGnssParaInfo(radioMode);
    if (pInfo == NULL)
    {
        return BSP_ERROR;
    }
    pInfo->sendCnt++;
    return pInfo->sendCnt;
}

VOID Send1PpsTodFrame()
{
    T_RRU_GNSS_FRAME tRruGnssFrame = {0};
    T_GnssParaInfo *pInfo = NULL;
    UINT32 loop;
    char  data[GNSS_LOG_LINE_SIZE] = {0};

    BspUpdateGnssRadioMode();
    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        pInfo = &s_gnssParaInfo[loop];
        GNSS_CFG_VALID_CHK_CON(pInfo->valid);

        /* 封装报文 */
        if (BSP_OK != BspUniCasdSend1PpsTodFrame(pInfo->radioMode,&tRruGnssFrame))
        {
            GPS_LOG(GPS_DBG_INIT_PRN, "BspUniCasdSend1PpsTodFrame: return error.\n");
        }
        else
        {
        }
        if ((tRruGnssFrame.usRev %10) == 0)
        {
            if (g_IntRcvDrvData != NULL)
            {
                tgnsssndInfo.rcvTodOkCnt = g_IntRcvDrvData->ulRcvTodOkCnt;
                tgnsssndInfo.rcvMsgSta   = g_IntRcvDrvData->ulRcvMsgStas;
                tgnsssndInfo.initSta     = g_IntRcvDrvData->ucRcvInitStep;
            }
            memcpy_s(&data[0], sizeof(T_GnssSndInfo), &tgnsssndInfo, sizeof(T_GnssSndInfo));
            memcpy_s(&data[0]+sizeof(T_GnssSndInfo), GNSS_LOG_LINE_SIZE-sizeof(T_GnssSndInfo), &tRruGnssFrame, sizeof(T_RRU_GNSS_FRAME));
            BspAddGnssLog(GNSS_LOG_TYPE_SNDMSG,data,sizeof(T_GnssSndInfo)+sizeof(T_RRU_GNSS_FRAME));
        }
        if (pInfo->pSendToBbu)
        {
            tRruGnssFrame.usRev = BspIncGnssSendCount(pInfo->radioMode);
            /* 转化成网络字节序传输 */
            _GpsFrameHostToNet(&tRruGnssFrame);
            /* 发送报文 */
            pInfo->pSendToBbu(&tRruGnssFrame, sizeof(T_RRU_GNSS_FRAME));
        }

    }

    return;
}

ULONG BspCommonClkRtCtrlTaskEntry(VOID)
{
    /* T_RRU_GNSS_FRAME tRruGnssFrame = {0}; */

    while (1)
    {
        /* 默认阻塞 */
        /* 阻塞时若被信号打断，待信号处理过程结束后重新执行阻塞操作*/
        semTake(g_GpsIntSem, WAIT_FOREVER);

        /* 没有配置时直接退出 */
        if (g_IntRcvDrvData->ulRefConfigFlag == 0)
        {
            //BspGnssTaskQuit();
            //return BSP_OK;
            sleep(1);
            continue;
        }

        usleep(1000 * 15);

        /* 内置接收机电文接收监控 */
     /* 和8854 方案保持一致，连续4秒未收到UART数据，判断串口异常 @2018.4.5*/
        if (g_bIntRcvMsgOn > 3)
        {
            g_ucIntGpsUartErr = 1;
        }
        else
        {
            g_ucIntGpsUartErr = 0;
            g_bIntRcvMsgOn++; /* 次次清除标志 */
        }

        /* 制造UART通讯异常 */
        if(GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(RCV_COMMUN_FAIL))
        {
            g_ucIntGpsUartErr = 1;
        }

        if(NULL == g_RcvDrvData)
        {
            GPS_LOG(GPS_DBG_INIT_PRN, "g_RcvDrvData is NULL\n");
            continue;
        }

        /* 源Sat可用时，将该tod同步给框架 */
        if((gtSatLocalTod.YEAR == g_RcvDrvData->tGpsDate.YEAR)
         &&(gtSatLocalTod.DAYS == g_RcvDrvData->tGpsDate.DAYS)
         &&(gtSatLocalTod.HOUR == g_RcvDrvData->tGpsDate.HOUR)
         &&(gtSatLocalTod.MIN  == g_RcvDrvData->tGpsDate.MIN)
         &&(gtSatLocalTod.SEC  == g_RcvDrvData->tGpsDate.SEC))
        {
            sulSatTodTAsyncTimes = 0;
            sulSyncRcvTodFlag = 1;
            /*SAT_CTRL_LOG(" gps Tod equal to Local Tod, tick = %d !\n",tickGet(),2,3,4,5,6);*/
        }
        else
        {
            /* 驱动tod可用 */
            if ((1 == g_RcvDrvData->ulRcvTodOkFlag)
                && (1 == g_RcvDrvData->ulRcvMsgStas))
            {
                sulSatTodTAsyncTimes++;

                /* 连续10次框架维护的tod与接收机tod不一致时 */
                if (10 < sulSatTodTAsyncTimes)
                {
                    /* 计数变量清零 */
                    sulSatTodTAsyncTimes = 0;
                    gulSatSyncTodToLocalTimes++;
                    GPS_LOG(GPS_DBG_INIT_PRN, " Sync gps Tod to Local, tick = %d !\n", tickGet());
                    GPS_LOG(GPS_DBG_INIT_PRN, "TOD: %d-%d-%d | %d:%d:%d. (SatRcv time)\n",
                        g_RcvDrvData->tGpsDate.YEAR, g_RcvDrvData->tGpsDate.MON,
                        g_RcvDrvData->tGpsDate.DAY, g_RcvDrvData->tGpsDate.HOUR,
                        g_RcvDrvData->tGpsDate.MIN, g_RcvDrvData->tGpsDate.SEC);
                    GPS_LOG(GPS_DBG_INIT_PRN, "TOD: %d-%d-%d | %d:%d:%d. (Satlocal time)\n",
                        gtSatLocalTod.YEAR, gtSatLocalTod.MON, gtSatLocalTod.DAY,
                        gtSatLocalTod.HOUR, gtSatLocalTod.MIN, gtSatLocalTod.SEC);
                    /* 同步驱动tod到框架维护tod */
                    memcpy(&gtSatLocalTod, &(g_RcvDrvData->tGpsDate), sizeof(g_RcvDrvData->tGpsDate));
                    /* 曾经同步驱动tod到框架维护tod标志,同时也是上报给上层tod是否可用的标志，0：不可用，1：可用 */
                    sulSyncRcvTodFlag = 1;
                }
                else
                {
                    sulSyncRcvTodFlag = 0;
                    GPS_LOG(GPS_DBG_INIT_PRN, " sat tod ok and not equal to local tod times = %d !\n", sulSatTodTAsyncTimes);
                }
            }
            else
            {
                sulSyncRcvTodFlag = 0;
            }
        }

        ClockChangeDaysToMonDay(&gtSatLocalTod);

        if (0 == sulSyncRcvTodFlag)
        {
            g_bTodAsync = TRUE; /* 框架维护tod不可用 */
            GPS_LOG(GPS_DBG_INIT_PRN, "ERR not equal: SatLocalTod.SEC = %d, RcvTod.SEC = %d !\n",
                gtSatLocalTod.SEC, g_RcvDrvData->tGpsDate.SEC);
        }
        else
        {
            g_bTodAsync = FALSE; /* 框架维护tod可用 */
        }

        {
            /* 清除电文接收正常标志 */
            g_IntRcvDrvData->ulRcvMsgStas = 0;/* 使用完之后，每次将时间接收OK标志清除 */
        }
        GPS_LOG(GPS_DBG_INIT_PRN, "TOD: %d-%d-%d | %d:%d:%d. (SatRcv time)\n",
            g_RcvDrvData->tGpsDate.YEAR, g_RcvDrvData->tGpsDate.MON,
            g_RcvDrvData->tGpsDate.DAY, g_RcvDrvData->tGpsDate.HOUR,
            g_RcvDrvData->tGpsDate.MIN, g_RcvDrvData->tGpsDate.SEC);
        GPS_LOG(GPS_DBG_INIT_PRN, "TOD: %d-%d-%d | %d:%d:%d. (Satlocal time)\n",
            gtSatLocalTod.YEAR, gtSatLocalTod.MON, gtSatLocalTod.DAY,
            gtSatLocalTod.HOUR, gtSatLocalTod.MIN, gtSatLocalTod.SEC);
    /* TOD回传*/
        Send1PpsTodFrame();
        memcpy_s(&tgnsssndInfo.tod[0], sizeof(T_Clock_Tod), &gtSatLocalTod,sizeof(T_Clock_Tod));
        memcpy_s(&tgnsssndInfo.tod[1], sizeof(T_Clock_Tod), &g_RcvDrvData->tGpsDate,sizeof(T_Clock_Tod));
        g_ulClkRunCnt++;
    }
}

UINT32 _BspGpsClrPp1sInt(VOID)
{
    //清pp1s中断
    IcHalWrReg(0,OPT_CPRI_GPS_PP1S_INT_CLR,0,0x1);/* wric(0xc2400808,0x1) */
    IcHalWrReg(0,OPT_CPRI_GPS_PP1S_INT_CLR,0,0x0);/* wric(0xc2400808,0x0) */
    return BSP_OK;
}

UINT32 _BspGpsDisablePp1sInt(VOID)
{
    IcHalWrReg(0,OPT_CPRI_GPS_PP1S_INT_EN,0,0x0);/* wric(0xc2400804,0x0) */
    return BSP_OK;
}

UINT32 _BspGpsEnablePp1sInt(VOID)
{
    IcHalWrReg(0,OPT_CPRI_GPS_PP1S_INT_EN,0,0x1);/* wric(0xc2400804,0x1) */
    return BSP_OK;
}

/* 获取pp1s丢失状态  */
UINT32 _BspGpsGetPp1sLostStatus(VOID)
{
    UINT32 ulRet = 0;
    UINT32 ulData = 0;
    UINT32 ulTemp = 0;
    ulTemp = IcHalRdReg(0, OPT_CPRI_GPS_PP1S_INT, 0x10, &ulData); /* 0xc2400810 */
    if (BSP_ERROR != ulTemp)
    {
        ulRet = ulData;
    }
    return ulRet;
}

/* 获取GPS鉴相值 */
UINT32 _BspGpsGetPhaseCnt(VOID)
{
    UINT32 ulData = 0;
    UINT32 ulTemp = 0;
    UINT32 ulSampleRateHz = 737280000;
    UINT32 ulCurPhaseVal = 0;
    DOUBLE dNanosecond = 0.0;
    UINT32 ulTempSta = 0;
    UINT32 ulDataSta = 0;
    UINT32 ulTempBfn = 0;
    UINT32 ulDataBfn = 0;
    ulTemp = IcHalBitRdReg(0,OPT_CPRI_GPS_PP1S_INT,0x1C,&ulData,0,31);   /* 0xc240081c */
    //coverity[cert_exp37_c_violation:SUPPRESS]
    ulTempSta = IcHalBitRdReg(0,OPT_CPRI_GPS_PP1S_INT,0x28,&ulDataSta,0,1);
    //coverity[cert_exp37_c_violation:SUPPRESS]
    ulTempBfn = IcHalBitRdReg(0,OPT_CPRI_GPS_PP1S_INT,0x30,&ulDataBfn,0,12);


    if ((BSP_OK == ulTemp) && (BSP_OK == ulTempSta) && (BSP_OK == ulTempBfn) && (0 == ulDataSta))
    {
        /* change unit to nano-second, 如:clk单位是1/368.64M  约2.71267ns */
        dNanosecond = (1000000000.0/(DOUBLE)ulSampleRateHz);
        //coverity[cert_flp34_c_violation:SUPPRESS]
        ulCurPhaseVal = (UINT32)(ulData * dNanosecond);
        //ulRet = ulCurPhaseVal%100000000
        dbgInfoEx("pha[OK]:%d,bfn:0x%x\n",ulCurPhaseVal,ulDataBfn);
    }
    else
    {
        ulCurPhaseVal = 0xFFFFFFFF;
        gnssPhaseErr++;
        if(0 == (gnssPhaseErr % 10))
        {
            dbgInfo("pha[ERR]:0x%x,bfn:0x%x,rdsta:0x%x,0x%x,0x%x; phasta:%d,phaerr:%d\n",ulCurPhaseVal,ulDataBfn,ulTemp,ulTempSta, ulTempBfn,ulDataSta,gnssPhaseErr);
        }
    }

    return ulCurPhaseVal;
}

/* bfn帧号 */
VOID _BspGpsSetBfnAdjust(VOID)
{
    UINT32 pval = 0;
    UINT32 mainopt = BspGetCurrFiberPort();
    pval = IcHalApiCpriGetPPoint(mainopt);
    if (pval<53)
    {
        IcHalWrReg(0,OPT_CPRI_GPS_PP1S_INT,0x30,0xfff);//使用光口恢复帧号-1    /* 0xc2400830 */
    }
    else
    {
        IcHalWrReg(0,OPT_CPRI_GPS_PP1S_INT,0x30,0x0);//直接使用光口恢复帧号
    }
    return;
}

/* 获取GPS鉴相无线帧号 */
UINT32 _BspGpsGetLockBfn(VOID)
{
    UINT32 ulRet = 0;
    UINT32 ulData = 0;
    UINT32 ulTemp = 0;
    ulTemp = IcHalBitRdReg(0,OPT_CPRI_GPS_PP1S_INT,0x24,&ulData,0,15);  /* 0xc2400824 */
    if (BSP_ERROR != ulTemp)
    {
        ulRet = ulData;
    }
    return ulRet;
}

/**********************************************************************
* 函数名称： getGpsIntVer
* 功能描述： 获取GPS使用的中断向量号。
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
* 修改日期        版本号     修改人          修改内容
* -----------------------------------------------
* 2017/08           V1.0         AAU
***********************************************************************/
UINT32 getGpsIntVer(unsigned long *pulIntVer)
{
    INPUT_POINTER_CHECK(pulIntVer);

    *pulIntVer = (unsigned long)BSP_RPGS_INT_VER;

    dbgInfo("%s>>IntVer= %ld\n", __FUNCTION__, *pulIntVer);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspEnablePp1sInt(*)
 * 功能描述: 使能pp1s中断
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年04月30日 尧小安00109169    创建
 **************************************************************************/
UINT32 _BspEnablePp1sInt(VOID)
{
    _BspGpsEnablePp1sInt();
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspClrPp1sInt(*)
 * 功能描述: 清除中断
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明: 中断放在内核清除,用户态不实现
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年05月25日 尧小安00109169    创建
 **************************************************************************/
UINT32 _BspClrPp1sInt(VOID)
{
    _BspGpsClrPp1sInt();
    return BSP_OK;
}


VOID SyncRcvTodToSatTod(VOID)
{
    /* 源Sat可用时，将该tod同步给框架 */
    if ((gtSatLocalTod.YEAR == g_RcvDrvData->tGpsDate.YEAR)
        && (gtSatLocalTod.DAYS == g_RcvDrvData->tGpsDate.DAYS)
        && (gtSatLocalTod.HOUR == g_RcvDrvData->tGpsDate.HOUR)
        && (gtSatLocalTod.MIN  == g_RcvDrvData->tGpsDate.MIN)
        && (gtSatLocalTod.SEC  == g_RcvDrvData->tGpsDate.SEC))
    {
        sulSatTodTAsyncTimes = 0;
        sulSyncRcvTodFlag = 1;
    }
    else
    {
        _SyncRcvTodToSatTod();
    }

    ClockChangeDaysToMonDay(&gtSatLocalTod);

    if (0 == sulSyncRcvTodFlag)
    {
        g_bTodAsync = TRUE; /* 框架维护tod不可用 */
    }
    else
    {
        g_bTodAsync = FALSE; /* 框架维护tod可用 */
    }
    /* 清除电文接收正常标志 */
    g_IntRcvDrvData->ulRcvMsgStas = 0;/* 使用完之后，每次将时间接收OK标志清除 */
    return;
}

/******************************************************************************
 * 函数名称: BspPp1sIsr(*)
 * 功能描述: 中断服务程序
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * ---------------------------------------------------------------------------
 * 修改日期         修改人    修改内容
 * 2015年05月29日   罗焕发    创建
 * ---------------------------------------------------------------------------
 */
VOID BspPp1sIsr(VOID)
{
    s_ulPp1sIsrCnt++;
    tgnsssndInfo.pp1sIntCnt = s_ulPp1sIsrCnt;
    _BspClrPp1sInt();

    if(NULL == g_IntRcvDrvData)
    {
        /*解决有aas,没有配置rgps异常复位问题*/
        return;
    }
    /* 没有RGPS配置时直接退出 */
    if (g_IntRcvDrvData->ulRefConfigFlag == 0)
    {
        return ;
    }

    /* 实时控制定时器时标清0 */
    g_ulProtectTimes = 0;

    /* 设置RT与PP1S同步上的标志 */
    ClockIncrementTime(&gtSatLocalTod);
    //SyncRcvTodToSatTod();
    semGive(g_GpsIntSem);

    s_ulPp1sIsrOkCnt++;

    return;

}

ULONG BspGetGpsIsrCnt(VOID)
{
    return s_ulPp1sIsrCnt;
}

/**************************************************************************
* 函数名称： BspUniCasdSend1PpsTodFrame
* 功能描述： 根据后台配置构造1pps+tod帧并写入逻辑函数
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK            成功
*            BSP_ERROR         失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-8-30    V1.0         jiaran         创建
**************************************************************************/
UINT32 BspUniCasdSend1PpsTodFrame(UINT32 radioMode,T_RRU_GNSS_FRAME *ptRruGnssFrame)
{
    UINT32 ulRetVal = BSP_OK;
    T_TodFrameHead tFrameHead = {0};
    T_RRU_GNSS_FRAME tLocaFrame = {0};

    /* part1 构造要发送的帧 */
    /* 根据后台增加消息帧头 */
    switch (BspUniCasdFrameModeGet())
    {
        case CHINA_MOBILE:
        {
            tFrameHead.ucFrameSyncChar1 = 0x43;/* "C" */
            tFrameHead.ucFrameSyncChar2 = 0x4D;/* "M" */
            break;
        }
        case CHINA_TELECOM:
        {
            tFrameHead.ucFrameSyncChar1 = 0x43;/* "C" */
            tFrameHead.ucFrameSyncChar2 = 0x54;/* "T" */
            break;
        }
        case DEFAULT_UNICOM:
        {
            tFrameHead.ucFrameSyncChar1 = 0x43;/* "C" */
            tFrameHead.ucFrameSyncChar2 = 0x4E;/* "N" */
            break;
        }
        default:
        {
            tLocaFrame.tTimeFrame.tFrameHead.ucFrameSyncChar1 = 0x43;/* "C" */
            tLocaFrame.tTimeFrame.tFrameHead.ucFrameSyncChar2 = 0x4D;/* "M" */
            ulRetVal = BSP_ERROR;
            break;
        }
    }

    /* 填写消息帧实体 */
    if (BSP_OK != BspUniCasdCreatTimeInfo(radioMode,&(tLocaFrame.tTimeFrame.tTimeInfo)))
    {
        ulRetVal = BSP_ERROR;
        GPS_LOG(GPS_DBG_INIT_PRN, "BspUniCasdCreatTimeInfo: return error!\n");
    }
    else
    {
        /* master tod可用时开始发送帧信息 */
       /* if(1 == tLocaFrame.tTimeFrame.tTimeInfo.ulReserved1)*/
        {
            /* 填写消息帧头 */
            memmove(&(tLocaFrame.tTimeFrame.tFrameHead), &tFrameHead, sizeof(T_TodFrameHead));
        }
    }

    /* master tod可用时开始发送帧状态 */
  /*  if(1 == tLocaFrame.tTimeFrame.tTimeInfo.ulReserved1)*/
    {
        if (BSP_OK != BspUniCasdCreatStateInfo(radioMode,&(tLocaFrame.tStasFrame.tStateInfo)))
        {
            ulRetVal = BSP_ERROR;
            GPS_LOG(GPS_DBG_INIT_PRN, "BspUniCasdCreatStateInfo: return error!\n");
        }
        else
        {
            /* 填写状态帧头 */
            memmove(&(tLocaFrame.tStasFrame.tFrameHead), &tFrameHead, sizeof(T_TodFrameHead));
        }
    }
    g_usRruSndCnt++;
    tLocaFrame.usRev = g_usRruSndCnt;
  /*  if (BspGetSatLocalTodStas() == FALSE)*/
    {
        memmove(ptRruGnssFrame, &tLocaFrame, sizeof(T_RRU_GNSS_FRAME));
        memmove(&g_tRruGnssFrame, &tLocaFrame, sizeof(T_RRU_GNSS_FRAME));
    }
    /*   else
       {
           memset(ptRruGnssFrame, 0xAA, sizeof(T_RRU_GNSS_FRAME));
           memset(&g_tRruGnssFrame, 0xAA, sizeof(T_RRU_GNSS_FRAME));
       }*/
    return ulRetVal;
}

ULONG BspGetSatLockeedSatCnt(void)
{
    UINT32 ulLockedSatCnt = 0;


    ulLockedSatCnt = g_RcvDrvData->ulLockedSatCnt[GPS_SAT_TYPE] + g_RcvDrvData->ulLockedSatCnt[GLONSS_SAT_TYPE] + g_RcvDrvData->ulLockedSatCnt[BEIDOU_SAT_TYPE];

    return ulLockedSatCnt;
}

/**************************************************************************
* 函数名称： BspUniCasdCreatTimeInfo
* 功能描述： 构造1pps+tod消息帧函数
* 输入参数： 无
* 输出参数： tTimeInfo：1pps+tod消息帧
* 返 回 值： BSP_OK            成功
*            BSP_ERROR         失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-8-30    V1.0         jiaran         创建
**************************************************************************/
ULONG BspUniCasdCreatTimeInfo(UINT32 radioMode, T_TodInfoTime *ptTimeInfo)
{
    ULONG ulRetVal = BSP_OK;
    T_Clock_Tod tTempLocalTod;
    USHORT usGpsWeek = 0;
    ULONG  ulGpsTow = 0;
    char   cLeaps = 0;
    UCHAR  ucPpsStatus = 0;

    /* 入参检测 */
    if(NULL == ptTimeInfo)
    {
        GPS_LOG(GPS_DBG_INIT_PRN, "BspUniCasdCreatTimeInfo: pointer null!\n");
        return BSP_ERROR_NULL_POINTER;
    }
    /* 清除上一次状态 */
    gulTodAsyncFlag = 0;
    ptTimeInfo->ucMsgHeadClass = 0x01;   /* 消息头的Class字段，0x01 */
    ptTimeInfo->ucMsgHeadId = 0x20;      /* 消息头的Id字段，0x20 */
    ptTimeInfo->usMsgLength = 16;        /* 消息长度，16 */


    /* tod数值 */
    if(BSP_OK != BspGetGpsTime(&tTempLocalTod))
    {
        GPS_LOG(GPS_DBG_INIT_PRN, "BspGetGpsTime return not ok!\n");
    }

    /* 闰秒和pp1s状态 */
    if(BSP_OK != BspGetSatLeapsPpsStas(radioMode, &cLeaps,&ucPpsStatus))
    {
        GPS_LOG(GPS_DBG_INIT_PRN, "BspGetSatLeaps return not ok!\n");
    }
    else
    {
        GPS_LOG(GPS_DBG_INIT_PRN, "PpsStas(Sat) = %d,Sat Leaps = %d,tick = %d!\n",
            ucPpsStatus, cLeaps , tickGet());
    }

    /* tod是否可用状态 */
    if(FALSE == BspGetSatLocalTodStas())
    {
        gulTodAsyncFlag = 1;
        GPS_LOG(GPS_DBG_INIT_PRN, "Ref Clk(Sat) TOD is available,tick = %d\n", tickGet());
    }
    else
    {
        gulTodAsyncFlag = 0;
        GPS_LOG(GPS_DBG_INIT_PRN, "Ref Clk(Sat) TOD is not available,tick = %d\n", tickGet());
    }

    /* 转换成week数+week内秒数格式 */
    if(BSP_OK != BspUniCasdSdTod2GpsTod(tTempLocalTod,&usGpsWeek,&ulGpsTow))
    {
        GPS_LOG(GPS_DBG_INIT_PRN, "BspUniCasdSdTod2GpsTod return error!\n");
    }

    ptTimeInfo->ulGpsTow = ulGpsTow;              /* gps时间周内秒数 */
    ptTimeInfo->ulReserved1 |= gulTodAsyncFlag;     /* 将tod是否可用信息赋值给该保留字段bit0 */
    ptTimeInfo->usGpsWeek = usGpsWeek;            /* gps时间周数 */
    ptTimeInfo->cLeapS = cLeaps;                  /* gps时与utc时偏移量 */
    ptTimeInfo->ucPpsStatus = ucPpsStatus;        /* 秒脉冲状态，0x00 =正常
                                                    0x01 =时间同步设备（原子钟）保持
                                                    0x02 =不可用
                                                    0x03 =时间同步设备（高稳晶振）保持
                                                    0x04 =传输承载设备保持 */

    ptTimeInfo->ucTacc = BspGetPp1sOffsetType(radioMode);           /* pps抖动量级，写死为0xff */
    /* Gps遗留问题: 上层配置下来的GNSS ID号 */
    ptTimeInfo->ucGnssId = g_RcvDrvData->ucGnssId;
    /* Gps遗留问题: 上层配置下来的GNSS ID号对应的机架号 */
    ptTimeInfo->ucRackNo = g_RcvDrvData->ucRackNo;
    /* 锁定卫星数，从驱动电文中获取 */
    ptTimeInfo->ucLockSatCnt = BspGetSatLockeedSatCnt();
    /* 不包括帧头字段的crc校验 */
    ptTimeInfo->ucMsgCRC = ClockCalcCRCChecksum((UCHAR *)&(ptTimeInfo->ucMsgHeadClass), 20);

    /* 异常时，设置TOD不可用状态,恢复按照正常流程 */
    if(GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(FAKE_GPS_TOD_ERR))
    {
        ptTimeInfo->ulReserved1 = 0; /* TOD不可用 */
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称： BspUniCasdSdTod2GpsTod
* 功能描述： 构造1pps+tod状态帧函数
* 输入参数： 无
* 输出参数： ptStateInfo：1pps+tod状态帧
* 返 回 值： BSP_OK            成功
*            BSP_ERROR         失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-8-30    V1.0         jiaran         创建
**************************************************************************/
UINT32 BspUniCasdCreatStateInfo(UINT32 radioMode,T_TodInfoState *ptStateInfo)
{
    UINT32 ulRetVal = BSP_OK;
    T_GNSS_PARA_CFG *pCfg = BspGetGnssCfgPara(radioMode);

    /* 入参检测 */
    if (NULL == ptStateInfo)
    {
        GPS_LOG(GPS_DBG_INIT_PRN, "BspUniCasdCreatStateInfo: pointer null!\n");
        return BSP_ERROR_NULL_POINTER;
    }

    ptStateInfo->ucMsgHeadClass = 0x01;   /* 消息头的Class字段，0x01 */
    ptStateInfo->ucMsgHeadId = 0x03;      /* 消息头的Id字段，0x20 */
    ptStateInfo->usMsgLength = 16;        /* 消息长度，16 */
    /* 参考类型是gps */
    ptStateInfo->ucClkSrcType = 0x01;
    ptStateInfo->usClkSrcState = g_RcvDrvData->ulRcvFixStatus;
    ptStateInfo->usClkSrcAlarm = BspGetSatClkAlarm();
    /*  Gps遗留问题: 上层配置下来的GNSS ID号 */
    ptStateInfo->ucGnssId     = pCfg ? pCfg->ucGnssId : g_RcvDrvData->ucGnssId;
    ptStateInfo->ucFrameMode  = BspGetGpsFrameMode(radioMode);
    ptStateInfo->ucFrameNum1  = 0;/* ucFrameNum1 */
    ptStateInfo->ulFrameNum2  = _BspGetGpsLockFrame(radioMode) + 4096;
    ptStateInfo->ulPp1sOffset = _BspGetPp1sOffset(radioMode) + BspGetGpsFrOffset();
    if (NULL != pGpsGetSel8tFunc)
    {
        /* 后续支持10ms鉴相使用 */
        if(ptStateInfo->ulPp1sOffset > 10000000)
        {
            ptStateInfo->ulFrameNum2  -= 1;
            ptStateInfo->ulPp1sOffset -= 10000000;
        }
    }
    else
    {
        if (((BSP_RADIO_STANDARD_LTE_TDD == radioMode)||(BSP_RADIO_STANDARD_LTE_FDD == radioMode)) && BspGetPp1sOffsetType(radioMode) == PP1S_OFFSET_TYPE_10MS)
        {
            /* 后续支持10ms鉴相使用 */
            if(ptStateInfo->ulPp1sOffset > 10000000)
            {
                ptStateInfo->ulFrameNum2  -= 1;
                ptStateInfo->ulPp1sOffset -= 10000000;
            }
        }
    }

    ptStateInfo->ulFrameNum2 %= 4096;/* ulFrameNum2 */
    /* 更新结构体数据 */
    g_RcvDrvData->ulPhaseValue = ptStateInfo->ulPp1sOffset;
    g_RcvDrvData->ullFrameNo = ((UINT64)(ptStateInfo->ucFrameNum1) << 32) + ptStateInfo->ulFrameNum2;
    GPS_LOG(GPS_DBG_INIT_PRN, "Frame No:%d\t g_RcvDrvData->ullFrameNo = %lld\n",
        ptStateInfo->ulFrameNum2, g_RcvDrvData->ullFrameNo);
    /* 不包括帧头字段的crc校验 */
    ptStateInfo->ucMsgCRC = ClockCalcCRCChecksum((UINT8 *) & (ptStateInfo->ucMsgHeadClass), 20);
    return ulRetVal;
}

/**************************************************************************
* 函数名称： ULONG BspGetGpsTime(T_Clock_Tod *ptGpsTime)
* 功能描述： 获取GPS时间(卫星类模块本地维护时间)
* 输入参数：
* 输出参数： ptGpsTime: GPS时间
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2008/08/12  V1.0       刘骏儒         创建
**************************************************************************/
ULONG BspGetGpsTime(T_Clock_Tod *ptGpsTime)
{
    if (NULL == ptGpsTime)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    memcpy(ptGpsTime, &gtSatLocalTod, sizeof(gtSatLocalTod));

    return BSP_OK;
}
/**************************************************************************
* 函数名称： ULONG BspGetSatLeaps(char *pcLeaps)
* 功能描述： 获取卫星类模块闰秒\pp1s状态信息
* 输入参数：
* 输出参数： pcLeaps：闰秒，pucPpsStatus：接收机综合状态信息
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-8-30   V1.0       jiaran         创建
**************************************************************************/
BOOL BspGetSatLocalTodStas(void)
{
    return g_bTodAsync;
}
/**************************************************************************
* 函数名称： BspUniCasdSdTod2GpsTod
* 功能描述： 将标准gps时间(年月日格式)装换成week数+week内秒数函数
* 输入参数： tClkLocalTod：激活参考源本地tod
* 输出参数： pusGpsWeek：gps week数，pulGpsTow：gps时间周内秒数
* 返 回 值： BSP_OK            成功
*            BSP_ERROR         失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-8-30    V1.0         jiaran         创建
**************************************************************************/
ULONG BspUniCasdSdTod2GpsTod(T_Clock_Tod tClkLocalTod,USHORT *pusGpsWeek,ULONG *pulGpsTow)
{
    ULONG ulRetVal = BSP_OK;
    ULONG ulTotalDays = 0;
    ULONG ulDaysInYear = 0;
    ULONG ulTimeInSeconds = 0;
    ULONG k = 0;
    /* 入参检测 */
    if((NULL == pusGpsWeek) || (NULL == pulGpsTow))
    {
        GPS_LOG(GPS_DBG_INIT_PRN, "BspUniCasdSdTod2GpsTod: pointer null!\n");
        return BSP_ERROR_NULL_POINTER;
    }
    /* 计算当前时间距1980年1.1的天数，进而得出s数 */
    ulTotalDays = 0;
    ulTimeInSeconds = 0;
    for(k = 1980; k < tClkLocalTod.YEAR; k++)
    {
        ulDaysInYear = ClockCalcDaysInCertainYear(k);
        ulTotalDays += ulDaysInYear;
    }
    ulTotalDays += tClkLocalTod.DAYS;
    /* 计算当前时间相对于1980年1月1号的秒数 */
    ulTimeInSeconds = (ulTotalDays) * 24 * 3600 + tClkLocalTod.HOUR * 3600 + tClkLocalTod.MIN * 60 + tClkLocalTod.SEC;
    /* 计算当前时间相对于1980年1月6号的秒数 */
    ulTimeInSeconds -= 5 * 24 * 3600;
    ulTimeInSeconds += 1;/* 计算出相对于当前tod的下一秒的tod */
    *pusGpsWeek = ulTimeInSeconds / SECOND_OF_WEEK;
    *pulGpsTow = ulTimeInSeconds % SECOND_OF_WEEK;
    return ulRetVal;

}

/**********************************************************************
* 函数名称：ClockCalcCRCChecksum
* 功能描述：计算校验和
* 访问的表：无
* 修改的表：无
* 输入参数：pucDataIn:被校验数据
            usLength：被校验数据长度
* 输出参数：
* 返 回 值：校验和
* 其它说明： x^8+x^5+x^4+x^0
* 修改日期      版本号   修改人      修改内容
* 2010-8-31      v1.0    jiaran        create
************************************************************************/
UCHAR ClockCalcCRCChecksum(UCHAR *pucDataIn, USHORT usLength)
{
    UCHAR  ucCRC = 0xff;
    UCHAR  ucLoop = 0;
    /* 入参保护 */
    if((0 == usLength) ||(NULL == pucDataIn))
    {
        return 0;
    }
    while(usLength--)
    {
        ucCRC = ucCRC^ (*(pucDataIn++));
        for(ucLoop= 0; ucLoop < 8; ucLoop++)
        {
            if(ucCRC & 0x01)
            {
                ucCRC = (ucCRC >> 1 )^ 0x8c;
            }
            else
            {
                ucCRC >>= 1;
            }
        }
    }
    return ucCRC;
}

/**************************************************************************
* 函数名称： void ClockIncrementTime(T_Clock_Tod *D)
* 功能描述： 本地维护tod信息增加函数
* 输入参数： tod信息
* 输出参数： 更新之后的tod信息
* 返 回 值： 无
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2008-9-16    V1.0         SDR BSP         创建
**************************************************************************/
void ClockIncrementTime(T_Clock_Tod *D)
{
    /* 入参检测 */
    if(NULL == D)
    {
        return;
    }
    if ( (++(*D).SEC) >= 60 )    /* CPU计时 */
    {
        (*D).SEC = 0;
        if ( (++(*D).MIN) >= 60 )
        {
            (*D).MIN = 0;
            if ( (++(*D).HOUR) >= 24 )
            {
                (*D).HOUR = 0;

                if (++(*D).DAYS >= 365)
                {
                    if (ClockLeapYearCheck((*D).YEAR) == FALSE)      /*平年365天*/
                    {
                        (*D).DAYS = 0;
                        (*D).YEAR++;
                    }
                    else
                    {
                        if ((*D).DAYS > 365)      /*润年366天*/
                        {
                            (*D).DAYS = 0;
                            (*D).YEAR++;
                        }
                    }
                }
            }
        }
    }
}

/**************************************************************************
* 函数名称： BspUniCasd1PpsTodStateUsedSet
* 功能描述： 设置1pps+tod帧头等格式模式函数
* 输入参数： ulFrameMode：模式
* 输出参数： 无
* 返 回 值： BSP_OK;
*            BSP_ERROR;
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-8-30    V1.0         jiaran         创建
**************************************************************************/
ULONG BspUniCasdFrameModeSet(ULONG ulFrameMode)
{
    if(DEFAULT_UNICOM < ulFrameMode)
    {
        return BSP_ERROR;
    }
    gul1PpsTodFrameMode = ulFrameMode;
    return BSP_OK;
}
/**************************************************************************
* 函数名称： BspUniCasd1PpsTodStateUsedSet
* 功能描述： 获取1pps+tod帧头等格式模式函数
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 格式模式数值
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号       修改人          修改内容
* 2010-8-30    V1.0         jiaran         创建
**************************************************************************/
ULONG BspUniCasdFrameModeGet(void)
{
    return gul1PpsTodFrameMode;
}

/**************************************************************************
* 函数名称： ULONG BspGetSatLeaps(char *pcLeaps)
* 功能描述： 获取卫星类模块闰秒\pp1s状态信息
* 输入参数：
* 输出参数： pcLeaps：闰秒，pucPpsStatus：接收机综合状态信息
* 返 回 值： BSP_OK:  成功；其他: 失败
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-8-30   V1.0       jiaran         创建
**************************************************************************/
ULONG BspGetSatLeapsPpsStas(UINT32 radioMode, char *pcLeaps,UCHAR *pucPpsStatus)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulRcvUsable = 0;
    UINT32 ulClkStatus = 0;

    if ((NULL == pcLeaps) || (NULL == pucPpsStatus))
    {
        return BSP_ERROR;
    }

    ulRcvUsable = g_RcvDrvData->ulRcvUseableFlag;
    ulClkStatus = BspGetLocalClkStatus(radioMode);
    *pcLeaps = g_RcvDrvData->ucLeapSeconds;

    tgnsssndInfo.ulClkStatus = ulClkStatus;
    if ((CLOCK_REF_USEABLE == ulRcvUsable) && (BSP_OK == ulClkStatus))
    {
        *pucPpsStatus = 0;    /* 可用 */
    }
    else
    {
        *pucPpsStatus = 0x02; /* 不可用 */
    }

    /* 设置秒脉冲不可用,恢复时按照正常流程 */
    if(GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(FAKE_GPS_LEAPS_ERR))
    {
        *pucPpsStatus = 0x02; /* 不可用 */
    }

    return ulRetVal;
}

/**************************************************************************
* 函数名称： UCHAR BspGetSatClkAlarm(void)
* 功能描述： 获取卫星类模块时钟源告警信息
* 输入参数：
* 输出参数： 无
* 返 回 值： 时钟源工作状态，默认无告警
* 其它说明： 每一bit位：0:ok,1:告警
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2010-8-30   V1.0       jiaran         创建
**************************************************************************/
USHORT BspGetSatClkAlarm(void)
{
    UINT32 ulLoop = 0;
    USHORT usClkSrcAlarm = 0;
    UINT32 ulTrackedSatCnt = 0;
    /* 天馈开路 */
    if(GPS_ANTENNA_STATE_BREAK == g_RcvDrvData->ulRcvAntennaStateShow)
    {
        usClkSrcAlarm |= 0x02;
    }
    /* 天馈短路 */
    else if(GPS_ANTENNA_STATE_SHORT == g_RcvDrvData->ulRcvAntennaStateShow)
    {
        usClkSrcAlarm |= 0x04;
    }

    /* GPS遗留问题: 锁定卫星数为0 */
    for(ulLoop = 0; ulLoop < MAX_SAT_TYPE; ulLoop++)
    {
        ulTrackedSatCnt += g_RcvDrvData->ulTrackedSatCnt[ulLoop];
    }

    if (0 == ulTrackedSatCnt)
    {
        usClkSrcAlarm |= 0x08;
    }

    return usClkSrcAlarm;
}

/**************************************************************************
* 函数名称： BOOL ClockLeapYearCheck(USHORT YEAR)
* 功能描述： 是否是闰年判断
* 输入参数： 年份
* 输出参数： 无
* 返 回 值： TRUE：闰年，FALSE：平年
* -----------------------------------------------------------------------
* 其它说明：此种闰年判断修改方式只能到2099年,避免浮点运算
*
* 修改日期     版本号       修改人          修改内容
* 2008-9-16    V1.0         SDR BSP         创建
**************************************************************************/
BOOL ClockLeapYearCheck(USHORT YEAR)
{
    BOOL bRetVal = FALSE;
    if ( 0 == (YEAR & 0x0003))
    {
        bRetVal = TRUE;
    }
    else
    {
        bRetVal = FALSE;
    }
    return bRetVal;
}

/**************************************************************************
* 函数名称： USHORT ClockCalcDaysInCertainYear(USHORT usYear)
* 功能描述： 计算某一年的天数
* 输入参数： 指定的年份
* 输出参数： 无
* 返 回 值： 天数
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-3-17     V1.0      贾冉            创建
**************************************************************************/
USHORT ClockCalcDaysInCertainYear(USHORT usYear)
{
   USHORT usDays = 365;
   /* 判断该年是否是闰年 */
   if(TRUE == ClockLeapYearCheck(usYear))
   {
       usDays = 366;
   }
   else
   {
       usDays = 365;
   }

   return(usDays);
}

/**********************************************************************
* 函数名称：void ClockMonDayToDays(T_SDR1588_DATE *D)
* 功能描述：将电文中的月日转换为天数
* 输入参数：TOD
* 输出参数：
* 返 回 值：
* 其它说明：
*
* 修改日期        版本号                 修改人          修改内容
* ---------------------------------------------------------------------
* 2009-1-19       V1.0                   贾冉            创建
***********************************************************************/
void ClockMonDayToDays(T_Clock_Tod *D)
{
    UCHAR  MON_DAYS[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    UCHAR  TemChar;
    /* 入参检测 */
    if(NULL == D)
    {
        return;
    }
    D->DAYS = 0;

    for (TemChar = 1; TemChar < D->MON; TemChar++)
    {
        D->DAYS += MON_DAYS[TemChar];
    }
    /* 月日转换成天数时需要减掉1 */
    D->DAYS += ( D->DAY - 1);

    /*是润年,二月为29天*/
    if (((D->YEAR & 0x03 ) == 0) && (D->MON > 2))
    {
        D->DAYS+=1;
    }
}

/**************************************************************************
* 函数名称： SatRcvIdentify
* 功能描述： 接收机识别
* 输入参数： ulSatRefConfigInfo 内外置标志
* 输出参数： 无
* 返 回 值： BSP_OK:     成功
*            其他:       失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-12-21     V1.0      王会昌         创建
**************************************************************************/
ULONG SatRcvIdentify(VOID)
{
    ULONG ulRetVal = BSP_OK;

    /* 内置接收机识别及初始化 */
    ulRetVal = SatIntRcvIdentifyAndInit();
    if (BSP_OK != ulRetVal)
    {
        printf("GcmMain:IntRcv Identify And Init failed!\n");
        ulRetVal = BSP_ERROR;
    }
    else
    {
        printf("GcmMain:IntRcv Identify And Init succeed!\n");
    }


    return ulRetVal;
}

UINT32 GcmMain(VOID)
{
    g_RcvDrvData = (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData;

    printf("-----------GcmMain-------------\n");
    SatRcvIdentify();

    /* delay 0.05s */
    taskDelay(sysClkRateGet() / 20);
    return BSP_OK;
}

/**************************************************************************
* 函数名称： BspCloseGps
* 功能描述： 关闭GPS
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK:     成功
*            其他:       失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2015-3-23     V1.0      10170631         创建

**************************************************************************/
ULONG BspCloseGps(void)
{
    #if 0
    BspGnssTaskQuit();
    semGive(g_GpsInfo.FuncSem);
    #endif
    return BSP_OK;
}

/**************************************************************************
* 函数名称： SatIntRcvIdentifyAndInit
* 功能描述： 内置接收机类型以及初始化入口
* 输入参数： 无
* 输出参数： 无
* 返 回 值： BSP_OK:     成功
*            其他:       失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-4-13     V1.0       jiaran         创建
* 2011-1-7      V1.1      张全士         增加SigNav
**************************************************************************/
ULONG SatIntRcvIdentifyAndInit(void)
{

    if(0xFFFFFFFF == sulIntRcvIdenTaskId)
    {
        sulIntRcvIdenTaskId = (unsigned long)taskSpawn("[GPS]tIntRcvIden", \
                                     80, /* priority */    \
                                     0x0008/*VX_FP_TASK,for linux*/, /* option,   */    \
                                     0x40000,/* stack size */ \
                                     (FUNCPTR)IntRcvTask, 0, 0, 0, 0, 0, 0, 0, 0 ,0,0);
    }
    return BSP_OK;
}

/**************************************************************************
* 函数名称： IntRcvTask(T_GPS_RCV_DRV_DATA *pRcvDrvData)
* 功能描述： 内置接收机识别任务实体函数。
* 输入参数： 接收机实例结构体
* 输出参数： 无
* 返 回 值： OK       成功
*            ERROR    失败
* -----------------------------------------------------------------------
* 其它说明：
*
* 修改日期     版本号     修改人         修改内容
* 2010-4-7     V1.0       SDRBSP            create
* 2010-9-26    V1.1       王会昌            移植到K161
**************************************************************************/
VOID IntRcvTask(VOID)
{

    /* UINT32 ulCnt = 0; */
    UINT32 ulRcvType = UBLOX_Receiver;/* 默认使用Ublox接收机 */
    char buf[GNSS_LOG_LINE_SIZE] = {0};
    INT32 len                     = 0;

    /* 驱动实例指针检测 */
    if (NULL == g_IntRcvDrvData)
    {
        return;
    }


    while (1)
    {
        /* 没有配置时直接退出 */
        if (g_IntRcvDrvData->ulRefConfigFlag == 0)
        {
            //BspGnssTaskQuit();
            //return BSP_OK;
            BspSysMsDelay(1000);
            continue;
        }

        /* 识别是否是Ublox接收机  */
        if (BSP_OK == BspUbloxRcvIdentify((T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData))
        {
            ulRcvType = UBLOX_Receiver;
            g_tGcmUartSwBuf.ulRcvId = UBLOX_Receiver;
            GPS_LOG(GPS_DBG_INIT_PRN, "IntRcv:Ublox Identify Receiver ok!\n");
            break;
        }
        else
        {
            ulRcvType =  0;/**异常值走recv,临时解决cov :分支default **/

            dbgInfoEx("a error ulRcvType :%d",ulRcvType);
            /*GPS_LOG(GPS_DBG_INIT_PRN, "Int Unkonwn Receiver!\n");*/
            /*do nothing*/
        }
    }
    /* 框架配置数据赋值 */
    g_IntRcvDrvData->ulSatStartTime = GetBookTime();/* 模块初始化开始时刻 */
    g_IntRcvDrvData->ucRcvType = (UINT8)ulRcvType;           /* 接收机类型 */
    g_IntRcvDrvData->ulTimeModeLast = SATELLITE_AUTO_MODE;   /* 授时模式默认为auto */
    g_IntRcvDrvData->ulGetTMode = 0;

    if(BSP_OK != UbloxRcvDrv())
    {
        printf("IntRcv:Ublox Receiver Driver task Init err.\n");
    }

    gSatIntRcvFunc.pFuncAntCabDelaySet = UbloxSetAntCableLenth;
    gSatIntRcvFunc.pFuncRcvTimeModeSet = UbloxSetGpsRcvTimeMode;
    gSatIntRcvFunc.pFuncRcvTimeModeGet = UbloxGetGpsRcvTimeMode;

    len = snprintf_s(buf, sizeof(buf), "rcvType:%d",g_IntRcvDrvData->ucRcvType);
    SNPRINTF_S_CHECK(len, sizeof(buf));
    BspAddGnssLog(GNSS_LOG_TYPE_INIT, buf, len);
    if(NULL != gSatIntRcvFunc.pFuncAntCabDelaySet)
    {
        printf("--------call gSatIntRcvFunc.pFuncAntCabDelaySet!------------\n");
        gSatIntRcvFunc.pFuncAntCabDelaySet(g_IntRcvDrvData->lAntCabDelay,(T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData);/* 设置到接收机 */
    }

    sleep(2); /* 由于taskspawn返回任务ID的时间晚于实际执行时间，在此处加2s延时，暂时规避 */

    sulIntRcvIdenTaskId = 0xFFFFFFFF;
    return;
}

ULONG BspPp1sProtectTaskEntry(VOID)
{

    while (1)
    {
       UINT32 ulTickOld = 0;
        /* 如果PP1s中断还没有来, 直接退出 */
        if (g_ulProtectTimes == 0xFFFFFFFF || g_IntRcvDrvData->ulRefConfigFlag == 0)
        {
            sleep(1);
            continue;
        }

        if (g_ulProtectTimes == 0)
        {
            GPS_LOG(GPS_DBG_INIT_PRN, "[PP1S protect] pp1sIsrCnt=%d protectCnt=%d ticks=%d\n",s_ulPp1sIsrCnt,s_ulPp1sProtectCnt,tickGet());
        }

        g_ulProtectTimes++;

        if (g_ulProtectTimes >= 55)
        {
            s_ulPp1sProtectCnt++;
            dbgInfoEx("PP1s Int Lost!!! Sim Tx Tod To CC!!!count=%d, last tick:%d, curr tick:%d.\n", s_ulPp1sProtectCnt, ulTickOld,tickGet());
            g_ulProtectTimes -= 50;
            ClockIncrementTime(&gtSatLocalTod);
            semGive(g_GpsIntSem);
        }
        tgnsssndInfo.pp1sProCnt = s_ulPp1sProtectCnt;
        taskDelay((sysClkRateGet()) / 50); /* 延时20ms */
    }
}

UINT32 BspGpsModuleInit()
{
    printf("--------BspGpsModuleInit------------\n");

    /* 打开外置gps供电 */
    BspGpsPowSwitchSet(SWITCH_ON);

    if ((NULL == g_GpsIntSem) && s_RgpsDevInitCtrlFlag)
    {
        /* 创建一个二进制信号量 */
        g_GpsIntSem = semBCreate(SEM_Q_FIFO, SEM_EMPTY);
        _BspInitPp1sInt();
    }

    /* 创建处理实时控制的任务 */
    if ((g_ltClkRtTaskId == 0xFFFF) && s_RgpsDevInitCtrlFlag)
    {
        g_ltClkRtTaskId = taskSpawn(
                              "[GPS]tClkRt", \
                              0,        /* priority */    \
                              0x0008/*VX_FP_TASK for linux*/, /* option,add VX_FP_TASK,2008.11.11 */    \
                              0x80000,  /* stack size */  \
                              (FUNCPTR)BspCommonClkRtCtrlTaskEntry, 0, 0, 0, 0, 0,   0, 0, 0, 0, 0
                          );
    }

    if (g_lGpsRecvTaskId == 0xFFFF)
    {
        g_lGpsRecvTaskId = taskSpawn("[GPS]UartSimRecvTask", 56, 0, 20000,
                                     (FUNCPTR)ReceiveDataFromFpgaSimUart, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }

    if (((INT32)0xFFFFFFFF == g_lPp1sProtectTaskId) && s_RgpsDevInitCtrlFlag)
    {
        g_lPp1sProtectTaskId = taskSpawn("[GPS]Pp1sProtect", 56, 0, 10000,
                                         (FUNCPTR)BspPp1sProtectTaskEntry, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }

    taskSpawn("[GPS]LogRecord", 165, 0, 16*1024,
              (FUNCPTR)BspRecordGnssLog, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return BSP_OK;
}

/**************************************************************************
 *以下为调试gps相关函数
 *
 *
 *
 **************************************************************************/

ULONG testInitGpsRecvTask()
{
    g_lGpsRecvTaskId = taskSpawn("GpsUartRecvTask", 56, 0, 20000,
                                 (FUNCPTR)ReceiveDataFromFpgaSimUart, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return BSP_OK;
}
/**************************************************************************
* 函数名称： void GcmPhyBufShow(void)
* 功能描述： Phy缓冲区电文打印
* 输入参数： 无
* 输出参数： 无
* 返 回 值： 无
* 其它说明：
* -----------------------------------------------
* 修改日期    版本号     修改人         修改内容
* 2011-3-12   V1.0       zhangqs           创建
**************************************************************************/
void GcmPhyBufShow(void)
{
    ULONG ulByteCnt = 0;
    ULONG i = 0;
    T_FpgaUartBuffer tTempBuf;
    memset(&tTempBuf, 0, sizeof(tTempBuf));

    printf("g_tGcmUartPhyBuf data list start!\n");
    for(i = 0; i < GCM_UART_QUEUE_SIZE; i++)
    {
        tTempBuf.aucBuf[i] = g_tGcmUartPhyBuf.aucBuf[i];
        printf("%02x ", tTempBuf.aucBuf[i]);

        if (0 == i % 128)
        {
            printf("\n");
        }
    }
    printf("\ng_tGcmUartPhyBuf data list end!\n");
    printf("**************************************\n");
    tTempBuf.ulHead = g_tGcmUartPhyBuf.ulHead;
    tTempBuf.ulTail = g_tGcmUartPhyBuf.ulTail;
    ulByteCnt = (tTempBuf.ulTail - tTempBuf.ulHead + GCM_UART_QUEUE_SIZE) % GCM_UART_QUEUE_SIZE;
    printf("%d Bytes data get, current ulHead = %d, current ulTail = %d\n",ulByteCnt,tTempBuf.ulHead,tTempBuf.ulTail);
    for(i = 0; i < ulByteCnt; i++)
    {
        printf("%02x ",tTempBuf.aucBuf[(tTempBuf.ulHead + i) % GCM_UART_QUEUE_SIZE]);
    }
    printf("\n");
}

void ShowDrvData(ULONG ulRefId)
{
    T_GPS_RCV_DRV_DATA *pDrvData = NULL;

    if(NULL == g_IntRcvDrvData)
    {
        return;
    }

    switch(ulRefId)
    {
        case BSP_CLOCK_REF_INTERNAL_GPS:/* 内置GPS */
            pDrvData = (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData;
            break;


        default:
            pDrvData = (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData;
            break;
    }

    /* 配置及过程变量 start*/
    printf("ulSatDriverId = %d\n",pDrvData->ulSatDriverId);  /* 参考源ID,例如驱动会根据不同的Id进行不同的处理 */
    printf("ulRefConfigFlag = %d\n",pDrvData->ulRefConfigFlag);/* 该结构体实例是否后台配置，0：未配置；1：配置 */
    /* 后台接收机配置模式，是否维护接收机，与参考源子类ID对应，
       1:内置；2：面板外置；3：背板外置，4/14：1pps+tod主/备，5：电文透传级联从框
       0表示未配置态 */
    printf("ulRcvPlace = %d\n",pDrvData->ulRcvPlace);
    printf("ulReceiverCtrl = %d\n",pDrvData->ulReceiverCtrl);  /* 是否维护接收机标志，0：不维护，1：维护 */
    printf("ulLostThreshold = %d\n",pDrvData->ulLostThreshold);/* 后台配置的参考源不可用门限值 */
    printf("lAntCabDelay = %d\n",pDrvData->lAntCabDelay); /* 天馈线缆延时ns，参考源1，2，3时有效 */
    printf("lAntCabDelayInLength = %d\n",pDrvData->lAntCabDelayInLength);/* 天馈线缆长度，参考源1，2，3时有效，可正可负，主要是可以双向调节pp1s的位置 */
    printf("ulInTimeInputType = %d\n",pDrvData->ulInTimeInputType); /* PP1S和TOD输入方式，0:为一线输入,1:为二线输入,参考源4，5，14有效 */
    printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);/* 天馈线缆长度改变标志 */
    printf("ulLeastSatNum = %d\n",pDrvData->ulLeastSatNum);   /* 最小开控、告警搜星数，参考源1，2，3时有效 */
    printf("ulLeastSatNumBackup = %d\n",pDrvData->ulLeastSatNumBackup);   /* 最小开控、告警搜星数，单星备份使用 */
    printf("ucRcvWorkMode = %d\n",pDrvData->ulRcvWorkMode);   /* 接收机类型以及工作模式，参考源2，3时有效  */
    /* 单星授时功能start */
    printf("ulTimeMode = %d\n",pDrvData->ulTimeMode);               /* 后台设置的 auto mode or fix mode */
    printf("ulTimeModeLast = %d\n",pDrvData->ulTimeModeLast);           /* 后台设置的上一次auto mode or fix mode */
    printf("dLongitude = %f\n",pDrvData->dLongitude);              /* 经度，单位是度 */
    printf("dLatitude = %f\n",pDrvData->dLatitude);               /* 维度，单位是度 */
    printf("dAltitude = %f\n",pDrvData->dAltitude);               /* 高度，单位是米 */
    printf("ulUsingTimeMode = %d\n",pDrvData->ulUsingTimeMode);          /* 接收机当前的模式 */
      /* 配置过程变量 */
    printf("ulSetTMode = %d\n",pDrvData->ulSetTMode);  /* 设置时设置成功标志 */
    printf("ulGetTMode = %d\n",pDrvData->ulGetTMode);  /* 获取时设置成功标志 */
    /* 单星授时功能end */
    printf("ulSatStartTime = %d\n", pDrvData->ulSatStartTime);  /* 卫星类模块启动时刻(s) */
    printf("ulAntCheckCnt = %d\n", pDrvData->ulAntCheckCnt); /* 检测天馈时临时计数变量 */
    printf("ulRcvInitCnt = %d\n", pDrvData->ulRcvInitCnt);  /* 接收机初始化临时计数变量 */
    printf("ulRcvUpdateCnt = %d\n", pDrvData->ulRcvUpdateCnt);  /* 接收机升级临时计数变量 */
    printf("ulGpsFixNotOkTime = %d\n", pDrvData->ulGpsFixNotOkTime); /* 接收机搜星4颗以上但是无法进入3D或者time模式的开始时间 */
    printf("ulAntState = %d\n", pDrvData->ulAntState);         /* 统计天馈异常次数临时状态变量，初始值为0 */
    //printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);T_SAT_DETAILS atSatDetails[16];/* 解析各颗卫星详细信息时用的临时缓存数组 */
    printf("ulRcvCmdNum = %d\n", pDrvData->ulRcvCmdNum);            /* 发送给接收机命令的编号 */
    printf("ulRcvCmdStartTime = %d\n", pDrvData->ulRcvCmdStartTime);       /* 命令发送时刻计时，发送命令后持续等待时间计数，超过即认为命令超时 */
    printf("ulRcvCmdRunFlag = %d\n", pDrvData->ulRcvCmdRunFlag);        /* 在当前命令没有得到回应之前不发送下一条命令，标示当前命令发送状态，0：无命令在发送，1：有命令在发送等待结果中 */
    printf("ulRcvCmdTimeOutCnt = %d\n", pDrvData->ulRcvCmdTimeOutCnt);     /* 接收机命令发送超时计数 */
    printf("ulRcvWarmStartCnt = %d\n", pDrvData->ulRcvWarmStartCnt);      /* 接收机热启计数,计到一定数值时有可能需要转到冷启 */
    printf("ulRcvColdInitFlag = %d\n", pDrvData->ulRcvColdInitFlag);      /* 接收机冷启标志，1：冷启；0：热启 */
    printf("ulRcvColdInitFlagLast = %d\n", pDrvData->ulRcvColdInitFlagLast);      /* 接收机冷启标志上一个状态，1：冷启；0：热启 */
    /* 配置及过程变量 end */
    /* 状态信息 start */
    printf("bUartMsgOn = %d\n", pDrvData->bUartMsgOn); /* CPU或FPGA UART能否接收到电文标志，FALSE为接收不到电文，TRUE为能接收到电文 */
    printf("ucGpsUartErr = %d\n", pDrvData->ucGpsUartErr); /* 接收机uart口状态标志，0：正常；1：不通 */
    printf("ucRcvType = %d\n", pDrvData->ucRcvType); /* 接收机类型 */
    printf("ucRcvVersion = %d\n", pDrvData->ucRcvVersion); /* 接收机版本 */
    //printf("ucRcvWorkMode = %d\n",pDrvData->ucRcvWorkMode); /* 接收机工作模式，0：单模，1：双模 */
    printf("ulRcvFixStatus = %d\n", pDrvData->ulRcvFixStatus); /* 接收机定位状态，也适用于1pps+tod参考源 */
    printf("ulRcvAntennaState = %d\n", pDrvData->ulRcvAntennaState); /* 天馈状态 */
    printf("ulRcvAntennaStateShow = %d\n", pDrvData->ulRcvAntennaStateShow); /* 增加天馈假开路处理后的天馈状态，告警诊断用 */
    printf("ulRcvInitStartTime = %d\n", pDrvData->ulRcvInitStartTime); /* 接收机初始化开始时刻 */
    printf("ulRcvInitFinishTime = %d\n", pDrvData->ulRcvInitFinishTime); /*接收机初始化完成的时间*/
    printf("ulRcvInitFinishFlag = %d\n", pDrvData->ulRcvInitFinishFlag); /* 接收机初始化完成标志 */
    printf("ucRcvInitStep = %d\n", pDrvData->ucRcvInitStep); /* 接收机初始化步骤 */
    printf("ulRcvOkTime = %d\n", pDrvData->ulRcvOkTime); /* 接收机状态ok时间，源质量检测，单位是s  */
    printf("ulRcvErrTime = %d\n", pDrvData->ulRcvErrTime); /* 接收机状态Err时间，源质量检测，单位是s  */
    printf("ucLockSatState = %d\n", pDrvData->ulLockSatState); /* GPS接收机搜星状态。0表示搜星成功，1表示正在搜星，2表示搜星失败 */
    printf("ulLastLockSatOkTime = %d\n", pDrvData->ulLastLockSatOkTime); /*最近一次搜星成功时间，防抖使用 */
    printf("ulLastLockSatErrTime = %d\n", pDrvData->ulLastLockSatErrTime); /* 最近一次搜星失败时间，防抖使用 */
    /* 防止天馈假开路相关变量 */
    printf("ulOmitAntBreakLockSatOkTimes = %d\n", pDrvData->ulOmitAntBreakLockSatOkTimes); /* 搜星好持续记数 */
    printf("ulOmitAntBreakLockSatErrTimes = %d\n", pDrvData->ulOmitAntBreakLockSatErrTimes); /* 搜星不好持续记数 */
    printf("ulLockedSatNumIsEnoughForOmitAntBreak = %d\n", pDrvData->ulLockedSatNumIsEnoughForOmitAntBreak); /* 记录到足够多的锁定卫星次数来屏蔽天馈开路，0：没有，1：有 */
    printf("ulLastBookTime = %d\n", pDrvData->ulLastBookTime);
    printf("ulAntennaBadTimes = %d\n", pDrvData->ulAntennaBadTimes); /* 天馈故障次数 */
    printf("ulRcvResetTimes = %d\n", pDrvData->ulRcvResetTimes); /* 接收机重启次数 */
    printf("ulRcvRstTimesSinceCmd = %d\n", pDrvData->ulRcvRstTimesSinceCmd); /* 因命令超时复位接收机统计次数 */
    //printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);UCHAR aucSatInUse[12];           /* 正在使用卫星信息 */
    /* 状态信息 end */
    /* msg start */
    //printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);T_Clock_Tod tGpsDate;/* gps tod */
    //printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);T_Clock_Tod tLastGpsDate;/* Last gps tod  */
    printf("ulRcvTodOkCnt = %d\n", pDrvData->ulRcvTodOkCnt); /* 驱动判断tod是否可用临时计数变量 */
    printf("ulFirstFlag = %d\n", pDrvData->ulFirstFlag);      /* 第一次同步电文tod */
    printf("ulSatTodAbnormalTimes = %d\n", pDrvData->ulSatTodAbnormalTimes); /* 统计tod跳秒次数 */
    printf("ulRcvTodOkFlag = %d\n", pDrvData->ulRcvTodOkFlag); /* gps tod 是否可用的一个标志 0:不可用，1：可用 */
    printf("ucLeapSeconds = %d\n", pDrvData->ucLeapSeconds); /* 闰秒 */
    //printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);T_POSITION tPositionInfo;/* 经纬高位置信息，给后台看的 */
    /* msg end */
    //printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);T_SAT_IN_VIEW tSatInVew;                  /* 可见卫星的详细信息 */
    printf("ulRcvUseableFlag = %d\n", pDrvData->ulRcvUseableFlag);                  /* 接收机是否可用的标志，0：初始化，1：不可用 ，2：可用*/
    printf("ulRcvOldUseableFlag = %d\n", pDrvData->ulRcvOldUseableFlag);               /* 接收机(上一个状态)是否可用的标志，0：不可用，1：可用 */
    printf("ulRcvStatusChgSttTime = %d\n", pDrvData->ulRcvStatusChgSttTime);             /* 接收机可用不可用状态改变时对应的时刻，为了计算接收机状态持续时间 */
    printf("ulRcvStatusLastTime = %d\n", pDrvData->ulRcvStatusLastTime);               /* 接收机可用或者不可用持续时间，以s为单位 */
    /****************详细信息(调试、定位故障专用，不向外暴露)start************************ */
    printf("ulRcvMsgStas = %d\n", pDrvData->ulRcvMsgStas);                      /* 接收机电文接收状态标志，0：接收不正常，1：每收到TOD信息就置为1 */
    //printf("ulAntCableLenChange = %d\n",pDrvData->ulAntCableLenChange);ULONG ulRcvRstDetails[10];   /* 接收机复位原因详细记录数据 */
    printf("ulRcvTodStas = %d\n", pDrvData->ulRcvTodStas);                      /* 接收机电文接收TOD状态标志，0：接收不正常，1：每收到TOD信息就置为1 */
    printf("ulTodStasErrCnt = %d\n", pDrvData->ulTodStasErrCnt);                   /* 接收机电文接收TOD 没收到持续次数 */
    printf("ulTodStasErrFlag = %d\n", pDrvData->ulTodStasErrFlag);                  /* 接收机电文接收TOD 没收到持续次数超过10次，给出错误标志：0:正常；1：出错 */
    printf("ulGpsNoAckTime = %d\n", pDrvData->ulGpsNoAckTime);                    /* 接收机收不到tod电文起始时间，若与GetBookTime相同则表示接收正常 */
    printf("ulLockFailedTime = %d\n", pDrvData->ulLockFailedTime); /* 天馈正常但是搜星为0的状态开始时间 */
    printf("ucInputLineCfgStatus = %d\n", pDrvData->ucInputLineCfgStatus); /* 分路合路输入和配置是否一直状态，0：一致；1：不一致 */
    /****************详细信息end************************ */
    /* 1pps+tod Ref state start */
    printf("ucFrameMode = %d\n", pDrvData->ucFrameMode);         /* 运营商标准 */
    printf("ucPpsStatus = %d\n", pDrvData->ucPpsStatus);          /* 秒脉冲状态，0x00 = 正常，0x01 = 降质，0x02 = 不可用；其它保留 */
    printf("ucTacc = %d\n", pDrvData->ucTacc);              /* pps抖动量级，写死为0xff */
    printf("ucClkSrcType = %d\n", pDrvData->ucClkSrcType);          /* 时钟源类型，0x00 = 北斗；0x01 = gps;0x02 = 1588，外置接收机也使用 */
    printf("usClkSrcState = %d\n", pDrvData->usClkSrcState);        /* 时钟源工作状态GPSfix Type, range 0..3
                                    0x00 = no fix
                                    0x01 = dead reckoning only
                                    0x02 = 2D-fix
                                    0x03 = 3D-fix
                                    0x04 = GPS + dead reckoning combined
                                    0x05 = Time only fix
                                    0x06..0xff = reserved  */
    printf("usClkSrcAlarm = %d\n", pDrvData->usClkSrcAlarm);        /* 监控告警，时钟源状态告警：
                                    Bit 0: not used
                                    Bit 1: Antenna open
                                    Bit 2: Antenna shorted
                                    Bit 3: Not tracking satellites
                                    Bit 4: not used
                                    Bit 5: Survey-in progress
                                    Bit 6: no stored position
                                    Bit 7: Leap second pending
                                    Bit 8: In test mode
                                    Bit 9: Position is questionable
                                    Bit 10: not used
                                    Bit 11: Almanac not complete
                                    Bit 12: PPS was generated */
    /* 1pps+tod Ref state end */
    /* FPGA操作相关start */
    printf("ulResv = %d\n", pDrvData->ulResv);          /* 保留字段，扩展使用 */
}

/*BSP-OAM 回传信息*/
void ShowRruGnssFrameInfo(void)
{
    T_RRU_GNSS_FRAME tLocaFrame = {0};
    memcpy((void*)&tLocaFrame, (void*)&g_tRruGnssFrame, sizeof(T_RRU_GNSS_FRAME));

    dbgInfo("tTimeFrame.tFrameHead.ucFrameSyncChar1 = 0x%x\n", tLocaFrame.tTimeFrame.tFrameHead.ucFrameSyncChar1);
    dbgInfo("tTimeFrame.tFrameHead.ucFrameSyncChar2 = 0x%x\n", tLocaFrame.tTimeFrame.tFrameHead.ucFrameSyncChar2);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucMsgHeadClass = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucMsgHeadClass);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucMsgHeadId = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucMsgHeadId);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.usMsgLength = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.usMsgLength);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ulGpsTow = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ulGpsTow);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ulReserved1 = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ulReserved1);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.usGpsWeek = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.usGpsWeek);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.cLeapS = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.cLeapS);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucPpsStatus = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucPpsStatus);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucTaccs = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucTacc);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucGnssId = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucGnssId);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucRackNo = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucRackNo);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucLockSatCnt = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucLockSatCnt);
    dbgInfo("tLocaFrame.tTimeFrame.tTimeInfo.ucMsgCRC = 0x%x\n", tLocaFrame.tTimeFrame.tTimeInfo.ucMsgCRC);

    dbgInfo("tLocaFrame.tStasFrame.tFrameHead.ucFrameSyncChar1 = 0x%x\n", tLocaFrame.tStasFrame.tFrameHead.ucFrameSyncChar1);
    dbgInfo("tLocaFrame.tStasFrame.tFrameHead.ucFrameSyncChar2 = 0x%x\n", tLocaFrame.tStasFrame.tFrameHead.ucFrameSyncChar2);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ucMsgHeadClass = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ucMsgHeadClass);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ucMsgHeadId = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ucMsgHeadId);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.usMsgLength = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.usMsgLength);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ucClkSrcType = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ucClkSrcType);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.usClkSrcState = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.usClkSrcState);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.usClkSrcAlarm = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.usClkSrcAlarm);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ucGnssId = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ucGnssId);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ucFrameMode = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ucFrameMode);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ucFrameNum1 = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ucFrameNum1);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ulFrameNum2 = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ulFrameNum2);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ulPp1sOffset = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ulPp1sOffset);
    dbgInfo("tLocaFrame.tStasFrame.tStateInfo.ucMsgCRC = 0x%x\n", tLocaFrame.tStasFrame.tStateInfo.ucMsgCRC);
    dbgInfo("tLocaFrame.usRev = 0x%x\n", tLocaFrame.usRev);
    return;
}

VOID _BspSetGpsAntState()
{
    if (g_IntRcvDrvData == NULL)
    {
        return;
    }
    if(ulLostCnt >= 100)
    {
        if (BSP_CLOCK_REF_EXTERNAL_FRONT_SATELLITE == g_IntRcvDrvData->ulRcvPlace)/* 外置GPS，设置为未知态 */
        {
            g_IntRcvDrvData->ulRcvAntennaStateShow = GPS_ANTENNA_STATE_DONTKNOW;
            g_IntRcvDrvData->ulRcvAntennaState = GPS_ANTENNA_STATE_DONTKNOW;
        }
        GPS_LOG(GPS_DBG_DATA_PRN, "lost recv > 100, ant break\n");
    }
    GPS_LOG(GPS_DBG_DATA_PRN, "_BspSetGpsAntState, cnt=%d\n", ulLostCnt);
}

/**************************************************************************
* 函数名称： BspGNSSDrvStatusGet
* 功能描述： GPS接收卡诊断信息获取接口
* 输入参数： ulRcvBabyId:对应参考源配置Id，可能值为内置、gps级联、面板外置、背板外置
* 输出参数： pGNSSRcvStatus   诊断输出结构
* 返 回 值： BSP_OK:成功；  BSP_ERROR:失败
* -----------------------------------------------------------------------
* 其它说明： 告警诊断使用
*
* 修改日期     版本号       修改人            修改内容
* 2010-12-8    V1.0         jiaran           创建
**************************************************************************/
ULONG BspGNSSDrvStatusGet(UINT32 index, UINT32 radioMode, T_GNSS_RECEIVER_STATE *pGNSSRcvStatus)
{
    ULONG ulRetVal = BSP_OK;

    /* 入参检测 */
    if (NULL == pGNSSRcvStatus)
    {
        return BSP_ERROR_NULL_POINTER;
    }


    if(NULL == g_IntRcvDrvData)
    {
        return BSP_ERROR_NULL_POINTER;
    }

    switch(g_IntRcvDrvData->ucRcvType)
    {
        case UBLOX_Receiver:
        {
            UbloxRcvStatusGet(radioMode, pGNSSRcvStatus,(T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData);
            if(0 == pGNSSRcvStatus->ucGpsAntennaStatus)
            {
                pGNSSRcvStatus->ucGpsAntennaStatus = GPS_ANTENNA_STATE_DONTKNOW;
            }

            break;
        }

        default:
        {
            if(BSP_OK == UbloxRcvStatusGet(radioMode, pGNSSRcvStatus,(T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData))
            {
                pGNSSRcvStatus->ucGpsReceiverInitFinish = 1;
                pGNSSRcvStatus->ucGpsReceiverType = 0xFF;
                pGNSSRcvStatus->ucLockSatState = 1;
                pGNSSRcvStatus->ucRcvWorkMode = g_IntRcvDrvData->ulRcvWorkMode;
            }
            else
            {
                ulRetVal = BSP_ERROR;
            }
            break;
        }
    }
    return ulRetVal;
}

/*GPS告警查询 对外接口 */
ULONG BspGnssAlarmStatus(UINT32 index, T_GNSS_ALARM_STATUS* ptGnssAlarmStatus)
{
    ULONG ulRetVal = BSP_OK;
    T_GNSS_ALARM_STATUS tTempGNSSAlarmStatus;
    /* 入参检测 */
    if (NULL == ptGnssAlarmStatus)
    {
        return BSP_ERROR_NULL_POINTER;
    }
    /* 数据清零 */
    memset(&tTempGNSSAlarmStatus,0,sizeof(tTempGNSSAlarmStatus));

    if (g_IntRcvDrvData == NULL)
    {
        return BSP_ERROR;
    }


    switch(g_IntRcvDrvData->ucRcvType)
    {
        case UBLOX_Receiver:
        {
            if(BSP_OK == UbloxRcvAlarmGet(&tTempGNSSAlarmStatus,(T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData))
            {
                memcpy(ptGnssAlarmStatus,&tTempGNSSAlarmStatus,sizeof(tTempGNSSAlarmStatus));
            }
            else
            {
                ulRetVal = BSP_ERROR;
            }
            break;
        }

        default:
        {
            /* 将默认值上报给上层诊断，即未配置 */
            memcpy(ptGnssAlarmStatus,&tTempGNSSAlarmStatus,sizeof(tTempGNSSAlarmStatus));
            if(BSP_OK == UbloxRcvAlarmGet(&tTempGNSSAlarmStatus,(T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData))
            {
                memcpy(ptGnssAlarmStatus,&tTempGNSSAlarmStatus,sizeof(tTempGNSSAlarmStatus));
            }
            else
            {
                ulRetVal = BSP_ERROR;
            }
            break;
        }
    }
    return ulRetVal;
}

/* 通过逻辑设置 */
ULONG BspResetGnss(VOID)
{
    #if 0
    INPUT_POINTER_CHECK( g_GpsInfo.gpsDevReset);
    g_GpsInfo.gpsDevReset();  /* 0x2100,bit0 复位ublox */
    #endif
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspConfigGnss(*)
*  功能描述   : GNSS配置接口
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : ptGnssParaCfg
*               T_GNSS_PARA_CFG的定义位于gpsapi.h中
*  输出参数   :
*  返 回 值   : BSP_OK, 其它值为失败
*  其它说明   : RRU公共接口函数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), zhaoyun@2017-05-12 10:59:05 create
*----------------------------------------------------------------------------
*/
UINT32 BspConfigGnss(UINT32 radioMode, T_GNSS_PARA_CFG *ptGnssParaCfg)
{
    UINT32 ulRetVal = BSP_OK;
    T_GNSS_PARA_CFG *pLocalParaCfg = NULL;
    UINT32 gnssCfgNum = 0;
    UINT32 gnssCfgLastNum = 0;
    char buf[GNSS_LOG_LINE_SIZE]  = {0};
    INT32 len       = 0;

    printf("---------------BspConfigGnss!------------------\n");

    INPUT_POINTER_CHECK(ptGnssParaCfg);

    BspGnssLogInit();
    len = snprintf_s(buf,sizeof(buf),"%#x {%d,%d,%d,%d,%d,%d,%.2f,%.2f,%.2f,%d,%#x,%d,%d}",
              radioMode,ptGnssParaCfg->ucRackNo,ptGnssParaCfg->ucGnssId,
              ptGnssParaCfg->ucGnssWorkMode,ptGnssParaCfg->ucResv,ptGnssParaCfg->lAntCabDelay,
              ptGnssParaCfg->ulTimeMode,ptGnssParaCfg->dLongitude,ptGnssParaCfg->dLatitude,
              ptGnssParaCfg->dAltitude,ptGnssParaCfg->ulLeastSatNum,ptGnssParaCfg->ulRadioMode,
              ptGnssParaCfg->ulAlmReportThre,ptGnssParaCfg->ulAlmRecoverThre);
    SNPRINTF_S_CHECK(len, sizeof(buf));
    BspAddGnssLog(GNSS_LOG_TYPE_CFG, buf, len);

    if (NULL != pGpsGetSel8tFunc)
    {
        BspGpsSetBfnAdjust();
    }
    if (g_IntRcvDrvData == NULL)
    {
        g_IntRcvDrvData = (T_GPS_RCV_DRV_DATA *)malloc(sizeof(T_GPS_RCV_DRV_DATA));
        if (g_IntRcvDrvData == NULL)
        {
            dbgErr("Malloc %lu Bytes Fails\n", sizeof(T_GPS_RCV_DRV_DATA));
            return BSP_ERROR;
        }
        memset((VOID *)g_IntRcvDrvData, 0, sizeof(T_GPS_RCV_DRV_DATA));
        /*gps uart 初始化回调*/
        if(NULL != pFuncGpsUartInitCallBack)
        {
            pFuncGpsUartInitCallBack();
        }
    }

    if (1 == g_ulFirstGpsInit)
    {
        BspResetGnss();
        memset((VOID *)g_IntRcvDrvData, 0, sizeof(T_GPS_RCV_DRV_DATA));
        g_IntRcvDrvData->ucGnssId = 0xff;
        g_IntRcvDrvData->ulRcvAntennaStateShow = GPS_ANTENNA_STATE_DONTKNOW;  /*天馈状态默认未知*/
        g_IntRcvDrvData->ulNormalTodTimes = BspGetFlashGpsTimeStamp();
    }

    UbloxRcvManualReset(1); // 这里主要是为了将搜星信息清零，实际不复位接收机
    gnssCfgLastNum = BspGetGnssValidNum();
    BspSetGnssCfgPara(ptGnssParaCfg);
    SetGnssAlmTime();
    gnssCfgNum = BspGetGnssValidNum();
    if (gnssCfgNum == 0)
    {
        if(NULL != pFuncGps1ppsSourceCallBack)//打开epld开关，rgps 1pps由epld送至mcs
        {
            pFuncGps1ppsSourceCallBack(0);
        }
        if(NULL != pFuncGpsSetRefCallBack)
        {
            pFuncGpsSetRefCallBack(0);
        }
        /* 删除配置，清掉数据 */
        memset((VOID *)g_IntRcvDrvData, 0, sizeof(T_GPS_RCV_DRV_DATA));
        if (g_RcvDrvData != NULL)
        {
            memset(g_RcvDrvData, 0, sizeof(T_GPS_RCV_DRV_DATA));
        }
        memset(&g_tGcmUartSwBuf, 0, sizeof(T_FpgaUartBuffer));
        g_IntRcvDrvData->ucGnssId = 0xff; /* 无效配置为0xFF */
        g_IntRcvDrvData->ulRcvAntennaStateShow = GPS_ANTENNA_STATE_DONTKNOW;   /*天馈状态默认未知*/
        //g_IntRcvDrvData->ulRefConfigFlag = 0;
        //g_IntRcvDrvData->ulRcvPlace = 0;
        GpsAlmStateInit();
        return BSP_OK;
    }

    pLocalParaCfg = ptGnssParaCfg;
    g_IntRcvDrvData->ucGnssId = pLocalParaCfg->ucGnssId;
    g_IntRcvDrvData->ulRefConfigFlag = 1;
    g_IntRcvDrvData->ulRcvPlace = BSP_CLOCK_REF_EXTERNAL_FRONT_SATELLITE;

    g_IntRcvDrvData->ulRcvWorkMode = pLocalParaCfg->ucGnssWorkMode; /* bbu 下发的模式gps:1,bd:5,bd+gps:6/7 */
    if(7 == g_IntRcvDrvData->ulRcvWorkMode)
    {
        g_IntRcvDrvData->ulRcvWorkMode = 6;
    }

    g_IntRcvDrvData->ucRackNo = pLocalParaCfg->ucRackNo;
    g_IntRcvDrvData->lAntCabDelay = pLocalParaCfg->lAntCabDelay - 8000; /* 宋连坡 2011-11-15 减去8000 */
    printf("pLocalParaCfg->lAntCabDelay = %d,g_IntRcvDrvData->lAntCabDelay=%d\n",
        pLocalParaCfg->lAntCabDelay, g_IntRcvDrvData->lAntCabDelay);
    g_IntRcvDrvData->ulLeastSatNum = pLocalParaCfg->ulLeastSatNum;
    g_IntRcvDrvData->ulTimeMode = pLocalParaCfg->ulTimeMode;
    if(NULL != pFuncGpsSetRefCallBack)
    {
        pFuncGpsSetRefCallBack(1);
    }
    if(NULL != pFuncGps1ppsSourceCallBack)//打开epld开关，rgps 1pps由epld送至mcs
    {
        pFuncGps1ppsSourceCallBack(1);
    }
    /* 单星授时：获取当前自动手动工作模式，如果当前模式与设置的一致则不进行设置，再调用设置函数 */
    if (g_IntRcvDrvData->ulTimeMode == g_IntRcvDrvData->ulTimeModeLast)
    {
        printf("The Int gps working time mode is same with cfg\n");
    }
    else
    {
        /* 更新本地维护的上一次模式值 */
        g_IntRcvDrvData->ulTimeModeLast = g_IntRcvDrvData->ulTimeMode;
    }
    g_IntRcvDrvData->ulReceiverCtrl = 1;

    if (gnssCfgLastNum >= 1) /* 已存在下面不重新初始化 */
    {
        if (NULL != gSatIntRcvFunc.pFuncAntCabDelaySet)
        {
            printf("--------call gSatIntRcvFunc.pFuncAntCabDelaySet!------------\n");
            gSatIntRcvFunc.pFuncAntCabDelaySet(g_IntRcvDrvData->lAntCabDelay, (T_GPS_RCV_DRV_DATA *)g_IntRcvDrvData); /* 设置到接收机 */
        }
        return BSP_OK;
    }

    BspGpsModuleInit();
    sleep(1);
    GcmMain();


    /* 实时控制定时器时标清0 */
    g_ulProtectTimes = 0;
    g_ulFirstGpsInit = 0;

    return ulRetVal;
}

ULONG BspGnssTaskQuit(VOID)
{
    extern ULONG sulIntRcvTaskId;

    //if (timer_delete(g_Simtimerid) != 0)
    //{
    //    dbgPrn("[GPS]Close Sim Timer Fail, Error : %s\n", strerror(errno));
    //}


    taskDelete(g_ltClkRtTaskId);
    taskDelete(g_lGpsRecvTaskId);
    taskDelete(sulIntRcvIdenTaskId);
    taskDelete(sulIntRcvTaskId);

    sulIntRcvIdenTaskId = 0xFFFFFFFF;
    sulIntRcvTaskId = 0xFFFFFFFF;
    g_ltClkRtTaskId = 0xFFFF;
    g_lGpsRecvTaskId = 0xFFFF;
    g_ulProtectTimes = 0xFFFFFFFF;

    memset((VOID *)g_IntRcvDrvData, 0, sizeof(T_GPS_RCV_DRV_DATA));
    memset(g_RcvDrvData,0,sizeof(T_GPS_RCV_DRV_DATA));
    memset(&g_tGcmUartSwBuf, 0, sizeof(T_FpgaUartBuffer));

    return BSP_OK;
}

UINT32 ShowGnssStatus(UINT32 radioMode)
{
    UINT32 ulRet, i = 0;
    T_GNSS_RECEIVER_STATE   tLocalGnssStas = {0};
    T_GNSS_ALARM_STATUS tLocalGnssAlarm = {0};
    ulRet = BspGNSSDrvStatusGet(tLocalGnssStas.ucGnssId, radioMode, &tLocalGnssStas);
    dbgInfo("--------------GNSS DRV STATUS INFO:%X------\n",ulRet);
    dbgInfo("         s_ulPp1sIsrCnt = %d\n", s_ulPp1sIsrCnt);
    dbgInfo("       s_ulPp1sIsrOkCnt = %d\n", s_ulPp1sIsrOkCnt);
    dbgInfo("               ucGnssId = %d\n", tLocalGnssStas.ucGnssId);
    dbgInfo("          ucRcvWorkMode = %d\n", tLocalGnssStas.ucRcvWorkMode);
    dbgInfo("      ucGpsReceiverType = %d\n", tLocalGnssStas.ucGpsReceiverType);
    dbgInfo("   ucGpsReceiverVersion = %d\n", tLocalGnssStas.ucGpsReceiverVersion);
    dbgInfo("           ucGpsFixType = %d\n", tLocalGnssStas.ucGpsFixType);
    dbgInfo("        ucLockGpsSatNum = %d\n", tLocalGnssStas.ucLockGpsSatNum);
    dbgInfo("         ucLockBDSatNum = %d\n", tLocalGnssStas.ucLockBDSatNum);
    dbgInfo("        ucLockGnsSatNum = %d\n", tLocalGnssStas.ucLockGnsSatNum);
    dbgInfo("     ucGpsAntennaStatus = %d (1:OK,126:init,127:unkowned,128:short,129:open)\n", tLocalGnssStas.ucGpsAntennaStatus);
    dbgInfo("         ulAntLeapTimes = %d\n", tLocalGnssStas.ulAntLeapTimes);
    dbgInfo("ucGpsReceiverInitFinish = %d (0:Y,1:N)\n", tLocalGnssStas.ucGpsReceiverInitFinish);
    dbgInfo("        ucGpsInitStatus = %d\n", tLocalGnssStas.ucGpsInitStatus);
    dbgInfo("         ucLockSatState = %d (0:OK,1:searching,2:ERR,3,fakegps)\n", tLocalGnssStas.ucLockSatState);
    dbgInfo("           ucGpsUartErr = %d (0:OK,1:ERR)\n", tLocalGnssStas.ucGpsUartErr);
    dbgInfo("         ucSatLostTimes = %d\n", tLocalGnssStas.ulSatLostTimes);
    dbgInfo("           ulPhaseValue = %d\n", tLocalGnssStas.ulPhaseValue);
    dbgInfo("            ucFrameMode = %d (1:TDD,5:FDD,6:5G)\n", tLocalGnssStas.ucFrameMode);
    dbgInfo("             ullFrameNo = %lld\n", tLocalGnssStas.ullFrameNo);
    dbgInfo("             lLongitude = %.7f (centigrade)\n", (float)tLocalGnssStas.tPosition.lLongitude / 3600000);
    dbgInfo("              lLatitude = %.7f (centigrade)\n", (float)tLocalGnssStas.tPosition.lLatitude / 3600000);
    dbgInfo("              lAltitude = %.2f (metre)\n", (float)tLocalGnssStas.tPosition.lAltitude / 100);
    dbgInfo("          aucRcvGpsTime = ");
    for (i = 0; i < 12; i++)
    {
        dbgInfo("%02x ", tLocalGnssStas.aucRcvGpsTime[i]);
    }
    dbgInfo("\n          aucRcvUtcTime = ");
    for (i = 0; i < 12; i++)
    {
        dbgInfo("%02x ", tLocalGnssStas.aucRcvUtcTime[i]);
    }
    dbgInfo("\n           cLeapSeconds = %d\n\n", tLocalGnssStas.cLeapSeconds);

    dbgInfo("                Id Eleva Azimuth  Cno  Status(1Visible,2Locked)  SatType(1:GPS,2:GLONASS,3:BEIDOU,4:GALILEO)\n");
    for (i = 0; i < (GPS_SAT_INVIEW_MAX * 2); i++)
    {
        if(tLocalGnssStas.tSatDetails[i].ucSatType!=0 || i==0)
        {
            dbgInfo("       Sat %2d:  %3d   %3d   %3d   %3d   %3d   %3d\n", i,
                tLocalGnssStas.tSatDetails[i].ucSatId,
                tLocalGnssStas.tSatDetails[i].ucElevation,
                tLocalGnssStas.tSatDetails[i].usAzimuth,
                tLocalGnssStas.tSatDetails[i].usCno,
                tLocalGnssStas.tSatDetails[i].ucState,
                tLocalGnssStas.tSatDetails[i].ucSatType);
        }
    }

    ulRet |= BspGnssAlarmStatus(0,&tLocalGnssAlarm);
    dbgInfo("\n-------GNSS ALARM STATUS INFO: %X-----\n",ulRet);
    dbgInfo("      ucGpsUartErr = %d (0:OK,1:ERR)\n", tLocalGnssAlarm.ucGpsUartErr);
    dbgInfo("ucGpsAntennaStatus = %d (1:OK,126:init,127:unkowned,128:short,129:open)\n", tLocalGnssAlarm.ucGpsAntennaStatus);
    dbgInfo("    ucLockSatState = %d (0:OK,1:searching,2:ERR,3:FakeGps)\n", tLocalGnssAlarm.ucLockSatState);
    dbgInfo("         ucSatLost = %d (0:OK,1:ERR)\n", tLocalGnssAlarm.ucSatLost);
    dbgInfo("    ucRefPpsStatus = %d (0:OK,1:ERR)\n", tLocalGnssAlarm.ucRefPpsStatus);

    printf("---------------------------------\n\n");
    printf("AAU Send Tod Frame Cnt = %d\n",BspGetGnssSendCount(radioMode));
    return ulRet;
}

ULONG BspGpsPortTest(VOID)
{

    ULONG ulRet = BSP_ERROR;

    if (g_tGcmUartSwBuf.ulRcvId == UBLOX_Receiver)
       {
        dbgPrn("Gps Test Success!!!\n");
        ulRet = BSP_OK;
    }

    return ulRet;
}

ULONG BspGetGpsLockState(VOID)
{
    if (g_IntRcvDrvData == NULL)
    {
        return BSP_ERROR;
    }

    return g_IntRcvDrvData->ulLockSatState;
}
ULONG InnerProtectPp1s(VOID)
{
    /* 如果PP1s中断还没有来, 直接退出 */
    if (g_ulProtectTimes == 0xFFFFFFFF || g_IntRcvDrvData->ulRefConfigFlag == 0)
    {
        return BSP_ERROR;
    }

    g_ulProtectTimes++;

    if (g_ulProtectTimes >= 55)
    {
        dbgPrn("PP1s Int Lost!!! Time[%d]\n", tickGet());
        g_ulProtectTimes -= 50;
        ClockIncrementTime(&gtSatLocalTod);
        semGive(g_GpsIntSem);
    }

    return BSP_OK;
}

ULONG BspPp1sProtectModule(VOID)
{
    return BSP_OK;
}

ULONG BspGetGpsLinkState(VOID)
{
    UINT32 ulLoop = 0;
    UINT32 AvlSatCmt = 0;


    for(ulLoop  = 0; ulLoop < MAX_SAT_TYPE; ulLoop++)
    {
        AvlSatCmt += g_IntRcvDrvData->ulAvlSatCnt[ulLoop];
    }

    if ((AvlSatCmt > 0) && (g_IntRcvDrvData->ulRcvAntennaState == GPS_ANTENNA_STATE_OK))
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}


/**********************************************************************
* 函数名称：BspGetGnssId
* 功能描述：获取GNSSID
* 输入参数：
* 输出参数：无
* 返 回 值：GNSSID值 0xFF为无效ID,其他为有效ID
* 其它说明：
* 修改日期   版本号 修改人 修改内容
* -----------------------------------------------
*  $0000000(N/A),zhaoyun@2017-05-16 16:30 create
***********************************************************************/
ULONG BspGetGnssId(UINT32 radioMode)
{
    if (g_IntRcvDrvData == NULL)
    {
        return 0xFF;
    }

    return g_IntRcvDrvData->ucGnssId;
}

/**********************************************************************
* 函数名称：BspSetGpsPrintFlag
* 功能描述：修改BspConfigGnss接口中的打印开关
* 输入参数：ucValue   非0  打开打印
                      0    关闭
* 输出参数：无
* 返 回 值：无
* 其它说明：
* 修改日期   版本号 修改人 修改内容
* -----------------------------------------------
* 2014/10/20 V1.0    yam    create
***********************************************************************/
ULONG BspSetGpsPrintFlag(UCHAR ucValue)
{
    g_ucGnssCfgPrint = ucValue;
    return BSP_OK;
}

/*BSP测试函数，调用BspConfigGnss扫描GPS*/
ULONG BspConfigGnssForDwg(UINT32 radioMode, UCHAR ucGnssId, UCHAR workMode, ULONG timeMode)
{
    T_GNSS_PARA_CFG tLocalGnssPara = {0};
    memset(&tLocalGnssPara, 0, sizeof(tLocalGnssPara));

    tLocalGnssPara.ucGnssId = ucGnssId;
    tLocalGnssPara.ucGnssWorkMode = workMode;
    tLocalGnssPara.ulTimeMode = timeMode;
    tLocalGnssPara.ulLeastSatNum = 4;

    return BspConfigGnss(radioMode, &tLocalGnssPara);

    //BspGpsModuleInit();
}

#if 0
g_tGnssInfo.ucRackNo        = 51
g_tGnssInfo.ucGnssID        = 0
g_tGnssInfo.ucWorkMode      = 1
g_tGnssInfo.dwAntCabDelay   = 8000
g_tGnssInfo.dwRecvTimeMode  = 1
g_tGnssInfo.dwLongitude     = 180000000
g_tGnssInfo.dwLatitude      = 90000000
g_tGnssInfo.dwAltitude      = 0
g_tGnssInfo.dwSatAlarmLevel = 4
#endif

ULONG BspConfigGnssForDbg(UINT32 rm, UCHAR wr,ULONG cb,ULONG tm,ULONG lo,ULONG la,ULONG al)
{
    T_GNSS_PARA_CFG tLocalGnssPara = {0};
    memset(&tLocalGnssPara, 0, sizeof(tLocalGnssPara));

    tLocalGnssPara.ucGnssId = 0;

    tLocalGnssPara.ucGnssWorkMode = wr;
    tLocalGnssPara.ulLeastSatNum = 4;

    tLocalGnssPara.dLongitude = lo;
    tLocalGnssPara.dLatitude = la;
    tLocalGnssPara.dAltitude = al;

    tLocalGnssPara.ulTimeMode = tm;

    tLocalGnssPara.lAntCabDelay = cb;


    return BspConfigGnss(rm, &tLocalGnssPara);

    //BspGpsModuleInit();
}

/******************************************************************************
 * 函数名称: BspRegisterGnssCallback(*)
 * 功能描述: 报文传输回调函数注册
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * ---------------------------------------------------------------------------
 * 修改日期         修改人    修改内容
 * 2015年05月29日   罗焕发    创建
 * ---------------------------------------------------------------------------
 */
UINT32 BspRegisterGnssCallback(UINT32 index, UINT32 radioMode, FUNC_BUF_CTRL pFunc)
{
    T_GnssParaInfo *pInfo = BspGetGnssParaInfo(radioMode);
    INPUT_POINTER_CHECK(pFunc);
    switch (radioMode)
    {
        case BSP_RADIO_STANDARD_LTE_TDD:
            pFuncGnssCallBack = pFunc;
            break;
        case RADIO_STANDARD_5G:
            pFuncGnssOfEcpriCallBack = pFunc;
            break;
        default:
            pFuncGnssCallBack = pFunc;
            break;
    }
    if (pInfo)
    {
        pInfo->pSendToBbu = pFunc;
    }
    dbgInfo("%s radioMode=%#x pFunc=%p pInfo=%p\n",__FUNCTION__,radioMode,pFunc,pInfo);
    return BSP_OK;
}

ULONG BspGnssGpsGetFpgaId(VOID)
{
    ULONG ulRetFpgaId = 0;

    if (NULL == pFuncGpsGetFpgaId)
    {
        ulRetFpgaId = 0; /* 默认 */
    }
    else
    {
        ulRetFpgaId = pFuncGpsGetFpgaId();
    }

    return ulRetFpgaId;
}

/**************************************************************************
 * 函数名称: _BspDisablePp1sInt(*)
 * 功能描述: 去使能pp1s中断使能
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年04月30日 尧小安00109169    创建
 **************************************************************************/
UINT32 _BspDisablePp1sInt(VOID)
{
    _BspGpsDisablePp1sInt();
    return BSP_OK;
}

UINT32 BspGspSel8TCallback(FUNC_GPS_SEL_8T pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pGpsGetSel8tFunc = pFunc;
    return BSP_OK;
}

/******************************************************************************
 * 函数名称: BspGpsIntModeCfgCallback(*)
 * 功能描述: GPS 中断触发模式配置
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * ---------------------------------------------------------------------------
 * 修改日期         修改人    修改内容
 * 2015年05月29日   罗焕发    创建
 * ---------------------------------------------------------------------------
 */
UINT32 BspGpsIntModeCfgCallback(UINT32 index, FUNC_GPS_INT_MODE_CFG pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pGpsIntModeCfgCallBack = pFunc;
    return BSP_OK;
}

/******************************************************************************
 * 函数名称: BspGpsLocalClkStaCallback(*)
 * 功能描述: 获取本地时钟同步状态。
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * ---------------------------------------------------------------------------
 * 修改日期         修改人    修改内容
 * 2015年05月29日   罗焕发    创建
 * ---------------------------------------------------------------------------
 */
UINT32 BspGpsLocalClkStaCallback(UINT32 index, FUNC_GPS_LOCAL_CLK_STA pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pFuncGpsLocalClkStatus= pFunc;
    return BSP_OK;
}

UINT32 BspGpsGetFpgaIdCallback(UINT32 index, FUNC_GPS_GET_FPGA_ID pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pFuncGpsGetFpgaId = pFunc;

    return BSP_OK;
}

UINT32 BspUpdateGnssRadioMode(VOID)
{
    UINT32 loop;
    UINT32 phyOpt;
    UINT32 radioMode;
    UINT32 cfgCnt = 0;
    UINT32 cfgIndex = 0;
    UINT32 cfgFound = 0;
    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        GNSS_CFG_VALID_CHK_CON(s_gnssParaInfo[loop].valid);
        if ((s_gnssParaInfo[loop].cfg.ulRadioMode==(BSP_RADIO_STANDARD_LTE_TDD|BSP_RADIO_STANDARD_5G))||(s_gnssParaInfo[loop].cfg.ulRadioMode==(BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_5G)))
        {
            cfgIndex = loop;
            cfgFound = 1;
        }
        cfgCnt++;
    }
    if (cfgCnt != 1)
    {
        GPS_LOG(GPS_DBG_UBX_DRV, "valid cfg cnt %d\n",cfgCnt);
        return BSP_OK;
    }

    if (cfgFound == 1 && s_GnssBoardInfo.pGetOptRadio)
    {
        phyOpt = BspGetCurrFiberPort();
        radioMode = s_GnssBoardInfo.pGetOptRadio(phyOpt);
        if (radioMode != BSP_ERROR)
        {
            s_gnssParaInfo[cfgIndex].radioMode = radioMode;
        }
        GPS_LOG(GPS_DBG_UBX_DRV, "index=%d phyOpt=%d optRadio=%#x radioMode=%#x\n",
            cfgIndex,phyOpt,radioMode,s_gnssParaInfo[cfgIndex].radioMode);
    }

    return BSP_OK;
}

UINT32 BspGetGpsFrameMode(UINT32 radioMode)
{
    UINT32 frameMode = 0;

    if (NULL != pGpsGetSel8tFunc)
    {
        return GPS_FRAME_MODE_TDD;
    }
    GNSS_REGISTER_FUNC_RUN(pGetFrameMode, radioMode);

    /* 制造制式类型异常，异常时，正常返回FDD异常返回TDD，正常返回5G异常返回TDD，正常返回TDD异常返回FDD，恢复时按照正常流程 */
    if ((radioMode == BSP_RADIO_STANDARD_LTE_FDD ) || (radioMode == BSP_RADIO_STANDARD_5G_RESERVED))
    {
        frameMode = (GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_FRAME_MODE_ERR)) ? GPS_FRAME_MODE_TDD:GPS_FRAME_MODE_FDD;
    }
    else if(radioMode == BSP_RADIO_STANDARD_5G)
    {
        frameMode = (GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_FRAME_MODE_ERR)) ? GPS_FRAME_MODE_TDD:GPS_FRAME_MODE_5G;
    }
    else
    {
        frameMode = (GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_FRAME_MODE_ERR)) ? GPS_FRAME_MODE_FDD:GPS_FRAME_MODE_TDD;
    }
    return frameMode;
}

ULONG BspGetLocalClkStatus(UINT32 radioMode)
{
    ULONG ulRet = BSP_OK;

    GNSS_REGISTER_FUNC_RUN(pGetClkStatus, radioMode);
    if(NULL != pFuncGpsLocalClkStatus)
    {
        ulRet = pFuncGpsLocalClkStatus();
    }

    return ulRet;
}

UINT32 BspGpsUartBaudRateCallback(UINT32 index, FUNC_GPS_UART_BAUDRATE pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pFuncGpsUartBaudRateCallBack = pFunc;
    return BSP_OK;
}

UINT32 BspGpsUartInitCallback(UINT32 index, FUNC_GPS_UART_INIT pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pFuncGpsUartInitCallBack = pFunc;
    return BSP_OK;
}
UINT32 BspGpsSetRefCallback(UINT32 index, FUNC_GPS_SET_REF pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pFuncGpsSetRefCallBack = pFunc;
    return BSP_OK;
}
UINT32 BspGps1ppsSourceCallback(UINT32 index, FUNC_GPS_1PPS_SOURCE pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pFuncGps1ppsSourceCallBack = pFunc;
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
void gnsscfg()
{
    UINT32 loop;
    T_GnssParaInfo *pInfo;
    dbgInfo("index radioMode  sendCnt pSendToBbu gnsscfg\n");
    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        pInfo = &s_gnssParaInfo[loop];
        GNSS_CFG_VALID_CHK_CON(pInfo->valid);
        dbgInfo("%-5d 0x%-8x %-7d %p {%d,%d,%d,%d,%d,%d,%.2f,%.2f,%.2f,%d,%#x,%d,%d}\n",
            loop,pInfo->radioMode,pInfo->sendCnt,pInfo->pSendToBbu,
            pInfo->cfg.ucRackNo,pInfo->cfg.ucGnssId,
            pInfo->cfg.ucGnssWorkMode,pInfo->cfg.ucResv,pInfo->cfg.lAntCabDelay,
            pInfo->cfg.ulTimeMode,pInfo->cfg.dLongitude,pInfo->cfg.dLatitude,
            pInfo->cfg.dAltitude,pInfo->cfg.ulLeastSatNum,pInfo->cfg.ulRadioMode,
            pInfo->cfg.ulAlmReportThre,pInfo->cfg.ulAlmRecoverThre);
    }
}
#endif

static UINT32 GetGnssCfgRadioMode(UINT32 radio)
{
    struct
    {
        UINT32 inRadio;
        UINT32 outRadio;
    } radioGroup[] =
    {
        {BSP_RADIO_STANDARD_LTE_TDD, BSP_RADIO_STANDARD_LTE_TDD},
        {BSP_RADIO_STANDARD_5G,      BSP_RADIO_STANDARD_5G},
        {BSP_RADIO_STANDARD_LTE_TDD|BSP_RADIO_STANDARD_5G, BSP_RADIO_STANDARD_5G},
        {BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_5G, BSP_RADIO_STANDARD_5G},
        {BSP_RADIO_STANDARD_LTE_FDD, BSP_RADIO_STANDARD_5G},
        {BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_UMTS, BSP_RADIO_STANDARD_5G},
        {BSP_RADIO_STANDARD_LTE_FDD|BSP_RADIO_STANDARD_UMTS|BSP_RADIO_STANDARD_5G, BSP_RADIO_STANDARD_5G},
        {BSP_RADIO_STANDARD_UMTS|BSP_RADIO_STANDARD_5G, BSP_RADIO_STANDARD_5G},
        {BSP_RADIO_STANDARD_UMTS, BSP_RADIO_STANDARD_5G},
    };
    UINT32 loop;
    UINT32 radioMode = BspGetRadioStandard();

    for (loop = 0; loop < NELEMENTS(radioGroup); loop++)
    {
        if (radio == radioGroup[loop].inRadio)
        {
            return radioGroup[loop].outRadio;
        }
    }

    for (loop = 0; loop < NELEMENTS(radioGroup); loop++)
    {
        if (radioMode == radioGroup[loop].inRadio)
        {
            return radioGroup[loop].outRadio;
        }
    }

    return radioMode;
}

T_GnssParaInfo *BspGetGnssParaInfo(UINT32 radioMode)
{
    UINT32 loop;

    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        GNSS_CFG_VALID_CHK_CON(s_gnssParaInfo[loop].valid);
        if (radioMode == s_gnssParaInfo[loop].cfg.ulRadioMode)
        {
            return &s_gnssParaInfo[loop];
        }
    }
    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        GNSS_CFG_VALID_CHK_CON(s_gnssParaInfo[loop].valid);
        if (radioMode == s_gnssParaInfo[loop].radioMode)
        {
            return &s_gnssParaInfo[loop];
        }
    }
    return NULL;
}

T_GNSS_PARA_CFG * BspGetGnssCfgPara(UINT32 radioMode)
{
    /* UINT32 loop; */
    T_GnssParaInfo *pInfo = BspGetGnssParaInfo(radioMode);
    if (pInfo == NULL)
    {
        return NULL;
    }
    return &pInfo->cfg;
}

UINT32 _BspGetPhaseStatus(UINT32 radioMode)
{
    UINT32 phaseFinish = 0;
    UINT32 phaseNormal = 0;
    UINT32 bbFpgaId = 0;
    UINT32 fpgaChan = 0;
    UINT32 phyOpt   = 0;

    GNSS_REGISTER_FUNC_RUN(pGetPhaseStatus, radioMode);

    if(BSP_RADIO_STANDARD_LTE_TDD == BspGetRadioStandard() || BSP_RADIO_STANDARD_LTE_FDD == BspGetRadioStandard())
    {
        phyOpt = BspGetCurrFiberPort();
        BspGetFpgaIdxByPhyOpt(phyOpt, &bbFpgaId, &fpgaChan,E_FPGA_TYPE_OPT);
        BspRegRd(bbFpgaId, REG_FPGA_LTE_RGPS_PHASE_IND, 0, &phaseFinish);
        if(0x1 != phaseFinish)
        {
            //--dbgErr("%s>>frame_fn_gps not Finish\n",__FUNCTION__);
            return BSP_ERROR;
        }

        BspRegRd(bbFpgaId, REG_FPGA_LTE_RGPS_FULL_FLAG, 0, &phaseNormal);
        if(0 != phaseNormal)
        {
            GPS_LOG(GPS_DBG_INIT_PRN, "phase_counter overflow\n");
            return BSP_ERROR;
        }
    }
    else
    {
        BspRegRd(0, REG_FPGA_NR_RGPS_PHASE_IND, 0, &phaseFinish);
        if(0x1 != phaseFinish)
        {
            //--dbgErr("%s>>frame_fn_gps not Finish\n",__FUNCTION__);
            return BSP_ERROR;
        }

        BspRegRd(0, REG_FPGA_NR_RGPS_FULL_FLAG, 0, &phaseNormal);
        if(0 != phaseNormal)
        {
            GPS_LOG(GPS_DBG_INIT_PRN, "phase_counter overflow\n");
            return BSP_ERROR;
        }
    }
    return BSP_OK;
}

/**************************************************************************
* 函数名称: GetGnssUseableFlag
* 功能描述: 获取GNSS状态是否可用
* 输入参数: 无
* 输出参数: 无
* 返 回 值: TRUE 可用
*           FLASE 不可用
* 其它说明: 无
* -------------------------------------------------------------------------
* 修改日期      版本号      修改人      修改内容
* 2017-11-23     V1.0       刘骏儒      创建
***************************************************************************/
BOOL GetGnssUseableFlag(void)
{
    if(NULL == g_IntRcvDrvData)
    {
        return FALSE;
    }
    if(CLOCK_REF_USEABLE == g_IntRcvDrvData->ulRcvUseableFlag)
    {
        return TRUE;
    }
    return FALSE;
}

VOID _SyncRcvTodToSatTod(VOID)
{
    /* 该接口挂接到中断中，去掉打印 */
    sulSatTodTAsyncTimes = (sulSatTodTAsyncTimes+1)%50;
    if((sulSatTodTAsyncTimes%10)==0)
    {
        if (g_RcvDrvData->ulRcvMsgStas==1)
        {
            /* 计数变量清零 */
            sulSatTodTAsyncTimes = 0;
            gulSatSyncTodToLocalTimes++;

            /* 同步驱动tod到框架维护tod */
            memmove(&gtSatLocalTod, &(g_RcvDrvData->tGpsDate), sizeof(g_RcvDrvData->tGpsDate));
            /* 曾经同步驱动tod到框架维护tod标志,同时也是上报给上层tod是否可用的标志，0：不可用，1：可用 */
            sulSyncRcvTodFlag = 1;
        }
        if(sulSatTodTAsyncTimes==0)
        {
            sulSyncRcvTodFlag = 0;
        }
    }
    else
    {
        sulSyncRcvTodFlag = 0;
    }

}

UINT32 BspGetGnssValidNum(VOID)
{
    UINT32 loop;
    UINT32 num = 0;
    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        GNSS_CFG_VALID_CHK_CON(s_gnssParaInfo[loop].valid);
        if (IS_GNSS_ID_VALID(s_gnssParaInfo[loop].cfg.ucGnssId))
        {
            num++;
        }
    }
    return num;
}

UINT32 BspSetGnssCfgPara(T_GNSS_PARA_CFG *pCfg)
{
    UINT32 loop;
    UINT32 index = BSP_ERROR;
    T_GnssParaInfo *pInfo = NULL;

    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        pInfo = &s_gnssParaInfo[loop];
        if (pInfo->valid != GNSS_CFG_VALID_ID)
        {
            if (index == BSP_ERROR)
            {
                index = loop;
            }
            continue;
        }

        if (pCfg->ulRadioMode == pInfo->cfg.ulRadioMode)
        {
            if (IS_GNSS_ID_VALID(pCfg->ucGnssId))
            {
                pInfo->sendCnt = 0;
                memmove(&pInfo->cfg,pCfg,sizeof(T_GNSS_PARA_CFG));
            }
            else
            {
                pInfo->sendCnt = 0;
                pInfo->valid = 0;
            }

            return BSP_OK;
        }
    }
    if (index != BSP_ERROR)
    {
        pInfo = &s_gnssParaInfo[index];
        memmove(&pInfo->cfg,pCfg,sizeof(T_GNSS_PARA_CFG));
        pInfo->radioMode = GetGnssCfgRadioMode(pCfg->ulRadioMode);
        pInfo->sendCnt = 0;
        pInfo->valid = GNSS_CFG_VALID_ID;
        return BSP_OK;
    }
    return BSP_OK;
}

UINT32 SetGnssAlmTime(VOID)
{
    UINT32 almReportThre = 0;
    UINT32 almRecoverThre = 0;
    UINT32 retVal = 0;

    retVal = BspGetGnssAlmTime(&almReportThre,&almRecoverThre);
    if (BSP_OK != retVal)
    {
        dbgErr("%s almReportThre=%d almRecoverThre=%d\n",__FUNCTION__,almReportThre,almRecoverThre);
    }
    else
    {
        dbgInfo("%s almReportThre=%d almRecoverThre=%d\n",__FUNCTION__,almReportThre,almRecoverThre);
    }

    BspSetUbloxAlmThre(almReportThre, almRecoverThre);
    return BSP_OK;
}

UINT32 BspGetFlashGpsTimeStamp(VOID)
{
    UINT32 ulGpsTimeStamp = 1227657600; /* 2018-12-01 00:00:00 的TOD秒数 */
    char ucTimeStamp[12] = {0};
    /* UINT32 ulSize = 0; */
    INT32 lFpfRet = 0;
    FILE *fp = NULL;
    if(NULL == fp)
    {
        if(NULL == (fp = fopen(GPS_TIMESTAMP_FILE, "r+")))
        {
            dbgErr("%s open %s Fail,use value of default %d.\n", __FUNCTION__, GPS_TIMESTAMP_FILE, ulGpsTimeStamp);
            return ulGpsTimeStamp;
        }
    }

    while(zte_fgets_s(ucTimeStamp, sizeof(ucTimeStamp),sizeof(ucTimeStamp), fp) == 0)
    {
        ulGpsTimeStamp = (UINT32)strtoul(ucTimeStamp, NULL, 10);
        STRTOUL_CHECK(((unsigned long)ulGpsTimeStamp));
    }

    lFpfRet = fclose(fp);
    FCLOSE_CHECK(lFpfRet);

    return ntohl(ulGpsTimeStamp);
}

UINT32 BspSetFlashGpsTimeStamp(UINT32 ulGpsTimeStamp)
{
    UINT32 ulTimeStamp = 1227657600;
    /* UINT8 ucTimeStamp[12] = {0}; */
    /* UINT32 ulSize = 0; */
    INT32 lFpfRet = 0;
    FILE *fp = NULL;

    if(ulTimeStamp < ulGpsTimeStamp)
    {
        ulTimeStamp = ulGpsTimeStamp;
    }

    if(NULL == fp)
    {
        if(NULL == (fp = fopen(GPS_TIMESTAMP_FILE, "w+b")))
        {
            return BSP_ERROR;
        }
    }

    ulTimeStamp = htonl(ulTimeStamp);

    lFpfRet = fprintf_s(fp, "%u", ulTimeStamp);
    FPRINTF_CHECK(lFpfRet);

    lFpfRet = fclose(fp);
    FCLOSE_CHECK(lFpfRet);

    return BSP_OK;
}

/*关闭Rpgs初始化多余的任务，仅提供搜星测试时使用*/
UINT32 BspCtrlRgpsInitTask(VOID)
{
    if(s_RgpsDevInitCtrlFlag)
    {
        dbgInfo("RgpsDevInitCtrlFlag is True,it will be Switch on False!\n");
        s_RgpsDevInitCtrlFlag = FALSE;
    }
    else
    {
        dbgInfo("RgpsDevInitCtrlFlag is False,it will be Switch on True!\n");
        s_RgpsDevInitCtrlFlag = TRUE;
    }

    return BSP_OK;
}

UINT32 BspGetGnssAlmTime(UINT32 *pReportTime,UINT32 *pRecoverTime)
{
    UINT32 loop;

    INPUT_POINTER_CHECK(pReportTime);
    INPUT_POINTER_CHECK(pRecoverTime);

    for (loop = 0; loop < NELEMENTS(s_gnssParaInfo); loop++)
    {
        GNSS_CFG_VALID_CHK_CON(s_gnssParaInfo[loop].valid);
        if (s_gnssParaInfo[loop].cfg.ulAlmReportThre != 0 ||
            s_gnssParaInfo[loop].cfg.ulAlmRecoverThre != 0)
        {
            *pReportTime = s_gnssParaInfo[loop].cfg.ulAlmReportThre;
            *pRecoverTime= s_gnssParaInfo[loop].cfg.ulAlmRecoverThre;
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}

UINT32 BspGetPp1sOffsetType(UINT32 radioMode)
{
    if (NULL != pGpsGetSel8tFunc)
    {
        return PP1S_OFFSET_TYPE_10MS;
    }
    GNSS_REGISTER_FUNC_RUN(pGetPp1sOffsetType, radioMode);

    /* 制造鉴相类型异常:
    正常返回PP1S_OFFSET_TYPE_10MS,异常返回PP1S_OFFSET_TYPE_1588，
    正常返回PP1S_OFFSET_TYPE_1588,异常返回PP1S_OFFSET_TYPE_10MS；
    恢复时按照正常流程 */
    if ((radioMode == BSP_RADIO_STANDARD_LTE_FDD ) || (radioMode == BSP_RADIO_STANDARD_5G_RESERVED))
    {
        return (GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_TACC_ERR)) ? PP1S_OFFSET_TYPE_1588:PP1S_OFFSET_TYPE_10MS;
    }
    else if (radioMode == BSP_RADIO_STANDARD_5G)
    {
        return (GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_TACC_ERR)) ? PP1S_OFFSET_TYPE_10MS:PP1S_OFFSET_TYPE_1588;
    }
    else
    {
        return (GPS_NORMAL_STATUS != BspGetRgpsAbnormalStatus(GPS_TACC_ERR)) ? PP1S_OFFSET_TYPE_1588:PP1S_OFFSET_TYPE_10MS;
    }
}

UINT32 BspGetGnssSendCount(UINT32 radioMode)
{
    /* UINT32 loop; */
    T_GnssParaInfo *pInfo = BspGetGnssParaInfo(radioMode);
    if (pInfo == NULL)
    {
        return BSP_ERROR;
    }
    return pInfo->sendCnt;
}

#ifdef BUILD_WITH_OM_FUNC
VOID gps(UINT32 radioMode)
{
    ShowGnssStatus(radioMode);
}
#endif

UINT32 logInitSta = BSP_ERROR;

UINT32 BspSetGnssLogSize(UINT32 maxSize)
{
    gnssLogSize = maxSize;
    return BSP_OK;
}

UINT32 BspGnssLogInit(VOID)
{
    INT32 fclsRet = 0;

    if (logInitSta == BSP_OK)
    {
        return BSP_OK;
    }
    recordSem = semBCreate(SEM_Q_FIFO, SEM_FULL);
    if (recordSem == NULL)
    {
        return BSP_ERROR;
    }

    gnssFp = fopen("/gnsslog.txt","w+");
    if (gnssFp == NULL)
    {
        dbgErr("%s fopen failed\n", __FUNCTION__);
        return BSP_ERROR;
    }

    logList = (T_LogList *)malloc(sizeof(T_LogList));
    if (logList == NULL)
    {
        dbgErr("%s>>malloc1 error\n", __FUNCTION__);
        fclsRet = fclose(gnssFp);
        FCLOSE_CHECK(fclsRet);
        return BSP_ERROR;
    }
    memset(logList, 0,sizeof(T_LogList));
    memset(&tgnsssndInfo, 0,sizeof(T_GnssSndInfo));
    logInitSta  = BSP_OK;
    return BSP_OK;
}

FILE *BspGetGnssLogFp(VOID)
{
    UINT32 size = 0;

    if (gnssFp == NULL)
    {
        return NULL;
    }
    size = ftell(gnssFp);
    if (size > (gnssLogSize-2*GNSS_LOG_LINE_SIZE))
    {
        rewind(gnssFp);
    }
    size = ftell(gnssFp);
    if (size > (gnssLogSize-2*GNSS_LOG_LINE_SIZE))
    {
        return NULL;
    }
    return gnssFp;
}

UINT32 BspAddGnssLog(UINT32 type, char *pBuf, UINT32 len)
{
    INT32  snpRet    = 0;
    char   strTime[20] = {0};
    time_t timeRet   = 0;
    T_GnssLogRecord *ptTmp = NULL;
    T_GnssLogRecord *ptReC = NULL;

    if ((logList == NULL) || (logInitSta != BSP_OK))
    {
        return BSP_ERROR;
    }

    semTake(recordSem, WAIT_FOREVER);

    len = min(len, GNSS_LOG_LINE_SIZE);
    /* 当buff记录满100条，没被记录到log中，则在插入新节点前先删除老节点 */
    if ((logList->listNode == 100) && (logList->pHead != NULL))
    {
        ptReC = logList->pHead->next;
        free(logList->pHead);
        logList->pHead = ptReC;
        logList->listNode--;
    }

    ptTmp = (T_GnssLogRecord *)malloc(sizeof(T_GnssLogRecord));
    if (ptTmp == NULL)
    {
        semGive(recordSem);
        return BSP_ERROR;
    }
    memset(ptTmp,0, sizeof(T_GnssLogRecord));

    timeRet = time(NULL);
    TIME_CHECK(timeRet);
    BspSecondToDate(strTime, sizeof(strTime), timeRet,0);
    snpRet = snprintf_s((char *)(&ptTmp->date[0]),sizeof(ptTmp->date),"%s",strTime);
    SNPRINTF_S_CHECK(snpRet, sizeof(ptTmp->date));
    memcpy_s(&ptTmp->logData[0],GNSS_LOG_LINE_SIZE, pBuf, len);
    ptTmp->type = type;
    ptTmp->next = NULL;

    if (logList->pHead == NULL)
    {
        logList->pTail = ptTmp;
        logList->pHead = logList->pTail;
    }
    else
    {
        if (logList->pTail != NULL)
        {
            logList->pTail->next = ptTmp;
        }
    }
    logList->pTail = ptTmp;
    logList->listNode++;
    semGive(recordSem);
    return BSP_OK;
}

UINT8  gnssLastFrameNum1  = 0;
UINT32 gnssLastFrameNum2  = 0;

VOID BspGnssLogToFile(T_GnssLogRecord *ptTmp)
{
    UINT32 almVal = 0;
    INT32 fprtRet = 0;
    INT32 ffluRet = 0;
    FILE   *fp    = NULL;
    T_GnssSndInfo sndInfo              = {0};
    T_RRU_GNSS_FRAME tLocaFrame        = {0,};

    if (ptTmp == NULL)
    {
        return;
    }
    fp = BspGetGnssLogFp();
    if (fp == NULL)
    {
        return;
    }

    switch (ptTmp->type)
    {
        case GNSS_LOG_TYPE_CFG:
        {
            fprtRet = fprintf_s(fp,"<%s>[%s]%s\n", "cfg",ptTmp->date,ptTmp->logData);
            FPRINTF_CHECK(fprtRet);
            break;
        }
        case GNSS_LOG_TYPE_SNDMSG:
        {
            if (g_IntRcvDrvData == NULL)
            {
                break;
            }
            memcpy_s(&sndInfo, sizeof(T_GnssSndInfo), &(ptTmp->logData[0]), sizeof(T_GnssSndInfo));
            memcpy_s(&tLocaFrame, sizeof(T_RRU_GNSS_FRAME), &(ptTmp->logData[0])+sizeof(T_GnssSndInfo), sizeof(T_RRU_GNSS_FRAME));
            if (1 != tLocaFrame.tTimeFrame.tTimeInfo.ulReserved1)    /* tod状态异常 */
            {
                almVal = BIT_SET(0);
                fprtRet = fprintf_s(fp,"<%s>[%s]TOD lt:%d-%d-%d|%d:%d:%d,rt:%d-%d-%d|%d:%d:%d,pp1sIntCnt(pro):%d(%d),"
                    "initSta:%d,rcvTodOkCnt:%d,rcvMsgSta:%d\n","snd",ptTmp->date,sndInfo.tod[0].YEAR,
                    sndInfo.tod[0].MON,sndInfo.tod[0].DAY,sndInfo.tod[0].HOUR,sndInfo.tod[0].MIN,sndInfo.tod[0].SEC,
                    sndInfo.tod[1].YEAR,sndInfo.tod[1].MON,sndInfo.tod[1].DAY,sndInfo.tod[1].HOUR,sndInfo.tod[1].MIN,
                    sndInfo.tod[1].SEC,sndInfo.pp1sIntCnt,sndInfo.pp1sProCnt,sndInfo.initSta,sndInfo.rcvTodOkCnt,sndInfo.rcvMsgSta);
                FPRINTF_CHECK(fprtRet);
            }
            if (tLocaFrame.tTimeFrame.tTimeInfo.ucPpsStatus != 0)  /*秒脉冲不可用 */
            {
                almVal |= BIT_SET(1);
                fprtRet = fprintf_s(fp,"<%s>[%s]PP1S sta1588&newFlag:%#x,localRcvInfo:%#x\n",
                    "snd",ptTmp->date,sndInfo.ulClkStatus,sndInfo.localRcvInfo);
                FPRINTF_CHECK(fprtRet);
            }
            if ((gnssLastFrameNum2 == tLocaFrame.tStasFrame.tStateInfo.ulFrameNum2) &&
                (gnssLastFrameNum1 == tLocaFrame.tStasFrame.tStateInfo.ucFrameNum1))
            {
                almVal |= BIT_SET(2);
                fprtRet = fprintf_s(fp,"<%s>[%s]FRAME abnormal:%#x,%#x\n",
                    "snd",ptTmp->date,tLocaFrame.tStasFrame.tStateInfo.ucFrameNum1,tLocaFrame.tStasFrame.tStateInfo.ulFrameNum2);
                FPRINTF_CHECK(fprtRet);
            }

           // if (g_IntRcvDrvData != NULL) kw告警，删除
            {
                if(tLocaFrame.tTimeFrame.tTimeInfo.ucLockSatCnt < g_IntRcvDrvData->ulLeastSatNum)
                {
                    almVal |= BIT_SET(4);
                    fprtRet = fprintf_s(fp,"<%s>[%s]LOCKSATCNT:%#x,\n","snd",ptTmp->date,tLocaFrame.tTimeFrame.tTimeInfo.ucLockSatCnt);
                    FPRINTF_CHECK(fprtRet);
                }
            }
            if ((tLocaFrame.tStasFrame.tStateInfo.ulPp1sOffset < GNSS_PP1S_OFFSET_DIF) ||
                (((1000000000-tLocaFrame.tStasFrame.tStateInfo.ulPp1sOffset) <GNSS_PP1S_OFFSET_DIF) && (PP1S_OFFSET_TYPE_1588 == tLocaFrame.tTimeFrame.tTimeInfo.ucTacc)) ||
                (((10000000-tLocaFrame.tStasFrame.tStateInfo.ulPp1sOffset) < GNSS_PP1S_OFFSET_DIF) && (PP1S_OFFSET_TYPE_10MS == tLocaFrame.tTimeFrame.tTimeInfo.ucTacc)) )
            {

            }
            else
            {
                almVal |= BIT_SET(3);
                fprtRet = fprintf_s(fp,"<%s>[%s]PP1SOFFSET abnormal:%d\n", "snd",ptTmp->date,tLocaFrame.tStasFrame.tStateInfo.ulPp1sOffset);
                FPRINTF_CHECK(fprtRet);
            }
            if (almVal != 0)
            {
                fprtRet = fprintf_s(fp,"<%s>[%s]TIMEF:%#x-%#x, %#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x\n","snd",ptTmp->date,
                    tLocaFrame.tTimeFrame.tFrameHead.ucFrameSyncChar1,tLocaFrame.tTimeFrame.tFrameHead.ucFrameSyncChar2,
                    tLocaFrame.tTimeFrame.tTimeInfo.ucMsgHeadClass,tLocaFrame.tTimeFrame.tTimeInfo.ucMsgHeadId,tLocaFrame.tTimeFrame.tTimeInfo.usMsgLength,
                    tLocaFrame.tTimeFrame.tTimeInfo.ulGpsTow, tLocaFrame.tTimeFrame.tTimeInfo.ulReserved1,tLocaFrame.tTimeFrame.tTimeInfo.usGpsWeek,
                    tLocaFrame.tTimeFrame.tTimeInfo.cLeapS, tLocaFrame.tTimeFrame.tTimeInfo.ucPpsStatus,tLocaFrame.tTimeFrame.tTimeInfo.ucTacc,
                    tLocaFrame.tTimeFrame.tTimeInfo.ucGnssId,tLocaFrame.tTimeFrame.tTimeInfo.ucRackNo,tLocaFrame.tTimeFrame.tTimeInfo.ucLockSatCnt,
                    tLocaFrame.tTimeFrame.tTimeInfo.ucMsgCRC);
                FPRINTF_CHECK(fprtRet);
                fprtRet = fprintf_s(fp,"<%s>[%s]STATEF:%#x-%#x, %#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x-%#x\n","snd",ptTmp->date,
                    tLocaFrame.tStasFrame.tFrameHead.ucFrameSyncChar1,tLocaFrame.tStasFrame.tFrameHead.ucFrameSyncChar2,
                    tLocaFrame.tStasFrame.tStateInfo.ucMsgHeadClass,tLocaFrame.tStasFrame.tStateInfo.ucMsgHeadId,
                    tLocaFrame.tStasFrame.tStateInfo.usMsgLength,tLocaFrame.tStasFrame.tStateInfo.ucClkSrcType,
                    tLocaFrame.tStasFrame.tStateInfo.usClkSrcState,tLocaFrame.tStasFrame.tStateInfo.usClkSrcAlarm,
                    tLocaFrame.tStasFrame.tStateInfo.ucGnssId,tLocaFrame.tStasFrame.tStateInfo.ucFrameMode,
                    tLocaFrame.tStasFrame.tStateInfo.ucFrameNum1,tLocaFrame.tStasFrame.tStateInfo.ulFrameNum2,
                    tLocaFrame.tStasFrame.tStateInfo.ulPp1sOffset,tLocaFrame.tStasFrame.tStateInfo.ucMsgCRC,tLocaFrame.usRev);
                FPRINTF_CHECK(fprtRet);
            }
            break;
        }
        case GNSS_LOG_TYPE_ALARM:
        {
            fprtRet = fprintf_s(fp,"<%s>[%s]%s\n", "alm",ptTmp->date,ptTmp->logData);
            FPRINTF_CHECK(fprtRet);
            break;
        }
        case GNSS_LOG_TYPE_RST:
        {
            fprtRet = fprintf_s(fp,"<%s>[%s]%s\n", "rst",ptTmp->date,ptTmp->logData);
            FPRINTF_CHECK(fprtRet);
            break;
        }
        case GNSS_LOG_TYPE_INIT:
        {
            fprtRet = fprintf_s(fp,"<%s>[%s]%s\n", "int",ptTmp->date,ptTmp->logData);
            FPRINTF_CHECK(fprtRet);
            break;
        }
        default:
            break;
    }
    ffluRet = fflush(fp);
    FFLUSH_CHECK(ffluRet);
    return;
}

UINT32 BspRecordGnssLog(VOID)
{
    T_GnssLogRecord *ptTmp   = NULL;

    while (1)
    {
        BspSysMsDelay(8000);
        if ((logList == NULL))
        {
            continue;
        }
        while (logList->pHead != NULL)
        {
            semTake(recordSem, WAIT_FOREVER);
            ptTmp = logList->pHead;
            logList->pHead = logList->pHead->next;
            if (logList->pHead == NULL)
            {
                logList->pTail = NULL;
            }
            logList->listNode--;
            semGive(recordSem);
            BspGnssLogToFile(ptTmp);
            free(ptTmp);
            BspSysMsDelay(100);
        }
    }
    return BSP_OK;
}

/**************************************************************************

* 函数名称: BspClkFaultSet
* 功能描述: 单板时钟源异常制造接口函数
* 输入参数: uiRefID: 参考源ID；
          uiFaultNum：异常类型；
          usSetFlag: 1-制造异常，0-恢复异常
* 输出参数: 无
* 返 回 值: BSP_OK：成功；BSP_ERROR：失败；
*
* 其它说明:uiFaultNum：    异常类型
*            1          UART通讯异常
*            2           天馈开路
*            3           天馈短路
*            4           接收机重启
*            5           pp1s丢失
*            9           TOD不可用
*            10         秒脉冲不可用
*            11          鉴相值异常
*            13           搜星异常
*            31       AAU增加，制式类型错误
*            32       AAU增加，鉴相类型异常
* -------------------------------------------------------------------------
* 修改日期      版本号      修改人      修改内容
***************************************************************************/
UINT32 BspClkFaultSet(UINT32 uiRefID, UINT32 uiFaultNum, UINT32 iSetFlag)
{
    UINT64 gpsStatus = 0;
    const UINT32 bitMax = 64;
    static UINT32 invalidFlag = GPS_INVALID_FLAG;

    if(invalidFlag == GPS_INVALID_FLAG)
    {
        s_LeastSatNum = g_IntRcvDrvData->ulLeastSatNum;
        s_LeastSatNumBackup = g_IntRcvDrvData->ulLeastSatNumBackup;
        invalidFlag = 1;
    }
    if(uiFaultNum >= bitMax)
    {
        dbgErr("Input Parameter (uiFaultNum = %d) Out The Range.\n",uiFaultNum);
        return BSP_ERROR;
    }

    /* usSetFlag: 1-制造异常，0-恢复异常 */
    if(iSetFlag == GPS_NORMAL_STATUS)
    {
        gpsStatus = ~BIT64_SET(uiFaultNum);
        s_RgpsAbnormalStatus = s_RgpsAbnormalStatus & gpsStatus; /* 设置为恢复异常，对应bit位置0 */
    }
    else
    {
        gpsStatus = BIT64_SET(uiFaultNum);
        s_RgpsAbnormalStatus = s_RgpsAbnormalStatus | gpsStatus;  /* 设置为异常状态，对应bit位置1 */
    }

    switch(uiFaultNum)
    {
        case INT_GPS_RCV_RESTART:
        {
            if(iSetFlag != GPS_NORMAL_STATUS)
            {
                (void)UbloxRcvManualReset(1); /* 断电再初始化 */
            }
            break;
        }
        case GPS_SEARCH_SAT_ERR:
        {
            /* 制造搜星异常，将搜星数量门限设置成0XFF,恢复时设置成正常值 */
            if(iSetFlag == GPS_NORMAL_STATUS)
            {
                g_IntRcvDrvData->ulLeastSatNum = s_LeastSatNum;
                g_IntRcvDrvData->ulLeastSatNumBackup = s_LeastSatNumBackup;
            }
            else
            {
                g_IntRcvDrvData->ulLeastSatNum = 0XFF;
                g_IntRcvDrvData->ulLeastSatNumBackup = 0XFF;
            }
            break;
        }
        default:
            break;
    }
    return BSP_OK;
}

UINT32 BspGetRgpsAbnormalStatus(UINT32 abnormalType)
{
    UINT64 abnormalStatusMask = 0;
    const UINT32 bitMax = 64;

    if(abnormalType >= bitMax)
    {
        dbgErr("Input Parameter (abnormalType = %d) Out The Range.\n",abnormalType);
        return BSP_ERROR;
    }

    abnormalStatusMask = BIT64_SET(abnormalType);
    if((s_RgpsAbnormalStatus & abnormalStatusMask) == (UINT64)GPS_NORMAL_STATUS)
    {
        return GPS_NORMAL_STATUS;
    }

    return GPS_ABNORMAL_STATUS;
}

UINT32 BspSetClkFaultInit(VOID)
{
    s_RgpsAbnormalStatus = 0;
    return BSP_OK;
}

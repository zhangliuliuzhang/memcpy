/*********************************************************************
* 版权所有 (C)2006, 深圳市中兴通讯股份有限公司。
*
* 文件名称： UbloxReceiverDrv.h
* 文件标识：
* 内容摘要： Ublox接收机驱动模块公共头文件
* 其它说明：
* 当前版本：
* 作    者： 贾冉
* 完成日期： 2010-3-25
* 修改记录1：
*    修改日期：2010-3-25
*    版 本 号：
*    修 改 人：贾冉
*    修改内容：创建
**********************************************************************/
#ifndef _FUNCLIB_GNSS_UBLOX_COMMON_H_
#define _FUNCLIB_GNSS_UBLOX_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#define CLOCK_REF_NOT_INITIALIZED                 (0)
#define CLOCK_REF_UNUSEABLE                       (1)
#define CLOCK_REF_USEABLE                         (2)

#define SEC_OF_DAY         (3600 * 24)        /* 一天时间的秒数 */
#define SEC_OF_WEEK        (SEC_OF_DAY * 7)   /* 一天时间的秒数 */
#define PI                 (3.14159265359)    /* 圆周率 */
/* 接收机类型宏值定义 */
#define K161_Receiver      (6)
#define CRESCENT_Receiver  (7)
#define M12_Receiver       (2)
#define TRIMBLE_Receiver   (8)
#define UBLOX_Receiver     (9)
/* 后台诊断已有个俄罗斯GLONASS接收机为10 */
#define QUICK200_Receiver  (11)
#define SigNav_Receiver    (12)
#define BD_Receiver        (13) /* 支持中移动协议的光口RGPS */
#define PPS_TOD_Receiver   (14) /*没有实体接收机，仅为对应的宏值*/
#define RGCI_Receiver      (15) /* 自研RGPS */
#define TAIDOU_RECEIVER    (16)
#define VR_Receiver        (255)/* 虚拟接收机:只可收信息，不可以发 */

/****** 数学相关宏 ******/
#define	ARC_CONVERT 	57.295779                 /* 弧度转换成度数比例系数(180/PI) */
#define	LALO_CONVERT	(3600000.0*ARC_CONVERT)	  /* 经度纬度倍乘系数到整型数的转换 */
#define	HEIGT_CONVERT	100.0                     /* 高度倍乘系数到整型数的转换比例系数*/

/* 秒脉冲状态 */
#define PPS_STATUS_OK                              (0x00)
#define PPS_STATUS_ATOM_HOLD                       (0x01)
#define PPS_STATUS_NOT_OK                          (0x02)
#define PPS_STATUS_OSCILLATOR_HOLD                 (0x03)
#define PPS_STATUS_TRANSMISSION_HOLD               (0x04)

/****** GPS模块配置相关宏 ******/

/* 天馈状态 */
#define GPS_ANTENNA_STATE_OK         (1)
#define GPS_ANTENNA_STATE_INIT       (126)
#define GPS_ANTENNA_STATE_DONTKNOW   (127)
#define GPS_ANTENNA_STATE_SHORT      (128)
#define GPS_ANTENNA_STATE_BREAK      (129)

/* 接收机状态 */
#define SATELLITE_NOT_FIX                         (0)
#define SATELLITE_DEAD_RECKONING_ONLY             (1)
#define SATELLITE_GPS_AND_DEAD_RECKONING_COMBINED (2)
#define SATELLITE_2D_FIX                          (3)
#define SATELLITE_3D_FIX                          (4)
#define SATELLITE_TIME_ONLY_FIX                   (5)

/* 接收机授时模式 */
#define SATELLITE_AUTO_MODE                       (1)
#define SATELLITE_FIXED_MODE                      (2)
#define SATELLITE_SELF_CTRL_FIXED_MODE            (3)

/* 逻辑鉴相频率对应的单位 */
#define PPS_80M_PD_UNIT                           (12.5)
#define PPS_160M_PD_UNIT                          (6.25)

/* GPS接收机命令超时时间 */
#define GPS_CMD_TIME_OUT_IN_SEC     (sysClkRateGet() * 10)

/* UART缓冲区结构宏值 */
#define GCM_UART_QUEUE_SIZE          (1024)
#define USR_GCMSERIAL_OUTQUEUE_SIZE  (1024)
#define FPGA_UART_QUEUE_SIZE         (1024) /* fpga uart口相关缓存区大小 */
/* 卫星类名称长度 */
#define GPS_REF_DESC_LENTH           (16)

#define BSP_CLOCK_REF_INTERNAL_GPS                   1   /* 内置GPS */
#define BSP_CLOCK_REF_EXTERNAL_FRONT_SATELLITE       2   /* 外置面板卫星 */
#define BSP_CLOCK_REF_EXTERNAL_BACK_SATELLITE        3   /* 外置背板卫星 */
#define BSP_CLOCK_REF_1PPS_AND_TOD                   4   /* TD使用的一直源方式 */

#define BSP_CLOCK_REF_SLAVE_PANNEL                   5   /* 级联从框 */

#define BSP_CLOCK_REF_BITS_2MHz                      6   /* BITS-2MHz时钟 */
#define BSP_CLOCK_REF_BITS_2Mbps                     7   /* BITS-2Mbps时钟 */
#define BSP_CLOCK_REF_LINE                           8   /* 线路时钟-本板 */
#define BSP_CLOCK_REF_LINE_A                         9   /* 线路时钟-其他板 */

#define BSP_CLOCK_REF_1588_AND_SYNCE                 10   /* syncE+1588调相 */
#define BSP_CLOCK_REF_1588_FREQ_ONLY                 11   /* 传统网1588调频 */
#define BSP_CLOCK_REF_1588_PHASE                     12   /* 传统网1588调相 */

#define BSP_CLOCK_REF_SYNCE_CLK                      13  /* SyncE时钟 */

#define BSP_CLOCK_REF_1PPS_AND_TOD_BACKUP            14   /* 1PPS+TOD 备份 */

#define BSP_CLOCK_REF_FOR_SLAVE_BOARD                15   /* 背板备份时钟(目前暂用作背板1588) */

#define BSP_CLOCK_REF_BBUCASCADE_CLK                 16   /* 堆叠时钟 */

#define BSP_CLOCK_REF_RRU_GPS                        17   /* RRU GPS时钟 */

#define BSP_CLOCK_REF_DEFAULT                        25  /* 默认时钟源 */

#define BSP_CLOCK_QUALITY_ERR_GATE                   100 /* 参考源质量门限，达到或超出表示异常 */

#define  LEAST_LOCKED_SAT_NUM_FOR_OMIT_ANT_BREAK		2
#define  LEAST_SAT_LOCK_OK_TIME_IN_SEC                  60


#define UART_ERR_ALARM_LIMIT     	(30) /* uart异常告警门限 */
#define DUAL_RCV_UART_ERR_LIMIT     (60)    /* 双模接收机异常保护门限 */
#define RCV_UART_ERR_RST_LIMIT      (DUAL_RCV_UART_ERR_LIMIT + 10)


/* UBLOX接收机初始化状态 */
#define UBLOX_INIT_RESET               (0)
#define UBLOX_INIT_MON_VER             (1)
#define UBLOX_INIT_CLOSE_MSG           (2)
#define UBLOX_INIT_CFG_TP              (3)
#define UBLOX_INIT_CFG_ANT             (4)
#define UBLOX_INIT_MON_ANT             (5)
#define UBLOX_INIT_CFG_NAV             (6)
#define UBLOX_INIT_CFG_TMODE           (7)
#define UBLOX_INIT_CFG_MSG_NAV_SOL     (8)
#define UBLOX_INIT_CFG_MSG_NAV_POSLLH  (9)
#define UBLOX_INIT_CFG_MSG_NAV_TIMEGPS (10)
#define UBLOX_INIT_5T_CLOSE_MSG_GPGLL  (11)
#define UBLOX_INIT_5T_CFG_MSG_GPGSV    (12)
#define UBLOX_INIT_5T_CLOSE_MSG_GPRMC  (13)
#define UBLOX_INIT_5T_CLOSE_MSG_GPVTG  (14)
#define UBLOX_INIT_5T_CLOSE_MSG_GPZDA  (15)
#define UBLOX_INIT_5T_CFG_NAV5         (16)
#define UBLOX_INIT_5T_CFG_TP           (17)
#define UBLOX_INIT_5T_CFG_TMODE_QUERY  (18)
#define UBLOX_INIT_CFG_SBAS            (19)
#define UBLOX_INIT_5T_CFG_NAV5_MOV     (20)
#define UBLOX_INIT_CFG_TMODE_NOT_SURVEY_IN  (21)
#define UBLOX_INIT_POLL_MSG_AID_INI    (22)
#define UBLOX_INIT_POLL_MSG_AID_HUI    (23)
#define UBLOX_INIT_POLL_MSG_AID_EPH    (24)
#define UBLOX_INIT_SEND_MSG_AID_INI    (25)
#define UBLOX_INIT_SEND_MSG_AID_HUI    (26)
#define UBLOX_INIT_SEND_MSG_AID_EPH    (27)
#define UBLOX_INIT_POLL_MSG_AID_DATA   (28)
#define UBLOX_INIT_CFG_MSG_AID_EPH     (29)
#define UBLOX_INIT_CFG_MSG_AID_HUI     (30)
#define UBLOX_INIT_CFG_MSG_AID_INI     (31)
#define UBLOX_INIT_CFG_TP5             (32)
#define UBLOX_INIT_CFG_TMODE2          (33)
#define UBLOX_INIT_CFG_GNSS            (34)
#define UBLOX_INIT_CFG_TMODE2_QUERY    (35)
#define UBLOX_INIT_CFG_GNSS_QUERY      (36)
#define UBLOX_INIT_CFG_NMEA            (37)
#define UBLOX_INIT_POLL_CFG_TP         (38)
#define UBLOX_INIT_POLL_CFG_TP5        (39)
#define UBLOX_INIT_CFG_PRT             (40)
#define UBLOX_INIT_POLL_CFG_PRT        (41)
#define UBLOX_INIT_NUM                 (42)
#define UBLOX_INIT_NUM2                (51)

#define GNSS_CMD_MAX_LEN (128)
#define GNSS_CMD_MAX_NUM (64)

 /* UBLOX接收机版本号 */
#define UBLOX_VERSION_4T (4)
#define UBLOX_VERSION_5T (5)
#define UBLOX_VERSION_6T (6)
#define UBLOX_VERSION_8T (8)

/* 泰斗接收机版本 */
#define TD_VERSION_T302  (2)
#define TD_VERSION_T303  (9)
#define TD_VERSION_T302G (10)
#define TD_VERSION_T303G (11)

/* 用于判定是否为多模接收机 */
#define IS_MULTI_RCV(ucVersion)   ((UBLOX_VERSION_8T == (ucVersion))\
                                || (TD_VERSION_T302  == (ucVersion))\
                                || (TD_VERSION_T303  == (ucVersion)))

#define OUTER_GPS_RECEIVER      (1)
#define OUTER_BD_RECEIVER       (5)
#define OUTER_GPS_BD_RECEIVER   (6)
#define OUTER_GLO_RECEIVER      (3)
#define OUTER_GPS_GLO_RECEIVER  (4)


/* 可见卫星数上限，大于各卫星系统卫星数(最多的北斗规划35颗) */
#define GNSS_SAT_INVIEW_MAX  (36)
/* 锁定卫星数上限，以所有接收机中支持的最大数为准，目前为16 */
#define GNSS_SAT_INUSE_MAX   (16)
#define GPS_SAT_NUM          (GNSS_SAT_INUSE_MAX)
#define AGPS_UBX_AID_INI_LEN (56)
#define AGPS_UBX_AID_HUI_LEN (80)
#define AGPS_UBX_AID_EPH_LEN (112)
#define AGPS_RESERVED_BYTE   (376)

#define UBX_MSG_PAYLOAG_OFFSET  6   /* ubx消息payload之前的长度 */

/* 信噪比锁定阈值，单位DB */
#define GPS_SAT_LOCK_SN_THRESHOLD      (10)
#define RGCI_SAT_LOCK_SN_THRESHOLD       (10)
/* 锁定卫星通道数 */
#define NUM_OF_UBLOX_LOCK_SAT_CHANNEL  (12)

#define CLOCK_REF_NOT_INITIALIZED                 (0)
#define CLOCK_REF_UNUSEABLE                       (1)
#define CLOCK_REF_USEABLE                         (2)
#define OCXO_WARM_UP_TIME (300) /* 晶体预热时间 */

#define UBX_CFG_TP_QUERY 0
#define UBX_CFG_TP_SET   1
#define UBX_ANT_CABLE_DELAY_GET 2

/* UBLOX接收机小端格式 -> 数值 */
#define UBLOX_ULONG(buf)   (((ULONG)(buf)[3] << 24) | ((ULONG)(buf)[2] << 16) | \
                            ((ULONG)(buf)[1] << 8)  | ((ULONG)(buf)[0] << 0))

#define UBLOX_LONG(buf)    ((LONG)UBLOX_ULONG(buf))

#define UBLOX_USHORT(buf)  (((USHORT)(buf)[1] << 8) | ((USHORT)(buf)[0] << 0))

#define UBLOX_SHORT(buf)   ((SHORT)UBLOX_USHORT(buf))


/* NMEA帧语句最大长度值 */
/* NMEA 0183 messages vary in length, but each message is limited to max 79
characters between the starting delimiter "$" and the terminating <CR><LF> */
#define NMEA_FRAME_MAX_LIMIT    (82)

/* TD-SDBP帧长度限制 */
#define TD_SDBP_FRAME_MAX_LENTH    (1024)
#define TD_SDBP_FRAME_MIN_LENTH    (10)

#define UBX_CFG_TP_IDX              0
#define UBX_POLL_TP_IDX             1
#define UBX_CFG_TMODE_IDX           2
#define UBX_CFG_TMODE_QUERY_IDX     3
#define UBX_CFG_DATA_MAX            (UBX_CFG_TMODE_QUERY_IDX + 1)


#pragma pack(1)
/* 操作接收机驱动函数集合 */
typedef struct
{
    /* 驱动相关 */
    ULONG   (*pFuncAntCabDelaySet)(long lAntCabDelay,T_GPS_RCV_DRV_DATA *pRcvDrvData);
    ULONG   (*pFuncRcvTimeModeSet)(ULONG ulTimeMode,double dLatitude, double dLongitude, double dAltitude,T_GPS_RCV_DRV_DATA *pRcvDrvData);
    ULONG   (*pFuncRcvTimeModeGet)(ULONG *pulTimeMode,double *pdLatitude, double *pdLongitude, double *pdAltitude,T_GPS_RCV_DRV_DATA *pRcvDrvData);
}T_SAT_RCV_FUNC;



typedef struct
{
    CHAR acGpsType[10];   /* 升级的GPS子卡类型：目前只有只有指南针GPS，名称为4字节字符串，剩余字符填0 */
    CHAR acCpuVer[40];    /* GPS CPU版本。字符串，不超过40 BYTE，剩余字符填0 */
    CHAR acFpgaVer[40];   /* GPS FPGA版本。字符串，不超过40 BYTE，剩余字符填0  */
    CHAR acHardVer[20];   /* GPS 硬件版本。字符串，不超过20 BYTE，剩余字符填0  */
    CHAR acHardId[20];    /* GPS 硬件序列号。字符串，不超过20 BYTE，剩余字符填0  */
}T_FIBER_RGPS_VER;

typedef struct
{
    UINT16 usCursor;   /* 游标 */
    UINT16 usFrameFoundLen;  /* 已找到的帧长 */
    UINT16 usTailFoundLen;   /* 已找到的帧尾长度 */
    UINT16 usPayloadLen;    /* 净荷长度 */
    UINT16 usCrc;         /* CRC */
}T_UBX_TD_FRAME_GET;

typedef struct
{
    UINT8 ucPayLoadLen;     /* 配置命令净荷长度 */
    UINT8 ucCmdIdx;         /* 配置命令在g_aucUbxCmd的索引 */
    UINT8 ucByteOffset;     /* 比较字段偏移 */
    UINT32 ulAckRet;         /* 响应返回值 */
}T_UBX_CMD_PARA;

/* 存储于磁盘上的天馈位置信息 */
typedef struct
{
    DOUBLE dLongitude;   /*经度，单位度*/
    DOUBLE dLatitude;    /*纬度，单位度*/
    DOUBLE dAltitude;    /*高度，单位米*/
    UINT16 usCrc16;      /* CRC */
}T_BSP_SAT_ANT_POS;

typedef struct
{
    UINT8 aucAidIni[AGPS_UBX_AID_INI_LEN];                     /* AID_INI帧 */
    UINT8 aucAidHui[AGPS_UBX_AID_HUI_LEN];                     /* AID_HUI帧 */
    UINT8 aucAidEph[GPS_SAT_NUM][AGPS_UBX_AID_EPH_LEN];        /* AID_EPH帧 */
    UINT8 aucReserved[AGPS_RESERVED_BYTE];                     /* AGPS保留字节数 */
}T_AGPS_UBX_INFO;

typedef struct
{
    UINT8 ucRcvType;                /* AGPS帧对应的接收机类型，9为UBLOX，12为SigNav */
    UINT32 ulUsableFlag;               /* 可用标志,1为可用,0为不可用 */
    UINT32 ulLockedSatCnt;           /* 获取到星历的卫星个数 */
    UINT8 aucAgpsSatNum[GPS_SAT_NUM]; /* 获取到星历的卫星号 */
    T_POSITION tPosition;           /* 位置信息。0~3byte:经度；4~7byte:纬度；8~11byte:高度 */
    T_AGPS_UBX_INFO tAgpsUbxInfo;
    UINT16 usCrc16;                 /* 星历的CRC16校验 */
}T_AGPS_INFO;

/*长整形和无符号字节数之间的转换, for little endian CPU */
union chartolong
{
    ULONG LongMode;
    struct
    {
        UCHAR LLBYTE;
        UCHAR LHBYTE;
        UCHAR HLBYTE;
        UCHAR HHBYTE;
    }CharMode;
};

/*----------------------------------------------------------------------------*
 *                               函数声明(内部)                           *
 *----------------------------------------------------------------------------*/
ULONG UbloxRcvDrv(void);
void UbloxRcvTask(void);
ULONG GpsUartOutput(ULONG ulLen, UCHAR *pucBuf);
void  GpsUnitGetData(T_FpgaUartBuffer *pUartBuf);
ULONG UbxReceiverProtect(T_GPS_RCV_DRV_DATA *pProtectRcv);
ULONG UbloxReceiverDeal(T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxUartSendData(UCHAR NUM);
ULONG UbxCalcCheckSum(ULONG ulCmdLen, UCHAR *ucCmdBuf);
ULONG UbxUpdateCheckSum(ULONG ulCmdIndex);
ULONG UbxSendCmdCfgRst(void);
ULONG UbxSendCmdMonVer(void);
ULONG UbxSendCmdCloseAllMsg(void);
ULONG UbxSendCmdCfgTp(void);
ULONG UbxSendCmdCfgAnt(void);
ULONG UbxSendCmdMonHw(void);
ULONG UbxSendCmdCfgNav2(void);
ULONG UbxSendCmdCfgTmode(void);
ULONG UbxSendCmdCfgMsgNavSol(void);
ULONG UbxSendCmdCfgMsgNavPosllh(void);
ULONG UbxSendCmdCfgMsgNavTimegps(void);
ULONG UbxSendCmd5TCloseGpgll(void);
ULONG UbxSendCmd5TCfgGpgsv(void);
ULONG UbxSendCmd5TCloseGprmc(void);
ULONG UbxSendCmd5TCloseGpvtg(void);
ULONG UbxSendCmd5TCloseGpzda(void);
ULONG UbxSendCmd5TCfgNav5(void);
ULONG UbxSendCmd5TCfgTp(void);
ULONG UbxSendCmd5TCfgTmodeQuery(void);
ULONG UbxSendCmdCfgSbas(void);
ULONG UbxSendCmdPollCfgTp(void);
ULONG UbloxCreatePositionHoldCmd(double dX, double dY, double dZ);
ULONG UbxCreateCableDelayCmd(long lLenth,T_GPS_RCV_DRV_DATA *pRcvDrvData);
void UbxGpsReceiverInit(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG UbxDecodePosition(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxDecodeGpsTime(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxDecodeAntennaStatus(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxDecodeVersion(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxDecodeAck (const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxDecodeStatus(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxDecodeTmode(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG NmeaDecodeGpgsv(UCHAR *pucBuf, const USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
UCHAR NmeaDecodeGpgga(UCHAR *pucBuf, const USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
UCHAR NmeaDecodeGpgsa(UCHAR *pucBuf, const USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxFrameGet(T_FpgaUartBuffer *ptGcmInput, UCHAR * const pucFrameBuf, USHORT *pusFrameLen, UCHAR *pucProtocol);
ULONG UbxFrameProcess(const UCHAR *pucBuf, USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
UCHAR NmeaFrameProcess(UCHAR *pucBuf, USHORT usFrameLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxCmdDecode(T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbloxSetAntCableLenth(long lLenth,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbloxSetGpsRcvTimeMode(ULONG ulTimeMode,double dLatitude, double dLongitude, double dAltitude,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbloxGetGpsRcvTimeMode(ULONG *pulTimeMode,double *pdLatitude, double *pdLongitude, double *pdAltitude,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxGetAgpsInfoStartTask(void);
ULONG UbloxStasCleanUpSinceMsgErr(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG TaiDouRcvIdentify(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG UbloxCreatTimeModeCmd(T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbloxCreatAntCableCmdForInit(T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxPollCfgTp(ULONG ulCmd, long lLenth, T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxRunModeMain(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG UbxSendCmdCfgGnssQuery(void);
ULONG UbxSendCmdCfgGnss(void);
ULONG UbxCreateCfgWorkModeCmd(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG UbxSendCmdCfgBaudRate(ULONG ulBaudRate);
ULONG UbxDecodeBaudRate(const UCHAR *pucCmd, USHORT usCmdLen,T_GPS_RCV_DRV_DATA *pRcvDrvData);
ULONG UbxCfgBaudRate(ULONG ulBaudRate, T_GPS_RCV_DRV_DATA *pRcvData);
void IntRcvTask(VOID);
UINT32 BspGetSatType(VOID);
VOID GpsAlmStateInit(VOID);
ULONG UbloxRcvManualReset(UCHAR ucResetMode);
ULONG ClockChangeDaysToMonDay(T_Clock_Tod *D);
ULONG BspUbloxRcvIdentify(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG GetBookTime(void);
ULONG UbloxRcvStatusGet(UINT32 radioMode, T_GNSS_RECEIVER_STATE *pGNSSRcvStatus, T_GPS_RCV_DRV_DATA *pRcvData);
ULONG UbloxRcvAlarmGet(T_GNSS_ALARM_STATUS *ptGnssAlarmStatus, T_GPS_RCV_DRV_DATA *ptRcvData);
ULONG BspSatOmitAntBreak(T_GPS_RCV_DRV_DATA *pRcvData);
ULONG GpsRcvOkErrTimeRecord(T_GPS_RCV_DRV_DATA *pRcvDrvData);

#pragma pack()

#ifdef __cplusplus
}
#endif

#endif /* #ifndef UBLOXRECEIVER_DRV_H */


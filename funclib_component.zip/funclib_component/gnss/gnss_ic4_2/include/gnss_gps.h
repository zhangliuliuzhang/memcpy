/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : Gps.h
* 文件标识 : {[N/A]}
* 内容摘要 : Gps模块的头文件
* 注意事项 : 无
* 作    者 : 孔祥焰
* 创建日期 : 2011-8-31 10:13:26
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 孔祥焰
* 修改日戳: 2011年8月31日10:13:37
* 变更说明: 创建
*
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_GNSS_GPS_COMMON_H_
#define _FUNCLIB_GNSS_GPS_COMMON_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "vxadp.h"
#include "gnssapi.h"

#define PP1S_OFFSET_TYPE_1588      0xFE
#define PP1S_OFFSET_TYPE_10MS      0xFF

//// 这几个跟寄存器、IC相关的函数需要实现 //
#define _BspZteGpioSetMode(a, b)        {}//
#define _BspZteGpioSet(a, b)            {}//
#define IntPub_WrRegBitVal(a,b,c,d,e,f) {}//
////////////////////////////////////////////


#define IS_GNSS_ID_VALID(id)    ((id) < 0xff)

#pragma pack(1)

#define BSP_COMMON_CLK_STAT_CNT      (100)
#define GCM_UART_QUEUE_SIZE          (1024)
#define USR_GCMSERIAL_OUTQUEUE_SIZE  (1024)
#define FPGA_UART_QUEUE_SIZE         (1024) /* fpga uart口相关缓存区大小 */

#define GPS_SAT_INVIEW_MAX           (16)

#define BSP_RPGS_INT_VER               (140)    /*RGPS中断向量号，待确认*/
typedef UINT32 (*FUNC_GPS_SEL_8T)(VOID);

typedef struct
{
   /* 设备编号，从0开始按顺序编号 */
   UINT32 ulDevIndex;
   /* 预留, 防止出现类似兼容芯片但有少量差异时使用 */
   UINT32 ulDevType;
   /* I2C接口相关的从器件信息结构体 
   T_I2C_CLIENT_OWNER tSlave;*/
   /*  */
   SEM_ID ptSemWrRd;
} T_GpsDev;

/* GNSS卫星类型 */
#define GPS_SAT_TYPE        (1)
#define GLONSS_SAT_TYPE     (2)
#define BEIDOU_SAT_TYPE     (3)
#define MAX_SAT_TYPE        (4)


/* GNSS接收机使用的卫星类别 */
#define     RCV_USED_SAT_TYPE_GPS           (1)
#define     RCV_USED_SAT_TYPE_GLN           (2)
#define     RCV_USED_SAT_TYPE_BD          	(3)
#define     RCV_USED_SAT_TYPE_GPS_GLN 		(4)
#define     RCV_USED_SAT_TYPE_GPS_BD      	(5)


/* 卫星导航系统 与UBLOX协议书 NEMA4.1定义的GNSS system ID一致 */
#define GNSS_SYSTEM_TYPE_GPS          (1)
#define GNSS_SYSTEM_TYPE_GLONASS      (2)
#define GNSS_SYSTEM_TYPE_GALILEO      (3)
#define GNSS_SYSTEM_TYPE_BEIDOU       (4)
#define GNSS_SYSTEM_TYPE_ALL          (GNSS_SYSTEM_TYPE_BEIDOU + 1)
#define GNSS_SYSTEM_TYPE_MAX          (GNSS_SYSTEM_TYPE_ALL)

#define GNSS_SUPPORT_SYSTEM_GPS         (1)
#define GNSS_SUPPORT_SYSTEM_GPS_BD      (2)
#define GNSS_SUPPORT_SYSTEM_GPS_GLN     (3)
#define GNSS_SUPPORT_SYSTEM_UNKOWN      (4)

/* 锁定卫星通道数 */
#define NUM_OF_LOCK_SAT_CHANNEL  (12)

/* 锁定卫星通道数 */
#define NUM_OF_UBLOX_LOCK_SAT_CHANNEL  (12)

#define GNSS_LOG_TYPE_CFG             (1)
#define GNSS_LOG_TYPE_INIT            (2)
#define GNSS_LOG_TYPE_ALARM           (3)
#define GNSS_LOG_TYPE_SNDMSG          (4)    
#define GNSS_LOG_TYPE_RST             (5)

#define GNSS_LOG_LINE_SIZE            (128)
#define GNSS_PP1S_OFFSET_DIF          (300)

#define RCV_COMMUN_FAIL               (1)   /* UART通讯异常 */
#define GPS_ANT_OPEN                  (2)   /* 天馈开路 */
#define GPS_ANT_SHORT                 (3)   /* 天馈短路 */
#define INT_GPS_RCV_RESTART           (4)   /* 接收机重启 */
#define GNSS_PP1S_LOST                (5)   /* pp1s丢失 */
#define FAKE_GPS_TOD_ERR              (9)   /* TOD不可用 */
#define FAKE_GPS_LEAPS_ERR            (10)  /* 秒脉冲不可用 */
#define FAKE_GPS_PHASE_ERR            (11)  /* 鉴相值异常 */
#define GPS_SEARCH_SAT_ERR            (13)  /* 搜星异常 */
#define GPS_FRAME_MODE_ERR            (31)  /* AAU增加，制式类型错误 */
#define GPS_TACC_ERR                  (32)  /* AAU增加，鉴相类型异常 */

#define GPS_NORMAL_STATUS             (0)
#define GPS_ABNORMAL_STATUS           (1)
#define GPS_INVALID_FLAG              (0xFFFFFFFF)


typedef struct ClkStatStatus
{
    UINT32 ulPp1sLostTimes;
    UINT32 aulPp1sLostTick[BSP_COMMON_CLK_STAT_CNT];
}T_CLK_STATUS;

typedef struct tagTodInfoTime
{
    UINT8      ucMsgHeadClass;   /* 消息头的Class字段，0x01 */
    UINT8      ucMsgHeadId;      /* 消息头的Id字段，0x20 */
    UINT16     usMsgLength;      /* 消息长度，16  */
    UINT32     ulGpsTow;         /* gps时间周内秒数 */
    UINT32     ulReserved1;      /* rsv */
    UINT16     usGpsWeek;        /* gps时间周数 */
    char       cLeapS;           /* gps时与utc时偏移量 */
    UINT8      ucPpsStatus;      /* 秒脉冲状态，0x00 =正常
                                         0x01 =时间同步设备（原子钟）保持
                                         0x02 =不可用
                                         0x03 =时间同步设备（高稳晶振）保持
                                         0x04 =传输承载设备保持 */
    UINT8      ucTacc; 			 /* 鉴相类型，0xff-10ms鉴相; 0xfe: PP1S鉴相 */
    UINT8      ucGnssId;         /* RRU上配置的Gnss ID */
    UINT8      ucRackNo;         /* 与GNSS ID对应的机架号 */
    UINT8      ucLockSatCnt;     /* 锁定卫星数 */
    UINT8      ucMsgCRC;         /* 不包括帧头字段的crc校验 */
}T_TodInfoTime;

/*GNSS@RRU帧 的时间状态包格式*/
typedef struct tagTodInfoState
{
    UINT8      ucMsgHeadClass;   /* 消息头的Class字段，0x01  */
    UINT8      ucMsgHeadId;      /* 消息头的Id字段，0x03 */
    UINT16     usMsgLength;      /* 消息长度，16  */
    UINT8      ucClkSrcType;     /* 时钟源类型，0x00 = 北斗；0x01 = gps;0x02 = 1588 */
    UINT16     usClkSrcState;    /* 时钟源工作状态GPSfix Type, range 0..3
                                    0x00 = no fix
                                    0x01 = dead reckoning only
                                    0x02 = 2D-fix
                                    0x03 = 3D-fix
                                    0x04 = GPS + dead reckoning combined
                                    0x05 = Time only fix
                                    0x06..0xff = reserved  */
    UINT16     usClkSrcAlarm;    /* 监控告警，时钟源状态告警：
                                    Bit 0: not used
                                    Bit 1: Antenna open
                                    Bit 2: Antenna shorted
                                    Bit 3: Not tracking satellites
                                    Bit 4: not used
                                    Bit 5: Survey-in progress
                                    Bit 6: no stored position
                                    Bit 7: Leap second pending
                                    Bit 8: In test mode
                                    Bit 9: Position is questionable
                                    Bit 10: not used
                                    Bit 11: Almanac not complete
                                    Bit 12: PPS was generated */
    UINT8      ucGnssId;         /* RRU上配置的Gnss ID */
    UINT8      ucFrameMode;      /* 0x01:  CPRI(UMTS/LTE)
                                    0x02:  TD-SCDMA
                                    0x03:  GSM
                                    0x04:  其它
                                    0x05:  FDD(用于区分原来TDD的1，王卓勇罗焕发)
                                    0x06:  5G 低频使用(20181025宋连坡给出)*/
    UINT8      ucFrameNum1;      /* GSM帧号高8位，其它制式写死为0 */
    UINT32      ulFrameNum2;      /* GSM帧号低32位，其它制式使用低2字节 */
    UINT32      ulPp1sOffset;     /* 鉴相值，单位ns */
    UINT8      ucMsgCRC;         /* 不包括帧头字段的crc校验 */
}T_TodInfoState;
/* 帧头定义字段 */
typedef struct tagFrameHead
{
    UINT8      ucFrameSyncChar1; /* 帧头的第一个字节，用来区分不同的运营商 */
    UINT8      ucFrameSyncChar2; /* 帧头的第二个字节 */
}T_TodFrameHead;

typedef struct tagTimeFrame
{
    T_TodFrameHead tFrameHead;
    T_TodInfoTime tTimeInfo;
}T_1PpsTodTimeFrame;

typedef struct tagStasFrame
{
    T_TodFrameHead tFrameHead;
    T_TodInfoState tStateInfo;
}T_1PpsTodStasFrame;
/* GNSS@RRU帧结构体 */
typedef struct tagRruGnssFrame
{
    T_1PpsTodTimeFrame tTimeFrame;
    T_1PpsTodStasFrame tStasFrame;
    UINT16 usRev; // 增加消息统计
}T_RRU_GNSS_FRAME;

/* 时间存储结构体 */
typedef struct
{
    UINT16  YEAR, DAYS;
    UINT8   MON, DAY, HOUR, MIN, SEC;
}T_Clock_Tod;


typedef struct
{
    UINT8 ucNumOfSatInView;               /* gps可见卫星数 */
    T_SAT_DETAILS atSatInViewDetails[GPS_SAT_INVIEW_MAX]; /* gps卫星详细信息 */
    UINT8 ucNumOfGlnSatInView;               /* GLONASS或BD可见卫星数 */
    T_SAT_DETAILS atGlnSatInViewDetails[GPS_SAT_INVIEW_MAX]; /* GLONASS或BD卫星详细信息 */
}T_SAT_IN_VIEW;



/* GPS接收机驱动数据 */
typedef struct tagT_GPS_RCV_DRV_DATA
{
    /* 配置及过程变量 start*/
    UINT32 ulSatDriverId;  /* 参考源ID,例如驱动会根据不同的Id进行不同的处理 */
    UINT32 ulRefConfigFlag;/* 该结构体实例是否后台配置，0：未配置；1：配置 */
    /* 后台接收机配置模式，是否维护接收机，与参考源子类ID对应，
       1:内置；2：面板外置；3：背板外置，4/14：1pps+tod主/备，5：电文透传级联从框
       0表示未配置态 */
    UINT32 ulRcvPlace;
    UINT32 ulReceiverCtrl;  /* 是否维护接收机标志，0：不维护，1：维护 */
    UINT32 ulLostThreshold;/* 后台配置的参考源不可用门限值 */
    INT32  lAntCabDelay;   /* 天馈线缆延时ns，参考源1，2，3时有效 */
    INT32  lAntCabDelayInLength;/* 天馈线缆长度，参考源1，2，3时有效，可正可负，主要是可以双向调节pp1s的位置 */
    UINT32 ulInTimeInputType; /* PP1S和TOD输入方式，0:为一线输入,1:为二线输入,参考源4，5，14有效 */
    UINT32 ulAntCableLenChange;/* 天馈线缆长度改变标志 */
    UINT32 ulLeastSatNum;   /* 最小开控、告警搜星数，参考源1，2，3时有效 */
    UINT32 ulLeastSatNumBackup;   /* 最小开控、告警搜星数，单星备份使用 */
    UINT32 ulRcvWorkMode;   /* 接收机工作模式，参考源2，3时有效  */
    UINT32 ulRcvRealWorkMode;  /* 接收机实际工作模式 */
    UINT32 ulSatCfgType;     /* 接收机类型*/
    /* 单星授时功能start */
    UINT32 ulTimeMode;               /* 后台设置的 auto mode or fix mode */
    UINT32 ulTimeModeLast;           /* 后台设置的上一次auto mode or fix mode */
    DOUBLE dLongitude;              /* 经度，单位是度 */
    DOUBLE dLatitude;               /* 维度，单位是度 */
    DOUBLE dAltitude;               /* 高度，单位是米 */
    UINT32 ulUsingTimeMode;          /* 接收机当前的模式 */
      /* 配置过程变量 */
    UINT32 ulSetTMode;  /* 设置时设置成功标志 */
    UINT32 ulGetTMode;  /* 获取时设置成功标志 */
    /* 单星授时功能end */
    UINT32 ulSatStartTime;   /* 卫星类模块启动时刻(s) */
    UINT32 ulAntCheckCnt;  /* 检测天馈时临时计数变量 */
    UINT32 ulRcvInitCnt;   /* 接收机初始化临时计数变量 */
    UINT32 ulRcvUpdateCnt;   /* 接收机升级临时计数变量 */
    UINT32 ulGpsFixNotOkTime; /* 接收机搜星4颗以上但是无法进入3D或者time模式的开始时间 */
    UINT32 ulAntState;          /* 统计天馈异常次数临时状态变量，初始值为0 */
    T_SAT_DETAILS atSatDetails[16];/* 解析各颗卫星详细信息时用的临时缓存数组 */
    UINT32 ulRcvCmdNum;             /* 发送给接收机命令的编号 */
    UINT32 ulRcvCmdStartTime;        /* 命令发送时刻计时，发送命令后持续等待时间计数，超过即认为命令超时 */
    UINT32 ulRcvCmdRunFlag;         /* 在当前命令没有得到回应之前不发送下一条命令，标示当前命令发送状态，0：无命令在发送，1：有命令在发送等待结果中 */
    UINT32 ulRcvCmdTimeOutCnt;      /* 接收机命令发送超时计数 */
    UINT32 ulRcvWarmStartCnt;       /* 接收机热启计数,计到一定数值时有可能需要转到冷启 */
    UINT32 ulRcvColdInitFlag;       /* 接收机冷启标志，1：冷启；0：热启 */
    UINT32 ulRcvColdInitFlagLast;       /* 接收机冷启标志上一个状态，1：冷启；0：热启 */
    /* 配置及过程变量 end */
    /* 状态信息 start */
    BOOL  bUartMsgOn; /* CPU或FPGA UART能否接收到电文标志，FALSE为接收不到电文，TRUE为能接收到电文 */
    UINT8 ucGpsUartErr; /* 接收机uart口状态标志，0：正常；1：不通 */
    UINT8 ucUartStat;/* UART口实时状态，用于运维信息检测 */
    UINT32 ulUartNormalTime; /* UART口接收正常的时间，防抖使用 */
	UINT8 ucPpsLost; /* PP1S丢失指示，0表示正常，1表示丢失 */
    UINT8 ucRcvType;/* 接收机类型 */
    UINT8 ucRcvVersion;/* 接收机版本 */
    UINT32 ulRcvFixStatus; /* 接收机定位状态，也适用于1pps+tod参考源 */
    UINT32 ulRcvAntennaState;/* 天馈状态 */
    UINT32 ulRcvAntennaStateShow;/* 增加天馈假开路处理后的天馈状态，告警诊断用 */
    UINT32 ulRcvInitStartTime;/* 接收机初始化开始时刻 */
    UINT32 ulRcvInitFinishTime;/*接收机初始化完成的时间*/
    UINT32 ulRcvInitFinishFlag; /* 接收机初始化完成标志 */
    UINT8 ucRcvInitStep; /* 接收机初始化步骤 */
    UINT32 ulRcvOkTime; /* 接收机状态ok时间，源质量检测，单位是s  */
    UINT32 ulRcvErrTime; /* 接收机状态Err时间，源质量检测，单位是s  */
    UINT32 ulLockSatState; /* GPS接收机搜星状态。0表示搜星成功，1表示正在搜星，2表示搜星失败, 3表示GPS信号不可用 */
    UINT32 ulLastLockSatErrTime;/* 最近一次搜星失败时间，防抖使用 */
    UINT32 ulLastLockSatOkTime; /* 最近一次搜星成功时间，防抖使用 */

	UINT32 ulBaudRate;
	UINT8  ucDualRcvProtectStep;     /* 双模接收机保护执行步骤 */
    UINT8  ucDualRcvProtectCnt;      /* 双模接收机保护执行次数 */
    UINT32 ulDualRcvProtectTime1;    /* 双模接收机保护进入步骤1的时间点 */
    UINT32 ulDualRcvProtectTime2;    /* 双模接收机保护进入步骤2的时间点 */
    UINT32 ulDualRcvProtectWorkMode; /* 双模接收机保护的工作模式 */
	
    /* 防止天馈假开路相关变量 */
    UINT32 ulOmitAntBreakLockSatOkTimes;/* 搜星好持续记数 */
    UINT32 ulOmitAntBreakLockSatErrTimes;/* 搜星不好持续记数 */
    UINT32 ulLockedSatNumIsEnoughForOmitAntBreak;/* 记录到足够多的锁定卫星次数来屏蔽天馈开路，0：没有，1：有 */
    UINT32 ulLastBookTime;
    UINT32 ulAntennaBadTimes;/* 天馈故障次数 */
    UINT32 ulRcvUsedSatType; /* 接收机使用的卫星类型，1为GPS，2为GLONASS，3为COMPASS，4为GPS+GLONASS */
    UINT32 ulAvlSatCnt[MAX_SAT_TYPE];   /* 可见卫星数包括gps、glnass、bd  */
    UINT32 ulTrackedSatCnt[MAX_SAT_TYPE];/* 跟踪卫星数包括gps、glnass、bd */
    UINT32 ulLockedSatCnt[MAX_SAT_TYPE];/* 锁定卫星数包括gps、glnass、bd */
    UINT32 ulRcvResetTimes;/* 接收机重启次数 */
    UINT32 ulRcvRstTimesSinceCmd; /* 因命令超时复位接收机统计次数 */
    UINT8 aucSatInUse[MAX_SAT_TYPE][NUM_OF_UBLOX_LOCK_SAT_CHANNEL];           /* 正在使用卫星信息 */
    T_SAT_IN_VIEW tSatInVew[MAX_SAT_TYPE];                  /* 可见卫星的详细信息 */
    /* 状态信息 end */
    /* msg start */
    T_Clock_Tod tGpsDate;/* gps tod */
    T_Clock_Tod tLastGpsDate;/* Last gps tod  */
    UINT32 ulNormalTodTimes;
    UINT32 ulRcvTodOkCnt;/* 驱动判断tod是否可用临时计数变量 */
    UINT32 ulFirstFlag;       /* 第一次同步电文tod */
    UINT32 ulSatTodAbnormalTimes;/* 统计tod跳秒次数 */
    UINT32 ulRcvTodOkFlag;/* gps tod 是否可用的一个标志 0:不可用，1：可用 */
    UINT8 ucLeapSeconds;/* 闰秒 */
    T_POSITION tPositionInfo;/* 经纬高位置信息，给后台看的 */
    T_POSITION tNormalPosition;
    UINT8 ucFakeGpsMsgErr;
    UINT8 ucFakeGpsMsgAlarm;
	UINT8 ucFakeGpsErrFlg;   /* 伪GPS异常标标志 */

    /* msg end */
    UINT32 ulRcvUseableFlag;                   /* 接收机是否可用的标志，0：初始化，1：不可用 ，2：可用*/
    UINT32 ulRcvOldUseableFlag;                /* 接收机(上一个状态)是否可用的标志，0：不可用，1：可用 */
    UINT32 ulRcvStatusChgSttTime;              /* 接收机可用不可用状态改变时对应的时刻，为了计算接收机状态持续时间 */
    UINT32 ulRcvStatusLastTime;                /* 接收机可用或者不可用持续时间，以s为单位 */
    /****************详细信息(调试、定位故障专用，不向外暴露)start************************ */
    UINT32 ulRcvMsgStas;                       /* 接收机电文接收状态标志，0：接收不正常，1：每收到TOD信息就置为1 */
    UINT32 ulRcvTodStas;                       /* 接收机电文接收TOD状态标志，0：接收不正常，1：每收到TOD信息就置为1 */
    UINT32 ulRcvMarkMsgStas;                   /* 接收机电文接收状态标志，0：接收不正常，1：每收到标志性电文信息就置为1 */
    UINT32 ulTodStasErrCnt;                    /* 接收机电文接收TOD 没收到持续次数 */
    UINT32 ulTodStasErrFlag;                   /* 接收机电文接收TOD 没收到持续次数超过10次，给出错误标志：0:正常；1：出错 */
    UINT32 ulRcvRstDetails[10];   /* 接收机复位原因详细记录数据 */
    UINT32 ulRcvMarkMsgErrCnt;                 /* 接收机收不到标志性电文计数*/
    UINT32 ulGpsNoAckTime;                     /* 接收机收不到tod电文起始时间，若与GetBookTime相同则表示接收正常 */
    UINT32 ulLockFailedTime;/* 天馈正常但是搜星为0的状态开始时间 */
    UINT32 ulRcvInitNotDoneTime;   /* 接收机初始化未完成的起始时间,，若与GetBookTime相同则表示接收机初始化完成 */
	UINT32 ulRcvAntennaStateStart; /* 天馈状态变化时起始时间 */
    UINT32 ulRcvAntennaLastState;  /* 上次天馈状态的稳定态(状态维持10s才认为ok) */
    /****************详细信息end************************ */
    /* 1pps+tod Ref state start */
    UINT8 ucFrameMode;           /* 运营商标准 */
    UINT8 ucPpsStatus;           /* 秒脉冲状态，0x00 = 正常，0x01 = 降质，0x02 = 不可用；其它保留 */
    UINT8 ucTacc;                /* pps抖动量级，写死为0xff */
    UINT8 ucClkSrcType;          /* 时钟源类型，0x00 = 北斗；0x01 = gps;0x02 = 1588，外置接收机也使用 */
    UINT16 usClkSrcState;        /* 时钟源工作状态GPSfix Type, range 0..3
                                    0x00 = no fix
                                    0x01 = dead reckoning only
                                    0x02 = 2D-fix
                                    0x03 = 3D-fix
                                    0x04 = GPS + dead reckoning combined
                                    0x05 = Time only fix
                                    0x06..0xff = reserved  */
    UINT16 usClkSrcAlarm;        /* 监控告警，时钟源状态告警：
                                    Bit 0: not used
                                    Bit 1: Antenna open
                                    Bit 2: Antenna shorted
                                    Bit 3: Not tracking satellites
                                    Bit 4: not used
                                    Bit 5: Survey-in progress
                                    Bit 6: no stored position
                                    Bit 7: Leap second pending
                                    Bit 8: In test mode
                                    Bit 9: Position is questionable
                                    Bit 10: not used
                                    Bit 11: Almanac not complete
                                    Bit 12: PPS was generated */
    UINT8 ucInputLineCfgStatus;  /* 分路合路输入和配置是否一直状态，0：一致；1：不一致 */
    /* 1pps+tod Ref state end */
    /* FPGA操作相关start */
    UINT32 ulVerPollFlag;
    UINT32 ulRgciPollCnt;    /* RGCI查询间隔计数 */
    UINT32 ulResv;           /* 保留字段，扩展使用 */
    /* RRU GPS相关 */
    UINT8 ucGnssId;
    UINT8 ucRackNo;
    UINT32 ulPhaseValue;
    UINT64 ullFrameNo;
	UINT8 ucTimeGrid;       /* PP1S对齐的时间 */
	UINT8 ucCurWaitCnt;
    T_GNSS_ALARM_STATUS tAlmStatus;
}T_GPS_RCV_DRV_DATA;

/* fpga串口输入缓冲区的类型定义 */
typedef struct tagT_FpgaUartBuffer
{
    UINT32   ulRcvId;
    UINT32   ulRcvMsgOkFlag;                 /* uart 口是否能够收到电文，0：不能，1：能；接收电文任务中置1，使用任务中清零 */
    UINT32   ulHead;                         /* 头指针 */
    UINT32   ulTail;                         /* 尾指针 */
    UINT8   aucBuf[FPGA_UART_QUEUE_SIZE];   /* 输入缓冲区队列 */
} T_FpgaUartBuffer;

#define CHINA_MOBILE             (0) /* 中国移动 */
#define CHINA_TELECOM            (1) /* 中国电信 */
#define DEFAULT_UNICOM           (2) /* 其它通用运营商 */

#define  SECOND_OF_WEEK            (7*24*3600)
typedef struct tagT_GnssBoardInfo
{
    UINT32 (*pGetPp1sLostEvent)();
    UINT32 (*pClrPp1sLostEvent)();
    UINT32 (*pGetPp1sStatus)();
    UINT32 (*pClrPp1sInt)();
    UINT32 (*pDisablePp1sInt)();
    UINT32 (*pEnablePp1sInt)();
    UINT32 (*pGetPhaseStatus)();
    UINT32 (*pGetPp1sOffset)();
    UINT32 (*pGetLockFrame)();
    UINT32 (*pGetOptRadio)(UINT32 optIndex);
    UINT32 (*pGetClkStatus)(UINT32 radioMode);
    UINT32 (*pGetPp1sOffsetType)(UINT32 radioMode);
    UINT32 (*pGetFrameMode)(UINT32 radioMode);
}T_GnssBoardInfo;

/* 单板注册信息 */
typedef struct tagT_GpsInfo
{
    SEM_ID FuncSem;
    UINT32 (*GetPp1sLost)(void);
    UINT32 (*ClrPp1sLost)(VOID);
    UINT32 (*GetPp1sOffset)(void);
    UINT32 (*GetGpsLockFrame)(VOID);
    UINT32 (*InitPp1sInt)(VOID);    
    UINT32 (*Send)(UINT8 *pucSendBuf,  UINT32  ulLen);
    UINT32 (*Recv)(UINT8 *pucRecvBuf, UINT32 ulLen);
    UINT32 (*GetAntStatus)(void);
    void (*gpsDevReset)(void);
}T_GpsInfo;

 typedef struct tagT_GnssParaInfo
{
    UINT32           valid;
    UINT32           radioMode;
    T_GNSS_PARA_CFG  cfg;
    UINT32           sendCnt;
    FUNC_BUF_CTRL    pSendToBbu; 
}T_GnssParaInfo;

typedef struct tag_T_GnssSndInfo
{
    T_Clock_Tod tod[2]; /* 本地tod,接收机tod */
    UINT32 pp1sIntCnt;  /* pp1s中断统计 */
    UINT32 pp1sProCnt;  /* pp1s保护次数统计 */
    UINT32 initSta;     /* 当前处于初始化哪一步 */
    UINT32 rcvTodOkCnt; /* tod是否可用临时计数变量 */
    UINT32 rcvMsgSta;   /* 接收机状态状态标志 */
    UINT32 ulClkStatus;  /* 1588,newflag */
    UINT32 localRcvInfo; /*接收机是否可用 */
}T_GnssSndInfo;

typedef struct tag_T_GnssCfgLog
{
    UINT8 ucRackNo;
    UINT8 ucGnssId;             /* GPS ID号, 正常是0\1\2*/
    UINT8 ucGnssWorkMode;    
    INT32 lAntCabDelay;        /* 天馈线缆延时 */ 
    UINT32 ulLeastSatNum;      /* 最小开控、告警搜星数，参考源1，2，3，5时有效 */
    UINT32 ulRadioMode;        /* 新增：按位组合，LTE-TDD：0x20;5G:0x2000*/
}T_GnssCfgLog;

typedef struct tag_T_GnssLogRecord
{
    UINT32 type;
    UINT8  date[20];
    UINT8  logData[GNSS_LOG_LINE_SIZE];
    struct tag_T_GnssLogRecord *next;
}T_GnssLogRecord;

typedef struct tag_T_LogList
{
    T_GnssLogRecord *pHead;
    T_GnssLogRecord *pTail;
    UINT32 listNode;
}T_LogList;


/* 天馈状态 */
#define GPS_ANTENNA_STATE_OK         (1)
#define GPS_ANTENNA_STATE_INIT       (126)
#define GPS_ANTENNA_STATE_DONTKNOW   (127)
#define GPS_ANTENNA_STATE_SHORT      (128)
#define GPS_ANTENNA_STATE_BREAK      (129)

#define GPS_PP1S_STATE_OK             (0)
#define GPS_PP1S_STATE_ALARM          (1)

#define GPS_FRAME_MODE_TDD            (1)
#define GPS_FRAME_MODE_FDD            (5)
#define GPS_FRAME_MODE_5G             (6)
//#define GPS_FRAME_MODE_5G_HI_FREQ     (7)

/* 接收机状态 */
#define SATELLITE_NOT_FIX                         (0)
#define SATELLITE_DEAD_RECKONING_ONLY             (1)
#define SATELLITE_GPS_AND_DEAD_RECKONING_COMBINED (2)
#define SATELLITE_2D_FIX                          (3)
#define SATELLITE_3D_FIX                          (4)
#define SATELLITE_TIME_ONLY_FIX                   (5)

/* 接收机授时模式 */
#define SATELLITE_AUTO_MODE                       (1)
#define SATELLITE_FIXED_MODE                      (2)
#define SATELLITE_SELF_CTRL_FIXED_MODE            (3)

/* 逻辑鉴相频率对应的单位 */
#define PPS_80M_PD_UNIT                           (12.5)
#define PPS_160M_PD_UNIT                          (6.25)


/* GPS接收机命令超时时间 */
#define GPS_CMD_TIME_OUT_IN_SEC     (sysClkRateGet() * 10)

/* 卫星类名称长度 */
#define GPS_REF_DESC_LENTH           (16)

#define CLOCK_REF_BAD_TO_OK_LIMIT (30)       /* 没有搜星告警时的恢复门限:30秒 */
#define SAT_REF_ALARM_RECOVER_LIMIT   (300)  /* 出现搜星告警时的告警恢复门限:300秒 */
#define SAT_REF_ALARM_LIMIT           (600)  /* 搜星告警门限:600秒 */

#define GPS_DBG_UBX_DRV      0x0001
#define GPS_DBG_INIT_PRN     0x0002
#define GPS_DBG_DATA_PRN     0x0004
#define GPS_DBG_SEND_PRN     0x0008
#define GPS_DBG_DRV_PRN      0x0010
#define GPS_MSG_DRV_PRN      0x0020
#define GPS_MSG_DECODE_PRN   0x0040
#define GPS_DBG_UBX_DRV_TEST 0x0080
#define GPS_FRAMER_NO_TEST   0x0100
#define GPS_ALM_PRN          0x0200   // gps告警查询周期太频繁，打印单独拎出来
#define GPS_DBG_BASE         0x1000

extern UINT32 ulGpsDbgPrnFlag;
#define __GPS_LOG(flg,fmt,...)   if (ulGpsDbgPrnFlag&(flg)) dbgPrn(fmt,##__VA_ARGS__)
#define GPS_LOG(FLG, FMT...)     __GPS_LOG(FLG,##FMT)

#define GET_GNSS_ID(pcfg,drv)    (pcfg) ? (pcfg->ucGnssId) : ((drv) ? (drv->ucGnssId) : (0xFF))
#define GET_GNSS_RACK(pcfg,drv)  (pcfg) ? (pcfg->ucRackNo) : ((drv) ? (drv->ucRackNo) : (0xFF))



UINT32 BspUniCasdSend1PpsTodFrame(UINT32 radioMode,T_RRU_GNSS_FRAME *ptRruGnssFrame);
UINT32 BspUniCasdCreatStateInfo(UINT32 radioMode,T_TodInfoState *ptStateInfo);
UINT32 BspUniCasdCreatTimeInfo(UINT32 radioMode,T_TodInfoTime *ptTimeInfo);
UINT32 BspUniCasdSdTod2GpsTod(T_Clock_Tod tClkLocalTod,UINT16 *pusGpsWeek,UINT32 *pulGpsTow);
UINT8 ClockCalcCRCChecksum(UINT8 *pucDataIn, UINT16 usLength);
UINT32 BspGetGpsTime(T_Clock_Tod *ptGpsTime);
UINT32 BspUniCasdFrameModeGet(VOID);
UINT32 BspGetSatLeapsPpsStas(UINT32 radioMode,char *pcLeaps,UINT8 *pucPpsStatus);
UINT16 BspGetSatClkAlarm(VOID);
BOOL ClockLeapYearCheck(UINT16 YEAR);
UINT16 ClockCalcDaysInCertainYear(UINT16 usYear);
UINT32 SatIntRcvIdentifyAndInit(VOID);
UINT32 _BspGetPp1sOffset(UINT32 radioMode);
UINT32 BspGnssTaskQuit(VOID);
UINT32 BspPp1sProtectModule(VOID);
VOID ClockIncrementTime(T_Clock_Tod *D);
VOID SetUartBaudrate(UINT32 ulRate, UINT8 ucParity);
INT32 BspGetGpsFrOffset(VOID);
INT32 BspGetGpsFrameNoOffset(VOID);
UINT32 BspGetGpsFrameMode(UINT32 radioMode);
UINT32 BspGetLocalClkStatus(UINT32 radioMode);
UINT32 _BspGetPp1sStatus(VOID);
UINT32 BspGpsGetFpgaIdCallback(UINT32 index, FUNC_GPS_GET_FPGA_ID pFunc);
UINT32 BspConvertTimeToSeconds(T_Clock_Tod *ptTod);
UINT32 BspIsSiteChang(T_GPS_RCV_DRV_DATA *pRcvData);
UINT32 BspIsTimeLast(T_GPS_RCV_DRV_DATA *pRcvData);
UINT32 BspIsFakeGps(T_GPS_RCV_DRV_DATA *pRcvData, UINT32 ulRcvInfo);
UINT32 BspFakeGpsErrAlm(T_GPS_RCV_DRV_DATA *pRcvData);

UINT32 BspSetGpsBoardInfo(T_GnssBoardInfo *pInfo);
T_GNSS_PARA_CFG * BspGetGnssCfgPara(UINT32 radioMode);
UINT32 BspGpsUartBaudRateCallback(UINT32 index, FUNC_GPS_UART_BAUDRATE pFunc);
UINT32 BspGpsUartInitCallback(UINT32 index, FUNC_GPS_UART_INIT pFunc);
UINT32 BspGpsSetRefCallback(UINT32 index, FUNC_GPS_SET_REF pFunc);
UINT32 BspGps1ppsSourceCallback(UINT32 index, FUNC_GPS_1PPS_SOURCE pFunc);
T_GnssParaInfo *BspGetGnssParaInfo(UINT32 radioMode);



ULONG BspGnssGpsGetFpgaId(VOID);
UINT32 _BspDisablePp1sInt(VOID);
VOID BspPp1sIsr(VOID);
UINT32 _BspClrPp1sInt(VOID);
UINT32 _BspEnablePp1sInt(VOID);
UINT32 _BspGetPhaseStatus(UINT32 radioMode);
VOID _SyncRcvTodToSatTod(VOID);
UINT32 BspGetGnssValidNum(VOID);
UINT32 BspSetGnssCfgPara(T_GNSS_PARA_CFG *pCfg);
UINT32 SetGnssAlmTime(VOID);
UINT32 BspGetFlashGpsTimeStamp(VOID);
UINT32 BspSetFlashGpsTimeStamp(UINT32 ulGpsTimeStamp);
UINT32 BspGpsPowSwitch(UINT32 ulPowSwitch);
UINT32 BspGetGnssAlmTime(UINT32 *pReportTime,UINT32 *pRecoverTime);
UINT32 BspSetUbloxAlmThre(UINT32 reportTime,UINT32 recoverTime);
VOID GpsAlmThreUpdate(VOID);
UINT32 BspUpdateGnssRadioMode(VOID);
UINT32 BspGetPp1sOffsetType(UINT32 radioMode);
UINT32 BspGetGnssSendCount(UINT32 radioMode);
UINT32 BspGnssLogInit(VOID);
UINT32 BspAddGnssLog(UINT32 type, char *pBuf, UINT32 len);
UINT32 BspSetGnssLogSize(UINT32 maxSize);
UINT32 BspGetRgpsAbnormalStatus(UINT32 abnormalType);
ULONG BspResetGnss(VOID);
ULONG _BspGetPp1sLostEvent(void);
ULONG _BspClrPp1sLostEvent(VOID);
ULONG _BspInitPp1sInt(VOID);
UINT32 BspGspSel8TCallback(FUNC_GPS_SEL_8T pFunc);
UINT32 _BspGpsClrPp1sInt(VOID);
UINT32 _BspGpsDisablePp1sInt(VOID);
UINT32 _BspGpsEnablePp1sInt(VOID);
UINT32 _BspGpsGetPp1sLostStatus(VOID);
UINT32 _BspGpsGetPhaseCnt(VOID);
UINT32 _BspGpsGetLockBfn(VOID);
UINT32 getGpsIntVer(unsigned long *pulIntVer);
VOID _BspGpsSetBfnAdjust(VOID);

#pragma pack()

#ifdef __cplusplus
}
#endif

#endif


/*****************************************************************************
 * 版权所有(C) 2010, ZTE Corp. RRU Bsp Platform
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : Gps.h
* 文件标识 : {[N/A]}
* 内容摘要 : Gps模块的头文件
* 注意事项 : 无
* 作    者 : 孔祥焰
* 创建日期 : 2011-8-31 10:13:26
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 孔祥焰
* 修改日戳: 2011年8月31日10:13:37
* 变更说明: 创建
*
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_GNSS_AAS_COMMON_H_
#define _FUNCLIB_GNSS_AAS_COMMON_H_


#include "vxadp.h"
#include "gnssapi.h"

#define RECVDATA_SIZE          (1024)
#define NOTSUPPORT                       ((UINT32)(-1))
#define EXIST                       	 (1)
#define NOEXIST                          (0)
typedef UINT32 (*BSP_AAS_EXIST_CALLBACK_FUNCPTR)(VOID);

VOID BspInitAasExistCallBack(UINT32 (*pFuncCallback)(VOID));
void Read_Test(void);


#pragma pack()

#endif


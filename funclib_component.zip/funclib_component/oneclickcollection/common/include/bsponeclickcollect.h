#ifndef _BSP_ONECLICK_H_
#define _BSP_ONECLICK_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
/**************************************************************************
 *                         数据类型
 **************************************************************************/




/**************************************************************************
*                         函数声明
**************************************************************************/
typedef UINT32 (*pOneClickSrsRegistFunc)(VOID);/* SRS回调 */
typedef UINT32 (*pOneClickGreenRegistFunc)(VOID);/* 汇聚节能回调 */
typedef UINT32 (*pOneClickUtdoaRegistFunc)(VOID);
typedef UINT32 (*pOneClickDmimoRegistFunc)(VOID);
typedef INT32 (*pMtsDiagnose)(INT32 chip,UINT32 option);/* MTS函数回调，因为在funclib下同时加上两个mts_common.h 和 mts2_common.h 一直报错*/
typedef INT32 (*pMts2Diagnose)(INT32 chip,UINT32 option);
typedef UINT32 (*pOneClickAdiRegistFunc)(VOID);/* ADI的挂接函数，因为很多机型没有ADI，直接使用ADI函数会报错 */

UINT32 BspSetUtdoaOneClickFunc(pOneClickUtdoaRegistFunc utdoaFunc);
UINT32 BspSetDmimoOneClickFunc(pOneClickDmimoRegistFunc dmimoFunc);
UINT32 BspSetMts2DiagnoseFucn(pMts2Diagnose mts2Fucn);
UINT32 BspSetMtsDiagnoseFucn(pMtsDiagnose mtsFucn);
UINT32 BspSetAdiOneClickFucn(pOneClickAdiRegistFunc AdiFucn);
UINT32 BspSetGreenOneClickFunc(pOneClickGreenRegistFunc greenFunc);
UINT32 BspSetSrsOneClickFunc(pOneClickSrsRegistFunc srsFunc);


VOID HelpShowBspCfg(VOID);
VOID HelpHalPaptShow(VOID);
VOID BspOneClickCollect(VOID);
typedef VOID (*HelpJ204Check)(VOID);
UINT32 BspSetMts2Test204c(HelpJ204Check ucFunc);
UINT32 BspIcHalApiGetMetricsSerdesInfo(T_SerdesInfo *pcSerdesInfo);
UINT32 BspHalAdaptGetMetricsDldvgaInfo(T_DldvgaInfo *pcDldvgaInfo);
UINT32 BspGetPwrTempByIndex(UINT32 index, INT32 *temp);
UINT32 BspGetPaTempByChan(UINT32 chan, INT32 *temp);
UINT32 BspGetPaDatSamp(T_FailPredSChipPaSta  *ptFailPredSChipPaSta);
UINT32 BspGetPaptByChan(UINT32 chan, UINT32 paptClass, UINT32 *alarmSta);
UINT32 BspGetChipPowerSta(T_FailPredSChipPowerSta  *failPredSChipPowerSta);
#ifdef __cplusplus
}
#endif
#endif

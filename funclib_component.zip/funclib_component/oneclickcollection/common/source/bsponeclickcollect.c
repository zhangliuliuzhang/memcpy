#include "bsponeclickcollect.h"
#include "freqcfgcommon.h"
#include "powerctrl_ic4_2_dbg.h"
#include "bsppub.h"
#include "j204_ic4_2.h"
#include "boardpapt.h"
#include "papt_maintain.h"
#include "powerctrl_ic4_2.h"
#include "devdrv_att.h"
#include "bspcomm.h"
#include "pacommon.h"
#include "pwr_a.h"
#ifndef MULT_PROGRESS_S
#include "sfp.h"
#endif
#if defined MULT_PROGRESS_S || defined SINGLE_PROGRESS
#include "cellcfgapi.h"
#endif
#include "oneclick_collect.h"
#include "devdrv_tempsensor.h"
#include "rruinfo.h"
#include "fpgaloadprocess.h"

#include "devdrv_transceiver.h"
#include "rftable_load.h"

#include "linkcfgcommon.h"
#include "boardversionload.h"
#include "ru_basedef.h"
#include "devdrv_att.h"
#include "gainctrl_ic4_2.h"
#include "pa_ic4_2_gridvolt.h"
#include "chnmap_a.h"
#include "pa_ic4_2_curr.h"


/* 由于宏站没有UTDOA/DMIMO/SRS/汇聚节能。编译的时候可能会出错，因此采用注册的方式实现QCELL的一键采集功能，不会影响宏站 */
pOneClickUtdoaRegistFunc utdoaOneclickFunc = NULL;
pOneClickDmimoRegistFunc dmimoOneclickFunc = NULL;
pOneClickGreenRegistFunc greenOneclickFunc = NULL;
pOneClickSrsRegistFunc   srsOneclickFunc   = NULL;
/* MTS函数回调，因为在funclib下同时加上两个mts_common.h 和 mts2_common.h 一直报错*/
pMtsDiagnose mtsDiagnoseFucn = NULL;
pMts2Diagnose mts2DiagnoseFunc = NULL;
pOneClickAdiRegistFunc adiOneClickFunc = NULL;/* ADI的回调函数 */

static UINT32 s_paptIndex[BSP_MAX_PAPT_CLASS][2] = {{0,6},{7,7},{8,8},{9,11},{12,13},{14,17},{18,19},{20,20},{21,21},{22,23}};

UINT32 BspSetGreenOneClickFunc(pOneClickGreenRegistFunc greenFunc)
{
    greenOneclickFunc = greenFunc;
    return BSP_OK;
}
VOID BspGreenOneClickFunc(VOID)
{
    // INPUT_POINTER_CHECK_RETURN(greenOneclickFunc); 存在kw告警 voidret：void函数却执行返回
    if (NULL != greenOneclickFunc)
    {
        greenOneclickFunc();
    }
}

UINT32 BspSetSrsOneClickFunc(pOneClickSrsRegistFunc srsFunc)
{
    srsOneclickFunc = srsFunc;
    return BSP_OK;
}
UINT32 BspSrsOneClickFunc(VOID)
{
    INPUT_POINTER_CHECK(srsOneclickFunc);
    srsOneclickFunc();

    return BSP_OK;
}

UINT32 BspSetUtdoaOneClickFunc(pOneClickUtdoaRegistFunc utdoaFunc)
{
    utdoaOneclickFunc = utdoaFunc;
    return BSP_OK;
}
UINT32 BspUtdoaOneClickFunc(VOID)
{
    INPUT_POINTER_CHECK(utdoaOneclickFunc);
    utdoaOneclickFunc();

    return BSP_OK;
}

UINT32 BspSetDmimoOneClickFunc(pOneClickDmimoRegistFunc dmimoFunc)
{
    dmimoOneclickFunc = dmimoFunc;
    return BSP_OK;
}
UINT32 BspDmimoOneClickFunc(VOID)
{
    INPUT_POINTER_CHECK(dmimoOneclickFunc);
    dmimoOneclickFunc();

    return BSP_OK;
}

UINT32 BspSetAdiOneClickFucn(pOneClickAdiRegistFunc AdiFucn)
{
    adiOneClickFunc = AdiFucn;
    return BSP_OK;
}
UINT32 BspAdiOneClickFunc(VOID)
{
    INPUT_POINTER_CHECK(adiOneClickFunc);
    adiOneClickFunc();

    return BSP_OK;
}

UINT32 BspSetMtsDiagnoseFucn(pMtsDiagnose mtsFucn)
{
    mtsDiagnoseFucn = mtsFucn;
    return BSP_OK;
}
INT32 BspMtsOneClickFucn(INT32 chip,UINT32 option)
{
    INPUT_POINTER_CHECK(mtsDiagnoseFucn);
    return mtsDiagnoseFucn(chip, option);
}

UINT32 BspSetMts2DiagnoseFucn(pMts2Diagnose mts2Fucn)
{
    mts2DiagnoseFunc = mts2Fucn;
    return BSP_OK;
}
INT32 BspMts2OneClickFucn(INT32 chip,UINT32 option)
{
    INPUT_POINTER_CHECK(mts2DiagnoseFunc);
    return mts2DiagnoseFunc(chip, option);
}
/* Started by AICoder, pid:2d72cf931bb54b6fae7efa9ed901689e */
UINT32 BspOneClikCollectTransciver(VOID)
{
    UINT32 retVal = 0;
    UINT32 bspChan = 0xff;
    UINT32 chipType = 0xff;
    UINT32 mtsInnerChan = 0xff;
    UINT32 chipIndex = 0xff;
    UINT32 txChanNum = 0;
    UINT32 falg = 1;
    INT32 mtsChipIndexArr[3] = {0xff,0xff,0xff};/* 第一个元素是MTS2.0的芯片号，第二个元素是MTS1.0的芯片号，第三个是ADI的芯片号，如果为0xff，则表示当前机型没有使用对应的MTS芯片 */

    txChanNum = BspGetTxChannel();

    for (bspChan = 0; bspChan < txChanNum; bspChan++)
    {
        retVal = BspGetTransceiverInfoByBspChnl(bspChan,&chipType,&chipIndex,&mtsInnerChan);
        if ((DEVICE_MTS == chipType) && (0xff == mtsChipIndexArr[1]))
        {
            mtsChipIndexArr[1] = chipIndex;
            chipType = 0xff;
            chipIndex = 0xff;
        }
        else if ((DEVICE_MTS2PRE == chipType) && (0xff == mtsChipIndexArr[0]))
        {
            mtsChipIndexArr[0] = chipIndex;
            chipType = 0xff;
            chipIndex = 0xff;
        }else if ((DEVICE_AD903X == chipType) && (0xff == mtsChipIndexArr[2]))
        {
            mtsChipIndexArr[2] = chipIndex;
            chipType = 0xff;
            chipIndex = 0xff;
        }
    }

    if (0xff != mtsChipIndexArr[0])/* 使用了MTS2.0 */
    {
        for (falg = 1; falg <= 4; falg++)
        {
            BspMts2OneClickFucn(mtsChipIndexArr[0], falg);
        }
    }

    if (0xff != mtsChipIndexArr[1])/* 使用了MTS1.0 */
    {
        for (falg = 1; falg <= 4; falg++)
        {
            BspMtsOneClickFucn(mtsChipIndexArr[1], falg);
        }
    }
    
    if (0xff != mtsChipIndexArr[2])/* 使用了ADI */
    {
        BspAdiOneClickFunc();
    }

    return retVal;
}
/* Ended by AICoder, pid:2d72cf931bb54b6fae7efa9ed901689e */

UINT32 BspOneClickCollectLogQcell(VOID)
{
    UINT32 retVal = BSP_OK;

    /* --------------------------------- 版本 -------------------------------- */
    RedirPrintf("ver:-----------------------------------------------------------\n");
    verswv();

    /* --------------------------------- 小区 -------------------------------- */
    RedirPrintf("showbspcfg:----------------------------------------------------\n");
    HelpShowBspCfg();

    /* --------------------------------- 增益 -------------------------------- */
    RedirPrintf("attshow:-------------------------------------------------------\n");
    attshow();

    /* --------------------------------- 温度 -------------------------------- */
    RedirPrintf("temp:----------------------------------------------------------\n");
    temp(NULL);

    /* -------------------------------- 光模块 -------------------------------- */
    /* MULT_PROGRESS_S 宏一般在从上定义，主上不定义，因此能够区分主从 */
#ifndef MULT_PROGRESS_S
    RedirPrintf("sfpInfo:-------------------------------------------------------\n");
    BspPrintSfpInfo(0);
    BspPrintSfpInfo(1);
    RedirPrintf("power:---------------------------------------------------------\n");
    testBspGetRpuPower();
#endif

    /* --------------------------------- 功率 -------------------------------- */
    RedirPrintf("*****************bbtssi****************************************\n");
    bbtssi();
    RedirPrintf("*****************rssi******************************************\n");
    rssi(0);
    rssi(1);
    RedirPrintf("*****************powshow***************************************\n");
    powshow();
    RedirPrintf("*****************dbfs******************************************\n");
    dbfs();
    RedirPrintf("*****************attshow***************************************\n");
    attshow();
    RedirPrintf("*****************pasta*****************************************\n");
    pasta();
    RedirPrintf("*****************trxsta****************************************\n");
    trxstatus();

    /* --------------------------------- 资产 -------------------------------- */
    RedirPrintf("rruinfo:-------------------------------------------------------\n");
    rruinfo();
    RedirPrintf("BspShowProtectHeadVerInfo:-------------------------------------\n");/* 查看有没有打开直起 */
    BspShowProtectHeadVerInfo();
    RedirPrintf("BspPrnModuleInfo:----------------------------------------------\n");/* 打印保护区的东西 */
    BspPrnModuleInfo();

    /* --------------------------------- 光口 -------------------------------- */
    /* Started by AICoder, pid:230edja00a8937414deb0822f0790503a7211f90 */
    // dbgInfo("opt:----------------------------------------------------------\n");
    // retVal = BspOptAlmCollect(); 应光口要求，取消改接口调用
    /* Ended by AICoder, pid:230edja00a8937414deb0822f0790503a7211f90 */

    /* --------------------------------- 定位 ------------------------------- */
    RedirPrintf("dmm:----------------------------------------------------------\n");
    BspDmimoOneClickFunc();
    RedirPrintf("utdoa:--------------------------------------------------------\n");
    BspUtdoaOneClickFunc();
    
    /* --------------------------------- 节能 ------------------------------- */
    BspGreenOneClickFunc();
    
    /* --------------------------------- SRS ------------------------------- */
    BspSrsOneClickFunc();

    return retVal;
}

/* QCELL一键采集 */
VOID BspOneClikCollectQcell(VOID)
{
    RedirPrintf("============================ >>> BSP Collect <<< ============================\n");
    BspOneClickCollectLogQcell();

    RedirPrintf("============================ >>> OPT Collect <<< ============================\n");
#ifdef MULT_PROGRESS_S  // 包括 主片从进程 和 从片从进程
    BspHalAdaptOneClickCollectOpt(0x0000FFFF);
#else/* 包括：单片主进程、主片主进程 */
    if (0 != BspGetRpuNum())/* 主片主进程 */
    {
        BspHalAdaptOneClickCollectOpt(0xFFFF0000);
    }
    else/* 单片主进程 */
    {
        BspHalAdaptOneClickCollectOpt(0xFFFFFFFF);
    }
#endif

    RedirPrintf("============================ >>> HAL Collect <<< ============================\n");
    BspHalAdaptOneClickCollectHal();

    RedirPrintf("========================= >>> TRANSCIVER Collect <<< =========================\n");
    BspOneClikCollectTransciver();

    RedirPrintf("============================ >>> DSP Collect <<< =============================\n");
}

/* 一键采集对外提供接口 */
HelpJ204Check g_Func_J204Check = NULL;
VOID BspApiOneClickCollect(VOID)
{
    if(NOT_QCELL_MODE == BspGetPbOrBbuMode())/* 非QCELL机型 */
    {
        BspOneClickCollect();
#if defined MULT_PROGRESS_S || defined SINGLE_PROGRESS
        IcHalOptOneClickCollect();
        IcHalApiOneClickCollect();
#endif
    }
    else/* QCELL机型 */
    {
        BspOneClikCollectQcell();
    }


}

VOID BspOneClickCollect(VOID)
{
    RedirPrintf("*****************showbspcfg************************************\n");
    HelpShowBspCfg();
    RedirPrintf("*****************bbtssi****************************************\n");
    bbtssi();
    RedirPrintf("*****************rssi******************************************\n");
    rssi(0);
    rssi(1);
    RedirPrintf("*****************powshow***************************************\n");
    powshow();
    RedirPrintf("*****************dbfs******************************************\n");
    dbfs();
    RedirPrintf("*****************attshow***************************************\n");
    attshow();
    RedirPrintf("*****************pasta*****************************************\n");
    pasta();
#ifndef MULT_PROGRESS_S
    RedirPrintf("*****************BspPrintSfpInfo*******************************\n");
    BspPrintSfpInfo(0);
    BspPrintSfpInfo(1);
    RedirPrintf("*********************power*************************************\n");
    testBspGetRpuPower();
#endif
#if defined MULT_PROGRESS_S || defined SINGLE_PROGRESS
    if(NULL != g_Func_J204Check)
    {
        g_Func_J204Check();
    }
    RedirPrintf("*****************PA protection status**************************\n");
    HelpHalPaptShow();
#endif
}

VOID HelpShowBspCfg(VOID)
{
    UINT32 loop = 0;
    UINT32 chanNumTx = BspGetTxChanNum();
    UINT32 chanNumRx = BspGetRxChanNum();
    for (loop = 0; loop < chanNumTx; loop++)
    {
        RedirPrintf("**********showbspcfg chan:%u dir:TX********\n",loop);
        showbspcfg(loop,0);
    }
    for (loop = 0; loop < chanNumRx; loop++)
    {
        RedirPrintf("**********showbspcfg chan:%u dir:RX********\n",loop);
        showbspcfg(loop,1);
    }
    return;
}

VOID HelpHalPaptShow(VOID)
{
    BspClrAllDpdicAlmStatus();
    HalPaptShow(0, 0);
    return;
}

UINT32 BspSetMts2Test204c(HelpJ204Check ucFunc)
{
    INPUT_POINTER_CHECK(ucFunc);
    g_Func_J204Check = ucFunc;
    return BSP_OK;
}

/*metrics信息采集主片主进程获取电源信息*/
/* Started by AICoder, pid:34306f8c1a00f9214dda0a4bc094ef5abd44b9f2 */
UINT32 BspGetFailurePredMainChipDatSamp(T_FailPredMChipSta *ptFailPredMChipSta)
{
    UINT32 retVal = BSP_ERROR;
    T_FailPredMChipSta failPredMChipSta = {0};
    INT32 power = 0;
    INT32 voltIn = 0;
    INT32 voltOut = 0;
    INT32 pwrIn = 0;
    UINT32 pwrStatus = 0;
    UINT32 pwrSupplyAlm = 0;
    UINT32 pwrLoop = 0;
    INT32 pwrTemp = 0;

    INPUT_POINTER_CHECK(ptFailPredMChipSta);
    retVal = BspGetRruConsumedPower(0,&power);
    if(BSP_ERROR != retVal)
    {
        failPredMChipSta.PowCons = power;
    }
    retVal = BspGetPwrVolt(0,&voltIn);
    if(BSP_ERROR != retVal)
    {
        failPredMChipSta.PowVin = voltIn;
    }
    retVal = BspGetBoardVolt(0,&voltOut);
    if(BSP_ERROR != retVal)
    {
        failPredMChipSta.PowVoutBoard = voltOut;
    }
    retVal = BspGetRruOrgConsumedPower(0,&pwrIn);
    if(BSP_ERROR != retVal)
    {
        failPredMChipSta.PowPin = pwrIn;
    }
    pwrStatus = BspGetPwrVoltAlarm();
    if(pwrStatus & BSP_BIT(1))  /*过压*/
    {
        failPredMChipSta.PowAlm[1] = 1;
    }
    else if(pwrStatus & BSP_BIT(0))   /*欠压*/
    {
        failPredMChipSta.PowAlm[0] = 1;
    }
    retVal = BspGetPowerSupplyInsufficient(&pwrSupplyAlm);
    if(BSP_OK == retVal)
    {
        failPredMChipSta.PowAlmSupplyAlm = pwrSupplyAlm;
    }
    for (pwrLoop = 0; pwrLoop < BSP_MAX_PWR_NUM; pwrLoop++)
    {
        retVal = BspGetPwrTempByIndex(pwrLoop, &pwrTemp);
        if(BSP_OK == retVal)
        {
            failPredMChipSta.PwrTemp[pwrLoop] = pwrTemp;
        }
    }
    (VOID)memcpy_s(ptFailPredMChipSta, sizeof(T_FailPredMChipSta), &failPredMChipSta, sizeof(T_FailPredMChipSta));
    return retVal;
}
/* Ended by AICoder, pid:34306f8c1a00f9214dda0a4bc094ef5abd44b9f2 */

/* Started by AICoder, pid:e304fa30d6h697f1452309ece032070bb7a645f2 */
UINT32 BspGetChipPowerSta(T_FailPredSChipPowerSta  *failPredSChipPowerSta)
{
    INPUT_POINTER_CHECK(failPredSChipPowerSta);
    failPredSChipPowerSta->Res = 0;

    return BSP_OK;
}
/* Ended by AICoder, pid:e304fa30d6h697f1452309ece032070bb7a645f2 */

/*metrics信息采集从进程获取功放信息*/
/* Started by AICoder, pid:b548b666b2d39151495a0b115086766a5f556cf1 */
UINT32 BspGetPaDatSamp(T_FailPredSChipPaSta  *ptFailPredSChipPaSta)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 chanNumTx = BspGetTxChanNum();
    T_FailPredSChipPaSta failPredSChipPaSta = {0};
    UINT32 loopChan = 0;
    INT32 paTemp = 0;
    UINT32 vibasIndex = 0;
    INT32 gridVolt = 0;
    INT32 boardTemp = 0;
    UINT32 paptLoop = 0;
    UINT32 paptAlarm = 0;
    UINT32 paChan = 0;

    if(METRIC_IC_CHAN_MAX_NUM < chanNumTx)
    {
        chanNumTx = METRIC_IC_CHAN_MAX_NUM;
    }
    INPUT_POINTER_CHECK(ptFailPredSChipPaSta);
    for (loopChan = 0; loopChan < chanNumTx; loopChan++)
    {
        retVal = BspGetPaTempByChan(loopChan, &paTemp);
        if(BSP_OK == retVal)
        {
            failPredSChipPaSta.PaTemp[loopChan] = paTemp;
        }
        BspGetTxIfTssi(loopChan, 0, &failPredSChipPaSta.TxTssi[loopChan]);
        BspGetFwdCpIfTssi(loopChan, 0, &failPredSChipPaSta.FwdTssi[loopChan]);
        BspGetRevIfTssi(loopChan, 0, &failPredSChipPaSta.RevTssi[loopChan]);
        BspGetRevCpIfTssi(loopChan, 0, &failPredSChipPaSta.RevCpTssi[loopChan]);
        BspGetTxAtt(loopChan, &failPredSChipPaSta.Txatt[loopChan]);
        BspGetPrxAtt(loopChan, &failPredSChipPaSta.PrxAtt[loopChan]);
        BspGetPrxAttDpd(loopChan, &failPredSChipPaSta.prxAttDpd[loopChan]);
        BspHalAdaptGetK0Gain(loopChan, &failPredSChipPaSta.preCfrGain[loopChan]);
        BspGetKfGain(loopChan, &failPredSChipPaSta.preDpdGain[loopChan]);
        BspGetKdGain(loopChan, &failPredSChipPaSta.KdGain[loopChan]);
        failPredSChipPaSta.PaSta[loopChan] = BspGetPaSwitch(loopChan);
        failPredSChipPaSta.PaNormalFlg[loopChan] = BspGetPaNormalFlag(loopChan);
        for (vibasIndex = 0; vibasIndex < BSP_MAX_VBIAS_NUM; vibasIndex++)
        {
            retVal = BspGetPaGirdValByType(loopChan, vibasIndex, &gridVolt);
            if(retVal != BSP_ERROR)
            {
                failPredSChipPaSta.PaGridVol[loopChan][vibasIndex] = gridVolt;
            }
        }
        retVal = BspGetBoardTemp(0, &boardTemp);
        if(BSP_OK == retVal)
        {
            failPredSChipPaSta.BpardTemp = boardTemp;
        }
        for (paptLoop = 0; paptLoop < BSP_MAX_PAPT_CLASS; paptLoop++)
        {
            retVal = BspGetPaptByChan(loopChan, paptLoop, &paptAlarm);
            if(retVal == BSP_OK)
            {
                failPredSChipPaSta.PaptSta[loopChan][paptLoop] = paptAlarm;
            }
        }
        retVal = BspGetPaChnByRfChn(loopChan, TX, &paChan);
        if(BSP_OK == retVal)
        {
            retVal = BspGetPaAdcVal(paChan, &failPredSChipPaSta.PaAdVal[loopChan]);
        }
    }
    (VOID)memcpy_s(ptFailPredSChipPaSta, sizeof(T_FailPredSChipPaSta), &failPredSChipPaSta, sizeof(T_FailPredSChipPaSta));
    return retVal;
}
/* Ended by AICoder, pid:b548b666b2d39151495a0b115086766a5f556cf1 */

/*通过bsp通道获取功放温度*/
/* Started by AICoder, pid:ad17fl662cp91d1142df08a6f0e6df2c84616b7b */
UINT32 BspGetPaTempByChan(UINT32 chan, INT32 *temp)
{
    UINT32 retVal = BSP_OK;
    UINT32 paChan = 0;
    INT32  iRet = 0;
    CHAR devIdName[20] = {0,};

    INPUT_POINTER_CHECK(temp);
    retVal =  BspGetPaChnByRfChn(chan, TX, &paChan);
    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }
    iRet = snprintf_s(devIdName, sizeof(devIdName), "TempPa%d", paChan);
    SNPRINTF_S_CHECK(iRet, sizeof(devIdName));

    return BspGetTempByDevName((UINT8 *)devIdName, temp);
}
/* Ended by AICoder, pid:ad17fl662cp91d1142df08a6f0e6df2c84616b7b */

/*通过电源索引获取电源温度*/
/* Started by AICoder, pid:o210fjf0b0i785914e590b2c40dbc311a13003ea */
UINT32 BspGetPwrTempByIndex(UINT32 index, INT32 *temp)
{
    INT32  iRet = 0;
    CHAR devIdName[20] = {0,};

    INPUT_POINTER_CHECK(temp);
    iRet = snprintf_s(devIdName, sizeof(devIdName), "TempRpdc%d", index);
    SNPRINTF_S_CHECK(iRet, sizeof(devIdName));

    return BspGetTempByDevName((UINT8 *)devIdName, temp);
}
/* Ended by AICoder, pid:o210fjf0b0i785914e590b2c40dbc311a13003ea */

/* Started by AICoder, pid:p1aa793415c987f1457e081f5069444836e346cf */
/* 获取功放保护状态，入参paptClass表示功放保护的类别 */
UINT32 BspGetPaptByChan(UINT32 chan, UINT32 paptClass, UINT32 *alarmSta)
{
    UINT32 retVal = 0;
    UINT32 paAlarmMask = 0;
    UINT32 daAlarmMask = 0;
    UINT32 paOffMask = 0;
    UINT32 daOffMask = 0;
    UINT32 uiNum = 0;
    UINT32 loop = 0;
    UINT32 startClass = 0;
    UINT32 endClass = 0;
    UINT32 uiDaEnVal = 0;
    UINT32 uiPaEnVal = 0;
    UINT32 paAlarmVal = 0;
    UINT32 daAlarmVal = 0;

    INPUT_POINTER_CHECK(alarmSta);
    if(paptClass >= BSP_MAX_PAPT_CLASS)
    {
        return BSP_ERROR;
    }

    retVal |= IcHalApiPaptDaLatchStaRpt(chan, &paAlarmMask, &uiNum);
    retVal |= IcHalApiGetPaptMonitorRpt(chan, &daAlarmMask, &uiNum);
    retVal |= IcHalApiGetPaptPaOffMask(chan, &paOffMask, &uiNum);
    retVal |= IcHalApiGetPaptDaOffMask(chan, &daOffMask, &uiNum);

    if(BSP_OK != retVal)
    {
        return BSP_ERROR;
    }

    startClass = s_paptIndex[paptClass][0];
    endClass = s_paptIndex[paptClass][1];

    for (loop = startClass; loop <= endClass; loop++)
    {
        uiDaEnVal = (daOffMask & BSP_BIT_SET(loop));
        uiPaEnVal = (paOffMask & BSP_BIT_SET(loop));
        paAlarmVal = (paAlarmMask & BSP_BIT_SET(loop));
        daAlarmVal = (daAlarmMask & BSP_BIT_SET(loop));

        if ((uiDaEnVal && daAlarmVal) || (uiPaEnVal && paAlarmVal)) {
            *alarmSta = 1;
            return BSP_OK;
        }
    }
    *alarmSta = 0;
    return BSP_OK;
}
/* Ended by AICoder, pid:p1aa793415c987f1457e081f5069444836e346cf */

/* Started by AICoder, pid:z904a9e8162c131142980be8104d432b73c95239 */
/* 从进程给高层上报维测信息 */
UINT32 BspGetFailurePredSlaveChipDatSamp(UINT32 ChipId, T_FailPredSChipSta *ptFailPredSChipSta)
{
    UINT32 retVal = 0;
    T_DldvgaInfo tFailPredSChipDlDvgaSta = {0};
    T_FailPredSChipPaSta     tFailPredSChipPaSta = {0};
    T_FailPredSChipPowerSta  tFailPredSChipPowerSta = {0};

    INPUT_POINTER_CHECK(ptFailPredSChipSta);
    retVal |= IcHalApiGetMetricsDldvgaInfo(&tFailPredSChipDlDvgaSta);
    retVal |= BspGetPaDatSamp(&tFailPredSChipPaSta);
    retVal |= BspGetChipPowerSta(&tFailPredSChipPowerSta);

    (VOID)memcpy_s(&(ptFailPredSChipSta->tFailPredSChipDlDvgaSta), sizeof(T_DldvgaInfo), &tFailPredSChipDlDvgaSta, sizeof(T_DldvgaInfo));
    (VOID)memcpy_s(&(ptFailPredSChipSta->tFailPredSChipPaSta), sizeof(T_FailPredSChipPaSta), &tFailPredSChipPaSta, sizeof(T_FailPredSChipPaSta));
    (VOID)memcpy_s(&(ptFailPredSChipSta->tFailPredSChipPowerSta), sizeof(T_FailPredSChipPowerSta), &tFailPredSChipPowerSta, sizeof(T_FailPredSChipPowerSta));
    return retVal;
}
/* Ended by AICoder, pid:z904a9e8162c131142980be8104d432b73c95239 */

/* Started by AICoder, pid:kbda6x67dew9edf14e950ad780a9101941054082 */
UINT32 BspGetMetricsSerdesInfo(T_SerdesInfo *pcSerdesInfo)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 chipId = BspGetRpuId();

    INPUT_POINTER_CHECK(pcSerdesInfo);
    if(0 == chipId)
    {
#ifdef MULT_PROGRESS_S
        return retVal; //主片上的serdes信息只能在主进程获取
#else
        retVal = IcHalApiGetMetricsSerdesInfo(pcSerdesInfo);
#endif
    }
    else
    {
        retVal = IcHalApiGetMetricsSerdesInfo(pcSerdesInfo);
    }
    return retVal;
}
/* Ended by AICoder, pid:kbda6x67dew9edf14e950ad780a9101941054082 */

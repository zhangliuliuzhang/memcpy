/*****************************************************************************
* 版权所有(C) 2025, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : powerctrl_catchdata_ic4_2.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了RRU全链路采数功能声明
* 注意事项 : 无
* 作    者 : 10346953
* 创建日期 : 2025-10-21
* 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

/* linux 系统头文件 */
#include <fcntl.h>
#include <math.h>
#include <linux/sysctl.h>
#include <sys/mman.h>
#include <pthread.h>
#include <errno.h>

/* bsp公共头文件 */
#include "powerctrl_catchdata_ic4_2.h"
#include "bsppub.h"
#include "bspcommon.h"
#include "funccommon_a.h"
#include "exprn.h"
#include "powerctrlcommon.h"
#include "ichaladapt_ic4_2.h"
#include "chnmap_a.h"

static UINT32 s_catchDataChan      = 0;
static UINT32 s_catchDataPointNo   = 0;
static UINT32 s_catchDataCarrierNo = 0;
static UINT32 s_catchDataRadioMode = 0;
static UINT32 s_catchDataSlotNo    = 0;

static UINT32 s_supprotDpdicCatchDataFlag = NO_SUPPROT_DPDIC_CATCHDATA_FLAG;
static UINT32 s_catchDataCategory  = 0;

static UINT32 s_catchDataFromIcdifRunFlag   = IC_DIF_CATCH_DATA_FREE;
static UINT32 s_catchDataFromIcdifRunRetVal = BSP_ERROR;

UINT32 BspSetDpdicCatchDataPara(UINT32 chan, UINT32 pointNo, UINT32 carrierNo, UINT32 radioMode, UINT32 slotNo)
{
    BspLog(LOG_LEVEL_0, "%s chan %d, pointNo %d, carrierNo %d, radioMode %d, slotNo %d\n", \
        __FUNCTION__, chan, pointNo, carrierNo, radioMode, slotNo);
    s_catchDataChan      = chan;
    s_catchDataPointNo   = pointNo;
    s_catchDataCarrierNo = carrierNo;
    s_catchDataRadioMode = radioMode;
    s_catchDataSlotNo    = slotNo;

    return BSP_OK;
}

UINT32 BspDpdicCatchDataFromIcDif(VOID)
{
    static INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack    = 10;
    
    if(IC_DIF_CATCH_DATA_FREE == s_catchDataFromIcdifRunFlag)
    {
        lTaskID = taskSpawn("BspDpdicCatchDataFromIcdifThread", 100, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspDpdicCatchDataFromIcDifRun, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    }
    else
    {
        BspLog(LOG_LEVEL_0, "%s Last Thread still run !!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    

    if (BSP_ERROR == (UINT32)lTaskID)
    {
        s_catchDataFromIcdifRunFlag = IC_DIF_CATCH_DATA_FREE;
        BspLog(LOG_LEVEL_0, "%s !! Creat Thread Error !!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    s_catchDataFromIcdifRunFlag = IC_DIF_CATCH_DATA_RUNNING;

    return BSP_OK;
}

UINT32 BspCheckDpdicChanNo(UINT32 chan, UINT32 dir)
{
    UINT32 retVal = BSP_OK;

    if (TX == dir)
    {
        if (chan >= BspGetTxChannel())
        {
            BspLog(LOG_LEVEL_0, "%s bspchan [%d] Tx error !!!\n", __FUNCTION__, chan);
            retVal = BSP_ERROR;
        }
    }
    else
    {
        if (chan >= BspGetRxChannel())
        {
            BspLog(LOG_LEVEL_0, "%s bspchan [%d] Rx error !!!\n", __FUNCTION__, chan);
            retVal = BSP_ERROR;
        }
    }

    return retVal;
}

UINT32 BspDpdicCatchDataFromIcDifRun(VOID)
{
    UINT32 retVal    = BSP_OK;
    UINT32 bspChan   = s_catchDataChan;
    UINT32 pointNo   = s_catchDataPointNo;
    UINT32 carrierNo = s_catchDataCarrierNo;
    UINT32 radioMode = s_catchDataRadioMode;
    UINT32 slotNo    = s_catchDataSlotNo;
    UINT32 chipId    = 0;
    UINT32 difChan   = 0;
    UINT32 dir       = 0;
    UINT32 index     = 0;
    UINT32 tx_point[IC_DIF_TX_POINT_NUM] = {IC_DIF_DL_RCF_OUTPORT, IC_DIF_DL_CFR_OUTPORT, IC_DIF_DL_DPD_OUTPORT};
    
    dir = RX;

    for (index = 0; index < IC_DIF_TX_POINT_NUM; index ++)
    {
        if (pointNo == tx_point[index])
        {
            dir = TX;
            break;
        }
    }

    if(BSP_OK != BspCheckDpdicChanNo(bspChan, dir))
    {
        s_catchDataFromIcdifRunRetVal = BSP_ERROR;
        s_catchDataFromIcdifRunFlag = IC_DIF_CATCH_DATA_FREE;
        return BSP_ERROR;
    }

    if(BSP_OK != BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan))
    {
        BspLog(LOG_LEVEL_0, "%s bspchan %d cant get dif chan \n", __FUNCTION__, bspChan);
        s_catchDataFromIcdifRunRetVal = BSP_ERROR;
        s_catchDataFromIcdifRunFlag = IC_DIF_CATCH_DATA_FREE;
        return BSP_ERROR;
    }

    BspLog(LOG_LEVEL_0, "%s start, chan[bsp %d dif %d dir = %d] carrId [%d] radioMode [%d] slot [%d] pos [%d]\n", __FUNCTION__, bspChan, difChan, dir, carrierNo, radioMode, slotNo, pointNo);
    

    retVal = BspHalAdaptCatchdataSampleBySlot(difChan, carrierNo, radioMode, slotNo, pointNo);
    s_catchDataFromIcdifRunRetVal = retVal;
    s_catchDataFromIcdifRunFlag = IC_DIF_CATCH_DATA_FREE;
    BspLog(LOG_LEVEL_0, "%s retVal = %d \n", __FUNCTION__, retVal);
    
    return retVal;
}

UINT32 BspDpdicCatchDataFromIcDsp(VOID)
{
    UINT32 retVal    = BSP_OK;
    UINT32 bspChan   = s_catchDataChan;
    UINT32 pointNo   = s_catchDataPointNo;
    UINT32 chipId    = 0;
    UINT32 difChan   = 0;
    UINT32 dir       = 0;
    UINT32 index     = 0;
    UINT32 tx_point[DSP_TX_POINT_NUM] = {DSP_DL_FEEDBACK_INPORT, DSP_DL_DPDCAL_DATA, DSP_DL_DPDLUT_DATA, DSP_TS_DATA, 
                                        DSP_TS_STANDARD_SOURCE, DSP_TRAP_DATA, DSP_TRAP_TABLE, DSP_SSC_DATA, DSP_SSC_TABLE};
    UINT32 sw        = START_SAMPLE;
    
    dir = RX;
    
    for (index = 0; index < DSP_TX_POINT_NUM; index ++)
    {
        if (pointNo == tx_point[index])
        {
            dir = TX;
            break;
        }
    }

    if(BSP_OK != BspCheckDpdicChanNo(bspChan, dir))
    {
        return BSP_ERROR;
    }

    if(BSP_OK != BspGetDifInfoByBspChn(bspChan, dir, &chipId, &difChan))
    {
        BspLog(LOG_LEVEL_0, "%s bspchan %d cant get dif chan \n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    BspLog(LOG_LEVEL_0, "%s start sw = 0x%x, chan[bsp %d dif %d dir = %d] point [%d]\n", __FUNCTION__, sw, bspChan, difChan, dir, pointNo);
    retVal = BspDpdicCatchDspData(sw, difChan, pointNo);

    BspLog(LOG_LEVEL_0, "%s retVal = %d \n", __FUNCTION__, retVal);
    return retVal;
}

UINT32 BspGetSupportDpdicCatchdataFlag(VOID)
{
    return s_supprotDpdicCatchDataFlag;
}

UINT32 BspSetSupportDpdicCatchdataFlag(UINT32 flag)
{
    BspLog(LOG_LEVEL_0, "%s flag: %d\n", __FUNCTION__, flag);
    s_supprotDpdicCatchDataFlag = flag;
    return BSP_OK;
}

UINT32 BspGetDpdicCatchDataCategory(UINT32 pointNo)
{
    UINT32 index     = 0;
    UINT32 icDifPoint[IC_DIF_POINT_NUM] = {IC_DIF_DL_RCF_OUTPORT, IC_DIF_DL_CFR_OUTPORT, IC_DIF_DL_DPD_OUTPORT, IC_DIF_UL_DDC_INPORT, IC_DIF_UL_RCF_OUTPORT};
    UINT32 dspPoint[DSP_POINT_NUM] = {DSP_DL_FEEDBACK_INPORT, DSP_DL_DPDCAL_DATA, DSP_DL_DPDLUT_DATA, DSP_TS_DATA, DSP_TS_STANDARD_SOURCE, DSP_TRAP_DATA, DSP_TRAP_TABLE,
                                    DSP_SSC_DATA, DSP_SSC_TABLE, DSP_PIMC_DATA, DSP_PIMC_TABLE};

    for (index = 0; index < IC_DIF_POINT_NUM; index ++)
    {
        if(pointNo == icDifPoint[index])
        {
            s_catchDataCategory = CATCH_IC_DIF_DATA;
            BspLog(LOG_LEVEL_0, "%s collect ic_dif data [%d] \n", __FUNCTION__, pointNo);
            return CATCH_IC_DIF_DATA;
        }
    }

    for (index = 0; index < DSP_POINT_NUM; index ++)
    {
        if(pointNo == dspPoint[index])
        {
            s_catchDataCategory = CATCH_DSP_DATA;
            BspLog(LOG_LEVEL_0, "%s collect dsp data [%d] \n", __FUNCTION__, pointNo);
            return CATCH_DSP_DATA;
        }
    }

    s_catchDataCategory = 0;
    BspLog(LOG_LEVEL_0, "%s point error, cant find [%d] \n", __FUNCTION__, pointNo);
    return BSP_ERROR;
}

UINT32 BspEnableDpdicCatchData(UINT32 pointNo)
{
    UINT32 retVal = BSP_OK;

    BspLog(LOG_LEVEL_0, "%s pointNo: %d\n", __FUNCTION__, pointNo);

/*当前机型是否支持采数*/
    if(SUPPROT_DPDIC_CATCHDATA_FLAG != BspGetSupportDpdicCatchdataFlag())
    {
        BspLog(LOG_LEVEL_0, "%s can't support catch data!\n", __FUNCTION__);
        return BSP_ERROR;
    }

/*本次下发的采数点与下发过的参数是否匹配*/
    if(s_catchDataPointNo == pointNo)
    {
        BspLog(LOG_LEVEL_0, "%s pointNo %d has been enabled\n", __FUNCTION__, pointNo);
    }
    else
    {
        BspLog(LOG_LEVEL_0, "%s pointNo %d not match para \n", __FUNCTION__, pointNo);
        return BSP_ERROR;
    }

/*识别中频/dsp采数点 进入对应类别进行采数*/
    if (CATCH_IC_DIF_DATA == BspGetDpdicCatchDataCategory(pointNo))
    {
        retVal = BspDpdicCatchDataFromIcDif();
    }
    else if (CATCH_DSP_DATA == BspGetDpdicCatchDataCategory(pointNo))
    {
        retVal = BspDpdicCatchDataFromIcDsp();
    }
    else
    {
        return BSP_ERROR;
    }

    return retVal;
}

UINT32 BspGetCatchDataResultFromIcDif(VOID)
{
    UINT32 retVal = BSP_OK;

/*采数执行失败或者仍在执行中都算失败  这个判断的前提是在成功发起了采数*/
    if((BSP_ERROR == s_catchDataFromIcdifRunRetVal) || IC_DIF_CATCH_DATA_RUNNING == s_catchDataFromIcdifRunFlag)
    {
        BspLog(LOG_LEVEL_0, "%s pointNo %d catch error! running = %d, ret = %d\n", __FUNCTION__, s_catchDataPointNo, s_catchDataFromIcdifRunFlag, s_catchDataFromIcdifRunRetVal);
        retVal = BSP_ERROR;
        return retVal;
    }
    BspLog(LOG_LEVEL_0, "%s pointNo %d catch success!\n", __FUNCTION__, s_catchDataPointNo);
/*避免对下一个新的采数结果判断有干扰*/
    s_catchDataFromIcdifRunRetVal = BSP_ERROR;

    return retVal;
}

UINT32 BspGetCatchDataResultFromDsp(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspDpdicGetCatchDspDataStatus();

    return retVal;
}

UINT32 BspGetCatchDataFinishFlag(VOID)
{
    UINT32 retVal = BSP_OK;
    BspLog(LOG_LEVEL_0, "%s start \n", __FUNCTION__);

    if (CATCH_IC_DIF_DATA == s_catchDataCategory)
    {
        retVal = BspGetCatchDataResultFromIcDif();
    }
    else if (CATCH_DSP_DATA == s_catchDataCategory)
    {
        retVal = BspGetCatchDataResultFromDsp();
    }
    else
    {
        return BSP_ERROR;
    }

    return retVal;
}

UINT32 testUT_s_catchDataCategory(UINT32 flag)
{
    s_catchDataCategory = flag;
    return BSP_OK;
}

UINT32 testUT_s_catchDataFromIcdifRunFlag(UINT32 flag)
{
    s_catchDataFromIcdifRunFlag = flag;
    return BSP_OK;
}

UINT32 testUT_s_catchDataFromIcdifRunRetVal(UINT32 flag)
{
    s_catchDataFromIcdifRunRetVal = flag;
    return BSP_OK;
}


/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : powerctrl_ic4.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 :   00125510
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 00125510
* 修改日戳: 2019-1-27 14:45:34
* 变更说明: 创建文件
* $记录2
* 变 更 单: $0000000(N/A)
* 责 任 人: 刘巨波10258234
* 修改日戳: 2022-3-7 14:45:34
* 变更说明: 基于IC4.0代码完成IC4.2功率检测代码
*----------------------------------------------------------------------------
*/


#include <math.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "ru_basedef.h"
#include "ru_univdef.h"
#include "powerctrl_ic4_2.h"
#include "powerctrlapi.h"
#include "powerctrl_comps_ic4_2.h"
#include "regdrv.h"
#include "funccommon_chncfg.h"
#include "chnmap_a.h"
#include "chnmapcommon.h"
#include "freqcfgcommon.h"
#include "funccommon_carrmap.h"
#include "devdrv_tempsensor.h"
#include "gainctrl_ic4_2.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"
#include "devdrv_att.h"
#include "ichaladapt_ic4_2.h"
#include "funccommon_a.h"
#include "pa_ic4_2_gridvolt.h"
#include "rx_gunb_cfg.h"
#include "cfrcommon.h"
#include "rftable_paensavadj.h"

#include "rev.h"
#if defined(CFR_REFACTOR)
#include "cfr_dpdic.h"
#else
#include "cfr_ic4_2.h"
#endif
#include "rftable_padacset.h"
#include "ichaladapt_ic4_2.h"
#include "boardid.h"
#include "gainctrlapi.h"
#include "tsg.h"
#include "funccommon_fpga.h"
#include "optctrl_cpri_ic4_2.h"

#define UMTS_CARR_POW_FLAG        (0xFFFF) // umts 功率降额区分逻辑机型临时处理
#define POW_MIX_CARR_ID            0xFFFF
#if 0
#define TCPW_CHAN_ALL              0xff
#define MAX_CHAN_NUM               32
#endif
//(1000*log10((a)+0.000001)-9031)
#define GET_POW_DBFS(a,bw)    ((INT32)(1000*(log10((DOUBLE)(a)+0.000001)-log10((DOUBLE)(1<<(2*bw-2))+0.000001))-0.5))
#define GET_POW_DBFS_FPGA(a,bw)    ((INT32)(1000*(log10_s((DOUBLE)(a), -6.0)-log10_s((DOUBLE)(1<<(2*bw-2)), -6.0))-0.5))
#define NBICACC_PROCESS_PRIORITY       (130)          /* 注册优先级130对应linux优先级97-130/3 = 54*/
#define MAIN_LOG_OPT_CNT                (2)
#define MIN_DBFS (-7826)
#define RCUA_CAL_NUM                     (3)
#define RCUA_FREQ_NUM                    (5)
static UINT32 s_nbicAccClrThreadSw = SWITCH_ON;

static T_PaAlarmCfg paTempCfgRcord = {0};

static INT32  s_gRadioDetaGain[DIF_RADIOMODE_MAX] = {0};
static UINT32 s_reducePaVoltFlag = NO_SUPP_REDUCE_PA_VOLT;
static UINT32 s_rssiTypeFlag = BSP_HALADAPT_RSSI_LONG_FRAME;
static INT32 s_paVoltDelt = 0;
INT32 g_acFwdVal[RCUA_CAL_NUM][RCUA_FREQ_NUM] = { 0 };
INT32 g_acRevVal[RCUA_CAL_NUM][RCUA_FREQ_NUM] = { 0 };
INT32 g_fwdDbmVal[RCUA_CAL_NUM] = {-9031, -9031, -9031};
INT32 g_revDbmVal[RCUA_CAL_NUM] = {-9031, -9031, -9031};
UINT32 g_scalarVswr[RCUA_CAL_NUM] = {BSP_INVALID_VALUE, BSP_INVALID_VALUE, BSP_INVALID_VALUE};

#define _LINEAR_INSERT(x,x1,y1,x2,y2) ((INT32)(((FLOAT)((y2) - (y1)) / ((x2) - (x1) + 0.000001)) * ((x) - (x1)) + (y1)+0.5))
#if 0
#define VSWR_GAMA_MIN             (0.01)
#define VSWR_GAMA_MAX             (0.818181)
#define EPSLON                    (1e-6)
#define CALIBRAION_VALUE_15BIT    (8428)


static UINT32 s_VswrVal[MAX_TX_CHAN][2] = {0};

static UINT32 s_AcVswrEnable = 0;

static UINT32 s_AcVswrVal[MAX_CHAN_NUM] = {0};
static INT32 s_AcVswrFwdVal[MAX_CHAN_NUM] = {0};
static INT32 s_AcVswrRevVal[MAX_CHAN_NUM] = {0};

static INT32 s_AcVswrFwdDbfs[MAX_CHAN_NUM] = {0};
static INT32 s_AcVswrRevDbfs[MAX_CHAN_NUM] = {0};

static UINT32 s_powDectectMode = 1;

static UINT32 s_powCalcMode = 0;
#endif
#define POW_TXCHAN_CHECK(ch)       \
{                                  \
    if ((ch) >= BspGetTxBspChanNum()) \
    {                              \
        return BSP_ERROR;          \
    }                              \
}

#define POW_RXCHAN_CHECK(ch)       \
{                                  \
    if ((ch) >= BspGetRxLogicChanNum()) \
    {                              \
        return BSP_ERROR;          \
    }                              \
}


#define POW_CARR_CHECK(ca)         \
{                                  \
    if ((ca) >= BspGetBspCarrNum()) \
    {                              \
        return BSP_ERROR;          \
    }                              \
}
#if 0
#define POW_DATA_CALC_CHECK(tpow)       \
{                                  \
    if (s_powDataCalc.tpow.num == 0 || s_powDataCalc.tpow.head == NULL) \
    {                              \
        return BSP_ERROR;          \
    }                              \
}

#define POW_DATA_REPORT_CHECK(tpow)       \
{                                  \
    if (s_powDataReport.tpow.num == 0 || s_powDataReport.tpow.head == NULL) \
    {                              \
        return BSP_ERROR;          \
    }                              \
}


#define GET_POW_DATA_CALC(tpow,bspchan,bspcarr,elems)   \
    GetPowDataBuf(s_powDataCalc.tpow.head,s_powDataCalc.tpow.num,bspchan,bspcarr,elems)

#define GET_POW_DATA_REPORT(tpow,bspchan,bspcarr,elems)   \
    GetPowDataBuf(s_powDataReport.tpow.head,s_powDataReport.tpow.num,bspchan,bspcarr,elems)

#define POW_DATA_UPDATE(tpow,elems)   \
    memcpy(s_powDataReport.tpow.head, s_powDataCalc.tpow.head, (s_powDataCalc.tpow.num)*(elems))


typedef struct tagT_PowProperty
{
    UINT32 valid;   /* 是否有效 */
    UINT32 bspChan; /* BSP通道号 */
    UINT32 bspCarr; /* BSP载波号,对于合载波时为POW_MIX_CARR_ID */
}T_PowProperty;

typedef struct tagT_BbTssiPow
{
    T_PowProperty  prop;
    INT32          powDbfs;
}T_BbTssiPow;

typedef struct tagT_RssiPow
{
    T_PowProperty  prop;
    INT32          powDbfs;
    INT32          powDbm;
}T_RssiPow;

typedef struct tagT_FwdPow
{
    T_PowProperty  prop;
    INT32          ifTssiPowDbfs;    /* 对应反馈功率的合载波TSSI */
    INT32          fwdPowDbfs;       /* 反馈功率 */
    INT32          fwdPowDbm;
}T_FwdPow;

typedef struct tagT_RevPow
{
    T_PowProperty  prop;
    INT32          ifTssiPowDbfs;    /* 对应反射功率的合载波TSSI */
    INT32          revPowDbfs;       /* 反射功率 */
    INT32          revPowDbm;
}T_RevPow;

typedef struct tagT_PowList
{
    UINT32 num;
    VOID   *head;
} T_PowList;

typedef struct tagT_PowData
{
    T_PowList    tssi;
    T_PowList    rssi;
    T_PowList    fwd;
    T_PowList    rev;
}T_PowData;

static T_PowCtrlPara s_powCtrlPara = {0,};
static T_PowData s_powDataCalc = {0,};
static T_PowData s_powDataReport = {0,};

static SEM_ID semPowDet = NULL;
#endif
typedef struct
{
    INT32 tssiPowAvg;
    INT32 dlBankDgain;
    INT32 dlPreDgain;
} T_PaNormalInfo;
#define MAX_POW_CAL_NUM 10

static T_TssiPara s_TssiInfo[BSP_HALADAPT_IC_CHAN_MAX_NUM][BSP_MAX_CARR_NUM] = {0};
static T_TxPow sTxPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM][MAX_POW_CAL_NUM] = {0};
static T_TxPow sVswrPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM][MAX_POW_CAL_NUM] = {0};
static T_TxPow sTxPowAvgVal[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
static T_TxAllChanPow sDspSetTxPowAvgVal = {0};/*给DSP传递前向功率结构体*/
static T_TxAllChanPow sDspGetTxPowAvgVal = {0};/*从DSP获取功率结构体*/
static T_TxPow sDspTxPowAvgVal[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};/*DSP功率记录*/
static T_DspPowCalcPara sDspPowCalcPara = {0};/*DSP功率检测相关参数*/
static UINT32 g_spePowCalcWay[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};/*功率检测方式，目前定义0：正常IC功率检测 1：DSP GP位置发数参数功率检测*/
static T_TxPow sVswrAvgVal[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
static T_TxPow sTxFwdRevPowerVal[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
/* static T_TxPow sTxPcPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
static T_TxPow sTxMaxPcPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
static T_TxBbPcPow sTxBbPcPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM][BSP_MAX_CARR_NUM] = {0};
static T_TxBbPcPow sTxMaxBbPcPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM][BSP_MAX_CARR_NUM] = {0};
static T_TxPow sTxReportPcPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
static T_TxBbPcPow sTxReportBbPcPowVal[BSP_HALADAPT_IC_CHAN_MAX_NUM][BSP_MAX_CARR_NUM] = {0}; */
static UINT32 g_dbgisr=0;
static T_TempSourcePara s_TempSourcePara = {TEMP_SOURCE_HW, TEMP_SOURCE_HW};
static UINT16 s_gsmStaticPowLevel[MAX_TX_CHAN] = {0}; // 分载波增益需要衰减的值,单位db
/*功率检测相关*/
static UINT32 s_virtualCarrNo = 0;
static INT32 s_fwdPowMwDelta[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
T_DefCableLossVaild g_ulSlaveCableLossVailFlag[BSP_MAX_TX_CHAN] = {0};
//功放保护的标志信号，‘1’为异常保护发生，BSP驻波计算过程中，丢掉当前采集值，认为无效值；同时停止动态功控调整。‘0’表示正常有效。采用读清零方式。
//#define REG_POWERCTRL_TSSI_ALM_STATUS       0
static UINT32 g_frStaChangeFlag[MAIN_LOG_OPT_CNT] = {0};
static UINT32 g_frStaOkCnt[MAIN_LOG_OPT_CNT] = {0};
static UINT32 g_lastOptRptFrAlmCnt[MAIN_LOG_OPT_CNT] = {0};
static UINT32 g_currOptRptFrAlmCnt[MAIN_LOG_OPT_CNT] = {0};

UINT32 g_ulPowCalcEnable[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0,0,0,0,0,0,0,0};//通道开关默认关闭

/* 求平均的时隙计数,最大为10 */
UINT32 g_ulPowAvgSlotCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM] =  {2,2,2,2,2,2,2,2};
UINT32 g_ulVswrAvgSlotCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {2,2,2,2,2,2,2,2};

UINT32 g_ulVswrUpdateCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0};/* 标量驻波所需功率统计序号 */
UINT32 g_aulTxPowUpdateCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0};/* 标量驻波所需功率统计序号 */
#if 0
UINT32 g_aulTxPcPowUpdateCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0};/*PC功率统计序号 */
UINT32 g_ulBbPcPowCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM]={3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3};
#endif
UINT32 g_oldvswr[BSP_HALADAPT_IC_CHAN_MAX_NUM][MAX_BAND_NUM]= {
                                                                {1200000,1200000},
                                                                {1200000,1200000},
                                                                {1200000,1200000},
                                                                {1200000,1200000},
                                                                {1200000,1200000},
                                                                {1200000,1200000},
                                                                {1200000,1200000},
                                                                {1200000,1200000},
                                                              };
INT32 g_lPowDbmThreshold[BSP_HALADAPT_IC_CHAN_MAX_NUM][THRESHOLD_NUM] = {
                                                                            {600,600,600,600},
                                                                            {600,600,600,600},
                                                                            {600,600,600,600},
                                                                            {600,600,600,600},
                                                                            {600,600,600,600},
                                                                            {600,600,600,600},
                                                                            {600,600,600,600},
                                                                            {600,600,600,600},
                                                                        };
INT32 g_lVswrThreshold[BSP_HALADAPT_IC_CHAN_MAX_NUM][THRESHOLD_NUM] =   {
                                                                            {2800,2800,2800,2800},
                                                                            {2800,2800,2800,2800},
                                                                            {2800,2800,2800,2800},
                                                                            {2800,2800,2800,2800},
                                                                            {2800,2800,2800,2800},
                                                                            {2800,2800,2800,2800},
                                                                            {2800,2800,2800,2800},
                                                                            {2800,2800,2800,2800},
                                                                        };
#if 0
UINT32 g_pcPowDbmThred = 0;
UINT32 g_bbPcPowDbmThred = 0;
#endif
UINT32 g_ulPowDataInvalidFlag[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0,};
UINT32 g_ulPowDataInvalidCause[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0,};
SEM_ID g_semPowerUpdate[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {NULL,};   /*功率检测结果更新*/

#define MAX_UPDATE_CNT          (0xffffffff) /*计数最大值*/

static UINT32 s_supportBandVswrFlag = NO_SUPPORT;
static UINT32 s_cancelScalarVswrFlag = NO_SUPPORT;

T_CableLossRecord g_ulTxRfCableLoss[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
T_CableLossRecord g_ulPrxRfCableLoss[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
INT32 g_ulCableLossBaseTemp[BSP_IC42_MAX_TX_CHAN_NUM] = {2000,2000,2000,2000,2000,2000,2000,2000};
static INT32 sVswrPowThresHold[BSP_HALADAPT_IC_CHAN_MAX_NUM][THRESHOLD_NUM] = {
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                                {MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD,MAX_VSWR_THRESHOLD},
                                                                              };

static INT32 g_RevDerateVal[BSP_IC42_MAX_TX_CHAN_NUM] =
{
                            REV_PRO_ATTENUATION_VALUE,
                            REV_PRO_ATTENUATION_VALUE,
                            REV_PRO_ATTENUATION_VALUE,
                            REV_PRO_ATTENUATION_VALUE,
                            REV_PRO_ATTENUATION_VALUE,
                            REV_PRO_ATTENUATION_VALUE,
                            REV_PRO_ATTENUATION_VALUE,
                            REV_PRO_ATTENUATION_VALUE,
};
#if 0
static T_DefDlPowCalPara s_TDlDefPowCalPara_Def[] = {
   /*txdbfs     txfullbit   txback      prxdbfs     prxfullbit  txatt     prxatt*/
    { -1900,    16,         300,        -1200,      14,         -1000,    -600,     -1500},
    { -1900,    16,         300,        -1200,      14,         -1000,    -600,     -1500},
    { -1900,    16,         300,        -1200,      14,         -1000,    -600,     -1500},
    { -1900,    16,         300,        -1200,      14,         -1000,    -600,     -1500},
};

static T_DefUlPowCalPara s_TUlDefPowCalPara[] = {
    /* rx gain */
    4300,
    4300,
    4300,
    4300,
};
#endif
#define  POW_INVALID_CONSIST    (2)
#if 0
#define CHIP_NUM_MAX  10
#endif
static SEM_ID pPowRamSem[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0};
static SEM_ID pBBTssiPowRamSem[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0};
static SEM_ID pBBRssiPowRamSem[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0};
static INT32  glDraCaliPaGain[CHAN_MAX_NUM_SOC] = {0};

/*功放漏压 双工插损等参数*/
static UINT32 salDflTxInsertLoss[BSP_MAX_TX_CHAN] = {0};
UINT32 g_ulSlaveScalarVswr[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {BSP_INVALID_VALUE};
T_CableLossRecord g_ulReInsertCableLoss[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
static UINT32 salPaVolt[BSP_MAX_TX_CHAN] = {0};
static INT32 salPaTempDelta = 0;
INT32 g_refRevGate[MAX_TX_CHAN] = {-200};
#define DATA_PROTECTION     1
#define DATA_NORMAL         0
#if 0
int powerctrldelay=0;


#define VSWR_DATA_CHECK(x)  1           //...数据正常

#endif
static FUNC_GetBoardScalarVswr pFuncGetBoardScalarVswr = NULL;
static FUN_GET_VECTORVSWR_PTR pGetVectorVswrVal = NULL;
static FUN_GET_VSWRMODE_PTR pSetVswrMode = NULL;
static FUN_GET_VECTORVSWR_FREQ pGetVectorVswrFreq = NULL;
static FUNC_GET_MULTY_PA_VIBAS_UPDATE pGetPaVibasUpdateFunc = NULL;
static FUNC_GetSlaveBoardTemp pGetSlaveBoardTemp = NULL;
static FUNC_GetSlaveAdVolt pGetSlaveRfDectorAdVolt = NULL;
static FUNC_GET_ANA_ATT_FROM_FPGA pGetAnaAttFromFpgaFunc = NULL;
static FUNC_GET_AC_FREQ_INDEX_FROM_BOARD pGetAcFreqIndexFromBoardFunc = NULL;
UINT32 BspGetTssiPowInfoFromIc(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs);
UINT32 BspSetNbicThredInit(VOID);
static UINT32 s_powprn = 0;
UINT32 _GetTssiPowInfoFromIcCntX = 0;

#define _pow_prn(flag, fmt...) {  if(flag) powerctrlLog(LOG_INFO, ##fmt);}

UINT32 BspGetReducePaVoltFlag(void)
{
    return s_reducePaVoltFlag;
}

void BspSetReducePaVoltFlag(UINT32 flag)
{
    s_reducePaVoltFlag = flag;
}

INT32 BspGetPaVoltDelt(void)
{
    return s_paVoltDelt;
}

void BspSetPaVoltDelt(INT32 volt)
{
    s_paVoltDelt = volt;
}

/*****************************************************************************
 *  函数名称   : (*)
 *  功能描述   : 配置打印放开
 *  读全局变量 :
 *  写全局变量 : 
 *  输入参数   : x = 非0，则立即强制放开打印
 *  输出参数   : 
 *  返 回 值   : 无
 *  其它说明   : 
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  
 *----------------------------------------------------------------------------
 *****************************************************************************/
VOID _SetTssiPowInfoFromIcCntX(UINT32 x)
{
    _GetTssiPowInfoFromIcCntX = x;
}

UINT32 BspGetBoardScalarVswrRegister(FUNC_GetBoardScalarVswr pFunc)
{
    pFuncGetBoardScalarVswr = pFunc;
    return BSP_OK;
}
FUNC_GetBoardScalarVswr BspGetBackBoardScalarVswrRegister(VOID)
{
    return pFuncGetBoardScalarVswr;
}
/*解决powctrl\dpd\vectorvswr 互相调用问题*/
VOID BspSetVectorVswrCallBackInit(FUN_GET_VECTORVSWR_PTR pVswrPtr)
{
    pGetVectorVswrVal = pVswrPtr;
}

UINT32 BspSetVswrModeCallBackInit(FUN_GET_VSWRMODE_PTR pVswrPtr)
{
    pSetVswrMode = pVswrPtr;
    
    return BSP_OK;
}

VOID BspSetVectorVswrFreqCallBackInit(FUN_GET_VECTORVSWR_FREQ pVswrFreq)
{
    pGetVectorVswrFreq = pVswrFreq;
}

FUNC_GET_MULTY_PA_VIBAS_UPDATE BspGetMultyPaVibasUpdate(VOID)
{
    return pGetPaVibasUpdateFunc;
}

VOID BspSetMultyPaVibasUpdateFuncInit(FUNC_GET_MULTY_PA_VIBAS_UPDATE pPaVibasPtr)
{
    pGetPaVibasUpdateFunc = pPaVibasPtr;
}

/*获取子端的单板温度*/
VOID BspGetSlaveBoardTempCallBackInit(FUNC_GetSlaveBoardTemp pBoardTempPtr)
{
    pGetSlaveBoardTemp = pBoardTempPtr;
}

/*获取子端的模拟检波*/
VOID BspGetSlaveAdVoltCallBackInit(FUNC_GetSlaveAdVolt pFunc)
{
    pGetSlaveRfDectorAdVolt = pFunc;
}
/* Started by AICoder, pid:rf1d0sbbda6aab914d3c09a6a08ddf084986677b */
UINT32 BspGetAnaAttFromFpgaCallBack(FUNC_GET_ANA_ATT_FROM_FPGA pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pGetAnaAttFromFpgaFunc = pFunc;
    return BSP_OK;
}
/* Ended by AICoder, pid:rf1d0sbbda6aab914d3c09a6a08ddf084986677b */

/* Started by AICoder, pid:tda54hcf89057eb149f10b4df096460749469c9b */
UINT32 BspSetAcFreqIndexFromBoardCallBack(FUNC_GET_AC_FREQ_INDEX_FROM_BOARD pFunc)
{
    INPUT_POINTER_CHECK(pFunc);
    pGetAcFreqIndexFromBoardFunc = pFunc;
    return BSP_OK;
}
/* Ended by AICoder, pid:tda54hcf89057eb149f10b4df096460749469c9b */

#if 0
UINT32 BspSetPowCalcMode(UINT32 powCalcMode)
{
    s_powCalcMode = powCalcMode;
    return BSP_OK;
}
#endif
static VOID BspSetRefRevGate(UINT32 chan, INT32 gate)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("chan is invalid\n");
        return ;
    }
    g_refRevGate[chan] = gate;
}

INT32 BspGetRefRevGate(UINT32 chan)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        dbgErr("chan is invalid\n");
        return BSP_ERROR;
    }
    return  g_refRevGate[chan];
}
UINT32 BspSetVwsrThreshold(UINT32 bspChn, UINT32 type,INT32 threshold)
{
    if (type >= THRESHOLD_NUM)
    {
        dbgErr("type = %d invalid\n",type);
        return BSP_ERROR;
    }

    sVswrPowThresHold[bspChn][type] = threshold;
    return BSP_OK;
}

/*驻波门限*/
INT32 BspGetVwsrThreshold(UINT32 bspChn, UINT32 type)
{

    return sVswrPowThresHold[bspChn][type];
}

/*功率点数*/
UINT32 BspSetPowAvgCnt(UINT32 bspChn,UINT32 cnt)
{
    if(bspChn>=BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }
    g_ulPowAvgSlotCnt[bspChn] = cnt;
    g_ulVswrAvgSlotCnt[bspChn] = cnt;

    return BSP_OK;
}
#if 0
/*pc功率计数点*/
UINT32 BspSetPcPowAvgCnt(UINT32 bspChn,UINT32 cnt)
{
    if(bspChn>=BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }
    g_ulBbPcPowCnt[bspChn] = cnt;

    return BSP_OK;
}
#endif

pPaProFlagGetFunc pGetPaProFlagCall = NULL;
UINT32 BspPaProFlagStaCall(pPaProFlagGetFunc pGetFlagCall)
{
   pGetPaProFlagCall = pGetFlagCall;
   return BSP_OK;
}

UINT32 BspSetRadioGain(INT32 *gainValue)
{
    INPUT_POINTER_CHECK(gainValue);
    memcpy_s(s_gRadioDetaGain, DIF_RADIOMODE_MAX*sizeof(INT32), gainValue, DIF_RADIOMODE_MAX*sizeof(INT32));
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspSetPowCalcPara(*)
 *  功能描述   : 配置功率计算参数，功率检测初始化
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *****************************************************************************/
UINT32 BspSetPowCalcPara(T_BspHalAdaptPowChk *powChkCfg)
{
    return BspHalAdaptPowCalcInit(powChkCfg);
}

/*****************************************************************************
 *  函数名称   : BspSetGsmPowCalcPara(*)
 *  功能描述   : 配置GSM功率计算参数，功率检测初始化
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *****************************************************************************/
UINT32 BspSetGsmPowCalcPara(T_BspHalAdaptGsmPowChk *pGsmPowChkCfg)
{
    return BspHalAdaptGsmPowCalcInit(pGsmPowChkCfg);
}


/*****************************************************************************
 *  函数名称   : _BspInitPowThrod(*)
 *  功能描述   :初始化过功率检测配置
 *  输入参数   :
 *  输出参数   :
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *****************************************************************************/
/* Started by AICoder, pid:a6ee15723ea6f4914a0508f7f026b61b71930ee7 */
UINT32 BspInitPowThrodCfg(void)
{
    /*
     * 最后一个参数暂时固定为23040，因为该值和无线帧周期绑定，
     * 后续由HAL内部确定。
     */
    BspHalAdaptSamplePowDetParaCfg(0, 0x800, 23040);

    /* 联合采数功能，需要把相关控制字使能 */
    BspHalAdaptUnionSampleCfg();

    return BSP_OK;
}
/* Ended by AICoder, pid:a6ee15723ea6f4914a0508f7f026b61b71930ee7 */

/*****************************************************************************
 *  函数名称   : BspPowThrodCfg(*)
 *  功能描述   : 功率检测门限配置(高层调用)
 *  输入参数   : rfChanNo - BSP通道号
 *  输入参数   : carrNo - 载波号
 *  输入参数   : radioMode - 制式
 *  输入参数   : powPosition - 功率触发方式选择，0-6
 *                0：下行分载波异常触发
 *                1：cb过来下行合载波功率异常触发
 *                2：cb过来上行合载波功率异常触发
 *                3：ulpost的VGA衰减量动作时触发
 *                4：盲采触发
 *                5：采数帧头0触发
 *                6：采数帧头1触发
 *                暂时只支持下行分载波异常触发
 *  输入参数   : powMaxThrod - 过功率检测高门限
 *  输出参数   :
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *****************************************************************************/
/* Started by AICoder, pid:lbc23ae265d1fdd147aa0a81b0af543568f1bbd6 */
UINT32 BspPowThrodCfg(UINT32 rfChanNo, UINT32 carrNo, UINT32 radioMode, UINT32 powPosition, UINT32 powMaxThrod)
{
    UINT32 difChan = 0;
    UINT32 chipId = 0;
    UINT32 retVal = BSP_OK;

    // 检查rfChanNo是否超出范围
    if (rfChanNo >= BspGetTxBspChanNum())
    {
        dbgErr("%s>> chanNo is Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    // 获取difChan信息
    retVal = BspGetDifInfoByBspChn(rfChanNo, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s TX bspChan[%d] Get DifChan err\n", __func__, rfChanNo);
        return retVal;
    }

    // 设置功率阈值配置
    retVal = BspHalAdaptSetPowThrodCfg(difChan, carrNo, radioMode, powPosition, powMaxThrod);
    if (BSP_OK != retVal)
    {
        dbgErr("%s BspHalAdaptSetPowThrodCfg err \n", __func__);
        return retVal;
    }

    return retVal;
}
/* Ended by AICoder, pid:lbc23ae265d1fdd147aa0a81b0af543568f1bbd6 */

/*****************************************************************************
 *  函数名称   : BspPowThrodStart
 *  功能描述   : 启动采数流程(高层调用)
 *  输入参数   : powPosition - 功率触发方式选择，0-6
 *                0：下行分载波异常触发
 *                1：cb过来下行合载波功率异常触发
 *                2：cb过来上行合载波功率异常触发
 *                3：ulpost的VGA衰减量动作时触发
 *                4：盲采触发
 *                5：采数帧头0触发
 *                6：采数帧头1触发
 *                暂时只支持下行分载波异常触发
 *  输出参数   :
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *****************************************************************************/
/* Started by AICoder, pid:me7ca40196k85aa14c220a3da0aa390de994620e */
UINT32 BspPowThrodStart(UINT32 powPosition)
{
    return BspHalAdaptPowThrodStart(powPosition);
}
/* Ended by AICoder, pid:me7ca40196k85aa14c220a3da0aa390de994620e */
/*****************************************************************************
 *  函数名称   : BspPowThrodIsDone
 *  功能描述   : 判断采数流程是否完成(高层调用)
 *  输入参数   : powPosition - 功率触发方式选择，0-6
 *                0：下行分载波异常触发
 *                1：cb过来下行合载波功率异常触发
 *                2：cb过来上行合载波功率异常触发
 *                3：ulpost的VGA衰减量动作时触发
 *                4：盲采触发
 *                5：采数帧头0触发
 *                6：采数帧头1触发
 *                暂时只支持下行分载波异常触发
 *  输出参数   : pFlag - 1:采数完成；0:采数未完成
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *****************************************************************************/
/* Started by AICoder, pid:9780dbcae5b50f3140c308a310b13d1ee42494ab */
UINT32 BspPowThrodIsDone(UINT32 powPosition, UINT32 *pFlag)
{
    INPUT_POINTER_CHECK(pFlag);
    return BspHalAdaptPowThrodIsDone(powPosition, pFlag);
}
/* Ended by AICoder, pid:9780dbcae5b50f3140c308a310b13d1ee42494ab */
/*****************************************************************************
 *  函数名称   : BspPowThrodEnd
 *  功能描述   : 结束采数(高层调用)
 *  输入参数   : powPosition - 功率触发方式选择，0-6
 *                0：下行分载波异常触发
 *                1：cb过来下行合载波功率异常触发
 *                2：cb过来上行合载波功率异常触发
 *                3：ulpost的VGA衰减量动作时触发
 *                4：盲采触发
 *                5：采数帧头0触发
 *                6：采数帧头1触发
 *                暂时只支持下行分载波异常触发
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 
 *****************************************************************************/
/* Started by AICoder, pid:284f8n40f8jf6f0141160ba770cc5107aa342efb */
UINT32 BspPowThrodEnd(UINT32 powPosition)
{
    return BspHalAdaptPowThrodEnd(powPosition);
}
/* Ended by AICoder, pid:284f8n40f8jf6f0141160ba770cc5107aa342efb */

/*IC4.0中HAL层按照通道上报功率*/
UINT32 BspReadIfPow (T_TxAllPcPow *txAllPcPow, T_BspHalAdaptPowCfg *fwd, T_BspHalAdaptPowCfg *rev)
{
    INPUT_POINTER_CHECK(txAllPcPow);

    txAllPcPow->tPcPow[0].tIfPcPow.tFwdPow.ifTssiPow = fwd->tssiPow;
    txAllPcPow->tPcPow[0].tIfPcPow.tFwdPow.fbPow = fwd->fwdPow;
    txAllPcPow->tPcPow[0].tIfPcPow.tRevPow.ifTssiPow = rev->tssiPow;
    txAllPcPow->tPcPow[0].tIfPcPow.tRevPow.fbPow = rev->fwdPow;

    return BSP_OK;
}
#if 0
UINT32 BspReadBbPcPow(UINT32 difChan, T_TxAllPcPow *txAllPcPow, T_BspHalAdaptPowCfg *pcFwd)
{
    UINT32 carrId = 0;
    UINT32 radioMode = 0;
    UINT32 carrNo = 0;
    UINT32 carrNumPerChan = 0;
    T_BspHalAdaptCarrInfo ptTxCarrInfo = {0};
    T_BspAdaptOneChanCarrInfo *pDifCarrInfo = NULL;
    //T_BspAdaptOneChanCarrInfo *difCarrInfo = NULL;

    INPUT_POINTER_CHECK(txAllPcPow);

    pDifCarrInfo = BspHalAdaptGetDifChanCarrInfo(TX, difChan);
    #if 0
    if (NULL == difCarrInfo)
    {
        dbgErr("[%s]difChan'%d difCarrInfo Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }

    memcpy_s(pDifCarrInfo, sizeof(pDifCarrInfo), difCarrInfo, sizeof(difCarrInfo));
    #endif
    if (NULL == pDifCarrInfo)
    {
        dbgErr("[%s]difChan'%d difCarrInfo Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }

    /*如果下发的载波数超过IC4.0最大支持能力，则返回ERROR*/
    carrNumPerChan = ((pDifCarrInfo->carrNum) + (UINT32)1);
    if (carrNumPerChan > BSP_HALADAPT_MAX_DIF_CARR_NUM)
    {
        dbgErr("[%s] carrNum[%d] out of range!\n", __FUNCTION__, carrNumPerChan);
        return BSP_ERROR;
    }

    for (carrId = 0; carrId < carrNumPerChan; carrId++)
    {
        ptTxCarrInfo = pDifCarrInfo->oneCarrInfo[carrId];
        radioMode = ptTxCarrInfo.carrRadio;
        carrNo = ptTxCarrInfo.difCarrNo;
        BspHalAdaptReadBbPcFwdPow(difChan, carrNo, radioMode, pcFwd);
        txAllPcPow->tBbPcPow[carrId].tbbPcPow.tFwdPow.ifTssiPow = pcFwd->tssiPow;
        txAllPcPow->tBbPcPow[carrId].tbbPcPow.tFwdPow.fbPow = pcFwd->fwdPow;
        txAllPcPow->tBbPcPow[carrId].carrNo = ptTxCarrInfo.difCarrNo;
        txAllPcPow->tBbPcPow[carrId].carrRadMod = ptTxCarrInfo.carrRadio;
    }

    return BSP_OK;
}
#endif
/*****************************************************************************
 *  函数名称   : BspReadPow
 *  功能描述   : DPDIC4.0读取功率检测上报值
 *  输入参数   : chip    - 芯片号
 *  输入参数   : powType - 功率检测类型
 *  输入参数   : difChan - 中频通道号
 *  返 回 值    : 功率上报值
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 10288704何瑞华 @2020-11-20 15:42:06, 创建
 *----------------------------------------------------------------------------
 *****************************************************************************/
UINT32 BspReadPow(UINT32 chip, ePowType powType, UINT32 difChan, T_TxAllPcPow *txAllPcPow)
{
    UINT32 retVal = BSP_OK;
    T_BspHalAdaptPowCfg fwd = {0};
    T_BspHalAdaptPowCfg rev = {0};
    /* T_BspHalAdaptPowCfg pcFwd = {0};
    T_BspHalAdaptPowCfg pcRev = {0}; */

    INPUT_POINTER_CHECK(txAllPcPow);

    switch(powType)
    {
        case BSP_TSSI_FWD_INFO:
        {
            retVal |= BspHalAdaptReadFwdIfPow(difChan, &fwd);
            retVal |= BspHalAdaptReadRevIfPow(difChan, &rev);

            if (BSP_OK != retVal)
            {
                dbgErr("%s Read ifTssiPow fbPow failed\n",__FUNCTION__);
                return retVal;
            }

            retVal |= BspReadIfPow(txAllPcPow, &fwd, &rev);
            break;
        }
        #if 0
        /*和王瑜00316247确认，IC4.2无PC功率*/
        case BSP_PC_TSSI_FWD_INFO:
        {
            retVal |= BspHalAdaptReadPcFwdIfPow(difChan, &pcFwd);
            retVal |= BspHalAdaptReadPcRevIfPow(difChan, &pcRev);

            if (BSP_OK != retVal)
            {
                dbgErr("%s Read PcIfTssi PcIfFwd failed\n",__FUNCTION__);
                return retVal;
            }

            retVal |= BspReadIfPow(txAllPcPow, &pcFwd, &pcRev);
            retVal |= BspReadBbPcPow(difChan, txAllPcPow, &pcFwd);
            break;
        }
        #endif
        default:
        {
            break;
        }
    }
    dbgInfoEx("[%s]fwdtssiPow = %d, fwdFbPow = %d, revtssiPow = %d, revFbPow = %d\n",__FUNCTION__,txAllPcPow->tPcPow[0].tIfPcPow.tFwdPow.ifTssiPow,\
        txAllPcPow->tPcPow[0].tIfPcPow.tFwdPow.fbPow, txAllPcPow->tPcPow[0].tIfPcPow.tRevPow.ifTssiPow,\
        txAllPcPow->tPcPow[0].tIfPcPow.tRevPow.fbPow);

    return retVal;
}

/*IC4.0反馈功率HAL层直接上报累加后的功率值*/
UINT32 GatherTssiFwd(UINT32 difChan,INT32 Index)
{
    /*UINT32 bandFreq = 0;*/
    ePowType powType = BSP_TSSI_FWD_INFO;
    T_TxAllPcPow txAllPcPow = {0};
    UINT32 bspChn = 0;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    T_TxPow *pTxPowVal = &sTxPowVal[difChan][Index];
    if (NULL == pTxPowVal)
    {
        dbgErr("%s: pTxPowVal get error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(pTxPowVal, 0, sizeof(T_TxPow));

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo)
    {
        if (BSP_OK != BspGetBspChnByDifChn(difChan, TX, &bspChn))
        {
            return BSP_ERROR;
        }

        INPUT_BSPCHN_CHECK(bspChn);

        if (FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChn] && NULL != pFpgaInfo->pFuncReadFpgaRevPow && NULL != pFpgaInfo->pFuncReadFpgaFwdPow)
        {
            pFpgaInfo->pFuncReadFpgaRevPow(bspChn, 0, &txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.ifTssiPow, &txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.fbPow);
            pFpgaInfo->pFuncReadFpgaFwdPow(bspChn, 0, &txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.ifTssiPow, &txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.fbPow);
        }
        else
        {
            BspReadPow(0, powType, difChan, &txAllPcPow);
        }
    }
    else
    {
        BspReadPow(0, powType, difChan, &txAllPcPow);
    }

    pTxPowVal->tFwdPow.ifTssiPow = txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.ifTssiPow;
    pTxPowVal->tRevPow.ifTssiPow = txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.ifTssiPow;
    pTxPowVal->tFwdPow.fbPow = txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.fbPow;
    pTxPowVal->tRevPow.fbPow = txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.fbPow;

    sTxFwdRevPowerVal[difChan].tFwdPow.ifTssiPow = txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.ifTssiPow;
    sTxFwdRevPowerVal[difChan].tRevPow.ifTssiPow = txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.ifTssiPow;
    sTxFwdRevPowerVal[difChan].tFwdPow.fbPow = txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.fbPow;
    sTxFwdRevPowerVal[difChan].tRevPow.fbPow = txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.fbPow;

    dbgInfoEx("[%s]: FwdTssi = %2d RevTssi = %2d FwdFb = %2d RevFb = %2d\n",__FUNCTION__,pTxPowVal->tFwdPow.ifTssiPow,\
        pTxPowVal->tRevPow.ifTssiPow,pTxPowVal->tFwdPow.fbPow,pTxPowVal->tRevPow.fbPow);

    return BSP_OK;
}
#if 0
UINT32 GatherPcTssiFwdPow(UINT32 difChan)
{
    /*UINT32 bandFreq = 0;*/
    ePowType powType = BSP_PC_TSSI_FWD_INFO;
    T_TxAllPcPow txAllPcPow = {0};

    T_TxPow *pTxPowVal = &sTxPcPowVal[difChan];
    if (NULL == pTxPowVal)
    {
        dbgErr("%s: pTxPowVal get error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(pTxPowVal, 0, sizeof(T_TxPow));

    T_TxBbPcPow *pTxBbPowVal = &sTxBbPcPowVal[difChan][0];
    if (NULL == pTxBbPowVal)
    {
        dbgErr("%s: pTxBbPowVal get error.\n", __FUNCTION__);
        return BSP_ERROR;
    }
    memset(pTxBbPowVal, 0, sizeof(T_TxBbPcPow));

    BspReadPow(0, powType, difChan, &txAllPcPow);
    
    pTxPowVal->tFwdPow.ifTssiPow = txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.ifTssiPow;
    pTxPowVal->tRevPow.ifTssiPow = txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.ifTssiPow;
    pTxPowVal->tFwdPow.fbPow = txAllPcPow.tPcPow[0].tIfPcPow.tFwdPow.fbPow;
    pTxPowVal->tRevPow.fbPow = txAllPcPow.tPcPow[0].tIfPcPow.tRevPow.fbPow;
    
    memcpy_s(pTxBbPowVal, sizeof(T_TxBbPcPow)*BSP_MAX_CARR_NUM, &(txAllPcPow.tBbPcPow),\
        sizeof(T_TxBbPcPow)*BSP_MAX_CARR_NUM);

        
    dbgInfoEx("[%s]: FwdTssi = %2d RevTssi = %2d FwdFb = %2d RevFb = %2d\n",__FUNCTION__,pTxPowVal->tFwdPow.ifTssiPow,\
        pTxPowVal->tRevPow.ifTssiPow,pTxPowVal->tFwdPow.fbPow,pTxPowVal->tRevPow.fbPow);

    return BSP_OK;
}
#endif

UINT32 BspGetRfMtsTemp(UINT32 chn, INT32 *pTemp)
{
    UINT32 ret   = BSP_OK;
    char   bufName[120] ={0};
    UINT32 devid = 0;
    INT32 iSnpRet = 0;

    INPUT_POINTER_CHECK(pTemp);

    iSnpRet = snprintf_s(bufName,sizeof(bufName),"TempRf%d",chn);
    SNPRINTF_S_CHECK(iSnpRet, sizeof(bufName));
    devid = BspDevNameToId(bufName);
    INPUT_DEVICEID_CHECK(devid);
    ret = BspGetTempSensorInfo(devid, pTemp);

    return ret;
}

void BspInitTempSourcePara(UINT32 boardTempSource, UINT32 paTempSource)
{
    s_TempSourcePara.boardTemp = boardTempSource;
    s_TempSourcePara.paTemp = paTempSource;
}

// 获取单板温度
UINT32 BspGetBoardTemp(UINT32 index, INT32 *pTemp)
{
    UINT32 ret = BSP_OK;

    if ((s_TempSourcePara.boardTemp == TEMP_SOURCE_BSP_CACHE) && (BspGetTempThreadSwitch() == SWITCH_ON))
    {
        ret = BspGetBoardCompTemp(index, pTemp);
    }
    else
    {
        ret = BspGetBoardTempFromHW(0, pTemp);
    }

    return ret;
}

/* Started by AICoder, pid:q188cg74a009ee914b5208820057627b0b78784b */
UINT32 BspRruTempOptiMiza(UINT32 chan, INT32 realTemp, UINT32 tempType, INT32 tempOffset, INT32 *optiMizaTemp)
{
    UINT32 retVal = BSP_OK;
    INT32  slightTempPeak = 0;
    INT32  OverTempPeak = 0;
    INT32  tempRec = 0;
    float  factor = 0;
    UINT32 loop = 0;
    UINT32 pwrTempType[PWR_MAX_TEMP_NUM] = {E_TEMP_TYPE_PWR, E_TEMP_TYPE_PWR1, E_TEMP_TYPE_PWR2, E_TEMP_TYPE_PWR3,
                                            E_TEMP_TYPE_PWR4, E_TEMP_TYPE_PWR5, E_TEMP_TYPE_PWR6, E_TEMP_TYPE_PWR7};
    UINT32 slightOverId[PWR_MAX_TEMP_NUM] = {BSP_THRESHOLD_ID_SLIGHTOVER_PWR_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR1_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR2_TEMPER,
                                             BSP_THRESHOLD_ID_SLIGHTOVER_PWR3_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR4_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR5_TEMPER,
                                             BSP_THRESHOLD_ID_SLIGHTOVER_PWR6_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_PWR7_TEMPER};
    UINT32 overId[PWR_MAX_TEMP_NUM] = {BSP_THRESHOLD_ID_OVER_PWR_TEMPER, BSP_THRESHOLD_ID_OVER_PWR1_TEMPER, BSP_THRESHOLD_ID_OVER_PWR2_TEMPER,
                                       BSP_THRESHOLD_ID_OVER_PWR3_TEMPER, BSP_THRESHOLD_ID_OVER_PWR4_TEMPER, BSP_THRESHOLD_ID_OVER_PWR5_TEMPER,
                                       BSP_THRESHOLD_ID_OVER_PWR6_TEMPER, BSP_THRESHOLD_ID_OVER_PWR7_TEMPER};

    INPUT_POINTER_CHECK(optiMizaTemp);
    switch(tempType)
    {
        case E_TEMP_TYPE_TRX:
        {
            retVal = BspGetTempThreshold(chan, BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER, &slightTempPeak, &tempRec);
            retVal |= BspGetTempThreshold(chan, BSP_THRESHOLD_ID_OVER_TEMPER, &OverTempPeak, &tempRec);
            break;
        }
        case E_TEMP_TYPE_PA:
        {
            retVal = BspGetTempThreshold(chan, BSP_THRESHOLD_ID_SLIGHTOVER_PA_TEMPER, &slightTempPeak, &tempRec);
            retVal |= BspGetTempThreshold(chan, BSP_THRESHOLD_ID_OVER_PA_TEMPER, &OverTempPeak, &tempRec);
            break;
        }
        default:
        {
            for(loop = 0; loop < PWR_MAX_TEMP_NUM; loop++)
            {
                if(tempType == pwrTempType[loop])
                {
                    retVal = BspGetTempThreshold(0, slightOverId[loop], &slightTempPeak, &tempRec);
                    retVal |= BspGetTempThreshold(0, overId[loop], &OverTempPeak, &tempRec);
                    break;
                }
            }
            if(PWR_MAX_TEMP_NUM == loop)
            {
                dbgInfo("[%s] tempType is Fault:%d\n",__FUNCTION__, tempType);
                return BSP_ERROR;
            }
            break;
        }
    }
    CHECK_RETVAL(BspGetTempThreshold, retVal);

    dbgInfoEx("[%s]slightTempPeak = %d, OverTempPeak = %d\n", __FUNCTION__, slightTempPeak, OverTempPeak);
    if(realTemp <= (slightTempPeak+tempOffset))
    {
        *optiMizaTemp = realTemp-tempOffset;
    }
    else if(((slightTempPeak+tempOffset) < realTemp) && (realTemp < OverTempPeak))
    {
        if(0 == (OverTempPeak-slightTempPeak-tempOffset))  //如果扩张系数分母为0,则不做美化处理
        {
            *optiMizaTemp = realTemp;
        }
        else
        {
            factor = ((float)OverTempPeak-slightTempPeak)/(OverTempPeak-slightTempPeak-tempOffset);
            *optiMizaTemp = round((slightTempPeak + (realTemp-(slightTempPeak+tempOffset))*factor)*2)/2;
        }
    }
    else
    {
        *optiMizaTemp = realTemp;
    }
    dbgInfoEx("[%s]factor=%f,offset=%d,realTemp=%d,optiMizaTemp=%d\n", __FUNCTION__, factor, tempOffset, realTemp, *optiMizaTemp);

    return retVal;
}
/* Ended by AICoder, pid:q188cg74a009ee914b5208820057627b0b78784b */

/* Started by AICoder, pid:i076c2ecb37509c14bb20afe1032ab2e6ef5b118 */
UINT32 BspGetOptiMizaBoardTemp(UINT32 index, INT32 *optiMizaBoardTemp)
{
    UINT32 retVal = BSP_OK;
    INT32  boardTemp = 0;
    INT32  OptiMizaTemp = 0;
    INT32  offset = 0;
    T_DefRruTempOffsetPara tempOffset = {0};

    INPUT_POINTER_CHECK(optiMizaBoardTemp);
    retVal = BspGetBoardTemp(index, &boardTemp);
    CHECK_RETVAL(BspGetBoardTemp, retVal);

    BspGetTempOffset(&tempOffset);
    offset = tempOffset.boardTempOffset;
    if(0 == offset)  //如果提高偏移量为0,无需美化上报真实值
    {
        *optiMizaBoardTemp = boardTemp;
        dbgInfoEx("[%s]boardTemp=%d,optiMizaBoardTemp=%d, No Needing Optimiza\n", __FUNCTION__, boardTemp, *optiMizaBoardTemp);
        return retVal;
    }

    retVal = BspRruTempOptiMiza(index, boardTemp, E_TEMP_TYPE_TRX, offset, &OptiMizaTemp);
    CHECK_RETVAL(BspRruTempOptiMiza, retVal);

    *optiMizaBoardTemp = OptiMizaTemp;

    return retVal;
}
/* Ended by AICoder, pid:i076c2ecb37509c14bb20afe1032ab2e6ef5b118 */

/* 多片IC机型，获取每片IC单板温度检测点温度 */
UINT32 BspGetBoardTempNode(UINT32 index, INT32 *temp)
{
    INPUT_POINTER_CHECK(temp);

    return BspGetBoardTempRecord(index, temp);
}

UINT32 BspGetBoardTempConfig(T_BoardAlarmCfg *boardTempAlarmCfg)
{
    static CHAR dviceName[] = "TempNodeBoard";
    UINT32 length = strnlen_s(dviceName, MAX_DEVICE_LEN);
    UINT32 chan = 0;
    UINT32 index = 0;
    UINT32 loop = 0;
    UINT32 boardIcNum = 0;
    UINT32 boardNodeNum = 0;
    UINT32 *record = NULL;
    INT32  warnThr = 0;
    INT32  recThr = 0;
    UINT32 nodeIndex = 0;
    INT32  offset = 0;
    UINT32 slightOverId[RRU_MAX_BOARD_NODE_NUM] = {BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER1, BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER2};
    UINT32 overId[RRU_MAX_BOARD_NODE_NUM] = {BSP_THRESHOLD_ID_OVER_TEMPER, BSP_THRESHOLD_ID_OVER_TEMPER1, BSP_THRESHOLD_ID_OVER_TEMPER2};
    T_DefRruTempOffsetPara tempOffset = {0};

    INPUT_POINTER_CHECK(boardTempAlarmCfg);

    memset_s(boardTempAlarmCfg, sizeof(T_BoardAlarmCfg), 0, sizeof(T_BoardAlarmCfg));

    boardIcNum = BspGetRpuNum();  /* 获取RRU整机单板数量 */
    if(boardIcNum > RRU_MAX_BOARD_NUM)
    {
        dbgErr("[%s] RRU_MAX_BOARD_NUM:%d, boardIcNum(%d) out of range!\n",
                    __FUNCTION__, RRU_MAX_BOARD_NUM, boardIcNum);
        return BSP_ERROR;
    }
    boardTempAlarmCfg->boardIcNum = boardIcNum;

    boardNodeNum = BspGetDeviceNodeNum(dviceName, length);  /* 获取RRU整机单板温度测量点数量 */
    if(boardNodeNum > RRU_MAX_BOARD_NODE_NUM)
    {
        dbgErr("[%s] RRU_MAX_BOARD_NODE_NUM:%d, boardNodeNum(%d) out of range!\n",
                 __FUNCTION__, RRU_MAX_BOARD_NODE_NUM, boardNodeNum);
        return BSP_ERROR;
    }

    record = (UINT32 *) malloc(boardNodeNum * sizeof(UINT32));
    if (NULL == record)
    {
        dbgErr("%s>>TmpBuf Malloc Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    memset_s(record, boardNodeNum * sizeof(UINT32), 0, boardNodeNum * sizeof(UINT32));
    if(BSP_OK != BspGetDeviceSerialCfg(dviceName, length, record, boardNodeNum))
    {
        free(record);
        return BSP_ERROR;
    }

    boardTempAlarmCfg->supportAbility = NO_SUPPORT;
    for(index = 0; index < boardIcNum; index++)
    {
        boardTempAlarmCfg->boardCfg[index].boardIndex = index;
        boardTempAlarmCfg->boardCfg[index].paBitMask  = BspGetSectorMaskByDevice(index, dviceName, length); /* 获取RRU单板对应的扇区功放掩码 */;
        for(loop = 0; loop < boardNodeNum; loop++)
        {
            if(index == record[loop])
            {
                boardTempAlarmCfg->boardCfg[index].boardNodeNum++;
            }
        }

        if(0 != boardTempAlarmCfg->boardCfg[index].paBitMask)
        {
            boardTempAlarmCfg->supportAbility = SUPPORT;
            if(nodeIndex < RRU_MAX_BOARD_NODE_NUM)
            {
                BspGetTempThreshold(chan, slightOverId[nodeIndex], &warnThr, &recThr);
                boardTempAlarmCfg->boardCfg[index].slightAlmThre = warnThr;
                boardTempAlarmCfg->boardCfg[index].slightRecThre = recThr;

                BspGetTempThreshold(chan, overId[nodeIndex], &warnThr, &recThr);
                boardTempAlarmCfg->boardCfg[index].seriousAlmThre = warnThr;
                boardTempAlarmCfg->boardCfg[index].seriousRecThre = recThr;
                nodeIndex++;
            }
        }
        BspGetTempOffset(&tempOffset);
        offset = tempOffset.boardTempOffset;
        boardTempAlarmCfg->boardCfg[index].boardTempOffset = offset;
    }

    free(record);

    return BSP_OK;
}

/* Started by AICoder, pid:pbfd44fb73a802d143530a9c30514f21ec237008 */
UINT32 showdbgBoardTempThreshold(UINT32 nodeIndex)
{
    UINT32 chan = 0;
    INT32  warnThr = 0;
    INT32  recThr = 0;
    UINT32 slightOverId[] = {BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER, BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER1, BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER2};
    UINT32 overId[] = {BSP_THRESHOLD_ID_OVER_TEMPER, BSP_THRESHOLD_ID_OVER_TEMPER1, BSP_THRESHOLD_ID_OVER_TEMPER2};

    if((nodeIndex >= NELEMENTS(slightOverId)) || (nodeIndex >= NELEMENTS(overId)))
    {
       dbgInfo("nodeIndex:%d is Error\n", nodeIndex);
       return BSP_ERROR;
    }

    dbgInfo("==================slightOverTempWarning============================\n");
    BspGetTempThreshold(chan, slightOverId[nodeIndex], &warnThr, &recThr);
    dbgInfo("slightPeak = [%d]\t slightRec= [%d]\t\n", warnThr, recThr);

    dbgInfo("================== SevereOverTempWarning===========================\n");
    BspGetTempThreshold(chan, overId[nodeIndex], &warnThr, &recThr);
    dbgInfo("overPeak = [%d]\t overRec= [%d]\t\n", warnThr, recThr);

    return BSP_OK;
}
/* Ended by AICoder, pid:pbfd44fb73a802d143530a9c30514f21ec237008 */

/* Started by AICoder, pid:0a5554f371y523d1459309685041e41f5d177258 */
UINT32 showdbgPaTempThreshold(UINT32 chan)
{
    UINT32 retVal = BSP_OK;
    INT32  slightTempPeak = 0;
    INT32  OverTempPeak = 0;
    INT32  tempRec = 0;

    dbgInfo("==================slightOverTempWarning============================\n");
    retVal = BspGetTempThreshold(chan, BSP_THRESHOLD_ID_SLIGHTOVER_PA_TEMPER, &slightTempPeak, &tempRec);
    dbgInfo("slightPeak = [%d]\t slightRec= [%d]\t\n", slightTempPeak, tempRec);

    dbgInfo("================== SevereOverTempWarning===========================\n");
    retVal |= BspGetTempThreshold(chan, BSP_THRESHOLD_ID_OVER_PA_TEMPER, &OverTempPeak, &tempRec);
    dbgInfo("overPeak = [%d]\t overRec= [%d]\t\n", OverTempPeak, tempRec);

    return retVal;
}
/* Ended by AICoder, pid:0a5554f371y523d1459309685041e41f5d177258 */

/*****************************************************************************
 *  函数名称   : BspGetPwrInletTemp(*)
 *  功能描述   : 获取电源连接器温度
 *  输入参数   :ulIndex 接线器的索引，0和1
 *  输出参数   :*pTemp 温度值单位：0.1°
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/

UINT32 BspGetPwrInletTemp(UINT32 ulIndex, INT32 *pTemp)
{
    int  ret = BSP_OK;
    UINT32  devId = 0;
    char    bufName[STRING_LENGTH_128_BYTE] = {0};

    ret = snprintf_s(bufName, sizeof(bufName), "TempPwrLet%d", ulIndex);
    SNPRINTF_S_CHECK(ret, sizeof(bufName));
    bufName[STRING_LENGTH_128_BYTE - 1] = '\0';
    devId = BspDevNameToId(bufName);
    if (devId == BSP_ERROR)
    {
        return BSP_ERROR;
    }

    return BspGetTempSensorInfo(devId, pTemp);
}

UINT32 BspGetPaTemp(UINT32 bspChn, INT32 *patmp)
{
    UINT32 retVal = 0;

    if ((s_TempSourcePara.paTemp == TEMP_SOURCE_BSP_CACHE) && (BspGetTempThreadSwitch() == SWITCH_ON))
    {
        retVal = BspGetPaCompTemp(bspChn, patmp);
    }
    else
    {
        retVal = BspGetPaTempFromHW(bspChn, patmp);
    }
    return retVal;
}

/* Started by AICoder, pid:u0a0c0980e1c6a0144460af570adf92db88524a6 */
UINT32 BspGetOptiMizaPaTemp(UINT32 bspChn, INT32 *optiMizaPaTemp)
{
    UINT32 retVal = BSP_OK;
    INT32  paTemp = 0;
    INT32  OptiMizaTemp = 0;
    INT32  offset = 0;
    T_DefRruTempOffsetPara tempOffset = {0};

    INPUT_POINTER_CHECK(optiMizaPaTemp);
    retVal = BspGetPaTemp(bspChn, &paTemp);
    CHECK_RETVAL(BspGetPaTemp, retVal);

    BspGetTempOffset(&tempOffset);
    offset = tempOffset.paTempOffset;
    if(0 == offset)  //如果提高偏移量为0,无需美化上报真实值
    {
        *optiMizaPaTemp = paTemp;
        dbgInfoEx("[%s]paTemp=%d,optiMizaPaTemp=%d, No Needing Optimiza\n", __FUNCTION__, paTemp, *optiMizaPaTemp);
        return retVal;
    }

    retVal = BspRruTempOptiMiza(bspChn, paTemp, E_TEMP_TYPE_PA, offset, &OptiMizaTemp);
    CHECK_RETVAL(BspRruTempOptiMiza, retVal);

    *optiMizaPaTemp = OptiMizaTemp;

    return retVal;
}
/* Ended by AICoder, pid:u0a0c0980e1c6a0144460af570adf92db88524a6 */

UINT32 rdpatemp(UINT32 idx)
{
    INT32 pTemp = 0;
    BspGetPaTemp(idx, &pTemp);
    dbgInfo("patemp %d temp = %0.2lf (centigrade)\n", idx, pTemp / 10.0);
    return BSP_OK;
}

UINT32 BspGetPaTempConfig(T_PaAlarmCfg *paTempAlarmCfg)
{
    static UINT32 flag = 0;
    static CHAR dviceName[] = "TempNodePa";
    UINT32 length = (UINT32)strnlen_s(dviceName, MAX_DEVICE_LEN);
    UINT32 paBitMask = 0;
    UINT32 index = 0;
    UINT32 paNum = 0;

    INPUT_POINTER_CHECK(paTempAlarmCfg);

    if(0 != flag)
    {
        memcpy_s(paTempAlarmCfg, sizeof(T_PaAlarmCfg), &paTempCfgRcord, sizeof(T_PaAlarmCfg));
        return BSP_OK;
    }

    paNum = BspGetDeviceNum(dviceName, length);  /* 获取RRU整机功放数量 */
    if(paNum > RRU_MAX_DEVICE_NUM)
    {
        dbgErr("[%s]paNum = %d, Out Range the RRU_MAX_DEVICE_NUM:%d\n", __FUNCTION__, paNum, RRU_MAX_DEVICE_NUM);
        return BSP_ERROR;
    }

    paTempCfgRcord.paNum = paNum;
    paTempCfgRcord.supportAbility = NO_SUPPORT;

    for(index = 0; index < paNum; index++)
    {
        paTempCfgRcord.rruPaCfg[index].paIndex = index;

        paBitMask = BspGetSectorMaskByDevice(index, dviceName, length); /* 获取RRU单板对应的扇区功放掩码 */;
        if(0 != paBitMask)
        {
            paTempCfgRcord.supportAbility = SUPPORT;
        }
        paTempCfgRcord.rruPaCfg[index].paBitMask = paBitMask;
    }
    memcpy_s(paTempAlarmCfg, sizeof(T_PaAlarmCfg), &paTempCfgRcord, sizeof(T_PaAlarmCfg));
    flag = 1;  /* 标志更新 */

    return BSP_OK;
}

UINT32 BspGetDpdCoreTemp(UINT32 index, INT32 *pTemp)
{
    UINT32 ret = BSP_OK;
    char   bufName[120] = {0};
    UINT32 devid = 0;
    INT32 iTmpRet = 0;

    INPUT_POINTER_CHECK(pTemp);
    iTmpRet = snprintf_s(bufName, 120, "DspCore");
    SNPRINTF_S_CHECK(iTmpRet, sizeof(bufName)-1);
    devid = BspDevNameToId(bufName);
    //INPUT_DEVICEID_CHECK(devid);
    ret = BspGetTempSensorInfo(devid, pTemp);

    return ret;
}

static UINT32 BspGetVswrThresholdByRatedPow(UINT32 ratePow, INT32 *threshold)
{
    INT32 vswrThreshold = 600;
    *threshold = vswrThreshold;
    return BSP_OK;
}

static VOID BspInitOldVswr()
{
    UINT32 i = 0;
    UINT32 j = 0;

    for (i = 0; i < BSP_HALADAPT_IC_CHAN_MAX_NUM; i++)
    {
        for (j = 0; j < MAX_BAND_NUM; j++)
        {
            g_oldvswr[i][j] = 1200000;
        }
    }
}

UINT32 BspInitPowCalc(void)
{
    UINT32 ulChanLoop = 0;
    UINT32 chanNum = BspGetBspChanNum(TX);
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && NULL != pFpgaInfo->pFuncInitFpgaPowCalc)
    {
        pFpgaInfo->pFuncInitFpgaPowCalc();
    }

    for(ulChanLoop = 0; ulChanLoop < chanNum; ulChanLoop++)
    {

        pPowRamSem[ulChanLoop] = semBCreate(SEM_Q_FIFO,SEM_FULL);
        pBBTssiPowRamSem[ulChanLoop] = semBCreate(SEM_Q_FIFO,SEM_FULL);
        pBBRssiPowRamSem[ulChanLoop] = semBCreate(SEM_Q_FIFO,SEM_FULL);
        g_semPowerUpdate[ulChanLoop] = semBCreate(SEM_Q_FIFO,SEM_FULL);
        if( (NULL == g_semPowerUpdate[ulChanLoop])||
            (NULL == pPowRamSem[ulChanLoop])||
            (NULL == pBBTssiPowRamSem[ulChanLoop])||
            (NULL == pBBRssiPowRamSem[ulChanLoop] ))
        {
            dbgErr("Tx %d Fail to create power Measure semaphore\n", ulChanLoop);
            return BSP_ERROR;
        }
    }
    BspInitOldVswr();
    return BSP_OK;
}

INT32 BspSetVswrThreshhold(UINT32 bspChn,UINT32 ulIndex,INT32 lVswrThreshhold)
{
    if((bspChn < BSP_HALADAPT_IC_CHAN_MAX_NUM) && (ulIndex < THRESHOLD_NUM))
    {
        g_lVswrThreshold[bspChn][ulIndex] = lVswrThreshhold;
    }
    return BSP_OK;
}

/* Started by AICoder, pid:9d322z446bz6891140410bedf069a74830931fdc */
INT32 BspGetVswrThreshhold(UINT32 bspChn,UINT32 ulIndex)
{
    UINT32 ratePowMw = 0;
    UINT32 retVal = 0;
    INT32 threshHold = 0;

    if((bspChn >= BSP_HALADAPT_IC_CHAN_MAX_NUM) || (ulIndex >= THRESHOLD_NUM))
    {
        return VSWR_THRESHOLD_DEFAULT;
    }

    if (NOT_QCELL_MODE == BspGetPbOrBbuMode())/* 非QCELL分支 */
    {
        retVal = BspGetRruPathRatedPower(bspChn, &ratePowMw);
        if (retVal != BSP_OK)
        {
            return VSWR_THRESHOLD_DEFAULT;
        }

        if (ratePowMw >= MIN_RATED_POWER_MW)
        {
            threshHold = (INT32)(1000.0*log10_s((DOUBLE)ratePowMw + 0.000001, 0.0)) - 2000;
        }
        else
        {
            threshHold = g_lVswrThreshold[bspChn][ulIndex];
        }
        return threshHold;
    }
    else /* QCELL分支 */
    {
        return g_lVswrThreshold[bspChn][ulIndex];
    }
}
/* Ended by AICoder, pid:9d322z446bz6891140410bedf069a74830931fdc */

INT32 BspSetPowThreshhold(UINT32 bspChn,UINT32 ulIndex,INT32 lPowThreshhold)
{
    if((bspChn < BSP_HALADAPT_IC_CHAN_MAX_NUM) && (ulIndex < THRESHOLD_NUM))
    {
        g_lPowDbmThreshold[bspChn][ulIndex] = lPowThreshhold;
    }
    return BSP_OK;
}

INT32 BspGetPowThreshhold(UINT32 bspChn,UINT32 ulIndex)
{
    UINT32 retVal = BSP_OK;
    INT32 deltaDbm = 0;

    if((bspChn < BSP_HALADAPT_IC_CHAN_MAX_NUM) && (ulIndex < THRESHOLD_NUM))
    {
        retVal = BspGetFwdDbmDelta(bspChn, &deltaDbm);

        if ((FWD_THRESHOLD == ulIndex) || (REV_THRESHOLD == ulIndex))
        {
            return g_lPowDbmThreshold[bspChn][ulIndex] + deltaDbm;
        }
        else
        {
            return g_lPowDbmThreshold[bspChn][ulIndex];
        }
    }

    return retVal;
}

UINT32 CopyToVswrPow(UINT32 difChn,INT32 powIndex,INT32 vswrIndex)
{
    T_TxPow *pTxPowVal = &sTxPowVal[difChn][powIndex];
    UINT32 thresholdType = FWD_THRESHOLD;
    INT32 fbPow = pTxPowVal->tFwdPow.fbPow;

    if (fbPow >= BspGetVwsrThreshold(difChn,thresholdType))
    {
        memcpy_s(&sVswrPowVal[difChn][vswrIndex], sizeof(T_TxPow), pTxPowVal, sizeof(T_TxPow));
        return BSP_OK;
    }
    return BSP_ERROR;
}

/*计算平均功率*/
UINT32 CalAvgTssiFwd(UINT32 bspChn, UINT32 iCntNum, T_TxPow pPowVal[], T_TxPow *pPowAvgVal)
{
    INT32 iCnt = 0;
    INT32 iAlarmSum = 0;
    INT64 iFwdIfPowSum = 0;
    INT64 iFwdfbPowSum = 0;
    INT64 iRevIfPowSum = 0;
    INT64 iRevfbPowSum = 0;

    for(iCnt = 0; iCnt < iCntNum; iCnt++)
    {
        iFwdIfPowSum += pPowVal[iCnt].tFwdPow.ifTssiPow;
        iFwdfbPowSum += pPowVal[iCnt].tFwdPow.fbPow;

        iRevIfPowSum += pPowVal[iCnt].tRevPow.ifTssiPow;
        iRevfbPowSum += pPowVal[iCnt].tRevPow.fbPow;

        iAlarmSum |= pPowVal[iCnt].isPowValid;
    }

    pPowAvgVal->tFwdPow.ifTssiPow = (INT32)(iFwdIfPowSum / iCntNum);
    pPowAvgVal->tFwdPow.fbPow = (INT32)(iFwdfbPowSum / iCntNum);

    pPowAvgVal->tRevPow.ifTssiPow = (INT32)(iRevIfPowSum / iCntNum);
    pPowAvgVal->tRevPow.fbPow = (INT32)(iRevfbPowSum / iCntNum);

    pPowAvgVal->isPowValid = (iAlarmSum ? 1 : 0);

    return BSP_OK;
}
#if 0
/*todo:DPDIC4编译修改：定义宏*/
#define BSP_MAX_BBCARR_NUM (10U)

UINT32 GetMaxBbPcPowVal(UINT32 bspChan, T_TxPow *pTxPcPowVal, T_TxBbPcPow pTxBbPcPowVal[], T_TxPow *pTxPcMaxPowVal, T_TxBbPcPow pTxBbPcMaxPowVal[])
{
    UINT32 carrId = 0;
    INPUT_POINTER_CHECK(pTxPcPowVal);
    INPUT_POINTER_CHECK(pTxBbPcPowVal);
    INPUT_POINTER_CHECK(pTxPcMaxPowVal);
    INPUT_POINTER_CHECK(pTxBbPcMaxPowVal);

    validCarrNum[bspChan][1] = 0;
    if(pTxPcPowVal->tFwdPow.ifTssiPow > g_pcPowDbmThred)
    {
        validIfPow[bspChan]++;
        for(carrId=0; carrId < BSP_MAX_BBCARR_NUM; carrId++)
        {
            if(pTxBbPcPowVal[carrId].tbbPcPow.tFwdPow.ifTssiPow > g_bbPcPowDbmThred) /*分载波pc功率检测门限*/
            {
                validCarrNum[bspChan][1]++;
            }
        }
        if(validCarrNum[bspChan][1]>validCarrNum[bspChan][0])
        {
            memcpy_s(pTxPcMaxPowVal, sizeof(T_TxPow), pTxPcPowVal, sizeof(T_TxPow));
            memcpy_s(pTxBbPcMaxPowVal, sizeof(T_TxBbPcPow)*BSP_MAX_CARR_NUM, pTxBbPcPowVal, sizeof(T_TxBbPcPow)*BSP_MAX_CARR_NUM);
            validCarrNum[bspChan][0] = validCarrNum[bspChan][1];
        }
    }
    else if(0 == validIfPow[bspChan])/*之前没有一组满足和载波门限*/
    {
        pTxPcMaxPowVal->tFwdPow.ifTssiPow = 0;//INVALID_VALUE;
        pTxPcMaxPowVal->tFwdPow.fbPow = 0;//INVALID_VALUE;
        pTxPcMaxPowVal->tRevPow.ifTssiPow = 0;//INVALID_VALUE;
        pTxPcMaxPowVal->tRevPow.fbPow = 0;//INVALID_VALUE;
        for(carrId=0; carrId < BSP_MAX_CARR_NUM; carrId++)
        {
            pTxBbPcMaxPowVal[carrId].tbbPcPow.tFwdPow.ifTssiPow = 0;//INVALID_VALUE;
            pTxBbPcMaxPowVal[carrId].tbbPcPow.tFwdPow.fbPow = 0;//INVALID_VALUE;
            pTxBbPcMaxPowVal[carrId].tbbPcPow.tRevPow.ifTssiPow = 0;//INVALID_VALUE;
            pTxBbPcMaxPowVal[carrId].tbbPcPow.tRevPow.fbPow = 0;//INVALID_VALUE;
        }
    }

    return BSP_OK;
}

UINT32 BspInitSetVswrPowVal(INT32 initVswrVal)
{
    UINT32 loopSel = 0;

    for (loopSel = 0; loopSel < BSP_HALADAPT_IC_CHAN_MAX_NUM; loopSel++)
    {
        sVswrAvgVal[loopSel].tFwdPow.ifTssiPow = initVswrVal;
        sVswrAvgVal[loopSel].tFwdPow.fbPow = initVswrVal;
        sVswrAvgVal[loopSel].tRevPow.ifTssiPow = initVswrVal;
        sVswrAvgVal[loopSel].tRevPow.fbPow = initVswrVal;
    }
    return BSP_OK;
}
#endif
//功放保护的标志信号，‘1’为异常保护发生，BSP驻波计算过程中，丢掉当前采集值，认为无效值；同时停止动态功控调整。‘0’表示正常有效。采用读清零方式。
UINT32 GetTssiAlmStatus(UINT32 bspChn,UINT32 *regVal)
{
    UINT32 uRetVal = BSP_OK;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo)
    {
        INPUT_BSPCHN_CHECK(bspChn);
        if (FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChn] && NULL != pFpgaInfo->pFuncGetFpgaTssiAlmStatus)
        {
            uRetVal = pFpgaInfo->pFuncGetFpgaTssiAlmStatus(bspChn, regVal);
        }
        return uRetVal;
    }

#if 0 
    UINT32 uRetVal = BSP_ERROR;
    UINT32 uChipId=0;
    UINT32 difChan=0;

    if(BspGetDifInfoByBspChn(bspChn,TX,&uChipId,&difChan) != BSP_OK)
    {
        dbgErr("%s BspGetDifInfoByBspChn(%d,TX) return error\n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    uRetVal = BspHalAdaptGetPowInvalidFlag(difChan,regVal);
    return uRetVal;
#else 
    return BSP_OK;
#endif
}

UINT32 ClrTssiAlm(UINT32 bspChn)
{
#if 0 
    UINT32 uRetVal = BSP_ERROR;
    UINT32 uChipId=0;
    UINT32 difChan=0;

    if(BspGetDifInfoByBspChn(bspChn,TX,&uChipId,&difChan) != BSP_OK)
    {
        dbgErr("%s BspGetDifInfoByBspChn(%d,TX) return error\n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    uRetVal = BspHalAdaptClrPowInvalidFlag(difChan);
    return uRetVal;
#else 
    return BSP_OK;
#endif    
}

static UINT32 testGetTssiAlmStatus(UINT32 bspChn)
{
    UINT32 regVal = 0;
    
    if(BSP_OK == GetTssiAlmStatus(bspChn,&regVal))
    {
        dbgInfo("regVal = %#x \n", regVal);
    }
    else 
    {
        dbgInfo("err \n");
    }
    return BSP_OK;
}

static void powcalsw(UINT32 idbgisr )
{
    g_dbgisr = idbgisr;
}

/*DPDIC4.0轮询时间由单板传入*/
UINT32 g_spePowTimeMs = 2560;/*所有通道轮询一次的总时间，对于2片IC对接1片MTS情况，由于总时间是按照俩片IC进行交叉检测的，所以是2片IC所有通道轮询一次的时间*/
/*设置轮询时间片，当双反馈的时候总体时间*/
UINT32 BspSetSpePowTimeCfg(UINT32 TimeMs)
{
    g_spePowTimeMs = TimeMs;

    return BSP_OK;
}
UINT32 BspGetSpePowTimeCfg(UINT32 *TimeMs)
{
    INPUT_POINTER_CHECK(TimeMs);
    *TimeMs = g_spePowTimeMs;
    dbgInfoEx("%s|times:%d(ms)\n",__FUNCTION__,g_spePowTimeMs);
    return BSP_OK;
}

static void CleanPowshowValue(void)
{
    memset_s(sTxPowVal, sizeof(sTxPowVal), 0, sizeof(sTxPowVal));
    memset_s(sVswrPowVal, sizeof(sVswrPowVal), 0, sizeof(sVswrPowVal));
    memset_s(sVswrAvgVal, sizeof(sVswrAvgVal), 0, sizeof(sVswrAvgVal));
    memset_s(sTxPowAvgVal, sizeof(sTxPowAvgVal), 0, sizeof(sTxPowAvgVal));
}

UINT32 g_tssiPrnTimes = 150;
VOID BspPrintTssiTestInit(VOID)
{
    UINT32 index = 0;
    T_Pow fwd = {0};
    INT32  dlPreGain = 0;
    INT32  dlBankAptune = 0;
    INT32  dlBankDgain = 0;
    INT32  dlPreGainEn = 0;
    INT32  dlBankAptuneEn = 0;
    INT32  dlBankDgainEn = 0;
    UINT32  chan = 0;
    UINT32  carrIndex = 0;
    UINT32  radioMode = BSP_RADIO_STANDARD_FDD_5G;
    INT32 rssiDbm = 0;
    INT32 rssiDbfs =0;

    BspLog(LOG_LEVEL_0,"BspPrintTssiTest i avg:TSSI FWD max:TSSI FWD RSSI:[dbfs: dbm:] gain[dlPreGain dlBankAptune dlBankDgain] gainEn[dlPreGainEn,dlBankAptuneEn,dlBankDgainEn]\n");
    dbgInfo("BspPrintTssiTest i avg:TSSI FWD max:TSSI FWD RSSI:[dbfs: dbm:] gain[dlPreGain dlBankAptune dlBankDgain] gainEn[dlPreGainEn,dlBankAptuneEn,dlBankDgainEn]\n");
    for(index = 0; index < g_tssiPrnTimes; index++)
    {
        IcHalApiReadFwdIfPow(chan, &fwd);
        BspHalAdaptGetDlpreGain(chan, carrIndex, radioMode, &dlPreGain);
        BspHalAdaptGetDlbankAptune(chan, carrIndex, radioMode, &dlBankAptune);
        BspHalAdaptGetDlbankDgain(chan, carrIndex, radioMode, &dlBankDgain);
        BspHalAdaptGetDlPerCarrGainSw(chan, radioMode, carrIndex, &dlPreGainEn);
        BspHalAdaptGetDlBankAptuneCarrGainSw(chan, radioMode, carrIndex, &dlBankAptuneEn);
        BspHalAdaptGetDlCarrGainSw(chan, radioMode, carrIndex, &dlBankDgainEn);

        BspGetRssiPowInfoByMode(chan, carrIndex, radioMode, 0, 0, &rssiDbm,&rssiDbfs);

        BspLog(LOG_LEVEL_0,"BspPrintTssiTest i:%d  tick_10ms[%llu] avg:TSSI= %d FWD= %d max:TSSI= %d FWD= %d RSSI:[dbfs:%d dbm:%d] gain[%d %d %d] gainEn[%d %d %d]\n", index, tick64Get(), fwd.iTssiAvgDbfs, fwd.iFwdAvgDbfs,\
                fwd.iTssiMaxDbfs, fwd.iFwdMaxDbfs, rssiDbfs, rssiDbm, dlPreGain,dlBankAptune,dlBankDgain, dlPreGainEn,dlBankAptuneEn,dlBankDgainEn);
        dbgInfoEx("BspPrintTssiTest i:%d tick_10ms[%llu] avg:TSSI= %d FWD= %d max:TSSI= %d FWD= %d RSSI:[dbfs:%d dbm:%d] gain[%d %d %d] gainEn[%d %d %d] \n", index, tick64Get(), fwd.iTssiAvgDbfs, fwd.iFwdAvgDbfs,\
                fwd.iTssiMaxDbfs, fwd.iFwdMaxDbfs, rssiDbfs, rssiDbm, dlPreGain,dlBankAptune,dlBankDgain, dlPreGainEn,dlBankAptuneEn,dlBankDgainEn);
        BspSysMsDelay(200);
    }

    return;
}

/* 环网定位倒换时功率恢复情况维测接口，倒换前手动调用 */
UINT32 BspPrintTssiTest(UINT32 prnTimes)
{
    UINT32 ulRet = BSP_OK;
    INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;

    if(prnTimes != 0)
    {
        g_tssiPrnTimes = prnTimes;
    }
    lTaskID = taskSpawn("BspPrintTssiTest", NBICACC_PROCESS_PRIORITY, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspPrintTssiTestInit, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, lTaskID);
        ulRet = BSP_ERROR;
    }
    else
    {
        dbgInfo("create thread<%s> success!\n", __FUNCTION__);
    }

    return ulRet;
}

/* ANF\NBIC下复位出光板或插拔光纤偶现ANF\NBIC抵消功能异常问题，检测光口帧头计数由不正常累加到正常不累加状态，清NbicAcc */
UINT32 BspSetNbicAccClrByOptFrSta(UINT32 logOpt)
{
    if(logOpt >= MAIN_LOG_OPT_CNT)
    {
        return BSP_ERROR;
    }
    g_lastOptRptFrAlmCnt[logOpt] = g_currOptRptFrAlmCnt[logOpt];
    g_currOptRptFrAlmCnt[logOpt] = BspHalAdaptOptRptFrAlmCnt(logOpt);

    if (g_lastOptRptFrAlmCnt[logOpt] != g_currOptRptFrAlmCnt[logOpt])
    {
        if (g_frStaChangeFlag[logOpt] == 0)
        {
            g_frStaChangeFlag[logOpt] = 1;
        }
        g_frStaOkCnt[logOpt] = 0;
    }
    else
    {
        if (g_frStaChangeFlag[logOpt] == 1)
        {
            g_frStaOkCnt[logOpt]++;
            if(g_frStaOkCnt[logOpt] >= 3) /* FrAlmCnt变稳定防抖3次 */
            {
                BspHalAdaptSetNbicAccClr();
                BspLog(LOG_LEVEL_0,"[%s] logOpt:%d NbicAccClr**\n", __FUNCTION__, logOpt);
                g_frStaChangeFlag[logOpt] = 0;
                g_frStaOkCnt[logOpt] = 0;
            }
        }
    }

    return BSP_OK;
}

VOID BspSetNbicAccClrThreadSw(UINT32 sw)
{
    s_nbicAccClrThreadSw = sw;
}

UINT32 BspGetNbicAccClrThreadSw(VOID)
{
    return s_nbicAccClrThreadSw;
}

UINT32 BspSetNbicAccClrByFrSta()
{
    UINT32 rpuId  = 0;

    rpuId = BspGetRpuId();
    while(1)
    {
        if (SWITCH_ON != s_nbicAccClrThreadSw)
        {
            BspSysMsDelay(2000);
            continue;
        }
        BspSetNbicAccClrByOptFrSta(0); /* 从片只判断逻辑0 Fr计数状态 */
        if(0 == rpuId)
        {
            BspSetNbicAccClrByOptFrSta(1); /* 单片或主片逻辑口0和逻辑口1都判断 */
        }
        BspSysMsDelay(2000);
    }
    return BSP_OK;
}

UINT32 BspSetNbicAccClrThreadInit(void)
{
    UINT32 ulRet = BSP_OK;
    INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;
    UINT32 rruType = 0;

    rruType = BspGetFddTddCoExistSta();
    if(MODE_ONLY_TDD == rruType || MODE_QCELL == rruType)
    {
        return BSP_OK;
    }
    lTaskID = taskSpawn("BspSetNbicAcc", NBICACC_PROCESS_PRIORITY, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspSetNbicAccClrByFrSta, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, lTaskID);
        ulRet = BSP_ERROR;
    }
    else
    {
        dbgInfo("create thread<%s> success!\n", __FUNCTION__);
    }

    return ulRet;
}

UINT32 BspSetFpgaDataFresh(UINT32 bspChn, UINT32 freshflag)
{
    INPUT_BSPCHN_CHECK(bspChn);
    UINT32 retVal = BSP_OK;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChn] && NULL != pFpgaInfo->pFuncSetFpgaDataFresh)
    {
        retVal = pFpgaInfo->pFuncSetFpgaDataFresh(freshflag);
        if (freshflag == 1)
        {
            BspSysMsDelay(10);
        }
    }

    return retVal;
}

/*Bsp实时刷新功率检测任务,DPDIC4.0中直接由单板传入*/
UINT32 BspPowCalcThreadIsr(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 bspChn = 0;
    INT32 PowAvgCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
    INT32 vswrAvgCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
    UINT32 almStatus = 0; //功放保护标志
    UINT32 difChan = 0;
    UINT32 chipId = 0;
    UINT32 temp = 0;
    UINT32 validFlag = 0;
    UINT32 SpePowTime = 2560;
    UINT32 chanNum = BspGetTxChannel();
    UINT32 lastFrId = 0;
    UINT32 frId = 0;


    /*所有通道更新一次功率所用的总时间*/

    while(1)
    {
        /*所有通道更新一次功率所用的总时间，延时后将所有通道功率依次读出*/
        BspGetSpePowTimeCfg(&SpePowTime);  /*工装需要修改延时 检测固定通道固定时间片*/
        BspSysMsDelay(SpePowTime);
        if (1 == g_dbgisr)
        {
            continue;
        }
        BspHalAdaptGetWirelessFrId(&frId);
        if (frId == lastFrId)
        {
            dbgInfoEx("[%s]: frId=%u not change, clean pow value\n", __FUNCTION__, frId);
            CleanPowshowValue();
            continue;
        }
        dbgInfoEx("[%s]: frId=%u lastFrId=%u\n", __FUNCTION__, frId, lastFrId);
        lastFrId = frId;
        for (bspChn=0; bspChn < chanNum; bspChn++)
        {
            /* fpga链路，d42链路无需关注此处 */
            (void)BspSetFpgaDataFresh(bspChn, 1);

            if (SWITCH_OFF == g_ulPowCalcEnable[bspChn])
            {
                continue;
            }
            
            temp = BspGetDifInfoByBspChn(bspChn ,TX, &chipId, &difChan);
            dbgInfoEx("%s[%d] BspGetDifInfoByBspChn ret:%#x\n", __FUNCTION__, __LINE__, temp);

            /************************获取传统功率检测的底层上报的功率***************************/
            if(pGetPaProFlagCall != NULL)
            {
                validFlag = pGetPaProFlagCall(bspChn);
            }
            else
            {
                GetTssiAlmStatus(bspChn,&almStatus);
                validFlag |= almStatus;
            }

            retVal = GatherTssiFwd(difChan, PowAvgCnt[bspChn]);
            if (BSP_OK != retVal)
            {
                continue;
            }

            if(pGetPaProFlagCall != NULL)
            {
                validFlag = pGetPaProFlagCall(bspChn);
            }
            else
            {
                GetTssiAlmStatus(bspChn,&almStatus);
                validFlag |= almStatus;  //此处在功率读取前后，各读取一次功率有效标志，如果2次都为0，才代表该功率真正有效
            }

            sTxPowVal[difChan][PowAvgCnt[bspChn]].isPowValid = validFlag;
            if (DATA_NORMAL == validFlag)
            {
                retVal = CopyToVswrPow(difChan, PowAvgCnt[bspChn], vswrAvgCnt[bspChn]);
                if (BSP_OK == retVal)
                {
                    vswrAvgCnt[bspChn]++;
                }
            }
            else
            {
               g_ulPowDataInvalidFlag[bspChn] = POW_INVALID_CONSIST;
               g_ulPowDataInvalidCause[bspChn] = validFlag;
            }
            /****************************计算平均功率********************************/
            if (PowAvgCnt[bspChn]++ >= g_ulPowAvgSlotCnt[bspChn]-1)
            {
                PowAvgCnt[bspChn] = 0;
                CalAvgTssiFwd(bspChn, g_ulPowAvgSlotCnt[bspChn], sTxPowVal[difChan], &sTxPowAvgVal[bspChn]);
                
                if (MAX_UPDATE_CNT == g_aulTxPowUpdateCnt[bspChn])
                {
                    g_aulTxPowUpdateCnt[bspChn] = 0;
                }
                else
                {
                    g_aulTxPowUpdateCnt[bspChn]++;
                }
            }
            /*************************calvswr***************************/
            if (vswrAvgCnt[bspChn] >= g_ulVswrAvgSlotCnt[bspChn])
            {
                vswrAvgCnt[bspChn] = 0;
                //..vswr统计平均值
                CalAvgTssiFwd(bspChn, g_ulVswrAvgSlotCnt[bspChn], sVswrPowVal[difChan], &sVswrAvgVal[bspChn]);

                /* 标量驻波比更新计数自增*/
                if (MAX_UPDATE_CNT == g_ulVswrUpdateCnt[bspChn])
                {
                    g_ulVswrUpdateCnt[bspChn] = 0;
                }
                else
                {
                    g_ulVswrUpdateCnt[bspChn]++;
                }
            }
            ClrTssiAlm(bspChn); /*功放保护接口*/
            validFlag = 0;
            #if 0
            /*和王瑜00316247确认，IC4.2无PC功率*/
            /************************获取PC功率检测的底层上报的功率***************************/
            retVal = GatherPcTssiFwdPow(difChan);
            if (BSP_OK != retVal)
            {
                continue;
            }
            /****************************统计PCTSSI中最优的一组值*****************************/
            if (pcPowAvgCnt[bspChn]++ < g_ulBbPcPowCnt[bspChn])
            {
                GetMaxBbPcPowVal(bspChn, &(sTxPcPowVal[difChan]), sTxBbPcPowVal[difChan], &(sTxMaxPcPowVal[bspChn]), sTxMaxBbPcPowVal[bspChn]);
            }
            else
            {
                memcpy_s(&(sTxReportPcPowVal[bspChn]), sizeof(T_TxPow) ,&(sTxMaxPcPowVal[bspChn]), sizeof(T_TxPow));
                memcpy_s(sTxReportBbPcPowVal[bspChn], sizeof(T_TxBbPcPow)*BSP_MAX_CARR_NUM, sTxMaxBbPcPowVal[bspChn], sizeof(T_TxBbPcPow)*BSP_MAX_CARR_NUM);
                reportCarrNum[bspChn] = validCarrNum[bspChn][0];
                pcPowAvgCnt[bspChn] = 0;
                validCarrNum[bspChn][0] = 0;/*清除当前满足二级门限最优的载波数目*/
                validIfPow[bspChn] = 0;/*清除当前满足一级门限的组数*/
                if (MAX_UPDATE_CNT == g_aulTxPcPowUpdateCnt[bspChn])
                {
                    g_aulTxPcPowUpdateCnt[bspChn] = 0;
                }
                else
                {
                    g_aulTxPcPowUpdateCnt[bspChn]++;
                }
            }
            #endif
            /* fpga链路，d42链路无需关注此处 */
            (void)BspSetFpgaDataFresh(bspChn, 0);
        }
    }
}


UINT32 BspPowCalcThreadInit(void)
{
    UINT32 ulRet = BSP_OK;
    static INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;

    if (lTaskID != ((INT32)BSP_ERROR))
    {
        return BSP_ERROR;
    }

    lTaskID = taskSpawn("BspPowCalcThread", 100, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspPowCalcThreadIsr, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgInfo("!!! Creat BspPowCalcThreadIsr Error !!!\n");
        dbgInfo("ulOptTaskRetVal = %x\n", lTaskID);
        dbgInfo("[1first]ulTaskStack = %d\n", ulTaskStack);
        ulRet = BSP_ERROR;
    }

    return ulRet;
}

/*DSP功率检测轮询周期设置*/
UINT32 BspSetDpdPowCalcTime(UINT32 timeMs)
{
    sDspPowCalcPara.powCalcDpdTime = timeMs;

    return BSP_OK;
}
/*DSP功率检测轮询周期获取*/
UINT32 BspGetDpdPowCalcTime(void)
{
    return sDspPowCalcPara.powCalcDpdTime;
}
/*设置通道功率检测模式 0：IC检测 1：DSP检测*/
UINT32 BspSetSpePowPowCalcWayByChan(UINT32 bspChan,UINT32 calcWay)
{
    if(bspChan >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }
    g_spePowCalcWay[bspChan] = calcWay;
    return BSP_OK;
}
/*获取通道功率检测模式 0：IC检测 1：DSP检测*/
UINT32 BspGetSpePowPowCalcWayByChan(UINT32 bspChan)
{
    if(bspChan >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        return g_spePowCalcWay[0];
    }
    return g_spePowCalcWay[bspChan];
}

/*复制功率信息*/
UINT32 CopyFwdRevDbfs(T_TxPow *ptAvgTxPow,T_TxPow *pPowDbfs)
{
    pPowDbfs->tFwdPow.fbPow = ptAvgTxPow->tFwdPow.fbPow;
    pPowDbfs->tFwdPow.ifTssiPow = ptAvgTxPow->tFwdPow.ifTssiPow;
    pPowDbfs->tRevPow.fbPow = ptAvgTxPow->tRevPow.fbPow;
    pPowDbfs->tRevPow.ifTssiPow = ptAvgTxPow->tRevPow.ifTssiPow;
    return BSP_OK;
}
/*清除DSP上报功率*/
void CleanDspPowshowValue(void)
{
    UINT32 chanIndex = 0;
    for(chanIndex = 0; chanIndex < BSP_HALADAPT_IC_CHAN_MAX_NUM; chanIndex++)
    {
        sDspTxPowAvgVal[chanIndex].tFwdPow.fbPow = GET_POW_DBFS(0,16);
        sDspTxPowAvgVal[chanIndex].tFwdPow.ifTssiPow = GET_POW_DBFS(0,14);
        sDspTxPowAvgVal[chanIndex].tRevPow.fbPow = GET_POW_DBFS(0,16);
        sDspTxPowAvgVal[chanIndex].tRevPow.ifTssiPow = GET_POW_DBFS(0,14);
    }
}
void dspdbfs(void)
{
    UINT32 chanIndex = 0;
    dbgInfo("*************************上报值**************************************************\n");
    for(chanIndex = 0; chanIndex < BspGetTxChannel(); chanIndex++)
    {
        dbgInfo("Chan %2d:FwdTssi=%6d | FbFwd=%6d | RevTssi=%6d | FbRev=%6d | isPowValid=%6d\n",\
                chanIndex, sDspTxPowAvgVal[chanIndex].tFwdPow.ifTssiPow, sDspTxPowAvgVal[chanIndex].tFwdPow.fbPow\
                ,sDspTxPowAvgVal[chanIndex].tRevPow.ifTssiPow, sDspTxPowAvgVal[chanIndex].tRevPow.fbPow\
                ,sDspTxPowAvgVal[chanIndex].isPowValid);
    }
    dbgInfo("*************************给DSP下发值**************************************************\n");
        for(chanIndex = 0; chanIndex < BspGetTxChannel(); chanIndex++)
    {
        dbgInfo("Chan %2d:FwdTssi=%6d | FbFwd=%6d | RevTssi=%6d | FbRev=%6d | isPowValid=%6d\n",\
                chanIndex, sDspSetTxPowAvgVal.tTxPow[chanIndex].tFwdPow.ifTssiPow, sDspSetTxPowAvgVal.tTxPow[chanIndex].tFwdPow.fbPow\
                ,sDspSetTxPowAvgVal.tTxPow[chanIndex].tRevPow.ifTssiPow, sDspSetTxPowAvgVal.tTxPow[chanIndex].tRevPow.fbPow\
                ,sDspSetTxPowAvgVal.tTxPow[chanIndex].isPowValid);
    }
/*        这个值周期性清除 不显示
    dbgInfo("*************************DSP计算值**************************************************");
    for(chanIndex = 0; chanIndex < BspGetTxChannel(); chanIndex++)
    {
        dbgInfo("Chan %2d:FwdTssi=%6d | FbFwd=%6d | RevTssi=%6d | FbRev=%6d | isPowValid=%6d\n",\
                chanIndex, sDspGetTxPowAvgVal.tTxPow[chanIndex].tFwdPow.ifTssiPow, sDspGetTxPowAvgVal.tTxPow[chanIndex].tFwdPow.fbPow\
                ,sDspGetTxPowAvgVal.tTxPow[chanIndex].tRevPow.ifTssiPow, sDspGetTxPowAvgVal.tTxPow[chanIndex].tRevPow.fbPow\
                ,sDspGetTxPowAvgVal.tTxPow[chanIndex].isPowValid);
    }*/
}
/*初始化DSP功率检测参数*/
UINT32 BspInitDspPowCalcPara(T_DspPowCalcPara* pDspPowPara)
{
    UINT32 loop = 0;
    UINT32 chanNum = BspGetTxChanNum();
    UINT32 chanMask = 0;

    memcpy_s(&sDspPowCalcPara, sizeof(T_DspPowCalcPara), pDspPowPara, sizeof(T_DspPowCalcPara));
    chanMask = pDspPowPara->dspCalcChanMask;
    chanNum = min(chanNum,BSP_HALADAPT_IC_CHAN_MAX_NUM);
    for(loop = 0; loop < chanNum; loop++)
    {
        if((BIT_SET(loop) & chanMask) != 0 )
        {
            BspSetSpePowPowCalcWayByChan(loop,1);
        }
    }
    CleanDspPowshowValue();
    return BSP_OK;
}

/*从DSP获取前反馈功率*/
UINT32 BspGetPowInfoFromDsp(T_TxAllChanPow* pTxAllChanPowInfo)
{
    UINT32 ret = BSP_ERROR;
    if(sDspPowCalcPara.pGetPowInfoFromDsp != NULL)
    {
        ret = sDspPowCalcPara.pGetPowInfoFromDsp(pTxAllChanPowInfo);
    }
    return ret;
}
/*向DSP传递功率信息*/
UINT32 BspSetPowInfoToDsp(T_TxAllChanPow* pTxAllChanPowInfo)
{
    UINT32 ret = BSP_ERROR;
    if(sDspPowCalcPara.pSetPowInfoToDsp != NULL)
    {
        ret = sDspPowCalcPara.pSetPowInfoToDsp(pTxAllChanPowInfo);
    }
    return ret;
}
/*将DSP检测的上报功率有效标志置为无效*/
UINT32 BspSetDspPowAllInValid(void)
{
    UINT32 chanIndex = 0;
    UINT32 chanNum = BspGetTxChannel();
    UINT32 powCalcWay[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
    for(chanIndex = 0; chanIndex < chanNum; chanIndex++)
    {
        if(chanIndex >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
        {
            continue;
        }
        dbgInfoEx("[%s]chanindex'%d powCalcWay'%d \n",__FUNCTION__,chanIndex,powCalcWay[chanIndex]);
        powCalcWay[chanIndex] = BspGetSpePowPowCalcWayByChan(chanIndex);
        if(powCalcWay[chanIndex] != POW_CALC_WAY_DSP)
        {
            continue;
        }
        sDspTxPowAvgVal[chanIndex].isPowValid = 1;
        sDspPowCalcPara.pSetDspPowInvalidAlarmFlag(DSP_POW_CALC_ALARM_SAVE_IDX,chanIndex,1);
    }
    return BSP_OK;
}
/*将DSP检测功率上报到上报数组中*/
UINT32 BspSetDspPowToAvgVal(T_TxAllChanPow* pTxAllChanPowInfo)
{
    UINT32 chanIndex = 0;
    UINT32 powCalcWay[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
    UINT32 chanNum = BspGetTxChannel();
    for(chanIndex = 0; chanIndex < chanNum; chanIndex++)
    {
        if(chanIndex >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
        {
            continue;
        }
        powCalcWay[chanIndex] = BspGetSpePowPowCalcWayByChan(chanIndex);
        dbgInfoEx("[%s] chanindex'%d powCalcWay'%d \n",__FUNCTION__,chanIndex,powCalcWay[chanIndex]);
        if(powCalcWay[chanIndex] != POW_CALC_WAY_DSP)
        {
            sDspPowCalcPara.pSetDspPowInvalidAlarmFlag(DSP_POW_CALC_ALARM_SAVE_IDX,chanIndex,0);
            continue;
        }
        pTxAllChanPowInfo->tTxPow[chanIndex].tRevPow.fbPow = GET_POW_DBFS(0,16);
        pTxAllChanPowInfo->tTxPow[chanIndex].tRevPow.ifTssiPow = GET_POW_DBFS(0,14);
        dbgInfoEx("[%s] chanindex'%d isPowValid'0x%04x \n",__FUNCTION__,chanIndex,pTxAllChanPowInfo->tTxPow[chanIndex].isPowValid);
        if(pTxAllChanPowInfo->tTxPow[chanIndex].isPowValid == 0x5a5a)
        {
            sDspTxPowAvgVal[chanIndex].isPowValid = 0;
            CopyFwdRevDbfs(&pTxAllChanPowInfo->tTxPow[chanIndex],&sDspTxPowAvgVal[chanIndex]);
            sDspPowCalcPara.pSetDspPowInvalidAlarmFlag(DSP_POW_CALC_ALARM_SAVE_IDX,chanIndex,0);
            dbgInfoEx("[%s] FWD ifTssiPow'%d fbPow'%d\n",__FUNCTION__,pTxAllChanPowInfo->tTxPow[chanIndex].tFwdPow.ifTssiPow,pTxAllChanPowInfo->tTxPow[chanIndex].tFwdPow.fbPow);
            dbgInfoEx("[%s] REV ifTssiPow'%d fbPow'%d\n",__FUNCTION__,pTxAllChanPowInfo->tTxPow[chanIndex].tRevPow.ifTssiPow,pTxAllChanPowInfo->tTxPow[chanIndex].tRevPow.fbPow);
        }
        else
        {
            sDspTxPowAvgVal[chanIndex].isPowValid = 1;
            sDspPowCalcPara.pSetDspPowInvalidAlarmFlag(DSP_POW_CALC_ALARM_SAVE_IDX,chanIndex,1);
        }
    }
    return BSP_OK;
}
/*填充给DSP传递的功率信息*/
static void BspFillDspPowInfo(T_TxAllChanPow* pTxAllChanPowInfo)
{
    UINT32 chanIndex = 0;
    UINT32 powCalcWay[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
    UINT32 chanNum = BspGetTxChannel();
    UINT32 txPowUpdateCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM]={0};
    UINT32 validFlag = 0;

    for(chanIndex = 0; chanIndex < chanNum; chanIndex++)
    {
        if(chanIndex >=BSP_HALADAPT_IC_CHAN_MAX_NUM)
        {
            dbgErr("bspChn'%d over %d\n",chanIndex, BSP_HALADAPT_IC_CHAN_MAX_NUM);
            continue;
        }
        dbgInfoEx("[%s] chanindex'%d PowCalcEnable'%dx \n",__FUNCTION__,chanIndex,g_ulPowCalcEnable[chanIndex]);
        if (SWITCH_OFF == g_ulPowCalcEnable[chanIndex])
        {
            pTxAllChanPowInfo->tTxPow[chanIndex].isPowValid = 1;
            continue;
        }
        powCalcWay[chanIndex] = BspGetSpePowPowCalcWayByChan(chanIndex);
        dbgInfoEx("[%s] chanindex'%d powCalcWay'%d \n",__FUNCTION__,chanIndex,powCalcWay[chanIndex]);
        if(powCalcWay[chanIndex] != POW_CALC_WAY_DSP)
        {
            pTxAllChanPowInfo->tTxPow[chanIndex].isPowValid = 1;
            continue;
        }
        /****************************获取平均功率********************************/
        CalFwdRevDbfs(chanIndex, &sTxPowAvgVal[chanIndex], &pTxAllChanPowInfo->tTxPow[chanIndex]);
        dbgInfoEx("[%s] FWD ifTssiPow'%d fbPow'%d\n",__FUNCTION__,sTxPowAvgVal[chanIndex].tFwdPow.ifTssiPow,sTxPowAvgVal[chanIndex].tFwdPow.fbPow);
        dbgInfoEx("[%s] REV ifTssiPow'%d fbPow'%d\n",__FUNCTION__,sTxPowAvgVal[chanIndex].tRevPow.ifTssiPow,sTxPowAvgVal[chanIndex].tRevPow.fbPow);
        dbgInfoEx("[%s] FWD ifTssiPow'%d fbPow'%d\n",__FUNCTION__,pTxAllChanPowInfo->tTxPow[chanIndex].tFwdPow.ifTssiPow,pTxAllChanPowInfo->tTxPow[chanIndex].tFwdPow.fbPow);
        dbgInfoEx("[%s] REV ifTssiPow'%d fbPow'%d\n",__FUNCTION__,pTxAllChanPowInfo->tTxPow[chanIndex].tRevPow.ifTssiPow,pTxAllChanPowInfo->tTxPow[chanIndex].tRevPow.fbPow);
        dbgInfoEx("[%s] txPowUpdateCnt'%d g_aulTxPowUpdateCnt'%d \n",__FUNCTION__,txPowUpdateCnt[chanIndex],g_aulTxPowUpdateCnt[chanIndex]);
        if(txPowUpdateCnt[chanIndex] == g_aulTxPowUpdateCnt[chanIndex])
        {
            validFlag = 1;
        }
        else
        {
            txPowUpdateCnt[chanIndex] = g_aulTxPowUpdateCnt[chanIndex];
            validFlag = 0;
        }
        pTxAllChanPowInfo->tTxPow[chanIndex].isPowValid = sTxPowAvgVal[chanIndex].isPowValid | validFlag;
        dbgInfoEx("isPowValid = %d|%d validFlag=%u \n",pTxAllChanPowInfo->tTxPow[chanIndex].isPowValid,sTxPowAvgVal[chanIndex].isPowValid,validFlag);
        validFlag = 0;
    }
}


/*DSP实时刷新功率检测任务*/
UINT32 BspDpdPowCalcThreadIsr(void)
{
    UINT32 retVal = BSP_OK;
    UINT32 SpePowTime = 5120;
    UINT32 lastFrId = 0;
    UINT32 frId = 0;

    /*所有通道更新一次功率所用的总时间*/

    while(1)
    {
        /*所有通道更新一次功率所用的总时间，延时后将所有通道功率依次读出*/
        SpePowTime = BspGetDpdPowCalcTime();  /*工装需要修改延时 检测固定通道固定时间片*/
        if (1 == g_dbgisr)
        {
            BspSysMsDelay(SpePowTime);
            continue;
        }
        BspHalAdaptGetWirelessFrId(&frId);
        if (frId == lastFrId)
        {
            dbgInfoEx("[%s]: frId=%u not change, clean pow value\n", __FUNCTION__, frId);
            CleanDspPowshowValue();
            BspSysMsDelay(SpePowTime);
            continue;
        }
        memset_s(&sDspGetTxPowAvgVal,sizeof(T_TxAllChanPow),0,sizeof(T_TxAllChanPow));
        memset_s(&sDspSetTxPowAvgVal,sizeof(T_TxAllChanPow),0,sizeof(T_TxAllChanPow));
        
        BspFillDspPowInfo(&sDspSetTxPowAvgVal);
        BspSetPowInfoToDsp(&sDspSetTxPowAvgVal);
        
        BspSysMsDelay(SpePowTime);
        
        retVal = BspGetPowInfoFromDsp(&sDspGetTxPowAvgVal);
        if(retVal != BSP_OK)
        {
            BspSetDspPowAllInValid();
        }
        else
        {
            BspSetDspPowToAvgVal(&sDspGetTxPowAvgVal);
        }
    }
}
/*DSP功率检测任务初始化*/
UINT32 BspDpdPowCalcThreadInit(void)
{
    UINT32 ulRet = BSP_OK;
    static INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;

    if (lTaskID != ((INT32)BSP_ERROR))
    {
        return BSP_ERROR;
    }

    lTaskID = taskSpawn("BspDpdPowCalcThread", 100, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspDpdPowCalcThreadIsr, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgInfo("!!! Creat BspPowCalcThreadIsr Error !!!\n");
        dbgInfo("ulOptTaskRetVal = %x\n", lTaskID);
        dbgInfo("[1first]ulTaskStack = %d\n", ulTaskStack);
        ulRet = BSP_ERROR;
    }

    return ulRet;
}

static void BspInitChanTssiInfo(T_ChanRfCfgPara *pRfCfg, T_TssiPara *chanTssiPara)
{
    UINT32 carrIndex = 0;

    for (carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        chanTssiPara[carrIndex].radioMode = pRfCfg->para.carrInfo[carrIndex].radioMode;
        chanTssiPara[carrIndex].carrNo    = pRfCfg->para.carrInfo[carrIndex].carrNo;
    }
}

static void BspUpdateChanTssiPow(UINT32 bspChan, UINT32 chanCarrNum, T_TssiPara *chanTssiPara)
{
    UINT32 carrIndex = 0;

    for (carrIndex = 0; carrIndex < chanCarrNum; carrIndex++)
    {
        BspGetTssiPowInfoFromIc(bspChan, chanTssiPara[carrIndex].radioMode, chanTssiPara[carrIndex].carrNo,
            &(chanTssiPara[carrIndex].tssiDbm), &(chanTssiPara[carrIndex].tssiDbfs));
    }
}

static void CleanTssiValue(void)
{
    UINT32 chan = 0;
    UINT32 carr = 0;
    for(chan=0; chan<BSP_HALADAPT_IC_CHAN_MAX_NUM; chan++)
    {
        for(carr=0; carr<BSP_MAX_CARR_NUM; carr++)
        {
            s_TssiInfo[chan][carr].tssiDbfs = GET_POW_DBFS(0,TX_BIT_WIDTH);
            s_TssiInfo[chan][carr].tssiDbm = 0;
        }
    }
    return;
}

static void * BspTssiUpdateThread(void *para)
{
    T_ChanRfCfgPara *pRfCfg = NULL;
    UINT32 maxChan = BspGetTxChanNum();
    UINT32 SpePowTime = 2560;
    T_TssiPara chanTssiPara[BSP_MAX_CARR_NUM] = {0};
    UINT32 bspChan = 0;
    UINT32 lastFrId = 0;
    UINT32 frId = 0;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    maxChan = (maxChan > BSP_HALADAPT_IC_CHAN_MAX_NUM) ? BSP_HALADAPT_IC_CHAN_MAX_NUM : maxChan;
    while (1)
    {
        BspGetSpePowTimeCfg(&SpePowTime);
        BspSysMsDelay(SpePowTime);
        if (1 == g_dbgisr)
        {
            continue;
        }
        BspHalAdaptGetWirelessFrId(&frId);
        if (frId == lastFrId)
        {
            dbgInfoEx("[%s]: frId=%u not change, clean pow value\n", __FUNCTION__, frId);
            CleanTssiValue();
            continue;
        }
        dbgInfoEx("[%s]: frId=%u lastFrId=%u\n", __FUNCTION__, frId, lastFrId);
        lastFrId = frId;
        for (bspChan = 0; bspChan < maxChan; bspChan++)
        {
            /* fpga链路，d42链路无需关注此处 */
            if (NULL != pFpgaInfo && FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChan])
            {
                continue;
            }
            pRfCfg = GetRfCfgPara(bspChan, TX);
            if (pRfCfg == NULL)
            {
                continue;
            }
            if (pRfCfg->para.carrNum > BSP_MAX_CARR_NUM)
            {
                dbgInfoEx("%s: chan%u maxCarrNum is %d \n", __FUNCTION__, bspChan, pRfCfg->para.carrNum);
                continue;
            }
            memset_s(chanTssiPara, sizeof(chanTssiPara), 0, sizeof(chanTssiPara));
            BspInitChanTssiInfo(pRfCfg, chanTssiPara);
            BspUpdateChanTssiPow(bspChan, pRfCfg->para.carrNum, chanTssiPara);
            memcpy_s(s_TssiInfo[bspChan], sizeof(chanTssiPara), chanTssiPara, sizeof(chanTssiPara));
        }
    }

    return NULL;
}

UINT32 BspTssiUpdateThreadInit(void)
{
    int ret = 0;
    pthread_t th_id = 0;

    ret = pthread_create(&th_id, NULL, BspTssiUpdateThread, NULL);
    if (ret != 0)
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*IQ数据转dBFs接口：DPDIC4.0中HAL上报Funclib层直接是dBfs，不需要进行转换*/
UINT32 CalFwdRevDbfs(UINT32 bspChn, T_TxPow *ptAvgTxPow,T_TxPow *pPowDbfs)
{
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChn])
    {
        pPowDbfs->tFwdPow.fbPow = GET_POW_DBFS_FPGA(ptAvgTxPow->tFwdPow.fbPow, 16);
        pPowDbfs->tFwdPow.ifTssiPow = GET_POW_DBFS_FPGA(ptAvgTxPow->tFwdPow.ifTssiPow,16);
        pPowDbfs->tRevPow.fbPow = GET_POW_DBFS_FPGA(ptAvgTxPow->tRevPow.fbPow, 16);
        pPowDbfs->tRevPow.ifTssiPow = GET_POW_DBFS_FPGA(ptAvgTxPow->tRevPow.ifTssiPow,16);
        pPowDbfs->isPowValid = ptAvgTxPow->isPowValid;
    }
    else
    {
        pPowDbfs->tFwdPow.fbPow = GET_POW_DBFS(ptAvgTxPow->tFwdPow.fbPow,16);
        pPowDbfs->tFwdPow.ifTssiPow = GET_POW_DBFS(ptAvgTxPow->tFwdPow.ifTssiPow,14);
        pPowDbfs->tRevPow.fbPow = GET_POW_DBFS(ptAvgTxPow->tRevPow.fbPow,16);
        pPowDbfs->tRevPow.ifTssiPow = GET_POW_DBFS(ptAvgTxPow->tRevPow.ifTssiPow,14);
    }

    return BSP_OK;
}


UINT32 BspGetPaNamalForDbfs(UINT32 bspChn, T_TxPow *pPowDbfs)
{
    UINT32 loop = 0;
    UINT32 loopChn = 0;
    UINT32 updateCnt = 0;
    UINT32 powCalcWay = 0;
    UINT32 chnNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(pPowDbfs);
    INPUT_PARAM_RANGE_CHECK(bspChn, BSP_HALADAPT_IC_CHAN_MAX_NUM);
    powCalcWay = BspGetSpePowPowCalcWayByChan(bspChn);
    for (loop = 0; loop < 5; loop++)  /*最多循环5次看能否查找到*/
    {
        if((BspGetPaNormalFlag(bspChn) == PA_UNNORMAL) && (BspGetTddChanModeFlag(bspChn) == 1))
        {
            updateCnt = g_aulTxPowUpdateCnt[bspChn];
            if(powCalcWay == POW_CALC_WAY_DSP)
            {
                CopyFwdRevDbfs(&sDspTxPowAvgVal[bspChn], pPowDbfs);
            }
            else
            {
                CalFwdRevDbfs(bspChn, &sTxPowAvgVal[bspChn], pPowDbfs);
            }
            
            for(loopChn = 0; loopChn < chnNum; loopChn++)
            {
                if((BspGetPaOnUnNormalFlag(loopChn) == 1) && (BspGetTddChanModeFlag(loopChn) == 1) && (loopChn < BSP_HALADAPT_IC_CHAN_MAX_NUM))
                {
                    updateCnt = g_aulTxPowUpdateCnt[loopChn];
                    CalFwdRevDbfs(loopChn, &sTxPowAvgVal[loopChn], pPowDbfs);
                    bspChn = loopChn;
                    break;
                }
            }
        }
        else
        {
            updateCnt = g_aulTxPowUpdateCnt[bspChn];
            if(powCalcWay == POW_CALC_WAY_DSP)
            {
                CopyFwdRevDbfs(&sDspTxPowAvgVal[bspChn], pPowDbfs);
            }
            else
            {
                CalFwdRevDbfs(bspChn, &sTxPowAvgVal[bspChn], pPowDbfs);
            }
        }

        dbgInfoEx("%s ulUpdateCnt = %d, fwdTssi = %d, fwdFb = %d, revTssi = %d, revFb = %d \n",__FUNCTION__,\
                updateCnt,pPowDbfs->tFwdPow.ifTssiPow,pPowDbfs->tFwdPow.fbPow,pPowDbfs->tRevPow.ifTssiPow,\
        pPowDbfs->tRevPow.fbPow);

        if(updateCnt == g_aulTxPowUpdateCnt[bspChn]&&(1/*..data err*/))
        {
            break;
        }
    }

    if (loop >= 5)
    {
        pPowDbfs->isPowValid = 0x10; /*0x10是否为PowValid确认上报的值*/
        dbgInfo("%s:Tx%u Get PwrData Exceed : 5.4s\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspQcellPaOffFwdPowDeal()
 *  功能描述   : pa关闭时，qcell反馈功率的处理，powshow的反馈设置为 -3000（和刘志敬沟通）
 *             修改背景：QCELL EP214通道闭塞后网管显示pa平均发射功率为较大正值，异常。
 *             根因：QCELL EP214是txen和rxen关闭后，MTS会在上行有一个残留数据，
 *             反馈和上行共lane，且反馈16bit，上行12bit，反馈时间片时MTS的上行残留数
 *             据会被解析成一个非常大的值，导致反馈功率检测偏大。APP直接将该正值上报。
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   :
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
UINT32 BspQcellPaOffFwdPowDeal(INT32 *fwdPow, UINT32 bspChn)
{
    INT32 fwdGain = 0;
    INT32 deltaDbm = 0;
    UINT32 retVal = BSP_OK;
    UINT32 comptype = COMPS_BY_FREQ_POINT_TYPE;

    if ((NOT_QCELL_MODE != BspGetPbOrBbuMode()) && (SWITCH_OFF == BspGetPaSwitch(bspChn)))
    {
        retVal |= BspGetFwdDbmDelta(bspChn, &deltaDbm);
        retVal |= _BspGetFwdDbmGain(bspChn, &fwdGain, comptype);

        // -3000(powshow的反馈) = tPowDbfs.tFwdPow.fbPow - fwdGain + deltaDbm;
        *fwdPow = (-3000) + fwdGain - deltaDbm;
        dbgInfoEx("%s:fwdPow:%d fwdGain:%d deltaDbm:%d \n",__FUNCTION__, *fwdPow,fwdGain,deltaDbm);
    }
    return retVal;
}

UINT32 GetTssiPowDbfs(UINT32 bspChn, UINT32 ulBand, ePowType powType, T_TxPow *pPowDbfs)
{
    UINT32 ret = BSP_OK;
    if (bspChn >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }

    INPUT_POINTER_CHECK(pPowDbfs);

    if(BSP_TSSI_FWD_INFO == powType)
    {
        ret = BspGetPaNamalForDbfs(bspChn, pPowDbfs);
        BspQcellPaOffFwdPowDeal(&(pPowDbfs->tFwdPow.fbPow), bspChn);/* 只有QCELL才走这个分支 */
    }

    #if 0
    else if(BSP_PC_TSSI_FWD_INFO == powType)
    {
        for (ulLoop = 0; ulLoop < 5; ulLoop++)
        {
            ulUpdateCnt = g_aulTxPcPowUpdateCnt[bspChn];
            CalFwdRevDbfs(bspChn, &sTxReportPcPowVal[bspChn], pPowDbfs);
            if(ulUpdateCnt == g_aulTxPcPowUpdateCnt[bspChn]&&(1/*..data err*/))
            {
                break;
            }
        }
    }
    #endif

    return ret;
}

UINT32 GetVswrPowDbfs(UINT32 bspChn,UINT32 ulBand,T_TxPow *pPowDbfs)
{
    UINT32 ulLoop = 0;
    UINT32 ulUpdateCnt = 0;

    INPUT_POINTER_CHECK(pPowDbfs);

    for (ulLoop = 0; ulLoop < 5; ulLoop++)
    {
        ulUpdateCnt = g_ulVswrUpdateCnt[bspChn];
        CalFwdRevDbfs(bspChn, &sVswrAvgVal[bspChn], pPowDbfs);
        if(ulUpdateCnt == g_ulVswrUpdateCnt[bspChn]&&(1/*..data err*/))
        {
            break;
        }
    }
    if (ulLoop >= 5)
    {
        dbgInfo("%s:Tx%d Get VswrData Exceed : 5.4s\n",__FUNCTION__, bspChn);
    }

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetTssiFlag(*)
 *  功能描述   : 获取TssiFlag
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : bspChn - 通道号，从0开始定义
 *  输出参数   :
 *  返 回 值   : 天馈口合载功率值，0.01dBm为单位
 *  其它说明   : 外部接口
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 李凯   @2012-08-31 15:42:06, 创建
 *  $0000000(N/A), 刘志敬 @2012-08-31 15:42:07, 更新
 *----------------------------------------------------------------------------
 *****************************************************************************/
UINT32 BspGetTssiFlag(UINT32 bspChn, UINT32 ulBand, UINT32 *pFlag)
{
    UINT32 isPowValid = 0;
    UINT32 retVal = 0;
    T_TxPow tPowDbfs = {0};
    ePowType powType = BSP_TSSI_FWD_INFO;

    INPUT_POINTER_CHECK(pFlag);

    retVal = GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    if(BSP_ERROR == retVal)
    {
        dbgErr("%s GetTssiPowDbfs failed\n",__FUNCTION__);
        return retVal;
    }
    isPowValid = tPowDbfs.isPowValid;
    if(pFlag!=NULL)
    {
        *pFlag = isPowValid;
    }

    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : BspGetVswrTssiTcpw(*)
 *  功能描述   : 获取Tx通道中频数字,前向模拟俩同步功率(0.01dbm)
 *  读全局变量 :
 *  写全局变量 : 无
 *  输入参数   : ulTxChan - 通道号，从0开始定义
 *  输出参数   : ptDualPow  - 中频数字,前向模拟俩功率结构指针
 *  返 回 值   : BSP_OK成功，其他值失败
 *  其它说明   : 返回失败时，或功率为无效值时，高层软件忽略此功率。
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  刘志敬@2012-08-23 16:24:07, 创建
 *  $0000000(N/A),  李凯@2012-08-23 16:24:07, 更新
 *----------------------------------------------------------------------------
 *****************************************************************************/
UINT32 BspGetVswrTssiTcpw(UINT32 bspChn,UINT32 ulBand,T_TxDualPow *fwd, T_TxDualPow *rev, UINT32 *num)
{
    UINT32 retVal = 0;
    T_TxPow tVswrDbfs={0};
    INT32   fwdGain = 0;
    INT32   revGain = 0;
    INT32   txGain = 0;
    INT32 deltaDbm = 0;
    UINT32 comptype = COMPS_BY_FREQ_POINT_TYPE;

    if ((NULL == fwd)|| (NULL == rev))
    {
        dbgInfo("Para Error : ulChannel = %d, or ptDualPow = NULL\n", bspChn);
        return BSP_ERROR_INVALID_PARA;
    }
    GetVswrPowDbfs(bspChn,ulBand,&tVswrDbfs);

    dbgInfoEx("\n[%s] tVswrDbfs.tFwdPow.ifTssiPow = %d,tVswrDbfs.tFwdPow.fbPow  =%d\n",__FUNCTION__,tVswrDbfs.tFwdPow.ifTssiPow ,tVswrDbfs.tFwdPow.fbPow  );
    dbgInfoEx("\n[%s] tVswrDbfs.tRevPow.ifTssiPow = %d,tVswrDbfs.tRevPow.fbPow  =%d\n",__FUNCTION__,tVswrDbfs.tRevPow.ifTssiPow ,tVswrDbfs.tRevPow.fbPow  );

    _BspGetFwdDbmGain(bspChn, &fwdGain, comptype);
    _BspGetRevDbmGain(bspChn, &revGain, comptype);
    _BspGetIfTssiDbmGain(bspChn, &txGain, comptype);
    retVal |= BspGetFwdDbmDelta(bspChn, &deltaDbm);

    dbgInfoEx("\n txGain = %d, fwdGain = %d, revGain = %d, deltaDbm = %d\n", txGain ,fwdGain ,revGain, deltaDbm);
    fwd->ifTssiPow = tVswrDbfs.tFwdPow.ifTssiPow + txGain ;
    fwd->fbPow = tVswrDbfs.tFwdPow.fbPow - fwdGain + deltaDbm;

    rev->ifTssiPow = tVswrDbfs.tRevPow.ifTssiPow + txGain;
    rev->fbPow =  tVswrDbfs.tRevPow.fbPow - revGain + deltaDbm;

    return retVal;
}
#if 0
UINT32 BspSetAcVswrEnable(UINT32 val)
{
    s_AcVswrEnable = val;
    return BSP_OK;
}

UINT32 BspGetAcVswrEnable()
{
    return s_AcVswrEnable;
}
#endif
/*当前功率计算的驻波值*/
UINT32 BspGetScalarVswrTemp(UINT32 bspChn, UINT32 ulband, UINT32 *pVswrVal)
{
    UINT32 retVal = BSP_OK;
    UINT32 RandData = 0;
    T_TxDualPow fwd={0}, rev={0};
    INT32  vswrCoef =0;
    DOUBLE gama = 0.0;
    UINT32 num = BSP_HALADAPT_IC_CHAN_MAX_NUM;
    UINT32 portId = 0;
    UINT32 portType = 0;

    INPUT_POINTER_CHECK(pVswrVal);
    POW_TXCHAN_CHECK(bspChn);
    BspGetPortIdByBspChn(bspChn, TX, &portId);
    BspGetSlavePortCfgTpye(portId, &portType);

    if(1 == portType)  /*拉远的通道特殊处理*/
    {
         *pVswrVal = g_ulSlaveScalarVswr[bspChn];  /*子端通道特殊处理 无法在线检测 只能使用上电初始化时计算的值*/
         return  BSP_OK;
    }
    if(BspGetPaNormalFlag(bspChn) == PA_UNNORMAL)
    {
        if(BspGetPaSwitch(bspChn) == SWITCH_OFF)
        {
            *pVswrVal = BSP_INVALID_VALUE;
        }
        else
        {
            (void)BspGetRandomData(1,&RandData);
            *pVswrVal = 1220000 + RandData%40001 - 20000;
        }
        return BSP_OK;
    }

    if(pFuncGetBoardScalarVswr)
    {
        return pFuncGetBoardScalarVswr(bspChn,pVswrVal);
    }

    retVal = BspGetVswrTssiTcpw(bspChn,ulband, &fwd, &rev, &num);

    if (retVal != BSP_OK)
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return BSP_ERROR;
    }

    if ((fwd.fbPow <= 0 && rev.fbPow <= 0) && (NOT_QCELL_MODE == BspGetPbOrBbuMode()))/* qcell机型不走这里 */
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return BSP_OK;
    }
    if((fwd.ifTssiPow < BspGetVswrThreshhold(bspChn,TSSI0_THRESHOLD))||
           (fwd.fbPow< BspGetVswrThreshhold(bspChn,FWD_THRESHOLD))||
           (rev.ifTssiPow < BspGetVswrThreshhold(bspChn,TSSI1_THRESHOLD)))
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return BSP_ERROR;
    }
    vswrCoef = rev.fbPow - rev.ifTssiPow + fwd.ifTssiPow - fwd.fbPow;
    dbgInfoEx("\n[%s] rev.fbPow = %d, rev.ifTssiPow =%d\n",__FUNCTION__,rev.fbPow,rev.ifTssiPow);
    dbgInfoEx("\n[%s] fwd.fbPow = %d, fwd.ifTssiPow =%d\n",__FUNCTION__,fwd.fbPow,fwd.ifTssiPow);
    dbgInfoEx("\n[%s] vswrCoef = %d\n",__FUNCTION__,vswrCoef);
    if (vswrCoef >= 0)
    {
        *pVswrVal = VSWR_ANORMAL_H_VAL;
        return BSP_OK;
    }

    gama = pow(10.0, (DOUBLE)vswrCoef/2000.0);
    *pVswrVal = VSWR_UINT * (1 + gama) / (1 - gama);
    
    if(*pVswrVal > VSWR_ANORMAL_H_VAL)
    {
        *pVswrVal = VSWR_ANORMAL_H_VAL;
    }
    if(*pVswrVal < VSWR_ANORMAL_L_VAL)
    {
        *pVswrVal = VSWR_ANORMAL_L_VAL;
    }
    return BSP_OK;
}

/* Started by AICoder, pid:q302di511eqbc8914b4d0b46d0e4201b44291e61 */
/*TDD获取驻波值APP接口*/
UINT32 BspGetScalarVswr(UINT32 bspChn, UINT32 *pVswrVal)
{
    UINT32 ret = BSP_OK;
    UINT32 vswrVal = BSP_INVALID_VALUE;
    UINT32 bandNum = 0;

    INPUT_POINTER_CHECK(pVswrVal);
    POW_IC_MAX_CHAN_CHECK(bspChn);
    
    /* 如果是QCELL机型且功放关闭的情况下，不计算驻波 */
    if((NOT_QCELL_MODE != BspGetPbOrBbuMode()) && (SWITCH_OFF == BspGetPaSwitch(bspChn)))
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return ret;
    }
    /* Started by AICoder, pid:500bd9512du4bab1485109460092841d50908189 */
    // if((IS_NCR == BspIsNcr()) && (4 > bspChn))
    if(IS_NCR == BspIsNcr())
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return BSP_OK;
    }

    bandNum = BspGetBandNumByBspChn(bspChn, TX);
    if((BspGetBandVswrFlag() == BAND_VSWR_SUPPORT) && (bandNum > 1))  /*支持频段级矢量驻波检测的机型，单频段通道支持标量驻波检测，多频段不支持*/
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return ret;
    }
  
    ret = BspGetScalarVswrTemp(bspChn,0,&vswrVal);
    /* Ended by AICoder, pid:500bd9512du4bab1485109460092841d50908189 */
    *pVswrVal = vswrVal;

    return ret;
}
/* Ended by AICoder, pid:q302di511eqbc8914b4d0b46d0e4201b44291e61 */

UINT32 BspCalVswr(UINT32 bspChn,UINT32 ulBand,UINT32 *pulVswrValue)
{
    UINT32 ret = BSP_OK;
    UINT32 vswrVal = BSP_INVALID_VALUE;
    UINT32 bandNum = 0;

    INPUT_POINTER_CHECK(pulVswrValue);
    POW_IC_MAX_CHAN_CHECK(bspChn);

    /* 如果是QCELL机型且功放关闭的情况下，不计算驻波 */
    if((NOT_QCELL_MODE != BspGetPbOrBbuMode()) && (SWITCH_OFF == BspGetPaSwitch(bspChn)))
    {
        *pulVswrValue = BSP_INVALID_VALUE;
        return ret;
    }

    bandNum = BspGetBandNumByBspChn(bspChn, TX);
    if((BspGetBandVswrFlag() == BAND_VSWR_SUPPORT) && (bandNum > 1))  /*支持频段级矢量驻波检测的机型，单频段通道支持标量驻波检测，多频段不支持*/
    {
        *pulVswrValue = BSP_INVALID_VALUE;
        return ret;
    }

    ret = BspGetScalarVswrTemp(bspChn,ulBand,&vswrVal);
    *pulVswrValue = vswrVal;

    return ret;
}

UINT32 BspGetChannelRealVswrCheckFreq(UINT32 chn, UINT32 *freq)
{
    UINT32 ret = BSP_OK;
    UINT32 VswrCheckFreq = 0;

    INPUT_POINTER_CHECK(freq);
    if(NULL != pGetVectorVswrFreq)
    {
        ret = pGetVectorVswrFreq(chn, &VswrCheckFreq);
    }
    *freq = VswrCheckFreq;
    dbgInfoEx("%s Chn:%d VswrCheckFreq:%d\n", __FUNCTION__, chn, *freq);

    return ret;
}

/*FDD机型获取驻波值APP接口*/
UINT32 BspGetPaVswrVal( UINT32 ulChan,UINT32 ulFreqBand, UINT32 ulPaOrAntenaMode)
{
    UINT32 ulVswrValue = BSP_INVALID_VALUE;

    if(PA_VSWR_MODE == ulPaOrAntenaMode)
    {
        BspCalVswr(ulChan,ulFreqBand,&ulVswrValue);
    }
    else if(ANTENNA_VSWR_MODE == ulPaOrAntenaMode)
    {
        if(NULL != pGetVectorVswrVal)
        {
            pGetVectorVswrVal(ulChan,ulFreqBand,&ulVswrValue);
        }
    }
     else if(OFFLINE_VSWR_MODE == ulPaOrAntenaMode)
    {
        if((NULL != pGetVectorVswrVal) && (NULL != pSetVswrMode))
        {
            pSetVswrMode(OFFLINE_VSWR_MODE); /* 设置离线驻波位置检测模式 */
            pGetVectorVswrVal(ulChan,ulFreqBand,&ulVswrValue);
            pSetVswrMode(PA_VSWR_MODE); /* 设置离线驻波位置检测模式 */
            dbgInfoEx("%s, chan:%u restore vswrmode:%u!\n",__FUNCTION__, ulChan, PA_VSWR_MODE);
        }
    }
    else
    {
        dbgErr("Vswr Mode Error, ulPaOrAntenaMode = %d\n", ulPaOrAntenaMode);
        return BSP_ERROR;
    }
    dbgInfoEx("chan=%d band=%d antmode=%d vswr=%f ticks=%d\n",
        ulChan, ulFreqBand, ulPaOrAntenaMode, ulVswrValue/1000000.0, tickGet());
    return ulVswrValue;

}

static UINT32 getvswr(UINT32 bspChn)
{
    UINT32 vswrVal = 0;
    UINT32 ret = 0;
    ret = BspGetScalarVswr(bspChn, &vswrVal);
    printf("Chan'%d: %d(0x%X)\n", bspChn, vswrVal, vswrVal);
    return ret;
}

UINT32 ReadBbTssiPow(UINT32 bspChn,UINT32 bspCarrNo,UINT32 carrMode,INT32 *pTssiPow)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 difChn = 0;
    UINT32 uChipId = 0;

    if(bspChn >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        dbgErr("[%s] input para is out of range!\n",__func__);
        return BSP_ERROR;
    }

    if (BspGetDifInfoByBspChn(bspChn,TX,&uChipId,&difChn) != BSP_OK)
    {
        return BSP_ERROR;
    }

    retVal = BspHalAdaptReadBbTssiPow(difChn, bspCarrNo, carrMode, pTssiPow);

    return retVal;
}

VOID BspXTssiPowInfoFromIcX(UINT32 x)
{
    s_powprn = x;
}


UINT32 BspGetPaOnUnNormalFlag(UINT32 dlchan)
{
    UINT32 paOnUnnormalFlag = 0;

    if((BspGetPaNormalFlag(dlchan) == PA_NORMAL) && (BspGetPaSwitch(dlchan) == SWITCH_ON))
    {
        paOnUnnormalFlag = 1;   /*通道如果是非降秩通道并且功放打开的置1为标志*/
    }

    return paOnUnnormalFlag;
}


UINT32 BspGetTddChanModeFlag(UINT32 dlchan)
{
    UINT32 carr = 0;
    UINT32 carrIndex = 0;
    UINT32 carrMode = 0;
    UINT32 carrRadioFlag = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;
    pRfCfg = GetRfCfgPara(dlchan, TX);
    if (NULL == pRfCfg)
    {
        dbgErr("[%s]bspChn'%u pRfCfg Get Error!\n",__FUNCTION__, dlchan);
        return BSP_ERROR;
    }
    if (pRfCfg->para.carrNum > BSP_MAX_CARR_NUM)
    {
        dbgErr("[%s]carrNum is %u \n",__FUNCTION__,pRfCfg->para.carrNum);
        return BSP_ERROR;
    }

    for(carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
    {
        carrMode = pRfCfg->para.carrInfo[carrIndex].radioMode;
        if((BSP_RADIO_STANDARD_LTE_TDD == carrMode) || (BSP_RADIO_STANDARD_5G == carrMode))
        {
            dbgInfoEx("%s, chan:%u carrNum:%u radio:%u!\n",__FUNCTION__, dlchan, carr, carrMode);
            carrRadioFlag = 1;
            return carrRadioFlag;   /*1只是判断当前通道是否有TDD LTE NR 载波的标志*/
        }
    }

    return carrRadioFlag;
}

static UINT32 BspGetPaNormalInfo(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, T_PaNormalInfo *paNormalInfo)
{
    UINT32 loopChn = 0;
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    INPUT_PARAM_RANGE_CHECK(bspChn, BSP_HALADAPT_IC_CHAN_MAX_NUM);
    UINT32 chnNum = BspGetTxChannel();
    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipId, &difChan);
    retVal |= BspHalAdaptGetDlpreGain(difChan, bspCarrNo, carrMode, &paNormalInfo->dlPreDgain);

    if((BspGetPaNormalFlag(bspChn) == PA_UNNORMAL) && ((BSP_RADIO_STANDARD_LTE_TDD == carrMode) || (BSP_RADIO_STANDARD_5G == carrMode)))
    {
        retVal = ReadBbTssiPow(bspChn, bspCarrNo, carrMode, &paNormalInfo->tssiPowAvg);
        retVal |= BspHalAdaptGetDlbankDgain(difChan, bspCarrNo, carrMode, &paNormalInfo->dlBankDgain);

        for(loopChn = 0; loopChn < chnNum; loopChn++)
        {
            if((BspGetPaOnUnNormalFlag(loopChn) == 1) && (BspGetTddChanModeFlag(loopChn) == 1) && (loopChn < BSP_HALADAPT_IC_CHAN_MAX_NUM))
            {
                retVal |= ReadBbTssiPow(loopChn, bspCarrNo, carrMode, &paNormalInfo->tssiPowAvg);
                retVal |= BspGetDifInfoByBspChn(loopChn, TX, &chipId, &difChan);
                retVal |= BspHalAdaptGetDlbankDgain(difChan, bspCarrNo, carrMode, &paNormalInfo->dlBankDgain);
                break;
            }
        }
     }
    else
    {
       retVal |= ReadBbTssiPow(bspChn, bspCarrNo, carrMode, &paNormalInfo->tssiPowAvg);
       retVal |= BspHalAdaptGetDlbankDgain(difChan, bspCarrNo, carrMode, &paNormalInfo->dlBankDgain);
    }
    return retVal;
}

static UINT32 BspSetQcellInvalidPowValue(INT32 *pTssiDbfs,INT32 *pTssiDbm)
{
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pTssiDbm);
    INPUT_POINTER_CHECK(pTssiDbfs);
    
    if(NOT_QCELL_MODE != BspGetPbOrBbuMode())
    {
        *pTssiDbfs = -9030;
        *pTssiDbm =  -4970;
    }

    return retVal;
}

INT32 g_targetGainDelta[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};

UINT32 BspSetTargetGainDelta(UINT32 chan, INT32 delta)
{
    if(chan >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        dbgErr("chan over index\n");
        return BSP_ERROR;
    }
    g_targetGainDelta[chan] = delta;

    return BSP_OK;
}
UINT32 BspGetTargetGainDelta(UINT32 chan, INT32 *delta)
{
    if(chan >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        dbgErr("chan over index\n");
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(delta);

    *delta = g_targetGainDelta[chan];

    return BSP_OK;
}

UINT32 BspGetTssiPowInfoFromIc(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs)
{
    UINT32 retVal = BSP_OK;
    INT32  txBBGain = 0;
    INT32  tssiDbm = 0;
    INT32  tssiDbfs = 0;
    UINT32 difChan = 0;
    UINT32 chipId = 0;
    INT32 sw = 0;
    UINT32 errFlag = 0;
    INT32 minDbfs = MIN_DBFS;
    INT32  targetGainDelta = 0;
    T_PaNormalInfo paNormalInfo = {0};

    INPUT_PARAM_RANGE_CHECK(bspChn, BSP_HALADAPT_IC_CHAN_MAX_NUM);
    INPUT_POINTER_CHECK(pTssiDbm);
    INPUT_POINTER_CHECK(pTssiDbfs);

    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgInfoEx("%s:difChan is %d,radioMode is %#x,carrNo is %d\n",__FUNCTION__,difChan,carrMode,bspCarrNo);
        return BSP_ERROR;
    }
    retVal = BspHalAdaptGetDtssiErrorFlag(difChan, bspCarrNo, carrMode, &errFlag);
    if (retVal == BSP_OK && errFlag == DIF_HAL_ENABLE)
    {

        dbgInfoEx("%s:difChan is %d,radioMode is %#x,carrNo is %d, errFlag is %u\n",__FUNCTION__,difChan,carrMode,bspCarrNo, errFlag);
        BspLog(LOG_LEVEL_4, "%s:ERROR difChan is %d,radioMode is %#x,carrNo is %d, errFlag is %u\n",\
                    __FUNCTION__,difChan,carrMode,bspCarrNo, errFlag);
        BspHalAdaptDtssiErrorClr(difChan, bspCarrNo, carrMode);
        *pTssiDbm = 0;
        *pTssiDbfs = GET_POW_DBFS(0,TX_BIT_WIDTH);
        BspSetQcellInvalidPowValue(pTssiDbfs, pTssiDbm);/* 纯粹为了过门限 */
        
        return BSP_OK;
    }

    retVal |= BspGetPaNormalInfo(bspChn,carrMode,bspCarrNo,&paNormalInfo) ;
    tssiDbfs = paNormalInfo.tssiPowAvg;
    if(paNormalInfo.dlBankDgain == GAIN_INVALID) /*GAIN_INVALID*/
    {
        tssiDbfs = GET_POW_DBFS(0,TX_BIT_WIDTH);
    }
    else
    {
        tssiDbfs = tssiDbfs + paNormalInfo.dlBankDgain;
    }
    /*todo 待确认增益节点和开关位置*/
    retVal |= BspHalAdaptGetDlCarrGainSw(difChan, carrMode, bspCarrNo, &sw);
    if (0 == sw)
    {
        tssiDbfs = GET_POW_DBFS(0,TX_BIT_WIDTH);
        BspLog(LOG_LEVEL_4, "[%s]chan:%d carr:%d mode:%d tssiPowAvg:%d,sw:%d,dlPreDgain:%d,dlBankDgain:%d,tssiDbfs:%d,retVal:%d\n",
                __FUNCTION__, difChan,bspCarrNo,carrMode,paNormalInfo.tssiPowAvg,sw,paNormalInfo.dlPreDgain,paNormalInfo.dlBankDgain,tssiDbfs,retVal);
    }
    retVal |= BspGetTxCarrTargetGain(bspChn, &txBBGain);
    if((BSP_OK == BspGetTargetGainDelta(bspChn,&targetGainDelta))&&(0 != targetGainDelta))
    {
        txBBGain = txBBGain - targetGainDelta;
    }

    tssiDbm = (tssiDbfs <= minDbfs)?0:(tssiDbfs + txBBGain);
    if(_GetTssiPowInfoFromIcCntX)
    {
        BspLog(LOG_LEVEL_4, "%s LINE %d:%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d\n", __func__,\
        __LINE__,difChan,carrMode,bspCarrNo, errFlag, paNormalInfo.tssiPowAvg, paNormalInfo.dlPreDgain, paNormalInfo.dlBankDgain, sw, txBBGain, tssiDbfs, tssiDbm,retVal);
    }

    if( (NOT_QCELL_MODE != BspGetPbOrBbuMode()) && ((0 == sw) || (paNormalInfo.dlBankDgain == GAIN_INVALID) || (tssiDbfs <= minDbfs)))
    {
        tssiDbfs = -9030;
        tssiDbm =  -4970;
    }

    dbgInfoEx("[%s]chan:%d carr:%d radio:%d tssiPowAvg:%d,sw:%d,txBBGain:%d,dlPreDgain:%d,dlBankDgain:%d,tssiDbfs:%d,tssiDbm:%d,retVal:%d\n",
            __FUNCTION__, bspChn,bspCarrNo,carrMode,paNormalInfo.tssiPowAvg,sw,txBBGain,paNormalInfo.dlPreDgain,paNormalInfo.dlBankDgain,tssiDbfs,tssiDbm,retVal);
    *pTssiDbfs = tssiDbfs;
    *pTssiDbm = tssiDbm;

    return retVal;
}
/* Started by AICoder, pid:nd54dk8f11z0db514dbf0bafe01ad60c5c38c0a5 */
UINT32 HandleTssiBelow0dbm(UINT32 bspChn, INT32 *pTssiDbm, INT32 *pTssiDbfs)
{
    INPUT_POINTER_CHECK(pTssiDbm);
    INPUT_POINTER_CHECK(pTssiDbfs);

    if(1 == BspGetPowerBelow0dbm())
    {
        if((*pTssiDbm < BspGetPowThreshhold(bspChn, TSSI0_THRESHOLD))||(*pTssiDbfs < MIN_DBFS))
        {
            *pTssiDbm = -15000;
        }

    }
    else
    {
        if (*pTssiDbm < BspGetPowThreshhold(bspChn, TSSI0_THRESHOLD))
        {
            *pTssiDbm = 0;
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:nd54dk8f11z0db514dbf0bafe01ad60c5c38c0a5 */

UINT32 BspSetTssiValue(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 tssiDbm, INT32 tssiDbfs)
{
    POW_TXCHAN_CHECK(bspChn);
    if(bspCarrNo >= BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }
    s_TssiInfo[bspChn][bspCarrNo].radioMode = carrMode;
    s_TssiInfo[bspChn][bspCarrNo].carrNo = bspCarrNo;
    s_TssiInfo[bspChn][bspCarrNo].tssiDbfs = tssiDbfs;
    s_TssiInfo[bspChn][bspCarrNo].tssiDbm = tssiDbm;

    return BSP_OK;
}

static UINT32 BspGetTssiPowInfoD42(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs)
{
    UINT32 carrIdx = 0;
    UINT32 loopChn = 0;
    INT32  gain = 0;
    UINT32 chnNum = BspGetTxChannel();
    POW_TXCHAN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pTssiDbm);
    INPUT_POINTER_CHECK(pTssiDbfs);

    if(bspChn >= BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        return BSP_ERROR;
    }
    for (carrIdx = 0; carrIdx < BSP_MAX_CARR_NUM; carrIdx++)
    {
        if (s_TssiInfo[bspChn][carrIdx].radioMode == carrMode &&
            s_TssiInfo[bspChn][carrIdx].carrNo == bspCarrNo)
        {
            break;
        }
    }

    if(carrIdx == BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }
    (void)BspGetCarrBalanceGain(bspChn, bspCarrNo, &gain);
    if((BspGetPaNormalFlag(bspChn) == PA_UNNORMAL) && ((BSP_RADIO_STANDARD_LTE_TDD == carrMode) || (BSP_RADIO_STANDARD_5G == carrMode)))
    {
       *pTssiDbfs = s_TssiInfo[bspChn][carrIdx].tssiDbfs - gain;
       *pTssiDbm = s_TssiInfo[bspChn][carrIdx].tssiDbm - gain;

        for(loopChn = 0; loopChn < chnNum; loopChn++)
        {
            if((BspGetPaOnUnNormalFlag(loopChn) == 1) && (BspGetTddChanModeFlag(loopChn) == 1) && (loopChn < BSP_HALADAPT_IC_CHAN_MAX_NUM))
            {
                *pTssiDbfs = s_TssiInfo[loopChn][carrIdx].tssiDbfs - gain;
                *pTssiDbm = s_TssiInfo[loopChn][carrIdx].tssiDbm - gain;
                 break;
            }
        }
    }
    else
    {
        *pTssiDbfs = s_TssiInfo[bspChn][carrIdx].tssiDbfs - gain;
        *pTssiDbm = s_TssiInfo[bspChn][carrIdx].tssiDbm - gain;
    }

    (void)HandleTssiBelow0dbm(bspChn, pTssiDbm, pTssiDbfs);

    return BSP_OK;
}

UINT32 BspGetTssiPowInfo(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs)
{
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();
    POW_TXCHAN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pTssiDbm);
    INPUT_POINTER_CHECK(pTssiDbfs);

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && BSP_RADIO_STANDARD_AIOT == carrMode && NULL != pFpgaInfo->pFuncGetFpgaTssiPowInfo)
    {
        return pFpgaInfo->pFuncGetFpgaTssiPowInfo(bspChn, carrMode, bspCarrNo, pTssiDbm, pTssiDbfs);
    }
    else
    {
        return BspGetTssiPowInfoD42(bspChn, carrMode, bspCarrNo, pTssiDbm, pTssiDbfs);
    }

}

#if 0

UINT32 BspSetRssiCarrDlyByType(UINT32 chipId,UINT32 bspChan,UINT32 radioMod,UINT32 bandWidth, UINT32 rssiType,UINT32 carrDly,T_BspAdaptOneChanCarrInfo *pDifCarrInfo)
{
    return BSP_OK;
}

UINT32 BspSetRssiCarrDly(UINT32 difChan, UINT32 radioMod, UINT32 carrNo, UINT32 rssiType)
{
    return BSP_OK;
}
#endif
static UINT32 ReadBbRssiPow(UINT32 bspChn,UINT32 bspCarrNo,UINT32 slotId ,UINT32 carrMode,UINT32 rssiType,INT32 *pRssiPow)
{
    UINT32 retVal = BSP_OK;
    UINT32 difChn = 0;
    UINT32 uChipId = 0;

    retVal = BspGetDifInfoByBspChn(bspChn, RX, &uChipId, &difChn);
    if(BSP_OK != retVal)
    {
        dbgInfoEx("%s bspChn=%d\n",__FUNCTION__,bspChn);
        return retVal;
    }

    retVal |= BspHalAdaptReadRssiPowValue(difChn, bspCarrNo, carrMode, slotId, rssiType, pRssiPow);

    return retVal;
}

/*DPDIC4.0获取VGA增益HAL接口改动*/
UINT32 BspGetVgaCompCarrFacx(UINT32 bspChn,UINT32 bspCarrNo ,UINT32 carrMode,INT32 *preAtt)
{
    UINT32 chipId = 0;
    UINT32 difChn = 0;
    INT32  vgaUlbankfacx = 0;
    INT32  vgaUlpostfacx = 0;

    *preAtt = 0;

    if(BspGetDifInfoByBspChn(bspChn,RX,&chipId,&difChn) != BSP_OK)
    {
        dbgInfoEx("%s bspChn=%d\n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    /*UlBank VGA*/
    BspHalAdaptGetRxPcGain(difChn, carrMode, bspCarrNo, &vgaUlbankfacx);
    /*UlPost VGA*/
    BspHalAdaptGetRxVgaGain(difChn, carrMode, bspCarrNo, &vgaUlpostfacx);

    *preAtt = vgaUlbankfacx + vgaUlpostfacx;  //0.01db
    if (NULL != pGetAnaAttFromFpgaFunc)
    {
        *preAtt -= (pGetAnaAttFromFpgaFunc(bspChn) * 100);
    }

    dbgInfoEx("bspChn=%d bspCarrNo=%d carrMode=%d vgaUlbankfacx=%d preAtt=%d,vgaUlpostfacx=%d\n",\
        bspChn,bspCarrNo,carrMode,vgaUlbankfacx,*preAtt,vgaUlpostfacx);

    return BSP_OK;
}

UINT32 BspCarrInfoMatching(UINT32 carrNo, UINT32 carrMode, T_ChanRfCfgPara *rfCfgInfo, UINT32 *carrId)
{
    UINT32 loopId = 0;
    UINT32 rxcarrNum = 0;

    INPUT_POINTER_CHECK(rfCfgInfo);
    INPUT_POINTER_CHECK(carrId);

    if(rfCfgInfo->para.carrNum > BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }
    rxcarrNum = rfCfgInfo->para.carrNum;

    for(loopId = 0; loopId < rxcarrNum; loopId++)
    {
        if(carrMode != rfCfgInfo->para.carrInfo[loopId].radioMode)
        {
            continue;
        }
        if (carrNo != rfCfgInfo->para.carrInfo[loopId].carrNo)
        {
            continue;
        }
        break;
    }

    if(rxcarrNum == loopId)
    {
        dbgInfoEx("[%s]carrNo = %d,carrMode = %d,rxcarrNum = %d,No find CarrNoInfo\n", __FUNCTION__, carrNo, carrMode, rxcarrNum);
        return BSP_ERROR;
    }
    *carrId = loopId;

    return BSP_OK;
}

UINT32 BspGetTwoSegAssociateVirtualCarr(UINT32 bspChn, UINT32 carrNo, UINT32 carrMode, UINT32 *virtualCarrNo)
{
    UINT32 ret = 0;
    UINT32 vCarrNo = 0;
    UINT32 vCarrBw = 0;
    UINT32 CarrBw = 0;
    UINT32 offset = 0;
    UINT32 mod = 0;
    UINT32 carrIdx = 0;
    UINT32 vcarrIdx = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    INPUT_POINTER_CHECK(virtualCarrNo);

    pRfCfg = GetRfCfgPara(bspChn, RX);
    if(NULL == pRfCfg)
    {
        dbgInfoEx("[%s]bspChn'%d pRfCfg Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    BspGetVirtualCarrNoOffsetPara(&offset, &mod);
    if(0 == offset || 0 == mod || 1 == mod)
    {
        dbgInfoEx("[%s] Error, The offset or mod is incorrect!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    vCarrNo = (carrNo + offset) % mod;
    if(vCarrNo == carrNo)
    {
        dbgInfoEx("[%s],The primary carrier number is the same as the virtual carrier.\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ret = BspCarrInfoMatching(carrNo, carrMode, pRfCfg, &carrIdx);
    ret |= BspCarrInfoMatching(vCarrNo, carrMode, pRfCfg, &vcarrIdx);
    if(BSP_OK != ret)
    {
        dbgInfoEx("[%s] carrIdx = %d, vcarrIdx = %d,No find CarrNoMatchInfo\n", __FUNCTION__, carrIdx, vcarrIdx);
        return BSP_ERROR;
    }

    CarrBw = pRfCfg->para.carrInfo[carrIdx].bandWidth;
    vCarrBw = pRfCfg->para.carrInfo[vcarrIdx].bandWidth;

    ret = BspCarrBwIsTwoSegAntiInterf(carrMode, CarrBw);
    ret |= BspCarrBwIsTwoSegAntiInterf(carrMode, vCarrBw);
    if(BSP_OK != ret)
    {
        dbgInfoEx("[%s] CarrBw = %d, vCarrBw = %d\n, CarrRxBw is not matching", __FUNCTION__, CarrBw, vCarrBw);
        return BSP_ERROR;
    }

    *virtualCarrNo = pRfCfg->para.carrInfo[vcarrIdx].carrNo;

    return BSP_OK;
}

#define   RSSI_NO_POWER_DBFS      ((INT32)(-9031))
#define   RSSI_NO_POWER_DBM      ((INT32)(-12000))
/* Started by AICoder, pid:12ef91aa25304401bc75bf5d141939fb */
static void SetDefaultRssiValues(UINT32 carrMode, INT32 *pRssiDbfs, INT32 *pRssiDbm)
{
    INPUT_POINTER_CHECK_RETURN(pRssiDbfs);
    INPUT_POINTER_CHECK_RETURN(pRssiDbm);

    if (carrMode == BSP_RADIO_STANDARD_LTE_FDD || carrMode == BSP_RADIO_STANDARD_FDD_5G)
    {
        *pRssiDbm = RSSI_NO_POWER_DBM;
        *pRssiDbfs = RSSI_NO_POWER_DBFS;
    }
    else if (carrMode == BSP_RADIO_STANDARD_UMTS)
    {
        *pRssiDbm = BSP_INVALID_VALUE;
        *pRssiDbfs = BSP_INVALID_VALUE;
    }
}

/* 农网场景，载波切换时，对切换载波做优化处理*/
VOID BspCalcFarmRssiDbmLimit(UINT32 bspChn, UINT32 bspCarrNo, UINT32 carrMode, INT32 *pRssiDbfs, INT32 *pRssiDbm)
{
    UINT32 carrOn = 0;
    BOOL chnValid = 0;

    INPUT_POINTER_CHECK_RETURN(pRssiDbfs);
    INPUT_POINTER_CHECK_RETURN(pRssiDbm);

    /* 非农网场景，返回0，不做任何处理 */
    chnValid = BspIsFarmValidRxChan(bspChn, carrMode);
    if (!chnValid)
    {
        return ;
    }

    carrOn = BspGetFarmRxCarrSwitch(bspChn, carrMode, bspCarrNo);
    dbgInfoEx("%s>>>chan[%u], carrNo[%u], carrMode[%u], carrValid[%u], rssiDbfs[%d], rssiDbm[%d]\n",
        __FUNCTION__, bspChn, bspCarrNo, carrMode, carrOn, *pRssiDbfs, *pRssiDbm);
    if (SWITCH_OFF == carrOn)
    {
        SetDefaultRssiValues(carrMode, pRssiDbfs, pRssiDbm);
    }
    else if (SWITCH_ON == carrOn)
    {
        if ((*pRssiDbfs <= RSSI_NO_POWER_DBFS) || (*pRssiDbm <= RSSI_NO_POWER_DBM))
        {
            SetDefaultRssiValues(carrMode, pRssiDbfs, pRssiDbm);
        }
    }
}
/* Ended by AICoder, pid:12ef91aa25304401bc75bf5d141939fb */

/* Started by AICoder, pid:3c6bbb88ad6c4117bd7f7ba704c85879 */
VOID BspCalcRssiDbmLimit(INT32 *pRssiDbfs, INT32 *pRssiDbm)
{
    INPUT_POINTER_CHECK_RETURN(pRssiDbfs);
    INPUT_POINTER_CHECK_RETURN(pRssiDbm);

    if (*pRssiDbfs <= RSSI_NO_POWER_DBFS || *pRssiDbm <= RSSI_NO_POWER_DBM)
    {
        *pRssiDbfs = RSSI_NO_POWER_DBFS;
        *pRssiDbm = RSSI_NO_POWER_DBM;
    }
}
/* Ended by AICoder, pid:3c6bbb88ad6c4117bd7f7ba704c85879 */

/* Started by AICoder, pid:43e14y4ae9dfc6f14c2b097610488d1e13954cf5 */
//GSM制式rssi的dbm和dbfs值的限制
VOID BspCalcGsmRssiLimit(INT32 *pRssiDbfs, INT32 *pRssiDbm)
{
    INPUT_POINTER_CHECK_RETURN(pRssiDbfs);
    INPUT_POINTER_CHECK_RETURN(pRssiDbm);

    if(*pRssiDbm < RSSI_NO_POWER_DBM)
    {
        *pRssiDbm = RSSI_NO_POWER_DBM;
    }
    *pRssiDbfs = *pRssiDbm + 1153;//GET_POW_DBFS(PowAvg);
    if(*pRssiDbfs < RSSI_NO_POWER_DBFS)
    {
        *pRssiDbfs = RSSI_NO_POWER_DBFS;
    }
}
/* Ended by AICoder, pid:43e14y4ae9dfc6f14c2b097610488d1e13954cf5 */

/* Started by AICoder, pid:zd325t16c9a5efc14fbc08a420c3a71f4145feff */
//UMTS制式rssi的dbm和dbfs值的限制
VOID BspCalcUmtsRssiLimit(INT32 rssiGain, INT32 preAtt, INT32 *pRssiDbfs, INT32 *pRssiDbm)
{
    INPUT_POINTER_CHECK_RETURN(pRssiDbfs);
    INPUT_POINTER_CHECK_RETURN(pRssiDbm);

    if(*pRssiDbm < RSSI_NO_POWER_DBM)
    {
        *pRssiDbm = RSSI_NO_POWER_DBM;
    }
    *pRssiDbfs = *pRssiDbm + rssiGain + preAtt;//preatt为负值
    if(*pRssiDbfs < RSSI_NO_POWER_DBFS)
    {
        *pRssiDbfs = RSSI_NO_POWER_DBFS;
    }
    return;
}
/* Ended by AICoder, pid:zd325t16c9a5efc14fbc08a420c3a71f4145feff */


VOID BspCalcUmtsRssiOptmize(INT32 lRssiOrig, INT32 *pRssiDbm)
{
    FLOAT fTemp = 0.0;
    INPUT_POINTER_CHECK_RETURN(pRssiDbm);

    if(lRssiOrig <= -10800)
    {
        *pRssiDbm = lRssiOrig;/*当x<=-108,y=x*/
    }
    else if((lRssiOrig>-10800) && (lRssiOrig <= -9400))
    {
    	fTemp = 0.0067*lRssiOrig*lRssiOrig/100 + 1.8087 * lRssiOrig + 880;/*当-108<x<=-94,y = 0.0067*x*x + 1.8087*x + 8.8*/
    	*pRssiDbm = (INT32)fTemp;
    }

    else if((lRssiOrig>-9400) && (lRssiOrig <= -5700))
    {
    	fTemp = 0.107 * lRssiOrig - 9189.5;/*当-94<x<=-57,y=0.107x-91.895*/
    	*pRssiDbm = (INT32)fTemp;
    }

    else if((lRssiOrig>-5700) && (lRssiOrig <= -4600))
    {
    	fTemp = 4849 + 2.57 * lRssiOrig;/*当-94<x<=-57,y=0.107x-91.895*/
    	*pRssiDbm = (INT32)fTemp;
    }
    else
    {
    	*pRssiDbm = -7000;/*当x>-46,y=-70*/
    }
    return;
}

/* Started by AICoder, pid:je99au8a48f085a14c1a087b50973c181a95e360 */
//非GSM和UMTS制式rssi的dbm和dbfs值的限制
VOID BspCalcRssiLimit(UINT32 bspChn, INT32 rssiGain, INT32 preAtt, INT32 *pRssiDbfs, INT32 *pRssiDbm)
{
    INPUT_POINTER_CHECK_RETURN(pRssiDbfs);
    INPUT_POINTER_CHECK_RETURN(pRssiDbm);

    if(*pRssiDbfs < RSSI_NO_POWER_DBFS)
    {
        *pRssiDbfs = RSSI_NO_POWER_DBFS;
    }
    *pRssiDbm = *pRssiDbfs - rssiGain - preAtt + BspGetLna2ByPassGain(bspChn);
    if(*pRssiDbm < RSSI_NO_POWER_DBM)
    {
        *pRssiDbm = RSSI_NO_POWER_DBM;
    }
}
/* Ended by AICoder, pid:je99au8a48f085a14c1a087b50973c181a95e360 */

/* Started by AICoder, pid:17ea1ocbf4abdb0147820abf1044890201f9e393 */
UINT32 BspCalcRssi(UINT32 bspChn, UINT32 bspCarrNo, UINT32 carrMode, INT32 PowAvg, INT32 rssiGain, INT32 *pRssiDbm, INT32 *pRssiDbfs)
{
    INT32 preAtt     = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 uiflag = 0;

    if(BSP_OK !=BspGetVgaCompCarrFacx(bspChn,bspCarrNo,carrMode, &preAtt))
    {
        preAtt = 0;
    }

    if(BSP_RADIO_STANDARD_GSM == carrMode)
    {
        *pRssiDbm = PowAvg;
        if(NOT_QCELL_MODE == BspGetPbOrBbuMode())
        {
            *pRssiDbfs = *pRssiDbm + 1153;//GET_POW_DBFS(PowAvg);
        }else//qcell走该分支
        {
            BspCalcGsmRssiLimit(pRssiDbfs, pRssiDbm); 
        }

        if(BspGetDifInfoByBspChn(bspChn, RX, &chipId, &difChan) != BSP_OK)
        {
            dbgErr("[%s] bspChn %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, bspChn);
            return BSP_ERROR;
        }
        BspHalApiGetRxDataOffFlag(difChan, bspCarrNo, carrMode, &uiflag);
        dbgInfoEx("[%s] uiflag = %d\n", __FUNCTION__, uiflag);
        if(1 == uiflag)
        {
            *pRssiDbm = RSSI_NO_POWER_DBM;
            *pRssiDbfs = RSSI_NO_POWER_DBFS;
        }
    }
    else if(BSP_RADIO_STANDARD_UMTS == carrMode)
    {
        *pRssiDbm = PowAvg;
        if( NOT_QCELL_MODE == BspGetPbOrBbuMode() )
        {
            if(BspGetUMTSRssiOptimizeSw(bspChn, bspCarrNo) == SWITCH_ON)
            {
                BspCalcUmtsRssiOptmize(PowAvg, pRssiDbm);
            }
            *pRssiDbfs = *pRssiDbm + rssiGain;

            dbgInfoEx("[%s]bspChn%d,bspCarrNo%d,carrMode%d,Source Rssi %d Dest Rssi %d\n", __FUNCTION__,bspChn,bspCarrNo,carrMode,PowAvg,*pRssiDbm);
        }
        else//qcell走该分支
        {
            BspCalcUmtsRssiLimit(rssiGain, preAtt, pRssiDbfs, pRssiDbm);
        }
    }
    else
    {
        *pRssiDbfs = PowAvg;

        if( NOT_QCELL_MODE == BspGetPbOrBbuMode() )
        {
            *pRssiDbm = *pRssiDbfs - rssiGain - preAtt + BspGetLna2ByPassGain(bspChn);
            BspCalcRssiDbmLimit(pRssiDbfs, pRssiDbm);
        }
        else //qcell走该分支
        {
            BspCalcRssiLimit(bspChn, rssiGain, preAtt, pRssiDbfs, pRssiDbm);
        }
    }

    BspCalcFarmRssiDbmLimit(bspChn, bspCarrNo, carrMode, pRssiDbfs, pRssiDbm);
    dbgInfoEx("[%s]bspChn%d,bspCarrNo%d,carrMode%d,&rssiGain=%d,preAtt=%d,PowAvg=%d,rssi=%d\n", __FUNCTION__,bspChn,bspCarrNo,carrMode,rssiGain,preAtt,PowAvg,*pRssiDbm);

    return BSP_OK;
}
/* Ended by AICoder, pid:17ea1ocbf4abdb0147820abf1044890201f9e393 */

UINT32 BspGetRssiInfoValue(UINT32 bspChn, UINT32 bspCarrNo, UINT32 carrMode, UINT32 slotNo, UINT32 rssiType,INT32 *pRssiDbm, INT32 *pRssiDbfs)
{
    UINT32 retVal    = 0;
    INT32  PowAvg    = 0;
    INT32  rssiGain  = 0;
    UINT32 carrFreq  = 0;
    UINT32 uIdx      = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    INPUT_POINTER_CHECK(pRssiDbm);
    INPUT_POINTER_CHECK(pRssiDbfs);

    pRfCfg = GetRfCfgPara(bspChn, RX);
    if (NULL == pRfCfg)
    {
        dbgInfoEx("[%s]bspChn'%d pRfCfg Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    if(pRfCfg->para.carrNum > BSP_MAX_CARR_NUM)
    {
        return BSP_ERROR;
    }

    retVal = BspCarrInfoMatching(bspCarrNo, carrMode, pRfCfg, &uIdx);
    if(BSP_OK != retVal)
    {
        dbgInfoEx("[%s]BspCarrInfoMatching is Error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(pRfCfg->para.carrNum == uIdx)
    {
        dbgInfoEx("[%s]uIdx = %d, No Find CarrInfo!\n", __FUNCTION__, uIdx);
        return BSP_ERROR;
    }
    carrFreq = pRfCfg->para.carrInfo[uIdx].freq;
    dbgInfoEx("uIdx = %d,carrFreq = %d\n",uIdx,carrFreq);

    retVal = BspGetRssiDbmCompGain(bspChn, carrMode, carrFreq, 0, &rssiGain, COMPS_BY_FREQ_POINT_TYPE);
    retVal |= ReadBbRssiPow(bspChn, bspCarrNo, slotNo, carrMode, rssiType, &PowAvg);
    if((0 == PowAvg) || (BSP_OK != retVal))
    {
        return BSP_ERROR;
    }

    retVal = BspCalcRssi(bspChn, bspCarrNo, carrMode, PowAvg, rssiGain, pRssiDbm, pRssiDbfs);

    return retVal;
}

INT32 BspCalcMergeRssi(INT32 masterPowAvg, INT32 virtualPowAvg)
{
    return (INT32)(10*log10(pow(10, (DOUBLE)masterPowAvg/1000) + pow(10,(DOUBLE)virtualPowAvg/1000)) * 100);
}

UINT32 BspGetVirtualCarrNo(void)
{
    return s_virtualCarrNo;
}
/**************************************************************************
 * 函数名称: BspGetRssiPowInfo(*)
 * 功能描述: 获取基带rssi分载波功率 dbm 和 dbfs
 * 输入参数: chan  - 通道号
             carr  - 载波号(业务载波，以工装后台以及高层看到的载波号为准)
 * 输出参数: pBbPow- 基带功率,单位0.01dBm
 * 返 回 值: BSP_OK 成功；其他 - 失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月29日 10090699    创建
 **************************************************************************/
UINT32 BspGetRssiPowInfoByMode(UINT32 bspChn, UINT32 bspCarrNo, UINT32 carrMode, UINT32 slotNo, UINT32 rssiType,INT32 *pRssiDbm, INT32 *pRssiDbfs)
{
    UINT32 retVal   = 0;
    UINT32 vCarrNo = 0;
    INT32  vRssiDbm = 0;
    INT32  vRssiDbfs = 0;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();
    POW_RXCHAN_CHECK(bspChn);
    INPUT_POINTER_CHECK(pRssiDbm);
    INPUT_POINTER_CHECK(pRssiDbfs);

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && BSP_RADIO_STANDARD_AIOT == carrMode && NULL != pFpgaInfo->pFuncGetFpgaRssiPowInfo)
    {
        return pFpgaInfo->pFuncGetFpgaRssiPowInfo(bspChn, bspCarrNo, carrMode, pRssiDbm, pRssiDbfs);
    }

    retVal = BspGetRssiInfoValue(bspChn, bspCarrNo, carrMode, slotNo, rssiType, pRssiDbm, pRssiDbfs);

    //支持NR两段式机型会进入以下流程进行两载波天线口功率统计合并
    if(BSP_OK == BspGetTwoSegAssociateVirtualCarr(bspChn, bspCarrNo, carrMode, &vCarrNo))
    {
        s_virtualCarrNo = vCarrNo;
        if(BSP_OK == BspGetRssiInfoValue(bspChn, vCarrNo, carrMode, slotNo, rssiType, &vRssiDbm, &vRssiDbfs))
        {
            dbgInfoEx("[%s] RssiDbm = %d, virtualDbm = %d,rssiType[%d]. \n", __FUNCTION__, *pRssiDbm, vRssiDbm,rssiType);
            *pRssiDbm = BspCalcMergeRssi(*pRssiDbm, vRssiDbm);
        }
    }

    return retVal;
}

#if 0
/**************************************************************************
 * 函数名称: BspGetRssiPowInfo(*)
 * 功能描述: 获取基带rssi分载波功率 dbm 和 dbfs
 * 输入参数: chan  - 通道号
             carr  - 载波号(物理载波)
 * 输出参数: pBbPow- 基带功率,单位0.01dBm
 * 返 回 值: BSP_OK 成功；其他 - 失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月29日 10090699    创建
 **************************************************************************/
UINT32 BspGetRssiPowInfoByModeDif(UINT32 bspChn, UINT32 difCarrNo, UINT32 uMode, UINT32 rssiType, INT32 *pRssiDbm, INT32 *pRssiDbfs)
{
    UINT32 retVal = BSP_OK;
    UINT32 carrMode = uMode;
    INT32  PowAvg = 0;
    INT32  rssiGain = 0;

    INPUT_POINTER_CHECK(pRssiDbm);
    INPUT_POINTER_CHECK(pRssiDbfs);

    POW_RXCHAN_CHECK(bspChn);
    POW_CARR_CHECK(difCarrNo);

    retVal = ReadBbRssiPow(bspChn, difCarrNo, 0, carrMode, rssiType, &PowAvg);
    if ((0 == PowAvg)||(retVal != BSP_OK))
    {
        return BSP_ERROR;
    }
    retVal |= _BspGetRssiDbmGain(bspChn, uMode, &rssiGain, COMPS_BY_FREQ_POINT_TYPE);
    if ((BSP_RADIO_STANDARD_LTE_FDD == carrMode)||(BSP_RADIO_STANDARD_5G == carrMode)||(BSP_RADIO_STANDARD_LTE_TDD == carrMode))
    {
        //*pRssiDbfs = PowAvg - 9031;//GET_POW_DBFS(PowAvg);
        *pRssiDbfs = PowAvg;
        *pRssiDbm = *pRssiDbfs - rssiGain;
    }
    else if(BSP_RADIO_STANDARD_NB_IOT == carrMode)
    {
        //*pRssiDbfs = 10 * (PowAvg - 65536 + 1300 + 90) - 9031;//按15bit折算
        *pRssiDbfs = PowAvg;
        *pRssiDbm = *pRssiDbfs - rssiGain;
    }
    else if(BSP_RADIO_STANDARD_GSM == carrMode)
    {
        //*pRssiDbm = 10*(PowAvg - 65536);
        *pRssiDbm = PowAvg;
        *pRssiDbfs = *pRssiDbm + rssiGain;//GET_POW_DBFS(PowAvg);
    }

    return retVal;
}
#endif
UINT32 BspGetBbTssiPow(UINT32 chan,UINT32 radio,UINT32 carr, INT32 *pBbPowDbfs)
{
    INT32 bbTssidbm = 0;
    INPUT_POINTER_CHECK(pBbPowDbfs);
    return BspGetTssiPowInfo(chan,radio, carr, &bbTssidbm, pBbPowDbfs);
}

/* Started by AICoder, pid:09eeebf12df9121142ba0a7830e7a612f9612466 */
UINT32 BspGetRssiTypeFlag(VOID)
{
    return s_rssiTypeFlag;
}

UINT32 BspSetRssiTypeFlag(UINT32 rssiTypeFlag)
{
    s_rssiTypeFlag = rssiTypeFlag;

    return BSP_OK;
}
/* Ended by AICoder, pid:09eeebf12df9121142ba0a7830e7a612f9612466 */

UINT32 BspGetRssiPow(UINT32 chan,UINT32 radio, UINT32 carr, INT32 *pBbPow)
{
    INT32 bbRssiDbfs = 0x80000000;
    INT32 bbRssiDbm = 0x80000000;
    UINT32 retVal = BSP_OK;
    INT32  powDbmSlot = 0x80000000;
    INT32  powDbfsSlot = 0x80000000;
    UINT32 slotNum = 1;
    UINT32 slotNo = 0;
    UINT32 rssiType = BSP_HALADAPT_RSSI_LONG_FRAME;

    INPUT_POINTER_CHECK(pBbPow);
    /*rssitype暂时只对lte有效，上报选择长时rssi*/
    if(radio == BSP_RADIO_STANDARD_GSM)
    {
        slotNum = FUNCLIB_GSM_MAX_SLOT_NUM;
    }
    for(slotNo = 0; slotNo < slotNum; slotNo++)
    {
        /* Started by AICoder, pid:bdc1chf9a97f56a14f0b0baa40679c01d174cac1 */
        if((BspGetRssiTypeFlag() == BSP_HALADAPT_RSSI_SHORT_FRAME) &&((radio == BSP_RADIO_STANDARD_5G) || (radio == BSP_RADIO_STANDARD_LTE_TDD)))
        {
            rssiType = BSP_HALADAPT_RSSI_SHORT_FRAME;
        }
        /* Ended by AICoder, pid:bdc1chf9a97f56a14f0b0baa40679c01d174cac1 */
        retVal |= BspGetRssiPowInfoByMode(chan,carr, radio, slotNo,rssiType, &powDbmSlot, &powDbfsSlot);
        dbgInfoEx("[%s] chan[%d] rssiType[%d] carrNo[%d] radio[%#x] slotNo[%d] rssidbm[%d] rssidbfs[%d], rssiType[%d]. \n",__func__,chan,rssiType,carr,radio,slotNo,powDbmSlot,powDbfsSlot,rssiType);
        bbRssiDbfs = max(bbRssiDbfs,powDbfsSlot);
        bbRssiDbm = max(bbRssiDbm,powDbmSlot);
    }

    if(retVal != BSP_OK)
    {
        return BSP_ERROR;
    }

    if(bbRssiDbm == ((INT32)0x80000000))
    {
        bbRssiDbm = BSP_INVALID_VALUE;
    }
    *pBbPow = bbRssiDbm;
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetRxIfRssi(*)
 *  功能描述   : 计算rssi合载波功率
 *  读全局变量:
 *  写全局变量:
 *  输入参数   : bspChn - 通道号，从0开始定义
 *  输出参数   : pIfPow - rssi合载功率
 *  返 回 值: BSP_OK成功，其他值失败
 *  其它说明   : 外部接口
 *  工装使用申明: 工装使用接口，请注意波及
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 王佳   @2022-11-01 15:42:06, 创建
 *----------------------------------------------------------------------------
 *****************************************************************************/
UINT32 BspGetRxIfRssi(UINT32 bspChn, INT32 *pIfPow)
{
    UINT32 carr = 0;
    INT32 rssiDbm = 0;
    UINT32 ulRadioNum = 0;
    UINT32 ulRadioLoop = 0;
    UINT32 carrNum = BSP_MAX_CARR_NUM;
    UINT32 uMode  = BspGetRadioStandard(); /*根据整机制式支持来获取底层rssi功率*/
    T_ChanRfCfgPara *pRfCfg = NULL;
    UINT32 difCarrNo = 0;
    DOUBLE powMw = 0.0;
    UINT32 retVal = BSP_OK;
    struct sRadio
    {
        UINT32 uMode;
        CHAR *pcModeString;
    }atRadio[] =
    {
        {BSP_RADIO_STANDARD_LTE_TDD, "LTE_TDD"},
        {BSP_RADIO_STANDARD_LTE_FDD, "LTE_FDD"},
        {BSP_RADIO_STANDARD_5G,      "5G-NR-TDD"},
        {BSP_RADIO_STANDARD_FDD_5G,  "5G-NR-FDD"},
        {BSP_RADIO_STANDARD_UMTS,    "UMTS"},
        {BSP_RADIO_STANDARD_NB_IOT,  "NB-IOT"},
        {BSP_RADIO_STANDARD_GSM,     "GSM"},
    };
    ulRadioNum = NELEMENTS(atRadio);

    INPUT_POINTER_CHECK(pIfPow);

    pRfCfg = GetRfCfgPara(bspChn,RX);
    if (NULL == pRfCfg)
    {
        dbgErr("[%s]BspChan'%d pRfCfg Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    for (carr = 0; carr < carrNum; carr++)
    {
        if(carr >= pRfCfg->para.carrNum)
        {
            continue;
        }
        for (ulRadioLoop = 0; ulRadioLoop < ulRadioNum; ulRadioLoop++)
        {
            if (0 == (uMode & atRadio[ulRadioLoop].uMode))
            {
                continue;
            }
            if(pRfCfg->para.carrInfo[carr].radioMode != atRadio[ulRadioLoop].uMode)
            {
                continue;
            }
            rssiDbm  = 0;
            difCarrNo = pRfCfg->para.carrInfo[carr].carrNo;
            retVal |= BspGetRssiPow(bspChn, atRadio[ulRadioLoop].uMode, difCarrNo, &rssiDbm);
            powMw += pow(10.0, rssiDbm / 1000.0);
        }
    }

    *pIfPow = (INT32)(1000.0*log10(powMw/1.0));

    return retVal;
}

/**************************************************************************
 * 函数名称: BspGetBbTssiTcpw(*)
 * 功能描述: 获取模拟分载波接口
 * 输入参数: chan  - 通道号
             carr  - 载波号(物理载波)
 * 输出参数: pTssi - 基带功率,单位0.01dBm
 *           pTcpw - UMTS的TCPW
 * 返 回 值: BSP_OK 成功；其他 - 失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年06月29日 10090699    创建
 **************************************************************************/
UINT32 BspGetBbTssiTcpw(UINT32 chan, UINT32 radio, UINT32 carr, INT32 *pTssi, INT32 *pTcpw)
{
    UINT32 retVal = BSP_OK;
    UINT32 bandno = 0;
    INT32 fwdGain=0;
    INT32 lDbfsValueTcpw=0;
    INT32 tssiDbfs = 0;
    ePowType powType = BSP_TSSI_FWD_INFO;
    T_TxPow tPowDbfs = {0};
    INPUT_POINTER_CHECK(pTssi);
    INPUT_POINTER_CHECK(pTcpw);

    retVal = BspGetTssiPowInfo(chan, radio, carr, pTssi,&tssiDbfs);
    if(radio == BSP_RADIO_STANDARD_UMTS)
    {
        retVal |= GetTssiPowDbfs(chan,bandno,powType,&tPowDbfs);/*IC4.2不存在频段功率检测*/
        retVal |= _BspGetFwdDbmGain(chan,&fwdGain,COMPS_BY_FREQ_POINT_TYPE);
        lDbfsValueTcpw = tssiDbfs - tPowDbfs.tFwdPow.ifTssiPow + tPowDbfs.tFwdPow.fbPow;/* UMTS基带处满功率-13dB,比-19大6dB */
        dbgInfoEx("[%s]bspChn%d,bspCarrNo%d,carrMode%d,tssiDbfs=%d| tPowDbfs.tFwdPow.ifTssiPow=%d tPowDbfs.tFwdPow.fbPow=%d\n",__FUNCTION__,chan,carr,radio,tssiDbfs,tPowDbfs.tFwdPow.ifTssiPow,tPowDbfs.tFwdPow.fbPow);
        *pTcpw = lDbfsValueTcpw - fwdGain;
        if((*pTcpw<0) || (*pTssi == 0))
        {
            *pTcpw = 0;
        }

        dbgInfoEx("[%s]bspChn%d,bspCarrNo%d,carrMode%d,*pTssi=%d| *pTcpw=%d\n",__FUNCTION__,chan,carr,radio,*pTssi,*pTcpw);
    }
    else/*其他制式无模拟分载波功率*/
    {
        *pTcpw = BSP_INVALID_VALUE;
    }
    return retVal;
}

UINT32 BspCarrPowUpdate(UINT32 chn,UINT32 carrNo,UINT32 carrPow,UINT32 radio)
{
    UINT32 retVal = BSP_OK;
    T_RruCarrPowCfgInfo *pCarrPowInfo = NULL;
    T_RruRfCfgInfo *pRfCfgInfo = NULL;
    UINT32 carrLoop = 0;
    UINT32 carrPowFlag = 0;

    pCarrPowInfo = malloc(sizeof(T_RruCarrPowCfgInfo));
    INPUT_POINTER_CHECK(pCarrPowInfo);
    pRfCfgInfo   = malloc(sizeof(T_RruRfCfgInfo));
    if(pRfCfgInfo == NULL)
    {
        free(pCarrPowInfo);
        return BSP_ERROR;
    }

    retVal  = BspGetCarrPowCfgPara(chn,pCarrPowInfo);
    retVal |= BspGetChnlCfgCarrPara(chn, pRfCfgInfo);

    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop ++)
    {
        if ((pCarrPowInfo->carr[carrLoop].carrNo == carrNo) && ( pCarrPowInfo->carr[carrLoop].carrRadio == radio))
        {
            pCarrPowInfo->carr[carrLoop].carrPow = carrPow;
            pCarrPowInfo->carr[carrLoop].cfgCarrPow = carrPow;
            carrPowFlag = 1;/*表明之前配置过功率，直接进行更新*/
        }
        if ((pRfCfgInfo->carr[carrLoop].carrTxNo == carrNo) && ( pRfCfgInfo->carr[carrLoop].carrTxRadio == radio))
        {
            pRfCfgInfo->carr[carrLoop].carrPow = carrPow;
        }
    }
    if (carrPowFlag == 0)/*表明新增功率*/
    {
        for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop ++)
        {
            if ((pCarrPowInfo->carr[carrLoop].carrNo == 0) && ( pCarrPowInfo->carr[carrLoop].carrRadio == 0))
            {
                pCarrPowInfo->carr[carrLoop].carrNo = carrNo;
                pCarrPowInfo->carr[carrLoop].carrRadio = radio;
                pCarrPowInfo->carr[carrLoop].carrPow = carrPow;
                pCarrPowInfo->carr[carrLoop].cfgCarrPow = carrPow;
                break;
            }
        }
    }
    /*
    pCarrPowInfo->carr[carrNo].carrNo       = carrNo;
    pCarrPowInfo->carr[carrNo].carrRadio    = radio;
    pCarrPowInfo->carr[carrNo].carrPow      = carrPow;
    */
    retVal |= BspSetCarrPowCfgPara(chn, pCarrPowInfo);
    retVal |= BspSetRruCfgPara(chn, pRfCfgInfo);
    free(pCarrPowInfo);
    free(pRfCfgInfo);
    return retVal;
}

UINT32 BspSetUmtsTxCarrPow(UINT32 bspChn, UINT32 carrIdx, UINT32 carrdb)// 高层传入默认是db增益
{
    UINT32 radioMode = BSP_RADIO_STANDARD_UMTS;
    INT32 umtsCarrDb = 0;
    INT32 umtsBaseGain = 0;

    BspLog(LOG_LEVEL_0,"%s{chn'%u, carr'%u, carrPow'%u} \n",__FUNCTION__,bspChn,carrIdx,carrdb);

    if(1 == BspHalAdaptGetFddUmtsVirCellFlag())
    {
        umtsBaseGain = (INT32)(1000*log10(1.0/8));// 8T FDD 机型功率除以8处理
    }

    umtsCarrDb = umtsBaseGain-carrdb;//umts 增益

    return BspSetTxPcGain(bspChn,carrIdx,radioMode,umtsCarrDb);
}

UINT32 BspGetUmtsTxCarrPow(UINT32 bspChn, UINT32 carrNo)
{
    return UMTS_CARR_POW_FLAG;
}

UINT32 BspSetUmtsCarrPow(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode, UINT32 ulRatePow, UINT32 retVal)
{
    UINT32 chipId=0;
    UINT32 difChan=0;

    if(radioMode == BSP_RADIO_STANDARD_UMTS)
    {
        if(BspGetDifInfoByBspChn(bspChn,TX,&chipId,&difChan) != BSP_OK)
        {
            dbgErr("[%s] line %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, __LINE__);
            return BSP_ERROR;
        }
        retVal = BspSetUmtsChanPow(difChan, carrIndex, radioMode, ulRatePow);
        retVal = BspSetTxBbtssiGain(bspChn, carrIndex, radioMode, carrPow);
        dbgInfoEx("[%s] line %d: difChan %d bspChn %d carrIndex %d radioMode %d ulRatePow %d carrPow %d\n", __FUNCTION__, __LINE__,
                  difChan, bspChn, carrIndex, radioMode, ulRatePow, carrPow);
        BspLog(LOG_LEVEL_0,"%s{chn'%d, carr'%d, radio'0x%x, pow'%d} ratePow=%d retVal %d \n",
                    __FUNCTION__,bspChn,carrIndex,radioMode,carrPow,ulRatePow, retVal);


    }

    return retVal;
}

/* Started by AICoder, pid:f52f7yfc923693f149d70b49b07356261fa00fe8 */
UINT32 BspSetTxAptuneGain(UINT32 bspChn, UINT32 carr, UINT32 radioMode, INT32 gain)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    INT32 bbtssiGain = 0;
    INT32 dlPreGain = 0;
    INT32 dlBankDgain = 0;
    INT32 dlCfrGain = 0;
    INT32 dlBankAPtuneGain = 0;
    T_GainCommPara gainCommPara = {0};

    if(BSP_OK != BspGetDifInfoByBspChn(bspChn,TX,&chipId,&difChan))
    {
        dbgErr("[%s] line %d: DifInfoByBspChn Get Error!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    if(gain == GAIN_INVALID)
    {
        dlBankDgain = GAIN_INVALID;
        bbtssiGain = GAIN_INVALID;
        dlPreGain = GAIN_INVALID;
    }
    else
    {
        if(BSP_OK != BspGetGainCommPara(&gainCommPara))
        {
            dbgErr("[%s] line %d: GainCommPara Get Error!\n", __FUNCTION__, __LINE__);
            return BSP_ERROR;
        }
        dlBankDgain = gainCommPara.dlBankDgain[difChan] + gain;
        dlCfrGain = gainCommPara.preCfrGain[difChan];
        dlBankAPtuneGain = gainCommPara.dlBankApTuneGain[difChan];
        bbtssiGain = (dlBankAPtuneGain + dlBankDgain + dlCfrGain)* 2;
        dlPreGain = gainCommPara.dlPreGain[difChan];
    }

    if(BSP_OK != BspHalAdaptSetDlpreBbtssiGain(difChan, carr, radioMode, bbtssiGain))
    {
        dbgErr("[%s] line %d: set dlpre bbtssi gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d bbtssiGain = %d: set dlpre bbtssi gain Err!\n",
               __FUNCTION__,__LINE__,difChan, carr, radioMode, bbtssiGain);
        return BSP_ERROR;
    }

    if(BSP_OK != BspHalAdaptSetDlpreGain(difChan, carr, radioMode, dlPreGain))
    {
        dbgErr("[%s] line %d: set dlpre gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d dlPreGain = %d: set dlpre gain Err!\n",
               __FUNCTION__,__LINE__,difChan, carr, radioMode, dlPreGain);
        return BSP_ERROR;
    }

    if(BSP_OK != BspHalAdaptSetDlbankAptune(difChan, carr, radioMode, gain))
    {
        dbgErr("[%s] line %d: set dlbank gain Err!\n", __FUNCTION__, __LINE__);
        BspLog(LOG_INFO,LOG_LEVEL_0,"[%s] line: %d difChan: %d carr: %d radioMode: %d dlBankDgain = %d: set dlbank gain Err!\n",
               __FUNCTION__,__LINE__,difChan, carr, radioMode, dlBankDgain);
        return BSP_ERROR;
    }

    dbgInfo("[%s] chan'%d carr'%d radio'%d set Tx carr gain dlPreGain'%d bbtssiGain'%d dlBankAPtuneGain'%d !\n",
               __FUNCTION__,bspChn,carr,radioMode,dlPreGain,bbtssiGain,gain);
    BspLog(LOG_LEVEL_0,"[%s] chan'%d carr'%d radio'%d set Tx carr gain dlPreGain'%d bbtssiGain'%d dlBankAPtuneGain'%d !\n",
               __FUNCTION__,bspChn,carr,radioMode,dlPreGain,bbtssiGain,gain);

    return BSP_OK;
}
/* Ended by AICoder, pid:f52f7yfc923693f149d70b49b07356261fa00fe8 */

UINT32 BspSetTxChanGain(UINT32 bspChn, UINT32 carrIndex, UINT32 radioMode, INT32 carrPow)
{
    UINT32 retVal = BSP_OK;

    if (IS_NCR == BspIsNcr())
    {
        if (carrPow > 0)
        {
            return BSP_ERROR;
        }
        retVal = BspSetTxAptuneGain(bspChn, carrIndex, radioMode, carrPow);
    }
    else
    {
        retVal = BspSetTxPcGain(bspChn,carrIndex,radioMode,carrPow);
    }
    return retVal;
}

static UINT32 BspSetCarrPowD42(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulRatePow=0;
    INT32 carrDbPow = 0;
    UINT16 gsmStaticLevel = 0;
    UINT32 tmpVal = BSP_OK;

    BspGetRruPathRatedPower(bspChn, &ulRatePow);
    if(ulRatePow == 0)
    {
        BspLog(LOG_LEVEL_0,"%s{%d,%d,%d,%d} ulRatePow=%d\n",__FUNCTION__,bspChn,carrIndex,carrPow,radioMode,ulRatePow);
        ulRatePow = 1;
    }

    if( (IS_NCR != BspIsNcr() && ((radioMode == BSP_RADIO_STANDARD_NB_IOT)||(radioMode == BSP_RADIO_STANDARD_LTE_FDD)||
                                  (radioMode == BSP_RADIO_STANDARD_FDD_5G)||(radioMode == BSP_RADIO_STANDARD_GSM)))
        ||
        (IS_NCR == BspIsNcr()) )
    {
        if(carrPow != 0)
        {
            carrDbPow = 1000.0*log10((double)carrPow/((double)ulRatePow+0.000001));
            if(radioMode == BSP_RADIO_STANDARD_GSM)
            {
                carrDbPow = carrDbPow - 950;
                retVal = BspGetGsmStaticPowLevel(bspChn, &gsmStaticLevel);
                if (retVal == BSP_OK)
                {
                    carrDbPow -= gsmStaticLevel * 100;
                }
            }
        }
        else
        {
            carrDbPow = GAIN_INVALID;
        }
        retVal = BspSetTxChanGain(bspChn,carrIndex,radioMode,carrDbPow);
        BspLog(LOG_LEVEL_0,"%s{chn'%d, carr'%d, radio'0x%x, pow'%d} SetGain retVal=%d gsmStaticLevel=%d ratePow=%d carrDbPow %d\n",
                __FUNCTION__,bspChn,carrIndex,radioMode,carrPow,retVal,gsmStaticLevel, ulRatePow, carrDbPow);
    }

    if( IS_NCR != BspIsNcr() && 
        ((radioMode == BSP_RADIO_STANDARD_5G) || (radioMode == BSP_RADIO_STANDARD_LTE_TDD)) )
    {
#if defined(BSP_MAKE_VER) || defined(_BSP_WITH_WFS) /*小版本允许调整tdd功率*/
        carrDbPow = 1000.0*log10((double)carrPow/((double)ulRatePow+0.000001));
        retVal = BspSetTxPcGain(bspChn,carrIndex,radioMode,carrDbPow);
#else
        retVal = BspSetTxBbtssiGain(bspChn, carrIndex, radioMode, carrPow);
#endif
    }

    if( BSP_OK != (tmpVal = BspSetUmtsCarrPow(bspChn, carrIndex, carrPow, radioMode, ulRatePow, retVal)) )
    {
        dbgErr("[%s] line %d: _SetUmtsCarrPow Error!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    BspCarrPowUpdate(bspChn, carrIndex, carrPow, radioMode);
    BspLog(LOG_LEVEL_0,"%s{chn'%d, carr'%d, radio'0x%x, pow'%d} Exit retVal=%d gsmStaticLevel=%d ratePow=%d carrDbPow %d\n",
                    __FUNCTION__,bspChn,carrIndex,radioMode,carrPow,tmpVal,gsmStaticLevel, ulRatePow, carrDbPow);

    return tmpVal;
}

/* 由于包括功率配置，只允许高层调用,高层保证跟配频一起使用，保证*/
UINT32 BspSetCarrPow(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    T_FpgaInfoInit *pFpgaInfo = BspGetFpgaInfo();

    /* fpga链路，d42链路无需关注此处 */
    if (NULL != pFpgaInfo && BSP_RADIO_STANDARD_AIOT == radioMode)
    {
        INPUT_BSPCHN_CHECK(bspChn);
        if (FPGA_CHAN == pFpgaInfo->txFpgaChanFlag[bspChn] && NULL != pFpgaInfo->pFuncSetFpgaCarrPow)
        {
            retVal |= pFpgaInfo->pFuncSetFpgaCarrPow(bspChn, carrIndex, carrPow, radioMode);
            retVal |= BspCarrPowUpdate(bspChn, carrIndex, carrPow, radioMode);
        }
    }
    else
    {
        retVal |= BspSetCarrPowD42(bspChn, carrIndex, carrPow, radioMode);
    }

    return retVal;
}

UINT32 BspSetCarrPowUwb(UINT32 bspChn, UINT32 carrIndex, UINT32 carrPow, UINT32 radioMode)
{
    return  BspSetCarrPow( bspChn,  carrIndex,  carrPow,  radioMode);

}

/* 清除载波增益 */
UINT32 BspClearCarrGain(VOID)
{
    UINT32 carrMode = 0;
    UINT32 bspChn = 0;
    UINT32 carrIndex = 0;
    UINT32 carrNo = 0;
    UINT32 chnNum = BspGetTxChannel();
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg = NULL;

    if(BSP_OK != BspIsRingOptWorkMode())
    {
        BspLog(LOG_LEVEL_0,"%s>>>Not Ring!\n", __FUNCTION__);
        return BSP_OK;
    }

    for(bspChn = 0; bspChn < chnNum; bspChn++)
    {
        pRfCfg = GetRfCfgPara(bspChn, TX);
        if (NULL == pRfCfg)
        {
            dbgErr("[%s]bspChn'%d pRfCfg Get Error!\n", __FUNCTION__, bspChn);
            continue;
        }
        if (pRfCfg->para.carrNum > BSP_MAX_CARR_NUM)
        {
            dbgErr("maxCarrNum is %d \n", pRfCfg->para.carrNum);
            continue;
        }

        for(carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
        {
            carrMode = pRfCfg->para.carrInfo[carrIndex].radioMode;
            carrNo =  pRfCfg->para.carrInfo[carrIndex].carrNo;
            retVal = BspSetCarrPow(bspChn, carrNo, 0, carrMode);
        }
    }
    BspLog(LOG_LEVEL_0,"%s\n", __FUNCTION__);

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetPowDbfs(*)
 *  功能描述   : 获取反馈通道中频处检测到的天馈口前向合载功率
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : ulTxChan - 通道号，从0开始定义
 *  输出参数   :
 *  返 回 值   : 天馈口合载功率值，0.01dBm为单位
 *  其它说明   : 外部接口
 *工装使用申明: 工装使用接口，请注意波及
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 李超   @2012-08-31 15:42:06, 创建

*----------------------------------------------------------------------------
*****************************************************************************/

UINT32 BspGetPowDbfs(UINT32 bspChn,UINT32 band,T_TxPow *pPowDbfs)
{
    ePowType powType = BSP_TSSI_FWD_INFO;
    return GetTssiPowDbfs(bspChn, band, powType, pPowDbfs);
}

/*****************************************************************************
 *  函数名称   : BspGetFwdCpIfTssi(*)
 *  功能描述   : 获取反馈通道中频处检测到的天馈口前向合载功率
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : ulTxChan - 通道号，从0开始定义
 *  输出参数   :
 *  返 回 值   : 天馈口合载功率值，0.01dBm为单位
 *  其它说明   : 外部接口
 *工装使用申明: 工装使用接口，请注意波及
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 李凯   @2012-08-31 15:42:06, 创建
 *  $0000000(N/A), 刘志敬 @2012-08-31 15:42:07, 更新
*----------------------------------------------------------------------------
*****************************************************************************/
UINT32 BspGetFwdCpIfTssi (UINT32 bspChn, UINT32 ulBand, INT32 *pFwdCpIfTssiDbm)
{
    INT32 iFwdCpIfTssiDbm=0;
    UINT32 retVal = 0;
    INT32 fwdGain1 = 0;
    UINT32 RandData = 0;
    INT32 fwdGain = 0;
    INT32 txIfTssiDbm = 0;
    INT32 deltaDbm = 0;
    ePowType powType = BSP_TSSI_FWD_INFO;
    UINT32 comptype = COMPS_BY_FREQ_POINT_TYPE;
    UINT32 ulIndex = FWD_THRESHOLD;
    T_TxPow tPowDbfs = {0};

    retVal = GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    if( BSP_ERROR == retVal )
    {
        dbgErr("%s GetAvgTssiPow failed\n",__FUNCTION__);
        return retVal;
    }

    retVal |= BspGetFwdDbmDelta(bspChn, &deltaDbm);
    retVal |= _BspGetFwdDbmGain(bspChn, &fwdGain1, comptype);
    dbgInfoEx("[%s] bspChn'%u, ulBand'%u fwdGain1'%d\n", __FUNCTION__,bspChn, ulBand,fwdGain1);
    fwdGain = fwdGain1;

    iFwdCpIfTssiDbm = tPowDbfs.tFwdPow.fbPow - fwdGain + deltaDbm;

    dbgInfoEx("[%s] bspChn'%u, ulBand'%u, tPowDbfs.tFwdPow.fbPow'%d, fwdGain'%d, deltaDbm'%d, iFwdCpIfTssiDbm'%d \n", __FUNCTION__,
                bspChn, ulBand, tPowDbfs.tFwdPow.fbPow, fwdGain, deltaDbm, iFwdCpIfTssiDbm);

    if(pFwdCpIfTssiDbm!=NULL)
    {
        *pFwdCpIfTssiDbm = iFwdCpIfTssiDbm;
        if(iFwdCpIfTssiDbm < BspGetPowThreshhold(bspChn, ulIndex))//600
        {
            if(1 == BspGetPowerBelow0dbm())/*额定功率小于0dbm的规格，功率显示和上报需要对0dbm特殊处理*/
            {
                *pFwdCpIfTssiDbm = -15000;
            }
            else
            {
                *pFwdCpIfTssiDbm = 0;
            }
            if (IS_NCR == BspIsNcr())
            {
                *pFwdCpIfTssiDbm = BspGetPowThreshhold(bspChn, ulIndex);
            }
            dbgInfoEx("[%s]: pFwdCpIfTssiDbm = %d, PowThreshhold = %d",
                    __func__, *pFwdCpIfTssiDbm, BspGetPowThreshhold(bspChn, ulIndex));
        }

        if(BspGetPaNormalFlag(bspChn) == PA_UNNORMAL)
        {
            if(BspGetPaSwitch(bspChn) == SWITCH_OFF)
            {
                *pFwdCpIfTssiDbm = 0;
            }
            else
            {
                (void)BspGetTxIfTssi(bspChn, ulBand, &txIfTssiDbm);
                if(txIfTssiDbm <= 0 )
                {
                    *pFwdCpIfTssiDbm = txIfTssiDbm;
                }
                else
                {
                (void)BspGetRandomData(1,&RandData);
                *pFwdCpIfTssiDbm = txIfTssiDbm + RandData%41 - 20;
                   dbgInfoEx("%s: TxIfTssiDbm[%d], RandData[%d]",__FUNCTION__,txIfTssiDbm,RandData);
                }
            }

        }
    }
    else
    {
        dbgInfo("tPowDbfs.tFwdPow.fbPow=%d,fwdGain=%d\n",tPowDbfs.tFwdPow.fbPow,fwdGain);
    }
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetRevCpIfTssi(*)
 *  功能描述   : 获取反馈通道中频处检测到的天馈口前向合载功率
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : ulTxChan - 通道号，从0开始定义
 *  输出参数   :
 *  返 回 值   : 天馈口合载功率值，0.01dBm为单位
 *  其它说明   : 外部接口
 *工装使用申明: 工装使用接口，请注意波及
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 李凯   @2012-08-31 15:42:06, 创建
 *  $0000000(N/A), 刘志敬 @2012-08-31 15:42:07, 更新
*----------------------------------------------------------------------------
*****************************************************************************/
UINT32 BspGetRevCpIfTssi (UINT32 bspChn, UINT32 ulBand, INT32 *pRevCpIfTssiDbm)
{
    INT32 iRevCpIfTssiDbm=0;
    UINT32 retVal = 0;
    UINT32 RandData = 0;
    T_TxPow tPowDbfs = {0};
    INT32 revGain = 0;
    INT32 txIfTssiDbm = 0;
    INT32 deltaDbm = 0;
    ePowType powType = BSP_TSSI_FWD_INFO;

    retVal = GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    if( BSP_ERROR == retVal )
    {
        dbgErr("%s GetAvgTssiPow failed\n",__FUNCTION__);
        return retVal;
    }

    retVal|=_BspGetRevDbmGain(bspChn, &revGain, COMPS_BY_FREQ_POINT_TYPE);
    retVal |= BspGetFwdDbmDelta(bspChn, &deltaDbm);

    iRevCpIfTssiDbm = tPowDbfs.tRevPow.fbPow - revGain + deltaDbm;

    dbgInfoEx("[%s] bspChn'%u, ulBand'%u  tPowDbfs.tRevPow.fbPow'%d, revGain'%d, deltaDbm'%d, iRevCpIfTssiDbm'%d \n", __FUNCTION__,
                bspChn, ulBand, tPowDbfs.tRevPow.fbPow, revGain, deltaDbm, iRevCpIfTssiDbm);

    if (pRevCpIfTssiDbm != NULL)
    {
        *pRevCpIfTssiDbm = iRevCpIfTssiDbm;
        if (iRevCpIfTssiDbm < BspGetPowThreshhold(bspChn, REV_THRESHOLD))
        {
            if(1 == BspGetPowerBelow0dbm())/*额定功率小于0dbm的规格，功率显示和上报需要对0dbm特殊处理*/
            {
                *pRevCpIfTssiDbm = -15000;
            }
            else
            {
                *pRevCpIfTssiDbm = 0;
            }
            if (IS_NCR == BspIsNcr())
            {
                *pRevCpIfTssiDbm = BspGetPowThreshhold(bspChn, REV_THRESHOLD);
            }
            dbgInfoEx("[%s]: pFwdCpIfTssiDbm = %d, PowThreshhold = %d",
                    __func__, *pRevCpIfTssiDbm, BspGetPowThreshhold(bspChn, REV_THRESHOLD));
        }

        if(BspGetPaNormalFlag(bspChn) == PA_UNNORMAL)
        {
            if(BspGetPaSwitch(bspChn) == SWITCH_OFF)
            {
                *pRevCpIfTssiDbm = 0;
            }
            else
            {
                (void)BspGetTxIfTssi(bspChn, ulBand, &txIfTssiDbm);
                if(txIfTssiDbm <= 0 )
                {
                    *pRevCpIfTssiDbm = txIfTssiDbm;
                }
                else
                {
                    (void)BspGetRandomData(1,&RandData);
                    *pRevCpIfTssiDbm = txIfTssiDbm + RandData%41 - 2000 - 20;
                }
            }
        }
    }
    else
    {
        dbgInfo("ulRevCpIfTssiDbm=%d,revGain=%d\n",iRevCpIfTssiDbm,revGain);
    }
    return retVal;
}

UINT32 BspGetTxIfTssiFwdCpIfTssi(UINT32 bspChn, UINT32 ulBand, INT32 *pTxIfTssiDbm, INT32 *pFwdCpIfTssiDbm)
{
    INT32 iTxIfTssiDbm = 0;
    UINT32 retVal = BSP_OK;
    INT32 txGain = 0;
    T_TxPow tPowDbfs = {0};
    INT32 iFwdCpIfTssiDbm=0;
    INT32 fwdGain = 0;
    INT32 deltaDbm = 0;
    ePowType powType = BSP_TSSI_FWD_INFO;

    INPUT_POINTER_CHECK(pTxIfTssiDbm);

    INPUT_POINTER_CHECK(pFwdCpIfTssiDbm);

    retVal = GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    if(BSP_ERROR == retVal )
    {
        dbgInfoEx("%s GetAvgTssiPow failed,bspChn is %d,ulBand is %d\n",__FUNCTION__,bspChn,ulBand);
        return retVal;
    }

    _BspGetIfTssiDbmGain(bspChn, &txGain, COMPS_BY_FREQ_POINT_TYPE);
    iTxIfTssiDbm = tPowDbfs.tFwdPow.ifTssiPow + txGain;

    *pTxIfTssiDbm = iTxIfTssiDbm;

    if (iTxIfTssiDbm < BspGetPowThreshhold(bspChn, TSSI0_THRESHOLD))
    {
        dbgInfoEx("%s TxIfTssiDbm=0, bspChn is %d, TSSI0_THRESHOLD is %d\n",__FUNCTION__,bspChn,BspGetPowThreshhold(bspChn,TSSI0_THRESHOLD));
        *pTxIfTssiDbm = 0;
    }

    _BspGetFwdDbmGain(bspChn, &fwdGain, COMPS_BY_FREQ_POINT_TYPE);
    retVal |= BspGetFwdDbmDelta(bspChn, &deltaDbm);

    iFwdCpIfTssiDbm = tPowDbfs.tFwdPow.fbPow - (INT32)fwdGain + deltaDbm;

    dbgInfoEx("%s bspChn %d, ulBand %d, tPowDbfs.tFwdPow.fbPow %d, fwdGain %d, deltaDbm %d, iFwdCpIfTssiDbm %d\n",__FUNCTION__,
      bspChn, ulBand, tPowDbfs.tFwdPow.fbPow, fwdGain, deltaDbm, iFwdCpIfTssiDbm);

    *pFwdCpIfTssiDbm = iFwdCpIfTssiDbm;
    if (iFwdCpIfTssiDbm < BspGetPowThreshhold(bspChn, FWD_THRESHOLD))//600
    {
        dbgInfoEx("%s pFwdCpIfTssiDbm=0, bspChn is %d, FWD_THRESHOLD is %d\n",__FUNCTION__,bspChn,BspGetPowThreshhold(bspChn,FWD_THRESHOLD));
        *pFwdCpIfTssiDbm = 0;
    }

    return retVal;
}


/*****************************************************************************
 *  函数名称   : BspGetTxIfTssi(*)
 *  功能描述   : 获取反馈通道中频处检测到的天馈口前向合载功率
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : ulTxChan - 通道号，从0开始定义
 *  输出参数   :
 *  返 回 值   : 天馈口合载功率值，0.01dBm为单位
 *  其它说明   : 外部接口
 *工装使用申明: 工装使用接口，请注意波及
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 李凯   @2012-08-31 15:42:06, 创建
 *  $0000000(N/A), 刘志敬 @2012-08-31 15:42:07, 更新
 *----------------------------------------------------------------------------
 *****************************************************************************/
UINT32 BspGetTxIfTssi (UINT32 bspChn, UINT32 ulBand, INT32 *pTxIfTssiDbm)
{
    INT32 iTxIfTssiDbm = 0;
    UINT32 retVal = 0;
    INT32 txGain = 0;
    T_TxPow tPowDbfs = {0};
    ePowType powType = BSP_TSSI_FWD_INFO;
    UINT32 comptype = COMPS_BY_FREQ_POINT_TYPE;
    UINT32 ulIndex = TSSI0_THRESHOLD;
    INT32 targetGainDelta = 0;

    retVal = GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    if( BSP_ERROR == retVal )
    {
        dbgErr("%s GetAvgTssiPow failed\n",__FUNCTION__);
        return retVal;
    }

    retVal |= _BspGetIfTssiDbmGain(bspChn, &txGain, comptype);

    if((BSP_OK == BspGetTargetGainDelta(bspChn,&targetGainDelta))&&(0 != targetGainDelta))
    {
        txGain = txGain - targetGainDelta;
    }

    iTxIfTssiDbm = tPowDbfs.tFwdPow.ifTssiPow + txGain;

    if (pTxIfTssiDbm!=NULL)
    {
        *pTxIfTssiDbm = iTxIfTssiDbm;
        if (iTxIfTssiDbm < BspGetPowThreshhold(bspChn, ulIndex))
        {
            if(1 == BspGetPowerBelow0dbm())/*额定功率小于0dbm的规格，功率显示和上报需要对0dbm特殊处理*/
            {
                *pTxIfTssiDbm = -15000;
            }
            else
            {
                *pTxIfTssiDbm = 0;
            }
            if (IS_NCR == BspIsNcr())
            {
                *pTxIfTssiDbm = BspGetPowThreshhold(bspChn, ulIndex);
            }
            dbgInfoEx("[%s]: pTxIfTssiDbm = %d, PowThreshhold = %d",
                    __func__, *pTxIfTssiDbm, BspGetPowThreshhold(bspChn, ulIndex));
        }
    }
    else
    {
        dbgInfo("tPowDbfs.tFwdPow.ifTssiPow=%d,txGain=%d\n",tPowDbfs.tFwdPow.ifTssiPow,txGain);
    }
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetRevIfTssi(*)
 *  功能描述   : 获取反馈通道中频处检测到的天馈口前向合载功率
 *  读全局变量 :
 *  写全局变量 :
 *  输入参数   : ulTxChan - 通道号，从0开始定义
 *  输出参数   :
 *  返 回 值   : 天馈口合载功率值，0.01dBm为单位
 *  其它说明   : 外部接口
 *工装使用申明: 工装使用接口，请注意波及
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 李凯   @2012-08-31 15:42:06, 创建
 *  $0000000(N/A), 刘志敬 @2012-08-31 15:42:07, 更新
 *----------------------------------------------------------------------------
 *****************************************************************************/
UINT32 BspGetRevIfTssi (UINT32 bspChn, UINT32 ulBand, INT32 *pTxRevTssiDbm)
{
    INT32 iTxRevTssiDbm = 0;
    UINT32 retVal = 0;
    INT32 txGain = 0;
    T_TxPow tPowDbfs = {0};
    ePowType powType = BSP_TSSI_FWD_INFO;
    UINT32 comptype = COMPS_BY_FREQ_POINT_TYPE;
    UINT32 ulIndex = TSSI1_THRESHOLD;

    retVal = GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    if( BSP_ERROR == retVal )
    {
        dbgErr("%s GetAvgTssiPow failed\n",__FUNCTION__);
        return retVal;
    }
    retVal |= _BspGetIfTssiDbmGain(bspChn, &txGain, comptype);

    iTxRevTssiDbm = tPowDbfs.tRevPow.ifTssiPow + txGain;

    if(pTxRevTssiDbm != NULL)
    {
        *pTxRevTssiDbm = iTxRevTssiDbm;
        if(iTxRevTssiDbm < BspGetPowThreshhold(bspChn, ulIndex))
        {
            if(1 == BspGetPowerBelow0dbm())/*额定功率小于0dbm的规格，功率显示和上报需要对0dbm特殊处理*/
            {
                *pTxRevTssiDbm = -15000;
            }
            else
            {
                *pTxRevTssiDbm = 0;
            }
            if (IS_NCR == BspIsNcr())
            {
                *pTxRevTssiDbm = BspGetPowThreshhold(bspChn, ulIndex);
            }
            dbgInfoEx("[%s]: pTxRevTssiDbm = %d, PowThreshhold = %d",
                    __func__, *pTxRevTssiDbm, BspGetPowThreshhold(bspChn, ulIndex));
        }
    }
    else
    {
        dbgInfo("tPowDbfs.tRevPow.ifTssiPow=%d,txGain=%d\n",tPowDbfs.tRevPow.ifTssiPow,txGain);
    }
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetTssiTcpwFlag(*)
 *  功能描述   : 获取Tx通道中频数字,前向模拟同步功率(0.01dbm) 功率有效标志
 *  读全局变量 :
 *  写全局变量 : 无
 *  输入参数   : ulTxChan - 通道号，从0开始定义
 *  输出参数   : ptDualPow  - 中频数字,前向模拟俩功率结构指针
                 ulValidFlag - 功率是否有效标志
 *  返 回 值   : BSP_OK成功，其他值失败
 *  其它说明   : 返回失败时，或功率为无效值时，高层软件忽略此功率。
                 合并BspGetPowerValidFlag和BspGetTssiTcpw两个接口, 并考虑多线程访问互斥
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),  wangfei@2016-03-23 16:24:07, 创建
 *----------------------------------------------------------------------------
 *****************************************************************************/
UINT32 BspGetTssiTcpwFlag(UINT32 bspChn, UINT32 ulBand, T_TxDualPow *ptDualPow, UINT32 *ulValidFlag)
{
    INT32 iTmpData = 0;
    if ((NULL == ptDualPow) || NULL == ulValidFlag)
    {
        dbgInfo("%s Para Error : ulChannel = %d, ulValidFlag or ptDualPow = NULL\n",__FUNCTION__, bspChn);
        return BSP_ERROR_INVALID_PARA;
    }

    /* app 最快2s查询一次，bsp两次平均，每次80ms 这里等待200ms即可 */
    if (BSP_OK != semTake(g_semPowerUpdate[bspChn], 20))
    {
        dbgErr("%s TxChan%d PowerUpdate semTake fail!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    BspGetTxIfTssi(bspChn, ulBand, &iTmpData);
    ptDualPow->ifTssiPow = iTmpData;
    BspGetFwdCpIfTssi(bspChn, ulBand, &iTmpData);
    ptDualPow->fbPow = iTmpData;
    if(pGetPaProFlagCall != NULL)
    {
        *ulValidFlag = pGetPaProFlagCall(bspChn);
    }
    else
    {
        *ulValidFlag = BspGetTssiFlag(bspChn,ulBand,(UINT32 *)(&iTmpData));
    }

    semGive(g_semPowerUpdate[bspChn]);
    return BSP_OK;
}

UINT32 BspGetTssiTcpw(UINT32 chan, T_TxDualPow *fwd, T_TxDualPow *rev, UINT32 *num)
{
    UINT32 ulBand = 0;
    T_RruRfCfgInfo tRruCfgInfo = {0};

    if ((NULL == fwd) || (NULL == num) || (NULL== rev) ||(chan >= BSP_HALADAPT_IC_CHAN_MAX_NUM))
    {
        dbgInfo("%s Para Error : ulChannel = %d, or fwd = NULL\n",__FUNCTION__, chan);
        return BSP_ERROR_INVALID_PARA;
    }

    /* app 最快2s查询一次，bsp两次平均，每次80ms 这里等待200ms即可 */
    if (BSP_OK != semTake(g_semPowerUpdate[chan], 20))
    {
        dbgErr("%s TxChan%d PowerUpdate semTake fail!\n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    if (BSP_OK !=BspGetRruCfgPara(chan, &tRruCfgInfo))
    {
        semGive(g_semPowerUpdate[chan]);
        return BSP_ERROR;
    }

    if(BSP_OK != BspGetTxIfTssiFwdCpIfTssi(chan, ulBand, &fwd->ifTssiPow, &fwd->fbPow))
    {
        dbgErr("[%s] chan %d, GetTxIfTssiFwdCpIfTssi  Error!\n", __FUNCTION__, chan);
        semGive(g_semPowerUpdate[chan]);
        return BSP_ERROR;
    }
    dbgInfoEx("BspGetTssiTcpw ifTssiPow(%d),fbPow(%d)\n", fwd->ifTssiPow, fwd->fbPow);

    *num = 0;
    semGive(g_semPowerUpdate[chan]);
    return BSP_OK;
}


INT32 _BspGetPaBestVolt(UINT32 ulIndex, INT32 lPow)
{
    T_PaInfo tInfo = {0};
    INT32 ulBestVolt = 0;

    if (BSP_OK != BspGetPaBaseInfo(ulIndex, &tInfo))
    {
        return BSP_ERROR;
    }

    ulBestVolt = tInfo.ulPaBestVolt;
    return ulBestVolt;
}

void BspGetChnDbfs(UINT32 bspChn)
{
    UINT32 ulBand = 0;
    UINT32 retVal = BSP_OK;
    T_TxPow tPowDbfs = {0};
    ePowType powType = BSP_TSSI_FWD_INFO;

    BspSetPowAvgCnt(bspChn, 1);
    /* BspSetPcPowAvgCnt(bspChn, 1); */

    retVal |= GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    dbgInfo("Chan %d:FwdTssi=%d|FbFwd=%d|RevTssi=%d|FbRev=%d|isPowValid=%d\n",\
            bspChn, tPowDbfs.tFwdPow.ifTssiPow, tPowDbfs.tFwdPow.fbPow\
            ,tPowDbfs.tRevPow.ifTssiPow, tPowDbfs.tRevPow.fbPow\
            ,tPowDbfs.isPowValid);

    /* retVal |= GetTssiPowDbfs(bspChn, ulBand, pcPowType, &tPowDbfs);
    dbgInfo("Chan %d:PCFwdTssi=%d|PCFbFwd=%d|PCRevTssi=%d|PCFbRev=%d|isPowValid=%d\n",\
            bspChn, tPowDbfs.tFwdPow.ifTssiPow, tPowDbfs.tFwdPow.fbPow\
            ,tPowDbfs.tRevPow.ifTssiPow, tPowDbfs.tRevPow.fbPow\
            ,tPowDbfs.isPowValid); */
}
#if 0
UINT32 BspGetMaxCarrNum(UINT32 carrMode)
{
    UINT32 MaxCarrNum=0;

    switch(carrMode)
    {
        case BSP_RADIO_STANDARD_5G:
        case BSP_RADIO_STANDARD_LTE_FDD:
        case BSP_RADIO_STANDARD_LTE_TDD:
            MaxCarrNum = 8;
            break;
        case BSP_RADIO_STANDARD_GSM:
            MaxCarrNum = 8;
            break;
        case BSP_RADIO_STANDARD_NB_IOT:
            MaxCarrNum = 8;
            break;
        default:
            break;
    }
    return MaxCarrNum;
}

UINT32 BspGetCarrNumByBspChn(UINT32 dir, UINT32 bspChn, UINT32 *carrNum)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    UINT32 retVal = BSP_OK;
    T_BspAdaptOneChanCarrInfo *pDifCarrInfo = NULL;
    //T_BspAdaptOneChanCarrInfo *difCarrInfo = NULL;

    retVal = BspGetDifInfoByBspChn(bspChn, dir, &chipId, &difChan);
    if(BSP_OK != retVal)
    {
        dbgErr("[%s]bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    pDifCarrInfo = BspHalAdaptGetDifChanCarrInfo(TX, difChan);
    #if 0
    if (NULL == difCarrInfo)
    {
        dbgErr("[%s]difChan'%d difCarrInfo Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }

    memcpy_s(pDifCarrInfo, sizeof(pDifCarrInfo), difCarrInfo, sizeof(difCarrInfo));
    #endif
    if (NULL == pDifCarrInfo)
    {
        dbgErr("[%s]difChan'%d pDifCarrInfo Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }

    *carrNum = pDifCarrInfo->carrNum;
    if(*carrNum >= BSP_MAX_CARR_NUM)
    {
        dbgErr("%s carrNum = %d is error.\n",__FUNCTION__, *carrNum);
        return BSP_ERROR;
    }

    return retVal;
}
#endif
UINT32 BspGetSupportDivMode()
{
    UINT32 uDivMode = BSP_RADIO_STANDARD_GSM|BSP_RADIO_STANDARD_UMTS|BSP_RADIO_STANDARD_NB_IOT;
    return uDivMode;
}
#if 0
UINT32 BspGetAntennaVswrVal(UINT32 bspChn)
{
    UINT32 ulVswrValue = BSP_INVALID_VALUE;

    BspCalVswr(bspChn, 0, &ulVswrValue);
    dbgInfoEx("cal vswr chan=%d,vswr=%d\n",bspChn,ulVswrValue);

    return ulVswrValue;
}

T_ComplexNum ComplexAdd(T_ComplexNum x, T_ComplexNum y)
{
    T_ComplexNum z = {0};

    z.dRe = x.dRe + y.dRe;
    z.dIm = x.dIm + y.dIm;

    return z;

}

T_ComplexNum ComplexSub(T_ComplexNum x, T_ComplexNum y)
{
    T_ComplexNum z = {0};

    z.dRe = x.dRe - y.dRe;
    z.dIm = x.dIm - y.dIm;

    return z;

}

T_ComplexNum ComplexMluti(T_ComplexNum x, T_ComplexNum y)
{
    T_ComplexNum z = {0};

    z.dRe = x.dRe*y.dRe - x.dIm*y.dIm;
    z.dIm = x.dRe*y.dIm + x.dIm*y.dRe;

    return z;

}

T_ComplexNum ComplexConj(T_ComplexNum x)
{
    T_ComplexNum z = {0};

    z.dRe = x.dRe;
    z.dIm = -x.dIm;

    return z;

}

/* 计算中仅使用模值平方，此处先不开平方 */
DOUBLE ComplexAmp(T_ComplexNum x)
{
    DOUBLE z = 0.0;

    z = x.dRe*x.dRe + x.dIm*x.dIm;

    return z;

}

T_ComplexNum ComplexDiv(T_ComplexNum x, T_ComplexNum y)
{
    T_ComplexNum z    = {0};
    T_ComplexNum tmp  = {0};
    DOUBLE       dMod = 0.0;

    dMod = ComplexAmp(y);
    tmp  = ComplexConj(y);
    tmp  = ComplexMluti(x,tmp);
    if(dMod < 0.00000000001)
    {
        z.dRe = 0.0;
        z.dIm = 0.0;
    }
    else
    {
        z.dRe = tmp.dRe/dMod;
        z.dIm = tmp.dIm/dMod;
    }

    return z;

}

UINT32 BspGetVswrGamm(T_ComplexNum spa, T_ComplexNum S11, T_ComplexNum S22, T_ComplexNum St, T_ComplexNum* pGamm)
{
    T_ComplexNum tmp  = {0.0};
    T_ComplexNum tmp1 = {0.0};
    if(NULL == pGamm)
    {
        return BSP_ERROR;
    }
    /* gamm = (spa-s11)/((spa-s11)*s22+st) */
    tmp  = ComplexSub(spa, S11);
    tmp1 = ComplexMluti(tmp, S22);
    tmp1 = ComplexAdd(tmp1, St);
    *pGamm = ComplexDiv(tmp, tmp1);

    return BSP_OK;
}

static UINT32 s_uDpdVswrFlag = 0;

UINT32 dpdvswrtest(UINT32 uFlag)
{
    s_uDpdVswrFlag = uFlag;
    return BSP_OK;

}
/*****************************************************************************
*  函数名称   : BspGetVswrDataCollectStatus
*  功能描述   : 获取矢量驻波反射系数
*  读全局变量 :
*  写全局变量 :
*  输入参数   : uChan - 通道号，从0开始定义
*  输出参数   : pVswrTao - 矢量驻波反射系数
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 刘志敬@2012-05-18 15:21:07, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspGetVswrDataCollectStatus(UINT32 uChan)
{
    return BSP_OK;
}

/*****************************************************************************
*  函数名称   : BspGetVswrDataCollectStatus
*  功能描述   : 获取矢量驻波反射系数
*  读全局变量 :
*  写全局变量 :
*  输入参数   : ulTxChan - 通道号，从0开始定义
*  输出参数   : pVswrTao - 矢量驻波反射系数
*  返 回 值   :
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), 刘志敬@2012-05-18 15:21:07, 创建
*----------------------------------------------------------------------------
*/
UINT32 BspSwitchVswrDataCollect(UINT32 uChan, UINT32 uSwitch)
{
    return BSP_OK;
}

UINT32 GetVswrVal( UINT32 ulChan,UINT32 ulFreqBand, UINT32 *pScalVal, UINT32 *pVector)
{

    if (ulChan >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    if (NULL != pScalVal)
    {
        *pScalVal = s_VswrVal[ulChan][PA_VSWR_MODE];
        if(0==*pScalVal)
        {
            *pScalVal = BSP_INVALID_VALUE;
        }
    }

    if (NULL != pVector)
    {
        *pVector = s_VswrVal[ulChan][ANTENNA_VSWR_MODE];
        if(0==*pVector)
        {
            *pVector = BSP_INVALID_VALUE;
        }
    }

    return BSP_OK;
}
#endif
void powsw(UINT32 index, UINT32 powsw)
{
    g_ulPowCalcEnable[index] = powsw;
}

/*功率检测开关*/
UINT32 BspSetPowCalcSwitch(UINT32 chan, UINT32 sw)
{
    if (chan < BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        g_ulPowCalcEnable[chan] = sw;
    }

    return BSP_OK;
}

/*设置通道功率检测任务使能*/
UINT32 BspSetAllPowCalcSwitch(UINT32 sw)
{
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;

    for(loop = 0; loop < BspGetTxChannel(); loop++)
    {
        retVal |= BspSetPowCalcSwitch(loop, sw);
    }
    return retVal;
}

/* sw=1,ON,sw=0,OFF */
void powswall(UINT32 sw)
{
    UINT32 chan = 0;
    for(chan=0; chan < BSP_HALADAPT_IC_CHAN_MAX_NUM; chan++)
    {
        powsw(chan, sw);
    }
}

static UINT32 s_TempUpdateTimes = 0;
static UINT32 s_TempCompPeriod  = 8000; /* 温补任务默认按8s周期进行更新 */
static UINT32 s_PaDacCompPeriod  = 6000; /* 温补任务默认按6s周期进行更新 */
static UINT32 s_TempUpdatePeriod = 2000;   /* 定时器周期单位ms */
static UINT32 s_PaDacTempParaUpdateSwitch = TEMP_PARA_UPDATA_SWITCH_ON;
static UINT32 s_RxSwStop = SWITCH_OFF;

VOID BspSetTempParaUpdateDisable(VOID)
{
    s_PaDacTempParaUpdateSwitch = TEMP_PARA_UPDATA_SWITCH_OFF;
}

VOID stopRxSw(UINT32 sw)
{
    s_RxSwStop = sw;
}

UINT32 BspChkRxFarmPara(UINT32 bspChan, UINT32 carrMode)
{
    UINT32  radio = BSP_RADIO_STANDARD_LTE_FDD|RADIO_STANDARD_NB_IOT|BSP_RADIO_STANDARD_FDD_5G|BSP_RADIO_STANDARD_UMTS;

    if (SWITCH_ON == s_RxSwStop)
    {
        return BSP_ERROR;
    }

    if (LADAR_SCAN_RUNNING == BspLadarGetSampleSta(bspChan))
    {
        return BSP_ERROR;
    }

    if ((carrMode & radio) == 0)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

#define    RX_CARR_COEF_NORMAL    ((UINT32)4097)
#define    RX_CARR_COEF_ZERO      ((UINT32)0)
UINT32 BspRecovUlbankCoef(UINT32 difChan, UINT32 carrMode, UINT32 carrNo, UINT32 rxCoef)
{
    if (RX_CARR_COEF_ZERO == rxCoef)
    {
        BspHalAdaptSetUlbankAptuneCoef(difChan, carrNo, carrMode, RX_CARR_COEF_NORMAL);
        BspLog(LOG_LEVEL_0,"%s{%u,%u,%u,%u}RX Coef Reovery\n", __FUNCTION__, difChan, carrNo, carrMode, rxCoef);
    }
    return BSP_OK;
}

UINT32 BspClrUlbankCoef(UINT32 difChan, UINT32 carrMode, UINT32 carrNo, UINT32 rxCoef)
{
    if (RX_CARR_COEF_ZERO != rxCoef)
    {
        BspHalAdaptSetUlbankAptuneCoef(difChan, carrNo, carrMode, RX_CARR_COEF_ZERO);
        BspLog(LOG_LEVEL_0,"%s{%u,%u,%u,%u}RX Coef Zero\n", __FUNCTION__, difChan, carrNo, carrMode, rxCoef);
    }
    return BSP_OK;
}

UINT32 BspSetUlbankCoef(UINT32 bspChan, UINT32 carrMode, UINT32 carrNo)
{
    BOOL   ret = FALSE;
    UINT32  carrOn   = SWITCH_OFF;
    UINT32 difId     = 0;
    UINT32 difChan   = 0;
    UINT32  rxCoef = 0;

    if (BspChkRxFarmPara(bspChan, carrMode) != BSP_OK)
    {
        return BSP_ERROR;
    }

    if (BspGetDifInfoByBspChn(bspChan, RX, &difId, &difChan) != BSP_OK)
    {
        return BSP_ERROR;
    }

    ret = BspIsFarmValidRxChan(bspChan, carrMode);
    carrOn = BspGetFarmRxCarrSwitch(bspChan, carrMode, carrNo);
    BspHalAdaptGetUlbankAptuneCoef(difChan, carrNo, carrMode, &rxCoef);
    dbgInfoEx("%s bspChan=%u,carrNo=%u,carrMode=%u,validChan=%u,validCarr=%u,rxCoef=%u\n", __FUNCTION__, bspChan, carrNo, carrMode, ret, carrOn, rxCoef);

    if (!ret)
    {
        BspRecovUlbankCoef(difChan, carrMode, carrNo, rxCoef);
    }
    else
    {
        if (SWITCH_OFF == carrOn)
        {
            BspClrUlbankCoef(difChan, carrMode, carrNo, rxCoef);
        }
        else
        {
            BspRecovUlbankCoef(difChan, carrMode, carrNo, rxCoef);
        }
    }

    return BSP_OK;
}

UINT32 BspSetUlCarrGainFactor(UINT32 uBspChn, UINT32 uMode, UINT32 uCarrNo, UINT32 uFreq)
{
    INT32 rssiGain    = 0;
    INT32 lnaGain     = 0;
    UINT32 uRet       = BSP_OK;
    UINT32 difId      = 0;
    UINT32 difChan    = 0;
    UINT32 ulDifMode  = 0;
    UINT32 comptype = COMPS_BY_FREQ_POINT_TYPE;
    UINT32 retVal = 0;

    BspSetUlbankCoef(uBspChn, uMode, uCarrNo);

    if ( BspGetDifInfoByBspChn(uBspChn,RX,&difId,&difChan) != BSP_OK )
    {
        return BSP_ERROR;
    }

    uRet = BspGetRssiDbmCompGain(uBspChn, uMode, uFreq, 0, &rssiGain, comptype);
    if(BSP_OK != uRet)
    {
        return BSP_ERROR;
    }

    BspGetLnaGain(uBspChn, rssiGain, &lnaGain);

    if(BSP_OK == BspGetDifModeByRadioMode(uMode, &ulDifMode))
    {
        lnaGain +=  s_gRadioDetaGain[ulDifMode];
        dbgInfoEx("%s, difChan=%d uMode=%d radioGain=%d\n",__FUNCTION__,difChan, uMode, s_gRadioDetaGain[ulDifMode]);
    }

    retVal = BspHalAdaptSetRxVgaInherentGain(difChan,uMode,uCarrNo,lnaGain);
    dbgInfoEx("%s, difChan=%d uMode=%d uCarrNo=%d rssiGain=%d lnaGain=%d\n",__FUNCTION__,difChan, uMode, uCarrNo, rssiGain, lnaGain);

    return retVal;
}

UINT32 BspSetUlGainFactor(UINT32 uBspChn, UINT32 uMode, T_RruRfCfgInfo* pCarrInfo)
{
    UINT32 uMaxCarrNum = 0;
    UINT32 uIdx = 0;
    UINT32 uMaxFreq = 0;
    UINT32 uMInFreq = 0xFFFFFFFF;
    UINT32 uFreqTmp = 0;

    if(NULL == pCarrInfo)
    {
        return BSP_ERROR;
    }

    uMaxCarrNum = pCarrInfo->rxCfgCarrSum;

    if(uMaxCarrNum>BSP_MAX_CARR_NUM)
    {
        uMaxCarrNum = BSP_MAX_CARR_NUM;
    }

    if(BSP_RADIO_STANDARD_GSM == uMode)
    {
        for(uIdx = 0; uIdx < uMaxCarrNum;uIdx++)
        {
            if(uMode==pCarrInfo->carr[uIdx].carrRxRadio)
            {
                uFreqTmp = pCarrInfo->carr[uIdx].carrRxFreq + pCarrInfo->carr[uIdx].carrRxBw/2;
                if(uFreqTmp>uMaxFreq)
                {
                    uMaxFreq = uFreqTmp;
                }
                uFreqTmp = pCarrInfo->carr[uIdx].carrRxFreq - pCarrInfo->carr[uIdx].carrRxBw/2;
                if(uFreqTmp<uMInFreq)
                {
                    uMInFreq = uFreqTmp;
                }
                uFreqTmp = (uMaxFreq+uMInFreq) / 2; /* GSM载波只需要配置GSM载波中心拼点处的不常在值 */
                BspSetUlCarrGainFactor(uBspChn, uMode, pCarrInfo->carr[uIdx].carrRxNo, uFreqTmp);
            }
        }
    }
    else
    {
        for(uIdx = 0; uIdx < uMaxCarrNum;uIdx++)
        {
            if(uMode==pCarrInfo->carr[uIdx].carrRxRadio)
            {
                BspSetUlCarrGainFactor(uBspChn, uMode, pCarrInfo->carr[uIdx].carrRxNo, pCarrInfo->carr[uIdx].carrRxFreq);
            }
        }
    }


    return BSP_OK;
}

UINT32 BspSetChnUlGainFactor(UINT32 uBspChn)
{
    UINT32 uMode = 0;
    UINT32 uRet = BSP_OK;
    T_RruRfCfgInfo *pCarrInfo = NULL;
    T_ChanRfCfgPara *pRfCfg = NULL;

    pRfCfg = GetRfCfgPara(uBspChn,RX);
    if (NULL == pRfCfg)
    {
        dbgInfoEx("[%s]BspChan'%d pRfCfg Get Error!\n",__FUNCTION__, uBspChn);
        return BSP_ERROR;
    }
    if(pRfCfg->para.carrNum == 0)
    {
        return BSP_OK;
    }

    pCarrInfo = (T_RruRfCfgInfo *)malloc(sizeof(T_RruRfCfgInfo));
    if(NULL == pCarrInfo)
    {
        return BSP_ERROR;
    }
    if(BSP_OK != BspGetChnlCfgCarrPara(uBspChn,pCarrInfo))
    {
        free(pCarrInfo);
        return BSP_ERROR;
    }

    uMode = BspGetRadioStandard();

    if (uMode & BSP_RADIO_STANDARD_LTE_FDD)
    {
        uRet |= BspSetUlGainFactor(uBspChn, BSP_RADIO_STANDARD_LTE_FDD, pCarrInfo);
    }
    if (uMode & BSP_RADIO_STANDARD_FDD_5G)
    {
        uRet |= BspSetUlGainFactor(uBspChn, BSP_RADIO_STANDARD_FDD_5G, pCarrInfo);
    }

    if (uMode & BSP_RADIO_STANDARD_GSM)
    {
        uRet |= BspSetUlGainFactor(uBspChn, BSP_RADIO_STANDARD_GSM, pCarrInfo);
    }

    if (uMode & BSP_RADIO_STANDARD_UMTS)
    {
        uRet |= BspSetUlGainFactor(uBspChn, BSP_RADIO_STANDARD_UMTS, pCarrInfo);
    }

    if (uMode & BSP_RADIO_STANDARD_NB_IOT)
    {
        uRet |= BspSetUlGainFactor(uBspChn, BSP_RADIO_STANDARD_NB_IOT, pCarrInfo);
    }

    free(pCarrInfo);
    return uRet;
}

UINT32 BspUpdateUlGainFactor()
{
    UINT32 uChn = 0;
    UINT32 uRet = BSP_OK;

    for(uChn = 0; uChn < BspGetRxLogicChanNum(); uChn++)
    {
        uRet |= BspSetChnUlGainFactor(uChn);
    }
    return uRet;
}

static UINT32 BspSetMultyPaDacVolt(VOID)
{
    UINT32 retVal = 0;
    FUNC_GET_MULTY_PA_VIBAS_UPDATE pFuncPaVibas=NULL;

    pFuncPaVibas = BspGetMultyPaVibasUpdate();
    if (pFuncPaVibas != NULL)
    {
        retVal = pFuncPaVibas();
    }
    else
    {
        retVal = BspSetPaVibas(0);
    }

    return retVal;
}

/*温补参数更新*/
UINT32 BspTempParaUpdate()
{
    UINT32 retVal = BSP_OK;
    UINT32 uTimes = 0;

    if(0==s_TempUpdatePeriod)
    {
        s_TempUpdatePeriod = 1000;
    }

    uTimes = s_TempCompPeriod / s_TempUpdatePeriod;
    if(uTimes != 0)
    {
        if(0==s_TempUpdateTimes%uTimes)
        {
            BspUpdateUlGainFactor();
        }
    }

    if(TEMP_PARA_UPDATA_SWITCH_ON == s_PaDacTempParaUpdateSwitch)
    {
        uTimes = s_PaDacCompPeriod/s_TempUpdatePeriod;
        if(uTimes==0)
        {
            uTimes = 1;
        }
        if(0==s_TempUpdateTimes%uTimes)
        {
            retVal |= BspSetMultyPaDacVolt();
        }
    }
    s_TempUpdateTimes++;
    return retVal;
}

static UINT32 BspSetGsmStaticPowLevel(UINT32 bspChn, UINT16 val)
{
    if(bspChn >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    s_gsmStaticPowLevel[bspChn] = val;
    return BSP_OK;
}

UINT32 BspGetGsmStaticPowLevel(UINT32 bspChn, UINT16 *pVal)
{
    if(bspChn >= MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    if (pVal != NULL)
    {
        *pVal = s_gsmStaticPowLevel[bspChn];
    }
    else
    {
        dbgInfo("chan%d s_gsmStaticPowLevel=%d\n", bspChn, s_gsmStaticPowLevel[bspChn]);
    }
    return BSP_OK;
}

UINT32 BspSetPowLevel(UINT32 bspChn, UINT32 powLevel)
{
    UINT32 retVal       = BSP_OK;
    UINT32 loop         = 0;
    UINT32 chipId       = 0;
    UINT32 difChan      = 0;
    UINT32 radio        = 0;
    UINT32 carrNo       = 0;
    UINT16 levelGain    = 0;
    UINT32 powLevelTmp  = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    if (powLevel > STATIC_POW_LEVEL_MAX)
    {
        powLevel = STATIC_POW_LEVEL_MAX;
    }
    if(powLevel >= 2)
    {
        levelGain = ((powLevel - 1) * 2);
    }
    retVal |= BspGetDifInfoByBspChn(bspChn, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("[%s]bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }
    pRfCfg = GetRfCfgPara(bspChn,TX);
    if (NULL == pRfCfg)
    {
        dbgErr("[%s]difChan'%d pRfCfg Get Error!\n",__FUNCTION__, difChan);
        return BSP_ERROR;
    }
    if(powLevel == 0)
    {
        powLevelTmp = powLevel;
    }
    else
    {
        powLevelTmp = 1;
    }
    
    for(loop=0; loop < pRfCfg->para.carrNum; loop++)
    {
        radio = pRfCfg->para.carrInfo[loop].radioMode;
        carrNo = pRfCfg->para.carrInfo[loop].carrNo;
        if(radio != BSP_RADIO_STANDARD_GSM)
        {
            continue;
        }
        retVal |= BspHalAdaptSetGsmPowLevel(difChan,carrNo,powLevelTmp);
    }
    retVal |= BspSetGsmStaticPowLevel(bspChn, levelGain); /* recoard gsm static level used powcfg */
    BspLog(LOG_LEVEL_0,"%s:bspChn=%d powLevel=%d retVal=%d\n",__FUNCTION__,bspChn,powLevel,retVal);
    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspSetRxAnfCfg
 *  功能描述   : 设置ANF信息，包括ANF频点、带宽、通道号
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ptRxAnfCfg - 一个指针序列，每个指针指向一个ANF对象
                 ulCount    - 用于指示上述指针序列的有效长度，这样设计可以不用担心后续扩张
 *  输出参数   : 无
 *  返 回 值   : 成功或者失败
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A),王卓勇@2021.11.18 15: 03:35  创建
 *----------------------------------------------------------------------------
 */

UINT32 BspSetRxAnfCfg(T_RxAnfCfg* ptRxAnfCfg, UINT32 ulCount)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulLoopSrc=0;
    UINT32 ulLoopCarr=0;
    UINT32 ulCarrFound=0;
    UINT32 ulCarrNo=0;
    UINT32 radioMode = 0;
    UINT32 freq = 0;
    UINT32 bandWidth = 0;
    UINT32 ulChan=0;
    UINT32 ulChanLoop=0;
    UINT32 point =0;
    UINT32 ulChanFind[8][16]={0};
    UINT32 ulLeftFreq = 0;
    UINT32 ulRightFreq = 0;
    T_RxAnfCfg tRxAnfCfg[16]={0};   /* 用于存储从高层得到的干扰频点序列 */
    T_RruRfCfgInfo *tRruCfgInfo = NULL;
    T_RxAnfCarrCfg tRxAntCarrInfo[8][16] = {0};

    INPUT_POINTER_CHECK(ptRxAnfCfg);

    if(ulCount > 16)
    {
        dbgInfo("count %d exceed 16 ! \n", ulCount);
        return BSP_ERROR;
    }

    tRruCfgInfo = malloc(sizeof(T_RruRfCfgInfo));
    INPUT_POINTER_CHECK(tRruCfgInfo);

    memset_s(tRruCfgInfo, sizeof(T_RruRfCfgInfo), 0, sizeof(T_RruRfCfgInfo));
    memcpy_s(tRxAnfCfg,ulCount*sizeof(T_RxAnfCfg),ptRxAnfCfg,ulCount*sizeof(T_RxAnfCfg));

    /* 先全部清零，写入ANF模块控制字，并将使能标志位清除 */
    retVal = BspHalAdaptSetAnfClr();

    /* 根据FPGA的格式要求进行查找和计算 */
    for(ulLoopSrc=0;ulLoopSrc<ulCount;ulLoopSrc++)
    {
        ulChan = tRxAnfCfg[ulLoopSrc].ulRxChannel;
        dbgInfo("[ANF] Searching %d/%d Freq%d(%d)KHz in Ch%d\n",ulLoopSrc+1,ulCount,tRxAnfCfg[ulLoopSrc].ulFreqKHz,tRxAnfCfg[ulLoopSrc].ulWidthKHz,tRxAnfCfg[ulLoopSrc].ulRxChannel);
        BspLog(LOG_LEVEL_0, "[%s]:Searching %ld/%ld, Freq%ld, Bw'%ldKHz in Chan'%ld \n", __FUNCTION__, ulLoopSrc+1, ulCount,
                tRxAnfCfg[ulLoopSrc].ulFreqKHz, tRxAnfCfg[ulLoopSrc].ulWidthKHz, tRxAnfCfg[ulLoopSrc].ulRxChannel);

        /* 当没有任何载波配置的时候*/
        if(BspGetChnlCfgCarrPara(ulChan,tRruCfgInfo) != BSP_OK)
        {
            dbgInfo("count %d chan %d get para fail. \n", ulLoopSrc, tRxAnfCfg[ulLoopSrc].ulRxChannel);
            BspLog(LOG_LEVEL_0, "[%s]:count %d chan %d get para fail. %d \n", __FUNCTION__, ulLoopSrc, tRxAnfCfg[ulLoopSrc].ulRxChannel);
            continue;
        }

        /* 查找当前干扰频点位于哪个UMTS载波 */
        for(ulLoopCarr=0;ulLoopCarr<tRruCfgInfo->rxCfgCarrSum;ulLoopCarr++)
        {
            ulCarrFound = 0;
            ulCarrNo = tRruCfgInfo->carr[ulLoopCarr].carrRxNo;
            freq = tRruCfgInfo->carr[ulLoopCarr].carrRxFreq;
            bandWidth = tRruCfgInfo->carr[ulLoopCarr].carrRxBw;
            radioMode = tRruCfgInfo->carr[ulLoopCarr].carrRxRadio;

            ulLeftFreq = freq - bandWidth/2;
            ulRightFreq = freq + bandWidth/2;
            dbgInfo("[ANF] Carr%d(U:%d) %d~%d\n",ulLoopCarr, ulCarrNo, ulLeftFreq, ulRightFreq);
            BspLog(LOG_LEVEL_0, "[%s]: No%ld(carrNo:%ld)/%d, 0x%x, %ld~%ld \n", __FUNCTION__, ulLoopCarr, ulCarrNo, tRruCfgInfo->rxCfgCarrSum, radioMode, ulLeftFreq, ulRightFreq);
            if(BSP_RADIO_STANDARD_UMTS == radioMode)
            {
                if((tRxAnfCfg[ulLoopSrc].ulFreqKHz<=ulRightFreq) && (tRxAnfCfg[ulLoopSrc].ulFreqKHz>=ulLeftFreq))
                {
                    ulCarrFound = 1;
                    dbgInfo("[ANF] Found Freq%d at carr%d.\n",tRxAnfCfg[ulLoopSrc].ulFreqKHz,ulLoopCarr);
                    BspLog(LOG_LEVEL_0, "[%s]: Found Freq'%ld at chan'%d carr'%ld \n", __FUNCTION__, tRxAnfCfg[ulLoopSrc].ulFreqKHz, ulChan, ulCarrNo);
                }
            }

            /*如果没有查到载波信息，不返回错误*/
            if(0 ==ulCarrFound)
            {
                dbgInfo("[ANF] not find in chan %d.\n", tRxAnfCfg[ulLoopSrc].ulRxChannel);
                BspLog(LOG_LEVEL_0, "[%s]: not find at chan'%d carr'%ld \n", __FUNCTION__, ulChan, ulCarrNo);
                continue;
            }

            tRxAntCarrInfo[ulChan][ulCarrNo].atAnfFreqCfg[ulChanFind[ulChan][ulCarrNo]].iAnfFreq = tRxAnfCfg[ulLoopSrc].ulFreqKHz - freq;
            tRxAntCarrInfo[ulChan][ulCarrNo].atAnfFreqCfg[ulChanFind[ulChan][ulCarrNo]].uiAnfBw = tRxAnfCfg[ulLoopSrc].ulWidthKHz;

            ulChanFind[ulChan][ulCarrNo]++;
            tRxAntCarrInfo[ulChan][ulCarrNo].uiAnfFreqNum++;
        }
    }

    for(ulChanLoop=0; ulChanLoop<BspGetRxChannel(); ulChanLoop++)
    {
        for(ulCarrNo=0; ulCarrNo<16; ulCarrNo++)
        {
            if(ulChanFind[ulChanLoop][ulCarrNo] != 0)
            {
                retVal |= BspHalAdaptSetAnfCfg(ulChanLoop, ulCarrNo, BSP_RADIO_STANDARD_UMTS, &tRxAntCarrInfo[ulChanLoop][ulCarrNo]);
                for(point=0; point<tRxAntCarrInfo[ulChan][ulCarrNo].uiAnfFreqNum; point++)
                {
                    dbgInfoEx(" chan %d carr %d freq %d band %d\n", ulChanLoop,ulCarrNo,\
                            tRxAntCarrInfo[ulChan][ulCarrNo].atAnfFreqCfg[point].iAnfFreq,\
                            tRxAntCarrInfo[ulChan][ulCarrNo].atAnfFreqCfg[point].uiAnfBw);
                    BspLog(LOG_LEVEL_0, "[%s]:chan'%d, carrNo'%d, freq'%d, anfBw'%d \n", __FUNCTION__, ulChanLoop, ulCarrNo,\
                            tRxAntCarrInfo[ulChan][ulCarrNo].atAnfFreqCfg[point].iAnfFreq,\
                            tRxAntCarrInfo[ulChan][ulCarrNo].atAnfFreqCfg[point].uiAnfBw);
                }
            }
        }
    }

    free(tRruCfgInfo);

    return retVal;
}

/*****************************************************************************
 *  函数名称   : BspGetDl60msTagState(*)
 *  功能描述   : 查询下行60ms状态
 *  读全局变量 : 无
 *  写全局变量 : 无
 *  输入参数   : ulIndex    - 光口索引号, 0开始
 *  输出参数   : 无
 *  返 回 值   : 32个bit，每个bit对应一种状态。0表示正常，1表示异常。默认填0。
 *               Bit11-0：分别对应载波11－载波0 60ms告警
 *  其它说明   : GSM
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), wangfei@2010-11-8 11:49:54, 创建
 *----------------------------------------------------------------------------
 */
UINT32 BspGetDl60msTagState(UINT32 bspChn)
{
    UINT32 almData      = 0;
    UINT32 difChipId    = 0;
    UINT32 difChn       = 0;
    UINT32 ulLoopCarr    = 0;
    UINT32 carrTxNo     = 0;
    UINT32 carrAlam     = 0;
    UINT32 ulIqCfgFlag  = 0;

    T_ChanRfCfgPara *pRfCfg = NULL;

    pRfCfg = GetRfCfgPara(bspChn,TX);
    INPUT_POINTER_CHECK(pRfCfg);

    if( BspCheckTxChannel(bspChn)!= BSP_OK )
    {
        return BSP_ERROR;
    }

    if (BspGetDifInfoByBspChn(bspChn,TX,&difChipId,&difChn) != BSP_OK)
    {
        dbgErr("%s BspGetDifInfoByBspChn(%d,TX) return error\n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    for(ulLoopCarr=0;ulLoopCarr<pRfCfg->para.carrNum;ulLoopCarr++)
    {
        if(BSP_RADIO_STANDARD_GSM == pRfCfg->para.carrInfo[ulLoopCarr].radioMode)
        {
            carrTxNo = pRfCfg->para.carrInfo[ulLoopCarr].carrNo;
            if(BspHalAdaptGetGsmIqCfgFlag(bspChn,carrTxNo,BSP_RADIO_STANDARD_GSM,&ulIqCfgFlag) == BSP_OK)
            {
                dbgInfoEx("%s,bspChn=%u,carrTxNo=%u,IqCfgFlag %u \n",__FUNCTION__,bspChn,carrTxNo,ulIqCfgFlag);
                if(ulIqCfgFlag == 1)
                {
                    BspHalAdapt60msAlarm(difChn,carrTxNo,BSP_RADIO_STANDARD_GSM,&almData);
                    carrAlam |= ((almData&0x1)<<carrTxNo);
                }
            }
        }
    }
    if(0 != carrAlam)
    {
        BspLog(LOG_LEVEL_0,"%s:bspChn=%d carrAlam=%04x \n",__FUNCTION__,bspChn,carrAlam);
    }
    dbgInfoEx("%s,bspChn=%u,carrAlm=0x%x\n",__FUNCTION__,bspChn,carrAlam);
    return carrAlam;
}
/*****************************************************************************
*  函数名称   : BspSetRxShutSwitch(*)
*  功能描述   : 设置主分集接收开关
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : uChn:通道号
*          uSwitch:开关
*  输出参数   : 无
*  返 回 值   : BSP_OK:成功;其他:失败
*  其它说明   :
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A),  秦菲@2018-04-09 13:46:53   创建
*----------------------------------------------------------------------------
*/
UINT32 BspRxShutSwitchByCarr(UINT32 uChn, UINT32 ulCarr, UINT32 uSwitch)
{
    UINT32 difId    = 0;
    UINT32 difChan  = 0;

    if ( BspGetDifInfoByBspChn(uChn,RX,&difId,&difChan) != BSP_OK )
    {
        return BSP_ERROR;
    }
    return BspHalRxDataOffEn(difChan, ulCarr, BSP_RADIO_STANDARD_GSM, uSwitch);
}


static UINT32 ulTxCompCenterFreq[BSP_MAX_TX_CHAN][MAX_BAND_NUM]={0};

UINT32 BspGetTxCompCenterFreq(UINT32 bspChan, UINT32 ulFreqBand)
{
    if ((BspCheckTxChannel(bspChan)!= BSP_OK)||(ulFreqBand >= (MAX_BAND_NUM)))
    {
        dbgInfoEx("Para Error, ulChan = %d, ulFreqBand = %d\n", bspChan,ulFreqBand);
        return BSP_ERROR_INVALID_PARA;
    }
    return ulTxCompCenterFreq[bspChan][ulFreqBand];
}

UINT32 BspGetRevPowerAlm(UINT32 uChan)
{
    UINT32 retVal  = BSP_OK;
    UINT32 difId   = 0;
    UINT32 difChan = 0;
    UINT32 almSta  = 0;
    UINT32 enSta   = 0;

    if ( BspGetDifInfoByBspChn(uChan, TX, &difId, &difChan) != BSP_OK )
    {
        dbgInfo("%s: Bsp Get difChan failed. \n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspGetRevEnSta(difChan, &enSta);
    if (BSP_FLAG_INVALID == enSta)
    {
        dbgInfoEx("[%s]: Rev ProTect EnSta: chn'%u, ret'%d, enSta'%u. \n", __FUNCTION__, difChan, retVal, enSta);
        almSta = BSP_FLAG_INVALID;

        return almSta;
    }

    retVal |= BspRevAlarmStaRpt(difChan, &almSta);
    dbgInfoEx("[%s]: chn'%u, ret'%d, almSta'%u. \n", __FUNCTION__, difChan, retVal, almSta);

    return almSta;
}

UINT32 BspClearRevPowerAlm(UINT32 uChan)
{
    UINT32 retVal = BSP_OK;
    UINT32 difId = 0;
    UINT32 difChan = 0;

    if ( BspGetDifInfoByBspChn(uChan, TX, &difId, &difChan) != BSP_OK )
    {
        dbgInfo("%s: Bsp Get difChan failed. \n", __FUNCTION__);
        return BSP_ERROR;
    }

   retVal = BspRevAlarmClr(difChan);
    BspLog(LOG_LEVEL_0,"[%s]: chn'%u clear rev alarm.\n", __FUNCTION__, uChan);

    return retVal;
}

/* Started by AICoder, pid:v6fe2z7c11v04bd143500bead0584147aa44c8bb */
UINT32 BspGetRevPower(UINT32 chan, DOUBLE *pVal)
{
    UINT32 retVal = BSP_OK;
    UINT32 difId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(pVal);
    if(BspGetDifInfoByBspChn(chan, TX, &difId, &difChan) != BSP_OK )
    {
        dbgInfo("%s: Bsp Get difChan failed. \n", __FUNCTION__);
        return BSP_ERROR;
    }
    retVal = BspGetRevPowerRpt(difChan, pVal);
    BspLog(LOG_LEVEL_0,"[%s]: chn'%u clear rev alarm.\n", __FUNCTION__, chan);

    return retVal;
}
/* Ended by AICoder, pid:v6fe2z7c11v04bd143500bead0584147aa44c8bb */

UINT32 BspSetRevProtectGate(UINT32 chan, INT32 gate)
{
    UINT32 retVal = BSP_OK;
    UINT32 difId = 0;
    UINT32 difChan = 0;

    /* 通过和刘航、赵远志确认，FDD 和 TDD 机型允许配置的门限范围改为 [-27,-13]dbfs */
    if(gate < -270 || gate > -130)
    {
        dbgErr("[%s] Error, chn'%u gate('%d) out of range! \n",  __FUNCTION__, chan, gate);
        BspLog(LOG_LEVEL_0,"[%s] Error, chn'%u gate('%d) out of range! \n", __FUNCTION__, chan, gate);

        gate = gate < -270 ? -270 : -130;
    }

    if(BspGetDifInfoByBspChn(chan, TX, &difId, &difChan) != BSP_OK)
    {
        dbgErr("[%s] chan'%u get difChan error! \n", __FUNCTION__, chan);
        return BSP_ERROR;
    }

    retVal = BspSetRevWarnThr(difChan, gate);

    dbgInfoEx("[%s]: chn'%u, gate'%d, retVal'%d. \n", __FUNCTION__, chan, gate, retVal);
    BspLog(LOG_LEVEL_0,"[%s] chn'%u, gate'%d, retVal'%d.\n", __FUNCTION__, chan, gate, retVal);

    return retVal;
}

UINT32 BspGetRevProtectGate(UINT32 chan, INT32 *gate)
{
    UINT32 retVal = BSP_OK;
    UINT32 difId = 0;
    UINT32 difChan = 0;

    if(NULL == gate)
    {
        dbgErr("Input gate is NULL, Error!\n");
        return BSP_ERROR;
    }

    if ( BspGetDifInfoByBspChn(chan, TX, &difId, &difChan) != BSP_OK )
    {
        dbgErr("%s %d gate wrong %d\n", __FUNCTION__, __LINE__, *gate);
        return BSP_ERROR;
    }

    retVal = BspGetRevAlarmThr(chan, gate);
    dbgInfoEx("[%s]: chn'%u, gate'%d, retVal'%d. \n", __FUNCTION__, chan, *gate, retVal);

    return retVal;
}

UINT32 BspSaveRevDerateCfg(UINT32 bspChn, INT32 val)
{
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgErr("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }
    g_RevDerateVal[bspChn] = val;
    return BSP_OK;
}

UINT32 BspGetRevDerateCfg(UINT32 bspChn, INT32 *val)
{
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgErr("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(val);
    *val = g_RevDerateVal[bspChn];
    return BSP_OK;
}

UINT32 BspRevPowProtect(INT32 *gate,UINT32 chanNum)
{
    UINT32 retVal = BSP_OK;
    UINT32 difId = 0;
    UINT32 difChan = 0;
    UINT32 chan = 0;
    INT32 revgate = 0;
    UINT32 flag = 0;

    T_BspHalAdaptRevInit pRevCfg = {0};

    INPUT_POINTER_CHECK(gate);
    if(chanNum > BSP_HALADAPT_IC_CHAN_MAX_NUM)
    {
        dbgErr("[%s] chanNum is over max chan num!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    for(chan = 0;chan < BspGetTxChanNum();chan++)
    {
        if ( BspGetDifInfoByBspChn(chan, TX, &difId, &difChan) != BSP_OK )
        {
            dbgInfo("%s: Bsp Get difChan failed. \n", __FUNCTION__);
            return BSP_ERROR;
        }

        if(IS_NCR == BspIsNcr())
        {
            pRevCfg.RevEn  = 0;     /*Rev降额暂时屏蔽使能*/
        }
        else
        {
            pRevCfg.RevEn  = 1;     /*Rev降额使能*/
        }
        pRevCfg.DeltaRamp  = 256;   /*降额步进，默认256*/
        pRevCfg.RiseRamp   = 64;    /*恢复步进，默认64*/
        pRevCfg.DerateCoef = 2048;  /*降额系数，  默认2048*/
        pRevCfg.RevWarnThr = -200;  /*降额告警门限*/
        pRevCfg.PwrDownEn  = 0;     /*过流降额使能，0使能，1旁路，默认配置旁路*/
        /* Started by AICoder, pid:xf4eb341c0i41631469009da8012c505d685e886 */
        (void)BspGetRfBridgeChanFlag(difChan, &flag);
        if(BSP_RF_BRIDGE_FLAG == flag)
        {
            pRevCfg.DerateCoef = 2584;  /*降额系数，默认2048为6db，此处修改为4db*/
        }
        /* Ended by AICoder, pid:xf4eb341c0i41631469009da8012c505d685e886 */
        BspSetRevInit(difChan, &pRevCfg);
        revgate = gate[chan];
        retVal |= BspSetRevProtectGate(chan,revgate);/* 默认门限太小会导致上电直接告警，单板传递默认门限*/
        BspSetRefRevGate(chan,revgate);
        retVal |= BspClearRevPowerAlm(chan); /* 清除一次告警*/
    }
    return retVal;
}

/*****************************************************************************
*  函数名称   : BspJudgeRevProtectAlm
*  功能描述   : 判断反向功率是否大于保护门限
*  输入参数   : bspChn   - BSP通道号
*  输出参数   : almFlag: 1:rev(dbfs)大于门限; 0:未超过门限
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 若反向功率加6db大于保护门限,则认为有告警,否则无告警
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 2023-04-28
*----------------------------------------------------------------------------
*/
UINT32 BspJudgeRevProtectAlm(UINT32 bspChn, UINT32 *almFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 ulBand = 0;
    INT32 revDbfs = 0;
    INT32 revGate = 0;
    INT32 revDerateVal = REV_PRO_ATTENUATION_VALUE;
    ePowType powType = BSP_TSSI_FWD_INFO;
    T_TxPow tPowDbfs = {0};

    INPUT_POINTER_CHECK(almFlag);

    retVal |= GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
    retVal |= BspGetRevProtectGate(bspChn, &revGate);
    /* 获取的dbfs功率单位是0.01dbfs，快衰值需要乘以100后参与计算 */
    if (BSP_OK != BspGetRevDerateCfg(bspChn, &revDerateVal))
    {
        dbgInfoEx("%s, get rev derate cfg err -_-!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    revDbfs = tPowDbfs.tRevPow.fbPow + (revDerateVal * 100);

    /* IC配置门限单位是0.1dbfs，需要乘以10后才与dbfs读取功率比较 */
    if (revDbfs > (revGate * 10))
    {
        *almFlag = BSP_FLAG_VALID;
    }
    else
    {
        *almFlag = BSP_FLAG_INVALID;
    }

    dbgInfoEx("[%s]: chn'%d, fastFall'%d, fbPow'%d, revDbfs'%.2lf > revGate'%.1lf ?, almFlag'%u. \n",
            __FUNCTION__, bspChn, revDerateVal, tPowDbfs.tRevPow.fbPow, revDbfs/100.0, revGate/10.0,*almFlag);

    return retVal;
}

/*****************************************************************************
*  函数名称   : BspGetRevProEnSta
*  功能描述   : 获取IC的REV降额使能状态
*  输入参数   : bspChn   - BSP通道号
*  输出参数   : sta: 1:使能; 0:未使能
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 无
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A), 2023-04-28
*----------------------------------------------------------------------------
*/
UINT32 BspGetRevProEnSta(UINT32 bspChn, UINT32 *sta)
{
    UINT32 retVal = BSP_OK;
    UINT32 difId = 0;
    UINT32 difChan = 0;

    INPUT_POINTER_CHECK(sta);

    if (BspGetDifInfoByBspChn(bspChn, TX, &difId, &difChan) != BSP_OK)
    {
        dbgInfo("%s: Bsp Get difChan failed. \n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspGetRevEnSta(difChan, sta);

    dbgInfoEx("[%s]: App get EnSta: chn'%d, status'%u. \n", __FUNCTION__, bspChn, *sta);

    return retVal;
}

UINT32 BspSetRevEn(UINT32 bspChan, UINT32 en)
{
    UINT32 difChan = 0;
    UINT32 chipId  = 0;
    UINT32 retVal  = BSP_OK;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    return HalSetRevEn(difChan, en);
}

UINT32 BspSetRevDerateCoefCfg(UINT32 bspChan, INT32 derateCoefDbfs)
{
    UINT32 difChan = 0;
    UINT32 chipId  = 0;
    UINT32 retVal  = BSP_OK;
    UINT32 derateCoef = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    derateCoef = (UINT32)GAIN_TO_REG(derateCoefDbfs,4096);

    return HalRevDerateCoefCfg(difChan, derateCoef);
}

UINT32 BspSetRevDeltaRampCfg(UINT32 bspChan, UINT32 deltaRamp)
{
    UINT32 difChan = 0;
    UINT32 chipId  = 0;
    UINT32 retVal  = BSP_OK;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    return HalRevDeltaRampCfg(difChan,deltaRamp);
}

UINT32 BspSetRevRiseRampCfg(UINT32 bspChan, UINT32 riseRamp)
{
    UINT32 difChan = 0;
    UINT32 chipId  = 0;
    UINT32 retVal  = BSP_OK;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }
    return HalRevRiseRampCfg(difChan, riseRamp);
}

UINT32 BspSetTxCompCenterFreq(UINT32 bspChan, UINT32 ulFreqBand, UINT32 ulFreq)
{
    UINT32 ulRet = BSP_OK;
    if ((BspCheckTxChannel(bspChan)!= BSP_OK)||(ulFreqBand >= (MAX_BAND_NUM)))
    {
        dbgInfoEx("Para Error, ulChan = %d, ulFreqBand = %d\n", bspChan,ulFreqBand);
        return BSP_ERROR_INVALID_PARA;
    }

    ulTxCompCenterFreq[bspChan][ulFreqBand]= ulFreq;
    return ulRet;
}

/**************************************************************************
 * 函数名称:IntPub_UnitFunc_DifCfrGetTssi
 * 功能描述:获取cfr后tssi功率值
 * 输入参数: ulChipIndex   - DPD IC索引号(0:主片,1--16:从片编号)
 *           ulDifChn      - IC通道号(0--3)
 * 输出参数: pdTssiDbc     - tssi功率值
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年10月25日 1233  qinfei    创建
 **************************************************************************/
UINT32 BspDifCfrGetTssi(UINT32 ulChn, DOUBLE *pdTssiDbc)
{
    UINT32 ulRet = BSP_OK;
    INT32 lDbf = 0;
    UINT32 ulType = E_TARGET_DBFS_TX;

    INPUT_POINTER_CHECK(pdTssiDbc);

    lDbf = (INT32)_BspGetDlPowDefPara(ulChn, ulType);
    *pdTssiDbc = 10.0 * log10((DOUBLE)((1 << 13) * (1 << 13))) + (DOUBLE)(lDbf / 100.0);
    dbgInfoEx("pdTssiDbc = %f\n",*pdTssiDbc);

    return ulRet;
}

/**************************************************************************
 * 函数名称:IntPub_UnitFunc_DifCfrGetPathPARByTssi
 * 功能描述:根据tssi获取峰均比值
 * 输入参数: ulChipIndex   - DPD IC索引号(0:主片,1--16:从片编号)
 *           ulDifChn      - IC通道号(0--3)
 *           dTssiDbc      - tssi功率值
 * 输出参数: pPARVal       - 计算的峰均比结果
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年10月25日 1233  qinfei    创建
 **************************************************************************/
UINT32 BspGetPathPARByTssi(UINT32 ulChipIndex, UINT32 ulDifChn, DOUBLE dTssiDbc, DOUBLE * pPARVal)
{
    UINT32 ulRet = BSP_OK;
    UINT32 aulCfrGate[3] = {3500,3500,3500};
    INPUT_POINTER_CHECK(pPARVal);

    //ulRet = BspGetCfrGatePara(ulDifChn,&aulCfrGate[0]);

    dbgInfoEx("aulCfrGate = %d %d %d\n",aulCfrGate[0],aulCfrGate[1],aulCfrGate[2]);
    if((BSP_OK==ulRet)&&(aulCfrGate[2]>0))
    {
        *pPARVal = 20*log10(((DOUBLE)aulCfrGate[2])/1.6465)-dTssiDbc+0.2;
    }
    else
    {
        ulRet = BSP_ERROR;
    }
    return ulRet;
}
/**************************************************************************
 * 函数名称:BspGetPathPAR
 * 功能描述:获取峰均比值
 * 输入参数: ulChipIndex   - DPD IC索引号(0:主片,1--16:从片编号)
 *           ulDifChn      - IC通道号(0--3)
 *           dTssiDbc      - tssi功率值
 * 输出参数: pPARVal       - 计算的峰均比结果
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2016年10月25日 1233  qinfei    创建
 **************************************************************************/
UINT32 BspGetPathPAR(UINT32 ulChn,UINT32 ulBand, DOUBLE * pPARVal)
{
    UINT32 ulChip    = 0;
    UINT32 ulDifChan = 0;
    /* UINT32 ulDifBand = 0; */
    DOUBLE dTssiDbc = 0.0;
    UINT32 ulRet     = BSP_OK;
    ulRet = BspGetDifInfoByBspChn(ulChn,TX,&ulChip,&ulDifChan);
    ulRet |= BspDifCfrGetTssi(ulChn,&dTssiDbc);
    if(BSP_OK == ulRet)
    {
        ulRet = BspGetPathPARByTssi(ulChip,ulDifChan,dTssiDbc,pPARVal);
    }
    return ulRet;
}

UINT32 BspGetPaTempDelta(INT32 *plPaTempDelta)
{
    INPUT_POINTER_CHECK(plPaTempDelta);

    *plPaTempDelta = salPaTempDelta;
    return BSP_OK;
}

UINT32 BspSetPaTempDelta(INT32 lPaTempDelta)
{
    salPaTempDelta = lPaTempDelta ;
    return BSP_OK;
}

UINT32 BspGetDflTxInsertLoss(UINT32  ulChan, UINT32 ulBand)
{

    if (ulChan >= BSP_MAX_TX_CHAN)
    {
        return 0;
    }
    return salDflTxInsertLoss[ulChan];
}

UINT32 BspSetDflTxInsertLoss(UINT32 ulChan, UINT32 ulTxInsertLoss)
{
    salDflTxInsertLoss[ulChan] = ulTxInsertLoss;
    return BSP_OK;
}

UINT32 BspGetPaDefaultVolt(UINT32 ulChan,UINT32 *pVolt)
{
    INPUT_POINTER_CHECK(pVolt);
    if (ulChan >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    *pVolt = salPaVolt[ulChan];
    dbgInfoEx("ulChan= %d pVolt = %d\n",ulChan,*pVolt);
    return BSP_OK;
}

UINT32 BspSetPaDefaultVolt(UINT32 ulChan,UINT32 Volt)
{
    salPaVolt[ulChan] = Volt;
    return BSP_OK;
}


UINT32 BspSetFddPaGain(UINT32 chanNo, INT32 gain)
{
    TBL_CHAN_VALID_CHECK(chanNo);
    glDraCaliPaGain[chanNo] = gain;
    return BSP_OK;
}

UINT32 BspGetFddPaGain(UINT32 chanNo, INT32 *pGain)
{
    TBL_CHAN_VALID_CHECK(chanNo);
    INPUT_POINTER_CHECK(pGain);
    *pGain = glDraCaliPaGain[chanNo];
    return BSP_OK;
}

/* 静态调压的削峰门限系数根据档位获取 */
UINT32 BspGetCfrParaByCfgPow(INT32 lCfgPowerDbm, INT32 lRatePowerDbm, float fGateCoef, DOUBLE *pCfrPara)
{
    INPUT_POINTER_CHECK(pCfrPara);

    if(((lRatePowerDbm - 155) < lCfgPowerDbm) && (lCfgPowerDbm <= lRatePowerDbm))  //[100%，70%）档位
    {
        *pCfrPara = 1.0 * fGateCoef;
    }
    else if(((lRatePowerDbm - 300) < lCfgPowerDbm) && (lCfgPowerDbm <= (lRatePowerDbm - 155)))  //[70%，50%）档位
    {
        *pCfrPara = sqrt(0.7)*pow(10.0,0.05) * fGateCoef;
    }
    else if(((lRatePowerDbm - 523) < lCfgPowerDbm) && (lCfgPowerDbm <= (lRatePowerDbm - 300)))  //[50%，30%）档位
    {
        *pCfrPara = sqrt(0.5)*pow(10.0,0.075) * fGateCoef;
    }
    else if(((lRatePowerDbm - 1000) < lCfgPowerDbm) && (lCfgPowerDbm <= (lRatePowerDbm - 523)))  //[30%，10%）档位
    {
        *pCfrPara = sqrt(0.3)*pow(10.0,0.075) * fGateCoef;
    }
    else if((0 < lCfgPowerDbm) && (lCfgPowerDbm <= (lRatePowerDbm - 1000)))  //10%以下
    {
        *pCfrPara = sqrt(0.1)*pow(10.0,0.2) * fGateCoef;
    }
    else
    {
        dbgInfoEx("[%s] ERROR No scene!\n", __FUNCTION__);
    }

    return BSP_OK;
}

/*削峰门限的系数计算新方案*/
UINT32 BspGetCfrGateParaByPower(UINT32 bspChn, UINT32 ulCfgPowerMw, UINT32 ulRatePowerMw, DOUBLE *pCfrPara)
{
    UINT32 ulRet = BSP_OK;
    INT32 lCfgPowerDbm = 0;
    INT32 lRatePowerDbm = 0;
    UINT32 ulPaOutPowMw = 0;
    UINT32 ulRefPowMw = 0;
    float fGateCoef = 0.0;
    *pCfrPara = 1.0;
    T_RruRfModuleInfoNew tRfModuleInfo = {0};

    INPUT_POINTER_CHECK(pCfrPara);

    ulRet = BspGetRruRfModuleInfoNew(bspChn, &tRfModuleInfo);
    ulPaOutPowMw = tRfModuleInfo.ulRuAntTxMaxPower;

    ulPaOutPowMw = (ulPaOutPowMw > ulRatePowerMw) ? ulRatePowerMw : ulPaOutPowMw;

    if (0 == (ulCfgPowerMw && ulRatePowerMw && ulPaOutPowMw))
    {
        dbgInfoEx("[%s] ERROR! ulCfgPowerMw:%d, ulRatePowerMw:%d, ulPaOutPowMw:%d \n",
                __FUNCTION__, ulCfgPowerMw, ulRatePowerMw, ulPaOutPowMw);
        return BSP_ERROR;
    }

    ulRefPowMw = (ulPaOutPowMw < ulRatePowerMw) ? ulPaOutPowMw : ulRatePowerMw;

    dbgInfoEx("[%s] chan:%u, ulRatePowerMw:%u, ulPaOutPowMw:%u, ulCfgPowerMw:%u \n",
                __FUNCTION__, bspChn, ulRatePowerMw, ulPaOutPowMw, ulCfgPowerMw);

    if((ulPaOutPowMw < ulCfgPowerMw) && (ulCfgPowerMw <= ulRatePowerMw))
    {
        *pCfrPara = sqrt((ulCfgPowerMw * 1.0) / ulRatePowerMw);
        dbgInfoEx("[%s] chan:%u, *pCfrPara:%.4lf \n", __FUNCTION__, bspChn, *pCfrPara);
        return BSP_OK;
    }
    else
    {
        fGateCoef = sqrt((ulPaOutPowMw * 1.0) / ulRatePowerMw);
    }

    lCfgPowerDbm  = (INT32)(1000.0 * log10((DOUBLE)ulCfgPowerMw) + 0.5);
    lRatePowerDbm  = (INT32)(1000.0 * log10((DOUBLE)ulRefPowMw) + 0.5);

    ulRet |= BspGetCfrParaByCfgPow(lCfgPowerDbm, lRatePowerDbm, fGateCoef, pCfrPara);

    dbgInfoEx("[%s] chan:%u, lRatePowerDbm:%d, lCfgPowerDbm:%d, fGateCoef:%.4lf, *pCfrPara:%.4lf \n",
            __FUNCTION__, bspChn, lRatePowerDbm, lCfgPowerDbm, fGateCoef, *pCfrPara);

    return ulRet;
}


UINT32 BspGetPaGainByVolt(UINT32 ulChanSel, UINT32 ulBand, UINT32 ulPaVolt, UINT32 ulCfgPower,DOUBLE *pCfrPara, INT32 *ulPaGain)
{
    UINT32 parLevel      = 0;
    UINT32 powerLevel    = 0;
    UINT32 vdsLevel      = 0;
    UINT32 freqLevel     = 0;
    UINT32 dataIndex     = 0;
    UINT32 freq          = 0;
    UINT32 vbiasTypeNum     = 0;
    UINT32 vgsDeltaNum   = 0;
    UINT32 paGainPos     = 0;
    UINT32 chanNo        = ulChanSel;
    UINT32 pwrAvgRat     = 0;
    DOUBLE par           = 0;
    UINT32 ulRet     = BSP_OK;
    INT32   lPowMw = 0;
    UINT32  ulRatePow = 0;
    UINT32  ulCfgDbm = 0;
    UINT32 ulDflTxInsertLoss = 0;
    UINT32 tblIndex = 0;
    UINT32 tblChn = chanNo;
    INT32  pwrLevelMw   = 0;

     ulDflTxInsertLoss = BspGetDflTxInsertLoss(chanNo,ulBand);
     ulCfgDbm = (ULONG)(1000.0*log10((DOUBLE)ulCfgPower)+0.5);
     ulCfgDbm += ulDflTxInsertLoss;

    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    INPUT_POINTER_CHECK(ulPaGain);
    TBL_CHAN_VALID_CHECK(ulChanSel);

    BspUpdateRfTblIndexAndChn(chanNo, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    vbiasTypeNum  = ptEnSavAdjData->atEnSavAdjPath[tblChn].vbiasTypeNum;
    vgsDeltaNum   = ptEnSavAdjData->atEnSavAdjPath[tblChn].vgsDeltaNum;
    if(vbiasTypeNum == 0 || vgsDeltaNum == 0)
    {
        dbgInfo("--%s--(%d): vbiasTypeNum and vgsDeltaNum are wrong.\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }
    paGainPos = vbiasTypeNum + vgsDeltaNum;

    freq        = BspGetMultiCarrCenterFreq(TX, chanNo);
    ulRet       = BspGetPathPAR(ulChanSel,ulBand,&par);
    if((ulRet== BSP_ERROR) || (freq==BSP_ERROR))
    {
        return BSP_ERROR;
    }

    pwrAvgRat     = (LONG)((par>0)?(par*10.0+0.5):(par*10.0-0.5));

    dbgInfoEx("chan %d par %d freq %d \n", chanNo, pwrAvgRat, freq);

    parLevel    = BspGetParLevelByFile(pwrAvgRat,chanNo);
    freqLevel   = BspGetFreqLevelByFile(freq,chanNo);
    powerLevel  = BspGetPowerLevelByFile(ulCfgDbm,chanNo);
    vdsLevel    = BspGetVdsLevelByFile(ulPaVolt,ulChanSel);

    /*D42规避静态调压tptl超额问题，后期正式方案落地后底层回退*/
    if(powerLevel>2)
    {
        powerLevel = 2;
    }

    dataIndex   = BspGetCombiIndex(parLevel, vdsLevel, freqLevel,chanNo);

    dbgInfoEx("chanNo[%d]: par[%d], ulPaVolt [%d] power[%d] freq[%d] data[%d]\n", chanNo, parLevel, vdsLevel, powerLevel, freqLevel, dataIndex);

    if ((dataIndex >= EN_SAV_ADJ_MAX_ROW) || (powerLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) ||
        (freqLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        dbgInfoEx("--%s--(%d): chanNo[%d]: par[%d], power[%d] freq[%d] data[%d]\n", __FUNCTION__, __LINE__, chanNo, parLevel, powerLevel, freqLevel, dataIndex);
        return BSP_ERROR;
    }

    *ulPaGain = ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[parLevel].combiItem[dataIndex][paGainPos];
    glDraCaliPaGain[ulChanSel] = *ulPaGain;
    dbgInfoEx("PaGain[%d]\n", *ulPaGain);

    ulRet = BspGetPowerUpByFile(ulCfgDbm, ulChanSel,&lPowMw);

    BspGetRruPathRatedPower(ulChanSel,&ulRatePow);
    /* Started by AICoder, pid:xbb4c778a48585f141b308dcd014b5161cf4a060 */
    if(1 == BspGetTFCommonPowerFlag())
    {
        BspGetPowerUpByFileByLevel(0, ulChanSel, dataIndex, &pwrLevelMw);
        BspGetCfrGateParaByPower(ulChanSel, pwrLevelMw, ulRatePow, pCfrPara);
        dbgInfoEx("dataIndex=%d pwrLevelMw=%d ulRatePow=%d pCfrPara=%lf\n",dataIndex,pwrLevelMw,ulRatePow,*pCfrPara);
        return BSP_OK;
    }
    /* Ended by AICoder, pid:xbb4c778a48585f141b308dcd014b5161cf4a060 */
    if(0!=ulRatePow)
    {
        BspGetCfrGateParaByPower(ulChanSel, ulCfgPower, ulRatePow, pCfrPara);
    }

    dbgInfoEx("ulCfgPower=%d ulRatePow=%d pCfrPara=%lf\n",ulCfgPower,ulRatePow,*pCfrPara);

    return BSP_OK;
}

UINT32 BspGetPaVoltByCfgPower(UINT32 ulChanSel, UINT32 ulBand, UINT32 ulCfgPower,UINT32 ulVoltFlag,UINT32 *pVolt, DOUBLE *pCfrPara, INT32 *ulPaGain)
{
    UINT32 powerLevel = 0;
    UINT32  ulCfgDbm = 0;
    UINT32 ulDflTxInsertLoss = 0;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    INPUT_POINTER_CHECK(ulPaGain);
    TBL_CHAN_VALID_CHECK(ulChanSel);
    UINT32 tblIndex = 0;
    UINT32 tblChn = ulChanSel;
    INT32 bestvolt = 0;
    INT32 delt = 0;
    UINT32 retVal = BSP_OK;

    if (1==ulVoltFlag)/*动态调压*/
    {
        ulCfgDbm = ulCfgPower;
    }
    else
    {
        ulDflTxInsertLoss = BspGetDflTxInsertLoss(ulChanSel,ulBand);
        ulCfgDbm = (ULONG)(1000.0*log10((DOUBLE)ulCfgPower)+0.5);
        ulCfgDbm += ulDflTxInsertLoss;
    }

    BspUpdateRfTblIndexAndChn(ulChanSel, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    powerLevel = BspGetPowerLevelByFile(ulCfgDbm,ulChanSel);
    INPUT_PARAM_RANGE_CHECK(powerLevel, PA_ENERGY_SAVING_ADJ_MAX_LEVEL);

    *pVolt = ptEnSavAdjData->atEnSavAdjPath[tblChn].vdsLevel[powerLevel];
    if(SUPP_REDUCE_PA_VOLT == BspGetReducePaVoltFlag())
    {
        retVal = BspGetPaBestVolt(ulChanSel, &bestvolt);
        if(BSP_OK == retVal)
        {
            delt = BspGetPaVoltDelt();
            bestvolt += delt;
            if(*pVolt > bestvolt)
            {
                *pVolt = bestvolt;
            }
        }
    }

    dbgInfoEx("[%s]ulCfgPower=%d, ulCfgDbm=%d, powerLevel=%d, pVolt=%d\n", __FUNCTION__, ulCfgPower, ulCfgDbm, powerLevel, *pVolt);
    return BSP_OK;
}

VOID showfddpagain()
{
    UINT32 chan = 0;
    for(chan = 0; chan < CHAN_MAX_NUM_SOC; chan++)
    {
        dbgInfo("pa[%d] gain:%d\n", chan, glDraCaliPaGain[chan]);
    }
}

/*****************************************************************************
*  函数名称   : BspAdpGetPwrVoltLimitUp
*  功能描述   : 获取电源输出至PA的调压最大值
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 电源编号ulIndex?e
*  输出参数   : 电压最大值pValue
*  返 回 值   : 成功或者失败
*  其它说明   : 根据硬件信息返回用户电压调整参数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), shiqaio@2017-05-19 08:33:43, create
*----------------------------------------------------------------------------
*/
UINT32 BspAdpGetPwrVoltLimitUp(UINT32 ulIndex, UINT32 *pVoltUp)
{
    UINT32  ulRet  = BSP_OK;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    UINT32 tblIndex = 0;
    UINT32 tblChn = ulIndex;

    BspUpdateRfTblIndexAndChn(ulIndex, TBL_PAENSAVADJ, &tblIndex, &tblChn);
     ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);


    INPUT_POINTER_CHECK(pVoltUp);

    *pVoltUp = ptEnSavAdjData->atEnSavAdjPath[tblChn].vdsLevel[0];
    dbgInfoEx("ulIndex %d pVoltUp %d \n",ulIndex,*pVoltUp);

    return ulRet;
}

/*****************************************************************************
*  函数名称   : BspAdpGetPwrVoltLimitDown
*  功能描述   : 获取电源输出至PA的最小电压
*  读全局变量 : 无
*  写全局变量 : 无
*  输入参数   : 电源编号ulIndex?e
*  输出参数   : 电压最小值pValue
*  返 回 值   : 成功或者失败
*  其它说明   : 根据硬件信息返回用户电压调整参数
*----------------------------------------------------------------------------
* 历史记录(变更单, 责任人@修改日期, 操作说明)
*  $0000000(N/A), shiqaio@2017-05-19 08:33:43, create
*----------------------------------------------------------------------------
*/
UINT32 BspAdpGetPwrVoltLimitDown(UINT32 ulIndex, UINT32 *pVoltDown)
{
    UINT32  ulRet  = BSP_OK;
    UINT32  vdsNum = 0;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    UINT32 tblIndex = 0;
    UINT32 tblChn = ulIndex;

    BspUpdateRfTblIndexAndChn(ulIndex, TBL_PAENSAVADJ, &tblIndex, &tblChn);
     ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);
    INPUT_POINTER_CHECK(pVoltDown);

    vdsNum = ptEnSavAdjData->tEnSavAdjHeader.vdsNum;
    if((vdsNum >= 1)&&(vdsNum < PA_ENERGY_SAVING_ADJ_MAX_LEVEL + 1))
    {
        *pVoltDown = ptEnSavAdjData->atEnSavAdjPath[tblChn].vdsLevel[vdsNum-1];
    }
    dbgInfoEx("ulIndex %d pVoltDown %d \n",ulIndex,*pVoltDown);

    return ulRet;
}

/*****************************************************************************
*  函数名称   : BspSetFwdDbmDelta
*  功能描述   : 设置FWD和REV的dbm模拟功率调整量
*  输入参数   : bspChn   - BSP通道号
               delta    - 功率调整量, 单位0.01db
*  输出参数   : 无
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 1) 基于功率美化需求; APP配频第一步配置给BSP调整量
               2) dbfs不调整; delta值需加到FWD和REV的模拟dbm功率上
*----------------------------------------------------------------------------
*/
UINT32 BspSetFwdDbmDelta(UINT32 bspChn, INT32 delta)
{
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgErr("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    s_fwdPowMwDelta[bspChn] = delta;

    return BSP_OK;
}

UINT32 BspGetFwdDbmDelta(UINT32 bspChn, INT32 *delta)
{
    INPUT_POINTER_CHECK(delta);
    if (bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        dbgErr("[%s] bspChn[%u] out of range!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    *delta = s_fwdPowMwDelta[bspChn];;

    return BSP_OK;
}

UINT32 BspSetNbicSwitch(UINT32 bspChn, UINT32 carrNo, UINT32 sw)
{
    UINT32 ulRet = BSP_OK;
    UINT32 chipidx = 0;
    UINT32 difChn = 0;
    UINT32 swStatus = 0xffffffff;
    static UINT8 uNbicFlag = 0;

    ulRet = BspGetDifInfoByBspChn(bspChn, RX, &chipidx, &difChn);
    if (BSP_OK != ulRet)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        BspLog(LOG_LEVEL_0,"[%s] bspChn'%d BspGetDifInfoByBspChn Get Error! \n",__FUNCTION__,bspChn);
        return BSP_ERROR;
    }

    ulRet |= BspHalAdaptGetNbicSwitch(difChn, carrNo, BSP_RADIO_STANDARD_UMTS, &swStatus);

    if (sw != swStatus)
    {
        ulRet |= BspHalAdaptSetNbicSwitch(difChn, carrNo, BSP_RADIO_STANDARD_UMTS, sw);
    }
    /*NBIC起控门限只配置一次*/
    if(0 == uNbicFlag)
    {
        uNbicFlag = 1;
        ulRet |= BspSetNbicThredInit();
    }
    BspLog(LOG_LEVEL_0,"[%s] bspChn'%d, carrNo'%d, swApp'%d, swHal'%d, ulRet'%d \n",__FUNCTION__,bspChn,carrNo,sw,swStatus,ulRet);

    return ulRet;
} 

UINT32 BspGetNbicSwitch(UINT32 bspChn, UINT32 carrNo, UINT32 *sw)
{
    UINT32 ulRet = BSP_OK;
    UINT32 chipidx = 0;
    UINT32 difChn = 0;
    UINT32 carr = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    INPUT_POINTER_CHECK(sw);

    ulRet = BspGetDifInfoByBspChn(bspChn, RX, &chipidx, &difChn);
    if (BSP_OK != ulRet)
    {
        dbgErr("%s>>bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChn, RX);
    if (NULL == pRfCfg)
    {
        dbgInfo("[%s]BspChan'%d pRfCfg Get Error!\n",__FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    for (carr = 0; carr < BSP_MAX_CARR_NUM; carr++)
    {
        if(carr >= pRfCfg->para.carrNum)
        {
            dbgInfoEx("[%s]BspChan'%d not find carr %d !\n",__FUNCTION__, bspChn, carrNo);
            ulRet = BSP_ERROR;
            break;
        }
        if((pRfCfg->para.carrInfo[carr].radioMode == BSP_RADIO_STANDARD_UMTS) && (pRfCfg->para.carrInfo[carr].carrNo == carrNo))
        {
            ulRet = BspHalAdaptGetNbicSwitch(difChn, carrNo, BSP_RADIO_STANDARD_UMTS, sw);
            break;
        }
    }
    return ulRet;
} 

/*****************************************************************************
*  函数名称   : BspGetNbicIq
*  功能描述   : 获取UMTS上行NBIC采数的IQ
*  输入参数   : bspChn - BSP通道号
               carrNo - UMTS载波号
               iqLen  - 高层需要获取的IQ数组长度
*  输出参数   : pusIq  - IQ数据, 数据点的I和Q紧挨间隔排列
               psCompDbX10 - U载波补偿增益,单位0.1db,用于高层计算对齐天线口rssi功率
                    psCompDbX10 = (-rssiGain - 9031) / 10; 9031为D42功率的位宽值
                    10log(求和(I平方+Q方)/采数点数) -> db值;
                    db值 - 90.31db -> dbfs值;
                    dbfs值 - rfGain -> dbm值
*  返 回 值   : BSP_OK  - 成功;其它值为失败
*  其它说明   : 高层调用; 在IC中频最多采集4096个点,每个数据点的高低16bit分别为I和Q
*----------------------------------------------------------------------------*/
UINT32 BspGetNbicIq(UINT32 bspChn, UINT32 carrNo, UINT16* pusIq, UINT16 iqLen, INT16* psCompDbX10)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipidx = 0;
    UINT32 difChn = 0;
    UINT32 loop = 0;
    UINT32 sampDataLen = (UINT32)(iqLen / 2);
    UINT32 sampDataIQ[NBIC_SAMPLE_DATA_LEN] = {0};
    INT32 rssiGain = 0;
    UINT32 carrFreq = 0;
    UINT32 uIdx = 0;
    T_ChanRfCfgPara *pRfCfg = NULL;

    if (VALID_RX_CHAN(bspChn) || (iqLen > NBIC_SAMPLE_DATA_LEN * 2))
    {
        dbgInfoEx("[%s] Err Para. Rxchan:%u, iqLen:%u \n", __FUNCTION__, bspChn, iqLen);
        return BSP_ERROR_INVALID_PARA;
    }
    INPUT_POINTER_CHECK(pusIq);
    INPUT_POINTER_CHECK(psCompDbX10);

    retVal |= BspGetDifInfoByBspChn(bspChn, RX, &chipidx, &difChn);
    if (BSP_OK != retVal)
    {
        dbgInfoEx("[%s] bspChan'%d to difChn Error!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    pRfCfg = GetRfCfgPara(bspChn, RX);
    if (NULL == pRfCfg)
    {
        dbgInfoEx("[%s] bspChn'%d pRfCfg Get Error!\n", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    retVal |= BspCarrInfoMatching(carrNo, BSP_RADIO_STANDARD_UMTS, pRfCfg, &uIdx);
    if(BSP_OK != retVal)
    {
        dbgInfoEx("[%s] BspCarrInfoMatching is Error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if(pRfCfg->para.carrNum == uIdx)
    {
        dbgInfoEx("[%s] uIdx = %d, No Find CarrInfo!\n", __FUNCTION__, uIdx);
        return BSP_ERROR;
    }

    carrFreq = pRfCfg->para.carrInfo[uIdx].freq;
    retVal |= BspGetRssiDbmCompGain(bspChn, BSP_RADIO_STANDARD_UMTS, carrFreq, 0, &rssiGain, COMPS_BY_FREQ_POINT_TYPE);
    retVal |= BspHalAdaptGetNbicIq(difChn, carrNo, BSP_RADIO_STANDARD_UMTS, sampDataLen, sampDataIQ);

    for (loop = 0; loop < iqLen; loop += 2)
    {
        *(pusIq + loop)     = (UINT16)((sampDataIQ[loop / 2] & 0xFFFF0000) >> 16);
        *(pusIq + loop + 1) = (UINT16)(sampDataIQ[loop / 2] & 0x0000FFFF);
        dbgInfoEx("[%s] loop:%-4u, sampData:0x%08x, I:0x%04x(%-5u), Q:0x%04x(%u) \n", __FUNCTION__,
                loop, sampDataIQ[loop / 2], *(pusIq + loop), *(pusIq + loop), *(pusIq + loop + 1), *(pusIq + loop + 1));
    }

    *psCompDbX10 = (INT16)((-9031 - rssiGain) / 10);  /* 9031为D42功率计算的位宽值 */
    dbgInfoEx("[%s] chan'%u, carrNo'%u, uIdx'%u, carrFreq'%u, rssiGain:%d, CompDbX10:%d(uint:0.1db) \n",
                __FUNCTION__, bspChn, carrNo, uIdx, carrFreq, rssiGain, *psCompDbX10);

    return retVal;
}

/*Nbic抵消检测门限设置*/
UINT32 BspSetNbicThredInit(VOID)
{
    UINT32 uRet = 0;
    UINT32 uChan = 0;
    UINT32 caliChn = 0;
    UINT32 bandLoop = 0;
    UINT32 bandNum = 0;
    UINT32 centerFreq = 0;
    UINT32 freqStart = 0;
    UINT32 freqEnd = 0;
    INT32  rssiGainTemp  = 0;
    INT32  rssiGainMin  = 9031;
    INT32  rssiGainThr  = 0;

    /*遍历整机上行所有通道、频段，取最小增益配置*/
    for(uChan=0; uChan<BspGetRxChannel(); uChan++)
    {
        uRet = BspGetCaliChnByRfChn(uChan, RX, &caliChn);
        if(BSP_OK != uRet)
        {
            caliChn = uChan;
        }
        bandNum = BspGetFreqBandCnts(caliChn, RX);

        for(bandLoop = 0; bandLoop < bandNum; bandLoop ++)
        {
            uRet |= BspGetFreqInfoByBandNum(uChan, RX, bandLoop, &freqStart, &freqEnd);
            centerFreq = (freqStart + freqEnd)/2;
            uRet |= BspGetRssiDbmCompGain(uChan, BSP_RADIO_STANDARD_LTE_FDD, centerFreq, 0, &rssiGainTemp, COMPS_BY_FREQ_POINT_TYPE);
            dbgInfoEx("[%s] chand %u band %u rxGain  %d\n ", __FUNCTION__, uChan, bandLoop, rssiGainTemp);
            if(rssiGainTemp < rssiGainMin)
            {
                rssiGainMin = rssiGainTemp;
            }
        }
    }

    /*T+F机型上行定标方案，上行增益按目标增益配置*/
    if(MODE_ONLY_TDD_FDD == BspGetFddTddCoExistSta())
    {
        uRet |= _BspGetRxChanTargetGain_Base(0,0,&rssiGainMin);
    }
    rssiGainThr = 9031 + rssiGainMin - 9900;/*系统方案设计按105底噪-6dB=99dB作为起控门限,9031为中频计算dbfs固定计算*/
    uRet |= BspHalAdaptSetNbicPowThr(rssiGainThr);

    BspLog(LOG_LEVEL_0,"%s  rssiGainMin = %d\n",__FUNCTION__, rssiGainThr);
    return uRet;
}

UINT32 BspClearAllDtxDly(VOID)
{
    return BSP_OK;
}

UINT32 BspInitPowShareModule(VOID)
{
    T_PowerSharerModule *powShareModule = NULL;

    powShareModule = (T_PowerSharerModule *)BspGetPowerShareModuleInfo();
    INPUT_POINTER_CHECK(powShareModule);

    powShareModule->powerShareFunc.pRefreshCpg = BspRefreshCfrCpgTbl;

    return BSP_OK;
}


// 获取子端的单板温度
UINT32 BspGetSlaveBoardTemp(UINT32 index, INT32 *pTemp)
{
    UINT32 retVal = 0;
    UINT32 portId = 0;
    UINT32 portSta = 0;

    INPUT_POINTER_CHECK(pTemp);
    retVal = BspGetPortIdByBspChn(index, TX, &portId);
    retVal |= BspGetSlavePortCfgSta(portId, &portSta);
    if((BSP_OK != retVal)||(LINK_OK != portSta))
    {
        return retVal;
    }
    retVal = BspGetRfsDevBoardTemp(portId, pTemp);
    dbgInfoEx("bspchan %d portId %d portSta %d *pTemp %d\n", index, portId, portSta, *pTemp);

    return retVal;
}

/*获取子端的pa温度*/
UINT32 BspGetSlavePaTemp(UINT32 bspChn, INT32 *pTemp)
{
    UINT32 retVal = 0;
    UINT32 portId = 0;
    UINT32 slaveChn = 0;
    UINT32 portSta = 0;

    INPUT_POINTER_CHECK(pTemp);
    retVal = BspGetPortIdByBspChn(bspChn, TX, &portId);
    retVal |= BspGetPortSlaveChnByBspChn(bspChn, TX, &slaveChn);
    retVal |= BspGetSlavePortCfgSta(portId, &portSta);
    if((BSP_OK != retVal)||(LINK_OK != portSta))
    {
        return retVal;
    }
    retVal = BspGetRfsDevPaTemp(portId, slaveChn, pTemp);
    dbgInfoEx("bspchan %d portId %d portType %d pTemp %d\n", bspChn, portId, portSta, *pTemp);

    return retVal;
}

UINT32 BspGetRfDectorAdVolt(UINT32 bspChn, UINT32 type, UINT32 *pAdVal, INT32 *paTemp, UINT8 *pValidFlag)
{
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pAdVal);
    INPUT_POINTER_CHECK(paTemp);
    INPUT_POINTER_CHECK(pValidFlag);
    if(NULL!= pGetSlaveRfDectorAdVolt)
    {
        return pGetSlaveRfDectorAdVolt(bspChn, type, pAdVal, paTemp, pValidFlag);
    }
    return retVal;
}

/*获取子端通道通过检波电路获取的fwd值 查表读取*/
UINT32 BspGetSlavePowInfoByRfDector(UINT32 bspChn, UINT32 dir, UINT32 type, UINT32 *pPowDbm)
{
    UINT32 powDbm = 0;
    UINT32 retVal = 0;

    INPUT_POINTER_CHECK(pPowDbm);
    retVal = BspGetSlavePowDbmGain(bspChn, dir, type, &powDbm); /*查表 +子端温补 = 功率值*/
    *pPowDbm = powDbm;

    return retVal;
}

UINT32 BspGetSlaveFwdByRfDector(UINT32 bspChn,  UINT32 *pFwdDbm)
{
    INPUT_POINTER_CHECK(pFwdDbm);
    return BspGetSlavePowInfoByRfDector(bspChn, TX, 0, pFwdDbm);
}

UINT32 BspGetSlaveRevByRfDector(UINT32 bspChn,  UINT32 *pRevDbm)
{
    INPUT_POINTER_CHECK(pRevDbm);
    return BspGetSlavePowInfoByRfDector(bspChn, RX, 0,pRevDbm);
}

UINT32 BspGetSlaveFwdDbfs(UINT32 bspChn, INT32 *pDbfs)
{
    UINT32 retVal = BSP_OK;
    T_TxPow powDbfs = {0};

    INPUT_POINTER_CHECK(pDbfs);
    retVal = BspGetPowDbfs(bspChn, 0, &powDbfs);
    *pDbfs = powDbfs.tFwdPow.fbPow;
    dbgInfo("chan %d pDbfs %d\n", bspChn, *pDbfs);
    BspLog(LOG_LEVEL_0, "BspGetSlaveFwdDbfs chan %d pDbfs %d\n", bspChn, *pDbfs);

    return retVal;
}

/*计算前向和反馈的插损*/
UINT32 BspCalcFwdSlaveCableLoss(UINT32 chan, UINT32 freq, INT32 *pLoss)
{
    INT32 fwdDbfs = 0;
    UINT32 retVal = BSP_OK;
    INT32 fwdGain = 0;
    UINT32 fwdDbm= 0;

    INPUT_POINTER_CHECK(pLoss);
    retVal =  BspGetSlaveFwdDbfs(chan, &fwdDbfs);
    _BspGetFwdDbmGain(chan, &fwdGain, COMPS_BY_FREQ_POINT_TYPE);
    retVal |= BspGetSlaveFwdByRfDector(chan, &fwdDbm);
    if(BSP_OK != retVal)
    {
        dbgErr("BspCalcFwdSlaveCableLoss get failed\n");
        if(0 == fwdDbm)
        {
            *pLoss = BSP_INVALID_VALUE;    /*特殊值通知高层 高层直接当失败，此时子端异常或者校准表异常*/
        }
        return BSP_ERROR;
    }
    *pLoss = fwdDbfs - fwdDbm -  fwdGain;
    dbgInfo("BspCalcFwdSlaveCableLoss chan %d freq %d fwdDbfs %d fwdDbm %d fwdGain %d loss %d\n", chan, freq, fwdDbfs, fwdDbm, fwdGain, *pLoss);
    BspLog(LOG_LEVEL_0,"BspCalcFwdSlaveCableLoss chan %d freq %d fwdDbfs %d fwdDbm %d fwdGain %d loss %d\n", chan, freq, fwdDbfs, fwdDbm, fwdGain, *pLoss);

    return retVal;
}

UINT32 BspCalcTxSlaveCableLoss(UINT32 chan, UINT32 freq, INT32 *pLoss)
{
    UINT32 retVal = BSP_OK;
    INT32 txGain = 0;
    UINT32 fwdDbm= 0;
    INT32 attval = 0;
    INT32 paGain = 0;
    INT32 dsaVal = 0;

    INPUT_POINTER_CHECK(pLoss);
    retVal = BspGetSlaveFwdByRfDector(chan, &fwdDbm);
    if(BSP_OK != retVal)
    {
        dbgErr("SlaveFwd ByRfDector get failed\n");
        if(0 == fwdDbm)
        {
            *pLoss = BSP_INVALID_VALUE;    /*特殊值通知高层 高层直接当失败，此时子端异常或者校准表异常*/
        }
        return BSP_ERROR;
    }
    BspGetTxAtt(chan,&attval);
    retVal = BspGetTxPreOpenLoopGain(chan, freq, &txGain); /*targetGain - fix.comps*/
    *pLoss = fwdDbm + 1400 - txGain - attval;
    BspGetPaGain(chan, &paGain);  /*txgain是正数值 静态调压增益算进去的时候是加paGain 注意50v---35v paGain从0变成负数*/
    BspGetSlaveDsaAtt(chan, TX, &dsaVal);
    dbgInfo("BspCalcTxSlaveCableLoss chan %d freq %d fwdDbm %d txGain %d attval %d loss %d paGain %d dsaVal %d\n", chan, freq, fwdDbm, txGain, attval, *pLoss, paGain, dsaVal);
    BspLog(LOG_LEVEL_0,"BspCalcTxSlaveCableLoss chan %d freq %d fwdDbm %d txGain %d attval %d loss %d  paGain %d dsaVal %d\n", chan, freq, fwdDbm, txGain, attval, *pLoss, paGain, dsaVal);

    return retVal;
}
/*保存中间过程计算的插损值 按通道 方向 频点记录*/
UINT32 BspSaveSlaveCableLoss(UINT32 chan, UINT32 dir, UINT32 freq, INT32 loss)
{
    T_CableLossRecord *pTmpData = NULL;
    UINT32 loop = 0;
    INT32 bdtemp = 0;

    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
         return BSP_ERROR;
    }
    if(TX == dir)
    {
        pTmpData = &g_ulTxRfCableLoss[chan];
    }
    else
    {
        pTmpData = &g_ulPrxRfCableLoss[chan];
    }
    BspGetBoardTemp(chan,&bdtemp);
    dbgInfoEx("%s chan %d dir %d cnt %d\n", __FUNCTION__, chan, dir, pTmpData->cnt);
    BspLog(LOG_LEVEL_0,"%s chan %d dir %d cnt %d\n", __FUNCTION__, chan, dir, pTmpData->cnt);
    for(loop = 0; loop < pTmpData->cnt; loop++)
    {
        if(loop >= MAX_SLAVE_FREQ_POINT)
        {
            return BSP_ERROR;
        }
        dbgInfo("loop %d freq %d loss %d temp %d\n", loop, pTmpData->freq[loop], pTmpData->loss[loop], pTmpData->temp[loop]);
        BspLog(LOG_LEVEL_0,"BspSaveSlaveCableLoss old loop %d freq %d loss %d cabletemp %d\n", loop, pTmpData->freq[loop], pTmpData->loss[loop], pTmpData->temp[loop]);
        if(pTmpData->freq[loop] == freq)
        {
            pTmpData->loss[loop] = loss;   /*对已有的频点进行修改*/
            pTmpData->temp[loop] = bdtemp-SLAVE_CABLE_DELT_TEMP;   /*系统定义馈线温度=母端单板温度-39°*/
            break;
        }
    }
    if(loop == pTmpData->cnt)
    {
        if(loop < MAX_SLAVE_FREQ_POINT-1)
        {
            pTmpData->cnt++;
            pTmpData->freq[loop] = freq;   /*新增频点记录*/
            pTmpData->loss[loop] = loss;
            pTmpData->temp[loop] = bdtemp-SLAVE_CABLE_DELT_TEMP;   /*系统定义馈线温度=母端单板温度-39°*/
            BspLog(LOG_LEVEL_0,"BspSaveSlaveCableLoss new loop %d freq %d loss %d cabletemp %d\n", loop, pTmpData->freq[loop], pTmpData->loss[loop], pTmpData->temp[loop]);
        }
        else
        {
           dbgErr("chan %d freq cnt is over MAX_SLAVE_FREQ_POINT \n", chan);
           return BSP_ERROR;
        }
    }

    return BSP_OK;
}

/*针对子端重新上电 清除上一次流程保存的测试数据*/
UINT32 BspClrSlaveSlavedTestData(UINT32 chan)
{
    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
         return BSP_ERROR;
    }
    memset_s(&g_ulTxRfCableLoss[chan], sizeof(T_CableLossRecord), 0, sizeof(T_CableLossRecord));
    memset_s(&g_ulPrxRfCableLoss[chan], sizeof(T_CableLossRecord), 0, sizeof(T_CableLossRecord));
    g_ulSlaveScalarVswr[chan] = BSP_INVALID_VALUE;
    g_ulCableLossBaseTemp[chan] = SLAVE_CABLE_BASE_TEMP*10;    /* 子端重新上电预开环需要保证没有温补 环境温度不可能200度 以这个值作为子端重新上电标志*/

    return BSP_OK;
}

/*预开环或者遍历频点计算插损 同时保存结果*/
UINT32 BspCalcSlaveCableLoss(UINT32 chan, UINT32 dir, UINT32 freq, INT32 *pLoss)
{
    UINT32 retVal = BSP_OK;

    if(TX == dir)
    {
        retVal = BspCalcTxSlaveCableLoss(chan, freq, pLoss);
    }
    else
    {
        retVal = BspCalcFwdSlaveCableLoss(chan, freq, pLoss);

    }
    retVal |= BspSaveSlaveCableLoss(chan, dir, freq, *pLoss);

    return retVal;
}

/*APP在判断插损结果是成功2还是失败8的时候：才组合看三者的状态——当前通道的时延是否成功，当前通道的前向插损是否有效，当前通道的反馈插损是否有效，然后只有三者都有效，才返回2，任何一个无效  都 返回8（这里不涉及因功放保护失败返回4*/
UINT32 isAppLossVaild(UINT32 result)
{
    if(0 == result)   /*方便修改 高层2 */
    {
        return BSP_OK;
    }
    return BSP_ERROR;
}

/*此接口的结果实际是给最后算前向的dsa时使用的*/
UINT32 BspGetSlaveCableLossInfoByApp(UINT32 chan, UINT32 *pType, UINT32 *pIndex, double *pCoef)
{
    UINT32 chnReult0 = 0;
    UINT32 chnReult1 = 0;
    UINT32 retVal = BSP_OK;
    UINT32 otherChn = 0;
    UINT32 slaveChn = 0;

    INPUT_POINTER_CHECK(pType);
    INPUT_POINTER_CHECK(pIndex);
    INPUT_POINTER_CHECK(pCoef);
    retVal = BspGetAnotherSlaveChnByBspChn(chan, TX, &otherChn);
    retVal |= BspGetPortSlaveChnByBspChn(chan, TX, &slaveChn);
    if(BSP_OK != retVal)
    {
         return BSP_ERROR;
    }
    BspGetCableLossVaildFlag(chan, RX, &chnReult0);
    BspGetCableLossVaildFlag(otherChn, RX, &chnReult1);
    dbgInfoEx("%s chan %d otherChn %d selfslaveChn %d chnReult0 %d chnReult1 %d\n", __func__, chan, otherChn, slaveChn, chnReult0, chnReult1);
    BspLog(LOG_LEVEL_0, "%s chan %d otherChn %d selfslaveChn %d  chnReult0 %d chnReult1 %d\n",__func__, chan, otherChn, slaveChn,  chnReult0, chnReult1);
    if((BSP_OK == isAppLossVaild(chnReult0)) && (BSP_OK == isAppLossVaild(chnReult1)))    /*两个通道都正常时 取另一个通道的反馈数据当本通道的前向*/
    {
        *pType = PRX;
        *pIndex = otherChn;
        *pCoef = 1.0;
        return BSP_OK;
    }
    else if(BSP_OK == isAppLossVaild(chnReult0))    /*当前通道正常 另一通道不正常*/
    {
        if(0 == slaveChn)   /*通道0正常通道1异常 当前是通道0*/
        {
            *pType = PRX;
            *pIndex = chan;
            *pCoef = 19.0/22.5;    /*通道0的前向 =通道0的反馈*19.0/22.5*/
            return BSP_OK;
        }
        else                /*通道1正常通道0异常 当前是通道1*/
        {
            *pType = PRX;
            *pIndex = chan;
            *pCoef = 22.5/19.0;    /*通道1的前向 =通道1的反馈*22.5/19*/
            return BSP_OK;
        }
    }
    else if(BSP_OK == isAppLossVaild(chnReult1))   /*当前通道不正常 另一通道正常*/
    {   /*通道0异常通道1正常 当前是通道0 则通道0的前向 =通道1的反馈  通道1异常通道0正常 当前是通道1，则通道1的前向 =通道0的反馈*/

        *pType = PRX;
        *pIndex = otherChn;
        *pCoef = 1.0;     /*通道0的前向 =通道1的反馈*/
        return BSP_OK;
    }
    else
    {
        return BSP_ERROR;
    }
}
/*结合时延测量结果 插损测量有戏性 判断通道插损的计算方式和转换系数*/
UINT32 BspGetSlaveCableLossInfo(UINT32 chan, UINT32 *pType, UINT32 *pIndex, double *pCoef)
{
    UINT32 dlyReult0 = 0;
    UINT32 dlyReult1 = 0;
    UINT32 prxReult0 = 0;
    UINT32 prxReult1 = 0;
    UINT32 txReult0 = 0;
    UINT32 txReult1 = 0;
    UINT32 retVal = BSP_OK;
    UINT32 otherChn = 0;
    UINT32 slaveChn = 0;

    retVal = BspGetAnotherSlaveChnByBspChn(chan, TX, &otherChn);
    retVal |= BspGetPortSlaveChnByBspChn(chan, TX, &slaveChn);
    if(BSP_OK != retVal)
    {
         return BSP_ERROR;
    }
    BspGetRfCableDlyResult(chan, &dlyReult0);
    BspGetRfCableDlyResult(otherChn, &dlyReult1);
    BspGetCableLossVaildFlag(chan, PRX, &prxReult0);
    BspGetCableLossVaildFlag(otherChn, PRX, &prxReult1);
    BspGetCableLossVaildFlag(chan, TX, &txReult0);
    BspGetCableLossVaildFlag(otherChn, TX, &txReult1);
    dbgInfoEx("chan %d otherChn %d selfslaveChn %d\n", chan, otherChn, slaveChn);
    BspLog(LOG_LEVEL_0, "chan %d otherChn %d selfslaveChn %d\n", chan, otherChn, slaveChn);
    dbgInfoEx("dlyReult0 %d dlyReult1 %d prxReult0 %d prxReult1 %d txReult0 %d txReult1 %d\n",
               dlyReult0, dlyReult1, prxReult0, prxReult1, txReult0, txReult1);
    BspLog(LOG_LEVEL_0, "dlyReult0 %d dlyReult1 %d prxReult0 %d prxReult1 %d txReult0 %d txReult1 %d\n",
            dlyReult0, dlyReult1, prxReult0, prxReult1, txReult0, txReult1);
    if((BSP_OK == dlyReult0)||(BSP_OK == dlyReult1))  /*同一子端有一个听到时延测量正常就认为ok*/
    {
         if(BSP_OK == prxReult0 + prxReult1)    /*反馈都正常时 取另一个通道的反馈数据当本通道的前向*/
         {
             *pType = PRX;
             *pIndex = otherChn;
             *pCoef = 1.0;
             return BSP_OK;
         }
         else if(BSP_OK == prxReult0)    /*当前通道正常 另一通道不正常*/
         {
             if(0 == slaveChn)   /*通道0正常通道1异常 当前是通道0*/
             {
                 *pType = PRX;
                 *pIndex = chan;
                 *pCoef = 19.0/22.5;    /*通道0的前向 =通道0的反馈*19.0/22.5*/
                 return BSP_OK;
             }
             else                /*通道1正常通道0异常 当前是通道1*/
             {
                 *pType = PRX;
                 *pIndex = chan;
                 *pCoef = 22.5/19.0;    /*通道1的前向 =通道1的反馈*22.5/19*/
                 return BSP_OK;
             }
         }
         else if(BSP_OK == prxReult1)   /*当前通道不正常 另一通道正常*/
         {   /*通道0异常通道1正常 当前是通道0 则通道0的前向 =通道1的反馈  通道1异常通道0正常 当前是通道1，则通道1的前向 =通道0的反馈*/

             *pType = PRX;
             *pIndex = otherChn;
             *pCoef = 1.0;     /*通道0的前向 =通道1的反馈*/
             return BSP_OK;
         }
         else
         {
               if(BSP_OK == txReult0 + txReult1)
               {
                   *pType = TX;
                   *pIndex = chan;
                   *pCoef = 1.0;
                   return BSP_OK;
               }
               else if(BSP_OK == txReult0)   /*本通道TX正常 另一通道异常 取本通道的前向*/
               {
                   *pType = TX;
                   *pIndex = chan;
                   *pCoef = 1.0;
                   return BSP_OK;
               }
               else if(BSP_OK == txReult1)   /*本通道TX不正常 另一通道正常*/
               {
                   if(0 == slaveChn)   /*通道0不正常通道1正常 当前是通道0*/
                   {
                       *pType = TX;
                       *pIndex = otherChn;
                       *pCoef = 19.0/22.5;   /*通道0的前向= 通道1的前向*19/22.5*/
                       return BSP_OK;
                   }
                   else                /*通道1不正常通道0正常 当前是通道1*/
                   {
                       *pType = TX;
                       *pIndex = otherChn;
                       *pCoef = 22.5/19.0;  /*通道1的前向= 通道0的前向*22.5/19*/
                       return BSP_OK;
                   }
               }
               else
               {
                   *pType = RX;
                   *pIndex = 0xf;
                   *pCoef = 0.0;
                    return BSP_ERROR;
               }
         }
    }
    return BSP_ERROR;   /*时延测量都失败 则error 插损外层上报是0*/
}


/*使用已有的插损校准表 计算当前频点的插损值*/
UINT32 BspGetSlaveCableLossData(UINT32 freq, T_CableLossRecord *pData, INT32 *pLoss)
{
    UINT32 loop = 0;
    UINT32 index = 0xff;
    UINT32 nextIndex = 0xff;

    INPUT_POINTER_CHECK(pData);
    INPUT_POINTER_CHECK(pLoss);
    dbgInfoEx("freq %d pData->cnt %d\n", freq, pData->cnt);
    for(loop = 1; loop < pData->cnt -1; loop++)
    {
        dbgInfoEx("%d %d %d \n",loop,pData->freq[loop],pData->freq[loop+1]);
        if((pData->freq[loop] <= freq)&&(pData->freq[loop+1] > freq))
        {
            index = loop;
            nextIndex = loop+1;
            break;
        }
    }
    if(loop == (pData->cnt -1))
    {
         if(pData->freq[loop] <= freq)
         {
             index = loop - 1;
             nextIndex = loop;
         }
         if(pData->freq[1] > freq)
         {
             index = 1;
             nextIndex = 2;
         }
    }
    if(index == 0xff)
    {
        return BSP_ERROR;
    }
    if(index >= MAX_SLAVE_FREQ_POINT)
    {
        return BSP_ERROR;
    }
    if(nextIndex >= MAX_SLAVE_FREQ_POINT)
    {
        return BSP_ERROR;
    }
    *pLoss = _LINEAR_INSERT((INT32)freq, (INT32)pData->freq[index], pData->loss[index],
        (INT32)pData->freq[nextIndex],pData->loss[nextIndex]);
    if(*pLoss > 0)
    {
        *pLoss = 0;   /*插损不能是正数值*/
    }
    dbgInfo("[%s] ulRecordIndex:%d,ulNextIndex:%d,ulCarrFreq:%d,lFreq1:%d,lCompVal1:%d,lFreq2:%d,lCompVal2:%d *pLoss %d\n",
           __FUNCTION__, index, nextIndex, freq, pData->freq[index], pData->loss[index],pData->freq[nextIndex],pData->loss[nextIndex], *pLoss);
    BspLog(LOG_LEVEL_0,"[%s] ulRecordIndex:%d,ulNextIndex:%d,ulCarrFreq:%d,lFreq1:%d,lCompVal1:%d,lFreq2:%d,lCompVal2:%d *pLoss %d\n",
            __FUNCTION__, index, nextIndex, freq, pData->freq[index], pData->loss[index],pData->freq[nextIndex],pData->loss[nextIndex], *pLoss);

    return BSP_OK;
}



/*对高层流程校准产生的插损表  进行插值扩展 覆盖到全带宽  点数过少边界点位置就不准确 算的增益值不准*/
UINT32 BspReInsertSlaveCableLoss(UINT32 chan, UINT32 freq, T_CableLossRecord *pTmpData)
{
    TFreqStartEnd freqStartEnd = {0};
    UINT32 loop = 0;
    UINT32 bandNo = 0;
    UINT32 bandWith = 0;
    UINT32 num = 0;
    UINT32 caliFreq = 0;
    INT32 tmpLoss = 0;
    UINT32 retVal = BSP_OK;

    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pTmpData);
    memset_s(&g_ulReInsertCableLoss[chan], sizeof(T_CableLossRecord),0, sizeof(T_CableLossRecord));
    BspGetFreqRange(chan, 0, TX, &freqStartEnd);
    for(loop = 0; loop < BSP_MAX_BAND_PER_CH; loop++)
    {
        if((freq <= freqStartEnd.aulFreqEnd[loop])&&(freq >= freqStartEnd.aulFreqStart[loop]))
        {
            bandNo = loop;
            break;
        }
    }
    if(loop == BSP_MAX_BAND_PER_CH)
    {
        return BSP_ERROR;
    }
    bandWith = freqStartEnd.aulFreqEnd[loop] - freqStartEnd.aulFreqStart[bandNo];
    num = bandWith/10000;
    for(loop = 0; loop < num; loop++)
    {
        caliFreq = freqStartEnd.aulFreqStart[bandNo] + loop *10000;
        retVal |= BspGetSlaveCableLossData(caliFreq, pTmpData, &tmpLoss);
        g_ulReInsertCableLoss[chan].loss[loop]= tmpLoss;
        g_ulReInsertCableLoss[chan].freq[loop]= caliFreq;
        g_ulReInsertCableLoss[chan].cnt++;
        dbgInfo("caliFreq %d tmpLoss %d cnt%d\n", caliFreq, tmpLoss, g_ulReInsertCableLoss[chan].cnt);
    }

    return retVal;
}

void showLoss(UINT32 chan, UINT32 type)
{
    UINT32 loop = 0;
    T_CableLossRecord *pTmpData = NULL;

    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return ;
    }
    if(TX == type)
    {
        pTmpData = &g_ulTxRfCableLoss[chan];
    }
    else
    {
        pTmpData = &g_ulPrxRfCableLoss[chan];
    }
    dbgInfo("chan %d dir %d cnt %d\n", chan, type, pTmpData->cnt);
    for(loop = 0; loop < pTmpData->cnt; loop++)
    {
        dbgInfo("loop %d freq %d loss %d temp %d\n", loop, pTmpData->freq[loop], pTmpData->loss[loop],pTmpData->temp[loop]);
    }
    return ;
}

UINT32 BspGetSlaveCableLoss(UINT32 chan, UINT32 freq, INT32 *pLoss)
{
    T_CableLossRecord pTmpData = {0};
    UINT32 loop = 0;
    UINT32 retVal = BSP_OK;
    UINT32 type = 0;
    UINT32 index = 0;
    double coef = 1.0;
    INT32 tmpVal = 0;
    INT32 bdtemp = 0;
    INT32 baseLoss = 0;
    INT32 currLoss = 0;
    T_RfTblChanPara tmp = {0};
    INT32 tmpLoss = 0;

    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
         return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pLoss);
    retVal = BspGetSlaveCableLossInfoByApp(chan, &type, &index, &coef);
    if(BSP_ERROR == retVal)  /*先根据高层的结果判断  如果没有一个通道正常 则按原来的条件判断*/
    {
        retVal = BspGetSlaveCableLossInfo(chan, &type, &index, &coef);
        if(BSP_OK != retVal)  /*实在找不到转换关系 报错 插损为0*/
        {
            *pLoss = 0;   /*两个通道都异常时 返回插损为0  这时候高层算出来的dsa是默认值*/
            dbgErr("BspGetSlaveCableLossData failed\n");
            return BSP_ERROR;
        }
    }
    if(index >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    dbgInfo("chan %d, type %d, index %d, coef %f\n", chan, type, index, coef);
    BspLog(LOG_LEVEL_0, "chan %d, type %d, index %d, coef %f\n", chan, type, index, coef);
    memset_s(&pTmpData, sizeof(T_CableLossRecord), 0, sizeof(T_CableLossRecord));
    if(TX == type)
    {
        memcpy_s(&pTmpData, sizeof(T_CableLossRecord), &g_ulTxRfCableLoss[index], sizeof(T_CableLossRecord));
    }
    else
    {
        memcpy_s(&pTmpData, sizeof(T_CableLossRecord), &g_ulPrxRfCableLoss[index], sizeof(T_CableLossRecord));
    }
    dbgInfoEx("chan %d dir %d cnt %d\n", chan, type, pTmpData.cnt);
    for(loop = 0; loop < pTmpData.cnt; loop++)
    {
        dbgInfo("ori loop %d freq %d loss %d\n", loop, pTmpData.freq[loop], pTmpData.loss[loop]);
        pTmpData.loss[loop] = pTmpData.loss[loop]*coef;
        dbgInfo("final loop %d freq %d loss %d\n", loop, pTmpData.freq[loop], pTmpData.loss[loop]);
    }
    for(loop = 1; loop < pTmpData.cnt; loop++)    /*第一个预开环的频点 后边正式计算通道插损时没有使用  不算进来*/
    {
       tmpVal += pTmpData.temp[loop];
       dbgInfo("tmpVal %d calbe pTmpData.temp[loop] %d\n", tmpVal, pTmpData.temp[loop]);
    }
    if(1 == pTmpData.cnt)
    {
        return BSP_ERROR;    /*业务场景这里不会是1*/
    } 
    g_ulCableLossBaseTemp[chan] = tmpVal/(INT32)(pTmpData.cnt-1);    /*生成线缆插损的校准温度（取频点遍历时 记录的各个频点插损校准温度的均值来等效）*/
    dbgInfo("chan %d cable g_ulCableLossBaseTemp %d\n", chan, g_ulCableLossBaseTemp[chan]);
    BspReInsertSlaveCableLoss(chan, freq, &pTmpData);
    BspGetSlaveCableLossData(freq, &g_ulReInsertCableLoss[chan], &tmpLoss);
    /*用的哪个通道的数据算  就要使用哪个通道对应的规则  */
    BspGetBoardTemp(chan,&bdtemp);
    BspGetSingleChanRfTblPara(chan, &tmp);
    type = tmp.chanType;
    BspGetSlaveCableTempGain(chan,type, g_ulCableLossBaseTemp[chan]+SLAVE_CABLE_DELT_TEMP, &baseLoss);
    BspGetSlaveCableTempGain(chan,type, bdtemp, &currLoss);
    *pLoss = tmpLoss + (currLoss - baseLoss);
    dbgInfoEx("%s bspChn %d freq %d loss %d = %d + (%d - %d)\n", __FUNCTION__, chan, freq, *pLoss, tmpLoss, currLoss, baseLoss);

    return BSP_OK;
}
/*负数斜率--DSA的补偿规则：以通道功放温度进行补偿，温度60°时，2.6G频段的基准是-19dB；
 3.5G频段的基准是-22dB，斜率就是 2.6G频段  0.3dB/10°，3.5G频段  0.4dB/10°
 算出来，功放温度-20°时，2.6G频段的补偿规则就是  -21.4dB    3.5G频段的补偿规则是  -25.2dB*/
UINT32 BspGetSlaveCableLossBaseVal(UINT32 chan, INT32 *pVal)
{
    T_RfTblChanPara tmp = {0};
    UINT32 retVal = BSP_OK;
    INT32 paTemp = 0;
    UINT32 bandType = 0;

    INPUT_POINTER_CHECK(pVal);
    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    retVal = BspGetSingleChanRfTblPara(chan, &tmp);
    if(BSP_OK != retVal)
    {
        return BSP_OK;  /*非子母端机型不需要此功能*/
    }
    if(NULL != tmp.pGetSlavePaTemp)
    {
        tmp.pGetSlavePaTemp(chan,&paTemp);
    }
    bandType = (tmp.chanType>>4)&0xf;    /*0表示2.6G 1表示3.5G*/
    if(0 == bandType)
    {
        *pVal = -1900 + 0.3*(paTemp - 600);
    }
    if(1 == bandType)
    {
        *pVal = -2200 + 0.4*(paTemp - 600);
    }
    dbgInfoEx("%s chan %d bandtype %d patemp %d pval %d\n", __FUNCTION__, chan, bandType, paTemp, *pVal);

    return BSP_OK;
}
/*1900 2200为基础  不再以之前的2100 2600为基础低温应该变成1600 2000这个趋势*/
UINT32 BspGetSlaveCableLossThreshold(UINT32 chan, UINT32 dir, UINT32 len, INT32 *pThr)
{
    T_RfTblChanPara tmp = {0};
    T_RfTblChanPara tmpEx = {0};
    UINT32 retVal = BSP_OK;
    INT32 baseThr = 0;
    INT32 bandType = 0;
    INT32 currLoss = 0;
    INT32 testTemp = 0;
    UINT32 anotherChn = 0;
    UINT32 loop = 0;
    INT32 tmpVal = 0;

    INPUT_POINTER_CHECK(pThr);
    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    retVal = BspGetSingleChanRfTblPara(chan, &tmp);
    if(BSP_OK != retVal)
    {
        return BSP_OK;  /*非子母端机型不需要此功能*/
    }
    BspGetAnotherSlaveChnByBspChn(chan, TX, &anotherChn);
    BspGetSingleChanRfTblPara(anotherChn, &tmpEx);
    bandType = (tmp.chanType>>4)&0xf;
    dbgInfoEx("chan %d dir %d len %d bandType %d anotherChn %d\n", chan, dir, len, bandType, anotherChn);
    if(TX == dir)
    {
        for(loop = 1; loop < g_ulTxRfCableLoss[chan].cnt; loop++)    /*第一个预开环的频点 后边正式计算通道插损时没有使用  不算进来*/
        {
             tmpVal += g_ulTxRfCableLoss[chan].temp[loop];
             dbgInfo("tmpVal %d calbe pTmpData.temp[loop] %d\n", tmpVal, g_ulTxRfCableLoss[chan].temp[loop]);
        }
        if(1 == g_ulTxRfCableLoss[chan].cnt)
        {
           return BSP_ERROR;    /*业务场景这里不会是1*/
        }
        testTemp = tmpVal/(INT32)(g_ulTxRfCableLoss[chan].cnt-1);    /*生成线缆插损的校准温度（取频点遍历时 记录的各个频点插损校准温度的均值来等效）*/
    }
    else
    {
        for(loop = 1; loop < g_ulPrxRfCableLoss[chan].cnt; loop++)    /*第一个预开环的频点 后边正式计算通道插损时没有使用  不算进来*/
        {
             tmpVal += g_ulPrxRfCableLoss[chan].temp[loop];
             dbgInfo("tmpVal %d calbe pTmpData.temp[loop] %d\n", tmpVal, g_ulPrxRfCableLoss[chan].temp[loop]);
        }
        if(1 == g_ulPrxRfCableLoss[chan].cnt)
        {
           return BSP_ERROR;    /*业务场景这里不会是1*/
        }
        testTemp = tmpVal/(INT32)(g_ulPrxRfCableLoss[chan].cnt-1);    /*生成线缆插损的校准温度（取频点遍历时 记录的各个频点插损校准温度的均值来等效）*/
    }
    if(0 == bandType)
    {
       if(TX == dir)
       {
          BspGetSlaveCableTempGain(chan,tmp.chanType, testTemp+SLAVE_CABLE_DELT_TEMP, &currLoss);  /*19 22对应20+39度基准点*/
          baseThr = -1900 + currLoss;
          *pThr = 0.001*baseThr*len - 800;
       }
       else
       {
           BspGetSlaveCableTempGain(anotherChn,tmpEx.chanType, testTemp+SLAVE_CABLE_DELT_TEMP, &currLoss);
           baseThr = -2200 + currLoss;
           *pThr = 0.001*baseThr*len - 500;
       }
    }
    else
    {
        if(TX == dir)
        {
           BspGetSlaveCableTempGain(chan,tmp.chanType, testTemp+SLAVE_CABLE_DELT_TEMP, &currLoss);
           baseThr = -2200 + currLoss;
           *pThr = 0.001*baseThr*len - 800;
        }
        else
        {
            BspGetSlaveCableTempGain(anotherChn,tmpEx.chanType, testTemp+SLAVE_CABLE_DELT_TEMP, &currLoss);
            baseThr = -1900 + currLoss;
            *pThr = 0.001*baseThr*len - 500;
        }
    }
    dbgInfoEx("%s testTemp %d dir %d len %d  currLoss %d baseThr  %d *pThr %d\n", __FUNCTION__, testTemp, dir, len, currLoss, baseThr, *pThr);
    return BSP_OK;
}

void getFreqLoss(UINT32 chan, UINT32 freq)
{
    INT32 loss = 0;
    BspGetSlaveCableLoss(chan,freq, &loss);
    dbgInfo("chan %d,freq %d, loss %d\n", chan,freq, loss);
}

/*获取通道插损的基准线缆温度*/
UINT32 BspGetCableLossBaseTemp(UINT32 chan, INT32 *pTemp)
{
    INPUT_POINTER_CHECK(pTemp);
    if(chan >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    *pTemp = g_ulCableLossBaseTemp[chan];
    return BSP_OK;
}
/*高层设置当前插损是否有效的标志  dir = 0xff 表示最后通道级的是否有效 2 4 8*/
UINT32 BspSetCableLossVaildFlag(UINT32 chan, UINT32 dir, UINT32 flag)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    if(0xff == dir)
    {
        dir = RX;
    }
    if(dir > PRX)
    {
        return BSP_ERROR;
    }
    g_ulSlaveCableLossVailFlag[chan].flag[dir] = flag;

    return BSP_OK;
}

/*高层获取当前插损是否有效的标志*/
UINT32 BspGetCableLossVaildFlag(UINT32 chan, UINT32 dir, UINT32 *pFlag)
{
    INPUT_POINTER_CHECK(pFlag);
    if(chan >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    if(dir > PRX)
    {
        return BSP_ERROR;
    }
    *pFlag = g_ulSlaveCableLossVailFlag[chan].flag[dir];

    return BSP_OK;
}

/*固定ic功率检测时间片*/
UINT32 BspSetCbForceSta(UINT32 swInex, UINT32 chan, UINT32 sta,UINT32 sw)
{
    UINT32 ret = BSP_OK;
    UINT32 period = 0;
    UINT32 chanNum = 0;
    UINT32 tmpVal = 0;
    static UINT32 dlyTime = 0;

    if(dlyTime == 0)
    {
        dlyTime = g_spePowTimeMs;   /*只赋值一次*/
    }
    chanNum = BspGetTxChannel();
    period = dlyTime/chanNum/8;

    if(sw == SWITCH_ON)
    {
        ret = BspHalAdaptCbSwForceModeOn(swInex,chan,sta,period);
        tmpVal = period;
    }
    else
    {
        ret = BspHalAdaptCbSwForceModeOff(swInex,chan);
        tmpVal = dlyTime;
    }
    BspSetSpePowTimeCfg(tmpVal);
    BspSetAllPowCalcSwitch(1-sw);
    BspSetPowCalcSwitch(chan, 1);
    BspSysMsDelay(3000);
    dbgInfo("%s: chan is %d,sta is %d,sw is %d tmpVal %d\n", __FUNCTION__, chan, sta, sw, tmpVal);
    BspLog(LOG_LEVEL_0, "%s: chan is %d,sta is %d,sw is %d\n",\
                __FUNCTION__, chan, sta, sw);

    return ret;
}

/*子端标量驻波计算 此时dsp发源 通过模拟检波电路获取fwd和rev  数字默认是-14*/
UINT32 BspGetSlaveScalarVswrTemp(UINT32 bspChn, UINT32 ulband, UINT32 *pVswrVal)
{
    UINT32 retVal = BSP_OK;
    T_TxDualPow fwd={0}, rev={0};
    INT32  vswrCoef =0;
    DOUBLE gama = 0.0;
    INT32 txGain = 0;
    INPUT_POINTER_CHECK(pVswrVal);
    POW_TXCHAN_CHECK(bspChn);

    _BspGetIfTssiDbmGain(bspChn, &txGain, 0);
    fwd.ifTssiPow = -1400 + txGain;  /*各个通道的功率检测任务停了  直接取源的功率算*/
    rev.ifTssiPow = -1400 + txGain;
#ifdef _BSP_WITH_WFS
    retVal = BspGetSlavePowInfoByRfDector(bspChn, TX, 0, (UINT32 *)(&fwd.fbPow)); /*模拟检波电路获取*/
    retVal |= BspGetSlavePowInfoByRfDector(bspChn, RX, 0, (UINT32 *)(&rev.fbPow));
#else
    retVal = BspGetSlavePowInfoByRfDector(bspChn, TX, 1, (UINT32 *)(&fwd.fbPow)); /*模拟检波电路获取*/
    retVal |= BspGetSlavePowInfoByRfDector(bspChn, RX, 1, (UINT32 *)(&rev.fbPow));
#endif
    if(BSP_OK != retVal)
    {
        dbgErr("powdbm get failed\n");
        return BSP_ERROR;
    }
    dbgInfo("\n[%s] rev.fbPow = %d, rev.ifTssiPow =%d\n",__FUNCTION__,rev.fbPow,rev.ifTssiPow);
    dbgInfo("\n[%s] fwd.fbPow = %d, fwd.ifTssiPow =%d\n",__FUNCTION__,fwd.fbPow,fwd.ifTssiPow);
    if (fwd.fbPow <= 0 && rev.fbPow <= 0)
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return BSP_OK;
    }
    if((fwd.ifTssiPow < BspGetVswrThreshhold(bspChn,TSSI0_THRESHOLD))||
           (fwd.fbPow< BspGetVswrThreshhold(bspChn,FWD_THRESHOLD))||
           (rev.ifTssiPow < BspGetVswrThreshhold(bspChn,TSSI1_THRESHOLD)))
    {
        *pVswrVal = BSP_INVALID_VALUE;
        return BSP_ERROR;
    }
    vswrCoef = rev.fbPow - rev.ifTssiPow + fwd.ifTssiPow - fwd.fbPow;
    dbgInfo("\n[%s] vswrCoef = %d\n",__FUNCTION__,vswrCoef);
    if (vswrCoef >= 0)
    {
        *pVswrVal = VSWR_ANORMAL_H_VAL;
        return BSP_OK;
    }

    gama = pow(10.0, (DOUBLE)vswrCoef/2000.0);
    *pVswrVal = VSWR_UINT * (1 + gama) / (1 - gama);

    if(*pVswrVal > VSWR_ANORMAL_H_VAL)
    {
        *pVswrVal = VSWR_ANORMAL_H_VAL;
    }
    if(*pVswrVal < VSWR_ANORMAL_L_VAL)
    {
        *pVswrVal = VSWR_ANORMAL_L_VAL;
    }
    return BSP_OK;
}

UINT32 BspGetSlaveScalarVswr(UINT32 bspChn, UINT32 *pVswrVal)
{
    UINT32 retVal = BSP_OK;
    UINT32 vswrVal = BSP_INVALID_VALUE;
    UINT32 portId = 0;
    UINT32 portType = 0;
    UINT32 portSta = 0;

    INPUT_POINTER_CHECK(pVswrVal);
    POW_IC_MAX_CHAN_CHECK(bspChn);
    BspGetPortIdByBspChn(bspChn, TX, &portId);
    BspGetSlavePortCfgTpye(portId, &portType);
    BspGetSlavePortCfgSta(portId, &portSta);
    if((0 == portType)||(LINK_OK != portSta))   /*不拉远或者断链*/
    {
       return BSP_INVALID_VALUE;     /*如何上报找se再明确*/
    }
    retVal = BspGetSlaveScalarVswrTemp(bspChn,0,&vswrVal);
    *pVswrVal = vswrVal;
    g_ulSlaveScalarVswr[bspChn] = vswrVal;
    dbgInfo("BspGetSlaveScalarVswr bspChn %d vswrVal %d\n", bspChn, vswrVal);

    return retVal;
}

UINT32 BspSetRssiGroupSw(UINT32 sw)
{
    UINT32 ret = BSP_OK;

    ret |= BspHalAdaptSetLongRssiGroup(sw);
    BspLog(LOG_LEVEL_0, "[%s]sw = %d, ret = %d\n", __FUNCTION__, sw, ret);

    return ret;
}

UINT32 BspCarrGainIsNormal(UINT32 bspChan, UINT32 radioMode, UINT32 carrNo, UINT32 *pulState)
{
    return BSP_OK;
}

UINT32 BspSetUmtsDagcReset(VOID)
{
    UINT32 retVal = BSP_OK;

    retVal = BspHalAdaptSetUmtsDagcReset();

    return retVal;
}

UINT32 BspSetUmtsDagcPowCfg(UINT32 bspChan, UINT32 carrId, UINT32 radioMode)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptSetUmtsDagcPowCfg(difChan, carrId, radioMode);

    return retVal;
}

UINT32 BspGetUmtsDagcPowPrt(UINT32 bspChan, UINT32 carrId, UINT32 radioMode, UINT32 *errFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 chipId = 0;
    UINT32 difChan = 0;

    if (NULL == errFlag)
    {
        printf("%s:Input Pointer is NULL!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    retVal = BspGetDifInfoByBspChn(bspChan, TX, &chipId, &difChan);
    if (BSP_OK != retVal)
    {
        dbgErr("%s>>BspChnl'%d BspGetDifInfoByBspChn Get Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    retVal = BspHalAdaptGetUmtsDagcPowPrt(difChan, carrId, radioMode, errFlag);

    return retVal;
}

/*设置GSM制式发单音，uiPower单位为mW，高层调用*/
UINT32 BspSetGsmDcTsgCtrl(UINT32 bspChan, UINT32 carrNo, UINT32 carrPower, UINT32 uiEn)
{
    UINT32 retVal = BSP_OK;
    INT32 powDbfs = 0;
    UINT32 ratedPow = 0;
    UINT16 gsmStaticLevel = 0;

    POW_IC_MAX_CHAN_CHECK(bspChan);

    BspGetRruPathRatedPower(bspChan, &ratedPow);
    if ((0 == ratedPow)||(ratedPow >= BSP_INVALID_VALUE))
    {
        dbgInfoEx("%s ERROR!TxChan#%d,ulRatedPow=%d\n", __FUNCTION__,bspChan,ratedPow);
        return BSP_ERROR;
    }
    if(SWITCH_ON == uiEn)
    {
        retVal = BspSetCarrPow(bspChan, carrNo, ratedPow, BSP_RADIO_STANDARD_GSM);  //GSM自发源先设置载波增益到最大，防止自发源功率达不到检测门限，后续功率恢复app重新设置
        if(BSP_OK != retVal)
        {
            BspLog(LOG_LEVEL_0,"%s failed,cause is BspSetCarrPow failed!\n",__FUNCTION__);
            return retVal;
        }
    }
    powDbfs = 1000.0*log10_s((double)carrPower / ((double)ratedPow + 0.000001), 0.0);
    powDbfs = powDbfs - 950;
    retVal = BspGetGsmStaticPowLevel(bspChan, &gsmStaticLevel);
    if (retVal == BSP_OK)
    {
        powDbfs -= gsmStaticLevel * 100;
    }
    powDbfs = (INT32)(powDbfs  / 100);
    retVal = IcHalApiSetGsmDcTsgCtrl(bspChan, carrNo, BSP_RADIO_STANDARD_GSM, powDbfs, uiEn);
    BspLog(LOG_LEVEL_0, "%s chan = %d, carrPower = %d,ratedPow = %d,gsmStaticLevel = %d,powDbfs = %d,en = %d, ret = %d\n",__FUNCTION__,bspChan,carrPower,ratedPow,gsmStaticLevel,powDbfs,uiEn,retVal);
    return retVal;
}

VOID BspSetCaliPow(UINT32 calPort, INT32 fwdDbmPow, INT32 revDbmPow)
{
    if (calPort >= RCUA_CAL_NUM)
    {
        dbgErr("[%s]>>>InputPara Error: calPort[%d]n", __FUNCTION__, calPort);
        return ;
    }

    g_fwdDbmVal[calPort] = fwdDbmPow;
    g_revDbmVal[calPort] = revDbmPow;
    BspLog(LOG_LEVEL_0, "[%s]>>> calPort[%d], fwdDbmVal[%d], revDbmVal[%d]\n",
        __FUNCTION__, calPort, g_fwdDbmVal[calPort], g_revDbmVal[calPort]);
}

/* Started by AICoder, pid:6097cnccf936ef9149dd0a4b00701e3abcf40a64 */
UINT32 BspGetCaliPow(UINT32 calPort, INT32 *fwdDbmPow, INT32 *revDbmPow)
{
    const UINT32 chan = 0;
    INPUT_POINTER_CHECK(fwdDbmPow);
    INPUT_POINTER_CHECK(revDbmPow);

    if (calPort >= RCUA_CAL_NUM)
    {
        dbgErr("[%s]>>>InputPara Error: calPort[%d]\n", __FUNCTION__, calPort);
        return BSP_ERROR;
    }

    if (g_fwdDbmVal[calPort] < BspGetVswrThreshhold(chan, FWD_THRESHOLD))
    {
        *fwdDbmPow = BSP_INVALID_VALUE;
    }
    else
    {
        *fwdDbmPow = g_fwdDbmVal[calPort];
    }

    if (g_revDbmVal[calPort] <= RSSI_NO_POWER_DBFS)
    {
        *revDbmPow = BSP_INVALID_VALUE;
    }
    else
    {
        *revDbmPow = g_revDbmVal[calPort];
    }

    dbgInfoEx("[%s]>>>calPort[%u], fwd[%d], rev[%d]\n", __FUNCTION__,  calPort, *fwdDbmPow, *revDbmPow);

    return BSP_OK;
}
/* Ended by AICoder, pid:6097cnccf936ef9149dd0a4b00701e3abcf40a64 */

/* Started by AICoder, pid:d3b92cba07iff10143d60a831096e72cd9e9950c */
UINT32 BspSetVswrDetectValue(UINT32 calPort, UINT32 freqId, INT32 fwdVal, INT32 revVal)
{
    UINT32 retVal = BSP_OK;
    UINT32 bandId = 0;

    if (calPort >= RCUA_CAL_NUM || freqId >= RCUA_FREQ_NUM)
    {
        dbgErr("[%s]>>> InputPara Error: calPort[%d], freqId[%d]\n", __FUNCTION__, calPort, freqId);
        return BSP_ERROR;
    }

    g_acFwdVal[calPort][freqId] = fwdVal;
    g_acRevVal[calPort][freqId] = revVal;

    BspLog(LOG_LEVEL_0, "[%s]>>> calPort[%d], freqId[%d], fwdVal[%d], revVal[%d]\n",
           __FUNCTION__, calPort, freqId, fwdVal, revVal);

    retVal = BspSaveScalarVswr(calPort, bandId);
    if (retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0, "BspSaveScalarVswr Error, calPort[%d], bandId[%d]\n", calPort, bandId);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:d3b92cba07iff10143d60a831096e72cd9e9950c */

UINT32 BspGetVswrDetectValue(UINT32 calPort, UINT32 freqId, INT32 *fwdVal, INT32 *revVal)
{
    INPUT_POINTER_CHECK(fwdVal);
    INPUT_POINTER_CHECK(revVal);

    if (calPort >= RCUA_CAL_NUM || freqId >= RCUA_FREQ_NUM)
    {
        dbgErr("[%s]>>>InputPara Error: calPort[%d], freqId[%d]\n", __FUNCTION__, calPort, freqId);
        return BSP_ERROR;
    }

    if ((g_acFwdVal[calPort][freqId] == 0) || (g_acRevVal[calPort][freqId] == 0))
    {
        return BSP_ERROR;
    }

    *fwdVal = g_acFwdVal[calPort][freqId];
    *revVal = g_acRevVal[calPort][freqId];

    return BSP_OK;
}

/* Started by AICoder, pid:g9aae5c2cbpa92c147300a180055dd30ac6754c0 */
UINT32 BspGetOptimizedRev(UINT32 bspChn, INT32 oriFwd, INT32 oriRev, INT32 *optimizedRev)
{
    INT32 circulatorIsoTempComp = 0;
    DOUBLE oriRevMw = 0.0;
    DOUBLE adjustRevMw = 0.0;
    INT32 adjustRevDb = 0;
    DOUBLE optimizedRevMw = 0.0;
    INT32 optimizedRevDb = 0;

    INPUT_POINTER_CHECK(optimizedRev);

    // 1. dB转mW，使用double防止精度损失
    oriRevMw = pow(10.0, oriRev / 1000.0);

    // 2. 获取温补值
    BspGetTempGainRxDComps(bspChn, &circulatorIsoTempComp);

    // 3. 计算补偿后的dB
    adjustRevDb = oriFwd - circulatorIsoTempComp;
    adjustRevMw = pow(10.0, adjustRevDb / 1000.0);

    // 4. 计算优化后的反射功率
    optimizedRevMw = (oriRevMw < adjustRevMw) ? oriRevMw : (oriRevMw - adjustRevMw);

    // 5. mW转dB，防止log10(0)
    optimizedRevDb =(INT32)(1000.0 * log10_s(optimizedRevMw, oriRev / 1000.0));
    dbgInfoEx("%s,oriRev:%d, oriRev /1000.0 = %.15g\n", __FUNCTION__, oriRev, oriRev / 1000.0);
    *optimizedRev = optimizedRevDb;

    // 6. 集中打印调试信息
    dbgInfoEx("\n%s input: bspChn=%u, oriRev=%d, oriFwd=%d\n", __FUNCTION__, bspChn, oriRev, oriFwd);
    dbgInfoEx("\n%s tempComp: circulatorIsoTempComp=%d\n", __FUNCTION__, circulatorIsoTempComp);
    dbgInfoEx("\n%s calc: oriRevMw=%.15g, adjustRevDb=%d, adjustRevMw=%.15g\n", __FUNCTION__, oriRevMw, adjustRevDb, adjustRevMw);
    dbgInfoEx("\n%s result: optimizedRevMw=%.15g, optimizedRevDb=%d, *optimizedRev=%d\n", __FUNCTION__, optimizedRevMw, optimizedRevDb, *optimizedRev);

    return BSP_OK;
}
/* Ended by AICoder, pid:g9aae5c2cbpa92c147300a180055dd30ac6754c0 */
/* Started by AICoder, pid:64d4en0f2eba59914fb70ac700f43a9ac06864e4 */
UINT32 BspGetTssiTcpwByAcDsp(UINT32 cal, UINT32 bandId, T_TxDualPow *fwd, T_TxDualPow *rev)
{
    UINT32 retVal = BSP_OK;
    UINT32 freqId = 0;
    INT32 fwdGain = 0;
    INT32 revGain = 0;
    /* Started by AICoder, pid:o04d1g259f1f229148dd08bf20132503b6717978 */
    INT32 optimizedRev = 0;
    /* Ended by AICoder, pid:o04d1g259f1f229148dd08bf20132503b6717978 */
    INT32 fwdVal = RSSI_NO_POWER_DBFS;
    INT32 revVal = RSSI_NO_POWER_DBFS;
    const UINT32 acType = 0;
    const UINT32 chan = 0;

    if (fwd == NULL || rev == NULL)
    {
        dbgErr("Para Error: cal = %d, or ptDualPow = NULL\n", cal);
        return BSP_ERROR;
    }

    retVal = BspChangeRfCfgDir(chan);
    if (retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0, "%s>>> Change RfCfg Dir Error\n", __FUNCTION__);
        dbgErr("%s>>> Change RfCfg Dir Error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (pGetAcFreqIndexFromBoardFunc != NULL)
    {
        freqId = pGetAcFreqIndexFromBoardFunc(acType);
    }

    // 获取VSWR检测值和增益
    retVal = BspGetVswrDetectValue(cal, freqId, &fwdVal, &revVal);
    retVal |= _BspGetFwdDbmGain(chan, &fwdGain, COMPS_BY_FREQ_POINT_TYPE);
    retVal |= _BspGetRevDbmGain(chan, &revGain, COMPS_BY_FREQ_POINT_TYPE);
    retVal |= BspChangeRfCfgDir(chan);
    if (retVal != BSP_OK)
    {
        BspLog(LOG_LEVEL_0, "%s>>>Get Vswr Detect Value Error\n", __FUNCTION__);
        dbgErr("%s>>>Get Vswr Detect Value Error\n", __FUNCTION__);
        return BSP_ERROR;
    }

    if (fwdVal <= RSSI_NO_POWER_DBFS || revVal <= RSSI_NO_POWER_DBFS)
    {
        BspLog(LOG_LEVEL_0, "%s>>> Get Power Error: FWD[%d], REV[%d]\n", __FUNCTION__, fwdVal, revVal);
        dbgErr("Get Power Error: FWD[%d], REV[%d]\n", fwdVal, revVal);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s]>>>cal[%u], freqId[%u], fwdGain[%d], revGain[%d], fwd[%d], rev[%d]\n",
        __FUNCTION__, cal, freqId, fwdGain, revGain, fwdVal, revVal);
    BspLog(LOG_LEVEL_0, "[%s]>>>cal[%u], freqId[%u], fwdGain[%d], revGain[%d], fwd[%d], rev[%d]\n",
        __FUNCTION__, cal, freqId, fwdGain, revGain, fwdVal, revVal);

    fwd->ifTssiPow = 0;
    fwd->fbPow = fwdVal - fwdGain;
    rev->ifTssiPow = 0;
    rev->fbPow = revVal - revGain;
  /* Started by AICoder, pid:12d91u65f9e2ebb1455a098ec0021d07ee434805 */
    // optimized rev
    BspGetOptimizedRev(chan, fwd->fbPow, rev->fbPow, &optimizedRev);
    rev->fbPow = optimizedRev;
    /* Ended by AICoder, pid:12d91u65f9e2ebb1455a098ec0021d07ee434805 */
    BspSetCaliPow(cal, fwd->fbPow, rev->fbPow);

    return retVal;
}
/* Ended by AICoder, pid:64d4en0f2eba59914fb70ac700f43a9ac06864e4 */

/* Started by AICoder, pid:1534fe7b4507f7d140da084320ad274e548934e7 */
UINT32 BspSaveScalarVswr(UINT32 cal, UINT32 bandId)
{
    UINT32 retVal = BSP_OK;
    UINT32 tmpVswr = 0;
    T_TxDualPow fwd = {0};
    T_TxDualPow rev = {0};
    DOUBLE gama = 0.0;
    INT32 vswrCoef = 0;
    // chan固定为0，Chan通道与cal通道映射关系由电子开关保证
    const UINT32 chan = 0;

    retVal = BspGetTssiTcpwByAcDsp(cal, bandId, &fwd, &rev);
    if (retVal != BSP_OK)
    {
        g_scalarVswr[cal] = BSP_INVALID_VALUE;
        return BSP_ERROR;
    }

    if (fwd.fbPow < BspGetVswrThreshhold(chan, FWD_THRESHOLD))
    {
        g_scalarVswr[cal] = BSP_INVALID_VALUE;
        return BSP_ERROR;
    }

    vswrCoef = rev.fbPow - fwd.fbPow;
    dbgInfoEx("\n[%s] rev.fbPow = %d, fwd.fbPow = %d\n", __FUNCTION__, rev.fbPow, fwd.fbPow);
    dbgInfoEx("\n[%s] vswrCoef = %d\n", __FUNCTION__, vswrCoef);
    if (vswrCoef >= 0)
    {
        g_scalarVswr[cal] = VSWR_ANORMAL_H_VAL;
        return BSP_OK;
    }

    gama = pow(10.0, (DOUBLE)vswrCoef / 2000.0);
    tmpVswr = (UINT32)(VSWR_UINT * (1 + gama) / (1 - gama));
    dbgInfoEx("\n[%s] vswr = %f\n", __FUNCTION__, (DOUBLE)tmpVswr / VSWR_UINT);

    if (tmpVswr > VSWR_ANORMAL_H_VAL)
    {
        tmpVswr = VSWR_ANORMAL_H_VAL;
    }
    if (tmpVswr < VSWR_ANORMAL_L_VAL)
    {
        tmpVswr = VSWR_ANORMAL_L_VAL;
    }

    g_scalarVswr[cal] = tmpVswr;
    return BSP_OK;
}
/* Ended by AICoder, pid:1534fe7b4507f7d140da084320ad274e548934e7 */

/* Started by AICoder, pid:e9852e2c44l35e2145ba092e3051641322b8c6ea */
UINT32 BspGetCalScalarVswr(UINT32 cal, UINT32 bandId, UINT32 *pVswrVal)
{
    INPUT_POINTER_CHECK(pVswrVal);
    if (cal >= RCUA_CAL_NUM)
    {
        return BSP_ERROR_INVALID_PARA;
    }

    *pVswrVal = g_scalarVswr[cal];
    return BSP_OK;
}
/* Ended by AICoder, pid:e9852e2c44l35e2145ba092e3051641322b8c6ea */

/* Started by AICoder, pid:ne6fef7f01ve444149520956f0d6e71befa2ba7d */
UINT32 ShowRcuaPowAndVswr(UINT32 cal)
{
    if (cal >= RCUA_CAL_NUM)
    {
        return BSP_ERROR_INVALID_PARA;
    }

    dbgInfo("cal[%u] fwdDbm[%d] revDbm[%d] scalarVswr[%.6f]\n",
        cal, g_fwdDbmVal[cal], g_revDbmVal[cal], g_scalarVswr[cal] / 1000000.0);

    return BSP_OK;
}
/* Ended by AICoder, pid:ne6fef7f01ve444149520956f0d6e71befa2ba7d */

/* Started by AICoder, pid:t2f65z6722wd7c0146dd0b01904f216b2117a3d1 */
UINT32 BspGetTxBridgeWeight(UINT16 uChan, UINT32 uCarrFreq, UINT32 uCarrBw, T_BridgePara *t_BridgePara)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 validFreqNum = 0;
    UINT32 vaildStartFreq = 0;
    UINT32 vaildEndFreq = 0;
    UINT32 ulStartFreq = 0;
    UINT32 ulEndFreq = 0;
    UINT32 curFreq = 0;
    INT32 rxPhase0 = 0;
    INT32 rxPhase1 = 0;
    INT32 rxPhase2 = 0;
    TxPhaseCaliData * txPhaseCaliData = NULL;

    INPUT_POINTER_CHECK(t_BridgePara);
    if(TBL_MAX_TX_CHAN_NUM <= uChan)
    {
        dbgErr("[%s] chan is error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    txPhaseCaliData = _BspGetTxPhaseCalibData();
    if (NULL == txPhaseCaliData)
    {
        dbgErr("_BspGetRxPhaseCalibData is error!\n");
        return BSP_ERROR;
    }
    ulStartFreq = txPhaseCaliData->txPhaseCaliPath[uChan].header.startFreq[0];
    ulEndFreq = txPhaseCaliData->txPhaseCaliPath[uChan].header.stopFreq[0];
    vaildStartFreq = (UINT32)(uCarrFreq - (uCarrBw / 2) + 500);
    vaildStartFreq = ((UINT32)(vaildStartFreq / 1000)) * 1000;
    vaildEndFreq = (UINT32)(uCarrFreq + (uCarrBw / 2) + 500);
    vaildEndFreq = ((UINT32)(vaildEndFreq / 1000)) * 1000;
    dbgInfoEx("vaildStartFreq = %d, vaildEndFreq = %d\n", vaildStartFreq,vaildEndFreq);
    if(vaildStartFreq < ulStartFreq)
    {
        vaildStartFreq = ulStartFreq;
    }

    if(vaildEndFreq > ulEndFreq)
    {
        vaildEndFreq = ulEndFreq;
    }

    validFreqNum = (UINT32)((vaildEndFreq - vaildStartFreq) / 1000); //不包括最大频点
    if(validFreqNum > OFFLINE_BRIDGR_WEIGHT_MAX_FREQ_NUM)
    {
        return BSP_ERROR;
    }
    dbgInfoEx("ulStartFreq = %d,ulEndFreq = %d,validFreqNum = %d\n", vaildStartFreq, vaildEndFreq, validFreqNum);
    for (UINT32 loop = 0; loop < validFreqNum;loop++)
    {
        curFreq = vaildStartFreq + loop * 1000;
        retVal = BspSearchTxPhaseVal(uChan, curFreq, &rxPhase0, &rxPhase1, &rxPhase2);
        if((BSP_OK == retVal) && (ulEndFreq != curFreq))
        {
            t_BridgePara->adwWeight[0][loop] = rxPhase0;
            t_BridgePara->adwWeight[1][loop] = rxPhase1;
            t_BridgePara->adwWeight[2][loop] = rxPhase2;
        }
        curFreq += 1000;
        dbgInfoEx("curFreq = %d,txPhase0 = %d,txPhase1 = %d,txPhase2 = %d,retVal = %d\n",curFreq, rxPhase0,rxPhase1,rxPhase2,retVal);
    }
    t_BridgePara->uFreqNum = validFreqNum;
    t_BridgePara->usColNum = txPhaseCaliData->txPhaseCaliPath[uChan].header.listNum - 1;
    return BSP_OK;
}
/* Ended by AICoder, pid:t2f65z6722wd7c0146dd0b01904f216b2117a3d1 */

/* Started by AICoder, pid:t638c6c98738b45144240bd8d0bf0b6e22e6c474 */
UINT32 BspGetRxBridgeWeight(UINT16 uChan, UINT32 uCarrFreq, UINT32 uCarrBw, T_BridgePara *t_BridgePara)
{
    UINT32 retVal = BSP_ERROR;
    UINT32 validFreqNum = 0;
    UINT32 vaildStartFreq = 0;
    UINT32 vaildEndFreq = 0;
    UINT32 ulStartFreq = 0;
    UINT32 ulEndFreq = 0;
    UINT32 curFreq = 0;
    INT32 rxPhase0 = 0;
    INT32 rxPhase1 = 0;
    INT32 rxPhase2 = 0;
    RxPhaseCaliData * rxPhaseCaliData = NULL;

    INPUT_POINTER_CHECK(t_BridgePara);
    if(TBL_MAX_TX_CHAN_NUM <= uChan)
    {
        dbgErr("[%s] chan is error\n",__FUNCTION__);
        return BSP_ERROR;
    }

    rxPhaseCaliData = _BspGetRxPhaseCalibData();
    if (NULL == rxPhaseCaliData)
    {
        dbgErr("_BspGetRxPhaseCalibData is error!\n");
        return BSP_ERROR;
    }
    ulStartFreq = rxPhaseCaliData->rxPhaseCaliPath[uChan].header.startFreq[0];
    ulEndFreq = rxPhaseCaliData->rxPhaseCaliPath[uChan].header.stopFreq[0];
    vaildStartFreq = (UINT32)(uCarrFreq - (uCarrBw / 2) + 500);
    vaildStartFreq = ((UINT32)(vaildStartFreq / 1000)) * 1000;
    vaildEndFreq = (UINT32)(uCarrFreq + (uCarrBw / 2) + 500);
    vaildEndFreq = ((UINT32)(vaildEndFreq / 1000)) * 1000;
    dbgInfoEx("vaildStartFreq = %d, vaildEndFreq = %d\n", vaildStartFreq,vaildEndFreq);
    if(vaildStartFreq < ulStartFreq)
    {
        vaildStartFreq = ulStartFreq;
    }

    if(vaildEndFreq > ulEndFreq)
    {
        vaildEndFreq = ulEndFreq;
    }

    validFreqNum = (UINT32)((vaildEndFreq - vaildStartFreq) / 1000); //不包括最大频点
    if(validFreqNum > OFFLINE_BRIDGR_WEIGHT_MAX_FREQ_NUM)
    {
        return BSP_ERROR;
    }
    dbgInfoEx("ulStartFreq = %d,ulEndFreq = %d,validFreqNum = %d\n",vaildStartFreq,vaildEndFreq,validFreqNum);
    for (UINT32 loop = 0; loop < validFreqNum;loop++)
    {
        curFreq = vaildStartFreq + loop * 1000;
        retVal = BspSearchRxPhaseVal(uChan, curFreq, &rxPhase0, &rxPhase1, &rxPhase2);
        if((BSP_OK == retVal) && (ulEndFreq != curFreq))
        {
            t_BridgePara->adwWeight[0][loop] = rxPhase0;
            t_BridgePara->adwWeight[1][loop] = rxPhase1;
            t_BridgePara->adwWeight[2][loop] = rxPhase2;
        }
        curFreq += 1000;
        dbgInfoEx("curFreq = %d,rxPhase0 = %d,rxPhase1 = %d,rxPhase2 = %d,retVal = %d\n",curFreq, rxPhase0,rxPhase1,rxPhase2,retVal);
    }
    t_BridgePara->uFreqNum = validFreqNum;
    t_BridgePara->usColNum = rxPhaseCaliData->rxPhaseCaliPath[uChan].header.listNum - 1;
    return BSP_OK;
}
/* Ended by AICoder, pid:t638c6c98738b45144240bd8d0bf0b6e22e6c474 */

/* Started by AICoder, pid:f55efue1b96e5531430b0a9f30638d3e6c694802 */
UINT32 BspSearchTxPhaseVal(UINT32 uChan, UINT32 curFreq, INT32 *phase0, INT32 *phase1, INT32 *phase2)
{
    TxPhaseCaliData * txPhaseCaliData = NULL;
    T_TxPhase_Record *ptRecord = NULL;
    UINT32 ulStartFreq = 0;
    UINT32 ulEndFreq = 0;
    UINT32 ulStepFreq = 0;
    UINT32 ulStepNum = 0;
    UINT32 loop = 0;
    INT16 iRealCoef = 0;
    INT16 iImagCoef = 0;
    INT32 comVal = 0;

    INPUT_POINTER_CHECK(phase0);
    INPUT_POINTER_CHECK(phase1);
    INPUT_POINTER_CHECK(phase2);
    if(TBL_MAX_TX_CHAN_NUM <= uChan)
    {
        dbgErr("[%s] chan is error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    txPhaseCaliData = _BspGetTxPhaseCalibData();
    if (NULL == txPhaseCaliData)
    {
        dbgErr("_BspGetTxPhaseCalibData is error!\n");
        return BSP_ERROR;
    }
    ptRecord = txPhaseCaliData->txPhaseCaliPath[uChan].pRfRecord[0];
    ulStartFreq = txPhaseCaliData->txPhaseCaliPath[uChan].header.startFreq[0];
    ulEndFreq   = txPhaseCaliData->txPhaseCaliPath[uChan].header.stopFreq[0];
    ulStepFreq  = txPhaseCaliData->txPhaseCaliPath[uChan].header.rfStep[0];

    ulStepNum = ((INT32)ulEndFreq - (INT32)ulStartFreq) / ulStepFreq +1;
    for (loop = 0; loop < ulStepNum; loop++)
    {
        if(curFreq == ptRecord[loop].freq)
        {
            iRealCoef = (INT16)((DOUBLE)16384 * cos((ptRecord[loop].hybrid_PhaseOfPath0 / 100)/(57.295779)));//57.295779为度数转弧度值转换的固定值，仅此处使用
            iImagCoef = (INT16)((DOUBLE)16384 * sin((ptRecord[loop].hybrid_PhaseOfPath0 / 100)/(57.295779)));
            comVal = ((INT32)iRealCoef << 16) | (iImagCoef & 0xFFFF);
            *phase0 = comVal;
            dbgInfo("[%s 0] chan = %d, freq = %d, iRealCoef = %d iImagCoef = %d comVal = %d\n", __FUNCTION__, uChan, curFreq, iRealCoef, iImagCoef, comVal);
            iRealCoef = (INT16)((DOUBLE)16384 * cos((ptRecord[loop].hybrid_PhaseOfPath1 / 100)/(57.295779)));//57.295779为度数转弧度值转换的固定值，仅此处使用
            iImagCoef = (INT16)((DOUBLE)16384 * sin((ptRecord[loop].hybrid_PhaseOfPath1 / 100)/(57.295779)));
            comVal = ((INT32)iRealCoef << 16) | (iImagCoef & 0xFFFF);
            *phase1 = comVal;
            dbgInfo("[%s 1] chan = %d, freq = %d, iRealCoef = %d iImagCoef = %d comVal = %d\n", __FUNCTION__, uChan, curFreq, iRealCoef, iImagCoef, comVal);
            iRealCoef = (INT16)((DOUBLE)16384 * cos((ptRecord[loop].hybrid_PhaseOfPath2 / 100)/(57.295779)));//57.295779为度数转弧度值转换的固定值，仅此处使用
            iImagCoef = (INT16)((DOUBLE)16384 * sin((ptRecord[loop].hybrid_PhaseOfPath2 / 100)/(57.295779)));
            comVal = ((INT32)iRealCoef << 16) | (iImagCoef & 0xFFFF);
            *phase2 = comVal;
            dbgInfo("[%s 2] chan = %d, freq = %d, iRealCoef = %d iImagCoef = %d comVal = %d\n", __FUNCTION__, uChan, curFreq, iRealCoef, iImagCoef, comVal);
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}
/* Ended by AICoder, pid:f55efue1b96e5531430b0a9f30638d3e6c694802 */

/* Started by AICoder, pid:cd7150d096t446514f6c0b0b70388e32cb29b2c7 */
UINT32 BspSearchRxPhaseVal(UINT32 uChan, UINT32 curFreq, INT32 *phase0, INT32 *phase1, INT32 *phase2)
{
    RxPhaseCaliData * rxPhaseCaliData = NULL;
    T_RxPhase_Record *ptRecord = NULL;
    UINT32 ulStartFreq = 0;
    UINT32 ulEndFreq = 0;
    UINT32 ulStepFreq = 0;
    UINT32 ulStepNum = 0;
    UINT32 loop = 0;
    INT16 iRealCoef = 0;
    INT16 iImagCoef = 0;
    INT32 comVal = 0;

    INPUT_POINTER_CHECK(phase0);
    INPUT_POINTER_CHECK(phase1);
    INPUT_POINTER_CHECK(phase2);
    if(TBL_MAX_TX_CHAN_NUM <= uChan)
    {
        dbgErr("[%s] chan is error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    rxPhaseCaliData = _BspGetRxPhaseCalibData();
    if (NULL == rxPhaseCaliData)
    {
        dbgErr("_BspGetRxPhaseCalibData is error!\n");
        return BSP_ERROR;
    }
    ptRecord = rxPhaseCaliData->rxPhaseCaliPath[uChan].pRfRecord[0];
    ulStartFreq = rxPhaseCaliData->rxPhaseCaliPath[uChan].header.startFreq[0];
    ulEndFreq   = rxPhaseCaliData->rxPhaseCaliPath[uChan].header.stopFreq[0];
    ulStepFreq  = rxPhaseCaliData->rxPhaseCaliPath[uChan].header.rfStep[0];

    ulStepNum = ((INT32)ulEndFreq - (INT32)ulStartFreq) / ulStepFreq +1;
    for (loop = 0; loop < ulStepNum; loop++)
    {
        if(curFreq == ptRecord[loop].freq)
        {
            iRealCoef = (INT16)((DOUBLE)16384 * cos((ptRecord[loop].hybrid_PhaseOfPath0 / 100)/(57.295779)));//57.295779为度数转弧度值转换的固定值，仅此处使用
            iImagCoef = (INT16)((DOUBLE)16384 * sin((ptRecord[loop].hybrid_PhaseOfPath0 / 100)/(57.295779)));
            comVal = ((INT32)iRealCoef << 16) | (iImagCoef & 0xFFFF);
            *phase0 = comVal;
            dbgInfo("[%s 0] chan = %d, freq = %d, iRealCoef = %d iImagCoef = %d comVal = %d\n", __FUNCTION__, uChan, curFreq, iRealCoef, iImagCoef, comVal);
            iRealCoef = (INT16)((DOUBLE)16384 * cos((ptRecord[loop].hybrid_PhaseOfPath1 / 100)/(57.295779)));//57.295779为度数转弧度值转换的固定值，仅此处使用
            iImagCoef = (INT16)((DOUBLE)16384 * sin((ptRecord[loop].hybrid_PhaseOfPath1 / 100)/(57.295779)));
            comVal = ((INT32)iRealCoef << 16) | (iImagCoef & 0xFFFF);
            *phase1 = comVal;
            dbgInfo("[%s 1] chan = %d, freq = %d, iRealCoef = %d iImagCoef = %d comVal = %d\n", __FUNCTION__, uChan, curFreq, iRealCoef, iImagCoef, comVal);
            iRealCoef = (INT16)((DOUBLE)16384 * cos((ptRecord[loop].hybrid_PhaseOfPath2 / 100)/(57.295779)));//57.295779为度数转弧度值转换的固定值，仅此处使用
            iImagCoef = (INT16)((DOUBLE)16384 * sin((ptRecord[loop].hybrid_PhaseOfPath2 / 100)/(57.295779)));
            comVal = ((INT32)iRealCoef << 16) | (iImagCoef & 0xFFFF);
            *phase2 = comVal;
            dbgInfo("[%s 2] chan = %d, freq = %d, iRealCoef = %d iImagCoef = %d comVal = %d\n", __FUNCTION__, uChan, curFreq, iRealCoef, iImagCoef, comVal);
            return BSP_OK;
        }
    }
    return BSP_ERROR;
}
/* Ended by AICoder, pid:cd7150d096t446514f6c0b0b70388e32cb29b2c7 */

/* Started by AICoder, pid:s8c01f9aa5t6545148d90a9790b63543f9a2fd15 */
UINT32 BspGetTxPowerDbfs(UINT32 bspChn, T_TxPow *pPowDbfs)
{
    UINT32 loopChn = 0;
    UINT32 chnNum = BspGetTxChannel();

    INPUT_POINTER_CHECK(pPowDbfs);
    INPUT_PARAM_RANGE_CHECK(bspChn, BSP_HALADAPT_IC_CHAN_MAX_NUM);

    dbgInfoEx("[%s]: bspChn:%d, FwdTssi = %2d RevTssi = %2d FwdFb = %2d RevFb = %2d\n",__FUNCTION__, bspChn,
            sTxFwdRevPowerVal[bspChn].tFwdPow.ifTssiPow, sTxFwdRevPowerVal[bspChn].tRevPow.ifTssiPow,
            sTxFwdRevPowerVal[bspChn].tFwdPow.fbPow, sTxFwdRevPowerVal[bspChn].tRevPow.fbPow);

    if((PA_UNNORMAL == BspGetPaNormalFlag(bspChn)) && (1 == BspGetTddChanModeFlag(bspChn)))
    {
        CalFwdRevDbfs(bspChn, &sTxFwdRevPowerVal[bspChn], pPowDbfs);
        for(loopChn = 0; loopChn < min(chnNum, BSP_HALADAPT_IC_CHAN_MAX_NUM); loopChn++)
        {
            if((1 == BspGetPaOnUnNormalFlag(loopChn)) && (1 == BspGetTddChanModeFlag(loopChn)))
            {
                CalFwdRevDbfs(loopChn, &sTxFwdRevPowerVal[loopChn], pPowDbfs);
                break;
            }
        }
    }
    else
    {
        CalFwdRevDbfs(bspChn, &sTxFwdRevPowerVal[bspChn], pPowDbfs);
    }

    dbgInfoEx("[%s]fwdTssi = %d, fwdFb = %d, revTssi = %d, revFb = %d \n",
               __FUNCTION__, pPowDbfs->tFwdPow.ifTssiPow, pPowDbfs->tFwdPow.fbPow,
               pPowDbfs->tRevPow.ifTssiPow, pPowDbfs->tRevPow.fbPow);

    return BSP_OK;
}
/* Ended by AICoder, pid:s8c01f9aa5t6545148d90a9790b63543f9a2fd15 */

/* Started by AICoder, pid:x1e3827ccce30c7147b30ace507f164b4e623215 */
UINT32 BspGetTxIfTssiDbm(UINT32 bspChn, INT32 *txIfTssiDbm)
{
    UINT32 retVal = BSP_OK;
    INT32 iTxIfTssiDbm = 0;
    INT32 txGain = 0;
    INT32 targetGainDelta = 0;
    T_TxPow tPowDbfs = {0};

    INPUT_POINTER_CHECK(txIfTssiDbm);

    retVal = BspGetTxPowerDbfs(bspChn, &tPowDbfs);;
    if(BSP_OK != retVal)
    {
        dbgInfoEx("[%s] BspGetTxPowerDbfs failed\n", __FUNCTION__);
        return retVal;
    }

    retVal = _BspGetIfTssiDbmGain(bspChn, &txGain, COMPS_BY_FREQ_POINT_TYPE);
    if((BSP_OK == BspGetTargetGainDelta(bspChn, &targetGainDelta)) && (0 != targetGainDelta))
    {
        txGain = txGain - targetGainDelta;
    }
    iTxIfTssiDbm = tPowDbfs.tFwdPow.ifTssiPow + txGain;

    *txIfTssiDbm = iTxIfTssiDbm;
    if (iTxIfTssiDbm < BspGetPowThreshhold(bspChn, TSSI0_THRESHOLD))
    {
        if(1 == BspGetPowerBelow0dbm())/*额定功率小于0dbm的规格，功率显示和上报需要对0dbm特殊处理*/
        {
            *txIfTssiDbm = -15000;
        }
        else
        {
            *txIfTssiDbm = 0;
        }
    }
    dbgInfoEx("[%s] tPowDbfs.tFwdPow.ifTssiPow:%d, txGain:%d\n", __FUNCTION__, tPowDbfs.tFwdPow.ifTssiPow, txGain);

    return retVal;
}
/* Ended by AICoder, pid:x1e3827ccce30c7147b30ace507f164b4e623215 */

/* Started by AICoder, pid:74226uf683y08d714dba0a7f4000a7606a03f72a */
UINT32 BspGetFwdPowerDbm(UINT32 bspChn, INT32 *fwdDbm)
{
    UINT32 retVal = BSP_OK;
    INT32 fwdGain = 0;
    INT32 fwdIfTssiDbm =0;
    INT32 txIfTssiDbm = 0;
    INT32 deltaDbm = 0;
    UINT32 RandData = 0;
    T_TxPow tPowDbfs = {0};

    INPUT_POINTER_CHECK(fwdDbm);

    retVal = BspGetTxPowerDbfs(bspChn, &tPowDbfs);
    if(BSP_OK != retVal)
    {
        dbgInfoEx("[%s] BspGetTxPowerDbfs failed\n", __FUNCTION__);
        return retVal;
    }

    retVal = BspGetFwdDbmDelta(bspChn, &deltaDbm);
    retVal |= _BspGetFwdDbmGain(bspChn, &fwdGain, COMPS_BY_FREQ_POINT_TYPE);
    fwdIfTssiDbm = tPowDbfs.tFwdPow.fbPow - fwdGain + deltaDbm;

    *fwdDbm = fwdIfTssiDbm;
    if(fwdIfTssiDbm < BspGetPowThreshhold(bspChn, FWD_THRESHOLD))
    {
        if(1 == BspGetPowerBelow0dbm())  /*额定功率小于0dbm的规格，功率显示和上报需要对0dbm特殊处理*/
        {
            *fwdDbm = -15000;
        }
        else
        {
            *fwdDbm = 0;
        }
    }
    dbgInfoEx("[%s] bspChn'%d, tPowDbfs.tFwdPow.fbPow'%d, fwdGain'%d, deltaDbm'%d, fwdIfTssiDbm'%d\n",
            __FUNCTION__, bspChn, tPowDbfs.tFwdPow.fbPow, fwdGain, deltaDbm, fwdIfTssiDbm);

    if(BspGetPaNormalFlag(bspChn) == PA_UNNORMAL)
    {
        if(BspGetPaSwitch(bspChn) == SWITCH_OFF)
        {
            *fwdDbm = 0;
        }
        else
        {
            BspGetTxIfTssiDbm(bspChn, &txIfTssiDbm);
            if(txIfTssiDbm <= 0)
            {
                *fwdDbm = txIfTssiDbm;
            }
            else
            {
                BspGetRandomData(1, &RandData);
                *fwdDbm = txIfTssiDbm + RandData%41 - 20;
            }
            dbgInfoEx("%s: TxIfTssiDbm[%d], RandData[%d], fwdDbm[%d]\n",__FUNCTION__, txIfTssiDbm, RandData, *fwdDbm);
        }
    }

    return retVal;
}
/* Ended by AICoder, pid:74226uf683y08d714dba0a7f4000a7606a03f72a */

/**************************************************************************
 * 函数名称: BspGetBnadVswrFlag
 * 功能描述: 获取整机支持是否支持频段级矢量驻波检测
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetBandVswrFlag(VOID)
{
    return s_supportBandVswrFlag;
}

/**************************************************************************
 * 函数名称: BspGetBnadVswrFlag
 * 功能描述: 设置整机支持是否支持频段级矢量驻波检测
 * 返 回 值: 1:支持, 0:不支持
 * 其它说明: 无
  **************************************************************************/
VOID BspSetBandVswrFlag(UINT32 flag)
{
    s_supportBandVswrFlag = flag;
}

/* Started by AICoder, pid:ib0e2i1e38vd2ce140790a81a0901b237d521429 */
/**************************************************************************
 * 函数名称: BspGetCancelScalarVswrFlag
 * 功能描述: 获取整机是否取消频段级矢量驻波检测
 * 返 回 值: 1:取消, 0:不取消
 * 其它说明: 无
  **************************************************************************/
UINT32 BspGetCancelScalarVswrFlag(VOID)
{
    return s_cancelScalarVswrFlag;
}

/**************************************************************************
 * 函数名称: BspSetCancelScalarVswrFlag
 * 功能描述: 设置整机是否支持频段级矢量驻波检测
 * 返 回 值: 1:取消, 0:不取消
 * 其它说明: 无
  **************************************************************************/
VOID BspSetCancelScalarVswrFlag(UINT32 flag)
{
    s_cancelScalarVswrFlag = flag;
}
/* Ended by AICoder, pid:ib0e2i1e38vd2ce140790a81a0901b237d521429 */

UINT32 BspGetPimChanStatus(UINT32 bspChan)
{
    return BSP_OK;
}

/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : powerctrl_ic4_property.c
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供rru的功率控制模块特性功能的实现
 * 注意事项 : 无
 * 作    者 : heruihua 10288704
 * 创建日期 : 2020-12-10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */
#include "powerctrl_ic4_2_property.h"
#include "powerctrl_ic4_2_private.h"

/* static UINT32 s_validCarrNum [6] = {0}; //6种制式,参考BspGetRadioStandardIdx
static UINT32 BspSetDlSymHeadGenEnErrCnt[4] = {0}; */
static FUNC_SET_FPGA_DELAY pSetFpgaDelay = NULL;
/* static UINT32 g_ulChannelDtxPowerSaveFlag[MAX_TX_CHANNEL] = {0}; */

/*todo:初始化dtX功能寄存器*/
UINT32 BspCfgDtxParaInit(UINT32 chipId)
{
    //return IcHalApiDtxParaInit(chipId);
    return BSP_OK;
}

//设置fpga时延配置回调函数
VOID BspSetFpgaDtxDelay(FUNC_SET_FPGA_DELAY pFuncCallBack)
{
    pSetFpgaDelay = pFuncCallBack;
}

UINT32 BspSetFpgaDtxEn(UINT32 bspChan, UINT32 on)
{
    return BSP_OK;
}

VOID BspSetSymbolEn(VOID)
{
    /* return BSP_OK; */
}

/*******************************************************************************
 * 函数名称: BspSetDtxEnFlag(*)
 * 功能描述: DTX使能控制
 * 输入参数: bspChan    - BSP通道号
 *           on - 使能标志, 0:去使能, 1:使能
 * 输出参数: 无
 * 返 回 值: BSP_OK- 成功; 其它- 失败
 * 其它说明: 无
 *------------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), wangfangli @2019-07-29 19:21:00 创建
 *------------------------------------------------------------------------------
 */
UINT32 BspChkRadioMod(UINT32 radioMod)
{
    UINT32 loopIdx = 0;
    UINT32 items = 0;
    UINT32 radioRef[6] = {
                                  BSP_RADIO_STANDARD_LTE_TDD,
                                  BSP_RADIO_STANDARD_LTE_FDD,
                                  BSP_RADIO_STANDARD_5G,
                                  BSP_RADIO_STANDARD_FDD_5G,
                                  BSP_RADIO_STANDARD_UMTS,
                                  BSP_RADIO_STANDARD_NB_IOT};

    items = sizeof(radioRef) / sizeof(sizeof(radioRef[0]));

    for (loopIdx = 0; loopIdx < items;loopIdx++)
    {
        if (radioMod == radioRef[loopIdx])
        {
            break;
        }
    }

    if (loopIdx >= items)
    {
        return BSP_ERROR;
    }

    return BSP_OK;
}

UINT32 BspGetRadioStandardIdx(UINT32 radioMod, UINT32 *pIdx)
{
    UINT32 loopIdx = 0;
    UINT32 items = 0;
    UINT32 radioRef[6] = {
                                  BSP_RADIO_STANDARD_LTE_TDD,
                                  BSP_RADIO_STANDARD_LTE_FDD,
                                  BSP_RADIO_STANDARD_5G,
                                  BSP_RADIO_STANDARD_FDD_5G,
                                  BSP_RADIO_STANDARD_UMTS,
                                  BSP_RADIO_STANDARD_NB_IOT};

    INPUT_POINTER_CHECK(pIdx);

    items = sizeof(radioRef) / sizeof(sizeof(radioRef[0]));

    for (loopIdx = 0; loopIdx < items;loopIdx++)
    {
        if (radioMod == radioRef[loopIdx])
        {
            *pIdx = loopIdx;
            break;
        }
    }

    if (loopIdx >= items)
    {
        return BSP_ERROR;
    }


    return BSP_OK;
}

UINT32 BspGetValidCarrInfo(UINT32 dir, UINT32 bspChn,UINT32 radioMod, T_DifValidCarrInfo *pValidCarrInfo)
{
#if 0 //DPDIC4.0暂时不使用，待后续确认
    UINT32 chipId = 0;
    UINT32 ret = BSP_OK;
    UINT32 difChan = 0;
    UINT32 maxCarrNum = 0;
    UINT32 bspCarrNo  =0;
    UINT32 carrMode =  0;
    UINT32 carrNo = 0;
    UINT32 index = 0;
    UINT32 chnNum = 0;
    T_BspAdaptOneChanCarrInfo *pDifCarrInfo = NULL;
    T_BspAdaptOneChanCarrInfo *difCarrInfo = NULL;

    INPUT_POINTER_CHECK(pValidCarrInfo);

    if (dir > TX)
    {
        dbgErr("[%s]dir =%dx is invalid \n" ,__FUNCTION__, dir);
        return BSP_ERROR;
    }

    memset(s_validCarrNum, 0, sizeof(s_validCarrNum));
    memset(pValidCarrInfo, 0, sizeof(T_DifValidCarrInfo));

    ret = BspChkRadioMod(radioMod);
    if (BSP_OK != ret)
    {
        dbgErr("[%s]radioMod =%#x is invalid \n" ,__FUNCTION__, radioMod);
        return BSP_ERROR;
    }

    pDifCarrInfo = (T_BspAdaptOneChanCarrInfo *)malloc(sizeof(T_BspAdaptOneChanCarrInfo));
    if (pDifCarrInfo == NULL)
    {
        dbgErr("[%s]:malloc pDifCarrInfo failed \n");
        return BSP_ERROR;
    }

    memset(pDifCarrInfo, 0, sizeof(T_BspAdaptOneChanCarrInfo));

    for (bspChn = 0; bspChn < chnNum; bspChn++)
    {
        ret = BspGetDifInfoByBspChn(bspChn, dir, &chipId, &difChan);
        if (BSP_OK != ret)
        {
            free(pDifCarrInfo);
            dbgErr("[%s] error :bspChan'%d BspGetDifInfoByBspChn Get Error!\n",__FUNCTION__, bspChn);
            return ret;
        }

        difCarrInfo = BspHalAdaptGetDifChanCarrInfo(TX, difChan);
        if (NULL == difCarrInfo)
        {
            dbgErr("[%s]difChan'%d difCarrInfo Get Error!\n",__FUNCTION__, difChan);
            return BSP_ERROR;
        }
        memcpy_s(pDifCarrInfo, sizeof(pDifCarrInfo), difCarrInfo, sizeof(difCarrInfo));
        maxCarrNum = pDifCarrInfo->carrNum;
        if (maxCarrNum >= BSP_MAX_BANK_NUM_ONEBLOCK)
        {
            dbgErr("[%s]error : maxCarrNum is %d \n",__FUNCTION__, maxCarrNum);
            free(pDifCarrInfo);
            return BSP_ERROR;
        }

        for (bspCarrNo = 0; bspCarrNo < maxCarrNum; bspCarrNo++)
        {
            carrMode = pDifCarrInfo->oneCarrInfo[bspCarrNo].carrRadio;
            carrNo = pDifCarrInfo->oneCarrInfo[bspCarrNo].difCarrNo;
            if (radioMod == carrMode)
            {
                BspGetRadioStandardIdx(radioMod, &index);
                pValidCarrInfo->carrInfo[s_validCarrNum[index]] = carrNo;
                s_validCarrNum[index]++;
            }
        }
        pValidCarrInfo->carrNum = s_validCarrNum[index];

    }
    free(pDifCarrInfo);
#endif    
    return BSP_OK;
}

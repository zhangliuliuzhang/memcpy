/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : BSP
* 文件名称 : powerctrl_comps_ic4.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者 :   190699
* 创建日期 : 2017-2-27 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 190699
* 修改日戳: 2017-2-27 14:45:34
* 变更说明: 创建文件
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10288704
* 修改日戳: 2020-11-19
* 变更说明: 基于IC3.0代码完成IC4.0功率控制代码
*----------------------------------------------------------------------------
*/

#include <math.h>
#include "bsppub.h"
#include "bspcomm.h"
#include "exprn.h"
#include "rftable.h"
#include "rruinfo.h"
#include "powerctrlcommon.h"
#include "powerctrl_comps_ic4_2.h"
#include "chnmap_a.h"
#include "vxadp.h"
#include "freqcfgapi.h"
#include "funccommon_chncfg.h"
#include "gainctrl_ic4_2.h"
#include "att_common.h"
#include "devdrv_att.h"
#include "ichaladaptbspapi.h"
#include "boardid.h"
#include "gainctrlcommon.h"
#include "freqcfgcommon.h"
#include "devdrv_tempsensor.h"
#include "chnmap_a.h"
#include "pa_ic4_2_ctrl.h"
#include "powerctrl_ic4_2.h"
#include "funccommon_a.h"
#include "funccommon_fpga.h"

#define _CALIB_TBL_GAIN_LIST(type,comps)  {type,#comps,PowCompsData.comps}

#define _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pp)   \
{\
    if (NULL == (pp))\
    {\
        \
        return BSP_ERROR;\
    }\
}

#define _NUM_ZERO_CHECK(num)   \
{\
    if (0 == (num))\
    {\
        \
        return BSP_ERROR;\
    }\
}
#define _LINEAR_INSERT(x,x1,y1,x2,y2) ((INT32)(((FLOAT)((y2) - (y1)) / ((x2) - (x1) + 0.000001)) * ((x) - (x1)) + (y1)+0.5))
#define PA_DRAIN_ADJ_SEARCH_FAILED           0
#define PA_DRAIN_ADJ_PA_GAIN_DEFAULT         0              //Pa Gain在检索失败的情况下默认返回0
#define CALITBL_COMPS_PROCESS_PRIORITY       (130)          /* 注册优先级130对应linux优先级97-130/3 = 54*/
#define TRXTEMP_CHECK(ulMsType, ulTblIndex)                                        \
    if((TBL_CHAN_S_TPYE == ulMsType)&&((ulTblIndex > E_RFTBL_MS)))                 \
    {/*拉远通道 在子端无单板温补,温补只体现母端的链路 这里的E_RFTBL_MS - 1指的是校准表编号*/   \
        *plVal = 0;                                                                \
        return BSP_OK;                                                             \
     }                                                                             \

 #define PATEMP_CHECK(ulMsType, ulTblIndex)                                          \
    if((TBL_CHAN_S_TPYE == ulMsType)&&(ulTblIndex <= E_RFTBL_MS))                    \
    {   /*拉远通道(2 3) 不能取母端的pa温补表 会通道越界 拉远通道PA温补只体现在子端*/            \
        *plVal = 0;                                                                  \
        return BSP_OK;                                                               \
    }                                                                                \
    if(TBL_CHAN_M_TPYE == ulMsType)                     \
    {/*母端通道pa温补只有一个*/                                                          \
        dbgInfoEx("ulTblIndex %d\n", ulTblIndex);  \
        ulTblIndex = 0;                                                              \
    }                                                                                \

static UINT32 glPwrAverageRat    = PWR_AVERAGE_RATIO;       //设置默认峰均比为6.5
static INT32  glOpenLoopCaliPaGain[CHAN_MAX_NUM_SOC] = {0}; //开环校准与静态调压相关部分

static INT32  s_gCaliModifyGain[BSP_MAX_TX_CHAN][TBL_TYPE_MAX] = {0}; //单板修改校准表参数0:TxGain;1:RxRssi;2:RxRssi_D;3:Fwd;4:Rev;37:DeltTxGain;38:DeltRxGain

static INT32  glOpenLoopCaliCableGain[BSP_IC42_MAX_TX_CHAN_NUM] = {0}; //开环校准与静态调压相关部分
static T_DefDlPowCalPara *s_pTDlDefPowCalPara = NULL;
static UINT32              ulDlParaNum         = 0;
static T_DefUlPowCalPara *s_pTUlDefPowCalPara = NULL;
static T_DefUlTargetGain *s_pTUlDefTargetGain = NULL;
static UINT32              ulUlTargetGainNum         = 0;
static UINT32              ulUlParaNum         = 0;
#if 0
static T_DefAcVswrPara   *s_pTAcVswrDefPara   = NULL;
static UINT32              ulAcVswrParaNum      = 0;
static UINT32              s_ulPaTempType      = 0;
#endif
static INT32               s_rxPowCaliFixAttGain = 0;
#if 0
T_TrxTempAlmThreshold g_tTrxTempAlmThreshold ={0,0,0};
#endif
static UINT32 BoardTempNode[RRU_MAX_BOARD_NODE_NUM] = {0};    /* 单板节点温度参数 */
static UINT32 sCalibTblCompsPeriod = 10000; /* 10s周期 */
static UINT32 sulTempCompsThreadSwitch = SWITCH_ON;
static TCompsTemp stCompsTemp = {0};    /* 温度参数 */
static UINT32   s_PcGainFileType = 0;   /* 0: PaDrainAdj.txt; 1: PaEngerSavingAdj.txt   */
static INT32 s_txCaliProcAttVal[BSP_MAX_TX_CHAN] = {0};

static INT32 salPowerAdjGain[BSP_MAX_TX_CHAN] = {250,250,250,250,250,250,250,250,250,250,250,250,250,250,250,250};
static INT32 s_alOverTempPowerAdjGain[BSP_MAX_TX_CHAN] = {0};
UINT32 g_defaultChanCenterFreqFlag = NO_SUPPORT;
static UINT32     s_tempThresholdFromCali    = 0;
static T_CaliUpdateInfo s_tCaliUpdateInfo = {0};
pOutputPowerReduceFunc pGetPowerReduceCall = NULL;


static T_DefLnaOffGain *s_pLnaOffGain = NULL;
static UINT32     s_lnaGainParaNum    = 0;
static INT32  s_pLna2ByPassGain[BSP_MAX_TX_CHAN] = {0};
UINT32 g_ulRfDlyMeasResult[BSP_IC42_MAX_TX_CHAN_NUM] = {0};

static INT32 s_slaveTxGain[BSP_MAX_TX_CHAN] = {0};
static INT32 s_slaveRxGain[BSP_MAX_TX_CHAN] = {0};
static INT32 s_slaveTxFwd[BSP_MAX_TX_CHAN] = {0};
UINT32 g_ulSlavePortCableLen[BSP_IC42_MAX_TX_CHAN_NUM] = {0};
static INT32 s_TargetGainOffset = 0;
static FUNC_CHANGE_RF_CFG_DIR s_pChangeRfCfgDirFunc = NULL;

#define BSP_THRESHOLD_DEFAULT_MAX_NUM    30
T_ThresholdPara g_tAlmPara[BSP_THRESHOLD_DEFAULT_MAX_NUM] =
{
    {BSP_THRESHOLD_ID_OVER_TEMPER, E_TEMP_TYPE_TRX, E_THRESHOLD_TYPE_OVERTEMP, 900, 880},
    {BSP_THRESHOLD_ID_OVER_TEMPER1, E_TEMP_TYPE_TRX1, E_THRESHOLD_TYPE_OVERTEMP, 900, 880},
    {BSP_THRESHOLD_ID_OVER_TEMPER2, E_TEMP_TYPE_TRX2, E_THRESHOLD_TYPE_OVERTEMP, 900, 880},
    {BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER, E_TEMP_TYPE_TRX, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 870, 840},
    {BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER1, E_TEMP_TYPE_TRX1, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 870, 840},
    {BSP_THRESHOLD_ID_SLIGHTOVER_TEMPER2, E_TEMP_TYPE_TRX2, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 870, 840},
    {BSP_THRESHOLD_ID_UNDER_TEMPER, E_TEMP_TYPE_NUM, E_THRESHOLD_TPYE_NUM, -400, -350},
    {BSP_THRESHOLD_ID_OVER_PA_TEMPER, E_TEMP_TYPE_PA, E_THRESHOLD_TYPE_OVERTEMP, 1040, 1020},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PA_TEMPER, E_TEMP_TYPE_PA, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 1010, 980},
    {BSP_THRESHOLD_ID_OVER_PWR_TEMPER,  E_TEMP_TYPE_PWR, E_THRESHOLD_TYPE_OVERTEMP,  1020, 980},
    {BSP_THRESHOLD_ID_OVER_PWR1_TEMPER, E_TEMP_TYPE_PWR1, E_THRESHOLD_TYPE_OVERTEMP, 1020, 980},
    {BSP_THRESHOLD_ID_OVER_PWR2_TEMPER, E_TEMP_TYPE_PWR2, E_THRESHOLD_TYPE_OVERTEMP, 1020, 980},
    {BSP_THRESHOLD_ID_OVER_PWR3_TEMPER, E_TEMP_TYPE_PWR3, E_THRESHOLD_TYPE_OVERTEMP, 1020, 980},
    {BSP_THRESHOLD_ID_OVER_PWR4_TEMPER, E_TEMP_TYPE_PWR4, E_THRESHOLD_TYPE_OVERTEMP, 1020, 980},
    {BSP_THRESHOLD_ID_OVER_PWR5_TEMPER, E_TEMP_TYPE_PWR5, E_THRESHOLD_TYPE_OVERTEMP, 1020, 980},
    {BSP_THRESHOLD_ID_OVER_PWR6_TEMPER, E_TEMP_TYPE_PWR6, E_THRESHOLD_TYPE_OVERTEMP, 1020, 980},
    {BSP_THRESHOLD_ID_OVER_PWR7_TEMPER, E_TEMP_TYPE_PWR7, E_THRESHOLD_TYPE_OVERTEMP, 1020, 980},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR_TEMPER, E_TEMP_TYPE_PWR, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR1_TEMPER, E_TEMP_TYPE_PWR1, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR2_TEMPER, E_TEMP_TYPE_PWR2, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR3_TEMPER, E_TEMP_TYPE_PWR3, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR4_TEMPER, E_TEMP_TYPE_PWR4, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR5_TEMPER, E_TEMP_TYPE_PWR5, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR6_TEMPER, E_TEMP_TYPE_PWR6, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_SLIGHTOVER_PWR7_TEMPER, E_TEMP_TYPE_PWR7, E_THRESHOLD_TYPE_SLIGHT_OVERTEMP, 950, 910},
    {BSP_THRESHOLD_ID_OVER_PWR_LET0_TEMPER, E_TEMP_TYPE_NUM, E_THRESHOLD_TPYE_NUM, 950, 850},
    {BSP_THRESHOLD_ID_OVER_PWR_LET1_TEMPER, E_TEMP_TYPE_NUM, E_THRESHOLD_TPYE_NUM, 950, 850},
    {BSP_THRESHOLD_ID_OVER_PWR_LET2_TEMPER, E_TEMP_TYPE_NUM, E_THRESHOLD_TPYE_NUM, 950, 850},
    {BSP_THRESHOLD_ID_OVER_PWR_LET3_TEMPER, E_TEMP_TYPE_NUM, E_THRESHOLD_TPYE_NUM, 950, 850},
};

INT32 g_txDestGainNcr[3][MAX_TX_CHAN] = {0};
INT32 g_rxDestGainNcr[3][MAX_RX_CHAN] = {0};
INT32 g_fbDestGainNcr[3][MAX_RX_CHAN] = 
{
    {0},
    {0},
    {-3500, -3500, -4500, -4500, -3500, -3500, -4800, -4800},
};
static FUNC_GET_DEST_GAIN s_pGetTxDestGainFunc = NULL;
static FUNC_GET_DEST_GAIN s_pGetRxDestGainFunc = NULL;
static FUNC_GET_DEST_GAIN s_pGetFbDestGainFunc = NULL;
UINT32 BspGetTxDestGainCallBackInit(FUNC_GET_DEST_GAIN pCallBackFunc)
{
    s_pGetTxDestGainFunc = pCallBackFunc;
   return BSP_OK;
}
UINT32 BspGetRxDestGainCallBackInit(FUNC_GET_DEST_GAIN pCallBackFunc)
{
    s_pGetRxDestGainFunc = pCallBackFunc;
   return BSP_OK;
}
UINT32 BspGetFbDestGainCallBackInit(FUNC_GET_DEST_GAIN pCallBackFunc)
{
    s_pGetFbDestGainFunc = pCallBackFunc;
   return BSP_OK;
}

/* Started by AICoder, pid:gc4555af7cf051f14c59085d70cfa6125cf370d1 */
UINT32 BspChangeRfCfgDirCallBackInit(FUNC_CHANGE_RF_CFG_DIR pCallBackFunc)
{
    s_pChangeRfCfgDirFunc = pCallBackFunc;
    return BSP_OK;
}
/* Ended by AICoder, pid:gc4555af7cf051f14c59085d70cfa6125cf370d1 */

/* Started by AICoder, pid:x07bakde5544aab14bd50b380085f21fb6e7d847 */
/**
 * @brief 更改RF配置方向。
 *
 * 该函数在非_WSP_WITH_WFS编译条件下调用外部更改RF配置方向的函数。
 *
 * @param chan 通道号。
 */
VOID ChangeRfCfgDir(UINT32 chan)
{
    #ifndef _BSP_WITH_WFS

    if (s_pChangeRfCfgDirFunc != NULL)
    {
        s_pChangeRfCfgDirFunc(chan);
    }
    #endif
}
/* Ended by AICoder, pid:x07bakde5544aab14bd50b380085f21fb6e7d847 */

UINT32 BspSetTxDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 destgainvalue)
{
    g_txDestGainNcr[dir][rfChan] = destgainvalue;
    return BSP_OK;
}
UINT32 BspGetTxDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 *destgainvalue)
{
    *destgainvalue = g_txDestGainNcr[dir][rfChan];
    return BSP_OK;
}
UINT32 BspSetRxDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 destgainvalue)
{
    g_rxDestGainNcr[dir][rfChan] = destgainvalue;
    return BSP_OK;
}
UINT32 BspGetRxDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 *destgainvalue)
{
    *destgainvalue = g_rxDestGainNcr[dir][rfChan];
    return BSP_OK;
}
UINT32 BspSetFbDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 destgainvalue)
{
    g_fbDestGainNcr[dir][rfChan] = destgainvalue;
    return BSP_OK;
}
UINT32 BspGetFbDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 *destgainvalue)
{
    *destgainvalue = g_fbDestGainNcr[dir][rfChan];
    return BSP_OK;
}

UINT32 BspGetDestGainCallBackInit(VOID)
{
    UINT32 ret = BSP_OK;

    ret |= BspGetTxDestGainCallBackInit(BspGetTxDestGainNcr);
    ret |= BspGetRxDestGainCallBackInit(BspGetRxDestGainNcr);
    ret |= BspGetFbDestGainCallBackInit(BspGetFbDestGainNcr);

    return ret;
}
UINT32 BspSetDestGain(UINT32 fwddir, UINT32 dir, UINT32 rfChan, INT32 destgainvalue)
{
    UINT32 ret = BSP_OK;
    if(dir == TX)//0上行，1下行，反馈是2;FB2/FB3/FB6/FB7 对应通道号rfChan就填2,3,6,7
    {
        ret = BspSetTxDestGainNcr(dir, rfChan, destgainvalue);
    }
    else if(dir == RX)
    {
        ret = BspSetRxDestGainNcr(dir, rfChan, destgainvalue);
    }
    else
    {
        ret = BspSetFbDestGainNcr(dir, rfChan, destgainvalue);
    }
    return ret;
}

/* Started by AICoder, pid:x1e56t89074ae9014df80b1d70c2ea277756f251 */
/**************************************************************************
 * 函数名称: BspGetChnGain(*)
 * 功能描述: APP诊断组件调用，获取通道增益
 * 输入参数: fwddir：大方向，dir：小方向，rfChan：通道号
 * 输出参数: pGain：增益值，单位：0.01dbm
 * 返 回 值: BSP_OK，BSP_ERROR(非法入参)
 * 其它说明:
 * 修改日期       版本号           修改人    修改内容
 * ------------------------------------------------------------------------
 * 2025年03月21日        创建
 **************************************************************************/
UINT32 BspGetChnGain(UINT32 fwddir, UINT32 dir, UINT32 rfChan, INT32 *pGain)
{
    UINT32 linkdir = 0;
    UINT32 ret = 0;
    INPUT_POINTER_CHECK(pGain);

    if((fwddir > LINK_TYPE_BS_2_UE) || (dir > PRX) || (rfChan >= BspGetTxChanNum()))
    {
        dbgErr("[%s] input error, fwddir:%d, dir:%d, rfChan:%d\n", __FUNCTION__, fwddir, dir, rfChan);
        *pGain = INVALID_CHN_GAIN;
        return BSP_ERROR;
    }

    //根据王翔方案：大方向、小方向与通道号匹配不上的增益配置无效值
/* Started by AICoder, pid:pe145n0b4ba977414b380ac4b0ecab082cf85ae2 */
    if(BSP_OK == BspGetFwdDirByRfInfo(rfChan, dir, &linkdir))
    {
        if(linkdir != fwddir)
        {
            *pGain = INVALID_CHN_GAIN;
            dbgInfoEx("[%s][%d] fwddir:%d, dir:%d, rfChan:%d, gain:%d\n", __FUNCTION__, __LINE__, fwddir, dir, rfChan, *pGain);
            return BSP_OK;
        }
    }
    else
    {
        dbgErr("[%s] Bsp Get Fwd Dir By RfInfo Error\n", __FUNCTION__);
        *pGain = INVALID_CHN_GAIN;
        return BSP_ERROR;
    }
/* Ended by AICoder, pid:pe145n0b4ba977414b380ac4b0ecab082cf85ae2 */
    if(dir == TX)
    {
        ret = BspGetTxDestGainNcr(dir, rfChan, pGain);
    }
    else if(dir == RX)
    {
        ret = BspGetRxDestGainNcr(dir, rfChan, pGain);
    }
    else
    {
        ret = BspGetFbDestGainNcr(dir, rfChan, pGain);
    }

    dbgInfoEx("[%s][%d] fwddir:%d, dir:%d, rfChan:%d, gain:%d\n", __FUNCTION__, __LINE__, fwddir, dir, rfChan, *pGain);
    return ret;
}

UINT32 testgetchngain(UINT32 fwddir, UINT32 dir, UINT32 rfChan)
{
    INT32 gain = 0;
    return BspGetChnGain(fwddir, dir, rfChan, &gain);
}

UINT32 testgetallchngain(VOID)
{
    UINT32 chnList0[4] = {0,1,4,5};
    UINT32 chnList1[4] = {2,3,6,7};
    UINT32 ret = 0;
    UINT32 i = 0;
    UINT32 j = 0;
    UINT32 k = 0;
    INT32 gain = 0;

    for(i = 0; i <= LINK_TYPE_BS_2_UE; i++)
    {
        for(j = 0; j <= LINK_TYPE_TX; j++)
        {
            for(k = 0; k < 4; k++)
            {
                if(1 == (i + j))
                {
                    ret |= BspGetChnGain(i, j, chnList0[k], &gain);
                }
                else
                {
                    ret |= BspGetChnGain(i, j, chnList1[k], &gain);
                }
            }
        }
    }

    return ret;
}
/* Ended by AICoder, pid:x1e56t89074ae9014df80b1d70c2ea277756f251 */

UINT32 BspRegisterSetPowerReduce(pOutputPowerReduceFunc pGetPowerReduceFunc)
{
    pGetPowerReduceCall = pGetPowerReduceFunc;
    return BSP_OK;
}

VOID BspSetTempThresholdFromCaliFlag(UINT32 flag)
{
    s_tempThresholdFromCali = flag;
}
UINT32 BspGetTempThresholdFromCaliFlag(VOID)
{
    return s_tempThresholdFromCali;
}

UINT32 BspSetTempCaliUpdateInfo(T_CaliUpdateInfo *ptCaliUpdaInfo)
{
	INPUT_POINTER_CHECK(ptCaliUpdaInfo);
	memcpy_s(&s_tCaliUpdateInfo, sizeof(T_CaliUpdateInfo), ptCaliUpdaInfo, sizeof(T_CaliUpdateInfo));
	return BSP_OK;
}

INT32 BspRxOpenLoopPowCailFixAttGainInit(INT32 attGain)
{
    return (s_rxPowCaliFixAttGain = attGain);
}

INT32 BspGetRxPowCaliFixAttGain(VOID)
{
    return s_rxPowCaliFixAttGain;
}

UINT32 BspSetCaliModefyGain(UINT32 caliChan, UINT32 caliType, INT32 gainValue)
{
    if(caliChan >= BSP_MAX_TX_CHAN || caliType >= TBL_TYPE_NUM)
    {
        return BSP_ERROR;
    }

    s_gCaliModifyGain[caliChan][caliType] = gainValue ;
    return BSP_OK;
}

UINT32 BspSetTxCaliProcAttVal(UINT32 chan,INT32 attValue)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    s_txCaliProcAttVal[chan] = attValue;

    return BSP_OK;
}

INT32 BspGetTxCaliProcAttVal(UINT32 chan)
{
    if(chan >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    return s_txCaliProcAttVal[chan];
}

VOID BspSetChanCenterFreqFlag(UINT32 flag)
{
    g_defaultChanCenterFreqFlag = flag;
}

BOOL BspIsSuportDefaultChanCenterFreq(VOID)
{
    if(g_defaultChanCenterFreqFlag == SUPPORT)
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

/*将每个载波频点的原始插损值保存一份  增益补偿时需要把线缆的增益补进去，用这里算的值  不能用高层的，高层有运算（步进）和取舍*/
UINT32 BspUpdateSlaveCableGain(UINT32 bspChn, INT32 loss)
{

    if(bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    dbgInfo("%s chan %d loss %d\n", __FUNCTION__, bspChn, loss);
    BspLog(LOG_LEVEL_0, "%s chan %d loss %d\n", __FUNCTION__, bspChn, loss);
    glOpenLoopCaliCableGain[bspChn] = loss;

    return BSP_OK;
}

/*子端重新上电需要清除原有值 为下一次做准备*/
UINT32 BspClrSlaveCableGain(UINT32 bspChn)
{
    if(bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    glOpenLoopCaliCableGain[bspChn] = 0;

    return BSP_OK;
}

UINT32 g_ulSlaveChnLossRec[MAX_SLAVEPORT_NUM] = {0xff,0xff,0xff};
/*高层在一轮插损完成之后调用*/
UINT32 BspResetSlavePortLossRec(UINT32 portId)
{
    if(portId >= MAX_SLAVEPORT_NUM)
    {
        return BSP_ERROR;
    }
    g_ulSlaveChnLossRec[portId] = 0xff;
    BspLog(LOG_LEVEL_0, "%s port %d \n", __FUNCTION__, portId);

    return BSP_OK;
}
/*针对子端二次发起测量要把上次保存的通道插损的结果清除掉  不能影响第二次*/
UINT32 BspClrSlavePortLossInfo(UINT32 chan)
{
    UINT32 anotherChan = 0;
    UINT32 retVal =0;
    UINT32 slaveChn = 0;
    UINT32 portId = 0;

    retVal = BspGetAnotherSlaveChnByBspChn(chan, TX, &anotherChan);
    retVal |= BspGetPortSlaveChnByBspChn(chan, TX, &slaveChn);
    retVal |= BspGetPortIdByBspChn(chan, TX, &portId);
    dbgInfo("%s chan %d slaveChn %d portId %d\n", __FUNCTION__, chan, slaveChn, portId);
    if(BSP_OK != retVal)
    {
         return BSP_ERROR;
    }
    if(portId >= MAX_SLAVEPORT_NUM)
    {
        return BSP_ERROR;
    }
    dbgInfo("%s chan %d slaveChn %d g_ulSlaveChnLossRec[portId] %d\n", __FUNCTION__, chan, slaveChn, g_ulSlaveChnLossRec[portId]);
    BspLog(LOG_LEVEL_0, "%s chan %d slaveChn %d g_ulSlaveChnLossRec[portId] %d\n", __FUNCTION__, chan, slaveChn, g_ulSlaveChnLossRec[portId]);
    /*每个子端下一轮发起前 为0xff是上电第一次 或者高层上一轮完成后置的  此时调用到这个接口说明是新一轮第一次调用到*/
    if(0xff == g_ulSlaveChnLossRec[portId])
    {
    /*这两个要等到端口的所有通道都测完才会更新*/
        BspClrSlaveCableGain(chan);
        BspClrSlaveCableGain(anotherChan);
    /*g_ulCableLossBaseTemp 所有通道都测完才会更新*/
        BspClrSlaveSlavedTestData(chan);   /*驻波 g_ulTxRfCableLoss g_ulPrxRfCableLoss是每个通道发起测量的时候更新*/
        BspClrSlaveSlavedTestData(anotherChan);   /*如果对应通道有功放保护 该通道不发起插损流程*/
    }
    g_ulSlaveChnLossRec[portId] = chan;       /*记录当前子端此时要测量的通道 和高层置为0xff不一样能区分开就行*/

    return BSP_OK;
}
UINT32 BspRecordSlavePortCableLen(UINT32 bspChn, UINT32 len)
{
    if(bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    g_ulSlavePortCableLen[bspChn] = len;
    return BSP_OK;
}

/*以当前单板温度获取线缆的温补增益*/
UINT32 BspGetSlaveCableTempGain(UINT32 bspChn, UINT32 type, INT32 temp, INT32 *pLoss)
{
    UINT32 bandType = 0;
    INT32 tempDelt = 0;
    UINT32 cableLen = 0;

    INPUT_POINTER_CHECK(pLoss);
    if(bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    cableLen = g_ulSlavePortCableLen[bspChn];
    bandType = (type>>4)&0xf;    /*0表示2.6G 1表示3.5G*/
    tempDelt = temp - SLAVE_CABLE_DELT_TEMP- SLAVE_CABLE_BASE_TEMP;   /*0.1度*/
    dbgInfoEx("BspGetSlaveCableTempGain bspChn %d cableLen %d bandType %d cabletemp %d\n", bspChn, cableLen, bandType, temp - SLAVE_CABLE_DELT_TEMP);
    if((0 == tempDelt)||(cableLen == 0))   /*以线缆温度20°为基准（对应温补为0）  时延测量失败长度为0  此时温补也为0*/
    {
        *pLoss = 0;    /*单位0.01db*/
        return BSP_OK;
    }

    switch(bandType)
    {
        case 0:       /*2.6G 大于20°的温补斜率是  0.33dB/100米/10° --33*0.01/100/10 小于20°的温补斜率是  0.47dB/100米/10度*/
        {
            if(tempDelt > 0)
            {
                *pLoss = 0.033*tempDelt*0.1*cableLen*(-1);
            }
            else
            {
                *pLoss = 0.047*tempDelt*0.1*cableLen*(-1);
            }
            break;
        }
        case 1:      /* 以线缆20°为基准（对应温补为0），大于20°的温补斜率是  0.44dB/100米/10°  小于20°的温补斜率是  0.59dB/100米/10度*/
        {
            if(tempDelt > 0)
            {
                *pLoss = 0.044*tempDelt*0.1*cableLen*(-1);
            }
            else
            {
                *pLoss = 0.059*tempDelt*0.1*cableLen*(-1);
            }
            break;
        }
    }
    dbgInfoEx("%s bspChn %d, type 0x%x, boardtemp %d pLoss %d\n", __FUNCTION__, bspChn, type, temp, *pLoss);

    return BSP_OK;
}

/*开环时需要将线缆测试出来的增益补偿算进去*/
UINT32 BspGetSlaveCableGain(UINT32 bspChn, UINT32 type, INT32 temp, INT32 *pLoss)
{
    UINT32 retVal = 0;
    INT32 baseTemp = SLAVE_CABLE_BASE_TEMP;
    INT32 baseLoss = 0;
    INT32 currLoss = 0;

    INPUT_POINTER_CHECK(pLoss);
    if(bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    BspGetCableLossBaseTemp(bspChn, &baseTemp);
    if(SLAVE_CABLE_BASE_TEMP*10 == baseTemp)   /*子端重新上电*/  /*这里注意默认值也写成2000*/
    {
        *pLoss = glOpenLoopCaliCableGain[bspChn];    /*这个值其实是0 子端重新上电*/
        dbgInfoEx("%s bspChn %d ori loss %d\n",__FUNCTION__, bspChn, *pLoss);
        return BSP_OK;
    }
    BspGetSlaveCableTempGain(bspChn,type, baseTemp+SLAVE_CABLE_DELT_TEMP, &baseLoss);
    BspGetSlaveCableTempGain(bspChn,type, temp, &currLoss);
    *pLoss = glOpenLoopCaliCableGain[bspChn] + (currLoss - baseLoss);     /*射频补偿-温补= 射频补偿+（当前温补-基准温补） 温补表是负斜率的两段折线*/
    dbgInfoEx("%s bspChn %d finnal loss %d = %d + (%d - %d)\n", __FUNCTION__, bspChn, *pLoss, glOpenLoopCaliCableGain[bspChn], currLoss, baseLoss);

    return retVal;
}


void showcablegain(UINT32 bspChn)
{
    UINT32 retVal = 0;
    INT32 loss = 0;

    retVal = BspGetSlaveCableGain(bspChn,0, SLAVE_CABLE_BASE_TEMP, &loss);
    if(BSP_OK == retVal)
    {
        dbgInfo("%s bspChn %d finnal loss %d\n", __FUNCTION__, bspChn, loss);
    }
}

#if 0
/******************************************************************************
 * 函数名称   : _BspGetRxAmpGainVal(*)
 * 功能描述   : 获取AMP Gain增益值
 * 读全局变量 : 无
 * 写全局变量 : 无
 * 输入参数   : ulChan   - 发送通道
 * 输出参数   : pVal- 返回增益值
 * 返 回 值   : BSP_OK - 成功
 *              其他   - 错误码
 * 其它说明   : 无
 * ----------------------------------------------------------------------------*
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * $0000000(N/A), 创建
 * $0000000(N/A), 崔文会@2011-02-10 16:36 根据TRM24B项目需求修改
 ******************************************************************************/
UINT32 _BspGetRxAmpGainVal( UINT32 ulChan,INT32 *pVal)
{
    UINT32 ulRfCompsChan = 0;
    TRxAmpGainCaliData *pRxAmpGain = NULL;
#if 0  /*20170401 注释部分要重新考虑*/
    _BspGetRxRfCompsChanInfo(LINK_GROUP_OTHER,ulChan,0,&ulRfCompsChan);/*不管什么制式 补偿通道号是一致的*/
#endif
    pRxAmpGain = (TRxAmpGainCaliData *)_BspGetCalibData(TBL_KIND_OF_RXAMPGAIN,0);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pRxAmpGain);
    if( ulRfCompsChan >= pRxAmpGain->tComHeader.ulPathNum)
    {
        return BSP_ERROR;
    }
    _TRXTEMPALMFILE_LOADED_CHECK((&(pRxAmpGain->atRxAmpGainCaliPath[ulRfCompsChan])));

    *pVal = pRxAmpGain->atRxAmpGainCaliPath[ulRfCompsChan].ptRecord[0].lBypassDeta;

    return BSP_OK;
}
#endif
UINT32 BspSetPowerAdjPara(INT32 *plGain, UINT32 ulNum)
{
    UINT32 ulIdx;
    INPUT_POINTER_CHECK(plGain);
    for (ulIdx = 0; ulIdx < min(ulNum, BSP_MAX_TX_CHAN); ulIdx++)
    {
        salPowerAdjGain[ulIdx] = plGain[ulIdx];
    }
    return BSP_OK;
}

UINT32 BspGetPowerAdjPara(UINT32 ulRfGrp, INT32 *plGain)
{
    INPUT_POINTER_CHECK(plGain);
    if (ulRfGrp >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    *plGain = salPowerAdjGain[ulRfGrp];
    return BSP_OK;
}

UINT32 BspSetOverTempPowerAdjPara(INT32 *plGain, UINT32 ulNum)
{
    UINT32 ulIdx;
    INPUT_POINTER_CHECK(plGain);
    for (ulIdx = 0; ulIdx < min(ulNum, BSP_MAX_TX_CHAN); ulIdx++)
    {
        s_alOverTempPowerAdjGain[ulIdx] = plGain[ulIdx];
    }
    return BSP_OK;
}
UINT32 BspGetOverTempPowerAdjPara(UINT32 ulRfGrp, INT32 *plGain)
{
    INPUT_POINTER_CHECK(plGain);
    if (ulRfGrp >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }

    *plGain = s_alOverTempPowerAdjGain[ulRfGrp];
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetAlmThreshold(*)
 * 功能描述: 获取告警门限或恢复门限
 * 输入参数: ulChan   - 发送通道
 *           TempType - 温度类型
             ulTypeThreshold     - 门限类型
 * 输出参数:  pVal- 返回门限值
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月14日 10090699    创建
 **************************************************************************/
UINT32 BspGetThreshold(UINT32 chn, OSS_ULONG ulThresholdId, UINT32 *pulHighVal, UINT32 *pulLowVal)
{
    UINT32 ulRet = BSP_ERROR;
    OSS_ULONG ulThresholdIdVal = ulThresholdId;
    INT32  lHiVal = 0;
    /* INT32  lLoVal = 0; */
    UINT32 idBase = 0;
    UINT32 innerIdx = 0;

    BspThresholdIdToBase(ulThresholdId, &idBase, &innerIdx);
    if (BSP_ID_MAX < ulThresholdId)
    {
        ulThresholdIdVal = BspThresholdNameToId((const char*)ulThresholdId);
    }
    switch (idBase)
    {
        case BSP_THRESHOLD_ID_POWER_ADJ_TX0:
        {
            ulRet = BspGetPowerAdjPara(chn, &lHiVal);
            *pulHighVal = (ULONG)lHiVal;
            *pulLowVal  = 0;
            break;
        }
        case BSP_THRESHOLD_ID_OVER_TEMP_POWER_ADJ_TX0:
        {
            ulRet = BspGetOverTempPowerAdjPara(chn, &lHiVal);
            *pulHighVal = (ULONG)lHiVal;
            *pulLowVal  = 0;
            break;
        }
        default:
        {
            dbgInfoEx("ThresholdId ERROR!ThresholdId:%#lx, idBase:%d\n", ulThresholdIdVal, idBase);
            return BSP_ERROR_DEVICE_NOT_EXIST;
        }
    }

    dbgInfoEx("chn = %d, ulThresholdIdVal=%#lx,HiVal=%d,LoVal=%d（idBase = %d,innerIdx = %d）\n",chn, ulThresholdIdVal, *pulHighVal, *pulLowVal,
        idBase, innerIdx);
    return ulRet;
}

/**************************************************************************
 * 函数名称: BspGetPwrTempAlmChNum(*)
 * 功能描述: 获取PwrTempAlm.txt中温度检测通道数
 * 输入参数: UINT32 *pPwrTempAlmChNum    通道数
 *
 *
 * 输出参数: UINT32 *pPwrTempAlmChNum    通道数
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2021年4月14日 贾路漫    创建
 **************************************************************************/
UINT32 BspGetPwrTempAlmChNum(UINT32 *pPwrTempAlmChNum)
{
    T_PwrTempAlarmData *ptPwrTempAlm = NULL;
    UINT32 ulPwrIdx = 0;

    INPUT_POINTER_CHECK(pPwrTempAlmChNum);

    ptPwrTempAlm = (T_PwrTempAlarmData *)_BspGetCalibData(TBL_KIND_OF_PWRTEMPALM,ulPwrIdx);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptPwrTempAlm);

    if ((UINT32)TBL_LOAD_SUCC != (ptPwrTempAlm->ulLoadFlag))
    {
        dbgInfoEx("%s,line%d, temp alarm file pwrtempalm.txt load failed!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    *pPwrTempAlmChNum = ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempNum;
    dbgInfoEx("%s  PwrTempChkNum ： %d\n", __FUNCTION__, *pPwrTempAlmChNum);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetTempAlmSensorNum(*)
 * 功能描述: 获取PwrTempAlm.txt中温度传感器节点数
 * 输入参数:
 *
 *
 * 输出参数: UINT32 *pPwrTempAlmSensorNum 温度检测节点数
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2021年4月14日 贾路漫    创建
 **************************************************************************/
UINT32 BspGetTempAlmSensorNum(UINT32 *pPwrTempAlmSensorNum)
{
    T_PwrTempAlarmData *ptPwrTempAlm = NULL;
    UINT32 ulPwrIdx = 0;

    INPUT_POINTER_CHECK(pPwrTempAlmSensorNum);

    ptPwrTempAlm = (T_PwrTempAlarmData *)_BspGetCalibData(TBL_KIND_OF_PWRTEMPALM,ulPwrIdx);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptPwrTempAlm);

    if ((UINT32)TBL_LOAD_SUCC != (ptPwrTempAlm->ulLoadFlag))
    {
        dbgInfoEx("%s,line%d, temp alarm file pwrtempalm.txt load failed!\n", __FUNCTION__, __LINE__);
        return BSP_ERROR;
    }

    *pPwrTempAlmSensorNum = ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempSensorNum;
    dbgInfoEx("%s  PwrTempSensorNum ： %d\n", __FUNCTION__, *pPwrTempAlmSensorNum);

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetAlmThresholdOrigin(*)
 * 功能描述: 获取原始告警门限或恢复门限
 * 输入参数: ulChan   - 发送通道
 *           TempType - 温度类型
             ulTypeThreshold     - 门限类型
 * 输出参数:  pVal- 返回门限值
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月14日 10090699    创建
 **************************************************************************/
UINT32 BspGetAlmThresholdOrigin(UINT32 ulChan, UINT32 ulTempType, UINT32 ulTypeThreshold, T_AlmThreshold *pAlmThreshold)
{
    T_TrxTempAlarmData *ptTrxTempAlm = NULL;
    T_PaTempAlarmData *ptPaTempAlm = NULL;
    T_PwrTempAlarmData *ptPwrTempAlm = NULL;
    T_TempThresholdOffsetPara thresholdOffset = {0};
    /*TPaBasicInfoCaliData *ptPaBasicInfo = NULL;*/
    INT32 lEnvTemp = 0;
    UINT32 index = 0;
    UINT32 tempPwrType[] = {E_TEMP_TYPE_PWR, E_TEMP_TYPE_PWR1, E_TEMP_TYPE_PWR2, E_TEMP_TYPE_PWR3,
                               E_TEMP_TYPE_PWR4, E_TEMP_TYPE_PWR5, E_TEMP_TYPE_PWR6, E_TEMP_TYPE_PWR7};
    UINT32 tempTrxType[] = {E_TEMP_TYPE_TRX, E_TEMP_TYPE_TRX1, E_TEMP_TYPE_TRX2};
    INT32 lTempOffset = 0, lTempSlightOver = 0, lTempOver = 0, lTempSlightOverRec = 0, lTempOverRec = 0;
    INT32 lPowerOver = 0;
    INT32 lPowerOverRec = 0;
    INT32 lAlarm = 0, lRecover = 0;
    UINT32 ulTmpChan = 0;
    UINT32 ulPwrIdx = 0;
    INT32 offset = 0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pAlmThreshold);

    BspGetTempThresholdOffset(&thresholdOffset);
    if(E_TEMP_TYPE_PA == ulTempType)
    {
        TBL_CHAN_VALID_CHECK(ulChan);
        ptPaTempAlm = (T_PaTempAlarmData *)_BspGetCalibData(TBL_KIND_OF_PATEMPALM,0);
        _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptPaTempAlm);
        _PWRTEMPALMFILE_LOADED_CHECK(ptPaTempAlm);
        lEnvTemp    = ptPaTempAlm->tHeader.lWorkEnvTempUpper;
        ulTmpChan = (ulChan >= ptPaTempAlm->tHeader.lPaTempNum) ? 0 : ulChan;
        lTempOffset = ptPaTempAlm->tHeader.lPaTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_OFFSET];
        lTempSlightOver = ptPaTempAlm->tHeader.lPaTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_SLIGHTOVER];
        lTempOver   = ptPaTempAlm->tHeader.lPaTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_OVER];
        lTempSlightOverRec = ptPaTempAlm->tHeader.lPaTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_SLIGHTOVER_REC];
        lTempOverRec   = ptPaTempAlm->tHeader.lPaTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_OVER_REC];
        offset = thresholdOffset.paThresholdOffset;
    }

    for(index = 0; index < NELEMENTS(tempTrxType); index++)
    {
        if(ulTempType == tempTrxType[index])
        {
            ptTrxTempAlm = (T_TrxTempAlarmData *)_BspGetCalibData(TBL_KIND_OF_TRXTEMPALM,0);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTrxTempAlm);
            _TRXTEMPALMFILE_LOADED_CHECK(ptTrxTempAlm);
            lEnvTemp    = ptTrxTempAlm->tHeader.lWorkEnvTempUpper;
            lTempOffset = ptTrxTempAlm->tHeader.lBoardTempAlm[E_TRXTEMP_THRESHOLD_OFFSET + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempSlightOver = ptTrxTempAlm->tHeader.lBoardTempAlm[E_TRXTEMP_THRESHOLD_SLIGHTOVER + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempOver   = ptTrxTempAlm->tHeader.lBoardTempAlm[E_TRXTEMP_THRESHOLD_OVER + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempSlightOverRec = ptTrxTempAlm->tHeader.lBoardTempAlm[E_TRXTEMP_THRESHOLD_SLIGHTOVER_REC + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempOverRec   = ptTrxTempAlm->tHeader.lBoardTempAlm[E_TRXTEMP_THRESHOLD_OVER_REC + (E_TRXTEMP_THRESHOLD_NUM * index)];
            offset = thresholdOffset.boardThresholdOffset;
        }
    }

    for(index = 0; index < NELEMENTS(tempPwrType); index++)
    {
        if(ulTempType == tempPwrType[index])
        {
            _PWRTEMP_ALM_PWR_CHK(ulChan);
            ulPwrIdx = 0;
            ptPwrTempAlm = (T_PwrTempAlarmData *)_BspGetCalibData(TBL_KIND_OF_PWRTEMPALM,ulPwrIdx);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptPwrTempAlm);
            _PWRTEMPALMFILE_LOADED_CHECK(ptPwrTempAlm);
            lEnvTemp    = ptPwrTempAlm->tHeader[ulPwrIdx].lWorkEnvTempUpper;
            ulTmpChan = (ulChan >= ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempNum) ? 0 : ulChan;
            lTempOffset = ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_OFFSET + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempSlightOver = ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_SLIGHTOVER + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempOver   = ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_OVER + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempSlightOverRec = ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_SLIGHTOVER_REC + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lTempOverRec   = ptPwrTempAlm->tHeader[ulPwrIdx].lPwrTempAlm[ulTmpChan][E_TRXTEMP_THRESHOLD_OVER_REC + (E_TRXTEMP_THRESHOLD_NUM * index)];
            lPowerOver     = ptPwrTempAlm->tHeader[ulPwrIdx].lWorkEnvPowerUpper;
            lPowerOverRec  = ptPwrTempAlm->tHeader[ulPwrIdx].lWorkEnvPowerLower;
            offset = thresholdOffset.pwrThresholdOffset;
            break;
        }
    }

    switch(ulTypeThreshold)
    {
        /* 告警恢复门限统一修改为告警门限-3°，刘航确认20160311 */
        /* 严重过温恢复门限=轻微过温+1°，轻微过温恢复门限=轻微过温-3°刘航确认20161208 */
        case E_THRESHOLD_TYPE_OVERTEMP:
        {
            lAlarm   = lEnvTemp + lTempOffset + lTempSlightOver;
            lRecover = lAlarm + 10;
            lAlarm   = lEnvTemp + lTempOffset + lTempOver;

            if(1 == BspGetTempThresholdFromCaliFlag())
            {
                lRecover = lEnvTemp + lTempOffset + lTempOver - lTempOverRec;
            }
            if(SUPPORT == BspGetUaeTempModeFlag())
            {
                lAlarm = lAlarm + offset;
                lRecover = lEnvTemp + lTempOffset + lTempSlightOver + offset + 10;
            }
            break;
        }
        case E_THRESHOLD_TYPE_SLIGHT_OVERTEMP:
        {
            lAlarm   = lEnvTemp + lTempOffset + lTempSlightOver;
            lRecover = lAlarm - 30;

            if(1 == BspGetTempThresholdFromCaliFlag())
            {
                lRecover = lEnvTemp + lTempOffset + lTempSlightOver - lTempSlightOverRec;
            }
            if(SUPPORT == BspGetUaeTempModeFlag())
            {
                lAlarm = lAlarm + offset;
                lRecover = lAlarm - 30;
            }
            break;
        }
        case E_THRESHOLD_TYPE_OVERPOWER:
        {
            lAlarm   = lPowerOver;
            lRecover = lPowerOverRec;
            break;
        }
        default:
        {
            return BSP_ERROR;
        }
    }
    pAlmThreshold->lAlarm   = lAlarm;
    pAlmThreshold->lRecover = lRecover;
    return BSP_OK;
}
/*单板侧传递过温离线表更新参数*/
/* Started by AICoder, pid:46f17h0922m37e0145300beaf0c7af5d5190ab28 */
UINT32 _BspGetAlmThreshold(UINT32 ulChan, UINT32 ulTempType, UINT32 ulTypeThreshold, T_AlmThreshold *pAlmThreshold)
{
    UINT32 ulRet = BSP_OK;
    UINT32 ulLoop = 0;
    UINT32 firstFlag = 0;
    UINT32 ulMaxChan = max(BspGetTxChannel(), BspGetRxChannel());
    T_AlmThreshold tAlmThrMaxMinTemp = {0};
    T_AlmThreshold tAlmThrTemp = {0};

    /* 规避部分硬件离线表参数需要从多通道取最大/最小值 */
    if ((s_tCaliUpdateInfo.flag == 1) && ((s_tCaliUpdateInfo.ulCaliTypeMask & BIT_SET(ulTempType)) != 0))
    {
        for (ulLoop = 0; ulLoop < ulMaxChan; ulLoop++)
        {
            if ((BIT_SET(ulLoop) & s_tCaliUpdateInfo.ulChanMask[ulChan]) != 0)
            {
                ulRet |= BspGetAlmThresholdOrigin(ulLoop, ulTempType, ulTypeThreshold, &tAlmThrTemp);
                if (firstFlag == 0)
                {
                    firstFlag = 1;
                    tAlmThrMaxMinTemp.lAlarm = tAlmThrTemp.lAlarm;
                    tAlmThrMaxMinTemp.lRecover = tAlmThrTemp.lRecover;
                }
                dbgInfoEx("loop: %d, ulTempType: %d, ulTypeThreshold: %d, Warning: %d, Resume: %d\n",
                          ulLoop, ulTempType, ulTypeThreshold, tAlmThrTemp.lAlarm, tAlmThrTemp.lRecover);
                if (s_tCaliUpdateInfo.ulMaxOrMin == 1)
                {
                    tAlmThrMaxMinTemp.lAlarm = max(tAlmThrTemp.lAlarm, tAlmThrMaxMinTemp.lAlarm);
                    tAlmThrMaxMinTemp.lRecover = max(tAlmThrTemp.lRecover, tAlmThrMaxMinTemp.lRecover);
                }
                else
                {
                    tAlmThrMaxMinTemp.lAlarm = min(tAlmThrTemp.lAlarm, tAlmThrMaxMinTemp.lAlarm);
                    tAlmThrMaxMinTemp.lRecover = min(tAlmThrTemp.lRecover, tAlmThrMaxMinTemp.lRecover);
                }
            }
        }
        pAlmThreshold->lAlarm = tAlmThrMaxMinTemp.lAlarm;
        pAlmThreshold->lRecover = tAlmThrMaxMinTemp.lRecover;
    }
    /* 从离线表直接读取 */
    else
    {
        ulRet = BspGetAlmThresholdOrigin(ulChan, ulTempType, ulTypeThreshold, pAlmThreshold);
    }

    dbgInfoEx("Chan: %d, ulTempType: %d, ulTypeThreshold: %d, Warning: %d, Resume: %d\n",
              ulChan, ulTempType, ulTypeThreshold, pAlmThreshold->lAlarm, pAlmThreshold->lRecover);

    return ulRet;
}
/* Ended by AICoder, pid:46f17h0922m37e0145300beaf0c7af5d5190ab28 */

UINT32 BspSetTempThresholdFromBoard(UINT32 thresholdId, INT32 alarmThreshold, INT32 recoverThreshold)
{
    UINT32 loop = 0;

    for(loop = 0; loop < NELEMENTS(g_tAlmPara); loop++)
    {
        if(g_tAlmPara[loop].devIdVal == thresholdId)
        {
            g_tAlmPara[loop].alarmThreshold = alarmThreshold;
            g_tAlmPara[loop].recoverThreshold = recoverThreshold;
            break;
        }
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:BspGetTempThreshold
 * 功能描述: 获取温度告警门限
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2018年04月16日 10105163    从V2移植
 **************************************************************************/
UINT32 BspGetTempThreshold(UINT32 ulChan, UINT32 ulThresholdId, INT32 *plWarning, INT32 *plResume)
{
    UINT32 ulDevIdVal = ulThresholdId;
    UINT32 ulLoop = 0;
    T_AlmThreshold tAlmThre = {0};
    uintptr_t pUlThresholdId = (uintptr_t)ulThresholdId;

    if( BSP_OK != VALID_TX_CHAN(ulChan) )
    {
        dbgErr("BspGetTempThreshold:ulChan Error\n");
        return BSP_ERROR;
    }

    INPUT_POINTER_CHECK(plWarning);
    INPUT_POINTER_CHECK(plResume);

    if ( BSP_ID_MAX < ulThresholdId)
    {
        ulDevIdVal = BspThresholdNameToId((const char *)pUlThresholdId);
    }

    for(ulLoop = 0; ulLoop < NELEMENTS(g_tAlmPara); ulLoop++)
    {
        if(g_tAlmPara[ulLoop].devIdVal == ulDevIdVal)
        {
            tAlmThre.lAlarm = g_tAlmPara[ulLoop].alarmThreshold;
            tAlmThre.lRecover = g_tAlmPara[ulLoop].recoverThreshold;
            if((E_TEMP_TYPE_NUM != g_tAlmPara[ulLoop].tempType) && (E_THRESHOLD_TPYE_NUM != g_tAlmPara[ulLoop].thresholdType))
            {
                _BspGetAlmThreshold(ulChan, g_tAlmPara[ulLoop].tempType, g_tAlmPara[ulLoop].thresholdType, &tAlmThre);
            }
            *plWarning = tAlmThre.lAlarm;
            *plResume  = tAlmThre.lRecover;
            break;
        }
    }
    if(ulLoop == NELEMENTS(g_tAlmPara))
    {
        dbgInfo("ThresholdId ERROR!Chan:%d,ThresholdId:%#x,ulDevIdVal:%d\n", ulChan, ulThresholdId, ulDevIdVal);
        return BSP_ERROR_DEVICE_NOT_EXIST;
    }
    dbgInfoEx("Chan:%d,ulDevIdVal:%#x,Warning:%d,Resume:%d\n", ulChan, ulDevIdVal,
        tAlmThre.lAlarm, tAlmThre.lRecover);

    return BSP_OK;
}
#if 0
/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年03月31日 10090699    创建
 **************************************************************************/
UINT32 _BspGetPwrAlmThreshold(UINT32 ulChan, UINT32 ulTypeThreshold, T_AlmThreshold *pAlmThreshold)
{
    /*T_PwrTempAlarmData *ptPwrTempAlm = NULL;*/
    TPaBasicInfoCaliData *ptPaBasicInfo = NULL;
    UINT32  ulPaIdx=0, ulPaChan=0;
    INT32   lOverPower=0, lOverPowerRecover=0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pAlmThreshold);
    TBL_CHAN_VALID_CHECK(ulChan);

    switch (ulTypeThreshold)
    {
        case E_THRESHOLD_TYPE_OVERPOWER:
        {
            #if 0 /*20170401 注释部分要重新考虑*/
            ulPaIdx  = IntPub_UnitFunc_ChanMap_GetPaIndex(ulChan);
            ulPaChan = IntPub_UnitFunc_ChanMap_GetPaChan(ulChan);
            #endif
            ptPaBasicInfo = (TPaBasicInfoCaliData *)_BspGetCalibData(TBL_KIND_OF_PABASICINFO,ulPaIdx);
            _PABASICINFO_LOADED_CHECK(ptPaBasicInfo, ulPaChan);
            lOverPower        = ptPaBasicInfo->atBasicInfoPath[ulPaChan].ulOverPowThreshold;
            lOverPowerRecover = lOverPower - 300;
            break;
        }
        default:
        {
            return BSP_ERROR;
        }
    }

    pAlmThreshold->lAlarm   = lOverPower;
    pAlmThreshold->lRecover = lOverPowerRecover;
    return BSP_OK;
}
#endif
/**************************************************************************
 * 函数名称:
 * 功能描述:
 * 输入参数: ulCarrFreq - 载波频点
 * 输出参数: 无
 * 返 回 值: 频段索引
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspGetFreqBand(UINT32 ulCarrFreq)
{
    return 0;
}


/**************************************************************************
 * 函数名称:
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspAvgCal(const T_FreqRecord *ptFreqTable,
        UINT32 ulFreq,UINT32 ulRecordIndex, UINT32 ulRecordNum,UINT32 ulBw, UINT32 ulFreqStep, INT32 *plVal)
{
    INT32   lCompsTemp = 0;
    UINT32  ulIdx;
    UINT32  ulStart, ulEnd;
    /*FLOAT  fRate = 0;*/
    UINT32  ulNextIndex = 0;
    INT32    lCompVal;
    UINT32 ulFreqReal = 0;

    //除数为零判断
    if (ulFreqStep == 0)
    {
        dbgErr("[%s] >> divisor ulFreqStep cannot be zero !!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulStart = ulRecordIndex - (ulBw/ulFreqStep/2);
    ulEnd   = ulRecordIndex + (ulBw/ulFreqStep/2);
    //fRate = (FLOAT)(ulFreq -  ptFreqTable[ulRecordIndex].lFreq)/1000;
    if (ulRecordIndex < (ulBw/ulFreqStep/2))
    {
        ulStart = 0;
    }
    if(ulEnd > ulRecordNum - 1)
    {
        ulEnd = ulRecordNum - 2;
    }
    for (ulIdx = ulStart; ulIdx <= (ulEnd - 1); ulIdx++)
    {
        if(1000 <= ulFreqStep)
        {
            ulNextIndex = ulIdx+1;
            ulFreqReal = ptFreqTable[ulIdx].lFreq + (ulFreq- ptFreqTable[ulRecordIndex].lFreq);
            lCompVal= _LINEAR_INSERT(ulFreqReal, ptFreqTable[ulIdx].lFreq, ptFreqTable[ulIdx].lCompVal,
            ptFreqTable[ulNextIndex].lFreq, ptFreqTable[ulNextIndex].lCompVal);
            //lCompVal =  ptFreqTable[ulIdx].lCompVal + (ptFreqTable[ulNextIndex].lCompVal - ptFreqTable[ulIdx].lCompVal) * fRate;
            lCompsTemp += lCompVal;
        }
        else
        {
            lCompsTemp += ptFreqTable[ulIdx].lCompVal;
        }
    }

    *plVal = lCompsTemp / (INT32)(ulEnd - ulStart);

    return BSP_OK;
}
#if 0
/**************************************************************************
 * 函数名称:
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月14日 10090699    创建
 **************************************************************************/
UINT32 _BspVswrParamAvgCal(const T_VswrRecord *ptFreqTable,
        UINT32 ulRecordIndex, UINT32 ulBw, UINT32 ulFreqStep, T_VswrSParamVal *ptSParam)
{
    UINT32  ulRetVal = BSP_OK;
    UINT32  ulIdx, ulStart, ulEnd, ulTotalPoint;
    T_VswrSParamVal tParam = {0};

    ulStart = ulRecordIndex - (ulBw / ulFreqStep / 4);
    ulEnd   = ulRecordIndex + (ulBw / ulFreqStep / 4);
    for (ulIdx = ulStart; ulIdx < ulEnd; ulIdx++)
    {
        tParam.lS11_Real += ptFreqTable[ulIdx].lS11_Real;
        tParam.lS11_Imag += ptFreqTable[ulIdx].lS11_Imag;
        tParam.lS22_Real += ptFreqTable[ulIdx].lS22_Real;
        tParam.lS22_Imag += ptFreqTable[ulIdx].lS22_Imag;
        tParam.lSt_Real  += ptFreqTable[ulIdx].lSt_Real;
        tParam.lSt_Imag  += ptFreqTable[ulIdx].lSt_Imag;
    }

    ulTotalPoint = ulEnd - ulStart;
    tParam.lS11_Real /= (INT32)ulTotalPoint;
    tParam.lS11_Imag /= (INT32)ulTotalPoint;
    tParam.lS22_Real /= (INT32)ulTotalPoint;
    tParam.lS22_Imag /= (INT32)ulTotalPoint;
    tParam.lSt_Real  /= (INT32)ulTotalPoint;
    tParam.lSt_Imag  /= (INT32)ulTotalPoint;

    memcpy(ptSParam, &tParam, sizeof(T_VswrSParamVal));
    return ulRetVal;
}

/******************************************************************************
 * 函数名称   : (*)
 * 功能描述   : 获取指定频点,通道的校准值
 * 读全局变量 : 无
 * 写全局变量 : 无
 * 输入参数   : usType    - 校准类型
 *              ulFreg    - 频点,单位 kHz
 *              ulChannel - 通道号,从0开始
 *              psCaliVal - 存放校准值的指针
 * 输出参数   : 无
 * 返 回 值   : BSP_OK - 成功; 其他 - 错误码
 * 其它说明   : IQ校准数据不使用该接口
 * ----------------------------------------------------------------------------*
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 * 2015年12月14日 10090699    创建
 ******************************************************************************/
UINT32 _BspInterGetVswrParam(UINT16 usType, UINT32 ulChan,
        UINT32 ulCenterFreq, UINT32 ulCarrFreq, UINT32 ulBw, T_VswrSParamVal *ptSParam)
{
    T_VswrRecord *ptFreqTable;
    TVswrParamCaliData *ptVswrParamData;
    T_VswrParamHeader *ptHeader;
    UINT32  ulRetVal = BSP_OK;
    UINT32  ulRecordIndex, ulRecordNum;
    UINT32  ulFreqStep, ulFreqBand, ulRoundFreq;
    INT32   lCompsIf;
    T_VswrSParamVal tRfParam = {0};

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptSParam);
    TBL_CHAN_VALID_CHECK(ulChan);

    ptVswrParamData = (TVswrParamCaliData *)_BspGetCalibData(TBL_KIND_OF_VSWRPARAM,0);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptVswrParamData);
    ulFreqBand = _BspGetFreqBand(ulCarrFreq);
    _VSWRPARAMFILE_LOADED_CHECK(ptVswrParamData, ulChan);
    ptFreqTable = ptVswrParamData->atVswrParamCaliPath[ulChan].patRfRecord[ulFreqBand];
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptFreqTable);
    ptHeader = &ptVswrParamData->atVswrParamCaliPath[ulChan].tHeader;

    switch(usType)
    {
        case TBL_VSWRParam:
            ulFreqStep = ptHeader->aulRfStep[ulFreqBand];
            lCompsIf = 0;
            break;
        default:
            ulFreqStep = COMPS_FREQ_STEP;
            lCompsIf = 0;
            break;
    }
    if (0 == ulFreqStep)
    {
        dbgErr("%s:freq step error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    ulRoundFreq= _BspFreqRound(ulCarrFreq,ptHeader->aulStartFreq[ulFreqBand],ptHeader->aulStopFreq[ulFreqBand],ulFreqStep);
    ulRecordIndex = (ulRoundFreq - ptHeader->aulStartFreq[ulFreqBand])/ulFreqStep;
    ulRecordNum   = ptVswrParamData->atVswrParamCaliPath[ulChan].aulRfRecordNum[ulFreqBand];
    if (ulRecordIndex >= ulRecordNum)
    {
        dbgErr("%s:RecordIndex ERROR!ulRecordIndex=%d,ulRecordNum=%d\n",
        __FUNCTION__, ulRecordIndex, ulRecordNum);
        return BSP_ERROR;
    }

    if (ptFreqTable[ulRecordIndex].lFreq != (INT32)ulRoundFreq)
    {
        dbgErr("%s:ptFreqTable[%d].lFreq(%d) != ulRoundFreq(%d)!\n", __FUNCTION__,
            ulRecordIndex, ptFreqTable[ulRecordIndex].lFreq, ulRoundFreq);
        return BSP_ERROR;
    }

    tRfParam.lS11_Real = ptFreqTable[ulRecordIndex].lS11_Real;
    tRfParam.lS11_Imag = ptFreqTable[ulRecordIndex].lS11_Imag;
    tRfParam.lS22_Real = ptFreqTable[ulRecordIndex].lS22_Real;
    tRfParam.lS22_Imag = ptFreqTable[ulRecordIndex].lS22_Imag;
    tRfParam.lSt_Real  = ptFreqTable[ulRecordIndex].lSt_Real;
    tRfParam.lSt_Imag  = ptFreqTable[ulRecordIndex].lSt_Imag;
    if ((ulRoundFreq >= (ptHeader->aulStartFreq[ulFreqBand] + ulBw/2)) &&
        (ulRoundFreq <= (ptHeader->aulStopFreq[ulFreqBand] - ulBw/2)))
    {
        if (0 != ulBw)   /* 接收到带宽不为0时,统计中心频点前后1/4带宽平均 */
        {
            ulRetVal = _BspVswrParamAvgCal(ptFreqTable,
                           ulRecordIndex, ulBw, ulFreqStep, &tRfParam);
        }
    }

    ptSParam->lS11_Real = lCompsIf + tRfParam.lS11_Real;
    ptSParam->lS11_Imag = lCompsIf + tRfParam.lS11_Imag;
    ptSParam->lS22_Real = lCompsIf + tRfParam.lS22_Real;
    ptSParam->lS22_Imag = lCompsIf + tRfParam.lS22_Imag;
    ptSParam->lSt_Real  = lCompsIf + tRfParam.lSt_Real;
    ptSParam->lSt_Imag  = lCompsIf + tRfParam.lSt_Imag;

    return ulRetVal;
}
/**************************************************************************
 * 函数名称:
 * 功能描述: 获取矢量驻波参数
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetVswrParam(UINT32 ulChan, UINT32 ulFreq, UINT32 ulBw, T_VswrSParamVal *ptSParam)
{
    UINT32 ulRetVal = BSP_OK;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptSParam);
    memset(ptSParam, 0, sizeof(*ptSParam)); /* 默认参数 */
    TBL_CHAN_VALID_CHECK(ulChan);

    ulRetVal = _BspInterGetVswrParam(TBL_VSWRParam, ulChan, ulFreq, ulFreq, ulBw, ptSParam);

    return ulRetVal;
}
#endif
/**************************************************************************
 * 函数名称:
 * 功能描述: 获取IQ平均校准值
 * 输入参数: ptFreqTable   - 校准表指针
 *           usRecordIndex - 表中的序号
             usBW     - 载波带宽
             wFreqStep- 校准步进
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspTxIqAvgCal(const T_TxIqCaliRecord *ptFreqTable,
        UINT32 ulRecordIndex, UINT32 ulBw, UINT32 ulFreqStep, T_TxIqVal *ptTxIqVal)
{
    UINT32  ulRetVal = BSP_OK;
    UINT32  ulIdx, ulStart, ulEnd, ulTotalPoint;
    T_TxIqVal tIqVal = {0};

    //除数为零判断
    if (ulFreqStep == 0)
    {
        dbgErr("[%s] >> divisor ulFreqStep cannot be zero !!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    ulStart = ulRecordIndex - (ulBw / ulFreqStep / 4);
    ulEnd   = ulRecordIndex + (ulBw / ulFreqStep / 4);
    for (ulIdx = ulStart; ulIdx < ulEnd; ulIdx++)
    {
        tIqVal.sIOffset += ptFreqTable[ulIdx].lIOffset;
        tIqVal.sQOffset += ptFreqTable[ulIdx].lQOffset;
        tIqVal.sIAmp    += ptFreqTable[ulIdx].lIAmp;
        tIqVal.sQAmp    += ptFreqTable[ulIdx].lQAmp;
        tIqVal.sIPhase  += ptFreqTable[ulIdx].lIPhase;
        tIqVal.sQPhase  += ptFreqTable[ulIdx].lQPhase;
    }

    ulTotalPoint = ulEnd - ulStart;
    tIqVal.sIOffset /= (INT32)ulTotalPoint;
    tIqVal.sQOffset /= (INT32)ulTotalPoint;
    tIqVal.sIAmp    /= (INT32)ulTotalPoint;
    tIqVal.sQAmp    /= (INT32)ulTotalPoint;
    tIqVal.sIPhase  /= (INT32)ulTotalPoint;
    tIqVal.sQPhase  /= (INT32)ulTotalPoint;

    memcpy(ptTxIqVal, &tIqVal, sizeof(T_TxIqVal));
    return ulRetVal;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取指定通道的IQ校准值
 * 输入参数: usType    - 校准类型
             ulCenterFreq-中心频点
             ulCarrFreq- 载波频点
             ulBw      - 载波带宽
             ulChan    - 通道号,从0开始
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspInterGetTxIqVal(UINT16 usType, UINT32 ulChan,
        UINT32 ulCenterFreq, UINT32 ulCarrFreq, UINT32 ulBw, T_TxIqVal *ptTxIqVal)
{
    T_TxIqCaliRecord *ptFreqTable;
    TTxIqCaliData *ptTxIqData;
    T_TxIqCaliHeader *ptHeader;
    UINT32  ulRetVal = BSP_OK;
    UINT32  ulRecordIndex, ulRecordNum;
    UINT32  ulFreqStep, ulFreqBand, ulRoundFreq;
    INT32   lCompsIf;
    T_TxIqVal tIqValRf = {0};

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTxIqVal);
    TBL_CHAN_VALID_CHECK(ulChan);

    ptTxIqData = (TTxIqCaliData *)_BspGetCalibData(TBL_KIND_OF_TXIQ,0);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTxIqData);
    ulFreqBand = _BspGetFreqBand(ulCarrFreq);
    _TXIQFILE_LOADED_CHECK(ptTxIqData, ulChan);
    ptFreqTable = ptTxIqData->atTxIqCaliPath[ulChan].patRfRecord[ulFreqBand];
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptFreqTable);
    ptHeader = &ptTxIqData->atTxIqCaliPath[ulChan].tHeader;

    switch(usType)
    {
        case TBL_TX_IQ_CAL:
            ulFreqStep = ptHeader->aulRfStep[ulFreqBand];
            lCompsIf = 0;
            break;
        default:
            ulFreqStep = COMPS_FREQ_STEP;
            lCompsIf = 0;
            break;
    }
    if (0 == ulFreqStep)
    {
        dbgErr("%s:freq step error!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    ulRoundFreq= _BspFreqRound(ulCarrFreq,ptHeader->aulStartFreq[ulFreqBand],ptHeader->aulStopFreq[ulFreqBand],ulFreqStep);
    ulRecordIndex = (ulRoundFreq - ptHeader->aulStartFreq[ulFreqBand])/ulFreqStep;
    ulRecordNum   = ptTxIqData->atTxIqCaliPath[ulChan].aulRfRecordNum[ulFreqBand];
    if (ulRecordIndex >= ulRecordNum)
    {
        dbgErr("%s:RecordIndex ERROR!ulRecordIndex=%d,ulRecordNum=%d\n",
            __FUNCTION__, ulRecordIndex, ulRecordNum);
        return BSP_ERROR;
    }

    if (ptFreqTable[ulRecordIndex].lFreq != (INT32)ulRoundFreq)
    {
        dbgErr("%s:ptFreqTable[%d].lFreq(%d) != ulRoundFreq(%d)!\n", __FUNCTION__,
            ulRecordIndex, ptFreqTable[ulRecordIndex].lFreq, ulRoundFreq);
        return BSP_ERROR;
    }

    tIqValRf.sIOffset = ptFreqTable[ulRecordIndex].lIOffset;
    tIqValRf.sQOffset = ptFreqTable[ulRecordIndex].lQOffset;
    tIqValRf.sIAmp    = ptFreqTable[ulRecordIndex].lIAmp;
    tIqValRf.sQAmp    = ptFreqTable[ulRecordIndex].lQAmp;
    tIqValRf.sIPhase  = ptFreqTable[ulRecordIndex].lIPhase;
    tIqValRf.sQPhase  = ptFreqTable[ulRecordIndex].lQPhase;
    if (0 != ulBw)   /* 接收到带宽不为0时,统计中心频点前后1/4带宽平均 */
    {
        if ((ulRoundFreq >= (ptHeader->aulStartFreq[ulFreqBand] + ulBw/2)) &&
            (ulRoundFreq <= (ptHeader->aulStopFreq[ulFreqBand] - ulBw/2)))
        {
            ulRetVal = _BspTxIqAvgCal(ptFreqTable, ulRecordIndex, ulBw, ulFreqStep, &tIqValRf);
        }
    }

    ptTxIqVal->sIOffset = lCompsIf + tIqValRf.sIOffset;
    ptTxIqVal->sQOffset = lCompsIf + tIqValRf.sQOffset;
    ptTxIqVal->sIAmp    = lCompsIf + tIqValRf.sIAmp;
    ptTxIqVal->sQAmp    = lCompsIf + tIqValRf.sQAmp;
    ptTxIqVal->sIPhase  = lCompsIf + tIqValRf.sIPhase;
    ptTxIqVal->sQPhase  = lCompsIf + tIqValRf.sQPhase;

    return ulRetVal;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取指定通道的IQ校准值
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTxIqVal(UINT32 ulChan, UINT32 ulFreq, UINT32 ulBw, T_TxIqVal *ptTxIqVal)
{
    UINT32 ulRetVal = BSP_OK;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTxIqVal);
    memset(ptTxIqVal, 0, sizeof(*ptTxIqVal)); /* 默认参数 */
    TBL_CHAN_VALID_CHECK(ulChan);

    ulRetVal = _BspInterGetTxIqVal(TBL_TX_IQ_CAL, ulChan, ulFreq, ulFreq, ulBw, ptTxIqVal);

    return ulRetVal;
}

/**************************************************************************
 * 函数名称:IntPub_UnitFunc_SetDlPowDefPara
 * 功能描述: 设置Dl定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspSetDlPowDefPara(T_DefDlPowCalPara *pInfo,UINT32 ulNum)
{
    s_pTDlDefPowCalPara = pInfo;
    ulDlParaNum         = ulNum;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:IntPub_UnitFunc_GetDlPowDefPara
 * 功能描述: 设置Dl定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
INT32 _BspGetDlPowDefPara(UINT32 ulChn, UINT32 ulType)
{
    _COMPSFLE_CHECK_INPUT_TX_CHAN(ulChn);

    if((NULL == s_pTDlDefPowCalPara)||(E_POW_CALC_MAX<=ulType))
    {
        return 0;
    }
    return s_pTDlDefPowCalPara[ulChn].lvVal[ulType];
}

/**************************************************************************
 * 函数名称:IntPub_UnitFunc_SetPowUlDefPara
 * 功能描述: 设置Dl定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspSetUlPowDefPara(T_DefUlPowCalPara *pInfo,UINT32 ulNum)
{
    s_pTUlDefPowCalPara = pInfo;
    ulUlParaNum         = ulNum;

    return BSP_OK;
}
/**************************************************************************
 * 函数名称:BspSetUlTargetGain
 * 功能描述: 按照制式设置上行目标增益参数默认值（qcell）
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 BspSetUlTargetGain(T_DefUlTargetGain *pInfo,UINT32 ulNum)
{
	s_pTUlDefTargetGain = pInfo;
    ulUlTargetGainNum = ulNum;

    return BSP_OK;
}
/**************************************************************************
 * 函数名称:IntPub_UnitFunc_SetPowUlDefPara
 * 功能描述: 设置UL定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetUlPowDefPara(UINT32 ulChn, UINT32 ulType)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(ulChn);

    if(NULL == s_pTUlDefPowCalPara)
    {
        return 0;
    }
    return s_pTUlDefPowCalPara[ulChn].lRxTargetGain;
}

/**************************************************************************
 * 函数名称:BspGetUlPowDefParaByCarrMode
 * 功能描述: 获取上行目标增益默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 BspGetUlPowDefParaByCarrMode(UINT32 uiCarrMode, UINT32 ulType)
{
	UINT32 uiLoop = 0;
    if(NULL == s_pTUlDefTargetGain)
    {
        return 0;
    }

    for(uiLoop = 0;uiLoop< ulUlTargetGainNum;uiLoop++)
    {
    	if(uiCarrMode == s_pTUlDefTargetGain[uiLoop].uiCarrMode)
    	{
    	    return s_pTUlDefTargetGain[uiLoop].lRxTargetGain;
    	}
    }
    return 0;
}

#if 0
/**************************************************************************
 * 函数名称:_BspSetAcVswrDefPara
 * 功能描述: 设置Ac Vswr参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日 10090699    创建
 **************************************************************************/
UINT32 _BspSetAcVswrDefPara(T_DefAcVswrPara *pInfo,UINT32 ulNum)
{
    s_pTAcVswrDefPara = pInfo;
    ulAcVswrParaNum         = ulNum;

    return BSP_OK;
}
/**************************************************************************
 * 函数名称:IntPub_UnitFunc_SetPowUlDefPara
 * 功能描述: 设置UL定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetAcVswrDefPara(UINT32 ulChn, UINT32 ulType)
{
    _COMPSFLE_CHECK_INPUT_TX_CHAN(ulChn);

    if((NULL == s_pTAcVswrDefPara) || (E_AC_VSWR_MAX <= ulType))
    {
        return 0;
    }
    return s_pTAcVswrDefPara[ulChn].lvVal[ulType];
}
#endif
/**************************************************************************
 * 函数名称:IntPub_UnitFunc_SetPowUlDefPara
 * 功能描述: 设置UL定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
INT32 _BspGetUlAttDefPara(UINT32 ulChn, UINT32 ulType)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(ulChn);

    if(NULL == s_pTUlDefPowCalPara)
    {
        return 0;
    }
    return s_pTUlDefPowCalPara[ulChn].lRxDefAttVal;
}

/**************************************************************************
 * 函数名称:_BspGetUlAttDigPara
 * 功能描述: 获取数字预衰默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
INT32 _BspGetUlAttDigPara(UINT32 ulChn, UINT32 ulType)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(ulChn);

    if(NULL == s_pTUlDefPowCalPara)
    {
        return 0;
    }
    return s_pTUlDefPowCalPara[ulChn].lRxDigAttVal;
}
#if 0
/**************************************************************************
 * 函数名称:_BspGetTxAcCalDefPara
 * 功能描述: 设置UL定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetTxAcCalDefPara(UINT32 ulChn, UINT32 ulType)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(ulChn);

    if(NULL == s_pTUlDefPowCalPara)
    {
        return 0;
    }
    return s_pTUlDefPowCalPara[ulChn].lTxAcCalDefVal;
}

/**************************************************************************
 * 函数名称:_BspGetRxIsoCalDefPara
 * 功能描述: 设置UL定标参数默认值
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetRxIsoCalDefPara(UINT32 ulChn, UINT32 ulType)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(ulChn);

    if(NULL == s_pTUlDefPowCalPara)
    {
        return 0;
    }
    return s_pTUlDefPowCalPara[ulChn].lRxIsoCalDefVal;
}
#endif
/**************************************************************************
 * 函数名称:_BspGetRxChanTargetGain_Base
 * 功能描述: 获取接收链路的目标增益
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetRxChanTargetGain_Base(UINT32 bspChn, UINT32 ulBand, INT32 *chanTargetGain)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);
    INPUT_POINTER_CHECK(chanTargetGain);
    *chanTargetGain = _BspGetUlPowDefPara(bspChn, 0);//unit 0.01db
    return BSP_OK;
}
/**************************************************************************
 * 函数名称:_BspGetRxCarrModeTargetGain_Base
 * 功能描述: 通过制式获取接收链路的目标增益（qcell）
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 BspGetRxCarrModeTargetGain_Base(UINT32 carrMode, INT32 *chanTargetGain)
{

    INPUT_POINTER_CHECK(chanTargetGain);
	UINT32 uiBspTargetGain = 0;

    uiBspTargetGain = BspGetUlPowDefParaByCarrMode(carrMode, 0);//unit 0.01db

    switch(carrMode)
    {
    	 case BSP_RADIO_STANDARD_UMTS:

    		 *chanTargetGain = 15 * 602 + uiBspTargetGain; //uiBspTargetGain BSP中频 目标增益，UMTS 15 是有效bit位宽。6.02是单bit对应的满量程 ((17*6.02+21)*100)
    	      break;
    	 default:
    		 *chanTargetGain = uiBspTargetGain;
    	      break;
    }
    return BSP_OK;
}
UINT32 BspGetRxCarrModeTargetGain_Bsp(UINT32 carrMode, INT32 *chanTargetGain)
{

    INPUT_POINTER_CHECK(chanTargetGain);
	UINT32 uiBspTargetGain = 0;
    uiBspTargetGain = BspGetUlPowDefParaByCarrMode(carrMode, 0);//unit 0.01db
    *chanTargetGain = uiBspTargetGain;

    return BSP_OK;
}
#if 0
/**************************************************************************
 * 函数名称:_BspGetRxChanTargetGain_Base
 * 功能描述: 获取接收链路的目标增益
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetTxAcCalTargetGain_Base(UINT32 bspChn, UINT32 ulBand, INT32 *chanTargetGain)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);
    INPUT_POINTER_CHECK(chanTargetGain);
    *chanTargetGain = _BspGetTxAcCalDefPara(bspChn, 0);//unit 0.01db
    return BSP_OK;
}
/**************************************************************************
 * 函数名称:_BspGetRxChanTargetGain_Base
 * 功能描述: 获取接收链路的目标增益
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetRxIsoCalTargetGain_Base(UINT32 bspChn, UINT32 ulBand, INT32 *chanTargetGain)
{
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);
    INPUT_POINTER_CHECK(chanTargetGain);
    *chanTargetGain = _BspGetRxIsoCalDefPara(bspChn, 0);//unit 0.01db
    return BSP_OK;
}
#endif
/**************************************************************************
 * 函数名称: BspGetTxCarrTargetGain(*)
 * 功能描述: 获取发射链路的目标增益
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 BspGetTxCarrTargetGain(UINT32 bspChn, INT32 *chanTargetGain)
{
    UINT32 ratedPow  = 0;
    INT32  tagetDbm   = 0;
    INT32  targetDbfs  = 0;

    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    INPUT_POINTER_CHECK(chanTargetGain);

    BspGetRruPathRatedPower(bspChn, &ratedPow);

    if ((0 == ratedPow)||(ratedPow >= BSP_INVALID_VALUE))
    {
        dbgInfoEx("%s ERROR!TxChan#%d,ulRatedPow=%d\n", __FUNCTION__,bspChn,ratedPow);
        return BSP_ERROR;
    }
    tagetDbm  = (INT32)(1000.0 * log10((DOUBLE)ratedPow) + 0.5);
    if(POWER_UNIT_UW == BspGetPowerUnit())
    {
        tagetDbm = tagetDbm - 3000; /*微瓦为单位，计算结果减30db*/
    }
    else if (POWER_UNIT_NW == BspGetPowerUnit())
    {
        tagetDbm = tagetDbm - 6000; /*纳瓦为单位，计算结果减60db*/
    }

    targetDbfs = _BspGetDlPowDefPara(bspChn, E_BBU_DBFS_TX);

    *chanTargetGain=tagetDbm - targetDbfs;//unit 0.01db

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取发射链路的目标增益,powshow调用
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetTxChanTargetGain_Base(UINT32 bspChn, INT32 *chanTargetGain)
{
    UINT32 ratedPow  = 0;
    INT32  targetDbm   = 0;
    INT32  targetDbfs  = 0;
    UINT32 ret = BSP_OK;

    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    INPUT_POINTER_CHECK(chanTargetGain);

    if (NULL != s_pGetTxDestGainFunc)
    {
        ret = s_pGetTxDestGainFunc(TX,bspChn,chanTargetGain);
        dbgInfoEx("dir: %d, chan: %d, txTargetGain: %d\n", TX, bspChn, *chanTargetGain);
        return ret;
    }

    BspGetRruPathRatedPower(bspChn, &ratedPow);

    if ((0 == ratedPow)||(ratedPow >= BSP_INVALID_VALUE))
    {
        dbgInfoEx("%s ERROR!TxChan#%d,ulRatedPow=%d\n", __FUNCTION__,bspChn,ratedPow);
        return BSP_ERROR;
    }
    targetDbm  = (INT32)(1000.0*log10((DOUBLE)ratedPow)+0.5);
    if(POWER_UNIT_UW == BspGetPowerUnit())
    {
        targetDbm = targetDbm - 3000; /*微瓦为单位，计算结果减30db*/
    }
    if(POWER_UNIT_NW == BspGetPowerUnit())
    {
        targetDbm = targetDbm - 6000; /*纳瓦为单位，计算结果减60db*/
    }


    targetDbfs = _BspGetDlPowDefPara(bspChn,E_TARGET_DBFS_TX);

    if(pGetPowerReduceCall != NULL)
    {
        targetDbm = targetDbm - pGetPowerReduceCall();
    }

    *chanTargetGain=targetDbm - targetDbfs;//unit 0.01db
    dbgInfoEx("[%s]bspChan'%d,ratedPow'%d,tagetDBm'%d,targetDbfs'%d,targetGain'%d\n",
               __FUNCTION__, bspChn,    ratedPow,   targetDbm,  targetDbfs,  *chanTargetGain);
    return BSP_OK;
}

/* Started by AICoder, pid:o116cw5a35a014314fc909d27072fa4bb0813cf3 */
UINT32 _BspGetTxChanTargetGain_Base_ncr(UINT32 bspChn, INT32 *chanTargetGain)
{
    UINT32 ratedPow  = 0;
    INT32  targetDbm   = 0;
    INT32  targetDbfs  = 0;
    UINT32 ret = BSP_OK;

    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    INPUT_POINTER_CHECK(chanTargetGain);

    (VOID)BspGetRruPathRatedPower(bspChn, &ratedPow);

    if ((0 == ratedPow)||(ratedPow >= BSP_INVALID_VALUE))
    {
        dbgInfoEx("%s ERROR!TxChan#%d,ulRatedPow=%d\n", __FUNCTION__,bspChn,ratedPow);
        return BSP_ERROR;
    }
    targetDbm  = (INT32)(1000.0*log10((DOUBLE)ratedPow)+0.5);
    if(1 == BspGetPowerUnit())
    {
        targetDbm = targetDbm - 3000; /*微瓦为单位，计算结果减30db*/
    }

    targetDbfs = _BspGetDlPowDefPara(bspChn,E_TARGET_DBFS_TX);

    *chanTargetGain = targetDbm - targetDbfs;//unit 0.01db
    dbgInfoEx("[%s]bspChan'%d,ratedPow'%d,tagetDBm'%d,targetDbfs'%d,targetGain'%d\n",
               __FUNCTION__, bspChn,    ratedPow,   targetDbm,  targetDbfs,  *chanTargetGain);
    return ret;
}
/* Ended by AICoder, pid:o116cw5a35a014314fc909d27072fa4bb0813cf3 */

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取反馈/反射链路的目标增益
 * 输入参数:
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月15日     创建
 **************************************************************************/
UINT32 _BspGetFwdRevChanTargetGain(UINT32 bspChn,INT32 *chanTargetGain)
{
    UINT32 ratedPow  = 0;
    INT32  targetDbm   = 0;
    INT32  targetDbfs = 0;
    UINT32 ret = BSP_OK;
    UINT32 FB = 2;

    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    INPUT_POINTER_CHECK(chanTargetGain);

    if (NULL != s_pGetFbDestGainFunc)
    {
        ret = s_pGetFbDestGainFunc(FB,bspChn,chanTargetGain);
        dbgInfoEx("dir: %d, chan: %d, txTargetGain: %d\n", TX, bspChn, *chanTargetGain);
        return ret;
    }

    BspGetRruPathRatedPower(bspChn,&ratedPow);

    if ((0 == ratedPow)||(ratedPow >= BSP_INVALID_VALUE))
    {
        dbgInfoEx("%s ERROR!TxChan#%d,ulRatedPow=%d\n", __FUNCTION__,bspChn,ratedPow);
        return BSP_ERROR;
    }
    targetDbm  = (INT32)(1000.0*log10((DOUBLE)ratedPow)+0.5);
    if(POWER_UNIT_UW == BspGetPowerUnit())
    {
        targetDbm = targetDbm - 3000; /*微瓦为单位，计算结果减30db*/
    }
    else if (POWER_UNIT_NW == BspGetPowerUnit())
    {
        targetDbm = targetDbm - 6000; /*纳瓦为单位，计算结果减60db*/
    }

    targetDbfs = _BspGetDlPowDefPara(bspChn,E_TARGET_DBFS_PRX);

    *chanTargetGain=targetDbfs-targetDbm;//unit 0.01db
    dbgInfoEx("[%s]bspChan'%d,ratedPow'%d,targetDbm'%d,targetDbfs'%d,chanTargetGain'%d\n",
               __FUNCTION__, bspChn,    ratedPow,   targetDbm,   targetDbfs,  *chanTargetGain);
    return BSP_OK;
}

pCpattRfTblMapFunc pGetCpattRfTblMapCall = NULL;

UINT32 BspCpattRfTblChanMapFuncCallBack(pCpattRfTblMapFunc pGetRfTblMapFunc)
{
    pGetCpattRfTblMapCall = pGetRfTblMapFunc;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetPrxAttDelta
 * 功能描述: 获取CPATT的校准值查找结果
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetPrxAttDelta(UINT32 ulChan, UINT32 ulFreq, UINT32 ulBw,UINT32 ulAtt, INT32 *plGain)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 ulIdx;
    UINT32 ulIsAsend = 0;
    INT32  lAttDeta = 0;
    INT32  lFirstAtt, lSecondAtt;
    /*UINT32 ulPrxATTCompsChnNo;*/
    TCpAttCaliData *ptCaliData;
    UINT32 rfTblChn = 0;

    if (pGetCpattRfTblMapCall != NULL)
    {
        pGetCpattRfTblMapCall(ulChan, &rfTblChn);
        ulChan = rfTblChn;
    }

    ptCaliData = (TCpAttCaliData *)_BspGetCalibData(TBL_KIND_OF_CPATT,0);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptCaliData);
    TBL_CHAN_VALID_CHECK(ulChan);
    _CPATTFILE_LOADED_CHECK(ptCaliData,ulChan);

    if (0 == ptCaliData->atCpAttCaliPath[ulChan].ulRecordNum)
    {
        dbgErr("ulChan = %d\n", ulChan);
        return BSP_ERROR;
    }
    else if (1 == ptCaliData->atCpAttCaliPath[ulChan].ulRecordNum)
    {
        ulIsAsend = 1;
    }
    else
    {
        lFirstAtt = ptCaliData->atCpAttCaliPath[ulChan].ptRecord[0].lCpAtt;
        lSecondAtt= ptCaliData->atCpAttCaliPath[ulChan].ptRecord[1].lCpAtt;
        ulIsAsend = (lFirstAtt < lSecondAtt) ? 1 : 0;
    }

    if (ulIsAsend) /* 升序 */
    {
        for (ulIdx = 0; ulIdx < ptCaliData->atCpAttCaliPath[ulChan].ulRecordNum; ulIdx++)
        {
            lAttDeta = ptCaliData->atCpAttCaliPath[ulChan].ptRecord[ulIdx].lDeta;
            if (ulAtt <= ptCaliData->atCpAttCaliPath[ulChan].ptRecord[ulIdx].lCpAtt)
            {
                break;
            }
        }
    }
    else /* 降序 */
    {
        for (ulIdx = 0; ulIdx < ptCaliData->atCpAttCaliPath[ulChan].ulRecordNum; ulIdx++)
        {
            lAttDeta = ptCaliData->atCpAttCaliPath[ulChan].ptRecord[ulIdx].lDeta;
            if (ulAtt >= ptCaliData->atCpAttCaliPath[ulChan].ptRecord[ulIdx].lCpAtt)
            {
                break;
            }
        }
    }

    *plGain = lAttDeta;
    dbgInfoEx("[%s] chn:%d att:%d attdelta:%d\r\n",__func__,ulChan,ulAtt,lAttDeta);
    return ulRetVal;
}
#if 0
UINT32 BspSetPaTempDataType(UINT32 fileType)
{
    /* 0 表示优先从TBL_KIND_OF_PATEMPGAIN 加载, 其他表示优先从TBL_KIND_OF_PAGAINTEMPTBL加载 */
    s_ulPaTempType = fileType;
    return BSP_OK;
}

UINT32 BspGetPaTempDataType(VOID)
{
    return s_ulPaTempType;
}
#endif

INT32 BspFixTempByStartEndTemp(INT32 lTemp, INT32 lTempStart, INT32 lTempStop)
{
    INT32 tmpVal = 0;

    tmpVal = lTemp;
    if (tmpVal < lTempStart)
    {
        tmpVal = lTempStart;
    }
    else if (lTemp > lTempStop)
    {
        tmpVal = lTempStop;
    }

    return tmpVal;
}

UINT32 BspGetTempGain(UINT32 usGainType, UINT32 ulRecordIndex, UINT32 ulNextRecordIndex, T_TempRecord *ptTempTable, INT32* plTempVal, INT32* plTempGain, INT32* plNextTempVal, INT32* plNextTempGain)
{
    INPUT_POINTER_CHECK(ptTempTable);
    INPUT_POINTER_CHECK(plTempVal);
    INPUT_POINTER_CHECK(plTempGain);
    INPUT_POINTER_CHECK(plNextTempVal);
    INPUT_POINTER_CHECK(plNextTempGain);

    switch (usGainType)
    {
        case TBL_TX_GAIN:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lTxGain;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lTxGain;
            break;
        case TBL_TX_FWD:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lTxFwd;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lTxFwd;
            break;
        case TBL_TX_REV:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lTxRev;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lTxRev;
            break;
        case TBL_RX_RSSI:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lRxRssiM;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lRxRssiM;
            break;
        case TBL_RX_RSSID:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lRxRssiD;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lRxRssiD;
            break;
        case TBL_TXBEAM_GAIN:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lTxGain;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lTxGain;
            break;
        case TBL_TXBEAM_FWD:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lTxFwd;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lTxFwd;
            break;
        case TBL_RXBEAM_RSSI:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lRxRssiM;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lRxRssiM;
            break;
        case TBL_RX_ISOCAL:
        case TBL_DELT_RX_GAIN:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lRxCali;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lRxCali;
            break;
        case TBL_TX_ACCAL:
        case TBL_DELT_TX_GAIN:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lTxCali;
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lTxCali;
            break;
        case TBL_TXFWD_ANALOG:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lAnalogFwd;
            //coverity[cert_ctr50_cpp_violation:SUPPRESS]
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            //coverity[cert_ctr50_cpp_violation:SUPPRESS]
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lAnalogFwd;
            break;
        case TBL_TXREV_ANALOG:
            *plTempVal  = ptTempTable[ulRecordIndex].lTemp;
            *plTempGain = ptTempTable[ulRecordIndex].lAnalogRev;
            //coverity[cert_ctr50_cpp_violation:SUPPRESS]
            *plNextTempVal  = ptTempTable[ulNextRecordIndex].lTemp;
            //coverity[cert_ctr50_cpp_violation:SUPPRESS]
            *plNextTempGain = ptTempTable[ulNextRecordIndex].lAnalogRev;
            break;
        default:
            dbgErr("%s:usType error!\n", __FUNCTION__);
            return BSP_ERROR;
    }
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetTempComps
 * 功能描述: 获取功放或者PA的温度补偿的具体实现函数
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTempComps(UINT16 usGainType, UINT32 ulTempType,
        UINT32 chan, UINT32 ulCenterFreq, INT32 lTemp, INT32 *plVal)
{
    UINT32  ulRetVal = BSP_OK;
    TTrxTempGainCaliData *ptTrxTempData;
    TPaTempGainCaliData  *ptPaTempData;
    T_TempRecord *ptTempTable;
    UINT32 ulFreqBand, ulRecordIndex, ulRecordNum, ulNextRecordIndex;
    INT32  lTempStep, lTempStart, lTempStop;
    INT32  lTempVal, lTempGain, lNextTempVal, lNextTempGain;
    UINT32 ulTblIndex = 0;
    UINT32 ulMsType =0;
    INT32 lTmpVal = 0;

    dbgInfoEx("%s: usGainType=%d,oriChan=0x%x\n", __FUNCTION__, usGainType, chan);
    ulTblIndex = (chan>>16)&0xff;  /*该通道使用的校准表的编号 9124支持同一类型校准表 不同通道使用不同的表 bit16-23*/
    ulMsType =(chan>>24)&0xff;     /*该通道是否拉远 拉远通道的PA温补只在子端，单板温补只在母端 bit24-31*/
    chan = chan &0xffff;           /*该通道原始校准通道号*/
    dbgInfoEx("%s: ulTblIndex = %d, ulMsType= %d chan %d \n", __FUNCTION__, ulTblIndex, ulMsType, chan);

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(plVal);
    TBL_CHAN_VALID_CHECK(chan);

    ulFreqBand = _BspGetFreqBand(ulCenterFreq);
    switch (ulTempType)
    {
        case E_TEMP_TYPE_TRX:
            TRXTEMP_CHECK(ulMsType, ulTblIndex)
            ptTrxTempData = (TTrxTempGainCaliData *)_BspGetCalibData(TBL_KIND_OF_TRXTEMPGAIN,ulTblIndex);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTrxTempData);
            _TRXTEMPFILE_LOADED_CHECK(ptTrxTempData, chan);
            ptTempTable = ptTrxTempData->atTrxTempGainCaliPath[chan].patGroupRecord[ulFreqBand];
            lTempStep   = ptTrxTempData->atTrxTempGainCaliPath[chan].tHeader.lTempStep;
            lTempStart  = ptTrxTempData->atTrxTempGainCaliPath[chan].tHeader.lTempStart;
            lTempStop   = ptTrxTempData->atTrxTempGainCaliPath[chan].tHeader.lTempStop;
            ulRecordNum = ptTrxTempData->atTrxTempGainCaliPath[chan].aulRecordNum[ulFreqBand];
            break;
        case E_TEMP_TYPE_PA:
            /* 刘航2016-5-17 功放温补从PaTempGain.txt读取 */
            /* 刘航2016-5-25 优先从PaTempGain.txt读取,失败时再从PaGainTempTbl.txt */
            PATEMP_CHECK(ulMsType, ulTblIndex)
            ptPaTempData = (TPaTempGainCaliData *)_BspGetCalibData(TBL_KIND_OF_PATEMPGAIN,ulTblIndex);
            if (NULL == ptPaTempData || TBL_LOAD_SUCC != ptPaTempData->atPaTempGainCaliPath[chan].ulPathLoadFalg)
            {
                ptPaTempData = (TPaTempGainCaliData *)_BspGetCalibData(TBL_KIND_OF_PAGAINTEMPTBL,chan);
                _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptPaTempData);
                _PATEMPFILE_LOADED_CHECK(ptPaTempData, chan);
            }
            ptTempTable = ptPaTempData->atPaTempGainCaliPath[chan].patGroupRecord[ulFreqBand];
            lTempStep   = ptPaTempData->atPaTempGainCaliPath[chan].tHeader.lTempStep;
            lTempStart  = ptPaTempData->atPaTempGainCaliPath[chan].tHeader.lTempStart;
            lTempStop   = ptPaTempData->atPaTempGainCaliPath[chan].tHeader.lTempStop;
            ulRecordNum = ptPaTempData->atPaTempGainCaliPath[chan].aulRecordNum[ulFreqBand];
            break;
        default:
            dbgErr("ulTempType error!\n");
            return BSP_ERROR;
    }
    if (0 == lTempStep)
    {
        dbgErr("%s:temp step error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    /* 温度超出边界,按照边界（温度增益）处理。*/
    lTmpVal = BspFixTempByStartEndTemp(lTemp, lTempStart, lTempStop);
    lTemp = lTmpVal;
    ulRecordIndex = (UINT32)((lTemp - lTempStart) / lTempStep);
    if (ulRecordIndex >= ulRecordNum)
    {
        dbgErr("%s:RecordIndex ERROR!ulRecordIndex=%d,ulRecordNum=%d\n",
            __FUNCTION__, ulRecordIndex, ulRecordNum);
        return BSP_ERROR;
    }
    ulNextRecordIndex = (ulRecordIndex == ulRecordNum - 1) ? ulRecordIndex : ulRecordIndex + 1;

    if(BSP_OK != BspGetTempGain(usGainType, ulRecordIndex, ulNextRecordIndex, ptTempTable, &lTempVal, &lTempGain, &lNextTempVal, &lNextTempGain))
    {
        return BSP_ERROR;
    }
    dbgInfoEx("\nlTemp = %d, lTempVal = %d, lTempGain =%d, lNextTempVal =%d, lNextTempGain=%d\n",lTemp, lTempVal, lTempGain, lNextTempVal, lNextTempGain);

    *plVal = _LINEAR_INSERT(lTemp, lTempVal, lTempGain, lNextTempVal, lNextTempGain);
    dbgInfoEx("\nplVal=%d\n",*plVal);
    return ulRetVal;
}

UINT32 BspGetIfFreqInfo(UINT16 usType, UINT32 caliChn, UINT32 ulTblIndex, UINT32* pFreqStep, UINT32* pRecordNum, UINT32* pIfRange, T_FreqRecord** pptFreqTable)
{
    TTxGainCaliData *ptTxGainData;
    TTxFwdCaliData *ptTxFwdData;
    TTxRevCaliData *ptTxRevData;
    TRxRssiCaliData *ptRxRssiData;
    TDeltTxGainCaliData *ptDeltTxGainData;
    TDeltRxGainCaliData *ptDeltRxGainData;

    INPUT_POINTER_CHECK(pFreqStep);
    INPUT_POINTER_CHECK(pRecordNum);
    INPUT_POINTER_CHECK(pIfRange);
    INPUT_POINTER_CHECK(pptFreqTable);

    switch (usType)
    {
        case TBL_TX_GAIN:
            ptTxGainData = (TTxGainCaliData *)_BspGetCalibData(TBL_KIND_OF_TXGAIN,ulTblIndex);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTxGainData);
            _TXGAINFILE_IF_LOADED_CHECK(ptTxGainData, caliChn);
            *pFreqStep = ptTxGainData->atTxGainCaliPath[caliChn].tHeader.ulIfStep;
            *pptFreqTable = ptTxGainData->atTxGainCaliPath[caliChn].ptIfRecord;
            *pRecordNum = ptTxGainData->atTxGainCaliPath[caliChn].ulIfRecordNum;
            *pIfRange     = ptTxGainData->atTxGainCaliPath[caliChn].tHeader.ulIfRange;
            break;
        case TBL_TX_FWD:
            ptTxFwdData = (TTxFwdCaliData *)_BspGetCalibData(TBL_KIND_OF_TxFWD,ulTblIndex);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTxFwdData);
            _TXFWDFILE_IF_LOADED_CHECK(ptTxFwdData, caliChn);
            *pFreqStep = ptTxFwdData->atTxFwdCaliPath[caliChn].tHeader.ulIfStep;
            *pptFreqTable = ptTxFwdData->atTxFwdCaliPath[caliChn].ptIfRecord;
            *pRecordNum = ptTxFwdData->atTxFwdCaliPath[caliChn].ulIfRecordNum;
            *pIfRange     = ptTxFwdData->atTxFwdCaliPath[caliChn].tHeader.ulIfRange;
            break;
        case TBL_TX_REV:
            ptTxRevData = (TTxRevCaliData *)_BspGetCalibData(TBL_KIND_OF_TxREV,ulTblIndex);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptTxRevData);
            _TXREVFILE_IF_LOADED_CHECK(ptTxRevData, caliChn);
            *pFreqStep = ptTxRevData->atTxRevCaliPath[caliChn].tHeader.ulIfStep;
            *pptFreqTable = ptTxRevData->atTxRevCaliPath[caliChn].ptIfRecord;
            *pRecordNum = ptTxRevData->atTxRevCaliPath[caliChn].ulIfRecordNum;
            *pIfRange     = ptTxRevData->atTxRevCaliPath[caliChn].tHeader.ulIfRange;
            break;
        case TBL_RX_RSSI:
            ptRxRssiData = (TRxRssiCaliData *)_BspGetCalibData(TBL_KIND_OF_RXRSSI,ulTblIndex);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptRxRssiData);
            _RXRSSIFILE_IF_LOADED_CHECK(ptRxRssiData, caliChn);
            *pFreqStep = ptRxRssiData->atRxRssiCaliPath[caliChn].tHeader.ulIfStep;
            *pptFreqTable = ptRxRssiData->atRxRssiCaliPath[caliChn].ptIfRecord;
            *pRecordNum = ptRxRssiData->atRxRssiCaliPath[caliChn].ulIfRecordNum;
            *pIfRange     = ptRxRssiData->atRxRssiCaliPath[caliChn].tHeader.ulIfRange;
            break;
        case TBL_DELT_TX_GAIN:
            ptDeltTxGainData = (TDeltTxGainCaliData *)_BspGetCalibData(TBL_KIND_OF_DELTTXGAIN,ulTblIndex);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptDeltTxGainData);
            _DELTTXGAINFILE_IF_LOADED_CHECK(ptDeltTxGainData, caliChn);
            *pFreqStep = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].tHeader.ulIfStep;
            *pptFreqTable = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].ptIfRecord;
            *pRecordNum = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].ulIfRecordNum;
            *pIfRange     = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].tHeader.ulIfRange;
            break;
        case TBL_DELT_RX_GAIN:
            ptDeltRxGainData = (TDeltRxGainCaliData *)_BspGetCalibData(TBL_KIND_OF_DELTRXGAIN,ulTblIndex);
            _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptDeltRxGainData);
            _DELTRXGAINFILE_IF_LOADED_CHECK(ptDeltRxGainData, caliChn);
            *pFreqStep = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].tHeader.ulIfStep;
            *pptFreqTable = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].ptIfRecord;
            *pRecordNum = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].ulIfRecordNum;
            *pIfRange     = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].tHeader.ulIfRange;
            break;
        case TBL_MBA_GAIN:
            return BSP_OK;
        case TBL_TXBEAM_GAIN:
            return BSP_OK;
        case TBL_RXBEAM_RSSI:
            return BSP_OK;
        case TBL_TXBEAM_FWD:
            return BSP_OK;
        case TBL_TX_ACCAL:
            return BSP_OK;
        case TBL_RX_ISOCAL:
            return BSP_OK;
        default:
            dbgErr("usType error!\n");
            return BSP_ERROR;
    }
    return BSP_GET_IF_FREQ_INFO_CAL;
}
/**************************************************************************
 * 函数名称:
 * 功能描述: 获取指定通道的中频校准值
 * 输入参数: usType    - 校准类型
             ulCenterFreq-中心频点
             ulCarrFreq- 载波频点
             ulBw      - 载波带宽
             ulChan    - 通道号,从0开始
 * 输出参数: plVal
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月16日 10090699    创建
 **************************************************************************/
UINT32 _BspGetIfFreqVal(UINT16 usType, UINT32 caliChn,
        UINT32 ulCenterFreq, UINT32 ulCarrFreq, UINT32 ulBw, INT32 *plVal)
{
    UINT32 ulRetVal = BSP_OK;
    T_FreqRecord *ptFreqTable;
    INT32  lTmpFreq, lRoundFreq;
    UINT32 ulFreqStep, ulRecordNum, ulIfRange;
    UINT32 ulRecordIndex;
    UINT32 ulTblIndex = 0;
    UINT32 ret = BSP_GET_IF_FREQ_INFO_CAL;

     dbgInfoEx("%s: usType=%d, oriChan=0x%x\n", __FUNCTION__, usType, caliChn);
     ulTblIndex = (caliChn>>16)&0xffff;  /*该通道使用的校准表的编号 9124支持同一类型校准表 不同通道使用不同的表 bit16-23*/
     caliChn = caliChn &0xff;            /*该通道原始校准通道号*/

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(plVal);
    TBL_CHAN_VALID_CHECK(caliChn);

    lTmpFreq = (INT32)(ulCarrFreq - ulCenterFreq);
    ret = BspGetIfFreqInfo(usType, caliChn, ulTblIndex, &ulFreqStep, &ulRecordNum, &ulIfRange, &ptFreqTable);
    if(BSP_GET_IF_FREQ_INFO_CAL != ret)
    {
        return ret;
    }
    if (0 == ulFreqStep)
    {
        dbgErr("%s:freq step error!usType=%d,ulChan=%d\n", __FUNCTION__, usType, caliChn);
        return BSP_ERROR;
    }
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptFreqTable);

    lRoundFreq = (lTmpFreq/(INT32)ulFreqStep)*(INT32)ulFreqStep;
    if (lRoundFreq > (INT32)(ulIfRange/2))
    {
        lRoundFreq = (INT32)(ulIfRange/2);
    }
    else if (lRoundFreq < (-1)*(INT32)(ulIfRange/2))
    {
        lRoundFreq = (-1)*(INT32)(ulIfRange/2);
    }

    ulRecordIndex = ((UINT32)lRoundFreq +(ulIfRange/2)) / ulFreqStep;
    if (ulRecordIndex >= ulRecordNum)
    {
        dbgInfoEx("%s:RecordIndex ERROR!ulRecordIndex=%d,ulRecordNum=%d\n",
            __FUNCTION__, ulRecordIndex, ulRecordNum);
        return BSP_ERROR;
    }

    if ((UINT32)ptFreqTable[ulRecordIndex].lFreq != (ulRecordIndex*ulFreqStep))
    {
        dbgErr("%s:ptFreqTable[%d].lFreq(%d) != (ulRecordIndex(%d)*ulFreqStep(%d))!\n",
            __FUNCTION__, ulRecordIndex, ptFreqTable[ulRecordIndex].lFreq,
            ulRecordIndex, ulFreqStep);
        return BSP_ERROR;
    }

    *plVal = ptFreqTable[ulRecordIndex].lCompVal;
    if ((ulRecordIndex >= (ulBw/ulFreqStep/2)) &&
        (ulRecordIndex <= ((ulIfRange/ulFreqStep)-(ulBw/ulFreqStep/4))))
    {
        if(ulBw != 0)   /* 接收到带宽不是0时统计平均*/
        {
            ulRetVal = _BspAvgCal(ptFreqTable,lTmpFreq,ulRecordIndex,ulRecordNum,ulBw,ulFreqStep,plVal);
        }
    }

    dbgInfoEx("[%s]type:%d,ch:%d,freq:%d,bw:%d,gain:%d\n",
               __FUNCTION__, usType, caliChn, ulCarrFreq, ulBw, *plVal);

    return ulRetVal;
}

VOID BspJudgeCarrFreq(UINT32* pulCarrFreq, UINT32 ulStartFreq, UINT32 ulStopFreq)
{
    if(*pulCarrFreq < ulStartFreq)
    {
        *pulCarrFreq = ulStartFreq;
    }
    if(*pulCarrFreq > ulStopFreq)
    {
        *pulCarrFreq = ulStopFreq;
    }
}

UINT32 BspGetRfFreqInfo(UINT16 usType, UINT32 caliChn, UINT32 ulTblIndex, UINT32 ulCarrFreq, UINT32 ulFreqBand, UINT32* pulFreqStep, T_FreqRecord** pptFreqTable, UINT32* pulRecordNum, UINT32* pulStartFreq, UINT32* pulStopFreq)
{
    TTxGainCaliData *ptTxGainData=NULL;
    TTxFwdCaliData *ptTxFwdData=NULL;
    TTxRevCaliData *ptTxRevData=NULL;
    TRxRssiCaliData *ptRxRssiData=NULL;
    TMbaGainCaliData *ptMbaGainData=NULL;
    TCalGainCaliData *ptTxBeamGainData=NULL;
    TCalGainCaliData *ptRxBeamRssiData=NULL;
    TCalGainCaliData *ptTxBeamFwdData=NULL;
    TTxAcCalCaliData *ptTxAcCalData=NULL;
    TRxIsoCalCaliData *ptRxIsoCalData=NULL;
    TDeltTxGainCaliData *ptDeltTxGainData=NULL;
    TDeltRxGainCaliData *ptDeltRxGainData=NULL;

    INPUT_POINTER_CHECK(pulFreqStep);
    INPUT_POINTER_CHECK(pptFreqTable);
    INPUT_POINTER_CHECK(pulRecordNum);
    INPUT_POINTER_CHECK(pulStartFreq);
    INPUT_POINTER_CHECK(pulStopFreq);

    switch (usType)
    {
        case TBL_TX_GAIN:
            ulFreqBand  = BspGetFreqBandNum(caliChn,TX, ulCarrFreq); /*根据载波频点判断频段*/
            ptTxGainData = (TTxGainCaliData *)_BspGetCalibData(TBL_KIND_OF_TXGAIN,ulTblIndex);
            _TXGAINFILE_RF_LOADED_CHECK(ptTxGainData, caliChn);
            *pulFreqStep = ptTxGainData->atTxGainCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptTxGainData->atTxGainCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptTxGainData->atTxGainCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptTxGainData->atTxGainCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptTxGainData->atTxGainCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_TX_FWD:
            ulFreqBand  = BspGetFreqBandNum(caliChn,TX, ulCarrFreq); /*根据载波频点判断频段*/
            ptTxFwdData = (TTxFwdCaliData *)_BspGetCalibData(TBL_KIND_OF_TxFWD,ulTblIndex);
            _TXFWDFILE_RF_LOADED_CHECK(ptTxFwdData, caliChn);
            *pulFreqStep = ptTxFwdData->atTxFwdCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptTxFwdData->atTxFwdCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptTxFwdData->atTxFwdCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptTxFwdData->atTxFwdCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptTxFwdData->atTxFwdCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_TX_REV:
            ulFreqBand  = BspGetFreqBandNum(caliChn,TX, ulCarrFreq); /*根据载波频点判断频段*/
            ptTxRevData = (TTxRevCaliData *)_BspGetCalibData(TBL_KIND_OF_TxREV,ulTblIndex);
            _TXREVFILE_RF_LOADED_CHECK(ptTxRevData, caliChn);
            *pulFreqStep = ptTxRevData->atTxRevCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptTxRevData->atTxRevCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptTxRevData->atTxRevCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptTxRevData->atTxRevCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptTxRevData->atTxRevCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_RX_RSSI:
            ulFreqBand  = BspGetFreqBandNum(caliChn,RX, ulCarrFreq); /*根据载波频点判断频段*/
            ptRxRssiData = (TRxRssiCaliData *)_BspGetCalibData(TBL_KIND_OF_RXRSSI,ulTblIndex);
            _RXRSSIFILE_RF_LOADED_CHECK(ptRxRssiData, caliChn);
            *pulFreqStep = ptRxRssiData->atRxRssiCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptRxRssiData->atRxRssiCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptRxRssiData->atRxRssiCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptRxRssiData->atRxRssiCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptRxRssiData->atRxRssiCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_MBA_GAIN:
            ptMbaGainData = (TMbaGainCaliData *)_BspGetCalibData(TBL_KIND_OF_MBAGAIN,0);
            _MBAGAINFILE_RF_LOADED_CHECK(ptMbaGainData, caliChn);
            *pulFreqStep = ptMbaGainData->atMbaGainCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptMbaGainData->atMbaGainCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptMbaGainData->atMbaGainCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptMbaGainData->atMbaGainCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptMbaGainData->atMbaGainCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
       case TBL_TXBEAM_GAIN:
            ptTxBeamGainData = (TCalGainCaliData *)_BspGetCalibData(TBL_KIND_OF_CALGAIN,0);
            _CALGAIN_LOADED_CHECK(ptTxBeamGainData, caliChn);
            *pulFreqStep =  ptTxBeamGainData->atPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptTxBeamGainData->atPath[caliChn].patRecord[ulFreqBand];
            *pulRecordNum = ptTxBeamGainData->atPath[caliChn].aulRecordNum[ulFreqBand];
            *pulStartFreq = ptTxBeamGainData->atPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptTxBeamGainData->atPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_RXBEAM_RSSI:
            ptRxBeamRssiData = (TCalGainCaliData *)_BspGetCalibData(TBL_KIND_OF_CALGAIN,5);
            _CALGAIN_LOADED_CHECK(ptRxBeamRssiData, caliChn);
            *pulFreqStep =  ptRxBeamRssiData->atPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptRxBeamRssiData->atPath[caliChn].patRecord[ulFreqBand];
            *pulRecordNum = ptRxBeamRssiData->atPath[caliChn].aulRecordNum[ulFreqBand];
            *pulStartFreq = ptRxBeamRssiData->atPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptRxBeamRssiData->atPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_TXBEAM_FWD:
            ptTxBeamFwdData = (TCalGainCaliData *)_BspGetCalibData(TBL_KIND_OF_CALGAIN,6);
            _CALGAIN_LOADED_CHECK(ptTxBeamFwdData, caliChn);
            *pulFreqStep =  ptTxBeamFwdData->atPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptTxBeamFwdData->atPath[caliChn].patRecord[ulFreqBand];
            *pulRecordNum = ptTxBeamFwdData->atPath[caliChn].aulRecordNum[ulFreqBand];
            *pulStartFreq = ptTxBeamFwdData->atPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptTxBeamFwdData->atPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_TX_ACCAL:
            ptTxAcCalData = (TTxAcCalCaliData *)_BspGetCalibData(TBL_KIND_OF_TXACCAL,0);
            _TXACCALFILE_RF_LOADED_CHECK(ptTxAcCalData, caliChn);
            *pulFreqStep = ptTxAcCalData->atTxAcCalCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptTxAcCalData->atTxAcCalCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptTxAcCalData->atTxAcCalCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptTxAcCalData->atTxAcCalCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptTxAcCalData->atTxAcCalCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_RX_ISOCAL:
            ptRxIsoCalData = (TRxIsoCalCaliData *)_BspGetCalibData(TBL_KIND_OF_RXISOCAL,0);
            _RXISOCALFILE_RF_LOADED_CHECK(ptRxIsoCalData, caliChn);
            *pulFreqStep = ptRxIsoCalData->atRxIsoCalCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptRxIsoCalData->atRxIsoCalCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptRxIsoCalData->atRxIsoCalCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptRxIsoCalData->atRxIsoCalCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptRxIsoCalData->atRxIsoCalCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_DELT_TX_GAIN:
            ulFreqBand  = BspGetFreqBandNum(caliChn,TX, ulCarrFreq); /*根据载波频点判断频段*/
            ptDeltTxGainData = (TDeltTxGainCaliData *)_BspGetCalibData(TBL_KIND_OF_DELTTXGAIN,ulTblIndex);
            _DELTTXGAINFILE_RF_LOADED_CHECK(ptDeltTxGainData, caliChn);
            *pulFreqStep = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptDeltTxGainData->atDeltTxGainCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        case TBL_DELT_RX_GAIN:
            ulFreqBand  = BspGetFreqBandNum(caliChn,RX, ulCarrFreq); /*根据载波频点判断频段*/
            ptDeltRxGainData = (TDeltRxGainCaliData *)_BspGetCalibData(TBL_KIND_OF_DELTRXGAIN,ulTblIndex);
            _DELTRXGAINFILE_RF_LOADED_CHECK(ptDeltRxGainData, caliChn);
            *pulFreqStep = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].tHeader.aulRfStep[ulFreqBand];
            *pptFreqTable = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].patRfRecord[ulFreqBand];
            *pulRecordNum = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].aulRfRecordNum[ulFreqBand];
            *pulStartFreq = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].tHeader.aulStartFreq[ulFreqBand];
            *pulStopFreq  = ptDeltRxGainData->atDeltRxGainCaliPath[caliChn].tHeader.aulStopFreq[ulFreqBand];
            break;
        default:
            dbgErr("%s usType=%d error!\n",__FUNCTION__,usType);
            return BSP_ERROR;
    }

    return BSP_OK;
}


/**************************************************************************
 * 函数名称: _BspGetRfFreqVal
 * 功能描述: 获取指定通道的射频校准值
 * 输入参数: usType    - 校准类型
             ulCenterFreq-中心频点
             ulCarrFreq- 载波频点
             ulBw      - 载波带宽
             ulChan    - 通道号,从0开始
 * 输出参数: plVal
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月16日 10090699    创建
 **************************************************************************/
UINT32 _BspGetRfFreqVal(UINT16 usType, UINT32 caliChn,
        UINT32 ulCenterFreq, UINT32 ulCarrFreq, UINT32 ulBw, INT32 *plVal,
        INT32 *plBdTemp, INT32 *plPaTemp, UINT32 compType)
{
    UINT32 ulRetVal = BSP_OK;
    T_FreqRecord *ptFreqTable=NULL;
    UINT32 ulRoundFreq;
    UINT32 ulFreqStep, ulRecordNum, ulFreqBand;
    UINT32 ulRecordIndex, ulStartFreq, ulStopFreq;
    UINT32 ulValidStart, ulValidEnd;
    INT32 lCompVal = 0;
    UINT32 ulNextIndex = 0;
    UINT32 bspChn = 0;
    UINT32 ulTblIndex = 0;
    UINT32 ret = BSP_OK;

    dbgInfoEx("%s: usType=%d,oriChan=0x%x\n", __FUNCTION__, usType, caliChn);
    ulTblIndex = (caliChn>>16)&0xff;  /*该通道使用的校准表的编号 9124支持同一类型校准表 不同通道使用不同的表 bit16-23*/
    caliChn = caliChn &0xffff;        /*该通道原始校准通道号*/

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(plVal);
    TBL_CHAN_VALID_CHECK(caliChn);

    ulFreqBand = _BspGetFreqBand(ulCarrFreq);

    ret = BspGetRfFreqInfo(usType, caliChn, ulTblIndex, ulCarrFreq, ulFreqBand, &ulFreqStep, &ptFreqTable, &ulRecordNum, &ulStartFreq, &ulStopFreq);
    if(BSP_OK != ret)
    {
        return BSP_ERROR;
    }

    if (0 == ulFreqStep)
    {
        dbgInfoEx("%s:freq step error!usType=%d,ulChan=%d\n", __FUNCTION__, usType, caliChn);
        return BSP_ERROR;
    }
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptFreqTable);
    ulRoundFreq = _BspFreqRound(ulCarrFreq,ulStartFreq,ulStopFreq,ulFreqStep);

    ulRecordIndex = (ulRoundFreq - ulStartFreq) / ulFreqStep;
    if (ulRecordIndex >= ulRecordNum)
    {
        dbgErr("%s:RecordIndex ERROR!ulRecordIndex=%d,ulRecordNum=%d\n",
            __FUNCTION__, ulRecordIndex, ulRecordNum);
        return BSP_ERROR;
    }

    if ((UINT32)ptFreqTable[ulRecordIndex].lFreq != ulRoundFreq)
    {
        dbgInfoEx("%s:ptFreqTable[%d].lFreq(%d) != RoundFreq(%d)!\n",
            __FUNCTION__, ulRecordIndex, ptFreqTable[ulRecordIndex].lFreq,
            ulRoundFreq);
        return BSP_ERROR;
    }

    (NULL == plBdTemp) ? 0 : (*plBdTemp = ptFreqTable[ulRecordIndex].lBoardTemp);
    (NULL == plPaTemp) ? 0 : (*plPaTemp = ptFreqTable[ulRecordIndex].lPaTemp);

    if(TBL_RX_RSSI == usType)
    {
        BspGetBspChnByCaliChn(caliChn,RX,&bspChn);
        BspAdpGetBoardFreqValue(bspChn,0,RX,START_FREQ_FLAG,&ulValidStart);
        BspAdpGetBoardFreqValue(bspChn,0,RX,END_FREQ_FLAG,&ulValidEnd);
    }
    else
    {
        BspGetBspChnByCaliChn(caliChn,TX,&bspChn);
        BspAdpGetBoardFreqValue(bspChn,0,TX,START_FREQ_FLAG,&ulValidStart);
        BspAdpGetBoardFreqValue(bspChn,0,TX,END_FREQ_FLAG,&ulValidEnd);
    }

    BspJudgeCarrFreq(&ulCarrFreq, ulStartFreq, ulStopFreq);

    /*单个频点补偿*/
    if (compType == COMPS_BY_FREQ_POINT_TYPE)
    {
        ulNextIndex = (ulRecordIndex == ulRecordNum - 1) ? ulRecordIndex : (ulRecordIndex + 1);

        lCompVal = _LINEAR_INSERT(ulCarrFreq, ptFreqTable[ulRecordIndex].lFreq, ptFreqTable[ulRecordIndex].lCompVal,
                    ptFreqTable[ulNextIndex].lFreq, ptFreqTable[ulNextIndex].lCompVal);
        dbgInfoEx("[%s] ulRecordIndex:%d,ulNextIndex:%d,ulCarrFreq:%d,lFreq1:%d,lCompVal1:%d,lFreq2:%d,lCompVal2:%d\n",
               __FUNCTION__, ulRecordIndex, ulNextIndex, ulCarrFreq, ptFreqTable[ulRecordIndex].lFreq, ptFreqTable[ulRecordIndex].lCompVal, ptFreqTable[ulNextIndex].lFreq,ptFreqTable[ulNextIndex].lCompVal);

    }
    else if( compType == COMPS_BY_FREQ_BW_TYPE )
    {
        if ((ulRoundFreq >= (ulValidStart+ulBw/2)) &&
            (ulRoundFreq <= (ulValidEnd-ulBw/2)) &&
            (0 != ulBw))
        {
            ulRetVal = _BspAvgCal(ptFreqTable,ulCarrFreq,ulRecordIndex,ulRecordNum,ulBw,ulFreqStep,&lCompVal);
            dbgInfoEx("[%s] ulCarrFreq:%d,ulRecordIndex:%d,ulRecordNum:%d,ulBw:%d,ulFreqStep:%d,lCompVal:%d\n",
               __FUNCTION__, ulCarrFreq, ulRecordIndex, ulRecordNum, ulBw, ulFreqStep,lCompVal);
        }
    }
    else
    {
        dbgErr("%s Unknow comp type %d\n",__FUNCTION__,compType);
        return BSP_ERROR;
    }
    *plVal = lCompVal;

    dbgInfoEx("[%s]type:%d,ch:%d,freq:%d,bw:%d,compType:%d,gain:%d\n",
               __FUNCTION__, usType, caliChn, ulCarrFreq, ulBw, compType,*plVal);
    return ulRetVal;
}

/**************************************************************************
 * 函数名称: _BspGetTempCompsVal
 * 功能描述: 获取温度补偿总增益，PA和单板温度补偿总和
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTempCompsVal(UINT16 usType, UINT32 caliChn, INT32 lBdTemp,
    INT32 lPaTemp,UINT32 freq, UINT32 ulBw, T_TempComps *pGain,UINT32 comptype)
{
    UINT32 ulRetVal = BSP_OK;
    INT32 lBdTempTbl = 300;
    INT32 lPaTempTbl = 300;
    INT32 lBdTempGain = 0;
    INT32 lPaTempGain = 0;
    INT32 lBdTempGainTbl = 0;
    INT32 lPaTempGainTbl = 0;
    INT32 lRfGain = 0;
    INT32 lTempGain = 0;
    /*INT32 paChn;*/

    TBL_CHAN_VALID_CHECK(caliChn&0xffff);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);

    ulRetVal = _BspGetRfFreqVal(usType, caliChn,
               freq, freq, ulBw, &lRfGain, &lBdTempTbl, &lPaTempTbl,comptype);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] usType:%#x,chan:%d,freq:%d,get rf freq comps val failed\n",
                   __FUNCTION__,usType, caliChn, freq);
        return BSP_ERROR;
    }

    ulRetVal  = _BspGetTempComps(usType, E_TEMP_TYPE_TRX,
                caliChn, freq, lBdTemp, &lBdTempGain);
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_TRX,
                caliChn, freq, lBdTempTbl, &lBdTempGainTbl);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] usType:%#x,chan:%d,freq:%d,get trx temp failed\n",
                   __FUNCTION__,usType, caliChn, freq);
    }

    /*传入PA的通道号*/
    /*BspGetPaChnByCaliChn(caliChn,TX,&paChn);*/
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_PA,
    		caliChn, freq, lPaTemp, &lPaTempGain);
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_PA,
    		caliChn, freq, lPaTempTbl, &lPaTempGainTbl);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] usType:%#x,chan:%d,freq:%d,get pa temp failed\n",
                   __FUNCTION__,usType, caliChn, freq);
    }
    dbgInfoEx("[%s]TempComps:(bdTemp:%d)Gain:%d,(paTemp:%d)Gain:%d;(bdTempTBL:%d)Gain:%d,(paTempTBL:%d)Gain:%d\n",
               __FUNCTION__, lBdTemp,lBdTempGain,lPaTemp,lPaTempGain,lBdTempTbl,lBdTempGainTbl,lPaTempTbl,lPaTempGainTbl);

    lBdTempGain = lBdTempGain - lBdTempGainTbl;
    lPaTempGain = lPaTempGain - lPaTempGainTbl;
    lTempGain   = lBdTempGain + lPaTempGain;

    pGain->bdGainTemp = lBdTempGain;
    pGain->paGainTemp = lPaTempGain;

    dbgInfoEx("[%s]type:%d,ch:%d,freq:%d,bw:%d,bdtemp:%d,patemp:%d,fix:%d = %d + %d\n",
               __FUNCTION__, usType, caliChn, freq, ulBw, lBdTemp, lPaTemp, lTempGain, lBdTempGain, lPaTempGain);

    return BSP_OK;
}
/* Started by AICoder, pid:a561cia9b3727eb14ff609fed0ea160f75486a67 */
/**************************************************************************
 * 函数名称: _BspGetTempCompsValNcr
 * 功能描述: 【NCR】获取温度补偿总增益，PA和单板温度补偿总和，
 *           NCR机型的Txgain和DeltaTxGain的定标温度不同，
 *           该接口是为了满足在不同定标温度下计算温补增益的需求
 * 输入参数: usTypeTbl,usType,caliChn,freq
 * 输出参数: pGain
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2025年05月10日 创建
 **************************************************************************/
UINT32 _BspGetTempCompsValNcr(UINT16 usTypeTbl, UINT16 usType, UINT32 caliChn, UINT32 freq, T_TempComps *pGain)
{
    UINT32 ulRetVal = BSP_OK;
    INT32 lBdTempTbl = 300;
    INT32 lPaTempTbl = 300;
    INT32 lBdTempGain = 0;
    INT32 lPaTempGain = 0;
    INT32 lBdTempGainTbl = 0;
    INT32 lPaTempGainTbl = 0;
    INT32 lRfGain = 0;
    INT32 lTempGain = 0;
    INT32 lBdTemp = 300;
    INT32 lPaTemp = 300;
    UINT32 ulBw = 0;

    TBL_CHAN_VALID_CHECK(caliChn&0xffff);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);

    ulRetVal = BspGetBoardTemp(caliChn, &lBdTemp);
    CHECK_RETVAL_PRN(BspGetBoardTemp, ulRetVal);
    ulRetVal = BspGetPaTemp(caliChn, &lPaTemp);
    CHECK_RETVAL_PRN(BspGetPaTemp, ulRetVal);

    ulRetVal = _BspGetRfFreqVal(usTypeTbl, caliChn,
               freq, freq, ulBw, &lRfGain, &lBdTempTbl, &lPaTempTbl,COMPS_BY_FREQ_POINT_TYPE);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] usTypeTbl:%#x,chan:%d,freq:%d,get rf freq comps val failed\n",
                   __FUNCTION__,usTypeTbl, caliChn, freq);
        return BSP_ERROR;
    }

    ulRetVal = _BspGetTempComps(usType, E_TEMP_TYPE_TRX, caliChn, freq, lBdTemp, &lBdTempGain);
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_TRX, caliChn, freq, lBdTempTbl, &lBdTempGainTbl);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] usType:%#x,chan:%d,freq:%d,get trx temp failed\n",
                   __FUNCTION__,usType, caliChn, freq);
    }

    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_PA, caliChn, freq, lPaTemp, &lPaTempGain);
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_PA, caliChn, freq, lPaTempTbl, &lPaTempGainTbl);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] usType:%#x,chan:%d,freq:%d,get pa temp failed\n",
                   __FUNCTION__,usType, caliChn, freq);
    }
    dbgInfoEx("[%s]TempComps:(bdTemp:%d)Gain:%d,(paTemp:%d)Gain:%d;(bdTempTBL:%d)Gain:%d,(paTempTBL:%d)Gain:%d\n",
               __FUNCTION__, lBdTemp,lBdTempGain,lPaTemp,lPaTempGain,lBdTempTbl,lBdTempGainTbl,lPaTempTbl,lPaTempGainTbl);

    lBdTempGain = lBdTempGain - lBdTempGainTbl;
    lPaTempGain = lPaTempGain - lPaTempGainTbl;
    lTempGain   = lBdTempGain + lPaTempGain;

    pGain->bdGainTemp = lBdTempGain;
    pGain->paGainTemp = lPaTempGain;

    dbgInfoEx("[%s]typeTbl:%d,type:%d,ch:%d,freq:%d,bw:%d,bdtemp:%d,patemp:%d,fix:%d = %d + %d\n",
               __FUNCTION__, usTypeTbl, usType, caliChn, freq, ulBw, lBdTemp, lPaTemp, lTempGain, lBdTempGain, lPaTempGain);

    return ulRetVal;
}
/* Ended by AICoder, pid:a561cia9b3727eb14ff609fed0ea160f75486a67 */
/**************************************************************************
 * 函数名称: BspGetTempGainComps
 * 功能描述: 获取温度补偿总增益，PA和单板温度补偿总和
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 BspGetTempGainComps(UINT32 chanNo, UINT32 type, INT32 *pComps)
{
    UINT32 caliChn = 0;
    UINT32 freq = 0;
    UINT32 retVal = BSP_OK;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    T_TempComps gain = {0};

    INPUT_POINTER_CHECK(pComps);
    BspGetCaliChnByRfChn(chanNo, TX,&caliChn);
    TBL_CHAN_VALID_CHECK(caliChn);

    freq = BspGetMultiCarrCenterFreq(TX,chanNo);
    BspGetBoardTemp(chanNo,&bdtemp);
    BspGetPaTemp(chanNo,&patemp);

    switch( type )
    {
        case TBL_TX_GAIN:
            retVal = _BspGetTempCompsVal(type, caliChn,bdtemp, patemp,freq, 0, &gain, COMPS_BY_FREQ_POINT_TYPE);
            break;
        default:
            return BSP_ERROR;
    }

    *pComps = gain.bdGainTemp + gain.paGainTemp;
    dbgInfoEx("chanNo=%d, sComps=%d\n",chanNo, *pComps);

    return retVal;
}

/* Started by AICoder, pid:bb005v348ep98b7146930a18a0e93c40c833513d */
UINT32 BspGetTempGainRxDComps(UINT32 bspChn, INT32 *pComps)
{
    UINT32 caliChn = 0;
    UINT32 rfChn = 0;
    UINT32 freq = 0;
    UINT32 retVal = BSP_OK;
    UINT32 type =  TBL_RX_RSSID;
    INT32  patemp = 0;

    INPUT_POINTER_CHECK(pComps);

    // 获取校准通道
    if (BspGetCaliChnByBspChn(bspChn, TX, &caliChn) != BSP_OK)
    {
        dbgInfoEx("%s: BspGetCaliChnByRfChn failed, chanNo=%u", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }
    // 校验通道有效性
    TBL_CHAN_VALID_CHECK(caliChn);

    // 获取RF通道
    if (BspGetRfChnByBspChn(bspChn, TX, &rfChn) != BSP_OK)
    {
        dbgInfoEx("%s: BspGetRfChnByBspChn failed, chanNo=%u", __FUNCTION__, bspChn);
        return BSP_ERROR;
    }

    // 校验通道有效性
    TBL_CHAN_VALID_CHECK(rfChn);

    freq = BspGetMultiCarrCenterFreq(TX, rfChn);
    retVal |= BspGetPaTemp(bspChn, &patemp);
    if (retVal != BSP_OK)
    {
        dbgInfoEx("%s: BspGetPaTemp failed, chanNo=%u", __FUNCTION__, bspChn);
        return retVal;
    }

    retVal |= _BspGetTempComps(type, E_TEMP_TYPE_TRX, caliChn, freq, patemp, pComps);
    dbgInfoEx("bspChn=%d, rfChn = %d, caliChn = %d, Comps=%d\n", bspChn, rfChn, caliChn, *pComps);

    return retVal;
}
/* Ended by AICoder, pid:bb005v348ep98b7146930a18a0e93c40c833513d */
/**************************************************************************
 * 函数名称: BspPaDrainAdjVoltCfg
 * 功能描述: 静态调压相关
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/

//设置峰均比值
UINT32 BspSetPwrAvergeRatio(UINT32 ulPwrAvgRatSet)
{
    glPwrAverageRat = ulPwrAvgRatSet;
    return BSP_OK;
}
//获取峰均比值
UINT32 BspGetPwrAverageRatio(UINT32 *ulPwrAvgRatGet)
{
    INPUT_POINTER_CHECK(ulPwrAvgRatGet);
    *ulPwrAvgRatGet = glPwrAverageRat;
    dbgInfoEx("[%s]:Pwr Average Ration is %d\n",__FUNCTION__,glPwrAverageRat);
    return BSP_OK;
}
UINT32 BspGetPaDraAdjCaliData(TPaDrainAdjCaliData *ptDataGet)
{
    UINT32 ulRet = BSP_OK;

    TPaDrainAdjCaliData *ptData = NULL;
    /*UINT32 ulRecord  = 0;*/

    if (NULL == ptDataGet)
    {
        dbgErr("[%s]:The Function Parameter Is Invalid !\n",__FUNCTION__);
        return BSP_ERROR;
    }
    //printf("[%s]The PaDrainAdjCaliData Get !!!!!!!!!!!!!!!!!!!!!!!\n",__FUNCTION__);
    ptData = (TPaDrainAdjCaliData*)_BspGetCalibData(TBL_KIND_OF_PADRAINADJ,0);
    //printf("[%s]The Path Num is %d\n",__FUNCTION__,ptData->tComHeader.ulPathNum);
    if((NULL == ptData) || (TBL_LOAD_SUCC != ptData->atCaliPath[0].aulLoadFlag[0]))
    {
        ulRet = BSP_ERROR;
        dbgErr("[%s]:Get PaDrainAdj.txt Info Failed !\n",__FUNCTION__);
    }
    else
    {
        memcpy(ptDataGet,ptData,sizeof(TPaDrainAdjCaliData));
        dbgInfoEx("[%s]:Get PaDrainAdj.txt Load Flag Is = %d!\n",__FUNCTION__,ptData->atCaliPath[0].aulLoadFlag[0]);
        dbgInfoEx("[%s]:Get PaDrainAdj.txt Path Load Flag Is = %d!\n",__FUNCTION__,ptData->atCaliPath[0].ulPathLoadFlag);
    }

    return ulRet;
}

//@20200422 0表示使用PaDrainAdj.txt：1：表示使用文件PaEngerSavingAdj.txt
UINT32 BspSetPaGainFlag(UINT32 flag)
{
    s_PcGainFileType = flag;
    return BSP_OK;
}

UINT32 BspGetPaGainFlag()
{
    return s_PcGainFileType;
}

UINT32 BspSetPaGain(UINT32 chanNo, INT32 gain)
{
    TBL_CHAN_VALID_CHECK(chanNo);
    glOpenLoopCaliPaGain[chanNo] = gain;
    return BSP_OK;
}

UINT32 BspGetPaGain(UINT32 chanNo, INT32 *pGain)
{
    TBL_CHAN_VALID_CHECK(chanNo);
    INPUT_POINTER_CHECK(pGain);
    *pGain = glOpenLoopCaliPaGain[chanNo];
    return BSP_OK;
}


UINT32 BspGetPaDrainAdjPaGainOld(UINT32 ulChanSel,UINT32 ulPaVolt,INT32 *ulPaGain)
{

    /*INT32  ulRfTblLoadState     = BSP_OK;       */  //文件加载状态
    UINT32 ulPwrAvgRat          = 0;              //获取峰均比
    UINT32 ulRecordNum          = 0;
    UINT32 iLoop                = 0;
    /*UINT32 ulPaVoltGet          = 0;*/
    UINT32 ulCentralFreqPoint   = 0;          // 获取中心频点，BspGetMultiCarrCenterFreq(UINT32 ulTrxType, UINT32 ulRfChnl)
    /*UINT32 ulRecordAddr         = 0;*/
    UINT32 ulPaVoltMin          = 0;
    /*UINT32 ulPaVoltMax          = 0;*/
    UINT32 ulFreqNearest        = 0;
    UINT32 ulParChanNum         = 0;
    UINT32 ulParIndexCtrl       = 0;
    UINT32 ulPaDrainAdjType = 0;

    INPUT_POINTER_CHECK(ulPaGain);
    TBL_CHAN_VALID_CHECK(ulChanSel);

    //TPaDrainAdjCaliData   *ptCaliData = NULL;
    TPaDrainAdjCaliData   ptCaliData  = {0};
    TPaDrainAdjPathRecord *ptRecord   = NULL;
    /*TPaDrainAdjPath       *ptPathData = NULL;*/

    if (BSP_ERROR == (ulCentralFreqPoint = BspGetMultiCarrCenterFreq(TX,ulChanSel)))   //获取中心频点
    {
        *ulPaGain = PA_DRAIN_ADJ_PA_GAIN_DEFAULT;
        dbgErr("[%s]Get Central Frequency Failed!Defuale Pa Gain Is %d\n",__FUNCTION__,*ulPaGain);
        return BSP_ERROR;
    }
    #if 0
    if(BSP_ERROR == BspGetPaDraAdjCaliData(&ulRecordAddr))
    {
        dbgErr("[%s]Get PaDrainAdj.txt Failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    ptCaliData = (TPaDrainAdjCaliData *)ulRecordAddr;
    #endif
    if(BSP_ERROR == BspGetPaDraAdjCaliData(&ptCaliData))
    {
        dbgErr("[%s]Get PaDrainAdj.txt Failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfoEx("[%s]:Central Freq Point = %d\n",__FUNCTION__,ulCentralFreqPoint);

    if(BSP_ERROR == BspGetPwrAverageRatio(&ulPwrAvgRat))                                    //获取峰均比
    {
        ulPwrAvgRat = PWR_AVERAGE_RATIO;
    }
    if(BSP_OK!=BspGetPaDrainAdjTypeByChan(ulChanSel,&ulPaDrainAdjType))
    {
        dbgErr("[%s]GetPaDrainAdjTypeByChan Failed!\n",__FUNCTION__);
        return BSP_ERROR;
    }
    ptRecord           = (TPaDrainAdjPathRecord *)ptCaliData.atCaliPath[ulPaDrainAdjType].patRecord[0];    //TBL_PA_DRAIN_ADJ_NUM 8 ，支持表文件数目
    ulRecordNum        = ptCaliData.atCaliPath[ulPaDrainAdjType].aulRecordNum[0];
    dbgInfoEx("[%s]:Record Number = %d\n",__FUNCTION__,ulRecordNum);
    #if 0
    for(iLoop = 0;iLoop < ulRecordNum;iLoop ++)
    {
        if ((ulPwrAvgRat != ptRecord->lPar) || (ulCentralFreqPoint != ptRecord->ulRfFreq))
        {
            ptRecord ++ ;
        }
    }
    #endif

    for(iLoop = 0;iLoop < ulRecordNum;iLoop ++)
    {
        if (ulPwrAvgRat == ptRecord[iLoop].lPar)
        {
            if (0 == ulParIndexCtrl)
            {
                ulFreqNearest   = abs(ulCentralFreqPoint - ptRecord[iLoop].ulRfFreq);
                ulParChanNum    = iLoop;
                ulParIndexCtrl += 1;
            }
            if (ulFreqNearest > abs(ulCentralFreqPoint - ptRecord[iLoop].ulRfFreq))
            {
                ulFreqNearest   = abs(ulCentralFreqPoint - ptRecord[iLoop].ulRfFreq);
                ulParChanNum    = iLoop;
                ulParIndexCtrl += 1;
            }
            dbgInfoEx("[%s]Get PAR=%d\n",__func__,ptRecord[iLoop].lPar);
        }
    }

    if (PA_DRAIN_ADJ_SEARCH_FAILED == ulParIndexCtrl)
    {
        dbgErr("[%s]Search PAR Failed !\n",__func__);
        *ulPaGain = PA_DRAIN_ADJ_PA_GAIN_DEFAULT;
        return BSP_ERROR;
    }

    ulPaVoltMin = abs(ulPaVolt - (ptRecord[ulParChanNum].atPowGain[0].lPaVolt));
    *ulPaGain = ptRecord[ulParChanNum].atPowGain[0].lPaGain;
    glOpenLoopCaliPaGain[ulChanSel] = *ulPaGain;
    dbgInfoEx("[%s]Get The first Pa Gain is %d,Pa Volt is %d \n",__FUNCTION__,*ulPaGain,ptRecord[ulParChanNum].atPowGain[0].lPaVolt);
    for(iLoop = 1;iLoop < PA_DRAIN_ADJ_POW_LBL_MAX ;iLoop ++)
    {
        dbgInfoEx("[%s]Pa Voltage [%d] is %d \n",__FUNCTION__,iLoop,ptRecord[ulParChanNum].atPowGain[iLoop].lPaVolt);
        if (ulPaVoltMin >= abs(ulPaVolt - (ptRecord[ulParChanNum].atPowGain[iLoop].lPaVolt)))
        {
            ulPaVoltMin = abs(ulPaVolt - (ptRecord[ulParChanNum].atPowGain[iLoop].lPaVolt));
            *ulPaGain = ptRecord[ulParChanNum].atPowGain[iLoop].lPaGain;
            glOpenLoopCaliPaGain[ulChanSel] = *ulPaGain;
            dbgInfoEx("[%s]Get Pa Gain is %d \n",__FUNCTION__,*ulPaGain);
        }
    }

    return BSP_OK;
}

UINT32 BspGetPaDrainAdjPaGain(UINT32 ulChanSel,UINT32 ulPaVolt,INT32 *ulPaGain)
{
    UINT32 parLevel      = 0;
    UINT32 powerLevel    = 0;
    UINT32 freqLevel     = 0;
    UINT32 vdsLevel     = 0;
    UINT32 dataIndex     = 0;
    UINT32 freq          = 0;
    UINT32 paGainPos     = 8;
    UINT32 chanNo        = ulChanSel;
    UINT32 pwrAvgRat     = 0;
    UINT32 tblIndex = 0;
    UINT32 tblChn = chanNo;

    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    INPUT_POINTER_CHECK(ulPaGain);
    TBL_CHAN_VALID_CHECK(ulChanSel);
    (void)BspGetPwrAverageRatio(&pwrAvgRat);

    BspUpdateRfTblIndexAndChn(chanNo, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);
    INPUT_POINTER_CHECK(ptEnSavAdjData->atEnSavAdjPath);

    freq        = BspGetMultiCarrCenterFreq(TX, chanNo);
    parLevel    = BspGetParLevelByFile(pwrAvgRat,chanNo);
    //powerLevel  = BspGetPowerLevelByFile(powerDbm);
    freqLevel   = BspGetFreqLevelByFile(freq,chanNo);
    vdsLevel    = BspGetVdsLevelByFile(ulPaVolt,chanNo);
    dataIndex   = BspGetCombiVdsIndex(parLevel, vdsLevel, freqLevel,chanNo);

    dbgInfoEx("chanNo[%d]: par[%d], vds[%d] freq[%d] data[%d]\n", chanNo, parLevel, vdsLevel, freqLevel, dataIndex);

    if ((dataIndex >= EN_SAV_ADJ_MAX_ROW) || (vdsLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL) ||
        (freqLevel >= PA_ENERGY_SAVING_ADJ_MAX_LEVEL))
    {
        dbgInfoEx("--%s--(%d): chanNo[%d]: par[%d], power[%d] freq[%d] data[%d]\n", __FUNCTION__, __LINE__, chanNo, parLevel, powerLevel, freqLevel, dataIndex);
        return BSP_ERROR;
    }

    *ulPaGain = ptEnSavAdjData->atEnSavAdjPath[tblChn].pCombiData[parLevel].combiItem[dataIndex][paGainPos];
    glOpenLoopCaliPaGain[ulChanSel] = *ulPaGain;
    dbgInfoEx("PaGain[%d]\n", *ulPaGain);
    return BSP_OK;
}

#ifdef BUILD_WITH_OM_FUNC
VOID showpagain()
{
    UINT32 chan = 0;
    for(chan = 0; chan < CHAN_MAX_NUM_SOC; chan++)
    {
        dbgInfo("pa[%d] gain:%d\n", chan, glOpenLoopCaliPaGain[chan]);
    }
}
#endif

/**************************************************************************
 * 函数名称: _BspGetCompsVal
 * 功能描述: 获取总增益，单板温度，PA温度和射频的总增益补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetCompsVal(UINT16 type, UINT32 caliChn, UINT32 freq,
    INT32 bdtemp,INT32 patemp,UINT32 bw,T_CompsData *pGain,UINT32 compType)
{
    UINT32 ulRetVal = BSP_OK;
    INT32  bdTempTbl,paTempTbl;
    INT32  rfGain = 0;
    INT32  ifGain = 0;
    INT32  tempGain = 0;
    UINT32 chanType = 0;
    UINT32 tblIndex = 0;

    TBL_CHAN_VALID_CHECK(caliChn&0xffff);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    chanType = (caliChn>>24)&0xff;
    tblIndex = (caliChn>>16)&0xff;

    ulRetVal = _BspGetRfFreqVal(type, caliChn,
               freq, freq, bw, &rfGain, &bdTempTbl, &paTempTbl,compType);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] get chn[%d] rf freq[%d] gain failed\n",__FUNCTION__,caliChn,freq);

        return BSP_ERROR;
    }
    _BspGetIfFreqVal(type,caliChn,freq,freq,bw,&ifGain);
  

    _BspGetTempCompsVal(type,caliChn,bdtemp,patemp,freq,bw,&(pGain->tempComps),compType);
    caliChn = caliChn&0xffff;    /*放到s_gCaliModifyGain之前防止越界,_BspGetTempCompsVal里9124还是要用完整的信息 */
    pGain->ChannelComps.lRf = rfGain + s_gCaliModifyGain[caliChn][type];/*单板测传递参数修改校准表*/
    pGain->ChannelComps.lIf = ifGain;
    tempGain = (pGain->tempComps.bdGainTemp + pGain->tempComps.paGainTemp);
    //old cfg
    //pGain->comps = (pGain->ChannelComps.lRf + pGain->ChannelComps.lIf) - tempGain + glOpenLoopCaliPaGain[caliChn];//增加静态调压相关PaGain部分
    //new cfg
    if (type == TBL_TX_FWD || type == TBL_TX_REV || type == TBL_RX_RSSI)
    {
        pGain->comps = (pGain->ChannelComps.lRf + pGain->ChannelComps.lIf) - tempGain;
    }
    else if(type == TBL_DELT_TX_GAIN || type == TBL_DELT_RX_GAIN)
    {
        pGain->comps = (pGain->ChannelComps.lRf + pGain->ChannelComps.lIf) + tempGain;
    }
    else
    {
        if((TBL_CHAN_S_TPYE == chanType)&&(tblIndex >= 2))   /*R9124 机型拉远通道是子端+母端增益   只能补一次调压增益*/
        {
             pGain->comps = (pGain->ChannelComps.lRf + pGain->ChannelComps.lIf) - tempGain;
        }
        else
        {
             pGain->comps = (pGain->ChannelComps.lRf + pGain->ChannelComps.lIf) - tempGain + glOpenLoopCaliPaGain[caliChn];//增加静态调压相关PaGain部分 glOpenLoopCaliPaGain这块也要注意子端的通道的处理
        }
    }

    dbgInfoEx("[%s]type:%d,ch:%d,freq:%d,bw:%d,bdtemp:%d,patemp:%d,total gain:%d = lRfGain[%d]+lIfGain[%d]-lTempGain[%d]\n",
               __FUNCTION__, type, caliChn, freq, bw, bdtemp, patemp, pGain->comps,rfGain,ifGain,tempGain);
    if(type==TBL_MBA_GAIN)
    {
        pGain->comps = pGain->ChannelComps.lRf;
    }

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetBeamCompsVal
 * 功能描述: 获取总增益，单板温度，PA温度和射频的总增益补偿
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetBeamCompsVal(UINT16 type, UINT32 caliChn, UINT32 freq,
    INT32 bdtemp,INT32 patemp,UINT32 bw,T_CompsData *pGain,UINT32 compType)
{
    UINT32 ulRetVal = BSP_OK;
    INT32  bdTempTbl,paTempTbl;
    INT32  rfGain = 0;
    INT32  ifGain = 0;
    INT32  tempGain = 0;

    TBL_CHAN_VALID_CHECK(caliChn&0xffff);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);


    ulRetVal = _BspGetRfFreqVal(type, caliChn,
               freq, freq, bw, &rfGain, &bdTempTbl, &paTempTbl,compType);
    if (ulRetVal != BSP_OK)
    {
        dbgInfoEx("[%s] get chn[%d] rf freq[%d] gain failed\n",__FUNCTION__,caliChn,freq);

        return BSP_ERROR;
    }
    _BspGetIfFreqVal(type,caliChn,freq,freq,bw,&ifGain);

    //_BspGetTempCompsVal(type,caliChn,bdtemp,patemp,freq,bw,&(pGain->tempComps),compType);

    pGain->ChannelComps.lRf = rfGain;
    pGain->ChannelComps.lIf = ifGain;
    //tempGain = (pGain->tempComps.bdGainTemp + pGain->tempComps.paGainTemp);
    pGain->comps = (pGain->ChannelComps.lRf + pGain->ChannelComps.lIf) - tempGain;

    dbgInfoEx("[%s]type:%d,ch:%d,freq:%d,bw:%d,bdtemp:%d,patemp:%d,total gain:%d = lRfGain[%d]+lIfGain[%d]-lTempGain[%d]\n",
               __FUNCTION__, type, caliChn, freq, bw, bdtemp, patemp, pGain->comps,rfGain,ifGain,tempGain);
    if(type==TBL_MBA_GAIN)
    {
        pGain->comps = pGain->ChannelComps.lRf;
    }

    return BSP_OK;
}

static UINT32 BspSetSlaveTxGain(UINT32 bspChn, INT32 slaveGain)
{
    if(bspChn >= BSP_MAX_TX_CHAN)
    {
        dbgErr("bspChn is ERR!\n");
        return BSP_ERROR;
    }
    s_slaveTxGain[bspChn] = slaveGain;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取TX GAIN
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTxGain(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 caliChn;
    T_RfTblChanPara tmp = {0};
    UINT32 caliIndex = 0;
    T_ChanRfTblBaseInfo baseInfo = {0};
    INT32 paTempEx = 600;
    INT32 boardTempEx = 550;
    UINT32 slaveChn = 0;
    T_CompsData slaveGain = {0};
    INT32 dsaAtt = 0;
    INT32 cableLoss = 0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetCaliChnByBspChn(bspChn,TX,&caliChn);
    BspGetPortSlaveChnByBspChn(bspChn,RX,&slaveChn);
    ulRetVal = BspGetSingleChanRfTblPara(bspChn, &tmp);
    if(BSP_OK != ulRetVal)   /*旧机型单板下没有传递这个参数 按原来的方式计算 不受影响*/
    {
         ulRetVal = _BspGetCompsVal(TBL_TX_GAIN, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
    }
    else
    {
        ulRetVal = BspGetChanRfTblBaseInfo(bspChn, TBL_TX_FWD, &baseInfo);
        if(BSP_OK != ulRetVal)
        {
            dbgErr("chan %d BspGetChanRfTblBaseInfo failed\n ", bspChn);
            return BSP_ERROR;
        }
        caliIndex = baseInfo.rfTblIndex[0];   /*0- 在母端侧校准表编号 M-0 MS-1 子端portid+2*/
        caliChn = caliChn|(caliIndex<<16);
        caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
        dbgInfoEx("\n");
        dbgInfoEx("*******************chan %d TxGain%d.txt get start********************\n", bspChn, caliIndex);
        ulRetVal = _BspGetCompsVal(TBL_TX_GAIN, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);  /*注意子端通道在母端的一部分没有pa温补 单板温补只在子端*/
        if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道还需要把子端的校准表里的数据取出来  最后加到一起，非拉远通道直接返回即可*/
        {
            INPUT_POINTER_CHECK(tmp.pGetSlaveBoardTemp);
            INPUT_POINTER_CHECK(tmp.pGetSlavePaTemp);
            tmp.pGetSlaveBoardTemp(bspChn,&boardTempEx);
            tmp.pGetSlavePaTemp(bspChn,&paTempEx);
            caliIndex = baseInfo.rfTblIndex[1];  /*1-在子端侧校准表编号*/
            caliChn = slaveChn|(caliIndex<<16);   /*拉远的通道这里要传子端的通道号 但是TXGAIN 增益获取 要额外加glOpenLoopCaliPaGain 通道号会和母端重叠 glOpenLoopCaliPaGain 需要封装个按原始通道号的get接口*/
            caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
            dbgInfoEx("\n");
            dbgInfoEx("*******************chan %d slave TxGain%d.txt get********************\n", bspChn, caliIndex);
            //dbgInfoEx("bspChn %d slaveChn %d boardTempEx %d paTempEx %d caliIndex %d caliChn 0x%x\n",bspChn, slaveChn,  boardTempEx, paTempEx, caliIndex, caliChn);
            ulRetVal = _BspGetCompsVal(TBL_TX_GAIN, caliChn, freq, boardTempEx, paTempEx, bw, &slaveGain,comptype);  /*额外加上子端的增益*/
            if(NULL != tmp.pGetDsaAtt)
            {
                tmp.pGetDsaAtt(bspChn, TX, &dsaAtt);
                BspGetSlaveCableGain(bspChn,tmp.chanType, bdtemp, &cableLoss);
            }
            dbgInfoEx("total = %d + %d + %d + %d\n", pGain->comps, slaveGain.comps, dsaAtt, cableLoss);
            pGain->comps = pGain->comps + slaveGain.comps + dsaAtt + cableLoss;
            BspSetSlaveTxGain(bspChn, slaveGain.comps);
        }
        dbgInfoEx("*******************chan %d all TxGain.txt get end********************\n", bspChn);
        dbgInfoEx("\n");
    }
    return ulRetVal;    /*子母端任意一个校准表异常或者没有  取默认txatt*/
}
UINT32 _BspGetDeltTxGain(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 caliChn;
    T_RfTblChanPara tmp = {0};
    UINT32 caliIndex = 0;
    T_ChanRfTblBaseInfo baseInfo = {0};
    INT32 paTempEx = 600;
    INT32 boardTempEx = 550;
    UINT32 slaveChn = 0;
    T_CompsData slaveGain = {0};
    INT32 dsaAtt = 0;
    INT32 cableLoss = 0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetCaliChnByBspChn(bspChn,TX,&caliChn);
    BspGetPortSlaveChnByBspChn(bspChn,RX,&slaveChn);
    ulRetVal = BspGetSingleChanRfTblPara(bspChn, &tmp);
    if(BSP_OK != ulRetVal)   /*旧机型单板下没有传递这个参数 按原来的方式计算 不受影响*/
    {
         ulRetVal = _BspGetCompsVal(TBL_DELT_TX_GAIN, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
    }
    else
    {
        ulRetVal = BspGetChanRfTblBaseInfo(bspChn, TBL_TX_FWD, &baseInfo);
        if(BSP_OK != ulRetVal)
        {
            dbgErr("chan %d BspGetChanRfTblBaseInfo failed\n ", bspChn);
            return BSP_ERROR;
        }
        caliIndex = baseInfo.rfTblIndex[0];   /*0- 在母端侧校准表编号 M-0 MS-1 子端portid+2*/
        caliChn = caliChn|(caliIndex<<16);
        caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
        dbgInfoEx("\n");
        dbgInfoEx("*******************chan %d TxGain%d.txt get start********************\n", bspChn, caliIndex);
        ulRetVal = _BspGetCompsVal(TBL_DELT_TX_GAIN, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);  /*注意子端通道在母端的一部分没有pa温补 单板温补只在子端*/
        if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道还需要把子端的校准表里的数据取出来  最后加到一起，非拉远通道直接返回即可*/
        {
            INPUT_POINTER_CHECK(tmp.pGetSlaveBoardTemp);
            INPUT_POINTER_CHECK(tmp.pGetSlavePaTemp);
            tmp.pGetSlaveBoardTemp(bspChn,&boardTempEx);
            tmp.pGetSlavePaTemp(bspChn,&paTempEx);
            caliIndex = baseInfo.rfTblIndex[1];  /*1-在子端侧校准表编号*/
            caliChn = slaveChn|(caliIndex<<16);   /*拉远的通道这里要传子端的通道号 但是TXGAIN 增益获取 要额外加glOpenLoopCaliPaGain 通道号会和母端重叠 glOpenLoopCaliPaGain 需要封装个按原始通道号的get接口*/
            caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
            dbgInfoEx("\n");
            dbgInfoEx("*******************chan %d slave TxGain%d.txt get********************\n", bspChn, caliIndex);
            //dbgInfoEx("bspChn %d slaveChn %d boardTempEx %d paTempEx %d caliIndex %d caliChn 0x%x\n",bspChn, slaveChn,  boardTempEx, paTempEx, caliIndex, caliChn);
            ulRetVal = _BspGetCompsVal(TBL_DELT_TX_GAIN, caliChn, freq, boardTempEx, paTempEx, bw, &slaveGain,comptype);  /*额外加上子端的增益*/
            if(NULL != tmp.pGetDsaAtt)
            {
                tmp.pGetDsaAtt(bspChn, TX, &dsaAtt);
                BspGetSlaveCableGain(bspChn,tmp.chanType, bdtemp, &cableLoss);
            }
            dbgInfoEx("total = %d + %d + %d + %d\n", pGain->comps, slaveGain.comps, dsaAtt, cableLoss);
            pGain->comps = pGain->comps + slaveGain.comps + dsaAtt + cableLoss;
            BspSetSlaveTxGain(bspChn, slaveGain.comps);
        }
        dbgInfoEx("*******************chan %d all TxGain.txt get end********************\n", bspChn);
        dbgInfoEx("\n");
    }
    return ulRetVal;    /*子母端任意一个校准表异常或者没有  取默认txatt*/
}

UINT32 BspGetSlaveTxGain(UINT32 bspChn, INT32 *slaveGain)
{
    INPUT_POINTER_CHECK(slaveGain);

    if(bspChn >= BSP_MAX_TX_CHAN)
    {
        dbgErr("bspChn is ERR!\n");
        return BSP_ERROR;
    }
    *slaveGain = s_slaveTxGain[bspChn];

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取TX GAIN
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTxBeamGain(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;


    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    ulRetVal = _BspGetBeamCompsVal(TBL_TXBEAM_GAIN, bspChn, freq, bdtemp,patemp,bw, pGain,comptype);

    return ulRetVal;
}

static UINT32 BspSetSlaveRxGain(UINT32 bspChn, INT32 slaveGain)
{
    if(bspChn >= BSP_MAX_TX_CHAN)
    {
        dbgErr("bspChn is ERR!\n");
        return BSP_ERROR;
    }
    s_slaveRxGain[bspChn] = slaveGain;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取RX GAIN
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetRxGain(UINT32 bspChn, UINT32 mode,INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 caliChn;
    T_RfTblChanPara tmp = {0};
    UINT32 caliIndex = 0;
    T_ChanRfTblBaseInfo baseInfo = {0};
    INT32 paTempEx = 600;
    INT32 boardTempEx = 550;
    UINT32 slaveChn = 0;
    T_CompsData slaveGain = {0};
    INT32 dsaAtt = 0;
    INT32 cableLoss = 0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);

    BspGetCaliChnByBspChn(bspChn,RX,&caliChn);
    BspGetPortSlaveChnByBspChn(bspChn,RX,&slaveChn);
    ulRetVal = BspGetSingleChanRfTblPara(bspChn, &tmp);
    if(BSP_OK != ulRetVal)   /**/
    {
         ulRetVal = _BspGetCompsVal(TBL_RX_RSSI, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
    }
    else
    {
        ulRetVal = BspGetChanRfTblBaseInfo(bspChn, TBL_TX_FWD, &baseInfo);
        if(BSP_OK != ulRetVal)
        {
            dbgErr("chan %d BspGetChanRfTblBaseInfo failed\n ", bspChn);
            return BSP_ERROR;
        }
        caliIndex = baseInfo.rfTblIndex[0];   /*校准表的编号M-0 MS-1 子端portid+2*/
        caliChn = caliChn|(caliIndex<<16);    /*射频校准表编号占bit16-23*/
        caliChn = caliChn|((tmp.chanType&0xf)<<24); /*温度校准表编号占bit24-31*/
        dbgInfoEx("\n");
        dbgInfoEx("*******************chan %d RxRssi%d.txt get start********************\n", bspChn, caliIndex);
        ulRetVal |= _BspGetCompsVal(TBL_RX_RSSI, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
        if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道*/
        {
/*            获取子端的通道号--子端通道号获取子端对应的校准通道号
            获取子端通道的pa温度和单板温度  这块要回调 不能直接调用OOK  如果通信异常需要默认温度 或者直接报错*/
            INPUT_POINTER_CHECK(tmp.pGetSlaveBoardTemp);
            INPUT_POINTER_CHECK(tmp.pGetSlavePaTemp);
            tmp.pGetSlaveBoardTemp(bspChn,&boardTempEx);
            tmp.pGetSlavePaTemp(bspChn,&paTempEx);
            caliIndex = baseInfo.rfTblIndex[1];
            caliChn = slaveChn|(caliIndex<<16);   /*拉远的通道这里要传子端的通道号 但是TXGAIN 增益获取 要额外加glOpenLoopCaliPaGain 通道号会和母端重叠 glOpenLoopCaliPaGain 需要封装个按原始通道号的get接口*/
            caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
            dbgInfoEx("\n");
            dbgInfoEx("*******************chan %d slave RxRssi%d.txt get********************\n", bspChn, caliIndex);
            //dbgInfoEx("bspChn %d slaveChn %d boardTempEx %d paTempEx %d caliIndex %d caliChn 0x%x\n",bspChn, slaveChn,  boardTempEx, paTempEx, caliIndex, caliChn);
            ulRetVal |= _BspGetCompsVal(TBL_RX_RSSI, caliChn, freq, boardTempEx, paTempEx, bw, &slaveGain,comptype);  /*额外加上子端的增益*/
            if(NULL != tmp.pGetDsaAtt)
            {
                tmp.pGetDsaAtt(bspChn, TX, &dsaAtt);
                BspGetSlaveCableGain(bspChn,tmp.chanType, bdtemp, &cableLoss);
            }
            dbgInfoEx("total = %d + %d + %d + %d\n", pGain->comps, slaveGain.comps, dsaAtt, cableLoss);
            pGain->comps = pGain->comps + slaveGain.comps + dsaAtt + cableLoss;
            BspSetSlaveRxGain(bspChn, slaveGain.comps);
        }
        dbgInfoEx("*******************chan %d all RxRssi.txt get end********************\n", bspChn);
        dbgInfoEx("\n");
    }
    return ulRetVal;
}
UINT32 _BspGetDeltRxGain(UINT32 bspChn, UINT32 mode,INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 caliChn;
    T_RfTblChanPara tmp = {0};
    UINT32 caliIndex = 0;
    T_ChanRfTblBaseInfo baseInfo = {0};
    INT32 paTempEx = 600;
    INT32 boardTempEx = 550;
    UINT32 slaveChn = 0;
    T_CompsData slaveGain = {0};
    INT32 dsaAtt = 0;
    INT32 cableLoss = 0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);

    BspGetCaliChnByBspChn(bspChn,RX,&caliChn);
    BspGetPortSlaveChnByBspChn(bspChn,RX,&slaveChn);
    ulRetVal = BspGetSingleChanRfTblPara(bspChn, &tmp);
    if(BSP_OK != ulRetVal)   /**/
    {
         ulRetVal = _BspGetCompsVal(TBL_DELT_RX_GAIN, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
    }
    else
    {
        ulRetVal = BspGetChanRfTblBaseInfo(bspChn, TBL_TX_FWD, &baseInfo);
        if(BSP_OK != ulRetVal)
        {
            dbgErr("chan %d BspGetChanRfTblBaseInfo failed\n ", bspChn);
            return BSP_ERROR;
        }
        caliIndex = baseInfo.rfTblIndex[0];   /*校准表的编号M-0 MS-1 子端portid+2*/
        caliChn = caliChn|(caliIndex<<16);    /*射频校准表编号占bit16-23*/
        caliChn = caliChn|((tmp.chanType&0xf)<<24); /*温度校准表编号占bit24-31*/
        dbgInfoEx("\n");
        dbgInfoEx("*******************chan %d RxRssi%d.txt get start********************\n", bspChn, caliIndex);
        ulRetVal |= _BspGetCompsVal(TBL_DELT_RX_GAIN, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
        if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道*/
        {
/*            获取子端的通道号--子端通道号获取子端对应的校准通道号
            获取子端通道的pa温度和单板温度  这块要回调 不能直接调用OOK  如果通信异常需要默认温度 或者直接报错*/
            INPUT_POINTER_CHECK(tmp.pGetSlaveBoardTemp);
            INPUT_POINTER_CHECK(tmp.pGetSlavePaTemp);
            tmp.pGetSlaveBoardTemp(bspChn,&boardTempEx);
            tmp.pGetSlavePaTemp(bspChn,&paTempEx);
            caliIndex = baseInfo.rfTblIndex[1];
            caliChn = slaveChn|(caliIndex<<16);   /*拉远的通道这里要传子端的通道号 但是TXGAIN 增益获取 要额外加glOpenLoopCaliPaGain 通道号会和母端重叠 glOpenLoopCaliPaGain 需要封装个按原始通道号的get接口*/
            caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
            dbgInfoEx("\n");
            dbgInfoEx("*******************chan %d slave RxRssi%d.txt get********************\n", bspChn, caliIndex);
            //dbgInfoEx("bspChn %d slaveChn %d boardTempEx %d paTempEx %d caliIndex %d caliChn 0x%x\n",bspChn, slaveChn,  boardTempEx, paTempEx, caliIndex, caliChn);
            ulRetVal |= _BspGetCompsVal(TBL_DELT_RX_GAIN, caliChn, freq, boardTempEx, paTempEx, bw, &slaveGain,comptype);  /*额外加上子端的增益*/
            if(NULL != tmp.pGetDsaAtt)
            {
                tmp.pGetDsaAtt(bspChn, TX, &dsaAtt);
                BspGetSlaveCableGain(bspChn,tmp.chanType, bdtemp, &cableLoss);
            }
            dbgInfoEx("total = %d + %d + %d + %d\n", pGain->comps, slaveGain.comps, dsaAtt, cableLoss);
            pGain->comps = pGain->comps + slaveGain.comps + dsaAtt + cableLoss;
            BspSetSlaveRxGain(bspChn, slaveGain.comps);
        }
        dbgInfoEx("*******************chan %d all RxRssi.txt get end********************\n", bspChn);
        dbgInfoEx("\n");
    }
    return ulRetVal;
}

UINT32 BspGetSlaveRxGain(UINT32 bspChn, INT32 *slaveGain)
{
    INPUT_POINTER_CHECK(slaveGain);

    if(bspChn >= BSP_MAX_TX_CHAN)
    {
        dbgErr("bspChn is ERR!\n");
        return BSP_ERROR;
    }
    *slaveGain = s_slaveRxGain[bspChn];

    return BSP_OK;
}


/**************************************************************************
 * 函数名称:
 * 功能描述: 获取RX GAIN
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetRxBeamGain(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);


    ulRetVal = _BspGetBeamCompsVal(TBL_RXBEAM_RSSI, bspChn, freq, bdtemp,patemp,bw, pGain,comptype);

    return ulRetVal;
}
#if 0
/**************************************************************************
 * 函数名称:
 * 功能描述: 获取MBA GAIN
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetMbaGain(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 caliChn;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetCaliChnByBspChn(bspChn,TX,&caliChn);
    ulRetVal = _BspGetCompsVal(TBL_MBA_GAIN, caliChn, freq, bdtemp,patemp,bw, pGain,comptype);

    return BSP_OK;
}
#endif
UINT32 BspGetRxPreAtt(UINT32 chanNo,UINT32 freq,INT32 *pAtt)
{
    UINT32 retVal;
    UINT32 bspChn = 0;
    INT32  bdTemp = 300;
    INT32  paTemp = 300;
    INT32  targetGain = 0;
    INT32  defAttVal = 0;
    T_CompsData rssiGain = {0};
    INT32  rxGain = 0;
    INT32  attStep = 50;
    INT32  attVal;
    INT32  fixedAttGain = BspGetRxPowCaliFixAttGain();
    INT32  fixedTargetGain = 0;
    if (BSP_OK != BspGetBspChnByRfChn(chanNo,RX,&bspChn))
    {
        return BSP_ERROR;
    }

    BspGetBoardTemp(chanNo,&bdTemp);
    BspGetPaTemp(chanNo,&paTemp);

    retVal = _BspGetRxChanTargetGain_Base(bspChn,0,&targetGain);
    fixedTargetGain = targetGain + fixedAttGain;
    if (retVal != BSP_OK)
    {
        return BSP_ERROR;
    }

    retVal = _BspGetRxGain(bspChn,0,bdTemp,paTemp,freq,0,&rssiGain,COMPS_BY_FREQ_POINT_TYPE);
    if (retVal == BSP_OK)
    {
        rxGain = rssiGain.comps;
    }
    else
    {
        defAttVal = _BspGetUlAttDefPara(bspChn,0);
        rxGain = fixedTargetGain - defAttVal;
    }

    /* 从targetGain修正为fixedTargetGain */


    attVal = ((fixedTargetGain - rxGain + BspGetLna2ByPassGain(bspChn)) / attStep) * attStep;
    dbgInfoEx("BspGetRxPreAtt> bdTp:%d,paTp:%d,fixedTargetGain:%d,rssiG.comps:%d,(defAtt:%d),rxG:%d,att:%d\n",
               bdTemp,paTemp,fixedTargetGain,rssiGain.comps,defAttVal,rxGain,attVal);
    if (pAtt)
    {
        *pAtt = attVal;
    }
    else
    {
        dbgInfo("%s chan%d freq %d att %d\n", __FUNCTION__, chanNo, freq, attVal);
    }
    return BSP_OK;
}
#if 0
/*DPDIC4.0：上行载波增益以及VGA补偿*/
UINT32 BspSetVgaUlbankCompFacx(UINT32 chanNo, UINT32 carrMode, UINT32 carrNo, INT32 gain)
{
    BspHalAdaptSetRxPcGain(chanNo, carrMode, carrNo, gain);
    return BSP_OK;
}

UINT32 BspGetVgaUlbankCompFacx(UINT32 chanNo, UINT32 carrMode, UINT32 carrNo, INT32 gain)
{
    BspHalAdaptGetRxPcGain(chanNo, carrMode, carrNo, gain);
    return BSP_OK;
}
#endif
/*DPDIC4.0HAL层接口改变：分载波增益配置*/
UINT32 BspSetRxPreAtt(UINT32 chanNo, INT32 pAtt)
{
    UINT32 ulCnt = 0;
    UINT32 carrNo = 0;
    /*UINT32 tdmId  = 0;*/
    UINT32 carrMode = 0;
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    /*UINT32 blockId = 0;*/
    /*UINT32 bankId = 0;*/
    INT32  preAtt = 0;

    T_RruRfCfgInfo rruCfgInfo = {0};
    if (BSP_OK != BspGetRruCfgPara(chanNo,&rruCfgInfo))
    {
        dbgErr("[%s] BspGetRruCfgPara error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (BspGetDifInfoByBspChn(chanNo,RX,&chipId,&difChan)!= BSP_OK)
    {
        dbgErr("%s chanNo=%d\n",__FUNCTION__, chanNo);
        return BSP_ERROR;
    }
    for(ulCnt = 0;ulCnt < BSP_MAX_CARR_NUM;ulCnt++)
    {
        if(0 == rruCfgInfo.carr[ulCnt].carrRxFreq)
        {
            continue;
        }
        carrMode = rruCfgInfo.carr[ulCnt].carrRxRadio;
        carrNo = rruCfgInfo.carr[ulCnt].carrRxNo;

        preAtt = pAtt;  //0.1db

#if 0
        BspGetSampleRateByDifCarr(chipId,RX,difChan,carrMode,carrNo,CARR_BLOCK_IDX,&blockId);
        BspGetSampleRateByDifCarr(chipId,RX,difChan,carrMode,carrNo,CARR_BANK_IDX,&bankId);

        dbgInfo("%s chanNo=%d difChan=%d carrMode=%d carrNo=%d blockId=%d bankId=%d pAtt=%d preAtt=%d\n",
                __FUNCTION__,chanNo,difChan,carrMode,carrNo,blockId,bankId,pAtt,preAtt);

        setVgaUlbankCompFacx(chipId,blockId,bankId,preAtt);
#endif

        BspHalAdaptSetRxPcGain(chanNo, carrMode, carrNo, preAtt);
    }
    return BSP_OK;
}
/*pAtt  单位0.01dB*/
UINT32 BspSetRxDigitAtt(UINT32 chanNo, UINT32 carrNo, UINT32 carrMode, INT32 gain)
{
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    /*UINT32 blockId = 0;*/
    /*UINT32 bankId = 0;*/

    if (BspGetDifInfoByBspChn(chanNo,RX,&chipId,&difChan)!= BSP_OK)
    {
        dbgErr("%s chanNo=%d\n",__FUNCTION__, chanNo);
        return BSP_ERROR;
    }
    gain = gain/10;/*单位变为0.1dB*/

#if 0
    BspGetSampleRateByDifCarr(chipId,RX,difChan,carrMode,carrNo,CARR_BLOCK_IDX,&blockId);
    BspGetSampleRateByDifCarr(chipId,RX,difChan,carrMode,carrNo,CARR_BANK_IDX,&bankId);

    dbgInfo("%s chanNo=%d difChan=%d carrMode=%d carrNo=%d blockId=%d bankId=%d gain=%d\n",
            __FUNCTION__,chanNo,difChan,carrMode,carrNo,blockId,bankId,gain);

    setVgaUlbankCompFacx(chipId,blockId,bankId,gain);
#endif

    BspHalAdaptSetRxPcGain(chanNo, carrMode, carrNo, gain);
    return BSP_OK;
}

/* Started by AICoder, pid:icba00cde4nf7d414db60aea605920185f07a9cb */
UINT32 BspSetRxVgaGainFpga(UINT32 bspChan, UINT32 carrRadio, UINT32 carrNo, INT32 gain)
{
    UINT32 retVal = BSP_ERROR;
    T_FpgaInfoInit *pFpgaInfo = NULL;
    INPUT_BSPCHN_CHECK(bspChan);
    pFpgaInfo = BspGetFpgaInfo();
    INPUT_POINTER_CHECK(pFpgaInfo);
    INPUT_POINTER_CHECK(pFpgaInfo->pFuncSetRxVgaGainFpga);

    if (FPGA_CHAN == pFpgaInfo->rxFpgaChanFlag[bspChan])
    {
        retVal = pFpgaInfo->pFuncSetRxVgaGainFpga(bspChan, carrRadio, carrNo, gain);
    }

    return retVal;
}
/* Ended by AICoder, pid:icba00cde4nf7d414db60aea605920185f07a9cb */

/*pAtt  单位0.01dB*/
UINT32 BspSetRxVgaAtt(UINT32 chanNo, UINT32 ulCarrNo, UINT32 carrMode, INT32 gain)
{
    /*UINT32 tdmId  = 0;*/
    /*UINT32 tdmPos = 0;*/
    UINT32 chipId = 0;
    UINT32 difChan = 0;
    /*UINT32 retVal = 0;*/

    if (BspGetDifInfoByBspChn(chanNo,RX,&chipId,&difChan)!= BSP_OK)
    {
        dbgErr("%s chanNo=%d\n",__FUNCTION__, chanNo);
        return BSP_ERROR;
    }
    /*gain = gain/10; 单位变为0.1dB,在中频消化*/

#if 0
    retVal = BspGetTdmInfoByDifChan(chipId,difChan,carrMode,ulCarrNo,&tdmId,&tdmPos);
    if (retVal != BSP_OK)
    {
        dbgErr("%s bsp get tdmid and tdmpos error!!\n",__FUNCTION__);
        return BSP_ERROR;
    }

    dbgInfo("%s chanNo=%d difChan=%d carrMode=%d ulCarrNo=%d tdmId=%d tdmPos=%d gain=%d\n",
            __FUNCTION__,chanNo,difChan,carrMode,ulCarrNo,tdmId,tdmPos,gain);
    setVgaCompCarrFacxByTdmPos(chipId,tdmId,tdmPos,gain);
#endif
    if (BSP_RADIO_STANDARD_AIOT == carrMode)
    {
        BspSetRxVgaGainFpga(chanNo, carrMode, ulCarrNo, gain);
    }
    BspHalAdaptSetRxVgaGain(chanNo, carrMode, ulCarrNo, gain);
    return BSP_OK;
}

static UINT32 BspSetSlaveTxFwd(UINT32 bspChn, INT32 slaveGain)
{
    if(bspChn >= BSP_MAX_TX_CHAN)
    {
        dbgErr("bspChn is ERR!\n");
        return BSP_ERROR;
    }
    s_slaveTxFwd[bspChn] = slaveGain;

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取TX FWD
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTxFwd(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 caliChn;
    T_RfTblChanPara tmp = {0};
    T_RfTblChanPara tmpEx = {0};
    UINT32 caliIndex = 0;
    T_ChanRfTblBaseInfo baseInfo = {0};
    INT32 paTempEx = 600;
    INT32 boardTempEx = 550;
    UINT32 slaveChn = 0;
    T_CompsData slaveGain = {0};
    INT32 dsaAtt = 0;
    INT32 cableLoss = 0;
    UINT32 tmpChn = 0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetCaliChnByBspChn(bspChn,TX,&caliChn);
    BspGetPortSlaveChnByBspChn(bspChn,RX,&slaveChn);
    ulRetVal = BspGetSingleChanRfTblPara(bspChn, &tmp);
    if(BSP_OK != ulRetVal)   /**/
    {
         ulRetVal = _BspGetCompsVal(TBL_TX_FWD, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
    }
    else
    {
        ulRetVal = BspGetChanRfTblBaseInfo(bspChn, TBL_TX_FWD, &baseInfo);
        if(BSP_OK != ulRetVal)
        {
            dbgErr("chan %d BspGetChanRfTblBaseInfo failed\n ", bspChn);
            return BSP_ERROR;
        }
        caliIndex = baseInfo.rfTblIndex[0];   /*校准表的编号M-0 MS-1 子端portid+2*/
        caliChn = caliChn|(caliIndex<<16);    /*射频校准表编号占bit16-23*/
        caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
        dbgInfoEx("\n");
        dbgInfoEx("*******************chan %d TxFwd%d.txt get start********************\n", bspChn, caliIndex);
        ulRetVal = _BspGetCompsVal(TBL_TX_FWD, caliChn, freq, bdtemp, patemp, bw, pGain,comptype);
        if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道*/
        {
            INPUT_POINTER_CHECK(tmp.pGetSlaveBoardTemp);
            INPUT_POINTER_CHECK(tmp.pGetSlavePaTemp);
            tmp.pGetSlaveBoardTemp(bspChn,&boardTempEx);
            tmp.pGetSlavePaTemp(bspChn,&paTempEx);
            caliIndex = baseInfo.rfTblIndex[1];   /*1- 在子端侧校准表编号*/
            caliChn = slaveChn|(caliIndex<<16);   /*拉远的通道这里要传子端的通道号 但是TXGAIN 增益获取 要额外加glOpenLoopCaliPaGain 通道号会和母端重叠 glOpenLoopCaliPaGain 需要封装个按原始通道号的get接口*/
            caliChn = caliChn|((tmp.chanType&0xf)<<24); /*是否拉远*/
            dbgInfoEx("\n");
            dbgInfoEx("*******************chan %d slave TxFwd%d.txt get********************\n", bspChn, caliIndex);
            //dbgInfoEx("bspChn %d slaveChn %d boardTempEx %d paTempEx %d caliIndex %d caliChn 0x%x\n",bspChn, slaveChn,  boardTempEx, paTempEx, caliIndex, caliChn);
            ulRetVal = _BspGetCompsVal(TBL_TX_FWD, caliChn, freq, boardTempEx, paTempEx, bw, &slaveGain,comptype);  /*额外加上子端的增益*/
            if(NULL != tmp.pGetDsaAtt)
            {
                tmp.pGetDsaAtt(bspChn, PRX, &dsaAtt);
                if(slaveChn == 1)
                {
                    tmpChn = bspChn -1;
                }
                else
                {
                    tmpChn = bspChn + 1;
                }
                BspGetSingleChanRfTblPara(tmpChn, &tmpEx);
                BspGetSlaveCableGain(tmpChn, tmpEx.chanType, bdtemp, &cableLoss);
            }
            dbgInfoEx("total = %d + %d + %d + %d\n", pGain->comps, slaveGain.comps, dsaAtt, cableLoss);
            pGain->comps = pGain->comps + slaveGain.comps + dsaAtt + cableLoss;
            BspSetSlaveTxFwd(bspChn, slaveGain.comps);
        }

        dbgInfoEx("*******************chan %d all TxFwd.txt get end********************\n", bspChn);
        dbgInfoEx("\n");
    }
    return ulRetVal;
}

UINT32 BspGetSlaveTxFwd(UINT32 bspChn, INT32 *slaveGain)
{
    INPUT_POINTER_CHECK(slaveGain);

    if(bspChn >= BSP_MAX_TX_CHAN)
    {
        dbgErr("bspChn is ERR!\n");
        return BSP_ERROR;
    }
    *slaveGain = s_slaveTxFwd[bspChn];

    return BSP_OK;
}

/**************************************************************************
 * 函数名称:
 * 功能描述: 获取TX FWD
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTxBeamFwd(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    ulRetVal = _BspGetBeamCompsVal(TBL_TXBEAM_FWD, bspChn, freq, bdtemp, patemp, bw, pGain,comptype);

    return ulRetVal;
}


/**************************************************************************
 * 函数名称:
 * 功能描述: 获取TX REV
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetTxRev(UINT32 bspChn, INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 ulRetVal = BSP_OK;
    UINT32 caliChn;
    T_RfTblChanPara tmp = {0};

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    ulRetVal = BspGetSingleChanRfTblPara(bspChn, &tmp);
    if((BSP_OK == ulRetVal)&&( TBL_CHAN_S_TPYE == (tmp.chanType&0xf)))  /*一拖三机型且是子端通道*/
    {
        pGain->comps = 0;
        return ulRetVal;  /*不取TXFWD表 子端直接返回一个固定值 算得REV功率就行 子端无法检测rev 正常是-50多 这里直接0 dbm= dbfs -pGain->comps*/
    }
    BspGetCaliChnByBspChn(bspChn,TX,&caliChn);
    ulRetVal = _BspGetCompsVal(TBL_TX_REV, caliChn, freq, bdtemp, patemp,bw, pGain,comptype);

    return ulRetVal;
}

/* Started by AICoder, pid:wadc4sedd4s704f1407a08a6f04f030ce9090add */
VOID BspSetTargetGainOffset(INT32 offsetVal)
{
    s_TargetGainOffset = offsetVal;
}

INT32 BspGetTargetGainOffset(VOID)
{
    return s_TargetGainOffset;
}
/* Ended by AICoder, pid:wadc4sedd4s704f1407a08a6f04f030ce9090add */

/**************************************************************************
 * 函数名称: _BspGetTxDbmGain
 * 功能描述: 前向FWD和REV对应检出来的TSSI的模拟功率增益
 * 输入参数: ulChan 传入射频通道号
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetIfTssiDbmGain(UINT32 bspChn,INT32 *pGain,UINT32 comptype)
{
    /*UINT32 retVal = BSP_OK;*/
    /*INT32 attval = 0;*/
    INT32 targetGain = 0;
    INT32 offsetVal = 0;

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    /*T_CompsData txGain = {0};*/

    /* Started by AICoder, pid:g4f2ei1eebi14dd140020a266057fa08446694eb */
    offsetVal = BspGetTargetGainOffset();
    _BspGetTxChanTargetGain_Base(bspChn,&targetGain);
    *pGain = targetGain + offsetVal;
    dbgInfoEx("%s>>Gain= %d, targetGain= %d, offsetVal= %d;\n",
              __FUNCTION__, *pGain, targetGain, offsetVal);
    /* Ended by AICoder, pid:g4f2ei1eebi14dd140020a266057fa08446694eb */

    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetFwdGainFromRftable
 * 功能描述: 从离线文件获取FWD链路增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10258234    创建
 **************************************************************************/
UINT32 BspGetFwdGainFromRftable(INT32 bspChn, INT32 bdtemp,INT32 patemp,UINT32 freq,UINT32 bw,INT32 *pGain,UINT32 comptype)
{
    UINT32 retVal = BSP_OK;
    INT32 targetGain = 0;
    INT32 prxAttDef = 0;
    T_CompsData prxGain = {0};
    T_CompsData BeamGain = {0};

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    #ifndef FUNCLIB_ADS
    retVal = _BspGetTxBeamFwd(bspChn,bdtemp,patemp,freq,bw,&BeamGain,COMPS_BY_FREQ_BW_TYPE);//TxBeamFwd.txt 0.001db
    if(BSP_OK == retVal)
    {
        targetGain = BeamGain.comps/10;
    }

    retVal = _BspGetTxFwd(bspChn,bdtemp,patemp,freq,bw,&prxGain,comptype);//TxFwd.txt   0.01db
    if(BSP_OK == retVal)
    {
        targetGain += prxGain.comps;
    }
    else
    #endif
    {
        _BspGetFwdRevChanTargetGain(bspChn,&targetGain);
        prxAttDef = _BspGetDlPowDefPara(bspChn, E_ATT_DEF_PRX);
        targetGain -= prxAttDef;
        dbgInfoEx("****FWD read from file Error!,use default value %d, prxAttDef%d!\n",targetGain,prxAttDef);
    }
    dbgInfoEx("bspChn%d BeamGain.comps=%d    prxGain.comps=%d targetGain=%d\n",
        bspChn,BeamGain.comps,prxGain.comps,targetGain);
    *pGain = targetGain;
    return BSP_OK;
 }

/**************************************************************************
 * 函数名称: BspGetFwdDbmGainSingleBand
 * 功能描述: 获取单频段反馈功率的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 BspGetFwdDbmGainSingleBand(UINT32 bspChn,INT32 *pGain,UINT32 comptype)
{
    INT32 attval = 0;
    INT32 targetGain = 0;
    INT32 attdelta = 0;
    UINT32 freq = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 bw = 800000;
    INT32 combinGain = 0;
    UINT32 mode = 0;

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetRfChnByBspChn(bspChn, TX, &rfChn);

    freq = BspGetMultiCarrCenterFreq(TX,rfChn);
    mode = BspGetChCbSwCtrlMode(bspChn);
    if(SWITCH_ON == mode)   /*9124 强制模式下*/
    {
        BspGetRecordCaliCarrFreq(bspChn,1,&freq);  /* 使用当前校准频点获取增益*/
    }
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    dbgInfoEx("[%s] bspChn'%d rfChn'%d centerFreq'%d bdtemp'%d patemp'%d\n",__FUNCTION__,bspChn,rfChn,freq,bdtemp,patemp);
    BspGetFwdGainFromRftable(bspChn,bdtemp,patemp,freq,bw,&targetGain,comptype);
    combinGain = _BspGetDlPowDefPara(bspChn,E_COMBIN_GAIN);


    BspGetPrxAtt(bspChn,&attval);
    _BspGetPrxAttDelta(bspChn,freq,bw,abs(attval), &attdelta);

    *pGain = targetGain + attval - attdelta + combinGain;

    dbgInfoEx("bspChn%d targetGain=%d attVal=%d attdelta=%d combinGain=%d\n",bspChn,targetGain,attval,attdelta,combinGain);
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: BspGetFwdDbmGainMultBand
 * 功能描述: 获取多频段反馈功率的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 BspGetFwdDbmGainMultBand(UINT32 bspChn,INT32 *pGain,UINT32 comptype)
{
    INT32 attval = 0;
    INT32 targetGain = 0;
    INT32 rfTblCarrGain_Db  = 0;        /*载波增益0.01db单位*/
    INT32 rfTblCarrGain_Mw  = 0;        /*载波增益mw单位*/
    double rfTblChanGain = 0;
    double tmpVal = 0;
    INT32 attdelta = 0;
    UINT32 carriBw = 0;
    UINT32 centerFreq = 0;
    UINT32 carrFreq = 0;
    UINT32 carrPow = 0;
    UINT32 carrNo = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 bw = 800000;
    INT32 combinGain = 0;
    UINT32 carrloop = 0;
    UINT32 carrNum = 0;
    UINT32 ulChanPow = 0; 
    T_RruRfCfgInfo tRruCfgInfo = {0};

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);


    BspGetRfChnByBspChn(bspChn, TX, &rfChn);
    BspGetChanCarrSumPow(rfChn,&ulChanPow);
    centerFreq = BspGetMultiCarrCenterFreq(TX,rfChn);
    BspGetChnlCfgCarrPara(rfChn, &tRruCfgInfo);
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    carrNum = tRruCfgInfo.txCfgCarrSum;
    dbgInfoEx("[%s] bspChn'%d rfChn'%d carrNum'%d centerFreq'%d bdtemp'%d patemp'%d chanPow'%d\n",__FUNCTION__,bspChn,rfChn,carrNum,centerFreq,bdtemp,patemp,ulChanPow);
    for (carrloop = 0; carrloop < carrNum; carrloop++)
    {
        carrPow = 0;
        BspGetCfgCarrPow(rfChn, tRruCfgInfo.carr[carrloop].carrTxNo, tRruCfgInfo.carr[carrloop].carrTxRadio, &carrPow);
        carrNo = tRruCfgInfo.carr[carrloop].carrTxNo;
        carrFreq  = tRruCfgInfo.carr[carrloop].carrTxFreq;
        carriBw = tRruCfgInfo.carr[carrloop].carrTxBw;
        dbgInfoEx("carrNo'%d carrFreq'%d Bw'%d carrPow'%d\n",carrNo,carrFreq,carriBw,carrPow);
        RRU_CFG_PARA_CHK_CONTINUE(carrFreq);
        RRU_CFG_PARA_CHK_CONTINUE(carriBw);
        RRU_CFG_PARA_CHK_CONTINUE(carrPow);
        BspGetFwdGainFromRftable(bspChn,bdtemp,patemp,carrFreq,bw,&rfTblCarrGain_Db,comptype);
        tmpVal = pow(10.0,abs(rfTblCarrGain_Db)*1.0/1000.0);
        rfTblCarrGain_Mw = (INT32)tmpVal;
        rfTblChanGain += carrPow * 1.0 / (ulChanPow * 1.0 + 0.000001) * abs(rfTblCarrGain_Mw);
        dbgInfoEx("rfTblCarrGain_Db'%d rfTblCarrGain_Mw'%d rfTblChanGain'%f, carrPow[%u]\n",rfTblCarrGain_Db,rfTblCarrGain_Mw,rfTblChanGain, carrPow);
        rfTblCarrGain_Db = 0;
    }
    rfTblChanGain  = (0 == (INT32)rfTblChanGain) ? 0 : (double)(-1000.0 * log10(abs((INT32)rfTblChanGain)));
    targetGain = (INT32)rfTblChanGain;

    combinGain = _BspGetDlPowDefPara(bspChn,E_COMBIN_GAIN);

    BspGetPrxAtt(bspChn,&attval);
    _BspGetPrxAttDelta(bspChn,centerFreq,bw,abs(attval), &attdelta);

    *pGain = targetGain + attval - attdelta + combinGain;

    dbgInfoEx("bspChn%d targetGain=%d attVal=%d attdelta=%d combinGain=%d\n",bspChn,targetGain,attval,attdelta,combinGain);
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetFwdDbmGain
 * 功能描述: 获取反馈功率的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetFwdDbmGain(UINT32 bspChn,INT32 *pGain,UINT32 comptype)
{
    UINT32 bandNum = 0;
    UINT32 caliChn = 0;
    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    BspGetCaliChnByBspChn(bspChn,TX,&caliChn);
    bandNum = BspGetFreqBandCnts(caliChn,TX);
    dbgInfoEx("[%s] bspChn'%d band Num is %d\n",__FUNCTION__,bspChn,bandNum);
    if(bandNum > 1)
    {
        BspGetFwdDbmGainMultBand(bspChn,pGain,comptype);
    }
    else
    {
        BspGetFwdDbmGainSingleBand(bspChn,pGain,comptype);
    }
    return BSP_OK;
}
#if 0
/**************************************************************************
 * 函数名称: _BspGetPcFwdDbmGain
 * 功能描述: 获取反馈分载波功率的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetPcFwdDbmGain(UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 *pGain, UINT32 comptype)
{
    UINT32 retVal = BSP_OK;
    INT32 attval = 0;
    INT32 targetGain = 0;
    INT32 attdelta = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 freq  = 0;
    UINT32 bw = 800000;
     INT32 combinGain = 0;
    INT32 prxAttDef = 0;

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    T_CompsData prxGain = {0};
    T_CompsData BeamGain = {0};

    BspGetRfChnByBspChn(bspChn, TX, &rfChn);

    freq = BspGetChanCarrFreq(TX,rfChn,carrNo,radioMode);
    BspGetBoardCompTemp(rfChn,&bdtemp);
    BspGetPaCompTemp(rfChn,&patemp);

    retVal = _BspGetTxBeamFwd(bspChn,bdtemp,patemp,freq,bw,&BeamGain,COMPS_BY_FREQ_BW_TYPE);//TxBeamFwd.txt 0.001db
    if(BSP_OK == retVal)
    {
        targetGain = BeamGain.comps/10;
    }

    retVal = _BspGetTxFwd(bspChn,bdtemp,patemp,freq,bw,&prxGain,comptype);//TxFwd.txt   0.01db
    if(BSP_OK == retVal)
    {
        targetGain += prxGain.comps;
    }
    else
    {
        _BspGetFwdRevChanTargetGain(bspChn,&targetGain);
        prxAttDef = _BspGetDlPowDefPara(bspChn, E_ATT_DEF_PRX);
        targetGain -= prxAttDef;
        dbgInfoEx("****FWD read from file Error!,use default value %d, prxAttDef%d!\n",targetGain,prxAttDef);
    }

    combinGain   =  _BspGetDlPowDefPara(bspChn,E_COMBIN_GAIN);

    dbgInfoEx("bspChn%d BeamGain.comps=%d    prxGain.comps=%d   combinGain = %d\n",
        bspChn,BeamGain.comps,prxGain.comps,combinGain);

    BspGetPrxAtt(bspChn,&attval);
    _BspGetPrxAttDelta(bspChn,freq,bw,abs(attval), &attdelta);

    *pGain = targetGain + attval - attdelta + combinGain;

    dbgInfoEx("bspChn%d targetGain=%d attVal=%d attdelta=%d\n",
        bspChn,targetGain,attval,attdelta);
    return BSP_OK;
}
#endif
/**************************************************************************
 * 函数名称: BspGetRevGainFromRftable
 * 功能描述: 从离线文件获取REV链路增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10258234    创建
 **************************************************************************/
UINT32 BspGetRevGainFromRftable(INT32 bspChn, INT32 bdtemp,INT32 patemp,UINT32 freq,UINT32 bw,INT32 *pGain,UINT32 comptype)
{
    UINT32 retVal = BSP_OK;
    INT32 targetGain = 0;
    INT32 prxAttDef = 0;
    T_CompsData revGain = {0};

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    #ifndef FUNCLIB_ADS
    retVal = _BspGetTxRev(bspChn,bdtemp,patemp,freq,bw,&revGain,comptype);
    if (retVal != BSP_OK)/* REV增益获取失败则用fwd增益 */
    {
        retVal = _BspGetTxFwd(bspChn,bdtemp,patemp,freq,bw,&revGain,comptype);
    }
    if(BSP_OK == retVal)
    {
        targetGain = revGain.comps;
    }
    else
    #endif
    {
        _BspGetFwdRevChanTargetGain(bspChn,&targetGain);
        prxAttDef = _BspGetDlPowDefPara(bspChn, E_ATT_DEF_PRX);
        targetGain -= prxAttDef;
        dbgInfoEx("****REV read from file Error!,use default value %d, prxAttDef%d!\n",targetGain,prxAttDef);
    }
    *pGain = targetGain;
    return BSP_OK;
 }

/**************************************************************************
 * 函数名称: BspGetRevDbmGainSingleBand
 * 功能描述: 单频段获取REV的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10258234    创建
 **************************************************************************/
UINT32 BspGetRevDbmGainSingleBand(UINT32 bspChn, INT32 *pGain,UINT32 comptype)
{
    INT32 attval = 0;
    INT32 targetGain = 0;
    INT32 attdelta = 0;
    UINT32 freq = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 bw = 0;
    UINT32 freqStart = 0;
    UINT32 freqEnd = 0;
    UINT32 bandNum = 1;
    UINT32 retVal = BSP_ERROR;

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetRfChnByBspChn(bspChn, TX, &rfChn);
    freq = BspGetMultiCarrCenterFreq(TX,rfChn);
    if((BSP_ERROR == freq) && BspIsSuportDefaultChanCenterFreq())
    {
        retVal = BspGetFreqInfoByBandNum(bspChn, TX, bandNum, &freqStart, &freqEnd);
        CHECK_RETVAL_PRN(BspGetFreqInfoByBandNum, retVal);
        freq = (freqStart + freqEnd)/2;
        BspLog(LOG_LEVEL_0,"%s, flag[%d], freq[%d]\n",__FUNCTION__, BspIsSuportDefaultChanCenterFreq(), freq);
    }
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    dbgInfoEx("[%s] bspChn'%d rfChn'%d centerFreq'%d bdtemp'%d patemp'%d\n",__FUNCTION__,bspChn,rfChn,freq,bdtemp,patemp);
    BspGetRevGainFromRftable(bspChn,bdtemp,patemp,freq,bw,&targetGain,comptype);
    #ifndef FUNCLIB_ADS
    BspGetPrxAtt(bspChn,&attval);
    _BspGetPrxAttDelta(bspChn,freq,bw,abs(attval), &attdelta);
    #endif
    *pGain = targetGain + attval - attdelta;
    dbgInfoEx("bspChn%d targetGain=%d attVal=%d attdelta=%d\n",
        bspChn,targetGain,attval,attdelta);
    return BSP_OK;

 }

/**************************************************************************
 * 函数名称: BspGetRevDbmGainMultBand
 * 功能描述: 多频段获取REV的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10258234    创建
 **************************************************************************/
UINT32 BspGetRevDbmGainMultBand(UINT32 bspChn, INT32 *pGain,UINT32 comptype)
{
    INT32 attval = 0;
    INT32 targetGain = 0;
    INT32 rfTblCarrGain_Db  = 0;        /*载波增益0.01db单位*/
    INT32 rfTblCarrGain_Mw  = 0;        /*载波增益mw单位*/
    double rfTblChanGain = 0;
    double tmpVal = 0;
    INT32 attdelta = 0;
    UINT32 carriBw = 0;
    UINT32 centerFreq = 0;
    UINT32 carrFreq = 0;
    UINT32 carrPow = 0;
    UINT32 carrNo = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 bw = 0;
    UINT32 carrloop = 0;
    UINT32 carrNum = 0;
    UINT32 ulChanPow = 0; 
    T_RruRfCfgInfo tRruCfgInfo = {0};

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetRfChnByBspChn(bspChn, TX, &rfChn);
    BspGetChanCarrSumPow(rfChn,&ulChanPow);
    centerFreq = BspGetMultiCarrCenterFreq(TX,rfChn);
    BspGetChnlCfgCarrPara(rfChn, &tRruCfgInfo);
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    carrNum = tRruCfgInfo.txCfgCarrSum;
    dbgInfoEx("[%s] bspChn'%d rfChn'%d carrNum'%d centerFreq'%d bdtemp'%d patemp'%d chanPow'%d\n",__FUNCTION__,bspChn,rfChn,carrNum,centerFreq,bdtemp,patemp,ulChanPow);
    for (carrloop = 0; carrloop < carrNum; carrloop++)
    {
        carrPow = 0;
        BspGetCfgCarrPow(rfChn, tRruCfgInfo.carr[carrloop].carrTxNo, tRruCfgInfo.carr[carrloop].carrTxRadio, &carrPow);
        carrNo = tRruCfgInfo.carr[carrloop].carrTxNo;
        carrFreq  = tRruCfgInfo.carr[carrloop].carrTxFreq;
        carriBw = tRruCfgInfo.carr[carrloop].carrTxBw;
        dbgInfoEx("carrNo'%d carrFreq'%d Bw'%d carrPow'%d\n",carrNo,carrFreq,carriBw,carrPow);
        RRU_CFG_PARA_CHK_CONTINUE(carrFreq);
        RRU_CFG_PARA_CHK_CONTINUE(carriBw);
        RRU_CFG_PARA_CHK_CONTINUE(carrPow);
        BspGetRevGainFromRftable(bspChn,bdtemp,patemp,carrFreq,bw,&rfTblCarrGain_Db,comptype);
        tmpVal = pow(10.0,abs(rfTblCarrGain_Db)*1.0/1000.0);
        rfTblCarrGain_Mw = (INT32)tmpVal;
        rfTblChanGain += carrPow * 1.0 / (ulChanPow * 1.0 + 0.000001) * abs(rfTblCarrGain_Mw);
        dbgInfoEx("rfTblCarrGain_Db'%d rfTblCarrGain_Mw'%d rfTblChanGain'%f, carrPow[%d]\n",rfTblCarrGain_Db,rfTblCarrGain_Mw,rfTblChanGain, carrPow);
        rfTblCarrGain_Db = 0;
    }
    rfTblChanGain  = (0 == (INT32)rfTblChanGain) ? 0 : (double)(-1000.0 * log10(abs((INT32)rfTblChanGain)));
    targetGain = (INT32)rfTblChanGain;
    BspGetPrxAtt(bspChn,&attval);
    _BspGetPrxAttDelta(bspChn,centerFreq,bw,abs(attval), &attdelta);

    *pGain = targetGain + attval - attdelta;
    dbgInfoEx("[%s] bspChn%d targetGain=%d attVal=%d attdelta=%d\n",__FUNCTION__,
        bspChn,targetGain,attval,attdelta);
    return BSP_OK;

 }

/**************************************************************************
 * 函数名称: _BspGetRevDbmGain
 * 功能描述: 获取REV的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10258234    创建
 **************************************************************************/
UINT32 _BspGetRevDbmGain(UINT32 bspChn, INT32 *pGain,UINT32 comptype)
{
    UINT32 bandNum = 0;
    UINT32 caliChn = 0;
    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);
    BspGetCaliChnByBspChn(bspChn,TX,&caliChn);
    bandNum = BspGetFreqBandCnts(caliChn,TX);
    dbgInfoEx("[%s] bspChn'%d band Num is %d\n",__FUNCTION__,bspChn,bandNum);
    if(bandNum > 1)
    {
        BspGetRevDbmGainMultBand(bspChn,pGain,comptype);
    }
    else
    {
        BspGetRevDbmGainSingleBand(bspChn,pGain,comptype);
    }
    return BSP_OK;

 }
 #if 0
/**************************************************************************
 * 函数名称: BspGetVswrFwdDbmGain
 * 功能描述: 获取反馈分载波功率的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 BspGetVswrFwdDbmGain(UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 *pGain, UINT32 comptype)
{
    UINT32 retVal = BSP_OK;
    /*INT32 attval = 0;*/
    INT32 targetGain = 0;
    /*INT32 attdelta = 0;*/
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 freq  = 0;
    UINT32 bw = 800000;
     /*INT32 combinGain = 0;*/
    /*INT32 prxAttDef = 0;*/
    T_CompsData prxGain = {0};
    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetRfChnByBspChn(bspChn, TX, &rfChn);

    freq = BspGetChanCarrFreq(TX,rfChn,carrNo,radioMode);
    BspGetBoardCompTemp(rfChn,&bdtemp);
    BspGetPaCompTemp(rfChn,&patemp);

    retVal = _BspGetTxAcCal(bspChn,bdtemp,patemp,freq,bw,&prxGain,comptype);//TxFwd.txt   0.01db
    if(BSP_OK == retVal)
    {
        targetGain += prxGain.comps;
    }
    else
    {
        _BspGetTxAcCalTargetGain_Base(bspChn,0,&targetGain);
        dbgInfoEx("****TxAcCal read from file Error!,use default value %d!\n",targetGain);
    }
    *pGain = targetGain;
    dbgInfoEx("bspChn%d prxGain.comps=%d targetGain=%d\n",bspChn,prxGain.comps,targetGain);
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: _BspGetVswrRevDbmGain
 * 功能描述: 获取反馈分载波功率的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 BspGetVswrRevDbmGain(UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 *pGain, UINT32 comptype)
{
    UINT32 retVal = BSP_OK;
    /*INT32 attval = 0;*/
    INT32 targetGain = 0;
    /*INT32 attdelta = 0;*/
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 freq  = 0;
    UINT32 bw = 800000;
     /*INT32 combinGain = 0;*/
    /*INT32 prxAttDef = 0;*/
    T_CompsData prxGain = {0};
    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_TX_CHAN(bspChn);

    BspGetRfChnByBspChn(bspChn, TX, &rfChn);

    freq = BspGetChanCarrFreq(TX,rfChn,carrNo,radioMode);
    BspGetBoardCompTemp(rfChn,&bdtemp);
    BspGetPaCompTemp(rfChn,&patemp);

    retVal = _BspGetRxIsoCal(bspChn,bdtemp,patemp,freq,bw,&prxGain,comptype);//TxFwd.txt   0.01db
    if(BSP_OK == retVal)
    {
        targetGain += prxGain.comps;
    }
    else
    {
        _BspGetRxIsoCalTargetGain_Base(bspChn,0,&targetGain);
        dbgInfoEx("****RxIsoCal read from file Error!,use default value %d!\n",targetGain);
    }
    *pGain = targetGain;
    dbgInfoEx("bspChn%d prxGain.comps=%d targetGain=%d\n",bspChn,prxGain.comps,targetGain);
    return BSP_OK;
}
#endif
/**************************************************************************
 * 函数名称: _BspGetRssiDbmGain
 * 功能描述: 获取RSSI的模拟增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 _BspGetRssiDbmGain(UINT32 bspChn,UINT32 mode,INT32 *pGain,UINT32 comptype)
{
    UINT32 retVal = BSP_OK;
    /*INT32 attval = 0;*/
    INT32 targetGain = 0;
    UINT32 freq = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 bw = 0;

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);
    T_CompsData rxGain = {0};

    BspGetRfChnByBspChn(bspChn, RX, &rfChn);
    freq = BspGetMultiCarrCenterFreq(RX,rfChn);
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);

    retVal = _BspGetRxGain(bspChn,mode,bdtemp,patemp,freq,bw,&rxGain,comptype);
    if(BSP_OK == retVal)
    {
        targetGain = rxGain.comps;
    }
    else
    {
        _BspGetRxChanTargetGain_Base(bspChn,0,&targetGain);
        dbgInfoEx("****RSSI read from file Error!,use default value!\n");
    }

    /*FPAG的dbfs已经补偿了ATT,VGA的增益了，这里不考虑*/
    *pGain = targetGain;
    return BSP_OK;

}
static UINT32 s_uTmaGain[MAX_RX_CHANNEL] = {0};

/**************************************************************************
 * 函数名称: BspSetTmaGain
 * 功能描述: 设置TMA增益
 * 输入参数: uAntNo--天线号
           uTmaGain -- 增益(0.01db)
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2018年04月23日 01105163    创建
 **************************************************************************/
UINT32 BspSetTmaGain(UINT32 uAntNo, UINT32 uTmaGain)
{
    if(uAntNo >= MAX_RX_CHANNEL)
    {
        return BSP_ERROR;
    }
    s_uTmaGain[uAntNo] = uTmaGain;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetTmaGain
 * 功能描述: 获取TMA增益
 * 输入参数: uAntNo--天线号
 * 输出参数: pTmaGain -- 增益(0.01db)
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2018年04月23日 01105163    创建
 **************************************************************************/
UINT32 BspGetTmaGain(UINT32 uAntNo, UINT32* pTmaGain)
{
    if((uAntNo >= MAX_RX_CHANNEL)||(NULL == pTmaGain))
    {
        return BSP_ERROR;
    }

    *pTmaGain = s_uTmaGain[uAntNo];
    return BSP_OK;
}

UINT32 BspGetPaTempByIdx(UINT32 uPaId, UINT32 uPaChn, INT32 *piTemp)
{
    UINT32 uBspChn = 0;
    UINT32 uRet    = BSP_OK;


    uRet = BspGetBspChnByPaInfo(uPaId,uPaChn, &uBspChn);
    if(BSP_OK == uRet)
    {
       uRet = BspGetPaTemp(uBspChn,piTemp);
    }

    return uRet;
}

/**************************************************************************
 * 函数名称: BspGetTmaGainByBspChn
 * 功能描述: 获取TMA增益
 * 输入参数: bspChn -- bsp通道号
 * 输出参数: pTmaGain -- 增益(0.01db)
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2018年04月23日 01105163    创建
 **************************************************************************/
UINT32 BspGetTmaGainByBspChn(UINT32 bspRxChn, UINT32* pTmaGain)
{

    UINT32 antId = 0;
    UINT32 antChn = 0;
    INPUT_POINTER_CHECK(pTmaGain);
    BspGetAntInfoByBspChn(bspRxChn, RX, &antId, &antChn);
    BspGetTmaGain(antId,pTmaGain);
    return BSP_OK;
}
/**************************************************************************
 * 函数名称: BspGetRssiDbmCompGain
 * 功能描述: 获取RSSI的频点校准值增益
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 BspGetRssiDbmCompGain(UINT32 bspChn,UINT32 mode,UINT32 freq,UINT32 bw,INT32 *pGain,UINT32 comptype)
{
    UINT32 retVal = BSP_OK;
    /*INT32 attval = 0;*/
    INT32 targetGain = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 rfChn = 0;
    UINT32 paId  = 0;
    UINT32 paChn = 0;
    UINT32 antId = 0;
    UINT32 antChn= 0;
    UINT32 tmaGain = 0;
    INT32 defAttVal = 0;

    INPUT_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChn);
    T_CompsData rxGain = {0};

    BspGetRfChnByBspChn(bspChn, RX, &rfChn);
    BspGetBoardTemp(rfChn,&bdtemp);/* 单板温度目前不区分通道号 */

    BspGetPaInfoByBspChn(bspChn, RX, &paId, &paChn);
    BspGetPaTempByIdx(paId,paChn,&patemp);
     #ifndef FUNCLIB_ADS
    retVal = _BspGetRxGain(bspChn,mode,bdtemp,patemp,freq,bw,&rxGain,comptype);
    if(BSP_OK == retVal)
    {
        targetGain = rxGain.comps;
    }
    else
    #endif
    {
        _BspGetRxChanTargetGain_Base(bspChn,0,&targetGain);
        defAttVal = _BspGetUlAttDefPara(bspChn,0);
        targetGain = targetGain - defAttVal;
        dbgInfoEx("****RSSI read from file Error!,use default value!\n");
    }
    BspGetAntInfoByBspChn(bspChn, RX, &antId, &antChn);
    BspGetTmaGain(antId,&tmaGain);

    /*FPAG的dbfs已经补偿了ATT,VGA的增益了，这里不考虑*/
    *pGain = targetGain + tmaGain;
    return BSP_OK;

}

#define ID_RSSI_DEF_COMP      ((INT32)(-4800))
UINT32 BspGetIdRssiDbmCompGain(UINT32 bspChan, UINT32 freqKHz, UINT32 bw, INT32 *pGain)
{
    UINT32 retVal = BSP_OK;
    UINT32 caliChan = 0;
    INT32 bdTempTbl = 0;
    INT32 paTempTbl = 0;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pGain);
    _COMPSFLE_CHECK_INPUT_RX_CHAN(bspChan);

    BspGetCaliChnByBspChn(bspChan, RX, &caliChan);
    BspSwitchRssiTblData(RSSI_TYPE_ID);
    retVal = _BspGetRfFreqVal(TBL_RX_RSSI, caliChan, freqKHz, freqKHz, bw, pGain, &bdTempTbl, &paTempTbl, COMPS_BY_FREQ_POINT_TYPE);
    BspSwitchRssiTblData(RSSI_TYPE_RX);
    if (BSP_OK != retVal)
    {
        *pGain = ID_RSSI_DEF_COMP;
    }

    return retVal;
}

#if 0
UINT32 _BspGetPaVolt(UINT32 ulIndex, UINT32 ulBand,UINT32 ulPar,
      UINT32 ulFreq, UINT32 ulPow, UINT32 *pVolt, UINT32 *pGain,UINT32 *pDbm)
{
    UINT32    ulPaIdx        = 0;
    UINT32    ulPaChan       = 0;
    UINT32    ulIdx          = 0;
    UINT32    ulNum          = 0;
    /*UINT32    ulMinIdx       = 0;*/
    INT32     lPar           = (INT32)ulPar;
    INT32     lPow           = (INT32)ulPow;
    UINT32    ulPARDif       = 0;
    UINT32    ulPowDif       = 0;
    UINT32    ulFreqDif      = 0;
    UINT32    ulPARDifMin    = 0xffffffff;
    UINT32    ulPowDifMin    = 0xffffffff;
    UINT32    ulFreqDifMin   = 0xffffffff;
    UINT32    ulTblIdx       = 0;
    UINT32    ulRetVal       = BSP_OK;
    TPaDrainAdjPathRecord *pRecord      = NULL;
    TPaDrainAdjCaliData *ptDrainAdjData = NULL;
    TPaDrainAdjPowGainRecord *pTmp      = NULL;

    if (ulIndex >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    if(ulBand >= TBL_MAX_CHAN_FREQBAND)
    {
        return BSP_ERROR;
    }
    #if 0  /*20170401 10010593 重新考虑*/
    ulPaIdx  = IntPub_UnitFunc_ChanMap_GetPaIndex(ulIndex);
    ulPaChan = IntPub_UnitFunc_ChanMap_GetPaChan(ulIndex);
    #endif
    ptDrainAdjData = (TPaDrainAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PADRAINADJ,ulPaIdx);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptDrainAdjData);
    _PADRAINADJ_LOADED_CHECK(ptDrainAdjData, ulPaChan,ulBand);

    ulNum   = ptDrainAdjData->atCaliPath[ulPaChan].aulRecordNum[ulBand];
    pRecord = ptDrainAdjData->atCaliPath[ulPaChan].patRecord[ulBand];
    ulTblIdx = ulNum;
    for(ulIdx = 0; ulIdx < ulNum; ulIdx++ )
    {
        if(pRecord->lPar<lPar)
        {
            pRecord++;
            continue;
        }
        ulPARDif   = (UINT32)(pRecord->lPar-lPar);
        if(ulPARDif<=ulPARDifMin)
        {
            ulPARDifMin = ulPARDif;
            ulFreqDif  = (pRecord->ulRfFreq>ulFreq)?(pRecord->ulRfFreq-ulFreq):(ulFreq-pRecord->ulRfFreq);
            if(ulFreqDif<=ulFreqDifMin)
            {
                ulFreqDifMin = ulFreqDif;
                ulTblIdx     = ulIdx;
            }
        }
        pRecord++;
    }
    if(ulTblIdx>=ulNum)
    {
        ulRetVal = BSP_ERROR;
    }
    else
    {
        pRecord = ptDrainAdjData->atCaliPath[ulPaChan].patRecord[ulBand];
        pTmp = pRecord[ulTblIdx].atPowGain;
        ulTblIdx = PA_DRAIN_ADJ_POW_LBL_MAX;
        for(ulIdx = 0; ulIdx < PA_DRAIN_ADJ_POW_LBL_MAX; ulIdx++)
        {
            if(lPow>pTmp[ulIdx].lPow)
            {
                continue;
            }
            ulPowDif = (UINT32)(pTmp[ulIdx].lPow-lPow);
            if(ulPowDif<ulPowDifMin)
            {
                ulPowDifMin = ulPowDif;
                ulTblIdx     = ulIdx;
            }
        }
        if(ulTblIdx<PA_DRAIN_ADJ_POW_LBL_MAX)
        {
            if(NULL != pVolt)
            {
                *pVolt = pTmp[ulTblIdx].lPaVolt;
            }
            else
            {
                dbgInfo("%s PaVolt = %d\n",__FUNCTION__,pTmp[ulTblIdx].lPaVolt);
            }
            if(NULL != pGain)
            {
                *pGain= pTmp[ulTblIdx].lPaGain;
            }
            else
            {
                dbgInfo("%s PaGain = %d\n",__FUNCTION__,pTmp[ulTblIdx].lPaGain);
            }
            if(NULL != pDbm)
            {
                *pDbm= pTmp[ulTblIdx].lPow;
            }
            else
            {
                dbgInfo("%s lPow = %d\n",__FUNCTION__,pTmp[ulTblIdx].lPow);
            }
        }
        else
        {
            ulRetVal = BSP_ERROR;
        }
    }
    return BSP_OK;
}


UINT32 _BspGetPaBar(UINT32 ulIndex, UCHAR *pbar, UINT32 ulLen)
{
    UINT32    ulPaIdx  = 0;
    UINT32    ulPaChan = 0;
    UINT32    ulBarLen = 0;
    TPaBasicInfoCaliData *ptPaBasicData = NULL;

    if (ulIndex >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pbar);
    #if 0 /*20170401 10010593 重新考虑*/
    ulPaIdx  = IntPub_UnitFunc_ChanMap_GetPaIndex(ulIndex);
    ulPaChan = IntPub_UnitFunc_ChanMap_GetPaChan(ulIndex);
    #endif
    ptPaBasicData = (TPaBasicInfoCaliData *)_BspGetCalibData(TBL_KIND_OF_PABASICINFO,ulPaIdx);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptPaBasicData);
    _PABASICINFO_LOADED_CHECK(ptPaBasicData, ulPaChan);

    ulBarLen = strlen(ptPaBasicData->tBasicInfoHeader.aucINT32Barcode)+1;
    if(ulLen < ulBarLen)
    {
        return BSP_ERROR;
    }
    memcpy(pbar,ptPaBasicData->tBasicInfoHeader.aucINT32Barcode,ulBarLen);

    return BSP_OK;
}


UINT32 _BspGetRfTxGain(UINT32 ulChan, UINT32 ulFreq, UINT32 ulBw, INT32 *plGain)
{
    UINT32 ulRetVal = BSP_OK;
    INT32  lBdTempTbl, lPaTempTbl;
    INT32  lRfGain = 0;

    ulRetVal = _BspGetRfFreqVal(TBL_TX_GAIN, ulChan,
               ulFreq, ulFreq, ulBw, &lRfGain, &lBdTempTbl, &lPaTempTbl);

    if (plGain)
    {
        *plGain = lRfGain;
    }
    return ulRetVal;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 _BspGetPauRelativeAmp(UINT32 ulChan, INT32 lFreq, INT32 *plAmp)
{
    TPauRelativeAmpCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;
    UINT32 ulBand = 0;

    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(plAmp);

    ptCaliData = (TPauRelativeAmpCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEAMP,0);
    PAURELATIVEAMP_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    if (lFreq <= (INT32)ulStartFreq)
    {
        lComps = ptRecord[0].lCompVal;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        lComps = ptRecord[ulRecordNum-1].lCompVal;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lCompVal,\
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lCompVal);
    }

    *plAmp = lComps;
    return BSP_OK;
}

/**************************************************************************
 * 函数名称: (*)
 * 功能描述:
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2016年09月30日 10090699    创建
 **************************************************************************/
UINT32 _BspGetPauRelativePhase(UINT32 ulChan, UINT32 ulBand, INT32 lFreq, INT32 *plPhase)
{
    TPauRelativePhaseCaliData *ptCaliData = NULL;
    T_FreqRecord *ptRecord = NULL;
    UINT32 ulStartFreq, ulEndFreq, ulStepFreq;
    UINT32 ulRecordNum, ulIndex;
    INT32  lComps;

    TBL_CHAN_VALID_CHECK(ulChan);
    TBL_BAND_VALID_CHECK(ulBand);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(plPhase);

    ptCaliData = (TPauRelativePhaseCaliData*)_BspGetCalibData(TBL_KIND_OF_PAURELATIVEPHASE,0);
    PAURELATIVEPHASE_LOADED_CHECK(ptCaliData,ulChan);

    ptRecord    = ptCaliData->atPath[ulChan].patRecord[ulBand];
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptRecord);
    ulStartFreq = ptCaliData->atPath[ulChan].tHeader.aulStartFreq[ulBand];
    ulEndFreq   = ptCaliData->atPath[ulChan].tHeader.aulStopFreq[ulBand];
    ulStepFreq  = ptCaliData->atPath[ulChan].tHeader.aulRfStep[ulBand];
    ulRecordNum = ptCaliData->atPath[ulChan].aulRecordNum[ulBand];

    if (lFreq <= (INT32)ulStartFreq)
    {
        lComps = ptRecord[0].lCompVal;
    }
    else if (lFreq >= (INT32)ulEndFreq)
    {
        lComps = ptRecord[ulRecordNum-1].lCompVal;
    }
    else
    {
        ulIndex = (lFreq - (INT32)ulStartFreq) / ulStepFreq;
        lComps = _LINEAR_INSERT(lFreq,ptRecord[ulIndex].lFreq,ptRecord[ulIndex].lCompVal,\
                                ptRecord[ulIndex+1].lFreq,ptRecord[ulIndex+1].lCompVal);
    }

    *plPhase = lComps;
    return BSP_OK;
}
#endif

UINT32 TestGetTempGain(UINT16 usType, UINT32 ulChan,UINT32 ulFreq)
{
    UINT32 ulRetVal = BSP_OK;
    INT32 lBdTemp=0, lPaTemp=0, lBdTempTbl=0, lPaTempTbl=0;
    INT32 lBdTempGain=0, lPaTempGain=0, lBdTempGainTbl=0, lPaTempGainTbl=0;
    INT32 lTempGain=0;

    //TBL_CHAN_VALID_CHECK(ulChan);

    //ulRetVal = IntPub_UnitFunc_Compsfile_GetRfFreqVal(usType, ulChan,
    //           ulFreq, ulFreq, 0, &lRfGain, &lBdTempTbl, &lPaTempTbl);
    if (ulRetVal != BSP_OK)
    {
        dbgErr("%s:usType:%#x,chan:%d,freq:%d,get Comp temp failed\n",
            __FUNCTION__, usType, ulChan, ulFreq);
        return BSP_ERROR;
    }

    //ulRetVal = BspGetBoardTemp(0, &lBdTemp);
    if (ulRetVal != BSP_OK)
    {
        dbgErr("%s:usType:%#x,chan:%d,freq:%d,get bd temp failed,use default temp 25\n",
            __FUNCTION__, usType, ulChan, ulFreq);
        lBdTemp = 250;
    }
    /*todo:暂时屏蔽，待pa模块合入后放开*/
    /* ulRetVal = BspGetPaTemp(ulChan, &lPaTemp); */
    if (ulRetVal != BSP_OK)
    {
        dbgErr("%s:usType:%#x,chan:%d,freq:%d,get pa temp failed,,use default temp 25\n",
            __FUNCTION__, usType, ulChan, ulFreq);
        //return BSP_ERROR;
        lPaTemp = 250;
    }

    ulRetVal  = _BspGetTempComps(usType, E_TEMP_TYPE_TRX,
                ulChan, ulFreq, lBdTemp, &lBdTempGain);
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_TRX,
                ulChan, ulFreq, lBdTempTbl, &lBdTempGainTbl);
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_PA,
                ulChan, ulFreq, lPaTemp, &lPaTempGain);
    ulRetVal |= _BspGetTempComps(usType, E_TEMP_TYPE_PA,
                ulChan, ulFreq, lPaTempTbl, &lPaTempGainTbl);
    if (ulRetVal != BSP_OK)
    {
        dbgErr("%s:usType:%#x,chan:%d,freq:%d,get trx&pa temp failed\n",
            __FUNCTION__, usType, ulChan, ulFreq);
        return BSP_ERROR;
    }

    lBdTempGain = lBdTempGain - lBdTempGainTbl;
    lPaTempGain = lPaTempGain - lPaTempGainTbl;
    lTempGain   = lBdTempGain + lPaTempGain;

    dbgInfo("Trx temp=%d Pa temp%d  total temp gain=%d [lBdTempGain=%d , lBdTempGainTbl=%d,lPaTempGain =%d, lPaTempGainTbl=%d]\n",lBdTemp,lPaTemp,lTempGain,lBdTempGain , lBdTempGainTbl,lPaTempGain , lPaTempGainTbl);
    return BSP_OK;
}

/*get dfl band avge gain */

UINT32 BspGetTxOpenLoopGainByDflFreq(UINT32 chanNo, UINT32 bandNum, INT32 *pTxGain)
{
    UINT32 retVal   = BSP_OK;
    UINT32 bandLoop   = 0;
    UINT32 freqStart   = 0;
    UINT32 freqEnd   = 0;
    UINT32 centerFreq   = 0;
    INT32 txAdjustGain   = 0;
    INT32 gainSum   = 0;

    if(bandNum == 0)
    {
        return BSP_ERROR;
    }

    for(bandLoop = 0; bandLoop < bandNum; bandLoop ++)
    {
        retVal |= BspGetFreqInfoByBandNum(chanNo,TX,bandLoop,&freqStart,&freqEnd);
        centerFreq = (freqStart + freqEnd)/2;
        retVal |= BspGetTxOpenLoopGain(chanNo,centerFreq,&txAdjustGain);
        dbgInfoEx("[%s] chand %u band %u adjustGain to %d\n ",__FUNCTION__,chanNo,bandLoop,txAdjustGain);
        gainSum += txAdjustGain;
    }

    *pTxGain = gainSum/(INT32)bandNum;

    return retVal;
}

UINT32 BspGetCarrTxGain(UINT32 chanNo, UINT32 freq, INT32 *pTxGain)
{
    UINT32 rfChn = chanNo;
    UINT32 bspChn = 0;
    INT32  bdtemp = 300;
    INT32  patemp = 300;
    UINT32 centerFreq = 0;
    T_CompsData fix = {0};
    UINT32 retVal = BSP_OK;

    INPUT_POINTER_CHECK(pTxGain);
    if(chanNo >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }

    retVal = BspGetBspChnByRfChn(rfChn, TX, &bspChn);
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] Bsp Get BspChn By RfChn Error!\n ", __FUNCTION__);
        return BSP_ERROR;
    }
    centerFreq = freq;
    retVal = BspGetBoardTemp(rfChn, &bdtemp);
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] Bsp Get Board Temp Error!\n ", __FUNCTION__);
        return BSP_ERROR;
    }
    retVal = BspGetPaTemp(rfChn, &patemp);
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] Bsp Get Pa Temp Error!\n ", __FUNCTION__);
        return BSP_ERROR;
    }
    retVal = _BspGetTxGain(bspChn, bdtemp, patemp, centerFreq, 0, &fix, COMPS_BY_FREQ_POINT_TYPE);
    if(BSP_OK != retVal)
    {
        dbgErr("[%s] Bsp Get Tx Gain Error!\n ", __FUNCTION__);
        return BSP_ERROR;
    }

    *pTxGain = fix.comps;
    return retVal;
}

UINT32 BspGetTxOpenLoopGain(UINT32 chanNo,UINT32 freq,INT32 *pTxGain)
{
    UINT32 retVal       = BSP_OK;
    UINT32 centerFreq   = 0;
    INT32  attStep      = 50;//0.5db
    INT32  targetGain   = 0;
    INT32  txAttDef     = 0;
    INT32  txAdjustGain   = 0;
    INT32  backDbm = 0;
    UINT32 rfChn = chanNo;
    UINT32 bspChn = 0;
    INT32  bdtemp = 300;
    INT32  patemp = 300;
    UINT32 bw   = 800000;
    INT32  combinGain = 0;
    T_CompsData fix = {0};
    T_CompsData Beamfix = {0};
    UINT32 retVal0       = BSP_OK;

    INPUT_POINTER_CHECK(pTxGain);
    if (chanNo >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }

    retVal = BspGetBspChnByRfChn(rfChn,TX,&bspChn);
    CHECK_RETVAL_PRN(BspGetBspChnByRfChn, retVal);
    centerFreq = freq;
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);

    if(IS_NCR != BspIsNcr())
    {
        _BspGetTxChanTargetGain_Base(chanNo,&targetGain);
    }
    else
    {
        _BspGetTxChanTargetGain_Base_ncr(chanNo,&targetGain);//离线文件，整机额定
    }

    retVal0 = _BspGetTxBeamGain(bspChn,bdtemp,patemp,centerFreq,bw,&Beamfix,COMPS_BY_FREQ_BW_TYPE); //0.01db
    retVal = _BspGetTxGain(bspChn,bdtemp,patemp,centerFreq,0,&fix,COMPS_BY_FREQ_POINT_TYPE);
    if((retVal == BSP_OK) && (retVal0 == BSP_OK))
    {
         fix.comps += Beamfix.comps;
    }
    if((retVal != BSP_OK) || (fix.comps == 0))
    {
        backDbm  = _BspGetDlPowDefPara(bspChn,E_BACK_DBM_TX);
        txAttDef = _BspGetDlPowDefPara(bspChn,E_ATT_DEF_TX);
        fix.comps = targetGain - txAttDef;
        dbgInfo("[%s]****TxGain read from file Error!,use default value![backDbm 0x%x,txAttDef 0x%x]\n", __FUNCTION__,backDbm,txAttDef);
    }
    combinGain   =  _BspGetDlPowDefPara(bspChn,E_COMBIN_GAIN);

    dbgInfoEx("[%s]bspChn%d fix.comps=%d    Beamfix.comps=%d   combinGain =%d targetGain =%d \n",
               __FUNCTION__,bspChn,fix.comps,Beamfix.comps,combinGain,targetGain);
    txAdjustGain   =  ((targetGain - fix.comps - backDbm - 25 + combinGain)/attStep)*attStep;
    dbgInfoEx("[%s] TxLink %d LoopCali ,adjustGain to %d\n ",__FUNCTION__,chanNo,txAdjustGain);

    BspLog(LOG_LEVEL_0,"[%s] bspChn %d fix.comps %d Beamfix.comps %d combinGain %d targetGain %d txAdjustGain %d\n",
               __FUNCTION__,bspChn,fix.comps,Beamfix.comps,combinGain,targetGain, txAdjustGain);

    *pTxGain = txAdjustGain;
    return retVal;
}

/*9124 下行预开环增益计算*/
UINT32 BspGetTxPreOpenLoopGain(UINT32 rfChn,UINT32 freq,INT32 *pTxGain)
{
    UINT32 retVal       = BSP_OK;
    UINT32 centerFreq   = 0;
    INT32  targetGain   = 0;
    INT32  txAttDef     = 0;
    INT32  backDbm = 0;
    UINT32 bspChn = 0;
    INT32  bdtemp = 300;
    INT32  patemp = 300;
    UINT32 bw   = 800000;
    INT32  combinGain = 0;
    T_CompsData fix = {0};
    T_CompsData Beamfix = {0};
    UINT32 retVal0 = BSP_OK;

    INPUT_POINTER_CHECK(pTxGain);
    if (rfChn >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }

    retVal = BspGetBspChnByRfChn(rfChn,TX,&bspChn);
    CHECK_RETVAL_PRN(BspGetBspChnByRfChn, retVal);
    centerFreq = freq;
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);

    retVal0 = _BspGetTxBeamGain(bspChn,bdtemp,patemp,centerFreq,bw,&Beamfix,COMPS_BY_FREQ_BW_TYPE); //0.01db
    retVal = _BspGetTxGain(bspChn,bdtemp,patemp,centerFreq,0,&fix,COMPS_BY_FREQ_POINT_TYPE);
    if((retVal == BSP_OK) && (retVal0 == BSP_OK))
    {
         fix.comps += Beamfix.comps;  /*额外加上线缆的插损*/
    }
    if((retVal != BSP_OK) || (fix.comps == 0))
    {
        backDbm  = _BspGetDlPowDefPara(bspChn,E_BACK_DBM_TX);
        txAttDef = _BspGetDlPowDefPara(bspChn,E_ATT_DEF_TX);
        fix.comps = targetGain - txAttDef;
        dbgInfo("[%s]****TxGain read from file Error!,use default value![backDbm 0x%x,txAttDef 0x%x]\n", __FUNCTION__,backDbm,txAttDef);
    }
    combinGain   =  _BspGetDlPowDefPara(bspChn,E_COMBIN_GAIN);

    dbgInfoEx("[%s]bspChn%d fix.comps=%d    Beamfix.comps=%d   combinGain =%d \n",
               __FUNCTION__,bspChn,fix.comps,Beamfix.comps,combinGain);
    *pTxGain = fix.comps;

    return retVal;
}

UINT32 BspGetTxOpenLoopGainMultBand(UINT32 chanNo,INT32 *pTxGain)
{
    UINT32 retVal       = BSP_OK;
    INT32  attStep      = 50;//0.5db
    INT32  targetGain   = 0;
    INT32  txAttDef     = 0;
    INT32  txAdjustGain   = 0;
    INT32  backDbm = 0;
    UINT32 rfChn = chanNo;
    UINT32 bspChn = 0;
    INT32  bdtemp = 300;
    INT32  patemp = 300;
    UINT32 carriBw = 0;
    UINT32 carrFreq = 0;
    INT32  combinGain = 0;
    UINT32 carrNum = 0;
    UINT32 carrloop = 0;
    UINT32 carrNo = 0;
    INT64 rfTblCarrGain_Mw  = 0;
    INT64 rfTblChanGain = 0;
    INT64 rfTblGain = 0;
    INT32 rfGaindBm = 0;
    double tmpVal = 0;
    UINT32 carrValid = 0;
    T_CompsData fix = {0};
    T_CompsData Beamfix = {0};
    UINT32 retVal0       = BSP_OK;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    

    INPUT_POINTER_CHECK(pTxGain);
    if (chanNo >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    retVal = BspGetBspChnByRfChn(rfChn,TX,&bspChn);
    CHECK_RETVAL_PRN(BspGetBspChnByRfChn, retVal);
    _BspGetTxChanTargetGain_Base(chanNo,&targetGain);
    backDbm  = _BspGetDlPowDefPara(bspChn,E_BACK_DBM_TX);
    txAttDef = _BspGetDlPowDefPara(bspChn,E_ATT_DEF_TX);
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    dbgInfoEx("[%s] rfchan'%d bdtemp'%d patemp'%d\n",__FUNCTION__,rfChn,bdtemp,patemp);
    BspGetChnlCfgCarrPara(chanNo, &tRruCfgInfo);
    carrNum = tRruCfgInfo.txCfgCarrSum;
    for (carrloop = 0; carrloop < carrNum; carrloop++)
    {
        carrNo = tRruCfgInfo.carr[carrloop].carrTxNo;
        carrFreq  = tRruCfgInfo.carr[carrloop].carrTxFreq;
        carriBw = tRruCfgInfo.carr[carrloop].carrTxBw;
        dbgInfoEx("carrNo'%d carrFreq'%d\n",carrNo,carrFreq);
        RRU_CFG_PARA_CHK_CONTINUE(carrFreq);
        retVal0 = _BspGetTxBeamGain(bspChn,bdtemp,patemp,carrFreq,carriBw,&Beamfix,COMPS_BY_FREQ_BW_TYPE); //0.01db
        retVal = _BspGetTxGain(bspChn,bdtemp,patemp,carrFreq,0,&fix,COMPS_BY_FREQ_POINT_TYPE);
        if((retVal == BSP_OK) && (retVal0 == BSP_OK))
        {
            fix.comps += Beamfix.comps;
        }
        if((retVal != BSP_OK) || (fix.comps == 0))
        {
            fix.comps = targetGain - txAttDef;
            dbgInfo("[%s]****TxGain read from file Error!,use default value![backDbm 0x%x,txAttDef 0x%x]\n", __FUNCTION__,backDbm,txAttDef);
        }
        dbgInfoEx("fix.comps'%d Beamfix.comps'%d\n",fix.comps,Beamfix.comps);
        tmpVal = pow(10.0,abs(fix.comps)*1.0/1000.0);
        rfTblCarrGain_Mw = (INT64)tmpVal;
        rfTblChanGain += rfTblCarrGain_Mw;
        dbgInfoEx("rfTblCarrGain_Db'%d rfTblCarrGain_Mw'%lld rfTblChanGain'%lld\n",fix.comps,rfTblCarrGain_Mw,rfTblChanGain);
        fix.comps = 0;
        carrValid++;
    }
    if(carrValid != 0)
    {
        rfTblGain  = rfTblChanGain/carrValid;
    }
    else
    {
        dbgErr("vaild carr Num is 0\n");
        return BSP_ERROR;
    }
    rfGaindBm  = (0 == rfTblGain) ? 0 : (INT32)(1000.0 * log10(rfTblGain));

    combinGain   =  _BspGetDlPowDefPara(bspChn,E_COMBIN_GAIN);

    dbgInfoEx("[%s]bspChn%d rfTblGain=%d combinGain =%d targetGain =%d \n",
               __FUNCTION__,bspChn,rfGaindBm,combinGain,targetGain);
    txAdjustGain   =  ((targetGain - rfGaindBm - backDbm - 25 + combinGain)/attStep)*attStep;
    dbgInfoEx("[%s] TxLink %d LoopCali ,adjustGain to %d\n ",__FUNCTION__,chanNo,txAdjustGain);

    *pTxGain = txAdjustGain;
    return BSP_OK;
}
UINT32 BspGetTxOpenLoopPwrDiff(UINT32 chanNo, INT32* attVal)
{
    UINT32 retVal       = BSP_OK;
    UINT32 centerFreq   = 0;
    /*INT32  txGainMin    = 0;*/
    /*INT32  txGainMax    = 0;*/
    INT32  txAdjustGain   = 0;
    UINT32 rfChn = chanNo;
    INT32  txAtt = 0,digGain = 0;
    UINT32 caliChn = 0;
    UINT32 bandNum = 0;
    T_TxOpenLoopPara *pTxPara = BspGetTxOpenLoopPara();

    //减少冗余打印BspSetRxSwitch
    //powCtrlLog(LOG_INFO,"%s{%d} enter\n",__FUNCTION__,chanNo);

    INPUT_POINTER_CHECK(attVal);
    INPUT_POINTER_CHECK(pTxPara);
    INPUT_POINTER_CHECK(pTxPara->pGetGain);
    retVal = BspGetCaliChnByRfChn(rfChn,TX,&caliChn);
    if(retVal != BSP_OK)
    {
        caliChn = rfChn;
    }
    bandNum = BspGetFreqBandCnts(caliChn,TX);
    dbgInfoEx("[%s] rfChn'%d band Num is %d\n",__FUNCTION__,rfChn,bandNum);
    if(bandNum > 1)
    {
        retVal = BspGetTxOpenLoopGainMultBand(rfChn,&txAdjustGain);
    }
    else
    {
        centerFreq = BspGetMultiCarrCenterFreq(TX,rfChn);
        retVal = BspGetTxOpenLoopGain(rfChn,centerFreq,&txAdjustGain);
    }
    
    if (retVal != BSP_OK)
    {
        dbgErr("%s get tx%d openloop gain failed\n",__FUNCTION__,rfChn);
        return BSP_ERROR;
    }

    retVal = pTxPara->pGetGain(chanNo,txAdjustGain,&txAtt,&digGain);
    if (retVal != BSP_OK)
    {
        dbgErr("%s get gain error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    *attVal = txAtt;
    dbgInfoEx("Chan'%d,centerFreq'%d,adjustGain'%d,digGain'%d,retTxAtt'%d\n",
               chanNo,centerFreq,txAdjustGain,digGain,txAtt);
    //减少冗余打印
    //BspLog(LOG_LEVEL_0,"%s Chan'%d,centerFreq'%d,adjustGain'%d,digGain'%d,retTxAtt'%d\n", __FUNCTION__,
    //                   chanNo, centerFreq, txAdjustGain, digGain, txAtt);
    return retVal;
}

UINT32 BspTxOpenLoopPowCail(UINT32 chanNo)
{
    UINT32 retVal       = BSP_OK;
    UINT32 centerFreq   = 0;
    /*INT32  txGainMin    = 0;*/
    /*INT32  txGainMax    = 0;*/
    INT32  txAdjustGain   = 0;
    UINT32 rfChn = chanNo;
    INT32  txAtt = 0;
    INT32 digGain = 0;
    UINT32 caliChn = 0;
    UINT32 bandNum = 0;
    T_RruRfCfgInfo tRruCfgInfo = {0};
    T_TxOpenLoopPara *pTxPara = BspGetTxOpenLoopPara();

    BspLog(LOG_LEVEL_0,"%s{%d} enter\n",__FUNCTION__,chanNo);
    INPUT_POINTER_CHECK(pTxPara);
    INPUT_POINTER_CHECK(pTxPara->pGetGain);

    BspGetChnlCfgCarrPara(chanNo, &tRruCfgInfo);
    retVal = BspGetCaliChnByRfChn(rfChn,TX,&caliChn);
    if(retVal != BSP_OK)
    {
        caliChn = rfChn;
    }
    bandNum = BspGetFreqBandCnts(caliChn,TX);
    dbgInfoEx("[%s] rfChn'%d band Num is %d\n",__FUNCTION__,rfChn,bandNum);

    if(tRruCfgInfo.txCfgCarrSum == 0)
    {
        retVal = BspGetTxOpenLoopGainByDflFreq(rfChn,bandNum,&txAdjustGain);
        if(BSP_OK != retVal)
        {
            return BSP_ERROR;
        }
    }
    else
    {
        if(bandNum > 1)
        {
            retVal = BspGetTxOpenLoopGainMultBand(rfChn,&txAdjustGain);
        }
        else
        {
            centerFreq = BspGetMultiCarrCenterFreq(TX,rfChn);
            retVal = BspGetTxOpenLoopGain(rfChn,centerFreq,&txAdjustGain);
        }
        if ((retVal != BSP_OK)||(centerFreq == BSP_ERROR))
        {
            dbgErr("[%s] get tx%d openloop gain failed\n",__FUNCTION__,rfChn);
            return BSP_ERROR;
        }
    }

    retVal = pTxPara->pGetGain(chanNo,txAdjustGain,&txAtt,&digGain);
    if (retVal != BSP_OK)
    {
        dbgErr("%s get gain error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    txAtt = txAtt - BspGetTxCaliProcAttVal(chanNo);
    if (pTxPara->pSetTxAtt)
    {
        if(BSP_OK != pTxPara->pSetTxAtt(chanNo,txAtt))
        {
            return BSP_ERROR;
        }
    }

    /*TDD 开环功率回退不需要在KdGain补回，后续其他机型需要开环配置kd增益需要单独处理*/
#if 0
    if (pTxPara->pSetDigGain)
    {
        pTxPara->pSetDigGain(chanNo,digGain);
    }
#endif

    if (pTxPara->pExtraProc)/* 现在是空的 */
    {
        pTxPara->pExtraProc(chanNo,txAdjustGain);
    }

    dbgInfoEx("[%s]chan'%d,freq'%d,adjustGain'%d,txAtt'%d,digGain'%d\n",
               __FUNCTION__,chanNo,centerFreq,txAdjustGain,txAtt,digGain);

    BspLog(LOG_LEVEL_0,"[%s]retVal %d Exit chan'%d,freq'%d,adjustGain'%d,txAtt'%d,digGain'%d\n",
               __FUNCTION__, retVal, chanNo, centerFreq, txAdjustGain, txAtt, digGain);

    return retVal;
}

/*下行预开环  高层传的是第一个载波的频点*/
UINT32 BspTxPreOpenLoopPowCail(UINT32 chanNo)
{
    UINT32 retVal       = BSP_OK;
    INT32  txAdjustGain   = 0;
    UINT32 rfChn = chanNo;
    INT32  txAtt = 0;
    INT32 digGain = 0;
    UINT32 caliChn = 0;
    T_TxOpenLoopPara *pTxPara = BspGetTxOpenLoopPara();
    UINT32 freq = 0;
    INT32 paGain = 0;    /*静态调压增益*/

    BspClrSlavePortLossInfo(chanNo);   /*高层支持插损失败时再次发起测量，需要将上一次记录的数据清除掉 否则影响本次的增益计算*/
    if (BspGetRfChCenterFreq(chanNo, TX, &freq) != BSP_OK)
    {
        return BSP_ERROR;
    }
    BspLog(LOG_LEVEL_0,"%s{%d %d} enter\n",__FUNCTION__, chanNo, freq);
    retVal |= BspGetCaliChnByRfChn(rfChn,TX,&caliChn);
    if(retVal != BSP_OK)
    {
        caliChn = rfChn;
    }
    retVal = BspGetTxOpenLoopGain(rfChn,freq,&txAdjustGain);
    if(retVal != BSP_OK)
    {
        dbgErr("[%s] get tx%d openloop gain failed\n",__FUNCTION__,rfChn);
        return BSP_ERROR;
    }
    retVal = pTxPara->pGetGain(chanNo,txAdjustGain,&txAtt,&digGain);   /*下行开环回退了3db*/
    if (retVal != BSP_OK)
    {
        dbgErr("%s get gain error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if (pTxPara->pSetTxAtt)
    {
        if(BSP_OK != pTxPara->pSetTxAtt(chanNo,txAtt))
        {
            return BSP_ERROR;
        }
    }
    if (pTxPara->pExtraProc)/* 现在是空的 */
    {
        pTxPara->pExtraProc(chanNo,txAdjustGain);
    }
    BspGetPaGain(chanNo, &paGain);  /*静态调压增益*/
    dbgInfo("[%s]chan'%d,freq'%d,adjustGain'%d,txAtt'%d,digGain'%d paGain %d\n", __FUNCTION__,chanNo,freq,txAdjustGain,txAtt,digGain, paGain);
    /*预开环的时候dsa必然是1900 2200这种默认值*/
    BspLog(LOG_LEVEL_0,"%s{%d} att %d paGain %d return %d\n", __FUNCTION__, chanNo, txAtt, paGain, retVal);

    return retVal;
}

/* Started by AICoder, pid:b9bc31cdd0vaaeb1492609c6a07c7e21a648e22f */
/**
 * @brief 执行发射校准过程。
 *
 * 该函数执行发射校准过程，包括设置衰减值和进行功率校准。
 *
 * @param bspChan 通道编号
 * @param ulBand 频段
 * @param lAttValue 衰减值
 * @return UINT32 返回操作结果，0表示成功，非0表示错误
 */
UINT32 BspTxCaliProc(UINT32 bspChan, UINT32 ulBand, INT32 lAttValue)
{
    UINT32 retVal = BSP_OK;

    // 更改RF配置方向
    ChangeRfCfgDir(bspChan);
    retVal |= BspSetTxCaliProcAttVal(bspChan, lAttValue);
    retVal |= BspTxOpenLoopPowCail(bspChan);
    // 再次更改RF配置方向
    ChangeRfCfgDir(bspChan);

    return retVal;
}
/* Ended by AICoder, pid:b9bc31cdd0vaaeb1492609c6a07c7e21a648e22f */

UINT32 BspGetFbOpenLoopCailGain(UINT32 chanNo,INT32 *pCaliGain)
{
    UINT32 retVal = BSP_OK;
    UINT32 centerFreq   = 0;
    /*INT32  prxGainMin    = 0;*/
    /*INT32  prxGainMax    = 0;*/
    INT32  attStep      = 50;//0.5db
    INT32  targetGain   = 0;
    INT32  prxAttDef     = 0;
    /*INT32  backDbm = 0;*/
    UINT32 rfChn = chanNo;
    UINT32 bspChn = 0;
    INT32  bdtemp = 300;
    INT32  patemp = 300;
    UINT32 freqStart   = 0;
    UINT32 freqEnd   = 0;
    UINT32 bandNum = 1;
    T_CompsData fix = {0};

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pCaliGain);
    if (chanNo >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }

    retVal = BspGetBspChnByRfChn(rfChn,TX,&bspChn);
    CHECK_RETVAL_PRN(BspGetBspChnByRfChn, retVal);
    centerFreq = BspGetMultiCarrCenterFreq(TX,rfChn);
    if((BSP_ERROR == centerFreq) && BspIsSuportDefaultChanCenterFreq())
    {
        retVal = BspGetFreqInfoByBandNum(chanNo, TX, bandNum, &freqStart, &freqEnd);
        CHECK_RETVAL_PRN(BspGetFreqInfoByBandNum, retVal);
        centerFreq = (freqStart + freqEnd)/2;
        BspLog(LOG_LEVEL_0,"%s, flag[%d], freq[%d]\n",__FUNCTION__, BspIsSuportDefaultChanCenterFreq(), centerFreq);
    }

    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);

    _BspGetFwdRevChanTargetGain(chanNo,&targetGain);
    retVal = _BspGetTxFwd(bspChn,bdtemp,patemp,centerFreq,0,&fix,COMPS_BY_FREQ_POINT_TYPE);
    if((retVal != BSP_OK) || (fix.comps == 0))
    {
        prxAttDef = _BspGetDlPowDefPara(bspChn,E_ATT_DEF_PRX);
        fix.comps = targetGain - prxAttDef;
        dbgInfo("****PrxGain read from file Error!,use default value!\n");
    }

    *pCaliGain   =  ((targetGain - fix.comps - 25)/attStep)*attStep;
    dbgInfoEx("[%s] targetGain %d fix.comps %d PrxLink %d LoopCali ,adjustGain to %d\n ",
               __FUNCTION__,targetGain,fix.comps,chanNo,*pCaliGain);

    return BSP_OK;
}

UINT32 BspGetFbOpenLoopCailGainMultBand(UINT32 chanNo,INT32 *pCaliGain)
{
    UINT32 retVal = BSP_OK;
    UINT32 centerFreq   = 0;
    /*INT32  prxGainMin    = 0;*/
    /*INT32  prxGainMax    = 0;*/
    INT32  attStep      = 50;//0.5db
    INT32  targetGain   = 0;
    INT32  prxAttDef     = 0;
    /*INT32  backDbm = 0;*/
    UINT32 rfChn = chanNo;
    UINT32 bspChn = 0;
    INT32  bdtemp = 300;
    INT32  patemp = 300;
    UINT32 carrNum = 0;
    UINT32 carrloop = 0;
    INT32 rfTblCarrGain_Mw  = 0; 
    INT64 rfTblChanGain = 0;
    INT32 rfTblGain = 0;
    UINT32 carrNo = 0;
    UINT32 carrFreq = 0;
    double tmpVal = 0;
    UINT32 carrValid = 0;
    T_CompsData fix = {0};
    T_RruRfCfgInfo tRruCfgInfo = {0};

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pCaliGain);
    if (chanNo >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }

    retVal = BspGetBspChnByRfChn(rfChn,TX,&bspChn);
    CHECK_RETVAL_PRN(BspGetBspChnByRfChn, retVal);
    centerFreq = BspGetMultiCarrCenterFreq(TX,rfChn);
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    dbgInfoEx("[%s] rfchan'%d bdtemp'%d patemp'%d\n",__FUNCTION__,rfChn,bdtemp,patemp);
    _BspGetFwdRevChanTargetGain(chanNo,&targetGain);
    BspGetChnlCfgCarrPara(rfChn, &tRruCfgInfo);
    carrNum = tRruCfgInfo.txCfgCarrSum;
    for (carrloop = 0; carrloop < carrNum; carrloop++)
    {
        carrNo = tRruCfgInfo.carr[carrloop].carrTxNo;
        carrFreq  = tRruCfgInfo.carr[carrloop].carrTxFreq;
        RRU_CFG_PARA_CHK_CONTINUE(carrFreq);
        retVal = _BspGetTxFwd(bspChn,bdtemp,patemp,centerFreq,0,&fix,COMPS_BY_FREQ_POINT_TYPE);
        if((retVal != BSP_OK) || (fix.comps == 0))
        {
            prxAttDef = _BspGetDlPowDefPara(bspChn,E_ATT_DEF_PRX);
            fix.comps = targetGain - prxAttDef;
            dbgInfo("****PrxGain read from file Error!,use default value!\n");
        }
        dbgInfoEx("carrNo'%d carrFreq'%d fix.comps'%d\n",carrNo,carrFreq,fix.comps);
        tmpVal = (INT32)pow(10.0,abs(fix.comps)*1.0/1000.0);
        rfTblCarrGain_Mw = (INT32)tmpVal;
        rfTblChanGain += rfTblCarrGain_Mw;
        dbgInfoEx("rfTblCarrGain_Db'%d rfTblCarrGain_Mw'%d rfTblChanGain'%lld\n",fix.comps,rfTblCarrGain_Mw,rfTblChanGain);
        fix.comps = 0;
        carrValid++;
    }
    if(carrValid != 0)
   {
       rfTblGain  = (INT32)rfTblChanGain/carrValid;

       if (0 != rfTblGain)
       {
            rfTblGain = (INT32)(-1000.0 * log10(rfTblGain));
       }
   }
   else
   {
       prxAttDef = _BspGetDlPowDefPara(bspChn,E_ATT_DEF_PRX);
       rfTblGain = targetGain - prxAttDef;
       dbgInfo("****PrxGain read from file Error!,use default value!\n");
   }
    *pCaliGain   =  ((targetGain - rfTblGain - 25)/attStep)*attStep;
    dbgInfoEx("[%s] targetGain %d rfTblGain %d PrxLink %d LoopCali ,adjustGain to %d\n ",
               __FUNCTION__,targetGain,rfTblGain,chanNo,*pCaliGain);

    return BSP_OK;
}

UINT32 ulFbOpenLoopType = 0;  //0--平均值 1--最大值

UINT32 BspSetFbOpenLoopType(UINT32 type)
{
    ulFbOpenLoopType = type;
    return BSP_OK;
}

UINT32 BspGetFbOpenLoopType(VOID)
{
    return ulFbOpenLoopType;
}

/* Started by AICoder, pid:c0e7ea5a55e7361140170ae790f67e69238294d1 */
UINT32 BspGetFbOpenLoopInfo(UINT32 linkNum, UINT32* pLinkId, UINT32* pRfInfo, INT32* cailGain, INT32* pTotalCailGain, INT32* pPrxattMin, UINT32* pRetVal, INT32* pCnt)
{
    UINT32 loop = 0;
    UINT32 caliChn = 0;
    UINT32 bandNum = 0;
    INT32 tmp = 0;

    INPUT_POINTER_CHECK(pLinkId);
    INPUT_POINTER_CHECK(pRfInfo);
    INPUT_POINTER_CHECK(cailGain);
    INPUT_POINTER_CHECK(pTotalCailGain);
    INPUT_POINTER_CHECK(pPrxattMin);
    INPUT_POINTER_CHECK(pRetVal);
    INPUT_POINTER_CHECK(pCnt);

   for(loop = 0; loop < linkNum; loop ++)
    {
        if(BSP_OK != BspGetLinkInfoByLinkId(pLinkId[loop],LINK_INFO_RFCHN,&pRfInfo[loop]))
        {
            pRfInfo[loop] = 0xFFFF;
            continue;
        }
        *pRetVal = BspGetCaliChnByRfChn(pRfInfo[loop],TX,&caliChn);
        if(*pRetVal != BSP_OK)
        {
            caliChn = pRfInfo[loop];
        }
        bandNum = BspGetFreqBandCnts(caliChn,TX);
        dbgInfoEx("[%s] rfChn'%d band Num is %d\n",__FUNCTION__,pRfInfo[loop],bandNum);
        if(bandNum > 1)
        {
            *pRetVal = BspGetFbOpenLoopCailGainMultBand(pRfInfo[loop],&cailGain[pRfInfo[loop]]);
        }
        else
        {
            *pRetVal = BspGetFbOpenLoopCailGain(pRfInfo[loop],&cailGain[pRfInfo[loop]]);
        }
        if (*pRetVal != BSP_OK)
        {
            pRfInfo[loop] = 0xFFFF;
            continue;
        }
        if( pRfInfo[loop] >= MAX_TX_CHAN )
        {
            pRfInfo[loop] = 0xFFFF;
            continue;
        }
        if(0 == BspGetFbOpenLoopType())  /*反馈att求平均值*/
        {
            if(IS_NCR == BspIsNcr())
            {
                if(0 == tmp)
                {
                    *pTotalCailGain = cailGain[pRfInfo[loop]];
                }
                else
                {
                    if(cailGain[pRfInfo[loop]] < *pTotalCailGain)
                    {
                        *pTotalCailGain = cailGain[pRfInfo[loop]];
                    }
                }
                tmp++;
            }
            else
            {
                *pTotalCailGain += cailGain[pRfInfo[loop]];
                (*pCnt)++;
            }
        }
        else   /*反馈att求最小值（负值）*/
        {
            dbgInfoEx("%s loop=%d cailGain[%d]=%d,prxattMin=%d\n",__FUNCTION__,loop,pRfInfo[loop],cailGain[pRfInfo[loop]],*pPrxattMin);
            if(cailGain[pRfInfo[loop]] < *pPrxattMin)
            {
                *pPrxattMin = cailGain[pRfInfo[loop]];
            }
        }
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:c0e7ea5a55e7361140170ae790f67e69238294d1 */

UINT32 BspFbOpenLoopPowCail(UINT32 chanNo)
{
    /*UINT32 bspChn = 0;*/
    UINT32 linkNum = 0;
    UINT32 fbChnIndex = 0;
    UINT32 *pLinkId = NULL;
    UINT32 *pRfInfo = NULL;
    INT32 cailGain[MAX_TX_CHAN] = {0};
    INT32 totalCailGain = 0;
    INT32 averCailGain = 0;
    INT32 prxGainMax = 0;
    INT32 prxGainMin = 0;
    UINT32 retVal = 0;
    INT32 cnt = 0;
    INT32 prxattMin = 0xFFFF;

    //powCtrlLog(LOG_INFO,"%s{%d} enter\n",__FUNCTION__,chanNo);

    linkNum = BspGetChanLinkNum();
    if ( linkNum > ((ULONG)(-1)/sizeof(UINT32)) )
    {
         dbgErr("[%s] get link num error\n",__FUNCTION__);
         return BSP_ERROR;
    }
    pLinkId = (UINT32 *)malloc(sizeof(UINT32)*linkNum);
    if (NULL == pLinkId)
    {
        dbgErr("[%s] malloc 1 error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    pRfInfo = (UINT32 *)malloc(sizeof(UINT32)*linkNum);
    if (NULL == pRfInfo)
    {
        free(pLinkId);
        dbgErr("[%s] malloc 2 error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset(pRfInfo,0xFF,sizeof(UINT32)*linkNum);
    memset(cailGain,0x0,sizeof(cailGain));
    /*获取该发射通道对应的所有的反馈通道的编号，并获取该通道的增益值*/
    BspGetFbChnInfoByRfChn(chanNo,&fbChnIndex);

    if(BSP_OK != BspGetLinkInfoByLinkType(LINK_TYPE_TX,LINK_INFO_FBCH,fbChnIndex,pLinkId,&linkNum))
    {
        free(pLinkId);
        free(pRfInfo);
        dbgErr("[%s] BspGetLinkInfoByLinkType error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(0 == linkNum)
    {
        free(pLinkId);
        free(pRfInfo);
        dbgErr("[%s] linkNum error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]chanNo'%d,fbChnIndex'%d,totalLinkNum'%d,linkNum'%d\n",
               __FUNCTION__,chanNo, fbChnIndex,BspGetChanLinkNum(),linkNum);

/* Started by AICoder, pid:o77f2822dbzeda814c2309b84047f707e9f75486 */
    retVal = BspGetFbOpenLoopInfo(linkNum, pLinkId, pRfInfo, cailGain, &totalCailGain, &prxattMin, &retVal, &cnt);
    if(BSP_OK != retVal)
    {
        free(pLinkId);
        free(pRfInfo);
        dbgErr("[%s] Bsp Get FbOpenLoop Info error\n",__FUNCTION__);
        return BSP_ERROR;
    }
/* Ended by AICoder, pid:o77f2822dbzeda814c2309b84047f707e9f75486 */

    if(0 == BspGetFbOpenLoopType())
    {
        if(cnt != 0)
        {
            averCailGain = totalCailGain/cnt;
        }
        else
        {
            dbgInfo("[%s]cnt is zero ! averCailGain[%d] == totalCailGain[%d]\n",__FUNCTION__,averCailGain,totalCailGain);
            averCailGain = totalCailGain;
        }
    }
    else
    {
        if((0 != prxattMin)&&(0xffff != prxattMin))
        {
            averCailGain = prxattMin;
        }
    }

    /*Ad9379定义为VGA*/
    //BspGetAttLimitedVal(chanNo,PRX,DEVICE_TYPE_ATT,ATT_GET_MAX_FLAG,&prxGainMax);
    //BspGetAttLimitedVal(chanNo,PRX,DEVICE_TYPE_ATT,ATT_GET_MIN_FLAG,&prxGainMin);
    BspGetAttLimitedVal(chanNo,PRX,DEVICE_TYPE_ATT,ATT_GET_MAX_FLAG,&prxGainMax);
    BspGetAttLimitedVal(chanNo,PRX,DEVICE_TYPE_ATT,ATT_GET_MIN_FLAG,&prxGainMin);
    if ((abs(averCailGain) > prxGainMax) || (abs(averCailGain) < prxGainMin))
    {
        dbgErr("[%s] Chan%d PrxAtt %d out of range (%d~%d)\n",__FUNCTION__, chanNo, averCailGain,prxGainMax, prxGainMin);
        dbgErr("[%s] Prx%d OpenPowCali out of range, Att %d\n",__FUNCTION__, chanNo, averCailGain);
        free(pLinkId);
        free(pRfInfo);
        return BSP_ERROR;
    }
    dbgInfoEx("\n[%s]totalCailGain'%d, cnt'%d, averCailGain'%d\n",__FUNCTION__,totalCailGain,cnt,averCailGain);
    retVal = BspSetPrxGain(chanNo,averCailGain);
    free(pLinkId);
    free(pRfInfo);

    BspLog(LOG_LEVEL_0,"%s{%d} return %d\n",__FUNCTION__,chanNo,retVal);
    return retVal;
}

/*9124 反馈预开环增益获取*/
UINT32 BspGetFbPreOpenLoopCailGain(UINT32 chanNo, UINT32 freq, INT32 *pCaliGain )
{
    UINT32 retVal = BSP_OK;
    INT32  attStep      = 50;//0.5db
    INT32  targetGain   = 0;
    INT32  prxAttDef     = 0;
    UINT32 rfChn = chanNo;
    UINT32 bspChn = 0;
    INT32  bdtemp = 300;
    INT32  patemp = 300;
    T_CompsData fix = {0};

    if (chanNo >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(pCaliGain);
    retVal = BspGetBspChnByRfChn(rfChn,TX,&bspChn);
    CHECK_RETVAL_PRN(BspGetBspChnByRfChn, retVal);
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);

    _BspGetFwdRevChanTargetGain(chanNo,&targetGain);
    retVal = _BspGetTxFwd(bspChn,bdtemp,patemp,freq,0,&fix,COMPS_BY_FREQ_POINT_TYPE);
    if((retVal != BSP_OK) || (fix.comps == 0))
    {
        prxAttDef = _BspGetDlPowDefPara(bspChn,E_ATT_DEF_PRX);
        fix.comps = targetGain - prxAttDef;
        dbgInfo("****PrxGain read from file Error!,use default value!\n");
    }

    *pCaliGain   =  ((targetGain - fix.comps - 25)/attStep)*attStep;
    dbgInfoEx("[%s] targetGain %d fix.comps %d PrxLink %d LoopCali ,adjustGain to %d\n ",
               __FUNCTION__,targetGain,fix.comps,chanNo,*pCaliGain);

    return BSP_OK;
}

/*反馈预开环 按单通道取增益 不用共反馈通道取平均*/
UINT32 BspFbPreOpenLoopPowCail(UINT32 chanNo)
{
    UINT32 loop = 0;
    INT32 cailGain = 0;
    INT32 prxGainMax = 0;
    INT32 prxGainMin = 0;
    UINT32 retVal = 0;
    UINT32 freq = 0;
    UINT32 linkNum = 0;
    UINT32 fbChnIndex = 0;
    UINT32 *pLinkId = NULL;
    UINT32 *pRfInfo = NULL;
    INT32 totalCailGain = 0;
    INT32 cnt = 0;
    INT32 averCailGain = 0;

    if (BspGetRfChCenterFreq(chanNo, TX, &freq) != BSP_OK)  /*预开环使用双工中心频点*/
    {
        return BSP_ERROR;
    }
    dbgInfo("%s{%d %d} enter\n",__FUNCTION__, chanNo, freq);
    BspLog(LOG_LEVEL_0,"%s{%d %d} enter\n",__FUNCTION__, chanNo, freq);
    linkNum = BspGetChanLinkNum();
    pLinkId = (UINT32 *)malloc(sizeof(UINT32)*linkNum);
    if (NULL == pLinkId)
    {
        dbgErr("[%s] malloc 1 error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    pRfInfo = (UINT32 *)malloc(sizeof(UINT32)*linkNum);
    if (NULL == pRfInfo)
    {
        free(pLinkId);
        dbgErr("[%s] malloc 2 error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    memset(pRfInfo,0xFF,sizeof(UINT32)*linkNum);
    BspGetFbChnInfoByRfChn(chanNo,&fbChnIndex);
    if(BSP_OK != BspGetLinkInfoByLinkType(LINK_TYPE_TX,LINK_INFO_FBCH,fbChnIndex,pLinkId,&linkNum))
    {
        free(pLinkId);
        free(pRfInfo);
        dbgErr("[%s] BspGetLinkInfoByLinkType error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    if(0 == linkNum)
    {
        free(pLinkId);
        free(pRfInfo);
        dbgErr("[%s] linkNum error\n",__FUNCTION__);
        return BSP_ERROR;
    }
    dbgInfoEx("[%s]chanNo'%d,fbChnIndex'%d,totalLinkNum'%d,linkNum'%d\n",
               __FUNCTION__,chanNo, fbChnIndex,BspGetChanLinkNum(),linkNum);
    for(loop = 0; loop < linkNum; loop ++)
    {
        if(BSP_OK != BspGetLinkInfoByLinkId(pLinkId[loop],LINK_INFO_RFCHN,&pRfInfo[loop]))
        {
            pRfInfo[loop] = 0xFFFF;
            continue;
        }
        retVal = BspGetFbPreOpenLoopCailGain(pRfInfo[loop], freq, &cailGain);
        if (retVal != BSP_OK)
        {
            continue;
        }
        totalCailGain += cailGain;   /*共反馈的通道如果取不回来增益 不算到平均里*/
        cnt++;
    }
    if(cnt != 0)
    {
        averCailGain = totalCailGain/cnt;
    }
    BspGetAttLimitedVal(chanNo,PRX,DEVICE_TYPE_ATT,ATT_GET_MAX_FLAG,&prxGainMax);
    BspGetAttLimitedVal(chanNo,PRX,DEVICE_TYPE_ATT,ATT_GET_MIN_FLAG,&prxGainMin);
    if ((abs(averCailGain) > prxGainMax) || (abs(averCailGain) < prxGainMin))
    {
        dbgErr("[%s] Chan%d PrxAtt %d out of range (%d~%d)\n",__FUNCTION__, chanNo, averCailGain,prxGainMax, prxGainMin);
        free(pLinkId);
        free(pRfInfo);
        return BSP_ERROR;
    }
    dbgInfoEx("\n[%s]totalCailGain'%d, cnt'%d, averCailGain'%d\n",__FUNCTION__,totalCailGain,cnt,averCailGain);
    retVal = BspSetPrxGain(chanNo,averCailGain);

    BspLog(LOG_LEVEL_0,"%s{%d} prxatt %d return %d\n", __FUNCTION__, chanNo, totalCailGain, retVal);
    free(pLinkId);
    free(pRfInfo);
    return retVal;
}


UINT32 BspGetRxPreAttByFreq(UINT32 chanNo, UINT32 freq, INT32 *preAtt,UINT32 carrMode)
{
        INT32  bdtemp = 300;
        INT32  patemp = 300;
        /*INT32  carrRxGain = 0;*/
        UINT32 bspChn = 0;
        INT32  targetGain = 0;
        /*INT32  attdefVal = 0;*/
        INT32  attValSet = 0;
        UINT32 retVal = BSP_OK;

        INT32  fixedAttGain = BspGetRxPowCaliFixAttGain();
        INT32  fixedTargetGain = 0;
        T_CompsData rssiGain = {0};
        T_RxOpenLoopPara *pRxPara = BspGetRxOpenLoopPara();
        INPUT_POINTER_CHECK(pRxPara);

        if (chanNo >= BspGetRxChannel())
        {
            return BSP_ERROR;
        }

        //powCtrlLog(LOG_INFO,"%s{%d} enter\n",__FUNCTION__,chanNo);

        retVal = BspGetBspChnByRfChn(chanNo,RX,&bspChn);
        CHECK_RETVAL_PRN(BspGetBspChnByRfChn,retVal);
        BspGetBoardTemp(chanNo,&bdtemp);
        BspGetPaTemp(chanNo,&patemp);
        _BspGetRxChanTargetGain_Base(bspChn,0,&targetGain);

        if(NULL != s_pTUlDefTargetGain)
        {
        	BspGetRxCarrModeTargetGain_Bsp(carrMode,&targetGain);
        }

        fixedTargetGain = targetGain + fixedAttGain;

        dbgInfoEx("[%s]chanNo'%d, bdtemp'%d,patemp'%d,targetGain'%d,fixedAttGain'%d,fixedTargetGain'%d\n",
                 __FUNCTION__,chanNo,bdtemp,patemp,targetGain,fixedAttGain,fixedTargetGain);
        if( freq != 0 )  /*载波有效*/
        {
            if (BSP_OK == _BspGetRxGain(bspChn,0,bdtemp,patemp,freq,0,&rssiGain,COMPS_BY_FREQ_POINT_TYPE))
            {
                attValSet = fixedTargetGain - rssiGain.comps + BspGetLna2ByPassGain(bspChn);
            }
            else
            {
                /* 按远志要求,取不到时,用默认值替代 */
                attValSet = _BspGetUlAttDefPara(bspChn,0);
            }
            dbgInfoEx("[%s]bspChn%d  carrfreq=%d rssiGain.comps=%d \n",__FUNCTION__, bspChn, freq, rssiGain.comps);
        }
        *preAtt = attValSet;
        dbgInfoEx("[%s]fixedTargetGain'%d ,attValSet'%d.\n",__FUNCTION__,fixedTargetGain,attValSet);
        return BSP_OK;
}

/* Started by AICoder, pid:r24552affa84285145680b7af02eb01860b623e8 */
static FUNC_SET_RX_GAIN_FPGA s_pSetRxGainFpga = NULL;
UINT32 BspSetRxVgaGainCallBackInit(FUNC_SET_RX_GAIN_FPGA pCallBackFunc)
{
    s_pSetRxGainFpga = pCallBackFunc;
    return BSP_OK;
}

UINT32 BspRxOpenLoopPowCail(UINT32 chanNo)
{
    if (NULL != s_pSetRxGainFpga)
    {
        return s_pSetRxGainFpga(chanNo);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:r24552affa84285145680b7af02eb01860b623e8 */

UINT32 _BspGetGainComps(UINT32 type,UINT32 bspChn,
    INT32 bdtemp,
    INT32 patemp,
    UINT32 freq,
    UINT32 bw,
    T_CompsData *pGain,
    UINT32 comptype
)
{
    UINT32 retVal = BSP_ERROR;
    switch(type)
    {
        case TX_GAIN_COMPS:
            retVal = _BspGetTxGain(bspChn,bdtemp,patemp,freq,0,pGain,COMPS_BY_FREQ_POINT_TYPE);
            break;

        case FWD_GAIN_COMPS:
            retVal = _BspGetTxFwd(bspChn,bdtemp,patemp,freq,0,pGain,COMPS_BY_FREQ_POINT_TYPE);
            break;

        case REV_GAIN_COMPS:
            retVal = _BspGetTxRev(bspChn,bdtemp,patemp,freq,0,pGain,COMPS_BY_FREQ_POINT_TYPE);
            break;

        case RX_GAIN_COMPS:
            retVal = _BspGetRxGain(bspChn,0,bdtemp,patemp,freq,0,pGain,COMPS_BY_FREQ_POINT_TYPE);
            break;

        case DELT_TX_GAIN_COMPS:
            retVal = _BspGetDeltTxGain(bspChn,bdtemp,patemp,freq,0,pGain,COMPS_BY_FREQ_POINT_TYPE);
            break;

        case DELT_RX_GAIN_COMPS:
            retVal = _BspGetDeltRxGain(bspChn,0,bdtemp,patemp,freq,0,pGain,COMPS_BY_FREQ_POINT_TYPE);
            break;

    }
    return retVal;
}


static UINT32 prngaincomps(
    INT32  bdtemp,
    INT32  patemp,
    UINT32 freq
)
{
    T_CompsData gain = {0};
    UINT32 chn  = 0;

    UINT32 type = 0;
    UINT32 retVal = 0;
    for(type = TX_GAIN_COMPS; type < GAIN_COMPS_MAX; type++)
    {
        dbgInfo("\ntypeIndex = %d, bdtemp = %d, patemp = %d\n", type, bdtemp, patemp);
        dbgInfo(" channl    lRf    lIf   bdGainTemp  paGainTemp   comps\n");
        for(chn = 0; chn < BspGetTxChanNum(); chn++)
        {
            retVal = _BspGetGainComps(type, chn, bdtemp, patemp, freq, 0, &gain, 0);
            if(BSP_OK == retVal)
            {
                dbgInfo("  %2d       %4d  %4d    %4d          %4d       %4d\n", chn, gain.ChannelComps.lRf, gain.ChannelComps.lIf,
                         gain.tempComps.bdGainTemp, gain.tempComps.paGainTemp, gain.comps);
            }
            else
            {
                dbgInfo("Error! retVal = 0x%08x\n", retVal);
            }
        }
    }

    return BSP_OK;
}


UINT32 BspGetFilterGain(UINT32 Index, INT32 *pFilterGain)
{
    UINT32 CenterFreq,Ret=BSP_ERROR;
//  INPUT_POINTER_CHECK(pFilterGain);

    CenterFreq = BspGetMultiCarrCenterFreq(TX,Index);

    if(CenterFreq!=BSP_ERROR && CenterFreq!=0)
    {
        Ret = GetFilterGain(Index,CenterFreq,pFilterGain);
    }
    return Ret;
}

UINT32 BspGetPaRl(UINT32 Index, INT32 *pPaRl)
{
    UINT32 CenterFreq,Ret=BSP_ERROR;
//  INPUT_POINTER_CHECK(pPaRl);

    CenterFreq = BspGetMultiCarrCenterFreq(TX,Index);

    if(CenterFreq!=BSP_ERROR && CenterFreq!=0)
    {
        Ret = GetPaRl(Index,CenterFreq,pPaRl);
    }
    return Ret;
}
UINT32 BspGetTxOpenRl(UINT32 Index, INT32 *pTxOpenRl)
{
    UINT32 CenterFreq,Ret=BSP_ERROR;
//  INPUT_POINTER_CHECK(pTxOpenRl);

    CenterFreq = BspGetMultiCarrCenterFreq(TX,Index);

    if(CenterFreq!=BSP_ERROR && CenterFreq!=0)
    {
        Ret = GetTxOpenRl(Index,CenterFreq,pTxOpenRl);
    }
    return Ret;
}

UINT32 BspGetPaBaseInfo(UINT32 ulIndex, T_PaInfo *ptInfo)
{
    UINT32    ulPaIdx = 0;
    UINT32    ulPaChan = 0;
    /*UINT32    ulEfficientVal = 0;*/
    TPaBasicInfoCaliData *ptPaBasicData = NULL;

    if (ulIndex >= BspGetTxChannel())
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(ptInfo);

    BspGetPaInfoByBspChn(ulIndex, TX, &ulPaIdx, &ulPaChan);

    ptPaBasicData = (TPaBasicInfoCaliData *)_BspGetCalibData(TBL_KIND_OF_PABASICINFO,ulPaIdx);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptPaBasicData);
    _PABASICINFO_LOADED_CHECK(ptPaBasicData, ulPaChan);

    ptInfo->ulEfficientVal = ptPaBasicData->atBasicInfoPath[ulPaChan].ulEfficientPa;
    ptInfo->ulPaType       = ptPaBasicData->atBasicInfoPath[ulPaChan].ulPaType;
    ptInfo->ulPaCfgFreq    = ptPaBasicData->atBasicInfoPath[ulPaChan].ulIsSupportCfgFreq;
    ptInfo->ulPaBestVolt   = ptPaBasicData->atBasicInfoPath[ulPaChan].ulPaBestVolt;
    ptInfo->ulPaVoltUp     = ptPaBasicData->atBasicInfoPath[ulPaChan].ulPwrVoltUp;
    ptInfo->ulPaVoltDown   = ptPaBasicData->atBasicInfoPath[ulPaChan].ulPwrVoltDown;

    return BSP_OK;
}

UINT32 testBspGetTxOpenRl(UINT32 Index)
{
    INT32 ulTxOpenRl = 0;

    if(BSP_OK!=BspGetTxOpenRl(Index,&ulTxOpenRl))
    {
        dbgErr("%s [Idx%d], Return Failed !\n",__FUNCTION__,Index);
    }
    else
    {
        dbgPrn("%s [Idx%d], TxOpenRl %d\n",__FUNCTION__,Index,ulTxOpenRl);
    }
    return BSP_OK;
}

UINT32 compsprn(UINT32 ulIdx, UINT32 ulRadioMode)
{
    INT32 freq;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    INT32 rfChn;
    UINT32 bspChn = 0;
    char  strtemp[16] = {0};
    T_PowCalcCompsPara PowCompsData = {0};
    /*INT8  *pItem;*/
    UINT8 list;
    UINT32 retVal = BSP_OK;

    struct tagTCalibTblList
    {
        UINT8         type;
        const char    *pItem;
        T_CompsData   compsData;
    }satCalibTblList[] =
    {
        _CALIB_TBL_GAIN_LIST(TX_GAIN_COMPS,TxGain),
        _CALIB_TBL_GAIN_LIST(FWD_GAIN_COMPS,FwdGain),
        _CALIB_TBL_GAIN_LIST(REV_GAIN_COMPS,RevGain),
        _CALIB_TBL_GAIN_LIST(RX_GAIN_COMPS,RxGain),
        _CALIB_TBL_GAIN_LIST(DELT_TX_GAIN_COMPS,DeltTxGain),
        _CALIB_TBL_GAIN_LIST(DELT_RX_GAIN_COMPS,DeltRxGain),
    };

    for (rfChn = 0; rfChn < max(BspGetTxChannel(), BspGetRxChannel()); rfChn++)
    {
        if (rfChn >= BSP_MAX_TX_CHAN)
        {
            break;
        }
        freq = BspGetMultiCarrCenterFreq(TX,rfChn);
        BspGetBoardTemp(rfChn,&bdtemp);
        BspGetPaTemp(rfChn,&patemp);
        retVal = BspGetBspChnByRfChn(rfChn, TX, &bspChn);
        CHECK_RETVAL_PRN(BspGetBspChnByRfChn,retVal);
        RedirPrintf("%-16s %-8s %-6s %-6s %-6s %-6s %-6s %-6s %-8s\n",
            "GainItem", "Comps", "Rf", "If", "BdTemp", "PaTemp", "TempBd", "TempPa","Freq");
        for(list = 0; list < NELEMENTS(satCalibTblList); list++)
        {
            if (list == 3)
            {
                freq = BspGetMultiCarrCenterFreq(RX,rfChn);
            }
            retVal = _BspGetGainComps(satCalibTblList[list].type,bspChn,bdtemp,patemp,freq,0,&satCalibTblList[list].compsData,COMPS_BY_FREQ_POINT_TYPE);
            CHECK_RETVAL_PRN(_BspGetGainComps,retVal);
            (void)snprintf_s(strtemp, sizeof(strtemp), "%s%d\0", satCalibTblList[list].pItem, rfChn);
            RedirPrintf("%-16s %-8d %-6d %-6d %-6d %-6d %-6d %-6d %-8d\n", strtemp,
                satCalibTblList[list].compsData.comps,
                satCalibTblList[list].compsData.ChannelComps.lRf,
                satCalibTblList[list].compsData.ChannelComps.lIf,
                satCalibTblList[list].compsData.tempComps.bdGainTemp,
                satCalibTblList[list].compsData.tempComps.paGainTemp,
                bdtemp, patemp, freq);
        }
        RedirPrintf("\n");
    }

    return BSP_OK;
}
/* Started by AICoder, pid:rd4c5sfc01c5c6a149420a2e5009561ddf966f3b */
INT32 g_ssbFreq = 0;

UINT32 BspGetSsbFreqFromApp(INT32 ssbFreq)
{
    g_ssbFreq = ssbFreq;
    return BSP_OK;
}
/* Ended by AICoder, pid:rd4c5sfc01c5c6a149420a2e5009561ddf966f3b */

/* Started by AICoder, pid:fbe5e19ebdw5bf314408096040521133c5d0c455 */
BOOL BspRadioModeIsNr(UINT32 chan)
{
    UINT32 ret = 0;
    UINT32 radioMode = 0;

    ret = BspGetRadioModeByChan(chan, &radioMode);
    if(BSP_OK != ret)
    {
        return FALSE;
    }

    if(BSP_RADIO_STANDARD_5G == radioMode || BSP_RADIO_STANDARD_FDD_5G == radioMode)
    {
        return TRUE;
    }

    return FALSE;
}
/* Ended by AICoder, pid:fbe5e19ebdw5bf314408096040521133c5d0c455 */

/* Started by AICoder, pid:d053cdf4125fa0c146160b4a4007320176672c7f */
/* Started by AICoder, pid:se8b5r47efee4f114c0908af306a2c0d1585d29c */
/**************************************************************************
 * G1_T1 ：     Rx定标链路增益（基于温度T1）
 * GTComp1_T1 ：Rx温补增益（基于温度T0 -T1）
 * G2_T2 ：     DeltaRx定标链路增益（基于温度T2）
 * GTComp1_T2 ：Rx温补增益（基于温度T0 -T2）
 * GTComp3_T2 ：共用链路温补增益（基于温度T0 -T2）
 * 代码中rxGain.comps为 G1_T1 - GTComp1_T1
 * 代码中deltRxGain.comps为 G2_T2 + GTComp3_T2
 * 代码中deltLinkTempGain为 GTComp1_T2
 * 增益公式：    Gain = (G1_T1 - GTComp1_T1) - (G2_T2 + GTComp3_T2 - GTComp1_T2)
 **************************************************************************/
UINT32 BspGetCompsGain(UINT32 rfChn, UINT32 dir, INT32* gain, INT32* deltGain)
{
    INT32 freq;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    INT32 deltLinkTempGain = 0;
    UINT32 bspChn = 0;
    char  strtemp[16] = {0};
    T_PowCalcCompsPara PowCompsData = {0};
    UINT8 list;
    UINT32 retVal = BSP_OK;
    T_CompsData txGain = {0};
    T_CompsData deltTxGain = {0};
    T_CompsData rxGain = {0};
    T_CompsData deltRxGain = {0};
    T_TempComps tempCompsGain = {0};

    struct tagTCalibTblList
    {
        UINT8         type;
        const char    *pItem;
        T_CompsData   compsData;
    }satCalibTblList[] =
    {
        _CALIB_TBL_GAIN_LIST(TX_GAIN_COMPS,TxGain),
        _CALIB_TBL_GAIN_LIST(DELT_TX_GAIN_COMPS,DeltTxGain),
        _CALIB_TBL_GAIN_LIST(RX_GAIN_COMPS,RxGain),
        _CALIB_TBL_GAIN_LIST(DELT_RX_GAIN_COMPS,DeltRxGain),
    };

    INPUT_POINTER_CHECK(gain);
    INPUT_POINTER_CHECK(deltGain);

    if (rfChn >= BSP_MAX_TX_CHAN)
    {
        return BSP_ERROR;
    }
    if(BspRadioModeIsNr(rfChn))
    {
        freq = g_ssbFreq;  //NR
    }
    else
    {
        freq = BspGetMultiCarrCenterFreq(TX,rfChn);  //LTE
    }
    
    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    retVal = BspGetBspChnByRfChn(rfChn, TX, &bspChn);
    CHECK_RETVAL_PRN(BspGetBspChnByRfChn,retVal);

    dbgInfoEx("%-16s %-8s %-6s %-6s %-6s %-6s %-6s %-6s %-8s\n",
            "GainItem", "Comps", "Rf", "If", "BdTemp", "PaTemp", "TempBd", "TempPa","Freq");
    for(list = 0; list < NELEMENTS(satCalibTblList); list++)
    {
        if ((2 == list) || (3 == list))
        {
            if(BspRadioModeIsNr(rfChn))
            {
                freq = g_ssbFreq;  //NR
            }
            else
            {
                freq = BspGetMultiCarrCenterFreq(RX,rfChn);  //LTE
            }
        }
        retVal = _BspGetGainComps(satCalibTblList[list].type,bspChn,bdtemp,patemp,freq,0,&satCalibTblList[list].compsData,COMPS_BY_FREQ_POINT_TYPE);
        CHECK_RETVAL_PRN(_BspGetGainComps,retVal);
        (void)snprintf_s(strtemp, sizeof(strtemp), "%s%d\0", satCalibTblList[list].pItem, rfChn);
        dbgInfoEx("%-16s %-8d %-6d %-6d %-6d %-6d %-6d %-6d %-8d\n", strtemp,
            satCalibTblList[list].compsData.comps,
            satCalibTblList[list].compsData.ChannelComps.lRf,
            satCalibTblList[list].compsData.ChannelComps.lIf,
            satCalibTblList[list].compsData.tempComps.bdGainTemp,
            satCalibTblList[list].compsData.tempComps.paGainTemp,
            bdtemp, patemp, freq);
    }
    retVal = _BspGetTxGain(bspChn,bdtemp,patemp,freq,0,&txGain,COMPS_BY_FREQ_POINT_TYPE);
    CHECK_RETVAL_PRN(_BspGetTxGain,retVal);
    retVal = _BspGetDeltTxGain(bspChn,bdtemp,patemp,freq,0,&deltTxGain,COMPS_BY_FREQ_POINT_TYPE);
    CHECK_RETVAL_PRN(_BspGetDeltTxGain,retVal);
    retVal = _BspGetRxGain(bspChn,0,bdtemp,patemp,freq,0,&rxGain,COMPS_BY_FREQ_POINT_TYPE);
    CHECK_RETVAL_PRN(_BspGetRxGain,retVal);
    retVal = _BspGetDeltRxGain(bspChn,0,bdtemp,patemp,freq,0,&deltRxGain,COMPS_BY_FREQ_POINT_TYPE);
    CHECK_RETVAL_PRN(_BspGetDeltRxGain,retVal);
    if(TX == dir)
    {
        retVal = _BspGetTempCompsValNcr(TBL_DELT_TX_GAIN, TBL_TX_GAIN, bspChn, freq, &tempCompsGain);
        CHECK_RETVAL_PRN(_BspGetTempCompsValNcr, retVal);
        deltLinkTempGain = tempCompsGain.bdGainTemp + tempCompsGain.paGainTemp;
        *gain = txGain.comps;
        *deltGain = deltTxGain.comps - deltLinkTempGain;
        dbgInfo("[%s]txch = %d, txgain = %d, deltatxgain = %d, deltatxcomps = %d, deltatxtempgain = %d\n", 
                 __FUNCTION__, rfChn, txGain.comps, *deltGain, deltTxGain.comps, deltLinkTempGain);
    }
    else
    {
        retVal = _BspGetTempCompsValNcr(TBL_DELT_RX_GAIN, TBL_RX_RSSI, bspChn, freq, &tempCompsGain);
        CHECK_RETVAL_PRN(_BspGetTempCompsValNcr, retVal);
        deltLinkTempGain = tempCompsGain.bdGainTemp + tempCompsGain.paGainTemp;
        *gain = rxGain.comps;
        *deltGain = deltRxGain.comps- deltLinkTempGain;
        dbgInfo("[%s]rxch = %d, rxgain = %d, deltarxgain = %d, deltarxcomps = %d, deltarxtempgain = %d\n", 
                 __FUNCTION__, rfChn, rxGain.comps, *deltGain, deltRxGain.comps, deltLinkTempGain);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:se8b5r47efee4f114c0908af306a2c0d1585d29c */

UINT32 BspCalcGainForMt(UINT32 rfChn, UINT32 dir, INT32 *totalGain)
{
    INT32 gain = 0;
    INT32 deltGain = 0;
    UINT32 ret = 0;

    INPUT_POINTER_CHECK(totalGain);
    ret = BspGetCompsGain(rfChn, dir, &gain, &deltGain);
    CHECK_RETVAL_PRN(BspGetCompsGain,ret);

    *totalGain = gain - deltGain;
    dbgInfoEx("[%s]rfChn:%d, dir:%d, gain:%d, deltGain:%d,  totalGain:%d\n", 
            __FUNCTION__, rfChn, dir, gain, deltGain, *totalGain);

    return ret;
}
/* Ended by AICoder, pid:d053cdf4125fa0c146160b4a4007320176672c7f */

static UINT32 txopenloop(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetTxChannel(), endChn+1);

    do
    {
        retVal |= BspTxOpenLoopPowCail(chn);
    } while (++chn < chnNum);
    return retVal;
}

static UINT32 rxopenloop(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetRxChannel(), endChn+1);

    do
    {
        retVal |= BspRxOpenLoopPowCail(chn);
    } while (++chn < chnNum);
    return retVal;
}

static UINT32 prxopenloop(UINT32 startChn,UINT32 endChn)
{
    UINT32 retVal = BSP_OK;
    UINT32 chn = startChn;
    UINT32 chnNum = min(BspGetPrxChannel(), endChn+1);

    do
    {
        retVal |= BspFbOpenLoopPowCail(chn);
    } while (++chn < chnNum);
    return retVal;
}


/*调试用函数**/
static VOID padrainadjpagaintest(UINT32 ulChanSel,UINT32 ulPaVolt)
{
    INT32 ulPaGain = 0;
    BspGetPaDrainAdjPaGain(ulChanSel,ulPaVolt,&ulPaGain);

    dbgInfo("[%s]Get Pa Gain is %d \n",__FUNCTION__,ulPaGain);

}

//获取峰均比值调试函数
static VOID pwrgetaverageratio(VOID)
{
    UINT32 ulGetPwrAvgRat = 0;
    if (BSP_ERROR == BspGetPwrAverageRatio(&ulGetPwrAvgRat))
    {
        dbgErr("[%s]:Pwr Average Ration Failed!\n",__FUNCTION__);
    }
    dbgInfo("[%s]:Pwr Average Ration is %d\n",__FUNCTION__,ulGetPwrAvgRat);
    //return ;
}

UINT32 TempCompsThreadSw(UINT32 ulSwitch)
{
    sulTempCompsThreadSwitch = ulSwitch;
    return BSP_OK;
}
// 单位s
UINT32 compsset(UINT32 ulSec)
{
    sCalibTblCompsPeriod = ulSec*1000;
    return BSP_OK;
}

UINT32 BspCalibTblCompsParaInit(void)
{
    UINT32 ulRfGrp = 0;

    for (ulRfGrp = 0; ulRfGrp < BspGetTxChannel(); ulRfGrp++)
    {
        stCompsTemp.alPaTemp[ulRfGrp] = 300;
        stCompsTemp.lTrxTemp[ulRfGrp] = 300;
    }
    return BSP_OK;
}

static uint32_t g_paInvalidTempCnt[BSP_HALADAPT_IC_CHAN_MAX_NUM] = {0};
static int32_t g_paInValidTempRecord[BSP_HALADAPT_IC_CHAN_MAX_NUM][3] = {0};
static void showPaTempRecord()
{
    uint32_t exLoop = 0;
    uint32_t inLoop = 0;

    dbgInfo("-----------------------------------------------\n");
    dbgInfo("ChanNo | paTemp1 | paTemp2 | paTemp3 | InvCnt |\n");
    for(exLoop = 0; exLoop < BSP_HALADAPT_IC_CHAN_MAX_NUM; exLoop++)
    {
        dbgInfo("-----------------------------------------------\n");
        dbgInfo("%4d   |", exLoop);
        for(inLoop = 0; inLoop < 3; inLoop++)
        {
            dbgInfo("%6d   |", g_paInValidTempRecord[exLoop][inLoop]);
        }
        dbgInfo("%5d   |\n", g_paInvalidTempCnt[exLoop]);
    }
    dbgInfo("-----------------------------------------------\n");
}

UINT32 BspGetBoardTempRecord(UINT32 index, INT32 *temp)
{
    INPUT_POINTER_CHECK(temp);

    if(index >= RRU_MAX_BOARD_NODE_NUM)
    {
        dbgErr("[%s] index = %d, Out of Range!", __FUNCTION__, index);
        return BSP_ERROR;
    }

    *temp = BoardTempNode[index];
    dbgInfoEx("%s: index=%d temp=%d \n",__FUNCTION__, index, *temp);

    return BSP_OK;
}

/* 从硬件获取单板节点温度 */
UINT32 BspGetBoardTempNodeFromHw(UINT32 index, INT32 *temp)
{
    int    ret = 0;
    UINT32 devId = 0;
    CHAR   bufName[STRING_LENGTH_128_BYTE] = {0};

    INPUT_POINTER_CHECK(temp);

    ret = snprintf_s(bufName, sizeof(bufName), "TempNodeBoard%d", index);
    SNPRINTF_S_CHECK(ret, sizeof(bufName));

    devId = BspDevNameToId(bufName);

    return BspGetTempSensorInfo(devId, temp);
}

UINT32 BspBoardTempNodeRecord(void)
{
    static CHAR dviceName[] = "TempNodeBoard";
    UINT32 length = strnlen_s(dviceName, MAX_DEVICE_LEN);
    UINT32 loop = 0;
    INT32  temp = 0;
    UINT32 deviceNodeNum = 0;

    deviceNodeNum = BspGetDeviceNodeNum(dviceName, length);  /* 获取RRU整机单板温度测量点数量 */
    if(deviceNodeNum > RRU_MAX_BOARD_NODE_NUM)
    {
        dbgErr("[%s] deviceNodeNum = %d, Out of Range!", __FUNCTION__, deviceNodeNum);
        return BSP_ERROR;
    }

    /* 单板节点温度 */
    for (loop = 0; loop < deviceNodeNum; loop++)
    {
        if(BSP_OK == BspGetBoardTempNodeFromHw(loop, &temp))
        {
            BoardTempNode[loop] = temp;
        }
    }
    dbgInfoEx("[%s]deviceNodeNum:%d, boardTempNode:%d\n", __FUNCTION__, deviceNodeNum, temp);

    return BSP_OK;
}

// 从硬件获取温度
static UINT32 _BspGetCompsTemp(UINT32 chan, UINT32 temptpye, INT32 *temp)
{
    UINT32 ulRet = 0;
    INT32  alTemp = 0;

    // 获取单板温度
    if(temptpye == 0)
    {
        ulRet = BspGetBoardTempFromHW(0, &alTemp);
    }
    else
    {
        ulRet = BspGetPaTempFromHW(chan, &alTemp);
    }
    if (temp)
    {
        *temp = alTemp;
    }
    dbgInfoEx("%s: chan=%d temptpye=%d Temp=%d\n",__FUNCTION__, chan, temptpye, alTemp);
    return ulRet;
}

UINT32 BspGetCalibTblCompsTemp(void)
{
    UINT32 ulRet = 0;
    UINT32 ulChan = 0;
    INT32  temp = 0;
    UINT32 maxChan = max(BspGetTxChannel(), BspGetRxChannel());

    /* 单板温度 */
    for (ulChan = 0; ulChan < maxChan; ulChan++)
    {
        ulRet = _BspGetCompsTemp(ulChan, 0, &temp);
        if(ulRet == BSP_OK)
        {
            stCompsTemp.lTrxTemp[ulChan] = temp;
        }
    }

    for (ulChan = 0; ulChan < BspGetTxChannel(); ulChan++)
    {
        /* 功放温度 */
        ulRet = _BspGetCompsTemp(ulChan, 1, &temp);
        if(ulRet == BSP_OK)
        {
            stCompsTemp.alPaTemp[ulChan] = temp;
        }
    }

    return BSP_OK;
}

void* BspCalibTblCompsThread(void *para)
{
    UINT64 tick1 = 0;
    UINT64 tick2 = 0;

    while (1)
    {
        tick1 = tick64Get();
        BspSysMsDelay_Sys(sCalibTblCompsPeriod);
        if (sulTempCompsThreadSwitch != SWITCH_ON)
        {
            continue;
        }
        #ifdef MULT_PROGRESS_S
        BspBoardTempNodeRecord();  /* 扇区概念机型,获取单板节点温度(只在主片从进程，和各从片收集单板温度) */
        #endif
        BspGetCalibTblCompsTemp();  /* 获取单板温度和pa温度 */
        tick2 = tick64Get();
        dbgInfoEx("<%s> tick1:%llu, tick1:%llu, time:%llu * 10ms\n", __FUNCTION__, tick1, tick2, (tick2-tick1));
        #ifdef UT_FT_TEST
        return NULL;
        #endif
    }
    return NULL;
}

UINT32 BspGetTempThreadSwitch(void)
{
    return sulTempCompsThreadSwitch;
}

UINT32 BspCalibTblCompsThreadInit(void)
{
    UINT32 ulRet = BSP_OK;
    INT32  lTaskID = (INT32)BSP_ERROR;
    UINT32 ulTaskStack = 10;

    lTaskID = taskSpawn("BspCaliTblComps", CALITBL_COMPS_PROCESS_PRIORITY, 0, (1024 * ulTaskStack),
                        (FUNCPTR)BspCalibTblCompsThread, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (BSP_ERROR == (UINT32)lTaskID)
    {
        dbgErr("create thread<%s> failed!lErrcode:%d\n", __FUNCTION__, lTaskID);
        ulRet = BSP_ERROR;
    }
    else
    {
        dbgInfo("create thread<%s> success!\n", __FUNCTION__);
    }

    return ulRet;
}

UINT32 BspGetBoardCompTemp(UINT32 ulchan, INT32 *temp)
{
    UINT32 ulRdBoardTempFlag = 0;
    
    ulRdBoardTempFlag = BspGetRdBoardTempFlag();
    if ((ulchan >= BSP_MAX_TX_CHAN) || (ulRdBoardTempFlag == NOT_READ_BOARD_TEMP_FLAG))
    {
        return BSP_ERROR;
    }
    *temp = stCompsTemp.lTrxTemp[ulchan];
    dbgInfoEx("%s: ulchan=%d temp=%d \n",__FUNCTION__,ulchan,*temp);
    return BSP_OK;
}

UINT32 BspSetSlaveBoardTemp(UINT32 ulChan, INT32 temp)
{
    UINT32 chanIndex = 0;
    if(ulChan >= BspGetTxChannel())
    {
        dbgErr("%s ulchan=%d,para error!\n",__FUNCTION__,ulChan);
        return BSP_ERROR;
    }
    for(chanIndex = 0;chanIndex < BspGetTxChannel();chanIndex++)
    {
        stCompsTemp.lTrxTemp[chanIndex] = temp;
    }
    dbgInfoEx("%s:ulchan=%d boardtemp=%d\n", __FUNCTION__, ulChan, temp);
    return BSP_OK;
}

UINT32 BspSetSlavePaTemp(UINT32 ulChan, INT32 temp)
{
    if(ulChan >= BspGetTxChannel())
    {
        dbgErr("%s ulchan=%d,para error!\n",__FUNCTION__,ulChan);
        return BSP_ERROR;
    }
    stCompsTemp.alPaTemp[ulChan] = temp;
    dbgInfoEx("%s:ulchan=%d patemp=%d\n", __FUNCTION__, ulChan, temp);
    return BSP_OK;
}

UINT32 BspGetPaCompTemp(UINT32 ulchan, INT32 *temp)
{
    INT32 tmp = 0;

    if(ulchan >= BspGetTxChannel())
    {
        dbgErr("%s ulchan=%d,para error!\n",__FUNCTION__,ulchan);
        return BSP_ERROR;
    }
    tmp = stCompsTemp.alPaTemp[ulchan];
    if (temp)
    {
        *temp = tmp;
    }
    else
    {
        dbgInfo("%s:ulchan=%d temp=%d\n", __FUNCTION__, ulchan, tmp);
    }
    dbgInfoEx("%s: ulchan=%d temp=%d \n",__FUNCTION__,ulchan, tmp);
    return BSP_OK;
}

static INT32 s_filterGain = -80;

/* BspGetFilterGain名字已被部分单板使用 */
UINT32 bspGetFilterGain(UINT32 Index, INT32 *pFilterGain)
{
    UINT32 centerFreq = 0;
    UINT32 ret=BSP_ERROR;
    INPUT_POINTER_CHECK(pFilterGain);

    centerFreq = BspGetMultiCarrCenterFreq(TX,Index);

    if(centerFreq!=BSP_ERROR && centerFreq!=0)
    {
        ret = GetFilterGain(Index,centerFreq,pFilterGain);
    }
    return ret;
}

/* 无滤波差损表上报默认值,不区分通道 */
INT32 BspGetDefaultFilterGain(VOID)
{
    return s_filterGain;
}

UINT32 BspSetDefaultFilterGain(INT32 filterGain)
{
    s_filterGain = filterGain;

    return BSP_OK;
}


UINT32 BspGetPaEnergySaveInfo(UINT32 chan, T_PaEnergySaveInfo *ptPaEnergySaveInfo)
{
    UINT32 loop       = 0;
    INT32  filterGain = 0;
    UINT32  ratePow   = 0;
    T_PaEnSavAdjCaliData *ptEnSavAdjData = NULL;
    UINT32 tblIndex = 0;
    UINT32 tblChn = chan;

    INPUT_POINTER_CHECK(ptPaEnergySaveInfo);

    BspUpdateRfTblIndexAndChn(chan, TBL_PAENSAVADJ, &tblIndex, &tblChn);
    ptEnSavAdjData = (T_PaEnSavAdjCaliData *)_BspGetCalibData(TBL_KIND_OF_PAENSAVADJ, tblIndex);
    INPUT_POINTER_CHECK(ptEnSavAdjData);

    if((ptEnSavAdjData->tEnSavAdjHeader.powerNum <1) ||(ptEnSavAdjData->tEnSavAdjHeader.powerNum >MAX_POWLEVEL_NUM))
    {
        dbgInfoEx("Get PowerLever Error!powerNum = %d\n",ptEnSavAdjData->tEnSavAdjHeader.powerNum);
        return BSP_ERROR;
    }
    ptPaEnergySaveInfo->voltLevel = ptEnSavAdjData->tEnSavAdjHeader.vdsNum;
    if(MAX_LEVEL_NUM < ptPaEnergySaveInfo->voltLevel)
    {
        dbgErr("[%s] Get Volt Level Error, voltLevel[%d]!\n",__FUNCTION__, ptPaEnergySaveInfo->voltLevel);
        return BSP_ERROR;
    }
    for (loop = 0; loop < ptPaEnergySaveInfo->voltLevel; loop++)
    {
        ptPaEnergySaveInfo->voltValue[loop] = ptEnSavAdjData->atEnSavAdjPath[0].vdsLevel[loop];
        dbgInfoEx("%s:voltValue = %d\n",__FUNCTION__, ptPaEnergySaveInfo->voltValue[loop]);
    }
    /* 节能表最后一档空载档写表值为0,会导致软件上报负值,功放同事决策，不上报空载档 */
    ptPaEnergySaveInfo->powLevel = ptEnSavAdjData->tEnSavAdjHeader.powerNum -1;
    if (BSP_OK != bspGetFilterGain(chan,&filterGain))
    {
        filterGain = BspGetDefaultFilterGain();
        dbgInfoEx("%s: no FilterGain.txt, chan = %d, gain = %d\n", __FUNCTION__, chan, filterGain);
    }
    BspGetRruPathRatedPower(chan,&ratePow);
    if (ratePow== 0)
    {
        dbgInfoEx("[%s]ratedPower powr is zeor! can not calc \n",__FUNCTION__);
        return BSP_ERROR;
    }
    for (loop = 0; loop < ptPaEnergySaveInfo->powLevel; loop++)
    {
        ptPaEnergySaveInfo->powValue[loop] = ptEnSavAdjData->atEnSavAdjPath[0].powLevel[loop] + filterGain;
        ptPaEnergySaveInfo->powPrecent[loop] = (INT32)(pow(10.0, (double)ptPaEnergySaveInfo->powValue[loop] / 1000.0)*100/ratePow);
        dbgInfoEx("%s:powValue = %d, ratedPower powr = %d, precent = %d\n",__FUNCTION__, ptPaEnergySaveInfo->powValue[loop], ratePow, ptPaEnergySaveInfo->powPrecent[loop]);
    }
    return BSP_OK;
}

UINT32 powlevel(UINT32 chan)
{
    T_PaEnergySaveInfo tPaEnergySaveInfo = {0,};
    UINT32 loop = 0;

    BspGetPaEnergySaveInfo(chan, &tPaEnergySaveInfo);
    dbgInfo("powleVel = %d\n", tPaEnergySaveInfo.powLevel);
    for (loop = 0; loop < tPaEnergySaveInfo.powLevel; loop++)
    {
        dbgInfo("level[%d]:%d precent:%d\n",loop,tPaEnergySaveInfo.powValue[loop],tPaEnergySaveInfo.powPrecent[loop]);
    }
    return BSP_OK;
}

/*****************************************************************************
 *  函数名称   : 获取下行定标txatt回退量
 *  功能描述   :
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 成功; 其它值为失败
 *  其它说明
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
static UINT32 GetTxAttAndDigGain(UINT32 chan,INT32 att,INT32 *txAtt,INT32 *digGain)
{
    INPUT_POINTER_CHECK(txAtt);
    INPUT_POINTER_CHECK(digGain);

    *digGain = _BspGetDlPowDefPara(chan,E_TXATT_BACK);/* 回退量 需要从单板下获取 这个值后边又通过BspSetKdGain设置进去了*/
    *txAtt = att - (*digGain);
    return BSP_OK;
}
/*****************************************************************************
 *  函数名称   : 下行定标接口挂接
 *  功能描述   :
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   : BSP_OK - 成功; 其它值为失败
 *  其它说明
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
* $0000000(N/A),  创建
 *----------------------------------------------------------------------------
 */
UINT32 BspInitTxOpenLoopPara(VOID)
{
    T_TxOpenLoopPara para = {0};

    para.pGetGain    = GetTxAttAndDigGain;
    para.pSetTxAtt   = BspSetTxGain;
    para.pSetDigGain = BspSetKdGain;
    para.pExtraProc  = NULL;
    return BspSetTxOpenLoopPara(&para);
}

UINT32 BspInitRxOpenLoopPara(T_RxOpenLoopPara *para )
{
    return BspSetRxOpenLoopPara(para);
}
UINT32 BspModifyRxOpenLoopPara(UINT32 chan,INT32 attMin,INT32 attMax,INT32 att)
{
    UINT32 ret = BSP_OK;
    T_RxOpenLoopPara *pPara = NULL;

    if (chan >= NELEMENTS(pPara->preAttMax))
    {
        return BSP_ERROR;
    }
    pPara = BspGetRxOpenLoopPara();
    pPara->preAtt[chan]    = att;
    pPara->preAttMin[chan] = attMin;
    pPara->preAttMax[chan] = attMax;
    ret = BspInitRxOpenLoopPara(pPara);

    return ret;
}

// 从硬件获取单板温度
UINT32 BspGetBoardTempFromHW(UINT32 index, INT32 *pTemp)
{
    int     ret = 0;
    CHAR    bufName[STRING_LENGTH_128_BYTE] = {0};
    UINT32 retVal = 0;
    T_RfTblChanPara tmp = {0};

    retVal = BspGetSingleChanRfTblPara(index, &tmp);
    if(BSP_OK == retVal)
    {
        if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道*/
        {
            if(NULL != tmp.pGetSlaveBoardTemp)
            {
               return tmp.pGetSlaveBoardTemp(index, pTemp);
            }
        }

    }

    ret = snprintf_s(bufName, sizeof(bufName), "TempBoard%d", index);
    SNPRINTF_S_CHECK(ret, sizeof(bufName));
    return BspGetTempSensorInfo(BspDevNameToId(bufName), pTemp);
}

UINT32 BspGetPaTempFromHW(UINT32 bspChan, INT32 *pTemp)
{
    UINT32  paChnl = 0;
    UINT32  retVal = 0;
    int     ret = 0;
    UINT32  devId = 0;
    CHAR    bufName[STRING_LENGTH_128_BYTE] = {0};
    T_RfTblChanPara tmp = {0};

    ret = BspGetPaChnByBspChn(bspChan, TX, &paChnl);
    if (ret != BSP_OK)
    {
        dbgErr("%s>>bspChan'%d GetPaChnl Error! Ret= 0x%X\n",
               __FUNCTION__, bspChan, ret);
        return BSP_ERROR;
    }

    retVal = BspGetSingleChanRfTblPara(bspChan, &tmp);
    if(BSP_OK == retVal)
    {
        if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道*/
        {
            INPUT_POINTER_CHECK(tmp.pGetSlavePaTemp);
            return tmp.pGetSlavePaTemp(bspChan, pTemp);
        }

    }

    ret = snprintf_s(bufName, sizeof(bufName), "TempPa%d", paChnl);
    SNPRINTF_S_CHECK(ret, sizeof(bufName));
    bufName[STRING_LENGTH_128_BYTE - 1] = '\0';
    devId = BspDevNameToId(bufName);
    if (devId == BSP_ERROR)
    {
        dbgErr("%s>>bspChan'%d DevName'%s ToDevId Error! DevId= 0x%X\n",
               __FUNCTION__, bspChan, bufName, devId);
        return BSP_ERROR;
    }

    return BspGetTempSensorInfo(devId, pTemp);
}

/* Started by AICoder, pid:a9662df891h7fe8148bf0811b0b56b2f7e93648f */
UINT32 BspGetCalPortTemp(UINT32 calChn, INT32 *pTemp)
{
    int     ret = 0;
    CHAR    bufName[STRING_LENGTH_128_BYTE] = {0};

    INPUT_POINTER_CHECK(pTemp);

    ret = snprintf_s(bufName, sizeof(bufName), "TempAtt%u", calChn);
    SNPRINTF_S_CHECK(ret, sizeof(bufName));
    return BspGetTempSensorInfo(BspDevNameToId(bufName), pTemp);
}
/* Ended by AICoder, pid:a9662df891h7fe8148bf0811b0b56b2f7e93648f */

/* Started by AICoder, pid:had62n6439y5654146df0a5fd0b77c3f41596753 */
UINT32 BspGetPaTempSensorCfgInfo(UINT32 bspChan, T_PaTempSensorCfg *paSensorCfg)
{
    INT    ret = 0;
    UINT32 paChnl = 0;
    UINT32 devId = 0;
    CHAR bufName[STRING_LENGTH_128_BYTE] = {0};
    TRruDeviceDescription dev = {0};

    INPUT_POINTER_CHECK(paSensorCfg);

    if(BSP_OK != BspGetPaChnByBspChn(bspChan, TX, &paChnl))
    {
        dbgErr("%s>>bspChan'%d GetPaChnl Error!\n", __FUNCTION__, bspChan);
        return BSP_ERROR;
    }

    ret = snprintf_s(bufName, sizeof(bufName), "TempPa%d", paChnl);
    SNPRINTF_S_CHECK(ret, sizeof(bufName));

    bufName[STRING_LENGTH_128_BYTE - 1] = '\0';
    devId = BspDevNameToId(bufName);
    if((BSP_ERROR == devId)  || (BSP_ERROR_NULL_POINTER == devId))
    {
        dbgErr("[%s]>>bspChan:%d bufName:%s ToDevId Error! DevId= 0x%x\n",
               __FUNCTION__, bspChan, bufName, devId);
        return BSP_ERROR;
    }

    if (BSP_OK != BspDevInfoGetByDevId(devId, &dev))
    {
        dbgErr("%s>>BspGetDevInfo Error!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    strncpy_s(paSensorCfg->deviceName, BAR_MAX_LENGTH, dev.acDeviceName, BAR_MAX_LENGTH);
    paSensorCfg->deviceIndex = dev.ulDeviceIndex;
    paSensorCfg->deviceInterIndex = dev.ulDeviceInterIndex;

    return BSP_OK;
}
/* Ended by AICoder, pid:had62n6439y5654146df0a5fd0b77c3f41596753 */

/* Started by AICoder, pid:w7d09o1670oc589141640aff1083a01847b43c83 */
UINT32 BspEqualPaSensorCfg(T_PaTempSensorCfg *destPaCfg, T_PaTempSensorCfg *srcPaCfg)
{
    INPUT_POINTER_CHECK(destPaCfg);
    INPUT_POINTER_CHECK(srcPaCfg);

    if(0 == strcmp(destPaCfg->deviceName, srcPaCfg->deviceName) &&
       destPaCfg->deviceIndex == srcPaCfg->deviceIndex &&
       destPaCfg->deviceInterIndex == srcPaCfg->deviceInterIndex)
    {
        return BSP_OK;
    }

    return BSP_ERROR;
}
/* Ended by AICoder, pid:w7d09o1670oc589141640aff1083a01847b43c83 */

/* Started by AICoder, pid:u20f1l4486800ef141a00ae810bf03440f16b416 */
UINT32 BspGetPaTempSensorCfgByChan(UINT32 bspChan, T_PaTempSharePara *para)
{
    UINT32 ret = BSP_OK;
    UINT32 chan = 0;
    UINT32 txChanNum = BspGetTxChannel();
    T_PaTempSensorCfg destPaCfg = {0};
    T_PaTempSensorCfg comparePaCfg = {0};

    INPUT_POINTER_CHECK(para);

    if(bspChan >= min(txChanNum, RRU_PA_MAX_NUM))
    {
        dbgErr("%s bspChan=%d Exceed the ChanNum:%d\n", __FUNCTION__, bspChan, min(txChanNum, RRU_PA_MAX_NUM));
        return BSP_ERROR;
    }

    para->shareFlag = NO_SUPPORT;
    for(chan = 0; chan < RRU_PA_MAX_NUM; chan++)
    {
        para->paChannel[chan] = 0xff;
    }  //初始化赋值

    ret = BspGetPaTempSensorCfgInfo(bspChan, &destPaCfg);
    for(chan = 0; chan < min(txChanNum, RRU_PA_MAX_NUM); chan++)
    {
        ret |= BspGetPaTempSensorCfgInfo(chan, &comparePaCfg);
        if(BSP_OK != ret)
        {
            dbgErr("[%s]BspGetPaTempSensorCfgInfo is Failed\n", __FUNCTION__);
            return BSP_ERROR;
        }

        if((BSP_OK == BspEqualPaSensorCfg(&destPaCfg, &comparePaCfg))  && (bspChan != chan))
        {
            para->shareFlag = SUPPORT;
            para->paChannel[chan] = chan;
        }
        dbgInfoEx("%s:bspChan:%d,flag:0x%x, sameChan:0x%x\n", __FUNCTION__, bspChan, para->shareFlag, para->paChannel[chan]);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:u20f1l4486800ef141a00ae810bf03440f16b416 */

UINT32 BspSetLnaGainPara(T_DefLnaOffGain *pInfo, UINT32 num)
{
    s_pLnaOffGain  = pInfo;
    s_lnaGainParaNum = num;

    return BSP_OK;
}
/**************************************************************************
 * 函数名称:BspSetLna2GainPara
 * 功能描述: 针对外场两级底噪放，M192635 2.6G通道信号极化后，上行NI扫描规避
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
UINT32 BspSetLna2ByPassGain(UINT32 bspChan,INT32 Lna2ByPassGain)
{
    s_pLna2ByPassGain[bspChan] = Lna2ByPassGain;
    return BSP_OK;
}
/**************************************************************************
 * 函数名称:BspGetLna2GainPara
 * 功能描述: 针对外场两级底噪放，M192635 2.6G通道信号极化后，上行NI扫描规避
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           其它   执行失败
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10090699    创建
 **************************************************************************/
INT32 BspGetLna2ByPassGain(UINT32 bspChan)
{
	 INT32 Lna2ByPassGain = 0;
     Lna2ByPassGain = s_pLna2ByPassGain[bspChan] ;
     return Lna2ByPassGain;
}

#define THERMAL_NOISE_DBM    ((LONG)(-17400))

UINT32 BspGetLnaGain(UINT32 bspChan, INT32 rssiGain, INT32 *lnaGain)
{
    UINT32  lnaSta = 0;

    INPUT_POINTER_CHECK(lnaGain);

    if (NULL == s_pLnaOffGain)
    {
        *lnaGain = rssiGain;
        return BSP_OK;
    }

    lnaSta = BspGetLnaSwitch(bspChan);
    if (lnaSta == LNA_SWITCH_OFF)
    {
        /* 关LNA时的目标增益=ADC满量程映射-ADC噪声密度-NF-热噪声密度 */
        *lnaGain = s_pLnaOffGain->adcFullScalMap + s_pLnaOffGain->adcNoise - s_pLnaOffGain->nf - THERMAL_NOISE_DBM;
    }
    else
    {
        /* 打开LNA时的目标增益=离线表格上行链路增益*/
        *lnaGain = rssiGain;
    }
    dbgInfoEx("%s, bspChan=%u adcFullScalMap=%d,adcNoise=%d,nf=%d,lnaGain=%d,lnaSta=%u\n",
         __FUNCTION__, bspChan, s_pLnaOffGain->adcFullScalMap, s_pLnaOffGain->adcNoise, s_pLnaOffGain->nf, *lnaGain, lnaSta);

    return BSP_OK;
}

/*模拟检波电路电压转功率值 并查询对应基准温补点*/
UINT32 BspGetAnaLogGain(UINT16 usType, UINT16 index, UINT32 caliChn,UINT32 carrFreq,UINT32 adVolt, INT32 *plVal, INT32 *plPaTemp)
{
    TTxFwdAnalogCaliData *ptTxFwdAnaData = NULL;
    TTxRevAnalogCaliData *ptTxRevAnaData = NULL;
    UINT32 roundFreq = 0;
    UINT32 freqBand = 0;
    UINT32 freqStep = 0;
    INT32 powStep = 0;
    UINT32 recordIndex = 0;
    UINT32 startFreq = 0;
    UINT32 stopFreq= 0;
    INT32 startPow = 0;
    INT32 stopPow= 0;
    INT32 lCompVal = 0;
    INT32 *pTempVal = NULL;
    UINT32 nextIndex = 0;
    T_AnalogRecord *ptFreqTable = NULL;
    T_AnalogRecord *ptVoltTable = NULL;
    UINT32 loop0 = 0;
    UINT32 loop1 = 0;
    UINT32 freqNum = 0;   /*校准表中频点个数*/
    UINT32 powNum = 0;    /*校准表中功率点个数*/
    UINT32 *pRecordIndex = NULL;

    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(plVal);
    TBL_CHAN_VALID_CHECK(caliChn);
    switch (usType)
    {
        case TBL_TXFWD_ANALOG:
        {
            freqBand  = BspGetFreqBandNum(caliChn,TX, carrFreq);
            TBL_BAND_VALID_CHECK(freqBand);
            ptTxFwdAnaData = (TTxFwdAnalogCaliData *)_BspGetCalibData(TBL_KIND_OF_TXFWDANALOG,index);
            _TXFWDANALOGFILE_RF_LOADED_CHECK(ptTxFwdAnaData, caliChn);
            freqStep = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulRfStep[freqBand];
            powStep = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulPowerStep;
            ptFreqTable = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].patRfRecord[freqBand];
            startFreq = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulStartFreq[freqBand];
            stopFreq  = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulStopFreq[freqBand];
            startPow = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulPowerStart;
            stopPow  = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulPowerStop;
            break;
        }
        case TBL_TXREV_ANALOG:
        {
            freqBand  = BspGetFreqBandNum(caliChn,TX, carrFreq);
            TBL_BAND_VALID_CHECK(freqBand);
            ptTxRevAnaData = (TTxRevAnalogCaliData *)_BspGetCalibData(TBL_KIND_OF_TXREVANALOG,index);
            _TXREVANALOGFILE_RF_LOADED_CHECK(ptTxRevAnaData, caliChn);
            freqStep = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulRfStep[freqBand];
            powStep = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulPowerStep;
            ptFreqTable = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].patRfRecord[freqBand];
            startFreq = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulStartFreq[freqBand];
            stopFreq  = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulStopFreq[freqBand];
            startPow = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulPowerStart;
            stopPow  = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulPowerStop;
            break;
        }
        default:
        {
            break;
        }
    }
    _NUM_ZERO_CHECK(freqStep);
    _NUM_ZERO_CHECK(powStep);
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptFreqTable);
    dbgInfoEx("%d %d %d %d %d %d\n", stopFreq, startFreq, freqStep, stopPow, startPow, powStep);
    freqNum = (stopFreq - startFreq)/freqStep + 1;
    powNum = (stopPow - startPow)/powStep + 1;
    dbgInfoEx("freqNum %d powNum %d\n", freqNum, powNum);
    ptVoltTable = (T_AnalogRecord *)malloc(sizeof(T_AnalogRecord)*powNum);   /*一个频点不同电压值的数据*/
    _MODULE_UNITFUNC_COMPSFILE_POINTER_CHECK(ptVoltTable);
    pTempVal = malloc(sizeof(INT32)*freqNum);
    if(NULL == pTempVal)
    {
        free(ptVoltTable);
        return BSP_ERROR;
    }
    pRecordIndex = malloc(sizeof(UINT32)*freqNum);
    if(NULL == pRecordIndex)
    {
        free(ptVoltTable);
        free(pTempVal);
        return BSP_ERROR;
    }
    memset(pRecordIndex, 0, sizeof(UINT32)*freqNum);
    memset(pTempVal, 0, sizeof(UINT32)*freqNum);
    for(loop0 = 0; loop0 < freqNum; loop0++)
    {
        memset(ptVoltTable, 0, sizeof(T_AnalogRecord)*powNum);
        for(loop1 = 0; loop1 < powNum; loop1++)
        {
            memcpy_s(&ptVoltTable[loop1], sizeof(T_AnalogRecord), &ptFreqTable[loop0*powNum+loop1], sizeof(T_AnalogRecord));
            recordIndex = 0;
        }
        for(loop1 = 0; loop1 < powNum-1; loop1++)
        {
            if((ptVoltTable[loop1].lVoltage <= adVolt)&&(ptVoltTable[loop1+1].lVoltage > adVolt))
            {
                recordIndex = loop1;
                break;
            }
        }
        if(ptVoltTable[0].lVoltage > adVolt)
        {
            recordIndex = 0;   /*用0 1算斜率*/
        }
        if(ptVoltTable[powNum-1].lVoltage <= adVolt)
        {
            recordIndex = powNum-2;  /*用倒数2个算斜率*/
        }
        nextIndex = recordIndex + 1;
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        pTempVal[loop0] = _LINEAR_INSERT((INT32)adVolt, ptVoltTable[recordIndex].lVoltage, ptVoltTable[recordIndex].lPower,
                   ptVoltTable[nextIndex].lVoltage, ptVoltTable[nextIndex].lPower);
        pRecordIndex[loop0] = loop0*powNum + recordIndex; /*在原表中的index*/
        dbgInfoEx("freqloop0 %d pRecordIndex %d  pTempVal %d\n", loop0, pRecordIndex[loop0], pTempVal[loop0]);
        //coverity[cert_ctr50_cpp_violation:SUPPRESS]
        dbgInfoEx("first insert [%s] ulRecordIndex:%d,ulNextIndex:%d,adVal:%d,lVoltage1:%d, lPower1:%d, lVoltage2:%d, lPower2:%d\n",
                   __FUNCTION__, recordIndex, nextIndex, adVolt, ptVoltTable[recordIndex].lVoltage, ptVoltTable[recordIndex].lPower, ptVoltTable[nextIndex].lVoltage,ptVoltTable[nextIndex].lPower);
    }

    roundFreq = _BspFreqRound(carrFreq, startFreq, stopFreq, freqStep);
    recordIndex = (roundFreq - startFreq) / freqStep;
    if (recordIndex >= freqNum)
    {
        free(ptVoltTable);
        free(pTempVal);
        free(pRecordIndex);
        return BSP_ERROR;
    }
    nextIndex = (recordIndex == freqNum - 1) ? recordIndex : (recordIndex + 1);
    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    lCompVal = _LINEAR_INSERT((INT32)carrFreq, ptFreqTable[pRecordIndex[recordIndex]].lFreq, (INT32)pTempVal[recordIndex],
                    ptFreqTable[pRecordIndex[nextIndex]].lFreq, (INT32)pTempVal[nextIndex]);  /*carrFreq 有符号和无符号数计算 会强转计算出异常大值*/
    //coverity[cert_ctr50_cpp_violation:SUPPRESS]
    dbgInfoEx("second insert [%s] ulRecordIndex:%d,ulNextIndex:%d,ulCarrFreq:%d,lFreq1:%d,lCompVal1:%d,lFreq2:%d,lCompVal2:%d\n",
               __FUNCTION__, recordIndex, nextIndex, carrFreq, ptFreqTable[pRecordIndex[recordIndex]].lFreq, pTempVal[recordIndex], ptFreqTable[pRecordIndex[nextIndex]].lFreq,pTempVal[nextIndex]);
    *plVal = lCompVal;
    if(*plVal < 0)
    {
        *plVal = 0;  /*小于0要特殊处理  否者取指数再取对数 数据异常*/
    }
    *plPaTemp = ptFreqTable[pRecordIndex[recordIndex]].lPaTemp;
    dbgInfo("[%s]type:%d,ch:%d,freq:%d,adVolt:%d, gain:%d finalIndex %d plPaTemp %d \n",
                   __FUNCTION__, usType, caliChn, carrFreq, adVolt, lCompVal, pRecordIndex[recordIndex], *plPaTemp);
    free(ptVoltTable);
    free(pTempVal);
    free(pRecordIndex);
    return BSP_OK;
}

/*子端标量驻波检测 dsp发的是全带宽源  所以补偿也需要取全带宽频点取均值*/
UINT32 BspGetAverageAnaLogGain(UINT16 usType, UINT16 index, UINT32 caliChn,UINT32 adVolt, INT32 *plVal, INT32 *plPaTemp)
{
    UINT32 freq = 0;
    UINT32 freqBand = 0;
    UINT32 freqStep = 0;
    UINT32 startFreq = 0;
    UINT32 stopFreq= 0;
    TTxFwdAnalogCaliData *ptTxFwdAnaData = NULL;
    TTxRevAnalogCaliData *ptTxRevAnaData = NULL;
    UINT32 loop = 0;
    UINT32 freqNum = 0;
    UINT32 carrFreq = 0;
    INT32 tmpVal = 0;
    double tmpMw = 0.0;
    double totalVal = 0.0;
    UINT32 retVal = BSP_OK;

    if (BspGetRfChCenterFreq(caliChn, TX, &freq) != BSP_OK)
    {
        return BSP_ERROR;
    }
    switch (usType)
    {
        case TBL_TXFWD_ANALOG:
        {
            freqBand  = BspGetFreqBandNum(caliChn,TX, freq);
            TBL_BAND_VALID_CHECK(freqBand);
            ptTxFwdAnaData = (TTxFwdAnalogCaliData *)_BspGetCalibData(TBL_KIND_OF_TXFWDANALOG,index);
            _TXFWDANALOGFILE_RF_LOADED_CHECK(ptTxFwdAnaData, caliChn);
            freqStep = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulRfStep[freqBand];
            startFreq = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulStartFreq[freqBand];
            stopFreq  = ptTxFwdAnaData->atTxFwdAnalogCaliPath[caliChn].tHeader.aulStopFreq[freqBand];
            break;
        }
        case TBL_TXREV_ANALOG:
        {
            freqBand  = BspGetFreqBandNum(caliChn,TX, freq);
            TBL_BAND_VALID_CHECK(freqBand);
            ptTxRevAnaData = (TTxRevAnalogCaliData *)_BspGetCalibData(TBL_KIND_OF_TXREVANALOG,index);
            _TXREVANALOGFILE_RF_LOADED_CHECK(ptTxRevAnaData, caliChn);
            freqStep = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulRfStep[freqBand];
            startFreq = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulStartFreq[freqBand];
            stopFreq  = ptTxRevAnaData->atTxRevAnalogCaliPath[caliChn].tHeader.aulStopFreq[freqBand];
            break;
        }
        default:
        {
            break;
        }
    }
    if(0 == freqStep)
    {
        dbgInfoEx("%s:freq or pow step error!usType=%d,ulChan=%d\n", __FUNCTION__, usType, caliChn);
        return BSP_ERROR;
    }
    freqNum = (stopFreq - startFreq)/freqStep + 1;
    if((stopFreq == 0)||(startFreq == 0))
    {
        dbgErr("data invalid\n ");
        return BSP_ERROR;
    }
    for(loop = 0; loop < freqNum; loop++)
    {
        carrFreq = startFreq + loop*freqStep;
        retVal |= BspGetAnaLogGain(usType, index, caliChn, carrFreq, adVolt, &tmpVal, plPaTemp);
        tmpMw = pow(10.0,abs(tmpVal)*1.0/1000.0);
        totalVal += tmpMw;
        dbgInfoEx("%d %f",tmpVal,tmpMw);
    }
    if(totalVal < 0.01)
    {
        *plVal = 0;
    }
    else
    {
        *plVal = (INT32)1000.0*log10(abs((INT32)totalVal)/freqNum);
    }
    dbgInfo("\n %d totalVal %f freqNum %d\n", *plVal, totalVal, freqNum);

    return retVal;
}

/*利用模拟检波电路获取fwd和rev功率值*/
UINT32 BspGetSlavePowDbmGain(UINT32 bspChn, UINT32 dir, UINT32 type, UINT32 *pPowDbm)
{
    UINT32 adVal = 0;
    UINT32 retVal = BSP_OK;
    INT32 paTemp = 0;
    INT32 paTblTemp = 60;
    UINT32 slaveChn = 0;
    T_ChanRfTblBaseInfo baseInfo = {0};
    T_RfTblChanPara tmp = {0};
    UINT32 caliIndex = 0;
    UINT32 tblType = 0;
    INT32 tmpPow = 0;
    INT32 lPaTempGain = 0;
    INT32 lPaTempGainTbl = 0;
    UINT32 tmpChan = 0;
    UINT32 carrFreq = 0;
    UINT8 flag = 0;

    retVal = BspGetPortSlaveChnByBspChn(bspChn, TX, &slaveChn);   /*母端通道号转到子端通道号*/
    retVal |= BspGetSingleChanRfTblPara(bspChn, &tmp);
    if(BSP_OK != retVal)  /*旧机型没有这个功能 直接返回即可*/
    {
        dbgErr("chan %d BspGetChanRfTblBaseInfo failed\n ", bspChn);
        return BSP_ERROR;
    }
    retVal = BspGetRfDectorAdVolt(bspChn, dir, &adVal, &paTemp, &flag);  /*通道转子端号*/
    BspGetRecordCaliCarrFreq(bspChn,1,&carrFreq);
    dbgInfo("BspGetSlavePowDbmGain bspChn %d slaveChn %d dir %d(1-tx 2-prx) carrFreq %d adVal %d flag %d\n", bspChn, slaveChn, dir, carrFreq, adVal, flag);
    BspLog(LOG_LEVEL_0, "BspGetSlavePowDbmGain bspChn %d slaveChn %d dir %d(1-tx 2-prx) carrFreq %d adVal %d flag %d\n", bspChn, slaveChn, dir, carrFreq, adVal, flag);
#ifdef _BSP_WITH_WFS
    carrFreq = BspGetCarrFreq(TX, bspChn, 0);   /*和中试约定在载波0发源*/
#endif
    if((0 == carrFreq)||(0 != flag))   /*flag 为0 表示子端检测到告警 此时功率无效 通过BSP_ERROR 通知高层要特殊处理*/
    {
        dbgErr("bspChn %d carrFreq %d \n", bspChn, carrFreq);
        *pPowDbm = 0;     /*此时功率异常*/
        return BSP_ERROR;
    }
    if(BSP_OK != retVal)
    {
        dbgErr("chan %d BspGetRfDectorAdVal failed\n ", bspChn);
        BspLog(LOG_LEVEL_0, "chan %d BspGetRfDectorAdVal failed\n ", bspChn);
        return BSP_ERROR;
    }
    if(TX == dir)
    {
        tblType = TBL_TXFWD_ANALOG;
    }
    else
    {
        tblType = TBL_TXREV_ANALOG;
    }
    retVal = BspGetChanRfTblBaseInfo(bspChn, tblType, &baseInfo);  /*这里返回值不等于ok表示非拉远通道 没有这个表*/
    if(BSP_OK != retVal)  /*旧机型没有这个功能 直接返回即可*/
    {
        dbgInfoEx("chan %d BspGetChanRfTblBaseInfo failed\n ", bspChn);
        return BSP_ERROR;
    }
   if(TBL_CHAN_S_TPYE == (tmp.chanType&0xf))  /*拉远通道还需要把子端的校准表里的数据取出来  最后加到一起，非拉远通道直接返回即可*/
    {
        caliIndex = baseInfo.rfTblIndex[0];  /*0-子端侧校准表编号*/
        if(0 == type)  /*单点*/
        {
            retVal = BspGetAnaLogGain(tblType, caliIndex, slaveChn, carrFreq, adVal, &tmpPow, &paTblTemp);
            if(0 == tmpPow)
            {
               *pPowDbm = 0;     /*此时功率异常*/
               dbgInfo("[%s]tmpPow 0\n", __FUNCTION__);
               BspLog(LOG_LEVEL_0,"[%s]tmpPow 0\n", __FUNCTION__);
               return BSP_ERROR;
            }
        }
        else   /*均值 温补确认了不需要均值 */
        {
            retVal = BspGetAverageAnaLogGain(tblType, caliIndex, slaveChn, adVal, &tmpPow, &paTblTemp);
        }
        tmpChan = slaveChn|(caliIndex<<16);
        tmpChan = tmpChan|((tmp.chanType&0xf)<<24); /*是否拉远*/
        retVal |= _BspGetTempComps(tblType, E_TEMP_TYPE_PA, tmpChan, carrFreq, paTemp, &lPaTempGain);
        retVal |= _BspGetTempComps(tblType, E_TEMP_TYPE_PA, tmpChan, carrFreq, paTblTemp, &lPaTempGainTbl);
        if (retVal != BSP_OK)
        {
            dbgInfoEx("[%s] usType:%#x,chan:%d,freq:%d,get pa temp failed\n", __FUNCTION__,tblType, slaveChn, carrFreq);
        }
        dbgInfoEx("[%s]TempComps:(paTemp:%d)Gain:%d;(paTempTBL:%d)Gain:%d\n",
                   __FUNCTION__, paTemp,lPaTempGain,paTblTemp,lPaTempGainTbl);
        BspLog(LOG_LEVEL_0,"[%s]TempComps:(paTemp:%d)Gain:%d;(paTempTBL:%d)Gain:%d\n",
                __FUNCTION__, paTemp,lPaTempGain,paTblTemp,lPaTempGainTbl);
        lPaTempGain = lPaTempGain - lPaTempGainTbl;
        *pPowDbm = tmpPow + lPaTempGain;
        dbgInfo("BspGetSlavePowDbmGain pPowDbm %d = %d + %d \n",*pPowDbm, tmpPow, lPaTempGain);
        BspLog(LOG_LEVEL_0, "BspGetSlavePowDbmGain pPowDbm %d = %d + %d \n",*pPowDbm, tmpPow, lPaTempGain);
    }
   return retVal;
}

/*线缆时延测量结果保持*/
UINT32 BspSetRfCableDlyResult(UINT32 bspChn, UINT32 result)
{
    if(bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    g_ulRfDlyMeasResult[bspChn] = result;
    BspLog(LOG_LEVEL_0, "%s, bspChn %d, result %d\n", __FUNCTION__, bspChn, result);

    return BSP_OK;
}

/*线缆时延测量结果上报 用于增益有效性判断*/
UINT32 BspGetRfCableDlyResult(UINT32 bspChn, UINT32 *pResult)
{
    if(bspChn >= BSP_IC42_MAX_TX_CHAN_NUM)
    {
        return BSP_ERROR;
    }
    INPUT_POINTER_CHECK(pResult);
    *pResult = g_ulRfDlyMeasResult[bspChn];

    return BSP_OK;
}

/* Started by AICoder, pid:0fc05ff307z6574142ed0b89105b3b3ceea14eeb */
FUNC_GET_RADIO_MODE_BY_CHAN pGetRadioModeFunc = NULL;

UINT32 BspGetRadioModeCallBack(FUNC_GET_RADIO_MODE_BY_CHAN pfunc)
{
    pGetRadioModeFunc = pfunc;
    return BSP_OK;
}

UINT32 BspGetRadioModeByChan(UINT32 chan, UINT32 *pVal)
{
    INPUT_POINTER_CHECK(pVal);

    if(NULL != pGetRadioModeFunc)
    {
        return pGetRadioModeFunc(chan, pVal);
    }

    return BSP_OK;
}
/* Ended by AICoder, pid:0fc05ff307z6574142ed0b89105b3b3ceea14eeb */

/* Started by AICoder, pid:ma5996bc4976e87148ae086ee0eb2e55f1b82177 */
/**************************************************************************
 * 函数名称: BspGetBoardTempThre
 * 功能描述: 从离线文件BoardTempThresAlarm.txt获取温度门限，供app调用
 * 输入参数: 无
 * 输出参数: 无
 * 返 回 值: BSP_OK 执行成功
 *           BSP_ERROR  app会使用默认温度门限
 * 其它说明:
 * 修改日期       修改人            修改内容
 * ------------------------------------------------------------------------
 * 2015年12月17日 10258234    创建
 **************************************************************************/
UINT32 BspGetBoardTempThre(BoardTempThre *tempThre)
{
    T_BoardTempThresAlarmData *boardTempThresAlarm = NULL;
    UINT32 tblIndex = 0;
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(tempThre);
    boardTempThresAlarm = (T_BoardTempThresAlarmData *)_BspGetCalibData(TBL_KIND_OF_BOARDTEMPTHRESALARM,tblIndex);

    if(NULL == boardTempThresAlarm)
    {
        dbgInfo("%s, BoardTempThresAlarm.txt no exist!!!\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0, "%s, BoardTempThresAlarm.txt no exist!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }
    _BOARDTEMPTHRESALARMFILE_LOADED_CHECK(boardTempThresAlarm);

    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.closeMPaTempThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.closeDPaTempThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.recoverPaTempThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.closeMPaICTempThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.closeDPaICTempThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.recoverPaICTempThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.boardAlmReportThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.boardAlmRecoverThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.icAlmReportThres);
    retVal |= BspChkTempThresResult(boardTempThresAlarm->tHeader.icAlmRecoverThres);
    if(retVal == BSP_ERROR)
    {
        dbgInfo("%s, tempThres no in range!!!\n", __FUNCTION__);
        BspLog(LOG_LEVEL_0, "%s, tempThres no in range!!!\n", __FUNCTION__);
        return BSP_ERROR;
    }

    tempThre->closeMPaTempThres = boardTempThresAlarm->tHeader.closeMPaTempThres;
    tempThre->closeDPaTempThres = boardTempThresAlarm->tHeader.closeDPaTempThres;
    tempThre->recoverPaTempThres = boardTempThresAlarm->tHeader.recoverPaTempThres;
    tempThre->closeMPaICTempThres = boardTempThresAlarm->tHeader.closeMPaICTempThres;
    tempThre->closeDPaICTempThres = boardTempThresAlarm->tHeader.closeDPaICTempThres;
    tempThre->recoverPaICTempThres = boardTempThresAlarm->tHeader.recoverPaICTempThres;
    tempThre->boardAlmReportThres = boardTempThresAlarm->tHeader.boardAlmReportThres;
    tempThre->boardAlmRecoverThres = boardTempThresAlarm->tHeader.boardAlmRecoverThres;
    tempThre->icAlmReportThres = boardTempThresAlarm->tHeader.icAlmReportThres;
    tempThre->icAlmRecoverThres = boardTempThresAlarm->tHeader.icAlmRecoverThres;

    return BSP_OK;
}
/* Ended by AICoder, pid:ma5996bc4976e87148ae086ee0eb2e55f1b82177 */

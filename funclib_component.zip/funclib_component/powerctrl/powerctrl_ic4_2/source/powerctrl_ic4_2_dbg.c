/*****************************************************************************
* 版权所有(C) 2021-2031, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 本文件主要提供功率检测维测打印接口
* 文件名称 : powerctrl_ic4_dbg.c
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者   : 10288704
* 创建日期 : 2021-05-10 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10288704
* 修改日戳: 2021-05-10 14:45:34
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#include "powerctrl_ic4_2_dbg.h"
#include "exprn.h"
#include "funccommon_carrmap.h"
#include "freqcfgcommon.h"
#include "devdrv_att.h"
#include "chnmap_a.h"
#include "powerctrl_comps_ic4_2.h"
#include "funccommon_a.h"

#define POW_HELP_LEN (50)

UINT8 g_powHelpPrint[][POW_HELP_LEN] =
{
    "==== funclib ====",
    "bbtssi",
    "powshow",
    "dbfs",
    "rssi(type) : 0-short frame 1-long frame",
    /*"bbpctssi",
    "pcpowshow",*/
    "dbgshowrssipowinfo",
    "dbgshowtssipowdbfs",
    "dbgshowtxiftssi",
    "dbgshowfwdcpiftssi",
    "dbgshowreviftssi",
    "dbgshowrevcpiftssi",
    /* "dbgshowpctssipow",
    "dbgshowpcrevtssipow", */
    "dbgshowtxbeamgaincomps",
    "dbgshowprxgaincomps",
    "dbgshowcombingain",
    "dbgshowprxatt",
    "dbgshowrssiifpow",
    "",
/*     "==== DPDICHAL ====",
    "HalBbTssiInfo(difChan, carrNo, radioMode)",
    "HalIfTssiInfo(difChan)",
    "HalBbTssiRptCalPow(difChan, carrNo, radioMode)",
    "HalIfTssiRptCalPow(difChan)",
    "HalRssiCalRptPow(difChan, carrNo, radioMode)",
    "HalTssiCtrlGenarate",
    "HalRssiCtrlTdmSelect(difChan, carrNo, radioMode)",
    "HalRssiCtrlGenarate",
    "HalTssiDelay",
    "HalTssiCh2BandEnCfg(difChan)",
    "HalTssiCfrBlkChSelCfg(difChan)",
    "HalRssiVgaBypass",
    "HalRssiVgaNotByPass",
    "HalRssiFrameNumBypass",
    "HalRssiFrameNumNotBypass", */
};

UINT32 destgaintest(UINT32 fwddir, UINT32 dir, UINT32 startChan, UINT32 endChan, INT32 destgainvalue)
{
    UINT32 loop = 0;
    UINT32 ret = BSP_OK;
    for(loop = startChan; loop < endChan; loop ++)
    {
        ret = BspSetDestGain(fwddir, dir, loop, destgainvalue);
    }
    return ret;
}
/*****************************************************************************
 *  函数名称   : bbtssi()
 *  功能描述   : 分载波tssi打印
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
void bbtssi(void)
{
    INT32 tTssiPowDbm = 0;
    INT32 tTssiPowDbfs = 0;
    UINT32 carrMode = 0;
    UINT32 bspChn = 0;
    UINT32 carrIndex = 0;
    UINT32 carrNo = 0;
    UINT32 chnNum = BspGetTxChannel();
    UINT32 retVal = BSP_OK;
    T_ChanRfCfgPara *pRfCfg = NULL;

    RedirPrintf("%s:\n",__FUNCTION__);
    for(bspChn = 0; bspChn < chnNum; bspChn++)
    {
        RedirPrintf("************chan %d***************\n",bspChn);
        pRfCfg = GetRfCfgPara(bspChn, TX);
        if (NULL == pRfCfg)
        {
            dbgErr("[%s]bspChn'%d pRfCfg Get Error!\n",__FUNCTION__, bspChn);
            continue;
        }
        if (pRfCfg->para.carrNum > BSP_MAX_CARR_NUM)
        {
            dbgErr("maxCarrNum is %d \n",pRfCfg->para.carrNum);
            continue;
        }

        for(carrIndex = 0; carrIndex < pRfCfg->para.carrNum; carrIndex++)
        {
            carrMode = pRfCfg->para.carrInfo[carrIndex].radioMode;
            carrNo =  pRfCfg->para.carrInfo[carrIndex].carrNo;
            retVal = BspGetTssiPowInfo(bspChn, carrMode, carrNo, &tTssiPowDbm, &tTssiPowDbfs);
            if(retVal == BSP_OK)
            {
                RedirPrintf("chan %2d | carr %d | mode 0x%04x | dbfs %6d | dbm %6d\n",bspChn,carrNo,carrMode,tTssiPowDbfs,tTssiPowDbm);
            }
        }
    }
}

/* Started by AICoder, pid:2ea8cc32fdb147e09f307e5e140f7688 */
/*从原powshow接口抽出驻波值判断打印接口，降低圈复杂度*/
VOID BspPrintVswrVal(UINT32 scalVal, UINT32 vector)
{
    if(BSP_INVALID_VALUE == scalVal || 0 == scalVal)
        dbgInfo("ScalarVswr=Invalid\t");
    else
        dbgInfo("ScalarVswr=%8.6f\t",scalVal/1000000.0);

    if(BSP_INVALID_VALUE == vector || 0 == vector)
        dbgInfo("VectorVswr=Invalid\n");
    else
        dbgInfo("VectorVswr=%8.6f\n",vector/1000000.0);
}
/* Ended by AICoder, pid:2ea8cc32fdb147e09f307e5e140f7688 */

/*****************************************************************************
 *  函数名称   : powshow()
 *  功能描述   : 功率打印，包含dbfs以及dbm
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/

/* Started by AICoder, pid:64c893032cfc42ba87387dcb94484f33 */
void powshow(void)
{
    UINT32 bspChn = 0;
    UINT32 ulBand = 0;
    INT32 iTmpPow[6] = {0};
    UINT32 scalVal = BSP_INVALID_VALUE;
    UINT32 vector  = BSP_INVALID_VALUE;
    T_HwInfo* pHwInfo = NULL;
    UINT32 ulFreqBandNum = 0;
    UINT32 ulBandLoop = 0;

    if(0 == BspGetBandVswrFlag())
    {
        for (bspChn = 0; bspChn < BspGetTxChannel(); bspChn++)
        {
            BspGetTxIfTssi(bspChn, ulBand, &iTmpPow[0]);
            BspGetFwdCpIfTssi(bspChn, ulBand, &iTmpPow[1]);
            BspGetRevIfTssi(bspChn, ulBand, &iTmpPow[2]);
            BspGetRevCpIfTssi(bspChn, ulBand, &iTmpPow[3]);

            BspGetScalarVswr(bspChn,&scalVal);
            BspGetVectorVswrVal(bspChn, ulBand, &vector);
            RedirPrintf("CHAN %d:TssiFwd = %d\tFWD = %d\tTssiRev = %d\tREV = %d\t",bspChn,iTmpPow[0],iTmpPow[1],iTmpPow[2],iTmpPow[3]);
            BspPrintVswrVal(scalVal, vector);
        }
        return;
    }

    if((pHwInfo = BspGetBoardPropInfo()) == NULL)
    {
        RedirPrintf("[%s]Get BoardPropInfo Err\n", __FUNCTION__);
        return ;
    }

    for (bspChn = 0; bspChn < BspGetTxChannel(); bspChn++)
    {
        ulFreqBandNum = pHwInfo->BoardInfo.tFreqStartEndTx[bspChn].ulBandNum;
        for (ulBandLoop = 0; ulBandLoop < ulFreqBandNum; ulBandLoop++)
        {
            BspGetTxIfTssi(bspChn, ulBand, &iTmpPow[0]);
            BspGetFwdCpIfTssi(bspChn, ulBand, &iTmpPow[1]);
            BspGetRevIfTssi(bspChn, ulBand, &iTmpPow[2]);
            BspGetRevCpIfTssi(bspChn, ulBand, &iTmpPow[3]);

            BspGetScalarVswr(bspChn, &scalVal);
            BspGetVectorVswrVal(bspChn, ulBandLoop, &vector);
            RedirPrintf("CHAN %d band %d:TssiFwd = %d FWD = %d TssiRev = %d REV = %d ",bspChn,ulBandLoop,iTmpPow[0],iTmpPow[1],iTmpPow[2],iTmpPow[3]);
            BspPrintVswrVal(scalVal, vector);
        }
    }
}
/* Ended by AICoder, pid:64c893032cfc42ba87387dcb94484f33 */

/*****************************************************************************
 *  函数名称   : BspGetDbfs()
 *  功能描述   : 数字功率打印，包含传统功率检测以及PC功率检测
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值   :
 *  其它说明   :dbfs的维测接口用于获取实时的功率信息
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID BspGetDbfs(T_TxPow *pDbfs, UINT32 num)
{
    UINT32 ulBand = 0;
    UINT32 bspChn = 0;
    UINT32 maxChn = min(num, BspGetTxChannel());
    T_TxPow tPowDbfs = {0};
    ePowType powType = BSP_TSSI_FWD_INFO;

    for (bspChn = 0; bspChn < maxChn; bspChn++)
    {
       GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
       pDbfs->tFwdPow.ifTssiPow = tPowDbfs.tFwdPow.ifTssiPow;
       pDbfs->tFwdPow.fbPow = tPowDbfs.tFwdPow.fbPow;
       pDbfs->tRevPow.ifTssiPow = tPowDbfs.tRevPow.ifTssiPow;
       pDbfs->tRevPow.fbPow = tPowDbfs.tRevPow.fbPow;
       pDbfs->isPowValid = tPowDbfs.isPowValid;
       pDbfs++;
    }
}

/*****************************************************************************
 *  函数名称   : dbfs()
 *  功能描述   : 数字功率打印，包含传统功率检测以及PC功率检测
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
void dbfs(void)
{
    UINT32 retVal = 0;
    UINT32 ulBand = 0;
    UINT32 bspChn = 0;
    ePowType powType = BSP_TSSI_FWD_INFO;
    T_TxPow tPowDbfs = {0};

    for (bspChn = 0; bspChn < BspGetTxChannel(); bspChn++)
    {
        retVal |= GetTssiPowDbfs(bspChn, ulBand, powType, &tPowDbfs);
        RedirPrintf("Chan %2d:FwdTssi=%6d | FbFwd=%6d | RevTssi=%6d | FbRev=%6d | isPowValid=%6d\n",\
                bspChn, tPowDbfs.tFwdPow.ifTssiPow, tPowDbfs.tFwdPow.fbPow\
                ,tPowDbfs.tRevPow.ifTssiPow, tPowDbfs.tRevPow.fbPow\
                ,tPowDbfs.isPowValid);
    }
}
#if 0
/*****************************************************************************
 *  函数名称   : vswrshow()
 *  功能描述   : 驻波信息打印
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
static void vswrshow(void)
{
    UINT32 retVal = 0;
    UINT32 chanNo = 0;
    INT32 fwdDbfs = 0;
    INT32 fwdDbm = 0;
    INT32 revDbfs = 0;
    INT32 revDbm = 0;
    UINT32 vswrVal = 0;
    INT32 FwdGate[2] = {0};
    INT32 RevGate[2] = {0};
    UINT32 fwdUpVswrType = E_FWD_GATE_UP;
    UINT32 fwdDownVswrType = E_FWD_GATE_DOWN;
    UINT32 revUpVswrType = E_REV_GATE_UP;

    dbgInfo("Chan  Fwd(dbfs)  Fwd(dbm)  Rev(dbfs)  Rev(dbm)  FwdHGate  FwdLGate  RevHGate  RevLGate  VswrValue \n");

    for (chanNo = 0; chanNo < BspGetTxChannel(); chanNo++)
    {
        retVal = GetAcVswrFwdInfo(chanNo, &fwdDbfs, &fwdDbm);
        if (retVal != BSP_OK)
        {
            dbgErr("[%s]chanNo = %d, GetAcVswrFwdInfo Error!\n",__FUNCTION__,chanNo);
            continue;
        }
        retVal = GetAcVswrRevInfo(chanNo, &revDbfs, &revDbm);
        if (retVal != BSP_OK)
        {
            dbgErr("[%s]chanNo = %d, GetAcVswrRevInfo Error!\n",__FUNCTION__,chanNo);
            continue;
        }
        retVal = BspGetAcVswr(chanNo, &vswrVal);
        if (retVal != BSP_OK)
        {
            dbgErr("[%s]chanNo = %d, BspGetAcVswr Error!\n",__FUNCTION__,chanNo);
            continue;
        }
		//coverity[cert_dcl37_c_violation:SUPPRESS]
		//coverity[cert_dcl40_c_violation:SUPPRESS]
        FwdGate[0] = _BspGetAcVswrGate(chanNo, fwdUpVswrType);   //fwd上限
        FwdGate[1] = _BspGetAcVswrGate(chanNo, fwdDownVswrType); //fwd下限
        RevGate[0] = _BspGetAcVswrGate(chanNo, revUpVswrType);   //rev上限
        RevGate[1] = 0;//rev功率下限不需要判断
        dbgInfo("%2d %10d %10d %10d %10d %9d %9d %9d %9d %8d\n",\
                chanNo,fwdDbfs,fwdDbm,revDbfs,revDbm,FwdGate[0],FwdGate[1],RevGate[0],RevGate[1],vswrVal);
    }
}
#endif
/*****************************************************************************
 *  函数名称   : BspGetRssiInfo()
 *  功能描述   : RSSI功率上报
 *  输入参数   :  rssiType  -- 检测模式：0--BSP_RSSI_SHORT_FRAME    1--BSP_RSSI_LONG_FRAME
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
/*rssiType：0--BSP_HALADAPT_RSSI_SHORT_FRAME  1--BSP_HALADAPT_RSSI_LONG_FRAME*/
UINT32 BspGetRssiInfo(UINT32 rssiType, T_RssiInfo *prssi, UINT32 *totalcarrNum, UINT32 *totalchnNum)
{
    UINT32 chnLoop;
    UINT32 carr;
    INT32  rssiDbm = 0;
    INT32  rssiDbfs =0;
    UINT32 ulRadioNum = 0;
    UINT32 ulRadioLoop = 0;
    UINT32 carrNum = 8;  /*NrRssiDbm、NrRssiDbfs 最大一维空间为8 BSP_MAX_CARR_NUM*/
    UINT32 chnNum = min(BspGetRxLogicChanNum(),32);
    UINT32 uMode  = BspGetRadioStandard();
    UINT32 uRet = BSP_OK;
    UINT32 slotNo = 0;

    INPUT_POINTER_CHECK(prssi);
    INPUT_POINTER_CHECK(totalcarrNum);
    INPUT_POINTER_CHECK(totalchnNum);

    struct sRadio
    {
        UINT32 uMode;
        CHAR *pcModeString;
    }atRadio[] =
    {
        {BSP_RADIO_STANDARD_LTE_TDD, "LTE_TDD"},
        {BSP_RADIO_STANDARD_LTE_FDD, "LTE_FDD"},
        {BSP_RADIO_STANDARD_UMTS,    "UMTS"  },
        {BSP_RADIO_STANDARD_GSM,     "GSM"   },
        {BSP_RADIO_STANDARD_NB_IOT,  "NB-IOT"},
        {BSP_RADIO_STANDARD_5G,      "5G-NR-TDD" },
        {BSP_RADIO_STANDARD_FDD_5G,      "5G-NR-FDD" },
    };
    ulRadioNum = NELEMENTS(atRadio);
    *totalchnNum = chnNum;

    for (ulRadioLoop = 0; ulRadioLoop < ulRadioNum; ulRadioLoop++)
    {
        if (0 == (uMode & atRadio[ulRadioLoop].uMode))
        {
            continue;
        }
        *totalcarrNum = carrNum;
        dbgInfoEx("\n-----------------%s CarrSum'%d ChnlSum'%d RSSI---------------\n",atRadio[ulRadioLoop].pcModeString, carrNum, chnNum);
        for (carr = 0; carr < carrNum; carr++)
        {
            for (chnLoop = 0; chnLoop < chnNum; chnLoop++)
            {
                rssiDbm  = 0;
                rssiDbfs = 0;
                uRet = BspGetRssiPowInfoByMode(chnLoop, carr, atRadio[ulRadioLoop].uMode, rssiType,slotNo, &rssiDbm, &rssiDbfs);
                if (atRadio[ulRadioLoop].uMode == BSP_RADIO_STANDARD_5G || atRadio[ulRadioLoop].uMode == BSP_RADIO_STANDARD_FDD_5G)
                {
                    prssi->NrRssiDbm[carr][chnLoop] = rssiDbm;
                    prssi->NrRssiDbfs[carr][chnLoop] = rssiDbfs;
                }
                if((atRadio[ulRadioLoop].uMode == BSP_RADIO_STANDARD_LTE_TDD) || (atRadio[ulRadioLoop].uMode == BSP_RADIO_STANDARD_LTE_FDD))
                {
                    prssi->LteRssiDbfs[carr][chnLoop] = rssiDbfs;
                    prssi->LteRssiDbm[carr][chnLoop] = rssiDbm;
                }
            }
        }
    }
    return uRet;
}

static BOOL IsCarrCfgVaild(UINT32 localRadioMode, UINT32 carrRadioMode, UINT32 carrBw, UINT32 carrNo)
{
    if(carrRadioMode != localRadioMode)
    {
        return FALSE;
    }

    if (BspCarrBwIsTwoSegAntiInterf(carrRadioMode, carrBw) == BSP_OK)
    {
        if (carrNo == BspGetVirtualCarrNo())
        {
            return FALSE;
        }
    }

    return TRUE;
}
/*****************************************************************************
 *  函数名称   : rssi()
 *  功能描述   : RSSI功率上报
 *  输入参数   :  rssiType  -- 检测模式：0--BSP_RSSI_SHORT_FRAME    1--BSP_RSSI_LONG_FRAME
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID rssi(UINT32 rssiType)
{
    UINT32 chnLoop = 0;
    UINT32 carr = 0;
    INT32 rssiDbm = 0;
    INT32 rssiDbfs =0;
    UINT32 ulRadioNum = 0;
    UINT32 ulRadioLoop = 0;
    CHAR *pstrDbfs = NULL;
    CHAR *pstrDbm = NULL;
    CHAR strDbfsTemp[50] = {0};
    CHAR strDbmTemp[50] = {0};
    UINT32 lendbfs = 0;
    UINT32 lendbm = 0;
    UINT32 carrNum = BSP_MAX_CARR_NUM;
    UINT32 carrBw = 0;
    UINT32 chnNum = BspGetRxLogicChanNum();
    UINT32 uMode  = BspGetRadioStandard(); /*根据整机制式支持来获取底层rssi功率*/
    CHAR *pstrDbfsBuf = NULL;
    CHAR *pstrDbmBuf = NULL;
    T_ChanRfCfgPara *pRfCfg = NULL;
    int snpRet = 0;
    UINT32 rfCarrNo = 0;
    UINT32 slotLoop = 0;
    struct sRadio
    {
        UINT32 uMode;
        CHAR *pcModeString;
        UINT32 slotNum;
    }atRadio[] =
    {
        {BSP_RADIO_STANDARD_LTE_TDD, "LTE_TDD",1},
        {BSP_RADIO_STANDARD_LTE_FDD, "LTE_FDD",1},
        {BSP_RADIO_STANDARD_5G,      "5G-NR-TDD",1},
        {BSP_RADIO_STANDARD_FDD_5G,  "5G-NR-FDD",1},
        {BSP_RADIO_STANDARD_UMTS,    "UMTS",1},
        {BSP_RADIO_STANDARD_NB_IOT,  "NB-IOT",1},
        {BSP_RADIO_STANDARD_AIOT,    "AIOT",1},
        {BSP_RADIO_STANDARD_GSM,     "GSM",FUNCLIB_GSM_MAX_SLOT_NUM},
    };

    ulRadioNum = NELEMENTS(atRadio);

    pstrDbfsBuf = malloc(sizeof(CHAR) * RSSI_BUF_SIZE);
    if (pstrDbfsBuf == NULL)
    {
        dbgErr("%s: pstrDbfsBuf malloc failed \n",__FUNCTION__);
        return ;
    }

    pstrDbmBuf = malloc(sizeof(CHAR) * RSSI_BUF_SIZE);
    if (pstrDbmBuf == NULL)
    {
        dbgErr("%s: pstrDbmBuf malloc failed \n",__FUNCTION__);
        free(pstrDbfsBuf);
        return ;
    }

    for (ulRadioLoop = 0; ulRadioLoop < ulRadioNum; ulRadioLoop++)
    {
        if (0 == (uMode & atRadio[ulRadioLoop].uMode))
        {
            continue;
        }
        memset_s(pstrDbfsBuf, sizeof(CHAR) * RSSI_BUF_SIZE, 0, sizeof(CHAR) * RSSI_BUF_SIZE);
        memset_s(pstrDbmBuf, sizeof(CHAR) * RSSI_BUF_SIZE, 0, sizeof(CHAR) * RSSI_BUF_SIZE);

        lendbfs  = 0;
        lendbm   = 0;
        pstrDbfs = pstrDbfsBuf;
        pstrDbm  = pstrDbmBuf;
        RedirPrintf("\n-----------------%s ChnlSum'%d RSSI---------------\n",
                atRadio[ulRadioLoop].pcModeString, chnNum);

        for (carr = 0; carr < carrNum; carr++)
        {

            for (chnLoop = 0; chnLoop < chnNum; chnLoop++)
            {
                pRfCfg = NULL;
                pRfCfg = GetRfCfgPara(chnLoop,RX);
                if (NULL == pRfCfg)
                {
                    dbgInfoEx("[%s]BspChan'%d pRfCfg Get Error!\n",__FUNCTION__, chnLoop);
                    continue;
                }
                if(carr >= pRfCfg->para.carrNum)
                {
                    continue;
                }
                carrBw = pRfCfg->para.carrInfo[carr].bandWidth;
                rfCarrNo = pRfCfg->para.carrInfo[carr].carrNo;
                if(IsCarrCfgVaild(atRadio[ulRadioLoop].uMode, pRfCfg->para.carrInfo[carr].radioMode, carrBw, rfCarrNo) == FALSE)
                {
                    continue;
                }
                for(slotLoop = 0; slotLoop < atRadio[ulRadioLoop].slotNum; slotLoop++)
                {
                    rssiDbm  = 0;
                    rssiDbfs = 0;
                    BspGetRssiPowInfoByMode(chnLoop, rfCarrNo,atRadio[ulRadioLoop].uMode, slotLoop, rssiType, &rssiDbm,&rssiDbfs);

                    if (lendbfs >= RSSI_BUF_SIZE)
                    {
                        dbgErr("%s>>Error! StrLen Over; DbfsLen(0~%d)= %d\n",
                               __FUNCTION__, RSSI_BUF_SIZE - 1, lendbfs);
                        continue;
                    }
                    if (lendbm >= RSSI_BUF_SIZE)
                    {
                        dbgErr("%s>>Error! StrLen Over; DbmLen(0~%d)= %d\n",
                               __FUNCTION__, RSSI_BUF_SIZE - 1, lendbm);
                        continue;
                    }
                    if(atRadio[ulRadioLoop].uMode != BSP_RADIO_STANDARD_GSM)
                    {
                        snpRet = snprintf_s(strDbfsTemp, sizeof(strDbfsTemp), "C%dA%d:%d %s", rfCarrNo, chnLoop,
                             rssiDbfs, (chnLoop == chnNum - 1) ? "\n" : "");
                        SNPRINTF_S_CHECK(snpRet, sizeof(strDbfsTemp));

                        snpRet = snprintf_s(pstrDbfs, RSSI_BUF_SIZE - lendbfs, "%s", strDbfsTemp);
                        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE - lendbfs);

                        snpRet = snprintf_s(strDbmTemp, sizeof(strDbmTemp), "C%dA%d:%d %s", rfCarrNo, chnLoop,
                             rssiDbm, (chnLoop == chnNum - 1) ? "\n" : "");
                        SNPRINTF_S_CHECK(snpRet, sizeof(strDbmTemp));

                        snpRet = snprintf_s(pstrDbm, RSSI_BUF_SIZE - lendbm, "%s", strDbmTemp);
                        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE - lendbm);
                    }
                    else
                    {
                        snpRet = snprintf_s(strDbfsTemp, sizeof(strDbfsTemp), "C%dS%dA%d:%d %s", rfCarrNo,slotLoop,chnLoop,
                             rssiDbfs, (slotLoop == (FUNCLIB_GSM_MAX_SLOT_NUM-1)) ? "\n" : "");
                        SNPRINTF_S_CHECK(snpRet, sizeof(strDbfsTemp));

                        snpRet = snprintf_s(pstrDbfs, RSSI_BUF_SIZE - lendbfs, "%s", strDbfsTemp);
                        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE - lendbfs);

                        snpRet = snprintf_s(strDbmTemp, sizeof(strDbmTemp), "C%dS%dA%d:%d %s", rfCarrNo, slotLoop, chnLoop,
                             rssiDbm, (slotLoop == (FUNCLIB_GSM_MAX_SLOT_NUM-1)) ? "\n" : "");
                        SNPRINTF_S_CHECK(snpRet, sizeof(strDbmTemp));

                        snpRet = snprintf_s(pstrDbm, RSSI_BUF_SIZE - lendbm, "%s", strDbmTemp);
                        SNPRINTF_S_CHECK(snpRet,RSSI_BUF_SIZE - lendbm);
                    }

                    pstrDbfs += strnlen_s(strDbfsTemp,50);
                    lendbfs  += strnlen_s(strDbfsTemp,50);

                    pstrDbm += strnlen_s(strDbmTemp,50);
                    lendbm  += strnlen_s(strDbmTemp,50);
                }

            }
        }
        RedirPrintf("dbfs: \n%s\n",pstrDbfsBuf);
        RedirPrintf("dbm : \n%s\n",pstrDbmBuf);
    }

    free(pstrDbfsBuf);
    free(pstrDbmBuf);
}
#if 0
/*****************************************************************************
 *  函数名称   : pcpowshow()
 *  功能描述   : PC功率检测数字及模拟功率打印
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID pcpowshow(VOID)
{
    UINT32 bspChn = 0;
    UINT32 ulBand = 0;
    INT32 iTmpPow[4] = {0};
    ePowType powtype = BSP_PC_TSSI_FWD_INFO;
    T_TxPow tPowDbfs = {0};

    dbgInfo("Chan FwdTssi(dbfs) FwdTssi(dbm) FwdFb(dbfs) FwdFb(dbm) RevTssi(dbfs) RevTssi(dbm) RevFb(dbfs) RevFb(dbm) valid\n");
    for (bspChn = 0; bspChn < BspGetTxChannel(); bspChn++)
    {
        GetTssiPowDbfs(bspChn, ulBand, powtype, &tPowDbfs);
        BspGetPcTssiPow(bspChn, ulBand, &iTmpPow[0]);
        BspGetPcFwdPow(bspChn, ulBand, &iTmpPow[1]);
        BspGetPcRevTssiPow(bspChn, ulBand, &iTmpPow[2]);
        BspGetPcRevPow(bspChn, ulBand, &iTmpPow[3]);
        dbgInfo("%2d    %6d        %6d      %6d      %6d       %6d       %6d      %6d      %6d       %s\n",\
                bspChn,tPowDbfs.tFwdPow.ifTssiPow, iTmpPow[0],tPowDbfs.tFwdPow.fbPow,iTmpPow[1],\
                tPowDbfs.tRevPow.ifTssiPow,iTmpPow[2], tPowDbfs.tRevPow.fbPow,iTmpPow[3],(tPowDbfs.isPowValid==0)?"OK":"ERR");
    }
}

/*****************************************************************************
 *  函数名称   : pcpowshow()
 *  功能描述   : PC功率检测分载波功率打印
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID bbpctssi(UINT32 carrMode)
{
    UINT32 bspChn = 0;
    UINT32 bspCarrNo = 0;
    UINT32 carrNum = BspGetMaxCarrNum(carrMode);
    UINT32 chnNum = BspGetTxChannel();
    UINT32 retVal = BSP_OK;
    T_TxDbfsDbmPow *txDbfsDbmPow = NULL;

    dbgInfo("%s:\n",__FUNCTION__);
    txDbfsDbmPow = (T_TxDbfsDbmPow *)malloc(sizeof(T_TxDbfsDbmPow));
    if(txDbfsDbmPow == NULL)
    {
        dbgErr("%s malloc txDbfsDbmPow error.\n",__FUNCTION__);
        return;
    }

    for(bspChn = 0; bspChn < chnNum; bspChn++)
    {
        retVal = BspGetCarrNumByBspChn(TX, bspChn, &carrNum);
        if(retVal != BSP_OK)
        {
            dbgErr("%s bspChn %d get carrNum is error.\n",__FUNCTION__,bspChn);
            continue;
        }
        for(bspCarrNo = 0; bspCarrNo < carrNum; bspCarrNo++)
        {
            retVal = BspGetPcBbTssiTcpwPow(bspChn, carrMode, bspCarrNo, txDbfsDbmPow);/*0.01db*/
            if(retVal == BSP_OK)
            {
                dbgInfo("Chan %2d | carr %d : PCFwdTssi=%6d | PCFwdTssiDbm=%6d | PCFbFwd=%6d | PCFbFwdDbm=%6d\n",\
                    bspChn, bspCarrNo, txDbfsDbmPow->iFwdTssi,txDbfsDbmPow->iFwdTssidbm,txDbfsDbmPow->iFbFwd,
                    txDbfsDbmPow->iFwddbm);
            }
        }
    }
    free(txDbfsDbmPow);
}
#endif
/*****************************************************************************
 *  函数名称   : dbgshowrssipowinfo()
 *  功能描述   : RSSI底层HAL上报功率维测打印
 *  输入参数   : bspChn     -- BSP通道号
 *            bspCarrNo -- 载波号
 *            carrMode  -- 载波制式
 *            rssiType  -- 检测模式：0--BSP_RSSI_SHORT_FRAME    1--BSP_RSSI_LONG_FRAME
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowrssipowinfo(UINT32 bspChn, UINT32 bspCarrNo, UINT32 carrMode, UINT32 slotNo, UINT32 rssiType)
{
    INT32 rssiDbm = 0;
    INT32 rssiDbfs =0;
    
    BspGetRssiPowInfoByMode(bspChn, bspCarrNo, carrMode, slotNo, rssiType, &rssiDbm, &rssiDbfs);

    dbgInfo("[rssi pow info] chn : %d  carrNo : %d  carrMode : %d  rssiType : %d  rssiDbm : %d  rssiDbfs : %d\n",bspChn,bspCarrNo,carrMode,rssiType,rssiDbm,rssiDbfs);
}

/*****************************************************************************
 *  函数名称   : bdgshowtssipowdbfs()
 *  功能描述   : FWD以及REV时间片数字功率打印
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowtssipowdbfs(void)
{
    UINT32 chn = 0;
    T_TxPow tPowDbfs = {0};
    UINT32 bspChn = BspGetTxChannel();

    for (chn = 0; chn<bspChn; chn++)
    {
        GetTssiPowDbfs(chn, 0, BSP_TSSI_FWD_INFO, &tPowDbfs);
        dbgInfo("TOTALCHAN = %d CHAN %d: FwdTssi(dbfs) = %d FwdFb(dbfs) = %d RevTssi(dbfs) = %d RevFb(dbfs) = %d\n", bspChn,chn,\
            tPowDbfs.tFwdPow.ifTssiPow,tPowDbfs.tFwdPow.fbPow,tPowDbfs.tRevPow.ifTssiPow,tPowDbfs.tRevPow.fbPow);
    }
}

/*****************************************************************************
 *  函数名称   : bdgshowtxiftssi()
 *  功能描述   : FWD时间片TSSI模拟功率
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowtxiftssi(void)
{
    UINT32 chn = 0;
    INT32 iTmpPow[1] = {0};
    UINT32 bspChn = BspGetTxChannel();

    for (chn = 0; chn<bspChn; chn++)
    {
        BspGetTxIfTssi(chn, 0, &iTmpPow[0]);
        dbgInfo("TOTALCHAN = %d CHAN %d: FwdTssi(dbm) = %d\n", bspChn,chn,iTmpPow[0]);
    }
}

/*****************************************************************************
 *  函数名称   : bdgshowfwdcpiftssi()
 *  功能描述   : FWD时间片反馈模拟功率
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowfwdcpiftssi(void)
{
    UINT32 chn = 0;
    INT32 iTmpPow[1] = {0};
    UINT32 bspChn = BspGetTxChannel();

    for (chn = 0; chn<bspChn; chn++)
    {
        BspGetFwdCpIfTssi(chn, 0, &iTmpPow[0]);
        dbgInfo("TOTALCHAN = %d CHAN %d: FwdFb(dbm) = %d\n", bspChn,chn,iTmpPow[0]);
    }
}

/*****************************************************************************
 *  函数名称   : bdgshowreviftssi()
 *  功能描述   : REV时间片TSSI模拟功率
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowreviftssi(void)
{
    UINT32 chn = 0;
    INT32 iTmpPow[1] = {0};
    UINT32 bspChn = BspGetTxChannel();

    for (chn = 0; chn<bspChn; chn++)
    {
        BspGetRevIfTssi(chn, 0, &iTmpPow[0]);
        dbgInfo("TOTALCHAN = %d CHAN %d: RevTssi(dbm) = %d\n", bspChn,chn,iTmpPow[0]);
    }
}

/*****************************************************************************
 *  函数名称   : bdgshowrevcpiftssi()
 *  功能描述   : REV时间片反馈模拟功率
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowrevcpiftssi(void)
{
    UINT32 chn = 0;
    INT32 iTmpPow[1] = {0};
    UINT32 bspChn = BspGetTxChannel();

    for (chn = 0; chn<bspChn; chn++)
    {
        BspGetRevCpIfTssi(chn, 0, &iTmpPow[0]);
        dbgInfo("TOTALCHAN = %d CHAN %d: RevFb(dbm) = %d\n", bspChn,chn,iTmpPow[0]);
    }
}
#if 0
/*****************************************************************************
 *  函数名称   : bdgshowpctssipow()
 *  功能描述   : PC功率检测TSSI功率
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowpctssipow(void)
{
    UINT32 chn = 0;
    INT32 iTmpPow[1] = {0};
    UINT32 bspChn = BspGetTxChannel();

    for (chn = 0; chn<bspChn; chn++)
    {
        BspGetPcTssiPow(chn, 0, &iTmpPow[0]);
        dbgInfo("TOTALCHAN = %d CHAN %d: PcFwdTssi(dbm) = %d\n", bspChn,chn,&iTmpPow[0]);
    }
}

/*****************************************************************************
 *  函数名称   : bdgshowpcrevtssipow()
 *  功能描述   : PC功率检测REV时间片TSSI功率
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowpcrevtssipow(void)
{
    UINT32 chn = 0;
    INT32 iTmpPow[1] = {0};
    UINT32 bspChn = BspGetTxChannel();

    for (chn = 0; chn<bspChn; chn++)
    {
        BspGetPcRevTssiPow(chn, 0, &iTmpPow[0]);
        dbgInfo("TOTALCHAN = %d CHAN %d: PcRevTssi(dbm) = %d\n", bspChn,chn,&iTmpPow[0]);
    }
}
#endif
/*****************************************************************************
 *  函数名称   : dbgshowtxbeamgaincomps()
 *  功能描述   : 打印波束增益beam gain离线参数表
 *  输入参数   : bspChn -- BSP通道
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowtxbeamgaincomps(UINT32 bspChn)
{
    UINT32 rfChn = 0;
    UINT32 freq = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 bw = 800000;
    T_CompsData BeamGain = {0};

    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    BspGetRfChnByBspChn(bspChn, TX, &rfChn);
    freq = BspGetMultiCarrCenterFreq(TX,rfChn);
    _BspGetTxBeamFwd(bspChn,bdtemp,patemp,freq,bw,&BeamGain,COMPS_BY_FREQ_BW_TYPE);

    dbgInfo("bspChn%d BeamGain.comps=%d\n",bspChn,BeamGain.comps);
}

/*****************************************************************************
 *  函数名称   : dbgshowprxgaincomps()
 *  功能描述   : 打印反馈补偿增益
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowprxgaincomps(UINT32 bspChn, UINT32 comptype)
{
    UINT32 rfChn = 0;
    UINT32 freq = 0;
    INT32 bdtemp = 300;
    INT32 patemp = 300;
    UINT32 bw = 800000;
    T_CompsData prxGain = {0};

    BspGetBoardTemp(rfChn,&bdtemp);
    BspGetPaTemp(rfChn,&patemp);
    BspGetRfChnByBspChn(bspChn, TX, &rfChn);
    freq = BspGetMultiCarrCenterFreq(TX,rfChn);
    _BspGetTxFwd(bspChn,bdtemp,patemp,freq,bw,&prxGain,comptype);

    dbgInfo("bspChn%d prxGain.comps=%d\n",bspChn,prxGain.comps);
}

/*****************************************************************************
 *  函数名称   : dbgshowprxgaincomps()
 *  功能描述   : 打印反馈补偿增益
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowcombingain(UINT32 bspChn)
{
    INT32 combinGain = 0;
    combinGain = _BspGetDlPowDefPara(bspChn,E_COMBIN_GAIN);
    dbgInfo("bspChn%d combinGain = %d\n",bspChn,combinGain);
}

/*****************************************************************************
 *  函数名称   : dbgshowprxatt()
 *  功能描述   : 获取prx att值
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
VOID dbgshowprxatt(UINT32 bspChn)
{
    UINT32 rfChn = 0;
    UINT32 freq = 0;
    INT32 attval = 0;
    INT32 attdelta = 0;
    UINT32 bw = 800000;
    BspGetRfChnByBspChn(bspChn, TX, &rfChn);
    freq = BspGetMultiCarrCenterFreq(TX,rfChn);
    BspGetPrxAtt(bspChn,&attval);
    _BspGetPrxAttDelta(bspChn,freq,bw,abs(attval), &attdelta);
    dbgInfo("bspChn%d attval = %d attdelta = %d\n",bspChn,attval,attdelta);
}
/*****************************************************************************
 *  函数名称   : dbgshowrssiifpow()
 *  功能描述   : rssi合载波功率检测
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *  $0000000(N/A), 王佳   @2022-11-01 15:42:06, 创建
 *****************************************************************************/
void dbgshowrssiifpow(void)
{
    UINT32 bspChn = 0;
    INT32 rssiIfPow = 0;
    UINT32 retVal = 0;

    for (bspChn = 0; bspChn < BspGetRxChannel(); bspChn++)
    {
        retVal |= BspGetRxIfRssi(bspChn, &rssiIfPow);
        dbgInfo("Chan %2d:RssiIfPow=%6d\n", bspChn, rssiIfPow);
    }
}
/*****************************************************************************
 *  函数名称   : pwrhelp()
 *  功能描述   : 功率检测维测命令打印
 *  输入参数   : 无
 *  输出参数   : 无
 *  返 回 值:
 *  其它说明   :
 *----------------------------------------------------------------------------
 * 历史记录(变更单, 责任人@修改日期, 操作说明)
 *
 *****************************************************************************/
UINT32 powerhelp(VOID)
{
    UINT32 udPrintCnt = 0;
    UINT32 udCnt = 0;

    dbgInfo("powctrl dbg info Help:\n");

    udPrintCnt = sizeof(g_powHelpPrint) / POW_HELP_LEN;
    for(udCnt = 0; udCnt < udPrintCnt; udCnt++)
    {
        dbgInfo(" %s \n", g_powHelpPrint[udCnt]);
    }

    return BSP_OK;
}

static UINT32 revgate(UINT32 chan)
{
    UINT32 uRegVal = BSP_OK;
    INT32 gate = 0;

    uRegVal = BspGetRevProtectGate(chan, &gate);
    dbgInfo("chan %u rev protect gate = %.1lf(dbfs) \n", chan, gate/10.0);

    return uRegVal;
}

static UINT32 revensta(UINT32 chan)
{
    UINT32 retVal = BSP_OK;
    UINT32 enSta = BSP_INVALID_VALUE;

    retVal = BspGetRevProEnSta(chan, &enSta);
    dbgInfo("chan %u rev enable status: %u (0:disable, 1:enable). \n", chan, enSta);

    return retVal;
}

static UINT32 revalm(UINT32 chan)
{
    UINT32 almSta = 0;

    almSta = BspGetRevPowerAlm(chan);
    dbgInfo("chan %u rev alm status: %u (0:no alarm, 1:alarm). \n", chan, almSta);

    return BSP_OK;
}

/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : powerctrl_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功率控制补偿接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
* $记录2
* 变 更 单: $0000000(N/A)
* 责 任 人: 何瑞华10288704
* 修改日戳: 2020-11-19
* 变更说明: 基于IC3.0代码完成IC4.0功率控制代码
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_POWERCTRL_IC4_2_H_
#define _FUNCLIB_POWERCTRL_IC4_2_H_

#ifdef __cplusplus
extern "C" {
#endif

#include "powerctrlcommon.h"
#include "bspvswr.h"
#include "powerctrl_comps_ic4_2.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"
#include "powerctrl_ic4_2_private.h"

#define RSSI_BUF_SIZE               (8192)
#define TSSI0_THRESHOLD         0
#define TSSI1_THRESHOLD         1
#define FWD_THRESHOLD           2
#define REV_THRESHOLD           3
#define THRESHOLD_NUM           4
/*驻波比检测*/
#define  PA_VSWR_MODE           0
#define  ANTENNA_VSWR_MODE      1
#define  OFFLINE_VSWR_MODE      4

#define TEMP_PARA_UPDATA_SWITCH_OFF   (0x5a5a)
#define TEMP_PARA_UPDATA_SWITCH_ON    (0xa5a5)

#define  REV_PRO_ATTENUATION_VALUE      (INT32)(6)  /* REV功率过大保护的快速降额量 */
#define NBIC_SAMPLE_DATA_LEN         (UINT32)(4096)  /* IC4.2最大支持采数4096个点, 高低16bit分别为I和Q, 共计8192个IQ */

#define  POW_CALC_WAY_DSP      (UINT32)(1)
#define VSWR_UINT                  (1000000)
#define VSWR_ANORMAL_H_VAL         (10*VSWR_UINT)
#define VSWR_ANORMAL_L_VAL         (1100000)

#define  REV_POW_INFO                (0)
#define  FWD_POW_INFO                (1)
typedef struct tagT_TxBbPcPow
{
    UINT32 carrNo;
    UINT32 carrRadMod;
    T_TxPow tbbPcPow;
}T_TxBbPcPow;

typedef struct tagT_TxIfPcPow
{
    UINT32 bandNo;
    T_TxPow tIfPcPow;
}T_TxIfPcPow;

/*DPDIC4编译修改：定义宏*/
#define BSP_MAX_BANK_NUM_ONEBLOCK (10U)
typedef struct tagT_TxAllPcPow
{
    T_TxIfPcPow tPcPow[2];
    T_TxBbPcPow tBbPcPow[BSP_MAX_CARR_NUM];
}T_TxAllPcPow;
typedef struct tagT_TxAllChanPow
{
    T_TxPow tTxPow[BSP_HALADAPT_IC_CHAN_MAX_NUM];
}T_TxAllChanPow;

#define DSP_POW_CALC_ALARM_SAVE_IDX  (29)  
#define CONVERT_TO_WORD32(H16, L16)       ((((UINT32)H16) << 16) |((UINT32)L16))
#define MAX_VSWR_THRESHOLD                (-4200)       //-42dbfs
#define MAX_VSWR_THRESHOLD1                (-6000)       //-60dbfs
typedef enum e_rf_iq_mode
{
    RFADC_IQ_MD_NOMAL = 0   ,/* 0 */
    RFADC_IQ_MD_I       ,/* 1 */
    RFADC_IQ_MD_Q       ,/* 2 */
    NUM_RFADC_IQ_MD
} eRfIQMd;


typedef enum e_pow_calc_type
{
    BSP_TSSI_FWD_INFO = 0,
    BSP_PC_TSSI_FWD_INFO = 1,
    NUM_POW_CALC_TYPE
}ePowType;

typedef enum e_pow_save_type
{
    BSP_POWER_SAVE_DISABLE = 0,
    BSP_POWER_SAVE_ENABLE = 1,
    NUM_POW_SAVE_TYPE
}ePowSaveType;

typedef struct tagT_ComplexNum
{
    DOUBLE dRe;
    DOUBLE dIm;
}T_ComplexNum;

typedef struct tagT_PowCtrlPara
{
    UINT32 period;    /* 周期ms */
    UINT32 cycleTime; /* FPGA时间,FPGA做一轮功率检测时间,ms */
    UINT32 singleTime;/* 单通道检测时间,ms */
    UINT32 (*pCfgPara)(UINT32 powType, UINT32 bspChan);
    UINT32 (*pSetMode)(UINT32 bspChan,UINT32 powType, UINT32 mode);
    UINT32 (*pSetFbSw)(UINT32 powType, UINT32 bspChan);
    UINT32 (*pRdEnable)(UINT32 powType, UINT32 bspChan, UINT32 isEnable);
    UINT32 (*pRdPow)(UINT32 powType, UINT32 bspChan, UINT32 bspCarr, INT32 *pBbPow, INT32 *pFbPow);
    UINT32 (*pSetModeSel)( UINT32 mode);
    UINT32 (*pStartPowCalc)(UINT32 bspChan, UINT32 uStart);
    UINT32 (*pSetRfCalMode)( UINT32 mode);
    UINT32 (*pStartPowCtrl)(UINT32 bspChan, UINT32 uStart);
}T_PowCtrlPara;

typedef struct tagT_PowThreInitPara
{
    UINT32 chanmask;/*通道掩码*/
    UINT32 powAvgCnt;/*功率计算平均次数*/
    INT32 powDbmThreshold[THRESHOLD_NUM];/*功率显示门限*/
    INT32 vswrThreshold[THRESHOLD_NUM];/*驻波计算门限*/
    INT32 vswrPowThresHold[THRESHOLD_NUM];/*驻波功率统计门限*/
}T_PowThreInitPara;

typedef struct
{
    UINT32 boardTemp;
    UINT32 paTemp;
} T_TempSourcePara;

typedef enum
{
    TEMP_SOURCE_HW,
    TEMP_SOURCE_BSP_CACHE,
} E_TempSourceVal;

typedef struct tagT_PowUpdateTime
{
    UINT32 powCalcTime;/*单位ms 所有通道轮询一次的总时间*/
}T_PowUpdateTime;

typedef struct
{
    UINT32 radioMode;
    UINT32 carrNo;
    INT32 tssiDbfs;
    INT32 tssiDbm;
} T_TssiPara;

#define MAX_SLAVE_FREQ_POINT  (20)
typedef struct
{
    UINT32 freq[MAX_SLAVE_FREQ_POINT];
    INT32  loss[MAX_SLAVE_FREQ_POINT];
    INT32  temp[MAX_SLAVE_FREQ_POINT];
    UINT32 cnt;
} T_CableLossRecord;

typedef struct tagDefCableLossVaild
{
    UINT32 flag[PRX+1];
}T_DefCableLossVaild;

typedef struct tagT_DspPowCalcPara
{
    UINT32 dspCalcChanMask;/*Dsp计算功率的通道掩码，1DSP计算，0非DSP计算*/
    UINT32 powCalcDpdTime;/*Dsp检测功率时间片周期*/
    UINT32 (*pSetPowInfoToDsp)(T_TxAllChanPow* pTxAllChanPowInfo);/*给DSP传递前向功率*/
    UINT32 (*pGetPowInfoFromDsp)(T_TxAllChanPow* pTxAllChanPowInfo);/*从DSP获取前向反馈功率*/
    UINT32 (*pSetDspPowInvalidAlarmFlag)(UINT32 ulAlmType, UINT32 bspChn, UINT32 ulAlmFlag);
}T_DspPowCalcPara;

typedef UINT32 (*T_BspValueChange)(UINT32 ulInVal, UINT32 *ulOutVal);

typedef UINT32 (*FUNC_GetBoardScalarVswr)(UINT32 chan, UINT32 *pVswrVal);

typedef UINT32 (*FUN_GET_VECTORVSWR_PTR)(UINT32 ulChan,UINT32 ulFreqBand, UINT32 *pVector);
typedef UINT32 (*FUN_GET_VSWRMODE_PTR)(UINT32 mode);
typedef UINT32 (*FUN_GET_VECTORVSWR_FREQ)(UINT32 ulChan, UINT32 *pVectorFreq);

typedef UINT32 (*pPaProFlagGetFunc)(UINT32 bspChn);
typedef UINT32 (*FUNC_GET_MULTY_PA_VIBAS_UPDATE)(VOID);

typedef UINT32 (*FUNC_GetSlaveBoardTemp)(UINT32 chan, INT32 *pTemp);
typedef UINT32 (*FUNC_GetSlaveAdVolt)(UINT32 bspChn, UINT32 type, UINT32 *pAdVal, INT32 *paTemp, UINT8 *pValidFlag);
typedef UINT32 (*FUNC_GET_AC_FREQ_INDEX_FROM_BOARD)(UINT32 acType);

UINT32 BspCarrGainIsNormal(UINT32 bspChan, UINT32 radioMode, UINT32 carrNo, UINT32 *pulState);
UINT32 BspInitPowCalc(void);
UINT32 BspSetPowAvgCnt(UINT32 bspChn,UINT32 cnt);
UINT32 BspSetPowCalcPara(T_BspHalAdaptPowChk *powChkCfg);
UINT32 BspSetGsmPowCalcPara(T_BspHalAdaptGsmPowChk *pGsmPowChkCfg);
UINT32 BspGetBoardScalarVswrRegister(FUNC_GetBoardScalarVswr pFunc);
FUNC_GetBoardScalarVswr BspGetBackBoardScalarVswrRegister(VOID);
FUNC_GET_MULTY_PA_VIBAS_UPDATE BspGetMultyPaVibasUpdate(VOID);
VOID BspSetMultyPaVibasUpdateFuncInit(FUNC_GET_MULTY_PA_VIBAS_UPDATE pPaVibasPtr);
UINT32 BspReadIfPow (T_TxAllPcPow *txAllPcPow, T_BspHalAdaptPowCfg *fwd, T_BspHalAdaptPowCfg *rev);
UINT32 BspReadPow(UINT32 chip, ePowType powType, UINT32 difChan, T_TxAllPcPow *txAllPcPow);
UINT32 GatherTssiFwd(UINT32 difChan,INT32 Index);
INT32 BspSetVswrThreshhold(UINT32 bspChn,UINT32 ulIndex,INT32 lVswrThreshhold);
INT32 BspGetVswrThreshhold(UINT32 bspChn,UINT32 ulIndex);
INT32 BspSetPowThreshhold(UINT32 bspChn,UINT32 ulIndex,INT32 lPowThreshhold);
INT32 BspGetPowThreshhold(UINT32 bspChn,UINT32 ulIndex);
UINT32 CopyToVswrPow(UINT32 difChn,INT32 powIndex,INT32 vswrIndex);
UINT32 CalAvgTssiFwd(UINT32 bspChn, UINT32 iCntNum, T_TxPow pPowVal[], T_TxPow *pPowAvgVal);
UINT32 GetTssiAlmStatus(UINT32 bspChn,UINT32 *regVal);
UINT32 ClrTssiAlm(UINT32 bspChn);
UINT32 BspSetSpePowTimeCfg(UINT32 TimeMs);
UINT32 BspGetSpePowTimeCfg(UINT32 *TimeMs);
UINT32 BspSetFpgaDataFresh(UINT32 bspChn, UINT32 freshflag);
UINT32 BspPowCalcThreadIsr(void);
UINT32 BspPowCalcThreadInit(void);
UINT32 BspSetNbicAccClrThreadInit(void);
UINT32 BspTssiUpdateThreadInit(void);
UINT32 CalFwdRevDbfs(UINT32 bspChn, T_TxPow *ptAvgTxPow,T_TxPow *pPowDbfs);
UINT32 GetTssiPowDbfs(UINT32 bspChn, UINT32 ulBand, ePowType powType, T_TxPow *pPowDbfs);
UINT32 GetVswrPowDbfs(UINT32 bspChn,UINT32 ulBand,T_TxPow *pPowDbfs);
UINT32 BspGetVswrTssiTcpw(UINT32 bspChn,UINT32 ulBand,T_TxDualPow *fwd, T_TxDualPow *rev, UINT32 *num);
UINT32 BspGetScalarVswrTemp(UINT32 bspChn, UINT32 ulband, UINT32 *pVswrVal);
UINT32 BspCalVswr(UINT32 bspChn,UINT32 ulBand,UINT32 *pulVswrValue);
UINT32 ReadBbTssiPow(UINT32 bspChn,UINT32 bspCarrNo,UINT32 carrMode,INT32 *pTssiPow);
UINT32 BspGetRssiPowInfoByMode(UINT32 bspChn, UINT32 bspCarrNo, UINT32 carrMode, UINT32 slotNo, UINT32 rssiType,INT32 *pRssiDbm, INT32 *pRssiDbfs);
void powsw(UINT32 index, UINT32 powsw);
UINT32 BspSetPowCalcSwitch(UINT32 chan, UINT32 sw);
UINT32 BspSetRadioGain(INT32 *gainValue);
UINT32 BspSetAllPowCalcSwitch(UINT32 sw);
void powswall(UINT32 sw);
UINT32 BspSetVwsrThreshold(UINT32 bspChn, UINT32 type,INT32 threshold);
void BspInitTempSourcePara(UINT32 boardTempSource, UINT32 paTempSource);
UINT32 BspSetUmtsTxCarrPow(UINT32 bspChn, UINT32 carrIdx, UINT32 carrdb);
UINT32 BspGetUmtsTxCarrPow(UINT32 bspChn, UINT32 carrNo);
VOID BspSetVectorVswrCallBackInit(FUN_GET_VECTORVSWR_PTR pVswrPtr);
UINT32 BspSetVswrModeCallBackInit(FUN_GET_VSWRMODE_PTR pVswrPtr);
VOID BspSetVectorVswrFreqCallBackInit(FUN_GET_VECTORVSWR_FREQ pVswrFreq);
UINT32 BspGetRxIfRssi(UINT32 bspChn, INT32 *pIfPow);
UINT32 BspSetDflTxInsertLoss(UINT32 ulChan, UINT32 ulTxInsertLoss);
UINT32 BspSetPaDefaultVolt(UINT32 ulChan,UINT32 Volt);
UINT32 BspSetPaTempDelta(INT32 lPaTempDelta);
UINT32 BspGetDflTxInsertLoss(UINT32  ulChan, UINT32 ulBand);
UINT32 BspPaProFlagStaCall(pPaProFlagGetFunc pGetFlagCall);
UINT32 BspGetRevPowerAlm(UINT32 uChan);
UINT32 BspClearRevPowerAlm(UINT32 uChan);
UINT32 BspSetRevProtectGate(UINT32 chan, INT32 gate);
UINT32 BspGetRevProtectGate(UINT32 chan, INT32 *gate);
UINT32 BspSaveRevDerateCfg(UINT32 bspChn, INT32 val);
UINT32 BspGetRevDerateCfg(UINT32 bspChn, INT32 *val);
UINT32 BspRevPowProtect(INT32 *gate,UINT32 chanNum);
INT32 BspGetRefRevGate(UINT32 chan);
UINT32 BspSetNbicSwitch(UINT32 bspChn, UINT32 carrNo, UINT32 sw);
UINT32 BspGetNbicSwitch(UINT32 bspChn, UINT32 carrNo, UINT32 *sw);
UINT32 BspGetNbicIq(UINT32 bspChn, UINT32 carrNo, UINT16* pusIq, UINT16 iqLen, INT16* psCompDbX10);
UINT32 BspGetTwoSegAssociateVirtualCarr(UINT32 bspChn, UINT32 carrNo, UINT32 carrMode, UINT32 *virtualCarrNo);
VOID BspSetTempParaUpdateDisable(VOID);
UINT32 BspGetVgaCompCarrFacx(UINT32 bspChn,UINT32 bspCarrNo ,UINT32 carrMode,INT32 *preAtt);
VOID BspXTssiPowInfoFromIcX(UINT32 data);
UINT32 BspGetVirtualCarrNo(void);
UINT32 BspJudgeRevProtectAlm(UINT32 bspChn, UINT32 *almFlag);
UINT32 BspGetRevProEnSta(UINT32 bspChn, UINT32 *sta);
UINT32 BspCarrPowUpdate(UINT32 chn,UINT32 carrNo,UINT32 carrPow,UINT32 radio);
UINT32 BspClearCarrGain(VOID);
UINT32 BspGetFwdDbmDelta(UINT32 bspChn, INT32 *delta);
UINT32 BspInitPowShareModule(VOID);
UINT32 BspDpdPowCalcThreadInit(void);
UINT32 BspInitDspPowCalcPara(T_DspPowCalcPara* pDspPowPara);
UINT32 BspSetRevDerateCoefCfg(UINT32 bspChan, INT32 derateCoefDbfs);
UINT32 BspSetRevDeltaRampCfg(UINT32 bspChan, UINT32 deltaRamp);
UINT32 BspSetRevRiseRampCfg(UINT32 bspChan, UINT32 riseRamp);
UINT32 BspGetPaGainByVolt(UINT32 ulChanSel, UINT32 ulBand, UINT32 ulPaVolt, UINT32 ulCfgPower,DOUBLE *pCfrPara, INT32 *ulPaGain);
UINT32 BspSetSpePowPowCalcWayByChan(UINT32 bspChan,UINT32 calcWay);
VOID BspGetSlaveBoardTempCallBackInit(FUNC_GetSlaveBoardTemp pBoardTempPtr);
VOID BspGetSlaveAdVoltCallBackInit(FUNC_GetSlaveAdVolt pFunc);
UINT32 BspGetSlaveBoardTemp(UINT32 index, INT32 *pTemp);
UINT32 BspGetSlavePaTemp(UINT32 bspChn, INT32 *pTemp);
UINT32 BspGetRfDectorAdVolt(UINT32 bspChn, UINT32 type, UINT32 *pAdVal, INT32 *paTemp, UINT8 *pValidFlag);
UINT32 BspGetCableLossVaildFlag(UINT32 chan, UINT32 dir, UINT32 *pFlag);
UINT32 BspGetSlaveScalarVswrTemp(UINT32 bspChn, UINT32 ulband, UINT32 *pVswrVal);
UINT32 BspGetSlaveFwdByRfDector(UINT32 bspChn,  UINT32 *pFwdDbm);
UINT32 BspGetCableLossBaseTemp(UINT32 chan, INT32 *pTemp);
UINT32 BspGetSlaveCableLossBaseVal(UINT32 chan, INT32 *pVal);
UINT32 BspGetSlaveCableLossThreshold(UINT32 chan, UINT32 dir, UINT32 len, INT32 *pThr);
UINT32 BspClrSlaveSlavedTestData(UINT32 chan);
UINT32 BspGetSpePowPowCalcWayByChan(UINT32 bspChan);
void BspSetReducePaVoltFlag(UINT32 flag);
INT32 BspGetPaVoltDelt(void);
UINT32 BspRruTempOptiMiza(UINT32 chan, INT32 realTemp, UINT32 tempType, INT32 tempOffset, INT32 *optiMizaTemp);
void BspSetPaVoltDelt(INT32 volt);
UINT32 isAppLossVaild(UINT32 result);
UINT32 BspGetSlaveCableLossInfoByApp(UINT32 chan, UINT32 *pType, UINT32 *pIndex, double *pCoef);
UINT32 BspGetSlaveCableLossInfo(UINT32 chan, UINT32 *pType, UINT32 *pIndex, double *pCoef);
UINT32 BspSetGsmDcTsgCtrl(UINT32 bspChan, UINT32 carrNo, UINT32 carrPower, UINT32 uiEn);
UINT32 BspGetGsmStaticPowLevel(UINT32 bspChn, UINT16 *pVal);
UINT32 BspSetTssiValue(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 tssiDbm, INT32 tssiDbfs);
UINT32 BspSetTargetGainDelta(UINT32 chan, INT32 delta);
UINT32 BspGetTargetGainDelta(UINT32 chan, INT32 *delta);
UINT32 BspGetTssiPowInfoFromIc(UINT32 bspChn, UINT32 carrMode, UINT32 bspCarrNo, INT32 *pTssiDbm, INT32 *pTssiDbfs);
typedef INT32 (*FUNC_GET_ANA_ATT_FROM_FPGA)(UINT32 bspChn);
UINT32 BspGetAnaAttFromFpgaCallBack(FUNC_GET_ANA_ATT_FROM_FPGA pFunc);
UINT32 BspSetAcFreqIndexFromBoardCallBack(FUNC_GET_AC_FREQ_INDEX_FROM_BOARD pFunc);
UINT32 BspSearchTxPhaseVal(UINT32 uChan, UINT32 curFreq, INT32 *phase0, INT32 *phase1, INT32 *phase2);
UINT32 BspSearchRxPhaseVal(UINT32 uChan, UINT32 curFreq, INT32 *phase0, INT32 *phase1, INT32 *phase2);
UINT32 BspPowThrodCfg(UINT32 rfChanNo, UINT32 carrNo, UINT32 radioMode,UINT32 powPosition,UINT32 powMaxThrod);
UINT32 BspPowThrodStart(UINT32 powPosition);
UINT32 BspPowThrodIsDone(UINT32 powPosition,UINT32 *pFlag);
UINT32 BspPowThrodEnd(UINT32 powPosition);
UINT32 BspInitPowThrodCfg(VOID);
UINT32 BspSetVswrDetectValue(UINT32 calPort, UINT32 freqId, INT32 fwdVal, INT32 revVal);
UINT32 BspGetVswrDetectValue(UINT32 calPort, UINT32 freqId, INT32 *fwdVal, INT32 *revVal);
VOID BspSetCaliPow(UINT32 calPort, INT32 fwdDbmPow, INT32 revDbmPow);
UINT32 BspGetTxPowerDbfs(UINT32 bspChn, T_TxPow *pPowDbfs);
UINT32 BspGetTxIfTssiDbm(UINT32 bspChn, INT32 *txIfTssiDbm);
UINT32 BspGetPathPAR(UINT32 ulChn,UINT32 ulBand, DOUBLE * pPARVal);
UINT32 ShowRcuaPowAndVswr(UINT32 cal);
UINT32 BspSetRssiTypeFlag(UINT32 rssiTypeFlag);
UINT32 BspGetRssiTypeFlag(VOID);
VOID BspSetCancelScalarVswrFlag(UINT32 flag);
UINT32 showdbgBoardTempThreshold(UINT32 nodeIndex);
UINT32 showdbgPaTempThreshold(UINT32 chan);
/* Started by AICoder, pid:f377ceafc5he8c114d7e0b22c0809e0e11216e08 */
UINT32 BspGetOptimizedRev(UINT32 bspChn, INT32 oriFwd, INT32 oriRev, INT32 *optimizedRev);
/* Ended by AICoder, pid:f377ceafc5he8c114d7e0b22c0809e0e11216e08 */
#if 0
UINT32 BspInitPowerCtrl(T_PowCtrlPara cfgPara);
VOID BspPowDetectIsr(VOID);
UINT32 BspGetOneChnTssiTcpw(UINT32 rfChn, T_TxDualPow *pFwdDbm, T_TxDualPow *pRevDbm,T_TxDualPow *pFwdDbfs, T_TxDualPow *pRevDbfs);
UINT32 BspGetBoardTemp(UINT32 index, INT32 * pTemp);
UINT32 BspGetPowDbfs(UINT32 bspChn, UINT32 band, T_TxPow * pPowDbfs);
UINT32 BspSetDivMode(UINT32 divFlag);
UINT32 _BspSetPowerAdjPara(INT32 *plGain, UINT32 ulNum);
UINT32 _BspSetOverTempPowerAdjPara(INT32 *plGain, UINT32 ulNum);
UINT32 BspPimRecoverFreq(UINT32 bspChn);
UINT32 BspPimCheckFreq(UINT32 bspChn, UINT32 uFreq);
UINT32 BspCfgDtxParaInit(UINT32 chipId);
VOID powmodset(UINT32 dectectMode);
UINT32 powmodget(VOID);

VOID bbpctssi(UINT32 carrMode);
UINT32 BspCalcAcVswr(UINT32 chanNum,UINT32 carrNo, UINT32 radioMode, UINT32 vswrType, T_AcVswrValue *acVswrValue);
UINT32 BspGetAcVswr(UINT32 bspChn, UINT32 *pVswrVal);
UINT32 BspGetPowThrodMode();
UINT32 BspGetPcBbTssiTcpwPow(UINT32 bspChn,UINT32 carrMode,UINT32 bspCarrNo,T_TxDbfsDbmPow* txDbfsDbmPow);
UINT32 BspGetCarrNumByBspChn(UINT32 dir, UINT32 bspChn, UINT32 *carrNum);
UINT32 CheckDbfsPowValid(INT32 dbfspow, UINT32 type, INT32 gain, INT32 *dbmpow);
UINT32 showpctssi(UINT32 chanNo);
UINT32 BspGetPowCalcBandNum(UINT32 powCalcBandNum[]);
VOID pcpowshow(VOID);
UINT32 BspSetPowCalcMode(UINT32 powCalcMode);
UINT32 _BspGetOverTempPowerAdjPara(UINT32 ulRfGrp, INT32 *plGain);
VOID BspSetSymbolEn(VOID);
#ifdef BUILD_WITH_OM_FUNC
VOID bbtssinew(void);
#endif
VOID powcalsw(UINT32 idbgisr );
UINT32 _BspSetPowAndFrDly(T_FrDlyCfg *pFrDlyCfg);
UINT32 BspSetAcVswrEnable(UINT32 val);
UINT32 BspSetRssiCarrDly(UINT32 difChan, UINT32 radioMod, UINT32 carrNo, UINT32 rssiType);
UINT32 BspGetRssiPowInfoByModeDif(UINT32 bspChn, UINT32 difCarrNo, UINT32 uMode, UINT32 rssiType, INT32 *pRssiDbm, INT32 *pRssiDbfs);
void rssi();
UINT32 BspGetAcVswrEnable();
void testPowTssi(void);
UINT32 BspGetVswrGamm(T_ComplexNum spa, T_ComplexNum S11, T_ComplexNum S22, T_ComplexNum St, T_ComplexNum* pGamm);
UINT32 getvswr(UINT32 bspChn);
UINT32 _BspInitPowThrod(T_CarrPowThrod *s_CarrPowThrod);
UINT32 BspGetAntennaVswrVal(UINT32 bspChn);
UINT32 BspGetDpdCoreTemp(UINT32 index, INT32 *pTemp);
UINT32 BspGetRssiInfo(UINT32 rssiType, T_RssiInfo *prssi, UINT32 *totalcarrNum, UINT32 *totalchnNum);

INT32 _BspGetPaBestVolt(UINT32 ulIndex, INT32 lPow);
UINT32 BspSetRssiCarrDlyByType(UINT32 chipId,UINT32 bspChan,UINT32 radioMod,UINT32 bandWidth, UINT32 rssiType,UINT32 carrDly,T_BspAdaptOneChanCarrInfo *pDifCarrInfo);
UINT32 _BspPaVoltProtectCallBack(T_BspValueChange tBspFunc);
UINT32 testacvswr(UINT32 startChan, UINT32 endChan, INT32 fwd, INT32 rev);
UINT32 dpdvswrtest(UINT32 uFlag);
UINT32 BspInitSetVswrPowVal(INT32 initVswrVal);
void BspGetChnDbfs(UINT32 bspChn);
VOID BspGetDbfs(T_TxPow *pDbfs, UINT32 num);
UINT32 getacvswr(UINT32 bspChn);
UINT32 _BspGetPowerAdjPara(UINT32 ulRfGrp, INT32 *plGain);
UINT32 GetVswrVal( UINT32 ulChan,UINT32 ulFreqBand, UINT32 *pScalVal, UINT32 *pVector);
UINT32 BspGetSupportDivMode();
void dbfs(void);
VOID BspSetBoardSosTemp(UINT32 ifOn, INT32 temp);
UINT32 GetAcVswrFwdInfo(UINT32 chanNo, INT32 *pFwdDbfs, INT32 *pFwdDbm);
UINT32 GetAcVswrRevInfo(UINT32 chanNo, INT32 *pRevDbfs, INT32 *pRevDbm);
UINT32 BspGetFwdCpIfTssi (UINT32 bspChn, UINT32 ulBand, INT32 *pFwdCpIfTssiDbm);

#endif 
#ifdef __cplusplus
}
#endif
#endif /* _FUNCLIB_POWERCTRL_IC4_2_H_ */

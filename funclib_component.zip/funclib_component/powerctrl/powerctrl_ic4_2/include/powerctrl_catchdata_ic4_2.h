/*****************************************************************************
* 版权所有(C) 2025, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : powerctrl_catchdata_ic4_2.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了RRU全链路采数功能声明
* 注意事项 : 无
* 作    者 : 10346953
* 创建日期 : 2025-10-21
* 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#ifndef _FUNCLIB_POWERCTRL_CATCHDATA_IC4_2_H
#define _FUNCLIB_POWERCTRL_CATCHDATA_IC4_2_H

#ifdef __cplusplus
extern "C" {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "powerctrlcommon.h"
#include "powerctrlapi.h"


/*中频参数点 dsp采数点 通过前缀区分 方案给的编号不连续*/
#define IC_DIF_DL_RCF_OUTPORT       (1)     /*下行成型滤波器输出之后*/
#define IC_DIF_DL_CFR_OUTPORT       (2)     /*下行削峰模块输出之后*/
#define IC_DIF_DL_DPD_OUTPORT       (3)     /*下行DPD模块输出之后*/
#define DSP_DL_FEEDBACK_INPORT      (4)     /*下行反馈输入*/
#define IC_DIF_UL_DDC_INPORT        (5)     /*上行DDC模块输入之前*/
#define IC_DIF_UL_RCF_OUTPORT       (6)     /*上行成型滤波器输出之后*/
#define DSP_DL_DPDCAL_DATA          (7)     /*下行DPD计算数据*/
#define DSP_DL_DPDLUT_DATA          (8)     /*下行DPD采集表格数据*/
#define DSP_TS_DATA                 (9)     /*TS数据 暂未交付*/
#define DSP_TS_STANDARD_SOURCE      (10)    /*TS标准源*/
#define DSP_TRAP_DATA               (11)    /*Trap数据*/
#define DSP_TRAP_TABLE              (12)    /*Trap表格*/
#define DSP_SSC_DATA                (13)    /*SSC数据*/
#define DSP_SSC_TABLE               (14)    /*SSC表格*/
/*dsp只有如下两个为上行*/
#define DSP_PIMC_DATA               (15)    /*PIMC数据*/
#define DSP_PIMC_TABLE              (16)    /*PIMC表格*/

#define IC_DIF_POINT_NUM            (5)     /*中频采数点数  数一下上面的点数*/
#define IC_DIF_TX_POINT_NUM         (3)     /*下行采数点数*/
#define IC_DIF_RX_POINT_NUM         (2)     /*下行采数点数*/
#define DSP_POINT_NUM               (11)     /*DSP采数点数*/
#define DSP_TX_POINT_NUM            (9)     /*dsp下行采数点数*/
#define DSP_RX_POINT_NUM            (2)     /*dsp上行采数点数*/

#define CATCH_IC_DIF_DATA           (1)     /*采数分类*/
#define CATCH_DSP_DATA              (2)

#define NO_SUPPROT_DPDIC_CATCHDATA_FLAG (0)     /*是否支持全链路参数功能*/
#define SUPPROT_DPDIC_CATCHDATA_FLAG    (1)

#define IC_DIF_CATCH_DATA_FREE      (0)         /*中频采数是否正在进行*/
#define IC_DIF_CATCH_DATA_RUNNING   (1)

/*对Dsp的开关*/
#define START_SAMPLE                (0x5A5A)
#define STOP_SAMPLE                 (0X2D2D)

UINT32 BspGetSupportDpdicCatchdataFlag(VOID);
UINT32 BspSetSupportDpdicCatchdataFlag(UINT32 flag);
UINT32 BspDpdicCatchDataFromIcDif(VOID);
UINT32 BspDpdicCatchDataFromIcDifRun(VOID);
UINT32 BspDpdicCatchDataFromIcDsp(VOID);
UINT32 BspGetDpdicCatchDataCategory(UINT32 pointNo);
UINT32 BspGetCatchDataResultFromIcDif(VOID);
UINT32 BspGetCatchDataResultFromDsp(VOID);
UINT32 BspCheckDpdicChanNo(UINT32 chan, UINT32 dir);
UINT32 testUT_s_catchDataCategory(UINT32 flag);
UINT32 testUT_s_catchDataFromIcdifRunFlag(UINT32 flag);
UINT32 testUT_s_catchDataFromIcdifRunRetVal(UINT32 flag);
UINT32 BspDpdicCatchDspData(UINT32 sw, UINT32 difChan, UINT32 pointNo);
UINT32 BspDpdicGetCatchDspDataStatus(VOID);

#ifdef __cplusplus
}
#endif

#endif /*_FUNCLIB_POWERCTRL_CATCHDATA_IC4_2_H*/

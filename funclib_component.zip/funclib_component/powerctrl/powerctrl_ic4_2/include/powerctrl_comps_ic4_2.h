/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : powerctrl_comps_ic4.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功率控制补偿接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
* $记录2
* 变 更 单: $0000000(N/A)
* 责 任 人: 何瑞华10288704
* 修改日戳: 2020-11-19
* 变更说明: 基于IC3.0代码完成IC4.0功率控制代码
*----------------------------------------------------------------------------
*/

#ifndef ITRANAAU_PLATFORM_BSP_FUNCLIB_POWERCTRL_POWERCTRL_IC4_2_INCLUDE_POWERCTRL_COMPS_IC4_H_
#define ITRANAAU_PLATFORM_BSP_FUNCLIB_POWERCTRL_POWERCTRL_IC4_2_INCLUDE_POWERCTRL_COMPS_IC4_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "powerctrlcommon.h"
#include "rftable.h"
#define RRU_CFG_PARA_CHK_CONTINUE(a)  if ((a) == 0 || (a) == BSP_ERROR) continue
#define COMPS_FREQ_STEP               200      /* 单位为KHz */

#define PWR_AVERAGE_RATIO              65
#define CHAN_MAX_NUM_SOC               64
#define SLAVE_CABLE_BASE_TEMP          (INT32)(200)     /*一拖三机型射频线缆温补基准温度*/
#define SLAVE_CABLE_DELT_TEMP          (INT32)(390)     /*一拖三机型射频线缆温度和单板温度差值*/
#define DIF_ULPOST_RXEN_CRUDE_DELAY_OFFSET    0x4/*0x89002b50+4 reg0~3，每个寄存器表示1个延时周期*/
#define DIF_ULPOST_RXEN_DELAY_GRADE_OFFSET    0x14/*0x89002b50+0x14 reg0~3，每个寄存器表示4个载波*/
#define DIF_ULPOST_RXEN_FINE_DELAY_OFFSET     0x24/*0x89002b50+0x24 reg0~7，每个寄存器表示2个载波的精时延*/
#define DIF_ULPOST_RX1EN_DELAY_GRADE_OFFSET   0x11b0/*0x89003d00 reg0~3，每个寄存器表示4个载波*/
#define DIF_ULPOST_RX1EN_FINE_DELAY_OFFSET    0x11c0/*0x89003d10 reg0~7,每个寄存器表示2个载波的精时延*/
#define DIF_ULPOST_RXEND_DELAY_OFFSET         0x11e0/*0x89003d30 reg0~15*/
#define BSP_GET_IF_FREQ_INFO_CAL 1
/* Started by AICoder, pid:f568f7413901b4d14c1209df1004a107e632cca2 */
#define INVALID_CHN_GAIN 0x7FFFFFFF
/* Ended by AICoder, pid:f568f7413901b4d14c1209df1004a107e632cca2 */

enum _PowCalPARA{
    E_BBU_DBFS_TX,
    E_TARGET_DBFS_TX,
    E_FULL_BIT_TX,
    E_BACK_DBM_TX,
    E_TARGET_DBFS_PRX,
    E_FULL_BIT_PRX,
    E_ATT_DEF_TX,
    E_ATT_DEF_PRX,
    E_IC_GAIN,
    E_TXATT_BACK,
    E_COMBIN_GAIN,
    E_POW_CALC_MAX
};

enum _PowCompsType{
    TX_GAIN_COMPS,
    FWD_GAIN_COMPS,
    REV_GAIN_COMPS,
    RX_GAIN_COMPS,
    DELT_TX_GAIN_COMPS,
    DELT_RX_GAIN_COMPS,
    GAIN_COMPS_MAX
};

enum _AcVswrPARA{
    E_AC_VSWR_TSSI_DBFS,
    E_FWD_GATE_UP,
    E_FWD_GATE_DOWN,
    E_REV_GATE_UP,
    E_REV_GATE_DOWN,
    E_AC_VSWR_MAX
};

typedef INT32 (*pOutputPowerReduceFunc)(void);
typedef UINT32 (*pCpattRfTblMapFunc)(UINT32 difChn, UINT32 *rftblChn);

/* tx iq calibrate data */
typedef struct tagTxIqVal
{
    INT16 sIOffset;   /* I 路偏置电流校准参数 */
    INT16 sQOffset;   /* Q 路偏置电流校准参数 */
    INT16 sIAmp;      /* I 路增益校准参数 */
    INT16 sQAmp;      /* Q 路增益校准参数 */
    INT16 sIPhase;    /* I 路相位校准参数 */
    INT16 sQPhase;    /* Q 路相位校准参数 */
}T_TxIqVal;

typedef struct tagTxDpdIqGainRecord
{
    INT16 sIGain;      /* I粗校准值 */
    INT16 sQGain;      /* Q粗校准值 */
    INT16 sIFineTurn;  /* I 微调值 */
    INT16 sQFineTurn;  /* Q 微调值 */
}T_TxDpdIqGainRecord;


typedef struct tagT_CompsItem
{
    INT32  lTxGain;
    INT32  lTxFwd;
    INT32  lTxRev;
    INT32  lTxCali;
    INT32  lRxCali;
    INT32  lRxRssiM;
    INT32  lRxRssiD;
}T_CompsItem;

typedef struct tagT_ChannelCompsItem
{
    INT32  lRf;      /* 射频补偿 */
    INT32  lIf;      /* 中频补偿 */
}T_ChannelComps;

typedef struct tagT_TempCompsItem
{
    INT32  bdGainTemp;  /* 单板温度补偿 */
    INT32  paGainTemp;  /* 功放温度补偿 */
}T_TempComps;

typedef struct tagT_CompsData
{
    T_ChannelComps ChannelComps;
    T_TempComps    tempComps;
    INT32          comps;   /* 最终补偿=lRf+lIf-(lBTemp+lPaTemp) */
}T_CompsData;

typedef struct tagT_PowCalcCompsPara
{
    T_CompsData TxGain;
    T_CompsData FwdGain;
    T_CompsData RevGain;
    T_CompsData RxGain;
    T_CompsData DeltTxGain;
    T_CompsData DeltRxGain;
}T_PowCalcCompsPara;

typedef struct tagTChnCompsData
{
    INT32  lFreqComp;      /*频补 */
    INT32  lTempComp;      /*温补 */
}TChnCompsData;

typedef struct tagTCarrCompsData
{
    UINT32 uCarrMode;
    UINT32 uCarrNo;
    INT32  lFreqComp;      /* 频补 */
    INT32  lTempComp;      /* 温补 */
}TCarrCompsData;
/* 校准表补偿用的温度 */
typedef struct tagTCompsTemp
{
    INT32 lTrxTemp[BSP_MAX_TX_CHAN]; /* 单板温度 */
    INT32 alPaTemp[BSP_MAX_TX_CHAN]; /* 功放温度 */
}TCompsTemp;

#if 0
typedef struct tagTPowCalcCompsPara
{
    T_CompsItem TxGain[BSP_MAX_TX_CHAN];  /* 下行 */
    T_CompsItem FwdGain[BSP_MAX_TX_CHAN]; /* 反馈 */
    T_CompsItem RevGain[BSP_MAX_TX_CHAN]; /* 反射 */
    T_CompsItem RxGain[BSP_MAX_RX_CHAN];/* 上行各制式分载波补偿 */
}TPowCalcCompsPara;
#endif

typedef struct tagT_PaInfo
{
    UINT32 ulEfficientVal;
    UINT32 ulPaType;
    UINT32 ulPaCfgFreq;
    UINT32 ulPaBestVolt;
    UINT32 ulPaVoltUp;
    UINT32 ulPaVoltDown;
}T_PaInfo;

typedef struct
{
    UINT32   devIdVal;
    UINT32   tempType;
    UINT32   thresholdType;
    INT32   alarmThreshold;
    INT32   recoverThreshold;
}T_ThresholdPara;

/* alarm threshold */
typedef struct tagAlmThreshold
{
    INT32   lAlarm;
    INT32   lRecover;
}T_AlmThreshold;

typedef struct tagCaliUpdateInfo
{
    UINT32   flag; //1为需要更新
    UINT32   ulCaliTypeMask;//表格类型掩码
    UINT32   ulChanMask[BSP_MAX_TX_CHAN];//共用通道掩码
    UINT32   ulMaxOrMin; //选择最大/最小 1：最大，0最小
}T_CaliUpdateInfo;

typedef struct tagDefDlPowCalPara
{
    INT32   lvVal[E_POW_CALC_MAX];
}T_DefDlPowCalPara;
typedef T_DefDlPowCalPara T_DlPowCalcPara;

typedef struct tagDefUlPowCalPara
{
    INT32   lRxTargetGain;
    INT32   lRxDefAttVal;
    INT32   lTxAcCalDefVal;   //AC驻波的FWD默认值
    INT32   lRxIsoCalDefVal;  //AC驻波的REV默认值
    INT32   lRxDigAttVal;  //数字预衰
}T_DefUlPowCalPara;

typedef struct tagDefUlTargetGain
{
    INT32   lRxTargetGain;
    UINT32  uiCarrMode;
}T_DefUlTargetGain;

typedef T_DefUlPowCalPara T_UlPowCalcPara;

typedef struct tagDefAcVswrPara
{
    INT32   lvVal[E_POW_CALC_MAX];
}T_DefAcVswrPara;
typedef T_DefAcVswrPara T_AcVswrPara;

typedef struct tagPaTempSensorCfg
{
    CHAR deviceName[BAR_MAX_LENGTH];  //传感器芯片名称
    UINT32 deviceIndex;  //传感器芯片编号
    UINT32 deviceInterIndex;  //传感器芯片内部通道号
}T_PaTempSensorCfg;

typedef struct tagDefLnaOffGain
{
    INT32 adcFullScalMap;/* ADC满量程映射 0.01dB eg R9244  S9000 D6A ADC输入7dBm对应0dBfs */
    INT32 adcNoise;      /* ADC噪声密度 0.01dBfs/Hz eg R9244  S9000 D6A MTS1.0 的底噪：-149dBfs/Hz */
    INT32 nf;            /* 单板噪声系数 0.01dB */
}T_DefLnaOffGain;



#if 0
typedef struct tagT_Chk_Period
{
    UINT32 transPeriod;/*TRANCEIVE校准的插入周期配置0x88245f2c*/
    UINT32 dpd2Period;/*DPD2的插入周期配置0x88245f30*/
    UINT32 transEn;/*TRANCEIVE校准的插入使能0x88245f34*/
    UINT32 dpd2En;/*DPD2的插入使能0x88245f38*/
    UINT32 dpd1TimeLen;/*DPD1时间片长度0x88245f3c*/
    UINT32 fwdTimeLen;/*FWD时间片长度0x88245f40*/
    UINT32 revTimeLen;/*REV时间片长度0x88245f44*/
    UINT32 holdTimeLen;/*HOLD时间片长度0x88245f48*/
    UINT32 tranTimeLen;/*TRANCEIVE时间片长度0x88245f4c*/
    UINT32 dpd2TimeLen;/*DPD2时间片长度0x88245f50*/
    UINT32 dpd2BaseTime;/*DPD2状态长度颗粒度配置0x88245f54*/
}T_ChkPeriod;

typedef struct tagT_Tssi_Chk
{
    UINT32 frFmatSel;
    UINT32 rfSwitchDly;/*射频开关切换延迟配置,0x88245f64*/
    UINT32 txPwcStart;/*TSSI功率检测起始位置配置0x88246030*/
    UINT32 txPwcEnd;/*TSSI功率检测结束位置配置0x88246040*/
    UINT32 pwcFrDly;/*功率计算贞头延时配置0x88246004*/
    UINT32 pcPowCalEndPrd; /*0x88245ab0,PC功率检测end周期的长度*/
    UINT32 pcPowCalEndNum; /*0x88245ab4,PC功率检测end个数*/
}T_TssiCheck;

typedef struct tagT_Rssi_Chk
{
    UINT32 rxPwcStart;/*RSSI功率检测起始位置配置0x88246060*/
    UINT32 rxPwcEnd;/*RSSI功率检测结束位置配置0x88246070*/
    UINT32 lteRssiChkThred;/*LTE长时rssi检测门限，0x89002984~890029a4*/
    UINT32 lteRssiGrp0;/*LTE长时rssi功率检测组数，0x89002b50*/
    UINT32 rxSfPwcStart;/*短时RSSI功率检测起始位置配置0x88246780*/
    UINT32 rxSfPwcEnd;/*短时RSSI功率检测结束位置配置0x88246790*/
    UINT32 lteSfRssiChkThred;/*LTE短时rssi检测门限，0x89002b98~89002ba8*/
}T_RssiCheck;

typedef struct tagT_PowChk_Cfg
{
    UINT32 sfLen;/*TSSI AND RSSI子贞长度配置0x88246014*/
    T_ChkPeriod  tCheckPeriod;
    T_TssiCheck tTssiCheck;
    T_RssiCheck tRssiCheck;
}T_PowChk_Cfg;
#endif

typedef struct tagT_CarrPowThrod
{
    UINT32 powThrodMax;  //过功率检测高门限配置，目前由高层指定
    UINT32 powThrodMin;  //过功率检测低门限配置，HAL层默认值0
    UINT32 powWinLen;    //过功率检测数据窗长，HAL层默认值2
}T_CarrPowThrod;

typedef struct tagT_frDlyCfg
{
    UINT32 cfrToDpdRate;
    UINT32 syncMode;
    UINT32 fbadcClk;
    UINT32 uladcClk;
    UINT32 lteCarrSapRat;/*仅上行ulbank->rssi检测点的延时配置时使用，因为rssi检测在延时补偿后，按现有时延补偿方案，此时延时与最低采样率时对齐，所以此处传最低采样速率即该部分延时*/
    UINT32 nrCarrSapRat;/*仅上行ulbank->rssi检测点的延时配置时使用，因为rssi检测在延时补偿后，按现有时延补偿方案，此时延时与最低采样率时对齐，所以此处传最低采样速率即该部分延时*/
    UINT32 umtsCarrSapRat;/*仅上行ulbank->rssi检测点的延时配置时使用，因为rssi检测在延时补偿后，按现有时延补偿方案，此时延时与最低采样率时对齐，所以此处传最低采样速率即该部分延时*/
    UINT32 nbCarrSapRat;/*仅上行ulbank->rssi检测点的延时配置时使用，因为rssi检测在延时补偿后，按现有时延补偿方案，此时延时与最低采样率时对齐，所以此处传最低采样速率即该部分延时*/
    UINT32 lteCarrBw;
    UINT32 nrCarrBw;
    UINT32 umtsCarrBw;
    UINT32 nbCarrBw;
    UINT32 lteCarrSrc;
    UINT32 nrCarrSrc;
    UINT32 umtsCarrSrc;
    UINT32 nbCarrSrc;
}T_FrDlyCfg;

#define MAX_LEVEL_NUM   7
typedef struct tag_TPaEnergySaveInfo
{
    UINT32 powLevel;
    UINT32 voltLevel;
    INT32  powPrecent[MAX_LEVEL_NUM];
    INT32  powValue[MAX_LEVEL_NUM];
    INT32  voltValue[MAX_LEVEL_NUM];
}T_PaEnergySaveInfo;

typedef UINT32 (*FUNC_GET_DEST_GAIN)(UINT32 dir, UINT32 chan, INT32 *destgainvalue);
typedef UINT32 (*FUNC_SET_RX_GAIN_FPGA)(UINT32 chanNo);
typedef UINT32 (*FUNC_CHANGE_RF_CFG_DIR)(UINT32 chan);
typedef UINT32 (*FUNC_GET_RADIO_MODE_BY_CHAN)(UINT32 chan, UINT32 *pVal);

UINT32 BspCpattRfTblChanMapFuncCallBack(pCpattRfTblMapFunc pGetRfTblMapFunc);
UINT32 BspGetFwdGainFromRftable(INT32 bspChn, INT32 bdtemp,INT32 patemp,UINT32 freq,UINT32 bw,INT32 *pGain,UINT32 comptype);
UINT32 BspGetFwdDbmGainSingleBand(UINT32 bspChn,INT32 *pGain,UINT32 comptype);
UINT32 BspGetFwdDbmGainMultBand(UINT32 bspChn,INT32 *pGain,UINT32 comptype);
UINT32 _BspGetFwdDbmGain(UINT32 bspChn,INT32 *pGain,UINT32 comptype);
UINT32 BspGetRevGainFromRftable(INT32 bspChn, INT32 bdtemp,INT32 patemp,UINT32 freq,UINT32 bw,INT32 *pGain,UINT32 comptype);
UINT32 BspGetRevDbmGainSingleBand(UINT32 bspChn, INT32 *pGain,UINT32 comptype);
UINT32 BspGetRevDbmGainMultBand(UINT32 bspChn, INT32 *pGain,UINT32 comptype);
UINT32 _BspGetRevDbmGain(UINT32 bspChn, INT32 *pGain,UINT32 comptype);
UINT32 BspGetBoardCompTemp(UINT32 ulchan, INT32 *temp);
UINT32 BspGetBoardTempRecord(UINT32 index, INT32 *temp);
UINT32 BspGetPaCompTemp(UINT32 ulchan, INT32 *temp);
UINT32 BspSetTempCaliUpdateInfo(T_CaliUpdateInfo *ptCaliUpdaInfo);
UINT32 _BspGetAlmThreshold(UINT32 ulChan, UINT32 ulTempType, UINT32 ulTypeThreshold, T_AlmThreshold *pAlmThreshold);
UINT32 _BspSetDlPowDefPara(T_DlPowCalcPara *pPara, UINT32 num);
UINT32 _BspSetUlPowDefPara(T_UlPowCalcPara *pPara, UINT32 num);
UINT32 BspSetUlTargetGain(T_DefUlTargetGain *pInfo,UINT32 ulNum);
INT32 _BspGetDlPowDefPara(UINT32 ulChn, UINT32 ulType);
UINT32 _BspGetAlmThreshold(UINT32 ulChan, UINT32 ulTempType, UINT32 ulTypeThreshold, T_AlmThreshold *pAlmThreshold);
UINT32 _BspGetCompsVal(UINT16 usType, UINT32 ulChan, UINT32 ulFreq, INT32 lBdTemp,INT32 lPaTemp,UINT32 ulBw, T_CompsData *pGain,UINT32 compType);
UINT32 _BspGetIfFreqVal(UINT16 usType, UINT32 ulChan, UINT32 ulCenterFreq, UINT32 ulCarrFreq, UINT32 ulBw, INT32 *plVal);
UINT32 _BspGetRfFreqVal(UINT16 usType, UINT32 ulChan, UINT32 ulCenterFreq, UINT32 ulCarrFreq, UINT32 ulBw, INT32 *plVal,INT32 *plBdTemp, INT32 *plPaTemp,UINT32 compType);
UINT32 _BspGetTxIqVal(UINT32 ulChan, UINT32 ulFreq, UINT32 ulBw, T_TxIqVal *ptTxIqVal);
UINT32 _BspGetTxGain(UINT32 ulChan, INT32 lBdTemp,INT32 lPaTemp,UINT32 ulFreq, UINT32 ulBw, T_CompsData *pGain,UINT32 comptype);
UINT32 _BspGetRxGain(UINT32 ulChan,UINT32 mode, INT32 lBdTemp,INT32 lPaTemp,UINT32 ulFreq, UINT32 ulBw,T_CompsData *pGain,UINT32 comptype);
UINT32 _BspGetTxFwd(UINT32 ulChan, INT32 lBdTemp,INT32 lPaTemp,UINT32 ulFreq, UINT32 ulBw, T_CompsData *pGain,UINT32 comptype);
UINT32 _BspGetTxRev(UINT32 ulChan, INT32 lBdTemp,INT32 lPaTemp,UINT32 ulFreq, UINT32 ulBw, T_CompsData *pGain,UINT32 comptype);
UINT32 _BspGetTxChanTargetGain_Base(UINT32 bspChn,INT32 *chanTargetGain);
UINT32 _BspGetRxChanTargetGain_Base(UINT32 bspChn,UINT32 ulBand,INT32 *chanTargetGain);
UINT32 _BspGetGainComps(UINT32 type,UINT32 bspChn,INT32 bdtemp, INT32 patemp,UINT32 freq, UINT32 bw, T_CompsData *pGain,UINT32 comptype);
UINT32 BspSetCaliModefyGain(UINT32 caliChan, UINT32 caliType, INT32 gainValue);
INT32 _BspGetUlAttDigPara(UINT32 ulChn, UINT32 ulType);
UINT32 BspGetRxPreAtt(UINT32 chanNo,UINT32 freq,INT32 *pAtt);
UINT32 BspGetTxOpenLoopGain(UINT32 chanNo,UINT32 freq,INT32 *pTxGain);
UINT32 BspGetTxPreOpenLoopGain(UINT32 chanNo,UINT32 freq,INT32 *pTxGain);
UINT32 _BspGetIfTssiDbmGain(UINT32 bspChn,INT32 *pGain,UINT32 comptype);
UINT32 BspGetPaBaseInfo(UINT32 ulIndex, T_PaInfo *ptInfo);
UINT32 BspSetRxPreAtt(UINT32 chanNo, INT32 pAtt);
UINT32 BspSetPaGain(UINT32 chanNo, INT32 gain);
UINT32 BspGetPaGain(UINT32 chanNo, INT32 *pGain);
UINT32 BspSetRxDigitAtt(UINT32 chanNo, UINT32 carrNo, UINT32 carrMode, INT32 gain);
UINT32 BspSetRxVgaAtt(UINT32 chanNo, UINT32 ulCarrNo, UINT32 carrMode, INT32 gain);
UINT32 BspSetRxVgaGainFpga(UINT32 bspChan, UINT32 carrRadio, UINT32 carrNo, INT32 gain);
UINT32 _BspGetPrxAttDelta(UINT32 ulChan, UINT32 ulFreq, UINT32 ulBw,UINT32 ulAtt, INT32 *plGain);
UINT32 _BspGetTxBeamFwd(UINT32 bspChn, INT32 bdtemp, INT32 patemp, UINT32 freq,
    UINT32 bw, T_CompsData *pGain, UINT32 comptype);
UINT32 BspGetTxCarrTargetGain(UINT32 bspChn,INT32 *chanTargetGain);
UINT32 BspInitTxOpenLoopPara(VOID);
UINT32 BspInitRxOpenLoopPara(T_RxOpenLoopPara *para );
UINT32 BspModifyRxOpenLoopPara(UINT32 chan,INT32 attMin,INT32 attMax,INT32 att);
UINT32 BspGetCalibTblCompsTemp(void);
UINT32 BspGetPaTempFromHW(UINT32 bspChan, INT32 *pTemp);
UINT32 BspGetBoardTempFromHW(UINT32 index, INT32 *pTemp);
UINT32 BspCalibTblCompsThreadInit(void);
UINT32 BspGetTempThreadSwitch(void);
UINT32 BspGetRxPreAttByFreq(UINT32 chanNo, UINT32 freq, INT32 *preAtt,UINT32 carrMode);
UINT32 BspGetTmaGainByBspChn(UINT32 bspRxChn, UINT32* pTmaGain);
UINT32 BspGetPwrTempAlmChNum(UINT32 *pPwrTempAlmChNum);
UINT32 BspGetTempAlmSensorNum(UINT32 *pPwrTempAlmSensorNum);
UINT32 BspSetPowerAdjPara(INT32 *plGain, UINT32 ulNum);
UINT32 BspGetPwrAverageRatio(UINT32 *ulPwrAvgRatGet);
UINT32 BspGetPaDraAdjCaliData(TPaDrainAdjCaliData *ptDataGet);
UINT32 BspRegisterSetPowerReduce(pOutputPowerReduceFunc pGetPowerReduceFunc);
UINT32 BspGetPaEnergySaveInfo(UINT32 chan, T_PaEnergySaveInfo *ptPaEnergySaveInfo);
UINT32 BspSetLnaGainPara(T_DefLnaOffGain *pInfo, UINT32 num);
UINT32 BspGetLnaGain(UINT32 bspChan, INT32 rssiGain, INT32 *lnaGain);
UINT32 BspGetIdRssiDbmCompGain(UINT32 bspChan, UINT32 freqKHz, UINT32 bw, INT32 *pGain);
INT32 BspGetLna2ByPassGain(UINT32 bspChan);
UINT32 BspSetLna2ByPassGain(UINT32 bspChan,INT32 Lna2ByPassGain);
UINT32 BspSetTmaGain(UINT32 uAntNo, UINT32 uTmaGain);
VOID BspSetChanCenterFreqFlag(UINT32 flag);
BOOL BspIsSuportDefaultChanCenterFreq(VOID);
UINT32 BspGetSlavePowDbmGain(UINT32 bspChn, UINT32 dir, UINT32 type, UINT32 *pPowDbm);
UINT32 BspGetFbPreOpenLoopCailGain(UINT32 chanNo, UINT32 freq, INT32 *pCaliGain );
UINT32 BspSetRfCableDlyResult(UINT32 bspChn, UINT32 result);
UINT32 BspGetRfCableDlyResult(UINT32 bspChn, UINT32 *pResult);
UINT32 BspGetBoardTempNodeFromHw(UINT32 index, INT32 *temp);
UINT32 BspGetSlaveTxFwd(UINT32 bspChn, INT32 *slaveGain);
UINT32 BspGetSlaveTxGain(UINT32 bspChn, INT32 *slaveGain);
UINT32 BspGetSlaveRxGain(UINT32 bspChn, INT32 *slaveGain);
UINT32 BspUpdateSlaveCableGain(UINT32 bspChn, INT32 loss);
UINT32 BspClrSlaveCableGain(UINT32 bspChn);
UINT32 BspGetSlaveCableTempGain(UINT32 bspChn, UINT32 type, INT32 temp, INT32 *pLoss);
UINT32 BspRecordSlavePortCableLen(UINT32 portId, UINT32 len);
VOID BspSetTempThresholdFromCaliFlag(UINT32 flag);
UINT32 BspGetTempThresholdFromCaliFlag(VOID);
UINT32 BspSetTempCaliUpdateInfo(T_CaliUpdateInfo *ptCaliUpdaInfo);
UINT32 BspSetTempThresholdFromBoard(UINT32 thresholdId, INT32 alarmThreshold, INT32 recoverThreshold);
UINT32 BspGetDestGainCallBackInit(VOID);
UINT32 BspSetDestGain(UINT32 fwddir, UINT32 dir, UINT32 rfChan, INT32 destgainvalue);
UINT32 BspGetChnGain(UINT32 fwddir, UINT32 dir, UINT32 rfChan, INT32 *pGain);
UINT32 BspGetTxDestGainCallBackInit(FUNC_GET_DEST_GAIN pCallBackFunc);
UINT32 BspGetRxDestGainCallBackInit(FUNC_GET_DEST_GAIN pCallBackFunc);
UINT32 BspGetFbDestGainCallBackInit(FUNC_GET_DEST_GAIN pCallBackFunc);
UINT32 BspChangeRfCfgDirCallBackInit(FUNC_CHANGE_RF_CFG_DIR pCallBackFunc);
UINT32 BspGetTxDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 *destgainvalue);
UINT32 BspGetRxDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 *destgainvalue);
UINT32 BspGetFbDestGainNcr(UINT32 dir, UINT32 rfChan, INT32 *destgainvalue);
UINT32 _BspGetFwdRevChanTargetGain(UINT32 bspChn,INT32 *chanTargetGain);
UINT32 BspSetRxVgaGainCallBackInit(FUNC_SET_RX_GAIN_FPGA pCallBackFunc);
UINT32 BspGetPaTempSensorCfgInfo(UINT32 bspChan, T_PaTempSensorCfg *paSensorCfg);
UINT32 BspEqualPaSensorCfg(T_PaTempSensorCfg *destPaCfg, T_PaTempSensorCfg *srcPaCfg);
UINT32 BspGetTssiTcpwByAcDsp(UINT32 cal, UINT32 bandId, T_TxDualPow *fwd, T_TxDualPow *rev);
UINT32 BspSaveScalarVswr(UINT32 cal, UINT32 bandId);
UINT32 _BspGetDeltTxGain(UINT32 bspChn, INT32 bdtemp, INT32 patemp, UINT32 freq, UINT32 bw, T_CompsData *pGain, UINT32 comptype);
UINT32 _BspGetDeltRxGain(UINT32 bspChn, UINT32 mode,INT32 bdtemp, INT32 patemp, UINT32 freq, UINT32 bw, T_CompsData *pGain, UINT32 comptype);
UINT32 BspCalcGainForMt(UINT32 rfChn, UINT32 dir, INT32 *totalGain);
UINT32 BspGetCompsGain(UINT32 rfChn, UINT32 dir, INT32* gain, INT32* deltGain);
UINT32 BspGetRfFreqInfo(UINT16 usType, UINT32 caliChn, UINT32 ulTblIndex, UINT32 ulCarrFreq, UINT32 ulFreqBand, UINT32* pulFreqStep, T_FreqRecord** pptFreqTable, UINT32* pulRecordNum, UINT32* pulStartFreq, UINT32* pulStopFreq);
VOID BspJudgeCarrFreq(UINT32* pulCarrFreq, UINT32 ulStartFreq, UINT32 ulStopFreq);
UINT32 BspGetIfFreqInfo(UINT16 usType, UINT32 caliChn, UINT32 ulTblIndex, UINT32* pFreqStep, UINT32* pRecordNum, UINT32* pIfRange, T_FreqRecord** pptFreqTable);
UINT32 BspGetTempGain(UINT32 usGainType, UINT32 ulRecordIndex, UINT32 ulNextRecordIndex, T_TempRecord *ptTempTable, INT32* plTempVal, INT32* plTempGain, INT32* plNextTempVal, INT32* plNextTempGain);
UINT32 BspGetFbOpenLoopInfo(UINT32 linkNum, UINT32* pLinkId, UINT32* pRfInfo, INT32* cailGain, INT32* pTotalCailGain, INT32* pPrxattMin, UINT32* pRetVal, INT32* pCnt);
UINT32 BspGetFbOpenLoopCailGain(UINT32 chanNo,INT32 *pCaliGain);
UINT32 BspGetFbOpenLoopType(VOID);
UINT32 BspSetFbOpenLoopType(UINT32 type);
UINT32 BspGetAverageAnaLogGain(UINT16 usType, UINT16 index, UINT32 caliChn,UINT32 adVolt, INT32 *plVal, INT32 *plPaTemp);
VOID BspSetTargetGainOffset(INT32 offsetVal);
INT32 BspGetTargetGainOffset(VOID);
VOID ChangeRfCfgDir(UINT32 chan);
UINT32 BspSetTxCaliProcAttVal(UINT32 chan,INT32 attValue);
UINT32 testgetchngain(UINT32 fwddir, UINT32 dir, UINT32 rfChan);
UINT32 BspGetAlmThresholdOrigin(UINT32 ulChan, UINT32 ulTempType, UINT32 ulTypeThreshold, T_AlmThreshold *pAlmThreshold);
UINT32 BspGetPowerAdjPara(UINT32 ulRfGrp, INT32 *plGain);
UINT32 testgetallchngain(VOID);
/* Started by AICoder, pid:o3a333651eufc9f14a5e0a2d4097a6080233ca6b */
UINT32 BspGetSsbFreqFromApp(INT32 ssbFreq);
UINT32 _BspGetTempCompsValNcr(UINT16 usTypeTbl, UINT16 usType, UINT32 caliChn, UINT32 freq, T_TempComps *pGain);
UINT32 _BspGetTempComps(UINT16 usGainType, UINT32 ulTempType, UINT32 chan, UINT32 ulCenterFreq, INT32 lTemp, INT32 *plVal);
/* Ended by AICoder, pid:o3a333651eufc9f14a5e0a2d4097a6080233ca6b */
/* Started by AICoder, pid:g602dqb666a76331434d08d370fe150535d1a89b */
UINT32 BspGetTempGainRxDComps(UINT32 bspChn, INT32 *pComps);
/* Ended by AICoder, pid:g602dqb666a76331434d08d370fe150535d1a89b */
UINT32 BspGetRadioModeByChan(UINT32 chan, UINT32 *pVal);
UINT32 BspGetRadioModeCallBack(FUNC_GET_RADIO_MODE_BY_CHAN pfunc);
BOOL BspRadioModeIsNr(UINT32 chan);
UINT32 BspGetAnaLogGain(UINT16 usType, UINT16 index, UINT32 caliChn,UINT32 carrFreq,UINT32 adVolt, INT32 *plVal, INT32 *plPaTemp);
UINT32 BspGetFbOpenLoopCailGainMultBand(UINT32 chanNo,INT32 *pCaliGain);
#if 0
UINT32 _BspGetVswrParam(UINT32 ulChan, UINT32 ulFreq, UINT32 ulBw, T_VswrSParamVal *ptSParam);
UINT32 _BspGetTxFixGain(UINT32 ulChan, INT32 lBdTemp,INT32 lPaTemp,UINT32 ulFreq, UINT32 ulBw, INT32 *plGain);
UINT32 _BspGetRxFixGain(UINT32 ulChan, INT32 lBdTemp,INT32 lPaTemp,UINT32 ulFreq, UINT32 ulBw, INT32 *plGain);
UINT32 BspGetTxCarrTargetGain(UINT32 bspChn,INT32 *chanTargetGain);
UINT32 _BspGetRevDbmGain(UINT32 bspChn, INT32 *pGain,UINT32 comptype);
UINT32 _BspGetRssiDbmGain(UINT32 bspChn,UINT32 mode,INT32 *pGain,UINT32 comptype);
UINT32 _BspGetBBTssiDbmGain(UINT32 bspChn,INT32 *pGain);
UINT32 BspSetPaTempDataType(UINT32 fileType);
UINT32 BspGetTmaGainByBspChn(UINT32 bspRxChn, UINT32* pTmaGain);
UINT32 BspGetVswrFwdDbmGain(UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 *pGain, UINT32 comptype);
UINT32 BspGetVswrRevDbmGain(UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 *pGain, UINT32 comptype);
UINT32 _BspGetPcFwdDbmGain(UINT32 bspChn, UINT32 radioMode, UINT32 carrNo, INT32 *pGain, UINT32 comptype);
#endif
#ifdef __cplusplus
}
#endif

#endif

/*****************************************************************************
* 版权所有(C) 2021-2031, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : 本文件主要提供功率检测维测打印接口
* 文件名称 : powerctrl_ic4_dbg.h
* 文件标识 : {[N/A]}
* 内容摘要 :
* 注意事项 : 无
* 作    者   : 10288704
* 创建日期 : 2021-05-10 14:45:34
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10288704
* 修改日戳: 2021-05-10 14:45:34
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_POWERCTRL_IC4_2_DBG_H_
#define _FUNCLIB_POWERCTRL_IC4_2_DBG_H_
    
#ifdef __cplusplus
    extern "C"
    {
#endif

#include "bsppub.h"
#include "bspcomm.h"
#include "powerctrl_ic4_2.h"
#include "powerctrlcommon.h"
#include "bspvswr.h"
#include "powerctrl_comps_ic4_2.h"
#include "ichaladaptbspapi.h"
#include "ichaladapt_ic4_2.h"

UINT32 BspGetRssiInfo(UINT32 rssiType, T_RssiInfo *prssi, UINT32 *totalcarrNum, UINT32 *totalchnNum);
VOID rssi(UINT32 rssiType);
void bbtssi(void);
void dbfs(void);
VOID BspPrintVswrVal(UINT32 scalVal, UINT32 vector);
#ifdef __cplusplus
}
#endif


#endif


/*****************************************************************************
 * 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
 *----------------------------------------------------------------------------
 * 模 块 名 : BSP
 * 文件名称 : powerctrl_ic4_property.h
 * 文件标识 : {[N/A]}
 * 内容摘要 : 本文件主要提供rru的功率控制模块特性功能的实现
 * 注意事项 : 无
 * 作    者 : heruihua 10288704
 * 创建日期 : 2020-12-10
 * 当前版本 : Ver1.0
 *----------------------------------------------------------------------------
 * 变更记录 :
 *
 * $记录1
 * 变 更 单:
 * 责 任 人:
 * 修改日戳:
 * 变更说明:

 *----------------------------------------------------------------------------
 */

#ifndef FUNCLIB_POWERCTRL_POWERCTRL_IC4_2_PRIVATE_H_
#define FUNCLIB_POWERCTRL_POWERCTRL_IC4_2_PRIVATE_H_


typedef UINT32 (*FUNC_SET_FPGA_DELAY)(UINT32 chan, UINT32 dtxEn);

#endif /* FUNCLIB_POWERCTRL_POWERCTRL_IC4_INCLUDE_POWERCTRL_IC4_PROPERTY_H_ */

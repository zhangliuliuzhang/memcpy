/*****************************************************************************
* 版权所有(C) 2017, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : powerctrlcommon.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了功率控制对内接口声明
* 注意事项 : 无
* 作    者 :   10090699
* 创建日期 : 2017-03-08
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 10090699
* 修改日戳: 2017-03-08
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_POWERCTRLCOMMON_H_
#define _FUNCLIB_POWERCTRLCOMMON_H_



#ifdef __cplusplus
extern "C" {
#endif

#include "ru_univdef.h"
#include "powerctrlapi.h"
#include "funccommon_log.h"
#include "funccommon_a.h"

#define PCGAIN_NOOFFSET (0)
#define PCGAIN_OFFSET   (1)

typedef UINT32 (*SetPreRxAtt)(UINT32 chan,INT32 att);
typedef UINT32 (*SetPostRxAtt)(UINT32 chan,INT32 att);
typedef struct tagT_RxOpenLoopPara
{
    INT32  preAttMin[BSP_MAX_RX_CHAN];
    INT32  preAttMax[BSP_MAX_RX_CHAN];
    SetPreRxAtt pSetPreAtt;
    SetPostRxAtt pSetPostAtt;
    INT32  preAtt[BSP_MAX_RX_CHAN];
    INT32  digAttMin[BSP_MAX_RX_CHAN];
    INT32  digAttMax[BSP_MAX_RX_CHAN];
}T_RxOpenLoopPara;

typedef struct tagT_TxOpenLoopPara
{
    UINT32 (*pGetGain)(UINT32 chan,INT32 totalAtt,INT32 *txAtt,INT32 *digGain);
    UINT32 (*pSetTxAtt)(UINT32 chan,INT32 att);
    UINT32 (*pSetDigGain)(UINT32 chan,INT32 att);
    UINT32 (*pExtraProc)(UINT32 chan,INT32 att);
    UINT32 (*pSetDigGainDualBand)(UINT32 chan, UINT band, INT32 att);
}T_TxOpenLoopPara;

typedef struct tagT_RxLinkGainPara
{
    UINT32 gainCtrlSolution;
    UINT32 (*pGetCtrlGain)(UINT32 chan,INT32 *totalGain);
}T_RxlinkGainPara;

typedef UINT32(*pGetPaDrainAdjTypeByChan)(UINT32 chan,UINT32 *ptPaDrainAdjType);
typedef UINT32 (*pGetFbAdcFreqOffset)(UINT32 ulBspChnl, INT32 *pFreqOffset);

typedef UINT32(*PowerShare_SetCarrPowBeforeShare)(UINT32 chnNo, UINT32 carrNo, UINT32 radioMode, UINT32 carrPow);
typedef UINT32(*PowerShare_RefreshCfrCpg)(UINT32 chNo);

typedef struct tag_func_power_share
{
    PowerShare_SetCarrPowBeforeShare   pCarrPow;        /*共享前的功率*/
    PowerShare_RefreshCfrCpg           pRefreshCpg;     /*刷新CPG*/
}T_PowShareFunc;

typedef struct tag_power_share_module
{
    T_PowShareFunc powerShareFunc;
    UINT32 res[4];
}T_PowerSharerModule;

typedef struct tag_power_adjust_delta
{
    UINT32 chanNo;
    BOOL   isSupport;
    INT32  thresVal;
}T_PowerAdjustDelta;

UINT32 BspSetRxOpenLoopPara(T_RxOpenLoopPara *pPara);
T_RxOpenLoopPara *BspGetRxOpenLoopPara();

UINT32 BspSetTxOpenLoopPara(T_TxOpenLoopPara *pPara);
T_TxOpenLoopPara *BspGetTxOpenLoopPara();

UINT32 BspSetRxGainCtrlPara(T_RxlinkGainPara *pPara);
T_RxlinkGainPara *BspGetRxGainCtrlPara();

INT32 BspRxOpenLoopPowCailFixAttGainInit(INT32 attGain);
INT32 BspGetRxPowCaliFixAttGain(VOID);

UINT32 BspSetFbAdcFreqOffsetInit(pGetFbAdcFreqOffset *pPara);
UINT32 BspSetPaDrainAdjTypeByChan(pGetPaDrainAdjTypeByChan ptBspSetFunc);
UINT32 BspGetPaDrainAdjTypeByChan(UINT32 chan,UINT32 *ptPaDrainAdj);
T_PowerSharerModule* BspGetPowerShareModuleInfo(VOID);
UINT32 BspPwrDeltaInit(T_PowerAdjustDelta *powerAdjustDelta, UINT32 chanNum);
BOOL BspIsSupportPwrDelta(UINT32 chanNo);
UINT32 BspGetPwrThres(UINT32 chanNo,INT32 *pwrThres);
UINT32 BspGetDlCarrGainSwByDifChan(UINT32 uiDifChan, UINT32* uiCarrNum, T_PowSwCarrDb* pSwCarrDb);
void BspSetPcGainOffsetFlag(UINT32 flag);
UINT32 BspGetPcGainOffsetFlag(void);
#ifdef __cplusplus
}
#endif
#endif 




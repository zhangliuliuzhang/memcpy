

#include "bsppub.h"
#include "bspcomm.h"
#include "gainctrlcommon.h"

#include "powerctrlcommon.h"
#include "funccommon_chncfg.h"
#include "exprn.h"

static T_RxOpenLoopPara rxOpenLoopPara = {{0}, {0}, BspSetRxGain};
static T_TxOpenLoopPara txOpenLoopPara = {NULL};
static T_RxlinkGainPara rxlinkCtrlPara = {0,NULL};
static  pGetPaDrainAdjTypeByChan getPaDrainAdjTypeByChan = NULL;
static T_PowerSharerModule s_powerShareModule = {0};
static T_PowerAdjustDelta txPowerAdjustDelta[ANT_CHANNEL_NUM_MAX] = {0};
UINT32 g_isTxPcGainNeedOffset = 0;

UINT32 BspSetRxOpenLoopPara(T_RxOpenLoopPara *pPara)
{
    if (pPara != NULL)
    {
        memcpy(&rxOpenLoopPara, pPara, sizeof(T_RxOpenLoopPara));
    }
    return BSP_OK;
}

T_RxOpenLoopPara *BspGetRxOpenLoopPara()
{
    return &rxOpenLoopPara;
}

UINT32 BspSetTxOpenLoopPara(T_TxOpenLoopPara *pPara)
{
    if (pPara != NULL)
    {
        memcpy(&txOpenLoopPara, pPara, sizeof(T_TxOpenLoopPara));
    }
    return BSP_OK;
}

T_TxOpenLoopPara *BspGetTxOpenLoopPara()
{
    return &txOpenLoopPara;
}

UINT32 BspSetRxGainCtrlPara(T_RxlinkGainPara *pPara)
{
    if (pPara != NULL)
    {
        memcpy(&rxlinkCtrlPara, pPara, sizeof(T_RxlinkGainPara));
    }
    return BSP_OK;
}

T_RxlinkGainPara *BspGetRxGainCtrlPara()
{
    return &rxlinkCtrlPara;
}

UINT32 BspSetPaDrainAdjTypeByChan(pGetPaDrainAdjTypeByChan ptBspSetFunc)
{
    getPaDrainAdjTypeByChan = ptBspSetFunc;
    return BSP_OK;
}
UINT32 BspGetPaDrainAdjTypeByChan(UINT32 chan,UINT32 *ptPaDrainAdj)
{
    UINT32 ulRet = BSP_OK;

    if(NULL!=getPaDrainAdjTypeByChan)
    {
        ulRet = getPaDrainAdjTypeByChan(chan,ptPaDrainAdj);
    }
    else
    {
        *ptPaDrainAdj = 0;
    }
    return ulRet;
}

/* 设置BBU下发的配置功率，不受降额等因素影响 验证之后放开*/
UINT32 BspSetCarrCfgPow(UINT32 bspChn, UINT32 carrNo, UINT32 carrPow, UINT32 radioMode)
{
    UINT32 retVal = 0;
    UINT32 carrLoop = 0;
    T_RruCarrPowCfgInfo pCarrPowInfo = {0};

    retVal |= BspGetCarrPowCfgPara(bspChn, &pCarrPowInfo);
    for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop++)
    {
        if (((pCarrPowInfo.carr[carrLoop].carrRadio & BSP_RADIO_STANDARD_ST_MASK) == radioMode) &&
                (pCarrPowInfo.carr[carrLoop].carrNo == carrNo))
        {
            pCarrPowInfo.carr[carrLoop].cfgCarrPow = carrPow;
            break;
        }
    }
    BspLog(LOG_LEVEL_0,"[%s]{carrLoop %d, bspChn'%d, carrNo'%d, carrPow'%d, radioMode'0x%x\n",
            __FUNCTION__, carrLoop, bspChn, carrNo, carrPow, radioMode);
    if (carrLoop == BSP_MAX_CARR_NUM) /* 表明新增功率 */
    {
        for (carrLoop = 0; carrLoop < BSP_MAX_CARR_NUM; carrLoop ++)
        {
            if (pCarrPowInfo.carr[carrLoop].carrRadio == 0)
            {
                pCarrPowInfo.carr[carrLoop].carrNo      = carrNo;
                pCarrPowInfo.carr[carrLoop].carrRadio   = radioMode;
                pCarrPowInfo.carr[carrLoop].cfgCarrPow  = carrPow;
                break;
            }
        }
        if (carrLoop == BSP_MAX_CARR_NUM)
        {
            dbgErr("%s: no location storage carr pow, bspChn:%u\n", __FUNCTION__, bspChn);
            return BSP_ERROR;
        }
        BspLog(LOG_LEVEL_0,"UpdateCarrPow==[%s]{carrLoop %d, bspChn'%d, carrNo'%d, carrPow'%d, radioMode'0x%x\n",
                    __FUNCTION__, carrLoop, bspChn, carrNo, carrPow, radioMode);
    }
    retVal |= BspSetCarrPowCfgPara(bspChn, &pCarrPowInfo);

    return retVal;
}

T_PowerSharerModule* BspGetPowerShareModuleInfo(VOID)
{
    return &(s_powerShareModule);
}

UINT32 BspSetCarrPowBeforeShare(UINT32 chnNo, UINT32 carrNo, UINT32 radioMode, UINT32 carrPow)
{
    if(s_powerShareModule.powerShareFunc.pCarrPow != NULL)
    {
        return s_powerShareModule.powerShareFunc.pCarrPow(chnNo, carrNo, radioMode, carrPow);
    }
    return BSP_OK;
}

UINT32 BspRefreshCfrCpgPara(UINT32 chnNo)
{
    if(s_powerShareModule.powerShareFunc.pRefreshCpg != NULL)
    {
        return s_powerShareModule.powerShareFunc.pRefreshCpg(chnNo);
    }
    return BSP_OK;
}

UINT32 BspPwrDeltaInit(T_PowerAdjustDelta *powerAdjustDelta, UINT32 chanNum)
{
    UINT32 chanIndex = 0;
    INPUT_POINTER_CHECK(powerAdjustDelta)

    for(chanIndex = 0; chanIndex < chanNum; chanIndex ++)
    {
        txPowerAdjustDelta[chanIndex].chanNo =  powerAdjustDelta[chanIndex].chanNo;
        txPowerAdjustDelta[chanIndex].isSupport =  powerAdjustDelta[chanIndex].isSupport;
        txPowerAdjustDelta[chanIndex].thresVal =  powerAdjustDelta[chanIndex].thresVal;
        dbgInfoEx("[%s] chanNo[%d], isSupport[%d], thresVal[%d]. \n",__FUNCTION__,
                powerAdjustDelta[chanIndex].chanNo, powerAdjustDelta[chanIndex].isSupport, powerAdjustDelta[chanIndex].thresVal);
    }

    return BSP_OK;
}

BOOL BspIsSupportPwrDelta(UINT32 chanNo)
{
    UINT32 chanNum = BspGetTxChanNum();

    if(chanNo >= chanNum)
    {
        dbgInfo("[%s]ERROR: chanNo[%d] is over chanNum[%d], ", __FUNCTION__, chanNo, chanNum);
        return FALSE;
    }

    return txPowerAdjustDelta[chanNo].isSupport ;

}
UINT32 BspGetPwrThres(UINT32 chanNo,INT32 *pwrThres)
{
    UINT32 chanNum = BspGetTxChanNum();
    INPUT_POINTER_CHECK(pwrThres)

    if(chanNo >= chanNum)
    {
        dbgInfo("[%s]ERROR: chanNo[%d] is over chanNum[%d], ", __FUNCTION__, chanNo, chanNum);
        return BSP_ERROR;
    }

    *pwrThres = txPowerAdjustDelta[chanNo].thresVal;

    return BSP_OK;
}

static UINT32 testGetPwrThres(UINT32 chanNo)
{
    INT32 pwrThres = 0;

    BspGetPwrThres(chanNo, &pwrThres);
    dbgInfo("[%s] chanNo[%d]  pwrThres[%d]. \n", __FUNCTION__, chanNo, pwrThres);

    return BSP_OK;
}

/* D42打桩 */
UINT32 BspStartSelfCheckSmp(T_SamplePara *pAppSmpInfo, T_SampleResult *pSmpRet)
{
    INPUT_POINTER_CHECK(pAppSmpInfo);
    INPUT_POINTER_CHECK(pSmpRet);

    return BSP_OK;
}

BOOL BspIsAvoidLowTempTssiTcpwDif(VOID)
{
    return FALSE;
}

/* D42打桩 */
UINT32 BspCloseAllUlTsgData(VOID)
{
    return BSP_OK;
}
/* D42打桩 */
UINT32 BspGetDlCarrGainSwByDifChan(UINT32 uiDifChan, UINT32* uiCarrNum, T_PowSwCarrDb* pSwCarrDb)
{
    return BSP_ERROR;
}

UINT32 BspGetPcGainOffsetFlag(void)
{
    return  g_isTxPcGainNeedOffset;
}

void BspSetPcGainOffsetFlag(UINT32 flag)
{
    g_isTxPcGainNeedOffset = flag;
}

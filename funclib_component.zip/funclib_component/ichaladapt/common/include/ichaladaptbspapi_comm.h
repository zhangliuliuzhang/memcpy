/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladaptbspapi_comm.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层公共功能对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPTBSPAPI_COMM_H_
#define _FUNCLIB_ICHALADAPTBSPAPI_COMM_H_


#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************
                            适配层和HAL层接口一致性检查
**************************************************************************/
UINT32 BspHalAdaptConsistenceCheck(VOID);


/**************************************************************************
                            HAL公共接口
**************************************************************************/
UINT32 BspHalAdaptGetDifVer(VOID); 
//获取当前版本IC芯片支持的最大通道数
UINT32 BspHalAdaptGetIcChanMax(VOID);  

/* 读写DPDIC寄存器 */
UINT32 BspHalAdaptDpdicRegRd(UINT32 chip, UINT32 ulPhyAddr, UINT32 ulOffset, UINT32 *ulData);
UINT32 BspHalAdaptDpdicRegWr(UINT32 chip, UINT32 ulPhyAddr, UINT32 ulOffset, UINT32 ulData);

#ifdef __cplusplus

}
#endif
#endif 





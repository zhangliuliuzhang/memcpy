/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladaptbspapi_J204.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层J204功能对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPTBSPAPI_J204_H_
#define _FUNCLIB_ICHALADAPTBSPAPI_J204_H_


#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************
                            J204c相关接口
**************************************************************************/
#define BSP_HALADAPT_J204_LINK_OK (0)  //BSP_J204_LINK_OK
#define BSP_HALADAPT_J204_LINK_ERR (1)
#define BSP_HALADAPT_J204_LINK_OK_REGVAL (0x20001)

//J204C sysref config
typedef struct tagT_BspHalAdaptSysrefCfg
{
    UINT32 sysrefEn;          //发sysref使能，0代表不往外发sysref，1代表往外发sysref
    UINT32 mode;              //设置sysref发送模式，0代表sysref常发，1代表发固定个数sysref
    UINT32 sysrefNum;         //配置发sysref个数
    UINT32 tsEnable;          //发给Ts端的使能掩码,共4bit，对应trx0-trx3,1为使能，0为关闭
    UINT32 sysrefFrDelay;     //sysref帧头延时配置（默认配置0）,单位是737时钟下的一个clk，最大值为0xfffffff
    UINT32 localcntSyncEn;    //配置系统同步信号产生周期计数器清0，0:帧头到来时不清周期计数器，1：帧头到来时清周期计数器
    UINT32 syncSrc;           //配置产生系统同步信号的寄存器源，0：选择前级空空口帧头，1：多片同步信号（IO引脚）
    UINT32 period;            //配置发sysref信号的周期，取值为0-6，取值为0对应960Khz,取值为1对应480Khz，取值为2对应240Khz、取值为3对应120Khz、取值为4对应60Khz、取值为5对应30Khz、取值为6对应15Khz。具体见表SysPerTbl;
    UINT32 width;             //配置脉冲高电平宽度，其值不大于周期的一半
    UINT32 sysPha;            //配置初始相位
    UINT32 isExtSysref;       //是否为外部sysref信号,1为外部,0为内部
 } T_BspHalAdaptSysrefCfg;

UINT32 BspHalAdaptJ204GetSerdesLaneMask(UINT32 dir, UINT32 j204LaneMask);

//以下接口中的lane掩码和laneId为serdes lane，且掩码需要在1个lane grp中
UINT32 BspHalAdaptJ204SerdesPhyApbRst(UINT32 txLaneIdMask,UINT32 rstFlag);
UINT32 BspHalAdaptJ204cSerdesLoadFrmware(UINT32 laneIdMask, UINT32 txDataRate, UINT32 rxDataRate);
UINT32 BspHalAdaptJ204cSerdesPowerOn(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptJ204cSerdesPowerDown(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptJ204cSerdesInit(UINT32 dir, UINT32 laneIdMask, UINT32 dataRate);
UINT32 BspHalAdaptAdjustJ204SerdesTxEq(UINT32 laneIdMask,UINT32 eqPre,UINT32 eqPost,UINT32 eqMain);
UINT32 BspHalAdaptJ204cSerdesTrxEn(UINT32 dir, UINT32 laneIdMask, UINT32 en);

//以下接口中的lane掩码和laneId为204       lane，且掩码需要在1个lane grp中
UINT32 BspHalAdaptJ204LinkInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pLinkInfo, UINT32 linkSize);
UINT32 BspHalAdaptJ204MapInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pMapInfo, UINT32 mapSize);
UINT32 BspHalAdaptCrmJ204SetResetLogic(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetApb(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetWorkMap(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetWorkLane(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmJ204SetResetRf(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag);
UINT32 BspHalAdaptGetSysrefStatus(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptClrSysrefStatus(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptGetJ204State(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal);
UINT32 BspHalAdaptGetJ204CrcErrCnt(UINT32 dir, UINT32 laneId, UINT32 *crcErrCnt);
UINT32 BspHalAdaptSysrefRequest(T_BspHalAdaptSysrefCfg *pSysrefCfg);
UINT32 BspHalAdaptSysrefGenerate(T_BspHalAdaptSysrefCfg *pSysrefCfg);
UINT32 BspHalAdaptSysrefRspEnable(UINT32 dir, UINT32 laneIdMask);
UINT32 BspHalAdaptGetJ204RegHeadAddr(UINT32 grpId);
UINT32 BspHalAdaptCrmJ204SetResetAll(UINT32 rstFlag);
UINT32 BspHalAdaptSetOptAntEnByLaneId(UINT32 laneId, UINT32 uDir, UINT32 uSwitch);
UINT32 BspHalAdaptNtlL2ssGetXmacFrameCnt(UINT32 udMacId,UINT32 udRcvOrTx,UINT32 udClr,UINT64 *frameCnt);
UINT32 BspHalAdaptJ204SdsTxResetCfg(UINT32 laneIdMask, UINT32 reset);

#ifdef __cplusplus

}
#endif
#endif 





/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladaptbspapi.h
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了ICHAL适配层对外接口声明
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/

#ifndef _FUNCLIB_ICHALADAPTBSPAPI_H_
#define _FUNCLIB_ICHALADAPTBSPAPI_H_


#include "rx_gunb_cfg.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "j204_serdes_api.h"
#include "ichaladaptbspapi_comm.h"
#include "ichaladaptbspapi_j204.h"
#include "ichaladaptbspapi_trx.h"
#include "ichaladaptbspapi_opt.h"

/**************************************************************************
                            TDD 帧头相关接口
**************************************************************************/
#define BSP_AIR_INTERFACE_FR_HD    (0)  //空口帧头
#define BSP_CHAN_ASSOCIATED_FR_HD  (1)  //随路帧头

typedef struct T_BspHalAdaptFrDlyInfo {
    UINT32 radioMode; /* 制式 */
    UINT32 antMask;   /* 天线掩码 */
    UINT32 frTmVal;   /* 帧头调整量，单位 ns */
} T_BspHalAdaptFrDlyInfo;

UINT32 BspHalAdaptSetDifFrSelect(UINT32 difChan, UINT32 frType);
UINT32 BspHalAdaptDifCfgTdd(T_CarrTddIndCfg *pTddIndCfg);
UINT32 BspHalAdaptOptCfgTdd(T_CarrTddIndCfg *pTddIndCfg, UINT32 cfgNum);
UINT32 BspHalAdaptGetFrStruct(UINT32 *pFrStructOfUs);
UINT32 BspHalApiSetDlTddSel(UINT32 difChan);
UINT32 BspHalApiSetUlTddSel(UINT32 difChan);
UINT32 BspIcHalApiSetTddSpiEn(UINT32 uiEn);
#if 0 /* 接口未使用，为清告警，屏蔽掉 */
/**************************************************************************
                            射频开关相关接口
**************************************************************************/
UINT32 BspHalAdaptSetPaModeCtrl(UINT32 difChan, UINT32 mode);
UINT32 BspHalAdaptSetPaSwitchCtrl(UINT32 difChan, UINT32 sw);
UINT32 BspHalAdaptSetLnaModeCtrl(UINT32 difChan, UINT32 mode);
UINT32 BspHalAdaptSetLnaSwitchCtrl(UINT32 difChan, UINT32 sw);
UINT32 BspHalAdaptSetTxSwitchCtrl(UINT32 difChan, UINT32 sw);
UINT32 BspHalAdaptSetRxSwitchCtrl(UINT32 difChan, UINT32 sw);

/**************************************************************************
                            TDD开关时序控制
**************************************************************************/
UINT32 BspHalAdaptInitTddSwDelayPara(UINT32 tddSel, T_TddSwDelayPara* para);

UINT32 BspHalAdaptInitModeMap(UINT32 tddSel,UINT32* modeMap, UINT32 modeNum);

UINT32 BspHalAdaptTddSwModeSel(UINT32 tddSel,UINT32 modeSel);
#endif
/**************************************************************************
                            AC 相关接口
**************************************************************************/
//AC-SYNC
UINT32 BspHalAdaptSetACEn(UINT32 uiEn);
UINT32 BspHalAdaptSetAcSync33FrSel(UINT32 uiSel);
UINT32 BspHalAdaptSetACSyncModeSel(UINT32 uiSel);
UINT32 BspHalAdaptSetACSyncFrPeriodMode(UINT32 uiMode);
UINT32 BspHalAdaptSetACSyncSrcSel(UINT32 uiSel);
UINT32 BspHalAdaptSetACSyncCutMode(UINT32 uiMode);
UINT32 BspHalAdaptSetACSyncPulseWidth(UINT32 uiWidth);
UINT32 BspHalAdaptSetACSyncHighGate(UINT32 uiHighGate);

//AC天线校准---DL_BANK
UINT32 BspHalAdaptSetRamSel(UINT32 uiBlockId, UINT32 uiRamSel);
UINT32 BspHalAdaptGetRamSel(UINT32 uiBlockId, UINT32 *uiRamSel);
UINT32 BspHalAdaptSetAcPos(UINT32 uiBlockId, UINT32 uiAcPos);
UINT32 BspHalAdaptGetAcPos(UINT32 uiBlockId, UINT32 *uiAcPos);
UINT32 BspHalAdaptSetAcSyncClear(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiClr);
UINT32 BspHalAdaptGetAcSyncClear(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiClr);
UINT32 BspHalAdaptSetPostLongDlyTimesCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiPos);
UINT32 BspHalAdaptGetPostLongDlyTimesCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiPos);
UINT32 BspHalAdaptSetAcGainCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGainCa);
UINT32 BspHalAdaptGetAcGainCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGainCa);
UINT32 BspHalAdaptSetFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiId);
UINT32 BspHalAdaptGetFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiId);
UINT32 BspHalAdaptSetOdevityFlag(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFlag);
UINT32 BspHalAdaptGetOdevityFlag(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFlag);
UINT32 BspHalAdaptSetOdevityEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn);
UINT32 BspHalAdaptGetOdevityEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn);
UINT32 BspHalAdaptSetFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn);
UINT32 BspHalAdaptGetFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn);
UINT32 BspHalAdaptSetAc5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn);
UINT32 BspHalAdaptGetAc5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn);
UINT32 BspHalAdaptSetOptFrameIdMk(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiMask);
UINT32 BspHalAdaptGetOptFrameIdMk(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiMask);
UINT32 BspHalAdaptSetAcDataSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSelCa);
UINT32 BspHalAdaptGetAcDataSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSelCa);
UINT32 BspHalAdaptSetGpFrSelCaMod(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiMod);
UINT32 BspHalAdaptGetGpFrSelCaMod(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiMod);
UINT32 BspHalAdaptSetAcTddConfig(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTddCfg);
UINT32 BspHalAdaptGetAcTddConfig(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTddCfg);
UINT32 BspHalAdaptSetAc10msSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSelCa);
UINT32 BspHalAdaptGetAc10msSelCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSelCa);
UINT32 BspHalAdaptSetAcInsrtTimeCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTimeCa);
UINT32 BspHalAdaptGetAcInsrtTimeCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTimeCa);
UINT32 BspHalAdaptSetAcCaliEnCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn);
UINT32 BspHalAdaptGetAcCaliEnCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn);
UINT32 BspHalAdaptSetAcInsrtStartAddrCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiAddr);
UINT32 BspHalAdaptGetAcInsrtStartAddrCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiAddr);
UINT32 BspHalAdaptSetGpIdCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGpId);
UINT32 BspHalAdaptGetGpIdCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGpId);
UINT32 BspHalAdaptSetAcInsrtEndAddr(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiAddr);
UINT32 BspHalAdaptGetAcInsrtEndAddr(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiAddr);
UINT32 BspHalAdaptSetAcSeqLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiAcSeqLen);
UINT32 BspHalAdaptGetAcSeqLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiAcSeqLen);
UINT32 BspHalAdaptSetPreAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDly);
UINT32 BspHalAdaptGetPreAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDly);
UINT32 BspHalAdaptSetAcInsrtZeroNumCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiZeroNum);
UINT32 BspHalAdaptGetAcInsrtZeroNumCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiZeroNum);
UINT32 BspHalAdaptSetPostAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDly);
UINT32 BspHalAdaptGetPostAcInsrtDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDly);
UINT32 BspHalAdaptSetPostAcInsrtLongDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDly);
UINT32 BspHalAdaptGetPostAcInsrtLongDlyCa(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDly);
UINT32 BspHalAdaptSetTopDataSelCfg(UINT32 uiBlockId, UINT32 uiCarrId, UINT32 uiCfg);
UINT32 BspHalAdaptGetTopDataSelCfg(UINT32 uiBlockId, UINT32 uiCarrId, UINT32 *uiCfg);
UINT32 BspHalAdaptSetAcSync(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSync);
UINT32 BspHalAdaptGetAcSync(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSync);
UINT32 BspHalAdaptSetAcInsertTimes(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTimes);
UINT32 BspHalAdaptGetAcInsertTimes(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTimes);
UINT32 BspHalAdaptSetFrGpPha(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGpPha);
UINT32 BspHalAdaptGetFrGpPha(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGpPha);
UINT32 BspHalAdaptAcInsrtDataWrRam(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *pAcData, UINT32 uiAcDataLen);

//AC天线校准---UL_BANK
UINT32 BspHalAdaptSetUlchDataDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDlyCfg);
UINT32 BspHalAdaptGetUlchDataDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDlyCfg);
UINT32 BspHalAdaptSetUlchFrDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDlyCfg);
UINT32 BspHalAdaptGetUlchFrDelayCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDlyCfg);
UINT32 BspHalAdaptSetAccbBankRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg);
UINT32 BspHalAdaptGetAccbBankRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg);
UINT32 BspHalAdaptSetAccbFr5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 ui5msEn);
UINT32 BspHalAdaptGetAccbFr5msEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *ui5msEn);
UINT32 BspHalAdaptSetAccbFrNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFrNum);
UINT32 BspHalAdaptGetAccbFrNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFrNum);
UINT32 BspHalAdaptSetAccbFrameIdMask(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdMask);
UINT32 BspHalAdaptGetAccbFrameIdMask(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiIdMask);
UINT32 BspHalAdaptSetAccbFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiId);
UINT32 BspHalAdaptGetAccbFrameId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiId);
UINT32 BspHalAdaptSetAccbFr5msId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 ui5msId);
UINT32 BspHalAdaptGetAccbFr5msId(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *ui5msId);
UINT32 BspHalAdaptSetAccbDataRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg);
UINT32 BspHalAdaptGetAccbDataRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg);
UINT32 BspHalAdaptSetAccbGpvldRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg);
UINT32 BspHalAdaptGetAccbGpvldRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg);
UINT32 BspHalAdaptSetAccbChFr0RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouter0Cfg);
UINT32 BspHalAdaptGetAccbChFr0RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouter0Cfg);
UINT32 BspHalAdaptSetAccbChFr1RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouter1Cfg);
UINT32 BspHalAdaptGetAccbChFr1RouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouter1Cfg);
UINT32 BspHalAdaptSetAccbChRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg);
UINT32 BspHalAdaptGetAccbChRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg);
UINT32 BspHalAdaptSetAccbChBnkRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRouterCfg);
UINT32 BspHalAdaptGetAccbChBnkRouterCfg(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRouterCfg);
UINT32 BspHalAdaptSetAccbSnapEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiSnapEn);
UINT32 BspHalAdaptGetAccbSnapEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiSnapEn);
UINT32 BspHalAdaptSetAccbCbMode(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCbMode);
UINT32 BspHalAdaptGetAccbCbMode(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCbMode);
UINT32 BspHalAdaptSetAccbFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFrameIdEn);
UINT32 BspHalAdaptGetAccbFrameIdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFrameIdEn);
UINT32 BspHalAdaptSetAccbCycleNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCycleNum);
UINT32 BspHalAdaptGetAccbCycleNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCycleNum);
UINT32 BspHalAdaptSetAccbRssiEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiRssiEn);
UINT32 BspHalAdaptGetAccbRssiEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiRssiEn);
UINT32 BspHalAdaptSetAccbFreeCbEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 FreeCbEn);
UINT32 BspHalAdaptGetAccbFreeCbEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *FreeCbEn);
UINT32 BspHalAdaptSetAccbRamRdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn);
UINT32 BspHalAdaptGetAccbRamRdEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn);
UINT32 BspHalAdaptSetAccbHoldNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiHoldNum);
UINT32 BspHalAdaptGetAccbHoldNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiHoldNum);
UINT32 BspHalAdaptSetAccbGetNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiGetNum);
UINT32 BspHalAdaptGetAccbGetNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiGetNum);
UINT32 BspHalAdaptSetAccbDelayNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiDelayNum);
UINT32 BspHalAdaptGetAccbDelayNum(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiDelayNum);
UINT32 BspHalAdaptSetAccbVgaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiVgaDly);
UINT32 BspHalAdaptGetAccbVgaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiVgaDly);
UINT32 BspHalAdaptSetAccbFrTaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiTaDly);
UINT32 BspHalAdaptGetAccbFrTaDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiTaDly);
UINT32 BspHalAdaptSetAccbCbLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCbLen);
UINT32 BspHalAdaptGetAccbCbLength(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCbLen);
UINT32 BspHalAdaptSetAccbInslotWaitAbnml(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiInslot);
UINT32 BspHalAdaptGetAccbInslotWaitAbnml(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiInslot);
UINT32 BspHalAdaptSetAccbIntCnt(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiCnt);
UINT32 BspHalAdaptGetAccbIntCnt(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiCnt);
UINT32 BspHalAdaptSetAccbAcInslotDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiInslotDly);
UINT32 BspHalAdaptGetAccbAcInslotDelay(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiInslotDly);
UINT32 BspHalAdaptSetAccbAcInslotEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiEn);
UINT32 BspHalAdaptGetAccbAcInslotEn(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiEn);
UINT32 BspHalAdaptSetAccbFrMeas(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiFrMeas);
UINT32 BspHalAdaptGetAccbFrMeas(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *uiFrMeas);
UINT32 BspHalAdaptGetAccbDoneInt(UINT32 uiBlockId, UINT32 *uiInt); // ReadOnly
UINT32 BspHalAdaptSetAccbWarningClr(UINT32 uiBlockId, UINT32 uiClr);
UINT32 BspHalAdaptGetAccbWarningClr(UINT32 uiBlockId, UINT32 *uiClr);
UINT32 BspHalAdaptSetAccbDoneIntClr(UINT32 uiBlockId, UINT32 uiClr);
UINT32 BspHalAdaptGetAccbDoneIntClr(UINT32 uiBlockId, UINT32 *uiClr);
UINT32 BspHalAdaptSetAccbDoneIntEn(UINT32 uiBlockId, UINT32 uiEn);
UINT32 BspHalAdaptGetAccbDoneIntEn(UINT32 uiBlockId, UINT32 *uiEn);
UINT32 BspHalAdaptGetAccbVgaCoef(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdx, UINT32 *uiCoef);
UINT32 BspHalAdaptGetAccbVgaAbnml(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdx, UINT32 *uiAbnml);
UINT32 BspHalAdaptGetAccbVgaStatus(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 uiIdx, UINT32 *uiStatus);
UINT32 BspHalAdaptAcSampleDataRdRam(UINT32 uiBlockId, UINT32 uiAcIdx, UINT32 *pAcData, UINT32 *uiAcDataLen);


/**************************************************************************
                            光口相位补偿相关接口
**************************************************************************/
UINT32 BspHalAdaptGetPhaCompParaScsSymNum(UINT32 cellIdx, UINT32* scs, UINT32* symNum);
UINT32 BspHalAdaptCfgPhaCompVal(UINT32 cellIdx, UINT32 uDir, UINT32 *pPhaCompVal, UINT32 uLen);

/*************************************************************************
                             光口FFT相关
**************************************************************************/
UINT32 BspHalAdaptAcWgtSwitchByChnMap(UINT32 acType, UINT32 antMask, UINT32 swOnOrOff);
#if 0 /* 接口未使用，为清告警，屏蔽掉 */
UINT32 BspHalAdaptInitOptFftaPara(UINT32 cellId, UINT32 dir, UINT32 scs, T_FFTACfgPara* fftaPara);
UINT32 BspHalAdaptInitOptFftaHwCfg(VOID);
UINT32 BspHalAdaptPreCfgL1OptByWorkMode(UINT32 workMode);
#endif
/*************************************************************************
                             光口下行联合采数
**************************************************************************/
UINT32 BspHalAdaptSetCwHiPowRptEn(UINT32 enable);
UINT32 BspHalAdaptSetCwHiPowRptCfg(T_CwHiPowRtpInfo *ptCwHiPowRtpInfo, UINT32 num);


/*************************************************************************
                             光口远程硬复位
**************************************************************************/
UINT32 BspHalAdaptSetEcpriRemoteRst(UINT8 *pDestMac1,UINT8 *pDestMac2);

/* 远程掉电复位初始化配置 */
UINT32 BspHalAdaptSetCrmRmtPwdRstSrc(UINT32 uRstSrc);
/*远程掉电测试接口*/
UINT32 BspHalAdaptSetCrmRmtPwdRstTestEn(UINT32 uTestEn);
/* 远程掉电复位状态获取 */
UINT32 BspHalAdaptGetCrmRmtPwdRstSrc(UINT32 *pRstSrc);
/* 远程硬复位初始化配置 */
UINT32 BspHalAdaptSetCrmRmtHardRstSrc(UINT32 uRstSrc);

/**************************************************************************
                            时延相关接口
**************************************************************************/

UINT32 BspHalAdaptUpdateDifChanDelay(UINT32 difChan);
UINT32 BspHalAdaptUpdateDifCarrDelay(UINT32 difChan,UINT32 radioMod,UINT32 difCarrNo); 

UINT32 BspHalAdaptSetFrameAlignment(UINT32 bandId, UINT32 radioMode, INT32 frameDelay);//名称修改，后续ichal层去掉Bsp的该接口
UINT32 BspHalAdaptSetDl204AndRfDly(UINT32 dlDly);
UINT32 BspHalAdaptSetUl204AndRfDly(UINT32 ulDly);

UINT32 BspHalAdaptGetUeAdvVal(UINT32 uMode);
UINT32 BspHalAdaptSetUeAdvVal(UINT32 uMode, UINT32 uVal);
UINT32 BspHalAdaptGetUeGapVal(UINT32 uMode, UINT32 *uVal);

UINT32 BspHalAdaptGetUeAdvGapVal(UINT32 mode, UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp);
UINT32 BspHalAdaptSetTddIoUeAdvGapVal(UINT32 ueAdvValNs, UINT32 ueGapValNs, UINT32 mixModAdvComp);
UINT32 BspHalAdaptGetTddIoUeAdvGapVal(UINT32 *pUeAdvValNs, UINT32 *pUeGapValNs, UINT32 *pMixModAdvComp);

UINT32 BspHalAdaptSetFrameStruc(UINT32 uStrucUs);




/**************************************************************************
                            增益控制相关接口
**************************************************************************/
UINT32 BspHalAdaptSetDlCarrGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 carrDb);
UINT32 BspHalAdaptGetDlCarrGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pcarrDb);
UINT32 BspHalAdaptClrDlCarrGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex);
UINT32 BspHalAdaptSetDlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw);
UINT32 BspHalAdaptGetDlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw);
UINT32 BspHalAdaptGetDlPerCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw);
UINT32 BspHalAdaptGetDlBankAptuneCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw);
UINT32 BspHalAdaptSetUlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 sw);
UINT32 BspHalAdaptGetUlCarrGainSw(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pSw);
UINT32 BspHalAdaptSetCarrGainEn(UINT32 difChan);
UINT32 BspHalAdaptSetDlGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 carrDb);
UINT32 BspHalAdaptSetCarrBalanceGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 carrGain);
UINT32 BspHalAdaptGetCarrBalanceGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *pcarrGain);
UINT32 BspHalAdaptSetK0Gain(UINT32 uiDifChan, INT32 uiGain);
UINT32 BspHalAdaptGetK0Gain(UINT32 uiDifChan, INT32 *puiGain);
UINT32 BspHalAdaptSetK1Gain(UINT32 uiDifChan, INT32 uiGain);
UINT32 BspHalAdaptGetK1Gain(UINT32 uiDifChan, INT32 *puiGain);
UINT32 BspHalAdaptSetK2Gain(UINT32 uiDifChan, INT32 uiGain);
UINT32 BspHalAdaptGetK2Gain(UINT32 uiDifChan, INT32 *puiGain);
UINT32 BspHalAdaptSetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt);
UINT32 BspHalAdaptGetRxVgaGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *preAtt);
UINT32 BspHalAdaptSetRxPcGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 preAtt);
UINT32 BspHalAdaptGetRxPcGain(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, INT32 *preAtt);
UINT32 BspHalAdaptRxPcGain(INT32 preAtt);
UINT32 BspHalAdaptRxVgaGain(INT32 preAtt);
UINT32 BspHalAdaptSetAllAptuneSwitch(UINT32 sw);
UINT32 BspHalAdaptSetAnfCfg(UINT32 difChan, UINT32 uiCarrId, UINT32 uiRadioMode, T_RxAnfCarrCfg *ptAnfCfg);
UINT32 BspHalAdaptSetAnfClr();
UINT32 BspHalAdapt60msAlarm(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 *puiAlarm);
UINT32 BspHalAdaptGetGsmIqCfgFlag(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiCarrRadio, UINT32 *puiIqCfgFlag);
UINT32 BspHalRxDataOffEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRadioMode, UINT32 uiFlag);



/**************************************************************************
                            功率控制相关接口
**************************************************************************/
#define BSP_IC_DIF_BSP_MAX_TDD_NUM (4UL)
#define BSP_IC_DIF_VGA_LUT_TAB_NUM (4)
#define BSP_TX_CARR_SPLIT_NUM (10)
#define BSP_RX_CARR_SPLIT_NUM (8)
#define BSP_HALADAPT_POW_CALC_MOD_AVG (0U)       /** TSSI功率检测平均值模式 */
#define BSP_HALADAPT_POW_CALC_MOD_MAX (1U)       /** TSSI功率检测最大值值模式  */
#define BSP_HALADAPT_POW_CALC_TYPE_TSSI (0U)     /** TSSI功率检测经典类型 */
#define BSP_HALADAPT_POW_CALC_TYPE_PC_TSSI (1U)  /** TSSI功率检测PC类型 */
#define BSP_HALADAPT_RSSI_SHORT_FRAME (0U)       /** 短时RSSI功率检测类型 */
#define BSP_HALADAPT_RSSI_LONG_FRAME (1U)        /** 长时RSSI功率检测类型 */


typedef struct tagT_BspHalAdaptTssiChk
{
    INT32  TssiAsynMod;    /* tssi功率上报模式 0-同步于合载波 1-异步分载波独立 */
    UINT32 uibbTssiCalMod; /* bbtssi功率检测模式 0-平均值 1-最大值 */
    UINT32 uiTssiCalMod;   /* tssi功率检测模式 0-平均值 1-最大值 */
    UINT32 AvgThred;       /* 平均功率筛数门限的配置 */
    UINT32 SfLen;          /* 子帧长度配置 */
    UINT32 TssiEn;         /* 子帧使能配置 */
    UINT32 AvgSymLen;      /* 符号长度的配置 */
    UINT32 TxPwcStart;     /* TSSI功率检测起始位置配置 */
    UINT32 TxPwcEnd;       /* TSSI功率检测结束位置配置 */
    UINT32 PcPowEndNum;    /* pc在cpu强制模式下每个功率检测大周期的end个数 */
    UINT32 PcPowEndPrd;    /* pc的tssi合载波检测周期配置 */
}T_BspHalAdaptTssiCheck;

typedef struct tagT_BspHalAdaptRssiChk
{
    UINT32 SfLen;    /* rssi子帧长度配置，0.125ms/0.25ms/0.5ms/1ms，长、短时共用 */
    UINT32 RxStart;      /* 长时rssi功率检测开始位置配置 */
    UINT32 RxEnd;        /* 长时rssi功率检测结束位置配置 */
    UINT32 Rx1Start;    /* 短时rssi功率检测起始位置配置 */
    UINT32 Rx1End;      /* 短时rssi功率检测结束位置配置 */
    UINT32 RxSfEn;       /* rssi的子帧使能配置 */
    UINT32 Rx1SfEn;     /* 短时rssi的子帧使能配置 */
    UINT32 RssiCalGrp;   /* rssi功率检测组数配置 */
    UINT32 RssiCalThr;   /* rssi功率检测门限配置 */
    UINT32 Rssi1CalThr; /* 短时rssi功率检测门限配置 */
//后续考虑功率检测无线帧号配置及真好旁路；
}T_BspHalAdaptRssiCheck;

typedef struct tagT_BspHalAdaptPowCtrlPara
{
    UINT32 ifFwdPos;        //功率检测位置配置(nco、src的选择)
    UINT32 rfSwitchDly;     //射频开关切换延时配置
}T_BspHalAdaptPowCtrl_Para;

typedef struct tagT_BspHalAdaptPowCtrl
{
    UINT32 chanNoMask;      //中频通道号
    T_BspHalAdaptTssiCheck tTssiCheck;
    T_BspHalAdaptRssiCheck tRssiCheck;
    T_BspHalAdaptPowCtrl_Para tPowCtrlPara;
}T_BspHalAdaptPowCtrl;

typedef struct tagT_BspHalAdaptPowChkCfg
{
    UINT32 powNum;
    T_BspHalAdaptPowCtrl tPowCtrl[BSP_IC_DIF_BSP_MAX_TDD_NUM];
}T_BspHalAdaptPowChk_CfgAll;

typedef struct tagT_BspHalAdaptpow
{
    INT32 tssiPow;      //uint:0.01dBFs
    INT32 fwdPow;       //uint:0.01dBFs
}T_BspHalAdaptPowCfg;

typedef struct tagT_BspHalAdaptCarrPow
{
    UINT32 splitCarrNo;
    T_BspHalAdaptPowCfg tPowCfg;
}T_BspHalAdaptCarrPowCfg;

typedef struct tagT_BspHalAdaptVgaCtrlRfGain
{
    INT32 rfFixGain;            //16通道共用一个增益值，0.5db
    INT32 diffFacx;             //facx用于补偿各射频通道增益偏差，射频提供，0.1db
    UINT32 vgaMode;             //vga模式 VGA_MODE_AGC--表示AGC模式
    UINT32 agcJ204Switch;       // VGA_AGC_J204_ENABLE：J204传送slicer信息
    UINT32 agcSlicerBitNum;     //agc模式下slicer bit位宽;
    UINT32 agcSlicerDbStep;     //agc模式下slicer biUINT32 initVgaAgcCompPara(UINT32 chip,UINT32 j204En)t位宽;
    UINT32 vgaType;             //0- 90XX, 1-79XX;
    UINT32 vgaLutTab[BSP_IC_DIF_VGA_LUT_TAB_NUM];        // slicer表，目前看IC3中是四个寄存器
} T_BspHalAdaptVgaCtrlRfGain;

typedef struct tagT_BspHalAdaptvgaAgcPara
{
    UINT32 Kp;
    UINT32 CompIdx;
    UINT32 CompThr;
    UINT32 CompMode;
    UINT32 CompBypass;
    UINT32 CompUndecLen;
    UINT32 DcrmPt;
}T_BspHalAdaptVgaAgcPara;

UINT32 BspHalAdaptPowChkInit(T_BspHalAdaptPowChk_CfgAll *tPowChkCfg);
UINT32 BspHalAdaptSetAllSfPosFlag(UINT32 Enable);
UINT32 BspHalAdaptSetDtssiThred(INT32 Thred);
UINT32 BspHalAdaptSetIfTssiThred(INT32 Thred);
UINT32 BspHalAdaptSetSwCtrlStaLen(INT32 Period);
UINT32 BspHalAdaptReadBbTssiPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, INT32 *pBbTssi);
UINT32 BspHalAdaptGetDtssiErrorFlag(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, UINT32 *puiErrorFlag);
UINT32 BspHalAdaptDtssiErrorClr(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode);
UINT32 BspHalAdaptReadBbPcFwdPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode,T_BspHalAdaptPowCfg *pBbPcPow);
UINT32 BspHalAdaptReadFwdIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pFwdIfPow);
UINT32 BspHalAdaptReadRevIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pRevIfPow);
UINT32 BspHalAdaptReadPcFwdIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pPcFwdIfPow);
UINT32 BspHalAdaptReadPcRevIfPow(UINT32 difChan, T_BspHalAdaptPowCfg *pPcRevIfPow);
UINT32 BspHalAdaptReadSplitBbPcFwdPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, T_BspHalAdaptCarrPowCfg *pcFwd[BSP_TX_CARR_SPLIT_NUM], UINT32 *pCarrNum);
UINT32 BspHalAdaptReadRssiPow(UINT32 difChan, UINT32 radioMode, UINT32 carrIndex, UINT32 uiRssiType, INT32 *pRssiPow);
UINT32 BspHalAdaptReadSplitRssiPow(UINT32 difChan, UINT32 carrIndex, UINT32 radioMode, T_BspHalAdaptCarrPowCfg *pRssoPow[BSP_RX_CARR_SPLIT_NUM], UINT32 *pCarrNum);
UINT32 BspHalAdaptInitVga(T_BspHalAdaptVgaCtrlRfGain *ptVgaGain);
UINT32 BspHalAdaptInitVgaAgcPara(T_BspHalAdaptVgaAgcPara *ptVgaAgc);
UINT32 BspHalAdaptGetIcTemp(UINT32 difChan);
/* 根据光口GSCN和SSB,更新NR功率计算的符号位置 */
UINT32 BspHalAdaptSetTssiSubFramePos(VOID);
UINT32 BspHalSetVswrPowPosSrc1(UINT32 uiSrc1SampRate);

/**************************************************************************
                            配频相关接口
**************************************************************************/
//IC支持最大通道数的宏，Funclib统一使用，避免定义重复的宏
#ifdef DPDIC_4_2
#define BSP_HALADAPT_IC_CHAN_MAX_NUM (8)
#else
#define BSP_HALADAPT_IC_CHAN_MAX_NUM (32)    //old:BSP_IC_DIF_MAX_CHAN_NUM
#endif

//IC最大支持频段数，暂时为2，高频场景需要调整
#define BSP_IC_PERCHAN_BAND_NUM (2) 

typedef struct tagT_BspHalAdaptCarrInfo
{
    UINT32 delOrAddFlag;      /** 载波增删标志--0：保持；1：增加；2：删除*/
    UINT32 difCarrNo;         /** 中频载波号*/
    UINT32 carrFreq;          /** 载波频点*/
    UINT32 carrBw;            /** 载波带宽*/
    UINT32 carrRadio;         /** 载波制式*/
    UINT32 isSsb;             /** SSB载波标志*/
    UINT32 isRcf;             /** 载波是否需要过成型滤波器-0：不需要过成型；1：需要过成型滤波器*/
    UINT32 sideFilterSw;      /*  单边滤波标志 0：不进行单边滤波 1：需要单边滤波  */
    UINT32 uiCellId;
    UINT32 reserve;
}T_BspHalAdaptCarrInfo;

typedef struct _T_BspHalAdaptDifCfrCommPara
{
    UINT32 cfrGrade[BSP_HALADAPT_IC_CHAN_MAX_NUM];          /** 削峰级数 0：一级 1：二级 2：三级 */
    UINT32 cfrSample[BSP_HALADAPT_IC_CHAN_MAX_NUM];         /** 削峰采样率 */
    UINT32 cfrClk;                                          /** 削峰时钟 */
    UINT32 inter[BSP_HALADAPT_IC_CHAN_MAX_NUM];             /** 削峰内部上插倍数 0:1x 1:2x 2:4x 3:8x */
    UINT32 cpgPhase[BSP_HALADAPT_IC_CHAN_MAX_NUM];          /** CPG相数 0:1相 1:2相 2:4相 */
    UINT32 delayEqualFlag[BSP_HALADAPT_IC_CHAN_MAX_NUM];    /** 链路等延时标志，此参数不实际配寄存器，只做传递模式，等时延时cpg长度需要等长 1:等延时 */
    UINT32 cpgCoefLenHalfMax[BSP_HALADAPT_IC_CHAN_MAX_NUM]; /** CPG最大半长长度 */
    UINT32 cfrBypassMode[BSP_HALADAPT_IC_CHAN_MAX_NUM];     /** 削峰输出模式 0：零延时旁路 1：等延时旁路 */
    UINT32 cpgLen[BSP_HALADAPT_IC_CHAN_MAX_NUM];            /** 光口小区建立预制的最大的cpg长度 */
    UINT32 cfrPeakMode[BSP_HALADAPT_IC_CHAN_MAX_NUM];       /** 峰值检测电平模式配置：0：自检测包络模式  1：自检测包络+tdd时隙模式  2：tdd时隙模式 3：持续有效模式*/
} T_BspHalAdaptDifCfrCommPara;

T_BspHalAdaptDifCfrCommPara *BspHalAdaptGetDifCfrCommPara(VOID);
UINT32 BspHalAdaptGetCfrPhase2xFlag(UINT32 difChan, UINT32 *cfrPhase2xFlag);

typedef struct tag_BspHalAdaptFilterCoefCfg
{
    UINT32 radioMode;
    UINT32 bandWidth;
    UINT32 sampleRate;
    UINT32 uRLLCFlag;//超低延时标志
    UINT32 narrowBandFlag;
    UINT32 narrowBandVal;
    UINT32 *pCoefArray;
    UINT32 coefLen;
}T_BspHalAdaptFilterCoefCfg;
/* 判断给定载波是否当前配置中的有效载波 */
UINT32 BspHalAdaptCheckCarrValid(UINT32 dir, UINT32 difChan, UINT32 radio, UINT32 carrNo);
UINT32 BspHalAdaptSetTxCarrNco(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, INT32 offset);
UINT32 BspHalAdaptSetGsmCenterFreq(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, INT32 uiFreq);
UINT32 BspHalAdaptSetTxFreqNco(UINT32 difChan, UINT32 bandNo, INT32 offset);
UINT32 BspHalAdaptSetRxCarrNco(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, INT32 offset);
UINT32 BspHalAdaptSetTxFreqNco(UINT32 difChan, UINT32 difFreqId, INT32 offset);
UINT32 BspHalAdaptSetTxFreqNco2(UINT32 difChan, UINT32 bandNo, INT32 offset);
UINT32 BspHalAdaptSetRxFreqNco2(UINT32 difChan, UINT32 bandNo, INT32 offset);
UINT32 BspHalAdaptDlRcfFilterCoef(T_BspHalAdaptFilterCoefCfg *ptFilterCfg,UINT32 filterNum);
UINT32 BspHalAdaptUlRcfFilterCoef(T_BspHalAdaptFilterCoefCfg *ptFilterCfg,UINT32 filterNum);
UINT32 BspHalAdaptCbRcfFilterCoef(UINT32 *ptFilterCfg);
UINT32 BspHalAdaptGetDifBandFreq(UINT32 dir, UINT32 difChan, UINT32 *bandNum, UINT32 *bandFreq);
UINT32 BspHalAdaptGetDifCarrBandNo(UINT32 dir, UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, UINT32 *bandNo);
UINT32 BspHalAdaptGetFreqNco2Step(UINT32 dir, UINT32 difChan, UINT32 *step);
UINT32 BspHalAdaptGetCarrNcoStep(UINT32 dir, UINT32 difChan, UINT32 *step);
UINT32 BspHalAdaptNarrowBandSwitch(UINT32 difChan, UINT32 radioMode, UINT32 difCarrNo, UINT32 sw);
UINT32 BspHalAdaptDifInit(VOID);
UINT32 BspHalAdaptSetDifCarrId(UINT32 dir, UINT32 difChan, UINT32 radioMode, UINT32 carrId, UINT32 difCarrId);
UINT32 BspHalAdaptShowTxCarrCfg(UINT32 difChan);
UINT32 BspHalAdaptShowRxCarrCfg(UINT32 difChan);
UINT32 BspHalAdaptGetDifDpdSamRate(UINT32 difChan, UINT32 *pSamRate);
UINT32 BspHalAdaptGetDifCfrSamRate(UINT32 difChan, UINT32 *pSamRate);
UINT32 BspHalAdaptSetTxBankNco(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, INT32 offset);
UINT32 BspHalAdaptSetRxBankNco(UINT32 difChan, UINT32 difCarrNo, UINT32 radioMode, INT32 offset);
UINT32 BspHalAdaptSetDcBypass(UINT32 uiDifChan, UINT32 uiIsBypass);
UINT32 BspHalAdaptSetDcIirCoef(UINT32 uiDifChan, UINT32 uiIirCoef);
UINT32 BspHalAdaptSetDcMode(UINT32 uiDifChan, UINT32 uiDcMode);
UINT32 BspHalAdaptSetPbOrBbuMode(UINT32 mode);
VOID BspHalAdaptGfTdmCheckForQcell(VOID);
/**************************************************************************
                            场景预置相关接口
**************************************************************************/
#define BSP_PRE_ALLOC_MAX_BAND_NUM (16)

typedef struct tag_BspHalAdaptPreAllocBwInfo
{
    UINT32 index;
    UINT32 nrNum;
    UINT32 lteNum;
    UINT32 bandWidth[BSP_PRE_ALLOC_MAX_BAND_NUM];     //大带宽往前排，降序排列
}T_BspHalAdaptPreAllocBwInfo;


typedef struct tagT_BspHalAdaptPreAlloc
{
    UINT32 chanMask;
    T_BspHalAdaptPreAllocBwInfo preAllocBwInfo;
}T_BspHalAdaptPreAlloc;

UINT32 BspHalAdaptCfgPreAlloc(T_BspHalAdaptPreAlloc *ptPreAlloc, UINT32 dir, UINT32 num);
UINT32 BspHalAdaptGetPreAllocBwInfo(T_BspHalAdaptPreAllocBwInfo **ptAllocBw,UINT32 *num);
UINT32 BspHalAdaptClrPreAlloc(void);

/* 通知当前场景中未使用的资源位置 */
UINT32 BspHalAdaptUnusedResNotify(UINT32 dir, UINT32 chanMask, UINT32 preAllocIdx, UINT32 resIdx);

/**************************************************************************
 *                              光口小区配置相关
 *************************************************************************/
UINT32 BspHalAdaptOptL1CellPrachInfoInit(T_PrachCellInfo* prachCellInfo, UINT32 prachNum);
UINT32 BspHalAdaptOptCellInfoInit(T_CellCfgInfo* cellCfg, UINT32 txResIndex, UINT32 rxResIndex);
UINT32 BspHalAdapSetRvsTax(UINT32 uCellId, UINT32 uRadioMode, INT32 rvsTaxDL,INT32 rvsTaxUL);
UINT32 BspHalAdapSetFftFocVal(UINT32 uCellId, UINT32 radio, UINT32 dir, INT32 offset);
UINT32 BspHalAdaptOptCellCfg(UINT32 cellId);
UINT32 BspHalAdaptSetOptLinkTbl(T_Opt_Link_Tbl *pOptlink,UINT32 linkNum);
UINT32 BspHalAdaptInitOptEcpriCellInfo(T_EcpriCellStreamInfo *pPara,UINT32 dir);
UINT32 BspHalAdaptSetOptAntFlowMapInfo(T_OptAntFlowMapInfo*  optAntFlowMapInfoArr, UINT32 mapArrSize);
UINT32 BspHalAdaptLoadArmSlaveCore(UINT32 cpuCoreId, const CHAR* elfFilePath);
UINT32 BspHalAdaptR8MesgInterInit(VOID);
UINT32 BspHalAdaptLoadFirstCfg(UINT32 chipId,UINT32 cpuId);
UINT32 BspHalAdaptLoadSecondR8Cfg(UINT32 chipId, UINT32 cpuId, UINT32 r8No);
UINT32 BspHalAdaptLoadDspVer(UINT32 dspIndex, UINT8* buff, ULONG buffSize);
UINT32 BspHalAdaptLoadSecondCevaCfg(UINT32 chipId, UINT32 cpuId, UINT32 cevaNo);
UINT32 BspHalAdaptUpdataGscn(UINT32 uRadioMode, UINT32 uCellId, UINT32 uGscn, UINT32 uSsbValid);
UINT32 BspHalOptGfTdmCheck();
/**************************************************************************
                            反馈开关控制相关接口
**************************************************************************/
#define STATIC_FBRFRAM_DEEPTH (32) //每种状态32个ram深度
#define DPD_RFCHN_MAX    (32)   //DPD最大也是32chn
#define MAX_TRANS_CHIP_NUM (4)

//静态真值表是按天线顺序 ？还是按bspchn顺序往下排列   (0-31)*3   0-31  按BSPchn排列会好点（ichal查找前做个映射），CB或DPD按天线检测，去选择时转换为 bspchn来

//5bit/4bit+2bit/3bit+...  共10bit
typedef struct  tag_BspHalAdaptFbRfChnCtrl 
{
    uint16_t RfTrsChnCtrlSel;
    uint16_t RfTrsChnCtrlSel_len;
    uint16_t RfChnSel;
    uint16_t RfChnSel_len;
    uint16_t Res;
    uint16_t Res_len;

} T_BspHalAdaptFbRfChnCtrl;//不用的列，len为0

typedef struct  tag_BspHalAdaptFbRfChnCtrlSelTab 
{
    UINT32 rfCtlType; /* 0：反馈   1：反射  2：校准 */
    UINT32 chanNum; /* 实际通道个数,最大STATIC_FBRFRAM_DEEPTH */
    UINT16 fbRfStaticTab[STATIC_FBRFRAM_DEEPTH][MAX_TRANS_CHIP_NUM]; /* 每一行传4个transceiver参数,每个10bit;目前看这个数字4应该不可更改 */

} T_BspHalAdaptFbRfChnCtrlSelTab;

typedef struct tag_BspHalAdaptFbDPDChnSelTab 
{
    UINT32 chanNum;//天线总数
    T_BspHalAdaptFbRfChnCtrl FbDPDStaticT[DPD_RFCHN_MAX];//每一行传1个天线参数，只会涉及一个TRS
} T_BspHalAdaptFbDPDChnSelTab;//DPD选择天线的配置


/* 射频反馈 Ram0 配置结构 */
typedef struct  tag_BspHalAdaptFbPeriodChnSel 
{
    UINT8 firstChn; /* trs 第一个通道， 同时模式下才需要配置 */
    UINT8 tranId;   /* 非chnA ChnB对应的tranId 可用作DPD, 同时模式下才需要配置 */
    UINT8 status;   /* 该时间片任务，1：DPD 3:FWD 4:REV  */
    UINT8 chanA;    /* 通道选择RfTrsChnCtrlSel,无论单反馈还是双反馈都是 按静态表32行进行选择 */
    UINT8 chanB;    /* chanA,chanB的选择比较固化，不能太灵活，根据后端射频控制开关，相同TRS两个通道是绑定选择的;不同TRS各一个通道是需要一致开关控制的 */
    UINT16 period;  /* 时间片周期 单位ms */

} T_BspHalAdaptFbPeriodChnSel;

/* 反馈状态类型,HAL用 */
typedef enum E_HAL_RF_RAM_TYPE {
	E_HAL_RF_RAM_TYPE_FWD, 
	E_HAL_RF_RAM_TYPE_REV,
	E_HAL_RF_RAM_TYPE_CAL
} E_HAL_RF_FWD_STATUS;

UINT32 BspHalAdaptFbDPDChnSelTabInit(UINT32 type,T_BspHalAdaptFbDPDChnSelTab* DPDRfCtrlRam);

/* 射频反馈开关Ram1初始化，用于配置4选1,5选1开关, 每个tranceiver 对应10bit配置 */
UINT32 BspHalAdaptFbRfChnCtrlSelTabInit(T_BspHalAdaptFbRfChnCtrlSelTab* FbRfCtrlRam); 

/* 射频反馈开关Ram0初始化，用于配置反馈时间片轮寻 */
UINT32 BspHalAdaptStaFbChnSelRamInit(T_BspHalAdaptFbPeriodChnSel fbChnSelramArr[], UINT32 arrLen); 


/**************************************************************************
                            CRM相关接口
**************************************************************************/
#define CRM_IF1_SEL (1)
#define CRM_IF0_SEL (0)

UINT32 BspHalAdaptCrmPllInit(UINT32 isIF1, UINT32 pll4Enable);
UINT32 BspHalAdaptCrmSocClkFreqInit(VOID);
UINT32 BspHalAdaptCrmFftInit(VOID);
UINT32 BspHalAdaptCrmRoeInit(VOID);
UINT32 BspHalAdaptCrmOptInit(UINT32 isIF1);
UINT32 BspHalAdaptCrmDifClkFreqInit(VOID);
UINT32 BspHalAdaptCrmDifInit(VOID);
UINT32 BspHalAdaptCrmJ204ClkFreqInit(VOID);
UINT32 BspHalAdaptCrmPcsSetReset(UINT32 laneMask, UINT32 rstFlag);
UINT32 BspHalAdaptCrmNtlTopSetReset(UINT32 rstFlag);
UINT32 BspHalAdaptCrmNtlPtpSetReset(UINT32 rstFlag);
UINT32 BspHalAdaptCrmNtlXmacSetReset(UINT32 dir, UINT32 laneMask, UINT32 rstFlag);
UINT32 BspHapAdaptCrmGetIcTemp(UINT32 sensorId, INT32 *pTemp);
UINT32 BspHalAdaptCrmClrReset(VOID);
UINT32 BspHalAdaptCrmClrRefClkReset(VOID);
UINT32 BspHalAdaptCrmGetResetRecord(UINT32 regId, UINT32 *pRstRecord);
UINT32 BspHalAdaptCrmClrResetRecord(UINT32 regId);
UINT32 BspHalAdaptCrmGetResetReason(UINT32 regId, UINT32 *pRstReason);
UINT32 BspHalAdaptCrmClrResetReason(UINT32 regId);
UINT32 BspHalAdaptCrmGetPwrAlarm(UINT32 *pPwrAlarm);
UINT32 BspHalAdaptClrCrmPwrAlarm(UINT32 startBit, UINT32 endBit);
UINT32 BspHalAdaptCrmGetN8vAlarm(UINT32 *pN8VStat);

/**************************************************************************
                            栅压DAC复位接口
**************************************************************************/
UINT32 BspHalAdaptResetDacChip(UINT32 chip, UINT32 resetVal);


/**************************************************************************
                            节能相关接口
**************************************************************************/
UINT32 BspHalAdaptSetTxChanGateEn(UINT32 uiDifChan, UINT32 uiGateEn);                                  /** 下行通道级静态时钟门控使能的对外接口 */
UINT32 BspHalAdaptSetRxChanGateEn(UINT32 uiDifChan, UINT32 uiGateEn);                                  /** 上行通道级静态时钟门控使能的对外接口 */
UINT32 BspHalAdaptSetTxCarrGateEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRatio, UINT32 uiGateEn); /** 下行载波级静态时钟门控使能的对外接口 */
UINT32 BspHalAdaptSetRxCarrGateEn(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiRatio, UINT32 uiGateEn); /** 上行载波级静态时钟门控使能的对外接口 */
/* 中频未使用资源静态门控的控制接口 */
UINT32 BspHalAdaptSetTxUnusedGateEn(UINT32 gate); 
UINT32 BspHalAdaptSetRxUnusedGateEn(UINT32 gate);   

/* 下行tdd动态节电配置的对外接口 */
UINT32 BspHalAdaptSetTxTddEn(UINT32 difChan, UINT32 tddEn);
/* 上行tdd动态节电配置的对外接口 */
UINT32 BspHalAdaptSetRxTddEn(UINT32 difChan, UINT32 tddEn);

/* 关闭中频门控时钟(两个接口关闭范围不同，接口1用于深度休眠，接口2范围更大，用于全载波关断) */
UINT32 BspHalAdaptSetIcAllGateEn(UINT32 uiGateEn);
UINT32 BspHalAdaptSetIcAllGateEn2(UINT32 uiGateEn);
/* IC 中频Block级时钟门控控制 */
UINT32 BspHalAdaptSetBlockGateEn(UINT32 difChanMask, UINT32 uiGateEn);
/*FDD的空口帧头补偿标志下发*/
UINT32 BspHalAdaptSetFddAntFrCompFlag(UINT32 FlagVal);
/* DTX路由改配的对外接口 */
UINT32 BspHalAdaptSetDtxRoute(UINT32 difChan, UINT32 carrId, UINT32 radio, UINT32 routeEn);
/* DTX路由复位的对外接口 */
UINT32 BspHalAdaptDtxClrAllRoute(VOID);
/* 获取通道的符号节电次数的对外接口 */
UINT32 BspHalAdaptGetDtxChSymCnt(UINT32 difChan, UINT32 *pSymCnt);
/* 获取通道级符号节电时长的对外接口 */
UINT32 BspHalAdaptGetDtxChSymOffTime(UINT32 difChan, UINT32 *puiSymCntUs);
/* 通道清零接口 */
UINT32 BspHalAdaptSetDtxChSymCntClr(UINT32 difChan, UINT32 clrEn);
/* 光口节电接口 */
UINT32 BspHalAdaptSetOptSysPwrSaveSwitch(UINT32 sw);
/* 中频资源分配前后使用，用于控制未使用资源的门控使能 */
VOID BspHalAdaptSetDifUnusedResGateEn(UINT32 dir, UINT32 gateEn);

/* 配置IO是否合入GP(320载波全部一起配置),仅用于单板初始化 */
UINT32 BspHalAdaptSetDifIoGpEnAll(UINT32 en);

/* 中频DTX合入状态下，配置IO是否合入GP */
UINT32 BspHalAdaptSetDifIoGpEn(UINT32 en);

/* 关闭L2ss内外端口 */
UINT32 BspHalAdaptNtlL2ssSw(UINT32 sw);

/* 关闭Ceva,R8等其它核的CPU代理口 */
UINT32 BspHalAdaptCpuAgentPortSw(UINT32 coreMask, UINT32 sw);

/* 打开/关闭光口模块门控时钟 */
UINT32 BspHalAdaptSetOptAllGateSw(UINT32 sw);

/* 打开/关闭L2D门控时钟 */
UINT32 BspHalAdaptSetL2DGateSw(UINT32 sw);

/* 打开/关闭L2ss单个Trxp端口 */
UINT32 BspHalAdaptL2ssTrxpSwitch(UINT32 trxpIdx, UINT32 sw);

/* 打开/关闭单个Xmac端口 */
UINT32 BspHalAdaptNtlXmacSwitch(UINT32 xMacIdx, UINT32 sw);


/**************************************************************************
                            工装相关接口
**************************************************************************/
#define BSP_HALADAPT_UL_CH_BLOCK_NUM (64U)

#define E_PRBSMODE_J204 LBERT_MODE

UINT32 BspHalAdaptL2dCheckTest();
UINT32 BspHalAdaptSetTsgFlag(UINT32 wfsFlag);
UINT32 BspHalAdaptOptTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, UINT32 sw);
UINT32 BspHalAdaptPsyncCfg(UINT32 psyncMode);
UINT32 BspHalAdaptGetAntFrShake(UINT32 blockId, UINT32 *frShakeInt);
UINT32 BspHalAdaptOptTsgSwitch(UINT32 antChan, UINT32 carrNo, UINT32 radioMode, UINT32 tsgType, UINT32 sw);
UINT32 BspHalAdaptJ204SdsCheckError(UINT32 laneId, E_PRBSMODE_J204 prbsMode, UINT32 clr);
UINT32 BspHalAdaptJ204SdsSendPrbs(UINT32 laneId,E_PRBSMODE_J204 prbsMode);
UINT32 BspHalAdaptSetVgaByPass(UINT32 isBypass);
UINT32 BspHalAdaptSetVgaTransDbLut(UINT32 blockId, UINT32* vgaLutTab);
/*FWD检测cpu强制模式*/
UINT32 BspHalAdaptSetCpuForceOpen(UINT32 swIdx, UINT32 chan, UINT32 status, UINT32 period);
UINT32 BspHalAdaptSetCpuForceOff(UINT32 swIdx);
UINT32 BspHalAdaptGetFsyncStatus();
UINT32 BspHalAdaptGetAntFrShake(UINT32 blockId, UINT32 *frShakeInt);
UINT32 BspHalAdaptCrmGetRefDetStatusROE(UINT32 chipId, UINT32 *refStatus);
UINT32 BspHalAdaptCrmGetRefDetStatusOpt(UINT32 chipId, UINT32 *refStatus);
UINT32 BspHalAdaptCrmGetRefDetStatusJ204_0(UINT32 chipId, UINT32 *refStatus);
UINT32 BspHalAdaptCrmGetRefDetStatusJ204_1(UINT32 chipId, UINT32 *refStatus);
UINT32 BspHalAdaptCrmGetLockStatusPll(UINT32 chipId, UINT32 pllId, UINT32 *status);
UINT32 BspHalAdaptCrmGetUnLockRecordPll(UINT32 chipId, UINT32 pllId, UINT32 *status);
UINT32 BspHalAdaptCrmClrUnLockRecordPll(UINT32 chipId, UINT32 pllId);
UINT32 BspHalAdaptCrmGetUnLockCntPll(UINT32 chipId, UINT32 pllId, UINT32 *status);
UINT32 BspHalAdaptCrmAlmShortPwrENStat(UINT32 bitStart, UINT32 bitEnd, UINT32 *PwrEnStat);
UINT32 BspHalAdaptCrmAlmShortForceCloseState(UINT32 bitStart, UINT32 bitEnd, UINT32 *ArmShortState);
UINT32 BspHalAdaptCfgCrmAlmShortForceCloseState(UINT32 mode, UINT32 bitStart, UINT32 bitEnd);
UINT32 BspHalAdaptCfgCrmAlmShortPwrEN(UINT32 sta, UINT32 bitStart, UINT32 bitEnd);
UINT32 BspHalAdaptSetAcCtrlTop4Sel1(UINT32 uiTimingId, UINT32 uiSel);
UINT32 BspHalAdaptSetAcCtrlOeEn(UINT32 uiIdx, UINT32 uiEn);
UINT32 BspHalAdaptGetAcCtrlOeEn(UINT32 uiIdx, UINT32 *puiEn);
UINT32 BspHalAdaptGetAcCtrlTop4Sel1(UINT32 uiTimingId, UINT32 *puiSel);
UINT32 BspHalAdaptCrmClrUnLockCntPll(UINT32 chipId, UINT32 pllId);
UINT32 BspHalAdaptCrmClrRefDetStatus(UINT32 chipId);
UINT32 BspHalAdaptSyncOutOn(VOID);
UINT32 BspHalAdaptSyncOutOff(VOID);
UINT32 BspHalAdaptTrigOutOn(VOID);
UINT32 BspHalAdaptTrigOutOff(VOID);
UINT32 BspHalAdaptGetAntFrShakeInt(UINT32 uiBlockId, UINT32 *puiFrShakeInt);
UINT32 BspHalAdaptClrAntFrSharkeInt(UINT32 uiBlockId);
UINT32 BspHalAdaptCovertJ204toSdsLaneId(UINT32 dir, UINT32 j204LaneId);
UINT32 BspHalAdaptSetRevPowCalcAverNum(UINT32 num);
UINT32 BspHalAdaptSaveL2dGfData(UINT32 uCellId, UINT32 uDir,UINT32 uAnt, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum);
UINT32 BspHalAdaptCalcPowValByL2dData(UINT32 symId, UINT32 sigFreq, UINT32 carrFreq, DOUBLE* powVal);
UINT32 BspHalAdaptSetUlTddSwHigh(UINT32 uiDifChan,UINT32 uiHigh);
UINT32 BspHalAdaptSetDlTddSwHigh(UINT32 uiDifChan, UINT32 uiCarrId, UINT32 uiCarrRadio, UINT32 uiHgih);
UINT32 j204serdes_tx_prbs_en(UINT32 laneIdMask,UINT32 prbsMode,UINT32 bank);
UINT32 j204serdeshelp2(UINT32 phyIdMask, UINT32 laneIdMask, UINT32 bank);
UINT32 BspHalAdaptGetCpriProtocol(UINT32 *pulProtocol);
/**************************************************************************
                            功放保护
**************************************************************************/
UINT32 BspHalAdaptSetPaptBypass(UINT32 uiDifChan, UINT32 uiBypass);

/**************************************************************************
                            DPD 黑匣子相关
**************************************************************************/
BOOLEAN BspHalAdaptIsDspAbnormal(VOID);
BOOLEAN BspHalAdaptIsDspBbxFileReady(VOID);
BOOLEAN BspHalAdaptIsNeedSendNmiToDsp(VOID);
VOID BspHalAdaptSendNmiToDsp(VOID);
BOOLEAN BspHalAdaptWriteDspBbxFile(UINT32 bbxFileFlag);
UINT32  BspHalAdaptDspMonBoxInit(VOID);


/**************************************************************************
                            单板控制相关
**************************************************************************/
UINT32 BspHalAdaptGetBoardPwrAlm(UINT32 chipId, UINT32 *pBoardPwrStatus);
UINT32 BspHalAdaptClrBoardPwrAlm(UINT32 chipId, UINT32 uiClearCode);
UINT32 BspHalAdaptSetPaVoltByReg(UINT32 ulLevel);

/**************************************************************************
                            联合采数
**************************************************************************/
UINT32 BspHalAdaptSamplePowDetParaCfg(UINT32 powThrMin, UINT32 powDataLen, UINT32 timeMiniLen);
UINT32 BspHalAdaptSetPowThrodCfg(UINT32 difChan, UINT32 carrNo, UINT32 radioMode, UINT32 powPosition, UINT32 powMaxThrod);
UINT32 BspHalAdaptPowThrodStart(UINT32 powPosition);
UINT32 BspHalAdaptPowThrodIsDone(UINT32 powPosition,UINT32 *pFlag);
UINT32 BspHalAdaptPowThrodEnd(UINT32 powPosition);
UINT32 BspHalAdaptUpCombSmpL2dStart(UINT32 uCellId, UINT32 uDir,UINT32 uAnt, UINT32 uDifOrGfTmp, UINT32 uSlot, UINT32 uStartSym, UINT32 uSymbNum);
UINT32 BspHalAdaptUpCombSmpL2dSave(UINT32 uCellId, UINT32 uDifOrGfTmp);

/**************************************************************************
                            CFR相关接口
**************************************************************************/
UINT32 BspHalAdaptGetCfrSwitch(UINT32 difChn, UINT32 *CfrOnOff);
UINT32 BspHalAdaptGetCfrGate(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrGate, UINT32 gateNum);
UINT32 BspHalAdaptGetCfrWin(UINT32 difChn, UINT32 freqBand, UINT32 *pcfrWin, UINT32 gateNum);
UINT32 BspHalAdaptCfrGetPar(UINT32 difChn, UINT32 freqBand, UINT32 peakFlag, UINT32 workMode, UINT32 pos, UINT32 *cfrParData);
UINT32 BspHalAdaptDpdGetPar(UINT32 difChn, UINT32 freqBand, UINT32 peakFlag, UINT32 workMode, UINT32 *cfrParData);
UINT32 BspHalAdaptSetCfrParCfgFr(UINT32 difChn, UINT32 freqband, UINT32 frDly, UINT32 symParFlagPer, UINT32 frDivSel);

#ifdef __cplusplus

}
#endif
#endif 





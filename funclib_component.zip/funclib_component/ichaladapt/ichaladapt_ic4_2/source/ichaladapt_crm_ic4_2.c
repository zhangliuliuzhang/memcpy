/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_j204_ic4.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了j204相关ICHAL适配层接口函数实现
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
#include "ichaladapt_ic4_2.h"

#include "ichaladapt_crm_ic4_2.h"
#include "regaccess.h"

#include "ichalcrmapi.h"
#include "crmsoc.h"
#include "crmdif.h"

/************************************************************************************************
 CRM操作流程：
 1、SOC时钟是基于晶振的，在配置时钟芯片前进行配置，时钟芯片配置需要用到SPI，PAD，GPIO控制同样不依赖于时钟芯片
 2、配置时钟芯片
 3、配置PLL2和PLL3
 4、配置中频/光口时钟
 5、释放复位
 6、门控配置
 7、时钟选择
***********************************************************************************************/

/**************************************************************************
                            CRM相关接口
**************************************************************************/
/* 写A53复位寄存器 */
UINT32 BspHalAdaptCrmRecRegSet(UINT32 ulOffset, UINT32 ulBitStart, UINT32 ulBitEnd, UINT32 ulInitRec)
{
    return IcHalApiCfgCrmRec(0, ulOffset, ulBitStart, ulBitEnd, ulInitRec);
}

/* 读A53复位寄存器 */
UINT32 BspHalAdaptCrmRecRegGet(UINT32 ulOffset, UINT32 ulBitStart, UINT32 ulBitEnd, UINT32 *regVal)
{
    return IcHalApiGetCrmRec(0, ulOffset, ulBitStart, ulBitEnd, regVal);
}

/*CRM PLL初始化*/
UINT32 BspHalAdaptCrmPllParaInit(T_BspHalAdaptPllCrmPara *pCrmPllPara)
{
    UINT32 chip = 0;
    UINT32 ifType = 0;
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pCrmPllPara);

    /* 使能PLL3 */
    retVal = IcHalApiCrmDifPll3PwrOnCfg(chip);
    CHECK_RETVAL(IcHalApiCrmDifPll3PwrOnCfg,retVal);

    ifType = pCrmPllPara->ifType;
    /* IF1场景使能PLL2 */
    if(CRM_IF1_SEL == ifType)
    {   
        retVal |= IcHalApiCrmSocPll2PwrOnCfg(chip);
        CHECK_RETVAL_PRN(IcHalApiCrmSocPll2PwrOnCfg,retVal);     
    }
    return retVal;
}

/*CRM SOC时钟初始化*/
UINT32 BspHalAdaptCrmSocClkParaInit(T_BspHalAdaptSocCrmClk *pCrmSocClkPara)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pCrmSocClkPara);

    /* SPIFC1*/
    retVal = IcHalApiCrmSocSpifc1SetClkFreq(chip,pCrmSocClkPara->clk_spifc1_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc0SetClkFreq,retVal);

    /* SPIFC2*/
    retVal |= IcHalApiCrmSocSpifc2SetClkFreq(chip,pCrmSocClkPara->clk_spifc2_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    /* SPI0*/
    retVal |=IcHalApiCrmSPI0SetClkFreq(chip,pCrmSocClkPara->clk_spi0_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    /* SPI1*/
    retVal |= IcHalApiCrmSPI1SetClkFreq(chip,pCrmSocClkPara->clk_spi1_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    /* SPI2*/
    retVal |= IcHalApiCrmSPI2SetClkFreq(chip,pCrmSocClkPara->clk_spi2_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    /* SPI3*/
    retVal |= IcHalApiCrmSPI3SetClkFreq(chip,pCrmSocClkPara->clk_spi3_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    /* SPI4*/
    retVal |= IcHalApiCrmSPI4SetClkFreq(chip,pCrmSocClkPara->clk_spi4_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    /* SPI5*/
    retVal |= IcHalApiCrmSPI5SetClkFreq(chip,pCrmSocClkPara->clk_spi5_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    /* SPI6*/
    retVal |= IcHalApiCrmSPI6SetClkFreq(chip,pCrmSocClkPara->clk_spi6_sys);
    CHECK_RETVAL_PRN(IcHalApiCrmSocSpifc1SetClkFreq,retVal);

    return retVal;
}

/*CRM OPT时钟初始化*/
UINT32 BspHalAdaptCrmOptClkParaInit(T_BspHalAdaptOptCrmClk *pCrmOptClkPara)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pCrmOptClkPara);

    /* 光口可变时钟配置*/
    retVal = IcHalApiCrmDifOptVariableSetClkFreq(chip,pCrmOptClkPara->clk_opt_variable);
    CHECK_RETVAL(IcHalApiCrmDifOptVariableSetClkFreq,retVal);
    return retVal;
}

/*CRM Dif时钟初始化*/
UINT32 BspHalAdaptCrmDifClkParaInit(T_BspHalAdaptDifCrmClk *pCrmDifClkPara)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pCrmDifClkPara);

    /* 保存中频CRM时钟参数 */
    SaveDifCfg(E_DIF_CRMCLK_PARA, (VOID*)pCrmDifClkPara, 1, 1);

    /* ulch模块时钟频率初始化*/
    retVal = IcHalApiCrmDifULLogic1SetClkFreq(chip,pCrmDifClkPara->clk_ul_logic1_0,pCrmDifClkPara->clk_ul_logic1_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifULLogic1SetClkFreq,retVal);

    /* CFR模块时钟初始化*/
    retVal |= IcHalApiCrmDifDLLogic2SetClkFreq(chip,pCrmDifClkPara->clk_dl_logic2);
    CHECK_RETVAL_PRN(IcHalApiCrmDifDLLogic2SetClkFreq,retVal);

    /* 下行为DPD生成的时钟初始化*/
    retVal |= IcHalApiCrmDifDLLogic3SetClkFreq(chip,pCrmDifClkPara->clk_dl_logic3_0,pCrmDifClkPara->clk_dl_logic3_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifDLLogic3SetClkFreq,retVal);

    /* fb模块时钟初始化*/
    retVal |= IcHalApiCrmDifFBLogicSetClkFreq(chip,pCrmDifClkPara->clk_fb_logic1_0,pCrmDifClkPara->clk_fb_logic1_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifFBLogicSetClkFreq,retVal);

    /* 下行J204 map work时钟初始化*/
    retVal |= IcHalApiCrmDifDLJ204SetClkFreq(chip,pCrmDifClkPara->clk_dl_j204_work_0,pCrmDifClkPara->clk_dl_j204_work_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifDLJ204SetClkFreq,retVal);

    /* 反馈J204work时钟初始化*/
    retVal |= IcHalApiCrmDifFBJ204SetClkFreq(chip,pCrmDifClkPara->clk_fb_j204_work);
    CHECK_RETVAL_PRN(IcHalApiCrmDifFBJ204SetClkFreq,retVal);

    /* 上行J204work时钟初始化*/
    retVal |= IcHalApiCrmDifULJ204SetClkFreq(chip,pCrmDifClkPara->clk_ul_j204_work);
    CHECK_RETVAL_PRN(IcHalApiCrmDifULJ204SetClkFreq,retVal);

    return retVal;
}

/*CRM Dif时钟选择初始化*/
UINT32 BspHalAdaptCrmDifClkSelectParaInit(T_BspHalAdaptDifCrmClkSelect *pCrmDifClkSelectPara)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    INPUT_POINTER_CHECK(pCrmDifClkSelectPara);

    /* 保存中频CRM时钟选择参数 */
    SaveDifCfg(E_DIF_CRMCLK_SEL, (VOID*)pCrmDifClkSelectPara, 1, 1);

    /*ulch blk时钟选择*/
    retVal = IcHalApiCrmDifSetUlChLogicMuxClk(chip,(CRM_DIF_CFG_MUX_CLK_ULCH_TYPE)pCrmDifClkSelectPara->mux_clk_ulch_0,(CRM_DIF_CFG_MUX_CLK_ULCH_TYPE)pCrmDifClkSelectPara->mux_clk_ulch_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifSetUlChLogicMuxClk,retVal);

    /*dlpsot blk时钟选择*/
    retVal |= IcHalApiCrmDifSetDlPostLogicMuxClk(chip,(CRM_DIF_CFG_MUX_CLK_DLPOST_TYPE)pCrmDifClkSelectPara->mux_clk_dlpost_0,(CRM_DIF_CFG_MUX_CLK_DLPOST_TYPE)pCrmDifClkSelectPara->mux_clk_dlpost_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifSetDlPostLogicMuxClk,retVal);
    
    /* DPD blk1(PIMC)工作时钟选择*/
    retVal |= IcHalApiCrmDifSetDlLogic6MuxClk(chip,(CRM_DIF_LOGIC_CLK_6_SELL_TYPE)pCrmDifClkSelectPara->mux_clk_dl_logic6);
    CHECK_RETVAL_PRN(IcHalApiCrmDifSetDlLogic6MuxClk,retVal);

    retVal |= IcHalApiCrmDifSetCFRMuxClk(chip,(CRM_DIF_LOGIC_CLK_6_SELL_TYPE)pCrmDifClkSelectPara->mux_clk_dl_logic6);
    CHECK_RETVAL_PRN(IcHalApiCrmDifSetCFRMuxClk,retVal);
    
    /*反馈fb的时钟选择*/
    retVal |= IcHalApiCrmDifSetFBMuxClk(chip,(CRM_DIF_CFG_MUX_CLK_FB_TYPE)pCrmDifClkSelectPara->mux_clk_fb0,(CRM_DIF_CFG_MUX_CLK_FB_TYPE)pCrmDifClkSelectPara->mux_clk_fb1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifSetFBMuxClk,retVal);

    /*LMS用到时钟，BSP初始化为0，DSP根据需要动态切换*/
    retVal |= IcHalApiCrmDifSetCBLMSMuxClk(chip,(CRM_DIF_CFG_MUX_CLK_CBLMS_TYPE)pCrmDifClkSelectPara->mux_clk_cblms);
    CHECK_RETVAL_PRN(IcHalApiCrmDifSetCBLMSMuxClk,retVal);

    retVal |= IcHalApiCrmDifJ204SetFBMuxClk(chip,(CRM_DIF_CFG_MUX_CLK_J204_FB_TYPE)pCrmDifClkSelectPara->mux_clk_j204_fb_logic2_0,(CRM_DIF_CFG_MUX_CLK_J204_FB_TYPE)pCrmDifClkSelectPara->mux_clk_j204_fb_logic2_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifJ204SetFBMuxClk,retVal);
    retVal |= IcHalApiCrmDifJ204SetDLMuxClk(chip,(CRM_DIF_CFG_MUX_CLK_J204_DL_TYPE)pCrmDifClkSelectPara->mux_clk_j204_dl_logic5_0,(CRM_DIF_CFG_MUX_CLK_J204_DL_TYPE)pCrmDifClkSelectPara->mux_clk_j204_dl_logic5_1);
    CHECK_RETVAL_PRN(IcHalApiCrmDifJ204SetDLMuxClk,retVal);
    retVal |= IcHalApiSetClkJ204FbLogic3_0(0, pCrmDifClkSelectPara->mux_clk_j204_fb_logic3_0);
    CHECK_RETVAL_PRN(IcHalApiSetClkJ204FbLogic3_0,retVal);
    retVal |= IcHalApiSetClkJ204FbLogic3_1(0, pCrmDifClkSelectPara->mux_clk_j204_fb_logic3_1);
    CHECK_RETVAL_PRN(IcHalApiSetClkJ204FbLogic3_1,retVal);
    retVal |= IcHalApiSetClkJ204DlLogic4_0(0, pCrmDifClkSelectPara->mux_clk_j204_dl_logic4_0);
    CHECK_RETVAL_PRN(IcHalApiSetClkJ204DlLogic4_0,retVal);
    retVal |= IcHalApiSetClkJ204DlLogic4_1(0, pCrmDifClkSelectPara->mux_clk_j204_dl_logic4_1);
    CHECK_RETVAL_PRN(IcHalApiSetClkJ204DlLogic4_1,retVal);
    retVal |= IcHalApiSetClkJ204UlLogic2_0(0, pCrmDifClkSelectPara->mux_clk_j204_ul_logic2_0);
    CHECK_RETVAL_PRN(IcHalApiSetClkJ204UlLogic2_0,retVal);
    retVal |= IcHalApiSetClkJ204UlLogic2_1(0, pCrmDifClkSelectPara->mux_clk_j204_ul_logic2_1);
    CHECK_RETVAL_PRN(IcHalApiSetClkJ204UlLogic2_1,retVal);

    /* J204 Sysref时钟选择 */
    retVal |= IcHalApiCrmDifJ204SetSysrefMuxClk(chip,(CRM_DIF_CFG_MUX_CLK_J204_SYSREF_TYPE)pCrmDifClkSelectPara->mux_clk_j204_sysref);
    CHECK_RETVAL_PRN(IcHalApiCrmDifJ204SetSysrefMuxClk,retVal);

    return retVal;
}

UINT32 BspHalAdaptCrmCommonRstParaInit(T_BspHalAdaptCrmRstCommonPara *pCrmComRstPara)
{
    UINT32 chip = 0;
    UINT32 retVal = BSP_OK;
    if(pCrmComRstPara == NULL)
    {
        /*ROE释放复位*/
        retVal = IcHalApiCrmRoeSetReset(chip,1);
        CHECK_RETVAL_PRN(IcHalApiCrmRoeSetReset,retVal);

        /*OPT释放复位*/
        retVal |= IcHalApiCrmOptSetReset(chip,1);
        CHECK_RETVAL_PRN(IcHalApiCrmOptSetReset,retVal);
        retVal |= IcHalApiCrmPrachSetReset(chip,1);
        CHECK_RETVAL_PRN(IcHalApiCrmPrachSetReset,retVal);

        /*FFT/prach释放复位*/
        retVal |= IcHalApiCrmFftSetReset(chip,1);
        CHECK_RETVAL_PRN(IcHalApiCrmFftSetReset,retVal);

        /*中频释放复位*/
        retVal |= IcHalApiCrmDifSetResetAll(chip,1);
        CHECK_RETVAL_PRN(IcHalApiCrmDifSetResetAll,retVal);

        /*门控去使能*/
        retVal |= IcHalApiCrmGateDisableAll(chip,0);
        CHECK_RETVAL_PRN(IcHalApiCrmGateDisableAll,retVal);

        return retVal;
    }
    
    /*ROE释放复位*/
    retVal = IcHalApiCrmRoeSetReset(chip,pCrmComRstPara->rst_roe);
    CHECK_RETVAL_PRN(IcHalApiCrmRoeSetReset,retVal);

    /*OPT释放复位*/
    retVal |= IcHalApiCrmOptSetReset(chip,pCrmComRstPara->rst_opt);
    CHECK_RETVAL_PRN(IcHalApiCrmOptSetReset,retVal);

    /*FFT/prach释放复位*/
    retVal |= IcHalApiCrmFftSetReset(chip,pCrmComRstPara->rst_fft_pranch);
    CHECK_RETVAL_PRN(IcHalApiCrmFftSetReset,retVal);
    retVal |= IcHalApiCrmPrachSetReset(chip,pCrmComRstPara->rst_fft_pranch);
    CHECK_RETVAL_PRN(IcHalApiCrmPrachSetReset,retVal);

    /*中频释放复位*/
    retVal |= IcHalApiCrmDifSetResetAll(chip,pCrmComRstPara->rst_dif);
    CHECK_RETVAL_PRN(IcHalApiCrmDifSetResetAll,retVal);

    /*门控去使能*/
    retVal |= IcHalApiCrmGateDisableAll(chip,0);
    CHECK_RETVAL_PRN(IcHalApiCrmGateDisableAll,retVal);

    return retVal;
}

UINT32 BspHalAdaptCrmGfBifDifSetReset(UINT32 chip, UINT32 rstFlag)
{
    return IcHalApiCrmGfBifDifSetReset(chip, rstFlag);
}

/* Started by AICoder, pid:ncd74z8622h6f0114b8d0bd8e0d06b085c76964c */
UINT32 BspHalAdaptCrmSocPll2PwrDivEnDis(UINT32 chip, UINT32 sw)
{
    return IcHalApiCrmSocPll2PwrDivEnDis(chip, sw);
}
/* Ended by AICoder, pid:ncd74z8622h6f0114b8d0bd8e0d06b085c76964c */
/* Started by AICoder, pid:m2667m0efco5ebf1412d0863806b230301b5ccf2 */
UINT32 BspHalAdaptCrmSocPll3PwrDivEnDis(UINT32 sw)
{
    return IcHalApiCrmSocPll3PwrDivEnDis(sw);
}
/* Ended by AICoder, pid:m2667m0efco5ebf1412d0863806b230301b5ccf2 */
/* Started by AICoder, pid:y7822w621854a9f1484209bd40991f086995a305 */
UINT32 BspHalAdaptCrmCfgPrachFftMode(UINT32 chip, UINT32 modeBitMap)
{
    return IcHalApiCrmCfgPrachFftMode(chip, modeBitMap);
}
/* Ended by AICoder, pid:y7822w621854a9f1484209bd40991f086995a305 */

static UINT32 GetJ204SysrefClkSel(UINT32 *clkSel)
{
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_CRMCLK_SEL);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_BspHalAdaptDifCrmClkSelect *pPara = (T_BspHalAdaptDifCrmClkSelect *)(pSaveCfg->pAddr);
    if(NULL == pPara)
    {
        return BSP_ERROR;
    }
    *clkSel = pPara->mux_clk_j204_sysref;

    return BSP_OK;
}

static UINT32 GetDifDlLogic3ClkPara(UINT32 *clk0, UINT32 *clk1)
{
    T_DifCfgSave* pSaveCfg = NULL;

    pSaveCfg = GetDifCfgSave(E_DIF_CRMCLK_PARA);
    if(NULL == pSaveCfg)
    {
        return BSP_ERROR;
    }
    
    T_BspHalAdaptDifCrmClk *pPara = (T_BspHalAdaptDifCrmClk *)(pSaveCfg->pAddr);
    if(NULL == pPara)
    {
        return BSP_ERROR;
    }
    *clk0 = pPara->clk_dl_logic3_0;
    *clk1 = pPara->clk_dl_logic3_1;

    return BSP_OK;
}

UINT32 BspHalAdaptGetJ204SysrefClk(UINT32 *sysrefClk)
{
    UINT32 j204ClkSel = 0;
    UINT32 clklogic3_0 = 0;
    UINT32 clklogic3_1 = 0;

    if(GetJ204SysrefClkSel(&j204ClkSel) == BSP_OK)
    {
        if(GetDifDlLogic3ClkPara(&clklogic3_0, &clklogic3_1) == BSP_OK)
        {
            if(j204ClkSel == CRM_J204_CLK_DL_LOGIC3_0)
            {
                *sysrefClk = clklogic3_0;
            }
            else if(j204ClkSel == CRM_J204_CLK_DL_LOGIC3_1)
            {
                *sysrefClk = clklogic3_1;
            }
            else 
            {
                return BSP_ERROR;
            }
        }
        else 
        {
           return BSP_ERROR; 
        }
    }
    else 
    {
       return BSP_ERROR; 
    }

    return BSP_OK;
}

UINT32 BspHalAdaptGetIcCalibrationTemp(INT32 *temp0, INT32 *temp1)
{
    return IcHalApiCrmGetIcCalibrationTempNew(0, 0, temp0, temp1);
}

UINT32 BspHalAdaptSetSoc25MClkOutEnable(UINT32 ulSw)
{
    UINT32 retVal = 0;
    retVal = IcHalApiSetSoc25MClkOutEnable(ulSw);
    return retVal;
}

UINT32 BspHalAdaptCfgSetCrmFifteenthRecordReg(UINT32 regVal, UINT32 bitStart, UINT32 bitEnd)
{
    return IcHalApiCfgSetCrmFifteenthRecordReg(regVal, bitStart, bitEnd);
}

UINT32 BspHalAdaptCfgGetCrmFifteenthRecordReg(UINT32 bitStart, UINT32 bitEnd, UINT32 *regVal)
{
    return IcHalApiCfgGetCrmFifteenthRecordReg(bitStart, bitEnd, regVal);
}

UINT32 BspHalAdaptCfgSetCrmRecordReg(UINT32 regVal,  UINT32 bitStart,  UINT32 bitEnd)
{
    return IcHalApiCfgSetCrmRecordReg(regVal, bitStart, bitEnd);
}

UINT32 BspHalAdaptCfgGetCrmRecordReg(UINT32 bitStart, UINT32 bitEnd, UINT32 *status)
{
    return IcHalApiCfgGetCrmRecordReg(bitStart, bitEnd, status);
}



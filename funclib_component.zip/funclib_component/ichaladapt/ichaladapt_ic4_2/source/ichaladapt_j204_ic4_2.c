/*****************************************************************************
* 版权所有(C) 2020, ZTE Corp. ZXSDR-RRU Platform BSP
*----------------------------------------------------------------------------
* 模 块 名 : bsp
* 文件名称 : ichaladapt_j204_ic4.c
* 文件标识 : {[N/A]}
* 内容摘要 : 本文件提供了j204相关ICHAL适配层接口函数实现
* 注意事项 : 无
* 作    者 : 王涛10248577
* 创建日期 : 2020-11-04
* 当前版本 : Ver1.0
*----------------------------------------------------------------------------
* 变更记录 :
*
* $记录1
* 变 更 单: $0000000(N/A)
* 责 任 人: 王涛10248577
* 修改日戳: 2020-11-04
* 变更说明: 创建文件
*----------------------------------------------------------------------------
*/
//#include "ichaladapt_ic4_2.h"
#include "bsppub.h"
#include "exprn.h"
//#include "ichaladaptbspapi.h"
#include "ichaladapt_j204_ic4_2.h"
#include "j204_api.h"
#include "j204_serdes_api.h"
#include "crmdif.h"
#include "jitter_cfg.h"

/*  */
#ifdef ADS_204_LOOP_TEST
//#define J204_SERDES_RETURN_OK
//#define J204_CRM_RETURN_OK
#endif

#ifdef PLAT_X86_TEST
#define J204_SERDES_RETURN_OK
#endif

/**************************************************************************
                            J204c 结构说明
**************************************************************************/
/*
J204 lane和Serdes lane的对应关系
204inf0: |                      block0                       |
serdes   |          ip0            |           ip1           |
serdes   | lane0 lane1 lane2 lane3 | lane0 lane1 lane2 lane3 |
serdes   | lane0 lane1 lane2 lane3   lane4 lane5 lane6 lane7 |   *serdes lane
j204c    |  tx0   tx1   tx2   tx3  |  tx4   tx5   tx6   tx7  |
j204c    |  rx0   rx1   rx2   rx3  |  fb0   fb1   fb2   fb3  |   *204 lane
射频       |  fb0   fb1   rx0   rx1  |  fb2   fb3   rx2   rx3  |
*/

/**************************************************************************
                                全局变量定义
**************************************************************************/

//static UINT32 s_J204MapLaneMask[DPDIC_J204_MAP_NUM_MAX][PRX+1] = {0};

//UINT32 j204cRxLane2SerdesLaneMap[J204C_SERDES_LANE_MAX] = {2,3,6,7,0,0,0,0};
//UINT32 j204cFbLane2SerdesLaneMap[J204C_SERDES_LANE_MAX] = {0,1,4,5,0,0,0,0};

/**************************************************************************
                            J204c 公共接口
**************************************************************************/
/* 由J204 lane掩码转换为Serdes lane掩码 */
UINT32 BspHalAdaptJ204GetSerdesLaneMask(UINT32 dir, UINT32 j204LaneMask)
{
    UINT32 serdesLaneMask = 0;

    if(TX == dir)
    {   
        serdesLaneMask = j204LaneMask;
    }
    else if(RX == dir)
    {
        serdesLaneMask = j204LaneMask;
    }
    else
    {
        serdesLaneMask = j204LaneMask << 4;
    }

    return serdesLaneMask;
}

/* 根据J204 lane掩码获取Block号(DPDIC4.2只有一个block，故固定为0) */
static UINT32 GetJ204CBlockIdByJ204LaneMask(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 blockId = 0;

    /* DPDIC4.2中只有一个block，固定为0 */
    
    return blockId;
}

/* 根据J204 lane掩码判断是否使用了全部的lane */
UINT32 BspHalAdaptJ204IsFullLane(UINT32 dir, UINT32 laneMask)
{
    if(TX == dir && 0xFF == laneMask)
    {
        return 1;
    }
    else if((RX == dir || PRX == dir) && 0xF == laneMask)
    {
        return 1;
    }
    else 
    {
        return 0;
    }
}

#if 0 /* 适配层接口增加mapMask，故以下接口不再使用了 */
/* 根据J204 lane掩码获取需要进行复位操作的Map掩码 */
static UINT32 GetJ204MapMaskByJ204LaneMask(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 mapId = 0;
    UINT32 fullMapMask = 0x3;
    UINT32 mapMask = 0;

    /* 使用了全部Lane，则操作全部Map */
    if(BspHalAdaptJ204IsFullLane(dir, laneIdMask))
    {
        return fullMapMask;    
    }

    /* 仅Grp0(Map0)使用，Grp1(Map1)未使用时，操作全部Map */
    if(s_J204MapLaneMask[0][dir] && (!s_J204MapLaneMask[1][dir]))
    {
        return fullMapMask;  
    }

    /* Grp0(Map0)，Grp1(Map1)仅使用时，按照掩码选择Map */
    for(mapId=0; mapId<DPDIC_J204_MAP_NUM_MAX; mapId++)
    {
        if(s_J204MapLaneMask[mapId][dir] & laneIdMask)
        {
            mapMask = BIT_SET(mapId);
        }
    }
    
    return mapMask;
}

UINT32 BspHalAdaptJ204SetGrpLaneMask(UINT32 grpId, UINT32 dir, UINT32 laneIdMask)
{
    if(grpId >= DPDIC_J204_MAP_NUM_MAX || dir > PRX)
    {
        return BSP_ERROR;
    }
    s_J204MapLaneMask[grpId][dir] = laneIdMask;
    return BSP_OK;
}
#endif
/**************************************************************************
                            J204c serders相关接口
**************************************************************************/
UINT32 BspHalAdaptJ204cSerdesLoadFrmware(UINT32 laneIdMask, UINT32 txDataRate, UINT32 rxDataRate)
{
#ifdef J204_SERDES_RETURN_OK
    return BSP_OK;
#endif

    return IcHalApiJ204SdsLoadFw(laneIdMask, txDataRate, rxDataRate,(BOOL)1);
}

UINT32 BspHalAdaptJ204SerdesPhyApbRst(UINT32 txLaneIdMask,UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;

#ifdef J204_SERDES_RETURN_OK
    return BSP_OK;
#endif

    //blockId = GetJ204CBlockIdByJ204LaneMask(TX,txLaneIdMask);
    retVal = IcHalApiPhyApbResetCfg(rstFlag);
    return retVal;
}

UINT32 BspHalAdaptJ204cSerdesPowerOn(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 powerOn = 1;
#ifdef J204_SERDES_RETURN_OK
    return BSP_OK;
#endif

    if(TX == dir)
    {
        return IcHalApiJ204SdsTxPwron(laneIdMask, powerOn);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxPwron(laneIdMask, powerOn);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;    
}

UINT32 BspHalAdaptJ204cSerdesPowerDown(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 powerOn = 0;
#ifdef J204_SERDES_RETURN_OK
     return BSP_OK;
#endif

    if(TX == dir)
    {
        return IcHalApiJ204SdsTxPwron(laneIdMask, powerOn);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxPwron(laneIdMask, powerOn);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;    
}

UINT32 BspHalAdaptJ204cSerdesInit(UINT32 dir, UINT32 laneIdMask, UINT32 dataRate)
{
#ifdef J204_SERDES_RETURN_OK
    return BSP_OK;
#endif

    if(TX == dir)
    {
        return IcHalApiJ204SdsTxDataEn(laneIdMask,1);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxDataEn(laneIdMask,1);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspHalAdaptJ204cSerdesTrxEn(UINT32 dir, UINT32 laneIdMask, UINT32 en)
{
#ifdef J204_SERDES_RETURN_OK
    return BSP_OK;
#endif

    if(TX == dir)
    {
        return IcHalApiJ204SdsTxDataEn(laneIdMask,en);
    }
    else if(RX == dir)
    {
        return IcHalApiJ204SdsRxDataEn(laneIdMask,en);
    }
    else 
    {
        return BSP_ERROR;
    }
    return BSP_OK;
}

UINT32 BspHalAdaptAdjustJ204SerdesTxEq(UINT32 laneIdMask,UINT32 eqPre,UINT32 eqPost,UINT32 eqMain)
{
#ifdef J204_SERDES_RETURN_OK
    return BSP_OK;
#endif

    return IcHalApiAdjustJ204SerdesTxEq(laneIdMask,eqPre,eqPost,eqMain);
}

/**************************************************************************
                            J204c block相关接口
**************************************************************************/
UINT32 BspHalAdaptJ204LinkInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pLinkInfo, UINT32 linkSize)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    INPUT_POINTER_CHECK(pLinkInfo)

    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask);
    retVal = IcHalApiJ204LinkInit(blockId, pLinkInfo, linkSize);
    return retVal;
}

UINT32 BspHalAdaptJ204MapInit(UINT32 dir, UINT32 laneIdMask, UINT32 *pMapInfo, UINT32 mapSize)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    INPUT_POINTER_CHECK(pMapInfo)

    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask);
    retVal = IcHalApiJ204MapInit(blockId, pMapInfo, mapSize);
    return retVal;
}

UINT32 BspHalAdaptSysrefRequest(T_BspHalAdaptSysrefCfg *pSysrefCfg)
{
    UINT32 pinId = 0;
    UINT32 retVal = BSP_OK;
    UINT32 txEnMask = 0;
    UINT32 loop = 0;
    T_DifSysrefCfg halSysrefCfg;
    INPUT_POINTER_CHECK(pSysrefCfg);

    memset(&halSysrefCfg, 0, sizeof(T_DifSysrefCfg));

    for(loop=0; loop<DPDIC_SYSREF_PIN_MAX_NUM; loop++)
    {
        if((0x1<<loop) & pSysrefCfg->tsEnable)
        {
            BspHalAdaptGetTrxPinId(loop, &pinId);
            txEnMask |= (0x1<<pinId);
            dbgInfoEx("%s chip=%d pinId=%d txEnMask=%#x\n", __func__, loop, pinId, txEnMask);
        }
    }
    
    halSysrefCfg.uiSysrefEn = pSysrefCfg->sysrefEn;
    halSysrefCfg.uiTsEnable= txEnMask;
    halSysrefCfg.uiMode = pSysrefCfg->mode;
    halSysrefCfg.uiSysrefNum = pSysrefCfg->sysrefNum;
    retVal = IcHalApiSysrefRequest(&halSysrefCfg);
    return retVal;
}

UINT32 BspHalAdaptSysrefGenerate(T_BspHalAdaptSysrefCfg *pSysrefCfg)
{
    UINT32 retVal = BSP_OK;
    T_DifSysrefGenCfg halSysrefGenCfg = {0};
    INPUT_POINTER_CHECK(pSysrefCfg);
    
    halSysrefGenCfg.uiSysrefFrDelay = pSysrefCfg->sysrefFrDelay;
    halSysrefGenCfg.uiLocalcntSyncEn = pSysrefCfg->localcntSyncEn;
    halSysrefGenCfg.uiSyncSrc = pSysrefCfg->syncSrc;
    halSysrefGenCfg.uiPrd = pSysrefCfg->period;
    halSysrefGenCfg.uiWidth = pSysrefCfg->width;
    halSysrefGenCfg.uiSysPha = pSysrefCfg->sysPha;
    halSysrefGenCfg.uiIsExtSysref = pSysrefCfg->isExtSysref;
    retVal = IcHalApiSysrefGenerate(&halSysrefGenCfg);
    return retVal;
}

UINT32 BspHalAdaptGetSysrefStatus(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(TX == dir)
    {
        retVal = IcHalApiGetDlSysrefStatus(blockId);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiGetUlSysrefStatus(blockId);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetFbSysrefStatus(blockId);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;        
}

UINT32 BspHalAdaptGetSysrefValidFlag(UINT32 dir, UINT32 mapId, UINT32 *validFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    
    if(TX == dir)
    {
        retVal = IcHalApiGetDlSysrefValidFlag(blockId, mapId, validFlag);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiGetUlSysrefValidFlag(blockId, validFlag);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetFbSysrefValidFlag(blockId, validFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;       
}

UINT32 BspHalAdaptClrSysrefStatus(UINT32 dir,UINT32 laneIdMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(TX == dir)
    {
        retVal = IcHalApiClrDlSysrefStatus(blockId, 0);
        retVal |= IcHalApiClrDlSysrefStatus(blockId, 1);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiClrUlSysrefStatus(blockId);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiClrFbSysrefStatus(blockId);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;     
}

UINT32 BspHalAdaptClrMapSysrefStatus(UINT32 dir, UINT32 mapId)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    
    if(TX == dir)
    {
        retVal = IcHalApiClrDlSysrefStatus(blockId, mapId);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiClrUlSysrefStatus(blockId);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiClrFbSysrefStatus(blockId);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;     
}

UINT32 BspHalAdaptGetJ204State(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal)
{
    UINT32 blockId = 0;
    UINT32 j204cLaneId = laneId;
    UINT32 retVal = BSP_OK;

    if(j204cLaneId >= DPDIC_J204_RX_LANE_MAX_SUM)
    {
        return BSP_ERROR;
    }
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,0x1<<j204cLaneId); 

    if(RX == dir)
    {
        retVal = IcHalApiGetJ204UlState(blockId, j204cLaneId, regVal);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetJ204FbState(blockId, j204cLaneId, regVal);
    }    
    else 
    {
        return BSP_ERROR;
    }

    if(BSP_OK == retVal)
    {
        *state = ((*regVal)==BSP_HALADAPT_J204_LINK_OK_REGVAL)?BSP_HALADAPT_J204_LINK_OK:BSP_HALADAPT_J204_LINK_ERR;        
    }
    
    return retVal;    
}

UINT32 BspHalAdaptGetJ204UlAddrErrAlmVal(UINT32 blockId, UINT32 laneId, UINT32 *ulLaneErrVal)
{
    return IcHalApiGetJ204UlAddrErrAlmVal(blockId, laneId, ulLaneErrVal);
}

UINT32 BspHalAdaptSetJ204UlClrCrcErr(UINT32 blockId, UINT32 ulBitMask)
{
    return IcHalApiSetJ204UlClrCrcErr(blockId, ulBitMask);
}

UINT32 BspHalAdaptGetJ204UlCrcErr(UINT32 blockId, UINT32 laneId, UINT32 *ulLaneErrVal)
{
    return IcHalApiGetJ204UlCrcErr(blockId, laneId, ulLaneErrVal);
}

UINT32 BspHalAdaptSetJ204UlClr64B66BErr(UINT32 blockId, UINT32 ulBitMask)
{
    return IcHalApiSetJ204UlClr64B66BErr(blockId, ulBitMask);
}

UINT32 BspHalAdaptGetJ204Ul64B66BErr(UINT32 blockId, UINT32 laneId, UINT32 *ulLaneErrVal)
{
    return IcHalApiGetJ204Ul64B66BErr(blockId, laneId, ulLaneErrVal);
}

UINT32 BspHalAdaptGetJ204FbAddrErrAlmVal(UINT32 blockId, UINT32 laneId, UINT32 *fbLaneErrVal)
{
    return IcHalApiGetJ204FbAddrErrAlmVal(blockId, laneId, fbLaneErrVal);
}

UINT32 BspHalAdaptSetJ204FbClrCrcErr(UINT32 blockId, UINT32 bitMask)
{
    return IcHalApiSetJ204FbClrCrcErr(blockId, bitMask);
}

UINT32 BspHalAdaptGetJ204FbCrcErr(UINT32 blockId, UINT32 laneId, UINT32 *laneErrVal)
{
    return IcHalApiGetJ204FbCrcErr(blockId, laneId, laneErrVal);
}

UINT32 BspHalAdaptSetJ204FbClr64B66BErr(UINT32 blockId, UINT32 bitMask)
{
    return IcHalApiSetJ204FbClr64B66BErr(blockId, bitMask);
}

UINT32 BspHalAdaptGetJ204Fb64B66BErr(UINT32 blockId, UINT32 laneId, UINT32 *laneErrVal)
{
    return IcHalApiGetJ204Fb64B66BErr(blockId, laneId, laneErrVal);
}

UINT32 BspHalAdaptClrJ204UlState(UINT32 blockId)
{
    return IcHalApiClrJ204UlState(blockId);
}

UINT32 BspHalAdaptClrJ204FbState(UINT32 blockId)
{
    return IcHalApiClrJ204FbState(blockId);
}

/* 获取CRC误码数量 */
UINT32 BspHalAdaptGetJ204CrcErrCnt(UINT32 dir, UINT32 laneId, UINT32 *crcErrCnt)
{
    UINT32 blockId = 0;
    UINT32 j204cLaneId = laneId;
    UINT32 retVal = BSP_OK;
    UINT32 regVal = 0;

    if(j204cLaneId >= J204C_SERDES_LANE_MAX)
    {
        return BSP_ERROR;
    }
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,0x1<<j204cLaneId); 

    if(RX == dir)
    {
        retVal = IcHalApiGetUlCRCErrCode(blockId, j204cLaneId, &regVal);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetFbCRCErrCode(blockId, j204cLaneId, &regVal);
    }    
    else 
    {
        return BSP_ERROR;
    }

    if(BSP_OK == retVal)
    {
        *crcErrCnt = regVal;        
    }
    
    return retVal;        
}

UINT32 BspHalAdaptGetJ204RwAddrDifState(UINT32 dir, UINT32 laneId, UINT32 *state, UINT32 *regVal)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 j204cLaneId = laneId;
    UINT32 icRegVal = 0;

    if(RX == dir)
    {
        retVal = IcHalApiGetJ204UlAlignAddrDif(blockId, j204cLaneId, &icRegVal);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetJ204FbAlignAddrDif(blockId, j204cLaneId, &icRegVal);
    }
    else
    {
        return BSP_ERROR;
    }

    if(BSP_OK == retVal)
    {
        *regVal = icRegVal;
        if(icRegVal <= 2  || 0x1f == icRegVal || 0x1e == icRegVal)
        {
            *state = DPDIC_J204_RWADDR_ERROR;
        }
        else
        {
            *state = DPDIC_J204_RWADDR_NORMAL;
        }
    }
    return retVal;
}

UINT32 BspHalAdaptSetJ204LemcOffset(UINT32 dir, UINT32 offset)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;

    if(RX == dir)
    {
        retVal = IcHalApiSetJ204UlLemcOffset(blockId, offset);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiSetJ204FbLemcOffset(blockId, offset);
    }
    else
    {
        return BSP_ERROR;
    }
    return retVal;
}

UINT32 BspHalAdaptGetJ204LemcOffset(UINT32 dir, UINT32 *offset)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;

    if(RX == dir)
    {
        retVal = IcHalApiGetJ204UlLemcOffset(blockId, offset);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiGetJ204FbLemcOffset(blockId, offset);
    }
    else
    {
        return BSP_ERROR;
    }
    return retVal;
}

UINT32 BspHalAdaptSysrefRspEnable(UINT32 dir, UINT32 laneIdMask)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    if(RX == dir)
    {
        /** 重新响应上行sysref*/
        retVal = IcHalApiRspUlSysref(blockId);
    }
    else if(PRX == dir)
    {
        /** 重新响应反馈sysref*/
        retVal = IcHalApiRspFbSysref(blockId);
    }    
    else if(TX == dir)
    {
        /** 重新响应下行sysref*/
        retVal = IcHalApiRspDlSysref(blockId);
    }
    else
    {
        return BSP_ERROR;
    }

    return retVal;         
}


/**************************************************************************
                            J204c crm相关接口
**************************************************************************/
static UINT32 CrmJ204SetResetLogicByMap(UINT32 blockId, UINT32 dir, UINT32 mapId, UINT32 rstFlag)
{
    UINT32 chip = 0;
    
    if(TX == dir)
    {
        return IcHalApiCrmJ204SetResetDLMapSmp(chip, blockId, mapId, rstFlag);
    }
    else if(RX == dir)
    {
        return IcHalApiCrmJ204SetResetULMapSmp(chip, blockId, mapId, rstFlag);
    }
    else if(PRX == dir)
    {
        return IcHalApiCrmJ204SetResetFBMapSmp(chip, blockId, mapId, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }    
}

static UINT32 CrmJ204SetResetWorkMapByMap(UINT32 blockId, UINT32 dir, UINT32 mapId, UINT32 rstFlag)
{
    UINT32 chip = 0;

    if(TX == dir)
    {
        return IcHalApiCrmJ204SetResetDLMapWork(chip, blockId, mapId, rstFlag);
    }
    else if(RX == dir)
    {
        return IcHalApiCrmJ204SetResetULMapWork(chip, blockId, mapId, rstFlag);
    }
    else if(PRX == dir)
    {
        return IcHalApiCrmJ204SetResetFBMapWork(chip, blockId, mapId, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
}

UINT32 BspHalAdaptCrmJ204SetRstLogic(UINT32 dir, UINT32 laneIdMask, UINT32 mapMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 mapId = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    for(mapId=0; mapId<DPDIC_J204_MAP_NUM_MAX; mapId++)
    {
        if(BIT_VAL(mapMask, mapId))
        {
            retVal |= CrmJ204SetResetLogicByMap(blockId, dir, mapId, rstFlag);
        }
    }
    
    return retVal;    
}

UINT32 BspHalAdaptCrmJ204SetResetApb(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif

    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 
    if(TX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetDLApb(chip, blockId, rstFlag);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULApb(chip, blockId, rstFlag);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetFBApb(chip, blockId, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;      
}

UINT32 BspHalAdaptCrmJ204SetRstMap(UINT32 dir, UINT32 laneIdMask, UINT32 mapMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 mapId = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 

    for(mapId=0; mapId<DPDIC_J204_MAP_NUM_MAX; mapId++)
    {
        if(BIT_VAL(mapMask, mapId))
        {
            retVal |= CrmJ204SetResetWorkMapByMap(blockId, dir, mapId, rstFlag);
        }
    }

    return retVal;
}

UINT32 BspHalAdaptCrmJ204SetResetWorkLane(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif
    
    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask);  
    if(TX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetDLLinkLane(chip, blockId, laneIdMask, rstFlag);
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULLinkLane(chip, blockId, laneIdMask, rstFlag);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetFBLinkLane(chip, blockId, laneIdMask, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;    
}

UINT32 BspHalAdaptCrmJ204SetResetRf(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif

    blockId = GetJ204CBlockIdByJ204LaneMask(dir,laneIdMask); 
    if(TX == dir)
    {
        return BSP_ERROR;
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULRf(chip, blockId, rstFlag);
    }
    else if(PRX == dir)
    {
        return BSP_ERROR;
    }    
    else 
    {
        return BSP_ERROR;
    }
    return retVal;    

}

UINT32 BspHalAdaptCrmJ204SetResetDlSysref(UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif

    blockId = GetJ204CBlockIdByJ204LaneMask(TX,laneIdMask); 
    retVal = IcHalApiCrmJ204SetResetDLSysRef(chip, blockId, rstFlag);
    return retVal;    
}

UINT32 BspHalAdaptCrmJ204SetResetCtrl(UINT32 dir, UINT32 laneIdMask, UINT32 rstFlag)
{
    UINT32 retVal = BSP_OK;
    UINT32 blockId = 0;
    UINT32 chip = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif
    
    blockId = GetJ204CBlockIdByJ204LaneMask(TX,laneIdMask); 
    if(TX == dir)
    {
        return BSP_ERROR;
    }
    else if(RX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetULCtrl(chip, blockId, rstFlag);
    }
    else if(PRX == dir)
    {
        retVal = IcHalApiCrmJ204SetResetFBCtrl(chip, blockId, rstFlag);
    }    
    else 
    {
        return BSP_ERROR;
    }

    return retVal;    
}

UINT32 BspHalAdaptCrmJ204SetResetGlobalApb(UINT32 rstFlag)
{
    UINT32 chip = 0;
    UINT32 blockId = 0;

#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif

    return IcHalApiCrmJ204SetResetGlbApb(chip, blockId, rstFlag);
}

UINT32 BspHalAdaptGetJ204RegHeadAddr(UINT32 grpId)
{
    return 0xc7e00000;
}

UINT32 BspHalAdaptCrmJ204SetResetAll(UINT32 rstFlag)
{
#ifdef J204_CRM_RETURN_OK
    return BSP_OK;
#endif

    return IcHalApiCrmJ204SetResetAll(0, rstFlag);
}

UINT32 BspHalAdaptJ204JitOutWinCfg(UINT32 uiDir, UINT32 uiJitterVal)
{
    return IcHalApiJ204JitOutWinCfg(uiDir, uiJitterVal);
}


#if 0
UINT32 BspHalAdaptDpdicRegRd(UINT32 chip, UINT32 ulPhyAddr, UINT32 ulOffset, UINT32 *ulData)
{
    return DpdIcHalAddrRegRd(chip, ulPhyAddr, ulOffset, ulData);
}

UINT32 BspHalAdaptDpdicRegWr(UINT32 chip, UINT32 ulPhyAddr, UINT32 ulOffset, UINT32 ulData)
{
    return DpdIcHalAddrRegWr(chip, ulPhyAddr, ulOffset, ulData);
}

/**************************************************************************
                                 其他接口
**************************************************************************/
UINT32 BspHalAdaptGetTrxPinId(UINT32 TrxChipIdx, UINT32 *pPinId)
{
    /* 待后续补充 */
    return BSP_OK;
}
#endif

/* Started by AICoder, pid:i4b15c68f0q794c14f140a4c80be7a1326296305 */
UINT32 BspHalAdaptJ204SdsTxResetCfg(UINT32 laneIdMask, UINT32 reset)
{
    UINT32 retVal = BSP_OK;

    retVal = IcHalApiJ204SdsTxResetCfg(laneIdMask, reset);
    return retVal;
}
/* Ended by AICoder, pid:i4b15c68f0q794c14f140a4c80be7a1326296305 */

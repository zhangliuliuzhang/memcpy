#include "dif_func.h"
#include "ichaladapt_diffunc_ic4_2.h"

/* Started by AICoder, pid:52579ic7c1v07f914b310a92f04b7b00a45497bf */
UINT32 BspHalDifSetAllLteTdmChanLoopBack(UINT32 enableSwitch)
{
    UINT32 ret = BSP_OK;
    ret = IcHalDifSetAllLteTdmChanLoopBack(enableSwitch);
    return ret;
}
/* Ended by AICoder, pid:52579ic7c1v07f914b310a92f04b7b00a45497bf */
